// Fill out your copyright notice in the Description page of Project Settings.

#include "ResourceCheck/RuleBase.h"

#include "ResourceCheck/ResourceCheckHelper.h"
#include "Serialization/JsonWriter.h"
#include "Serialization/JsonSerializer.h"
#include "FileHelpers.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"
#include "ISourceControlModule.h"

static TAutoConsoleVariable<int32> CVarResourceCheckLocalTest(
	TEXT("r.ResourceChecker.LocalTest"),
	0,
	TEXT("Whether to local test resource check."),
	ECVF_Default);

bool URuleBase::CheckOne(const FAssetData& AssetData)
{
	bool bSuccess = true;
	if (PreExecuteAsset(AssetData))
	{
		CheckPropertiesAndFunctions(AssetData);
		if (HasErrorLog())
		{
			bSuccess = false;
		}
		PostExecuteAsset(AssetData);
	}
	CheckedAssetNum += 1;
	return bSuccess;
}

bool URuleBase::RepairOne(const bool& bPropertyAutoRepair, const FAssetData& AssetData, const FString& RepairFunctionName, TMap<FString, FString> RepairParameters)
{
	if (bPropertyAutoRepair)
	{
		UE_LOG(LogTemp, Log, TEXT("RepairProperty Start"));
		UObject* Asset = AssetData.GetAsset();
		for (auto Parameters : RepairParameters)
		{
			FString PropertyName = Parameters.Key;
			FString PropertyValue = Parameters.Value;
			if (FProperty* Property = Asset->GetClass()->FindPropertyByName(FName(*PropertyName)))
			{
				if (void* ValuePtr = Property->ContainerPtrToValuePtr<void>(Asset))
				{
					Property->ImportText_Direct(*PropertyValue, ValuePtr, Asset, PPF_None);
					FPropertyChangedEvent Event(Property);
					// LODGroup的PostEdit逻辑中会修改LOD Num,不触发post
					if (!Asset->IsA(UStaticMesh::StaticClass()) || PropertyName != "LODGroup" )
					{
						Asset->PostEditChangeProperty(Event);
					}
					// 可能存在值写入失败的情况，比如Texture的NeverStream必须在贴图大小是2的幂次方时才能设置为false
					FString Value;
					Property->ExportTextItem_Direct(Value, ValuePtr, nullptr, nullptr, PPF_None);
					if (Value == PropertyValue)
					{
						Asset->Modify();
						if(Asset->GetPackage()->MarkPackageDirty())
						{
							if (UEditorLoadingAndSavingUtils::SavePackages({AssetData.GetPackage()}, true))
							{
								return true;
							}
						}
					}
				}
			}
		}
	}
	else
	{
		UE_LOG(LogTemp, Log, TEXT("RepairFunction Start: %s"), *RepairFunctionName);
		if (RepairOneFunction(AssetData, RepairFunctionName, RepairParameters))
		{
			AssetData.GetPackage()->Modify();
			if (UEditorLoadingAndSavingUtils::SavePackages({AssetData.GetPackage()}, true))
			{
				return true;
			}
		}
	}
	return false;
}

bool URuleBase::RepairAllPending()
{
	TArray<int32> RepairedList;
	if (UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>())
	{
		for (int32 LogIndex = 0; LogIndex < Log.LogInfos.Num(); LogIndex++)
		{
			const FResourceCheckLogInfo& LogInfo = Log.LogInfos[LogIndex];
			if (!LogInfo.bAutoRepair)
			{
				continue;
			}
			const FResourceRepairData& RepairData = LogInfo.RepairData;
			if (RepairOne(RepairData.bPropertyAutoRepair, RepairData.RepairAssetData, RepairData.RepairFunctionName,RepairData.RepairParameters))
			{
				RepairedList.Add(LogIndex);
			}
		}
	
		for (int32 i = RepairedList.Num() - 1; i >= 0; i--)
		{
			Log.LogInfos.RemoveAt(RepairedList[i]);
		}
	}
	return RepairedList.Num() > 0;
}

void AddObjectPathInAssetSet(FString ObjectPath, TSet<FString>& Assets)
{
	FString PackageName = FPackageName::ObjectPathToPackageName(ObjectPath);
	FString FilePath = FPaths::ConvertRelativePathToFull(FPackageName::LongPackageNameToFilename(PackageName));
	if (FPaths::FileExists(FilePath + FPackageName::GetAssetPackageExtension()))
	{
		Assets.Add(FilePath + FPackageName::GetAssetPackageExtension());
	}
	else if (FPaths::FileExists(FilePath + FPackageName::GetMapPackageExtension()))
	{
		Assets.Add(FilePath + FPackageName::GetMapPackageExtension());
	}
}

bool URuleBase::RepairByJsonData(const FRMRuleRepairData& RuleRepairData, TSet<FString>& SuccessRepairAssetes, TSet<FString>& FailedRepairAssetes)
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	
	for (auto RepairData : RuleRepairData.RepairDetailList)
	{
		FAssetData AssetToRepair;
		AssetRegistryModule.TryGetAssetByObjectPath(RepairData.RepairAssetPath, AssetToRepair);
		UE_LOG(LogKGResourceManager, Display, TEXT("Repair %s by rule: %s"), *RepairData.RepairAssetPath, *RuleName)
		if (AssetToRepair.IsValid())
		{
			if (RepairOne(RepairData.bPropertyAutoRepair, AssetToRepair, RepairData.RepairFunctionName,RepairData.RepairParameters))
			{
				AddObjectPathInAssetSet(RepairData.RepairAssetPath, SuccessRepairAssetes);
			}
			else
			{
				AddObjectPathInAssetSet(RepairData.RepairAssetPath, FailedRepairAssetes);
			}
		}
	}
	return SuccessRepairAssetes.Num() == RuleRepairData.RepairDetailList.Num();
}

void URuleBase::Initialize(const FRMResCheckData& Data)
{
	CheckedAssetNum = 0;
	ResCheckWebData = Data;
	CustomParam = Data.CustomParam;
	Params.ParamList = Data.ParamList;
	// RuleName = Data.TemplateName;
	RuleName = Data.RuleName;
	
	//CheckType
	if (Data.CommitReport)
	{
		CheckRuleRange |= ERMCheckRuleRange::SubmitCheck;
	}
	if (Data.SourceReport)
	{
		CheckRuleRange |= ERMCheckRuleRange::ResourceCheck;
	}
	//CheckPath
	FString CheckPath = Data.CheckPath;
	TArray<FString> AllCheckPaths;
	CheckPath.ParseIntoArray(AllCheckPaths, TEXT("|"));
	for (auto Path : AllCheckPaths)
	{
		if (Path.StartsWith("-"))
		{
			ExpectCheckPaths.Add(Path.Mid(1));
		}
		else
		{
			CheckPaths.Add(Path);
		}
	}
	ImportRulesFromJsonString(Data.RuleJson);

	TArray<FAssetData> AssetDatas;
	PreExecuteAllObject(AssetDatas);
}

bool URuleBase::CheckPropertiesAndFunctions(const FAssetData& AssetData)
{
	bool bSuccess = true;
	bSuccess &= CheckProperties(AssetData);
	bSuccess &= CheckFunctions(AssetData);
	return bSuccess;
}

bool URuleBase::CheckCondition(const FAssetData& AssetData, FRMRule InRule)
{
	bool bRuleSuccess = true;

	if (InRule.RuleType == ERMCheckRuleType::Ignore)
	{
		return false;
	}
	
	if (InRule.bAnyRequire)
	{
		bool bRequirePass = true;
		for (auto Condition : InRule.ConditionRequirements)
		{
			if (Conditions.Contains(Condition))
			{
				bRequirePass = CheckOneProperty(Conditions[Condition], AssetData);
				if (bRequirePass)
				{
					break;
				}
			}
		}
		bRuleSuccess &= bRequirePass;
	}
	else
	{
		for (auto Condition : InRule.ConditionRequirements)
		{
			if (Conditions.Contains(Condition))
			{
				bRuleSuccess &= CheckOneProperty(Conditions[Condition], AssetData);
			}
		}
	}

	for (auto Condition : InRule.ConditionProhibits)
	{
		if (Conditions.Contains(Condition))
		{
			bRuleSuccess &= !CheckOneProperty(Conditions[Condition], AssetData);
		}
	}

	//在这里测试是否满足所选分支
	if (UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>())
	{
		TArray<FString> RuleBranchList;
		InRule.RuleBranch.ParseIntoArray(RuleBranchList, TEXT(","));
		// BranchName 为空(获取失败)，视为满足分支需要检查
		bool bLocalTest = RuleBranchList.Contains("EngineDev") && CVarResourceCheckLocalTest.GetValueOnAnyThread(true) == 1;
		bool bNotInCheckBranch = (RuleBranchList.Num() > 0 && !RuleBranchList.Contains(ResourceCheckSubsystem->BranchName)) && ResourceCheckSubsystem->BranchName != TEXT("");
		if (!bLocalTest && bNotInCheckBranch)
		{
			bRuleSuccess = false;
		}
	}
	return bRuleSuccess;
}

bool URuleBase::CheckProperties(const FAssetData& AssetData)
{
	bool bSuccess = true;
	for (auto RuleKV : PropertyRuleMappings)
	{
		auto Rule = RuleKV.Value;
		if (CheckCondition(AssetData, Rule.GetParent()))
		{			
			bSuccess &= CheckOneProperty(Rule, AssetData);
		}
	}
	return bSuccess;
}

bool URuleBase::CheckOneProperty(const FRMPropertyRule& PropertyRule, const FAssetData& AssetData)
{
	if (PropertyRule.RuleType == Ignore)
	{
		return true;
	}

	UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
	FResourceCheckLogManager& LogManager = ResourceCheckSubsystem->GetLogManager();
	LogManager.SetNewGuid();
	
	FString OutReason = TEXT("");
	CheckRuleType = PropertyRule.RuleType;
	TMap<FString, FString> OutRepairParameters;
	bool bSuccess = CheckOneProperty(PropertyRule.RuleMapping, PropertyRule.Comparer, AssetData, OutReason, OutRepairParameters, PropertyRule.bInvert);
	if (!bSuccess)
	{
		if(PropertyRule.CustomLog != TEXT(""))
		{
			Log.RegistryAndLog(AssetData, PropertyRule.RuleID, CheckRuleType, TEXT("{} | {}"), OutReason, PropertyRule.CustomLog);
		}
		else
		{
			Log.RegistryAndLog(AssetData, PropertyRule.RuleID, CheckRuleType, TEXT("{}"), OutReason);
		}
		FResourceCheckLogInfo& LogInfo = Log.LogInfos.Last();
		FGuid Guid = LogManager.GetGuid();
		for(int32 Index = Log.LogInfos.Num() - 1; Index >= 0; Index--)
		{
			if(Guid == Log.LogInfos[Index].RuleGuid)
			{
				if (PropertyRule.RepairType == ERMRepairType::FunctionRepair)
				{
					LogInfo.bAutoRepair = PropertyRule.IsAutoFix;
					LogInfo.RepairData = FResourceRepairData(AssetData, PropertyRule.RepairRule.FunctionName, OutRepairParameters);
				}
				else if (PropertyRule.RuleMapping.PropertyGetterFunc == "None")
				{
					if (PropertyRule.Comparer == ERMComparerType::Equal)
					{
						LogInfo.bAutoRepair = PropertyRule.IsAutoFix;
						LogInfo.RepairData = FResourceRepairData(AssetData, OutRepairParameters);
					}
					else if (PropertyRule.Comparer == ERMComparerType::Included)
					{
						bool bCanRepairIncluded = true;
						for (auto KV : OutRepairParameters)
						{
							if (KV.Value.Contains(","))
							{
								bCanRepairIncluded = false;
								break;
							}
						}
						if (bCanRepairIncluded)
						{
							LogInfo.bAutoRepair = PropertyRule.IsAutoFix;
							LogInfo.RepairData = FResourceRepairData(AssetData, OutRepairParameters);
						}
					}
				}
			}
			else
			{
				break;
			}
		}
	}
	return bSuccess;
}

bool URuleBase::CheckOneProperty(const FRMConditionRule& ConditionRule, const FAssetData& AssetData)
{
	FString OutReason = TEXT("");
	TMap<FString, FString> OutRepairParameters;
	return CheckOneProperty(ConditionRule.RuleMapping, ConditionRule.Comparer, AssetData, OutReason, OutRepairParameters, ConditionRule.bInvert);
}

bool URuleBase::CheckOneProperty(FRMPropertyRuleMapping RuleMapping, TEnumAsByte<ERMComparerType> Comparer, const FAssetData& AssetData, FString& OutReason, TMap<FString, FString>& OutRepairParameters, bool bInvert)
{
	FString PropertyValue;
	FString PropertyIdentifier;
	FString StandardValue;
	FString StandardIdentifier;

	FString PropertyName = RuleMapping.PropertyName;
	FString PropertyFunction = RuleMapping.PropertyGetterFunc;
	FString StandardParamValue = RuleMapping.StandardParam;
	FString StandardConstValue = RuleMapping.StandardValue;
	FString StandardValueFunction = RuleMapping.StandardValueGetterFunc;

	if (PropertyFunction != "None")
	{
		PropertyIdentifier = PropertyFunction;
		if (UFunction* PropertyGetterFunc = this->FindFunction(FName(PropertyIdentifier)))
		{
			FRMPropertyRuleParams PropertyGetterParams;
			PropertyGetterParams.AssetData = AssetData;
			this->ProcessEvent(PropertyGetterFunc, &PropertyGetterParams);
			PropertyValue = PropertyGetterParams.ReturnValue;
		}
	}
	else
	{
		PropertyIdentifier = PropertyName;
		PropertyValue = FResourceCheckHelper::GetPropertyValueByName(AssetData, PropertyIdentifier);
	}

	if (StandardValueFunction != "None")
	{
		if (UFunction* StandardGetterFunc = this->FindFunction(FName(StandardValueFunction)))
		{
			FRMPropertyRuleParams StandardGetterParams;
			StandardGetterParams.AssetData = AssetData;
			this->ProcessEvent(StandardGetterFunc, &StandardGetterParams);
			StandardValue = StandardGetterParams.ReturnValue;
		}
	}
	else
	{
		if(Params.ParamList.Contains(StandardParamValue))
		{
			StandardValue = Params.GetValue(StandardParamValue);
		}
		else
		{
			StandardValue = StandardConstValue;
		}
	}

	bool bCheckPass = true;
	FString StandardText;

	switch (Comparer)
	{
	case Equal:
		{
			StandardText = FString::Printf(TEXT("等于 %s"), *StandardValue);
			if (PropertyValue != StandardValue)
			{
				bCheckPass = false;
			}
			break;
		}
	case NotEqual:
		{
			StandardText = FString::Printf(TEXT("不等于 %s"), *StandardValue);
			if (PropertyValue == StandardValue)
			{
				bCheckPass = false;
			}
			break;
		}
	case GreaterThanOrEqualTo:
		{
			if (bInvert)
			{
				StandardText = FString::Printf(TEXT("小于 %s"), *StandardValue);
			}
			else
			{
				StandardText = FString::Printf(TEXT("大于等于 %s"), *StandardValue);
			}
			TArray<FString> CurrentValueArray;
			PropertyValue.ParseIntoArray(CurrentValueArray, TEXT(","), true);

			bool bLess = false;
			for (const auto& CurVal : CurrentValueArray)
			{
				bLess |= (FCString::Atod(*CurVal) < FCString::Atod(*StandardValue));
			}

			if (bLess)
			{
				bCheckPass = false;
			}
			break;
		}
	case LessThanOrEqualTo:
		{
			if (bInvert)
			{
				StandardText = FString::Printf(TEXT("大于 %s"), *StandardValue);
			}
			else
			{
				StandardText = FString::Printf(TEXT("小于等于 %s"), *StandardValue);
			}
			TArray<FString> CurrentValueArray;
			PropertyValue.ParseIntoArray(CurrentValueArray, TEXT(","), true);

			bool bMore = false;
			for (const auto& CurVal : CurrentValueArray)
			{
				bMore |= (FCString::Atod(*CurVal) > FCString::Atod(*StandardValue));
			}

			if (bMore)
			{
				bCheckPass = false;
			}
		}
		break;
	case Interval:
		{
			TArray<FString> StandardValueArray;
			StandardValue.ParseIntoArray(StandardValueArray, TEXT(","), true);
			if (StandardValueArray.Num() > 1)
			{
				StandardText = FString::Printf(TEXT("在区间 %s-%s中"), *StandardValueArray[0], *StandardValueArray[1]);
				TArray<FString> CurrentValueArray;
				PropertyValue.ParseIntoArray(CurrentValueArray, TEXT(","), true);
				bool bInterval = true;
				for (const auto& CurVal : CurrentValueArray)
				{
					bInterval &= (FCString::Atod(*CurVal) >= FCString::Atod(*StandardValueArray[0]) && FCString::Atod(*CurVal) <= FCString::Atod(*StandardValueArray[1]));
				}
				bCheckPass = bInterval;
			}
		}
		break;
		
	case PowerOf:
		{
			StandardText = FString::Printf(TEXT("为 %s 的幂次"), *StandardValue);
			TArray<FString> CurrentValueArray;
			PropertyValue.ParseIntoArray(CurrentValueArray, TEXT(","), true);

			bool bNotPowerOfTwo = false;
			for (const auto& CurVal : CurrentValueArray)
			{
				bNotPowerOfTwo |= (!FMath::IsPowerOfTwo(FCString::Atoi(*CurVal)));
			}

			if (bNotPowerOfTwo)
			{
				bCheckPass = false;
			}
		}
		break;
	case DividedBy:
		{
			StandardText = FString::Printf(TEXT("可以被 %s 整除"), *StandardValue);
			TArray<FString> CurrentValueArray;
			PropertyValue.ParseIntoArray(CurrentValueArray, TEXT(","), true);

			bool bNotDividedByFour = false;
			int32 TotalSize = 1;
			int32 Standard = FCString::Atoi(*StandardValue);
			for (const auto& CurVal : CurrentValueArray)
			{
				int32 Size = FCString::Atoi(*CurVal);
				if (Size >= 0)
				{
					TotalSize *= Size;
					bNotDividedByFour |= (Size % Standard != 0);
				}
			}

			if (bNotDividedByFour)
			{
				bCheckPass = false;
			}
		}
		break;
	case Included:
		{
			if (bInvert)
			{
				StandardText = FString::Printf(TEXT("不属于 %s"), *StandardValue);
			}
			else
			{
				StandardText = FString::Printf(TEXT("属于 %s"), *StandardValue);
			}
			TArray<FString> CurrentValueArray;
			PropertyValue.ParseIntoArray(CurrentValueArray, TEXT(","), false);
			TArray<FString> StandardValueArray;
			StandardValue.ParseIntoArray(StandardValueArray, TEXT(","), false);
			if (StandardValueArray.Num() == 1)
			{
				StandardText = FString::Printf(TEXT("等于 %s"), *StandardValue);
			}

			bool bNotIncluded = false;

			for (const auto& CurVal : CurrentValueArray)
			{
				if (!StandardValueArray.Contains(CurVal))
				{
					bNotIncluded = true;
					break;
				}
			}
			if (bNotIncluded)
			{
				bCheckPass = false;
			}
		}
		break;
	case Include:
		{
			if (bInvert)
			{
				StandardText = FString::Printf(TEXT("不包含 %s"), *StandardValue);
			}
			else
			{
				StandardText = FString::Printf(TEXT("包含 %s"), *StandardValue);
			}
			TArray<FString> CurrentValueArray;
			PropertyValue.ParseIntoArray(CurrentValueArray, TEXT(","), false);
			TArray<FString> StandardValueArray;
			StandardValue.ParseIntoArray(StandardValueArray, TEXT(","), false);

			bool bNotInclude = false;

			for (const auto& CurVal : StandardValueArray)
			{
				if (!CurrentValueArray.Contains(CurVal))
				{
					bNotInclude = true;
					break;
				}
			}
			if (bNotInclude)
			{
				bCheckPass = false;
			}
		}
		break;
	case Contained:
		{
			if (bInvert)
			{
				StandardText = FString::Printf(TEXT("不属于字符串 %s"), *StandardValue);
			}
			else
			{
				StandardText = FString::Printf(TEXT("属于字符串 %s"), *StandardValue);
			}
			if (!StandardValue.Contains(PropertyValue))
			{
				bCheckPass = false;
			}
		}
		break;
	case Contain:
		{
			if (bInvert)
			{
				StandardText = FString::Printf(TEXT("不包含字符串 %s"), *StandardValue);
			}
			else
			{
				StandardText = FString::Printf(TEXT("包含字符串 %s"), *StandardValue);
			}
			TArray<FString> StandardValueArray;
			StandardValue.ParseIntoArray(StandardValueArray, TEXT("|"), true);
			bool bInclude = false;
			for (const FString& CurVal : StandardValueArray)
			{
				if (PropertyValue.Contains(CurVal))
				{
					bInclude = true;
					break;
				}
			}
			if (!bInclude)
			{
				bCheckPass = false;
			}
		}
		break;
	case StartsWith:
		{
			if (bInvert)
			{
				StandardText = FString::Printf(TEXT("字符串不以 %s 开头"), *StandardValue);
			}
			else
			{
				StandardText = FString::Printf(TEXT("字符串以 %s 开头"), *StandardValue);
			}
			if (!PropertyValue.StartsWith(StandardValue))
			{
				bCheckPass = false;
			}
		}
		break;
	case EndsWith:
		{
			if (bInvert)
			{
				StandardText = FString::Printf(TEXT("字符串不以 %s 结尾"), *StandardValue);
			}
			else
			{
				StandardText = FString::Printf(TEXT("字符串以 %s 结尾"), *StandardValue);
			}
			if (!PropertyValue.EndsWith(StandardValue))
			{
				bCheckPass = false;
			}
		}
		break;
	default:
		break;
	}
	OutReason = FString::Format(TEXT("当前属性{0}={1}(应该 {2})"), {PropertyIdentifier, PropertyValue, StandardText});

	// 用来做修复的参数
	OutRepairParameters.Add(PropertyIdentifier, StandardValue);
	return bInvert ? !bCheckPass : bCheckPass;
}

bool URuleBase::CheckFunctions(const FAssetData& AssetData)
{
	bool bSuccess = true;
	for (auto RuleKV : FuncRuleMappings)
	{
		auto Rule = RuleKV.Value;
		if (CheckCondition(AssetData, Rule.GetParent()))
		{
			bSuccess &= CheckOneFunction(Rule, AssetData);
		}
	}
	return bSuccess;
}

bool URuleBase::CheckOneFunction(const FRMFunctionRule& FunctionRule, const FAssetData& AssetData)
{
	bool bSuccess = true;

	UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
	FResourceCheckLogManager& LogManager = ResourceCheckSubsystem->GetLogManager();
	LogManager.SetNewGuid();
	
	if (FunctionRule.RuleMapping.FunctionName != "None")
	{
		FString FunctionIdentifier = FunctionRule.RuleMapping.FunctionName;
		UFunction* Function = this->FindFunction(FName(FunctionIdentifier));
		CheckRuleType = FunctionRule.RuleType;
		if (Function)
		{
			FRMFunctionRuleParams FunctionRuleParams;
			FunctionRuleParams.AssetData = AssetData;
			int32 PreLogNum = Log.LogInfos.Num();
			this->ProcessEvent(Function, &FunctionRuleParams);
			bSuccess &= FunctionRuleParams.bSuccess;
			if (!FunctionRuleParams.bSuccess && FunctionRule.RepairType == ERMRepairType::FunctionRepair)
			{
				int32 LogNum = Log.LogInfos.Num();
				if (LogNum == PreLogNum)
				{
					UE_LOG(LogKGResourceManager, Warning, TEXT("Check result is not valid but not add Log!"))
				}
				else
				{
					FGuid Guid = LogManager.GetGuid();
					for(int32 Index = Log.LogInfos.Num() - 1; Index >= 0; Index--)
					{
						if(Guid == Log.LogInfos[Index].RuleGuid)
						{
							Log.LogInfos[Index].bAutoRepair = FunctionRule.IsAutoFix;
							Log.LogInfos[Index].RepairData = FResourceRepairData(AssetData, FunctionRule.RepairRule.FunctionName, FunctionRuleParams.RepairParams);
						}
						else
						{
							break;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool URuleBase::RepairOneFunction(const FAssetData& AssetData, const FString& FunctionName, const TMap<FString, FString>& InRepairParams)
{
	bool bSuccess = true;
	if (FunctionName != "None")
	{
		if (UFunction* Function = this->FindFunction(FName(FunctionName)))
		{
			FRMRepairRuleParams RepairRuleParams;
			RepairRuleParams.AssetData = AssetData;
			RepairRuleParams.RepairParams = InRepairParams;
			this->ProcessEvent(Function, &RepairRuleParams);
			bSuccess &= RepairRuleParams.bSuccess;
		}
	}
	return bSuccess;
}

FRMRuleReport URuleBase::GetRuleReport()
{
	return RuleReport;
}

// ==== Import And Export Start ==== 

void URuleBase::ImportRuleFromWeb(const FString InRuleName)
{
	TArray<FRMResCheckData> ResCheckDataList;
	FResourceCheckHelper::GetRuleFunctionFromWeb(ResCheckDataList);
	for(auto ResCheckData : ResCheckDataList)
	{
		if(ResCheckData.RuleName == InRuleName)
		{
			Initialize(ResCheckData);
		}
	}
}

void URuleBase::ImportRulesFromJsonString(const FString& JsonString)
{	
	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
	if (UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>())
	{
		if (FJsonSerializer::Deserialize(Reader, JsonObject))
		{
			if(JsonObject->HasField(TEXT("Conditions")))
			{
				Conditions.Empty();
				TSharedPtr<FJsonObject> ConditionsObject = JsonObject->GetObjectField(TEXT("Conditions"));
				for(auto ConditionKV : ConditionsObject->Values)
				{
					FString RuleID = ConditionKV.Key;
					TSharedPtr<FJsonObject> Condition = ConditionKV.Value->AsObject();
					FString ConditionsPropertyName = Condition->GetStringField(TEXT("PropertyName"));
					FString ConditionsPropertyGetterFunc = Condition->GetStringField(TEXT("PropertyGetterFunc"));
				
					FString ConditionsStandardParam = Condition->GetStringField(TEXT("StandardParam"));
					FString ConditionsStandardValue = Condition->GetStringField(TEXT("StandardValue"));
					FString ConditionsStandardValueGetterFunc = Condition->GetStringField(TEXT("StandardValueGetterFunc"));
					FString ConditionsComparer = Condition->GetStringField(TEXT("Comparer"));
					FString ConditionsDescription = Condition->GetStringField(TEXT("Description"));

					FRMConditionRule KGConditionRule;

					KGConditionRule.RuleMapping.PropertyName = ConditionsPropertyName;
					KGConditionRule.RuleMapping.PropertyGetterFunc = ConditionsPropertyGetterFunc;

					KGConditionRule.RuleMapping.StandardParam = ConditionsStandardParam;
					KGConditionRule.RuleMapping.StandardValue = ConditionsStandardValue;
					KGConditionRule.RuleMapping.StandardValueGetterFunc = ConditionsStandardValueGetterFunc;
					UEnum* EnumPtr = StaticEnum<ERMComparerType>();
					KGConditionRule.Comparer = static_cast<ERMComparerType>(EnumPtr->GetValueByName(FName(ConditionsComparer)));
					KGConditionRule.bInvert = Condition->GetBoolField(TEXT("bInvert"));
					KGConditionRule.Description = ConditionsDescription;
					Conditions.FindOrAdd(RuleID) = KGConditionRule;
				}
			}
			if(JsonObject->HasField(TEXT("PropertyRules")))
			{
				PropertyRuleMappings.Empty();
				TSharedPtr<FJsonObject> PropertyRulesObject = JsonObject->GetObjectField(TEXT("PropertyRules"));
				for(auto PropertyRuleKV : PropertyRulesObject->Values)
				{
					FString RuleID = PropertyRuleKV.Key;
					TSharedPtr<FJsonObject> PropertyRule = PropertyRuleKV.Value->AsObject();
					FString PropertyRulePropertyName = PropertyRule->GetStringField(TEXT("PropertyName"));
					FString PropertyRulePropertyGetterFunc = PropertyRule->GetStringField(TEXT("PropertyGetterFunc"));

					FString PropertyRuleStandardParam = PropertyRule->GetStringField(TEXT("StandardParam"));
					FString PropertyRuleStandardValue = PropertyRule->GetStringField(TEXT("StandardValue"));
					FString PropertyRuleStandardValueGetterFunc = PropertyRule->GetStringField(TEXT("StandardValueGetterFunc"));
					FString PropertyRuleComparer = PropertyRule->GetStringField(TEXT("Comparer"));
					FString PropertyRuleCustomLog = TEXT("");
					if(PropertyRule->HasField(TEXT("CustomLog")))
					{
						PropertyRuleCustomLog = PropertyRule->GetStringField(TEXT("CustomLog"));
					}
						
					FString PropertyRuleType = PropertyRule->GetStringField(TEXT("RuleType"));
					FString PropertyRuleDescription = PropertyRule->GetStringField(TEXT("Description"));
					TSet<FString> PropertyRuleConditionRequirements;
					TArray<TSharedPtr<FJsonValue>> ConditionRequirementsObject = PropertyRule->GetArrayField(TEXT("ConditionRequirements"));
					for(auto& ConditionRequirementObject : ConditionRequirementsObject)
					{
						PropertyRuleConditionRequirements.Add(ConditionRequirementObject->AsString());
					}
					TSet<FString> PropertyRuleConditionProhibits;
					TArray<TSharedPtr<FJsonValue>> ConditionProhibitsObject = PropertyRule->GetArrayField(TEXT("ConditionProhibits"));
					for(auto& ConditionProhibitObject : ConditionProhibitsObject)
					{
						PropertyRuleConditionProhibits.Add(ConditionProhibitObject->AsString());
					}

					FString PropertyRuleBranch = PropertyRule->HasField(TEXT("RuleBranch")) ? PropertyRule->GetStringField(TEXT("RuleBranch")) : TEXT("");
						
					FRMPropertyRule KGPropertyRule;
					KGPropertyRule.RuleMapping.PropertyName = PropertyRulePropertyName;
					KGPropertyRule.RuleMapping.PropertyGetterFunc = PropertyRulePropertyGetterFunc;
				
					KGPropertyRule.RuleMapping.StandardParam = PropertyRuleStandardParam;
					KGPropertyRule.RuleMapping.StandardValue = PropertyRuleStandardValue;
					KGPropertyRule.RuleMapping.StandardValueGetterFunc = PropertyRuleStandardValueGetterFunc;
					UEnum* EnumPtr = StaticEnum<ERMComparerType>();
					KGPropertyRule.Comparer = static_cast<ERMComparerType>(EnumPtr->GetValueByName(FName(PropertyRuleComparer)));
					KGPropertyRule.bInvert = PropertyRule->GetBoolField(TEXT("bInvert"));
					KGPropertyRule.CustomLog = PropertyRuleCustomLog;
					EnumPtr = StaticEnum<ERMCheckRuleType>();
					KGPropertyRule.RuleType = static_cast<ERMCheckRuleType>(EnumPtr->GetValueByName(FName(PropertyRuleType)));
					KGPropertyRule.RuleID = RuleID;
					KGPropertyRule.Description = PropertyRuleDescription;
					KGPropertyRule.ConditionRequirements.Empty();
					KGPropertyRule.ConditionRequirements.Append(PropertyRuleConditionRequirements);
					KGPropertyRule.bAnyRequire = PropertyRule->GetBoolField(TEXT("bAnyRequire"));
					KGPropertyRule.ConditionProhibits.Empty();
					KGPropertyRule.ConditionProhibits.Append(PropertyRuleConditionProhibits);
					KGPropertyRule.RuleBranch = PropertyRuleBranch;

					FString RepairType = PropertyRule->GetStringField(TEXT("RepairType"));
					UEnum* RepairEnumPtr = StaticEnum<ERMRepairType>();
					KGPropertyRule.RepairType = static_cast<ERMRepairType>(RepairEnumPtr->GetValueByName(FName(RepairType)));
					
					FString RepairFunction = PropertyRule->GetStringField(TEXT("RepairFunction"));
					KGPropertyRule.RepairRule.FunctionName = RepairFunction;

					
					if (ResourceCheckSubsystem->RuleRange == ERMCheckRuleRange::ResourceCheck)
					{
						KGPropertyRule.IsAutoFix = PropertyRule->HasField(TEXT("isFix")) ? PropertyRule->GetBoolField(TEXT("isFix")) : false;
					}
					else
					{
						KGPropertyRule.IsAutoFix = true;
					}
					
					PropertyRuleMappings.FindOrAdd(RuleID) = KGPropertyRule;
				}
			}

			if(JsonObject->HasField(TEXT("FunctionRules")))
			{
				FuncRuleMappings.Empty();
				TSharedPtr<FJsonObject> FunctionRulesObject = JsonObject->GetObjectField(TEXT("FunctionRules"));		
				for(auto FunctionRuleKV : FunctionRulesObject->Values)
				{
					FString RuleID = FunctionRuleKV.Key;
					TSharedPtr<FJsonObject> FunctionRule = FunctionRuleKV.Value->AsObject();
					FString FunctionRulePropertyName = FunctionRule->GetStringField(TEXT("FunctionName"));
						
					FString FunctionRuleType = FunctionRule->GetStringField(TEXT("RuleType"));
					FString FunctionRuleDescription = FunctionRule->GetStringField(TEXT("Description"));
					TSet<FString> FunctionRuleConditionRequirements;
					TArray<TSharedPtr<FJsonValue>> ConditionRequirementsObject = FunctionRule->GetArrayField(TEXT("ConditionRequirements"));
					for(auto& ConditionRequirementObject : ConditionRequirementsObject)
					{
						FunctionRuleConditionRequirements.Add(ConditionRequirementObject->AsString());
					}
					TSet<FString> FunctionRuleConditionProhibits;
					TArray<TSharedPtr<FJsonValue>> ConditionProhibitsObject = FunctionRule->GetArrayField(TEXT("ConditionProhibits"));
					for(auto& ConditionProhibitObject : ConditionProhibitsObject)
					{
						FunctionRuleConditionProhibits.Add(ConditionProhibitObject->AsString());
					}

					FString FunctionRuleBranch = FunctionRule->HasField(TEXT("RuleBranch")) ? FunctionRule->GetStringField(TEXT("RuleBranch")) : TEXT("");
					
					FRMFunctionRule KGFunctionRule;
					KGFunctionRule.RuleMapping.FunctionName = FunctionRulePropertyName;
					UEnum* EnumPtr = StaticEnum<ERMCheckRuleType>();
					KGFunctionRule.RuleType = static_cast<ERMCheckRuleType>(EnumPtr->GetValueByName(FName(FunctionRuleType)));
					KGFunctionRule.RuleID = RuleID;
					KGFunctionRule.Description = FunctionRuleDescription;
					KGFunctionRule.ConditionRequirements.Empty();
					KGFunctionRule.ConditionRequirements.Append(FunctionRuleConditionRequirements);
					KGFunctionRule.bAnyRequire = FunctionRule->HasField(TEXT("bAnyRequire")) ? FunctionRule->GetBoolField(TEXT("bAnyRequire")) : false;
					KGFunctionRule.ConditionProhibits.Empty();
					KGFunctionRule.ConditionProhibits.Append(FunctionRuleConditionProhibits);
					KGFunctionRule.RuleBranch = FunctionRuleBranch;

					FString RepairType = FunctionRule->GetStringField(TEXT("RepairType"));
					UEnum* RepairEnumPtr = StaticEnum<ERMRepairType>();
					KGFunctionRule.RepairType = static_cast<ERMRepairType>(RepairEnumPtr->GetValueByName(FName(RepairType)));
					
					FString RepairFunction = FunctionRule->GetStringField(TEXT("RepairFunction"));
					KGFunctionRule.RepairRule.FunctionName = RepairFunction;

					if (ResourceCheckSubsystem->RuleRange == ERMCheckRuleRange::ResourceCheck)
					{
						KGFunctionRule.IsAutoFix = FunctionRule->HasField(TEXT("isFix")) ? FunctionRule->GetBoolField(TEXT("isFix")) : false;
					}
					else
					{
						KGFunctionRule.IsAutoFix = true;
					}					
						
					FuncRuleMappings.FindOrAdd(RuleID) = KGFunctionRule;
				}
			}
					
			if (JsonObject->HasField(TEXT("RuleRequirements")))
			{
				TArray<TSharedPtr<FJsonValue>> RuleRequirementsObject = JsonObject->GetArrayField(TEXT("RuleRequirements"));
				for(auto& RuleRequirementObject : RuleRequirementsObject)
				{
					RuleRequirements.Add(RuleRequirementObject->AsString());
				}
			}

			if (JsonObject->HasField(TEXT("bAnyRequire")))
			{
				bAnyRequire = JsonObject->GetBoolField(TEXT("bAnyRequire"));
			}
			
			if (JsonObject->HasField(TEXT("RuleProhibits")))
			{
				TArray<TSharedPtr<FJsonValue>> RuleProhibitsObject = JsonObject->GetArrayField(TEXT("RuleProhibits"));
				for(auto& RuleProhibitObject : RuleProhibitsObject)
				{
					RuleProhibits.Add(RuleProhibitObject->AsString());
				}
			}

			RuleVersion = JsonObject->HasField(TEXT("RuleVersion")) ? JsonObject->GetIntegerField(TEXT("RuleVersion")) : 0;
		}
	}		
}

void URuleBase::ExportRulesToJson(const FString InRuleName)
{
	FString JsonString;
	FString ExportPath = FPaths::RootDir() / TEXT("Tools/C7ResourceChecker") / InRuleName + TEXT(".json");

	if (FPaths::FileExists(ExportPath))
	{
		IFileManager& FileManager = IFileManager::Get();
		FileManager.Delete(*ExportPath);
	}
	
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject);
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonString);

	TSharedPtr<FJsonObject> ConditionsObject = MakeShareable(new FJsonObject);
	for(auto ConditionKV : Conditions)
	{
		FRMConditionRule Condition = ConditionKV.Value;

		TSharedPtr<FJsonObject> ConditionObject = MakeShareable(new FJsonObject);
		ConditionObject->SetStringField(TEXT("PropertyName"), Condition.RuleMapping.PropertyName);
		ConditionObject->SetStringField(TEXT("PropertyGetterFunc"), Condition.RuleMapping.PropertyGetterFunc);

		ConditionObject->SetStringField(TEXT("StandardParam"), Condition.RuleMapping.StandardParam);
		ConditionObject->SetStringField(TEXT("StandardValue"), Condition.RuleMapping.StandardValue);
		ConditionObject->SetStringField(TEXT("StandardValueGetterFunc"), Condition.RuleMapping.StandardValueGetterFunc);
		UEnum* EnumPtr = StaticEnum<ERMComparerType>();
		ConditionObject->SetStringField(TEXT("Comparer"), EnumPtr->GetNameByValue(Condition.Comparer.GetValue()).ToString());
		ConditionObject->SetBoolField(TEXT("bInvert"), Condition.bInvert);
		ConditionObject->SetStringField(TEXT("Description"),Condition.Description);
		
		ConditionsObject->SetObjectField(ConditionKV.Key, ConditionObject);
	}
	JsonObject->SetObjectField(TEXT("Conditions"), ConditionsObject);

	TSharedPtr<FJsonObject> PropertyRulesObject = MakeShareable(new FJsonObject);
	for(auto PropertyRuleKV : PropertyRuleMappings)
	{
		FRMPropertyRule PropertyRule = PropertyRuleKV.Value;
		FString WebShowText = TEXT("");

		TSharedPtr<FJsonObject> PropertyRuleObject = MakeShareable(new FJsonObject);
		PropertyRuleObject->SetStringField(TEXT("PropertyName"), PropertyRule.RuleMapping.PropertyName);
		PropertyRuleObject->SetStringField(TEXT("PropertyGetterFunc"), PropertyRule.RuleMapping.PropertyGetterFunc);

		PropertyRuleObject->SetStringField(TEXT("StandardParam"), PropertyRule.RuleMapping.StandardParam);
		PropertyRuleObject->SetStringField(TEXT("StandardValue"), PropertyRule.RuleMapping.StandardValue);		
		PropertyRuleObject->SetStringField(TEXT("StandardValueGetterFunc"), PropertyRule.RuleMapping.StandardValueGetterFunc);
		UEnum* EnumPtr = StaticEnum<ERMComparerType>();
		PropertyRuleObject->SetStringField(TEXT("Comparer"), EnumPtr->GetNameByValue(PropertyRule.Comparer.GetValue()).ToString());
		PropertyRuleObject->SetBoolField(TEXT("bInvert"), PropertyRule.bInvert);
		PropertyRuleObject->SetStringField(TEXT("CustomLog"), PropertyRule.CustomLog);
		EnumPtr = StaticEnum<ERMCheckRuleType>();
		PropertyRuleObject->SetStringField(TEXT("RuleType"), EnumPtr->GetNameByValue(PropertyRule.RuleType.GetValue()).ToString());
		PropertyRuleObject->SetStringField(TEXT("RuleTypeDesc"), EnumPtr->GetDisplayNameTextByValue(PropertyRule.RuleType.GetValue()).ToString());
		PropertyRuleObject->SetStringField(TEXT("Description"), PropertyRule.Description);

		WebShowText += PropertyRule.Description; 
		
		TArray<TSharedPtr<FJsonValue>> ConditionRequirementsObject;
		if(PropertyRule.ConditionRequirements.Num() > 0 || RuleRequirements.Num() > 0)
		{
			WebShowText +=  TEXT("\n规则条件:");
			for(auto& RuleRequirement : RuleRequirements)
			{
				if(Conditions.Contains(RuleRequirement))
				{
					WebShowText += Conditions[RuleRequirement].Description + TEXT(" ");
				}
			}
			
			for(auto& ConditionRequirement : PropertyRule.ConditionRequirements)
			{
				ConditionRequirementsObject.Add(MakeShareable(new FJsonValueString(ConditionRequirement)));
				if(Conditions.Contains(ConditionRequirement))
				{
					WebShowText += Conditions[ConditionRequirement].Description + TEXT(" ");
				}
			}
		}
		PropertyRuleObject->SetArrayField(TEXT("ConditionRequirements"), ConditionRequirementsObject);
		PropertyRuleObject->SetBoolField(TEXT("bAnyRequire"), PropertyRule.bAnyRequire);

		TArray<TSharedPtr<FJsonValue>> ConditionProhibitsObject;
		if(PropertyRule.ConditionProhibits.Num() > 0 || RuleProhibits.Num() > 0)
		{
			WebShowText +=  TEXT("\n排除条件:");
			for(auto& RuleProhibit : RuleProhibits)
			{
				if(Conditions.Contains(RuleProhibit))
				{
					WebShowText += Conditions[RuleProhibit].Description + TEXT(" ");
				}
			}
			
			for(auto& ConditionProhibit : PropertyRule.ConditionProhibits)
			{
				ConditionProhibitsObject.Add(MakeShareable(new FJsonValueString(ConditionProhibit)));
				if(Conditions.Contains(ConditionProhibit))
				{
					WebShowText += Conditions[ConditionProhibit].Description + TEXT(" ");
				}
			}
		}

    	PropertyRuleObject->SetArrayField(TEXT("ConditionProhibits"), ConditionProhibitsObject);
		
		if (PropertyRule.RuleBranch != TEXT(""))
		{
			WebShowText += TEXT("\n作用分支:") + PropertyRule.RuleBranch;
		}
		PropertyRuleObject->SetStringField(TEXT("RuleBranch"), PropertyRule.RuleBranch);
		
		PropertyRuleObject->SetStringField(TEXT("WebShowText"), WebShowText);
		
		PropertyRulesObject->SetObjectField(PropertyRuleKV.Key, PropertyRuleObject);

		UEnum* RepairEnumPtr = StaticEnum<ERMRepairType>();
		PropertyRuleObject->SetStringField(TEXT("RepairType"), RepairEnumPtr->GetNameByValue(PropertyRule.RepairType.GetValue()).ToString());

		PropertyRuleObject->SetStringField(TEXT("RepairFunction"), PropertyRule.RepairRule.FunctionName);
	}
	JsonObject->SetObjectField(TEXT("PropertyRules"), PropertyRulesObject);
	
	TSharedPtr<FJsonObject> FunctionRulesObject = MakeShareable(new FJsonObject);
	for(auto FunctionRuleKV : FuncRuleMappings)
    {
    	FRMFunctionRule FunctionRule = FunctionRuleKV.Value;
		FString WebShowText = TEXT("");
		
    	TSharedPtr<FJsonObject> FunctionRuleObject = MakeShareable(new FJsonObject);
    	FunctionRuleObject->SetStringField(TEXT("FunctionName"), FunctionRule.RuleMapping.FunctionName);
    	
    	UEnum* EnumPtr = StaticEnum<ERMCheckRuleType>();
    	FunctionRuleObject->SetStringField(TEXT("RuleType"), EnumPtr->GetNameByValue(FunctionRule.RuleType.GetValue()).ToString());
		FunctionRuleObject->SetStringField(TEXT("RuleTypeDesc"), EnumPtr->GetDisplayNameTextByValue(FunctionRule.RuleType.GetValue()).ToString());
    	FunctionRuleObject->SetStringField(TEXT("Description"), FunctionRule.Description);
		WebShowText += FunctionRule.Description;
		
    	TArray<TSharedPtr<FJsonValue>> ConditionRequirementsObject;
		if(FunctionRule.ConditionRequirements.Num() > 0 || RuleRequirements.Num() > 0)
		{
			WebShowText +=  TEXT("\n规则条件:");
			for(auto& RuleRequirement : RuleRequirements)
			{
				if(Conditions.Contains(RuleRequirement))
				{
					WebShowText += Conditions[RuleRequirement].Description + TEXT(" ");
				}
			}			
			for(auto& ConditionRequirement : FunctionRule.ConditionRequirements)
			{				
				ConditionRequirementsObject.Add(MakeShareable(new FJsonValueString(ConditionRequirement)));
				if(Conditions.Contains(ConditionRequirement))
				{
					WebShowText += Conditions[ConditionRequirement].Description + TEXT(" ");
				}
			}
		}
		FunctionRuleObject->SetArrayField(TEXT("ConditionRequirements"), ConditionRequirementsObject);
		FunctionRuleObject->SetBoolField(TEXT("bAnyRequire"), FunctionRule.bAnyRequire);
		
    	TArray<TSharedPtr<FJsonValue>> ConditionProhibitsObject;
		if(FunctionRule.ConditionProhibits.Num() > 0 || RuleProhibits.Num() > 0)
		{
			WebShowText +=  TEXT("\n排除条件:");

			for(auto& RuleProhibit : RuleProhibits)
			{
				if(Conditions.Contains(RuleProhibit))
				{
					WebShowText += Conditions[RuleProhibit].Description + TEXT(" ");
				}
			}
			
			for(auto& ConditionProhibit : FunctionRule.ConditionProhibits)
			{			
				ConditionProhibitsObject.Add(MakeShareable(new FJsonValueString(ConditionProhibit)));
				if(Conditions.Contains(ConditionProhibit))
				{
					WebShowText += Conditions[ConditionProhibit].Description + TEXT(" ");
				}
			}
		}
        FunctionRuleObject->SetArrayField(TEXT("ConditionProhibits"), ConditionProhibitsObject);
		
		if (FunctionRule.RuleBranch != TEXT(""))
		{
			WebShowText += TEXT("\n作用分支:") + FunctionRule.RuleBranch;
		}
		FunctionRuleObject->SetStringField(TEXT("RuleBranch"), FunctionRule.RuleBranch);

		FunctionRuleObject->SetStringField(TEXT("WebShowText"), WebShowText);
    	FunctionRulesObject->SetObjectField(FunctionRuleKV.Key, FunctionRuleObject);

		UEnum* RepairEnumPtr = StaticEnum<ERMRepairType>();
		FunctionRuleObject->SetStringField(TEXT("RepairType"), RepairEnumPtr->GetNameByValue(FunctionRule.RepairType.GetValue()).ToString());

		FunctionRuleObject->SetStringField(TEXT("RepairFunction"), FunctionRule.RepairRule.FunctionName);
    }
    JsonObject->SetObjectField(TEXT("FunctionRules"), FunctionRulesObject);

	if (RuleRequirements.Num() > 0)
	{
		TArray<TSharedPtr<FJsonValue>> RuleRequirementsObject;
		for(auto& RuleRequirement : RuleRequirements)
		{
			RuleRequirementsObject.Add(MakeShareable(new FJsonValueString(RuleRequirement)));
		}
		JsonObject->SetArrayField(TEXT("RuleRequirements"), RuleRequirementsObject);
	}
	JsonObject->SetBoolField(TEXT("bAnyRequire"), bAnyRequire);

	if (RuleProhibits.Num() > 0)
	{
		TArray<TSharedPtr<FJsonValue>> RuleProhibitsObject;
		for(auto& RuleProhibit : RuleProhibits)
		{
			RuleProhibitsObject.Add(MakeShareable(new FJsonValueString(RuleProhibit)));
		}
		JsonObject->SetArrayField(TEXT("RuleProhibits"), RuleProhibitsObject);
	}

	RuleVersion ++;
	JsonObject->SetNumberField(TEXT("RuleVersion"), RuleVersion);
	
	if (FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer))
	{
		FFileHelper::SaveStringToFile(JsonString, *ExportPath);
	}
}

//==== Base Check Function Start ====
FString URuleBase::GetNameEnding(const FAssetData& AssetData)
{
	FString Path = AssetData.PackageName.ToString();
	int CharIndex = 0;
	if (Path.FindLastChar('_', CharIndex))
	{
		return Path.Mid(CharIndex);
	}
	return "None";
}

FString URuleBase::GetAssetName(const FAssetData& AssetData)
{
	return AssetData.PackageName.ToString();
}

FString URuleBase::GetAssetClassName(const FAssetData& AssetData)
{
	if (UClass* AssetClass = AssetData.GetClass(EResolveClass::Yes))
	{
		return AssetClass->GetName();
	}
	return TEXT("");
}

FString URuleBase::GetAssetShortName(const FAssetData& AssetData)
{
	return AssetData.AssetName.ToString();
}

FString URuleBase::GetTagList(const FAssetData& AssetData)
{
	TArray<FString> Tags;
	FResourceCheckHelper::GetAssetEditorTags(AssetData, Tags);
	FString TagString = FString::Join(Tags, TEXT(","));
	return TagString;
}

FString URuleBase::GetPathName(const FAssetData& AssetData)
{
	return AssetData.PackagePath.ToString();
}

FString URuleBase::IsSourceControlAdd(const FAssetData& AssetData)
{
	FString AbsoluteFilePath = FPackageName::LongPackageNameToFilename(AssetData.PackageName.ToString());
	const FString AssetFullDependPath = FPaths::ConvertRelativePathToFull(AbsoluteFilePath) + FPackageName::GetAssetPackageExtension();
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	FSourceControlStatePtr SourceControlState = SourceControlProvider.GetState(AssetFullDependPath, EStateCacheUsage::ForceUpdate);
	if(SourceControlState.IsValid() && SourceControlState->IsAdded())
	{
		return "1";
	}
	return "0"; 
}

FString URuleBase::IsSourceControlDelete(const FAssetData& AssetData)
{
	FString AbsoluteFilePath = FPackageName::LongPackageNameToFilename(AssetData.PackageName.ToString());
	const FString AssetFullDependPath = FPaths::ConvertRelativePathToFull(AbsoluteFilePath) + FPackageName::GetAssetPackageExtension();
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	FSourceControlStatePtr SourceControlState = SourceControlProvider.GetState(AssetFullDependPath, EStateCacheUsage::ForceUpdate);
	if(SourceControlState.IsValid() && SourceControlState->IsDeleted())
	{
		return "1";
	}
	return "0";
}

bool URuleBase::CheckByLuaChecker(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (UObject* Object = AssetData.GetAsset())
	{
		UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
		TArray<FString> CheckResult = ResourceCheckSubsystem->DataCheck({Object}, OutRepairParams);
		
		for (const FString& ErrorInfo : CheckResult)
		{
			Log.RegistryAndLog(AssetData,GetRuleName(), CheckRuleType, ErrorInfo);
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool URuleBase::RepairByLuaRepairer(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	if (UObject* Object = AssetData.GetAsset())
	{
		UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
		if (ResourceCheckSubsystem->DataRepair(Object, Arguments))
		{
			Object->Modify();
			Object->GetPackage()->MarkPackageDirty();
			return true;
		}
	}
	return false;
}

//==== Base Check Function End ====