// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/RuleFunctions/Avatar/AvatarPresetBaseRule.h"

#include "Asset/AvatarPresetBase.h"
#include "Asset/AvatarProfile.h"
#include "Asset/MakeupInstance.h"
#include "Asset/MakeupProfile.h"
#include "Asset/MakeupProperty.h"
#include "Asset/DressProfile.h"

UClass* UAvatarPresetBaseRule::GetAssetType()
{
	return UAvatarPresetBase::StaticClass();
}

bool UAvatarPresetBaseRule::CheckAvatarReference(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FName AssetPackageName = AssetData.PackageName;

	TArray<FName> ReferenceAssetList;
	if (AssetRegistryModule.Get().GetReferencers(AssetPackageName, ReferenceAssetList))
	{
		if (ReferenceAssetList.Num() == 0)
		{
			Log.RegistryAndLog(AssetData,GetRuleName(), CheckRuleType, TEXT("所有的捏脸资产都不能有引用为空的情况"));
			bSuccess = false;
		}
	}
	return true;
}

bool UAvatarPresetBaseRule::CheckDressInstance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto AvatarPresetBase = Cast<UAvatarPresetBase>(AssetData.GetAsset()))
	{
		if (!AvatarPresetBase->DressInstance)
		{
			Log.RegistryAndLog(AssetData,GetRuleName(), CheckRuleType, TEXT("Dress Instance不能为空"));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UAvatarPresetBaseRule::CheckMakeupInstance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto AvatarPresetBase = Cast<UAvatarPresetBase>(AssetData.GetAsset()))
	{
		if (!AvatarPresetBase->MakeupInstance)
		{
			Log.RegistryAndLog(AssetData,GetRuleName(), CheckRuleType, TEXT("Makeup Instance不能为空"));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UAvatarPresetBaseRule::ChecFaceInstance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto AvatarPresetBase = Cast<UAvatarPresetBase>(AssetData.GetAsset()))
	{
		if (!AvatarPresetBase->FaceInstance)
		{
			Log.RegistryAndLog(AssetData,GetRuleName(), CheckRuleType, TEXT("Face Instance不能为空"));
			bSuccess = false;
		}
	}
	return bSuccess;
}


