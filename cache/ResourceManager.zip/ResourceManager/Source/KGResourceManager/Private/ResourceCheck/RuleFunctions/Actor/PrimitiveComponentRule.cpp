// Fill out your copyright notice in the Description page of Project Settings.

#include "ResourceCheck/RuleFunctions/Actor/PrimitiveComponentRule.h"

#include "Components/RuntimeVirtualTextureComponent.h"
#include "Kismet/GameplayStatics.h"
#include "VT/RuntimeVirtualTextureVolume.h"

bool UPrimitiveComponentRule::PreExecuteAsset(const FAssetData& AssetData)
{
	//需要包含 PrimitiveComponent
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(const auto Comp : Actor->GetComponents())
			{
				if(Cast<UPrimitiveComponent>(Comp))
				{
					return true;
				}
			}
		}
	}
	return false;
}

bool UPrimitiveComponentRule::CheckRVT(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	// refer to UStaticMeshComponentRule::CheckComponentRuntimeVirtualTextureVolume
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if (UWorld* World = Actor->GetWorld())
		{

			TArray<AActor*> FoundActors;
			UGameplayStatics::GetAllActorsOfClass(World->GetWorld(), ARuntimeVirtualTextureVolume::StaticClass(), FoundActors);
			
			TMap<URuntimeVirtualTexture*, ARuntimeVirtualTextureVolume*> RVT2Volume;
			for(auto FoundActor : FoundActors)
			{
				if(auto RVTV = Cast<ARuntimeVirtualTextureVolume>(FoundActor))
				{
					if(auto RVTVC = RVTV->VirtualTextureComponent)
					{
						if (RVTVC->GetVirtualTexture())
						{
							RVT2Volume.Add(RVTVC->GetVirtualTexture(), RVTV);
						}
					}
				}
			}

			for(auto Comp : Actor->GetComponents())
			{
				int32 AcceptChecks = 0;
				if(UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(Comp))
				{
					for(auto RVT : PrimitiveComponent->RuntimeVirtualTextures)
					{
						if(RVT2Volume.Contains(RVT))
						{
							AcceptChecks += 1;

							// Primitive Component 的 Bounds 需要在对应 ARuntimeVirtualTextureVolume 内
							ARuntimeVirtualTextureVolume* Volume = RVT2Volume[RVT];

							// 获取Volume的包围盒
							FBox VolumeBounds = Volume->VirtualTextureComponent->Bounds.GetBox();

							// 获取PrimitiveComponent的包围盒
							FBox ComponentBounds = PrimitiveComponent->Bounds.GetBox();

							// 检查组件的Bounds是否在VolumeBounds内
							if (!VolumeBounds.IsInside(ComponentBounds))
							{
								Log.RegistryAndLog(AssetData, TEXT("PrimitiveComponent"), CheckRuleType,
									TEXT("{} 的 PrimitiveComponent 的 Bounds 需要在对应 RuntimeVirtualTextureVolume {} 的 Bounds 内"),
									PrimitiveComponent->GetName(), Volume->GetActorNameOrLabel());
								bSuccess = false; 
							}
						}
					}
					if(RVT2Volume.Num() == 0 && PrimitiveComponent->RuntimeVirtualTextures.Num() != 0)
					{
						Log.RegistryAndLog(AssetData, TEXT("PrimitiveComponent"), CheckRuleType,
							TEXT("没有RuntimeVirtualTextureVolume的情况下，{}的RuntimeVirtualTextures必须为空"),
							PrimitiveComponent->GetName());
						OutRepairParams.FindOrAdd(PrimitiveComponent->GetName()) =  TEXT("Clear");
						bSuccess = false; 
					}
					if(RVT2Volume.Num() > 0 && PrimitiveComponent->RuntimeVirtualTextures.Num() > 0 && (
						RVT2Volume.Num() != PrimitiveComponent->RuntimeVirtualTextures.Num() ||
						RVT2Volume.Num() != AcceptChecks))
					{
						Log.RegistryAndLog(AssetData, TEXT("PrimitiveComponent"), CheckRuleType,
							TEXT("有RuntimeVirtualTextureVolume的情况下，{}的RuntimeVirtualTextures需要和RuntimeVirtualTextureVolume相同"),
							PrimitiveComponent->GetName());
						OutRepairParams.FindOrAdd( PrimitiveComponent->GetName()) = TEXT("Same");
						bSuccess = false; 
					}
				}
			}
		}
    }
	return bSuccess; 
}

bool UPrimitiveComponentRule::CheckBoundsExtents(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		for (const auto Comp : Actor->GetComponents())
		{
			if (UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(Comp))
			{
				PrimitiveComponent->UpdateBounds();
				const FVector& BoxExtent = PrimitiveComponent->Bounds.BoxExtent;
				if (BoxExtent.X <= 0 && BoxExtent.Y <= 0 && BoxExtent.Z <= 0)
				{
					Log.RegistryAndLog(AssetData, TEXT("PrimitiveComponent"), CheckRuleType,
							TEXT("对象{}的组件{}的Primitive Component Bounds Extents的X Y Z至少要有一个大于0"), Actor->GetActorLabel(), PrimitiveComponent->GetName());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}
