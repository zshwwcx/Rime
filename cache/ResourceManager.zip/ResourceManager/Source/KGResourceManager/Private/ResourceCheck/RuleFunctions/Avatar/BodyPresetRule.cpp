// Fill out your copyright notice in the Description page of Project Settings.

#include "ResourceCheck/RuleFunctions/Avatar/BodyPresetRule.h"
#include "Asset/AvatarPresetBase.h"

UClass* UBodyPresetRule::GetAssetType()
{
	return UBodyPreset::StaticClass();
}