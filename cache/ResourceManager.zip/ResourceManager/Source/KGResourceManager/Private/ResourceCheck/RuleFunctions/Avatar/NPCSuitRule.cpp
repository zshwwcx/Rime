﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/RuleFunctions/Avatar/NPCSuitRule.h"

#include "Asset/AvatarModelAsset.h"

UClass* UNPCSuitRule::GetAssetType()
{
	return UGeneralNPCSuitObj::StaticClass();
}

bool UNPCSuitRule::CheckIncludeBody(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = false;
	
	if (auto NPCSuit = Cast<UGeneralNPCSuitObj>(AssetData.GetAsset()))
	{
		if (NPCSuit->BodyPartList.IsEmpty())
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("NPCSuit资产的BodyPartList不能为空"));
			bSuccess = false;
			return bSuccess;
		}

		for (const FGeneralNPCPartData & PartData : NPCSuit->BodyPartList)
		{
			UNPCMeshPartDefine* MeshPart = PartData.MeshPart.LoadSynchronous();
				
			if (!MeshPart)
				continue;

			if (MeshPart->PartType == ENPCPartType::Body)
			{
				bSuccess = true;
				return bSuccess;
			}
		}
	}

	Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("NPCSuit资产必须包含上半身Body"));
	return bSuccess;
}

bool UNPCSuitRule::CheckBodyType(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	
	if (const auto NPCSuit = Cast<UGeneralNPCSuitObj>(AssetData.GetAsset()))
	{
		const ENPCBodyType SuitBodyType = NPCSuit->BodyType;

		for (const FGeneralNPCPartData & PartData : NPCSuit->BodyPartList)
		{
			const UNPCMeshPartDefine* MeshPart = PartData.MeshPart.LoadSynchronous();

			if (!MeshPart)
				continue;

			if (SuitBodyType != MeshPart->BodyType)
			{
				bSuccess = false;

				Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("NPC部件资产必须和Suit资产体型相同"));
				return bSuccess;
			}
		}
	}
	
	return bSuccess;
}
