#include "ResourceCheck/RuleFunctions/StaticMesh/StaticMeshAssetNaniteRule.h"

#include "NaniteSceneProxy.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"

FString UStaticMeshAssetNaniteRule::NanitePropertyName = "NaniteEnabled";
FString UStaticMeshAssetNaniteRule::TwoSidedDistanceFieldPropertyName = "TwoSidedDistanceFieldEnabled";

bool UStaticMeshAssetNaniteRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	ForceWPOMaterial = Params.GetValueList(TEXT("ForceWPOMaterial"));
	FoliageMaterial = Params.GetValueList(TEXT("FoliageMaterial"));
	SkyMaterial = Params.GetValueList(TEXT("SkyMaterial"));
	TwoSidedDistanceFieldMaterial = Params.GetValueList(TEXT("TwoSidedDistanceFieldMaterial"));
	DisableNantieMaterial = Params.GetValueList(TEXT("DisableNantieMaterial"));
	TArray<FString> DisableNantieBlendModeList = Params.GetValueList(TEXT("DisableNantieBlendMode"));
	for(auto DisableNantieBlendModeParam : DisableNantieBlendModeList)
	{
		DisableNantieBlendMode.Add(static_cast<EBlendMode>(StaticEnum<EBlendMode>()->GetValueByName(FName(DisableNantieBlendModeParam))));
	}
	Super::PreExecuteAllObject(InAssetDataList);
	TArray<FString> TempStandardList = Params.GetValueList(TEXT("MaterialNumStandard"));
	for(auto StandardRawData : TempStandardList)
	{
		FString StandardKey;
		FString StandardValueLow;
		FString StandardValueHigh;
		FString StandardValue;
		StandardRawData.Split("=",&StandardKey,&StandardValue);
		StandardValue.Split(",",&StandardValueLow,&StandardValueHigh);
		MaterialNumStandard[StandardKey] = {FCString::Atof(*StandardValueLow),FCString::Atof(*StandardValueHigh)};
	}
	return true;
}

bool UStaticMeshAssetNaniteRule::PreExecuteAsset(const FAssetData& InAssetData)
{
	FString NaniteEnabled = FResourceCheckHelper::GetPropertyValueByName(InAssetData, "NaniteEnabled", false);
	if (NaniteEnabled.IsEmpty())
	{
		UE_LOG(LogKGResourceManager, Error, TEXT("NaniteEnabled is empty"));
		return false;
	}
	CollectAssetInfo(InAssetData);
	CollectFirstLODInfo(InAssetData);
	return true;
}

bool UStaticMeshAssetNaniteRule::PostExecuteAsset(const FAssetData& AssetData)
{
	CollectedInfo.bHasFoliageMat = false;
	CollectedInfo.bHasTwoSidedDistanceFieldMat = false;
	CollectedInfo.TwoSidedDistanceFieldMatNames.Empty();
	FirstLODInfo.Reset();
	return true;
}

bool UStaticMeshAssetNaniteRule::EnableNantieSupport(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		const TArray<FString> WhiteNaniteMaterialNames = Params.GetValueList(TEXT("WhiteNaniteMaterialNames"));
		const TArray<FStaticMaterial>& StaticMaterials = StaticMesh->GetStaticMaterials();
		bool bOnlyWhiteNaniteMaterials = true;
		for (const FStaticMaterial& StaticMaterial : StaticMaterials)
		{
			if (const UMaterialInterface* MatInterface = StaticMaterial.MaterialInterface)
			{
				if (!WhiteNaniteMaterialNames.Contains(MatInterface->GetPathName()))
				{
					bOnlyWhiteNaniteMaterials = false;
					break;
				}
			}
		}
		if (bOnlyWhiteNaniteMaterials)
		{
			return bSuccess;
		}
		
		bool bNaniteEnabled = StaticMesh->NaniteSettings.bEnabled;
		if (FirstLODInfo.bHasTranslucent && bNaniteEnabled)
		{
			Log.RegistryAndLog(AssetData, TEXT("Nantie"), CheckRuleType, TEXT("拥有半透明材质 {} 的StaticMesh不应该启用Nanite"),
				FString::Join(FirstLODInfo.TranslucentMatNames, TEXT(",")));
			OutRepairParams.Add(NanitePropertyName, "false");
			bSuccess = false;
		}
		if (FirstLODInfo.bHasFoliageMat && bNaniteEnabled)
		{
			Log.RegistryAndLog(AssetData, TEXT("Nantie"), CheckRuleType, TEXT("拥有植被材质 {} 的StaticMesh不应该启用Nanite"),
				FString::Join(FirstLODInfo.FoliageMatNames, TEXT(",")));
			OutRepairParams.Add(NanitePropertyName, "false");
			bSuccess = false;
		}
		if (FirstLODInfo.bHasSkyMat && bNaniteEnabled)
		{
			Log.RegistryAndLog(AssetData, TEXT("Nantie"), CheckRuleType, TEXT("拥有天空球材质 {} 的StaticMesh不应该启用Nanite"),
				FString::Join(FirstLODInfo.SkyMatNames, TEXT(",")));
			OutRepairParams.Add(NanitePropertyName, "false");
			bSuccess = false;
		}
		if ((!FirstLODInfo.bHasFoliageMat && !FirstLODInfo.bHasTranslucent && !FirstLODInfo.bHasSkyMat) && !bNaniteEnabled)
		{
			Log.RegistryAndLog(AssetData, TEXT("Nantie"), CheckRuleType, TEXT("不带半透明、植被、天空盒材质的StaticMesh需要启用Nanite"));
			OutRepairParams.Add(NanitePropertyName, "true");
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetNaniteRule::EnablePreserverArea(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		if(CollectedInfo.bHasFoliageMat && !StaticMesh->NaniteSettings.bPreserveArea)
		{
			Log.RegistryAndLog(AssetData, TEXT("Nantie"), CheckRuleType, TEXT("具有植被材质的StaticMesh没有开启PreserveArea"));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetNaniteRule::EnableTwoSidedDistanceField(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	if (!CollectedInfo.bHasTwoSidedDistanceFieldMat)
	{
		return true;
	}

	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		int32 LODCount = StaticMesh->GetNumLODs();
		for (int32 LODIndex = 0; LODIndex < LODCount; ++LODIndex)
		{
			FStaticMeshSourceModel& SrcModel = StaticMesh->GetSourceModel(LODIndex);
			if(SrcModel.BuildSettings.bGenerateDistanceFieldAsIfTwoSided == false)
			{
				Log.RegistryAndLog(AssetData, TEXT("TwoSidedDistanceField"), CheckRuleType, TEXT("拥有材质 {} 的StaticMesh需要启用双向距离场生成（Two-Sided Distance Field Generation）"),
					FString::Join(CollectedInfo.TwoSidedDistanceFieldMatNames, TEXT(",")));
				OutRepairParams.Add(TwoSidedDistanceFieldPropertyName, "true");
				bSuccess = false;
				break;
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetNaniteRule::RepairStaticMeshNaniteSetting(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	if (Arguments.Contains(NanitePropertyName))
	{
		UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
		StaticMesh->NaniteSettings.bEnabled = Arguments[NanitePropertyName].ToBool();
		StaticMesh->Modify();
		StaticMesh->GetPackage()->MarkPackageDirty();
		return true;
	}
	return false;
}

bool UStaticMeshAssetNaniteRule::RepairTwoSidedDistanceField(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	if (InRepairParams.Contains(TwoSidedDistanceFieldPropertyName))
	{
		if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
		{
			int32 LODCount = StaticMesh->GetNumLODs();
			for (int32 LODIndex = 0; LODIndex < LODCount; ++LODIndex)
			{
				FStaticMeshSourceModel& SrcModel = StaticMesh->GetSourceModel(LODIndex);
				SrcModel.BuildSettings.bGenerateDistanceFieldAsIfTwoSided = InRepairParams[TwoSidedDistanceFieldPropertyName].ToBool();
			}
			StaticMesh->Modify();
			StaticMesh->GetPackage()->MarkPackageDirty();
			return true;
		}
	}
	return false;
}

void UStaticMeshAssetNaniteRule::CollectAssetInfo(const FAssetData& InAssetData)
{
	bool bHasFoliageMat = false;
	bool bHasTwoSidedDistanceFieldMat = false;
	
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FName> AssetDependencies;
	AssetRegistryModule.Get().GetDependencies(InAssetData.PackageName, AssetDependencies, UE::AssetRegistry::EDependencyCategory::All);

	TArray<FAssetData> MaterialDependencies;
	for (int32 i = 0; i < AssetDependencies.Num(); ++i)
	{
		TArray<FAssetData> OutAssetData;
		AssetRegistryModule.Get().GetAssetsByPackageName(AssetDependencies[i], OutAssetData);
		if (!OutAssetData.IsEmpty() && OutAssetData[0].GetClass()->IsChildOf(UMaterialInterface::StaticClass()))
		{
			MaterialDependencies.Add(OutAssetData[0]);
		}
	}

	FString MaterialNum = FResourceCheckHelper::GetPropertyValueByName(InAssetData, "Materials", false);

	TArray<UMaterialInterface*> Materials;

	if (MaterialDependencies.Num() == 0)
	{
		UE_LOG(LogKGResourceManager, Warning, TEXT("Material Dependencies NUM is 0, Static Mesh: %s"), *InAssetData.PackageName.ToString());
		UStaticMesh* StaticMesh = Cast<UStaticMesh>(InAssetData.GetAsset());
		TArray<FStaticMaterial>& StaticMaterials = StaticMesh->GetStaticMaterials();
		for (int32 i = 0; i < StaticMaterials.Num(); ++i)
		{
			if (UMaterialInterface* MI = StaticMaterials[i].MaterialInterface.Get())
			{
				Materials.Add(MI);
			}
			else
			{
				UE_LOG(LogKGResourceManager, Warning, TEXT("Can not get the material of Static Mesh: %s"), *InAssetData.PackageName.ToString());
			}
		}
	}
	else
	{
		for (int32 i = 0; i < MaterialDependencies.Num(); ++i)
		{
			Materials.Add(Cast<UMaterialInterface>(MaterialDependencies[i].GetAsset()));
		}
	}

	for (UMaterialInterface* MatInterface : Materials)
	{
		UMaterialInterface* CurrentMaterial = MatInterface;
		while (CurrentMaterial)
		{
			const FString MatPackageName = CurrentMaterial->GetPackage()->GetFName().ToString();
			if (FoliageMaterial.Contains(MatPackageName))
			{
				bHasFoliageMat = true;
			}
			if (TwoSidedDistanceFieldMaterial.Contains(MatPackageName))
			{
				bHasTwoSidedDistanceFieldMat = true;
				CollectedInfo.TwoSidedDistanceFieldMatNames.AddUnique(MatInterface->GetFName().ToString());
			}

			if (auto MatInstance = Cast<UMaterialInstance>(CurrentMaterial))
			{
				CurrentMaterial = MatInstance->Parent;
			}
			else
			{
				break;
			}
		}
	}

	CollectedInfo.bHasFoliageMat = bHasFoliageMat;
	CollectedInfo.bHasTwoSidedDistanceFieldMat = bHasTwoSidedDistanceFieldMat;
}

void UStaticMeshAssetNaniteRule::CollectFirstLODInfo(const FAssetData& InAssetData)
{
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(InAssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		return;
	}
	FStaticMeshRenderData* RenderData = StaticMesh->GetRenderData();
	if (RenderData == nullptr)
	{
		return;
	}
	if (RenderData->LODResources.IsEmpty())
	{
		return;
	}
	int32 SectionNum = RenderData->LODResources[0].Sections.Num();
	const FMeshSectionInfoMap& SectionInfoMap = StaticMesh->GetSectionInfoMap();
	const TArray<FStaticMaterial>& StaticMaterials = StaticMesh->GetStaticMaterials();
	for (int32 i = 0; i < SectionNum; ++i)
	{
		const FMeshSectionInfo& SectionInfo = SectionInfoMap.Get(0, i);
		const int32 MaterialIndex = SectionInfo.MaterialIndex;
		if (StaticMaterials.IsValidIndex(MaterialIndex))
		{
			UMaterialInterface* MaterialInterface = StaticMaterials[MaterialIndex].MaterialInterface;
			if (MaterialInterface == nullptr)
			{
				continue;
			}
			FString MaterialName = MaterialInterface->GetFName().ToString();
			if (MaterialInterface->GetBlendMode() != EBlendMode::BLEND_Opaque)
			{
				FirstLODInfo.bHasTranslucent = true;
				FirstLODInfo.TranslucentMatNames.AddUnique(MaterialName);
			}
			UMaterialInterface* CurrentMaterial = MaterialInterface;
			while (CurrentMaterial)
			{
				if (CurrentMaterial->GetPackage() == nullptr)
				{
					break;
				}
				const FString MatPackageName = CurrentMaterial->GetPackage()->GetName();
				if (FoliageMaterial.Contains(MatPackageName))
				{
					FirstLODInfo.bHasFoliageMat = true;
					FirstLODInfo.FoliageMatNames.AddUnique(MaterialName);
				}
				if (SkyMaterial.Contains(MatPackageName))
				{
					FirstLODInfo.bHasSkyMat = true;
					FirstLODInfo.SkyMatNames.AddUnique(MaterialName);
				}
				if (const UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>(CurrentMaterial))
				{
					CurrentMaterial = MaterialInstance->Parent;
				}
				else
				{
					break;
				}
			}
		}
	}
}
