#include "ResourceCheck/RuleFunctions/Avatar/NpcMeshPartDefineRule.h"

#include "Asset/AvatarModelAsset.h"
#include "Asset/MeshPartCollection.h"

UClass* UNpcMeshPartDefineRule::GetAssetType()
{
	return UNPCMeshPartDefine::StaticClass();
}

bool UNpcMeshPartDefineRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	Params.GetValue("MaterialSlotClothTypeName").ParseIntoArray(MaterialSlotClothTypeName, TEXT(","));
	return true;
}

bool UNpcMeshPartDefineRule::CheckSkeletalMeshMaterialSlot(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto NPCMeshPartDefine = Cast<UNPCMeshPartDefine>(AssetData.GetAsset()))
	{
		USkeletalMesh* SkeletalMesh = NPCMeshPartDefine->GetSkeletalMesh();
		if (!SkeletalMesh)
		{
			if (NPCMeshPartDefine->FacePreset.IsNull())
			{
				Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("NPCMeshPartDefine资产引用的Skeletal Mesh和FacePreset不能同时为空"));
				bSuccess = false;
				return bSuccess;
			}
		}
		else
		{
			// 提取资产包路径
			FString PackagePath = AssetData.PackagePath.ToString();
			
			// 从资产包路径中提取文件夹名称
			int32 LastSlashIndex;
			if (PackagePath.FindLastChar('/', LastSlashIndex))
			{
				const FString FolderName = PackagePath.Mid(LastSlashIndex + 1);
				if (MaterialSlotClothTypeName.Contains(FolderName))
				{
					const TArray<FSkeletalMaterial>& Materials = SkeletalMesh->GetMaterials();
					bool bFindClothSlot = false;
					for (const FSkeletalMaterial& Material : Materials)
					{
						if (Material.MaterialSlotName == "Cloth")
						{
							bFindClothSlot = true;
							break;
						}
					}
					if (!bFindClothSlot)
					{
						Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("{} 下的 MeshPartDefine 资产引用的Skeletal Mesh的材质插槽名需要有 Cloth"), FolderName);
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}
