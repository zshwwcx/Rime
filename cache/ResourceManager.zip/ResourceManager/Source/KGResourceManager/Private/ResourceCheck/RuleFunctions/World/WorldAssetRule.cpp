#include "ResourceCheck/RuleFunctions/World/WorldAssetRule.h"

#include "Kismet/GameplayStatics.h"
#include "VT/RuntimeVirtualTextureVolume.h"
#include "Components/RuntimeVirtualTextureComponent.h"
#include "GameplayDebuggerPlayerManager.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"
#include "WorldPartition/ActorDescContainerCollection.h"
#include "WorldPartition/WorldPartition.h"
#include "WorldPartition/HLOD/HLODActor.h"
#include "ActorEditorUtils.h"
#include "LevelUtils.h"
#include "Engine/StaticMeshActor.h"
#include "FileHelpers.h"
#include "InstancedFoliageActor.h"
#include "Landscape.h"
#include "Components/SkyAtmosphereComponent.h"
#include "NavMesh/NavMeshBoundsVolume.h"
#include "WorldPartition/WorldPartitionRuntimeSpatialHash.h"

UClass* UWorldAssetRule::GetAssetType()
{
	return UWorld::StaticClass();
}

bool UWorldAssetRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	NewPrecomputeVisibility = FCString::Atoi(*Params.GetValue(TEXT("PrecomputeVisibility")));
	NewVisibilityCellSize = FCString::Atoi(*Params.GetValue(TEXT("VisibilityCellSize")));
	NewVisibilityAggressiveness = static_cast<EVisibilityAggressiveness>(StaticEnum<EVisibilityAggressiveness>()->GetValueByName(FName(Params.GetValue(TEXT("VisibilityAggressiveness")))));
	NumRuntimeVirtualTextureVolume = FCString::Atoi(*Params.GetValue(TEXT("NumRuntimeVirtualTextureVolume")));

	WCActors = Params.GetValueList(TEXT("WCActors"));
	return true;
}

bool UWorldAssetRule::PreExecuteAsset(const FAssetData& AssetData)
{
	if (UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		if (World->IsPartitionedWorld())
		{
			UWorldPartition* WorldPartition = World->GetWorldPartition();
			if (!WorldPartition->IsInitialized())
			{
				WorldPartition->Initialize(World, FTransform::Identity);
			}
		}
	}
	return true;
}

bool UWorldAssetRule::PostExecuteAsset(const FAssetData& AssetData)
{
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		//World->DestroyWorld(false);
	}
	return true;
}

FString UWorldAssetRule::IsPartitionedWorld(const FAssetData& AssetData)
{
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		return FString::FromInt(World->IsPartitionedWorld());
	}
	return FString::FromInt(0);
}

bool UWorldAssetRule::CompileRuntimeVirtualTexture(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		TArray<AActor*> FoundActors;
		UGameplayStatics::GetAllActorsOfClass(World->GetWorld(), ARuntimeVirtualTextureVolume::StaticClass(), FoundActors);
		if (FoundActors.Num() > 1)
		{
			Log.RegistryAndLog(AssetData, TEXT("RuntimeVirtualTextureVolume"), CheckRuleType, TEXT("RuntimeVirtualTextureVolume数量大于{}"), NumRuntimeVirtualTextureVolume);
			return false;
		}
		else if (FoundActors.Num() == 1)
		{
			ARuntimeVirtualTextureVolume* RuntimeVirtualTextureVolume = Cast<ARuntimeVirtualTextureVolume>(FoundActors[0]);
			if (RuntimeVirtualTextureVolume)
			{
				if (RuntimeVirtualTextureVolume->VirtualTextureComponent->GetVirtualTexture() == nullptr)
				{
					Log.RegistryAndLog(AssetData,TEXT("RuntimeVirtualTextureVolume"), CheckRuleType, TEXT("RuntimeVirtualTextureVolume中VirtualTexture为空"));
					return false;
				}
			}
		}
	}
	return true;
}

bool UWorldAssetRule::WorldNavMeshCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		bool bFindNavMeshLevel = false;
		auto StreamingLevels = World->GetStreamingLevels();
		for (const auto& StreamingLevel : StreamingLevels)
		{
			FString LevelPackageName = StreamingLevel->GetWorldAssetPackageName();
			if (LevelPackageName.EndsWith("_NavMesh"))
			{
				bFindNavMeshLevel = true;
				break;
			}
		}
		if (!bFindNavMeshLevel)
		{
			Log.RegistryAndLog(AssetData,TEXT("NavMesh"), CheckRuleType, TEXT("没有找到NavMeshLevel"));
			bSuccess = false;				
		}
	}
	return bSuccess;
}

FString UWorldAssetRule::GetNavMeshBoundsVolumeNum(const FAssetData& AssetData)
{
	int32 NavMeshVolumeCount = 0;
	if (const UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		for (AActor* Actor : World->PersistentLevel->Actors)
		{
			if (Cast<ANavMeshBoundsVolume>(Actor))
			{
				NavMeshVolumeCount++;
			}
		}
	}
	return FString::FromInt(NavMeshVolumeCount);
}

bool UWorldAssetRule::WorldPartitionCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		if(UWorldPartition* WorldPartition = World->GetWorldPartition())
		{			
			for(FActorDescContainerInstanceCollection::TIterator<AWorldPartitionHLOD> ActorDescIterator(WorldPartition); ActorDescIterator; ++ActorDescIterator)
			{
				TArray<TPair<FGuid, TArray<FGuid>>> ActorsWithRefs;
				ActorsWithRefs.Emplace(ActorDescIterator->GetGuid(), ActorDescIterator->GetReferences());
				for(auto ActorWithRefs : ActorsWithRefs)
				{
					if (UActorDescContainerInstance* ActorDescContainerInstance = WorldPartition->GetActorDescContainerInstance())
					{
						FWorldPartitionActorDescInstance* ActorDescInstance = ActorDescContainerInstance->GetActorDescInstance(ActorWithRefs.Key);
						if (!ActorDescInstance)
						{
							Log.RegistryAndLog(AssetData, TEXT("WorldPartition"), CheckRuleType,
								TEXT("WorldPartition引用的Guid={}资源缺失"), ActorWithRefs.Key.ToString());
							bSuccess = false;
							continue;
						}
						TSet<FGuid> RefGuidSet;
						for(auto RefActor : ActorWithRefs.Value)
						{
							FWorldPartitionActorDescInstance* RefActorDesc = ActorDescContainerInstance->GetActorDescInstance(RefActor);
							if(!RefActorDesc && !RefGuidSet.Contains(RefActor))
							{
								RefGuidSet.Add(RefActor); 
								Log.RegistryAndLog(AssetData, TEXT("WorldPartition"), CheckRuleType,
								TEXT("World:{}中的Actor{}依赖的Guid{}缺失"), World->GetName(), ActorDescInstance->GetActorName(), RefActor.ToString());bSuccess = false; 
							}
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UWorldAssetRule::WorldCompositionActorCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		for(auto Actor:World->PersistentLevel->Actors)
		{
			if(Actor)
			{

				bool bIsActorDisplayable =	Actor &&
								Actor->IsEditable() &&				
								Actor->IsListedInSceneOutliner();
	
				if(bIsActorDisplayable)
				{
					if (Actor->HasAnyFlags(RF_Transient))
					{
						bIsActorDisplayable = (Actor->GetWorld() && Actor->GetWorld()->IsPlayInEditor());
					}
				}
				
				bool EnableActor = bIsActorDisplayable &&
					!Actor->IsTemplate() &&																	// Should never happen, but we never want CDOs displayed
					!FActorEditorUtils::IsABuilderBrush(Actor) &&											// Don't show the builder brush
					!Actor->IsA(AWorldSettings::StaticClass()) &&											// Don't show the WorldSettings actor, even though it is technically editable
					IsValidChecked(Actor) &&																// We don't want to show actors that are about to go away
					FLevelUtils::IsLevelVisible(Actor->GetLevel());
				if(EnableActor)
				{
					FString ActorClassName = Actor->GetClass()->GetName();
					if(!WCActors.Contains(ActorClassName))
					{
						Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
							TEXT("不允许放置除WCActors以外的Actor:{}"), ActorClassName);
						bSuccess = false; 
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UWorldAssetRule::CheckNumRuntimeVirtualTextureVolume(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		TArray<FString> FoundActors;
		for (AActor* Actor : World->PersistentLevel->Actors)
		{
			if (Cast<ARuntimeVirtualTextureVolume>(Actor))
			{
				FoundActors.Add(Actor->GetActorLabel());
			}
		}

		if (FoundActors.Num() > 2)
		{
			Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
						TEXT("关卡中最多只允许放置俩个RuntimeVirtualTextureVolume，现在有{}个"), FoundActors.Num());
			bSuccess = false; 
		}
		else if (FoundActors.Num() == 2)
		{
			if (!FoundActors.Contains("LandscapeVTVolume_PC") || !FoundActors.Contains("LandscapeVTVolume_Mobile"))
			{
				Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
				TEXT("关卡中只有俩个RuntimeVirtualTextureVolume，其命名必须为LandscapeVTVolume_PC和LandscapeVTVolume_Mobile"));
				bSuccess = false; 
			}
		}
		else if (FoundActors.Num() == 1)
		{
			if (!FoundActors.Contains("LandscapeVTVolume_PC"))
			{
				Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
				TEXT("关卡中只有一个RuntimeVirtualTextureVolume，其命名必须为LandscapeVTVolume_PC"));
				bSuccess = false; 
			}
		}
	}
	return bSuccess;
}

bool UWorldAssetRule::CheckActorPrimitiveComponentRVT(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	// refer to UPrimitiveComponentRule::CheckRVT
	bool bSuccess = true;

	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		// 遍历所有 Actor，找到所有 ARuntimeVirtualTextureVolume
		TMap<URuntimeVirtualTexture*, ARuntimeVirtualTextureVolume*> RVT2Volume;
		for (AActor* Actor : World->PersistentLevel->Actors)
		{
			if(auto RVTV = Cast<ARuntimeVirtualTextureVolume>(Actor))
			{
				if(auto RVTVC = RVTV->VirtualTextureComponent)
				{
					if (RVTVC->GetVirtualTexture())
					{
						RVT2Volume.Add(RVTVC->GetVirtualTexture(), RVTV);
					}
				}
			}
		}
		// 遍历所有 UPrimitiveComponent
		for (AActor* Actor : World->PersistentLevel->Actors)
		{
			if (!Actor)
			{
				continue;
			}
		
			// 获取Actor的所有组件
			TSet<UActorComponent*> Components = Actor->GetComponents();
			for (UActorComponent* Component : Components)
			{
				UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(Component);
				if (!PrimitiveComponent)
				{
					continue;
				}

				int32 AcceptChecks = 0;
				for(auto RVT : PrimitiveComponent->RuntimeVirtualTextures)
				{
					if(RVT2Volume.Contains(RVT))
					{
						AcceptChecks += 1;

						// Primitive Component 的 Bounds 需要在对应 ARuntimeVirtualTextureVolume 内
						ARuntimeVirtualTextureVolume* Volume = RVT2Volume[RVT];

						// 获取Volume的包围盒
						FBox VolumeBounds = Volume->VirtualTextureComponent->Bounds.GetBox();

						// 获取PrimitiveComponent的包围盒
						FBox ComponentBounds = PrimitiveComponent->Bounds.GetBox();

						// 检查组件的Bounds是否在VolumeBounds内
						if (!VolumeBounds.IsInside(ComponentBounds))
						{
							Log.RegistryAndLog(AssetData, TEXT("PrimitiveComponent"), CheckRuleType,
								TEXT("{} 的 PrimitiveComponent 的 Bounds 需要在对应 RuntimeVirtualTextureVolume {} 的 Bounds 内"),
								Actor->GetActorNameOrLabel(), Volume->GetActorNameOrLabel());
							bSuccess = false; 
						}
					}
				}
				if(RVT2Volume.Num() == 0 && PrimitiveComponent->RuntimeVirtualTextures.Num() != 0)
				{
					Log.RegistryAndLog(AssetData, TEXT("PrimitiveComponent"), CheckRuleType,
						TEXT("没有RuntimeVirtualTextureVolume的情况下，{}的RuntimeVirtualTextures必须为空"),
						Actor->GetActorNameOrLabel());
					OutRepairParams.FindOrAdd(PrimitiveComponent->GetName()) =  TEXT("Clear");
					bSuccess = false; 
				}
				if(RVT2Volume.Num() > 0 && PrimitiveComponent->RuntimeVirtualTextures.Num() > 0 && (
					RVT2Volume.Num() != PrimitiveComponent->RuntimeVirtualTextures.Num() ||
					RVT2Volume.Num() != AcceptChecks))
				{
					Log.RegistryAndLog(AssetData, TEXT("PrimitiveComponent"), CheckRuleType,
						TEXT("有RuntimeVirtualTextureVolume的情况下，{}的RuntimeVirtualTextures需要和RuntimeVirtualTextureVolume相同"),
						Actor->GetActorNameOrLabel());
					OutRepairParams.FindOrAdd( PrimitiveComponent->GetName()) = TEXT("Same");
					bSuccess = false; 
				}
			}
		}
	}

	return bSuccess;
}

bool UWorldAssetRule::CheckSkyAtmosphereWorldSkyMaterial(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		bool HasSkyAtmosphere = false;

		for (AActor* Actor : World->PersistentLevel->Actors)
		{
			if (Actor == nullptr)
			{
				continue;
			}
			if (Actor->IsA(ASkyAtmosphere::StaticClass()))
			{
				continue;
			}
			if (Actor->FindComponentByClass<USkyAtmosphereComponent>())
			{
				HasSkyAtmosphere = true;
				break;
			}
		}
		if (HasSkyAtmosphere)
		{
			TArray<UStaticMeshComponent*> StaticMeshComponents;
			for (const AActor* Actor : World->PersistentLevel->Actors)
			{
				if (Actor == nullptr)
				{
					continue;
				}
				TArray<UStaticMeshComponent*> Components;
				Actor->GetComponents<UStaticMeshComponent>(Components); // 获取 Actor 下的所有 StaticMeshComponent
				for (const UStaticMeshComponent* Component : Components)
				{
					if (UStaticMesh* StaticMesh = Component->GetStaticMesh())
					{
						TArray<FStaticMaterial>& StaticMaterials = StaticMesh->GetStaticMaterials();
						for (int32 i = 0; i < StaticMaterials.Num(); ++i)
						{
							if (UMaterialInterface* MatInterface = StaticMaterials[i].MaterialInterface.Get())
							{
								if (const UMaterial* Material = MatInterface->GetMaterial())
								{
									if (Material->bIsSky)
									{
										return true;
									}
								}
							}
						}
					}
				}
			}
			Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
			TEXT("有SkyAtmosphere组件的world，至少得有一个StaticMesh其Material带IsSky标记。"));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UWorldAssetRule::CheckLandScape(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		if (World->IsPartitionedWorld())
		{
			return bSuccess;
		}
		int32 LandscapeNum = 0;
		for (AActor* Actor : World->PersistentLevel->Actors)
		{
			if (Actor == nullptr)
			{
				continue;
			}
			if (Actor->IsA(ALandscape::StaticClass()))
			{
				LandscapeNum++;
			}
			if (LandscapeNum == 2)
			{
				Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
			TEXT("一个场景中最多只能存在一个Landscape实例"));
				return false;
			}
		}
	}
	return bSuccess;
}

bool UWorldAssetRule::CheckFoliageActor(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		if (World->IsPartitionedWorld())
		{
			return bSuccess;
		}
		int32 InstancedFoliageActorNum = 0;
		for (AActor* Actor : World->PersistentLevel->Actors)
		{
			if (Actor == nullptr)
			{
				continue;
			}
			if (Actor->IsA(AInstancedFoliageActor::StaticClass()))
			{
				InstancedFoliageActorNum++;
			}
			if (InstancedFoliageActorNum == 2)
			{
				Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
			TEXT("一个场景中最多只能有一个FoliageActor"));
				return false;
			}
		}
	}
	return bSuccess;
}

FString UWorldAssetRule::GetRuntimeHasClass(const FAssetData& AssetData)
{
	if (const UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		if (const UWorldPartition* WorldPartition = World->GetWorldPartition())
		{
			if (WorldPartition->RuntimeHash)
			{
				if (UClass* RuntimeHashClass = WorldPartition->RuntimeHash.GetClass())
				{
					return RuntimeHashClass->GetName();
				}
			}
		}
	}
	return TEXT("");
}

bool UWorldAssetRule::RepairRuntimeHasClass(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	bool bSuccess = false;
	if (UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		if (UWorldPartition* WorldPartition = World->GetWorldPartition())
		{
			WorldPartition->RuntimeHash = UWorldPartitionRuntimeHash::ConvertWorldPartitionHash(WorldPartition->RuntimeHash, UWorldPartitionRuntimeSpatialHash::StaticClass());
			bSuccess = true;
		}
	}	
	return bSuccess;
}

FString UWorldAssetRule::GetEnableRayTracing(const FAssetData& AssetData)
{
	bool bSuccess = true;
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		if (AWorldSettings* WorldSettings = World->GetWorldSettings())
		{
			return WorldSettings->RayTracingSettings.bEnableRayTracing ? TEXT("True") : TEXT("False");
		}
	}
	return TEXT("None");
}

bool UWorldAssetRule::RepairEnableRayTracing(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	bool bDirty = false;
	if(UWorld* World = Cast<UWorld>(AssetData.GetAsset()))
	{
		if (AWorldSettings* WorldSettings = World->GetWorldSettings())
		{		
			if (Arguments.Num() > 0)
			{
				for (auto RepairParam : Arguments)
				{
					WorldSettings->RayTracingSettings.bEnableRayTracing = RepairParam.Value == TEXT("True") ? true : false;
					bDirty = true;
				}
			}
		}		
		if (bDirty)
        {
        	World->Modify();
        	if (World->GetPackage()->MarkPackageDirty())
        	{
        		return true;
        	}
        }
	}	
	return false;
}
