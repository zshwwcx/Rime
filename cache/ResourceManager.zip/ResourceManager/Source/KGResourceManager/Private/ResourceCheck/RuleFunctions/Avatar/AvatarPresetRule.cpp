// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/RuleFunctions/Avatar/AvatarPresetRule.h"

#include "Asset/AvatarPresetBase.h"
#include "Utils/AvatarCreatorProfileUtils.h"
#include "Utils/AvatarCreatorEditorConfig.h"

UClass* UAvatarPresetRule::GetAssetType()
{
	return UAvatarPreset::StaticClass();
}
bool UAvatarPresetRule::CheckHeadPreset(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;

	if (auto AvatarPreset = Cast<UAvatarPreset>(AssetData.GetAsset()))
	{
		if (!AvatarPreset->HeadPreset)
		{
			Log.RegistryAndLog(AssetData,GetRuleName(), CheckRuleType, TEXT("捏脸资产HeadPreset不能为空"));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UAvatarPresetRule::CheckBodyPreset(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;

	if (auto AvatarPreset = Cast<UAvatarPreset>(AssetData.GetAsset()))
	{
		if (!AvatarPreset->BodyPreset)
		{
			Log.RegistryAndLog(AssetData,GetRuleName(), CheckRuleType, TEXT("捏脸资产BodyPreset不能为空"));
			bSuccess = false;
		}
	}
	
	return bSuccess;
}

bool UAvatarPresetRule::CheckPresetPrimitiveStats(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;

	if (auto AvatarPreset = Cast<UAvatarPreset>(AssetData.GetAsset()))
	{
		UAvatarCreatorEditorConfig::Initialize();
		FAvatarMeshStatsCache Stats = FAvatarCreatorProfileUtils::GetAssetPathStats(AvatarPreset->GetPathName());
		if (Stats.IsValid() && Stats.StatsLevel == EAvatarCreatorStatsLevel::Error)
		{
			Log.RegistryAndLog(AssetData,GetRuleName(), CheckRuleType, TEXT("角色资产预算不达标，可能是面数超标，具体可进角色编辑器查看统计项."));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UAvatarPresetRule::CheckTextureGroup(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	if (UAvatarPresetBase* AvatarPresetBase = Cast<UAvatarPresetBase>(AssetData.GetAsset()))
	{
		UAvatarCreatorEditorConfig::Initialize();
		TArray<FString> OutErrors;
		const bool bPassed = FAvatarCreatorProfileUtils::CheckAvatarTextureGroups(AvatarPresetBase, OutErrors);
		if (!bPassed)
		{
			for (const FString& OutError : OutErrors)
			{
				Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, *OutError);
			}
			return false;
		}
	}

	return true;
}
