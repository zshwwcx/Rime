#include "ResourceCheck/RuleFunctions/Niagara/NiagaraMaterialFlagRule.h"

#include "NiagaraEmitter.h"
#include "NiagaraMeshRendererProperties.h"
#include "NiagaraRibbonRendererProperties.h"
#include "NiagaraSystem.h"
#include "NiagaraSpriteRendererProperties.h"
#include "ViewModels/Stack/NiagaraStackFunctionInput.h"

UClass* UNiagaraMaterialFlagRule::GetAssetType()
{
	return UNiagaraSystem::StaticClass();
}

bool UNiagaraMaterialFlagRule::CheckMaterialFlag(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TSet<UMaterial*> SpritesMaterials;
	TSet<UMaterial*> RibbonMaterials;
	TSet<UMaterial*> MeshMaterials;
	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
	for (const FNiagaraEmitterHandle& EmitterHandle : NiagaraSystem->GetEmitterHandles())
	{
		if (UNiagaraEmitter* Emitter = EmitterHandle.GetInstance().Emitter)
		{
			if (const FVersionedNiagaraEmitterData* EmitterData = Emitter->GetLatestEmitterData())
			{
				for (UNiagaraRendererProperties* Renderer : EmitterData->GetRenderers())
				{
					if (const UNiagaraSpriteRendererProperties* SpriteRenderer = Cast<UNiagaraSpriteRendererProperties>(Renderer))
					{
						if (SpriteRenderer->Material && SpriteRenderer->Material->GetMaterial())
						{
							SpritesMaterials.Add(SpriteRenderer->Material->GetMaterial());
						}
						continue;
					}
					if (const UNiagaraRibbonRendererProperties* RibbonRenderer = Cast<UNiagaraRibbonRendererProperties>(Renderer))
					{
						if (RibbonRenderer->Material && RibbonRenderer->Material->GetMaterial())
						{
							RibbonMaterials.Add(RibbonRenderer->Material->GetMaterial());
						}
						continue;
					}
					if (const UNiagaraMeshRendererProperties* MeshRenderer = Cast<UNiagaraMeshRendererProperties>(Renderer))
					{
						if (MeshRenderer->OverrideMaterials.IsEmpty())
						{
							for (const auto& MeshProperties : MeshRenderer->Meshes)
							{
								if (MeshProperties.Mesh && MeshProperties.Mesh->GetRenderData())
								{
									const FStaticMeshLODResources& LODModel = MeshProperties.Mesh->GetRenderData()->LODResources[0];
									for (int32 SectionIndex = 0; SectionIndex < LODModel.Sections.Num(); SectionIndex++)
									{
										const FStaticMeshSection& Section = LODModel.Sections[SectionIndex];
										if (UMaterialInterface *MaterialInterface = MeshProperties.Mesh->GetMaterial(Section.MaterialIndex))
										{
											UMaterial* Material = MaterialInterface->GetMaterial();
											MeshMaterials.Add(Material);
										}
									}
								}
							}
						}
						else
						{
							for (const auto& OverrideMaterial : MeshRenderer->OverrideMaterials)
							{
								if (UMaterialInterface* MaterialInterface = OverrideMaterial.ExplicitMat)
								{
									UMaterial* Material = MaterialInterface->GetMaterial();
									MeshMaterials.Add(Material);
								}
							}
						}
					}
				}
			}
		}
	}

	for (const UMaterial* Material : SpritesMaterials)
	{
		if (!Material->GetUsageByFlag(EMaterialUsage::MATUSAGE_NiagaraSprites))
		{
			Log.RegistryAndLog(AssetData, TEXT("NiagaraMaterial"), CheckRuleType, TEXT("Niagara Sprite渲染器使用了未勾选Niagara Sprites的材质：{}"),
				Material->GetFName().ToString());
			bSuccess = false;
		}
		else if (Material->GetPackage()->IsDirty())
		{
			Log.RegistryAndLog(AssetData, TEXT("NiagaraMaterial"), CheckRuleType, TEXT("Niagara Sprite渲染器使用的材质：{} 已自动勾选上NiagaraSprites，但没有保存，请查看未保存列表保存后一并提交"),
				Material->GetFName().ToString());
			bSuccess = false;
		}
	}

	for (const UMaterial* Material : RibbonMaterials)
	{
		if (!Material->GetUsageByFlag(EMaterialUsage::MATUSAGE_NiagaraRibbons))
		{
			Log.RegistryAndLog(AssetData, TEXT("NiagaraMaterial"), CheckRuleType, TEXT("Niagara Ribbon渲染器使用了未勾选Niagara Ribbons的材质：{}"),
				Material->GetFName().ToString());
			bSuccess = false;
		}
		else if (Material->GetPackage()->IsDirty())
		{
			Log.RegistryAndLog(AssetData, TEXT("NiagaraMaterial"), CheckRuleType, TEXT("Niagara Ribbon渲染器使用的材质：{} 已自动勾选上NiagaraRibbons，但没有保存，请查看未保存列表保存后一并提交"),
				Material->GetFName().ToString());
			bSuccess = false;
		}
	}

	for (const UMaterial* Material : MeshMaterials)
	{
		if (!Material->GetUsageByFlag(EMaterialUsage::MATUSAGE_NiagaraMeshParticles))
		{
			Log.RegistryAndLog(AssetData, TEXT("NiagaraMaterial"), CheckRuleType, TEXT("Niagara Mesh渲染器使用了未勾选Niagara Mesh Particles的材质：{}"),
				Material->GetFName().ToString());
			bSuccess = false;
		}
		else if (Material->GetPackage()->IsDirty())
		{
			Log.RegistryAndLog(AssetData, TEXT("NiagaraMaterial"), CheckRuleType, TEXT("Niagara Mesh渲染器使用的材质：{} 已自动勾选上NiagaraMeshParticles，但没有保存，请查看未保存列表保存后一并提交"),
				Material->GetFName().ToString());
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UNiagaraMaterialFlagRule::CheckMeshRendererOverrideMaterial(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TSet<UMaterial*> MeshMaterials;
	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
	for (const FNiagaraEmitterHandle& EmitterHandle : NiagaraSystem->GetEmitterHandles())
	{
		if (!EmitterHandle.GetIsEnabled())
		{
			continue;
		}
		if (UNiagaraEmitter* Emitter = EmitterHandle.GetInstance().Emitter)
		{
			if (const FVersionedNiagaraEmitterData* EmitterData = Emitter->GetLatestEmitterData())
			{
				for (UNiagaraRendererProperties* Renderer : EmitterData->GetRenderers())
				{
					if (const UNiagaraMeshRendererProperties* MeshRenderer = Cast<UNiagaraMeshRendererProperties>(Renderer))
					{
						if (!MeshRenderer->OverrideMaterials.IsEmpty())
						{
							if (MeshRenderer->Meshes.Num() != MeshRenderer->OverrideMaterials.Num())
							{
								Log.RegistryAndLog(AssetData, TEXT("NiagaraMaterial"), CheckRuleType, TEXT("Niagara Mesh渲染器使用了重载材质，但数量和Mesh数量不一致!"));
								bSuccess = false;
							}
							for (auto Materials : MeshRenderer->OverrideMaterials)
							{
								if (Materials.ExplicitMat == nullptr)
								{
									Log.RegistryAndLog(AssetData, TEXT("NiagaraMaterial"), CheckRuleType, TEXT("Niagara Mesh渲染器添加了空的重载材质"));
									bSuccess = false;
								}
							}
						}
					}
				}
			}
		}
	}
	return bSuccess;
}
