#include "ResourceCheck/RuleFunctions/Actor/RuntimeVirtualTextureVolumeRule.h"

#include "Components/RuntimeVirtualTextureComponent.h"
#include "VT/RuntimeVirtualTexture.h"
#include "VT/RuntimeVirtualTextureVolume.h"

UClass* URuntimeVirtualTextureVolumeRule::GetAssetType()
{
	return ARuntimeVirtualTextureVolume::StaticClass();
}

FString URuntimeVirtualTextureVolumeRule::IsMobileRVT(const FAssetData& AssetData)
{
	ARuntimeVirtualTextureVolume* RuntimeVirtualTextureVolume = Cast<ARuntimeVirtualTextureVolume>(AssetData.GetAsset());
	if (!RuntimeVirtualTextureVolume)
	{
		return TEXT("0");
	}
	const URuntimeVirtualTextureComponent* VirtualTextureComponent = RuntimeVirtualTextureVolume->VirtualTextureComponent;
	if (!VirtualTextureComponent)
	{
		return TEXT("0");
	}
	if (const URuntimeVirtualTexture* RuntimeVirtualTexture = VirtualTextureComponent->GetVirtualTexture())
	{
		if (RuntimeVirtualTexture->GetName().EndsWith(TEXT("_Mobile")))
		{
			return TEXT("1");
		}
	}
	return TEXT("0");
}

FString URuntimeVirtualTextureVolumeRule::GetMaxAxisScale(const FAssetData& AssetData)
{
	ARuntimeVirtualTextureVolume* RuntimeVirtualTextureVolume = Cast<ARuntimeVirtualTextureVolume>(AssetData.GetAsset());
	if (!RuntimeVirtualTextureVolume)
	{
		return TEXT("0");
	}
	const FVector& Scale = RuntimeVirtualTextureVolume->GetActorScale();
	return FString::Printf(TEXT("%f"), FMath::Max(Scale.X, Scale.Y));
}

FString URuntimeVirtualTextureVolumeRule::GetVirtualTextureSize(const FAssetData& AssetData)
{
	ARuntimeVirtualTextureVolume* RuntimeVirtualTextureVolume = Cast<ARuntimeVirtualTextureVolume>(AssetData.GetAsset());
	if (!RuntimeVirtualTextureVolume)
	{
		return TEXT("0");
	}
	const URuntimeVirtualTextureComponent* VirtualTextureComponent = RuntimeVirtualTextureVolume->VirtualTextureComponent;
	if (!VirtualTextureComponent)
	{
		return TEXT("0");
	}
	if (const URuntimeVirtualTexture* RuntimeVirtualTexture = VirtualTextureComponent->GetVirtualTexture())
	{
		FString SizeUnits = TEXT("Texels");
		int32 Size = RuntimeVirtualTexture->GetSize();
		int32 SizeLog2 = FMath::CeilLogTwo(Size);
		if (SizeLog2 >= 10)
		{
			Size = Size >> 10;
			SizeUnits = TEXT("KiTexels");
		}
		FNumberFormattingOptions SizeOptions;
		SizeOptions.UseGrouping = false;
		SizeOptions.MaximumFractionalDigits = 0;
		return FString::Printf(TEXT("%s%s"), *FText::AsNumber(Size, &SizeOptions).ToString(), *SizeUnits);
	}
	return TEXT("0");
}
