#include "ResourceCheck/RuleFunctions/LevelSequence/LevelSequenceRule.h"

#include "CineCameraActor.h"
#include "CineCameraComponent.h"
#include "MovieScene.h"
#include "NiagaraActor.h"
#include "NiagaraComponent.h"
#include "ObjectEditorUtils.h"
#include "Bindings/MovieSceneSpawnableActorBinding.h"
#include "Bindings/MovieSceneSpawnableBinding.h"
#include "Camera/CameraActor.h"
#include "Components/LightComponent.h"
#include "Engine/DirectionalLight.h"
#include "Engine/RectLight.h"
#include "Engine/SkyLight.h"
#include "GameFramework/ActorPlatformSetUtilities.h"
#include "MovieScene/MovieSceneNiagaraSystemSpawnSection.h"
#include "MovieScene/MovieSceneNiagaraSystemTrack.h"
#include "Sections/MovieSceneBoolSection.h"
#include "Sections/MovieSceneCinematicShotSection.h"
#include "Sections/MovieSceneComponentMaterialParameterSection.h"
#include "Sections/MovieSceneFloatSection.h"
#include "Settings/SceneCIConfig.h"
#include "Settings/SceneConvertSettings.h"
#include "Tracks/MovieSceneCameraCutTrack.h"
#include "Tracks/MovieSceneCinematicShotTrack.h"
#include "Tracks/MovieSceneColorTrack.h"
#include "Tracks/MovieSceneEventTrack.h"
#include "Tracks/MovieSceneFloatTrack.h"
#include "Tracks/MovieSceneMaterialTrack.h"
#include "Tracks/MovieSceneSubTrack.h"

UClass* ULevelSequenceRule::GetAssetType()
{
	return ULevelSequence::StaticClass();
}

bool ULevelSequenceRule::PreExecuteAsset(const FAssetData& AssetData)
{
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null"));
		return false;
	}
	PossessableActors = GetAllPossessableActors(LevelSequence, BindingActors);
	SpawnableActors = GetAllSpawnableActors(LevelSequence, BindingActors);
	return true;
}

bool ULevelSequenceRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	TArray<FString> OverridablePostProcessPropertyGroupList = Params.GetValueList(TEXT("OverridablePostProcessPropertyNames"), TEXT(";"));
	OverridablePostProcessPropertyNames.Empty();
	for (const FString& Groups : OverridablePostProcessPropertyGroupList)
	{
		FString GroupName, PropertyList;
		Groups.Split(TEXT(":"), &GroupName, &PropertyList);
		TArray<FString> PropertyNames;
		PropertyList.ParseIntoArray(PropertyNames, TEXT(","));
		OverridablePostProcessPropertyNames.Add(GroupName, PropertyNames);
	}
	return true;
}

bool ULevelSequenceRule::PostExecuteAsset(const FAssetData& AssetData)
{
	PossessableActors.Reset();
	SpawnableActors.Reset();
	BindingActors.Reset();
	return true;
}

TArray<AActor*> ULevelSequenceRule::GetAllPossessableActors(const ULevelSequence* LevelSequence, TMap<FGuid, AActor*>& GuidActors)
{
	TArray<AActor*> Actors;
	if (LevelSequence == nullptr)
	{
		return Actors;
	}
	const FMovieSceneBindingReferences* MovieSceneBindingReferences = LevelSequence->GetBindingReferences();
	if (MovieSceneBindingReferences == nullptr)
	{
		return Actors;
	}
	for (const FMovieSceneBindingReference& Reference: MovieSceneBindingReferences->GetAllReferences())
	{
		FStringBuilderBase OutStrings;
		Reference.Locator.ToString(OutStrings);
		FString LocatorPaths = OutStrings.ToString();
		if (LocatorPaths.Contains("actor?"))
		{
			FString LString, RString;
			LocatorPaths.Split(TEXT("?"), &LString, &RString);
			TArray<FString> PayloadArray;
			RString.ParseIntoArray(PayloadArray, TEXT("&"));
			for (FString Payload : PayloadArray)
			{
				FString SoftObjectPath;
				Payload.Split(TEXT("="), &LString, &SoftObjectPath);
				FString WorldPath, ActorName;
				SoftObjectPath.Split(TEXT(":"), &WorldPath, &ActorName);
				if (UWorld* World = LoadObject<UWorld>(nullptr, *WorldPath))
				{
					UObject* OutObject = nullptr;
					World->ResolveSubobject(*ActorName, OutObject, true);
					if (AActor* Actor = Cast<AActor>(OutObject))
					{
						Actors.Add(Actor);
						if (!GuidActors.Contains(Reference.ID))
						{
							GuidActors.Add(Reference.ID, Actor);
						}
					}
				}
			}
		}
	}
	return Actors;
}

TArray<AActor*> ULevelSequenceRule::GetAllSpawnableActors(const ULevelSequence* LevelSequence, TMap<FGuid, AActor*>& GuidActors)
{
	TArray<AActor*> Actors;
	if (LevelSequence == nullptr)
	{
		return Actors;
	}
	const FMovieSceneBindingReferences* MovieSceneBindingReferences = LevelSequence->GetBindingReferences();
	if (MovieSceneBindingReferences == nullptr)
	{
		return Actors;
	}
	for (const FMovieSceneBindingReference& Reference: MovieSceneBindingReferences->GetAllReferences())
	{
		if (UMovieSceneSpawnableActorBinding* SpawnableActorBinding = Cast<UMovieSceneSpawnableActorBinding>(Reference.CustomBinding))
		{
			if (AActor* Actor = Cast<AActor>(SpawnableActorBinding->GetObjectTemplate()))
			{
				Actors.Add(Actor);
				if (!GuidActors.Contains(Reference.ID))
				{
					GuidActors.Add(Reference.ID, Actor);
				}
			}
		}
	}
	return Actors;
}

int32 ULevelSequenceRule::GetSpawnableActorCount(const ULevelSequence* LevelSequence)
{
	int32 ActorCount = 0;
	if (LevelSequence == nullptr)
	{
		return ActorCount;
	}
	const FMovieSceneBindingReferences* MovieSceneBindingReferences = LevelSequence->GetBindingReferences();
	if (MovieSceneBindingReferences == nullptr)
	{
		return ActorCount;
	}
	for (const FMovieSceneBindingReference& Reference: MovieSceneBindingReferences->GetAllReferences())
	{
		if (UMovieSceneSpawnableActorBinding* SpawnableActorBinding = Cast<UMovieSceneSpawnableActorBinding>(Reference.CustomBinding))
		{
			if (Cast<AActor>(SpawnableActorBinding->GetObjectTemplate()))
			{
				++ActorCount;
			}
		}
	}
	return ActorCount;
}
TArray<FAssetData> ULevelSequenceRule::GetAllDependedLevelSequenceAssetData(const FAssetData& AssetData, int32 CurrentDepth, TSet<FName>& VisitedPackages)
{
	constexpr int32 MAX_RECURSION_DEPTH = 10;
    
    // 深度限制检查
    if (CurrentDepth > MAX_RECURSION_DEPTH)
    {
        UE_LOG(LogTemp, Error, TEXT("递归深度超过限制(%d)，资产: %s"), 
            MAX_RECURSION_DEPTH, *AssetData.PackageName.ToString());
        return TArray<FAssetData>();
    }
    
    // 循环依赖检查：如果已经访问过此资产包，说明存在循环依赖
    if (VisitedPackages.Contains(AssetData.PackageName))
    {
        UE_LOG(LogTemp, Warning, TEXT("检测到循环依赖，资产: %s"), *AssetData.PackageName.ToString());
        return TArray<FAssetData>();
    }
    
    // 标记当前资产为已访问
    VisitedPackages.Add(AssetData.PackageName);
    
    TArray<FAssetData> Result;
    TArray<FName> DependAssetList;
    
    FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
    if (AssetRegistryModule.Get().GetDependencies(AssetData.PackageName, DependAssetList))
    {
        for (const auto& DependAsset : DependAssetList)
        {
            TArray<FAssetData> OutAssetDatas;
            AssetRegistryModule.Get().GetAssetsByPackageName(DependAsset, OutAssetDatas);
            
            for (const FAssetData& Data : OutAssetDatas)
            {
                if (Data.AssetClassPath == ULevelSequence::StaticClass()->GetClassPathName())
                {
                    Result.Append(GetAllDependedLevelSequenceAssetData(Data, CurrentDepth + 1, VisitedPackages));
                }
            }
        }
    }
    
    if (AssetData.AssetClassPath == ULevelSequence::StaticClass()->GetClassPathName())
    {
        Result.Add(AssetData);
    }
    
    return Result;
}

// 公开接口
TArray<FAssetData> ULevelSequenceRule::GetAllDependedLevelSequenceAssetData(const FAssetData& AssetData)
{
    TSet<FName> VisitedPackages;
    return GetAllDependedLevelSequenceAssetData(AssetData, 0, VisitedPackages);
}

// 获取possessable的父actor，如果possessable有父actor则返回父actor，否则返回possessable绑定的actor
const AActor* ULevelSequenceRule::GetPossessableParentActor(const ULevelSequence* LevelSequence, const FMovieScenePossessable* Possessable)
{
	if (LevelSequence == nullptr || Possessable == nullptr)
	{
		return nullptr;
	}
	const FMovieSceneBindingReferences* MovieSceneBindingReferences = LevelSequence->GetBindingReferences();
	if (MovieSceneBindingReferences == nullptr)
	{
		return nullptr;
	}
	
	const FGuid& ParentGuid = Possessable->GetParent();
	FGuid ActorGuid = Possessable->GetGuid();
	if (ParentGuid.IsValid())
	{
		ActorGuid = ParentGuid;
	}
	if (const UMovieSceneSpawnableActorBinding* SpawnableActorBinding = Cast<UMovieSceneSpawnableActorBinding>(MovieSceneBindingReferences->GetCustomBinding(ActorGuid, 0)))
	{
		return Cast<AActor>(const_cast<UMovieSceneSpawnableActorBinding*>(SpawnableActorBinding)->GetObjectTemplate());
	}
	return nullptr;
}

FString ULevelSequenceRule::GetSpawnedActorsCount(const FAssetData& AssetData) const
{
	int32 ActorCount = 0;
	const TArray<FAssetData>& DependedLevelSequenceAssetData = GetAllDependedLevelSequenceAssetData(AssetData);
	TSet<const ULevelSequence*> LevelSequenceSet;
	for (const FAssetData& Data : DependedLevelSequenceAssetData)
	{
		if (const ULevelSequence* LevelSequence = Cast<ULevelSequence>(Data.GetAsset()))
		{
			if (!LevelSequenceSet.Contains(LevelSequence))
			{
				ActorCount += GetSpawnableActorCount(LevelSequence);
				LevelSequenceSet.Add(LevelSequence);
			}
		}
	}
	return FString::FromInt(ActorCount);
}

FString ULevelSequenceRule::GetCanProcessBySceneConvertActorsCount(const FAssetData& AssetData) const
{
	const TArray<FAssetData>& DependedLevelSequenceAssetData = GetAllDependedLevelSequenceAssetData(AssetData);
	TSet<const ULevelSequence*> LevelSequenceSet;
	TSet<const AActor*> ActorSet;
	for (const FAssetData& Data : DependedLevelSequenceAssetData)
	{
		if (const ULevelSequence* LevelSequence = Cast<ULevelSequence>(Data.GetAsset()))
		{
			if (!LevelSequenceSet.Contains(LevelSequence))
			{
				GetCanProcessBySceneConvertActors(LevelSequence, ActorSet);
				LevelSequenceSet.Add(LevelSequence);
			}
		}
	}
	return FString::FromInt(ActorSet.Num());
}

void ULevelSequenceRule::GetCanProcessBySceneConvertActors(const ULevelSequence* LevelSequence, TSet<const AActor*>& ActorSet)
{
	if (LevelSequence == nullptr)
	{
		return;
	}
	TMap<FGuid, AActor*> ActorMap;
	for (const AActor* Actor: GetAllPossessableActors(LevelSequence, ActorMap))
	{
		const USceneCIConfig* SceneCIConfig = GetSceneCIConfig();
		if (SceneCIConfig && SceneCIConfig->CanProcessBySceneConvert(Actor))
		{
			ActorSet.Add(Actor);
		}
	}
}

bool ULevelSequenceRule::CheckStaticMobilityDependence(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = false;
	if (const ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset()))
	{
		// 对引用的场景中的actor进行检查
		for (const FMovieSceneBindingReference& Reference: LevelSequence->GetBindingReferences()->GetAllReferences())
		{
			FStringBuilderBase OutStrings;
			Reference.Locator.ToString(OutStrings);
			FString LocatorPaths = OutStrings.ToString();
			if (LocatorPaths.Contains("actor?"))
			{
				FString LString, RString;
				LocatorPaths.Split(TEXT("?"), &LString, &RString);
				TArray<FString> PayloadArray;
				RString.ParseIntoArray(PayloadArray, TEXT("&"));
				for (FString Payload : PayloadArray)
				{
					FString SoftObjectPath;
					Payload.Split(TEXT("="), &LString, &SoftObjectPath);
					FString WorldPath, ActorName;
					SoftObjectPath.Split(TEXT(":"), &WorldPath, &ActorName);
					if (UWorld* World = LoadObject<UWorld>(nullptr, *WorldPath))
					{
						UObject* OutObject = nullptr;
						World->ResolveSubobject(*ActorName, OutObject, true);
						if (const AActor* Actor = Cast<AActor>(OutObject))
						{
							if (Actor->GetRootComponent() && Actor->GetRootComponent()->Mobility == EComponentMobility::Static)
							{
								Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("level sequence不能引用static mobility的对象:{}"), SoftObjectPath);
								bSuccess = false;
							}
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckDependedLevel(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TArray<FName> DependAssetList;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	if (AssetRegistryModule.Get().GetDependencies(AssetData.PackageName, DependAssetList))
	{
		const TArray<FString>& ForbidDependedPaths = Params.GetValueList("ForbidDependedPaths");
		for (const auto& DependAsset : DependAssetList)
		{
			TArray<FAssetData> OutAssetDatas;
			AssetRegistryModule.Get().GetAssetsByPackageName(DependAsset, OutAssetDatas);

			for (const FAssetData& DependAssetData : OutAssetDatas)
			{
				UClass* DependAssetClass = DependAssetData.GetClass();
				if (DependAssetClass && (DependAssetClass->IsChildOf(ULevel::StaticClass()) || DependAssetClass->IsChildOf(UWorld::StaticClass())))
				{
					FString ObjectPath = DependAssetData.GetObjectPathString();
					for (auto Path : ForbidDependedPaths)
					{
						if (ObjectPath.StartsWith(Path))
						{
							Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("关卡序列不能引用{}路径下的关卡:{}"), Path, DependAssetData.AssetName);
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckMaterialParam(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null"));
		return bSuccess;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null"));
		return bSuccess;
	}
	for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
	{
		for (const UMovieSceneTrack* Track : Binding.GetTracks())
		{
			if (Track == nullptr)
			{
				continue;
			}
			const UMovieSceneMaterialTrack* MaterialTrack = Cast<UMovieSceneMaterialTrack>(Track);
			if (MaterialTrack == nullptr)
			{
				continue;
			}
			for (const UMovieSceneSection* Section : MaterialTrack->GetAllSections())
			{
				if (Section == nullptr)
				{
					continue;
				}
				const UMovieSceneComponentMaterialParameterSection* MaterialParameterSection = Cast<UMovieSceneComponentMaterialParameterSection>(Section);
				if (MaterialParameterSection == nullptr)
				{
					continue;
				}
				for (const FScalarMaterialParameterInfoAndCurve& ScalarMaterialParameterInfoAndCurve : MaterialParameterSection->ScalarParameterInfosAndCurves)
				{
					FName ParameterName = ScalarMaterialParameterInfoAndCurve.ParameterInfo.Name;
					if (ParameterName == TEXT("_DissolveAlpha") || ParameterName == TEXT("_DitherAlpha"))
					{
						Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("关卡序列不能有_DissolveAlpha  or _DitherAlpha 这两个参数"));
						return false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckMaterialLightPosParam(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null"));
		return bSuccess;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null"));
		return bSuccess;
	}
	for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
	{
		for (const UMovieSceneTrack* Track : Binding.GetTracks())
		{
			if (Track == nullptr)
			{
				continue;
			}
			const UMovieSceneMaterialTrack* MaterialTrack = Cast<UMovieSceneMaterialTrack>(Track);
			if (MaterialTrack == nullptr)
			{
				continue;
			}
			for (const UMovieSceneSection* Section : MaterialTrack->GetAllSections())
			{
				if (Section == nullptr)
				{
					continue;
				}
				const UMovieSceneComponentMaterialParameterSection* MaterialParameterSection = Cast<UMovieSceneComponentMaterialParameterSection>(Section);
				if (MaterialParameterSection == nullptr)
				{
					continue;
				}
				for (const FColorMaterialParameterInfoAndCurves& ColorMaterialParameterInfoAndCurve : MaterialParameterSection->ColorParameterInfosAndCurves)
				{
					FName ParameterName = ColorMaterialParameterInfoAndCurve.ParameterInfo.Name;
					if (ParameterName == TEXT("LightPos"))
					{
						Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("关卡序列不能有LightPos这个参数"));
						return false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckSpawnedActorType(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	for (const AActor* Actor: SpawnableActors)
	{
		if (Actor == nullptr)
		{
			continue;
		}
		if (Actor->IsA(ADirectionalLight::StaticClass()))
		{
			Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("禁止Spawned形式在LevelSequence的轨道动态新增引入DirectionalLight,当前引入对象名:{}"), Actor->GetActorLabel());
			bSuccess = false;
		}
		else if (Actor->IsA(ASkyLight::StaticClass()))
		{
			Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("禁止Spawned形式在LevelSequence的轨道动态新增引入skylight,当前引入对象名:{}"), Actor->GetActorLabel());
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::IsWindowsOnly(const AActor* Actor)
{
	if (Actor == nullptr)
	{
		return false;
	}
	return !FActorPlatformSetUtilities::IsEnabledForPlatform(&Actor->Platforms, TEXT("Android")) && !FActorPlatformSetUtilities::IsEnabledForPlatform(&Actor->Platforms, TEXT("IOS"));
}

bool ULevelSequenceRule::CheckWindowsOnlyFeature(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	for (const AActor* Actor: SpawnableActors)
	{
		if (Actor == nullptr)
		{
			continue;
		}
		if (const ALight* Light = Cast<ALight>(Actor))
		{
			if (IsWindowsOnly(Light))
			{
				continue;
			}
			if (Light->GetLightComponent() && Light->GetLightComponent()->LightFunctionMaterial)
			{
				Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("Spawned的Light其LightFunctionMaterial不为空时必须设置Scalability为Windows Only,当前的Light为:{}"), Actor->GetActorLabel());
				bSuccess = false;
			}
			if (Light->IsA(ARectLight::StaticClass()))
			{
				Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("Spawned的RectLight必须设置Scalability为Windows Only,当前的RectLight为:{}"), Actor->GetActorLabel());
				bSuccess = false;
			}
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckCharacterLightIntensityTrack(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null"));
		return bSuccess;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null"));
		return bSuccess;
	}
	TArray<FString> InvalidLightPropertyNames = Params.GetValueList(TEXT("InvalidLightPropertyNames"));
	for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
	{
		for (const UMovieSceneTrack* Track : Binding.GetTracks())
		{
			if (Track == nullptr)
			{
				continue;
			}
			if (const UMovieScenePropertyTrack* PropertyTrack = Cast<UMovieScenePropertyTrack>(Track))
			{
				const FString& PropertyName = PropertyTrack->GetPropertyName().ToString();
				if (InvalidLightPropertyNames.Contains(PropertyName))
				{
					Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("禁止在Sequence控制DirectionalLight/SkyLight里的{}属性,当前控制对象:{}"), PropertyName, Binding.GetName());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::IsWorldHasLightingBuildData(const UWorld* World)
{
	bool bHasLightmap= false;
	if (World && !World->IsPartitionedWorld())
	{
		bHasLightmap = World->PersistentLevel->MapBuildData != nullptr;
		const AWorldSettings* WS = World->GetWorldSettings();
		if (!bHasLightmap)
		{
			for (ULevel* Level : World->GetLevels())
			{
				if (Level && Level->MapBuildData != nullptr)
				{
					bHasLightmap = true;
					break;
				}
			}
		}
		bHasLightmap &= !WS->bForceNoPrecomputedLighting;
	}
	return bHasLightmap;
}

bool ULevelSequenceRule::CheckDependedSceneActorBase(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null"));
		return bSuccess;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null"));
		return bSuccess;
	}
	float SceneActorMeshBoundValidSize = FCString::Atof(*Params.GetValue(TEXT("SceneActorMeshBoundValidSize")));
	TMap<FGuid, AActor*> CanProcessBySceneConvertActorGuids;
	for (auto BindingActor : BindingActors)
	{
		const AActor* Actor = BindingActor.Value;
		if (Actor == nullptr)
		{
			continue;
		}
		if (!PossessableActors.Contains(Actor))
		{
			continue;
		}
		const USceneCIConfig* SceneCIConfig = GetSceneCIConfig();
		if (SceneCIConfig && SceneCIConfig->CanProcessBySceneConvert(Actor))
		{
			CanProcessBySceneConvertActorGuids.Add(BindingActor.Key, BindingActor.Value);
			const FMovieSceneBinding* MovieSceneBinding = MovieScene->FindBinding(BindingActor.Key);
			if (MovieSceneBinding == nullptr)
			{
				continue;
			}
			for (const UMovieSceneTrack* Track : MovieSceneBinding->GetTracks())
			{
				if (Track == nullptr)
				{
					continue;
				}
				FString TrackName = Track->GetName();
				bool bValidTrack = false;
				if (const UMovieScenePropertyTrack* PropertyTrack = Cast<UMovieScenePropertyTrack>(Track))
				{
					if (PropertyTrack->UniqueTrackName == TEXT("bHidden"))
					{
						bValidTrack = true;
						UWorld* World = Actor->GetWorld();
						if (IsWorldHasLightingBuildData(World))
						{
							TInlineComponentArray<UStaticMeshComponent*> StaticMeshComponents(Actor);
							for (auto MeshComponent : StaticMeshComponents)
							{
								if (MeshComponent == nullptr)
								{
									continue;
								}
								if (UStaticMesh* StaticMesh = MeshComponent->GetStaticMesh())
								{
									const FBoxSphereBounds& Bounds = StaticMesh->GetBounds();
									if (Bounds.BoxExtent.X > SceneActorMeshBoundValidSize || Bounds.BoxExtent.Y > SceneActorMeshBoundValidSize || Bounds.BoxExtent.Z > SceneActorMeshBoundValidSize)
									{
										Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("当前引用对象:{}控制的是烘焙场景模型，Mesh的Bound尺寸需要限制在{}厘米以内（长宽高）"), Actor->GetActorLabel(), SceneActorMeshBoundValidSize);
										bSuccess = false;
									}
								}
							}
						}
					}
				}
				if (bValidTrack)
				{
					continue;
				}
				Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("Seq引用除SceneActorBase之外的场景对象,只允许修改visibility,当前引用对象:{}"), Actor->GetActorLabel());
				bSuccess = false;
			}
		}
	}
	for (int32 i = 0; i < MovieScene->GetPossessableCount(); ++i)
	{
		const FMovieScenePossessable& Possessable = MovieScene->GetPossessable(i);
		const FGuid& ParentGuid = Possessable.GetParent();
		if (!ParentGuid.IsValid())
		{
			continue;
		}
		if (!CanProcessBySceneConvertActorGuids.Contains(ParentGuid))
		{
			continue;
		}
		AActor* Actor = CanProcessBySceneConvertActorGuids[ParentGuid];
		Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("Seq引用除SceneActorBase之外的场景对象,只允许修改visibility,当前引用对象:{}"), Actor->GetActorLabel());
		bSuccess = false;
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckEventTrack(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null"));
		return bSuccess;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null"));
		return bSuccess;
	}
	for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
	{
		for (const UMovieSceneTrack* Track : Binding.GetTracks())
		{
			if (Track == nullptr)
			{
				continue;
			}
			if (const UMovieSceneEventTrack* EventTrack = Cast<UMovieSceneEventTrack>(Track))
			{
				Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("LevelSequence禁止使用轨道触发蓝图事件,当前轨道:{}"), EventTrack->GetDisplayName());
				bSuccess = false;
			}
		}
	}
	for (const UMovieSceneTrack* Track : MovieScene->GetTracks())
	{
		if (const UMovieSceneEventTrack* EventTrack = Cast<UMovieSceneEventTrack>(Track))
		{
			Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("LevelSequence禁止使用轨道触发蓝图事件,当前轨道:{}"), EventTrack->GetDisplayName());
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckFloatPropertyTrack(const UMovieScenePropertyTrack* PropertyTrack, 
						   float MinValue, float MaxValue)
{
	for (UMovieSceneSection* Section : PropertyTrack->GetAllSections())
	{
		if (const UMovieSceneFloatSection* FloatSection = Cast<UMovieSceneFloatSection>(Section))
		{
			const FMovieSceneFloatChannel& Channel = FloatSection->GetChannel();
            
			// 检查默认值
			if (const TOptional<float>& DefaultValue = Channel.GetDefault();
				DefaultValue.IsSet() && (DefaultValue.GetValue() < MinValue || DefaultValue.GetValue() > MaxValue))
			{
				return false;
			}
            
			// 检查所有关键帧值
			for (const FMovieSceneFloatValue& Value : Channel.GetData().GetValues())
			{
				if (Value.Value < MinValue || Value.Value > MaxValue)
				{
					return false;
				}
			}
		}
	}
	return true;
}

bool ULevelSequenceRule::CheckCameraProperties(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null"));
		return bSuccess;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null"));
		return bSuccess;
	}
	const FString ValidCurrentApertureStr = Params.GetValue(TEXT("ValidCurrentAperture"));
	const float ValidCurrentAperture = FCString::Atof(*ValidCurrentApertureStr);
	const FString ValidLowerAutoExposureBiasStr = Params.GetValue(TEXT("ValidLowerAutoExposureBias"));
	const float ValidLowerAutoExposureBias = FCString::Atof(*ValidLowerAutoExposureBiasStr);
	const FString ValidUpperAutoExposureBiasStr = Params.GetValue(TEXT("ValidUpperAutoExposureBias"));
	const float ValidUpperAutoExposureBias = FCString::Atof(*ValidUpperAutoExposureBiasStr);
	TMap<FString, TPair<float, float>> CheckPropertiesValue = {
		{TEXT("CurrentAperture"), {ValidCurrentAperture, MAX_FLT}},
		{TEXT("AutoExposureBias"), {ValidLowerAutoExposureBias, ValidUpperAutoExposureBias}}
	};
	for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
	{
		const FMovieScenePossessable* Possessable = MovieScene->FindPossessable(Binding.GetObjectGuid());
		if (Possessable == nullptr)
		{
			continue;
		}
		const UClass* BoundObjectClass = Possessable->GetPossessedObjectClass();
		if (BoundObjectClass == nullptr)
		{
			continue;
		}
		const bool bIsCineCameraComponent = BoundObjectClass->IsChildOf(UCineCameraComponent::StaticClass());
		const bool bIsPostProcessVolume = BoundObjectClass->IsChildOf(APostProcessVolume::StaticClass());
		if (!bIsCineCameraComponent && !bIsPostProcessVolume)
		{
			continue;
		}
		FString CameraActorName;
		if (const AActor* ActorTemplate = GetPossessableParentActor(LevelSequence, Possessable))
		{
			CameraActorName = ActorTemplate->GetActorLabel();
		}
		else
		{
			CameraActorName = Binding.GetName();
		}
		TMap<FString, FString> CheckPropertiesLogs = {
			{TEXT("CurrentAperture"), FString::Format(TEXT("后处理的镜头光圈属性Aperture应该大于{0},当前有问题的相机或后处理对象:{1}"), {ValidCurrentApertureStr, CameraActorName})},
			{TEXT("AutoExposureBias"), FString::Format(TEXT("后处理的镜头曝光属性数值应该在({0}, {1})之内,当前有问题的相机或后处理对象:{2}"), {ValidLowerAutoExposureBiasStr, ValidUpperAutoExposureBiasStr, CameraActorName})}
		};
		for (const UMovieSceneTrack* Track : Binding.GetTracks())
		{
			if (Track == nullptr)
			{
				continue;
			}
			if (const UMovieScenePropertyTrack* PropertyTrack = Cast<UMovieScenePropertyTrack>(Track))
			{
				const FString PropertyName = PropertyTrack->GetPropertyName().ToString();
				if (CheckPropertiesLogs.Contains(PropertyName))
				{
					if (!CheckFloatPropertyTrack(PropertyTrack, CheckPropertiesValue[PropertyName].Key, CheckPropertiesValue[PropertyName].Value))
					{
						Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,CheckPropertiesLogs[PropertyName]);
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckPostProcessOverride(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null"));
		return bSuccess;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null"));
		return bSuccess;
	}
	
	const FName EditConditionKey = TEXT("EditCondition");
	for (auto BindingActor : BindingActors)
	{
		const AActor* Actor = BindingActor.Value;
		if (Actor == nullptr)
		{
			continue;
		}
		const FPostProcessSettings* PostProcessSettings = nullptr;
		FStructProperty* StructProp = nullptr;
		if (const ACineCameraActor* CineCameraActor = Cast<ACineCameraActor>(Actor))
		{
			if (UCineCameraComponent* CineCameraComponent = CineCameraActor->GetCineCameraComponent())
			{
				PostProcessSettings = &CineCameraComponent->PostProcessSettings;
				StructProp = CastField<FStructProperty>(UCineCameraComponent::StaticClass()->FindPropertyByName(FName("PostProcessSettings")));
			}
		}
		else if (const APostProcessVolume* PostProcessVolume = Cast<APostProcessVolume>(Actor))
		{
			PostProcessSettings = &PostProcessVolume->Settings;
			StructProp = CastField<FStructProperty>(APostProcessVolume::StaticClass()->FindPropertyByName(FName("Settings")));
		}
		if (PostProcessSettings == nullptr || StructProp == nullptr || StructProp->Struct == nullptr)
		{
			continue;
		}
		
		for (TFieldIterator<FProperty> PropIt(StructProp->Struct); PropIt; ++PropIt)
		{
			FProperty* Prop = *PropIt;
			if (Prop == nullptr)
			{
				continue;
			}
			FString CategoryName = FObjectEditorUtils::GetCategoryFName(Prop).ToString();
			TArray<FString> CategoryAndGroups;
			CategoryName.ParseIntoArray(CategoryAndGroups, TEXT("|"));
			FString RootCategoryName = CategoryAndGroups.Num() > 0 ? CategoryAndGroups[0] : CategoryName;
			
			FString CategoryKey;
			if (OverridablePostProcessPropertyNames.Contains(CategoryName))
			{
				CategoryKey = CategoryName;
			}
			else if (OverridablePostProcessPropertyNames.Contains(RootCategoryName))
			{
				CategoryKey = RootCategoryName;
			}
			if (CategoryKey.IsEmpty())
			{
				continue;
			}
			const TArray<FString>& OverridableNames = OverridablePostProcessPropertyNames[CategoryKey];
			FString PropertyName = Prop->GetName();
			if (OverridableNames.Contains(PropertyName))
			{
				continue;
			}
			if (!Prop->HasMetaData(EditConditionKey))
			{
				continue;
			}
			const FString& EditCondition = Prop->GetMetaData(EditConditionKey);
			const FBoolProperty* BoolProp = CastField<FBoolProperty>(StructProp->Struct->FindPropertyByName(*EditCondition));
			if (BoolProp == nullptr)
			{
				continue;
			}
			const void* EditConditionPropertyAddress = BoolProp->ContainerPtrToValuePtr<void>(PostProcessSettings);
			if (EditConditionPropertyAddress == nullptr)
			{
				continue;
			}
			if (BoolProp->GetPropertyValue(EditConditionPropertyAddress))
			{
				FString PropertyDisplayName = Prop->GetDisplayNameText().ToString();
				Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType, TEXT("不允许修改{}的后处理参数:{}:{}"), Actor->GetActorLabel(), CategoryName, PropertyDisplayName);
				bSuccess = false;
			}
		}
	}
	return bSuccess;
}

float ULevelSequenceRule::GetStartFrameSeconds(UMovieSceneSection* Section)
{
	if (!Section)
	{
		FFrame::KismetExecutionMessage(TEXT("Cannot call GetStartFrameSeconds on a null section"), ELogVerbosity::Error);
		return -1.f;
	}

	if (!Section->HasStartFrame())
	{
		FFrame::KismetExecutionMessage(TEXT("Section does not have a start frame"), ELogVerbosity::Error);
		return -1.f;
	}

	UMovieScene* MovieScene = Section->GetTypedOuter<UMovieScene>();
	if (MovieScene)
	{
		FFrameRate DisplayRate = MovieScene->GetDisplayRate();
		return DisplayRate.AsSeconds(ConvertFrameTime(UE::MovieScene::DiscreteInclusiveLower(Section->GetRange()), MovieScene->GetTickResolution(), DisplayRate));
	}

	return -1.f;
}

bool ULevelSequenceRule::CheckNiagaraStartTime(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	const ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null"));
		return bSuccess;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null"));
		return bSuccess;
	}
	const float NiagaraValidStartTime = FCString::Atof(*Params.GetValue(TEXT("NiagaraValidStartTime")));
	for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
	{
		const FMovieScenePossessable* Possessable = MovieScene->FindPossessable(Binding.GetObjectGuid());
		if (Possessable == nullptr)
		{
			continue;
		}
		const UClass* BoundObjectClass = Possessable->GetPossessedObjectClass();
		if (BoundObjectClass == nullptr)
		{
			continue;
		}
		if (!BoundObjectClass->IsChildOf(UNiagaraComponent::StaticClass()))
		{
			continue;
		}
		for (const UMovieSceneTrack* Track : Binding.GetTracks())
		{
			if (Track == nullptr)
			{
				continue;
			}
			if (!Track->IsA(UMovieSceneNiagaraSystemTrack::StaticClass()))
			{
				continue;
			}
			for (const UMovieSceneSection* Section : Track->GetAllSections())
			{
				if (Section == nullptr)
				{
					continue;
				}
				const UMovieSceneNiagaraSystemSpawnSection* NiagaraSection = Cast<UMovieSceneNiagaraSystemSpawnSection>(Section);
				if (NiagaraSection == nullptr)
				{
					continue;
				}
				if (NiagaraSection->GetAgeUpdateMode() != ENiagaraAgeUpdateMode::DesiredAge)
				{
					continue;
				}
				auto LowerBound = Section->SectionRange.GetLowerBound();
				if (LowerBound.IsClosed())
				{
					const float StartSeconds = GetStartFrameSeconds(const_cast<UMovieSceneSection*>(Section));
					if (StartSeconds < NiagaraValidStartTime)
					{
						FString NiagaraActorName;
						if (const AActor* ActorTemplate = GetPossessableParentActor(LevelSequence, Possessable))
						{
							NiagaraActorName = ActorTemplate->GetActorLabel();
						}
						else
						{
							NiagaraActorName = Binding.GetName();
						}
						Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("特效轨道的提前摆放时间不能超过{}（Property的Section时间不能小于{}）,当前对象:{}"), -NiagaraValidStartTime, NiagaraValidStartTime, NiagaraActorName);
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckCollision(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TArray<FString> WhiteCollisionActorClasses = Params.GetValueList(TEXT("WhiteCollisionActorClasses"));
	for (const AActor* Actor: SpawnableActors)
	{
		if (Actor == nullptr)
		{
			continue;
		}
		if (Actor->GetClass())
		{
			FString ActorClassName = Actor->GetClass()->GetName();
			if (WhiteCollisionActorClasses.Contains(ActorClassName))
			{
				continue;
			}
		}
		if (!Actor->GetActorEnableCollision())
		{
			continue;
		}
		TInlineComponentArray<UPrimitiveComponent*> PrimitiveComponents(Actor);
		for (const UPrimitiveComponent* PrimitiveComponent : PrimitiveComponents)
		{
			if (PrimitiveComponent == nullptr)
			{
				continue;
			}
			if (PrimitiveComponent->BodyInstance.GetCollisionEnabled())
			{
				Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("Sequence创建的Actor特效等对象都需要关闭碰撞 避免影响其他对象的表现,当前创建的Actor对象名:{}"), Actor->GetActorLabel());
				bSuccess = false;
				break;
			}
		}
	}
	return bSuccess;
}

bool ULevelSequenceRule::CheckEmptyCameraCutsFrame(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
    // 1. 基础检查
    ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
    if (LevelSequence == nullptr)
    {
        UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null for asset: %s"), *AssetData.GetObjectPathString());
        return true; // 空序列视为检查通过
    }
    
    UMovieScene* MovieScene = LevelSequence->GetMovieScene();
    if (MovieScene == nullptr)
    {
        UE_LOG(LogTemp, Warning, TEXT("MovieScene is null for sequence: %s"), *LevelSequence->GetName());
        return true;
    }
    
    // 2. 播放范围检查
    const TRange<FFrameNumber>& PlaybackRange = MovieScene->GetPlaybackRange();
    if (!PlaybackRange.HasUpperBound() || !PlaybackRange.GetUpperBound().IsClosed())
    {
        return true; // 无上边界或开放边界，视为通过
    }
    
    const FFrameNumber LevelSequenceEnd = PlaybackRange.GetUpperBoundValue();
    
    // 3. 检查是否存在镜头轨道
    bool bHasCameraCutSection = CheckCameraCutTrack(MovieScene, LevelSequenceEnd);
    bool bHasShotsSection = CheckShotTracks(MovieScene, LevelSequenceEnd);
    
    // 4. 无镜头轨道的情况直接通过
    if (!bHasCameraCutSection && !bHasShotsSection)
    {
        return true;
    }
    
    // 5. 检查镜头覆盖情况
    bool bCameraCutCoversEnd = CheckCameraCutCoverage(MovieScene, LevelSequenceEnd);
    bool bShotsCoverEnd = CheckShotsCoverage(MovieScene, LevelSequenceEnd);
    
    // 6. 最终判断
    if (!bCameraCutCoversEnd && !bShotsCoverEnd)
    {
        FString Message = FString::Printf(TEXT("Sequence结束以后需要立马衔接下一段或者结束,不能空帧,否则游戏内表现会有异常。特殊情况需加白"));
        Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType, Message);
        return false;
    }
    
    return true;
}

// 辅助函数：检查CameraCut轨道是否存在有效的Section
bool ULevelSequenceRule::CheckCameraCutTrack(const UMovieScene* MovieScene, FFrameNumber LevelSequenceEnd)
{
    if (const UMovieSceneTrack* CameraCutTrack = MovieScene->GetCameraCutTrack())
    {
        const TArray<UMovieSceneSection*>& Sections = CameraCutTrack->GetAllSections();
        return !Sections.IsEmpty();
    }
    return false;
}

// 辅助函数：检查CameraCut轨道是否覆盖序列末尾
bool ULevelSequenceRule::CheckCameraCutCoverage(const UMovieScene* MovieScene, const FFrameNumber LevelSequenceEnd)
{
    if (const UMovieSceneTrack* CameraCutTrack = MovieScene->GetCameraCutTrack())
    {
        const TArray<UMovieSceneSection*>& Sections = CameraCutTrack->GetAllSections();
        for (const UMovieSceneSection* Section : Sections)
        {
            if (Section && DoesSectionCoverFrame(Section, LevelSequenceEnd))
            {
                return true;
            }
        }
    }
    return false;
}

// 辅助函数：检查Shot轨道是否存在
bool ULevelSequenceRule::CheckShotTracks(const UMovieScene* MovieScene, FFrameNumber LevelSequenceEnd)
{
    for (const UMovieSceneTrack* Track : MovieScene->GetTracks())
    {
        if (Cast<UMovieSceneCinematicShotTrack>(Track) != nullptr)
        {
            const TArray<UMovieSceneSection*>& Sections = Track->GetAllSections();
            if (!Sections.IsEmpty())
            {
                return true;
            }
        }
    }
    return false;
}

// 辅助函数：检查Shot轨道是否覆盖序列末尾
bool ULevelSequenceRule::CheckShotsCoverage(const UMovieScene* MovieScene, FFrameNumber LevelSequenceEnd)
{
    for (const UMovieSceneTrack* Track : MovieScene->GetTracks())
    {
        if (const UMovieSceneCinematicShotTrack* ShotTrack = Cast<UMovieSceneCinematicShotTrack>(Track))
        {
            const TArray<UMovieSceneSection*>& Sections = ShotTrack->GetAllSections();
            for (const UMovieSceneSection* Section : Sections)
            {
                if (Section && DoesShotSectionCoverFrame(Section, LevelSequenceEnd))
                {
                    return true;
                }
            }
        }
    }
    return false;
}

// 辅助函数：检查单个Section是否覆盖指定帧
bool ULevelSequenceRule::DoesSectionCoverFrame(const UMovieSceneSection* Section, FFrameNumber TargetFrame)
{
    if (!Section) return false;
    
    const TRange<FFrameNumber>& SectionRange = Section->GetRange();
    if (SectionRange.HasUpperBound() && SectionRange.GetUpperBound().IsClosed())
    {
        const FFrameNumber SectionEnd = SectionRange.GetUpperBoundValue();
        return SectionEnd.Value >= TargetFrame.Value;
    }
    return false;
}

// 辅助函数：检查Shot Section是否覆盖指定帧（包含子序列检查）
bool ULevelSequenceRule::DoesShotSectionCoverFrame(const UMovieSceneSection* Section, FFrameNumber TargetFrame)
{
    if (!Section) return false;
    
    // 首先检查Shot Section本身是否覆盖
    if (!DoesSectionCoverFrame(Section, TargetFrame))
    {
        return false;
    }
    
    // 检查子序列的CameraCut轨道
    if (const UMovieSceneCinematicShotSection* ShotSection = Cast<UMovieSceneCinematicShotSection>(Section))
    {
	    if (const UMovieSceneSequence* SubSequence = ShotSection->GetSequence())
        {
            const UMovieScene* SubMovieScene = SubSequence->GetMovieScene();
            if (SubMovieScene && SubMovieScene->GetCameraCutTrack())
            {
                // 计算在子序列中的对应时间
                FFrameNumber SubSequenceTime = CalculateSubSequenceTime(ShotSection, TargetFrame);
                
                // 检查子序列CameraCut轨道在该时间是否有活跃的Section
                return CheckSubSequenceCameraCutAtTime(SubMovieScene, SubSequenceTime);
            }
        }
    }
    
    return false;
}

// 辅助函数：计算子序列中的对应时间
FFrameNumber ULevelSequenceRule::CalculateSubSequenceTime(const UMovieSceneCinematicShotSection* ShotSection, FFrameNumber TargetFrame)
{
    const TRange<FFrameNumber>& SectionRange = ShotSection->GetRange();
    FFrameNumber RelativeTime = TargetFrame - SectionRange.GetLowerBoundValue();
    
    const TOptional<FFrameTime>& OffsetTime = ShotSection->GetOffsetTime();
    if (OffsetTime.IsSet())
    {
        RelativeTime += OffsetTime.GetValue().GetFrame();
    }
    
    return RelativeTime;
}

// 辅助函数：检查子序列在指定时间是否有CameraCut
bool ULevelSequenceRule::CheckSubSequenceCameraCutAtTime(const UMovieScene* SubMovieScene, const FFrameNumber Time)
{
    if (const UMovieSceneTrack* SubCameraCutTrack = SubMovieScene->GetCameraCutTrack())
    {
        for (const UMovieSceneSection* SubCameraCutSection : SubCameraCutTrack->GetAllSections())
        {
            if (SubCameraCutSection)
            {
            	const TRange<FFrameNumber>& SubCameraCutSectionRange = SubCameraCutSection->GetRange();
            	if (SubCameraCutSectionRange.GetLowerBound().IsOpen() || SubCameraCutSectionRange.GetLowerBoundValue() <= Time)
            	{
            		if (SubCameraCutSectionRange.GetUpperBound().IsOpen() || SubCameraCutSectionRange.GetUpperBoundValue() >= Time)
            		{
            			return true;
            		}
            	}
            }
        }
    }
    return false;
}

bool ULevelSequenceRule::CheckCameraCutSectionOverlapping(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null for asset: %s"), *AssetData.GetObjectPathString());
		return true;
	}
    
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null for sequence: %s"), *LevelSequence->GetName());
		return true;
	}

	if (const UMovieSceneTrack* CameraCutTrack = MovieScene->GetCameraCutTrack())
	{
		const TArray<UMovieSceneSection*>& Sections = CameraCutTrack->GetAllSections();
		for (int32 i = 0; i < Sections.Num() - 1; i++)
		{
			const UMovieSceneSection* Section = Sections[i];
			TRange<FFrameNumber> SectionRange = Section->GetRange();
			const UMovieSceneSection* NextSection = Sections[i + 1];
			TRange<FFrameNumber> NextSectionRange = NextSection->GetRange();
			if (NextSectionRange.Overlaps(SectionRange))
			{
				Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("在CameraCut轨道中不能有两个CameraCutSection重叠"));
				return false;
			}
		}
	}
	return true;
}

bool ULevelSequenceRule::CheckCameraConstrainAspectRatio(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(AssetData.GetAsset());
	if (LevelSequence == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("LevelSequence is null for asset: %s"), *AssetData.GetObjectPathString());
		return true;
	}
    
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (MovieScene == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("MovieScene is null for sequence: %s"), *LevelSequence->GetName());
		return true;
	}
	bool bSuccess = true;
	if (const UMovieSceneCameraCutTrack* CameraCutTrack = Cast<UMovieSceneCameraCutTrack>(MovieScene->GetCameraCutTrack()))
	{
		if (!CameraCutTrack->bCanBlend)
		{
			return true;
		}
		for (int32 i = 0; i < MovieScene->GetPossessableCount(); ++i)
		{
			const FMovieScenePossessable& Possessable = MovieScene->GetPossessable(i);
			const UClass* BoundObjectClass = Possessable.GetPossessedObjectClass();
			if (BoundObjectClass == nullptr)
			{
				continue;
			}
			if (!BoundObjectClass->IsChildOf(UCineCameraComponent::StaticClass()))
			{
				continue;
			}
			if (const AActor* ActorTemplate =GetPossessableParentActor(LevelSequence, &Possessable))
			{
				if (const ACineCameraActor* CineCameraActor = Cast<ACineCameraActor>(ActorTemplate))
				{
					if (CineCameraActor->GetCineCameraComponent() && CineCameraActor->GetCineCameraComponent()->bConstrainAspectRatio)
					{
						Log.RegistryAndLog(AssetData, TEXT("LevelSequence"), CheckRuleType,TEXT("CameraCuts如果勾选了可混合，相机{}的Constrain Aspect Ratio参数不能为True"), CineCameraActor->GetActorLabel());
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}
