#include "ResourceCheck/RuleFunctions/BinkMediaPlayer/BinkMediaPlayerRule.h"
#include "BinkMediaPlayer.h"
#include "ISourceControlModule.h"
#include "SourceControlHelpers.h"

UClass* UBinkMediaPlayerRule::GetAssetType()
{
	return UBinkMediaPlayer::StaticClass();
}

FString UBinkMediaPlayerRule::GetUrlPath(const FAssetData& AssetData)
{
	if (UBinkMediaPlayer* BinkMediaPlayer = Cast<UBinkMediaPlayer>(AssetData.GetAsset()))
	{
		BinkMediaPlayer->InitializePlayer();
		FString Url = BinkMediaPlayer->GetUrl();
		return Url;
	}
	return TEXT("");
}

bool UBinkMediaPlayerRule::HasAbsolutePath(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (UBinkMediaPlayer* BinkMediaPlayer = Cast<UBinkMediaPlayer>(AssetData.GetAsset()))
	{
		BinkMediaPlayer->InitializePlayer();
		FString Url = BinkMediaPlayer->GetUrl();
		if (Url.IsEmpty())
		{
			Log.RegistryAndLog(AssetData, TEXT("BinkMediaPlayer"), CheckRuleType, TEXT("该资源的视频资源为空或者无法访问"));
			return false;
		}
		Url = Url.Replace(TEXT("./"), TEXT(""));
		FString MoviePath = FPaths::ProjectContentDir() + Url;
		FString AbsolutePath = FPaths::ConvertRelativePathToFull(MoviePath);
		if (!FPaths::FileExists(AbsolutePath))
		{
			Log.RegistryAndLog(AssetData, TEXT("BinkMediaPlayer"), CheckRuleType, TEXT("该资源的视频资源为空或者无法访问"));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UBinkMediaPlayerRule::CheckDependedBkAssetCommit(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	const FString SourceFileName = USourceControlHelpers::PackageFilename(AssetData.PackageName.ToString());
	FSourceControlStatePtr SourceFileState = SourceControlProvider.GetState(SourceFileName, EStateCacheUsage::ForceUpdate);
	if (!SourceFileState->IsAdded() && !SourceFileState->IsCheckedOut())
	{
		return true;
	}
	UBinkMediaPlayer* BinkMediaPlayer = Cast<UBinkMediaPlayer>(AssetData.GetAsset());
	if (BinkMediaPlayer == nullptr)
	{
		return true;
	}
	BinkMediaPlayer->InitializePlayer();
	FString Url = BinkMediaPlayer->GetUrl();
	if (Url.IsEmpty())
	{
		return true;
	}
	Url = Url.Replace(TEXT("./"), TEXT(""));
	const FString MoviePath = FPaths::ProjectContentDir() + Url;
	const FString AbsolutePath = FPaths::ConvertRelativePathToFull(MoviePath);
	if (!FPaths::FileExists(AbsolutePath))
	{
		return true;
	}
	const FSourceControlStatePtr BkFileState = SourceControlProvider.GetState(AbsolutePath, EStateCacheUsage::ForceUpdate);
	if (BkFileState->IsAdded())
	{
		const FString SourceChangeListID = SourceFileState->GetCheckInIdentifier()->GetIdentifier();
		const FString BkFileChangeListID = BkFileState->GetCheckInIdentifier()->GetIdentifier();
		if (SourceChangeListID != BkFileChangeListID)
		{
			Log.RegistryAndLog(AssetData, TEXT("BinkMediaPlayer"), CheckRuleType, TEXT("流媒体资产（.bk2）和Bink资源不在同一个changelist中，请一起上传"));
			return false;
		}
		return true;
	}
	if (!BkFileState->IsSourceControlled())
	{
		Log.RegistryAndLog(AssetData, TEXT("BinkMediaPlayer"), CheckRuleType, TEXT("流媒体资产（.bk2）未上传,请先在p4标记add一起上传"));
		return false;
	}
	return true;
}

FString UBinkMediaPlayerRule::GetBinkMediaResolution(const FAssetData& AssetData)
{
	int32 X = 0;
	int32 Y = 0;
	if (UBinkMediaPlayer* BinkMediaPlayer = Cast<UBinkMediaPlayer>(AssetData.GetAsset()))
	{
		BinkMediaPlayer->InitializePlayer();
		X = BinkMediaPlayer->GetDimensions().X;
		Y = BinkMediaPlayer->GetDimensions().Y;
	}
	TArray<FString> ReStr;
	ReStr.Add(FString::FromInt(X));
	ReStr.Add(FString::FromInt(Y));

	return FString::Join(ReStr, TEXT(","));
}

FString UBinkMediaPlayerRule::GetBinkMediaResolutionX(const FAssetData& AssetData)
{
	int32 X = 0;
	if (UBinkMediaPlayer* BinkMediaPlayer = Cast<UBinkMediaPlayer>(AssetData.GetAsset()))
	{
		BinkMediaPlayer->InitializePlayer();
		X = BinkMediaPlayer->GetDimensions().X;
	}
	return FString::FromInt(X);
}

FString UBinkMediaPlayerRule::GetBinkMediaResolutionY(const FAssetData& AssetData)
{
	int32 Y = 0;
	if (UBinkMediaPlayer* BinkMediaPlayer = Cast<UBinkMediaPlayer>(AssetData.GetAsset()))
	{
		BinkMediaPlayer->InitializePlayer();
		Y = BinkMediaPlayer->GetDimensions().Y;
	}
	return FString::FromInt(Y);
}

FString UBinkMediaPlayerRule::GetBinkMediaFPS(const FAssetData& AssetData)
{
	if (UBinkMediaPlayer* BinkMediaPlayer = Cast<UBinkMediaPlayer>(AssetData.GetAsset()))
	{
		BinkMediaPlayer->InitializePlayer();
		return FString::SanitizeFloat(BinkMediaPlayer->GetFrameRate());
	}
	return FString::FromInt(0);
}
