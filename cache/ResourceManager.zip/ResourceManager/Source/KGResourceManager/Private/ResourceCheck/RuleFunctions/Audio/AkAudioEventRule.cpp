#include "ResourceCheck/RuleFunctions/Audio/AkAudioEventRule.h"

#include "AkAudioEvent.h"

UClass* UAkAudioEventRule::GetAssetType()
{
	return UAkAudioEvent::StaticClass();
}

bool UAkAudioEventRule::CheckDuplicatedName(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	FARFilter Filter;
	Filter.ClassPaths.Add(UAkAudioEvent::StaticClass()->GetClassPathName());
	Filter.PackagePaths.Add(TEXT("/Game/Arts/Audio/"));
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	TArray<FAssetData> OutAssetData;
	AssetRegistry.GetAssets(Filter, OutAssetData);
	for (const FAssetData& AkAudioAssetData : OutAssetData)
	{
		if (AkAudioAssetData.AssetName == AssetData.AssetName && AkAudioAssetData.PackageName != AssetData.PackageName)
		{
			Log.RegistryAndLog(AssetData, TEXT("AkAudioEvent"), CheckRuleType,TEXT("Audiokinetic Event不能有重复的命名"));
			return false;
		}
	}
	return bSuccess;
}
