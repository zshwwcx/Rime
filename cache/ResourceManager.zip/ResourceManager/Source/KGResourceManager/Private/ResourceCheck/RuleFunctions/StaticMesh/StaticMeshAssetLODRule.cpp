#include "ResourceCheck/RuleFunctions/StaticMesh/StaticMeshAssetLODRule.h"
#include "StaticMeshEditorExtender.h"
#include "StaticMeshEditorExtenderManager.h"
#include "ResourceCheck/ResourceCheckHelper.h"

int32 UStaticMeshAssetLODRule::GetLodNum(const FAssetData& AssetData)
{
	FString LODs = FResourceCheckHelper::GetPropertyValueByName(AssetData, "LODs");
	return FCString::Atoi(*LODs);
}

bool UStaticMeshAssetLODRule::PreExecuteAsset(const FAssetData& AssetData)
{
	const int32 LODNum = GetLodNum(AssetData);
	if (LODNum < 1)
	{
		return false;
	}
	return true;
}

FString UStaticMeshAssetLODRule::GetNumTriangles(const FAssetData& AssetData)
{
	
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		const FStaticMeshRenderData* RenderData = StaticMesh->GetRenderData();
		const FStaticMeshLODResources& LODModel = RenderData->LODResources[0];
		const int32 NumTriangles = LODModel.GetNumTriangles();
		return FString::FromInt(NumTriangles);
	}
	return FString::FromInt(0);
}

bool UStaticMeshAssetLODRule::CheckLODScreenSize(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	const int32 LODNum = GetLodNum(AssetData);
	if (LODNum <= 1)
	{
		return true;
	}
	
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh->bAutoComputeLODScreenSize)
	{
		return true;
	}
	
	const FStaticMeshRenderData* RenderData = StaticMesh->GetRenderData();
	for (int32 i = 0; i < LODNum - 1; ++i)
	{
		const auto ScreenSize = RenderData->ScreenSize[i];
		const auto NextScreenSize = RenderData->ScreenSize[i + 1];
		if (ScreenSize.Default <= NextScreenSize.Default)
		{
			Log.RegistryAndLog(AssetData, TEXT("LODScreenSize"), CheckRuleType, TEXT("LOD{}的ScreenSize:{} 需要大于 LOD{}的ScreenSize:{}"), i, ScreenSize.Default, i + 1, NextScreenSize.Default);
			bSuccess = false;
		}
		else if ((ScreenSize.Default - NextScreenSize.Default) / NextScreenSize.Default < 0.1)
		{
			Log.RegistryAndLog(AssetData, TEXT("LODScreenSize"), CheckRuleType, TEXT("LOD{}的ScreenSize在LOD{}的ScreenSize的占比没有超过110%%"), i, ScreenSize.Default, i + 1, NextScreenSize.Default);
			bSuccess = false;
		}
	}

	return bSuccess;
}

bool UStaticMeshAssetLODRule::CheckLODHighFaceNum(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		const int32 LODNum = GetLodNum(AssetData);
		const FStaticMeshRenderData* RenderData = StaticMesh->GetRenderData();
		const FStaticMeshLODResources& LODModel = RenderData->LODResources[0];
		const int32 NumTriangles = LODModel.GetNumTriangles();
		if (Params.ParamList.Contains(TEXT("HighFaceNum"))
			&& Params.ParamList.Contains(TEXT("HighLodLevel")))
		{
			const int32 HighFaceNum = FCString::Atoi(*Params.GetValue(TEXT("HighFaceNum")));
			const int32 HighLodLevel = FCString::Atoi(*Params.GetValue(TEXT("HighLodLevel")));
			if (NumTriangles > HighFaceNum && LODNum < HighLodLevel)
			{
				Log.RegistryAndLog(AssetData, TEXT("Triangle"), CheckRuleType, TEXT("模型面数大于 {} 需要至少 {} 级 LOD"), HighFaceNum, HighLodLevel);
				bSuccess = false;
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetLODRule::CheckLODDecrementRate(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		const FStaticMeshRenderData* RenderData = StaticMesh->GetRenderData();
		const FStaticMeshLODResources& LODModel = RenderData->LODResources[0];
		const int32 NumTriangles = LODModel.GetNumTriangles();
		if (Params.ParamList.Contains(TEXT("DecrementRate")))
		{			
			const int32 LODNum = GetLodNum(AssetData);
			const int32 DecrementNum = FCString::Atoi(*Params.GetValue(TEXT("DecrementRate")));
			const float DecrementRate = (DecrementNum - 2) / 100.0f; // 数值减二，避免临界情况
			int32 LastTriangleNum = NumTriangles;
			for (int32 Index = 1; Index < LODNum; Index++)
			{
				const FStaticMeshLODResources& CurLODModel = RenderData->LODResources[Index];
				const int32 CurNumTriangles = CurLODModel.GetNumTriangles();
				if ((LastTriangleNum - CurNumTriangles) <= int32(DecrementRate * LastTriangleNum))
				{
					Log.RegistryAndLog(AssetData, TEXT("Triangle"), CheckRuleType, TEXT("每个 LOD 级别面数降低值需要高于 {} %%"), DecrementNum);
					bSuccess = false;
				}
				LastTriangleNum = CurNumTriangles;
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetLODRule::CheckLODByGroup(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	// 只检查 CheckPath 中的资源
	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		const int32 LODNum = StaticMesh->GetNumLODs();
		const FString CurLodGroup = StaticMesh->LODGroup.ToString();
		
		if (Params.ParamList.Contains(CurLodGroup))
		{
			const int32 LodLeastNum = FCString::Atoi(*Params.GetValue(CurLodGroup));
			if (LODNum < LodLeastNum)
			{
				Log.RegistryAndLog(AssetData, TEXT("LodGroup"), CheckRuleType, TEXT("LodGroup 为 {} 必须要至少 {} 级 LOD"), CurLodGroup, LodLeastNum);
				bSuccess = false;
			}
		}
		else if (CurLodGroup == "None")
		{
			Log.RegistryAndLog(AssetData, TEXT("LodGroup"), CheckRuleType, TEXT("LodGroup 不能为 None"));
			OutRepairParams.FindOrAdd(TEXT("LogGroup"), TEXT("Auto"));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetLODRule::CheckLODScreenSizeByGroup(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		const int32 LODNum = StaticMesh->GetNumLODs();
		const FString CurLodGroup = StaticMesh->LODGroup.ToString();

		TArray<FString> ContactPersonNames;
		if (GConfig)
		{
			FString MeshEditorIniPath = FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("StaticMeshEditorExtender/Config/MeshEditor.ini"));
			MeshEditorIniPath = FConfigCacheIni::NormalizeConfigIniPath(MeshEditorIniPath);

			IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
			if (PlatformFile.FileExists(*MeshEditorIniPath))
			{
				GConfig->Flush(true, *MeshEditorIniPath);

				const FStaticMeshRenderData* RenderData = StaticMesh->GetRenderData();
				for (int32 LodIndex = 0; LodIndex < LODNum; LodIndex++)
				{
					const auto ScreenSize = RenderData->ScreenSize[LodIndex];
					FString ScreenSizeKey = "LODScreenSize.LOD" + FString::FromInt(LodIndex);
					double StandardVal = 0.0;
					if (!GConfig->GetDouble(*CurLodGroup, *ScreenSizeKey, StandardVal, MeshEditorIniPath))
					{
						UE_LOG(LogTemp, Warning, TEXT("Can't Load ContactPersonNames from file : %s"), *MeshEditorIniPath);
						break;
					}

					// 浮点数可能不够精确，加个允许的误差值
					if (StandardVal - ScreenSize.Default > 0.00001f )
					{
						Log.RegistryAndLog(AssetData, TEXT("LodScreenSize"), CheckRuleType, TEXT("LodGroup 为 {} 的 Mesh 的 {} 需要大于等于 {}"), CurLodGroup, ScreenSizeKey, StandardVal);
						bSuccess = false;
					}
				}
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("Can't find file : %s"), *MeshEditorIniPath);
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetLODRule::RepairLODByGroup(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		FStaticMeshEditorExtenderModule* const StaticMeshExtenderModule = FModuleManager::Get().GetModulePtr<FStaticMeshEditorExtenderModule>("StaticMeshEditorExtender");
		TSharedPtr<FStaticMeshEditorExtenderManager> StaticMeshExtenderMgr = StaticMeshExtenderModule->Manager;

		if(!StaticMeshExtenderMgr || !StaticMeshExtenderMgr->ReadConfig())
		{
			UE_LOG(LogTemp, Error, TEXT("Can't Get StaticMeshExtenderManager."));
			return false;
		}
		
		StaticMeshExtenderMgr->AutoLODGroup(StaticMesh,false,true);
		StaticMeshExtenderMgr->FillLOD(StaticMesh, false, true);
		StaticMeshExtenderMgr->SetLODScreenSize(StaticMesh, false, true);
	}
	return bSuccess;
}

bool UStaticMeshAssetLODRule::RepairLODScreenSizeByGroup(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		FStaticMeshEditorExtenderModule* const StaticMeshExtenderModule = FModuleManager::Get().GetModulePtr<FStaticMeshEditorExtenderModule>("StaticMeshEditorExtender");
		TSharedPtr<FStaticMeshEditorExtenderManager> StaticMeshExtenderMgr = StaticMeshExtenderModule->Manager;

		if(!StaticMeshExtenderMgr || !StaticMeshExtenderMgr->ReadConfig())
		{
			UE_LOG(LogTemp, Error, TEXT("Can't Get StaticMeshExtenderManager."));
			return false;
		}
		
		StaticMeshExtenderMgr->SetLODScreenSize(StaticMesh, false, true);
	}
	return bSuccess;
}
