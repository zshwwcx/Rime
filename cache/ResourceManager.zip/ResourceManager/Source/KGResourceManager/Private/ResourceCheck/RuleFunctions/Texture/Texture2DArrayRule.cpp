#include "ResourceCheck/RuleFunctions/Texture/Texture2DArrayRule.h"

#include "EditorFramework/AssetImportData.h"
#include "Engine/Texture2DArray.h"
UClass* UTexture2DArrayRule::GetAssetType()
{
	return UTexture2DArray::StaticClass();
}

bool UTexture2DArrayRule::CheckSuffixDR(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto Texture2DArray = Cast<UTexture2DArray>(AssetData.GetAsset()))
	{
		for (auto SourceTexture : Texture2DArray->SourceTextures)
		{
			if (IsValid(SourceTexture))
			{
				if (!SourceTexture->GetName().EndsWith(TEXT("_DR")))
				{
					Log.RegistryAndLog(AssetData, TEXT("Texture2DArray"), CheckRuleType,
						TEXT("后缀为_DR的贴图数组中引用的贴图也需要有_DR后缀,{}贴图不符合规则"),
						SourceTexture->GetName());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool UTexture2DArrayRule::CheckSuffixNOH(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto Texture2DArray = Cast<UTexture2DArray>(AssetData.GetAsset()))
	{
		for (auto SourceTexture : Texture2DArray->SourceTextures)
		{
			if (IsValid(SourceTexture))
			{
				if (!SourceTexture->GetName().EndsWith(TEXT("_NOH")))
				{
					Log.RegistryAndLog(AssetData, TEXT("Texture2DArray"), CheckRuleType,
						TEXT("后缀为_NOH的贴图数组中引用的贴图也需要有_NOH后缀,{}贴图不符合规则"),
						SourceTexture->GetName());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}