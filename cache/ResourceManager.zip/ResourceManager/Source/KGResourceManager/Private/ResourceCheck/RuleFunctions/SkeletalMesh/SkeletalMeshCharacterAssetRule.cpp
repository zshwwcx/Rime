#include "ResourceCheck/RuleFunctions/SkeletalMesh/SkeletalMeshCharacterAssetRule.h"

#include "AssetBrowserExtensionSettings.h"
#include "HttpManager.h"
#include "HttpModule.h"
#include "KGAssetBrowserExtension.h"
#include "Rendering/SkeletalMeshRenderData.h"
#include "TagFilter/ContentTagClient.h"
#include "Utils/AvatarCreatorEditorConfig.h"
#include "Utils/AvatarCreatorProfileUtils.h"


bool USkeletalMeshCharacterAssetRule::bTagClientInitialized = false;

bool USkeletalMeshCharacterAssetRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	if (IsRunningCommandlet() && !bTagClientInitialized)
	{
		InitializeTagClient();
	}
	return Super::PreExecuteAllObject(InAssetDataList);
}

TArray<float> USkeletalMeshCharacterAssetRule::GetStats(const FAssetData& AssetData)
{
	const USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	if (SkeletalMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("SkeletalMesh is null"))
		return TArray<float>();
	}
	UAvatarCreatorEditorConfig::Initialize();
	FString PathName = SkeletalMesh->GetPathName();
	const FAvatarMeshStatsCache& Stats = FAvatarCreatorProfileUtils::GetAssetPathStats(PathName);
	return Stats.Stats;
}

FString USkeletalMeshCharacterAssetRule::GetStatTriangles(const FAssetData& AssetData)
{
	TArray<float> Stats = GetStats(AssetData);
	if (Stats.Num() < 1)
	{
		UE_LOG(LogTemp, Warning, TEXT("triangles stat is null"))
		return TEXT("0");
	}
	return FString::SanitizeFloat(Stats[0]);
}

FString USkeletalMeshCharacterAssetRule::GetStatDrawCall(const FAssetData& AssetData)
{
	TArray<float> Stats = GetStats(AssetData);
	if (Stats.Num() < 3)
	{
		UE_LOG(LogTemp, Warning, TEXT("triangles stat is null"))
		return TEXT("0");
	}
	return FString::SanitizeFloat(Stats[1]);
}

int32 USkeletalMeshCharacterAssetRule::GetTagIndex(const FAssetData& AssetData)
{
	const USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	if (SkeletalMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("SkeletalMesh is null"))
		return INDEX_NONE;
	}
	FKGAssetBrowserExtensionModule& Module = FModuleManager::Get().GetModuleChecked<FKGAssetBrowserExtensionModule>("KGAssetBrowserExtension");
	const TSharedRef<FContentTagClient> TagClient = Module.GetTagClient();
	const FString PathName = SkeletalMesh->GetPathName();
	const TSet<FName>& AllTags = TagClient->GetPackageTags(FName(PathName));
	const UEnum* Enum = StaticEnum<EAvatarPresetLevel>();
	const int64 MaxEnumValue = Enum->GetMaxEnumValue();
	for (int i = 0; i <= MaxEnumValue; i++)
	{
		FString DisplayNameText = Enum->GetDisplayNameTextByIndex(i).ToString();
		if (AllTags.Contains(FName(DisplayNameText)))
		{
			return Enum->GetValueByIndex(i) - 1;
		}
	}
	return INDEX_NONE;
}

FString USkeletalMeshCharacterAssetRule::GetStandardTriangles(const FAssetData& AssetData)
{
	const int32 TagIndex = GetTagIndex(AssetData);
	const TArray<FString>& StandardTriangles = Params.GetValueList(TEXT("StandardTriangles"));
	if (TagIndex >= 0 && TagIndex < StandardTriangles.Num())
	{
		return StandardTriangles[TagIndex];
	}
	return TEXT("0");
}

FString USkeletalMeshCharacterAssetRule::GetStandardDrawCall(const FAssetData& AssetData)
{
	const int32 TagIndex = GetTagIndex(AssetData);
	const TArray<FString>& StandardDrawCall = Params.GetValueList(TEXT("StandardDrawCall"));
	if (TagIndex >= 0 && TagIndex < StandardDrawCall.Num())
	{
		return StandardDrawCall[TagIndex];
	}
	return TEXT("0");
}

void USkeletalMeshCharacterAssetRule::InitializeTagClient()
{
	bTagClientInitialized = true;
	FKGAssetBrowserExtensionModule& Module = FModuleManager::Get().GetModuleChecked<FKGAssetBrowserExtensionModule>("KGAssetBrowserExtension");
	const TSharedRef<FContentTagClient> TagClient = Module.GetTagClient();
	FEvent* TagClientReadyEvent = FPlatformProcess::GetSynchEventFromPool(true);
	const FOnTagRequestResponse OnUpdateTagsCompleted = FOnTagRequestResponse::CreateLambda([TagClientReadyEvent](bool bSuccess)
	{
		TagClientReadyEvent->Trigger();
	});
	TagClient->RequestUpdateTagsByTime(TEXT("/Game/"), -1, 600, OnUpdateTagsCompleted);
	while (!TagClientReadyEvent->Wait(100))
	{
		FHttpModule::Get().GetHttpManager().Tick(0.1);
	}
	TagClientReadyEvent->Reset();
}
