#include "ResourceCheck/RuleFunctions/Actor/StaticMeshActorMobilityRule.h"

#include "Engine/StaticMeshActor.h"

UClass* UStaticMeshActorMobilityRule::GetAssetType()
{
	return AStaticMeshActor::StaticClass();
}

bool UStaticMeshActorMobilityRule::PreExecuteAsset(const FAssetData& AssetData)
{
	if (const AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if (Actor->IsEditorOnly())
		{
			return false;
		}
		if (Actor->FindComponentByClass(USceneComponent::StaticClass()) == nullptr)
		{
			return false;
		}
	}
	return true;
}

bool UStaticMeshActorMobilityRule::CheckMobility(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (const AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if (USceneComponent* RootComponent = Actor->GetRootComponent(); RootComponent != nullptr && RootComponent->Mobility != EComponentMobility::Static)
		{
			Log.RegistryAndLog(AssetData, TEXT("StaticMeshActor"), CheckRuleType,
									TEXT("StaticMeshActor的移动性只能为Static"));
			bSuccess = false;
		}
	}
	return bSuccess;
}
