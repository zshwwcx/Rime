#include "ResourceCheck/RuleFunctions/Avatar/MeshPartDefineRule.h"

#include "Asset/MeshPartCollection.h"

UClass* UMeshPartDefineRule::GetAssetType()
{
	return UMeshPartDefine::StaticClass();
}

bool UMeshPartDefineRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{

	FString RegexCheckPath = Params.GetValue("RegexCheckPath");
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	
	TArray<FAssetData> OutAssetDatas;
	FARFilter Filter;
	Filter.ClassPaths.Add(UMeshPartDefine::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	Filter.PackagePaths.Append(CheckPaths);
	AssetRegistry.GetAssets(Filter, OutAssetDatas);
	for (auto AssetData : OutAssetDatas)
	{
		TArray<FString> AssetNameTag;
		FString AssetName = AssetData.AssetName.ToString();
		FString AssetPath = AssetData.GetObjectPathString();
		
		AssetName.ParseIntoArray(AssetNameTag, TEXT("_"));
			
		if (AssetNameTag.Num() > 0)
		{
			FString PackageName = AssetData.PackageName.ToString();
			FString PackagePath = AssetData.PackagePath.ToString();
			FString PackagePrefix = PackagePath + "/";
			UniqueIDToPackageName.FindOrAdd(AssetNameTag[0]).Add(TTuple<FString, FString>(PackagePrefix, PackageName));
		}
	}
	FString MeshPartDefineIniPath = FConfigCacheIni::NormalizeConfigIniPath(FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("KGResourceManager/Config/MeshPartDefineRule.ini")));
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (PlatformFile.FileExists(*MeshPartDefineIniPath))
	{
		GConfig->Flush(true, *MeshPartDefineIniPath);
		GConfig->GetArray(TEXT("CanSkipEstimatePresetStatLevel"), TEXT("WhiteList"), CanSkipEstimatePresetStatLevelWhiteList, MeshPartDefineIniPath);
	}
	return true;
}

FString UMeshPartDefineRule::GetCanSkipEstimatePresetStatLevelWhiteList(const FAssetData& AssetData)
{
	return FString::Join(CanSkipEstimatePresetStatLevelWhiteList, TEXT(","));
}

bool UMeshPartDefineRule::IsMeshIDUnique(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TArray<FString> AssetNameTag;
	FString AssetName = AssetData.AssetName.ToString();
	AssetName.ParseIntoArray(AssetNameTag, TEXT("_"));

	if (AssetNameTag.Num() > 0)
	{
		auto PackageNames = UniqueIDToPackageName.Find(AssetNameTag[0]);
		if (PackageNames)
		{
			if (PackageNames->Num() > 1)
			{
				TArray <FString> NotUniquePackageStr;
				FString AssetDataPackagePrefix = TEXT("");
				for (auto PackagePair : *PackageNames)
				{
					FString PackagePrefix = PackagePair.Key;
					FString PackageName = PackagePair.Value;
					FString AssetDataPackageName = AssetData.PackageName.ToString();
					FString AssetDataObjectPath = AssetData.GetObjectPathString();
					if (AssetDataObjectPath.StartsWith(PackagePrefix) && AssetDataPackageName != PackageName)
					{
						NotUniquePackageStr.Add(PackageName);
					}
				}
				if (NotUniquePackageStr.Num() > 0)
				{
					Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("存在重复前缀ID的资源:{}"), FString::Join(NotUniquePackageStr, TEXT("\n")));
					bSuccess = false;
				}
			}
		}
		else
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("MeshPartDefine不存在前缀ID"));
			bSuccess = false;
		}
	}
	
	return bSuccess;
}

bool UMeshPartDefineRule::CheckSkeletalMesh(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto MeshPartDefine = Cast<UMeshPartDefine>(AssetData.GetAsset()))
	{
		if (!MeshPartDefine->GetSkeletalMesh())
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("MeshPartDefine资产引用的Skeletal Mesh资产不能为空"));
			bSuccess = false;
		}
	}	
	return bSuccess;
}

bool UMeshPartDefineRule::CheckSkeletalMeshPath(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto MeshPartDefine = Cast<UMeshPartDefine>(AssetData.GetAsset()))
	{
		if (USkeletalMesh* SkeletalMesh = MeshPartDefine->GetSkeletalMesh())
		{
			FString ValidPathKey = "SkeletalMeshValidPath";
			if (Params.ParamList.Contains(ValidPathKey))
			{
				FString ValidPath = Params.GetValue(ValidPathKey);
				if (!SkeletalMesh->GetPathName().StartsWith(ValidPath))
				{
					Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("Head MeshPartDefine资产引用的Skeletal Mesh资产必须位于{}下"), ValidPath);
					bSuccess = false;
				}
			}
		}
	}	
	return bSuccess;
}
