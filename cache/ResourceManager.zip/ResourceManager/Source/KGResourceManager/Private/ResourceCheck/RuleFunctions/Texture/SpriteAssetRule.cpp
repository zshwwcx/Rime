#include "ResourceCheck/RuleFunctions/Texture/SpriteAssetRule.h"

#include "PaperSpriteAtlas.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"
#include "ResourceCheck/ResourceCheckGlobalData.h"

UClass* USpriteAssetRule::GetAssetType()
{
	return UPaperSprite::StaticClass();
}

bool USpriteAssetRule::PreExecuteAsset(const FAssetData& AssetData)
{
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FName Name = AssetData.PackageName;
	AssetReferencers.Empty();
	AssetRegistryModule.Get().GetDependencies(Name, AssetReferencers, UE::AssetRegistry::EDependencyCategory::All);
	for (int32 i = 0; i < AssetReferencers.Num(); ++i)
	{
		TArray<FAssetData> OutAssetData;
		AssetRegistryModule.Get().GetAssetsByPackageName(AssetReferencers[i], OutAssetData);
		if(!OutAssetData.IsEmpty())
		{
			UObject* AssetInPackage = OutAssetData[0].GetAsset();
			if(UPaperSpriteAtlas* PaperSpriteAtlas = Cast<UPaperSpriteAtlas>(AssetInPackage))
			{
				NameToPaperSpriteAtlas.FindOrAdd(AssetReferencers[i]) = PaperSpriteAtlas;
			}
		}
	}
	return true;
}

bool USpriteAssetRule::IsUsedInLuaFile(const FString& PathName, const FString& SingleName)
{
	if (FResourceCheckGlobalData::SpriteAssetRuleLuaDatas.IsEmpty())
	{
		FResourceCheckGlobalData::LoadSpriteAssetRuleLuaDatas();
	}
	for(auto LuaData : FResourceCheckGlobalData::SpriteAssetRuleLuaDatas)
	{
	 	if(LuaData.Find(PathName) != INDEX_NONE || LuaData.Find(SingleName) != INDEX_NONE)
	 	{
	 		return true;
	 	}
	}
	return false;
}

FString USpriteAssetRule::HasReferenced(const FAssetData& AssetData)
{
	// 暂时不需要
	// bool bHasReference = false;
	// const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	// TArray<FName> Referencers;
	// AssetRegistryModule.Get().GetReferencers(AssetData.PackageName, Referencers, UE::AssetRegistry::EDependencyCategory::All);
	// for (int32 i = 0; i < Referencers.Num(); ++i)
	// {
	// 	TArray<FAssetData> OutAssetData;
	// 	AssetRegistryModule.Get().GetAssetsByPackageName(Referencers[i], OutAssetData);
	// 	if(!OutAssetData.IsEmpty())
	// 	{
	// 		UObject* AssetInPackage = OutAssetData[0].GetAsset();
	// 		if(!Cast<UPaperSpriteAtlas>(AssetInPackage))
	// 		{
	// 			bHasReference = true;
	// 			break;
	// 		}
	// 	}
	// }
	//
	// // 判断图是否有被lua的表格引用
	// if (!bHasReference && IsUsedInLuaFile(AssetData.PackagePath.ToString(), AssetData.AssetName.ToString()))
	// {
	// 	bHasReference = true;
	// }

	return FString::FromInt(1);
}

FString USpriteAssetRule::GetSourceDimensionX(const FAssetData& AssetData)
{
	UPaperSprite* PaperSprite = Cast<UPaperSprite>(AssetData.GetAsset());

	return FString::FromInt(int32(PaperSprite->GetSourceSize().X));
}

FString USpriteAssetRule::GetSourceDimensionY(const FAssetData& AssetData)
{
	UPaperSprite* PaperSprite = Cast<UPaperSprite>(AssetData.GetAsset());

	return FString::FromInt(int32(PaperSprite->GetSourceSize().Y));
}

FString USpriteAssetRule::GetAtlasDimensionX(const FAssetData& AssetData)
{
	// 返回引用该Sprite的图集的最大尺寸
	for (int32 i = 0; i < AssetReferencers.Num(); ++i)
	{
		if(NameToPaperSpriteAtlas.Contains(AssetReferencers[i]))
		{
			return FString::FromInt(NameToPaperSpriteAtlas[AssetReferencers[i]]->MaxWidth);
		}
	}

	// 如果没被图集引用，返回一个值让他始终通过检查
	return FString::FromInt(40960);
}

FString USpriteAssetRule::GetAtlasDimensionY(const FAssetData& AssetData)
{
	// 返回引用该Sprite的图集的最大尺寸
	for (int32 i = 0; i < AssetReferencers.Num(); ++i)
	{
		if(NameToPaperSpriteAtlas.Contains(AssetReferencers[i]))
		{
			return FString::FromInt(NameToPaperSpriteAtlas[AssetReferencers[i]]->MaxHeight);
		}
	}

	// 如果没被图集引用，返回一个值让他始终通过检查
	return FString::FromInt(40960);
}
