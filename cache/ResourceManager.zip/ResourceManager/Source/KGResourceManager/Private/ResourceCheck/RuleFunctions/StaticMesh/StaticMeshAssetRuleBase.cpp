#include "ResourceCheck/RuleFunctions/StaticMesh/StaticMeshAssetRuleBase.h"

#include "RawMesh.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"
#include "StaticMeshAttributes.h"
#include "PhysicsEngine/BodySetup.h"

UClass* UStaticMeshAssetRuleBase::GetAssetType()
{
	return UStaticMesh::StaticClass();
}

bool UStaticMeshAssetRuleBase::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{

	return true;
}

FString UStaticMeshAssetRuleBase::IsFoliageMaterial(const FAssetData& AssetData)
{
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		TArray<FString> FoliageMaterials;
		if (GConfig)
		{
			FString MeshEditorIniPath = FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("StaticMeshEditorExtender/Config/MeshEditor.ini"));
			MeshEditorIniPath = FConfigCacheIni::NormalizeConfigIniPath(MeshEditorIniPath);

			IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
			if (PlatformFile.FileExists(*MeshEditorIniPath))
			{
				GConfig->Flush(true, *MeshEditorIniPath);

				if (GConfig->GetArray(TEXT("Foliage"), TEXT("Material"), FoliageMaterials, MeshEditorIniPath))
				{
					TArray<FStaticMaterial>& StaticMaterials = StaticMesh->GetStaticMaterials();
					for (int32 i = 0; i < StaticMaterials.Num(); ++i)
					{
						if (UMaterialInterface* MatInterface = StaticMaterials[i].MaterialInterface.Get())
						{
							if (UMaterial* Material = MatInterface->GetMaterial())
							{
								if (FoliageMaterials.Contains(Material->GetPathName()))
								{
									return "1";
								}
							}
						}
					}
				}
				else
				{
					UE_LOG(LogTemp, Warning, TEXT("Can't Load Material Name Array from file : %s"), *MeshEditorIniPath);
				}
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("Can't find file : %s"), *MeshEditorIniPath);
			}
		}
	}
	return "0";
}

FString UStaticMeshAssetRuleBase::GetMaterialNum(const FAssetData& AssetData)
{
	auto StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	auto RetVal = StaticMesh->GetStaticMaterials().Num();
	return FString::FromInt(RetVal);
}

FString UStaticMeshAssetRuleBase::GetMaterialNames(const FAssetData& AssetData)
{
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogKGResourceManager, Warning, TEXT("Can't find StaticMesh"));
		return TEXT("");
	}
	TArray<FStaticMaterial>& StaticMaterials = StaticMesh->GetStaticMaterials();
	TArray<FString> MaterialNames;
	for (int32 i = 0; i < StaticMaterials.Num(); ++i)
	{
		if (UMaterialInterface* MatInterface = StaticMaterials[i].MaterialInterface.Get())
		{
			if (UMaterial* Material = MatInterface->GetMaterial())
			{
				MaterialNames.AddUnique(Material->GetName());
			}
		}
	}
	return FString::Join(MaterialNames, TEXT(","));
}

FString UStaticMeshAssetRuleBase::GetApproxiSizeX(const FAssetData& AssetData)
{
	if(auto StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		if (const UBodySetup* BodySetup = StaticMesh->GetBodySetup())
		{
			return FString::FromInt(StaticMesh->GetBounds().BoxExtent.X * 2.0f);
		}
	}
	return FString::FromInt(0.0f);
}

FString UStaticMeshAssetRuleBase::GetApproxiSizeY(const FAssetData& AssetData)
{
	if(auto StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		if (const UBodySetup* BodySetup = StaticMesh->GetBodySetup())
		{
			return FString::FromInt(StaticMesh->GetBounds().BoxExtent.Y * 2.0f);
		}
	}
	return FString::FromInt(0.0f);
}

FString UStaticMeshAssetRuleBase::GetApproxiSizeZ(const FAssetData& AssetData)
{
	if(auto StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		if (const UBodySetup* BodySetup = StaticMesh->GetBodySetup())
		{
			return FString::FromInt(StaticMesh->GetBounds().BoxExtent.Z * 2.0f);
		}
	}
	return FString::FromInt(0.0f);
}

FString UStaticMeshAssetRuleBase::GetApproxiVolume(const FAssetData& AssetData)
{
	if(auto StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		if (const UBodySetup* BodySetup = StaticMesh->GetBodySetup())
		{
			const double SizeX = StaticMesh->GetBounds().BoxExtent.X * 2.0f;
			const double SizeY = StaticMesh->GetBounds().BoxExtent.Y * 2.0f;
			const double SizeZ = StaticMesh->GetBounds().BoxExtent.Z * 2.0f;
			return FString::SanitizeFloat(SizeX * SizeY * SizeZ);
		}
	}
	return FString::SanitizeFloat(0.0);
}

FString UStaticMeshAssetRuleBase::GetTriangles(const FAssetData& AssetData)
{
	FString Triangles = FResourceCheckHelper::GetPropertyValueByName(AssetData, "Triangles");
	return Triangles;
}

FString UStaticMeshAssetRuleBase::GetRawMeshTriangles(const FAssetData& AssetData)
{
	const UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		return TEXT("0");
	}
	int32 TriangleCount = 0;
	if (FMeshDescription* MeshDescription = StaticMesh->GetMeshDescription(0))
	{
		for (FPolygonGroupID PolygonGroupID : MeshDescription->PolygonGroups().GetElementIDs())
		{
			const TArrayView<const FTriangleID>& TriangleIDs = MeshDescription->GetPolygonGroupTriangles(PolygonGroupID);
			TriangleCount += TriangleIDs.Num();
		}
	}
	return FString::FromInt(TriangleCount);
}

FString UStaticMeshAssetRuleBase::GetNumLODs(const FAssetData& AssetData)
{
	const UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		return TEXT("0");
	}
	return FString::FromInt(StaticMesh->GetNumLODs());
}

FString UStaticMeshAssetRuleBase::GetNumUVChannels(const FAssetData& AssetData)
{
	const UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		return TEXT("0");
	}
	if (StaticMesh->GetRenderData() && StaticMesh->GetRenderData()->LODResources.Num() > 0)
	{
		const FStaticMeshLODResources& LOD = StaticMesh->GetRenderData()->LODResources[0];
		int32 NumUVChannels = LOD.VertexBuffers.StaticMeshVertexBuffer.GetNumTexCoords();
		return FString::FromInt(NumUVChannels);
	}
	return TEXT("0");
}

bool UStaticMeshAssetRuleBase::RepairNumUVChannels(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find StaticMesh From AssetData: %s"), *AssetData.PackageName.ToString())
		return false;
	}
	if (StaticMesh->GetRenderData() && StaticMesh->GetRenderData()->LODResources.Num() > 0)
	{
		const FStaticMeshLODResources& LOD = StaticMesh->GetRenderData()->LODResources[0];
		int32 NumUVChannels = LOD.VertexBuffers.StaticMeshVertexBuffer.GetNumTexCoords();
		if (InRepairParams.Contains(TEXT("GetNumUVChannels")))
		{
			int32 ValidNumUVChannels = FCString::Atoi(*InRepairParams[TEXT("GetNumUVChannels")]);
			for (int32 i = NumUVChannels; i > ValidNumUVChannels; --i)
			{
				StaticMesh->RemoveUVChannel(0, i - 1);
			}
			StaticMesh->Modify();
			StaticMesh->GetPackage()->MarkPackageDirty();
			return true;
		}
	}
	return false;
}

bool UStaticMeshAssetRuleBase::CheckCollisionValid(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (!Params.ParamList.Contains(TEXT("CollisionSizeDiff")))
	{
		return bSuccess;
	}
	const UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (const UBodySetup* BodySetup = StaticMesh->GetBodySetup())
	{
		FTransform LocalToWorld;
		FBoxSphereBounds AggGeomBounds;
		BodySetup->AggGeom.CalcBoxSphereBounds(AggGeomBounds, LocalToWorld);
		const FBoxSphereBounds StaticMeshBounds = StaticMesh->GetBounds();
		const FVector SMBoundsSize = StaticMeshBounds.GetBox().GetSize();
		const FBox CollisionBox = BodySetup->AggGeom.CalcAABB(LocalToWorld);
		const FVector CollisionBoxSize = CollisionBox.GetSize();
		float MinCheckLength = 100.f;
		const float CollisionSizeDiff = FCString::Atof(*Params.GetValue(TEXT("CollisionSizeDiff")));
		// 只判断X和Y轴的大小，Z轴有时候会特意加高碰撞
		if ((SMBoundsSize.X > 0 && CollisionBoxSize.X > MinCheckLength && CollisionBoxSize.X / SMBoundsSize.X > CollisionSizeDiff)
			|| (SMBoundsSize.Y > 0 && CollisionBoxSize.Y > MinCheckLength && CollisionBoxSize.Y / SMBoundsSize.Y > CollisionSizeDiff))
		{
			Log.RegistryAndLog(AssetData, TEXT("CollisionDiff"), CheckRuleType, TEXT("碰撞包围盒不能超过网格包围盒的{}倍"), CollisionSizeDiff);
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetRuleBase::CheckMaterialFlag(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		if (StaticMesh->NaniteSettings.bEnabled)
		{
			TArray<FStaticMaterial>& StaticMaterials = StaticMesh->GetStaticMaterials();
			TSet<UMaterial*> Materials;
			const TArray<FString>& MaterialFlagExcludedNames = Params.GetValueList(TEXT("MaterialFlagExcludedNames"));
			for (int32 i = 0; i < StaticMaterials.Num(); ++i)
			{
				if (UMaterialInterface* MatInterface = StaticMaterials[i].MaterialInterface.Get())
				{
					if (UMaterial* Material = MatInterface->GetMaterial())
					{
						if (MaterialFlagExcludedNames.Contains(Material->GetPathName()))
						{
							continue;
						}
						// 做一下去重处理，引用了相同的材质，只做一次判断
						if (!Materials.Contains(Material))
						{
							Materials.Add(Material);
							if (!Material->GetUsageByFlag(EMaterialUsage::MATUSAGE_Nanite))
							{
								Log.RegistryAndLog(AssetData, TEXT("StaticMesh"), CheckRuleType, TEXT("StaticMesh 是开启 Nanite 的，但是使用了非 Nanite 的材质：{}"),
									Material->GetFName().ToString());
								bSuccess = false;
							}
							else if (Material->GetPackage()->IsDirty())
							{
								Log.RegistryAndLog(AssetData, TEXT("StaticMesh"), CheckRuleType, TEXT("StaticMesh 是开启 Nanite 的，使用的材质：{} 已自动勾选上Nanite，但没有保存，请查看未保存列表保存后一并提交"),
									Material->GetFName().ToString());
								bSuccess = false;
							}
						}
					}
				}
				else
				{
					UE_LOG(LogTemp, Warning, TEXT("Can not get the material of Static Mesh: %s"), *AssetData.PackageName.ToString());
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetRuleBase::CheckMaterialUsedWithNanite(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (const UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		if (StaticMesh->NaniteSettings.bEnabled)
		{
			const TArray<FString> WhiteNaniteMaterialNames = Params.GetValueList(TEXT("WhiteNaniteMaterialNames"));
			const TArray<FStaticMaterial>& StaticMaterials = StaticMesh->GetStaticMaterials();
			for (const FStaticMaterial& StaticMaterial : StaticMaterials)
			{
				if (UMaterialInterface* MatInterface = StaticMaterial.MaterialInterface)
				{
					if (const UMaterial* Material = MatInterface->GetMaterial())
					{
						if (!Material->bUsedWithNanite)
						{
							if (!WhiteNaniteMaterialNames.Contains(MatInterface->GetPathName()))
							{
								Log.RegistryAndLog(AssetData, TEXT("StaticMesh"), CheckRuleType, TEXT("材质实例{}检测不到支持Nanite的材质，需要改用支持Nanite的中继材质"), MatInterface->GetName());
								bSuccess = false;
							}
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetRuleBase::CheckLodScreenSizeZero(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset()))
	{
		const int32 LODNum = StaticMesh->GetNumLODs();
		const FStaticMeshRenderData* RenderData = StaticMesh->GetRenderData();
		for (int32 LodIndex = 0; LodIndex < LODNum; LodIndex++)
		{
			const auto ScreenSize = RenderData->ScreenSize[LodIndex];
			FString ScreenSizeKey = "LODScreenSize.LOD" + FString::FromInt(LodIndex);
			if (ScreenSize.Default == 0)
			{
				Log.RegistryAndLog(AssetData, TEXT("LodScreenSize"), CheckRuleType, TEXT("Mesh 的 {} 不能等于0"), ScreenSizeKey);
				bSuccess = false;
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetRuleBase::CheckAutoGenerateLightmapUVClosed(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogKGResourceManager, Warning, TEXT("Can't find StaticMesh"));
		return bSuccess;
	}
	for (int32 LodIndex = 0; LodIndex < StaticMesh->GetNumSourceModels(); ++LodIndex)
	{
		FStaticMeshSourceModel& SourceModel = StaticMesh->GetSourceModel(LodIndex);
		if (StaticMesh->IsMeshDescriptionValid(LodIndex))
		{
			if (SourceModel.BuildSettings.bGenerateLightmapUVs == true)
			{
				Log.RegistryAndLog(AssetData, TEXT("StaticMeshLightmapUV"), CheckRuleType, TEXT("Mesh的LOD{}需要关闭自动生成lightmapUV"), LodIndex);
				bSuccess = false;
				if (!OutRepairParams.Contains(TEXT("LightmapUV")))
				{
					OutRepairParams.Add(TEXT("LightmapUV"), TEXT("1"));
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetRuleBase::RepairAutoGenerateLightmapUVClosed(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find StaticMesh From AssetData: %s"), *AssetData.PackageName.ToString())
		return false;
	}
	if (InRepairParams.Contains(TEXT("LightmapUV")))
	{
		for (int32 LodIndex = 0; LodIndex < StaticMesh->GetNumSourceModels(); ++LodIndex)
		{
			FStaticMeshSourceModel& SourceModel = StaticMesh->GetSourceModel(LodIndex);
			if (StaticMesh->IsMeshDescriptionValid(LodIndex))
			{
				SourceModel.BuildSettings.bGenerateLightmapUVs = false;
			}
		}
		StaticMesh->Modify();
		StaticMesh->GetPackage()->MarkPackageDirty();
		return true;
	}
	return false;
}

bool UStaticMeshAssetRuleBase::CheckNanitedStaticMeshMinLOD(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find StaticMesh From AssetData: %s"), *AssetData.PackageName.ToString())
		return bSuccess;
	}
	if (!StaticMesh->IsNaniteEnabled())
	{
		return bSuccess;
	}
	const FPerPlatformInt& MinLOD = StaticMesh->GetMinLOD();
	TSet<FName> PerPlatformKeys;
	MinLOD.PerPlatform.GetKeys(PerPlatformKeys);
	if (PerPlatformKeys.Num() > 1 || (PerPlatformKeys.Num() == 1 && !PerPlatformKeys.Contains(TEXT("Mobile"))))
	{
		Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("开启了Nanite的StaticMesh不允许设置除MinimumLOD、Mobile LOD之外的Min LOD"));
		OutRepairParams.Add(TEXT("MinimumLOD"), TEXT("1"));
		bSuccess = false;
	}
	if (MinLOD.PerPlatform.Find(TEXT("Mobile")) != nullptr)
	{
		int32 MobileMinLOD = StaticMesh->GetMinLOD().GetValueForPlatform(TEXT("Mobile"));
		if (StaticMesh->GetMinLOD().GetDefault() != MobileMinLOD)
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("开启了Nanite的StaticMesh若设置了Mobile MinLod，需要保持MinLod的默认值和Mobile一致"));
			OutRepairParams.Add(TEXT("DefaultMinLOD"), FString::FromInt(MobileMinLOD));
			bSuccess = false;
		}
	}
	else if (MinLOD.Default == 0)
	{
		if (StaticMesh->NaniteSettings.FallbackTarget != ENaniteFallbackTarget::PercentTriangles || StaticMesh->NaniteSettings.FallbackPercentTriangles < 1.f)
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("开启了Nanite的StaticMesh若未设置Minimum LOD或Mobile MinLod，需要将Fallback设为Percent Triangles模式，并设为100%"));
			OutRepairParams.Add(TEXT("FallbackTarget"), TEXT("Percent Triangles"));
			bSuccess = false;
		}
	}
	if (MinLOD.PerPlatform.Find(TEXT("Mobile")) != nullptr || MinLOD.Default > 0)
	{
		if (StaticMesh->NaniteSettings.FallbackTarget != ENaniteFallbackTarget::Auto)
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("开启了Nanite的StaticMesh若设置了Minimum LOD或Mobile MinLod大于等于1，需要将Fallback设为Auto"));
			OutRepairParams.Add(TEXT("FallbackTargetAuto"), TEXT("Auto"));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UStaticMeshAssetRuleBase::RepairNanitedStaticMeshMinLOD(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find StaticMesh From AssetData: %s"), *AssetData.PackageName.ToString())
		return false;
	}
	bool bRepaired = false;
	if (InRepairParams.Contains(TEXT("MinimumLOD")))
	{
		FPerPlatformInt MinLOD = StaticMesh->GetMinLOD();
		TSet<FName> PerPlatformKeys;
		MinLOD.PerPlatform.GetKeys(PerPlatformKeys);
		for (FName Key : PerPlatformKeys)
		{
			if (Key != TEXT("Mobile"))
			{
				MinLOD.PerPlatform.Remove(Key);
			}
		}
		StaticMesh->SetMinLOD(MinLOD);
		bRepaired = true;
	}
	if (InRepairParams.Contains(TEXT("DefaultMinLOD")))
	{
		int32 DefaultMinLod = FCString::Atoi(*InRepairParams[TEXT("DefaultMinLOD")]);
		FPerPlatformInt MinLOD = StaticMesh->GetMinLOD();
		MinLOD.Default = DefaultMinLod;
		StaticMesh->SetMinLOD(MinLOD);
		bRepaired = true;
	}
	if (InRepairParams.Contains(TEXT("FallbackTargetAuto")))
	{
		StaticMesh->NaniteSettings.FallbackTarget = ENaniteFallbackTarget::Auto;
		bRepaired = true;
	}
	if (InRepairParams.Contains(TEXT("FallbackTarget")))
	{
		StaticMesh->NaniteSettings.FallbackTarget = ENaniteFallbackTarget::PercentTriangles;
		StaticMesh->NaniteSettings.FallbackPercentTriangles = 1.f;
		bRepaired = true;
	}
	if (bRepaired)
	{
		StaticMesh->Modify();
		StaticMesh->GetPackage()->MarkPackageDirty();
	}
	return true;
}

bool UStaticMeshAssetRuleBase::CheckHighTriangleNanitedStaticMeshMinLOD(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find StaticMesh From AssetData: %s"), *AssetData.PackageName.ToString())
		return bSuccess;
	}
	if (!StaticMesh->IsNaniteEnabled())
	{
		return bSuccess;
	}
	const FPerPlatformInt& MinLOD = StaticMesh->GetMinLOD();
	const int32 NumTris = FCString::Atoi(*GetRawMeshTriangles(AssetData));
	const int32 NaniteHighTriangleNum = FCString::Atoi(*Params.GetValue(TEXT("NaniteHighTriangleNum")));
	if (NumTris > NaniteHighTriangleNum && MinLOD.Default == 0)
	{
		Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("开启了Nanite且面数大于{}的StaticMesh需要设置MinimumLOD等于1"), NaniteHighTriangleNum);
		OutRepairParams.Add(TEXT("HighTriangleDefaultMinLOD"), TEXT("1"));
		bSuccess = false;
	}
	return bSuccess;
}

bool UStaticMeshAssetRuleBase::RepairHighTriangleNanitedStaticMeshMinLOD(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find StaticMesh From AssetData: %s"), *AssetData.PackageName.ToString())
		return false;
	}
	if (InRepairParams.Contains(TEXT("HighTriangleDefaultMinLOD")))
	{
		FPerPlatformInt MinLOD = StaticMesh->GetMinLOD();
		MinLOD.Default = 1;
		StaticMesh->SetMinLOD(MinLOD);
		StaticMesh->Modify();
		StaticMesh->GetPackage()->MarkPackageDirty();
		return true;
	}
	return false;
}

bool UStaticMeshAssetRuleBase::CheckNonNanitedStaticMeshMinLOD(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find StaticMesh From AssetData: %s"), *AssetData.PackageName.ToString())
		return bSuccess;
	}
	if (StaticMesh->IsNaniteEnabled())
	{
		return bSuccess;
	}
	const FPerPlatformInt& MinLOD = StaticMesh->GetMinLOD();
	TSet<FName> PerPlatformKeys;
	MinLOD.PerPlatform.GetKeys(PerPlatformKeys);
	if (PerPlatformKeys.Num() > 1 || (PerPlatformKeys.Num() == 1 && !PerPlatformKeys.Contains(TEXT("Mobile"))))
	{
		Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("未开启Nanite的StaticMesh不允许设置除MinimumLOD、Mobile LOD之外的Min LOD"));
		OutRepairParams.Add(TEXT("MinimumLOD"), TEXT("1"));
		bSuccess = false;
	}
	if (MinLOD.PerPlatform.Find(TEXT("Mobile")) != nullptr)
	{
		int32 MobileMinLOD = StaticMesh->GetMinLOD().GetValueForPlatform(TEXT("Mobile"));
		if (MobileMinLOD >= StaticMesh->GetNumLODs())
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("未开启Nanite的StaticMesh如果设置了Min mobile，则mobile需小于等于Lodnum-1"));
			OutRepairParams.Add(TEXT("MobileMinLOD"), FString::FromInt(StaticMesh->GetNumLODs() - 1));
			bSuccess = false;
		}
	}
	if (MinLOD.Default > 0)
	{
		Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("未开启Nanite的StaticMesh其MinimumLOD必须设置为0"));
		OutRepairParams.Add(TEXT("DefaultMinLOD"), TEXT("0"));
		bSuccess = false;
	}
	return bSuccess;
}

bool UStaticMeshAssetRuleBase::RepairNonNanitedStaticMeshMinLOD(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find StaticMesh From AssetData: %s"), *AssetData.PackageName.ToString())
		return false;
	}
	bool bRepaired = false;
	if (InRepairParams.Contains(TEXT("MinimumLOD")))
	{
		FPerPlatformInt MinLOD = StaticMesh->GetMinLOD();
		TSet<FName> PerPlatformKeys;
		MinLOD.PerPlatform.GetKeys(PerPlatformKeys);
		for (FName Key : PerPlatformKeys)
		{
			if (Key != TEXT("Mobile"))
			{
				MinLOD.PerPlatform.Remove(Key);
			}
		}
		StaticMesh->SetMinLOD(MinLOD);
		bRepaired = true;
	}
	if (InRepairParams.Contains(TEXT("DefaultMinLOD")))
	{
		int32 DefaultMinLod = FCString::Atoi(*InRepairParams[TEXT("DefaultMinLOD")]);
		FPerPlatformInt MinLOD = StaticMesh->GetMinLOD();
		MinLOD.Default = DefaultMinLod;
		StaticMesh->SetMinLOD(MinLOD);
		bRepaired = true;
	}
	if (InRepairParams.Contains(TEXT("MobileMinLOD")))
	{
		int32 MobileMinLOD = FCString::Atoi(*InRepairParams[TEXT("MobileMinLOD")]);
		FPerPlatformInt MinLOD = StaticMesh->GetMinLOD();
		MinLOD.PerPlatform[TEXT("Mobile")] = MobileMinLOD;
		StaticMesh->SetMinLOD(MinLOD);
		bRepaired = true;
	}
	if (bRepaired)
	{
		StaticMesh->Modify();
		StaticMesh->GetPackage()->MarkPackageDirty();
	}
	return bRepaired;
}

bool UStaticMeshAssetRuleBase::CheckMixedOpacityMaterials(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (StaticMesh == nullptr)
	{
		UE_LOG(LogKGResourceManager, Warning, TEXT("Can't find StaticMesh"));
		return bSuccess;
	}
	bool bHasOpaqueMaterial = false;
	bool bHasTranslucentMaterial = false;
	const TArray<FStaticMaterial>& StaticMaterials = StaticMesh->GetStaticMaterials();
	for (int32 i = 0; i < StaticMaterials.Num(); ++i)
	{
		if (UMaterialInterface* MatInterface = StaticMaterials[i].MaterialInterface.Get())
		{
			if (UMaterial* Material = MatInterface->GetMaterial())
			{
				const EBlendMode& BlendMode = Material->GetBlendMode();
				if (BlendMode == EBlendMode::BLEND_Opaque)
				{
					bHasOpaqueMaterial = true;
				}
				else
				{
					bHasTranslucentMaterial = true;
				}
			}
		}
	}
	if (bHasOpaqueMaterial && bHasTranslucentMaterial)
	{
		Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("场景模型不能同时包含半透明和不透明材质"));
		bSuccess = false;
	}
	return bSuccess;
}
