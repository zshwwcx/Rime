#include "ResourceCheck/RuleFunctions/Texture/MakeupTextureRule.h"

#include "ISourceControlModule.h"
#include "SourceControlHelpers.h"
#include "TextureCompiler.h"
#include "SourceControlOperations.h"

bool UMakeupTextureRule::PreExecuteAsset(const FAssetData& AssetData)
{
	bNeedCheck = false;
	FString MakeupTextureIniPath = FConfigCacheIni::NormalizeConfigIniPath(FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("KGResourceManager/Config/MakeupTextureRule.ini")));

	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (PlatformFile.FileExists(*MakeupTextureIniPath))
	{
		GConfig->Flush(true, *MakeupTextureIniPath);
		TArray<FString> Matchers;
		GConfig->GetArray(TEXT("NamingStandard"), TEXT("Matchers"), Matchers, MakeupTextureIniPath);
		FString PackageName = AssetData.AssetName.ToString();
		FString TextureType;
		for (int32 i = 0; i < Matchers.Num(); i++)
		{
			FString NamingType, PatternString;
			Matchers[i].Split("=", &NamingType, &PatternString);
			PatternString = PatternString.Mid(1, PatternString.Len() - 2);
			FRegexPattern Pattern(PatternString);
			FRegexMatcher Matcher(Pattern, PackageName);
			if (Matcher.FindNext())
			{
				TextureType = NamingType;
				bNeedCheck = true;
				break;
			}
		}
		if (bNeedCheck)
		{
			MakeupTextureStandard.MaxInGame = GConfig->GetStr(*TextureType, TEXT("MaxInGame"), MakeupTextureIniPath);
			MakeupTextureStandard.TextureGroup = GConfig->GetStr(*TextureType, TEXT("TextureGroup"), MakeupTextureIniPath);
			MakeupTextureStandard.MipGenSetting = GConfig->GetStr(*TextureType, TEXT("MipGenSetting"), MakeupTextureIniPath);
			MakeupTextureStandard.CompressionSettings = GConfig->GetStr(*TextureType, TEXT("CompressionSettings"), MakeupTextureIniPath);
			MakeupTextureStandard.SRGB = GConfig->GetStr(*TextureType, TEXT("SRGB"), MakeupTextureIniPath);
			MakeupTextureStandard.Alpha = GConfig->GetStr(*TextureType, TEXT("Alpha"), MakeupTextureIniPath);
			if (UTexture* Texture = Cast<UTexture>(AssetData.GetAsset()))
			{
				FTextureCompilingManager::Get().FinishCompilation({Texture});
			}
		}
	}
	return true;
}

FString UMakeupTextureRule::IsNeedCheck(const FAssetData& AssetData)
{
	return bNeedCheck ? "1" : "0";
}

FString UMakeupTextureRule::GetHasAlphaChannel(const FAssetData& AssetData)
{
	if (UTexture2D* Texture2D = Cast<UTexture2D>(AssetData.GetAsset()))
	{
		return Texture2D->HasAlphaChannel() ? "true" : "false";
	}
	return "false";
}

FString UMakeupTextureRule::GetStandMaxInGame(const FAssetData& AssetData)
{
	return MakeupTextureStandard.MaxInGame;
}

FString UMakeupTextureRule::GetStandTextureGroup(const FAssetData& AssetData)
{
	return MakeupTextureStandard.TextureGroup;
}

FString UMakeupTextureRule::GetStandMipGenSetting(const FAssetData& AssetData)
{
	return MakeupTextureStandard.MipGenSetting;
}

FString UMakeupTextureRule::GetStandCompressionSettings(const FAssetData& AssetData)
{
	return MakeupTextureStandard.CompressionSettings;
}

FString UMakeupTextureRule::GetStandSRGB(const FAssetData& AssetData)
{
	return MakeupTextureStandard.SRGB;
}

FString UMakeupTextureRule::GetStandAlpha(const FAssetData& AssetData)
{
	return MakeupTextureStandard.Alpha;
}

bool UMakeupTextureRule::CheckPairedAssetCommit(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	FString PathA = TEXT("/Game/Arts/Character/Makeup/Texture/");
	FString PathB = TEXT("/Game/Arts/Character/Makeup/ClippedTexture/");
	const FString PackageName = AssetData.PackageName.ToString();
	const bool bStartsWithPathA = PackageName.StartsWith(PathA);
	const bool bStartsWithPathB = PackageName.StartsWith(PathB);
	if (!bStartsWithPathA && !bStartsWithPathB)
	{
		return true;
	}
	FString PairedPackageName;
	if (bStartsWithPathA)
	{
		PairedPackageName = FPaths::Combine(PathB, PackageName.Right(PackageName.Len() - PathA.Len()));
	}
	else
	{
		PairedPackageName = FPaths::Combine(PathA, PackageName.Right(PackageName.Len() - PathB.Len()));
	}
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	const FString SourceFileName = USourceControlHelpers::PackageFilename(PackageName);
	FSourceControlStatePtr SourceFileState = SourceControlProvider.GetState(SourceFileName, EStateCacheUsage::ForceUpdate);
	if (!SourceFileState->IsCheckedOut() && !SourceFileState->IsAdded())
	{
		return true;
	}
	const FString PairedFileName = USourceControlHelpers::PackageFilename(PairedPackageName);
	FSourceControlStatePtr PairedFileState = SourceControlProvider.GetState(PairedFileName, EStateCacheUsage::ForceUpdate);
	if (PairedFileState->IsCheckedOut() || PairedFileState->IsAdded())
	{
		const FString SourceChangeListID = SourceFileState->GetCheckInIdentifier()->GetIdentifier();
		const FString PairedChangeListID = PairedFileState->GetCheckInIdentifier()->GetIdentifier();
		if (SourceChangeListID == PairedChangeListID)
		{
			return true;
		}
	}
	Log.RegistryAndLog(AssetData,TEXT("SubmitCheck"), ERMCheckRuleType::Error, TEXT("需要同时提交同名文件：{}"), PairedPackageName);
	return false;
}
