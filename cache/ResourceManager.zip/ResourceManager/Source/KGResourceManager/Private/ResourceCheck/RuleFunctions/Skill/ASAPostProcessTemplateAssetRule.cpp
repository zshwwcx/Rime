#include "ResourceCheck/RuleFunctions/Skill/ASAPostProcessTemplateAssetRule.h"

#include "KGAbilitySystemEditor/AbilityEditor/Ability/ASAPostProcessTemplateAsset.h"

UClass* UASAPostProcessTemplateAssetRule::GetAssetType()
{
	return UASAPostProcessTemplateAsset::StaticClass();
}
