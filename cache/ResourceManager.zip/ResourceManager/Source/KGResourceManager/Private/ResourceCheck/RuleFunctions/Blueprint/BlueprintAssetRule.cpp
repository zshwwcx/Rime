#include "ResourceCheck/RuleFunctions/Blueprint/BlueprintAssetRule.h"

#include "Engine/SCS_Node.h"
#include "Engine/SimpleConstructionScript.h"

UClass* UBlueprintAssetRule::GetAssetType()
{
	return UBlueprint::StaticClass();
}

bool UBlueprintAssetRule::CheckStaticMeshNotEmpty(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = false;
	const UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset());
	if (Blueprint == nullptr)
	{
		return bSuccess;
	}
	if (!Blueprint->ParentClass->IsChildOf(AActor::StaticClass()))
	{
		return bSuccess;
	}
	if (const USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript)
	{
		for (const USCS_Node* Node : SCS->GetAllNodes())
		{
			if (Node == nullptr)
			{
				continue;
			}
			UActorComponent* ComponentTemplate = Node->ComponentTemplate;
			if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(ComponentTemplate))
			{
				if (StaticMeshComponent->GetStaticMesh() == nullptr)
				{
					Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("蓝图类实例组件中静态网格体不能为空,组件名:{}"), StaticMeshComponent->GetName());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool UBlueprintAssetRule::CheckStaticMeshComp(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = false;
	const UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset());
	if (Blueprint == nullptr)
	{
		return bSuccess;
	}
	if (!Blueprint->ParentClass->IsChildOf(AActor::StaticClass()))
	{
		return bSuccess;
	}
	if (const USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript)
	{
		for (const USCS_Node* Node : SCS->GetAllNodes())
		{
			if (Node == nullptr)
			{
				continue;
			}
			UActorComponent* ComponentTemplate = Node->ComponentTemplate;
			if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(ComponentTemplate))
			{
				if (StaticMeshComponent->GetGenerateOverlapEvents())
				{
					Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("蓝图中静态网格体需要取消勾选Gengrate Overlap Events,组件名:{}"), StaticMeshComponent->GetName());
					bSuccess = false;
				}
				if (StaticMeshComponent->GetShouldUpdatePhysicsVolume())
				{
					Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("蓝图中静态网格体需要取消勾选Should Update Physics Volume,组件名:{}"), StaticMeshComponent->GetName());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool UBlueprintAssetRule::CheckMaterialInstanceDynamic(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset());
	if (Blueprint == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Blueprint is null"));
		return bSuccess;
	}
	if (!Blueprint->ParentClass->IsChildOf(AActor::StaticClass()))
	{
		return bSuccess;
	}
	const USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript;
	if (SCS == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("SimpleConstructionScript is null"));
		return bSuccess;
	}
	for (const USCS_Node* Node : SCS->GetAllNodes())
	{
		if (Node == nullptr)
		{
			continue;
		}
		UActorComponent* ComponentTemplate = Node->ComponentTemplate;
		if (UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(ComponentTemplate))
		{
			TArray<UMaterialInterface*> Materials;
			PrimitiveComponent->GetUsedMaterials(Materials);
			for (UMaterialInterface* Material : Materials)
			{
				if (Material == nullptr)
				{
					continue;
				}
				if (Material->IsA<UMaterialInstanceDynamic>())
				{
					Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("蓝图资源不能引用UMaterialInstanceDynamic对象"));
					return false;
				}
			}
		}
	}
	return bSuccess;
}
