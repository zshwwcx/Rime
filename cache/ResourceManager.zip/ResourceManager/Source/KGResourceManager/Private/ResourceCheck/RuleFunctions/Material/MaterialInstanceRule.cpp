#include "ResourceCheck/RuleFunctions/Material/MaterialInstanceRule.h"

#include "ISourceControlModule.h"
#include "MaterialEditingLibrary.h"
#include "MaterialEditorUtilities.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "Materials/MaterialInstanceConstant.h"
#include "VT/RuntimeVirtualTexture.h"

UClass* UMaterialInstanceRule::GetAssetType()
{
	return UMaterialInstance::StaticClass();
}

bool UMaterialInstanceRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	RelayMaterialPath = Params.GetValueList(TEXT("RelayMaterialPath"));
	ParentDirToMaterialInstancePrefix = Params.GetValueMap(TEXT("ParentDirToMaterialInstancePrefix"));
	return true;
}

bool UMaterialInstanceRule::CheckRelayMaterialInstance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	auto MaterialInstance = Cast<UMaterialInstance>(AssetData.GetAsset());
	if(MaterialInstance)
	{
		UMaterialInterface* ParentMaterialInterface = MaterialInstance->Parent;
		if(UMaterialInstance* ParentMaterialInstance = Cast<UMaterialInstance>(ParentMaterialInterface))
		{
			FString MaterialPath = ParentMaterialInstance->GetPathName();
			bool bRelayMaterial = false;
			for(auto RelayMaterialPrefix : RelayMaterialPath)
			{
				if(MaterialPath.StartsWith(RelayMaterialPrefix))
				{
					bRelayMaterial = true;
				}
			}
			
			if(bRelayMaterial)
			{
				//StaticSwitch
				TArray<FMaterialParameterInfo> ParentMaterialStaticSwitches;
				TArray<FGuid> ParentMaterialParameterGuids;
				TArray<FMaterialParameterInfo> MaterialStaticSwitches;
				TArray<FGuid> MaterialParameterGuids;
				
				ParentMaterialInstance->GetAllStaticSwitchParameterInfo(ParentMaterialStaticSwitches, ParentMaterialParameterGuids);
				MaterialInstance->GetAllStaticSwitchParameterInfo(MaterialStaticSwitches, MaterialParameterGuids);
				if(ParentMaterialStaticSwitches.Num() == MaterialStaticSwitches.Num())
				{
					for(int32 Index = 0; Index < ParentMaterialStaticSwitches.Num() ; Index ++)
					{
						bool ParentMaterialValue;
						bool MaterialValue;
						FGuid ParentMaterialGuid;
						FGuid MaterialGuid;
						ParentMaterialInstance->GetStaticSwitchParameterValue(ParentMaterialStaticSwitches[Index], ParentMaterialValue, ParentMaterialGuid);
						MaterialInstance->GetStaticSwitchParameterValue(MaterialStaticSwitches[Index], MaterialValue, MaterialGuid);

						if(ParentMaterialStaticSwitches[Index] != MaterialStaticSwitches[Index] ||
							ParentMaterialValue != MaterialValue)
						{
							Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的{}和中继材质实例{}不一致"), MaterialStaticSwitches[Index].Name, ParentMaterialInstance->GetPathName());
							bSuccess = false;
						}
					}
				}
				//MaterialPropertyOverrides
				FMaterialInstanceBasePropertyOverrides& ParentPropertyOverrides = ParentMaterialInstance->BasePropertyOverrides;
				FMaterialInstanceBasePropertyOverrides& PropertyOverrides = MaterialInstance->BasePropertyOverrides;
				if(ParentPropertyOverrides.OpacityMaskClipValue != PropertyOverrides.OpacityMaskClipValue)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的OpacityMaskClipValue和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.BlendMode != PropertyOverrides.BlendMode)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的BlendMode和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.ShadingModel != PropertyOverrides.ShadingModel)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的ShadingModel和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.TwoSided != PropertyOverrides.TwoSided)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的TwoSided和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.DitheredLODTransition != PropertyOverrides.DitheredLODTransition)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的DitheredLODTransition和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.bOutputTranslucentVelocity != PropertyOverrides.bOutputTranslucentVelocity)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的OutputTranslucentVelocity和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.bHasPixelAnimation != PropertyOverrides.bHasPixelAnimation)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的HasPixelAnimation和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.bEnableTessellation != PropertyOverrides.bEnableTessellation)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的EnableTessellation和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.DisplacementScaling != PropertyOverrides.DisplacementScaling)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的DisplacementScaling和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.MaxWorldPositionOffsetDisplacement != PropertyOverrides.MaxWorldPositionOffsetDisplacement)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的MaxWorldPositionOffsetDisplacement和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
				if(ParentPropertyOverrides.bCastDynamicShadowAsMasked != PropertyOverrides.bCastDynamicShadowAsMasked)
				{
					Log.RegistryAndLog(AssetData, TEXT("ReplyMaterialInstance"), CheckRuleType,
								TEXT("材质实例的CastDynamicShadowAsMasked和中继材质实例{}不一致"), ParentMaterialInstance->GetName());
					bSuccess = false;
				}
			}			
		}
	}
	return bSuccess;
}

bool UMaterialInstanceRule::CheckMaterialInstanceParent(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(auto MaterialInstance = Cast<UMaterialInstance>(AssetData.GetAsset()))
	{
		UMaterialInterface* ParentMaterialInterface = MaterialInstance->Parent;
		FString ParentMaterialPath = ParentMaterialInterface->GetPathName();
		for (auto ParentMaterialKV : ParentDirToMaterialInstancePrefix)
		{
			FString ParentContains = ParentMaterialKV.Key;
			FString MaterialInstancePrefixList = ParentMaterialKV.Value;
			if (ParentMaterialPath.Contains(ParentContains))
			{
				TArray<FString> MaterialInstancePrefixes;
				MaterialInstancePrefixList.ParseIntoArray(MaterialInstancePrefixes,TEXT(","));
				bool bPrefix = false;
				for (auto MaterialInstancePrefix : MaterialInstancePrefixes)
				{
					if (MaterialInstance->GetName().StartsWith(MaterialInstancePrefix) || ParentMaterialInterface->GetName().StartsWith(MaterialInstancePrefix))
					{
						bPrefix = true;
					}
				}

				if (!bPrefix)
				{
					Log.RegistryAndLog(AssetData, TEXT("MaterialInstance"), CheckRuleType,
								TEXT("路径 {} 下的材质实例的母材质 {} 需要拥有 {} 作为前缀"), ParentContains, ParentMaterialInterface->GetName(), MaterialInstancePrefixList);
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool UMaterialInstanceRule::CheckMaterialInstanceParentIsMR(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	if (UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>(AssetData.GetAsset()))
	{
		const UMaterial* ParentMaterial = MaterialInstance->GetMaterial();
		if (ParentMaterial)
		{
			if (ParentMaterial->GetPathName().StartsWith(TEXT("/Game/Arts/Effects/FX_Library/FX_Materials/")))
			{
				return true;
			}
			const TArray<FString> LandScapeFunctionNames = Params.GetValueList(TEXT("LandScapeFunctionNames"));
			if (IsLandScapeMaterial(ParentMaterial, LandScapeFunctionNames))
			{
				return true;
			}
		}
		TSet<UMaterialInterface*> Dependencies;
		MaterialInstance->GetDependencies(Dependencies);
		bool bDependencyMR = false;
		for (const UMaterialInterface* Dependency : Dependencies)
		{
			if (Dependency == nullptr || Dependency->IsA(UMaterial::StaticClass()))
			{
				continue;
			}
			if (Dependency->GetName().StartsWith(TEXT("MR_")))
			{
				bDependencyMR = true;
				break;
			}
		}
		if (!bDependencyMR)
		{
			FString ParentMaterialName;
			if (ParentMaterial)
			{
				ParentMaterialName = ParentMaterial->GetPathName();
			}
			Log.RegistryAndLog(AssetData, TEXT("MaterialInstance"), CheckRuleType,TEXT("材质实例的父项需要是中继材质（父项需要以MR_开头）,母材质为{}"), ParentMaterialName);
			return false;
		}
	}
	return true;
}

bool UMaterialInstanceRule::IsLandScapeMaterial(const UMaterial* InMaterial, const TArray<FString>& LandScapeFunctionNames)
{
	if (InMaterial == nullptr || LandScapeFunctionNames.IsEmpty())
	{
		return false;
	}
	TArray<UMaterialFunctionInterface*> DependentFunctions;
	InMaterial->GetDependentFunctions(DependentFunctions);
	for (const UMaterialFunctionInterface* DependentFunction : DependentFunctions)
	{
		if (DependentFunction && LandScapeFunctionNames.Contains(DependentFunction->GetName()))
		{
			return true;
		}
	}
	return false;
}

bool UMaterialInstanceRule::CheckRVTMaterialInstance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto MaterialInstance = Cast<UMaterialInstance>(AssetData.GetAsset()))
	{
		if (MaterialInstance->GetName().StartsWith("MR_"))
		{
			return bSuccess;
		}

		// 1. 获取材质实例中所有运行时虚拟纹理类型的参数信息
		URuntimeVirtualTexture* FoundRVTValue = nullptr;
		URuntimeVirtualTexture* FoundRVTMobileValue = nullptr;
		bool bUseRVT = true;
		FName RVTMaterialParameterName = TEXT("RVTMaterial"); // 目标参数名
		FName RVTMaterialMobileParameterName = TEXT("RVTMobile"); // 目标参数名
		FName UseRvtParameterName = TEXT("UseRvt");

		TArray<FMaterialParameterInfo> OutVisibleExpressions;
		FMaterialEditorUtilities::GetVisibleMaterialParameters(MaterialInstance->GetMaterial(), MaterialInstance , OutVisibleExpressions);
		// 2. 遍历获取到的参数信息列表
		for (const FMaterialParameterInfo& ParamInfo : OutVisibleExpressions)
		{
			if (ParamInfo.Name == RVTMaterialParameterName)
			{
				MaterialInstance->GetRuntimeVirtualTextureParameterValue(ParamInfo, FoundRVTValue);
			}
			if (ParamInfo.Name == RVTMaterialMobileParameterName)
			{
				MaterialInstance->GetRuntimeVirtualTextureParameterValue(ParamInfo, FoundRVTMobileValue);
			}
			if (ParamInfo.Name == UseRvtParameterName)
			{
				FGuid ParamGUID;
				MaterialInstance->GetStaticSwitchParameterValue(ParamInfo, bUseRVT, ParamGUID);
			}
		}

		if (FoundRVTValue == nullptr && FoundRVTMobileValue == nullptr)
		{
			return true;
		}

		if (FoundRVTValue == nullptr)
		{
			Log.RegistryAndLog(AssetData, TEXT("MaterialInstance"), CheckRuleType,
								TEXT("使用了RVT Mobile但缺少RVT"));
			return false;
		}

		FString RVTName = FoundRVTValue->GetName();
		FString ValidMobileRVTName = RVTName + "_Mobile";

		if (bUseRVT && RVTName == TEXT("RVT_Default"))
		{
			Log.RegistryAndLog(AssetData, TEXT("MaterialInstance"), CheckRuleType,
								TEXT("非中继材质的材质实例，使用RVTMaterial时不允许使用RVT_Default"));
			return false;
		}

		if (FoundRVTMobileValue == nullptr)
		{
			Log.RegistryAndLog(AssetData, TEXT("MaterialInstance"), CheckRuleType,
								TEXT("使用了RVT但缺少RVT Mobile"));
			OutRepairParams.Add(RVTMaterialMobileParameterName.ToString(), ValidMobileRVTName);
			return false;
		}

		FString RVTMobileName = FoundRVTMobileValue->GetName();

		if (RVTMobileName != RVTName + "_Mobile")
		{
			Log.RegistryAndLog(AssetData, TEXT("MaterialInstance"), CheckRuleType,
								TEXT("RVTMobile的名称需要是RVTMaterial的名称加上_Mobile后缀,当前使用的RVT为:{},使用的RVTMobile为:{}"), RVTName, RVTMobileName);
			OutRepairParams.Add(RVTMaterialMobileParameterName.ToString(), ValidMobileRVTName);
			return false;
		}
	}
	return bSuccess;
}

bool UMaterialInstanceRule::RepairRVTMaterialInstance(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	UMaterialInstanceConstant* MaterialInstanceConstant = Cast<UMaterialInstanceConstant>(AssetData.GetAsset());
	if (!MaterialInstanceConstant)
	{
		return false;
	}
	FName RVTMaterialMobileParameterName = TEXT("RVTMobile");
	if (InRepairParams.Contains(RVTMaterialMobileParameterName.ToString()))
	{
		FString ValidMobileRVTName = InRepairParams[RVTMaterialMobileParameterName.ToString()];
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		TArray<FAssetData> OutAssetData;
		FARFilter Filter;
		Filter.ClassPaths.Add(URuntimeVirtualTexture::StaticClass()->GetClassPathName());
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;
		Filter.PackagePaths.Add("/Game/Arts");
		AssetRegistryModule.Get().GetAssets(Filter, OutAssetData);
		for (const FAssetData& AssetDataToRepair : OutAssetData)
		{
			if (AssetDataToRepair.PackageName.ToString().EndsWith(ValidMobileRVTName))
			{
				if (URuntimeVirtualTexture* RuntimeVirtualTexture = Cast<URuntimeVirtualTexture>(AssetDataToRepair.GetAsset()))
				{
					UMaterialEditingLibrary::SetMaterialInstanceRuntimeVirtualTextureParameterValue(MaterialInstanceConstant, RVTMaterialMobileParameterName, RuntimeVirtualTexture);
					MaterialInstanceConstant->Modify();
					MaterialInstanceConstant->GetPackage()->MarkPackageDirty();
					return true;
				}
			}
		}
	}
	return false;
}

bool UMaterialInstanceRule::SubmitCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (const UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>(AssetData.GetAsset()))
	{
		bool bOnlyTA = false;
		FString Reason;
		if (const UMaterialInterface* MaterialInterface = MaterialInstance->GetParent())
		{
			FString MaterialPath = MaterialInterface->GetPathName();
			if (Params.ContainValue(TEXT("PPCommonMaterials"), MaterialPath))
			{
				bOnlyTA = true;
				Reason = TEXT("不允许非TA同学上传直接以PP_Common为母材质的材质实例");
			}
		}
		if (MaterialInstance->GetName().StartsWith(TEXT("MR_")))
		{
			bOnlyTA = true;
			Reason = TEXT("不允许非TA同学上传以MR_为前缀的材质实例");
		}
		if (bOnlyTA)
		{
			const FString AbsolutePath = FResourceCheckHelper::GetAbsoultePath(AssetData);
			ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
			const FString UserName = SourceControlProvider.GetWorkSpaceUserName();
			if (!UserName.IsEmpty())
			{
				const FString Process = TEXT("p4");
				const FString Command = FString::Printf(TEXT("groups %s"), *UserName);

				int32 ResultCode;
				FString Result;
				FString ResultErr;
				const bool bProcessSuccess = FPlatformProcess::ExecProcess(*Process, *Command, &ResultCode, &Result, &ResultErr);
				if (bProcessSuccess && Result != "")
				{
					TArray<FString> SplitStrings;
					Result.TrimStartAndEnd().ParseIntoArray(SplitStrings, TEXT("\n"), false);

					bool bContain = false;
					const TArray<FString> SubmitMaterialGroups = Params.GetValueList("SubmitMaterialGroup");
					for(auto SplitString : SplitStrings)
					{
						FString UserGroup = SplitString.TrimStartAndEnd();
						if(SubmitMaterialGroups.Contains(UserGroup))
						{
							bContain = true;
							break;
						}
					}
			
					if(!bContain)
					{
						Log.RegistryAndLog(AssetData, TEXT("MaterialInstance"), CheckRuleType, Reason);
						bSuccess = false;	
					}
				}
				else
				{
					Log.RegistryAndLog(AssetData, TEXT("MaterialInstance"), CheckRuleType, TEXT("P4返回结果出现问题，请重启引擎"));
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

TArray<FAssetData> UMaterialInstanceRule::GetReferencedClassAssetDatas(const FAssetData& AssetData, const UClass* InClass)
{
	TArray<FAssetData> Result;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FName AssetPackageName = AssetData.PackageName;
	
	TArray<FName> ReferencersAssetList;
	if (AssetRegistryModule.Get().GetReferencers(AssetPackageName, ReferencersAssetList))
	{
		for (const FName& ReferenceAssetName : ReferencersAssetList)
		{
			TArray<FAssetData> OutAssetData;
			AssetRegistryModule.Get().GetAssetsByPackageName(ReferenceAssetName, OutAssetData);
			if (!OutAssetData.IsEmpty())
			{
				const FAssetData& ReferenceAsset = OutAssetData[0];
				if (UClass* ReferenceAssetClass = ReferenceAsset.GetClass())
				{
					if (ReferenceAssetClass->IsChildOf(InClass))
					{
						Result.Add(ReferenceAsset);
					}
				}
			}
		}
	}
	return Result;
}

bool UMaterialInstanceRule::CheckUsedWithSkeletalMesh(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (!GetReferencedClassAssetDatas(AssetData, USkeletalMesh::StaticClass()).IsEmpty())
	{
		if (const UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>(AssetData.GetAsset()))
		{
			if (const UMaterial* Material = MaterialInstance->GetMaterial())
			{
				if (!Material->bUsedWithSkeletalMesh)
				{
					Log.RegistryAndLog(AssetData, TEXT("SkeletalMesh"), CheckRuleType, TEXT("检测到被SkeletalMesh 引用，需要改用支持SkeletalMesh的中继材质"));
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool UMaterialInstanceRule::CheckUsedWithNanite(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	const TArray<FAssetData>& ReferencedAssetList = GetReferencedClassAssetDatas(AssetData, UStaticMesh::StaticClass());
	bool bUsedNanite = false;
	TArray<FString> NaniteStaticMeshNames;
	for (const FAssetData& ReferencedAsset : ReferencedAssetList)
	{
		if (const UStaticMesh* StaticMesh = Cast<UStaticMesh>(ReferencedAsset.GetAsset()))
		{
			if (StaticMesh->NaniteSettings.bEnabled)
			{
				bUsedNanite = true;
				NaniteStaticMeshNames.Add(ReferencedAsset.PackageName.ToString());
			}
		}
	}
	if (bUsedNanite)
	{
		if (const UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>(AssetData.GetAsset()))
		{
			if (const UMaterial* Material = MaterialInstance->GetMaterial())
			{
				if (!Material->bUsedWithNanite)
				{
					Log.RegistryAndLog(AssetData, TEXT("SkeletalMesh"), CheckRuleType, TEXT("检测到被开启Nanite的StaticMesh引用，需要改用支持Nanite的中继材质，开启Nanite的StaticMesh有：{}"), FString::Join(NaniteStaticMeshNames, TEXT(",")));
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}
