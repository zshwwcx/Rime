#include "ResourceCheck/RuleFunctions/Actor/BpActorMobilityRule.h"

UClass* UBpActorMobilityRule::GetAssetType()
{
	return AActor::StaticClass();
}

bool UBpActorMobilityRule::PreExecuteAsset(const FAssetData& AssetData)
{
	if (const AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if (Actor->IsEditorOnly())
		{
			return false;
		}
		UBlueprintGeneratedClass* BlueprintClass = Cast<UBlueprintGeneratedClass>(Actor->GetClass());
		if (BlueprintClass == nullptr)
		{
			return false;
		}
		if (Actor->FindComponentByClass(USceneComponent::StaticClass()) == nullptr)
		{
			return false;
		}
	}
	return true;
}

bool UBpActorMobilityRule::CheckSubComponentMobility(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (const AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		USceneComponent* RootComponent = Actor->GetRootComponent();
		if (RootComponent != nullptr && RootComponent->Mobility == EComponentMobility::Movable)
		{
			for (auto Component : Actor->GetComponents())
			{
				if (RootComponent == Component)
				{
					continue;
				}
				if (USceneComponent* SceneComponent = Cast<USceneComponent>(Component))
				{
					if (SceneComponent->Mobility != EComponentMobility::Movable)
					{
						Log.RegistryAndLog(AssetData, TEXT("BpActor"), CheckRuleType,
									TEXT("蓝图类Actor根节点移动性为movable时，其子节点:{}也需要是movable"), SceneComponent->GetName());
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}
