#include "ResourceCheck/RuleFunctions/Misc/GrassTypeRule.h"
#include "FileHelpers.h"
UClass* UGrassTypeRule::GetAssetType()
{
	return ULandscapeGrassType::StaticClass();
}

bool UGrassTypeRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	ForceWPOMaterial = Params.GetValueList(TEXT("ForceWPOMaterial"));
	FoliageMaterial = Params.GetValueList(TEXT("FoliageMaterial"));
	WPODisableDistance = FCString::Atoi(*Params.GetValue(TEXT("WPODisableDistance")));
	return true;
}

bool UGrassTypeRule::HasForceWPOMaterial(const FStaticMaterial& StaticMaterial)
{
	if(auto MaterialInstance = Cast<UMaterialInstance>(StaticMaterial.MaterialInterface.Get()))
	{
		while (MaterialInstance)
		{
			auto ParentMat = MaterialInstance->Parent;
			if(ParentMat && ForceWPOMaterial.Contains(ParentMat.GetName()))
			{
				return true;
			}
			MaterialInstance =  Cast<UMaterialInstance>(MaterialInstance->Parent);
		}
	}
	return false;
}

bool UGrassTypeRule::HasFoliageMaterial(const FStaticMaterial& StaticMaterial)
{
	if(auto MaterialInstance = Cast<UMaterialInstance>(StaticMaterial.MaterialInterface.Get()))
	{
		while (MaterialInstance)
		{
			auto ParentMat = MaterialInstance->Parent;
			if(ParentMat && FoliageMaterial.Contains(ParentMat.GetName()))
			{
				return true;
			}
			MaterialInstance =  Cast<UMaterialInstance>(MaterialInstance->Parent);
		}
	}
	return false;
}
bool UGrassTypeRule::FoliageMaterialEnableNantieSupport(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for(int Index = 0; Index < GrassType->GrassVarieties.Num(); Index++ )
		{
			if(auto GrassMesh = GrassType->GrassVarieties[Index].GrassMesh.Get())
			{
				for(const auto &StaticMat : GrassMesh->GetStaticMaterials())
				{
					if(HasFoliageMaterial(StaticMat))
					{
						if(!GrassMesh->NaniteSettings.bEnabled)
						{
							Log.RegistryAndLog(AssetData, TEXT("GrassType"), CheckRuleType,TEXT("静态模型{}不具有风动植被材质需要在StaticMeshAsset里开启 启用Nantie支持 属性"), GrassMesh->GetName());
							OutRepairParams.FindOrAdd(GrassMesh->GetName() + TEXT(",NaniteSettingsbEnabled")) = TEXT("true");
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UGrassTypeRule::FoliageMaterialPreserveArea(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for(int Index = 0; Index < GrassType->GrassVarieties.Num(); Index++ )
		{
			if(auto GrassMesh = GrassType->GrassVarieties[Index].GrassMesh.Get())
			{
				for(const auto &StaticMat : GrassMesh->GetStaticMaterials())
				{
					if(HasFoliageMaterial(StaticMat))
					{
						if(!GrassMesh->NaniteSettings.bPreserveArea)
						{
							Log.RegistryAndLog(AssetData, TEXT("GrassType"), CheckRuleType,TEXT("静态模型{}不具有风动植被材质需要在StaticMeshAsset里开启PreserveArea"), GrassMesh->GetName());
							OutRepairParams.FindOrAdd(GrassMesh->GetName() + TEXT(",bPreserveArea")) = TEXT("true");
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UGrassTypeRule::FoliageMaterialCastDynamicShadow(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for(int Index = 0; Index < GrassType->GrassVarieties.Num(); Index++ )
		{
			if(auto GrassMesh = GrassType->GrassVarieties[Index].GrassMesh.Get())
			{
				for(const auto &StaticMat : GrassMesh->GetStaticMaterials())
				{
					if(HasFoliageMaterial(StaticMat))
					{
						if(!GrassType->GrassVarieties[Index].bCastDynamicShadow)
						{
							Log.RegistryAndLog(AssetData, TEXT("GrassType"), CheckRuleType,TEXT("{}:拥有非风动植被材质应该打开动态阴影"), GrassMesh->GetName());
							OutRepairParams.FindOrAdd(FString::FromInt(Index) + TEXT(",bCastDynamicShadow")) = TEXT("true");
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UGrassTypeRule::ForceWPOMaterialEnableNantieSupport(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for(int Index = 0; Index < GrassType->GrassVarieties.Num(); Index++ )
		{
			if(auto GrassMesh = GrassType->GrassVarieties[Index].GrassMesh.Get())
			{
				for(const auto &StaticMat : GrassMesh->GetStaticMaterials())
				{
					if(HasForceWPOMaterial(StaticMat))
					{
						if(GrassMesh->NaniteSettings.bEnabled)
						{
							Log.RegistryAndLog(AssetData, TEXT("GrassType"), CheckRuleType,TEXT("静态模型{}具有风动植被材质情况下应该关闭 启用Nantie支持 属性"), GrassMesh->GetName());
							OutRepairParams.FindOrAdd(GrassMesh->GetName() + TEXT(",NaniteSettingsbEnabled")) = TEXT("false");
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UGrassTypeRule::ForceWPOMaterialPreserveArea(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for(int Index = 0; Index < GrassType->GrassVarieties.Num(); Index++ )
		{
			if(auto GrassMesh = GrassType->GrassVarieties[Index].GrassMesh.Get())
			{
				for(const auto &StaticMat : GrassMesh->GetStaticMaterials())
				{
					if(HasForceWPOMaterial(StaticMat))
					{
						if(!GrassMesh->NaniteSettings.bPreserveArea)
						{
							Log.RegistryAndLog(AssetData, TEXT("GrassType"), CheckRuleType,TEXT("静态模型{}具有风动植被材质需要在StaticMeshAsset里开启PreserveArea"), GrassMesh->GetName());
							OutRepairParams.FindOrAdd(GrassMesh->GetName() + TEXT(",bPreserveArea")) = TEXT("true");
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UGrassTypeRule::ForceWPOMaterialReceivesDecals(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for(int Index = 0; Index < GrassType->GrassVarieties.Num(); Index++ )
		{
			if(auto GrassMesh = GrassType->GrassVarieties[Index].GrassMesh.Get())
			{
				for(const auto &StaticMat : GrassMesh->GetStaticMaterials())
				{
					if(HasForceWPOMaterial(StaticMat))
					{
						if(!GrassType->GrassVarieties[Index].bReceivesDecals)
						{
							Log.RegistryAndLog(AssetData, TEXT("GrassType"), CheckRuleType,TEXT("静态模型{}具有风动植被材质需要勾选Receives Decals"), GrassMesh->GetName());
							OutRepairParams.FindOrAdd(FString::FromInt(Index) + TEXT(",bReceivesDecals")) = TEXT("true");
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UGrassTypeRule::ForceWPOMaterialCastContactShadow(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for(int Index = 0; Index < GrassType->GrassVarieties.Num(); Index++ )
		{
			if(auto GrassMesh = GrassType->GrassVarieties[Index].GrassMesh.Get())
			{
				for(const auto &StaticMat : GrassMesh->GetStaticMaterials())
				{
					if(HasForceWPOMaterial(StaticMat))
					{
						if (GrassType->GrassVarieties[Index].bCastContactShadow == false || GrassType->GrassVarieties[Index].bCastDynamicShadow == true)
						{
							Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType,TEXT("静态模型{}具有风动植被材质应该关闭动态阴影，打开接触阴影"), GrassMesh->GetName());
							OutRepairParams.FindOrAdd(FString::FromInt(Index) + TEXT(",bCastContactShadow")) = TEXT("true");
							OutRepairParams.FindOrAdd(FString::FromInt(Index) + TEXT(",bCastDynamicShadow")) = TEXT("false");
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UGrassTypeRule::UnForceWPOMaterialWPODisableDistance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for(int Index = 0; Index < GrassType->GrassVarieties.Num(); Index++ )
		{
			if(auto GrassMesh = GrassType->GrassVarieties[Index].GrassMesh.Get())
			{
				for(const auto &StaticMat : GrassMesh->GetStaticMaterials())
				{
					if(!HasForceWPOMaterial(StaticMat))
					{
						if(GrassType->GrassVarieties[Index].InstanceWorldPositionOffsetDisableDistance != WPODisableDistance)
						{
							Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType,TEXT("静态模型{}不具有风动植被材质的Asset应该设置WPO disable distance为{}"), GrassMesh->GetName(), WPODisableDistance);
							OutRepairParams.FindOrAdd(FString::FromInt(Index) + TEXT(",InstanceWorldPositionOffsetDisableDistance")) = FString::FromInt(WPODisableDistance);
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UGrassTypeRule::RepairGrassType(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bDirty = false;
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for (auto RepairParam : OutRepairParams)
		{
			TArray<FString> KeyParams;
			RepairParam.Key.ParseIntoArray(KeyParams, TEXT(","));
			if (KeyParams.Num() > 1)
			{
				int32 Index = FCString::Atoi(*KeyParams[0]);
				FString Property = KeyParams[1];
				if (Index >= 0 && Index < GrassType->GrassVarieties.Num())
				{
					if (Property == TEXT("bCastContactShadow"))
					{
						GrassType->GrassVarieties[Index].bCastContactShadow = RepairParam.Value == TEXT("true") ? true : false;
						bDirty = true;
					}
					else if (Property == TEXT("bCastDynamicShadow"))
					{
						GrassType->GrassVarieties[Index].bCastDynamicShadow = RepairParam.Value == TEXT("true") ? true : false;
						bDirty = true;
					}
					else if (Property == TEXT("InstanceWorldPositionOffsetDisableDistance"))
					{
						GrassType->GrassVarieties[Index].InstanceWorldPositionOffsetDisableDistance = FCString::Atoi(*RepairParam.Value);
						bDirty = true;
					}
					else if (Property == TEXT("bReceivesDecals"))
					{
						GrassType->GrassVarieties[Index].bReceivesDecals = RepairParam.Value == TEXT("true") ? true : false;
						bDirty = true;
					}
				}
			}
		}
		if (bDirty)
		{
			GrassType->Modify();
			bSuccess = GrassType->GetPackage()->MarkPackageDirty();
		}
	}
	
	return bSuccess;
}

bool UGrassTypeRule::RepairGrassMesh(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset()))
	{
		for(int Index = 0; Index < GrassType->GrassVarieties.Num(); Index++ )
		{
			if(auto GrassMesh = GrassType->GrassVarieties[Index].GrassMesh.Get())
			{
				bool bDirty = false;
				for (auto RepairParam : OutRepairParams)
				{			
					TArray<FString> KeyParams;
					RepairParam.Key.ParseIntoArray(KeyParams, TEXT(","));
					if (KeyParams.Num() > 1)
					{
						FString GrassMeshName = KeyParams[0];
						FString Property = KeyParams[1];
						if (GrassMeshName == GrassMesh->GetName())
						{
							if (Property == TEXT("NaniteSettingsbEnabled"))
							{
								GrassMesh->NaniteSettings.bEnabled = RepairParam.Value == TEXT("true") ? true : false;
							}
							else if (Property == TEXT("bPreserveArea"))
							{
								GrassMesh->NaniteSettings.bPreserveArea = RepairParam.Value == TEXT("true") ? true : false;
							}
						}
					}
				}
				if (bDirty)
				{
					GrassMesh->Modify();
					bSuccess &= GrassMesh->GetPackage()->MarkPackageDirty();
					//GrassType导致的StaticMesh修改需要额外保存
					bSuccess &= UEditorLoadingAndSavingUtils::SavePackages({GrassMesh->GetPackage()}, true);
				}
			}
		}		
	}
	return bSuccess;
}

bool UGrassTypeRule::CheckCullDistance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset());
	if (GrassType == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("GrassType is null"));
		return bSuccess;
	}
	int32 ValidEndCullDistance = FCString::Atoi(*Params.GetValue(TEXT("ValidEndCullDistance")));
	TArray<FString> InvalidGrassVarieties;
	for (int32 Index = 0; Index < GrassType->GrassVarieties.Num(); Index++)
	{
		const FGrassVariety& GrassVariety = GrassType->GrassVarieties[Index];
		int32 CurEndCullDistance = GrassVariety.GetEndCullDistance();
		if (CurEndCullDistance > ValidEndCullDistance || CurEndCullDistance == 0)
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType,TEXT("End Cull Distance需要小于等于{}且不能为0,当前第{}个GrassVariety不符合"), ValidEndCullDistance, Index);
			InvalidGrassVarieties.Add(FString::FromInt(Index));
			bSuccess = false;
		}
	}
	if (InvalidGrassVarieties.Num() > 0)
	{
		OutRepairParams.Add(TEXT("InvalidEndCullDistance"), FString::Join(InvalidGrassVarieties, TEXT(",")));
	}
	return bSuccess;
}

bool UGrassTypeRule::RepairCullDistance(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	bool bSuccess = false;
	ULandscapeGrassType* GrassType = Cast<ULandscapeGrassType>(AssetData.GetAsset());
	if (GrassType == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("GrassType is null"));
		return bSuccess;
	}
	if (InRepairParams.Contains(TEXT("InvalidEndCullDistance")))
	{
		int32 ValidEndCullDistance = FCString::Atoi(*Params.GetValue(TEXT("ValidEndCullDistance")));
		TArray<FString> InvalidGrassVarieties;
		InRepairParams[TEXT("InvalidEndCullDistance")].ParseIntoArray(InvalidGrassVarieties, TEXT(","));
		bool bModified = false;
		for (const FString& InvalidGrassVariety : InvalidGrassVarieties)
		{
			int32 InvalidIndex = FCString::Atoi(*InvalidGrassVariety);
			if (InvalidIndex >= 0 && InvalidIndex < GrassType->GrassVarieties.Num())
			{
				GrassType->GrassVarieties[InvalidIndex].EndCullDistance = ValidEndCullDistance;
				bModified = true;
			}
		}
		if (bModified)
		{
			GrassType->Modify();
			GrassType->GetPackage()->MarkPackageDirty();
			bSuccess = true;
		}
	}
	return bSuccess;
}
