#include "ResourceCheck/RuleFunctions/Skill/ASAAssetRule.h"

#include "KGAbilitySystemEditor/AbilityEditor/Ability/ASAAsset.h"
#include "NiagaraSystem.h"

UClass* UASAAssetRule::GetAssetType()
{
	return UASAAsset::StaticClass();
}

bool UASAAssetRule::CheckNiagaraEffectType(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	const TArray<FString>& ValidSkillEffectTypeNames = Params.GetValueList("ValidSkillEffectTypeNames");
	if (ValidSkillEffectTypeNames.IsEmpty())
	{
		return bSuccess;
	}
	const UASAAsset* ASAAsset = Cast<UASAAsset>(AssetData.GetAsset());
	if (ASAAsset == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find ASAAsset"));
		return bSuccess;
	}
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FName> DependAssetList;
	if (AssetRegistryModule.Get().GetDependencies(AssetData.PackageName, DependAssetList))
	{
		TArray<FString> DependAssetArray;
		for (const auto& DependAssetName : DependAssetList)
		{
			TArray<FAssetData> OutAssetData;
			AssetRegistryModule.Get().GetAssetsByPackageName(DependAssetName, OutAssetData);
			if (OutAssetData.IsEmpty())
			{
				continue;
			}
			const FAssetData& DependAsset = OutAssetData[0];
			UClass* DependAssetClass = DependAsset.GetClass();
			if (DependAssetClass == nullptr || DependAssetClass != UNiagaraSystem::StaticClass())
			{
				continue;
			}
			const UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(DependAsset.GetAsset());
			if (NiagaraSystem == nullptr)
			{
				continue;
			}
			const UNiagaraEffectType* EffectType = NiagaraSystem->GetEffectType();
			if (EffectType == nullptr)
			{
				continue;
			}
			const FString& EffectTypeName = EffectType->GetName();
			if (!ValidSkillEffectTypeNames.Contains(EffectTypeName))
			{
				Log.RegistryAndLog(AssetData, TEXT("StaticMeshFoliage"), CheckRuleType, TEXT("技能资产使用了非法效果类型的特效资产：{}，当前特效效果类型：{},允许的效果类型:{},请更换合法特效或找美术同学更改特效类型"), NiagaraSystem->GetFullName(), EffectTypeName, FString::Join(ValidSkillEffectTypeNames, TEXT(",")));
				bSuccess = false;
			}
		}
	}
	return bSuccess;
}
