#include "ResourceCheck/RuleFunctions/Animation/AnimSequenceRule.h"

#include "3C/Animation/AnimNotify/AnimNotifyState_C7TimedNiagaraEffect.h"
#include "Factories/FbxAnimSequenceImportData.h"


UClass* UAnimSequenceRule::GetAssetType()
{
	return UAnimSequence::StaticClass();
}

FString UAnimSequenceRule::IsUseDefaultSampleRate(const FAssetData& AssetData)
{
	if (UAnimSequence* AnimSequence = Cast<UAnimSequence>(AssetData.GetAsset()))
	{
		if (const UFbxAnimSequenceImportData* FbxImportSetting = Cast<UFbxAnimSequenceImportData>(AnimSequence->AssetImportData))
		{
			if (FbxImportSetting->bUseDefaultSampleRate)
			{
				return TEXT("1");
			}
		}
	}
	return TEXT("0");
}

FString UAnimSequenceRule::IsRetargetSourceValidPrefix(const FAssetData& AssetData)
{
	const FString AssetName = AssetData.AssetName.ToString();
	TArray<FString> RetargetSourceValidPrefixes = Params.GetValueList(TEXT("RetargetSourceValidPrefixes"));
	for (const FString& Prefix : RetargetSourceValidPrefixes)
	{
		if (AssetName.StartsWith(Prefix))
		{
			return TEXT("1");
		}
	}
	return TEXT("0");
}

FString UAnimSequenceRule::IsRetargetSourceValidFolder(const FAssetData& AssetData)
{
	const FString PackageName = AssetData.PackageName.ToString();
	TArray<FString> RetargetSourceValidFolders = Params.GetValueList(TEXT("RetargetSourceValidFolders"));
	for (const FString& Folder : RetargetSourceValidFolders)
	{
		if (PackageName.StartsWith(Folder))
		{
			return TEXT("1");
		}
	}
	return TEXT("0");
}

bool UAnimSequenceRule::CheckRetargetSourceNotEndWithOld(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	const UAnimSequence* AnimSequence = Cast<UAnimSequence>(AssetData.GetAsset());
	if (!AnimSequence)
	{
		return true;
	}
	if (AnimSequence->RetargetSource.ToString().EndsWith("_Old"))
	{
		Log.RegistryAndLog(AssetData, TEXT("AnimSequence"), CheckRuleType,TEXT("动画序列里重定向源不能有_Old结尾:{}"), AnimSequence->RetargetSource);
		return false;
	}
	return true;
}

bool UAnimSequenceRule::CheckTimedNiagaraEffectNotifyState(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	const UAnimSequence* AnimSequence = Cast<UAnimSequence>(AssetData.GetAsset());
	if (!AnimSequence)
	{
		return true;
	}
	bool bSuccess = true;
	for (const FAnimNotifyEvent& NotifyEvent : AnimSequence->Notifies)
	{
		if (NotifyEvent.NotifyStateClass == nullptr)
		{
			continue;
		}
		if (UAnimNotifyState_C7TimedNiagaraEffect* TimedNiagaraEffect = Cast<UAnimNotifyState_C7TimedNiagaraEffect>(NotifyEvent.NotifyStateClass))
		{
			if (TimedNiagaraEffect->ReleaseMode == EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnNiagaraFinished)
			{
				if (TimedNiagaraEffect->TemplatePath == nullptr)
				{
					continue;
				}
				UNiagaraSystem* NiagaraSystem = TimedNiagaraEffect->TemplatePath.LoadSynchronous();
				if (NiagaraSystem && NiagaraSystem->bInfiniteSystem)
				{
					Log.RegistryAndLog(AssetData, TEXT("AnimSequence"), CheckRuleType,TEXT("动画序列里的Timed Niagara Effect模式为AutoReleaseOnNiagaraFinished时，其特效不能是Loop特效"));
					bSuccess = false;
				}
			}
			else if (TimedNiagaraEffect->ReleaseMode == EC7AnimNotifyStateNiagaraReleaseMode::AutoReleaseOnNotifyStateEnd)
			{
				const float TriggerTime = NotifyEvent.GetTriggerTime();
				constexpr float Tolerance = 0.001f;
				const bool bStartsAtZero = FMath::IsNearlyZero(TriggerTime, Tolerance);
				const float EndTime = NotifyEvent.GetEndTriggerTime();
				const bool bEndsAtFinalFrame = FMath::IsNearlyEqual(EndTime, AnimSequence->GetPlayLength(), Tolerance);
				if (!bStartsAtZero || !bEndsAtFinalFrame)
				{
					Log.RegistryAndLog(AssetData, TEXT("AnimSequence"), CheckRuleType,TEXT("动画序列里的Timed Niagara Effect模式为AutoReleaseOnNotifyStateEnd时，必须从第0帧触发，最后一帧结束"));
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}
