#include "ResourceCheck/RuleFunctions/GFur/GFurAssetRule.h"

#include "FurComponent.h"

UClass* UGFurRuleBase::GetAssetType()
{
	return UBlueprint::StaticClass();
}

bool UGFurAssetRule::PreExecuteAsset(const FAssetData& AssetData)
{
	const UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset());
	if (Blueprint == nullptr  || Blueprint->ParentClass == nullptr)
	{
		return false;
	}
	if (!Blueprint->ParentClass->IsChildOf(UGFurComponent::StaticClass()))
	{
		return false;
	}
	return true;
}

UGFurComponent* UGFurAssetRule::GetGFurComponent(const FAssetData& AssetData)
{
	const UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset());
	if (Blueprint == nullptr || Blueprint->GeneratedClass == nullptr)
	{
		return nullptr;
	}
	return Cast<UGFurComponent>(Blueprint->GeneratedClass->GetDefaultObject());
}

FString UGFurAssetRule::GetLODsCount(const FAssetData& AssetData)
{
	const UGFurComponent* FurComponent = GetGFurComponent(AssetData);
	if (FurComponent == nullptr)
	{
		return TEXT("0");
	}
	return FString::FromInt(FurComponent->LODs.Num());
}

FString UGFurAssetRule::GetLayerCount(const FAssetData& AssetData)
{
	const UGFurComponent* FurComponent = GetGFurComponent(AssetData);
	if (FurComponent == nullptr)
	{
		return TEXT("0");
	}
	return FString::FromInt(FurComponent->LayerCount);
}

FString UGFurAssetRule::GetSkeletalGrowMeshVertices(const FAssetData& AssetData)
{
	const UGFurComponent* FurComponent = GetGFurComponent(AssetData);
	if (FurComponent == nullptr)
	{
		return TEXT("0");
	}
	const USkeletalMesh* SkeletalGrowMesh = FurComponent->SkeletalGrowMesh;
	if (SkeletalGrowMesh == nullptr)
	{
		return TEXT("0");
	}
	FSkeletalMeshRenderData* SkelMeshRenderData = SkeletalGrowMesh->GetResourceForRendering();
	if (SkelMeshRenderData && SkelMeshRenderData->LODRenderData.Num() > 0)
	{
		const FSkeletalMeshLODRenderData& LODData = SkelMeshRenderData->LODRenderData[0];
		return FString::FromInt(LODData.GetNumVertices());
	}
	return TEXT("0");
}

FString UGFurAssetRule::GetStaticGrowMeshVertices(const FAssetData& AssetData)
{
	const UGFurComponent* FurComponent = GetGFurComponent(AssetData);
	if (FurComponent == nullptr)
	{
		return TEXT("0");
	}
	const UStaticMesh* StaticMesh = FurComponent->StaticGrowMesh;
	if (StaticMesh == nullptr)
	{
		return TEXT("0");
	}
	if (StaticMesh->GetRenderData() && StaticMesh->GetRenderData()->LODResources.Num() > 0)
	{
		const FStaticMeshLODResources& LOD = StaticMesh->GetRenderData()->LODResources[0];
		return FString::FromInt(LOD.VertexBuffers.StaticMeshVertexBuffer.GetNumVertices());
	}
	return TEXT("0");
}
