#include "ResourceCheck/RuleFunctions/Texture/RuntimeVirtualTextureRule.h"

#include "VT/RuntimeVirtualTexture.h"

UClass* URuntimeVirtualTextureRule::GetAssetType()
{
	return URuntimeVirtualTexture::StaticClass();
}

bool URuntimeVirtualTextureRule::CheckMobileAssetExist(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	FString RVTName = AssetData.AssetName.ToString();
	FString MobileRVTName = RVTName + "_Mobile";
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	TArray<FAssetData> OutAssetData;
	FARFilter Filter;
	Filter.ClassPaths.Add(URuntimeVirtualTexture::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	Filter.PackagePaths.Add(TEXT("/Game"));
	AssetRegistry.GetAssets(Filter, OutAssetData);
	for (auto RVTAssetData : OutAssetData)
	{
		if (RVTAssetData.IsValid() && RVTAssetData.AssetName.ToString() == MobileRVTName)
		{
			return true;
		}
	}
	Log.RegistryAndLog(AssetData,TEXT("RuntimeVirtualTexture"), ERMCheckRuleType::Error, TEXT("需要有一个名为{}的RVT资源给手机端使用（各场景的RVT资源成对出现）"), MobileRVTName);
	return false;
}
