#include "ResourceCheck/RuleFunctions/Actor/PostProcessVolumeRule.h"
#include "Engine/PostProcessVolume.h"
#include "UObject/UnrealType.h"
#include "UObject/UnrealNames.h"
#include "UObject/StructOnScope.h"
#include "ObjectEditorUtils.h"
#include "UObject/ConstructorHelpers.h"
#include "Misc/Paths.h"
#include "Misc/ConfigCacheIni.h"

UClass* UPostProcessVolumeRule::GetAssetType()
{
    return APostProcessVolume::StaticClass();
}

void UPostProcessVolumeRule::LocalLogViolation(const FAssetData* AssetData, const FString& ModuleName, const FString& SubCategory, const FString& PropDisplay, const FString& VolumeName)
{
	FString PropertyName = PropDisplay;
	if (SubCategory != TEXT("Default"))
	{
		PropertyName = FString::Printf(TEXT("%s|%s"), *SubCategory, *PropDisplay);
	}
    const FString Msg = FString::Printf(TEXT("场景 PostProcessVolume 不允许修改模块 %s 下的属性: %s (Volume: %s)"), *ModuleName, *PropertyName, *VolumeName);
    if (AssetData && AssetData->IsValid())
    {
        // 使用项目中统一的日志接口（若不可用可改为 UE_LOG）
        Log.RegistryAndLog(*AssetData, TEXT("PostProcessVolume"), CheckRuleType, Msg);
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("%s"), *Msg);
    }
}

bool UPostProcessVolumeRule::CheckPostProcessVolumeOverrides(const FAssetData& AssetData, TMap<FString, FString>& RepairParams)
{
    bool bSuccess = true;

    const APostProcessVolume* PPV = Cast<APostProcessVolume>(AssetData.GetAsset());
    if (!PPV)
    {
        return bSuccess;
    }

    const FPostProcessSettings& Settings = PPV->Settings;
    const UStruct* SettingsStruct = FPostProcessSettings::StaticStruct();
    if (!SettingsStruct)
    {
        return bSuccess;
    }

    // 构造配置文件路径（插件目录下）
    const FString ConfigRelative = TEXT("Plugins/KGResourceManager/Config/PostProcessVolumeRule.ini");
    const FString ConfigPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectDir() / ConfigRelative);

    // 试着加载配置文件（若不存在则视为不允许任何属性）
    if (FPaths::FileExists(ConfigPath))
    {
        GConfig->LoadFile(ConfigPath);
    }

    // 遍历 Settings 的属性，查找有 EditCondition 并且被覆盖的属性
    for (TFieldIterator<FProperty> PropIt(const_cast<UStruct*>(SettingsStruct)); PropIt; ++PropIt)
    {
        FProperty* Prop = *PropIt;
        if (!Prop) continue;

        if (!Prop->HasMetaData(TEXT("EditCondition"))) continue;

        // 检查该属性是否被 override（EditCondition 指向的 bool 为 true）
        const FString EditConditionName = Prop->GetMetaData(TEXT("EditCondition"));
        if (EditConditionName.IsEmpty()) continue;

        FProperty* BoolProp = const_cast<UStruct*>(SettingsStruct)->FindPropertyByName(FName(*EditConditionName));
        const FBoolProperty* OverrideBoolProp = CastField<const FBoolProperty>(BoolProp);
        if (!OverrideBoolProp) continue;

        const void* BoolAddr = OverrideBoolProp->ContainerPtrToValuePtr<void>(&Settings);
        if (!BoolAddr) continue;

        const bool bOverridden = OverrideBoolProp->GetPropertyValue(BoolAddr);
        if (!bOverridden) continue;

        // 获取 Category 的顶级和次级（如果有）
        const FString CategoryName = FObjectEditorUtils::GetCategoryFName(Prop).ToString();
        if (CategoryName.IsEmpty()) continue;

        TArray<FString> CategoryPieces;
        CategoryName.ParseIntoArray(CategoryPieces, TEXT("|"));
        const FString RootCategory = CategoryPieces.Num() > 0 ? CategoryPieces[0] : CategoryName;
        const FString SubCategory = CategoryPieces.Num() > 1 ? CategoryPieces[1] : TEXT("Default");

        // 从 ini 中读取允许列表（逗号分隔）
        FString AllowedList;
        bool bHasKey = false;
        if (FPaths::FileExists(ConfigPath))
        {
            bHasKey = GConfig->GetString(*RootCategory, *SubCategory, AllowedList, *ConfigPath);
        }

        // 如果文件不存在或没有对应 key，则视为没有允许的属性（即禁止）
        bool bAllowed = false;
        if (bHasKey && !AllowedList.IsEmpty())
        {
            TArray<FString> AllowedItems;
            AllowedList.ParseIntoArray(AllowedItems, TEXT(","), true);

            const FString PropName = Prop->GetName();
            const FString PropDisplay = Prop->GetDisplayNameText().ToString();

            for (FString& Item : AllowedItems)
            {
                Item = Item.TrimStartAndEnd();
                if (Item.IsEmpty()) continue;
                // 比较属性名或者 display 名称
                if (Item.Equals(PropName, ESearchCase::IgnoreCase) || Item.Equals(PropDisplay, ESearchCase::IgnoreCase))
                {
                    bAllowed = true;
                    break;
                }
            }
        }

        if (!bAllowed)
        {
            const FString PropDisplay = Prop->GetDisplayNameText().ToString();
            LocalLogViolation(&AssetData, RootCategory, SubCategory, PropDisplay, PPV ? PPV->GetName() : TEXT("Unknown"));
            bSuccess = false;
            // 继续收集更多违规项
        }
    }

    return bSuccess;
}
