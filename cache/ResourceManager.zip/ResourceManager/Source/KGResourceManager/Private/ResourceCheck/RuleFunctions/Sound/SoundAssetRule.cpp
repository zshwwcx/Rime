#include "ResourceCheck/RuleFunctions/Sound/SoundAssetRule.h"

UClass* USoundAssetRule::GetAssetType()
{
	return USoundBase::StaticClass();
}

bool USoundAssetRule::CheckSoundAsset(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("所有继承自USoundBase类型的资产都不允许提交"));
	return false;
}
