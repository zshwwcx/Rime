#include "ResourceCheck/RuleFunctions/Misc/FontAssetRule.h"
#include "Engine/FontFace.h"
UClass* UFontAssetRule::GetAssetType()
{
	return UFontFace::StaticClass();
}

bool UFontAssetRule::CheckFontFace(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	FString FontName = AssetData.AssetName.ToString();
	if(Params.ContainValue(TEXT("FontAssetName"), FontName))
	{
		return true;
	}
	Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("不合法的字体文件名字{}，应该在Key:FontAssetName之中"), FontName);
	return false;	
}