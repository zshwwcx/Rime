#include "ResourceCheck/RuleFunctions/Texture/SpriteAtlasGroupAssetRule.h"
#include "PaperSpriteAtlas.h"

UClass* USpriteAtlasGroupAssetRule::GetAssetType()
{
	return UPaperSpriteAtlas::StaticClass();
}

bool USpriteAtlasGroupAssetRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	CommonMax = FCString::Atoi(*Params.GetValue("CommonMax"));
	NormalMax = FCString::Atoi(*Params.GetValue("NormalMax"));
	CommonMaxSizePath = Params.GetValueList("CommonMaxSizePath");
	return true;
}

FString USpriteAtlasGroupAssetRule::GetUsedRatio(const FAssetData& AssetData)
{
	UPaperSpriteAtlas* PaperSpriteAtlas = Cast<UPaperSpriteAtlas>(AssetData.GetAsset());
	int64 UsedArea = 0;
	for (int i = 0; i < PaperSpriteAtlas->AtlasSlots.Num(); ++i)
	{
		const auto Atlas = PaperSpriteAtlas->AtlasSlots[i];
		if (!Atlas.SpriteRef.IsNull())
		{
			auto CArea = Atlas.Height * Atlas.Width;
			UsedArea += CArea;
		}
	}
	const int64 Area = PaperSpriteAtlas->BuiltHeight * PaperSpriteAtlas->BuiltWidth;
	const float UsedPercent = static_cast<float>(UsedArea) / static_cast<float>(Area);

	return FString::SanitizeFloat(UsedPercent);
}

FString USpriteAtlasGroupAssetRule::GetMaxSize(const FAssetData& AssetData)
{
	UPaperSpriteAtlas* PaperSpriteAtlas = Cast<UPaperSpriteAtlas>(AssetData.GetAsset());
	FString ObjectPath = PaperSpriteAtlas->GetPathName();
	for(auto Prefix : CommonMaxSizePath)
	{
		if(ObjectPath.StartsWith(Prefix))
		{
			return FString::FromInt(CommonMax);
		}
	}
	return FString::FromInt(NormalMax);
}