#include "ResourceCheck/RuleFunctions/Misc/TAPathSubmitCheckRule.h"

#include "ISourceControlModule.h"

UClass* UTAPathSubmitCheckRule::GetAssetType()
{
	return UObject::StaticClass();
}

bool UTAPathSubmitCheckRule::CheckP4Groups(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	const FString UserName = SourceControlProvider.GetWorkSpaceUserName();
	const FString Process = TEXT("p4");
	const FString Command = FString::Printf(TEXT("groups %s"), *UserName);

	int32 ResultCode;
	FString Result;
	FString ResultErr;

	const bool bProcessSuccess = FPlatformProcess::ExecProcess(*Process, *Command, &ResultCode, &Result, &ResultErr);
	TArray<FString> ValidP4Groups = Params.GetValueList("ValidP4Groups");
	if (bProcessSuccess && Result != "")
	{
		TArray<FString> SplitStrings;
		Result.TrimStartAndEnd().ParseIntoArray(SplitStrings, TEXT("\n"), false);
		for(auto SplitString : SplitStrings)
		{
			FString UserGroup = SplitString.TrimStartAndEnd();
			if (ValidP4Groups.Contains(UserGroup))
			{
				return true;
			}
		}
		Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("当前目录下不允许非引擎TA同学提交"));
		return false;
	}
	Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("P4返回结果出现问题，请重启引擎"));
	return false;
}
