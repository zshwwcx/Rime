// Fill out your copyright notice in the Description page of Project Settings.

#include "ResourceCheck/RuleFunctions/Actor/SkeletalMeshComponentRule.h"

bool USkeletalMeshComponentRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	VisibilityBasedAnimTickOptionWL = Params.GetValueList("VisibilityBasedAnimTickOptionWL");
	return true;
}

bool USkeletalMeshComponentRule::PreExecuteAsset(const FAssetData& AssetData)
{
	//需要包含SkeletalMeshComponent
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto SkeletalMeshComp = Cast<USkeletalMeshComponent>(Comp);
				if(SkeletalMeshComp)
				{
					return true;
				}
			}
		}
	}
	return false;	
}

bool USkeletalMeshComponentRule::CheckRVT(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
    	if(!Actor->IsEditorOnly())
    	{
    		for(auto Comp : Actor->GetComponents())
    		{
    			auto SkeletalMeshComp = Cast<USkeletalMeshComponent>(Comp);
    			if(SkeletalMeshComp)
    			{
    				bool bUsingRVT = false;
    				if(SkeletalMeshComp->RuntimeVirtualTextures.Num()>0)
    				{
    					bUsingRVT = true;
    				}

    				if(bUsingRVT)
    				{
    					Log.RegistryAndLog(AssetData, TEXT("SkeletalMeshComponent"), CheckRuleType, TEXT("{} : {} 骨骼模型不应该使用RVT")
							,Actor->GetName(), SkeletalMeshComp->GetName());
    					bSuccess = false;
    				}
    			}
    		}
    	}
    }
	return bSuccess; 
}

bool USkeletalMeshComponentRule::CheckSkeletalMeshValid(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				if(auto SkeletalMeshComponent = Cast<USkeletalMeshComponent>(Comp))
				{
					if (!SkeletalMeshComponent->GetSkinnedAsset())
					{
						Log.RegistryAndLog(AssetData, TEXT("SkeletalMeshComponent"), CheckRuleType, TEXT("Actor {} : {} 的 SkeletalMesh 不能为空."),
							Actor->GetActorLabel(), SkeletalMeshComponent->GetName());
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool USkeletalMeshComponentRule::CheckVisibilityBasedAnimTickOption(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly() && !VisibilityBasedAnimTickOptionWL.Contains(Actor->GetActorLabel()))
		{
			for(auto Comp : Actor->GetComponents())
			{
				if(auto SkeletalMeshComponent = Cast<USkeletalMeshComponent>(Comp))
				{
					if (SkeletalMeshComponent->VisibilityBasedAnimTickOption != EVisibilityBasedAnimTickOption::OnlyTickPoseWhenRendered)
					{
						Log.RegistryAndLog(AssetData, TEXT("SkeletalMeshComponent"), CheckRuleType, TEXT("Actor {} : {} 的基于动画tick的可视性选项需要设置为渲染时仅tick姿势."),
							Actor->GetActorLabel(), SkeletalMeshComponent->GetName());
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool USkeletalMeshComponentRule::RepairVisibilityBasedAnimTickOption(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				if(auto SkeletalMeshComponent = Cast<USkeletalMeshComponent>(Comp))
				{
					Actor->Modify();
					SkeletalMeshComponent->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::OnlyTickPoseWhenRendered;
					return Actor->GetPackage()->MarkPackageDirty();
				}
			}
		}
	}
	return false;
}
