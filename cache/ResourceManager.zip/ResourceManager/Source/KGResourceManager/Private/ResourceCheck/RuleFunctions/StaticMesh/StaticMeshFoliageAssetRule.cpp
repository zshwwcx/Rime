#include "ResourceCheck/RuleFunctions/StaticMesh/StaticMeshFoliageAssetRule.h"

#include "FoliageType_InstancedStaticMesh.h"
#include "ResourceCheck/ResourceCheckHelper.h"

FString UStaticMeshFoliageAssetRule::CullDistancePropertyName = "CullDistanceMax";

UClass* UStaticMeshFoliageAssetRule::GetAssetType()
{
	return UFoliageType_InstancedStaticMesh::StaticClass();
}

bool UStaticMeshFoliageAssetRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	Super::PreExecuteAllObject(InAssetDataList);
	TArray<FString> CullDistanceRangeString = Params.GetValueList(TEXT("CullDistanceRange"));
	TArray<FString> CullDistanceValueString = Params.GetValueList(TEXT("CullDistanceValue"));
	for (const auto& RangeString : CullDistanceRangeString)
	{
		CullDistanceRange.Add(FCString::Atoi(*RangeString));
	}
	for (const auto& ValueString : CullDistanceValueString)
	{
		CullDistanceValue.Add(FCString::Atoi(*ValueString));
	}
	return true;
}

bool UStaticMeshFoliageAssetRule::PostExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	CullDistanceRange.Empty();
	CullDistanceValue.Empty();
	return Super::PostExecuteAllObject(InAssetDataList);
}

FString UStaticMeshFoliageAssetRule::WithForceWPOMaterial(const FAssetData& AssetData)
{
	if(UFoliageType_InstancedStaticMesh* StaticMeshFoliage = Cast<UFoliageType_InstancedStaticMesh>(AssetData.GetAsset()))
	{
		if(auto StaticMesh = StaticMeshFoliage->Mesh)
		{
			for(const auto &StaticMat : StaticMesh->GetStaticMaterials())
			{
				if(HasForceWPOMaterial(StaticMat))
				{
					return "1";
				}
			}
		}
	}
	return "0";
}

bool UStaticMeshFoliageAssetRule::HasForceWPOMaterial(const FStaticMaterial& StaticMaterial)
{
	TArray<FString> ForceWPOMaterial = Params.GetValueList(TEXT("ForceWPOMaterial"));
	if(auto MaterialInstance = Cast<UMaterialInstance>(StaticMaterial.MaterialInterface.Get()))
	{
		while (MaterialInstance)
		{
			auto ParentMat = MaterialInstance->Parent;
			if(ParentMat && ForceWPOMaterial.Contains(ParentMat.GetName()))
			{
				return true;
			}
			MaterialInstance =  Cast<UMaterialInstance>(MaterialInstance->Parent);
		}
	}
	return false;
}

bool UStaticMeshFoliageAssetRule::CheckCullDistanceMax(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UFoliageType_InstancedStaticMesh* StaticMeshFoliage = Cast<UFoliageType_InstancedStaticMesh>(AssetData.GetAsset()))
	{
		if (UStaticMesh* StaticMesh = StaticMeshFoliage->GetStaticMesh())
		{
			UE::Math::TVector<double> Size = StaticMesh->GetBoundingBox().GetSize();
			const double SideMax = FMath::Max3(Size.X, Size.Y, Size.Z);
			const double CheckVal = SideMax * StaticMeshFoliage->ScaleX.Max;
			int32 ValMin = 0;
			for (int32 Index = 0; Index < CullDistanceRange.Num(); Index++)
			{
				if (CheckVal <= CullDistanceRange[Index])
				{
					const int32 StandardVal = CullDistanceValue[Index];
					if (StaticMeshFoliage->CullDistance.Max != StandardVal)
					{
						Log.RegistryAndLog(AssetData, TEXT("StaticMeshFoliage"), CheckRuleType, TEXT("检查值在 {} ~ {} 内，Cull Distance Max 应该设置为 {}"),
							ValMin, CullDistanceRange[Index], StandardVal);
						OutRepairParams.Add(CullDistancePropertyName, FString::FromInt(StandardVal));
						bSuccess = false;
					}
					break;
				}
				ValMin = CullDistanceRange[Index];
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshFoliageAssetRule::RepairCullDistanceMax(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	if (InRepairParams.Contains(CullDistancePropertyName))
	{
		if(UFoliageType_InstancedStaticMesh* StaticMeshFoliage = Cast<UFoliageType_InstancedStaticMesh>(AssetData.GetAsset()))
		{
			StaticMeshFoliage->CullDistance.Max = FCString::Atoi(*InRepairParams[CullDistancePropertyName]);
			StaticMeshFoliage->Modify();
			StaticMeshFoliage->GetPackage()->MarkPackageDirty();
			return true;
		}
	}
	return false;
}

bool UStaticMeshFoliageAssetRule::ForceWPOMaterialCastContactShadow(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UFoliageType_InstancedStaticMesh* StaticMeshFoliage = Cast<UFoliageType_InstancedStaticMesh>(AssetData.GetAsset()))
	{
		if(auto StaticMesh = StaticMeshFoliage->Mesh)
		{
			for(const auto &StaticMat : StaticMesh->GetStaticMaterials())
			{
				if(HasForceWPOMaterial(StaticMat))
				{
					if (StaticMeshFoliage->bCastContactShadow == false || StaticMeshFoliage->bCastDynamicShadow == true || StaticMeshFoliage->bCastStaticShadow == true)
					{
						Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType,TEXT("静态模型{}具有风动植被材质应该关闭动态阴影和静态阴影，打开接触阴影"), StaticMesh->GetName());
						OutRepairParams.FindOrAdd(TEXT("bCastContactShadow")) = TEXT("true");
						OutRepairParams.FindOrAdd(TEXT("bCastDynamicShadow")) = TEXT("false");
						OutRepairParams.FindOrAdd(TEXT("bCastStaticShadow")) = TEXT("false");
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshFoliageAssetRule::RepairWPOMaterialCastContactShadow(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	if (UFoliageType_InstancedStaticMesh* StaticMeshFoliage = Cast<UFoliageType_InstancedStaticMesh>(AssetData.GetAsset()))
	{
		if (InRepairParams.Contains(TEXT("bCastContactShadow")))
		{
			StaticMeshFoliage->bCastContactShadow = InRepairParams[TEXT("bCastContactShadow")].ToBool();
		}
		if (InRepairParams.Contains(TEXT("bCastDynamicShadow")))
		{
			StaticMeshFoliage->bCastDynamicShadow = InRepairParams[TEXT("bCastDynamicShadow")].ToBool();
		}
		if (InRepairParams.Contains(TEXT("bCastStaticShadow")))
		{
			StaticMeshFoliage->bCastStaticShadow = InRepairParams[TEXT("bCastStaticShadow")].ToBool();
		}
		return true;
	}
	return false;
}
