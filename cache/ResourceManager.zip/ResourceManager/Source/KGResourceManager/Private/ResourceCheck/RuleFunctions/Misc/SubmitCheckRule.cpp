#include "ResourceCheck/RuleFunctions/Misc/SubmitCheckRule.h"
#include "Settings/ProjectPackagingSettings.h"
#include "ISourceControlState.h"
#include "ISourceControlProvider.h"
#include "ISourceControlModule.h"
#include "SourceControlHelpers.h"
#include "AssetRegistry/AssetRegistryModule.h"

UClass* USubmitCheckRule::GetAssetType()
{
	return UObject::StaticClass();
}

bool USubmitCheckRule::PreExecuteAsset(const FAssetData& AssetData)
{
	FString PackageName = AssetData.PackagePath.ToString();

	// 技能资源也需要进行检查，返回true
	if (PackageName.StartsWith(TEXT("/Game/EditorTemplate/Skill")))
	{
		return true;
	}
	
	if (IsNeverCook(PackageName) && !PackageName.StartsWith("/Game/Editor/"))
	{
		return false;
	}
	return true;
}

bool USubmitCheckRule::P4Connected(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	FString AbsoluteFilePath = FPackageName::LongPackageNameToFilename(AssetData.PackagePath.ToString());
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	FSourceControlStatePtr SourceControlState = SourceControlProvider.GetState(AbsoluteFilePath, EStateCacheUsage::Use);

	if(!SourceControlState.IsValid())
	{
		Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("资源未和P4进行关联。"));
		return false;
	}
	return true;
}

bool USubmitCheckRule::CheckLinker(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	auto AssetPackage = AssetData.GetPackage();
	if (AssetPackage == nullptr)
	{
		return true;
	}
	if (auto Linker = AssetPackage->GetLinker())
	{
		if (Linker->Summary.Tag != PACKAGE_FILE_TAG)
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("资源文件头损坏，请验证并重新保存."));
			return false;
		}
	}
	return true;
}

bool USubmitCheckRule::CheckDependAssetInChangeList(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FName AssetPackageName = AssetData.PackageName;
	
	TArray<FName> DependAssetList;
	if (AssetRegistryModule.Get().GetDependencies(AssetPackageName, DependAssetList))
	{
		TArray<FString> DependAssetArray;
		TMap<FString, FName> FullDependPath2AssetName;
		for (const auto& DependAsset : DependAssetList)
		{
			FString FileName;
			if (!FPackageName::TryConvertLongPackageNameToFilename(DependAsset.ToString(), FileName))
			{
				Log.RegistryAndLog(AssetData ,TEXT("SubmitCheck"), CheckRuleType, TEXT("依赖的资源{}在UE转化路径时失败，可能是UE找不到该依赖资源."), DependAsset);
				bSuccess = false;
				continue;
			}
			const FString FullDependPath = FPaths::ConvertRelativePathToFull(DependAsset.ToString());
			const FString AssetFullDependPath = FPaths::ConvertRelativePathToFull(FileName) + FPackageName::GetAssetPackageExtension();
			const FString MapFullDependPath = FPaths::ConvertRelativePathToFull(FileName) + FPackageName::GetMapPackageExtension();
			if (FullDependPath.StartsWith(TEXT("/Game/")))
			{
				if (FPaths::FileExists(AssetFullDependPath))
				{
					DependAssetArray.Add(AssetFullDependPath);
					FullDependPath2AssetName.FindOrAdd(AssetFullDependPath) = DependAsset;
				}
				else if (FPaths::FileExists(MapFullDependPath))
				{
					DependAssetArray.Add(MapFullDependPath);
					FullDependPath2AssetName.FindOrAdd(MapFullDependPath) = DependAsset;
				}
				else
				{
					Log.RegistryAndLog(AssetData ,TEXT("SubmitCheck"), CheckRuleType, TEXT("依赖的资源{}的源文件不存在."), DependAsset);
					bSuccess = false;
				}

				if(IsNeverCook(AssetFullDependPath))
				{
					Log.RegistryAndLog(AssetData ,TEXT("SubmitCheck"), CheckRuleType, TEXT("依赖的资源{}位于NeverCook目录."), DependAsset);
					bSuccess = false;
				}
			}
		}
		ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
		const FString SourceFileName = USourceControlHelpers::PackageFilename(AssetData.PackageName.ToString());
		FSourceControlStatePtr SourceFileState = SourceControlProvider.GetState(SourceFileName, EStateCacheUsage::ForceUpdate);
		if (!SourceFileState->IsCheckedOut() && !SourceFileState->IsAdded())
		{
			return bSuccess;
		}
		const FString SourceChangeListID = SourceFileState->GetCheckInIdentifier()->GetIdentifier();
		TArray<FSourceControlStateRef> States;
		SourceControlProvider.GetState(DependAssetArray, States, EStateCacheUsage::Use);

		for (auto State : States)
		{
			FString FullDependPath = State->GetFilename();
			if (!FPaths::FileExists(FullDependPath))
			{
				continue;
			}
			if (!FullDependPath2AssetName.Contains(FullDependPath))
			{
				continue;
			}
			// 如果文件不是Add状态并且未被版本控制，或者add了但不在同一个changelist里都应拦截
			bool bPassed = true;
			if (!State->IsAdded())
			{
				if (!State->IsSourceControlled())
				{
					bPassed = false;
				}
			}
			else
			{
				if (State->GetCheckInIdentifier()->GetIdentifier() != SourceChangeListID)
				{
					bPassed = false;
				}
			}

			if (!bPassed)
			{
				Log.RegistryAndLog(AssetData ,TEXT("SubmitCheck"), CheckRuleType, TEXT("依赖的资源 {} 忘记提交."), FullDependPath2AssetName[FullDependPath]);
				bSuccess = false;
			}
		}
	}
	return bSuccess;
}

bool USubmitCheckRule::CheckDependArtsTest(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FName AssetPackageName = AssetData.PackageName;
	
	TArray<FName> DependAssetList;
	if (AssetRegistryModule.Get().GetDependencies(AssetPackageName, DependAssetList))
	{
		TArray<FString> UnPackagedDirectory = Params.GetValueList("UnPackagedDirectory");
		TArray<FString> UnPackagedWhiteDirectory = Params.GetValueList("UnPackagedWhiteDirectory");
		for (const auto& DependAsset : DependAssetList)
		{
			const FString FullDependPath = FPaths::ConvertRelativePathToFull(DependAsset.ToString());
			for (auto Directory : UnPackagedDirectory)
			{
				if (FullDependPath.StartsWith(Directory))
				{
					bool bInWhiteDirectory = false;
					for (auto WhiteDirectory : UnPackagedWhiteDirectory)
					{
						if (FullDependPath.StartsWith(WhiteDirectory))
						{
							bInWhiteDirectory = true;
							break;
						}
					}
					if (!bInWhiteDirectory)
					{
						Log.RegistryAndLog(AssetData ,TEXT("SubmitCheck"), CheckRuleType, TEXT("依赖了不进包目录{}的资源:{}"), Directory, FullDependPath);
						bSuccess = false;
						break;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool USubmitCheckRule::IsNeverCook(const FString InPackageName)
{
	//NeverCook
	bool bNeverCook = false;
	const UProjectPackagingSettings* const PackagingSettings = GetDefault<UProjectPackagingSettings>();
	if(PackagingSettings && PackagingSettings->DirectoriesToNeverCook.Num() > 0)
	{
		for (auto& NeverCook : PackagingSettings->DirectoriesToNeverCook)
		{
			if (InPackageName.StartsWith(NeverCook.Path))
			{
				bNeverCook = true;
				break;
			}
		}
	}
	return bNeverCook;
}
