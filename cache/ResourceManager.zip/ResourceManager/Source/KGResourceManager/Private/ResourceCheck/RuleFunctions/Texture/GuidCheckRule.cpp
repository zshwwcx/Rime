#include "ResourceCheck/RuleFunctions/Texture/GuidCheckRule.h"
#include "ISourceControlState.h"
#include "ISourceControlProvider.h"
#include "ISourceControlModule.h"
#include "Http.h"
#include "HttpModule.h"
#include "HttpManager.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "FileHelpers.h"

UClass* UGuidCheckRule::GetAssetType()
{
	return UTexture::StaticClass();
}

bool UGuidCheckRule::TextureGuidCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	UTexture* Texture = Cast<UTexture>(AssetData.GetAsset());
	if(Texture && Texture->GetPackage())
	{
		FString AbsoultePath = FResourceCheckHelper::GetAbsoultePath(AssetData);
		FString LoadObjectPath = Texture->GetPathName();
		ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
		FSourceControlStatePtr SourceControlState = SourceControlProvider.GetState(AbsoultePath, EStateCacheUsage::Use);

		FGuid SubmitedLightingGuid = Texture->GetLightingGuid();		
		FTextureStatus TextureStatus;

		TextureStatus.AssetData = AssetData;
		TextureStatus.Guid = SubmitedLightingGuid;
		TextureStatus.State = SourceControlState;
		TextureStatus.AbsoluteFilePath = AbsoultePath;
		TextureStatus.Texture = Texture;
		TextureStatus.LoadObjectPath = LoadObjectPath;

		if (TextureStatus.State->IsDeleted())
		{
			return true;
		}

		FString LoadedPackagePath = AssetData.GetObjectPathString();
		if (GuidToLoadObjectName.Contains(TextureStatus.Guid))
		{
			if(GuidToLoadObjectName[TextureStatus.Guid] != LoadedPackagePath)
			{
				Log.RegistryAndLog(AssetData, TEXT("Guid"), CheckRuleType, TEXT("与本地资源:{}存在Guid冲突"), GuidToLoadObjectName[TextureStatus.Guid]);
				return false;
			}
		}

		GuidToLoadObjectName.FindOrAdd(SubmitedLightingGuid) = LoadObjectPath;
		LoadObjectNameToTextureStatus.FindOrAdd(LoadObjectPath) = TextureStatus;

		int32 LastLogNum = Log.LogInfos.Num();

		FEvent* GetGuidDataByHttpEvent = FPlatformProcess::GetSynchEventFromPool(true);
		GetGuidDataByHttp(TextureStatus, GetGuidDataByHttpEvent, [GetGuidDataByHttpEvent]()
		{
			GetGuidDataByHttpEvent->Trigger();
		});
		
		FPlatformProcess::ReturnSynchEventToPool(GetGuidDataByHttpEvent);
		if(LastLogNum < Log.LogInfos.Num())
		{
			return false;
		}
	}
	return true;
}

void UGuidCheckRule::GetGuidDataByHttp(FTextureStatus InTextureStatus, FEvent* GetGuidDataByHttpEvent, FVoidCallback InCallBack)
{
	TSharedPtr<FJsonObject> SearchJsonObject = MakeShareable(new FJsonObject);
	TArray<TSharedPtr<FJsonValue>> GuidList;

	FString OutputString;
	TSharedRef<TJsonWriter<>> JsonWriter = TJsonWriterFactory<>::Create(&OutputString);
	SearchJsonObject->SetStringField("Project", ProjectName);
	SearchJsonObject->SetStringField("Branch", BranchName);
	SearchJsonObject->SetStringField("Guid", InTextureStatus.Guid.ToString());
	FJsonSerializer::Serialize(SearchJsonObject.ToSharedRef(), JsonWriter);

	TSharedRef<IHttpRequest> Request = FHttpModule::Get().CreateRequest();
	Request->SetURL("https://ueguid-c7.staging.kuaishou.com/v1/guid/get");
	Request->SetVerb("POST");
	Request->SetHeader(TEXT("accept"), TEXT("application/json"));
	Request->SetHeader(TEXT("X-Access-Token"), TEXT("ueguidserver"));
	Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));
	Request->SetContentAsString(OutputString);

	Request->OnProcessRequestComplete().BindLambda([&](FHttpRequestPtr InRequest, FHttpResponsePtr InResponse, bool bWasSuccessful)
	{
		if (bWasSuccessful && InResponse.IsValid() && InResponse->GetResponseCode() == 200)
		{			
			FString ResponseString = InResponse->GetContentAsString();
			TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject);
			TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(ResponseString);
			if (FJsonSerializer::Deserialize(JsonReader, JsonObject))
			{
				TSharedPtr<FJsonObject> JsonDataObject = JsonObject->GetObjectField(TEXT("data"));
				int32 Count = JsonDataObject->GetIntegerField(TEXT("count"));
				if (Count > 0)
				{
					TArray<TSharedPtr<FJsonValue>> JsonArrayDataValue = JsonDataObject->GetArrayField(TEXT("data"));
					TSet<FString> RedisNames;
					for (const auto& DataValue : JsonArrayDataValue)
					{
						TSharedPtr<FJsonObject> RedisDataObject = DataValue->AsObject();
						FString RedisFName = RedisDataObject->GetStringField(TEXT("path"));
						if(RedisNames.Contains(RedisFName))
						{
							continue;
						}						
						if (!LoadObjectNameToTextureStatus.Contains(RedisFName) && RedisFName != InTextureStatus.LoadObjectPath)
						{
							Log.RegistryAndLog(InTextureStatus.AssetData, TEXT("Guid"), CheckRuleType, TEXT("与数据库资源:{} 存在Guid冲突"), RedisFName);
						}
						RedisNames.Add(RedisFName);
					}
				}
			}
			InCallBack();
		}
	});
	Request->ProcessRequest();
	
	while (!GetGuidDataByHttpEvent->Wait(100))
	{
		FHttpModule::Get().GetHttpManager().Tick(0.1);
	}
	GetGuidDataByHttpEvent->Reset();
}

void UGuidCheckRule::SendGuidDataByHttp(FEvent* SendGuidDataByHttpEvent, FVoidCallback InCallBack)
{
	TSharedPtr<FJsonObject> SubmitJsonObject = MakeShareable(new FJsonObject);

	FString OutputString;
	TSharedRef<TJsonWriter<>> JsonWriter = TJsonWriterFactory<>::Create(&OutputString);
	SubmitJsonObject->SetStringField("Project", ProjectName);
	SubmitJsonObject->SetStringField("Branch", BranchName);

	TArray<TSharedPtr<FJsonValue>> DataList;
	for (auto& KeyValue : LoadObjectNameToTextureStatus)
	{
		const FString& LoadObjectName = KeyValue.Key;
		const FTextureStatus& Texture2DStatus = KeyValue.Value;
		const FSourceControlStatePtr& State = Texture2DStatus.State;
				
		TSharedPtr<FJsonObject> NewJsonObject = MakeShareable(new FJsonObject);
		NewJsonObject->SetStringField("guid", Texture2DStatus.Guid.ToString());
		NewJsonObject->SetStringField("path", LoadObjectName);
		if (State->IsDeleted())
		{
			NewJsonObject->SetStringField("status", "D");
		}
		else if (State->IsAdded())
		{
			NewJsonObject->SetStringField("status", "A");
		}
		else
		{
			NewJsonObject->SetStringField("status", "M");
		}
		
		DataList.Add(MakeShareable(new FJsonValueObject(NewJsonObject)));
	}

	SubmitJsonObject->SetArrayField("Data", DataList);
	FJsonSerializer::Serialize(SubmitJsonObject.ToSharedRef(), JsonWriter);
		
	TSharedRef<IHttpRequest> Request = FHttpModule::Get().CreateRequest();
	Request->SetURL("https://ueguid-c7.staging.kuaishou.com/v1/file/change");
	Request->SetVerb("POST");
	Request->SetHeader(TEXT("accept"), TEXT("application/json"));
	Request->SetHeader(TEXT("X-Access-Token"), TEXT("ueguidserver"));
	Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));

	Request->SetContentAsString(OutputString);
	Request->OnProcessRequestComplete().BindLambda([&](FHttpRequestPtr InRequest, FHttpResponsePtr InResponse, bool bWasSuccessful)
	{
		InCallBack();
	});
	
	Request->ProcessRequest();

	while (!SendGuidDataByHttpEvent->Wait(100))
	{
		FHttpModule::Get().GetHttpManager().Tick(0.1);
	}
	SendGuidDataByHttpEvent->Reset();
}

bool UGuidCheckRule::RepairGuid(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	// 重新保存以重新生成 guid
	if (UObject* Asset = AssetData.GetAsset())
	{
		Asset->PostEditChange();
	}
	return UEditorLoadingAndSavingUtils::SavePackages({AssetData.GetPackage()}, false);
}

void UGuidCheckRule::PreCheckIn(TArray<FAssetData> InFiles, TSharedPtr<FPerforceSourceControlProviderDelegatesPackage> InPackage)
{
	ProjectName = FApp::GetProjectName();
	BranchName = FResourceCheckHelper::GetBranchName(InPackage->Workspace);
}

// 后处理
void UGuidCheckRule::PostCheckIn(TArray<FAssetData> InFiles, TSharedPtr<FPerforceSourceControlProviderDelegatesPackage> InPackage)
{
	if(InPackage->Result == ECommandResult::Succeeded)
	{
		FEvent* SendGuidDataByHttpEvent = FPlatformProcess::GetSynchEventFromPool(true);
		SendGuidDataByHttp(SendGuidDataByHttpEvent, [SendGuidDataByHttpEvent]()
		{
			SendGuidDataByHttpEvent->Trigger();
		});
	
		FPlatformProcess::ReturnSynchEventToPool(SendGuidDataByHttpEvent);
	}		
}
