// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/RuleFunctions/Avatar/AvatarProfileRule.h"

#include "Asset/AvatarProfile.h"
#include "Asset/MakeupProfile.h"
#include "Asset/MakeupProperty.h"
#include "Utils/AvatarCreatorUtils.h"

UClass* UAvatarProfileRule::GetAssetType()
{
	return UAvatarProfile::StaticClass();
}

bool UAvatarProfileRule::CheckNameRepeat(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UAvatarProfile* AvatarProfile = Cast<UAvatarProfile>(AssetData.GetAsset()))
	{
		if (UMakeupProfile* MakeupProfile = AvatarProfile->MakeupProfile)
		{
			TSet<FString> NameSet;
			for (const FMakeupPropertyConfig& Config : MakeupProfile->PropertyConfigs)
			{
				if (NameSet.Contains(Config.Name))
				{
					Log.RegistryAndLog(AssetData, TEXT("MakeupProfile"), CheckRuleType, TEXT("捏脸设置参数 {} 和其他的捏脸设置参数使用了相同的参数名称 {}"),
									Config.ChineseName, Config.Name);
					bSuccess = false;
				}
				NameSet.Add(Config.Name);
			}
		}
	}
	return bSuccess;
}

bool UAvatarProfileRule::CheckMaterialRepeat(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UAvatarProfile* AvatarProfile = Cast<UAvatarProfile>(AssetData.GetAsset()))
	{
		if (UMakeupProfile* MakeupProfile = AvatarProfile->MakeupProfile)
		{
			TMap<FString, TSet<FString>> PartAndSlotName2PropertyNames;
			TMap<FString, FString> PartSlotAndPropertyName2ConfigName;
			for (const FMakeupPropertyConfig& Config : MakeupProfile->PropertyConfigs)
			{
				const FString PartAndSlotName = AvatarCreatorUtils::EnumToString(Config.BodyPartType) + "__" + Config.SlotName.ToString();
				const FString PartSlotAndPropertyName = PartAndSlotName + "__" + Config.MaterialPropertyName;
				if (!PartAndSlotName2PropertyNames.Contains(PartAndSlotName))
				{
					PartAndSlotName2PropertyNames.Add(PartAndSlotName, {Config.MaterialPropertyName});
					PartSlotAndPropertyName2ConfigName.Add(PartSlotAndPropertyName, Config.ChineseName);
				}
				else
				{
					// BodyPartType 相同且 slotname 相同，Material Property Name 不能重复
					if (PartAndSlotName2PropertyNames[PartAndSlotName].Contains(Config.MaterialPropertyName))
					{
						Log.RegistryAndLog(AssetData, TEXT("MakeupProfile"), CheckRuleType, TEXT("捏脸设置参数 {} 和捏脸设置参数 {} 使用了相同的BodyPartType, 插槽名 {} 和材质名字 {}"),
							Config.ChineseName, PartSlotAndPropertyName2ConfigName[PartSlotAndPropertyName], Config.SlotName.ToString(), Config.MaterialPropertyName);
						bSuccess = false;
					}
					else
					{
						PartAndSlotName2PropertyNames[PartAndSlotName].Add(Config.MaterialPropertyName);
						PartSlotAndPropertyName2ConfigName.Add(PartSlotAndPropertyName, Config.ChineseName);
					}
				}
			}
		}
	}
	return bSuccess;
}