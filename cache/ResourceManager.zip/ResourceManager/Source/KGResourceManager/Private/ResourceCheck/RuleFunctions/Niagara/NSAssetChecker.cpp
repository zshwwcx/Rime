// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: huxingjian03@kuaishou.com

#include "ResourceCheck/RuleFunctions/Niagara/NSAssetChecker.h"

#pragma region FNSAssetCheckerUtils: Stat 工具相关
#if WITH_EDITOR
double FNSAssetCheckerUtils::GetStatCounter(UObject* WorldContextObject, FName StatGroupName, FName StatName)
{
#if STATS
	const FString GroupNameString = FString(TEXT("STATGROUP_")) + FString(StatGroupName.ToString());
	const FName GroupNameFull = FName(*GroupNameString, EFindName::FNAME_Find);
	FGameThreadStatsData* StatsData = FLatestGameThreadStatsData::Get().Latest;

	if (StatsData && StatsData->GroupNames.Contains(GroupNameFull)) // stat中已有StatGroupName
	{
		for (FActiveStatGroupInfo ActiveStatGroup : StatsData->ActiveStatGroups)
		{
			for (FComplexStatMessage CountersAggregate : ActiveStatGroup.CountersAggregate)
			{
				FName Name = CountersAggregate.GetShortName();
				if (Name == StatName)
				{
					return CountersAggregate.GetValue_double(EComplexStatField::IncAve);
				}
			}
		}
	}
	else // 开启stat
	{
		// 这种写法 PIE 和 Editor 下都能生效。不能抄 UAutomationBlueprintFunctionLibrary::EnableStatGroup() 的写法，它只能在 PIE 下生效。
		UKismetSystemLibrary::ExecuteConsoleCommand(WorldContextObject, FString(TEXT("stat ")) + FString(StatGroupName.ToString()) + FString(TEXT(" -nodisplay")));
	}
	return 0;
#endif
}

void FNSAssetCheckerUtils::GetNiagaraNumParticles(UObject* WorldContextObject, int32& CPUParticlesNum, int32& GPUParticlesNum, int32& CPUEmittersNum, int32& GPUEmittersNum)
{
	UWorld* World = nullptr;
	World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);
	if (!World) 
		return;

	TArray<UNiagaraComponent*> NiagaraComponents;
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		AActor* Actor = *It;
		if (Actor)
		{
			TArray<UNiagaraComponent*> Components;
			Actor->GetComponents(UNiagaraComponent::StaticClass(), Components, true);
			NiagaraComponents.Append(Components);
		}
	}

	CPUParticlesNum = 0;
	GPUParticlesNum = 0; 
	CPUEmittersNum = 0; 
	GPUEmittersNum = 0;

	for (UNiagaraComponent* NiagaraComponent : NiagaraComponents)
	{
		if (!NiagaraComponent || !NiagaraComponent->IsActive() || !NiagaraComponent->GetAsset())
		{
			continue;
		}

		UNiagaraSystem* NiagaraSystem = NiagaraComponent->GetAsset();
		FString NiagaraSystemName = NiagaraSystem->GetPackage()->GetName();
		TArrayView<TSharedRef<FNiagaraEmitterInstance>> NiagaraEmitterInstances = NiagaraComponent->GetSystemInstanceController()->GetSystemInstance_Unsafe()->GetEmitters();

		for (TSharedRef<FNiagaraEmitterInstance> NiagaraEmitterInstance : NiagaraEmitterInstances)
		{
			//发射器数量
			if (NiagaraEmitterInstance->IsActive())
			{

				//粒子数量(CPU/GPU)
				if (NiagaraEmitterInstance->GetSimTarget() == ENiagaraSimTarget::GPUComputeSim)
				{
					GPUParticlesNum += NiagaraEmitterInstance->GetNumParticles();
					GPUEmittersNum += 1;
				}
				else
				{
					CPUParticlesNum += NiagaraEmitterInstance->GetNumParticles();
					CPUEmittersNum += 1;
				}
			}
		}
	}
}
#endif // WITH_EDITOR
#pragma endregion FNSAssetCheckerUtils: Stat 工具相关

#pragma region FNSAssetCheckerUtils: File 工具相关
#if WITH_EDITOR
bool FNSAssetCheckerUtils::SaveStringToFile(const FString& StringContent, const FString& FilePath)
{
	return FFileHelper::SaveStringToFile(StringContent, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8);
}

bool FNSAssetCheckerUtils::SaveStringArrayToFile(const TArray<FString>& StringArrayContent, const FString& FilePath)
{
	return FFileHelper::SaveStringArrayToFile(StringArrayContent, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8);
}

bool FNSAssetCheckerUtils::LoadFileToString(FString& StringContent, const FString& FilePath)
{
	return FFileHelper::LoadFileToString(StringContent, *FilePath);
}

bool FNSAssetCheckerUtils::LoadFileToStringArray(TArray<FString>& StringArrayContent, const FString& FilePath)
{
	return FFileHelper::LoadFileToStringArray(StringArrayContent, *FilePath);
}
#endif // WITH_EDITOR
#pragma endregion FNSAssetCheckerUtils: File 工具相关

#pragma region FNSAssetCheckerUtils: AnimNotify 工具相关
#if WITH_EDITOR
UAnimNotify* FNSAssetCheckerUtils::GetAnimationNotifyEvent_AnimNotify(const FAnimNotifyEvent& NotifyEvent)
{
	return NotifyEvent.Notify;
}

UAnimNotifyState* FNSAssetCheckerUtils::GetAnimationNotifyEvent_AnimNotifyState(const FAnimNotifyEvent& NotifyEvent)
{
	return NotifyEvent.NotifyStateClass;
}

void FNSAssetCheckerUtils::GetAnimationNotifyEvent_TrackNameIndex(const UAnimSequenceBase* AnimationSequenceBase, const FAnimNotifyEvent& NotifyEvent, 
	FName& TrackName, int& TrackIndex)
{
	TrackIndex = NotifyEvent.TrackIndex;
	TrackName = AnimationSequenceBase->AnimNotifyTracks[TrackIndex].TrackName;
}

void FNSAssetCheckerUtils::GetProperty_UAnimNotify_PlayNiagaraEffect(const UAnimNotify_PlayNiagaraEffect* AnimNotify,
	UNiagaraSystem*& NSTemplate, FVector& LocationOffset, FRotator& RotationOffset, FVector& Scale, bool& bAbsoluteScale, FName& SocketName)
{
	NSTemplate = AnimNotify->Template;
	LocationOffset = AnimNotify->LocationOffset;
	RotationOffset = AnimNotify->RotationOffset;
	Scale = AnimNotify->Scale;
	bAbsoluteScale = AnimNotify->bAbsoluteScale;
	SocketName = AnimNotify->SocketName;
}

void FNSAssetCheckerUtils::GetProperty_UAnimNotifyState_TimedNiagaraEffect(const UAnimNotifyState_TimedNiagaraEffect* AnimNotify,
	UNiagaraSystem*& NSTemplate, FVector& LocationOffset, FRotator& RotationOffset, FName& SocketName)
{
	NSTemplate = AnimNotify->Template;
	LocationOffset = AnimNotify->LocationOffset;
	RotationOffset = AnimNotify->RotationOffset;
	SocketName = AnimNotify->SocketName;
}

void FNSAssetCheckerUtils::SetProperty_UAnimNotifyState_C7TimedNiagaraEffect(UAnimNotifyState_C7TimedNiagaraEffect* AnimNotify,
	const UNiagaraSystem* NSTemplate, const FTransform& Transform, bool bAbsoluteScale, FName SocketName)
{
	AnimNotify->TemplatePath = NSTemplate;
	AnimNotify->Transform = Transform;
	AnimNotify->bAbsoluteScale = bAbsoluteScale;
	AnimNotify->SocketName = SocketName;
}
#endif // WITH_EDITOR
#pragma endregion FNSAssetCheckerUtils: AnimNotify 工具相关

#pragma region FNSAssetCheckerUtils: 母材质光照设置修改相关
#if WITH_EDITOR
bool FNSAssetCheckerUtils::Is_SurfacePerPixelLighting(UMaterial* Mat)
{
	return Mat->TranslucencyLightingMode == ETranslucencyLightingMode::TLM_SurfacePerPixelLighting;
}

void FNSAssetCheckerUtils::Change_TranslucencyLightingMode_To_VolumetricDirectional(UMaterial* MatIn, UMaterial*& MatRet)
{
	MatRet = MatIn;
	MatRet->TranslucencyLightingMode = ETranslucencyLightingMode::TLM_VolumetricDirectional;
}
#endif // WITH_EDITOR
#pragma endregion FNSAssetCheckerUtils: 母材质光照设置修改相关

#pragma region FNSAssetCheckerUtils: NS 相关
#if WITH_EDITOR
// 判断一个 NS 里是否有激活的 Light Renderer
bool FNSAssetCheckerUtils::Niagara_HasActiveLightRenderer(const UNiagaraSystem* NiagaraSystem)
{
	if (!NiagaraSystem)
	{
		return false;
	}

	// 遍历系统里的所有 EmitterHandle
	for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
	{
		if (Handle.GetIsEnabled())
		{
			const FVersionedNiagaraEmitter& Emitter = Handle.GetInstance();
			if (FVersionedNiagaraEmitterData* EmitterData = Emitter.GetEmitterData())
			{
				const TArray<UNiagaraRendererProperties*>& Renderers = EmitterData->GetRenderers();
				const TArray<UNiagaraRendererProperties*>& EnabledRenderers = Renderers.FilterByPredicate([](const UNiagaraRendererProperties* Renderer) {return Renderer->bIsEnabled; });
				if (EnabledRenderers.IsEmpty())
				{
					continue;
				}
				// 遍历 Emitter 里的所有激活的 Renderer
				for (UNiagaraRendererProperties* Renderer : EnabledRenderers)
				{
					if (Renderer->IsA<UNiagaraLightRendererProperties>())
					{
						return true; // 抓到一个活的 Light Renderer
					}
				}
			}
		}
	}

	return false;
}

// 判断一个 Emitter 是否有不被杀死的 Loop 粒子泄露 // 用于 CI 检测，没有暴露对应的蓝图节点 
// 
// 判断逻辑：
// 1. Particle 得是无限生命的：无限循环 或 永远不被杀死
// 且
// 2. Emitter 得是无限发射的：无限循环发射 或 （单次循环时间无限 且 在这单次循环时用 SpawnRate 不断发射）
//
// 这整个函数都很丑陋。。。主要是判断一个 Emitter 是否循环泄露，确实也只能穷举各种可能性了。。。
bool FNSAssetCheckerUtils::Niagara_IsEmitterLoopLeaking(const UNiagaraSystem* NiagaraSystem, const FVersionedNiagaraEmitter& Emitter,
	bool& bSpawnRate, bool& bInfiniteParticle, bool& bInfiniteEmitter, bool& bInfiniteNiagara)
{
	bool bFinalRet = false;

	bSpawnRate = false; // 这个 Emitter 是否含有 SpawnRate 模块
	bInfiniteParticle = false; // 粒子是否永远不会被杀死：当 Emitter 的 ParticleState 没有勾选第一个时
	bInfiniteEmitter = false; // 这个 Emitter 是否为 Loop 的
	bInfiniteNiagara = false; // 这个 Niagara 是否为 Loop 的

	// 检查这个 NS 的 System 设置 
	FNiagaraSystemStateData NiagaraSystemStateData = NiagaraSystem->GetSystemStateData();
	if (NiagaraSystemStateData.LoopBehavior == ENiagaraLoopBehavior::Infinite) // Life Cycle Mode 为 System
	{
		bInfiniteNiagara = true;
	}

	if (const FVersionedNiagaraEmitterData* EmitterData = Emitter.GetEmitterData())
	{
		const UNiagaraScriptSource* SourceScript = Cast<UNiagaraScriptSource>(EmitterData->GraphSource);
		if (SourceScript == nullptr || SourceScript->NodeGraph == nullptr)
		{
			return false;
		}

		// 检查 ParticleState 设置，和 Emitter 的 Life Cycle 设置
		int32 emitterUseSystemLoopMode = 0; // 0: System || 1: Self
		int32 emitterLoopBehaviorMode = 0; // 0: Infinite || 1: Once || 2: Multiple
		int32 emitterLoopDurationMode = 0; // 0: Fixed || 1: Infinite
		for (UEdGraphNode* Node : SourceScript->NodeGraph->Nodes)
		{
			if (!Node)
			{
				continue;
			}

			// 检查是否含有激活的 SpawnRate 模块
			UNiagaraNodeFunctionCall* FuncNode = Cast<UNiagaraNodeFunctionCall>(Node);
			if (FuncNode && FuncNode->GetFunctionName() == TEXT("SpawnRate") && FuncNode->IsNodeEnabled())
			{
				bSpawnRate = true;
			}

			for (const UEdGraphPin* Pin : Node->Pins)
			{
				if (!Pin)
				{
					continue;
				}

				if (Pin->PinName == TEXT("Kill Particles When Lifetime Has Elapsed") && Pin->DefaultValue == TEXT("false"))
				{
					bInfiniteParticle = true;
				}

				// ENiagaraEmitterLifeCycleMode 通过 UEdGraphPin 读出来的格式为：
				// (Name="ENiagaraEmitterLifeCycleMode", InternalFlags=1073741826)
				// {"NewEnumerator0",L"System"}
				// {"NewEnumerator1",L"Self"}
				if (Pin->PinName == TEXT("Life Cycle Mode") && Pin->DefaultValue == TEXT("NewEnumerator0")) // Life Cycle Mode 为 System
				{
					emitterUseSystemLoopMode = 0;
				}
				if (Pin->PinName == TEXT("Life Cycle Mode") && Pin->DefaultValue == TEXT("NewEnumerator1")) // Life Cycle Mode 为 Self
				{
					emitterUseSystemLoopMode = 1;
				}

				// ENiagara_EmitterStateOptions 通过 UEdGraphPin 读出来的格式为：
				// (Name="ENiagara_EmitterStateOptions", InternalFlags=1073741825)
				// { "NewEnumerator0", L"Infinite" }
				// { "NewEnumerator1", L"Once" }
				// { "NewEnumerator2", L"Multiple" }
				if (Pin->PinName == TEXT("Loop Behavior") && Pin->DefaultValue == TEXT("NewEnumerator0")) // Loop Behavior 为 Infinite
				{
					emitterLoopBehaviorMode = 0;
				}
				if (Pin->PinName == TEXT("Loop Behavior") && Pin->DefaultValue == TEXT("NewEnumerator1")) // Loop Behavior 为 Once
				{
					emitterLoopBehaviorMode = 1;
				}
				if (Pin->PinName == TEXT("Loop Behavior") && Pin->DefaultValue == TEXT("NewEnumerator2")) // Loop Behavior 为 Multiple
				{
					emitterLoopBehaviorMode = 2;
				}

				if (Pin->PinName == TEXT("Loop Duration Mode") && Pin->DefaultValue == TEXT("NewEnumerator0")) // Loop Duration Mode 为 Fixed
				{
					emitterLoopDurationMode = 0;
				}
				if (Pin->PinName == TEXT("Loop Duration Mode") && Pin->DefaultValue == TEXT("NewEnumerator1")) // Loop Duration Mode 为 Infinite
				{
					emitterLoopDurationMode = 1;
				}
			}
		}

		// 判断 Emitter 是无限发射的：无限循环发射 或 （单次循环时间无限 且 在这单次循环时用 SpawnRate 不断发射）
		bInfiniteEmitter = false;
		if (emitterUseSystemLoopMode == 0) // 此 Emitter 使用系统设置
		{
			if (bInfiniteNiagara) // 系统设置为无限循环
			{
				bInfiniteEmitter = true;
			}
			else
			{
				bInfiniteEmitter = false;
			}
		}
		else // 此 Emitter 使用自己的设置
		{
			if (emitterLoopBehaviorMode == 0) // Emitter 自己的设置是无限循环
			{
				bInfiniteEmitter = true;
			}
			else if (emitterLoopBehaviorMode == 1) // Emitter 自己的设置是只循环一次
			{
				if (emitterLoopDurationMode == 0) // Emitter 单次循环生命有限
				{
					bInfiniteEmitter = false;
				}
				else // Emitter 单次循环生命无限
				{
					if (bSpawnRate) // 此 Emitter 会不断发射 Particle
					{
						bInfiniteEmitter = true;
					}
					else // 此 Emitter 不会不断发射 Particle
					{
						bInfiniteEmitter = false;
					}
				}
			}
			else // 粒子自己的设置是多次循环
			{
				bInfiniteEmitter = false;
			}
		}

		// 已经读完此 Emitter 所需的数据，开始判断
		if (bInfiniteParticle && bInfiniteEmitter)
		{
			bFinalRet = true; // 判断为会泄露
		}
		// 但话又说回来.jpg
		if (EmitterData->AllocationMode == EParticleAllocationMode::FixedCount)
		{
			bFinalRet = false; // 数量固定，无论之前是什么情况，永远不会泄露
			// 这步判断必须放在最后做，因为外部有别的功能会用到之前 bSpawnRate bInfiniteParticle bInfiniteEmitter bInfiniteNiagara 的结果
		}
	}

	return bFinalRet;
}

// 判断一个 Emitter 是否循环 // 用于 CI 检测，没有暴露对应的蓝图节点 
bool FNSAssetCheckerUtils::Niagara_IsEmitterLooping(const UNiagaraSystem* NiagaraSystem, const FVersionedNiagaraEmitter& Emitter)
{
	bool bInfiniteNiagara = false; // 这个 Niagara 是否为 Loop 的
	bool bSpawnRate = false; // 这个 Emitter 是否含有 SpawnRate 模块
	bool bInfiniteParticle = false; // 粒子是否永远不会被杀死：当 Emitter 的 ParticleState 没有勾选第一个时
	bool bInfiniteEmitter = false; // 这个 Emitter 是否为 Loop 的

	Niagara_IsEmitterLoopLeaking(NiagaraSystem, Emitter, bSpawnRate, bInfiniteParticle, bInfiniteEmitter, bInfiniteNiagara);
	if (bInfiniteParticle)
	{
		return true; // 判断为会泄露
	}

	return false;
}


// 判断一个 NS 是否有不被杀死的 Loop 粒子泄露
// 当 Emitter 的 ParticleState 没有勾选第一个时，说明这个 Emitter 里的粒子是不会被杀死的
// 如果这个 Emitter 又是 Loop 的，或者有 SpawnRate 不停生成，那么就说明这个 NS 里有 Loop 泄露
bool FNSAssetCheckerUtils::Niagara_HasLoopLeak(const UNiagaraSystem* NiagaraSystem)
{
	if (NiagaraSystem)
	{
		// 逐 Emitter 检查
		for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
		{
			if (!Handle.GetIsEnabled())
			{
				continue;
			}

			const FVersionedNiagaraEmitter& Emitter = Handle.GetInstance();

			bool bInfiniteNiagara = false; // 这个 Niagara 是否为 Loop 的
			bool bSpawnRate = false; // 这个 Emitter 是否含有 SpawnRate 模块
			bool bInfiniteParticle = false; // 粒子是否永远不会被杀死：当 Emitter 的 ParticleState 没有勾选第一个时
			bool bInfiniteEmitter = false; // 这个 Emitter 是否为 Loop 的

			if (Niagara_IsEmitterLoopLeaking(NiagaraSystem, Emitter, bSpawnRate, bInfiniteParticle, bInfiniteEmitter, bInfiniteNiagara))
			{
				return true; // 判断为会泄露，直接返回有泄露
			}
			else
			{
				; // 否则进入 for 循环的下一个，检查下一个 Emitter
			}
		}
	}

	return false;
}

// 判断一群 NS 是否有不被杀死的 Loop 粒子泄露
void FNSAssetCheckerUtils::Niagaras_HaveLoopLeak(const TArray<FString>& NiagaraAssetPaths, FString& Result_InvalidNSAssetPathStr)
{
	UAssetManager& AssetManager = UAssetManager::Get();
	TArray<FString> Result_InvalidNSAssetPath;
	Result_InvalidNSAssetPath.Reset();

	for (const FString& AssetPath : NiagaraAssetPaths)
	{
		FAssetData AssetData = AssetManager.GetAssetRegistry().GetAssetByObjectPath(FSoftObjectPath(AssetPath));
		if (AssetData.IsValid())
		{
			TObjectPtr<UNiagaraSystem> NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
			if (NiagaraSystem)
			{
				if (Niagara_HasLoopLeak(NiagaraSystem))
				{
					Result_InvalidNSAssetPath.Add(AssetPath);
				}
			}
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("[Niagaras_HaveLoopLeak] Fail To Check Asset Path: %s"), *AssetPath);
		}
	}

	Result_InvalidNSAssetPathStr = UsdUtils::StringifyAsStringArray(Result_InvalidNSAssetPath);
}

// 设置 NiagaraEffectType 的特效优先级
void FNSAssetCheckerUtils::SetNiagaraEffectTypePriority(const int32 Priority, UNiagaraEffectType* EffectType)
{
	if (EffectType)
	{
		if (EffectType->Priority == Priority && EffectType->bUsePriority == true) // 本身设置已和我们预期一致
		{
			; // 什么都不做
		}
		else // 否则修改优先级,并标记资产为脏以便后续保存
		{
			EffectType->bUsePriority = true;
			EffectType->Priority = Priority;
			EffectType->MarkPackageDirty();
		}
	}
}

// 设置 NiagaraEffectType 资产的特效优先级
void FNSAssetCheckerUtils::SetNiagaraEffectTypePriority(const int32 Priority, const FAssetData& AssetData)
{
	UNiagaraEffectType* EffectType = Cast<UNiagaraEffectType>(AssetData.GetAsset());
	SetNiagaraEffectTypePriority(Priority, EffectType);
}

// 设置 NiagaraSystem 的特效优先级
void FNSAssetCheckerUtils::SetNiagaraSystemPriority(const int32 Priority, UNiagaraSystem* NiagaraSystem)
{
	if (NiagaraSystem)
	{
		if (NiagaraSystem->GetPriority() == Priority) // 本身设置已和我们预期一致
		{
			; // 什么都不做
		}
		else // 否则修改优先级,并标记资产为脏以便后续保存
		{
			NiagaraSystem->SetPriority(true, Priority);
			NiagaraSystem->MarkPackageDirty();
		}
	}
}

#endif // WITH_EDITOR
#pragma endregion FNSAssetCheckerUtils: NS 相关


#pragma region ANSAssetLoopChecker 相关
#if WITH_EDITOR

#define ANSASSETLOOPCHECKER_NIAGARA_STAT_GROUPNAME "Niagara"
#define ANSASSETLOOPCHECKER_NIAGARA_STAT_NUMSPRITES "STAT_NiagaraNumSprites"
#define ANSASSETLOOPCHECKER_NIAGARA_STAT_NUMMESHES "STAT_NiagaraNumMeshVerts"

#pragma region 修改设置 AActor 的属性
ANSAssetLoopChecker::ANSAssetLoopChecker()
{
	PrimaryActorTick.bCanEverTick = true; // 构造时打开 Tick 开关。虽然这个值默认是1，但必须再手动设置一下。

	InitNSAssetLoopCheckerData(); // 初始化 NSAssetLoopChecker 里的各个数据
}

bool ANSAssetLoopChecker::ShouldTickIfViewportsOnly() const
{
	return true; // 在非运行时也要 Tick
} 

void ANSAssetLoopChecker::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	Ticker_NSChecker();
}

void ANSAssetLoopChecker::Destroyed()
{
	Super::Destroy();

	// 在死亡时注销所有 Timer
	UE_LOG(LogTemp, Warning, TEXT("[NSAssetLoopChecker] Timer Clear"));
	GetWorldTimerManager().ClearAllTimersForObject(this);
};

void ANSAssetLoopChecker::InitNSAssetLoopCheckerData() // 用于初始化 NSAssetLoopChecker 里的各个数据
{
	this->Result_InvalidNSAssetPath.Reset();
	this->NSHalfCPUParticlesNumArray.Reset();
	this->NSHalfGPUParticlesNumArray.Reset();
	this->NSWholeCPUParticlesNumArray.Reset();
	this->NSWholeGPUParticlesNumArray.Reset();


	this->NiagaraAssetDatas.Reset(); // 初始化 NiagaraAssetDatas 数组
	this->TimeToPlayNS = 60; // 默认播放 60s。后续由 StartChecker() 传入参数设置。
	this->NSAssetValidThreshold = 1.7; // 当后半段数值是前半段的1.7倍时，会被判定为 Loop 泄露。后续由 StartChecker() 传入参数设置。
	this->NSIndexCur = 0;
	this->NSActor = nullptr; // 初始化置空，由 Timer_NSChecker() 赋值
}
#pragma endregion 修改设置 AActor 的属性

#pragma region ANSAssetLoopChecker: Timer 相关
void ANSAssetLoopChecker::StartChecker(const TArray<FString>& niagaraAssetPaths, const double timeToPlayNS, const double nsAssetValidThreshold)
{
	if (GetWorldTimerManager().IsTimerActive(TimerHandle_ANSAssetLoopChecker)) // 如果为 true, 这说明已经有一个正在运行的 Timer 在跑。不需要再次注册。
	{
		UE_LOG(LogTemp, Warning, TEXT("[NSAssetLoopChecker] NSAssetLoopChecker is Working."));
	}
	else
	{
		InitNSAssetLoopCheckerData();

		// 激活 Stat 
		FNSAssetCheckerUtils::GetStatCounter(this, ANSASSETLOOPCHECKER_NIAGARA_STAT_GROUPNAME, ANSASSETLOOPCHECKER_NIAGARA_STAT_NUMSPRITES);

		this->NiagaraAssetDatas.Reset(); // 重置 NiagaraAssetDatas 数组
		UAssetManager& AssetManager = UAssetManager::Get();
		for (const FString& AssetPath : niagaraAssetPaths) // 将传入的 Niagara 资产路径转换为 FAssetData 并存入 NiagaraAssetDatas 数组
		{
			FAssetData AssetData = AssetManager.GetAssetRegistry().GetAssetByObjectPath(FSoftObjectPath(AssetPath));

			if (AssetData.IsValid())
			{
				this->NiagaraAssetDatas.Add(AssetData);
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("[NSAssetLoopChecker] Invalid Asset Path: %s"), *AssetPath);
			}
		}

		this->TimeToPlayNS = timeToPlayNS;
		this->NSAssetValidThreshold = nsAssetValidThreshold;
		this->NSIndexCur = 0;
		this->NSActor = nullptr;

		// 注册一个 Timer。 // 此 Timer 注销时机: 1. 此 Actor 实例被销毁 2. EndChecker() 被调用 3. NiagaraAssetDatas 里的所有元素被检查完毕
		GetWorldTimerManager().SetTimer(TimerHandle_ANSAssetLoopChecker, this, &ANSAssetLoopChecker::Timer_NSChecker, this->TimeToPlayNS, true);
		UE_LOG(LogTemp, Warning, TEXT("[NSAssetLoopChecker] Timer Start"));
	}
}

void ANSAssetLoopChecker::EndChecker()
{
	// 在结束时注销所有 Timer
	UE_LOG(LogTemp, Warning, TEXT("[NSAssetLoopChecker] Timer Clear"));
	GetWorldTimerManager().ClearAllTimersForObject(this);

	// 删掉放到场景里的 NSActor
	if (NSActor)
	{
		NSActor->K2_DestroyActor();
	}
}

// True: 没问题 || False: 有问题，Loop 泄露
// 检查上一个 Timer 被触发后记录下的结果，其 Loop 是否有泄露，将结果记录在结果数组里并打印
bool ANSAssetLoopChecker::PrevNSValidChecker()
{
	bool bIsValid = true;
	int NSIndexPrev = NSIndexCur - 1;

	if (!NiagaraAssetDatas.IsValidIndex(NSIndexPrev) // 数组越界时直接打印结果并返回 true // 在第一次检查时会触发
		|| !NSHalfCPUParticlesNumArray.IsValidIndex(NSIndexPrev) || !NSHalfGPUParticlesNumArray.IsValidIndex(NSIndexPrev) 
		|| !NSWholeCPUParticlesNumArray.IsValidIndex(NSIndexPrev) || !NSWholeGPUParticlesNumArray.IsValidIndex(NSIndexPrev))
	{
		bIsValid = true;
	}
	else
	{
		bool bValidSpriteNum = NSWholeCPUParticlesNumArray[NSIndexPrev] < 1
			|| NSHalfCPUParticlesNumArray[NSIndexPrev] * this->NSAssetValidThreshold > NSWholeCPUParticlesNumArray[NSIndexPrev];
		bool bValidMeshNum = NSWholeGPUParticlesNumArray[NSIndexPrev] < 1 
			|| NSHalfGPUParticlesNumArray[NSIndexPrev] * this->NSAssetValidThreshold > NSWholeGPUParticlesNumArray[NSIndexPrev];

		if (bValidSpriteNum && bValidMeshNum && !FNSAssetCheckerUtils::Niagara_HasLoopLeak(NSObject)) // 此处额外进行检查
		{
			bIsValid = true;
		}
		else // 前一个 NSAsset 不合格！将资产名放入 Result_InvalidNSAssetPath 并返回 false
		{
			bIsValid = false;
			Result_InvalidNSAssetPath.Add(NiagaraAssetDatas.operator[](NSIndexPrev).PackagePath.ToString() + TEXT("/")
											+ NiagaraAssetDatas.operator[](NSIndexPrev).AssetName.ToString()); // 已确定必然在 Win 下运行
		}
	}

	FString retString = UsdUtils::StringifyAsStringArray(Result_InvalidNSAssetPath);
	UE_LOG(LogTemp, Warning, TEXT("[NSAssetLoopChecker] Invalid Loop NS Assets: %s"), *retString);

	return bIsValid;
}

void ANSAssetLoopChecker::Timer_NSChecker()
{
	UE_LOG(LogTemp, Warning, TEXT("[NSAssetLoopChecker] Timer Callback"));

	// 检查上一个 Timer 被触发后记录下的结果，其 Loop 是否有泄露，将结果记录在结果数组里
	PrevNSValidChecker();

	// 是否检查结束
	if (!NiagaraAssetDatas.IsValidIndex(NSIndexCur)) // 可以直接结束 Timer 了
	{
		EndChecker();
		return;
	}

	// 销毁上一次检查残留的 Actor 和加载进来的 Asset 。
	if (NSActor)
	{
		NSActor->Destroy(); // 销毁上一次检查残留在场景里的 Actor
	}
	// 下列 Asset 包卸载相关，QA 反馈说加了之后会导致运行 NSLoop 检查过程中 Editor 崩溃，先注释掉。
	//if (NSObject)
	//{
	//	UPackage* Package = NSObject->GetOutermost();
	//	if (Package)
	//	{
	//		FString PkgName = Package->GetName();
	//		TArray<UPackage*> PackagesToUnload;
	//		PackagesToUnload.Add(Package);
	//		bool bUnloaded = UPackageTools::UnloadPackages(PackagesToUnload);
	//		if (bUnloaded)
	//		{
	//			UE_LOG(LogTemp, Warning, TEXT("Unloaded Package: %s"), *PkgName);
	//		}
	//		else
	//		{
	//			UE_LOG(LogTemp, Warning, TEXT("Failed to unload Package: %s (maybe still in use)"), *PkgName);
	//		}
	//	}

	//	CollectGarbage(RF_NoFlags);
	//}

	// 将当前待检查的 NSActor 放入场景
	NSObject = Cast<UNiagaraSystem>((NiagaraAssetDatas.operator[](NSIndexCur)).GetAsset());
	UEditorActorSubsystem* EditorActorSubsystem = GEditor->GetEditorSubsystem<UEditorActorSubsystem>(); // 已确保此工具只在编辑器下运行
	NSActor = EditorActorSubsystem ? EditorActorSubsystem->SpawnActorFromObject(NSObject, FVector::ZeroVector, FRotator::ZeroRotator, false) : nullptr;

	// 为在当前 NSAsset 的 Timer 区间内的 Tick 做准备，初始化一些 Tick 相关的数据
	NSHalfCPUParticlesNumArray.Add(0);
	NSHalfGPUParticlesNumArray.Add(0);
	NSWholeCPUParticlesNumArray.Add(0);
	NSWholeGPUParticlesNumArray.Add(0);
	TickStartTime = UKismetSystemLibrary::GetPlatformTime_Seconds();
	TickCount = 0;

	// 索引指向下一个元素
	NSIndexCur++;

	// 固定摄像机视角
	if (GEditor && NSActor)
	{
		FVector TargetLocation = NSActor->GetActorLocation();
		FVector CameraLocation = TargetLocation + FVector(1.f, 1.f, 1.f) * 1000.f;
		FRotator LookAtRotation = UKismetMathLibrary::FindLookAtRotation(CameraLocation, TargetLocation);
		UEditorLevelLibrary::SetLevelViewportCameraInfo(CameraLocation, LookAtRotation);
	}

};
#pragma endregion ANSAssetLoopChecker: Timer 相关

#pragma region ANSAssetLoopChecker: Tick 相关

void ANSAssetLoopChecker::Ticker_NSChecker()
{
	if (!GetWorldTimerManager().IsTimerActive(TimerHandle_ANSAssetLoopChecker) 
		|| !NSHalfCPUParticlesNumArray.IsValidIndex(NSIndexCur - 1) || !NSHalfGPUParticlesNumArray.IsValidIndex(NSIndexCur - 1)
		|| !NSWholeCPUParticlesNumArray.IsValidIndex(NSIndexCur - 1) || !NSWholeGPUParticlesNumArray.IsValidIndex(NSIndexCur - 1)		)
	{
		return; // 当前没有 Timer 在跑，不需要在 Tick 中记录数据
	}

	double TimeInterval = UKismetSystemLibrary::GetPlatformTime_Seconds() - TickStartTime;

	if (TimeInterval < FMath::Min(2, TimeToPlayNS / 4.0))
	{
		return; // 不要立即开始记录，防止上一个 NS 很大的值残留在 Stat 里干扰到当前 // 最多延迟 2s 开始记录
	}
	else if (TimeInterval < TimeToPlayNS / 2.0) // 记录前半段的数值
	{
		TickCount++;
		TickCountHalf = TickCount;

		// 下列数据原本是通过 GetStatCounter 获取的，无法直接获取到粒子数量。但现在新写了能直接获取粒子数量的接口，改用它直接获取粒子数量。
		//double immediateSpriteNum = FNSAssetCheckerUtils::GetStatCounter(this, ANSASSETLOOPCHECKER_NIAGARA_STAT_GROUPNAME, ANSASSETLOOPCHECKER_NIAGARA_STAT_NUMSPRITES);
		//double avgSpriteNum = (NSHalfStatSpriteNumArray[NSIndexCur - 1] * (TickCount - 1) + immediateSpriteNum) / TickCount;
		//NSHalfStatSpriteNumArray[NSIndexCur - 1] = avgSpriteNum;
		//double immediateMeshNum = FNSAssetCheckerUtils::GetStatCounter(this, ANSASSETLOOPCHECKER_NIAGARA_STAT_GROUPNAME, ANSASSETLOOPCHECKER_NIAGARA_STAT_NUMMESHES);
		//double avgMeshNum = (NSHalfStatMeshNumArray[NSIndexCur - 1] * (TickCount - 1) + immediateMeshNum) / TickCount;
		//NSHalfStatMeshNumArray[NSIndexCur - 1] = avgMeshNum;

		int32 CPUEmittersNum, GPUEmittersNum, immediateCPUParticlesNum, immediateGPUParticlesNum;
		FNSAssetCheckerUtils::GetNiagaraNumParticles(this, immediateCPUParticlesNum, immediateGPUParticlesNum, CPUEmittersNum, GPUEmittersNum);
		double avgCPUParticlesNum = (NSHalfCPUParticlesNumArray[NSIndexCur - 1] * (TickCount - 1) + immediateCPUParticlesNum) / TickCount;
		NSHalfCPUParticlesNumArray[NSIndexCur - 1] = avgCPUParticlesNum;
		double avgGPUParticlesNum = (NSHalfGPUParticlesNumArray[NSIndexCur - 1] * (TickCount - 1) + immediateGPUParticlesNum) / TickCount;
		NSHalfGPUParticlesNumArray[NSIndexCur - 1] = avgGPUParticlesNum;
	}
	else // 记录后半段的数值
	{
		TickCount++;

		// 下列数据原本是通过 GetStatCounter 获取的，无法直接获取到粒子数量。但现在新写了能直接获取粒子数量的接口，改用它直接获取粒子数量。
		//double immediateSpriteNum = FNSAssetCheckerUtils::GetStatCounter(this, ANSASSETLOOPCHECKER_NIAGARA_STAT_GROUPNAME, ANSASSETLOOPCHECKER_NIAGARA_STAT_NUMSPRITES);
		//double avgSpriteNum = (NSWholeCPUParticlesNumArray[NSIndexCur - 1] * (TickCount - TickCountHalf - 1) + immediateSpriteNum) / (TickCount - TickCountHalf);
		//NSWholeCPUParticlesNumArray[NSIndexCur - 1] = avgSpriteNum;
		//double immediateGPUParticlesNum = FNSAssetCheckerUtils::GetStatCounter(this, ANSASSETLOOPCHECKER_NIAGARA_STAT_GROUPNAME, ANSASSETLOOPCHECKER_NIAGARA_STAT_NUMMESHES);
		//double avgGPUParticlesNum = (NSWholeGPUParticlesNumArray[NSIndexCur - 1] * (TickCount - TickCountHalf - 1) + immediateGPUParticlesNum) / (TickCount - TickCountHalf);
		//NSWholeGPUParticlesNumArray[NSIndexCur - 1] = avgGPUParticlesNum;

		int32 CPUEmittersNum, GPUEmittersNum, immediateCPUParticlesNum, immediateGPUParticlesNum;
		FNSAssetCheckerUtils::GetNiagaraNumParticles(this, immediateCPUParticlesNum, immediateGPUParticlesNum, CPUEmittersNum, GPUEmittersNum);
		double avgCPUParticlesNum = (NSWholeCPUParticlesNumArray[NSIndexCur - 1] * (TickCount - TickCountHalf - 1) + immediateCPUParticlesNum) / (TickCount - TickCountHalf);
		NSWholeCPUParticlesNumArray[NSIndexCur - 1] = avgCPUParticlesNum;
		double avgGPUParticlesNum = (NSWholeGPUParticlesNumArray[NSIndexCur - 1] * (TickCount - TickCountHalf - 1) + immediateGPUParticlesNum) / (TickCount - TickCountHalf);
		NSWholeGPUParticlesNumArray[NSIndexCur - 1] = avgGPUParticlesNum;

	}
}

// 获取到 Result_InvalidNSAssetPath 存放有问题 NS 资产的路径数组，以及所有 NS 检测时的数据
void ANSAssetLoopChecker::GetNSLoopCheckerResult_All(FString& NSHalfCPUParticlesNumArrayStr, FString& NSWholeCPUParticlesNumArrayStr,
	FString& NSHalfGPUParticlesNumArrayStr, FString& NSWholeGPUParticlesNumArrayStr, FString& Result_InvalidNSAssetPathStr)
{
	NSHalfCPUParticlesNumArrayStr = UsdUtils::StringifyAsDoubleArray(NSHalfCPUParticlesNumArray);
	NSWholeCPUParticlesNumArrayStr = UsdUtils::StringifyAsDoubleArray(NSWholeCPUParticlesNumArray);
	NSHalfGPUParticlesNumArrayStr = UsdUtils::StringifyAsDoubleArray(NSHalfGPUParticlesNumArray);
	NSWholeGPUParticlesNumArrayStr = UsdUtils::StringifyAsDoubleArray(NSWholeGPUParticlesNumArray);
	Result_InvalidNSAssetPathStr = UsdUtils::StringifyAsStringArray(Result_InvalidNSAssetPath);
}

// 获取到 Result_InvalidNSAssetPath 存放有问题 NS 资产的路径数组
void ANSAssetLoopChecker::GetNSLoopCheckerResult(FString& Result_InvalidNSAssetPathStr)
{
	Result_InvalidNSAssetPathStr = UsdUtils::StringifyAsStringArray(Result_InvalidNSAssetPath);
}

// 返回当前的 Timer 是否在工作
bool ANSAssetLoopChecker::IsNSLoopTimerWorking()
{
	return GetWorldTimerManager().IsTimerActive(TimerHandle_ANSAssetLoopChecker);
}

#pragma endregion ANSAssetLoopChecker: Tick 相关
#endif // WITH_EDITOR
#pragma endregion ANSAssetLoopChecker 相关

#pragma region NS性能打分相关
#if WITH_EDITOR

ANSPerformanceScorer::ANSPerformanceScorer()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = true;
	PrimaryActorTick.TickGroup = TG_PrePhysics;

	LastTickTime = FPlatformTime::Seconds();
}

bool ANSPerformanceScorer::ShouldTickIfViewportsOnly() const
{
	return true; // 在非运行时也要 Tick
}

void ANSPerformanceScorer::StartChecker()
{
	bStartCheck = true;
	bFinishCheck = false;
	LastTickTime = FPlatformTime::Seconds();

	GenCameraActor();
}

void ANSPerformanceScorer::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!bStartCheck || bFinishCheck || NiagaraAssetPath.IsEmpty())
	{
		return;
	}

	UWorld* World = GetWorld();
	if (World)
	{
		if (!NiagaraActor_NSPerformanceScorer)
		{
			GenNiagaraActor(NiagaraAssetPath);
		}

		int32 CPUParticlesNum_Temp, GPUParticlesNum_Temp, CPUEmittersNum_Temp, GPUEmittersNum_Temp = 0;
		FNSAssetCheckerUtils::GetNiagaraNumParticles(this, CPUParticlesNum_Temp, GPUParticlesNum_Temp, CPUEmittersNum_Temp, GPUEmittersNum_Temp);
		this->ParticlesNum = FMath::Max(CPUParticlesNum_Temp + GPUParticlesNum_Temp, this->ParticlesNum);
		this->EmittersNum = FMath::Max(CPUEmittersNum_Temp + GPUEmittersNum_Temp, this->EmittersNum);
		this->CPUParticlesNum = FMath::Max(CPUParticlesNum_Temp, this->CPUParticlesNum);
		this->GPUParticlesNum = FMath::Max(GPUParticlesNum_Temp, this->GPUParticlesNum);
		this->CPUEmittersNum = FMath::Max(CPUEmittersNum_Temp, this->CPUEmittersNum);
		this->GPUEmittersNum = FMath::Max(GPUEmittersNum_Temp, this->GPUEmittersNum);
		FScene* Scene = World->Scene->GetRenderScene();
		this->ScreenPSComplexityMean = FMath::Max(Scene->ScreenAvgPSComplexity, this->ScreenPSComplexityMean);

		UpdateNiagaraActor();
		UpdateCameraActor();
	}

	// 按一定时间间隔调用 Timer_ANSPerformanceScorer()。
	// 这玩意本来使用 Timer 来做的，但 Timer 在 PIE 下不太准，且无法去掉编译时间，所以改成在 Tick 里手动计时调用。
	double NowTime = FPlatformTime::Seconds();
	double ElapsedTime = NowTime - LastTickTime;
	LastTickTime = NowTime;
	AccumulatorTime += ElapsedTime;
	if (AccumulatorTime >= PlayTime_NiagaraActor)
	{
		AccumulatorTime = 0.0;
		Timer_ANSPerformanceScorer();
	}
}

void ANSPerformanceScorer::Destroyed()
{
	Super::Destroyed();

	if (CameraActor_NSPerformanceScorer)
	{
		CameraActor_NSPerformanceScorer->Destroy();
	}
	if (NiagaraActor_NSPerformanceScorer)
	{
		NiagaraActor_NSPerformanceScorer->Destroy();
	}
}

void ANSPerformanceScorer::Timer_ANSPerformanceScorer()
{
	//CameraPointIndex = (CameraPointIndex + 1) % CameraPoints.Num();
	CameraPointIndex++;
	if (CameraPointIndex < CameraPoints.Num())
	{
		bFinishCheck = false;
	}
	else
	{
		bFinishCheck = true;
	}
	CameraPointIndex = CameraPointIndex % CameraPoints.Num();

	UE_LOG(LogTemp,
		Warning,
		TEXT("[NSPerformanceScorer] Timer Callback. ParticlesNum %d. EmittersNum %d. ScreenPSComplexityMean %d"),
		int32(ParticlesNum),
		int32(EmittersNum),
		int32(ScreenPSComplexityMean));

	if (NiagaraActor_NSPerformanceScorer) // 删掉已有的，重新生成一个新的
	{
		NiagaraActor_NSPerformanceScorer->Destroy();
		GenNiagaraActor(NiagaraAssetPath);
	}
}

void ANSPerformanceScorer::GenCameraActor()
{
	if (GEditor && GEditor->PlayWorld)
	{
		// 当前在 PIE 或 SIE 模式
		UWorld* World = GetWorld();
		if (World)
		{
			FVector Location(0.f, 0.f, 300.f); // 初始位置，后续会在 Tick 里更新
			FRotator Rotation(-90.f, 0.f, 0.f); // 初始旋转，后续会在 Tick 里更新
			// 生成 Camera Actor
			FActorSpawnParameters SpawnParams;
			CameraActor_NSPerformanceScorer = World->SpawnActor<ACameraActor>(
				ACameraActor::StaticClass(),
				Location,
				Rotation,
				SpawnParams
			);
			if (CameraActor_NSPerformanceScorer)
			{
				CameraActor_NSPerformanceScorer->GetCameraComponent()->SetFieldOfView(90.f);
				CameraActor_NSPerformanceScorer->GetCameraComponent()->SetAspectRatio(16.f / 9.f);
			}
			// 获取 PlayerController
			APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0);
			if (PC)
			{
				// 切换到新的相机
				PC->SetViewTargetWithBlend(
					CameraActor_NSPerformanceScorer,   // 新的相机
					0.0f,        // 切换时间，0 瞬切
					EViewTargetBlendFunction::VTBlend_Cubic // 过渡方式
				);
			}
		}
	}
}

void ANSPerformanceScorer::UpdateCameraActor()
{
	if (GEditor && GEditor->PlayWorld)
	{
		if (CameraActor_NSPerformanceScorer && NiagaraActor_NSPerformanceScorer)
		{
			FVector TargetLocation = NiagaraActor_NSPerformanceScorer->GetActorLocation();
			FVector CameraLocation = TargetLocation + CameraPoints[CameraPointIndex] * CheckDistance_NiagaraActor;
			CameraActor_NSPerformanceScorer->SetActorLocation(CameraLocation);
			FRotator LookAtRotation = UKismetMathLibrary::FindLookAtRotation(CameraLocation, TargetLocation);
			CameraActor_NSPerformanceScorer->SetActorRotation(LookAtRotation);
		}
	}
	else // 非 PIE 或 SIE 模式
	{
		if (GEditor && NiagaraActor_NSPerformanceScorer)
		{
			FVector TargetLocation = NiagaraActor_NSPerformanceScorer->GetActorLocation();
			FVector CameraLocation = TargetLocation + CameraPoints[CameraPointIndex] * CheckDistance_NiagaraActor;
			FRotator LookAtRotation = UKismetMathLibrary::FindLookAtRotation(CameraLocation, TargetLocation);
			UEditorLevelLibrary::SetLevelViewportCameraInfo(CameraLocation, LookAtRotation);
		}
	}
}

void ANSPerformanceScorer::GenNiagaraActor(FString NSFilePath)
{
	UWorld* World = GetWorld();
	if (World)
	{
		if (NiagaraSystem_NSPerformanceScorer)
		{
			// 生成 Niagara Actor
			FVector Location(0.f, 0.f, 100.f); // 初始位置，后续会在 Tick 里更新
			FRotator Rotation(0.f, 0.f, 0.f); // 初始旋转，后续会在 Tick 里更新
			FActorSpawnParameters SpawnParams;
			NiagaraActor_NSPerformanceScorer = World->SpawnActor<ANiagaraActor>(
				ANiagaraActor::StaticClass(),
				Location,
				Rotation,
				SpawnParams
			);

			if (NiagaraActor_NSPerformanceScorer)
			{
				TObjectPtr<UNiagaraComponent> NiagaraComp = NiagaraActor_NSPerformanceScorer->GetNiagaraComponent();
				if (NiagaraComp)
				{
					NiagaraComp->SetAsset(NiagaraSystem_NSPerformanceScorer);
					NiagaraComp->ResetSystem();
					NiagaraComp->SetCustomTimeDilation(CheckTime_NiagaraActor / PlayTime_NiagaraActor);
					NiagaraComp->Activate(true);
				}
			}
		}
	}
}

void ANSPerformanceScorer::UpdateNiagaraActor()
{
	if (NiagaraActor_NSPerformanceScorer)
	{
		FVector TargetPoint = NiagaraActor_NSPerformanceScorer->GetActorLocation();
		TargetPoint[0] += MoveSpeed_NiagaraActor;
		NiagaraActor_NSPerformanceScorer->SetActorLocation(TargetPoint);
	}
}

bool ANSPerformanceScorer::IsFinishCheck() const
{
	return bFinishCheck;
}
float ANSPerformanceScorer::GetParticlesNum() const
{
	return ParticlesNum;
}
float ANSPerformanceScorer::GetCPUParticlesNum() const
{
	return CPUParticlesNum;
}
float ANSPerformanceScorer::GetGPUParticlesNum() const
{
	return GPUParticlesNum;
}
float ANSPerformanceScorer::GetEmittersNum() const
{
	return EmittersNum;
}
float ANSPerformanceScorer::GetCPUEmittersNum() const
{
	return CPUEmittersNum;
}
float ANSPerformanceScorer::GetGPUEmittersNum() const
{
	return GPUEmittersNum;
}
float ANSPerformanceScorer::GetScreenPSComplexityMean() const
{
	return ScreenPSComplexityMean;
}

ANSPerformanceScorerManager::ANSPerformanceScorerManager()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = true;
	PrimaryActorTick.TickGroup = TG_PrePhysics;
}

bool ANSPerformanceScorerManager::ShouldTickIfViewportsOnly() const
{
	return true; // 在非运行时也要 Tick
}

void ANSPerformanceScorerManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!bStartCheck)
	{
		return;
	}

	// 如果当前没有 NSPerformanceScorer，则按参数循环，生成一个新的
	if (NSPerformanceScorer == nullptr)
	{
		// 首次启动检查，无论从哪里开始，都需要设置画质
		if (bFirstCheck)
		{
			Scalability::FQualityLevels QualityLevels = Scalability::GetQualityLevels();
			QualityLevels.EffectsQuality = ScalabilityArray[Scalability_CurrentIndex];
			Scalability::SetQualityLevels(QualityLevels);
			Scalability::SaveState(GEditorSettingsIni);

			GetNiagaraSystem();

			bFirstCheck = false;
		}

		// NSDistance_CurrentIndex++ 在后面 NSPerformanceScorer 销毁时进位
		if (NSDistance_CurrentIndex >= NSDistanceArray.Num()) // 检测完当前画质下的当前特效的所有距离，于是检查下一个特效
		{
			NSDistance_CurrentIndex = 0;
			NSArray_CurrentIndex++;

			GetNiagaraSystem();
			//SaveDataTablesToDisk();
		}
		if (NSArray_CurrentIndex >= NiagaraAssetPathArray.Num()) // 检查完当前画质下的所有特效，于是检查下一个画质
		{
			// 检查完当前画质下的当前特效
			NSArray_CurrentIndex = 0;
			Scalability_CurrentIndex++;

			if (Scalability_CurrentIndex >= ScalabilityArray.Num())
			{
				SaveDataTablesToDisk();
				// 全部检查完毕
				bFinishAllCheck = true;

				Destroy();
				return;
			}
			else
			{
				Scalability::FQualityLevels QualityLevels = Scalability::GetQualityLevels();
				QualityLevels.EffectsQuality = ScalabilityArray[Scalability_CurrentIndex];
				Scalability::SetQualityLevels(QualityLevels);
				Scalability::SaveState(GEditorSettingsIni);

				GetNiagaraSystem();
				SaveDataTablesToDisk();
			}
		}

		// 生成 ANSPerformanceScorer
		UWorld* World = GetWorld();
		if (World)
		{
			FVector Location(0.f, 0.f, 0.f);
			FRotator Rotation(0.f, 0.f, 0.f);
			FActorSpawnParameters SpawnParams;
			NSPerformanceScorer = World->SpawnActor<ANSPerformanceScorer>(
				ANSPerformanceScorer::StaticClass(),
				Location,
				Rotation,
				SpawnParams
			);

			NSPerformanceScorer->NiagaraSystem_NSPerformanceScorer = NiagaraSystem_Current;

			NSPerformanceScorer->CheckDistance_NiagaraActor = NSDistanceArray[NSDistance_CurrentIndex];
			NSPerformanceScorer->NiagaraAssetPath = NiagaraAssetPathArray[NSArray_CurrentIndex];

			NSPerformanceScorer->PlayTime_NiagaraActor = PlayTime_NiagaraActor;
			NSPerformanceScorer->CheckTime_NiagaraActor = CheckTime_NiagaraActor;
			NSPerformanceScorer->MoveSpeed_NiagaraActor = MoveSpeed_NiagaraActor;

			NSPerformanceScorer->bCheckMobileNS = bCheckMobileNS;

			NSPerformanceScorer->StartChecker();
		}
	}
	else // 当前有 NSPerformanceScorer
	{
		if (NSPerformanceScorer->IsFinishCheck())
		{
			ParticlesNumArray.Add(NSPerformanceScorer->GetParticlesNum());
			CPUParticlesNumArray.Add(NSPerformanceScorer->GetCPUParticlesNum());
			GPUParticlesNumArray.Add(NSPerformanceScorer->GetGPUParticlesNum());
			EmittersNumArray.Add(NSPerformanceScorer->GetEmittersNum());
			CPUEmittersNumArray.Add(NSPerformanceScorer->GetCPUEmittersNum());
			GPUEmittersNumArray.Add(NSPerformanceScorer->GetGPUEmittersNum());
			ScreenPSComplexityMeanArray.Add(NSPerformanceScorer->GetScreenPSComplexityMean());

			NSScoreArray.Add(NSPerformanceScorer->GetParticlesNum() + 
				NSPerformanceScorer->GetScreenPSComplexityMean() + 
				NSPerformanceScorer->GetEmittersNum() * 40
			);

			UE_LOG(LogTemp,
				Warning,
				TEXT("[NSPerformanceScorer] %s Finish Check. NSArray_CurrentIndex is %d. NSDistance_CurrentIndex is %d. Scalability_CurrentIndex is %d."),
				*NSPerformanceScorer->NiagaraAssetPath,
				int32(NSArray_CurrentIndex), int32(NSDistance_CurrentIndex), int32(Scalability_CurrentIndex));

			// 写入记录
			WriteToDataTable_OriData();
			WriteToDataTable_ClampToInt8();

			UE_LOG(LogTemp,
				Warning,
				TEXT("[NSPerformanceScorer] %s Finish Check. ScoreOri is %d. ParticlesNum is %d. EmittersNum is %d."),
				*NSPerformanceScorer->NiagaraAssetPath,
				int32(NSScoreArray.Last()), int32(ParticlesNumArray.Last()), int32(EmittersNumArray.Last()));


			NSPerformanceScorer->Destroy();
			NSPerformanceScorer = nullptr;

			// 最后进位
			NSDistance_CurrentIndex++;
		}
		else
		{
			; // 继续等 NSPerformanceScorer 检查完
		}
	}
}

void ANSPerformanceScorerManager::Destroyed()
{
	Super::Destroyed();

	if (NSPerformanceScorer)
	{
		NSPerformanceScorer->Destroy();
		NSPerformanceScorer = nullptr;
	}

	if (GEditor)
	{
		for (FEditorViewportClient* ViewportClient : GEditor->GetAllViewportClients())
		{
			if (ViewportClient)
			{
				ViewportClient->SetViewMode(EViewModeIndex::VMI_Lit);
				ViewportClient->Invalidate();
			}
		}
	}
}

void ANSPerformanceScorerManager::GetMobileNiagaraSystem(TObjectPtr<UNiagaraSystem> NiagaraSystem_PC2Mobile)
{
	if (!NiagaraSystem_PC2Mobile)
	{
		return;
	}

	const FString SystemObjectPath = NiagaraSystem_PC2Mobile.GetPath();

	// 从 JSON 找这个 System 需要禁用的 emitters
	TArray<FName> EmittersToDisable;
	if (!FNiagaraEditorTools::GetEmittersToDisableFromJson(SystemObjectPath, EmittersToDisable))
	{
		UE_LOG(LogTemp, Error, TEXT("[NSPerformanceScorer] No emitters to disable from JSON for system: %s"), *SystemObjectPath);
		return;
	}

	TArray<FNiagaraEmitterHandle>& EmitterHandles = NiagaraSystem_PC2Mobile->GetEmitterHandles();
	for (FNiagaraEmitterHandle& Handle : EmitterHandles)
	{
		FVersionedNiagaraEmitter EmitterInstance = Handle.GetInstance();
		FVersionedNiagaraEmitterData* EmitterData = EmitterInstance.GetEmitterData();
		if (!EmitterData)
		{
			continue;
		}

		const FName EmitterName = Handle.GetName();
		if (EmittersToDisable.Contains(EmitterName))
		{
			Handle.SetIsEnabled(false, *NiagaraSystem_PC2Mobile, true);
			NiagaraSystem_PC2Mobile->WaitForCompilationComplete();
			UE_LOG(LogTemp, Log, TEXT("[NSPerformanceScorer] Disabled Emitter %s"), *EmitterName.ToString());
		}
	}
}

void ANSPerformanceScorerManager::GetNiagaraSystem()
{
	NiagaraSystem_Current = LoadObject<UNiagaraSystem>(nullptr, *(NiagaraAssetPathArray[NSArray_CurrentIndex % NiagaraAssetPathArray.Num()]));
	if (NiagaraSystem_Current)
	{
		NiagaraSystem_Current->WaitForCompilationComplete();
		if (bCheckMobileNS) // 需要检测移动端特效
		{
			GetMobileNiagaraSystem(NiagaraSystem_Current);
		}
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("[NSPerformanceScorer] %s Cant Find."), *(NiagaraAssetPathArray[NSArray_CurrentIndex % NiagaraAssetPathArray.Num()]));
	}
}

void ANSPerformanceScorerManager::WriteRowData_OriData(FKGNiagaraScoreOriData* InOutRowData)
{
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 0)
	{
		InOutRowData->Score_QL0_200 = NSScoreArray.Last();
		InOutRowData->Score_QL0_200_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL0_200_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_200_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_200_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL0_200_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 1)
	{
		InOutRowData->Score_QL0_500 = NSScoreArray.Last();
		InOutRowData->Score_QL0_500_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL0_500_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_500_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_500_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL0_500_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 2)
	{
		InOutRowData->Score_QL0_1000 = NSScoreArray.Last();
		InOutRowData->Score_QL0_1000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL0_1000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_1000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_1000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL0_1000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 3)
	{
		InOutRowData->Score_QL0_2000 = NSScoreArray.Last();
		InOutRowData->Score_QL0_2000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL0_2000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_2000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_2000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL0_2000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 4)
	{
		InOutRowData->Score_QL0_4000 = NSScoreArray.Last();
		InOutRowData->Score_QL0_4000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL0_4000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_4000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_4000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL0_4000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 5)
	{
		InOutRowData->Score_QL0_8000 = NSScoreArray.Last();
		InOutRowData->Score_QL0_8000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL0_8000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_8000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL0_8000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL0_8000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}

	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 0)
	{
		InOutRowData->Score_QL1_200 = NSScoreArray.Last();
		InOutRowData->Score_QL1_200_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL1_200_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_200_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_200_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL1_200_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 1)
	{
		InOutRowData->Score_QL1_500 = NSScoreArray.Last();
		InOutRowData->Score_QL1_500_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL1_500_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_500_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_500_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL1_500_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 2)
	{
		InOutRowData->Score_QL1_1000 = NSScoreArray.Last();
		InOutRowData->Score_QL1_1000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL1_1000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_1000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_1000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL1_1000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 3)
	{
		InOutRowData->Score_QL1_2000 = NSScoreArray.Last();
		InOutRowData->Score_QL1_2000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL1_2000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_2000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_2000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL1_2000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 4)
	{
		InOutRowData->Score_QL1_4000 = NSScoreArray.Last();
		InOutRowData->Score_QL1_4000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL1_4000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_4000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_4000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL1_4000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 5)
	{
		InOutRowData->Score_QL1_8000 = NSScoreArray.Last();
		InOutRowData->Score_QL1_8000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL1_8000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_8000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL1_8000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL1_8000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}

	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 0)
	{
		InOutRowData->Score_QL2_200 = NSScoreArray.Last();
		InOutRowData->Score_QL2_200_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL2_200_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_200_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_200_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL2_200_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 1)
	{
		InOutRowData->Score_QL2_500 = NSScoreArray.Last();
		InOutRowData->Score_QL2_500_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL2_500_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_500_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_500_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL2_500_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 2)
	{
		InOutRowData->Score_QL2_1000 = NSScoreArray.Last();
		InOutRowData->Score_QL2_1000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL2_1000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_1000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_1000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL2_1000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 3)
	{
		InOutRowData->Score_QL2_2000 = NSScoreArray.Last();
		InOutRowData->Score_QL2_2000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL2_2000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_2000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_2000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL2_2000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 4)
	{
		InOutRowData->Score_QL2_4000 = NSScoreArray.Last();
		InOutRowData->Score_QL2_4000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL2_4000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_4000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_4000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL2_4000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 5)
	{
		InOutRowData->Score_QL2_8000 = NSScoreArray.Last();
		InOutRowData->Score_QL2_8000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL2_8000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_8000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL2_8000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL2_8000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}

	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 0)
	{
		InOutRowData->Score_QL3_200 = NSScoreArray.Last();
		InOutRowData->Score_QL3_200_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL3_200_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_200_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_200_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL3_200_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 1)
	{
		InOutRowData->Score_QL3_500 = NSScoreArray.Last();
		InOutRowData->Score_QL3_500_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL3_500_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_500_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_500_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL3_500_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 2)
	{
		InOutRowData->Score_QL3_1000 = NSScoreArray.Last();
		InOutRowData->Score_QL3_1000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL3_1000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_1000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_1000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL3_1000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 3)
	{
		InOutRowData->Score_QL3_2000 = NSScoreArray.Last();
		InOutRowData->Score_QL3_2000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL3_2000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_2000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_2000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL3_2000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 4)
	{
		InOutRowData->Score_QL3_4000 = NSScoreArray.Last();
		InOutRowData->Score_QL3_4000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL3_4000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_4000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_4000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL3_4000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 5)
	{
		InOutRowData->Score_QL3_8000 = NSScoreArray.Last();
		InOutRowData->Score_QL3_8000_ShaderComplexity = ScreenPSComplexityMeanArray.Last();
		InOutRowData->Score_QL3_8000_CPUEmittersNum = CPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_8000_GPUEmittersNum = GPUEmittersNumArray.Last();
		InOutRowData->Score_QL3_8000_CPUParticlesNum = CPUParticlesNumArray.Last();
		InOutRowData->Score_QL3_8000_GPUParticlesNum = GPUParticlesNumArray.Last();
	}
}

void ANSPerformanceScorerManager::WriteToDataTable_OriData()
{
	if (!DataTable_OriData)
	{
		UE_LOG(LogTemp, Error, TEXT("[NSPerformanceScorer] Failed to load DataTable_Ori"));
		return;
	}
	// 确认 DataTable 的结构体类型正确
	if (DataTable_OriData->GetRowStruct() != FKGNiagaraScoreOriData::StaticStruct())
	{
		UE_LOG(LogTemp, Error, TEXT("[NSPerformanceScorer] DataTable_OriData RowStruct Mismatch FKGNiagaraScoreOriData!"));
		return;
	}

	// 查找是否存在行
	FKGNiagaraScoreOriData* ExistingRow = DataTable_OriData->FindRow<FKGNiagaraScoreOriData>(*NiagaraAssetPathArray[NSArray_CurrentIndex],
		TEXT("AddOrUpdate Row In FKGNiagaraScoreOriData"));

	if (ExistingRow)
	{
		WriteRowData_OriData(ExistingRow);
	}
	else
	{
		FKGNiagaraScoreOriData NewRow;

		// 创建新的行数据
		WriteRowData_OriData(&NewRow);

		// 添加到 DataTable
		DataTable_OriData->AddRow(*NiagaraAssetPathArray[NSArray_CurrentIndex], NewRow);
		UE_LOG(LogTemp, Warning, TEXT("[NSPerformanceScorer] Added new row: %s"), *NiagaraAssetPathArray[NSArray_CurrentIndex]);
	}
}

uint8 ANSPerformanceScorerManager::OriDataClampToInt8(const float oriFloatData)
{
	uint8 ret = 0;

	if (oriFloatData <= 0.f)
	{
		ret = 0;
	}
	else if (oriFloatData >= DataTable_MaxNSScore)
	{
		ret = 255;
	}
	else
	{
		// 四舍五入到最接近的整数，并确保至少为 1
		// 只要这个 NS 的原始 Float 分数大于 0，转成 uint8 之后就至少给 1 分
		ret = static_cast<uint8>(FMath::Max(FMath::RoundToInt(oriFloatData / DataTable_MaxNSScore * 255.f), 1.f));
	}

	return ret;
}

void ANSPerformanceScorerManager::WriteRowData_ClampToInt8(FKGNiagaraScoreData* InOutRowData)
{
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 0)
	{
		InOutRowData->Score_QL0_200 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 1)
	{
		InOutRowData->Score_QL0_500 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 2)
	{
		InOutRowData->Score_QL0_1000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 3)
	{
		InOutRowData->Score_QL0_2000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 4)
	{
		InOutRowData->Score_QL0_4000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 0 && NSDistance_CurrentIndex == 5)
	{
		InOutRowData->Score_QL0_8000 = OriDataClampToInt8(NSScoreArray.Last());
	}

	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 0)
	{
		InOutRowData->Score_QL1_200 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 1)
	{
		InOutRowData->Score_QL1_500 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 2)
	{
		InOutRowData->Score_QL1_1000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 3)
	{
		InOutRowData->Score_QL1_2000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 4)
	{
		InOutRowData->Score_QL1_4000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 1 && NSDistance_CurrentIndex == 5)
	{
		InOutRowData->Score_QL1_8000 = OriDataClampToInt8(NSScoreArray.Last());
	}

	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 0)
	{
		InOutRowData->Score_QL2_200 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 1)
	{
		InOutRowData->Score_QL2_500 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 2)
	{
		InOutRowData->Score_QL2_1000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 3)
	{
		InOutRowData->Score_QL2_2000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 4)
	{
		InOutRowData->Score_QL2_4000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 2 && NSDistance_CurrentIndex == 5)
	{
		InOutRowData->Score_QL2_8000 = OriDataClampToInt8(NSScoreArray.Last());
	}

	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 0)
	{
		InOutRowData->Score_QL3_200 = OriDataClampToInt8(NSScoreArray.Last());
		InOutRowData->Score_QL4_200 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 1)
	{
		InOutRowData->Score_QL3_500 = OriDataClampToInt8(NSScoreArray.Last());
		InOutRowData->Score_QL4_500 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 2)
	{
		InOutRowData->Score_QL3_1000 = OriDataClampToInt8(NSScoreArray.Last());
		InOutRowData->Score_QL4_1000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 3)
	{
		InOutRowData->Score_QL3_2000 = OriDataClampToInt8(NSScoreArray.Last());
		InOutRowData->Score_QL4_2000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 4)
	{
		InOutRowData->Score_QL3_4000 = OriDataClampToInt8(NSScoreArray.Last());
		InOutRowData->Score_QL4_4000 = OriDataClampToInt8(NSScoreArray.Last());
	}
	if (Scalability_CurrentIndex == 3 && NSDistance_CurrentIndex == 5)
	{
		InOutRowData->Score_QL3_8000 = OriDataClampToInt8(NSScoreArray.Last());
		InOutRowData->Score_QL4_8000 = OriDataClampToInt8(NSScoreArray.Last());
	}
}

void ANSPerformanceScorerManager::WriteToDataTable_ClampToInt8()
{
	if (!DataTable_ClampToInt8)
	{
		UE_LOG(LogTemp, Error, TEXT("[NSPerformanceScorer] Failed to load DataTable_ClampToInt8"));
		return;
	}
	// 确认 DataTable 的结构体类型正确
	if (DataTable_ClampToInt8->GetRowStruct() != FKGNiagaraScoreData::StaticStruct())
	{
		UE_LOG(LogTemp, Error, TEXT("[NSPerformanceScorer] DataTable_ClampToInt8 RowStruct Mismatch FKGNiagaraScoreData!"));
		return;
	}

	// 查找是否存在行
	FKGNiagaraScoreData* ExistingRow = DataTable_ClampToInt8->FindRow<FKGNiagaraScoreData>(*NiagaraAssetPathArray[NSArray_CurrentIndex],
		TEXT("AddOrUpdate Row In FKGNiagaraScoreData"));

	if (ExistingRow)
	{
		WriteRowData_ClampToInt8(ExistingRow);
	}
	else
	{
		FKGNiagaraScoreData NewRow;

		// 创建新的行数据
		WriteRowData_ClampToInt8(&NewRow);

		// 添加到 DataTable
		DataTable_ClampToInt8->AddRow(*NiagaraAssetPathArray[NSArray_CurrentIndex], NewRow);
		UE_LOG(LogTemp, Warning, TEXT("[NSPerformanceScorer] Added new row: %s"), *NiagaraAssetPathArray[NSArray_CurrentIndex]);
	}
}

void ANSPerformanceScorerManager::SaveDataTablesToDisk()
{
	FSavePackageArgs SaveArgs;
	SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
	SaveArgs.Error = GError;
	SaveArgs.SaveFlags = SAVE_NoError;

	/////--------------------------------------------------------------------
	FString PackagePath = DataTable_ClampToInt8->GetOutermost()->GetName();
	FString PackageFilename = FPackageName::LongPackageNameToFilename(PackagePath, FPackageName::GetAssetPackageExtension());
	UPackage* Package = DataTable_ClampToInt8->GetOutermost();

	bool bSaved = UPackage::SavePackage(Package, DataTable_ClampToInt8, *PackageFilename, SaveArgs);
	UE_LOG(LogTemp, Warning, TEXT("[NSPerformanceScorer] Save DataTable_ClampToInt8: %s"), bSaved ? TEXT("Success") : TEXT("Failed"));

	/////--------------------------------------------------------------------
	PackagePath = DataTable_OriData->GetOutermost()->GetName();
	PackageFilename = FPackageName::LongPackageNameToFilename(PackagePath, FPackageName::GetAssetPackageExtension());
	Package = DataTable_OriData->GetOutermost();

	bSaved = UPackage::SavePackage(Package, DataTable_OriData, *PackageFilename, SaveArgs);
	UE_LOG(LogTemp, Warning, TEXT("[NSPerformanceScorer] Save DataTable_OriData: %s"), bSaved ? TEXT("Success") : TEXT("Failed"));

}

void ANSPerformanceScorerManager::ANSPerformanceScorerManager_Start(
	const TArray<FString>& niagaraAssetPathArray, // NS资产路径
	const float moveSpeed_NiagaraActor, // NS位移速度
	const float playTime_NiagaraActor, // NS实际播放的时间；比如，实际播放 1 秒，但是需要检查 5 秒的性能表现，就会以 5 倍速播放
	const float checkTime_NiagaraActor, // NS检查的时间；比如，需要检查粒子播放 5 秒的性能表现
	const float dataTable_MaxNSScore, // 归一化到 0-255 时的最大分数
	const bool boolCheckMobileNS,  // 是否检查移动端特供裁剪后的 NS
	const int32 scalability_CurrentIndex, // 画质档位起始索引，便于断点续传
	const FString& dataTablePath_ClampToInt8,
	const FString& dataTablePath_OriData, // DataTable
	const FString& dataTablePath_ClampToInt8_Mobile,
	const FString& dataTablePath_OriData_Mobile
)
{
	MoveSpeed_NiagaraActor = moveSpeed_NiagaraActor;
	PlayTime_NiagaraActor = playTime_NiagaraActor;
	CheckTime_NiagaraActor = checkTime_NiagaraActor;
	NiagaraAssetPathArray = niagaraAssetPathArray;

	Scalability_CurrentIndex = scalability_CurrentIndex;

	DataTable_MaxNSScore = dataTable_MaxNSScore;
	DataTablePath_ClampToInt8 = dataTablePath_ClampToInt8;
	DataTablePath_ClampToInt8_Mobile = dataTablePath_ClampToInt8_Mobile;
	DataTablePath_OriData = dataTablePath_OriData;
	DataTablePath_OriData_Mobile = dataTablePath_OriData_Mobile;

	UE_LOG(LogTemp, Warning, TEXT("[NSPerformanceScorer] ANSPerformanceScorerManager Init %d"), NiagaraAssetPathArray.Num());

	bStartCheck = true;
	this->bCheckMobileNS = boolCheckMobileNS;

	if (GEditor)
	{
		for (FEditorViewportClient* ViewportClient : GEditor->GetAllViewportClients())
		{
			if (ViewportClient)
			{
				ViewportClient->SetViewMode(EViewModeIndex::VMI_ShaderComplexityWithQuadOverdraw);
				ViewportClient->Invalidate();
			}
		}
	}

	if (bCheckMobileNS)
	{
		DataTable_ClampToInt8 = LoadObject<UDataTable>(nullptr, *DataTablePath_ClampToInt8_Mobile);
		DataTable_OriData = LoadObject<UDataTable>(nullptr, *DataTablePath_OriData_Mobile);
	}
	else
	{
		DataTable_ClampToInt8 = LoadObject<UDataTable>(nullptr, *DataTablePath_ClampToInt8);
		DataTable_OriData = LoadObject<UDataTable>(nullptr, *DataTablePath_OriData);
	}
}
#endif // WITH_EDITOR
#pragma endregion NS性能打分相关

#pragma region FNSAssetCheckerUtils: 贴图相关
#if WITH_EDITOR

// 检查贴图是否有A通道
bool FNSAssetCheckerUtils::CheckTextureHasAlphaChannel(UTexture2D* Texture)
{
	if (!Texture)
	{
		return false;
	}

	const ETextureSourceFormat& TexSourceFormat = Texture->Source.GetFormat();
	if (TexSourceFormat == ETextureSourceFormat::TSF_BGRA8 || TexSourceFormat == ETextureSourceFormat::TSF_RGBA16
		|| TexSourceFormat == ETextureSourceFormat::TSF_RGBA16F || TexSourceFormat == ETextureSourceFormat::TSF_RGBA32F)
	{
		return true;
	}

	return false;
}

// 检查贴图某个通道中数值在某个区间的占比
float FNSAssetCheckerUtils::GetTextureChannelValueInRangeRatio(UTexture2D* Texture, int ValueMin, int ValueMax, int CheckChannel)
{
	if (!Texture) return -1.f;

	CheckChannel = FMath::Clamp(CheckChannel, 0, 3); // 格式BGRA: B = 0; G = 1; R = 2; A = 3
	if (CheckChannel == 3 && !CheckTextureHasAlphaChannel(Texture)) return -1.f;

	int32 Width = Texture->Source.GetSizeX();
	int32 Height = Texture->Source.GetSizeY();
	if (Width == 0 || Height == 0) return -1.f;

	const uint8* RawData = (const uint8*)Texture->Source.LockMipReadOnly(0);
	if (!RawData) return -1.f;

	int32 TotalPixels = Width * Height;
	int32 NotOneCount = 0;

	for (int32 i = 0; i < TotalPixels; ++i)
	{
		uint8 ChannelValue = RawData[i * 4 + CheckChannel];
		if (ChannelValue <= ValueMax && ChannelValue >= ValueMin)
		{
			++NotOneCount;
		}
	}
	Texture->Source.UnlockMip(0);

	return static_cast<float>(NotOneCount) / TotalPixels;
}

// =========================================================
#endif // WITH_EDITOR
#pragma endregion 贴图相关

