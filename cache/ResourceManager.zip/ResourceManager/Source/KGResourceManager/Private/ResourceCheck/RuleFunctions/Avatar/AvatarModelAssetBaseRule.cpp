// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/RuleFunctions/Avatar/AvatarModelAssetBaseRule.h"

#include "Asset/AvatarModelAsset.h"


UClass* UAvatarModelAssetBaseRule::GetAssetType()
{
	return UAvatarModelAssetBase::StaticClass();
}

