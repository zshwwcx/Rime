#include "ResourceCheck/RuleFunctions/Actor/LightComponentRule.h"

#include "Components/PointLightComponent.h"

bool ULightComponentRule::CheckComponentIntensityMappingForCharacter(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	const AActor* Actor = Cast<AActor>(AssetData.GetAsset());
	if (Actor == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Actor is null"));
		return bSuccess;
	}
	const TArray<FString>& WhiteActorList = Params.GetValueList("WhiteActorList");
	const FString ActorName = Actor->GetActorLabel();
	if (WhiteActorList.Contains(ActorName))
	{
		return bSuccess;
	}
	for (const UActorComponent* Comp : Actor->GetComponents())
	{
		const ULocalLightComponent* LightComponent = Cast<ULocalLightComponent>(Comp);
		if (LightComponent == nullptr)
		{
			continue;
		}
		if (!LightComponent->bIntensityMappingForCharacter)
		{
			Log.RegistryAndLog(AssetData, TEXT("LightComponent"), CheckRuleType,TEXT("场景内所有PointLight，SpotLight，RectLight component都需要勾选intensity mapping for character,未勾选的component:{}"),LightComponent->GetName());
			OutRepairParams.Add(TEXT("IntensityMappingForCharacter"), TEXT("1"));
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool ULightComponentRule::RepairComponentIntensityMappingForCharacter(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = false;
	AActor* Actor = Cast<AActor>(AssetData.GetAsset());
	if (!OutRepairParams.Contains(TEXT("IntensityMappingForCharacter")))
	{
		return bSuccess;
	}
	if (Actor == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Actor is null"));
		return bSuccess;
	}
	bool bModified = false;
	for (UActorComponent* Comp : Actor->GetComponents())
	{
		ULocalLightComponent* LightComponent = Cast<ULocalLightComponent>(Comp);
		if (LightComponent == nullptr)
		{
			continue;
		}
		if (!LightComponent->bIntensityMappingForCharacter)
		{
			LightComponent->bIntensityMappingForCharacter = true;
			bModified = true;
		}
	}
	if (bModified)
	{
		Actor->Modify();
		Actor->GetPackage()->MarkPackageDirty();
		bSuccess = true;
	}
	return bSuccess;
}
