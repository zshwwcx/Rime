// Fill out your copyright notice in the Description page of Project Settings.

#include "ResourceCheck/RuleFunctions/Actor/LandscapeRule.h"
#include "Landscape.h"
#include "LandscapeSubsystem.h"

UClass* ULandscapeRule::GetAssetType()
{
	return ALandscape::StaticClass();
}

bool ULandscapeRule::RepairNantie(const FAssetData& AssetData, TMap<FString, FString>& RepairParams)
{
	bool bDirty = false;
	if(ALandscape* Landscape = Cast<ALandscape>(AssetData.GetAsset()))
	{
		if (UWorld* World = GetWorld())
		{
			if (ULandscapeSubsystem* LandscapeSubsystem = World->GetSubsystem<ULandscapeSubsystem>())
			{
				for (auto Parameters : RepairParams)
				{
					FString PropertyName = Parameters.Key;
					FString PropertyValue = Parameters.Value;
					if (FProperty* Property = Landscape->GetClass()->FindPropertyByName(FName(*PropertyName)))
					{
						if (void* ValuePtr = Property->ContainerPtrToValuePtr<void>(Landscape))
						{
							Property->ImportText_Direct(*PropertyValue, ValuePtr, Landscape, PPF_None);
							FPropertyChangedEvent Event(Property);
							Landscape->PostEditChangeProperty(Event);
							// 可能存在值写入失败的情况，比如Texture的NeverStream必须在贴图大小是2的幂次方时才能设置为false
							FString Value;
							Property->ExportTextItem_Direct(Value, ValuePtr, nullptr, nullptr, PPF_None);
							if (Value == PropertyValue)
							{

								TArray<ALandscapeProxy*> ProxiesToBuild;
								ProxiesToBuild.Add(Landscape);
								LandscapeSubsystem->BuildNanite(MakeArrayView(ProxiesToBuild), false);
								
								Landscape->Modify();
								bDirty = Landscape->GetPackage()->MarkPackageDirty();
							}						
						}
					}
				}
			}
		}		
	}
	
	return bDirty;
}

bool ULandscapeRule::CheckOverallResolution(const FAssetData& AssetData, TMap<FString, FString>& RepairParams)
{
	if (ALandscape* Landscape = Cast<ALandscape>(AssetData.GetAsset()))
	{
		FIntRect Rect = Landscape->GetBoundingRect();
		FIntPoint Size = Rect.Size();
		if (Size.X != Size.Y)
		{
			Log.RegistryAndLog(AssetData, TEXT("Landscape"), CheckRuleType,
									TEXT("Landscape整体需要为正方形，当前为{}*{}"), Size.X, Size.Y);
			return false;
		}
	}
	return true;
}


bool ULandscapeRule::CheckRotation(const FAssetData& AssetData, TMap<FString, FString>& RepairParams)
{
	if (ALandscape* Landscape = Cast<ALandscape>(AssetData.GetAsset()))
	{
		FRotator Rotator = Landscape->GetActorRotation();
		if (Rotator.Yaw != 0.f || Rotator.Pitch != 0.f || Rotator.Roll != 0.f)
		{
			Log.RegistryAndLog(AssetData, TEXT("Landscape"), CheckRuleType,
									TEXT("Landscape的旋转值XYZ必须为(0,0,0)，当前为{}, {}, {}"), Rotator.Roll, Rotator.Pitch, Rotator.Yaw);
			return false;
		}
	}
	return true;
}

bool ULandscapeRule::CheckScale(const FAssetData& AssetData, TMap<FString, FString>& RepairParams)
{
	if (ALandscape* Landscape = Cast<ALandscape>(AssetData.GetAsset()))
	{
		FVector Scale = Landscape->GetActorScale();
		if (Scale.X != 100 || Scale.Y != 100 || Scale.Z != 100)
		{
			Log.RegistryAndLog(AssetData, TEXT("Landscape"), CheckRuleType,
									TEXT("Landscape的缩放值XYZ必须为(0,0,0)，当前为{}, {}, {}"), Scale.X, Scale.Y, Scale.Z);
			return false;
		}
	}
	return true;
}
