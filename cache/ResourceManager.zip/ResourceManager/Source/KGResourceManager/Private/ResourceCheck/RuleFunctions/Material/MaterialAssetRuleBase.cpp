#include "ResourceCheck/RuleFunctions/Material/MaterialAssetRuleBase.h"

#include "AssetRegistry/AssetRegistryModule.h"
#include "Particles/ParticleSystem.h"
#include "Particles/Beam/ParticleModuleBeamSource.h"
#include "Particles/Beam/ParticleModuleBeamTarget.h"
#include "ISourceControlModule.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "UObject/PackageRelocation.h"

FString UMaterialAssetRuleBase::MaterialUsagePropertyName = "MaterialUsages";

UClass* UMaterialAssetRuleBase::GetAssetType()
{
	return UMaterial::StaticClass();
}

bool UMaterialAssetRuleBase::PreExecuteAsset(const FAssetData& AssetData)
{
	SubmitMaterialGroups = Params.GetValueList("SubmitMaterialGroup");
	return true;
}

void GetParentAssets(const FName& InPackageName, TArray<FAssetData>& OutParentAssets)
{
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FName> AssetReferencers;
	AssetRegistryModule.Get().GetReferencers(InPackageName, AssetReferencers, UE::AssetRegistry::EDependencyCategory::All);
	OutParentAssets.Reserve(OutParentAssets.Num() + AssetReferencers.Num());
	for (int32 i = 0; i < AssetReferencers.Num(); ++i)
	{
		TArray<FAssetData> OutAssetData;
		AssetRegistryModule.Get().GetAssetsByPackageName(AssetReferencers[i], OutAssetData);
		if (!OutAssetData.IsEmpty())
		{
			OutParentAssets.Add(OutAssetData[0]);
		}
	}
}

void GetNecessaryUsage(const TArray<FAssetData>& ParentAssets, TSet<TEnumAsByte<EMaterialUsage>>& OutMaterialUsage)
{
	for (int32 i = 0; i < ParentAssets.Num(); ++i)
	{
		const FAssetData& ParentAssetData = ParentAssets[i];
		FString ParentAssetClassPathString = ParentAssetData.AssetClassPath.ToString();
		const UClass* ParentAssetClass = LoadObject<UClass>(nullptr, *ParentAssetClassPathString);
		if (!ParentAssetClass)
		{
			continue;
		}
		if (ParentAssetClass->IsChildOf(UMaterialInstance::StaticClass()))
		{
			TArray<FAssetData> GrandParentAssets;
			GetParentAssets(ParentAssetData.PackageName, GrandParentAssets);
			GetNecessaryUsage(GrandParentAssets, OutMaterialUsage);
		}
		else
		{
			if (ParentAssetClass->IsChildOf(USkeletalMesh::StaticClass()))
			{
				OutMaterialUsage.Add(EMaterialUsage::MATUSAGE_SkeletalMesh);
			}
			else if (ParentAssetClass->IsChildOf(UParticleSystem::StaticClass()))
			{
				OutMaterialUsage.Add(EMaterialUsage::MATUSAGE_MeshParticles);
			}
			else if (ParentAssetClass->IsChildOf(UParticleModuleBeamSource::StaticClass()) || ParentAssetClass->IsChildOf(UParticleModuleBeamTarget::StaticClass()))
			{
				OutMaterialUsage.Add(EMaterialUsage::MATUSAGE_BeamTrails);
			}
			else if (ParentAssetClass->IsChildOf(UStaticMesh::StaticClass()))
			{
				// 因为目前有场景导出流程，理论上所有static mesh对象都有可能被合批成为ISM
				OutMaterialUsage.Add(EMaterialUsage::MATUSAGE_InstancedStaticMeshes);
			}
		}
	}
}

void GetNecessaryUsage(const FAssetData& AssetData, TSet<TEnumAsByte<EMaterialUsage>>& OutMaterialUsage)
{
	TArray<FAssetData> ParentAssets;
	GetParentAssets(AssetData.PackageName, ParentAssets);
	GetNecessaryUsage(ParentAssets, OutMaterialUsage);
}

bool UMaterialAssetRuleBase::CheckMaterialUsage(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	TSet<TEnumAsByte<EMaterialUsage>> MaterialUsage;
	GetNecessaryUsage(AssetData, MaterialUsage);
	FString AssetMessage = TEXT("");

	if (MaterialUsage.IsEmpty())
	{
		return true;
	}

	if (UMaterial* Material = Cast<UMaterial>(AssetData.GetAsset()))
	{
		FString OutRepairValue;
		for (TSet<TEnumAsByte<EMaterialUsage>>::TIterator ItrMap(MaterialUsage); ItrMap; ++ItrMap)
		{
			if (!Material->GetUsageByFlag(*ItrMap))
			{
				// 特例：材质内勾选了Used with Skeletal Mesh，则无需要勾 InstancedStaticMeshes
				if (*ItrMap == EMaterialUsage::MATUSAGE_InstancedStaticMeshes && Material->GetUsageByFlag(EMaterialUsage::MATUSAGE_SkeletalMesh))
				{
					continue;
				}
				AssetMessage += FString::Format(TEXT("需要勾选{0}"), {UEnum::GetValueAsString(*ItrMap)});
				OutRepairValue += FString::Format(TEXT("{0},"), {UEnum::GetValueAsString(*ItrMap)});
			}
		}

		if (AssetMessage.Len() > 0)
		{
			auto ResourcePath = Material->GetPathName();

			Log.RegistryAndLog(AssetData, TEXT("MaterialUsage"), CheckRuleType, TEXT("下列MaterialUsage需修改:{}"), AssetMessage);
			OutRepairParams.Add(MaterialUsagePropertyName, OutRepairValue);
			return false;
		}
	}
	
	return true;
}

bool UMaterialAssetRuleBase::SubmitCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;

	UMaterial* Material = Cast<UMaterial>(AssetData.GetAsset());
	if (Material == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find Material From AssetData"))
		return bSuccess;
	}

	const TArray<FString>& WhiteMaterialFunctions = Params.GetValueList(TEXT("WhiteMaterialFunctions"));
	if (!WhiteMaterialFunctions.IsEmpty())
	{
		const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
		TArray<FName> AssetDependencies;
		AssetRegistryModule.Get().GetDependencies(AssetData.PackageName, AssetDependencies, UE::AssetRegistry::EDependencyCategory::All);
		for (int32 i = 0; i < AssetDependencies.Num(); ++i)
		{
			TArray<FAssetData> OutAssetData;
			AssetRegistryModule.Get().GetAssetsByPackageName(AssetDependencies[i], OutAssetData);
			if (!OutAssetData.IsEmpty())
			{
				const FAssetData& DependenceAssetData = OutAssetData[0];
				const UClass* DependenceClass = DependenceAssetData.GetClass();
				if (DependenceClass && DependenceClass->IsChildOf(UMaterialFunction::StaticClass()))
				{
					if (WhiteMaterialFunctions.Contains(DependenceAssetData.AssetName))
					{
						return bSuccess;
					}
				}
			}
		}
	}

	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	FString UserName = SourceControlProvider.GetWorkSpaceUserName();
	
	FString Process = TEXT("p4");
	FString Command = FString::Printf(TEXT("groups %s"), *UserName);

	int32 ResultCode;
	FString Result;
	FString ResultErr;

	bool bProcessSuccess = FPlatformProcess::ExecProcess(*Process, *Command, &ResultCode, &Result, &ResultErr);
	if (bProcessSuccess && Result != "")
	{
		TArray<FString> SplitStrings;
		Result.TrimStartAndEnd().ParseIntoArray(SplitStrings, TEXT("\n"), false);

		bool bContain = false;
		for(auto SplitString : SplitStrings)
		{
			FString UserGroup = SplitString.TrimStartAndEnd();
			if(SubmitMaterialGroups.Contains(UserGroup))
			{
				bContain = true;
			}
		}
			
		if(!bContain)
		{
			Log.RegistryAndLog(AssetData, TEXT("Material"), CheckRuleType, TEXT("非引擎和TA组无法增删改材质"));
			bSuccess = false;	
		}
	}
	else
	{
		Log.RegistryAndLog(AssetData, TEXT("Material"), CheckRuleType, TEXT("P4返回结果出现问题，请重启引擎"));
		bSuccess = false;
	}
	return bSuccess;
}

bool UMaterialAssetRuleBase::RepairMaterialUsage(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	if (Arguments.Contains(MaterialUsagePropertyName))
	{
		if (UMaterial* Material = Cast<UMaterial>(AssetData.GetAsset()))
		{
			FString OutRepairValue = Arguments[MaterialUsagePropertyName];
			TArray<FString> MaterialUsages;
			OutRepairValue.ParseIntoArray(MaterialUsages, TEXT(","), true);
			static const UEnum* MaterialUsageEnum = StaticEnum<EMaterialUsage>();
			for (auto Usage : MaterialUsages)
			{
				int64 MaterialUsageIndex = MaterialUsageEnum->GetValueByName(FName(Usage));
				EMaterialUsage MaterialUsage = static_cast<EMaterialUsage>(MaterialUsageIndex);
				bool bNeedsRecompile;
				Material->SetMaterialUsage(bNeedsRecompile, MaterialUsage);
			}
			Material->Modify();
			Material->GetPackage()->MarkPackageDirty();
			return true;
		}
	}
	return false;
}

