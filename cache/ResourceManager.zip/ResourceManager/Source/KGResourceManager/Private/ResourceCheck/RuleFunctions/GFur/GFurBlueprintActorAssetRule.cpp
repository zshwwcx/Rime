#include "ResourceCheck/RuleFunctions/GFur/GFurBlueprintActorAssetRule.h"

#include "Engine/InheritableComponentHandler.h"
#include "Engine/SCS_Node.h"
#include "Engine/SimpleConstructionScript.h"


bool UGFurBlueprintActorAssetRule::PreExecuteAsset(const FAssetData& AssetData)
{
	const UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset());
	if (Blueprint == nullptr || Blueprint->ParentClass == nullptr)
	{
		return false;
	}
	if (!Blueprint->ParentClass->IsChildOf(AActor::StaticClass()))
	{
		return false;
	}
	return true;
}

TArray<UGFurComponent*> UGFurBlueprintActorAssetRule::GetAllGFurComponents(const FAssetData& AssetData)
{
	TArray<UGFurComponent*> GFurComponents;
	UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset());
	if (Blueprint == nullptr || Blueprint->ParentClass == nullptr)
	{
		return GFurComponents;
	}
	if (!Blueprint->ParentClass->IsChildOf(AActor::StaticClass()))
	{
		return GFurComponents;
	}
	const USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript;
	if (SCS == nullptr)
	{
		return GFurComponents;
	}
	const USCS_Node* DefaultSceneRootNode = SCS->GetDefaultSceneRootNode();
	if (SCS->GetRootNodes().Contains(DefaultSceneRootNode))
	{
		auto GetAllChildNodes = [](const USCS_Node* Node)
		{
			TArray<const USCS_Node*> AllNodes;
			TArray<const USCS_Node*> Nodes;
			Nodes.Add(Node);
			while (Nodes.Num() > 0)
			{
				const USCS_Node* N = Nodes.Pop();
				if (N == nullptr)
				{
					continue;
				}
				AllNodes.Add(N);
				Nodes.Append(N->GetChildNodes());
			}
			return AllNodes;
		};
		USceneComponent* RootComponent = SCS->GetSceneRootComponentTemplate();
		if (RootComponent == nullptr)
		{
			return GFurComponents;
		}
		if (UGFurComponent* GFur = Cast<UGFurComponent>(RootComponent))
		{
			GFurComponents.Add(GFur);
		}
		for (const USCS_Node* Node : GetAllChildNodes(DefaultSceneRootNode))
		{
			if (Node == nullptr)
			{
				continue;
			}
			if (UGFurComponent* GFur = Cast<UGFurComponent>(Node->ComponentTemplate))
			{
				GFurComponents.Add(GFur);
			}
		}
	}
	else
	{
		USCS_Node* OutSCSNode;
		const USceneComponent* RootComponent = SCS->GetSceneRootComponentTemplate(false, &OutSCSNode);
		if (UInheritableComponentHandler* InheritableComponentHandler = Blueprint->GetInheritableComponentHandler(false))
		{
			if (OutSCSNode != nullptr)
			{
				const FComponentKey Key(OutSCSNode);
				const UActorComponent* OverridenComponentTemplate = InheritableComponentHandler->GetOverridenComponentTemplate(Key);
				if (OverridenComponentTemplate != nullptr)
				{
					RootComponent = Cast<USceneComponent>(OverridenComponentTemplate);
				}
			}
			TArray<UActorComponent*> AllTemplates;
			InheritableComponentHandler->GetAllTemplates(AllTemplates);
			for (UActorComponent* ComponentTemplate : AllTemplates)
			{
				if (UGFurComponent* GFur = Cast<UGFurComponent>(ComponentTemplate))
				{
					GFurComponents.Add(GFur);
				}
			}
		}
		if (RootComponent == nullptr)
		{
			return GFurComponents;
		}
		for (const USCS_Node* Node : SCS->GetAllNodes())
		{
			if (Node == nullptr)
			{
				continue;
			}
			if (UGFurComponent* GFur = Cast<UGFurComponent>(Node->ComponentTemplate))
			{
				GFurComponents.Add(GFur);
			}
		}
	}
	return GFurComponents;
}

bool UGFurBlueprintActorAssetRule::CheckLODsCount(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TArray<UGFurComponent*> GFurComponents = GetAllGFurComponents(AssetData);
	const int32 ValidLODsCount = FCString::Atoi(*Params.GetValue("ValidLODsCount"));
	for (const UGFurComponent* GFur : GFurComponents)
	{
		if (GFur && GFur->LODs.Num() < ValidLODsCount)
		{
			Log.RegistryAndLog(AssetData, TEXT("GFurBlueprintActorAsset"), CheckRuleType, TEXT("蓝图内GFur组件{}的LOD数量需要大于等于{}"), GFur->GetName(), ValidLODsCount);
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UGFurBlueprintActorAssetRule::CheckLayerCount(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TArray<UGFurComponent*> GFurComponents = GetAllGFurComponents(AssetData);
	const int32 ValidLayerCount = FCString::Atoi(*Params.GetValue("ValidLayerCount"));
	for (const UGFurComponent* GFur : GFurComponents)
	{
		if (GFur && GFur->LayerCount > ValidLayerCount)
		{
			Log.RegistryAndLog(AssetData, TEXT("GFurBlueprintActorAsset"), CheckRuleType, TEXT("蓝图内GFur组件{}的layerCount需要小于等于{}"), GFur->GetName(), ValidLayerCount);
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UGFurBlueprintActorAssetRule::CheckGrowMeshVertices(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TArray<UGFurComponent*> GFurComponents = GetAllGFurComponents(AssetData);
	const int32 ValidGrowMeshVertices = FCString::Atoi(*Params.GetValue("ValidGrowMeshVertices"));
	for (const UGFurComponent* GFur : GFurComponents)
	{
		if (GFur == nullptr)
		{
			continue;
		}
		if (const USkeletalMesh* SkeletalGrowMesh = GFur->SkeletalGrowMesh)
		{
			FSkeletalMeshRenderData* SkelMeshRenderData = SkeletalGrowMesh->GetResourceForRendering();
			if (SkelMeshRenderData && SkelMeshRenderData->LODRenderData.Num() > 0)
			{
				const FSkeletalMeshLODRenderData& LODData = SkelMeshRenderData->LODRenderData[0];
				if (LODData.GetNumVertices() > static_cast<uint32>(ValidGrowMeshVertices))
				{
					Log.RegistryAndLog(AssetData, TEXT("GFurBlueprintActorAsset"), CheckRuleType, TEXT("蓝图内GFur组件{}的SkeletalGrowMesh顶点数需要不大于{}"), GFur->GetName(), ValidGrowMeshVertices);
					bSuccess = false;
				}
			}
		}

		if (const UStaticMesh* StaticMesh = GFur->StaticGrowMesh)
		{
			if (StaticMesh->GetRenderData() && StaticMesh->GetRenderData()->LODResources.Num() > 0)
			{
				const FStaticMeshLODResources& LOD = StaticMesh->GetRenderData()->LODResources[0];
				if (LOD.GetNumVertices() > ValidGrowMeshVertices)
				{
					Log.RegistryAndLog(AssetData, TEXT("GFurBlueprintActorAsset"), CheckRuleType, TEXT("蓝图内GFur组件{}的StaticGrowMesh顶点数需要不大于{}"), GFur->GetName(), ValidGrowMeshVertices);
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}
