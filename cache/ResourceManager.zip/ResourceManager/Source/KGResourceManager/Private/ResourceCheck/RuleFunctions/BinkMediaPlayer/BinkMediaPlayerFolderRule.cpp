#include "ResourceCheck/RuleFunctions/BinkMediaPlayer/BinkMediaPlayerFolderRule.h"
#include "BinkMediaPlayer.h"
#include "BinkMediaTexture.h"

UClass* UBinkMediaPlayerFolderRule::GetAssetType()
{
	return UObject::StaticClass();
}

bool UBinkMediaPlayerFolderRule::CheckAssetClass(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	if (AssetData.GetClass() == UBinkMediaPlayer::StaticClass() ||
		AssetData.GetClass() == UBinkMediaTexture::StaticClass())
	{
		return true;
	}
	else
	{
		Log.RegistryAndLog(AssetData, TEXT("BinkMediaPlayer"), CheckRuleType, TEXT("在/Game/Movies/目录下存在非BinkMedia相关的资源")); 
	}
	return false;
}