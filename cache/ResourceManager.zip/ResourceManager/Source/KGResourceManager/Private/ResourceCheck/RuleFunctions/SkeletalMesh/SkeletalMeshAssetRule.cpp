#include "ResourceCheck/RuleFunctions/SkeletalMesh/SkeletalMeshAssetRule.h"

#include "ISourceControlModule.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "SourceControlHelpers.h"
#include "Asset/AvatarPresetBase.h"
#include "Asset/DressProfile.h"
#include "Asset/MeshPartCollection.h"
#include "PhysicsEngine/PhysicsAsset.h"
#include "PhysicsEngine/ShapeElem.h"
#include "PhysicsEngine/SkeletalBodySetup.h"
#include "Rendering/SkeletalMeshModel.h"
#include "Rendering/SkeletalMeshRenderData.h"

UClass* USkeletalMeshAssetRule::GetAssetType()
{
	return USkeletalMesh::StaticClass();
}

bool USkeletalMeshAssetRule::PreExecuteAsset(const FAssetData& AssetData)
{
	if(USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset()))
	{
		if (!SkeletalMesh->GetSkeleton())
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), ERMCheckRuleType::Error, TEXT("{} 缺少Skeleton"), AssetData.GetAsset()->GetName());
			return false;
		}
	}
	return true;
}

bool USkeletalMeshAssetRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	if (Params.ParamList.Contains(TEXT("CoatBone")))
	{
		CoatBone = Params.GetValue(TEXT("CoatBone"));
	}
	return true;
}

bool USkeletalMeshAssetRule::CheckSkeletonExists(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	if (!SkeletalMesh->GetSkeleton())
	{
		Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("{} 缺少Skeleton"), AssetData.GetAsset()->GetName());
		return false;
	}	
	return true;
}

bool USkeletalMeshAssetRule::CheckHairMaterialSlot(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FName> AssetReferencers;
	AssetRegistryModule.Get().GetReferencers(AssetData.PackageName, AssetReferencers, UE::AssetRegistry::EDependencyCategory::All);
	for (int32 i = 0; i < AssetReferencers.Num(); ++i)
	{
		TArray<FAssetData> OutAssetData;
		AssetRegistryModule.Get().GetAssetsByPackageName(AssetReferencers[i], OutAssetData);
		if (OutAssetData.IsEmpty())
		{
			continue;
		}
		if (OutAssetData[0].AssetClassPath != UMeshPartDefine::StaticClass()->GetClassPathName())
		{
			continue;
		}
		TArray<FName> PartDefineReferencers;
		AssetRegistryModule.Get().GetReferencers(OutAssetData[0].PackageName, PartDefineReferencers, UE::AssetRegistry::EDependencyCategory::All);
		for (int32 j = 0; j < PartDefineReferencers.Num(); ++j)
		{
			TArray<FAssetData> PartDefineAssetData;
			AssetRegistryModule.Get().GetAssetsByPackageName(PartDefineReferencers[j], PartDefineAssetData);
			if (PartDefineAssetData.IsEmpty())
			{
				continue;
			}
			if (PartDefineAssetData[0].AssetClassPath != UHairPreset::StaticClass()->GetClassPathName())
			{
				continue;
			}
			UHairPreset* HairPreset = Cast<UHairPreset>(PartDefineAssetData[0].GetAsset());
			if (!HairPreset->DressInstance)
			{
				continue;
			}
			for (const FDressProperty& DressProperty : HairPreset->DressInstance->DressProperties)
			{
				if (DressProperty.BodyPartType == EAvatarBodyPartType::Hair && DressProperty.MeshPart)
				{
					if (USkeletalMesh* SkeletalMesh = DressProperty.MeshPart->GetSkeletalMesh())
					{
						if (SkeletalMesh != AssetData.GetAsset())
						{
							continue;
						}
						const TArray<FSkeletalMaterial>& Materials = SkeletalMesh->GetMaterials();
						bool bFindHairSlot = false;
						for (const FSkeletalMaterial& Material : Materials)
						{
							if (Material.MaterialSlotName == "Hair")
							{
								bFindHairSlot = true;
								break;
							}
						}
						if (!bFindHairSlot)
						{
							Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("HairPreset 引用的Skeletal Mesh的材质插槽名需要有 Hair"));
							return false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool USkeletalMeshAssetRule::CheckSkeletonInChangeList(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	if (!SkeletalMesh)
	{
		return true;
	}
	bool bSuccess = true;
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	if (FSourceControlStatePtr SourceControlState = SourceControlProvider.GetState(SourceControlHelpers::PackageFilename(SkeletalMesh->GetPathName()), EStateCacheUsage::Use))
	{
		FSourceControlChangelistPtr ChangelistPtr = SourceControlState->GetCheckInIdentifier();
		FString SkeletalMeshIdentifier = ChangelistPtr->GetIdentifier();
		if (USkeleton* Skeleton = SkeletalMesh->GetSkeleton())
		{
			if (FSourceControlStatePtr SkeletonSourceControlState = SourceControlProvider.GetState(SourceControlHelpers::PackageFilename(Skeleton->GetPathName()), EStateCacheUsage::Use))
			{
				FSourceControlChangelistPtr SkeletonChangelistPtr = SkeletonSourceControlState->GetCheckInIdentifier();
				FString SkeletonIdentifier = SkeletonChangelistPtr->GetIdentifier();
				if (SkeletalMeshIdentifier == SkeletonIdentifier)
				{
					return true;
				}
				UObject* HistoryObject = FResourceCheckHelper::GetHistoryObject(Skeleton->GetPathName(), Skeleton->GetName());
				if (USkeleton* HistorySkeleton = Cast<USkeleton>(HistoryObject))
				{
					const FReferenceSkeleton& MeshRefSkel = SkeletalMesh->GetRefSkeleton();

					const int32 NumMeshBones = MeshRefSkel.GetNum();

					for (int32 MeshBoneIndex = 0; MeshBoneIndex < NumMeshBones; MeshBoneIndex++)
					{
						const FName MeshBoneName = MeshRefSkel.GetBoneName(MeshBoneIndex);
						int32 SkeletonBoneIndex = HistorySkeleton->GetReferenceSkeleton().FindBoneIndex(MeshBoneName);

						if (SkeletonBoneIndex == INDEX_NONE)
						{
							Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("当骨骼网格体有骨骼的增减时，需要同步提交骨骼资产"));
							return false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool USkeletalMeshAssetRule::CheckLODGenerated(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	if(USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset()))
	{
		for (int32 LODIndex = 0; LODIndex < 2; ++LODIndex)
		{
			if (SkeletalMesh->IsValidLODIndex(LODIndex))
			{
				if (SkeletalMesh->GetLODInfo(LODIndex)->bHasBeenSimplified)
				{
					Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("S/A的头发SkeletalMesh的LOD0和LOD1需要是手动导入的"));
					return false;
				}
			}
		}
	}
	return true;
}

bool USkeletalMeshAssetRule::CheckLODTriangleRatio(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TArray<FString> LODTriangleRatio = Params.GetValueList("LODTriangleRatio");
	
	if(USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset()))
	{
		if(FSkeletalMeshRenderData* RenderData = SkeletalMesh->GetResourceForRendering())
		{
			if (RenderData->LODRenderData.Num() > 2)
			{
				int32 FirstLodFaces = RenderData->LODRenderData[1].GetTotalFaces();
				for (int32 LODIndex = 2; LODIndex < RenderData->LODRenderData.Num(); ++LODIndex)
				{
					if (LODTriangleRatio.Num() < (LODIndex - 1) * 2)
					{
						break;
					}
					const FSkeletalMeshLODRenderData& LODData = RenderData->LODRenderData[LODIndex];
					int32 TotalFaces = LODData.GetTotalFaces();
					float MinRatio = FCString::Atof(*LODTriangleRatio[(LODIndex - 2) * 2]);
					float MaxRatio = FCString::Atof(*LODTriangleRatio[(LODIndex - 2) * 2 + 1]);
					float Ratio = TotalFaces / static_cast<float>(FirstLodFaces);
					if (Ratio < MinRatio || Ratio > MaxRatio)
					{
						Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("LOD{}面数必须大于LOD1的{}%,小于LOD1的{}%,当前为{}%"), LODIndex, MinRatio * 100, MaxRatio * 100, Ratio * 100);
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

FString USkeletalMeshAssetRule::GetBoundsPhysicsAssetShapeCount(const FAssetData& AssetData)
{
	const USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	if (SkeletalMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find SkeletalMesh From AssetData"))
		return TEXT("0");
	}
	UPhysicsAsset* PhysicsAsset = SkeletalMesh->GetBoundsPhysicsAsset();
	if (PhysicsAsset == nullptr)
	{
		return TEXT("0");
	}
	TSet<EAggCollisionShape::Type> ShapeTypes;
	ShapeTypes.Add(EAggCollisionShape::Sphere);
	ShapeTypes.Add(EAggCollisionShape::Box);
	ShapeTypes.Add(EAggCollisionShape::Sphyl);
	ShapeTypes.Add(EAggCollisionShape::Convex);
	ShapeTypes.Add(EAggCollisionShape::TaperedCapsule);
	int32 TotalShapeCount = 0;
	for (const TObjectPtr <USkeletalBodySetup>& SkeletalBodySetup : PhysicsAsset->SkeletalBodySetups)
	{
		if (SkeletalBodySetup)
		{
			for (const EAggCollisionShape::Type& Type : ShapeTypes)
			{
				TotalShapeCount += SkeletalBodySetup->AggGeom.GetElementCount(Type);
			}
		}
	}
	return FString::FromInt(TotalShapeCount);
}

FString USkeletalMeshAssetRule::GetLODNum(const FAssetData& AssetData)
{
	FString LODs = FResourceCheckHelper::GetPropertyValueByName(AssetData, "LODs");
	return LODs;
}

FString USkeletalMeshAssetRule::GetSkeletonNum(const FAssetData& AssetData)
{
	if(USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset())) 
	{
		if(FSkeletalMeshRenderData* RenderData = SkeletalMesh->GetResourceForRendering())
		{
			if (USkeleton* Skeleton = SkeletalMesh->GetSkeleton())
			{
				int32 LodNum = FCString::Atoi(*GetLODNum(AssetData));
				if(LodNum > 0)
				{
					int32 ActiveBoneIndicesNumBones = 0;
		
					const FReferenceSkeleton& ReferenceSkeleton = Skeleton->GetReferenceSkeleton();
					int32 NumBones = ReferenceSkeleton.GetNum();
					FSkeletalMeshLODRenderData& LODRenderData = RenderData->LODRenderData[0];				
					for(int32 BoneIndex = 0; BoneIndex < NumBones; BoneIndex ++)
					{
						int32 Index = LODRenderData.ActiveBoneIndices.Find(IntCastChecked<FBoneIndexType>(BoneIndex));
						if(Index != INDEX_NONE)
						{
							ActiveBoneIndicesNumBones++;
						}
					}
					return FString::FromInt(ActiveBoneIndicesNumBones);
				}
			}
		}
	}
	return FString::FromInt(0);
}

FString USkeletalMeshAssetRule::GetBones(const FAssetData& AssetData)
{
	if(USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset()))
	{
		return FString::FromInt(SkeletalMesh->GetRefSkeleton().GetRawBoneNum());
	}
	return FString::FromInt(0);
}

FString USkeletalMeshAssetRule::GetNumVertices(const FAssetData& AssetData)
{
	FString Vertices = FResourceCheckHelper::GetPropertyValueByName(AssetData, "Vertices");
	return Vertices;
}
FString USkeletalMeshAssetRule::GetSkinCacheUsage(const FAssetData& AssetData)
{
	USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	UEnum* EnumPtr = StaticEnum<ESkinCacheUsage>();
	ESkinCacheUsage SkinCacheUsage = SkeletalMesh->GetLODInfo(0)->SkinCacheUsage;
	
	return EnumPtr->GetNameByValue(int32(SkinCacheUsage)).ToString();
}
FString USkeletalMeshAssetRule::GetTotalTriangles(const FAssetData& AssetData)
{
	FString Triangles = FResourceCheckHelper::GetPropertyValueByName(AssetData, "Triangles");
	return Triangles;
}

FString USkeletalMeshAssetRule::GetNumMaterials(const FAssetData& AssetData)
{
	USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	return FString::FromInt(SkeletalMesh->GetMaterials().Num());
}

FString USkeletalMeshAssetRule::GetNumMeshClothingAssets(const FAssetData& AssetData)
{
	USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	return FString::FromInt(SkeletalMesh->GetMeshClothingAssets().Num());
}

FString USkeletalMeshAssetRule::IsHumanLike(const FAssetData& AssetData)
{
	if (USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset()))
	{
		if (USkeleton* Skeleton = SkeletalMesh->GetSkeleton())
		{
			FString SkeletonName = Skeleton->GetName();
			if (SkeletonName == "SKEL_3C")
			{
				return "1";
			}
		}
	}
	return "0";
}

bool USkeletalMeshAssetRule::CheckMeshLODMaterialValid(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	const USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	if (SkeletalMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find SkeletalMesh From AssetData"))
		return bSuccess;
	}
	const FSkeletalMeshModel* SkeletalMeshModel = SkeletalMesh->GetImportedModel();
	if (SkeletalMeshModel == nullptr)
	{
		return bSuccess;
	}
	const TArray<FSkeletalMaterial>& Materials = SkeletalMesh->GetMaterials();
	for (const FSkeletalMeshLODModel& LODModel : SkeletalMeshModel->LODModels)
	{
		for (const FSkelMeshSection& Section : LODModel.Sections)
		{
			if (!Materials.IsValidIndex(Section.MaterialIndex))
			{
				Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("网格体的LOD Section材质Index不存在,索引号:{}"), Section.MaterialIndex);
				bSuccess = false;
			}
		}
	}
	return bSuccess;
}

bool USkeletalMeshAssetRule::CheckFullBones(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	const USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	if (SkeletalMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find SkeletalMesh From AssetData"))
		return bSuccess;
	}

	TObjectPtr<USkeleton> Skeleton = SkeletalMesh->Skeleton;
	if (!Skeleton)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find Skeleton from SkeletalMesh"))
		return bSuccess;
	}
	const FReferenceSkeleton& SkeletonRefSkel = Skeleton->GetReferenceSkeleton();
	const FReferenceSkeleton& MeshRefSkel = SkeletalMesh->GetRefSkeleton();

	const int32 NumMeshBones = MeshRefSkel.GetNum();
	for (int32 MeshBoneIndex = 0; MeshBoneIndex < NumMeshBones; MeshBoneIndex++)
	{
		const FName MeshBoneName = MeshRefSkel.GetBoneName(MeshBoneIndex);
		int32 SkeletonBoneIndex = SkeletonRefSkel.FindBoneIndex(MeshBoneName);

		if (SkeletonBoneIndex == INDEX_NONE)
		{
			Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("Skeleton{}中不能缺少SkeletalMesh{}中需要的骨骼{}"),
				Skeleton->GetName(), SkeletalMesh->GetName(), MeshBoneName.ToString());
			bSuccess = false;
		}
	}

	return bSuccess;
}

bool USkeletalMeshAssetRule::CheckMaterialUsedWithSkeletalMesh(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	const USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	if (SkeletalMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find SkeletalMesh From AssetData"))
		return bSuccess;
	}
	for (const FSkeletalMaterial& SkeletalMaterial : SkeletalMesh->GetMaterials())
	{
		if (UMaterialInterface* MatInterface = SkeletalMaterial.MaterialInterface)
		{
			if (const UMaterial* Material = MatInterface->GetMaterial())
			{
				if (!Material->bUsedWithSkeletalMesh)
				{
					Log.RegistryAndLog(AssetData, TEXT("SkeletalMesh"), CheckRuleType, TEXT("材质实例{}检测不到支持SkeletalMesh的材质，需要改用支持SkeletalMesh的中继材质"), MatInterface->GetName());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool USkeletalMeshAssetRule::CheckCoatBone(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	if (CoatBone.IsEmpty() || CoatBone == "None") return true;

	bool bSuccess = true;
	const USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(AssetData.GetAsset());
	if (SkeletalMesh == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find SkeletalMesh From AssetData"))
		return bSuccess;
	}
	// 获取参考骨架
	const FReferenceSkeleton& RefSkeleton = SkeletalMesh->GetRefSkeleton();
	// 查找骨骼索引
	const int32 BoneIndex = RefSkeleton.FindBoneIndex(FName(*CoatBone));
	if (BoneIndex == INDEX_NONE)
	{
		Log.RegistryAndLog(AssetData, TEXT("SkeletalMesh"), CheckRuleType, TEXT("命名中有_Coat的骨骼网格体必须有骨骼{}"), FText::FromString(CoatBone));
		bSuccess = false;
	}
	return bSuccess;
}
