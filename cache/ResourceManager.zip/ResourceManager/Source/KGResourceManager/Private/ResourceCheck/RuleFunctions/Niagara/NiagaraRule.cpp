// Fill out your copyright notice in the Description page of Project Settings.

#include "ResourceCheck/RuleFunctions/Niagara/NiagaraRule.h"

#include "NiagaraEditorUtilities.h"
#include "NiagaraLightRendererProperties.h"
#include "NiagaraMeshRendererProperties.h"
#include "NiagaraNodeOutput.h"
#include "NiagaraScriptSource.h"
#include "NiagaraSettings.h"
#include "NiagaraSpriteRendererProperties.h"
#include "NiagaraSystem.h"
#include "ResourceCheck/RuleFunctions/Niagara/NSAssetChecker.h"
#include "ViewModels/Stack/NiagaraStackFunctionInput.h"
#include "ViewModels/Stack/NiagaraStackModuleItem.h"
#include "ViewModels/Stack/NiagaraStackRendererItem.h"
#include "ViewModels/Stack/NiagaraStackViewModel.h"


namespace NiagaraRuleHelper
{
	TArray<UObject*> GetDependedAssets(const UObject* ParentObject)
	{
		const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
		TArray<FName> AssetDependencies;
		TArray<UObject*> DependedAssets;
		const FName Name = ParentObject->GetPackage()->GetFName();
		AssetRegistryModule.Get().GetDependencies(Name, AssetDependencies, UE::AssetRegistry::EDependencyCategory::All);
		for (int32 i = 0; i < AssetDependencies.Num(); ++i)
		{
			TArray<FAssetData> OutAssetData;
			AssetRegistryModule.Get().GetAssetsByPackageName(AssetDependencies[i], OutAssetData);
			if (!OutAssetData.IsEmpty())
			{
				UObject* AssetInPackage = OutAssetData[0].GetAsset();
				DependedAssets.Add(AssetInPackage);
			}
		}
		return DependedAssets;
	}

	template<typename T>
	void GetDependedTypeAssets(TArray<UObject*> DependedAssets, TArray<T*>& DependedAssetArray, int& IterationCount)
	{
		IterationCount++;
		if (IterationCount > 3)
		{
			IterationCount--;
			return;
		}
		for(int32 i = 0; i < DependedAssets.Num(); ++i)
		{
			UObject* DependedAsset = DependedAssets[i];
			if(T* Asset = Cast<T>(DependedAsset))
			{
				if(!DependedAssetArray.Contains(Asset))
				{
					DependedAssetArray.Add(Asset);
				}
			}
			else
			{
				GetDependedTypeAssets<T>(GetDependedAssets(DependedAsset), DependedAssetArray, IterationCount);
			}
		}
		IterationCount--;
	};

	template<typename T>
	TArray<T*> GetStackEntries(UNiagaraStackViewModel* StackViewModel, bool bRefresh = false)
	{
		TArray<T*> Results;
		TArray<UNiagaraStackEntry*> EntriesToCheck;
		if (UNiagaraStackEntry* RootEntry = StackViewModel->GetRootEntry())
		{
			if (bRefresh)
			{
				RootEntry->RefreshChildren();
			}
			RootEntry->GetUnfilteredChildren(EntriesToCheck);
		}
		while (EntriesToCheck.Num() > 0)
		{
			UNiagaraStackEntry* Entry = EntriesToCheck.Pop();
			if (T* ItemToCheck = Cast<T>(Entry))
			{
				if (ItemToCheck->GetIsEnabled())
				{
					Results.Add(ItemToCheck);
				}
			}
			Entry->GetUnfilteredChildren(EntriesToCheck);
		}
		return Results;
	}

	FString MeshScaleCheckFunc(FStructOnScope* InBuffer)
	{
		FString Result = "";
		checkf(InBuffer->GetStruct() == FNiagaraTypeDefinition::GetVec3Struct() || InBuffer->GetStruct() == FNiagaraTypeDefinition::GetPositionStruct(), TEXT("Struct type not supported."));
		const FVector3f VectorValue = *reinterpret_cast<FVector3f*>(InBuffer->GetStructMemory());
		if(VectorValue.X == 0 || VectorValue.Y == 0 || VectorValue.Z == 0)
		{
			Result = FString::Printf(TEXT(" 的值不能含 0"));
		}
		return Result;
	}
}


UClass* UNiagaraRule::GetAssetType()
{
	return UNiagaraSystem::StaticClass();
}

bool UNiagaraRule::PreExecuteAsset(const FAssetData& AssetData)
{
	FString NiagaraIniPath = FConfigCacheIni::NormalizeConfigIniPath(FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("KGResourceManager/Config/NiagaraRule.ini")));
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (PlatformFile.FileExists(*NiagaraIniPath))
	{
		GConfig->Flush(true, *NiagaraIniPath);
		GConfig->GetArray(TEXT("NoCulling"), TEXT("WhiteList"), NoCullingWhiteList, NiagaraIniPath);
	}
	
	if (UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset()))
	{
		auto EmitterHandles = NiagaraSystem->GetEmitterHandles();
		FNiagaraEditorModule& NiagaraEditorModule = FModuleManager::Get().LoadModuleChecked<FNiagaraEditorModule>("NiagaraEditor");
		SystemViewModel = NiagaraEditorModule.GetSystemExistingViewModel(NiagaraSystem);

		const UNiagaraSettings* Settings = GetDefault<UNiagaraSettings>();
		if (Settings)
		{
			NumQualityLevels = Settings->QualityLevels.Num();
			QualityLevelsNumActive.AddZeroed(NumQualityLevels);
			QualityLevelsEmitters.AddZeroed(NumQualityLevels);
			QualityLevelsEmitterHandles.AddZeroed(NumQualityLevels);
			
			// 先把每个发射器的数据单独计算出来并保存在map中
			for (FNiagaraEmitterHandle& Handle : EmitterHandles)
			{
				if (Handle.GetIsEnabled())
				{
					FVersionedNiagaraEmitter Emitter = Handle.GetInstance();
					FVersionedNiagaraEmitterData* EmitterData = Emitter.GetEmitterData();

					auto EmitterHandleViewModel = SystemViewModel->GetEmitterHandleViewModelById(Handle.GetId());
					auto EmitterStackViewModel = EmitterHandleViewModel->GetEmitterStackViewModel();
					TArray<UNiagaraStackEntry*> FilteredChildren;
					EmitterStackViewModel->GetRootEntry()->GetFilteredChildren(FilteredChildren);
					auto NiagaraStackModuleItems = NiagaraRuleHelper::GetStackEntries<UNiagaraStackModuleItem>(EmitterStackViewModel);
					StackModuleItems.Add(Handle.GetId(), NiagaraStackModuleItems);
					CollisionModuleItems.Add(Handle.GetId(), TArray<UNiagaraStackModuleItem*>());
					for(auto ModuleItem : NiagaraStackModuleItems)
					{
						UNiagaraNodeFunctionCall& ModuleNode = ModuleItem->GetModuleNode();
						if(ModuleNode.FunctionScript && ModuleNode.FunctionScript->GetName()  == TEXT("Collision"))
						{
							CollisionModuleItems[Handle.GetId()].Add(ModuleItem);
						}
					}
						
					auto NiagaraStackRendererItems = NiagaraRuleHelper::GetStackEntries<UNiagaraStackRendererItem>(EmitterStackViewModel);

					DependedTextureArray.Add(Handle.GetId(), TArray<UTexture*>());
					NumTotalTriangles.Add(Handle.GetId(), 0);
					for(UNiagaraStackRendererItem* RendererItem : NiagaraStackRendererItems)
					{
						auto RendererProperties = RendererItem->GetRendererProperties();
						if(auto MeshRendererProperties = Cast<UNiagaraMeshRendererProperties>(RendererProperties))
						{
							MeshRendererProperties->Meshes;
							for(auto NiagaraMeshRendererMeshProperties: MeshRendererProperties->Meshes)
							{
								if(!NiagaraMeshRendererMeshProperties.Mesh->IsValidLowLevel())
								{
									continue;
								}
								TArray<UObject*> DependedAssets = NiagaraRuleHelper::GetDependedAssets(NiagaraMeshRendererMeshProperties.Mesh);
								int32 IterationCount=0;
								NiagaraRuleHelper::GetDependedTypeAssets<UTexture>(DependedAssets, DependedTextureArray[Handle.GetId()], IterationCount);
								FStaticMeshRenderData* LODData = NiagaraMeshRendererMeshProperties.Mesh->GetRenderData();

								// Triangles
								int32 NumSections = LODData->LODResources.Num();
								for (int32 SectionIndex = 0; SectionIndex < NumSections; SectionIndex++)
								{
									NumTotalTriangles[Handle.GetId()] += LODData->LODResources[SectionIndex].GetNumTriangles();
								}
							}
						}
						else if(auto SpriteRendererProperties = Cast<UNiagaraSpriteRendererProperties>(RendererProperties))
						{
							if (!SpriteRendererProperties->Material->IsValidLowLevel())
							{
								continue;
							}
							TArray<UObject*> DependedAssets = NiagaraRuleHelper::GetDependedAssets(SpriteRendererProperties->Material);
							int32 IterationCount=0;
							NiagaraRuleHelper::GetDependedTypeAssets<UTexture>(DependedAssets, DependedTextureArray[Handle.GetId()], IterationCount);
						}
					}
					
					if (EmitterData)
					{
						for (int32 i = 0; i < NumQualityLevels; i++)
						{
							if (EmitterData->Platforms.IsEffectQualityEnabled(i))
							{
								QualityLevelsNumActive[i]++;
								QualityLevelsEmitters[i].Add(EmitterData);
								QualityLevelsEmitterHandles[i].Add(&Handle);
							}
						}
					}
				}
			}

			return true;
		}
	}

	return false;
}

bool UNiagaraRule::PostExecuteAsset(const FAssetData& AssetData)
{
	SystemViewModel = nullptr;
	QualityLevelsNumActive.Empty();
	QualityLevelsEmitters.Empty();
	QualityLevelsEmitterHandles.Empty();
	DependedTextureArray.Empty();
	DependedSkeletalMeshArray.Empty();
	CollisionModuleItems.Empty();
	NumTotalTriangles.Empty();
	StackModuleItems.Empty();
	return true;
}

bool UNiagaraRule::NiagaraMeshScaleCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset()))
	{
		TMap<FString, FNiagaraCallableRule> CustomizedCheckRules;
		FNiagaraCallableRule MeshScaleCheckFuncRule;
		MeshScaleCheckFuncRule.Func = &NiagaraRuleHelper::MeshScaleCheckFunc;
		CustomizedCheckRules.Add("Mesh Scale", MeshScaleCheckFuncRule);
		CustomizedCheckRules.Add("Mesh Scale Max", MeshScaleCheckFuncRule);
		CustomizedCheckRules.Add("Mesh Scale Min", MeshScaleCheckFuncRule);
		
		for(const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
		{
			if(StackModuleItems.Contains(Handle.GetId()))
			{
				auto NiagaraStackModuleItems = StackModuleItems[Handle.GetId()];
				for(auto NiagaraStackModuleItem : NiagaraStackModuleItems)
				{
					TArray<FString> CheckResults = CheckCustomizedModuleAttribute(NiagaraStackModuleItem, CustomizedCheckRules);
					for (const FString& CheckResult : CheckResults)
					{
						const FString LogInfo = TEXT("发射器 ") + Handle.GetName().ToString() + ": " + CheckResult;
						Log.RegistryAndLog(AssetData, TEXT("NiagaraMeshScale"), CheckRuleType, LogInfo);
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UNiagaraRule::NiagaraGPUEmitterCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	int32 GPUMinEmitterLevel = FCString::Atoi(*Params.GetValue(TEXT("GPUMinEmitterLevel")));
	if (UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset()))
	{
		for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
		{
			if (Handle.GetIsEnabled())
			{
				const FVersionedNiagaraEmitter& Emitter = Handle.GetInstance();
				if (FVersionedNiagaraEmitterData* EmitterData = Emitter.GetEmitterData())
				{
					if (EmitterData->SimTarget == ENiagaraSimTarget::GPUComputeSim)
					{
						for (int32 i = 0; i < GPUMinEmitterLevel; i++)
						{
							if (EmitterData->Platforms.IsEffectQualityEnabled(i))
							{
								Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("高以下的Emitter不允许存在GPU粒子发射器"));
								return false;
							}
						}
					}
				}
			}
		}
	}
	
	return bSuccess;
}

bool UNiagaraRule::NiagaraEmitterScalabilityCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset()))
	{
		for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
		{
			if (Handle.GetIsEnabled())
			{
				const FVersionedNiagaraEmitter& Emitter = Handle.GetInstance();
				if (FVersionedNiagaraEmitterData* EmitterData = Emitter.GetEmitterData())
				{
					const TArray<UNiagaraRendererProperties*>& Renderers = EmitterData->GetRenderers();
					const TArray<UNiagaraRendererProperties*>& EnabledRenderers = Renderers.FilterByPredicate([](const UNiagaraRendererProperties* Renderer){return Renderer->bIsEnabled;});
					if (EnabledRenderers.IsEmpty())
					{
						continue;
					}
					for (int32 i = 0; i < NumQualityLevels; i++)
					{
						bool HasActiveRenderer = false;
						for (UNiagaraRendererProperties* Renderer : EnabledRenderers)
						{
							if (Renderer->Platforms.IsEffectQualityEnabled(i))
							{
								HasActiveRenderer = true;
								break;
							}
						}
						if (!HasActiveRenderer)
						{
							if (EmitterData->Platforms.IsEffectQualityEnabled(i))
							{
								Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("发射器:{}在{}延展级别下没有渲染器,需要将{}级别的发射器延展性关闭"), Emitter.Emitter->GetUniqueEmitterName(), i, i);
								bSuccess = false;
							}
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UNiagaraRule::EmitterScalabilityEpicCinematicSelectedCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset()))
	{
		for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
		{
			if (Handle.GetIsEnabled())
			{
				const FVersionedNiagaraEmitter& Emitter = Handle.GetInstance();
				if (const FVersionedNiagaraEmitterData* EmitterData = Emitter.GetEmitterData())
				{
					const bool bEpicEnabled = EmitterData->Platforms.IsEffectQualityEnabled(NumQualityLevels - 2);
					const bool bCinematicEnabled = EmitterData->Platforms.IsEffectQualityEnabled(NumQualityLevels - 1);
					if (bEpicEnabled != bCinematicEnabled)
					{
						Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("发射器:{} 分级[极高]和[过场动画]，要么同时选中，要么同时不选中"), Emitter.Emitter->GetUniqueEmitterName());
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UNiagaraRule::CheckEmitterMeshNanite(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
	for (const FNiagaraEmitterHandle& EmitterHandle : NiagaraSystem->GetEmitterHandles())
	{
		if (UNiagaraEmitter* Emitter = EmitterHandle.GetInstance().Emitter)
		{
			if (const FVersionedNiagaraEmitterData* EmitterData = Emitter->GetLatestEmitterData())
			{
				for (UNiagaraRendererProperties* Renderer : EmitterData->GetRenderers())
				{
					if (const UNiagaraMeshRendererProperties* MeshRenderer = Cast<UNiagaraMeshRendererProperties>(Renderer))
					{
						for (const auto& MeshProperties : MeshRenderer->Meshes)
						{
							if (MeshProperties.Mesh && MeshProperties.Mesh->IsNaniteEnabled())
							{
								Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("发射器:{} 的网格体{}启用了Nanite，可以考虑关闭Nanite，请知悉"), Emitter->GetUniqueEmitterName(), MeshProperties.Mesh.GetName());
								bSuccess = false;
							}
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UNiagaraRule::NiagaraEmitterAllocationModeCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
	if (!NiagaraSystem)
	{
		return true;
	}
	for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
	{
		if (!Handle.GetIsEnabled())
		{
			continue;
		}
		const FVersionedNiagaraEmitter& Emitter = Handle.GetInstance();
		if (const FVersionedNiagaraEmitterData* EmitterData = Emitter.GetEmitterData())
		{
			if (EmitterData->AllocationMode == EParticleAllocationMode::FixedCount)
			{
				continue;
			}
			bool bLoopParticleLifetime = false;
			bool bKillParticleWhenLifetimeHasElapsed = false;
			bool bLetInfinitelyLivedParticlesDieWhenEmitterDeactivates = false;
			const UNiagaraScriptSource* SourceScript = Cast<UNiagaraScriptSource>(EmitterData->GraphSource);
			if (SourceScript == nullptr || SourceScript->NodeGraph == nullptr)
			{
				continue;
			}
			for (UEdGraphNode* Node : SourceScript->NodeGraph->Nodes)
			{
				if (!Node)
				{
					continue;
				}
				for (const UEdGraphPin* Pin : Node->Pins)
				{
					if (!Pin)
					{
						continue;
					}
					if (Pin->PinName == TEXT("ParticleState.Loop Particles Lifetime") && Pin->DefaultValue == TEXT("true"))
					{
						bLoopParticleLifetime = true;
					}
					else if (Pin->PinName == TEXT("Kill Particles When Lifetime Has Elapsed") && Pin->DefaultValue == TEXT("true"))
					{
						bKillParticleWhenLifetimeHasElapsed = true;
					}
					else if (Pin->PinName == TEXT("ParticleState.Let Infinitely Lived Particles Die When Emitter Deactivates") && Pin->DefaultValue == TEXT("true"))
					{
						bLetInfinitelyLivedParticlesDieWhenEmitterDeactivates = true;
					}
				}
			}
			if (bLoopParticleLifetime)
			{
				Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("发射器:{}在设置了Particle State为Loop Particle Lifetime的时候,需要将Emitter属性中的分配模式设置为:固定数量"), Emitter.Emitter->GetUniqueEmitterName());
				bSuccess = false;
			}
			else if (!bKillParticleWhenLifetimeHasElapsed && !bLetInfinitelyLivedParticlesDieWhenEmitterDeactivates)
			{
				Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("发射器:{}在Particle State三个都没勾选的时候,需要将Emitter属性中的分配模式设置为:固定数量"), Emitter.Emitter->GetUniqueEmitterName());
				bSuccess = false;
			}
		}
	}
	return bSuccess;
}

bool UNiagaraRule::CheckLightRenderer(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
	if (!NiagaraSystem)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find NiagaraSystem From AssetData: %s"), *AssetData.PackageName.ToString())
		return bSuccess;
	}
	int32 LightRendererCount = 0;
	for (const FNiagaraEmitterHandle& EmitterHandle : NiagaraSystem->GetEmitterHandles())
	{
		if (!EmitterHandle.GetIsEnabled())
		{
			continue;
		}
		if (UNiagaraEmitter* Emitter = EmitterHandle.GetInstance().Emitter)
		{
			if (const FVersionedNiagaraEmitterData* EmitterData = Emitter->GetLatestEmitterData())
			{
				for (UNiagaraRendererProperties* Renderer : EmitterData->GetRenderers())
				{
					if (Renderer && Renderer->GetIsEnabled())
					{
						if (Cast<UNiagaraLightRendererProperties>(Renderer))
						{
							++LightRendererCount;
							for (int32 i = 0; i < 3; ++i)
							{
								if (EmitterData->Platforms.IsEffectQualityEnabled(i))
								{
									Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("只有极高及以上的Emitter，才允许使用LightRenderer,当前Emitter名:{}"), Emitter->GetUniqueEmitterName());
									bSuccess = false;
									break;
								}
							}
						}
					}
				}
			}
		}
	}
	if (LightRendererCount > 1)
	{
		Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("一个NS内，最多只能有一个LightRenderer"));
		bSuccess = false;
	}
	return bSuccess;
}

bool UNiagaraRule::CheckFixedBound(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
	if (!NiagaraSystem)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find NiagaraSystem From AssetData: %s"), *AssetData.PackageName.ToString())
		return bSuccess;
	}
	UNiagaraEffectType* EffectType = NiagaraSystem->GetEffectType();
	if (!EffectType)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find EffectType From NiagaraSystem: %s"), *AssetData.PackageName.ToString())
		return bSuccess;
	}
	const FString EffectTypeName = EffectType->GetName();
	const TArray<FString>& CheckEffectTypeNames = Params.GetValueList("CheckEffectTypeNames");
	if (!CheckEffectTypeNames.Contains(EffectTypeName))
	{
		return bSuccess;
	}
	const FString MaxBoundSizeStr = Params.GetValue("MaxBoundSize");
	if (MaxBoundSizeStr == "None")
	{
		return bSuccess;
	}
	const double MaxBoundSize = FCString::Atod(*MaxBoundSizeStr);
	for (const FNiagaraEmitterHandle& EmitterHandle : NiagaraSystem->GetEmitterHandles())
	{
		if (UNiagaraEmitter* Emitter = EmitterHandle.GetInstance().Emitter)
		{
			if (const FVersionedNiagaraEmitterData* EmitterData = Emitter->GetLatestEmitterData())
			{
				if (EmitterData->CalculateBoundsMode == ENiagaraEmitterCalculateBoundMode::Fixed)
				{
					const UE::Math::TVector<double>& BoundSize = EmitterData->FixedBounds.GetSize();
					if (BoundSize.X > MaxBoundSize || BoundSize.Y > MaxBoundSize || BoundSize.Z > MaxBoundSize)
					{
						Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("发射器{}的边界超过了规定的最大值:{}，请确认是否正确设置"), Emitter->GetUniqueEmitterName(), MaxBoundSize);
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UNiagaraRule::CheckRendererCameraDistanceCulling(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
	if (!NiagaraSystem)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find NiagaraSystem From AssetData: %s"), *AssetData.PackageName.ToString())
		return bSuccess;
	}
	for (const FNiagaraEmitterHandle& EmitterHandle : NiagaraSystem->GetEmitterHandles())
	{
		if (UNiagaraEmitter* Emitter = EmitterHandle.GetInstance().Emitter)
		{
			if (const FVersionedNiagaraEmitterData* EmitterData = Emitter->GetLatestEmitterData())
			{
				for (UNiagaraRendererProperties* Renderer : EmitterData->GetRenderers())
				{
					if (Renderer && Renderer->GetIsEnabled())
					{
						if (UNiagaraMeshRendererProperties* MeshRendererProperties = Cast<UNiagaraMeshRendererProperties>(Renderer))
						{
							if (MeshRendererProperties->bEnableCameraDistanceCulling)
							{
								Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("特效Emitter的Renderer不能勾选启用摄像机距离剔除,当前Emitter名:{}"), Emitter->GetUniqueEmitterName());
								bSuccess = false;
							}
						}
						if (UNiagaraSpriteRendererProperties* SpriteRendererProperties = Cast<UNiagaraSpriteRendererProperties>(Renderer))
						{
							if (SpriteRendererProperties->bEnableCameraDistanceCulling)
							{
								Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("特效Emitter的Renderer不能勾选启用摄像机距离剔除,当前Emitter名:{}"), Emitter->GetUniqueEmitterName());
								bSuccess = false;
							}
						}
					}
				}
			}
		}
	}
	if (!bSuccess)
	{
		OutRepairParams.Add(TEXT("RendererCameraDistanceCulling"), TEXT("1"));
	}
	return bSuccess;
}

bool UNiagaraRule::RepairRendererCameraDistanceCulling(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	bool bSuccess = false;
	if (!InRepairParams.Contains(TEXT("RendererCameraDistanceCulling")))
	{
		return bSuccess;
	}
	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
	if (!NiagaraSystem)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find NiagaraSystem From AssetData: %s"), *AssetData.PackageName.ToString())
		return bSuccess;
	}
	for (const FNiagaraEmitterHandle& EmitterHandle : NiagaraSystem->GetEmitterHandles())
	{
		if (UNiagaraEmitter* Emitter = EmitterHandle.GetInstance().Emitter)
		{
			if (const FVersionedNiagaraEmitterData* EmitterData = Emitter->GetLatestEmitterData())
			{
				for (UNiagaraRendererProperties* Renderer : EmitterData->GetRenderers())
				{
					if (Renderer && Renderer->GetIsEnabled())
					{
						if (UNiagaraMeshRendererProperties* MeshRendererProperties = Cast<UNiagaraMeshRendererProperties>(Renderer))
						{
							if (MeshRendererProperties->bEnableCameraDistanceCulling)
							{
								MeshRendererProperties->bEnableCameraDistanceCulling = false;
								bSuccess = true;
							}
						}
						if (UNiagaraSpriteRendererProperties* SpriteRendererProperties = Cast<UNiagaraSpriteRendererProperties>(Renderer))
						{
							if (SpriteRendererProperties->bEnableCameraDistanceCulling)
							{
								SpriteRendererProperties->bEnableCameraDistanceCulling = false;
								bSuccess = true;
							}
						}
					}
				}
			}
		}
	}
	if (bSuccess)
	{
		NiagaraSystem->Modify();
		NiagaraSystem->GetPackage()->MarkPackageDirty();
	}
	return bSuccess;
}

FString UNiagaraRule::IsInNoCullingWhiteList(const FAssetData& AssetData)
{
	const FString& PackageName = AssetData.PackageName.ToString();
	return NoCullingWhiteList.Contains(PackageName) ? TEXT("1") : TEXT("0");
}

bool UNiagaraRule::CheckEmitterSpawnCount(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset()))
	{
		for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
		{
			const FVersionedNiagaraEmitter& Emitter = Handle.GetInstance();
			if (FVersionedNiagaraEmitterData* EmitterData = Emitter.GetEmitterData())
			{
				if (EmitterData->AllocationMode == EParticleAllocationMode::FixedCount) continue;

				if (!FNSAssetCheckerUtils::Niagara_IsEmitterLooping(NiagaraSystem, Emitter)) continue;
			}

			// 发射无限生命粒子 且 不为固定数量 的发射器
			if (StackModuleItems.Contains(Handle.GetId()))
			{
				auto NiagaraStackModuleItems = StackModuleItems[Handle.GetId()];
				int32 SpawnCount = 0;
				bool bOnlySpawnBurstInstantaneous = true;
				for (auto NiagaraStackModuleItem : NiagaraStackModuleItems)
				{
					bool bEnabled = NiagaraStackModuleItem->GetIsEnabled();
					if (!bEnabled) continue;
					
					if (UNiagaraNodeOutput* OutputNode = NiagaraStackModuleItem->GetOutputNode())
					{
						if (OutputNode->GetUsage() == ENiagaraScriptUsage::EmitterUpdateScript)
						{
							UNiagaraNodeFunctionCall& ModuleNode = NiagaraStackModuleItem->GetModuleNode();
							if (ModuleNode.FunctionScript)
							{
								FString FunctionName = ModuleNode.FunctionScript->GetName();
								if (FunctionName.Contains(TEXT("Spawn")))
								{
									if (FunctionName != TEXT("SpawnBurst_Instantaneous"))
									{
										// 发射器更新阶段，Spawn相关的，不只有Spawn Burst Instantaneous模块
										bOnlySpawnBurstInstantaneous = false;
										Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("请将发射器 {} 设置为【固定数量】，并填写预分配数"), Handle.GetName().ToString());
										bSuccess = false;
										break;
									}
									else
									{
										// 发射器更新阶段，Spawn相关的，只有Spawn Burst Instantaneous模块，则可以自动修复
										TArray<UNiagaraStackFunctionInput*> OutResult;
										NiagaraStackModuleItem->GetParameterInputs(OutResult);
										for (auto Parameter:OutResult)
										{
											auto ParameterHandleName = Parameter->GetInputParameterHandle().GetName().ToString();
											if (ParameterHandleName == TEXT("Spawn Count"))
											{
												switch (Parameter->GetValueMode())
												{
												case UNiagaraStackFunctionInput::EValueMode::Local:
													{
														TSharedRef<FStructOnScope> ValueStruct = MakeShared<FStructOnScope>(Parameter->GetInputType().GetStruct());
														FNiagaraEditorUtilities::CopyDataTo(*ValueStruct, *Parameter->GetLocalValueStruct().Get());
														const int32 IntValue = *reinterpret_cast<int32*>(ValueStruct->GetStructMemory());
														SpawnCount += IntValue;
													}
												default:
													{
													};
												}
											}
										}
									}
								}
							}
						}
					}
				}
				if (bOnlySpawnBurstInstantaneous)
				{
					Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("请将发射器 {} 设置为【固定数量】，并填写预分配数"), Handle.GetName().ToString());
					OutRepairParams.FindOrAdd(Handle.GetName().ToString()) = FString::FromInt(SpawnCount);
					bSuccess = false;
					continue;
				}
			}
		}
	}
	return bSuccess;
}

bool UNiagaraRule::RepairEmitterSpawnCount(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	bool bDirty = false;
	if (UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset()))
	{
		for(const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
		{
			if (Arguments.Contains(Handle.GetName().ToString()))
			{
				const FVersionedNiagaraEmitter& Emitter = Handle.GetInstance();
				if (FVersionedNiagaraEmitterData* EmitterData = Emitter.GetEmitterData())
				{
					EmitterData->AllocationMode = EParticleAllocationMode::FixedCount;
					EmitterData->PreAllocationCount = FCString::Atoi(*Arguments[Handle.GetName().ToString()]);
					bDirty = NiagaraSystem->GetPackage()->MarkPackageDirty();
				}
			}
		}
	}
	
	return bDirty;
}

bool UNiagaraRule::CheckCollisionModule(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	TArray<FString> InvalidEmitterNames;
	if (UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset()))
	{
		for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
		{
			if (CollisionModuleItems.Contains(Handle.GetId()))
			{
				const FString& HandleName = Handle.GetName().ToString();
				const ENiagaraSimTarget& SimTarget = Handle.GetEmitterData()->SimTarget;
				FString CollisionTypeName = TEXT("CPU Collision Type");
				if (SimTarget == ENiagaraSimTarget::GPUComputeSim)
				{
					CollisionTypeName = TEXT("GPU Collision Type");
				}
				for (const UNiagaraStackModuleItem* Item : CollisionModuleItems[Handle.GetId()])
				{
					if (Item && Item->GetIsEnabled())
					{
						UNiagaraNodeFunctionCall& ModuleNode = Item->GetModuleNode();
						const UEdGraphPin* CollisionTypePin = nullptr;
						for (const UEdGraphPin* Pin : ModuleNode.GetAllPins())
						{
							if (Pin == nullptr)
							{
								continue;
							}
							if (Pin->GetName() == CollisionTypeName)
							{
								CollisionTypePin = Pin;
								break;
							}
						}
						bool bValidCollision = false;
						if (CollisionTypePin != nullptr)
						{
							if (const UEnum* CollisionTypeEnum = Cast<UEnum>(CollisionTypePin->PinType.PinSubCategoryObject))
							{
								const int32 Index = CollisionTypeEnum->GetIndexByName(FName(CollisionTypePin->DefaultValue));
								if (CollisionTypeEnum->GetDisplayNameTextByIndex(Index).ToString() == TEXT("Analytical Planes"))
								{
									bValidCollision = true;
								}
							}
						}
						if (!bValidCollision)
						{
							Log.RegistryAndLog(AssetData, TEXT("NiagaraSystem"), CheckRuleType, TEXT("特效的Emitter:{}内有激活的Collision模块:{},请移除或禁用"), Handle.GetName().ToString(), ModuleNode.GetFunctionName());
							InvalidEmitterNames.AddUnique(FString::Printf(TEXT("%s,%s"), *HandleName, *ModuleNode.GetFunctionName()));
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	if (!bSuccess)
	{
		OutRepairParams.Add(TEXT("CollisionModule"), FString::Join(InvalidEmitterNames, TEXT(";")));
	}
	return bSuccess;
}

TArray<UNiagaraStackModuleItem*> UNiagaraRule::GetAllCollisionModules(const TSharedPtr<FNiagaraSystemViewModel>& SystemViewModel, const FNiagaraEmitterHandle& Handle)
{
	TArray<UNiagaraStackModuleItem*> CollisionItems;
	if (Handle.GetIsEnabled())
	{
		const TSharedPtr<FNiagaraEmitterHandleViewModel> EmitterHandleViewModel = SystemViewModel->GetEmitterHandleViewModelById(Handle.GetId());
		UNiagaraStackViewModel* EmitterStackViewModel = EmitterHandleViewModel->GetEmitterStackViewModel();
		TArray<UNiagaraStackModuleItem*> NiagaraStackModuleItems = NiagaraRuleHelper::GetStackEntries<UNiagaraStackModuleItem>(EmitterStackViewModel);
		for (UNiagaraStackModuleItem* ModuleItem : NiagaraStackModuleItems)
		{
			const UNiagaraNodeFunctionCall& ModuleNode = ModuleItem->GetModuleNode();
			if (ModuleNode.FunctionScript && ModuleNode.FunctionScript->GetName()  == TEXT("Collision"))
			{
				CollisionItems.Add(ModuleItem);
			}
		}
	}
	return CollisionItems;
}

bool UNiagaraRule::RepairCollisionModule(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams)
{
	bool bSuccess = false;
	if (!InRepairParams.Contains(TEXT("CollisionModule")))
	{
		return bSuccess;
	}
	UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(AssetData.GetAsset());
	if (!NiagaraSystem)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find NiagaraSystem From AssetData: %s"), *AssetData.PackageName.ToString())
		return bSuccess;
	}
	FNiagaraEditorModule& NiagaraEditorModule = FModuleManager::Get().LoadModuleChecked<FNiagaraEditorModule>("NiagaraEditor");
	SystemViewModel = NiagaraEditorModule.GetSystemExistingViewModel(NiagaraSystem);
	TArray<FString> InvalidEmitterItemNames;
	InRepairParams[TEXT("CollisionModule")].ParseIntoArray(InvalidEmitterItemNames, TEXT(";"), true);
	for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
	{
		TArray<UNiagaraStackModuleItem*> CollisionItems = GetAllCollisionModules(SystemViewModel, Handle);
		const FString& HandleName = Handle.GetName().ToString();
		for (UNiagaraStackModuleItem* Item : CollisionItems)
		{
			if (Item && Item->GetIsEnabled())
			{
				UNiagaraNodeFunctionCall& ModuleNode = Item->GetModuleNode();
				if (InvalidEmitterItemNames.Contains(FString::Printf(TEXT("%s,%s"), *HandleName, *ModuleNode.GetFunctionName())))
				{
					Item->SetEnabled(false);
					bSuccess = true;
				}
			}
		}
	}
	if (bSuccess)
	{
		NiagaraSystem->Modify();
		NiagaraSystem->GetPackage()->MarkPackageDirty();
	}
	return bSuccess;
}

TArray<FString> UNiagaraRule::CheckCustomizedModuleAttribute(UObject* InNiagaraStackModuleItem, TMap<FString, FNiagaraCallableRule> CustomizedCheckRules)
{
	TArray<FString> CheckResults;
	auto NiagaraStackModuleItem = Cast<UNiagaraStackModuleItem>(InNiagaraStackModuleItem);
	TArray<UNiagaraStackFunctionInput*> OutResult;
	NiagaraStackModuleItem->GetParameterInputs(OutResult);
	for(auto Parameter:OutResult)
	{
		auto ParameterHandleName = Parameter->GetInputParameterHandle().GetName().ToString();
		if (CustomizedCheckRules.Contains(ParameterHandleName))
		{
			switch (Parameter->GetValueMode())
			{
			case UNiagaraStackFunctionInput::EValueMode::Local:
				{
					TSharedRef<FStructOnScope> ValueStruct = MakeShared<FStructOnScope>(Parameter->GetInputType().GetStruct());
					FNiagaraEditorUtilities::CopyDataTo(*ValueStruct, *Parameter->GetLocalValueStruct().Get());
					FString CurParameterCheckResult = CustomizedCheckRules[ParameterHandleName].Func(&ValueStruct.Get());
					if (!CurParameterCheckResult.IsEmpty())
					{
						CheckResults.Add(ParameterHandleName + CurParameterCheckResult);
					}
				}
			default:
				{
				};
			}
		}
	}
	return CheckResults;
}
