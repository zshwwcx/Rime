
#include "ResourceCheck/RuleFunctions/Blueprint/WBPAssetRule.h"
#include "MovieScene.h"
#include "WidgetBlueprint.h"
#include "PaperSpriteAtlas.h"
#include "PaperSprite.h"
#include "Engine/AssetManager.h"

#include "Kismet/KismetSystemLibrary.h"
#include "Blueprint/WidgetTree.h"
#include "Components/RichTextBlock.h"

#include "Animation/WidgetAnimation.h"
#include "Animation/MovieScene2DTransformSection.h"
#include "Animation/MovieScene2DTransformTrack.h"
#include "Sections/MovieSceneFloatSection.h"
#include "Tracks/MovieSceneFloatTrack.h"

// CheckLuaModify
#include "BinkMediaPlayer.h"
#include "DiffUtils.h"
#include "ISourceControlModule.h"
#include "ISourceControlOperation.h"
#include "MovieSceneFolder.h"
#include "SourceControlOperations.h"

#include "SourceControlHelpers.h"
#include "C7/C7UMGExtensions/C7UMGExtensions.h"
#include "Engine/FontFace.h"
#include "Engine/UserInterfaceSettings.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "UMG/Skeletal/KGUserWidgetSkeletalWidget.h"

#define LOCTEXT_NAMESPACE "UWBPAssetRule"

UClass* UWBPAssetRule::GetAssetType()
{
	return UWidgetBlueprint::StaticClass();
	
}

bool UWBPAssetRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	DependResourceAssetes = Params.GetValueList(TEXT("DependResourceAssetes"));
	DependPaperSpriteAssetes = Params.GetValueList(TEXT("DependPaperSpriteAssetes"));
	ExceptDependAssetPaths = Params.GetValueList(TEXT("ExceptDependAssetPaths"));
	MaxMainBPDependedAtlasNum = FCString::Atoi(*Params.GetValue(TEXT("MaxMainBPDependedAtlasNum")));
	MaxSubBPDependedAtlasNum = FCString::Atoi(*Params.GetValue(TEXT("MaxSubBPDependedAtlasNum")));
	MaxMainBPDependedTextureNum = FCString::Atoi(*Params.GetValue(TEXT("MaxMainBPDependedTextureNum")));
	MaxSubBPDependedTextureNum = FCString::Atoi(*Params.GetValue(TEXT("MaxSubBPDependedTextureNum")));
	MaxGUITextureSize = FCString::Atoi(*Params.GetValue(TEXT("MaxGUITextureSize")));
	MaxDependedBinkMediaPlayerNum = FCString::Atoi(*Params.GetValue(TEXT("MaxDependedBinkMediaPlayerNum")));
	TMap<FString, FString> ExternDependDirectorys;
	ExternDependDirectorys = Params.GetValueMap("ExternDependDirectory");
	for(auto ExternDependDirectoryParam : ExternDependDirectorys)
	{
		FString DataKey = ExternDependDirectoryParam.Key;
		TArray<FString> Values;
		ExternDependDirectoryParam.Value.ParseIntoArray(Values, TEXT(","));
		for(auto Value : Values)
		{
			ExternDependDirectory.FindOrAdd(DataKey).Add(Value);
		}
	}
	
	return true;
}

bool UWBPAssetRule::PreExecuteAsset(const FAssetData& InAssetData)
{
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FName> AssetDependencies;
	AssetRegistryModule.Get().GetDependencies(FName(*InAssetData.PackageName.ToString()), AssetDependencies, UE::AssetRegistry::EDependencyCategory::All);
	for (int32 Index = 0; Index < AssetDependencies.Num(); ++Index)
	{
		TArray<FAssetData> OutAssetData;
		AssetRegistryModule.Get().GetAssetsByPackageName(AssetDependencies[Index], OutAssetData);
		if (!OutAssetData.IsEmpty())
		{
			UObject* AssetInPackage = OutAssetData[0].GetAsset();
			if(UPaperSprite* Sprite = Cast<UPaperSprite>(AssetInPackage))
			{
				TWeakObjectPtr<const UPaperSpriteAtlas> PaperSpriteAtlas = Sprite->GetAtlasGroup();
				if(DependPaperSpriteAtlas.Find(PaperSpriteAtlas) == INDEX_NONE)
				{
					DependPaperSpriteAtlas.Add(PaperSpriteAtlas);
				}
			}
			else if(UTexture* Texture = Cast<UTexture>(AssetInPackage))
			{
				DependTexture.Add(Texture);
			}
		}
	}

	bIsSubWidget = false;
	TArray<FName> AssetReferencers;
	AssetRegistryModule.Get().GetReferencers(FName(*InAssetData.PackageName.ToString()), AssetReferencers, UE::AssetRegistry::EDependencyCategory::All);
	for (auto AssetRefencer : AssetReferencers)
	{
		TArray<FAssetData> OutAssetData;
		AssetRegistryModule.Get().GetAssetsByPackageName(AssetRefencer, OutAssetData);
		if (!OutAssetData.IsEmpty())
		{
			UObject* AssetInPackage = OutAssetData[0].GetAsset();
			if(Cast<UWidgetBlueprint>(AssetInPackage))
			{
				bIsSubWidget = true;
				break;
			}
		}
	}
	return true;
}

bool UWBPAssetRule::PostExecuteAsset(const FAssetData& AssetData)
{
	// 检查完一个资产后应该及时清理，不要累加
	DependPaperSpriteAtlas.Empty();
	DependTexture.Empty();
	return true;
}

bool IsStringStartWithStringList(FString InString, TArray<FString>& InPrefixStringList)
{
	for(auto InPrefixString : InPrefixStringList)
	{
		if(InString.StartsWith(InPrefixString))
		{
			return true;
		}
	}
	return false;
}

FString UWBPAssetRule::GetWBPObjectNum(const FAssetData& AssetData)
{
	auto WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset());

	if (!WidgetBlueprint)
	{
		return FString::FromInt(0);
	}

	int32 Counter = FC7UMGExtensionsModule::GetUObjectNumFromWidgetTree(WidgetBlueprint);

	return FString::FromInt(Counter);
}

bool UWBPAssetRule::CheckKGUserWidget(const FAssetData& AssetData,const TMap<FString, FString>& OutRepairParams)
{
	if(UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset()))
	{
		if (!WidgetBlueprint->GeneratedClass->IsChildOf(UKGUserWidget::StaticClass()) && !WidgetBlueprint->GeneratedClass->IsChildOf(UKGUserWidgetSkeletalWidget::StaticClass()))
		{
			Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("蓝图父类不是KGUserWidget|KGUserWidgetSkeletalWidget"));
			return false;
		}
	}
	return true;
}

bool UWBPAssetRule::CheckDependencedTexture(const FAssetData& AssetData,const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset()))
	{
		int32 NumDependencPaperSpriteAtlas = DependPaperSpriteAtlas.Num();
		int32 NumDependencTexture = DependTexture.Num();
		
		int32 MaxDependencedAtlas = MaxMainBPDependedAtlasNum;
		int32 MaxDependencedTexture = MaxMainBPDependedTextureNum;
		if(bIsSubWidget)
		{
			MaxDependencedAtlas = MaxSubBPDependedAtlasNum;
			MaxDependencedTexture = MaxSubBPDependedTextureNum;
		}
		if(NumDependencPaperSpriteAtlas > MaxDependencedAtlas)
		{
			Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType,TEXT("引用图集数量超过了{}"), MaxDependencedAtlas);
			bSuccess = false;
		}
		if(NumDependencTexture > MaxDependencedTexture)
		{
			Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType,TEXT("引用散图数量超过了{}"), MaxDependencedTexture);
			bSuccess = false;
		}
	}
	return bSuccess;
}

bool UWBPAssetRule::CheckGUITextureSize(const FAssetData& AssetData,const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset()))
	{
		if(WidgetBlueprint->GetName().Contains(TEXT("VX")))
		{
			for(auto Texture : DependTexture)
			{
				int32 MaxInGameWidth = Texture->Source.GetSizeX();
				int32 MaxInGameHeight = Texture->Source.GetSizeY();
				if (Texture->MaxTextureSize > 0)
				{
					MaxInGameWidth = FMath::Min(MaxInGameWidth, Texture->MaxTextureSize);
					MaxInGameHeight = FMath::Min(MaxInGameHeight, Texture->MaxTextureSize);
				}

				const int32 LODBias = Texture->LODBias;

				MaxInGameWidth = MaxInGameWidth >> LODBias;
				MaxInGameHeight = MaxInGameHeight >> LODBias;

				if(FMath::Max(MaxInGameWidth, MaxInGameHeight) > MaxGUITextureSize)
				{
					Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType,TEXT("GUI动效蓝图引用的贴图MaxSize应该小于等于{}"), MaxGUITextureSize);
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool UWBPAssetRule::CheckIllegalDependedAsset(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset()))
	{
		const FName Name = WidgetBlueprint->GetPackage()->GetFName();
		TArray<FString> StringArray;
		Name.ToString().ParseIntoArray(StringArray, TEXT("/"));
		FString SourceFeature;
		// 找到对应的功能目录名称
		if(StringArray.Num() > 5)
		{
			SourceFeature = StringArray[4];
		}
		else
		{
			return true;
		}
	
		auto IsDependenceValid = [SourceFeature, AssetData, this](UObject* DependedAsset)
		{
			if(SourceFeature.IsEmpty() || Cast<UTexture>(DependedAsset))
			{
				return true;
			}
			
			if(Cast<UPaperSprite>(DependedAsset))
			{
				const FString DependedString = DependedAsset->GetPackage()->GetFName().ToString();

				if(IsStringStartWithStringList(DependedString, DependPaperSpriteAssetes))
				{
					return true;
				}

				for(auto ExceptDependAssetPath : ExceptDependAssetPaths)
				{
					if(DependedString.StartsWith(ExceptDependAssetPath))
					{
						return true;
					}
				}
				bool bIsSameFunctionDirectory = false;
				TArray<FString> DependedStringArray;
				DependedString.ParseIntoArray(DependedStringArray, TEXT("/"));

				FString DependFeature;
				if(DependedStringArray.Num() > 5)
				{
					DependFeature = DependedStringArray[4];
				}
				else
				{
					return true;
				}
			
				if(IsStringStartWithStringList(DependedString, DependResourceAssetes))
				{
					// 引用目录的名字为WBP目录名或加上后缀 _x，例如 WBP 目录为 3V3，引用目录的名字为 3V3_2
					if (DependFeature == SourceFeature || DependFeature.Find(SourceFeature + "_") == 0)
					{
						return true;
					}
				}
				
				if (ExternDependDirectory.Contains(SourceFeature))
				{
					if (ExternDependDirectory[SourceFeature].Contains(DependFeature))
					{
						return true;
					}
				}
				Log.RegistryAndLog(AssetData,TEXT("WBPAsset"), CheckRuleType,TEXT("{} 中的 WBP 引用 {} 中的资源 {}"), SourceFeature, DependFeature, DependedAsset->GetPathName());
				return false;
			}
			return true;
		};
		
		const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
		TArray<FName> AssetDependencies;
		AssetRegistryModule.Get().GetDependencies(Name, AssetDependencies, UE::AssetRegistry::EDependencyCategory::All);
		TArray<FString> IllegalDependedArray;
		for (int32 i = 0; i < AssetDependencies.Num(); ++i)
		{
			TArray<FAssetData> OutAssetData;
			AssetRegistryModule.Get().GetAssetsByPackageName(AssetDependencies[i], OutAssetData);
			if (!OutAssetData.IsEmpty())
			{
				UObject* AssetInPackage = OutAssetData[0].GetAsset();
				bSuccess &= IsDependenceValid(AssetInPackage);
			}

			if (AssetDependencies[i].ToString().Contains("_DEADPACKAGE_"))
			{
				Log.RegistryAndLog(AssetData,TEXT("WBPAsset"), CheckRuleType,TEXT("{} 的引用关系中包含空节点，请查看可能关联{}资产的动画轨道"), Name.ToString(), AssetDependencies[i].ToString());
				return false;
			}
		}
	}

	return bSuccess;
}

//动效资源检查Ani_In与Ani_Out匹配
bool UWBPAssetRule::CheckAniInAndOut(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset()))
	{
		AnimationMap.Empty();
		TArray<TObjectPtr<UWidgetAnimation>> WidgetAnimations = WidgetBlueprint->Animations;
		for (auto& WidgetAnimation : WidgetAnimations)
		{
			FString AnimName = WidgetAnimation->GetDisplayName().ToString();
			if (AnimName.EndsWith("_out"))
			{
				FString AnimNameNoSuffix = AnimName.LeftChop(4);
				if (AnimationMap.Contains(AnimNameNoSuffix))
				{
					AnimationMap[AnimNameNoSuffix].Value = WidgetAnimation;
				}
				else
				{
					AnimationMap.Add(AnimNameNoSuffix, MakeTuple(nullptr, WidgetAnimation));
				}
			}
			else if (AnimName.EndsWith("_in"))
			{
				FString AnimNameNoSuffix = AnimName.LeftChop(3);
				if (AnimationMap.Contains(AnimNameNoSuffix))
				{
					AnimationMap[AnimNameNoSuffix].Key = WidgetAnimation;
				}
				else
				{
					AnimationMap.Add(AnimNameNoSuffix, MakeTuple(WidgetAnimation, nullptr));
				}
			}
		}

		for (auto& [AnimName, AnimInAndOut] : AnimationMap)
		{
			UWidgetAnimation* AnimIn = AnimInAndOut.Key.Get();
			UWidgetAnimation* AnimOut = AnimInAndOut.Value.Get();
			BindingObjectsTrackMap.Empty();
			if (AnimIn == nullptr)
			{
				Log.RegistryAndLog(AssetData, TEXT("Animation"), CheckRuleType,TEXT("带有_out后缀的动画必须带有对应的_in后缀动画:{}"), AnimName);
				bSuccess = false;
			}
			if (AnimOut != nullptr)
			{
				for (auto BindObject : AnimOut->GetMovieScene()->GetBindings())
				{
					const TArray<UMovieSceneTrack*>& Tracks = BindObject.GetTracks();
					TArray<TWeakObjectPtr<UMovieSceneTrack>> BindingObjects = BindingObjectsTrackMap.Emplace(BindObject.GetName());
					for (UMovieSceneTrack* Track : Tracks)
					{
						BindingObjects.Add(Track);
					}
				}
			}
			for (auto [BindObjectName, BindObjectTracks] : BindingObjectsTrackMap)
			{
				bool bMatchObject = false;
				if (AnimIn == nullptr || AnimOut == nullptr)
				{
					continue;
				}
				for (auto BindObject : AnimIn->GetMovieScene()->GetBindings())
				{
					if (BindObjectName == BindObject.GetName())
					{
						bMatchObject = true;
						for (const auto BindObjectTrackOut : BindObjectTracks)
						{
							bool bMatchTrack = false;
							for (const auto BindObjectTrackIn : BindObject.GetTracks())
							{
								if (BindObjectTrackOut->GetTrackName().ToString() == BindObjectTrackIn->GetTrackName().ToString())
								{
									bMatchTrack = true;
									CompareTrack(AssetData, WidgetBlueprint, BindObjectTrackIn, BindObjectTrackOut.Get(), AnimOut->GetDisplayName().ToString(), BindObjectName, AnimIn->GetDisplayName().ToString());
								}
							}
							if (!bMatchTrack)
							{
								Log.RegistryAndLog(AssetData, TEXT("Animation"), CheckRuleType,TEXT("动画{}的绑定对象{}的轨道{}在动画{}中不存在"),
													AnimOut->GetDisplayName().ToString(),
													BindObjectName,
													BindObjectTrackOut->GetDisplayName().ToString(),
													AnimIn->GetDisplayName().ToString()
													);
								bSuccess = false;
							}
						}
					}
				}
				if (!bMatchObject)
				{
					Log.RegistryAndLog(AssetData, TEXT("Animation"), CheckRuleType,TEXT("动画{}的绑定对象{}在动画{}中不存在"),
													AnimOut->GetDisplayName().ToString(),
													BindObjectName,
													AnimIn->GetDisplayName().ToString()
													);
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool UWBPAssetRule::CheckAnimRefNonExistObj(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
    bool bSuccess = true;
    if(UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset()))
    {
        FAnimRefNoExistObjectChecker Checker;
        const auto& WidgetAnimations = WidgetBlueprint->Animations;
        for (const auto& Animation : WidgetAnimations)
        {
          if (!Checker(Animation, WidgetBlueprint, CheckRuleType, AssetData, Log))
          {
              bSuccess = false;
          }
        }
    }
    return bSuccess;
}

bool UWBPAssetRule::CheckLuaModify(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	// 如果本地有 lua 文件，说明是程序，跳过该项规则检查
	const FString GameInstanceScriptPath = FPaths::Combine(FPaths::ProjectContentDir(), TEXT("Script"), TEXT("Gameplay"), TEXT("GameEntrance"), TEXT("GameInstance.lua"));
	if (IFileManager::Get().FileExists(*GameInstanceScriptPath))
	{
		return true;
	}
	
	UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset());
	const FString PackagePath = WidgetBlueprint->GetPackage()->GetFName().ToString();
	const FString PackageName = WidgetBlueprint->GetFName().ToString();

	// 只在 本地自测/提交 时检查，Commandlet (增量、全量检查) 不检查
	if (!IsRunningCommandlet())
	{
		// 参考 UAssetToolsImpl::DiffAgainstDepot
	
		// Make sure our history is up to date
		ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
		TSharedRef<FUpdateStatus, ESPMode::ThreadSafe> UpdateStatusOperation = ISourceControlOperation::Create<FUpdateStatus>();
		UpdateStatusOperation->SetUpdateHistory(true);
		SourceControlProvider.Execute(UpdateStatusOperation, SourceControlHelpers::PackageFilename(PackagePath));

		// Get the SCC state
		FSourceControlStatePtr SourceControlState = SourceControlProvider.GetState(SourceControlHelpers::PackageFilename(PackagePath), EStateCacheUsage::Use);

		// If we have an asset and its in SCC..
		if( SourceControlState.IsValid() && WidgetBlueprint != nullptr && SourceControlState->IsSourceControlled() )
		{
			// Get the file name of package
			FString RelativeFileName;
			if(FPackageName::DoesPackageExist(PackagePath, &RelativeFileName))
			{
				if(SourceControlState->GetHistorySize() > 0)
				{
					TSharedPtr<ISourceControlRevision, ESPMode::ThreadSafe> Revision = SourceControlState->GetHistoryItem(0);
					check(Revision.IsValid());

					// Get the head revision of this package from source control
					FString AbsoluteFileName = FPaths::ConvertRelativePathToFull(RelativeFileName);
					FString TempFileName;
					if(UPackage* TempPackage = DiffUtils::LoadPackageForDiff(Revision))
					{
						// Grab the old asset from that old package
						UObject* OldObject = FindObject<UObject>(TempPackage, *PackageName);

						// Recovery for package names that don't match
						if (OldObject == nullptr)
						{
							OldObject = TempPackage->FindAssetInPackage();
						}

						if(OldObject != nullptr)
						{
							// TODO:
							// 比较 Asset (本地版本) 与 OldObject (服务器版本)
							UWidgetBlueprint* OldBlueprint = Cast<UWidgetBlueprint>(OldObject);
							OldBlueprint->WidgetTree->ForEachWidget([&](UWidget* Widget) {
								FName OldName = Widget->GetFName();
								if (OldName.ToString().EndsWith("_lua"))
								{
									UWidget* CurrentWidget = WidgetBlueprint->WidgetTree->FindWidget(OldName);
									if (CurrentWidget == nullptr)
									{
										Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType,TEXT("蓝图{}中节点{}被删除或名称被修改，请检查对应资源"),
											PackageName, OldName.ToString()
											);										
									}
								}
							});
							
						}
					}
				}
			} 
		}
	}

	return false;
}

void UWBPAssetRule::GetDependedBinkAssets(const FAssetData& AssetData, TArray<FAssetData>& OutDependedBinkAssets, int32& OutDepth)
{
	if (OutDepth > 8)
	{
		return;
	}
	OutDepth++;
	TArray<FName> AssetDependencies;
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	AssetRegistryModule.Get().GetDependencies(AssetData.PackageName, AssetDependencies, UE::AssetRegistry::EDependencyCategory::All);
	for (int32 i = 0; i < AssetDependencies.Num(); ++i)
	{
		TArray<FAssetData> OutAssetData;
		AssetRegistryModule.Get().GetAssetsByPackageName(AssetDependencies[i], OutAssetData);
		for (int32 j = 0; j < OutAssetData.Num(); ++j)
		{
			const FAssetData& DependedAsset = OutAssetData[j];
			if (UClass* AssetClass = DependedAsset.GetClass())
			{
				if (AssetClass->IsChildOf(UBinkMediaPlayer::StaticClass()))
				{
					OutDependedBinkAssets.AddUnique(DependedAsset);
					continue;
				}
				if (AssetClass->IsChildOf(UPaperSprite::StaticClass()))
				{
					continue;
				}
			}
			GetDependedBinkAssets(DependedAsset, OutDependedBinkAssets, OutDepth);
		}
	}
	OutDepth--;
}

bool UWBPAssetRule::CheckDependedBinkMediaPlayerNum(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = false;
	TArray<FAssetData> OutDependedBinkAssets;
	int32 StartDepth = 0;
	GetDependedBinkAssets(AssetData, OutDependedBinkAssets, StartDepth);
	if (OutDependedBinkAssets.Num() > MaxDependedBinkMediaPlayerNum)
	{
		Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType,TEXT("蓝图资产引用的Bink文件不能超过{}个,当前{}个"), MaxDependedBinkMediaPlayerNum, OutDependedBinkAssets.Num());
		bSuccess = false;
	}
	return bSuccess;
}

bool UWBPAssetRule::CheckUFunctionWithBlank(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
#if WITH_EDITORONLY_DATA
	if(UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset()))
	{
		for (auto Graph: WidgetBlueprint->FunctionGraphs)
		{
			if (Graph->GetName().Contains(TEXT(" ")))
			{
				Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("蓝图中的{}函数含有空格。"), Graph->GetName());
				return false;
			}
		}
	}
#endif
	return true;
}

const FSlateFontInfo* UWBPAssetRule::GetSlateFontInfo(UObject* Object)
{
	const UWidget* Widget = Cast<UWidget>(Object);
	if (Widget == nullptr)
	{
		return nullptr;
	}
	const UClass* WidgetClass = Widget->GetClass();
	if (WidgetClass == nullptr)
	{
		return nullptr;
	}
	FProperty* FontProperty = WidgetClass->FindPropertyByName("Font");
	if (FontProperty == nullptr)
	{
		return nullptr;
	}
	const FStructProperty* FontStructProperty = CastField<FStructProperty>(FontProperty);
	if (FontStructProperty == nullptr)
	{
		return nullptr;
	}
	if (FontStructProperty->Struct != FSlateFontInfo::StaticStruct())
	{
		return nullptr;
	}
	void* DataAddress = FontStructProperty->ContainerPtrToValuePtr<void>(Object);
	if (DataAddress == nullptr)
	{
		return nullptr;
	}
	const FSlateFontInfo* SlateFontInfo = static_cast<FSlateFontInfo*>(DataAddress);
	return SlateFontInfo;
}

const UFontFace* UWBPAssetRule::GetFontFaceFromSlateFontInfo(const FSlateFontInfo* SlateFontInfo)
{
	if (SlateFontInfo == nullptr)
	{
		return nullptr;
	}
	const FCompositeFont* CompositeFont = SlateFontInfo->GetCompositeFont();
	if (CompositeFont == nullptr)
	{
		return nullptr;
	}
	const FName TypefaceFontName = SlateFontInfo->TypefaceFontName;
	for (const FTypefaceEntry& TypefaceEntry : CompositeFont->DefaultTypeface.Fonts)
	{
		if (TypefaceEntry.Name != TypefaceFontName)
		{
			continue;
		}
		const UObject* FontFaceAsset = TypefaceEntry.Font.GetFontFaceAsset();
		if (FontFaceAsset == nullptr)
		{
			return nullptr;
		}
		const UFontFace* FontFace = Cast<UFontFace>(FontFaceAsset);
		return FontFace;
	}
	return nullptr;
}

bool UWBPAssetRule::CheckFontDistanceField(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset());
	if (WidgetBlueprint == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find WidgetBlueprint"));
		return bSuccess;
	}
	TArray<UObject*> Objects;
	GetObjectsWithOuter(WidgetBlueprint->GetPackage(), Objects);
	TArray<const UFontFace*> UsedFontFaces;
	int32 ValidDistanceFieldPpem = FCString::Atoi(*Params.GetValue(TEXT("ValidDistanceFieldPpem")));
	for (UObject* Object : Objects)
	{
		const FSlateFontInfo* SlateFontInfo = GetSlateFontInfo(Object);
		if (SlateFontInfo == nullptr)
		{
			continue;
		}
		const UFontFace* FontFace = GetFontFaceFromSlateFontInfo(SlateFontInfo);
		if (FontFace && FontFace->bEnableDistanceFieldRendering)
		{
			UsedFontFaces.AddUnique(FontFace);
		}
	}
	for (const UFontFace* FontFace : UsedFontFaces)
	{
		if (FontFace->MinDistanceFieldPpem > ValidDistanceFieldPpem ||
				FontFace->MidDistanceFieldPpem > ValidDistanceFieldPpem ||
				FontFace->MaxDistanceFieldPpem > ValidDistanceFieldPpem)
		{
			Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("引用的字体样式{}的单通道距离场分辨率的Low Quality，Medium Quality ，High  Quality值要小于等于{}"), FontFace->GetName(), ValidDistanceFieldPpem);
			bSuccess = false;
		}
	}
	return bSuccess;
}

float UWBPAssetRule::ConvertFontSizeFromNativeToDisplay(float NativeFontSize)
{
	const UUserInterfaceSettings* UISettings = GetDefault<UUserInterfaceSettings>();
	if (UISettings == nullptr)
	{
		return NativeFontSize;
	}
	const float FontDisplayDPI = UISettings->GetFontDisplayDPI();
	if (FontDisplayDPI <= 0)
	{
		return NativeFontSize;
	}
	const float DisplayedSize = NativeFontSize * static_cast<float>(FontConstants::RenderDPI) / FontDisplayDPI;
	return DisplayedSize;
}

bool UWBPAssetRule::CheckFontOutlineSize(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset());
	if (WidgetBlueprint == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find WidgetBlueprint"));
		return bSuccess;
	}
	TArray<UObject*> Objects;
	GetObjectsWithOuter(WidgetBlueprint->GetPackage(), Objects);
	TArray<const UFontFace*> UsedFontFaces;
	const float MaxOutlineSizeRatio = FCString::Atof(*Params.GetValue(TEXT("MaxOutlineSizeRatio")));
	for (UObject* Object : Objects)
	{
		const FSlateFontInfo* SlateFontInfo = GetSlateFontInfo(Object);
		if (SlateFontInfo == nullptr)
		{
			continue;
		}
		const UFontFace* FontFace = GetFontFaceFromSlateFontInfo(SlateFontInfo);
		if (FontFace && FontFace->bEnableDistanceFieldRendering)
		{
			const float DisplayedFontSize = ConvertFontSizeFromNativeToDisplay(SlateFontInfo->Size);
			if (DisplayedFontSize <= 0)
			{
				continue;
			}
			if (SlateFontInfo->Size > 0 && SlateFontInfo->OutlineSettings.OutlineSize / DisplayedFontSize > MaxOutlineSizeRatio)
			{
				Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("头顶UI下使用SDF字体的TextBlock，其轮廓大小不大于字体尺寸的{}"), MaxOutlineSizeRatio);
				return false;
			}
		}
	}
	return bSuccess;
}

bool UWBPAssetRule::CheckWidgetIsVolatile(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UWidgetBlueprint* WidgetBlueprint = Cast<UWidgetBlueprint>(AssetData.GetAsset());
	if (WidgetBlueprint == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find WidgetBlueprint"));
		return bSuccess;
	}
	const FBoolProperty* IsVolatileProperty = CastField<FBoolProperty>(UWidget::StaticClass()->FindPropertyByName(TEXT("bIsVolatile")));
	if (IsVolatileProperty == nullptr)
	{
		return bSuccess;
	}
	TArray<UObject*> Objects;
	GetObjectsWithOuter(WidgetBlueprint->GetPackage(), Objects);
	for (UObject* Object : Objects)
	{
		const UWidget* Widget = Cast<UWidget>(Object);
		if (Widget == nullptr)
		{
			continue;
		}
		const void* PropertyValueAddr = IsVolatileProperty->ContainerPtrToValuePtr<void>(Widget);
		if (PropertyValueAddr == nullptr)
		{
			continue;
		}
		if (IsVolatileProperty->GetPropertyValue(PropertyValueAddr))
		{
			Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("头顶UI下的UWidget及其子UWidget的bIsVolatile属性不能为true,当前widget:{}"), Widget->GetName());
			return false;
		}
	}
	return bSuccess;
}

bool UWBPAssetRule::CheckDuplicatedName(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	FARFilter Filter;
	Filter.ClassPaths.Add(UWidgetBlueprint::StaticClass()->GetClassPathName());
	Filter.PackagePaths.Add(TEXT("/Game/Arts/UI_2/"));
	Filter.PackagePaths.Add(TEXT("/Game/Arts/UI/"));
	Filter.PackagePaths.Add(TEXT("/Game/Arts/UI_Update/"));
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	TArray<FAssetData> OutAssetData;
	AssetRegistry.GetAssets(Filter, OutAssetData);
	for (const FAssetData& WBPAssetData : OutAssetData)
	{
		if (WBPAssetData.AssetName == AssetData.AssetName && WBPAssetData.PackageName != AssetData.PackageName)
		{
			Log.RegistryAndLog(AssetData, TEXT("WBP"), CheckRuleType,TEXT("控件资产不能有重复的命名"));
			return false;
		}
	}
	return bSuccess;
}
void UWBPAssetRule::CompareTrack(const FAssetData& AssetData, UWidgetBlueprint* WidgetBlueprint, UMovieSceneTrack* TrackIn, UMovieSceneTrack* TrackOut, FString AnimOut, FString BindObjectName, FString AnimIn)
{
	TArray<UMovieSceneSection*> SectionsIn = TrackIn->GetAllSections();
	TArray<UMovieSceneSection*> SectionsOut = TrackOut->GetAllSections();
	if (SectionsIn.Num() != SectionsOut.Num())
	{
		Log.RegistryAndLog(AssetData, TEXT("Animation"), CheckRuleType,TEXT("动画{}的绑定对象{}的轨道{}的Section数量与动画{}不一致"),
			AnimOut, BindObjectName, TrackIn->GetTrackName().ToString(),AnimIn);
		return;
	}
	if (Cast<UMovieScene2DTransformTrack>(TrackIn) && Cast<UMovieScene2DTransformTrack>(TrackOut))
	{
		for (int i = 0;i < SectionsIn.Num();i++)
		{
			FString TempLog = FString::Format(TEXT("动画{0}的绑定对象{1}的轨道{2}的"),{AnimOut, BindObjectName, TrackIn->GetTrackName().ToString(),AnimIn});
			CompareSection(AssetData, WidgetBlueprint, Cast<UMovieScene2DTransformSection>(SectionsIn[i]), Cast<UMovieScene2DTransformSection>(SectionsOut[i]), TempLog);
		}
	}
	if (Cast<UMovieSceneFloatTrack>(TrackIn) && Cast<UMovieSceneFloatTrack>(TrackOut))
	{
		for (int i = 0;i < SectionsIn.Num();i++)
		{
			FString TempLog = FString::Format(TEXT("动画{0}的绑定对象{1}的轨道{2}的"),{AnimOut, BindObjectName, TrackIn->GetTrackName().ToString(),AnimIn});
			CompareSection(AssetData, WidgetBlueprint, Cast<UMovieSceneFloatSection>(SectionsIn[i]), Cast<UMovieSceneFloatSection>(SectionsOut[i]), TempLog);
		}
	}
}

void UWBPAssetRule::CompareSection(const FAssetData& AssetData, UWidgetBlueprint* WidgetBlueprint, UMovieScene2DTransformSection* SectionIn, UMovieScene2DTransformSection* SectionOut, FString InLog)
{
	if (SectionIn == nullptr || SectionOut == nullptr)
	{
		return;
	}
	CompareChannel(AssetData, WidgetBlueprint, &SectionIn->Translation[0], &SectionOut->Translation[0], InLog + "Translation X");
	CompareChannel(AssetData, WidgetBlueprint, &SectionIn->Translation[1], &SectionOut->Translation[1], InLog + "Translation Y");
	CompareChannel(AssetData, WidgetBlueprint, &SectionIn->Scale[0], &SectionOut->Scale[0], InLog + "Scale X");
	CompareChannel(AssetData, WidgetBlueprint, &SectionIn->Scale[1], &SectionOut->Scale[1], InLog + "Scale Y");
	CompareChannel(AssetData, WidgetBlueprint, &SectionIn->Rotation, &SectionOut->Rotation, InLog + "Rotation");
	CompareChannel(AssetData, WidgetBlueprint, &SectionIn->Shear[0], &SectionOut->Shear[0], InLog + "Shear X");
	CompareChannel(AssetData, WidgetBlueprint, &SectionIn->Shear[1], &SectionOut->Shear[1], InLog + "Shear Y");
}

void UWBPAssetRule::CompareSection(const FAssetData& AssetData, UWidgetBlueprint* WidgetBlueprint, UMovieSceneFloatSection* SectionIn, UMovieSceneFloatSection* SectionOut, FString InLog)
{
	if (SectionIn == nullptr || SectionOut == nullptr)
	{
		return;
	}
	CompareChannel(AssetData, WidgetBlueprint, &SectionIn->GetChannel(), &SectionOut->GetChannel(), InLog);
}

void UWBPAssetRule::CompareChannel(const FAssetData& AssetData, UWidgetBlueprint* WidgetBlueprint, FMovieSceneFloatChannel* ChannelIn, FMovieSceneFloatChannel* ChannelOut, FString InLog)
{
	const auto InValues = ChannelIn->GetValues();
	const auto OutValues = ChannelOut->GetValues();
	if (!ChannelIn->HasAnyData() && !ChannelOut->HasAnyData())
	{
		return;
	}
	float InValue = ChannelIn->GetDefault().Get(.0f);
	float OutValue = ChannelIn->GetDefault().Get(.0f);
	if (InValues.Num() > 0)
	{
		InValue = InValues[InValues.Num() - 1].Value;
	}
	if (OutValues.Num() > 0)
	{
		OutValue = OutValues[0].Value;
	}
	if (InValue != OutValue)
	{
		Log.RegistryAndLog(AssetData, TEXT("Animation"), CheckRuleType,TEXT("{0}的起始值与对应的In动画的结尾不一致"), InLog);
	}
}

bool UWBPAssetRule::FAnimRefNoExistObjectChecker::operator()(const TObjectPtr<UWidgetAnimation>& InAnimation, UWidgetBlueprint* WidgetBlueprint, ERMCheckRuleType InCheckRuleType, const FAssetData& AssetData, FResourceCheckLogCollect& InLog) const
{
    bool bSuccessed = true;
    if (InAnimation && InAnimation->MovieScene)
    {
        const auto& OwningScene = InAnimation->MovieScene;
        TArray<UMovieSceneFolder*> AllFolders;
        GetMovieSceneFoldersRecursive(InAnimation->MovieScene->GetRootFolders(), AllFolders);
        
        // check if folder is referencing a valid object
        for (int32 Index = 0; Index < AllFolders.Num(); Index++)
        {
            if (auto* Folder = AllFolders[Index])
            {
                const auto& ChildObjBindings = Folder->GetChildObjectBindings();
                for (int32 ChildObjectBindingIndex = 0; ChildObjectBindingIndex < ChildObjBindings.Num(); ChildObjectBindingIndex++)
                {
                    const FGuid& ChildBinding = ChildObjBindings[ChildObjectBindingIndex];
                    if (!OwningScene->FindBinding(ChildBinding))
                    {
                        InLog.RegistryAndLog(AssetData, TEXT("Animation"), InCheckRuleType, TEXT("动画{}的文件夹{}绑定了一个不存在的对象{}"),
                                                    InAnimation->GetDisplayName().ToString(),
                                                    *Folder->GetFolderName().ToString(),
                                                    *ChildBinding.ToString()
                                                    );
                        bSuccessed = false;
                    }
                }
            }
        }
        
        // check if object binding is referencing a valid object
        for (const auto& ObjBinding : OwningScene->GetBindings())
        {
            bool bFound = false;
            for (const auto& WidgetAnimBinding : InAnimation->AnimationBindings)
            {
                if (WidgetAnimBinding.AnimationGuid == ObjBinding.GetObjectGuid())
                {
                    bFound = true;
                    break;
                }
            }
            
            if (!bFound)
            {
                InLog.RegistryAndLog(AssetData, TEXT("Animation"), InCheckRuleType, TEXT("动画{}的轨道{}绑定了一个不存在的控件"),
                                                    InAnimation->GetDisplayName().ToString(),
                                                    ObjBinding.GetName()
                                                    );
                bSuccessed = false;
            }
        }
    }
    
    return bSuccessed;
}

void UWBPAssetRule::FAnimRefNoExistObjectChecker::GetMovieSceneFoldersRecursive(TArrayView<UMovieSceneFolder* const> InFoldersToRecurse, TArray<UMovieSceneFolder*>& OutFolders)
{
    for (UMovieSceneFolder* Folder : InFoldersToRecurse)
    {
        if (Folder)
        {
            OutFolders.Add(Folder);
            GetMovieSceneFoldersRecursive(Folder->GetChildFolders(), OutFolders);
        }
    }
}

#undef LOCTEXT_NAMESPACE
