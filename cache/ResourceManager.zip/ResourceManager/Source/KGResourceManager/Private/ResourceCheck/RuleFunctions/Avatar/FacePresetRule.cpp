// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/RuleFunctions/Avatar/FacePresetRule.h"
#include "Asset/AvatarPresetBase.h"

UClass* UFacePresetRule::GetAssetType()
{
	return UFacePreset::StaticClass();
}