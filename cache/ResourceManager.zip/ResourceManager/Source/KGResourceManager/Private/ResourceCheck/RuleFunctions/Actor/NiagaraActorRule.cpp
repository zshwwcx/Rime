#include "ResourceCheck/RuleFunctions/Actor/NiagaraActorRule.h"

#include "NiagaraActor.h"
#include "NiagaraComponent.h"
#include "NiagaraSystem.h"

UClass* UNiagaraActorRule::GetAssetType()
{
	return ANiagaraActor::StaticClass();
}

bool UNiagaraActorRule::CheckNiagaraEffectType(const FAssetData& AssetData, TMap<FString, FString>& RepairParams)
{
	bool bSuccess = true;
	const TArray<FString>& ValidEffectTypeNames = Params.GetValueList("ValidEffectTypeNames");
	if (ValidEffectTypeNames.IsEmpty())
	{
		return bSuccess;
	}
	const TArray<FString>& WhiteEffectTypeNames = Params.GetValueList("WhiteEffectTypeNames");
	const TArray<FString>& WhiteNiagaraActorList = Params.GetValueList("WhiteNiagaraActorList");
	ANiagaraActor* NiagaraActor = Cast<ANiagaraActor>(AssetData.GetAsset());
	if (NiagaraActor == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find NiagaraActor"));
		return bSuccess;
	}
	UNiagaraComponent* NiagaraComponent = NiagaraActor->GetNiagaraComponent();
	if (NiagaraComponent == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find NiagaraComponent"));
		return bSuccess;
	}
	UNiagaraSystem* NiagaraSystem = NiagaraComponent->GetAsset();
	if (NiagaraSystem == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can't find NiagaraSystem"));
		return bSuccess;
	}
	const UNiagaraEffectType* EffectType = NiagaraSystem->GetEffectType();
	if (EffectType == nullptr)
	{
		return bSuccess;
	}
	const FString& EffectTypeName = EffectType->GetName();
	if (!ValidEffectTypeNames.Contains(EffectTypeName))
	{
		if (WhiteEffectTypeNames.Contains(EffectTypeName))
		{
			const FString NiagaraActorName = NiagaraActor->GetActorLabel();
			if (!WhiteNiagaraActorList.Contains(NiagaraActorName))
			{
				Log.RegistryAndLog(AssetData, TEXT("NiagaraActor"), CheckRuleType, TEXT("Niagara Actor的特效资产：{}，使用了需要加白才能使用的效果类型：{},请更换合法特效或找美术同学更改特效类型"), NiagaraSystem->GetFullName(), EffectTypeName);
				bSuccess = false;
			}
		}
		else
		{
			Log.RegistryAndLog(AssetData, TEXT("NiagaraActor"), CheckRuleType, TEXT("Niagara Actor使用了非法效果类型的特效资产：{}，当前特效效果类型：{},允许的效果类型:{},请更换合法特效或找美术同学更改特效类型"), NiagaraSystem->GetFullName(), EffectTypeName, FString::Join(ValidEffectTypeNames, TEXT(",")));
			bSuccess = false;
		}
	}
	return bSuccess;
}
