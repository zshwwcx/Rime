#include "ResourceCheck/RuleFunctions/Texture/TextureCubeRule.h"

#include "LevelSequence.h"
#include "MovieScene.h"
#include "TextureCompiler.h"
#include "Components/ReflectionCaptureComponent.h"
#include "Components/SkyLightComponent.h"
#include "Engine/TextureCube.h"

namespace
{
	void IsTextureCubeReferencedBySkyLightOrReflection(const AActor* InActor, UTextureCube* InTextureCube, bool& bOutReferenceBySkylight, bool& bOutReferenceByReflection)
	{
		if (!bOutReferenceBySkylight)
		{
			if (const USkyLightComponent* SkyLightComponent = InActor->FindComponentByClass<USkyLightComponent>())
			{
				if (SkyLightComponent->Cubemap == InTextureCube)
				{
					bOutReferenceBySkylight = true;
				}
			}
		}

		if (!bOutReferenceByReflection)
		{
			if (const UReflectionCaptureComponent* ReflectionComponent = InActor->FindComponentByClass<UReflectionCaptureComponent>())
			{
				if (ReflectionComponent->Cubemap == InTextureCube)
				{
					bOutReferenceByReflection = true;
				}
			}
		}
	}

	TArray<const AActor*> GetCheckActorsForAsset(const FAssetData& OutAsset) 
	{
		TArray<const AActor*> CheckActors;

		if (const ULevelSequence* LevelSequence = Cast<ULevelSequence>(OutAsset.GetAsset())) 
		{
			for (int32 Index = 0; Index < LevelSequence->MovieScene->GetSpawnableCount(); ++Index) 
			{
				if (const AActor* Actor = Cast<AActor>(LevelSequence->MovieScene->GetSpawnable(Index).GetObjectTemplate())) 
				{
					CheckActors.Add(Actor);
				}
			}
		} 
		else if (const UWorld* World = Cast<UWorld>(OutAsset.GetAsset())) 
		{
			if (!World->IsPartitionedWorld()) 
			{
				for (const AActor* Actor : World->PersistentLevel->Actors) 
				{
					if (Actor)
					{
						CheckActors.Add(Actor);
					}
				}
			}
		} 
		else if (const AActor* Actor = Cast<AActor>(OutAsset.GetAsset())) 
		{
			CheckActors.Add(Actor);
		}

		return CheckActors;
	}
}


UClass* UTextureCubeRule::GetAssetType()
{
	return UTextureCube::StaticClass();
}

bool UTextureCubeRule::PreExecuteAsset(const FAssetData& AssetData)
{
	bNeedCheck = false;
	bNeverCook = false;
	bNeedCook = false;
	UTextureCube* TextureCube = Cast<UTextureCube>(AssetData.GetAsset());
	if (!TextureCube)
	{
		return true;
	}
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FName> AssetReferencers;
	AssetRegistryModule.Get().GetReferencers(AssetData.PackageName, AssetReferencers, UE::AssetRegistry::EDependencyCategory::All);
	bool bReferenceByBp = false, bReferenceByMaterial = false, bReferenceBySkylight = false, bReferenceByReflection = false;
	for (const FName& Referencer : AssetReferencers)
	{
		TArray<FAssetData> OutAssetData;
		AssetRegistryModule.Get().GetAssetsByPackageName(Referencer, OutAssetData);
		if (OutAssetData.IsEmpty())
		{
			continue;
		}
		const FAssetData& OutAsset = OutAssetData[0];
		const UClass* AssetClass = LoadObject<UClass>(nullptr, *OutAsset.AssetClassPath.ToString());
		if (!AssetClass)
		{
			continue;
		}
		if (AssetClass->IsChildOf(UBlueprint::StaticClass()))
		{
			bReferenceByBp = true;
		}
		else if (AssetClass->IsChildOf(UMaterialInterface::StaticClass()))
		{
			bReferenceByMaterial = true;
		}
		else if (!bReferenceBySkylight || !bReferenceByReflection)
		{
			TArray<const AActor*> CheckActors = GetCheckActorsForAsset(OutAsset);
			for (const AActor* Actor : CheckActors)
			{
				IsTextureCubeReferencedBySkyLightOrReflection(Actor, TextureCube, bReferenceBySkylight, bReferenceByReflection);
				if (bReferenceBySkylight && bReferenceByReflection)
				{
					break;
				}
			}
		}
		if (bReferenceByMaterial && bReferenceByBp && bReferenceBySkylight && bReferenceByReflection)
		{
			break;
		}
	}

	const int32 ReferenceTypeCount = bReferenceByBp + bReferenceByMaterial + bReferenceBySkylight + bReferenceByReflection;
	if (ReferenceTypeCount == 0)
	{
		return true;
	}
	FString Section;
	bNeedCheck = true;
	if (ReferenceTypeCount > 1)
	{
		Section = "BpMaterialAndActor";
	}
	else
	{
		Section = (bReferenceByBp || bReferenceByMaterial) ? "OnlyBpMaterial" : "OnlyActor";
	}
	const FString TextureCubeRuleIniPath = FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("KGResourceManager/Config/TextureCubeRule.ini"));
	FString TextureCubeIniPath = FConfigCacheIni::NormalizeConfigIniPath(TextureCubeRuleIniPath);

	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (PlatformFile.FileExists(*TextureCubeIniPath))
	{
		GConfig->Flush(true, *TextureCubeIniPath);
		MaximumTextureSize = GConfig->GetStr(*Section, TEXT("MaximumTextureSize"), TextureCubeIniPath);
		MipGenSetting = GConfig->GetStr(*Section, TEXT("MipGenSetting"), TextureCubeIniPath);
		TextureGroup = GConfig->GetStr(*Section, TEXT("TextureGroup"), TextureCubeIniPath);
		CompressionSettings = GConfig->GetStr(*Section, TEXT("CompressionSettings"), TextureCubeIniPath);
	}
	if (bReferenceByReflection && !bReferenceBySkylight && !bReferenceByMaterial && !bReferenceByBp)
	{
		bNeverCook = true;
	}
	else if (bReferenceByReflection && (bReferenceByMaterial || bReferenceByBp))
	{
		bNeedCook = true;
	}
	return true;
}

FString UTextureCubeRule::IsNeedCheck(const FAssetData& AssetData)
{
	return bNeedCheck ? "1" : "0";
}

bool UTextureCubeRule::CheckCookPath(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	FString PackagePath = AssetData.PackagePath.ToString();
	FString NeverCookPath = Params.GetValue("NeverCookPath");
	bool bInNeverCookPath = PackagePath.Contains(NeverCookPath);
	if (bNeedCook && bInNeverCookPath)
	{
		Log.RegistryAndLog(AssetData, TEXT("TextureCube"), CheckRuleType, TEXT("混合使用的TextureCube不能放在该目录下:{}"), NeverCookPath);
		return false;
	}
	else if (bNeverCook && !bInNeverCookPath)
	{
		Log.RegistryAndLog(AssetData, TEXT("TextureCube"), CheckRuleType, TEXT("单独使用的TextureCube必须放在该目录下:{}"), NeverCookPath);
		return false;
	}
	return bSuccess;
}

FString UTextureCubeRule::GetStandMaximumTextureSize(const FAssetData& AssetData)
{
	return MaximumTextureSize;
}

FString UTextureCubeRule::GetStandMipGenSetting(const FAssetData& AssetData)
{
	return MipGenSetting;
}

FString UTextureCubeRule::GetStandTextureGroup(const FAssetData& AssetData)
{
	return TextureGroup;
}

FString UTextureCubeRule::GetStandCompressionSettings(const FAssetData& AssetData)
{
	return CompressionSettings;
}

FString UTextureCubeRule::GetTextureCubeMaxInGameSize(const FAssetData& AssetData)
{
	UTextureCube* TextureCube = Cast<UTextureCube>(AssetData.GetAsset());
	if (TextureCube == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s Is not a TextureCube"), *AssetData.AssetName.ToString());
		return TEXT("0,0");
	}
	FTextureCompilingManager::Get().FinishCompilation({TextureCube});
	const int32 SurfaceWidth =  static_cast<int32>(TextureCube->GetSurfaceWidth());
	const int32 SurfaceHeight = static_cast<int32>(TextureCube->GetSurfaceHeight());
	const int32 MaxResMipBias = TextureCube->GetCachedLODBias();
	const int32 MaxInGameWidth = SurfaceWidth ? FMath::Max(SurfaceWidth >> MaxResMipBias, 1) : 0;
	const int32 MaxInGameHeight = SurfaceHeight ? FMath::Max(SurfaceHeight >> MaxResMipBias, 1) : 0;
	TArray<FString> ReStr;
	ReStr.Add(FString::FromInt(MaxInGameWidth));
	ReStr.Add(FString::FromInt(MaxInGameHeight));

	return FString::Join(ReStr, TEXT(","));
}
