// Fill out your copyright notice in the Description page of Project Settings.

#include "ResourceCheck/RuleFunctions/Actor/StaticMeshComponentRule.h"
#include "NavMeshWayPointSystem/SplineWayPoint.h"
#include "Landscape.h"
#include "MainSkyPerformer.h"
#include "NaniteSceneProxy.h"
#include "VT/RuntimeVirtualTexture.h"
#include "Kismet/GameplayStatics.h"
#include "VT/RuntimeVirtualTextureVolume.h"
#include "Components/RuntimeVirtualTextureComponent.h"

bool UStaticMeshComponentRule::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	HalfWPODistanceRadius = FCString::Atoi(*Params.GetValue(TEXT("HalfWPODistanceRadius")));
	HalfWorldPositionOffsetDisableDistance = FCString::Atoi(*Params.GetValue(TEXT("HalfWorldPositionOffsetDisableDistance")));
	WorldPositionOffsetDisableDistance = FCString::Atoi(*Params.GetValue(TEXT("WorldPositionOffsetDisableDistance")));
	ForceWPOMaterial = Params.GetValueList(TEXT("ForceWPOMaterial"));
	DrawInMainPassNeverActorClass = Params.GetValueList(TEXT("DrawInMainPassNeverActorClass"));
	ForbiddenMaterialNames = Params.GetValueList(TEXT("ForbiddenMaterialNames"));
	return true;
}

bool UStaticMeshComponentRule::PreExecuteAsset(const FAssetData& AssetData)
{
	UClass* Class = AssetData.GetClass();

	if(!Class || Class->IsChildOf(ALandscape::StaticClass()) ||
			Class->IsChildOf(ASplineWayPoint::StaticClass()))
	{
		return false;
	}

	//需要包含StaticMeshComponent
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			bool bHasStaticMeshComp = false;
			for(auto Comp : Actor->GetComponents())
			{
				if(UStaticMeshComponent* StaticMeshComp = Cast<UStaticMeshComponent>(Comp))
				{
					bHasStaticMeshComp = true;
					if (!StaticMeshComp->GetStaticMesh()) continue;

					FStaticMeshComponentParam Param;
					if(StaticMeshComp->RuntimeVirtualTextures.Num() > 0)
					{
						for(auto RuntimeVitualTexture : StaticMeshComp->RuntimeVirtualTextures)
						{
							if (RuntimeVitualTexture)
							{
								if(RuntimeVitualTexture->GetName().Contains("RVT"))
								{
									Param.bUsingRVT = true;
								}
								if(RuntimeVitualTexture->GetName().Contains("SAT"))
								{
									Param.bUsingSAT = true;
								}
							}
						}
					}
					
					auto MatInstances = StaticMeshComp->GetMaterials();
					for(int32 Index = 0; Index < MatInstances.Num(); Index++)
					{
						if(auto MatInterface = MatInstances[Index])
						{
							if(MatInterface->GetName().Contains("SAT"))
							{
								Param.bUsingSAT = true;
							}
						}
					}

					if(StaticMeshComp->GetName().Contains("SAT"))
					{
						Param.bUsingSAT = true;
					}
					
					StaticMeshComponentParams.FindOrAdd(StaticMeshComp) = Param;
				}
			}
			if (!bHasStaticMeshComp) return false;
		}
	}
	return true;
}

bool UStaticMeshComponentRule::CheckStaticMeshValid(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				if (Comp->HasAnyFlags(RF_Transient))
				{
					continue;
				}
				if(auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp))
				{
					if (!StaticMeshComp->GetStaticMesh())
					{
						Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("Actor {} : {} 的 StaticMesh 不能为空."),
							Actor->GetActorLabel(), StaticMeshComp->GetName());
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::CheckStaticMeshComponentMobility(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
				{
					StaticMeshComp->UpdateComponentToWorld();
					StaticMeshComp->UpdateBounds();
					if(StaticMeshComp->Mobility != EComponentMobility::Static)
					{
						Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("{} : {} 移动性设置错误，应该为Static")
							,Actor->GetName(),  StaticMeshComp->GetName());
						OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = TEXT("Static");
						bSuccess = false;
					}

				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::CheckStaticMeshComponentNantie(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh() && StaticMeshComponentParams.Find(StaticMeshComp))
				{
					bool MatOverriden = false;
					bool NaniteValidation = true;
					bool bContainsTranslucent = false;
					auto StaticMesh = StaticMeshComp->GetStaticMesh();
					auto MatInstances = StaticMeshComp->GetMaterials();
					for(int32 Index = 0; Index < MatInstances.Num(); Index++)
					{
						if(auto MatInterface = MatInstances[Index])
						{
							if(MatInterface != StaticMesh->GetMaterial(Index))
							{
								MatOverriden = true;
							}
							auto MatInst = Cast<UMaterialInstance>(MatInterface);
							if(!MatInst)
							{
								continue;
							}
							NaniteValidation &= Nanite::IsSupportedShadingModel(MatInst->ShadingModels);
							NaniteValidation &= Nanite::IsSupportedBlendMode(MatInst->BlendMode);

							bool bHasTranslucent = MatInterface->GetBlendMode() == BLEND_Translucent || MatInterface->GetBlendMode() == BLEND_Additive || MatInterface->GetBlendMode() == BLEND_Modulate;
							bContainsTranslucent |= bHasTranslucent;
							if(bHasTranslucent && StaticMeshComp->bDisallowNanite == false)
							{
								Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("StaticMeshComponent: {}的材质{}具有半透明属性，应该禁用Nanite")
									, StaticMeshComp->GetName(), MatInterface->GetName());
								OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = TEXT("true");
								bSuccess = false;
							}
						}
					}
					
					if(!NaniteValidation &&
						MatOverriden ||
						(StaticMeshComponentParams[StaticMeshComp].bUsingRVT ||
						StaticMeshComponentParams[StaticMeshComp].bUsingSAT))
					{
						if(StaticMeshComp->bDisallowNanite == false)
						{
							Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("{} : {} 重载了不适用Nanite的材质或使用RVT/SAT情况下应该禁用Nanite")
								, Actor->GetName(), StaticMeshComp->GetName());
							OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = TEXT("true");
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::CheckStaticMeshComponentWPO(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
				{
					bool bHasForceWPOMat = true;
					auto MatInstances = StaticMeshComp->GetMaterials();
					for(int32 Index = 0; Index < MatInstances.Num(); Index++)
					{
						if(auto MatInst = Cast<UMaterialInstance>(MatInstances[Index]))
						{
							if(ForceWPOMaterial.Contains(MatInst->GetName()) ||
							MatInst->Parent && ForceWPOMaterial.Contains(MatInst->Parent->GetName()))
							{
								bHasForceWPOMat = true;
								break;
							}
						}
					}
					
					if(bHasForceWPOMat)
					{
						int32 SphereRadius = StaticMeshComp->GetStaticMesh()->GetBounds().SphereRadius;
						if(SphereRadius <= HalfWPODistanceRadius)
						{
							if(StaticMeshComp->WorldPositionOffsetDisableDistance != HalfWorldPositionOffsetDisableDistance)
							{
								Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("{} : {} 非强制WPO材质且LocalBounds<={} 需要限定WorldPositionOffsetDisableDistance为{}")
									,Actor->GetName(),  StaticMeshComp->GetName(), HalfWPODistanceRadius, HalfWorldPositionOffsetDisableDistance);
								OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = FString::FromInt(HalfWorldPositionOffsetDisableDistance);
								bSuccess = false;
							}
						}
						else
						{
							if(StaticMeshComp->WorldPositionOffsetDisableDistance != WorldPositionOffsetDisableDistance)
							{
								Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("{} : {} 非强制WPO材质且LocalBounds>{} 需要限定WorldPositionOffsetDisableDistance为{}")
									,Actor->GetName(),  StaticMeshComp->GetName(), HalfWPODistanceRadius, WorldPositionOffsetDisableDistance);
								OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = FString::FromInt(WorldPositionOffsetDisableDistance);
								bSuccess = false;
							}
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::EnableCastShadow(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		for(auto Comp : Actor->GetComponents())
		{
			auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
			if(StaticMeshComp && StaticMeshComp->GetStaticMesh() && StaticMeshComponentParams.Find(StaticMeshComp))
			{
				if(Actor->IsHidden() && StaticMeshComp->CastShadow)
				{
					Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("StaticMeshComponent: {} 不可视的Actor不需要勾选CastShadow")
									, StaticMeshComp->GetName());
					OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = TEXT("false");
					bSuccess = false;
				}
				
				if((StaticMeshComponentParams[StaticMeshComp].bUsingRVT ||
					StaticMeshComponentParams[StaticMeshComp].bUsingSAT) &&
						StaticMeshComp->CastShadow)
				{
					Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("{}: {} 开启RVT/SAT的贴图不需要勾选CastShadow")
									,Actor->GetName(),  StaticMeshComp->GetName());
					OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = TEXT("false");
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::CheckDrawInMainPass(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh() && StaticMeshComponentParams.Find(StaticMeshComp))
				{					
					if((StaticMeshComponentParams[StaticMeshComp].bUsingRVT ||
						StaticMeshComponentParams[StaticMeshComp].bUsingSAT) &&
						StaticMeshComp->VirtualTextureRenderPassType != ERuntimeVirtualTextureMainPassType::Exclusive)
					{
						Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("{} : {} 开启RVT/SAT的贴图DrawInMainPass这里需要选择From Virtual Texture")
									, Actor->GetName(), StaticMeshComp->GetName());
						UEnum* EnumPtr = StaticEnum<ERuntimeVirtualTextureMainPassType>();
						OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = EnumPtr->GetNameByValue(static_cast<int32>(ERuntimeVirtualTextureMainPassType::Exclusive)).ToString();
						bSuccess = false;
					}
					
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::CheckDrawInMainPassNeverActorClass(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
				{
					if(DrawInMainPassNeverActorClass.Contains(Actor->GetClass()->GetName()) && StaticMeshComp->VirtualTextureRenderPassType != ERuntimeVirtualTextureMainPassType::Never)
					{
						Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("{} : {} Actor的类型为{}的DrawInMainPass这里需要选择Never")
									,Actor->GetName(), StaticMeshComp->GetName(), Actor->GetClass()->GetName());
						UEnum* EnumPtr = StaticEnum<ERuntimeVirtualTextureMainPassType>();
						OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = EnumPtr->GetNameByValue(static_cast<int32>(ERuntimeVirtualTextureMainPassType::Never)).ToString();
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::CheckTranslucencySortPriority(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
    {
    	if(!Actor->IsEditorOnly())
    	{
    		for(auto Comp : Actor->GetComponents())
    		{
    			auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
    			if(StaticMeshComp && StaticMeshComp->GetStaticMesh() && StaticMeshComponentParams.Find(StaticMeshComp)) 
    			{
    				if((StaticMeshComponentParams[StaticMeshComp].bUsingRVT ||
    					StaticMeshComponentParams[StaticMeshComp].bUsingSAT) &&
    					StaticMeshComp->TranslucencySortPriority <= 0)
    				{
    					Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("{} : {} 具有RVT/SAT贴图的StaticMeshComponent半透明排序优先级应该大于0")
								,Actor->GetName(),  StaticMeshComp->GetName());
    					OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = TEXT("1");
    					bSuccess = false;
    				}
    			}
    		}
    	}
    }
    return bSuccess;
}

bool UStaticMeshComponentRule::CheckRVTMaterial(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh() && StaticMeshComponentParams.Find(StaticMeshComp))
				{
					bool bUsingVTAvailableMat = false;
					auto MaterialInterfaces = StaticMeshComp->GetMaterials();
					
					for(auto MaterialInterface : MaterialInterfaces)
					{
						if(MaterialInterface)
						{
							if(auto MaterialInstance = Cast<UMaterialInstance>(MaterialInterface))
							{
								if(MaterialInstance->Parent && MaterialInstance->Parent.GetName().Contains("_VT"))
								{
									bUsingVTAvailableMat = true;
								}
							}
						}
					}
					
					if(StaticMeshComponentParams[StaticMeshComp].bUsingRVT && !bUsingVTAvailableMat)
					{
						Log.RegistryAndLog(AssetData, TEXT("StaticMeshComponent"), CheckRuleType, TEXT("{}: {} 使用RVT的模型没有使用支持VT的材质")
						, Actor->GetName(), StaticMeshComp->GetName());
						bSuccess = false;
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::RepairStaticMeshComponentWPO(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	bool IsDirty = false;
	bool bSuccess = false;
	if(Arguments.Num() > 0)
	{
		if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
		{
			if(!Actor->IsEditorOnly())
			{
				for(auto Comp : Actor->GetComponents())
				{
					auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
					if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
					{
						for(auto ArgumentKV : Arguments)
						{
							auto ComponentName = ArgumentKV.Key;
							int32 WPODistance = FCString::Atoi(*ArgumentKV.Value);
							if(ComponentName == StaticMeshComp->GetName())
							{
								StaticMeshComp->WorldPositionOffsetDisableDistance = WPODistance;
								IsDirty = true;
							}
						}
					}
				}
			}

			if(IsDirty)
			{
				Actor->Modify();
				bSuccess = Actor->GetPackage()->MarkPackageDirty();
			}
		}
	}
	
	return bSuccess;
}

bool UStaticMeshComponentRule::RepairCastShadow(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	bool IsDirty = false;
	bool bSuccess = false;
	if(Arguments.Num() > 0)
	{
		if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
		{
			if(!Actor->IsEditorOnly())
			{
				for(auto Comp : Actor->GetComponents())
				{
					auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
					if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
					{
						for(auto ArgumentKV : Arguments)
						{
							auto ComponentName = ArgumentKV.Key;
							bool CastShadow = ArgumentKV.Value == TEXT("true") ? true : false;
							if(ComponentName == StaticMeshComp->GetName())
							{
								StaticMeshComp->CastShadow = CastShadow;
								IsDirty = true;
							}
						}
					}
				}
			}
			

			if(IsDirty)
			{
				Actor->Modify();
				bSuccess = Actor->GetPackage()->MarkPackageDirty();
			}
		}
	}
	
	return bSuccess;
}

bool UStaticMeshComponentRule::RepairNantie(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	bool IsDirty = false;
	bool bSuccess = false;
	if(Arguments.Num() > 0)
	{
		if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
		{
			if(!Actor->IsEditorOnly())
			{
				for(auto Comp : Actor->GetComponents())
				{
					auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
					if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
					{
						for(auto ArgumentKV : Arguments)
						{
							auto ComponentName = ArgumentKV.Key;
							bool bDisallowNanite = ArgumentKV.Value == TEXT("true") ? true : false;
							if(ComponentName == StaticMeshComp->GetName())
							{
								StaticMeshComp->bDisallowNanite = bDisallowNanite;
								IsDirty = true;
							}
						}
					}
				}
			}
			

			if(IsDirty)
			{
				Actor->Modify();
				bSuccess = Actor->GetPackage()->MarkPackageDirty();
			}
		}
	}
	
	return bSuccess;
}

bool UStaticMeshComponentRule::RepairDrawInMainPass(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	bool IsDirty = false;
	bool bSuccess = false;

	if(Arguments.Num() > 0)
	{
		if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
				{
					for(auto ArgumentKV : Arguments)
					{
						auto ComponentName = ArgumentKV.Key;
						UEnum* EnumPtr = StaticEnum<ERuntimeVirtualTextureMainPassType>();
						ERuntimeVirtualTextureMainPassType RuntimeVirtualTextureMainPassType = static_cast<ERuntimeVirtualTextureMainPassType>(EnumPtr->GetValueByNameString(ArgumentKV.Value));
						if(ComponentName == StaticMeshComp->GetName())
						{
							StaticMeshComp->VirtualTextureRenderPassType = RuntimeVirtualTextureMainPassType;
							IsDirty = true;
						}
					}
				}
			}
				if(IsDirty)
				{
            		Actor->Modify();
            		bSuccess = Actor->GetPackage()->MarkPackageDirty();
            	}
		}
	}

	return bSuccess;
}

bool UStaticMeshComponentRule::RepairTranslucencySortPriority(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	bool IsDirty = false;
	bool bSuccess = false;

	if(Arguments.Num() > 0)
	{
		if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
				{
					for(auto ArgumentKV : Arguments)
					{
						auto ComponentName = ArgumentKV.Key;
						if(ComponentName == StaticMeshComp->GetName())
						{
							StaticMeshComp->TranslucencySortPriority = FCString::Atoi(*ArgumentKV.Value);
							IsDirty = true;
						}
					}
				}
			}
			if(IsDirty)
			{
				Actor->Modify();
				bSuccess = Actor->GetPackage()->MarkPackageDirty();
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::CheckComponentRuntimeVirtualTextureVolume(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = false;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if (UWorld* World = Actor->GetWorld())
		{

			TArray<AActor*> FoundActors;
			UGameplayStatics::GetAllActorsOfClass(World->GetWorld(), ARuntimeVirtualTextureVolume::StaticClass(), FoundActors);
			
			TArray<TObjectPtr<URuntimeVirtualTexture>> FoundRVTextures;
			for(auto FoundActor : FoundActors)
			{
				if(auto RVTV = Cast<ARuntimeVirtualTextureVolume>(FoundActor))
				{
					if(auto RVTVC = RVTV->VirtualTextureComponent)
					{
						if (RVTVC->GetVirtualTexture())
						{
							FoundRVTextures.Add(RVTVC->GetVirtualTexture());
						}
					}
				}
			}
			
			for(auto Comp : Actor->GetComponents())
			{
				int32 AcceptChecks = 0;
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
				{
					if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
					{
						for(auto RVT : StaticMeshComp->RuntimeVirtualTextures)
						{
							if(FoundRVTextures.Contains(RVT))
							{
								AcceptChecks += 1;
							}
						}
						if(FoundRVTextures.Num() == 0 && StaticMeshComp->RuntimeVirtualTextures.Num() != 0)
						{
							Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
								TEXT("没有RuntimeVirtualTextureVolume的情况下，{}的RuntimeVirtualTextures必须为空"),
								StaticMeshComp->GetName());
							OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) =  TEXT("Clear");
							bSuccess = false; 
						}
						if(FoundRVTextures.Num() > 0 && StaticMeshComp->RuntimeVirtualTextures.Num() > 1)
						{
							Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
								TEXT("有RuntimeVirtualTextureVolume的情况下，{}的RuntimeVirtualTextures的数量需要小于2"),
								StaticMeshComp->GetName());
							OutRepairParams.FindOrAdd(StaticMeshComp->GetName()) = TEXT("Same");
							bSuccess = false; 
						}
						
						if(FoundRVTextures.Num() > 0 && StaticMeshComp->RuntimeVirtualTextures.Num() > 0 && (
							FoundRVTextures.Num() != StaticMeshComp->RuntimeVirtualTextures.Num() ||
							FoundRVTextures.Num() != AcceptChecks))
						{
							Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
								TEXT("有RuntimeVirtualTextureVolume的情况下，{}的RuntimeVirtualTextures需要和RuntimeVirtualTextureVolume相同"),
								StaticMeshComp->GetName());
							OutRepairParams.FindOrAdd( StaticMeshComp->GetName()) = TEXT("Same");
							bSuccess = false; 
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::RepairRuntimeVirtualTextureVolume(const FAssetData& AssetData, const TMap<FString, FString>& Arguments)
{
	bool bSuccess = false;
	bool IsDirty = false;
	if(Arguments.Num() > 0)
	{
		if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
		{
			if (UWorld* World = Actor->GetWorld())
			{							
				TArray<AActor*> FoundActors;
				UGameplayStatics::GetAllActorsOfClass(World->GetWorld(), ARuntimeVirtualTextureVolume::StaticClass(), FoundActors);
			
				TArray<TObjectPtr<URuntimeVirtualTexture>> FoundRVTextures;
				for(auto FoundActor : FoundActors)
				{
					if(auto RVTV = Cast<ARuntimeVirtualTextureVolume>(FoundActor))
					{
						if(auto RVTVC = RVTV->VirtualTextureComponent)
						{
							if (RVTVC->GetVirtualTexture())
							{
								FoundRVTextures.Add(RVTVC->GetVirtualTexture());
							}
						}
					}
				}
				for(auto Comp : Actor->GetComponents())
				{
					auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
					if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
					{
						for(auto ArgumentKV : Arguments)
						{
							FString ArgumentKey = ArgumentKV.Key;
							FString ArgumentValue = ArgumentKV.Value;
							if (ArgumentKey == StaticMeshComp->GetName())
							{
								if (ArgumentValue == TEXT("Clear"))
								{
									StaticMeshComp->RuntimeVirtualTextures.Empty();
									IsDirty = true;
								}
								else if (ArgumentValue == TEXT("Same"))
								{
									StaticMeshComp->RuntimeVirtualTextures.Empty();
									StaticMeshComp->RuntimeVirtualTextures.Append(FoundRVTextures);
									IsDirty = true;
								}
							}
						}
					}
				}				
			}
			if (IsDirty)
			{					
				Actor->Modify();
				bSuccess = Actor->GetPackage()->MarkPackageDirty();
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::RepairComponentMobility(const FAssetData& AssetData,const TMap<FString, FString>& Arguments)
{
	bool IsDirty = false;
	bool bSuccess = false;

	if(Arguments.Num() > 0)
	{
		if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
				{
					for(auto ArgumentKV : Arguments)
					{
						auto ComponentName = ArgumentKV.Key;
						if(ComponentName == StaticMeshComp->GetName())
						{
							StaticMeshComp->Mobility = EComponentMobility::Static;
							IsDirty = true;
						}
					}
				}
			}
			if(IsDirty)
			{
				Actor->Modify();
				bSuccess = Actor->GetPackage()->MarkPackageDirty();
			}
		}
	}
	return bSuccess;
}

bool UStaticMeshComponentRule::CheckForbiddenMaterial(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if(AActor* Actor = Cast<AActor>(AssetData.GetAsset()))
	{
		if(!Actor->IsEditorOnly())
		{
			for(auto Comp : Actor->GetComponents())
			{
				auto StaticMeshComp = Cast<UStaticMeshComponent>(Comp);
				if(StaticMeshComp && StaticMeshComp->GetStaticMesh())
				{
					int32 NumMaterials = StaticMeshComp->GetNumMaterials();
    
					for (int32 i = 0; i < NumMaterials; i++)
					{
						// 获取当前材质索引的材质
						UMaterialInterface* MaterialInterface = StaticMeshComp->GetMaterial(i);
        
						if (!MaterialInterface)
						{
							// 尝试从静态网格获取默认材质
							MaterialInterface = StaticMeshComp->GetStaticMesh()->GetMaterial(i);
						}
        
						if (MaterialInterface)
						{
							// 递归检查材质
							FString MaterialName;
							if (CheckMaterialRecursive(MaterialInterface, ForbiddenMaterialNames, MaterialName))
							{
								Log.RegistryAndLog(AssetData, TEXT("World"), CheckRuleType,
									TEXT("{}: {}有禁止使用的材质{}"),
									Actor->GetName(),
									StaticMeshComp->GetName(),
									MaterialName);
								bSuccess = false; 
							}
						}
					}
				}
			}
		}
	}
	return bSuccess;
}

FString UStaticMeshComponentRule::IsMainSkyPerformerActor(const FAssetData& AssetData)
{
	if(Cast<AMainSkyPerformer>(AssetData.GetAsset()))
	{
		return "1";
	}
	return "0";
}

bool UStaticMeshComponentRule::CheckMaterialRecursive(UMaterialInterface* MaterialInterface, const TArray<FString>& MaterialNames, FString& OutMaterialName)
{
	if (!MaterialInterface)
	{
		return false;
	}
    
	// 获取材质名称（不包含路径）
	FString MaterialName = MaterialInterface->GetName();
    
	// 检查是否匹配目标材质名称
	for (const FString& TargetName : MaterialNames)
	{
		if (MaterialName.Equals(TargetName))
		{
			OutMaterialName = MaterialName;
			return true;
		}
	}
    
	// 如果是材质实例，检查其父材质
	if (UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>(MaterialInterface))
	{
		UMaterialInterface* ParentMaterial = MaterialInstance->Parent;
		if (ParentMaterial)
		{
			return CheckMaterialRecursive(ParentMaterial, MaterialNames, OutMaterialName);
		}
	}
    
	return false;
}
