#include "ResourceCheck/RuleFunctions/Misc/RedirectorRule.h"

UClass* URedirectorRule::GetAssetType()
{
	return UObjectRedirector::StaticClass();
}

bool URedirectorRule::CheckRedirector(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("这是个重定向器，需要先执行修复重定向器（fixup redirector）后，令其自我删除后，再提交相关changelist"));
	return false;
}