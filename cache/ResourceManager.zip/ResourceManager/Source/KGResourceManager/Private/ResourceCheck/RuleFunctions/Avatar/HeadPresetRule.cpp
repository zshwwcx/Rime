// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/RuleFunctions/Avatar/HeadPresetRule.h"
#include "Asset/AvatarPresetBase.h"

UClass* UHeadPresetRule::GetAssetType()
{
	return UHeadPreset::StaticClass();
}