#include "ResourceCheck/RuleFunctions/Blueprint/BlueprintActorAssetMobilityRule.h"

#include "Engine/InheritableComponentHandler.h"
#include "Engine/SCS_Node.h"
#include "Engine/SimpleConstructionScript.h"

UClass* UBlueprintActorAssetMobilityRule::GetAssetType()
{
	return UBlueprint::StaticClass();
}

bool UBlueprintActorAssetMobilityRule::PreExecuteAsset(const FAssetData& AssetData)
{
	const UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset());
	if (Blueprint == nullptr)
	{
		return false;
	}
	if (!Blueprint->ParentClass->IsChildOf(AActor::StaticClass()))
	{
		return false;
	}
	return true;
}

bool UBlueprintActorAssetMobilityRule::CheckSubComponentMobility(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset());
	if (Blueprint == nullptr)
	{
		return true;
	}
	if (!Blueprint->ParentClass->IsChildOf(AActor::StaticClass()))
	{
		return true;
	}
	const USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript;
	if (SCS == nullptr)
	{
		return true;
	}
	TSet<USceneComponent*> NeedCheckComponents;
	const USCS_Node* DefaultSceneRootNode = SCS->GetDefaultSceneRootNode();
	if (SCS->GetRootNodes().Contains(DefaultSceneRootNode))
	{
		auto GetAllChildNodes = [](const USCS_Node* Node)
		{
			TArray<const USCS_Node*> AllNodes;
			TArray<const USCS_Node*> Nodes;
			Nodes.Add(Node);
			while (Nodes.Num() > 0)
			{
				const USCS_Node* N = Nodes.Pop();
				if (N == nullptr)
				{
					continue;
				}
				AllNodes.Add(N);
				Nodes.Append(N->GetChildNodes());
			}
			return AllNodes;
		};
		const USceneComponent* RootComponent = SCS->GetSceneRootComponentTemplate();
		if (RootComponent == nullptr || RootComponent->Mobility != EComponentMobility::Movable)
		{
			return true;
		}
		for (const USCS_Node* Node : GetAllChildNodes(DefaultSceneRootNode))
		{
			if (Node == nullptr)
			{
				continue;
			}
			if (USceneComponent* SceneComponent = Cast<USceneComponent>(Node->ComponentTemplate))
			{
				NeedCheckComponents.Add(SceneComponent);
			}
		}
	}
	else
	{
		USCS_Node* OutSCSNode;
		const USceneComponent* RootComponent = SCS->GetSceneRootComponentTemplate(false, &OutSCSNode);
		if (UInheritableComponentHandler* InheritableComponentHandler = Blueprint->GetInheritableComponentHandler(false))
		{
			if (OutSCSNode != nullptr)
			{
				const FComponentKey Key(OutSCSNode);
				const UActorComponent* OverridenComponentTemplate = InheritableComponentHandler->GetOverridenComponentTemplate(Key);
				if (OverridenComponentTemplate != nullptr)
				{
					RootComponent = Cast<USceneComponent>(OverridenComponentTemplate);
				}
			}
			TArray<UActorComponent*> AllTemplates;
			InheritableComponentHandler->GetAllTemplates(AllTemplates);
			for (UActorComponent* ComponentTemplate : AllTemplates)
			{
				if (USceneComponent* SceneComponent = Cast<USceneComponent>(ComponentTemplate))
				{
					NeedCheckComponents.Add(SceneComponent);
				}
			}
		}
		if (RootComponent == nullptr || RootComponent->Mobility != EComponentMobility::Movable)
		{
			return true;
		}
		for (const USCS_Node* Node : SCS->GetAllNodes())
		{
			if (Node == nullptr)
			{
				continue;
			}
			if (USceneComponent* SceneComponent = Cast<USceneComponent>(Node->ComponentTemplate))
			{
				NeedCheckComponents.Add(SceneComponent);
			}
		}
	}
	for (const USceneComponent* Component : NeedCheckComponents)
	{
		if (Component->Mobility != EComponentMobility::Movable)
		{
			Log.RegistryAndLog(AssetData, TEXT("Blueprint"), CheckRuleType, TEXT("蓝图类根节点移动性为movable时，其子节点:{}也需要是movable"), Component->GetName());
			bSuccess = false;
		}
	}
	return bSuccess;
}


