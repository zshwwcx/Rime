#include "ResourceCheck/RuleFunctions/Texture/TextureAssetRuleBase.h"

#include "TextureCompiler.h"
#include "Curves/CurveLinearColorAtlas.h"
#include "EditorFramework/AssetImportData.h"
#include "Engine/TextureCube.h"
#include "Internationalization/Regex.h"

UClass* UTextureAssetRuleBase::GetAssetType()
{
	return UTexture::StaticClass();
}


bool UTextureAssetRuleBase::PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
{
	TMap<FString, FString> CompressionSettingDatas;
	CompressionSettingDatas = Params.GetValueMap("CompressionSettingDatas");
	for(auto CompressionSettingData : CompressionSettingDatas)
	{
		FString DataKey = CompressionSettingData.Key;
		TArray<FString> Values;
		CompressionSettingData.Value.ParseIntoArray(Values, TEXT(","));
		for(auto Value : Values)
		{
			TextureCompressionSettings InSetting = static_cast<TextureCompressionSettings>(StaticEnum<TextureCompressionSettings>()->GetValueByName(FName(Value)));
			CompressionSettingsEnum.FindOrAdd(DataKey).Add(InSetting);
		}
	}
	TMap<FString, FString> HighCompressionSettings;
	HighCompressionSettings = Params.GetValueMap("HighCompressionSettings");
	for(auto HighCompressionSetting : HighCompressionSettings)
	{
		FString DataKey = HighCompressionSetting.Key;
		TextureCompressionSettings InSetting = static_cast<TextureCompressionSettings>(StaticEnum<TextureCompressionSettings>()->GetValueByName(FName(HighCompressionSetting.Value)));
		HighCompressionSettingsEnum.FindOrAdd(DataKey) = InSetting;
	}
	UITextureImportPath = Params.GetValueList("UITextureImportPath");

	HighPrecisionGroupWhiteList.Empty();
	FString TextureRuleCharacterIniPath = FConfigCacheIni::NormalizeConfigIniPath(FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("KGResourceManager/Config/TextureRuleCharacter.ini")));
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (PlatformFile.FileExists(*TextureRuleCharacterIniPath))
	{
		GConfig->Flush(true, *TextureRuleCharacterIniPath);
		GConfig->GetArray(TEXT("HighPrecisionGroupWhiteList"), TEXT("TexturePaths"), HighPrecisionGroupWhiteList, TextureRuleCharacterIniPath);
	}
	
	return true;
}

bool UTextureAssetRuleBase::PreExecuteAsset(const FAssetData& InAssetData)
{
	if(InAssetData.GetClass()->IsChildOf(UCurveLinearColorAtlas::StaticClass()))
	{
		return false;
	}
	return true;
}


FString UTextureAssetRuleBase::GetMaxInGameSize(const FAssetData& AssetData)
{
	UTexture* Texture = Cast<UTexture>(AssetData.GetAsset());
	if (Texture == nullptr)
	{
		return TEXT("1,1");
	}
	FTextureCompilingManager::Get().FinishCompilation({Texture});

	int32 MaxInGameWidth = Texture->Source.GetSizeX();
	int32 MaxInGameHeight = Texture->Source.GetSizeY();
	if (Texture->MaxTextureSize > 0)
	{
		MaxInGameWidth = FMath::Min(MaxInGameWidth, Texture->MaxTextureSize);
		MaxInGameHeight = FMath::Min(MaxInGameHeight, Texture->MaxTextureSize);
	}

	const int32 LODBias = Texture->GetCachedLODBias();

	MaxInGameWidth = MaxInGameWidth >> LODBias;
	MaxInGameHeight = MaxInGameHeight >> LODBias;

	TArray<FString> ReStr;
	ReStr.Add(FString::FromInt(MaxInGameWidth));
	ReStr.Add(FString::FromInt(MaxInGameHeight));

	return FString::Join(ReStr, TEXT(","));
}

bool UTextureAssetRuleBase::RepairMaxInGame(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	if (UTexture2D* Texture2D = Cast<UTexture2D>(AssetData.GetAsset()))
	{
		if (OutRepairParams.Contains(TEXT("GetMaxInGameSize")))
		{
			int32 MaxInGameSize = FCString::Atoi(*OutRepairParams["GetMaxInGameSize"]);
			Texture2D->MaxTextureSize = MaxInGameSize;
			return true;
		}
	}
	return false;
}

FString UTextureAssetRuleBase::GetImportedSize(const FAssetData& AssetData)
{
	int32 X = 0, Y = 0;
	if (auto Texture = Cast<UTexture>(AssetData.GetAsset()))
	{
		const int32 SurfaceX = static_cast<int32>(Texture->GetSurfaceWidth());
		const int32 SurfaceY = static_cast<int32>(Texture->GetSurfaceHeight());

		X = Texture->Source.IsValid() ? Texture->Source.GetSizeX() : SurfaceX;
		Y = Texture->Source.IsValid() ? Texture->Source.GetSizeY() : SurfaceY;

	}
	
	TArray<FString> ReStr;
	ReStr.Add(FString::FromInt(X));
	ReStr.Add(FString::FromInt(Y));

	return FString::Join(ReStr, TEXT(","));
}

bool UTextureAssetRuleBase::ImportPathInfixCheck(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams)
{
	if(UTexture* Texture = Cast<UTexture>(AssetData.GetAsset()))
	{		
		auto SourceFiles = Texture->AssetImportData->SourceData.SourceFiles;
		if(SourceFiles.Num() > 0)
		{
			for(auto ImportPath : UITextureImportPath)
			{
				if(SourceFiles[0].RelativeFilename.Contains(ImportPath))
				{
					return true;
				}
			}
		}
		else
		{
			// SourceFiles 为空默认通过检查，如 RenderTarget
			return true;
		}
	}
	FString UITextureParam = Params.GetValue("UITextureImportPath");
	Log.RegistryAndLog(AssetData, TEXT("Texture"), CheckRuleType, TEXT("导入路径必须包含关键词:{}"), UITextureParam);
	return false;
}

FString UTextureAssetRuleBase::GetCompressionSettingStandard(const FAssetData& AssetData)
{
					
	auto Tex = Cast<UTexture>(AssetData.GetAsset());
	FString NameEnding = GetNameEnding(AssetData);
	FString RetVal;
	bool SpecialTag = false;
	if(Tex)
	{
		for (int32 i = 0; i < Tex->AssetEditorTags.Num(); ++i)
		{
			if (Tex->AssetEditorTags[i].ToString().ToLower() == "high")
			{
				SpecialTag = true;
				break;
			}
		}
	}
	if(!CompressionSettingsEnum.Contains(NameEnding) && CompressionSettingsEnum.Contains("All"))
	{
		NameEnding = "All";
	}
	if(!CompressionSettingsEnum.Contains(NameEnding))
	{
		return "None";
	}
	auto TempCompressionSettingsArray = CompressionSettingsEnum[NameEnding];
	if(SpecialTag)
	{
		if(HighCompressionSettingsEnum.Contains(NameEnding))
		{
			TempCompressionSettingsArray.FindOrAdd(HighCompressionSettingsEnum[NameEnding]);
		}
	}
	for(auto CompressionSetting:TempCompressionSettingsArray)
	{
		if (UEnum* EnumPtr = StaticEnum<TextureCompressionSettings>())
		{
			// 获取枚举值的名称
			RetVal += EnumPtr->GetNameByValue(CompressionSetting.GetValue()).ToString() + ",";
		}
	}
	return RetVal;
}

FString UTextureAssetRuleBase::CheckRegexFaceOld(const FAssetData& AssetData)
{
	FRegexPattern Pattern(TEXT("T_[a-zA-Z]_FaceOld_\\d{2,3}_N"));
	FRegexMatcher Matcher(Pattern, AssetData.PackageName.ToString());

	if(Matcher.FindNext())
	{
		return "1";
	}
	return "0";
}

FString UTextureAssetRuleBase::IsTextureCube(const FAssetData& AssetData)
{
	const UClass* AssetClass = AssetData.GetClass();
	if (!AssetClass)
	{
		AssetClass = LoadObject<UClass>(nullptr, *AssetData.AssetClassPath.ToString());
	}
	if (!AssetClass || !AssetClass->IsChildOf(UTextureCube::StaticClass()))
	{
		return "0";
	}
	return "1";
}

FString UTextureAssetRuleBase::IsInHighPrecisionGroupWhiteList(const FAssetData& AssetData)
{
	if (HighPrecisionGroupWhiteList.Contains(AssetData.PackageName))
	{
		return "1";
	}
	return "0";
}
