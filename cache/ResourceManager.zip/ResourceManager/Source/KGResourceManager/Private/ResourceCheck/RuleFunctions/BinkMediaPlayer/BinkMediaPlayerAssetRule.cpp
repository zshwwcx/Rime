#include "ResourceCheck/RuleFunctions/BinkMediaPlayer/BinkMediaPlayerAssetRule.h"
#include "BinkMediaPlayer.h"

UClass* UBinkMediaPlayerAssetRule::GetAssetType()
{
	return UBinkMediaPlayer::StaticClass();
}

bool UBinkMediaPlayerAssetRule::CheckBinkMediaPlayer(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	Log.RegistryAndLog(AssetData, TEXT("BinkMediaPlayer"), CheckRuleType, TEXT("BinkMediaPlayer出现在非/Game/Movies/的目录中"));
	return false;
}