// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/RuleFunctions/Avatar/HairPresetRule.h"
#include "Asset/AvatarPresetBase.h"
#include "Asset/DressProfile.h"

UClass* UHairPresetRule::GetAssetType()
{
	return UHairPreset::StaticClass();
}

bool UHairPresetRule::CheckHairSlotName(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams)
{
	bool bSuccess = true;
	if (auto HairPreset = Cast<UHairPreset>(AssetData.GetAsset()))
	{
		if (HairPreset->DressInstance)
		{
			for (const FDressProperty& DressProperty : HairPreset->DressInstance->DressProperties)
			{
				if (DressProperty.BodyPartType == EAvatarBodyPartType::Hair && DressProperty.MeshPart)
				{
					if (USkeletalMesh* SkeletalMesh = DressProperty.MeshPart->GetSkeletalMesh())
					{
						const TArray<FSkeletalMaterial>& Materials = SkeletalMesh->GetMaterials();
						bool bFindHairSlot = false;
						for (const FSkeletalMaterial& Material : Materials)
						{
							if (Material.MaterialSlotName == "Hair")
							{
								bFindHairSlot = true;
								break;
							}
						}
						if (!bFindHairSlot)
						{
							Log.RegistryAndLog(AssetData, GetRuleName(), CheckRuleType, TEXT("HairPreset 引用的Skeletal Mesh的材质插槽名需要有 Hair"));
							bSuccess = false;
						}
					}
				}
			}
		}
	}
	return bSuccess;
}
