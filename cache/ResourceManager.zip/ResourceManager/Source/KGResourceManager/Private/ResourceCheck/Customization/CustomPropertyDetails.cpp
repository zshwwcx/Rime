// Copyright Kuaishou, Inc. All Rights Reserved.

#include "ResourceCheck/Customization/CustomPropertyDetails.h"
#include "ResourceCheck/RuleBase.h"
#include "DetailWidgetRow.h"
#include "IDetailChildrenBuilder.h"
#include "DetailLayoutBuilder.h"
#include "DetailCategoryBuilder.h"

#define LOCTEXT_NAMESPACE "KCustomPropertyDetails"

void FCustomPropertyDetails::CustomizeHeader(TSharedRef<class IPropertyHandle> StructPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	PropertyNameHandle = StructPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FRMPropertyRuleMapping, PropertyName));
	PropertyGetterFuncHandle = StructPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FRMPropertyRuleMapping, PropertyGetterFunc));
	StandardParamHandle = StructPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FRMPropertyRuleMapping, StandardParam));
	StandardValueHandle = StructPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FRMPropertyRuleMapping, StandardValue));
	StandardValueGetterFuncHandle = StructPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FRMPropertyRuleMapping, StandardValueGetterFunc));
	
}

TSharedRef<SWidget> FCustomPropertyDetails::HandleGenerateWidgetForPropertyNamesComboBox(TSharedPtr<FString> Item) const
{
	FString StringItem = Item.IsValid() ? *Item : FString();

	// If a row wasn't generated just create the default one, a simple text block of the item's name.
	return SNew(STextBlock)
		.Text(FText::FromString(StringItem));
}

void FCustomPropertyDetails::ChangePropertyAndStandardType()
{
	FString PropertyFunctionValue;
	PropertyGetterFuncHandle->GetValueAsFormattedString(PropertyFunctionValue);

	FString PropertyNameValue;
	PropertyNameHandle->GetValueAsFormattedString(PropertyNameValue);
	if(PropertyFunctionValue != "None")
	{
		NowPropertyTypeText->SetText(FText::FromString(TEXT("使用属性值获取函数 : ") + PropertyFunctionValue));
	}
	else
	{
		NowPropertyTypeText->SetText(FText::FromString(TEXT("使用属性名 : ") + PropertyNameValue));
	}

	FString StandardFunctionValue;
	StandardValueGetterFuncHandle->GetValueAsFormattedString(StandardFunctionValue);

	FString StandardParamValue;
	StandardParamHandle->GetValueAsFormattedString(StandardParamValue);

	FString StandardConstValue;
	StandardValueHandle->GetValueAsFormattedString(StandardConstValue);
	
	if(StandardFunctionValue != "None")
	{
		NowStandardTypeText->SetText(FText::FromString(TEXT("使用合法值获取函数 : ") + StandardFunctionValue));
	}
	else if (StandardParamValue != "")
	{
		NowStandardTypeText->SetText(FText::FromString(TEXT("使用合法值参数 : ") + StandardParamValue));
	}
	else
	{
		NowStandardTypeText->SetText(FText::FromString(TEXT("使用合法值常量 : ") + StandardConstValue));
	}
}


void FCustomPropertyDetails::OnPropertyValueChanged()
{
	if (CurrentPropertyHandle.IsValid())
	{
		FString Value;
		CurrentPropertyHandle->GetValueAsFormattedString(Value);
		StandardValueHandle->SetValueFromFormattedString(Value);
		ChangePropertyAndStandardType();
	}
}

void FCustomPropertyDetails::HandleSelectionChangedForPropertyNamesComboBox(TSharedPtr<FString> Item, ESelectInfo::Type SelectionType)
{
	TSharedPtr<FString> StringItem = AllPropertySelector->GetSelectedItem();
	if (StringItem.IsValid())
	{
		// change property name
		TSharedRef<SWidget> ComboContentText = SNew(STextBlock).Text(FText::FromString(*StringItem.Get()));
		PropertyNameComboContent->SetContent(ComboContentText);
		PropertyNameHandle->SetValue(*StringItem.Get());
	}

	if (AssetCLass.IsValid() && StringItem.IsValid())
	{
		// change property value
		FProperty* PropertyIns = NULL;
		for (TFieldIterator<FProperty> PropertyIter(AssetCLass.Get()); PropertyIter; ++PropertyIter)
		{
			if (PropertyIter->GetName().Equals(*StringItem.Get()) &&
					PropertyIter->GetCPPType() != TEXT("TArray") &&
					PropertyIter->GetCPPType() != TEXT("TSet") &&
					PropertyIter->GetCPPType() != TEXT("TMap")
					)
			{
				PropertyIns = *PropertyIter;
			}
		}
		if (PropertyIns)
		{
			FString PropertyName = *StringItem.Get();
			IDetailPropertyRow* PropertyRow = PropertyDetailBuilder->AddExternalStructureProperty(MakeShareable(new FStructOnScope(Cast<UStruct>(AssetCLass.Get()))), *PropertyName);

			//// reset Property value to default
			//if (OldPropertyRow || !PropertyRow)
			//{
			//	PropertyValueHandle->SetValueFromFormattedString(TEXT(""));
			//}

			TSharedRef<SWidget> Widget = StandardValueHandle->CreatePropertyValueWidget();
			if (PropertyRow)
			{
				//OldPropertyRow = CurrentPropertyRow;
				CurrentPropertyHandle = PropertyRow->GetPropertyHandle();
				PropertyRow->Visibility(EVisibility::Hidden);
				FSimpleDelegate OnPropertyValueChanged = FSimpleDelegate::CreateSP(this, &FCustomPropertyDetails::OnPropertyValueChanged);
				PropertyRow->GetPropertyHandle()->SetOnPropertyValueChanged(OnPropertyValueChanged);

				FString ExistValue;
				StandardValueHandle->GetValueAsFormattedString(ExistValue);
				PropertyRow->GetPropertyHandle()->SetValueFromFormattedString(ExistValue);

				Widget = PropertyRow->GetPropertyHandle()->CreatePropertyValueWidget();
			}

			StandardValueContent->SetContent(Widget);
		}
		else
		{
			TSharedRef<SWidget> Widget = StandardValueHandle->CreatePropertyValueWidget();
			StandardValueContent->SetContent(Widget);
		}
	}
}

void FCustomPropertyDetails::HandleSelectionChangedForPropertyGetterFuncNameComboBox(TSharedPtr<FString> Item,
	ESelectInfo::Type SelectionType)
{
	TSharedPtr<FString> StringItem = Item;
	if (StringItem.IsValid())
	{
		// change property name
		TSharedRef<SWidget> ComboContentText = SNew(STextBlock).Text(FText::FromString(*StringItem.Get()));
		PropertyFuncNameComboContent->SetContent(ComboContentText);
		PropertyGetterFuncHandle->SetValue(*StringItem.Get());
	}
}

void FCustomPropertyDetails::HandleSelectionChangedForStandardGetterFuncNameComboBox(TSharedPtr<FString> Item,
	ESelectInfo::Type SelectionType)
{
	TSharedPtr<FString> StringItem = Item;
	if (StringItem.IsValid())
	{
		// change property name
		TSharedRef<SWidget> ComboContentText = SNew(STextBlock).Text(FText::FromString(*StringItem.Get()));
		StandardFuncNameComboContent->SetContent(ComboContentText);
		StandardValueGetterFuncHandle->SetValue(*StringItem.Get());
	}
}

bool IsUObjectParamAndFStringReturnFunction(UFunction* Function)
{
	// 检查返回值类型
	if (Function->ReturnValueOffset != MAX_uint16)
	{
		FProperty* ReturnValue = Function->GetReturnProperty();
		if (ReturnValue->GetCPPType() != TEXT("FString"))
		{
			return false;
		}
	}
	else
	{
		return false; // 返回值必须是FString
	}

	// 检查参数类型
	for (TFieldIterator<FProperty> ParamIt(Function); ParamIt && (ParamIt->PropertyFlags & CPF_Parm); ++ParamIt)
	{
		FProperty* Param = *ParamIt;
		if(Param->GetName()=="ReturnValue")
		{
			continue;
		}
		if(Param->GetCPPType() != "FAssetData")
		{
			return false;
		}
	}

	return true;
}

void FCustomPropertyDetails::CustomizeChildren(TSharedRef<class IPropertyHandle> StructPropertyHandle, IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	PropertyDetailBuilder = &StructBuilder;
	IDetailCategoryBuilder& ParentCategory = StructBuilder.GetParentCategory();
	IDetailLayoutBuilder& ParentLayout = ParentCategory.GetParentLayout();
	TSubclassOf<URuleBase> ActionPrefabRule = ParentLayout.GetBaseClass();
	if (ActionPrefabRule)
	{
		AssetCLass = ActionPrefabRule->GetDefaultObject<URuleBase>()->GetAssetType();
	}

	if (AssetCLass.IsValid())
	{
		FSimpleDelegate OnPropertyValueChanged = FSimpleDelegate::CreateSP(this, &FCustomPropertyDetails::ChangePropertyAndStandardType);
		StandardValueHandle->SetOnPropertyValueChanged(OnPropertyValueChanged);
		// 1. property name selector
		StructBuilder.AddCustomRow(FText::FromString(TEXT("PropertyName")))
			.NameContent()
			[
				PropertyNameHandle->CreatePropertyNameWidget()
			]
			.ValueContent()
			[
				SAssignNew(AllPropertySelectorBox, SBox)
			];

		// get all property to fill the property selector
		for (TFieldIterator<FProperty> PropertyIter(AssetCLass.Get()); PropertyIter; ++PropertyIter)
		{
			FProperty* PropertyIns = *PropertyIter;
			AllPropertyNames.Add(MakeShareable(new FString(PropertyIns->GetName())));
		}
		AllPropertyNames.Add(MakeShareable(new FString("Customized")));
		AllPropertyNames.Sort([](const TSharedPtr<FString>& A, const TSharedPtr<FString>& B) {
			return *A < *B;
		});

		TSharedPtr<SWidget> Widget;
		SAssignNew(AllPropertySelector, SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&AllPropertyNames)
			.OnGenerateWidget(SComboBox<TSharedPtr<FString>>::FOnGenerateWidget::CreateRaw(this, &FCustomPropertyDetails::HandleGenerateWidgetForPropertyNamesComboBox))
			.OnSelectionChanged(SComboBox< TSharedPtr<FString> >::FOnSelectionChanged::CreateRaw(this, &FCustomPropertyDetails::HandleSelectionChangedForPropertyNamesComboBox))
			[
				SAssignNew(PropertyNameComboContent, SBox)
			];
		if (AllPropertyNames.Num())
		{
			FString PropertyName;
			PropertyNameHandle->GetValue(PropertyName);
			if (PropertyName.IsEmpty())
			{
				PropertyName = "Customized";
			}
			PropertyNameComboContent->SetContent(SNew(STextBlock).Text(FText::FromString(PropertyName)));
			Widget = AllPropertySelector;
			AllPropertySelectorBox->SetContent(Widget.ToSharedRef());
		}
		PropertyNameHandle->SetOnPropertyValueChanged(OnPropertyValueChanged);
		// 2. Property value getter func box
		StructBuilder.AddCustomRow(FText::FromString(TEXT("PropertyGetterFunc")))
			.NameContent()
			[
				PropertyGetterFuncHandle->CreatePropertyNameWidget()
			]
			.ValueContent()
			[
				SAssignNew(AllFuncSelectorBox, SBox)
			];

		// get all property to fill the property selector
		for (TFieldIterator<UFunction> FuncIter(ActionPrefabRule); FuncIter; ++FuncIter)
		{
			UFunction* Function = *FuncIter;
			if(IsUObjectParamAndFStringReturnFunction(Function))
			{
				AllFuncNames.Add(MakeShareable(new FString(Function->GetName())));
			}
		}
		AllFuncNames.Add(MakeShareable(new FString("None")));
		AllFuncNames.Sort([](const TSharedPtr<FString>& A, const TSharedPtr<FString>& B) {
			return *A < *B;
		});

		TSharedPtr<SWidget> FuncWidget;
		SAssignNew(AllFuncSelector, SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&AllFuncNames)
			.OnGenerateWidget(SComboBox<TSharedPtr<FString>>::FOnGenerateWidget::CreateRaw(this, &FCustomPropertyDetails::HandleGenerateWidgetForPropertyNamesComboBox))
			.OnSelectionChanged(SComboBox< TSharedPtr<FString> >::FOnSelectionChanged::CreateRaw(this, &FCustomPropertyDetails::HandleSelectionChangedForPropertyGetterFuncNameComboBox))
			[
				SAssignNew(PropertyFuncNameComboContent, SBox)
			];
		PropertyFuncNameComboContent->SetContent(SNew(STextBlock).Text(FText::FromString("None")));
		FuncWidget = AllFuncSelector;
		AllFuncSelectorBox->SetContent(FuncWidget.ToSharedRef());

		if (AllFuncNames.Num())
		{
			FString FuncName;
			PropertyGetterFuncHandle->GetValue(FuncName);
			if (FuncName.IsEmpty())
			{
				FuncName = "None";
			}
			AllFuncSelector->SetSelectedItem(MakeShareable(new FString(FuncName)));
			PropertyFuncNameComboContent->SetContent(SNew(STextBlock).Text(FText::FromString(FuncName)));
		}
		PropertyGetterFuncHandle->SetOnPropertyValueChanged(OnPropertyValueChanged);

		//Property Type
		StructBuilder.AddCustomRow(FText::FromString(TEXT("NowPropertyType")))
		.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("属性值的获取方式")))
		]
		.ValueContent()
		[
			SAssignNew(NowPropertyTypeText, STextBlock)
		];
		
		// 3, StandardValue
		StructBuilder.AddCustomRow(FText::FromString(TEXT("StandardValue")))
			.NameContent()
			[
				StandardValueHandle->CreatePropertyNameWidget()
			]
			.ValueContent()
			[
				SAssignNew(StandardValueContent, SBox)
			];
		StandardValueContent->SetContent(StandardValueHandle->CreatePropertyValueWidget());
		StandardValueHandle->SetOnPropertyValueChanged(OnPropertyValueChanged);
		// 4.StandardParam
    	StructBuilder.AddCustomRow(FText::FromString(TEXT("StandardParam")))
        	.NameContent()
        	[
        		StandardParamHandle->CreatePropertyNameWidget()
        	]
        	.ValueContent()
        	[
        		SAssignNew(StandardParamContent, SBox)
        	];
		StandardParamContent->SetContent(StandardParamHandle->CreatePropertyValueWidget());
		StandardParamHandle->SetOnPropertyValueChanged(OnPropertyValueChanged);
		// 5. Standard value getter func box
		StructBuilder.AddCustomRow(FText::FromString(TEXT("StandardGetterFunc")))
			.NameContent()
			[
				StandardValueGetterFuncHandle->CreatePropertyNameWidget()
			]
			.ValueContent()
			[
				SAssignNew(AllFuncSelectorBox, SBox)
			];

		TSharedPtr<SWidget> Func2Widget;
		SAssignNew(AllFuncSelector, SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&AllFuncNames)
			.OnGenerateWidget(SComboBox<TSharedPtr<FString>>::FOnGenerateWidget::CreateRaw(this, &FCustomPropertyDetails::HandleGenerateWidgetForPropertyNamesComboBox))
			.OnSelectionChanged(SComboBox< TSharedPtr<FString> >::FOnSelectionChanged::CreateRaw(this, &FCustomPropertyDetails::HandleSelectionChangedForStandardGetterFuncNameComboBox))
			[
				SAssignNew(StandardFuncNameComboContent, SBox)
			];
		StandardFuncNameComboContent->SetContent(SNew(STextBlock).Text(FText::FromString("None")));
		Func2Widget = AllFuncSelector;
		AllFuncSelectorBox->SetContent(Func2Widget.ToSharedRef());

		if (AllFuncNames.Num())
		{
			FString FuncName;
			StandardValueGetterFuncHandle->GetValue(FuncName);
			if (FuncName.IsEmpty())
			{
				FuncName = "None";
			}
			AllFuncSelector->SetSelectedItem(MakeShareable(new FString(FuncName)));
			StandardFuncNameComboContent->SetContent(SNew(STextBlock).Text(FText::FromString(FuncName)));
		}
		StandardValueGetterFuncHandle->SetOnPropertyValueChanged(OnPropertyValueChanged);
		
		//Standard Type
		StructBuilder.AddCustomRow(FText::FromString(TEXT("NowStandardType")))
		.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("合法值的获取方式")))
		]
		.ValueContent()
		[
			SAssignNew(NowStandardTypeText, STextBlock)
		];

		ChangePropertyAndStandardType();
	}
}

#undef LOCTEXT_NAMESPACE
