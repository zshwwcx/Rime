// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/Customization/ResourceManagerSingleWidget.h"
#include "Components/TextBlock.h"
#include "Components/MultiLineEditableText.h"
#include "ContentBrowserModule.h"
#include "IContentBrowserSingleton.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "Selection.h"
#include "Components/Button.h"
#include "ResourceCheck/ResourceCheckDataStruct.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"

void UResourceManagerSingleWidget::SetSelectedObj(const FResourceCheckLogInfo& InLogInfo)
{
	AssetPackageName = InLogInfo.AssetData.PackageName.ToString();
	if (UTextBlock* AssetText = Cast<UTextBlock>(GetWidgetFromName(FName(TEXT("AssetNameText")))))
	{
		AssetText->SetText(FText::FromString(InLogInfo.ResourcePath));
	}
}

void UResourceManagerSingleWidget::SetState(const FResourceCheckLogInfo& InLogInfo)
{
	UTextBlock* AssetTypeText = Cast<UTextBlock>(GetWidgetFromName(FName(TEXT("AssetTypeText"))));
	UTextBlock* IsPassText = Cast<UTextBlock>(GetWidgetFromName(FName(TEXT("IsPassText"))));
	UMultiLineEditableText* DescriptionText = Cast<UMultiLineEditableText>(GetWidgetFromName(FName(TEXT("DescriptionText"))));

	FLinearColor NormalColor{ 1.0f, 1.0f, 1.0f, 1.0f };
	FLinearColor WarningColor{ 0.8f, 0.2f, 0.0f, 1.0f };
	FLinearColor ErrorColor{ 1.0f, 0.0f, 0.0f, 1.0f };
	
	if(AssetTypeText && IsPassText && DescriptionText)
	{
		AssetTypeText->SetText(FText::FromString(""));
		IsPassText->SetText(FText::FromString(""));
		DescriptionText->SetText(FText::FromString(""));

		TArray<FAssetData> OutAssetData;
		FResourceCheckHelper::GetAssetDataByPackageName(AssetPackageName, OutAssetData);

		if(!OutAssetData.IsEmpty())
		{
			AssetTypeText->SetText(FText::FromString(OutAssetData[0].GetClass()->GetName()));
		}
		if(InLogInfo.Level == ERMCheckRuleType::Info)
		{
			IsPassText->SetText(FText::FromString(UTF8_TO_TCHAR("统计")));
			IsPassText->SetColorAndOpacity(NormalColor);
			bPass = true;
		}
		else if(InLogInfo.Level == ERMCheckRuleType::Warning)
		{
			IsPassText->SetText(FText::FromString(UTF8_TO_TCHAR("警告")));
			IsPassText->SetColorAndOpacity(WarningColor);
			bPass = true;
		}
		else if(InLogInfo.Level == ERMCheckRuleType::Error)
		{
			IsPassText->SetText(FText::FromString(UTF8_TO_TCHAR("错误")));
			IsPassText->SetColorAndOpacity(ErrorColor);
			bPass = false;
		}

		DescriptionText->SetText(FText::FromString(InLogInfo.Description));
	}
}

void UResourceManagerSingleWidget::NativeConstruct()
{
	Super::NativeConstruct();
	
	if (UButton* AssetLinkBtn = Cast<UButton>(GetWidgetFromName(FName(TEXT("AssetLinkBtn")))))
	{
		FScriptDelegate Del;
		Del.BindUFunction(this, "OnAssetLinkBtnClick");
		AssetLinkBtn->OnClicked.Add(Del);
	}
}

void UResourceManagerSingleWidget::OnAssetLinkBtnClick()
{
	TArray<FAssetData> OutAssetData;
	FResourceCheckHelper::GetAssetDataByPackageName(AssetPackageName, OutAssetData);
	if (!OutAssetData.IsEmpty())
	{
		FBox FocusBounds(EForceInit::ForceInit);
		UWorld* CurrentWorld = GEditor->GetEditorWorldContext().World();
		FContentBrowserModule& ContentBrowserModule = FModuleManager::Get().LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
		ContentBrowserModule.Get().SyncBrowserToAssets(OutAssetData);
		if(CurrentWorld)
		{
			if (!OutAssetData[0].GetClass()->IsChildOf<AActor>())
			{
				return;
			}
			AActor* CurrentActor = Cast<AActor>(OutAssetData[0].GetAsset());
			if (!CurrentActor)
			{
				UE_LOG(LogTemp, Warning, TEXT("Failed to get Actor %s."), *OutAssetData[0].PackageName.ToString());
				return;
			}
			GEditor->GetSelectedActors()->BeginBatchSelectOperation();
			bool bNotify = false;
			GEditor->SelectNone(bNotify, true);
			const FBox EditorBounds = CurrentActor->GetStreamingBounds();
			const bool bSelected = true;
			GEditor->SelectActor(CurrentActor, bSelected, bNotify);
			if (EditorBounds.IsValid)
			{
				FocusBounds += EditorBounds;
			}
			bNotify = true;
			GEditor->GetSelectedActors()->EndBatchSelectOperation(bNotify);
			if (FocusBounds.IsValid)
			{
				const bool bActiveViewportOnly = true;
				const float TimeInSeconds = 0.5f;
				GEditor->MoveViewportCamerasToBox(FocusBounds, bActiveViewportOnly, TimeInSeconds);
			}
		}
	}
}