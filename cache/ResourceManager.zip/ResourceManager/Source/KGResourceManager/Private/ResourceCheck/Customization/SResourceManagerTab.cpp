#include "ResourceCheck/Customization/SResourceManagerTab.h"
#include "Blueprint/UserWidget.h"
#include "ResourceCheck/Customization/ResourceManagerWidget.h"
#include "ResourceCheck/ResourceCheckConfig.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"

void SResourceManagerTab::Construct(const FArguments& InArgs)
{
	UClass* WidgetClass = LoadClass<UUserWidget>(NULL, *FResourceCheckConfig::WBPResourceManagerWidget);
	UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
	if (WidgetClass && ResourceCheckSubsystem)
	{
		if (WidgetClass)
		{
			MessageWidget = CreateWidget<UUserWidget>(ResourceCheckSubsystem->GetMessageTabWorld(), WidgetClass); 
		}
		if (MessageWidget.IsValid())
		{
			BaseWidget = MessageWidget->TakeWidget();
		}
	}
	else
	{
		if (!WidgetClass)
		{
			UE_LOG(LogTemp, Error, TEXT("WidgetClass is null."));
		}
		if (!ResourceCheckSubsystem)
		{
			UE_LOG(LogTemp, Error, TEXT("ResourceCheckSubsystem is null."));
		}
	}

	ChildSlot
	[
		BaseWidget.ToSharedRef()
	];
}

void SResourceManagerTab::AddMessage(const FResourceCheckLogInfo& InLogInfo)
{
	if (BaseWidget.IsValid() && MessageWidget.IsValid())
	{
		
		UResourceManagerWidget* Widget = Cast<UResourceManagerWidget>(MessageWidget.Get());
		if (Widget)
		{
			Widget->AddMessage(InLogInfo);
		}
	}
}

void SResourceManagerTab::RemoveAllMessages()
{
	if (BaseWidget.IsValid() && MessageWidget.IsValid())
	{
		if (UResourceManagerWidget* Widget = Cast<UResourceManagerWidget>(MessageWidget.Get()))
		{
			Widget->RemoveAllMessages();
		}
	}
}
