// Copyright Kuaishou, Inc. All Rights Reserved.

#include "ResourceCheck/Customization/FunctionDetail.h"
#include "ResourceCheck/RuleBase.h"
#include "DetailWidgetRow.h"
#include "IDetailChildrenBuilder.h"
#include "DetailLayoutBuilder.h"
#include "DetailCategoryBuilder.h"

#define LOCTEXT_NAMESPACE "FunctionDetail"

void FFunctionDetails::CustomizeHeader(TSharedRef<class IPropertyHandle> StructPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	FunctionNameHandle = StructPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FRMFunctionRuleMapping, FunctionName));
}

TSharedRef<SWidget> FFunctionDetails::HandleGenerateWidgetForFunctionNameComboBox(TSharedPtr<FString> Item) const
{
	FString StringItem = Item.IsValid() ? *Item : FString();

	// If a row wasn't generated just create the default one, a simple text block of the item's name.
	return SNew(STextBlock)
		.Text(FText::FromString(StringItem));
}

void FFunctionDetails::HandleSelectionChangedForFunctionNameComboBox(TSharedPtr<FString> Item, ESelectInfo::Type SelectionType)
{
	TSharedPtr<FString> StringItem = Item;
	if (StringItem.IsValid())
	{
		// change property name
		TSharedRef<SWidget> ComboContentText = SNew(STextBlock).Text(FText::FromString(*StringItem.Get()));
		FunctionNameComboContent->SetContent(ComboContentText);
		FunctionNameHandle->SetValue(*StringItem.Get());
	}
}

//
bool FFunctionDetails::IsFunctionHasCurrentInputAndOutput(UFunction* Function)
{
	// 检查返回值类型
	if (Function->ReturnValueOffset != MAX_uint16)
	{
		FProperty* ReturnValue = Function->GetReturnProperty();
		if (ReturnValue->GetCPPType() != TEXT("bool"))
		{
			return false;
		}
	}
	else
	{
		return false;
	}

	TArray<FString> CheckPropertyList;
	CheckPropertyList.Add(TEXT("FAssetData")); //InAsset
	CheckPropertyList.Add(TEXT("TMap")); //Arguments
	CheckPropertyList.Add(TEXT("FString")); //OutputString

	int32 CheckIndex = 0;
	
	// 检查参数类型
	for (TFieldIterator<FProperty> ParamIt(Function); ParamIt && (ParamIt->PropertyFlags & CPF_Parm); ++ParamIt)
	{
		FProperty* Param = *ParamIt;
		if(Param->GetName()=="ReturnValue")
		{
			continue;
		}

		if(CheckIndex >= CheckPropertyList.Num())
		{
			return false;
		}
		if(CheckPropertyList[CheckIndex] == TEXT("UObject"))
		{
			// FObjectProperty* ObjectProperty = CastField<FObjectProperty>(Param);
			// if (!ObjectProperty || !ObjectProperty->PropertyClass->IsChildOf(UObject::StaticClass()))
			// {
			// 	return false;
			// }
		}
		else
		{
			if (Param->GetCPPType() != CheckPropertyList[CheckIndex])
			{
				return false;
			}
		}
		CheckIndex++;
	}
	return true;
}

void FFunctionDetails::CustomizeChildren(TSharedRef<class IPropertyHandle> StructPropertyHandle, IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	PropertyDetailBuilder = &StructBuilder;
	IDetailCategoryBuilder& ParentCategory = StructBuilder.GetParentCategory();
	IDetailLayoutBuilder& ParentLayout = ParentCategory.GetParentLayout();
	TSubclassOf<URuleBase> ActionPrefabRule = ParentLayout.GetBaseClass();
	if (ActionPrefabRule)
	{
		AssetCLass = ActionPrefabRule->GetDefaultObject<URuleBase>()->GetAssetType();
	}

	if (AssetCLass.IsValid())
	{
		// 1. Function value box
		StructBuilder.AddCustomRow(FText::FromString(TEXT("Function")))
			.NameContent()
			[
				FunctionNameHandle->CreatePropertyNameWidget()
			]
			.ValueContent()
			[
				SAssignNew(AllFunctionNameSelectorBox, SBox)
			];

		// get all property to fill the property selector
		for (TFieldIterator<UFunction> FuncIter(ActionPrefabRule); FuncIter; ++FuncIter)
		{
			UFunction* Function = *FuncIter;			
			if(IsFunctionHasCurrentInputAndOutput(Function))
			{
				AllFunctionNames.Add(MakeShareable(new FString(Function->GetName())));
			}
		}
		AllFunctionNames.Sort([](const TSharedPtr<FString>& A, const TSharedPtr<FString>& B) {
			return *A < *B;
		});
		AllFunctionNames.Add(MakeShareable(new FString("None")));

		TSharedPtr<SWidget> FuncWidget;
		SAssignNew(AllFunctionNameSelector, SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&AllFunctionNames)
			.OnGenerateWidget(SComboBox<TSharedPtr<FString>>::FOnGenerateWidget::CreateRaw(this, &FFunctionDetails::HandleGenerateWidgetForFunctionNameComboBox))
			.OnSelectionChanged(SComboBox< TSharedPtr<FString> >::FOnSelectionChanged::CreateRaw(this, &FFunctionDetails::HandleSelectionChangedForFunctionNameComboBox))
			[
				SAssignNew(FunctionNameComboContent, SBox)
			];
		FunctionNameComboContent->SetContent(SNew(STextBlock).Text(FText::FromString("None")));
		FuncWidget = AllFunctionNameSelector;
		AllFunctionNameSelectorBox->SetContent(FuncWidget.ToSharedRef());

		if (AllFunctionNames.Num())
		{
			FString FuncName;
			FunctionNameHandle->GetValue(FuncName);
			if (FuncName.IsEmpty())
			{
				FuncName = TEXT("None");
			}
			AllFunctionNameSelector->SetSelectedItem(MakeShareable(new FString(FuncName)));
			FunctionNameComboContent->SetContent(SNew(STextBlock).Text(FText::FromString(FuncName)));
		}
	}
}

#undef LOCTEXT_NAMESPACE
