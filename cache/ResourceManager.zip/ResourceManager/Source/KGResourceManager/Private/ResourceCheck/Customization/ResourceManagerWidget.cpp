// Fill out your copyright notice in the Description page of Project Settings.


#include "ResourceCheck/Customization/ResourceManagerWidget.h"

#include "FileHelpers.h"
#include "ResourceCheck/ResourceCheckConfig.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"
#include "ResourceCheck/Customization/ResourceManagerSingleWidget.h"

#include "Components/ListView.h"
#include "Components/VerticalBox.h"
#include "Components/Border.h"
#include "Components/Button.h"


void UResourceManagerWidget::AddMessage(const FResourceCheckLogInfo& InLogInfo)
{
	if (UVerticalBox* HistoryVerticalBox = Cast<UVerticalBox>(GetWidgetFromName(FName(TEXT("HistoryVerticalBox")))))
	{
		UClass* WidgetClass = LoadClass<UUserWidget>(NULL, *FResourceCheckConfig::WBPResourceManagerSingleWidget);
		if (WidgetClass)
		{
			auto AddWidget = [this, HistoryVerticalBox, WidgetClass](const FResourceCheckLogInfo& InLogInfo)
			{
				if (auto Widget = CreateWidget<UUserWidget>(this, WidgetClass))
                {
                	UResourceManagerSingleWidget* SingleWidget = Cast<UResourceManagerSingleWidget>(Widget);
                	if (SingleWidget)
                	{
                		SingleWidget->SetSelectedObj(InLogInfo);
                		SingleWidget->SetState(InLogInfo); 
                		HistoryVerticalBox->AddChild(SingleWidget);
                		UBorder* Border = NewObject<UBorder>();
                		HistoryVerticalBox->AddChild(Border);
                	}
                }
			};
			AddWidget(InLogInfo);
		}
	}
}

void UResourceManagerWidget::RemoveAllMessages()
{
	if (UVerticalBox* HistoryVerticalBox = Cast<UVerticalBox>(GetWidgetFromName(FName(TEXT("HistoryVerticalBox")))))
	{
		HistoryVerticalBox->ClearChildren();
	}
}

void UResourceManagerWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (UButton* ClearRightBtn = Cast<UButton>(GetWidgetFromName(FName(TEXT("ClearRightBtn")))))
	{
		FScriptDelegate Del;
		Del.BindUFunction(this, "OnClearRightBtnClick");
		ClearRightBtn->OnClicked.Add(Del);
	}

	if (UButton* AutoFixBtn = Cast<UButton>(GetWidgetFromName(FName(TEXT("AutoFixBtn")))))
	{
		FScriptDelegate Del;
		Del.BindUFunction(this, "OnAutoFixBtnClick");
		AutoFixBtn->OnClicked.Add(Del);
	}

	if (UButton* AutoSaveBtn = Cast<UButton>(GetWidgetFromName(FName(TEXT("AutoSaveBtn")))))
	{
		FScriptDelegate Del;
		Del.BindUFunction(this, "OnAutoSaveBtnClick");
		AutoSaveBtn->OnClicked.Add(Del);
	}
}
void UResourceManagerWidget::OnClearRightBtnClick() const
{
	if (UVerticalBox* HistoryVerticalBox = Cast<UVerticalBox>(GetWidgetFromName(FName(TEXT("HistoryVerticalBox")))))
	{
		TArray<UWidget*> SingleMessageWidgets = HistoryVerticalBox->GetAllChildren();
		for (int32 Index = SingleMessageWidgets.Num() - 1; Index >= 0; Index--)
		{
			if (const UResourceManagerSingleWidget* SingleMessageWidget = Cast<UResourceManagerSingleWidget>(SingleMessageWidgets[Index]))
			{
				if (SingleMessageWidget->bPass)
				{
					if (Index + 1 < SingleMessageWidgets.Num())
					{
						if (UBorder* Border = Cast<UBorder>(SingleMessageWidgets[Index + 1]))
						{
							HistoryVerticalBox->RemoveChildAt(Index + 1);
						}
					}
					HistoryVerticalBox->RemoveChildAt(Index);
				}
			}
		}
	}
}
void UResourceManagerWidget::OnAutoFixBtnClick() const
{
	if (UVerticalBox* HistoryVerticalBox = Cast<UVerticalBox>(GetWidgetFromName(FName(TEXT("HistoryVerticalBox")))))
	{
		TArray<UWidget*> SingleMessageWidgets = HistoryVerticalBox->GetAllChildren();
		for (int32 Index = SingleMessageWidgets.Num() - 1; Index >= 0; Index--)
		{
			if (const UResourceManagerSingleWidget* ResourceCheckSingleWidget = Cast<UResourceManagerSingleWidget>(SingleMessageWidgets[Index]))
			{
				if (ResourceCheckSingleWidget->bPass)
				{
					if (Index + 1 < SingleMessageWidgets.Num())
					{
						if (UBorder* Border = Cast<UBorder>(SingleMessageWidgets[Index + 1]))
						{
							HistoryVerticalBox->RemoveChildAt(Index + 1);
						}
					}
					HistoryVerticalBox->RemoveChildAt(Index);
				}
			}
		}
		UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
		ResourceCheckSubsystem->RepairCheckedAssets();
	}
}
void UResourceManagerWidget::OnAutoSaveBtnClick() const
{
	if (const UVerticalBox* HistoryVerticalBox = Cast<UVerticalBox>(GetWidgetFromName(FName(TEXT("HistoryVerticalBox")))))
	{
		TArray<UWidget*> SingleMessageWidgets = HistoryVerticalBox->GetAllChildren();
		TArray<UPackage*> Packages;
		for (int32 Index = SingleMessageWidgets.Num() - 1; Index >= 0; Index--)
		{
			if (const UResourceManagerSingleWidget* ResourceCheckSingleWidget = Cast<UResourceManagerSingleWidget>(SingleMessageWidgets[Index]))
			{
				TArray<FAssetData> OutAssetData;
				FResourceCheckHelper::GetAssetDataByPackageName(ResourceCheckSingleWidget->AssetPackageName, OutAssetData);
				if (OutAssetData.Num() > 0)
				{
					UPackage* Package = OutAssetData[0].GetPackage();
					if (Package && Package->IsDirty())
					{
						Packages.Add(Package);
					}
				}
			}
		}
		FEditorFileUtils::PromptForCheckoutAndSave(Packages, true, false);
	}
}
