#include "ResourceCheck/ResourceCheckCommandlet.h"

#include "ResourceCheck/ResourceCheckSubsystem.h"
#include "Misc/OutputDeviceRedirector.h"

#include "HAL/Event.h"
#include "Async/Async.h"
#include "AssetRegistry/AssetRegistryModule.h"

UResourceCheckCommandlet::UResourceCheckCommandlet()
{
	
}

int32 UResourceCheckCommandlet::Main(const FString& Params)
{
	UE_LOG(LogKGResourceManager, Log, TEXT("ResourceCheckCommandlet started with params: %s"), *Params);
	
	// 准备 AsssetRegistry
	FEvent* AssetRegistryLoadedEvent = FPlatformProcess::GetSynchEventFromPool(true);

	// Ensure AssetRegistryModule is initialized
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

	// 初始化 AssetRegistry
	AssetRegistry.SearchAllAssets(true);

	// Wait until the AssetRegistry is fully loaded
	AssetRegistry.OnFilesLoaded().AddLambda([AssetRegistryLoadedEvent]()
	{
		AssetRegistryLoadedEvent->Trigger();
	});

	if (!AssetRegistry.IsLoadingAssets())
	{
		AssetRegistryLoadedEvent->Trigger();
	}

	// Wait for the AssetRegistry to be fully loaded
	AssetRegistryLoadedEvent->Wait();
	FPlatformProcess::ReturnSynchEventToPool(AssetRegistryLoadedEvent);

	// Log to verify AssetRegistry is loaded
	UE_LOG(LogKGResourceManager, Log, TEXT("AssetRegistry is fully loaded"));

	TArray<FString> ParamList;
	Params.ParseIntoArray(ParamList, TEXT(" "));
	TArray<FString> EnableRules;
	if (ParamList.Num() > 1)
	{
		// 如果没加规则参数，剔除掉 -xxx 的格式，变为全量检查
		// 例如：-run=ResourceCheckCommandlet -RUNNINGUNATTENDEDSCRIPT
		if (!ParamList[1].StartsWith(TEXT("-")))
		{
			// e.g. -run=ResourceCheckCommandlet TextureRuleUI
			ParamList[1].ParseIntoArray(EnableRules, TEXT(","));
		}
	}
	// if(ParamList.Num() > 0)
	// {
	// 	for(auto Param : ParamList)
	// 	{
	// 		if(Param.StartsWith(TEXT("-rule=")))
	// 		{
	// 			FResourceCheckerMgr::Get().AddTestRuleFilter(Param.Mid(6).TrimStartAndEnd());
	// 		}
	// 	}
	// }
	UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
	ResourceCheckSubsystem->CheckAssetsByCommandlet(EnableRules);

	CommandletHelpers::TickEngine();
	UE_LOG(LogKGResourceManager, Log, TEXT("ResourceCheckCommandlet end with params: %s"), *Params);
	return 0;
}

UResourceRepairCommandlet::UResourceRepairCommandlet()
{
	
}

int32 UResourceRepairCommandlet::Main(const FString& Params)
{
	UE_LOG(LogKGResourceManager, Log, TEXT("ResourceCheckCommandlet started with params: %s"), *Params);
	
	// 准备 AsssetRegistry
	FEvent* AssetRegistryLoadedEvent = FPlatformProcess::GetSynchEventFromPool(true);

	// Ensure AssetRegistryModule is initialized
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

	// 初始化 AssetRegistry
	AssetRegistry.SearchAllAssets(true);

	// Wait until the AssetRegistry is fully loaded
	AssetRegistry.OnFilesLoaded().AddLambda([AssetRegistryLoadedEvent]()
	{
		AssetRegistryLoadedEvent->Trigger();
	});

	if (!AssetRegistry.IsLoadingAssets())
	{
		AssetRegistryLoadedEvent->Trigger();
	}

	// Wait for the AssetRegistry to be fully loaded
	AssetRegistryLoadedEvent->Wait();
	FPlatformProcess::ReturnSynchEventToPool(AssetRegistryLoadedEvent);

	// Log to verify AssetRegistry is loaded
	UE_LOG(LogKGResourceManager, Log, TEXT("AssetRegistry is fully loaded"));

	TArray<FString> ParamList;
	Params.ParseIntoArray(ParamList, TEXT(" "));

	TArray<FString> EnableRules;
	if (ParamList.Num() > 1)
	{		
		ParamList[1].ParseIntoArray(EnableRules, TEXT(","));
	}

	UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
	ResourceCheckSubsystem->RepairAssetsByCommandlet(EnableRules);

	CommandletHelpers::TickEngine();
	UE_LOG(LogKGResourceManager, Log, TEXT("ResourceRepairCommandlet end with params: %s"), *Params);
	return 0;
}