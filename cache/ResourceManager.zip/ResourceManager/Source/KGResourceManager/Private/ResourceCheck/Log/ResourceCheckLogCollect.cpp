#include "ResourceCheck/Log/ResourceCheckLogCollect.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"

void FResourceCheckLogCollect::Initialize()
{
    LogInfos.Empty();
}

bool FResourceCheckLogCollect::Log(const FAssetData AssetData, const FString Tag, ERMCheckRuleType ResourceCheckLogLevel, const FString StatusDesc)
{

	bool bSuccess = true;
	
	UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
	FResourceCheckLogManager& LogManager = ResourceCheckSubsystem->GetLogManager();
	FString MatchString = StatusDesc;
	for(int32 Index = 0; Index < ParamArray.Num(); Index++)
	{
		int32 FindIndex = MatchString.Find(TEXT("{}"), ESearchCase::CaseSensitive, ESearchDir::FromStart);
		if(FindIndex != INDEX_NONE)
		{
			MatchString = MatchString.Left(FindIndex) + ParamArray[Index] + MatchString.RightChop(FindIndex + 2);
		}
	}
	FResourceCheckLogInfo LogInfo;

	LogInfo.AssetData = AssetData;
	LogInfo.ResourcePath = AssetData.PackageName.ToString();
	LogInfo.Description = MatchString;
	LogInfo.Level = ResourceCheckLogLevel;
	LogInfo.Tag = Tag;
	LogInfo.RuleGuid = LogManager.GetGuid();

	Tags.Add(LogInfo.Tag);
	LogInfos.Add(LogInfo);  
    return bSuccess;
}

FString FResourceCheckLogCollect::GetFilePathFromAssetData(const FAssetData AssetData)
{
    // 获取对象的包
    UPackage* Package = AssetData.GetPackage();
    if (!Package)
    {
        return FString();
    }

    // 获取包名
    FString PackageName = Package->GetName();

    // 将包名转换为文件路径，并添加文件后缀
    FString FilePath = FPackageName::LongPackageNameToFilename(PackageName, FPackageName::GetAssetPackageExtension());

    return FilePath;
}

void FResourceCheckLogCollect::Combine(FResourceCheckLogCollect& InLogCollect)
{
    LogInfos.Append(InLogCollect.LogInfos);
}

void FResourceCheckLogCollect::Combine(TArray<FResourceCheckLogInfo>& InLogList)
{
    LogInfos.Append(InLogList);
}

void FResourceCheckLogCollect::Sort()
{
    Algo::Sort(LogInfos, [](const FResourceCheckLogInfo A, const FResourceCheckLogInfo B)
        {
            return A.Tag > B.Tag || (A.Tag == B.Tag && A.RuleGuid.ToString() > B.RuleGuid.ToString());
        }
    );
}
