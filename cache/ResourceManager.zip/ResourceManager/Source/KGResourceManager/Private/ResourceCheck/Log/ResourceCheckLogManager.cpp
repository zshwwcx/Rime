#include "ResourceCheck/Log/ResourceCheckLogManager.h"
#include "KGResourceManagerModule.h"

void FResourceCheckLogManager::SetNewGuid()
{
	LogManagerGuid = FGuid::NewGuid();
}
