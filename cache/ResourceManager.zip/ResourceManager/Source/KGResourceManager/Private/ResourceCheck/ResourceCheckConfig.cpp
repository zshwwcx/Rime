#include "ResourceCheck/ResourceCheckConfig.h"

FString FResourceCheckConfig::SkipCheckTag = "SkipCheck";
FString FResourceCheckConfig::HighTag = "high";
FString FResourceCheckConfig::BlueprintRulePath = "/Game/Editor/ResourceManager";
FString FResourceCheckConfig::WBPResourceManagerWidget = "/Game/Editor/ResourceManager/UI/WBP_ResourceManagerWidget.WBP_ResourceManagerWidget_C";
FString FResourceCheckConfig::WBPResourceManagerSingleWidget = "/Game/Editor/ResourceManager/UI/WBP_ResourceManagerSingleWidget.WBP_ResourceManagerSingleWidget_C";