#include "ResourceCheck/ResourceCheckHelper.h"

#include "DiffUtils.h"
#include "ISourceControlModule.h"
#include "Particles/ParticleSystem.h"
#include "PaperSpriteAtlas.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "ResourceCheck/ResourceCheckUtility.h"
#include "SourceControlHelpers.h"
#include "SourceControlOperations.h"

FString FResourceCheckHelper::GetPropertyValueByName(const FAssetData& InAssetData, const FString& PropertyName, bool bLoad)
{
	FString AssetDataTagValue;
	if (InAssetData.GetTagValue(*PropertyName, AssetDataTagValue))
	{
		return AssetDataTagValue;
	}
	if (bLoad)
	{
		FString PropertyValue;
		UObject* Asset = InAssetData.GetAsset();
		if (const FProperty* Property = Asset->GetClass()->FindPropertyByName(FName(PropertyName)))
		{
			if (const void* ValuePtr = Property->ContainerPtrToValuePtr<void>(Asset))
			{
				Property->ExportTextItem_Direct(PropertyValue, ValuePtr, nullptr, nullptr, PPF_None);
			}
		}
		return PropertyValue;
	}
	return "";
}

void FResourceCheckHelper::GetAssetEditorTags(const FAssetData& InAssetData, TArray<FString>& OutTags)
{
	FString AssetDataTagValue;
	if (InAssetData.GetTagValue("AssetEditorTags", AssetDataTagValue))
	{
		TArray<FString> Tags;
		AssetDataTagValue = AssetDataTagValue.Mid(1, AssetDataTagValue.Len() - 2);
		AssetDataTagValue.ParseIntoArray(Tags, TEXT(","));
		OutTags.Reserve(Tags.Num());
		for (int32 i = 0; i < Tags.Num(); i++)
		{
			OutTags.Add(Tags[i].Mid(1, Tags[i].Len() - 2));
		}
	}
}

bool FResourceCheckHelper::HasTag(const FAssetData& InAssetData, const FString& InTag)
{
	TArray<FString> Tags;
	GetAssetEditorTags(InAssetData, Tags);
	return Tags.Contains(InTag);
}

FString FResourceCheckHelper::GetEditorTagContent(const FAssetData& InAssetData)
{
	TArray<FString> Tags;
	FResourceCheckHelper::GetAssetEditorTags(InAssetData, Tags);
	FString TagContent;
	if (!Tags.IsEmpty())
	{
		for(const FString& Tag : Tags)
		{
			if (!Tag.IsEmpty())
			{
				if(TagContent.Len() != 0)
				{
					TagContent += TEXT(",") + Tag;
				}
				else
				{							
					TagContent += Tag;
				}
			}
		}
	}
	return TagContent;
}

void FResourceCheckHelper::GetAssetDataByPackageName(const FString& PackageName, TArray<FAssetData>& OutAssetData)
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	AssetRegistryModule.Get().GetAssetsByPackageName(*PackageName, OutAssetData);
}

void FResourceCheckHelper::GetRuleFunctionFromWeb(TArray<FRMResCheckData>& OutResCheckData)
{
	OutResCheckData.Empty();
	FEvent* RuleReadyEvent = FPlatformProcess::GetSynchEventFromPool(true);
	TFunction<void()> RuleReadyFunction = [RuleReadyEvent]()
	{
		RuleReadyEvent->Trigger();
	};
	FResourceCheckUtility::InitRuleDataFromWeb(RuleReadyEvent, [&](const FRMJsonResponse& JsonResponse)
	{
		OutResCheckData.Append(JsonResponse.Data);	
		RuleReadyFunction();
	});
	
	FPlatformProcess::ReturnSynchEventToPool(RuleReadyEvent);
}

URuleBase* FResourceCheckHelper::CreateRule(const FRMResCheckData& Data)
{
	FString ClassName = FString::Printf(TEXT("/Script/KGResourceManager.%s"), *Data.RuleFunction);
	UClass*	RuleClass = StaticLoadClass(UObject::StaticClass(), nullptr, *ClassName);
	if (RuleClass && RuleClass->IsChildOf(URuleBase::StaticClass()))
	{
		URuleBase* RuleFunction = NewObject<URuleBase>(GetTransientPackage(), RuleClass);
		if (RuleFunction)
		{
			RuleFunction->Initialize(Data);
		}
		return RuleFunction;
	}
	return nullptr;
}

FString FResourceCheckHelper::GetBranchName(const FString InWorkspace)
{
	FString BranchName = TEXT("");
	FString Process = TEXT("p4");
	FString Command = FString::Printf(TEXT("-Ztag -F %%Stream%% client -o %s"), *InWorkspace);

	int32 ResultCode;
	FString Result;
	FString ResultErr;

	bool bProcessSuccess = FPlatformProcess::ExecProcess(*Process, *Command, &ResultCode, &Result, &ResultErr);
	if (bProcessSuccess && Result != "")
	{
		TArray<FString> SplitString;
		Result.TrimStartAndEnd().ParseIntoArray(SplitString, TEXT("/"), false);
		BranchName = SplitString.Last();
	}
	else
	{
		TArray<FString> ContactPersonNames; 
		GConfig->GetArray(TEXT("ResourceCheck"), TEXT("ContactPersonName"), ContactPersonNames, GEditorIni);
		FString ErrorMessage = FString::Printf(TEXT("P4 获取分支名失败，错误信息：\n%s\n\n有问题可以联系"), *ResultErr);
		if (ContactPersonNames.Num() > 0)
		{
			for (const auto& ContactPersonName : ContactPersonNames)
			{
				ErrorMessage += "@" + ContactPersonName + " ";
			}
		}
		else
		{
			ErrorMessage += UTF8_TO_TCHAR("@程文华 @何博航");
		}
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(ErrorMessage));
	}
	return BranchName;
}

void FResourceCheckHelper::AddTagInAssetes(TArray<FAssetData>& AssetDatas, FName Tag)
{
	for(auto Asset : AssetDatas)
	{
		UObject* Obj = Asset.GetAsset();
		if(Obj)
		{
			if (UStreamableRenderAsset* StreamableRenderAsset = Cast<UStreamableRenderAsset>(Obj))
			{
				if(!StreamableRenderAsset->AssetEditorTags.Contains(Tag))
				{
					StreamableRenderAsset->AssetEditorTags.Add(Tag);
					Obj->MarkPackageDirty();
				}
			}
			else if (UFXSystemAsset* FXSystemAsset = Cast<UFXSystemAsset>(Obj))
			{
				if(!FXSystemAsset->AssetEditorTags.Contains(Tag))
				{
					FXSystemAsset->AssetEditorTags.Add(Tag);
					Obj->MarkPackageDirty();
				}
			}
			else if (UPaperSpriteAtlas* PaperSpriteAtlasAsset = Cast<UPaperSpriteAtlas>(Obj))
			{
				if(!PaperSpriteAtlasAsset->AssetEditorTags.Contains(Tag))
				{
					PaperSpriteAtlasAsset->AssetEditorTags.Add(Tag);
					Obj->MarkPackageDirty();
				}
			}
		}
	}
}

void FResourceCheckHelper::RemoveTagInAssetes(TArray<FAssetData>& AssetDatas, FName Tag)
{
	for(auto Asset : AssetDatas)
	{
		UObject* Obj = Asset.GetAsset();
		if(Obj)
		{
			if (UStreamableRenderAsset* StreamableRenderAsset = Cast<UStreamableRenderAsset>(Obj))
			{
				if(StreamableRenderAsset->AssetEditorTags.Contains(Tag))
				{
					StreamableRenderAsset->AssetEditorTags.Remove(Tag);
					Obj->MarkPackageDirty();
				}
			}
			else if (UFXSystemAsset* FXSystemAsset = Cast<UFXSystemAsset>(Obj))
			{
				if(FXSystemAsset->AssetEditorTags.Contains(Tag))
				{
					FXSystemAsset->AssetEditorTags.Remove(Tag);
					Obj->MarkPackageDirty();
				}
			}
			else if (UPaperSpriteAtlas* PaperSpriteAtlasAsset = Cast<UPaperSpriteAtlas>(Obj))
			{
				if(PaperSpriteAtlasAsset->AssetEditorTags.Contains(Tag))
				{
					PaperSpriteAtlasAsset->AssetEditorTags.Remove(Tag);    
					Obj->MarkPackageDirty();
				}
			}
		}	
	}
}

bool FResourceCheckHelper::HasTagInAssetes(TArray<FAssetData>& AssetDatas, FName Tag)
{
	bool HasTag = false;
	for(auto Asset : AssetDatas)
	{
		if (FResourceCheckHelper::HasTag(Asset, Tag.ToString()))
		{
			HasTag = true;
			break;
		}
	}
	return HasTag;
}

bool FResourceCheckHelper::HasNotTagInAssetes(TArray<FAssetData>& AssetDatas, FName Tag)
{
	bool HasNotTag = false;
	for(auto Asset : AssetDatas)
	{
		if (!FResourceCheckHelper::HasTag(Asset, Tag.ToString()))
		{
			HasNotTag = true;
			break;
		}
	}
	return HasNotTag;
}

FString FResourceCheckHelper::GetAbsoultePath(const FAssetData& AssetData)
{
	const FString FileName = FPackageName::LongPackageNameToFilename(AssetData.PackageName.ToString());;
	const FString AssetFullDependPath = FPaths::ConvertRelativePathToFull(FileName) + FPackageName::GetAssetPackageExtension();
	const FString MapFullDependPath = FPaths::ConvertRelativePathToFull(FileName) + FPackageName::GetMapPackageExtension();
	if (FPaths::FileExists(AssetFullDependPath))
	{
		return AssetFullDependPath;
	}
	else if (FPaths::FileExists(MapFullDependPath))
	{
		return MapFullDependPath;
	}
	return TEXT("None");
}

UObject* FResourceCheckHelper::GetHistoryObject(const FString& InPackagePath, const FString& InPackageName)
{
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	TSharedRef<FUpdateStatus, ESPMode::ThreadSafe> UpdateStatusOperation = ISourceControlOperation::Create<FUpdateStatus>();
	UpdateStatusOperation->SetUpdateHistory(true);
	SourceControlProvider.Execute(UpdateStatusOperation, SourceControlHelpers::PackageFilename(InPackagePath));

	FSourceControlStatePtr SourceControlState = SourceControlProvider.GetState(SourceControlHelpers::PackageFilename(InPackagePath), EStateCacheUsage::Use);

	if( SourceControlState.IsValid() && SourceControlState->IsSourceControlled() )
	{
		FString RelativeFileName;
		if(FPackageName::DoesPackageExist(InPackagePath, &RelativeFileName))
		{
			if(SourceControlState->GetHistorySize() > 0)
			{
				TSharedPtr<ISourceControlRevision, ESPMode::ThreadSafe> Revision = SourceControlState->GetHistoryItem(0);
				check(Revision.IsValid());

				FString AbsoluteFileName = FPaths::ConvertRelativePathToFull(RelativeFileName);
				FString TempFileName;
				if(UPackage* TempPackage = DiffUtils::LoadPackageForDiff(Revision))
				{
					UObject* OldObject = FindObject<UObject>(TempPackage, *InPackageName);

					if (OldObject == nullptr)
					{
						OldObject = TempPackage->FindAssetInPackage();
					}
					return OldObject;
				}
			}
		}
	}
	return nullptr;
}
