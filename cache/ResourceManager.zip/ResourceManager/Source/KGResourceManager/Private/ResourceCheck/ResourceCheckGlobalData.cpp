#include "ResourceCheck/ResourceCheckGlobalData.h"

TArray<FString> FResourceCheckGlobalData::SpriteAssetRuleLuaDatas = TArray<FString>();

void FResourceCheckGlobalData::StartupSubsystem()
{

}

void FResourceCheckGlobalData::LoadSpriteAssetRuleLuaDatas()
{
	const FString LuaPath = FPaths::ProjectContentDir() + TEXT("Script/");
	TArray<FString> FileNames;
	IFileManager::Get().FindFilesRecursive(FileNames, *LuaPath, TEXT("*.lua"), true, false);
	for (const FString& FileName : FileNames)
	{
		FString FileData = "";
		FFileHelper::LoadFileToString(FileData, *FileName);
		SpriteAssetRuleLuaDatas.Add(FileData);
	}
}
