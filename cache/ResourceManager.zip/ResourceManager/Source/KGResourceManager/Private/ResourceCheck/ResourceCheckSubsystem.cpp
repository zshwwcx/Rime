#include "ResourceCheck/ResourceCheckSubsystem.h"

#include "EditorWorldUtils.h"
#include "ISourceControlModule.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "ResourceCheck/ResourceCheckUtility.h"
#include "ResourceCheck/Customization/SResourceManagerTab.h"
#include "Elements/Framework/TypedElementRegistry.h"
#include "ResourceCheck/ResourceCheckConfig.h"
#include "StaticMeshCompiler.h"
#include "EngineUtils.h"
#include "Algo/AllOf.h"
#include "Algo/AnyOf.h"
#include "WorldPartition/WorldPartitionActorDescInstance.h"
#include "WorldPartition/WorldPartitionHelpers.h"
#include "WorldPartition/LoaderAdapter/LoaderAdapterShape.h"

DEFINE_LOG_CATEGORY(LogKGResourceManager);

#define LOCTEXT_NAMESPACE "ResourceCheck"

FName UResourceCheckSubsystem::ResourceCheckTabId = FName("ResourceCheckInTab");

FString UResourceCheckSubsystem::RepairJsonDataSaveDir = FPaths::ProjectSavedDir() / TEXT("ResourceCheck");

FString UResourceCheckSubsystem::RepairJsonDataSavePath = FPaths::ProjectSavedDir() / TEXT("ResourceCheck/RepairData.json");

FString UResourceCheckSubsystem::RepairJsonResultSavePath = FPaths::ProjectSavedDir() / TEXT("ResourceCheck/RepairResult.json");

void UResourceCheckSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
}

void UResourceCheckSubsystem::Deinitialize()
{
	Super::Deinitialize();
	ShutDownLuaState();
}

void UResourceCheckSubsystem::InitRulesFromWeb(const ERMCheckRuleRange& InRuleRange)
{
	TArray<FString> EnableRuleNames;
	EnableRuleNames.Empty();
	InitRulesFromWeb(InRuleRange, EnableRuleNames);
}

void UResourceCheckSubsystem::InitRulesFromWeb(const ERMCheckRuleRange& InRuleRange, TArray<FString> EnableRuleNames)
{
	RuleRange = InRuleRange;
	FEvent* RuleReadyEvent = FPlatformProcess::GetSynchEventFromPool(true);

	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	FString WorkspaceName = SourceControlProvider.GetCurrentWorkspaceName();
	BranchName = FResourceCheckHelper::GetBranchName(WorkspaceName);

	FResourceCheckUtility::InitRuleDataFromWeb(RuleReadyEvent, [this, &RuleReadyEvent, &InRuleRange, &EnableRuleNames](const FRMJsonResponse& JsonResponse)
	{
		UE_LOG(LogKGResourceManager, Log, TEXT("Code: %d"), JsonResponse.Code);
		CheckRules.Empty();
		for (const FRMResCheckData& Data : JsonResponse.Data)
		{
			if(URuleBase* Rule = FResourceCheckHelper::CreateRule(Data))
			{
				if (Rule && Rule->CheckRuleRange & InRuleRange)
				{
					//EnableRuleNames为空默认允许所有规则
					if (EnableRuleNames.Num() > 0 && !EnableRuleNames.Contains(Data.RuleName))
					{
						continue;
					}
					
					UE_LOG(LogKGResourceManager, Log, TEXT("Loading RuleName : %s"), *Data.RuleName);
					CheckRules.Add(Rule);
				}
			}
		}
		RuleReadyEvent->Trigger();
	});

	FPlatformProcess::ReturnSynchEventToPool(RuleReadyEvent);
}

bool UResourceCheckSubsystem::IsRuleCheckForAsset(const FAssetData& InAssetData, URuleBase* InRule)
{
	UClass* AssetClass = InAssetData.GetClass();
	if (!AssetClass)
	{
		AssetClass = LoadObject<UClass>(nullptr, *InAssetData.AssetClassPath.ToString());
	}
	if (!AssetClass || !AssetClass->IsChildOf(InRule->GetAssetType()))
	{
		return false;
	}
	FString AssetDataPackagePath = InAssetData.PackagePath.ToString() + TEXT("/");
	UE_LOG(LogKGResourceManager, Display, TEXT("AssetPath -> %s : Rule : %s"), *AssetDataPackagePath, *InRule->GetAssetType()->GetName());

	auto IsPathInRule = [AssetDataPackagePath](const FString& CheckPath) {
		return AssetDataPackagePath.StartsWith(CheckPath);
	};

	if (Algo::AnyOf(InRule->ExpectCheckPaths, IsPathInRule))
	{
		return false;
	}
    
	if (!Algo::AnyOf(InRule->CheckPaths, IsPathInRule))
	{
		return false;
	}

	auto CheckOneCondition = [InRule, &InAssetData](const FRMConditionRule* Condition){return InRule->CheckOneProperty(*Condition, InAssetData);};

	// 检查依赖条件
	TArray<const FRMConditionRule*> RequirementConditions;
	for (auto Condition : InRule->RuleRequirements)
	{
		if (InRule->Conditions.Contains(Condition))
		{
			RequirementConditions.Add(&InRule->Conditions[Condition]);
		}
	}

	if (RequirementConditions.Num() > 0)
	{
		if (InRule->bAnyRequire)
		{
			if (!Algo::AnyOf(RequirementConditions, CheckOneCondition))
			{
				return false;
			}
		}
		else
		{
			if (!Algo::AllOf(RequirementConditions, CheckOneCondition))
			{
				return false;
			}
		}
	}

	// 检查禁止条件
	TArray<const FRMConditionRule*> ProhibitConditions;
	for (auto Condition : InRule->RuleProhibits)
	{
		if (InRule->Conditions.Contains(Condition))
		{
			ProhibitConditions.Add(&InRule->Conditions[Condition]);
		}
	}

	if (ProhibitConditions.Num() > 0 && Algo::AnyOf(ProhibitConditions, CheckOneCondition))
	{
		return false;
	}
		
	return true;
}

void UResourceCheckSubsystem::TriggerGCWhenNeed(int32& Counter, bool bForce) const
{
	Counter++;
	FPlatformMemoryStats MemoryStats = FPlatformMemory::GetStats();
	if (Counter % 1000 != 0)
	{
		if (MemoryStats.AvailableVirtual > MemoryMinFreeVirtual
			&& MemoryStats.AvailablePhysical > MemoryMinFreePhysical
			&& MemoryStats.UsedVirtual < MemoryMaxUsedVirtual)
		{
			return;
		}
	}
	UE_LOG(LogTemp, Display, TEXT("Resource Check CollectGarbage %llu,%llu,%llu"), MemoryStats.AvailableVirtual, MemoryStats.AvailablePhysical, MemoryStats.UsedVirtual)
	UTypedElementRegistry* Registry = UTypedElementRegistry::GetInstance();
	UTypedElementRegistry::FDisableElementDestructionOnGC GCGuard(Registry);
	FAssetRegistryModule::TickAssetRegistry(-1.0f);
	UE_LOG(LogTemp, Display, TEXT("GC Before: UsedVirtual=%llu"), FPlatformMemory::GetStats().UsedVirtual);
		
	if (bForce)
	{
		CollectGarbage(RF_NoFlags);
	}
	else
	{
		CollectGarbage(GARBAGE_COLLECTION_KEEPFLAGS);
	}
	UE_LOG(LogTemp, Display, TEXT("GC After: UsedVirtual=%llu"), FPlatformMemory::GetStats().UsedVirtual);
	if (IsIncrementalPurgePending())
	{
		IncrementalPurgeGarbage(false);
	}
	FMemory::Trim();
}

int32 UResourceCheckSubsystem::CheckAssetsInternal(const TSet<FAssetData>& AssetDataList,bool bCheckFull)
{
	FScopedSlowTask SlowTask(AssetDataList.Num(), LOCTEXT("ResourceProcess.CheckAssetsTask", "Checking Assets"));
	SlowTask.MakeDialog();
	
	UE_LOG(LogKGResourceManager, Display, TEXT("Start check, asset num: %d"), AssetDataList.Num())
	int32 SkippedNum = 0;
	int32 CheckedNum = 0;
	int32 Counter = 0;
	for (const FAssetData& AssetData : AssetDataList)
	{
		SlowTask.EnterProgressFrame(1.0f, FText::Format(LOCTEXT("ResourceProcess.CheckingFilename", "Checking {0}"), FText::FromString(AssetData.GetFullName())));
		if (!bCheckFull && FResourceCheckHelper::HasTag(AssetData, FResourceCheckConfig::SkipCheckTag))
		{
			++SkippedNum;
			continue;
		}
		UE_LOG(LogKGResourceManager, Display, TEXT("Checking %d/%d: %s"), SkippedNum + CheckedNum, AssetDataList.Num(), *AssetData.PackageName.ToString())
		FString ClassPath = AssetData.AssetClassPath.ToString();
		bool bCheckResult = true;
		
		for (URuleBase* Rule : CheckRules)
		{
			if (IsRuleCheckForAsset(AssetData, Rule))
			{
				bCheckResult &= Rule->CheckOne(AssetData);
				++Rule->CheckedAssetNum;
			}
		}
		++CheckedNum;
		if (IsRunningCommandlet())
		{
			TriggerGCWhenNeed(Counter, true);
		}
		else
		{
			TriggerGCWhenNeed(Counter);
		}
	}
	return SkippedNum;
}

void UResourceCheckSubsystem::CheckAssetsByFunction(const TArray<FAssetData>& AssetDataList,ERMCheckRuleRange RMCheckRuleRange)
{
	InitRulesFromWeb(RMCheckRuleRange);

	CheckAssetsInternal(TSet<FAssetData>(AssetDataList));
}

void UResourceCheckSubsystem::CheckAssetsByContentMenu(const TArray<FAssetData>& AssetDataList)
{
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	if (!SourceControlProvider.IsEnabled())
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("未连接P4，执行资源检查之前请先连接P4")));
		return;
	}
	InitRulesFromWeb(ERMCheckRuleRange::SubmitCheck);

	int32 SkippedNum = CheckAssetsInternal(TSet<FAssetData>(AssetDataList));

	if (!ShowCheckResultsInWidget())
	{
		const FText Message = FText::Format(FText::FromString(TEXT("所选资产全部通过检查,资源总数:{0}个,共跳过{1}个")), AssetDataList.Num(), SkippedNum);
		FMessageDialog::Open(EAppMsgType::Ok, Message);
	}
}

void UResourceCheckSubsystem::RemoveAllResultsMessages()
{
	const TSharedPtr<SDockTab> MessageDockTab = FGlobalTabmanager::Get()->TryInvokeTab(ResourceCheckTabId);
	const TSharedRef<SResourceManagerTab> MessageWidget = StaticCastSharedRef<SResourceManagerTab>(MessageDockTab->GetContent());
	MessageWidget->RemoveAllMessages();
}

bool UResourceCheckSubsystem::ShowCheckResultsInWidget()
{
	TArray<FResourceCheckLogInfo> LogInfoList;
	for(const TWeakObjectPtr<URuleBase> RuleFunction : CheckRules)
	{
		LogInfoList.Append(RuleFunction->GetLogList());
	}

	if(LogInfoList.Num() > 0)
	{
		const TSharedPtr<SDockTab> MessageDockTab = FGlobalTabmanager::Get()->TryInvokeTab(ResourceCheckTabId);
		const TSharedRef<SResourceManagerTab> MessageWidget = StaticCastSharedRef<SResourceManagerTab>(MessageDockTab->GetContent());
		MessageWidget->RemoveAllMessages();
		for(auto& LogInfo : LogInfoList)
		{
			if(LogInfo.Level == ERMCheckRuleType::Warning || LogInfo.Level == ERMCheckRuleType::Error)
			{
				MessageWidget->AddMessage(LogInfo);
			}
		}
		return true;
	}
	return false;
}

void UResourceCheckSubsystem::RepairCheckedAssets()
{
	bool bRepairResult = false;
	bool bRemainError = false;
	for (auto Rule : CheckRules)
	{
		bRepairResult |= Rule->RepairAllPending();
		bRemainError |= Rule->Log.LogInfos.Num() > 0;
	}
	FText Message;
	if (bRepairResult)
	{
		if (bRemainError)
		{
			Message = FText::FromString(TEXT("部分资源已修复成功，剩下的错误请手动进行修复"));
			ShowCheckResultsInWidget();
		}
		else
		{
			RemoveAllResultsMessages();
			Message = FText::FromString(TEXT("全部资源修复成功"));
		}
	}
	else
	{
		Message = FText::FromString(TEXT("无法自动修复，请手动进行修复"));
	}
	FMessageDialog::Open(EAppMsgType::Ok, Message);
}

void UResourceCheckSubsystem::RepairAssetsByContentMenu(const TArray<FAssetData>& AssetDataList)
{
	CheckAssetsByContentMenu(AssetDataList);
	RepairCheckedAssets();
}
void UResourceCheckSubsystem::SaveRepairJsonData()
{
	FRMRepairJsonData RepairJsonData;
	for (TWeakObjectPtr<URuleBase> Rule : CheckRules)
	{
		TArray<FResourceCheckLogInfo> LogInfoList = Rule->GetLogList();
		FRMRuleRepairData RuleRepairData;
		bool HasRepairData = false;
		RuleRepairData.RuleName = Rule->RuleName;
		for (auto& LogInfo : LogInfoList)
		{
			if (LogInfo.bAutoRepair)
			{
				HasRepairData = true;
				FRMRepairDetail Detail;
				Detail.RepairParameters = LogInfo.RepairData.RepairParameters;
				Detail.bPropertyAutoRepair = LogInfo.RepairData.bPropertyAutoRepair;
				Detail.RepairFunctionName = LogInfo.RepairData.RepairFunctionName;
				Detail.RepairAssetPath = LogInfo.RepairData.RepairAssetData.GetSoftObjectPath().ToString();
				RuleRepairData.RepairDetailList.Add(Detail);
			}
		}
		if (HasRepairData)
		{
			RepairJsonData.RuleRepairDataList.Add(RuleRepairData);
		}
	}
	FString JsonString;

	if (const bool bJsonStringOk = FJsonObjectConverter::UStructToJsonObjectString(RepairJsonData, JsonString); !bJsonStringOk)
	{
		UE_LOG(LogKGResourceManager, Error, TEXT("Failed to convert FRMRepairJsonData to JSON"));
		return;
	}

	if (!FPaths::DirectoryExists(RepairJsonDataSaveDir))
	{
		FPlatformFileManager::Get().GetPlatformFile().CreateDirectoryTree(*RepairJsonDataSaveDir);
	}

	if (!FFileHelper::SaveStringToFile(JsonString, *RepairJsonDataSavePath))
	{
		UE_LOG(LogKGResourceManager, Error, TEXT("Failed to save JSON to file: %s"), *RepairJsonDataSavePath);
	}
}

void UResourceCheckSubsystem::LoadRepairJsonData(FRMRepairJsonData& OutRepairJsonData)
{
	if (IFileManager::Get().FileExists(*RepairJsonDataSavePath))
	{
		FString JsonString;
		if (!FFileHelper::LoadFileToString(JsonString, *RepairJsonDataSavePath))
		{
			return;
		}
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
		TSharedPtr<FJsonObject> JsonObject;
		if (!FJsonSerializer::Deserialize(Reader, JsonObject) || !JsonObject.IsValid())
		{
			return;
		}
		FJsonObjectConverter::JsonObjectToUStruct(JsonObject.ToSharedRef(), &OutRepairJsonData);
	}
}

TArray<FString> UResourceCheckSubsystem::DataCheck(const TArray<UObject*>& CheckObjects, TMap<FString, FString>& OutRepairParams)
{
	if (ResourceCheckLuaObj == nullptr)
	{
		CreateResourceCheckLuaObj(GetWorld());
	}
	UE_LOG(LogTemp, Log, TEXT("UResourceCheckSubsystem DataCheck."));
	return ResourceCheckLuaObj->DoDataCheck(CheckObjects, OutRepairParams);
}

bool UResourceCheckSubsystem::DataRepair(UObject* RepairObject, const TMap<FString, FString>& Arguments)
{
	if (ResourceCheckLuaObj == nullptr)
	{
		CreateResourceCheckLuaObj(GetWorld());
	}
	UE_LOG(LogTemp, Log, TEXT("UResourceCheckSubsystem DataRepair."));
	return ResourceCheckLuaObj->DoDataRepair(RepairObject, Arguments);
}

void UResourceCheckSubsystem::CreateResourceCheckLuaObj(UWorld* InWorld)
{
    LuaEnv = UEditorLuaEnv::CreateLuaEnv(UResourceCheckLuaObj::StaticClass());
    if (UResourceCheckLuaObj *_GameInstance = Cast<UResourceCheckLuaObj>(LuaEnv->GetLuaGameInstance()))
	{
		ResourceCheckLuaObj = _GameInstance;
		_GameInstance->Inner_OnStart();
	}
}

void UResourceCheckSubsystem::ShutDownLuaState()
{
    if (LuaEnv)
	{
        UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
	}
	ResourceCheckLuaObj = nullptr;
}

void UResourceCheckSubsystem::CollectRuleReport(TWeakObjectPtr<URuleBase> RuleFunction, FRMRuleReport& RuleReport)
{
	TMap<FString, int32> ResourcePathToIndex;
	TMap<FString, int32> TagToIndex;
	TArray<FResourceCheckLogInfo> LogInfoList = RuleFunction->GetLogList();

	RuleReport.CheckAssetCount = RuleFunction->GetCheckedAssetNum();
	RuleReport.ProjectRuleConfigId = RuleFunction->ResCheckWebData.Id;

	int32 bCheckSuccess = 1;
	
	for(auto LogInfo :LogInfoList)
	{
		int32 Index = 0;
		if(LogInfo.Level == ERMCheckRuleType::Error)
		{
			bCheckSuccess = 0;
		}		
		if(ResourcePathToIndex.Contains(LogInfo.ResourcePath))
		{
			Index = ResourcePathToIndex[LogInfo.ResourcePath];
		}
		else
		{
			FRMReportDetail ReportDetail = FRMReportDetail();

			auto ResourcePath = LogInfo.ResourcePath;

			ReportDetail.Resource = LogInfo.ResourcePath;		
			RuleReport.DetailParam = RuleFunction->GetLogTags();
			RuleReport.DetailParam.Add("Tag");
			for(int32 ParamIndex = 0; ParamIndex < RuleReport.DetailParam.Num(); ParamIndex++)
			{
				TagToIndex.FindOrAdd(RuleReport.DetailParam[ParamIndex]) = ParamIndex; 
			}
			ReportDetail.ParamContentDetail.Init(TEXT(""), RuleReport.DetailParam.Num());
			ReportDetail.ParamContentDetail[ReportDetail.ParamContentDetail.Num() - 1] = FResourceCheckHelper::GetEditorTagContent(LogInfo.AssetData);
			
			RuleReport.ReportDetailList.Add(ReportDetail);
			Index = RuleReport.ReportDetailList.Num() - 1;
			ResourcePathToIndex.FindOrAdd(LogInfo.ResourcePath) = Index;
		}
		//添加Tag
		FRMReportDetail& ReportDetail = RuleReport.ReportDetailList[Index];

		//新规则添加		
		if(TagToIndex.Contains(LogInfo.Tag))
		{
			int32 TagIndex = TagToIndex[LogInfo.Tag];
			FString& Desc = ReportDetail.ParamContentDetail[TagIndex];
			if(Desc.Len() > 0)
			{
				Desc += TEXT("\n");
			}

			Desc += LogInfo.Description;
		}
	}
	
	RuleReport.CheckPass = bCheckSuccess;
}

void UResourceCheckSubsystem::CheckAssetsByCommandlet(TArray<FString>& EnableRules)
{
	// step 1.拿到所有的检查规则
	InitRulesFromWeb(ERMCheckRuleRange::ResourceCheck, EnableRules);
	
	// step 2.收集需要检查的所有资源
	TMap<UClass*, TArray<URuleBase*>> ClassToRuleMap;
	TSet<URuleBase*> ActorRules;
	for (URuleBase* Rule : CheckRules)
	{
		if (Rule->GetAssetType() && Rule->GetAssetType()->IsChildOf(AActor::StaticClass()))
		{
			ActorRules.Add(Rule);
			continue;
		}
		TArray<URuleBase*>& Rules = ClassToRuleMap.FindOrAdd(Rule->GetAssetType());
		Rules.Add(Rule);
	}
	TArray<FAssetData> AssetDataList;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

	for (auto ClassRule : ClassToRuleMap)
	{
		TArray<FAssetData> OutAssetData;
		FARFilter Filter;
		Filter.ClassPaths.Add(ClassRule.Key->GetClassPathName());
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;
		for (auto Rule : ClassRule.Value)
		{
			Filter.PackagePaths.Append(Rule->CheckPaths);
		}
		AssetRegistry.GetAssets(Filter, OutAssetData);
		TArray<FAssetData> NeedCheckAssetDataList;
		for (auto AssetData : OutAssetData)
		{
			// 过滤Package的内部object，只检查package本身对应的主object
			if (AssetData.PackageName.ToString().StartsWith("/Game/__ExternalActors__") || FPaths::Combine(AssetData.PackagePath.ToString(), AssetData.AssetName.ToString()) == AssetData.PackageName.ToString())
			{
				NeedCheckAssetDataList.Add(AssetData);
			}
		}
		UE_LOG(LogKGResourceManager, Display, TEXT("CheckAssetsByFull Assets %s: %d"), *ClassRule.Key->GetName(), NeedCheckAssetDataList.Num());
		AssetDataList.Append(NeedCheckAssetDataList);
	}
	
	// step 3.逐项检查

	// 检查非actor的资源
	CheckAssetsInternal(TSet<FAssetData>(AssetDataList), true);

	// 检查actor资源
	CheckWPActorsByCommandlet(ActorRules);
	CheckWCActorsByCommandlet(ActorRules);
	
	// 保存检查结果
	TArray<FRMRuleReport> RuleReportList = TArray<FRMRuleReport>();
	FResourceCheckLogCollect LogCollect;
	for (TWeakObjectPtr<URuleBase> RuleFunction : CheckRules)
	{
		FRMRuleReport RuleReport;
		CollectRuleReport(RuleFunction, RuleReport);
		RuleReportList.Add(RuleReport);
	}

	bool Created = FResourceCheckUtility::CreateProjectReport(RuleReportList);
	if (!Created)
	{
		UE_LOG(LogTemp, Error, TEXT("CreateProjectReport Failed"));
	}

	// 保存修复用数据
	SaveRepairJsonData();
}

TArray<FString> UResourceCheckSubsystem::GetNeedCheckActorsPaths(const TSet<URuleBase*>& ActorRules)
{
	TArray<FString> CheckPaths;
	for (URuleBase* ActorRule : ActorRules)
	{
		if (ActorRule == nullptr)
		{
			continue;
		}
		for (FString Path : ActorRule->CheckPaths)
		{
			if (!Path.StartsWith(TEXT("/Game/__ExternalActors__")))
			{
				continue;
			}
			if (!Path.EndsWith(TEXT("/")))
			{
				Path += TEXT("/");
			}
			CheckPaths.AddUnique(Path);
		}
	}
	CheckPaths.Sort();
	TArray<FString> Result;
	for (const FString& Path : CheckPaths)
	{
		// 跳过与上一个结果相同的路径（去重）
		if (Result.Num() > 0 && Result.Last().Equals(Path))
		{
			continue;
		}
        
		// 如果当前路径是结果集中某个路径的子目录，则跳过
		bool bIsCovered = false;
		for (const FString& ExistingPath : Result)
		{
			if (Path.StartsWith(ExistingPath))
			{
				bIsCovered = true;
				break;
			}
		}
        
		if (!bIsCovered)
		{
			Result.Add(Path);
		}
	}
	return Result;
}

void UResourceCheckSubsystem::CheckWPActorsByCommandlet(const TSet<URuleBase*>& ActorRules)
{
	TArray<FString> CheckPaths = GetNeedCheckActorsPaths(ActorRules);
	TArray<FString> AllFilesAndDirs;
	for (FString Path : CheckPaths)
	{
		TArray<FString> FileNames;
		FString RootPath = FPaths::Combine(FPaths::ProjectContentDir(), Path.Mid(6)); // /Game/
		IFileManager::Get().FindFilesRecursive(FileNames, *RootPath, TEXT("*"), true, false, false);
		AllFilesAndDirs.Append(FileNames);
	}
	TArray<FString> AllMaps;
	for (const FString& FileName : AllFilesAndDirs)
	{
		FString Prefix = TEXT("/Client/Content/__ExternalActors__");
		int32 PrefixIndex = FileName.Find(Prefix);
		if (PrefixIndex != INDEX_NONE)
		{
			FString MapName = FileName.Mid(PrefixIndex + Prefix.Len());
			int32 LastSlashIndex = 0;
			for (int32 i = 0; i < 3; ++i)
			{
				MapName.FindLastChar('/', LastSlashIndex);
				if (LastSlashIndex == INDEX_NONE)
				{
					break;
				}
				MapName = MapName.Left(LastSlashIndex);
			}
			if (LastSlashIndex == INDEX_NONE)
			{
				continue;
			}
			MapName = TEXT("/Game") + MapName;
			AllMaps.AddUnique(MapName);
		}
	}
	AllMaps.Sort();
	int32 SkippedNum, CheckedNum, CheckedMapCount = 0;
	int32 WorldNum = AllMaps.Num();
	for (const FString& MapName : AllMaps)
	{
		CheckedMapCount++;
		UE_LOG(LogTemp, Display, TEXT("Check Map %d/%d: %s"), CheckedMapCount, WorldNum, *MapName);
		CheckActorsByMapName(MapName, SkippedNum, CheckedNum);
		CollectGarbage(RF_NoFlags);
	}
}

void UResourceCheckSubsystem::CheckWCActorsByCommandlet(const TSet<URuleBase*>& ActorRules)
{
	TArray<FString> CheckPaths;
	for (URuleBase* ActorRule : ActorRules)
	{
		if (ActorRule == nullptr)
		{
			continue;
		}
		for (FString Path : ActorRule->CheckPaths)
		{
			if (Path.StartsWith(TEXT("/Game/__ExternalActors__")))
			{
				continue;
			}
			if (!Path.EndsWith(TEXT("/")))
			{
				Path += TEXT("/");
			}
			CheckPaths.AddUnique(Path);
		}
	}
	CheckPaths.Sort();
	TArray<FString> Result;
	for (const FString& Path : CheckPaths)
	{
		// 跳过与上一个结果相同的路径（去重）
		if (Result.Num() > 0 && Result.Last().Equals(Path))
		{
			continue;
		}
        
		// 如果当前路径是结果集中某个路径的子目录，则跳过
		bool bIsCovered = false;
		for (const FString& ExistingPath : Result)
		{
			if (Path.StartsWith(ExistingPath))
			{
				bIsCovered = true;
				break;
			}
		}
        
		if (!bIsCovered)
		{
			Result.Add(Path);
		}
	}
	if (Result.IsEmpty())
	{
		return;
	}
	TArray<FAssetData> OutAssetData;
	FARFilter Filter;
	Filter.ClassPaths.Add(UWorld::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	Filter.PackagePaths.Append(Result);
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	AssetRegistry.GetAssets(Filter, OutAssetData);
	int32 SkippedNum, CheckedNum, CheckedMapCount = 0;
	for (const FAssetData& AssetData : OutAssetData)
	{
		CheckedMapCount++;
		UWorld* World = Cast<UWorld>(AssetData.GetAsset());
		if (World == nullptr)
		{
			continue;
		}
		if (World->IsPartitionedWorld())
		{
			continue;
		}
		FString MapName = AssetData.PackageName.ToString();
		UE_LOG(LogTemp, Display, TEXT("Check Map %d/%d: %s"), CheckedMapCount, OutAssetData.Num(), *MapName);
		CheckActorsByMapName(MapName, SkippedNum, CheckedNum);
		int32 Counter = 999;
		TriggerGCWhenNeed(Counter, true);
	}
}

void UResourceCheckSubsystem::CheckActorsByMapName(const FString& MapName, int32& SkippedNum, int32& CheckedNum)
{
	FString WorldLongPackageName;
	FString WorldFilename;
	if (!FPackageName::SearchForPackageOnDisk(MapName, &WorldLongPackageName, &WorldFilename))
	{
		return;
	}

	// Load the world package
	UPackage* WorldPackage = LoadWorldPackageForEditor(WorldLongPackageName);
	if (!WorldPackage)
	{
		return;
	}

	// Find the world in the given package
	UWorld* World = UWorld::FindWorldInPackage(WorldPackage);
	if (!World)
	{
		return;
	}
	FString WorldConfigFilename = FPackageName::LongPackageNameToFilename(World->GetPackage()->GetName(), TEXT(".ini"));
	if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*WorldConfigFilename))
	{
		LoadConfig(GetClass(), *WorldConfigFilename);
	}
	UWorld::InitializationValues IVS;
	{
		IVS.RequiresHitProxies(false);
		IVS.ShouldSimulatePhysics(false);
		IVS.EnableTraceCollision(false);
		IVS.CreateNavigation(true);
		IVS.CreateAISystem(false);
		IVS.AllowAudioPlayback(false);
		IVS.CreatePhysicsScene(true);
	}

	
	if (World->IsPartitionedWorld())
	{
		TUniquePtr<FScopedEditorWorld> EditorSourceWorld;
		if (World->bIsWorldInitialized == false)
		{
			EditorSourceWorld = MakeUnique<FScopedEditorWorld>(World, IVS);
		}

		TUniquePtr<FLoaderAdapterShape> LoaderAdapterShape;
		// LoadDataLayers(World);

		static const FBox BoxEntireWorld = FBox(FVector(-HALF_WORLD_MAX, -HALF_WORLD_MAX, -HALF_WORLD_MAX), FVector(HALF_WORLD_MAX, HALF_WORLD_MAX, HALF_WORLD_MAX));
		LoaderAdapterShape = MakeUnique<FLoaderAdapterShape>(World, BoxEntireWorld, TEXT("Loaded Region"));
		LoaderAdapterShape->Load();
		FStaticMeshCompilingManager::Get().FinishAllCompilation();
		FWorldPartitionHelpers::FakeEngineTick(World);
		UWorldPartition* WorldPartition = World->GetWorldPartition();

		FWorldPartitionHelpers::FForEachActorWithLoadingResult Result;
		FWorldPartitionHelpers::FForEachActorWithLoadingParams Params;

		Params.ActorClasses = {AActor::StaticClass()};
		Params.bKeepReferences = false;

		FWorldPartitionHelpers::ForEachActorWithLoading(
			WorldPartition,
			[this, &SkippedNum, &CheckedNum](
			const FWorldPartitionActorDescInstance* ActorDescInstance)
			{
				if (const AActor* Actor = ActorDescInstance->GetActor())
				{
					CheckActor(Actor, SkippedNum, CheckedNum);
				}
				return true;
			}, Params);
	}
	else
	{
		for (auto Actor : World->PersistentLevel->Actors)
		{
			if (Actor)
			{
				CheckActor(Actor, SkippedNum, CheckedNum);
			}
		}
	}
}

void UResourceCheckSubsystem::CheckActor(const AActor* InActor, int32& SkippedNum, int32& CheckedNum)
{
	if (InActor == nullptr)
	{
		return;
	}
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FAssetData AssetData = AssetRegistryModule.Get().GetAssetByObjectPath(InActor->GetPathName());
	UE_LOG(LogKGResourceManager, Display, TEXT("Checking %d: %s"), SkippedNum + CheckedNum, *AssetData.PackageName.ToString())
	if (FResourceCheckHelper::HasTag(AssetData, FResourceCheckConfig::SkipCheckTag))
	{
		++SkippedNum;
		return;
	}
	FString ClassPath = AssetData.AssetClassPath.ToString();
	bool bCheckResult = true;
		
	for (URuleBase* Rule : CheckRules)
	{
		if (IsRuleCheckForAsset(AssetData, Rule))
		{
			bCheckResult &= Rule->CheckOne(AssetData);
			++Rule->CheckedAssetNum;
		}
	}
	++CheckedNum;
}

void UResourceCheckSubsystem::RepairAssetsByCommandlet(TArray<FString>& EnableRules)
{
	UE_LOG(LogKGResourceManager, Display, TEXT("Start Repair Assets By Commandlet"));
	InitRulesFromWeb(ERMCheckRuleRange::ResourceCheck, EnableRules);
	FRMRepairJsonData RepairJsonData;
	LoadRepairJsonData(RepairJsonData);
	auto GetRuleByName = [this](const FString& RuleName)
	{
		URuleBase* OutRule = nullptr;
		for (const TObjectPtr<URuleBase>& Rule : CheckRules)
		{
			if (Rule->RuleName == RuleName)
			{
				return Rule.Get();
			}
		}
		return OutRule;
	};
	TSet<FString> SuccessRepairAssetes;
	TSet<FString> FailedRepairAssetes;	
	for (auto JsonData : RepairJsonData.RuleRepairDataList)
	{
		UE_LOG(LogKGResourceManager, Display, TEXT("Repair %d Error by rule: %s"), JsonData.RepairDetailList.Num(), *JsonData.RuleName)
		if (URuleBase* Rule = GetRuleByName(JsonData.RuleName))
		{
			Rule->RepairByJsonData(JsonData, SuccessRepairAssetes, FailedRepairAssetes);
		}
	}

	FString JsonString;
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject);
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonString);

	TArray<TSharedPtr<FJsonValue>> SuccessJsonArray;
	for (auto SuccessRepairAsset : SuccessRepairAssetes)
	{
		SuccessJsonArray.Add(MakeShareable(new FJsonValueString(SuccessRepairAsset)));
	}
	JsonObject->SetArrayField(TEXT("Success"), SuccessJsonArray);

	TArray<TSharedPtr<FJsonValue>> FailedJsonArray;
	for (auto FailedRepairAsset : FailedRepairAssetes)
	{
		SuccessJsonArray.Add(MakeShareable(new FJsonValueString(FailedRepairAsset)));
	}
	JsonObject->SetArrayField(TEXT("Failed"), FailedJsonArray);
	
	if (!FPaths::DirectoryExists(RepairJsonDataSaveDir))
	{
		FPlatformFileManager::Get().GetPlatformFile().CreateDirectoryTree(*RepairJsonDataSaveDir);
	}
	if (FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer))
	{
		if (!FFileHelper::SaveStringToFile(JsonString, *RepairJsonResultSavePath))
		{
			UE_LOG(LogKGResourceManager, Display, TEXT("Repaired %d Assets; Success : %d; Failed : %d Assets."), SuccessRepairAssetes.Num() + FailedRepairAssetes.Num() , SuccessRepairAssetes.Num(), FailedRepairAssetes.Num());
		}
	}
	
}

UWorld* UResourceCheckSubsystem::GetMessageTabWorld()
{
	if (!MessageTabWorld)
	{
		MessageTabWorld = UWorld::CreateWorld(EWorldType::Inactive, false, TEXT("ResourceCheckInTab"), GetTransientPackage(), false);
	}
	return MessageTabWorld;
}

void UResourceCheckSubsystem::CheckAssetsByPreSubmit(const TArray<FAssetData>& InFiles, const TSharedPtr<FPerforceSourceControlProviderDelegatesPackage>& InPackage)
{
	if (!bSubmitEnabled)
	{
		return;
	}
	InitRulesFromWeb(ERMCheckRuleRange::SubmitCheck); // 这儿会初始化 BranchName
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();

	//跳过指定分支的提交检查
	TArray<FString> IgnoreBranch; 
	GConfig->GetArray(TEXT("ResourceCheck"), TEXT("IgnoreBranch"), IgnoreBranch, GEditorIni);
	if(IgnoreBranch.Contains(BranchName))
	{
		return;
	}
	
	TArray<FAssetData> AssetDataList;
	for(auto& File : InFiles)
	{
		FString AbsoultePath = FResourceCheckHelper::GetAbsoultePath(File);
		if(AbsoultePath != TEXT("None"))
		{
			FSourceControlStatePtr SourceControlState = SourceControlProvider.GetState(AbsoultePath, EStateCacheUsage::Use);
			if(!SourceControlState->IsDeleted())
			{
				AssetDataList.Add(File);
			}
		}
	}
	for (TWeakObjectPtr<URuleBase> CheckRule : CheckRules)
	{
		CheckRule->PreCheckIn(AssetDataList, InPackage);
	}
	CheckAssetsInternal(TSet<FAssetData>(AssetDataList));
	for(const TWeakObjectPtr<URuleBase> RuleFunction : CheckRules)
	{
		if (RuleFunction->HasErrorLog())
		{
			InPackage->Result = ECommandResult::Failed;
			break;
		}
	}
	ShowCheckResultsInWidget();
}

void UResourceCheckSubsystem::OnPostAssetsSubmit(const TArray<FAssetData>& InFiles, const TSharedPtr<FPerforceSourceControlProviderDelegatesPackage>& InPackage)
{
	if (!bSubmitEnabled)
	{
		return;
	}
	for(const TWeakObjectPtr<URuleBase> RuleFunction : CheckRules)
	{
		RuleFunction->PostCheckIn(InFiles, InPackage);
	}
	
	if(InPackage->Result == ECommandResult::Failed)
	{
		ShowCheckResultsInWidget();
	}
}

#undef LOCTEXT_NAMESPACE