#include "ResourceDensity/ResourceDensityCommandlet.h"

#include "ResourceDensity/ResourceDensityManager.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"

UResourceDensityCommandlet::UResourceDensityCommandlet()
{
	
}

int32 UResourceDensityCommandlet::Main(const FString& Params)
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	AssetRegistryModule.Get().SearchAllAssets(true);

	const TSharedPtr<FResourceDensityManager> ResourceDensityManager = MakeShared<FResourceDensityManager>();
	ResourceDensityManager->CalculateDensity();
	return 0;
}