#include "ResourceDensity/ResourceDensityManager.h"

#include "ResourceDensity/ResourceDensityCalculator.h"
#include "ResourceDensity/StaticMeshDensityCalculator.h"
#include "ResourceDensity/TextureDensityCalculator.h"

void FResourceDensityManager::CalculateDensity()
{
	TArray<TSharedPtr<FResourceDensityCalculator>> DensityCalculators;
	// DensityCalculators.Add(MakeShared<FTextureDensityCalculator>());
	DensityCalculators.Add(MakeShared<FStaticMeshDensityCalculator>());
	for (TSharedPtr<FResourceDensityCalculator> DensityCalculator : DensityCalculators)
	{
		DensityCalculator->CalculateAll();
		DensityCalculator->ExportResults();
	}
}
