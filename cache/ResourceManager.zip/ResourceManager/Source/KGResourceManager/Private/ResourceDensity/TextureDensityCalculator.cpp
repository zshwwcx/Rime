#include "ResourceDensity/TextureDensityCalculator.h"


UClass* FTextureDensityCalculator::GetResourceClass()
{
	return UTexture::StaticClass();
}

void FTextureDensityCalculator::CalculateOne(const FAssetData& AssetData)
{
	
}
