#include "ResourceDensity/StaticMeshDensityCalculator.h"

#include "EditorUtilityLibrary.h"
#include "ISourceControlModule.h"
#include "ISourceControlOperation.h"
#include "SourceControlOperations.h"

#include "SourceControlHelpers.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"
#include "Materials/MaterialExpressionTextureBase.h"
#include "Materials/MaterialInstanceConstant.h"


FString FStaticMeshDensityData::GetCSVHeader(EStaticMeshDensityType DensityType)
{
	UEnum* StaticMeshDensityTypeEnum = StaticEnum<EStaticMeshDensityType>();
	FText EnumName = StaticMeshDensityTypeEnum->GetDisplayNameTextByValue(static_cast<int32>(DensityType));
	return FString::Printf(TEXT("Mesh Name, Triangles, %s, Last Submitted By, Mean, Median,"), *EnumName.ToString());
}

FString FStaticMeshDensityData::ToCSVString(EStaticMeshDensityType DensityType) const
{
	float OutAreaDensity = LodAreaDensities.IsEmpty() ? 0.f : LodAreaDensities[0];
	float OutVolumeDensity = LodVolumeDensities.IsEmpty() ? 0.f : LodVolumeDensities[0];
	float OutUVRate = LodUVUtilizationRate.IsEmpty() ? 0.f : LodUVUtilizationRate[0];
	float OutPixelDensity = LodPixelDensities.IsEmpty() ? 0.f : LodPixelDensities[0];

	float Density = 0.f;
	switch (DensityType)
	{
	case EStaticMeshDensityType::Area:
		Density = OutAreaDensity;
		break;
	case EStaticMeshDensityType::Volume:
		Density = OutVolumeDensity;
		break;
	case EStaticMeshDensityType::UVRate:
		Density = OutUVRate;
		break;
	case EStaticMeshDensityType::Pixel:
		Density = OutPixelDensity;
		break;
	}

	FString Line = FString::Format(TEXT("{0}, {1}, {2}, {3}"), {PackageName, Triangles, Density, UserName});
	return Line;
}

UClass* FStaticMeshDensityCalculator::GetResourceClass()
{
	return UStaticMesh::StaticClass();
}

void FStaticMeshDensityCalculator::CalculateOne(const FAssetData& AssetData)
{
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(AssetData.GetAsset());
	if (!StaticMesh)
	{
		return;
	}
	FStaticMeshDensityData DensityData;
	DensityData.PackageName = AssetData.PackageName.ToString();

	DensityData.UserName = "Unknown";
	// Make sure our history is up to date
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	TSharedRef<FUpdateStatus, ESPMode::ThreadSafe> UpdateStatusOperation = ISourceControlOperation::Create<FUpdateStatus>();
	UpdateStatusOperation->SetUpdateHistory(true);
	SourceControlProvider.Execute(UpdateStatusOperation, SourceControlHelpers::PackageFilename(DensityData.PackageName));

	TSet<FString> WhiteUsers = {"teamcity", "chengfeng", "muyanke", "chengwenhua"};
	bool bFoundUserName = false;

	// Get the SCC state
	FSourceControlStatePtr SourceControlState = SourceControlProvider.GetState(SourceControlHelpers::PackageFilename(DensityData.PackageName), EStateCacheUsage::Use);
	if (SourceControlState->GetHistorySize() > 0)
	{
/*
同模块里的 NSAssetChecker 里的 Timer 会使用 \Windows Kits\10\Include\10.0.20348.0\um\WinBase.h, 其中有下列代码:
# line 7445:
	#ifdef UNICODE
	#define GetUserName  GetUserNameW
	#else
	#define GetUserName  GetUserNameA
	#endif // !UNICODE
这会导致 GetUserName 被 WinBase.h 里的预编译指令给替换掉，引起全量编译时报错。
微软竟然把这么常见的一个名称包成了宏。
UE 官方也遇到过同样的问题，在 PlasticSourceControlShell.cpp Line21, 直接 undef GetUserName 了。
我这里将只在这里代码局部 undef GetUserName, 不影响全局。
*/	
UE_PUSH_MACRO("GetUserName")
#undef GetUserName
		for (int32 i = 0; i < SourceControlState->GetHistorySize(); i++)
		{
			TSharedPtr<ISourceControlRevision, ESPMode::ThreadSafe> Revision = SourceControlState->GetHistoryItem(i);
			FString UserName = "Unknown";// Revision->GetUserName(); 
			if (!WhiteUsers.Contains(UserName))
			{
				DensityData.UserName = "Unknown"; //Revision->GetUserName();
				bFoundUserName = true;
				break;
			}
		}
UE_POP_MACRO("GetUserName")
	}

	if (!bFoundUserName)
	{
		TArray<FString> BranchNames = {
			"//C7/Development/Mainline/Client/Content",
			"//C7/Development/HZDev/Client/Content",
			"//C7/Development/CGDev/Client/Content",
			"//C7/Development/EngineDev/Client/Content",
			"//C7/QA/TBT2_2024_08/Client/Content"
		};
		for (int32 i = 0; i < BranchNames.Num(); i++)
		{
			FString FileName = BranchNames[i] + DensityData.PackageName.Right(DensityData.PackageName.Len() - 5) + ".uasset";
			FString Cmd = FString::Printf(TEXT("-C utf8 changes -m 5 %s"), *FileName);
			FString Process = TEXT("p4");

			int32 ResultCode;
			FString Result;
			FString ResultErr;

			bool bProcessSuccess = FPlatformProcess::ExecProcess(*Process, *Cmd, &ResultCode, &Result, &ResultErr);
			if (bProcessSuccess && Result != TEXT(""))
			{
				TArray<FString> SplitStrings;
				Result.TrimStartAndEnd().ParseIntoArray(SplitStrings, TEXT("\n"), false);
				for(auto SplitString : SplitStrings)
				{
					int32 FirstIndex = SplitString.Find(TEXT("by")) + 2;
					int32 LastIndex = SplitString.Find(TEXT("@"));
					FString UserName = SplitString.Mid(FirstIndex + 1, LastIndex - FirstIndex - 1);
					if (!WhiteUsers.Contains(UserName))
					{
						DensityData.UserName = UserName;
						bFoundUserName = true;
						break;
					}
				}
				if (bFoundUserName)
				{
					break;
				}
			}
		}
	}

	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FName> AssetReferencers;
	AssetRegistryModule.Get().GetReferencers(AssetData.PackageName, AssetReferencers, UE::AssetRegistry::EDependencyCategory::All);
	DensityData.bHasReferencedObjects = AssetReferencers.Num() > 0;

	if (CalculateDensity(StaticMesh, DensityData))
	{
		StaticMeshDensities.Add(DensityData);
	}
}

void FStaticMeshDensityCalculator::CalculateMean()
{
	float AreaSum = 0.f;
	int32 AreaCount = 0;
	float VolumeSum = 0.f;
	int32 VolumeCount = 0;
	float UVRateSum = 0.f;
	int32 UVRateCount = 0;
	float PixelDensitySum = 0.f;
	int32 PixelDensityCount = 0;
	for (const FStaticMeshDensityData& DensityData : StaticMeshDensities)
	{
		if (DensityData.LodAreaDensities.Num() > 0 && DensityData.LodAreaDensities[0] > 0.f)
		{
			AreaSum += DensityData.LodAreaDensities[0];
			AreaCount++;
		}
		if (DensityData.LodVolumeDensities.Num() > 0 && DensityData.LodVolumeDensities[0] > 0.f)
		{
			VolumeSum += DensityData.LodVolumeDensities[0];
			VolumeCount++;
		}
		if (DensityData.LodUVUtilizationRate.Num() > 0 && DensityData.LodUVUtilizationRate[0] > 0.f)
		{
			UVRateSum += DensityData.LodUVUtilizationRate[0];
			UVRateCount++;
		}
		if (DensityData.LodPixelDensities.Num() > 0 && DensityData.LodPixelDensities[0] > 0.f)
		{
			PixelDensitySum += DensityData.LodPixelDensities[0];
			PixelDensityCount++;
		}
	}
	AreaMean = AreaCount > 0 ? AreaSum / AreaCount : 0.f;
	VolumeMean = VolumeCount > 0 ? VolumeSum / VolumeCount : 0.f;
	UVRateMean = UVRateCount > 0 ? UVRateSum / UVRateCount : 0;
	PixelDensityMean = PixelDensityCount > 0 ? PixelDensitySum / PixelDensityCount : 0;
}

void FStaticMeshDensityCalculator::ExportResults()
{
	FString SaveDir = FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("ResourceManager"));
	if (!IFileManager::Get().MakeDirectory(*SaveDir, true))
	{
		UE_LOG(LogKGResourceManager, Error, TEXT("Failed to create directory: %s"), *SaveDir);
		return;
	}

	auto SavaDensity = [this, &SaveDir](EStaticMeshDensityType DensityType)
	{
		float Mean = 0.f;
		float Median = 0.f;
		FString FileName;
		switch (DensityType)
		{
		case EStaticMeshDensityType::Area:
			FileName = TEXT("StaticMeshAreaDensity.csv");
			Mean = AreaMean;
			StaticMeshDensities.Sort([](const FStaticMeshDensityData& A, const FStaticMeshDensityData& B)
			{
				return A.LodAreaDensities[0] > B.LodAreaDensities[0];
			});
			Median = StaticMeshDensities[StaticMeshDensities.Num() / 2].LodAreaDensities[0];
			break;
		case EStaticMeshDensityType::Volume:
			FileName = TEXT("StaticMeshVolumeDensity.csv");
			Mean = VolumeMean;
			StaticMeshDensities.Sort([](const FStaticMeshDensityData& A, const FStaticMeshDensityData& B)
			{
				return A.LodVolumeDensities[0] > B.LodVolumeDensities[0];
			});
			Median = StaticMeshDensities[StaticMeshDensities.Num() / 2].LodVolumeDensities[0];
			break;
		case EStaticMeshDensityType::UVRate:
			FileName = TEXT("StaticMeshUVRateDensity.csv");
			Mean = UVRateMean;
			StaticMeshDensities.Sort([](const FStaticMeshDensityData& A, const FStaticMeshDensityData& B)
			{
				if ((A.LodUVUtilizationRate[0] == 0.f || A.LodUVUtilizationRate[0] == -1.f) && B.LodUVUtilizationRate[0] > 0.f)
				{
					return false;
				}
				if ((B.LodUVUtilizationRate[0] == 0.f || B.LodUVUtilizationRate[0] == -1.f) && A.LodUVUtilizationRate[0] > 0.f)
				{
					return true;
				}
				return A.LodUVUtilizationRate[0] < B.LodUVUtilizationRate[0];
			});
			Median = StaticMeshDensities[StaticMeshDensities.Num() / 2].LodUVUtilizationRate[0];
			break;
		case EStaticMeshDensityType::Pixel:
			FileName = TEXT("StaticMeshPixelDensity.csv");
			Mean = PixelDensityMean;
			StaticMeshDensities.Sort([](const FStaticMeshDensityData& A, const FStaticMeshDensityData& B)
			{
				return A.LodPixelDensities[0] > B.LodPixelDensities[0];
			});
			Median = StaticMeshDensities[StaticMeshDensities.Num() / 2].LodPixelDensities[0];
			break;
		}
		TArray<FString> CSVLines;
		CSVLines.Add(FStaticMeshDensityData::GetCSVHeader(DensityType));

		for (const FStaticMeshDensityData& DensityData : StaticMeshDensities)
		{
			FString Line = DensityData.ToCSVString(DensityType);
			Line += FString::Printf(TEXT(", %f, %f"), Mean, Median);
			CSVLines.Add(Line);
		}
		const FString CSVContent = FString::Join(CSVLines, TEXT("\n"));


		const FString FilePath = FPaths::Combine(SaveDir, FileName);
		if (!FFileHelper::SaveStringToFile(CSVContent, *FilePath))
		{
			UE_LOG(LogKGResourceManager, Error, TEXT("Failed to save CSV file: %s"), *FilePath);
		}
	};

	CalculateMean();

	SavaDensity(EStaticMeshDensityType::Area);
	SavaDensity(EStaticMeshDensityType::Volume);
	SavaDensity(EStaticMeshDensityType::UVRate);
	SavaDensity(EStaticMeshDensityType::Pixel);
}

float FStaticMeshDensityCalculator::GetArea(const FStaticMeshLODResources& LODResource)
{
	double Area = 0.0;
	const FPositionVertexBuffer& VertexBuffer = LODResource.VertexBuffers.PositionVertexBuffer;
	const FRawStaticIndexBuffer& IndexBuffer = LODResource.IndexBuffer;
	int32 NumIndices = IndexBuffer.GetNumIndices();
	for (int32 i = 0; i < NumIndices; i += 3)
	{
		FVector3f Vertex0 = VertexBuffer.VertexPosition(IndexBuffer.GetIndex(i));
		FVector3f Vertex1 = VertexBuffer.VertexPosition(IndexBuffer.GetIndex(i + 1));
		FVector3f Vertex2 = VertexBuffer.VertexPosition(IndexBuffer.GetIndex(i + 2));

		float TriangleArea = 0.5f * FVector3f::CrossProduct(Vertex1 - Vertex0, Vertex2 - Vertex0).Size();
		Area += TriangleArea;
	}
	return Area;
}

bool IsPointInTriangle(FVector2D A, FVector2D B, FVector2D C, FVector2D P)
{
	// Compute vectors
	FVector2D v0 = {C.X - A.X, C.Y - A.Y};
	FVector2D v1 = {B.X - A.X, B.Y - A.Y};
	FVector2D v2 = {P.X - A.X, P.Y - A.Y};

	// Compute dot products
	float dot00 = v0.X * v0.X + v0.Y * v0.Y;
	float dot01 = v0.X * v1.X + v0.Y * v1.Y;
	float dot02 = v0.X * v2.X + v0.Y * v2.Y;
	float dot11 = v1.X * v1.X + v1.Y * v1.Y;
	float dot12 = v1.X * v2.X + v1.Y * v2.Y;

	// Compute barycentric coordinates
	float invDenom = 1 / (dot00 * dot11 - dot01 * dot01);
	float u = (dot11 * dot02 - dot01 * dot12) * invDenom;
	float v = (dot00 * dot12 - dot01 * dot02) * invDenom;

	// Check if point is in triangle
	return (u >= 0) && (v >= 0) && (u + v <= 1);
}

void MarkTriangleOnGrid(FVector2D UV1, FVector2D UV2, FVector2D UV3, TArray<TArray<bool>>& OutGrid)
{
	const int GridSize = OutGrid.Num();
	double CellSize = 1.0f / GridSize;

	// Calculate bounding box of the triangle
	double MinU = std::min({UV1.X, UV2.X, UV3.X});
	double MaxU = std::max({UV1.X, UV2.X, UV3.X});
	double MinV = std::min({UV1.Y, UV2.Y, UV3.Y});
	double MaxV = std::max({UV1.Y, UV2.Y, UV3.Y});

	// Convert bounding box to grid coordinates
	int MinX = std::max(0, static_cast<int>(MinU / CellSize));
	int MaxX = std::min(GridSize - 1, static_cast<int>(MaxU / CellSize));
	int MinY = std::max(0, static_cast<int>(MinV / CellSize));
	int MaxY = std::min(GridSize - 1, static_cast<int>(MaxV / CellSize));

	// Iterate only over the grid cells within the bounding box
	for (int y = MinY; y <= MaxY; ++y)
	{
		for (int x = MinX; x <= MaxX; ++x)
		{
			// Check the center of the grid cell
			FVector2D CellCenter = {(x + 0.5f) * CellSize, (y + 0.5f) * CellSize};
			if (IsPointInTriangle(UV1, UV2, UV3, CellCenter))
			{
				OutGrid[y][x] = true;
			}
		}
	}
}

float FStaticMeshDensityCalculator::GetUVUtilizationRate(const UStaticMesh* StaticMesh, const FStaticMeshLODResources& LODResource)
{
	const int32 GridSize = 128;
	TArray<TArray<bool>> UVGrid;
	UVGrid.SetNumZeroed(GridSize);
	for (int32 i = 0; i < GridSize; ++i)
	{
		UVGrid[i].Init(false, GridSize);
	}
	int32 InvalidUVCount = 0;
	for (int32 Index = 0; Index < LODResource.IndexBuffer.GetNumIndices(); Index += 3)
	{
		// Get indices for the triangle
		int32 Index0 = LODResource.IndexBuffer.GetIndex(Index);
		int32 Index1 = LODResource.IndexBuffer.GetIndex(Index + 1);
		int32 Index2 = LODResource.IndexBuffer.GetIndex(Index + 2);

		// Get UVs for each vertex
		FVector2D UV0 = FVector2D(LODResource.VertexBuffers.StaticMeshVertexBuffer.GetVertexUV(Index0, 0));
		FVector2D UV1 = FVector2D(LODResource.VertexBuffers.StaticMeshVertexBuffer.GetVertexUV(Index1, 0));
		FVector2D UV2 = FVector2D(LODResource.VertexBuffers.StaticMeshVertexBuffer.GetVertexUV(Index2, 0));
		if ((UV0.X > 1 || UV0.Y > 1) && (UV1.X > 1 || UV1.Y > 1) && (UV2.X > 1 || UV2.Y > 1))
		{
			++InvalidUVCount;
			if (InvalidUVCount > 10)
			{
				return -1;
			}
		}
		MarkTriangleOnGrid(UV0, UV1, UV2, UVGrid);
	}
	int32 Count = 0;
	for (int32 i = 0; i < UVGrid.Num(); ++i)
	{
		for (int32 j = 0; j < UVGrid[i].Num(); ++j)
		{
			if (UVGrid[i][j])
			{
				++Count;
			}
		}
	}
	return Count / static_cast<float>(GridSize * GridSize);
}

bool FStaticMeshDensityCalculator::GetTrianglesAndUVArea(const UStaticMesh* StaticMesh, const FStaticMeshLODResources& LODResource, double& OutTrianglesArea, double& OutPixelNum)
{
	for (const FStaticMeshSection& SectionInfo : LODResource.Sections)
	{
		FIndexArrayView IndexBuffer = LODResource.IndexBuffer.GetArrayView();
		if (UMaterialInterface* MaterialInterface = StaticMesh->GetMaterial(SectionInfo.MaterialIndex))
		{
			TArray<UTexture*> Textures;
			if (Cast<UMaterialInstanceConstant>(MaterialInterface))
			{
				TArray<FMaterialParameterInfo> ParameterInfos;
				TArray<FGuid> Guids;
				MaterialInterface->GetAllTextureParameterInfo(ParameterInfos, Guids);

				for (auto& ParameterInfo : ParameterInfos)
				{
					UTexture* TextureValue = nullptr;
					if (MaterialInterface->GetTextureParameterValue(ParameterInfo, TextureValue))
					{
						if (TextureValue)
						{
							Textures.AddUnique(TextureValue);
						}
					}
				}
			}
			// 获取基本材质中的纹理
			else if (UMaterial* Material = MaterialInterface->GetMaterial())
			{
				for (UMaterialExpression* Expression : Material->GetExpressions())
				{
					if (UMaterialExpressionTextureBase* TextureExpression = Cast<UMaterialExpressionTextureBase>(Expression))
					{
						if (UTexture* Texture = TextureExpression->Texture)
						{
							Textures.AddUnique(Texture);
						}
					}
				}
			}

			if (Textures.Num() > 0)
			{
				double UVArea = 0.0;
				int32 MaxTextureSize = 0;
				for (UTexture* Texture : Textures)
				{
					int32 MaxInGameWidth = Texture->Source.GetSizeX();
					int32 MaxInGameHeight = Texture->Source.GetSizeY();
					if (Texture->MaxTextureSize > 0)
					{
						MaxInGameWidth = FMath::Min(MaxInGameWidth, Texture->MaxTextureSize);
						MaxInGameHeight = FMath::Min(MaxInGameHeight, Texture->MaxTextureSize);
					}

					const int32 LODBias = Texture->LODBias;

					MaxInGameWidth = MaxInGameWidth >> LODBias;
					MaxInGameHeight = MaxInGameHeight >> LODBias;
					MaxTextureSize = FMath::Max(MaxTextureSize, MaxInGameWidth * MaxInGameHeight);
				}

				int32 InvalidUVCount = 0;
				for (uint32 TriangleIndex = 0; TriangleIndex < SectionInfo.NumTriangles; ++TriangleIndex)
				{
					const int32 Index0 = IndexBuffer[SectionInfo.FirstIndex + TriangleIndex * 3 + 0];
					const int32 Index1 = IndexBuffer[SectionInfo.FirstIndex + TriangleIndex * 3 + 1];
					const int32 Index2 = IndexBuffer[SectionInfo.FirstIndex + TriangleIndex * 3 + 2];

					FVector3f Vertex0 = LODResource.VertexBuffers.PositionVertexBuffer.VertexPosition(Index0);
					FVector3f Vertex1 = LODResource.VertexBuffers.PositionVertexBuffer.VertexPosition(Index1);
					FVector3f Vertex2 = LODResource.VertexBuffers.PositionVertexBuffer.VertexPosition(Index2);

					float TriangleArea = 0.5f * FVector3f::CrossProduct(Vertex1 - Vertex0, Vertex2 - Vertex0).Size();
					OutTrianglesArea += TriangleArea;

					FVector2D UV0 = FVector2D(LODResource.VertexBuffers.StaticMeshVertexBuffer.GetVertexUV(Index0, 0));
					FVector2D UV1 = FVector2D(LODResource.VertexBuffers.StaticMeshVertexBuffer.GetVertexUV(Index1, 0));
					FVector2D UV2 = FVector2D(LODResource.VertexBuffers.StaticMeshVertexBuffer.GetVertexUV(Index2, 0));
					FVector2D UV01 = UV1 - UV0;
					FVector2D UV02 = UV2 - UV0;
					double TArea = FMath::Abs<double>((UV01.X * UV02.Y - UV01.Y * UV02.X) / 2.0f);
					UVArea += TArea;
					if ((UV0.X > 1 || UV0.Y > 1) && (UV1.X > 1 || UV1.Y > 1) && (UV2.X > 1 || UV2.Y > 1))
					{
						++InvalidUVCount;
						if (InvalidUVCount > 10)
						{
							return false;
						}
					}
				}

				OutPixelNum += UVArea * MaxTextureSize;
			}
			else
			{
				OutPixelNum += 0;
			}
		}
	}
	return true;
}

bool FStaticMeshDensityCalculator::CalculateDensity(const UStaticMesh* StaticMesh, FStaticMeshDensityData& OutDensityData)
{
	if (!StaticMesh || !StaticMesh->GetRenderData() || StaticMesh->GetRenderData()->LODResources.Num() == 0)
	{
		return false;
	}

	double TotalTrianglesArea = 0;
	double TotalPixelNum = 0;
	float TotalTrianglesNum = 0;
	float TotalVolume = 0;
	float TotalArea = 0;
	float TotalWeightSum = 0.f;
	float TotalWeightedUVDensity = 0;
	OutDensityData.Triangles = StaticMesh->GetRenderData()->LODResources[0].GetNumTriangles();
	for (int32 LodIndex = 0; LodIndex < StaticMesh->GetNumLODs(); ++LodIndex)
	{
		const FStaticMeshLODResources& LODResource = StaticMesh->GetRenderData()->LODResources[LodIndex];
		// 计算体积密度:单位体积的三角面数量
		const int32 TrianglesNum = LODResource.GetNumTriangles();
		const double Volume = StaticMesh->GetBoundingBox().GetVolume() / 1000000; // 转化为立方米，用厘米做单位会导致太多接近0的值
		float VolumeDensity = Volume > UE_SMALL_NUMBER ? TrianglesNum / Volume : 0;
		if (StaticMesh->GetBoundingBox().GetSize().X < 10 || StaticMesh->GetBoundingBox().GetSize().Y < 10 || StaticMesh->GetBoundingBox().GetSize().Z < 10)
		{
			VolumeDensity = 0;
		}
		OutDensityData.LodVolumeDensities.Add(VolumeDensity);

		// 计算表面积密度:单位表面积的三角面数量
		const float Area = GetArea(LODResource) / 10000; // 转化为平方米，用厘米做单位会导致太多接近0的值
		float AreaDensity = Area > UE_SMALL_NUMBER ? TrianglesNum / Area : 0;
		OutDensityData.LodAreaDensities.Add(AreaDensity);

		TotalTrianglesNum += TrianglesNum;
		TotalVolume += Volume;
		TotalArea += Area;

		// UV Density
		float WeightSum = 0.f;
		float WeightedUVDensity = 0.F;
		for (const FStaticMeshSection& SectionInfo : LODResource.Sections)
		{
			WeightedUVDensity += SectionInfo.UVDensities[0] * SectionInfo.Weights[0];
			WeightSum += SectionInfo.Weights[0];
		}
		float UVDensity = WeightedUVDensity > UE_SMALL_NUMBER ? WeightSum / WeightedUVDensity : 0;
		OutDensityData.LodUVDensities.Add(UVDensity);
		TotalWeightSum += WeightSum;
		TotalWeightedUVDensity += WeightedUVDensity;

		// UV利用率
		float UVUtilizationRate = GetUVUtilizationRate(StaticMesh, LODResource);
		OutDensityData.LodUVUtilizationRate.Add(UVUtilizationRate);

		// 每平方厘米的像素个数
		double PixelNum = 0.f;
		double TrianglesArea = 0.f;
		bool UVValid = GetTrianglesAndUVArea(StaticMesh, LODResource, TrianglesArea, PixelNum);

		float PixelDensity = TrianglesArea > UE_SMALL_NUMBER ? PixelNum / (TrianglesArea) : 0;

		if (!UVValid)
		{
			PixelDensity = -1;
		}
		OutDensityData.LodPixelDensities.Add(PixelDensity);
		TotalTrianglesArea += TrianglesArea;
		TotalPixelNum += PixelNum;
	}
	return true;
}

FAutoConsoleCommand KGDensity(TEXT("KGRM.Density"), TEXT("KGRM.Density"), FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
{
	TArray<UObject*> SelectedAssets = UEditorUtilityLibrary::GetSelectedAssets();
	if (SelectedAssets.Num() > 0)
	{
		UObject* SelectedAsset = SelectedAssets[0];
		if (UStaticMesh* StaticMesh = Cast<UStaticMesh>(SelectedAsset))
		{
			FStaticMeshDensityData DensityData;
			DensityData.PackageName = StaticMesh->GetPackage()->GetName();

			const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
			TArray<FName> AssetReferencers;
			AssetRegistryModule.Get().GetReferencers(StaticMesh->GetPackage()->GetFName(), AssetReferencers, UE::AssetRegistry::EDependencyCategory::All);
			DensityData.bHasReferencedObjects = AssetReferencers.Num() > 0;

			FStaticMeshDensityCalculator::CalculateDensity(StaticMesh, DensityData);
			int32 a = 0;
		}
	}
}));
