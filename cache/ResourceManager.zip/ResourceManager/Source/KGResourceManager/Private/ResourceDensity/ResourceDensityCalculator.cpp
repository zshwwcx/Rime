#include "ResourceDensity/ResourceDensityCalculator.h"

#include "ResourceCheck/ResourceCheckSubsystem.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "Elements/Framework/TypedElementRegistry.h"

void FResourceDensityCalculator::CollectAssetsData(TArray<FAssetData>& OutAssetData)
{
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	const IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	FARFilter Filter;
	Filter.ClassPaths.Add(GetResourceClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	Filter.PackagePaths.Add("/Game/Arts");
	AssetRegistry.GetAssets(Filter, OutAssetData);
}

void FResourceDensityCalculator::CalculateAll()
{
	auto TriggerGCWhenNeed = []
	{
		uint64 MemoryMinFreeVirtual = 2048 * 1024ULL * 1024ULL;
		uint64 MemoryMaxUsedVirtual= 98304 * 1024ULL * 1024ULL;
		uint64 MemoryMinFreePhysical= 2048 * 1024ULL * 1024ULL;
		FPlatformMemoryStats MemoryStats = FPlatformMemory::GetStats();
		if (MemoryStats.AvailableVirtual > MemoryMinFreeVirtual
			&& MemoryStats.AvailablePhysical > MemoryMinFreePhysical
			&& MemoryStats.UsedVirtual < MemoryMaxUsedVirtual)
		{
			return;
		}
		UE_LOG(LogKGResourceManager, Display, TEXT("Trigger GC"))
		UTypedElementRegistry* Registry = UTypedElementRegistry::GetInstance();
		UTypedElementRegistry::FDisableElementDestructionOnGC GCGuard(Registry);
		FAssetRegistryModule::TickAssetRegistry(-1.0f);
		CollectGarbage(RF_NoFlags);
		if (IsIncrementalPurgePending())
		{
			IncrementalPurgeGarbage(false);
		}
		FMemory::Trim();
	};
	TArray<FAssetData> AssetsData;
	CollectAssetsData(AssetsData);
	int32 AssetsNum = AssetsData.Num();
	for (int32 i = 0; i < AssetsData.Num(); i++)
	{
		const FAssetData& AssetData = AssetsData[i];
		UE_LOG(LogKGResourceManager, Display, TEXT("Calculate Asset Density %d/%d: %s"), i + 1, AssetsNum, *AssetData.PackageName.ToString())
		CalculateOne(AssetData);
		TriggerGCWhenNeed();
	}
}

void FResourceDensityCalculator::ExportResults()
{
	
}