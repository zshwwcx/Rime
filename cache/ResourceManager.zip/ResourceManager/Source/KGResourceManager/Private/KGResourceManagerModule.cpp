// Copyright Epic Games, Inc. All Rights Reserved.

#include "KGResourceManagerModule.h"

#include "ContentBrowserMenuContexts.h"
#include "EditorUtilityLibrary.h"
#include "ResourceCheck/Customization/CustomPropertyDetails.h"
#include "ResourceCheck/Customization/FunctionDetail.h"
#include "ResourceCheck/Customization/SResourceManagerTab.h"
#include "ResourceCheck/ResourceCheckSubsystem.h"
#include "ResourceCheck/RuleBase.h"
#include "ResourceCheck/ResourceCheckConfig.h"
#include "Selection.h"
#include "ResourceCheck/ResourceCheckHelper.h"
#include "FileHelpers.h"
#include "Delegates/AssetCheckDelegates.h"
#include "Engine/SCS_Node.h"
#include "Engine/SimpleConstructionScript.h"
#include "PackedLevelActor/PackedLevelActor.h"
#include "PhysicsEngine/BodySetup.h"

#include "SeqPerformanceMonitor/PerformanceMonitor.h"

#define LOCTEXT_NAMESPACE "FKGResourceManagerModule"


void FKGResourceManagerModule::StartupModule()
{
	if (!IsRunningCommandlet() && !IsRunningGame() && FSlateApplication::IsInitialized())
	{
		// add the File->DataValidation menu subsection
		UToolMenus::Get()->RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FKGResourceManagerModule::RegisterMenus));
		{
			FPropertyEditorModule& PropertyEditorModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
			PropertyEditorModule.RegisterCustomPropertyTypeLayout("RMPropertyRuleMapping", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FCustomPropertyDetails::MakeInstance));
			PropertyEditorModule.RegisterCustomPropertyTypeLayout("RMFunctionRuleMapping", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FFunctionDetails::MakeInstance));
			PropertyEditorModule.RegisterCustomPropertyTypeLayout("RMRepairRuleMapping", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FFunctionDetails::MakeInstance));
		}
	}

	IConsoleManager::Get().RegisterConsoleCommand(TEXT("ResManager.CheckAll"), TEXT("ResManager.CheckAll"), FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
	{
		// Get().CheckALlRules();
	}), ECVF_Default);
	
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(UResourceCheckSubsystem::ResourceCheckTabId, FOnSpawnTab::CreateLambda([](const FSpawnTabArgs& SpawnTabArgs)
	{
		return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		[
			SNew(SResourceManagerTab)
		];
	}))
	.SetDisplayName(FText::FromName(UResourceCheckSubsystem::ResourceCheckTabId))
	.SetMenuType(ETabSpawnerMenuType::Hidden);

	// 注册Tab生成器（如果需要作为Dockable面板）
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(
		TEXT("PerformanceMonitor"),
		FOnSpawnTab::CreateRaw(this, &FKGResourceManagerModule::SpawnPerformanceMonitorTab))
		.SetDisplayName(FText::FromString(TEXT("性能监控")))
		.SetTooltipText(FText::FromString(TEXT("场景性能监控工具")));
}

void FKGResourceManagerModule::ShutdownModule()
{
	// 注销Tab生成器
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(TEXT("PerformanceMonitor"));

	// 清理菜单扩展
	//if (MenuExtender.IsValid() && ExtensionManager.IsValid())
	//{
	//	ExtensionManager->RemoveExtender(MenuExtender);
	//}
}

void FKGResourceManagerModule::RegisterMenus()
{
	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("ContentBrowser.AssetContextMenu");
		FToolMenuSection& Section = Menu->FindOrAddSection("ResourceCheck");
		Section.Label = LOCTEXT("FResourceCheck", "ResourceCheck");
		Section.AddSubMenu(
			"ResourceCheckActionsSubMenu",
			LOCTEXT("ResourceCheckActionsSubMenuLabel", "ResourceCheck Actions"),
			LOCTEXT("ResourceCheckActionsSubMenuToolTip", "ResourceCheck actions"),
			FNewToolMenuDelegate::CreateRaw(this, &FKGResourceManagerModule::RegisterContentBrowserSubMenus)
			);
	}

	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("SceneOutliner.DefaultContextMenuBase");
		FToolMenuSection& Section = Menu->FindOrAddSection("ResourceCheck");
		Section.Label = LOCTEXT("FResourceCheck", "ResourceCheck");
		Section.AddSubMenu(
			"ResourceCheckActionsSubMenu",
			LOCTEXT("ResourceCheckActionsSubMenuLabel", "ResourceCheck Actions"),
			LOCTEXT("ResourceCheckActionsSubMenuToolTip", "ResourceCheck actions"),
			FNewToolMenuDelegate::CreateRaw(this, &FKGResourceManagerModule::RegisterSceneOutlinerSubMenus)
			);
	}

	// 批量刷新static mesh的碰撞设置工具
	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("ContentBrowser.AssetContextMenu");
		FToolMenuSection& Section = Menu->FindOrAddSection("ResourceManager");
		Section.Label = LOCTEXT("ResourceManager", "ResourceManager");
		Section.AddSubMenu(
			"CollisionSetActionsSubMenu",
			LOCTEXT("CollisionSetActionsSubMenuLabel", "CollisionSet Actions"),
			LOCTEXT("CollisionSetActionsSubMenuToolTip", "CollisionSet actions"),
			FNewToolMenuDelegate::CreateRaw(this, &FKGResourceManagerModule::RegisterCollisionSetSubMenus)
			);
	}

	{
		FPerforceSourceControlProviderDelegates::PreCheckInSubmitFiles.AddLambda([](const TArray<FAssetData>& InFiles, const TSharedPtr<FPerforceSourceControlProviderDelegatesPackage>& InPackage)
		{
			UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
			ResourceCheckSubsystem->CheckAssetsByPreSubmit(InFiles, InPackage);
		});

		FPerforceSourceControlProviderDelegates::PostCheckInSubmitFiles.AddLambda([](const TArray<FAssetData>& InFiles, const TSharedPtr<FPerforceSourceControlProviderDelegatesPackage>& InPackage)
		{
			UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
			ResourceCheckSubsystem->OnPostAssetsSubmit(InFiles, InPackage);
		});
	}

	{
		FAssetCheckDelegates::AssetCheckDelegate.AddLambda([](const TArray<FAssetData>& InFiles)
		{
			UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
			ResourceCheckSubsystem->CheckAssetsByFunction(InFiles, ERMCheckRuleRange::SubmitCheck);
			ResourceCheckSubsystem->ShowCheckResultsInWidget();
		});
	}

	{

		{
			UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.C7_Editor");
			{
				FToolMenuSection& Section = Menu->FindOrAddSection("SequencePerformance");
				const FToolMenuEntry& Entry = FToolMenuEntry::InitMenuEntry(
					FName("SequencePerformance"),
					LOCTEXT("SeqPerfMenuLabel", "SequencePerformance"),
					FText::GetEmpty(),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateRaw(this, &FKGResourceManagerModule::OnOpenPerformanceMonitor))
				);
				Section.AddEntry(Entry);
			}
		}
	}
}

void FKGResourceManagerModule::RegisterContentBrowserSubMenus(UToolMenu* InMenu)
{
	FToolMenuSection& Section = InMenu->FindOrAddSection("ResourceCheck");
	Section.AddMenuEntry(
		"CheckAsset",
		LOCTEXT("CheckAssetTabTitle", "CheckAsset"),
		LOCTEXT("CheckAssetTooltipText", "CheckAsset"), FSlateIcon(),
		FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
					ResourceCheckSubsystem->CheckAssetsByContentMenu(Context->SelectedAssets);
				}
			}));

	Section.AddMenuEntry(
		"RepairAsset",
		LOCTEXT("RepairAssetTabTitle", "RepairAsset"),
		LOCTEXT("RepairAssetTooltipText", "RepairAsset"), FSlateIcon(),
		FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
					ResourceCheckSubsystem->RepairAssetsByContentMenu(Context->SelectedAssets);
				}
			}));

	FToolUIAction ImportRulesFromJsonAction;
		ImportRulesFromJsonAction.ExecuteAction =
			FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					for(auto& AssetData :Context->SelectedAssets)
					{
						UObject* Asset = AssetData.GetAsset();
						if(UBlueprint* Blueprint = Cast<UBlueprint>(Asset))
						{
							if(UClass* Class = Blueprint->GeneratedClass)
							{
								if(URuleBase* ParentDefaultObject = Cast<URuleBase>(Class->GetDefaultObject()))
								{									
									ParentDefaultObject->ImportRuleFromWeb(Asset->GetName());
									if(UPackage* Package = Blueprint->GetPackage())
									{
										if (Asset->MarkPackageDirty())
										{
											UEditorLoadingAndSavingUtils::SavePackages({Package}, true);
										}
									}									
								}
							}
						}
					}
				}
			}
		);
		ImportRulesFromJsonAction.CanExecuteAction =
			FToolMenuCanExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					for(auto& AssetData :Context->SelectedAssets)
					{
						if(AssetData.PackagePath.ToString().StartsWith(FResourceCheckConfig::BlueprintRulePath))
						{
							UObject* Asset = AssetData.GetAsset();						
							UBlueprint* Blueprint = Cast<UBlueprint>(Asset);
							if(!Blueprint)
							{
								return false;
							}
							if(!Blueprint->ParentClass->IsChildOf(URuleBase::StaticClass()))
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
				}
				return true;
			}
		);
		Section.AddMenuEntry(
			"ImportRulesFromJson",
			LOCTEXT("ImportRulesFromJsonTabTitle", "ImportRulesFromJson"),
			LOCTEXT("ImportRulesFromJsonTooltipText", "ImportRulesFromJson"),
			FSlateIcon(),
			ImportRulesFromJsonAction
		);

		FToolUIAction ExportRulesToJsonAction;
		ExportRulesToJsonAction.ExecuteAction =
			FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					for(auto& AssetData :Context->SelectedAssets)
					{
						UObject* Asset = AssetData.GetAsset();
						if(UBlueprintCore* BlueprintCore = Cast<UBlueprintCore>(Asset))
						{
							if(UClass* Class = BlueprintCore->GeneratedClass)
							{
								if(URuleBase* ParentDefaultObject = Cast<URuleBase>(Class->GetDefaultObject()))
								{
									URuleBase* RuleFromWeb = NewObject<URuleBase>(GetTransientPackage(), URuleBase::StaticClass());
									RuleFromWeb->ImportRuleFromWeb(Asset->GetName());
									if (ParentDefaultObject->RuleVersion + 1 > RuleFromWeb->RuleVersion)
									{
										ParentDefaultObject->ExportRulesToJson(Asset->GetName());
										if (Asset->MarkPackageDirty())
										{
											UEditorLoadingAndSavingUtils::SavePackages({Asset->GetPackage()}, true);
										}
									}
									else
									{
										FText DialogTitle = FText::FromString(TEXT("导出失败"));
										FText DialogMessage = FText::Format(LOCTEXT("Export Error", "无法导出资源检查JSON。本地版本:{0},平台版本:{1}。请使用ImportRulesFromJson导入最新版本。"),ParentDefaultObject->RuleVersion, RuleFromWeb->RuleVersion);
										FMessageDialog::Open(EAppMsgType::Ok, DialogMessage, DialogTitle);
									}
								}
							}
						}
					}
				}
			}
		);
		ExportRulesToJsonAction.CanExecuteAction =
			FToolMenuCanExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					for(auto& AssetData :Context->SelectedAssets)
					{
						if(AssetData.PackagePath.ToString().StartsWith(FResourceCheckConfig::BlueprintRulePath))
						{
							UObject* Asset = AssetData.GetAsset();
							UBlueprint* Blueprint = Cast<UBlueprint>(Asset);
							if(!Blueprint)
							{
								return false;
							}
							if(!Blueprint->ParentClass->IsChildOf(URuleBase::StaticClass()))
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
				}
				return true;
			}
		);
		Section.AddMenuEntry(
			"ExportRulesToJson",
			LOCTEXT("ExportRulesToJsonTabTitle", "ExportRulesToJson"),
			LOCTEXT("ExportRulesToJsonTooltipText", "ExportRulesToJson"),
			FSlateIcon(),
			ExportRulesToJsonAction
		);

		//skiptag
		FToolUIAction AddSkipTagToolUIAction;
		AddSkipTagToolUIAction.ExecuteAction =
			FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					FResourceCheckHelper::AddTagInAssetes(Context->SelectedAssets, FName(FResourceCheckConfig::SkipCheckTag));
				}
			}
		);
		AddSkipTagToolUIAction.CanExecuteAction =
			FToolMenuCanExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				bool CanAddSkipTag = false;
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					CanAddSkipTag = FResourceCheckHelper::HasNotTagInAssetes(Context->SelectedAssets, FName(FResourceCheckConfig::SkipCheckTag));
				}
				return CanAddSkipTag;
			}
		);
		Section.AddMenuEntry(
			"AddSkipTag",
			LOCTEXT("AddSkipTagTitle", "AddSkipTag"),
			LOCTEXT("AddSkipTagTooltipText", "AddSkipTag"),
			FSlateIcon(),
			AddSkipTagToolUIAction
		);

		FToolUIAction RemoveSkipTagToolUIAction;
		RemoveSkipTagToolUIAction.ExecuteAction =
			FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					FResourceCheckHelper::RemoveTagInAssetes(Context->SelectedAssets, FName(FResourceCheckConfig::SkipCheckTag));
				}
			}
		);
		RemoveSkipTagToolUIAction.CanExecuteAction =
			FToolMenuCanExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				bool CanRemoveSkipTag = false;
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					CanRemoveSkipTag = FResourceCheckHelper::HasTagInAssetes(Context->SelectedAssets, FName(FResourceCheckConfig::SkipCheckTag));
				}
				return CanRemoveSkipTag;
			}
		);
		Section.AddMenuEntry(
			"RemoveSkipTag",
			LOCTEXT("RemoveSkipTagTitle", "RemoveSkipTag"),
			LOCTEXT("RemoveSkipTagTooltipText", "RemoveSkipTag"),
			FSlateIcon(),
			RemoveSkipTagToolUIAction
		);

		// ==== HighTag ====
		FToolUIAction AddHighTagToolUIAction;
		AddHighTagToolUIAction.ExecuteAction =
			FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					FResourceCheckHelper::AddTagInAssetes(Context->SelectedAssets, FName(FResourceCheckConfig::HighTag));
				}
			}
		);
		AddHighTagToolUIAction.CanExecuteAction =
			FToolMenuCanExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				bool CanAddHighTag = false;
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					CanAddHighTag = FResourceCheckHelper::HasNotTagInAssetes(Context->SelectedAssets, FName(FResourceCheckConfig::HighTag));
				}
				return CanAddHighTag;
			}
		);
		Section.AddMenuEntry(
			"AddHighTag",
			LOCTEXT("AddHighTagTitle", "AddHighTag"),
			LOCTEXT("AddHighTagTooltipText", "AddHighTag"),
			FSlateIcon(),
			AddHighTagToolUIAction
		);
		FToolUIAction RemoveHighTagToolUIAction;
		RemoveHighTagToolUIAction.ExecuteAction =
			FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					FResourceCheckHelper::RemoveTagInAssetes(Context->SelectedAssets, FName(FResourceCheckConfig::HighTag));
				}
			}
		);
		RemoveHighTagToolUIAction.CanExecuteAction =
			FToolMenuCanExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				bool CanRemoveHighTag = false;
				if (UContentBrowserAssetContextMenuContext* Context = InContext.FindContext<UContentBrowserAssetContextMenuContext>())
				{
					CanRemoveHighTag = FResourceCheckHelper::HasTagInAssetes(Context->SelectedAssets, FName(FResourceCheckConfig::HighTag));
				}
				return CanRemoveHighTag;
			}
		);
		Section.AddMenuEntry(
			"RemoveHighTag",
			LOCTEXT("RemoveHighTagTitle", "RemoveHighTag"),
			LOCTEXT("RemoveHighTagTooltipText", "RemoveHighTag"),
			FSlateIcon(),
			RemoveHighTagToolUIAction
		);

}

void FKGResourceManagerModule::RegisterCollisionSetSubMenus(UToolMenu* InMenu)
{
	auto AutoSetSelectedCollisionPresets = [](FName ProfileName)
	{
		TArray<UObject*> SelectedAssets = UEditorUtilityLibrary::GetSelectedAssets();
		TArray<UPackage*> ModifiedPackages;
		for (int32 i = 0; i < SelectedAssets.Num(); i++)
		{
			UObject* SelectedAsset = SelectedAssets[i];
			if (UStaticMesh* StaticMesh = Cast<UStaticMesh>(SelectedAsset))
			{
				// 获取BodySetup
				UBodySetup* BodySetup = StaticMesh->GetBodySetup();
				// 设置碰撞预设
				FName CurrentCollisionProfileName = BodySetup->DefaultInstance.GetCollisionProfileName();
				if (CurrentCollisionProfileName != ProfileName)
				{
					if (ProfileName != "Default")
					{
						BodySetup->DefaultInstance.SetCollisionProfileName(ProfileName);
						SelectedAsset->MarkPackageDirty();
						SelectedAsset->PreEditChange(nullptr);
						SelectedAsset->PostEditChange();
						ModifiedPackages.Add(SelectedAsset->GetPackage());
					}
				}
			}
			else if (UBlueprint* Blueprint = Cast<UBlueprint>(SelectedAsset))
			{
				if (Blueprint->ParentClass->IsChildOf(AActor::StaticClass()))
				{
					if (USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript)
					{
						bool bModified = false;
						for (const USCS_Node* Node : SCS->GetAllNodes())
						{
							if (Node)
							{
								UActorComponent* ComponentTemplate = Node->ComponentTemplate;
								if (UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(ComponentTemplate))
								{
									if (PrimitiveComponent->GetCollisionProfileName() != ProfileName)
									{
										if (ProfileName == "Default")
										{
											if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(PrimitiveComponent))
											{
												StaticMeshComponent->bUseDefaultCollision = true;
												bModified = true;
											}
										}
										else
										{
											PrimitiveComponent->SetCollisionProfileName(ProfileName);
											bModified = true;
										}
									}
								}
							}
						}
						if (bModified)
						{
							SelectedAsset->MarkPackageDirty();
							SelectedAsset->PreEditChange(nullptr);
							SelectedAsset->PostEditChange();
							ModifiedPackages.Add(SelectedAsset->GetPackage());
						}
					}
				}
			}
		}
		UEditorLoadingAndSavingUtils::SavePackagesWithDialog(ModifiedPackages, true);
	};
	// static mesh的碰撞设置工具
	{
        FToolMenuSection& Section = InMenu->FindOrAddSection("ResourceManager");

        TArray<FName> PresetNames;
        {
            PresetNames.Add("Default");
        }

        UCollisionProfile* CollisionProfile = UCollisionProfile::Get();
        if (CollisionProfile)
        {
            int32 NumProfiles = CollisionProfile->GetNumOfProfiles();
            for (int32 Index = 0; Index < NumProfiles; Index++)
            {
                PresetNames.Add(CollisionProfile->GetProfileByIndex(Index)->Name);
            }
        }

        for (const FName& CollisionPreset : PresetNames)
        {
            Section.AddMenuEntry(
                CollisionPreset,
                FText::FromString(CollisionPreset.ToString()),
                FText::FromString(CollisionPreset.ToString()), FSlateIcon(),
                FToolMenuExecuteAction::CreateLambda([this, &AutoSetSelectedCollisionPresets, CollisionPreset](const FToolMenuContext& InContext) {
                    AutoSetSelectedCollisionPresets(CollisionPreset);
                }));
        }
	}
}

void FKGResourceManagerModule::RegisterSceneOutlinerSubMenus(UToolMenu* InMenu)
{
	FToolMenuSection& Section = InMenu->FindOrAddSection("ResourceCheck");
	Section.AddMenuEntry(
		"CheckAsset",
		LOCTEXT("CheckAssetTabTitle", "CheckAsset"),
		LOCTEXT("CheckAssetTooltipText", "CheckAsset"), FSlateIcon(),
		FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				TArray<AActor*> SelectedActors;
				const UEditorEngine* EEngine = Cast<UEditorEngine>(GEngine);
				EEngine->GetSelectedActors()->GetSelectedObjects(SelectedActors);

				FAssetRegistryModule& AssetRegistryModule = FModuleManager::Get().LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
			
				TArray<FAssetData> SelectedAssetDatas;
				for(auto SelectedActor : SelectedActors)
				{
					FAssetData AssetData = AssetRegistryModule.Get().GetAssetByObjectPath(SelectedActor->GetPathName());
					SelectedAssetDatas.Add(AssetData);
				}
				
				UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
				ResourceCheckSubsystem->CheckAssetsByContentMenu(SelectedAssetDatas);
			}));

	Section.AddMenuEntry(
		"RepairAsset",
		LOCTEXT("RepairAssetTabTitle", "RepairAsset"),
		LOCTEXT("RepairAssetTooltipText", "RepairAsset"), FSlateIcon(),
		FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				TArray<AActor*> SelectedActors;
				const UEditorEngine* EEngine = Cast<UEditorEngine>(GEngine);
				EEngine->GetSelectedActors()->GetSelectedObjects(SelectedActors);

				FAssetRegistryModule& AssetRegistryModule = FModuleManager::Get().LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
							
				TArray<FAssetData> SelectedAssetDatas;
				for(auto SelectedActor : SelectedActors)
				{
					FAssetData AssetData = AssetRegistryModule.Get().GetAssetByObjectPath(SelectedActor->GetPathName());
					SelectedAssetDatas.Add(AssetData);
				}
								
				UResourceCheckSubsystem* ResourceCheckSubsystem = GEditor->GetEditorSubsystem<UResourceCheckSubsystem>();
				ResourceCheckSubsystem->RepairAssetsByContentMenu(SelectedAssetDatas);
			}));
}

void FKGResourceManagerModule::RegisterSeqPerfSubMenus(UToolMenu* InMenu)
{
	FToolMenuSection& Section = InMenu->FindOrAddSection("Sequence");
	Section.AddMenuEntry(
		"SeqPerfMonitor",
		LOCTEXT("SeqPerfMonitorTitle", "SeqPerfMonitor"),
		LOCTEXT("SeqPerfMonitorTooltipText", "SeqPerfMonitor"), FSlateIcon(),
		FToolMenuExecuteAction::CreateLambda([this](const FToolMenuContext& InContext)
			{
				OnOpenPerformanceMonitor();
			}));

}

void FKGResourceManagerModule::OnOpenPerformanceMonitor()
{
	// 打开或聚焦性能监控面板
	FGlobalTabmanager::Get()->TryInvokeTab(FTabId(TEXT("PerformanceMonitor")));
}

// 创建Dockable Tab的函数
TSharedRef<SDockTab> FKGResourceManagerModule::SpawnPerformanceMonitorTab(const FSpawnTabArgs& SpawnTabArgs)
{
	TSharedRef<SPerformanceMonitorPanel> mainPanel = SNew(SPerformanceMonitorPanel);
	TSharedRef<SDockTab> NewTab = SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		.OnTabClosed(SDockTab::FOnTabClosedCallback::CreateLambda([mainPanel](TSharedRef<SDockTab> Tab)
		{
			mainPanel->OnClosed();
		}))
		[
			SNew(SBox)
				.Padding(2.0f)
				[
					//SNew(SPerformanceMonitorPanel)
					mainPanel
				]
		];

	mainPanel->OnActivated();

	//PerformanceMonitorTab = NewTab;
	return NewTab;
}


#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FKGResourceManagerModule, KGResourceManagerModule)
