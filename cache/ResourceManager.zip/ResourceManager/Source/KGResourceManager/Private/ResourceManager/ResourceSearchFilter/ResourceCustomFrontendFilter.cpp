#include "ResourceManager/ResourceSearchFilter/ResourceCustomFrontendFilter.h"

#include "ResourceCheck/ResourceCheckHelper.h"
#include "Particles/ParticleSystem.h"

#define LOCTEXT_NAMESPACE "ResourceSearchFilter"

void UResourceCustomAssetSearchFilter::AddFrontEndFilterExtensions(TSharedPtr<class FFrontendFilterCategory> DefaultCategory, TArray< TSharedRef<class FFrontendFilter> >& InOutFilterList) const
{
	InOutFilterList.Add(MakeShareable(new FFrontendFilter_AssetEditorTag(DefaultCategory)));
}

FFrontendFilter_AssetEditorTag::FFrontendFilter_AssetEditorTag(TSharedPtr<FFrontendFilterCategory> InCategory)
: FFrontendFilter(InCategory)
{
}

FString FFrontendFilter_AssetEditorTag::GetName() const
{
	return TEXT("Asset Editor Tags");
}

FText FFrontendFilter_AssetEditorTag::GetDisplayName() const
{
	return FText::FromString("Asset Editor Tags");
}

FText FFrontendFilter_AssetEditorTag::GetToolTipText() const
{
	return FText::FromString("Filter assets by customized tags, tags divided by ;");
}

void FFrontendFilter_AssetEditorTag::ModifyContextMenu(FMenuBuilder& MenuBuilder)
{
	FUIAction Action;

	MenuBuilder.BeginSection(TEXT("EditorTagsSection"), LOCTEXT("EditorTagsSectionHeading", "AssetRegistrySearchable EditorTagsComparison"));

	TSharedRef<SWidget> KeyWidget =
		SNew(SEditableTextBox)
		.Text_Raw(this, &FFrontendFilter_AssetEditorTag::GetTagsValueAsText)
		.OnTextCommitted_Raw(this, &FFrontendFilter_AssetEditorTag::OnTagsValueTextCommitted)
		.MinDesiredWidth(100.0f);

	MenuBuilder.AddWidget(KeyWidget, LOCTEXT("KeyMenuDesc", "Tags"));
	
	MenuBuilder.EndSection();
}

bool FFrontendFilter_AssetEditorTag::PassesFilter(FAssetFilterType InItem) const
{
	if (TargetTags.IsEmpty())
	{
		return false;
	}
	FAssetData ItemAssetData;
	if (InItem.Legacy_TryGetAssetData(ItemAssetData))
	{
		TArray<FString> OutTags;
		FResourceCheckHelper::GetAssetEditorTags(ItemAssetData, OutTags);
		for(auto Tag:TargetTags)
		{
			if(OutTags.Find(Tag.ToString()) == INDEX_NONE)
			{
				return false;
			}
		}
		return true;
	}
	return false;
}

FText FFrontendFilter_AssetEditorTag::GetTagsValueAsText() const
{
	FString ShowText;
	for(auto Item:TargetTags)
	{
		ShowText += Item.ToString() + ";";
	}
	
	return FText::FromString(ShowText);
}

void FFrontendFilter_AssetEditorTag::OnTagsValueTextCommitted(const FText& InText, ETextCommit::Type InCommitType)
{
	TargetTags.Empty();
	FString InString=*InText.ToString();
	TArray<FString> TagsArray;
	InString.ParseIntoArray(TagsArray,TEXT(";"));
	for(auto Item:TagsArray)
	{
		TargetTags.FindOrAdd(FName(Item));
	}
	BroadcastChangedEvent();
}

#undef LOCTEXT_NAMESPACE