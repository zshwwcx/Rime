#include "SeqPerformanceMonitor/EffectsTabPanel.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SSplitter.h"
#include "Styling/CoreStyle.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"


void SEffectsTabPanel::Construct(const FArguments& InArgs)
{
	// 初始化字体
	RegularFont = FCoreStyle::GetDefaultFontStyle("Regular", 10);
	BoldFont = FCoreStyle::GetDefaultFontStyle("Bold", 12);
	SmallFont = FCoreStyle::GetDefaultFontStyle("Regular", 9);

	// 初始化示例数据
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Fire_01"), TEXT("Main_Level"), false, TEXT("Medium"), 2, true, 5000));
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Smoke_Trail"), TEXT("Character_Level"), true, TEXT("High"), 3, false, 8000));
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Magic_Circle"), TEXT("Magic_Level"), false, TEXT("Low"), 1, true, 2000));
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Explosion_01"), TEXT("Combat_Level"), true, TEXT("Very High"), 5, false, 15000));
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Water_Splash"), TEXT("Water_Level"), false, TEXT("Medium"), 2, true, 3500));
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Dust_Kickup"), TEXT("Desert_Level"), true, TEXT("High"), 3, false, 6000));
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Portal_VFX"), TEXT("Magic_Level"), false, TEXT("Very High"), 4, true, 12000));
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Rain_Effect"), TEXT("Outdoor_Level"), true, TEXT("Medium"), 1, false, 25000));
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Blood_Splash"), TEXT("Combat_Level"), false, TEXT("Low"), 2, false, 3000));
	AllEffects.Add(MakeShared<FEffectInfo>(TEXT("Energy_Shield"), TEXT("SciFi_Level"), true, TEXT("High"), 3, true, 7000));

	SortEffectsList();
	FilteredEffects = AllEffects;

	// 初始化质量选项
	EffectQualityOptions.Add(MakeShared<FString>(TEXT("Low")));
	EffectQualityOptions.Add(MakeShared<FString>(TEXT("Medium")));
	EffectQualityOptions.Add(MakeShared<FString>(TEXT("High")));
	EffectQualityOptions.Add(MakeShared<FString>(TEXT("Epic")));
	EffectQualityOptions.Add(MakeShared<FString>(TEXT("Cinematic")));

	// 初始化显示数量选项
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("10")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("25")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("50")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("100")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("All")));

	ChildSlot
		[
			SNew(SScrollBox)
				+ SScrollBox::Slot()
				.Padding(5)
				[
					SNew(SVerticalBox)

						// 第一格：4个性能数据面板
						+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 0, 0, 10)
						[
							SNew(SHorizontalBox)

								// 有效发射器数量
								+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Active Emitters")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(ActiveEmitterCountLabel, STextBlock)
														.Text(FText::FromString(TEXT("15")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Active particle emitters")))
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]

							// 粒子总数
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Total Particles")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(TotalParticleCountLabel, STextBlock)
														.Text(FText::FromString(TEXT("85.5K")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Total active particles")))
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]

							// 材质复杂度
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Material Complexity")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(MaterialComplexityLabel, STextBlock)
														.Text(FText::FromString(TEXT("3.2")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Average material complexity")))
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]

							// 叠层总数
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Overdraw Total")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(OverdrawTotalLabel, STextBlock)
														.Text(FText::FromString(TEXT("26")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Total overdraw layers")))
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]
						]

					// 第二格：快捷功能
					+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 10, 0, 10)
						[
							SNew(SVerticalBox)

								// 第一子格：4个切换开关
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 10)
								[
									SNew(SHorizontalBox)

										// OverDraw View Mode切换开关
										+ SHorizontalBox::Slot()
										.FillWidth(1.0f)
										.Padding(5, 0, 5, 0)
										[
											SNew(SBorder)
												.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
												.Padding(10)
												[
													SNew(SHorizontalBox)

														+ SHorizontalBox::Slot()
														.AutoWidth()
														.Padding(0, 0, 10, 0)
														[
															SAssignNew(OverdrawViewCheckBox, SCheckBox)
																.IsChecked(ECheckBoxState::Unchecked)
																.OnCheckStateChanged(this, &SEffectsTabPanel::OnOverdrawViewChanged)
														]

														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														[
															SNew(SVerticalBox)

																+ SVerticalBox::Slot()
																.AutoHeight()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(TEXT("OverDraw View")))
																		.Font(BoldFont)
																]

																+ SVerticalBox::Slot()
																.AutoHeight()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(TEXT("Toggle OverDraw view mode")))
																		.Font(SmallFont)
																		.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
																]
														]
												]
										]

									// Material Complexity View Mode切换开关
									+ SHorizontalBox::Slot()
										.FillWidth(1.0f)
										.Padding(5, 0, 5, 0)
										[
											SNew(SBorder)
												.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
												.Padding(10)
												[
													SNew(SHorizontalBox)

														+ SHorizontalBox::Slot()
														.AutoWidth()
														.Padding(0, 0, 10, 0)
														[
															SAssignNew(MaterialComplexityCheckBox, SCheckBox)
																.IsChecked(ECheckBoxState::Unchecked)
																.OnCheckStateChanged(this, &SEffectsTabPanel::OnMaterialComplexityChanged)
														]

														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														[
															SNew(SVerticalBox)

																+ SVerticalBox::Slot()
																.AutoHeight()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(TEXT("Material Complexity")))
																		.Font(BoldFont)
																]

																+ SVerticalBox::Slot()
																.AutoHeight()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(TEXT("Toggle Material Complexity view")))
																		.Font(SmallFont)
																		.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
																]
														]
												]
										]

									// Effect Hierarchy切换开关
									+ SHorizontalBox::Slot()
										.FillWidth(1.0f)
										.Padding(5, 0, 5, 0)
										[
											SNew(SBorder)
												.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
												.Padding(10)
												[
													SNew(SHorizontalBox)

														+ SHorizontalBox::Slot()
														.AutoWidth()
														.Padding(0, 0, 10, 0)
														[
															SAssignNew(EffectHierarchyCheckBox, SCheckBox)
																.IsChecked(ECheckBoxState::Unchecked)
																.OnCheckStateChanged(this, &SEffectsTabPanel::OnEffectHierarchyChanged)
														]

														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														[
															SNew(SVerticalBox)

																+ SVerticalBox::Slot()
																.AutoHeight()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(TEXT("Effect Hierarchy")))
																		.Font(BoldFont)
																]

																+ SVerticalBox::Slot()
																.AutoHeight()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(TEXT("Show effect hierarchy levels")))
																		.Font(SmallFont)
																		.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
																]
														]
												]
										]

									// Overdraw Display切换开关
									+ SHorizontalBox::Slot()
										.FillWidth(1.0f)
										.Padding(5, 0, 5, 0)
										[
											SNew(SBorder)
												.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
												.Padding(10)
												[
													SNew(SHorizontalBox)

														+ SHorizontalBox::Slot()
														.AutoWidth()
														.Padding(0, 0, 10, 0)
														[
															SAssignNew(OverdrawDisplayCheckBox, SCheckBox)
																.IsChecked(ECheckBoxState::Unchecked)
																.OnCheckStateChanged(this, &SEffectsTabPanel::OnOverdrawDisplayChanged)
														]

														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														[
															SNew(SVerticalBox)

																+ SVerticalBox::Slot()
																.AutoHeight()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(TEXT("Overdraw Display")))
																		.Font(BoldFont)
																]

																+ SVerticalBox::Slot()
																.AutoHeight()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(TEXT("Display overdraw layers")))
																		.Font(SmallFont)
																		.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
																]
														]
												]
										]
								]

							// 第二子格：按钮和下拉框
							+ SVerticalBox::Slot()
								.AutoHeight()
								[
									SNew(SHorizontalBox)

										+ SHorizontalBox::Slot()
										.FillWidth(1.0f)
										.Padding(5, 0, 5, 0)
										[
											SAssignNew(SelfCheckEffectsButton, SButton)
												.Text(FText::FromString(TEXT("Self Check Effects")))
												.HAlign(HAlign_Center)
												.VAlign(VAlign_Center)
												.OnClicked(this, &SEffectsTabPanel::OnSelfCheckEffects)
												.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton"))
												.ContentPadding(FMargin(15, 8))
										]

									+ SHorizontalBox::Slot()
										.FillWidth(1.0f)
										.Padding(5, 0, 5, 0)
										[
											SNew(SBorder)
												.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
												.Padding(10)
												[
													SNew(SVerticalBox)

														+ SVerticalBox::Slot()
														.AutoHeight()
														.Padding(0, 0, 0, 5)
														[
															SNew(STextBlock)
																.Text(FText::FromString(TEXT("Effect Quality")))
																.Font(BoldFont)
														]

														+ SVerticalBox::Slot()
														.AutoHeight()
														[
															SAssignNew(EffectQualityComboBox, SComboBox<TSharedPtr<FString>>)
																.OptionsSource(&EffectQualityOptions)
																.OnSelectionChanged(this, &SEffectsTabPanel::OnEffectQualityChanged)
																.OnGenerateWidget_Lambda([](TSharedPtr<FString> Option) {
																return SNew(STextBlock).Text(FText::FromString(*Option));
																	})
																.Content()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(CurrentEffectQuality))
																]
														]
												]
										]
								]
						]

					// 第三格：刷新、搜索和过滤控件
					+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 0, 0, 10)
						[
							SNew(SHorizontalBox)

								// 刷新按钮
								+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SAssignNew(RefreshEffectsButton, SButton)
										.Text(FText::FromString(TEXT("Refresh Effects List")))
										.HAlign(HAlign_Center)
										.VAlign(VAlign_Center)
										.OnClicked(this, &SEffectsTabPanel::OnRefreshEffectsList)
										.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"))
										.ContentPadding(FMargin(10, 8))
								]

							// 搜索框
							+ SHorizontalBox::Slot()
								.FillWidth(2.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(10)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Search Effects")))
														.Font(BoldFont)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SAssignNew(EffectSearchBox, SSearchBox)
														.HintText(FText::FromString(TEXT("Search by name, level or complexity...")))
														.OnTextChanged(this, &SEffectsTabPanel::OnSearchTextChanged)
														.OnTextCommitted(this, &SEffectsTabPanel::OnSearchTextCommitted)
												]
										]
								]

							// 显示数量下拉框
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(10)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Display Count")))
														.Font(BoldFont)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SAssignNew(DisplayCountComboBox, SComboBox<TSharedPtr<FString>>)
														.OptionsSource(&DisplayCountOptions)
														.OnSelectionChanged(this, &SEffectsTabPanel::OnDisplayCountChanged)
														.OnGenerateWidget_Lambda([](TSharedPtr<FString> Option) {
														return SNew(STextBlock).Text(FText::FromString(*Option));
															})
														.Content()
														[
															SNew(STextBlock)
																.Text(FText::FromString(TEXT("50")))
														]
												]
										]
								]
						]

					// 第四格：特效列表表格
					+ SVerticalBox::Slot()
						.FillHeight(1.0f)
						.Padding(0, 0, 0, 10)
						[
							SNew(SBorder)
								.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
								.Padding(5)
								[
									SNew(SVerticalBox)

										// 表格标题
										+ SVerticalBox::Slot()
										.AutoHeight()
										.Padding(0, 0, 0, 5)
										[
											SNew(STextBlock)
												.Text(FText::FromString(TEXT("Effect List (Sorted by Particle Count)")))
												.Font(BoldFont)
										]

										// 表格
										+ SVerticalBox::Slot()
										.FillHeight(1.0f)
										[
											SAssignNew(EffectsListView, SListView<TSharedPtr<FEffectInfo>>)
												.ListItemsSource(&FilteredEffects)
												.OnGenerateRow(this, &SEffectsTabPanel::GenerateEffectRow)
												.HeaderRow
												(
													SNew(SHeaderRow)

													+ SHeaderRow::Column(TEXT("Name"))
													.DefaultLabel(FText::FromString(TEXT("Effect Name")))
													.FixedWidth(150)
													.HAlignHeader(HAlign_Left)
													.HAlignCell(HAlign_Left)

													+ SHeaderRow::Column(TEXT("Level"))
													.DefaultLabel(FText::FromString(TEXT("Level")))
													.FixedWidth(120)
													.HAlignHeader(HAlign_Left)
													.HAlignCell(HAlign_Left)

													+ SHeaderRow::Column(TEXT("GPU Particle"))
													.DefaultLabel(FText::FromString(TEXT("GPU Particle")))
													.FixedWidth(100)
													.HAlignHeader(HAlign_Center)
													.HAlignCell(HAlign_Center)

													+ SHeaderRow::Column(TEXT("Material Complexity"))
													.DefaultLabel(FText::FromString(TEXT("Material Complexity")))
													.FixedWidth(140)
													.HAlignHeader(HAlign_Left)
													.HAlignCell(HAlign_Left)

													+ SHeaderRow::Column(TEXT("Overdraw"))
													.DefaultLabel(FText::FromString(TEXT("Overdraw")))
													.FixedWidth(80)
													.HAlignHeader(HAlign_Center)
													.HAlignCell(HAlign_Center)

													+ SHeaderRow::Column(TEXT("Preplaced"))
													.DefaultLabel(FText::FromString(TEXT("Preplaced")))
													.FixedWidth(80)
													.HAlignHeader(HAlign_Center)
													.HAlignCell(HAlign_Center)

													+ SHeaderRow::Column(TEXT("Particle Count"))
													.DefaultLabel(FText::FromString(TEXT("Particle Count")))
													.FixedWidth(120)
													.HAlignHeader(HAlign_Right)
													.HAlignCell(HAlign_Right)
												)
										]

									// 底部状态栏
									+ SVerticalBox::Slot()
										.AutoHeight()
										.Padding(0, 5, 0, 0)
										[
											SNew(SHorizontalBox)

												+ SHorizontalBox::Slot()
												.FillWidth(1.0f)
												.Padding(8, 4, 8, 4)
												[
													SNew(STextBlock)
														.Text_Lambda([this]() {
														int32 Total = AllEffects.Num();
														int32 Filtered = FilteredEffects.Num();
														return FText::FromString(FString::Printf(TEXT("Showing %d of %d effects"), Filtered, Total));
															})
														.Font(RegularFont)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f))
														.Justification(ETextJustify::Left)
												]

											+ SHorizontalBox::Slot()
												.AutoWidth()
												.Padding(8, 4, 8, 4)
												[
													SNew(STextBlock)
														.Text_Lambda([this]() {
														int32 TotalParticles = 0;
														for (const auto& Effect : AllEffects)
														{
															TotalParticles += Effect->ParticleCount;
														}
														return FText::FromString(FString::Printf(TEXT("Total Particles: %dK"), TotalParticles / 1000));
															})
														.Font(RegularFont)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f))
														.Justification(ETextJustify::Right)
												]
										]
								]
						]
				]
		];

	// 初始刷新数据
	RefreshEffectsData();
}

TSharedRef<SWidget> SEffectsTabPanel::CreateTextColumn(const FString& Text, float Width, ETextJustify::Type Justify, TOptional<FLinearColor> Color)
{
	return SNew(SBox)
		.WidthOverride(Width)
		.HAlign(Justify == ETextJustify::Left ? HAlign_Left :
			Justify == ETextJustify::Right ? HAlign_Right :
			HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
				.Text(FText::FromString(Text))
				.Font(RegularFont)
				.Justification(Justify)
				.ColorAndOpacity(Color.Get(FLinearColor::White))
				.OverflowPolicy(ETextOverflowPolicy::Ellipsis)
		];
}

TSharedRef<ITableRow> SEffectsTabPanel::GenerateEffectRow(TSharedPtr<FEffectInfo> EffectInfo, const TSharedRef<STableViewBase>& OwnerTable)
{
	return SNew(STableRow<TSharedPtr<FEffectInfo>>, OwnerTable)
		[
			SNew(SHorizontalBox)

				// 特效名
				+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					CreateTextColumn(EffectInfo->Name, 150, ETextJustify::Left)
				]

				// 关卡
				+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					CreateTextColumn(EffectInfo->Level, 120, ETextJustify::Left)
				]

				// 是否GPU粒子
				+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SBox)
						.WidthOverride(100)
						.HAlign(HAlign_Center)
						.VAlign(VAlign_Center)
						[
							SNew(STextBlock)
								.Text(FText::FromString(EffectInfo->bIsGPUParticle ? TEXT("Yes") : TEXT("No")))
								.Font(RegularFont)
								.Justification(ETextJustify::Center)
								.ColorAndOpacity(EffectInfo->bIsGPUParticle ? FLinearColor(0.2f, 0.8f, 0.2f) : FLinearColor(0.7f, 0.7f, 0.7f))
						]
				]

			// 材质复杂度
			+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SBox)
						.WidthOverride(140)
						.HAlign(HAlign_Left)
						.VAlign(VAlign_Center)
						[
							SNew(STextBlock)
								.Text(FText::FromString(EffectInfo->MaterialComplexity))
								.Font(RegularFont)
								.Justification(ETextJustify::Left)
								.ColorAndOpacity(
									EffectInfo->MaterialComplexity == TEXT("Very High") ? FLinearColor(0.8f, 0.2f, 0.2f) :
									EffectInfo->MaterialComplexity == TEXT("High") ? FLinearColor(0.8f, 0.8f, 0.2f) :
									EffectInfo->MaterialComplexity == TEXT("Medium") ? FLinearColor(0.2f, 0.8f, 0.8f) :
									FLinearColor(0.2f, 0.8f, 0.2f))
						]
				]

			// 叠层
			+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SBox)
						.WidthOverride(80)
						.HAlign(HAlign_Center)
						.VAlign(VAlign_Center)
						[
							SNew(STextBlock)
								.Text(FText::FromString(FString::Printf(TEXT("%d"), EffectInfo->OverdrawCount)))
								.Font(RegularFont)
								.Justification(ETextJustify::Center)
								.ColorAndOpacity(
									EffectInfo->OverdrawCount > 4 ? FLinearColor(0.8f, 0.2f, 0.2f) :
									EffectInfo->OverdrawCount > 2 ? FLinearColor(0.8f, 0.8f, 0.2f) :
									FLinearColor(0.2f, 0.8f, 0.2f))
						]
				]

			// 预摆设
			+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SBox)
						.WidthOverride(80)
						.HAlign(HAlign_Center)
						.VAlign(VAlign_Center)
						[
							SNew(STextBlock)
								.Text(FText::FromString(EffectInfo->bIsPreplaced ? TEXT("Yes") : TEXT("No")))
								.Font(RegularFont)
								.Justification(ETextJustify::Center)
								.ColorAndOpacity(EffectInfo->bIsPreplaced ? FLinearColor(0.2f, 0.6f, 1.0f) : FLinearColor(0.7f, 0.7f, 0.7f))
						]
				]

			// 粒子数（排序用）
			+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SBox)
						.WidthOverride(120)
						.HAlign(HAlign_Right)
						.VAlign(VAlign_Center)
						[
							SNew(STextBlock)
								.Text(FText::FromString(FString::Printf(TEXT("%d"), EffectInfo->ParticleCount)))
								.Font(RegularFont)
								.Justification(ETextJustify::Right)
								.ColorAndOpacity(
									EffectInfo->ParticleCount > 10000 ? FLinearColor(0.8f, 0.2f, 0.2f) :
									EffectInfo->ParticleCount > 5000 ? FLinearColor(0.8f, 0.8f, 0.2f) :
									FLinearColor(0.2f, 0.8f, 0.2f))
						]
				]
		];
}

void SEffectsTabPanel::RefreshEffectsData()
{
	// 计算统计数据
	int32 ActiveEmitterCount = AllEffects.Num();
	int32 TotalParticleCount = 0;
	float TotalMaterialComplexity = 0.0f;
	int32 TotalOverdraw = 0;

	for (const auto& Effect : AllEffects)
	{
		TotalParticleCount += Effect->ParticleCount;
		TotalOverdraw += Effect->OverdrawCount;

		// 转换材质复杂度为数值
		if (Effect->MaterialComplexity == TEXT("Very High"))
			TotalMaterialComplexity += 4.0f;
		else if (Effect->MaterialComplexity == TEXT("High"))
			TotalMaterialComplexity += 3.0f;
		else if (Effect->MaterialComplexity == TEXT("Medium"))
			TotalMaterialComplexity += 2.0f;
		else
			TotalMaterialComplexity += 1.0f;
	}

	float AvgMaterialComplexity = TotalMaterialComplexity / ActiveEmitterCount;

	ActiveEmitterCountLabel->SetText(FText::FromString(FString::Printf(TEXT("%d"), ActiveEmitterCount)));
	TotalParticleCountLabel->SetText(FText::FromString(FString::Printf(TEXT("%.1fK"), TotalParticleCount / 1000.0f)));
	MaterialComplexityLabel->SetText(FText::FromString(FString::Printf(TEXT("%.1f"), AvgMaterialComplexity)));
	OverdrawTotalLabel->SetText(FText::FromString(FString::Printf(TEXT("%d"), TotalOverdraw)));

	// 根据数值设置颜色警告
	if (ActiveEmitterCount > 20)
	{
		ActiveEmitterCountLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f));
	}
	else if (ActiveEmitterCount > 10)
	{
		ActiveEmitterCountLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.8f, 0.2f, 1.0f));
	}
	else
	{
		ActiveEmitterCountLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f));
	}

	if (TotalParticleCount > 100000)
	{
		TotalParticleCountLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f));
	}
	else if (TotalParticleCount > 50000)
	{
		TotalParticleCountLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.8f, 0.2f, 1.0f));
	}
	else
	{
		TotalParticleCountLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f));
	}

	if (AvgMaterialComplexity > 3.5f)
	{
		MaterialComplexityLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f));
	}
	else if (AvgMaterialComplexity > 2.5f)
	{
		MaterialComplexityLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.8f, 0.2f, 1.0f));
	}
	else
	{
		MaterialComplexityLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f));
	}

	if (TotalOverdraw > 30)
	{
		OverdrawTotalLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f));
	}
	else if (TotalOverdraw > 20)
	{
		OverdrawTotalLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.8f, 0.2f, 1.0f));
	}
	else
	{
		OverdrawTotalLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f));
	}
}

void SEffectsTabPanel::SortEffectsList()
{
	Algo::Sort(AllEffects, [](const TSharedPtr<FEffectInfo>& A, const TSharedPtr<FEffectInfo>& B) {
		return A->ParticleCount > B->ParticleCount; // 从大到小排序
		});
}

void SEffectsTabPanel::FilterEffectsList()
{
	FilteredEffects.Empty();

	for (const auto& Effect : AllEffects)
	{
		// 应用搜索过滤
		if (!CurrentSearchText.IsEmpty())
		{
			FString SearchTextLower = CurrentSearchText.ToLower();
			FString NameLower = Effect->Name.ToLower();
			FString LevelLower = Effect->Level.ToLower();
			FString ComplexityLower = Effect->MaterialComplexity.ToLower();

			if (!NameLower.Contains(SearchTextLower) &&
				!LevelLower.Contains(SearchTextLower) &&
				!ComplexityLower.Contains(SearchTextLower))
			{
				continue;
			}
		}

		FilteredEffects.Add(Effect);
	}

	// 应用数量限制
	if (CurrentDisplayCount > 0 && FilteredEffects.Num() > CurrentDisplayCount)
	{
		FilteredEffects.SetNum(CurrentDisplayCount);
	}

	// 刷新列表视图
	if (EffectsListView.IsValid())
	{
		EffectsListView->RequestListRefresh();
	}
}

FReply SEffectsTabPanel::OnRefreshEffectsList()
{
	UE_LOG(LogTemp, Log, TEXT("Refresh effects list"));

	// 模拟添加新特效
	static int32 NewEffectCounter = 1;
	const TArray<FString> Complexities = { TEXT("Low"), TEXT("Medium"), TEXT("High"), TEXT("Very High") };
	const TArray<FString> Levels = { TEXT("Main_Level"), TEXT("Combat_Level"), TEXT("Magic_Level"), TEXT("Outdoor_Level") };

	AllEffects.Add(MakeShared<FEffectInfo>(
		FString::Printf(TEXT("New_Effect_%d"), NewEffectCounter++),
		Levels[FMath::RandRange(0, 3)],
		FMath::RandBool(),
		Complexities[FMath::RandRange(0, 3)],
		FMath::RandRange(1, 5),
		FMath::RandBool(),
		FMath::RandRange(1000, 20000)
	));

	SortEffectsList();
	FilterEffectsList();
	RefreshEffectsData();

	// 显示通知
	FNotificationInfo Info(FText::FromString(TEXT("Effects list refreshed")));
	Info.ExpireDuration = 2.0f;
	FSlateNotificationManager::Get().AddNotification(Info);

	return FReply::Handled();
}

FReply SEffectsTabPanel::OnSelfCheckEffects()
{
	UE_LOG(LogTemp, Log, TEXT("Self check effects"));

	// 检查潜在问题
	TArray<FString> Issues;

	int32 TotalParticles = 0;
	int32 HighComplexityCount = 0;
	int32 HighOverdrawCount = 0;

	for (const auto& Effect : AllEffects)
	{
		TotalParticles += Effect->ParticleCount;

		if (Effect->MaterialComplexity == TEXT("Very High") || Effect->MaterialComplexity == TEXT("High"))
		{
			HighComplexityCount++;
		}

		if (Effect->OverdrawCount > 3)
		{
			HighOverdrawCount++;
		}
	}

	if (TotalParticles > 100000)
	{
		Issues.Add(FString::Printf(TEXT("Total particles too high: %dK (recommend <= 100K)"), TotalParticles / 1000));
	}

	if (HighComplexityCount > 5)
	{
		Issues.Add(FString::Printf(TEXT("Too many high complexity effects: %d (recommend <= 5)"), HighComplexityCount));
	}

	if (HighOverdrawCount > 3)
	{
		Issues.Add(FString::Printf(TEXT("Too many high overdraw effects: %d (recommend <= 3)"), HighOverdrawCount));
	}

	// 显示结果
	if (Issues.Num() > 0)
	{
		FString Message = TEXT("Effect performance issues found:\n");
		for (const auto& Issue : Issues)
		{
			Message += TEXT("• ") + Issue + TEXT("\n");
		}

		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
	}
	else
	{
		FNotificationInfo Info(FText::FromString(TEXT("No effect performance issues found")));
		Info.ExpireDuration = 3.0f;
		FSlateNotificationManager::Get().AddNotification(Info);
	}

	return FReply::Handled();
}

void SEffectsTabPanel::OnOverdrawViewChanged(ECheckBoxState NewState)
{
	bOverdrawViewEnabled = (NewState == ECheckBoxState::Checked);
	UE_LOG(LogTemp, Log, TEXT("OverDraw View: %s"), bOverdrawViewEnabled ? TEXT("Enabled") : TEXT("Disabled"));

	// 这里应该切换OverDraw视图模式
}

void SEffectsTabPanel::OnMaterialComplexityChanged(ECheckBoxState NewState)
{
	bMaterialComplexityEnabled = (NewState == ECheckBoxState::Checked);
	UE_LOG(LogTemp, Log, TEXT("Material Complexity View: %s"), bMaterialComplexityEnabled ? TEXT("Enabled") : TEXT("Disabled"));

	// 这里应该切换Material Complexity视图模式
}

void SEffectsTabPanel::OnEffectHierarchyChanged(ECheckBoxState NewState)
{
	bEffectHierarchyEnabled = (NewState == ECheckBoxState::Checked);
	UE_LOG(LogTemp, Log, TEXT("Effect Hierarchy: %s"), bEffectHierarchyEnabled ? TEXT("Enabled") : TEXT("Disabled"));

	// 这里应该显示/隐藏特效层级
}

void SEffectsTabPanel::OnOverdrawDisplayChanged(ECheckBoxState NewState)
{
	bOverdrawDisplayEnabled = (NewState == ECheckBoxState::Checked);
	UE_LOG(LogTemp, Log, TEXT("Overdraw Display: %s"), bOverdrawDisplayEnabled ? TEXT("Enabled") : TEXT("Disabled"));

	// 这里应该显示/隐藏叠层显示
}

void SEffectsTabPanel::OnEffectQualityChanged(TSharedPtr<FString> NewSelection, ESelectInfo::Type SelectType)
{
	if (NewSelection.IsValid())
	{
		CurrentEffectQuality = *NewSelection;
		UE_LOG(LogTemp, Log, TEXT("Effect Quality changed to: %s"), *CurrentEffectQuality);

		// 这里应该应用特效质量设置
	}
}

void SEffectsTabPanel::OnDisplayCountChanged(TSharedPtr<FString> NewSelection, ESelectInfo::Type SelectType)
{
	if (NewSelection.IsValid())
	{
		if (*NewSelection == TEXT("All"))
		{
			CurrentDisplayCount = -1; // 表示显示所有
		}
		else
		{
			CurrentDisplayCount = FCString::Atoi(**NewSelection);
		}

		UE_LOG(LogTemp, Log, TEXT("Display count changed to: %s"), **NewSelection);
		FilterEffectsList();
	}
}

void SEffectsTabPanel::OnSearchTextChanged(const FText& SearchText)
{
	CurrentSearchText = SearchText.ToString();
	FilterEffectsList();
}

void SEffectsTabPanel::OnSearchTextCommitted(const FText& SearchText, ETextCommit::Type CommitType)
{
	CurrentSearchText = SearchText.ToString();
	FilterEffectsList();
}