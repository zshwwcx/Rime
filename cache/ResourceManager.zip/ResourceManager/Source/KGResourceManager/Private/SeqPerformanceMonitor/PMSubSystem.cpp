#include "SeqPerformanceMonitor/PMSubSystem.h"

#include "Stats/StatsData.h"
#include "Stats/Stats2.h"

#include "LevelSequenceEditorBlueprintLibrary.h"
#include "LevelSequence.h"
#include "Engine/Light.h"

void FPerfData::Enable()
{
	StatsPrimaryEnableAdd();
	FStatsThreadState& Stats = FStatsThreadState::GetLocalState();
	Stats.NewFrameDelegate.AddRaw(this, &FPerfData::OnStatUpdateCB);

	StartTime = (double)FDateTime::Now().GetTicks() / static_cast<double>(ETimespan::TicksPerSecond);
}

void FPerfData::Disable()
{
	StatsPrimaryEnableSubtract();
	FStatsThreadState& Stats = FStatsThreadState::GetLocalState();
	Stats.NewFrameDelegate.RemoveAll(this);

}

double FPerfData::GetCycleTimeMS(const FStatMessage& InStatMessage)
{
	int64 Cycles = InStatMessage.GetValue_Duration();
	return FPlatformTime::ToMilliseconds(Cycles);
}

void FPerfData::OnStatUpdateCB(int64 frame)
{
	if (!FThreadStats::IsCollectingData())
	{
		UE_LOG(LogTemp, Warning, TEXT("Stats collection is not enabled"));
		return;
	}

	double ct = FDateTime::Now().GetTicks() / static_cast<double>(ETimespan::TicksPerSecond);
	Time = (double)(ct - StartTime);

	FStatsThreadState& Stats = FStatsThreadState::GetLocalState();

	// 1. 读取关键性能指标
	//UE_LOG(LogTemp, Log, TEXT("=== Performance Stats ==="));

	// 获取最新帧号
	int64 LatestFrame = Stats.GetLatestValidFrame();

	// 获取聚合统计数据
	TArray<FStatMessage> AggregateStats;
	Stats.GetInclusiveAggregateStackStats(LatestFrame, AggregateStats);


	// 筛选特定组的统计
	for (const FStatMessage& Message : AggregateStats)
	{
		// 打印Message里的类型和数值到日志
		FName ShortName = Message.NameAndInfo.GetShortName();
		FName GroupName = Message.NameAndInfo.GetGroupName();
		FString Description = Message.NameAndInfo.GetDescription();

		// 获取统计值的类型
		EStatDataType::Type StatType = Message.NameAndInfo.GetField<EStatDataType>();

		// 获取统计标志位
		bool bIsCycle = Message.NameAndInfo.GetFlag(EStatMetaFlags::IsCycle);
		bool bIsMemory = Message.NameAndInfo.GetFlag(EStatMetaFlags::IsMemory);
		//bool bIsCounter = Message.NameAndInfo.GetFlag(EStatMetaFlags::IsCounter);
		bool bIsPacked = Message.NameAndInfo.GetFlag(EStatMetaFlags::IsPackedCCAndDuration);

		FString TypeString;
		FString ValueString;
		double ValueDouble = 0.0;
		int64 ValueInt64 = 0;



		if (GroupName == GroupName_STATGROUP_Engine)
		{
			if (ShortName == StatName_STAT_FrameTime)
			{
				FrameTime = GetCycleTimeMS(Message);
				FPS = (FrameTime > 0.0f) ? static_cast<int32>(1000.0f / FrameTime) : 0;
			}
			else if (ShortName == STAT_GameThreadTime)
			{
				GameThreadTime = GetCycleTimeMS(Message);
			}
			else if (ShortName == STAT_RenderThreadTime)
			{
				RenderThreadTime = GetCycleTimeMS(Message);
			}
			else if (ShortName == STAT_RHITickTime)
			{
				RHIThreadTime = GetCycleTimeMS(Message);
			}
			else if (ShortName == STAT_StaticMeshTriangles)
			{
				StaticMeshTriangles = Message.GetValue_int64();
			}

		}
		else if (GroupName == GroupName_STATGROUP_Game)
		{
			//TODO
		}
		else if (GroupName == STATGROUP_RHI)
		{
			if (ShortName == STAT_RHITriangles)
			{
				TrianglesNum = Message.GetValue_int64();
			}
			else if (ShortName == STAT_RHIDrawPrimitiveCalls)
			{
				DrawCalls = static_cast<int32>(Message.GetValue_int64());
			}
		}
		else if (GroupName == STATGROUP_LightRendering)
		{
			if (ShortName == STAT_NumLightsUsingStandardDeferred)
			{
				NumLights = static_cast<int32>(Message.GetValue_int64());
			}
			else if (ShortName == STAT_NumShadowedLights)
			{
				NumShadowedLights = static_cast<int32>(Message.GetValue_int64());
			}
		}
		else if (GroupName == STATGROUP_DebugView)
		{
			if (ShortName == STATGROUP_DebugView_LightComplexityAvg)
			{
				LightComplexityAvg = static_cast<float>(Message.GetValue_double());
			}
		}
	}


	FrameIndex = LatestFrame;
}


int32 FPerfData::CollectSequenceData(class UWorld* InWorld, TArray<AActor*>& OutLightActors)
{
	ULevelSequence* LevelSeqToSave = ULevelSequenceEditorBlueprintLibrary::GetCurrentLevelSequence();
	if (LevelSeqToSave == nullptr)
	{
		return 0;
	}

	const FMovieSceneBindingReferences* msbr = LevelSeqToSave->GetBindingReferences();

	TArrayView<const FMovieSceneBindingReference> msbrs = msbr->GetAllReferences();
	for (const FMovieSceneBindingReference& i : msbrs)
	{
		UObject* obj = i.Locator.SyncFind(InWorld);
		ALight* light = Cast<ALight>(obj);
		if (light)
		{
			OutLightActors.Add(light);
		}

	}

	return OutLightActors.Num();
}