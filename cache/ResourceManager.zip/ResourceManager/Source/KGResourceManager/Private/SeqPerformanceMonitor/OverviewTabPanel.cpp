#include "SeqPerformanceMonitor/OverviewTabPanel.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SSplitter.h"
#include "Styling/CoreStyle.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Brushes/SlateColorBrush.h"
#include "Fonts/FontMeasure.h"

void SLineChartWidget::Construct(const FArguments& InArgs)
{
	ChartConfig = InArgs._ChartConfig;
	DataPoints.SetMaxSize(ChartConfig.MaxDataPoints);

	ChildSlot
		[
			SNew(SBox)
				.WidthOverride(ChartConfig.ChartSize.X)
				.HeightOverride(ChartConfig.ChartSize.Y)
				[
					SNew(SBorder)
						.BorderImage(FAppStyle::GetBrush("ToolPanel.DarkGroupBorder"))
						.Padding(20, 30, 30, 20)
						.HAlign(HAlign_Fill)
						.VAlign(VAlign_Fill)
						[
							SNew(SOverlay)

								// 图表标题
								+ SOverlay::Slot()
								.HAlign(HAlign_Center)
								.VAlign(VAlign_Top)
								.Padding(0, -25, 0, 0)
								[
									SNew(STextBlock)
										.Text(FText::FromString(ChartConfig.Title))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12))
										.ColorAndOpacity(FLinearColor::White)
								]

								// Y轴标签
								+ SOverlay::Slot()
								.HAlign(HAlign_Left)
								.VAlign(VAlign_Center)
								.Padding(-25, 0, 0, 0)
								[
									SNew(STextBlock)
										.Text(FText::FromString(ChartConfig.YAxisLabel))
										.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
										.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f))
								]

								// X轴标签
								+ SOverlay::Slot()
								.HAlign(HAlign_Center)
								.VAlign(VAlign_Bottom)
								.Padding(0, 0, 0, -25)
								[
									SNew(STextBlock)
										.Text(FText::FromString(ChartConfig.XAxisLabel))
										.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
										.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f))
								]

								// 图表绘制区域
								+ SOverlay::Slot()
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("NoBorder"))
										.HAlign(HAlign_Fill)
										.VAlign(VAlign_Fill)
								]
						]
				]
		];
}

int32 SLineChartWidget::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	int32 CurrentLayerId = LayerId;

	DrawGridAndAxis(AllottedGeometry, MyCullingRect, OutDrawElements, CurrentLayerId);

	if (DataPoints.Num() >= 2)
	{
		DrawLineChart(AllottedGeometry, MyCullingRect, OutDrawElements, CurrentLayerId);
	}

	if (ChartConfig.bShowPoints && DataPoints.Num() > 0)
	{
		DrawDataPoints(AllottedGeometry, MyCullingRect, OutDrawElements, CurrentLayerId);
	}

	if (ChartConfig.bShowValueLabels && DataPoints.Num() > 0)
	{
		DrawValueLabels(AllottedGeometry, MyCullingRect, OutDrawElements, CurrentLayerId);
	}

	return CurrentLayerId;
}

void SLineChartWidget::DrawGridAndAxis(const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32& LayerId) const
{
	const FVector2D Size = AllottedGeometry.GetLocalSize();
	const float Width = Size.X;
	const float Height = Size.Y;

	// 绘制坐标轴
	TArray<FVector2D> AxisLines;
	AxisLines.Add(FVector2D(0, Height));
	AxisLines.Add(FVector2D(0, 0));
	AxisLines.Add(FVector2D(0, Height));
	AxisLines.Add(FVector2D(Width, Height));

	FSlateDrawElement::MakeLines(
		OutDrawElements,
		LayerId++,
		AllottedGeometry.ToPaintGeometry(),
		AxisLines,
		ESlateDrawEffect::None,
		FLinearColor(0.4f, 0.4f, 0.4f, 0.8f),
		true,
		1.5f
	);

	if (!ChartConfig.bShowGrid)
		return;

	// 计算时间范围
	float MinX, MaxX;
	CalculateVisibleRange(MinX, MaxX);

	// 绘制网格线
	TArray<FVector2D> GridLines;

	// 垂直网格线
	for (int32 i = 1; i < ChartConfig.GridLineCount; i++)
	{
		float X = (Width / ChartConfig.GridLineCount) * i;
		GridLines.Add(FVector2D(X, 0));
		GridLines.Add(FVector2D(X, Height));

		// X轴刻度标签
		if (MaxX > MinX)
		{
			float TimeValue = MinX + (MaxX - MinX) * (i / static_cast<float>(ChartConfig.GridLineCount));
			FString TimeLabel = FString::Printf(TEXT("%.1f"), TimeValue);

			FSlateDrawElement::MakeText(
				OutDrawElements,
				LayerId,
				AllottedGeometry.ToOffsetPaintGeometry(FVector2D(X - 10, Height + 5)),
				FText::FromString(TimeLabel),
				FCoreStyle::GetDefaultFontStyle("Regular", 8),
				ESlateDrawEffect::None,
				FLinearColor(0.6f, 0.6f, 0.6f)
			);
		}
	}

	// 水平网格线
	for (int32 i = 0; i <= ChartConfig.GridLineCount; i++)
	{
		float Y = (Height / ChartConfig.GridLineCount) * i;
		GridLines.Add(FVector2D(0, Y));
		GridLines.Add(FVector2D(Width, Y));

		// Y轴刻度标签
		float Value = ChartConfig.MaxYValue - (ChartConfig.MaxYValue - ChartConfig.MinYValue) * (i / static_cast<float>(ChartConfig.GridLineCount));
		FString ValueLabel = FormatValue(Value);

		FSlateDrawElement::MakeText(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToOffsetPaintGeometry(FVector2D(-35, Y - 6)),
			FText::FromString(ValueLabel),
			FCoreStyle::GetDefaultFontStyle("Regular", 8),
			ESlateDrawEffect::None,
			FLinearColor(0.6f, 0.6f, 0.6f)
		);
	}

	// 绘制网格线
	if (GridLines.Num() > 0)
	{
		FSlateDrawElement::MakeLines(
			OutDrawElements,
			LayerId++,
			AllottedGeometry.ToPaintGeometry(),
			GridLines,
			ESlateDrawEffect::None,
			FLinearColor(0.2f, 0.2f, 0.2f, 0.3f),
			true,
			0.5f
		);
	}
}

void SLineChartWidget::DrawLineChart(const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32& LayerId) const
{
	const FVector2D Size = AllottedGeometry.GetLocalSize();

	// 计算时间范围
	float MinX, MaxX;
	CalculateVisibleRange(MinX, MaxX);

	// 计算可见点数和起始索引
	int32 VisibleCount = FMath::Min(ChartConfig.VisiblePoints, DataPoints.Num());
	int32 StartIndex = FMath::Max(0, DataPoints.Num() - VisibleCount);

	// 准备折线点
	TArray<FVector2D> LinePoints;
	int32 SampleCounter = 0;

	for (int32 i = StartIndex; i < DataPoints.Num(); ++i)
	{
		if (ChartConfig.SampleRate > 1)
		{
			SampleCounter++;
			if (SampleCounter % ChartConfig.SampleRate != 0 && i != DataPoints.Num() - 1)
			{
				continue; // 跳过采样
			}
		}

		const FChartDataPoint& DataPoint = DataPoints[i];
		FVector2D ScreenPoint = NormalizeToScreen(
			FVector2D(DataPoint.X, DataPoint.Y),
			Size,
			MinX, MaxX
		);
		LinePoints.Add(ScreenPoint);
	}

	// 绘制曲线
	if (LinePoints.Num() > 1)
	{
		FSlateDrawElement::MakeLines(
			OutDrawElements,
			LayerId++,
			AllottedGeometry.ToPaintGeometry(),
			LinePoints,
			ESlateDrawEffect::None,
			ChartConfig.LineColor,
			true,
			ChartConfig.LineThickness
		);
	}
}

void SLineChartWidget::DrawDataPoints(const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32& LayerId) const
{
	const FVector2D Size = AllottedGeometry.GetLocalSize();

	// 计算时间范围
	float MinX, MaxX;
	CalculateVisibleRange(MinX, MaxX);

	// 只绘制最后的几个数据点
	const int32 MaxPointsToDraw = 1;// FMath::Min(ChartConfig.VisiblePoints / 2, 20);
	const int32 StartIndex = FMath::Max(0, DataPoints.Num() - MaxPointsToDraw);

	for (int32 i = StartIndex; i < DataPoints.Num(); ++i)
	{
		const FChartDataPoint& DataPoint = DataPoints[i];
		FVector2D ScreenPoint = NormalizeToScreen(
			FVector2D(DataPoint.X, DataPoint.Y),
			Size,
			MinX, MaxX
		);

		// 绘制圆形数据点
		FSlateDrawElement::MakeBox(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToPaintGeometry(FVector2D(6, 6), FSlateLayoutTransform(ScreenPoint - FVector2D(3, 3))),
			FAppStyle::GetBrush("WhiteBrush"),
			ESlateDrawEffect::None,
			ChartConfig.LineColor
		);

		// 绘制数据点边框
		FSlateDrawElement::MakeBox(
			OutDrawElements,
			LayerId + 1,
			AllottedGeometry.ToPaintGeometry(FVector2D(8, 8), FSlateLayoutTransform(ScreenPoint - FVector2D(4, 4))),
			FAppStyle::GetBrush("WhiteBrush"),
			ESlateDrawEffect::None,
			FLinearColor::Black
		);
	}

	LayerId += 2;
}

void SLineChartWidget::DrawValueLabels(const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32& LayerId) const
{
	if (DataPoints.Num() == 0)
		return;

	const FVector2D Size = AllottedGeometry.GetLocalSize();

	// 计算时间范围
	float MinX, MaxX;
	CalculateVisibleRange(MinX, MaxX);

	// 只显示最后几个数据点的标签
	const int32 NumLabelsToShow = FMath::Min(5, DataPoints.Num());
	for (int32 i = DataPoints.Num() - NumLabelsToShow; i < DataPoints.Num(); i++)
	{
		const FChartDataPoint& DataPoint = DataPoints[i];
		FVector2D ScreenPoint = NormalizeToScreen(
			FVector2D(DataPoint.X, DataPoint.Y),
			Size,
			MinX, MaxX
		);

		// 格式化数值
		FString ValueText = FormatValue(DataPoint.Y);

		// 计算标签位置
		FVector2D LabelPosition = ScreenPoint + FVector2D(5, -15);

		// 确保标签在图表范围内
		if (LabelPosition.Y < 0) LabelPosition.Y = 0;
		if (LabelPosition.X > Size.X - 30) LabelPosition.X = Size.X - 30;

		// 绘制数值标签
		FSlateDrawElement::MakeText(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToOffsetPaintGeometry(LabelPosition),
			FText::FromString(ValueText),
			FCoreStyle::GetDefaultFontStyle("Regular", 9),
			ESlateDrawEffect::None,
			FLinearColor::White
		);

		// 绘制标签背景
		FSlateDrawElement::MakeBox(
			OutDrawElements,
			LayerId - 1,
			AllottedGeometry.ToPaintGeometry(
				FVector2D(30, 15),
				FSlateLayoutTransform(LabelPosition - FVector2D(2, 2))
			),
			FAppStyle::GetBrush("WhiteBrush"),
			ESlateDrawEffect::None,
			FLinearColor(0.1f, 0.1f, 0.1f, 0.7f)
		);
	}

	LayerId += 2;
}

FVector2D SLineChartWidget::NormalizeToScreen(const FVector2D& DataPoint, const FVector2D& ScreenSize, float MinX, float MaxX) const
{
	// X轴归一化
	float NormalizedX = (MaxX > MinX) ? ((DataPoint.X - MinX) / (MaxX - MinX)) : 0.0f;
	NormalizedX = FMath::Clamp(NormalizedX, 0.0f, 1.0f);

	// Y轴归一化（使用配置的范围）
	float NormalizedY = (ChartConfig.MaxYValue > ChartConfig.MinYValue) ?
		((DataPoint.Y - ChartConfig.MinYValue) / (ChartConfig.MaxYValue - ChartConfig.MinYValue)) : 0.0f;
	NormalizedY = FMath::Clamp(NormalizedY, 0.0f, 1.0f);

	// 转换为屏幕坐标
	float ScreenX = NormalizedX * ScreenSize.X;
	float ScreenY = ScreenSize.Y - (NormalizedY * ScreenSize.Y);

	return FVector2D(ScreenX, ScreenY);
}

FString SLineChartWidget::FormatValue(float Value) const
{
	if (FMath::IsNaN(Value))
		return TEXT("NaN");
	//if (FMath::IsInfinite(Value))
	//	return Value > 0 ? TEXT("+∞") : TEXT("-∞");

	return FString::Printf(TEXT("%.0f"), Value);
}

void SLineChartWidget::CalculateVisibleRange(float& OutMinX, float& OutMaxX) const
{
	if (DataPoints.Num() == 0)
	{
		OutMinX = 0.0f;
		OutMaxX = ChartConfig.TimeWindow;
		return;
	}

	// 基于时间窗口计算可见范围
	if (ChartConfig.TimeWindow > 0.0f)
	{
		const FChartDataPoint& LastPoint = DataPoints.GetLast();
		OutMaxX = LastPoint.X;
		OutMinX = OutMaxX - ChartConfig.TimeWindow;

		// 确保最小值不小于第一个数据点的时间
		if (OutMinX < DataPoints.GetFirst().X)
		{
			OutMinX = DataPoints.GetFirst().X;
		}
	}
	else
	{
		// 显示所有数据点的时间范围
		OutMinX = DataPoints.GetFirst().X;
		OutMaxX = DataPoints.GetLast().X;

		// 如果只有一个点，显示合理的时间范围
		if (OutMinX == OutMaxX)
		{
			OutMinX -= 1.0f;
			OutMaxX += 1.0f;
		}
	}
}

// 接口实现
void SLineChartWidget::SetDataPoints(const TArray<FChartDataPoint>& NewDataPoints)
{
	DataPoints.Empty();
	DataPoints.SetMaxSize(ChartConfig.MaxDataPoints);

	for (const auto& Point : NewDataPoints)
	{
		DataPoints.Add(Point);
	}

	Invalidate(EInvalidateWidget::Paint);
}

void SLineChartWidget::SetChartConfig(const FLineChartConfig& NewConfig)
{
	ChartConfig = NewConfig;
	DataPoints.SetMaxSize(ChartConfig.MaxDataPoints);

	Invalidate(EInvalidateWidget::Paint | EInvalidateWidget::Layout);
}

TArray<FChartDataPoint> SLineChartWidget::GetDataPoints() const
{
	TArray<FChartDataPoint> Result;
	Result.Reserve(DataPoints.Num());

	for (int32 i = 0; i < DataPoints.Num(); ++i)
	{
		Result.Add(DataPoints[i]);
	}

	return Result;
}

void SLineChartWidget::ClearData()
{
	DataPoints.Empty();
	Invalidate(EInvalidateWidget::Paint);
}

void SLineChartWidget::AddDataPoint(const FChartDataPoint& NewPoint)
{
	//if (NewPoint.Y <= ChartConfig.MaxYValue)
	//{
	//	SetYRange(ChartConfig.MinYValue, NewPoint.Y * 1.1f);
	//}
	DataPoints.Add(NewPoint);
	Invalidate(EInvalidateWidget::Paint);
}

void SLineChartWidget::AddDataPoint(float X, float Y)
{
	AddDataPoint(FChartDataPoint(X, Y));
}

void SLineChartWidget::SetVisiblePoints(int32 Points)
{
	ChartConfig.VisiblePoints = FMath::Max(1, Points);
	Invalidate(EInvalidateWidget::Paint);
}

void SLineChartWidget::SetYRange(float MinY, float MaxY)
{
	if (MaxY > MinY)
	{
		ChartConfig.MinYValue = MinY;
		ChartConfig.MaxYValue = MaxY;
		Invalidate(EInvalidateWidget::Paint);
	}
}

void SLineChartWidget::SetTimeWindow(float Seconds)
{
	ChartConfig.TimeWindow = FMath::Max(0.0f, Seconds);
	Invalidate(EInvalidateWidget::Paint);
}

void SLineChartWidget::SetSampleRate(int32 Rate)
{
	ChartConfig.SampleRate = FMath::Max(1, Rate);
	Invalidate(EInvalidateWidget::Paint);
}
void SOverviewTabPanel::Construct(const FArguments& InArgs)
{
	// 创建FPS图表配置
	FLineChartConfig FPSConfig;
	FPSConfig.Title = TEXT("FPS Trend (0.5s interval)");
	FPSConfig.YAxisLabel = TEXT("FPS");
	FPSConfig.LineColor = FLinearColor(0.2f, 0.5f, 1.0f, 1.0f); // 蓝色
	FPSConfig.ChartSize = FVector2D(800, 400);
	FPSConfig.bShowPoints = true;
	FPSConfig.bShowValueLabels = true;
	FPSConfig.bShowGrid = true;
	FPSConfig.LineThickness = 1.0f;

	// 创建Tris图表配置 - 单位改为千(K)
	FLineChartConfig TrisConfig;
	TrisConfig.Title = TEXT("Triangles Trend (0.5s interval)");
	TrisConfig.YAxisLabel = TEXT("Tris (K)");  // 从M改为K
	TrisConfig.LineColor = FLinearColor(0.2f, 0.8f, 0.2f, 1.0f); // 绿色
	TrisConfig.ChartSize = FVector2D(800, 400);
	TrisConfig.bShowPoints = true;
	TrisConfig.bShowValueLabels = true;
	TrisConfig.bShowGrid = true;
	TrisConfig.LineThickness = 1.0f;
	TrisConfig.MaxYValue = 1000.0f;  // 调整Y轴范围，以千为单位

	// 创建DrawCalls图表配置
	FLineChartConfig DrawCallConfig;
	DrawCallConfig.Title = TEXT("Draw Calls Trend (0.5s interval)");
	DrawCallConfig.YAxisLabel = TEXT("Draw Calls");
	DrawCallConfig.LineColor = FLinearColor(0.8f, 0.2f, 0.2f, 1.0f); // 红色
	DrawCallConfig.ChartSize = FVector2D(800, 400);
	DrawCallConfig.bShowPoints = true;
	DrawCallConfig.bShowValueLabels = true;
	DrawCallConfig.bShowGrid = true;
	DrawCallConfig.LineThickness = 1.0f;
	DrawCallConfig.MaxYValue = 1000;

	// 创建三个图表
	FPSChart = SNew(SLineChartWidget).ChartConfig(FPSConfig);
	TrisChart = SNew(SLineChartWidget).ChartConfig(TrisConfig);
	DrawCallChart = SNew(SLineChartWidget).ChartConfig(DrawCallConfig);  // 从BatchesChart改为DrawCallChart

	// 创建图表切换器
	ChartSwitcher = SNew(SWidgetSwitcher)
		.WidgetIndex(0) // 默认显示第一个图表（FPS）
		+ SWidgetSwitcher::Slot()
		[
			FPSChart.ToSharedRef()
		]
		+ SWidgetSwitcher::Slot()
		[
			TrisChart.ToSharedRef()
		]
		+ SWidgetSwitcher::Slot()
		[
			DrawCallChart.ToSharedRef()  // 从BatchesChart改为DrawCallChart
		];

	ChildSlot
		[
			SNew(SScrollBox)
				+ SScrollBox::Slot()
				.Padding(5)
				[
					SNew(SVerticalBox)

						// 第一格：4个等宽水平框，每个包含精简的性能数据
						+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 0, 0, 10)
						[
							SNew(SHorizontalBox)

								// FPS数据
								+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												// 标题
												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("FPS")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												// 数值
												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(FPSValueLabel, STextBlock)
														.Text(FText::FromString(TEXT("42.0")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											// 说明文本
											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Frames per second")))
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]

							// Triangles数据 - 单位改为千(K)
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												// 标题
												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Triangles")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												// 数值 - 显示为千单位
												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(TrisCountLabel, STextBlock)
														.Text(FText::FromString(TEXT("4000K")))  // 从4.0M改为4000K
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											// 说明文本
											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Thousand triangles")))  // 从Million改为Thousand
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]

							// Draw Calls数据
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												// 标题
												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Draw Calls")))  // 从Batch改为Draw Calls
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												// 数值
												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(DrawCallLabel, STextBlock)  // 从TotalBatchLabel改为DrawCallLabel
														.Text(FText::FromString(TEXT("1273")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											// 说明文本
											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Draw calls count")))  // 从Draw call batches改为Draw calls count
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]

							// Shadow Pass数据 - 单位改为千(K)
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												// 标题
												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Shadow Pass")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												// 数值 - 显示为千单位
												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(ShadowTrisLabel, STextBlock)
														.Text(FText::FromString(TEXT("1800K")))  // 从1.8M改为1800K
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f)) // 红色，表示潜在性能问题
												]

											// 说明文本
											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Shadow triangles (K)")))  // 添加(K)单位
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]
						]

					// 第二格：图表切换控件（使用Button + Switcher）
					+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 10, 0, 10)
						[
							SNew(SHorizontalBox)

								+ SHorizontalBox::Slot()
								.AutoWidth()
								.Padding(5, 0, 10, 0)
								[
									SNew(STextBlock)
										.Text(FText::FromString(TEXT("Chart Type:")))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12))
								]

								+ SHorizontalBox::Slot()
								.AutoWidth()
								.Padding(10, 0, 10, 0)
								[
									SNew(SHorizontalBox)
										// FPS按钮
										+ SHorizontalBox::Slot()
										.AutoWidth()
										.Padding(5, 0, 5, 0)
										[
											SAssignNew(FPSChartButton, SButton)
												.Text(FText::FromString(TEXT("FPS")))
												.OnClicked_Lambda([this]() {
												SwitchToChart(EChartType::FPS);
												return FReply::Handled();
													})
												.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton"))
												.ContentPadding(FMargin(15, 8))
										]

									// Tris按钮
									+ SHorizontalBox::Slot()
										.AutoWidth()
										.Padding(5, 0, 5, 0)
										[
											SAssignNew(TrisChartButton, SButton)
												.Text(FText::FromString(TEXT("Tris")))
												.OnClicked_Lambda([this]() {
												SwitchToChart(EChartType::Tris);
												return FReply::Handled();
													})
												.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"))
												.ContentPadding(FMargin(15, 8))
										]

									// Draw Calls按钮
									+ SHorizontalBox::Slot()
										.AutoWidth()
										.Padding(5, 0, 5, 0)
										[
											SAssignNew(DrawCallChartButton, SButton)  // 从BatchesChartButton改为DrawCallChartButton
												.Text(FText::FromString(TEXT("Draw Calls")))  // 从Batches改为Draw Calls
												.OnClicked_Lambda([this]() {
												SwitchToChart(EChartType::DrawCalls);
												return FReply::Handled();
													})
												.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"))
												.ContentPadding(FMargin(15, 8))
										]
								]
						]

					// 第三格：折线图容器（使用Switcher）
					+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 0, 0, 15)
						[
							SNew(SBox)
								.HeightOverride(300)
								[
									ChartSwitcher.ToSharedRef()
								]
						]

					// 第四格：按钮区域
					+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 10, 0, 10)
						[
							SNew(SHorizontalBox)

								+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SAssignNew(SelfCheckButton, SButton)
										.Text(FText::FromString(TEXT("Self Check")))
										.HAlign(HAlign_Center)
										.VAlign(VAlign_Center)
										.OnClicked(this, &SOverviewTabPanel::OnRunSelfCheck)
										.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton"))
										.ContentPadding(FMargin(20, 10))
								]

							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SAssignNew(ClearWarningsButton, SButton)
										.Text(FText::FromString(TEXT("Clear Warnings")))
										.HAlign(HAlign_Center)
										.VAlign(VAlign_Center)
										.OnClicked(this, &SOverviewTabPanel::OnClearWarnings)
										.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"))
										.ContentPadding(FMargin(20, 10))
								]
						]
				]
		];

	// 初始刷新数据
	RefreshData();
}

void SOverviewTabPanel::SwitchToChart(EChartType ChartType)
{
	if (ChartType == SelectedChartType)
		return;

	// 更新按钮样式（将之前的选中按钮恢复为普通样式）
	switch (SelectedChartType)
	{
	case EChartType::FPS:
		FPSChartButton->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"));
		break;
	case EChartType::Tris:
		TrisChartButton->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"));
		break;
	case EChartType::DrawCalls:
		DrawCallChartButton->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"));
		break;
	}

	SelectedChartType = ChartType;

	// 设置新选中的按钮样式
	switch (ChartType)
	{
	case EChartType::FPS:
		FPSChartButton->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton"));
		ChartSwitcher->SetActiveWidgetIndex(0);
		break;
	case EChartType::Tris:
		TrisChartButton->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton"));
		ChartSwitcher->SetActiveWidgetIndex(1);
		break;
	case EChartType::DrawCalls:
		DrawCallChartButton->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton"));
		ChartSwitcher->SetActiveWidgetIndex(2);
		break;
	}
}

void SOverviewTabPanel::RefreshSlate()
{
	// 更新FPS数据
	FPSValueLabel->SetText(FText::FromString(FString::Printf(TEXT("%.1f"), CurrentFPS)));

	// 更新Triangles数据 - 以千为单位
	float TrisInK = CurrentTris / 1000.0f;
	TrisCountLabel->SetText(FText::FromString(FString::Printf(TEXT("%.0fK"), TrisInK)));

	// 更新Draw Calls数据
	DrawCallLabel->SetText(FText::FromString(FString::Printf(TEXT("%d"), CurrentDrawCalls)));

	// 更新Shadow Pass数据 - 以千为单位
	float ShadowTrisInK = CurrentShadowTris / 1000.0f;
	ShadowTrisLabel->SetText(FText::FromString(FString::Printf(TEXT("%.0fK"), ShadowTrisInK)));

	// 根据数值设置颜色（阈值警告）
	if (CurrentFPS < 30.0f)
	{
		FPSValueLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f)); // 红色警告
	}
	else if (CurrentFPS < 50.0f)
	{
		FPSValueLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.8f, 0.2f, 1.0f)); // 黄色警告
	}
	else
	{
		FPSValueLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f)); // 绿色正常
	}

	// Triangles警告阈值（超过5000K显示警告）- 调整为千单位
	if (CurrentTris > 5000000)  // 5000K
	{
		TrisCountLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f)); // 红色警告
	}
	else
	{
		TrisCountLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f)); // 绿色正常
	}

	// Draw Calls警告阈值（超过1500显示警告）
	if (CurrentDrawCalls > 1500)
	{
		DrawCallLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f)); // 红色警告
	}
	else
	{
		DrawCallLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f)); // 绿色正常
	}

	// Shadow Pass警告阈值 - 调整为千单位
	if (CurrentShadowTris > 2000000)  // 2000K
	{
		ShadowTrisLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f)); // 深红色，严重警告
	}
	else
	{
		ShadowTrisLabel->SetColorAndOpacity(FLinearColor(1.0f, 0.5f, 0.5f, 1.0f)); // 浅红色，一般警告
	}
}

void SOverviewTabPanel::OnFrameStatUpdate(FPerfData& InPerfData)
{
	CurrentFPS = InPerfData.FPS;
	CurrentTris = InPerfData.TrianglesNum;
	CurrentDrawCalls = InPerfData.DrawCalls;

	// 根据当前选中的图表类型添加数据点
	switch (SelectedChartType)
	{
	case EChartType::FPS:
		FPSChart->AddDataPoint(InPerfData.Time, CurrentFPS);
		break;
	case EChartType::Tris:
		TrisChart->AddDataPoint(InPerfData.Time, CurrentTris / 1000.0f); // 转换为千
		break;
	case EChartType::DrawCalls:
		DrawCallChart->AddDataPoint(InPerfData.Time, CurrentDrawCalls);
		break;
	}

	RefreshSlate();
}

FReply SOverviewTabPanel::OnRunSelfCheck()
{
	UE_LOG(LogTemp, Log, TEXT("Execute self check"));

	//// 模拟数据刷新
	////CurrentTris = 4000000 + FMath::RandRange(-500000, 500000);
	////CurrentDrawCalls = 1273 + FMath::RandRange(-100, 100);
	////CurrentShadowTris = 1800000 + FMath::RandRange(-300000, 300000);

	//// 添加新的数据点到所有图表
	//float NewTime = 0.0f;

	//// 获取时间（根据FPS图表的数据点数量）
	//TArray<FChartDataPoint> FPSPoints = FPSChart->GetDataPoints();
	//if (FPSPoints.Num() > 0)
	//{
	//	NewTime = FPSPoints.Last().X + 0.5f;
	//}
	//else
	//{
	//	NewTime = 0.5f;
	//}

	//FPSChart->AddDataPoint(NewTime, CurrentFPS);
	//TrisChart->AddDataPoint(NewTime, CurrentTris / 1000.0f); // 转换为千
	//DrawCallChart->AddDataPoint(NewTime, CurrentDrawCalls);

	//// 限制数据点数量，保持图表清晰
	//const int32 MaxDataPoints = 20;
	//auto TrimDataPoints = [MaxDataPoints](TSharedPtr<SLineChartWidget> Chart) {
	//	if (Chart.IsValid())
	//	{
	//		TArray<FChartDataPoint> CurrentPoints = Chart->GetDataPoints();
	//		if (CurrentPoints.Num() > MaxDataPoints)
	//		{
	//			// 只保留最后MaxDataPoints个点
	//			TArray<FChartDataPoint> NewPoints;
	//			int32 StartIndex = CurrentPoints.Num() - MaxDataPoints;
	//			for (int32 i = StartIndex; i < CurrentPoints.Num(); i++)
	//			{
	//				// 调整时间，使第一个点的时间为0
	//				float AdjustedTime = CurrentPoints[i].X - CurrentPoints[StartIndex].X;
	//				NewPoints.Add(FChartDataPoint(AdjustedTime, CurrentPoints[i].Y));
	//			}
	//			Chart->SetDataPoints(NewPoints);
	//		}
	//	}
	//	};

	//TrimDataPoints(FPSChart);
	//TrimDataPoints(TrisChart);
	//TrimDataPoints(DrawCallChart);

	//// 更新数据显示（包括颜色警告）
	//RefreshSlate();

	// 显示通知
	FNotificationInfo Info(FText::FromString(TEXT("Self check completed")));
	Info.ExpireDuration = 3.0f;
	FSlateNotificationManager::Get().AddNotification(Info);

	return FReply::Handled();
}

FReply SOverviewTabPanel::OnClearWarnings()
{
	UE_LOG(LogTemp, Log, TEXT("Clear warnings"));

	// 清空所有图表数据
	FPSChart->ClearData();
	TrisChart->ClearData();
	DrawCallChart->ClearData();

	// 重新添加初始点
	for (int32 i = 0; i < 5; i++)
	{
		float Time = i * 0.5f;
		FPSChart->AddDataPoint(Time, 42.0f);
		TrisChart->AddDataPoint(Time, 4000.0f); // 以千为单位
		DrawCallChart->AddDataPoint(Time, 1273.0f);
	}

	// 重置性能数据到默认值
	CurrentFPS = 42.0f;
	CurrentTris = 4000000;
	CurrentDrawCalls = 1273;
	CurrentShadowTris = 1800000;

	// 更新数据显示（包括颜色重置）
	RefreshSlate();  // 注意：这里应该是RefreshSlate而不是RefreshData

	// 显示通知
	FNotificationInfo Info(FText::FromString(TEXT("All warnings cleared and data reset")));
	Info.ExpireDuration = 3.0f;
	FSlateNotificationManager::Get().AddNotification(Info);

	return FReply::Handled();
}