#include "SeqPerformanceMonitor/AnimationTabPanel.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SSplitter.h"
#include "Styling/CoreStyle.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"
void SAnimationTabPanel::Construct(const FArguments& InArgs)
{
	// Initialize display count options
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("10")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("25")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("50")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("100")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("All")));

	// Use UE5.5 correct delegate binding
	auto OnTextChangedHandler = [this](const FText& Text)
		{
			CurrentFilterText = Text.ToString();
		};

	auto OnTextCommittedHandler = [this](const FText& Text, ETextCommit::Type CommitType)
		{
			CurrentFilterText = Text.ToString();
			ApplyFilterToActorList();
		};

	auto OnSelectionChangedHandler = [this](TSharedPtr<FString> NewValue, ESelectInfo::Type SelectType)
		{
			if (NewValue.IsValid())
			{
				if (*NewValue == TEXT("All"))
				{
					CurrentDisplayCount = -1;
				}
				else
				{
					CurrentDisplayCount = FCString::Atoi(**NewValue);
				}
				ApplyFilterToActorList();
			}
		};

	auto OnGenerateWidgetHandler = [](TSharedPtr<FString> Item) -> TSharedRef<SWidget>
		{
			return SNew(STextBlock)
				.Text(FText::FromString(*Item));
		};

	// Create the main vertical layout with 4 slots
	TSharedRef<SVerticalBox> MainVerticalBox = SNew(SVerticalBox)

		// First row: Stats display
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(0, 0, 0, 10)
		[
			SNew(SHorizontalBox)

				// Total Triangles
				+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				.Padding(5, 0, 5, 0)
				[
					SNew(SBorder)
						.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
						.Padding(15)
						[
							SNew(SVerticalBox)
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 10)
								[
									SNew(STextBlock)
										.Text(FText::FromString(TEXT("Total Triangles")))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
										.Justification(ETextJustify::Center)
								]
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 5)
								[
									SAssignNew(TotalTrianglesLabel, STextBlock)
										.Text(FText::FromString(TEXT("0")))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
										.Justification(ETextJustify::Center)
										.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
								]
							+ SVerticalBox::Slot()
								.AutoHeight()
								[
									SNew(STextBlock)
										.Text(FText::FromString(TEXT("Million triangles")))
										.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
										.Justification(ETextJustify::Center)
										.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
								]
						]
				]

			// SkeletalMesh Count
			+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				.Padding(5, 0, 5, 0)
				[
					SNew(SBorder)
						.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
						.Padding(15)
						[
							SNew(SVerticalBox)
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 10)
								[
									SNew(STextBlock)
										.Text(FText::FromString(TEXT("SkeletalMesh Count")))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
										.Justification(ETextJustify::Center)
								]
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 5)
								[
									SAssignNew(SkeletalMeshCountLabel, STextBlock)
										.Text(FText::FromString(TEXT("0")))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
										.Justification(ETextJustify::Center)
										.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
								]
							+ SVerticalBox::Slot()
								.AutoHeight()
								[
									SNew(STextBlock)
										.Text(FText::FromString(TEXT("Total SkeletalMeshes")))
										.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
										.Justification(ETextJustify::Center)
										.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
								]
						]
				]

			// Total Texture Size
			+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				.Padding(5, 0, 5, 0)
				[
					SNew(SBorder)
						.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
						.Padding(15)
						[
							SNew(SVerticalBox)
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 10)
								[
									SNew(STextBlock)
										.Text(FText::FromString(TEXT("Texture Size")))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
										.Justification(ETextJustify::Center)
								]
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 5)
								[
									SAssignNew(TotalTextureSizeLabel, STextBlock)
										.Text(FText::FromString(TEXT("0 MB")))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
										.Justification(ETextJustify::Center)
										.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
								]
							+ SVerticalBox::Slot()
								.AutoHeight()
								[
									SNew(STextBlock)
										.Text(FText::FromString(TEXT("Total texture memory")))
										.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
										.Justification(ETextJustify::Center)
										.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
								]
						]
				]

			// Cloth Actors
			+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				.Padding(5, 0, 5, 0)
				[
					SNew(SBorder)
						.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
						.Padding(15)
						[
							SNew(SVerticalBox)
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 10)
								[
									SNew(STextBlock)
										.Text(FText::FromString(TEXT("Cloth Actors")))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
										.Justification(ETextJustify::Center)
								]
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 5)
								[
									SAssignNew(ClothActorsLabel, STextBlock)
										.Text(FText::FromString(TEXT("0")))
										.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
										.Justification(ETextJustify::Center)
										.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
								]
							+ SVerticalBox::Slot()
								.AutoHeight()
								[
									SNew(STextBlock)
										.Text(FText::FromString(TEXT("Actors with cloth")))
										.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
										.Justification(ETextJustify::Center)
										.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
								]
						]
				]
		]

	// Second row: Quick actions
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(0, 0, 0, 10)
		[
			SNew(SVerticalBox)

				// First quick action row
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0, 0, 0, 5)
				[
					SNew(SBorder)
						.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
						.Padding(10)
						[
							SNew(SHorizontalBox)

								// OverDraw View Mode Toggle
								+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0)
								[
									SNew(SCheckBox)
										.Style(&FAppStyle::Get().GetWidgetStyle<FCheckBoxStyle>("ToggleButtonCheckBox"))
										.OnCheckStateChanged(FOnCheckStateChanged::CreateLambda([this](ECheckBoxState NewState)
											{
												OnToggleOverDrawViewMode();
											}))
										[
											SNew(STextBlock)
												.Text(FText::FromString(TEXT("OverDraw View")))
												.Justification(ETextJustify::Center)
										]
								]

							// Material Complexity Mode Toggle
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0)
								[
									SAssignNew(MaterialComplexityModeToggle, SCheckBox)
										.Style(&FAppStyle::Get().GetWidgetStyle<FCheckBoxStyle>("ToggleButtonCheckBox"))
										.OnCheckStateChanged(FOnCheckStateChanged::CreateLambda([this](ECheckBoxState NewState)
											{
												OnToggleMaterialComplexityMode();
											}))
										[
											SNew(STextBlock)
												.Text(FText::FromString(TEXT("Mat Complexity")))
												.Justification(ETextJustify::Center)
										]
								]

							// Effects LOD Toggle
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0)
								[
									SAssignNew(EffectsLODToggle, SCheckBox)
										.Style(&FAppStyle::Get().GetWidgetStyle<FCheckBoxStyle>("ToggleButtonCheckBox"))
										.OnCheckStateChanged(FOnCheckStateChanged::CreateLambda([this](ECheckBoxState NewState)
											{
												OnToggleEffectsLOD();
											}))
										[
											SNew(STextBlock)
												.Text(FText::FromString(TEXT("FX LOD")))
												.Justification(ETextJustify::Center)
										]
								]

							// Overlay Toggle
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0)
								[
									SAssignNew(OverlayToggle, SCheckBox)
										.Style(&FAppStyle::Get().GetWidgetStyle<FCheckBoxStyle>("ToggleButtonCheckBox"))
										.OnCheckStateChanged(FOnCheckStateChanged::CreateLambda([this](ECheckBoxState NewState)
											{
												OnToggleOverlay();
											}))
										[
											SNew(STextBlock)
												.Text(FText::FromString(TEXT("Overlay")))
												.Justification(ETextJustify::Center)
										]
								]
						]
				]

			// Second quick action row
			+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SBorder)
						.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
						.Padding(10)
						[
							SNew(SHorizontalBox)

								// Quick Check Button
								+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0)
								[
									SAssignNew(QuickCheckButton, SButton)
										.Text(FText::FromString(TEXT("Quick Check")))
										.OnClicked(this, &SAnimationTabPanel::OnRunQuickCheck)
										.HAlign(HAlign_Center)
										.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"))
										.ContentPadding(FMargin(20, 5))
								]

							// Material Complexity Toggle
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0)
								[
									SAssignNew(MaterialComplexityToggle, SCheckBox)
										.Style(&FAppStyle::Get().GetWidgetStyle<FCheckBoxStyle>("ToggleButtonCheckBox"))
										.OnCheckStateChanged(FOnCheckStateChanged::CreateLambda([this](ECheckBoxState NewState)
											{
												OnToggleMaterialComplexity();
											}))
										[
											SNew(STextBlock)
												.Text(FText::FromString(TEXT("Show Mat Complexity")))
												.Justification(ETextJustify::Center)
										]
								]

							// Primary Light Only Toggle
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0)
								[
									SAssignNew(PrimaryLightOnlyToggle, SCheckBox)
										.Style(&FAppStyle::Get().GetWidgetStyle<FCheckBoxStyle>("ToggleButtonCheckBox"))
										.OnCheckStateChanged(FOnCheckStateChanged::CreateLambda([this](ECheckBoxState NewState)
											{
												OnTogglePrimaryLightOnly();
											}))
										[
											SNew(STextBlock)
												.Text(FText::FromString(TEXT("Primary Light Only")))
												.Justification(ETextJustify::Center)
										]
								]
						]
				]
		]

	// Third row: Controls
	+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(0, 0, 0, 10)
		[
			SNew(SBorder)
				.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
				.Padding(10)
				[
					SNew(SHorizontalBox)

						// Refresh Button
						+ SHorizontalBox::Slot()
						.AutoWidth()
						.Padding(5, 0, 10, 0)
						[
							SAssignNew(RefreshActorListButton, SButton)
								.Text(FText::FromString(TEXT("Refresh List")))
								.OnClicked(this, &SAnimationTabPanel::OnRefreshActorList)
								.ToolTipText(FText::FromString(TEXT("Refresh skeletal mesh actor list")))
								.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"))
								.ContentPadding(FMargin(15, 5))
						]

					// Filter Text Box
					+ SHorizontalBox::Slot()
						.FillWidth(1.0f)
						.Padding(5, 0)
						[
							SAssignNew(FilterTextBox, SEditableTextBox)
								.HintText(FText::FromString(TEXT("Filter by actor name...")))
								// UE5.5 use correct delegate binding
								.OnTextChanged_Lambda(OnTextChangedHandler)
								.OnTextCommitted_Lambda(OnTextCommittedHandler)
						]

					// Display Count Combo Box
					+ SHorizontalBox::Slot()
						.AutoWidth()
						.Padding(10, 0, 5, 0)
						[
							SNew(SBox)
								.WidthOverride(80)
								[
									SAssignNew(DisplayCountComboBox, SComboBox<TSharedPtr<FString>>)
										.OptionsSource(&DisplayCountOptions)
										.InitiallySelectedItem(DisplayCountOptions[2]) // Default to 50
										// UE5.5 use Lambda direct binding
										.OnGenerateWidget_Lambda(OnGenerateWidgetHandler)
										.OnSelectionChanged_Lambda(OnSelectionChangedHandler)
										[
											SNew(STextBlock)
												.Text(FText::FromString(TEXT("50")))
										]
								]
						]
				]
		]

	// Fourth row: Actor list table
	+ SVerticalBox::Slot()
		.FillHeight(1.0f)
		[
			SNew(SBorder)
				.BorderImage(FAppStyle::GetBrush("ToolPanel.DarkGroupBorder"))
				[
					SNew(SVerticalBox)

						// Table header
						+ SVerticalBox::Slot()
						.AutoHeight()
						[
							SNew(SBorder)
								.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
								.Padding(5)
								[
									SNew(SHorizontalBox)

										// Actor Name header
										+ SHorizontalBox::Slot()
										.FillWidth(0.3f)
										[
											SNew(SButton)
												.ButtonStyle(FAppStyle::Get(), "FlatButton")
												.OnClicked_Lambda([this]()
													{
														OnSortByActorName();
														return FReply::Handled();
													})
												[
													SNew(SHorizontalBox)
														+ SHorizontalBox::Slot()
														.AutoWidth()
														[
															SNew(STextBlock)
																.Text(FText::FromString(TEXT("Actor Name")))
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
														]
														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														.HAlign(HAlign_Right)
														.Padding(5, 0, 0, 0)
														[
															SNew(STextBlock)
																.Text_Lambda([this]() -> FText
																	{
																		return FText::FromString(bShowActorNameSortArrow ?
																			(bSortAscending ? TEXT("↑") : TEXT("↓")) : TEXT(""));
																	})
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
																.ColorAndOpacity(FLinearColor::Yellow)
														]
												]
										]

									// Poly Count header
									+ SHorizontalBox::Slot()
										.FillWidth(0.2f)
										.Padding(5, 0)
										[
											SNew(SButton)
												.ButtonStyle(FAppStyle::Get(), "FlatButton")
												.OnClicked_Lambda([this]()
													{
														OnSortByPolyCount();
														return FReply::Handled();
													})
												[
													SNew(SHorizontalBox)
														+ SHorizontalBox::Slot()
														.AutoWidth()
														[
															SNew(STextBlock)
																.Text(FText::FromString(TEXT("Polygons")))
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
														]
														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														.HAlign(HAlign_Right)
														.Padding(5, 0, 0, 0)
														[
															SNew(STextBlock)
																.Text_Lambda([this]() -> FText
																	{
																		return FText::FromString(bShowPolyCountSortArrow ?
																			(bSortAscending ? TEXT("↑") : TEXT("↓")) : TEXT(""));
																	})
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
																.ColorAndOpacity(FLinearColor::Yellow)
														]
												]
										]

									// Bone Count header
									+ SHorizontalBox::Slot()
										.FillWidth(0.2f)
										.Padding(5, 0)
										[
											SNew(SButton)
												.ButtonStyle(FAppStyle::Get(), "FlatButton")
												.OnClicked_Lambda([this]()
													{
														OnSortByBoneCount();
														return FReply::Handled();
													})
												[
													SNew(SHorizontalBox)
														+ SHorizontalBox::Slot()
														.AutoWidth()
														[
															SNew(STextBlock)
																.Text(FText::FromString(TEXT("Bones")))
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
														]
														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														.HAlign(HAlign_Right)
														.Padding(5, 0, 0, 0)
														[
															SNew(STextBlock)
																.Text_Lambda([this]() -> FText
																	{
																		return FText::FromString(bShowBoneCountSortArrow ?
																			(bSortAscending ? TEXT("↑") : TEXT("↓")) : TEXT(""));
																	})
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
																.ColorAndOpacity(FLinearColor::Yellow)
														]
												]
										]

									// Texture Size header
									+ SHorizontalBox::Slot()
										.FillWidth(0.2f)
										.Padding(5, 0)
										[
											SNew(SButton)
												.ButtonStyle(FAppStyle::Get(), "FlatButton")
												.OnClicked_Lambda([this]()
													{
														OnSortByTextureSize();
														return FReply::Handled();
													})
												[
													SNew(SHorizontalBox)
														+ SHorizontalBox::Slot()
														.AutoWidth()
														[
															SNew(STextBlock)
																.Text(FText::FromString(TEXT("Texture Size")))
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
														]
														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														.HAlign(HAlign_Right)
														.Padding(5, 0, 0, 0)
														[
															SNew(STextBlock)
																.Text_Lambda([this]() -> FText
																	{
																		return FText::FromString(bShowTextureSizeSortArrow ?
																			(bSortAscending ? TEXT("↑") : TEXT("↓")) : TEXT(""));
																	})
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
																.ColorAndOpacity(FLinearColor::Yellow)
														]
												]
										]

									// Cloth Enabled header
									+ SHorizontalBox::Slot()
										.FillWidth(0.1f)
										.Padding(5, 0)
										[
											SNew(SButton)
												.ButtonStyle(FAppStyle::Get(), "FlatButton")
												.OnClicked_Lambda([this]()
													{
														OnSortByClothEnabled();
														return FReply::Handled();
													})
												[
													SNew(SHorizontalBox)
														+ SHorizontalBox::Slot()
														.AutoWidth()
														[
															SNew(STextBlock)
																.Text(FText::FromString(TEXT("Cloth")))
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
														]
														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														.HAlign(HAlign_Right)
														.Padding(5, 0, 0, 0)
														[
															SNew(STextBlock)
																.Text_Lambda([this]() -> FText
																	{
																		return FText::FromString(bShowClothEnabledSortArrow ?
																			(bSortAscending ? TEXT("↑") : TEXT("↓")) : TEXT(""));
																	})
																.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
																.ColorAndOpacity(FLinearColor::Yellow)
														]
												]
										]
								]
						]

					// List view
					+ SVerticalBox::Slot()
						.FillHeight(1.0f)
						[
							SAssignNew(ActorListView, SListView<TSharedPtr<FActorListItem>>)
								.ListItemsSource(&FilteredActorListItems)
								.OnGenerateRow_Lambda([this](TSharedPtr<FActorListItem> Item, const TSharedRef<STableViewBase>& OwnerTable) -> TSharedRef<ITableRow>
									{
										return SNew(STableRow<TSharedPtr<FActorListItem>>, OwnerTable)
											[
												SNew(SHorizontalBox)

													// Actor Name
													+ SHorizontalBox::Slot()
													.FillWidth(0.3f)
													.Padding(10, 2)
													[
														SNew(STextBlock)
															.Text(FText::FromString(Item->ActorName))
															.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
													]

													// Poly Count
													+ SHorizontalBox::Slot()
													.FillWidth(0.2f)
													.Padding(10, 2)
													[
														SNew(STextBlock)
															.Text(FText::FromString(FString::Printf(TEXT("%d"), Item->PolyCount)))
															.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
															.Justification(ETextJustify::Right)
															.ColorAndOpacity(Item->PolyCount > 100000 ? FLinearColor::Yellow :
																(Item->PolyCount > 50000 ? FLinearColor(1.0f, 0.5f, 0.0f) : FLinearColor::White))
													]

												// Bone Count
												+ SHorizontalBox::Slot()
													.FillWidth(0.2f)
													.Padding(10, 2)
													[
														SNew(STextBlock)
															.Text(FText::FromString(FString::Printf(TEXT("%d"), Item->BoneCount)))
															.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
															.Justification(ETextJustify::Right)
															.ColorAndOpacity(Item->BoneCount > 100 ? FLinearColor::Yellow :
																(Item->BoneCount > 50 ? FLinearColor(1.0f, 0.5f, 0.0f) : FLinearColor::White))
													]

												// Texture Size
												+ SHorizontalBox::Slot()
													.FillWidth(0.2f)
													.Padding(10, 2)
													[
														SNew(STextBlock)
															.Text(FText::FromString(Item->TextureSizeText))
															.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
															.Justification(ETextJustify::Right)
															.ColorAndOpacity(Item->TextureSizeMB > 50.0f ? FLinearColor::Yellow :
																(Item->TextureSizeMB > 20.0f ? FLinearColor(1.0f, 0.5f, 0.0f) : FLinearColor::White))
													]

												// Cloth Enabled
												+ SHorizontalBox::Slot()
													.FillWidth(0.1f)
													.Padding(10, 2)
													[
														SNew(STextBlock)
															.Text(FText::FromString(Item->bClothEnabled ? TEXT("Yes") : TEXT("No")))
															.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
															.Justification(ETextJustify::Center)
															.ColorAndOpacity(Item->bClothEnabled ? FLinearColor::Green : FLinearColor(0.7f, 0.7f, 0.7f))
													]
											];
									})
						]
				]
		];

	ChildSlot
		[
			MainVerticalBox
		];

	// Initial data refresh
	UpdateActorList();
}

void SAnimationTabPanel::RefreshData()
{
	// Update stats with sample data
	int32 TotalTriangles = 0;
	int32 TotalSkeletalMeshes = 0;
	float TotalTextureSize = 0.0f;
	int32 ClothEnabledCount = 0;

	for (const auto& Item : ActorListItems)
	{
		TotalTriangles += Item->PolyCount;
		TotalSkeletalMeshes++;
		TotalTextureSize += Item->TextureSizeMB;
		if (Item->bClothEnabled)
		{
			ClothEnabledCount++;
		}
	}

	// Format values
	FString TrianglesText;
	if (TotalTriangles >= 1000000)
	{
		TrianglesText = FString::Printf(TEXT("%.1fM"), TotalTriangles / 1000000.0f);
	}
	else if (TotalTriangles >= 1000)
	{
		TrianglesText = FString::Printf(TEXT("%.1fK"), TotalTriangles / 1000.0f);
	}
	else
	{
		TrianglesText = FString::Printf(TEXT("%d"), TotalTriangles);
	}

	// Update labels
	TotalTrianglesLabel->SetText(FText::FromString(TrianglesText));
	SkeletalMeshCountLabel->SetText(FText::FromString(FString::Printf(TEXT("%d"), TotalSkeletalMeshes)));
	TotalTextureSizeLabel->SetText(FText::FromString(FString::Printf(TEXT("%.1f MB"), TotalTextureSize)));
	ClothActorsLabel->SetText(FText::FromString(FString::Printf(TEXT("%d"), ClothEnabledCount)));

	// Set warning colors based on thresholds
	if (TotalTriangles > 5000000)
	{
		TotalTrianglesLabel->SetColorAndOpacity(FLinearColor::Red);
	}
	else if (TotalTriangles > 2000000)
	{
		TotalTrianglesLabel->SetColorAndOpacity(FLinearColor::Yellow);
	}
	else
	{
		TotalTrianglesLabel->SetColorAndOpacity(FLinearColor::Green);
	}

	if (TotalSkeletalMeshes > 100)
	{
		SkeletalMeshCountLabel->SetColorAndOpacity(FLinearColor::Red);
	}
	else if (TotalSkeletalMeshes > 50)
	{
		SkeletalMeshCountLabel->SetColorAndOpacity(FLinearColor::Yellow);
	}
	else
	{
		SkeletalMeshCountLabel->SetColorAndOpacity(FLinearColor::Green);
	}

	if (TotalTextureSize > 500.0f)
	{
		TotalTextureSizeLabel->SetColorAndOpacity(FLinearColor::Red);
	}
	else if (TotalTextureSize > 200.0f)
	{
		TotalTextureSizeLabel->SetColorAndOpacity(FLinearColor::Yellow);
	}
	else
	{
		TotalTextureSizeLabel->SetColorAndOpacity(FLinearColor::Green);
	}
}

// Callback implementations
FReply SAnimationTabPanel::OnToggleOverDrawViewMode()
{
	UE_LOG(LogTemp, Log, TEXT("Toggling OverDraw View Mode"));
	// TODO: Implement OverDraw view mode toggle
	return FReply::Handled();
}

FReply SAnimationTabPanel::OnToggleMaterialComplexityMode()
{
	UE_LOG(LogTemp, Log, TEXT("Toggling Material Complexity Mode"));
	// TODO: Implement Material Complexity mode toggle
	return FReply::Handled();
}

FReply SAnimationTabPanel::OnToggleEffectsLOD()
{
	UE_LOG(LogTemp, Log, TEXT("Toggling Effects LOD"));
	// TODO: Implement Effects LOD toggle
	return FReply::Handled();
}

FReply SAnimationTabPanel::OnToggleOverlay()
{
	UE_LOG(LogTemp, Log, TEXT("Toggling Overlay"));
	// TODO: Implement Overlay toggle
	return FReply::Handled();
}

FReply SAnimationTabPanel::OnRunQuickCheck()
{
	UE_LOG(LogTemp, Log, TEXT("Running Quick Check"));

	// Refresh the data
	UpdateActorList();
	RefreshData();

	// Show notification
	FNotificationInfo Info(FText::FromString(TEXT("Quick check completed")));
	Info.ExpireDuration = 3.0f;
	FSlateNotificationManager::Get().AddNotification(Info);

	return FReply::Handled();
}

FReply SAnimationTabPanel::OnToggleMaterialComplexity()
{
	UE_LOG(LogTemp, Log, TEXT("Toggling Material Complexity Display"));
	// TODO: Implement material complexity toggle
	return FReply::Handled();
}

FReply SAnimationTabPanel::OnTogglePrimaryLightOnly()
{
	UE_LOG(LogTemp, Log, TEXT("Toggling Primary Light Only"));
	// TODO: Implement primary light only toggle
	return FReply::Handled();
}

FReply SAnimationTabPanel::OnRefreshActorList()
{
	UpdateActorList();

	// Show notification
	FNotificationInfo Info(FText::FromString(TEXT("Actor list refreshed")));
	Info.ExpireDuration = 2.0f;
	FSlateNotificationManager::Get().AddNotification(Info);

	return FReply::Handled();
}

// Sorting callbacks - Fixed: Update sort arrow visibility
void SAnimationTabPanel::OnSortByActorName()
{
	if (CurrentSortColumn == ESortColumn::ActorName)
	{
		bSortAscending = !bSortAscending;
	}
	else
	{
		CurrentSortColumn = ESortColumn::ActorName;
		bSortAscending = true;
	}

	// Update sort arrow visibility
	bShowActorNameSortArrow = true;
	bShowPolyCountSortArrow = false;
	bShowBoneCountSortArrow = false;
	bShowTextureSizeSortArrow = false;
	bShowClothEnabledSortArrow = false;

	// Sort and refresh list
	ApplyFilterToActorList();
}

void SAnimationTabPanel::OnSortByPolyCount()
{
	if (CurrentSortColumn == ESortColumn::PolyCount)
	{
		bSortAscending = !bSortAscending;
	}
	else
	{
		CurrentSortColumn = ESortColumn::PolyCount;
		bSortAscending = true;
	}

	// Update sort arrow visibility
	bShowActorNameSortArrow = false;
	bShowPolyCountSortArrow = true;
	bShowBoneCountSortArrow = false;
	bShowTextureSizeSortArrow = false;
	bShowClothEnabledSortArrow = false;

	ApplyFilterToActorList();
}

void SAnimationTabPanel::OnSortByBoneCount()
{
	if (CurrentSortColumn == ESortColumn::BoneCount)
	{
		bSortAscending = !bSortAscending;
	}
	else
	{
		CurrentSortColumn = ESortColumn::BoneCount;
		bSortAscending = true;
	}

	// Update sort arrow visibility
	bShowActorNameSortArrow = false;
	bShowPolyCountSortArrow = false;
	bShowBoneCountSortArrow = true;
	bShowTextureSizeSortArrow = false;
	bShowClothEnabledSortArrow = false;

	ApplyFilterToActorList();
}

void SAnimationTabPanel::OnSortByTextureSize()
{
	if (CurrentSortColumn == ESortColumn::TextureSize)
	{
		bSortAscending = !bSortAscending;
	}
	else
	{
		CurrentSortColumn = ESortColumn::TextureSize;
		bSortAscending = true;
	}

	// Update sort arrow visibility
	bShowActorNameSortArrow = false;
	bShowPolyCountSortArrow = false;
	bShowBoneCountSortArrow = false;
	bShowTextureSizeSortArrow = true;
	bShowClothEnabledSortArrow = false;

	ApplyFilterToActorList();
}

void SAnimationTabPanel::OnSortByClothEnabled()
{
	if (CurrentSortColumn == ESortColumn::ClothEnabled)
	{
		bSortAscending = !bSortAscending;
	}
	else
	{
		CurrentSortColumn = ESortColumn::ClothEnabled;
		bSortAscending = true;
	}

	// Update sort arrow visibility
	bShowActorNameSortArrow = false;
	bShowPolyCountSortArrow = false;
	bShowBoneCountSortArrow = false;
	bShowTextureSizeSortArrow = false;
	bShowClothEnabledSortArrow = true;

	ApplyFilterToActorList();
}

// Utility functions
void SAnimationTabPanel::UpdateActorList()
{
	// Clear existing items
	ActorListItems.Empty();

	// Add 10 reference test cases
	// 1. High poly character with many bones and cloth
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("MainCharacter_BP");
		Item->PolyCount = 185000;
		Item->BoneCount = 216;
		Item->TextureSizeMB = 256.5f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = true;
		ActorListItems.Add(Item);
	}

	// 2. Enemy character with moderate complexity
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("Enemy_Goblin_01");
		Item->PolyCount = 75000;
		Item->BoneCount = 98;
		Item->TextureSizeMB = 128.2f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = false;
		ActorListItems.Add(Item);
	}

	// 3. NPC with simple animation
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("NPC_Villager_Female");
		Item->PolyCount = 45000;
		Item->BoneCount = 72;
		Item->TextureSizeMB = 85.3f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = true;
		ActorListItems.Add(Item);
	}

	// 4. Animal with cloth simulation
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("Creature_Wolf_Alpha");
		Item->PolyCount = 68000;
		Item->BoneCount = 54;
		Item->TextureSizeMB = 92.7f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = true;
		ActorListItems.Add(Item);
	}

	// 5. Boss character - high complexity
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("Boss_Dragon_Final");
		Item->PolyCount = 350000;
		Item->BoneCount = 312;
		Item->TextureSizeMB = 512.8f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = false;
		ActorListItems.Add(Item);
	}

	// 6. Simple prop with animation
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("Prop_Windmill");
		Item->PolyCount = 15000;
		Item->BoneCount = 12;
		Item->TextureSizeMB = 45.6f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = false;
		ActorListItems.Add(Item);
	}

	// 7. Vehicle with complex rig
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("Vehicle_Tank_Main");
		Item->PolyCount = 120000;
		Item->BoneCount = 45;
		Item->TextureSizeMB = 186.4f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = false;
		ActorListItems.Add(Item);
	}

	// 8. Crowd character (optimized)
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("Crowd_Citizen_04");
		Item->PolyCount = 18000;
		Item->BoneCount = 36;
		Item->TextureSizeMB = 32.1f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = false;
		ActorListItems.Add(Item);
	}

	// 9. Player weapon with cloth
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("Weapon_Royal_Banner");
		Item->PolyCount = 9500;
		Item->BoneCount = 8;
		Item->TextureSizeMB = 28.9f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = true;
		ActorListItems.Add(Item);
	}

	// 10. Environmental animated object
	{
		TSharedPtr<FActorListItem> Item = MakeShared<FActorListItem>();
		Item->ActorName = TEXT("Env_Tent_Animated");
		Item->PolyCount = 32000;
		Item->BoneCount = 24;
		Item->TextureSizeMB = 76.3f;
		Item->TextureSizeText = FString::Printf(TEXT("%.1f MB"), Item->TextureSizeMB);
		Item->bClothEnabled = true;
		ActorListItems.Add(Item);
	}

	// Apply filter and sorting
	ApplyFilterToActorList();

	// Refresh statistics
	RefreshData();
}

void SAnimationTabPanel::ApplyFilterToActorList()
{
	// Clear filtered list
	FilteredActorListItems.Empty();

	// Apply filter
	for (const auto& Item : ActorListItems)
	{
		if (CurrentFilterText.IsEmpty() ||
			Item->ActorName.Contains(CurrentFilterText, ESearchCase::IgnoreCase))
		{
			FilteredActorListItems.Add(Item);
		}
	}

	// Apply sorting
	switch (CurrentSortColumn)
	{
	case ESortColumn::ActorName:
		FilteredActorListItems.Sort([this](const TSharedPtr<FActorListItem>& A, const TSharedPtr<FActorListItem>& B)
			{
				return bSortAscending ?
					A->ActorName.Compare(B->ActorName, ESearchCase::IgnoreCase) < 0 :
					B->ActorName.Compare(A->ActorName, ESearchCase::IgnoreCase) < 0;
			});
		break;

	case ESortColumn::PolyCount:
		FilteredActorListItems.Sort([this](const TSharedPtr<FActorListItem>& A, const TSharedPtr<FActorListItem>& B)
			{
				return bSortAscending ?
					A->PolyCount < B->PolyCount :
					B->PolyCount < A->PolyCount;
			});
		break;

	case ESortColumn::BoneCount:
		FilteredActorListItems.Sort([this](const TSharedPtr<FActorListItem>& A, const TSharedPtr<FActorListItem>& B)
			{
				return bSortAscending ?
					A->BoneCount < B->BoneCount :
					B->BoneCount < A->BoneCount;
			});
		break;

	case ESortColumn::TextureSize:
		FilteredActorListItems.Sort([this](const TSharedPtr<FActorListItem>& A, const TSharedPtr<FActorListItem>& B)
			{
				return bSortAscending ?
					A->TextureSizeMB < B->TextureSizeMB :
					B->TextureSizeMB < A->TextureSizeMB;
			});
		break;

	case ESortColumn::ClothEnabled:
		FilteredActorListItems.Sort([this](const TSharedPtr<FActorListItem>& A, const TSharedPtr<FActorListItem>& B)
			{
				if (A->bClothEnabled == B->bClothEnabled)
				{
					return bSortAscending ?
						A->ActorName.Compare(B->ActorName, ESearchCase::IgnoreCase) < 0 :
						B->ActorName.Compare(A->ActorName, ESearchCase::IgnoreCase) < 0;
				}
				return bSortAscending ?
					(A->bClothEnabled < B->bClothEnabled) :
					(B->bClothEnabled < A->bClothEnabled);
			});
		break;
	}

	// Apply display count limit
	if (CurrentDisplayCount > 0 && FilteredActorListItems.Num() > CurrentDisplayCount)
	{
		FilteredActorListItems.SetNum(CurrentDisplayCount);
	}

	// Refresh the list view
	if (ActorListView.IsValid())
	{
		ActorListView->RequestListRefresh();
	}
}