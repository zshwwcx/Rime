#include "SeqPerformanceMonitor/PerformanceMonitor.h"
#include "SeqPerformanceMonitor/OverviewTabPanel.h"
#include "SeqPerformanceMonitor/LightingTabPanel.h"
#include "SeqPerformanceMonitor/EffectsTabPanel.h"
#include "SeqPerformanceMonitor/AnimationTabPanel.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SSplitter.h"
#include "Styling/CoreStyle.h"
#include "Engine/Console.h"

#include "SeqPerformanceMonitor/PMSubSystem.h"

#define LOCTEXT_NAMESPACE "SeqPerformanceMonitor"



// 主面板实现
void SPerformanceMonitorPanel::Construct(const FArguments& InArgs)
{
	// 创建各个标签页
	TabPanels.Add(SNew(SOverviewTabPanel));
	TabPanels.Add(SNew(SLightingTabPanel));
	TabPanels.Add(SNew(SEffectsTabPanel));
	TabPanels.Add(SNew(SAnimationTabPanel));

	// 默认激活总览标签页
	ActiveTabIndex = 0;

	ChildSlot
		[
			SNew(SVerticalBox)

				// 标签栏
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0, 0, 0, 2)
				[
					SNew(SBorder)
						.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
						.Padding(0)
						[
							SNew(SHorizontalBox)

								// 总览标签按钮
								+ SHorizontalBox::Slot()
								.AutoWidth()
								[
									CreateTabButton("Summary", 0)
								]

								// 灯光标签按钮
								+ SHorizontalBox::Slot()
								.AutoWidth()
								[
									CreateTabButton("Light", 1)
								]

								// 特效标签按钮
								+ SHorizontalBox::Slot()
								.AutoWidth()
								[
									CreateTabButton("Effect", 2)
								]

								// 动作标签按钮
								+ SHorizontalBox::Slot()
								.AutoWidth()
								[
									CreateTabButton("SkeletalMesh", 3)
								]

								//// 渲染标签按钮
								//+ SHorizontalBox::Slot()
								//.AutoWidth()
								//[
								//	CreateTabButton("渲染", 4)
								//]
						]
				]

			// 内容区域 - 使用WidgetSwitcher
			+ SVerticalBox::Slot()
				.FillHeight(1.0f)
				[
					SAssignNew(TabSwitcher, SWidgetSwitcher)

						// 添加各个标签页到切换器
						+ SWidgetSwitcher::Slot()
						[
							TabPanels[0].ToSharedRef()
						]
						+ SWidgetSwitcher::Slot()
						[
							TabPanels[1].ToSharedRef()
						]
						+ SWidgetSwitcher::Slot()
						[
							TabPanels[2].ToSharedRef()
						]
						+ SWidgetSwitcher::Slot()
						[
							TabPanels[3].ToSharedRef()
						]
						//+ SWidgetSwitcher::Slot()
						//[
						//	TabPanels[4].ToSharedRef()
						//]
				]
		];

	// 设置初始激活的标签页
	SwitchTab(0);
	//TabSwitcher->SetActiveWidgetIndex(ActiveTabIndex);
}

TSharedRef<SWidget> SPerformanceMonitorPanel::CreateTabButton(const FString& TabName, int32 TabIndex)
{
	TSharedPtr<SButton> TabButton;

	TSharedRef<SButton> ButtonWidget = SNew(SButton)
		.Text(FText::FromString(TabName))
		.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("FlatButton"))
		.OnClicked_Lambda([this, TabIndex]() {
		SwitchTab(TabIndex);
		return FReply::Handled();
			})
		//.BorderBackgroundColor_Lambda([this, TabIndex]() {
		//return ActiveTabIndex == TabIndex ?
		//	FLinearColor(0.1f, 0.4f, 0.8f, 0.5f) :
		//	FLinearColor::Transparent;
		//	})
		.ContentPadding(FMargin(10, 5))
		[
			SNew(STextBlock)
				.Text(FText::FromString(TabName))
				.ColorAndOpacity_Lambda([this, TabIndex]() {
				return ActiveTabIndex == TabIndex ?
					FLinearColor::White :
					FLinearColor(0.7f, 0.7f, 0.7f);
					})
		];

	// 保存按钮引用用于高亮
	TabButtons.Add(ButtonWidget);

	return ButtonWidget;
}

void SPerformanceMonitorPanel::SwitchTab(int32 TabIndex)
{
	if (ActiveTabIndex >= 0 && ActiveTabIndex < TabButtons.Num() && TabButtons[ActiveTabIndex].IsValid())
	{
		TabButtons[ActiveTabIndex]->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("FlatButton"));
	}

	if (TabIndex >= 0 && TabIndex < TabButtons.Num() && TabButtons[TabIndex].IsValid())
	{
		TabButtons[TabIndex]->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton"));
	}

	if (TabIndex >= 0 && TabIndex < TabPanels.Num() && TabIndex != ActiveTabIndex)
	{
		ActiveTabIndex = TabIndex;
		TabSwitcher->SetActiveWidgetIndex(ActiveTabIndex);

		// 刷新新标签页的数据
		if (TabPanels[ActiveTabIndex].IsValid())
		{
			TabPanels[ActiveTabIndex]->RefreshData();
		}
	}
}

void SPerformanceMonitorPanel::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	//Super::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);

	static int LastFrameIndex = -1;
	if (LastFrameIndex != PerfData.FrameIndex)
	{
		RefreshAllData();
		LastFrameIndex = PerfData.FrameIndex;
	}
	
}

void SPerformanceMonitorPanel::RefreshAllData()
{
	if (TabPanels[ActiveTabIndex].IsValid())
	{
		TabPanels[ActiveTabIndex]->OnFrameStatUpdate(PerfData);
	}
}

void SPerformanceMonitorPanel::OnActivated()
{
	PerfData.Enable();

	//TArray<FString> Commands;
	//Commands.Add(TEXT("stat fps"));
	////Commands.Add(TEXT("stat Engine"));
	//if (GEditor && GEditor->GameViewport)
	//{
	//	if (UConsole* ViewportConsole = GEditor->GameViewport->ViewportConsole)
	//	{
	//		for (auto Command : Commands)
	//		{
	//			ViewportConsole->ConsoleCommand(Command);
	//		}
	//	}
	//}
}

void SPerformanceMonitorPanel::OnClosed()
{
	PerfData.Disable();
}

// 替代方案：使用SScrollBox + 自定义样式的标签栏
TSharedRef<SWidget> CreateCustomTabBar()
{
	return SNew(SBox)
		.HeightOverride(30)
		[
			SNew(SBorder)
				.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
				[
					SNew(SScrollBox)
						.Orientation(Orient_Horizontal)
						+ SScrollBox::Slot()
						[
							SNew(SHorizontalBox)
								// 这里添加各个标签按钮...
						]
				]
		];
}

#undef LOCTEXT_NAMESPACE