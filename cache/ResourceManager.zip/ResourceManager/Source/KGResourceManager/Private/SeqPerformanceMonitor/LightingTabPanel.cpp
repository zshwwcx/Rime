#include "SeqPerformanceMonitor/LightingTabPanel.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SSplitter.h"
#include "Styling/CoreStyle.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"

#include "LevelEditor.h"
#include "SLevelViewport.h"

#include "Kismet/GameplayStatics.h"
#include "Engine/Light.h"
#include "Components/LightComponent.h"

void SLightingTabPanel::Construct(const FArguments& InArgs)
{
	// 初始化字体
	RegularFont = FCoreStyle::GetDefaultFontStyle("Regular", 10);
	BoldFont = FCoreStyle::GetDefaultFontStyle("Bold", 12);
	SmallFont = FCoreStyle::GetDefaultFontStyle("Regular", 9);


	// 初始化质量选项
	LightQualityOptions.Add(MakeShared<FString>(TEXT("Low")));
	LightQualityOptions.Add(MakeShared<FString>(TEXT("Medium")));
	LightQualityOptions.Add(MakeShared<FString>(TEXT("High")));
	LightQualityOptions.Add(MakeShared<FString>(TEXT("Ultra")));

	// 初始化显示数量选项
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("10")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("25")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("50")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("100")));
	DisplayCountOptions.Add(MakeShared<FString>(TEXT("All")));

	ChildSlot
		[
			SNew(SScrollBox)
				+ SScrollBox::Slot()
				.Padding(5)
				[
					SNew(SVerticalBox)

						// 第一格：4个性能数据面板
						+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 0, 0, 10)
						[
							SNew(SHorizontalBox)

								// 同屏动态灯光数
								+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Dynamic Lights")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(DynamicLightCountLabel, STextBlock)
														.Text(FText::FromString(TEXT("3")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Active dynamic lights")))
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]

							// 灯光加权面积
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Weighted Area")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(LightWeightedAreaLabel, STextBlock)
														.Text(FText::FromString(TEXT("85%")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Light coverage area")))
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]

							// 开启阴影的灯光数
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Shadow Lights")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(ShadowLightCountLabel, STextBlock)
														.Text(FText::FromString(TEXT("5")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Lights casting shadows")))
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]

							// Sequence创建灯光数
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(15)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Sequence Lights")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
														.Justification(ETextJustify::Center)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SAssignNew(SequenceLightCountLabel, STextBlock)
														.Text(FText::FromString(TEXT("3")))
														.Font(FCoreStyle::GetDefaultFontStyle("Bold", 24))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.9f, 0.9f, 0.9f, 1.0f))
												]

											+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Lights from sequences")))
														.Font(FCoreStyle::GetDefaultFontStyle("Regular", 10))
														.Justification(ETextJustify::Center)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]
								]
						]

					// 第二格：快捷功能
					+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 10, 0, 10)
						[
							SNew(SVerticalBox)

								// 第一子格：视图模式选择
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 0, 0, 10)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(10)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 10)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("View Mode")))
														.Font(BoldFont)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SNew(SHorizontalBox)

														// Normal View按钮
														+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														.Padding(2, 0, 2, 0)
														[
															SAssignNew(NormalViewButton, SButton)
																.Text(FText::FromString(TEXT("Normal")))
																.HAlign(HAlign_Center)
																.VAlign(VAlign_Center)
																.OnClicked(this, &SLightingTabPanel::OnNormalViewClicked)
																.ContentPadding(FMargin(10, 5))
																.ToolTipText(FText::FromString(TEXT("Switch to Normal view mode")))
														]

													// Light Complexity按钮
													+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														.Padding(2, 0, 2, 0)
														[
															SAssignNew(LightComplexityButton, SButton)
																.Text(FText::FromString(TEXT("Light Complexity")))
																.HAlign(HAlign_Center)
																.VAlign(VAlign_Center)
																.OnClicked(this, &SLightingTabPanel::OnLightComplexityClicked)
																.ContentPadding(FMargin(10, 5))
																.ToolTipText(FText::FromString(TEXT("Switch to Light Complexity view mode")))
														]

													// Shadow Complexity按钮
													+ SHorizontalBox::Slot()
														.FillWidth(1.0f)
														.Padding(2, 0, 2, 0)
														[
															SAssignNew(ShadowComplexityButton, SButton)
																.Text(FText::FromString(TEXT("Shadow Complexity")))
																.HAlign(HAlign_Center)
																.VAlign(VAlign_Center)
																.OnClicked(this, &SLightingTabPanel::OnShadowComplexityClicked)
																.ContentPadding(FMargin(10, 5))
																.ToolTipText(FText::FromString(TEXT("Switch to Shadow Complexity view mode")))
														]
												]
										]
								]

							// 第二子格：其他设置和按钮
							+ SVerticalBox::Slot()
								.AutoHeight()
								[
									SNew(SHorizontalBox)

										// 灯光质量下拉框
										+ SHorizontalBox::Slot()
										.FillWidth(1.0f)
										.Padding(5, 0, 5, 0)
										[
											SNew(SBorder)
												.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
												.Padding(10)
												[
													SNew(SVerticalBox)

														+ SVerticalBox::Slot()
														.AutoHeight()
														.Padding(0, 0, 0, 5)
														[
															SNew(STextBlock)
																.Text(FText::FromString(TEXT("Light Quality")))
																.Font(BoldFont)
														]

														+ SVerticalBox::Slot()
														.AutoHeight()
														[
															SAssignNew(LightQualityComboBox, SComboBox<TSharedPtr<FString>>)
																.OptionsSource(&LightQualityOptions)
																.OnSelectionChanged(this, &SLightingTabPanel::OnLightQualityChanged)
																.OnGenerateWidget_Lambda([](TSharedPtr<FString> Option) {
																return SNew(STextBlock).Text(FText::FromString(*Option));
																	})
																.Content()
																[
																	SNew(STextBlock)
																		.Text(FText::FromString(CurrentLightQuality))
																]
														]
												]
										]

									// 刷新灯光列表按钮
									+ SHorizontalBox::Slot()
										.FillWidth(1.0f)
										.Padding(5, 0, 5, 0)
										[
											SAssignNew(RefreshLightListButton, SButton)
												.Text(FText::FromString(TEXT("Refresh Light List")))
												.HAlign(HAlign_Center)
												.VAlign(VAlign_Center)
												.OnClicked(this, &SLightingTabPanel::OnRefreshLightList)
												.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton"))
												.ContentPadding(FMargin(15, 8))
												.ToolTipText(FText::FromString(TEXT("Refresh and update the light list")))
										]

									// 自检灯光按钮
									+ SHorizontalBox::Slot()
										.FillWidth(1.0f)
										.Padding(5, 0, 5, 0)
										[
											SAssignNew(SelfCheckLightsButton, SButton)
												.Text(FText::FromString(TEXT("Self Check Lights")))
												.HAlign(HAlign_Center)
												.VAlign(VAlign_Center)
												.OnClicked(this, &SLightingTabPanel::OnSelfCheckLights)
												.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button"))
												.ContentPadding(FMargin(15, 8))
												.ToolTipText(FText::FromString(TEXT("Perform automatic light validation and issue detection")))
										]
								]
						]

					// 第三格：搜索和过滤控件
					+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0, 0, 0, 10)
						[
							SNew(SHorizontalBox)

								// 搜索框
								+ SHorizontalBox::Slot()
								.FillWidth(2.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(10)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Search Lights")))
														.Font(BoldFont)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SAssignNew(LightSearchBox, SSearchBox)
														.HintText(FText::FromString(TEXT("Search by name, type or level...")))
														.OnTextChanged(this, &SLightingTabPanel::OnSearchTextChanged)
														.OnTextCommitted(this, &SLightingTabPanel::OnSearchTextCommitted)
												]
										]
								]

							// 显示数量下拉框
							+ SHorizontalBox::Slot()
								.FillWidth(1.0f)
								.Padding(5, 0, 5, 0)
								[
									SNew(SBorder)
										.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
										.Padding(10)
										[
											SNew(SVerticalBox)

												+ SVerticalBox::Slot()
												.AutoHeight()
												.Padding(0, 0, 0, 5)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Display Count")))
														.Font(BoldFont)
												]

												+ SVerticalBox::Slot()
												.AutoHeight()
												[
													SAssignNew(DisplayCountComboBox, SComboBox<TSharedPtr<FString>>)
														.OptionsSource(&DisplayCountOptions)
														.OnSelectionChanged(this, &SLightingTabPanel::OnDisplayCountChanged)
														.OnGenerateWidget_Lambda([](TSharedPtr<FString> Option) {
														return SNew(STextBlock).Text(FText::FromString(*Option));
															})
														.Content()
														[
															SNew(STextBlock)
																.Text(FText::FromString(TEXT("50")))
														]
												]
										]
								]
						]

					// 第四格：灯光列表表格
					+ SVerticalBox::Slot()
						.FillHeight(1.0f)
						.Padding(0, 0, 0, 10)
						[
							SNew(SBorder)
								.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
								.Padding(5)
								[
									SNew(SVerticalBox)

										// 表格标题
										+ SVerticalBox::Slot()
										.AutoHeight()
										.Padding(0, 0, 0, 5)
										[
											SNew(SHorizontalBox)

												+ SHorizontalBox::Slot()
												.AutoWidth()
												.VAlign(VAlign_Center)
												[
													SNew(STextBlock)
														.Text(FText::FromString(TEXT("Light List")))
														.Font(BoldFont)
												]

												+ SHorizontalBox::Slot()
												.FillWidth(1.0f)
												.HAlign(HAlign_Right)
												.VAlign(VAlign_Center)
												[
													SNew(STextBlock)
														.Text_Lambda([this]() {
														return GetCurrentViewModeText();
															})
														.Font(SmallFont)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f, 0.8f))
												]
										]

									// 表格
									+ SVerticalBox::Slot()
										.FillHeight(1.0f)
										[
											SAssignNew(LightsListView, SListView<TSharedPtr<FLightInfo>>)
												.ListItemsSource(&FilteredLights)
												.OnGenerateRow(this, &SLightingTabPanel::GenerateLightRow)
												.HeaderRow
												(
													SNew(SHeaderRow)

													+ SHeaderRow::Column(TEXT("Name"))
													.DefaultLabel(FText::FromString(TEXT("Light Name")))
													.FixedWidth(150)
													.HAlignHeader(HAlign_Left)
													.HAlignCell(HAlign_Left)

													+ SHeaderRow::Column(TEXT("Level"))
													.DefaultLabel(FText::FromString(TEXT("Level")))
													.FixedWidth(120)
													.HAlignHeader(HAlign_Left)
													.HAlignCell(HAlign_Left)

													+ SHeaderRow::Column(TEXT("Type"))
													.DefaultLabel(FText::FromString(TEXT("Type")))
													.FixedWidth(100)
													.HAlignHeader(HAlign_Left)
													.HAlignCell(HAlign_Left)

													+ SHeaderRow::Column(TEXT("Cast Shadows"))
													.DefaultLabel(FText::FromString(TEXT("Cast Shadows")))
													.FixedWidth(120)
													.HAlignHeader(HAlign_Center)
													.HAlignCell(HAlign_Center)

													+ SHeaderRow::Column(TEXT("Static"))
													.DefaultLabel(FText::FromString(TEXT("Static")))
													.FixedWidth(80)
													.HAlignHeader(HAlign_Center)
													.HAlignCell(HAlign_Center)

													+ SHeaderRow::Column(TEXT("Source"))
													.DefaultLabel(FText::FromString(TEXT("Source")))
													.FixedWidth(120)
													.HAlignHeader(HAlign_Left)
													.HAlignCell(HAlign_Left)
												)
										]

									// 底部状态栏
									+ SVerticalBox::Slot()
										.AutoHeight()
										.Padding(0, 5, 0, 0)
										[
											SNew(SHorizontalBox)

												+ SHorizontalBox::Slot()
												.FillWidth(1.0f)
												.Padding(8, 4, 8, 4)
												[
													SNew(STextBlock)
														.Text_Lambda([this]() {
														int32 Total = AllLights.Num();
														int32 Filtered = FilteredLights.Num();
														return FText::FromString(FString::Printf(TEXT("Showing %d of %d lights"), Filtered, Total));
															})
														.Font(RegularFont)
														.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f))
														.Justification(ETextJustify::Left)
												]
										]
								]
						]
				]
		];

	// 初始刷新数据
	RefreshSlate();

	// 初始更新按钮样式
	UpdateViewModeButtonStyles();
}

TSharedRef<SWidget> SLightingTabPanel::CreateTextColumn(const FString& Text, float Width, ETextJustify::Type Justify, TOptional<FLinearColor> Color)
{
	return SNew(SBox)
		.WidthOverride(Width)
		.HAlign(Justify == ETextJustify::Left ? HAlign_Left :
			Justify == ETextJustify::Right ? HAlign_Right :
			HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
				.Text(FText::FromString(Text))
				.Font(RegularFont)
				.Justification(Justify)
				.ColorAndOpacity(Color.Get(FLinearColor::White))
				.OverflowPolicy(ETextOverflowPolicy::Ellipsis)
		];
}

TSharedRef<ITableRow> SLightingTabPanel::GenerateLightRow(TSharedPtr<FLightInfo> LightInfo, const TSharedRef<STableViewBase>& OwnerTable)
{
	return SNew(STableRow<TSharedPtr<FLightInfo>>, OwnerTable)
		[
			SNew(SHorizontalBox)

				// 灯名
				+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					CreateTextColumn(LightInfo->Name, 150, ETextJustify::Left)
				]

				// 关卡
				+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					CreateTextColumn(LightInfo->Level, 120, ETextJustify::Left)
				]

				// 灯光类型
				+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SBox)
						.WidthOverride(100)
						.HAlign(HAlign_Left)
						.VAlign(VAlign_Center)
						[
							SNew(STextBlock)
								.Text(FText::FromString(LightInfo->Type))
								.Font(RegularFont)
								.Justification(ETextJustify::Left)
								.ColorAndOpacity(LightInfo->Type == TEXT("Directional") ? FLinearColor(0.8f, 0.4f, 0.1f) :
									LightInfo->Type == TEXT("Spot") ? FLinearColor(0.2f, 0.6f, 1.0f) :
									LightInfo->Type == TEXT("Point") ? FLinearColor(0.2f, 0.8f, 0.2f) :
									FLinearColor(0.8f, 0.2f, 0.8f))
								.OverflowPolicy(ETextOverflowPolicy::Ellipsis)
						]
				]

			// 是否投射阴影
			+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SBox)
						.WidthOverride(120)
						.HAlign(HAlign_Center)
						.VAlign(VAlign_Center)
						[
							SNew(SCheckBox)
								.IsChecked(LightInfo->bCastShadows ? ECheckBoxState::Checked : ECheckBoxState::Unchecked)
								.OnCheckStateChanged_Lambda([this, LightInfo](ECheckBoxState NewState) {
								OnCastShadowsChanged(LightInfo, NewState);
									})
								.ToolTipText(FText::FromString(TEXT("Toggle shadow casting")))
						]
				]

			// 是否静态光源
			+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SBox)
						.WidthOverride(80)
						.HAlign(HAlign_Center)
						.VAlign(VAlign_Center)
						[
							SNew(SCheckBox)
								.IsChecked(LightInfo->bIsStatic ? ECheckBoxState::Checked : ECheckBoxState::Unchecked)
								.OnCheckStateChanged_Lambda([this, LightInfo](ECheckBoxState NewState) {
								OnIsStaticChanged(LightInfo, NewState);
									})
								.ToolTipText(FText::FromString(TEXT("Toggle static light")))
						]
				]

			// 来源
			+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SBox)
						.WidthOverride(120)
						.HAlign(HAlign_Left)
						.VAlign(VAlign_Center)
						[
							SNew(STextBlock)
								.Text(FText::FromString(LightInfo->Source))
								.Font(RegularFont)
								.Justification(ETextJustify::Left)
								.ColorAndOpacity(LightInfo->Source == TEXT("Sequence") ? FLinearColor(0.8f, 0.2f, 0.2f) :
									LightInfo->Source == TEXT("Built-in") ? FLinearColor(0.2f, 0.8f, 0.2f) :
									FLinearColor(0.7f, 0.7f, 0.7f))
								.OverflowPolicy(ETextOverflowPolicy::Ellipsis)
						]
				]
		];
}

void SLightingTabPanel::OnCastShadowsChanged(TSharedPtr<FLightInfo> LightInfo, ECheckBoxState NewState)
{
	if (!LightInfo.IsValid())
	{
		return;
	}

	// 更新数据
	LightInfo->bCastShadows = (NewState == ECheckBoxState::Checked);

	// 更新对应的 Actor（如果存在）
	if (LightInfo->LightActor.IsValid())
	{
		ALight* Light = Cast<ALight>(LightInfo->LightActor.Get());
		if (Light && Light->GetLightComponent())
		{
			Light->GetLightComponent()->Modify(); // 支持撤销
			Light->GetLightComponent()->CastShadows = LightInfo->bCastShadows;

			// 如果需要立即更新，可以调用：
			// Light->GetLightComponent()->MarkRenderStateDirty();
		}
	}

	// 刷新显示
	RefreshSlate();

	// 可选：记录日志
	UE_LOG(LogTemp, Log, TEXT("Light %s shadow casting changed to: %s"),
		*LightInfo->Name, LightInfo->bCastShadows ? TEXT("Enabled") : TEXT("Disabled"));
}

void SLightingTabPanel::OnIsStaticChanged(TSharedPtr<FLightInfo> LightInfo, ECheckBoxState NewState)
{
	if (!LightInfo.IsValid())
	{
		return;
	}

	// 更新数据
	LightInfo->bIsStatic = (NewState == ECheckBoxState::Checked);

	// 更新对应的 Actor（如果存在）
	if (LightInfo->LightActor.IsValid())
	{
		ALight* Light = Cast<ALight>(LightInfo->LightActor.Get());
		if (Light && Light->GetLightComponent())
		{
			Light->GetLightComponent()->Modify(); // 支持撤销
			Light->GetLightComponent()->Mobility = LightInfo->bIsStatic ?
				EComponentMobility::Static : EComponentMobility::Movable;

			// 如果需要立即更新，可以调用：
			// Light->GetLightComponent()->MarkRenderStateDirty();
		}
	}

	// 刷新显示
	RefreshSlate();

	// 可选：记录日志
	UE_LOG(LogTemp, Log, TEXT("Light %s static property changed to: %s"),
		*LightInfo->Name, LightInfo->bIsStatic ? TEXT("Static") : TEXT("Dynamic"));
}

void SLightingTabPanel::OnFrameStatUpdate(FPerfData& InPerfData)
{
	DynamicLightNum = InPerfData.NumLights;
	CastShadowLightNum = InPerfData.NumShadowedLights;
	LightComplexityAvg = InPerfData.LightComplexityAvg;

	UpdateLightList();

	FilterLightList();

	RefreshSlate();
}

void SLightingTabPanel::RefreshSlate()
{
	DynamicLightCountLabel->SetText(FText::FromString(FString::Printf(TEXT("%d"), DynamicLightNum)));
	ShadowLightCountLabel->SetText(FText::FromString(FString::Printf(TEXT("%d"), CastShadowLightNum)));
	SequenceLightCountLabel->SetText(FText::FromString(FString::Printf(TEXT("%d"), SequenceLightNum)));

	LightWeightedAreaLabel->SetText(FText::FromString(FString::Printf(TEXT("%.2f%%"), LightComplexityAvg * 100)));

	// 根据数值设置颜色警告
	if (DynamicLightNum > 10)
	{
		DynamicLightCountLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f));
	}
	else if (DynamicLightNum > 5)
	{
		DynamicLightCountLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.8f, 0.2f, 1.0f));
	}
	else
	{
		DynamicLightCountLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f));
	}

	if (CastShadowLightNum > 8)
	{
		ShadowLightCountLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f));
	}
	else
	{
		ShadowLightCountLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f));
	}

	if (LightComplexityAvg > 90.0f)
	{
		LightWeightedAreaLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f));
	}
	else if (LightComplexityAvg > 70.0f)
	{
		LightWeightedAreaLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.8f, 0.2f, 1.0f));
	}
	else
	{
		LightWeightedAreaLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f));
	}

	if (SequenceLightNum > 5)
	{
		SequenceLightCountLabel->SetColorAndOpacity(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f));
	}
	else
	{
		SequenceLightCountLabel->SetColorAndOpacity(FLinearColor(0.2f, 0.8f, 0.2f, 1.0f));
	}
}

FReply SLightingTabPanel::OnRefreshLightList()
{
	UE_LOG(LogTemp, Log, TEXT("Refresh light list"));

	UpdateLightList();

	FilterLightList();
	RefreshSlate();

	// 显示通知
	FNotificationInfo Info(FText::FromString(TEXT("Light list refreshed")));
	Info.ExpireDuration = 2.0f;
	FSlateNotificationManager::Get().AddNotification(Info);

	return FReply::Handled();
}

FReply SLightingTabPanel::OnSelfCheckLights()
{
	UE_LOG(LogTemp, Log, TEXT("Self check lights"));

	// 检查潜在问题
	TArray<FString> Issues;

	int32 DynamicCount = 0;
	int32 ShadowCount = 0;
	for (const auto& Light : AllLights)
	{
		if (!Light->bIsStatic) DynamicCount++;
		if (Light->bCastShadows) ShadowCount++;
	}

	if (DynamicCount > 8)
	{
		Issues.Add(FString::Printf(TEXT("Too many dynamic lights: %d (recommend <= 8)"), DynamicCount));
	}

	if (ShadowCount > 6)
	{
		Issues.Add(FString::Printf(TEXT("Too many shadow-casting lights: %d (recommend <= 6)"), ShadowCount));
	}

	// 显示结果
	if (Issues.Num() > 0)
	{
		FString Message = TEXT("Light issues found:\n");
		for (const auto& Issue : Issues)
		{
			Message += TEXT("• ") + Issue + TEXT("\n");
		}

		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
	}
	else
	{
		FNotificationInfo Info(FText::FromString(TEXT("No light issues found")));
		Info.ExpireDuration = 3.0f;
		FSlateNotificationManager::Get().AddNotification(Info);
	}

	return FReply::Handled();
}

FReply SLightingTabPanel::OnNormalViewClicked()
{
	SetViewMode(EViewMode::Normal);
	return FReply::Handled();
}

FReply SLightingTabPanel::OnLightComplexityClicked()
{
	SetViewMode(EViewMode::LightComplexity);
	return FReply::Handled();
}

FReply SLightingTabPanel::OnShadowComplexityClicked()
{
	SetViewMode(EViewMode::ShadowComplexity);
	return FReply::Handled();
}

void SLightingTabPanel::UpdateLightList()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>("LevelEditor");
	TSharedPtr<IAssetViewport> ActiveLevelViewport = LevelEditorModule.GetFirstActiveViewport();
	if (ActiveLevelViewport.IsValid() == false)
	{
		return;
	}

	FEditorViewportClient& vc = ActiveLevelViewport->GetAssetViewportClient();

	UWorld* w = vc.GetWorld();
	if (w == nullptr)
	{
		return;
	}

	TArray<AActor*> TmpLightActorList;
	UGameplayStatics::GetAllActorsOfClass(w, ALight::StaticClass(), TmpLightActorList);
	TArray<TSharedPtr<FLightInfo>> TempAllLights;


	TArray<AActor*> SequenceLights;
	FPerfData::CollectSequenceData(w, SequenceLights);

	SequenceLightNum = SequenceLights.Num();

	for (AActor* Actor : TmpLightActorList)
	{
		ALight* al = Cast<ALight>(Actor);
		if (al == nullptr)
		{
			continue;
		}

		if (al->IsEnabled() == false)
		{
			continue;
		}

		if (al->IsTemporarilyHiddenInEditor(true))
		{
			continue;
		}

		int idx = TempAllLights.Add(MakeShared<FLightInfo>());
		FLightInfo& linfo = *TempAllLights[idx];
		linfo.LightActor = al;
		linfo.Name = al->GetActorLabel();
		UObject* ot = al->GetOuter();
		if (ot)
		{
			linfo.Level = ot->GetName();
		}

		linfo.Type = al->GetClass()->GetName();
		ULightComponent* lc = al->GetLightComponent();
		if (lc)
		{
			linfo.bCastShadows = lc->CastShadows;
			linfo.bIsStatic = lc->Mobility == EComponentMobility::Static;
		}

		if (SequenceLights.Contains(al))
		{
			linfo.Source = TEXT("Sequence");
		}
		else
		{
			linfo.Source = TEXT("");
		}
	}

	if (TempAllLights.Num() != AllLights.Num())
	{
		bAllLightsDirty = true;
	}
	else
	{
		for (int32 i = 0; i < TempAllLights.Num(); i++)
		{
			TSharedPtr<FLightInfo> TempLightInfo = TempAllLights[i];
			if (TempLightInfo.IsValid() == false || TempLightInfo->LightActor.IsValid() == false)
			{
				bAllLightsDirty = true;
				break;
			}

			int32 FoundIdx = -1;
			for (int32 j = 0; j < AllLights.Num(); ++j)
			{
				if (TempLightInfo->LightActor == AllLights[j]->LightActor)
				{
					FoundIdx = j;
					break;
				}
			}

			if (FoundIdx == -1)
			{
				bAllLightsDirty = true;
				break;
			}

			if (*TempLightInfo == *AllLights[FoundIdx])
			{

			}
			else
			{
				bAllLightsDirty = true;
				break;
			}
		}
	}

	if (bAllLightsDirty)
	{
		AllLights = MoveTemp(TempAllLights);
		UE_LOG(LogTemp, Log, TEXT("Light list updated. Total lights: %d"), AllLights.Num());
	}
	else
	{
		UE_LOG(LogTemp, Log, TEXT("Light list unchanged. Total lights: %d"), AllLights.Num());
	}
}

void SLightingTabPanel::SetViewMode(EViewMode NewMode)
{
	if (CurrentViewMode == NewMode)
	{
		return; // 已经是当前模式，不需要切换
	}

	FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>("LevelEditor");
	TSharedPtr<IAssetViewport> ActiveLevelViewport = LevelEditorModule.GetFirstActiveViewport();
	if (ActiveLevelViewport.IsValid() == false)
	{
		return;
	}

	CurrentViewMode = NewMode;

	switch (CurrentViewMode)
	{
	case EViewMode::Normal:
		ActiveLevelViewport->GetAssetViewportClient().SetViewMode(VMI_Lit);
		break;

	case EViewMode::LightComplexity:
		ActiveLevelViewport->GetAssetViewportClient().SetViewMode(VMI_LightComplexity);
		break;

	case EViewMode::ShadowComplexity:
		ActiveLevelViewport->GetAssetViewportClient().SetViewMode(VMI_ShaderComplexity);
		break;
	}

	// 更新按钮样式
	UpdateViewModeButtonStyles();
}

void SLightingTabPanel::UpdateViewModeButtonStyles()
{
	if (NormalViewButton.IsValid())
	{
		NormalViewButton->SetButtonStyle((CurrentViewMode == EViewMode::Normal) ? PrimaryButtonStyle : StandardButtonStyle);
	}

	if (LightComplexityButton.IsValid())
	{
		LightComplexityButton->SetButtonStyle((CurrentViewMode == EViewMode::LightComplexity) ? PrimaryButtonStyle : StandardButtonStyle);
	}

	if (ShadowComplexityButton.IsValid())
	{
		ShadowComplexityButton->SetButtonStyle((CurrentViewMode == EViewMode::ShadowComplexity) ? PrimaryButtonStyle : StandardButtonStyle);
	}
}

void SLightingTabPanel::OnLightQualityChanged(TSharedPtr<FString> NewSelection, ESelectInfo::Type SelectType)
{
	if (NewSelection.IsValid())
	{
		CurrentLightQuality = *NewSelection;
		UE_LOG(LogTemp, Log, TEXT("Light Quality changed to: %s"), *CurrentLightQuality);

		// 这里应该应用灯光质量设置
	}
}

void SLightingTabPanel::OnDisplayCountChanged(TSharedPtr<FString> NewSelection, ESelectInfo::Type SelectType)
{
	if (NewSelection.IsValid())
	{
		if (*NewSelection == TEXT("All"))
		{
			CurrentDisplayCount = -1; // 表示显示所有
		}
		else
		{
			CurrentDisplayCount = FCString::Atoi(**NewSelection);
		}

		UE_LOG(LogTemp, Log, TEXT("Display count changed to: %s"), **NewSelection);
		FilterLightList();
	}
}

void SLightingTabPanel::OnSearchTextChanged(const FText& SearchText)
{
	CurrentSearchText = SearchText.ToString();
	FilterLightList();
}

void SLightingTabPanel::OnSearchTextCommitted(const FText& SearchText, ETextCommit::Type CommitType)
{
	CurrentSearchText = SearchText.ToString();
	FilterLightList();
}

FText SLightingTabPanel::GetCurrentViewModeText() const
{
	switch (CurrentViewMode)
	{
	case EViewMode::Normal:
		return FText::FromString(TEXT("Normal View Mode"));
	case EViewMode::LightComplexity:
		return FText::FromString(TEXT("Light Complexity View Mode"));
	case EViewMode::ShadowComplexity:
		return FText::FromString(TEXT("Shadow Complexity View Mode"));
	default:
		return FText::FromString(TEXT("Unknown View Mode"));
	}
}

void SLightingTabPanel::FilterLightList()
{
	if (bAllLightsDirty)
	{
		bAllLightsDirty = false;
	}
	else
	{
		return; // 如果灯光列表未更改，则不需要重新过滤
	}

	FilteredLights.Empty();

	for (const auto& Light : AllLights)
	{
		// 应用搜索过滤
		if (!CurrentSearchText.IsEmpty())
		{
			FString SearchTextLower = CurrentSearchText.ToLower();
			FString NameLower = Light->Name.ToLower();
			FString LevelLower = Light->Level.ToLower();
			FString TypeLower = Light->Type.ToLower();
			FString SourceLower = Light->Source.ToLower();

			if (!NameLower.Contains(SearchTextLower) &&
				!LevelLower.Contains(SearchTextLower) &&
				!TypeLower.Contains(SearchTextLower) &&
				!SourceLower.Contains(SearchTextLower))
			{
				continue;
			}
		}

		FilteredLights.Add(Light);
	}

	// 应用数量限制
	if (CurrentDisplayCount > 0 && FilteredLights.Num() > CurrentDisplayCount)
	{
		FilteredLights.SetNum(CurrentDisplayCount);
	}

	// 刷新列表视图
	if (LightsListView.IsValid())
	{
		LightsListView->RequestListRefresh();
	}
}