#pragma once
#include "CoreMinimal.h"
#include "ContentBrowserFrontEndFilterExtension.h"

#include "FrontendFilterBase.h"

#include "ResourceCustomFrontendFilter.generated.h"

UCLASS()
class UResourceCustomAssetSearchFilter : public UContentBrowserFrontEndFilterExtension
{
public:
	GENERATED_BODY()

	virtual void AddFrontEndFilterExtensions(TSharedPtr<class FFrontendFilterCategory> DefaultCategory, TArray< TSharedRef<class FFrontendFilter> >& InOutFilterList) const override;
};

class FFrontendFilter_AssetEditorTag : public FFrontendFilter
{
public:
	FFrontendFilter_AssetEditorTag(TSharedPtr<FFrontendFilterCategory> InCategory);

	// FFrontendFilter implementation
	virtual FString GetName() const override;
	virtual FText GetDisplayName() const override;
	virtual FText GetToolTipText() const override;
	virtual void ModifyContextMenu(FMenuBuilder& MenuBuilder) override;

	// IFilter implementation
	virtual bool PassesFilter(FAssetFilterType InItem) const override;

protected:

	FText GetTagsValueAsText() const; 
	void OnTagsValueTextCommitted(const FText& InText, ETextCommit::Type InCommitType);

public:
	TSet<FName> TargetTags;
};