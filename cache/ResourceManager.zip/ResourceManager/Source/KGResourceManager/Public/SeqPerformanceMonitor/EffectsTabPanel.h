#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Layout/SSplitter.h"
#include "SeqPerformanceMonitor/MonitorTabPanel.h"

class SEffectsTabPanel : public SMonitorTabPanel
{
public:
	SLATE_BEGIN_ARGS(SEffectsTabPanel) {}
	SLATE_END_ARGS()

	virtual void Construct(const FArguments& InArgs);

	// 获取标签页名称
	FText GetTabName() const { return FText::FromString(TEXT("Effects")); }

	// 刷新特效数据
	void RefreshEffectsData();

	virtual void OnFrameStatUpdate(FPerfData& InPerfData) {}

private:
	// 特效数据结构
	struct FEffectInfo
	{
		FString Name;
		FString Level;
		bool bIsGPUParticle;
		FString MaterialComplexity;
		int32 OverdrawCount;
		bool bIsPreplaced;
		int32 ParticleCount;  // 用于排序

		FEffectInfo() : bIsGPUParticle(false), OverdrawCount(0), bIsPreplaced(false), ParticleCount(0) {}
		FEffectInfo(const FString& InName, const FString& InLevel, bool bInIsGPUParticle,
			const FString& InMaterialComplexity, int32 InOverdrawCount,
			bool bInIsPreplaced, int32 InParticleCount)
			: Name(InName), Level(InLevel), bIsGPUParticle(bInIsGPUParticle),
			MaterialComplexity(InMaterialComplexity), OverdrawCount(InOverdrawCount),
			bIsPreplaced(bInIsPreplaced), ParticleCount(InParticleCount) {
		}
	};

	// 按钮回调函数
	FReply OnRefreshEffectsList();
	FReply OnSelfCheckEffects();

	// 开关回调函数
	void OnOverdrawViewChanged(ECheckBoxState NewState);
	void OnMaterialComplexityChanged(ECheckBoxState NewState);
	void OnEffectHierarchyChanged(ECheckBoxState NewState);
	void OnOverdrawDisplayChanged(ECheckBoxState NewState);

	// 下拉框回调函数
	void OnEffectQualityChanged(TSharedPtr<FString> NewSelection, ESelectInfo::Type SelectType);
	void OnDisplayCountChanged(TSharedPtr<FString> NewSelection, ESelectInfo::Type SelectType);

	// 搜索框回调函数
	void OnSearchTextChanged(const FText& SearchText);
	void OnSearchTextCommitted(const FText& SearchText, ETextCommit::Type CommitType);

	// 生成表格行
	TSharedRef<ITableRow> GenerateEffectRow(TSharedPtr<FEffectInfo> EffectInfo, const TSharedRef<STableViewBase>& OwnerTable);

	// 创建文本列控件
	TSharedRef<SWidget> CreateTextColumn(const FString& Text, float Width, ETextJustify::Type Justify = ETextJustify::Left,
		TOptional<FLinearColor> Color = TOptional<FLinearColor>());

	// 过滤特效列表
	void FilterEffectsList();

	// 排序特效列表（按粒子数从大到小）
	void SortEffectsList();

private:
	// 性能数据显示控件
	TSharedPtr<STextBlock> ActiveEmitterCountLabel;
	TSharedPtr<STextBlock> TotalParticleCountLabel;
	TSharedPtr<STextBlock> MaterialComplexityLabel;
	TSharedPtr<STextBlock> OverdrawTotalLabel;

	// 开关控件
	TSharedPtr<SCheckBox> OverdrawViewCheckBox;
	TSharedPtr<SCheckBox> MaterialComplexityCheckBox;
	TSharedPtr<SCheckBox> EffectHierarchyCheckBox;
	TSharedPtr<SCheckBox> OverdrawDisplayCheckBox;

	// 下拉框控件
	TSharedPtr<SComboBox<TSharedPtr<FString>>> EffectQualityComboBox;
	TSharedPtr<SComboBox<TSharedPtr<FString>>> DisplayCountComboBox;

	// 搜索框控件
	TSharedPtr<SSearchBox> EffectSearchBox;

	// 按钮控件
	TSharedPtr<SButton> RefreshEffectsButton;
	TSharedPtr<SButton> SelfCheckEffectsButton;

	// 表格控件
	TSharedPtr<SListView<TSharedPtr<FEffectInfo>>> EffectsListView;

	// 数据
	TArray<TSharedPtr<FEffectInfo>> AllEffects;
	TArray<TSharedPtr<FEffectInfo>> FilteredEffects;

	// 下拉框选项
	TArray<TSharedPtr<FString>> EffectQualityOptions;
	TArray<TSharedPtr<FString>> DisplayCountOptions;

	// 当前设置
	FString CurrentSearchText;
	FString CurrentEffectQuality = TEXT("High");
	int32 CurrentDisplayCount = 50;
	bool bOverdrawViewEnabled = false;
	bool bMaterialComplexityEnabled = false;
	bool bEffectHierarchyEnabled = false;
	bool bOverdrawDisplayEnabled = false;

	// 字体
	FSlateFontInfo RegularFont;
	FSlateFontInfo BoldFont;
	FSlateFontInfo SmallFont;
};