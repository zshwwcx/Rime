#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Layout/SSplitter.h"

#include "SeqPerformanceMonitor/PMSubSystem.h"

// 性能数据结构
struct FPerformanceSample
{
	FString Timestamp;
	float FPS;
	int32 TrisCount;
	int32 BatchCount;
};



// 基类标签页
class SMonitorTabPanel : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SMonitorTabPanel) {}
	SLATE_END_ARGS()

	//virtual void Construct(const FArguments& InArgs) = 0;
	virtual void RefreshData() {}
	virtual void OnFrameStatUpdate(FPerfData& InPerfData) {}
	virtual FText GetTabName() const { return FText::GetEmpty(); }

protected:
	TSharedPtr<SWidget> CreateNotImplementedPanel()
	{
		return SNew(SBox)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			[
				SNew(STextBlock)
					.Text(FText::FromString("该功能面板正在开发中..."))
					.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f))
			];
	}
};