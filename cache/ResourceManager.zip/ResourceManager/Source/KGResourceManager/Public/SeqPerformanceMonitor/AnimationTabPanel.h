#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Layout/SSplitter.h"
#include "SeqPerformanceMonitor/MonitorTabPanel.h"


// Struct for list items
struct FActorListItem
{
	FString ActorName;
	int32 PolyCount;
	int32 BoneCount;
	float TextureSizeMB;  // Store as float for proper sorting
	FString TextureSizeText;
	bool bClothEnabled;

	FActorListItem()
		: PolyCount(0)
		, BoneCount(0)
		, TextureSizeMB(0.0f)
		, bClothEnabled(false)
	{
	}
};

class SAnimationTabPanel : public SMonitorTabPanel
{
public:
	SLATE_BEGIN_ARGS(SAnimationTabPanel) {}
	SLATE_END_ARGS()

	// 添加 override 关键字
	virtual void Construct(const FArguments& InArgs);
	void RefreshData() override;
	virtual void OnFrameStatUpdate(FPerfData& InPerfData) {}
	FText GetTabName() const override { return FText::FromString(TEXT("SkeletalMesh")); }

private:
	// Quick action button callbacks
	FReply OnToggleOverDrawViewMode();
	FReply OnToggleMaterialComplexityMode();
	FReply OnToggleEffectsLOD();
	FReply OnToggleOverlay();

	FReply OnRunQuickCheck();
	FReply OnToggleMaterialComplexity();
	FReply OnTogglePrimaryLightOnly();

	FReply OnRefreshActorList();

	// List sorting callbacks
	void OnSortByActorName();
	void OnSortByPolyCount();
	void OnSortByBoneCount();
	void OnSortByTextureSize();
	void OnSortByClothEnabled();

	// Utility functions
	void UpdateActorList();
	void ApplyFilterToActorList();

	// Stats display widgets (top row)
	TSharedPtr<STextBlock> TotalTrianglesLabel;
	TSharedPtr<STextBlock> SkeletalMeshCountLabel;
	TSharedPtr<STextBlock> TotalTextureSizeLabel;
	TSharedPtr<STextBlock> ClothActorsLabel;

	// Toggle buttons (first quick action row)
	TSharedPtr<SCheckBox> OverDrawViewModeToggle;
	TSharedPtr<SCheckBox> MaterialComplexityModeToggle;
	TSharedPtr<SCheckBox> EffectsLODToggle;
	TSharedPtr<SCheckBox> OverlayToggle;

	// Second quick action row
	TSharedPtr<SButton> QuickCheckButton;
	TSharedPtr<SCheckBox> MaterialComplexityToggle;
	TSharedPtr<SCheckBox> PrimaryLightOnlyToggle;

	// Control row widgets
	TSharedPtr<SButton> RefreshActorListButton;
	TSharedPtr<SEditableTextBox> FilterTextBox;
	TSharedPtr<SComboBox<TSharedPtr<FString>>> DisplayCountComboBox;

	// List view related
	TSharedPtr<SListView<TSharedPtr<FActorListItem>>> ActorListView;
	TArray<TSharedPtr<FActorListItem>> ActorListItems;
	TArray<TSharedPtr<FActorListItem>> FilteredActorListItems;
	TArray<TSharedPtr<FString>> DisplayCountOptions;

	// Current filter and display settings
	FString CurrentFilterText;
	int32 CurrentDisplayCount = 50;

	// Sorting state
	enum class ESortColumn
	{
		ActorName,
		PolyCount,
		BoneCount,
		TextureSize,
		ClothEnabled
	};

	ESortColumn CurrentSortColumn = ESortColumn::ActorName;
	bool bSortAscending = true;

	// Sort arrow visibility
	bool bShowActorNameSortArrow = false;
	bool bShowPolyCountSortArrow = false;
	bool bShowBoneCountSortArrow = false;
	bool bShowTextureSizeSortArrow = false;
	bool bShowClothEnabledSortArrow = false;

	
};