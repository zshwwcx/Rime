#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Layout/SSplitter.h"
#include "SeqPerformanceMonitor/MonitorTabPanel.h"

// 灯光标签页
class SLightingTabPanel : public SMonitorTabPanel
{
public:
	SLATE_BEGIN_ARGS(SLightingTabPanel) {}
	SLATE_END_ARGS()

	virtual void Construct(const FArguments& InArgs);

	virtual void OnFrameStatUpdate(FPerfData& InPerfData);

	// 获取标签页名称
	FText GetTabName() const { return FText::FromString(TEXT("Lighting")); }

	// 刷新灯光数据
	void RefreshSlate();

private:
	// 灯光数据结构
	struct FLightInfo
	{
		FString Name;
		FString Level;
		FString Type;
		bool bCastShadows;
		bool bIsStatic;
		FString Source;
		TWeakObjectPtr<AActor> LightActor;

		FLightInfo() : bCastShadows(false), bIsStatic(false) {}
		FLightInfo(const FString& InName, const FString& InLevel, const FString& InType,
			bool bInCastShadows, bool bInIsStatic, const FString& InSource)
			: Name(InName), Level(InLevel), Type(InType),
			bCastShadows(bInCastShadows), bIsStatic(bInIsStatic), Source(InSource) {
		}

		bool operator==(const FLightInfo& Other) const
		{
			return Name == Other.Name && Type == Other.Type
				&& bCastShadows == Other.bCastShadows && bIsStatic == Other.bIsStatic
				&& Source == Other.Source;
		}
	};

	// 视图模式枚举
	enum class EViewMode
	{
		Normal,
		LightComplexity,
		ShadowComplexity
	};

	// 按钮回调函数
	FReply OnRefreshLightList();
	FReply OnSelfCheckLights();

	// 视图模式切换回调
	FReply OnNormalViewClicked();
	FReply OnLightComplexityClicked();
	FReply OnShadowComplexityClicked();
	void SetViewMode(EViewMode NewMode);

	// 下拉框回调函数
	void OnLightQualityChanged(TSharedPtr<FString> NewSelection, ESelectInfo::Type SelectType);
	void OnDisplayCountChanged(TSharedPtr<FString> NewSelection, ESelectInfo::Type SelectType);

	// 搜索框回调函数
	void OnSearchTextChanged(const FText& SearchText);
	void OnSearchTextCommitted(const FText& SearchText, ETextCommit::Type CommitType);

	// 生成表格行
	TSharedRef<ITableRow> GenerateLightRow(TSharedPtr<FLightInfo> LightInfo, const TSharedRef<STableViewBase>& OwnerTable);

	// 创建文本列控件
	TSharedRef<SWidget> CreateTextColumn(const FString& Text, float Width, ETextJustify::Type Justify = ETextJustify::Left,
		TOptional<FLinearColor> Color = TOptional<FLinearColor>());

	// 灯光列表
	void UpdateLightList();
	void FilterLightList();

	// 获取当前视图模式文本
	FText GetCurrentViewModeText() const;

	// 更新视图模式按钮样式
	void UpdateViewModeButtonStyles();

	// 新增：勾选操作回调函数
	void OnCastShadowsChanged(TSharedPtr<FLightInfo> LightInfo, ECheckBoxState NewState);
	void OnIsStaticChanged(TSharedPtr<FLightInfo> LightInfo, ECheckBoxState NewState);

private:
	// 性能数据显示控件
	TSharedPtr<STextBlock> DynamicLightCountLabel;
	TSharedPtr<STextBlock> LightWeightedAreaLabel;
	TSharedPtr<STextBlock> ShadowLightCountLabel;
	TSharedPtr<STextBlock> SequenceLightCountLabel;

	// 视图模式按钮
	TSharedPtr<SButton> NormalViewButton;
	TSharedPtr<SButton> LightComplexityButton;
	TSharedPtr<SButton> ShadowComplexityButton;
	EViewMode CurrentViewMode = EViewMode::Normal;

	// 下拉框控件
	TSharedPtr<SComboBox<TSharedPtr<FString>>> LightQualityComboBox;
	TSharedPtr<SComboBox<TSharedPtr<FString>>> DisplayCountComboBox;

	// 搜索框控件
	TSharedPtr<SSearchBox> LightSearchBox;

	// 按钮控件
	TSharedPtr<SButton> RefreshLightListButton;
	TSharedPtr<SButton> SelfCheckLightsButton;

	// 表格控件
	TSharedPtr<SListView<TSharedPtr<FLightInfo>>> LightsListView;

	// 数据
	bool bAllLightsDirty = false;
	TArray<TSharedPtr<FLightInfo>> AllLights;
	TArray<TSharedPtr<FLightInfo>> FilteredLights;

	// 下拉框选项
	TArray<TSharedPtr<FString>> LightQualityOptions;
	TArray<TSharedPtr<FString>> DisplayCountOptions;

	// 当前设置
	FString CurrentSearchText;
	FString CurrentLightQuality = TEXT("High");
	int32 CurrentDisplayCount = 50;

	// 字体
	FSlateFontInfo RegularFont;
	FSlateFontInfo BoldFont;
	FSlateFontInfo SmallFont;

	// 按钮样式
	const FButtonStyle* PrimaryButtonStyle = &FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton");
	const FButtonStyle* StandardButtonStyle = &FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button");

	// 更新性能数据
	int32 DynamicLightNum = 0;
	int32 CastShadowLightNum = 0;
	int32 SequenceLightNum = 0;
	float LightComplexityAvg = 0;

	TArray<AActor*> LightActorList;
};