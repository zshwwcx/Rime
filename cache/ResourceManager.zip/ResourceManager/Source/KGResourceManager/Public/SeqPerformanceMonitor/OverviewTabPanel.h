#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Layout/SSplitter.h"
#include "SeqPerformanceMonitor/MonitorTabPanel.h"

// 极简循环数组，只有核心功能
template<typename T>
class TCircularArray
{
public:
	TCircularArray() : MaxSize(1000), Head(0), Size(0)
	{
		Data.Reserve(MaxSize);
	}

	void SetMaxSize(int32 InMaxSize)
	{
		MaxSize = FMath::Max(1, InMaxSize);

		if (Size > MaxSize)
		{
			// 保留最新的MaxSize个数据
			TArray<T> NewData;
			NewData.Reserve(MaxSize);

			// 从最新的数据开始复制
			for (int32 i = Size - MaxSize; i < Size; ++i)
			{
				NewData.Add((*this)[i]);
			}

			Data = MoveTemp(NewData);
			Head = 0;
			Size = MaxSize;
		}
		else
		{
			Data.Reserve(MaxSize);
		}
	}

	void Add(const T& Item)
	{
		if (Size < MaxSize)
		{
			Data.Add(Item);
			Size++;
		}
		else
		{
			Data[Head] = Item;
			Head = (Head + 1) % MaxSize;
		}
	}

	const T& operator[](int32 Index) const
	{
		check(Index >= 0 && Index < Size);

		if (Size < MaxSize)
		{
			return Data[Index];
		}
		else
		{
			return Data[(Head + Index) % MaxSize];
		}
	}

	T& operator[](int32 Index)
	{
		check(Index >= 0 && Index < Size);

		if (Size < MaxSize)
		{
			return Data[Index];
		}
		else
		{
			return Data[(Head + Index) % MaxSize];
		}
	}

	int32 Num() const { return Size; }
	bool IsEmpty() const { return Size == 0; }

	void Empty()
	{
		Data.Empty();
		Head = 0;
		Size = 0;
	}

	const T& GetLast() const
	{
		check(Size > 0);
		return (*this)[Size - 1];
	}

	const T& GetFirst() const
	{
		check(Size > 0);
		return (*this)[0];
	}

	int32 GetMaxSize() const { return MaxSize; }

private:
	TArray<T> Data;
	int32 MaxSize;
	int32 Head;   // 数组已满时，指向最旧数据的下一个位置
	int32 Size;   // 当前元素数量
};

// 图表数据点
struct FChartDataPoint
{
	float X;
	float Y;

	FChartDataPoint() : X(0), Y(0) {}
	FChartDataPoint(float InX, float InY) : X(InX), Y(InY) {}
};

// 图表配置 - 简化版本
struct FLineChartConfig
{
	FVector2D ChartSize = FVector2D(400, 200);
	FString Title = TEXT("Line Chart");
	FString XAxisLabel = TEXT("Time");
	FString YAxisLabel = TEXT("Value");
	FLinearColor LineColor = FLinearColor::Green;
	float LineThickness = 2.0f;

	// 显示控制
	bool bShowGrid = true;
	bool bShowPoints = true;
	bool bShowValueLabels = false;

	// 数据控制 - 完全由配置决定
	int32 MaxDataPoints = 1000;      // 最大存储点数
	int32 VisiblePoints = 1000;       // 可见点数
	int32 GridLineCount = 10;        // 网格线数量
	float MinYValue = 0.0f;          // Y轴最小值
	float MaxYValue = 150.0f;        // Y轴最大值

	// 采样控制
	int32 SampleRate = 1;            // 采样率（每n个点取1个）

	// 时间窗口控制（秒）
	float TimeWindow = 10.0f;        // 显示的时间窗口
};

// 独立曲线图控件 - 简化版本
class SLineChartWidget : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SLineChartWidget)
		: _ChartConfig()
		{
		}

		SLATE_ARGUMENT(FLineChartConfig, ChartConfig)

	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	// 接口保持与原始版本兼容
	void SetDataPoints(const TArray<FChartDataPoint>& NewDataPoints);
	void SetChartConfig(const FLineChartConfig& NewConfig);
	TArray<FChartDataPoint> GetDataPoints() const;
	void ClearData();
	void AddDataPoint(const FChartDataPoint& NewPoint);
	void AddDataPoint(float X, float Y);

	// 新增控制接口
	void SetVisiblePoints(int32 Points);
	void SetYRange(float MinY, float MaxY);
	void SetTimeWindow(float Seconds);
	void SetSampleRate(int32 Rate);

private:
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	void DrawGridAndAxis(const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32& LayerId) const;
	void DrawLineChart(const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32& LayerId) const;
	void DrawDataPoints(const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32& LayerId) const;
	void DrawValueLabels(const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32& LayerId) const;

	FVector2D NormalizeToScreen(const FVector2D& DataPoint, const FVector2D& ScreenSize, float MinX, float MaxX) const;
	FString FormatValue(float Value) const;

	// 计算可见数据范围
	void CalculateVisibleRange(float& OutMinX, float& OutMaxX) const;

private:
	TCircularArray<FChartDataPoint> DataPoints;
	FLineChartConfig ChartConfig;
};

// 总览标签页
class SOverviewTabPanel : public SMonitorTabPanel
{
public:
	SLATE_BEGIN_ARGS(SOverviewTabPanel) {}
	SLATE_END_ARGS()

	virtual void Construct(const FArguments& InArgs);
	void RefreshSlate();
	virtual void OnFrameStatUpdate(FPerfData& InPerfData);
	FText GetTabName() const override { return FText::FromString(TEXT("Overview")); }

private:
	// 枚举表示选中的图表类型
	enum class EChartType
	{
		FPS,
		Tris,
		DrawCalls  // 从Batches改为DrawCalls
	};

	// 切换到指定图表
	void SwitchToChart(EChartType ChartType);

	// 按钮回调
	FReply OnRunSelfCheck();
	FReply OnClearWarnings();

	// 性能数据显示控件（精简版）
	TSharedPtr<STextBlock> FPSValueLabel;
	TSharedPtr<STextBlock> TrisCountLabel;
	TSharedPtr<STextBlock> DrawCallLabel;  // 从TotalBatchLabel改为DrawCallLabel
	TSharedPtr<STextBlock> ShadowTrisLabel;  // Shadow Pass数据

	// 图表控件
	TSharedPtr<SLineChartWidget> FPSChart;
	TSharedPtr<SLineChartWidget> TrisChart;
	TSharedPtr<SLineChartWidget> DrawCallChart;  // 从BatchesChart改为DrawCallChart

	// 图表切换器（使用WidgetSwitcher）
	TSharedPtr<SWidgetSwitcher> ChartSwitcher;

	// 图表切换按钮
	TSharedPtr<SButton> FPSChartButton;
	TSharedPtr<SButton> TrisChartButton;
	TSharedPtr<SButton> DrawCallChartButton;  // 从BatchesChartButton改为DrawCallChartButton

	// 当前显示的图表类型
	EChartType SelectedChartType = EChartType::FPS;

	// 按钮控件
	TSharedPtr<SButton> SelfCheckButton;
	TSharedPtr<SButton> ClearWarningsButton;

	// 性能数据（精简版）
	float CurrentFPS = 42.0f;
	int32 CurrentTris = 4000000;
	int32 CurrentDrawCalls = 1273;  // 从CurrentBatches改为CurrentDrawCalls
	int32 CurrentShadowTris = 1800000;  // Shadow Pass数据
};