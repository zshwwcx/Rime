#pragma once
#include "SeqPerformanceMonitor/MonitorTabPanel.h"
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Layout/SSplitter.h"


// 标签页类型
enum class EMonitorTabType
{
    Overview,
    Lighting,
    Effects,
    Animation,
    Rendering,
    Custom
};





// 主编辑器面板
class SPerformanceMonitorPanel : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SPerformanceMonitorPanel) {}
	SLATE_END_ARGS()

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime);

	void Construct(const FArguments& InArgs);

	// 切换标签页
	void SwitchTab(int32 TabIndex);

	void OnActivated();
	void OnClosed();

	// 刷新所有数据
	void RefreshAllData();

private:
	// 当前激活的标签页索引
	int32 ActiveTabIndex;

	// 所有标签页
	TArray<TSharedPtr<SMonitorTabPanel>> TabPanels;

	// 标签页切换器
	TSharedPtr<SWidgetSwitcher> TabSwitcher;

	// 标签按钮数组（用于高亮当前选中标签）
	TArray<TSharedPtr<SButton>> TabButtons;

	FPerfData PerfData;

	// 创建标签按钮
	TSharedRef<SWidget> CreateTabButton(const FString& TabName, int32 TabIndex);
};