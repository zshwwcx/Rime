#pragma once

#include "CoreMinimal.h"
#include "EditorSubsystem.h"
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"


#include "PMSubSystem.generated.h"

UCLASS(Blueprintable, BlueprintType)
class UPMSubSystem : public UEditorSubsystem
{
	GENERATED_BODY()

public:
};



struct FPerfData
{
	double StartTime = 0.0;
	double Time = 0.0;
	int32 FPS = 0;
	int64 FrameIndex = 0;
	float FrameTime = 0.0f;
	float GameThreadTime = 0.0f;
	float RenderThreadTime = 0.0f;
	float RHIThreadTime = 0.0f;
	float GPUTime = 0.0f;
	int BatchNum = 0;
	int64 TrianglesNum = 0;
	int64 StaticMeshTriangles = 0;
	int32 DrawCalls = 0;

	int32 NumLights = 0;
	int32 NumShadowedLights = 0;
	float LightComplexityAvg = 0;



	FName GroupName_STATGROUP_Engine = FName(TEXT("STATGROUP_Engine"));
	FName StatName_STAT_FrameTime = FName(TEXT("STAT_FrameTime"));
	FName STAT_RHITickTime = FName(TEXT("STAT_UnitRHIT"));
	FName STAT_GameThreadTime = FName(TEXT("STAT_UnitGame"));
	FName STAT_RenderThreadTime = FName(TEXT("STAT_UnitRender"));
	FName STAT_StaticMeshTriangles = FName(TEXT("STAT_StaticMeshTriangles"));

	FName GroupName_STATGROUP_Game = FName(TEXT("STATGROUP_Game"));

	FName STATGROUP_RHI = FName(TEXT("STATGROUP_RHI"));
	FName STAT_RHITriangles = FName(TEXT("STAT_RHITriangles"));
	FName STAT_RHIDrawPrimitiveCalls = FName(TEXT("STAT_RHIDrawPrimitiveCalls"));

	FName STATGROUP_LightRendering = FName(TEXT("STATGROUP_LightRendering"));
	FName STAT_NumLightsUsingStandardDeferred = FName(TEXT("STAT_NumLightsUsingStandardDeferred"));
	FName STAT_NumShadowedLights = FName(TEXT("STAT_NumShadowedLights"));


	FName STATGROUP_DebugView = FName(TEXT("STATGROUP_DebugView"));
	FName STATGROUP_DebugView_LightComplexityAvg = FName(TEXT("STATGROUP_DebugView_LightComplexityAvg"));



public:
	void Enable();
	void Disable();

	//stat线程
	void OnStatUpdateCB(int64 frame);
	double GetCycleTimeMS(const FStatMessage& InStatMessage);

	// game thread
	static int32 CollectSequenceData(class UWorld* InWorld, TArray<AActor*>& OutLightActors);
};

