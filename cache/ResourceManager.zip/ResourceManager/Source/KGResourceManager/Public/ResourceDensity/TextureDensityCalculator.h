﻿#pragma once

#include "ResourceDensity/ResourceDensityCalculator.h"

class FTextureDensityCalculator : public FResourceDensityCalculator
{
public:
	virtual void CalculateOne(const FAssetData& AssetData) override;

	virtual UClass* GetResourceClass() override;
};