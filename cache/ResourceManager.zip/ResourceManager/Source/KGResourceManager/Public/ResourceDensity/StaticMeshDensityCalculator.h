﻿#pragma once

#include "ResourceDensity/ResourceDensityCalculator.h"

#include "StaticMeshDensityCalculator.generated.h"

UENUM()
enum class EStaticMeshDensityType:uint8
{
	Area					UMETA(DisplayName = "Area density"),
	Volume	                UMETA(DisplayName = "Volume density"),
	UVRate					UMETA(DisplayName = "UV Rate"),
	Pixel					UMETA(DisplayName = "Pixel density"),
}; 

struct FStaticMeshDensityData
{
	FString PackageName;
	FString UserName;
	bool bHasReferencedObjects = false;
	TArray<float> LodVolumeDensities;
	float VolumeDensity = 0.f;
	TArray<float> LodAreaDensities;
	float AreaDensity = 0.f;
	TArray<float> LodUVDensities;
	float UVDensity = 0.f;
	TArray<float> LodUVUtilizationRate;
	TArray<float> LodPixelDensities;
	float PixelDensity = 0.f;

	int32 Triangles = 0;

	FString ToCSVString(EStaticMeshDensityType DensityType) const;

	static FString GetCSVHeader(EStaticMeshDensityType DensityType);
};

class FStaticMeshDensityCalculator : public FResourceDensityCalculator
{
public:
	virtual UClass* GetResourceClass() override;

	virtual void CalculateOne(const FAssetData& AssetData) override;

	static float GetArea(const FStaticMeshLODResources& LODResource);

	static bool GetTrianglesAndUVArea(const UStaticMesh* StaticMesh, const FStaticMeshLODResources& LODResource, double& OutTrianglesArea, double& OutPixelNum);

	static float GetUVUtilizationRate(const UStaticMesh* StaticMesh, const FStaticMeshLODResources& LODResource);

	static bool CalculateDensity(const UStaticMesh* StaticMesh, FStaticMeshDensityData& OutDensityData);

	virtual void ExportResults() override;

	void CalculateMean();

private:
	TArray<FStaticMeshDensityData> StaticMeshDensities;

	float AreaMean = 0.f;
	float VolumeMean = 0.f;
	float UVRateMean = 0.f;
	float PixelDensityMean = 0.f;
};
