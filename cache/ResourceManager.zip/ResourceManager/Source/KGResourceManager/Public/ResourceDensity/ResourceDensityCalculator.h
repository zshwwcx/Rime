﻿#pragma once

class FResourceDensityCalculator : public TSharedFromThis<FResourceDensityCalculator>
{
public:
	virtual ~FResourceDensityCalculator() {}
	
	virtual void CalculateOne(const FAssetData& AssetData){}
	
	virtual void CalculateAll();

	virtual UClass* GetResourceClass() PURE_VIRTUAL(FResourceDensityCalculator::GetResourceClass, return UObject::StaticClass(););

	void CollectAssetsData(TArray<FAssetData>& OutAssetData);

	virtual void ExportResults();
};
