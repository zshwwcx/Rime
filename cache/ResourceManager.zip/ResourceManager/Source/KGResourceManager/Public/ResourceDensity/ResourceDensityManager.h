﻿#pragma once

class FResourceDensityManager : public TSharedFromThis<FResourceDensityManager>
{
public:

	// void CollectAllAssets();
	
	void CalculateDensity();
};
