#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"


class FKGResourceManagerModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	void RegisterMenus();

	void RegisterContentBrowserSubMenus(UToolMenu* InMenu);
	void RegisterSceneOutlinerSubMenus(UToolMenu* InMenu);

	void RegisterCollisionSetSubMenus(UToolMenu* InMenu);



	void RegisterSeqPerfSubMenus(UToolMenu* InMenu);
	void OnOpenPerformanceMonitor();
	TSharedRef<SDockTab> SpawnPerformanceMonitorTab(const FSpawnTabArgs& SpawnTabArgs);

	void OnPerformanceMonitorTabClosed(TSharedRef<SDockTab> ClosedTab);
	void OnPerformanceMonitorTabActivated(TSharedRef<SDockTab> ActivatedTab);

	private:
		// 新增性能监控相关成员
		TSharedPtr<FExtender> PerformanceMenuExtender;
		TSharedPtr<SDockTab> PerformanceMonitorTab;
};

