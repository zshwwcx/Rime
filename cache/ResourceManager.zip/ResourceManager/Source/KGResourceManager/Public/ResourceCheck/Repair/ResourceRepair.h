﻿#pragma once

#include "CoreMinimal.h"


struct FResourceRepairData
{
	FAssetData RepairAssetData;
	bool bPropertyAutoRepair;
	FString RepairFunctionName;
	TMap<FString, FString> RepairParameters;

	FResourceRepairData()
	{
		bPropertyAutoRepair = false;
		RepairFunctionName = "";
		RepairParameters.Empty();
	}

	FResourceRepairData(FAssetData InAssetData, FString InFunctionName, const TMap<FString, FString>& InRepairParameters)
	{
		RepairAssetData = InAssetData;
		bPropertyAutoRepair = false;
		RepairFunctionName = InFunctionName;
		RepairParameters = InRepairParameters;
	}

	FResourceRepairData(FAssetData InAssetData, const TMap<FString, FString>& InRepairParameters)
	{
		RepairAssetData = InAssetData;
		bPropertyAutoRepair = true;
		RepairFunctionName = "";
		RepairParameters = InRepairParameters;
	}
};


struct FResourceRepairPending
{
	TArray<FResourceRepairData> RepairDatas;
};