// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ResourceCheck/Log/ResourceCheckLogCollect.h"
#include "ResourceManagerWidget.generated.h"

UCLASS()
class UResourceManagerWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	void AddMessage(const FResourceCheckLogInfo& InLogInfo);
	virtual void NativeConstruct() override;
	UFUNCTION()
	void OnClearRightBtnClick() const;
	UFUNCTION()
	void OnAutoFixBtnClick() const;
	UFUNCTION()
	void OnAutoSaveBtnClick() const;

	void RemoveAllMessages();
};
