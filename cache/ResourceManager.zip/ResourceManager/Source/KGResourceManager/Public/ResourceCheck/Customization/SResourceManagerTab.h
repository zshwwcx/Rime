#pragma once 

#include "CoreMinimal.h"

#include "Templates/SharedPointer.h"
#include "IDetailsView.h"
#include "PropertyEditorModule.h"
#include "ResourceCheck/Log/ResourceCheckLogCollect.h"

class SResourceManagerTab : public SCompoundWidget
{
public:

	SLATE_BEGIN_ARGS(SResourceManagerTab) { }
	SLATE_END_ARGS()

public:

	/**
	 * Constructs the widget.
	 *
	 * @param InArgs The Slate argument list.
	 */
	void Construct(	const FArguments& InArgs);

public:
	void AddMessage(const FResourceCheckLogInfo& InLogInfo);

	void RemoveAllMessages();

private:
	TSharedPtr<SWidget> BaseWidget;
	TWeakObjectPtr<class UUserWidget> MessageWidget;
};