// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ResourceCheck/Log/ResourceCheckLogCollect.h"
#include "ResourceManagerSingleWidget.generated.h"

UCLASS()
class UResourceManagerSingleWidget final : public UUserWidget
{
	GENERATED_BODY()

public:
	void SetSelectedObj(const FResourceCheckLogInfo& InLogInfo);

	void SetState(const FResourceCheckLogInfo& InLogInfo);

private:
	virtual void NativeConstruct() override;

	UFUNCTION()
	void OnAssetLinkBtnClick();

	bool bPass = false;
	
	FString AssetPackageName;

	friend class UResourceManagerWidget;
};
