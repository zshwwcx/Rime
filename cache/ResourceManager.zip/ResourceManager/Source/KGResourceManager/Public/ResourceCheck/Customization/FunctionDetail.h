// Copyright Kuaishou, Inc. All Rights Reserved.

#pragma once

#include "IPropertyTypeCustomization.h"
#include "IDetailCustomization.h"
#include "CoreMinimal.h"
#include "Widgets/Layout/SBox.h"

class FFunctionDetails : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FFunctionDetails);
	}

	virtual void CustomizeHeader(TSharedRef<class IPropertyHandle> StructPropertyHandle, class FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<class IPropertyHandle> StructPropertyHandle, class IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils) override;

private:
	TSharedRef<SWidget> HandleGenerateWidgetForFunctionNameComboBox(TSharedPtr<FString> Item) const;
	void HandleSelectionChangedForFunctionNameComboBox(TSharedPtr<FString> Item, ESelectInfo::Type SelectionType);
	bool IsFunctionHasCurrentInputAndOutput(UFunction* Function);

private:
	TSharedPtr<IPropertyHandle> FunctionNameHandle;

	TArray<TSharedPtr<FString>> FunctionNames;
	
	// StaticClass
	TWeakObjectPtr<const UClass> AssetCLass = nullptr;

	IDetailChildrenBuilder* PropertyDetailBuilder;

	TArray<TSharedPtr<FString>> AllFunctionNames;
	
	TSharedPtr<SBox> AllFunctionNameSelectorBox;
	TSharedPtr<SComboBox<TSharedPtr<FString>>> AllFunctionNameSelector;
	TSharedPtr<SBox> FunctionNameComboContent;
	
};