// Copyright Kuaishou, Inc. All Rights Reserved.

#pragma once

#include "IPropertyTypeCustomization.h"
#include "CoreMinimal.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"

class FCustomPropertyDetails : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FCustomPropertyDetails);
	}

	virtual void CustomizeHeader(TSharedRef<class IPropertyHandle> StructPropertyHandle, class FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<class IPropertyHandle> StructPropertyHandle, class IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils) override;

private:
	
	TSharedRef<SWidget> HandleGenerateWidgetForPropertyNamesComboBox(TSharedPtr<FString> Item) const;
	void HandleSelectionChangedForPropertyNamesComboBox(TSharedPtr<FString> Item, ESelectInfo::Type SelectionType);
	void HandleSelectionChangedForPropertyGetterFuncNameComboBox(TSharedPtr<FString> Item, ESelectInfo::Type SelectionType);
	void HandleSelectionChangedForStandardGetterFuncNameComboBox(TSharedPtr<FString> Item, ESelectInfo::Type SelectionType);
	
	void OnPropertyValueChanged();
	void ChangePropertyAndStandardType();
	
private:
	TSharedPtr<IPropertyHandle> PropertyNameHandle;
	TSharedPtr<IPropertyHandle> PropertyGetterFuncHandle;
	TSharedPtr<IPropertyHandle> StandardParamHandle;
	TSharedPtr<IPropertyHandle> StandardValueHandle;
	TSharedPtr<IPropertyHandle> StandardValueGetterFuncHandle;

	TArray<TSharedPtr<FString>> AllPropertyNames;
	TArray<TSharedPtr<FString>> AllFuncNames;
	
	// StaticClass
	TWeakObjectPtr<const UClass> AssetCLass = nullptr;

	IDetailChildrenBuilder* PropertyDetailBuilder;

	TSharedPtr<SBox> AllPropertySelectorBox;
	TSharedPtr<SComboBox<TSharedPtr<FString>>> AllPropertySelector;
	TSharedPtr<SBox> PropertyNameComboContent;
	TSharedPtr<SBox> StandardValueContent;
	TSharedPtr<SBox> AllFuncSelectorBox;
	TSharedPtr<SComboBox<TSharedPtr<FString>>> AllFuncSelector;
	TSharedPtr<SBox> StandardParamContent;
	TSharedPtr<SBox> PropertyFuncNameComboContent;
	TSharedPtr<SBox> StandardFuncNameComboContent;

	TSharedPtr<STextBlock> NowPropertyTypeText;
	TSharedPtr<STextBlock> NowStandardTypeText;
	
	TSharedPtr<IPropertyHandle> CurrentPropertyHandle;
	//class IDetailPropertyRow* OldPropertyRow;
};