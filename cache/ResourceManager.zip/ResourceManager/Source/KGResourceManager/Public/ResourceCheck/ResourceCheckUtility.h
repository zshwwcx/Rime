#pragma once

#include "ResourceCheck/ResourceCheckWebStruct.h"

#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "JsonUtilities.h"
#include "CoreMinimal.h"
#include "HttpManager.h"
#include "AssetRegistry/AssetRegistryModule.h"

class FResourceCheckUtility
{
public:
	using FRMJsonResponseCallback = TFunction<void(const FRMJsonResponse&)>;
	using GetWebRulesCallback = TFunction<void(const FRMResCheckData&)>;
	using SendReportFinishCallback = TFunction<void()>;


	// 解析 JSON 字符串到指定类型
	template<typename T>
	static T ParseJsonFromString(const FString& JsonString)
	{
		T Result;

		TSharedPtr<FJsonObject> JsonObject;

		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);

		if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
		{
			FJsonObjectConverter::JsonObjectToUStruct(JsonObject.ToSharedRef(), &Result, 0, 0);
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("Failed to parse JSON, JsonString: %s"), *JsonString);
		}

		return Result;
	}


	template <typename T>
	static void GetDependedTypeAssets(TArray<UObject*> DependedAssets,
		TArray<T*>& DependedAssetArray, int& IterationCount)
	{
		IterationCount++;
		if (IterationCount > 3)
		{
			IterationCount--;
			return;
		}
		for (int32 i = 0; i < DependedAssets.Num(); ++i)
		{
			UObject* DependedAsset = DependedAssets[i];
			if (T* Asset = Cast<T>(DependedAsset))
			{
				if (!DependedAssetArray.Contains(Asset))
				{
					DependedAssetArray.Add(Asset);
				}
			}
			else
			{
				GetDependedTypeAssets<T>(GetDependedAssets(DependedAsset), DependedAssetArray, IterationCount);
			}
		}
		IterationCount--;
	}


	// 获取指定资产依赖的资源
	static TArray<UObject*> GetDependedAssets(const UObject* ParentObject)
	{
		const FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>(
			"AssetRegistry");
		TArray<FName> AssetDependencies;
		TArray<UObject*> DependedAssets;
		const FName Name = ParentObject->GetPackage()->GetFName();
		AssetRegistryModule.Get().GetDependencies(Name, AssetDependencies, UE::AssetRegistry::EDependencyCategory::All);
		for (int32 i = 0; i < AssetDependencies.Num(); ++i)
		{
			TArray<FAssetData> OutAssetData;
			AssetRegistryModule.Get().GetAssetsByPackageName(AssetDependencies[i], OutAssetData);
			if (!OutAssetData.IsEmpty())
			{
				UObject* AssetInPackage = OutAssetData[0].GetAsset();
				DependedAssets.Add(AssetInPackage);
			}
		}
		return DependedAssets;
	}


	// web 相关的操作 {{
	static void InitRuleDataFromWeb(FEvent* RuleReadyEvent, FRMJsonResponseCallback Callback)
	{
		FString Url = "https://c7-qatool.staging.kuaishou.com/api/artCheck/openProject/ueNew?projectId=1";

		// Create the HTTP request
		TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
		Request->SetVerb("GET");
		Request->SetURL(Url);
		Request->SetHeader(TEXT("Accept"), TEXT("application/json"));

		// Define the response handler
		Request->OnProcessRequestComplete().BindLambda([Callback](FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded)
			{
				if (bSucceeded && HttpResponse.IsValid() && EHttpResponseCodes::IsOk(HttpResponse->GetResponseCode()))
				{
					// Parse the JSON response
					FRMJsonResponse JsonResponse = ParseJsonFromString<FRMJsonResponse>(HttpResponse->GetContentAsString());
					Callback(JsonResponse);
				}
				else
				{
					UE_LOG(LogTemp, Error, TEXT("HTTP request failed"));
					FRMJsonResponse EmptyResponse;
					Callback(EmptyResponse);
				}
			});

		// Send the request
		Request->ProcessRequest();

		while (!RuleReadyEvent->Wait(100))
		{
			FHttpModule::Get().GetHttpManager().Tick(0.1);
		}
		RuleReadyEvent->Reset();
	}

	static bool CreateProjectReport(const TArray<FRMRuleReport>& RuleReportList)
	{
		FRMProjectReport ProjectReport;

		ProjectReport.BranchName = "";
		ProjectReport.ProjectId = 0;
		ProjectReport.ProjectRuleGroupNum = 0;
		ProjectReport.TotalCheckAssetCount = 0;

		// 统计下总的检查资源数量
		for (const FRMRuleReport& RuleReport : RuleReportList)
		{
			ProjectReport.TotalCheckAssetCount += RuleReport.CheckAssetCount;
		}

		// 生成一个随机的UniqueKey
		ProjectReport.UniqueKey = FGuid::NewGuid().ToString(EGuidFormats::DigitsWithHyphensInBraces) + FString::FromInt(FDateTime::UtcNow().ToUnixTimestamp() * 1000);
		ProjectReport.RuleReportList = RuleReportList;

		// 将 FProjectReport 实例转换为 JSON 字符串
		FString JsonString;
		const bool bJsonStringOk = FJsonObjectConverter::UStructToJsonObjectString(ProjectReport, JsonString);

		if (!bJsonStringOk)
		{
			UE_LOG(LogTemp, Error, TEXT("Failed to convert FProjectReport to JSON"));
			return false;
		}

		// 将 JsonString 保存到 Client/Save/KGReourceCheck/Report.json 文件中, 如果文件存在则覆盖
		FString SaveDir = FPaths::ProjectSavedDir() / TEXT("ResourceCheck");
		FString SavePath = SaveDir / TEXT("Report.json");

		if (!FPaths::DirectoryExists(SaveDir))
		{
			FPlatformFileManager::Get().GetPlatformFile().CreateDirectoryTree(*SaveDir);
		}

		if (!FFileHelper::SaveStringToFile(JsonString, *SavePath))
		{
			UE_LOG(LogTemp, Error, TEXT("Failed to save JSON to file: %s"), *SavePath);
			return false;
		}

		return true;
	}
};
