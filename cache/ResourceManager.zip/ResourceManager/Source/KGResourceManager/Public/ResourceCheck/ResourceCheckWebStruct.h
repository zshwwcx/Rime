#pragma once

#include "CoreMinimal.h"
#include "ResourceCheckWebStruct.generated.h"

// 获取资源检查数据的结构体{{
USTRUCT(BlueprintType)
struct FRMResCheckData
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite)
	int32 CategoryId;

	UPROPERTY(BlueprintReadWrite)
	FString CategoryName;

	UPROPERTY(BlueprintReadWrite)
	FString CheckPath;

	UPROPERTY(BlueprintReadWrite)
	FString CustomParam;

	UPROPERTY(BlueprintReadWrite)
	FString Description;

	UPROPERTY(BlueprintReadWrite)
	int32 Id;

	UPROPERTY(BlueprintReadWrite)
	TMap<FString, FString> ParamList;

	UPROPERTY(BlueprintReadWrite)
	int32 ProjectId;

	UPROPERTY(BlueprintReadWrite)
	int32 RuleCategory;

	UPROPERTY(BlueprintReadWrite)
	FString RuleFunction;

	UPROPERTY(BlueprintReadWrite)
	FString RuleName;

	UPROPERTY(BlueprintReadWrite)
	bool SourceReport;

	UPROPERTY(BlueprintReadWrite)
	bool CommitReport;

	UPROPERTY(BlueprintReadWrite)
	FString RuleJson;
	
	UPROPERTY(BlueprintReadWrite)
	FString TemplateName;
};

USTRUCT(BlueprintType)
struct FRMJsonResponse
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadWrite)
    int32 Code;

    UPROPERTY(BlueprintReadWrite)
    TArray<FRMResCheckData> Data;

    UPROPERTY(BlueprintReadWrite)
    FString Msg;

    UPROPERTY(BlueprintReadWrite)
    int64 ServerTimestamp;

    UPROPERTY(BlueprintReadWrite)
    bool Success;
};
// 获取资源检查数据的结构体}}


// 上报结果用的结构体{{
USTRUCT(BlueprintType)
struct FRMReportDetail
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite)
	TArray<FString> ParamContentDetail;

	UPROPERTY(BlueprintReadWrite)
	FString Resource;
};

USTRUCT(BlueprintType)
struct FRMRuleReport
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite)
	int32 CheckAssetCount;

	UPROPERTY(BlueprintReadWrite)
	int CheckPass;

	UPROPERTY(BlueprintReadWrite)
	TArray<FString> DetailParam;

	UPROPERTY(BlueprintReadWrite)
	int32 ProjectRuleConfigId;

	UPROPERTY(BlueprintReadWrite)
	TArray<FRMReportDetail> ReportDetailList;
};

USTRUCT(BlueprintType)
struct FRMProjectReport
{
	GENERATED_BODY()
	
	UPROPERTY(BlueprintReadWrite)
	FString BranchName;

	UPROPERTY(BlueprintReadWrite)
	FString Extend;

	UPROPERTY(BlueprintReadWrite)
	int32 ProjectId;

	UPROPERTY(BlueprintReadWrite)
	int32 ProjectRuleGroupNum;

	UPROPERTY(BlueprintReadWrite)
	TArray<FRMRuleReport> RuleReportList;

	UPROPERTY(BlueprintReadWrite)
	int32 TotalCheckAssetCount;

	UPROPERTY(BlueprintReadWrite)
	FString UniqueKey;
};
// 上报结果用的结构体}}

USTRUCT(BlueprintType)
struct FRMRepairDetail
{
	GENERATED_BODY()

	UPROPERTY()
	FString RepairAssetPath;

	UPROPERTY()
	bool bPropertyAutoRepair;

	UPROPERTY()
	FString RepairFunctionName;

	UPROPERTY()
	TMap<FString, FString> RepairParameters;
};

USTRUCT(BlueprintType)
struct FRMRuleRepairData
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite)
	FString RuleName;
	
	UPROPERTY(BlueprintReadWrite)
	TArray<FRMRepairDetail> RepairDetailList;
};

USTRUCT(BlueprintType)
struct FRMRepairJsonData
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite)
	TArray<FRMRuleRepairData> RuleRepairDataList;
};