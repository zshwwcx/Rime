// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "ResourceCheck/ResourceCheckWebStruct.h"
#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "ResourceCheck/ResourceCheckDataStruct.h"
#include "PerforceSourceControlProviderDelegates.h"
#include "GenericPlatform/GenericPlatformSplash.h"
#include "ResourceCheck/Log/ResourceCheckLogCollect.h"
#include "ResourceCheck/Repair/ResourceRepair.h"
#include "RuleBase.generated.h"

struct FRMParamStruct
{
	FString GetValue(const FString Key)
	{
		FString RetValue = TEXT("None");
		if(ParamList.Contains(Key))
		{
			RetValue = ParamList[Key];
		}
		return RetValue;
	}
	TArray<FString> GetValueList(const FString Key, const FString Split = TEXT(","))
	{
		TArray<FString> RetValueList;
		if(ParamList.Contains(Key))
		{
			FString Value = ParamList[Key];
			Value.ParseIntoArray(RetValueList, *Split);
		}
		return RetValueList;
	}
	FString GetValueByTwoKey(const FString Key, const FString Key2, const FString Split = TEXT(" "))
	{
		FString RetValue = TEXT("None");
		if(ParamList.Contains(Key))
		{
			FString Value1 = ParamList[Key];
			TArray<FString> ValueList1;
			Value1.ParseIntoArray(ValueList1, *Split);
			for(auto& KeyValue : ValueList1)
			{
				TArray<FString> KeyValueList;
				KeyValue.ParseIntoArray(KeyValueList, TEXT("="));
				if(KeyValueList.Num() > 1)
				{
					if(KeyValueList[0] == Key2)
					{
						RetValue = KeyValueList[1];
					}
				}
			}
		}
		return RetValue;
	}
	TArray<FString> GetValueListByTwoKey(const FString Key, const FString Key2, const FString Split = TEXT(" "), const FString Split2 = TEXT(","))
	{
		TArray<FString> RetValueList;
		if(ParamList.Contains(Key))
		{
			FString Value1 = ParamList[Key];
			TArray<FString> ValueList1;
			Value1.ParseIntoArray(ValueList1, *Split);
			for(auto& KeyValue : ValueList1)
			{
				TArray<FString> KeyValueList;
				KeyValue.ParseIntoArray(KeyValueList, TEXT("="));
				if(KeyValueList.Num() > 1)
				{
					if(KeyValueList[0] == Key2)
					{
						KeyValueList[1].ParseIntoArray(RetValueList, *Split2);
					}
				}
			}
		}
		return RetValueList;
	}
	TMap<FString, FString> GetValueMap(const FString Key, const FString Split = TEXT(" "))
	{
		TMap<FString, FString> RetValueMap;
		if(ParamList.Contains(Key))
		{
			FString Value = ParamList[Key];
			TArray<FString> ValueList;
			Value.ParseIntoArray(ValueList, *Split);
			for(auto& KeyValue : ValueList)
			{
				TArray<FString> KeyValueList;
				KeyValue.ParseIntoArray(KeyValueList, TEXT("="));
				if(KeyValueList.Num() > 1)
				{
					RetValueMap.FindOrAdd(KeyValueList[0]) = KeyValueList[1];
				}
			}
		}
		return RetValueMap;
	}
	bool CheckValue(const FString Key, const FString Value)
	{
		if(GetValue(Key) == Value)
		{
			return true;
		}
		return false;
	}
	bool ContainValue(const FString Key, const FString Value)
	{
		if(GetValueList(Key).Contains(Value))
		{
			return true;
		}
		return false;
	}
	bool CheckValueByTwoKey(const FString Key, const FString Key2, const FString Value)
	{
		if(GetValueByTwoKey(Key, Key2) == Value)
		{
			return true;
		}
		return false;
	}
	bool ContainValueByTwoKey(const FString Key, const FString Key2, const FString Value)
	{
		if(GetValueListByTwoKey(Key, Key2).Contains(Value))
		{
			return true;
		}
		return false;
	}
	TMap<FString, FString> ParamList;
};

USTRUCT(BlueprintType)
struct FRMPropertyRuleMapping
{
	GENERATED_USTRUCT_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="属性名"))
	FString PropertyName;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="属性值获取函数"))
	FString PropertyGetterFunc;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="合法值参数"))
	FString StandardParam;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="合法值常量"))
	FString StandardValue;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="合法值获取函数"))
	FString StandardValueGetterFunc;
};

USTRUCT(BlueprintType)
struct FRMFunctionRuleMapping
{
	GENERATED_USTRUCT_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="函数名"))
	FString FunctionName;
};

USTRUCT(BlueprintType)
struct FRMRepairRuleMapping
{
	GENERATED_USTRUCT_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="修复函数"))
	FString FunctionName;
};

USTRUCT(BlueprintType)
struct FRMRule
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="规则编号"))
	FString RuleID;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="依赖条件"))
	TSet<FString> ConditionRequirements;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="依赖条件任意满足"))
	bool bAnyRequire=false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="禁止条件"))
	TSet<FString> ConditionProhibits;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="检查级别"))
	TEnumAsByte<ERMCheckRuleType> RuleType = ERMCheckRuleType::Error;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="描述"))
	FString Description;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="修复方法"))
	TEnumAsByte<ERMRepairType> RepairType=ERMRepairType::PropertyRepair;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="修复规则", EditConditionHides, EditCondition="RepairType==ERMRepairType::FunctionRepair"))
	FRMRepairRuleMapping RepairRule;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "作用分支"))
	FString RuleBranch = TEXT("");

	bool IsAutoFix = false;
};

USTRUCT(BlueprintType)
struct FRMPropertyRule : public FRMRule
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="属性规则", ShowOnlyInnerProperties))
	FRMPropertyRuleMapping RuleMapping;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="比较方法"))
	TEnumAsByte<ERMComparerType> Comparer;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="是否取反"))
	bool bInvert;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="自定义日志"))
	FString CustomLog;

	FRMRule GetParent()
	{
		FRMRule RMRule;
		RMRule.Description = Description;
		RMRule.bAnyRequire = bAnyRequire;
		RMRule.ConditionProhibits = ConditionProhibits;
		RMRule.ConditionRequirements = ConditionRequirements;
		RMRule.RepairRule = RepairRule;
		RMRule.RepairType = RepairType;
		RMRule.RuleType = RuleType;
		RMRule.RuleID = RuleID;
		RMRule.RuleBranch = RuleBranch;
		return RMRule;
	}
};

USTRUCT(BlueprintType)
struct FRMFunctionRule : public FRMRule
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="函数规则", ShowOnlyInnerProperties))
	FRMFunctionRuleMapping RuleMapping;

	FRMRule GetParent()
	{
		FRMRule RMRule;
		RMRule.Description = Description;
		RMRule.ConditionProhibits = ConditionProhibits;
		RMRule.bAnyRequire = bAnyRequire;
		RMRule.ConditionRequirements = ConditionRequirements;
		RMRule.RepairRule = RepairRule;
		RMRule.RepairType = RepairType;
		RMRule.RuleType = RuleType;
		RMRule.RuleID = RuleID;
		RMRule.RuleBranch = RuleBranch;
		return RMRule;
	}
	
};

USTRUCT(BlueprintType)
struct FRMConditionRule
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="条件规则"))
	FRMPropertyRuleMapping RuleMapping;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="比较方法"))
	TEnumAsByte<ERMComparerType> Comparer;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="是否取反"))
	bool bInvert;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="描述"))
	FString Description;
};

struct FRMPropertyRuleParams
{
	FAssetData AssetData;
	FString ReturnValue;
};

struct FRMFunctionRuleParams
{
	FAssetData AssetData;
	TMap<FString, FString> RepairParams;
	bool bSuccess;
};

struct FRMRepairRuleParams
{
	FAssetData AssetData;
	TMap<FString, FString> RepairParams;
	bool bSuccess;
};

/**
 *  检查规则基类
 */
UCLASS(BlueprintType, Blueprintable)
class KGRESOURCEMANAGER_API URuleBase : public UObject
{
	GENERATED_BODY()

public:
	// 获取对应检查项类型
	virtual UClass* GetAssetType() PURE_VIRTUAL(URuleBase::GetAssetType, return UObject::StaticClass(););

	// 初始化
	virtual void Initialize(const FRMResCheckData& Data);
	
	// 获取对象所属类型名字
	virtual FString GetRuleName() PURE_VIRTUAL(URuleBase::GetName, return TEXT("Object"););

	// CheckIn前处理
	virtual void PreCheckIn(TArray<FAssetData> InFiles, TSharedPtr<FPerforceSourceControlProviderDelegatesPackage> InPackage)
	{
		return;
	}

	// CheckIn后处理
	virtual void PostCheckIn(TArray<FAssetData> InFiles, TSharedPtr<FPerforceSourceControlProviderDelegatesPackage> InPackage)
	{
		return;
	}
	
	// 获取检查结果
	virtual FRMRuleReport GetRuleReport();
	
	// 规则预处理
	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList)
	{
		return true;
	}
	
	// 规则后处理
	virtual bool PostExecuteAllObject(TArray<FAssetData>& InAssetDataList)
	{
		return true;
	}
	
	// 单个资源预处理
	virtual bool PreExecuteAsset(const FAssetData& AssetData)
	{
		return true;
	}	
	
	// 单个资源后处理
	virtual bool PostExecuteAsset(const FAssetData& AssetData)
	{
		return true;
	}
	
	// 检查一个资源
	bool CheckOne(const FAssetData& AssetData);
	
	//执行所有规则检查
	bool CheckPropertiesAndFunctions(const FAssetData& AssetData);

	//判断资源是否符合判定规则
	bool CheckCondition(const FAssetData& AssetData, FRMRule InRule);
	
	// 执行所有Property检查
	bool CheckProperties(const FAssetData& AssetData);
		
	// 执行单Property检查
	bool CheckOneProperty(const FRMPropertyRule& PropertyRule, const FAssetData& AssetData);
	bool CheckOneProperty(const FRMConditionRule& ConditionRule, const FAssetData& AssetData);
	bool CheckOneProperty(
							FRMPropertyRuleMapping RuleMapping,
							TEnumAsByte<ERMComparerType> Comparer,
							const FAssetData& AssetData,
							FString& OutReason,
							TMap<FString, FString>& OutRepairParameters,
							bool bInvert=false
						);

	// 执行所有Property检查
	bool CheckFunctions(const FAssetData& AssetData);
	
	// 执行按规则匹配的函数检查
	bool CheckOneFunction(const FRMFunctionRule& FunctionRule, const FAssetData& AssetData);

	// 执行一次函数修复
	bool RepairOneFunction(const FAssetData& AssetData, const FString& FunctionName, const TMap<FString, FString>& InRepairParams);

	bool RepairOne(const bool& bPropertyAutoRepair, const FAssetData& AssetData, const FString& RepairFunctionName, TMap<FString, FString> RepairParameters);

	// 修复当前所有待修复
	bool RepairAllPending();

	bool RepairByJsonData(const FRMRuleRepairData& RuleRepairData, TSet<FString>& SuccessRepairAssetes, TSet<FString>& FailedRepairAssetes);

	bool HasErrorLog() const
	{
		for(auto LogInfo : Log.LogInfos)
		{
			if(LogInfo.Level == ERMCheckRuleType::Error)
			{
				return true;
			}
		}
		return false;
	}
	bool HasWarningLog() const
	{
		for(auto LogInfo : Log.LogInfos)
		{
			if(LogInfo.Level == ERMCheckRuleType::Warning)
			{
				return true;
			}
		}
		return false;
	}

	TArray<FResourceCheckLogInfo> GetLogList() const {return Log.LogInfos;}
	TArray<FString> GetLogTags() const {return Log.Tags.Array();}
	int32 GetCheckedAssetNum() {return CheckedAssetNum;}
	
	//表格导入导出
	void ImportRuleFromWeb(const FString RuleName);
	void ImportRulesFromJsonString(const FString& JsonString);
	void ExportRulesToJson(const FString InRuleName);

	// ==== Base Check Function Start ====
	UFUNCTION()
	FString GetNameEnding(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetAssetName(const FAssetData& AssetData);

	UFUNCTION()
	FString GetAssetClassName(const FAssetData& AssetData);

	UFUNCTION()
	FString GetAssetShortName(const FAssetData& AssetData);

	UFUNCTION()
	FString GetTagList(const FAssetData& AssetData);

	UFUNCTION()
	FString GetPathName(const FAssetData& AssetData);

	UFUNCTION()
	FString IsSourceControlAdd(const FAssetData& AssetData);
	
	UFUNCTION()
	FString IsSourceControlDelete(const FAssetData& AssetData);

	// 通过 lua 去检查数据
	UFUNCTION()
	bool CheckByLuaChecker(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	// 通过 lua 去修复数据
	// 缺陷：返回 true 表示修复通过，但是 lua 层可以有很多规则配置，通过就表示所有的 lua 错误规则都修复通过了，不能单独表达某一条 lua 规则通过的情况
	UFUNCTION()
	bool RepairByLuaRepairer(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

	// ==== Base Check Function End ====

	UPROPERTY(VisibleAnywhere, meta=(DisplayName="规则版本"))
	int32 RuleVersion = 0;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="条件列表"))
	TMap<FString, FRMConditionRule> Conditions;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="属性规则列表"))
	TMap<FString, FRMPropertyRule> PropertyRuleMappings;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="函数规则列表"))
	TMap<FString, FRMFunctionRule> FuncRuleMappings;
	
	UPROPERTY()
	FRMResCheckData ResCheckWebData;	// 检查项的 web 配置数据
	
	UPROPERTY()
	FRMRuleReport RuleReport;	// 检查的报告结果
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="规则依赖条件"))
	TSet<FString> RuleRequirements;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="依赖条件任意满足"))
	bool bAnyRequire;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(DisplayName="规则禁止条件"))
	TSet<FString> RuleProhibits;
	
	//Info
	int32 CheckRuleRange = 0;
	bool CanRepair = false;
	FString RuleName;
	int32 CheckedAssetNum = 0;
	FString CustomParam;	

	TArray<FString> CheckPaths;
	TArray<FString> ExpectCheckPaths;
	
	//System
	FRMParamStruct Params;
	FResourceRepairPending RepairPending;
	FResourceCheckLogCollect Log;


protected:
	
	//GC
	int32 CurrentProcess = 0;
	float MemoryUsageThreshold = 0.8;
	
	//FKGRule
	TEnumAsByte<ERMCheckRuleType> CheckRuleType = ERMCheckRuleType::Ignore;
};
