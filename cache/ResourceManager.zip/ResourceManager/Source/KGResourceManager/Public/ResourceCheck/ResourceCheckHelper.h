#pragma once
#include "ResourceCheck/ResourceCheckWebStruct.h"
#include "ResourceCheck/RuleBase.h"

class FResourceCheckHelper
{
public:
	static FString GetPropertyValueByName(const FAssetData& InAssetData, const FString& PropertyName, bool bLoad = true);

	static void GetAssetEditorTags(const FAssetData& InAssetData, TArray<FString>& OutTags);

	static bool HasTag(const FAssetData& InAssetData, const FString& InTag);
	static FString GetEditorTagContent(const FAssetData& InAssetData);

	static void GetAssetDataByPackageName(const FString& PackageName, TArray<FAssetData>& OutAssetData);
	
	static void GetRuleFunctionFromWeb(TArray<FRMResCheckData>& OutResCheckData);

	static URuleBase* CreateRule(const FRMResCheckData& Data);

	static FString GetBranchName(const FString InWorkspace);

	static void AddTagInAssetes(TArray<FAssetData>& AssetDatas, FName Tag);
	static void RemoveTagInAssetes(TArray<FAssetData>& AssetDatas, FName Tag);
	static bool HasTagInAssetes(TArray<FAssetData>& AssetDatas, FName Tag);
	static bool HasNotTagInAssetes(TArray<FAssetData>& AssetDatas, FName Tag);

	static FString GetAbsoultePath(const FAssetData& AssetData);

	static UObject* GetHistoryObject(const FString& InPackagePath, const FString& InPackageName);
};
