#pragma once

//SpriteAssetRule

class FResourceCheckGlobalData
{
public:
	static void StartupSubsystem();

	static void LoadSpriteAssetRuleLuaDatas();

	static TArray<FString> SpriteAssetRuleLuaDatas;
};
