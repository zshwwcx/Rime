// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Lua/LuaEnv.h"
#include "ResourceCheckLuaObj.generated.h"

/**
 * 
 */
UCLASS()
class KGRESOURCEMANAGER_API UResourceCheckLuaObj : public UEditorLuaGameInstanceBase
{
	GENERATED_BODY()

public:
	virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Editor.ResourceCheck.ResourceCheckLuaObj"); }

	UFUNCTION(BlueprintImplementableEvent)
	void Inner_OnStart();

	UFUNCTION(BlueprintImplementableEvent)
	TArray<FString> DoDataCheck(const TArray<UObject*>& CheckObjects, TMap<FString, FString>& OutRepairParams);

	UFUNCTION(BlueprintImplementableEvent)
	bool DoDataRepair(UObject* RepairObject, const TMap<FString, FString>& Arguments);
};
