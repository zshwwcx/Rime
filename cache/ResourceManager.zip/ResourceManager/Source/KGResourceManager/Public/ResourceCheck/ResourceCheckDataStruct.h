#pragma once

UENUM()
enum ERMCheckRuleType
{
	Ignore				UMETA(DisplayName = "关闭"),
	Info				UMETA(DisplayName = "统计"),
	Warning				UMETA(DisplayName = "警告但不拦截"),
	Error				UMETA(DisplayName = "拦截")
};

UENUM()
enum ERMComparerType
{
	Equal					UMETA(DisplayName = "等于"),
	NotEqual				UMETA(DisplayName = "不等于"),
	GreaterThanOrEqualTo	UMETA(DisplayName = "大于等于"),
	LessThanOrEqualTo		UMETA(DisplayName = "小于等于"),
	Interval				UMETA(DisplayName = "区间(需要指定两个数值用,隔开)"),
	PowerOf					UMETA(DisplayName = "幂次"),
	DividedBy				UMETA(DisplayName = "整除"),
	Included				UMETA(DisplayName = "属于"),
	Include					UMETA(DisplayName = "包含"),
	Contained				UMETA(DisplayName = "属于字符串"),
	Contain					UMETA(DisplayName = "包含字符串"),
	StartsWith				UMETA(DisplayName = "字符串以...开头"),
	EndsWith				UMETA(DisplayName = "字符串以...结尾")
};

UENUM()
enum ERMCheckRuleRange
{
	ResourceCheck = 1			UMETA(DisplayName = "资源检查"),
	SubmitCheck = 2				UMETA(DisplayName = "提交检查")
};


UENUM()
enum ERMRepairType
{
	PropertyRepair			UMETA(DisplayName = "属性自动修复"),
	FunctionRepair			UMETA(DisplayName = "函数自动修复")
};