// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Commandlets/ResavePackagesCommandlet.h"
#include "ResourceCheckCommandlet.generated.h"

/**
 * 
 */
UCLASS()
class KGRESOURCEMANAGER_API UResourceCheckCommandlet : public UResavePackagesCommandlet
{
	GENERATED_BODY()

public:
	UResourceCheckCommandlet();

	virtual int32 Main(const FString& Params) override;
};


UCLASS()
class KGRESOURCEMANAGER_API UResourceRepairCommandlet : public UResavePackagesCommandlet
{
	GENERATED_BODY()

public:
	UResourceRepairCommandlet();

	virtual int32 Main(const FString& Params) override;
};
