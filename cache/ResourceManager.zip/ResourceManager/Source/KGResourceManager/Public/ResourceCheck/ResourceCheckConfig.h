﻿#pragma once


class FResourceCheckConfig
{
public:
	static FString SkipCheckTag;
	static FString HighTag;
	static FString BlueprintRulePath;
	static FString WBPResourceManagerWidget;
	static FString WBPResourceManagerSingleWidget;
};