﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "MaterialInstanceRule.generated.h"

/**
 * 
 */
UCLASS()
class KGRESOURCEMANAGER_API UMaterialInstanceRule : public URuleBase
{
	GENERATED_BODY()
	
	virtual UClass* GetAssetType() override;

	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;

	virtual FString GetRuleName() override {return TEXT("MaterialInstance");};

	UFUNCTION()
	bool CheckRelayMaterialInstance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMaterialInstanceParent(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMaterialInstanceParentIsMR(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	static bool IsLandScapeMaterial(const UMaterial* InMaterial, const TArray<FString>& LandScapeFunctionNames);

	UFUNCTION()
	bool CheckRVTMaterialInstance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairRVTMaterialInstance(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	UFUNCTION()
	bool SubmitCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	static TArray<FAssetData> GetReferencedClassAssetDatas(const FAssetData& AssetData, const UClass* InClass);

	UFUNCTION()
	bool CheckUsedWithSkeletalMesh(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckUsedWithNanite(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	TArray<FString> RelayMaterialPath; 
	TMap<FString, FString> ParentDirToMaterialInstancePrefix; 
};
