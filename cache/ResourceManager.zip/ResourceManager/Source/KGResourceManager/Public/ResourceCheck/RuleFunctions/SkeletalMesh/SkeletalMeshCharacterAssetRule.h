// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/SkeletalMesh.h"
#include "ResourceCheck/RuleFunctions/SkeletalMesh/SkeletalMeshAssetRule.h"
#include "SkeletalMeshCharacterAssetRule.generated.h"


UCLASS()
class KGRESOURCEMANAGER_API USkeletalMeshCharacterAssetRule : public USkeletalMeshAssetRule
{
	GENERATED_BODY()

public:
	virtual FString GetRuleName() override {return TEXT("SkeletalMeshCharacter");}

	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;

	TArray<float> GetStats(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStatTriangles(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStatDrawCall(const FAssetData& AssetData);
	
	int32 GetTagIndex(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandardTriangles(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandardDrawCall(const FAssetData& AssetData);

	static void InitializeTagClient();

	static bool bTagClientInitialized;
};
