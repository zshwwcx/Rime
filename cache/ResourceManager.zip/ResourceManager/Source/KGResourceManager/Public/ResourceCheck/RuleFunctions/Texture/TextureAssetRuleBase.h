// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "TextureAssetRuleBase.generated.h"

USTRUCT()
struct FRMTextureAssetInfo
{
	GENERATED_BODY()
	
};

USTRUCT(BlueprintType)
struct FRMCompressionSettingArray
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSet<TEnumAsByte<TextureCompressionSettings>> Data;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<TextureCompressionSettings> HighCompressionSetting;
};
/**
 * 
 */
UCLASS(Blueprintable, BlueprintType)
class KGRESOURCEMANAGER_API UTextureAssetRuleBase : public URuleBase
{
	GENERATED_BODY()

public:

	virtual UClass* GetAssetType() override;
	virtual FString GetRuleName() override {return TEXT("Texture");}
	bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;
	bool PreExecuteAsset(const FAssetData& InAssetData) override;
	
	UFUNCTION()
	FString GetMaxInGameSize(const FAssetData& AssetData);

	UFUNCTION()
	bool RepairMaxInGame(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	FString GetImportedSize(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetCompressionSettingStandard(const FAssetData& AssetData);

	UFUNCTION()
	bool ImportPathInfixCheck(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	FString CheckRegexFaceOld(const FAssetData& AssetData);

	UFUNCTION()
	FString IsTextureCube(const FAssetData& AssetData);

	UFUNCTION()
	FString IsInHighPrecisionGroupWhiteList(const FAssetData& AssetData);

protected:
	
	TMap<FString, TSet<TEnumAsByte<TextureCompressionSettings>>> CompressionSettingsEnum;
	TMap<FString, TEnumAsByte<TextureCompressionSettings>> HighCompressionSettingsEnum;
	TArray<FString> UITextureImportPath;
	FString MFLandscapePath;
	TArray<FString> HighPrecisionGroupWhiteList;
};
