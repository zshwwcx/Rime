// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: huxingjian03@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "BlueprintActionDatabaseRegistrar.h"
#include "BlueprintNodeSpawner.h"
#include "UObject/ObjectMacros.h"
#include "Engine/EngineTypes.h"
#include "NiagaraComponentPool.h"
#include "NiagaraCommon.h"
#include "VectorVM.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "Particles/ParticleSystemComponent.h"
#include "K2Node.h"	// BlueprintGraph
#include "KismetCompiler.h"	// KismetCompiler
#include "EdGraph/EdGraph.h"	// Engine
#include "EdGraph/EdGraphPin.h"	// Engine
#include "EdGraphSchema_K2.h"	// BlueprintGraph
#include "K2Node_CallFunction.h"	// BlueprintGraph
#include "Stats/StatsData.h" // Stats
#include "Kismet/GameplayStatics.h"  // Stats
#include "Misc/FileHelper.h"  // File

#include "NiagaraEmitter.h"
#include "NiagaraRendererProperties.h"
#include "NiagaraLightRendererProperties.h"
#include "NiagaraEmitterHandle.h"
#include "NiagaraScriptSource.h"
#include "NiagaraEditorUtilities.h"
#include "NiagaraMeshRendererProperties.h"
#include "NiagaraSettings.h"
#include "NiagaraSpriteRendererProperties.h"
#include "ViewModels/Stack/NiagaraStackFunctionInput.h"
#include "ViewModels/Stack/NiagaraStackModuleItem.h"
#include "ViewModels/Stack/NiagaraStackRendererItem.h"
#include "ViewModels/Stack/NiagaraStackViewModel.h"

#include "Animation/AnimCurveTypes.h" // Anim
#include "Animation/AnimEnums.h"
#include "Animation/AnimMetaData.h"
#include "Animation/AnimTypes.h"
#include "Animation/SmartName.h"
#include "AnimationGraph.h"
#include "Containers/Array.h"
#include "Containers/EnumAsByte.h"
#include "Delegates/Delegate.h"
#include "Math/Color.h"
#include "Math/Quat.h"
#include "Math/Transform.h"
#include "Math/UnrealMathSSE.h"
#include "Templates/SubclassOf.h"
#include "UObject/NameTypes.h"
#include "UObject/UObjectGlobals.h"
#include "UObject/WeakObjectPtr.h"
#include "NiagaraAnimNotifies/Public/AnimNotify_PlayNiagaraEffect.h"
#include "NiagaraAnimNotifies/Public/AnimNotifyState_TimedNiagaraEffect.h"
#include "3C/Animation/AnimNotify/AnimNotifyState_C7TimedNiagaraEffect.h"
#include "3C/Effect/KGNiagaraScore.h"
#include "NiagaraEditorTools.h"

#include "Tickable.h"
#include "UObject/Object.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameFramework/Actor.h"
#include "USDValueConversion.h"
#include "Engine/AssetManager.h"

#include "NiagaraComponent.h"
#include "NiagaraSystemInstance.h"
#include "NiagaraSystemInstanceController.h"
#include "NiagaraActor.h"
#include "UObject/ConstructorHelpers.h"
#include "Engine/Texture2D.h"
#include "Components/ArrowComponent.h"
#include "Components/BillboardComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "ScenePrivate.h"
#include "KGViewModes/DebugViewSceneDataWrapper.h"
#include "KGViewModes/DebugViewSceneDataStats.h"
#include "Scalability.h"
#include "Engine/EngineBaseTypes.h"
#include "UObject/SavePackage.h"
#include "PackageTools.h"

#if WITH_EDITOR
#include "NiagaraEmitterEditorData.h" // NiagaraEditor Module
#include "EditorLevelLibrary.h"
#include "Subsystems/EditorActorSubsystem.h"
#endif // WITH_EDITOR

#include "NSAssetChecker.generated.h"

#pragma region FNSAssetCheckerUtils
class FNSAssetCheckerUtils
{
#if WITH_EDITOR
public:

	// UE已有的Stat相关蓝图接口拿不到CountersAggregate类型的Stat数据，因此在此补充一个蓝图接口
	static double GetStatCounter(UObject* WorldContextObject, FName StatGroupName, FName StatName);
	// UE里的Stat Niagara无法分别获取GPU粒子和CPU粒子的数量，NiagaraDebugHUD.h相关API又为Private。因此在这里模仿之，单独写一个方法。
	static void GetNiagaraNumParticles(UObject* WorldContextObject, int32& CPUParticlesNum, int32& GPUParticlesNum, int32& CPUEmittersNum, int32& GPUEmittersNum);


	// UE竟然没有文本文件读写相关的蓝图接口，因此在这补充几个基础的
	static bool SaveStringToFile(const FString& StringContent, const FString& FilePath);
	static bool SaveStringArrayToFile(const TArray<FString>& StringArrayContent, const FString& FilePath);
	static bool LoadFileToString(FString& StringContent, const FString& FilePath);
	static bool LoadFileToStringArray(TArray<FString>& StringArrayContent, const FString& FilePath);

	// Animation Notify 相关
	// UE 原本只有 GetAnimationNotifyEvent 接口，只能获取到 FAnimNotifyEvent 结构体，无法更进一步获取到 UAnimNotify 类。因此添加此接口。
	static UAnimNotify* GetAnimationNotifyEvent_AnimNotify(const FAnimNotifyEvent& NotifyEvent);
	// UE 原本只有 GetAnimationNotifyEvent 接口，只能获取到 FAnimNotifyEvent 结构体，无法更进一步获取到 UAnimNotifyState 类。因此添加此接口。
	static UAnimNotifyState* GetAnimationNotifyEvent_AnimNotifyState(const FAnimNotifyEvent& NotifyEvent);
	// FAnimNotifyEvent 没有接口获取到其所在的 Track Index 和名称。因此添加此接口。
	static void GetAnimationNotifyEvent_TrackNameIndex(const UAnimSequenceBase* AnimationSequenceBase, const FAnimNotifyEvent& NotifyEvent, 
		FName& TrackName, int& TrackIndex);
	// UAnimNotify_PlayNiagaraEffect 没有接口获取到相关参数。因此添加此接口。
	static void GetProperty_UAnimNotify_PlayNiagaraEffect(const UAnimNotify_PlayNiagaraEffect* AnimNotify,
		UNiagaraSystem*& NSTemplate, FVector& LocationOffset, FRotator& RotationOffset, FVector& Scale, bool& bAbsoluteScale, FName& SocketName);
	// UAnimNotifyState_TimedNiagaraEffect 没有接口获取到相关参数。因此添加此接口。
	static void GetProperty_UAnimNotifyState_TimedNiagaraEffect(const UAnimNotifyState_TimedNiagaraEffect* AnimNotify,
		UNiagaraSystem*& NSTemplate, FVector& LocationOffset, FRotator& RotationOffset, FName& SocketName);
	// UAnimNotifyState_C7TimedNiagaraEffect 没有接口设置相关参数。因此添加此接口。
	static void SetProperty_UAnimNotifyState_C7TimedNiagaraEffect(UAnimNotifyState_C7TimedNiagaraEffect* AnimNotify,
		const UNiagaraSystem* NSTemplate, const FTransform& Transform, bool bAbsoluteScale, FName SocketName);

	// 母材质光照设置修改相关
	// 判断一个材质是否是 SurfacePerPixelLighting
	static bool Is_SurfacePerPixelLighting(UMaterial* Mat); 
	// 将一个材质的光照模式修改为 TLMSurface
	static void Change_TranslucencyLightingMode_To_VolumetricDirectional(UMaterial* MatIn, UMaterial*& MatRet);

	// Niagara System 相关
	// 判断一个 NS 里是否有激活的 Light Renderer
	static bool Niagara_HasActiveLightRenderer(const UNiagaraSystem* NiagaraSystem);
	// 判断一个 Emitter 是否有不被杀死的 Loop 粒子泄露 // 用于 CI 检测，没有暴露对应的蓝图节点 
	static bool Niagara_IsEmitterLoopLeaking(const UNiagaraSystem* NiagaraSystem, const FVersionedNiagaraEmitter& Emitter, 
		bool& bSpawnRate, bool& bInfiniteParticle, bool& bInfiniteEmitter, bool& bInfiniteNiagara);
	// 判断一个 Emitter 是否循环 // 用于 CI 检测，没有暴露对应的蓝图节点 
	static bool Niagara_IsEmitterLooping(const UNiagaraSystem* NiagaraSystem, const FVersionedNiagaraEmitter& Emitter);
	// 判断一个 NS 是否有不被杀死的 Loop 粒子泄露
	static bool Niagara_HasLoopLeak(const UNiagaraSystem* NiagaraSystem);
	// 判断一群 NS 是否有不被杀死的 Loop 粒子泄露
	static void Niagaras_HaveLoopLeak(const TArray<FString>& niagaraAssetPaths, FString& Result_InvalidNSAssetPathStr);
	// 设置 NiagaraEffectType 的特效优先级
	// 此接口为编辑器工具蓝图提供基础接口功能
	static void SetNiagaraEffectTypePriority(const int32 Priority, UNiagaraEffectType* EffectType);
	// 蓝图没有把 Asset 转换为 UNiagaraEffectType 的方法。。。因此这一步只能写在 C++ 里
	static void SetNiagaraEffectTypePriority(const int32 Priority, const FAssetData& AssetData);
	// 设置 NiagaraSystem 的特效优先级
	// 此接口为编辑器工具蓝图提供基础接口功能
	static void SetNiagaraSystemPriority(const int32 Priority, UNiagaraSystem* NiagaraSystem);

	// == 下面是和贴图相关的东西 ===========================================
	// 检查贴图是否有A通道
	static bool CheckTextureHasAlphaChannel(UTexture2D* Texture);
	// 检查贴图A通道中Alpha数值在某个区间的占比
	static float GetTextureChannelValueInRangeRatio(UTexture2D* Texture, int ValueMin, int ValueMax, int CheckChannel);

#endif // WITH_EDITOR
};
#pragma endregion FNSAssetCheckerUtils

#pragma region ANSAssetLoopChecker
// 这个类的功能是将一个 NSAssetLoopChecker 编辑器蓝图工具的逻辑搬过来，以便自动化 CI 调用。
// 其逻辑由两部分组成：
//	一个是一个间隔一段时间才执行的计时事件，用于往场景里替换需要检查的 NS。
//	另一个是每帧 Tick, 用于更新 Stat 参数并记录。
// 此类里面的 Timer 注册时机：
//	由 StartChecker() 注册 Timer。
// 此类里面的 Timer 注销时机:
//	1. 此 Actor 实例被销毁。
//	2. EndChecker() 被调用。
//	3. NiagaraAssetDatas 里的所有元素被检查完毕。
UCLASS(Blueprintable, BlueprintType)
class ANSAssetLoopChecker : public AActor
{
	GENERATED_BODY()

#if WITH_EDITOR
public: // 基础设置
	ANSAssetLoopChecker();
	virtual bool ShouldTickIfViewportsOnly() const override;
	virtual void Tick(float DeltaTime);
	virtual void Destroyed() override;

	void InitNSAssetLoopCheckerData(); // 用于初始化 NSAssetLoopChecker 里的各个数据

private: // 记录检测结果相关的各种数据结构
	TArray<FString> Result_InvalidNSAssetPath; // 记录有 Loop 泄露的 NS 的资产路径。

	TArray<double> NSHalfCPUParticlesNumArray; // 记录各 NS 前半段的 SpriteNum 数据。
	TArray<double> NSHalfGPUParticlesNumArray; // 记录各 NS 前半段的 MeshNum 数据。
	TArray<double> NSWholeCPUParticlesNumArray; // 记录各 NS 后半段的 SpriteNum 数据。
	TArray<double> NSWholeGPUParticlesNumArray; // 记录各 NS 后半段的 MeshNum 数据。

public: // Timer 相关 // 暴露的接口
	// 开始检查：通过此接口传入设置【待检查的资产数组】【每个 NS 的播放时长】【当后半段数值是前半段的多少倍时会被判定为泄露】等参数，同时启动 Timer 开始间隔放入 NS 播放。
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Start NS Loop Checker"))
	void StartChecker(const TArray<FString>& niagaraAssetPaths, const double timeToPlayNS = 60, const double nsAssetValidThreshold = 1.7);

	// 结束检查：销毁放入的 NSActor，注销 Timer 。
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "End NS Loop Checker"))
	void EndChecker();

private: // Timer 相关
	FTimerHandle TimerHandle_ANSAssetLoopChecker; // TimerHandle

	TArray<FAssetData> NiagaraAssetDatas; // 存放待检查资产的数组，由 StartChecker() 传入设置。
	double TimeToPlayNS; // 每一个待检查的 NS 的播放时间，由 StartChecker() 传入设置。
	double NSAssetValidThreshold; // 当后半段数值是前半段的多少倍时，会被判定为 Loop 泄露。由 StartChecker() 传入设置。

	int NSIndexCur; // 用来指示当前待检查的 NS 在资产数组中的索引。由 StartChecker() 初始化，由 Timer_NSChecker() 更新。
	TObjectPtr<UNiagaraSystem> NSObject; // 用GetAsset()加载的当前待检查的 NS 资产。由 Timer_NSChecker() 初始化。
	TObjectPtr<AActor> NSActor; // 用来指示当前待检查的 NS 实例化到场景里的 NS Actor 指针。由 StartChecker() 初始化，由 Timer_NSChecker() 更新。

	void Timer_NSChecker(); // 由 StartChecker() 调用。
	bool PrevNSValidChecker(); // 检查上一个 Timer 被触发后记录下的结果，其 Loop 是否有泄露，将结果记录在结果数组里

private: // Tick 相关
	double TickStartTime; // 每个 Timer 放入 NS 时的起始时间。由 Timer_NSChecker() 设置。
	double TickCount; // 在 Timer 放入 NS 后，经历了多少次 Tick 。由 Timer_NSChecker() 初始化，由 Ticker_NSChecker() 递增。
	double TickCountHalf; // 在 Timer 放入 NS 后，前半段经历了多少次 Tick 。用于计算【后】半段平均数值时使用，由 Ticker_NSChecker() 里面统计前半段的逻辑设置递增。

	void Ticker_NSChecker(); // 由 Tick() 调用。

public: // Tick 相关 // 暴露的接口
	// 获取到 Result_InvalidNSAssetPath 存放有问题 NS 资产的路径数组，以及所有 NS 检测时的数据
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Get NS Loop Checker Result All"))
	void GetNSLoopCheckerResult_All(FString& NSHalfCPUParticlesNumArrayStr, FString& NSWholeCPUParticlesNumArrayStr, FString& NSHalfGPUParticlesNumArrayStr, FString& NSWholeGPUParticlesNumArrayStr, FString& Result_InvalidNSAssetPathStr);
	
	// 获取到 Result_InvalidNSAssetPath 存放有问题 NS 资产的路径数组
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Get NS Loop Checker Result"))
	void GetNSLoopCheckerResult(FString& Result_InvalidNSAssetPathStr);

	// 返回当前的 Timer 是否在工作
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Is NS Loop Timer Working"))
	bool IsNSLoopTimerWorking();
#endif // WITH_EDITOR
};
#pragma endregion ANSAssetLoopChecker

#pragma region NS性能打分相关
/*
Python 使用示例:
import unreal

blueprint_path = "/Game/Blueprint/Niagara/NS_PerformanceScore/ANSPerformanceScorerManager.ANSPerformanceScorerManager"
ns_paths = ["/Game/ArtsTest/TA/huxingjian03/LingShiTest/NS_2049_Inject_loop.NS_2049_Inject_loop", "/Game/Arts/Effects/FX_Character/Seer_FX/Attack01_03/Attack_01.Attack_01"]

spawned_actor = unreal.EditorLevelLibrary.spawn_actor_from_class(unreal.NSPerformanceScorerManager, unreal.Vector(0.0, 0.0, 0.0), unreal.Rotator(0.0, 0.0, 0.0))
spawned_actor.call_method("ANSPerformanceScorerManager_Start", args=(ns_paths, 5, 2))
*/

// ST 结构
// 此 ST 只在 Editor 下能使用
USTRUCT(BlueprintType)
struct FKGNiagaraEffectTypePriorityData :public FTableRowBase
{
	GENERATED_BODY()

#pragma region Properties
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara EffectType")
	TObjectPtr<UNiagaraEffectType> EffectType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "使用此EffectType的NS的优先级")
	int32 EffectTypePriority = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "备注")
	FString Description;
#pragma endregion Properties
};

// 此 ST 只在 Editor 下能使用
USTRUCT(BlueprintType)
struct FKGNiagaraSystemPriorityData :public FTableRowBase
{
	GENERATED_BODY()

#pragma region Properties
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara System")
	TObjectPtr<UNiagaraSystem> NiagaraSystem;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "此NS的优先级")
	int32 NiagaraSystemPriority = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "备注")
	FString Description;
#pragma endregion Properties
};

// 此 ST 只在 Editor 下能使用
USTRUCT(BlueprintType)
struct FKGNiagaraScoreOriData :public FTableRowBase
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_200 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_200_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_200_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_200_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_200_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_200_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_500 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_500_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_500_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_500_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_500_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_500_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_1000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_1000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_1000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_1000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_1000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_1000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_2000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_2000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_2000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_2000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_2000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_2000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_4000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_4000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_4000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_4000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_4000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_4000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_8000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_8000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_8000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_8000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_8000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL0")
	float Score_QL0_8000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_200 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_200_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_200_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_200_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_200_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_200_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_500 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_500_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_500_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_500_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_500_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_500_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_1000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_1000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_1000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_1000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_1000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_1000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_2000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_2000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_2000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_2000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_2000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_2000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_4000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_4000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_4000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_4000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_4000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_4000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_8000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_8000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_8000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_8000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_8000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL1")
	float Score_QL1_8000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_200 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_200_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_200_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_200_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_200_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_200_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_500 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_500_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_500_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_500_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_500_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_500_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_1000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_1000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_1000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_1000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_1000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_1000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_2000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_2000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_2000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_2000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_2000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_2000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_4000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_4000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_4000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_4000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_4000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_4000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_8000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_8000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_8000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_8000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_8000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL2")
	float Score_QL2_8000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_200 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_200_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_200_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_200_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_200_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_200_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_500 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_500_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_500_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_500_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_500_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_500_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_1000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_1000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_1000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_1000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_1000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_1000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_2000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_2000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_2000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_2000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_2000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_2000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_4000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_4000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_4000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_4000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_4000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_4000_GPUParticlesNum = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_8000 = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_8000_ShaderComplexity = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_8000_CPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_8000_GPUEmittersNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_8000_CPUParticlesNum = 0;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QL3")
	float Score_QL3_8000_GPUParticlesNum = 0;
};


UCLASS(Blueprintable, BlueprintType)
class ANSPerformanceScorer : public AActor
{
	GENERATED_BODY()

#if WITH_EDITOR
private:
	bool bStartCheck = false; // 是否开始检查
	bool bFinishCheck = false; // NS是否移动
	float ParticlesNum = 0; // 粒子数
	float CPUParticlesNum = 0; // CPU粒子数
	float GPUParticlesNum = 0; // GPU粒子数
	float EmittersNum = 0; // 发射器数
	float CPUEmittersNum = 0; // CPU发射器数
	float GPUEmittersNum = 0; // GPU发射器数
	float ScreenPSComplexityMean = 0; // 平均屏幕粒子复杂度

public:
	bool bCheckMobileNS = false; // 是否检查移动端特供裁剪后的 NS
	float MoveSpeed_NiagaraActor = 10; // NS位移速度
	float PlayTime_NiagaraActor = 1; // NS检查时间
	float CheckTime_NiagaraActor = 5; // NS检查时间
	float CheckDistance_NiagaraActor = 100; // NS检查距离
	FString NiagaraAssetPath = TEXT(""); // NS资产路径

	// 原本设计的是，每一个视角、每个距离都重新生成一次NS。
	// 但是现在需要进行裁剪，裁剪之后需要编译，每个都这么搞时间就炸了。
	// 于是开放出来由外部传入。
	TObjectPtr<UNiagaraSystem> NiagaraSystem_NSPerformanceScorer = nullptr; 

private:
	double AccumulatorTime = 0.0; // 时间累加器，用于精确计时。不能用Timer，因为Timer会有各类误差累积。
	double LastTickTime = 0.0; // 上一次Tick的时间点
	TObjectPtr<ACameraActor> CameraActor_NSPerformanceScorer = nullptr;
	TObjectPtr<ANiagaraActor> NiagaraActor_NSPerformanceScorer = nullptr;
	TArray<FVector> CameraPoints = {
		FVector(1.f, 1.f, 1.f),
		//FVector(1.f, 1.f, -1.f),
		//FVector(1.f, -1.f, 1.f),
		//FVector(1.f, -1.f, -1.f),
		//FVector(-1.f, 1.f, -1.f),
		//FVector(-1.f, -1.f, 1.f),
		FVector(-1.f, -1.f, -1.f)
	};
	int32 CameraPointIndex = 0;

public:
	ANSPerformanceScorer();
	bool ShouldTickIfViewportsOnly() const;
	void StartChecker();
	virtual void Tick(float DeltaTime);
	virtual void Destroyed() override;

private:
	void Timer_ANSPerformanceScorer();
	void GenCameraActor();
	// 每帧更新 Camera Actor 的位置和旋转，让 Camera Actor 指向一个目标 NiagaraActor_NSPerformanceScorer
	void UpdateCameraActor();
	// 生成 Niagara System 实例
	void GenNiagaraActor(FString NSFilePath);
	void UpdateNiagaraActor();

public:
	bool IsFinishCheck() const;
	float GetParticlesNum() const;
	float GetCPUParticlesNum() const;
	float GetGPUParticlesNum() const;
	float GetEmittersNum() const;
	float GetCPUEmittersNum() const;
	float GetGPUEmittersNum() const;
	float GetScreenPSComplexityMean() const;
#endif // WITH_EDITOR
};

UCLASS(Blueprintable, BlueprintType)
class KGRESOURCEMANAGER_API ANSPerformanceScorerManager : public AActor
{
	GENERATED_BODY()

#if WITH_EDITOR
public:
	// 这些public的值，在Spawn的下一个Tick中使用；需要在Spawn之后立即设置。
	float MoveSpeed_NiagaraActor = 10; // NS位移速度
	float PlayTime_NiagaraActor = 1; // NS检查时间
	float CheckTime_NiagaraActor = 5; // NS检查时间
	TArray<FString> NiagaraAssetPathArray; // NS资产路径

private:
	bool bFirstCheck = true; // 是否是第一次检查
	bool bStartCheck = false; // 是否开始检查
	bool bFinishAllCheck = true; // 所有NS是否检查完毕
	bool bCheckMobileNS = false; // 是否检查移动端特供裁剪后的 NS

	// 原本设计的是，ANSPerformanceScorer 每一个视角、每个距离都重新生成一次NS。
	// 但是现在需要进行裁剪，裁剪之后需要编译，每个都这么搞时间就炸了。
	// 于是开放出来由 Manager 传入。
	TObjectPtr<UNiagaraSystem> NiagaraSystem_Current = nullptr;
	void GetMobileNiagaraSystem(TObjectPtr<UNiagaraSystem> NiagaraSystem_PC);
	void GetNiagaraSystem();

	// 不再每次都重新生成了，而是复用同一个。
	TObjectPtr<UDataTable> DataTable_OriData = nullptr;
	TObjectPtr<UDataTable> DataTable_ClampToInt8 = nullptr;

	TObjectPtr<ANSPerformanceScorer> NSPerformanceScorer = nullptr;
	TArray<float> ParticlesNumArray;
	TArray<float> CPUParticlesNumArray;
	TArray<float> GPUParticlesNumArray;
	TArray<float> EmittersNumArray;
	TArray<float> CPUEmittersNumArray;
	TArray<float> GPUEmittersNumArray;
	TArray<float> ScreenPSComplexityMeanArray;
	TArray<float> NSScoreArray;

	int32 NSArray_CurrentIndex = 0;
	TArray<int32> ScalabilityArray = { 0, 1, 2, 3 };
	int32 Scalability_CurrentIndex = 0; 
	TArray<int32> NSDistanceArray = { 200, 500, 1000, 2000, 4000, 8000 }; // 每档距离
	int32 NSDistance_CurrentIndex = 0;

	FString DataTablePath_OriData; // 存储原始分数（未归一化到0-255）的 DataTable
	FString DataTablePath_OriData_Mobile; // 存储原始分数（未归一化到0-255）的 DataTable

	float DataTable_MaxNSScore = 3000.f; // 归一化到 0-255 时的最大分数
	FString DataTablePath_ClampToInt8; // 归一化到 0-255 的 DataTable
	FString DataTablePath_ClampToInt8_Mobile; // 归一化到 0-255 的 DataTable

	void WriteRowData_OriData(FKGNiagaraScoreOriData* InOutRowData);
	uint8 OriDataClampToInt8(const float oriFloatData);
	void WriteRowData_ClampToInt8(FKGNiagaraScoreData* InOutRowData);
	void WriteToDataTable_OriData();
	void WriteToDataTable_ClampToInt8();
	void SaveDataTablesToDisk();

public:

	// 蓝图可调用函数
	UFUNCTION(BlueprintCallable, Category = "ANSPerformanceScorerManager")
	void ANSPerformanceScorerManager_Start(
		const TArray<FString>& niagaraAssetPathArray, // NS资产路径
		const float moveSpeed_NiagaraActor = 10, // NS位移速度
		const float playTime_NiagaraActor = 1, // NS实际播放的时间；比如，实际播放 1 秒，但是需要检查 5 秒的性能表现，就会以 5 倍速播放
		const float checkTime_NiagaraActor = 5, // NS检查的时间；比如，需要检查粒子播放 5 秒的性能表现
		const float dataTable_MaxNSScore = 3000.f, // 归一化到 0-255 时的最大分数
		const bool bCheckMobileNS = false, // 是否检查移动端特供裁剪后的 NS
		const int32 scalability_CurrentIndex = 0, // 画质档位起始索引，便于断点续传
		const FString& dataTablePath_ClampToInt8 = TEXT("/Game/Blueprint/Niagara/NS_PerformanceScore/DT_NS_PerformanceScore.DT_NS_PerformanceScore"),
		const FString& dataTablePath_OriData = TEXT("/Game/Blueprint/Niagara/NS_PerformanceScore/OriData/DT_NS_PerformanceScore_Ori.DT_NS_PerformanceScore_Ori"),
		const FString& dataTablePath_ClampToInt8_Mobile = TEXT("/Game/Blueprint/Niagara/NS_PerformanceScore/DT_NS_PerformanceScore_Mobile.DT_NS_PerformanceScore_Mobile"),
		const FString& dataTablePath_OriData_Mobile = TEXT("/Game/Blueprint/Niagara/NS_PerformanceScore/OriData/DT_NS_PerformanceScore_Ori_Mobile.DT_NS_PerformanceScore_Ori_Mobile")
	);

	ANSPerformanceScorerManager();
	bool ShouldTickIfViewportsOnly() const;
	virtual void Tick(float DeltaTime);
	virtual void Destroyed() override;
#endif // WITH_EDITOR
};
#pragma endregion NS性能打分相关

#pragma region UNSAssetCheckerBP
UCLASS()
class UNSAssetCheckerBP : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

#if WITH_EDITOR
public: // Utils BP Nodes
	// Stat 相关
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Get Stat Counter", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
	static double GetStatCounterBP(UObject* WorldContextObject, FName StatGroupName, FName StatName)
	{
		return FNSAssetCheckerUtils::GetStatCounter(WorldContextObject, StatGroupName, StatName);
	};

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Get Niagara Particles Num", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
	static void GetNiagaraNumParticles(UObject* WorldContextObject, int32& CPUParticlesNum, int32& GPUParticlesNum, int32& CPUEmittersNum, int32& GPUEmittersNum)
	{
		FNSAssetCheckerUtils::GetNiagaraNumParticles(WorldContextObject, CPUParticlesNum, GPUParticlesNum, CPUEmittersNum, GPUEmittersNum);
	}

	// File 相关
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Save String To File"))
	static bool SaveStringToFile(const FString& StringContent, const FString& FilePath)
	{
		return FNSAssetCheckerUtils::SaveStringToFile(StringContent, FilePath);
	};

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Save String Array To File"))
	static bool SaveStringArrayToFile(const TArray<FString>& StringArrayContent, const FString& FilePath)
	{
		return FNSAssetCheckerUtils::SaveStringArrayToFile(StringArrayContent, FilePath);
	};

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Load String To File"))
	static bool LoadFileToString(FString& StringContent, const FString& FilePath)
	{
		return FNSAssetCheckerUtils::LoadFileToString(StringContent, FilePath);
	};

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Load String Array To File"))
	static bool LoadFileToStringArray(TArray<FString>& StringArrayContent, const FString& FilePath)
	{
		return FNSAssetCheckerUtils::LoadFileToStringArray(StringArrayContent, FilePath);
	};

	// Niagara System 相关
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Niagara Has Active Light Renderer"))
	static bool Niagara_HasActiveLightRenderer(const UNiagaraSystem* NiagaraSystem)
	{
		return FNSAssetCheckerUtils::Niagara_HasActiveLightRenderer(NiagaraSystem);
	}
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Niagara Has Loop Leak"))
	static bool Niagara_HasLoopLeak(const UNiagaraSystem* NiagaraSystem)
	{
		return FNSAssetCheckerUtils::Niagara_HasLoopLeak(NiagaraSystem);
	}
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Niagaras Have Loop Leak"))
	static void Niagaras_HaveLoopLeak(const TArray<FString>& NiagaraAssetPaths, FString& Result_InvalidNSAssetPathStr)
	{
		return FNSAssetCheckerUtils::Niagaras_HaveLoopLeak(NiagaraAssetPaths, Result_InvalidNSAssetPathStr);
	}
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Set Niagara EffectType Asset Priority"))
	static void SetNiagaraEffectTypeAssetPriority(const int32 Priority, const FAssetData& AssetData)
	{
		return FNSAssetCheckerUtils::SetNiagaraEffectTypePriority(Priority, AssetData);
	}
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Set Niagara EffectType Priority"))
	static void SetNiagaraEffectTypePriority(const int32 Priority, UNiagaraEffectType* EffectType)
	{
		return FNSAssetCheckerUtils::SetNiagaraEffectTypePriority(Priority, EffectType);
	}
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Set Niagara System Priority"))
	static void SetNiagaraSystemPriority(const int32 Priority, UNiagaraSystem* NiagaraSystem)
	{
		return FNSAssetCheckerUtils::SetNiagaraSystemPriority(Priority, NiagaraSystem);
	}

	// AnimNotify 相关
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Get AnimationNotifyEvent: AnimNotify"))
	static UAnimNotify* GetAnimationNotifyEvent_AnimNotify(const FAnimNotifyEvent& NotifyEvent)
	{
		return FNSAssetCheckerUtils::GetAnimationNotifyEvent_AnimNotify(NotifyEvent);
	}

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Get AnimationNotifyEvent: AnimNotifyState"))
	static UAnimNotifyState* GetAnimationNotifyEvent_AnimNotifyState(const FAnimNotifyEvent& NotifyEvent)
	{
		return FNSAssetCheckerUtils::GetAnimationNotifyEvent_AnimNotifyState(NotifyEvent);
	}

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Get AnimationNotifyEvent: Track Name&Index"))
	static void GetAnimationNotifyEvent_TrackNameIndex(const UAnimSequenceBase* AnimationSequenceBase, const FAnimNotifyEvent& NotifyEvent,
		FName& TrackName, int& TrackIndex)
	{
		FNSAssetCheckerUtils::GetAnimationNotifyEvent_TrackNameIndex(AnimationSequenceBase, NotifyEvent, TrackName, TrackIndex);
	}

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Get AnimNotify Property: PlayNiagaraEffect"))
	static void GetProperty_UAnimNotify_PlayNiagaraEffect(const UAnimNotify_PlayNiagaraEffect* AnimNotify,
		UNiagaraSystem*& NSTemplate, FVector& LocationOffset, FRotator& RotationOffset, FVector& Scale, bool& bAbsoluteScale, FName& SocketName)
	{
		FNSAssetCheckerUtils::GetProperty_UAnimNotify_PlayNiagaraEffect(AnimNotify, NSTemplate, LocationOffset, RotationOffset, Scale, bAbsoluteScale, SocketName);
	}

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Get AnimNotify Property: TimedNiagaraEffect"))
	static void GetProperty_UAnimNotifyState_TimedNiagaraEffect(const UAnimNotifyState_TimedNiagaraEffect* AnimNotify,
		UNiagaraSystem*& NSTemplate, FVector& LocationOffset, FRotator& RotationOffset, FName& SocketName)
	{
		FNSAssetCheckerUtils::GetProperty_UAnimNotifyState_TimedNiagaraEffect(AnimNotify, NSTemplate, LocationOffset, RotationOffset, SocketName);
	}

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Set AnimNotify Property: C7TimedNiagaraEffect"))
	static void SetProperty_UAnimNotifyState_C7TimedNiagaraEffect(UAnimNotifyState_C7TimedNiagaraEffect* AnimNotify,
		const UNiagaraSystem* NSTemplate, const FTransform& Transform, bool bAbsoluteScale, FName SocketName)
	{
		FNSAssetCheckerUtils::SetProperty_UAnimNotifyState_C7TimedNiagaraEffect(AnimNotify, NSTemplate, Transform, bAbsoluteScale, SocketName);
	}

	// 母材质光照设置修改相关
	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Mat", meta = (DisplayName = "Is SurfacePerPixelLighting"))
	static bool Is_SurfacePerPixelLighting(UMaterial* Mat)
	{
		return FNSAssetCheckerUtils::Is_SurfacePerPixelLighting(Mat);
	};

	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Mat", meta = (DisplayName = "Change TranslucencyLightingMode To TLM_VolumetricDirectional"))
	static void Change_TranslucencyLightingMode_To_VolumetricDirectional(UMaterial* MatIn, UMaterial*& MatRet)
	{
		FNSAssetCheckerUtils::Change_TranslucencyLightingMode_To_VolumetricDirectional(MatIn, MatRet);
	};


	UFUNCTION(BlueprintCallable, Category = "NS Asset Checker\|Utils", meta = (DisplayName = "Change_ttttttttttttttttttt", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
	static void Change_ttttttttttttttttttt(UObject* WorldContextObject, UNiagaraSystem* NiagaraSystem)
	{
		UWorld* World = nullptr;
		World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);
		if (!World)
			return;

		NiagaraSystem = FNiagaraEditorTools::DuplicateAndDisableEmitters(NiagaraSystem);

		//// 逐 Emitter 编译
		//TArray<FVersionedNiagaraEmitter> AffectedEmitters;
		//for (const FNiagaraEmitterHandle& Handle : NiagaraSystem->GetEmitterHandles())
		//{
		//	if (!Handle.GetIsEnabled())
		//	{
		//		continue;
		//	}

		//	const FVersionedNiagaraEmitter& Emitter = Handle.GetInstance();
		//	AffectedEmitters.Add(Emitter);
		//}
		//FNiagaraEditorUtilities::CompileExistingEmitters(AffectedEmitters);
		//// 沟槽的FNiagaraEditorUtilities::CompileExistingEmitters内部也用的是NiagaraSystem->RequestCompile

		NiagaraSystem->RequestCompile(false);

		FVector Location(0.f, 0.f, 100.f);
		FRotator Rotation(0.f, 0.f, 0.f);

		// 生成 Niagara Actor
		FActorSpawnParameters SpawnParams;
		TObjectPtr<ANiagaraActor> NiagaraActor_NSPerformanceScorer = World->SpawnActor<ANiagaraActor>(
			ANiagaraActor::StaticClass(),
			Location,
			Rotation,
			SpawnParams
		);

		if (NiagaraActor_NSPerformanceScorer)
		{
			TObjectPtr<UNiagaraComponent> NiagaraComp = NiagaraActor_NSPerformanceScorer->GetNiagaraComponent();
			if (NiagaraComp)
			{
				NiagaraComp->SetAsset(NiagaraSystem);
				NiagaraComp->Activate(true);
			}

		}
	};

	// ================================================================
	// 贴图相关
	UFUNCTION(BlueprintCallable, Category = "Utils", meta = (DisplayName = "Get Texture Alpha Not One Ratio"))
	static float GetTextureChannelValueInRangeRatio(UTexture2D* Texture, int ValueMin, int ValueMax, int CheckChannel)
	{
		return FNSAssetCheckerUtils::GetTextureChannelValueInRangeRatio(Texture, ValueMin, ValueMax, CheckChannel);
	};
#endif // WITH_EDITOR
};
#pragma endregion UNSAssetCheckerBP

