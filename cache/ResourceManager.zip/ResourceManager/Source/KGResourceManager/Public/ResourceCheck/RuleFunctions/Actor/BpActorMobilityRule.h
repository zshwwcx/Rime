#pragma once

#include "ResourceCheck/RuleBase.h"

#include "BpActorMobilityRule.generated.h"

UCLASS()
class UBpActorMobilityRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("BpActorMobilityRule");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	UFUNCTION()
	bool CheckSubComponentMobility(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);
};