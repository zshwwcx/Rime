// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "WorldPartition/DataLayer/DataLayerAsset.h"
#include "DataLayerAssetRule.generated.h"

/**
 * 
 */
UCLASS()
class KGRESOURCEMANAGER_API UDataLayerAssetRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override
	{
		return UDataLayerAsset::StaticClass();
	}

	virtual FString GetRuleName() override {return TEXT("DataLayer");}
};
