﻿#pragma once

#include "ResourceCheck/RuleFunctions/GFur/GFurAssetRule.h"
#include "FurComponent.h"
#include "GFurBlueprintActorAssetRule.generated.h"

UCLASS()
class UGFurBlueprintActorAssetRule : public UGFurRuleBase
{
	GENERATED_BODY()

public:
	virtual FString GetRuleName() override {return TEXT("GFurBlueprintActorAsset");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	static TArray<UGFurComponent*> GetAllGFurComponents(const FAssetData& AssetData);

	UFUNCTION()
	bool CheckLODsCount(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckLayerCount(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckGrowMeshVertices(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};

