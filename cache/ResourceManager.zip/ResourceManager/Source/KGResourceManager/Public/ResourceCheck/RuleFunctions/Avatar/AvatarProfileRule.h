// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "AvatarProfileRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API UAvatarProfileRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("AvatarProfile");};
	
	UFUNCTION()
	bool CheckNameRepeat(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMaterialRepeat(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};
