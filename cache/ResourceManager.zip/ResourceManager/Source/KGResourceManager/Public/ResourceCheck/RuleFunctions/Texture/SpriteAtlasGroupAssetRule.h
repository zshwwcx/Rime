// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "PaperSpriteAtlas.h"
#include "SpriteAtlasGroupAssetRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API USpriteAtlasGroupAssetRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("PaperSpriteAtlas");};

	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;
	
	UFUNCTION()
	FString GetUsedRatio(const FAssetData& AssetData);

	UFUNCTION()
	FString GetMaxSize(const FAssetData& AssetData);

	TArray<FString> CommonMaxSizePath;
	int32 CommonMax;
	int32 NormalMax;
};
