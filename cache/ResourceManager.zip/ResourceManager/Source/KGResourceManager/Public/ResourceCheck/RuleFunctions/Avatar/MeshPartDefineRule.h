
#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "MeshPartDefineRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API UMeshPartDefineRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;
	
	virtual FString GetRuleName() override {return TEXT("MeshPartDefine");};

	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;

	UFUNCTION()
	FString GetCanSkipEstimatePresetStatLevelWhiteList(const FAssetData& AssetData);
	
	UFUNCTION()
	bool IsMeshIDUnique(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckSkeletalMesh(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckSkeletalMeshPath(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	TMap<FString, TArray<TTuple<FString, FString>>> UniqueIDToPackageName;

	TArray<FString> CanSkipEstimatePresetStatLevelWhiteList;
};
