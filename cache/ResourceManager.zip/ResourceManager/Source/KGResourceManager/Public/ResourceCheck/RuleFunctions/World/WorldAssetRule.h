// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "WorldAssetRule.generated.h"

/**
 * 
 */
UCLASS()
class KGRESOURCEMANAGER_API UWorldAssetRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override; 

	virtual FString GetRuleName() override {return TEXT("World");}

	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;
	
	bool PreExecuteAsset(const FAssetData& AssetData) override;
	
	bool PostExecuteAsset(const FAssetData& AssetData) override;
	
	UFUNCTION()
	FString IsPartitionedWorld(const FAssetData& AssetData);
	
	UFUNCTION()
	bool CompileRuntimeVirtualTexture(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool WorldNavMeshCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	FString GetNavMeshBoundsVolumeNum(const FAssetData& AssetData);
	
	UFUNCTION()
	bool WorldPartitionCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool WorldCompositionActorCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckNumRuntimeVirtualTextureVolume(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckActorPrimitiveComponentRVT(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckSkyAtmosphereWorldSkyMaterial(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckLandScape(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckFoliageActor(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	FString GetRuntimeHasClass(const FAssetData& AssetData);

	UFUNCTION()
	bool RepairRuntimeHasClass(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

	UFUNCTION()
	FString GetEnableRayTracing(const FAssetData& AssetData);
	
	UFUNCTION()
	bool RepairEnableRayTracing(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);
	
	int32 NewPrecomputeVisibility;
	int32 NewVisibilityCellSize;
	EVisibilityAggressiveness NewVisibilityAggressiveness;
	int32 NumRuntimeVirtualTextureVolume;

	TArray<FString> WCActors; 
};
