#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "AnimSequenceRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API UAnimSequenceRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("AnimSequence");}

	UFUNCTION()
	FString IsUseDefaultSampleRate(const FAssetData& AssetData);

	UFUNCTION()
	FString IsRetargetSourceValidPrefix(const FAssetData& AssetData);

	UFUNCTION()
	FString IsRetargetSourceValidFolder(const FAssetData& AssetData);

	UFUNCTION()
	bool CheckRetargetSourceNotEndWithOld(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckTimedNiagaraEffectNotifyState(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};