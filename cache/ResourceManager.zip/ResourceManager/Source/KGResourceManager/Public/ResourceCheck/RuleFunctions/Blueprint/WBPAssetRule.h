// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "WBPAssetRule.generated.h"

class UWidgetBlueprint;
class UMovieSceneFloatSection;
class UMovieSceneFloatTrack;
struct FMovieSceneFloatChannel;
class UMovieScene2DTransformSection;
class UMovieScene2DTransformTrack;
class UMovieSceneTrack;
class UWidgetAnimation;

UCLASS()
class KGRESOURCEMANAGER_API UWBPAssetRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("WBPAsset");};
	
	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;

	virtual bool PreExecuteAsset(const FAssetData& InAssetData) override;

	virtual bool PostExecuteAsset(const FAssetData& AssetData) override;
	
	UFUNCTION()
	FString GetWBPObjectNum(const FAssetData& AssetData);

	// func rules
	UFUNCTION()
	bool CheckKGUserWidget(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool CheckDependencedTexture(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckGUITextureSize(const FAssetData& AssetData,const TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool CheckIllegalDependedAsset(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckAniInAndOut(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);
    
    UFUNCTION()
    bool CheckAnimRefNonExistObj(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckLuaModify(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	static void GetDependedBinkAssets(const FAssetData& AssetData, TArray<FAssetData>& OutDependedBinkAssets, int32& OutDepth);

	UFUNCTION()
	bool CheckDependedBinkMediaPlayerNum(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckUFunctionWithBlank(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	static const FSlateFontInfo* GetSlateFontInfo(UObject* Object);

	static const class UFontFace* GetFontFaceFromSlateFontInfo(const FSlateFontInfo* SlateFontInfo);

	UFUNCTION()
	bool CheckFontDistanceField(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	static float ConvertFontSizeFromNativeToDisplay(float NativeFontSize);

	UFUNCTION()
	bool CheckFontOutlineSize(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckWidgetIsVolatile(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckDuplicatedName(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	TArray<FString> DependResourceAssetes;
	TArray<FString> DependPaperSpriteAssetes;
	TArray<FString> ExceptDependAssetPaths;
	int32 MaxMainBPDependedAtlasNum;
	int32 MaxSubBPDependedAtlasNum;
	int32 MaxMainBPDependedTextureNum;
	int32 MaxSubBPDependedTextureNum;
	int32 MaxGUITextureSize;
	int32 MaxDependedBinkMediaPlayerNum;
	TMap<FString, TSet<FString>> ExternDependDirectory;
	
private:

	void CompareTrack(const FAssetData& AssetData, UWidgetBlueprint* WidgetBlueprint, UMovieSceneTrack* TrackIn, UMovieSceneTrack* TrackOut, FString AnimOut, FString BindObjectName, FString AnimIn);
	void CompareSection(const FAssetData& AssetData, UWidgetBlueprint* WidgetBlueprint, UMovieScene2DTransformSection* SectionIn, UMovieScene2DTransformSection* SectionOut, FString InLog);
	void CompareSection(const FAssetData& AssetData, UWidgetBlueprint* WidgetBlueprint, UMovieSceneFloatSection* SectionIn, UMovieSceneFloatSection* SectionOut, FString InLog);
	void CompareChannel(const FAssetData& AssetData, UWidgetBlueprint* WidgetBlueprint, FMovieSceneFloatChannel* ChannelIn, FMovieSceneFloatChannel* ChannelOut, FString InLog);
	
    struct FAnimRefNoExistObjectChecker
    {
        bool operator()(const TObjectPtr<UWidgetAnimation>& InAnimation, UWidgetBlueprint* WidgetBlueprint, ERMCheckRuleType InCheckRuleType, const FAssetData& AssetData, FResourceCheckLogCollect& InLog) const;

        static void GetMovieSceneFoldersRecursive(TArrayView<class UMovieSceneFolder* const> InFoldersToRecurse, TArray<class UMovieSceneFolder*>& OutFolders);
    };
    
	TMap<FString, TPair<TWeakObjectPtr<UWidgetAnimation>, TWeakObjectPtr<UWidgetAnimation>>> AnimationMap;
	TMap<FString, TArray<TWeakObjectPtr<UMovieSceneTrack>>> BindingObjectsTrackMap;

	TArray<TWeakObjectPtr<const class UPaperSpriteAtlas>> DependPaperSpriteAtlas;
	TArray<TWeakObjectPtr<UTexture>> DependTexture;
	bool bIsSubWidget;
};
