// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleFunctions/Actor/ActorRule.h"
#include "StaticMeshComponentRule.generated.h"

USTRUCT()
struct FStaticMeshComponentParam
{
	GENERATED_BODY()

	bool bUsingRVT = false;
	bool bUsingSAT = false;

	FStaticMeshComponentParam()
		:bUsingRVT(false)
		,bUsingSAT(false)
	{
		
	}
};

UCLASS()
class KGRESOURCEMANAGER_API UStaticMeshComponentRule : public UActorRule
{
	GENERATED_BODY()

public:

	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	UFUNCTION()
	bool CheckStaticMeshValid(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckStaticMeshComponentMobility(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckStaticMeshComponentNantie(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckStaticMeshComponentWPO(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool EnableCastShadow(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckDrawInMainPass(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckDrawInMainPassNeverActorClass(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool CheckTranslucencySortPriority(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckRVTMaterial(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairStaticMeshComponentWPO(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

	UFUNCTION()
	bool RepairCastShadow(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

	UFUNCTION()
	bool RepairNantie(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

	UFUNCTION()
	bool RepairDrawInMainPass(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);
	
	UFUNCTION()
	bool CheckComponentRuntimeVirtualTextureVolume(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool RepairTranslucencySortPriority(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

	UFUNCTION()
	bool RepairRuntimeVirtualTextureVolume(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

	UFUNCTION()
	bool RepairComponentMobility(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

	UFUNCTION()
	bool CheckForbiddenMaterial(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	FString IsMainSkyPerformerActor(const FAssetData& AssetData);
private:
	bool CheckMaterialRecursive(UMaterialInterface* MaterialInterface, const TArray<FString>& MaterialNames, FString& OutMaterialName);
public:
	int32 HalfWPODistanceRadius;
	int32 HalfWorldPositionOffsetDisableDistance;
	int32 WorldPositionOffsetDisableDistance;
	TArray<FString> ForceWPOMaterial;
	TArray<FString> DrawInMainPassNeverActorClass;
	TArray<FString> ForbiddenMaterialNames;

	TMap<TWeakObjectPtr<UStaticMeshComponent>, FStaticMeshComponentParam> StaticMeshComponentParams;
};
