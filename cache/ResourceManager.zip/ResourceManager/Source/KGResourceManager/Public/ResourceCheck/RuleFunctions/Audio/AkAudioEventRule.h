#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "AkAudioEventRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API UAkAudioEventRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("AkAudioEventRule");}

	UFUNCTION()
	bool CheckDuplicatedName(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};