﻿#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleFunctions/StaticMesh/StaticMeshAssetRuleBase.h"
#include "StaticMeshAssetNaniteRule.generated.h"


struct FStaticMeshAssetFirstLODCollectedInfo
{
	void Reset()
	{
		bHasFoliageMat = false;
		bHasSkyMat = false;
		bHasTranslucent = false;
		FoliageMatNames.Empty();
		SkyMatNames.Empty();
		TranslucentMatNames.Empty();
	}

	bool bHasFoliageMat = false;
	bool bHasSkyMat = false;
	bool bHasTranslucent = false;
	TArray<FString> FoliageMatNames;
	TArray<FString> SkyMatNames;
	TArray<FString> TranslucentMatNames;
};


UCLASS()
class KGRESOURCEMANAGER_API UStaticMeshAssetNaniteRule : public UStaticMeshAssetRuleBase
{
	GENERATED_BODY()
	
	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;
	virtual bool PreExecuteAsset(const FAssetData& InAssetData) override;
	virtual bool PostExecuteAsset(const FAssetData& AssetData) override;

	UFUNCTION()
	bool EnableNantieSupport(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool EnablePreserverArea(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool EnableTwoSidedDistanceField(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool RepairStaticMeshNaniteSetting(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	UFUNCTION()
	bool RepairTwoSidedDistanceField(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);
	
	void CollectAssetInfo(const FAssetData& InAssetData);
	
	void CollectFirstLODInfo(const FAssetData& InAssetData);

	TArray<FString> ForceWPOMaterial;
	TArray<FString> FoliageMaterial;
	TArray<FString> SkyMaterial;
	TArray<FString> TwoSidedDistanceFieldMaterial;
	TArray<FString> DisableNantieMaterial;
	TMap<FString, TTuple<float,float>> MaterialNumStandard;
	TArray<EBlendMode> DisableNantieBlendMode;
	
	static FString NanitePropertyName;
	static FString TwoSidedDistanceFieldPropertyName;
	FRMStaticMeshAssetCollectedInfo CollectedInfo;

	FStaticMeshAssetFirstLODCollectedInfo FirstLODInfo;
};
