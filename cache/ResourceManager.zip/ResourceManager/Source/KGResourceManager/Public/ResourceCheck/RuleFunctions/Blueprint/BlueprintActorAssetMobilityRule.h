#pragma once

#include "ResourceCheck/RuleBase.h"

#include "BlueprintActorAssetMobilityRule.generated.h"

UCLASS()
class UBlueprintActorAssetMobilityRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("BlueprintActorAssetMobilityRule");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	UFUNCTION()
	bool CheckSubComponentMobility(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);
};