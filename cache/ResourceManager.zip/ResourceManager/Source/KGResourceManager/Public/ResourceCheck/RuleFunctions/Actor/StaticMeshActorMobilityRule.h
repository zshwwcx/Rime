#pragma once

#include "ResourceCheck/RuleBase.h"

#include "StaticMeshActorMobilityRule.generated.h"

UCLASS()
class UStaticMeshActorMobilityRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("StaticMeshActorMobilityRule");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	UFUNCTION()
	bool CheckMobility(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);
};