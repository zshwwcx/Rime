
#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "NpcMeshPartDefineRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API UNpcMeshPartDefineRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;
	
	virtual FString GetRuleName() override {return TEXT("MeshPartDefine");};

	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;

	UFUNCTION()
	bool CheckSkeletalMeshMaterialSlot(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	TArray<FString> MaterialSlotClothTypeName;
};
