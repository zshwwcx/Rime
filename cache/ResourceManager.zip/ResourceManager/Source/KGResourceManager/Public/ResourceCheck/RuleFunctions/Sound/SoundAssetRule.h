﻿#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "SoundAssetRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API USoundAssetRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("SoundAsset");}

	UFUNCTION()
	bool CheckSoundAsset(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};