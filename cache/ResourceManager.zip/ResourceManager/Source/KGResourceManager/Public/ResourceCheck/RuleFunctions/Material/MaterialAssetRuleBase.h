// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "MaterialAssetRuleBase.generated.h"

/**
 * 
 */
UCLASS()
class KGRESOURCEMANAGER_API UMaterialAssetRuleBase : public URuleBase
{
	GENERATED_BODY()
	
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("Material");};

	bool PreExecuteAsset(const FAssetData& AssetData);
	
	UFUNCTION()
	bool CheckMaterialUsage(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairMaterialUsage(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	UFUNCTION()
	bool SubmitCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	static FString MaterialUsagePropertyName;
	TArray<FString> SubmitMaterialGroups;
};
