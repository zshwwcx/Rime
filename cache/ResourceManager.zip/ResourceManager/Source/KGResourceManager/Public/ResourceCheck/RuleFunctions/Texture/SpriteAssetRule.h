// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "PaperSprite.h"
#include "SpriteAssetRule.generated.h"

/**
 * 
 */
UCLASS()
class KGRESOURCEMANAGER_API USpriteAssetRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override { return TEXT("PaperSprite"); };

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	UFUNCTION()
	FString HasReferenced(const FAssetData& AssetData);

	UFUNCTION()
	FString GetSourceDimensionX(const FAssetData& AssetData);

	UFUNCTION()
	FString GetAtlasDimensionX(const FAssetData& AssetData);

	UFUNCTION()
	FString GetSourceDimensionY(const FAssetData& AssetData);

	UFUNCTION()
	FString GetAtlasDimensionY(const FAssetData& AssetData);

	bool IsUsedInLuaFile(const FString& PathName, const FString& SingleName);

	UPROPERTY(Transient)
	TMap<FName, UPaperSpriteAtlas*> NameToPaperSpriteAtlas;

	TArray<FName> AssetReferencers;
};
