#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleFunctions/Texture/TextureAssetRuleBase.h"
#include "MakeupTextureRule.generated.h"

struct FMakeupTextureStandard
{
	FString MaxInGame;
	FString TextureGroup;
	FString MipGenSetting;
	FString CompressionSettings;
	FString SRGB;
	FString Alpha;
};

UCLASS()
class KGRESOURCEMANAGER_API UMakeupTextureRule : public UTextureAssetRuleBase
{
	GENERATED_BODY()

public:
	virtual FString GetRuleName() override {return TEXT("MakeupTextureRule");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	UFUNCTION()
	FString IsNeedCheck(const FAssetData& AssetData);

	UFUNCTION()
	FString GetHasAlphaChannel(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandMaxInGame(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandTextureGroup(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandMipGenSetting(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandCompressionSettings(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandSRGB(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandAlpha(const FAssetData& AssetData);

	UFUNCTION()
	bool CheckPairedAssetCommit(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	bool bNeedCheck=false;
	FMakeupTextureStandard MakeupTextureStandard;
};