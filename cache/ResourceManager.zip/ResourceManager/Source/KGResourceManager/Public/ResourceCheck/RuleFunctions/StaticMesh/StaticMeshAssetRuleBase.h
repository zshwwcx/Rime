﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "StaticMeshAssetRuleBase.generated.h"

USTRUCT()
struct FRMStaticMeshAssetCollectedInfo
{
	GENERATED_BODY()
	
	bool bHasFoliageMat = false;
	bool bHasTwoSidedDistanceFieldMat = false;
	TArray<FString> TwoSidedDistanceFieldMatNames;
};

/**
 * 
 */
UCLASS(Blueprintable, BlueprintType)
class KGRESOURCEMANAGER_API UStaticMeshAssetRuleBase : public URuleBase
{
	GENERATED_BODY()
	
public:
	
	virtual UClass* GetAssetType() override;
	virtual FString GetRuleName() override {return TEXT("StaticMesh");};

	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;
	
protected:

	UFUNCTION()
	FString IsFoliageMaterial(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetMaterialNum(const FAssetData& AssetData);

	UFUNCTION()
	FString GetMaterialNames(const FAssetData& AssetData);

	UFUNCTION()
	FString GetApproxiSizeX(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetApproxiSizeY(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetApproxiSizeZ(const FAssetData& AssetData);

	UFUNCTION()
	FString GetApproxiVolume(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetTriangles(const FAssetData& AssetData);

	UFUNCTION()
	FString GetRawMeshTriangles(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetNumLODs(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetNumUVChannels(const FAssetData& AssetData);
	
	UFUNCTION()
	bool RepairNumUVChannels(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	UFUNCTION()
	bool CheckCollisionValid(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMaterialFlag(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMaterialUsedWithNanite(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckLodScreenSizeZero(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckAutoGenerateLightmapUVClosed(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairAutoGenerateLightmapUVClosed(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	UFUNCTION()
	bool CheckNanitedStaticMeshMinLOD(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairNanitedStaticMeshMinLOD(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	UFUNCTION()
	bool CheckHighTriangleNanitedStaticMeshMinLOD(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairHighTriangleNanitedStaticMeshMinLOD(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	UFUNCTION()
	bool CheckNonNanitedStaticMeshMinLOD(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairNonNanitedStaticMeshMinLOD(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	UFUNCTION()
	bool CheckMixedOpacityMaterials(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};
