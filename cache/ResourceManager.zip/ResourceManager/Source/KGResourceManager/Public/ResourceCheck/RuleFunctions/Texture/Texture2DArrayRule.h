// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleFunctions/Texture/TextureAssetRuleBase.h"
#include "Texture2DArrayRule.generated.h"

UCLASS(Blueprintable, BlueprintType)
class KGRESOURCEMANAGER_API UTexture2DArrayRule : public UTextureAssetRuleBase
{
	GENERATED_BODY()

public:

	virtual UClass* GetAssetType() override;
	virtual FString GetRuleName() override {return TEXT("Texture2DArray");}

	UFUNCTION()
	bool CheckSuffixDR(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckSuffixNOH(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);
	
};
