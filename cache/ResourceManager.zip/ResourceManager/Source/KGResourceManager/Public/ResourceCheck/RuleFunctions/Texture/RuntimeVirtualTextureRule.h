#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "RuntimeVirtualTextureRule.generated.h"

UCLASS(Blueprintable, BlueprintType)
class KGRESOURCEMANAGER_API URuntimeVirtualTextureRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual FString GetRuleName() override {return TEXT("RuntimeVirtualTextureRule");}

	virtual UClass* GetAssetType() override;

	UFUNCTION()
	bool CheckMobileAssetExist(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);
};