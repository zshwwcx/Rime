// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "Engine/SkeletalMesh.h"
#include "SkeletalMeshAssetRule.generated.h"

USTRUCT(BlueprintType)
struct FRMSkeletalMeshPropertyRules
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere)
	FString SkeletalMeshAssetPath;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FRMPropertyRule> Rules;
};

UCLASS()
class KGRESOURCEMANAGER_API USkeletalMeshAssetRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("SkeletalMesh");};

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;
	
	UFUNCTION()
	FString GetLODNum(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetSkeletonNum(const FAssetData& AssetData);

	UFUNCTION()
	FString GetBones(const FAssetData& AssetData);

	UFUNCTION()
	FString GetNumVertices(const FAssetData& AssetData);

	UFUNCTION()
	FString GetSkinCacheUsage(const FAssetData& AssetData);

	UFUNCTION()
	FString GetTotalTriangles(const FAssetData& AssetData);
	
	UFUNCTION()
	FString GetNumMaterials(const FAssetData& AssetData);

	UFUNCTION()
	FString GetNumMeshClothingAssets(const FAssetData& AssetData);

	UFUNCTION()
	FString IsHumanLike(const FAssetData& AssetData);

	UFUNCTION()
	bool CheckSkeletonExists(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckHairMaterialSlot(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool CheckSkeletonInChangeList(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckLODGenerated(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckLODTriangleRatio(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	FString GetBoundsPhysicsAssetShapeCount(const FAssetData& AssetData);

	UFUNCTION()
	bool CheckMeshLODMaterialValid(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckFullBones(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMaterialUsedWithSkeletalMesh(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckCoatBone(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
private:
	FString CoatBone;
};
