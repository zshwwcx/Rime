﻿#pragma once

#include "ResourceCheck/RuleBase.h"
#include "FurComponent.h"
#include "GFurAssetRule.generated.h"


UCLASS(abstract)
class UGFurRuleBase : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;
};

UCLASS()
class UGFurAssetRule : public UGFurRuleBase
{
	GENERATED_BODY()

public:
	virtual FString GetRuleName() override {return TEXT("GFurAsset");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	static UGFurComponent* GetGFurComponent(const FAssetData& AssetData);

	UFUNCTION()
	FString GetLODsCount(const FAssetData& AssetData);

	UFUNCTION()
	FString GetLayerCount(const FAssetData& AssetData);

	UFUNCTION()
	FString GetSkeletalGrowMeshVertices(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStaticGrowMeshVertices(const FAssetData& AssetData);
};

