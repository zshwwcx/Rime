#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "LevelSequence.h"
#include "Sections/MovieSceneCinematicShotSection.h"
#include "Tracks/MovieScenePropertyTrack.h"
#include "LevelSequenceRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API ULevelSequenceRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("LevelSequence");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;
	
	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;

	virtual bool PostExecuteAsset(const FAssetData& AssetData) override;

	static TArray<AActor*> GetAllPossessableActors(const ULevelSequence* LevelSequence, TMap<FGuid, AActor*>& GuidActors);

	static TArray<AActor*> GetAllSpawnableActors(const ULevelSequence* LevelSequence, TMap<FGuid, AActor*>& GuidActors);

	static int32 GetSpawnableActorCount(const ULevelSequence* LevelSequence);

	static TArray<FAssetData> GetAllDependedLevelSequenceAssetData(const FAssetData& AssetData, int32 CurrentDepth, TSet<FName>& VisitedPackages);
	
	static TArray<FAssetData> GetAllDependedLevelSequenceAssetData(const FAssetData& AssetData);
	
	static const AActor* GetPossessableParentActor(const ULevelSequence* LevelSequence, const FMovieScenePossessable* Possessable);

	UFUNCTION()
	FString GetSpawnedActorsCount(const FAssetData& AssetData) const;
	
	UFUNCTION()
	FString GetCanProcessBySceneConvertActorsCount(const FAssetData& AssetData) const;
	
	static void GetCanProcessBySceneConvertActors(const ULevelSequence* LevelSequence, TSet<const AActor*>& ActorSet);

	UFUNCTION()
	bool CheckStaticMobilityDependence(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckDependedLevel(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMaterialParam(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMaterialLightPosParam(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckSpawnedActorType(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	static bool IsWindowsOnly(const AActor* Actor);

	UFUNCTION()
	bool CheckWindowsOnlyFeature(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckCharacterLightIntensityTrack(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	static bool IsWorldHasLightingBuildData(const UWorld* World);

	UFUNCTION()
	bool CheckDependedSceneActorBase(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckEventTrack(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	static bool CheckFloatPropertyTrack(const UMovieScenePropertyTrack* PropertyTrack, float MinValue, float MaxValue);

	UFUNCTION()
	bool CheckCameraProperties(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool CheckPostProcessOverride(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	static float GetStartFrameSeconds(UMovieSceneSection* Section);

	UFUNCTION()
	bool CheckNiagaraStartTime(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckCollision(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckEmptyCameraCutsFrame(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	static bool CheckCameraCutTrack(const UMovieScene* MovieScene, FFrameNumber LevelSequenceEnd);
	static bool CheckCameraCutCoverage(const UMovieScene* MovieScene, FFrameNumber LevelSequenceEnd);
	static bool CheckShotTracks(const UMovieScene* MovieScene, FFrameNumber LevelSequenceEnd);
	static bool CheckShotsCoverage(const UMovieScene* MovieScene, FFrameNumber LevelSequenceEnd);
	static bool DoesSectionCoverFrame(const UMovieSceneSection* Section, FFrameNumber TargetFrame);
	static bool DoesShotSectionCoverFrame(const UMovieSceneSection* Section, FFrameNumber TargetFrame);
	static FFrameNumber CalculateSubSequenceTime(const UMovieSceneCinematicShotSection* ShotSection, FFrameNumber TargetFrame);
	static bool CheckSubSequenceCameraCutAtTime(const UMovieScene* SubMovieScene, FFrameNumber Time);

	UFUNCTION()
	bool CheckCameraCutSectionOverlapping(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool CheckCameraConstrainAspectRatio(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

private:
	UPROPERTY(Transient)
	TArray<AActor*> PossessableActors;

	UPROPERTY(Transient)
	TArray<AActor*> SpawnableActors;

	UPROPERTY(Transient)
	TMap<FGuid, AActor*> BindingActors;
	
	TMap<FString, TArray<FString>> OverridablePostProcessPropertyNames;
};
