// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "NiagaraEmitter.h"
#include "ResourceCheck/RuleBase.h"
#include "ViewModels/Stack/NiagaraStackModuleItem.h"
#include "NiagaraEmitterHandle.h"
#include "NiagaraRule.generated.h"

// Niagara attribute check functions
USTRUCT(BlueprintType)
struct FNiagaraCallableRule
{
	GENERATED_BODY()

public:
	TFunction<FString(FStructOnScope*)> Func;
};


UCLASS()
class KGRESOURCEMANAGER_API UNiagaraRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("Niagara");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	virtual bool PostExecuteAsset(const FAssetData& AssetData) override;

public:
	UFUNCTION()
	bool NiagaraMeshScaleCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool NiagaraGPUEmitterCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool NiagaraEmitterScalabilityCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool EmitterScalabilityEpicCinematicSelectedCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckEmitterMeshNanite(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool NiagaraEmitterAllocationModeCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckLightRenderer(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckFixedBound(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckRendererCameraDistanceCulling(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairRendererCameraDistanceCulling(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	UFUNCTION()
	FString IsInNoCullingWhiteList(const FAssetData& AssetData);

	UFUNCTION()
	bool CheckEmitterSpawnCount(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairEmitterSpawnCount(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

	UFUNCTION()
	bool CheckCollisionModule(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	static TArray<UNiagaraStackModuleItem*> GetAllCollisionModules(const TSharedPtr<FNiagaraSystemViewModel>& SystemViewModel, const FNiagaraEmitterHandle& Handle);

	UFUNCTION()
	bool RepairCollisionModule(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

private:
	TArray<FString> CheckCustomizedModuleAttribute(UObject* InNiagaraStackModuleItem, TMap<FString, FNiagaraCallableRule> CustomizedCheckRules);

private:
	// 在 PreExecuteAsset 阶段初始化出来、 PostExecuteAsset 阶段销毁，避免在 Check 的时候被析构掉了
	// 否则会导致 NiagaraStackModuleItem->GetParameterInputs 获得的为空
	TSharedPtr<FNiagaraSystemViewModel> SystemViewModel;

	// cppcheck:push ignore
	int32 NumQualityLevels;
	TArray<int32> QualityLevelsNumActive;
	TArray<TArray<FVersionedNiagaraEmitterData*>> QualityLevelsEmitters;
	TArray<TArray<FNiagaraEmitterHandle*>> QualityLevelsEmitterHandles;

	TMap<FGuid, TArray<UTexture*>> DependedTextureArray;
	TMap<FGuid, TArray<USkeletalMesh*>> DependedSkeletalMeshArray;
	TMap<FGuid, TArray<UNiagaraStackModuleItem*>> CollisionModuleItems;
	TMap<FGuid, int32> NumTotalTriangles;
	TMap<FGuid, TArray<UNiagaraStackModuleItem*>> StackModuleItems;
	TArray<FString> NoCullingWhiteList;
	// cppcheck:pop
};
