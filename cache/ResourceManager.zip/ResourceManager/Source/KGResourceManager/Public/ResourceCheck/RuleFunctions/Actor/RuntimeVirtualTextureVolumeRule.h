#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleFunctions/Actor/ActorRule.h"
#include "RuntimeVirtualTextureVolumeRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API URuntimeVirtualTextureVolumeRule : public UActorRule
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;
	
	virtual FString GetRuleName() override { return TEXT("RuntimeVirtualTextureVolume"); }

	UFUNCTION()
	FString IsMobileRVT(const FAssetData& AssetData);

	UFUNCTION()
	FString GetMaxAxisScale(const FAssetData& AssetData);

	UFUNCTION()
	FString GetVirtualTextureSize(const FAssetData& AssetData);
};