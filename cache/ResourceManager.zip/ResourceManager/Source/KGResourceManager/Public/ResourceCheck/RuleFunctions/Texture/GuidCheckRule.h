// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "ISourceControlState.h"
#include "ResourceCheck/RuleFunctions/Texture/TextureAssetRuleBase.h"
#include "GuidCheckRule.generated.h"

struct FTextureStatus
{
	FGuid Guid;
	FSourceControlStatePtr State;
	FString AbsoluteFilePath;
	TWeakObjectPtr<UTexture> Texture;
	FAssetData AssetData;
	FString LoadObjectPath;
};

UCLASS()
class KGRESOURCEMANAGER_API UGuidCheckRule : public URuleBase
{
	GENERATED_BODY()
	using FVoidCallback = TFunction<void()>;
public:

	virtual UClass* GetAssetType() override;

	UFUNCTION()
	bool TextureGuidCheck(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
		
	// 前处理
	virtual void PreCheckIn(TArray<FAssetData> InFiles, TSharedPtr<FPerforceSourceControlProviderDelegatesPackage> InPackage) override;
	
	// 后处理
	virtual void PostCheckIn(TArray<FAssetData> InFiles, TSharedPtr<FPerforceSourceControlProviderDelegatesPackage> InPackage) override;
	
	void GetGuidDataByHttp(FTextureStatus InTextureStatus, FEvent* GetGuidDataByHttpEvent, FVoidCallback Callback);
	
	void SendGuidDataByHttp(FEvent* SendGuidDataByHttpEvent, FVoidCallback Callback);

	UFUNCTION()
	bool RepairGuid(const FAssetData& AssetData, const TMap<FString, FString>& Arguments);

public:
	TMap<FString, FTextureStatus> LoadObjectNameToTextureStatus;
	TMap<FGuid, FString> GuidToLoadObjectName;
	FString ProjectName;
	FString BranchName;
};
