#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "Engine/PostProcessVolume.h"
#include "PostProcessVolumeRule.generated.h"

/**
 * 统一的 PostProcessVolume 检查规则
 * - 主入口：CheckPostProcessVolumeOverrides（读取插件配置 INI，判断哪些属性允许被覆盖）
 */
UCLASS()
class UPostProcessVolumeRule : public URuleBase
{
	GENERATED_BODY()

public:
	// 返回该规则关注的 Actor 类型
	virtual UClass* GetAssetType() override;
	void LocalLogViolation(const FAssetData* AssetData, const FString& ModuleName, const FString& SubCategory, const FString& PropDisplay, const
	                       FString& VolumeName);

	// 统一检查入口（覆盖基类签名）
	UFUNCTION()
	bool CheckPostProcessVolumeOverrides(const FAssetData& AssetData, TMap<FString, FString>& RepairParams);
};
