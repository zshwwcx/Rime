﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleFunctions/Actor/ActorRule.h"
#include "NiagaraActorRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API UNiagaraActorRule : public UActorRule
{
	GENERATED_BODY()

public:

	virtual UClass* GetAssetType() override;

	UFUNCTION()
	bool CheckNiagaraEffectType(const FAssetData& AssetData, TMap<FString, FString>& RepairParams);
};
