﻿#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "ASAAssetRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API UASAAssetRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("ASAAsset");}

	UFUNCTION()
	bool CheckNiagaraEffectType(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};