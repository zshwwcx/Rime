#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "NiagaraMaterialFlagRule.generated.h"


UCLASS()
class KGRESOURCEMANAGER_API UNiagaraMaterialFlagRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("NiagaraMaterialDependency");}

	UFUNCTION()
	bool CheckMaterialFlag(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMeshRendererOverrideMaterial(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);
};