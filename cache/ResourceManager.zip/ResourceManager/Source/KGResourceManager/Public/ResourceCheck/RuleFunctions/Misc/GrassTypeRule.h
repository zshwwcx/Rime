// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "LandscapeGrassType.h"
#include "GrassTypeRule.generated.h"

/**
 * 
 */
UCLASS()
class KGRESOURCEMANAGER_API UGrassTypeRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;
	virtual FString GetRuleName() override {return TEXT("GrassType");};
	
	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;
	
	bool HasForceWPOMaterial(const FStaticMaterial& StaticMaterial);
	bool HasFoliageMaterial(const FStaticMaterial& StaticMaterial);
	
	UFUNCTION()
	bool FoliageMaterialEnableNantieSupport(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool FoliageMaterialPreserveArea(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool FoliageMaterialCastDynamicShadow(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool ForceWPOMaterialEnableNantieSupport(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool ForceWPOMaterialPreserveArea(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool ForceWPOMaterialReceivesDecals(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool ForceWPOMaterialCastContactShadow(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool UnForceWPOMaterialWPODisableDistance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairGrassType(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairGrassMesh(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckCullDistance(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairCullDistance(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);
	
protected:
	
	TArray<FString> ForceWPOMaterial;
	TArray<FString> FoliageMaterial;	
	int32 WPODisableDistance; 
};
