// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "BinkMediaPlayerFolderRule.generated.h"

/**
 * 
 */
UCLASS()
class KGRESOURCEMANAGER_API UBinkMediaPlayerFolderRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	UFUNCTION()
	bool CheckAssetClass(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};
