// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleFunctions/Actor/ActorRule.h"
#include "SkeletalMeshComponentRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API USkeletalMeshComponentRule : public UActorRule
{
	GENERATED_BODY()

public:
	virtual bool PreExecuteAllObject(TArray<FAssetData>& InAssetDataList) override;

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	virtual FString GetRuleName() override { return TEXT("SkeletalMeshComponent"); }
	
	UFUNCTION()
	bool CheckRVT(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckSkeletalMeshValid(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckVisibilityBasedAnimTickOption(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairVisibilityBasedAnimTickOption(const FAssetData& AssetData, const TMap<FString, FString>& InRepairParams);

	TArray<FString> VisibilityBasedAnimTickOptionWL;
};
