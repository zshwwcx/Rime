#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "TAPathSubmitCheckRule.generated.h"


UCLASS()
class KGRESOURCEMANAGER_API UTAPathSubmitCheckRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("TAPathSubmitCheckRule");}

	UFUNCTION()
	bool CheckP4Groups(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};