#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "ResourceCheck/RuleFunctions/Texture/TextureAssetRuleBase.h"
#include "TextureCubeRule.generated.h"


UCLASS()
class KGRESOURCEMANAGER_API UTextureCubeRule : public UTextureAssetRuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("TextureCubeRule");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;

	UFUNCTION()
	FString IsNeedCheck(const FAssetData& AssetData);

	UFUNCTION()
	bool CheckCookPath(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	FString GetStandMaximumTextureSize(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandMipGenSetting(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandTextureGroup(const FAssetData& AssetData);

	UFUNCTION()
	FString GetStandCompressionSettings(const FAssetData& AssetData);

	UFUNCTION()
	FString GetTextureCubeMaxInGameSize(const FAssetData& AssetData);

	bool bNeedCheck=false;

	FString MaximumTextureSize;
	FString MipGenSetting;
	FString TextureGroup;
	FString CompressionSettings;

	bool bNeverCook=false;
	bool bNeedCook=false;
};