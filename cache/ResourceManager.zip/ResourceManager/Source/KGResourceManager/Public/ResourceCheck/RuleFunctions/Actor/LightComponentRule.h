﻿#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleFunctions/Actor/ActorRule.h"
#include "LightComponentRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API ULightComponentRule : public UActorRule
{
	GENERATED_BODY()

public:
	UFUNCTION()
	bool CheckComponentIntensityMappingForCharacter(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool RepairComponentIntensityMappingForCharacter(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);
};