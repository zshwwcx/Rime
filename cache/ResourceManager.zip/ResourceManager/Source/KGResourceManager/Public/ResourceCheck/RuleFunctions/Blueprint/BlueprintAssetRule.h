#pragma once

#include "ResourceCheck/RuleBase.h"
#include "BlueprintAssetRule.generated.h"

UCLASS()
class UBlueprintAssetRule : public URuleBase
{
	GENERATED_BODY()

public:
	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("BlueprintAsset");}

	UFUNCTION()
	bool CheckStaticMeshNotEmpty(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckStaticMeshComp(const FAssetData& AssetData, const TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckMaterialInstanceDynamic(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
};

