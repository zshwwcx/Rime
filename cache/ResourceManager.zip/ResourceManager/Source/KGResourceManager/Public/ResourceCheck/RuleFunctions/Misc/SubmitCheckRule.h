// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/RuleBase.h"
#include "SubmitCheckRule.generated.h"

UCLASS()
class KGRESOURCEMANAGER_API USubmitCheckRule : public URuleBase
{
	GENERATED_BODY()

public:

	virtual UClass* GetAssetType() override;

	virtual FString GetRuleName() override {return TEXT("Object");}

	virtual bool PreExecuteAsset(const FAssetData& AssetData) override;
	
	UFUNCTION()
	bool P4Connected(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	UFUNCTION()
	bool CheckLinker(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckDependAssetInChangeList(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);

	UFUNCTION()
	bool CheckDependArtsTest(const FAssetData& AssetData, TMap<FString, FString>& OutRepairParams);
	
	bool IsNeverCook(const FString InPackageName);
};
