#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/Log/ResourceCheckLogManager.h"
#include "ResourceCheck/Repair/ResourceRepair.h"


struct FResourceCheckLogInfo
{
	FAssetData AssetData;
	
	FGuid RuleGuid;
	FString ResourcePath;
	
	FString Tag;
	FString Description;

	TEnumAsByte<ERMCheckRuleType> Level;

	// 用来做自动修复
	bool bAutoRepair = false;
	FResourceRepairData RepairData;
};

class FResourceCheckLogCollect
{
public:
	
	void Initialize();
	
	bool Log(const FAssetData AssetData, const FString Tag, ERMCheckRuleType ResourceCheckLogLevel, const FString StatusDesc);
	
	template<typename... Args>
	bool RegistryAndLog(FAssetData AssetData, const FString Tag, ERMCheckRuleType ResourceCheckLogLevel, const FString StatusDesc, Args... Params)
	{
		ParamArray.Empty();
		(ChangeType(Params),...);
		
		return Log(AssetData, Tag, ResourceCheckLogLevel, StatusDesc);
	}
	
	void Combine(FResourceCheckLogCollect& InLogCollect);
	void Combine(TArray<FResourceCheckLogInfo>& InLogList);
	void Sort();

	FString GetFilePathFromAssetData(const FAssetData AssetData);
	
private:
	
	template<typename T>
	void ChangeType(T ParamArg)
	{
		if constexpr(std::is_same<decltype(ParamArg), int>::value)
		{
			int ParamInt = ParamArg;
			ParamArray.Add(FString::FromInt(ParamInt));
		}
		else if constexpr(std::is_same<decltype(ParamArg), int32>::value)
		{
			int32 ParamInt = ParamArg;
			ParamArray.Add(FString::FromInt(ParamInt));
		}
		else if constexpr(std::is_same<decltype(ParamArg), int64>::value)
		{
			int64 ParamInt = ParamArg;
			ParamArray.Add(FString::FromInt(ParamInt));
		}
		else if constexpr(std::is_same<decltype(ParamArg), uint8>::value)
		{
			uint8 ParamInt = ParamArg;
			ParamArray.Add(FString::FromInt(ParamInt));
		}
		else if constexpr(std::is_same<decltype(ParamArg), uint32>::value)
		{
			uint32 ParamInt = ParamArg;
			ParamArray.Add(FString::FromInt(ParamInt));
		}
		else if constexpr(std::is_same<decltype(ParamArg), uint64>::value)
		{
			uint64 ParamInt = ParamArg;
			ParamArray.Add(FString::FromInt(ParamInt));
		}
		else if constexpr(std::is_same<decltype(ParamArg), float>::value)
		{
			float ParamFloat = ParamArg;
			ParamArray.Add(FString::SanitizeFloat(ParamFloat));
		}
		else if constexpr(std::is_same<decltype(ParamArg), double>::value)
		{
			double ParamFloat = ParamArg;
			ParamArray.Add(FString::SanitizeFloat(ParamFloat));
		}
		else if constexpr(std::is_same<decltype(ParamArg), FString>::value)
		{
			FString ParamString = ParamArg;
			ParamArray.Add(ParamString);
		}
		else if constexpr(std::is_same<decltype(ParamArg), FName>::value)
		{
			FName ParamName = ParamArg;
			ParamArray.Add(ParamName.ToString());
		}
		else if constexpr(std::is_same<decltype(ParamArg), FText>::value)
		{
			FText ParamText = ParamArg;
			ParamArray.Add(ParamText.ToString());
		}
		else
		{
			ParamArray.Add(TEXT("None"));
		}
	}
	
public:
	TArray<FResourceCheckLogInfo> LogInfos;
	TSet<FString> Tags;
private:
	TArray<FString> ParamArray;
};
