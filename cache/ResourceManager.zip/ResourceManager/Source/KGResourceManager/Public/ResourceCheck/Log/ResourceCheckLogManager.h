#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/ResourceCheckDataStruct.h"


class FResourceCheckLogManager
{

public:

	void SetNewGuid();

	FGuid GetGuid() {return LogManagerGuid;}

private:

	FGuid LogManagerGuid;
};
