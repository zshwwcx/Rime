#pragma once

#include "CoreMinimal.h"
#include "ResourceCheck/Log/ResourceCheckLogManager.h"
#include "ResourceCheck/ResourceCheckDataStruct.h"
#include "ResourceCheck/RuleBase.h"
#include "Lua/LuaEnv.h"
#include "ResourceCheck/ResourceCheckLuaObj.h"
#include "ResourceCheckSubsystem.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogKGResourceManager, Log, All);

UCLASS(Config = Editor)
class KGRESOURCEMANAGER_API UResourceCheckSubsystem : public UEditorSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	void InitRulesFromWeb(const ERMCheckRuleRange& InRuleRange);

	void InitRulesFromWeb(const ERMCheckRuleRange& InRuleRange, TArray<FString> EnableRuleNames);

    void CheckAssetsByFunction(const TArray<FAssetData>& AssetDataList,ERMCheckRuleRange RMCheckRuleRange);
	
	void CheckAssetsByContentMenu(const TArray<FAssetData>& AssetDataList);

	void CheckAssetsByPreSubmit(const TArray<FAssetData>& InFiles, const TSharedPtr<FPerforceSourceControlProviderDelegatesPackage>& InPackage);

	void OnPostAssetsSubmit(const TArray<FAssetData>& InFiles, const TSharedPtr<FPerforceSourceControlProviderDelegatesPackage>& InPackage);

	void RemoveAllResultsMessages();
	
	bool ShowCheckResultsInWidget();

	void RepairAssetsByContentMenu(const TArray<FAssetData>& AssetDataList);

	void RepairCheckedAssets();

	void CheckAssetsByCommandlet(TArray<FString>& EnableRules);

	static bool IsRuleCheckForAsset(const FAssetData& InAssetData, URuleBase* InRule);

	static TArray<FString> GetNeedCheckActorsPaths(const TSet<URuleBase*>& ActorRules);

	void CheckWPActorsByCommandlet(const TSet<URuleBase*>& ActorRules);
	void CheckWCActorsByCommandlet(const TSet<URuleBase*>& ActorRules);

	void CheckActorsByMapName(const FString& MapName, int32& SkippedNum, int32& CheckedNum);

	void CheckActor(const AActor* InActor, int32& SkippedNum, int32& CheckedNum);

	void RepairAssetsByCommandlet(TArray<FString>& EnableRules);

	FResourceCheckLogManager& GetLogManager(){return ResourceCheckLogManager;}

	UWorld* GetMessageTabWorld();

	void GetAssetDataLogInfo(TMap<FAssetData, TArray<FResourceCheckLogInfo>>& OutLogInfos)
	{
		OutLogInfos.Empty();
		for(auto CheckRule : CheckRules)
		{
			TArray<FResourceCheckLogInfo> LogList = CheckRule->GetLogList();
			for(auto Log : LogList)
			{
				OutLogInfos.FindOrAdd(Log.AssetData).Add(Log);
			}
		}
	}
	

private:
	void TriggerGCWhenNeed(int32& Counter, bool bForce=false) const;
	int32 CheckAssetsInternal(const TSet<FAssetData>& AssetDataList, bool bCheckFull=false);
	
	void CollectRuleReport(TWeakObjectPtr<URuleBase> RuleFunction, FRMRuleReport& RuleReport);

	void SaveRepairJsonData();

	void LoadRepairJsonData(FRMRepairJsonData& OutRepairJsonData);

public:
	TArray<FString> DataCheck(const TArray<UObject*>& CheckObjects, TMap<FString, FString>& OutRepairParams);
	bool DataRepair(UObject* RepairObject, const TMap<FString, FString>& Arguments);

private:
	void CreateResourceCheckLuaObj(class UWorld* InWorld);
	void ShutDownLuaState();
	
private:
	UPROPERTY()
	TArray<TObjectPtr<class URuleBase>> CheckRules;

	FResourceCheckLogManager ResourceCheckLogManager;

	// 当内存使用达到一定值时触发GC
	uint64 MemoryMinFreeVirtual = 2048 * 1024ULL * 1024ULL;
	uint64 MemoryMaxUsedVirtual= 98304 * 1024ULL * 1024ULL;
	uint64 MemoryMinFreePhysical= 2048 * 1024ULL * 1024ULL;

public:
	static FName ResourceCheckTabId;

	static FString RepairJsonDataSaveDir;
	
	static FString RepairJsonDataSavePath;

	static FString RepairJsonResultSavePath;

	TSet<FString> LuaDatas;

	UPROPERTY(Config)
	bool bSubmitEnabled=true;

	ERMCheckRuleRange RuleRange;
	
	FString BranchName;

private:
    UEditorLuaEnv *LuaEnv = nullptr;
	TWeakObjectPtr<UResourceCheckLuaObj> ResourceCheckLuaObj;

	UPROPERTY(Transient)
	UWorld* MessageTabWorld = nullptr;
};