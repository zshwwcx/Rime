#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "GameplayTagContainer.h"

#include "BattleSystem/Ability/BSAEnums.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSEditorStructs.generated.h"



USTRUCT(BlueprintType)
struct FBSASkillCreater
{
	GENERATED_USTRUCT_BODY()

public:
	// 新技能的ID
	UPROPERTY(VisibleDefaultsOnly)
	int32 NewSkillID = 0;

	// 技能时长
	UPROPERTY(EditDefaultsOnly)
	float SkillDuration = 5.0f;

	// 新技能是否需要同步
	UPROPERTY(EditDefaultsOnly)
	bool bNeedReplicated = true;

	// 新技能的类型
	UPROPERTY(EditDefaultsOnly)
	EBSASkillType SkillType = EBSASkillType::ST_Battle;

	// 技能标签
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FGameplayTagContainer SkillGameplayTag;

	UPROPERTY(EditDefaultsOnly, Meta = (Bitmask, BitmaskEnum = "/Script/Engine.EMovementMode"))
	int32 MovementMode = 0;

	// 扩展数据
	UPROPERTY(EditDefaultsOnly, Instanced)
	class UBSAAssetExpandData* ExpandData = nullptr;

	// Task列表
	UPROPERTY(EditDefaultsOnly, Instanced)
	TArray<UBSATask*> TaskList;

	friend uint32 GetTypeHash(const FBSASkillCreater& s)
	{
		return GetTypeHash(s.NewSkillID);
	}

	bool operator == (const FBSASkillCreater& Other) const
	{
		return NewSkillID == Other.NewSkillID;
	}
};
