#pragma once

#include "Commandlets/Commandlet.h"



#include "BSExportCommandlet.generated.h"



UCLASS()
class UBSExportCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	UBSExportCommandlet();

public:
	virtual int32 Main(const FString& Params) override;

	void Init();

	void UnInit();

public:
	// 导出有EnumToExport标记的蓝图枚举和EBS相关的C++枚举
	void ExportEnum();

	// 导出战斗技能和Buff相关数据
	void ExportBattleData();

private:
	void ParseParam(const FString& Params);

	bool bExportEnum = false;
	bool bExportBattleData = false;

	class UEditorLuaEnv *LuaEnv = nullptr;

};
