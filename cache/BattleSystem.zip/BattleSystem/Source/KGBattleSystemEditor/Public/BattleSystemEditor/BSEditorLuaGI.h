#pragma once

#include "CoreMinimal.h"

#include "EngineUtils.h"
#include "Camera/CameraActor.h"
#include "Camera/PlayerCameraManager.h"
#include "Runtime/CinematicCamera/Public/CineCameraActor.h"
#include "GameFramework/PlayerController.h"

#include "BattleSystemEditor/BSEditorLuaBasicGI.h"

#include "BSEditorLuaGI.generated.h"



UCLASS(BlueprintType, Blueprintable)
class KGBATTLESYSTEMEDITOR_API UBSEditorLuaGI : public UBSEditorLuaBasicGI
{
	GENERATED_BODY()

#pragma region Important
public:
	virtual FString GetLuaFilePath_Implementation() const override
	{
		return TEXT("Gameplay.BattleSystem.Editor.E_GameInstance");
	}

#pragma endregion Important



#pragma region Preview
public:
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	void OnPreviewActorSpawned(AActor* NewActor, class UBSAPreviewActor* ThePreview);

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	void OnPreviewEnvironmentActorSpawned(AActor* NewActor, class UBSAPreviewActor* ThePreview);

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	void OnWillDestroyPreviewActor(AActor* TheActor);

	UFUNCTION(BlueprintImplementableEvent)
	void PlayerLockTarget(AActor* InPlayer, AActor* InTarget);

	UFUNCTION(BlueprintImplementableEvent)
	int64 PreviewBuff(AActor* Actor, int32 ID, const TArray<USceneComponent*>& LockParts);

	UFUNCTION(BlueprintImplementableEvent)
	void StopPreviewBuff(AActor* Actor, int64 InGID);

	UFUNCTION(BlueprintImplementableEvent)
	int64 PreviewSkill(AActor* Actor, int32 ID, const TArray<USceneComponent*>& LockParts);

	UFUNCTION(BlueprintImplementableEvent)
	void StopPreviewSkill(AActor* Actor, int64 InGID);

	UFUNCTION(BlueprintImplementableEvent)
	void PlayAnimationAndNiagaraInSection(AActor* Actor, int64 GID, float PreTime, float ClickTime);

#pragma endregion Preview



#pragma region Optimize
public:
	// 检查BuffAction是否合法
	UFUNCTION(BlueprintImplementableEvent)
	bool CheckIsBuffActionValid(int32 BuffID, int32  BuffActionID);

	// 检查Attack的SkillAction是否合法
	UFUNCTION(BlueprintImplementableEvent)
	bool CheckIsSkillActionValid(int32 SkillID, int32  SkillActionID);

#pragma endregion Optimize



#pragma region Camera
public:
	// 使用过场动画镜头
	UFUNCTION(BlueprintCallable)
	void SwitchToSequencerCamera()
	{
		UWorld* CurrentWorld = GetWorld();
		if (!CurrentWorld)
		{
			return;
		}

		ACineCameraActor* CCA = nullptr;
		for (TActorIterator<ACameraActor> It(CurrentWorld); It; ++It)
		{
			if (It->IsA<ACineCameraActor>())
			{
				CCA = Cast<ACineCameraActor>(*It);
				break;
			}
		}

		for (TActorIterator<APlayerController> It(CurrentWorld); It; ++It)
		{
			if (It->PlayerCameraManager)
			{
				It->PlayerCameraManager->SetViewTarget(CCA);
				break;
			}
		}
	}

#pragma endregion Camera

};
