#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Input/SComboBox.h"

#include "BattleSystem/Ability/Task/BSATaskStructs.h"



class FDetailWidgetRow;



class KGBATTLESYSTEMEDITOR_API FBSATaskSelectorLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FBSATaskSelectorLayout());
	}

	// IPropertyTypeCustomization interface
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils);
	// End of IPropertyTypeCustomization interface

	FBSATaskSelector* GetRawStructData(TSharedRef<IPropertyHandle> InPropertyHandle);
	void SetTaskName(FName NewTaskName);

private:
	TSharedPtr<IPropertyHandle> PropertyHandle;
};






class KGBATTLESYSTEMEDITOR_API FBSATaskParameterizedPropertyLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FBSATaskParameterizedPropertyLayout());
	}

	// IPropertyTypeCustomization interface
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils);
	// End of IPropertyTypeCustomization interface

private:
	TSharedPtr<IPropertyHandle> PropertyHandle;
};






class KGBATTLESYSTEMEDITOR_API FBSATransformCreaterLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FBSATransformCreaterLayout());
	}

	// IPropertyTypeCustomization interface
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils);
	// End of IPropertyTypeCustomization interface

private:
	TSharedPtr<IPropertyHandle> PropertyHandle;
};

