#pragma once
#include "CoreMinimal.h"
#include "DetailWidgetRow.h"
#include "IPropertyTypeCustomization.h"

#include "BattleSystem/BSStructs.h"

#include "BattleSystem/BSBeatenPerformanceAsset.h"



class FBeatenPerformanceLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FBeatenPerformanceLayout());
	}

	// IPropertyTypeCustomization interface
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) {}
	// End of IPropertyTypeCustomization interface

};






class FBSSelectTargetInfoLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FBSSelectTargetInfoLayout());
	}

	// IPropertyTypeCustomization interface
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) {}
	// End of IPropertyTypeCustomization interface

};






class FBSSocketSelectorLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FBSSocketSelectorLayout());
	}

	// IPropertyTypeCustomization interface
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) {}
	// End of IPropertyTypeCustomization interface

protected:
	FText GetSocketName() const;

	bool CanChangeSocket() const;

	void OnBrowseSocket();

	void OnClearSocket();

	void OnSocketSelection(FName SocketName);

	FBSSocketSelector* GetRawStructData() const;

private:
	TSharedPtr<IPropertyHandle> PropertyHandle;

	FDetailWidgetRow* HeaderWidget = nullptr;

};
