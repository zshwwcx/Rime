#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Text/STextBlock.h"

DECLARE_DELEGATE_OneParam(FOnAddTaskTemplateDelegate, FName);

// TaskGroup选择器
class SBSTaskGroupPicker : public SCompoundWidget
{
public:
	//DECLARE_DELEGATE_OneParam(FOnAddTaskTemplateDelegate, FName);

public:
	SLATE_BEGIN_ARGS(SBSTaskGroupPicker)
	{

	}
	SLATE_ARGUMENT(TArray<TSharedPtr<FName>>, AllTemplateNames)
	SLATE_EVENT(FOnAddTaskTemplateDelegate, AddTemplateEvent)
	SLATE_END_ARGS()

	virtual void Construct(const FArguments& InArgs);

public:
	TSharedRef<SWidget> OnGenerateComboWidget(TSharedPtr<FName> InComboID)
	{
		if (InComboID.IsValid())
			return SNew(STextBlock).Text(FText::FromName(*InComboID));

		return SNew(STextBlock).Text(FText());
	}

	void OnComboSelectionChanged(TSharedPtr<FName> NewValue, ESelectInfo::Type SelectInfo)
	{
		if (NewValue.IsValid())
		{
			SelectedName = *NewValue.Get();
			AddTemplateEvent.ExecuteIfBound(SelectedName);
		}
	}

	FText GetSelectTaskName() const
	{
		return FText::FromName(SelectedName);
	}

private:
	void SetFilterName(const FText& NewSubjectName);

private:
	TArray<TSharedPtr<FName>> AllTemplateNames;

	TArray<TSharedPtr<FName>> FilteredTemplateNames;

	FName FilterName;

	FName SelectedName;

	FOnAddTaskTemplateDelegate AddTemplateEvent;
};