#pragma once

#include "CoreMinimal.h"
#include "SGraphNode.h"
#include "Components/HorizontalBox.h"

class UEdNode_DecisionTreeNode;

class SEdNode_DecisionTreeNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SEdNode_DecisionTreeNode) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, UEdNode_DecisionTreeNode* InNode);

	virtual void UpdateGraphNode() override;
	virtual void CreatePinWidgets() override;
	virtual void AddPin(const TSharedRef<SGraphPin>& PinToAdd) override;
	virtual bool IsNameReadOnly() const override;

	void OnNameTextCommited(const FText& InText, ETextCommit::Type CommitInfo);

	virtual FSlateColor GetBorderBackgroundColor() const;
	virtual FSlateColor GetBackgroundColor() const;

	virtual EVisibility GetDragOverMarkerVisibility() const;

	virtual const FSlateBrush* GetNameIcon() const;

protected:
	FText GetNodeTitle() const;

	TSharedPtr<SBorder> NodeBody;
	TSharedPtr<SHorizontalBox> OutputPinBox;
};
