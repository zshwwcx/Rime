#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeEdge.h"

#include "PassiveSkillTreeTemplate.generated.h"



UCLASS(Abstract)
class UPassiveSkillTreeTypeMessage : public UDTTypeMessage
{
	GENERATED_BODY()

public:
	UPassiveSkillTreeTypeMessage();

};



UCLASS()
class UPassiveSkillTreeTemplate : public UDecisionTreeTemplate
{
	GENERATED_BODY()

	
public:

	//常驻被动
	UPROPERTY(EditDefaultsOnly, Category = "Thumbnail Helper")
	bool PermanentPassive = true;

	UPROPERTY(EditDefaultsOnly, Category = "Thumbnail Helper")
	bool CheckNotInSkillSlot = false;

	UPassiveSkillTreeTemplate()
	{
		TypeMessage = UPassiveSkillTreeTypeMessage::StaticClass();
	}
};
