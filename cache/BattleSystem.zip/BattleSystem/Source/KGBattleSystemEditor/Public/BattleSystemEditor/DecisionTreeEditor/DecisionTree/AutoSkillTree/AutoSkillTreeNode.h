#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeNode.h"

#include "BattleSystemEditor/BSEditorStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"

#include "AutoSkillTreeNode.generated.h"



UCLASS()
class UAutoSkillTreeRootNode : public UDecisionTreeNode
{
	GENERATED_BODY()

public:
	UAutoSkillTreeRootNode();

#if WITH_EDITOR
public:
	void SetNodeTitle(const FText& NewTitle) override;

	virtual bool CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage) override;

	virtual bool CanUserDelete() const override;

#endif

};



UCLASS()
class UAutoSkillTreeNode : public UDecisionTreeNode
{
	GENERATED_BODY()
	
public:
	UAutoSkillTreeNode();

public:
	// 要释放的技能
	UPROPERTY(EditDefaultsOnly, Category = "Common")
	TArray<TSoftObjectPtr<class UASASkillAsset>> ReleaseSkillAssets;

#if WITH_EDITOR
public:
	void CopyData(UDecisionTreeNode* OtherNode) override;

	void RefreshNodeTitle() override;

	void SetNodeTitle(const FText& NewTitle) override;

	virtual bool CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage) override;

protected:
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;

#endif
};
