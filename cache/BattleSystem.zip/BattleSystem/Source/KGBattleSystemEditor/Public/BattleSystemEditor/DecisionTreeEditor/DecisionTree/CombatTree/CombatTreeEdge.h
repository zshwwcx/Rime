#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"

#include "KGAbilitySystemEditor/AbilityEditor/Ability/ASASkillAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"

#include "CombatTreeEdge.generated.h"



UCLASS()
class UCombatTreeEdge : public UDecisionTreeEdge
{
	GENERATED_BODY()

public:
	// 检查哪些技能的连招窗口
	UPROPERTY(EditDefaultsOnly)
	TArray<TSoftObjectPtr<UASASkillAsset>> ComboWindows;

#if WITH_EDITOR
public:
	void CopyData(UDecisionTreeEdge* OtherNode) override;

	void RefreshEdgeTitle() override;

	void SetEdgeTitle(const FText& NewTitle) override;

	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

#endif

};
