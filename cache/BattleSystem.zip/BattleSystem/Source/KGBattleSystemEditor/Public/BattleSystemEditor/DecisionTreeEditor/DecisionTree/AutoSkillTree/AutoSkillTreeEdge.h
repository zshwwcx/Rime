#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"

#include "AutoSkillTreeEdge.generated.h"



UCLASS()
class UAutoSkillTreeEdge : public UDecisionTreeEdge
{
	GENERATED_BODY()

public:
	UAutoSkillTreeEdge();

public:
	// 该节点的一键连招检查条件
	UPROPERTY(EditDefaultsOnly, Instanced)
	UAutoSkillTreeConditionGroup* AutoSkillConditionGroup = nullptr;

#if WITH_EDITOR
public:
	void CopyData(UDecisionTreeEdge* OtherNode) override;

	void RefreshEdgeTitle() override;

	void SetEdgeTitle(const FText& NewTitle) override;

	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	static int32 GetTitle(TArray<UASACondition*> InConditions, int32 InStartSpace, FString& InTitle);

#endif

};