#pragma once

#include "CoreMinimal.h"
#include "Framework/MultiBox/MultiBoxExtender.h"

class FDecisionTreeEditor;
class FExtender;
class FToolBarBuilder;


class FDecisionTreeEditorToolbar : public TSharedFromThis<FDecisionTreeEditorToolbar>
{
public:
	FDecisionTreeEditorToolbar(TSharedPtr<FDecisionTreeEditor> InDecisionTreeEditor) : DecisionTreeEditor(InDecisionTreeEditor) {}

	void AddGraphToolbar(TSharedPtr<FExtender> Extender);

private:
	void FillGraphToolbar(FToolBarBuilder& ToolbarBuilder);

protected:
	TWeakPtr<FDecisionTreeEditor> DecisionTreeEditor;

};