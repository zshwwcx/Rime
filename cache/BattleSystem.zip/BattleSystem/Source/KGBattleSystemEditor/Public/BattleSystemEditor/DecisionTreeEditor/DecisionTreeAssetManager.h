#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeExporter.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeTemplate.h"

#include "DecisionTreeAssetManager.generated.h"


UCLASS(Blueprintable, BlueprintType)
class UDecisionTreeAssetManager : public UObject
{
	GENERATED_BODY()

public:
	void Init();

	void UnInit();

	static UDecisionTreeAssetManager* GetInstance();

public:
	// 捕获所有资源的路径
	void FindAllDecisionTreePath();



	// 获取所有的出招表ID
	TArray<int32> GetCombatTreeList();

	// 根据ID获取出招表资源
	UCombatTreeTemplate* GetCombatTreeAssetByID(int32 ID);

	// 根据ID获取出招表软指针
	TSoftObjectPtr<UCombatTreeTemplate>GetCombatTreeAssetSoftObjectByID(int32 ID);



	// 获取所有的一键连招表ID
	TArray<int32> GetAutoSkillTreeList();

	// 根据ID获取一键连招表资源
	UAutoSkillTreeTemplate* GetAutoSkillTreeAssetByID(int32 ID);

	// 根据ID获取一键连招表软指针
	TSoftObjectPtr<UAutoSkillTreeTemplate>GetAutoSkillTreeAssetSoftObjectByID(int32 ID);



	// 获取所有的受击树ID
	TArray<int32> GetBeatenTreeList();

	// 根据ID获取受击树资源
	UBeatenTreeTemplate* GetBeatenTreeAssetByID(int32 ID);

	// 根据ID获取Buff软指针
	TSoftObjectPtr<UBeatenTreeTemplate>GetBeatenTreeAssetSoftObjectByID(int32 ID);

	// 获取所有的被动技能树ID
	TArray<int32> GetPassiveSkillTreeList();

	// 根据ID获取被动技能树资源
	UPassiveSkillTreeTemplate* GetPassiveSkillTreeAssetByID(int32 ID);

	// 根据ID获取被动技能表软指针
	TSoftObjectPtr<UPassiveSkillTreeTemplate>GetPassiveSkillTreeAssetSoftObjectByID(int32 ID);

	// 导出数据
	void ExportCombatTreeData(int32 ID);

	void ExportAutoSkillTreeData(int32 ID);

	void ExportBeatenTreeData(int32 ID);

	void ExportPassiveSkillTreeData(int32 ID);

private:
	bool bActive = false;

	// 出招表资源路径查询表
	UPROPERTY(Transient)
	TMap<int32, TSoftObjectPtr<class UCombatTreeTemplate>> CombatTreePathMap;

	// 一键连招表资源路径查询表
	UPROPERTY(Transient)
	TMap<int32, TSoftObjectPtr<class UAutoSkillTreeTemplate>> AutoSkillTreePathMap;

	// 受击树资源路径查询表
	UPROPERTY(Transient)
	TMap<int32, TSoftObjectPtr<class UBeatenTreeTemplate>> BeatenTreePathMap;

	// 被动技能树资源路径查询表
	TMap<int32, TSoftObjectPtr<class UPassiveSkillTreeTemplate>> PassiveSkillTreePathMap;

	UPROPERTY(Transient)
	TSoftObjectPtr<class UCombatTreeExporter> CombatTreeExporter = nullptr;

	UPROPERTY(Transient)
	TSoftObjectPtr <class UAutoSkillTreeExporter> AutoSkillTreeExporter = nullptr;

	UPROPERTY(Transient)
	TSoftObjectPtr <class UBeatenTreeExporter> BeatenTreeExporter = nullptr;

	UPROPERTY(Transient)
	TSoftObjectPtr <class UPassiveSkillTreeExporter> PassiveSkillTreeExporter = nullptr;

};
