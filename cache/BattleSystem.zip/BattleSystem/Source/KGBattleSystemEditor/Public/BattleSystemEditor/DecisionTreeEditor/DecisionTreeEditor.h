#pragma once

#include "Misc/NotifyHook.h"
#include "GraphEditor.h"
#include "EdGraphUtilities.h"
#include "Toolkits/AssetEditorToolkit.h"

#include "ClassViewerFilter.h"

#include "Widgets/Docking/SDockTab.h"
#include "Widgets/DeclarativeSyntaxSupport.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeExporter.h"



class FDecisionTreeEditor : public FAssetEditorToolkit, public FNotifyHook, public FGCObject
{
public:
	FDecisionTreeEditor();
	virtual ~FDecisionTreeEditor();

	void InitEditor(const EToolkitMode::Type Mode, const TSharedPtr<IToolkitHost>& InitToolkitHost, UDecisionTreeTemplate* InTreeTemp);


	// IToolkit interface
	virtual void RegisterTabSpawners(const TSharedRef<FTabManager>& TabManager) override;
	virtual void UnregisterTabSpawners(const TSharedRef<FTabManager>& TabManager) override;
	// End of IToolkit interface


	// FAssetEditorToolkit
	virtual void OnClose() override;
	virtual FName GetToolkitFName() const override;
	virtual FText GetBaseToolkitName() const override;
	virtual FText GetToolkitName() const override;
	virtual FText GetToolkitToolTipText() const override;
	virtual FLinearColor GetWorldCentricTabColorScale() const override;
	virtual FString GetWorldCentricTabPrefix() const override;
	virtual FString GetDocumentationLink() const override;
	virtual void SaveAsset_Execute() override;
	// End of FAssetEditorToolkit


	TSharedPtr<class FDecisionTreeEditorToolbar> GetToolbarBuilder() { return ToolbarBuilder; }
	void RegisterToolbarTab(const TSharedRef<class FTabManager>& TabManager);

	// FSerializableObject interface
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	// End of FSerializableObject interface

	virtual FString GetReferencerName() const { return "FDecisionTreeEditor"; };

private:
	TSharedRef<SDockTab> SpawnTab_Viewport(const FSpawnTabArgs& Args);
	TSharedRef<SDockTab> SpawnTab_Details(const FSpawnTabArgs& Args);
	TSharedRef<SDockTab> SpawnTab_EditorSettings(const FSpawnTabArgs& Args);

	// 创建主要的编辑窗口
	void CreateMainEditWidgets();
	// 创建新的节点编辑窗口
	bool CreateViewportWidget(FString ViewportName, UEdGraph* OwnerGraph);


	void BindCommands();

	void CreateEdGraph(UObject* TheOwner, UEdGraph*& TheGraphPtr);

	void CreateCommandList();

	TSharedPtr<SGraphEditor> GetCurrentGraphEditor() const;

	FGraphPanelSelectionSet GetSelectedNodes() const;

	void SelectAllNodes();
	bool CanSelectAllNodes();

	void DeleteNodes(FGraphPanelSelectionSet& SelectedNodes);
	void DeleteSelectedNodes();
	bool CanDeleteNodes();
	void DeleteSelectedDuplicatableNodes();

	void CutSelectedNodes();
	bool CanCutNodes();

	void CopySelectedNodes();
	bool CanCopyNodes();

	void PasteNodes();
	void PasteNodesHere(const FVector2D& Location);
	bool CanPasteNodes();

	void DuplicateNodes();
	bool CanDuplicateNodes();

	void OpenSelectNode();
	bool CanOpenSelectNode();

	// 回到上一层
	void BackToPreviousGraph();

	void GraphSettings();
	bool CanGraphSettings() const;

	void OnRenameNode();
	bool CanRenameNodes() const;

	void OnSelectedNodesChanged(const TSet<class UObject*>& NewSelection);

	void OnNodeDoubleClicked(UEdGraphNode* Node);

	void OnFinishedChangingProperties(const FPropertyChangedEvent& PropertyChangedEvent);

private:
	void PreSaveExecute();

	void RefreshGraphMessage(UEdGraph* CurSaveGraph);

	void CheckGraphNodeType(UEdGraph* CurSaveGraph);

	void CollectRootMessage(UEdGraph* CurSaveGraph, TArray<UDecisionTreeNode*>& RootNodes);


private:
	TWeakObjectPtr<UDecisionTreeTemplate> DecisionTreeTemplate = nullptr;

	TSharedPtr<class FDecisionTreeEditorToolbar> ToolbarBuilder;

	// 编辑窗口
	TSharedPtr<SDockTab> ViewportTab;
	// 编辑窗口栈
	TArray<TSharedPtr<SGraphEditor>> ViewportWidgetStack;

	TSharedPtr<class IDetailsView> PropertyWidget;
	TSharedPtr<class IDetailsView> EditorSettingsWidget;

	TSharedPtr<FUICommandList> GraphEditorCommands;



#pragma region ClassFilter
private:
	class FDTTypeFilter : public IClassViewerFilter
	{
	public:
		virtual bool IsClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const UClass* InClass, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			return InClass->IsChildOf<UDTTypeMessage>() && !InClass->HasAnyClassFlags(CLASS_Abstract);
		}

		virtual bool IsUnloadedClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const TSharedRef< const IUnloadedBlueprintData > InClass, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			return InClass->IsChildOf(UDTTypeMessage::StaticClass()) && !InClass->HasAnyClassFlags(CLASS_Abstract);
		}
	};

#pragma endregion ClassFilter



#pragma region Export
private:
	// 导出数据
	void ExportData();

private:
	static int32 DecisionTreeIndex;

	static int32 DecisionTreeNum;

	class UEditorLuaEnv *LuaEnv = nullptr;

	TWeakObjectPtr<class UDTBasicExporter> DataExporter = nullptr;

#pragma endregion Export

};