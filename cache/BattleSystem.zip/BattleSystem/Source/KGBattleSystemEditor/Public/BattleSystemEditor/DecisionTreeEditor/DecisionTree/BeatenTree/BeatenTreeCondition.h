#pragma once

#include "CoreMinimal.h"

#include "BattleSystem/BSEnums.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeCondition.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeCollector.h"

#include "BeatenTreeCondition.generated.h"



UCLASS()
class UBeatenTreeCondition : public UDecisionTreeCondition
{
	GENERATED_BODY()
	
public:
	// 比较硬直状态
	UPROPERTY(EditDefaultsOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bCheckStaggerState = false;
	UPROPERTY(EditDefaultsOnly, Meta = (Bitmask, BitmaskEnum = "/Script/KGBattleSystem.EBSStaggerState", EditCondition = "bCheckStaggerState"))
	int32 StaggerState = 0;

	// 比较攻击类型
	UPROPERTY(EditDefaultsOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bCheckAttackType = false;
	UPROPERTY(EditDefaultsOnly, Meta = (Bitmask, BitmaskEnum = "/Script/KGBattleSystem.EBSAttackType", EditCondition = "bCheckAttackType"))
	int32 AttackType = 0;

	// 比较攻击力度
	UPROPERTY(EditDefaultsOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bCheckAttackForce = false;
	UPROPERTY(EditDefaultsOnly, Meta = (Bitmask, BitmaskEnum = "/Script/KGBattleSystem.EBSAttackForce", EditCondition = "bCheckAttackForce"))
	int32 AttackForce = 0;

	// 比较相对位置
	UPROPERTY(EditDefaultsOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bCheckRelationType = false;
	UPROPERTY(EditDefaultsOnly, Meta = (Bitmask, BitmaskEnum = "/Script/KGBattleSystem.EBSAttackerLocationType", EditCondition = "bCheckRelationType"))
	int32 RelationType = 0;


public:
	UBeatenTreeCondition();

	// 外界调用的条件检查函数
	bool PerformCheck_Implementation(const FBSConditionData& InData) const override;


#if WITH_EDITOR
protected:
	bool CopyData(UBSCondition* OtherCondition) override;

	FString GetConditionDescription() override;

#endif

};
