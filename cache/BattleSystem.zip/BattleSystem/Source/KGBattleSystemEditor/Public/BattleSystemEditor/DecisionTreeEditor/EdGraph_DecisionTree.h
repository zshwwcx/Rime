#pragma once

#include "CoreMinimal.h"
#include "EdGraph/EdGraph.h"
#include "EdGraph_DecisionTree.generated.h"

class UDecisionTreeTemplate;

UCLASS()
class UEdGraph_DecisionTree : public UEdGraph
{
	GENERATED_BODY()

public:
	UEdGraph_DecisionTree();
	virtual ~UEdGraph_DecisionTree();

	virtual bool Modify(bool bAlwaysMarkDirty = true) override;
	virtual void PostEditUndo() override;

protected:
	void Clear();
};
