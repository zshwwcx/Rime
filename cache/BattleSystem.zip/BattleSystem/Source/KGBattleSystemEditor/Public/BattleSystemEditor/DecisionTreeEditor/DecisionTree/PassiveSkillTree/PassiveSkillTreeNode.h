#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeNode.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskEventListener.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "BattleSystem/Ability/PassiveSkillCondition.h"
#include "BattleSystem/Ability/PassiveSkillEvent.h"
#include "BattleSystemEditor/BSEditorStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"
#include "KGAbilitySystemEditor/Public/KGAbilitySystemEditor/AbilityEditor/Ability/Conditions/ASACondition.h"
#include "KGAbilitySystemEditor/Public/KGAbilitySystemEditor/AbilityEditor/Ability/Events/ASASkillEvent.h"
#include "PassiveSkillTreeNode.generated.h"

UENUM(BlueprintType)
enum class PassiveSkillConditionTargetType : uint8
{
	MySelf = 0,
	BeHitTargets,
	PriorityLockTargets,
	EnterTeamMembers,
	LeaveTeamMembers,
	TeamMembers,
};

UCLASS()
class UPassiveSkillEventNode : public UDecisionTreeNode
{
	GENERATED_BODY()

public:


	UPassiveSkillEventNode();

#if WITH_EDITOR
public:
	void SetNodeTitle(const FText& NewTitle) override;

	void CopyData(UDecisionTreeNode* OtherNode) override;
	
	virtual bool CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage) override;

	virtual bool CanUserDelete() const override;

	// 该节点的检查条件

	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Event")
	TArray<UPassiveSkillEvent*> EventGroup;

	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Event")
	TArray<UASASkillEvent*> ASAEventGroup;


	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;
#endif

};



UCLASS()
class UPassiveSkillTaskNode : public UDecisionTreeNode
{
	GENERATED_BODY()
	
public:
	UPassiveSkillTaskNode();

	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Event")
	UBSATask* TaskData;
public:


#if WITH_EDITOR
public:
	void CopyData(UDecisionTreeNode* OtherNode) override;

	void RefreshNodeTitle() override;

	void SetNodeTitle(const FText& NewTitle) override;

	virtual bool CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage) override;
protected:
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;

#endif
};


UCLASS()
class UPassiveSkillCondtionNode : public UDecisionTreeNode
{
	GENERATED_BODY()

public:
	UPassiveSkillCondtionNode();


	UPROPERTY(EditAnywhere, Instanced, Category = "Event")
	TArray<UPassiveSkillCondition*> ConditionDatas;

	UPROPERTY(EditAnywhere, Instanced, Category = "Event")
	TArray<UASACondition*> ASAConditionDatas;

	
	//技能开始时触发条件
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool NeedStartTrigger = true;

	//触发了被动也不计CD
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool NotCD;

	//触发概率
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Probability = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	PassiveSkillConditionTargetType TriggerActor = PassiveSkillConditionTargetType::MySelf;
public:

#if WITH_EDITOR
public:
	virtual bool CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage) override;

	void CopyData(UDecisionTreeNode* OtherNode) override;

	void RefreshNodeTitle() override;

	void SetNodeTitle(const FText& NewTitle) override;

protected:
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;

#endif
};
