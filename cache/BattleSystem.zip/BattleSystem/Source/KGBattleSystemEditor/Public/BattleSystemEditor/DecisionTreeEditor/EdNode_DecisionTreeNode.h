#pragma once

#include "CoreMinimal.h"
#include "EdGraph/EdGraphNode.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/SEdNode_DecisionTreeNode.h"

#include "EdNode_DecisionTreeNode.generated.h"

class UEdGraph_DecisionTree;
class UEdNode_DecisionTreeEdge;

class SEdNode_DecisionTreeNode;

UCLASS(MinimalAPI)
class UEdNode_DecisionTreeNode : public UEdGraphNode
{
	GENERATED_BODY()

public:
	UEdNode_DecisionTreeNode();
	virtual ~UEdNode_DecisionTreeNode();

	UPROPERTY(VisibleAnywhere, Instanced)
	UDecisionTreeNode* GraphNode;

	TWeakPtr<SEdNode_DecisionTreeNode> SEdNode;

	void SetDecisionTreeNode(UDecisionTreeNode* InNode);
	UEdGraph_DecisionTree* GetDecisionTreeEdGraph();

	// 创建节点的Pin脚
	virtual void AllocateDefaultPins() override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	virtual void PrepareForCopying() override;

	virtual FLinearColor GetBackgroundColor() const;
	virtual UEdGraphPin* GetPinByIndex(int32 InIndex) const;
	virtual int32 GetPinIndex(const UEdGraphPin* InPin) const;
	virtual UEdGraphPin* GetPinByName(FName InName) const;

	virtual bool CanUserDeleteNode() const;

	// 获取该节点的深度
	virtual int32 GetNodeDepth();

	void DestroyNode() override;

	virtual void PostEditUndo() override;
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

};
