#pragma once

#include "Factories/Factory.h"
#include "UObject/Object.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"

#include "DecisionTreeAssetFactory.generated.h"



UCLASS(HideCategories = Object, MinimalAPI)
class UDecisionTreeAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UDecisionTreeAssetFactory(const FObjectInitializer& ObjectInitializer);
	virtual ~UDecisionTreeAssetFactory();

	//~ Begin UFactory Interface
	virtual bool ConfigureProperties() override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;
	//~ Begin UFactory Interface	

public:
	UPROPERTY()
	UClass* DTTypeClassType = nullptr;

};






UCLASS(HideCategories = Object, MinimalAPI)
class UBeatenTreeAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UBeatenTreeAssetFactory(const FObjectInitializer& ObjectInitializer);
	virtual ~UBeatenTreeAssetFactory();

	//~ Begin UFactory Interface
	virtual bool ConfigureProperties() override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;
	//~ Begin UFactory Interface	

public:
	UPROPERTY()
	UClass* DTTypeClassType = NULL;

};






UCLASS(HideCategories = Object, MinimalAPI)
class UCombatTreeAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UCombatTreeAssetFactory(const FObjectInitializer& ObjectInitializer);
	virtual ~UCombatTreeAssetFactory();

	//~ Begin UFactory Interface
	virtual bool ConfigureProperties() override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;
	//~ Begin UFactory Interface	

public:
	UPROPERTY()
	UClass* DTTypeClassType = NULL;

};






UCLASS(HideCategories = Object, MinimalAPI)
class UAutoSkillTreeAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UAutoSkillTreeAssetFactory(const FObjectInitializer& ObjectInitializer);
	virtual ~UAutoSkillTreeAssetFactory();

	//~ Begin UFactory Interface
	virtual bool ConfigureProperties() override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;
	//~ Begin UFactory Interface	

public:
	UPROPERTY()
	UClass* DTTypeClassType = NULL;

};






UCLASS(HideCategories = Object, MinimalAPI)
class UPassiveSkillTreeAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UPassiveSkillTreeAssetFactory(const FObjectInitializer& ObjectInitializer);
	virtual ~UPassiveSkillTreeAssetFactory();

	//~ Begin UFactory Interface
	virtual bool ConfigureProperties() override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;
	//~ Begin UFactory Interface	

public:
	UPROPERTY()
	UClass* DTTypeClassType = NULL;

};