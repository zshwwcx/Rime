#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeCollector.h"

#include "BeatenTreeTemplate.generated.h"



UCLASS(Abstract)
class UBeatenTreeTypeMessage : public UDTTypeMessage
{
	GENERATED_BODY()

public:
	UBeatenTreeTypeMessage();

};



UCLASS()
class UBeatenTreeTemplate : public UDecisionTreeTemplate
{
	GENERATED_BODY()
	

public:
	UBeatenTreeTemplate()
	{
		TypeMessage = UBeatenTreeTypeMessage::StaticClass();
	}	

private:
	TArray<TWeakObjectPtr<UBeatenTreeNode>> VisitedNodes;

#if WITH_EDITOR
public:
	void RefreshLogicMessage() override;

	void RefreshNodeMessage(UBeatenTreeNode* InCurNode, int32 CurrentDepth);

private:
	int32 TotalSkillNum = 0;

#endif

};
