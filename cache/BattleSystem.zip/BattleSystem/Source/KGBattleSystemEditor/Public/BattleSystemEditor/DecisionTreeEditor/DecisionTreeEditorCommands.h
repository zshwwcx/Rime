#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"
#include "Framework/Commands/UICommandInfo.h"
#include "EditorStyleSet.h"

class FDecisionTreeEditorCommands : public TCommands<FDecisionTreeEditorCommands>
{
public:
	FDecisionTreeEditorCommands() : TCommands<FDecisionTreeEditorCommands>
	(
		TEXT("DecisionTreeEditor"), 
		NSLOCTEXT("Contexts", "DecisionTreeEditor", "DecisionTree Editor"), 
		NAME_None, 
		FAppStyle::GetAppStyleSetName()
	) {}

	virtual void RegisterCommands() override;

public:
	TSharedPtr<FUICommandInfo> BackToPreviousGraph;

};