#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"

#include "PassiveSkillTreeEdge.generated.h"



UCLASS()
class UPassiveSkillTreeEdge : public UDecisionTreeEdge
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, Category = "Base")
	bool IsTrue = true;

#if WITH_EDITOR
public:
	void CopyData(UDecisionTreeEdge* OtherNode) override;

	void RefreshEdgeTitle() override;

	void SetEdgeTitle(const FText& NewTitle) override;

	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

#endif

};
