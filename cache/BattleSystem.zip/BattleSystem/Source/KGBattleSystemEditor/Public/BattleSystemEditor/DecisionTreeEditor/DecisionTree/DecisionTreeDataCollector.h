#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "DecisionTreeDataCollector.generated.h"


UCLASS(Blueprintable, BlueprintType)
class UDecisionTreeDataCollector : public UObject
{
	GENERATED_BODY()
	
};
