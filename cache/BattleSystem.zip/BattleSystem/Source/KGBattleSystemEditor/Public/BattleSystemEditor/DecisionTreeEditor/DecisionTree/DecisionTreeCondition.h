#pragma once

#include "CoreMinimal.h"
#include "KGAbilitySystemEditor/AbilityEditor/Ability/Enums/ASAEditEnums.h"
#include "UObject/NoExportTypes.h"

#include "BattleSystem/BSCondition.h"
#include "KGAbilitySystemEditor/AbilityEditor/Ability/Conditions/ASACondition.h"

#include "DecisionTreeCondition.generated.h"



UCLASS(Blueprintable, EditInlineNew)
class UDecisionTreeCondition : public UBSCondition
{
	GENERATED_BODY()

};






UCLASS(Blueprintable, EditInlineNew)
class UDecisionTreeConditionGroup : public UDecisionTreeCondition
{
	GENERATED_BODY()

public:
	UDecisionTreeConditionGroup();

	bool CheckCondition(const FBSConditionData& InData) override;

protected:
	bool PerformCheck_Implementation(const FBSConditionData& InData) const;

public:
	// 条件之间的逻辑(false为“或”,true为“与”)
	UPROPERTY(EditDefaultsOnly, Category = "Base")
	bool bUseAndLogic = true;

	// 条件列表
	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Condition")
	TArray<UDecisionTreeCondition*> ConditionList;


#if WITH_EDITOR
public:
	bool CopyData(UBSCondition* OtherCondition);

	FString GetConditionDescription();

#endif
};


UCLASS(Blueprintable, EditInlineNew, HideCategories="Comment | 基础 | Default")
class UAutoSkillTreeConditionGroup : public UASACondition
{
	GENERATED_BODY()

public:
	UAutoSkillTreeConditionGroup();

public:

	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	FName Name;

	UPROPERTY(EditAnywhere, Category = "Condition", meta = (EditInline))
	EASAConditionType ConditionRelationType = EASAConditionType::And;
	
	// 条件列表
	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Condition")
	TArray<UASACondition*> Conditions;
};
