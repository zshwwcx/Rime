#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeEdge.h"

#include "AutoSkillTreeTemplate.generated.h"



UCLASS(Abstract)
class UAutoSkillTreeTypeMessage : public UDTTypeMessage
{
	GENERATED_BODY()

public:
	UAutoSkillTreeTypeMessage();

};



UCLASS()
class KGBATTLESYSTEMEDITOR_API UAutoSkillTreeTemplate : public UDecisionTreeTemplate
{
	GENERATED_BODY()
	
public:
	UAutoSkillTreeTemplate()
	{
		TypeMessage = UAutoSkillTreeTypeMessage::StaticClass();
	}
};
