#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeActuator.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeDataCollector.h"

#include "DecisionTreeTemplate.generated.h"




UCLASS(Abstract, Blueprintable)
class UDTTypeMessage : public UObject
{
	GENERATED_BODY()

public:
	// 是否允许出现环路
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Edit Setting")
	bool bAllowCycle = false;

	// 数据导出对象类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Edit Setting")
	TSubclassOf<class UDTBasicExporter> ExporterType;

	// 节点列表为空时，默认创建的节点类型，为空则不创建
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Edit Setting")
	TSubclassOf<UDecisionTreeNode> FirstNodeType = nullptr;

	// 打开编辑器时，默认加载哪些资源对象
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Edit Setting")
	TArray<TSubclassOf<UObject>> NeedLoadAssetTypes;

	// 决策执行器类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RunTime Setting")
	TSubclassOf<UDTBaseActuator> ActuatorType = UDecisionTreeActuator::StaticClass();

	// 数据收集器类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RunTime Setting")
	TSubclassOf<UDecisionTreeDataCollector> DataCollectorType = UDecisionTreeDataCollector::StaticClass();

public:
	UFUNCTION(BlueprintImplementableEvent)
	FString GetTypeMessageName();

#if WITH_EDITORONLY_DATA
public:
	// 节点类型
	UPROPERTY(EditDefaultsOnly, Category = "Edit Setting")
	TArray<TSubclassOf<UDecisionTreeNode> > NodeTypes;

	// 边类型
	UPROPERTY(EditDefaultsOnly, Category = "Edit Setting")
	TSubclassOf<UDecisionTreeEdge> EdgeType = UDecisionTreeEdge::StaticClass();

	UPROPERTY()
	TWeakObjectPtr<UEdGraph> EdGraph = NULL;

#endif

};

UCLASS()
class UDTTestTypeMessage : public UDTTypeMessage
{
	GENERATED_BODY()

public:
	UDTTestTypeMessage()
	{
		ActuatorType = UDecisionTreeActuator::StaticClass();
		DataCollectorType = UDecisionTreeDataCollector::StaticClass();

#if WITH_EDITORONLY_DATA
		NodeTypes.Empty();
		NodeTypes.Add(UDecisionTreeNode::StaticClass());

		EdgeType = UDecisionTreeEdge::StaticClass();
#endif
	}

};






UCLASS()
class UDecisionTreeTemplate : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	virtual void PreLoad(UObject* WorldContext) {}

public:
	// 该模板的ID
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly)
	int32 ID = 0;

	// 决策树的根节点数组
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly)
	TArray<UDecisionTreeNode*> RootNodes;

	// 决策树的边信息
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly)
	TArray<UDecisionTreeEdge*> DecisionTreeEdges;

	// 决策树类型信息
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly)
	TSubclassOf<UDTTypeMessage> TypeMessage;



#if WITH_EDITORONLY_DATA
public:
	// 缩略图主要标题
	UPROPERTY(EditDefaultsOnly, Category = "Thumbnail Helper")
	FText ThumbnailMainTitle;

	// 缩略图附加标题
	UPROPERTY(EditDefaultsOnly, Category = "Thumbnail Helper")
	FText ThumbnailSubTitle;

	UPROPERTY()
	TObjectPtr<UEdGraph> EdGraph = nullptr;
#endif



#if WITH_EDITOR
public:
	virtual void InitByEditor();

	virtual void InitSaver();

	virtual void AddEdgeMessage(UDecisionTreeNode* InFromNode, UDecisionTreeNode* InToNode, UDecisionTreeEdge* InEdge);

	virtual void RefreshLogicMessage();

private:
	TArray<TWeakObjectPtr<UDecisionTreeNode> > EditedNodes;

#endif

};
