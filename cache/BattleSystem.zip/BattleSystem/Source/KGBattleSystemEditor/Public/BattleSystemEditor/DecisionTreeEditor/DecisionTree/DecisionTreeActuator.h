#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeDataCollector.h"

#include "DecisionTreeActuator.generated.h"



UCLASS(Abstract)
class UDTBaseActuator : public UObject
{
	GENERATED_BODY()

public:
	virtual ~UDTBaseActuator();

	virtual void ClearSubGraphActuators();

protected:
	UPROPERTY(BlueprintReadOnly)
	UObject* CurrentDataObject = NULL;

	UPROPERTY(BlueprintReadOnly)
	UDecisionTreeDataCollector* CurrentDataCollector = NULL;

	// 缓存子图表的执行器对象
	UPROPERTY(Transient)
	TMap<UDecisionTreeNode*, UDTBaseActuator*> SubGraphActuatorMap;
};






UCLASS(BlueprintType, Blueprintable)
class UDecisionTreeActuator : public UDTBaseActuator
{
	GENERATED_BODY()

public:
	// 查询当前状态下的最佳决策节点
	UFUNCTION(BlueprintCallable)
	virtual UDecisionTreeNode* GetBestTreeNode(UObject* InDataObject, UDecisionTreeDataCollector* InDataCollector);

	// 尝试获取子树执行器
	UFUNCTION(BlueprintCallable)
	UDecisionTreeActuator* GetSubTreeActuator(UDecisionTreeNode* InGraphNode);

protected:
	// 决策树遍历接口
	UFUNCTION(BlueprintCallable)
	virtual UDecisionTreeNode* TravelDecisionTree(UDecisionTreeNode* StartNode);

};

