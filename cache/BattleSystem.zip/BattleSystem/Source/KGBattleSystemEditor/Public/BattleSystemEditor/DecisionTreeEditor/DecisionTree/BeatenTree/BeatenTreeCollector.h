#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeDataCollector.h"

#include "BeatenTreeCollector.generated.h"



UCLASS()
class UBeatenTreeCollector : public UDecisionTreeDataCollector
{
	GENERATED_BODY()
	
public:
	// 硬直状态
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	uint8 StaggerState;

	// 攻击类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	uint8 AttackType;

	// 攻击力度
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	uint8 AttackForce;

	// 攻击者相对位置
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	uint8 RelationType;

};
