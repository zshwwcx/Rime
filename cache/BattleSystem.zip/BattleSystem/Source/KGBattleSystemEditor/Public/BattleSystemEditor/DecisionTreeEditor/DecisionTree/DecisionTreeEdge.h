#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeCondition.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeDataCollector.h"

#include "DecisionTreeEdge.generated.h"


UCLASS(BlueprintType, Blueprintable)
class UDecisionTreeEdge : public UObject
{
	GENERATED_BODY()

public:
	// 该节点的检查条件
	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Conditions")
	UDecisionTreeConditionGroup* ConditionGroup;


public:
	// 边的出发节点
	UPROPERTY(VisibleDefaultsOnly)
	class UDecisionTreeNode* StartNode = NULL;

	// 边的终止节点
	UPROPERTY(VisibleDefaultsOnly)
	class UDecisionTreeNode* EndNode = NULL;


public:
	UFUNCTION(BlueprintCallable)
	virtual bool CheckConditions(UDecisionTreeDataCollector* InDataCollector);


#if WITH_EDITORONLY_DATA
public:
	// 边信息框的大小
	UPROPERTY(EditDefaultsOnly)
	FVector2D EdgeMessageSize = FVector2D(5.0f, 5.0f);

protected:
	UPROPERTY()
	FText EdgeTitle;

#endif


#if WITH_EDITOR
public:
	virtual void ConstructEdge();

	virtual void CopyData(UDecisionTreeEdge* OtherEdge);

	virtual void RefreshEdgeTitle();

	virtual FText GetEdgeTitle() const;

	virtual void SetEdgeTitle(const FText& NewTitle);

protected:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

#endif

};

