#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"

#include "BeatenTreeEdge.generated.h"



UCLASS()
class UBeatenTreeEdge : public UDecisionTreeEdge
{
	GENERATED_BODY()
	
public:
	UBeatenTreeEdge();


#if WITH_EDITORONLY_DATA
public:
	UPROPERTY(VisibleDefaultsOnly)
	int32 EdgeShortestDepth = 100000;

#endif


#if WITH_EDITOR
public:
	void ConstructEdge() override;

	void SetEdgeTitle(const FText& NewTitle) override {}

	void CheckConditionData();

protected:
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

#endif

};
