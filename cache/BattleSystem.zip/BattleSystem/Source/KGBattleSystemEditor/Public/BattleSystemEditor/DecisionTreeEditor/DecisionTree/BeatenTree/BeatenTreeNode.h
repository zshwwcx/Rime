#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeNode.h"

#include "BattleSystemEditor/BSEditorStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"

#include "BeatenTreeNode.generated.h"



UCLASS()
class UBeatenTreeNode : public UDecisionTreeNode
{
	GENERATED_BODY()
	
public:
	UBeatenTreeNode();

public:
	// 硬直类型
	UPROPERTY(EditDefaultsOnly, Category = "Feedback")
	EBSHitFeedbackType HitFeedbackType = EBSHitFeedbackType::HFT_Normal;

	// 受击方位
	UPROPERTY(EditDefaultsOnly, Category = "Feedback")
	EBSAttackerLocationType HitLocationType = EBSAttackerLocationType::ALT_None;

	// 运动曲线
	UPROPERTY(EditDefaultsOnly, Category = "Feedback")
	FKGRemapFloatCurve MotionCurve;

	// 定制受击参数
	UPROPERTY(EditDefaultsOnly, Category = "Feedback")
	TMap<FString, float> CustomHFParams;

#if WITH_EDITOR
public:
	void SetNodeTitle(const FText& NewTitle) override;

protected:
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;
#endif

};
