#pragma once

#include "CoreMinimal.h"
#include "KGAbilitySystemEditor/AbilityEditor/Ability/ASASkillAsset.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeNode.h"

#include "BattleSystemEditor/BSEditorStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"

#include "CombatTreeNode.generated.h"



UCLASS()
class UCombatTreeRootNode : public UDecisionTreeNode
{
	GENERATED_BODY()

public:
	UCombatTreeRootNode();

#if WITH_EDITOR
public:
	void SetNodeTitle(const FText& NewTitle) override;

	virtual bool CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage) override;

	virtual bool CanUserDelete() const override;

#endif

};



UCLASS()
class UCombatTreeNode : public UDecisionTreeNode
{
	GENERATED_BODY()
	
public:
	UCombatTreeNode();

public:
	// 要释放的技能
	UPROPERTY(EditDefaultsOnly, Category = "Common")
	TSoftObjectPtr<UASASkillAsset> ReleaseSkillAsset = nullptr;

	// 检测技能释放条件
	UPROPERTY(EditDefaultsOnly, Category = "Common")
	bool bCheckReleaseCondition = false;

	// AI技能释放条件
	UPROPERTY(EditDefaultsOnly, Category = "AI_Only")
	bool bFinishWhenRecover = true;

#if WITH_EDITOR
public:
	void CopyData(UDecisionTreeNode* OtherNode) override;

	void RefreshNodeTitle() override;

	void SetNodeTitle(const FText& NewTitle) override;

protected:
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;

#endif
};
