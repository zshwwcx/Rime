#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeCondition.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeDataCollector.h"

#include "DecisionTreeNode.generated.h"



USTRUCT()
struct FDTNodePin
{
	GENERATED_USTRUCT_BODY()

public:
	FDTNodePin() {}
	FDTNodePin(bool InIsOutput, FName InName) : bIsOutput(InIsOutput), PinName(InName) {}

public:
	// Pin脚类型(false为输入Pin，true为输出Pin)
	UPROPERTY()
	bool bIsOutput = false;

	// Pin脚名称
	UPROPERTY()
	FName PinName = NAME_None;

};



UCLASS(Blueprintable)
class UDecisionTreeNode : public UObject
{
	GENERATED_BODY()

public:
	UDecisionTreeNode();

	// 检查条件
	UFUNCTION(BlueprintCallable)
	virtual bool CheckConditions(UDecisionTreeDataCollector* InDataCollector);

public:
	// 从该节点出发的边的索引
	UPROPERTY(VisibleDefaultsOnly, Category = "Tree Data")
	TArray<int32> OutEdges;

	// 到达该节点的边的索引
	UPROPERTY(VisibleDefaultsOnly, Category = "Tree Data")
	TArray<int32> InEdges;

	// 该节点的检查条件
	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Conditions")
	UDecisionTreeConditionGroup* ConditionGroup;



#if WITH_EDITORONLY_DATA
protected:
	// 节点信息
	UPROPERTY(EditDefaultsOnly)
	FText NodeTitle;

	// 节点Pin脚信息
	UPROPERTY()
	TArray<FDTNodePin> PinInformations;
#endif

#if WITH_EDITOR
public:
	virtual void ConstructNode();

	virtual void CopyData(UDecisionTreeNode* OtherNode);

	virtual void RefreshNodeTitle();

	virtual FText GetNodeTitle() const;

	virtual void SetNodeTitle(const FText& InText);

	virtual bool CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage);

	virtual bool CanUserDelete() const;

	const TArray<FDTNodePin>* GetNodePinList();

protected:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

};






UCLASS(Blueprintable)
class UDecisionTreeGraphNode : public UDecisionTreeNode
{
	GENERATED_BODY()


public:
	UDecisionTreeGraphNode()
	{
#if WITH_EDITORONLY_DATA
		NodeTitle = FText::FromString(TEXT("子图表节点"));
#endif
	}

	virtual void TryFindDefaultTypeMessage() {}


public:
	// 根节点信息
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly)
	TArray<UDecisionTreeNode*> RootNodes;

	// 边信息
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly)
	TArray<class UDecisionTreeEdge*> DecisionTreeEdges;

	// 决策树类型信息
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly)
	TSubclassOf<class UDTTypeMessage> TypeMessage;


#if WITH_EDITORONLY_DATA
public:
	UPROPERTY()
	class UEdGraph* EdGraph = NULL;

#endif


#if WITH_EDITOR
public:
	virtual void InitSaver();

	virtual void AddEdgeMessage(UDecisionTreeNode* InFromNode, UDecisionTreeNode* InToNode, UDecisionTreeEdge* InEdge);

	virtual void RefreshLogicMessage();

private:
	TArray<TWeakObjectPtr<UDecisionTreeNode> > EditedNodes;

#endif

};

