#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "LuaOverriderInterface.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"

#include "BattleSystemEditor/BSEditorFunctionLibrary.h"

#include "DecisionTreeExporter.generated.h"



UCLASS(Abstract)
class UDTBasicExporter : public UObject, public ILuaOverriderInterface
{
	GENERATED_BODY()	

public:
	virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Gameplay.BattleSystem.Editor.E_DTExporter"); }

	UFUNCTION(BlueprintImplementableEvent)
	FString JsonStringToLuaString(const FString& InString, int32 ID, const FString& InHead);

	virtual FString ExportDecisionTree(UDecisionTreeTemplate* InTemp) { return FString(); }

public:
	FString ExportPath;

};






UCLASS()
class UBeatenTreeExporter : public UDTBasicExporter
{
	GENERATED_BODY()

public:
	UBeatenTreeExporter()
	{
		ExportPath = "Script/Data/Config/BattleSystem/BeatenTree/";
	}

	FString ExportDecisionTree(UDecisionTreeTemplate* InTemp) override;

};






UCLASS()
class UCombatTreeExporter : public UDTBasicExporter
{
	GENERATED_BODY()

public:
	UCombatTreeExporter()
	{
		ExportPath = "Script/Data/Config/BattleSystem/CombatTree/";
	}

	FString ExportDecisionTree(UDecisionTreeTemplate* InTemp) override;

};






UCLASS()
class UAutoSkillTreeExporter : public UDTBasicExporter
{
	GENERATED_BODY()

public:
	UAutoSkillTreeExporter()
	{
		ExportPath = "Script/Data/Config/BattleSystem/AutoSkillTree/";
	}

	FString ExportDecisionTree(UDecisionTreeTemplate* InTemp) override;

};






UCLASS()
class UPassiveSkillTreeExporter : public UDTBasicExporter
{
	GENERATED_BODY()

public:
	UPassiveSkillTreeExporter()
	{
		ExportPath = "Script/Data/Config/BattleSystem/PassiveSkillTree/";
	}

	FString ExportDecisionTree(UDecisionTreeTemplate* InTemp) override;

};
