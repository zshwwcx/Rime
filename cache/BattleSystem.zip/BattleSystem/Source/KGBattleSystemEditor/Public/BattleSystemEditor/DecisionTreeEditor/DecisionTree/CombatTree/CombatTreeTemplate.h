#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeEdge.h"

#include "CombatTreeTemplate.generated.h"



UCLASS(Abstract)
class UCombatTreeTypeMessage : public UDTTypeMessage
{
	GENERATED_BODY()

public:
	UCombatTreeTypeMessage();

};



UCLASS()
class KGBATTLESYSTEMEDITOR_API UCombatTreeTemplate : public UDecisionTreeTemplate
{
	GENERATED_BODY()
	
public:
	UCombatTreeTemplate()
	{
		TypeMessage = UCombatTreeTypeMessage::StaticClass();
	}
};
