#pragma once

#include "CoreMinimal.h"

#include "KGCore/Public/Lua/LuaEnv.h"

#include "BSEditorLuaBasicGI.generated.h"



UCLASS(BlueprintType, Blueprintable)
class KGBATTLESYSTEMEDITOR_API UBSEditorLuaBasicGI : public UEditorLuaGameInstanceBase
{
	GENERATED_BODY()

public:
	virtual FString GetLuaFilePath_Implementation() const override
	{
		return TEXT("Gameplay.BattleSystem.Editor.E_SimpleGameInstance");
	}

	UFUNCTION(BlueprintImplementableEvent)
	FString ConvertJsonToLuaTable(const FString& InJson, int32 Type);

	UFUNCTION(BlueprintImplementableEvent)
	TArray<FString> ExtractFightProp(const FString& InString, const FString& Name);

};
