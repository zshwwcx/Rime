#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "BattleSystemEditor/BSEditorObjects.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"

#include "BattleSystem/Actor/BSUSpellField.h"
#include "BattleSystem/Actor/BSUProjectile.h"

#include "BSATaskSpawnUnit.generated.h"



#pragma region Base
UCLASS(Abstract, Blueprintable, BlueprintType)
class UBSUnitData : public UObject
{
	GENERATED_BODY()

public:
	// 获取Unit的引用资源列表
	virtual void GetReferenceResources(TArray<FString>& InOutList) { GetBPReferenceResources(InOutList, InOutList); }

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	void GetBPReferenceResources(const TArray<FString>& InList, TArray<FString>& OutList);

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	bool RefreshBPProperty(bool InForceRefresh = false);

public:
	// 模板ID
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base")
	int64 TempID = 0;

	// 生命(值小于0，代表永存)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base")
	float TotalLife = 5.0f;

	// 延时销毁
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base", Meta = (ClampMin = 0.4f))
	float DelayDestroy = 0.4f;

	// 需要同步
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base")
	bool bNeedReplicated = true;
};

UCLASS(Abstract, Blueprintable, BlueprintType)
class UBSMoveableUnitData : public UBSUnitData
{
	GENERATED_BODY()

public:
	UBSMoveableUnitData();

	void GetReferenceResources(TArray<FString>& InOutList) override;

public:
	// 投射物模型信息
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Mesh")
	TArray<FBSMeshCreater> ProjectileMeshList;

	// 模型物理模拟数据
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Mesh", Instanced)
	UBSPhysicalSimulationData* PhysicalSimulationData = nullptr;



	// 投射物特效
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Effect")
	TSoftObjectPtr<class UNiagaraSystem> ProjectileNiagara = nullptr;

	// 投射物特效偏移位置
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Effect")
	FTransform ProjectileEffectRelativeTransform = FTransform::Identity;

	// 投射物拖尾特效
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Effect")
	TSoftObjectPtr<class UNiagaraSystem> ProjectileTrailNiagara = nullptr;

	// 投射物特效偏移位置
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Effect")
	FTransform ProjectileTrailEffectRelativeTransform = FTransform::Identity;



	// 投射物音效
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Sound")
	TSoftObjectPtr<class UAkAudioEvent> SoundAsset = nullptr;



	// 投射物碰撞检测类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Collision")
	bool bIsSphereCollision = true;

	/* 投射物碰撞盒参数
	*  球体：(半径)
	*  长方体：(长,宽,高)
	*/
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Collision")
	FVector CollisionBoxParameter = FVector(30.0f, 0.0f, 0.0f);

	// 延时多长时间开启碰撞盒的碰撞(-1代表永不开启)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Collision")
	float DelayCollisionEnable = -1.0f;

	// 单独设置部分碰撞策略
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Collision")
	TMap<TEnumAsByte<ECollisionChannel>, TEnumAsByte<ECollisionResponse>> OverCollisionResponses;



	// 延时多长时间开始Sweep检测(-1代表永不开启)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Collision Check")
	float DelayStartSweepCheck = 0.05f;

	// Sweep检测类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Collision Check")
	TArray<TEnumAsByte<EObjectTypeQuery>> SweepObjectTypes;

	// Sweep检测结果筛选
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Collision Check")
	FBSCollisionFilter SweepFilter;

	// Sweep检测结果业务筛选
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Collision Check")
	FBSSelectTargetInfo TargetFilter;



	// 投射物初始朝向目标
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Move")
	bool bInitFaceToTarget = true;

	// 投射物速度曲线
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Move")
	FKGRemapFloatCurve SpeedCurve;

	// 投射物发射速度的相对方向
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Move")
	FRotator LaunchRelativeRotation = FRotator::ZeroRotator;

	// 投射物朝向同速度方向一致
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Move")
	bool bRotationFollowsVelocity = false;
};

#pragma endregion Base






#pragma region SpellField
UCLASS(Blueprintable, BlueprintType, EditInlineNew)
class UBSUSpellFieldData : public UBSUnitData
{
	GENERATED_BODY()

public:
	UBSUSpellFieldData();

	void GetReferenceResources(TArray<FString>& InOutList) override;

public:
	// 延时激活主要技能
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Effect")
	float DelayReleaseSkill = 0.0f;

	// 法术场主要技能
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Effect")
	TSoftObjectPtr<class UBSASkillAsset> MainSkill;

};

UCLASS(Abstract, Blueprintable)
class UBSATSpawnSpellField : public UBSATask
{
	GENERATED_BODY()

public:
	// 法术场类
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SpellField")
	TSubclassOf<ABSUSpellFieldV2> SpellFieldClass = nullptr;

	// 法术场数据
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Instanced, Category = "SpellField")
	UBSUSpellFieldData* SpellFieldData = nullptr;



	// 坐标计算器(遍历找到并计算出当前合法的坐标)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform")
	TArray<FBSATransformCreater> TransformCreaters;

	// 是否要贴近地表生成
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform")
	bool bNeedCheckGround = false;
	// 地表查询射线的对象类型
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度(X,Y)/向上偏移距离(Z)
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	FVector ExtraGroundMsg = FVector(-400.0f, 400.0f, 2.0f);

public:
	UBSATSpawnSpellField();

	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	void PreSave(FObjectPreSaveContext SaveContext) override;

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual void CopyDataFromOther(UBSATaskBase* OtherTask) override;

	bool UpdateEditorProperty() override
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		return SpellFieldClass.Get() == nullptr;
	}

#endif
};



UCLASS(Blueprintable, BlueprintType, EditInlineNew)
class UBSURandomSpellFieldData : public UBSUSpellFieldData
{
	GENERATED_BODY()

public:
	UBSURandomSpellFieldData() {};

public:
	// 法术场释放次数
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Random")
	int32 ReleaseTimes = 1;
};


UCLASS(Abstract, Blueprintable)
class UBSATSpawnRandomSpellField : public UBSATask
{
	GENERATED_BODY()

public:
	// 法术场类
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SpellField")
	TSubclassOf<ABSUSpellFieldV2> SpellFieldClass = nullptr;

	// 法术场数据
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Instanced, Category = "SpellField")
	TArray<UBSURandomSpellFieldData*> SpellFieldDatas;



	// 坐标计算器(遍历找到并计算出当前合法的坐标)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform")
	TArray<FBSATransformCreater> TransformCreaters;

	// 是否要贴近地表生成
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform")
	bool bNeedCheckGround = false;
	// 地表查询射线的对象类型
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度(X,Y)/向上偏移距离(Z)
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	FVector ExtraGroundMsg = FVector(-400.0f, 400.0f, 2.0f);


	// 随机范围半径下限
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Random")
	float RandomRadiusMin = 0.0f;

	// 随机范围半径上限
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Random")
	float RandomRadiusMax = 0.0f;

	// 随机生成个数
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Random", Meta = (EditCondition = "false"))
	int32 SpawnNum = 1;

	// 陷阱生成的间隔时间(小于等于0则认为一次性直接全部生成)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Random")
	float SpawnInterval = -1.0;

	// 每次间隔时间生成的陷阱数量
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Random", Meta = (ClampMin = 1, EditCondition = "SpawnInterval > 0.0", EditConditionHides))
	int32 SpawnNumEveryInterval = 1;

	// 是否开启朝向随机功能
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Random")
	bool bRandomRotation = false;

public:
	UBSATSpawnRandomSpellField();

	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	void PreSave(FObjectPreSaveContext SaveContext) override;

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual void CopyDataFromOther(UBSATaskBase* OtherTask) override;

	bool UpdateEditorProperty() override
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		return SpellFieldClass.Get() == nullptr;
	}

#endif
};

#pragma endregion SpellField






#pragma region Projectile
USTRUCT(BlueprintType)
struct FBSUProjectileHitConfig
{
	GENERATED_USTRUCT_BODY()

public:
	// 造成伤害的数据索引
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 AttackActionID = 0;

	// 伤害表现相对朝向
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FRotator AttackEffectRelativeRotation = FRotator(0.0f, 0.0f, 0.0f);

	// 延时添加BUFF(延时时间 + 层数)
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<TSoftObjectPtr<class UBSABuffAsset>, FVector2D> Buffs;

	// 使用技能进行表现
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bUseClientSkill = false;

	// 客户端纯表现技能
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseClientSkill", EditConditionHides))
	TSoftObjectPtr<class UBSASkillAsset> ClientSkill = nullptr;

	// 特效
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "!bUseClientSkill", EditConditionHides))
	TSoftObjectPtr<class UNiagaraSystem> Effect = nullptr;
	// 特效延时播放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "!bUseClientSkill", EditConditionHides))
	float DelayPlayEffect = 0.0f;
	// 特效相对方位
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "!bUseClientSkill", EditConditionHides))
	FTransform EffectRelation;

	// 音效
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "!bUseClientSkill", EditConditionHides))
	TSoftObjectPtr<class UAkAudioEvent> Sound = nullptr;
	// 音效延时播放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "!bUseClientSkill", EditConditionHides))
	float DelayPlaySound = 0.0f;



	// 使用法术场
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bUseSpellField = false;

	// 法术场释放概率
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseSpellField", EditConditionHides, ClampMin = 0.001f, ClampMax = 1.0f))
	float SpellFieldProbability = 1.0f;

	// 要创建的法术场
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseSpellField", EditConditionHides))
	TSoftObjectPtr<class UBSASkillAsset> SpellField = nullptr;

	// 法术场生命周期
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseSpellField", EditConditionHides))
	float SpellFieldTotalLife = 10.0f;

	// 法术场延时多久释放技能
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseSpellField", EditConditionHides))
	float SpellFieldDelayReleaseSkill = 0.0f;

	// 法术场相对位置
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseSpellField", EditConditionHides))
	FTransform SpellFieldRelation;
	// 法术场是否要贴近地表生成
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseSpellField", EditConditionHides))
	bool bSpellFieldNeedCheckGround = false;
	// 法术场地表查询射线的对象类型
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseSpellField && bSpellFieldNeedCheckGround", EditConditionHides))
	TArray<TEnumAsByte<EObjectTypeQuery>> SpellFieldGroundCheckObjectTypes = { EObjectTypeQuery::ObjectTypeQuery1 };
	// 法术场地表查询射线长度(X,Y)/向上偏移距离(Z)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseSpellField && bSpellFieldNeedCheckGround", EditConditionHides))
	FVector ExtraSpellFieldGroundMsg = FVector(-400.0f, 400.0f, 2.0f);

};

UCLASS(Blueprintable, BlueprintType, EditInlineNew)
class UBSUProjectileData : public UBSMoveableUnitData
{
	GENERATED_BODY()

public:
	UBSUProjectileData();

	void GetReferenceResources(TArray<FString>& InOutList) override;

public:
	// 投射物命中次数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability")
	int32 TotalHitTime = 1;

	// 投射物对单一目标的命中冷却
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability")
	float HitCoolDown = 0.4f;

	// 子弹命中逻辑数据
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability")
	FBSUProjectileHitConfig HitLogic;

	// 子弹寿终正寝逻辑数据
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability")
	FBSUProjectileHitConfig LifeEndLogic;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

};

UCLASS(Blueprintable, BlueprintType, EditInlineNew)
class UBSUMissileData : public UBSUProjectileData
{
	GENERATED_BODY()

public:
	UBSUMissileData();

	void GetReferenceResources(TArray<FString>& InOutList) override;

public:
	// 是否追踪地点
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Track")
	bool TrackSpecificPlace = false;

	// 跟踪加速度曲线
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Track")
	FKGRemapFloatCurve TrackAccelerationCurve;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

};

UCLASS(Abstract, Blueprintable)
class UBSATSpawnProjectile : public UBSATask
{
	GENERATED_BODY()

public:
	// 投射物类
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Projectile")
	TSubclassOf<ABSUProjectileV2> ProjectileClass = nullptr;

	// 投射物数据
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Instanced, Category = "Projectile")
	UBSMoveableUnitData* ProjectileData = nullptr;

	// 投射物生成频率
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Projectile")
	float SpawnFrequency = 0.5f;

	// 投射物默认最少生成个数
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Projectile")
	int32 SpawnMinNum = 1;



	// 坐标计算器(遍历找到并计算出当前合法的坐标)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform")
	TArray<FBSATransformCreater> TransformCreaters;

	// 目标坐标计算器(遍历找到并计算出当前合法的坐标)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform")
	TArray<FBSATransformCreater> TargetTransformCreaters;

public:
	UBSATSpawnProjectile();

	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	void PreSave(FObjectPreSaveContext SaveContext) override;

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual void CopyDataFromOther(UBSATaskBase* OtherTask) override;

	virtual bool UpdateEditorProperty() override;

	bool IsTaskInvalid_Implementation() override
	{
		return ProjectileClass.Get() == nullptr;
	}

#endif
};

#pragma endregion Projectile






#pragma region Boomerang
UCLASS(Blueprintable, BlueprintType, EditInlineNew)
class UBSUBoomerangData : public UBSMoveableUnitData
{
	GENERATED_BODY()

public:
	UBSUBoomerangData();

	void GetReferenceResources(TArray<FString>& InOutList) override;

public:
	// 飞去最长持续时间
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyAway")
	float FlyAwayMaxTime = 0.5f;

	// 飞去途中投射物命中停止次数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyAway")
	int32 FlyAwayTotalHitTime = 999;

	// 飞去途中投射物对单一目标的命中冷却
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyAway")
	float FlyAwayHitCoolDown = 999.0f;

	// 飞去途中投射物命中目标后播放的技能
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyAway")
	TSoftObjectPtr<class UBSASkillAsset> FlyAwayHitSkill = nullptr;

	/* 命中目标技能允许同步，默认为否，因为一般情况下这类技能大部分都是播个音效 + 特效 + AttackTask
	 * 为了优化网络延迟，完全可以让客户端先播也不需要服务器同步，而策划99%不会去设置这个技能bNeedReplicated
	 * 没有办法，只好加这个选项作为编辑优化
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyAway")
	bool bAllowReplicateFlyAwayHitSkill = false;



	// 悬停最长持续时间
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | Hover")
	float HoverMaxTime = 1.0f;

	// 悬停过程投射物命中停止次数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | Hover")
	int32 HoverTotalHitTime = 999;

	// 悬停过程投射物对单一目标的命中冷却
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | Hover")
	float HoverHitCoolDown = 0.5f;

	// 悬停过程投射物命中目标后播放的技能
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | Hover")
	TSoftObjectPtr<class UBSASkillAsset> HoverHitSkill = nullptr;

	/* 命中目标技能允许同步，默认为否，因为一般情况下这类技能大部分都是播个音效 + 特效 + AttackTask
	 * 为了优化网络延迟，完全可以让客户端先播也不需要服务器同步，而策划99%不会去设置这个技能bNeedReplicated
	 * 没有办法，只好加这个选项作为编辑优化
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | Hover")
	bool bAllowReplicateHoverHitSkill = false;

	// 到达HoverMaxTime是否自动飞回，不勾选则到时销毁
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | Hover")
	bool bAutoFlyBack = true;



	// 飞回最长持续时间
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyBack")
	float FlyBackMaxTime = 1.0f;

	// 飞回途中投射物命中停止次数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyBack")
	int32 FlyBackTotalHitTime = 999;

	// 飞回途中投射物对单一目标的命中冷却
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyBack")
	float FlyBackHitCoolDown = 999.0f;

	// 飞回途中投射物命中目标后播放的技能
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyBack")
	TSoftObjectPtr<class UBSASkillAsset> FlyBackHitSkill = nullptr;

	/* 命中目标技能允许同步，默认为否，因为一般情况下这类技能大部分都是播个音效 + 特效 + AttackTask
	 * 为了优化网络延迟，完全可以让客户端先播也不需要服务器同步，而策划99%不会去设置这个技能bNeedReplicated
	 * 没有办法，只好加这个选项作为编辑优化
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyBack")
	bool bAllowReplicateFlyBackHitSkill = false;



	// 成功接到回旋镖触发的技能
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyBackSuccess")
	TSoftObjectPtr<class UBSASkillAsset> FlyBackSuccessSkill = nullptr;

	/* 命中目标技能允许同步，默认为否，因为一般情况下这类技能大部分都是播个音效 + 特效 + AttackTask
	 * 为了优化网络延迟，完全可以让客户端先播也不需要服务器同步，而策划99%不会去设置这个技能bNeedReplicated
	 * 没有办法，只好加这个选项作为编辑优化
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability | FlyBackSuccess")
	bool bAllowReplicateFlyBackSuccessSkill = false;



	// 投射物寿终正寝后播放的技能
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Ability | LifeEnd")
	TSoftObjectPtr<class UBSASkillAsset> LifeEndSkill = nullptr;

	/* 寿终正寝后播放的技能允许同步，默认为否，因为一般情况下这类技能大部分都是播个音效 + 特效
	* 为了优化网络延迟，完全可以让客户端先播也不需要服务器同步，而策划99%不会去设置这个技能bNeedReplicated
	* 没有办法，只好加这个选项作为编辑优化
	   */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ability")
	bool bAllowReplicateLifeEndSkill = false;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif
};

#pragma endregion Boomerang