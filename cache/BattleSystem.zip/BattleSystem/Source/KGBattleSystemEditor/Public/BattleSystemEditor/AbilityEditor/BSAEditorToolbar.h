#pragma once

#include "Input/Reply.h"
#include "Styling/SlateBrush.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"



class FBSAEditorToolbar : public TSharedFromThis<FBSAEditorToolbar>
{
public:
	// 建立工具栏
	void SetupToolbar(TSharedPtr<FExtender> Extender, TSharedPtr<class FBSAEditor> InEditor);

	// 添加模式工具栏
	void AddModesToolbar(TSharedPtr<FExtender> Extender);

	// 添加时间轴工具栏
	void AddTimelineToolbar(TSharedPtr<FExtender> Extender);

private:
	// 填充模式工具栏
	void FillModesToolbar(FToolBarBuilder& ToolbarBuilder);

	// 填充时间轴工具栏
	void FillTimelineModeToolbar(FToolBarBuilder& ToolbarBuilder);

	// 数据导出菜单栏
	TSharedRef<SWidget> GenerateDataProcessMenu();

	FText GetPlayText() const;

	FText GetPlayToolTip() const;

	FSlateIcon GetPlayIcon() const;

private:
	TWeakPtr<class FBSAEditor> CachedEditor;

	FSlateIcon PlayIcon;
	FSlateIcon PauseIcon;
};
