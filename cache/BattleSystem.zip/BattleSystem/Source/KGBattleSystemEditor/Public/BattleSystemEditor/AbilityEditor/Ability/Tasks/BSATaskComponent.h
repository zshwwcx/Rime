#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSATaskComponent.generated.h"



#pragma region RelativeTransform
UCLASS(Abstract, Blueprintable)
class UBSATComponentRelation : public UBSATask
{
	GENERATED_BODY()
	
public:
	// 组件名称
	UPROPERTY(EditAnywhere)
	FName ComponentName = TEXT("Mesh");


	// 是否修改组件的挂载者
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeParent = false;
	// 组件的新挂载者名称
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "bNeedChangeParent"))
	FName NewAttachParentName = NAME_None;

	// 是否修改组件的挂载点
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeSocket = false;
	// 组件的新挂载点
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "bNeedChangeSocket"))
	FName NewAttachSocketName = NAME_None;


	// 是否修改组件的相对位置
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeRelativeLocation = false;
	// 新的相对位置
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "bNeedChangeRelativeLocation"))
	FVector RelativeLocation;
	// 新的相对位置时间曲线
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedLocationTimeCurve = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "bNeedLocationTimeCurve"))
	FKGRemapFloatCurve RelativeLocationTimeCurve;


	// 是否修改组件的相对朝向
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeRelativeRotation = false;
	// 新的相对朝向
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "bNeedChangeRelativeRotation"))
	FRotator RelativeRotation;
	// 新的相对旋转时间曲线
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedRotationTimeCurve = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "bNeedRotationTimeCurve"))
	FKGRemapFloatCurve RelativeRotationTimeCurve;


	// 是否修改组件的相对缩放
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeRelativeScale = false;
	// 新的相对大小
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "bNeedChangeRelativeScale"))
	FVector RelativeScale;
	// 新的相对大小时间曲线
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedScaleTimeCurve = false;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "bNeedScaleTimeCurve"))
	FKGRemapFloatCurve RelativeScaleTimeCurve;




#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

#endif

};

#pragma endregion RelativeTransform






#pragma region BeatenRise
UCLASS(Abstract, Blueprintable)
class UBSATBeatenRise : public UBSATask
{
	GENERATED_BODY()

public:
	// 模型名称
	UPROPERTY(EditAnywhere)
	FName MeshName = TEXT("Mesh");

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FKGRemapFloatCurve TimeCurve;

};

#pragma endregion BeatenRise
