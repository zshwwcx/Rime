#pragma once

#include "Styling/ISlateStyle.h"
#include "Runtime/Slate/Public/Framework/Commands/Commands.h"



class FBSAEditorCommands : public TCommands<FBSAEditorCommands>
{
public:
	FBSAEditorCommands() : TCommands<FBSAEditorCommands>(TEXT("BSAEditor"), NSLOCTEXT("Contexts", "BSAEditor", "BSAEditor"), NAME_None, TEXT("Waiting"))
	{

	}

	virtual void RegisterCommands() override;

public:
	TSharedPtr<FUICommandInfo> Play;
	TSharedPtr<FUICommandInfo> Stop;
	TSharedPtr<FUICommandInfo> Step;

	TSharedPtr<FUICommandInfo> ResetWorld;
	TSharedPtr<FUICommandInfo> ShowCollision;
};
