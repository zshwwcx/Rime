#pragma once

#include "CoreMinimal.h"

#include "UMG/Blueprint/KGUserWidget.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "QTE/BSQTEObject.h"

#include "BSATaskUI.generated.h"



#pragma region OpenUI
// 打开UI类型
UENUM(BlueprintType)
enum class EBSAOpenUIType : uint8
{
	OUIT_Widget = 0               UMETA(DisplayName = "Widget"),
	OUIT_ThreeDUI                 UMETA(DisplayName = "3DUI"),
	OUIT_Reminder                 UMETA(DisplayName = "Reminder"),
	OUIT_Map					  UMETA(DisplayName = "Map"),
	OUIT_Letter                   UMETA(DisplayName = "Letter"),

	OUIT_TMax                     UMETA(Hidden)
};



UCLASS(Abstract, Blueprintable)
class UBSATOpenUI : public UBSATask
{
	GENERATED_BODY()

public:
	// 打开UI类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	EBSAOpenUIType UIType = EBSAOpenUIType::OUIT_Widget;

	// 要打开的UI
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Meta = (EditCondition = "UIType == EBSAOpenUIType::OUIT_Widget", EditConditionHides))
	TSubclassOf<UKGUserWidget> WidgetClass;

	// P_开头的UI名称(必填！，请与程序咨询)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Meta = (EditCondition = "UIType == EBSAOpenUIType::OUIT_Widget", EditConditionHides))
	FString UIName;

	// 传递给UI控件的额外参数
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Meta = (EditCondition = "UIType == EBSAOpenUIType::OUIT_Widget", EditConditionHides))
	TMap<FString, FString> ExtraParamMap;

	// 3DUI对应Excel中的ConfigID
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Meta = (EditCondition = "UIType == EBSAOpenUIType::OUIT_ThreeDUI", EditConditionHides))
	int32 ThreeDUIConfigID = -1;

	// Reminder对应Excel中的ConfigID
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Meta = (EditCondition = "UIType == EBSAOpenUIType::OUIT_Reminder", EditConditionHides))
	int32 ReminderConfigID = -1;

	// Reminder对应的额外参数
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Meta = (EditCondition = "UIType == EBSAOpenUIType::OUIT_Reminder", EditConditionHides))
	TMap<FString, FString> ReminderParamMap;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (UIType == EBSAOpenUIType::OUIT_Widget && WidgetClass == nullptr)
		{
			return true;
		}

		if (UIType == EBSAOpenUIType::OUIT_ThreeDUI && ThreeDUIConfigID < 0)
		{
			return true;
		}

		if (UIType == EBSAOpenUIType::OUIT_Reminder && ReminderConfigID < 0)
		{
			return true;
		}

		return false;
	}

#endif
};

#pragma endregion OpenUI






#pragma region QTE
UCLASS(Abstract, Blueprintable)
class UBSATQTE : public UBSATask
{
	GENERATED_BODY()

public:
	// 要执行的QTE
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Instanced)
	UBSQTEData* QTEData = nullptr;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (QTEData == nullptr)
		{
			return true;
		}

		return false;
	}

#endif
};

#pragma endregion QTE
