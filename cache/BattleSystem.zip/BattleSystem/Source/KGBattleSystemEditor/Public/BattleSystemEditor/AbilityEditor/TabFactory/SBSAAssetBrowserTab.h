#pragma once

#include "CoreMinimal.h"
#include "Editor.h"
#include "EditorStyleSet.h"
#include "ContentBrowserModule.h"
#include "Widgets/SCompoundWidget.h"
#include "IContentBrowserSingleton.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"



class SBSAAssetBrowser : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SBSAAssetBrowser) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs)
	{
		FContentBrowserModule& ContentBrowserModule = FModuleManager::Get().LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
		FAssetPickerConfig Config;
		FARFilter Filter;
		Filter.bRecursiveClasses = true;
		Filter.ClassPaths.Add(UBSAAsset::StaticClass()->GetClassPathName());
		Filter.ClassPaths.Add(FTopLevelAssetPath(TEXT("/Script/C7Editor"), TEXT("BSAAsset")));
		Config.Filter = Filter;
		Config.InitialAssetViewType = EAssetViewType::Column;
		Config.bAddFilterUI = false;
		Config.bShowPathInColumnView = false;
		Config.bSortByPathInColumnView = false;
		Config.bShowTypeInColumnView = false;
		Config.OnAssetDoubleClicked = FOnAssetDoubleClicked::CreateSP(this, &SBSAAssetBrowser::OnRequestOpenAsset);
		Config.OnGetAssetContextMenu = FOnGetAssetContextMenu::CreateSP(this, &SBSAAssetBrowser::OnGetAssetContextMenu);
		Config.bFocusSearchBoxWhenOpened = false;

		this->ChildSlot
		[
			SNew(SBorder)
			.Padding(FMargin(3))
			.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
			[
				ContentBrowserModule.Get().CreateAssetPicker(Config)
			]
		];
	}

	void OnRequestOpenAsset(const FAssetData& AssetData)
	{
		if (UObject* ObjectToEdit = AssetData.GetAsset())
		{
			GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(ObjectToEdit);
		}
	}

	TSharedPtr<SWidget> OnGetAssetContextMenu(const TArray<FAssetData>& SelectedAssets)
	{
		return SNullWidget::NullWidget;
	}
};