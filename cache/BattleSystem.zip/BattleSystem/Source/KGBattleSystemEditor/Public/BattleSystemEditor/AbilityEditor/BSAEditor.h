#pragma once

#include "CoreMinimal.h"
#include "UObject/GCObject.h"
#include "EditorUndoClient.h"
#include "GraphEditor.h"
#include "WorkflowOrientedApp/WorkflowTabManager.h"
#include "WorkflowOrientedApp/WorkflowCentricApplication.h"
#include "AdvancedPreviewSceneModule.h"

#include "Subsystems/SubsystemCollection.h"
#include "Serialization/JsonSerializer.h"



namespace BSAEditorModes
{
	extern const FName Main;
	extern const FName LogicGraph;
};

namespace BSAEditorTabs
{
	extern const FName ViewportTab;
	extern const FName AssetEdit;
	extern const FName AssetBrowser;
	extern const FName AssetDetails;
	extern const FName Details;
	extern const FName PreviewSettings;

	extern const FName GraphEdit;
	extern const FName GraphPallete;
	extern const FName GraphDetail;
};



class IBSAEditor : public FWorkflowCentricApplication
{
public:
	static TSharedPtr<IBSAEditor> OpenEditor(UObject* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost);

	virtual class UBSAAsset* GetEditingAsset() = 0;

protected:
	virtual void InitializeEditor(class UBSAAsset* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost) = 0;

	virtual TSharedPtr<class FBSAEditorPreviewScene> GetPreviewScene() const = 0;

};



class KGBATTLESYSTEMEDITOR_API FBSAEditor : public IBSAEditor, public FGCObject, public FEditorUndoClient
{
#pragma region Important
public:
	FBSAEditor();

	virtual ~FBSAEditor();
	virtual FString GetReferencerName() const override { return "FBSAEditor"; }
	// 初始化
	void InitializeEditor(UBSAAsset* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost) override;

	// 更新
	void Tick(float DeltaTime);

	// 关闭
	void OnClose() override;

	// 获取正在编辑的资源
	class UBSAAsset* GetEditingAsset();

	// 重载改变当前编辑模式
	void SetCurrentMode(FName NewMode) override;

	// 保存
	void SaveAsset_Execute() override;

private:
	static TArray<int64> ExistBSAEditorGUIDs;
	
	static int32 BSAEditorIndex;

	int64 CurBSAEditorGUID = 0;

	TWeakObjectPtr<class UBSAAsset> EditAsset = nullptr;
	
	class UEditorLuaEnv *LuaEnv = nullptr;

#pragma endregion Important



#pragma region Editor
public:
	void RegisterTabSpawners(const TSharedRef<class FTabManager>& TabManager) override;

	void UnregisterTabSpawners(const TSharedRef<class FTabManager>& TabManager) override;

	FText GetBaseToolkitName() const override;

	FName GetToolkitFName() const override;

	FString GetWorldCentricTabPrefix() const override;

	FLinearColor GetWorldCentricTabColorScale() const override;

	// 设置编辑器窗口UI
	void SetViewport(TSharedPtr<class SBSAEditorViewport> InViewport);

	// 获得编辑器窗口UI
	TSharedPtr<class SBSAEditorViewport> GetViewportWidget();

	// 设置属性细节窗口UI
	void SetDetailWidget(TSharedPtr<class SBSADetailTab> InDetailWidget);

	// LogicGraph设置属性细节窗口UI
	void SetGraphDetailWidget(TSharedPtr<SBSADetailTab> InDetailWidget);

	// 显示对象的属性细节
	void ShowObjectDetail(UObject* InObject);

	// LogicGraph显示对象的属性细节
	void ShowGraphObjectDetail(UObject* InObject);

	// 编辑器模式
	static FText GetLocalizedMode(FName InMode);

public:
	// 扩展工具栏
	void ExtendToolbar();

	// 和引擎GC相关，添加引用的对象
	void AddReferencedObjects(class FReferenceCollector& Collector);

private:
	// 编辑器主窗口
	TSharedPtr<class SBSAEditorViewport> Viewport;

	// 属性编辑窗口
	TSharedPtr<class SBSADetailTab> DetailWidgetPtr;

	// 属性编辑窗口
	TSharedPtr<class SBSADetailTab> GraphDetailWidgetPtr;

	// 工具栏
	TSharedPtr<class FExtender> ToolbarExtender;

	// 工具栏
	TSharedPtr<class FBSAEditorToolbar> EditorToolbar;

	// 临时文件路径
	FString TemporaryLuaFile = "";

#pragma endregion Editor



#pragma region Command
public:
	// 播放技能
	void Play();

	// 是否正在播放技能
	bool IsPlaying() const;

	// 是否暂停播放技能
	bool IsPaused() const;

	// 是否停止播放技能
	bool IsStopped() const;

	// 暂停技能
	void Pause();

	// 停止技能
	void Stop();

	// 步进技能
	void Step();

	// 重置世界
	void ResetWorld();

	// 显示碰撞
	void ShowHitBox();

	// 更新所有Ability的数据
	void UpdateAllAbilityData();

	// 导出全部Json数据
	void ExportAllAbilityJson();

	// 导出当前Json数据
	void ExportCurrentAbilityJson();

	// 刷新GameplayTag
	void RefreshGameplayTags();

	//刷新PIE world的技能/buff数据
	void RefreshPIEWorldAbilityData();

	// 导出数据到临时文件
	void ExportAbilityToTemporaryFile();

	// 自动优化
	int32 AutoOptimize();

	// 检查所有技能&Buff的引用资源合法性
	void CheckAllResources();

	// 根据同名文件查找自动修复所有技能&Buff的引用资源合法性
	void AutoFixAllResources();

	// 根据DisableBehavior自动生成技能后摇开始时间
	void AutoGenSkillRecoveryStartTime(TArray<int32> SkillIDs);

public:
	// 监听到其他多开编辑器窗口开始play
	void OnAnyBSEditorStartPlay();

protected:
	// 工具栏命令绑定
	void BindCommands();

	void FindAndExportAbilityAssetToJson(int32 HeadID = -1, int32 ExportType = 0, int32 UpdateID = 0);

public:
	// 显示碰撞的开关
	bool bShowCollision = false;

	void UpdateHitBox();

#pragma endregion Command



#pragma region Preview
public:
	virtual TSharedPtr<class FBSAEditorPreviewScene> GetPreviewScene() const override;

	virtual TSharedPtr<class FPreviewScene> GetPreviewSceneBase() const;

	class UBSAPreviewSettings* GetPreviewSettings();

	virtual TSharedPtr<class FBSAPreviewProxy> GetPreviewProxy() const;

	// 是否需要暂停世界
	bool ShouldPauseWorld() const;

protected:
	// 创建预览场景
	void CreatePreviewScene();

	// 创建预览代理
	virtual void CreatePreviewProxy();

	// 初始化上下文
	void InitPreviewContext();

	// 重置上下文
	void ResetPreviewContext();

private:
	// 预览配置
	TWeakObjectPtr<class UBSAPreviewSettings> PreviewSettings;

	// 预览场景
	TSharedPtr<class FBSAEditorPreviewScene> PreviewScene;

	// 预览代理
	TSharedPtr<class FBSAPreviewProxy> PreviewProxy;

#pragma endregion Preview



#pragma region AbilityLogic
public:
	class UBSManager* GetBSManager();

	// 获取当前选中的Task
	TArray<class UBSATask*> GetTaskSelection();

	// Task选取发生改变
	void SetTaskSelection(TArray<class UBSATask*> InSelection, bool bIsOverride = true);

protected:
	// 收集Task类型
	void CollectAllTaskClass();

public:
	TArray<TWeakObjectPtr<UClass>> TaskClassList;
	TArray<TStrongObjectPtr<class UUserDefinedEnum>> EnumList;

private:
	TWeakObjectPtr<class UBSManager> CachedBSManager = nullptr;

	struct FSelectedTaskInfo
	{
		int32 SectionID = -1;
		int32 GroupID = -1;

		TArray<TWeakObjectPtr<class UBSATask>> TaskList;
	};
	FSelectedTaskInfo TaskSelection;

#pragma endregion AbilityLogic



#pragma region LogicGraph
public:
	void SetLogicGraphEditor(const TSharedPtr<SGraphEditor>& InGraphEditor);

	void OnSelectedNodesChanged(const TSet<class UObject*>& NewSelection);

	void DeleteSelectedNodes();

	void GenerateTaskGraphNode(class UBSATask* InTask, int32 PosX, int32 PosY);

	void GenerateGraphNodesByTaskList(TArray<class UBSATask*> InTaskList);

private:
	TSharedPtr<SGraphEditor> LogicGraphEditor = nullptr;

	TArray<TWeakObjectPtr<UObject>> SelectedGraphNodes;

#pragma endregion LogicGraph

};
