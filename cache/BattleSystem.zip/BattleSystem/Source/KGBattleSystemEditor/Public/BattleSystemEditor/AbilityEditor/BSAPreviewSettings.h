#pragma once

#include "Internationalization/StringTable.h"

#include "BSAPreviewSettings.generated.h"



UCLASS(Config = Editor, DefaultConfig)
class UBSAPreviewSettings : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(Config, EditAnywhere, Category = "Viewport", meta = (DisplayName = "Field of View", ClampMin = 70.0f, ClampMax = 180.0f))
	float FOV;

	UPROPERTY(Config, EditAnywhere, Category = "Collision")
	float ShowHitBoxDuration = 2.0f;

};