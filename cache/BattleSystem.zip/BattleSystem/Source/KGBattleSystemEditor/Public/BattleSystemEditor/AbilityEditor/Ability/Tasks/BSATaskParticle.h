#pragma once

#include "CoreMinimal.h"

#include "Misc/CommonDefines.h"
#include "Misc/LowLevelFunctions.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystem/Ability/BSAStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"

#include "BSATaskParticle.generated.h"



#pragma region PlayNiagara
UCLASS(Abstract, Blueprintable)
class UBSATPlayNiagara : public UBSATask
{
	GENERATED_BODY()

public:
	// 是否从数据缓冲中得到Niagara粒子资源
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	bool bUseInputNiagaraAsset = false;

	// Niagara粒子资源
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara", Meta = (EditCondition = "!bUseInputNiagaraAsset"))
	TSoftObjectPtr<class UNiagaraSystem> NiagaraAsset = nullptr;

	// 延时删除
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara", Meta = (ClampMin = 0.1f, ClampMax = 10.0f))
	float FinishDelay = 0.1f;

	// 维持和挂载者相同的隐藏状态
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	bool bSameHiddenToAttachParent = false;

	// 维持和发射者相同的Slomo数值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	bool bSameSlomoToSpawner = true;

	// 是否含有无限循环的粒子发射器
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadWrite, Category = "Niagara")
	bool bHasLoopEmitter = false;

	// Task结束时是否直接停止粒子
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara", Meta = (EditCondition = "!bHasLoopEmitter"))
	bool bDestroyWhenTaskEnd = false;

	// 需要绑定的Tag
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	TArray<FName> ActorTags;



	// 是否进行绑定
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform")
	bool bNeedAttach = false;

	// 是否绑定旋转(true：跟随角色旋转)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach"))
	bool bAttachRotation = false;

	// 是否绑定缩放(true：跟随角色缩放)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach"))
	bool bAttachScale = false;

	// 绑定目标
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	EBSASelectTarget AttachType = EBSASelectTarget::ST_Self;

	// 使用骨骼名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	bool bUseSocket = true;
	// 绑定模式下的骨骼名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach && bUseSocket", EditConditionHides))
	FBSSocketSelector AttachSocket;
	// 绑定模式下的特定名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach && !bUseSocket", EditConditionHides))
	FGameplayTag SpecialName; 



	// 绑定模式下的坐标偏移矩阵
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSATPP_Transform AttachTransform;

	// 坐标计算信息
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "!bNeedAttach", EditConditionHides))
	FBSATransformCreater CoordinateCreater;

	// 是否要贴近地表生成
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "!bNeedAttach", EditConditionHides))
	bool bNeedCheckGround = false;

	// 地表查询射线的对象类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度(X,Y)/向上偏移距离(Z)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	FVector ExtraGroundMsg = FVector(-400.0f, 400.0f, 2.0f);

#if WITH_EDITORONLY_DATA
	// 点击后自动将CoordinateCreater中配置的Transform逆时针旋转90度
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, AdvancedDisplay, Category = "Transform", Transient)
	bool bClickToFixCoordinateCreater = false;
#endif



	// 选取哪个角色作为特效的连接目标
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Connection")
	EBSASelectTarget ConnectionTargetType = EBSASelectTarget::ST_TMax;

	// 当ConnectionTargetType为无效目标时，把传入的数据作为目标
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Connection", Meta = (EditCondition = "ConnectionTargetType == EBSASelectTarget::ST_TMax"))
	int32 ConnectionTargetInputDataID = 2;



	// 是否接受贴花
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Render")
	bool bReceiveDecal = false;

	// 半透明排序优先级
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Render")
	int32 TranslucencySortPriority = 0;

	// 半透明排序距离附加值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Render")
	float TranslucencySortDistanceOffset = 0.0f;

	// 写入自定义深度值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Render")
	bool bRenderCustomDepthPass = false;

	// 自定义深度模板值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Render")
	int32 CustomDepthStencilValue = 0;

	// 自定义深度模板值遮罩
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Render")
	ERendererStencilMask CustomDepthStencilWriteMask = ERendererStencilMask::ERSM_Default;


#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	void UpdateDataByDynamicActorInfo(const FBSADynamicObjectInfo& InInfo) override;

	void UpdateDynamicActorByData(const FBSADynamicObjectInfoArray& InInfoArray) override;

	bool UpdateEditorProperty() override
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		return bUseInputNiagaraAsset == false && NiagaraAsset.IsNull();
	}
#endif

};



UCLASS(Abstract, Blueprintable)
class UBSATStopNiagara : public UBSATask
{
	GENERATED_BODY()

public:
	// 过滤需要停止特效的Tag
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	TArray<FString> FilterTags;

#if WITH_EDITORONLY_DATA
	// 提示
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara", Meta = (EditCondition = "false"))
	FString Tips = TEXT("注意：TargetTypes将用于筛选Niagara的Spawner!");
#endif
};



USTRUCT(BlueprintType)
struct FBSANiagaraReplaceInfo
{
	GENERATED_USTRUCT_BODY()

public:
	// 过滤需要替换特效的Tag
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	TArray<FString> FilterTags;

	// 需要被替换的特效资产
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	TSoftObjectPtr<UNiagaraSystem> NiagaraToReplace = nullptr;

	// 替换的特效资产
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	TSoftObjectPtr<UNiagaraSystem> ReplacedNiagara = nullptr;
};

UCLASS(Abstract, Blueprintable)
class UBSATReplaceNiagara : public UBSATask
{
	GENERATED_BODY()

public:
	// 特效替换信息
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	TArray<FBSANiagaraReplaceInfo> ReplaceInfos;

#if WITH_EDITORONLY_DATA
	// 提示
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara", Meta = (EditCondition = "false"))
	FString Tips = TEXT("注意：TargetTypes将用于筛选Niagara的Spawner!");
#endif
};

UCLASS(Abstract, Blueprintable)
class UBSATHideNiagara : public UBSATask
{
	GENERATED_BODY()

public:
	// 过滤需要替换特效的Tag
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara")
	TArray<FString> FilterTags;

#if WITH_EDITORONLY_DATA
	// 提示
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Niagara", Meta = (EditCondition = "false"))
	FString Tips = TEXT("注意：TargetTypes将用于筛选Niagara的Spawner!");
#endif
};

#pragma endregion PlayNiagara



#pragma region Ninja
UCLASS(Abstract, Blueprintable)
class UBSATFluidNinja : public UBSATask
{
	GENERATED_BODY()

public:
	// 总生命 小于0时表示无限生命
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ninja")
	float TotalLife = 1.0f;

	// 是否进行绑定
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform")
	bool bNeedAttach = false;

	// 是否绑定旋转(true：跟随角色旋转)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	bool bAttachRotation = false;

	// 是否绑定缩放(true：跟随角色缩放)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	bool bAttachScale = false;

	// Ninja是否由Niagara驱动
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	bool bDriveByNiagara = false;

	// 绑定模式下的组件名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", AdvancedDisplay, Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FName AttachComponentName;

	// 绑定模式下的骨骼名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSSocketSelector AttachSocket;

	// 绑定模式下的坐标偏移矩阵
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSATPP_Transform AttachTransform;



	// 坐标计算信息
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "!bNeedAttach", EditConditionHides))
	FBSATransformCreater CoordinateCreater;

	// 是否要贴近地表生成
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "!bNeedAttach", EditConditionHides))
	bool bNeedCheckGround = false;

	// 地表查询射线的对象类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "!bNeedAttach && bNeedCheckGround", EditConditionHides))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度(X,Y)/向上偏移距离(Z)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "!bNeedAttach && bNeedCheckGround", EditConditionHides))
	FVector ExtraGroundMsg = FVector(-400.0f, 400.0f, 2.0f);

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	bool UpdateEditorProperty() override
	{
		return false;
	}
#endif

};

#pragma endregion Ninja
