#pragma once

#include "CoreMinimal.h"
#include "Input/Reply.h"
#include "Misc/Attribute.h"

#include "SNodePanel.h"
#include "SCurveEditor.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineEvent.h"



namespace ENotifyStateHandleHit
{
	enum Type
	{
		Start,
		End,
		None
	};
}



struct FBSATaskNodeData
{
	// 设置Node对应的Task对象
	void SetTaskNodeData(class UBSATask* InTask);

	// 获取Task对象
	class UBSATask* GetTask() const;

	// 获取Task名称
	FString GetTaskName() const;

	// 获取颜色
	TOptional<FLinearColor> GetColor() const;

	// 获取Tip
	FText GetNodeTooltip() const;

	// 获取开始时间
	float GetStartTime() const;

	// 设置开始时间
	void SetStartTime(float Time);

	// 获取持续时间
	float GetDuration() const;

	// 设置持续时间
	void SetDuration(float InDuration);

private:
	// 缓存的Task对象
	TWeakObjectPtr<class UBSATask> CachedTask = nullptr;

};






class SBSATaskTrackNode : public SLeafWidget
{
#pragma region Important
public:
	friend class SBSATaskTrackTimeline;

	SLATE_BEGIN_ARGS(SBSATaskTrackNode) 
		:_ViewInputMin(), 
		_ViewInputMax(), 
		_OnRefreshPanel(),
		_OnStartDragNode()
	{}
	SLATE_ARGUMENT(class UBSATask*, Task)
	SLATE_ATTRIBUTE(float, ViewInputMin)
	SLATE_ATTRIBUTE(float, ViewInputMax)
	SLATE_ATTRIBUTE(float, TimelinePlayLength)
	SLATE_EVENT(FRefreshPanel, OnRefreshPanel)
	SLATE_EVENT(FStartDragNode, OnStartDragNode)
	SLATE_END_ARGS()

	void Construct(const FArguments& Declaration);

	virtual ~SBSATaskTrackNode();

	void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	FBSATaskNodeData* GetTaskNodeDataPtr();

	const FBSATaskNodeData& GetTaskNodeData() const;

private:
	FBSATaskNodeData TaskNodeData;

#pragma endregion Important



#pragma region Render
public:
	// 绘制该控件
	int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const;

	// 绘制移动时的偏移虚影
	void DrawHandleOffset(const float& Offset, const float& HandleCentre, FSlateWindowElementList& OutDrawElements, int32 MarkerLayer, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FLinearColor NodeColour) const;

#pragma endregion Render



#pragma region Parameter
public:
	bool IsSelected() const;

	FText GetNotifyText() const;

	FText GetNodeTooltip() const;

	FVector2D GetSize() const;

	const FVector2D& GetScreenPosition() const;

	float GetDurationSize() const;

	FVector2D GetWidgetPosition() const;

	FVector2D GetNotifyPosition() const;

	FVector2D GetNotifyPositionOffset() const;

	FVector2D ComputeDesiredSize(float) const override;

	void UpdateSizeAndPosition(const FGeometry& AllottedGeometry);

protected:
	void OnEditorTaskSelectionChanged(TArray<class UBSATask*> InTaskSelection);

private:
	bool bSelected;

	FSlateFontInfo Font;

	float NotifyTimePositionX;

	float NotifyDurationSizeX;

	float NotifyScrubHandleCentre;

	FVector2D ScreenPosition;

	bool bDrawTooltipToRight;

	FVector2D TextSize;

	float LabelWidth;

	float NodeStartTime;

	float NodeDuration;


#pragma endregion Parameter



#pragma region Widget
public:
	// 接收聚焦
	FReply OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent) override;

	// 丢失聚焦
	void OnFocusLost(const FFocusEvent& InFocusEvent) override;

	// 是否支持键盘聚焦
	bool SupportsKeyboardFocus() const override;

	// 分析鼠标拖拽TaskNode的类型
	ENotifyStateHandleHit::Type DurationHandleHitTest(const FVector2D& CursorScreenPosition) const;

	// 是否正在被拖动
	bool BeingDragged() const;

	// 拖动回调
	FReply OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	
	// 拖动被取消
	void DragCancelled();

	// 设置鼠标按下时的位置
	void SetLastMouseDownPosition(const FVector2D& CursorPosition);

	// 鼠标移动回调
	FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	
	// 鼠标按键抬起回调
	FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	// 鼠标悬停查询
	FCursorReply OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const override;

	float HandleOverflowPan(const FVector2D& ScreenCursorPos, float TrackScreenSpaceXPosition, float TrackScreenSpaceMin, float TrackScreenSpaceMax);

private:
	bool bBeingDragged;

	// Index for undo transactions for dragging, as a check to make sure it's active
	int32 DragMarkerTransactionIdx;

	// Index for undo transactions for dragging, as a check to make sure it's active
	int32 DragMarkerPositionIdx;

	/** The scrub handle currently being dragged, if any */
	ENotifyStateHandleHit::Type CurrentDragHandle;

	float WidgetX;

	FVector2D WidgetSize;

	TAttribute<float> ViewInputMin;

	TAttribute<float> ViewInputMax;

	float TimelinePlayLength;

	/** Last position the user clicked in the widget */
	FVector2D LastMouseDownPosition;

	/** Cached owning track geometry */
	FGeometry CachedTrackGeometry;

	FVector2D CachedAllotedGeometrySize;

#pragma endregion Widget



#pragma region Event
private:
	/** Delegate to redraw the notify panel */
	FRefreshPanel RefreshPanelEvent;

	/** Delegate that is called when the user initiates dragging */
	FStartDragNode StartDragNodeEvent;

#pragma endregion Event

};
