#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSATaskMesh.generated.h"



#pragma region MeshVisibility
UCLASS(Abstract, Blueprintable)
class UBSATMeshVisibility : public UBSATask
{
	GENERATED_BODY()

public:
	// 是否反选
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bReverse = false;

	// 是否检查MeshNames
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bCheckMeshNames = false;
	
	// 模型名称列表
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Meta = (EditCondition = "bCheckMeshNames", EditConditionHides))
	TArray<FName> MeshNames;

	// 是否检查 SocketNames
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bCheckSocketNames = false;

	// 模型挂接的骨骼名称列表
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Meta = (EditCondition = "bCheckSocketNames", EditConditionHides))
	TArray<FName> SocketNames;

	// 隐藏 或 显示
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bNeedHidden = true;

	// 优先级
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	int32 Priority = 5;

	// Task结束后是否要重置
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bNeedReset = false;

	virtual bool UpdateEditorProperty()
	{
		return false;
	}

};

#pragma endregion MeshVisibility






#pragma region AddMesh
UCLASS(Abstract, Blueprintable)
class UBSATAddMesh : public UBSATask
{
	GENERATED_BODY()

public:
	// 添加模型信息
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TArray<FBSMeshCreater> MeshList;

	// Task结束后是否需要重置
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bNeedReset = true;

	//是否开启延迟销毁
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bDelayDestroy = false;

	// 延迟销毁时间
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (ClampMin = 0.0f, ClampMax = 10.0f, EditCondition = "bDelayDestroy", EditConditionHides))
	float DelayDestroyTime = 0.0f;
	
	// 淡出时间
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (ClampMin = 0.0f, ClampMax = 10.0f, EditCondition = "bDelayDestroy", EditConditionHides))
	float FadeOutTime = 0.0f;

	// 初始显隐状态,true为显示, false交由MeshVisibility管理
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool InitialVisibility = true;
	
};

#pragma endregion AddMesh






#pragma region ModifyTerrain
UCLASS(Abstract, Blueprintable)
class UBSATModifyTerrain : public UBSATask
{
	GENERATED_BODY()

public:
	// 增加地形大小(仅支持Box)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FVector TerrainSize = FVector();

	// 坐标计算信息
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FBSATransformCreater CoordinateCreater;

	// 是否影响寻路(暂时不支持不影响寻路)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Meta = (EditCondition = "false"))
	bool bInfluencePathFinding = true;
};
#pragma endregion ModifyTerrain