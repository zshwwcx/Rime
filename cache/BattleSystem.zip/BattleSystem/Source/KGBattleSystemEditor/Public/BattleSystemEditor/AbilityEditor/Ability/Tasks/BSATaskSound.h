#pragma once

#include "CoreMinimal.h"
#include "AkAudio/Classes/AkAudioEvent.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSATaskSound.generated.h"



UCLASS(Abstract, Blueprintable)
class UBSATAkAudioEvent : public UBSATask
{
	GENERATED_BODY()
	
public:
	// 是否从数据缓冲中得到声音资源
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AkEvent")
	bool bUseInputAkEvent = false;

	// 声音资源
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AkEvent", Meta = (EditCondition = "!bUseInputAkEvent"))
	TSoftObjectPtr<UAkAudioEvent> AkEvent = nullptr;



	// Task结束时是否中断声音播放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interrupt")
	bool bInterruptAudio = false;

	// 声音中断的淡出时长
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interrupt")
	float BlendOutDuration = 0.0f;

	/* 声音中断的淡出方式
	 * AkCurveInterpolation_Log3			= 0, ///< Log3
	 * AkCurveInterpolation_Sine			= 1, ///< Sine
     * AkCurveInterpolation_Log1			= 2, ///< Log1
     * AkCurveInterpolation_InvSCurve		= 3, ///< Inversed S Curve
     * AkCurveInterpolation_Linear			= 4, ///< Linear (Default)
     * AkCurveInterpolation_SCurve			= 5, ///< S Curve
     * AkCurveInterpolation_Exp1			= 6, ///< Exp1
     * AkCurveInterpolation_SineRecip		= 7, ///< Reciprocal of sine curve
     * AkCurveInterpolation_Exp3			= 8, ///< Exp3
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interrupt")
	int32 BlendOutType = 4;



	// 是否进行绑定
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform")
	bool bNeedAttach = false;

	// 绑定模式下的骨骼名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach"))
	FBSSocketSelector AttachSocket;

public:
	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (!bUseInputAkEvent && AkEvent.IsNull())
		{
			return true;
		}

		return false;
	}

#endif

};
