#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"

#include "BattleSystemEditor/BSEditorStructs.h"

#include "BSAPreviewGameMode.generated.h"



UCLASS(minimalapi)
class ABSAPreviewGameMode : public AGameModeBase
{
	GENERATED_BODY()

#pragma region Predefine
#if WITH_EDITORONLY_DATA
public:
	// 技能默认提供的Task列表
	UPROPERTY(EditDefaultsOnly)
	FBSASkillCreater SkillDefaultTaskList;

	// Buff默认提供的Task列表
	UPROPERTY(EditDefaultsOnly)
	FBSASkillCreater BuffDefaultTaskList;
#endif
#pragma endregion Predefine

};

