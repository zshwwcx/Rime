#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSATaskMaterial.generated.h"



USTRUCT(Blueprintable, BlueprintType)
struct FBSATaskMeshMaterialOverride
{
	GENERATED_BODY()

public:
	// 组件名称
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FName MeshName;

	// 材质信息
	// UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	// TArray<FOverrideMaterialParameter> MaterialInfos;

};

UCLASS(Abstract, Blueprintable)
class UBSATChangeMeshMaterial : public UBSATask
{
	GENERATED_BODY()

public:
	// 是否修改所有的模型
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bChangeAllMesh = false;

	// 新的模型材质信息
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "!bChangeAllMesh", EditConditionHides))
	TArray<FBSATaskMeshMaterialOverride> OverrideMaterials;

	// 这些名称的组件不进行修改
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bChangeAllMesh", EditConditionHides))
	TArray<FName> ExceptMeshNames;

	// 新的模型材质信息
	// UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bChangeAllMesh", EditConditionHides))
	// TArray<FOverrideMaterialParameter> MaterialInfos;

	// 记录脚本要推送哪些数据
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	TArray<int32> MaterialScriptDataIndex;

public:
	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

#endif
};
