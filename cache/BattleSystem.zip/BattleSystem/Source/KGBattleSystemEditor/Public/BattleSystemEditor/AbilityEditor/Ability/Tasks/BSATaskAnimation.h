#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "Animation/AnimMontage.h"
#include "3C/Animation/AnimAssetDefine.h"

#include "BSATaskAnimation.generated.h"



#pragma region PlayAnimation
UENUM(BlueprintType, Meta = (Bitflags))
enum class EBSAAnimType : uint8
{
	AT_Blank               = 0               UMETA(DisplayName = "特定动画"),
	AT_Beaten                                UMETA(Hidden),
	AT_AnimAsset							 UMETA(Hidden),
	AT_AnimLib							     UMETA(DisplayName = "动画库中动画"),

	AT_TMax
};



UCLASS(Abstract, Blueprintable)
class UBSATPlayAnimation : public UBSATask
{
	GENERATED_BODY()

public:
	UBSATPlayAnimation() 
	{

	}

public:
	// 想要播放该动画的模型的名称，默认是Character的Mesh
	UPROPERTY(EditAnywhere, Category = "Animation")
	FName SkeltalMeshName = TEXT("Mesh");

	// 动画资源类型
	UPROPERTY(EditAnywhere, Category = "Animation")
	EBSAAnimType AnimType = EBSAAnimType::AT_Blank;

	// 蒙太奇资源(AllowedClasses = "AnimMontage")
	UPROPERTY(EditAnywhere, Category = "Animation", meta = (EditCondition = "AnimType == EBSAAnimType::AT_Blank"))
	TSoftObjectPtr<UAnimMontage> MontageAsset = NULL;

	// 受击动画名称
	UPROPERTY(EditAnywhere, Category = "Animation", meta = (EditCondition = "AnimType == EBSAAnimType::AT_Beaten || AnimType == EBSAAnimType::AT_AnimAsset"))
	FGameplayTag BeatenTag;

	UPROPERTY(EditAnywhere, Category = "Animation", meta = (EditCondition = "AnimType == EBSAAnimType::AT_AnimLib"))
	FAnimLibAssetID LibAssetID;

	// 播放速率
	UPROPERTY(EditAnywhere, Category = "Animation")
	float PlayRate = 1.0f;

	// 播放该蒙太奇时，是否终止同组其他蒙太奇的播放
	UPROPERTY(EditAnywhere, Category = "Animation", AdvancedDisplay)
	bool bStopGroup = true;

	// Task结束时是否中断Montage的播放，默认为是
	UPROPERTY(EditAnywhere, Category = "Animation", AdvancedDisplay)
	bool bFinishMontageWhenTaskEnd = true;

	// 该Task被中断时的淡出时间
	UPROPERTY(EditAnywhere, Category = "Animation")
	float InterruptBlendOut = 0.25f;

	// 该Task的蒙太奇播放优先级
	UPROPERTY(EditAnywhere, Category = "Animation", AdvancedDisplay)
	int32 MontagePlayPriority = 1000;
	

	// 动画Rootmotion是否生效
	UPROPERTY(EditAnywhere, Category = "Rootmotion")
	bool bEnableRootmotion = true;

	// RootMotion结束时的速度处理，小于0表示维持Rootmotion速度，大于0.01表示限制的速度值，[0, 0.01]表示Rootmotion结束速度清零
	UPROPERTY(EditAnywhere, Category = "Rootmotion", meta = (EditCondition = "bEnableRootmotion"))
	float FinishClampVelocity = 0.0f;

	// Rootmotion的AccumulateMode，0：Override;1:Addictive
	UPROPERTY(EditAnywhere, Category = "Rootmotion", meta = (EditCondition = "bEnableRootmotion"))
	int32 AccumulateMode = 0;

	// 曲线Rootmotion的优先级
	UPROPERTY(EditAnywhere, Category = "Rootmotion", meta = (EditCondition = "bEnableRootmotion"))
	int32 RootMotionPriority = 1000;

	// 是否要检测地面，防止角色停在半空中
	UPROPERTY(EditDefaultsOnly, Category = "Rootmotion", Meta = (EditCondition = "!bNeedTraceTarget"))
	bool bNeedCheckGround = true;
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Category = "Rootmotion", Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度的对象类型
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Category = "Rootmotion", Meta = (EditCondition = "bNeedCheckGround"))
	FVector2D GroundCheckOffset = FVector2D(-300.0f, 300.0f);

public:
	// Montage造成的Rootmotion偏移
	UPROPERTY(EditDefaultsOnly, Category = "ForExport")
	FTransform MontageRootmotion;

	// 记录RootMotion的Translation变化Curve
	UPROPERTY(EditDefaultsOnly, Category = "ForExport")
	FRuntimeFloatCurve TimeMappingTranslationFloatCurve;

	// 记录RootMotion的Translation变化Curve
	UPROPERTY(EditDefaultsOnly, Category = "ForExport")
	FRuntimeFloatCurve TimeMappingRotationFloatCurve;

	// 记录RootMotion的Translation变化Curve
	UPROPERTY(EditDefaultsOnly, Category = "ForExport")
	FRuntimeFloatCurve TimeMappingTrScaleFloatCurve;

public:
	void GetReferenceResources(TArray<FString>& InOutList) override;


#if WITH_EDITOR
public:
	virtual void PreSave(FObjectPreSaveContext SaveContext) override;
	
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty()
	{
		//if (UAnimMontage* MontageData = MontageAsset.LoadSynchronous())
		//{
		//	MontageRootmotion = MontageData->ExtractRootMotionFromTrackRange(0.0f, MontageData->GetPlayLength());
		//	ExportAnimRootmotionCurve();
		//}
		//else
		//{
		//	MontageRootmotion = FTransform();
		//	TimeMappingTrScaleFloatCurve.GetRichCurve()->Reset();
		//	TimeMappingRotationFloatCurve.GetRichCurve()->Reset();
		//	TimeMappingTranslationFloatCurve.GetRichCurve()->Reset();
		//}
		return false;
	}

	void ExportAnimRootmotionCurve();

	bool IsTaskInvalid_Implementation() override
	{
		return MontageAsset.IsNull();
	}

#endif

};



UCLASS(Abstract, Blueprintable)
class UBSATPlayJumpAnimation : public UBSATask
{
	GENERATED_BODY()

public:
	UBSATPlayJumpAnimation()
	{

	}

public:
	// 想要播放该动画的模型的名称，默认是Character的Mesh
	UPROPERTY(EditAnywhere, Category = "Animation")
	FName SkeltalMeshName = TEXT("Mesh");

	// Idle时触发的蒙太奇资源(AllowedClasses = "AnimMontage")，为空时会再次尝试找LocoInputMontageAsset
	UPROPERTY(EditAnywhere, Category = "Animation")
	TSoftObjectPtr<UAnimMontage> IdleMontageAsset = NULL;

	// 有移动输入时的蒙太奇资源(AllowedClasses = "AnimMontage")，为空时会再次尝试找IdleMontageAsset
	UPROPERTY(EditAnywhere, Category = "Animation")
	TSoftObjectPtr<UAnimMontage> LocoInputMontageAsset = NULL;

	// 播放速率
	UPROPERTY(EditAnywhere, Category = "Animation")
	float PlayRate = 1.0f;

	// 播放该蒙太奇时，是否终止同组其他蒙太奇的播放
	UPROPERTY(EditAnywhere, Category = "Animation", AdvancedDisplay)
	bool bStopGroup = true;

	// Task结束时是否中断Montage的播放，默认为是
	UPROPERTY(EditAnywhere, Category = "Animation", AdvancedDisplay)
	bool bFinishMontageWhenTaskEnd = true;

	// 该Task被中断时的淡出时间
	UPROPERTY(EditAnywhere, Category = "Animation")
	float InterruptBlendOut = 0.25f;

	// 该Task的蒙太奇播放优先级
	UPROPERTY(EditAnywhere, Category = "Animation", AdvancedDisplay)
	int32 MontagePlayPriority = 1000;


public:
	void GetReferenceResources(TArray<FString>& InOutList) override;


#if WITH_EDITOR
public:
	//virtual void PreSave(FObjectPreSaveContext SaveContext) override;

	//virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty()
	{
		return false;
	}


	bool IsTaskInvalid_Implementation() override
	{
		return IdleMontageAsset.IsNull() && LocoInputMontageAsset.IsNull();
	}

#endif

};

#pragma endregion PlayAnimation
