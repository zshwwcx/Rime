#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "Curve/KGCurve.h"

#include "BattleSystem/Ability/Task/BSATaskEnums.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"
#include "BattleSystem/Ability/Task/BSATaskInstanceV2.h"

#include "BSATask.generated.h"



// 可扩展的Task基类
UCLASS(Abstract, Blueprintable, EditInlineNew)
class UBSATaskBase : public UObject
{
	GENERATED_BODY()

#pragma region Important
protected:
	// 生命周期类型
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base Property")
	EBSATaskLife LifeType = EBSATaskLife::TL_DurAndController;

	// 持续时长
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base Property")
	float Duration = 1.0f;

public:
	// 获取Task的生命周期类型
	UFUNCTION(BlueprintPure)
	EBSATaskLife GetLifeType();

	// 获取Task的时长
	UFUNCTION(BlueprintPure)
	virtual float GetDuration();

	// 获取Task的引用资源列表
	virtual void GetReferenceResources(TArray<FString>& InOutList);

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	void GetBPReferenceResources(const TArray<FString>& InList, TArray<FString>& OutList);

#pragma endregion Important



#if WITH_EDITORONLY_DATA
public:
	UPROPERTY(EditDefaultsOnly, Category = "Base Property")
	FText TaskDisplayName;
#endif

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	// 判断两个Task是否相同
	bool IsEqual(UBSATaskBase* OtherTask);

	// 从另一个Task中获取数值
	virtual void CopyDataFromOther(UBSATaskBase* OtherTask);

	// 获得Task的名称
	FText GetTaskName() const;

	// 设置Task的名称
	void SetTaskName(FText NewName);

	// 检查是否可以修改持续时长
	virtual bool CanChangeDuration() const;

	// 设置Task的生命周期类型
	virtual void SetLifeType(EBSATaskLife InNewType);

	// 设置Task的持续时长
	virtual void SetDuration(float InDuration);

	// 手动调用PostEditChangeProperty
	void CallPostEditChangeProperty(FName InPropertyName);
#endif

};



// 给技能/BUFF使用的Task类
UCLASS(Abstract, Blueprintable, EditInlineNew)
class UBSATask : public UBSATaskBase
{
	GENERATED_BODY()

public:
	UBSATask();

#pragma region Important
protected:
	// 网络类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base Property")
	EBSATaskNet NetType = EBSATaskNet::TN_ServerAndClient;

	// 选取的目标
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base Property", Meta = (Bitmask, BitmaskEnum = "/Script/KGBattleSystem.EBSATaskTarget"))
	int32 TargetTypes = 1;
	// 如果目标类型包含"碰撞目标"，在这里添加碰撞数据来源
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base Property", Meta = (EditCondition = "bUseCollisionTarget"))
	TArray<FBSATaskInputInfo> CollisionTargetInfos;

	// 开始时间
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base Property")
	float StartTime = 0.0f;

	// 触发方式
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base Property", Meta = (Bitmask, BitmaskEnum = "/Script/KGBattleSystem.EBSATaskTrigger"))
	int32 TriggerMethod = 1;

	// 重要度阈值（当重要度小于等于该值时，允许触发，默认大部分情况下都允许触发）
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base Property")
	int32 TriggerSignificance = 10;

public:
	virtual float GetDuration() override;

	UFUNCTION(BlueprintPure)
	EBSATaskNet GetNetType() const;

	UFUNCTION(BlueprintPure)
	int32 GetTargetTypes() const;
	UFUNCTION(BlueprintPure)
	void GetCollisionTargetInfos(TArray<FBSATaskInputInfo>& OutInfos) const;

	UFUNCTION(BlueprintPure)
	float GetStartTime() const;

	UFUNCTION(BlueprintPure)
	int32 GetTriggerMethod() const;

	UFUNCTION(BlueprintPure)
	bool GetEventTaskList(const FName& InEventName, FBSATaskSelectorList& OutTaskList);

#pragma endregion Important



#pragma region GBSData
public:
	// 该Task的数据读取(获取"XXX"Task生产的名为"xxx"的数据)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RunTime Data")
	TArray<FBSATaskInputInfo> InputDatas;

	// 该Task的数据输出(生产名为"xxx"的"xxx"类型的数据)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "RunTime Data")
	TArray<FBSATaskOutputInfo> OutputDatas;

#pragma endregion GBSData



#pragma region Event
public:
	// 是否在网络上广播触发的事件
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Event")
	bool bNetMulticastEvent = false;

	// 事件触发Task列表
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Event")
	TMap<FName, FBSATaskSelectorList> EventTaskMap;

#pragma endregion Event



#pragma region Data
public:
	// 根据InTemplateTaskList修复Task之间的依赖关系
	static void FixTaskListDependency(TArray<UBSATask*>& InOutTaskList, const TArray<UBSATask*>& InTemplateTaskList);

#pragma endregion Data



#pragma region Export
protected:
	// 索引
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadWrite, Category = "For Export")
	int32 Index = 0;

	// 类
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadWrite, Category = "For Export")
	TSubclassOf<UBSATask> ClassType = nullptr;

#pragma endregion Export



#pragma region Editor
#if WITH_EDITORONLY_DATA
public:
	// Task节点注释
	UPROPERTY(EditDefaultsOnly, Category = "Base Property")
	FString TaskNote;

	UPROPERTY(VisibleDefaultsOnly, AdvancedDisplay, Category = "Base Property")
	bool bUseCollisionTarget = false;

	// 不参与哪些自动检查
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, Category = "Base Property")
	uint32 IgnoreAutoOptimize = 0;

	// GUI查询表
	UPROPERTY()
	TMap<FString, int64> GUIDMap;
#endif

#if WITH_EDITOR
public:
	virtual void PreSave(FObjectPreSaveContext SaveContext) override;
	UFUNCTION(BlueprintImplementableEvent)
	void ReceivePreSave();

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
	UFUNCTION(BlueprintImplementableEvent)
	void ReceivePostEditChangeProperty(const FString& PropertyName);

	virtual void CopyDataFromOther(UBSATaskBase* OtherTask) override;

	void UpdateGUIDMap();

	void CleanInvalidDependencies();

	// 更新Task的里包含的FGBSTaskSelector结构体的默认配置
	void RefreshTaskSelector();

	// 设置起始时间
	void SetStartTime(float Time);

	// 设置触发模式
	void SetTriggerMethod(int32 NewMethod);

	// 设置网络类型
	void SetNetType(EBSATaskNet NewNetType);

	// 设置索引
	void SetIndex(int32 InIndex);

	// 批量更新配置数据时使用
	virtual bool UpdateEditorProperty() 
	{
		return false; 
	}

	// 批量更新蓝图配置数据时使用
	UFUNCTION(BlueprintImplementableEvent)
	bool UpdateBlueprintProperty();

	// 更新碰撞输入信息
	void SetCollisionTargetInfo(int32 Index, FName DataTag, UBSATask* DataOwner);

	// 更新输入信息
	void SetInputDataInfo(int32 Index, FName DataTag, UBSATask* DataOwner);

	// 根据对动态对象的拖拽结果更新数据
	virtual void UpdateDataByDynamicActorInfo(const FBSADynamicObjectInfo& InInfo) {}

	// 更新所有的动态对象
	virtual void UpdateDynamicActorByData(const FBSADynamicObjectInfoArray& InInfoArray) {}

	// 检查Task是否正确配置
	UFUNCTION(BlueprintNativeEvent)
	bool IsTaskInvalid();
	virtual bool IsTaskInvalid_Implementation(){ { return false; } }

public:
	float StageDuration = 0.0f;
#endif
#pragma endregion Editor

};
