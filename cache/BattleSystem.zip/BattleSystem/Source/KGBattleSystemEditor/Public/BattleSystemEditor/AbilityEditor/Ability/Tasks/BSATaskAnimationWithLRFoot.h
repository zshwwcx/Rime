#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskAnimation.h"

#include "Animation/AnimMontage.h"
#include "3C/Animation/AnimAssetDefine.h"

#include "BSATaskAnimationWithLRFoot.generated.h"

#pragma region PlayAnimation


UCLASS(Abstract, Blueprintable)
class UBSATPlayAnimationWithLRFoot : public UBSATPlayAnimation
{
	GENERATED_BODY()

public:
	UBSATPlayAnimationWithLRFoot()
	{

	}

public:
	// 右脚蒙太奇资源
	UPROPERTY(EditAnywhere, Category = "Animation", meta = (EditCondition = "AnimType == EBSAAnimType::AT_Blank && bDistinguishLeftRightFoot"))
	TSoftObjectPtr<UAnimMontage> MontageAssetRightFoot = NULL;

	// 是否区分左右脚
	UPROPERTY(EditAnywhere, Category = "Animation", AdvancedDisplay)
	bool bDistinguishLeftRightFoot = false;
public:
	void GetReferenceResources(TArray<FString>& InOutList) override;
#if WITH_EDITOR
public:

#endif

};

#pragma endregion PlayAnimation
