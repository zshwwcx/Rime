#pragma once

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"

#include "BattleSystem/Ability/BSAEnums.h"
#include "BattleSystem/Ability/BSAStructs.h"

#include "BSABuffAsset.generated.h"



UCLASS(Blueprintable)
class KGBATTLESYSTEMEDITOR_API UBSABuffAsset : public UBSAAsset
{
	GENERATED_BODY()

public:
	UBSABuffAsset(const FObjectInitializer& ObjectInitializer);



#pragma region Important
public:
	// BUFF标签
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Important")
	FGameplayTagContainer BuffTags;

	// 是否需要网络同步
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Important")
	bool bNeedReplicated = true;

	// 网络同步的对象筛选
	UPROPERTY(EditDefaultsOnly, Category = "Important", Meta = (EditCondition = "bNeedReplicated", EditConditionHides, Bitmask, BitmaskEnum = "/Script/KGBattleSystem.EBSAReplicateTarget"))
	int32 ReplicatedTargetTypes = 15;

#pragma endregion Important



#pragma region API
#if WITH_EDITOR
public:
	void InitByEditor(UObject* WorldContext) override;

	void PreEditChange(FProperty* PropertyThatWillChange) override;

	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;

	// 添加Section
	bool AddSection(FName NewSectionName = NAME_None) override { return false; }

	// 删除Section
	bool RemoveSection(int32 SectionID) override { return false; }

	void ChangeSectionName(int32 SectionID, FName NewName) override;

	void ChangeSectionLoopTime(int32 SectionID, int32 NewLoop) override;

	void ChangeSectionDuration(int32 SectionID, float NewDuration) override;

#endif
#pragma endregion API

};

