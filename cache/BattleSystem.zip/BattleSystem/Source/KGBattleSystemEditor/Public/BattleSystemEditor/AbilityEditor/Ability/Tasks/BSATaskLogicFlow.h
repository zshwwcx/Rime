#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BattleSystem/Ability/BSACondition.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"

#include "BSATaskLogicFlow.generated.h"



UCLASS(Abstract, Blueprintable)
class UBSATBranch : public UBSATask
{
	GENERATED_BODY()
	
public:
	UBSATBranch();

public:
	// 判断条件
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Instanced)
	UBSACondition* Condition = nullptr;

	// 判断成功，提前结束
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Meta = (EditCondition = "LifeType != EBSATaskLife::TL_Instant"))
	bool TerminateWhenCheckSucess = true;



#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty()
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		return Condition == nullptr;
	}

#endif

};



UCLASS(Abstract, Blueprintable)
class UBSATSwitch : public UBSATask
{
	GENERATED_BODY()

public:
	UBSATSwitch();

public:
	// 判断条件列表
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Instanced)
	TArray<UBSACondition*> ConditionList;

	// 判断成功，提前结束
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Meta = (EditCondition = "LifeType != EBSATaskLife::TL_Instant"))
	bool TerminateWhenCheckSucess = true;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty()
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		if (ConditionList.Num() == 0)
		{
			return true;
		}

		for (int i = 0; i < ConditionList.Num(); i++)
		{
			if (ConditionList[i] == nullptr)
			{
				return true;
			}
		}

		return false;
	}

#endif

};



UCLASS(Abstract, Blueprintable)
class UBSATTerminateSelf : public UBSATask
{
	GENERATED_BODY()

};



UCLASS(Abstract, Blueprintable)
class UBSATChangeSection : public UBSATask
{
	GENERATED_BODY()

public:
	// 跳转到哪个Section
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	int32 NextSectionID = 0;

};



UCLASS(Abstract, Blueprintable)
class UBSATFilterTarget : public UBSATask
{
	GENERATED_BODY()

public:
	// 条件筛选
	UPROPERTY(EditDefaultsOnly, Category = "Filter", BlueprintReadWrite, Instanced)
	UBSACondition* Condition = nullptr;

	// 锁定筛选结果
	UPROPERTY(EditDefaultsOnly, Category = "Filter")
	bool bLockResult = false;



#if WITH_EDITOR
public:
	virtual bool UpdateEditorProperty()
	{
		return false;
	}

#endif

};



UCLASS(Abstract, Blueprintable)
class UBSATTerminateTask : public UBSATask
{
	GENERATED_BODY()

public:
	// 需要终结的Task
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FBSATaskSelectorList TasksToTerminate;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	bool IsTaskInvalid_Implementation() override
	{
		if (TasksToTerminate.SelectedTaskList.Num() == 0)
		{
			return true;
		}

		for (int i = 0; i < TasksToTerminate.SelectedTaskList.Num(); i++)
		{
			if (TasksToTerminate.SelectedTaskList[i].SelectedTask == nullptr)
			{
				return true;
			}
		}

		return false;
	}

#endif

};
