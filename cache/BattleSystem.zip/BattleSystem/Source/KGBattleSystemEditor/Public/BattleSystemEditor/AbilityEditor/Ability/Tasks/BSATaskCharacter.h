#pragma once

#include "CoreMinimal.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystem/Ability/BSAStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"

#include "BSATaskCharacter.generated.h"



#pragma region ActorParameter
USTRUCT(BlueprintType)
struct FTaskMeshCollectionInput
{
	GENERATED_USTRUCT_BODY()

public:
	// Socket名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName SocketName = NAME_None;

	// Transform选取的坐标系
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<ERelativeTransformSpace> TransSpace = ERelativeTransformSpace::RTS_World;

	// Socket偏移Transform
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FTransform MeshOffsetTransform = FTransform::Identity;

};

UCLASS(Abstract, Blueprintable)
class UBSATActorParameterCollection : public UBSATask
{
	GENERATED_BODY()

public:
	// 角色模型坐标收集
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Mesh")
	TArray<FTaskMeshCollectionInput> MeshCollector;

	// 角色坐标输出Offset
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Mesh")
	FVector ActorLocationOutputOffset;

#if WITH_EDITOR
public:
	void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;

#endif

};



USTRUCT(BlueprintType)
struct FTaskActorParameterSetMsg
{
	GENERATED_USTRUCT_BODY()

public:
	// Actor参数
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FGameplayTag ActorParam;

	// 是否使用输入float座位曲线表
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bUseInputAsTime = false;

	// 参数设置
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FRuntimeFloatCurve DeltaFloatTimeCurve;

	// 是否在Task时间内循环Curve设置参数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "!bUseInputAsTime", EditConditionHides))
	bool bLoopCurve = false;

	// 曲线设置间隔时间（<=0.0f代表逐帧设置）
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "!bUseInputAsTime", EditConditionHides))
	float SetCurveInterval = 0.0f;

	// Task结束时候是否回退
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bNeedRevert = false;

	// Override上下限(业务端对属性的上下限管理)
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D OverrideMinMax = FVector2D(0.0f, -1.0f);
};

UCLASS(Abstract, Blueprintable)
class UBSATSetActorParameter : public UBSATask
{
	GENERATED_BODY()

public:
	// 设置Actor参数
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FTaskActorParameterSetMsg> ActorSetter;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (ActorSetter.Num() == 0)
		{
			return true;
		}

		for (int i = 0; i < ActorSetter.Num(); i++)
		{
			if (!ActorSetter[i].ActorParam.IsValid())
			{
				return true;
			}
		}

		return false;
	}

	virtual bool UpdateEditorProperty()
	{
		return false;
	}

#endif

};

#pragma endregion ActorParameter






#pragma region Revive
USTRUCT(BlueprintType)
struct FTaskReviveParams
{
	GENERATED_USTRUCT_BODY()

public:
	// 复活目标要设置的属性名（例如：HP）
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString TargetAttrName;

	// 百分比设置属性时的分母属性（例如：MaxHp）
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bResumePercentageOrAbsoluteValue", EditConditionHides))
	FString SourceAttrName;

	// 按照百分比还是绝对值设置
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bResumePercentageOrAbsoluteValue = true;

	// 值（30%即30）
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Value = 0.0;
};

UCLASS(Abstract, Blueprintable)
class UBSATRevive : public UBSATask
{
	GENERATED_BODY()

public:
	// 请求对方复活还是直接将对方复活
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bRequestOrDirectly;

	// 复活时设置的参数
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TArray<FTaskReviveParams> ReviveParams;
};

#pragma endregion Revive






#pragma region CreateActor
UCLASS(Abstract, Blueprintable)
class UBSATCreateActor : public UBSATask
{
	GENERATED_BODY()

public:

};

#pragma endregion CreateActor






#pragma region Attach
UCLASS(Abstract, Blueprintable)
class UBSATCharacterAttach : public UBSATask
{
	GENERATED_BODY()

public:
	// 绑定还是解绑操作
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool AttachOrDetach = true;
	
	// 绑定对象的SocketName
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FName SocketName = NAME_None;

	// 绑定偏移
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FTransform AttachTransform;

	// 是否在Task生效期间监控并修正RelativeTransform
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "AttachOrDetach", EditConditionHides))
	bool RelativeTransformRectify = false;

	// Task结束时候是否解绑
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (EditCondition = "AttachOrDetach", EditConditionHides))
	bool DetachOnTaskEnd = false;
};

#pragma endregion Attach
