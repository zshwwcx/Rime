#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Serialization/JsonSerializer.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/BSEditorFunctionLibrary.h"

#include "BSAJsonExporter.generated.h"


UCLASS()
class UBSAJsonExporter : public UBSJsonExporter
{
	GENERATED_BODY()

public:
	virtual void ExportSpecialStructToJson(void* DataAddress, FStructProperty* TheStructProp, TSharedPtr<FJsonObject> OutJson, FString ExtraString = "") const override;

	virtual void ExportSpecialObjectToJson(UObject* TheObject, TSharedPtr<FJsonObject> OutJson, FString ExtraString = "") const override;

	TSharedPtr<FJsonValue> ExportGameplayTag(FGameplayTag& InTag) const override;

	TSharedPtr<FJsonValue> ExportGameplayTagContainer(FGameplayTagContainer& InTagContainer) const override;

	int64 TryGetGUID(FString PropName) const;

public:
	TWeakObjectPtr<UBSAAsset> CachedAsset = nullptr;

};

