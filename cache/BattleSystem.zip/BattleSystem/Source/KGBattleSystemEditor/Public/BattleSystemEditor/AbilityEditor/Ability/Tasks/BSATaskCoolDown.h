#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystem/Ability/BSAStructs.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"

#include "BSATaskCoolDown.generated.h"



UCLASS(Abstract, Blueprintable)
class UBSATSetCoolDown : public UBSATask
{
	GENERATED_BODY()

public:
	// 调整总冷却时间(true)还是当前剩余的冷却时间(false)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "AdjustParam")
	bool TotalOrCurrent;

	// 使用百分比折扣(true)还是绝对时间缩减(false)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "AdjustParam")
	bool DiscountOrCut;

	// 百分比折扣分母是Total(true)还是Current(false)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "AdjustParam", Meta = (EditCondition = "DiscountOrCut && !TotalOrCurrent", EditConditionHides))
	bool DiscountOfTotalOrCurrent;

	// 技能冷却调整值(例如：CD缩减2s，则为2.0；CD缩减至10%，则为0.9)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "AdjustParam")
	float AdjustValue;



	// 是否调整目标所有技能缩减
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Skill")
	bool bAdjustAll;

	// 是否反选技能列表(bReverseSelect为true时，则除了AdjustedSkillArray的技能ID其余均调整)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Skill", Meta = (EditCondition = "!bAdjustAll && !TotalOrCurrent", EditConditionHides))
	bool bReverseSelect = false;

	// 非调整所有技能缩减时，需要调整CD的技能列表
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Skill", Meta = (EditCondition = "!bAdjustAll", EditConditionHides))
	TArray<int32> AdjustedSkillArray;



#if WITH_EDITOR
public:
	virtual bool UpdateEditorProperty() override
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		if (!bAdjustAll && AdjustedSkillArray.Num() == 0)
		{
			return true;
		}

		return false;
	}

#endif
};
