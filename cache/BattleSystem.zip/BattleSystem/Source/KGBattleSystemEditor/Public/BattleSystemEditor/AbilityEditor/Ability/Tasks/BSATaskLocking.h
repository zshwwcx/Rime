#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSATaskLocking.generated.h"


#pragma region LockingLimit
UCLASS(Abstract, Blueprintable)
class UBSATLockingLimit : public UBSATask
{
	GENERATED_BODY()

public:
	
};

#pragma endregion LockingLimit
