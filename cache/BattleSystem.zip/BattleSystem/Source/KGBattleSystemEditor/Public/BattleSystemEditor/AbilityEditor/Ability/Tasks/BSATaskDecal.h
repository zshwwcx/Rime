#pragma once

#include "CoreMinimal.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystem/Ability/BSAStructs.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSATaskDecal.generated.h"



#pragma region AddDecal
class UMaterialInstance;

UCLASS(Abstract, Blueprintable)
class UBSATAddDecal : public UBSATask
{
	GENERATED_BODY()

public:
	// Decal材质资源
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Decal Material")
	TSoftObjectPtr<UMaterialInstance> DecalAsset = nullptr;

	// 材质参数
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Decal Material")
	TArray<FBSADynamicMaterialParams> DynamicMaterialParams;



	// DecalSize
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Decal Parameter")
	FVector DecalSize;

	// 淡入时间
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Decal Parameter")
	float FadeInDuration;

	// 淡出时间
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Decal Parameter")
	float FadeDuration;

	// 渲染优先级，数量越高渲染顺序越靠后，越在表面
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Decal Parameter")
	int32 SortOrder;

	// 贴花的可视距离，越大越容易消失，默认为0不消失
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Decal Parameter")
	float FadeScreenSize;

	

	// 根据输入设置DecalSize
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Decal ")
	bool UseInputDecalSize;

	// 根据输入设置DecalSize的持续时间(如<0表示始终更新DecalSize， 持续更新功能暂不生效)
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Decal ")
	float UseInputDecalSizeTime;

public:
	// 是否进行绑定
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Transform")
	bool bNeedAttach = false;

	// 是否绑定旋转(true：跟随角色旋转)
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Transform", Meta = (EditCondition = "bNeedAttach"))
	bool bAttachRotation = false;

	// 是否绑定缩放(true：跟随角色缩放)
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Transform", Meta = (EditCondition = "bNeedAttach"))
	bool bAttachScale = false;

	// 绑定模式下的骨骼名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSSocketSelector AttachSocket;

	// 绑定模式下的坐标偏移矩阵
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSATPP_Transform AttachTransform;

	// 坐标计算信息
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "!bNeedAttach"))
	FBSATransformCreater CoordinateCreater;

	// 是否要贴近地表生成
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Transform", Meta = (EditCondition = "!bNeedAttach"))
	bool bNeedCheckGround = false;

	// 地表查询射线的对象类型
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度(X,Y)/向上偏移距离(Z)
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	FVector ExtraGroundMsg = FVector(-400.0f, 400.0f, 2.0f);

public:
	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	void UpdateDataByDynamicActorInfo(const FBSADynamicObjectInfo& InInfo) override;

	void UpdateDynamicActorByData(const FBSADynamicObjectInfoArray& InInfoArray) override;

	bool UpdateEditorProperty() override
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		return DecalAsset.IsNull();
	}
#endif

};

#pragma endregion AddDecal
