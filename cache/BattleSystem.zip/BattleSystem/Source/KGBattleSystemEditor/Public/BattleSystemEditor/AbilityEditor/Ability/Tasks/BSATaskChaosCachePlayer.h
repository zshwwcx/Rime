#pragma once

#include "CoreMinimal.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystem/Ability/BSAStructs.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSATaskChaosCachePlayer.generated.h"



#pragma region AddChaosCachePlayer
UCLASS(Abstract, Blueprintable)
class UBSATAddChaosCachePlayer : public UBSATask
{
	GENERATED_BODY()

public:
	// ChaosCache资源
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "ChaosCache")
	TSoftObjectPtr<UChaosCacheCollection> CacheCollection = nullptr;

	// CacheMode
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "ChaosCache")
	ECacheMode CacheMode;

	// StartMode，暂不支持触发
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "ChaosCache")
	EStartMode StartMode;

	// StartTime，指开始播放时的时间点，例：延后播放3s，则需要填-3.0
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "ChaosCache")
	float ChaosCacheStartTime;

public:
	// 是否进行绑定
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Transform")
	bool bNeedAttach = false;

	// 绑定模式下的骨骼名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSSocketSelector AttachSocket;

	// 绑定模式下的坐标偏移矩阵
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSATPP_Transform AttachTransform;

	// 坐标计算信息
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "!bNeedAttach"))
	FBSATransformCreater CoordinateCreater;

	// 是否要贴近地表生成
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Transform", Meta = (EditCondition = "!bNeedAttach"))
	bool bNeedCheckGround = false;

	// 地表查询射线的对象类型
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度(X,Y)/向上偏移距离(Z)
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, Category = "Transform", Meta = (EditCondition = "bNeedCheckGround"))
	FVector ExtraGroundMsg = FVector(-400.0f, 400.0f, 2.0f);

public:
	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	void UpdateDataByDynamicActorInfo(const FBSADynamicObjectInfo& InInfo) override;

	void UpdateDynamicActorByData(const FBSADynamicObjectInfoArray& InInfoArray) override;

	bool UpdateEditorProperty() override
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		return CacheCollection.IsNull();
	}
#endif

};

#pragma endregion AddChaosCachePlayer
