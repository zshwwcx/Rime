#pragma once

#include "CoreMinimal.h"
#include "SViewportToolBar.h"



class SBSAEditorViewportToolBar : public SViewportToolBar
{
public:
	SLATE_BEGIN_ARGS(SBSAEditorViewportToolBar) 
	{

	}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, TSharedPtr<class FBSAEditor> InEditor, TSharedPtr<class SBSAEditorViewport> InViewport);

private:
	EVisibility GetTransformToolBarVisibility() const;

	TSharedRef<class SWidget> GenerateViewMenu();
	
	FText GetCameraModeEntryLable(FName Mode, bool bSkillBone = false) const;

	void SetCameraMode(FName CameraMode);

	FName GetCameraMode() const;

	TSharedRef<class SWidget> MakeFOVWidget() const;

private:
	TWeakPtr<class FBSAEditor> CachedEditor = nullptr;

	TWeakPtr<class SBSAEditorViewport> CachedViewport = nullptr;

	TSharedPtr<class FExtender> OptionsMenuExtender = nullptr;
};