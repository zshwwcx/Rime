#pragma once

#include "CoreMinimal.h"

#include "BattleSystem/BSManager.h"
#include "BattleSystem/Ability/BSACondition.h"
#include "3C/Character/BSUnit.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "BattleSystem/Ability/Task/BSATaskInstanceV2.h"

#include "BattleSystemEditor/BSEditorLuaGI.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Enums/BSAEditEnums.h"
#include "UObject/UObjectIterator.h"

#include "BSATaskBattle.generated.h"



#pragma region Attack
// 冲量原点选取
UENUM(BlueprintType)
enum class EBSAImpulseOriginType : uint8
{
	IOT_Attacker               = 0               UMETA(DisplayName = "攻击者位置"),
	IOT_CollisionShape                           UMETA(DisplayName = "碰撞盒位置"),
	IOT_SpecialLocation                          UMETA(DisplayName = "特定位置"),

	IOT_TMax                                     UMETA(Hidden)
};



UCLASS(Abstract, Blueprintable)
class UBSATAttack : public UBSATask
{
	GENERATED_BODY()

public:
	// 攻击ActionID
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackData")
	int32 AttackActionID = 1;

	// 选择策略
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackData")
	EBSASelectSrategy AttackStrategy = EBSASelectSrategy::SS_Default;

	// 攻击者选取策略
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackData")
	EBSASelectTarget AttackerType = EBSASelectTarget::ST_Owner;



	// 攻击冲量原点选取类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackPerformance")
	EBSAImpulseOriginType ImpulseOriginType = EBSAImpulseOriginType::IOT_Attacker;

	// 攻击冲量原点位置计算
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackPerformance", Meta = (EditCondition = "ImpulseOriginType == EBSAImpulseOriginType::IOT_SpecialLocation", EditConditionHides))
	FBSATransformCreater ImpulseOrigin;

	// 攻击冲量的相对方向(零向量代表冲量原点与目标之间的连线)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackPerformance")
	FVector ImpulseDirection = FVector(1.0f, 0.0f, 0.0f);

	// 特效的相对朝向(默认竖直向上)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackPerformance")
	FRotator EffectRelativeRotation = FRotator::ZeroRotator;

#if WITH_EDITORONLY_DATA
	// 当Task执行者仅为一个人 或 碰撞结果时，不再需要进行目标筛选
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Filter")
	bool bNeedFilterTarget = false;
#endif

	// 筛选攻击的目标
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Filter", Meta = (EditCondition = "bNeedFilterTarget"))
	FBSSelectTargetInfo AttackTargetInfo = FBSSelectTargetInfo(0, 0);



#if WITH_EDITOR
public:
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty()
	{
		return false;
	}

public:
	bool IsTaskInvalid_Implementation() override
	{
		if (UBSAAsset* Asset = Cast<UBSAAsset>(GetOuter()))
		{
			for (TObjectIterator<UBSEditorLuaGI> It; It; ++It)
			{
				if (UBSEditorLuaGI* GI = *It)
				{
					return !GI->CheckIsSkillActionValid(Asset->ID, AttackActionID);
				}
			}
		}

		return false;
	}

#endif

};






USTRUCT(BlueprintType)
struct FBSAConditionAttack
{
	GENERATED_USTRUCT_BODY()

public:
	// 条件
	UPROPERTY(EditDefaultsOnly, Instanced)
	UBSACondition* Condition = nullptr;

	// ActionID
	UPROPERTY(EditDefaultsOnly)
	int32 ActionID = 1;

};

UCLASS(Abstract, Blueprintable)
class UBSATConditionAttack : public UBSATask
{
	GENERATED_BODY()

public:
	// 条件攻击列表
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackData")
	TArray<FBSAConditionAttack> AttackArray;

	// 攻击策略对应SkillActionID（配置的TargetCamp和TargetType将影响受击目标筛选）
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackData")
	int32 AttackStrategyActionID = 1;
	
	// 攻击策略
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackData")
	EBSASelectSrategy AttackStrategy = EBSASelectSrategy::SS_Default;

	// 攻击者选取策略
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackData")
	EBSASelectTarget AttackerType = EBSASelectTarget::ST_Owner;



	// 攻击冲量原点选取类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackPerformance")
	EBSAImpulseOriginType ImpulseOriginType = EBSAImpulseOriginType::IOT_Attacker;

	// 攻击冲量原点位置计算
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackPerformance", Meta = (EditCondition = "ImpulseOriginType == EBSAImpulseOriginType::IOT_SpecialLocation", EditConditionHides))
	FBSATPP_Transform ImpulseOrigin;

	// 攻击冲量的相对方向(零向量代表冲量原点与目标之间的连线)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackPerformance")
	FVector ImpulseDirection = FVector(1.0f, 0.0f, 0.0f);

	// 特效的相对朝向(默认竖直向上)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AttackPerformance")
	FRotator EffectRelativeRotation = FRotator::ZeroRotator;



#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (AttackArray.Num() == 0)
		{
			return true;
		}

		for (int i = 0; i < AttackArray.Num(); i++)
		{
			if (AttackArray[i].Condition == nullptr)
			{
				if(i == AttackArray.Num() - 1)
				{
					// 最后一个条件节点可以为空，表示直接执行
					continue;
				}
				return true;
			}
		}

		return false;
	}

#endif
};

#pragma endregion Attack






#pragma region Beaten
UCLASS(Abstract, Blueprintable)
class UBSATChangeStagger : public UBSATask
{
	GENERATED_BODY()

public:
	// 开始时的硬直状态
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Start")
	EBSStaggerState StartStagger = EBSStaggerState::SS_Repel;

	// 开始时的硬直状态是否使用输入数据
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Start")
	bool bStartUseInput = true;

	// 攻击者相对于受击者的方向
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Start")
	EBSAttackerLocationType AttackerLocationType = EBSAttackerLocationType::ALT_None;

	// 开始时的硬直状态持续时间
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Start", EditFixedSize, Meta = (EditCondition = "!bStartUseInput", EditConditionHides))
	float StartStaggerDuration = 1.0;



	// 结束时的硬直状态(默认不切换)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "End")
	EBSStaggerState EndStagger = EBSStaggerState::SS_TMax;

	// 结束时的硬直状态是否使用输入数据
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "End")
	bool bEndUseInput = true;

	// 结束时的硬直状态持续时间
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "End", EditFixedSize, Meta = (EditCondition = "!bEndUseInput", EditConditionHides))
	float EndStaggerDuration = 1.0;


#if WITH_EDITOR
public:
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty()
	{
		return false;
	}

#endif

};

#pragma endregion Beaten






#pragma region Ability
UCLASS(Abstract, Blueprintable)
class UBSATActivateSkill : public UBSATask
{
	GENERATED_BODY()

public:
	// 要执行的技能
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TSoftObjectPtr<class UBSASkillAsset> SkillAsset = nullptr;

	// 指定技能的始作俑者(默认无效选项，代表执行技能的人自己)
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	EBSASelectTarget InstigatorType = EBSASelectTarget::ST_Owner;

	// 指定技能的目标
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Meta = (Bitmask, BitmaskEnum = "/Script/KGBattleSystem.EBSATaskTarget"))
	int32 SkillTarget = 8;

	// 是否检查条件
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bCheckCondition = false;


public:
	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
	// 批量更新配置数据时使用
	bool UpdateEditorProperty() override
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		return SkillAsset.IsNull();
	}
#endif

};






USTRUCT(BlueprintType)
struct FBSAComboWindowMsg
{
	GENERATED_USTRUCT_BODY()

public:
	// 要设置ComboWindow的技能
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Skill")
	TSoftObjectPtr<class UBSASkillAsset> SkillID = nullptr;

	// 是否为强制移除对应技能ID的ComboWindow
	UPROPERTY(EditDefaultsOnly, Category = "ForceRemove")
	bool bForceRemove = false;

	// 是否为改变对应技能ID的ComboWindow时间
	UPROPERTY(EditDefaultsOnly, Category = "ChangeTime", Meta = (EditCondition = "!bForceRemove", EditConditionHides))
	bool bChangeTime = true;

	// ComboWindow改变时间
	UPROPERTY(EditDefaultsOnly, Category = "ChangeTime", Meta = (EditCondition = "!bForceRemove && bChangeTime", EditConditionHides))
	float DeltaTime = 0.0f;

	// SkillID对应的ComboWindow不存在时，创建对应ComboWindow还是忽略
	UPROPERTY(EditDefaultsOnly, Category = "ChangeTime", Meta = (EditCondition = "!bForceRemove && bChangeTime && DeltaTime>0.0", EditConditionHides))
	bool bAllowCreateNew = true;
};

UCLASS(Abstract, Blueprintable)
class UBSATSetComboWindow : public UBSATask
{
	GENERATED_BODY()

public:
	// Combo设置项
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TArray<FBSAComboWindowMsg> ComboWindowSetters;

public:
	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (ComboWindowSetters.Num() == 0)
		{
			return true;
		}

		for (int i = 0; i < ComboWindowSetters.Num(); i++)
		{
			if (ComboWindowSetters[i].SkillID.IsNull())
			{
				return true;
			}
		}

		return false;
	}

#endif

};
#pragma endregion Ability






#pragma region DisableBehavior
UCLASS(Abstract, Blueprintable)
class UBSATDisableBehavior : public UBSATask
{
	GENERATED_BODY()

public:
	// 禁止主动移动
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bDisableMovement = true;

	// 禁止主动的动画驱动移动(例如走跑跳阶段)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bDisableLocoStartMovement = true;

	// 禁止主动旋转
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bDisableRotation = true;

	// 禁止跳跃
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bDisableJump = true;

	// 禁止部分技能类型的释放行为
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Meta = (Bitmask, BitmaskEnum = "/Script/KGBattleSystem.EBSASkillType"))
	int32 DisableSkillTypes = 7;

	// 为true时将DisableSkillTypes加入白名单，只要是DisableSkillTypes的技能均允许释放
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bSetSkillTypesWhiteList = false;

	// 禁止部分含有该标签的技能的释放行为
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FGameplayTagContainer DisableSkillTags;

	// 为true时将DisableSkillTags加入白名单，只要是DisableSkillTags的技能均允许释放
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bSetSkillTagsWhiteList = false;

	// Task结束时回滚
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bNeedReset = true;

public:
	// 批量更新配置数据时使用
	virtual bool UpdateEditorProperty()
	{
		/*if (!bDisableMovement && bDisableRotation && !bAllowThruster)
		{
			bDisableMovement = true;
			bAllowThruster = true;
			return true;
		}*/
		return false;
	}

};

#pragma endregion DisableBehavior






#pragma region Buff
UCLASS(Abstract, Blueprintable)
class UBSATAddBuff : public UBSATask
{
	GENERATED_BODY()

public:
	// 要添加的BUFF列表
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Buff")
	TArray<TSoftObjectPtr<class UBSABuffAsset>> BuffAssets;

	// 指定Buff的Trigger
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Buff")
	EBSASelectTarget TriggerType = EBSASelectTarget::ST_Owner;

	// 要添加的层数
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Buff")
	FBSATPP_Int32 AddLayer = 1;

	// 要添加的最大层数
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Buff")
	int32 MaxAddLayer = 10;

	// 覆盖生命时长(小于0无效)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Buff")
	FBSATPP_Float OverLife = -1.0f;



#if WITH_EDITORONLY_DATA
	// 当Task执行者仅为一个人 或 碰撞结果时，不再需要进行目标筛选
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Filter")
	bool bNeedFilterTarget = false;
#endif

	// 筛选添加该BUFF的目标
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Filter", Meta = (EditCondition = "bNeedFilterTarget"))
	FBSSelectTargetInfo BuffTargetInfo;

public:
	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty() override
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		if (BuffAssets.Num() == 0)
		{
			return true;
		}

		for (int i = 0; i < BuffAssets.Num(); i++)
		{
			if (BuffAssets[i].IsNull())
			{
				return true;
			}
		}

		return false;
	}

#endif

};






USTRUCT(BlueprintType)
struct FBSARemoveBuffInfo
{
	GENERATED_USTRUCT_BODY()

public:
	// 要删除的BUFF
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TSoftObjectPtr<class UBSABuffAsset> BuffAsset = nullptr;

	// 要删除的层数（0代表全部删除）
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FBSATPP_Float RemoveLayerNum = 1;

};

UCLASS(Abstract, Blueprintable)
class UBSATRemoveBuff : public UBSATask
{
	GENERATED_BODY()

public:
	// 是否使用驱散模式
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base")
	bool bUseDispel = false;

	// 移除模式
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Base")
	EBSABuffRemoveType RemoveType = EBSABuffRemoveType::BRT_RemoveLayer;



	// 是否检测当前BUFF层数大于等于移除层数
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Remove", Meta = (EditCondition = "!bUseDispel"))
	bool bCheckCurrentBuffLayer = false;

	// 选择始作俑者（默认不关心始作俑者）
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Remove", Meta = (EditCondition = "!bUseDispel"))
	EBSASelectTarget InstigatorType = EBSASelectTarget::ST_TMax;

	// 要移除的BUFF
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Remove", Meta = (EditCondition = "!bUseDispel"))
	TArray<FBSARemoveBuffInfo> RemoveBuffInfos;



	// 驱散等级数值类型(0技能等级，1公式，2固定值)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Dispel", Meta = (EditCondition = "bUseDispel"))
	int32 DispelType = 0;

	// 驱散等级(根据技能等级选取不同的驱散等级，如果技能等级大于该数组的数量，则使用最后一个数值)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Dispel", Meta = (EditCondition = "bUseDispel"))
	TArray<int32> DispelLevels = { 10 };

	// 是否反选
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Dispel", Meta = (EditCondition = "bUseDispel"))
	bool bReverse = false;

	// 想要驱散的BUFF（bReverse为true,则这些BUFF不被驱散）
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Dispel", Meta = (EditCondition = "bUseDispel"))
	TArray<TSoftObjectPtr<class UBSABuffAsset>> BuffList;

	// 想要驱散的BUFF标签（bReverse为true,则这些BUFF标签不被驱散）
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Dispel", Meta = (EditCondition = "bUseDispel"))
	FGameplayTagContainer BuffTags;



#if WITH_EDITORONLY_DATA
	// 当Task执行者仅为一个人 或 碰撞结果时，不再需要进行目标筛选
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Filter")
	bool bNeedFilterTarget = true;
#endif

	// 筛选要移除BUFF的目标
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Filter", Meta = (EditCondition = "bNeedFilterTarget"))
	FBSSelectTargetInfo BuffTargetInfo;



#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty() override
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		if (!bUseDispel)
		{
			if (RemoveBuffInfos.Num() == 0)
			{
				return true;
			}

			for (int i = 0; i < RemoveBuffInfos.Num(); i++)
			{
				if (RemoveBuffInfos[i].BuffAsset.IsNull())
				{
					return true;
				}
			}
		}

		return false;
	}

#endif
};






UCLASS(Abstract, Blueprintable)
class UBSATBuffAction : public UBSATask
{
	GENERATED_BODY()

public:
	// BUFF Action ID
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 BuffActionID = 1;

	// 重置时间刷新效果
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bRefreshWhenResetTime = false;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (UBSAAsset* Asset = Cast<UBSAAsset>(GetOuter()))
		{
			for (TObjectIterator<UBSEditorLuaGI> It; It; ++It)
			{
				if (UBSEditorLuaGI* GI = *It)
				{
					return !GI->CheckIsBuffActionValid(Asset->ID, BuffActionID);
				}
			}
		}

		return false;
	}

	virtual bool UpdateEditorProperty()
	{
		return false;
	}
#endif
};






UCLASS(Abstract, Blueprintable)
class UBSATChangeBuffTime : public UBSATask
{
	GENERATED_BODY()

public:
	// 想要修改的Buff
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TArray<TSoftObjectPtr<class UBSABuffAsset>> BuffAssets;

	// 根据始作俑者查询BUFF实例
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	EBSASelectTarget InstigatorType = EBSASelectTarget::ST_Owner;

	// 修改总生命时长还是当前生命时长
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bFixTotalLife = false;

	// 是增加数值还是覆盖数值
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bFixByDelta = true;

	// 修改的数值
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FBSATPP_Float FixedValue;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (BuffAssets.Num() == 0)
		{
			return true;
		}

		for (int i = 0; i < BuffAssets.Num(); i++)
		{
			if (BuffAssets[i].IsNull())
			{
				return true;
			}
		}

		return false;
	}

#endif
};






UCLASS(Abstract, Blueprintable)
class UBSATImmuneBuff : public UBSATask
{
	GENERATED_BODY()

public:
	// 是否全部免疫
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bImmuneAll = false;

	// 想要免疫的Buff
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Meta = (EditCondition = "!bImmuneAll", EditConditionHides))
	TArray<TSoftObjectPtr<class UBSABuffAsset>> BuffAssets;

	// 想要免疫的Buff标签
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Meta = (EditCondition = "!bImmuneAll", EditConditionHides))
	FGameplayTagContainer BuffTags;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (bImmuneAll)
		{
			return false;
		}

		if (BuffAssets.Num() == 0 && BuffTags.Num() == 0)
		{
			return true;
		}

		for (int i = 0; i < BuffAssets.Num(); i++)
		{
			if (BuffAssets[i].IsNull())
			{
				return true;
			}
		}

		return false;
	}

#endif
};






USTRUCT(BlueprintType)
struct FBSAChangeBuffMaxLayerInfo
{
	GENERATED_USTRUCT_BODY()

public:
	// 要修改的BUFF
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TSoftObjectPtr<class UBSABuffAsset> BuffID = nullptr;

	// 设置的最大层数
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FBSATPP_Float OverrideMaxLayer = 1;

};

UCLASS(Abstract, Blueprintable)
class UBSATChangeBuffMaxLayer : public UBSATask
{
	GENERATED_BODY()

public:
	// BuffOverrideMaxLayer修改条目
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TArray<FBSAChangeBuffMaxLayerInfo> ChangeBuffMaxLayerInfos;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (ChangeBuffMaxLayerInfos.Num() == 0)
		{
			return true;
		}

		for (int i = 0; i < ChangeBuffMaxLayerInfos.Num(); i++)
		{
			if (ChangeBuffMaxLayerInfos[i].BuffID.IsNull())
			{
				return true;
			}
		}

		return false;
	}

#endif

};

#pragma endregion Buff






#pragma region Suicide
UCLASS(Abstract, Blueprintable)
class UBSATSuicide : public UBSATask
{
	GENERATED_BODY()

public:

};

#pragma endregion Suicide






#pragma region Query
UCLASS(Abstract, Blueprintable)
class UBSATSelfUnitQuery : public UBSATask
{
	GENERATED_BODY()

public:
	// Unit类
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TSubclassOf<ABSUnit> UnitClass = nullptr;

	// 是否指定TempID
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	bool bUseTempID = false;

	// Unit类
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Meta = (EditCondition = "bUseTempID", EditConditionHides))
	int64 TempID = 0;

#if WITH_EDITOR
public:
	bool IsTaskInvalid_Implementation() override
	{
		if (UnitClass.Get() == nullptr)
		{
			return true;
		}

		return false;
	}

#endif
};

#pragma endregion Query






#pragma region ExpandState
UCLASS(Abstract, Blueprintable)
class UBSATChangeExpandState : public UBSATask
{
	GENERATED_BODY()

public:
	// 增加还是移除扩展状态（当Remove时，默认仅移除Manual记录）
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Default")
	bool bAddOrRemove = true;

	// 增加固定时间状态还是手动关闭状态
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Add", Meta = (EditCondition = "bAddOrRemove", EditConditionHides))
	bool bTimeFixOrManual = true;

	// 固定时间长度
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Add", Meta = (EditCondition = "bAddOrRemove && bTimeFixOrManual", EditConditionHides))
	float FixedTime = 2.0f;

	// 当已有该InInstigator的状态申请时，时间是叠加还是覆盖
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Add", Meta = (EditCondition = "bAddOrRemove && bTimeFixOrManual", EditConditionHides))
	bool bAddOrSetTime = true;

	// 是否强制移除该状态
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Remove", Meta = (EditCondition = "!bAddOrRemove", EditConditionHides))
	bool bForceRemove = true;

	// 指定扩展状态改变的施加者(默认自己)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Default")
	EBSASelectTarget InstigatorType = EBSASelectTarget::ST_Owner;
};

#pragma endregion ExpandState
