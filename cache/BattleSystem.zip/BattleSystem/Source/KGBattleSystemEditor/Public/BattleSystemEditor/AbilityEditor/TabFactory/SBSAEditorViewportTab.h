#pragma once

#include "CoreMinimal.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/SBSAEditorViewport.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorPreviewScene.h"



class SBSAEditorViewportTab : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SBSAEditorViewportTab) {}
	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, const TSharedRef<FBSAEditor>& InAssetEditorToolkit, const TSharedRef<FBSAEditorPreviewScene>& InPreviewScene, int32 InViewportIndex)
	{
		FEditorViewportParameter ViewportParameter(InPreviewScene, InAssetEditorToolkit, InViewportIndex);
		CachedViewport = SNew(SBSAEditorViewport, ViewportParameter);

		TSharedPtr<FEditorViewportClient> ViewportClient = CachedViewport->GetViewportClient();
		ViewportClient->SetRealtime(true);

		InAssetEditorToolkit->SetViewport(CachedViewport);

		this->ChildSlot
		[
			SNew(SVerticalBox)
			+SVerticalBox::Slot()
			.FillHeight(1)
			[
				CachedViewport.ToSharedRef()
			]
		];
	}

private:
	TSharedPtr<SBSAEditorViewport> CachedViewport = nullptr;

};