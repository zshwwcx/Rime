#pragma once

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"

#include "BattleSystem/Ability/BSAEnums.h"
#include "BattleSystem/Ability/BSAStructs.h"

#include "BSASkillAsset.generated.h"



USTRUCT(BlueprintType)
struct FBSASkillConsume
{
	GENERATED_USTRUCT_BODY()

public:
	// 属性名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FGameplayTag AttributeName;

	// 使用比例值还是固定值
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bUseProportion = false;

	// 数值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "!bUseProportion", EditConditionHides))
	float Value = 0.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "bUseProportion", EditConditionHides))
	FAttributeCalculator Calculator;

	// 是否作为释放条件
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bIsActivateCondition = true;

};



UCLASS(Blueprintable)
class KGBATTLESYSTEMEDITOR_API UBSASkillAsset : public UBSAAsset
{
	GENERATED_BODY()

public:
	UBSASkillAsset(const FObjectInitializer& ObjectInitializer);



#pragma region Important
public:
	// 技能时长(被动技能的生命周期为无限)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Important", Meta = (ClampMin = "0.5"))
	float SkillDuration = 1.0f;

	// 是否需要网络同步
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Important")
	bool bNeedReplicated = true;

	// 技能类型
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Important")
	EBSASkillType SkillType = EBSASkillType::ST_Battle;

	// 技能标签
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Important")
	FGameplayTagContainer SkillGameplayTag;

#pragma endregion Important



#pragma region Condition
public:
	// 检查当前的移动模式
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Condition", Meta = (Bitmask, BitmaskEnum = "/Script/Engine.EMovementMode"))
	int32 MovementMode = 6;

	// 检查自定义条件
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Instanced, Category = "Condition")
	TArray<class UBSACondition*> ActivateConditions;

#pragma endregion Condition



#pragma region Extra
public:
	// 吟唱时间(CD触发时机为技能结束后触发（循环技能）时，表示取消技能的冷却时间)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Extra", Meta = (ClampMin = "0.0"))
	float ChantDuration = 0.4f;

	// 技能连段时间窗口(X代表开始时间，Y代表持续时间，Y为0代表无连段需求)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Extra")
	FVector2D ComboWindow = FVector2D::ZeroVector;

	// 技能后摇开始时间（小于等于0无效）
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Extra", Meta = (ClampMin = "0.0"))
	float SkillRecoveryStartTime = 0.0f;
	
	private:
	int32 RedoIndex = -1;
#pragma endregion Extra



#pragma region API
#if WITH_EDITOR
public:
	void InitByEditor(UObject* WorldContext) override;

	void PreEditChange(FProperty* PropertyThatWillChange) override;

	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	void ChangeSectionName(int32 SectionID, FName NewName) override;

	void ChangeSectionLoopTime(int32 SectionID, int32 NewLoop) override;

	void ChangeSectionDuration(int32 SectionID, float NewDuration) override;

	void ChangeChantDuration(float NewDuration);

	void ChangeComboWindowStart(float NewStart);

	void ChangeComboWindowDuration(float NewDuration);

	virtual void PreSave(FObjectPreSaveContext SaveContext) override;
#endif
#pragma endregion API

};

