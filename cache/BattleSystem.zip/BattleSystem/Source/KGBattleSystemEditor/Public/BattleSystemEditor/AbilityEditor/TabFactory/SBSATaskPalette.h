#pragma once

#include "CoreMinimal.h"
#include "Widgets/SWidget.h"
#include "SGraphPalette.h"
#include "GraphEditAction.h"


class SBSATaskPaletteItem : public SGraphPaletteItem
{
public:
	SLATE_BEGIN_ARGS(SBSATaskPaletteItem) {};
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, FCreateWidgetForActionData* const InCreateData);

private:
	virtual FText GetItemTooltip() const override;

};



class SBSATaskPalette : public SGraphPalette
{
public:
	SLATE_BEGIN_ARGS(SBSATaskPalette) {}
	SLATE_END_ARGS()

	virtual	~SBSATaskPalette();

	void Construct(const FArguments& InArgs, const TSharedRef<class FBSAEditor>& InAssetEditorToolkit);
	
private:
	// 创建调色板中的条目
	TSharedRef<SWidget> OnCreateWidgetForAction(FCreateWidgetForActionData* const InCreateData) override;

	// 搜集所有的编辑行为
	void CollectAllActions(FGraphActionListBuilderBase& OutAllActions) override;

	// 逻辑图表发生改变时的回调
	void OnLogicGraphChanged(const FEdGraphEditAction& InAction);

private:
	TWeakPtr<class FBSAEditor> CachedEditor;

	FDelegateHandle GraphChangedHandle;

};