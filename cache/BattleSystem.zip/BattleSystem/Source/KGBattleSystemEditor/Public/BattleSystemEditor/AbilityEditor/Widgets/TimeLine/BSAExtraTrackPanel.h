#pragma once

#include "KGCoreEditor/Public/Widgets/TimeLineBase/AnimTimelineTrack.h"



class FBSAExtraTrackPanel : public FAnimTimelineTrack
{
	ANIMTIMELINE_DECLARE_TRACK(FBSAExtraTrackPanel, FAnimTimelineTrack);

public:
	static float NotificationTrackHeight;

	FBSAExtraTrackPanel(const TSharedRef<class FBSATimelineController>& InController, class UBSAAsset* InAsset, int32 InTrackType, const FText& InDisplayName, const FText& InToolTipText);

	void UpdateLayout();

	// 绘制Task时间轨道
	TSharedRef<SWidget> GenerateContainerWidgetForTimeline() override;

private:
	void InputViewRangeChanged(float ViewMin, float ViewMax);

private:
	TWeakObjectPtr<class UBSAAsset> CachedAsset = nullptr;

	int32 TrackType = 0;

	TSharedPtr<class SBSAExtraTrackTimeline> TrackWidget = nullptr;
	
};