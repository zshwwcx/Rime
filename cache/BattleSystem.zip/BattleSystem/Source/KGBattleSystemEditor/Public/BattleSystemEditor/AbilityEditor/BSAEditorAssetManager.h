#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSABuffAsset.h"
#include "BattleSystemEditor/BSEditorStructs.h"

#include "BSAEditorAssetManager.generated.h"



UCLASS(Blueprintable, BlueprintType)
class UBSAEditorAssetManager : public UObject
{
	GENERATED_BODY()

public:
	void Init();

	void UnInit();

	static UBSAEditorAssetManager* GetInstance();

public:
	// 捕获所有资源的路径
	void FindAllAbilityPath();

	// 获取技能资源的引用资源列表
	TArray<TSoftObjectPtr<UObject>> GetBSAAssetResources(UBSAAsset* TheAsset);



	// 获取所有的技能ID
	TArray<int32> GetSkillIDList();

	// 根据ID获取技能资源
	UBSASkillAsset* GetSkillAssetByID(int32 ID);

	// 根据ID获取技能软指针
	TSoftObjectPtr<UBSASkillAsset>GetSkillAssetSoftObjectByID(int32 ID);



	// 获取所有的BuffID
	TArray<int32> GetBuffIDList();

	// 根据ID获取Buff资源
	UBSABuffAsset* GetBuffAssetByID(int32 ID);

	// 根据ID获取Buff软指针
	TSoftObjectPtr<UBSABuffAsset>GetBuffAssetSoftObjectByID(int32 ID);

public:
	// 使用过的Guid列表
	TArray<int64> UsedGuidList;

	// 检查过的Task+PropName - GID列表
	TMap<FString, int64> UsedGuidNameList;

private:
	bool bActive = false;

	// 技能资源路径查询表
	UPROPERTY(Transient)
	TMap<int32, TSoftObjectPtr<class UBSASkillAsset>> SkillPathMap;

	// Buff资源路径查询表
	UPROPERTY(Transient)
	TMap<int32, TSoftObjectPtr<class UBSABuffAsset>> BuffPathMap;

};
