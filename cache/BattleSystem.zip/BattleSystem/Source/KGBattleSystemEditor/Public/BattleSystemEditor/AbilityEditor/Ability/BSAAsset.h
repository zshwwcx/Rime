#pragma once

#include "UObject/Object.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"
#include "UObject/ObjectSaveContext.h"

#include "Engine/DataAsset.h"

#include "BattleSystem/Ability/BSAStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSAAsset.generated.h"



#define LOCTEXT_NAMESPACE "BSAAsset"



USTRUCT()
struct FBSATaskTemplateInfo
{
	GENERATED_USTRUCT_BODY()

public:
	FBSATaskTemplateInfo() : Name(NAME_None) {}
	FBSATaskTemplateInfo(FName GrroupName) : Name(GrroupName) {}

public:
	UPROPERTY(EditAnywhere)
	FName Name = NAME_None;

	UPROPERTY(EditAnywhere)
	TArray<UBSATask*> TaskList;
};

USTRUCT()
struct FBSATaskGroup
{
	GENERATED_USTRUCT_BODY()

public:
	FBSATaskGroup() : Name(NAME_None) {}
	FBSATaskGroup(FName GrroupName) : Name(GrroupName) {}

public:
	UPROPERTY()
	FName Name = NAME_None;

	UPROPERTY()
	TArray<TWeakObjectPtr<UBSATask>> TaskList;
};

USTRUCT()
struct FBSATaskSection
{
	GENERATED_USTRUCT_BODY()

public:
	FBSATaskSection()
	{
#if WITH_EDITORONLY_DATA
		TaskGroups.Add(FBSATaskGroup(TEXT("Group:0")));
#endif
	}
	FBSATaskSection(FName SectionName)
	{
#if WITH_EDITORONLY_DATA
		Name = SectionName;
		TaskGroups.Add(FBSATaskGroup(TEXT("Group:0")));
#endif
	}

public:
	// 循环次数(小于等于0代表无限循环)
	UPROPERTY(EditDefaultsOnly)
	int32 LoopTime = 1;

	// 持续时间
	UPROPERTY(EditDefaultsOnly, Meta = (ClampMin = "0.52"))
	float SectionDuration = 1.0f;

	// Task列表
	UPROPERTY(EditDefaultsOnly, Instanced)
	TArray<UBSATask*> TaskList;

	// 索引
	UPROPERTY()
	int32 Index = 0;

	// 客户端关键帧
	UPROPERTY()
	TArray<FBSAKeyframe> ClientKeyframeList;

	// 服务器关键帧
	UPROPERTY()
	TArray<FBSAKeyframe> ServerKeyframeList;

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditDefaultsOnly)
	FName Name = NAME_None;

	UPROPERTY()
	TArray<FBSATaskGroup> TaskGroups;

#endif

};



USTRUCT()
struct FBSASocketRelation
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY()
	TArray<float> Times;

	UPROPERTY()
	TArray<FTransform> Relations;

};

UCLASS(Abstract, Blueprintable, EditInlineNew)
class UBSAAssetExpandData : public UObject
{
	GENERATED_BODY()

public:
	// 缓存服务器所需要的模型Socket相对位置信息
	UPROPERTY()
	TMap<FName, FBSASocketRelation> SocketRelations;

public:
	UFUNCTION(BlueprintImplementableEvent)
	bool UpdateEditorProperty();

	UFUNCTION(BlueprintImplementableEvent)
	bool UpdateExpandDataAfterPropertyChanged(UBSAAsset* Asset, FName PropertyName);

};



UCLASS(Blueprintable)
class KGBATTLESYSTEMEDITOR_API UBSAAsset : public UPrimaryDataAsset
{
	GENERATED_BODY()

	friend class UBSEditorFunctionLibrary;

#pragma region API
public:
	// 获取引用资源列表
	virtual void GetReferenceResources(TArray<FString>& InOutList);

	FBSATaskSection* GetSectionPointerByIndex(int32 Index);

	// 根据Task返回SectionID
	FBSATaskSection* GetSectionPointerByTask(UBSATaskBase* InTask);

	// 根据Task返回一个查询ID
	int32 GetSearchIDByTask(UBSATaskBase* InTask);

	// 根据查询ID返回Task指针
	UBSATaskBase* GetTaskBySearchID(int32 InSearchID);

	// 返回所有的Task
	UFUNCTION(BlueprintCallable)
	TArray<UBSATask*> GetTasks();

#if WITH_EDITOR
public:
	virtual void PreEditChange(FProperty* PropertyThatWillChange) override {}

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;

	// 通过编辑器打开的初始化
	virtual void InitByEditor(UObject* WorldContext);

	// 资源保存前的预处理
	virtual void PreSave(FObjectPreSaveContext SaveContext) override;

	// 查询Task所在的SectionID和GroupID
	void GetSectionIDAndGroupID(UBSATask& Task, int32& OutSectionID, int32& OutGroupID);

	// 添加Task
	virtual bool AddTask(int32 SectionID, int32 GroupID, UBSATask& Task);

	// 删除Task
	virtual bool RemoveTask(int32 SectionID, int32 GroupID, UBSATask& Task);
	virtual bool RemoveTask(UBSATask& Task);

	// 添加Group
	virtual bool AddGroup(int32 SectionID, FName NewGroupName);

	// 删除Group
	virtual bool RemoveGroup(int32 SectionID, int32 GroupID);

	// 获取Section数量
	int32 GetSectionNum();

	// 清除所有的Section
	void ClearAllSection();

	// 添加空Section
	virtual bool AddSection(FName NewSectionName = NAME_None);

	// 添加Section
	virtual bool AddSection(const FBSATaskSection& InNewSection);

	// 删除Section
	virtual bool RemoveSection(int32 SectionID);

	// 修改Section名称
	virtual void ChangeSectionName(int32 SectionID, FName NewName);

	// 修改Section循环次数
	virtual void ChangeSectionLoopTime(int32 SectionID, int32 NewLoop);

	// 修改Section时长
	virtual void ChangeSectionDuration(int32 SectionID, float NewDuration);

	// 更新时间轴的关键帧信息
	virtual void UpdateKeyframeList();
#endif
#pragma endregion API



#pragma region CommonProperty
public:
	int32 CreateNewUniqueID()
	{
		return ++UniqueIDCreater;
	}

public:
	// 资源ID
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Important")
	int32 ID;

	// 资源扩展数据
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Instanced, Category = "Important")
	UBSAAssetExpandData* ExpandData = nullptr;

#if WITH_EDITORONLY_DATA
	// 逻辑图
	UPROPERTY()
	class UEdGraph* LogicGraph = NULL;

	UPROPERTY()
	bool bHasInit = false;

	// 唯一ID生成器
	UPROPERTY()
	uint16 UniqueIDCreater = 0;
#endif

protected:
	// Task列表组
	UPROPERTY(EditDefaultsOnly)
	TArray<FBSATaskSection> Sections;

#pragma endregion CommonProperty



#pragma region EditorProperty
#if WITH_EDITORONLY_DATA
public:
	// 名称
	UPROPERTY(EditDefaultsOnly, Category = "Common")
	FText Name;

	// 说明
	UPROPERTY(EditDefaultsOnly, Category = "Common")
	FText Tips;

	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Preview")
	class UBSAPreviewActor* PreviewPlayerInfo = nullptr;

	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Preview")
	class UBSAPreviewActor* PreviewTargetInfo = nullptr;

	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Preview")
	class UBSAPreviewActor* PreviewWaterFieldInfo = nullptr;

	UPROPERTY(EditDefaultsOnly, Instanced, Category = "Preview")
	class UBSAPreviewActor* PreviewGrassFieldInfo = nullptr;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Environment")
	bool bOpenWaterField = true;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Environment")
	bool bOpenWindField = true;

	UPROPERTY()
	int32 ConfigProblemNumber = 0;
#endif
#pragma endregion EditorProperty



#pragma region AutoOptimize
#if WITH_EDITOR
public:
	// 自动优化配置
	void AutoOptimizeTask();

protected:
	// 检查Task是否配置了有效数据
	void CheckTaskInvalid(bool bOnlyCheck);

	// 检查Task的NetType
	void CheckTaskNetType(bool bOnlyCheck);

	// 检查Task的重复触发
	void CheckTaskRedundantTrigger(bool bOnlyCheck);

	// 检查Task的无法触发
	void CheckTaskNonTrigger(bool bOnlyCheck);

	// 检查事件监听的子Task生命周期
	void CheckEventListenerLifeType(bool bOnlyCheck);

	// 检查Buff的可叠加轨道
	void CheckBuffStackableSection(bool bOnlyCheck);

	// 检查Buff的全局轨道
	void CheckBuffGlobalSection(bool bOnlyCheck);

	// 检查Animation配置数量是否合理
	void CheckSectionAnimationNum(bool bOnlyCheck);
	
	// 检查Niagara总数是否合理
	void CheckNiagaraTotalNumber(bool bOnlyCheck);

	// 检查Niagara密度是否合理
	void CheckNiagaraDensity(bool bOnlyCheck);

	// 检查AkEvent的AudioAsset是否正确配置
	void CheckAudioAsset(bool bOnlyCheck);

#endif
#pragma endregion AutoOptimize



#pragma region Statistics
public:	
	// 统计特效数量需求,并对特效密度和数量进行自动调整
	void UpdateNiagaraNumber();

public:
	// 技能/Buff的特效数量需求
	UPROPERTY(VisibleAnywhere, Category = "Statistics")
	int32 AssetNiagaraNum = 0;

#pragma endregion Statistics

};

#undef LOCTEXT_NAMESPACE
