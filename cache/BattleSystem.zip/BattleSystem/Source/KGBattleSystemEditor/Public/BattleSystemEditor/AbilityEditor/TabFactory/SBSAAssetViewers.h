#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "SSingleObjectDetailsPanel.h"



class SBSAAssetPropertyTabBody : public SSingleObjectDetailsPanel
{
public:
	SLATE_BEGIN_ARGS(SBSAAssetPropertyTabBody) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, TSharedPtr<class FBSAEditor> InEditor);

	virtual UObject* GetObjectToObserve() const override;

	virtual TSharedRef<class SWidget> PopulateSlot(TSharedRef<class SWidget> PropertyEditorWidget) override;

	virtual FText GetAssetDisplayName() const;

	virtual EVisibility GetAssetDisplayNameVisibility() const;

private:
	TWeakPtr<class FBSAEditor> CachedEditor = nullptr;

};



class SBSAEditorSettingsTabBody : public SSingleObjectDetailsPanel
{
public:
	SLATE_BEGIN_ARGS(SBSAEditorSettingsTabBody) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, TSharedPtr<class FBSAEditor> InEditor);

	virtual UObject* GetObjectToObserve() const override;

	virtual TSharedRef<class SWidget> PopulateSlot(TSharedRef<class SWidget> PropertyEditorWidget) override;

	virtual FText GetAssetDisplayName() const;

	virtual EVisibility GetAssetDisplayNameVisibility() const;

private:
	TWeakPtr<class FBSAEditor> CachedEditor = nullptr;

};