#pragma once

#include "CoreMinimal.h"
#include "BattleSystemEditor/AbilityEditor/Preview/BSAPreviewActor.h"
#include "Engine/DeveloperSettings.h"
#include "Engine/DataTable.h"
#include "BSAEditorSettings.generated.h"



USTRUCT(BlueprintType)
struct FBSAEditorExportReplace
{
	GENERATED_USTRUCT_BODY()

public:
	// 原始子串
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Origin;

	// 替换字串
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Replace;

};



UCLASS(Config = Editor, DefaultConfig, meta = (DisplayName = "BSA Editor Settings"))
class KGBATTLESYSTEMEDITOR_API UBSAEditorSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UBSAEditorSettings(const FObjectInitializer& ObjectInitializer);

public:
	UPROPERTY(Config, EditDefaultsOnly, Category = "Important")
	TSubclassOf<class ABSAPreviewGameMode> GameModeClass = nullptr;

	UPROPERTY(Config, EditDefaultsOnly, Category = "Important")
	TSubclassOf<class UBSAAssetExpandData> SkillExpandData = nullptr;

	UPROPERTY(Config, EditDefaultsOnly, Category = "Important")
	TSubclassOf<class UBSAAssetExpandData> BuffExpandData = nullptr;

	UPROPERTY(Config, EditDefaultsOnly, Category = "Important")
	TSoftObjectPtr<class UBSATaskTemplate> TaskTemplate = nullptr;



	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene")
	TSoftObjectPtr<UWorld> DefaultViewMap;

	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene", meta = (Tooltip = "Player type for ability preview"))
	TSubclassOf<UBSAPreviewActor> PlayerType = UBSAPreviewActor::StaticClass();

	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene", meta = (Tooltip = "Target type for ability preview"))
	TSubclassOf<UBSAPreviewActor> TargetType = UBSAPreviewActor::StaticClass();
	
	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene", meta = (Tooltip = "Water Field type for ability preview"))
	TSubclassOf<UBSAPreviewActor> WaterFieldType = UBSAPreviewActor::StaticClass();

	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene", meta = (Tooltip = "Grass Field type for wind ability preview"))
	TSubclassOf<UBSAPreviewActor> GrassFieldType = UBSAPreviewActor::StaticClass();



	// 技能资源导出文件路径
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	FString SkillJsonPath;

	// BUFF资源导出文件路径
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	FString BuffJsonPath;

	// 中文字符文件路径
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	FString ChineseDBPath;

	// 属性标签文件路径
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	FString PropTagPath;

	// 属性标签文件路径
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	FString PropModeTagPath;

	// 要导出的曲线目录
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	TArray<FString> ExportCurvePaths;
	// 导出枚举的目录
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	TArray<FString> ExportEnumPaths;
	// 导出成枚举的基类
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	TArray<TSubclassOf<UObject>> ExportEnumClasses;
	// 导出成枚举的基类路径
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	TArray<FString> ExportEnumClassPaths;
	// 导出成枚举的基类映射表
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	TSoftObjectPtr<UDataTable> ExportEnumClassTable = nullptr;
	// 客户端类映射文件
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	FString ClientClassTypeToClassPath;
	// 导出客户端Lua逻辑代码的路径字段替换
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	TArray<FBSAEditorExportReplace> ExportClientLuaCodeReplacePath;
	// 服务器类映射文件
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	FString ServerClassTypeToClassPath;
	// 导出服务器Lua逻辑代码的路径字段替换
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Export")
	TArray<FBSAEditorExportReplace> ExportServerLuaCodeReplacePath;



	// 角色类型枚举补充
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Enum")
	TSoftObjectPtr<class UStringTable> CharacterTypeNameTable = nullptr;

	// 阵营关系枚举补充
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Enum")
	TSoftObjectPtr<class UStringTable> CampTypeNameTable = nullptr;

	// 技能类型枚举补充
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Enum")
	TSoftObjectPtr<class UStringTable> SkillTypeNameTable = nullptr;

	// 攻击类型枚举补充
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Enum")
	TSoftObjectPtr<class UStringTable> AttackTypeNameTable = nullptr;

	// 受击反馈类型枚举补充
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Enum")
	TSoftObjectPtr<class UStringTable> HitFeedbackTypeNameTable = nullptr;

	// 硬直状态枚举补充
	UPROPERTY(Config, EditDefaultsOnly, BlueprintReadOnly, Category = "Enum")
	TSoftObjectPtr<class UStringTable> StaggerNameTable = nullptr;



#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

};