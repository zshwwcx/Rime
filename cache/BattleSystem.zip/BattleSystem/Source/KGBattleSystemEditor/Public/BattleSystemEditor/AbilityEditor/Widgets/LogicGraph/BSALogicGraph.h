#pragma once

#include "CoreMinimal.h"
#include "EdGraph/EdGraph.h"

#include "BSALogicGraph.generated.h"



UCLASS()
class UBSALogicGraph : public UEdGraph
{
	GENERATED_BODY()

public:
	UBSALogicGraph();

	virtual ~UBSALogicGraph();

	void RefreshLogicGraph();

	// 尝试根据Task信息连接将Node1的pin连接上Node2
	void TryAutoConnectPin(class UBSALogicGraphNode* Node1, class UBSALogicGraphNode* Node2);

};
