#pragma once

#include "Widgets/TimeLineBase/AnimTimelineTrack.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"



class FBSATimelineTrackGroup : public FAnimTimelineTrack
{
	ANIMTIMELINE_DECLARE_TRACK(FBSATimelineTrackGroup, FAnimTimelineTrack);

public:
	FBSATimelineTrackGroup(const TSharedRef<class FBSATimelineController>& InModel, FBSATaskGroup* InGroupData, const FText& InDisplayName, const FText& InToolTipText);

	// 绘制Group轨道左边的大纲
	TSharedRef<class SWidget> GenerateContainerWidgetForOutliner(const TSharedRef<SAnimOutlinerItem>& InRow) override;

	bool CanRename() const override { return true; }

	FText GetLabel() const override;

	void OnCommitCurveName(const FText& InText, ETextCommit::Type CommitInfo);

	void AddTaskTemplate(FName TemplateName);

private:
	TSharedRef<class SWidget> BuildGroupSubMenu();

	void AddNewTask(UClass* InTaskClass);

	void PasteTasks();

	void AddTaskGroup();

	void DeleteTaskGroup();

	void FillNewTaskMenu(class FMenuBuilder& MenuBuilder);

	void FillNewTaskTemplateMenu(class FMenuBuilder& MenuBuilder);

private:
	FBSATaskGroup* GroupData;

};