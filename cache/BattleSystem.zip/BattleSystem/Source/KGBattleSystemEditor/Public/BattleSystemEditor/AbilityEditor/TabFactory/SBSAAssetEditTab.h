#pragma once

#include "CoreMinimal.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/SBSAEditorViewport.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorPreviewScene.h"



class SBSAAssetEditTab;
class SBSAAssetEditSection : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SBSAAssetEditSection) {};
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, const TSharedPtr<FBSAEditor>& InAssetEditorToolkit, const TSharedPtr<SBSAAssetEditTab>& AssetEditWidget, int32 InSectionIndex);

private:
	void ChangeSectionName(const FText& InText, ETextCommit::Type CommitInfo);

	void ChangeSectionLoopTime(const FText& InText, ETextCommit::Type CommitInfo);

	void ChangeSectionDuration(const FText& InText, ETextCommit::Type CommitInfo);

	TSharedRef<SWidget> BuildSectionSubMenu();

	void AddSection();

	void DeleteSection();

	FText GetSectionName() const;

	FText GetSectionLoopTime() const;

	FText GetSectionDuration() const;
	 
public:
	TWeakPtr<FBSAEditor> CachedEditor = nullptr;

	TWeakPtr<SBSAAssetEditTab> CachedEditTab = nullptr;

	TSharedPtr<class SAnimTimeline> TimelineWidget = nullptr;

	TSharedPtr<class FBSATimelineController> TimelineController = nullptr;

};



class SBSAAssetEditTab : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SBSAAssetEditTab) {};
	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, const TSharedPtr<FBSAEditor>& InAssetEditorToolkit);

	void Update();

	FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	FReply OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

private:
	TWeakPtr<FBSAEditor> CachedEditor = nullptr;

	TArray<TSharedPtr<class SBSAAssetEditSection>> SectionWidgets;

	TSharedPtr<SBorder> BorderWidgetArea = nullptr;

};