#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "GameFramework/Actor.h"
#include "BSAPreviewActor.generated.h"



UCLASS(Blueprintable, EditInlineNew)
class UBSAPreviewActor : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<AActor> ActorClass = nullptr;

	UPROPERTY(EditDefaultsOnly)
	FTransform SpawnTransform = FTransform::Identity;

public:
	UFUNCTION(BlueprintNativeEvent)
	AActor* CreateActor(class UWorld* InWorld);
	virtual AActor* CreateActor_Implementation(class UWorld* InWorld);

};

