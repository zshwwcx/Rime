#pragma once

#include "ThumbnailRendering/DefaultSizedThumbnailRenderer.h"

#include "BSAAssetThumbnailRenderer.generated.h"



UCLASS()
class KGBATTLESYSTEMEDITOR_API UBSAAssetThumbnailRenderer : public UDefaultSizedThumbnailRenderer
{
	GENERATED_UCLASS_BODY()

public:
	UBSAAssetThumbnailRenderer();

	virtual void Draw(UObject* Object, int32 X, int32 Y, uint32 Width, uint32 Height, FRenderTarget* RenderTarget, FCanvas* Canvas, bool bAdditionalViewFamily) override;

private:
	UPROPERTY()
	class UTexture2D* m_NoImage = NULL;

	UPROPERTY()
	class UFont* NameFont = NULL;

	UPROPERTY()
	class UFont* TipFont = NULL;
};

