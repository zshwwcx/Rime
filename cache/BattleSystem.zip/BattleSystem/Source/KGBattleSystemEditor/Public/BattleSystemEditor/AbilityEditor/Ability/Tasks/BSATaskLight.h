#pragma once

#include "Engine/PointLight.h"

#include "BSATask.h"

#include "BSATaskLight.generated.h"



#pragma region PointLight
UCLASS(Abstract, Blueprintable)
class UBSATAddPointLight : public UBSATask
{
	GENERATED_BODY()

public:
	// 生命周期
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	float LightLife = 1.0f;

	// 生成间隔时间(单位秒)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	float SpawnFrequency = 100.0f;

	// Task结束时强行关闭点光源
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	bool ForceCloseLightWhenTaskEnd = false;



	// 光源强度模式
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Light")
	ELightUnits Units;

	// 光源强度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Light")
	FKGRemapFloatCurve Brightness;

	// 光源范围
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Light")
	FKGRemapFloatCurve Radius;

	// 光源颜色
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Light")
	FKGRemapColorCurve Color;

	// 点光源镜面反射系数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Light")
	float PointLightSpecularScale = 0.0f;

	// 光源衰减模式
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Light")
	bool bEnableInverseSquaredFalloff = false;

	// 点光源衰减指数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Light", Meta = (ClampMin = 0.01f))
	float PointLightFallOffExponent = 2.0f;



	// 是否进行绑定
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform")
	bool bNeedAttach = false;

	// 绑定模式下的骨骼名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSSocketSelector AttachSocket;

	// 绑定模式下的坐标偏移矩阵
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSATPP_Transform AttachTransform;

	// 坐标计算信息
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "!bNeedAttach"))
	FBSATransformCreater CoordinateCreater;
};

#pragma endregion PointLight
