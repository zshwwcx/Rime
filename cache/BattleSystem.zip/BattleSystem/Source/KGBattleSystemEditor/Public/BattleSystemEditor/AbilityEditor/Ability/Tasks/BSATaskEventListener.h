#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "BattleSystem/Ability/BSACondition.h"

#include "BSATaskEventListener.generated.h"



UCLASS(Abstract, Blueprintable)
class UBSATEventListener : public UBSATask
{
	GENERATED_BODY()

public:
	UBSATEventListener();

public:
	// 事件触发概率
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Meta = (ClampMin = 0.0f, ClampMax = 1.0f))
	float Probability = 1.0f;

	// 事件触发冷却(默认大于0.2s，需要更高频率提前与程序沟通)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	float CoolDown = 0.2f;

	// 允许触发的检查条件
	UPROPERTY(EditDefaultsOnly, Instanced)
	TArray<UBSACondition*> AllowTriggerConditions;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	
	virtual bool UpdateEditorProperty() override
	{
		/*if (CoolDown < 0.2f)
		{
			return true;
		}*/

		return false;
	}
#endif

};



UCLASS(Abstract, Blueprintable)
class UBSATListenPreAttackEvent : public UBSATEventListener
{
	GENERATED_BODY()

public:
	// DamageCoefficient的Attcker判断条件
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Instanced, Category = "Action")
	TArray<UBSACondition*> DamageCoefficientAttackerConditions;

	// DamageCoefficient的Defender判断条件
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Instanced, Category = "Action")
	TArray<UBSACondition*> DamageCoefficientDefenderConditions;

	// DamageCoefficient
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Action")
	float DamageCoefficient = 1.0f;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

#endif
};
