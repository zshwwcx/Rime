#pragma once

#include "Factories/Factory.h"

#include "BSAAssetFactory.generated.h"



UCLASS(HideCategories = Object, MinimalAPI)
class UBSASkillAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UBSASkillAssetFactory(const FObjectInitializer& ObjectInitializer);

	virtual ~UBSASkillAssetFactory() {}

	virtual bool ConfigureProperties() override { return true; }

	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;
	
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;

};






UCLASS(HideCategories = Object, MinimalAPI)
class UBSABuffAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UBSABuffAssetFactory(const FObjectInitializer& ObjectInitializer);

	virtual ~UBSABuffAssetFactory() {}

	virtual bool ConfigureProperties() override { return true; }

	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;

	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;

};






UCLASS(HideCategories = Object, MinimalAPI)
class UBSATaskTemplateAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UBSATaskTemplateAssetFactory(const FObjectInitializer& ObjectInitializer);

	virtual ~UBSATaskTemplateAssetFactory() {}

	virtual bool ConfigureProperties() override { return true; }

	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;

	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;

};
