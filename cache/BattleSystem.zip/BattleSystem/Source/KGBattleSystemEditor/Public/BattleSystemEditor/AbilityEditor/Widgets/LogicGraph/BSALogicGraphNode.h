#pragma once

#include "CoreMinimal.h"
#include "EdGraph/EdGraphNode.h"
#include "GameplayTagContainer.h"
#include "EdGraph/EdGraphPin.h"

#include "BattleSystem/BSEnums.h"

#include "BSALogicGraphNode.generated.h"



USTRUCT(BlueprintType)
struct FBSALGNodePin
{
	GENERATED_USTRUCT_BODY()

public:
	// 信息类型
	/*
	* 0:Task执行
	* 1:Task事件
	* 2:Task碰撞输入
 	* 3:Task输入数据
	* 4:Task输出数据
	*/
	UPROPERTY()
	uint8 PinType = 0;

	UPROPERTY()
	int32 DataRandID = 0;

	UPROPERTY()
	FName ExtraName;

	UPROPERTY()
	FName PinGUIDName;

public:
	bool operator == (const FBSALGNodePin& Info) const
	{
		return PinType == Info.PinType && DataRandID == Info.DataRandID && ExtraName.IsEqual(Info.ExtraName);
	}

};



UCLASS(MinimalAPI)
class UBSALogicGraphNode : public UEdGraphNode
{
	GENERATED_BODY()

#pragma region Important
public:
	UBSALogicGraphNode();

	virtual ~UBSALogicGraphNode();

	void PreSave(class FObjectPreSaveContext ObjectSaveContext) override;

public:
	UPROPERTY()
	class UBSATask* CachedTask = nullptr;

	class SBSALogicGraphNode* NodeWidget = nullptr;

#pragma endregion Important



#pragma region Pin
public:
	// 创建节点的Pin脚
	void AllocateDefaultPins() override;

	// 刷新Pin信息
	void UpdatePins();

	// 获取Pin的颜色
	FLinearColor GetPinColor(const UEdGraphPin* InPin);

	// 获取Pin的信息
	FBSALGNodePin* GetPinInformation(const UEdGraphPin* InPin);

	// 获取Pin的数据类型
	void GetPinDataType(const UEdGraphPin* InPin, EBSDataType& OutType, UScriptStruct*& OutStructType);

private:
	FName GetPinNameFromTagName(const FName& InTag);

	// 刷新Pin信息列表
	void RefreshPinInformationList(TArray<FBSALGNodePin>& InPinInformationList);

	// 根据GUID获取Pin对象
	UEdGraphPin* GetPinByGUID(FGuid InGuid);

	// 根据ExtraName获取Pin对象
	UEdGraphPin* GetPinByName(FName InExtraName);

	// 根据Pin信息创建Pin
	void CreatePinByInformation(FBSALGNodePin& InInformation);

private:
	UPROPERTY()
	TArray<FBSALGNodePin> PinInformations;

	friend class UBSALogicGraph;

#pragma endregion Pin



#pragma region Property
public:
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;

#pragma endregion Property



#pragma region Edit
public:
	virtual void PrepareForCopying() override;

	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

#pragma endregion Edit

};
