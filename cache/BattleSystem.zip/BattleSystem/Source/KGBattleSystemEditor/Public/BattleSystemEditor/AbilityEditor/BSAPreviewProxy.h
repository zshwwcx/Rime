#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"



class FBSAPreviewProxy
{
#pragma region Important
public:
	FBSAPreviewProxy(class UBSAAsset* InAsset, const TSharedPtr<class FBSAEditor>& InEditor);

	virtual ~FBSAPreviewProxy();

	void Tick(float DeltaTime);

	void Finish();

	float GetCurrentTime(int32 SectionID);

	class UBSAAsset* GetPreviewAsset() const;

private:
	void OnPreviewEnd();

private:
	// 资源文件
	TWeakObjectPtr<class UBSAAsset> CachedAsset;

	// 编辑器
	TWeakPtr<class FBSAEditor> CachedEditor;

	// 当前正在播放的实例
	TWeakObjectPtr<class UBSAInstanceV2> PlayingInstanceV2;

#pragma endregion Important



#pragma region Preview
public:
	class UBSAInstanceV2* GetPlayingInstanceV2() const;

	void Play();

	bool IsPlaying() const;

	void Pause();

	bool IsPaused() const;

	void Resume();

	void Stop();

	bool IsStopped() const;

	void ResetWorld();

	void OnObjectMoved(UObject* InObject);

	void TimeLineClick(float PreTime, float ClickTime);

private:
	void InitPlay();

private:
	// 开始播放的时间戳
	int64 PlayTimeStamp = 0;

	// 正在播放
	bool bPlaying = false;

	// 正在暂停
	bool bPause = false;

	// 正在时间轴拖动
	bool bSrubing = false;

	float RecordStartTimer = -1.0f;

	float RecordEndTimer = -1.0f;

	class IVideoRecordingSystem* VideoRecordingSystem = nullptr;

	// 记录顿帧信息
	TArray<FInt64Vector> SlomoInformations;

#pragma endregion Preview



#pragma region Event
public:
	void OnTaskSelectionChanged(TArray<class UBSATask*> SelectTaskList);

	void OnAnyBSEditorStartPlay(UWorld* PlayingWorld);

	void OnSetShowCollision(bool bShowCollision);

#pragma endregion Event
	
};