#pragma once

#include "UObject/Object.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"

#include "Engine/DataAsset.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BSATaskTemplate.generated.h"



UCLASS(Blueprintable)
class UBSATaskTemplate : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	TArray<FBSATaskTemplateInfo> TaskGroups;

};