#pragma once

#include "Widgets/TimeLineBase/AnimTimelineTrack.h"



class FBSATimelineTrackPanel : public FAnimTimelineTrack
{
	ANIMTIMELINE_DECLARE_TRACK(FBSATimelineTrackPanel, FAnimTimelineTrack);

public:
	static const float NotificationTrackHeight;
	static const float NotificationSubTrackHeight;

	FBSATimelineTrackPanel(const TSharedRef<class FBSATimelineController>& InController, class UBSATask* InTask, const FText& InDisplayName, const FText& InToolTipText);

	void UpdateLayout();

	// 绘制Task时间轨道
	TSharedRef<SWidget> GenerateContainerWidgetForTimeline() override;

	// 绘制Task轨道左边的大纲
	TSharedRef<SWidget> GenerateContainerWidgetForOutliner(const TSharedRef<SAnimOutlinerItem>& InRow) override;

private:
	void OnCommitTrackName(const FText& InText, ETextCommit::Type CommitInfo);

	void RefreshOutlinerWidget();

	void InputViewRangeChanged(float ViewMin, float ViewMax);

	void OnSelectTask();

	void OnDeselectAllTask();

	void RemoveSelectedTasks();

	void AddNewTask(UClass* InTaskClass, float InStartTime);

	void CopySelectedTasks();

	void PasteSelectedTasks();

	void ExportTaskTemplate();

private:
	TWeakObjectPtr<class UBSATask> CachedTask = nullptr;

	TSharedPtr<class SBSATaskTrackTimeline> TrackWidget = nullptr;
	
};