#pragma once

#include "CoreMinimal.h"
#include "WorkflowOrientedApp/ApplicationMode.h"
#include "WorkflowOrientedApp/WorkflowTabManager.h"



class FBSAEditorMode : public FApplicationMode
{
public:
	FBSAEditorMode(const FName& InModeName, TSharedRef<class FBSAEditor> InEditor);

	virtual ~FBSAEditorMode() {}

	virtual void RegisterTabFactories(TSharedPtr<FTabManager> InTabManager) final override;

	virtual void AddTabFactory(FCreateWorkflowTabFactory FactoryCreator) final override;

	virtual void RemoveTabFactory(FName TabFactoryID) final override;

	virtual void CreateModeTabs(const TSharedRef<class FBSAEditor> InEditor, FWorkflowAllowedTabSet& OutTabFactories) = 0;

protected:
	TWeakPtr<class FBSAEditor> CachedEditor;

	FWorkflowAllowedTabSet TabFactories;

};






class FBSAEditorMode_Main : public FBSAEditorMode
{
public:
	FBSAEditorMode_Main(TSharedRef<class FBSAEditor> InEditor);

	virtual void CreateModeTabs(const TSharedRef<class FBSAEditor> InEditor, FWorkflowAllowedTabSet& OutTabFactories) override;

};






class FBSAEditorMode_LogicGraph : public FBSAEditorMode
{
public:
	FBSAEditorMode_LogicGraph(TSharedRef<class FBSAEditor> InEditor);

	virtual void CreateModeTabs(const TSharedRef<class FBSAEditor> InEditor, FWorkflowAllowedTabSet& OutTabFactories) override;

};
