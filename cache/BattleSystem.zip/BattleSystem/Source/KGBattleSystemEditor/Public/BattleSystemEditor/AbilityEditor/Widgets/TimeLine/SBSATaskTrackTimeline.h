#pragma once

#include "CoreMinimal.h"
#include "Input/Reply.h"
#include "Misc/Attribute.h"

#include "SNodePanel.h"
#include "SCurveEditor.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineEvent.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackNode.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SScrollBar.h"


class SBSATaskTrackTimeline : public SCompoundWidget
{
#pragma region Important
public:
	SLATE_BEGIN_ARGS(SBSATaskTrackTimeline)
		: _ViewInputMin()
		, _ViewInputMax()
		, _TimelinePlayLength()
		, _TrackIndex()
		, _OnSetInputViewRange()
		, _OnRefreshPanel()
		, _OnSelectNode()
		, _OnDeselectAllNodes()
		, _OnDeleteTask()
		, _OnAddNewTask()
		, _OnCopyTasks()
	{}
	SLATE_ARGUMENT(class UBSATask*, Task)
	SLATE_ATTRIBUTE(float, ViewInputMin)
	SLATE_ATTRIBUTE(float, ViewInputMax)
	SLATE_ATTRIBUTE(float, InputMin)
	SLATE_ATTRIBUTE(float, InputMax)
	SLATE_ATTRIBUTE(float, TimelinePlayLength)
	SLATE_ATTRIBUTE(double, FrameRate)
	SLATE_ARGUMENT(int32, TrackIndex)

	SLATE_EVENT(FOnSetInputViewRange, OnSetInputViewRange)

	SLATE_EVENT(FRefreshPanel, OnRefreshPanel)

	SLATE_EVENT(FSelectNode, OnSelectNode)
	SLATE_EVENT(FDeselectAllNodes, OnDeselectAllNodes)

	SLATE_EVENT(FDeleteTask, OnDeleteTask)
	SLATE_EVENT(FAddNewTask, OnAddNewTask)
	SLATE_EVENT(FCopyTask, OnCopyTasks)
	SLATE_EVENT(FPasteTask, OnPasteTasks)
	SLATE_EVENT(FTaskTemplate, OnExportTaskTemplate)

	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	int32 GetTrackIndex() const;

private:
	float TimelinePlayLength;

	int32 TrackIndex;

	TWeakObjectPtr<class UBSATask> CachedTask = nullptr;

	TSharedPtr<SBSATaskTrackNode> TaskNode = nullptr;

#pragma endregion Important



#pragma region Render
public:
	int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	void UpdateLayout();

private:
	TAttribute<FLinearColor> TrackColor;

#pragma endregion Render



#pragma region Menu
private:
	TSharedPtr<SWidget> SummonContextMenu(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

	void AddNewTaskMenu(FMenuBuilder& MenuBuilder);

	void CreateNewTaskNodeAtCursor(UClass* NotifyClass);

	void CopyTaskMenu();

	void PasteTaskMenu();

	void ExportTaskTemplateMenu();

private:
	bool bIsCtrlDown = false;

#pragma endregion Menu



#pragma region Widget
public:
	float GetLastClickedTime() const;

	const FGeometry& GetCachedGeometry() const;

	void UpdateCachedGeometry(const FGeometry& InGeometry);

	FTrackScaleInfo GetCachedScaleInfo() const;

	FVector2D ComputeDesiredSize(float) const override;

	bool SupportsKeyboardFocus() const override;

	FReply OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	FCursorReply OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const override;

	void HandleNodeDrop(TSharedPtr<SBSATaskTrackNode> Node, float Offset = 0.0f);

private:
	void SelectTaskNode();

	void DeselectAllTaskNodes();

	void DeleteSelectedTask();

	void OnDeleteKeyPressed();

	float CalculateTime(const FGeometry& MyGeometry, FVector2D NodePos, bool bInputIsAbsolute = true);

	FMargin GetNotifyTrackPadding() const;

	FReply OnNotifyNodeDragStarted(TSharedRef<SBSATaskTrackNode> NotifyNode, const FPointerEvent& MouseEvent, const FVector2D& ScreenNodePosition, const bool bDragOnMarker, int32 NotifyIndex);

	float CalculateDraggedNodePos() const { return CurrentDragXPosition; }

private:
	TAttribute<float> ViewInputMin;

	TAttribute<float> ViewInputMax;

	TAttribute<float> InputMin;

	TAttribute<float> InputMax;

	float LastClickedTime;

	float CurrentDragXPosition;

	FGeometry CachedGeometry;

	TSharedPtr<SBorder> TrackArea;

	TSharedPtr<SOverlay> NodeSlots;

	TSharedPtr<SScrollBar> NotifyTrackScrollBar;

#pragma endregion Widget



#pragma region Event
private:
	FOnSetInputViewRange SetInputViewRangeEvent;

	FRefreshPanel RefreshPanelEvent;

	FSelectNode SelectNodeEvent;

	FDeselectAllNodes DeselectAllNodesEvent;

	FDeleteTask DeleteTaskEvent;

	FAddNewTask AddNewTaskEvent;

	FStartDragNode StartDragNodeEvent;

	FCopyTask CopyTaskEvent;

	FPasteTask PasteTaskEvent;

	FTaskTemplate TaskTemplateEvent;

#pragma endregion Event

};
