#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameState.h"

#include "LuaOverriderInterface.h"

#include "BattleSystem/Ability/Task/BSATaskStructs.h"

#include "BSAPreviewGameState.generated.h"



UCLASS()
class ABSAPreviewGameState : public AGameState, public ILuaOverriderInterface
{
	GENERATED_BODY()
	
public:
	
};
