#pragma once

#include "CoreMinimal.h"

#include "Curves/CurveFloat.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "3C/Movement/MovementPipeline/MovementContext.h"

#include "BSATaskMovement.generated.h"



#pragma region AddImpulse
UCLASS(Abstract, Blueprintable)
class UBSATAddImpulse : public UBSATask
{
	GENERATED_BODY()

public:
	// 使用外界数据
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Data")
	bool bUseExtraData = false;



	// 创建一个坐标系
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Impulse", meta = (EditCondition = "!bUseExtraData"))
	TArray<FBSATransformCreater> TransformCreaters;

	// 冲量在Forward方向上的大小
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Impulse", meta = (EditCondition = "!bUseExtraData"))
	float ForwardImpulse = 0.0f;

	// 冲量在Up方向上的大小
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Impulse", meta = (EditCondition = "!bUseExtraData"))
	float UpImpulse = 0.0f;



	// 清空速度
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Extra")
	bool ClearVelocity = true;

	// 是否使用质量
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Extra")
	bool bUseMass = false;


#if WITH_EDITOR
public:
	bool UpdateEditorProperty() override
	{
		return false;
	}

#endif
};

#pragma endregion AddImpulse






#pragma region RotateActor
UCLASS(Abstract, Blueprintable)
class UBSATRotateActor : public UBSATask
{
	GENERATED_BODY()

public:
	// 设置方向还是设置位置(Look At Location)
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bSetDirection = true;

	// 坐标计算器(遍历找到并计算出当前合法的坐标)
	UPROPERTY(EditAnywhere)
	TArray<FBSATransformCreater> TransformCreaters;


	// 最大旋转角度(0代表无最大限制)
	UPROPERTY(EditAnywhere, Meta = (ClampMin = "0.0", ClampMax = "180.0"))
	float MaxRotateAngle = 0.0f;

	// 旋转速度(单位Deg/s，默认360度每秒，值为0代表放弃旋转)
	UPROPERTY(EditAnywhere, meta = (EditCondition = "LifeType != EBSATaskLife::TL_Instant"))
	float RotateSpeed = 3600.0f;

	// 是否跟随目标(无最大旋转角度、非立即结束时才可以使用)
	UPROPERTY(EditAnywhere, meta = (EditCondition = "LifeType != EBSATaskLife::TL_Instant || MaxRotateAngle <= 0.1"))
	bool NeedHomingTarget = false;

	// 以本地坐标中的某个方向为基准，计算目标Rotation（默认是(1.0f, 0.0f, 0.0f)即Actor的ForwardVector）
	UPROPERTY(EditAnywhere, AdvancedDisplay)
	FVector2D RelativeDirection = FVector2D(1.0f, 0.0f);


#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty()
	{
		return false;
	}

#endif
};

#pragma endregion RotateActor






#pragma region RootMotionToActor
UCLASS(Abstract, Blueprintable)
class UBSATRootMotionToTarget : public UBSATask
{
	GENERATED_BODY()

public:
	// 目标位置的偏移量（以目标和角色的连线作为X轴，角色的UpVector作为Z轴来构建坐标系）
	UPROPERTY(EditDefaultsOnly)
	FVector TargetLocationBias = FVector(-150.0f, 0.0f, 0.0f);

	// 是否追踪Target
	UPROPERTY(EditDefaultsOnly)
	bool bNeedTraceTarget = false;

	// 最大移动距离
	UPROPERTY(EditDefaultsOnly, meta = (EditCondition = "!bNeedTraceTarget"))
	float MaxDistance = 1000.0f;



	// 是否要检测地面，防止角色停在半空中
	UPROPERTY(EditDefaultsOnly, Category = "ExtraLogic", Meta = (EditCondition = "!bNeedTraceTarget"))
	bool bNeedCheckGround = true;
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Category = "ExtraLogic", Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度的对象类型
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Category = "ExtraLogic", Meta = (EditCondition = "bNeedCheckGround"))
	FVector2D GroundCheckOffset = FVector2D(-300.0f, 300.0f);



	// 完成度曲线（[0,1]）, 不填默认线性递增
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FRuntimeFloatCurve TimeMappingFloatCurve;



	// 位移偏移曲线（即：支持曲线移动）
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FRuntimeVectorCurve PathOffsetVectorCurve;


#if WITH_EDITOR
public:
	virtual void PreSave(class FObjectPreSaveContext SaveContext) override;

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty() override { return false; }

#endif

};

#pragma endregion RootMotionToActor






#pragma region RootMotionToLocation
UCLASS(Abstract, Blueprintable)
class UBSATRootMotionToLocation : public UBSATask
{
	GENERATED_BODY()

public:
	// 创建一个坐标系
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	TArray<FBSATransformCreater> TransformCreaters;
	// 移动距离
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	float Distance = 1000.0f;
	// 优先级
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	int32 RootMotionPriority = 1000;


	// 完成度曲线[0,1], 为NULL则默认线性递增
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FRuntimeFloatCurve TimeMappingFloatCurve;
	//UPROPERTY(VisibleDefaultsOnly, BlueprintReadWrite)
	//UCurveFloat* GeneratedTimeMappingCurve = NULL;


	// 位移偏移曲线（即：支持曲线移动）
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FRuntimeVectorCurve PathOffsetVectorCurve;
	//UPROPERTY(VisibleDefaultsOnly, BlueprintReadWrite)
	//UCurveVector* GeneratedPathOffsetCurve = NULL;
	

	// 控制结束最大速度(>0 开启)
	UPROPERTY(EditDefaultsOnly)
	float FinishClampVelocity = 0.0f;

	// 是否要检测地面，防止角色停在半空中
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "ExtraLogic")
	bool bNeedCheckGround = true;
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Category = "ExtraLogic", Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度的对象类型
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Category = "ExtraLogic", Meta = (EditCondition = "bNeedCheckGround"))
	FVector2D GroundCheckOffset = FVector2D(-300.0f, 300.0f);


#if WITH_EDITOR
public:
	virtual void PreSave(class FObjectPreSaveContext SaveContext) override;

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty() override { return false; }

#endif

};

#pragma endregion RootMotionToLocation






#pragma region RootMotionByBeaten
UCLASS(Abstract, Blueprintable)
class UBSATRootMotionByBeaten : public UBSATask
{
	GENERATED_BODY()

public:
	// 完成度曲线[0,1], 为NULL则默认线性递增
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FRuntimeFloatCurve TimeMappingFloatCurve;

	// 是否要检测地面，防止角色停在半空中
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	bool bNeedCheckGround = true;
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	// 地表查询射线长度的对象类型
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Meta = (EditCondition = "bNeedCheckGround"))
	FVector2D GroundCheckOffset = FVector2D(-300.0f, 300.0f);


#if WITH_EDITOR
public:
	virtual void PreSave(class FObjectPreSaveContext SaveContext) override;

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty() override { return false; }

#endif

};

#pragma endregion RootMotionForBeaten






#pragma region BeatenTeleport
UCLASS(Abstract, Blueprintable)
class UBSATBeatenTeleport : public UBSATask
{
	GENERATED_BODY()

public:
	// 是否要检测地面，防止角色停在半空中
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	bool bNeedCheckGround = true;
	
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Meta = (EditCondition = "bNeedCheckGround"))
	TArray<TEnumAsByte<EObjectTypeQuery>> GroundCheckObjectTypes;
	
	// 地表查询射线长度的对象类型
	UPROPERTY(EditDefaultsOnly, AdvancedDisplay, BlueprintReadWrite, Meta = (EditCondition = "bNeedCheckGround"))
	FVector2D GroundCheckOffset = FVector2D(-300.0f, 300.0f);

};

#pragma endregion BeatenTeleport






#pragma region FlashToLocation
UCLASS(Abstract, Blueprintable)
class UBSATFlashToLocation : public UBSATask
{
	GENERATED_BODY()

public:
	// 坐标计算器(遍历找到并计算出当前合法的坐标)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform")
	TArray<FBSATransformCreater> TransformCreaters;

	// 当前角色坐标系下的额外的位置坐标偏移
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform")
	FVector LocationOffset;
};

#pragma endregion FlashToLocation





#pragma region BasicMoveAdjust
UCLASS(Abstract, Blueprintable)
class UBSATBasicMoveAdjust : public UBSATask
{
	GENERATED_BODY()

public:
	// Task结束时是否回滚
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	bool bNeedReset = true;



	// 开启移动推进器（技能中需要非正常行走驱动的移动时，需要打开）
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Thruster")
	bool bAllowThruster = false;

	// 默认推进器最大速度以当时的MaxSpeed为准，当OverrideThrusterMaxSpeed大于0时，将以他为准
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Thruster", Meta = (EditCondition = "bAllowThruster"))
	float OverrideThrusterMaxSpeed = -1.0f;

	// 默认推进器最大加速度以当时的MaxAcceleration为准，当OverrideThrusterMaxAcceleration大于0时，将以他为准
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Thruster", Meta = (EditCondition = "bAllowThruster"))
	float OverrideThrusterMaxAcceleration = -1.0f;

	// 默认推进器最大减速度以当时的MaxBrakingDeceleration为准，当OverrideThrusterMaxBrakingDeceleration大于等于0时，将以他为准
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Thruster", Meta = (EditCondition = "bAllowThruster"))
	float OverrideThrusterMaxBrakingDeceleration = -1.0f;



	// 开启旋转控制器
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|YawController")
	bool bAllowYawController = false;

	// MovementOutputMode
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|YawController", Meta = (EditCondition = "bAllowYawController"))
	EMovementOutputMode MovementOutputMode = EMovementOutputMode::EOverride;

	// EInterpolationMode
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|YawController", Meta = (EditCondition = "bAllowYawController"))
	EInterpolationMode InterpolationMode = EInterpolationMode::Halflife;

	// EArgSourceMode
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|YawController", Meta = (EditCondition = "bAllowYawController"))
	EArgSourceMode ArgSourceMode = EArgSourceMode::LocoInputVector;



	// 当OverrideGravityScale大于等于0时，将以他替换角色的OverrideGravityScale
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Gravity")
	float OverrideGravityScale = -1.0f;



	// 是否开启冲浪模式（默认固定前向移动，并附加转向限制）
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Surf")
	bool bAllowSurfMode = false;

	// 加速度的最小偏转角
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Surf", Meta = (EditCondition = "bAllowSurfMode"))
	float MinAcceAngle = 0.1f;

	// 加速度的最大偏转角
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Surf", Meta = (EditCondition = "bAllowSurfMode"))
	float MaxAcceAngle = 0.5f;

	// 触发冲浪方向调整的角度
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Surf", Meta = (EditCondition = "bAllowSurfMode"))
	float MinAdjustAngle = 10.0f;

	// 触发冲浪方向调整的最大角度
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config|Surf", Meta = (EditCondition = "bAllowSurfMode"))
	float MaxAdjustAngle = 80.0f;
};

#pragma endregion BasicMoveAdjust
