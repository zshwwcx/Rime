#pragma once

#include "Delegates/DelegateCombinations.h"



DECLARE_DELEGATE(FRefreshPanel);
DECLARE_DELEGATE(FSelectNode);
DECLARE_DELEGATE(FDeselectAllNodes);
DECLARE_DELEGATE(FDeleteTask);
DECLARE_DELEGATE(FCopyTask);
DECLARE_DELEGATE(FPasteTask);
DECLARE_DELEGATE(FExportTask);
DECLARE_DELEGATE(FTaskTemplate);


DECLARE_DELEGATE_TwoParams(FAddNewTask, UClass*, float)

DECLARE_DELEGATE_RetVal_FourParams(FReply, FStartDragNode, TSharedRef<class SBSATaskTrackNode>, const FPointerEvent&, const FVector2D&, const bool)

DECLARE_DELEGATE_RetVal_FourParams(FReply, FStartExtraDragNode, TSharedRef<class SBSAExtraTrackNode>, const FPointerEvent&, const FVector2D&, const bool)
