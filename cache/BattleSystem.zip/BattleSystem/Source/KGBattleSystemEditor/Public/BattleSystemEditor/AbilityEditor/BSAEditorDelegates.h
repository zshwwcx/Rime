#pragma once
#include "CoreMinimal.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"

class KGBATTLESYSTEMEDITOR_API FBSAEditorDelegates
{
public:
	DECLARE_MULTICAST_DELEGATE_OneParam(FAddTaskDelegate, class UBSATask*);
	static FAddTaskDelegate AddTaskEvent;

	DECLARE_MULTICAST_DELEGATE_OneParam(FDeleteTaskDelegate, class UBSATask*);
	static FDeleteTaskDelegate DeleteTaskEvent;

	DECLARE_MULTICAST_DELEGATE_OneParam(FMoveTaskDelegate, class UBSATask*);
	static FMoveTaskDelegate MoveTaskEvent;

	DECLARE_MULTICAST_DELEGATE_OneParam(FTaskSelectionChangedDelegate, TArray<class UBSATask*>);
	static FTaskSelectionChangedDelegate TaskSelectionChangedEvent;

	DECLARE_MULTICAST_DELEGATE_TwoParams(FPreviewStateChanged, bool, bool);
	static FPreviewStateChanged PreviewStateChangedEvent;

	DECLARE_DELEGATE_RetVal_OneParam(class ACameraActor*, FOnCreatePreviewCameraDelegate, class UWorld*);
	static FOnCreatePreviewCameraDelegate OnCreatePreviewCameraEvent;

	DECLARE_MULTICAST_DELEGATE_OneParam(FStartPlayDelegate, class UWorld*);
	static FStartPlayDelegate StartPlayEvent;

	DECLARE_MULTICAST_DELEGATE_OneParam(FSetShowCollisionDelegate, bool);
	static FSetShowCollisionDelegate SetShowCollisionEvent;

	DECLARE_MULTICAST_DELEGATE_OneParam(FAutoOptimizeDoneDelegate, class UBSAAsset*);
	static FAutoOptimizeDoneDelegate AutoOptimizeDoneDelegate;
	
	DECLARE_MULTICAST_DELEGATE_OneParam(FSkillAssetPropertyChange, FName PropertyName);
	static FSkillAssetPropertyChange SkillAssetPropertyChange;
	
	DECLARE_MULTICAST_DELEGATE_TwoParams(FOnInitializeEditorFinishDelegate,TWeakPtr<FBSAEditor>,TWeakPtr<FExtender>);
	static FOnInitializeEditorFinishDelegate OnInitializeEditorFinishDelegate;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnDestructorEditorDelegate, FBSAEditor*);
	static FOnDestructorEditorDelegate OnDestructorEditorDelegate;
};
