#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystem/Ability/BSAStructs.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"

#include "BSATaskGhost.generated.h"


#pragma region AddGhost
UCLASS(Abstract, Blueprintable)
class UBSATAddGhost : public UBSATask
{
	GENERATED_BODY()

public:
	// 模型来源
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	EBSASelectTarget MeshSource = EBSASelectTarget::ST_Owner;

	// 残影使用的模型LOD
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	int32 MeshLOD = 2;

	// 残影生成间隔时间
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	float GhostSpawnFrequency = 0.1f;

	// 残影的生命周期
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base", Meta = (ClampMin = 0.1f))
	float GhostLife = 0.5f;



	// 播放特定动画
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Anim")
	bool bPlayAnim = false;

	// 需要播放的动画
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Anim", Meta = (EditCondition = "bPlayAnim", EditConditionHides))
	TSoftObjectPtr<class UAnimSequence> AnimSequence = nullptr;

	// 需要循环播放动画
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Anim", Meta = (EditCondition = "bPlayAnim", EditConditionHides))
	bool bNeedLoop = false;

	// 是否更新动作
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Anim", Meta = (EditCondition = "!bPlayAnim", EditConditionHides))
	bool bNeedUpdatePose = false;



	// 是否强制使用目标最原始材质(可能与当前材质不同)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Draw")
	bool bUseTargetOriginMaterial = false;

	// 基础替换材质
	// UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Draw")
	// FOverrideMaterialParameter BaseMaterial;

	// 是否开启自定义深度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Draw")
	bool bUseCustomDepth = false;

	// 在开启自定义深度后是否进行绘制
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Draw", Meta = (EditCondition = "bUseCustomDepth", EditConditionHides))
	bool bNeedRenderInMainPass = false;

	// 自定义深度的Mask
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Draw", Meta = (EditCondition = "bUseCustomDepth", EditConditionHides))
	ERendererStencilMask CustomDepthStencilMask = ERendererStencilMask::ERSM_Default;

	// 自定义深度的值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Draw", Meta = (EditCondition = "bUseCustomDepth", EditConditionHides))
	int32 CustomDepthValue = 0;



	// 是否进行绑定
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform")
	bool bNeedAttach = false;

	// 绑定模式下的骨骼名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSSocketSelector AttachSocket;

	// 绑定模式下的坐标偏移矩阵
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "bNeedAttach", EditConditionHides))
	FBSATPP_Transform AttachTransform;

	// 坐标计算信息
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", Meta = (EditCondition = "!bNeedAttach"))
	FBSATransformCreater CoordinateCreater;

public:
	void GetReferenceResources(TArray<FString>& InOutList) override;

#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	void UpdateDataByDynamicActorInfo(const FBSADynamicObjectInfo& InInfo) override;

	void UpdateDynamicActorByData(const FBSADynamicObjectInfoArray& InInfoArray) override;

	bool UpdateEditorProperty() override
	{
		return false;
	}
#endif

};

#pragma endregion AddDecal
