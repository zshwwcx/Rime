#pragma once

#include "CoreMinimal.h"
#include "Input/Reply.h"
#include "Input/DragAndDrop.h"
#include "Misc/Attribute.h"

#include "SNodePanel.h"
#include "SCurveEditor.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineEvent.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineController.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackNode.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackTimeline.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSAExtraTrackNode.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSAExtraTrackTimeline.h"



class FBSATrackDragDropOp : public FDragDropOperation
{
public:
	DRAG_DROP_OPERATOR_TYPE(FBSATrackDragDropOp, FDragDropOperation)

	FBSATrackDragDropOp();

	void Construct() override;

	static TSharedRef<FBSATrackDragDropOp> New(const TSharedPtr<FBSATimelineController>& InTimelineController, class UBSATask* InTask, TSharedPtr<SWidget> Decorator);

	void OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent) override;

	void OnDragged(const class FDragDropEvent& DragDropEvent) override;

	TSharedPtr<SWidget> GetDefaultDecorator() const override;

	void SetCanDropHere(bool bCanDropHere);

	void ChangeTaskTrackPosition(class UBSATask* TargetTask);

public:
	TSharedPtr<SWidget>	Decorator = nullptr;

	TWeakObjectPtr<class UBSATask> CachedTask = nullptr;

	TWeakPtr<FBSATimelineController> TimelineController = nullptr;

};






class FBSATrackNodeDragDropOp : public FDragDropOperation
{
public:
	struct FTrackClampInfo
	{
		int32 TrackPos;
		int32 TrackSnapTestPos;
		TSharedPtr<SBSATaskTrackTimeline> NotifyTrack;
	};
	
	DRAG_DROP_OPERATOR_TYPE(FBSATrackNodeDragDropOp, FDragDropOperation)

	FBSATrackNodeDragDropOp(float& InCurrentDragXPosition);

	static TSharedRef<FBSATrackNodeDragDropOp> New
	(
		TArray<TSharedPtr<SBSATaskTrackNode>> NotifyNodes, TSharedPtr<SWidget> Decorator,
		const TArray<TSharedPtr<SBSATaskTrackTimeline>>& NotifyTracks, float InViewPlayLength,
		const FVector2D& CursorPosition, const FVector2D& SelectionScreenPosition,
		const FVector2D& SelectionSize, float& CurrentDragXPosition, FRefreshPanel& RefreshPanel
	);
	
	void OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent) override;

	void OnDragged(const class FDragDropEvent& DragDropEvent) override;

	TSharedPtr<SWidget> GetDefaultDecorator() const override
	{
		return Decorator;
	}

	FText GetHoverText() const;

	FTrackClampInfo& GetTrackClampInfo(const FVector2D NodePos);

public:
	FVector2D DragOffset;
	TArray<FTrackClampInfo> ClampInfos;	

	TSharedPtr<SWidget> Decorator;
	TArray<TSharedPtr<SBSATaskTrackNode>> SelectedNodes;

	TArray<float> NodeTimes;
	TArray<float> NodeTimeOffsets;
	TArray<float> NodeXOffsets;
	FVector2D NodeGroupPosition;
	FVector2D NodeGroupSize;

	int32 TrackSpan;
	float ViewPlayLength;
	float SelectionTimeLength;
	float CurrentDragXPosition;

	FRefreshPanel RefreshPanelEvent;

};






class FBSAExtraTrackNodeDragDropOp : public FDragDropOperation
{
public:
	struct FTrackClampInfo
	{
		int32 TrackPos;
		int32 TrackSnapTestPos;
		TSharedPtr<SBSAExtraTrackTimeline> NotifyTrack;
	};

	DRAG_DROP_OPERATOR_TYPE(FBSAExtraTrackNodeDragDropOp, FDragDropOperation)

	FBSAExtraTrackNodeDragDropOp(float& InCurrentDragXPosition);

	static TSharedRef<FBSAExtraTrackNodeDragDropOp> New
	(
		TArray<TSharedPtr<SBSAExtraTrackNode>> NotifyNodes, TSharedPtr<SWidget> Decorator,
		const TArray<TSharedPtr<SBSAExtraTrackTimeline>>& NotifyTracks, float InViewPlayLength,
		const FVector2D& CursorPosition, const FVector2D& SelectionScreenPosition,
		const FVector2D& SelectionSize, float& CurrentDragXPosition, FRefreshPanel& RefreshPanel
	);

	void OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent) override;

	void OnDragged(const class FDragDropEvent& DragDropEvent) override;

	TSharedPtr<SWidget> GetDefaultDecorator() const override
	{
		return Decorator;
	}

	FText GetHoverText() const;

	FTrackClampInfo& GetTrackClampInfo(const FVector2D NodePos);

public:
	FVector2D DragOffset;
	TArray<FTrackClampInfo> ClampInfos;

	TSharedPtr<SWidget> Decorator;
	TArray<TSharedPtr<SBSAExtraTrackNode>> SelectedNodes;

	TArray<float> NodeTimes;
	TArray<float> NodeTimeOffsets;
	TArray<float> NodeXOffsets;
	FVector2D NodeGroupPosition;
	FVector2D NodeGroupSize;

	int32 TrackSpan;
	float ViewPlayLength;
	float SelectionTimeLength;
	float CurrentDragXPosition;

	FRefreshPanel RefreshPanelEvent;

};
