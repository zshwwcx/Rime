#pragma once

#include "IDocumentation.h"
#include "SimpleEditor/SSimpleEditorViewport.h"



class SBSAEditorViewport : public SSimpleEditorViewport
{
#pragma region Important
public:
	SLATE_BEGIN_ARGS(SBSAEditorViewport) {}
	SLATE_END_ARGS()

	virtual ~SBSAEditorViewport();

	void Construct(const FArguments& InArgs, const FEditorViewportParameter& InParameter);

	void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	virtual TSharedRef<FEditorViewportClient> MakeEditorViewportClient() override;

	virtual TSharedPtr<SWidget> MakeViewportToolbar() override;

protected:
	TWeakPtr<class FBSAEditor> CachedEditor = nullptr;

#pragma endregion Important

};