#pragma once

#include "CoreMinimal.h"
#include "CollisionQueryParams.h"

#include "WorkProxy/OperateStackStructs.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystem/BSSettings.h"
#include "BattleSystem/Ability/BSACollision.h"
#include "BattleSystem/Ability/BSACondition.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Enums/BSAEditEnums.h"

#include "BSATaskCollision.generated.h"



#pragma region CollisionQuery
UCLASS(Abstract, Blueprintable)
class UBSATCollisionQueryBase : public UBSATask
{
	GENERATED_BODY()

public:
	UBSATCollisionQueryBase()
	{
		EventTaskMap.Add(TEXT("Sucess"), FBSATaskSelectorList());
	}

public:
	// 开启客户端预测模式（此模式下，服务器不进行碰撞检测，碰撞结果由客户端上报给服务器）
	UPROPERTY(EditDefaultsOnly, Category = "Prediction")
	bool bUseClientPrediction = false;

	// 延迟触发碰撞事件
	UPROPERTY(EditDefaultsOnly, Category = "Prediction", Meta = (ClampMin = 0.1f, ClampMax = 0.2f, EditCondition = "bUseClientPrediction", EditConditionHides))
	float DelayTriggerCollisionEvent = 0.1f;


	// 命中数量限制(小于等于0代表无限制)
	UPROPERTY(EditDefaultsOnly, Category = "Important")
	int32 CollisionResultLimit = -1;

	// 当角色被碰撞检查到后，设置一个时长，使其在后续N秒内不会再次被检测到
	UPROPERTY(EditDefaultsOnly, Category = "Important", Meta = (EditCondition = "LifeType != EBSATaskLife::TL_Instant && !bUseClientPrediction", EditConditionHides))
	float CollisionCoolDown = 10.0f;

	// 碰撞检测频率，每隔N秒进行一次碰撞检查
	UPROPERTY(EditDefaultsOnly, Category = "Important", Meta = (EditCondition = "LifeType != EBSATaskLife::TL_Instant && !bUseClientPrediction", EditConditionHides))
	float CollisionFrequency = 0.4f;

	// 碰撞盒坐标发生改变，是否需要做扫描检测
	UPROPERTY(EditDefaultsOnly, Category = "Important", Meta = (EditCondition = "LifeType != EBSATaskLife::TL_Instant && !bUseClientPrediction", EditConditionHides))
	bool bUseSweep = false;

	// 是否要贴近地表
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform", AdvancedDisplay)
	bool bNeedGround = true;


	// 目标粗筛
	UPROPERTY(EditDefaultsOnly, Category = "Filter")
	FBSSelectTargetInfo TargetFilter;

	// 锁定碰撞结果
	UPROPERTY(EditDefaultsOnly, Category = "Filter")
	bool bLockTargets = false;


#if WITH_EDITOR
public:
	virtual void PreSave(class FObjectPreSaveContext SaveContext);

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

};

USTRUCT(BlueprintType)
struct FCQSubTask : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName TaskName;

};

UCLASS(Abstract, Blueprintable)
class UBSATCollisionQuery : public UBSATCollisionQueryBase
{
	GENERATED_BODY()

public:
	UBSATCollisionQuery() {}

public:
	// 碰撞检测策略
	UPROPERTY(EditDefaultsOnly, Category = "Important", Instanced)
	UBSACollisionStrategy* CollisionStrategy = nullptr;


	// 坐标计算器(遍历找到并计算出当前合法的坐标)
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform")
	TArray<FBSATransformCreater> TransformCreaters = { FBSATransformCreater() };

	// 坐标相对偏移曲线
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform", Meta = (EditCondition = "LifeType != EBSATaskLife::TL_Instant && !bUseClientPrediction", EditConditionHides))
	FKGRemapVectorCurve OffsetCurve;

	// 碰撞盒增量缩放曲线
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Transform", Meta = (EditCondition = "LifeType != EBSATaskLife::TL_Instant && !bUseSweep && !bUseClientPrediction", EditConditionHides))
	FKGRemapVectorCurve DeltaScaleCurve;


#if WITH_EDITOR
public:
	virtual void PreSave(class FObjectPreSaveContext SaveContext);

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty()
	{
		return false;
	}

	bool IsTaskInvalid_Implementation() override
	{
		return CollisionStrategy == nullptr;
	}

	void AutoSetNetType();
#endif

};
#pragma endregion CollisionQuery






#pragma region HaloInspection
UCLASS(Abstract, Blueprintable)
class UBSATHaloBase : public UBSATask
{
	GENERATED_BODY()

public:
	// 光环检测频率
	UPROPERTY(EditDefaultsOnly, Category = "Halo", Meta = (ClampMin = 0.1f))
	float CheckFrequency = 1.0f;



	// 光环开启条件
	UPROPERTY(EditDefaultsOnly, Category = "Condition", Instanced)
	TArray<UBSACondition*> HaloEnableConditions;

	// 目标刷新冷却
	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	float TargetRefreshCD = 0.0f;

	// 目标粗筛
	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	FBSSelectTargetInfo TargetFilter;

	// 目标检测条件
	UPROPERTY(EditDefaultsOnly, Category = "Condition", Instanced)
	TArray<UBSACondition*> HaloConditions;



#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual bool UpdateEditorProperty()
	{
		return false;
	}

#endif

};


UCLASS(Abstract, Blueprintable)
class UBSATHaloInspection : public UBSATHaloBase
{
	GENERATED_BODY()

public:

	// 光环范围类型（1：环形，2：矩形）
	UPROPERTY(EditDefaultsOnly, Category = "Halo", Meta = (ClampMin = 1, ClampMax = 2))
	int32 HaloCollisionType = 1;

	// 环形光环内径
	UPROPERTY(EditDefaultsOnly, Category = "Halo", Meta = (EditCondition = "HaloCollisionType == 1", EditConditionHides))
	float HaloInsideRange = 0.0f;

	// 环形光环外径
	UPROPERTY(EditDefaultsOnly, Category = "Halo", Meta = (EditCondition = "HaloCollisionType == 1", EditConditionHides))
	float HaloRange = 1000.0f;

	// 矩形光环宽
	UPROPERTY(EditDefaultsOnly, Category = "Halo", Meta = (EditCondition = "HaloCollisionType == 2", EditConditionHides))
	float HaloWidth = 500.0f;

	// 矩形光环长
	UPROPERTY(EditDefaultsOnly, Category = "Halo", Meta = (EditCondition = "HaloCollisionType == 2", EditConditionHides))
	float HaloLength = 1000.0f;

	// 环形光环角度(暂时先不暴露)
	//UPROPERTY(EditDefaultsOnly, Category = "Halo", Meta = (EditCondition = "HaloCollisionType == 2", EditConditionHides))
	//float HaloAngle = 0.0f;

	// 光环高度限制
	UPROPERTY(EditDefaultsOnly, Category = "Halo", AdvancedDisplay)
	FVector2D HaloHeightRange = FVector2D(-500.0f, 500.0f);



#if WITH_EDITOR
public:
	virtual void PreSave(class FObjectPreSaveContext SaveContext);

	void AutoSetNetType();

#endif

};
#pragma endregion HaloInspection






#pragma region DealCollision
UCLASS(Abstract, Blueprintable)
class UBSATCollisionRedistribute : public UBSATask
{
	GENERATED_BODY()

public:
	// 选择策略
	UPROPERTY(EditDefaultsOnly)
	EBSASelectSrategy AttackStrategy;

	// 碰撞个数上限
	UPROPERTY(EditDefaultsOnly)
	int32 CollisionNum;

	// 碰撞个数上限
	UPROPERTY(EditDefaultsOnly)
	int32 SingleCollisionLimit;

};

#pragma endregion DealCollision






#pragma region SetCollision
UCLASS(Abstract, Blueprintable)
class UBSATSetCollision : public UBSATask
{
	GENERATED_BODY()

public:
	// 碰撞设置参数
	UPROPERTY(EditDefaultsOnly, Category = "Important")
	FChangeCollisionMessage ChangeCollisionMessage;

	// Task结束时恢复碰撞设置
	UPROPERTY(EditDefaultsOnly, Category = "Important")
	bool bRestoreWhenTaskEnd = true;

};

#pragma endregion SetCollision
