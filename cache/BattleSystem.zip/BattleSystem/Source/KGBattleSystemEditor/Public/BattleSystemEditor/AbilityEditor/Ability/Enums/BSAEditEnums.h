#pragma once

#include "CoreMinimal.h"

#include "BSAEditEnums.generated.h"



// 选取策略
UENUM(BlueprintType)
enum class EBSASelectSrategy : uint8
{
	SS_Default               = 0               UMETA(DisplayName = "所有Target各选择一次"),
	SS_RandomAttack                            UMETA(DisplayName = "完全随机选择一定次数"),
	SS_RandomAttackWithLimit                   UMETA(DisplayName = "随机选择一定次数(但是目标有被选择上限)"),
	SS_AverageAttack                           UMETA(DisplayName = "尽量平均选择一定次数"),

	SS_TMax                                    UMETA(Hidden)
};

// Buff移除模式
UENUM(BlueprintType)
enum class EBSABuffRemoveType : uint8
{
	BRT_RemoveLayer               = 0               UMETA(DisplayName = "移除层级或实例"),
	BRT_RemoveReference                             UMETA(DisplayName = "移除引用计数"),

	BRT_TMax                                        UMETA(Hidden)
};

