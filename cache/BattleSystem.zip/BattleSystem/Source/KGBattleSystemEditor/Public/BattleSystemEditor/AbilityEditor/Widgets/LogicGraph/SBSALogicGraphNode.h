#pragma once

#include "CoreMinimal.h"
#include "SGraphNode.h"



class SBSALogicGraphNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SBSALogicGraphNode) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, class UBSALogicGraphNode* InNode);

	void UpdateGraphNode() override;

};
