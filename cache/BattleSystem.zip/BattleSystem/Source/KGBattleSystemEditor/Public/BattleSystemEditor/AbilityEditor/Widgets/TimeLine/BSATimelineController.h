#pragma once

#include "Templates/SharedPointer.h"
#include "UObject/GCObject.h"
#include "Containers/ArrayView.h"
#include "Misc/FrameTime.h"

#include "Widgets/TimeLineBase/TimelineController.h"



class FBSATimelineController : public FTimelineController
{
#pragma region Important
public:
	FBSATimelineController();
	virtual ~FBSATimelineController();

	// 初始化
	void Initialize(const TSharedPtr<class FBSAEditor>& InAssetEditorToolkit, TSharedPtr<class FBSAPreviewProxy> InPreviewProxy, int32 InSectionIndex);

	void RefreshTracks() override;

	void PostClearTrackSelection() override;

	void OnAssetPropertyChange(FName PropertyName);

#pragma endregion Important



#pragma region Parameter
public:
	int32 GetSectionID();
	
	// 获取当前游标的位置
	FFrameNumber GetScrubPosition() const override;

	// 设置游标位置
	void SetScrubPosition(FFrameTime NewScrubPostion) const override;

	// 获取总时长
	float GetPlayLength() const override;

	// 获取帧率
	double GetFrameRate() const override;

	// 获取资源对象
	class UBSAAsset* GetAsset() const;

private:
	TWeakPtr<class FBSAEditor> CachedEditor = nullptr;

	TSharedPtr<class FBSAPreviewProxy> CachedPreviewProxy = nullptr;

	int32 SectionIndex = 0;

	mutable float ScrubPosition = 0;

#pragma endregion Parameter



#pragma region Input
public:
	void ChangeCtrlState(bool bPress);

private:
	bool bPressCtrl = false;

#pragma endregion Input



#pragma region Task
public:
	// 清除Task选择信息
	void ClearTaskSelection();

	// 选中Task
	void ChangeTaskSelection(const TArray<class UBSATask*>& Tasks);

	// 改变Task名称
	void ChangeTaskName(class UBSATask* AtTask, FName NewName);

	// 改变Task轨道位置
	void ChangeTaskPosition(class UBSATask* SrcTask, class UBSATask* DestTask);

	// 改变Task所属的Group
	void ChangeTaskGroup(class UBSATask* SrcTask, struct FBSATaskGroup* DestGroupData);

	// 创建Task组
	void AddNewTaskGroup(const FName& InGroupName = NAME_None);

	// 删除Task组
	void DeleteTaskGroup(struct FBSATaskGroup* InGroup);

	// 创建Task
	class UBSATask* AddNewTask(struct FBSATaskGroup* AtGroup, UClass* InTaskClass, float StartTime = 0.0f);

	// 删除Task
	void DeleteTask(class UBSATask* TheTask);
	
	// 删除选中的Task
	void DeleteSelectedTasks();

	// 获取选中的Tasks
	TArray<class UBSATask*> GetSelectedTasks();

public:
	// 将Asset中与输入Task逻辑相关的Task也加入其中
	void ExpandLogicIncludedTasks(TArray<class UBSATask*>& InTasks);

	// 复制选中的Tasks
	void CopySelectedTasks();

	// 粘贴选中的Tasks
	void PasteSelectedTasks(FString InPasteMsg, int32 InGroupID);

	// 导出选中的Tasks到TaskTemplate
	void ExportSelectedTaskTemplate();

	// 导入对应名称的TaskTemplate
	void ImportTaskTemplate(FName InTemplateName, int32 InGroupID);

private:
	// 根据Group指针查询GroupID
	int32 FindGroupID(struct FBSATaskGroup* AtGroup);

	void ExportSelectedTaskTemplate_Impl();

	// 保存Template名称
	FText TemplateName;
	// 设置模板名称的UI
	TSharedPtr<SWindow> TemplateNameWindow;

#pragma endregion Task


#pragma region Event
public:
	void ReceiveAutoOptimizeDone(class UBSAAsset* Asset);
#pragma endregion Event

};