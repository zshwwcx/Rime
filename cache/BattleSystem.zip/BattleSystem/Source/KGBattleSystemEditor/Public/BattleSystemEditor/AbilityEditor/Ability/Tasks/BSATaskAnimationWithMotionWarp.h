#pragma once

#include "CoreMinimal.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskAnimation.h"

#include "Animation/AnimMontage.h"
#include "3C/Animation/AnimAssetDefine.h"

#include "BSATaskAnimationWithMotionWarp.generated.h"

#pragma region PlayAnimation


UCLASS(Abstract, Blueprintable)
class UBSATPlayAnimationWithMotionWarp: public UBSATPlayAnimation
{
	GENERATED_BODY()

public:
	UBSATPlayAnimationWithMotionWarp()
	{

	}

public:
	UPROPERTY(EditAnywhere, Category = "Animation", AdvancedDisplay)
	bool bIsWarpTranslation = false;

	UPROPERTY(EditAnywhere, Category = "Animation", AdvancedDisplay)
	bool bIsWarpRotation = false;

#if WITH_EDITOR
public:

#endif

};

#pragma endregion PlayAnimation
