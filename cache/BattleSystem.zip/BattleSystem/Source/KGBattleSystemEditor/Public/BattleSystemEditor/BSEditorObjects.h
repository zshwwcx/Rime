#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "BSEditorObjects.generated.h"



UCLASS(Abstract, Blueprintable, EditInlineNew)
class UBSPhysicalSimulationData : public UObject
{
	GENERATED_BODY()

public:

};
