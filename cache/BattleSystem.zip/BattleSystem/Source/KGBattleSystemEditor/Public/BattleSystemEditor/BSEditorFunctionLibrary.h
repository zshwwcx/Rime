#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Serialization/JsonSerializer.h"

#include "GameplayTagsManager.h"
#include "GameplayTagContainer.h"
#include "Misc/KGCoreEditorFunctionLibrary.h"
#include "BSEditorFunctionLibrary.generated.h"



UCLASS(Abstract)
class UBSJsonExporter : public UObject
{
	GENERATED_BODY()

public:
	virtual void ExportSpecialStructToJson(void* DataAddress, FStructProperty* TheStructProp, TSharedPtr<FJsonObject> OutJson, FString ExtraString = "") const {}

	virtual void ExportSpecialObjectToJson(UObject* TheObject, TSharedPtr<FJsonObject> OutJson, FString ExtraString = "") const {}

	virtual TSharedPtr<FJsonValue> ExportGameplayTag(FGameplayTag& InTag) const;

	virtual TSharedPtr<FJsonValue> ExportGameplayTagContainer(FGameplayTagContainer& InTagContainer) const;

public:
	TWeakObjectPtr<UObject> CurrentExportObject = nullptr;
};



UCLASS(Blueprintable)
class KGBATTLESYSTEMEDITOR_API UBSEditorFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

#pragma region Property
public:
	static void CopyStruct(void* DestAddress, void* SrcAddress, UScriptStruct* StructType, UObject* Dest, UObject* Src);

	static void CopyObject(UObject* DestObject, UObject* SrcObject);

	static void CopyData(void* DestAddress, void* SrcAddress, FProperty* DataType, UObject* Dest, UObject* Src);

protected:
	static FString DataTableFindName;

#pragma endregion Property



#pragma region Json
public:
	static void ExportStructToJson(void* DataAddress, UScriptStruct* TheStruct, TSharedPtr<FJsonObject> OutJson, const TArray<UStruct*>& SpecialType, UBSJsonExporter* SpecialExporter = nullptr, FString ExtraString = "");

	static void ExportObjectToJson(UObject* TheObject, TSharedPtr<FJsonObject> OutJson, const TArray<UStruct*>& SpecialType, UBSJsonExporter* SpecialExporter = nullptr, FString ExtraString = "");

	static TSharedPtr<FJsonValue> ExportPropertyToJson(void* DataAddress, FProperty* Prop, const TArray<UStruct*>& SpecialType, UBSJsonExporter* SpecialExporter = nullptr, FString ExtraString = "");

#pragma endregion Json



#pragma region Lua
public:
	static FString FindChineseStringByID(const FString& TableString, int32 ID);

	static void UpdatePropTagList(class UBSEditorLuaBasicGI* GI, bool NeedCheckout = false);

	static void RefreshTagList(FString Key, const TArray<FString>& NewTags, const TArray<FString>& NewNotes, bool NeedCheckout = false);

#pragma endregion Lua



#pragma region Export
public:
	static int32 GetAbilityHeadID(int32 InAbilityID);

	static FString GetAbilityJsonFilePath(int32 InAbilityID, bool bSkill);

	static FString GetAbilityFolderPath(bool bSkill);

	static FString GetCombatTreeFolderPath();

	static FString GetAutoSkillTreeFolderPath();

	static FString GetBeatenTreeFolderPath();

	static FString GetPassiveSkillTreeFolderPath();

	static bool CheckOutByPerforce(FString FilePath);

public:
	static TSharedPtr<FJsonObject> ExportAbilityToJson(class UBSAAsset* InAsset);

	static void ExportCurveData(class UBSEditorLuaBasicGI* GI);

	static void ExportSkillData(class UBSEditorLuaBasicGI* GI, int32 HeadID = -1, int32 ExportType = 0, int32 UpdateID = 0);

	static void ExportBuffData(class UBSEditorLuaBasicGI* GI, int32 HeadID = -1, int32 ExportType = 0, int32 UpdateID = 0);

	static void ExportEnum(bool bNeedCheckOut = false);

	static void ExportCombatTreeData();

	static void ExportAutoSkillTreeData();

	static void ExportBeatenTreeData();

	static void ExportPassiveSkillData();

#pragma endregion Export



#pragma region CheckResource
public:
	static void CheckSkillBuffResouces();

	static void AutoFixSkillBuffResouces();

	static void AutoGenSkillRecoveryStartTime(TArray<int32> SkillIDs);
	static void AutoGenSkillRecoveryStartTime(class UBSASkillAsset* SkillAsset);

protected:
	static TArray<FString> CheckResouces(TArray<FString> InResourceList);

	static bool AutoFixResource(UObject* ObjectToCheck, FString Log);
	
#pragma endregion CheckResource

};
