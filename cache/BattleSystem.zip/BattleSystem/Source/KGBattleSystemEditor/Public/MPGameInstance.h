#pragma once

#include "CoreMinimal.h"

#include "Lua/LuaEnv.h"

#include "Manager/KGBasicManager.h"
#include "Misc/KGGameInstanceBase.h"

#include "MPGameInstance.generated.h"



UCLASS(BlueprintType, Blueprintable)
class KGBATTLESYSTEMEDITOR_API UMPLuaGameInstance : public ULuaGameInstance
{
	GENERATED_BODY()

#pragma region Important
public:
	UFUNCTION(BlueprintImplementableEvent)
	void OnLuaInit(UGameInstance* InGI);

	UFUNCTION(BlueprintImplementableEvent)
	void SetStartLocation(float InX, float InY, float InZ);

	virtual FString GetLuaFilePath_Implementation() const override
	{
		return TEXT("Editor.MPGameInstance");
	}

#pragma endregion Important

};






UCLASS(BlueprintType)
class KGBATTLESYSTEMEDITOR_API UMPGameInstance : public UKGGameInstanceBase
{
	GENERATED_BODY()

public:
	void Init() override;

	FGameInstancePIEResult StartPlayInEditorGameInstance(ULocalPlayer* LocalPlayer, const FGameInstancePIEParameters& Params) override;

	void Shutdown() override;

protected:
    UEditorLuaEnv *LuaEnv = nullptr;

};
