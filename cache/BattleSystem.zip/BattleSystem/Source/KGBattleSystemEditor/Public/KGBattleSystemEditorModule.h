#pragma once

#include "Internationalization/StringTable.h"
#include "Modules/ModuleManager.h"
#include "Toolkits/AssetEditorToolkit.h"


DECLARE_LOG_CATEGORY_EXTERN(LogKGBattleSystemEditor, Log, All);

class FKGBattleSystemEditorModule : public IModuleInterface, public IHasToolBarExtensibility
{

#pragma region Important
public:
	virtual void StartupModule() override;

	virtual void ShutdownModule() override;

	void RegisterToolBarExtensions();

	void UnRegisterToolBarExtensions();
	
	virtual TSharedPtr<FExtensibilityManager> GetToolBarExtensibilityManager() override
	{
		return ToolBarExtensibilityManager;
	}

	/** Holds the tool bar extensibility manager. */
	TSharedPtr<FExtensibilityManager> ToolBarExtensibilityManager;

#pragma endregion Important



#pragma region Enum
public:
	void UpdateCharacterTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext);

	void UpdateCampTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext);

	void UpdateSkillTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext);

	void UpdateAttackTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext);

	void UpdateHitFeedbackTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext);

	void UpdateStaggerStateEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext); 

private:
	void UpdateEnumDisplayName(UEnum* InEnumType, UStringTable* InStringTable);

#pragma endregion Enum
};
