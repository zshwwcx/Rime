#include "KGBattleSystemEditorModule.h"

#include "Core.h"
#include "IAssetTools.h"
#include "AssetToolsModule.h"
#include "IAssetTypeActions.h"
#include "AssetTypeCategories.h"
#include "Internationalization/StringTable.h"
#include "Internationalization/StringTableCore.h"
#include "Modules/ModuleManager.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"
#include "BattleSystemEditor/CustomLayout/BSStructLayout.h"
#include "BattleSystemEditor/CustomLayout/BSATaskLayout.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSABuffAsset.h"
#include "BattleSystemEditor/AbilityEditor/BSAAssetTypeActions.h"
#include "BattleSystemEditor/AbilityEditor/BSAAssetThumbnailRenderer.h"
#include "BattleSystemEditor/DecisionTreeEditor/AssetTypeActions_DecisionTree.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeThumbnailRenderers.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"
#include "BattleSystemEditor/BSEditorFunctionLibrary.h"



#define LOCTEXT_NAMESPACE "FKGBattleSystemEditorModule"

DEFINE_LOG_CATEGORY(LogKGBattleSystemEditor);

#define REG_CUSTOM_PROP_LAYOUT_GENERIC(StructType, CustomLayout) PropertyModule.RegisterCustomPropertyTypeLayout(StructType::StaticStruct()->GetFName(), FOnGetPropertyTypeCustomizationInstance::CreateStatic(&CustomLayout::MakeInstance));

#pragma region Important
void FKGBattleSystemEditorModule::StartupModule()
{
	// 受击树、一键连招还在使用，等迁移到新技能，技能、被动技能策划要看，等策划确定不要之后可以把整个插件直接移除
	IAssetTools& AssetToolsModule = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	EAssetTypeCategories::Type CurrentAssetCategory = EAssetTypeCategories::Type::Gameplay;
	// 注册技能资源
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_BSASkillAsset(CurrentAssetCategory)));
	// 注册BUFF资源  //被动技能用到不少旧buff配置
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_BSABuffAsset(CurrentAssetCategory)));
	// 注册决策树资源
	//AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_DecisionTree(CurrentAssetCategory)));
	// 注册受击树资源
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_BeatenTree(CurrentAssetCategory)));
	// 注册连招表资源
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_CombatTree(CurrentAssetCategory)));
	// 注册一键连招表资源
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_AutoSkillTree(CurrentAssetCategory)));
	// 注册被动技能资源
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_PassiveSkillTree(CurrentAssetCategory)));
	// 注册TaskGroup模板
	//AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_BSATaskTemplateAsset(CurrentAssetCategory)));


	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSATaskSelector, FBSATaskSelectorLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSBeatenPerformance, FBeatenPerformanceLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSSelectTargetInfo, FBSSelectTargetInfoLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSATPP_Int32, FBSATaskParameterizedPropertyLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSATPP_Float, FBSATaskParameterizedPropertyLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSATPP_String, FBSATaskParameterizedPropertyLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSATPP_Vector, FBSATaskParameterizedPropertyLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSATPP_Rotator, FBSATaskParameterizedPropertyLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSATPP_Transform, FBSATaskParameterizedPropertyLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSATransformCreater, FBSATransformCreaterLayout);
	REG_CUSTOM_PROP_LAYOUT_GENERIC(FBSSocketSelector, FBSSocketSelectorLayout);


	// 自定义缩略图
	UThumbnailManager::Get().UnregisterCustomRenderer(UBSASkillAsset::StaticClass());
	UThumbnailManager::Get().RegisterCustomRenderer(UBSASkillAsset::StaticClass(), UBSAAssetThumbnailRenderer::StaticClass());
	UThumbnailManager::Get().UnregisterCustomRenderer(UBSABuffAsset::StaticClass());
	UThumbnailManager::Get().RegisterCustomRenderer(UBSABuffAsset::StaticClass(), UBSAAssetThumbnailRenderer::StaticClass());
	UThumbnailManager::Get().UnregisterCustomRenderer(UDecisionTreeTemplate::StaticClass());
	UThumbnailManager::Get().RegisterCustomRenderer(UDecisionTreeTemplate::StaticClass(), UDecisionTreeThumbnailRenderer::StaticClass());


	// 更新扩展枚举
	FObjectSaveContextData ObjectSaveData;
	FObjectPostSaveContext ObjectSaveContext(ObjectSaveData);
	UPackage::PackageSavedWithContextEvent.AddRaw(this, &FKGBattleSystemEditorModule::UpdateCharacterTypeEnum);
	UpdateCharacterTypeEnum(FString("CharacterType"), nullptr, ObjectSaveContext);
	UPackage::PackageSavedWithContextEvent.AddRaw(this, &FKGBattleSystemEditorModule::UpdateCampTypeEnum);
	UpdateCampTypeEnum(FString("CampType"), nullptr, ObjectSaveContext);
	UPackage::PackageSavedWithContextEvent.AddRaw(this, &FKGBattleSystemEditorModule::UpdateSkillTypeEnum);
	UpdateSkillTypeEnum(FString("SkillType"), nullptr, ObjectSaveContext);
	UPackage::PackageSavedWithContextEvent.AddRaw(this, &FKGBattleSystemEditorModule::UpdateAttackTypeEnum);
	UpdateAttackTypeEnum(FString("AttackType"), nullptr, ObjectSaveContext);
	UPackage::PackageSavedWithContextEvent.AddRaw(this, &FKGBattleSystemEditorModule::UpdateStaggerStateEnum);
	UpdateStaggerStateEnum(FString("StaggerState"), nullptr, ObjectSaveContext);
	UPackage::PackageSavedWithContextEvent.AddRaw(this, &FKGBattleSystemEditorModule::UpdateHitFeedbackTypeEnum);
	UpdateHitFeedbackTypeEnum(FString("HitFeedback"), nullptr, ObjectSaveContext);

	RegisterToolBarExtensions();
}

void FKGBattleSystemEditorModule::ShutdownModule()
{
	UnRegisterToolBarExtensions();
}

void FKGBattleSystemEditorModule::RegisterToolBarExtensions()
{
	ToolBarExtensibilityManager = MakeShareable(new FExtensibilityManager());
}

void FKGBattleSystemEditorModule::UnRegisterToolBarExtensions()
{	
	ToolBarExtensibilityManager.Reset();
}
#pragma endregion Important



#pragma region Enum
void FKGBattleSystemEditorModule::UpdateCharacterTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext)
{
	const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>();

	if (!PackageFileName.Contains("CharacterType") || Setting->CharacterTypeNameTable.IsNull())
		return;

	UEnum* Enum = StaticEnum<EBSCharacterType>();
	check(Enum);

	UpdateEnumDisplayName(Enum, Setting->CharacterTypeNameTable.LoadSynchronous());
}

void FKGBattleSystemEditorModule::UpdateCampTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext)
{
	const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>();

	if (!PackageFileName.Contains("CampType") || Setting->CampTypeNameTable.IsNull())
		return;

	UEnum* Enum = StaticEnum<EBSTargetCampType>();
	check(Enum);

	UpdateEnumDisplayName(Enum, Setting->CampTypeNameTable.LoadSynchronous());
}

void FKGBattleSystemEditorModule::UpdateSkillTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext)
{
	const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>();

	if (!PackageFileName.Contains("SkillType") || Setting->SkillTypeNameTable.IsNull())
		return;

	UEnum* Enum = StaticEnum<EBSASkillType>();
	check(Enum);

	UpdateEnumDisplayName(Enum, Setting->SkillTypeNameTable.LoadSynchronous());
}

void FKGBattleSystemEditorModule::UpdateAttackTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext)
{
	const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>();

	if (!PackageFileName.Contains("AttackType") || Setting->AttackTypeNameTable.IsNull())
		return;

	UEnum* Enum = StaticEnum<EBSAttackType>();
	check(Enum);

	UpdateEnumDisplayName(Enum, Setting->AttackTypeNameTable.LoadSynchronous());
}

void FKGBattleSystemEditorModule::UpdateHitFeedbackTypeEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext)
{
	const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>();

	if (!PackageFileName.Contains("HitFeedback") || Setting->HitFeedbackTypeNameTable.IsNull())
		return;

	UEnum* Enum = StaticEnum<EBSHitFeedbackType>();
	check(Enum);

	UpdateEnumDisplayName(Enum, Setting->HitFeedbackTypeNameTable.LoadSynchronous());
}

void FKGBattleSystemEditorModule::UpdateStaggerStateEnum(const FString& PackageFileName, UPackage* PackageObj, FObjectPostSaveContext InContext)
{
	const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>();

	if (!PackageFileName.Contains("StaggerState") || Setting->StaggerNameTable.IsNull())
		return;

	UEnum* Enum = StaticEnum<EBSStaggerState>();
	check(Enum);

	UpdateEnumDisplayName(Enum, Setting->StaggerNameTable.LoadSynchronous());
}

void FKGBattleSystemEditorModule::UpdateEnumDisplayName(UEnum* InEnumType, UStringTable* InStringTable)
{
	if (!InStringTable)
		return;

	// 取出表格里面的枚举名称
	TArray<FString> KeyNames;	TArray<FString> ShowNames;
	InStringTable->GetStringTable()->EnumerateSourceStrings
	(
		[&](const FString& InKey, const FString& InSourceString) -> bool
		{
			KeyNames.Add(InKey);
			ShowNames.Add(InSourceString);
			return true;
		}
	);


	int32 NumEnum = InEnumType->NumEnums();
	static const FString DisplayNameKey = TEXT("DisplayName");
	static const FString HiddenMeta = TEXT("Hidden");


	// 查找需要覆盖的枚举起始值
	TArray<int32> IndexList;
	for (int32 i = 0; i < NumEnum; ++i)
	{
		FString Name = InEnumType->GetNameStringByIndex(i);

		// 以数字开头的枚举值作为字段表覆盖起始
		if (!Name.IsEmpty() && Name.Contains(TEXT("_BackUp")))
		{
			IndexList.Add(i);
		}
	}

	// 名称初始化
	for (int32 i = 0; i < IndexList.Num(); ++i)
	{
		if (InEnumType->HasMetaData(*DisplayNameKey, IndexList[i]))
		{
			InEnumType->RemoveMetaData(*DisplayNameKey, IndexList[i]);
		}

		if (!InEnumType->HasMetaData(*HiddenMeta, IndexList[i]))
		{
			InEnumType->SetMetaData(*HiddenMeta, *HiddenMeta, IndexList[i]);
		}
	}

	// 更新名称
	for (int32 i = 0; i < KeyNames.Num(); ++i)
	{
		if (IndexList.IsValidIndex(i))
		{
			InEnumType->SetMetaData(*DisplayNameKey, *ShowNames[i], IndexList[i]);

			if (InEnumType->HasMetaData(*HiddenMeta, IndexList[i]))
			{
				InEnumType->RemoveMetaData(*HiddenMeta, IndexList[i]);
			}
		}
	}
}

#pragma endregion Enum

IMPLEMENT_MODULE(FKGBattleSystemEditorModule, KGBattleSystemEditor)

#undef LOCTEXT_NAMESPACE