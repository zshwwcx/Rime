#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeCondition.h"



UBeatenTreeCondition::UBeatenTreeCondition()
{
	Name = TEXT("BeatenTree");
}

bool UBeatenTreeCondition::PerformCheck_Implementation(const FBSConditionData& InData) const
{
	bool Result = true;
	if (UBeatenTreeCollector* CurCollector = Cast<UBeatenTreeCollector>(InData.ObjectArray.Last()))
	{
		if (bCheckStaggerState)
			Result &= (StaggerState & (1 << (int32)CurCollector->StaggerState)) > 0;

		if (bCheckAttackType)
			Result &= (AttackType & (1 << (int32)CurCollector->AttackType)) > 0;

		if (bCheckAttackForce)
			Result &= (AttackForce & (1 << (int32)CurCollector->AttackForce)) > 0;

		if (bCheckRelationType)
			Result &= (RelationType & (1 << (int32)CurCollector->RelationType)) > 0;

	}

	return Result;
}


#if WITH_EDITOR
bool UBeatenTreeCondition::CopyData(UBSCondition* OtherCondition)
{
	if (!Super::CopyData(OtherCondition))
		return false;

	if (UBeatenTreeCondition* OtherHitCondition = Cast<UBeatenTreeCondition>(OtherCondition))
	{
		bCheckStaggerState = OtherHitCondition->bCheckStaggerState;
		StaggerState = OtherHitCondition->StaggerState;

		bCheckAttackType = OtherHitCondition->bCheckAttackType;
		AttackType = OtherHitCondition->AttackType;

		bCheckAttackForce = OtherHitCondition->bCheckAttackForce;
		AttackForce = OtherHitCondition->AttackForce;

		bCheckRelationType = OtherHitCondition->bCheckRelationType;
		RelationType = OtherHitCondition->RelationType;
	}

	return true;
}

FString UBeatenTreeCondition::GetConditionDescription()
{
	FString Result;
	if (bCheckStaggerState)
	{
		UEnum* EnumType = StaticEnum<EBSStaggerState>();

		int32 Num = (int32)EBSStaggerState::SS_TMax;
		for (int32 i = 0; i < Num; ++i)
		{
			if ((StaggerState & (1 << i)) > 0)
			{
				Result += EnumType->GetDisplayNameTextByIndex(i).ToString();
				Result += TEXT(" ");
			}
		}
		Result += TEXT("\n");
	}

	if (bCheckAttackType)
	{
		UEnum* EnumType = StaticEnum<EBSAttackType>();

		int32 Num = (int32)EBSAttackType::AT_TMax;
		for (int32 i = 0; i < Num; ++i)
		{
			if ((AttackType & (1 << i)) > 0)
			{
				Result += EnumType->GetDisplayNameTextByIndex(i).ToString();
				Result += TEXT(" ");
			}
		}
		Result += TEXT("\n");
	}

	if (bCheckAttackForce)
	{
		UEnum* EnumType = StaticEnum<EBSAttackForce>();

		int32 Num = (int32)EBSAttackForce::AF_TMax;
		for (int32 i = 0; i < Num; ++i)
		{
			if ((AttackForce & (1 << i)) > 0)
			{
				Result += EnumType->GetDisplayNameTextByIndex(i).ToString();
				Result += TEXT(" ");
			}
		}
		Result += TEXT("\n");
	}

	if (bCheckRelationType)
	{
		UEnum* EnumType = StaticEnum<EBSAttackerLocationType>();

		int32 Num = (int32)EBSAttackerLocationType::ALT_TMax;
		for (int32 i = 0; i < Num; ++i)
		{
			if ((RelationType & (1 << i)) > 0)
			{
				Result += EnumType->GetDisplayNameTextByIndex(i).ToString();
				Result += TEXT(" ");
			}
		}
		Result += TEXT("\n");
	}

	return Result;
}

#endif