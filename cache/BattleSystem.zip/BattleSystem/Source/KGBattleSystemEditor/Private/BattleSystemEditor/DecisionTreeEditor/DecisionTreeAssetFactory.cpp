#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeAssetFactory.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeTemplate.h"

#include "Modules/ModuleManager.h"
#include "ClassViewerModule.h"
#include "ClassViewerFilter.h"

#include "Widgets/SWindow.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Views/SListView.h"
#include "EditorStyleSet.h"
#include "Input/Reply.h"
#include "Editor.h"



#define LOCTEXT_NAMESPACE "DecisionTreeAssetFactory"



UDecisionTreeAssetFactory::UDecisionTreeAssetFactory(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	bCreateNew = false;
	bEditAfterNew = true;
	SupportedClass = UDecisionTreeTemplate::StaticClass();
}

UDecisionTreeAssetFactory::~UDecisionTreeAssetFactory()
{
	
}

bool UDecisionTreeAssetFactory::ConfigureProperties()
{
	class FDTTypeFilter : public IClassViewerFilter
	{
	public:
		virtual bool IsClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const UClass* InClass, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			return InClass->IsChildOf<UDTTypeMessage>() && !InClass->HasAnyClassFlags(CLASS_Abstract);
		}

		virtual bool IsUnloadedClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const TSharedRef< const IUnloadedBlueprintData > InClass, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			return InClass->IsChildOf(UDTTypeMessage::StaticClass()) && !InClass->HasAnyClassFlags(CLASS_Abstract);
		}
	};

	class FDecisionTreeFactoryUI : public TSharedFromThis<FDecisionTreeFactoryUI>
	{
	public:
		FReply OnCreate()
		{
			if (PickerWindow.IsValid())
			{
				PickerWindow->RequestDestroyWindow();
			}
			return FReply::Handled();
		}

		FReply OnCancel()
		{
			CachedFactory->DTTypeClassType = NULL;

			if (PickerWindow.IsValid())
			{
				PickerWindow->RequestDestroyWindow();
			}
			return FReply::Handled();
		}

		TSharedRef<SWidget> GenerateDTTypePicker()
		{
			FClassViewerModule& ClassViewerModule = FModuleManager::LoadModuleChecked<FClassViewerModule>("ClassViewer");

			FClassViewerInitializationOptions Options;
			Options.Mode = EClassViewerMode::ClassPicker;
			Options.bIsActorsOnly = false;
			Options.bIsBlueprintBaseOnly = false;
			Options.ClassFilters.Add(MakeShared<FDTTypeFilter>());
			Options.ExtraPickerCommonClasses.Add(NULL);

			return SNew(SBox)
				.WidthOverride(330)
				[
					SNew(SVerticalBox)

					+ SVerticalBox::Slot()
					.FillHeight(1.0f)
					.MaxHeight(500)
					[
						SNew(SBorder)
						.Padding(4)
						.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
						[
							ClassViewerModule.CreateClassViewer(Options, FOnClassPicked::CreateSP(this, &FDecisionTreeFactoryUI::OnPickedDTTypeClassType))
						]
					]
				];
		}

		void OpenDecisionTreeConfigurator(UDecisionTreeAssetFactory* TheFactory)
		{
			CachedFactory = TheFactory;

			FClassViewerModule& ClassViewerModule = FModuleManager::LoadModuleChecked<FClassViewerModule>("ClassViewer");

			PickerWindow = SNew(SWindow)
				.Title(LOCTEXT("DecisionTreeConfigurator", "Select Decision Tree Options"))
				.ClientSize(FVector2D(350, 100))
				.SupportsMinimize(false)
				.SupportsMaximize(false)
				[
					SNew(SBorder)
					.BorderImage(FAppStyle::GetBrush("Menu.Background"))
					.Padding(10)
					[
						SNew(SVerticalBox)
						+SVerticalBox::Slot()
						.AutoHeight()
						[
							SAssignNew(DTTypePickerAnchor, SComboButton)
							.ContentPadding(FMargin(2, 2, 2, 1))
							.MenuPlacement(MenuPlacement_BelowAnchor)
							.ButtonContent()
							[
								SNew(STextBlock)
								.Text(this, &FDecisionTreeFactoryUI::OnGetDTTypeTextValue)
							]
							.OnGetMenuContent(this, &FDecisionTreeFactoryUI::GenerateDTTypePicker)
						]

						+SVerticalBox::Slot()
						.AutoHeight()
						[
							SNew(SHorizontalBox)
							+SHorizontalBox::Slot()
							.AutoWidth()
							.HAlign(HAlign_Left)
							[
								SNew(SButton)
								.Text(LOCTEXT("OK", "OK"))
								.OnClicked(this, &FDecisionTreeFactoryUI::OnCreate)
							]

							+ SHorizontalBox::Slot()
							.AutoWidth()
							.HAlign(HAlign_Right)
							[
								SNew(SButton)
								.Text(LOCTEXT("Cancel", "Cancel"))
								.OnClicked(this, &FDecisionTreeFactoryUI::OnCancel)
							]
						]
					]
				];

			GEditor->EditorAddModalWindow(PickerWindow.ToSharedRef());
			PickerWindow.Reset();
		}

	public:
		FText OnGetDTTypeTextValue() const
		{
			FString OutString;

			if (CachedFactory->DTTypeClassType)
			{
				if (UDTTypeMessage* CurDTT = Cast<UDTTypeMessage>(CachedFactory->DTTypeClassType->GetDefaultObject()))
					OutString = TEXT("编辑类型为:") + CurDTT->GetTypeMessageName();
			}
			else
				OutString = TEXT("无效的编辑类型集合!");

			return FText::FromString(*OutString);
		}

		void OnPickedDTTypeClassType(UClass* ChosenClass) const
		{
			CachedFactory->DTTypeClassType = ChosenClass;
		}

	private:
		TSharedPtr<SWindow> PickerWindow;
		TSharedPtr<SComboButton> DTTypePickerAnchor;

		TWeakObjectPtr<UDecisionTreeAssetFactory> CachedFactory;
	};

	TSharedRef<FDecisionTreeFactoryUI> DecisionTreeFactory = MakeShareable(new FDecisionTreeFactoryUI());
	DecisionTreeFactory->OpenDecisionTreeConfigurator(this);


	return true;
};

UObject* UDecisionTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	if (!DTTypeClassType)
		return NULL;

	UDecisionTreeTemplate* NewAsset = NULL;
	NewAsset = NewObject<UDecisionTreeTemplate>(InParent, Class, Name, Flags | RF_Transactional);
	NewAsset->TypeMessage = DTTypeClassType;

	return NewAsset;
}

UObject* UDecisionTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	if (!DTTypeClassType)
		return NULL;

	UDecisionTreeTemplate* NewAsset = NULL;
	NewAsset = NewObject<UDecisionTreeTemplate>(InParent, Class, Name, Flags | RF_Transactional);
	NewAsset->TypeMessage = DTTypeClassType;

	return NewAsset;
}






UBeatenTreeAssetFactory::UBeatenTreeAssetFactory(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	bCreateNew = true;
	bEditAfterNew = true;
	SupportedClass = UBeatenTreeTemplate::StaticClass();
}

UBeatenTreeAssetFactory::~UBeatenTreeAssetFactory()
{

}

bool UBeatenTreeAssetFactory::ConfigureProperties()
{
	return true;
};

UObject* UBeatenTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	UBeatenTreeTemplate* NewAsset = NULL;
	NewAsset = NewObject<UBeatenTreeTemplate>(InParent, Class, Name, Flags | RF_Transactional);

	return NewAsset;
}

UObject* UBeatenTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	return FactoryCreateNew(Class, InParent, Name, Flags, Context, Warn, NAME_None);
}






UCombatTreeAssetFactory::UCombatTreeAssetFactory(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	bCreateNew = true;
	bEditAfterNew = true;
	SupportedClass = UCombatTreeTemplate::StaticClass();
}

UCombatTreeAssetFactory::~UCombatTreeAssetFactory()
{

}

bool UCombatTreeAssetFactory::ConfigureProperties()
{
	return true;
};

UObject* UCombatTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	UCombatTreeTemplate* NewAsset = NULL;
	NewAsset = NewObject<UCombatTreeTemplate>(InParent, Class, Name, Flags | RF_Transactional);

	return NewAsset;
}

UObject* UCombatTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	return FactoryCreateNew(Class, InParent, Name, Flags, Context, Warn, NAME_None);
}






UAutoSkillTreeAssetFactory::UAutoSkillTreeAssetFactory(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	bCreateNew = true;
	bEditAfterNew = true;
	SupportedClass = UAutoSkillTreeTemplate::StaticClass();
}

UAutoSkillTreeAssetFactory::~UAutoSkillTreeAssetFactory()
{

}

bool UAutoSkillTreeAssetFactory::ConfigureProperties()
{
	return true;
};

UObject* UAutoSkillTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	UAutoSkillTreeTemplate* NewAsset = NULL;
	NewAsset = NewObject<UAutoSkillTreeTemplate>(InParent, Class, Name, Flags | RF_Transactional);

	return NewAsset;
}

UObject* UAutoSkillTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	return FactoryCreateNew(Class, InParent, Name, Flags, Context, Warn, NAME_None);
}






UPassiveSkillTreeAssetFactory::UPassiveSkillTreeAssetFactory(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	bCreateNew = true;
	bEditAfterNew = true;
	SupportedClass = UPassiveSkillTreeTemplate::StaticClass();
}

UPassiveSkillTreeAssetFactory::~UPassiveSkillTreeAssetFactory()
{

}

bool UPassiveSkillTreeAssetFactory::ConfigureProperties()
{
	return true;
};

UObject* UPassiveSkillTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	UPassiveSkillTreeTemplate* NewAsset = NULL;
	NewAsset = NewObject<UPassiveSkillTreeTemplate>(InParent, Class, Name, Flags | RF_Transactional);

	return NewAsset;
}

UObject* UPassiveSkillTreeAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	return FactoryCreateNew(Class, InParent, Name, Flags, Context, Warn, NAME_None);
}


#undef LOCTEXT_NAMESPACE
