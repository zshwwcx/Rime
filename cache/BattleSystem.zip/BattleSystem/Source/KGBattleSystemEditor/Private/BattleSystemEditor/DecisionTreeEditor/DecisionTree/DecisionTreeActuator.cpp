#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeActuator.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"



UDTBaseActuator::~UDTBaseActuator()
{
	ClearSubGraphActuators();
}

void UDTBaseActuator::ClearSubGraphActuators()
{
	for (TMap<UDecisionTreeNode*, UDTBaseActuator*>::TIterator It(SubGraphActuatorMap); It; ++It)
	{
		if (It->Value)
		{
			It->Value->ClearSubGraphActuators();
			It->Value->MarkAsGarbage();
		}
	}
	SubGraphActuatorMap.Empty();
}






UDecisionTreeNode* UDecisionTreeActuator::GetBestTreeNode(UObject* InDataObject, UDecisionTreeDataCollector* InDataCollector)
{
	if (!InDataCollector || !InDataObject)
		return NULL;

	CurrentDataObject = InDataObject;
	CurrentDataCollector = InDataCollector;

	TArray<UDecisionTreeNode*> RootList;
	if (UDecisionTreeTemplate* CurTemp = Cast<UDecisionTreeTemplate>(CurrentDataObject))
		RootList.Append(CurTemp->RootNodes);
	else if (UDecisionTreeGraphNode* CurGraphNode = Cast<UDecisionTreeGraphNode>(CurrentDataObject))
		RootList.Append(CurGraphNode->RootNodes);

	UDecisionTreeNode* ResultNode = NULL;
	for (int32 i = 0; i < RootList.Num(); ++i)
	{
		if (RootList[i])
		{
			// 遍历该根节点的决策树
			ResultNode = TravelDecisionTree(RootList[i]);

			if (ResultNode)
				return ResultNode;
		}
	}

	return NULL;
}

UDecisionTreeActuator* UDecisionTreeActuator::GetSubTreeActuator(UDecisionTreeNode* InGraphNode)
{
	UDecisionTreeGraphNode* CurGraphNode = Cast<UDecisionTreeGraphNode>(InGraphNode);
	if (!CurGraphNode)
		return NULL;

	if (UDTBaseActuator** FindRes = SubGraphActuatorMap.Find(CurGraphNode))
		return Cast<UDecisionTreeActuator>(*FindRes);
	else
	{
		if (CurGraphNode->TypeMessage)
		{
			if (UDTTypeMessage* DTT = Cast<UDTTypeMessage>(CurGraphNode->TypeMessage->GetDefaultObject()))
			{
				if (DTT->ActuatorType->IsChildOf<UDecisionTreeActuator>())
				{
					UDTBaseActuator* NewActuator = NewObject<UDTBaseActuator>(this, DTT->ActuatorType);
					SubGraphActuatorMap.Add(CurGraphNode, NewActuator);

					return Cast<UDecisionTreeActuator>(NewActuator);
				}
			}
		}
	}

	return NULL;
}

UDecisionTreeNode* UDecisionTreeActuator::TravelDecisionTree(UDecisionTreeNode* StartNode)
{
	if (!StartNode || !StartNode->CheckConditions(CurrentDataCollector))
		return NULL;

	TArray<UDecisionTreeEdge*> EdgeList;
	if (UDecisionTreeTemplate* CurTemp = Cast<UDecisionTreeTemplate>(CurrentDataObject))
		EdgeList.Append(CurTemp->DecisionTreeEdges);
	else if (UDecisionTreeGraphNode* CurGraphNode = Cast<UDecisionTreeGraphNode>(CurrentDataObject))
		EdgeList.Append(CurGraphNode->DecisionTreeEdges);

	UDecisionTreeNode* Result = StartNode;
	// 遍历从该节点出发的边
	for (int32 i = 0; i < StartNode->OutEdges.Num(); ++i)
	{
		if (EdgeList.IsValidIndex(StartNode->OutEdges[i]))
		{
			UDecisionTreeEdge* CurEdge = EdgeList[StartNode->OutEdges[i]];
			if (CurEdge && CurEdge->CheckConditions(CurrentDataCollector))
			{
				Result = TravelDecisionTree(CurEdge->EndNode);
				if (Result)
					break;
			}
		}
	}

	if (Result)
	{
		// 尝试递归子决策树
		if (UDecisionTreeActuator* DTA = GetSubTreeActuator(Result))
			return DTA->GetBestTreeNode(Result, CurrentDataCollector);

		return Result;
	}

	return NULL;
}

