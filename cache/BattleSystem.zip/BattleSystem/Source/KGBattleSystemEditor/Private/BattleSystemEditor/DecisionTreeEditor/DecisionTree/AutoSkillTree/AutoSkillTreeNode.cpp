#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeNode.h"

#include "KGAbilitySystemEditor/AbilityEditor/Ability/ASASkillAsset.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeNode.h"

#include "BattleSystem/BSFunctionLibrary.h" 
#include "EdGraph/EdGraph.h"


UAutoSkillTreeRootNode::UAutoSkillTreeRootNode()
{
	NodeTitle = FText::FromString(TEXT("Start"));
}

#if WITH_EDITOR
void UAutoSkillTreeRootNode::SetNodeTitle(const FText& NewTitle)
{
	
}

bool UAutoSkillTreeRootNode::CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage)
{
	if (PinInformations.IsValidIndex(SelfPinID) && !PinInformations[SelfPinID].bIsOutput)
	{
		return false;
	}

	return true;
}

bool UAutoSkillTreeRootNode::CanUserDelete() const
{
	return false;
}

#endif






UAutoSkillTreeNode::UAutoSkillTreeNode()
{
}

#if WITH_EDITOR
void UAutoSkillTreeNode::SetNodeTitle(const FText& NewTitle)
{
	// NodeTitle = NewTitle;
	RefreshNodeTitle();
}

void UAutoSkillTreeNode::CopyData(UDecisionTreeNode* OtherNode)
{
	Super::CopyData(OtherNode);

	if (UAutoSkillTreeNode* Other = Cast<UAutoSkillTreeNode>(OtherNode))
	{
		ReleaseSkillAssets.Empty();
		ReleaseSkillAssets.Append(Other->ReleaseSkillAssets);
	}
}

void UAutoSkillTreeNode::RefreshNodeTitle()
{
	FString Title;

	bool bConfigValid = false;
	for (int32 i = 0; i < ReleaseSkillAssets.Num(); i++)
	{
		if (!ReleaseSkillAssets[i].IsNull())
		{
			bConfigValid = true;
			break;
		}
	}

	if (bConfigValid == false)
	{
		Title += TEXT("Need Check! Empty ReleaseSkillAssets !\n");
	}
	else
	{
		Title += TEXT("Release:\n");
		for (int32 i = 0; i < ReleaseSkillAssets.Num(); i++)
		{
			Title += ReleaseSkillAssets[i].GetAssetName();
			if (UASASkillAsset* Skill = ReleaseSkillAssets[i].LoadSynchronous())
			{
				Title += TEXT(" ");
				Title += Skill->Name.ToString();
				Title += TEXT("\n");
			}
		}	
	}
	
	NodeTitle = FText::FromString(Title);
}

void UAutoSkillTreeNode::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	RefreshNodeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UAutoSkillTreeNode::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

bool UAutoSkillTreeNode::CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage)
{
	if (UAutoSkillTreeTemplate* ASTT = Cast<UAutoSkillTreeTemplate>(GetOuter()))
	{
		if (IsValid(ASTT->EdGraph.Get()))
		{
			for (int32 i = 0; i < ASTT->EdGraph->Nodes.Num(); i++)
			{
				if (UEdNode_DecisionTreeNode* EdNode = Cast<UEdNode_DecisionTreeNode>(ASTT->EdGraph->Nodes[i].Get()))
				{
					if (EdNode->GraphNode == this)
					{
						// this被Other连接，this不允许有EGPD_Input的pin
						for (int32 j = 0; j < EdNode->Pins.Num(); j++)
						{
							if (EdNode->Pins[j]->Direction == EGPD_Input && !EdNode->Pins[j]->LinkedTo.IsEmpty())
							{
								return false;
							}
						}
					}
					else if (EdNode->GraphNode == Other)
					{
						// Other连接this，Other不允许有EGPD_Output的pin
						for (int32 j = 0; j < EdNode->Pins.Num(); j++)
						{
							if (EdNode->Pins[j]->Direction == EGPD_Output && !EdNode->Pins[j]->LinkedTo.IsEmpty())
							{
								return false;
							}
						}
					}
				}
			}
		}
	}
	return true;
}

#endif
