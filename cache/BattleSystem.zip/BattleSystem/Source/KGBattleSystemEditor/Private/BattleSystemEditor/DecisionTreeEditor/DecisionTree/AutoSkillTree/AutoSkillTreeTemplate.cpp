#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeExporter.h"



UAutoSkillTreeTypeMessage::UAutoSkillTreeTypeMessage()
{
	bAllowCycle = false;
	ExporterType = UAutoSkillTreeExporter::StaticClass();
	FirstNodeType = UAutoSkillTreeRootNode::StaticClass();
	NeedLoadAssetTypes.Add(UBSASkillAsset::StaticClass());
	DataCollectorType = UDecisionTreeDataCollector::StaticClass();

#if WITH_EDITORONLY_DATA
	NodeTypes.Add(UAutoSkillTreeNode::StaticClass());
	EdgeType = UAutoSkillTreeEdge::StaticClass();
#endif
}
