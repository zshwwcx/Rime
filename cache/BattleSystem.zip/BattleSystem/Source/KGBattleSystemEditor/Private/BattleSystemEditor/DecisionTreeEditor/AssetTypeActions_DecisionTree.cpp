#include "BattleSystemEditor/DecisionTreeEditor/AssetTypeActions_DecisionTree.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditor.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeTemplate.h"
#include "Misc/MessageDialog.h"


#define LOCTEXT_NAMESPACE "AssetTypeActions"

FAssetTypeActions_DecisionTree::FAssetTypeActions_DecisionTree(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{
}

FText FAssetTypeActions_DecisionTree::GetName() const
{
	return LOCTEXT("FAssetTypeActions_DecisionTree", "DecisionTree");
}

FColor FAssetTypeActions_DecisionTree::GetTypeColor() const
{
	return FColor::Green;
}

UClass* FAssetTypeActions_DecisionTree::GetSupportedClass() const
{
	return UDecisionTreeTemplate::StaticClass();
}

void FAssetTypeActions_DecisionTree::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	const EToolkitMode::Type Mode = EditWithinLevelEditor.IsValid() ? EToolkitMode::WorldCentric : EToolkitMode::Standalone;

	for (auto ObjIt = InObjects.CreateConstIterator(); ObjIt; ++ObjIt)
	{
		if (UDecisionTreeTemplate* Template = Cast<UDecisionTreeTemplate>(*ObjIt))
		{
			TSharedRef<FDecisionTreeEditor> NewEditor(new FDecisionTreeEditor());
			NewEditor->InitEditor(Mode, EditWithinLevelEditor, Template);
		}
	}
}

uint32 FAssetTypeActions_DecisionTree::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}

void FAssetTypeActions_DecisionTree::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{
	
}






FAssetTypeActions_BeatenTree::FAssetTypeActions_BeatenTree(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{
}

FText FAssetTypeActions_BeatenTree::GetName() const
{
	return LOCTEXT("FAssetTypeActions_BeatenTree", "BeatenTree");
}

FColor FAssetTypeActions_BeatenTree::GetTypeColor() const
{
	return FColor::Blue;
}

UClass* FAssetTypeActions_BeatenTree::GetSupportedClass() const
{
	return UBeatenTreeTemplate::StaticClass();
}

void FAssetTypeActions_BeatenTree::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	const EToolkitMode::Type Mode = EditWithinLevelEditor.IsValid() ? EToolkitMode::WorldCentric : EToolkitMode::Standalone;

	for (auto ObjIt = InObjects.CreateConstIterator(); ObjIt; ++ObjIt)
	{
		if (UDecisionTreeTemplate* Template = Cast<UDecisionTreeTemplate>(*ObjIt))
		{
			TSharedRef<FDecisionTreeEditor> NewEditor(new FDecisionTreeEditor());
			NewEditor->InitEditor(Mode, EditWithinLevelEditor, Template);
		}
	}
}

uint32 FAssetTypeActions_BeatenTree::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}

void FAssetTypeActions_BeatenTree::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{

}






FAssetTypeActions_CombatTree::FAssetTypeActions_CombatTree(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{
}

FText FAssetTypeActions_CombatTree::GetName() const
{
	return LOCTEXT("FAssetTypeActions_CombatTree", "CombatTree");
}

FColor FAssetTypeActions_CombatTree::GetTypeColor() const
{
	return FColor::Red;
}

UClass* FAssetTypeActions_CombatTree::GetSupportedClass() const
{
	return UCombatTreeTemplate::StaticClass();
}

void FAssetTypeActions_CombatTree::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	const EToolkitMode::Type Mode = EditWithinLevelEditor.IsValid() ? EToolkitMode::WorldCentric : EToolkitMode::Standalone;

	for (auto ObjIt = InObjects.CreateConstIterator(); ObjIt; ++ObjIt)
	{
		if (UDecisionTreeTemplate* Template = Cast<UDecisionTreeTemplate>(*ObjIt))
		{
			TSharedRef<FDecisionTreeEditor> NewEditor(new FDecisionTreeEditor());
			NewEditor->InitEditor(Mode, EditWithinLevelEditor, Template);
		}
	}
}

uint32 FAssetTypeActions_CombatTree::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}

void FAssetTypeActions_CombatTree::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{

}






FAssetTypeActions_AutoSkillTree::FAssetTypeActions_AutoSkillTree(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{
}

FText FAssetTypeActions_AutoSkillTree::GetName() const
{
	return LOCTEXT("FAssetTypeActions_AutoSkillTree", "AutoSkillTree");
}

FColor FAssetTypeActions_AutoSkillTree::GetTypeColor() const
{
	return FColor::White;
}

UClass* FAssetTypeActions_AutoSkillTree::GetSupportedClass() const
{
	return UAutoSkillTreeTemplate::StaticClass();
}

void FAssetTypeActions_AutoSkillTree::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	const EToolkitMode::Type Mode = EditWithinLevelEditor.IsValid() ? EToolkitMode::WorldCentric : EToolkitMode::Standalone;

	for (auto ObjIt = InObjects.CreateConstIterator(); ObjIt; ++ObjIt)
	{
		if (UDecisionTreeTemplate* Template = Cast<UDecisionTreeTemplate>(*ObjIt))
		{
			TSharedRef<FDecisionTreeEditor> NewEditor(new FDecisionTreeEditor());
			NewEditor->InitEditor(Mode, EditWithinLevelEditor, Template);
		}
	}
}

uint32 FAssetTypeActions_AutoSkillTree::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}

void FAssetTypeActions_AutoSkillTree::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{

}






FAssetTypeActions_PassiveSkillTree::FAssetTypeActions_PassiveSkillTree(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{
}

FText FAssetTypeActions_PassiveSkillTree::GetName() const
{
	return LOCTEXT("FAssetTypeActions_PassiveSkillTree", "PassiveSkillTree");
}

FColor FAssetTypeActions_PassiveSkillTree::GetTypeColor() const
{
	return FColor::Black;
}

UClass* FAssetTypeActions_PassiveSkillTree::GetSupportedClass() const
{
	return UPassiveSkillTreeTemplate::StaticClass();
}

void FAssetTypeActions_PassiveSkillTree::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	const bool bIsInPIEOrSimulate = GEditor->PlayWorld || GEditor->bIsSimulatingInEditor;
	if(bIsInPIEOrSimulate)
	{
		FText DialogText = LOCTEXT("PassiveSkillTree Error !", "与“PIE模式”或“场景编辑模式”冲突，请关闭后再打开技能编辑器");
		EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::Ok, DialogText);
		return;
	}
	const EToolkitMode::Type Mode = EditWithinLevelEditor.IsValid() ? EToolkitMode::WorldCentric : EToolkitMode::Standalone;

	for (auto ObjIt = InObjects.CreateConstIterator(); ObjIt; ++ObjIt)
	{
		if (UDecisionTreeTemplate* Template = Cast<UDecisionTreeTemplate>(*ObjIt))
		{
			TSharedRef<FDecisionTreeEditor> NewEditor(new FDecisionTreeEditor());
			NewEditor->InitEditor(Mode, EditWithinLevelEditor, Template);
		}
	}
}

uint32 FAssetTypeActions_PassiveSkillTree::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}

void FAssetTypeActions_PassiveSkillTree::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{

}


#undef LOCTEXT_NAMESPACE