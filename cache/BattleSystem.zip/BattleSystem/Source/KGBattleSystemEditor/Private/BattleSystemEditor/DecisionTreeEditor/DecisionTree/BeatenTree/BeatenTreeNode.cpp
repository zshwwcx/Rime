#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeNode.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystem/BSFunctionLibrary.h" 



UBeatenTreeNode::UBeatenTreeNode()
{

}

#if WITH_EDITOR
void UBeatenTreeNode::SetNodeTitle(const FText& NewTitle)
{
	NodeTitle = NewTitle;
}

void UBeatenTreeNode::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{


	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBeatenTreeNode::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{


	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

#endif
