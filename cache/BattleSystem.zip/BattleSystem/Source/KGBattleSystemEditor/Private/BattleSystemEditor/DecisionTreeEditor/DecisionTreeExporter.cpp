#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeExporter.h"

#include "Misc/LowLevelFunctions.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeCondition.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeTemplate.h"

#include "BattleSystemEditor/AbilityEditor/BSAJsonExporter.h"



FString UBeatenTreeExporter::ExportDecisionTree(UDecisionTreeTemplate* InTemp)
{
	FString Result;
	TArray<TSharedPtr<FJsonValue>> JsonValues;
	TSharedPtr<TJsonWriter<TCHAR>> JsonWriter;
	TSharedPtr<FJsonObject> NewJsonObject = MakeShareable(new FJsonObject());
	if (UBeatenTreeTemplate* BTT = Cast<UBeatenTreeTemplate>(InTemp))
	{
		// 获取所有节点
		TArray<UDecisionTreeNode*> AllNodes;
		for (int32 i = 0; i < BTT->DecisionTreeEdges.Num(); ++i)
		{
			if (!BTT->DecisionTreeEdges[i])
				continue;

			AllNodes.AddUnique(BTT->DecisionTreeEdges[i]->StartNode);
			AllNodes.AddUnique(BTT->DecisionTreeEdges[i]->EndNode);
		}

		
		// 导出节点数据
		JsonValues.Empty();
		for (int32 i = 0; i < AllNodes.Num(); ++i)
		{
			UBeatenTreeNode* BTN = Cast<UBeatenTreeNode>(AllNodes[i]);
			if (!BTN)
			{
				continue;
			}

			TSharedPtr<FJsonObject> NewNode = MakeShareable(new FJsonObject());
			
			// 受击反馈ID
			NewNode->SetNumberField(TEXT("HitFeedbackID"), InTemp->ID * 1000 + i + 1);

			// 受击反馈类型
			NewNode->SetNumberField(TEXT("HitFeedbackType"), (int32)BTN->HitFeedbackType);

			// 受击方位
			NewNode->SetNumberField(TEXT("HitLocationType"), (int32)BTN->HitLocationType);

			// 定制受击参数
			if (!BTN->CustomHFParams.IsEmpty())
			{
				TSharedPtr<FJsonObject> CustomHFParamsJO = MakeShareable(new FJsonObject());
				for (TMap<FString, float>::TIterator It(BTN->CustomHFParams); It; ++It)
				{
					CustomHFParamsJO->SetNumberField(It.Key(), It.Value());
				}
				NewNode->SetField(TEXT("CustomHFParams"), MakeShared<FJsonValueObject>(CustomHFParamsJO));
			}

			// 曲线
			if (FRichCurve* CurCurve = BTN->MotionCurve.Curve.GetRichCurve())
			{
				if (CurCurve->GetNumKeys() > 0)
				{
					TSharedPtr<FJsonObject> NewCurve = MakeShareable(new FJsonObject());
					NewCurve->SetNumberField(TEXT("GID"), ULowLevelFunctions::GetGlobalUniqueID());
					NewCurve->SetBoolField(TEXT("bNeedRemap"), BTN->MotionCurve.bNeedRemap);
					TArray<TSharedPtr<FJsonValue>> JsonArray;
					int32 KeyNum = CurCurve->Keys.Num();
					for (int32 j = 0; j < KeyNum; ++j)
					{
						TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
						UBSEditorFunctionLibrary::ExportStructToJson(&CurCurve->Keys[j], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

						JsonArray.Add(MakeShared<FJsonValueObject>(NewObject));
					}
					NewCurve->SetArrayField(TEXT("Keys"), JsonArray);
					NewNode->SetField(TEXT("MotionCurve"), MakeShared<FJsonValueObject>(NewCurve));
				}
			}

			// 出边
			TArray<TSharedPtr<FJsonValue>> EdgeValues;
			for (int32 j = 0; j < BTN->OutEdges.Num(); ++j)
			{
				EdgeValues.Add(MakeShareable(new FJsonValueNumber(BTN->OutEdges[j] + 1)));
			}
			NewNode->SetField(TEXT("OutEdges"), MakeShared<FJsonValueArray>(EdgeValues));

			// 入边
			EdgeValues.Empty();
			for (int32 j = 0; j < BTN->InEdges.Num(); ++j)
			{
				EdgeValues.Add(MakeShareable(new FJsonValueNumber(BTN->InEdges[j] + 1)));
			}
			NewNode->SetField(TEXT("InEdges"), MakeShared<FJsonValueArray>(EdgeValues));

			JsonValues.Add(MakeShared<FJsonValueObject>(NewNode));
		}
		NewJsonObject->SetField(TEXT("Nodes"), MakeShared<FJsonValueArray>(JsonValues));


		// 导出边数据
		JsonValues.Empty();
		for (int32 i = 0; i < BTT->DecisionTreeEdges.Num(); ++i)
		{
			if (!BTT->DecisionTreeEdges[i])
			{
				continue;
			}

			TSharedPtr<FJsonObject> NewEdge = MakeShareable(new FJsonObject());
			NewEdge->SetField(TEXT("StartNode"), MakeShared<FJsonValueNumber>(AllNodes.Find(BTT->DecisionTreeEdges[i]->StartNode) + 1));
			NewEdge->SetField(TEXT("EndNode"), MakeShared<FJsonValueNumber>(AllNodes.Find(BTT->DecisionTreeEdges[i]->EndNode) + 1));

			if (BTT->DecisionTreeEdges[i]->ConditionGroup)
			{
				if (BTT->DecisionTreeEdges[i]->ConditionGroup->ConditionList.Num() <= 0)
				{
					NewEdge->SetNumberField(TEXT("Condition"), 0xFFFFFFFF);
				}
				else
				{
					if (UBeatenTreeCondition* BTC = Cast<UBeatenTreeCondition>(BTT->DecisionTreeEdges[i]->ConditionGroup->ConditionList[0]))
					{
						if (BTC->bCheckStaggerState)
						{
							NewEdge->SetNumberField(TEXT("Condition"), BTC->StaggerState);
						}
						else if (BTC->bCheckAttackType)
						{
							NewEdge->SetNumberField(TEXT("Condition"), BTC->AttackType);
						}
						else if (BTC->bCheckAttackForce)
						{
							NewEdge->SetNumberField(TEXT("Condition"), BTC->AttackForce);
						}
						else
						{
							NewEdge->SetNumberField(TEXT("Condition"), BTC->RelationType);
						}
					}
					else
					{
						NewEdge->SetNumberField(TEXT("Condition"), 0xFFFFFFFF);
					}
				}
			}

			JsonValues.Add(MakeShared<FJsonValueObject>(NewEdge));
		}
		NewJsonObject->SetField(TEXT("Edges"), MakeShared<FJsonValueArray>(JsonValues));


		// 导出根节点数据
		JsonValues.Empty();
		for (int32 i = 0; i < BTT->RootNodes.Num(); ++i)
		{
			if (!BTT->RootNodes[i])
			{
				continue;
			}

			JsonValues.Add(MakeShared<FJsonValueNumber>(AllNodes.Find(BTT->RootNodes[i]) + 1));
		}
		NewJsonObject->SetField(TEXT("RootNodes"), MakeShared<FJsonValueArray>(JsonValues));
	}

	JsonValues.Empty();
	JsonValues.Add(MakeShared<FJsonValueObject>(NewJsonObject));

	JsonWriter = TJsonWriterFactory<TCHAR>::Create(&Result);
	FJsonSerializer::Serialize(JsonValues, *JsonWriter);

	return JsonStringToLuaString(Result, InTemp->ID, TEXT("BSBT"));
}






FString UCombatTreeExporter::ExportDecisionTree(UDecisionTreeTemplate* InTemp)
{
	FString Result;
	TArray<TSharedPtr<FJsonValue>> JsonValues;
	TSharedPtr<TJsonWriter<TCHAR>> JsonWriter;
	TSharedPtr<FJsonObject> NewJsonObject = MakeShareable(new FJsonObject());

	if (UCombatTreeTemplate* CTT = Cast<UCombatTreeTemplate>(InTemp))
	{
		// 导出模板ID
		NewJsonObject->SetField(TEXT("ID"), MakeShared<FJsonValueNumber>(InTemp->ID));


		// 获取所有节点
		TArray<UDecisionTreeNode*> AllNodes;
		for (int32 i = 0; i < CTT->DecisionTreeEdges.Num(); ++i)
		{
			if (!CTT->DecisionTreeEdges[i])
				continue;

			AllNodes.AddUnique(CTT->DecisionTreeEdges[i]->StartNode);
			AllNodes.AddUnique(CTT->DecisionTreeEdges[i]->EndNode);
		}
		
		
		// 导出节点数据
		for (int32 i = 0; i < AllNodes.Num(); ++i)
		{
			UDecisionTreeNode* DTN = AllNodes[i];
			if (!DTN)
			{
				continue;
			}

			TSharedPtr<FJsonObject> NewNode = MakeShareable(new FJsonObject());
			
			if (UCombatTreeNode* CTN = Cast<UCombatTreeNode>(AllNodes[i]))
			{
				// 技能ID
				NewNode->SetField(TEXT("SkillID"), MakeShared<FJsonValueNumber>(FCString::Atoi(*CTN->ReleaseSkillAsset.GetAssetName())));
				// 检查技能释放条件
				NewNode->SetBoolField(TEXT("bCheckReleaseCondition"), CTN->bCheckReleaseCondition);
				// AI技能释放条件
				NewNode->SetBoolField(TEXT("bFinishWhenRecover"), CTN->bFinishWhenRecover);
			}

			// 出边
			TArray<TSharedPtr<FJsonValue>> EdgeValues;
			for (int32 j = 0; j < DTN->OutEdges.Num(); ++j)
			{
				EdgeValues.Add(MakeShareable(new FJsonValueNumber(DTN->OutEdges[j] + 1)));
			}
			NewNode->SetField(TEXT("OutEdges"), MakeShared<FJsonValueArray>(EdgeValues));

			// 入边
			EdgeValues.Empty();
			for (int32 j = 0; j < DTN->InEdges.Num(); ++j)
			{
				EdgeValues.Add(MakeShareable(new FJsonValueNumber(DTN->InEdges[j] + 1)));
			}
			NewNode->SetField(TEXT("InEdges"), MakeShared<FJsonValueArray>(EdgeValues));

			JsonValues.Add(MakeShared<FJsonValueObject>(NewNode));
		}
		NewJsonObject->SetField(TEXT("Nodes"), MakeShared<FJsonValueArray>(JsonValues));


		// 导出边数据
		JsonValues.Empty();
		for (int32 i = 0; i < CTT->DecisionTreeEdges.Num(); ++i)
		{
			UCombatTreeEdge* CTE = Cast<UCombatTreeEdge>(CTT->DecisionTreeEdges[i]);
			if (!CTE)
				continue;

			TSharedPtr<FJsonObject> NewEdge = MakeShareable(new FJsonObject());
			NewEdge->SetField(TEXT("StartNode"), MakeShared<FJsonValueNumber>(AllNodes.Find(CTT->DecisionTreeEdges[i]->StartNode) + 1));
			NewEdge->SetField(TEXT("EndNode"), MakeShared<FJsonValueNumber>(AllNodes.Find(CTT->DecisionTreeEdges[i]->EndNode) + 1));

			TArray<TSharedPtr<FJsonValue>> JsonArray;
			for (int32 j = 0; j < CTE->ComboWindows.Num(); ++j)
			{
				JsonArray.Add(MakeShared<FJsonValueNumber>(FCString::Atoi(*CTE->ComboWindows[j].GetAssetName())));
			}
			NewEdge->SetArrayField(TEXT("ComboWindows"), JsonArray);

			JsonValues.Add(MakeShared<FJsonValueObject>(NewEdge));
		}
		NewJsonObject->SetField(TEXT("Edges"), MakeShared<FJsonValueArray>(JsonValues));


		// 导出根节点数据
		JsonValues.Empty();
		for (int32 i = 0; i < CTT->RootNodes.Num(); ++i)
		{
			if (!CTT->RootNodes[i])
				continue;

			JsonValues.Add(MakeShared<FJsonValueNumber>(AllNodes.Find(CTT->RootNodes[i]) + 1));
		}
		NewJsonObject->SetField(TEXT("RootNodes"), MakeShared<FJsonValueArray>(JsonValues));
	}

	JsonValues.Empty();
	JsonValues.Add(MakeShared<FJsonValueObject>(NewJsonObject));

	JsonWriter = TJsonWriterFactory<TCHAR>::Create(&Result);
	FJsonSerializer::Serialize(JsonValues, *JsonWriter);

	return JsonStringToLuaString(Result, InTemp->ID, TEXT("BSCT"));
}






FString UAutoSkillTreeExporter::ExportDecisionTree(UDecisionTreeTemplate* InTemp)
{
	FString Result;
	TArray<TSharedPtr<FJsonValue>> JsonValues;
	TSharedPtr<TJsonWriter<TCHAR>> JsonWriter;
	TSharedPtr<FJsonObject> NewJsonObject = MakeShareable(new FJsonObject());

	if (UAutoSkillTreeTemplate* ASTT = Cast<UAutoSkillTreeTemplate>(InTemp))
	{
		// 导出模板ID
		NewJsonObject->SetField(TEXT("ID"), MakeShared<FJsonValueNumber>(InTemp->ID));


		// 获取所有节点
		TArray<UDecisionTreeNode*> AllNodes;
		for (int32 i = 0; i < ASTT->DecisionTreeEdges.Num(); ++i)
		{
			if (!ASTT->DecisionTreeEdges[i])
				continue;

			AllNodes.AddUnique(ASTT->DecisionTreeEdges[i]->StartNode);
			AllNodes.AddUnique(ASTT->DecisionTreeEdges[i]->EndNode);
		}


		// 导出节点数据
		for (int32 i = 0; i < AllNodes.Num(); ++i)
		{
			UDecisionTreeNode* DTN = AllNodes[i];
			if (!DTN)
			{
				continue;
			}

			TSharedPtr<FJsonObject> NewNode = MakeShareable(new FJsonObject());

			if (UAutoSkillTreeNode* CTN = Cast<UAutoSkillTreeNode>(AllNodes[i]))
			{
				// 技能ID
				TArray<TSharedPtr<FJsonValue>> SkillIDsValues;
				for (int32 j = 0; j < CTN->ReleaseSkillAssets.Num(); j++)
				{
					SkillIDsValues.Add(MakeShareable(new FJsonValueNumber(FCString::Atoi(*CTN->ReleaseSkillAssets[j].GetAssetName()))));
				}				
				NewNode->SetField(TEXT("SkillIDs"), MakeShared<FJsonValueArray>(SkillIDsValues));

			}

			// 出边
			TArray<TSharedPtr<FJsonValue>> EdgeValues;
			for (int32 j = 0; j < DTN->OutEdges.Num(); ++j)
			{
				EdgeValues.Add(MakeShareable(new FJsonValueNumber(DTN->OutEdges[j] + 1)));
			}
			NewNode->SetField(TEXT("OutEdges"), MakeShared<FJsonValueArray>(EdgeValues));

			// 入边
			EdgeValues.Empty();
			for (int32 j = 0; j < DTN->InEdges.Num(); ++j)
			{
				EdgeValues.Add(MakeShareable(new FJsonValueNumber(DTN->InEdges[j] + 1)));
			}
			NewNode->SetField(TEXT("InEdges"), MakeShared<FJsonValueArray>(EdgeValues));

			JsonValues.Add(MakeShared<FJsonValueObject>(NewNode));
		}
		NewJsonObject->SetField(TEXT("Nodes"), MakeShared<FJsonValueArray>(JsonValues));


		// 导出边数据
		JsonValues.Empty();
		for (int32 i = 0; i < ASTT->DecisionTreeEdges.Num(); ++i)
		{
			UAutoSkillTreeEdge* ASTE = Cast<UAutoSkillTreeEdge>(ASTT->DecisionTreeEdges[i]);
			if (!ASTE)
				continue;

			TSharedPtr<FJsonObject> NewEdge = MakeShareable(new FJsonObject());
			NewEdge->SetField(TEXT("StartNode"), MakeShared<FJsonValueNumber>(AllNodes.Find(ASTT->DecisionTreeEdges[i]->StartNode) + 1));
			NewEdge->SetField(TEXT("EndNode"), MakeShared<FJsonValueNumber>(AllNodes.Find(ASTT->DecisionTreeEdges[i]->EndNode) + 1));

			TSharedPtr<FJsonObject> CurObj = MakeShareable(new FJsonObject());
			UBSJsonExporter* JsonExporter = NewObject<UBSJsonExporter>(GetTransientPackage(), UBSAJsonExporter::StaticClass());
			if (UAutoSkillTreeConditionGroup* Condition = Cast<UAutoSkillTreeConditionGroup>(ASTE->AutoSkillConditionGroup))
			{
				UBSEditorFunctionLibrary::ExportObjectToJson(Condition, CurObj, TArray<UStruct*>{}, JsonExporter);
				NewEdge->SetField(TEXT("Conditions"), MakeShared<FJsonValueObject>(CurObj));
			}

			JsonValues.Add(MakeShared<FJsonValueObject>(NewEdge));
		}
		NewJsonObject->SetField(TEXT("Edges"), MakeShared<FJsonValueArray>(JsonValues));


		// 导出根节点数据
		JsonValues.Empty();
		for (int32 i = 0; i < ASTT->RootNodes.Num(); ++i)
		{
			if (!ASTT->RootNodes[i])
				continue;

			JsonValues.Add(MakeShared<FJsonValueNumber>(AllNodes.Find(ASTT->RootNodes[i]) + 1));
		}
		NewJsonObject->SetField(TEXT("RootNodes"), MakeShared<FJsonValueArray>(JsonValues));
	}

	JsonValues.Empty();
	JsonValues.Add(MakeShared<FJsonValueObject>(NewJsonObject));

	JsonWriter = TJsonWriterFactory<TCHAR>::Create(&Result);
	FJsonSerializer::Serialize(JsonValues, *JsonWriter);

	return JsonStringToLuaString(Result, InTemp->ID, TEXT("BSAST"));
}






FString UPassiveSkillTreeExporter::ExportDecisionTree(UDecisionTreeTemplate* InTemp)
{
	FString Result;
	TArray<TSharedPtr<FJsonValue>> JsonValues;
	TSharedPtr<TJsonWriter<TCHAR>> JsonWriter;
	TSharedPtr<FJsonObject> NewJsonObject = MakeShareable(new FJsonObject());

	if (UPassiveSkillTreeTemplate* CTT = Cast<UPassiveSkillTreeTemplate>(InTemp))
	{
		// 导出模板ID
		NewJsonObject->SetField(TEXT("ID"), MakeShared<FJsonValueNumber>(InTemp->ID));
		NewJsonObject->SetField(TEXT("PermanentPassive"), MakeShared<FJsonValueBoolean>(CTT->PermanentPassive));
		NewJsonObject->SetField(TEXT("CheckNotInSkillSlot"), MakeShared<FJsonValueBoolean>(CTT->CheckNotInSkillSlot));

		// 获取所有节点
		TArray<UDecisionTreeNode*> AllNodes;
		for (int32 i = 0; i < CTT->DecisionTreeEdges.Num(); ++i)
		{
			if (!CTT->DecisionTreeEdges[i])
				continue;

			AllNodes.AddUnique(CTT->DecisionTreeEdges[i]->StartNode);
			AllNodes.AddUnique(CTT->DecisionTreeEdges[i]->EndNode);
		}

		TArray<TSharedPtr<FJsonValue>> EventIndexValues;
		TArray<TSharedPtr<FJsonValue>> DirectTaskValues;
		TSharedPtr<FJsonObject> ExtraData = MakeShareable(new FJsonObject());
		// 导出节点数据
		for (int32 i = 0; i < AllNodes.Num(); ++i)
		{
			TArray<TSharedPtr<FJsonValue>> TaskValues;
			TArray<TSharedPtr<FJsonValue>> ConditionValues;
			TArray<TSharedPtr<FJsonValue>> EventValues;
			UDecisionTreeNode* DTN = AllNodes[i];
			if (!DTN)
			{
				continue;
			}

			TSharedPtr<FJsonObject> NewNode = MakeShareable(new FJsonObject());

			// 出边
			TArray<TSharedPtr<FJsonValue>> EdgeValues;
			for (int32 j = 0; j < DTN->OutEdges.Num(); ++j)
			{
				EdgeValues.Add(MakeShareable(new FJsonValueNumber(DTN->OutEdges[j] + 1)));
			}
			NewNode->SetField(TEXT("OutEdges"), MakeShared<FJsonValueArray>(EdgeValues));

			// 入边
			EdgeValues.Empty();
			for (int32 j = 0; j < DTN->InEdges.Num(); ++j)
			{
				EdgeValues.Add(MakeShareable(new FJsonValueNumber(DTN->InEdges[j] + 1)));
			}
			NewNode->SetField(TEXT("InEdges"), MakeShared<FJsonValueArray>(EdgeValues));


			TSharedPtr<FJsonObject> CurObj = MakeShareable(new FJsonObject());
			TSharedPtr<FJsonObject> IndexObj = MakeShareable(new FJsonObject());
			CurObj->SetField(TEXT("NodeIndex"), MakeShared<FJsonValueNumber>(i + 1));
			UBSJsonExporter* JsonExporter = NewObject<UBSJsonExporter>(GetTransientPackage(), UBSAJsonExporter::StaticClass());
			if (UPassiveSkillCondtionNode* ConditionNode = Cast<UPassiveSkillCondtionNode>(DTN))
			{
				UBSEditorFunctionLibrary::ExportObjectToJson(ConditionNode, CurObj, TArray<UStruct*>{}, JsonExporter);
				ConditionValues.Add(MakeShared<FJsonValueObject>(CurObj));
				NewNode->SetField(TEXT("Conditions"), MakeShared<FJsonValueArray>(ConditionValues));
				NewNode->SetField(TEXT("NodeType"), MakeShared<FJsonValueString>("Conditions"));
			}
			else if (UPassiveSkillEventNode* EventNode = Cast<UPassiveSkillEventNode>(DTN))
			{
				IndexObj->SetField(TEXT("NodeIndex"), MakeShared<FJsonValueNumber>(i + 1));
				EventIndexValues.Add(MakeShared<FJsonValueObject>(IndexObj));
				UBSEditorFunctionLibrary::ExportObjectToJson(EventNode, CurObj, TArray<UStruct*>{}, JsonExporter);
				EventValues.Add(MakeShared<FJsonValueObject>(CurObj));
				NewNode->SetField(TEXT("Events"), MakeShared<FJsonValueArray>(EventValues));
				NewNode->SetField(TEXT("NodeType"), MakeShared<FJsonValueString>("Events"));
			}
			else if (UPassiveSkillTaskNode* TaskNode = Cast<UPassiveSkillTaskNode>(DTN))
			{
				bool IsRootTask = true;
				UBSEditorFunctionLibrary::ExportObjectToJson(TaskNode, CurObj, TArray<UStruct*>{}, JsonExporter);
				for (int32 k = 0; k < CTT->DecisionTreeEdges.Num(); ++k)
				{
					if (!CTT->DecisionTreeEdges[k])
						continue;
					if (CTT->DecisionTreeEdges[k]->EndNode == DTN)
					{
						IsRootTask = false;
						break;
					}
				}
				TaskValues.Add(MakeShared<FJsonValueObject>(CurObj));
				if (IsRootTask)
				{
					DirectTaskValues.Add(MakeShared<FJsonValueNumber>(i + 1));
				}
				NewNode->SetField(TEXT("Tasks"), MakeShared<FJsonValueArray>(TaskValues));
				NewNode->SetField(TEXT("NodeType"), MakeShared<FJsonValueString>("Tasks"));
			}
			JsonValues.Add(MakeShared<FJsonValueObject>(NewNode));
		}
		ExtraData->SetField(TEXT("Events"), MakeShared<FJsonValueArray>(EventIndexValues));
		ExtraData->SetField(TEXT("DirectTasks"), MakeShared<FJsonValueArray>(DirectTaskValues));
		NewJsonObject->SetField(TEXT("Nodes"), MakeShared<FJsonValueArray>(JsonValues));
		NewJsonObject->SetField(TEXT("PassvieData"), MakeShared<FJsonValueObject>(ExtraData));

		// 导出边数据
		JsonValues.Empty();
		for (int32 i = 0; i < CTT->DecisionTreeEdges.Num(); ++i)
		{
			UPassiveSkillTreeEdge* CTE = Cast<UPassiveSkillTreeEdge>(CTT->DecisionTreeEdges[i]);
			if (!CTE)
				continue;

			TSharedPtr<FJsonObject> NewEdge = MakeShareable(new FJsonObject());
			NewEdge->SetField(TEXT("StartNode"), MakeShared<FJsonValueNumber>(AllNodes.Find(CTT->DecisionTreeEdges[i]->StartNode) + 1));
			NewEdge->SetField(TEXT("EndNode"), MakeShared<FJsonValueNumber>(AllNodes.Find(CTT->DecisionTreeEdges[i]->EndNode) + 1));
			NewEdge->SetField(TEXT("IsTrue"), MakeShared<FJsonValueBoolean>(CTE->IsTrue));
			JsonValues.Add(MakeShared<FJsonValueObject>(NewEdge));
		}
		NewJsonObject->SetField(TEXT("Edges"), MakeShared<FJsonValueArray>(JsonValues));


		// 导出根节点数据
		JsonValues.Empty();
		for (int32 i = 0; i < CTT->RootNodes.Num(); ++i)
		{
			if (!CTT->RootNodes[i])
				continue;

			JsonValues.Add(MakeShared<FJsonValueNumber>(AllNodes.Find(CTT->RootNodes[i]) + 1));
		}
		NewJsonObject->SetField(TEXT("RootNodes"), MakeShared<FJsonValueArray>(JsonValues));
	}

	JsonValues.Empty();
	JsonValues.Add(MakeShared<FJsonValueObject>(NewJsonObject));

	JsonWriter = TJsonWriterFactory<TCHAR>::Create(&Result);
	FJsonSerializer::Serialize(JsonValues, *JsonWriter);
	return JsonStringToLuaString(Result, InTemp->ID, TEXT("BSAPS"));
}
