#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeNode.h"



bool UDecisionTreeEdge::CheckConditions(UDecisionTreeDataCollector* InDataCollector)
{
	if (ConditionGroup)
		return ConditionGroup->CheckCondition(FBSConditionData(InDataCollector));
	else
		return true;
}




#if WITH_EDITOR
void UDecisionTreeEdge::ConstructEdge()
{
	RefreshEdgeTitle();
}

void UDecisionTreeEdge::CopyData(UDecisionTreeEdge* OtherEdge)
{
	if (!OtherEdge)
		return;

	if (OtherEdge->ConditionGroup)
	{
		ConditionGroup = NewObject<UDecisionTreeConditionGroup>(this, OtherEdge->ConditionGroup->GetClass());
		ConditionGroup->CopyData(OtherEdge->ConditionGroup);
	}

	RefreshEdgeTitle();
}

void UDecisionTreeEdge::RefreshEdgeTitle()
{
	if (ConditionGroup)
	{
		EdgeTitle = FText::FromString(ConditionGroup->GetConditionDescription());
	}
}

FText UDecisionTreeEdge::GetEdgeTitle() const
{
	return EdgeTitle;
}

void UDecisionTreeEdge::SetEdgeTitle(const FText& NewTitle)
{
	EdgeTitle = NewTitle;
}

void UDecisionTreeEdge::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	RefreshEdgeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif

