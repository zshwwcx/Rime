#include "BattleSystemEditor/DecisionTreeEditor/EdGraph_DecisionTree.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"
#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeEdge.h"

UEdGraph_DecisionTree::UEdGraph_DecisionTree()
{

}

UEdGraph_DecisionTree::~UEdGraph_DecisionTree()
{

}

bool UEdGraph_DecisionTree::Modify(bool bAlwaysMarkDirty)
{
	bool Rtn = Super::Modify(bAlwaysMarkDirty);

	GetOuter()->Modify();

	for (int32 i = 0; i < Nodes.Num(); ++i)
		Nodes[i]->Modify();

	return Rtn;
}

void UEdGraph_DecisionTree::Clear()
{
	Nodes.Empty();
}

void UEdGraph_DecisionTree::PostEditUndo()
{
	Super::PostEditUndo();

	NotifyGraphChanged();
}

