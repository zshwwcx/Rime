#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeTemplate.h"




#if WITH_EDITOR
void UDecisionTreeTemplate::InitByEditor()
{
	return;
}

void UDecisionTreeTemplate::InitSaver()
{
	EditedNodes.Empty();

	RootNodes.Empty(50);
	DecisionTreeEdges.Empty(100);
}

void UDecisionTreeTemplate::AddEdgeMessage(UDecisionTreeNode* InFromNode, UDecisionTreeNode* InToNode, UDecisionTreeEdge* InEdge)
{
	if (!InFromNode || !InToNode || !InEdge)
		return;

	if (!EditedNodes.Contains(InFromNode))
	{
		InFromNode->OutEdges.Empty(5);
		InFromNode->InEdges.Empty(5);

		EditedNodes.Add(InFromNode);
	}

	if (!EditedNodes.Contains(InToNode))
	{
		InToNode->OutEdges.Empty(5);
		InToNode->InEdges.Empty(5);

		EditedNodes.Add(InToNode);
	}

	InEdge->StartNode = InFromNode;
	InEdge->EndNode = InToNode;

	// 将该条边添加到数组中
	DecisionTreeEdges.Add(InEdge);

	InFromNode->OutEdges.Add(DecisionTreeEdges.Num() - 1);
	InToNode->InEdges.Add(DecisionTreeEdges.Num() - 1);
	InEdge->RefreshEdgeTitle();
}

void UDecisionTreeTemplate::RefreshLogicMessage()
{
	return;
}

#endif