#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeAssetManager.h"

#include "Misc/FileHelper.h"
#include "Modules/ModuleManager.h"
#include "UObject/UObjectIterator.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "SourceControlHelpers.h"
#include "HAL/PlatformFileManager.h"

#include "BattleSystemEditor/BSEditorFunctionLibrary.h"



void UDecisionTreeAssetManager::Init()
{
	bActive = true;

	AddToRoot();

	if (!CombatTreeExporter)
	{
		CombatTreeExporter = NewObject<UCombatTreeExporter>(GetTransientPackage());
	}

	if (!AutoSkillTreeExporter)
	{
		AutoSkillTreeExporter = NewObject<UAutoSkillTreeExporter>(GetTransientPackage());
	}

	if (!BeatenTreeExporter)
	{
		BeatenTreeExporter = NewObject<UBeatenTreeExporter>(GetTransientPackage());
	}

	if (!PassiveSkillTreeExporter)
	{
		PassiveSkillTreeExporter = NewObject<UPassiveSkillTreeExporter>(GetTransientPackage());
	}

	FindAllDecisionTreePath();
}

void UDecisionTreeAssetManager::UnInit()
{
	bActive = false;

	if (CombatTreeExporter)
	{
		CombatTreeExporter->MarkAsGarbage();
		CombatTreeExporter = nullptr;
	}

	if (BeatenTreeExporter)
	{
		BeatenTreeExporter->MarkAsGarbage();
		BeatenTreeExporter = nullptr;
	}

	if (PassiveSkillTreeExporter)
	{
		PassiveSkillTreeExporter->MarkAsGarbage();
		PassiveSkillTreeExporter = nullptr;
	}

	RemoveFromRoot();

	MarkAsGarbage();
}

UDecisionTreeAssetManager* UDecisionTreeAssetManager::GetInstance()
{
	for (TObjectIterator<UDecisionTreeAssetManager> It; It; ++It)
	{
		if (!It->IsTemplate() && It->bActive)
		{
			return *It;
		}
	}

	return nullptr;
}

void UDecisionTreeAssetManager::FindAllDecisionTreePath()
{
	// 查询出招表、受击树的资源路径
	CombatTreePathMap.Empty();
	AutoSkillTreePathMap.Empty();
	BeatenTreePathMap.Empty();
	PassiveSkillTreePathMap.Empty();
	
	TArray<FAssetData> AssetData;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FARFilter Filter;
	Filter.PackagePaths.Add("/Game");
	Filter.ClassPaths.Add(UCombatTreeTemplate::StaticClass()->GetClassPathName());
	Filter.ClassPaths.Add(UBeatenTreeTemplate::StaticClass()->GetClassPathName());
	Filter.ClassPaths.Add(UAutoSkillTreeTemplate::StaticClass()->GetClassPathName());
	Filter.ClassPaths.Add(UPassiveSkillTreeTemplate::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	AssetData.Empty();
	AssetRegistryModule.Get().GetAssets(Filter, AssetData);
	for (int32 i = 0; i < AssetData.Num(); ++i)
	{
		int32 ID = FCString::Atoi(*AssetData[i].AssetName.ToString());
		if (AssetData[i].GetClass() == UCombatTreeTemplate::StaticClass() && ID > 0)
		{
			CombatTreePathMap.Add(ID, TSoftObjectPtr<UCombatTreeTemplate>(AssetData[i].ToSoftObjectPath()));
		}
		else if (AssetData[i].GetClass() == UAutoSkillTreeTemplate::StaticClass() && ID > 0)
		{
			AutoSkillTreePathMap.Add(ID, TSoftObjectPtr<UAutoSkillTreeTemplate>(AssetData[i].ToSoftObjectPath()));
		}
		else if (AssetData[i].GetClass() == UBeatenTreeTemplate::StaticClass() && ID > 0)
		{
			BeatenTreePathMap.Add(ID, TSoftObjectPtr<UBeatenTreeTemplate>(AssetData[i].ToSoftObjectPath()));
		}
		else if (AssetData[i].GetClass() == UPassiveSkillTreeTemplate::StaticClass() && ID > 0)
		{
			PassiveSkillTreePathMap.Add(ID, TSoftObjectPtr<UPassiveSkillTreeTemplate>(AssetData[i].ToSoftObjectPath()));
		}
	}
}

TArray<int32> UDecisionTreeAssetManager::GetCombatTreeList()
{
	TArray<int32> Keys;
	CombatTreePathMap.GenerateKeyArray(Keys);

	return Keys;
}

UCombatTreeTemplate* UDecisionTreeAssetManager::GetCombatTreeAssetByID(int32 ID)
{
	if (TSoftObjectPtr<UCombatTreeTemplate>* Res = CombatTreePathMap.Find(ID))
	{
		if (UCombatTreeTemplate* LoadCombatTree = Res->LoadSynchronous())
		{
			return LoadCombatTree;
		}
	}

	return nullptr;
}

TSoftObjectPtr<UCombatTreeTemplate> UDecisionTreeAssetManager::GetCombatTreeAssetSoftObjectByID(int32 ID)
{
	if (TSoftObjectPtr<UCombatTreeTemplate>* Res = CombatTreePathMap.Find(ID))
	{
		return *Res;
	}

	return nullptr;
}



TArray<int32> UDecisionTreeAssetManager::GetAutoSkillTreeList()
{
	TArray<int32> Keys;
	AutoSkillTreePathMap.GenerateKeyArray(Keys);

	return Keys;
}

UAutoSkillTreeTemplate* UDecisionTreeAssetManager::GetAutoSkillTreeAssetByID(int32 ID)
{
	if (TSoftObjectPtr<UAutoSkillTreeTemplate>* Res = AutoSkillTreePathMap.Find(ID))
	{
		if (UAutoSkillTreeTemplate* LoadAutoSkillTree = Res->LoadSynchronous())
		{
			return LoadAutoSkillTree;
		}
	}

	return nullptr;
}

TSoftObjectPtr<UAutoSkillTreeTemplate> UDecisionTreeAssetManager::GetAutoSkillTreeAssetSoftObjectByID(int32 ID)
{
	if (TSoftObjectPtr<UAutoSkillTreeTemplate>* Res = AutoSkillTreePathMap.Find(ID))
	{
		return *Res;
	}

	return nullptr;
}



TArray<int32> UDecisionTreeAssetManager::GetBeatenTreeList()
{
	TArray<int32> Keys;
	BeatenTreePathMap.GenerateKeyArray(Keys);

	return Keys;
}

UBeatenTreeTemplate* UDecisionTreeAssetManager::GetBeatenTreeAssetByID(int32 ID)
{
	if (TSoftObjectPtr<UBeatenTreeTemplate>* Res = BeatenTreePathMap.Find(ID))
	{
		if (UBeatenTreeTemplate* LoadBeatenTree = Res->LoadSynchronous())
		{
			return LoadBeatenTree;
		}
	}

	return nullptr;
}

TSoftObjectPtr<UBeatenTreeTemplate> UDecisionTreeAssetManager::GetBeatenTreeAssetSoftObjectByID(int32 ID)
{
	if (TSoftObjectPtr<UBeatenTreeTemplate>* Res = BeatenTreePathMap.Find(ID))
	{
		return *Res;
	}

	return nullptr;
}

TArray<int32> UDecisionTreeAssetManager::GetPassiveSkillTreeList()
{
	TArray<int32> Keys;
	PassiveSkillTreePathMap.GenerateKeyArray(Keys);

	return Keys;
}

UPassiveSkillTreeTemplate* UDecisionTreeAssetManager::GetPassiveSkillTreeAssetByID(int32 ID)
{
	if (TSoftObjectPtr<UPassiveSkillTreeTemplate>* Res = PassiveSkillTreePathMap.Find(ID))
	{
		if (UPassiveSkillTreeTemplate* LoadPassiveSkillTree = Res->LoadSynchronous())
		{
			return LoadPassiveSkillTree;
		}
	}
	return nullptr;
}

TSoftObjectPtr<UPassiveSkillTreeTemplate> UDecisionTreeAssetManager::GetPassiveSkillTreeAssetSoftObjectByID(int32 ID)
{
	if (TSoftObjectPtr<UPassiveSkillTreeTemplate>* Res = PassiveSkillTreePathMap.Find(ID))
	{
		return *Res;
	}
	return nullptr;
}


void UDecisionTreeAssetManager::ExportCombatTreeData(int32 ID)
{
	if (UCombatTreeTemplate* Asset = GetCombatTreeAssetByID(ID))
	{
		if (CombatTreeExporter)
		{
			FString LuaPath = FPaths::ProjectContentDir() + CombatTreeExporter->ExportPath + FString::FromInt(Asset->ID) + TEXT(".lua");

			if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*LuaPath))
			{
				FFileHelper::SaveStringToFile(FString(), *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
			}

			/*
			FText ErrorMessage;
			SourceControlHelpers::CheckoutOrMarkForAdd(LuaPath, FText::FromString(LuaPath), nullptr, ErrorMessage);
			*/

			FString DataString = CombatTreeExporter->ExportDecisionTree(Asset);

			FFileHelper::SaveStringToFile(DataString, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
		}
	}
}

void UDecisionTreeAssetManager::ExportAutoSkillTreeData(int32 ID)
{
	if (UAutoSkillTreeTemplate* Asset = GetAutoSkillTreeAssetByID(ID))
	{
		if (AutoSkillTreeExporter)
		{
			FString LuaPath = FPaths::ProjectContentDir() + AutoSkillTreeExporter->ExportPath + FString::FromInt(Asset->ID) + TEXT(".lua");

			if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*LuaPath))
			{
				FFileHelper::SaveStringToFile(FString(), *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
			}

			/*
			FText ErrorMessage;
			SourceControlHelpers::CheckoutOrMarkForAdd(LuaPath, FText::FromString(LuaPath), nullptr, ErrorMessage);
			*/

			FString DataString = AutoSkillTreeExporter->ExportDecisionTree(Asset);

			FFileHelper::SaveStringToFile(DataString, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
		}
	}
}

void UDecisionTreeAssetManager::ExportBeatenTreeData(int32 ID)
{
	if (UBeatenTreeTemplate* Asset = GetBeatenTreeAssetByID(ID))
	{
		if (BeatenTreeExporter)
		{
			FString LuaPath = FPaths::ProjectContentDir() + BeatenTreeExporter->ExportPath + FString::FromInt(Asset->ID) + TEXT(".lua");

			if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*LuaPath))
			{
				FFileHelper::SaveStringToFile(FString(), *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
			}

			/*
			FText ErrorMessage;
			SourceControlHelpers::CheckoutOrMarkForAdd(LuaPath, FText::FromString(LuaPath), nullptr, ErrorMessage);
			*/

			FString DataString = BeatenTreeExporter->ExportDecisionTree(Asset);

			FFileHelper::SaveStringToFile(DataString, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
		}
	}
}

void UDecisionTreeAssetManager::ExportPassiveSkillTreeData(int32 ID)
{
	if (UPassiveSkillTreeTemplate* Asset = GetPassiveSkillTreeAssetByID(ID))
	{
		if (PassiveSkillTreeExporter)
		{
			FString LuaPath = FPaths::ProjectContentDir() + PassiveSkillTreeExporter->ExportPath + FString::FromInt(Asset->ID) + TEXT(".lua");

			if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*LuaPath))
			{
				FFileHelper::SaveStringToFile(FString(), *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
			}

			/*
			FText ErrorMessage;
			SourceControlHelpers::CheckoutOrMarkForAdd(LuaPath, FText::FromString(LuaPath), nullptr, ErrorMessage);
			*/

			FString DataString = PassiveSkillTreeExporter->ExportDecisionTree(Asset);

			FFileHelper::SaveStringToFile(DataString, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
		}
	}
}
