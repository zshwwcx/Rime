#include "BattleSystemEditor/DecisionTreeEditor/SEdNode_DecisionTreeNode.h"

#include "Widgets/Layout/SBox.h"
#include "Widgets/SBoxPanel.h"
#include "SLevelOfDetailBranchNode.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "SCommentBubble.h"
#include "SlateOptMacros.h"
#include "SGraphPin.h"
#include "Widgets/DeclarativeSyntaxSupport.h"

#include "ScopedTransaction.h"

#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeEdge.h"



#define LOCTEXT_NAMESPACE "EdNode_DecisionTree"



class SDecisionTreePin : public SGraphPin
{
public:
	SLATE_BEGIN_ARGS(SDecisionTreePin) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, UEdGraphPin* InPin)
	{
		this->SetCursor(EMouseCursor::Default);

		bShowLabel = true;

		GraphPinObj = InPin;
		check(GraphPinObj != nullptr);

		const UEdGraphSchema* Schema = GraphPinObj->GetSchema();
		check(Schema);

		SBorder::Construct
		(
			SBorder::FArguments()
			.BorderImage(this, &SDecisionTreePin::GetPinBorder)
			.BorderBackgroundColor(this, &SDecisionTreePin::GetPinColor)
			.OnMouseButtonDown(this, &SDecisionTreePin::OnPinMouseDown)
			.Cursor(this, &SDecisionTreePin::GetPinCursor)
			.Padding(FMargin(10.0f))
		);
	}

protected:
	virtual FSlateColor GetPinColor() const override
	{
		return FLinearColor(0.02f, 0.02f, 0.02f);
	}

	virtual TSharedRef<SWidget>	GetDefaultValueWidget() override
	{
		return SNew(STextBlock);
	}

	const FSlateBrush* GetPinBorder() const
	{
		return FAppStyle::GetBrush(TEXT("Graph.StateNode.Body"));
	}
};



void SEdNode_DecisionTreeNode::Construct(const FArguments& InArgs, UEdNode_DecisionTreeNode* InNode)
{
	GraphNode = InNode;
	UpdateGraphNode();
	InNode->SEdNode = SharedThis(this);
}

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void SEdNode_DecisionTreeNode::UpdateGraphNode()
{
	const FMargin NodePadding = FMargin(2.0f);

	InputPins.Empty();
	OutputPins.Empty();

	// Reset variables that are going to be exposed, in case we are refreshing an already setup node.
	RightNodeBox.Reset();
	LeftNodeBox.Reset();
	OutputPinBox.Reset();

	TSharedPtr<SErrorText> ErrorText;
	TSharedPtr<SNodeTitle> NodeTitle = SNew(SNodeTitle, GraphNode);

	this->ContentScale.Bind(this, &SGraphNode::GetContentScale);
	this->GetOrAddSlot(ENodeZone::Center)
		.HAlign(HAlign_Fill)
		.VAlign(VAlign_Center)
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush("Graph.StateNode.Body"))
			.Padding(0.0f)
			.BorderBackgroundColor(this, &SEdNode_DecisionTreeNode::GetBorderBackgroundColor)
			[
				SNew(SOverlay)

				// Pins and node details
				+ SOverlay::Slot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				[
					SNew(SVerticalBox)

					// INPUT PIN AREA
					+ SVerticalBox::Slot()
					.AutoHeight()
					[
						SNew(SBox)
						.MinDesiredHeight(NodePadding.Top)
						[
							SAssignNew(LeftNodeBox, SVerticalBox)
						]
					]

					// STATE NAME AREA
					+ SVerticalBox::Slot()
					.Padding(FMargin(NodePadding.Left, 0.0f, NodePadding.Right, 0.0f))
					[
						SNew(SVerticalBox)
						+ SVerticalBox::Slot()
						.AutoHeight()
						[
							SAssignNew(NodeBody, SBorder)
							.BorderImage(FAppStyle::GetBrush("BTEditor.Graph.BTNode.Body"))
							.BorderBackgroundColor(this, &SEdNode_DecisionTreeNode::GetBackgroundColor)
							.HAlign(HAlign_Fill)
							.VAlign(VAlign_Center)
							.Visibility(EVisibility::SelfHitTestInvisible)
							[
								SNew(SOverlay)
								+ SOverlay::Slot()
								.HAlign(HAlign_Fill)
								.VAlign(VAlign_Fill)
								[
									SNew(SVerticalBox)
									+ SVerticalBox::Slot()
									.AutoHeight()
									[
										SNew(SHorizontalBox)
										+ SHorizontalBox::Slot()
										.AutoWidth()
										[
											// POPUP ERROR MESSAGE
											SAssignNew(ErrorText, SErrorText)
											.BackgroundColor(this, &SEdNode_DecisionTreeNode::GetErrorColor)
											.ToolTipText(this, &SEdNode_DecisionTreeNode::GetErrorMsgToolTip)
										]

										+ SHorizontalBox::Slot()
										.AutoWidth()
										.Padding(FMargin(10.0f, 5.0f, 5.0f, 10.0f))
										[
											SNew(SVerticalBox)
											+ SVerticalBox::Slot()
											.AutoHeight()
											[
												SAssignNew(InlineEditableText, SInlineEditableTextBlock)
												.Text(this, &SEdNode_DecisionTreeNode::GetNodeTitle)
												.Style(FAppStyle::Get(), "Graph.StateNode.NodeTitleInlineEditableText")
												.OnVerifyTextChanged(this, &SEdNode_DecisionTreeNode::OnVerifyNameTextChanged)
												.OnTextCommitted(this, &SEdNode_DecisionTreeNode::OnNameTextCommited)
												.IsSelected(this, &SEdNode_DecisionTreeNode::IsSelectedExclusively)
												.IsReadOnly(this, &SEdNode_DecisionTreeNode::IsNameReadOnly)
											]
										]
									]
								]
							]
						]
					]

					// OUTPUT PIN AREA
					+ SVerticalBox::Slot()
					.AutoHeight()
					[
						SNew(SBox)
						.MinDesiredHeight(NodePadding.Bottom)
						[
							SAssignNew(RightNodeBox, SVerticalBox)
							+ SVerticalBox::Slot()
							.HAlign(HAlign_Fill)
							.VAlign(VAlign_Fill)
							.Padding(20.0f, 0.0f)
							.FillHeight(1.0f)
							[
								SAssignNew(OutputPinBox, SHorizontalBox)
							]
						]
					]
				]
			]
		];


	// Create comment bubble
	TSharedPtr<SCommentBubble> CommentBubble;
	const FSlateColor CommentColor = FLinearColor::White;

	SAssignNew(CommentBubble, SCommentBubble)
		.GraphNode(GraphNode)
		.Text(this, &SGraphNode::GetNodeComment)
		.OnTextCommitted(this, &SGraphNode::OnCommentTextCommitted)
		.ColorAndOpacity(CommentColor)
		.AllowPinning(true)
		.EnableTitleBarBubble(true)
		.EnableBubbleCtrls(true)
		.GraphLOD(this, &SGraphNode::GetCurrentLOD)
		.IsGraphNodeHovered(this, &SGraphNode::IsHovered);

	GetOrAddSlot(ENodeZone::TopCenter)
		.SlotOffset(TAttribute<FVector2D>(CommentBubble.Get(), &SCommentBubble::GetOffset))
		.SlotSize(TAttribute<FVector2D>(CommentBubble.Get(), &SCommentBubble::GetSize))
		.AllowScaling(TAttribute<bool>(CommentBubble.Get(), &SCommentBubble::IsScalingAllowed))
		.VAlign(VAlign_Top)
		[
			CommentBubble.ToSharedRef()
		];

	ErrorReporting = ErrorText;
	ErrorReporting->SetError(ErrorMsg);
	CreatePinWidgets();
}

void SEdNode_DecisionTreeNode::CreatePinWidgets()
{
	UEdNode_DecisionTreeNode* StateNode = CastChecked<UEdNode_DecisionTreeNode>(GraphNode);

	for (int32 PinIdx = 0; PinIdx < StateNode->Pins.Num(); PinIdx++)
	{
		UEdGraphPin* MyPin = StateNode->Pins[PinIdx];
		if (!MyPin->bHidden)
		{
			TSharedPtr<SGraphPin> NewPin = SNew(SDecisionTreePin, MyPin);

			AddPin(NewPin.ToSharedRef());
		}
	}
}

void SEdNode_DecisionTreeNode::AddPin(const TSharedRef<SGraphPin>& PinToAdd)
{
	PinToAdd->SetOwner(SharedThis(this));

	const UEdGraphPin* PinObj = PinToAdd->GetPinObj();
	const bool bAdvancedParameter = PinObj && PinObj->bAdvancedView;
	if (bAdvancedParameter)
	{
		PinToAdd->SetVisibility(TAttribute<EVisibility>(PinToAdd, &SGraphPin::IsPinVisibleAsAdvanced));
	}

	if (PinToAdd->GetDirection() == EEdGraphPinDirection::EGPD_Input)
	{
		LeftNodeBox->AddSlot()
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Fill)
			.FillHeight(1.0f)
			.Padding(20.0f, 0.0f)
			[
				PinToAdd
			];

		InputPins.Add(PinToAdd);
	}
	else
	{
		OutputPinBox->AddSlot()
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Fill)
			.FillWidth(1.0f)
			[
				PinToAdd
			];

		OutputPins.Add(PinToAdd);
	}
}

bool SEdNode_DecisionTreeNode::IsNameReadOnly() const
{
	return false;
}

END_SLATE_FUNCTION_BUILD_OPTIMIZATION

void SEdNode_DecisionTreeNode::OnNameTextCommited(const FText& InText, ETextCommit::Type CommitInfo)
{
	SGraphNode::OnNameTextCommited(InText, CommitInfo);

	UEdNode_DecisionTreeNode* MyNode = CastChecked<UEdNode_DecisionTreeNode>(GraphNode);

	if (MyNode != nullptr && MyNode->GraphNode != nullptr)
	{
		const FScopedTransaction Transaction(LOCTEXT("DecisionTreeEditorRenameNode", "DecisionTree Editor: Rename Node"));
		MyNode->Modify();
		MyNode->GraphNode->Modify();
		MyNode->GraphNode->SetNodeTitle(InText);
		UpdateGraphNode();
	}
}

FSlateColor SEdNode_DecisionTreeNode::GetBorderBackgroundColor() const
{
	UEdNode_DecisionTreeNode* MyNode = CastChecked<UEdNode_DecisionTreeNode>(GraphNode);
	if (!MyNode || MyNode->Pins.Num() < 2)
		return FLinearColor(0.0f, 0.22f, 0.4f);

	UEdNode_DecisionTreeEdge* TheEdge = NULL;
	if (MyNode->Pins[0]->LinkedTo.Num() > 0)
	{
		TheEdge = Cast<UEdNode_DecisionTreeEdge>(MyNode->Pins[0]->LinkedTo[0]->GetOwningNode());
	}
	else if (MyNode->Pins[1]->LinkedTo.Num() > 0)
	{
		TheEdge = Cast<UEdNode_DecisionTreeEdge>(MyNode->Pins[1]->LinkedTo[0]->GetOwningNode());
	}

	return FLinearColor(0.0f, 0.22f, 0.4f);
}

FSlateColor SEdNode_DecisionTreeNode::GetBackgroundColor() const
{
	return FLinearColor(0.1f, 0.1f, 0.1f);
}

EVisibility SEdNode_DecisionTreeNode::GetDragOverMarkerVisibility() const
{
	return EVisibility::Visible;
}

const FSlateBrush* SEdNode_DecisionTreeNode::GetNameIcon() const
{
	return FAppStyle::GetBrush(TEXT("BTEditor.Graph.BTNode.Icon"));
}

FText SEdNode_DecisionTreeNode::GetNodeTitle() const
{
	UEdNode_DecisionTreeNode* TheNode = Cast<UEdNode_DecisionTreeNode>(this->GraphNode);
	if (TheNode)
	{
		return TheNode->GetNodeTitle(ENodeTitleType::Type::FullTitle);
	}
	return FText();
}



#undef LOCTEXT_NAMESPACE
