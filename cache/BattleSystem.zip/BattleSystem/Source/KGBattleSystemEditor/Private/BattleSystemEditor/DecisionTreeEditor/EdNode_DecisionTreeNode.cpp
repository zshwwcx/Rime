#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/EdGraph_DecisionTree.h"
#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeEdge.h"
#include "Kismet2/Kismet2NameValidators.h"
#include "Kismet2/BlueprintEditorUtils.h"

#include "BattleSystemEditor/DecisionTreeEditor/SEdNode_DecisionTreeNode.h"

#define LOCTEXT_NAMESPACE "EdNode_DecisionTree"

UEdNode_DecisionTreeNode::UEdNode_DecisionTreeNode()
{
	bCanRenameNode = true;
}

UEdNode_DecisionTreeNode::~UEdNode_DecisionTreeNode()
{
	if (GraphNode && GraphNode->IsValidLowLevel() && !IsValid(GraphNode))
		GraphNode->MarkAsGarbage();
}

void UEdNode_DecisionTreeNode::AllocateDefaultPins()
{
	if (GraphNode)
	{
		const TArray<FDTNodePin>* List = GraphNode->GetNodePinList();
		for (int32 i = 0; i < List->Num(); ++i)
		{
			const FDTNodePin& CurPin = (*List)[i];
			if (CurPin.bIsOutput)
			{
				CreatePin(EGPD_Output, TEXT("DecisionTree"), TEXT("DTNode"), CurPin.PinName);
			}
			else
			{
				CreatePin(EGPD_Input, TEXT("DecisionTree"), TEXT("DTNode"), CurPin.PinName);
			}
		}
	}
}

UEdGraph_DecisionTree* UEdNode_DecisionTreeNode::GetDecisionTreeEdGraph()
{
	return Cast<UEdGraph_DecisionTree>(GetGraph());
}

FText UEdNode_DecisionTreeNode::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	if (!GraphNode)
		return Super::GetNodeTitle(TitleType);
	else
		return GraphNode->GetNodeTitle();
}

void UEdNode_DecisionTreeNode::PrepareForCopying()
{
	
}

void UEdNode_DecisionTreeNode::SetDecisionTreeNode(UDecisionTreeNode* InNode)
{
	GraphNode = InNode;
}

FLinearColor UEdNode_DecisionTreeNode::GetBackgroundColor() const
{
	return FLinearColor::Black;
}

UEdGraphPin* UEdNode_DecisionTreeNode::GetPinByIndex(int32 InIndex) const
{
	if (Pins.IsValidIndex(InIndex))
		return Pins[InIndex];

	return nullptr;
}

int32 UEdNode_DecisionTreeNode::GetPinIndex(const UEdGraphPin* InPin) const
{
	for (int32 i = 0; i < Pins.Num(); ++i)
	{
		if (Pins[i] == InPin)
			return i;
	}

	return -1;
}

UEdGraphPin* UEdNode_DecisionTreeNode::GetPinByName(FName InName) const
{
	for (int32 i = 0; i < Pins.Num(); ++i)
	{
		if (Pins[i]->GetFName().IsEqual(InName))
			return Pins[i];
	}

	return nullptr;
}

bool UEdNode_DecisionTreeNode::CanUserDeleteNode() const
{
	if (GraphNode)
	{
		return GraphNode->CanUserDelete();
	}

	return true;
}

void UEdNode_DecisionTreeNode::PostEditUndo()
{
	UEdGraphNode::PostEditUndo();
}

void UEdNode_DecisionTreeNode::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (SEdNode.IsValid())
	{
		SEdNode.Pin()->UpdateGraphNode();
	}

	UEdGraphNode::PostEditChangeProperty(PropertyChangedEvent);
}

int32 UEdNode_DecisionTreeNode::GetNodeDepth()
{
	if (Pins[0]->LinkedTo.Num() == 0)
		return 0;

	int32 Depth = 10000;
	for (int32 i = 0; i < Pins[0]->LinkedTo.Num(); ++i)
	{
		int32 TmpDepth = 10000;
		UEdNode_DecisionTreeEdge* Edge = Cast<UEdNode_DecisionTreeEdge>(Pins[0]->LinkedTo[i]->GetOwningNode());
		if (UEdNode_DecisionTreeNode* FatherNode = Edge->GetStartNode())
		{
			TmpDepth = FatherNode->GetNodeDepth();
			if (TmpDepth < Depth)
				Depth = TmpDepth;
		}
	}

	return Depth + 1;
}

void UEdNode_DecisionTreeNode::DestroyNode()
{
	if (GraphNode)
	{
		GraphNode->MarkAsGarbage();
		GraphNode = NULL;
	}

	Super::DestroyNode();
}

#undef LOCTEXT_NAMESPACE
