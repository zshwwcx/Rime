#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeExporter.h"



UPassiveSkillTreeTypeMessage::UPassiveSkillTreeTypeMessage()
{
	bAllowCycle = true;
	ExporterType = UPassiveSkillTreeExporter::StaticClass();
	FirstNodeType = UPassiveSkillEventNode::StaticClass();
	NeedLoadAssetTypes.Add(UBSASkillAsset::StaticClass());
	DataCollectorType = UDecisionTreeDataCollector::StaticClass();

#if WITH_EDITORONLY_DATA
	NodeTypes.Add(UPassiveSkillEventNode::StaticClass());
	NodeTypes.Add(UPassiveSkillTaskNode::StaticClass());
	NodeTypes.Add(UPassiveSkillCondtionNode::StaticClass());
	EdgeType = UPassiveSkillTreeEdge::StaticClass();
#endif
}
