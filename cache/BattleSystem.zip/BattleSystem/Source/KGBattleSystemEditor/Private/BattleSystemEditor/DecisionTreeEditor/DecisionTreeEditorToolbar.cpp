#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditorToolbar.h"

#include "Framework/MultiBox/MultiBoxBuilder.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditor.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditorToolbar.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditorCommands.h"

#define LOCTEXT_NAMESPACE "DecisionTreeEditorToolbar"

void FDecisionTreeEditorToolbar::AddGraphToolbar(TSharedPtr<FExtender> Extender)
{
	check(DecisionTreeEditor.IsValid());
	TSharedPtr<FDecisionTreeEditor> DecisionTreeEditorPtr = DecisionTreeEditor.Pin();

	TSharedPtr<FExtender> ToolbarExtender = MakeShareable(new FExtender);
	ToolbarExtender->AddToolBarExtension("Asset", EExtensionHook::After, DecisionTreeEditorPtr->GetToolkitCommands(), FToolBarExtensionDelegate::CreateSP(this, &FDecisionTreeEditorToolbar::FillGraphToolbar));	
	DecisionTreeEditorPtr->AddToolbarExtender(ToolbarExtender);
}

void FDecisionTreeEditorToolbar::FillGraphToolbar(FToolBarBuilder& ToolbarBuilder)
{
	const FDecisionTreeEditorCommands& Commands = FDecisionTreeEditorCommands::Get();

	ToolbarBuilder.BeginSection("Graph");
	ToolbarBuilder.AddToolBarButton(Commands.BackToPreviousGraph);
	ToolbarBuilder.EndSection();
}

#undef LOCTEXT_NAMESPACE
