#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeNode.h"


#if WITH_EDITOR
void UPassiveSkillTreeEdge::CopyData(UDecisionTreeEdge* OtherNode)
{
	Super::CopyData(OtherNode);

}

void UPassiveSkillTreeEdge::RefreshEdgeTitle()
{
	if (UPassiveSkillCondtionNode* Node = Cast<UPassiveSkillCondtionNode>(StartNode))
	{
		EdgeMessageSize.X = 100.0f;
		EdgeMessageSize.Y = 30;
		EdgeTitle = FText::FromString(IsTrue ? "True" : "False");
	}
	else
	{
		EdgeMessageSize.X = 0;
		EdgeMessageSize.Y = 0;
		EdgeTitle = FText::FromString("");
	}
}

void UPassiveSkillTreeEdge::SetEdgeTitle(const FText& NewTitle)
{

}

void UPassiveSkillTreeEdge::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	RefreshEdgeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif
