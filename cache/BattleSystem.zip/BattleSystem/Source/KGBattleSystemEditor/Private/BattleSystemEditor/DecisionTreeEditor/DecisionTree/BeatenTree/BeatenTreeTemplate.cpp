#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeExporter.h"



UBeatenTreeTypeMessage::UBeatenTreeTypeMessage()
{
	ExporterType = UBeatenTreeExporter::StaticClass();
	DataCollectorType = UBeatenTreeCollector::StaticClass();

#if WITH_EDITORONLY_DATA
	NodeTypes.Add(UBeatenTreeNode::StaticClass());

	EdgeType = UBeatenTreeEdge::StaticClass();
#endif
}






#if WITH_EDITOR
void UBeatenTreeTemplate::RefreshLogicMessage()
{
	Super::RefreshLogicMessage();

	TotalSkillNum = 0;
	VisitedNodes.Empty();

	for (int32 i = 0; i < DecisionTreeEdges.Num(); ++i)
	{
		if (UBeatenTreeEdge* CurBattleEdge = Cast<UBeatenTreeEdge>(DecisionTreeEdges[i]))
		{
			CurBattleEdge->EdgeShortestDepth = 100000;
		}
	}

	for (int32 i = 0; i < RootNodes.Num(); ++i)
	{
		UBeatenTreeNode* CurNode = Cast<UBeatenTreeNode>(RootNodes[i]);
		RefreshNodeMessage(CurNode, 1);
	}

	for (int32 i = 0; i < DecisionTreeEdges.Num(); ++i)
	{
		if (UBeatenTreeEdge* CurBattleEdge = Cast<UBeatenTreeEdge>(DecisionTreeEdges[i]))
		{
			CurBattleEdge->CheckConditionData();
		}
	}
}

void UBeatenTreeTemplate::RefreshNodeMessage(UBeatenTreeNode* InCurNode, int32 CurrentDepth)
{
	if (InCurNode)
	{
		if (!VisitedNodes.Contains(InCurNode))
		{
			TotalSkillNum += 1;
			VisitedNodes.Add(InCurNode);

			// 遍历该节点的边
			for (int32 i = 0; i < InCurNode->OutEdges.Num(); ++i)
			{
				UBeatenTreeEdge* CurEdge = Cast<UBeatenTreeEdge>(DecisionTreeEdges[InCurNode->OutEdges[i]]);
				if (!CurEdge)
					continue;

				if (CurEdge->EdgeShortestDepth > CurrentDepth)
					CurEdge->EdgeShortestDepth = CurrentDepth;

				UBeatenTreeNode* CurNode = Cast<UBeatenTreeNode>(CurEdge->EndNode);
				RefreshNodeMessage(CurNode, CurrentDepth + 1);
			}
		}
	}
}

#endif