#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeNode.h"

#include "BattleSystem/BSFunctionLibrary.h" 



UPassiveSkillEventNode::UPassiveSkillEventNode()
{
	NodeTitle = FText::FromString(TEXT("EventNode"));

}

void UPassiveSkillEventNode::CopyData(UDecisionTreeNode* OtherNode) 
{
	if(UPassiveSkillEventNode* EventNode = Cast<UPassiveSkillEventNode>(OtherNode))
	{
		TArray<UPassiveSkillEvent*> NewEventGroup;
		for (auto event : EventNode->EventGroup)
		{
			NewEventGroup.Add(DuplicateObject<UPassiveSkillEvent>(event, this));
		}
		EventGroup = NewEventGroup;
		ConditionGroup = DuplicateObject<UDecisionTreeConditionGroup>(EventNode->ConditionGroup, this);
		NodeTitle = EventNode->NodeTitle;
	}
	Super::CopyData(OtherNode);
}


#if WITH_EDITOR
void UPassiveSkillEventNode::SetNodeTitle(const FText& NewTitle)
{
	
}

bool UPassiveSkillEventNode::CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage)
{
	//if (PinInformations.IsValidIndex(SelfPinID))
	//{
	//	if (!PinInformations[SelfPinID].bIsOutput)
	//	{
	//		if (Other->GetClass() == UPassiveSkillTaskNode::StaticClass())
	//		{
	//			return true;
	//		}
	//	}
	//	else
	//	{
	//		if (Other->GetClass() == UPassiveSkillCondtionNode::StaticClass())
	//		{
	//			return true;
	//		}
	//	}
	//}

	return true;
}

bool UPassiveSkillEventNode::CanUserDelete() const
{
	return true;
}


void UPassiveSkillEventNode::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.Property->GetName() == TEXT("EventGroup"))
	{
		//NodeTitle = FText::FromString(TEXT("EventNode"));
		if (EventGroup.Num() > 0 && EventGroup[0])
		{
			FString name, externName;
			EventGroup[0]->GetName().Split(TEXT("_"), &name, &externName);
			EventGroup[0]->EventType = name;
			NodeTitle = FText::FromString(name);
		}
	}
	RefreshNodeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UPassiveSkillEventNode::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}
#endif






UPassiveSkillTaskNode::UPassiveSkillTaskNode()
{
	NodeTitle = FText::FromString(TEXT("TaskNode"));
}

#if WITH_EDITOR
void UPassiveSkillTaskNode::SetNodeTitle(const FText& NewTitle)
{
	NodeTitle = NewTitle;
}

void UPassiveSkillTaskNode::CopyData(UDecisionTreeNode* OtherNode)
{
	if(UPassiveSkillTaskNode* OtherSkillTaskNode = Cast<UPassiveSkillTaskNode>(OtherNode))
	{
		TaskData = DuplicateObject<UBSATask>(OtherSkillTaskNode->TaskData, this);
		ConditionGroup = DuplicateObject<UDecisionTreeConditionGroup>(OtherSkillTaskNode->ConditionGroup, this);
		NodeTitle = OtherSkillTaskNode->NodeTitle;
	}
	Super::CopyData(OtherNode);
}

void UPassiveSkillTaskNode::RefreshNodeTitle()
{

}

void UPassiveSkillTaskNode::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.Property->GetName() == TEXT("TaskData"))
	{
		if (TaskData)
		{
			FString name, externName;
			TaskData->GetName().Split(TEXT("_"), &name, &externName);
			NodeTitle = FText::FromString(externName);
		}
	}
	RefreshNodeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UPassiveSkillTaskNode::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

bool UPassiveSkillTaskNode::CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage)
{
	//if (PinInformations.IsValidIndex(SelfPinID))
	//{
	//	if (!PinInformations[SelfPinID].bIsOutput)
	//	{
	//		if (Other->GetClass() == UPassiveSkillCondtionNode::StaticClass())
	//		{
	//			return true;
	//		}
	//	}
	//}

	return true;
}

#endif



UPassiveSkillCondtionNode::UPassiveSkillCondtionNode()
{
	NodeTitle = FText::FromString(TEXT("ConditionNode"));

}
bool UPassiveSkillCondtionNode::CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage)
{
	//if (PinInformations.IsValidIndex(SelfPinID))
	//{
	//	if (!PinInformations[SelfPinID].bIsOutput)
	//	{
	//		if (Other->GetClass() == UPassiveSkillEventNode::StaticClass())
	//		{
	//			return true;
	//		}
	//	}
	//}

	return true;
}

#if WITH_EDITOR
void UPassiveSkillCondtionNode::SetNodeTitle(const FText& NewTitle)
{
	NodeTitle = NewTitle;
}

void UPassiveSkillCondtionNode::CopyData(UDecisionTreeNode* OtherNode)
{
	if(UPassiveSkillCondtionNode* OtherConditionNode = Cast<UPassiveSkillCondtionNode>(OtherNode))
	{
		TArray<UPassiveSkillCondition*> NewConditionDatas;
		for (auto data : OtherConditionNode->ConditionDatas)
		{
			NewConditionDatas.Add(DuplicateObject<UPassiveSkillCondition>(data, this));
		}
		ConditionDatas = NewConditionDatas;
		NeedStartTrigger = OtherConditionNode->NeedStartTrigger;
		NotCD = OtherConditionNode->NotCD;
		Probability = OtherConditionNode->Probability;
		TriggerActor = OtherConditionNode->TriggerActor;
		ConditionGroup = DuplicateObject<UDecisionTreeConditionGroup>(OtherConditionNode->ConditionGroup, this);
		NodeTitle = OtherConditionNode->NodeTitle;
	}
	Super::CopyData(OtherNode);
}

void UPassiveSkillCondtionNode::RefreshNodeTitle()
{
	//FString Title;

	//if (bCheckReleaseCondition)
	//{
	//	Title += TEXT("Neec Check Release Condition !\n");
	//}
	//Title += TEXT("ConditionNode");
	//Title += ReleaseSkillAsset.GetAssetName();
	//if (UBSASkillAsset* Skill = ReleaseSkillAsset.LoadSynchronous())
	//{
	//	Title += TEXT("  ");
	//	Title += Skill->Name.ToString();
	//}

	//NodeTitle = FText::FromString(Title);
}

void UPassiveSkillCondtionNode::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.Property->GetName() == TEXT("ConditionDatas"))
	{
		//NodeTitle = FText::FromString(TEXT("ConditionNode"));
		FString name, externName;
		for (int i = 0; i < ConditionDatas.Num(); i++)
		{
			if (!ConditionDatas[i])
				continue;
			ConditionDatas[i]->GetName().Split(TEXT("_"), &name, &externName);
			NodeTitle = FText::FromString(name);
			ConditionDatas[i]->CondtionType = name;
		}
	}
	RefreshNodeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UPassiveSkillCondtionNode::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

#endif
