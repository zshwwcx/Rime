#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeEdge.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/BeatenTree/BeatenTreeCondition.h"



UBeatenTreeEdge::UBeatenTreeEdge()
{

#if WITH_EDITORONLY_DATA
	EdgeMessageSize = FVector2D(150.0f, 50.0f);
#endif

}

#if WITH_EDITOR
void UBeatenTreeEdge::ConstructEdge()
{
	Super::ConstructEdge();

	// 创建ConditionGroup
	if (!ConditionGroup)
	{
		ConditionGroup = NewObject<UDecisionTreeConditionGroup>(this);
		ConditionGroup->ConditionList.Add(NewObject<UBeatenTreeCondition>(ConditionGroup));
	}

	CheckConditionData();
}

void UBeatenTreeEdge::CheckConditionData()
{
	if (ConditionGroup && ConditionGroup->ConditionList.Num() > 0)
	{
		if (UBeatenTreeCondition* CurEdgeCondition = Cast<UBeatenTreeCondition>(ConditionGroup->ConditionList.Last()))
		{
			// 根据深度检查配置数据是否正确
			if (EdgeShortestDepth == 1)
			{
				CurEdgeCondition->bCheckStaggerState = true;
				CurEdgeCondition->bCheckAttackType = false;
				CurEdgeCondition->bCheckAttackForce = false;
				CurEdgeCondition->bCheckRelationType = false;
			}
			else if (EdgeShortestDepth == 2)
			{
				CurEdgeCondition->bCheckStaggerState = false;
				CurEdgeCondition->bCheckAttackType = true;
				CurEdgeCondition->bCheckAttackForce = false;
				CurEdgeCondition->bCheckRelationType = false;
			}
			else if (EdgeShortestDepth == 3)
			{
				CurEdgeCondition->bCheckStaggerState = false;
				CurEdgeCondition->bCheckAttackType = false;
				CurEdgeCondition->bCheckAttackForce = true;
				CurEdgeCondition->bCheckRelationType = false;
			}
			else if (EdgeShortestDepth == 4)
			{
				CurEdgeCondition->bCheckStaggerState = false;
				CurEdgeCondition->bCheckAttackType = false;
				CurEdgeCondition->bCheckAttackForce = false;
				CurEdgeCondition->bCheckRelationType = true;
			}
			else
			{
				CurEdgeCondition->bCheckStaggerState = false;
				CurEdgeCondition->bCheckAttackType = false;
				CurEdgeCondition->bCheckAttackForce = false;
				CurEdgeCondition->bCheckRelationType = false;
			}
		}
	}
}

void UBeatenTreeEdge::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	CheckConditionData();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif