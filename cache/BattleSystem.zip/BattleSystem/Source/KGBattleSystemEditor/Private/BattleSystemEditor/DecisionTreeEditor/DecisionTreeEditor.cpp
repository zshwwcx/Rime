#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditor.h"

#include "IDetailsView.h"
#include "Modules/ModuleManager.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Framework/Commands/GenericCommands.h"
#include "EdGraphUtilities.h"
#include "ScopedTransaction.h"
#include "GraphEditorActions.h"
#include "PropertyEditorModule.h"
#include "Kismet2/SClassPickerDialog.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "HAL/PlatformFilemanager.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Misc/FileHelper.h"
#include "SourceControlHelpers.h"

#include "Lua/LuaEnv.h"

#include "LevelLuaEditorProxyBase.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"

#include "BattleSystem/BSCondition.h"
#include "BattleSystem/Ability/BSACondition.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/SEdNode_DecisionTreeEdge.h"
#include "BattleSystemEditor/DecisionTreeEditor/SEdNode_DecisionTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditorSchema.h"
#include "BattleSystemEditor/DecisionTreeEditor/EdGraph_DecisionTree.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditorToolbar.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditorCommands.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeEdge.h"



#define LOCTEXT_NAMESPACE "DecisionTreeEditor"



const FName DecisionTreeEditorAppName = FName(TEXT("DecisionTreeEditor"));



class FGraphPanelNodeFactory_DecisionTree : public FGraphPanelNodeFactory
{
	virtual TSharedPtr<SGraphNode> CreateNode(UEdGraphNode* Node) const override
	{
		if (UEdNode_DecisionTreeNode* EdNode_GraphNode = Cast<UEdNode_DecisionTreeNode>(Node))
			return SNew(SEdNode_DecisionTreeNode, EdNode_GraphNode);
		else if (UEdNode_DecisionTreeEdge* EdNode_GrpahEdge = Cast<UEdNode_DecisionTreeEdge>(Node))
		{
			if (UPassiveSkillTreeEdge* PassvieEdge = Cast<UPassiveSkillTreeEdge>(EdNode_GrpahEdge))
				return nullptr;
			return SNew(SEdNode_DecisionTreeEdge, EdNode_GrpahEdge);
		}

		return nullptr;
	}
};
TSharedPtr<FGraphPanelNodeFactory> GraphPanelNodeFactory_DecisionTree;



struct FDecisionTreeEditorTabs
{
	static const FName PropertyID;
	static const FName ViewportID;
	static const FName SettingsID;
};
const FName FDecisionTreeEditorTabs::PropertyID(TEXT("DecisionTreeProperty"));
const FName FDecisionTreeEditorTabs::ViewportID(TEXT("Viewport"));
const FName FDecisionTreeEditorTabs::SettingsID(TEXT("DecisionTreeSettings"));



int32 FDecisionTreeEditor::DecisionTreeIndex = 0;
int32 FDecisionTreeEditor::DecisionTreeNum = 0;

FDecisionTreeEditor::FDecisionTreeEditor()
{
	FDecisionTreeEditor::DecisionTreeIndex += 1;
	FDecisionTreeEditor::DecisionTreeNum += 1;
	FString WorldName = TEXT("DTEditor") + FString::FromInt(FDecisionTreeEditor::DecisionTreeIndex);

	// 创建Lua环境
	LuaEnv = UEditorLuaEnv::CreateLuaEnv(GEditor->GetEditorWorldContext().World(), UEditorLuaGameInstanceBase::StaticClass());

	DecisionTreeTemplate = nullptr;

	GraphPanelNodeFactory_DecisionTree = MakeShareable(new FGraphPanelNodeFactory_DecisionTree());
	FEdGraphUtilities::RegisterVisualNodeFactory(GraphPanelNodeFactory_DecisionTree);
}

FDecisionTreeEditor::~FDecisionTreeEditor()
{
	FDecisionTreeEditor::DecisionTreeNum -= 1;
	if (GraphPanelNodeFactory_DecisionTree.IsValid())
	{
		FEdGraphUtilities::UnregisterVisualNodeFactory(GraphPanelNodeFactory_DecisionTree);
		GraphPanelNodeFactory_DecisionTree.Reset();
	}
}

void FDecisionTreeEditor::InitEditor(const EToolkitMode::Type Mode, const TSharedPtr<IToolkitHost>& InitToolkitHost, UDecisionTreeTemplate* InTreeTemp)
{
	DecisionTreeTemplate = InTreeTemp;
	// 初始化资源对象
	if (DecisionTreeTemplate.IsValid())
	{
		UEdGraph* tEdGraph = DecisionTreeTemplate->EdGraph.Get();
		CreateEdGraph(DecisionTreeTemplate.Get(), tEdGraph);
		DecisionTreeTemplate->EdGraph = tEdGraph;
		DecisionTreeTemplate->InitByEditor();

		if (DecisionTreeTemplate->TypeMessage)
		{
			UDTTypeMessage* CurDTMsg = Cast<UDTTypeMessage>(DecisionTreeTemplate->TypeMessage.GetDefaultObject());

			if (CurDTMsg && DecisionTreeTemplate->EdGraph.Get() && DecisionTreeTemplate->EdGraph->Nodes.Num() <= 0 && CurDTMsg->FirstNodeType)
			{
				UEdNode_DecisionTreeNode* FirstNode = NewObject<UEdNode_DecisionTreeNode>(DecisionTreeTemplate->EdGraph.Get());
				FirstNode->GraphNode = NewObject<UDecisionTreeNode>(DecisionTreeTemplate->EdGraph->GetOuter(), CurDTMsg->FirstNodeType);
				FirstNode->GraphNode->ConstructNode();

				DecisionTreeTemplate->EdGraph->AddNode(FirstNode, true, false);
				FirstNode->CreateNewGuid();
				FirstNode->PostPlacedNewNode();
				FirstNode->AllocateDefaultPins();
				FirstNode->NodePosX = 0.0f;
				FirstNode->NodePosY = 0.0f;
				FirstNode->GraphNode->SetFlags(RF_Transactional);
				FirstNode->SetFlags(RF_Transactional);
			}

			if (CurDTMsg && CurDTMsg->NeedLoadAssetTypes.Num() > 0)
			{
				TArray<FAssetData> AssetData;
				FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
				FARFilter Filter;
				Filter.PackagePaths.Add("/Game");
				for (int32 i = 0; i < CurDTMsg->NeedLoadAssetTypes.Num(); ++i)
				{
					Filter.ClassPaths.Add(CurDTMsg->NeedLoadAssetTypes[i]->GetClassPathName());
				}
				Filter.bRecursivePaths = true;
				Filter.bRecursiveClasses = true;
				AssetData.Empty();
				AssetRegistryModule.Get().GetAssets(Filter, AssetData);
			}

			// 创建Json数据导出器
			if (CurDTMsg && CurDTMsg->ExporterType)
			{
				DataExporter = NewObject<UDTBasicExporter>(GEditor->GetEditorWorldContext().World(), CurDTMsg->ExporterType);
				DataExporter->AddToRoot();
			}
		}
	}

	FGraphEditorCommands::Register();
	FDecisionTreeEditorCommands::Register();

	BindCommands();
	CreateCommandList();

	if (!ToolbarBuilder.IsValid())
		ToolbarBuilder = MakeShareable(new FDecisionTreeEditorToolbar(SharedThis(this)));

	TSharedPtr<FExtender> ToolbarExtender = MakeShareable(new FExtender);
	ToolbarBuilder->AddGraphToolbar(ToolbarExtender);

	// 创建主要的编辑窗口
	CreateMainEditWidgets();

	// Layout
	const TSharedRef<FTabManager::FLayout> StandaloneDefaultLayout = FTabManager::NewLayout("Standalone_DecisionTreeEditor_Layout_v1")
		->AddArea
		(
			FTabManager::NewPrimaryArea()->SetOrientation(Orient_Vertical)
			->Split
			(
				FTabManager::NewStack()
				->SetSizeCoefficient(0.1f)
				->AddTab(TEXT("DecisionTreeEditor"), ETabState::OpenedTab)->SetHideTabWell(true)
			)
			->Split
			(
				FTabManager::NewSplitter()->SetOrientation(Orient_Horizontal)->SetSizeCoefficient(0.9f)
				->Split
				(
					FTabManager::NewStack()
					->SetSizeCoefficient(0.65f)
					->AddTab(FDecisionTreeEditorTabs::ViewportID, ETabState::OpenedTab)->SetHideTabWell(true)
				)
				->Split
				(
					FTabManager::NewSplitter()->SetOrientation(Orient_Vertical)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.7f)
						->AddTab(FDecisionTreeEditorTabs::PropertyID, ETabState::OpenedTab)->SetHideTabWell(true)
					)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.3f)
						->AddTab(FDecisionTreeEditorTabs::SettingsID, ETabState::OpenedTab)
					)
				)
			)
		);

	const bool bCreateDefaultStandaloneMenu = true;
	const bool bCreateDefaultToolbar = true;
	FAssetEditorToolkit::InitAssetEditor
	(
		Mode, InitToolkitHost, DecisionTreeEditorAppName, StandaloneDefaultLayout,
		bCreateDefaultStandaloneMenu, bCreateDefaultToolbar, DecisionTreeTemplate.Get(), false
	);

	RegenerateMenusAndToolbars();

	// 初始化时刷新一遍节点/边的文字内容
	for (int32 i = 0; i < DecisionTreeTemplate->EdGraph->Nodes.Num(); ++i)
	{
		if (UEdNode_DecisionTreeNode* CurNode = Cast<UEdNode_DecisionTreeNode>(DecisionTreeTemplate->EdGraph->Nodes[i]))
		{
			if (CurNode->GraphNode)
			{
				CurNode->GraphNode->RefreshNodeTitle();
			}
		}
		else if (UEdNode_DecisionTreeEdge* CurEdge = Cast<UEdNode_DecisionTreeEdge>(DecisionTreeTemplate->EdGraph->Nodes[i]))
		{
			if (CurEdge->GraphEdge)
			{
				CurEdge->GraphEdge->RefreshEdgeTitle();
			}
		}
	}

	// 应策划需求，在这个编辑器里做一些特殊的屏蔽
	if (FDecisionTreeEditor::DecisionTreeNum == 1)
	{
		if (FProperty* Prop = UBSCondition::StaticClass()->FindPropertyByName(TEXT("Name")))
		{
			Prop->SetMetaData("EditCondition", "false");
			Prop->SetMetaData("EditConditionHides", "true");
		}

		if (DecisionTreeTemplate->IsA(UAutoSkillTreeTemplate::StaticClass()))
		{
			if (FProperty* Prop = UAutoSkillTreeEdge::StaticClass()->FindPropertyByName(TEXT("ConditionGroup")))
			{
				Prop->SetMetaData("EditCondition", "false");
				Prop->SetMetaData("EditConditionHides", "true");
			}

			if (FProperty* Prop = UAutoSkillTreeNode::StaticClass()->FindPropertyByName(TEXT("ConditionGroup")))
			{
				Prop->SetMetaData("EditCondition", "false");
				Prop->SetMetaData("EditConditionHides", "true");
			}
			
			UEnum* Enum = StaticEnum<EBSAConditionTarget>();
			Enum->RemoveMetaData(TEXT("Hidden"), int32(EBSAConditionTarget::CT_AllTeamMember));
			Enum->RemoveMetaData(TEXT("Hidden"), int32(EBSAConditionTarget::CT_AnyTeamMember));
			Enum->RemoveMetaData(TEXT("Hidden"), int32(EBSAConditionTarget::CT_AllGrounpMember));
			Enum->RemoveMetaData(TEXT("Hidden"), int32(EBSAConditionTarget::CT_AnyGroupMember));
			Enum->SetMetaData(TEXT("Hidden"), TEXT("Hidden"), int32(EBSAConditionTarget::CT_TaskTarget));
			Enum->SetMetaData(TEXT("Hidden"), TEXT("Hidden"), int32(EBSAConditionTarget::CT_InstanceInstigator));
			Enum->SetMetaData(TEXT("Hidden"), TEXT("Hidden"), int32(EBSAConditionTarget::CT_InstanceTrigger));
			Enum->SetMetaData(TEXT("Hidden"), TEXT("Hidden"), int32(EBSAConditionTarget::CT_InstanceLockPart));
		}
	}
}


void FDecisionTreeEditor::RegisterTabSpawners(const TSharedRef<FTabManager>& InTabManager)
{
	WorkspaceMenuCategory = InTabManager->AddLocalWorkspaceMenuCategory(LOCTEXT("WorkspaceMenu_DecisionTreeEditor", "DecisionTree Editor"));
	auto WorkspaceMenuCategoryRef = WorkspaceMenuCategory.ToSharedRef();

	FAssetEditorToolkit::RegisterTabSpawners(InTabManager);

	// 数据可视化面板
	InTabManager->RegisterTabSpawner
	(
		FDecisionTreeEditorTabs::ViewportID, FOnSpawnTab::CreateSP(this, &FDecisionTreeEditor::SpawnTab_Viewport))
		.SetDisplayName(LOCTEXT("GraphCanvasTab", "Viewport"))
		.SetGroup(WorkspaceMenuCategoryRef)
		.SetIcon(FSlateIcon(FAppStyle::GetAppStyleSetName(), "GraphEditor.EventGraph_16x")
	);

	// 属性细节面板
	InTabManager->RegisterTabSpawner
	(
		FDecisionTreeEditorTabs::PropertyID, FOnSpawnTab::CreateSP(this, &FDecisionTreeEditor::SpawnTab_Details))
		.SetDisplayName(LOCTEXT("DetailsTab", "Property"))
		.SetGroup(WorkspaceMenuCategoryRef)
		.SetIcon(FSlateIcon(FAppStyle::GetAppStyleSetName(), "LevelEditor.Tabs.Details")
	);
}


void FDecisionTreeEditor::UnregisterTabSpawners(const TSharedRef<FTabManager>& InTabManager)
{
	FAssetEditorToolkit::UnregisterTabSpawners(InTabManager);

	InTabManager->UnregisterTabSpawner(FDecisionTreeEditorTabs::ViewportID);
	InTabManager->UnregisterTabSpawner(FDecisionTreeEditorTabs::PropertyID);
	InTabManager->UnregisterTabSpawner(FDecisionTreeEditorTabs::SettingsID);
}

void FDecisionTreeEditor::OnClose()
{
	if (LuaEnv)
	{
        UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
	}

	if (DataExporter.IsValid())
	{
		DataExporter->RemoveFromRoot();
		DataExporter->MarkAsGarbage();
		DataExporter = nullptr;
	}

	// 回退特殊的屏蔽
	if (FDecisionTreeEditor::DecisionTreeNum == 1)
	{
		if (FProperty* Prop = UBSCondition::StaticClass()->FindPropertyByName(TEXT("Name")))
		{
			Prop->SetMetaData("EditCondition", "true");
			Prop->SetMetaData("EditConditionHides", "false");
		}

		if (DecisionTreeTemplate->IsA(UAutoSkillTreeTemplate::StaticClass()))
		{
			if (FProperty* Prop = UAutoSkillTreeEdge::StaticClass()->FindPropertyByName(TEXT("ConditionGroup")))
			{
				Prop->SetMetaData("EditCondition", "true");
				Prop->SetMetaData("EditConditionHides", "false");
			}

			if (FProperty* Prop = UAutoSkillTreeNode::StaticClass()->FindPropertyByName(TEXT("ConditionGroup")))
			{
				Prop->SetMetaData("EditCondition", "true");
				Prop->SetMetaData("EditConditionHides", "false");
			}

			UEnum* Enum = StaticEnum<EBSAConditionTarget>();
			Enum->SetMetaData(TEXT("Hidden"), TEXT("Hidden"), int32(EBSAConditionTarget::CT_AllTeamMember));
			Enum->SetMetaData(TEXT("Hidden"), TEXT("Hidden"), int32(EBSAConditionTarget::CT_AnyTeamMember));
			Enum->SetMetaData(TEXT("Hidden"), TEXT("Hidden"), int32(EBSAConditionTarget::CT_AllGrounpMember));
			Enum->SetMetaData(TEXT("Hidden"), TEXT("Hidden"), int32(EBSAConditionTarget::CT_AnyGroupMember));
			Enum->RemoveMetaData(TEXT("Hidden"), int32(EBSAConditionTarget::CT_TaskTarget));
			Enum->RemoveMetaData(TEXT("Hidden"), int32(EBSAConditionTarget::CT_InstanceInstigator));
			Enum->RemoveMetaData(TEXT("Hidden"), int32(EBSAConditionTarget::CT_InstanceTrigger));
			Enum->RemoveMetaData(TEXT("Hidden"), int32(EBSAConditionTarget::CT_InstanceLockPart));
		}
	}

	FAssetEditorToolkit::OnClose();
}

FName FDecisionTreeEditor::GetToolkitFName() const
{
	return FName("FDecisionTreeEditor");
}

FText FDecisionTreeEditor::GetBaseToolkitName() const
{
	return LOCTEXT("DecisionTreeEditorAppLabel", "DecisionTree Editor");
}

FText FDecisionTreeEditor::GetToolkitName() const
{
	const bool bDirtyState = DecisionTreeTemplate->GetOutermost()->IsDirty();

	FFormatNamedArguments Args;
	Args.Add(TEXT("DecisionTreeName"), FText::FromString(DecisionTreeTemplate->GetName()));
	Args.Add(TEXT("DirtyState"), bDirtyState ? FText::FromString(TEXT("*")) : FText::GetEmpty());
	return FText::Format(LOCTEXT("DecisionTreeEditorToolkitName", "{DecisionTreeName}{DirtyState}"), Args);
}

FText FDecisionTreeEditor::GetToolkitToolTipText() const
{
	return FAssetEditorToolkit::GetToolTipTextForObject(DecisionTreeTemplate.Get());
}

FLinearColor FDecisionTreeEditor::GetWorldCentricTabColorScale() const
{
	return FLinearColor::White;
}

FString FDecisionTreeEditor::GetWorldCentricTabPrefix() const
{
	return TEXT("DecisionTreeEditor");
}

FString FDecisionTreeEditor::GetDocumentationLink() const
{
	return TEXT("");
}

void FDecisionTreeEditor::SaveAsset_Execute()
{
	DecisionTreeTemplate->MarkPackageDirty();

	PreSaveExecute();

	ExportData();

	FAssetEditorToolkit::SaveAsset_Execute();
}

void FDecisionTreeEditor::AddReferencedObjects(FReferenceCollector& Collector)
{
	Collector.AddReferencedObject(DecisionTreeTemplate);
	Collector.AddReferencedObject(DecisionTreeTemplate->EdGraph);
}

TSharedRef<SDockTab> FDecisionTreeEditor::SpawnTab_Viewport(const FSpawnTabArgs& Args)
{
	check(Args.GetTabId() == FDecisionTreeEditorTabs::ViewportID);

	SAssignNew(ViewportTab, SDockTab).Label(LOCTEXT("ViewportTab_Title", "Viewport"));

	if (ViewportWidgetStack.Num() > 0)
		ViewportTab->SetContent(ViewportWidgetStack[0].ToSharedRef());

	return ViewportTab.ToSharedRef();
}

TSharedRef<SDockTab> FDecisionTreeEditor::SpawnTab_Details(const FSpawnTabArgs& Args)
{
	check(Args.GetTabId() == FDecisionTreeEditorTabs::PropertyID);

	TSharedPtr<SDockTab> TheTab = SNew(SDockTab)
		.Label(LOCTEXT("Details_Title", "Property"))
		[
			PropertyWidget.ToSharedRef()
		];

	TheTab->SetTabIcon(FAppStyle::GetBrush("LevelEditor.Tabs.Details"));

	return TheTab.ToSharedRef();
}

TSharedRef<SDockTab> FDecisionTreeEditor::SpawnTab_EditorSettings(const FSpawnTabArgs& Args)
{
	check(Args.GetTabId() == FDecisionTreeEditorTabs::SettingsID);

	TSharedPtr<SDockTab> TheTab = SNew(SDockTab)
		.Label(LOCTEXT("EditorSettings_Title", "Decision Tree Editor Setttings"))
		[
			EditorSettingsWidget.ToSharedRef()
		];

	TheTab->SetTabIcon(FAppStyle::GetBrush("LevelEditor.Tabs.Details"));

	return TheTab.ToSharedRef();
}

void FDecisionTreeEditor::CreateMainEditWidgets()
{
	// 创建节点编辑窗口
	CreateViewportWidget(TEXT("Decision Tree Editor"), DecisionTreeTemplate->EdGraph.Get());

	FDetailsViewArgs Args;
	Args.bHideSelectionTip = true;
	Args.NotifyHook = this;

	// 创建属性编辑窗口
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyWidget = PropertyModule.CreateDetailView(Args);
	PropertyWidget->SetObject(DecisionTreeTemplate.Get());
	PropertyWidget->OnFinishedChangingProperties().AddSP(this, &FDecisionTreeEditor::OnFinishedChangingProperties);
}

bool FDecisionTreeEditor::CreateViewportWidget(FString ViewportName, UEdGraph* OwnerGraph)
{
	FGraphAppearanceInfo AppearanceInfo;
	AppearanceInfo.CornerText = FText::FromString(ViewportName);

	SGraphEditor::FGraphEditorEvents InEvents;
	InEvents.OnSelectionChanged = SGraphEditor::FOnSelectionChanged::CreateSP(this, &FDecisionTreeEditor::OnSelectedNodesChanged);
	InEvents.OnNodeDoubleClicked = FSingleNodeEvent::CreateSP(this, &FDecisionTreeEditor::OnNodeDoubleClicked);

	TSharedPtr<SGraphEditor> NewViewPort;

	SAssignNew(NewViewPort, SGraphEditor)
		.AdditionalCommands(GraphEditorCommands)
		.IsEditable(true)
		.Appearance(AppearanceInfo)
		.GraphToEdit(OwnerGraph)
		.GraphEvents(InEvents)
		.AutoExpandActionMenu(true)
		.ShowGraphStateOverlay(false);

	if (NewViewPort.IsValid())
	{
		ViewportWidgetStack.Add(NewViewPort);
		return true;
	}
	else
		return false;

}


void FDecisionTreeEditor::BindCommands()
{
	const FDecisionTreeEditorCommands& Commands = FDecisionTreeEditorCommands::Get();
	const TSharedRef<FUICommandList>& UICommandList = GetToolkitCommands();

	UICommandList->MapAction(Commands.BackToPreviousGraph, FExecuteAction::CreateSP(this, &FDecisionTreeEditor::BackToPreviousGraph));

}

void FDecisionTreeEditor::CreateEdGraph(UObject* TheOwner, UEdGraph*& TheGraphPtr)
{
	// 如果该决策树还没有可视化界面，则进行创建
	if (!TheGraphPtr)
	{
		TheGraphPtr = CastChecked<UEdGraph_DecisionTree>
		(
			FBlueprintEditorUtils::CreateNewGraph
			(
				TheOwner, NAME_None,
				UEdGraph_DecisionTree::StaticClass(),
				UDecisionTreeEditorSchema::StaticClass()
			)
		);
	}
}

void FDecisionTreeEditor::CreateCommandList()
{
	if (GraphEditorCommands.IsValid())
		return;

	GraphEditorCommands = MakeShareable(new FUICommandList);

	GraphEditorCommands->MapAction
	(
		FGenericCommands::Get().SelectAll,
		FExecuteAction::CreateRaw(this, &FDecisionTreeEditor::SelectAllNodes),
		FCanExecuteAction::CreateRaw(this, &FDecisionTreeEditor::CanSelectAllNodes)
	);

	GraphEditorCommands->MapAction
	(
		FGenericCommands::Get().Delete,
		FExecuteAction::CreateRaw(this, &FDecisionTreeEditor::DeleteSelectedNodes),
		FCanExecuteAction::CreateRaw(this, &FDecisionTreeEditor::CanDeleteNodes)
	);

	GraphEditorCommands->MapAction
	(
		FGenericCommands::Get().Copy,
		FExecuteAction::CreateRaw(this, &FDecisionTreeEditor::CopySelectedNodes),
		FCanExecuteAction::CreateRaw(this, &FDecisionTreeEditor::CanCopyNodes)
	);

	GraphEditorCommands->MapAction
	(
		FGenericCommands::Get().Cut,
		FExecuteAction::CreateRaw(this, &FDecisionTreeEditor::CutSelectedNodes),
		FCanExecuteAction::CreateRaw(this, &FDecisionTreeEditor::CanCutNodes)
	);

	GraphEditorCommands->MapAction
	(
		FGenericCommands::Get().Paste,
		FExecuteAction::CreateRaw(this, &FDecisionTreeEditor::PasteNodes),
		FCanExecuteAction::CreateRaw(this, &FDecisionTreeEditor::CanPasteNodes)
	);

	GraphEditorCommands->MapAction
	(
		FGenericCommands::Get().Duplicate,
		FExecuteAction::CreateRaw(this, &FDecisionTreeEditor::DuplicateNodes),
		FCanExecuteAction::CreateRaw(this, &FDecisionTreeEditor::CanDuplicateNodes)
	);

	GraphEditorCommands->MapAction
	(
		FGenericCommands::Get().Rename,
		FExecuteAction::CreateSP(this, &FDecisionTreeEditor::OnRenameNode),
		FCanExecuteAction::CreateSP(this, &FDecisionTreeEditor::CanRenameNodes)
	);
}

TSharedPtr<SGraphEditor> FDecisionTreeEditor::GetCurrentGraphEditor() const
{
	return ViewportWidgetStack.Last();
}

FGraphPanelSelectionSet FDecisionTreeEditor::GetSelectedNodes() const
{
	FGraphPanelSelectionSet CurrentSelection;
	TSharedPtr<SGraphEditor> FocusedGraphEd = GetCurrentGraphEditor();
	if (FocusedGraphEd.IsValid())
	{
		CurrentSelection = FocusedGraphEd->GetSelectedNodes();
	}

	return CurrentSelection;
}

void FDecisionTreeEditor::SelectAllNodes()
{
	TSharedPtr<SGraphEditor> CurrentGraphEditor = GetCurrentGraphEditor();
	if (CurrentGraphEditor.IsValid())
		CurrentGraphEditor->SelectAllNodes();
}

bool FDecisionTreeEditor::CanSelectAllNodes()
{
	return true;
}

void FDecisionTreeEditor::DeleteNodes(FGraphPanelSelectionSet& SelectedNodes)
{
	for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
	{
		UEdGraphNode* EdNode = Cast<UEdGraphNode>(*NodeIt);
		if (!EdNode || !EdNode->CanUserDeleteNode())
			continue;

		// 如果是决策树节点，则有可能要断开节点之间的链接关系
		if (UEdNode_DecisionTreeNode* EdNode_Node = Cast<UEdNode_DecisionTreeNode>(EdNode))
		{
			EdNode_Node->Modify();

			if (const UEdGraphSchema* Schema = EdNode_Node->GetSchema())
				Schema->BreakNodeLinks(*EdNode_Node);

			EdNode_Node->DestroyNode();
		}
		else
		{
			EdNode->Modify();
			EdNode->DestroyNode();
		}
	}
}

void FDecisionTreeEditor::DeleteSelectedNodes()
{
	TSharedPtr<SGraphEditor> CurrentGraphEditor = GetCurrentGraphEditor();
	if (!CurrentGraphEditor.IsValid())
		return;

	const FScopedTransaction Transaction(FGenericCommands::Get().Delete->GetDescription());

	CurrentGraphEditor->GetCurrentGraph()->Modify();

	FGraphPanelSelectionSet SelectedNodes = CurrentGraphEditor->GetSelectedNodes();
	CurrentGraphEditor->ClearSelectionSet();

	DeleteNodes(SelectedNodes);
}

bool FDecisionTreeEditor::CanDeleteNodes()
{
	const FGraphPanelSelectionSet SelectedNodes = GetSelectedNodes();
	for (FGraphPanelSelectionSet::TConstIterator SelectedIter(SelectedNodes); SelectedIter; ++SelectedIter)
	{
		UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter);
		if (Node && Node->CanUserDeleteNode())
			return true;
	}

	return false;
}

void FDecisionTreeEditor::DeleteSelectedDuplicatableNodes()
{
	TSharedPtr<SGraphEditor> CurrentGraphEditor = GetCurrentGraphEditor();
	if (!CurrentGraphEditor.IsValid())
		return;
	

	const FGraphPanelSelectionSet OldSelectedNodes = CurrentGraphEditor->GetSelectedNodes();
	CurrentGraphEditor->ClearSelectionSet();

	for (FGraphPanelSelectionSet::TConstIterator SelectedIter(OldSelectedNodes); SelectedIter; ++SelectedIter)
	{
		UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter);
		if (Node && Node->CanDuplicateNode())
			CurrentGraphEditor->SetNodeSelection(Node, true);
	}

	DeleteSelectedNodes();

	CurrentGraphEditor->ClearSelectionSet();

	for (FGraphPanelSelectionSet::TConstIterator SelectedIter(OldSelectedNodes); SelectedIter; ++SelectedIter)
	{
		if (UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter))
			CurrentGraphEditor->SetNodeSelection(Node, true);
	}
}

void FDecisionTreeEditor::CutSelectedNodes()
{
	CopySelectedNodes();
	DeleteSelectedDuplicatableNodes();
}

bool FDecisionTreeEditor::CanCutNodes()
{
	return CanCopyNodes() && CanDeleteNodes();
}

void FDecisionTreeEditor::CopySelectedNodes()
{
	FGraphPanelSelectionSet SelectedNodes = GetSelectedNodes();

	FString ExportedText;

	for (FGraphPanelSelectionSet::TIterator SelectedIter(SelectedNodes); SelectedIter; ++SelectedIter)
	{
		UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter);
		if (!Node)
		{
			SelectedIter.RemoveCurrent();
			continue;
		}

		// 如果要复制一条边，要检查它的连接点是否需要被复制
		if (UEdNode_DecisionTreeEdge* EdNode_Edge = Cast<UEdNode_DecisionTreeEdge>(*SelectedIter))
		{
			UEdNode_DecisionTreeNode* StartNode = EdNode_Edge->GetStartNode();
			UEdNode_DecisionTreeNode* EndNode = EdNode_Edge->GetEndNode();

			if (!SelectedNodes.Contains(StartNode) || !SelectedNodes.Contains(EndNode))
			{
				SelectedIter.RemoveCurrent();
				continue;
			}
		}

		Node->PrepareForCopying();
	}

	FEdGraphUtilities::ExportNodesToText(SelectedNodes, ExportedText);
	FPlatformApplicationMisc::ClipboardCopy(*ExportedText);
}

bool FDecisionTreeEditor::CanCopyNodes()
{
	const FGraphPanelSelectionSet SelectedNodes = GetSelectedNodes();
	for (FGraphPanelSelectionSet::TConstIterator SelectedIter(SelectedNodes); SelectedIter; ++SelectedIter)
	{
		UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter);
		if (Node && Node->CanDuplicateNode())
			return true;
	}

	return false;
}

void FDecisionTreeEditor::PasteNodes()
{
	TSharedPtr<SGraphEditor> CurrentGraphEditor = GetCurrentGraphEditor();

	if (CurrentGraphEditor.IsValid())
		PasteNodesHere(CurrentGraphEditor->GetPasteLocation());
}

void FDecisionTreeEditor::PasteNodesHere(const FVector2D& Location)
{
	TSharedPtr<SGraphEditor> CurrentGraphEditor = GetCurrentGraphEditor();
	if (!CurrentGraphEditor.IsValid())
		return;

	UEdGraph* EdGraph = CurrentGraphEditor->GetCurrentGraph();
	if (!EdGraph)
		return;

	const FScopedTransaction Transaction(FGenericCommands::Get().Paste->GetDescription());
	EdGraph->Modify();

	CurrentGraphEditor->ClearSelectionSet();

	FString TextToImport;
	FPlatformApplicationMisc::ClipboardPaste(TextToImport);

	TSet<UEdGraphNode*> PastedNodes;
	FEdGraphUtilities::ImportNodesFromText(EdGraph, TextToImport, PastedNodes);

	// 创建新的数据节点对象，从旧的对象中获取数据并进行复制
	for (TSet<UEdGraphNode*>::TIterator It(PastedNodes); It; ++It)
	{
		UEdGraphNode* Node = *It;

		// 处理节点
		if (UEdNode_DecisionTreeNode* TmpNode = Cast<UEdNode_DecisionTreeNode>(Node))
		{
			UDecisionTreeNode* OriginNode = TmpNode->GraphNode;
			TmpNode->GraphNode = NewObject<UDecisionTreeNode>(DecisionTreeTemplate.Get(), OriginNode->GetClass());
			TmpNode->GraphNode->CopyData(OriginNode);

			TmpNode->GraphNode->RefreshNodeTitle();
		}
		// 处理边
		else if (UEdNode_DecisionTreeEdge* TmpEdge = Cast<UEdNode_DecisionTreeEdge>(Node))
		{
			UDecisionTreeEdge* OriginEdge = TmpEdge->GraphEdge;
			TmpEdge->GraphEdge = NewObject<UDecisionTreeEdge>(DecisionTreeTemplate.Get(), OriginEdge->GetClass());
			TmpEdge->GraphEdge->CopyData(OriginEdge);

			TmpEdge->GraphEdge->RefreshEdgeTitle();
		}
	}

	// 计算所有复制节点的平均位置
	FVector2D AvgNodePosition(0.0f, 0.0f);
	float InvNumNodes = 1.0f / float(PastedNodes.Num());
	for (TSet<UEdGraphNode*>::TIterator It(PastedNodes); It; ++It)
	{
		UEdGraphNode* Node = *It;
		AvgNodePosition.X += Node->NodePosX;
		AvgNodePosition.Y += Node->NodePosY;
	}
	AvgNodePosition.X *= InvNumNodes;
	AvgNodePosition.Y *= InvNumNodes;

	// 将复制出来的节点放到正确的位置上
	for (TSet<UEdGraphNode*>::TIterator It(PastedNodes); It; ++It)
	{
		UEdGraphNode* Node = *It;
		CurrentGraphEditor->SetNodeSelection(Node, true);

		Node->NodePosX = (Node->NodePosX - AvgNodePosition.X) + Location.X;
		Node->NodePosY = (Node->NodePosY - AvgNodePosition.Y) + Location.Y;

		Node->SnapToGrid(16);

		Node->CreateNewGuid();
	}

	// 标记相关文件需要保存
	CurrentGraphEditor->NotifyGraphChanged();
	UObject* GraphOwner = EdGraph->GetOuter();
	if (GraphOwner)
	{
		GraphOwner->PostEditChange();
		GraphOwner->MarkPackageDirty();
	}
}

bool FDecisionTreeEditor::CanPasteNodes()
{
	TSharedPtr<SGraphEditor> CurrentGraphEditor = GetCurrentGraphEditor();
	if (!CurrentGraphEditor.IsValid())
		return false;

	FString ClipboardContent;
	FPlatformApplicationMisc::ClipboardPaste(ClipboardContent);

	return FEdGraphUtilities::CanImportNodesFromText(CurrentGraphEditor->GetCurrentGraph(), ClipboardContent);
}

void FDecisionTreeEditor::DuplicateNodes()
{
	CopySelectedNodes();
	PasteNodes();
}

bool FDecisionTreeEditor::CanDuplicateNodes()
{
	return CanCopyNodes();
}

void FDecisionTreeEditor::OpenSelectNode()
{
	FGraphPanelSelectionSet CurSelectInfo = GetSelectedNodes();
	if (UEdNode_DecisionTreeNode* EdGraphNode = Cast<UEdNode_DecisionTreeNode>(CurSelectInfo.Array()[0]))
	{
		if (UDecisionTreeGraphNode* GraphNode = Cast<UDecisionTreeGraphNode>(EdGraphNode->GraphNode))
		{
			bool CanOpenSubGraph = false;
			if (GraphNode->TypeMessage)
				CanOpenSubGraph = true;
			else
			{
				// 尝试找到默认的类型信息
				GraphNode->TryFindDefaultTypeMessage();

				if (!GraphNode->TypeMessage)
				{
					FClassViewerInitializationOptions Options;
					Options.Mode = EClassViewerMode::ClassPicker;
					Options.bIsActorsOnly = false;
					Options.bIsBlueprintBaseOnly = true;
					Options.ClassFilters.Add(MakeShared<FDTTypeFilter>());
					Options.ExtraPickerCommonClasses.Add(NULL);

					UClass* ChosenClass = NULL;
					const bool bPressOk = SClassPickerDialog::PickClass
					(
						LOCTEXT("SetSubGraphType", "Graph Type Message"),
						Options, ChosenClass, UDTTypeMessage::StaticClass()
					);

					if (bPressOk && ChosenClass)
					{
						CanOpenSubGraph = true;
						GraphNode->TypeMessage = ChosenClass;
					}
				}
				else
					CanOpenSubGraph = true;
			}


			CreateEdGraph(GraphNode, GraphNode->EdGraph);
			CreateViewportWidget(TEXT("Graph Node Editor"), GraphNode->EdGraph);


			if (CanOpenSubGraph && ViewportWidgetStack.Num() > 0)
				ViewportTab->SetContent(ViewportWidgetStack.Last().ToSharedRef());
		}
	}
}

bool FDecisionTreeEditor::CanOpenSelectNode()
{
	FGraphPanelSelectionSet CurSelectInfo = GetSelectedNodes();
	if (CurSelectInfo.Num() == 1)
	{
		if (UEdNode_DecisionTreeNode* GraphNode = Cast<UEdNode_DecisionTreeNode>(CurSelectInfo.Array()[0]))
		{
			if (GraphNode->GraphNode->GetClass()->IsChildOf<UDecisionTreeGraphNode>())
				return true;
		}
	}

	return false;
}

void FDecisionTreeEditor::BackToPreviousGraph()
{
	if (ViewportWidgetStack.Num() > 1)
	{
		ViewportWidgetStack.RemoveAt(ViewportWidgetStack.Num() - 1);
		ViewportTab->SetContent(ViewportWidgetStack.Last().ToSharedRef());
	}
	else if (ViewportWidgetStack.Num() > 0)
		ViewportTab->SetContent(ViewportWidgetStack.Last().ToSharedRef());
}

void FDecisionTreeEditor::GraphSettings()
{
	PropertyWidget->SetObject(DecisionTreeTemplate.Get());
}

bool FDecisionTreeEditor::CanGraphSettings() const
{
	return true;
}

void FDecisionTreeEditor::OnRenameNode()
{
	TSharedPtr<SGraphEditor> CurrentGraphEditor = GetCurrentGraphEditor();
	if (CurrentGraphEditor.IsValid())
	{
		const FGraphPanelSelectionSet SelectedNodes = GetSelectedNodes();
		for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
		{
			UEdGraphNode* SelectedNode = Cast<UEdGraphNode>(*NodeIt);
			if (SelectedNode != NULL && SelectedNode->bCanRenameNode)
			{
				CurrentGraphEditor->IsNodeTitleVisible(SelectedNode, true);
				break;
			}
		}
	}
}

bool FDecisionTreeEditor::CanRenameNodes() const
{
	return true;
}

void FDecisionTreeEditor::OnSelectedNodesChanged(const TSet<UObject*>& NewSelection)
{
	TArray<UObject*> Selection;

	for (UObject* SelectionEntry : NewSelection)
		Selection.Add(SelectionEntry);

	if (Selection.Num() == 0)
		PropertyWidget->SetObject(DecisionTreeTemplate.Get());
	else
		PropertyWidget->SetObjects(Selection);
}

void FDecisionTreeEditor::OnNodeDoubleClicked(UEdGraphNode* Node)
{
	if (CanOpenSelectNode())
		OpenSelectNode();
}

void FDecisionTreeEditor::OnFinishedChangingProperties(const FPropertyChangedEvent& PropertyChangedEvent)
{
	return;
}

void FDecisionTreeEditor::PreSaveExecute()
{
	DecisionTreeTemplate->ID = FCString::Atoi(*DecisionTreeTemplate->GetName());

	RefreshGraphMessage(DecisionTreeTemplate->EdGraph.Get());
}

void FDecisionTreeEditor::CheckGraphNodeType(UEdGraph* CurSaveGraph)
{
	if (!CurSaveGraph)
		return;

	UDTTypeMessage* CurDTMsg = Cast<UDTTypeMessage>(DecisionTreeTemplate->TypeMessage.GetDefaultObject());
	if (!CurDTMsg)
		return;

	// 删除类型不对的节点
	FGraphPanelSelectionSet WillDeleteNodes;
	for (int32 i = 0; i < CurSaveGraph->Nodes.Num(); ++i)
	{
		if (UEdNode_DecisionTreeNode* CurEdNode = Cast<UEdNode_DecisionTreeNode>(CurSaveGraph->Nodes[i]))
		{
			// 检查节点类型
			if (!CurDTMsg->NodeTypes.Contains(CurEdNode->GraphNode->GetClass()))
			{
				WillDeleteNodes.Add(CurEdNode);
				continue;
			}
		}

		// 检查边类型
		if (UEdNode_DecisionTreeEdge* CurEdEdge = Cast<UEdNode_DecisionTreeEdge>(CurSaveGraph->Nodes[i]))
		{
			if (CurDTMsg->EdgeType != CurEdEdge->GraphEdge->GetClass())
				WillDeleteNodes.Add(CurEdEdge);
		}
	}
	DeleteNodes(WillDeleteNodes);
}

void FDecisionTreeEditor::RefreshGraphMessage(UEdGraph* CurSaveGraph)
{
	if (!CurSaveGraph)
		return;


	// 递归刷新子图表
	for (int32 i = 0; i < CurSaveGraph->Nodes.Num(); ++i)
	{
		if (UEdNode_DecisionTreeNode* CurEdNode = Cast<UEdNode_DecisionTreeNode>(CurSaveGraph->Nodes[i]))
		{
			if (UDecisionTreeGraphNode* CurNode = Cast<UDecisionTreeGraphNode>(CurEdNode->GraphNode))
			{
				RefreshGraphMessage(CurNode->EdGraph);
			}
		}
	}


	// 先检查图表中的节点类型是否合法
	CheckGraphNodeType(CurSaveGraph);


	// 对节点按照“从左到右”进行排序
	CurSaveGraph->Nodes.Sort
	(
		[](const UEdGraphNode& A, const UEdGraphNode& B)
		{
			return A.NodePosX < B.NodePosX;
		}
	);


	// 刷新图表信息
	if (UDecisionTreeGraphNode* CurNode = Cast<UDecisionTreeGraphNode>(CurSaveGraph->GetOuter()))
	{
		CurNode->InitSaver();

		for (int32 i = 0; i < CurSaveGraph->Nodes.Num(); ++i)
		{
			if (UEdNode_DecisionTreeEdge* CheckEdEdge = Cast<UEdNode_DecisionTreeEdge>(CurSaveGraph->Nodes[i]))
			{
				CurNode->AddEdgeMessage(CheckEdEdge->GetStartNode()->GraphNode, CheckEdEdge->GetEndNode()->GraphNode, CheckEdEdge->GraphEdge);
			}
		}

		CollectRootMessage(CurSaveGraph, CurNode->RootNodes);

		CurNode->RefreshLogicMessage();
	}
	else if (UDecisionTreeTemplate* CurTemp = Cast<UDecisionTreeTemplate>(CurSaveGraph->GetOuter()))
	{
		CurTemp->InitSaver();

		for (int32 i = 0; i < CurSaveGraph->Nodes.Num(); ++i)
		{
			if (UEdNode_DecisionTreeEdge* CheckEdEdge = Cast<UEdNode_DecisionTreeEdge>(CurSaveGraph->Nodes[i]))
			{
				CurTemp->AddEdgeMessage(CheckEdEdge->GetStartNode()->GraphNode, CheckEdEdge->GetEndNode()->GraphNode, CheckEdEdge->GraphEdge);
			}
		}

		CollectRootMessage(CurSaveGraph, CurTemp->RootNodes);

		CurTemp->RefreshLogicMessage();
	}
}

void FDecisionTreeEditor::CollectRootMessage(UEdGraph* CurSaveGraph, TArray<UDecisionTreeNode*>& RootNodes)
{
	// 如果没有任何边的终点是该节点，则认为该节点是一个根节点
	for (int32 i = 0; i < CurSaveGraph->Nodes.Num(); ++i)
	{
		if (UEdNode_DecisionTreeNode* CheckEdNode = Cast<UEdNode_DecisionTreeNode>(CurSaveGraph->Nodes[i]))
		{
			if (CheckEdNode->GraphNode && CheckEdNode->GraphNode->InEdges.Num() <= 0)
				RootNodes.Add(CheckEdNode->GraphNode);
		}
	}
}

void FDecisionTreeEditor::RegisterToolbarTab(const TSharedRef<FTabManager>& InTabManager)
{
	FAssetEditorToolkit::RegisterTabSpawners(InTabManager);
}



#pragma region Export
void FDecisionTreeEditor::ExportData()
{
	if (DataExporter.IsValid())
	{
		FString LuaPath = FPaths::ProjectContentDir() + DataExporter->ExportPath + FString::FromInt(DecisionTreeTemplate->ID) + TEXT(".lua");

		if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*LuaPath))
		{
			FFileHelper::SaveStringToFile(FString(), *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
		}

		FString DataString = DataExporter->ExportDecisionTree(DecisionTreeTemplate.Get());

		FFileHelper::SaveStringToFile(DataString, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
	}
}

#pragma endregion Export


#undef LOCTEXT_NAMESPACE
