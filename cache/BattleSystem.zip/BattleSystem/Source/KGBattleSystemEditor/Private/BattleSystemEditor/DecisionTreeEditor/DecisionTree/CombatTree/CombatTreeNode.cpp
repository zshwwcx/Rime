#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeNode.h"

#include "BattleSystem/BSFunctionLibrary.h" 



UCombatTreeRootNode::UCombatTreeRootNode()
{
	NodeTitle = FText::FromString(TEXT("Start"));
}

#if WITH_EDITOR
void UCombatTreeRootNode::SetNodeTitle(const FText& NewTitle)
{
	
}

bool UCombatTreeRootNode::CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage)
{
	if (PinInformations.IsValidIndex(SelfPinID) && !PinInformations[SelfPinID].bIsOutput)
	{
		return false;
	}

	return true;
}

bool UCombatTreeRootNode::CanUserDelete() const
{
	return false;
}

#endif






UCombatTreeNode::UCombatTreeNode()
{

}

#if WITH_EDITOR
void UCombatTreeNode::SetNodeTitle(const FText& NewTitle)
{
	NodeTitle = NewTitle;
}

void UCombatTreeNode::CopyData(UDecisionTreeNode* OtherNode)
{
	Super::CopyData(OtherNode);

	if (UCombatTreeNode* Other = Cast<UCombatTreeNode>(OtherNode))
	{
		ReleaseSkillAsset = Other->ReleaseSkillAsset;
	}
}

void UCombatTreeNode::RefreshNodeTitle()
{
	FString Title;

	if (bCheckReleaseCondition)
	{
		Title += TEXT("Neec Check Release Condition !\n");
	}

	if (!bFinishWhenRecover)
	{
		Title += TEXT("Will Finish Till Instance End !\n");
	}
	Title += TEXT("Release ");
	Title += ReleaseSkillAsset.GetAssetName();
	// if (UASASkillAsset* Skill = ReleaseSkillAsset.LoadSynchronous())
	// {
	// 	Title += TEXT("  ");
	// 	Title += Skill->Name.ToString();
	// }

	NodeTitle = FText::FromString(Title);
}

void UCombatTreeNode::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	RefreshNodeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UCombatTreeNode::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

#endif
