#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeEdge.h"



#if WITH_EDITOR
void UCombatTreeEdge::CopyData(UDecisionTreeEdge* OtherNode)
{
	Super::CopyData(OtherNode);

	if (UCombatTreeEdge* Other = Cast<UCombatTreeEdge>(OtherNode))
	{
		ComboWindows.Empty();
		ComboWindows.Append(Other->ComboWindows);
	}
}

void UCombatTreeEdge::RefreshEdgeTitle()
{
	FString Title;

	if (ComboWindows.Num() > 0)
	{
		EdgeMessageSize.X = 200.0f;
		for (int32 i = 0; i < ComboWindows.Num(); ++i)
		{
			Title += TEXT("After ");
			Title += ComboWindows[i].GetAssetName();
			// if (UASASkillAsset* Skill = ComboWindows[i].LoadSynchronous())
			// {
			// 	Title += TEXT("  ");
			// 	Title += Skill->Name.ToString();
			// }
			Title += TEXT("\n");
		}
	}
	else
	{
		EdgeMessageSize.X = 100.0f;
		Title = TEXT("No Condition");
	}

	EdgeMessageSize.Y = FMath::Max(30.0f, ComboWindows.Num() * 16.0f);
	EdgeTitle = FText::FromString(Title);
}

void UCombatTreeEdge::SetEdgeTitle(const FText& NewTitle)
{

}

void UCombatTreeEdge::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	RefreshEdgeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif
