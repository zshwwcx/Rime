#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeEdge.h"

#include "EdGraph/EdGraph.h"
#include "EdGraph/EdGraphPin.h"

#include "BattleSystemEditor/DecisionTreeEditor/EdNode_DecisionTreeNode.h"

#define LOCTEXT_NAMESPACE "EdNode_DecisionTreeEdge"

UEdNode_DecisionTreeEdge::UEdNode_DecisionTreeEdge()
{
	
}

UEdNode_DecisionTreeEdge::~UEdNode_DecisionTreeEdge()
{
	if (GraphEdge && GraphEdge->IsValidLowLevel() && !IsValid(GraphEdge))
		GraphEdge->MarkAsGarbage();
}

void UEdNode_DecisionTreeEdge::AllocateDefaultPins()
{
	UEdGraphPin* Inputs = CreatePin(EGPD_Input, TEXT("Edge"), FName(), TEXT("In"));
	Inputs->bHidden = true;

	UEdGraphPin* Outputs = CreatePin(EGPD_Output, TEXT("Edge"), FName(), TEXT("Out"));
	Outputs->bHidden = true;
}

FText UEdNode_DecisionTreeEdge::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	if (!GraphEdge)
		return Super::GetNodeTitle(TitleType);
	else
		return GraphEdge->GetEdgeTitle();
}

void UEdNode_DecisionTreeEdge::PinConnectionListChanged(UEdGraphPin* Pin)
{
	if (Pin->LinkedTo.Num() == 0)
	{
		Modify();

		if (UEdGraph* ParentGraph = GetGraph())
			ParentGraph->Modify();

		DestroyNode();
	}
}

void UEdNode_DecisionTreeEdge::PrepareForCopying()
{
	
}

void UEdNode_DecisionTreeEdge::CreateConnections(UEdGraphPin* StartPin, UEdGraphPin* EndPin)
{
	Pins[0]->Modify();
	Pins[0]->LinkedTo.Empty();
	Pins[0]->MakeLinkTo(StartPin);

	Pins[1]->Modify();
	Pins[1]->LinkedTo.Empty();
	Pins[1]->MakeLinkTo(EndPin);
}

UEdNode_DecisionTreeNode* UEdNode_DecisionTreeEdge::GetStartNode()
{
	if (Pins[0]->LinkedTo.Num() > 0)
		return Cast<UEdNode_DecisionTreeNode>(Pins[0]->LinkedTo[0]->GetOwningNode());
	else
		return NULL;
}

UEdNode_DecisionTreeNode* UEdNode_DecisionTreeEdge::GetEndNode()
{
	if (Pins[1]->LinkedTo.Num() > 0)
		return Cast<UEdNode_DecisionTreeNode>(Pins[1]->LinkedTo[0]->GetOwningNode());
	else
		return NULL;
}

int32 UEdNode_DecisionTreeEdge::GetNodeDepth()
{
	UEdNode_DecisionTreeNode* StartNode = GetStartNode();
	if (StartNode)
		return StartNode->GetNodeDepth();

	return -1;
}

void UEdNode_DecisionTreeEdge::ResetEdgeMessage()
{
	
}

void UEdNode_DecisionTreeEdge::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (SEdEdge.IsValid())
	{
		SEdEdge.Pin()->UpdateGraphNode();
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#undef LOCTEXT_NAMESPACE

