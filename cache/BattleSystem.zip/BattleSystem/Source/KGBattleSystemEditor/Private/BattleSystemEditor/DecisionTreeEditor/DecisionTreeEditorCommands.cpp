#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeEditorCommands.h"

#define LOCTEXT_NAMESPACE "EditorCommands_GenericGraph"

void FDecisionTreeEditorCommands::RegisterCommands()
{
	UI_COMMAND(BackToPreviousGraph, "Back To Previous Graph", "Back To Previous Graph", EUserInterfaceActionType::Button, FInputChord(EKeys::Q));
}

#undef LOCTEXT_NAMESPACE
