#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/CombatTree/CombatTreeTemplate.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeExporter.h"



UCombatTreeTypeMessage::UCombatTreeTypeMessage()
{
	bAllowCycle = true;
	ExporterType = UCombatTreeExporter::StaticClass();
	FirstNodeType = UCombatTreeRootNode::StaticClass();
	NeedLoadAssetTypes.Add(UBSASkillAsset::StaticClass());
	DataCollectorType = UDecisionTreeDataCollector::StaticClass();

#if WITH_EDITORONLY_DATA
	NodeTypes.Add(UCombatTreeNode::StaticClass());
	EdgeType = UCombatTreeEdge::StaticClass();
#endif
}
