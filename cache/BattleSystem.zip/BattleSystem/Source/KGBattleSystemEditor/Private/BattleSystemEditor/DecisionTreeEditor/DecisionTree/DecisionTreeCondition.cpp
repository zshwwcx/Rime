#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeCondition.h"



UDecisionTreeConditionGroup::UDecisionTreeConditionGroup()
{
	Name = TEXT("ConditionGroup");
}

bool UDecisionTreeConditionGroup::CheckCondition(const FBSConditionData& InData)
{
	bool Result = PerformCheck(InData);

	return bIsNot ? !Result : Result;
}

bool UDecisionTreeConditionGroup::PerformCheck_Implementation(const FBSConditionData& InData) const
{
	return BSConditionFunc::CheckConditionList<UDecisionTreeCondition>(ConditionList, InData, bUseAndLogic);
}

#if WITH_EDITOR
bool UDecisionTreeConditionGroup::CopyData(UBSCondition* OtherCondition)
{
	if (!Super::CopyData(OtherCondition))
		return false;

	UDecisionTreeConditionGroup* OtherGroup = Cast<UDecisionTreeConditionGroup>(OtherCondition);

	bUseAndLogic = OtherGroup->bUseAndLogic;

	BSConditionFunc::CopyConditionList<UDecisionTreeCondition>(this, ConditionList, OtherGroup->ConditionList);

	return true;
}

FString UDecisionTreeConditionGroup::GetConditionDescription()
{
	return BSConditionFunc::GetConditionListDescription(ConditionList);
}

#endif






UAutoSkillTreeConditionGroup::UAutoSkillTreeConditionGroup()
{
	Name = TEXT("ConditionGroup");
}

// bool UAutoSkillTreeConditionGroup::CheckCondition(const FBSConditionData& InData)
// {
// 	bool Result = PerformCheck(InData);
//
// 	return bIsNot ? !Result : Result;
// }
//
// bool UAutoSkillTreeConditionGroup::PerformCheck_Implementation(const FBSConditionData& InData) const
// {
// 	return BSConditionFunc::CheckConditionList<UBSCondition>(ConditionList, InData, bUseAndLogic);
// }
//
// #if WITH_EDITOR
// bool UAutoSkillTreeConditionGroup::CopyData(UBSCondition* OtherCondition)
// {
// 	if (!Super::CopyData(OtherCondition))
// 		return false;
//
// 	UAutoSkillTreeConditionGroup* OtherGroup = Cast<UAutoSkillTreeConditionGroup>(OtherCondition);
//
// 	bUseAndLogic = OtherGroup->bUseAndLogic;
//
// 	BSConditionFunc::CopyConditionList<UBSCondition>(this, ConditionList, OtherGroup->ConditionList);
//
// 	return true;
// }
//
// FString UAutoSkillTreeConditionGroup::GetConditionDescription()
// {
// 	return BSConditionFunc::GetConditionListDescription(ConditionList);
// }
//
// void UAutoSkillTreeConditionGroup::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
// {
// }
//
// #endif