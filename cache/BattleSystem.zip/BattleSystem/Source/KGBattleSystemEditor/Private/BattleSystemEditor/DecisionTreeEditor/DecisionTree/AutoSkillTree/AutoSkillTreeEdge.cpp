#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/AutoSkillTree/AutoSkillTreeEdge.h"



UAutoSkillTreeEdge::UAutoSkillTreeEdge()
{
}

#if WITH_EDITOR
void UAutoSkillTreeEdge::CopyData(UDecisionTreeEdge* OtherNode)
{
	Super::CopyData(OtherNode);

}

void UAutoSkillTreeEdge::RefreshEdgeTitle()
{
	FString Title;
	int32 Layers = 0;

	if (AutoSkillConditionGroup)
	{
		Title += AutoSkillConditionGroup->Name.ToString() + TEXT("\n");
		Layers = 1 + UAutoSkillTreeEdge::GetTitle(AutoSkillConditionGroup->Conditions, 1, Title);
	}
	else
	{
		Title = TEXT("No Condition");
		Layers = 1;
	}

	EdgeMessageSize.X = 300.0f;
	EdgeMessageSize.Y = FMath::Max(30.0f, Layers * 16.0f);

	EdgeTitle = FText::FromString(Title);
}

void UAutoSkillTreeEdge::SetEdgeTitle(const FText& NewTitle)
{
	RefreshEdgeTitle();
}

void UAutoSkillTreeEdge::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	RefreshEdgeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}


int32 UAutoSkillTreeEdge::GetTitle(TArray<UASACondition*> InConditions, int32 InStartSpace, FString& InTitle)
{
	int32 Layers = 0;
	for (int32 i = 0; i < InConditions.Num(); i++)
	{
		if (!IsValid(InConditions[i]))
		{
			continue;
		}

		if (UAutoSkillTreeConditionGroup* ConditionGroup = Cast<UAutoSkillTreeConditionGroup>(InConditions[i]))
		{
			for (int32 j = 0; j < InStartSpace; j++)
			{
				InTitle += TEXT("*");
			}
			InTitle += ConditionGroup->Name.ToString() + TEXT("\n");

			Layers += 1 + UAutoSkillTreeEdge::GetTitle(ConditionGroup->Conditions, InStartSpace + 1, InTitle);
		}
		else
		{
			for (int32 j = 0; j < InStartSpace; j++)
			{
				InTitle += TEXT("*");
			}
			InTitle += InConditions[i]->GetName() + TEXT("\n");
			Layers += 1;
		}
	}

	return Layers;
}
#endif
