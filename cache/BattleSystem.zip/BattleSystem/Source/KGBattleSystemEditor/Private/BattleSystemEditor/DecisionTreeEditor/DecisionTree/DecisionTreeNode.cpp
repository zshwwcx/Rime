#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeNode.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeEdge.h"

#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/DecisionTreeActuator.h"



UDecisionTreeNode::UDecisionTreeNode()
{
#if WITH_EDITORONLY_DATA
	PinInformations.Empty();
	PinInformations.Add(FDTNodePin(false, TEXT("In")));
	PinInformations.Add(FDTNodePin(true, TEXT("Out")));
#endif

}

bool UDecisionTreeNode::CheckConditions(UDecisionTreeDataCollector* InDataCollector)
{
	if (ConditionGroup)
		return ConditionGroup->CheckCondition(InDataCollector);
	else
		return true;
}

#if WITH_EDITOR
void UDecisionTreeNode::ConstructNode()
{
	RefreshNodeTitle();
}

void UDecisionTreeNode::CopyData(UDecisionTreeNode* OtherNode)
{
	if (!OtherNode)
		return;

	if (OtherNode->ConditionGroup)
	{
		ConditionGroup = NewObject<UDecisionTreeConditionGroup>(this, OtherNode->ConditionGroup->GetClass());
		ConditionGroup->CopyData(OtherNode->ConditionGroup);
	}

	RefreshNodeTitle();
}

void UDecisionTreeNode::RefreshNodeTitle()
{
	if (ConditionGroup)
	{
		NodeTitle = FText::FromString(ConditionGroup->GetConditionDescription());
	}
}

FText UDecisionTreeNode::GetNodeTitle() const
{
	return NodeTitle;
}

void UDecisionTreeNode::SetNodeTitle(const FText& InText)
{
	NodeTitle = InText;
}

bool UDecisionTreeNode::CanCreateConnection(int32 SelfPinID, UDecisionTreeNode* Other, int32 OtherPinID, FText& ErrorMessage)
{
	return true;
}

bool UDecisionTreeNode::CanUserDelete() const
{
	return true;
}

const TArray<FDTNodePin>* UDecisionTreeNode::GetNodePinList()
{
	return &PinInformations;
}

void UDecisionTreeNode::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	RefreshNodeTitle();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}
#endif






#if WITH_EDITOR
void UDecisionTreeGraphNode::InitSaver()
{
	EditedNodes.Empty();

	RootNodes.Empty(50);
	DecisionTreeEdges.Empty(100);
}

void UDecisionTreeGraphNode::AddEdgeMessage(UDecisionTreeNode* InFromNode, UDecisionTreeNode* InToNode, UDecisionTreeEdge* InEdge)
{
	if (!InFromNode || !InToNode || !InEdge)
		return;

	if (!EditedNodes.Contains(InFromNode))
	{
		InFromNode->OutEdges.Empty(5);
		InFromNode->InEdges.Empty(5);

		EditedNodes.Add(InFromNode);
	}

	if (!EditedNodes.Contains(InToNode))
	{
		InToNode->OutEdges.Empty(5);
		InToNode->InEdges.Empty(5);

		EditedNodes.Add(InToNode);
	}

	InEdge->StartNode = InFromNode;
	InEdge->EndNode = InToNode;

	// 将该条边添加到数组中
	DecisionTreeEdges.Add(InEdge);

	InFromNode->OutEdges.Add(DecisionTreeEdges.Num() - 1);
	InToNode->InEdges.Add(DecisionTreeEdges.Num() - 1);
	InEdge->RefreshEdgeTitle();
}

void UDecisionTreeGraphNode::RefreshLogicMessage()
{
	return;
}

#endif

