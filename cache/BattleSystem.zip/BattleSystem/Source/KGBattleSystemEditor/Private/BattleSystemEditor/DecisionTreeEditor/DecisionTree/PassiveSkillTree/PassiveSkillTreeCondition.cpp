#include "BattleSystemEditor/DecisionTreeEditor/DecisionTree/PassiveSkillTree/PassiveSkillTreeCondition.h"



UPassiveSkillTreeCondition::UPassiveSkillTreeCondition()
{
	Name = TEXT("BeatenTree");
}

bool UPassiveSkillTreeCondition::PerformCheck_Implementation(const FBSConditionData& InData) const
{
	bool Result = true;
	return Result;
}


#if WITH_EDITOR
bool UPassiveSkillTreeCondition::CopyData(UBSCondition* OtherCondition)
{
	if (!Super::CopyData(OtherCondition))
		return false;

	if (UPassiveSkillTreeCondition* OtherHitCondition = Cast<UPassiveSkillTreeCondition>(OtherCondition))
	{
		bCheckStaggerState = OtherHitCondition->bCheckStaggerState;
		StaggerState = OtherHitCondition->StaggerState;

		bCheckAttackType = OtherHitCondition->bCheckAttackType;
		AttackType = OtherHitCondition->AttackType;

		bCheckAttackForce = OtherHitCondition->bCheckAttackForce;
		AttackForce = OtherHitCondition->AttackForce;

		bCheckRelationType = OtherHitCondition->bCheckRelationType;
		RelationType = OtherHitCondition->RelationType;
	}

	return true;
}

FString UPassiveSkillTreeCondition::GetConditionDescription()
{
	FString Result;
	if (bCheckStaggerState)
	{
		UEnum* EnumType = StaticEnum<EBSStaggerState>();

		int32 Num = (int32)EBSStaggerState::SS_TMax;
		for (int32 i = 0; i < Num; ++i)
		{
			if ((StaggerState & (1 << i)) > 0)
			{
				Result += EnumType->GetDisplayNameTextByIndex(i).ToString();
				Result += TEXT(" ");
			}
		}
		Result += TEXT("\n");
	}

	if (bCheckAttackType)
	{
		UEnum* EnumType = StaticEnum<EBSAttackType>();

		int32 Num = (int32)EBSAttackType::AT_TMax;
		for (int32 i = 0; i < Num; ++i)
		{
			if ((AttackType & (1 << i)) > 0)
			{
				Result += EnumType->GetDisplayNameTextByIndex(i).ToString();
				Result += TEXT(" ");
			}
		}
		Result += TEXT("\n");
	}

	if (bCheckAttackForce)
	{
		UEnum* EnumType = StaticEnum<EBSAttackForce>();

		int32 Num = (int32)EBSAttackForce::AF_TMax;
		for (int32 i = 0; i < Num; ++i)
		{
			if ((AttackForce & (1 << i)) > 0)
			{
				Result += EnumType->GetDisplayNameTextByIndex(i).ToString();
				Result += TEXT(" ");
			}
		}
		Result += TEXT("\n");
	}

	if (bCheckRelationType)
	{
		UEnum* EnumType = StaticEnum<EBSAttackerLocationType>();

		int32 Num = (int32)EBSAttackerLocationType::ALT_TMax;
		for (int32 i = 0; i < Num; ++i)
		{
			if ((RelationType & (1 << i)) > 0)
			{
				Result += EnumType->GetDisplayNameTextByIndex(i).ToString();
				Result += TEXT(" ");
			}
		}
		Result += TEXT("\n");
	}

	return Result;
}

#endif