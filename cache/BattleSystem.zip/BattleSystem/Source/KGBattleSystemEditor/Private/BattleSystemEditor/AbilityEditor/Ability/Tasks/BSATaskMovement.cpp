#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskMovement.h"

#include "UObject/ObjectSaveContext.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameFramework/Character.h"
#include "GameFramework/RootMotionSource.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "NavigationSystem.h"
#include "Engine/BlockingVolume.h"

#include "BattleSystem/Ability/BSAStructs.h"
#include "BattleSystem/BSFunctionLibrary.h"



#pragma region RotateActor
#if WITH_EDITOR
void UBSATRotateActor::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	if (LifeType > EBSATaskLife::TL_Instant && LifeType < EBSATaskLife::TL_ByController)
	{
		Duration = FMath::Max(0.1f, Duration);
	}

	if (MaxRotateAngle > 1e-5 || LifeType <= EBSATaskLife::TL_Instant)
	{
		NeedHomingTarget = false;
	}
	
	if (NeedHomingTarget)
	{
		NetType = EBSATaskNet::TN_ServerOnly;
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}
#endif

#pragma endregion RotateActor






#pragma region RootMotionToActor
#if WITH_EDITOR
void UBSATRootMotionToTarget::PreSave(FObjectPreSaveContext SaveContext)
{
	if (NetType <= EBSATaskNet::TN_ServerOnly)
	{
		NetType = EBSATaskNet::TN_ServerAndClient;
	}

	Super::PreSave(SaveContext);
}

void UBSATRootMotionToTarget::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);


	if (PropertyChangedEvent.Property->GetName() == TEXT("bNeedTraceTarget"))
	{
		if (bNeedTraceTarget)
		{
			bNeedCheckGround = false;
		}
	}

	/*if (!GeneratedTimeMappingCurve && !HasAnyFlags(RF_ClassDefaultObject))
	{
		GeneratedTimeMappingCurve = NewObject<UCurveFloat>(this);

		MarkPackageDirty();
	}
	if (GeneratedTimeMappingCurve)
	{
		GeneratedTimeMappingCurve->FloatCurve.SetKeys(TimeMappingFloatCurve.GetRichCurveConst()->Keys);
	}


	if (!GeneratedPathOffsetCurve)
	{
		GeneratedPathOffsetCurve = NewObject<UCurveVector>(this);

		MarkPackageDirty();
	}
	if (GeneratedPathOffsetCurve)
	{
		GeneratedPathOffsetCurve->FloatCurves[0].SetKeys(PathOffsetVectorCurve.VectorCurves[0].Keys);
		GeneratedPathOffsetCurve->FloatCurves[1].SetKeys(PathOffsetVectorCurve.VectorCurves[1].Keys);
		GeneratedPathOffsetCurve->FloatCurves[2].SetKeys(PathOffsetVectorCurve.VectorCurves[2].Keys);
	}*/

}
#endif

#pragma endregion RootMotionToActor






#pragma region RootMotionToLocation
#if WITH_EDITOR
void UBSATRootMotionToLocation::PreSave(FObjectPreSaveContext SaveContext)
{
	if (NetType <= EBSATaskNet::TN_ServerOnly)
	{
		NetType = EBSATaskNet::TN_ServerAndClient;
	}

	Super::PreSave(SaveContext);
}

void UBSATRootMotionToLocation::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);


	/*if (!GeneratedTimeMappingCurve && !HasAnyFlags(RF_ClassDefaultObject))
	{
		GeneratedTimeMappingCurve = NewObject<UCurveFloat>(this);

		MarkPackageDirty();
	}
	if (GeneratedTimeMappingCurve)
	{
		GeneratedTimeMappingCurve->FloatCurve.SetKeys(TimeMappingFloatCurve.GetRichCurveConst()->Keys);
	}


	if (!GeneratedPathOffsetCurve && !HasAnyFlags(RF_ClassDefaultObject))
	{
		GeneratedPathOffsetCurve = NewObject<UCurveVector>(this);

		MarkPackageDirty();
	}
	if (GeneratedPathOffsetCurve)
	{
		GeneratedPathOffsetCurve->FloatCurves[0].SetKeys(PathOffsetVectorCurve.VectorCurves[0].Keys);
		GeneratedPathOffsetCurve->FloatCurves[1].SetKeys(PathOffsetVectorCurve.VectorCurves[1].Keys);
		GeneratedPathOffsetCurve->FloatCurves[2].SetKeys(PathOffsetVectorCurve.VectorCurves[2].Keys);
	}*/
}
#endif

#pragma endregion RootMotionToLocation






#pragma region RootMotionByBeaten
#if WITH_EDITOR
void UBSATRootMotionByBeaten::PreSave(FObjectPreSaveContext SaveContext)
{
	if (NetType <= EBSATaskNet::TN_ServerOnly)
	{
		NetType = EBSATaskNet::TN_ServerAndClient;
	}

	Super::PreSave(SaveContext);
}

void UBSATRootMotionByBeaten::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	/*if (!GeneratedTimeMappingCurve && !HasAnyFlags(RF_ClassDefaultObject))
	{
		GeneratedTimeMappingCurve = NewObject<UCurveFloat>(this);

		MarkPackageDirty();
	}
	if (GeneratedTimeMappingCurve)
	{
		GeneratedTimeMappingCurve->FloatCurve.SetKeys(TimeMappingFloatCurve.GetRichCurveConst()->Keys);
	}*/
}
#endif

#pragma endregion RootMotionForBeaten
