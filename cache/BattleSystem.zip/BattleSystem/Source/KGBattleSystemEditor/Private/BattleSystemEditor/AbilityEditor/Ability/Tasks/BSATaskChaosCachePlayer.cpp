#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskChaosCachePlayer.h"

#include "Kismet/KismetMathLibrary.h"
#include "BattleSystem/BSFunctionLibrary.h"



void UBSATAddChaosCachePlayer::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	InOutList.AddUnique(CacheCollection.ToString());
}

#if WITH_EDITOR
void UBSATAddChaosCachePlayer::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATAddChaosCachePlayer::UpdateDataByDynamicActorInfo(const FBSADynamicObjectInfo& InInfo)
{
	AActor* DActor = Cast<AActor>(InInfo.DynamicObject);
	if (!DActor)
		return;

	if (bNeedAttach)
	{
		AttachTransform.ConfigValue = DActor->GetRootComponent()->GetRelativeTransform();
	}
	else if (!CoordinateCreater.OffsetTransform.bUseInputData)
	{
		FTransform CurWorldTransform = DActor->GetActorTransform();
		CoordinateCreater.OffsetTransform.ConfigValue = CurWorldTransform * InInfo.CachedTransform.Inverse();
	}
}

void UBSATAddChaosCachePlayer::UpdateDynamicActorByData(const FBSADynamicObjectInfoArray& InInfoArray)
{
	for (int32 i = 0; i < InInfoArray.Informations.Num(); ++i)
	{
		AActor* DActor = Cast<AActor>(InInfoArray.Informations[i].DynamicObject);
		if (!DActor)
			continue;

		if (bNeedAttach)
		{
			DActor->SetActorRelativeTransform(AttachTransform.ConfigValue);
		}
		else if (!CoordinateCreater.OffsetTransform.bUseInputData)
		{
			FTransform CurWorldTransform = CoordinateCreater.OffsetTransform.ConfigValue * InInfoArray.Informations[i].CachedTransform;

			if (bNeedCheckGround)
			{
				FVector Result(ForceInit), ResNormal(ForceInit); TArray<AActor*> IgnoreActors;
				FVector UpVec = DActor->GetActorUpVector();
				UBSFunctionLibrary::FindGroundLocation(InInfoArray.Informations[i].DynamicObject, CurWorldTransform.GetLocation(), GroundCheckObjectTypes, Result, ExtraGroundMsg, UpVec * -1.0f);
			}

			DActor->SetActorTransform(CurWorldTransform);
		}
	}
}

#endif
