#include "BattleSystemEditor/AbilityEditor/BSAEditorUtilities.h"

#include "ClassViewerFilter.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskTemplate.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Input/SComboButton.h"


#define LOCTEXT_NAMESPACE "BSAEditorUtilities"



void FBSAEditorUtilities::MakeNewTaskPicker(FMenuBuilder& MenuBuilder, const FOnClassPicked& OnTaskClassPicked)
{
	class FNotifyStateClassFilter : public IClassViewerFilter
	{
	public:
		FNotifyStateClassFilter() {}

		bool IsClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const UClass* InClass, TSharedRef< FClassViewerFilterFuncs > InFilterFuncs) override
		{
			const bool bChildOfObjectClass = InClass->IsChildOf(UBSATask::StaticClass());
			const bool bMatchesFlags = !InClass->HasAnyClassFlags(CLASS_Hidden | CLASS_HideDropDown | CLASS_Deprecated | CLASS_Abstract);

			return bChildOfObjectClass && bMatchesFlags;
		}

		virtual bool IsUnloadedClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const TSharedRef< const IUnloadedBlueprintData > InUnloadedClassData, TSharedRef< FClassViewerFilterFuncs > InFilterFuncs) override
		{
			const bool bChildOfObjectClass = InUnloadedClassData->IsChildOf(UBSATask::StaticClass());
			const bool bMatchesFlags = !InUnloadedClassData->HasAnyClassFlags(CLASS_Hidden | CLASS_HideDropDown | CLASS_Deprecated | CLASS_Abstract);

			return bChildOfObjectClass && bMatchesFlags;
		}
	};


	if (MenuBuilder.GetMultiBox()->GetBlocks().Num() > 1)
	{
		MenuBuilder.AddMenuSeparator();
	}


	FClassViewerInitializationOptions InitOptions;
	InitOptions.Mode = EClassViewerMode::ClassPicker;
	InitOptions.bShowObjectRootClass = false;
	InitOptions.bShowUnloadedBlueprints = true;
	InitOptions.bShowNoneOption = false;
	InitOptions.bEnableClassDynamicLoading = true;
	InitOptions.bExpandRootNodes = true;
	InitOptions.NameTypeToDisplay = EClassViewerNameTypeToDisplay::DisplayName;
	InitOptions.ClassFilters.Add(MakeShared<FNotifyStateClassFilter>());
	InitOptions.bShowBackgroundBorder = false;


	FClassViewerModule& ClassViewerModule = FModuleManager::LoadModuleChecked<FClassViewerModule>("ClassViewer");
	MenuBuilder.AddWidget
	(
		SNew(SBox)
		.MinDesiredWidth(300.0f)
		.MaxDesiredHeight(400.0f)
		[
			ClassViewerModule.CreateClassViewer(InitOptions, OnTaskClassPicked)
		],
		FText(), true, false
	);
}


void FBSAEditorUtilities::MakeNewTaskTemplatePicker(class FMenuBuilder& MenuBuilder, const FOnAddTaskTemplateDelegate& OnTaskTemplatePicked)
{
	TArray< TSharedPtr<FName>> TemplateNameList;
	if (const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>())
	{
		if (UBSATaskTemplate* TaskTemplate = Setting->TaskTemplate.LoadSynchronous())
		{
			for (FBSATaskTemplateInfo SingleTaskGroup : TaskTemplate->TaskGroups)
			{
				TemplateNameList.Add(MakeShared<FName>(SingleTaskGroup.Name));;
			}
		}
	}

	MenuBuilder.AddWidget
	(
		SNew(SBox)
		.MinDesiredWidth(200.0f)
		.MaxDesiredHeight(400.0f)
		[
			SNew(SBSTaskGroupPicker)
			.AllTemplateNames(TemplateNameList)
			.AddTemplateEvent(OnTaskTemplatePicked)
		],
		FText(), true, false
	);
}



TSharedRef<SWidget> FBSAEditorUtilities::MakeTrackButton(FText HoverText, FOnGetContent MenuContent, const TAttribute<bool>& HoverState)
{
	FSlateFontInfo SmallLayoutFont = FCoreStyle::GetDefaultFontStyle("Regular", 8);

	TSharedRef<STextBlock> ComboButtonText = 
		SNew(STextBlock)
		.Text(HoverText)
		.Font(SmallLayoutFont)
		.ColorAndOpacity(FSlateColor::UseForeground());


	TSharedRef<SComboButton> ComboButton =
		SNew(SComboButton)
		.HasDownArrow(false)
		.ButtonStyle(FAppStyle::Get(), "HoverHintOnly")
		.ForegroundColor(FSlateColor::UseForeground())
		.OnGetMenuContent(MenuContent)
		.ContentPadding(FMargin(5, 2))
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		.ButtonContent()
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(FMargin(0, 0, 2, 0))
			[
				SNew(SImage)
				.ColorAndOpacity(FSlateColor::UseForeground())
				.Image(FAppStyle::GetBrush("ComboButton.Arrow"))
			]
			+ SHorizontalBox::Slot()
			.VAlign(VAlign_Center)
			.AutoWidth()
			[
				ComboButtonText
			]
		];


	auto GetRolloverVisibility = [WeakComboButton = TWeakPtr<SComboButton>(ComboButton), HoverState]()
	{
		TSharedPtr<SComboButton> ComboButton = WeakComboButton.Pin();
		if (HoverState.Get() || ComboButton->IsOpen())
		{
			return EVisibility::SelfHitTestInvisible;
		}
		else
		{
			return EVisibility::Collapsed;
		}
	};


	TAttribute<EVisibility> Visibility = TAttribute<EVisibility>::Create(TAttribute<EVisibility>::FGetter::CreateLambda(GetRolloverVisibility));
	ComboButtonText->SetVisibility(Visibility);


	return ComboButton;
}



#undef LOCTEXT_NAMESPACE
