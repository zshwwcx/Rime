#include "BattleSystemEditor/AbilityEditor/BSAEditorToolbar.h"

#include "ToolMenus.h"
#include "WorkflowOrientedApp/SModeWidget.h"

#include "KGEditorStyle.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorCommands.h"   
#include "Widgets/Layout/SSpacer.h"


#define LOCTEXT_NAMESPACE "BSAEditorToolbar"



void FBSAEditorToolbar::SetupToolbar(TSharedPtr<FExtender> Extender, TSharedPtr<FBSAEditor> InEditor)
{
	CachedEditor = InEditor;

	PlayIcon = FSlateIcon(FAppStyle::GetAppStyleSetName(), FName(TEXT("Animation.Forward")));
	PauseIcon = FSlateIcon(FAppStyle::GetAppStyleSetName(), FName(TEXT("Animation.Pause")));
}

void FBSAEditorToolbar::AddModesToolbar(TSharedPtr<FExtender> Extender)
{
	Extender->AddToolBarExtension
	(
		"Asset",
		EExtensionHook::After,
		CachedEditor.Pin()->GetToolkitCommands(),
		FToolBarExtensionDelegate::CreateSP(this, &FBSAEditorToolbar::FillModesToolbar)
	);
}

void FBSAEditorToolbar::AddTimelineToolbar(TSharedPtr<FExtender> Extender)
{
	Extender->AddToolBarExtension
	(
		"Asset",
		EExtensionHook::After,
		CachedEditor.Pin()->GetToolkitCommands(),
		FToolBarExtensionDelegate::CreateSP(this, &FBSAEditorToolbar::FillTimelineModeToolbar)
	);
}

void FBSAEditorToolbar::FillModesToolbar(FToolBarBuilder& ToolbarBuilder)
{
	TAttribute<FName> GetActiveMode(CachedEditor.Pin().ToSharedRef(), &FBSAEditor::GetCurrentMode);
	FOnModeChangeRequested SetActiveMode = FOnModeChangeRequested::CreateSP(CachedEditor.Pin().ToSharedRef(), &FBSAEditor::SetCurrentMode);

	CachedEditor.Pin()->AddToolbarWidget(SNew(SSpacer).Size(FVector2D(4.0f, 1.0f)));

	CachedEditor.Pin()->AddToolbarWidget
	(
		SNew(SModeWidget, FBSAEditor::GetLocalizedMode(BSAEditorModes::Main), BSAEditorModes::Main)
		.OnGetActiveMode(GetActiveMode)
		.OnSetActiveMode(SetActiveMode)
		.ToolTipText(LOCTEXT("MainModeButtonTooltip", "Switch to Main Mode"))
	);

	CachedEditor.Pin()->AddToolbarWidget
	(
		SNew(SModeWidget, FBSAEditor::GetLocalizedMode(BSAEditorModes::LogicGraph), BSAEditorModes::LogicGraph)
		.OnGetActiveMode(GetActiveMode)
		.OnSetActiveMode(SetActiveMode)
		.ToolTipText(LOCTEXT("LogicGraphModeButtonTooltip", "Switch to Logic Graph Mode"))
	);

	CachedEditor.Pin()->AddToolbarWidget(SNew(SSpacer).Size(FVector2D(4.0f, 1.0f)));
}

void FBSAEditorToolbar::FillTimelineModeToolbar(FToolBarBuilder& ToolbarBuilder)
{
	const FBSAEditorCommands& Commands = FBSAEditorCommands::Get();

	ToolbarBuilder.BeginSection("Timeline");
	{
		ToolbarBuilder.AddToolBarButton
		(
			Commands.Play,
			NAME_None,
			TAttribute<FText>(this, &FBSAEditorToolbar::GetPlayText),
			TAttribute<FText>(this, &FBSAEditorToolbar::GetPlayToolTip),
			TAttribute<FSlateIcon>(this, &FBSAEditorToolbar::GetPlayIcon)
		);
		ToolbarBuilder.AddToolBarButton(Commands.Stop);
		ToolbarBuilder.AddToolBarButton(Commands.Step);
		//ToolbarBuilder.AddToolBarButton(Commands.Record);
	}
	ToolbarBuilder.EndSection();


	ToolbarBuilder.BeginSection("Other");
	{
		ToolbarBuilder.AddToolBarButton
		(
			Commands.ResetWorld, NAME_None,
			LOCTEXT("Toolbar_ResetWorld", "ResetWorld"),
			LOCTEXT("Toolbar_ResetWorld", "ResetWorld"),
			FSlateIcon(FAppStyle::GetAppStyleSetName(), "ContentBrowser.AssetActions.ReimportAsset")
		);

		ToolbarBuilder.AddToolBarButton
		(
			Commands.ShowCollision, NAME_None,
			LOCTEXT("Toolbar_ShowCollision", "ShowCollision"),
			LOCTEXT("Toolbar_ShowCollision", "ShowCollision"),
			FSlateIcon(FAppStyle::GetAppStyleSetName(), "LevelEditor.ViewOptions.Small")
		);
	}
	ToolbarBuilder.EndSection();


	ToolbarBuilder.BeginSection("Data");
	{
		ToolbarBuilder.AddComboButton
		(
			FUIAction(),
			FOnGetContent::CreateRaw(this, &FBSAEditorToolbar::GenerateDataProcessMenu),
			LOCTEXT("DataProcess", "DataProcess"),
			LOCTEXT("DataProcess", "DataProcess"),
			FSlateIcon(FKGEditorStyle::GetStyleSetName(), TEXT("BSAEditor.DataProcess"))
		);
		UToolMenu* DataProcessMenu = UToolMenus::Get()->ExtendMenu("BSAEditor.BSAEditorToolBar.DataProcess");
		FToolMenuSection& Section = DataProcessMenu->AddSection("DataProcess", LOCTEXT("BSAEditor.DataProcess", "DataProcess"));
		Section.AddMenuEntry
		(
			"Export All Ability Data",
			LOCTEXT("Export All Data", "Export All Data"),
			LOCTEXT("Export All Data", "Export All Data"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateRaw(CachedEditor.Pin().Get(), &FBSAEditor::ExportAllAbilityJson), FCanExecuteAction())
		);

		Section.AddMenuEntry
		(
			"Refresh Ability Tags",
			LOCTEXT("Refresh Ability Tags", "Refresh Ability Tags"),
			LOCTEXT("Refresh Ability Tags", "Refresh Ability Tags"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateRaw(CachedEditor.Pin().Get(), &FBSAEditor::RefreshGameplayTags), FCanExecuteAction())
		);

		Section.AddMenuEntry
		(
			"Update All Ability Data",
			LOCTEXT("Update All Data", "Update All Data"),
			LOCTEXT("Update All Data", "Update All Data"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateRaw(CachedEditor.Pin().Get(), &FBSAEditor::UpdateAllAbilityData), FCanExecuteAction())
		);

		Section.AddMenuEntry
		(
			"AutoFix All Skill&Buff Resources Quoted",
			LOCTEXT("AutoFix All Resources", "AutoFix All Resources"),
			LOCTEXT("AutoFix All Resources", "AutoFix All Resources"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateRaw(CachedEditor.Pin().Get(), &FBSAEditor::AutoFixAllResources), FCanExecuteAction())
		);

		Section.AddMenuEntry
		(
			"Check All Skill&Buff Resources Quoted",
			LOCTEXT("Check All Resources", "Check All Resources"),
			LOCTEXT("Check All Resources", "Check All Resources"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateRaw(CachedEditor.Pin().Get(), &FBSAEditor::CheckAllResources), FCanExecuteAction())
		);
	}
	ToolbarBuilder.EndSection();
}

TSharedRef<SWidget> FBSAEditorToolbar::GenerateDataProcessMenu()
{
	TSharedPtr<FUICommandList> InCommandList = nullptr;
	TSharedPtr<FExtender> MenuExtender = nullptr;

	FToolMenuContext MenuContext(InCommandList, MenuExtender);
	return UToolMenus::Get()->GenerateWidget("BSAEditor.BSAEditorToolBar.DataProcess", MenuContext);
}

FText FBSAEditorToolbar::GetPlayText() const
{
	if (CachedEditor.Pin()->IsPlaying())
		return LOCTEXT("TimelineCommand", "Pause");

	return LOCTEXT("TimelineCommand", "Play");
}

FText FBSAEditorToolbar::GetPlayToolTip() const
{
	if (CachedEditor.Pin()->IsPlaying())
		return LOCTEXT("TimelineCommandToolTip", "Pause Ability.");

	return LOCTEXT("TimelineCommandToolTip", "Play Ability.");
}

FSlateIcon FBSAEditorToolbar::GetPlayIcon() const
{
	if (CachedEditor.Pin()->IsPlaying())
		return PauseIcon;

	return PlayIcon;
}



#undef LOCTEXT_NAMESPACE