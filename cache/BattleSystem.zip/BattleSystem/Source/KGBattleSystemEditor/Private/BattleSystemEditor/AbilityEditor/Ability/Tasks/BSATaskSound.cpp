#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskSound.h"

#include "AkAudio/Classes/AkGameplayStatics.h"
#include "AkAudio/Public/AkAudioDevice.h"



void UBSATAkAudioEvent::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	InOutList.AddUnique(this->AkEvent.ToString());
}
