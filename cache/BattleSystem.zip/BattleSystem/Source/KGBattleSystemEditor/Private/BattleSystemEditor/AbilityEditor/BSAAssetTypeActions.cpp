#include "BattleSystemEditor/AbilityEditor/BSAAssetTypeActions.h"

#include "EditorModeManager.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSABuffAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskTemplate.h"
#include "Misc/MessageDialog.h"


#define LOCTEXT_NAMESPACE "AssetTypeActions_BSAAsset"



FAssetTypeActions_BSASkillAsset::FAssetTypeActions_BSASkillAsset(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{

}

FAssetTypeActions_BSASkillAsset::~FAssetTypeActions_BSASkillAsset()
{

}

FText FAssetTypeActions_BSASkillAsset::GetName() const
{
	return LOCTEXT("AssetTypeActions_SkillAsset", "Skill");
}

FColor FAssetTypeActions_BSASkillAsset::GetTypeColor() const
{
	return FColor::Cyan;
}

UClass* FAssetTypeActions_BSASkillAsset::GetSupportedClass() const
{
	return UBSASkillAsset::StaticClass();
}

void FAssetTypeActions_BSASkillAsset::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{

}

void FAssetTypeActions_BSASkillAsset::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	for (UObject* Object : InObjects)
	{
		if (UBSASkillAsset* SkillAsset = Cast<UBSASkillAsset>(Object))
		{
			IBSAEditor::OpenEditor(SkillAsset, EditWithinLevelEditor);
		}
	}
}

uint32 FAssetTypeActions_BSASkillAsset::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}






FAssetTypeActions_BSABuffAsset::FAssetTypeActions_BSABuffAsset(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{

}

FAssetTypeActions_BSABuffAsset::~FAssetTypeActions_BSABuffAsset()
{

}

FText FAssetTypeActions_BSABuffAsset::GetName() const
{
	return LOCTEXT("AssetTypeActions_BuffAsset", "Buff");
}

FColor FAssetTypeActions_BSABuffAsset::GetTypeColor() const
{
	return FColor::Orange;
}

UClass* FAssetTypeActions_BSABuffAsset::GetSupportedClass() const
{
	return UBSABuffAsset::StaticClass();
}

void FAssetTypeActions_BSABuffAsset::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{

}

void FAssetTypeActions_BSABuffAsset::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	for (UObject* Object : InObjects)
	{
		if (UBSABuffAsset* BuffAsset = Cast<UBSABuffAsset>(Object))
		{
			IBSAEditor::OpenEditor(BuffAsset, EditWithinLevelEditor);
		}
	}
}

uint32 FAssetTypeActions_BSABuffAsset::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}






FAssetTypeActions_BSATaskTemplateAsset::FAssetTypeActions_BSATaskTemplateAsset(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{

}

FAssetTypeActions_BSATaskTemplateAsset::~FAssetTypeActions_BSATaskTemplateAsset()
{

}

FText FAssetTypeActions_BSATaskTemplateAsset::GetName() const
{
	return LOCTEXT("AssetTypeActions_TaskTemplateAsset", "TaskTemplate");
}

FColor FAssetTypeActions_BSATaskTemplateAsset::GetTypeColor() const
{
	return FColor::Yellow;
}

UClass* FAssetTypeActions_BSATaskTemplateAsset::GetSupportedClass() const
{
	return UBSATaskTemplate::StaticClass();
}

void FAssetTypeActions_BSATaskTemplateAsset::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{

}

uint32 FAssetTypeActions_BSATaskTemplateAsset::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}



#undef LOCTEXT_NAMESPACE