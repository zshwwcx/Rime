#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskComponent.h"

#include "BattleSystem/BSFunctionLibrary.h"



#pragma region RelativeTransform
#if WITH_EDITOR
void UBSATComponentRelation::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (!bNeedChangeRelativeLocation)
		bNeedLocationTimeCurve = false;

	if (!bNeedChangeRelativeRotation)
		bNeedRotationTimeCurve = false;

	if (!bNeedChangeRelativeScale)
		bNeedScaleTimeCurve = false;
}

#endif

#pragma endregion RelativeTransform
