#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSAAssetEditTab.h"
#include "Widgets/Layout/SSpacer.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SSeparator.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Widgets/TimeLineBase/SAnimTimeline.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineController.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/BSAPreviewProxy.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorUtilities.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "Widgets/Input/SEditableTextBox.h"


#define LOCTEXT_NAMESPACE "SBSAAssetEditTab"



void SBSAAssetEditSection::Construct(const FArguments& InArgs, const TSharedPtr<FBSAEditor>& InAssetEditorToolkit, const TSharedPtr<SBSAAssetEditTab>& AssetEditWidget, int32 InSectionIndex)
{
	CachedEditor = InAssetEditorToolkit;
	CachedEditTab = AssetEditWidget;

	// 创建时间轴
	TimelineController = MakeShared<FBSATimelineController>();
	TimelineController->Initialize(CachedEditor.Pin(), CachedEditor.Pin()->GetPreviewProxy(), InSectionIndex);
	TimelineWidget = SNew(SAnimTimeline, TimelineController.ToSharedRef());

	TSharedPtr<SBox> OutBorder;
	TSharedPtr<SBorder> OutOuterBorder;
	TSharedPtr<SHorizontalBox> OutInnerHorizontalBox;

	this->ChildSlot
	[
		SNew(SExpandableArea)
		.HeaderContent()
		[
			SAssignNew(OutBorder, SBox)
			.Padding(2.0f)
			[
				SAssignNew(OutInnerHorizontalBox, SHorizontalBox)
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Left)
				.Padding(2.0f, 1.0f)
				.AutoWidth()
				[
					SNew(SInlineEditableTextBlock)
					.IsReadOnly(true)
					.Text_Lambda
					(
						[this]()
						{
							return this->GetSectionName();
						}
					)
					.IsSelected(FIsSelected::CreateLambda([]() { return false; }))
					.OnTextCommitted(this, &SBSAAssetEditSection::ChangeSectionName)
				]

				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Left)
				.Padding(10.0f, 1.0f, 2.0f, 1.0f)
				.AutoWidth()
				[
					SNew(STextBlock)
					.Text(FText::FromString(TEXT("LoopTime:")))
				]

				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Left)
				.Padding(1.0f, 1.0f)
				.AutoWidth()
				[
					SNew(SEditableTextBox)
					.Text_Lambda
					(
						[this]()
						{
							return this->GetSectionLoopTime();
						}
					)
					.OnTextCommitted(this, &SBSAAssetEditSection::ChangeSectionLoopTime)
				]

				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Left)
				.Padding(10.0f, 1.0f, 2.0f, 1.0f)
				.AutoWidth()
				[
					SNew(STextBlock)
					.Text(FText::FromString(TEXT("Duration:")))
				]

				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Left)
				.Padding(1.0f, 1.0f)
				.AutoWidth()
				[
					SNew(SEditableTextBox)
					.Text_Lambda
					(
						[this]()
						{
							return this->GetSectionDuration();
						}
					)
					.OnTextCommitted(this, &SBSAAssetEditSection::ChangeSectionDuration)
				]
			]
		]
		.BodyContent()
		[
			SNew(SBox)
			.MinDesiredHeight(370)
			.Padding(FMargin(0, 2, 0, 2))
			[
				TimelineWidget.ToSharedRef()
			]
		]
	];

	OutInnerHorizontalBox->AddSlot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Left)
		.Padding(60.0f, 0.0f)
		[
			FBSAEditorUtilities::MakeTrackButton(LOCTEXT("BSASection", "Actions"), FOnGetContent::CreateSP(this, &SBSAAssetEditSection::BuildSectionSubMenu),
			MakeAttributeSP(OutBorder.Get(), &SWidget::IsHovered))
		];

}

void SBSAAssetEditSection::ChangeSectionName(const FText& InText, ETextCommit::Type CommitInfo)
{
	if (InText.IsEmpty())
		return;

	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		Asset->ChangeSectionName(TimelineController->GetSectionID(), *InText.ToString());
	}
}

void SBSAAssetEditSection::ChangeSectionLoopTime(const FText& InText, ETextCommit::Type CommitInfo)
{
	if (InText.IsEmpty())
		return;

	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		Asset->ChangeSectionLoopTime(TimelineController->GetSectionID(), FCString::Atoi(*InText.ToString()));
	}
}

void SBSAAssetEditSection::ChangeSectionDuration(const FText& InText, ETextCommit::Type CommitInfo)
{
	if (InText.IsEmpty())
		return;

	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		Asset->ChangeSectionDuration(TimelineController->GetSectionID(), FCString::Atof(*InText.ToString()));
	}
}

TSharedRef<SWidget> SBSAAssetEditSection::BuildSectionSubMenu()
{
	FMenuBuilder MenuBuilder(true, nullptr);

	MenuBuilder.BeginSection("Section Actions", LOCTEXT("MenuSectionS", "Section"));
	{
		MenuBuilder.AddMenuEntry
		(
			LOCTEXT("Action_NewSection_Lable", "New Section"),
			LOCTEXT("Action_NewSection_Tooltip", "Add a new section"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateSP(this, &SBSAAssetEditSection::AddSection)),
			NAME_None,
			EUserInterfaceActionType::Button
		);

		MenuBuilder.AddMenuEntry
		(
			LOCTEXT("Action_DeleteSection_Lable", "Delete Section"),
			LOCTEXT("Action_DeleteSection_Tooltip", "Delete Section"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateSP(this, &SBSAAssetEditSection::DeleteSection)),
			NAME_None,
			EUserInterfaceActionType::Button
		);
	}
	MenuBuilder.EndSection();

	return MenuBuilder.MakeWidget();
}

FText SBSAAssetEditSection::GetSectionName() const
{
	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		if (FBSATaskSection* SectionPtr = Asset->GetSectionPointerByIndex(TimelineController->GetSectionID()))
		{
			return FText::FromString(SectionPtr->Name.ToString());
		}
	}

	return FText::FromString(TEXT("None"));
}

FText SBSAAssetEditSection::GetSectionLoopTime() const
{
	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		if (FBSATaskSection* SectionPtr = Asset->GetSectionPointerByIndex(TimelineController->GetSectionID()))
		{
			return FText::FromString(FString::FromInt(SectionPtr->LoopTime));
		}
	}

	return FText::FromString(TEXT("1"));
}

FText SBSAAssetEditSection::GetSectionDuration() const
{
	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		if (FBSATaskSection* SectionPtr = Asset->GetSectionPointerByIndex(TimelineController->GetSectionID()))
		{
			return FText::FromString(FString::SanitizeFloat(SectionPtr->SectionDuration));
		}
	}

	return FText::FromString(TEXT("1"));
}

void SBSAAssetEditSection::AddSection()
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		Asset->AddSection();

		CachedEditTab.Pin()->Update();
	}
}

void SBSAAssetEditSection::DeleteSection()
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		Asset->RemoveSection(TimelineController->GetSectionID());

		CachedEditTab.Pin()->Update();
	}
}



void SBSAAssetEditTab::Construct(const FArguments& InArgs, const TSharedPtr<FBSAEditor>& InAssetEditorToolkit)
{
	CachedEditor = InAssetEditorToolkit;

	this->ChildSlot
	[
		SAssignNew(BorderWidgetArea, SBorder)
		.Visibility(EVisibility::SelfHitTestInvisible)
		.BorderImage(FAppStyle::GetBrush("NoBorder"))
		.Padding(FMargin(0.f, 0.f))
		.ColorAndOpacity(FLinearColor::White)
	];

	Update();
}

void SBSAAssetEditTab::Update()
{
	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		SectionWidgets.Empty();

		for (int32 i = 0; i < Asset->GetSectionNum(); i++)
		{
			TSharedPtr<SBSAAssetEditSection> NewSection = SNew(SBSAAssetEditSection, CachedEditor.Pin(), SharedThis(this), i);
			SectionWidgets.Add(NewSection);
		}

		if (SectionWidgets.Num() == 1)
		{
			BorderWidgetArea->SetContent
			(
				SectionWidgets[0].ToSharedRef()
			);
		}
		else
		{
			TSharedPtr<SScrollBox> OutScrollBox;

			BorderWidgetArea->SetContent
			(
				SAssignNew(OutScrollBox, SScrollBox)
				.Orientation(Orient_Vertical)
			);

			for (int32 i = 0; i < SectionWidgets.Num(); i++)
			{
				OutScrollBox->AddSlot()
				[
					SectionWidgets[i].ToSharedRef()
				];
			}
		}
	}
}

FReply SBSAAssetEditTab::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::LeftControl)
	{
		for (int32 i = 0; i < SectionWidgets.Num(); ++i)
		{
			if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(SectionWidgets[i]->TimelineController.Get()))
			{
				BSATC->ChangeCtrlState(true);
			}
		}
	}

	return FReply::Unhandled();
}

FReply SBSAAssetEditTab::OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::LeftControl)
	{
		for (int32 i = 0; i < SectionWidgets.Num(); ++i)
		{
			if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(SectionWidgets[i]->TimelineController.Get()))
			{
				BSATC->ChangeCtrlState(false);
			}
		}
	}

	return FReply::Unhandled();
}



#undef LOCTEXT_NAMESPACE