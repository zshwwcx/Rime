#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineController.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"

#include "Animation/AnimSequence.h"
#include "Preferences/PersonaOptions.h"

#include "Widgets/TimeLineBase/AnimTimelineTrack.h"
#include "Widgets/TimeLineBase/SAnimOutlinerItem.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineTrackGroup.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineTrackPanel.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSAExtraTrackPanel.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/BSAPreviewProxy.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorDelegates.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorPreviewScene.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"
#include "BattleSystem/Ability/BSAInstanceV2.h"

#include "BattleSystem/BSMacroDefinition.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskTemplate.h"
#include "IDesktopPlatform.h"
#include "DesktopPlatformModule.h"
#include "SourceControlHelpers.h"
#include "FileHelpers.h"
#include "EditorUtilityLibrary.h"
#include "Framework/Application/SlateApplication.h"
#include "Misc/MessageDialog.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableText.h"


#define LOCTEXT_NAMESPACE "FBSATimelineController"



#pragma region Important
FBSATimelineController::FBSATimelineController()
{
	bIsSelecting = false;
}

FBSATimelineController::~FBSATimelineController()
{
	FBSAEditorDelegates::AutoOptimizeDoneDelegate.RemoveAll(this);
	FBSAEditorDelegates::SkillAssetPropertyChange.RemoveAll(this);
}

void FBSATimelineController::Initialize(const TSharedPtr<FBSAEditor>& InAssetEditorToolkit, TSharedPtr<FBSAPreviewProxy> InPreviewProxy,  int32 InSectionIndex)
{
	CachedEditor = InAssetEditorToolkit;
	CachedPreviewProxy = InPreviewProxy;
	SectionIndex = InSectionIndex;

	SnapViewToPlayRange();

	FBSAEditorDelegates::AutoOptimizeDoneDelegate.AddRaw(this, &FBSATimelineController::ReceiveAutoOptimizeDone);
		FBSAEditorDelegates::SkillAssetPropertyChange.AddRaw(this, &FBSATimelineController::OnAssetPropertyChange);
}

void FBSATimelineController::RefreshTracks()
{
	if (!CachedEditor.IsValid() || !CachedPreviewProxy.IsValid())
		return;

	UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (!Asset)
		return;

	FBSATaskSection* SectionPtr = Asset->GetSectionPointerByIndex(SectionIndex);
	if (!SectionPtr)
		return;

	// 清除轨道选取信息
	ClearTrackSelection();
	
	// 记录轨道的展开信息
	TMap<int32, int32> GroupExpandStateMap;
	for (int32 i = 0; i < RootTracks.Num(); i++)
	{
		if (FAnimTimelineTrack* tGroup = &RootTracks[i].Get())
		{
			GroupExpandStateMap.Add(i, tGroup->IsExpanded() ? 1 : 0);
		}
	}

	// 清除所有轨道
	RootTracks.Empty();

	// 针对技能资源的主Section创建额外轨道
	if (SectionIndex == 0)
	{
		if (UBSASkillAsset* Skill = Cast<UBSASkillAsset>(Asset))
		{
			TSharedRef<FBSAExtraTrackPanel> NewTrack = MakeShareable
			(
				new FBSAExtraTrackPanel(SharedThis(this), Skill, 0, FText::FromString(TEXT("Chant")), LOCTEXT("Chant_Tooltip", "Chant"))
			);
			RootTracks.Add(NewTrack);

			NewTrack = MakeShareable
			(
				new FBSAExtraTrackPanel(SharedThis(this), Skill, 1, FText::FromString(TEXT("Combo")), LOCTEXT("Combo_Tooltip", "Combo"))
			);
			RootTracks.Add(NewTrack);

			NewTrack = MakeShareable
			(
				new FBSAExtraTrackPanel(SharedThis(this), Skill, 2, FText::FromString(TEXT("Skill Recovery Start Time")), LOCTEXT("SkillRecoveryStartTime_Tooltip", "SkillRecoveryStartTime"))
			);
			RootTracks.Add(NewTrack);
		}
	}

	// 重新创建各个轨道
	for (int32 i = 0; i < SectionPtr->TaskGroups.Num(); ++i)
	{
		FBSATaskGroup* GroupPtr = &SectionPtr->TaskGroups[i];

		TSharedRef<FBSATimelineTrackGroup> NewTrackGroup = MakeShareable
		(
			new FBSATimelineTrackGroup
			(
				SharedThis(this), GroupPtr, FText::FromName(SectionPtr->TaskGroups[i].Name), LOCTEXT("TaskGroup_Tooltip", "Task Group")
			)
		);

		if (GroupExpandStateMap.Contains(RootTracks.Num()))
		{
			// 恢复历史的展开状况
			NewTrackGroup->SetExpanded(*GroupExpandStateMap.Find(RootTracks.Num()) > 0);
		}
		else
		{
			// 无法恢复历史展开状况时，默认设置展开
			NewTrackGroup->SetExpanded(true);
		}

		for (int32 j = 0; j < GroupPtr->TaskList.Num(); ++j)
		{
			UBSATask* TheTask = nullptr;
			if (!GroupPtr->TaskList[j].IsValid())
			{
				//redo恢复删除Task的时候 会出现缓存Task异常 这里重新New一个赋值回去
				for (int32 m = 0; m < SectionPtr->TaskList.Num(); m++)
				{
					if (SectionPtr->TaskList[m] == GroupPtr->TaskList[j])
					{
						TheTask = NewObject<UBSATask>(Asset, SectionPtr->TaskList[m]->GetClass(), NAME_None, RF_Transactional);
						TheTask->CopyDataFromOther(SectionPtr->TaskList[m]);
						SectionPtr->TaskList[m] = TheTask;
						GroupPtr->TaskList[j] = TheTask;
						break;
					}
				}
			}
			else
				TheTask = GroupPtr->TaskList[j].Get();
			if (!TheTask)
				continue;

			TSharedRef<FBSATimelineTrackPanel> NewTrack = MakeShareable
			(
				new FBSATimelineTrackPanel
				(
					SharedThis(this), TheTask, TheTask->GetTaskName(), LOCTEXT("Task_Tooltip", "Task")
				)
			);
			NewTrack->GenerateContainerWidgetForTimeline();
			NewTrackGroup->AddChild(NewTrack);
		}

		RootTracks.Add(NewTrackGroup);
	}

	TracksChangedEvent.Broadcast();
	
	SnapViewToPlayRange();
}


void FBSATimelineController::OnAssetPropertyChange(FName PropertyName)
{
	if (PropertyName.IsNone())
	{
		RefreshTracks();
	}
}

void FBSATimelineController::PostClearTrackSelection()
{
	CachedEditor.Pin()->SetTaskSelection(TArray<UBSATask*>{});
}

#pragma endregion Important



#pragma region Parameter
int32 FBSATimelineController::GetSectionID()
{
	return SectionIndex;
}

FFrameNumber FBSATimelineController::GetScrubPosition() const
{
	if (CachedPreviewProxy.IsValid())
	{
		if (CachedPreviewProxy->GetPlayingInstanceV2() != nullptr)
		{
			return FFrameNumber(FMath::RoundToInt(CachedPreviewProxy->GetCurrentTime(SectionIndex) * GetTickResolution()));
		}
		else
		{
			return FFrameNumber(FMath::RoundToInt(ScrubPosition * GetTickResolution()));
		}
	}
	

	return FFrameNumber(0);
}

void FBSATimelineController::SetScrubPosition(FFrameTime NewScrubPosition) const
{
	if(CachedPreviewProxy.IsValid())
	{
		if(CachedPreviewProxy->IsPlaying())
		{
			CachedPreviewProxy->Stop();
		}
		
		float PositionValue =  static_cast<float>(NewScrubPosition.AsDecimal() / static_cast<double>(GetTickResolution()));

		PositionValue = FMath::Min(FMath::Max(PositionValue, 0), GetPlayLength());

		CachedPreviewProxy->TimeLineClick(ScrubPosition, PositionValue);
		
		ScrubPosition = PositionValue;
	}
}

float FBSATimelineController::GetPlayLength() const
{
	if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
	{
		return Asset->GetSectionPointerByIndex(SectionIndex)->SectionDuration;
	}

	return 0.f;
}

double FBSATimelineController::GetFrameRate() const
{
	return BSFrameRate;
}

UBSAAsset* FBSATimelineController::GetAsset() const
{
	return CachedPreviewProxy->GetPreviewAsset();
}

#pragma endregion Parameter



#pragma region Input
void FBSATimelineController::ChangeCtrlState(bool bPress)
{
	bPressCtrl = bPress;
}

#pragma endregion Input



#pragma region Task
void FBSATimelineController::ClearTaskSelection()
{
	CachedEditor.Pin()->SetTaskSelection(TArray<UBSATask*>{});
}

void FBSATimelineController::ChangeTaskSelection(const TArray<UBSATask*>& Tasks)
{
	CachedEditor.Pin()->SetTaskSelection(Tasks, !bPressCtrl);
}

void FBSATimelineController::ChangeTaskName(UBSATask* AtTask, FName NewName)
{
	GEditor->BeginTransaction(NSLOCTEXT("AnimNotifyNode", "TaskRedo", "ChangeTaskName"));
	AtTask->SetTaskName(FText::FromName(NewName));
	AtTask->Modify();
	GEditor->EndTransaction();
}

void FBSATimelineController::ChangeTaskPosition(UBSATask* SrcTask, UBSATask* DestTask)
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	if (SrcTask == DestTask)
		return;

	UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset();
	if (!Asset)
		return;

	FBSATaskSection* Section = Asset->GetSectionPointerByIndex(SectionIndex);
	if (!Section)
		return;

	int32 SrcGroupIndex = -1;
	int32 DestGroupIndex = -1;
	int32 DestIndex = -1;

	for (int32 GroupIndex = 0; GroupIndex < Section->TaskGroups.Num(); ++GroupIndex)
	{
		if (Section->TaskGroups[GroupIndex].TaskList.Contains(SrcTask))
		{
			SrcGroupIndex = GroupIndex;
			break;
		}
	}

	for (int32 GroupIndex = 0; GroupIndex < Section->TaskGroups.Num(); ++GroupIndex)
	{
		for (int32 TaskIndex = 0; TaskIndex < Section->TaskGroups[GroupIndex].TaskList.Num(); ++TaskIndex)
		{
			if (Section->TaskGroups[GroupIndex].TaskList[TaskIndex] == DestTask)
			{
				DestGroupIndex = GroupIndex;
				DestIndex = TaskIndex;
				break;
			}
		}
	}

	if (SrcGroupIndex < 0 || DestGroupIndex < 0)
		return;

	// 从原先的Group中删除，然后添加到新的Group中
	Section->TaskGroups[SrcGroupIndex].TaskList.Remove(SrcTask);
	Section->TaskGroups[DestGroupIndex].TaskList.Insert(SrcTask, DestIndex);

	RefreshTracks();

	Asset->GetPackage()->MarkPackageDirty();
}

void FBSATimelineController::ChangeTaskGroup(UBSATask* SrcTask, struct FBSATaskGroup* DestGroupData)
{
	GEditor->BeginTransaction(NSLOCTEXT("AnimNotifyNode", "TaskRedo", "ChangeTaskGroup"));
	if (!CachedEditor.Pin()->IsStopped())
		return;

	UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset();
	if (!Asset)
		return;
	Asset->Modify();
	FBSATaskSection* Section = Asset->GetSectionPointerByIndex(SectionIndex);
	if (!Section)
		return;

	int32 SrcGroupIndex = -1;
	int32 DestGroupIndex = FindGroupID(DestGroupData);

	for (int32 GroupIndex = 0; GroupIndex < Section->TaskGroups.Num(); ++GroupIndex)
	{
		if (Section->TaskGroups[GroupIndex].TaskList.Contains(SrcTask))
		{
			SrcGroupIndex = GroupIndex;
			break;
		}
	}

	if (SrcGroupIndex < 0 || DestGroupIndex < 0)
		return;

	// 从原先的Group中删除，然后添加到新的Group中
	Section->TaskGroups[SrcGroupIndex].TaskList.Remove(SrcTask);
	Section->TaskGroups[DestGroupIndex].TaskList.Add(SrcTask);

	RefreshTracks();

	Asset->GetPackage()->MarkPackageDirty();
	GEditor->EndTransaction();
}

void FBSATimelineController::AddNewTaskGroup(const FName& Name)
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
	{
		GEditor->BeginTransaction(NSLOCTEXT("AnimNotifyNode", "TaskRedo", "AddNewTaskGroup"));
		Asset->Modify();
		Asset->AddGroup(SectionIndex, Name);
		GEditor->EndTransaction();

		RefreshTracks();
	}
}

void FBSATimelineController::DeleteTaskGroup(FBSATaskGroup* InGroup)
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
	{
		if (FBSATaskSection* Section = Asset->GetSectionPointerByIndex(SectionIndex))
		{
			int32 GroupID = FindGroupID(InGroup);

			if (GroupID >= 0)
			{
				GEditor->BeginTransaction(NSLOCTEXT("AnimNotifyNode", "TaskRedo", "DeleteTaskGroup"));
				Asset->Modify();
				Asset->RemoveGroup(SectionIndex, GroupID);
				GEditor->EndTransaction();
				RefreshTracks();
			}
		}
	}
}

UBSATask* FBSATimelineController::AddNewTask(FBSATaskGroup* AtGroup, UClass* InTaskClass, float StartTime)
{
	if (!CachedEditor.Pin()->IsStopped())
		return nullptr;

	if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
	{
		if (UBSATask* NewTask = NewObject<UBSATask>(Asset, InTaskClass, NAME_None, RF_Transactional))
		{
			int32 GroupID = FindGroupID(AtGroup);
			if (GroupID >= 0)
			{
				GEditor->BeginTransaction(NSLOCTEXT("AnimNotifyNode", "TaskRedo", "AddNewTask"));
				Asset->Modify();
				NewTask->SetStartTime(StartTime);
				Asset->AddTask(SectionIndex, GroupID, *NewTask);
				GEditor->EndTransaction();

				RefreshTracks();

				FBSAEditorDelegates::AddTaskEvent.Broadcast(NewTask);
			}

			return NewTask;
		}
	}

	return nullptr;
}

void FBSATimelineController::DeleteTask(UBSATask* TheTask)
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
	{
		GEditor->BeginTransaction(NSLOCTEXT("AnimNotifyNode", "TaskRedo", "DeleteTask"));
		Asset->Modify();
		int32 SectionID = -1;
		int32 GroupID = -1;

		Asset->GetSectionIDAndGroupID(*TheTask, SectionID, GroupID);

		Asset->RemoveTask(SectionID, GroupID, *TheTask);
		GEditor->EndTransaction();
		RefreshTracks();
	}
}

void FBSATimelineController::DeleteSelectedTasks()
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
	{
		GEditor->BeginTransaction(NSLOCTEXT("AnimNotifyNode", "TaskRedo", "DeleteSelectTasks"));
		Asset->Modify();
		int32 SectionID = -1;
		int32 GroupID = -1;

		TArray<UBSATask*> CurSelectedTasks = GetSelectedTasks();

		for (int32 i = 0; i < CurSelectedTasks.Num(); ++i)
		{
			Asset->GetSectionIDAndGroupID(*CurSelectedTasks[i], SectionID, GroupID);
			Asset->RemoveTask(SectionID, GroupID, *CurSelectedTasks[i]);
		}
		GEditor->EndTransaction();
		RefreshTracks();
	}
}

int32 FBSATimelineController::FindGroupID(FBSATaskGroup* AtGroup)
{
	int32 GroupID = -1;

	if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
	{
		if (FBSATaskSection* Section = Asset->GetSectionPointerByIndex(SectionIndex))
		{
			for (int32 i = 0; i < Section->TaskGroups.Num(); ++i)
			{
				if ((&Section->TaskGroups[i]) == AtGroup)
				{
					GroupID = i;
					break;
				}
			}
		}
	}

	return GroupID;
}

TArray<UBSATask*> FBSATimelineController::GetSelectedTasks()
{
	return CachedEditor.Pin()->GetTaskSelection();
}

void FBSATimelineController::ExpandLogicIncludedTasks(TArray<class UBSATask*>& InTasks)
{
	// 检查CollisionTargetInfos, InputDatas和EventTaskMap中是否有未加入复制的Task引用
	// 如果有，也需要加入复制，并在完成复制后修正Task为新生成的Task引用
	while (1)
	{
		TArray<UBSATask*> tTaskNeedCopy;
		for (UBSATask* tSingleTask : InTasks)
		{
			TArray<FBSATaskInputInfo> tTaskInputInfoArray;
			tSingleTask->GetCollisionTargetInfos(tTaskInputInfoArray);	// 统计CollisionTargetInfos
			tTaskInputInfoArray.Append(tSingleTask->InputDatas);		// 统计InputDatas

			TArray<FBSATaskSelector> tTaskSelectors;
			for (FBSATaskInputInfo tSingleTaskInputInfo : tTaskInputInfoArray)
			{
				tTaskSelectors.Add(tSingleTaskInputInfo.ProduceDataTask);
			}

			for (TPair<FName, FBSATaskSelectorList> tSingleEventTaskMap : tSingleTask->EventTaskMap)
			{
				// 统计EventTaskMap
				tTaskSelectors.Append(tSingleEventTaskMap.Value.SelectedTaskList);
			}

			for (int i = 0; i < tTaskSelectors.Num(); i++)
			{
				if (tTaskSelectors[i].SelectedTask != nullptr && !InTasks.Contains(tTaskSelectors[i].SelectedTask))
				{
					tTaskNeedCopy.AddUnique(Cast<UBSATask>(tTaskSelectors[i].SelectedTask));
				}
			}
		}

		if (tTaskNeedCopy.Num() == 0)
		{
			break;
		}
		else
		{
			InTasks.Append(tTaskNeedCopy);
			tTaskNeedCopy.Empty();
		}
	}
}

void FBSATimelineController::CopySelectedTasks()
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	TArray<UBSATask*> tOriginTasks = GetSelectedTasks();
	//ExpandLogicIncludedTasks(tOriginTasks);

	FString CopyString;
	CopyString += TEXT("BEGIN Copy UTask!\n");
	for (int32 i = 0; i < tOriginTasks.Num(); ++i)
	{
		if (tOriginTasks[i])
		{
			TSoftObjectPtr<UBSATask> ObjectPath(tOriginTasks[i]);
			CopyString += ObjectPath.ToString() + TEXT("!!!!");
		}
	}

	FPlatformApplicationMisc::ClipboardCopy(*CopyString);
}

void FBSATimelineController::PasteSelectedTasks(FString InPasteMsg, int32 InGroupID)
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	FBSATaskGroup* NewTaskGoup;
	if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
	{
		GEditor->BeginTransaction(NSLOCTEXT("AnimNotifyNode", "TaskRedo", "PasteSelectedTasks"));
		Asset->Modify();
		TArray<UBSATask*> OldTasks;
		TArray<FString> AllPaths;
		InPasteMsg.ParseIntoArray(AllPaths, TEXT("!!!!"));
		for (int32 i = 0; i < AllPaths.Num(); ++i)
		{
			TSoftObjectPtr<UBSATask> ObjectPath(AllPaths[i]);

			if (ObjectPath.IsNull())
				continue;

			UBSATask* OldTask = Cast<UBSATask>(ObjectPath.LoadSynchronous());
			if (OldTask)
			{
				OldTasks.Add(OldTask);
			}
		}

		if (FBSATaskSection* Section = Asset->GetSectionPointerByIndex(SectionIndex))
		{
			if (Section->TaskGroups.Num() > 0)
			{
				if (!Section->TaskGroups.IsValidIndex(InGroupID))
				{
					InGroupID = Section->TaskGroups.Num() - 1;
				}

				// 获取新建TaskGroup的地址
				NewTaskGoup = &Section->TaskGroups[InGroupID];

				// 复制所选的Tasks
				TArray<UBSATask*> NewTasks;
				for (UBSATask* OldTask : OldTasks)
				{
					UBSATask* NewTask = AddNewTask(NewTaskGoup, OldTask->GetClass(), 0.0f);
					NewTask->CopyDataFromOther(OldTask);
					NewTasks.Add(NewTask);
				}

				// 更新CollisionTargetInfos, InputDatas和EventTaskMap
				UBSATask::FixTaskListDependency(NewTasks, OldTasks);

				// 对更新了LogicPin关系的节点，要生成LogicGraph的对应节点
				CachedEditor.Pin()->GenerateGraphNodesByTaskList(NewTasks);

				RefreshTracks();
			}
		}
		GEditor->EndTransaction();
	}
}

void FBSATimelineController::ExportSelectedTaskTemplate()
{
	//创建模板命名弹窗
	TemplateNameWindow = SNew(SWindow)
		.AutoCenter(EAutoCenter::PreferredWorkArea)
		.Title(LOCTEXT("TaskTemplateNameTitle", "设置TaskTemplate名称"))
		.SizingRule(ESizingRule::FixedSize)
		.SupportsMaximize(false)
		.SupportsMinimize(false).HasCloseButton(true)
		.ClientSize(FVector2D(350, 120))
		.CreateTitleBar(true);
	
	//创建弹窗内容
	TSharedPtr< SWidget > content =
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBox)
			.HeightOverride(90)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.HAlign(HAlign_Center)
				.Padding(0.0f, 12.0f, 0.0f, 12.0f)
				.AutoHeight()
				[
					SNew(SEditableText)	
					.HintText(LOCTEXT("TaskTemplateNameInputHint", "请输入TaskTemplate名称"))
					.OnTextChanged_Lambda([this](const FText& InText) { TemplateName = InText;})
					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 20))
				]

				+ SVerticalBox::Slot()
				.HAlign(HAlign_Center)
				.AutoHeight()
				[
					SNew(SButton)
					.Text(LOCTEXT("TaskTemplateNameConfirm", "确认"))
					.OnClicked_Lambda([this]()
						{
							if (TemplateName.IsEmpty())
							{
								FText DialogText = LOCTEXT("空Task模板错误", "请勿设置TaskTemplate名称为空...");
								FMessageDialog::Open(EAppMsgType::Ok, DialogText);
							}
							else
							{
								ExportSelectedTaskTemplate_Impl();
							}
							TemplateNameWindow.ToSharedRef().Get().RequestDestroyWindow();
							return FReply::Handled();
						}
					)
				]
			]
		];
	//将弹窗内容添加到弹框中
	TemplateNameWindow->SetContent(content.ToSharedRef());
	//显示弹窗
	FSlateApplication::Get().AddWindow(TemplateNameWindow.ToSharedRef());
}

void FBSATimelineController::ExportSelectedTaskTemplate_Impl()
{
	TArray<UBSATask*> tOriginTasks = GetSelectedTasks();
	//ExpandLogicIncludedTasks(tOriginTasks);

	if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
	{
		if (const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>())
		{
			if (UBSATaskTemplate* TaskTemplate = Setting->TaskTemplate.LoadSynchronous())
			{
				// 避免出现同名模板
				for (FBSATaskTemplateInfo SingleTaskGroup : TaskTemplate->TaskGroups)
				{
					if (SingleTaskGroup.Name == FName(TemplateName.ToString()))
					{
						FText DialogText = LOCTEXT("同名Task模板错误", "存在同名Task模板...");
						FMessageDialog::Open(EAppMsgType::Ok, DialogText);
						return;
					}
				}

				// 新建TaskGroup
				FBSATaskTemplateInfo tNewTaskGroup = FBSATaskTemplateInfo(FName(TemplateName.ToString()));

				// 复制所选的Tasks
				for (UBSATask* tOriginTask : tOriginTasks)
				{
					UBSATask* NewTask = NewObject<UBSATask>(TaskTemplate, tOriginTask->GetClass());
					NewTask->CopyDataFromOther(tOriginTask);
					tNewTaskGroup.TaskList.Add(NewTask);
				}
				// 更新CollisionTargetInfos, InputDatas和EventTaskMap
				UBSATask::FixTaskListDependency(tNewTaskGroup.TaskList, tOriginTasks);

				// 添加至TaskTemplate
				TaskTemplate->TaskGroups.Add(tNewTaskGroup);

				// Save
				TaskTemplate->MarkPackageDirty();
				TArray<UPackage*> PackagesToSave;
				PackagesToSave.AddUnique(TaskTemplate->GetOutermost());
				FEditorFileUtils::PromptForCheckoutAndSave(PackagesToSave, true, true);

				// Checkout
				FString DefaultLocation = FPaths::GetPath(TaskTemplate->GetPathName()); //生成原文件路径
				DefaultLocation.Split(TEXT("/Game/"), nullptr, &DefaultLocation);
				DefaultLocation = FPaths::ProjectContentDir() + DefaultLocation + TEXT("/") + TaskTemplate->GetName() + TEXT(".uasset");

				FText ErrorMessage;
				SourceControlHelpers::CheckoutOrMarkForAdd(DefaultLocation, FText::FromString(DefaultLocation), NULL, ErrorMessage);
			}
		}
	}
}

void FBSATimelineController::ImportTaskTemplate(FName InTemplateName, int32 InGroupID)
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	if (const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>())
	{
		if (UBSATaskTemplate* TaskTemplate = Setting->TaskTemplate.LoadSynchronous())
		{
			// 找到Template中的同名模板
			for (FBSATaskTemplateInfo SingleTaskGroup : TaskTemplate->TaskGroups)
			{
				if (SingleTaskGroup.Name == FName(InTemplateName.ToString()))
				{
					if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
					{
						if (FBSATaskSection* Section = Asset->GetSectionPointerByIndex(SectionIndex))
						{
							if (!Section->TaskGroups.IsValidIndex(InGroupID))
							{
								InGroupID = Section->TaskGroups.Num() - 1;
							}

							FBSATaskGroup* tNewTaskGoup = &Section->TaskGroups[InGroupID];

							// 复制所选的Tasks
							TArray<UBSATask*> tCopiedTasks;
							for (TWeakObjectPtr<UBSATask> tOriginTask : SingleTaskGroup.TaskList)
							{
								UBSATask* tCopiedTask = AddNewTask(tNewTaskGoup, tOriginTask->GetClass(), 0.0f);
								tCopiedTask->CopyDataFromOther(tOriginTask.Get());
								tCopiedTasks.Add(tCopiedTask);
							}

							// 更新CollisionTargetInfos, InputDatas和EventTaskMap
							UBSATask::FixTaskListDependency(tCopiedTasks, SingleTaskGroup.TaskList);
							// 对更新了LogicPin关系的节点，要生成LogicGraph的对应节点
							CachedEditor.Pin()->GenerateGraphNodesByTaskList(tCopiedTasks);

							RefreshTracks();
						}
					}
					break;
				}
			}
		}
	}
}

#pragma endregion Task



#pragma region Event
void FBSATimelineController::ReceiveAutoOptimizeDone(UBSAAsset* Asset)
{
	if (CachedPreviewProxy->GetPreviewAsset() == Asset)
	{
		RefreshTracks();
	}
}
#pragma endregion Event






#pragma region BackUp
/*void FBSATimelineController::ExportSelectedTasks()
{
	if (!CachedEditor.Pin()->IsStopped())
		return;

	TArray<UBSATask*> tOriginTasks = GetSelectedTasks();
	ExpandLogicIncludedTasks(tOriginTasks);

	if (IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get())
	{
		if (UBSAAsset* Asset = CachedPreviewProxy->GetPreviewAsset())
		{
			FString DestinationFolder;
			const void* ParentWindowHandle = FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr);
			const FString Title = LOCTEXT("DatasmithDirProducerFolderTitle", "Choose a folder for new Skill Asset(default)").ToString();

			const FString AssetFileName = FString::FromInt(FCString::Atoi(*Asset->GetName()) + 1) + TEXT(".uasset"); // 默认存储名字为当前Asset的ID+1
			FString DefaultLocation = FPaths::GetPath(Asset->GetFullName()); //生成原文件路径
			DefaultLocation.Split(TEXT("/Game/"), nullptr, &DefaultLocation);
			DefaultLocation = FPaths::ProjectContentDir() + DefaultLocation;

			// 保存Dialog
			TArray<FString> SaveFilenames;
			const bool bSaved = DesktopPlatform->SaveFileDialog(
				FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
				LOCTEXT("ExportTaskSaveTitle", "Save Exported Skill Asset").ToString(),
				DefaultLocation,
				AssetFileName,
				TEXT("SkillAsset|*.uasset"),
				EFileDialogFlags::None,
				SaveFilenames
			);

			// 同名文件替换暂时不允许
			if (bSaved && SaveFilenames.Num() > 0)
			{
				if (IFileManager::Get().FileExists(*SaveFilenames[0]))
				{
					FText DialogText = LOCTEXT("提示", "暂不支持导出覆盖已有SkillAsset...");
					FMessageDialog::Open(EAppMsgType::Ok, DialogText);
					return;
				}

				IFileManager::Get().Copy(*SaveFilenames[0], *(DefaultLocation + TEXT("/") + Asset->GetName() + TEXT(".uasset")));
				UPackage* Package = LoadPackage(NULL, *SaveFilenames[0], LOAD_NoRedirects);
				Package->FullyLoad();
				UBSAAsset* NewSkillAsset = FindObject<UBSAAsset>(Package, *Asset->GetName()); //此时Asset仍然为旧ID

				if (NewSkillAsset)
				{
					UEditorUtilityLibrary::RenameAsset(NewSkillAsset, FPaths::GetBaseFilename(SaveFilenames[0])); //改名为新ID

					// 去掉旧的Task，只保留选中要导出的Task
					TArray<int> SectionID2Delete, GroupID2Delete;
					TArray<UBSATask*> Task2Delete;
					for (int i = 0; i < Asset->GetSectionNum(); i++)
					{
						FBSATaskSection* tTaskSection = Asset->GetSectionPointerByIndex(i);
						for (int j = 0; j < tTaskSection->TaskGroups.Num(); j++)
						{
							for (int k = 0; k < tTaskSection->TaskGroups[j].TaskList.Num(); k++)
							{
								if (!tOriginTasks.Contains(tTaskSection->TaskGroups[j].TaskList[k].Get()))
								{
									SectionID2Delete.Add(i);
									GroupID2Delete.Add(j);
									Task2Delete.Add(NewSkillAsset->GetSectionPointerByIndex(i)->TaskGroups[j].TaskList[k].Get());
								}
							}
						}
					}
					for (int i = 0; i < SectionID2Delete.Num(); i++)
					{
						NewSkillAsset->RemoveTask(SectionID2Delete[i], GroupID2Delete[i], *Task2Delete[i]);
					}

					// Checkout并在技能编辑器中打开文件
					FText ErrorMessage;
					SourceControlHelpers::CheckoutOrMarkForAdd(SaveFilenames[0], FText::FromString(SaveFilenames[0]), NULL, ErrorMessage);
					GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(NewSkillAsset);
				}
			}
		}
	}
}*/
#pragma endregion BackUp



#undef LOCTEXT_NAMESPACE