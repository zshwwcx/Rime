#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskGhost.h"

#include "BattleSystem/BSFunctionLibrary.h"

#include "3C/Character/BSAGhostActor.h"



void UBSATAddGhost::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	InOutList.AddUnique(AnimSequence.ToString());
}

#if WITH_EDITOR
void UBSATAddGhost::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	// BaseMaterial.bReplaceAllMaterial = true;
	// BaseMaterial.MaterialIDs.Empty();
	// BaseMaterial.MaterialSlotNames.Empty();
}

void UBSATAddGhost::UpdateDataByDynamicActorInfo(const FBSADynamicObjectInfo& InInfo)
{
	if (!InInfo.DynamicObject)
		return;

	ABSAGhostActor* GhostActor = Cast<ABSAGhostActor>(InInfo.DynamicObject);
	if (GhostActor != nullptr)
	{
		if (bNeedAttach)
		{
			AttachTransform.ConfigValue = GhostActor->GetRootComponent()->GetRelativeTransform();
		}
		else if (!CoordinateCreater.OffsetTransform.bUseInputData)
		{
			FTransform CurWorldTransform = GhostActor->GetActorTransform();
			CoordinateCreater.OffsetTransform.ConfigValue = CurWorldTransform * InInfo.CachedTransform.Inverse();
		}
	}
}

void UBSATAddGhost::UpdateDynamicActorByData(const FBSADynamicObjectInfoArray& InInfoArray)
{
	for (int32 i = 0; i < InInfoArray.Informations.Num(); ++i)
	{
		if (!InInfoArray.Informations[i].DynamicObject)
			continue;

		ABSAGhostActor* GhostActor = Cast<ABSAGhostActor>(InInfoArray.Informations[i].DynamicObject);
		if (GhostActor != nullptr)
		{
			if (bNeedAttach)
			{
				GhostActor->SetActorRelativeTransform(AttachTransform.ConfigValue);

			}
			else if (!CoordinateCreater.OffsetTransform.bUseInputData)
			{
				FTransform CurWorldTransform = CoordinateCreater.OffsetTransform.ConfigValue * InInfoArray.Informations[i].CachedTransform;

				GhostActor->SetActorTransform(CurWorldTransform);
			}
		}
	}
}
#endif
