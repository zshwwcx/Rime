#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "LevelEditor.h"
#include "UObject/SavePackage.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Modules/ModuleManager.h"
#include "GameFramework/GameStateBase.h"
#include "GameFramework/WorldSettings.h"
#include "Components/ShapeComponent.h"
#include "EdGraphUtilities.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Framework/Commands/GenericCommands.h"
#include "Misc/FileHelper.h"
#include "SourceControlHelpers.h"
#include "HAL/PlatformFilemanager.h"
#include "FileHelpers.h"
#include "Engine/UserDefinedEnum.h"

#include "Misc/LowLevelFunctions.h"
#include "LevelLuaEditorProxyBase.h"

#include "BattleSystemEditor/BSEditorLuaGI.h"
#include "BattleSystemEditor/AbilityEditor/BSAJsonExporter.h"
#include "BattleSystemEditor/AbilityEditor/BSAPreviewProxy.h"
#include "BattleSystemEditor/AbilityEditor/BSAPreviewSettings.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorPreviewScene.h"
#include "BattleSystemEditor/AbilityEditor/Viewport/BSAEditorViewportClient.h"
#include "BattleSystemEditor/AbilityEditor/Modes/BSAEditorMode.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorDelegates.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorToolbar.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorCommands.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"
#include "BattleSystemEditor/AbilityEditor/BSALogicGraphSchema.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorAssetManager.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/BSALogicGraph.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/BSALogicGraphNode.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/SBSALogicGraphNode.h"

#include "DoraSDK.h"

#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSADetailTab.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/SBSAEditorViewport.h"

#include "BattleSystem/BSMacroDefinition.h"
#include "BattleSystem/BSSettings.h"
#include "BattleSystem/BSManager.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "Engine/BlueprintGeneratedClass.h"
#include "BattleSystemEditor/AbilityEditor/Preview/BSAPreviewGameMode.h"
#include "KGBattleSystemEditorModule.h"


const FName BSAEditorAppIdentifier = TEXT("BSAEditorApp");



const FName BSAEditorModes::Main(TEXT("MainMode"));
const FName BSAEditorModes::LogicGraph(TEXT("LogicGraphMode"));



const FName BSAEditorTabs::ViewportTab(TEXT("Viewport"));
const FName BSAEditorTabs::AssetEdit(TEXT("Asset"));
const FName BSAEditorTabs::AssetBrowser(TEXT("AssetBrowser"));
const FName BSAEditorTabs::AssetDetails(TEXT("AssetDetails"));
const FName BSAEditorTabs::Details(TEXT("Details"));
const FName BSAEditorTabs::PreviewSettings(TEXT("PreviewSettings"));

const FName BSAEditorTabs::GraphEdit(TEXT("GraphEdit"));
const FName BSAEditorTabs::GraphPallete(TEXT("GraphPallete"));
const FName BSAEditorTabs::GraphDetail(TEXT("GraphDetail"));



#define LOCTEXT_NAMESPACE "BSAEditor"



class FBSALogicGraphNodeFactory : public FGraphPanelNodeFactory
{
	virtual TSharedPtr<SGraphNode> CreateNode(UEdGraphNode* Node) const override
	{
		if (UBSALogicGraphNode* GraphNode = Cast<UBSALogicGraphNode>(Node))
		{
			return SNew(SBSALogicGraphNode, GraphNode);
		}

		return nullptr;
	}
};
TSharedPtr<FGraphPanelNodeFactory> BSALogicGraphNodeFactory;



TSharedPtr<IBSAEditor> IBSAEditor::OpenEditor(UObject* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost)
{
	check(InAsset);

	TSharedPtr<FBSAEditor> EditorPtr(new FBSAEditor());

	EditorPtr->InitializeEditor(Cast<UBSAAsset>(InAsset), InitToolkitHost);

	return EditorPtr;
}



#pragma region Important
TArray<int64> FBSAEditor::ExistBSAEditorGUIDs = TArray<int64>();
int32 FBSAEditor::BSAEditorIndex = 0;

FBSAEditor::FBSAEditor()
{
	CurBSAEditorGUID = ULowLevelFunctions::GetGlobalUniqueID();
	FBSAEditor::ExistBSAEditorGUIDs.AddUnique(CurBSAEditorGUID);
	FBSAEditor::BSAEditorIndex += 1;
	if (FBSAEditor::ExistBSAEditorGUIDs.Num() == 1)
	{
		if (UBSAEditorAssetManager* Manager = NewObject<UBSAEditorAssetManager>())
		{
			Manager->Init();
		}
	}

	// 注册节点工厂
	BSALogicGraphNodeFactory = MakeShareable(new FBSALogicGraphNodeFactory());
	FEdGraphUtilities::RegisterVisualNodeFactory(BSALogicGraphNodeFactory);
}

FBSAEditor::~FBSAEditor()
{
	//add by wangwenfeng05@kuaishou.com 触发析构回调
	FBSAEditorDelegates::OnDestructorEditorDelegate.Broadcast(this);
}

void FBSAEditor::InitializeEditor(UBSAAsset* InAsset, const TSharedPtr<IToolkitHost>& InInitToolkitHost)
{
	// 缓存编辑的资源指针
	check(InAsset);
	EditAsset = InAsset;

	// 获取所有的Task信息
	CollectAllTaskClass();

	// 缓存配置资源指针
	PreviewSettings = GetMutableDefault<UBSAPreviewSettings>(UBSAPreviewSettings::StaticClass());

	// 尝试创建逻辑图表
	if (!EditAsset->LogicGraph)
	{
		EditAsset->LogicGraph = CastChecked<UEdGraph>
		(
			FBlueprintEditorUtils::CreateNewGraph
			(
				EditAsset.Get(), TEXT("LogicGraph"),
				UBSALogicGraph::StaticClass(),
				UBSALogicGraphSchema::StaticClass()
			)
		);
	}

	// 尝试创建扩展数据对象
	if (const UBSAEditorSettings* EditorSetting = GetDefault<UBSAEditorSettings>())
	{
		if (!InAsset->ExpandData)
		{
			if (InAsset->IsA<UBSASkillAsset>())
			{
				InAsset->ExpandData = NewObject<UBSAAssetExpandData>(InAsset, EditorSetting->SkillExpandData);
			}
			else
			{
				InAsset->ExpandData = NewObject<UBSAAssetExpandData>(InAsset, EditorSetting->BuffExpandData);
			}

			InAsset->MarkPackageDirty();
		}
	}


	// 初始化UE的资源编辑器
	const bool bCreateDefaultStandaloneMenu = true;
	const bool bCreateDefaultToolbar = true;
	FAssetEditorToolkit::InitAssetEditor(EToolkitMode::Standalone, InInitToolkitHost, BSAEditorAppIdentifier, FTabManager::FLayout::NullLayout, bCreateDefaultStandaloneMenu, bCreateDefaultToolbar, InAsset);


	// 绑定指令
	BindCommands();
	// 扩展工具栏
	ExtendToolbar();


	// 创建预览场景
	CreatePreviewScene();
	// 初始化预览场景
	InitPreviewContext();


	// 初始化资源
	EditAsset->InitByEditor(PreviewScene->GetWorld());


	// 添加编辑器模式
	AddApplicationMode(BSAEditorModes::Main, MakeShareable(new FBSAEditorMode_Main(SharedThis(this))));
	AddApplicationMode(BSAEditorModes::LogicGraph, MakeShareable(new FBSAEditorMode_LogicGraph(SharedThis(this))));
	// 设置编辑器模式
	SetCurrentMode(BSAEditorModes::Main);


	// 创建临时文件路径
	TemporaryLuaFile = FPaths::ProjectDir() + TEXT("Intermediate/BSAEditor/");
	if (EditAsset->IsA<UBSASkillAsset>())
	{
		TemporaryLuaFile = TemporaryLuaFile + TEXT("S") + FString::FromInt(EditAsset->ID) + TEXT(".lua");
	}
	else if (EditAsset->IsA<UBSABuffAsset>())
	{
		TemporaryLuaFile = TemporaryLuaFile + TEXT("B") + FString::FromInt(EditAsset->ID) + TEXT(".lua");
	}
	if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*TemporaryLuaFile))
	{
		FFileHelper::SaveStringToFile(FString(), *TemporaryLuaFile, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_NoFail);
	}
	// 自动导出一次临时文件
	ExportAbilityToTemporaryFile();

	if (EditAsset.IsValid())
	{
		int32 Limit = 1000;
		TArray<FString> ResourcePaths;
		EditAsset->GetReferenceResources(ResourcePaths);
		while (ResourcePaths.Num() > 0 || Limit <= 0)
		{
			Limit = Limit - 1;

			TSoftObjectPtr<UObject> SoftPtr(ResourcePaths[ResourcePaths.Num() - 1]);
			ResourcePaths.RemoveAt(ResourcePaths.Num() - 1);

			if (!SoftPtr.IsNull() && !SoftPtr.IsValid())
			{
				if (UObject* TheObj = SoftPtr.LoadSynchronous())
				{
					if (UBSAAsset* Asset = Cast<UBSAAsset>(TheObj))
					{
						TArray<FString> CurPaths;
						Asset->GetReferenceResources(CurPaths);

						ResourcePaths.Append(CurPaths);
					}
				}
			}
		}
	}

	// 刷新碰撞
	UpdateHitBox();
}

void FBSAEditor::Tick(float DeltaTime)
{
	PreviewProxy->Tick(DeltaTime);
}

void FBSAEditor::OnClose()
{
	if (PreviewProxy.IsValid())
	{
		PreviewProxy->Finish();
	}

	if (PreviewScene.IsValid())
	{
		PreviewScene->Finish();
	}

	FBSAEditor::ExistBSAEditorGUIDs.Remove(CurBSAEditorGUID);
	if (FBSAEditor::ExistBSAEditorGUIDs.Num() == 0)
	{
		if (UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance())
		{
			EAMgr->UnInit();
		}
	}

	if (LuaEnv)
	{
        UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
	}

	FWorkflowCentricApplication::OnClose();
}

UBSAAsset* FBSAEditor::GetEditingAsset()
{
	return Cast<UBSAAsset>(GetEditingObject());
}

void FBSAEditor::SetCurrentMode(FName NewMode)
{
	// 如果是要切换到逻辑图编辑模式
	if (NewMode.IsEqual(BSAEditorModes::LogicGraph))
	{
		// 刷新一遍逻辑图表
		if (UBSALogicGraph* LogicGraph = Cast<UBSALogicGraph>(EditAsset->LogicGraph))
		{
			LogicGraph->RefreshLogicGraph();
		}
	}

	FWorkflowCentricApplication::SetCurrentMode(NewMode);
}

void FBSAEditor::SaveAsset_Execute()
{
	if (AutoOptimize() <= 5)
	{
		FAssetEditorToolkit::SaveAsset_Execute();
	}

	// 增量导出数据
	ExportCurrentAbilityJson();

	// 导出临时数据
	ExportAbilityToTemporaryFile();

	// 若 PIE world 正在运行，重新加载PIE world中的资源
	RefreshPIEWorldAbilityData();
}

#pragma endregion Important



#pragma region Editor
void FBSAEditor::RegisterTabSpawners(const TSharedRef<FTabManager>& InTabManager)
{
	WorkspaceMenuCategory = InTabManager->AddLocalWorkspaceMenuCategory(LOCTEXT("WorkspaceMenu_BSAEditor", "BSAEditor"));

	FAssetEditorToolkit::RegisterTabSpawners(InTabManager);
}

void FBSAEditor::UnregisterTabSpawners(const TSharedRef<FTabManager>& InTabManager)
{
	FAssetEditorToolkit::UnregisterTabSpawners(InTabManager);
}
FText FBSAEditor::GetBaseToolkitName() const
{
	return LOCTEXT("AppLabel", "BSAEditor");
}

FName FBSAEditor::GetToolkitFName() const
{
	return FName("BSAEditor");
}

FString FBSAEditor::GetWorldCentricTabPrefix() const
{
	return LOCTEXT("WorldCentricTabPrefix", "BattleSystemAbilityEditor").ToString();
}

FLinearColor FBSAEditor::GetWorldCentricTabColorScale() const
{
	return FLinearColor(0.3f, 0.2f, 0.5f, 0.5f);
}

void FBSAEditor::SetViewport(TSharedPtr<SBSAEditorViewport> InViewport)
{ 
	Viewport = InViewport; 
}

TSharedPtr<SBSAEditorViewport> FBSAEditor::GetViewportWidget()
{ 
	return Viewport; 
}

void FBSAEditor::SetDetailWidget(TSharedPtr<SBSADetailTab> InDetailWidget)
{ 
	DetailWidgetPtr = InDetailWidget; 
}

void FBSAEditor::SetGraphDetailWidget(TSharedPtr<SBSADetailTab> InDetailWidget)
{
	GraphDetailWidgetPtr = InDetailWidget;
}

void FBSAEditor::ExtendToolbar()
{
	// 创建工具栏
	if (!EditorToolbar.IsValid())
	{
		EditorToolbar = MakeShareable(new FBSAEditorToolbar());
	}

	if (ToolbarExtender.IsValid())
	{
		RemoveToolbarExtender(ToolbarExtender);
		ToolbarExtender.Reset();
	}

	ToolbarExtender = MakeShareable(new FExtender);

	EditorToolbar->SetupToolbar(ToolbarExtender, SharedThis(this));

	EditorToolbar->AddModesToolbar(ToolbarExtender);

	EditorToolbar->AddTimelineToolbar(ToolbarExtender);
		
	FBSAEditorDelegates::OnInitializeEditorFinishDelegate.Broadcast(SharedThis(this), ToolbarExtender);

	AddToolbarExtender(ToolbarExtender);

}

void FBSAEditor::ShowObjectDetail(UObject* InObject)
{
	if (DetailWidgetPtr.IsValid())
	{
		DetailWidgetPtr->SetDetailObject(InObject);
	}
}

void FBSAEditor::ShowGraphObjectDetail(UObject* InObject)
{
	if (GraphDetailWidgetPtr.IsValid())
	{
		if (UBSALogicGraphNode* GraphNode = Cast<UBSALogicGraphNode>(InObject))
		{
			GraphDetailWidgetPtr->SetDetailObject(GraphNode->CachedTask);
		}
	}
}

FText FBSAEditor::GetLocalizedMode(FName InMode)
{
	static TMap<FName, FText> LocModes;

	if (LocModes.Num() == 0)
	{
		LocModes.Add(BSAEditorModes::Main, LOCTEXT("MainMode", "Main"));
		LocModes.Add(BSAEditorModes::LogicGraph, LOCTEXT("LogicGraphMode", "LogicGraph"));
	}

	check(InMode != NAME_None);
	const FText* OutDesc = LocModes.Find(InMode);
	check(OutDesc);

	return *OutDesc;
}

void FBSAEditor::AddReferencedObjects(FReferenceCollector& Collector)
{
	
}

#pragma endregion Editor



#pragma region Command
void FBSAEditor::BindCommands()
{
	// 注册指令
	FBSAEditorCommands::Register();

	const FBSAEditorCommands& Commands = FBSAEditorCommands::Get();
	const TSharedRef<FUICommandList>& UICommandsList = GetToolkitCommands();

	UICommandsList->MapAction(Commands.Play, FExecuteAction::CreateSP(this, &FBSAEditor::Play));
	UICommandsList->MapAction(Commands.Stop, FExecuteAction::CreateSP(this, &FBSAEditor::Stop));
	UICommandsList->MapAction(Commands.Step, FExecuteAction::CreateSP(this, &FBSAEditor::Step));

	UICommandsList->MapAction(Commands.ResetWorld, FExecuteAction::CreateSP(this, &FBSAEditor::ResetWorld));
	UICommandsList->MapAction(Commands.ShowCollision, FExecuteAction::CreateSP(this, &FBSAEditor::ShowHitBox));

	UICommandsList->MapAction(FGenericCommands::Get().Delete, FExecuteAction::CreateRaw(this, &FBSAEditor::DeleteSelectedNodes));
}

void FBSAEditor::Play()
{
	if (!PreviewScene.IsValid())
		return;

	if (PreviewProxy->IsPlaying())
	{
		PreviewProxy->Pause();
	}
	else if (PreviewProxy->IsPaused())
	{
		PreviewProxy->Resume();
	}
	else
	{
		PreviewProxy->Play();
	}
}

bool FBSAEditor::IsPlaying() const
{
	return PreviewProxy->IsPlaying();
}

bool FBSAEditor::IsPaused() const
{
	return PreviewProxy->IsPaused();
}

bool FBSAEditor::IsStopped() const
{
	return PreviewProxy->IsStopped();
}

void FBSAEditor::Pause()
{
	if (PreviewProxy->IsPaused())
	{
		PreviewProxy->Resume();
	}
	else
	{
		PreviewProxy->Pause();
	}
}

void FBSAEditor::Stop()
{
	if (!PreviewProxy->IsStopped())
		PreviewProxy->Stop();
}

void FBSAEditor::Step()
{
	if (PreviewProxy->IsStopped())
	{
		PreviewProxy->Play();
		PreviewProxy->Pause();
	}
	else if (PreviewProxy->IsPlaying())
	{
		PreviewProxy->Pause();
	}

	TSharedPtr<FBSAEditorViewportClient> ViewportClient = StaticCastSharedPtr<FBSAEditorViewportClient>(Viewport.Get()->GetViewportClient());
	if (ViewportClient.IsValid())
	{
		ViewportClient->TickWorld(1.0f / BSFrameRate);
	}
}

void FBSAEditor::ResetWorld()
{
	ResetPreviewContext();
}

void FBSAEditor::ShowHitBox()
{
	bShowCollision = !bShowCollision;
	UpdateHitBox();
	FBSAEditorDelegates::SetShowCollisionEvent.Broadcast(bShowCollision);
}

void FBSAEditor::UpdateHitBox()
{
	if (bShowCollision)
	{
		TArray<TWeakObjectPtr<AActor>> PreviewActors = PreviewScene->GetPreviewActors();
		for (int32 i = 0; i < PreviewActors.Num(); ++i)
		{
			if (!PreviewActors[i].IsValid())
			{
				continue;
			}

			TArray<UShapeComponent*> Components;
			PreviewActors[i]->GetComponents<UShapeComponent>(Components);
			for (int32 k = 0; k < Components.Num(); ++k)
			{
				if (Components[k])
				{
					Components[k]->SetVisibility(true);
					Components[k]->SetHiddenInGame(false);
				}
			}
		}
	}
	else
	{
		TArray<TWeakObjectPtr<AActor>> PreviewActors = PreviewScene->GetPreviewActors();
		for (int32 i = 0; i < PreviewActors.Num(); ++i)
		{
			if (!PreviewActors[i].IsValid())
			{
				continue;
			}

			TArray<UShapeComponent*> Components;
			PreviewActors[i]->GetComponents<UShapeComponent>(Components);
			for (int32 k = 0; k < Components.Num(); ++k)
			{
				if (Components[k])
				{
					Components[k]->SetVisibility(false);
					Components[k]->SetHiddenInGame(true);
				}
			}
		}
	}

	if (GetBSManager())
	{
		GetBSManager()->ChangeShowCollision(PreviewSettings->ShowHitBoxDuration, bShowCollision);
	}
}

void FBSAEditor::UpdateAllAbilityData()
{
	UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance();
	if (!EAMgr)
	{
		return;
	}

	const UBSAEditorSettings* EditorSetting = GetDefault<UBSAEditorSettings>();

	TArray<int32> SkillIDList = EAMgr->GetSkillIDList();
	for (int32 i = 0; i < SkillIDList.Num(); ++i)
	{
		if (UBSASkillAsset* Asset = EAMgr->GetSkillAssetByID(SkillIDList[i]))
		{
			if (Asset->ExpandData && Asset->ExpandData->UpdateEditorProperty())
			{
				Asset->MarkPackageDirty();
			}

			int32 SectionNum = Asset->GetSectionNum();
			for (int32 j = 0; j < SectionNum; ++j)
			{
				if (FBSATaskSection* CurSection = Asset->GetSectionPointerByIndex(j))
				{
					for (int32 k = 0; k < CurSection->TaskList.Num(); ++k)
					{
						if (CurSection->TaskList[k] && (CurSection->TaskList[k]->UpdateEditorProperty() || CurSection->TaskList[k]->UpdateBlueprintProperty()))
						{
							Asset->MarkPackageDirty();
						}
					}
				}
			}
		}
	}

	TArray<int32> BuffIDList = EAMgr->GetBuffIDList();
	for (int32 i = 0; i < BuffIDList.Num(); ++i)
	{
		if (UBSABuffAsset* Asset = EAMgr->GetBuffAssetByID(BuffIDList[i]))
		{
			if (Asset->ExpandData && Asset->ExpandData->UpdateEditorProperty())
			{
				Asset->MarkPackageDirty();
			}

			int32 SectionNum = Asset->GetSectionNum();
			for (int32 j = 0; j < SectionNum; ++j)
			{
				if (FBSATaskSection* CurSection = Asset->GetSectionPointerByIndex(j))
				{
					for (int32 k = 0; k < CurSection->TaskList.Num(); ++k)
					{
						if (CurSection->TaskList[k] && (CurSection->TaskList[k]->UpdateEditorProperty() || CurSection->TaskList[k]->UpdateBlueprintProperty()))
						{
							Asset->MarkPackageDirty();
						}
					}
				}
			}
		}
	}
}

void FBSAEditor::ExportAllAbilityJson()
{
	UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance();
	if (!EAMgr)
	{
		return;
	}

	TArray<UPackage*> AllAbilityAssets;

	TArray<int32> SkillIDList = EAMgr->GetSkillIDList();
	for (int32 i = 0; i < SkillIDList.Num(); ++i)
	{
		if (UBSAAsset* CurAsset = EAMgr->GetSkillAssetByID(SkillIDList[i]))
		{
			AllAbilityAssets.AddUnique(CurAsset->GetOutermost());
		}
	}

	// 自动生成一下技能后摇开始时间
	AutoGenSkillRecoveryStartTime(SkillIDList);

	TArray<int32> BuffIDList = EAMgr->GetBuffIDList();
	for (int32 i = 0; i < BuffIDList.Num(); ++i)
	{
		if (UBSAAsset* CurAsset = EAMgr->GetBuffAssetByID(BuffIDList[i]))
		{
			AllAbilityAssets.AddUnique(CurAsset->GetOutermost());
		}
	}

	// 保存并迁出发生修改过的资源文件
	FEditorFileUtils::PromptForCheckoutAndSave(AllAbilityAssets, false, true);

	FindAndExportAbilityAssetToJson();
}

void FBSAEditor::ExportCurrentAbilityJson()
{
	if (EditAsset.IsValid())
	{
		int32 Type = 0;

		if (EditAsset->IsA<UBSASkillAsset>())
		{
			Type = 1;
		}
		else if (EditAsset->IsA<UBSABuffAsset>())
		{
			Type = 2;
		}

		FindAndExportAbilityAssetToJson(UBSEditorFunctionLibrary::GetAbilityHeadID(EditAsset->ID), Type, EditAsset->ID);
	}
}

void FBSAEditor::RefreshGameplayTags()
{
    UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(LuaEnv->GetLuaGameInstance());
	if (!IsValid(GI))
	{
		return;
	}

	UBSEditorFunctionLibrary::UpdatePropTagList(GI, true);
}

void FBSAEditor::RefreshPIEWorldAbilityData()
{
	if (EditAsset->IsA<UBSASkillAsset>())
	{
		UBSManager::ReloadAllSkillAsset(EditAsset->ID);
	}
	else if (EditAsset->IsA<UBSABuffAsset>())
	{
		UBSManager::ReloadPIEBuffAsset(EditAsset->ID);
	}
}

void FBSAEditor::ExportAbilityToTemporaryFile()
{
    UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(LuaEnv->GetLuaGameInstance());
	if (!IsValid(GI))
	{
		return;
	}

	FString FileWriteData;
	TSharedPtr<TJsonWriter<TCHAR>> JsonWriter;
	TArray<TSharedPtr<FJsonValue>> JsonValues;

	TSharedPtr<FJsonObject> NewObject = UBSEditorFunctionLibrary::ExportAbilityToJson(EditAsset.Get());

	JsonValues.Add(MakeShareable(new FJsonValueObject(NewObject)));

	JsonWriter = TJsonWriterFactory<TCHAR>::Create(&FileWriteData);
	FJsonSerializer::Serialize(JsonValues, *JsonWriter);

	// 导出Lua表
	FileWriteData = GI->ConvertJsonToLuaTable(FileWriteData, -1);
	FFileHelper::SaveStringToFile(FileWriteData, *TemporaryLuaFile);

	// 重新加载资源
	if (GetBSManager())
	{
		if (EditAsset->IsA<UBSASkillAsset>())
		{
			GetBSManager()->ReloadEditorSkillAsset(EditAsset->ID);
		}
		else if (EditAsset->IsA<UBSABuffAsset>())
		{
			GetBSManager()->ReloadEditorBuffAsset(EditAsset->ID);
		}
	}
}

void FBSAEditor::FindAndExportAbilityAssetToJson(int32 HeadID, int32 ExportType, int32 UpdateID)
{
    UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(LuaEnv->GetLuaGameInstance());

	if (const UBSSettings* Settings = GetDefault<UBSSettings>())
	{
		if (UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance())
		{
			EAMgr->UsedGuidList.Empty();
			EAMgr->UsedGuidNameList.Empty();
		}
		
		// 一、导出技能数据
		UBSEditorFunctionLibrary::ExportSkillData(GI, HeadID, ExportType, UpdateID);

		// 二、导出BUFF数据
		UBSEditorFunctionLibrary::ExportBuffData(GI, HeadID, ExportType, UpdateID);
	}
}

int32 FBSAEditor::AutoOptimize()
{
	if (EditAsset.IsValid())
	{
		// 手动执行预保存
		FObjectSaveContextData OSCD;
		TArray<UObject*> ObjectsInPackage;
		GetObjectsWithPackage(EditAsset->GetPackage(), ObjectsInPackage);
		for (UObject* Object : ObjectsInPackage)
		{
			if (Object->IsA<UBSALogicGraphNode>())
			{
				UE::SavePackageUtilities::CallPreSave(Object, OSCD);
			}
		}
		for (UObject* Object : ObjectsInPackage)
		{
			if (Object->IsA<UBSATask>())
			{
				UE::SavePackageUtilities::CallPreSave(Object, OSCD);
			}
		}
		for (UObject* Object : ObjectsInPackage)
		{
			if (!Object->IsA<UBSALogicGraphNode>() && !Object->IsA<UBSATask>())
			{
				UE::SavePackageUtilities::CallPreSave(Object, OSCD);
			}
		}

		EditAsset.Get()->AutoOptimizeTask();

		return EditAsset.Get()->ConfigProblemNumber;
	}

	return 0;
}

void FBSAEditor::OnAnyBSEditorStartPlay()
{
	ResetPreviewContext();
}

void FBSAEditor::CheckAllResources()
{
	UBSEditorFunctionLibrary::CheckSkillBuffResouces();
}

void FBSAEditor::AutoFixAllResources()
{
	UBSEditorFunctionLibrary::AutoFixSkillBuffResouces();
}

void FBSAEditor::AutoGenSkillRecoveryStartTime(TArray<int32> SkillIDs)
{
	UBSEditorFunctionLibrary::AutoGenSkillRecoveryStartTime(SkillIDs);
}
#pragma endregion Command



#pragma region Preview
TSharedPtr<FBSAEditorPreviewScene> FBSAEditor::GetPreviewScene() const
{ 
	return PreviewScene; 
}

TSharedPtr<FPreviewScene> FBSAEditor::GetPreviewSceneBase() const
{ 
	return PreviewScene; 
}

UBSAPreviewSettings* FBSAEditor::GetPreviewSettings()
{ 
	return PreviewSettings.Get(); 
}

TSharedPtr<FBSAPreviewProxy> FBSAEditor::GetPreviewProxy() const
{ 
	return PreviewProxy; 
}

bool FBSAEditor::ShouldPauseWorld() const
{
	if (PreviewProxy->IsPaused())
	{
		return true;
	}

	return false;
}

void FBSAEditor::CreatePreviewScene()
{
	if (!PreviewScene.IsValid())
	{
		const UBSAEditorSettings* EditorSetting = GetDefault<UBSAEditorSettings>();

		FPreviewScene::ConstructionValues CVS;
		CVS.bAllowAudioPlayback = true;
		CVS.bShouldSimulatePhysics = true;
		CVS.bEditor = true;
		if (EditorSetting && EditorSetting->GameModeClass.Get())
		{
			CVS.DefaultGameMode = EditorSetting->GameModeClass.Get();
		}
		else
		{
			CVS.DefaultGameMode = ABSAPreviewGameMode::StaticClass();
		}

		PreviewScene = MakeShareable(new FBSAEditorPreviewScene(CVS, SharedThis(this)));
		UWorld* PreviewWorld = PreviewScene->GetWorld();

		// 对世界重命名
		FString PreviewWorldName = TEXT("BSAEditorWorld") + FString::FromInt(FBSAEditor::BSAEditorIndex);
		PreviewWorld->Rename(*PreviewWorldName, PreviewWorld->GetOuter());

		// 创建Lua环境
        LuaEnv = UEditorLuaEnv::CreateLuaEnv(PreviewScene->GetWorld(), UBSEditorLuaGI::StaticClass());
	}
}

void FBSAEditor::CreatePreviewProxy()
{
	PreviewProxy = MakeShareable(new FBSAPreviewProxy(EditAsset.Get(), SharedThis(this)));
}

void FBSAEditor::InitPreviewContext()
{
	check(PreviewScene.IsValid());

	PreviewScene->InitPreviewWorld();

	CreatePreviewProxy();
}

void FBSAEditor::ResetPreviewContext()
{
	check(PreviewScene.IsValid());

	PreviewProxy->ResetWorld();

	PreviewScene->ResetPreviewWorld();

	// 刷新碰撞
	UpdateHitBox();
}

#pragma endregion Preview



#pragma region AbilityLogic
UBSManager* FBSAEditor::GetBSManager()
{ 
	if (!CachedBSManager.IsValid())
	{
		CachedBSManager = UBSManager::GetInstance(GetPreviewScene()->GetWorld());
	}

	return CachedBSManager.Get();
}

void FBSAEditor::CollectAllTaskClass()
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	TArray<FAssetData> BlueprintList;
	FARFilter Filter;
	Filter.PackagePaths.Add("/Game");
	Filter.ClassPaths.Add(UUserDefinedEnum::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	AssetRegistryModule.Get().GetAssets(Filter, BlueprintList);
	for (FAssetData SingleAsset : BlueprintList)
	{
		UUserDefinedEnum* CurEnum = LoadObject<UUserDefinedEnum>(nullptr, *SingleAsset.GetSoftObjectPath().ToString());
		if (CurEnum)
		{
			EnumList.AddUnique(TStrongObjectPtr<UUserDefinedEnum>(CurEnum));
		}
	}

	// 筛选出Task蓝图资源
	auto CheckClass = [&](FAssetData& AssetMsg)
	{
		if (!AssetMsg.AssetName.ToString().Contains(TEXT("BPT_")))
			return;

		FString ClassPath = AssetMsg.GetSoftObjectPath().ToString();
		UBlueprint* CurBP = LoadObject<UBlueprint>(NULL, *ClassPath);
		UClass* CurClass = CurBP->GeneratedClass;

		if (!CurClass)
			return;

		if (UBSATask* Task = Cast<UBSATask>(CurClass->GetDefaultObject()))
		{
			TaskClassList.AddUnique(Task->GetClass());
			return;
		}
		return;
	};

	BlueprintList.Empty();
	Filter.ClassPaths.Empty();
	Filter.PackagePaths.Empty();
	Filter.ClassPaths.AddUnique(UBlueprint::StaticClass()->GetClassPathName());
	Filter.ClassPaths.AddUnique(UBlueprintGeneratedClass::StaticClass()->GetClassPathName());

	Filter.bRecursiveClasses = true;
	AssetRegistryModule.Get().GetAssets(Filter, BlueprintList);
	for (int32 i = 0; i < BlueprintList.Num(); ++i)
	{
		CheckClass(BlueprintList[i]);
	}
}

TArray<UBSATask*> FBSAEditor::GetTaskSelection()
{
	TArray<UBSATask*> Result;
	for (int32 i = 0; i < TaskSelection.TaskList.Num(); ++i)
	{
		Result.Add(TaskSelection.TaskList[i].Get());
	}

	return Result;
}

void FBSAEditor::SetTaskSelection(TArray<UBSATask*> InSelection, bool bIsOverride)
{
	if (IsPlaying() && !InSelection.IsEmpty())
	{
		return;
	}

	if (EditAsset.IsValid())
	{
		if (bIsOverride)
		{
			TaskSelection.TaskList.Empty();
		}

		if (InSelection.Num() > 0)
		{
			if (TaskSelection.TaskList.Num() > 0)
			{
				EditAsset->GetSectionIDAndGroupID(*(TaskSelection.TaskList[0]), TaskSelection.SectionID, TaskSelection.GroupID);
			}
			else
			{
				EditAsset->GetSectionIDAndGroupID(*(InSelection[0]), TaskSelection.SectionID, TaskSelection.GroupID);
			}

			for (int32 i = 0; i < InSelection.Num(); ++i)
			{
				int32 CurSectionID = -1;
				int32 CurGroupID = -1;
				EditAsset->GetSectionIDAndGroupID(*(InSelection[i]), CurSectionID, CurGroupID);

				if (CurSectionID == TaskSelection.SectionID && CurGroupID == TaskSelection.GroupID)
				{
					TaskSelection.TaskList.AddUnique(InSelection[i]);
				}
			}
		}
	}
	else
	{
		TaskSelection.TaskList.Empty();
	}


	TArray<UBSATask*> CurTaskList = GetTaskSelection();
	if (CurTaskList.Num() > 0)
	{
		ShowObjectDetail(CurTaskList[0]);
	}
	else
	{
		ShowObjectDetail(nullptr);
	}


	// 广播事件
	FBSAEditorDelegates::TaskSelectionChangedEvent.Broadcast(CurTaskList);
}

#pragma endregion AbilityLogic



#pragma region LogicGraph
void FBSAEditor::SetLogicGraphEditor(const TSharedPtr<SGraphEditor>& InGraphEditor)
{
	LogicGraphEditor = InGraphEditor;
}

void FBSAEditor::OnSelectedNodesChanged(const TSet<UObject*>& NewSelection)
{
	SelectedGraphNodes.Empty();
	ShowGraphObjectDetail(NULL);
	for (UObject* SelectionEntry : NewSelection)
	{
		SelectedGraphNodes.Add(SelectionEntry);
		ShowGraphObjectDetail(SelectionEntry);
	}
}

void FBSAEditor::DeleteSelectedNodes()
{
	TArray<TWeakObjectPtr<UObject>> CurNodes;
	CurNodes.Append(SelectedGraphNodes);

	if (LogicGraphEditor.IsValid())
	{
		LogicGraphEditor->GetCurrentGraph()->Modify();
		LogicGraphEditor->ClearSelectionSet();
	}

	for (TArray<TWeakObjectPtr<UObject>>::TIterator It(CurNodes); It; ++It)
	{
		if (UEdGraphNode* EdNode = Cast<UEdGraphNode>(*It))
		{
			EdNode->Modify();

			if (const UEdGraphSchema* Schema = EdNode->GetSchema())
			{
				Schema->BreakNodeLinks(*EdNode);
			}

			EdNode->DestroyNode();
		}
	}

	// 刷新一遍逻辑图表
	if (UBSALogicGraph* LogicGraph = Cast<UBSALogicGraph>(EditAsset->LogicGraph))
	{
		LogicGraph->RefreshLogicGraph();
	}
}

void FBSAEditor::GenerateTaskGraphNode(UBSATask* InTask, int32 PosX, int32 PosY)
{
	if (UBSALogicGraph* LogicGraph = Cast<UBSALogicGraph>(EditAsset->LogicGraph))
	{
		if (InTask)
		{
			LogicGraph->Modify();

			if (UBSALogicGraphNode* ResultNode = NewObject<UBSALogicGraphNode>(LogicGraph))
			{
				LogicGraph->AddNode(ResultNode, true, true);

				ResultNode->CachedTask = InTask;

				ResultNode->CreateNewGuid();
				ResultNode->PostPlacedNewNode();
				ResultNode->AllocateDefaultPins();
				ResultNode->UpdatePins();

				ResultNode->NodePosX = PosX;
				ResultNode->NodePosY = PosY;

				ResultNode->SetFlags(RF_Transactional);
			}
		}
	}
}

void FBSAEditor::GenerateGraphNodesByTaskList(TArray<class UBSATask*> InTaskList)
{
	if (InTaskList.Num() <= 0)
		return;

	if (UBSALogicGraph* LogicGraph = Cast<UBSALogicGraph>(EditAsset->LogicGraph))
	{
		int32 NodeY = 0;
		for (int32 i = 0; i < LogicGraph->Nodes.Num(); ++i)
		{
			if (NodeY < LogicGraph->Nodes[i]->NodePosY)
			{
				NodeY = LogicGraph->Nodes[i]->NodePosY;
			}
		}

		NodeY += 400;
		int32 NodeX = 0;
		for (int32 i = 0; i < InTaskList.Num(); ++i)
		{
			if (!InTaskList[i])
				continue;

			bool bGenerateNode = false;

			// 判断有没有必要创建逻辑节点
			TArray<FBSATaskInputInfo> OutCols;
			InTaskList[i]->GetCollisionTargetInfos(OutCols);
			for (int32 j = 0; j < OutCols.Num(); ++j)
			{
				if (OutCols[j].ProduceDataTask.SelectedTask != nullptr)
				{
					bGenerateNode = true;
					break;
				}
			}

			if (!bGenerateNode)
			{
				for (int32 j = 0; j < InTaskList[i]->InputDatas.Num(); ++j)
				{
					if (InTaskList[i]->InputDatas[j].ProduceDataTask.SelectedTask != nullptr)
					{
						bGenerateNode = true;
						break;
					}
				}
			}

			if (!bGenerateNode)
			{
				// 自身有连接到外部的节点，需要生成自身节点
				for (TMap<FName, FBSATaskSelectorList>::TIterator It(InTaskList[i]->EventTaskMap); It; ++It)
				{
					if (It->Value.SelectedTaskList.Num() > 0)
					{
						bGenerateNode = true;
						break;
					}
				}

				// 有其他节点连接到自身，也需要生成自身节点
				for (int32 k = 0; k < InTaskList.Num(); ++k)
				{
					for (TMap<FName, FBSATaskSelectorList>::TIterator It(InTaskList[k]->EventTaskMap); It; ++It)
					{
						for (int32 l = 0; l < It->Value.SelectedTaskList.Num(); l++)
						{
							if (It->Value.SelectedTaskList[l].SelectedTask == InTaskList[i])
							{
								bGenerateNode = true;
								break;
							}
						}
						if (bGenerateNode)
						{
							break;
						}
					}
					if (bGenerateNode)
					{
						break;
					}
				}
			}

			if (!bGenerateNode)
				continue;

			GenerateTaskGraphNode(InTaskList[i], NodeX, NodeY);
			NodeX += 400;
		}
	}
}

#pragma endregion LogicGraph



#undef LOCTEXT_NAMESPACE

