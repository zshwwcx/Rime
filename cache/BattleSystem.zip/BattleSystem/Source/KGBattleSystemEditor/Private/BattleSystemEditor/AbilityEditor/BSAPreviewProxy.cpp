#include "BattleSystemEditor/AbilityEditor/BSAPreviewProxy.h"

#include "Misc/FileHelper.h"
#include "Misc/MessageDialog.h"
#include "HAL/PlatformFilemanager.h"
#include "PlatformFeatures.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/BSEditorLuaGI.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorDelegates.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorPreviewScene.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystem/BSManager.h"
#include "BattleSystem/BSSettings.h"
#include "BattleSystem/BSFunctionLibrary.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSABuffAsset.h"

#include "BattleSystem/Ability/Task/BSATaskInstanceV2.h"
#include "BattleSystem/Ability/Buff/BSABuffInstanceV2.h"
#include "BattleSystem/Ability/Skill/BSASkillInstanceV2.h"



#pragma region Important
FBSAPreviewProxy::FBSAPreviewProxy(UBSAAsset* InAsset, const TSharedPtr<FBSAEditor>& InEditor) : CachedAsset(InAsset), CachedEditor(InEditor)
{
	FBSAEditorDelegates::TaskSelectionChangedEvent.AddRaw(this, &FBSAPreviewProxy::OnTaskSelectionChanged);
	FBSAEditorDelegates::StartPlayEvent.AddRaw(this, &FBSAPreviewProxy::OnAnyBSEditorStartPlay);
	FBSAEditorDelegates::SetShowCollisionEvent.AddRaw(this, &FBSAPreviewProxy::OnSetShowCollision);
}

FBSAPreviewProxy::~FBSAPreviewProxy()
{

}

void FBSAPreviewProxy::Tick(float DeltaTime)
{
	// 记录顿帧情况
	if (UBSAInstanceV2* Instance = PlayingInstanceV2.Get())
	{
		if (!FMath::IsNearlyEqual(Instance->GetTickRate(), 1.0f))
		{
			int64 ID = 0; 
			int32 SectionIndex = 0;
			float RunningTime = 0.0;
			int32 LoopTime = 1;
			int32 StartKeyIndex = 1;
			Instance->GetSI(1, ID, SectionIndex, RunningTime, LoopTime, StartKeyIndex);

			int64 TS = ULowLevelFunctions::GetUtcMillisecond();

			if (SlomoInformations.Num() <= 0)
			{
				SlomoInformations.Add(FInt64Vector(FMath::RoundToInt(RunningTime * 1000), TS, TS));
			}
			else
			{
				if (Instance->GetTickRate() < 0.9999f)
				{
					SlomoInformations[SlomoInformations.Num() - 1].Z = TS;
				}
				else
				{
					SlomoInformations.Add(FInt64Vector(FMath::RoundToInt(RunningTime * 1000), TS, TS));
				}
			}
		}
	}
}

void FBSAPreviewProxy::Finish()
{
	GEditor->SelectNone(false, true, false);

	FBSAEditorDelegates::TaskSelectionChangedEvent.RemoveAll(this);
	FBSAEditorDelegates::StartPlayEvent.RemoveAll(this);
	FBSAEditorDelegates::SetShowCollisionEvent.RemoveAll(this);
}

float FBSAPreviewProxy::GetCurrentTime(int32 SectionID)
{
	if (PlayingInstanceV2.IsValid())
	{
		TArray<int32> SectionIDs;
		TArray<float> SectionTimes;

		PlayingInstanceV2->GetSectionRunningMessages(SectionIDs, SectionTimes);

		int32 CurID = SectionIDs.Find(SectionID);

		return CurID >= 0 ? SectionTimes[CurID] : 0.0f;
	}

	return 0.0f;
}

void FBSAPreviewProxy::OnPreviewEnd()
{
	GEditor->SelectNone(false, false);

	bPlaying = false;
	bPause = false;
	bSrubing = false;

	PlayingInstanceV2 = nullptr;

	RecordEndTimer = 1.0;

	FBSAEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);

	if (SlomoInformations.Num() > 1)
	{
		FString WarningText = TEXT("运行过程中发现多次时间减缓，分别在：\n");
		for (int32 i = 0; i < SlomoInformations.Num(); ++i)
		{
			WarningText = WarningText + TEXT("    开始时间:");
			WarningText = WarningText + FString::Printf(TEXT("%f"), SlomoInformations[i].X * 0.001);
			WarningText = WarningText + TEXT(" 持续时间:");
			WarningText = WarningText + FString::Printf(TEXT("%f"), (SlomoInformations[i].Z - SlomoInformations[i].Y) * 0.001);
			WarningText = WarningText + TEXT(" \n");
		}
		WarningText = WarningText + TEXT("请注意，过度时间减缓会导致客户端与服务器出现不同步情况，谨慎使用“命中顿帧”等功能！！");

		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(WarningText));
	}
}

#pragma endregion Important



#pragma region Preview
UBSAAsset* FBSAPreviewProxy::GetPreviewAsset() const
{ 
	return CachedAsset.Get(); 
}

UBSAInstanceV2* FBSAPreviewProxy::GetPlayingInstanceV2() const
{
	return PlayingInstanceV2.Get();
}

void FBSAPreviewProxy::Play()
{
	GEditor->SelectNone(false, true, false);

	const UBSSettings* Setting = GetDefault<UBSSettings>();
	if (!Setting)
		return;

	// 初始化
	InitPlay();

	// 如果是技能
	if (CachedAsset->IsA<UBSASkillAsset>())
	{
		if (AActor* ThePlayer = CachedEditor.Pin()->GetPreviewScene()->GetPlayerActor())
		{
			UWorld* World = ThePlayer->GetWorld();
            if (UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(UEditorLuaEnv::GetLuaGameInstance(World)))
			{
				USceneComponent* TargetComp = UBSFunctionLibrary::V2GetNearestLockComponent_P(CachedEditor.Pin()->GetPreviewScene()->GetPlayerActor(), CachedEditor.Pin()->GetPreviewScene()->GetTargetActor());
				
				int64 GID = GI->PreviewSkill(ThePlayer, CachedAsset->ID, TArray<USceneComponent*>{ TargetComp });
				// PlayingInstanceV2 = Cast<UBSAInstanceV2>(UOM->GetUObjectByGlobalID(GID));
			}
		}
	}
	// 如果是BUFF
	else if (CachedAsset->IsA<UBSABuffAsset>())
	{
		if (AActor* ThePlayer = CachedEditor.Pin()->GetPreviewScene()->GetPlayerActor())
		{
			UWorld* World = ThePlayer->GetWorld();
            if (UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(UEditorLuaEnv::GetLuaGameInstance(World)))
			{
				USceneComponent* TargetComp = UBSFunctionLibrary::V2GetNearestLockComponent_P(CachedEditor.Pin()->GetPreviewScene()->GetPlayerActor(), CachedEditor.Pin()->GetPreviewScene()->GetTargetActor());
				
				int64 GID = GI->PreviewBuff(ThePlayer, CachedAsset->ID, TArray<USceneComponent*>{ TargetComp });
				// PlayingInstanceV2 = Cast<UBSAInstanceV2>(UOM->GetUObjectByGlobalID(GID));
			}
		}
	}

	if (PlayingInstanceV2.IsValid())
	{
		PlayingInstanceV2->GetInstanceEndEvent().AddRaw(this, &FBSAPreviewProxy::OnPreviewEnd);

		// 通知编辑器清除Task选取信息
		if (CachedEditor.IsValid())
		{
			CachedEditor.Pin()->SetTaskSelection(TArray<UBSATask*>{});
		}

		bPlaying = true;
		bPause = false;
		bSrubing = false;

		FBSAEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);
	}
}

bool FBSAPreviewProxy::IsPlaying() const
{
	return bPlaying && !bPause && !bSrubing;
}

void FBSAPreviewProxy::Pause()
{
	bPause = true;

	FBSAEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);
}

bool FBSAPreviewProxy::IsPaused() const
{
	return (bPlaying && bPause) || bSrubing;
}

void FBSAPreviewProxy::Resume()
{
	GEditor->SelectNone(false, true, false);

	// 通知编辑器清除Task选取信息
	if (CachedEditor.IsValid())
	{
		CachedEditor.Pin()->SetTaskSelection(TArray<UBSATask*>{});
	}

	bPause = false;
	bSrubing = false;

	FBSAEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);
}

void FBSAPreviewProxy::Stop()
{
	GEditor->SelectNone(false, true, false);

	bPlaying = false;
	bPause = false;
	bSrubing = false;

	FBSAEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);

	if (!PlayingInstanceV2.IsValid())
		return;

	const UBSSettings* Setting = GetDefault<UBSSettings>();
	if (!Setting)
		return;

	// 如果是技能
	if (CachedAsset->IsA<UBSASkillAsset>())
	{
		if (AActor* ThePlayer = CachedEditor.Pin()->GetPreviewScene()->GetPlayerActor())
		{
			UWorld* World = ThePlayer->GetWorld();
            if (UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(UEditorLuaEnv::GetLuaGameInstance(World)))
			{
				GI->StopPreviewSkill(ThePlayer, PlayingInstanceV2->GetGID());
				
			}
		}
	}
	// 如果是BUFF
	if (CachedAsset->IsA<UBSABuffAsset>())
	{
		if (AActor* ThePlayer = CachedEditor.Pin()->GetPreviewScene()->GetPlayerActor())
		{
			UWorld* World = ThePlayer->GetWorld();
            if (UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(UEditorLuaEnv::GetLuaGameInstance(World)))
			{
				GI->StopPreviewBuff(ThePlayer, PlayingInstanceV2->GetGID());
			}
		}
	}
}

bool FBSAPreviewProxy::IsStopped() const
{
	return !bPlaying;
}

void FBSAPreviewProxy::ResetWorld()
{
	Stop();
}

void FBSAPreviewProxy::OnObjectMoved(UObject* InObject)
{
	const UBSSettings* Setting = GetDefault<UBSSettings>();
	if (!Setting)
		return;

	if (PlayingInstanceV2.IsValid())
	{
		int32 TaskID = PlayingInstanceV2->GetTaskByDynamicObject(InObject);
		if (TaskID > 0)
		{
			int32 SectionID = TaskID / 1000 - 1;
			int32 TaskIndex = TaskID % 1000 - 1;

			UBSATask* Task = nullptr;
			if (CachedAsset.IsValid())
			{
				if (FBSATaskSection* Section = CachedAsset->GetSectionPointerByIndex(SectionID))
				{
					if (Section->TaskList.IsValidIndex(TaskIndex))
					{
						Task = Section->TaskList[TaskIndex];
					}
				}
			}

			if (Task)
			{
				// 刷新Task数据
				if (FBSADynamicObjectInfo* Info = PlayingInstanceV2->GetDynamicObjectInfo(InObject))
				{
					Task->UpdateDataByDynamicActorInfo(*Info);
				}

				// 刷新动态对象数据
				if (FBSADynamicObjectInfoArray* Array = PlayingInstanceV2->GetDynamicObjectInfoArray(TaskID))
				{
					Task->UpdateDynamicActorByData(*Array);
				}
			}

			if (CachedAsset.IsValid())
			{
				CachedAsset->MarkPackageDirty();
			}
		}
	}
}

void FBSAPreviewProxy::TimeLineClick(float PreTime, float ClickTime)
{
	const UBSSettings* Setting = GetDefault<UBSSettings>();

	if (!Setting)
		return;
	
	// 如果是技能
	if (CachedAsset->IsA<UBSASkillAsset>())
	{
		if (AActor* ThePlayer = CachedEditor.Pin()->GetPreviewScene()->GetPlayerActor())
		{
			UWorld* World = ThePlayer->GetWorld();
            if (UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(UEditorLuaEnv::GetLuaGameInstance(World)))
			{
				GI->PlayAnimationAndNiagaraInSection(ThePlayer, CachedAsset->ID, PreTime, ClickTime);
			}
		}
	}

	if (PlayingInstanceV2.IsValid())
	{
		PlayingInstanceV2->GetInstanceEndEvent().AddRaw(this, &FBSAPreviewProxy::OnPreviewEnd);
	
		// 通知编辑器清除Task选取信息
		if (CachedEditor.IsValid())
		{
			CachedEditor.Pin()->SetTaskSelection(TArray<UBSATask*>{});
		}
	
		bPlaying = true;
		bPause = false;
		bSrubing = true;
	
		FBSAEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);
	}
}

void FBSAPreviewProxy::InitPlay()
{
	SlomoInformations.Empty();

	// 数据发生修改，需要重新导出临时文件
	if (CachedEditor.IsValid() && CachedAsset->GetPackage() && CachedAsset->GetPackage()->IsDirty())
	{
		// 导出数据到临时文件中
		CachedEditor.Pin()->ExportAbilityToTemporaryFile();
	}

	FBSAEditorDelegates::StartPlayEvent.Broadcast(CachedEditor.Pin()->GetPreviewScene()->GetWorld());
}

#pragma endregion Preview



#pragma region Event
void FBSAPreviewProxy::OnTaskSelectionChanged(TArray<UBSATask*> SelectTaskList)
{
	const UBSSettings* Setting = GetDefault<UBSSettings>();
	if (!Setting)
	{
		return;
	}

	if (PlayingInstanceV2.IsValid() && SelectTaskList.Num() > 0 && CachedAsset.IsValid())
	{
		int32 SectionID, GroupID;
		CachedAsset->GetSectionIDAndGroupID(*SelectTaskList[0], SectionID, GroupID);

		if (FBSATaskSection* SectionPtr = CachedAsset->GetSectionPointerByIndex(SectionID))
		{
			int32 TaskIndex = SectionPtr->TaskList.Find(SelectTaskList[0]);
			if (TaskIndex < 0)
			{
				return;
			}

			int32 TaskID = (SectionID + 1) * 1000 + TaskIndex + 1;
			if (FBSADynamicObjectInfoArray* InfoArray = PlayingInstanceV2->GetDynamicObjectInfoArray(TaskID))
			{
				FBSADynamicObjectInfo& CurInfo = InfoArray->Informations[0];

				GEditor->SelectNone(false, true, false);
				if (AActor* DActor = Cast<AActor>(CurInfo.DynamicObject))
				{
					GEditor->SelectActor(DActor, true, true, true);
				}
				else if (USceneComponent* DComponent = Cast<USceneComponent>(CurInfo.DynamicObject))
				{
					GEditor->SelectComponent(DComponent, true, true, true);
				}
			}
		}
	}
	else
	{
		GEditor->SelectNone(false, true, false);
	}
}

void FBSAPreviewProxy::OnAnyBSEditorStartPlay(UWorld* PlayingWorld)
{
	if (CachedEditor.Pin()->GetPreviewScene()->GetWorld() != PlayingWorld)
	{
		CachedEditor.Pin()->OnAnyBSEditorStartPlay();
	}
}

void FBSAPreviewProxy::OnSetShowCollision(bool bShowCollision)
{
	CachedEditor.Pin()->bShowCollision = bShowCollision;
	CachedEditor.Pin()->UpdateHitBox();
}

#pragma endregion Event
