#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSAExtraTrackPanel.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineController.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSAExtraTrackTimeline.h"



#define LOCTEXT_NAMESPACE "FBSASkillTrackPanel"



ANIMTIMELINE_IMPLEMENT_TRACK(FBSAExtraTrackPanel);



float FBSAExtraTrackPanel::NotificationTrackHeight = 18.0f;

FBSAExtraTrackPanel::FBSAExtraTrackPanel(const TSharedRef<FBSATimelineController>& InModel, UBSAAsset* InAsset, int32 InTrackType, const FText& InDisplayName, const FText& InToolTipText) : FAnimTimelineTrack(InModel, InDisplayName, InToolTipText), CachedAsset(InAsset), TrackType(InTrackType)
{
	SetHeight(NotificationTrackHeight);
}

void FBSAExtraTrackPanel::UpdateLayout()
{
	SetHeight(NotificationTrackHeight);

	if (TrackWidget.IsValid())
	{
		TrackWidget->UpdateLayout();
	}
}

TSharedRef<SWidget> FBSAExtraTrackPanel::GenerateContainerWidgetForTimeline()
{
	if (!TrackWidget.IsValid())
	{
		TrackWidget = SNew(SBSAExtraTrackTimeline)
			.Asset(CachedAsset.Get())
			.TrackType(TrackType)
			.InputMin(this, &FBSAExtraTrackPanel::GetMinInput)
			.InputMax(this, &FBSAExtraTrackPanel::GetMaxInput)
			.ViewInputMin(this, &FBSAExtraTrackPanel::GetViewMinInput)
			.ViewInputMax(this, &FBSAExtraTrackPanel::GetViewMaxInput)
			.TimelinePlayLength(GetEditorTimelineController()->GetPlayLength())
			.FrameRate(GetEditorTimelineController()->GetFrameRate())
			.OnSetInputViewRange(this, &FBSAExtraTrackPanel::InputViewRangeChanged)
			.OnRefreshPanel(this, &FBSAExtraTrackPanel::UpdateLayout);
	}

	return TrackWidget.ToSharedRef();
}

void FBSAExtraTrackPanel::InputViewRangeChanged(float ViewMin, float ViewMax)
{

}

#undef LOCTEXT_NAMESPACE