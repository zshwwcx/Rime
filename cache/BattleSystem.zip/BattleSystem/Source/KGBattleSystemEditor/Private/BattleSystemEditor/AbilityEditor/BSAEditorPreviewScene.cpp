#include "BattleSystemEditor/AbilityEditor/BSAEditorPreviewScene.h"
#include "RHI.h"
#include "RHIDefinitions.h"
#include "EngineUtils.h"
#include "EngineSettings.h"
#include "Engine/Selection.h"

#include "EditorLevelUtils.h"
#include "Slate/SceneViewport.h"
#include "Camera/CameraComponent.h"
#include "Engine/LevelStreamingDynamic.h"
#include "GameFramework/GameStateBase.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/MovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Components/StaticMeshComponent.h"

#include "AkAudio/Classes/AkComponent.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/BSEditorLuaGI.h"
#include "BattleSystemEditor/AbilityEditor/BSAPreviewProxy.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorDelegates.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/SBSAEditorViewport.h"
#include "BattleSystem/BSManager.h"
#include "BattleSystem/BSFunctionLibrary.h"



#pragma region Important
FBSAEditorPreviewScene::FBSAEditorPreviewScene(ConstructionValues CVS, TSharedPtr<FBSAEditor> InEditor) : FAdvancedPreviewScene(CVS), CachedEditor(InEditor)
{
	
}

FBSAEditorPreviewScene::~FBSAEditorPreviewScene()
{

}

void FBSAEditorPreviewScene::OnCreateViewport(SBSAEditorViewport* InEditorViewport, TSharedPtr<FSceneViewport> InSceneViewport)
{
	const UBSAEditorSettings* EditorSettings = GetDefault<UBSAEditorSettings>();
	if (!EditorSettings->DefaultViewMap.IsNull())
	{
		ExternalLevel = LoadExternalMap(EditorSettings->DefaultViewMap);
	}

	if (UStaticMesh* FloorMesh = LoadObject<UStaticMesh>(NULL, TEXT("/Engine/EditorMeshes/AssetViewer/Floor_Mesh.Floor_Mesh"), NULL, LOAD_None, NULL))
	{
		FloorOwner = GetWorld()->SpawnActor<AActor>(AActor::StaticClass(), FTransform::Identity);
		FloorOwner->SetActorLocation(FVector(0.0f, 0.0f, -110.0f));
		UStaticMeshComponent* NewFloor = NewObject<UStaticMeshComponent>(FloorOwner.Get());
		FloorOwner->SetRootComponent(NewFloor);
		FloorOwner->AttachToActor(FloorOwner.Get(), FAttachmentTransformRules::KeepWorldTransform);

		NewFloor->RegisterComponent();
		NewFloor->SetStaticMesh(FloorMesh);
		NewFloor->SetCollisionProfileName("BlockAll");
		NewFloor->AttachToComponent(FloorOwner->GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
		NewFloor->SetRelativeLocation(FVector::ZeroVector);
		NewFloor->SetRelativeScale3D(FVector(10.0f, 10.0f, 1.0f));
		NewFloor->bReceivesDecals = true;

		FloorMeshComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	}

	// 注册关心的事件
	GEngine->OnActorMoved().AddRaw(this, &FBSAEditorPreviewScene::OnActorMoved);
	GEngine->OnComponentTransformChanged().AddRaw(this, &FBSAEditorPreviewScene::OnComponentMoved);
}

void FBSAEditorPreviewScene::Tick(float DeltaTime)
{
	FAdvancedPreviewScene::Tick(DeltaTime);

	TSharedPtr<SBSAEditorViewport> ViewportWidget = CachedEditor.Pin()->GetViewportWidget();
	TSharedPtr<FEditorViewportClient> ViewportClient = ViewportWidget.IsValid() ? ViewportWidget->GetViewportClient() : nullptr;
	if (ViewportClient)
	{
		GEditor->RedrawAllViewports();
	}
}

void FBSAEditorPreviewScene::Finish()
{
	if (GetWorld())
	{
		DestroyPreviewActors();

		if (PlayerController.IsValid())
		{
			PlayerController->RemoveFromRoot();
			GetWorld()->EditorDestroyActor(PlayerController.Get(), false);
		}

		if (GetWorld()->GetGameState())
		{
			GetWorld()->GetGameState()->RouteEndPlay(EEndPlayReason::Destroyed);
		}
	}

	// 注销关心的事件
	GEngine->OnActorMoved().RemoveAll(this);
	GEngine->OnComponentTransformChanged().RemoveAll(this);
}

void FBSAEditorPreviewScene::AddReferencedObjects(FReferenceCollector& Collector)
{
	FPreviewScene::AddReferencedObjects(Collector);

	if (CachedEditor.IsValid())
	{
		CachedEditor.Pin()->AddReferencedObjects(Collector);
	}
}

#pragma endregion Important



#pragma region Preview
void FBSAEditorPreviewScene::InitPreviewWorld()
{
	UWorld* World = GetWorld();


	World->GetWorldSettings()->SetIsTemporarilyHiddenInEditor(false);
	World->GetWorldSettings()->NotifyBeginPlay();


	// 创建PlayerController并设置摄像机
	PlayerController = World->SpawnActorDeferred<APlayerController>(APlayerController::StaticClass(), FTransform::Identity);
	if (PlayerController.IsValid())
	{
		PlayerController->bAutoManageActiveCameraTarget = true;
		PlayerController->FinishSpawning(FTransform::Identity);
		PlayerController->AddToRoot();

		// 初始化镜头
		PlayerController->PlayerCameraManager->DispatchBeginPlay();
		PlayerController->PlayerCameraManager->bDebugClientSideCamera = true;
	}


	// 自动重置世界
	ResetPreviewWorld();
}

void FBSAEditorPreviewScene::ResetPreviewWorld()
{
	UWorld* World = GetWorld();

	DestroyPreviewActors();

	// 手动销毁所有的摄像机对象
	for (TActorIterator<ACameraActor> It(GetWorld()); It; ++It)
	{
		It->Destroy();
	}

	SpawnPreviewActors();
}

void FBSAEditorPreviewScene::SpawnPreviewActors()
{
	if (UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		UWorld* World = GetWorld();

		if (Asset->PreviewPlayerInfo)
		{
			PreviewPlayer = Asset->PreviewPlayerInfo->CreateActor(World);
			PreviewActors.Add(PreviewPlayer);
		}

		if (Asset->PreviewTargetInfo)
		{
			PreviewTarget = Asset->PreviewTargetInfo->CreateActor(World);
			PreviewActors.Add(PreviewTarget);
		}

		if (Asset->PreviewWaterFieldInfo && Asset->bOpenWaterField)
		{
			PreviewWaterField = Asset->PreviewWaterFieldInfo->CreateActor(World);
			PreviewActors.Add(PreviewWaterField);
		}

		if (Asset->PreviewGrassFieldInfo && Asset->bOpenWindField)
		{
			PreviewGrassField = Asset->PreviewGrassFieldInfo->CreateActor(World);
			PreviewActors.Add(PreviewGrassField);
		}

		// 手动调用新对象的BeginPlay
        UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(UEditorLuaEnv::GetLuaGameInstance(World));
		for (int32 i = 0; i < PreviewActors.Num(); ++i)
		{
			if (PreviewActors[i].IsValid())
			{
				PreviewActors[i]->AddToRoot();
				PreviewActors[i]->DispatchBeginPlay();

				// 手动设置移动组件的一些信息
				if (UMovementComponent* MoveComp = PreviewActors[i]->FindComponentByClass<UMovementComponent>())
				{
					MoveComp->SetUpdatedComponent(PreviewActors[i]->GetRootComponent());
				}

				if (GI)
				{
					if (PreviewActors[i] == PreviewPlayer)
					{
						GI->OnPreviewActorSpawned(PreviewActors[i].Get(), Asset->PreviewPlayerInfo);
					}
					else if (PreviewActors[i] == PreviewTarget)
					{
						GI->OnPreviewActorSpawned(PreviewActors[i].Get(), Asset->PreviewTargetInfo);
					}
					else if (PreviewActors[i] == PreviewWaterField)
					{
						if(Asset->bOpenWaterField)
						{
							GI->OnPreviewEnvironmentActorSpawned(PreviewActors[i].Get(), Asset->PreviewWaterFieldInfo);
						}
					}
					else if (PreviewActors[i] == PreviewGrassField)
					{
						if(Asset->bOpenWindField)
						{
							GI->OnPreviewEnvironmentActorSpawned(PreviewActors[i].Get(), Asset->PreviewGrassFieldInfo);
						}
					}
					else
					{
						GI->OnPreviewActorSpawned(PreviewActors[i].Get(), nullptr);
					}
				}

				if (APawn* Pawn = Cast<APawn>(PreviewActors[i]))
				{
					if (Pawn == PreviewPlayer)
					{
						if (PlayerController.IsValid())
						{
							USpringArmComponent* Arm = NewObject<USpringArmComponent>(Pawn);
							Arm->TargetArmLength = 600.0f;
							Arm->SocketOffset.Y = 400.0f;
							Arm->SocketOffset.Z = 200.0f;
							Arm->AttachToComponent(Pawn->GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
							Arm->ResetRelativeTransform();
							Arm->RegisterComponent();

							UCameraComponent* Camera = NewObject<UCameraComponent>(Pawn);
							Camera->AttachToComponent(Arm, FAttachmentTransformRules::KeepRelativeTransform);
							Camera->ResetRelativeTransform();
							Camera->SetRelativeRotation(FRotator(-15.0f, -30.0f, 0.0f));
							Camera->RegisterComponent();

							PlayerController->Possess(Pawn);
						}

						// 手动设置目标
						if (GI)
						{
							GI->PlayerLockTarget(PreviewPlayer.Get(), PreviewTarget.Get());
						}
					}
					else
					{
						Pawn->SpawnDefaultController();
					}
				}
			}
		}
	}


	// 清理无效摄像机
	for (TActorIterator<ACameraActor> It(GetWorld()); It; ++It)
	{
		It->Destroy();
	}


	// 调整AkComponent数量
	for (TObjectIterator<UAkComponent> It; It; ++It)
	{
		if (IsValid(*It) && IsValid(It->GetOwner()) && It->GetOwner()->GetWorld() == GetWorld())
		{
			if (It->GetOwner() != PreviewPlayer && It->GetOwner() != PreviewTarget)
			{
				It->DestroyComponent(true);
			}
		}
	}
}

void FBSAEditorPreviewScene::DestroyPreviewActors()
{
	GEditor->SelectNone(false, false);

	if (PlayerController.IsValid())
	{
		PlayerController->UnPossess();
	}

	UWorld* World = GetWorld();

	UBSEditorLuaGI *GI = Cast<UBSEditorLuaGI>(UEditorLuaEnv::GetLuaGameInstance(World));
	
	if (UBSManager* BSMgr = UBSManager::GetInstance(World))
	{
		BSMgr->CleanupManager();
	}

	for (TWeakObjectPtr<AActor> ActorPtr : PreviewActors)
	{
		if (GI)
		{
			GI->OnWillDestroyPreviewActor(ActorPtr.Get());
		}

		if (ActorPtr.IsValid())
		{
			// 删除子对象
			for (int32 i = ActorPtr->Children.Num() - 1; i >= 0; --i)
			{
				if (AActor* Child = ActorPtr->Children[i].Get())
				{
					Child->RemoveFromRoot();
					World->EditorDestroyActor(Child, false);
				}
			}

			ActorPtr->RemoveFromRoot();

			if (APawn* Pawn = Cast<APawn>(ActorPtr))
			{
				if (AController* Controller = Pawn->GetController())
				{
					Controller->UnPossess();
					World->EditorDestroyActor(Controller, false);
				}
			}

			World->EditorDestroyActor(ActorPtr.Get(), false);
		}
	}
	PreviewActors.Empty();

	PreviewPlayer = nullptr;
	PreviewTarget = nullptr;
}

AActor* FBSAEditorPreviewScene::GetPlayerActor() const
{
	return PreviewPlayer.Get();
}

AActor* FBSAEditorPreviewScene::GetTargetActor() const
{
	return PreviewTarget.Get();
}

AActor* FBSAEditorPreviewScene::GetSelectedActor() const
{
	if (USelection* Selection = GEditor->GetSelectedActors())
	{
		TArray<AActor*> SelectedActors;
		int32 Num = Selection->GetSelectedObjects(SelectedActors);
		if (Num > 0)
		{
			for (AActor* Actor : SelectedActors)
			{
				if (Actor->GetWorld() == GetWorld())
				{
					return Actor;
				}
			}
		}
	}

	return nullptr;
}

USceneComponent* FBSAEditorPreviewScene::GetSelectedComponent() const
{
	if (USelection* Selection = GEditor->GetSelectedComponents())
	{
		TArray<USceneComponent*> SelectedComponents;
		int32 Num = Selection->GetSelectedObjects(SelectedComponents);
		if (Num > 0)
		{
			for (USceneComponent* Component : SelectedComponents)
			{
				if (Component->GetWorld() == GetWorld())
				{
					return Component;
				}
			}
		}
	}

	return nullptr;
}

TArray<TWeakObjectPtr<AActor>> FBSAEditorPreviewScene::GetPreviewActors() const
{
	return PreviewActors;
}

ULevelStreaming* FBSAEditorPreviewScene::LoadExternalMap(TSoftObjectPtr<UWorld> NewMap)
{
	UWorld* World = GetWorld();
	FWorldContext* WorldConetxt = GEngine->GetWorldContextFromWorld(World);

	ULevelStreaming* NewLevel = EditorLevelUtils::AddLevelToWorld(World, *NewMap.GetLongPackageName(), ULevelStreamingDynamic::StaticClass());
	if (NewLevel)
	{
		NewLevel->SetFlags(RF_Transactional);
		World->SetCurrentLevel(World->PersistentLevel);
	}

	return NewLevel;
}

void FBSAEditorPreviewScene::OnActorMoved(AActor* InActor)
{
	if (!CachedEditor.IsValid() || InActor->GetWorld() != GetWorld() || InActor->IsA<AWorldSettings>() || GetSelectedActor() != InActor)
	{
		return;
	}

	UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (!Asset)
	{
		return;
	}

	if (InActor == PreviewPlayer)
	{
		if (CachedEditor.Pin()->IsStopped() && Asset->PreviewPlayerInfo)
		{
			Asset->PreviewPlayerInfo->SpawnTransform = InActor->GetActorTransform();			
		}
	}
	else if (InActor == PreviewTarget)
	{
		if (CachedEditor.Pin()->IsStopped() && Asset->PreviewTargetInfo)
		{
			Asset->PreviewTargetInfo->SpawnTransform = InActor->GetActorTransform();
		}
	}
	else 
	{
		if (FBSAPreviewProxy* Proxy = CachedEditor.Pin()->GetPreviewProxy().Get())
		{
			Proxy->OnObjectMoved(InActor);
		}
	}
}

void FBSAEditorPreviewScene::OnComponentMoved(USceneComponent* InComponent, ETeleportType InType)
{
	if (!CachedEditor.IsValid() || !InComponent || InComponent->GetWorld() != GetWorld() || GetSelectedComponent() != InComponent)
	{
		return;
	}

	UBSAAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (!Asset)
	{
		return;
	}

	if (FBSAPreviewProxy* Proxy = CachedEditor.Pin()->GetPreviewProxy().Get())
	{
		Proxy->OnObjectMoved(InComponent);
	}
}

#pragma endregion Preview

