#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskCollision.h"

#include "UObject/ObjectSaveContext.h"
#include "Components/LineBatchComponent.h"

#include "BattleSystem/BSFunctionLibrary.h"
#include "3C/Character/BSUnit.h"

#if WITH_EDITOR
#include "DrawDebugHelpers.h"
#endif



#define CHECKCOLLISIONMAX 5



#pragma region CollisionQuery
#if WITH_EDITOR
void UBSATCollisionQueryBase::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);

	if (TargetTypes <= 0)
	{
		TargetTypes = 1;
	}
}

void UBSATCollisionQueryBase::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (TargetTypes != 0 && TargetTypes != 1 && TargetTypes != 2)
	{
		TargetTypes = 1;
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}



void UBSATCollisionQuery::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);

	AutoSetNetType();
}

void UBSATCollisionQuery::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("bUseClientPrediction")))
	{
		if (!bUseClientPrediction)
		{
			Duration = 1.0f;
			LifeType = EBSATaskLife::TL_Instant;
		}
	}

	// 开启客户端预测后，对其他属性进行规范
	if (bUseClientPrediction)
	{
		// 开启预测后对数量进行限制
		if (CollisionResultLimit < 0 || CollisionResultLimit > 10)
		{
			CollisionResultLimit = 5;
		}

		bUseSweep = false;
		NetType = EBSATaskNet::TN_ServerAndLocalClient;
		LifeType = EBSATaskLife::TL_DurAndController;
		Duration = DelayTriggerCollisionEvent + 0.05f;
	}

	if (CollisionStrategy && CollisionStrategy->GetClass() == UBSAFan2DCollision::StaticClass())
	{
		bUseSweep = false;
		if (LifeType == EBSATaskLife::TL_Instant)
		{
			if (UBSAFan2DCollision* FanCollisionSS = Cast<UBSAFan2DCollision>(CollisionStrategy))
			{
				FanCollisionSS->bDynamicFanAngle = false;
			}
		}
	}

	// 自动设置NetType
	AutoSetNetType();

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATCollisionQuery::AutoSetNetType()
{
	if (!GetOuter()->IsAsset())
	{
		return;
	}

	if (bUseClientPrediction)
	{
		if (NetType != EBSATaskNet::TN_ServerAndClient && NetType != EBSATaskNet::TN_ServerAndLocalClient)
		{
			NetType = EBSATaskNet::TN_ServerAndLocalClient;
		}
	}
	else
	{
		// 如果要锁定目标，可能会影响后续逻辑，因此这里不再强设数据
		if (!bLockTargets)
		{
			EBSATaskNet MinType = EBSATaskNet::TN_TMax;
			EBSATaskNet MaxType = EBSATaskNet::TN_ServerOnly;
			for (TMap<FName, FBSATaskSelectorList>::TIterator It1(EventTaskMap); It1; ++It1)
			{
				for (TArray<FBSATaskSelector>::TIterator It2(It1->Value.SelectedTaskList); It2; ++It2)
				{
					if (UBSATask* Task = Cast<UBSATask>(It2->SelectedTask))
					{
						if (MinType > Task->GetNetType())
						{
							MinType = Task->GetNetType();
						}

						if (MaxType < Task->GetNetType())
						{
							MaxType = Task->GetNetType();
						}
					}
				}
			}

			if (MinType >= EBSATaskNet::TN_TMax)
			{
				NetType = EBSATaskNet::TN_TMax;
			}
			else
			{
				if (MinType >= EBSATaskNet::TN_OnlyClient)
				{
					if (NetType < EBSATaskNet::TN_OnlyClient)
					{
						NetType = MinType;
					}
				}

				if (MaxType <= EBSATaskNet::TN_ServerOnly)
				{
					if (NetType > EBSATaskNet::TN_ServerOnly)
					{
						NetType = MaxType;
					}
				}

				if (NetType >= EBSATaskNet::TN_TMax)
				{
					NetType = EBSATaskNet::TN_ServerAndLocalClient;
				}
			}
		}
	}
}
#endif
#pragma endregion CollisionQuery






#pragma region HaloInspection
#if WITH_EDITOR
void UBSATHaloBase::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	for (int32 i = 0; i < HaloConditions.Num(); i++)
	{
		if (HaloConditions[i])
		{
			HaloConditions[i]->CheckTarget = EBSAConditionTarget::CT_TMax;
		}
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATHaloInspection::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);

	AutoSetNetType();
}

void UBSATHaloInspection::AutoSetNetType()
{
	if (!GetOuter()->IsAsset())
	{
		return;
	}

	EBSATaskNet MinType = EBSATaskNet::TN_TMax;
	for (TMap<FName, FBSATaskSelectorList>::TIterator It1(EventTaskMap); It1; ++It1)
	{
		for (TArray<FBSATaskSelector>::TIterator It2(It1->Value.SelectedTaskList); It2; ++It2)
		{
			if (UBSATask* Task = Cast<UBSATask>(It2->SelectedTask))
			{
				if (MinType > Task->GetNetType())
				{
					MinType = Task->GetNetType();
				}
			}
		}
	}

	if (MinType >= EBSATaskNet::TN_TMax)
	{
		NetType = EBSATaskNet::TN_TMax;
	}
	else
	{
		NetType = EBSATaskNet::TN_ServerOnly;
	}
}
#endif
#pragma endregion HaloInspection