#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskAnimation.h"

#include "UObject/ObjectSaveContext.h"

#include "Components/SkeletalMeshComponent.h"
#include "Animation/AnimInstance.h"
#include "BattleSystem/BSFunctionLibrary.h"
#include "BattleSystem/BSBeatenPerformanceAsset.h"



#pragma region PlayAnimation
void UBSATPlayAnimation::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	InOutList.AddUnique(MontageAsset.ToString());
}

#if WITH_EDITOR
void UBSATPlayAnimation::PreSave(FObjectPreSaveContext SaveContext)
{
	if (UAnimMontage* MontageData = MontageAsset.LoadSynchronous())
	{
		MontageRootmotion = FTransform();
		ExportAnimRootmotionCurve();
	}
	else
	{
		MontageRootmotion = FTransform();
		TimeMappingTrScaleFloatCurve.GetRichCurve()->Reset();
		TimeMappingRotationFloatCurve.GetRichCurve()->Reset();
		TimeMappingTranslationFloatCurve.GetRichCurve()->Reset();
	}
	
	Super::PreSave(SaveContext);
}

void UBSATPlayAnimation::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.Property->GetName() == TEXT("MontageAsset") || PropertyChangedEvent.Property->GetName() == TEXT("PlayRate"))
	{
		if (UAnimMontage* MontageData = MontageAsset.LoadSynchronous())
		{
			Duration = MontageData->GetPlayLength() / PlayRate;
			MontageRootmotion = FTransform();
			ExportAnimRootmotionCurve();
		}
		else
		{
			MontageRootmotion = FTransform();
			TimeMappingTrScaleFloatCurve.GetRichCurve()->Reset();
			TimeMappingRotationFloatCurve.GetRichCurve()->Reset();
			TimeMappingTranslationFloatCurve.GetRichCurve()->Reset();
		}
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATPlayAnimation::ExportAnimRootmotionCurve()
{
	TimeMappingTrScaleFloatCurve.GetRichCurve()->Reset();
	TimeMappingRotationFloatCurve.GetRichCurve()->Reset();
	TimeMappingTranslationFloatCurve.GetRichCurve()->Reset();

	if (UAnimMontage* MontageData = MontageAsset.LoadSynchronous())
	{
		FTransform tRootmotionTransform;
		FVector tMontageTranslation, MaxMontageTranslation = FVector::ZeroVector, tMontageScale, MaxMontageScale = FVector::OneVector;
		float tMontageRotationYaw = 0.0f, MaxMontageRotationYaw = 0.0f;
		FQuat MaxMontageRotation;
		TMap<float, float> ScaleData, RotationData;
		TMap<float, FVector> TranslationData;

		// 采集数据
		float TotalTime = MontageData->GetPlayLength() / PlayRate;
		for (float i = 0.1f; i <= TotalTime; i = FMath::Min(i + 0.1f, TotalTime))
		{
			tRootmotionTransform = MontageData->ExtractRootMotionFromTrackRange(0.0f, i * PlayRate);

			tMontageScale = tRootmotionTransform.GetScale3D();
			ScaleData.Add(i, tMontageScale.Size());
			if (tMontageScale.Size() > MaxMontageScale.Size())
			{
				MaxMontageScale = tMontageScale;
			}

			tMontageRotationYaw = tRootmotionTransform.Rotator().Yaw;
			RotationData.Add(i, tMontageRotationYaw);
			if (FMath::Abs(tMontageRotationYaw) > FMath::Abs(MaxMontageRotationYaw))
			{
				MaxMontageRotationYaw = tMontageRotationYaw;
				MaxMontageRotation = tRootmotionTransform.GetRotation();
			}

			tMontageTranslation = tRootmotionTransform.GetTranslation();
			TranslationData.Add(i, tMontageTranslation);
			if (tMontageTranslation.Size() > MaxMontageTranslation.Size())
			{
				MaxMontageTranslation = tMontageTranslation;
			}

			if (FMath::Abs(i - TotalTime) < 0.001f)
			{
				break;
			}
		}

		auto SimplifyKeys = [&](FRuntimeFloatCurve* InCurve) {
			FRichCurve* tCurve = InCurve->GetRichCurve();
			TArray<FRichCurveKey> tKeys = tCurve->Keys;
			for (int32 i = 1; i < tKeys.Num() - 1; i++)
			{
				FRichCurveKey* Key1 = &tKeys[i - 1];
				FRichCurveKey* Key2 = &tKeys[i];
				FRichCurveKey* Key3 = &tKeys[i + 1];

				if ((Key2->Time - Key1->Time) > 0.2f || (Key3->Time - Key2->Time) > 0.2f)
				{
					// 精简不能让节点过于稀疏
					continue;
				}

				float Gradient1 = (Key2->Value - Key1->Value) / (Key2->Time - Key1->Time);
				float Gradient2 = (Key3->Value - Key2->Value) / (Key3->Time - Key2->Time);
				if (FMath::Abs(Gradient1 - Gradient2) <= 0.5 * TotalTime)
				{
					tKeys.RemoveAt(i);
					i--;
				}
			}
			tCurve->SetKeys(tKeys);
		};

		// 采集到有效的信息，则输出
		float tCurveValue = 0.0f;
		if (MaxMontageScale.Size() > 1.74f)
		{
			TimeMappingTrScaleFloatCurve.GetRichCurve()->AddKey(0.0f, 1.0f);
			for (TMap<float, float>::TIterator It(ScaleData); It; ++It)
			{
				tCurveValue = It.Value() / MaxMontageScale.Size();
				TimeMappingTrScaleFloatCurve.GetRichCurve()->AddKey(It.Key() / TotalTime, tCurveValue);
			}
			SimplifyKeys(&TimeMappingTrScaleFloatCurve);
			MontageRootmotion.SetScale3D(MaxMontageScale);
		}
		if (MaxMontageRotationYaw > 0.0f)
		{
			TimeMappingRotationFloatCurve.GetRichCurve()->AddKey(0.0f, 0.0f);
			for (TMap<float, float>::TIterator It(RotationData); It; ++It)
			{
				tCurveValue = It.Value() / MaxMontageRotationYaw;
				TimeMappingRotationFloatCurve.GetRichCurve()->AddKey(It.Key() / TotalTime, tCurveValue);
			}
			SimplifyKeys(&TimeMappingRotationFloatCurve);
			MontageRootmotion.SetRotation(MaxMontageRotation);
		}
		if (MaxMontageTranslation.Size() > 0.0f)
		{
			TimeMappingTranslationFloatCurve.GetRichCurve()->AddKey(0.0f, 0.0f);
			for (TMap<float, FVector>::TIterator It(TranslationData); It; ++It)
			{
				tCurveValue = It.Value().Size() / MaxMontageTranslation.Size() * (It.Value().Dot(MaxMontageTranslation) > 0.0f ? 1.0f : -1.0f);
				TimeMappingTranslationFloatCurve.GetRichCurve()->AddKey(It.Key() / TotalTime, tCurveValue);
			}
			SimplifyKeys(&TimeMappingTranslationFloatCurve);
			MontageRootmotion.SetTranslation(MaxMontageTranslation);
		}		
	}
}

#endif

#pragma endregion PlayAnimation






void UBSATPlayJumpAnimation::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	if (!IdleMontageAsset.IsNull())
	{
		InOutList.AddUnique(IdleMontageAsset.ToString());
	}
	if (!LocoInputMontageAsset.IsNull())
	{
		InOutList.AddUnique(LocoInputMontageAsset.ToString());
	}	
}