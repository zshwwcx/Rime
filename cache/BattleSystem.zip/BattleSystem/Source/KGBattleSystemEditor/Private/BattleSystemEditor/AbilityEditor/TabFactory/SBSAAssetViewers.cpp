#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSAAssetViewers.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/BSAPreviewSettings.h"



#define LOCTEXT_NAMESPACE "BSAAssetTabBodys"



void SBSAAssetPropertyTabBody::Construct(const FArguments& InArgs, TSharedPtr<FBSAEditor> InEditor)
{
	CachedEditor = InEditor;

	SSingleObjectDetailsPanel::Construct(SSingleObjectDetailsPanel::FArguments().HostCommandList(CachedEditor.Pin()->GetToolkitCommands()), true, true);
}

UObject* SBSAAssetPropertyTabBody::GetObjectToObserve() const
{
	return Cast<UObject>(CachedEditor.Pin()->GetEditingAsset());
}

TSharedRef<SWidget> SBSAAssetPropertyTabBody::PopulateSlot(TSharedRef<SWidget> PropertyEditorWidget)
{
	return 
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush(TEXT("Graph.TitleBackground")))
			.HAlign(HAlign_Center)
			.Visibility(this, &SBSAAssetPropertyTabBody::GetAssetDisplayNameVisibility)
		]
		+ SVerticalBox::Slot()
		.FillHeight(1)
		[
			PropertyEditorWidget
		];
}

EVisibility SBSAAssetPropertyTabBody::GetAssetDisplayNameVisibility() const
{
	return (GetObjectToObserve() != NULL) ? EVisibility::Hidden : EVisibility::Collapsed;
}

FText SBSAAssetPropertyTabBody::GetAssetDisplayName() const
{
	return LOCTEXT("BSAAssetProperty", "Asset Properties");
}



void SBSAEditorSettingsTabBody::Construct(const FArguments& InArgs, TSharedPtr<FBSAEditor> InEditor)
{
	CachedEditor = InEditor;

	SSingleObjectDetailsPanel::Construct(SSingleObjectDetailsPanel::FArguments().HostCommandList(CachedEditor.Pin()->GetToolkitCommands()), true, true);
}

UObject* SBSAEditorSettingsTabBody::GetObjectToObserve() const
{
	return Cast<UObject>(CachedEditor.Pin()->GetPreviewSettings());
}

TSharedRef<SWidget> SBSAEditorSettingsTabBody::PopulateSlot(TSharedRef<SWidget> PropertyEditorWidget)
{
	return 
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush(TEXT("Graph.TitleBackground")))
			.HAlign(HAlign_Center)
			.Visibility(this, &SBSAEditorSettingsTabBody::GetAssetDisplayNameVisibility)
		]
		+ SVerticalBox::Slot()
		.FillHeight(1)
		[
			PropertyEditorWidget
		];
}

EVisibility SBSAEditorSettingsTabBody::GetAssetDisplayNameVisibility() const
{
	return (GetObjectToObserve() != NULL) ? EVisibility::Hidden : EVisibility::Collapsed;
}

FText SBSAEditorSettingsTabBody::GetAssetDisplayName() const
{
	return LOCTEXT("BSAEditorSettings", "Editor Settings");
}



#undef LOCTEXT_NAMESPACE
