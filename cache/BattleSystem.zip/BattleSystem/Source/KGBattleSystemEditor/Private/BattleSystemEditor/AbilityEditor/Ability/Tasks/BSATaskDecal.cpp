#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskDecal.h"
#include "Kismet/KismetMathLibrary.h"

#include "BattleSystem/BSFunctionLibrary.h"
#include "Components/DecalComponent.h"
#include "Materials/MaterialInstanceDynamic.h"



void UBSATAddDecal::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	InOutList.AddUnique(DecalAsset.ToString());
}

#if WITH_EDITOR
void UBSATAddDecal::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (LifeType == EBSATaskLife::TL_Instant)
	{
		LifeType = EBSATaskLife::TL_DurAndController;
	}

	if (bNeedAttach == false)
	{
		bAttachRotation = false;
		bAttachScale = false;
	}
	
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATAddDecal::UpdateDataByDynamicActorInfo(const FBSADynamicObjectInfo& InInfo)
{
	AActor* DActor = Cast<AActor>(InInfo.DynamicObject);
	if (!DActor)
		return;

	if (bNeedAttach)
	{
		AttachTransform.ConfigValue = DActor->GetRootComponent()->GetRelativeTransform();
	}
	else if (!CoordinateCreater.OffsetTransform.bUseInputData)
	{
		FTransform CurWorldTransform = DActor->GetActorTransform();
		CoordinateCreater.OffsetTransform.ConfigValue = CurWorldTransform * InInfo.CachedTransform.Inverse();
	}
}

void UBSATAddDecal::UpdateDynamicActorByData(const FBSADynamicObjectInfoArray& InInfoArray)
{
	for (int32 i = 0; i < InInfoArray.Informations.Num(); ++i)
	{
		AActor* DActor = Cast<AActor>(InInfoArray.Informations[i].DynamicObject);
		if (!DActor)
			continue;

		if (bNeedAttach)
		{
			DActor->SetActorRelativeTransform(AttachTransform.ConfigValue);
		}
		else if (!CoordinateCreater.OffsetTransform.bUseInputData)
		{
			FTransform CurWorldTransform = CoordinateCreater.OffsetTransform.ConfigValue * InInfoArray.Informations[i].CachedTransform;

			if (bNeedCheckGround)
			{
				FVector Result(ForceInit), ResNormal(ForceInit); TArray<AActor*> IgnoreActors;
				FVector UpVec = DActor->GetActorUpVector();
				UBSFunctionLibrary::FindGroundLocation(InInfoArray.Informations[i].DynamicObject, CurWorldTransform.GetLocation(), GroundCheckObjectTypes, Result, ExtraGroundMsg, UpVec * -1.0f);
			}

			DActor->SetActorTransform(CurWorldTransform);
		}
	}
}

#endif
