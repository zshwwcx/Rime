#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskMaterial.h"

#include "BattleSystem/BSFunctionLibrary.h"



void UBSATChangeMeshMaterial::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	// if (bChangeAllMesh)
	// {
	// 	for (int32 j = 0; j < MaterialInfos.Num(); ++j)
	// 	{
	// 		InOutList.AddUnique(MaterialInfos[j].ReplaceMaterial.ToString());
	//
	// 		for (int32 k = 0; k < MaterialInfos[j].MaterialTextureParamValues.Num(); ++k)
	// 		{
	// 			InOutList.AddUnique(MaterialInfos[j].MaterialTextureParamValues[k].NewTexture.ToString());
	// 		}
	// 	}
	// }
	// else
	// {
	// 	for (int32 i = 0; i < OverrideMaterials.Num(); ++i)
	// 	{
	// 		for (int32 j = 0; j < OverrideMaterials[i].MaterialInfos.Num(); ++j)
	// 		{
	// 			InOutList.AddUnique(OverrideMaterials[i].MaterialInfos[j].ReplaceMaterial.ToString());
	//
	// 			for (int32 k = 0; k < OverrideMaterials[i].MaterialInfos[j].MaterialTextureParamValues.Num(); ++k)
	// 			{
	// 				InOutList.AddUnique(OverrideMaterials[i].MaterialInfos[j].MaterialTextureParamValues[k].NewTexture.ToString());
	// 			}
	// 		}
	// 	}
	// }
}

#if WITH_EDITOR
void UBSATChangeMeshMaterial::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	MaterialScriptDataIndex.Empty();

	// if (bChangeAllMesh)
	// {
	// 	for (int32 i = 0; i < MaterialInfos.Num(); ++i)
	// 	{
	// 		FOverrideMaterialParameter& OMP = MaterialInfos[i];
	//
	// 		for (int32 j = 0; j < OMP.MaterialScalarParamValues.Num(); ++j)
	// 		{
	// 			FMaterialScalarParameter& MSP = OMP.MaterialScalarParamValues[j];
	//
	// 			if (MSP.ParameterType == EMaterialParameterUsingType::MPT_UseManagerValue)
	// 			{
	// 				MaterialScriptDataIndex.AddUnique(MSP.DataIndex);
	// 			}
	// 		}
	//
	// 		for (int32 j = 0; j < OMP.MaterialVectorParamValues.Num(); ++j)
	// 		{
	// 			FMaterialVectorParameter& MVP = OMP.MaterialVectorParamValues[j];
	//
	// 			if (MVP.ParameterType == EMaterialParameterUsingType::MPT_UseManagerValue)
	// 			{
	// 				MaterialScriptDataIndex.AddUnique(MVP.DataIndex);
	// 			}
	// 		}
	// 	}
	// }
	// else
	// {
	// 	for (int32 Loop = 0; Loop < OverrideMaterials.Num(); ++Loop)
	// 	{
	// 		FBSATaskMeshMaterialOverride& TMMO = OverrideMaterials[Loop];
	//
	// 		for (int32 i = 0; i < TMMO.MaterialInfos.Num(); ++i)
	// 		{
	// 			FOverrideMaterialParameter& OMP = TMMO.MaterialInfos[i];
	//
	// 			for (int32 j = 0; j < OMP.MaterialScalarParamValues.Num(); ++j)
	// 			{
	// 				FMaterialScalarParameter& MSP = OMP.MaterialScalarParamValues[j];
	//
	// 				if (MSP.ParameterType == EMaterialParameterUsingType::MPT_UseManagerValue)
	// 				{
	// 					MaterialScriptDataIndex.AddUnique(MSP.DataIndex);
	// 				}
	// 			}
	//
	// 			for (int32 j = 0; j < OMP.MaterialVectorParamValues.Num(); ++j)
	// 			{
	// 				FMaterialVectorParameter& MVP = OMP.MaterialVectorParamValues[j];
	//
	// 				if (MVP.ParameterType == EMaterialParameterUsingType::MPT_UseManagerValue)
	// 				{
	// 					MaterialScriptDataIndex.AddUnique(MVP.DataIndex);
	// 				}
	// 			}
	// 		}
	// 	}
	// }
}

#endif
