#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/BSALogicGraph.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/BSALogicGraphNode.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "EdGraph/EdGraphSchema.h"


UBSALogicGraph::UBSALogicGraph()
{

}

UBSALogicGraph::~UBSALogicGraph()
{

}

void UBSALogicGraph::RefreshLogicGraph()
{
	UBSAAsset* Asset = Cast<UBSAAsset>(GetOuter());
	if (!Asset)
		return;

	// 删除无效节点
	for (int32 i = Nodes.Num() - 1; i >= 0; --i)
	{
		if (UBSALogicGraphNode* Node = Cast<UBSALogicGraphNode>(Nodes[i]))
		{
			if (!Node->CachedTask || !Asset->GetSectionPointerByTask(Node->CachedTask))
			{
				Node->DestroyNode();
			}
		}
	}

	// 刷新已有节点的Pin
	for (int32 i = 0; i < Nodes.Num(); ++i)
	{
		if (UBSALogicGraphNode* Node = Cast<UBSALogicGraphNode>(Nodes[i]))
		{
			Node->UpdatePins();
		}
	}

	// 根据现在的数据/事件传输关系，重建节点和连接关系
	for (int32 i = 0; i < Nodes.Num(); i++)
	{
		for (int32 j = i + 1; j < Nodes.Num(); j++)
		{
			UBSALogicGraphNode* Node1 = Cast<UBSALogicGraphNode>(Nodes[i]);
			UBSALogicGraphNode* Node2 = Cast<UBSALogicGraphNode>(Nodes[j]);
			if (Node1 && Node2)
			{
				TryAutoConnectPin(Node1, Node2);
				TryAutoConnectPin(Node2, Node1);
			}
		}
	}
}

void UBSALogicGraph::TryAutoConnectPin(UBSALogicGraphNode* Node1, UBSALogicGraphNode* Node2)
{
	UEdGraphPin* Pin1, * Pin2;
	
	// 更新Task事件触发列表
	for (TMap<FName, FBSATaskSelectorList>::TIterator It(Node1->CachedTask->EventTaskMap); It; ++It)
	{
		TArray<FBSATaskSelector> TaskSelectorArray = It->Value.SelectedTaskList;
		for (int i = 0; i < TaskSelectorArray.Num(); i++)
		{
			if (TaskSelectorArray[i].SelectedTask == Node2->CachedTask)
			{
				Pin1 = Node1->GetPinByName(It.Key());
				Pin2 = Node2->GetPinByName(FName("Exe"));
				if (Pin1 && Pin2 && !Pin1->LinkedTo.Contains(Pin2))
				{
					GetSchema()->TryCreateConnection(Pin1, Pin2);
				}
			}
		}
	}

	// 更新碰撞信息列表
	TArray<FBSATaskInputInfo> TaskCollisionInfos;
	Node1->CachedTask->GetCollisionTargetInfos(TaskCollisionInfos);
	for (FBSATaskInputInfo SingleCollisionInfo : TaskCollisionInfos)
	{
		if (SingleCollisionInfo.ProduceDataTask.SelectedTask == Node2->CachedTask)
		{
			Pin1 = Node1->GetPinByName(SingleCollisionInfo.DisplayName);
			Pin2 = Node2->GetPinByName(SingleCollisionInfo.DataDesc);
			if (Pin1 && Pin2 && !Pin1->LinkedTo.Contains(Pin2))
			{
				GetSchema()->TryCreateConnection(Pin1, Pin2);
			}
		}
	}

	// 修复InputDatas
	for (FBSATaskInputInfo SingelInputInfo : Node1->CachedTask->InputDatas)
	{
		if (SingelInputInfo.ProduceDataTask.SelectedTask == Node2->CachedTask)
		{
			Pin1 = Node1->GetPinByName(SingelInputInfo.DisplayName);
			Pin2 = Node2->GetPinByName(SingelInputInfo.DataDesc);
			if (Pin1 && Pin2 && !Pin1->LinkedTo.Contains(Pin2))
			{
				GetSchema()->TryCreateConnection(Pin1, Pin2);
			}
		}
	}
}

