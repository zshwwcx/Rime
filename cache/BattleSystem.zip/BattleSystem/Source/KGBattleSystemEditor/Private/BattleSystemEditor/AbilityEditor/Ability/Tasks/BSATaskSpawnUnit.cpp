#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskSpawnUnit.h"

#include "BattleSystem/Ability/BSAStructs.h"
#include "BattleSystem/BSFunctionLibrary.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSABuffAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"

#include "3C/Character/BaseCharacter.h"



APawn* FindBSUnitInstigator(AActor* InOwner)
{
	if (InOwner)
	{
		if (InOwner->IsA<APawn>())
		{
			return Cast<APawn>(InOwner);
		}
		else
		{
			return InOwner->GetInstigator();
		}
	}

	return nullptr;
}

int64 CalculateTemplateID(int64 OriginID, UBSATask* InTask)
{
	if (!InTask)
		return 0;

	if (UBSAAsset* Asset = Cast<UBSAAsset>(InTask->GetOuter()))
	{
		int64 TempID = Asset->ID;

		if (OriginID / 10000000 == TempID)
		{
			return OriginID;
		}

		TempID = TempID * 10000000 + Asset->CreateNewUniqueID() * 10;
		if (Asset->IsA<UBSASkillAsset>())
		{
			TempID += 1;
		}
		else if (Asset->IsA<UBSABuffAsset>())
		{
			TempID += 2;
		}

		return TempID;
	}

	return 0;
}






#pragma region Base
UBSMoveableUnitData::UBSMoveableUnitData()
{
	SweepObjectTypes.Add(EObjectTypeQuery::ObjectTypeQuery1);
	SweepObjectTypes.Add(EObjectTypeQuery::ObjectTypeQuery7);

	SweepFilter.ClassTypes.Add(ABaseCharacter::StaticClass());
}

void UBSMoveableUnitData::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	for (int32 i = 0; i < ProjectileMeshList.Num(); ++i)
	{
		InOutList.AddUnique(ProjectileMeshList[i].StaticMesh.ToString());
		InOutList.AddUnique(ProjectileMeshList[i].SkeletalMesh.ToString());
		InOutList.AddUnique(ProjectileMeshList[i].AnimSequence.ToString());
	}

	InOutList.AddUnique(ProjectileNiagara.ToString());
	InOutList.AddUnique(ProjectileTrailNiagara.ToString());

	InOutList.AddUnique(SoundAsset.ToString());
}
#pragma region Base






#pragma region SpellField
UBSUSpellFieldData::UBSUSpellFieldData()
{
	
}

void UBSUSpellFieldData::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	InOutList.AddUnique(MainSkill.ToString());
}

UBSATSpawnSpellField::UBSATSpawnSpellField()
{
	
}

void UBSATSpawnSpellField::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	if (SpellFieldData)
	{
		SpellFieldData->GetReferenceResources(InOutList);
	}
}

#if WITH_EDITOR
void UBSATSpawnSpellField::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);

	if (SpellFieldData)
	{
		SpellFieldData->TempID = CalculateTemplateID(SpellFieldData->TempID, this);
		SpellFieldData->RefreshBPProperty();
	}
}

void UBSATSpawnSpellField::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("SpellFieldClass")) && !IsTemplate())
	{
		if (SpellFieldData)
		{
			SpellFieldData->MarkAsGarbage();
			SpellFieldData = nullptr;
		}

		if (SpellFieldClass)
		{
			if (const ABSUnit* DefaultUnit = Cast<ABSUnit>(SpellFieldClass->GetDefaultObject()))
			{
				SpellFieldData = NewObject<UBSUSpellFieldData>(this, DefaultUnit->StaticDataType);
			}
		}
	}

	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("SpellFieldData")))
	{
		if (SpellFieldData)
		{
			if (SpellFieldData->bNeedReplicated)
				NetType = EBSATaskNet::TN_ServerOnly;
			else
				NetType = EBSATaskNet::TN_ServerAndClient;
		}
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATSpawnSpellField::CopyDataFromOther(UBSATaskBase* OtherTask)
{
	Super::CopyDataFromOther(OtherTask);

	if (SpellFieldData)
	{
		SpellFieldData->TempID = 0;
	}
}
#endif


UBSATSpawnRandomSpellField::UBSATSpawnRandomSpellField()
{

}

void UBSATSpawnRandomSpellField::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	for (UBSURandomSpellFieldData* tSingleSpellFieldData : SpellFieldDatas)
	{
		if (tSingleSpellFieldData)
		{
			tSingleSpellFieldData->GetReferenceResources(InOutList);
		}
	}
}

#if WITH_EDITOR
void UBSATSpawnRandomSpellField::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);

	int64 CurrentTempID = 0;
	for (UBSURandomSpellFieldData* tSingleSpellFieldData : SpellFieldDatas)
	{
		if (tSingleSpellFieldData)
		{
			tSingleSpellFieldData->TempID = CalculateTemplateID(tSingleSpellFieldData->TempID, this);
			tSingleSpellFieldData->RefreshBPProperty();
		}
	}
}

void UBSATSpawnRandomSpellField::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("SpellFieldClass")) && !IsTemplate())
	{
		for (UBSURandomSpellFieldData* tSingleSpellFieldData : SpellFieldDatas)
		{
			if (tSingleSpellFieldData)
			{
				tSingleSpellFieldData->MarkAsGarbage();
			}
		}
		SpellFieldDatas.Reset();


		if (SpellFieldClass)
		{
			if (const ABSUnit* DefaultUnit = Cast<ABSUnit>(SpellFieldClass->GetDefaultObject()))
			{
				UBSURandomSpellFieldData* tSpellFieldData = NewObject<UBSURandomSpellFieldData>(this);
				SpellFieldDatas.Add(tSpellFieldData);
			}
		}
	}

	NetType = EBSATaskNet::TN_ServerOnly;
	SpawnNum = 0;
	for (UBSURandomSpellFieldData* tSingleSpellFieldData : SpellFieldDatas)
	{
		if (tSingleSpellFieldData)
		{
			tSingleSpellFieldData->bNeedReplicated = true;
			SpawnNum += tSingleSpellFieldData->ReleaseTimes;
		}
	}

	if (SpawnInterval > 0.0f)
	{
		if (LifeType == EBSATaskLife::TL_Instant)
		{
			SetLifeType(EBSATaskLife::TL_DurAndController);
		}
	}
	else
	{
		if (LifeType != EBSATaskLife::TL_Instant)
		{
			SetLifeType(EBSATaskLife::TL_Instant);
		}
	}

	if (RandomRadiusMax < RandomRadiusMin)
	{
		RandomRadiusMax = RandomRadiusMin;
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATSpawnRandomSpellField::CopyDataFromOther(UBSATaskBase* OtherTask)
{
	Super::CopyDataFromOther(OtherTask);

	for (UBSURandomSpellFieldData* tSingleSpellFieldData : SpellFieldDatas)
	{
		if (tSingleSpellFieldData)
		{
			tSingleSpellFieldData->TempID = 0;
		}
	}
}
#endif

#pragma endregion SpellField






#pragma region Projectile
UBSUProjectileData::UBSUProjectileData()
{
	SpeedCurve.bNeedRemap = false;
	SpeedCurve.Curve.EditorCurveData.AddKey(0.0f, 2000.0f);
}

void UBSUProjectileData::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	// 收集命中数据
	for (TMap<TSoftObjectPtr<UBSABuffAsset>, FVector2D>::TIterator It(HitLogic.Buffs); It; ++It)
	{
		if (!It->Key.IsNull())
		{
			InOutList.AddUnique(It->Key.ToString());
		}
	}
	if (!HitLogic.ClientSkill.IsNull())
	{
		InOutList.AddUnique(HitLogic.ClientSkill.ToString());
	}
	if (!HitLogic.Effect.IsNull())
	{
		InOutList.AddUnique(HitLogic.Effect.ToString());
	}
	if (!HitLogic.Sound.IsNull())
	{
		InOutList.AddUnique(HitLogic.Sound.ToString());
	}
	if (!HitLogic.SpellField.IsNull())
	{
		InOutList.AddUnique(HitLogic.SpellField.ToString());
	}

	// 收集寿终正寝数据
	for (TMap<TSoftObjectPtr<UBSABuffAsset>, FVector2D>::TIterator It(LifeEndLogic.Buffs); It; ++It)
	{
		if (!It->Key.IsNull())
		{
			InOutList.AddUnique(It->Key.ToString());
		}
	}
	if (!LifeEndLogic.ClientSkill.IsNull())
	{
		InOutList.AddUnique(LifeEndLogic.ClientSkill.ToString());
	}
	if (!LifeEndLogic.Effect.IsNull())
	{
		InOutList.AddUnique(LifeEndLogic.Effect.ToString());
	}
	if (!LifeEndLogic.Sound.IsNull())
	{
		InOutList.AddUnique(LifeEndLogic.Sound.ToString());
	}
	if (!LifeEndLogic.SpellField.IsNull())
	{
		InOutList.AddUnique(LifeEndLogic.SpellField.ToString());
	}
}

#if WITH_EDITOR
void UBSUProjectileData::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	for (int32 i = 0; i < SpeedCurve.Curve.EditorCurveData.Keys.Num(); ++i)
	{
		FRichCurveKey& CurKey = SpeedCurve.Curve.EditorCurveData.Keys[i];

		if (CurKey.Value < 0.00001f)
		{
			CurKey.Value = 0.00001f;
		}
	}

	// 找到最小的延迟死亡时间
	if (!HitLogic.bUseSpellField && !HitLogic.bUseClientSkill)
	{
		DelayDestroy = FMath::Max3(DelayDestroy, HitLogic.DelayPlayEffect + 1.0f, HitLogic.DelayPlaySound + 1.0f);
		for (TMap<TSoftObjectPtr<UBSABuffAsset>, FVector2D>::TIterator It(HitLogic.Buffs); It; ++It)
		{
			DelayDestroy = FMath::Max(DelayDestroy, It->Value.X + 1.0f);
		}
	}
	if (!LifeEndLogic.bUseSpellField && !LifeEndLogic.bUseClientSkill)
	{
		DelayDestroy = FMath::Max3(DelayDestroy, LifeEndLogic.DelayPlayEffect + 1.0f, LifeEndLogic.DelayPlaySound + 1.0f);
		for (TMap<TSoftObjectPtr<UBSABuffAsset>, FVector2D>::TIterator It(LifeEndLogic.Buffs); It; ++It)
		{
			DelayDestroy = FMath::Max(DelayDestroy, It->Value.X + 1.0f);
		}
	}

	// 刷新AttackActionID
	if (UObject* Task = GetOuter())
	{
		if (UBSAAsset* Asset = Cast<UBSAAsset>(Task->GetOuter()))
		{
			if (HitLogic.AttackActionID < 10000000)
			{
				HitLogic.AttackActionID = HitLogic.AttackActionID % 100;
				if (HitLogic.AttackActionID > 0)
				{
					HitLogic.AttackActionID = Asset->ID * 100 + HitLogic.AttackActionID;
				}
			}

			if (LifeEndLogic.AttackActionID < 10000000)
			{
				LifeEndLogic.AttackActionID = LifeEndLogic.AttackActionID % 100;
				if (LifeEndLogic.AttackActionID > 0)
				{
					LifeEndLogic.AttackActionID = Asset->ID * 100 + LifeEndLogic.AttackActionID;
				}
			}
		}
	}
	

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif



UBSUMissileData::UBSUMissileData()
{
	bRotationFollowsVelocity = true;
	TrackAccelerationCurve.bNeedRemap = false;
}

void UBSUMissileData::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

}

#if WITH_EDITOR
void UBSUMissileData::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	bIsSphereCollision = true;

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif



UBSATSpawnProjectile::UBSATSpawnProjectile()
{
	
}

void UBSATSpawnProjectile::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	if (ProjectileData)
	{
		ProjectileData->GetReferenceResources(InOutList);
	}
}

#if WITH_EDITOR
void UBSATSpawnProjectile::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);

	if (ProjectileData)
	{
		ProjectileData->TempID = CalculateTemplateID(ProjectileData->TempID, this);
		ProjectileData->RefreshBPProperty();
	}
}

void UBSATSpawnProjectile::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("ProjectileClass")) && !IsTemplate())
	{
		if (ProjectileData)
		{
			ProjectileData->MarkAsGarbage();
			ProjectileData = nullptr;
		}

		if (ProjectileClass)
		{
			if (const ABSUnit* DefaultUnit = Cast<ABSUnit>(ProjectileClass->GetDefaultObject()))
			{
				ProjectileData = NewObject<UBSMoveableUnitData>(this, DefaultUnit->StaticDataType);
			}
		}
	}

	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("ProjectileData")))
	{
		if (ProjectileData)
		{
			if (ProjectileData->bNeedReplicated)
			{
				NetType = EBSATaskNet::TN_ServerOnly;
			}
		}
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATSpawnProjectile::CopyDataFromOther(UBSATaskBase* OtherTask)
{
	Super::CopyDataFromOther(OtherTask);

	if (ProjectileData)
	{
		ProjectileData->TempID = 0;
	}
}

bool UBSATSpawnProjectile::UpdateEditorProperty()
{
	return false;
}

#endif

#pragma endregion Projectile






#pragma region Boomerang
UBSUBoomerangData::UBSUBoomerangData()
{
	SpeedCurve.bNeedRemap = false;
	SpeedCurve.Curve.EditorCurveData.AddKey(0.0f, 2000.0f);

	TotalLife = FlyAwayMaxTime + HoverMaxTime + FlyBackMaxTime;
}

void UBSUBoomerangData::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	InOutList.AddUnique(FlyAwayHitSkill.ToString());

	InOutList.AddUnique(HoverHitSkill.ToString());

	InOutList.AddUnique(FlyBackHitSkill.ToString());

	InOutList.AddUnique(LifeEndSkill.ToString());
}

#if WITH_EDITOR
void UBSUBoomerangData::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{	
	for (int32 i = 0; i < SpeedCurve.Curve.EditorCurveData.Keys.Num(); ++i)
	{
		FRichCurveKey& CurKey = SpeedCurve.Curve.EditorCurveData.Keys[i];

		if (CurKey.Value < 0.00001f)
		{
			CurKey.Value = 0.00001f;
		}
	}

	TotalLife = FlyAwayMaxTime + HoverMaxTime + FlyBackMaxTime;

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif
#pragma endregion Boomerang