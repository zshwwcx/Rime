#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineDragDropOp.h"
#include "Framework/Application/SlateApplication.h"

#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackNode.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackTimeline.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackOutliner.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"



#define LOCTEXT_NAMESPACE "FBSATimelineDragDropOp"



FBSATrackDragDropOp::FBSATrackDragDropOp()
{

}

void FBSATrackDragDropOp::Construct()
{
	MouseCursor = EMouseCursor::GrabHandClosed;

	FDragDropOperation::Construct();
}

TSharedRef<FBSATrackDragDropOp> FBSATrackDragDropOp::New(const TSharedPtr<FBSATimelineController>& InTimelineController, UBSATask* InTask, TSharedPtr<SWidget> Decorator)
{
	TSharedRef<FBSATrackDragDropOp> Operation = MakeShareable(new FBSATrackDragDropOp);
	Operation->TimelineController = InTimelineController;
	Operation->CachedTask = InTask;
	Operation->Decorator = Decorator;
	Operation->Construct();

	return Operation;
}

void FBSATrackDragDropOp::OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent)
{
	if (!bDropWasHandled)
	{

	}
}

void FBSATrackDragDropOp::OnDragged(const class FDragDropEvent& DragDropEvent)
{
	if (CursorDecoratorWindow.IsValid())
	{
		CursorDecoratorWindow->MoveWindowTo(DragDropEvent.GetScreenSpacePosition());
	}
}

TSharedPtr<SWidget> FBSATrackDragDropOp::GetDefaultDecorator() const
{
	return Decorator;
}

void FBSATrackDragDropOp::SetCanDropHere(bool bCanDropHere)
{
	MouseCursor = bCanDropHere ? EMouseCursor::TextEditBeam : EMouseCursor::SlashedCircle;
}

void FBSATrackDragDropOp::ChangeTaskTrackPosition(UBSATask* TargetTask)
{
	TimelineController.Pin()->ChangeTaskPosition(CachedTask.Get(), TargetTask);
}






FBSATrackNodeDragDropOp::FBSATrackNodeDragDropOp(float& InCurrentDragXPosition) :SelectionTimeLength(0.0f), CurrentDragXPosition(InCurrentDragXPosition)
{

}

TSharedRef<FBSATrackNodeDragDropOp> FBSATrackNodeDragDropOp::New
(
	TArray<TSharedPtr<SBSATaskTrackNode>> NotifyNodes, TSharedPtr<SWidget> Decorator, 
	const TArray<TSharedPtr<SBSATaskTrackTimeline>>& NotifyTracks, float InViewPlayLength, 
	const FVector2D& CursorPosition, const FVector2D& SelectionScreenPosition, 
	const FVector2D& SelectionSize, float& CurrentDragXPosition, FRefreshPanel& RefreshPanel
)
{
	TSharedRef<FBSATrackNodeDragDropOp> Operation = MakeShareable(new FBSATrackNodeDragDropOp(CurrentDragXPosition));
	Operation->ViewPlayLength = MAX_FLT;
	Operation->RefreshPanelEvent = RefreshPanel;

	Operation->NodeGroupPosition = SelectionScreenPosition;
	Operation->NodeGroupSize = SelectionSize;
	Operation->DragOffset = SelectionScreenPosition - CursorPosition;
	Operation->Decorator = Decorator;
	Operation->SelectedNodes = NotifyNodes;
	Operation->TrackSpan = NotifyTracks.Last()->GetTrackIndex() - NotifyTracks[0]->GetTrackIndex();

	float BeginTime = MAX_flt;
	for (TSharedPtr<SBSATaskTrackNode> Node : NotifyNodes)
	{
		float NotifyTime = Node->GetTaskNodeData().GetStartTime();

		if (NotifyTime < BeginTime)
		{
			BeginTime = NotifyTime;
		}
	}

	for (TSharedPtr<SBSATaskTrackNode> Node : NotifyNodes)
	{
		float NotifyTime = Node->GetTaskNodeData().GetStartTime();

		Operation->NodeTimeOffsets.Add(NotifyTime - BeginTime);
		Operation->NodeTimes.Add(NotifyTime);
		Operation->NodeXOffsets.Add(Node->GetNotifyPositionOffset().X);

		Operation->SelectionTimeLength = FMath::Max(Operation->SelectionTimeLength, NotifyTime + Node->GetTaskNodeData().GetDuration() - BeginTime);
	}

	Operation->Construct();

	for (int32 i = 0; i < NotifyTracks.Num(); ++i)
	{
		FTrackClampInfo Info;
		Info.NotifyTrack = NotifyTracks[i];
		const FGeometry& CachedGeometry = Info.NotifyTrack->GetCachedGeometry();
		Info.TrackPos = CachedGeometry.AbsolutePosition.Y;
		Info.TrackSnapTestPos = Info.TrackPos + (CachedGeometry.Size.Y / 2);
		Operation->ClampInfos.Add(Info);
	}

	Operation->CursorDecoratorWindow->SetOpacity(0.5f);
	return Operation;
}

void FBSATrackNodeDragDropOp::OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent)
{
	if (bDropWasHandled == false)
	{
		int32 NumNodes = SelectedNodes.Num();

		for (int32 CurrentNode = 0; CurrentNode < NumNodes; ++CurrentNode)
		{
			TSharedPtr<SBSATaskTrackNode> Node = SelectedNodes[CurrentNode];
			float NodePositionOffset = NodeXOffsets[CurrentNode];
			const FTrackClampInfo& ClampInfo = GetTrackClampInfo(Node->GetScreenPosition());
			ClampInfo.NotifyTrack->HandleNodeDrop(Node, NodePositionOffset);
			Node->DragCancelled();
		}

		RefreshPanelEvent.ExecuteIfBound();
	}

	FDragDropOperation::OnDrop(bDropWasHandled, MouseEvent);
}

void FBSATrackNodeDragDropOp::OnDragged(const class FDragDropEvent& DragDropEvent)
{
	NodeGroupPosition = DragDropEvent.GetScreenSpacePosition() + DragOffset;

	FTrackClampInfo* SelectionPositionClampInfo = &GetTrackClampInfo(DragDropEvent.GetScreenSpacePosition());
	if ((SelectionPositionClampInfo->NotifyTrack->GetTrackIndex() + TrackSpan) >= ClampInfos.Num())
	{
		SelectionPositionClampInfo = &ClampInfos[ClampInfos.Num() - TrackSpan - 1];
	}

	const FGeometry& TrackGeom = SelectionPositionClampInfo->NotifyTrack->GetCachedGeometry();
	const FTrackScaleInfo& TrackScaleInfo = SelectionPositionClampInfo->NotifyTrack->GetCachedScaleInfo();

	FVector2D SelectionBeginPosition = TrackGeom.LocalToAbsolute(TrackGeom.AbsoluteToLocal(NodeGroupPosition) + SelectedNodes[0]->GetNotifyPositionOffset());

	float LocalTrackMin = TrackScaleInfo.InputToLocalX(0.0f);
	float LocalTrackMax = TrackScaleInfo.InputToLocalX(ViewPlayLength);
	float LocalTrackWidth = LocalTrackMax - LocalTrackMin;

	float SnapMovement = 0.0f;
	float SelectionBeginLocalPositionX = TrackGeom.AbsoluteToLocal(SelectionBeginPosition).X;
	const float ClampedEnd = FMath::Clamp(SelectionBeginLocalPositionX + NodeGroupSize.X, LocalTrackMin, LocalTrackMax);
	const float ClampedBegin = FMath::Clamp(SelectionBeginLocalPositionX, LocalTrackMin, LocalTrackMax);
	if (ClampedBegin > SelectionBeginLocalPositionX)
	{
		SelectionBeginLocalPositionX = ClampedBegin;
	}
	else if (ClampedEnd < SelectionBeginLocalPositionX + NodeGroupSize.X)
	{
		SelectionBeginLocalPositionX = ClampedEnd - NodeGroupSize.X;
	}

	SelectionBeginPosition.X = TrackGeom.LocalToAbsolute(FVector2D(SelectionBeginLocalPositionX, 0.0f)).X;

	bool bSnapped = false;
	for (int32 NodeIdx = 0; NodeIdx < SelectedNodes.Num() && !bSnapped; ++NodeIdx)
	{
		TSharedPtr<SBSATaskTrackNode> CurrentNode = SelectedNodes[NodeIdx];

		const FTrackClampInfo& NodeClamp = GetTrackClampInfo(CurrentNode->GetScreenPosition());

		FVector2D EventPosition = SelectionBeginPosition + FVector2D(TrackScaleInfo.PixelsPerInput * NodeTimeOffsets[NodeIdx], 0.0f);

		SelectionBeginPosition.Y = SelectionPositionClampInfo->TrackPos - 1.0f;
	}

	SelectionBeginPosition.X += SnapMovement;

	CurrentDragXPosition = TrackGeom.AbsoluteToLocal(FVector2D(SelectionBeginPosition.X, 0.0f)).X;

	CursorDecoratorWindow->MoveWindowTo(TrackGeom.LocalToAbsolute(TrackGeom.AbsoluteToLocal(SelectionBeginPosition) - SelectedNodes[0]->GetNotifyPositionOffset()));
	NodeGroupPosition = SelectionBeginPosition;
}

FText FBSATrackNodeDragDropOp::GetHoverText() const
{
	FText HoverText = LOCTEXT("Invalid", "Invalid");

	if (SelectedNodes[0].IsValid())
	{
		HoverText = FText::FromString(SelectedNodes[0]->GetTaskNodeData().GetTaskName());
	}

	return HoverText;
}

FBSATrackNodeDragDropOp::FTrackClampInfo& FBSATrackNodeDragDropOp::GetTrackClampInfo(const FVector2D NodePos)
{
	int32 ClampInfoIndex = 0;
	int32 SmallestNodeTrackDist = FMath::Abs(ClampInfos[0].TrackSnapTestPos - NodePos.Y);
	for (int32 i = 0; i < ClampInfos.Num(); ++i)
	{
		int32 Dist = FMath::Abs(ClampInfos[i].TrackSnapTestPos - NodePos.Y);
		if (Dist < SmallestNodeTrackDist)
		{
			SmallestNodeTrackDist = Dist;
			ClampInfoIndex = i;
		}
	}

	return ClampInfos[ClampInfoIndex];
}






FBSAExtraTrackNodeDragDropOp::FBSAExtraTrackNodeDragDropOp(float& InCurrentDragXPosition) :SelectionTimeLength(0.0f), CurrentDragXPosition(InCurrentDragXPosition)
{

}

TSharedRef<FBSAExtraTrackNodeDragDropOp> FBSAExtraTrackNodeDragDropOp::New
(
	TArray<TSharedPtr<SBSAExtraTrackNode>> NotifyNodes, TSharedPtr<SWidget> Decorator,
	const TArray<TSharedPtr<SBSAExtraTrackTimeline>>& NotifyTracks, float InViewPlayLength,
	const FVector2D& CursorPosition, const FVector2D& SelectionScreenPosition,
	const FVector2D& SelectionSize, float& CurrentDragXPosition, FRefreshPanel& RefreshPanel
)
{
	TSharedRef<FBSAExtraTrackNodeDragDropOp> Operation = MakeShareable(new FBSAExtraTrackNodeDragDropOp(CurrentDragXPosition));
	Operation->ViewPlayLength = MAX_FLT;
	Operation->RefreshPanelEvent = RefreshPanel;

	Operation->NodeGroupPosition = SelectionScreenPosition;
	Operation->NodeGroupSize = SelectionSize;
	Operation->DragOffset = SelectionScreenPosition - CursorPosition;
	Operation->Decorator = Decorator;
	Operation->SelectedNodes = NotifyNodes;
	Operation->TrackSpan = 0;

	float BeginTime = MAX_flt;
	for (TSharedPtr<SBSAExtraTrackNode> Node : NotifyNodes)
	{
		float NotifyTime = Node->GetNodeStartTime();

		if (NotifyTime < BeginTime)
		{
			BeginTime = NotifyTime;
		}
	}

	for (TSharedPtr<SBSAExtraTrackNode> Node : NotifyNodes)
	{
		float NotifyTime = Node->GetNodeStartTime();

		Operation->NodeTimeOffsets.Add(NotifyTime - BeginTime);
		Operation->NodeTimes.Add(NotifyTime);
		Operation->NodeXOffsets.Add(Node->GetNotifyPositionOffset().X);

		Operation->SelectionTimeLength = FMath::Max(Operation->SelectionTimeLength, NotifyTime + Node->GetNodeDuration() - BeginTime);
	}

	Operation->Construct();

	for (int32 i = 0; i < NotifyTracks.Num(); ++i)
	{
		FTrackClampInfo Info;
		Info.NotifyTrack = NotifyTracks[i];
		const FGeometry& CachedGeometry = Info.NotifyTrack->GetCachedGeometry();
		Info.TrackPos = CachedGeometry.AbsolutePosition.Y;
		Info.TrackSnapTestPos = Info.TrackPos + (CachedGeometry.Size.Y / 2);
		Operation->ClampInfos.Add(Info);
	}

	Operation->CursorDecoratorWindow->SetOpacity(0.5f);
	return Operation;
}

void FBSAExtraTrackNodeDragDropOp::OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent)
{
	if (bDropWasHandled == false)
	{
		int32 NumNodes = SelectedNodes.Num();

		for (int32 CurrentNode = 0; CurrentNode < NumNodes; ++CurrentNode)
		{
			TSharedPtr<SBSAExtraTrackNode> Node = SelectedNodes[CurrentNode];
			float NodePositionOffset = NodeXOffsets[CurrentNode];
			const FTrackClampInfo& ClampInfo = GetTrackClampInfo(Node->GetScreenPosition());
			ClampInfo.NotifyTrack->HandleNodeDrop(Node, NodePositionOffset);
			Node->DragCancelled();
		}

		RefreshPanelEvent.ExecuteIfBound();
	}

	FDragDropOperation::OnDrop(bDropWasHandled, MouseEvent);
}

void FBSAExtraTrackNodeDragDropOp::OnDragged(const class FDragDropEvent& DragDropEvent)
{
	NodeGroupPosition = DragDropEvent.GetScreenSpacePosition() + DragOffset;

	FTrackClampInfo* SelectionPositionClampInfo = &GetTrackClampInfo(DragDropEvent.GetScreenSpacePosition());
	if (TrackSpan >= ClampInfos.Num())
	{
		SelectionPositionClampInfo = &ClampInfos[ClampInfos.Num() - TrackSpan - 1];
	}

	const FGeometry& TrackGeom = SelectionPositionClampInfo->NotifyTrack->GetCachedGeometry();
	const FTrackScaleInfo& TrackScaleInfo = SelectionPositionClampInfo->NotifyTrack->GetCachedScaleInfo();

	FVector2D SelectionBeginPosition = TrackGeom.LocalToAbsolute(TrackGeom.AbsoluteToLocal(NodeGroupPosition) + SelectedNodes[0]->GetNotifyPositionOffset());

	float LocalTrackMin = TrackScaleInfo.InputToLocalX(0.0f);
	float LocalTrackMax = TrackScaleInfo.InputToLocalX(ViewPlayLength);
	float LocalTrackWidth = LocalTrackMax - LocalTrackMin;

	float SnapMovement = 0.0f;
	float SelectionBeginLocalPositionX = TrackGeom.AbsoluteToLocal(SelectionBeginPosition).X;
	const float ClampedEnd = FMath::Clamp(SelectionBeginLocalPositionX + NodeGroupSize.X, LocalTrackMin, LocalTrackMax);
	const float ClampedBegin = FMath::Clamp(SelectionBeginLocalPositionX, LocalTrackMin, LocalTrackMax);
	if (ClampedBegin > SelectionBeginLocalPositionX)
	{
		SelectionBeginLocalPositionX = ClampedBegin;
	}
	else if (ClampedEnd < SelectionBeginLocalPositionX + NodeGroupSize.X)
	{
		SelectionBeginLocalPositionX = ClampedEnd - NodeGroupSize.X;
	}

	SelectionBeginPosition.X = TrackGeom.LocalToAbsolute(FVector2D(SelectionBeginLocalPositionX, 0.0f)).X;

	bool bSnapped = false;
	for (int32 NodeIdx = 0; NodeIdx < SelectedNodes.Num() && !bSnapped; ++NodeIdx)
	{
		TSharedPtr<SBSAExtraTrackNode> CurrentNode = SelectedNodes[NodeIdx];

		const FTrackClampInfo& NodeClamp = GetTrackClampInfo(CurrentNode->GetScreenPosition());

		FVector2D EventPosition = SelectionBeginPosition + FVector2D(TrackScaleInfo.PixelsPerInput * NodeTimeOffsets[NodeIdx], 0.0f);

		SelectionBeginPosition.Y = SelectionPositionClampInfo->TrackPos - 1.0f;
	}

	SelectionBeginPosition.X += SnapMovement;

	CurrentDragXPosition = TrackGeom.AbsoluteToLocal(FVector2D(SelectionBeginPosition.X, 0.0f)).X;

	CursorDecoratorWindow->MoveWindowTo(TrackGeom.LocalToAbsolute(TrackGeom.AbsoluteToLocal(SelectionBeginPosition) - SelectedNodes[0]->GetNotifyPositionOffset()));
	NodeGroupPosition = SelectionBeginPosition;
}

FText FBSAExtraTrackNodeDragDropOp::GetHoverText() const
{
	FText HoverText = LOCTEXT("Invalid", "Invalid");

	if (SelectedNodes[0].IsValid())
	{
		HoverText = SelectedNodes[0]->GetNodeName();
	}

	return HoverText;
}

FBSAExtraTrackNodeDragDropOp::FTrackClampInfo& FBSAExtraTrackNodeDragDropOp::GetTrackClampInfo(const FVector2D NodePos)
{
	int32 ClampInfoIndex = 0;
	int32 SmallestNodeTrackDist = FMath::Abs(ClampInfos[0].TrackSnapTestPos - NodePos.Y);
	for (int32 i = 0; i < ClampInfos.Num(); ++i)
	{
		int32 Dist = FMath::Abs(ClampInfos[i].TrackSnapTestPos - NodePos.Y);
		if (Dist < SmallestNodeTrackDist)
		{
			SmallestNodeTrackDist = Dist;
			ClampInfoIndex = i;
		}
	}

	return ClampInfos[ClampInfoIndex];
}

#undef LOCTEXT_NAMESPACE
