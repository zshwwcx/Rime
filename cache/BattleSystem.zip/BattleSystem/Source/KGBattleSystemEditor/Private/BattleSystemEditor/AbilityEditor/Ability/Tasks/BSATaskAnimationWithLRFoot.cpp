#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskAnimationWithLRFoot.h"

#include "UObject/ObjectSaveContext.h"

#include "Components/SkeletalMeshComponent.h"
#include "Animation/AnimInstance.h"
#include "BattleSystem/BSFunctionLibrary.h"
#include "BattleSystem/BSBeatenPerformanceAsset.h"


void UBSATPlayAnimationWithLRFoot::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	InOutList.AddUnique(MontageAssetRightFoot.ToString());
}