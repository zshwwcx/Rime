#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"

#include "BattleSystem/BSSettings.h"
#include "BattleSystem/BSMacroDefinition.h"
#include "BattleSystemEditor/BSEditorFunctionLibrary.h"
#include "BattleSystemEditor/AbilityEditor/BSAJsonExporter.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"



#pragma region Important
EBSATaskLife UBSATaskBase::GetLifeType()
{
	return LifeType;
}

float UBSATaskBase::GetDuration()
{
	switch (LifeType)
	{
	case EBSATaskLife::TL_Instant:
		return 0.0f;
		break;
	case EBSATaskLife::TL_ByController:
		return 1000000000.0f;
		break;
	case EBSATaskLife::TL_DurAndController:
	case EBSATaskLife::TL_ForceDuration:
		return Duration;
		break;
	}

	return 0.0f;
}

void UBSATaskBase::GetReferenceResources(TArray<FString>& InOutList)
{
	GetBPReferenceResources(InOutList, InOutList);
}

#pragma endregion Important



#pragma region Editor
#if WITH_EDITOR
void UBSATaskBase::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

bool UBSATaskBase::IsEqual(UBSATaskBase* OtherTask)
{
	if (OtherTask && this && (OtherTask->GetClass() == this->GetClass()))
	{
		// 遍历反射数据
		for (TFieldIterator<FProperty> PropIt(this->GetClass()); PropIt; ++PropIt)
		{
			FProperty* Property = *PropIt;
			if (Property)
			{
				ANSICHAR* ThisValuePtr = Property->ContainerPtrToValuePtr<ANSICHAR>(this);
				ANSICHAR* OtherValuePtr = Property->ContainerPtrToValuePtr<ANSICHAR>(OtherTask);

				FString ThisValue;	ThisValue.AppendChars(ThisValuePtr, Property->GetSize());
				FString OtherValue;	OtherValue.AppendChars(OtherValuePtr, Property->GetSize());

				if (ThisValue.Equals(OtherValue))
					continue;
			}

			return false;
		}
	}
	else
		return false;

	return true;
}

void UBSATaskBase::CopyDataFromOther(UBSATaskBase* OtherTask)
{
	UBSEditorFunctionLibrary::CopyObject(this, OtherTask);
}

FText UBSATaskBase::GetTaskName() const
{
	if (TaskDisplayName.IsEmpty())
	{
		FString OriginName = this->GetName();
		OriginName = OriginName.Replace(TEXT("BPT_"), TEXT(""));
		OriginName = OriginName.Replace(TEXT("_C"), TEXT(""));
		OriginName = OriginName.Replace(TEXT("_"), TEXT(":"));

		return FText::FromString(OriginName);
	}

	return TaskDisplayName;
}

void UBSATaskBase::SetTaskName(FText NewName)
{
	TaskDisplayName = NewName;
}

bool UBSATaskBase::CanChangeDuration() const
{
	if (LifeType == EBSATaskLife::TL_ForceDuration || LifeType == EBSATaskLife::TL_DurAndController)
		return true;
	else
		return false;
}

// 设置Task的生命周期类型
void UBSATaskBase::SetLifeType(EBSATaskLife InNewType)
{
	LifeType = InNewType;
}

// 设置Task的持续时长
void UBSATaskBase::SetDuration(float InDuration)
{
	if (CanChangeDuration())
	{
		Duration = FMath::Max(0.0f, InDuration);

		CallPostEditChangeProperty(TEXT("Duration"));
	}
}

void UBSATaskBase::CallPostEditChangeProperty(FName InPropertyName)
{
	for (TFieldIterator<FProperty> It(GetClass()); It; ++It)
	{
		if (It->GetFName().IsEqual(InPropertyName))
		{
			FPropertyChangedEvent PC(*It);
			PostEditChangeProperty(PC);
			break;
		}
	}

	GetPackage()->MarkPackageDirty();
}

#endif
#pragma endregion Editor








UBSATask::UBSATask()
{
	EventTaskMap.Add(TEXT("Start"), FBSATaskSelectorList());
	EventTaskMap.Add(TEXT("End"), FBSATaskSelectorList());
}



#pragma region Important
float UBSATask::GetDuration()
{
	switch (LifeType)
	{
	case EBSATaskLife::TL_Instant:
		return 0.001f;
		break;
	case EBSATaskLife::TL_ByController:
	{
		if (UBSAAsset* Asset = Cast<UBSAAsset>(GetOuter()))
		{
			if (FBSATaskSection* Section = Asset->GetSectionPointerByTask(this))
			{
				return Section->SectionDuration - StartTime;
			}
		}
	}
		break;
	case EBSATaskLife::TL_DurAndController:
	case EBSATaskLife::TL_ForceDuration:
		return Duration;
		break;
	}

	return 0.0f;
}

EBSATaskNet UBSATask::GetNetType() const
{ 
	return NetType; 
}

int32 UBSATask::GetTargetTypes() const
{ 
	return TargetTypes; 
}

void UBSATask::GetCollisionTargetInfos(TArray<FBSATaskInputInfo>& OutInfos) const
{
	OutInfos.Empty();
	OutInfos.Append(CollisionTargetInfos);
}

float UBSATask::GetStartTime() const
{ 
	return StartTime; 
}

int32 UBSATask::GetTriggerMethod() const
{
	return TriggerMethod;
}

bool UBSATask::GetEventTaskList(const FName& InEventName, FBSATaskSelectorList& OutTaskList)
{ 
	OutTaskList.SelectedTaskList.Empty();

	if (FBSATaskSelectorList* List = EventTaskMap.Find(InEventName))
	{
		OutTaskList.SelectedTaskList.Append(List->SelectedTaskList);

		return true;
	}

	return false; 
}

#pragma endregion Important



#pragma region Data
void UBSATask::FixTaskListDependency(TArray<UBSATask*>& InOutTaskList, const TArray<UBSATask*>& InTemplateTaskList)
{
	// 两个数组的大小不一致，则直接返回
	if (InOutTaskList.Num() != InTemplateTaskList.Num())
	{
		return;
	}

	// 对应元素的类型不一致，则直接返回
	for (int32 i = 0; i < InTemplateTaskList.Num(); i++)
	{
		if (InTemplateTaskList[i]->GetClass() != InOutTaskList[i]->GetClass())
		{
			return;
		}
	}

	// 根据模板列表，修复Task的依赖关系
	for (int32 i = 0; i < InTemplateTaskList.Num(); i++)
	{
		// 修复CollisionTargetInfos
		InOutTaskList[i]->CollisionTargetInfos.Empty();
		for (int32 j = 0; j < InTemplateTaskList[i]->CollisionTargetInfos.Num(); j++)
		{
			InOutTaskList[i]->CollisionTargetInfos.Add(FBSATaskInputInfo());
			InOutTaskList[i]->CollisionTargetInfos.Last().DataDesc = InTemplateTaskList[i]->CollisionTargetInfos[j].DataDesc;
#if WITH_EDITOR
			InOutTaskList[i]->CollisionTargetInfos.Last().DisplayName = InTemplateTaskList[i]->CollisionTargetInfos[j].DisplayName;
			InOutTaskList[i]->CollisionTargetInfos.Last().DataType = InTemplateTaskList[i]->CollisionTargetInfos[j].DataType;
			InOutTaskList[i]->CollisionTargetInfos.Last().StructType = InTemplateTaskList[i]->CollisionTargetInfos[j].StructType;
			InOutTaskList[i]->CollisionTargetInfos.Last().ProduceDataTask.Owner = InOutTaskList[i];
			InOutTaskList[i]->CollisionTargetInfos.Last().GetRandID();
#endif

			int32 FindIndex = InTemplateTaskList.Find(Cast<UBSATask>(InTemplateTaskList[i]->CollisionTargetInfos[j].ProduceDataTask.SelectedTask));
			if (FindIndex >= 0)
			{
				InOutTaskList[i]->CollisionTargetInfos[j].ProduceDataTask.SelectedTask = InOutTaskList[FindIndex];
			}
		}

		// 修复InputDatas
		InOutTaskList[i]->InputDatas.Empty();
		for (int32 j = 0; j < InTemplateTaskList[i]->InputDatas.Num(); j++)
		{
			InOutTaskList[i]->InputDatas.Add(FBSATaskInputInfo());
			InOutTaskList[i]->InputDatas.Last().DataDesc = InTemplateTaskList[i]->InputDatas[j].DataDesc;
#if WITH_EDITOR
			InOutTaskList[i]->InputDatas.Last().DisplayName = InTemplateTaskList[i]->InputDatas[j].DisplayName;
			InOutTaskList[i]->InputDatas.Last().DataType = InTemplateTaskList[i]->InputDatas[j].DataType;
			InOutTaskList[i]->InputDatas.Last().StructType = InTemplateTaskList[i]->InputDatas[j].StructType;
			InOutTaskList[i]->InputDatas.Last().ProduceDataTask.Owner = InOutTaskList[i];
			InOutTaskList[i]->InputDatas.Last().GetRandID();
#endif

			int32 FindIndex = InTemplateTaskList.Find(Cast<UBSATask>(InTemplateTaskList[i]->InputDatas[j].ProduceDataTask.SelectedTask));
			if (FindIndex >= 0)
			{
				InOutTaskList[i]->InputDatas[j].ProduceDataTask.SelectedTask = InOutTaskList[FindIndex];
			}
		}

		// 修复EventTaskMap
		InOutTaskList[i]->EventTaskMap.Empty();
		for (TMap<FName, FBSATaskSelectorList>::TIterator It(InTemplateTaskList[i]->EventTaskMap); It; ++It)
		{
			InOutTaskList[i]->EventTaskMap.Add(It->Key, FBSATaskSelectorList());

			if (FBSATaskSelectorList* DestTaskList = InOutTaskList[i]->EventTaskMap.Find(It->Key))
			{
				for (int32 j = 0; j < It->Value.SelectedTaskList.Num(); j++)
				{
					int32 FindIndex = InTemplateTaskList.Find(Cast<UBSATask>(It->Value.SelectedTaskList[j].SelectedTask));
					if (FindIndex >= 0)
					{
						DestTaskList->SelectedTaskList.AddZeroed();
						DestTaskList->SelectedTaskList.Last().SelectedTask = InOutTaskList[FindIndex];
#if WITH_EDITOR
						DestTaskList->SelectedTaskList.Last().Owner = InOutTaskList[i];
#endif
					}
				}
			}
		}
	}
}

#pragma endregion Data



#pragma region Editor
#if WITH_EDITOR
void UBSATask::PreSave(FObjectPreSaveContext SaveContext)
{
	UpdateGUIDMap();

	ClassType = GetClass();

	// 检查bNetMulticastEvent选项
	bNetMulticastEvent = false;
	if (NetType == EBSATaskNet::TN_ServerOnly)
	{
		for (TMap<FName, FBSATaskSelectorList>::TIterator It(EventTaskMap); It; ++It)
		{
			FBSATaskSelectorList& List = It->Value;

			for (TArray<FBSATaskSelector>::TIterator It1(List.SelectedTaskList); It1; ++It1)
			{
				if (UBSATask* Task = Cast<UBSATask>(It1->SelectedTask))
				{
					if (Task->NetType > EBSATaskNet::TN_ServerOnly)
					{
						bNetMulticastEvent = true;

						break;
					}
				}
			}
		}
	}

	// 通知蓝图进行预保存
	ReceivePreSave();

	Super::PreSave(SaveContext);
}

void UBSATask::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	// 对StartTime进行规范化
	StartTime = FMath::RoundToFloat(StartTime * BSFrameRate) / BSFrameRate;
	// 自动更新时长
	if (PropertyChangedEvent.Property->GetName() == TEXT("LifeType"))
	{
		if (LifeType == EBSATaskLife::TL_ByController)
		{
			Duration = StageDuration - StartTime;
		}
	}
	// 对Duration进行规范化
	Duration = FMath::RoundToFloat(Duration * BSFrameRate) / BSFrameRate;

	// 刷新Task选择器
	RefreshTaskSelector();

	// 通知蓝图，属性发生了变更
	ReceivePostEditChangeProperty(PropertyChangedEvent.Property->GetName());

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATask::UpdateGUIDMap()
{
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

	TArray<UStruct*> SpecialType;
	SpecialType.Add(FRuntimeFloatCurve::StaticStruct());
	SpecialType.Add(FKGRemapFloatCurve::StaticStruct());
	SpecialType.Add(FRuntimeVectorCurve::StaticStruct());
	SpecialType.Add(FKGRemapVectorCurve::StaticStruct());
	SpecialType.Add(FRuntimeCurveLinearColor::StaticStruct());
	SpecialType.Add(FKGRemapColorCurve::StaticStruct());

	UBSJsonExporter* JsonExporter = NewObject<UBSJsonExporter>(GetTransientPackage(), UBSAJsonExporter::StaticClass());
	UBSEditorFunctionLibrary::ExportObjectToJson(this, JsonObject, SpecialType, JsonExporter);

	JsonExporter->MarkAsGarbage();
	JsonObject.Reset();
}

void UBSATask::CopyDataFromOther(UBSATaskBase* OtherTask)
{
	Super::CopyDataFromOther(OtherTask);

	for (int32 i = 0; i < CollisionTargetInfos.Num(); ++i)
	{
		CollisionTargetInfos[i].ProduceDataTask.Owner = this;
		CollisionTargetInfos[i].ProduceDataTask.SelectedTask = nullptr;
	}

	for (int32 i = 0; i < InputDatas.Num(); ++i)
	{
		InputDatas[i].ProduceDataTask.Owner = this;
		InputDatas[i].ProduceDataTask.SelectedTask = nullptr;
	}

	for (TMap<FName, FBSATaskSelectorList>::TIterator It(EventTaskMap); It; ++It)
	{
		It->Value.SelectedTaskList.Empty();
	}

	// 清空GUID缓存表
	GUIDMap.Empty();
}

void UBSATask::CleanInvalidDependencies()
{
	if (UBSAAsset* OwnerAsset = Cast<UBSAAsset>(GetOuter()))
	{
		if (FBSATaskSection* CurSectionPtr = OwnerAsset->GetSectionPointerByTask(this))
		{
			for (TArray<FBSATaskInputInfo>::TIterator It(CollisionTargetInfos); It; ++It)
			{
				if (It->ProduceDataTask.SelectedTask)
				{
					FBSATaskSection* TarSectionPtr = OwnerAsset->GetSectionPointerByTask(Cast<UBSATask>(It->ProduceDataTask.SelectedTask));

					if (!TarSectionPtr || TarSectionPtr != CurSectionPtr)
					{
						It.RemoveCurrent();
					}
				}
				else
				{
					It.RemoveCurrent();
				}
			}

			for (TMap<FName, FBSATaskSelectorList>::TIterator It(EventTaskMap); It; ++It)
			{
				for (TArray<FBSATaskSelector>::TIterator Loop(It->Value.SelectedTaskList); Loop; ++Loop)
				{
					if (Loop->SelectedTask)
					{
						FBSATaskSection* TarSectionPtr = OwnerAsset->GetSectionPointerByTask(Cast<UBSATask>(Loop->SelectedTask));

						if (!TarSectionPtr || TarSectionPtr != CurSectionPtr)
						{
							Loop.RemoveCurrent();
						}
					}
					else
					{
						Loop.RemoveCurrent();
					}
				}
			}
		}	

		OwnerAsset->GetPackage()->MarkPackageDirty();
	}
}

void UBSATask::RefreshTaskSelector()
{
	if ((TargetTypes & (1 << (int32)EBSATaskTarget::TT_CollisionResults)) == 0)
	{
		bUseCollisionTarget = false;
		CollisionTargetInfos.Empty();
	}
	else
	{
		bUseCollisionTarget = true;
		if (CollisionTargetInfos.Num() <= 0)
		{
			CollisionTargetInfos.AddZeroed();
		}
	}

	// 刷新碰撞输入信息
	for (int32 i = 0; i < CollisionTargetInfos.Num(); ++i)
	{
		CollisionTargetInfos[i].ProduceDataTask.Owner = this;
		CollisionTargetInfos[i].DisplayName = FName(TEXT("CollisionResults") + FString::FromInt(i + 1));
		if (CollisionTargetInfos[i].DataDesc.IsNone())
		{
			CollisionTargetInfos[i].DataDesc = TEXT("CollisionResults");
		}

		CollisionTargetInfos[i].GetRandID();
		CollisionTargetInfos[i].DataType = EBSDataType::DT_Struct;
		CollisionTargetInfos[i].StructType = FBSATaskHitResults::StaticStruct();
	}

	// 刷新其他输入信息
	for (int32 i = 0; i < InputDatas.Num(); ++i)
	{
		InputDatas[i].GetRandID();
		InputDatas[i].ProduceDataTask.Owner = this;
	}

	// 刷新输出信息
	for (int32 i = 0; i < OutputDatas.Num(); ++i)
	{
		OutputDatas[i].GetRandID();
	}

	// 刷新Task事件
	for (TMap<FName, FBSATaskSelectorList>::TIterator It(EventTaskMap); It; ++It)
	{
		for (int32 i = 0; i < It->Value.SelectedTaskList.Num(); ++i)
		{
			It->Value.SelectedTaskList[i].Owner = this;
		}
	}
}

void UBSATask::SetStartTime(float Time)
{
	StartTime = FMath::Max(0.0f, Time);

	CallPostEditChangeProperty(TEXT("StartTime"));
}

void UBSATask::SetTriggerMethod(int32 NewMethod)
{
	TriggerMethod = NewMethod;
}

void UBSATask::SetNetType(EBSATaskNet NewNetType)
{
	NetType = NewNetType;
}

void UBSATask::SetIndex(int32 InIndex)
{
	Index = InIndex;
}

void UBSATask::SetCollisionTargetInfo(int32 InIndex, FName DataTag, UBSATask* DataOwner)
{
	if (CollisionTargetInfos.IsValidIndex(InIndex))
	{
		CollisionTargetInfos[InIndex].DataDesc = DataTag;
		CollisionTargetInfos[InIndex].ProduceDataTask.SelectedTask = DataOwner;
	}
}

void UBSATask::SetInputDataInfo(int32 InIndex, FName DataTag, UBSATask* DataOwner)
{
	UBSATask* Task = Cast<UBSATask>(GetClass()->GetDefaultObject());

	if (InputDatas.IsValidIndex(InIndex))
	{
		if (!DataTag.IsNone())
		{
			InputDatas[InIndex].DataDesc = DataTag;
		}
		else if (Task && Task->InputDatas.IsValidIndex(InIndex))
		{
			InputDatas[InIndex].DataDesc = Task->InputDatas[InIndex].DataDesc;
		}
		InputDatas[InIndex].ProduceDataTask.SelectedTask = DataOwner;
	}
}

#endif
#pragma endregion Editor
