#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackOutliner.h"
#include "Framework/Application/SlateApplication.h"

#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineDragDropOp.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineTrackPanel.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorUtilities.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineController.h"



#define LOCTEXT_NAMESPACE "SBSATaskTrackOutliner"



void SBSATaskTrackOutliner::Construct(const FArguments& InArgs, const TSharedPtr<FTimelineController>& InTimelineController, UBSATask* InTask)
{
	TimelineController = StaticCastSharedPtr<FBSATimelineController>(InTimelineController);

	CachedTask = InTask;

	TrackPanelArea = InArgs._TrackPanelArea;
	InlineEditableTextBlock = InArgs._InlineEditableTextBlock;

	this->ChildSlot
	[
		TrackPanelArea.ToSharedRef()
	];

	UpdateLayout();
}


void SBSATaskTrackOutliner::UpdateLayout()
{
	TSharedPtr<SHorizontalBox> ParentOutlinerWidget =
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.FillWidth(1.0f)
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Left)
		.Padding(20.0f, 0.0f, 0.0f, 0.0f)
		[
			InlineEditableTextBlock.ToSharedRef()
		];
	
	TrackPanelArea->SetContent(ParentOutlinerWidget.ToSharedRef());
}

FReply SBSATaskTrackOutliner::OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	bool bWasDropHandled = false;

	TSharedPtr<FDragDropOperation> Operation = DragDropEvent.GetOperation();
	if (!Operation.IsValid())
	{

	}
	else if (Operation->IsOfType<FBSATrackDragDropOp>())
	{
		const auto& FrameDragDropOp = StaticCastSharedPtr<FBSATrackDragDropOp>(Operation);
		FrameDragDropOp->ChangeTaskTrackPosition(CachedTask.Get());
		bWasDropHandled = true;
	}
	
	return bWasDropHandled ? FReply::Handled() : FReply::Unhandled();
}

FReply SBSATaskTrackOutliner::OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton))
	{
		TSharedRef<SOverlay> NodeDragDecoratorOverlay = SNew(SOverlay);
		TSharedRef<SBorder> NodeDragDecorator = 
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
			.BorderBackgroundColor(FLinearColor(.0f, 1.f, .0f))
			[
				NodeDragDecoratorOverlay
			];

		FVector2D OffsetFromFirst(2, 2);

		NodeDragDecoratorOverlay->
			AddSlot()
			.Padding(FMargin(OffsetFromFirst.X, OffsetFromFirst.Y, 0.0f, 0.0f))
			[
				SharedThis(this)
			];


		return FReply::Handled().BeginDragDrop(FBSATrackDragDropOp::New(TimelineController.Pin().ToSharedRef(), CachedTask.Get(), NodeDragDecorator));
	}

	return FReply::Unhandled();
}

FReply SBSATaskTrackOutliner::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		return FReply::Handled().DetectDrag(SharedThis(this), EKeys::LeftMouseButton);
	}

	return FReply::Unhandled();
}



#undef LOCTEXT_NAMESPACE
