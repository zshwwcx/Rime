#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"
#include "GameFramework/WorldSettings.h"
#include "BattleSystemEditor/BSEditorFunctionLibrary.h"
#include "string"
#include "BattleSystem/Ability/BSAEnums.h"
#include "BattleSystem/BSMacroDefinition.h"
#include "BattleSystemEditor/AbilityEditor/Preview/BSAPreviewGameMode.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorDelegates.h"

#if WITH_EDITOR
#include "Editor.h"
#endif

UBSASkillAsset::UBSASkillAsset(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
#if WITH_EDITOR
	Sections.Add(FBSATaskSection(TEXT("主要任务列表")));
#endif
}



#pragma region API
#if WITH_EDITOR
void UBSASkillAsset::InitByEditor(UObject* WorldContext)
{
	if (!bHasInit && WorldContext && WorldContext->GetWorld())
	{
		UWorld* World = WorldContext->GetWorld();

		if (World->GetWorldSettings() && World->GetWorldSettings()->DefaultGameMode)
		{
			UClass* DGMClass = World->GetWorldSettings()->DefaultGameMode;

			if (const ABSAPreviewGameMode* GameMode = GetDefault<ABSAPreviewGameMode>(DGMClass))
			{
				for (int32 i = 0; i < GameMode->SkillDefaultTaskList.TaskList.Num(); ++i)
				{
					if (GameMode->SkillDefaultTaskList.TaskList[i])
					{
						if (UBSATask* NewTask = NewObject<UBSATask>(this, GameMode->SkillDefaultTaskList.TaskList[i]->GetClass(), NAME_None, RF_Transactional, GameMode->SkillDefaultTaskList.TaskList[i]))
						{
							AddTask(0, 0, *NewTask);
						}
					}
				}
			}
		}
	}

	Super::InitByEditor(WorldContext);
}

void UBSASkillAsset::PreEditChange(FProperty* PropertyThatWillChange)
{
	RedoIndex = GEditor->BeginTransaction(NSLOCTEXT("BSASkillAsset", "ProportyChange", "ProportyWillChange"));
	this->Modify();
	Super::PreEditChange(PropertyThatWillChange);
}

void UBSASkillAsset::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	
	if (RedoIndex != -1)
	{
		GEditor->EndTransaction();
		RedoIndex = -1;
	}
	SkillDuration = FMath::RoundToFloat(SkillDuration * BSFrameRate) / BSFrameRate;

	if (Sections.IsValidIndex(0))
	{
		Sections[0].LoopTime = 1;
		Sections[0].SectionDuration = SkillDuration;
	}

	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("SkillType")))
	{
		if (SkillType == EBSASkillType::ST_Passive)
		{
			bNeedReplicated = false;
		}
	}
	FBSAEditorDelegates::SkillAssetPropertyChange.Broadcast(PropertyChangedEvent.GetPropertyName());
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSASkillAsset::ChangeSectionName(int32 SectionID, FName NewName)
{
	if (SectionID == 0)
	{
		return;
	}
	else
	{
		Super::ChangeSectionName(SectionID, NewName);
	}
}

void UBSASkillAsset::ChangeSectionLoopTime(int32 SectionID, int32 NewLoop)
{
	if (SectionID == 0)
	{
		return;
	}
	else
	{
		Super::ChangeSectionLoopTime(SectionID, NewLoop);
	}
}

void UBSASkillAsset::ChangeSectionDuration(int32 SectionID, float NewDuration)
{
	if (SectionID == 0)
	{
		return;
	}
	else
	{
		Super::ChangeSectionDuration(SectionID, NewDuration);
	}
}

void UBSASkillAsset::ChangeChantDuration(float NewDuration)
{
	NewDuration = FMath::Max(0.0f, NewDuration);
	ChantDuration = FMath::RoundToFloat(NewDuration * BSFrameRate) / BSFrameRate;
}

void UBSASkillAsset::ChangeComboWindowStart(float NewStart)
{
	NewStart = FMath::Max(0.0f, NewStart);
	ComboWindow.X = FMath::RoundToFloat(NewStart * BSFrameRate) / BSFrameRate;
}

void UBSASkillAsset::ChangeComboWindowDuration(float NewDuration)
{
	NewDuration = FMath::Max(0.0f, NewDuration);
	ComboWindow.Y = FMath::RoundToFloat(NewDuration * BSFrameRate) / BSFrameRate;
}

void UBSASkillAsset::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);

	UBSEditorFunctionLibrary::AutoGenSkillRecoveryStartTime(this);
}

#endif
#pragma endregion API