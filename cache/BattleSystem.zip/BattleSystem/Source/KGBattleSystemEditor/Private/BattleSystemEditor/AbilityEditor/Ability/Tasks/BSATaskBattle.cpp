#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskBattle.h"

#include "3C/Movement/RoleMovementComponentBase.h"

#include "BattleSystem/BSFunctionLibrary.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"
#include "3C/Character/BSUnit.h"
#include "BattleSystem/BSBeatenPerformanceAsset.h"

#if WITH_EDITOR
#include "DrawDebugHelpers.h"
#endif



#pragma region Attack
#if WITH_EDITOR
void UBSATAttack::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("TargetTypes")))
	{
		if (TargetTypes != 16)
		{
			bool flag = false;
			for (int32 i = 0; i < InputDatas.Num(); ++i)
			{
				if (InputDatas[i].StructType == FBSATaskHitResults::StaticStruct())
				{
					flag = true;
					break;
				}
			}

			if (!flag)
			{
				FBSATaskInputInfo NewInfo;
				NewInfo.DisplayName = TEXT("CollisionResults");
				NewInfo.DataType = EBSDataType::DT_Struct;
				NewInfo.StructType = FBSATaskHitResults::StaticStruct();
				NewInfo.DataDesc = TEXT("CollisionResults");

				InputDatas.Add(NewInfo);
			}

			if (TargetTypes == (1 << (int32)EBSATaskTarget::TT_Owner) || 
			TargetTypes == (1 << (int32)EBSATaskTarget::TT_Instigator) || 
			TargetTypes == (1 << (int32)EBSATaskTarget::TT_Trigger) || 
			TargetTypes == (1 << (int32)EBSATaskTarget::TT_CollisionResults) || 
			TargetTypes == ((1 << (int32)EBSATaskTarget::TT_Owner) | (1 << (int32)EBSATaskTarget::TT_CollisionResults)) ||
			TargetTypes == ((1 << (int32)EBSATaskTarget::TT_Instigator) | (1 << (int32)EBSATaskTarget::TT_CollisionResults)) ||
			TargetTypes == ((1 << (int32)EBSATaskTarget::TT_Trigger) | (1 << (int32)EBSATaskTarget::TT_CollisionResults)))
			{
				bNeedFilterTarget = false;
				AttackTargetInfo.TargetCampType = 0;
				AttackTargetInfo.TargetCharacterType = 0;
			}
			else
			{
				if (TargetTypes == (1 << (int32)EBSATaskTarget::TT_AllTeamMember) || TargetTypes == (1 << (int32)EBSATaskTarget::TT_AllGroupMember))
				{
					AttackTargetInfo.TargetCampType = 0;
				}

				bNeedFilterTarget = true;
			}
		}
		else
		{
			bNeedFilterTarget = false;
			AttackTargetInfo.TargetCampType = 0;
			AttackTargetInfo.TargetCharacterType = 0;
		}
	}
}

#endif

#pragma endregion Attack






#pragma region Beaten
#if WITH_EDITOR
void UBSATChangeStagger::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (LifeType == EBSATaskLife::TL_Instant)
	{
		EndStagger = EBSStaggerState::SS_TMax;
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif

#pragma endregion Beaten






#pragma region Ability
void UBSATActivateSkill::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	InOutList.AddUnique(SkillAsset.ToString());
}

void UBSATSetComboWindow::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	for (FBSAComboWindowMsg tComboSetter : ComboWindowSetters)
	{
		InOutList.AddUnique(tComboSetter.SkillID.ToString());
	}
}
#pragma endregion Ability






#pragma region Buff
void UBSATAddBuff::GetReferenceResources(TArray<FString>& InOutList)
{
	Super::GetReferenceResources(InOutList);

	for (int32 i = 0; i < BuffAssets.Num(); ++i)
	{
		InOutList.AddUnique(BuffAssets[i].ToString());
	}
}

#if WITH_EDITOR
void UBSATAddBuff::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	AddLayer.ConfigValue = FMath::Max(1, AddLayer.ConfigValue);
	MaxAddLayer = FMath::Max(1, MaxAddLayer);

	if (TargetTypes == (1 << (int32)EBSATaskTarget::TT_Owner) || 
		TargetTypes == (1 << (int32)EBSATaskTarget::TT_Instigator) || 
		TargetTypes == (1 << (int32)EBSATaskTarget::TT_Trigger) || 
		TargetTypes == (1 << (int32)EBSATaskTarget::TT_CollisionResults) || 
		TargetTypes == ((1 << (int32)EBSATaskTarget::TT_Owner) | (1 << (int32)EBSATaskTarget::TT_CollisionResults)) ||
		TargetTypes == ((1 << (int32)EBSATaskTarget::TT_Instigator) | (1 << (int32)EBSATaskTarget::TT_CollisionResults)) ||
		TargetTypes == ((1 << (int32)EBSATaskTarget::TT_Trigger) | (1 << (int32)EBSATaskTarget::TT_CollisionResults)))
	{
		bNeedFilterTarget = false;
		BuffTargetInfo.TargetCampType = 0;
		BuffTargetInfo.TargetCharacterType = 0;
	}
	else
	{
		if (TargetTypes == (1 << (int32)EBSATaskTarget::TT_AllTeamMember) || TargetTypes == (1 << (int32)EBSATaskTarget::TT_AllGroupMember))
		{
			BuffTargetInfo.TargetCampType = 0;
		}

		bNeedFilterTarget = true;
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}
#endif



#if WITH_EDITOR
void UBSATRemoveBuff::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	for (int32 i = 0; i < DispelLevels.Num(); ++i)
	{
		DispelLevels[i] = FMath::Clamp(DispelLevels[i], 0, 9999);
	}

	if (TargetTypes == (1 << (int32)EBSATaskTarget::TT_Owner) ||
		TargetTypes == (1 << (int32)EBSATaskTarget::TT_Instigator) ||
		TargetTypes == (1 << (int32)EBSATaskTarget::TT_Trigger) ||
		TargetTypes == (1 << (int32)EBSATaskTarget::TT_CollisionResults) ||
		TargetTypes == ((1 << (int32)EBSATaskTarget::TT_Owner) | (1 << (int32)EBSATaskTarget::TT_CollisionResults)) ||
		TargetTypes == ((1 << (int32)EBSATaskTarget::TT_Instigator) | (1 << (int32)EBSATaskTarget::TT_CollisionResults)) ||
		TargetTypes == ((1 << (int32)EBSATaskTarget::TT_Trigger) | (1 << (int32)EBSATaskTarget::TT_CollisionResults)))
	{
		bNeedFilterTarget = false;
		BuffTargetInfo.TargetCampType = 0;
		BuffTargetInfo.TargetCharacterType = 0;
	}
	else
	{
		if (TargetTypes == (1 << (int32)EBSATaskTarget::TT_AllTeamMember) || TargetTypes == (1 << (int32)EBSATaskTarget::TT_AllGroupMember))
		{
			BuffTargetInfo.TargetCampType = 0;
		}

		bNeedFilterTarget = true;
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}
#endif
#pragma endregion Buff
