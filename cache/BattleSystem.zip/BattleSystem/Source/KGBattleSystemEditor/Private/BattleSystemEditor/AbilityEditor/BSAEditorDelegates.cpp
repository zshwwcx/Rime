#include "BattleSystemEditor/AbilityEditor/BSAEditorDelegates.h"



FBSAEditorDelegates::FAddTaskDelegate FBSAEditorDelegates::AddTaskEvent;

FBSAEditorDelegates::FDeleteTaskDelegate FBSAEditorDelegates::DeleteTaskEvent;

FBSAEditorDelegates::FMoveTaskDelegate FBSAEditorDelegates::MoveTaskEvent;

FBSAEditorDelegates::FTaskSelectionChangedDelegate FBSAEditorDelegates::TaskSelectionChangedEvent;

FBSAEditorDelegates::FPreviewStateChanged FBSAEditorDelegates::PreviewStateChangedEvent;

FBSAEditorDelegates::FOnCreatePreviewCameraDelegate FBSAEditorDelegates::OnCreatePreviewCameraEvent;

FBSAEditorDelegates::FStartPlayDelegate FBSAEditorDelegates::StartPlayEvent;

FBSAEditorDelegates::FSetShowCollisionDelegate FBSAEditorDelegates::SetShowCollisionEvent;

FBSAEditorDelegates::FAutoOptimizeDoneDelegate FBSAEditorDelegates::AutoOptimizeDoneDelegate;

FBSAEditorDelegates::FSkillAssetPropertyChange FBSAEditorDelegates::SkillAssetPropertyChange;

FBSAEditorDelegates::FOnInitializeEditorFinishDelegate FBSAEditorDelegates::OnInitializeEditorFinishDelegate;

FBSAEditorDelegates::FOnDestructorEditorDelegate FBSAEditorDelegates::OnDestructorEditorDelegate;
