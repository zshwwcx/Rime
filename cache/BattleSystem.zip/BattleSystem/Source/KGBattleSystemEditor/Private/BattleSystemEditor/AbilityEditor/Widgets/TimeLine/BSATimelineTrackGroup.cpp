#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineTrackGroup.h"
#include "ScopedTransaction.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"

#include "Widgets/SBoxPanel.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Widgets/TimeLineBase/SAnimOutlinerItem.h"
#include "BattleSystemEditor/CustomLayout/SBSTaskGroupPicker.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineTrackPanel.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineController.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorUtilities.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSAGroupTrackOutliner.h"



#define LOCTEXT_NAMESPACE "FBSATimelineTrackGroup"



ANIMTIMELINE_IMPLEMENT_TRACK(FBSATimelineTrackGroup);

FBSATimelineTrackGroup::FBSATimelineTrackGroup
(
	const TSharedRef<FBSATimelineController>& InMode, FBSATaskGroup* InGroupData, 
	const FText& InDisplayName, const FText& InToolTipText
) : FAnimTimelineTrack(InMode, InDisplayName, InToolTipText, true), GroupData(InGroupData)
{
	SetHeight(30.0f);
}

TSharedRef<SWidget> FBSATimelineTrackGroup::GenerateContainerWidgetForOutliner(const TSharedRef<SAnimOutlinerItem>& InRow)
{
	TSharedPtr<SBorder> OuterBorder;
	TSharedPtr<SHorizontalBox> InnerHorizontalBox;
	TSharedRef<SWidget> OutlinerWidget = GenerateStandardOutlinerWidget(InRow, false, OuterBorder, InnerHorizontalBox);

	OuterBorder->SetBorderBackgroundColor(FAppStyle::GetColor("AnimTimeline.Outliner.HeaderColor"));

	// Group的名称
	InnerHorizontalBox->AddSlot()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Left)
		.Padding(2.0f, 1.0f)
		.FillWidth(1.0f)
		[
			SNew(SInlineEditableTextBlock)
			.IsReadOnly(false)
			.Text(this, &FBSATimelineTrackGroup::GetLabel)
			.IsSelected(FIsSelected::CreateLambda([]() { return false; }))
			.OnTextCommitted(this, &FBSATimelineTrackGroup::OnCommitCurveName)
			.HighlightText(InRow->GetHighlightText())
		];

	// Group的下拉菜单
	InnerHorizontalBox->AddSlot()
		.AutoWidth()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		.Padding(OutlinerRightPadding, 1.0f)
		[
			FBSAEditorUtilities::MakeTrackButton
			(
				LOCTEXT("BSATrackGroup", "Actions"),
				FOnGetContent::CreateSP(this, &FBSATimelineTrackGroup::BuildGroupSubMenu),
				MakeAttributeSP(this, &FBSATimelineTrackGroup::IsHovered)
			)
		];

	TSharedRef<SWidget> TrackGroup_Outliner = SNew(SBSAGroupTrackOutliner, GetEditorTimelineController(), GroupData).MainWidget(OutlinerWidget);

	return TrackGroup_Outliner;
}

TSharedRef<SWidget> FBSATimelineTrackGroup::BuildGroupSubMenu()
{
	FMenuBuilder MenuBuilder(true, nullptr);

	MenuBuilder.BeginSection("Group Actions", LOCTEXT("NotifiesMenuSection", "Group"));
	{
		MenuBuilder.AddMenuEntry
		(
			LOCTEXT("Action_NewGroup_Lable", "New Group"),
			LOCTEXT("Action_NewGroup_Tooltip", "Add a new task group"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateSP(this, &FBSATimelineTrackGroup::AddTaskGroup)),
			NAME_None,
			EUserInterfaceActionType::Button
		);

		MenuBuilder.AddMenuEntry
		(
			LOCTEXT("Action_DeleteGroup_Lable", "Delete Group"),
			LOCTEXT("Action_DeleteGroup_Tooltip", "Delete group"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateSP(this, &FBSATimelineTrackGroup::DeleteTaskGroup)),
			NAME_None,
			EUserInterfaceActionType::Button
		);
	}
	MenuBuilder.EndSection();


	MenuBuilder.BeginSection("Track Actions", LOCTEXT("NotifiesMenuSection", "Tracks"));
	{
		MenuBuilder.AddSubMenu
		(
			LOCTEXT("Action_AddTaskTrack_Lable", "Add Task Track"),
			LOCTEXT("Action_AddTaskTrack_Tooltip", "Add A New Task Track"),
			FNewMenuDelegate::CreateRaw( this, &FBSATimelineTrackGroup::FillNewTaskMenu)
		);
		MenuBuilder.AddMenuEntry
		(
			LOCTEXT("Action_PasteTasks_Lable", "Paste Tasks"),
			LOCTEXT("Action_PasteTasks_Tooltip", "Paste Tasks"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateSP(this, &FBSATimelineTrackGroup::PasteTasks)),
			NAME_None,
			EUserInterfaceActionType::Button
		);
		MenuBuilder.AddSubMenu
		(
			LOCTEXT("Action_AddTaskTemplate_Lable", "Add Task Template"),
			LOCTEXT("Action_AddTaskTemplate_Tooltip", "Add A New Task Template"),
			FNewMenuDelegate::CreateRaw(this, &FBSATimelineTrackGroup::FillNewTaskTemplateMenu)
		);
	}
	MenuBuilder.EndSection();


	return MenuBuilder.MakeWidget();
}

void FBSATimelineTrackGroup::AddNewTask(UClass* InTaskClass)
{
	if (FBSATimelineController* BSATC = StaticCast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		BSATC->AddNewTask(GroupData, InTaskClass);
	}
}

void FBSATimelineTrackGroup::PasteTasks()
{
	if (FBSATimelineController* BSATC = StaticCast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		FString SubString = TEXT("BEGIN Copy UTask!\n");

		FString PasteString;
		FPlatformApplicationMisc::ClipboardPaste(PasteString);
		if (PasteString.Contains(SubString))
		{
			PasteString = PasteString.Replace(*SubString, TEXT(""));

			int32 GroupID = -1;
			if (GroupData && BSATC->GetAsset())
			{
				int32 Index = 0;
				while (FBSATaskSection* Section = BSATC->GetAsset()->GetSectionPointerByIndex(Index))
				{
					for (int32 i = 0; i < Section->TaskGroups.Num(); ++i)
					{
						if (&(Section->TaskGroups[i]) == GroupData)
						{
							GroupID = i;
							break;
						}
					}

					if (GroupID > 0)
					{
						break;
					}

					Index = Index + 1;
				}
			}

			BSATC->PasteSelectedTasks(PasteString, GroupID);
		}
	}
}

void FBSATimelineTrackGroup::AddTaskGroup()
{
	if (FBSATimelineController* BSATC = StaticCast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		BSATC->AddNewTaskGroup();
	}
}

void FBSATimelineTrackGroup::DeleteTaskGroup()
{
	if (FBSATimelineController* BSATC = StaticCast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		BSATC->DeleteTaskGroup(GroupData);
	}
}

void FBSATimelineTrackGroup::FillNewTaskMenu(class FMenuBuilder& MenuBuilder)
{
	FBSAEditorUtilities::MakeNewTaskPicker(MenuBuilder, FOnClassPicked::CreateSP(this, &FBSATimelineTrackGroup::AddNewTask));
}

void FBSATimelineTrackGroup::FillNewTaskTemplateMenu(class FMenuBuilder& MenuBuilder)
{
	FBSAEditorUtilities::MakeNewTaskTemplatePicker(MenuBuilder, FOnAddTaskTemplateDelegate::CreateSP(this, &FBSATimelineTrackGroup::AddTaskTemplate));
}

FText FBSATimelineTrackGroup::GetLabel() const
{
	return FText::FromName(GroupData->Name);
}

void FBSATimelineTrackGroup::OnCommitCurveName(const FText& InText, ETextCommit::Type CommitInfo)
{
	GroupData->Name = *InText.ToString();
}

void FBSATimelineTrackGroup::AddTaskTemplate(FName TemplateName)
{
	if (FBSATimelineController* BSATC = StaticCast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		int32 GroupID = -1;
		if (GroupData && BSATC->GetAsset())
		{
			int32 Index = 0;
			while (FBSATaskSection* Section = BSATC->GetAsset()->GetSectionPointerByIndex(Index))
			{
				for (int32 i = 0; i < Section->TaskGroups.Num(); ++i)
				{
					if (&(Section->TaskGroups[i]) == GroupData)
					{
						GroupID = i;
						break;
					}
				}

				if (GroupID > 0)
				{
					break;
				}

				Index = Index + 1;
			}
		}

		BSATC->ImportTaskTemplate(TemplateName, GroupID);
	}
}

#undef LOCTEXT_NAMESPACE