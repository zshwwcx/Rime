#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineTrackPanel.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"

#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Views/SExpanderArrow.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Widgets/TimeLineBase/SAnimOutlinerItem.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackTimeline.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackOutliner.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorUtilities.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineController.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"
#include "Misc/MessageDialog.h"


#define LOCTEXT_NAMESPACE "FBSATimelineTrackPanel"



const float FBSATimelineTrackPanel::NotificationTrackHeight = 38.0f;

ANIMTIMELINE_IMPLEMENT_TRACK(FBSATimelineTrackPanel);

FBSATimelineTrackPanel::FBSATimelineTrackPanel
(
	const TSharedRef<FBSATimelineController>& InModel, UBSATask* InTask,
	const FText& InDisplayName, const FText& InToolTipText
) : FAnimTimelineTrack(InModel, InDisplayName, InToolTipText), CachedTask(InTask)
{
	SetHeight(NotificationTrackHeight);
}

void FBSATimelineTrackPanel::UpdateLayout()
{
	SetHeight(NotificationTrackHeight);

	RefreshOutlinerWidget();

	if (TrackWidget.IsValid())
	{
		TrackWidget->UpdateLayout();
	}
}

TSharedRef<SWidget> FBSATimelineTrackPanel::GenerateContainerWidgetForTimeline()
{
	if (!TrackWidget.IsValid())
	{
		TrackWidget =
			SNew(SBSATaskTrackTimeline)
			.Task(CachedTask.Get())
			.InputMin(this, &FBSATimelineTrackPanel::GetMinInput)
			.InputMax(this, &FBSATimelineTrackPanel::GetMaxInput)
			.ViewInputMin(this, &FBSATimelineTrackPanel::GetViewMinInput)
			.ViewInputMax(this, &FBSATimelineTrackPanel::GetViewMaxInput)
			.TimelinePlayLength(GetEditorTimelineController()->GetPlayLength())
			.FrameRate(GetEditorTimelineController()->GetFrameRate())
			.OnSetInputViewRange(this, &FBSATimelineTrackPanel::InputViewRangeChanged)
			.OnRefreshPanel(this, &FBSATimelineTrackPanel::UpdateLayout)
			.OnSelectNode(this, &FBSATimelineTrackPanel::OnSelectTask)
			.OnDeselectAllNodes(this, &FBSATimelineTrackPanel::OnDeselectAllTask)
			.OnDeleteTask(this, &FBSATimelineTrackPanel::RemoveSelectedTasks)
			.OnAddNewTask(this, &FBSATimelineTrackPanel::AddNewTask)
			.OnCopyTasks(this, &FBSATimelineTrackPanel::CopySelectedTasks)
			.OnPasteTasks(this, &FBSATimelineTrackPanel::PasteSelectedTasks)
			.OnExportTaskTemplate(this, &FBSATimelineTrackPanel::ExportTaskTemplate);
	}

	return TrackWidget.ToSharedRef();
}

TSharedRef<SWidget> FBSATimelineTrackPanel::GenerateContainerWidgetForOutliner(const TSharedRef<SAnimOutlinerItem>& InRow)
{
	TSharedPtr<SBorder> OuterBorder = 
		SNew(SBorder)
		.ToolTipText(this, &FAnimTimelineTrack::GetToolTipText)
		.BorderImage(FAppStyle::GetBrush("Sequencer.Section.BackgroundTint"))
		.BorderBackgroundColor(FAppStyle::GetColor("AnimTimeline.Outliner.ItemColor"));

	TSharedRef<SWidget> TaskTrackPanel = 
		SNew(SBSATaskTrackOutliner, GetEditorTimelineController(), CachedTask.Get())
		.TrackPanelArea(OuterBorder)
		.InlineEditableTextBlock
		(
			SNew(SInlineEditableTextBlock)
			.Text_Lambda
			(
				[this]()
				{
					return DisplayName;
				}
			)
			.IsSelected(FIsSelected::CreateLambda([]() { return false; }))
			.OnTextCommitted(this, &FBSATimelineTrackPanel::OnCommitTrackName)
		);

		return TaskTrackPanel;
}

void FBSATimelineTrackPanel::OnCommitTrackName(const FText& InText, ETextCommit::Type CommitInfo)
{
	FText TrimText = FText::TrimPrecedingAndTrailing(InText);
	if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		BSATC->ChangeTaskName(CachedTask.Get(), FName(*TrimText.ToString()));
	}

	this->UpdateLayout();
}

void FBSATimelineTrackPanel::RefreshOutlinerWidget()
{
	
}

void FBSATimelineTrackPanel::InputViewRangeChanged(float ViewMin, float ViewMax)
{
	
}

void FBSATimelineTrackPanel::OnSelectTask()
{
	if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		TArray<UBSATask*> TaskObjects;
		TaskObjects.Add(CachedTask.Get());

		BSATC->ChangeTaskSelection(TaskObjects);
	}
}

void FBSATimelineTrackPanel::OnDeselectAllTask()
{
	if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		BSATC->ChangeTaskSelection(TArray<UBSATask*>{});
	}
}

void FBSATimelineTrackPanel::RemoveSelectedTasks()
{
	if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		BSATC->DeleteSelectedTasks();
	}
}

void FBSATimelineTrackPanel::AddNewTask(UClass* InTaskClass, float InStartTime)
{
	if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		if (CachedTask.IsValid())
		{
			if (UBSAAsset* Asset = Cast<UBSAAsset>(CachedTask->GetOuter()))
			{
				int32 SectionID = -1;
				int32 GroupID = -1;

				Asset->GetSectionIDAndGroupID(*CachedTask.Get(), SectionID, GroupID);

				if (FBSATaskSection* SectionPtr = Asset->GetSectionPointerByIndex(SectionID))
				{
					BSATC->AddNewTask(&(SectionPtr->TaskGroups[GroupID]), InTaskClass, InStartTime);
				}
			}
		}
	}
}

void FBSATimelineTrackPanel::CopySelectedTasks()
{
	if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		if (BSATC->GetSelectedTasks().Num() == 0)
		{
			if (BSATC->GetSelectedTasks().Num() == 0)
			{
				FText DialogText = LOCTEXT("提示", "请先选中Task再复制");
				FMessageDialog::Open(EAppMsgType::Ok, DialogText);
				return;
			}
		}

		BSATC->CopySelectedTasks();
	}
}

void FBSATimelineTrackPanel::PasteSelectedTasks()
{
	if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		FString SubString = TEXT("BEGIN Copy UTask!\n");

		FString PasteString;
		FPlatformApplicationMisc::ClipboardPaste(PasteString);
		if (PasteString.Contains(SubString))
		{
			PasteString = PasteString.Replace(*SubString, TEXT(""));

			int32 GroupID = -1;
			if (CachedTask.IsValid() && BSATC->GetAsset())
			{
				int32 SectionID;
				BSATC->GetAsset()->GetSectionIDAndGroupID(*(CachedTask.Get()), SectionID, GroupID);
			}

			BSATC->PasteSelectedTasks(PasteString, GroupID);
		}
		else
		{
			FText DialogText = LOCTEXT("提示", "目前没有复制任何Task");
			FMessageDialog::Open(EAppMsgType::Ok, DialogText);
		}
	}
}

void FBSATimelineTrackPanel::ExportTaskTemplate()
{
	if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get()))
	{
		if (BSATC->GetSelectedTasks().Num() == 0)
		{
			BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get());
			if (BSATC->GetSelectedTasks().Num() == 0)
			{
				FText DialogText = LOCTEXT("提示", "请先选中Task");
				FMessageDialog::Open(EAppMsgType::Ok, DialogText);
				return;
			}
		}

		BSATC->ExportSelectedTaskTemplate();
	}
}

#undef LOCTEXT_NAMESPACE