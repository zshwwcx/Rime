#include "BattleSystemEditor/AbilityEditor/BSAEditorAssetManager.h"

#include "UObject/UObjectIterator.h"

#include "BattleSystemEditor/BSEditorFunctionLibrary.h"



void UBSAEditorAssetManager::Init()
{
	bActive = true;

	AddToRoot();

	FindAllAbilityPath();
}

void UBSAEditorAssetManager::UnInit()
{
	bActive = false;

	RemoveFromRoot();

	MarkAsGarbage();
}

UBSAEditorAssetManager* UBSAEditorAssetManager::GetInstance()
{
	for (TObjectIterator<UBSAEditorAssetManager> It; It; ++It)
	{
		if (!It->IsTemplate() && It->bActive)
		{
			return *It;
		}
	}

	return nullptr;
}

void UBSAEditorAssetManager::FindAllAbilityPath()
{
	// 查询技能、BUFF的资源路径
	SkillPathMap.Empty();
	BuffPathMap.Empty();
	UsedGuidList.Empty();
	UsedGuidNameList.Empty();
	TArray<FAssetData> AssetData;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FARFilter Filter;
	Filter.PackagePaths.Add("/Game");
	Filter.ClassPaths.Add(UBSASkillAsset::StaticClass()->GetClassPathName());
	Filter.ClassPaths.Add(UBSABuffAsset::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	AssetData.Empty();
	AssetRegistryModule.Get().GetAssets(Filter, AssetData);
	for (int32 i = 0; i < AssetData.Num(); ++i)
	{
		int32 ID = FCString::Atoi(*AssetData[i].AssetName.ToString());
		if (AssetData[i].GetClass() == UBSASkillAsset::StaticClass() && ID > 0)
		{
			SkillPathMap.Add(ID, TSoftObjectPtr<UBSASkillAsset>(AssetData[i].ToSoftObjectPath()));
		}
		else if (AssetData[i].GetClass() == UBSABuffAsset::StaticClass() && ID > 0)
		{
			BuffPathMap.Add(ID, TSoftObjectPtr<UBSABuffAsset>(AssetData[i].ToSoftObjectPath()));
		}
	}
}

TArray<TSoftObjectPtr<UObject>> UBSAEditorAssetManager::GetBSAAssetResources(UBSAAsset* TheAsset)
{
	TArray<FString> NewList;
	TheAsset->GetReferenceResources(NewList);

	TArray<TSoftObjectPtr<UObject>> ResList;
	for (int32 i = 0; i < NewList.Num(); ++i)
	{
		FString PathString = NewList[i];

		ResList.Add(TSoftObjectPtr<UObject>(NewList[i]));
	}

	return ResList;
}



TArray<int32> UBSAEditorAssetManager::GetSkillIDList()
{
	TArray<int32> Keys;
	SkillPathMap.GenerateKeyArray(Keys);

	return Keys;
}

UBSASkillAsset* UBSAEditorAssetManager::GetSkillAssetByID(int32 ID)
{
	if (TSoftObjectPtr<UBSASkillAsset>* Res = SkillPathMap.Find(ID))
	{
		if (UBSASkillAsset* LoadSkill = Res->LoadSynchronous())
		{
			return LoadSkill;
		}
	}

	return nullptr;
}

TSoftObjectPtr<UBSASkillAsset> UBSAEditorAssetManager::GetSkillAssetSoftObjectByID(int32 ID)
{
	if (TSoftObjectPtr<UBSASkillAsset>* Res = SkillPathMap.Find(ID))
	{
		return *Res;
	}

	return nullptr;
}



TArray<int32> UBSAEditorAssetManager::GetBuffIDList()
{
	TArray<int32> Keys;
	BuffPathMap.GenerateKeyArray(Keys);

	return Keys;
}

UBSABuffAsset* UBSAEditorAssetManager::GetBuffAssetByID(int32 ID)
{
	if (TSoftObjectPtr<UBSABuffAsset>* Res = BuffPathMap.Find(ID))
	{
		if (UBSABuffAsset* LoadBuff = Res->LoadSynchronous())
		{
			return LoadBuff;
		}
	}

	return nullptr;
}

TSoftObjectPtr<UBSABuffAsset> UBSAEditorAssetManager::GetBuffAssetSoftObjectByID(int32 ID)
{
	if (TSoftObjectPtr<UBSABuffAsset>* Res = BuffPathMap.Find(ID))
	{
		return *Res;
	}

	return nullptr;
}
