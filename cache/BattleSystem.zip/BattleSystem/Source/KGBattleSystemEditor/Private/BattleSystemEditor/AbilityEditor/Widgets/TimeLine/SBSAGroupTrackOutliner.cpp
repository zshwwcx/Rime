#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSAGroupTrackOutliner.h"
#include "Framework/Application/SlateApplication.h"

#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditorUtilities.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineDragDropOp.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/BSATimelineController.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/TimeLine/SBSATaskTrackOutliner.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"



#define LOCTEXT_NAMESPACE "SBSAGroupTrackOutliner"



void SBSAGroupTrackOutliner::Construct(const FArguments& InArgs, const TSharedPtr<FTimelineController>& InTimelineController, FBSATaskGroup* InGroupData)
{
	TimelineController = InTimelineController;
	GroupData = InGroupData;

	TSharedPtr<SWidget> MainWidget = InArgs._MainWidget;

	this->ChildSlot
	[
		MainWidget.ToSharedRef()
	];
}

FReply SBSAGroupTrackOutliner::OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	bool bWasDropHandled = false;

	TSharedPtr<FDragDropOperation> Operation = DragDropEvent.GetOperation();
	if (!Operation.IsValid())
	{

	}
	else if (Operation->IsOfType<FBSATrackDragDropOp>())
	{
		const auto& FrameDragDropOp = StaticCastSharedPtr<FBSATrackDragDropOp>(Operation);

		if (FBSATimelineController* BSATC = static_cast<FBSATimelineController*>(TimelineController.Pin().Get()))
		{
			BSATC->ChangeTaskGroup(FrameDragDropOp->CachedTask.Get(), GroupData);
		}

		bWasDropHandled = true;
	}

	return bWasDropHandled ? FReply::Handled() : FReply::Unhandled();
}



#undef LOCTEXT_NAMESPACE
