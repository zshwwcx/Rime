#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/SBSALogicGraphNode.h"

#include "SGraphPin.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/BSALogicGraphNode.h"



#define LOCTEXT_NAMESPACE "SLogicGraphNode"



void SBSALogicGraphNode::Construct(const FArguments& InArgs, UBSALogicGraphNode* InNode)
{
	GraphNode = InNode;
	UpdateGraphNode();

	InNode->NodeWidget = this;
}

void SBSALogicGraphNode::UpdateGraphNode()
{
	SGraphNode::UpdateGraphNode();

	// 覆盖Pin脚的颜色
	if (UBSALogicGraphNode* LGNode = Cast<UBSALogicGraphNode>(GraphNode))
	{
		for (int32 i = 0; i < InputPins.Num(); ++i)
		{
			InputPins[i].Get().SetPinColorModifier(LGNode->GetPinColor(InputPins[i]->GetPinObj()));
		}

		for (int32 i = 0; i < OutputPins.Num(); ++i)
		{
			OutputPins[i].Get().SetPinColorModifier(LGNode->GetPinColor(OutputPins[i]->GetPinObj()));
		}
	}
}

#undef LOCTEXT_NAMESPACE
