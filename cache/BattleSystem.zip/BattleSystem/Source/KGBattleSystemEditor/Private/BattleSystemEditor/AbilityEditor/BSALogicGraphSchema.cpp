#include "BattleSystemEditor/AbilityEditor/BSALogicGraphSchema.h"

#include "CoreMinimal.h"
#include "UObject/UObjectIterator.h"
#include "ScopedTransaction.h"
#include "EdGraph/EdGraph.h"
#include "GraphEditorActions.h"

#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Framework/Commands/GenericCommands.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/BSALogicGraphNode.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"



#define LOCTEXT_NAMESPACE "BSALogicGraphSchema"



UEdGraphNode* FBSALGCreatTaskNodeAction::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	if (TaskPointer.IsValid())
	{
		ParentGraph->Modify();

		if (FromPin)
		{
			FromPin->Modify();
		}

		if (UBSALogicGraphNode* ResultNode = NewObject<UBSALogicGraphNode>(ParentGraph))
		{
			ResultNode->CachedTask = TaskPointer.Get();

			ParentGraph->AddNode(ResultNode, true, bSelectNewNode);

			ResultNode->CreateNewGuid();
			ResultNode->PostPlacedNewNode();
			ResultNode->AllocateDefaultPins();
			ResultNode->AutowireNewNode(FromPin);

			ResultNode->NodePosX = Location.X;
			ResultNode->NodePosY = Location.Y;

			ResultNode->SetFlags(RF_Transactional);

			return ResultNode;
		}
	}

	return nullptr;
}

void FBSALGCreatTaskNodeAction::AddReferencedObjects(FReferenceCollector& Collector)
{
	FEdGraphSchemaAction::AddReferencedObjects(Collector);

	Collector.AddReferencedObject(TaskPointer);
}






// 循环连接检查器
class FBSALogicGraphCycleChecker
{
public:
	bool CheckForLoop(UEdGraphNode* InputNode, UEdGraphNode* OutputNode)
	{
		CacheOutputNode = OutputNode;

		return TraverseInputNodesToRoot(InputNode);
	}

private:
	bool TraverseInputNodesToRoot(UEdGraphNode* Node)
	{
		for (int32 PinIndex = 0; PinIndex < Node->Pins.Num(); ++PinIndex)
		{
			UEdGraphPin* MyPin = Node->Pins[PinIndex];

			if (MyPin->Direction == EGPD_Output)
			{
				for (int32 LinkedPinIndex = 0; LinkedPinIndex < MyPin->LinkedTo.Num(); ++LinkedPinIndex)
				{
					if (UEdGraphPin* OtherPin = MyPin->LinkedTo[LinkedPinIndex])
					{
						if (CacheOutputNode == OtherPin->GetOwningNode())
							return false;
						else if (!TraverseInputNodesToRoot(OtherPin->GetOwningNode()))
							return false;
					}
				}
			}
		}

		return true;
	}

	TWeakObjectPtr<UEdGraphNode> CacheOutputNode;
};






FBSALGConnectionDrawingPolicy::FBSALGConnectionDrawingPolicy(int32 InBackLayerID, int32 InFrontLayerID, float ZoomFactor, const FSlateRect& InClippingRect, FSlateWindowElementList& InDrawElements)
	: FConnectionDrawingPolicy(InBackLayerID, InFrontLayerID, ZoomFactor, InClippingRect, InDrawElements)
{

}

void FBSALGConnectionDrawingPolicy::DetermineWiringStyle(UEdGraphPin* OutputPin, UEdGraphPin* InputPin, FConnectionParams& Params)
{
	FConnectionDrawingPolicy::DetermineWiringStyle(OutputPin, InputPin, Params);

	if (UBSALogicGraphNode* LGNode = Cast<UBSALogicGraphNode>(OutputPin->GetOwningNode()))
	{
		Params.WireColor = LGNode->GetPinColor(OutputPin);
	}
}






EGraphType UBSALogicGraphSchema::GetGraphType(const UEdGraph* TestEdGraph) const
{
	return GT_StateMachine;
}

const FPinConnectionResponse UBSALogicGraphSchema::CanCreateConnection(const UEdGraphPin* InPinA, const UEdGraphPin* InPinB) const
{
	// 首先检查两个Pin的类型是不是一个输入一个输出
	if (!InPinA || !InPinB)
	{
		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("Connect Error", "Invalid Pin!"));
	}
	if (InPinA->Direction == InPinB->Direction)
	{
		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("Connect Error", "Direction Type Is Same!"));
	}


	const UEdGraphPin* InputPin = (InPinA->Direction == EEdGraphPinDirection::EGPD_Input) ? InPinA : InPinB;
	const UEdGraphPin* OutputPin = (InPinA->Direction == EEdGraphPinDirection::EGPD_Output) ? InPinA : InPinB;


	// 其次检查是否会出现环路
	UBSALogicGraphNode* InputNode = Cast<UBSALogicGraphNode>(InputPin->GetOwningNode());
	UBSALogicGraphNode* OutputNode = Cast<UBSALogicGraphNode>(OutputPin->GetOwningNode());
	if (!InputNode || !OutputNode)
	{
		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("Connect Error", "Invalid Node!"));
	}
	if (UBSAAsset* Asset = Cast<UBSAAsset>(InputNode->CachedTask->GetOuter()))
	{
		int32 InputSectionID;
		int32 InputGroupID;
		Asset->GetSectionIDAndGroupID(*InputNode->CachedTask, InputSectionID, InputGroupID);

		int32 OutputSectionID;
		int32 OutputGroupID;
		Asset->GetSectionIDAndGroupID(*OutputNode->CachedTask, OutputSectionID, OutputGroupID);

		if (InputSectionID != OutputSectionID)
		{
			return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("Connect Error", "Not Same Task Section!"));
		}
	}
	FBSALogicGraphCycleChecker CycleChecker;
	if (!CycleChecker.CheckForLoop(InputNode, OutputNode))
	{
		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("Connect Error", "Can't Create A Graph Cycle!"));
	}


	// 获取Pin的信息
	FBSALGNodePin* InputInfo = InputNode->GetPinInformation(InputPin);
	FBSALGNodePin* OutputInfo = OutputNode->GetPinInformation(OutputPin);
	if (!InputInfo || !OutputInfo)
	{
		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("Connect Error", "Invalid Pin!"));
	}


	// 如果是事件输入/输出相关
	if (InputInfo->PinType == 0)
	{
		if (OutputInfo->PinType == 1)
		{
			return FPinConnectionResponse(CONNECT_RESPONSE_MAKE, LOCTEXT("Connect Sucess", "Add Task Event To Start New Task!"));
		}
		else
		{
			return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("Connect Error", "Pin Type Error!"));
		}
	}
	else if (InputInfo->PinType == 2 || InputInfo->PinType == 3)
	{
		EBSDataType InputDataType = EBSDataType::DT_TMax;
		UScriptStruct* InputDataStructType = nullptr;
		InputNode->GetPinDataType(InputPin, InputDataType, InputDataStructType);

		EBSDataType OutputDataType = EBSDataType::DT_TMax;
		UScriptStruct* OutputDataStructType = nullptr;
		OutputNode->GetPinDataType(OutputPin, OutputDataType, OutputDataStructType);

		if (InputDataType != EBSDataType::DT_TMax && InputDataType == OutputDataType)
		{
			ECanCreateConnectionResponse ConnectResponse;
			if (InputPin == InPinA)
			{
				ConnectResponse = CONNECT_RESPONSE_BREAK_OTHERS_A;
			}
			else
			{
				ConnectResponse = CONNECT_RESPONSE_BREAK_OTHERS_B;
			}

			if (InputDataType == EBSDataType::DT_Struct)
			{
				if (InputDataStructType == OutputDataStructType)
				{
					return FPinConnectionResponse(ConnectResponse, LOCTEXT("Connect Sucess", "Transfer Task Struct Data!"));
				}
			}
			else
			{
				return FPinConnectionResponse(ConnectResponse, LOCTEXT("Connect Sucess", "Transfer Task Data!"));
			}
		}

		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("Connect Error", "Data Type Mismatch!"));
	}


	return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("Connect Error", "No Reason."));
}

FConnectionDrawingPolicy* UBSALogicGraphSchema::CreateConnectionDrawingPolicy(int32 InBackLayerID, int32 InFrontLayerID, float InZoomFactor, const FSlateRect& InClippingRect, class FSlateWindowElementList& InDrawElements, class UEdGraph* InGraphObj) const
{
	return new FBSALGConnectionDrawingPolicy(InBackLayerID, InFrontLayerID, InZoomFactor, InClippingRect, InDrawElements);
}

FLinearColor UBSALogicGraphSchema::GetPinTypeColor(const FEdGraphPinType& PinType) const
{
	return FColor::White;
}



#undef LOCTEXT_NAMESPACE
