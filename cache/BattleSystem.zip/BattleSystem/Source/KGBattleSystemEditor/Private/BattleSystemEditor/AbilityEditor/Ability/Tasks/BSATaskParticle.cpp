#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskParticle.h"

#include "Kismet/KismetMathLibrary.h"

#include "NiagaraSystem.h"
#include "Particles/ParticleSystem.h"

#include "BattleSystem/BSFunctionLibrary.h"



#if WITH_EDITOR
void UBSATPlayNiagara::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("NiagaraAsset")))
	{
		bHasLoopEmitter = NiagaraAsset.IsNull() ? false : UBSFunctionLibrary::IsLoopingNiagara(NiagaraAsset.LoadSynchronous());
	}	

	if (bHasLoopEmitter)
	{
		bDestroyWhenTaskEnd = true;
	}

	if (bNeedAttach)
	{
		bNeedCheckGround = false;
	}
	else
	{
		bAttachRotation = false;
		bAttachScale = false;
	}

	if (!bDestroyWhenTaskEnd)
	{
		LifeType = EBSATaskLife::TL_Instant;
	}
	else if (LifeType == EBSATaskLife::TL_Instant)
	{
		LifeType = EBSATaskLife::TL_DurAndController;
		FinishDelay = FMath::Max(1.0f, FinishDelay);
	}

	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("bUseInputData")))
	{
		CoordinateCreater.OffsetTransform.InputDataID = 1;
	}

	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("bClickToFixCoordinateCreater")))
	{
		CoordinateCreater.OffsetTransform.ConfigValue = CoordinateCreater.OffsetTransform.ConfigValue * FTransform(FRotator(0.0f, -90.0f, 0.0f));
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSATPlayNiagara::UpdateDataByDynamicActorInfo(const FBSADynamicObjectInfo& InInfo)
{
	USceneComponent* DComponent = Cast<USceneComponent>(InInfo.DynamicObject);
	if (!DComponent)
		return;

	if (bNeedAttach)
	{
		AttachTransform.ConfigValue = DComponent->GetRelativeTransform();
	}
	else if (!CoordinateCreater.OffsetTransform.bUseInputData)
	{
		FTransform CurWorldTransform = DComponent->GetComponentTransform();
		CoordinateCreater.OffsetTransform.ConfigValue = CurWorldTransform * InInfo.CachedTransform.Inverse();
	}
}

void UBSATPlayNiagara::UpdateDynamicActorByData(const FBSADynamicObjectInfoArray& InInfoArray)
{
	for (int32 i = 0; i < InInfoArray.Informations.Num(); ++i)
	{
		USceneComponent* DComponent = Cast<USceneComponent>(InInfoArray.Informations[i].DynamicObject);
		if (!DComponent)
			continue;

		if (bNeedAttach)
		{
			DComponent->SetRelativeTransform(AttachTransform.ConfigValue);
		}
		else if (!CoordinateCreater.OffsetTransform.bUseInputData)
		{
			FTransform CurWorldTransform = CoordinateCreater.OffsetTransform.ConfigValue * InInfoArray.Informations[i].CachedTransform;

			if (bNeedCheckGround)
			{
				FVector Result(ForceInit); TArray<AActor*> IgnoreActors;
				FVector UpVec = DComponent->GetUpVector();
				UBSFunctionLibrary::FindGroundLocation(InInfoArray.Informations[i].DynamicObject, CurWorldTransform.GetLocation(), GroundCheckObjectTypes, Result, ExtraGroundMsg, UpVec * -1.0f);
			}

			DComponent->SetWorldTransform(CurWorldTransform);
		}
	}
}

#endif






void UBSATFluidNinja::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (bNeedAttach)
	{
		bNeedCheckGround = false;
	}
	else
	{
		bAttachRotation = false;
		bAttachScale = false;
	}

	if (TotalLife >= 0.0f)
	{
		LifeType = EBSATaskLife::TL_Instant;
	}
	else if (LifeType == EBSATaskLife::TL_Instant)
	{
		LifeType = EBSATaskLife::TL_DurAndController;
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}
