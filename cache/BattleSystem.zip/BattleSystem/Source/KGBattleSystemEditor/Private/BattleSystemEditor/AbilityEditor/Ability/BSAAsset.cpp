#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorDelegates.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskAnimation.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskSound.h"

#include "BattleSystem/BSMacroDefinition.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSABuffAsset.h"
#include "Misc/MessageDialog.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskUI.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskBattle.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskParticle.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskCollision.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskMovement.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskEventListener.h"



void UBSAAsset::GetReferenceResources(TArray<FString>& InOutList)
{
	for (int32 i = 0; i < Sections.Num(); ++i)
	{
		for (int32 j = 0; j < Sections[i].TaskList.Num(); ++j)
		{
			if (Sections[i].TaskList[j])
			{
				Sections[i].TaskList[j]->GetReferenceResources(InOutList);
			}
		}
	}
}

FBSATaskSection* UBSAAsset::GetSectionPointerByIndex(int32 Index)
{
	if (Sections.IsValidIndex(Index))
	{
		return &(Sections[Index]);
	}
	
	return nullptr;
}

FBSATaskSection* UBSAAsset::GetSectionPointerByTask(UBSATaskBase* InTask)
{
	for (int32 i = 0; i < Sections.Num(); ++i)
	{
		if (Sections[i].TaskList.Contains(InTask))
		{
			return &(Sections[i]);
		}
	}

	return nullptr;
}

int32 UBSAAsset::GetSearchIDByTask(UBSATaskBase* InTask)
{
	int32 SearchID = -1;
	for (int32 i = 0; i < Sections.Num(); ++i)
	{
		int32 Index = -1;
		for (int32 j = 0; j < Sections[i].TaskList.Num(); ++j)
		{
			if (Sections[i].TaskList[j] == InTask)
			{
				Index = j;
				break;
			}
		}
		if (Index >= 0)
		{
			// 和LUA对齐
			SearchID = (i + 1) * 1000 + Index + 1;
			break;
		}
	}

	return SearchID;
}

UBSATaskBase* UBSAAsset::GetTaskBySearchID(int32 InSearchID)
{
	if (InSearchID <= 0)
		return nullptr;

	int32 SectionID = InSearchID / 1000 - 1;
	int32 ListIndex = InSearchID % 1000 - 1;

	if (Sections.IsValidIndex(SectionID) && Sections[SectionID].TaskList.IsValidIndex(ListIndex))
	{
		return Sections[SectionID].TaskList[ListIndex];
	}

	return nullptr;
}

TArray<UBSATask*> UBSAAsset::GetTasks()
{
	TArray<UBSATask*> OutTasks;
	for (int32 i = 0; i < Sections.Num(); ++i)
	{
		for (int32 j = 0; j < Sections[i].TaskGroups.Num(); ++j)
		{
			for (int32 k = 0; k < Sections[i].TaskGroups[j].TaskList.Num(); ++k)
			{
				if (Sections[i].TaskGroups[j].TaskList[k].IsValid())
				{
					OutTasks.AddUnique(Sections[i].TaskGroups[j].TaskList[k].Get());
				}
			}
		}
	}

	return OutTasks;
}

#if WITH_EDITOR
void UBSAAsset::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	if (ExpandData)
	{
		ExpandData->UpdateExpandDataAfterPropertyChanged(this, PropertyChangedEvent.GetPropertyName());
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSAAsset::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{
	// 对Section的时长进行规范化
	for (int32 i = 0; i < Sections.Num(); ++i)
	{
		Sections[i].SectionDuration = FMath::RoundToFloat(Sections[i].SectionDuration * BSFrameRate) / BSFrameRate;
	}

	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

void UBSAAsset::InitByEditor(UObject* WorldContext)
{
	bHasInit = true;
}

void UBSAAsset::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);

	int32 RealID = FCString::Atoi(*GetName());
	if (ID != RealID)
	{
		ID = RealID;
	}

	// 根据编辑的顺序进行重排序
	for (int32 i = 0; i < Sections.Num(); ++i)
	{
		Sections[i].Index = i + 1;
		Sections[i].TaskList.Empty();
		for (int32 j = 0; j < Sections[i].TaskGroups.Num(); ++j)
		{
			for (int32 k = 0; k < Sections[i].TaskGroups[j].TaskList.Num(); ++k)
			{
				if (Sections[i].TaskGroups[j].TaskList[k].IsValid())
				{
					// 移除无效的Task事件
					for (TMap<FName, FBSATaskSelectorList>::TIterator It(Sections[i].TaskGroups[j].TaskList[k]->EventTaskMap); It; ++It)
					{
						for (TArray<FBSATaskSelector>::TIterator It2(It->Value.SelectedTaskList); It2; ++It2)
						{
							if (!IsValid(It2->SelectedTask))
							{
								It2.RemoveCurrent();
							}
						}
					}

					Sections[i].TaskGroups[j].TaskList[k]->SetIndex(Sections[i].Index * 1000 + Sections[i].TaskList.Num() + 1);
					Sections[i].TaskList.Add(Sections[i].TaskGroups[j].TaskList[k].Get());
				}
			}
		}

		Sections[i].SectionDuration = FMath::RoundToFloat(Sections[i].SectionDuration * BSFrameRate) / BSFrameRate;

		for (int32 j = 0; j < Sections[i].TaskList.Num(); ++j)
		{
			if (Sections[i].TaskList[j])
			{
				// 对齐时间轴
				Sections[i].TaskList[j]->CallPostEditChangeProperty(FName(TEXT("StartTime")));

				Sections[i].TaskList[j]->GUIDMap.Empty();
			}
		}
	}

	// 更新时间轴的关键帧信息
	UpdateKeyframeList();

	// 更新Niagara数量
	UpdateNiagaraNumber();
}

void UBSAAsset::GetSectionIDAndGroupID(UBSATask& Task, int32& OutSectionID, int32& OutGroupID)
{
	for (int32 i = 0; i < Sections.Num(); ++i)
	{
		for (int32 j = 0; j < Sections[i].TaskGroups.Num(); ++j)
		{
			if (Sections[i].TaskGroups[j].TaskList.Contains(&Task))
			{
				OutSectionID = i;
				OutGroupID = j;

				break;
			}
		}
	}
}

bool UBSAAsset::AddTask(int32 SectionID, int32 GroupID, UBSATask& Task)
{
	if (!Sections.IsValidIndex(SectionID) || !Sections[SectionID].TaskGroups.IsValidIndex(GroupID))
	{
		Task.MarkAsGarbage();

		return false;
	}

	Sections[SectionID].TaskList.Add(&Task);

	Sections[SectionID].TaskGroups[GroupID].TaskList.Add(&Task);

	GetPackage()->MarkPackageDirty();

	return true;
}

bool UBSAAsset::RemoveTask(int32 SectionID, int32 GroupID, UBSATask& Task)
{
	if (!Sections.IsValidIndex(SectionID) || !Sections[SectionID].TaskGroups.IsValidIndex(GroupID))
	{
		return false;
	}

	Task.MarkAsGarbage();

	Sections[SectionID].TaskList.Remove(&Task);

	Sections[SectionID].TaskGroups[GroupID].TaskList.Remove(&Task);

	// 清理同Section中其他Task的依赖关系
	for (int32 i = 0; i < Sections[SectionID].TaskList.Num(); ++i)
	{
		if (Sections[SectionID].TaskList[i])
		{
			Sections[SectionID].TaskList[i]->CleanInvalidDependencies();
		}
	}

	GetPackage()->MarkPackageDirty();

	return true;
}

bool UBSAAsset::RemoveTask(UBSATask& Task)
{
	for (int i = 0; i < Sections.Num(); i++)
	{
		for (int j = 0; j < Sections[i].TaskGroups.Num(); j++)
		{
			for (int k = 0; k < Sections[i].TaskGroups[j].TaskList.Num(); k++)
			{
				if (Sections[i].TaskGroups[j].TaskList[k].Get() == &Task)
				{
					return RemoveTask(i, j, Task);
				}
			}
		}
	}

	return false;
}

bool UBSAAsset::AddGroup(int32 SectionID, FName NewGroupName)
{
	if (!Sections.IsValidIndex(SectionID))
	{
		return false;
	}

	if (NewGroupName.IsNone())
	{
		Sections[SectionID].TaskGroups.Add(FBSATaskGroup(FName(FString::Printf(TEXT("Group:%d"), Sections[SectionID].TaskGroups.Num()))));
	}
	else
	{
		Sections[SectionID].TaskGroups.Add(FBSATaskGroup(NewGroupName));
	}

	GetPackage()->MarkPackageDirty();

	return true;
}

bool UBSAAsset::RemoveGroup(int32 SectionID, int32 GroupID)
{
	if (!Sections.IsValidIndex(SectionID) || !Sections[SectionID].TaskGroups.IsValidIndex(GroupID) || Sections[SectionID].TaskGroups.Num() <= 1)
	{
		return false;
	}

	int32 ListNum = Sections[SectionID].TaskGroups[GroupID].TaskList.Num();
	for (int32 i = ListNum - 1; i >= 0; --i)
	{
		if (Sections[SectionID].TaskGroups[GroupID].TaskList.IsValidIndex(i) && Sections[SectionID].TaskGroups[GroupID].TaskList[i].IsValid())
		{
			RemoveTask(SectionID, GroupID, *Sections[SectionID].TaskGroups[GroupID].TaskList[i]);
		}
	}

	Sections[SectionID].TaskGroups.RemoveAt(GroupID);

	GetPackage()->MarkPackageDirty();

	return true;
}

int32 UBSAAsset::GetSectionNum()
{
	return Sections.Num();
}

void UBSAAsset::ClearAllSection()
{
	Sections.Empty();
}

bool UBSAAsset::AddSection(FName NewSectionName)
{
	if (NewSectionName.IsNone())
	{
		Sections.Add( FBSATaskSection( FName(FString::Printf(TEXT("Section:%d"), Sections.Num())) ) );
	}
	else
	{
		Sections.Add(FBSATaskSection(NewSectionName));
	}

	GetPackage()->MarkPackageDirty();

	return true;
}

bool UBSAAsset::AddSection(const FBSATaskSection& InNewSection)
{
	Sections.Add(InNewSection);

	return true;
}

bool UBSAAsset::RemoveSection(int32 SectionID)
{
	if (!Sections.IsValidIndex(SectionID) || Sections.Num() <= 1)
	{
		return false;
	}

	for (int32 i = Sections[SectionID].TaskGroups.Num() - 1; i >= 0; --i)
	{
		RemoveGroup(SectionID, i);
	}

	Sections.RemoveAt(SectionID);

	GetPackage()->MarkPackageDirty();

	return true;
}

void UBSAAsset::ChangeSectionName(int32 SectionID, FName NewName)
{
	if (!Sections.IsValidIndex(SectionID))
	{
		return;
	}

	Sections[SectionID].Name = NewName;

	GetPackage()->MarkPackageDirty();
}

void UBSAAsset::ChangeSectionLoopTime(int32 SectionID, int32 NewLoop)
{
	if (!Sections.IsValidIndex(SectionID))
	{
		return;
	}

	Sections[SectionID].LoopTime = NewLoop;

	GetPackage()->MarkPackageDirty();
}

void UBSAAsset::ChangeSectionDuration(int32 SectionID, float NewDuration)
{
	if (!Sections.IsValidIndex(SectionID))
	{
		return;
	}

	Sections[SectionID].SectionDuration = FMath::RoundToFloat(NewDuration * BSFrameRate) / BSFrameRate;

	GetPackage()->MarkPackageDirty();
}

void UBSAAsset::UpdateKeyframeList()
{
	for (int32 i = 0; i < Sections.Num(); ++i)
	{
		FBSATaskSection& CurSection = Sections[i];
		CurSection.ClientKeyframeList.Empty();
		CurSection.ServerKeyframeList.Empty();

		for (int32 j = 0; j < CurSection.TaskList.Num(); ++j)
		{
			if (!CurSection.TaskList[j])
			{
				continue;
			}

			if ((CurSection.TaskList[j]->GetTriggerMethod() & 1) > 0)
			{
				if (CurSection.TaskList[j]->GetNetType() <= EBSATaskNet::TN_ServerAndLocalClient)
				{
					bool bFind = false;
					for (int32 k = 0; k < CurSection.ServerKeyframeList.Num(); ++k)
					{
						if (FMath::IsNearlyEqual(CurSection.TaskList[j]->GetStartTime(), CurSection.ServerKeyframeList[k].Time, 0.01f))
						{
							bFind = true;
							CurSection.ServerKeyframeList[k].TaskIndexList.Add(j + 1);
							break;
						}
					}

					if (!bFind)
					{
						FBSAKeyframe NewFrame(CurSection.TaskList[j]->GetStartTime());
						NewFrame.TaskIndexList.Add(j + 1);

						CurSection.ServerKeyframeList.Add(NewFrame);
					}
				}

				if (CurSection.TaskList[j]->GetNetType() >= EBSATaskNet::TN_ServerAndClient)
				{
					bool bFind = false;
					for (int32 k = 0; k < CurSection.ClientKeyframeList.Num(); ++k)
					{
						if (FMath::IsNearlyEqual(CurSection.TaskList[j]->GetStartTime(), CurSection.ClientKeyframeList[k].Time, 0.01f))
						{
							bFind = true;
							CurSection.ClientKeyframeList[k].TaskIndexList.Add(j + 1);
							break;
						}
					}

					if (!bFind)
					{
						FBSAKeyframe NewFrame(CurSection.TaskList[j]->GetStartTime());
						NewFrame.TaskIndexList.Add(j + 1);

						CurSection.ClientKeyframeList.Add(NewFrame);
					}
				}
			}
		}

		CurSection.ClientKeyframeList.Sort
		(
			[](const FBSAKeyframe& KeyA, const FBSAKeyframe& KeyB)
			{
				return KeyA.Time < KeyB.Time;
			}
		);

		CurSection.ServerKeyframeList.Sort
		(
			[](const FBSAKeyframe& KeyA, const FBSAKeyframe& KeyB)
			{
				return KeyA.Time < KeyB.Time;
			}
		);
	}
}

#endif



#pragma region AutoOptimize
#define LOCTEXT_NAMESPACE "BSAAsset"

#if WITH_EDITOR
// 暴力做法，不优雅，但编辑器逻辑无伤大雅
void UBSAAsset::AutoOptimizeTask()
{
	ConfigProblemNumber = 0;

	CheckTaskInvalid(true);
	CheckTaskNonTrigger(true);
	CheckTaskNetType(true);
	CheckTaskRedundantTrigger(true);
	CheckEventListenerLifeType(true);
	CheckBuffStackableSection(true);
	CheckBuffGlobalSection(true);
	CheckSectionAnimationNum(true);
	CheckNiagaraTotalNumber(true);
	CheckNiagaraDensity(true);
	CheckAudioAsset(true);

	if (ConfigProblemNumber > 0)
	{
		// 消息框显示的消息内容
		FText DialogText = LOCTEXT("Auto Optimize Suggestion", "资源配置存在部分问题，是否查看并解决问题？");

		EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
		if (ReturnType == EAppReturnType::Type::Yes)
		{
			CheckTaskInvalid(false);
			CheckTaskNonTrigger(false);
			CheckTaskNetType(false);
			CheckTaskRedundantTrigger(false);
			CheckEventListenerLifeType(false);
			CheckBuffStackableSection(false);
			CheckBuffGlobalSection(false);
			CheckSectionAnimationNum(false);
			CheckNiagaraTotalNumber(false);
			CheckNiagaraDensity(false);
			CheckAudioAsset(false);
		}
	}

	if (ConfigProblemNumber > 5)
	{
		FText DialogText = LOCTEXT("Auto Optimize Suggestion", "错误太多 或 有影响较大的错误，只提供临时数据导出，不保存！！！！");
		EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::Ok, DialogText);
	}

	FBSAEditorDelegates::AutoOptimizeDoneDelegate.Broadcast(this);
}

void UBSAAsset::CheckTaskInvalid(bool bOnlyCheck)
{
	for (int i = 0; i < Sections.Num(); i++)
	{
		for (int j = 0; j < Sections[i].TaskGroups.Num(); j++)
		{
			for (int k = 0; k < Sections[i].TaskGroups[j].TaskList.Num(); k++)
			{
				UBSATask* Task = Sections[i].TaskGroups[j].TaskList[k].Get();

				if (!Task)
				{
					// 空的Task直接删除
					Sections[i].TaskGroups[j].TaskList.RemoveAtSwap(k);
					GetPackage()->MarkPackageDirty();
					continue;
				}

				if ((Task->IgnoreAutoOptimize & 1) <= 0 && Task->IsTaskInvalid())
				{
					// 仅仅检查一下
					if (bOnlyCheck)
					{
						ConfigProblemNumber += 1;
						return;
					}

					// 消息框显示的消息内容
					FText DialogText = FText::Format
					(
						LOCTEXT("Auto Optimize Suggestion", "{0} 无有效的配置数据，建议删除，是否自动执行？"),
						FText::FromString(Sections[i].TaskGroups[j].TaskList[k].Get()->GetName())
					);

					EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
					if (ReturnType == EAppReturnType::Type::Yes)
					{
						RemoveTask(i, j, *Sections[i].TaskGroups[j].TaskList[k].Get());
						GetPackage()->MarkPackageDirty();

						ConfigProblemNumber = FMath::Max(0, ConfigProblemNumber - 1);
					}					
				}
			}
		}
	}
}

void UBSAAsset::CheckTaskNetType(bool bOnlyCheck)
{
	for (int i = 0; i < Sections.Num(); i++)
	{
		for (int j = 0; j < Sections[i].TaskList.Num(); j++)
		{
			UBSATask* TaskToCheck = Sections[i].TaskList[j];

			if (!TaskToCheck || (TaskToCheck->IgnoreAutoOptimize & 2) > 0 || TaskToCheck->GetNetType() == EBSATaskNet::TN_TMax)
			{
				continue;
			}

			bool HasFollowClientTask = false;
			bool HasFollowServerTask = false;

			TArray<UBSATask*> TasksList;
			TasksList.Add(TaskToCheck);

			for (int k = 0; k < TasksList.Num(); k++)
			{
				for (TMap<FName, FBSATaskSelectorList>::TIterator It(TasksList[k]->EventTaskMap); It; ++It)
				{
					for (int l = 0; l < It.Value().SelectedTaskList.Num(); l++)
					{
						if (UBSATask* SelectedTask = Cast<UBSATask>(It.Value().SelectedTaskList[l].SelectedTask))
						{
							TasksList.AddUnique(SelectedTask);
							switch (SelectedTask->GetNetType())
							{
							case EBSATaskNet::TN_ServerOnly:
								HasFollowServerTask = true;
								break;
							case EBSATaskNet::TN_OnlyClient:
							case EBSATaskNet::TN_OnlyLocalClient:
							case EBSATaskNet::TN_NonLocalClient:
								HasFollowClientTask = true;
								break;
							case EBSATaskNet::TN_ServerAndClient:
							case EBSATaskNet::TN_ServerAndLocalClient:
								HasFollowClientTask = true;
								HasFollowServerTask = true;
								break;
							}

							if (HasFollowClientTask && HasFollowServerTask)
							{
								break;
							}
						}
					}
					if (HasFollowClientTask && HasFollowServerTask)
					{
						break;
					}
				}
				if (HasFollowClientTask && HasFollowServerTask)
				{
					break;
				}
			}

			if (TaskToCheck->GetNetType() == EBSATaskNet::TN_ServerAndClient)
			{
				// 后面只跟了一种类型的Task，那么没必要设置为双端Task
				if (HasFollowServerTask != HasFollowClientTask)
				{
					if (HasFollowServerTask)
					{
						// 仅仅检查一下
						if (bOnlyCheck)
						{
							ConfigProblemNumber += 1;
							return;
						}

						// 消息框显示的消息内容
						FText DialogText = FText::Format
						(
							LOCTEXT("Auto Optimize Suggestion", "{0} 后续触发均为服务器Task，建议将NetType改为ServerOnly，是否自动执行？"),
							FText::FromString(TaskToCheck->GetName())
						);

						EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
						if (ReturnType == EAppReturnType::Type::Yes)
						{
							TaskToCheck->SetNetType(EBSATaskNet::TN_ServerOnly);

							GetPackage()->MarkPackageDirty();

							ConfigProblemNumber = FMath::Max(0, ConfigProblemNumber - 1);
						}
					}
					else
					{
						// 仅仅检查一下
						if (bOnlyCheck)
						{
							ConfigProblemNumber += 1;
							return;
						}

						// 消息框显示的消息内容
						FText DialogText = FText::Format
						(
							LOCTEXT("Auto Optimize Suggestion", "{0} 后续触发均为客户端Task，建议将NetType改为OnlyClient，是否自动执行？"),
							FText::FromString(TaskToCheck->GetName())
						);

						EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
						if (ReturnType == EAppReturnType::Type::Yes)
						{
							TaskToCheck->SetNetType(EBSATaskNet::TN_OnlyClient);
							GetPackage()->MarkPackageDirty();

							ConfigProblemNumber = FMath::Max(0, ConfigProblemNumber - 1);
						}
					}
				}
			}
			else if (TaskToCheck->GetNetType() == EBSATaskNet::TN_OnlyClient || TaskToCheck->GetNetType() == EBSATaskNet::TN_OnlyLocalClient || TaskToCheck->GetNetType() == EBSATaskNet::TN_NonLocalClient)
			{
				// 客户端Task后面不能跟服务端Task，仅QTE是个例外
				if (HasFollowServerTask)
				{
					// 仅仅检查一下
					if (bOnlyCheck)
					{
						ConfigProblemNumber += 1;
						return;
					}

					// 消息框显示的消息内容
					FText DialogText = FText::Format
					(
						LOCTEXT("Auto Optimize Warning", "纯客户端Task {0} 后续触发服务端的Task，建议将NetType改为ServerAndClient否则服务端Task无法运行，是否自动执行？"),
						FText::FromString(TaskToCheck->GetName())
					);

					EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
					if (ReturnType == EAppReturnType::Type::Yes)
					{
						TaskToCheck->SetNetType(EBSATaskNet::TN_ServerAndClient);
						GetPackage()->MarkPackageDirty();

						ConfigProblemNumber = FMath::Max(0, ConfigProblemNumber - 1);
					}
				}
			}
		}
	}
}

void UBSAAsset::CheckTaskRedundantTrigger(bool bOnlyCheck)
{
	for (int i = 0; i < Sections.Num(); i++)
	{
		for (int j = 0; j < Sections[i].TaskList.Num(); j++)
		{
			bool CheckRes = false;

			UBSATask* TaskToCheck = Sections[i].TaskList[j];

			if (!TaskToCheck || (TaskToCheck->IgnoreAutoOptimize & 4) > 0 || TaskToCheck->GetNetType() == EBSATaskNet::TN_TMax)
			{
				// 无效标志不做检查
				continue;
			}

			if ((TaskToCheck->GetTriggerMethod() & 1))
			{
				for (int a = 0; a < Sections.Num(); a++)
				{
					for (int b = 0; b < Sections[a].TaskList.Num(); b++)
					{
						for (TMap<FName, FBSATaskSelectorList>::TIterator It(Sections[a].TaskList[b]->EventTaskMap); It; ++It)
						{
							for (int l = 0; l < It.Value().SelectedTaskList.Num(); l++)
							{
								if (TaskToCheck == Cast<UBSATask>(It.Value().SelectedTaskList[l].SelectedTask))
								{
									CheckRes = true;
									break;
								}
							}
							if (CheckRes)break;
						}
						if (CheckRes)break;
					}
					if (CheckRes)break;
				}

				if (CheckRes)
				{
					// 仅仅检查一下
					if (bOnlyCheck)
					{
						ConfigProblemNumber += 1;
						return;
					}

					// 消息框显示的消息内容
					FText DialogText = FText::Format
					(
						LOCTEXT("Auto Optimize Suggestion", "{0} 可由其他Task事件触发的同时还能由时间轴触发，建议取消TriggerMethod中的时间轴触发，是否自动执行？"),
						FText::FromString(TaskToCheck->GetName())
					);

					EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
					if (ReturnType == EAppReturnType::Type::Yes)
					{
						TaskToCheck->SetTriggerMethod(TaskToCheck->GetTriggerMethod() - 1);
						GetPackage()->MarkPackageDirty();

						ConfigProblemNumber = FMath::Max(0, ConfigProblemNumber - 1);
					}
				}
			}
		}
	}
}

void UBSAAsset::CheckTaskNonTrigger(bool bOnlyCheck)
{
	TArray<UBSATask*> TaskNonTriggerList;
	TArray<UBSATask*> TaskNonTriggerListToDelete;

	for (int i = 0; i < Sections.Num(); i++)
	{
		for (int j = 0; j < Sections[i].TaskList.Num(); j++)
		{
			bool CheckRes = false;

			UBSATask* TaskToCheck = Sections[i].TaskList[j];

			if (!TaskToCheck || (TaskToCheck->IgnoreAutoOptimize & 8) > 0 || TaskToCheck->GetNetType() == EBSATaskNet::TN_TMax)
			{
				// 无效标志不做检查
				continue;
			}

			if (TaskToCheck->GetTriggerMethod() == 0)
			{
				// 无触发标记，检查是否有Task的event与它相连
				for (int a = 0; a < Sections.Num(); a++)
				{
					for (int b = 0; b < Sections[a].TaskList.Num(); b++)
					{
						if (TaskNonTriggerList.Contains(Sections[a].TaskList[b]))
						{
							// 已经被认为是无效的Task不再检查
							continue;
						}
						for (TMap<FName, FBSATaskSelectorList>::TIterator It(Sections[a].TaskList[b]->EventTaskMap); It; ++It)
						{
							for (int l = 0; l < It.Value().SelectedTaskList.Num(); l++)
							{
								if (TaskToCheck == Cast<UBSATask>(It.Value().SelectedTaskList[l].SelectedTask))
								{
									CheckRes = true;
									break;
								}
							}
							if (CheckRes)break;
						}
						if (CheckRes)break;
					}
					if (CheckRes)break;
				}
			}
			else if (TaskToCheck->GetTriggerMethod() == 1)
			{
				CheckRes = true;
			}
			else
			{
				// 其他种类的触发都认为是合理的
				CheckRes = true;
			}

			if (!CheckRes)
			{
				// 仅仅检查一下
				if (bOnlyCheck)
				{
					ConfigProblemNumber += 1;
					return;
				}

				TaskNonTriggerList.Add(TaskToCheck);
				// 消息框显示的消息内容
				FText DialogText = FText::Format
				(
					LOCTEXT("Auto Optimize Warning", "{0} 无法由任何方式触发，建议删除，是否自动执行？"),
					FText::FromString(TaskToCheck->GetName())
				);

				EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
				if (ReturnType == EAppReturnType::Type::Yes)
				{
					TaskNonTriggerListToDelete.Add(TaskToCheck);

					ConfigProblemNumber = FMath::Max(0, ConfigProblemNumber - 1);
				}
			}
		}
	}

	int32 SectionID = -1;
	int32 GroupID = -1;
	for (int i = 0; i < TaskNonTriggerListToDelete.Num(); i++)
	{
		GetSectionIDAndGroupID(*TaskNonTriggerListToDelete[i], SectionID, GroupID);

		// 删除无效Task
		RemoveTask(SectionID, GroupID, *TaskNonTriggerListToDelete[i]);

		// 检查对应Gruop，如果没有其他Task，那么顺便删除Group
		if (Sections[SectionID].TaskGroups[GroupID].TaskList.Num() < 1)
		{
			RemoveGroup(SectionID, GroupID);
		}

		GetPackage()->MarkPackageDirty();
	}
}

void UBSAAsset::CheckEventListenerLifeType(bool bOnlyCheck)
{
	for (int i = 0; i < Sections.Num(); i++)
	{
		for (int j = 0; j < Sections[i].TaskList.Num(); j++)
		{
			bool CheckResult = false;

			TArray<UBSATask*> ErrorTasks;

			UBSATEventListener* BSATEL = Cast<UBSATEventListener>(Sections[i].TaskList[j]);
			if (!IsValid(BSATEL))
			{
				continue;
			}

			for (TMap<FName, FBSATaskSelectorList>::TIterator It1(BSATEL->EventTaskMap); It1; ++It1)
			{
				for (TArray<FBSATaskSelector>::TIterator It2(It1->Value.SelectedTaskList); It2; ++It2)
				{
					UBSATask* BSAT = Cast<UBSATask>(It2->SelectedTask);
					if (!IsValid(BSAT))
					{
						continue;
					}

					// 如果是上层控制，会有风险
					if (BSAT->GetLifeType() == EBSATaskLife::TL_ByController)
					{
						CheckResult = true;
						ErrorTasks.Add(BSAT);
					}

					// 如果带有时长，可能会有风险
					if (BSAT->GetLifeType() == EBSATaskLife::TL_DurAndController || BSAT->GetLifeType() == EBSATaskLife::TL_ForceDuration)
					{
						if (BSAT->GetDuration() > 10.0f)
						{
							CheckResult = true;
							ErrorTasks.Add(BSAT);
						}
					}
				}
			}

			if (CheckResult)
			{
				// 仅仅检查一下
				if (bOnlyCheck)
				{
					ConfigProblemNumber += 1;
					return;
				}

				// 消息框显示的消息内容
				FText DialogText = FText::Format
				(
					LOCTEXT("Auto Optimize Suggestion", "{0} 检测到事件监听Task会触发生命周期不是立即结束，且长时间执行的子Task，此行为有一定风险，建议调整子Task的生命周期，是否自动执行？"),
					FText::FromString(BSATEL->GetName())
				);

				EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
				if (ReturnType == EAppReturnType::Type::Yes)
				{
					for (TArray<UBSATask*>::TIterator It(ErrorTasks); It; ++It)
					{
						UBSATask* Task = (*It);
						if (!IsValid(Task))
						{
							continue;
						}

						// 如果是上层控制，会有风险
						if (Task->GetLifeType() == EBSATaskLife::TL_ByController)
						{
							Task->SetLifeType(EBSATaskLife::TL_Instant);
						}

						// 如果带有时长，可能会有风险
						if (Task->GetLifeType() == EBSATaskLife::TL_DurAndController || Task->GetLifeType() == EBSATaskLife::TL_ForceDuration)
						{
							Task->SetDuration(9.0f);
						}
					}

					GetPackage()->MarkPackageDirty();

					ConfigProblemNumber = FMath::Max(0, ConfigProblemNumber - 1);
				}
			}
		}
	}
}

void UBSAAsset::CheckBuffStackableSection(bool bOnlyCheck)
{
	if (!IsA<UBSABuffAsset>() || !Sections.IsValidIndex(0))
	{
		return;
	}

	for (int j = 0; j < Sections[0].TaskList.Num(); j++)
	{
		if (UBSATask* BSAT = Cast<UBSATask>(Sections[0].TaskList[j]))
		{
			if (BSAT->GetNetType() < EBSATaskNet::TN_OnlyClient)
			{
				// 仅仅检查一下
				if (bOnlyCheck)
				{
					ConfigProblemNumber += 1;
					return;
				}

				// 消息框显示的消息内容
				FText DialogText = FText::Format(LOCTEXT("Auto Optimize Suggestion", "{0} BUFF可叠加轨道的Task的NetType不再支持服务器相关类型，请修改为客户端类型，是否自动执行？"), FText::FromString(BSAT->GetName()));

				EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
				if (ReturnType == EAppReturnType::Type::Yes)
				{
					BSAT->SetNetType(EBSATaskNet::TN_OnlyClient);

					GetPackage()->MarkPackageDirty();

					ConfigProblemNumber = FMath::Max(0, ConfigProblemNumber - 1);
				}
			}
		}
	}
}

void UBSAAsset::CheckBuffGlobalSection(bool bOnlyCheck)
{
	if (!IsA<UBSABuffAsset>() || !Sections.IsValidIndex(1))
	{
		return;
	}

	for (int j = 0; j < Sections[1].TaskList.Num(); j++)
	{
		if (UBSATask* BSAT = Cast<UBSATask>(Sections[1].TaskList[j]))
		{
			if (BSAT->GetNetType() <= EBSATaskNet::TN_ServerAndLocalClient && BSAT->GetStartTime() > 1e-4)
			{
				// 仅仅检查一下
				if (bOnlyCheck)
				{
					ConfigProblemNumber += 1;
					return;
				}

				// 消息框显示的消息内容
				FText DialogText = FText::Format(LOCTEXT("Auto Optimize Suggestion", "{0} BUFF全局轨道中NetType为服务器相关的Task，起始时间必须是0，是否自动执行？"), FText::FromString(BSAT->GetName()));

				EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);
				if (ReturnType == EAppReturnType::Type::Yes)
				{
					BSAT->SetStartTime(0.0f);

					GetPackage()->MarkPackageDirty();

					ConfigProblemNumber = FMath::Max(0, ConfigProblemNumber - 1);
				}
			}
		}
	}
}

void UBSAAsset::CheckSectionAnimationNum(bool bOnlyCheck)
{
	for (int32 i = 0; i < Sections.Num(); i++)
	{
		int32 TaskNum = 0;

		for (int32 j = 0; j < Sections[i].TaskList.Num(); j++)
		{
			UBSATask* task = Sections[i].TaskList[j];
			if (task->IsA<UBSATPlayAnimation>())
			{
				TaskNum += 1;
			}
		}

		if (TaskNum > 3)
		{
			// 仅仅检查一下
			if (bOnlyCheck)
			{
				ConfigProblemNumber += 1 + (TaskNum - 3) / 2;
				return;
			}

			// 消息框显示的消息内容
			FText DialogText = FText::Format
			(
				LOCTEXT
				(
					"Auto Optimize Suggestion", 
					"{0} PlayAnimation Task 数量超出3个，建议在Montage中拼接动画片段。友情提示：这属于重大错误！！！"
				), 
				FText::FromName(Sections[i].Name)
			);

			FMessageDialog::Open(EAppMsgType::Ok, DialogText);
		}
	}
}

void UBSAAsset::CheckNiagaraTotalNumber(bool bOnlyCheck)
{
	for (int32 i = 0; i < Sections.Num(); i++)
	{
		int32 TaskNum = 0;

		for (int32 j = 0; j < Sections[i].TaskList.Num(); j++)
		{
			UBSATask* task = Sections[i].TaskList[j];
			if (task->IsA<UBSATPlayNiagara>())
			{
				TaskNum += 1;
			}
		}

		if (TaskNum > 14)
		{
			// 仅仅检查一下
			if (bOnlyCheck)
			{
				ConfigProblemNumber += 1 + (TaskNum - 14) / 4;
				return;
			}

			// 消息框显示的消息内容
			FText DialogText = FText::Format
			(
				LOCTEXT
				(
					"Auto Optimize Suggestion", 
					"{0} 播放特效数量超出14个，建议减少特效数量，将部分不重要特效进行合并。友情提示：这属于重大错误！！！"
				), 
				FText::FromName(Sections[i].Name)
			);

			FMessageDialog::Open(EAppMsgType::Ok, DialogText);
		}
	}
}

void UBSAAsset::CheckNiagaraDensity(bool bOnlyCheck)
{
	for (int32 i = 0; i < Sections.Num(); i++)
	{
		TMap<int32, TArray<UBSATask*>> NiagaraDensityMap;

		for (int32 j = 0; j < Sections[i].TaskList.Num(); j++)
		{
			UBSATask* Task = Sections[i].TaskList[j];
			if (Task->IsA<UBSATPlayNiagara>())
			{
				int32 FrameNumber = FMath::Floor((Task->GetStartTime() * 10000.0f + 1.0f) / 333.0f);

				if (TArray<UBSATask*>* FR = NiagaraDensityMap.Find(FrameNumber))
				{
					FR->Add(Task);
				}
				else
				{
					NiagaraDensityMap.Add(FrameNumber, { Task });
				}
			}
		}

		for (TMap<int32, TArray<UBSATask*>>::TIterator It(NiagaraDensityMap); It; ++It)
		{
			if (It->Value.Num() > 4)
			{
				// 仅仅检查一下
				if (bOnlyCheck)
				{
					ConfigProblemNumber += 1 + (It->Value.Num() - 4) / 2;
					return;
				}

				// 消息框显示的消息内容
				FText DialogText = FText::Format
				(
					LOCTEXT
					(
						"Auto Optimize Suggestion", 
						"时间轴:{0}，在第{1}帧播放特效数量超出4个，建议减少该帧特效数量，请分摊到其他帧！！！友情提示：这属于非常重大错误！！！！！"
					), 
					FText::FromName(Sections[i].Name), 
					FText::FromString(FString::FromInt(It->Key)
					)
				);

				FMessageDialog::Open(EAppMsgType::Ok, DialogText);
			}
		}
	}
}

void UBSAAsset::CheckAudioAsset(bool bOnlyCheck)
{
	for (int32 i = 0; i < Sections.Num(); i++)
	{
		int32 TaskNum = 0;

		for (int32 j = 0; j < Sections[i].TaskList.Num(); j++)
		{
			UBSATask* Task = Sections[i].TaskList[j];
			if (Task->IsA<UBSATAkAudioEvent>())
			{
				UBSATAkAudioEvent* AkEventTask = Cast<UBSATAkAudioEvent>(Task);
				if (AkEventTask->AkEvent == nullptr)
				{
					// 仅仅检查一下
					if (bOnlyCheck)
					{
						ConfigProblemNumber += 1;
						return;
					}

					// 消息框显示的消息内容
					FText DialogText = FText::Format
					(
						LOCTEXT
						(
							"Auto Optimize Suggestion", 
							"{0} AkAudioEvent Task 的 AkEvent为空！请检查资源配置"
						), 
						FText::FromName(Sections[i].Name)
					);

					FMessageDialog::Open(EAppMsgType::Ok, DialogText);
				}
				
			}
		}

		if (TaskNum > 3)
		{
			// 仅仅检查一下
			if (bOnlyCheck)
			{
				ConfigProblemNumber += 1 + (TaskNum - 3) / 2;
				return;
			}

			
		}
	}
}
#endif

#undef LOCTEXT_NAMESPACE
#pragma endregion AutoOptimize



#pragma region Statistics
void UBSAAsset::UpdateNiagaraNumber()
{
	AssetNiagaraNum = 0;

	TArray<TPair<float, int32>> PlayNiagaraKeyOperation;
	int32 AdditionNum = 0, CurrentNum = 0;

	for (int i = 0; i < Sections.Num(); i++)
	{
		// 每个Section单独统计
		PlayNiagaraKeyOperation.Empty();
		AdditionNum = 0; CurrentNum = 0;

		for (int j = 0; j < Sections[i].TaskList.Num(); j++)
		{
			if (UBSATPlayNiagara* CurPlayNiagaraTask = Cast<UBSATPlayNiagara>(Sections[i].TaskList[j]))
			{
				if (CurPlayNiagaraTask->IsTaskInvalid())
				{
					continue;
				}

				if (CurPlayNiagaraTask->GetLifeType() != EBSATaskLife::TL_Instant && CurPlayNiagaraTask->bDestroyWhenTaskEnd == true)
				{
					// 由Task控制生命周期的Niagara可以准确计算时间轴内实际特效数量需求
					PlayNiagaraKeyOperation.Add(TPair<float, int32>(CurPlayNiagaraTask->GetStartTime(), 1));
					PlayNiagaraKeyOperation.Add(TPair<float, int32>(CurPlayNiagaraTask->GetStartTime() + CurPlayNiagaraTask->GetDuration(), -1));
					continue;
				}

				// 其余情况暂时认为整个技能Buff时间轴均需要
				AssetNiagaraNum += 1;
			}
		}

		// 按照时间排序
		PlayNiagaraKeyOperation.Sort
		(
			[](const TPair<float, int32>& A, const TPair<float, int32>& B)
			{
				return A.Key < B.Key;
			}
		);

		for (int32 k = 0; k < PlayNiagaraKeyOperation.Num(); k++)
		{
			CurrentNum = CurrentNum + PlayNiagaraKeyOperation[k].Value;
			AdditionNum = FMath::Max(AdditionNum, CurrentNum);
		}

		AssetNiagaraNum += AdditionNum;
	}
}
#pragma endregion Statistics