#include "BattleSystemEditor/AbilityEditor/Ability/BSABuffAsset.h"
#include "GameFramework/WorldSettings.h"

#include "BattleSystem/Ability/BSAEnums.h"
#include "BattleSystem/BSMacroDefinition.h"
#include "BattleSystemEditor/AbilityEditor/Preview/BSAPreviewGameMode.h"



UBSABuffAsset::UBSABuffAsset(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
#if WITH_EDITOR
	Sections.Add(FBSATaskSection(TEXT("可叠加任务列表")));

	Sections.Add(FBSATaskSection(TEXT("全局任务列表")));
	Sections.Last().SectionDuration = 10.0f;
#endif
}



#pragma region API
#if WITH_EDITOR
void UBSABuffAsset::InitByEditor(UObject* WorldContext)
{
	if (!bHasInit)
	{
		if (WorldContext && WorldContext->GetWorld() && WorldContext->GetWorld()->GetWorldSettings() && WorldContext->GetWorld()->GetWorldSettings()->DefaultGameMode)
		{
			if (const ABSAPreviewGameMode* GameMode = GetDefault<ABSAPreviewGameMode>(WorldContext->GetWorld()->GetWorldSettings()->DefaultGameMode))
			{
				for (int32 i = 0; i < GameMode->BuffDefaultTaskList.TaskList.Num(); ++i)
				{
					if (GameMode->BuffDefaultTaskList.TaskList[i])
					{
						if (UBSATask* NewTask = NewObject<UBSATask>(this, GameMode->BuffDefaultTaskList.TaskList[i]->GetClass(), NAME_None, RF_Transactional, GameMode->BuffDefaultTaskList.TaskList[i]))
						{
							AddTask(1, 0, *NewTask);
						}
					}
				}
			}
		}
	}

	Super::InitByEditor(WorldContext);
}

void UBSABuffAsset::PreEditChange(FProperty* PropertyThatWillChange)
{


	Super::PreEditChange(PropertyThatWillChange);
}

void UBSABuffAsset::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (Sections.IsValidIndex(0))
	{
		Sections[0].LoopTime = 1;
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBSABuffAsset::PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

void UBSABuffAsset::ChangeSectionName(int32 SectionID, FName NewName)
{
	return;
}

void UBSABuffAsset::ChangeSectionLoopTime(int32 SectionID, int32 NewLoop)
{
	return;
}

void UBSABuffAsset::ChangeSectionDuration(int32 SectionID, float NewDuration)
{
	if (SectionID == 0)
	{
		return;
	}
	else
	{
		Super::ChangeSectionDuration(SectionID, NewDuration);
	}
}

#endif
#pragma endregion API