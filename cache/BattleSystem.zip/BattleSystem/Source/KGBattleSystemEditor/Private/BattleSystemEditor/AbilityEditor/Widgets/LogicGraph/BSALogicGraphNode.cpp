#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/BSALogicGraphNode.h"
#include "UObject/ObjectSaveContext.h"
#include "Kismet2/Kismet2NameValidators.h"
#include "Kismet2/BlueprintEditorUtils.h"

#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/SBSALogicGraphNode.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"



#define LOCTEXT_NAMESPACE "BSALogicGraphNode"



#pragma region Important
UBSALogicGraphNode::UBSALogicGraphNode()
{
	bCanRenameNode = false;
}

UBSALogicGraphNode::~UBSALogicGraphNode()
{

}

void UBSALogicGraphNode::PreSave(FObjectPreSaveContext ObjectSaveContext)
{
	Super::PreSave(ObjectSaveContext);

	if (!CachedTask)
		return;

	for (int32 i = 0; i < Pins.Num(); ++i)
	{
		FBSALGNodePin* CurPinInfo = GetPinInformation(Pins[i]);
		if (!CurPinInfo)
			continue;

		// 更新Task事件触发列表
		if (CurPinInfo->PinType == 1)
		{
			if (FBSATaskSelectorList* SubTaskList = CachedTask->EventTaskMap.Find(CurPinInfo->ExtraName))
			{
				SubTaskList->SelectedTaskList.Empty();

				for (int32 j = 0; j < Pins[i]->LinkedTo.Num(); ++j)
				{
					if (UBSALogicGraphNode* CurNode = Cast<UBSALogicGraphNode>(Pins[i]->LinkedTo[j]->GetOwningNode()))
					{
						FBSATaskSelector NewSub;
						NewSub.Owner = CachedTask;
						NewSub.SelectedTask = CurNode->CachedTask;

						SubTaskList->SelectedTaskList.Add(NewSub);
					}
				}
			}
		}
		// 更新碰撞信息列表
		else if (CurPinInfo->PinType == 2)
		{
			TArray<FBSATaskInputInfo> TaskCollisionInfos;
			CachedTask->GetCollisionTargetInfos(TaskCollisionInfos);
			for (int32 j = 0; j < TaskCollisionInfos.Num(); ++j)
			{
				if (TaskCollisionInfos[j].GetRandID() == CurPinInfo->DataRandID)
				{
					if (Pins[i]->LinkedTo.Num() > 0)
					{
						if (UBSALogicGraphNode* TargetNode = Cast<UBSALogicGraphNode>(Pins[i]->LinkedTo[0]->GetOwningNode()))
						{
							if (FBSALGNodePin* TargetPin = TargetNode->GetPinInformation(Pins[i]->LinkedTo[0]))
							{
								CachedTask->SetCollisionTargetInfo(j, TargetPin->ExtraName, TargetNode->CachedTask);
							}
						}
					}
					else
					{
						CachedTask->SetCollisionTargetInfo(j, NAME_None, nullptr);
					}

					break;
				}
			}
		}
		// 更新输入信息列表
		else if (CurPinInfo->PinType == 3)
		{
			for (int32 j = 0; j < CachedTask->InputDatas.Num(); ++j)
			{
				if (CachedTask->InputDatas[j].GetRandID() == CurPinInfo->DataRandID)
				{
					if (Pins[i]->LinkedTo.Num() > 0)
					{
						if (UBSALogicGraphNode* TargetNode = Cast<UBSALogicGraphNode>(Pins[i]->LinkedTo[0]->GetOwningNode()))
						{
							if (FBSALGNodePin* TargetPin = TargetNode->GetPinInformation(Pins[i]->LinkedTo[0]))
							{
								CachedTask->SetInputDataInfo(j, TargetPin->ExtraName, TargetNode->CachedTask);
							}
						}
					}
					else
					{
						CachedTask->SetInputDataInfo(j, NAME_None, nullptr);
					}

					break;
				}
			}
		}
	}
}

#pragma endregion Important



#pragma region Pin
void UBSALogicGraphNode::AllocateDefaultPins()
{
	if (CachedTask)
	{
		RefreshPinInformationList(PinInformations);

		for (int32 i = 0; i < PinInformations.Num(); ++i)
		{
			CreatePinByInformation(PinInformations[i]);
		}
	}
}

void UBSALogicGraphNode::UpdatePins()
{
	if (CachedTask)
	{
		TArray<FBSALGNodePin> NewPinInformationList;
		RefreshPinInformationList(NewPinInformationList);

		// 第一次循环，将目前没有，之前已有的删除
		for (int32 i = 0; i < PinInformations.Num(); ++i)
		{
			int32 Index = NewPinInformationList.Find(PinInformations[i]);
			if (Index >= 0)
			{
				NewPinInformationList[Index].PinGUIDName = PinInformations[i].PinGUIDName;
			}
			else
			{
				FGuid CurGuid;
				FGuid::Parse(PinInformations[i].PinGUIDName.ToString(), CurGuid);

				UEdGraphPin* CurPin = GetPinByGUID(CurGuid);
				if (CurPin)
					RemovePin(CurPin);
			}
		}

		// 第二次循环，将目前已有，之前没有的添加
		for (int32 i = 0; i < NewPinInformationList.Num(); ++i)
		{
			int32 Index = PinInformations.Find(NewPinInformationList[i]);
			if (Index >= 0)
			{
				NewPinInformationList[i].PinGUIDName = PinInformations[Index].PinGUIDName;
			}
			else
			{
				CreatePinByInformation(NewPinInformationList[i]);
			}
		}

		PinInformations.Empty();
		PinInformations.Append(NewPinInformationList);
	}
}

FLinearColor UBSALogicGraphNode::GetPinColor(const UEdGraphPin* InPin)
{
	if (FBSALGNodePin* PinInfo = GetPinInformation(InPin))
	{
		if (PinInfo->PinType == 0 || PinInfo->PinType == 1)
			return FLinearColor::White;
		else
			return FLinearColor::Yellow;
	}

	return FLinearColor::Red;
}

FBSALGNodePin* UBSALogicGraphNode::GetPinInformation(const UEdGraphPin* InPin)
{
	if (Pins.Contains(InPin))
	{
		FName GUIDName = FName(InPin->PinId.ToString());

		for (int32 i = 0; i < PinInformations.Num(); ++i)
		{
			if (PinInformations[i].PinGUIDName.IsEqual(GUIDName))
			{
				return &PinInformations[i];
			}
		}
	}

	return nullptr;
}

void UBSALogicGraphNode::GetPinDataType(const UEdGraphPin* InPin, EBSDataType& OutType, UScriptStruct*& OutStructType)
{
	if (!CachedTask)
		return;

	if (FBSALGNodePin* PinInfo = GetPinInformation(InPin))
	{
		if (PinInfo->PinType == 2)
		{
			TArray<FBSATaskInputInfo> TaskCollisionInfos;
			CachedTask->GetCollisionTargetInfos(TaskCollisionInfos);
			for (int32 i = 0; i < TaskCollisionInfos.Num(); ++i)
			{
				if (TaskCollisionInfos[i].GetRandID() == PinInfo->DataRandID)
				{
					OutType = TaskCollisionInfos[i].DataType;
					OutStructType = TaskCollisionInfos[i].StructType;

					return;
				}
			}
		}
		else if (PinInfo->PinType == 3)
		{
			for (int32 i = 0; i < CachedTask->InputDatas.Num(); ++i)
			{
				if (CachedTask->InputDatas[i].GetRandID() == PinInfo->DataRandID)
				{
					OutType = CachedTask->InputDatas[i].DataType;
					OutStructType = CachedTask->InputDatas[i].StructType;

					return;
				}
			}
		}
		else if (PinInfo->PinType == 4)
		{
			for (int32 i = 0; i < CachedTask->OutputDatas.Num(); ++i)
			{
				if (CachedTask->OutputDatas[i].GetRandID() == PinInfo->DataRandID)
				{
					OutType = CachedTask->OutputDatas[i].DataType;
					OutStructType = CachedTask->OutputDatas[i].StructType;

					return;
				}
			}
		}
	}
}

FName UBSALogicGraphNode::GetPinNameFromTagName(const FName& InTag)
{
	FString TagString = InTag.ToString();
	int32 LastPointPos = 0;
	TagString.FindLastChar('.', LastPointPos);
	TagString = TagString.Right(TagString.Len() - LastPointPos - 1);

	return FName(TagString);
}

void UBSALogicGraphNode::RefreshPinInformationList(TArray<FBSALGNodePin>& InPinInformationList)
{
	InPinInformationList.Empty();


	FBSALGNodePin PinInfo;
	PinInfo.PinType = 0;
	PinInfo.ExtraName = TEXT("Exe");
	InPinInformationList.Add(PinInfo);


	for (TMap<FName, FBSATaskSelectorList>::TIterator It(CachedTask->EventTaskMap); It; ++It)
	{
		PinInfo.PinType = 1;
		PinInfo.ExtraName = It->Key;
		InPinInformationList.Add(PinInfo);
	}


	TArray<FBSATaskInputInfo> TaskCollisionInfos;
	CachedTask->GetCollisionTargetInfos(TaskCollisionInfos);
	for (TArray<FBSATaskInputInfo>::TIterator It(TaskCollisionInfos); It; ++It)
	{
		PinInfo.PinType = 2;
		PinInfo.DataRandID = It->GetRandID();
		PinInfo.ExtraName = It->DisplayName;
		InPinInformationList.Add(PinInfo);
	}


	for (TArray<FBSATaskInputInfo>::TIterator It(CachedTask->InputDatas); It; ++It)
	{
		PinInfo.PinType = 3;
		PinInfo.DataRandID = It->GetRandID();
		PinInfo.ExtraName = It->DisplayName;
		InPinInformationList.Add(PinInfo);
	}


	for (TArray<FBSATaskOutputInfo>::TIterator It(CachedTask->OutputDatas); It; ++It)
	{
		PinInfo.PinType = 4;
		PinInfo.DataRandID = It->GetRandID();
		PinInfo.ExtraName = It->DataDesc;
		InPinInformationList.Add(PinInfo);
	}
}

UEdGraphPin* UBSALogicGraphNode::GetPinByGUID(FGuid InGuid)
{
	for (int32 i = 0; i < Pins.Num(); ++i)
	{
		if (Pins[i]->PinId == InGuid)
		{
			return Pins[i];
		}
	}

	return nullptr;
}

UEdGraphPin* UBSALogicGraphNode::GetPinByName(FName InExtraName)
{
	for (int32 i = 0; i < Pins.Num(); ++i)
	{
		if (Pins[i]->PinName == InExtraName)
		{
			return Pins[i];
		}
	}

	return nullptr;
}

void UBSALogicGraphNode::CreatePinByInformation(FBSALGNodePin& InInformation)
{
	EEdGraphPinDirection CurPinDir;
	if (InInformation.PinType == 1 || InInformation.PinType == 4)
		CurPinDir = EEdGraphPinDirection::EGPD_Output;
	else
		CurPinDir = EEdGraphPinDirection::EGPD_Input;


	FName PinName = InInformation.ExtraName;
	if (InInformation.PinType == 4)
		PinName = GetPinNameFromTagName(PinName);


	UEdGraphPin* NewPin = CreatePin(CurPinDir, TEXT("LogicGraph"), TEXT("TaskNode"), PinName);
	InInformation.PinGUIDName = FName(NewPin->PinId.ToString());
}

#pragma endregion Pin



#pragma region Property
FText UBSALogicGraphNode::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	if (!CachedTask)
		return Super::GetNodeTitle(TitleType);
	else
		return CachedTask->GetTaskName();
}

#pragma endregion Property



#pragma region Edit
void UBSALogicGraphNode::PrepareForCopying()
{

}

void UBSALogicGraphNode::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#pragma endregion Edit



#undef LOCTEXT_NAMESPACE
