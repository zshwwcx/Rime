#include "BattleSystemEditor/AbilityEditor/Modes/BSAEditorMode.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/BSALogicGraph.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"



FBSAEditorMode::FBSAEditorMode(const FName& InModeName, TSharedRef<FBSAEditor> InEditor): FApplicationMode(InModeName), CachedEditor(InEditor)
{
	
}

void FBSAEditorMode::RegisterTabFactories(TSharedPtr<FTabManager> InTabManager)
{
	TSharedPtr<FWorkflowCentricApplication> HostingApp = CachedEditor.Pin();
	HostingApp->RegisterTabSpawners(InTabManager.ToSharedRef());
	HostingApp->PushTabFactories(TabFactories);

	FApplicationMode::RegisterTabFactories(InTabManager);
}

void FBSAEditorMode::AddTabFactory(FCreateWorkflowTabFactory FactoryCreator)
{
	if (FactoryCreator.IsBound())
	{
		TabFactories.RegisterFactory(FactoryCreator.Execute(CachedEditor.Pin()));
	}
}

void FBSAEditorMode::RemoveTabFactory(FName TabFactoryID)
{
	TabFactories.UnregisterFactory(TabFactoryID);
}






FBSAEditorMode_Main::FBSAEditorMode_Main(TSharedRef<FBSAEditor> InEditor) : FBSAEditorMode(BSAEditorModes::Main, InEditor)
{
	// 创建Mode所需的Tabs
	CreateModeTabs(CachedEditor.Pin().ToSharedRef(), TabFactories);

	// 基础布局
	TabLayout = FTabManager::NewLayout("BSAMainLayout")
		->AddArea
		(
			FTabManager::NewPrimaryArea()
			->SetOrientation(Orient_Vertical)
			->Split
			(
				FTabManager::NewStack()
				->SetSizeCoefficient(0.1f)
				->SetHideTabWell(true)
				->AddTab(TEXT("BXAEditor"), ETabState::OpenedTab)
			)
			->Split
			(
				FTabManager::NewSplitter()
				->SetSizeCoefficient(1.f)
				->SetOrientation(Orient_Horizontal)
				// 左
				->Split
				(
					FTabManager::NewStack()
					->SetSizeCoefficient(0.2f)
					->SetHideTabWell(false)
					->AddTab(BSAEditorTabs::AssetDetails, ETabState::OpenedTab)
				)

				// 中
				->Split
				(
					FTabManager::NewSplitter()
					->SetSizeCoefficient(0.6f)
					->SetOrientation(Orient_Vertical)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.6f)
						->SetHideTabWell(true)
						->AddTab(BSAEditorTabs::ViewportTab, ETabState::OpenedTab)
					)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.6f)
						->SetHideTabWell(true)
						->AddTab(BSAEditorTabs::AssetEdit, ETabState::OpenedTab)
					)
				)

				// 右
				->Split
				(
					FTabManager::NewSplitter()
					->SetSizeCoefficient(0.2f)
					->SetOrientation(Orient_Vertical)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.6f)
						->SetHideTabWell(false)
						->AddTab(BSAEditorTabs::Details, ETabState::OpenedTab)
					)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.4f)
						->SetHideTabWell(false)
						->AddTab(BSAEditorTabs::PreviewSettings, ETabState::OpenedTab)
						->AddTab(BSAEditorTabs::AssetBrowser, ETabState::OpenedTab)
					)
				)
			)
		);
}






FBSAEditorMode_LogicGraph::FBSAEditorMode_LogicGraph(const TSharedRef<FBSAEditor> InEditor) : FBSAEditorMode(BSAEditorModes::LogicGraph, InEditor)
{
	// 创建Mode所需的Tabs
	CreateModeTabs(CachedEditor.Pin().ToSharedRef(), TabFactories);


	// 对Tab进行布局
	TabLayout = FTabManager::NewLayout("BSALogicGraphLayout")
		->AddArea
		(
			FTabManager::NewPrimaryArea()
			->SetOrientation(Orient_Vertical)
			->Split
			(
				FTabManager::NewStack()
				->SetSizeCoefficient(0.1f)
				->SetHideTabWell(true)
				->AddTab(TEXT("BXAEditor"), ETabState::OpenedTab)
			)
			->Split
			(
				FTabManager::NewSplitter()
				->SetSizeCoefficient(1.f)
				->SetOrientation(Orient_Horizontal)
				// 左
				->Split
				(
					FTabManager::NewSplitter()
					->SetSizeCoefficient(0.4f)
					->SetOrientation(Orient_Vertical)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.4f)
						->SetHideTabWell(true)
						->AddTab(BSAEditorTabs::ViewportTab, ETabState::OpenedTab)
					)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.6f)
						->SetHideTabWell(true)
						->AddTab(BSAEditorTabs::GraphPallete, ETabState::OpenedTab)
					)
				)
				// 右
				->Split
				(
					FTabManager::NewSplitter()
					->SetSizeCoefficient(0.6f)
					->SetOrientation(Orient_Horizontal)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.6f)
						->SetHideTabWell(true)
						->AddTab(BSAEditorTabs::GraphEdit, ETabState::OpenedTab)
					)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient(0.4f)
						->SetHideTabWell(true)
						->AddTab(BSAEditorTabs::GraphDetail, ETabState::OpenedTab)
					)
				)
			)
		);
}
