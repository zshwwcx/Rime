#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskEventListener.h"



#pragma region EventListener
UBSATEventListener::UBSATEventListener()
{
	EventTaskMap.Add(TEXT("Trigger"), FBSATaskSelectorList());

	EventTaskMap.Add(TEXT("FinishCoolDown"), FBSATaskSelectorList());
}

#if WITH_EDITOR
void UBSATEventListener::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);


}

void UBSATListenPreAttackEvent::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	for (int i = 0; i < DamageCoefficientAttackerConditions.Num(); i++)
	{
		if (DamageCoefficientAttackerConditions[i]) 
		{
			DamageCoefficientAttackerConditions[i]->CheckTarget = EBSAConditionTarget::CT_TMax;
		}

	}
	for (int i = 0; i < DamageCoefficientDefenderConditions.Num(); i++)
	{
		if (DamageCoefficientDefenderConditions[i])
		{
			DamageCoefficientDefenderConditions[i]->CheckTarget = EBSAConditionTarget::CT_TMax;
		}
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}


#endif

#pragma endregion EventListener
