#include "BattleSystemEditor/AbilityEditor/Widgets/SBSAEditorViewport.h"
#include "Editor/EditorEngine.h"
#include "Editor/UnrealEdEngine.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Layout/SBox.h"

#include "Engine/Selection.h"
#include "Slate/SceneViewport.h"
#include "Framework/Commands/UICommandList.h"
#include "Framework/Application/SlateApplication.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorPreviewScene.h"

#include "Viewports.h"
#include "BattleSystemEditor/AbilityEditor/Viewport/BSAEditorViewportToolbar.h"
#include "BattleSystemEditor/AbilityEditor/Viewport/BSAEditorViewportClient.h"



#define LOCTEXT_NAMESPACE "BSAEditorViewport"



SBSAEditorViewport::~SBSAEditorViewport()
{
	UEditorEngine* Editor = (UEditorEngine*)GEngine;
	Editor->OnPreviewFeatureLevelChanged().Remove(PreviewFeatureLevelChangedHandle);
}

void SBSAEditorViewport::Construct(const FArguments& InArgs, const FEditorViewportParameter& InParameter)
{
	CachedEditor = StaticCastSharedRef<FBSAEditor>(InParameter.AssetEditorToolkit);

	SSimpleEditorViewport::Construct
	(
		SSimpleEditorViewport::FArguments()
		.IsEnabled(FSlateApplication::Get().GetNormalExecutionAttribute())
		.AddMetaData<FTagMetaData>(TEXT("BS.BSAEditor.Viewport")),
		InParameter
	);

	TSharedPtr<FBSAEditorPreviewScene> PreviewScene = CachedEditor.Pin()->GetPreviewScene();
	PreviewScene->OnCreateViewport(this, SceneViewport);

	Client->VisibilityDelegate.BindSP(this, &SBSAEditorViewport::IsVisible);
}

void SBSAEditorViewport::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SSimpleEditorViewport::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);

}

TSharedRef<FEditorViewportClient> SBSAEditorViewport::MakeEditorViewportClient()
{
	TSharedPtr<FBSAEditorViewportClient> NewViewportClient = MakeShareable(new FBSAEditorViewportClient(CachedEditor.Pin(), CachedEditor.Pin()->GetPreviewScene().Get(), SharedThis(this)));

	NewViewportClient->ViewportType = LVT_Perspective;
	NewViewportClient->bSetListenerPosition = false;
	NewViewportClient->SetViewLocation(EditorViewportDefs::DefaultPerspectiveViewLocation);
	NewViewportClient->SetViewRotation(EditorViewportDefs::DefaultPerspectiveViewRotation);
	NewViewportClient->SetRealtime(true);
	NewViewportClient->SetShowStats(true);
	ViewportClient = NewViewportClient;

	return NewViewportClient.ToSharedRef();
}

TSharedPtr<SWidget> SBSAEditorViewport::MakeViewportToolbar()
{
	return SNew(SVerticalBox)
	.Visibility(EVisibility::SelfHitTestInvisible)
	+ SVerticalBox::Slot()
	.AutoHeight()
	.VAlign(VAlign_Top)
	[
		SNew(SBSAEditorViewportToolBar, CachedEditor.Pin(), SharedThis(this)).Cursor(EMouseCursor::Default)
	];
}



#undef LOCTEXT_NAMESPACE