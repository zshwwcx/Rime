#include "BattleSystemEditor/AbilityEditor/Modes/BSAEditorMode.h"

#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSADetailTab.h"
#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSATaskPalette.h"
#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSAAssetViewers.h"
#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSAAssetEditTab.h"
#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSAAssetBrowserTab.h"
#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSAEditorViewportTab.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/BSAPreviewSettings.h"



#define DECLARE_TAB_SUMMONER_BEGIN(SummonerName, TabIdentify) \
struct SummonerName : public FWorkflowTabFactory \
{ \
public: \
	static TSharedRef<class FWorkflowTabFactory> Create(const TSharedRef<class FWorkflowCentricApplication>& InHostingApp) \
	{ \
		return MakeShareable(new SummonerName(InHostingApp)); \
	} \
public: \
	SummonerName(TSharedPtr<class FAssetEditorToolkit> InHostingApp) \
		: FWorkflowTabFactory(TabIdentify, InHostingApp) {}

#define DECLARE_TAB_SUMMONER_END };



// 创建预览窗口
DECLARE_TAB_SUMMONER_BEGIN(FEditorViewportSummoner, BSAEditorTabs::ViewportTab)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FBSAEditor> BSAEditor = StaticCastSharedPtr<FBSAEditor>(HostingApp.Pin());
	return SNew(SBSAEditorViewportTab, BSAEditor.ToSharedRef(), BSAEditor->GetPreviewScene().ToSharedRef(), 0);
}
DECLARE_TAB_SUMMONER_END



// 创建时间轴
DECLARE_TAB_SUMMONER_BEGIN(FAssetEditSummoner, BSAEditorTabs::AssetEdit)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FBSAEditor> BSAEditor = StaticCastSharedPtr<FBSAEditor>(HostingApp.Pin());
	return SNew(SBSAAssetEditTab, BSAEditor);
}
DECLARE_TAB_SUMMONER_END



// 创建资源预览器
DECLARE_TAB_SUMMONER_BEGIN(FAssetBrowserSummoner, BSAEditorTabs::AssetBrowser)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	return SNew(SBSAAssetBrowser);
}
DECLARE_TAB_SUMMONER_END



// 创建资源属性面板
DECLARE_TAB_SUMMONER_BEGIN(FAssetDetailSummoner, BSAEditorTabs::AssetDetails)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FBSAEditor> BSAEditor = StaticCastSharedPtr<FBSAEditor>(HostingApp.Pin());
	return SNew(SBSAAssetPropertyTabBody, BSAEditor.ToSharedRef());
}
DECLARE_TAB_SUMMONER_END



// 创建Task属性面板
DECLARE_TAB_SUMMONER_BEGIN(FDetailTabSummoner, BSAEditorTabs::Details)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FBSAEditor> BSAEditor = StaticCastSharedPtr<FBSAEditor>(HostingApp.Pin());

	TSharedPtr<SBSADetailTab> DetailsTab = SNew(SBSADetailTab);
	BSAEditor->SetDetailWidget(DetailsTab);

	return DetailsTab.ToSharedRef();
}
DECLARE_TAB_SUMMONER_END



// 预览配置面板
DECLARE_TAB_SUMMONER_BEGIN(FPreviewSettingSummoner, BSAEditorTabs::PreviewSettings)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FBSAEditor> BSAEditor = StaticCastSharedPtr<FBSAEditor>(HostingApp.Pin());

	TArray<FAdvancedPreviewSceneModule::FDetailCustomizationInfo> DetailsCustomizations;
	TArray<FAdvancedPreviewSceneModule::FPropertyTypeCustomizationInfo> PropertyTypeCustomizations;

	FAdvancedPreviewSceneModule& AdvancedPreviewSceneModule = FModuleManager::LoadModuleChecked<FAdvancedPreviewSceneModule>("AdvancedPreviewScene");
	return AdvancedPreviewSceneModule.CreateAdvancedPreviewSceneSettingsWidget
	(
		BSAEditor->GetPreviewScene().ToSharedRef(),
		BSAEditor->GetPreviewSettings(),
		DetailsCustomizations, 
		PropertyTypeCustomizations
	);
}
DECLARE_TAB_SUMMONER_END



void FBSAEditorMode_Main::CreateModeTabs(const TSharedRef<FBSAEditor> HostingAppPt, FWorkflowAllowedTabSet& OutTabFactories)
{
	OutTabFactories.RegisterFactory(FEditorViewportSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FAssetEditSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FAssetBrowserSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FAssetDetailSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FDetailTabSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FPreviewSettingSummoner::Create(HostingAppPt));
}






// 图表编辑器
DECLARE_TAB_SUMMONER_BEGIN(FLogicGraphEditorSummoner, BSAEditorTabs::GraphEdit)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FBSAEditor> BSAEditor = StaticCastSharedPtr<FBSAEditor>(HostingApp.Pin());
	
	FGraphAppearanceInfo AppearanceInfo;
	AppearanceInfo.CornerText = FText::FromString(TEXT("LogicGraph"));

	SGraphEditor::FGraphEditorEvents InEvents;
	InEvents.OnSelectionChanged = SGraphEditor::FOnSelectionChanged::CreateSP(BSAEditor.Get(), &FBSAEditor::OnSelectedNodesChanged);

	TSharedPtr<SGraphEditor> NewViewPort;

	SAssignNew(NewViewPort, SGraphEditor)
		.IsEditable(true)
		.Appearance(AppearanceInfo)
		.GraphToEdit(BSAEditor->GetEditingAsset()->LogicGraph)
		.GraphEvents(InEvents)
		.AutoExpandActionMenu(true)
		.ShowGraphStateOverlay(false);
	
	BSAEditor->SetLogicGraphEditor(NewViewPort);

	return NewViewPort.ToSharedRef();
}
DECLARE_TAB_SUMMONER_END



// Task选取器
DECLARE_TAB_SUMMONER_BEGIN(FLogicGraphTaskPalleteSummoner, BSAEditorTabs::GraphPallete)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FBSAEditor> BSAEditor = StaticCastSharedPtr<FBSAEditor>(HostingApp.Pin());

	return SNew(SBSATaskPalette, BSAEditor.ToSharedRef());
}
DECLARE_TAB_SUMMONER_END

// 创建Task属性面板
DECLARE_TAB_SUMMONER_BEGIN(FLogicGraphDetailTabSummoner, BSAEditorTabs::GraphDetail)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FBSAEditor> BSAEditor = StaticCastSharedPtr<FBSAEditor>(HostingApp.Pin());

	TSharedPtr<SBSADetailTab> DetailsTab = SNew(SBSADetailTab);
	BSAEditor->SetGraphDetailWidget(DetailsTab);

	return DetailsTab.ToSharedRef();
}
DECLARE_TAB_SUMMONER_END

void FBSAEditorMode_LogicGraph::CreateModeTabs(const TSharedRef<FBSAEditor> HostingAppPt, FWorkflowAllowedTabSet& OutTabFactories)
{
	OutTabFactories.RegisterFactory(FEditorViewportSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FLogicGraphEditorSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FLogicGraphTaskPalleteSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FLogicGraphDetailTabSummoner::Create(HostingAppPt));

}
