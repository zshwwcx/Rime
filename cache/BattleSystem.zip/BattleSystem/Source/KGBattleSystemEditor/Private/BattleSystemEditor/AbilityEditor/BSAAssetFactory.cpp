#include "BattleSystemEditor/AbilityEditor/BSAAssetFactory.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSASkillAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSABuffAsset.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskTemplate.h"



UBSASkillAssetFactory::UBSASkillAssetFactory(const FObjectInitializer& ObjectInitializer)
{
	bCreateNew = true;
	bEditAfterNew = true;
	SupportedClass = UBSASkillAsset::StaticClass();
}

UObject* UBSASkillAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	UBSASkillAsset* NewSkill = NewObject<UBSASkillAsset>(InParent, Class, Name, Flags | RF_Transactional);
	if (NewSkill)
	{
		const UBSAEditorSettings* EdSettings = GetDefault<UBSAEditorSettings>();

		UClass* PlayerType = EdSettings->PlayerType.Get() ? EdSettings->PlayerType.Get() : UBSAPreviewActor::StaticClass();
		UClass* TargetType = EdSettings->TargetType.Get() ? EdSettings->TargetType.Get() : UBSAPreviewActor::StaticClass();
		UClass* WaterFieldType = EdSettings->WaterFieldType.Get() ? EdSettings->WaterFieldType.Get() : UBSAPreviewActor::StaticClass();
		UClass* GrassFieldType = EdSettings->GrassFieldType.Get() ? EdSettings->GrassFieldType.Get() : UBSAPreviewActor::StaticClass();

		NewSkill->PreviewPlayerInfo = NewObject<UBSAPreviewActor>(NewSkill, PlayerType, NAME_None);
		NewSkill->PreviewPlayerInfo->SpawnTransform.SetLocation(FVector(-150.0f, 0.0f, 100.0f));

		NewSkill->PreviewTargetInfo = NewObject<UBSAPreviewActor>(NewSkill, TargetType, NAME_None);
		NewSkill->PreviewTargetInfo->SpawnTransform.SetLocation(FVector(150.0f, 0.0f, 100.0f));
		NewSkill->PreviewTargetInfo->SpawnTransform.SetRotation(FRotator(0.0f, 180.0f, 0.0f).Quaternion());

		NewSkill->PreviewWaterFieldInfo = NewObject<UBSAPreviewActor>(NewSkill, WaterFieldType, NAME_None);
		NewSkill->PreviewWaterFieldInfo->SpawnTransform.SetLocation(FVector(0.0f, 0.0f, 0.0f));
		NewSkill->PreviewWaterFieldInfo->SpawnTransform.SetRotation(FRotator(0.0f, 0.0f, 0.0f).Quaternion());

		NewSkill->PreviewGrassFieldInfo = NewObject<UBSAPreviewActor>(NewSkill, GrassFieldType, NAME_None);
		NewSkill->PreviewGrassFieldInfo->SpawnTransform.SetLocation(FVector(0.0f, 0.0f, 0.0f));
		NewSkill->PreviewGrassFieldInfo->SpawnTransform.SetRotation(FRotator(0.0f, 0.0f, 0.0f).Quaternion());
	}

	return NewSkill;
}

UObject* UBSASkillAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	return FactoryCreateNew(Class, InParent, Name, Flags, Context, Warn, NAME_None);
}






UBSABuffAssetFactory::UBSABuffAssetFactory(const FObjectInitializer& ObjectInitializer)
{
	bCreateNew = false;
	bEditAfterNew = true;
	SupportedClass = UBSABuffAsset::StaticClass();
}

UObject* UBSABuffAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	UBSABuffAsset* NewBuff = NewObject<UBSABuffAsset>(InParent, Class, Name, Flags | RF_Transactional);
	if (NewBuff)
	{
		const UBSAEditorSettings* EdSettings = GetDefault<UBSAEditorSettings>();

		UClass* PlayerType = EdSettings->PlayerType.Get() ? EdSettings->PlayerType.Get() : UBSAPreviewActor::StaticClass();
		UClass* TargetType = EdSettings->TargetType.Get() ? EdSettings->TargetType.Get() : UBSAPreviewActor::StaticClass();
		UClass* WaterFieldType = EdSettings->WaterFieldType.Get() ? EdSettings->WaterFieldType.Get() : UBSAPreviewActor::StaticClass();
		UClass* GrassFieldType = EdSettings->GrassFieldType.Get() ? EdSettings->GrassFieldType.Get() : UBSAPreviewActor::StaticClass();

		NewBuff->PreviewPlayerInfo = NewObject<UBSAPreviewActor>(NewBuff, PlayerType, NAME_None);
		NewBuff->PreviewPlayerInfo->SpawnTransform.SetLocation(FVector(-150.0f, 0.0f, 100.0f));

		NewBuff->PreviewTargetInfo = NewObject<UBSAPreviewActor>(NewBuff, TargetType, NAME_None);
		NewBuff->PreviewTargetInfo->SpawnTransform.SetLocation(FVector(150.0f, 0.0f, 100.0f));
		NewBuff->PreviewTargetInfo->SpawnTransform.SetRotation(FRotator(0.0f, 180.0f, 0.0f).Quaternion());

		NewBuff->PreviewWaterFieldInfo = NewObject<UBSAPreviewActor>(NewBuff, WaterFieldType, NAME_None);
		NewBuff->PreviewWaterFieldInfo->SpawnTransform.SetLocation(FVector(0.0f, 0.0f, 0.0f));
		NewBuff->PreviewWaterFieldInfo->SpawnTransform.SetRotation(FRotator(0.0f, 0.0f, 0.0f).Quaternion());

		NewBuff->PreviewGrassFieldInfo = NewObject<UBSAPreviewActor>(NewBuff, GrassFieldType, NAME_None);
		NewBuff->PreviewGrassFieldInfo->SpawnTransform.SetLocation(FVector(0.0f, 0.0f, 0.0f));
		NewBuff->PreviewGrassFieldInfo->SpawnTransform.SetRotation(FRotator(0.0f, 0.0f, 0.0f).Quaternion());
	}

	return NewBuff;
}

UObject* UBSABuffAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	return FactoryCreateNew(Class, InParent, Name, Flags, Context, Warn, NAME_None);
}






UBSATaskTemplateAssetFactory::UBSATaskTemplateAssetFactory(const FObjectInitializer& ObjectInitializer)
{
	bCreateNew = false;
	bEditAfterNew = true;
	SupportedClass = UBSATaskTemplate::StaticClass();
}

UObject* UBSATaskTemplateAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	UBSATaskTemplate* NewTaskTemplate = NewObject<UBSATaskTemplate>(InParent, Class, Name, Flags | RF_Transactional);
	return NewTaskTemplate;
}

UObject* UBSATaskTemplateAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	return FactoryCreateNew(Class, InParent, Name, Flags, Context, Warn, NAME_None);
}