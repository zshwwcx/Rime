#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"

#include "3C/Character/BSUnit.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"



UBSAEditorSettings::UBSAEditorSettings(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	
}



#if WITH_EDITOR
void UBSAEditorSettings::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (ExportEnumClasses.Num() <= 0)
	{
		ExportEnumClasses.Add(ABSUnit::StaticClass());
		ExportEnumClasses.Add(UBSATask::StaticClass());
	}
}
#endif
