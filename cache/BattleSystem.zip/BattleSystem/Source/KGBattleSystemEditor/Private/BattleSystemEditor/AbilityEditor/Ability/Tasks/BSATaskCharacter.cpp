#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskCharacter.h"
#include "3C/Movement/RoleMovementComponentBase.h"

#include "BattleSystem/BSFunctionLibrary.h"



#pragma region ActorParameter
#if WITH_EDITOR
void UBSATActorParameterCollection::PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("MeshCollector")))
	{
		OutputDatas.Empty();

		FBSATaskOutputInfo NewInfo;

		NewInfo.DataDesc = FName(TEXT("ActorTransform"));
		NewInfo.DataType = EBSDataType::DT_Struct;
		NewInfo.StructType = TBaseStructure<FTransform>::Get();
		OutputDatas.Add(NewInfo);

		NewInfo.DataDesc = FName(TEXT("ActorRootSize"));
		NewInfo.DataType = EBSDataType::DT_Struct;
		NewInfo.StructType = TBaseStructure<FVector>::Get();
		OutputDatas.Add(NewInfo);

		for (int32 i = 0; i < MeshCollector.Num(); ++i)
		{
			NewInfo.DataDesc = MeshCollector[i].SocketName;
			NewInfo.DataType = EBSDataType::DT_Struct;
			NewInfo.StructType = TBaseStructure<FTransform>::Get();
			OutputDatas.Add(NewInfo);
		}
	}
}
#endif

#pragma endregion ActorParameter
