#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskLogicFlow.h"



UBSATBranch::UBSATBranch()
{
	EventTaskMap.Add(TEXT("Start"), FBSATaskSelectorList());
	EventTaskMap.Add(TEXT("End"), FBSATaskSelectorList());
	EventTaskMap.Add(TEXT("Sucess"), FBSATaskSelectorList());
	EventTaskMap.Add(TEXT("Fail"), FBSATaskSelectorList());
}

#if WITH_EDITOR
void UBSATBranch::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	TargetTypes = 0;

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif






UBSATSwitch::UBSATSwitch()
{
	EventTaskMap.Add(TEXT("Start"), FBSATaskSelectorList());
	EventTaskMap.Add(TEXT("End"), FBSATaskSelectorList());
}

#if WITH_EDITOR
void UBSATSwitch::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	TargetTypes = 0;

	if (PropertyChangedEvent.GetPropertyName().IsEqual(TEXT("ConditionList")))
	{
		for (TMap<FName, FBSATaskSelectorList>::TIterator It(EventTaskMap); It; ++It)
		{
			if (!It->Key.IsEqual("Start") && !It->Key.IsEqual("End"))
			{
				It.RemoveCurrent();
			}
		}

		for (int32 i = 0; i < ConditionList.Num(); ++i)
		{
			FString Key = FString::FromInt(i + 1);
			EventTaskMap.Add(FName(TEXT("S") + Key), FBSATaskSelectorList());
		}
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif






#if WITH_EDITOR
void UBSATTerminateTask::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	for (int32 i = 0; i < TasksToTerminate.SelectedTaskList.Num(); i++)
	{
		TasksToTerminate.SelectedTaskList[i].Owner = this;
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif
