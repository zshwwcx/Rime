#include "BattleSystemEditor/AbilityEditor/TabFactory/SBSATaskPalette.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "EditorWidgetsModule.h"
#include "GraphEditAction.h"

#include "BattleSystemEditor/AbilityEditor/BSAEditor.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "BattleSystemEditor/AbilityEditor/BSALogicGraphSchema.h"
#include "BattleSystemEditor/AbilityEditor/Widgets/LogicGraph/BSALogicGraphNode.h"
#include "EdGraph/EdGraph.h"

#define LOCTEXT_NAMESPACE "BSATaskPalette"



void SBSATaskPaletteItem::Construct(const FArguments& InArgs, FCreateWidgetForActionData* const InCreateData)
{
	TSharedPtr<FEdGraphSchemaAction> GraphAction = InCreateData->Action;
	ActionPtr = InCreateData->Action;

	// 图标控件
	FText IconToolTip = GraphAction->GetTooltipDescription();
	const FSlateBrush* IconBrush = FAppStyle::GetBrush(TEXT("NoBrush"));
	FSlateColor IconColor = FSlateColor::UseForeground();
	TSharedRef<SWidget> IconWidget = CreateIconWidget(IconToolTip, IconBrush, IconColor);

	// 名字控件
	bool bIsReadOnly = false;
	FSlateFontInfo NameFont = FCoreStyle::GetDefaultFontStyle("Regular", 10);
	TSharedRef<SWidget> NameSlotWidget = CreateTextSlotWidget(InCreateData, bIsReadOnly);

	// 创建子控件
	this->ChildSlot
	[
		SNew(SHorizontalBox)
		// 图标
		+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			IconWidget
		]
		// 名字
		+ SHorizontalBox::Slot()
		.FillWidth(1.f)
		.VAlign(VAlign_Center)
		.Padding(3, 0)
		[
			NameSlotWidget
		]
	];
}

FText SBSATaskPaletteItem::GetItemTooltip() const
{
	return ActionPtr.Pin()->GetTooltipDescription();
}






void SBSATaskPalette::Construct(const FArguments& InArgs, const TSharedRef<FBSAEditor>& InAssetEditorToolkit)
{
	CachedEditor = InAssetEditorToolkit;

	// 注册事件
	if (UBSAAsset* EditAsset = CachedEditor.Pin()->GetEditingAsset())
	{
		if (EditAsset->LogicGraph)
		{
			GraphChangedHandle = EditAsset->LogicGraph->AddOnGraphChangedHandler(FOnGraphChanged::FDelegate::CreateRaw(this, &SBSATaskPalette::OnLogicGraphChanged));
		}
	}

	this->ChildSlot
	[
		SNew(SBorder)
		.Padding(2.0f)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		[
			SNew(SVerticalBox)
			+SVerticalBox::Slot()
			[
				SNew(SOverlay)
				+SOverlay::Slot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				[
					SAssignNew(GraphActionMenu, SGraphActionMenu)
					.OnActionDragged(this, &SBSATaskPalette::OnActionDragged)
					.OnCreateWidgetForAction(this, &SBSATaskPalette::OnCreateWidgetForAction)
					.OnCollectAllActions(this, &SBSATaskPalette::CollectAllActions)
					.AutoExpandActionMenu(true)
				]
			]
		]
	];
}

SBSATaskPalette::~SBSATaskPalette()
{
	// 注销事件
	if (CachedEditor.IsValid())
	{
		if (UBSAAsset* EditAsset = CachedEditor.Pin()->GetEditingAsset())
		{
			if (EditAsset->LogicGraph)
			{
				EditAsset->LogicGraph->RemoveOnGraphChangedHandler(GraphChangedHandle);
			}
		}
	}
}

TSharedRef<SWidget> SBSATaskPalette::OnCreateWidgetForAction(FCreateWidgetForActionData* const InCreateData)
{
	return SNew(SBSATaskPaletteItem, InCreateData);
}

void SBSATaskPalette::CollectAllActions(FGraphActionListBuilderBase& OutAllActions)
{
	FGraphActionMenuBuilder ActionMenuBuilder;
	
	if (UBSAAsset* EditingAsset = CachedEditor.Pin()->GetEditingAsset())
	{
		// 获取当前图表里有哪些Task对应的节点
		TArray<UBSATask*> AddedTaskList;
		if (EditingAsset->LogicGraph)
		{
			for (int32 i = 0; i < EditingAsset->LogicGraph->Nodes.Num(); ++i)
			{
				if (UBSALogicGraphNode* GraphNode = Cast<UBSALogicGraphNode>(EditingAsset->LogicGraph->Nodes[i]))
				{
					AddedTaskList.Add(GraphNode->CachedTask);
				}
			}
		}

		// 遍历资源的所有Task，添加对应的SchemaAction
		int32 SectionNum = EditingAsset->GetSectionNum();
		for (int32 i = 0; i < SectionNum; ++i)
		{
			if (FBSATaskSection* SectionPtr = EditingAsset->GetSectionPointerByIndex(i))
			{
				for (int32 j = 0; j < SectionPtr->TaskList.Num(); ++j)
				{
					if (SectionPtr->TaskList[j] && !AddedTaskList.Contains(SectionPtr->TaskList[j]))
					{
						TSharedPtr<FEdGraphSchemaAction> NewAction = TSharedPtr<FEdGraphSchemaAction>
						(
							new FBSALGCreatTaskNodeAction
							(
								FText::GetEmpty(),
								SectionPtr->TaskList[j]->GetTaskName(),
								SectionPtr->TaskList[j]->GetTaskName(),
								0, SectionPtr->TaskList[j]
							)
						);

						ActionMenuBuilder.AddAction(NewAction);
					}
				}
			}
		}
	}

	OutAllActions.Append(ActionMenuBuilder);
}

void SBSATaskPalette::OnLogicGraphChanged(const FEdGraphEditAction& InAction)
{
	if (GraphActionMenu.IsValid() && (InAction.Action & (EEdGraphActionType::GRAPHACTION_AddNode | EEdGraphActionType::GRAPHACTION_RemoveNode)) > 0)
	{
		GraphActionMenu->RefreshAllActions(false);
	}
}



#undef LOCTEXT_NAMESPACE
