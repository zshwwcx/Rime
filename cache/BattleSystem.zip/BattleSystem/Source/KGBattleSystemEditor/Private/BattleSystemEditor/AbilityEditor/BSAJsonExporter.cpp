#include "BattleSystemEditor/AbilityEditor/BSAJsonExporter.h"
#include "GameplayTagsManager.h"
#include "GameplayTagContainer.h"

#include "Curve/KGCurve.h"
#include "Misc/LowLevelFunctions.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorAssetManager.h"

#include "BattleSystem/Ability/Task/BSATaskStructs.h"
#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATask.h"



void UBSAJsonExporter::ExportSpecialStructToJson(void* DataAddress, FStructProperty* TheStructProp, TSharedPtr<FJsonObject> OutJson, FString ExtraString) const
{
	UScriptStruct* TheStruct = TheStructProp->Struct;

	if (TheStruct == FRuntimeFloatCurve::StaticStruct())
	{
		TArray<TSharedPtr<FJsonValue>> JsonArray;

		FRuntimeFloatCurve* CurStruct = (FRuntimeFloatCurve*)DataAddress;
		if (FRichCurve* CurCurve = CurStruct->GetRichCurve())
		{
			int32 KeyNum = CurCurve->Keys.Num();
			for (int32 i = 0; i < KeyNum; ++i)
			{
				TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
				UBSEditorFunctionLibrary::ExportStructToJson(&CurCurve->Keys[i], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

				JsonArray.Add(MakeShared<FJsonValueObject>(NewObject));
			}
		}

		OutJson->SetArrayField(TEXT("Keys"), JsonArray);

		OutJson->SetNumberField(TEXT("GID"), TryGetGUID(TheStructProp->GetFullName() + ExtraString));
	}
	else if (TheStruct == FKGRemapFloatCurve::StaticStruct())
	{
		FKGRemapFloatCurve* CurStruct = (FKGRemapFloatCurve*)DataAddress;

		OutJson->SetBoolField(TEXT("bNeedRemap"), CurStruct->bNeedRemap);

		TArray<TSharedPtr<FJsonValue>> JsonArray;
		if (FRichCurve* CurCurve = CurStruct->Curve.GetRichCurve())
		{
			int32 KeyNum = CurCurve->Keys.Num();
			for (int32 i = 0; i < KeyNum; ++i)
			{
				TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
				UBSEditorFunctionLibrary::ExportStructToJson(&CurCurve->Keys[i], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

				JsonArray.Add(MakeShared<FJsonValueObject>(NewObject));
			}
		}

		OutJson->SetArrayField(TEXT("Keys"), JsonArray);

		OutJson->SetNumberField(TEXT("GID"), TryGetGUID(TheStructProp->GetFullName() + ExtraString));
	}
	else if (TheStruct == FRuntimeVectorCurve::StaticStruct())
	{
		FRuntimeVectorCurve* CurStruct = (FRuntimeVectorCurve*)DataAddress;

		TArray<TSharedPtr<FJsonValue>> JsonArrayX, JsonArrayY, JsonArrayZ;
		for (int32 i = 0; i < 3; ++i)
		{
			TArray<TSharedPtr<FJsonValue>>* CurArray = nullptr;

			if (i == 0)
				CurArray = &JsonArrayX;
			else if (i == 1)
				CurArray = &JsonArrayY;
			else
				CurArray = &JsonArrayZ;

			if (FRichCurve* CurCurve = CurStruct->ExternalCurve ? &CurStruct->ExternalCurve->FloatCurves[i] : &CurStruct->VectorCurves[i])
			{
				int32 KeyNum = CurCurve->Keys.Num();
				for (int32 j = 0; j < KeyNum; ++j)
				{
					TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
					UBSEditorFunctionLibrary::ExportStructToJson(&CurCurve->Keys[j], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

					CurArray->Add(MakeShared<FJsonValueObject>(NewObject));
				}
			}
		}

		OutJson->SetArrayField(TEXT("XKeys"), JsonArrayX);
		OutJson->SetArrayField(TEXT("YKeys"), JsonArrayY);
		OutJson->SetArrayField(TEXT("ZKeys"), JsonArrayZ);

		OutJson->SetNumberField(TEXT("GID"), TryGetGUID(TheStructProp->GetFullName() + ExtraString));
	}
	else if (TheStruct == FKGRemapVectorCurve::StaticStruct())
	{
		FKGRemapVectorCurve* CurStruct = (FKGRemapVectorCurve*)DataAddress;

		OutJson->SetBoolField(TEXT("bNeedRemap"), CurStruct->bNeedRemap);

		TArray<TSharedPtr<FJsonValue>> JsonArrayX, JsonArrayY, JsonArrayZ;
		for (int32 i = 0; i < 3; ++i)
		{
			TArray<TSharedPtr<FJsonValue>>* CurArray = nullptr;

			if (i == 0)
				CurArray = &JsonArrayX;
			else if (i == 1)
				CurArray = &JsonArrayY;
			else
				CurArray = &JsonArrayZ;

			if (FRichCurve* CurCurve = CurStruct->Curve.ExternalCurve ? &CurStruct->Curve.ExternalCurve->FloatCurves[i] : &CurStruct->Curve.VectorCurves[i])
			{
				int32 KeyNum = CurCurve->Keys.Num();
				for (int32 j = 0; j < KeyNum; ++j)
				{
					TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
					UBSEditorFunctionLibrary::ExportStructToJson(&CurCurve->Keys[j], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

					CurArray->Add(MakeShared<FJsonValueObject>(NewObject));
				}
			}
		}

		OutJson->SetArrayField(TEXT("XKeys"), JsonArrayX);
		OutJson->SetArrayField(TEXT("YKeys"), JsonArrayY);
		OutJson->SetArrayField(TEXT("ZKeys"), JsonArrayZ);

		OutJson->SetNumberField(TEXT("GID"), TryGetGUID(TheStructProp->GetFullName() + ExtraString));
	}
	else if (TheStruct == FRuntimeCurveLinearColor::StaticStruct())
	{
		FRuntimeCurveLinearColor* CurStruct = (FRuntimeCurveLinearColor*)DataAddress;

		TArray<TSharedPtr<FJsonValue>> JsonArrayX, JsonArrayY, JsonArrayZ, JsonArrayW;
		for (int32 i = 0; i < 4; ++i)
		{
			TArray<TSharedPtr<FJsonValue>>* CurArray = nullptr;

			if (i == 0)
				CurArray = &JsonArrayX;
			else if (i == 1)
				CurArray = &JsonArrayY;
			else if (i == 2)
				CurArray = &JsonArrayZ;
			else
				CurArray = &JsonArrayW;

			if (FRichCurve* CurCurve = CurStruct->ExternalCurve ? &CurStruct->ExternalCurve->FloatCurves[i] : &CurStruct->ColorCurves[i])
			{
				int32 KeyNum = CurCurve->Keys.Num();
				for (int32 j = 0; j < KeyNum; ++j)
				{
					TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
					UBSEditorFunctionLibrary::ExportStructToJson(&CurCurve->Keys[j], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

					CurArray->Add(MakeShared<FJsonValueObject>(NewObject));
				}
			}
		}

		OutJson->SetArrayField(TEXT("XKeys"), JsonArrayX);
		OutJson->SetArrayField(TEXT("YKeys"), JsonArrayY);
		OutJson->SetArrayField(TEXT("ZKeys"), JsonArrayZ);
		OutJson->SetArrayField(TEXT("WKeys"), JsonArrayW);

		OutJson->SetNumberField(TEXT("GID"), TryGetGUID(TheStructProp->GetFullName() + ExtraString));
	}
	else if (TheStruct == FKGRemapColorCurve::StaticStruct())
	{
		FKGRemapColorCurve* CurStruct = (FKGRemapColorCurve*)DataAddress;

		OutJson->SetBoolField(TEXT("bNeedRemap"), CurStruct->bNeedRemap);

		TArray<TSharedPtr<FJsonValue>> JsonArrayX, JsonArrayY, JsonArrayZ, JsonArrayW;
		for (int32 i = 0; i < 4; ++i)
		{
			TArray<TSharedPtr<FJsonValue>>* CurArray = nullptr;

			if (i == 0)
				CurArray = &JsonArrayX;
			else if (i == 1)
				CurArray = &JsonArrayY;
			else if (i == 2)
				CurArray = &JsonArrayZ;
			else
				CurArray = &JsonArrayW;

			if (FRichCurve* CurCurve = CurStruct->Curve.ExternalCurve ? &CurStruct->Curve.ExternalCurve->FloatCurves[i] : &CurStruct->Curve.ColorCurves[i])
			{
				int32 KeyNum = CurCurve->Keys.Num();
				for (int32 j = 0; j < KeyNum; ++j)
				{
					TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
					UBSEditorFunctionLibrary::ExportStructToJson(&CurCurve->Keys[j], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

					CurArray->Add(MakeShared<FJsonValueObject>(NewObject));
				}
			}
		}

		OutJson->SetArrayField(TEXT("XKeys"), JsonArrayX);
		OutJson->SetArrayField(TEXT("YKeys"), JsonArrayY);
		OutJson->SetArrayField(TEXT("ZKeys"), JsonArrayZ);
		OutJson->SetArrayField(TEXT("WKeys"), JsonArrayW);

		OutJson->SetNumberField(TEXT("GID"), TryGetGUID(TheStructProp->GetFullName() + ExtraString));
	}
	else if (TheStruct == FBSATaskSelector::StaticStruct())
	{
		if (CachedAsset.IsValid())
		{
			FBSATaskSelector* CurStruct = (FBSATaskSelector*)DataAddress;

			if (FBSATaskSection* TheSection = CachedAsset->GetSectionPointerByTask(Cast<UBSATaskBase>(CurStruct->Owner)))
			{
				int32 Index = TheSection->TaskList.Find(Cast<UBSATask>(CurStruct->SelectedTask));
				OutJson->SetNumberField(TEXT("TaskIndex"), Index + 1);
			}
		}
	}
	else if (TheStruct == FBSATaskSelectorList::StaticStruct())
	{
		if (CachedAsset.IsValid())
		{
			FBSATaskSelectorList* CurStruct = (FBSATaskSelectorList*)DataAddress;
			if (CurStruct->SelectedTaskList.Num() > 0)
			{
				if (FBSATaskSection* TheSection = CachedAsset->GetSectionPointerByTask(Cast<UBSATaskBase>(CurStruct->SelectedTaskList[0].Owner)))
				{
					for (int32 i = 0; i < CurStruct->SelectedTaskList.Num(); ++i)
					{
						int32 Index = TheSection->TaskList.Find(Cast<UBSATask>(CurStruct->SelectedTaskList[i].SelectedTask));
						OutJson->SetNumberField(TEXT("INT64_") + FString::FromInt(i + 1), Index + 1);
					}
				}
			}
		}
	}
	else if (TheStruct == FBSATaskInputInfo::StaticStruct())
	{
		if (CachedAsset.IsValid())
		{
			FBSATaskInputInfo* CurStruct = (FBSATaskInputInfo*)DataAddress;

			if (FBSATaskSection* TheSection = CachedAsset->GetSectionPointerByTask(Cast<UBSATaskBase>(CurStruct->ProduceDataTask.Owner)))
			{
				int32 Index = TheSection->TaskList.Find(Cast<UBSATask>(CurStruct->ProduceDataTask.SelectedTask));
				OutJson->SetNumberField(TEXT("DataFrom"), Index + 1);
				OutJson->SetStringField(TEXT("DataName"), CurStruct->DataDesc.ToString());
			}
			else
			{
				//OutJson->SetNumberField(TEXT("DataFrom"), 0);
				//OutJson->SetStringField(TEXT("DataName"), CurStruct->DataDesc.ToString());
			}
		}
	}
	else if (TheStruct == FBSATaskOutputInfo::StaticStruct())
	{
		if (CachedAsset.IsValid())
		{
			FBSATaskOutputInfo* CurStruct = (FBSATaskOutputInfo*)DataAddress;

			OutJson->SetStringField(TEXT("DataName"), CurStruct->DataDesc.ToString());
			//OutJson->SetNumberField(TEXT("DataType"), (int32)CurStruct->DataType);
			//OutJson->SetStringField(TEXT("StructType"), CurStruct->StructType ? CurStruct->StructType->GetName() : TEXT("None"));
		}
	}
	else if (TheStruct == FBSATransformCreater::StaticStruct())
	{
		FBSATransformCreater* CurStruct = (FBSATransformCreater*)DataAddress;


		OutJson->SetNumberField(TEXT("OriginType"), (int32)CurStruct->OriginType);
		if (CurStruct->OriginType == EBSATaskCoordType::TCT_InputActor || CurStruct->OriginType == EBSATaskCoordType::TCT_World)
		{
			OutJson->SetNumberField(TEXT("OriginInputID"), CurStruct->OriginInputID + 1);
		}
		OutJson->SetBoolField(TEXT("bOriginUseSocket"), CurStruct->bOriginUseSocket);
		if (CurStruct->bOriginUseSocket)
		{
			OutJson->SetStringField(TEXT("OriginSocketName"), CurStruct->OriginSocketName.SocketName.ToString());
		}
		else
		{
			OutJson->SetStringField(TEXT("OriginSpecialName"), CurStruct->OriginSpecialName.ToString());
		}


		OutJson->SetNumberField(TEXT("DirectionType"), (int32)CurStruct->DirectionType);
		if (CurStruct->DirectionType == EBSATaskCoordType::TCT_InputActor || CurStruct->DirectionType == EBSATaskCoordType::TCT_World)
		{
			OutJson->SetNumberField(TEXT("DirectionInputID"), CurStruct->DirectionInputID + 1);
		}
		if (CurStruct->DirectionType != EBSATaskCoordType::TCT_TMax)
		{
			OutJson->SetBoolField(TEXT("bUseConnection"), CurStruct->bUseConnection);
			if (!CurStruct->bUseConnection)
			{
				OutJson->SetBoolField(TEXT("bDirectionUseSocket"), CurStruct->bDirectionUseSocket);
				if (CurStruct->bDirectionUseSocket)
				{
					OutJson->SetStringField(TEXT("DirectionSocketName"), CurStruct->DirectionSocketName.SocketName.ToString());
				}
				else
				{
					OutJson->SetStringField(TEXT("DirectionSpecialName"), CurStruct->DirectionSpecialName.ToString());
				}
			}
		}


		TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());
		UBSEditorFunctionLibrary::ExportStructToJson(&CurStruct->OffsetTransform, CurStruct->OffsetTransform.StaticStruct(), JsonObject, {});
		OutJson->SetObjectField(TEXT("OffsetTransform"), JsonObject);
	}
}

void UBSAJsonExporter::ExportSpecialObjectToJson(UObject* TheObject, TSharedPtr<FJsonObject> OutJson, FString ExtraString) const
{

}

TSharedPtr<FJsonValue> UBSAJsonExporter::ExportGameplayTag(FGameplayTag& InTag) const
{
	FString TagName = InTag.ToString();
	if (TagName.Contains(TEXT("BuffTag")))
	{
		int32 SPos = TagName.Find(TEXT(":"));
		FString SubStr = TagName.Mid(SPos + 1, TagName.Len() - SPos);

		return MakeShared<FJsonValueNumber>(FCString::Atoi(*SubStr));
	}
	else if (TagName.Contains(TEXT("Prop.")))
	{
		return MakeShared<FJsonValueString>(TagName.Replace(TEXT("Prop."), TEXT("")));
	}
	else if (TagName.Contains(TEXT("PropMode.")))
	{
		return MakeShared<FJsonValueString>(TagName.Replace(TEXT("PropMode."), TEXT("")));
	}
	else
	{
		return MakeShared<FJsonValueString>(TagName);
	}
}

TSharedPtr<FJsonValue> UBSAJsonExporter::ExportGameplayTagContainer(FGameplayTagContainer& InTag) const
{
	TArray<FGameplayTag> TagArray;
	InTag.GetGameplayTagArray(TagArray);

	TArray<TSharedPtr<FJsonValue>> JsonArray;
	for (int32 i = 0; i < TagArray.Num(); ++i)
	{
		FString TagName = TagArray[i].ToString();

		if (TagName.Contains(TEXT("BuffTag")))
		{
			int32 SPos = TagName.Find(TEXT(":"));
			FString SubStr = TagName.Mid(SPos + 1, TagName.Len() - SPos);

			JsonArray.Add(MakeShared<FJsonValueNumber>(FCString::Atoi(*SubStr)));
		}
		else if (TagName.Contains(TEXT("Prop.")))
		{
			JsonArray.Add(MakeShared<FJsonValueString>(TagName.Replace(TEXT("Prop."), TEXT(""))));
		}
		else if (TagName.Contains(TEXT("PropMode.")))
		{
			JsonArray.Add(MakeShared<FJsonValueString>(TagName.Replace(TEXT("PropMode."), TEXT(""))));
		}
		else
		{
			JsonArray.Add(MakeShared<FJsonValueString>(TagName));
		}
	}

	return MakeShared<FJsonValueArray>(JsonArray);
}

int64 UBSAJsonExporter::TryGetGUID(FString PropName) const
{
	UBSATask* Task = nullptr;
	UObject* CurObj = CurrentExportObject.Get();
	while (CurObj)
	{
		if (CurObj->IsA<UBSATask>())
		{
			Task = Cast<UBSATask>(CurObj);
			break;
		}
		CurObj = CurObj->GetOuter();
	}

	UBSAEditorAssetManager* BSAEAM = UBSAEditorAssetManager::GetInstance();
	if (!BSAEAM)
	{
		return 0;
	}

	if (Task)
	{
		FString GuidName = Task->GetFullName() + PropName;
		if (int64* Res = Task->GUIDMap.Find(PropName))
		{
			if (!BSAEAM)
			{
				// EditorAssetManage不存在时以找到的Guid为准
				return *Res;
			}

			if (BSAEAM->UsedGuidNameList.Contains(GuidName))
			{
				// 已检查过的Task和PropName，以找到的Guid为准
				return *BSAEAM->UsedGuidNameList.Find(GuidName);
			}

			if (BSAEAM->UsedGuidList.Contains(*Res))
			{
				// 如果记录的Guid发现被其他Task使用过，删除并重新生成
				Task->GUIDMap.Remove(PropName);
			}
			else
			{
				// 如果记录的Guid未发现被其他Task使用过，则可以直接使用，并记录为已被使用
				BSAEAM->UsedGuidNameList.Add(GuidName, *Res);
				BSAEAM->UsedGuidList.Add(*Res);

				return *Res;
			}
		}
		
		int64 NewID = ULowLevelFunctions::GetGlobalUniqueID();
		Task->GUIDMap.Add(PropName, NewID);
		if (CachedAsset.IsValid())
		{
			CachedAsset->MarkPackageDirty();
		}
		if (BSAEAM)
		{
			BSAEAM->UsedGuidNameList.Add(GuidName, NewID);
			BSAEAM->UsedGuidList.Add(NewID);
		}

		return NewID;
	}

	return ULowLevelFunctions::GetGlobalUniqueID();
}
