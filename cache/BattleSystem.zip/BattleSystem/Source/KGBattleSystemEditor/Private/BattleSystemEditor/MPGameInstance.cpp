#include "MPGameInstance.h"

#include "Editor/UnrealEd/Classes/Editor/EditorEngine.h"
#include "Editor/UnrealEd/Public/PlayInEditorDataTypes.h"

#include "lua.hpp"
#include "LuaState.h"



void UMPGameInstance::Init()
{
	Super::Init();

	// 创建Lua环境
    LuaEnv = UEditorLuaEnv::CreateLuaEnv(GetWorld(), UMPLuaGameInstance::StaticClass());
    if (UMPLuaGameInstance *MPLGI = Cast<UMPLuaGameInstance>(LuaEnv->GetLuaGameInstance()))
	{
		MPLGI->OnLuaInit(this);
	}
}

FGameInstancePIEResult UMPGameInstance::StartPlayInEditorGameInstance(ULocalPlayer* LocalPlayer, const FGameInstancePIEParameters& Params)
{
	FGameInstancePIEResult Result = Super::StartPlayInEditorGameInstance(LocalPlayer, Params);

	FVector StartLocation = FVector::ZeroVector;
	StartLocation.Z = 100.0f;

	if (UEditorEngine* const EditorEngine = CastChecked<UEditorEngine>(GetEngine()))
	{
		const TOptional<FPlayInEditorSessionInfo> PIESI = EditorEngine->GetPlayInEditorSessionInfo();
		if (PIESI.IsSet() && PIESI->OriginalRequestParams.StartLocation.IsSet())
		{
			StartLocation.X = PIESI->OriginalRequestParams.StartLocation->X;
			StartLocation.Y = PIESI->OriginalRequestParams.StartLocation->Y;
			StartLocation.Z = PIESI->OriginalRequestParams.StartLocation->Z;
		}
	}

	if (LuaEnv)
	{
        if (UMPLuaGameInstance *MPLGI = Cast<UMPLuaGameInstance>(LuaEnv->GetLuaGameInstance()))
		{
			MPLGI->SetStartLocation(StartLocation.X, StartLocation.Y, StartLocation.Z);
		}

		LuaEnv->GetLuaGameInstance()->BeginPlay(GetWorld());
	}

	return Result;
}

void UMPGameInstance::Shutdown()
{
    if (LuaEnv)
	{
        LuaEnv->GetLuaGameInstance()->EndPlay();
		UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
	}

	Super::Shutdown();
}
