#include "BattleSystemEditor/CustomLayout/BSStructLayout.h"
#include "PropertyCustomizationHelpers.h"
#include "Misc/TextFilterExpressionEvaluator.h"
#include "Widgets/Input/SSearchBox.h"
#include "Engine/SkeletalMeshSocket.h"

#include "Internationalization/StringTable.h"
#include "Internationalization/StringTableCore.h"

#include "BattleSystem/BSSettings.h"
#include "Engine/SkeletalMesh.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Views/SListView.h"


#define LOCTEXT_NAMESPACE "BSStruct"



void FBeatenPerformanceLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	HeaderRow.NameContent()
	[
		InPropertyHandle->CreatePropertyNameWidget()
	]
	.ValueContent()
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("受击动画:")))
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		[
			SNew(SProperty, InPropertyHandle->GetChildHandle(TEXT("BeatenMontage")))
			.ShouldDisplayName(false)
		]
		/*+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("受击起始硬直:")))
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		[
			SNew(SProperty, InPropertyHandle->GetChildHandle(TEXT("StartStagger")))
			.ShouldDisplayName(false)
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("硬直时长:")))
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		[
			SNew(SProperty, InPropertyHandle->GetChildHandle(TEXT("StartStaggerDuration")))
			.ShouldDisplayName(false)
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("受击结束硬直:")))
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		[
			SNew(SProperty, InPropertyHandle->GetChildHandle(TEXT("EndStagger")))
			.ShouldDisplayName(false)
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("硬直时长:")))
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f)
		.AutoWidth()
		[
			SNew(SProperty, InPropertyHandle->GetChildHandle(TEXT("EndStaggerDuration")))
			.ShouldDisplayName(false)
		]*/
	];
}






void FBSSelectTargetInfoLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	HeaderRow
	.NameContent()
	[
		InPropertyHandle->CreatePropertyNameWidget()
	]
	.ValueContent()
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(2.0f)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Camp:")))
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(2.0f)
		.VAlign(VAlign_Center)
		[
			SNew(SProperty, InPropertyHandle->GetChildHandle(TEXT("TargetCampType")))
			.ShouldDisplayName(false)
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(2.0f)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Type:")))
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(2.0f)
		.VAlign(VAlign_Center)
		[
			SNew(SProperty, InPropertyHandle->GetChildHandle(TEXT("TargetCharacterType")))
			.ShouldDisplayName(false)
		]
	];
}






class SSocketChooserPopup : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnSocketChosen, FName);

	struct FSocketInfo
	{
		FComponentSocketDescription Description;

		FBasicStringFilterExpressionContext FilterContext;

		static TSharedRef<FSocketInfo> Make(FComponentSocketDescription Description)
		{
			return MakeShareable(new FSocketInfo(Description));
		}

	protected:
		FSocketInfo(FComponentSocketDescription InDescription) : Description(InDescription), FilterContext(InDescription.Name.ToString()) {}
	};

	TWeakObjectPtr<USkeletalMesh> SkeletalMesh;

	TArray<TSharedPtr<FSocketInfo>> Sockets;

	TArray<TSharedPtr<FSocketInfo>> FilteredSockets;

	FOnSocketChosen OnSocketChosen;

	TSharedPtr<SListView<TSharedPtr<FSocketInfo>>> SocketListView;

	TSharedPtr<FTextFilterExpressionEvaluator> TextFilterPtr;

	TSharedPtr<SWidget> SearchBox;

	SLATE_BEGIN_ARGS(SSocketChooserPopup) : _SkeletalMesh(NULL), _ProvideNoSocketOption(true) {}

	SLATE_ARGUMENT(USkeletalMesh*, SkeletalMesh)
		SLATE_EVENT(FOnSocketChosen, OnSocketChosen)
		SLATE_ARGUMENT(bool, ProvideNoSocketOption)
	SLATE_END_ARGS()

private:
	TWeakPtr<SWindow> WidgetWindow;

public:
	TSharedRef<ITableRow> MakeItemWidget(TSharedPtr<FSocketInfo> SocketInfo, const TSharedRef<STableViewBase>& OwnerTable)
	{
		const FSlateBrush* Brush = FAppStyle::GetBrush(TEXT("SocketIcon.None"));

		if (SocketInfo->Description.Type == EComponentSocketType::Socket)
		{
			Brush = FAppStyle::GetBrush(TEXT("SocketIcon.Socket"));
		}
		else if (SocketInfo->Description.Type == EComponentSocketType::Bone)
		{
			Brush = FAppStyle::GetBrush(TEXT("SocketIcon.Bone"));
		}

		return
			SNew(STableRow<TSharedPtr<FSocketInfo>>, OwnerTable)
			.Content()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(2)
				.VAlign(VAlign_Center)
				[
					SNew(SImage)
					.Image(Brush)
				]
				+ SHorizontalBox::Slot()
				.FillWidth(1.f)
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::FromName(SocketInfo->Description.Name))
					.HighlightText_Lambda([this]() { return TextFilterPtr->GetFilterText(); })
				]
			];
	}

	void SelectedSocket(TSharedPtr<FSocketInfo> SocketInfo, ESelectInfo::Type)
	{
		const FName SocketName = SocketInfo->Description.Name;

		FSlateApplication::Get().DismissAllMenus();

		if (OnSocketChosen.IsBound())
		{
			OnSocketChosen.Execute(SocketName);
		}
	}

	void Construct(const FArguments& InArgs)
	{
		OnSocketChosen = InArgs._OnSocketChosen;
		SkeletalMesh = InArgs._SkeletalMesh;

		if (InArgs._ProvideNoSocketOption)
		{
			Sockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(NAME_None, EComponentSocketType::Invalid)));
		}

		TextFilterPtr = MakeShareable(new FTextFilterExpressionEvaluator(ETextFilterExpressionEvaluatorMode::BasicString));

		if (SkeletalMesh != NULL)
		{
			TArray<FComponentSocketDescription> Descriptions;
			
			const TArray<USkeletalMeshSocket*> AllSockets = SkeletalMesh->GetActiveSocketList();

			for (int32 SocketIdx = 0; SocketIdx < AllSockets.Num(); ++SocketIdx)
			{
				if (USkeletalMeshSocket* Socket = AllSockets[SocketIdx])
				{
					new (Descriptions) FComponentSocketDescription(Socket->SocketName, EComponentSocketType::Socket);
				}
			}

			for (int32 BoneIdx = 0; BoneIdx < SkeletalMesh->GetRefSkeleton().GetNum(); ++BoneIdx)
			{
				const FName BoneName = SkeletalMesh->GetRefSkeleton().GetBoneName(BoneIdx);
				new (Descriptions) FComponentSocketDescription(BoneName, EComponentSocketType::Bone);
			}

			for (auto DescriptionIt = Descriptions.CreateConstIterator(); DescriptionIt; ++DescriptionIt)
			{
				Sockets.Add(SSocketChooserPopup::FSocketInfo::Make(*DescriptionIt));
			}

			FilteredSockets.Append(Sockets);
		}
		else
		{
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(NAME_None, EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("root"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("pelvis"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("spine_01"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("spine_02"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("spine_03"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("hand_l"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("weapon_l"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("hand_r"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("weapon_r"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("foot_l"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("foot_r"), EComponentSocketType::Bone)));
			FilteredSockets.Add(SSocketChooserPopup::FSocketInfo::Make(FComponentSocketDescription(TEXT("weapon_u"), EComponentSocketType::Bone)));
		}

		this->ChildSlot
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush(TEXT("Menu.Background")))
			.Padding(5)
			.Content()
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 1.0f)
				[
					SNew(STextBlock)
					.Font(FAppStyle::GetFontStyle(TEXT("SocketChooser.TitleFont")))
					.Text(NSLOCTEXT("SocketChooser", "ChooseSocketOrBoneLabel", "Choose Socket or Bone"))
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 1.0f)
				[
					SAssignNew(SearchBox, SSearchBox)
					.OnTextChanged(this, &SSocketChooserPopup::HandleSearchTextChanged)
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.MaxHeight(512)
				[
					SNew(SBox)
					.WidthOverride(256)
					.Content()
					[
						SAssignNew(SocketListView, SListView< TSharedPtr<FSocketInfo> >)
						.ListItemsSource(&FilteredSockets)
						.OnGenerateRow(this, &SSocketChooserPopup::MakeItemWidget)
						.OnSelectionChanged(this, &SSocketChooserPopup::SelectedSocket)
					]
				]
			]
		];
	}

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override
	{
		TSharedPtr<SWindow> Window = CheckAndGetWindowPtr();
		if (Window.IsValid())
		{
			FVector2D WindowLocation = Window->IsMorphing() ? Window->GetMorphTargetPosition() : Window->GetPositionInScreen();
			FVector2D WindowSize = Window->GetDesiredSize();
			FSlateRect Anchor(WindowLocation.X, WindowLocation.Y, WindowLocation.X, WindowLocation.Y);
			WindowLocation = FSlateApplication::Get().CalculatePopupWindowPosition(Anchor, WindowSize, false);

			if (Window->IsMorphing())
			{
				if (WindowLocation != Window->GetMorphTargetPosition())
				{
					Window->UpdateMorphTargetShape(FSlateRect(WindowLocation.X, WindowLocation.Y, WindowLocation.X + WindowSize.X, WindowLocation.Y + WindowSize.Y));
				}
			}
			else
			{
				if (WindowLocation != Window->GetPositionInScreen())
				{
					Window->MoveWindowTo(WindowLocation);
				}
			}
		}
	}

	void HandleSearchTextChanged(const FText& InText)
	{
		TextFilterPtr->SetFilterText(InText);

		FilteredSockets.Reset();

		if (InText.IsEmpty())
		{
			FilteredSockets.Append(Sockets);
		}
		else
		{
			for (TSharedPtr<FSocketInfo>& SocketInfo : Sockets)
			{
				if (TextFilterPtr->TestTextFilter(SocketInfo->FilterContext))
				{
					FilteredSockets.Add(SocketInfo);
				}
			}
		}

		SocketListView->RequestListRefresh();
	}

	bool SupportsKeyboardFocus() const
	{
		return SearchBox->SupportsKeyboardFocus();
	}

	bool HasKeyboardFocus() const
	{
		return SearchBox->HasKeyboardFocus();
	}

	FReply OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent)
	{
		return FReply::Handled().SetUserFocus(SearchBox.ToSharedRef(), InFocusEvent.GetCause());
	}

private:
	TSharedPtr<SWindow> CheckAndGetWindowPtr()
	{
		if (WidgetWindow.IsValid())
		{
			return WidgetWindow.Pin();
		}
		else
		{
			TSharedPtr<SWindow> Window = FSlateApplication::Get().FindWidgetWindow(AsShared());
			WidgetWindow = Window;
			return Window;
		}
	}
};

void FBSSocketSelectorLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;

	HeaderWidget = &HeaderRow;

	HeaderRow
	.NameContent()
	[
		InPropertyHandle->CreatePropertyNameWidget()
	]
	.ValueContent()
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.VAlign(VAlign_Center)
		.AutoWidth()
		[
			SNew(SEditableTextBox)
			.Text(this, &FBSSocketSelectorLayout::GetSocketName)
			.IsReadOnly(true)
		]
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		.Padding(2.0f, 1.0f)
		[
			PropertyCustomizationHelpers::MakeBrowseButton
			(
				FSimpleDelegate::CreateSP(this, &FBSSocketSelectorLayout::OnBrowseSocket),
				LOCTEXT("SocketBrowseButtonToolTipText", "Select a different Parent Socket - cannot change socket on inherited components"),
				TAttribute<bool>(this, &FBSSocketSelectorLayout::CanChangeSocket)
			)
		]
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		.Padding(2.0f, 1.0f)
		[
			PropertyCustomizationHelpers::MakeClearButton
			(
				FSimpleDelegate::CreateSP(this, &FBSSocketSelectorLayout::OnClearSocket),
				LOCTEXT("SocketClearButtonToolTipText", "Clear the Parent Socket - cannot change socket on inherited components"),
				TAttribute<bool>(this, &FBSSocketSelectorLayout::CanChangeSocket)
			)
		]
		+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(SProperty, InPropertyHandle->GetChildHandle(TEXT("SkeletalMesh")))
			.ShouldDisplayName(false)
		]
	];
}

FBSSocketSelector* FBSSocketSelectorLayout::GetRawStructData() const
{
	if (!PropertyHandle.IsValid())
		return nullptr;

	void* RawData = NULL;
	PropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FBSSocketSelector*>(RawData);

	return nullptr;
}

FText FBSSocketSelectorLayout::GetSocketName() const
{
	if (FBSSocketSelector* Data = GetRawStructData())
	{
		return FText::FromName(Data->SocketName);
	}
	return FText::GetEmpty();
}

bool FBSSocketSelectorLayout::CanChangeSocket() const
{
	return true;
}

void FBSSocketSelectorLayout::OnBrowseSocket()
{
	if (FBSSocketSelector* Data = GetRawStructData())
	{
		if (HeaderWidget)
		{
			FSlateApplication::Get().PushMenu
			(
				HeaderWidget->NameWidget.Widget,
				FWidgetPath(),
				SNew(SSocketChooserPopup)
				.SkeletalMesh(Data->SkeletalMesh.LoadSynchronous())
				.OnSocketChosen(this, &FBSSocketSelectorLayout::OnSocketSelection),
				FSlateApplication::Get().GetCursorPos(),
				FPopupTransitionEffect(FPopupTransitionEffect::TypeInPopup)
			);
		}
	}
}

void FBSSocketSelectorLayout::OnClearSocket()
{
	if (FBSSocketSelector* Data = GetRawStructData())
	{
		Data->SocketName = NAME_None;
	}
}

void FBSSocketSelectorLayout::OnSocketSelection(FName SocketName)
{
	if (FBSSocketSelector* Data = GetRawStructData())
	{
		Data->SocketName = SocketName;
	}
}

#undef LOCTEXT_NAMESPACE
