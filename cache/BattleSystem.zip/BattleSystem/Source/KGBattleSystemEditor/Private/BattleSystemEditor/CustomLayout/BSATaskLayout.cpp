#include "BattleSystemEditor/CustomLayout/BSATaskLayout.h"

#include "PropertyCustomizationHelpers.h"
#include "IDetailChildrenBuilder.h"

#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"






#define LOCTEXT_NAMESPACE "GBSTaskLayout"

class STaskPicker : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnPickTaskDelegate, FName);

private:
	FBSATaskSelector* TaskSelector = NULL;
	TArray<FName> CachedTaskNameList;

	TArray<TSharedPtr<FName>> TaskNameList;
	TSharedPtr<SComboBox<TSharedPtr<FName>>> NameListBox;

	FOnPickTaskDelegate OnPickTaskName;

public:
	SLATE_BEGIN_ARGS(STaskPicker) : _TaskSelector(NULL) {}
	SLATE_ARGUMENT(FBSATaskSelector*, TaskSelector)
	SLATE_EVENT(FOnPickTaskDelegate, OnPickTaskName)
	SLATE_END_ARGS()

public:
	TSharedRef<SWidget> OnGenerateComboWidget(TSharedPtr<FName> InComboID)
	{
		if (InComboID.IsValid())
			return SNew(STextBlock).Text(FText::FromName(*InComboID));

		return SNew(STextBlock).Text(FText());
	}

	void OnComboSelectionChanged(TSharedPtr<FName> NewValue, ESelectInfo::Type SelectInfo)
	{
		if (TaskSelector && NewValue.IsValid())
		{
			OnPickTaskName.ExecuteIfBound(*NewValue.Get());
		}
	}

	FName GetTaskName(UBSATask* InTask) const
	{
		if (InTask && InTask->IsValidLowLevelFast())
		{
			if (UBSAAsset* Asset = Cast<UBSAAsset>(InTask->GetOuter()))
			{
				int32 SectionNum = Asset->GetSectionNum();
				for (int32 i = 0; i < SectionNum; ++i)
				{
					FBSATaskSection* SectionPtr = Asset->GetSectionPointerByIndex(i);
					if (!SectionPtr)
						continue;

					for (int32 j = 0; j < SectionPtr->TaskList.Num(); ++j)
					{
						if (SectionPtr->TaskList[j] == InTask)
						{
							FString TaskName = InTask->GetTaskName().ToString();
							TaskName = FString::FromInt(j) + TEXT("::") + TaskName;

							return FName(TaskName);
						}
					}
				}
			}
		}

		return FName();
	}

	FText GetSelectTaskName() const
	{
		if (TaskSelector && TaskSelector->SelectedTask && TaskSelector->SelectedTask->IsValidLowLevel())
		{
			return FText::FromName(GetTaskName(Cast<UBSATask>(TaskSelector->SelectedTask)));
		}

		return FText();
	}

	void RefreshTaskNameList()
	{
		CachedTaskNameList.Empty();
		TaskNameList.Empty();

		if (!TaskSelector || !TaskSelector->Owner)
			return;

		if (UBSAAsset* Asset = Cast<UBSAAsset>(TaskSelector->Owner->GetOuter()))
		{
			int32 SectionNum = Asset->GetSectionNum();
			for (int32 i = 0; i < SectionNum; ++i)
			{
				FBSATaskSection* SectionPtr = Asset->GetSectionPointerByIndex(i);
				if (!SectionPtr || !SectionPtr->TaskList.Contains(TaskSelector->Owner))
					continue;

				for (int32 j = 0; j < SectionPtr->TaskList.Num(); ++j)
				{
					CachedTaskNameList.Add(GetTaskName(SectionPtr->TaskList[j]));
				}
			}
		}

		for (int32 i = 0; i < CachedTaskNameList.Num(); ++i)
		{
			TaskNameList.Add(MakeShared<FName>(CachedTaskNameList[i]));
		}
	}

	void Construct(const FArguments& InArgs)
	{
		this->TaskSelector = InArgs._TaskSelector;
		this->OnPickTaskName = InArgs._OnPickTaskName;

		RefreshTaskNameList();

		this->ChildSlot
		[
			SAssignNew(NameListBox, SComboBox<TSharedPtr<FName>>)
			.OptionsSource(&TaskNameList)
			.OnComboBoxOpening(this, &STaskPicker::RefreshTaskNameList)
			.OnGenerateWidget(this, &STaskPicker::OnGenerateComboWidget)
			.OnSelectionChanged(this, &STaskPicker::OnComboSelectionChanged)
			[
				SNew(STextBlock)
				.Text(this, &STaskPicker::GetSelectTaskName)
			]
		];
	}
};



void FBSATaskSelectorLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;

	HeaderRow
	.NameContent()
	[
		PropertyHandle->CreatePropertyNameWidget()
	]
	.ValueContent()
	[
		SNew(STaskPicker)
		.TaskSelector(GetRawStructData(InPropertyHandle))
		.OnPickTaskName(this, &FBSATaskSelectorLayout::SetTaskName)
	];
}

void FBSATaskSelectorLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("SelectedTask")).ToSharedRef());
}

FBSATaskSelector* FBSATaskSelectorLayout::GetRawStructData(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FBSATaskSelector*>(RawData);

	return NULL;
}

void FBSATaskSelectorLayout::SetTaskName(FName NewTaskName)
{
	if (FBSATaskSelector* Struct = GetRawStructData(PropertyHandle.ToSharedRef()))
	{
		FString TaskName = NewTaskName.ToString();

		int32 CheckPos = TaskName.Find(TEXT("::"));
		TaskName = TaskName.Left(CheckPos);

		int32 Index = FCString::Atoi(*TaskName);

		if (UBSAAsset* Asset = Cast<UBSAAsset>(Struct->Owner->GetOuter()))
		{
			int32 SectionNum = Asset->GetSectionNum();
			for (int32 i = 0; i < SectionNum; ++i)
			{
				FBSATaskSection* SectionPtr = Asset->GetSectionPointerByIndex(i);
				if (!SectionPtr)
					continue;

				if (!SectionPtr->TaskList.Contains(Struct->Owner))
					continue;

				if (SectionPtr->TaskList.IsValidIndex(Index))
				{
					Struct->SelectedTask = SectionPtr->TaskList[Index];
				}
			}
		}
	}
}






void FBSATaskParameterizedPropertyLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle; 

	HeaderRow
	.NameContent()
	[
		PropertyHandle->CreatePropertyNameWidget()
	]
	.ValueContent()
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(2.0f)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("UseInput:")))
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(2.0f)
		.VAlign(VAlign_Center)
		[
			SNew(SProperty, PropertyHandle->GetChildHandle(TEXT("bUseInputData")))
			.ShouldDisplayName(false)
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(2.0f)
		.VAlign(VAlign_Center)
		[
			SNew(SProperty, PropertyHandle->GetChildHandle(TEXT("InputDataID")))
			.ShouldDisplayName(false)
		]
	];
}

void FBSATaskParameterizedPropertyLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	if (PropertyHandle->GetChildHandle(TEXT("ConfigValue")).IsValid())
	{
		IDetailPropertyRow& ValueRow = ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("ConfigValue")).ToSharedRef());
		ValueRow.ShouldAutoExpand(true);
	}
}






void FBSATransformCreaterLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;

	HeaderRow
	.NameContent()
	[
		PropertyHandle->CreatePropertyNameWidget()
	]
	.ValueContent()
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(2.0f)
		.VAlign(VAlign_Center)
		[
			SNew(SProperty, PropertyHandle->GetChildHandle(TEXT("OriginType")))
			.ShouldDisplayName(false)
		]
	];
}

void FBSATransformCreaterLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("OriginInputID")).ToSharedRef());
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("bOriginUseSocket")).ToSharedRef());
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("OriginSocketName")).ToSharedRef());
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("OriginSpecialName")).ToSharedRef());

	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("DirectionType")).ToSharedRef());
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("DirectionInputID")).ToSharedRef());
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("bUseConnection")).ToSharedRef());
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("bDirectionUseSocket")).ToSharedRef());
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("DirectionSocketName")).ToSharedRef());
	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("DirectionSpecialName")).ToSharedRef());

	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(TEXT("OffsetTransform")).ToSharedRef());
}


#undef LOCTEXT_NAMESPACE
