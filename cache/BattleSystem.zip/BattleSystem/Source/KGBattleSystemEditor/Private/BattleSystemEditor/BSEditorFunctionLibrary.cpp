#include "BattleSystemEditor/BSEditorFunctionLibrary.h"

#include "FileHelpers.h"
#include "Misc/FileHelper.h"
#include "SourceControlHelpers.h"
#include "HAL/PlatformFilemanager.h"
#include "Engine/UserDefinedEnum.h"
#include "GameplayTagsSettings.h"

#include "BattleSystem/BSStructs.h"
#include "BattleSystemEditor/BSEditorLuaGI.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"
#include "BattleSystem/Ability/Task/BSATaskStructs.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorAssetManager.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeAssetManager.h"
#include "BattleSystemEditor/AbilityEditor/BSAJsonExporter.h"
#include "BattleSystemEditor/AbilityEditor/Ability/BSAAsset.h"
#include "Engine/Blueprint.h"
#include "Engine/BlueprintGeneratedClass.h"

#include "BattleSystemEditor/AbilityEditor/Ability/Tasks/BSATaskBattle.h"
#include "Misc/ConfigCacheIni.h"
#include "Misc/MessageDialog.h"


#define LOCTEXT_NAMESPACE "BSEditorFunctionLibrary"



TSharedPtr<FJsonValue> UBSJsonExporter::ExportGameplayTag(FGameplayTag& InTag) const
{
	return MakeShared<FJsonValueString>(InTag.GetTagName().ToString());
}

TSharedPtr<FJsonValue> UBSJsonExporter::ExportGameplayTagContainer(FGameplayTagContainer& InTag) const
{
	TArray<FGameplayTag> TagArray;
	InTag.GetGameplayTagArray(TagArray);

	TArray<TSharedPtr<FJsonValue>> JsonArray;
	for (int32 i = 0; i < TagArray.Num(); ++i)
	{
		JsonArray.Add(MakeShared<FJsonValueString>(TagArray[i].ToString()));
	}
	return MakeShared<FJsonValueArray>(JsonArray);
}






#pragma region Property
FString UBSEditorFunctionLibrary::DataTableFindName = TEXT("BSEFLSearchDT");

void UBSEditorFunctionLibrary::CopyStruct(void* DestAddress, void* SrcAddress, UScriptStruct* StructType, UObject* Dest, UObject* Src)
{
	if (!DestAddress || !SrcAddress || !StructType)
		return;

	for (TFieldIterator<FProperty> PropIt(StructType); PropIt; ++PropIt)
	{
		FProperty* Prop = *PropIt;

		void* CurSrcAddress = Prop->ContainerPtrToValuePtr<void>(SrcAddress);
		void* CurDestAddress = Prop->ContainerPtrToValuePtr<void>(DestAddress);

		if (!CurSrcAddress || !CurDestAddress)
			continue;

		if (FObjectProperty* CurObjProp = CastField<FObjectProperty>(Prop))
		{
			UObject* CurSrcObject = CurObjProp->GetObjectPropertyValue(CurSrcAddress);
			if (CurSrcObject && CurSrcObject->GetOuter() == Src)
			{
				UObject* CurDestObject = CurObjProp->GetObjectPropertyValue(CurDestAddress);
				CurDestObject = NewObject<UObject>(Dest, CurSrcObject->GetClass());
				CurObjProp->SetObjectPropertyValue(CurDestAddress, CurDestObject);

				UBSEditorFunctionLibrary::CopyObject(CurDestObject, CurSrcObject);
			}
			else
			{
				UBSEditorFunctionLibrary::CopyData(CurDestAddress, CurSrcAddress, Prop, Dest, Src);
			}
		}
		else if (FStructProperty* CurStructProp = CastField<FStructProperty>(Prop))
		{
			UBSEditorFunctionLibrary::CopyStruct(CurDestAddress, CurSrcAddress, CurStructProp->Struct, Dest, Src);
		}
		else
		{
			UBSEditorFunctionLibrary::CopyData(CurDestAddress, CurSrcAddress, Prop, Dest, Src);
		}
	}
}

void UBSEditorFunctionLibrary::CopyObject(UObject* DestObject, UObject* SrcObject)
{
	if (!DestObject || !SrcObject)
		return;

	if (DestObject->GetClass() != SrcObject->GetClass())
		return;

	for (TFieldIterator<FProperty> PropIt(SrcObject->GetClass()); PropIt; ++PropIt)
	{
		FProperty* Prop = *PropIt;

		void* SrcAddress = Prop->ContainerPtrToValuePtr<void>(SrcObject);
		void* DestAddress = Prop->ContainerPtrToValuePtr<void>(DestObject);

		if (!SrcAddress || !DestAddress)
			continue;

		if (FObjectProperty* CurObjProp = CastField<FObjectProperty>(Prop))
		{
			UObject* CurSrcObject = CurObjProp->GetObjectPropertyValue(SrcAddress);
			if (CurSrcObject && CurSrcObject->GetOuter() == SrcObject)
			{
				UObject* CurDestObject = CurObjProp->GetObjectPropertyValue(DestAddress);
				CurDestObject = NewObject<UObject>(DestObject, CurSrcObject->GetClass());
				CurObjProp->SetObjectPropertyValue(DestAddress, CurDestObject);

				UBSEditorFunctionLibrary::CopyObject(CurDestObject, CurSrcObject);
			}
			else
			{
				UBSEditorFunctionLibrary::CopyData(DestAddress, SrcAddress, Prop, DestObject, SrcObject);
			}
		}
		else if (FStructProperty* CurStructProp = CastField<FStructProperty>(Prop))
		{
			UBSEditorFunctionLibrary::CopyStruct(DestAddress, SrcAddress, CurStructProp->Struct, DestObject, SrcObject);
		}
		else
		{
			UBSEditorFunctionLibrary::CopyData(DestAddress, SrcAddress, Prop, DestObject, SrcObject);
		}
	}

	return;
}

void UBSEditorFunctionLibrary::CopyData(void* DestAddress, void* SrcAddress, FProperty* DataType, UObject* Dest, UObject* Src)
{
	if (FArrayProperty* ArrayProp = CastField<FArrayProperty>(DataType))
	{
		DataType->CopySingleValue(DestAddress, SrcAddress);

		FProperty* Prop = ArrayProp->Inner;

		FScriptArrayHelper DestArrayHelper(ArrayProp, DestAddress);
		FScriptArrayHelper SrcArrayHelper(ArrayProp, SrcAddress);
		int32 SrcArrayNum = SrcArrayHelper.Num();

		for (int32 i = 0; i < SrcArrayNum; ++i)
		{
			void* CurSrcAddress = SrcArrayHelper.GetRawPtr(i);
			void* CurDestAddress = DestArrayHelper.GetRawPtr(i);

			if (FObjectProperty* CurObjProp = CastField<FObjectProperty>(Prop))
			{
				UObject* CurSrcObject = CurObjProp->GetObjectPropertyValue(CurSrcAddress);
				if (CurSrcObject && CurSrcObject->GetOuter() == Src)
				{
					UObject* CurDestObject = CurObjProp->GetObjectPropertyValue(CurDestAddress);
					CurDestObject = NewObject<UObject>(Dest, CurSrcObject->GetClass());
					CurObjProp->SetObjectPropertyValue(CurDestAddress, CurDestObject);

					UBSEditorFunctionLibrary::CopyObject(CurDestObject, CurSrcObject);
				}
			}
			else if (FStructProperty* CurStructProp = CastField<FStructProperty>(Prop))
			{
				UBSEditorFunctionLibrary::CopyStruct(CurDestAddress, CurSrcAddress, CurStructProp->Struct, Dest, Src);
			}
		}
	}
	else if (FMapProperty* MapProp = CastField<FMapProperty>(DataType))
	{
		DataType->CopySingleValue(DestAddress, SrcAddress);

		FScriptMapHelper DestMapHelper(MapProp, DestAddress);
		FScriptMapHelper SrcMapHelper(MapProp, SrcAddress);
		int32 SrcMapNum = SrcMapHelper.Num();

		FProperty* KeyProp = MapProp->KeyProp;
		FProperty* ValueProp = MapProp->ValueProp;

		for (int32 i = 0; i < SrcMapNum; ++i)
		{
			void* CurSrcAddress = SrcMapHelper.GetKeyPtr(i);
			void* CurDestAddress = DestMapHelper.GetKeyPtr(i);
			if (FObjectProperty* CurObjProp = CastField<FObjectProperty>(KeyProp))
			{
				UObject* CurSrcObject = CurObjProp->GetObjectPropertyValue(CurSrcAddress);
				if (CurSrcObject && CurSrcObject->GetOuter() == Src)
				{
					UObject* CurDestObject = CurObjProp->GetObjectPropertyValue(CurDestAddress);
					CurDestObject = NewObject<UObject>(Dest, CurSrcObject->GetClass());
					CurObjProp->SetObjectPropertyValue(CurDestAddress, CurDestObject);

					UBSEditorFunctionLibrary::CopyObject(CurDestObject, CurSrcObject);
				}
			}
			else if (FStructProperty* CurStructProp = CastField<FStructProperty>(KeyProp))
			{
				UBSEditorFunctionLibrary::CopyStruct(CurDestAddress, CurSrcAddress, CurStructProp->Struct, Dest, Src);
			}


			CurSrcAddress = SrcMapHelper.GetValuePtr(i);
			CurDestAddress = DestMapHelper.GetValuePtr(i);
			if (FObjectProperty* CurObjProp = CastField<FObjectProperty>(ValueProp))
			{
				UObject* CurSrcObject = CurObjProp->GetObjectPropertyValue(CurSrcAddress);
				if (CurSrcObject && CurSrcObject->GetOuter() == Src)
				{
					UObject* CurDestObject = CurObjProp->GetObjectPropertyValue(CurDestAddress);
					CurDestObject = NewObject<UObject>(Dest, CurSrcObject->GetClass());
					CurObjProp->SetObjectPropertyValue(CurDestAddress, CurDestObject);

					UBSEditorFunctionLibrary::CopyObject(CurDestObject, CurSrcObject);
				}
			}
			else if (FStructProperty* CurStructProp = CastField<FStructProperty>(ValueProp))
			{
				UBSEditorFunctionLibrary::CopyStruct(CurDestAddress, CurSrcAddress, CurStructProp->Struct, Dest, Src);
			}
		}
	}
	else
	{
		DataType->CopySingleValue(DestAddress, SrcAddress);
	}
}

#pragma endregion Property



#pragma region Json
void UBSEditorFunctionLibrary::ExportStructToJson(void* DataAddress, UScriptStruct* TheStruct, TSharedPtr<FJsonObject> OutJson, const TArray<UStruct*>& SpecialType, UBSJsonExporter* SpecialExporter, FString ExtraString)
{
	if (!TheStruct)
		return;

	for (TFieldIterator<FProperty> PropIt(TheStruct); PropIt; ++PropIt)
	{
		if ((*PropIt)->IsEditorOnlyProperty())
		{
			continue;
		}

		void* CurAddress = (*PropIt)->ContainerPtrToValuePtr<void>(DataAddress);
		if (FObjectProperty* CurObjProp = CastField<FObjectProperty>((*PropIt)))
		{
			UObject* CurObject = CurObjProp->GetObjectPropertyValue(CurAddress);
			OutJson->SetField((*PropIt)->GetName(), UBSEditorFunctionLibrary::ExportPropertyToJson(CurObject, *PropIt, SpecialType, SpecialExporter, ExtraString));
		}
		else
		{
			OutJson->SetField((*PropIt)->GetName(), UBSEditorFunctionLibrary::ExportPropertyToJson(CurAddress, *PropIt, SpecialType, SpecialExporter, ExtraString));
		}
	}
}

void UBSEditorFunctionLibrary::ExportObjectToJson(UObject* TheObject, TSharedPtr<FJsonObject> OutJson, const TArray<UStruct*>& SpecialType, UBSJsonExporter* SpecialExporter, FString ExtraString)
{
	if (!TheObject)
		return;

	if (SpecialExporter)
	{
		SpecialExporter->CurrentExportObject = TheObject;
	}

	if (TheObject->IsA<UBSATask>() && ExtraString == "")
	{
		// 从Task开始记录
		ExtraString = "_";
	}

	UClass* ObjectClass = TheObject->GetClass();
	for (TFieldIterator<FProperty> PropIt(ObjectClass); PropIt; ++PropIt)
	{
		// 不导出编辑器数据
		if ((*PropIt)->IsEditorOnlyProperty())
		{
			continue;
		}

		// 不导出UObject的数据
		UClass* CurrentClass = PropIt->GetOwnerClass();
		if (CurrentClass == UObject::StaticClass())
		{
			continue;
		}
		else
		{
			void* CurAddress = (*PropIt)->ContainerPtrToValuePtr<void>(TheObject);
			if (FObjectProperty* CurObjProp = CastField<FObjectProperty>((*PropIt)))
			{
				UObject* CurObject = CurObjProp->GetObjectPropertyValue(CurAddress);
				OutJson->SetField((*PropIt)->GetName(), UBSEditorFunctionLibrary::ExportPropertyToJson(CurObject, *PropIt, SpecialType, SpecialExporter, ExtraString));
			}
			else
			{
				OutJson->SetField((*PropIt)->GetName(), UBSEditorFunctionLibrary::ExportPropertyToJson(CurAddress, *PropIt, SpecialType, SpecialExporter, ExtraString));
			}
		}
	}
}

TSharedPtr<FJsonValue> UBSEditorFunctionLibrary::ExportPropertyToJson(void* DataAddress, FProperty* Prop, const TArray<UStruct*>& SpecialType, UBSJsonExporter* SpecialExporter, FString ExtraString)
{
	UDataTable* DT = nullptr;
	if (const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>())
	{
		DT = Setting->ExportEnumClassTable.LoadSynchronous();
	}

	if (FByteProperty* ByteProp = CastField<FByteProperty>(Prop))
	{
		int8* ValuePtr = (int8*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FEnumProperty* EnumProp = CastField<FEnumProperty>(Prop))
	{
		int8* ValuePtr = (int8*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FBoolProperty* BoolProp = CastField<FBoolProperty>(Prop))
	{
		uint8 FMask = BoolProp->GetFieldMask();

		if (FMask <= 0)
		{
			bool* Value = (bool*)DataAddress;
			return MakeShared<FJsonValueBoolean>(*Value);
		}
		else
		{
			uint8* Value = (uint8*)DataAddress;
			return MakeShared<FJsonValueBoolean>(((*Value) & FMask) > 0);
		}
	}
	else if (FInt8Property* Int8Prop = CastField<FInt8Property>(Prop))
	{
		int8* ValuePtr = (int8*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FInt16Property* Int16Prop = CastField<FInt16Property>(Prop))
	{
		int16* ValuePtr = (int16*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FIntProperty* Int32Prop = CastField<FIntProperty>(Prop))
	{
		int32* ValuePtr = (int32*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FInt64Property* Int64Prop = CastField<FInt64Property>(Prop))
	{
		int64* ValuePtr = (int64*)DataAddress;
		return MakeShared<FJsonValueString>(FString::Printf(TEXT("INT64_%lld"), *ValuePtr));
	}
	else if (FFloatProperty* FloatProp = CastField<FFloatProperty>(Prop))
	{
		float* ValuePtr = (float*)DataAddress;
		double Value = FMath::RoundToDouble((*ValuePtr) * 10000.0f) / 10000.0f;
		return MakeShared<FJsonValueNumber>(Value);
	}
	else if (FDoubleProperty* DoubleProp = CastField<FDoubleProperty>(Prop))
	{
		double* ValuePtr = (double*)DataAddress;
		double Value = FMath::RoundToDouble((*ValuePtr) * 10000.0f) / 10000.0f;
		return MakeShared<FJsonValueNumber>(Value);
	}
	else if (FClassProperty* ClassProp = CastField<FClassProperty>(Prop))
	{
		if (UClass* TheClass = (UClass*)(DataAddress))
		{
			if (DT)
			{
				if (FBSClassTypeData* Row = DT->FindRow<FBSClassTypeData>(FName(TheClass->GetName()), DataTableFindName, false))
				{
					return MakeShared<FJsonValueNumber>(Row->EnumValue);
				}
			}

			return MakeShared<FJsonValueString>(TheClass->GetPathName());
		}

		return MakeShared<FJsonValueString>(TEXT(""));
	}
	else if (FSoftClassProperty* SoftClassProp = CastField<FSoftClassProperty>(Prop))
	{
		if (FSoftObjectPtr* TheClass = (FSoftObjectPtr*)(DataAddress))
		{
			if (DT && TheClass->IsValid())
			{
				if (UClass* Class = Cast<UClass>(TheClass->Get()))
				{
					if (FBSClassTypeData* Row = DT->FindRow<FBSClassTypeData>(FName(Class->GetName()), DataTableFindName, false))
					{
						return MakeShared<FJsonValueNumber>(Row->EnumValue);
					}
				}
			}

			return MakeShared<FJsonValueString>(TheClass->ToString());
		}

		return MakeShared<FJsonValueString>(TEXT(""));
	}
	else if (FObjectProperty* ObjectProp = CastField<FObjectProperty>(Prop))
	{
		if (ObjectProp->HasMetaData(TEXT("EditInline")))
		{
			UObject* ObjectPtr = (UObject*)DataAddress;
			TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

			if (SpecialType.Contains(ObjectProp->GetOwnerClass()) && SpecialExporter)
			{
				SpecialExporter->ExportSpecialObjectToJson(ObjectPtr, JsonObject, ExtraString);
			}
			else
			{
				UBSEditorFunctionLibrary::ExportObjectToJson(ObjectPtr, JsonObject, SpecialType, SpecialExporter, ExtraString);
			}

			return MakeShared<FJsonValueObject>(JsonObject);
		}
		else
		{
			UObject* ObjectPtr = (UObject*)DataAddress;
			return MakeShared<FJsonValueString>(ObjectPtr->GetPathName());
		}
	}
	else if (FSoftObjectProperty* SoftObjectProp = CastField<FSoftObjectProperty>(Prop))
	{
		FSoftObjectPtr* ValuePtr = (FSoftObjectPtr*)DataAddress;

		FString ObjectType;
		SoftObjectProp->GetCPPMacroType(ObjectType);

		if (ObjectType.Contains(TEXT("UBSASkillAsset")) || ObjectType.Contains(TEXT("UBSABuffAsset")) || ObjectType.Contains(TEXT("UBSAAsset")))
		{
			if (ValuePtr->IsNull())
			{
				return MakeShared<FJsonValueNumber>(0);
			}
			else
			{
				int32 ID = FCString::Atoi(*ValuePtr->GetAssetName());
				return MakeShared<FJsonValueNumber>(ID);
			}
		}

		return MakeShared<FJsonValueString>(ValuePtr->ToString());
	}
	else if (FNameProperty* NameProp = CastField<FNameProperty>(Prop))
	{
		FName* ValuePtr = (FName*)DataAddress;
		return MakeShared<FJsonValueString>(ValuePtr->ToString());
	}
	else if (FStrProperty* StringProp = CastField<FStrProperty>(Prop))
	{
		FString* ValuePtr = (FString*)DataAddress;
		return MakeShared<FJsonValueString>(*ValuePtr);
	}
	else if (FArrayProperty* ArrayProp = CastField<FArrayProperty>(Prop))
	{
		TArray<TSharedPtr<FJsonValue>> JsonArray;
		FScriptArrayHelper ArrayHelper(ArrayProp, DataAddress);

		FProperty* ElementType = ArrayProp->Inner;
		int32 ArrayNum = ArrayHelper.Num();
		for (int32 i = 0; i < ArrayNum; ++i)
		{
			void* ElementPtr = ArrayHelper.GetRawPtr(i);
			if (FObjectProperty* CurObjectProp = CastField<FObjectProperty>(ElementType))
			{
				ElementPtr = CurObjectProp->GetObjectPropertyValue(ElementPtr);
			}

			TSharedPtr<FJsonValue> NewJsonValue = UBSEditorFunctionLibrary::ExportPropertyToJson(ElementPtr, ElementType, SpecialType, SpecialExporter, ExtraString != "" ? ExtraString + FString::FromInt(i) : ExtraString);
			
			TSharedPtr<FJsonObject>* NewJsonObject = nullptr;
			if (NewJsonValue->TryGetObject(NewJsonObject))
			{
				if (NewJsonObject->IsValid() && NewJsonObject->Get()->Values.Num() > 0)
				{
					JsonArray.Add(NewJsonValue);
				}
			}
			else
			{
				JsonArray.Add(NewJsonValue);
			}
		}

		return MakeShared<FJsonValueArray>(JsonArray);
	}
	else if (FMapProperty* MapProp = CastField<FMapProperty>(Prop))
	{
		TArray<TSharedPtr<FJsonValue>> JsonArray;
		FScriptMapHelper MapHelper(MapProp, DataAddress);

		FProperty* KeyType = MapHelper.GetKeyProperty();
		FProperty* ValueType = MapHelper.GetValueProperty();
		int32 MapNum = MapHelper.Num();
		for (int32 i = 0; i < MapNum; ++i)
		{
			TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

			TSharedPtr<FJsonValue> NewJsonValue = nullptr;
			TSharedPtr<FJsonObject>* NewJsonObject = nullptr;

			void* KeyPtr = MapHelper.GetKeyPtr(i);
			if (FObjectProperty* TmpProp = CastField<FObjectProperty>(KeyType))
			{
				KeyPtr = TmpProp->GetObjectPropertyValue(KeyPtr);
			}
			NewJsonValue = UBSEditorFunctionLibrary::ExportPropertyToJson(KeyPtr, KeyType, SpecialType, SpecialExporter, ExtraString != "" ? ExtraString + FString("Key") + FString::FromInt(i) : ExtraString);
			if (NewJsonValue->TryGetObject(NewJsonObject))
			{
				if (NewJsonObject->IsValid() && NewJsonObject->Get()->Values.Num() > 0)
				{
					JsonObject->SetField(TEXT("Key"), NewJsonValue);
				}
			}
			else
			{
				JsonObject->SetField(TEXT("Key"), NewJsonValue);
			}

			void* ValuePtr = MapHelper.GetValuePtr(i);
			if (FObjectProperty* TmpProp = CastField<FObjectProperty>(ValueType))
			{
				ValuePtr = TmpProp->GetObjectPropertyValue(ValuePtr);
			}
			NewJsonValue = UBSEditorFunctionLibrary::ExportPropertyToJson(ValuePtr, ValueType, SpecialType, SpecialExporter, ExtraString != "" ? ExtraString + FString("Value") + FString::FromInt(i) : ExtraString);
			if (NewJsonValue->TryGetObject(NewJsonObject))
			{
				if (NewJsonObject->IsValid() && NewJsonObject->Get()->Values.Num() > 0)
				{
					JsonObject->SetField(TEXT("Value"), NewJsonValue);
				}
			}
			else
			{
				JsonObject->SetField(TEXT("Value"), NewJsonValue);
			}

			if (JsonObject->HasField(TEXT("Key")) && JsonObject->HasField(TEXT("Value")))
			{
				JsonArray.Add(MakeShared<FJsonValueObject>(JsonObject));
			}
		}

		return MakeShared<FJsonValueArray>(JsonArray);
	}
	else if (FStructProperty* StructProp = CastField<FStructProperty>(Prop))
	{
		TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

		if (StructProp->Struct == FGameplayTag::StaticStruct())
		{
			FGameplayTag* TheTag = (FGameplayTag*)DataAddress;
			return SpecialExporter->ExportGameplayTag(*TheTag);
		}
		else if (StructProp->Struct == FGameplayTagContainer::StaticStruct())
		{
			FGameplayTagContainer* TheTags = (FGameplayTagContainer*)DataAddress;
			return SpecialExporter->ExportGameplayTagContainer(*TheTags);
		}
		else if (StructProp->Struct == FBSSocketSelector::StaticStruct())
		{
			FBSSocketSelector* TheStruct = (FBSSocketSelector*)DataAddress;
			return MakeShared<FJsonValueString>(*TheStruct->SocketName.ToString());
		}
		else if (SpecialType.Contains(StructProp->Struct) && SpecialExporter)
		{
			SpecialExporter->ExportSpecialStructToJson(DataAddress, StructProp, JsonObject, ExtraString);
		}
		else
		{
			UBSEditorFunctionLibrary::ExportStructToJson(DataAddress, StructProp->Struct, JsonObject, SpecialType, SpecialExporter, ExtraString);
		}

		return MakeShared<FJsonValueObject>(JsonObject);
	}

	return MakeShared<FJsonValueNull>();
}
#pragma endregion Json



#pragma region Lua
FString UBSEditorFunctionLibrary::FindChineseStringByID(const FString& TableString, int32 ID)
{
	FString FindStr = TEXT("[");
	FindStr = FindStr + FString::FromInt(ID);
	FindStr = FindStr + TEXT("]");

	int32 StartPos = TableString.Find(FindStr);
	StartPos = TableString.Find(TEXT("value"), ESearchCase::CaseSensitive, ESearchDir::FromStart, StartPos);
	int32 EndPos = TableString.Find(TEXT(","), ESearchCase::CaseSensitive, ESearchDir::FromStart, StartPos + 10);

	if (StartPos == -1 || EndPos == -1)
	{
		return FString();
	}

	FString Res = TableString.Mid(StartPos + 11, EndPos - StartPos - 12);

	return Res;
}

void UBSEditorFunctionLibrary::UpdatePropTagList(UBSEditorLuaBasicGI* GI, bool NeedCheckout)
{
	if (!GI)
	{
		return;
	}

	TArray<FString> NewTags;
	if (const UBSAEditorSettings* Setting = GetDefault<UBSAEditorSettings>())
	{
		FString Path = FPaths::ProjectContentDir() + Setting->PropTagPath;

		FString LuaString;
		if (FFileHelper::LoadFileToString(LuaString, *Path))
		{
			NewTags.Append(GI->ExtractFightProp(LuaString, TEXT("Prop")));
		}

		Path = FPaths::ProjectContentDir() + Setting->PropModeTagPath;
		if (FFileHelper::LoadFileToString(LuaString, *Path))
		{
			NewTags.Append(GI->ExtractFightProp(LuaString, TEXT("PropMode")));
		}
	}

	// 刷新Tag列表
	UBSEditorFunctionLibrary::RefreshTagList(TEXT("Prop"), NewTags, TArray<FString>{}, NeedCheckout);
	UBSEditorFunctionLibrary::RefreshTagList(TEXT("PropMode"), NewTags, TArray<FString>{}, NeedCheckout);
}

void UBSEditorFunctionLibrary::RefreshTagList(FString Key, const TArray<FString>& NewTags, const TArray<FString>& NewNotes, bool NeedCheckout)
{
	UGameplayTagsManager& GTMgr = UGameplayTagsManager::Get();

	// 这里获取所有的根标签
	FString TempStr;
	TArray<TSharedPtr<FGameplayTagNode>> RootTags;
	GTMgr.GetFilteredGameplayRootTags(TempStr, RootTags);

	// 判断需不需要刷新标签列表
	bool bNeedRefresh = true;
	TArray<FString> OldTags;
	for (int32 i = 0; i < RootTags.Num(); ++i)
	{
		if (RootTags[i]->GetCompleteTagString().Contains(Key))
		{
			bNeedRefresh = false;

			// 收集当前所有的BUFF标签字符串
			TArray<TSharedPtr<FGameplayTagNode>> ChildTags = RootTags[i]->GetChildTagNodes();
			for (int32 j = 0; j < ChildTags.Num(); ++j)
			{
				OldTags.Add(ChildTags[j]->GetCompleteTagString());
			}

			// 判断是否有旧标签无效
			for (int32 j = 0; j < OldTags.Num(); ++j)
			{
				if (NewTags.Contains(OldTags[j]) == false)
				{
					bNeedRefresh = true;
					break;
				}
			}
			if (bNeedRefresh)
				break;

			// 判断是否有新标签不存在
			for (int32 j = 0; j < NewTags.Num(); ++j)
			{
				if (OldTags.Contains(NewTags[j]) == false)
				{
					bNeedRefresh = true;
					break;
				}
			}

			break;
		}
	}

	if (!bNeedRefresh)
		return;

	FString ConfigFileName;
	UObject* TagListObj = nullptr;
	FName SourceName(TEXT("DefaultGameplayTags.ini"));
	if (const FGameplayTagSource* TagSource = GTMgr.FindTagSource(SourceName))
	{
		UGameplayTagsList* TagList = TagSource->SourceTagList;
		TagListObj = TagList;
		ConfigFileName = TagList->ConfigFileName;

		// 删除旧标签
		for (int32 i = TagList->GameplayTagList.Num() - 1; i >= 0; --i)
		{
			if (TagList->GameplayTagList[i].Tag.ToString().Contains(Key))
			{
				TagList->GameplayTagList.RemoveAt(i);
			}
		}

		// 添加新标签
		for (int32 i = 0; i < NewTags.Num(); ++i)
		{
			if (NewNotes.IsValidIndex(i))
			{
				TagList->GameplayTagList.AddUnique(FGameplayTagTableRow(FName(*NewTags[i]), NewNotes[i]));
			}
			else
			{
				TagList->GameplayTagList.AddUnique(FGameplayTagTableRow(FName(*NewTags[i])));
			}
		}

		// 迁出配置文件
		if (NeedCheckout)
		{
			FText ErrorMessage;
			SourceControlHelpers::CheckoutOrMarkForAdd(ConfigFileName, FText::FromString(ConfigFileName), nullptr, ErrorMessage);
		}

		TagListObj->TryUpdateDefaultConfigFile(ConfigFileName);
		GConfig->LoadFile(ConfigFileName);

		// 刷新标签树
		GTMgr.EditorRefreshGameplayTagTree();
	}
}

#pragma endregion Lua



#pragma region Export
void UBSEditorFunctionLibrary::ExportEnum(bool bNeedCheckOut)
{
	static const FString HiddenMeta = TEXT("Hidden");

	if (const UBSAEditorSettings* EditorSetting = GetDefault<UBSAEditorSettings>())
	{
		// 刷新类名映射表
		{
			TArray<UClass*> Classes;
			TMap<FString, FString> PathToEnum;

			// 寻找所有的蓝图类 并 筛选
			const FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName);
			TArray<FAssetData> AssetData;
			FARFilter ClassFilter;
			ClassFilter.PackagePaths.Append(EditorSetting->ExportEnumClassPaths);
			ClassFilter.ClassPaths.AddUnique(UBlueprint::StaticClass()->GetClassPathName());
			ClassFilter.ClassPaths.AddUnique(UBlueprintGeneratedClass::StaticClass()->GetClassPathName());
			ClassFilter.bRecursivePaths = true;
			ClassFilter.bRecursiveClasses = true;
			AssetRegistryModule.Get().GetAssets(ClassFilter, AssetData);
			AssetData.Sort();
			for (int32 i = 0; i < AssetData.Num(); ++i)
			{
				UBlueprint* CurBP = LoadObject<UBlueprint>(nullptr, *AssetData[i].GetSoftObjectPath().ToString());
				if (!CurBP)
				{
					continue;
				}

				UClass* CurClass = CurBP->GeneratedClass;
				if (!CurClass)
				{
					continue;
				}

				bool Flag = false;
				for (int32 j = 0; j < EditorSetting->ExportEnumClasses.Num(); ++j)
				{
					if (CurClass->IsChildOf(EditorSetting->ExportEnumClasses[j]))
					{
						Flag = true;
						break;
					}
				}
				if (!Flag)
				{
					continue;
				}

				Classes.Add(CurClass);
			}

			// 导出到中间资源中，方便后续的导出查询
			if (UDataTable* ClassTypeTable = EditorSetting->ExportEnumClassTable.LoadSynchronous())
			{
				int32 TotalNum = ClassTypeTable->GetRowNames().Num();

				if (bNeedCheckOut)
				{
					for (int32 i = 0; i < Classes.Num(); ++i)
					{
						if (Classes[i])
						{
							FString ClassName = Classes[i]->GetName();

							if (FBSClassTypeData* Result = ClassTypeTable->FindRow<FBSClassTypeData>(Classes[i]->GetFName(), DataTableFindName, false))
							{
								PathToEnum.Add(ClassName, Result->ClassName);
								continue;
							}
							else
							{
								FString EnumName = ClassName;

								EnumName = EnumName.Replace(TEXT("_"), TEXT(""));
								EnumName = EnumName.Replace(TEXT("BP"), TEXT(""));
								EnumName = EnumName.Left(EnumName.Len() - 1);

								FBSClassTypeData Data;
								Data.ClassName = EnumName;
								Data.EnumValue = (++TotalNum);

								PathToEnum.Add(ClassName, EnumName);
								ClassTypeTable->AddRow(FName(ClassName), Data);

								ClassTypeTable->MarkPackageDirty();
							}
						}
					}

					SourceControlHelpers::CheckOutFile(ClassTypeTable->GetPathName(), true);
					TArray<UPackage*> Packages;
					Packages.Add(ClassTypeTable->GetPackage());
					UEditorLoadingAndSavingUtils::SavePackages(Packages, true);
				}
				else
				{
					for (int32 i = 0; i < Classes.Num(); ++i)
					{
						if (Classes[i])
						{
							FString ClassName = Classes[i]->GetName();

							if (FBSClassTypeData* Result = ClassTypeTable->FindRow<FBSClassTypeData>(FName(ClassName), DataTableFindName, false))
							{
								PathToEnum.Add(ClassName, Result->ClassName);
							}
						}
					}
				}
			}

#if 0
			// 导出客户端代码
			FString ClientCode = TEXT("local function LRequire(InPath)\n\tlocal _, Module = pcall(require, InPath)\n\treturn Module\nend\n\nGame.BSManager.ScriptClasses = {\n");
			for (int32 i = 0; i < Classes.Num(); ++i)
			{
				if (Classes[i])
				{
					bool bFind = false;
					FString ClassName = Classes[i]->GetName();
					FString EnumName = ClassName;
					if (FString* Result = PathToEnum.Find(ClassName))
					{
						bFind = true;
						EnumName = *Result;
					}

					int32 PointLocation;
					FString ClassPath = Classes[i]->GetPathName();
					// 先把.后面的去掉
					ClassPath.FindChar('.', PointLocation);
					ClassPath = ClassPath.Left(PointLocation);
					ClassPath = ClassPath.Replace(TEXT("/"), TEXT("."));

					FString ClientPath = ClassPath;
					for (TArray<FBSAEditorExportReplace>::TConstIterator It(EditorSetting->ExportClientLuaCodeReplacePath); It; ++It)
					{
						if (ClientPath.Contains(It->Origin))
						{
							ClientPath = ClientPath.Replace(*It->Origin, *It->Replace);
						}
					}
					if (bFind)
					{
						ClientCode += TEXT("\t[ETE.EBSClassType.") + EnumName + TEXT("] = LRequire(\"") + ClientPath + TEXT("\"),\n");
					}
					else
					{
						ClientCode += TEXT("\t[\"") + Classes[i]->GetPathName() + TEXT("\"] = LRequire(\"") + ClientPath + TEXT("\"),\n");
					}
				}
			}
			ClientCode += TEXT("}\n\n");
			ClientCode += TEXT("Game.BSManager.NativeClasses = {\n");
			for (int32 i = 0; i < Classes.Num(); ++i)
			{
				if (Classes[i] && !Classes[i]->IsChildOf<UBSATask>())
				{
					bool bFind = false;
					FString ClassName = Classes[i]->GetName();
					FString EnumName = ClassName;
					if (FString* Result = PathToEnum.Find(ClassName))
					{
						bFind = true;
						EnumName = *Result;
					}

					if (bFind)
					{
						ClientCode += TEXT("\t[ETE.EBSClassType.") + EnumName + TEXT("] = Game.ResourceManager:GetClassByPath(\"") + Classes[i]->GetPathName() + TEXT("\"),\n");
					}
					else
					{
						ClientCode += TEXT("\t[\"") + Classes[i]->GetPathName() + TEXT("\"] = LRequire(\"") + Classes[i]->GetPathName() + TEXT("\"),\n");
					}
				}
			}
			ClientCode += TEXT("}\n\n");
			if (bNeedCheckOut)
			{
				UBSEditorFunctionLibrary::CheckOutByPerforce(*(FPaths::ProjectContentDir() + EditorSetting->ClientClassTypeToClassPath));
			}
			FFileHelper::SaveStringToFile(ClientCode, *(FPaths::ProjectContentDir() + EditorSetting->ClientClassTypeToClassPath), FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), 4);


			// 导出服务器代码(临时版本，不是完美逻辑)
			FString ServerCode = TEXT("local ETE = kg_require(\"logicScript.ability.AbEnumExport\")\n\n\n\nClientClassToServerClass = {\n");
			for (int32 i = 0; i < Classes.Num(); ++i)
			{
				if (Classes[i])
				{
					bool bFind = false;
					FString ClassName = Classes[i]->GetName();
					FString EnumName = ClassName;
					if (FString* Result = PathToEnum.Find(ClassName))
					{
						bFind = true;
						EnumName = *Result;
					}

					FString ServerPath = Classes[i]->GetPathName();
					ServerPath = ServerPath.Left(ServerPath.Len() - 2);

					for (TArray<FBSAEditorExportReplace>::TConstIterator It(EditorSetting->ExportServerLuaCodeReplacePath); It; ++It)
					{
						if (ServerPath.Contains(It->Origin))
						{
							ServerPath = ServerPath.Replace(*It->Origin, *It->Replace);
						}
					}

					int32 LastPointLocation;
					ServerPath.FindLastChar('.', LastPointLocation);
					FString Left = ServerPath.Left(LastPointLocation).ToLower();
					Left = Left.Replace(TEXT("logicscript"), TEXT("logicScript"));
					FString Right = ServerPath.Right(ServerPath.Len() - LastPointLocation);

					if (bFind)
					{
						ServerCode += TEXT("\t[ETE.EBSClassType.") + EnumName + TEXT("] = \"") + Left + Right + TEXT("\",\n");
					}
					else
					{
						ServerCode += TEXT("\t[\"") + Classes[i]->GetPathName() + TEXT("\"] = \"") + ServerPath + TEXT("\",\n");
					}
				}
			}
			ServerCode += TEXT("}\n\n");
			if (bNeedCheckOut)
			{
				UBSEditorFunctionLibrary::CheckOutByPerforce(*(FPaths::ProjectContentDir() + EditorSetting->ServerClassTypeToClassPath));
			}
			FFileHelper::SaveStringToFile(ServerCode, *(FPaths::ProjectContentDir() + EditorSetting->ServerClassTypeToClassPath), FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), 4);
#endif
			
		}



		// 读取类映射表并转换成枚举
		FString outRes = TEXT("ETE = {}\n\n");
		FString outServerRes;
		if (UDataTable* ClassTypeTable = EditorSetting->ExportEnumClassTable.LoadSynchronous())
		{
			TArray<FBSClassTypeData*> Rows;
			ClassTypeTable->GetAllRows<FBSClassTypeData>(TEXT("BSClassToEnumAllRows"), Rows);

			FString ClassEnumString = TEXT("EBSClassType = {\n");
			for (int32 i = 0; i < Rows.Num(); ++i)
			{
				ClassEnumString += TEXT("\t") + Rows[i]->ClassName + TEXT(" = ") + FString::FromInt(Rows[i]->EnumValue) + TEXT(",\n");
			}
			outRes += TEXT("ETE.") + ClassEnumString + TEXT("}\n\n");
			outServerRes += ClassEnumString + TEXT("}\n\n");
		}


		// 寻找所有蓝图枚举
		TArray<FAssetData> AssetData;
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>("AssetRegistry");
		FARFilter EnumFilter;
		EnumFilter.PackagePaths.Add("/Game");
		EnumFilter.ClassPaths.Add(UUserDefinedEnum::StaticClass()->GetClassPathName());
		EnumFilter.bRecursivePaths = true;
		EnumFilter.bRecursiveClasses = true;
		AssetRegistryModule.Get().GetAssets(EnumFilter, AssetData);
		AssetData.Sort();


		// 导出Description里有"EnumToExport"标记的蓝图枚举
		for (FAssetData SingleAsset : AssetData)
		{
			UUserDefinedEnum* tEnum = Cast<UUserDefinedEnum>(SingleAsset.GetAsset());
			if (tEnum && tEnum->EnumDescription.ToString().Contains("EnumToExport"))
			{
				FString SingleRes = tEnum->GetFName().ToString() + TEXT(" = {\n");
				for (int32 index = 0; index < tEnum->GetMaxEnumValue(); index++)
				{
					SingleRes += TEXT("\t") + tEnum->GetDisplayNameTextByIndex(index).ToString() + TEXT(" = ") + FString::FromInt(index) + TEXT(", -- ")
						+ tEnum->GetToolTipTextByIndex(index).ToString() + TEXT("\n");
				}
				outRes += TEXT("ETE.") + SingleRes + TEXT("}\n\n");
				outServerRes += SingleRes + TEXT("}\n\n");
			}
		}


		// 导出EBS相关的C++枚举
		TArray<UObject*> tResult;
		GetObjectsOfClass(UEnum::StaticClass(), tResult);
		tResult.Sort();
		for (UObject* SingleObject : tResult)
		{
			// 蓝图枚举已完成导出，跳过
			if (UUserDefinedEnum* tBPEnum = Cast<UUserDefinedEnum>(SingleObject))
			{
				continue;
			}

			UEnum* tEnum = Cast<UEnum>(SingleObject);
			if (tEnum)
			{
				// 导出名称包含EBS的C++枚举
				if (tEnum->GetName().Contains(TEXT("EBS"), ESearchCase::CaseSensitive) || tEnum->GetName().Contains(TEXT("CollisionChannel"), ESearchCase::CaseSensitive))
				{
					FString SingleRes = tEnum->GetFName().ToString() + TEXT(" = {\n");
					for (int32 index = 0; index < tEnum->GetMaxEnumValue(); index++)
					{
						if (tEnum->GetName().Contains(TEXT("CollisionChannel"), ESearchCase::CaseSensitive) && tEnum->HasMetaData(*HiddenMeta, index))
						{
							continue;
						}

						SingleRes += TEXT("\t") + tEnum->GetNameStringByIndex(index) + TEXT(" = ") + FString::FromInt(index) + TEXT(", -- ") + tEnum->GetDisplayNameTextByIndex(index).ToString() + TEXT("\n");
					}
					outRes += TEXT("ETE.") + SingleRes + TEXT("}\n\n");
					outServerRes += SingleRes + TEXT("}\n\n");

					continue;
				}
			}
		}


		for (FString SingleExportEnumPath : EditorSetting->ExportEnumPaths)
		{
			if (SingleExportEnumPath.Contains(TEXT("Server/script_lua/")))
			{
				if (bNeedCheckOut)
				{
					UBSEditorFunctionLibrary::CheckOutByPerforce(*(FPaths::ProjectContentDir() + SingleExportEnumPath));
				}
				FFileHelper::SaveStringToFile(outServerRes, *(FPaths::ProjectContentDir() + SingleExportEnumPath), FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), 4);
			}
			else
			{
				if (bNeedCheckOut)
				{
					UBSEditorFunctionLibrary::CheckOutByPerforce(*(FPaths::ProjectContentDir() + SingleExportEnumPath));
				}
				FFileHelper::SaveStringToFile(outRes, *(FPaths::ProjectContentDir() + SingleExportEnumPath), FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), 4);
			}
		}
	}
}

int32 UBSEditorFunctionLibrary::GetAbilityHeadID(int32 InAbilityID)
{
	int32 HeadID = -1;

	if (InAbilityID < 1000000)
	{
		HeadID = 0;
	}
	else if (InAbilityID >= 1000000 && InAbilityID < 10000000)
	{
		HeadID = InAbilityID / 100;
	}
	else if (InAbilityID >= 100000000)
	{
		HeadID = InAbilityID / 100000;
	}

	return HeadID;
}

FString UBSEditorFunctionLibrary::GetAbilityFolderPath(bool bSkill)
{
	FString FolderPath = "";
	if (const UBSAEditorSettings* Settings = GetDefault<UBSAEditorSettings>())
	{
		if (bSkill)
		{
			FolderPath = FPaths::ProjectContentDir() + Settings->SkillJsonPath;
		}
		else
		{
			FolderPath = FPaths::ProjectContentDir() + Settings->BuffJsonPath;
		}
	}

	return FolderPath;
}

FString UBSEditorFunctionLibrary::GetCombatTreeFolderPath()
{
	return GetAbilityFolderPath(false).Replace(TEXT("EditorTemplate/Json/Buff"), TEXT("Script/Data/Config/BattleSystem/CombatTree"));
}

FString UBSEditorFunctionLibrary::GetAutoSkillTreeFolderPath()
{
	return GetAbilityFolderPath(false).Replace(TEXT("EditorTemplate/Json/Buff"), TEXT("Script/Data/Config/BattleSystem/AutoSkillTree"));
}

FString UBSEditorFunctionLibrary::GetBeatenTreeFolderPath()
{
	return GetAbilityFolderPath(false).Replace(TEXT("EditorTemplate/Json/Buff"), TEXT("Script/Data/Config/BattleSystem/BeatenTree"));
}

FString UBSEditorFunctionLibrary::GetPassiveSkillTreeFolderPath()
{
	return GetAbilityFolderPath(false).Replace(TEXT("EditorTemplate/Json/Buff"), TEXT("Script/Data/Config/BattleSystem/PassiveSkillTree"));
}

FString UBSEditorFunctionLibrary::GetAbilityJsonFilePath(int32 InAbilityID, bool bSkill)
{
	FString CurFile = "";

	if (const UBSAEditorSettings* Settings = GetDefault<UBSAEditorSettings>())
	{
		FString FolderPath = GetAbilityFolderPath(bSkill);

		int32 HeadID = UBSEditorFunctionLibrary::GetAbilityHeadID(InAbilityID);
		if (HeadID <= 0)
		{
			CurFile = FolderPath + TEXT("Common.json");
		}
		else
		{
			CurFile = FolderPath + FString::FromInt(HeadID) + TEXT(".json");
		}
	}

	return CurFile;
}

bool UBSEditorFunctionLibrary::CheckOutByPerforce(FString FilePath)
{
	FText ErrorMessage;
	return  SourceControlHelpers::CheckoutOrMarkForAdd(FilePath, FText::FromString(FilePath), nullptr, ErrorMessage);
}

TSharedPtr<FJsonObject> UBSEditorFunctionLibrary::ExportAbilityToJson(UBSAAsset* InAsset)
{
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

	if (!InAsset || !JsonObject.IsValid())
	{
		return nullptr;
	}

	UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance();
	if (!EAMgr)
	{
		return nullptr;
	}

	InAsset->UpdateKeyframeList();


	TArray<UStruct*> SpecialType;
	SpecialType.Add(FRuntimeFloatCurve::StaticStruct());
	SpecialType.Add(FRuntimeVectorCurve::StaticStruct());
	SpecialType.Add(FKGRemapFloatCurve::StaticStruct());
	SpecialType.Add(FKGRemapVectorCurve::StaticStruct());
	SpecialType.Add(FRuntimeCurveLinearColor::StaticStruct());
	SpecialType.Add(FKGRemapColorCurve::StaticStruct());

	SpecialType.Add(FBSATaskSelector::StaticStruct());
	SpecialType.Add(FBSATaskSelectorList::StaticStruct());
	SpecialType.Add(FBSATaskInputInfo::StaticStruct());
	SpecialType.Add(FBSATaskOutputInfo::StaticStruct());
	SpecialType.Add(FBSATransformCreater::StaticStruct());


	UBSJsonExporter* JsonExporter = NewObject<UBSJsonExporter>(GetTransientPackage(), UBSAJsonExporter::StaticClass());
	if (UBSAJsonExporter* BSAJE = Cast<UBSAJsonExporter>(JsonExporter))
	{
		BSAJE->CachedAsset = InAsset;
	}

	UBSEditorFunctionLibrary::ExportObjectToJson(InAsset, JsonObject, SpecialType, JsonExporter);

	TArray<TSharedPtr<FJsonValue>> JsonArray;
	TArray<TSharedPtr<FJsonValue>> JsonSkillArray;
	TArray<TSharedPtr<FJsonValue>> JsonBuffArray;
	TArray<TSoftObjectPtr<UObject>> ReferencePathList = EAMgr->GetBSAAssetResources(InAsset);
	for (int32 i = 0; i < ReferencePathList.Num(); ++i)
	{
		FString ThePath = ReferencePathList[i].ToString();

		if (ThePath.IsEmpty() || ThePath.Contains(TEXT("/Engine/Transient")))
			continue;

		if (ThePath.Contains(TEXT("/Game/EditorTemplate/Skill/")))
		{
			JsonSkillArray.Add(MakeShared<FJsonValueNumber>(FCString::Atoi(*ReferencePathList[i].GetAssetName())));
		}
		else if (ThePath.Contains(TEXT("/Game/EditorTemplate/Buff/")))
		{
			JsonBuffArray.Add(MakeShared<FJsonValueNumber>(FCString::Atoi(*ReferencePathList[i].GetAssetName())));
		}
		else
		{
			JsonArray.Add(MakeShared<FJsonValueString>(ReferencePathList[i].ToString()));
		}
	}
	JsonObject->SetArrayField(TEXT("OtherResources"), JsonArray);
	JsonObject->SetArrayField(TEXT("OtherSkills"), JsonSkillArray);
	JsonObject->SetArrayField(TEXT("OtherBuffs"), JsonBuffArray);

	return JsonObject;
}

void UBSEditorFunctionLibrary::ExportCurveData(UBSEditorLuaBasicGI* GI)
{
	if (!GI)
	{
		return;
	}

	FString FileWriteData;
	TSharedPtr<TJsonWriter<TCHAR>> JsonWriter;
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName);
	TArray<FAssetData> AssetData;
	FARFilter ClassFilter;
	ClassFilter.ClassPaths.AddUnique(UCurveFloat::StaticClass()->GetClassPathName());
	ClassFilter.ClassPaths.AddUnique(UCurveVector::StaticClass()->GetClassPathName());
	ClassFilter.ClassPaths.AddUnique(UCurveLinearColor::StaticClass()->GetClassPathName());
	ClassFilter.ClassPaths.AddUnique(UCurveTable::StaticClass()->GetClassPathName());
	AssetRegistryModule.Get().GetAssets(ClassFilter, AssetData);
	AssetData.Sort();

	for (int32 Loop = 0; Loop < AssetData.Num(); ++Loop)
	{
		UObject* AssetObject = AssetData[Loop].GetAsset();
		FString PathName = AssetObject->GetPathName();
		if (!PathName.Contains(TEXT("Game/Blueprint/Curve")))
		{
			continue;
		}

		TSharedPtr<FJsonObject> CurveObject = MakeShareable(new FJsonObject());

		if (UCurveFloat* FC = Cast<UCurveFloat>(AssetObject))
		{
			TArray<TSharedPtr<FJsonValue>> JsonArray;

			int32 KeyNum = FC->FloatCurve.Keys.Num();
			for (int32 i = 0; i < KeyNum; ++i)
			{
				TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
				UBSEditorFunctionLibrary::ExportStructToJson(&FC->FloatCurve.Keys[i], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

				JsonArray.Add(MakeShared<FJsonValueObject>(NewObject));
			}

			CurveObject->SetStringField(TEXT("GID"), FString::Printf(TEXT("%lld"), ULowLevelFunctions::GetGlobalUniqueID()));
			CurveObject->SetNumberField(TEXT("Type"), 1);
			CurveObject->SetArrayField(TEXT("Keys"), JsonArray);
		}
		else if (UCurveVector* VC = Cast<UCurveVector>(AssetObject))
		{
			TArray<TSharedPtr<FJsonValue>> JsonArrayX, JsonArrayY, JsonArrayZ;
			for (int32 i = 0; i < 3; ++i)
			{
				TArray<TSharedPtr<FJsonValue>>* CurArray = nullptr;

				if (i == 0)
					CurArray = &JsonArrayX;
				else if (i == 1)
					CurArray = &JsonArrayY;
				else
					CurArray = &JsonArrayZ;

				int32 KeyNum = VC->FloatCurves[i].Keys.Num();
				for (int32 j = 0; j < KeyNum; ++j)
				{
					TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
					UBSEditorFunctionLibrary::ExportStructToJson(&VC->FloatCurves[i].Keys[j], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

					CurArray->Add(MakeShared<FJsonValueObject>(NewObject));
				}
			}

			CurveObject->SetStringField(TEXT("GID"), FString::Printf(TEXT("%lld"), ULowLevelFunctions::GetGlobalUniqueID()));
			CurveObject->SetNumberField(TEXT("Type"), 2);
			CurveObject->SetArrayField(TEXT("XKeys"), JsonArrayX);
			CurveObject->SetArrayField(TEXT("YKeys"), JsonArrayY);
			CurveObject->SetArrayField(TEXT("ZKeys"), JsonArrayZ);
		}
		else if (UCurveLinearColor* LC = Cast<UCurveLinearColor>(AssetObject))
		{
			TArray<TSharedPtr<FJsonValue>> JsonArrayX, JsonArrayY, JsonArrayZ, JsonArrayW;
			for (int32 i = 0; i < 4; ++i)
			{
				TArray<TSharedPtr<FJsonValue>>* CurArray = nullptr;

				if (i == 0)
					CurArray = &JsonArrayX;
				else if (i == 1)
					CurArray = &JsonArrayY;
				else if (i == 2)
					CurArray = &JsonArrayZ;
				else
					CurArray = &JsonArrayW;

				int32 KeyNum = LC->FloatCurves[i].Keys.Num();
				for (int32 j = 0; j < KeyNum; ++j)
				{
					TSharedPtr<FJsonObject> NewObject = MakeShareable(new FJsonObject());
					UBSEditorFunctionLibrary::ExportStructToJson(&LC->FloatCurves[i].Keys[j], FRichCurveKey::StaticStruct(), NewObject, TArray<UStruct*>{});

					CurArray->Add(MakeShared<FJsonValueObject>(NewObject));
				}
			}

			CurveObject->SetStringField(TEXT("GID"), FString::Printf(TEXT("%lld"), ULowLevelFunctions::GetGlobalUniqueID()));
			CurveObject->SetNumberField(TEXT("Type"), 3);
			CurveObject->SetArrayField(TEXT("XKeys"), JsonArrayX);
			CurveObject->SetArrayField(TEXT("YKeys"), JsonArrayY);
			CurveObject->SetArrayField(TEXT("ZKeys"), JsonArrayZ);
			CurveObject->SetArrayField(TEXT("WKeys"), JsonArrayW);
		}

		JsonObject->SetObjectField(PathName, CurveObject);
	}

	FString LuaPath = FPaths::ProjectContentDir() + TEXT("Script/Data/Config/Curves/Curves.lua");

	// 查询文件是否有效，无效的话创建一个新的文件
	if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*LuaPath))
	{
		FFileHelper::SaveStringToFile(FileWriteData, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
	}

	JsonWriter = TJsonWriterFactory<TCHAR>::Create(&FileWriteData);
	FJsonSerializer::Serialize(JsonObject.ToSharedRef(), *JsonWriter);
	// 导出Lua表
	FileWriteData = GI->ConvertJsonToLuaTable(FileWriteData, -1);
	FFileHelper::SaveStringToFile(FileWriteData, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
}

void UBSEditorFunctionLibrary::ExportSkillData(UBSEditorLuaBasicGI* GI, int32 HeadID, int32 ExportType, int32 UpdateID)
{	
	if (!GI)
	{
		return;
	}

	UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance();
	if (!EAMgr)
	{
		return;
	}
	
	// 零、载入技能数据
	FString FileReadData, FileWriteData;
	TArray<TSharedPtr<FJsonValue>> JsonValues;
	TSharedPtr<TJsonWriter<TCHAR>> JsonWriter;
	TMap<FString, TArray<int32>> ExportCategoryMap;

	if (ExportType == 0)
	{
		// 删除原先json技能文件
		FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively(*GetAbilityFolderPath(true));
		// 删除原先lua技能文件
		FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively(*GetAbilityFolderPath(true).Replace(TEXT("EditorTemplate/Json/"), TEXT("Script/Data/Config/BattleSystem/")));
	}

	// 一、导出技能数据
	if (ExportType != 2)
	{
		ExportCategoryMap.Empty();
		TArray<int32> SkillIDList;
		if (UpdateID == 0)
		{
			SkillIDList = EAMgr->GetSkillIDList();
			SkillIDList.Sort();
		}
		else
		{
			SkillIDList.Add(UpdateID);
		}

		for (int32 i = 0; i < SkillIDList.Num(); ++i)
		{
			if (HeadID >= 0 && UBSEditorFunctionLibrary::GetAbilityHeadID(SkillIDList[i]) != HeadID)
				continue;

			FString FilePath = UBSEditorFunctionLibrary::GetAbilityJsonFilePath(SkillIDList[i], true);
			if (FilePath.IsEmpty())
				continue;

			if (TArray<int32>* Res = ExportCategoryMap.Find(FilePath))
			{
				Res->Add(SkillIDList[i]);
			}
			else
			{
				ExportCategoryMap.Add(FilePath, TArray<int32>{SkillIDList[i]});
			}
		}
		for (TMap<FString, TArray<int32>>::TIterator It(ExportCategoryMap); It; ++It)
		{
			if (It->Value.Num() <= 0)
			{
				continue;
			}

			FString LuaPath = It->Key;
			LuaPath = LuaPath.Replace(TEXT("EditorTemplate/Json/"), TEXT("Script/Data/Config/BattleSystem/"));
			LuaPath = LuaPath.Replace(TEXT(".json"), TEXT(".lua"));

			JsonValues.Empty();
			FileWriteData.Empty();

			// 查询文件是否有效，无效的话创建一个新的文件
			if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*It->Key))
			{
				FFileHelper::SaveStringToFile(FileWriteData, *It->Key, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
				FFileHelper::SaveStringToFile(FileWriteData, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
			}

			if (UpdateID == 0)
			{
				for (int32 i = 0; i < It->Value.Num(); ++i)
				{
					if (UBSASkillAsset* Asset = EAMgr->GetSkillAssetSoftObjectByID(It->Value[i]).LoadSynchronous())
					{
						TSharedPtr<FJsonObject> NewObject = UBSEditorFunctionLibrary::ExportAbilityToJson(Asset);

						JsonValues.Add(MakeShareable(new FJsonValueObject(NewObject)));
					}
				}
			}
			else
			{
				if (FFileHelper::LoadFileToString(FileReadData, *It->Key))
				{
					int32 Index = -1;
					TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(FileReadData);
					if (FJsonSerializer::Deserialize(JsonReader, JsonValues))
					{
						for (int32 i = 0; i < JsonValues.Num(); ++i)
						{
							TSharedPtr<FJsonObject>* TheObject = nullptr;
							if (JsonValues[i]->TryGetObject(TheObject))
							{
								FString Name = TEXT("ID");
								int32 AssetID = 0;
								if ((*TheObject)->TryGetNumberField(Name, AssetID))
								{
									if (AssetID == UpdateID)
									{
										Index = i;
										break;
									}
								}
							}
						}
					}

					if (UBSASkillAsset* Asset = EAMgr->GetSkillAssetSoftObjectByID(UpdateID).LoadSynchronous())
					{
						TSharedPtr<FJsonObject> NewObject = UBSEditorFunctionLibrary::ExportAbilityToJson(Asset);

						if (Index >= 0)
						{
							JsonValues.RemoveAt(Index);
							JsonValues.Insert(MakeShareable(new FJsonValueObject(NewObject)), Index);
						}
						else
						{
							JsonValues.Add(MakeShareable(new FJsonValueObject(NewObject)));
						}
					}
				}
			}

			JsonWriter = TJsonWriterFactory<TCHAR>::Create(&FileWriteData);
			FJsonSerializer::Serialize(JsonValues, *JsonWriter);
			// 导出Json表
			FFileHelper::SaveStringToFile(FileWriteData, *It->Key, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
			// 导出Lua表
			FileWriteData = GI->ConvertJsonToLuaTable(FileWriteData, UBSEditorFunctionLibrary::GetAbilityHeadID(UpdateID == 0 ? It->Value[0] : UpdateID) * 10 + 1);
			FFileHelper::SaveStringToFile(FileWriteData, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
		}
	}
}

void UBSEditorFunctionLibrary::ExportBuffData(UBSEditorLuaBasicGI* GI, int32 HeadID, int32 ExportType, int32 UpdateID)
{
	if (!GI)
	{
		return;
	}

	UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance();
	if (!EAMgr)
	{
		return;
	}

	FString FileReadData, FileWriteData;
	TArray<TSharedPtr<FJsonValue>> JsonValues;
	TSharedPtr<TJsonWriter<TCHAR>> JsonWriter;
	TMap<FString, TArray<int32>> ExportCategoryMap;

	if (ExportType == 0)
	{
		// 删除原先json Buff文件
		FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively(*GetAbilityFolderPath(false));
		// 删除原先lua Buff文件
		FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively(*GetAbilityFolderPath(false).Replace(TEXT("EditorTemplate/Json/"), TEXT("Script/Data/Config/BattleSystem/")));
	}

	// 二、导出BUFF数据
	if (ExportType != 1)
	{
		ExportCategoryMap.Empty();
		TArray<int32> BuffIDList;
		if (UpdateID == 0)
		{
			BuffIDList = EAMgr->GetBuffIDList();
			BuffIDList.Sort();
		}
		else
		{
			BuffIDList.Add(UpdateID);
		}

		for (int32 i = 0; i < BuffIDList.Num(); ++i)
		{
			if (HeadID >= 0 && UBSEditorFunctionLibrary::GetAbilityHeadID(BuffIDList[i]) != HeadID)
				continue;

			FString FilePath = UBSEditorFunctionLibrary::GetAbilityJsonFilePath(BuffIDList[i], false);
			if (FilePath.IsEmpty())
				continue;

			if (TArray<int32>* Res = ExportCategoryMap.Find(FilePath))
			{
				Res->Add(BuffIDList[i]);
			}
			else
			{
				ExportCategoryMap.Add(FilePath, TArray<int32>{BuffIDList[i]});
			}
		}
		for (TMap<FString, TArray<int32>>::TIterator It(ExportCategoryMap); It; ++It)
		{
			if (It->Value.Num() <= 0)
			{
				continue;
			}

			FString LuaPath = It->Key;
			LuaPath = LuaPath.Replace(TEXT("EditorTemplate/Json/"), TEXT("Script/Data/Config/BattleSystem/"));
			LuaPath = LuaPath.Replace(TEXT(".json"), TEXT(".lua"));

			JsonValues.Empty();
			FileWriteData.Empty();

			// 查询文件是否有效，无效的话创建一个新的文件
			if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*It->Key))
			{
				FFileHelper::SaveStringToFile(FileWriteData, *It->Key, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
				FFileHelper::SaveStringToFile(FileWriteData, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
			}

			if (UpdateID == 0)
			{
				for (int32 i = 0; i < It->Value.Num(); ++i)
				{
					if (UBSABuffAsset* Asset = EAMgr->GetBuffAssetSoftObjectByID(It->Value[i]).LoadSynchronous())
					{
						TSharedPtr<FJsonObject> NewObject = UBSEditorFunctionLibrary::ExportAbilityToJson(Asset);

						JsonValues.Add(MakeShareable(new FJsonValueObject(NewObject)));
					}
				}
			}
			else
			{
				if (FFileHelper::LoadFileToString(FileReadData, *It->Key))
				{
					int32 Index = -1;
					TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(FileReadData);
					if (FJsonSerializer::Deserialize(JsonReader, JsonValues))
					{
						for (int32 i = 0; i < JsonValues.Num(); ++i)
						{
							TSharedPtr<FJsonObject>* TheObject = nullptr;
							if (JsonValues[i]->TryGetObject(TheObject))
							{
								FString Name = TEXT("ID");
								int32 AssetID = 0;
								if ((*TheObject)->TryGetNumberField(Name, AssetID))
								{
									if (AssetID == UpdateID)
									{
										Index = i;
										break;
									}
								}
							}
						}
					}

					if (UBSABuffAsset* Asset = EAMgr->GetBuffAssetSoftObjectByID(UpdateID).LoadSynchronous())
					{
						TSharedPtr<FJsonObject> NewObject = UBSEditorFunctionLibrary::ExportAbilityToJson(Asset);

						if (Index >= 0)
						{
							JsonValues.RemoveAt(Index);
							JsonValues.Insert(MakeShareable(new FJsonValueObject(NewObject)), Index);
						}
						else
						{
							JsonValues.Add(MakeShareable(new FJsonValueObject(NewObject)));
						}
					}
				}
			}

			JsonWriter = TJsonWriterFactory<TCHAR>::Create(&FileWriteData);
			FJsonSerializer::Serialize(JsonValues, *JsonWriter);
			// 导出Json表
			FFileHelper::SaveStringToFile(FileWriteData, *It->Key, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
			// 导出Lua表
			FileWriteData = GI->ConvertJsonToLuaTable(FileWriteData, UBSEditorFunctionLibrary::GetAbilityHeadID(UpdateID == 0 ? It->Value[0] : UpdateID) * 10 + 2);
			FFileHelper::SaveStringToFile(FileWriteData, *LuaPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), EFileWrite::FILEWRITE_EvenIfReadOnly);
		}
	}
}

void UBSEditorFunctionLibrary::ExportCombatTreeData()
{
	UDecisionTreeAssetManager* DTMgr = UDecisionTreeAssetManager::GetInstance();
	if (!DTMgr)
	{
		return;
	}

	// 一、删除原先lua CombatTree文件
	FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively(*GetCombatTreeFolderPath());

	// 二、导出CombatTree数据
	TArray<int32> CombatTreeList = DTMgr->GetCombatTreeList();
	for (int32 i = 0; i < CombatTreeList.Num(); ++i)
	{
		DTMgr->ExportCombatTreeData(CombatTreeList[i]);
	}
}

void UBSEditorFunctionLibrary::ExportAutoSkillTreeData()
{
	UDecisionTreeAssetManager* DTMgr = UDecisionTreeAssetManager::GetInstance();
	if (!DTMgr)
	{
		return;
	}

	// 一、删除原先lua AutoSkillTree文件
	FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively(*GetAutoSkillTreeFolderPath());

	// 二、导出AutoSkillTree数据
	TArray<int32> AutoSkillTreeList = DTMgr->GetAutoSkillTreeList();
	for (int32 i = 0; i < AutoSkillTreeList.Num(); ++i)
	{
		DTMgr->ExportAutoSkillTreeData(AutoSkillTreeList[i]);
	}
}

void UBSEditorFunctionLibrary::ExportBeatenTreeData()
{
	UDecisionTreeAssetManager* DTMgr = UDecisionTreeAssetManager::GetInstance();
	if (!DTMgr)
	{
		return;
	}

	// 一、删除原先lua BeatenTree文件
	FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively(*GetBeatenTreeFolderPath());

	// 二、导出BeatenTree数据
	TArray<int32> BeatenTreeList = DTMgr->GetBeatenTreeList();
	for (int32 i = 0; i < BeatenTreeList.Num(); ++i)
	{
		DTMgr->ExportBeatenTreeData(BeatenTreeList[i]);
	}
}

void UBSEditorFunctionLibrary::ExportPassiveSkillData()
{
	UDecisionTreeAssetManager* DTMgr = UDecisionTreeAssetManager::GetInstance();
	if (!DTMgr)
	{
		return;
	}

	// 一、删除原先lua PassiveSkillTree文件
	FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively(*GetPassiveSkillTreeFolderPath());

	// 二、导出PassiveSkillTree数据
	TArray<int32> PassiveSkillTreeList = DTMgr->GetPassiveSkillTreeList();
	for (int32 i = 0; i < PassiveSkillTreeList.Num(); ++i)
	{
		DTMgr->ExportPassiveSkillTreeData(PassiveSkillTreeList[i]);
	}
}

#pragma endregion Export






#pragma region CheckResource
void UBSEditorFunctionLibrary::CheckSkillBuffResouces()
{
	UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance();
	if (!EAMgr)
	{
		return;
	}

	TArray<FString> ResourceList;
	TArray<FString> TempResourceList;
	TArray<int32> IDList;

	UE_LOG(LogTemp, Warning, TEXT("================================================================="));
	UE_LOG(LogTemp, Warning, TEXT("==================== Check Resources Started ===================="));
	UE_LOG(LogTemp, Warning, TEXT("================================================================="));

	// 1、检查技能的Resource
	IDList = EAMgr->GetSkillIDList();
	IDList.Sort();
	for (int32 a = 0; a < IDList.Num(); a++)
	{
		if (UBSASkillAsset* SkillAsset = EAMgr->GetSkillAssetByID(IDList[a]))
		{
			for (int32 i = 0; i < SkillAsset->Sections.Num(); ++i)
			{
				for (int32 j = 0; j < SkillAsset->Sections[i].TaskList.Num(); ++j)
				{
					if (SkillAsset->Sections[i].TaskList[j])
					{
						ResourceList.Empty();
						SkillAsset->Sections[i].TaskList[j]->GetReferenceResources(ResourceList);
						TempResourceList = UBSEditorFunctionLibrary::CheckResouces(ResourceList);
						if (TempResourceList.Num() > 0)
						{
							UE_LOG(LogTemp, Warning, TEXT("SkillID: %i, TaskName: %s, FindInValid Resource:"), IDList[a], *(SkillAsset->Sections[i].TaskList[j]->GetName()));
							for (int32 k = 0; k < TempResourceList.Num(); k++)
							{
								UE_LOG(LogTemp, Warning, TEXT("\t%s"), *TempResourceList[k]);
							}
						}
					}
				}
			}
		}
	}

	// 2、检查Buff的Resource
	IDList = EAMgr->GetBuffIDList();
	IDList.Sort();
	for (int32 a = 0; a < IDList.Num(); a++)
	{
		if (UBSABuffAsset* BuffAsset = EAMgr->GetBuffAssetByID(IDList[a]))
		{
			for (int32 i = 0; i < BuffAsset->Sections.Num(); ++i)
			{
				for (int32 j = 0; j < BuffAsset->Sections[i].TaskList.Num(); ++j)
				{
					if (BuffAsset->Sections[i].TaskList[j])
					{
						ResourceList.Empty();
						BuffAsset->Sections[i].TaskList[j]->GetReferenceResources(ResourceList);
						TempResourceList = UBSEditorFunctionLibrary::CheckResouces(ResourceList);
						if (TempResourceList.Num() > 0)
						{
							UE_LOG(LogTemp, Warning, TEXT("BuffID: %i, TaskName: %s, FindInValid Resource:"), IDList[a], *(BuffAsset->Sections[i].TaskList[j]->GetName()));
							for (int32 k = 0; k < TempResourceList.Num(); k++)
							{
								UE_LOG(LogTemp, Warning, TEXT("\t%s"), *TempResourceList[k]);
							}
						}
					}
				}
			}
		}
	}

	UE_LOG(LogTemp, Warning, TEXT("================================================================="));
	UE_LOG(LogTemp, Warning, TEXT("====================== Check Resources End ======================"));
	UE_LOG(LogTemp, Warning, TEXT("================================================================="));
}

void UBSEditorFunctionLibrary::AutoFixSkillBuffResouces()
{
	UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance();
	if (!EAMgr)
	{
		return;
	}

	TArray<FString> ResourceList;
	TArray<FString> TempResourceList;
	TArray<int32> IDList;

	UE_LOG(LogTemp, Warning, TEXT("================================================================="));
	UE_LOG(LogTemp, Warning, TEXT("=================== AutoFix Resources Started ==================="));
	UE_LOG(LogTemp, Warning, TEXT("================================================================="));

	// 1、检查技能的Resource
	IDList = EAMgr->GetSkillIDList();
	IDList.Sort();
	for (int32 a = 0; a < IDList.Num(); a++)
	{
		if (UBSASkillAsset* SkillAsset = EAMgr->GetSkillAssetByID(IDList[a]))
		{
			for (int32 i = 0; i < SkillAsset->Sections.Num(); ++i)
			{
				for (int32 j = 0; j < SkillAsset->Sections[i].TaskList.Num(); ++j)
				{
					if (SkillAsset->Sections[i].TaskList[j])
					{
						FString Log = TEXT("Skill:") + FString::FromInt(IDList[a]) + TEXT(".") + SkillAsset->Sections[i].TaskList[j]->GetName();
						if (UBSEditorFunctionLibrary::AutoFixResource(SkillAsset->Sections[i].TaskList[j], Log))
						{
							TSoftObjectPtr<UBSASkillAsset> SkillAssetSOPtr = EAMgr->GetSkillAssetSoftObjectByID(IDList[a]);
							FString FileString = SkillAssetSOPtr.ToString();
							// 资源路径转换为绝对路径
							FileString.Split(TEXT("."), &FileString, nullptr);
							FileString.Split(TEXT("/Game/"), nullptr, &FileString);
							FileString = FPaths::ProjectContentDir() + FileString;
							FileString = FPaths::ConvertRelativePathToFull(FileString + TEXT(".uasset"));
							UBSEditorFunctionLibrary::CheckOutByPerforce(*FileString);
						}
					}
				}
			}
		}
	}

	// 2、检查Buff的Resource
	IDList = EAMgr->GetBuffIDList();
	IDList.Sort();
	for (int32 a = 0; a < IDList.Num(); a++)
	{
		if (UBSABuffAsset* BuffAsset = EAMgr->GetBuffAssetByID(IDList[a]))
		{
			for (int32 i = 0; i < BuffAsset->Sections.Num(); ++i)
			{
				for (int32 j = 0; j < BuffAsset->Sections[i].TaskList.Num(); ++j)
				{
					if (BuffAsset->Sections[i].TaskList[j])
					{
						FString Log = TEXT("Buff:") + FString::FromInt(IDList[a]) + TEXT(".") + BuffAsset->Sections[i].TaskList[j]->GetName();
						if (UBSEditorFunctionLibrary::AutoFixResource(BuffAsset->Sections[i].TaskList[j], Log))
						{
							TSoftObjectPtr<UBSABuffAsset> BuffAssetSOPtr = EAMgr->GetBuffAssetSoftObjectByID(IDList[a]);
							FString FileString = BuffAssetSOPtr.ToString();
							// 资源路径转换为绝对路径
							FileString.Split(TEXT("."), &FileString, nullptr);
							FileString.Split(TEXT("/Game/"), nullptr, &FileString);
							FileString = FPaths::ProjectContentDir() + FileString;
							FileString = FPaths::ConvertRelativePathToFull(FileString + TEXT(".uasset"));
							UBSEditorFunctionLibrary::CheckOutByPerforce(*FileString);
						}
					}
				}
			}
		}
	}

	UE_LOG(LogTemp, Warning, TEXT("================================================================="));
	UE_LOG(LogTemp, Warning, TEXT("====================== AutoFix Resources End ======================"));
	UE_LOG(LogTemp, Warning, TEXT("================================================================="));

	FText DialogText = LOCTEXT("AutoFix Resources End", "引用缺失同名资产自动替换已完成，请手动逐个检查Checkout的文件，确认无误后【保存】再【提交】");
	FMessageDialog::Open(EAppMsgType::Ok, DialogText);
}

bool UBSEditorFunctionLibrary::AutoFixResource(UObject* ObjectToCheck, FString Log)
{
	bool bNeedCheckout = false;
	UClass* ObjectClass = ObjectToCheck->GetClass();

	for (TFieldIterator<FProperty> PropIt(ObjectClass); PropIt; ++PropIt)
	{
		// 跳过编辑器数据
		if ((*PropIt)->IsEditorOnlyProperty())
		{
			continue;
		}

		// 跳过纯UObject的数据
		UClass* CurrentClass = PropIt->GetOwnerClass();
		if (CurrentClass == UObject::StaticClass())
		{
			continue;
		}
		else
		{
			void* CurAddress = (*PropIt)->ContainerPtrToValuePtr<void>(ObjectToCheck);
			if (FObjectProperty* CurObjProp = CastField<FObjectProperty>((*PropIt)))
			{
				UObject* CurObject = CurObjProp->GetObjectPropertyValue(CurAddress);
				if (CurObject && CurObject->IsValidLowLevel())
				{
					if (UBSEditorFunctionLibrary::AutoFixResource(CurObject, Log + TEXT(".") + CurObject->GetName()))
					{
						bNeedCheckout = true;
					}
				}
			}
			else if (FSoftObjectProperty* SoftObjectProp = CastField<FSoftObjectProperty>((*PropIt)))
			{
				FSoftObjectPtr* ValuePtr = (FSoftObjectPtr*)CurAddress;
				if (!ValuePtr->IsNull())
				{
					FString Path = ValuePtr->ToString();

					// 资源路径转换为绝对路径
					FString t, FileName;
					Path.Split(TEXT("."), &t, &FileName);
					t.Split(TEXT("/Game/"), nullptr, &t);
					t = FPaths::ProjectContentDir() + t;
					t = FPaths::ConvertRelativePathToFull(t + TEXT(".uasset"));
					if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*t))
					{
						TArray<FString> FindFiles;
						IFileManager::Get().FindFilesRecursive(FindFiles, *FPaths::ProjectContentDir(), *(FileName + TEXT(".uasset")), true, false, false);
						for (int32 i = 0; i < FindFiles.Num(); i++)
						{
							// 绝对路径转换回资源路径
							t = FPaths::ConvertRelativePathToFull(FindFiles[i]);
							t = t.Replace(*FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir()), TEXT("/Game/"));
							t = t.Replace(TEXT(".uasset"), TEXT(""));
							t = t + TEXT(".") + FileName;
							if (UObject* ReloadObject = LoadObject<UObject>(nullptr, *t))
							{
								SoftObjectProp->SetObjectPropertyValue(CurAddress, ReloadObject);
								ObjectToCheck->MarkPackageDirty();
								UE_LOG(LogTemp, Warning, TEXT("%s.%s AutoFixed!"), *Log, *FileName);
								bNeedCheckout = true;
							}
						}
					}
				}
			}
		}
	}

	return bNeedCheckout;
}

TArray<FString> UBSEditorFunctionLibrary::CheckResouces(TArray<FString> InResourceList)
{
	static TArray<FString> OutInvalidResList;
	OutInvalidResList.Empty();

	for (int32 i = 0; i < InResourceList.Num(); i++)
	{
		if (InResourceList[i].IsEmpty())
		{
			continue;
		}
		
		FString t;
		InResourceList[i].Split(TEXT("."), &t, nullptr);
		t.Split(TEXT("/Game/"), nullptr, &t);
		t = FPaths::ProjectContentDir() + t;
		t = FPaths::ConvertRelativePathToFull(t + TEXT(".uasset"));
		if (!FPlatformFileManager::Get().GetPlatformFile().FileExists(*t))
		{
			OutInvalidResList.AddUnique(InResourceList[i]);
		}
	}

	return OutInvalidResList;
}

void UBSEditorFunctionLibrary::AutoGenSkillRecoveryStartTime(TArray<int32> SkillIDs)
{
	UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance();
	if (!EAMgr)
	{
		return;
	}

	for (int32 a = 0; a < SkillIDs.Num(); a++)
	{
		if (UBSASkillAsset* SkillAsset = EAMgr->GetSkillAssetByID(SkillIDs[a]))
		{
			UBSEditorFunctionLibrary::AutoGenSkillRecoveryStartTime(SkillAsset);
		}
	}
}

void UBSEditorFunctionLibrary::AutoGenSkillRecoveryStartTime(UBSASkillAsset* SkillAsset)
{
	if (SkillAsset->SkillRecoveryStartTime > 0.0f)
	{
		// 已经存在大于0的非默认技能后摇时间，说明已经更新过了就不用再更新了
		return;
	}

	float RealSkillRecoveryStartTime = 0.0f;

	for (int32 i = 0; i < SkillAsset->Sections.Num(); ++i)
	{
		for (int32 j = 0; j < SkillAsset->Sections[i].TaskList.Num(); ++j)
		{
			if (UBSATDisableBehavior* DBTask = Cast<UBSATDisableBehavior>(SkillAsset->Sections[i].TaskList[j]))
			{
				if (DBTask->GetLifeType() == EBSATaskLife::TL_ByController)
				{
					// 如果是由上层控制，则为技能时长
					RealSkillRecoveryStartTime = SkillAsset->SkillDuration;
				}
				else if (DBTask->GetLifeType() == EBSATaskLife::TL_ForceDuration || DBTask->GetLifeType() == EBSATaskLife::TL_DurAndController)
				{
					// 如果是固定时间，或固定时间且由上层控制，则计算最长时间，不超过技能时长
					RealSkillRecoveryStartTime = FMath::Min(SkillAsset->SkillDuration, FMath::Max(RealSkillRecoveryStartTime, DBTask->GetStartTime() + DBTask->GetDuration()));
				}
			}

			if (RealSkillRecoveryStartTime >= SkillAsset->SkillDuration)
			{
				break;
			}
		}

		if (RealSkillRecoveryStartTime >= SkillAsset->SkillDuration)
		{
			break;
		}
	}

	if (SkillAsset->SkillRecoveryStartTime != RealSkillRecoveryStartTime)
	{
		SkillAsset->SkillRecoveryStartTime = RealSkillRecoveryStartTime;
		SkillAsset->MarkPackageDirty();
	}
}
#pragma endregion CheckResource



#undef LOCTEXT_NAMESPACE