#include "BattleSystemEditor/BSCommandlet/BSExportCommandlet.h"
#include "SceneTypes.h"

#include "SceneTypes.h"
#include "EditorLevelUtils.h"
#include "Engine/LevelStreamingDynamic.h"
#include "GameFramework/WorldSettings.h"

#include "LevelLuaEditorProxyBase.h"

#include "BattleSystemEditor/BSEditorLuaBasicGI.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorSettings.h"
#include "BattleSystemEditor/BSEditorFunctionLibrary.h"
#include "BattleSystemEditor/AbilityEditor/BSAEditorAssetManager.h"
#include "BattleSystemEditor/DecisionTreeEditor/DecisionTreeAssetManager.h"
#include "BattleSystemEditor/AbilityEditor/Preview/BSAPreviewGameMode.h"

#if WITH_EDITOR
#include "Editor.h"
#endif



DEFINE_LOG_CATEGORY_STATIC(BSExportCommandlet, Log, All);






UBSExportCommandlet::UBSExportCommandlet()
{
	LogToConsole = true;
}

int32 UBSExportCommandlet::Main(const FString& Params)
{
	UE_LOG(BSExportCommandlet, Display, TEXT("Hello BSExportCommandlet!"));

	ParseParam(Params);

	Init();

	if (bExportEnum)
	{
		ExportEnum();
	}

	if (bExportBattleData)
	{
		ExportBattleData();
	}

	UnInit();

	return 0;
}

void UBSExportCommandlet::ParseParam(const FString& Params)
{
	TArray<FString> Tokens;
	TArray<FString> Switches;
	ParseCommandLine(*Params, Tokens, Switches);

	for (FString SingleSwitch : Switches)
	{
		bool tValue = false;
		if (FParse::Bool(*SingleSwitch, TEXT("ExportEnum="), tValue) && tValue)
		{
			bExportEnum = true;
			continue;
		}

		if (FParse::Bool(*SingleSwitch, TEXT("ExportBattleData="), tValue) && tValue)
		{
			bExportBattleData = true;
			continue;
		}
	}
}



void UBSExportCommandlet::Init()
{
	UE_LOG(BSExportCommandlet, Display, TEXT("BSExportCommandlet Init!"));

	if (!bExportBattleData && !bExportEnum)
	{
		return;
	}

	// 启动AssetRegistry
	const FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName);
	AssetRegistryModule.Get().SearchAllAssets(true);

	// 创建Lua环境
    LuaEnv = UEditorLuaEnv::CreateLuaEnv(GEditor->GetEditorWorldContext().World(), UBSEditorLuaBasicGI::StaticClass());
	if (UBSAEditorAssetManager* Mgr = NewObject<UBSAEditorAssetManager>())
	{
		Mgr->Init();
	}

	if (UDecisionTreeAssetManager* DecisionTreeMgr = NewObject<UDecisionTreeAssetManager>())
	{
		DecisionTreeMgr->Init();
	}

	if (bExportBattleData)
	{
		// 允许GS执行Lua脚本
		GAllowActorScriptExecutionInEditor = true;
	}
}

void UBSExportCommandlet::UnInit()
{
	if (UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance())
	{
		EAMgr->UnInit();
	}

	if (UDecisionTreeAssetManager* DTMgr = UDecisionTreeAssetManager::GetInstance())
	{
		DTMgr->UnInit();
	}

	// 关闭Lua环境
    UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
    LuaEnv = nullptr;
}



void UBSExportCommandlet::ExportEnum()
{
	//UBSEditorFunctionLibrary::ExportEnum(true);
}

void UBSExportCommandlet::ExportBattleData()
{
	if (UBSAEditorAssetManager* EAMgr = UBSAEditorAssetManager::GetInstance())
	{
		EAMgr->UsedGuidList.Empty();
		EAMgr->UsedGuidNameList.Empty();
	}
	
	UBSEditorLuaBasicGI *GI = Cast<UBSEditorLuaBasicGI>(LuaEnv->GetLuaGameInstance());

	//UBSEditorFunctionLibrary::ExportCurveData(GI);
	//UBSEditorFunctionLibrary::ExportSkillData(GI);
	//UBSEditorFunctionLibrary::ExportBuffData(GI);
	//UBSEditorFunctionLibrary::ExportCombatTreeData();
	UBSEditorFunctionLibrary::ExportAutoSkillTreeData();
	//UBSEditorFunctionLibrary::ExportBeatenTreeData();
	//UBSEditorFunctionLibrary::ExportPassiveSkillData();
	//UBSEditorFunctionLibrary::UpdatePropTagList(GI, true);



#pragma region Trash
	/*FProcHandle ExportHandle = FPlatformProcess::CreateProc(TEXT("../../../Tools/AbilityExcelExporter/AbilityExcelProcessor.exe"), TEXT("../../../"), true, false, false, nullptr, 0, nullptr, nullptr);
	if (FPlatformProcess::IsProcRunning(ExportHandle))
	{
		FPlatformProcess::WaitForProc(ExportHandle);
	}
	FPlatformProcess::CloseProc(ExportHandle);*/
#pragma endregion Trash

}