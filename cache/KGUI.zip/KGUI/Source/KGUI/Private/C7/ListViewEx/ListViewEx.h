#pragma once
#include "CoreMinimal.h"
#include "Components/Widget.h"
#include "Components/CanvasPanel.h"
#include "Components/ListView.h"
#include "SListViewEx.h"
#include "ListViewEx.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnListEntryInitializedExtDynamic, UObject*, Item, UWidget*, Widget);
/**
 *
 */
UCLASS()
class KGUI_API UListViewEx : public UListView
{
	GENERATED_UCLASS_BODY()

	IMPLEMENT_TYPED_UMG_LIST(UObject*, MyListView)
public:
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	template <typename RowWidgetT = UWidget>
	RowWidgetT* GetEntryWidgetFromItem(const UObject* Item) const
	{
		RowWidgetT* Widget = Item ? ITypedUMGListView<UObject*>::GetEntryWidgetFromItem<RowWidgetT>(const_cast<UObject*>(Item)) : nullptr;
		if (Widget != nullptr)
		{
			if (Widget->template IsA<UUserWidget>())
			{
				if(UUserWidget* UserWidget = Cast<UUserWidget>(Widget))
				{
					UWidget* root = UserWidget->GetRootWidget();
					if(root)
					{
						if(UCanvasPanel* panel = Cast<UCanvasPanel>(root))
						{
							return panel->GetChildAt(0);
						}
					}
				}
				
			}
		}
		return nullptr;
	}

	void HandleOnEntryInitializedInternal(UObject* Item, const TSharedRef<ITableRow>& TableRow);

#if WITH_EDITOR
	// UWidget interface
	virtual const FText GetPaletteCategory() override;
	virtual bool CanEditChange(const FProperty* InProperty) const override;
	// End UWidget interface
	virtual void OnCreationFromPalette() override;
#endif

	virtual UUserWidget& OnGenerateEntryWidgetInternal(UObject* Item, TSubclassOf<UUserWidget> DesiredEntryClass, const TSharedRef<STableViewBase>& OwnerTable) override;

	/** SListView construction helper - useful if using a custom STreeView subclass */
	template <template<typename> class ListViewT = SListViewEx>
	TSharedRef<ListViewT<UObject*>> ConstructListView()
	{
		FListViewConstructArgs Args;
		Args.bAllowFocus = bIsFocusable;
		Args.SelectionMode = SelectionMode;
		Args.bClearSelectionOnClick = bClearSelectionOnClick;
		Args.ConsumeMouseWheel = ConsumeMouseWheel;
		Args.bReturnFocusToSelection = bReturnFocusToSelection;
		Args.Orientation = Orientation;
		Args.ScrollBarStyle = &ScrollBarStyle;
		
		MyListView = ITypedUMGListView<UObject*>::ConstructListView<ListViewT>(this, ListItems, Args);
		MyListView->SetOnEntryInitialized(SListView<UObject*>::FOnEntryInitialized::CreateUObject(this, &UListViewEx::HandleOnEntryInitializedInternal));
		return StaticCastSharedRef<ListViewT<UObject*>>(MyListView.ToSharedRef());
	}
	void SynchronizeProperties();

	UFUNCTION(BlueprintCallable, Category = ListView)
		void SetScrollbarVisibilityEx(bool InVisibility);

	//UFUNCTION(BlueprintCallable, Category = ListView)
	//	float GetScrollOffset();

    UFUNCTION(BlueprintCallable, Category = TileView)
    	void SetCurrentScrollOffsetDefault();
    	
	UFUNCTION(BlueprintCallable, Category = ListView)
		float GetDistancePercent();

	UFUNCTION(BlueprintCallable, Category = ListView)
		float GetDistancePercentRemaining();

	UFUNCTION(BlueprintCallable, Category = ListView)
		virtual void OnListViewScrolledInternal(float ItemOffset, float DistanceRemaining);

	UFUNCTION(BlueprintCallable, Category = ListView)
		void SetAllowOverscroll(bool NewAllowOverscroll);

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Content)
		bool bAllowLoopScroll;

	UFUNCTION(BlueprintCallable, Category = ListView)
		void SetAllowLoopScroll(bool NewAllowLoopScroll);

	UFUNCTION(BlueprintPure, Category = ListView)
	FString GetEntryWidgetClassName();

	UFUNCTION(BlueprintCallable, Category = ListView)
	void SetScrollbarThickness(const FVector2D& NewScrollbarThickness);

	UFUNCTION(BlueprintCallable, Category = ListView)
	void ScrollToOffset(float Offset);

	TSharedPtr<SListViewEx<UObject*>> MyListView;  // cppcheck:ignore 野指针作为模板类型参数

protected:
	UPROPERTY(EditAnywhere, Category = Content, meta = (MultiLine = "true"))
	UWidget* ScrollWidget;
	/**
	 * set it to true while list wants to be automatic expand by children.
	 */
	UPROPERTY(EditAnywhere, Category = Content, meta = (MultiLine = "true"))
	bool KeepChildSize = false;
	int curIndex;
	FVector2D DesiredSize;
	bool isUserWidget;
	void CaculateDesireSize();
	bool inAllowLoopScroll;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Content)
		bool bShowScrollBar = false;

	/** Called when a row widget is generated for a list item */
	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Entry Initialized"))
		FOnListEntryInitializedExtDynamic BP_OnEntryInitializedExt;
	virtual TSharedRef<STableViewBase> RebuildListWidget() override;
};