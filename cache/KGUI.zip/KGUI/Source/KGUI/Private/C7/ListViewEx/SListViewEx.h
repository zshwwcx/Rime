﻿#pragma once
#include "Framework/Layout/Overscroll.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Views/STableViewBase.h"

class STableViewBase;
//增加了是否过度滚动的功能
template <typename ItemType>
class KGUI_API SListViewEx : public SListView <ItemType>
{
public:
	EAllowOverscroll GetAllowOverscroll() const
	{
		return STableViewBase::AllowOverscroll;
	}

	void SetCurrentScrollOffsetDefault()
	{
		STableViewBase::CurrentScrollOffset= 0.;
	}
	void SetAllowOverscroll(EAllowOverscroll NewAllowOverscroll)
	{
		STableViewBase::AllowOverscroll = NewAllowOverscroll;
		if (STableViewBase::AllowOverscroll == EAllowOverscroll::No)
		{
			STableViewBase::Overscroll.ResetOverscroll();
		}
	}

	void SetScrollbarThickness(const FVector2D& NewScrollbarThickness)
	{
		if (STableViewBase::ScrollBar)
		{
			return STableViewBase::ScrollBar->SetThickness(NewScrollbarThickness);
		}
	}

	void ScrollToOffset(float InScrollOffset)
	{
		STableViewBase::ScrollTo(InScrollOffset);
	}
};