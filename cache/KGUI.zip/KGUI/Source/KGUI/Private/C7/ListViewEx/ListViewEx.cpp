#include "ListViewEx.h"

#include "AssetRegistry/AssetData.h"
#include "Components/SlateWrapperTypes.h"
#include "Components/Image.h"
#include "Components/CanvasPanelSlot.h"
#include "Blueprint/UserWidget.h"
#include "UMG/Blueprint/UIFunctionLibrary.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Engine/Blueprint.h"
#include "UObject/ConstructorHelpers.h"

#define LOCTEXT_NAMESPACE "UMG"

/////////////////////////////////////////////////////
// UListViewEx

UListViewEx::UListViewEx(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	curIndex = 0;
	if (EntryWidgetClass == nullptr)
	{
		static ConstructorHelpers::FClassFinder<UUserWidget> bpclass(TEXT("/Game/Arts/UI_2/Blueprint/GM/EmptyEntry.EmptyEntry_C"));
		if (bpclass.Class != NULL)
		{
			EntryWidgetClass = bpclass.Class;
		}
	}
}

void UListViewEx::HandleOnEntryInitializedInternal(UObject* Item, const TSharedRef<ITableRow>& TableRow)
{
	BP_OnEntryInitializedExt.Broadcast(Item, GetEntryWidgetFromItem(Item));
}

#if WITH_EDITOR

const FText UListViewEx::GetPaletteCategory()
{
	return LOCTEXT("Custom", "Custom");
}

bool UListViewEx::CanEditChange(const FProperty* InProperty) const
{
	if (!Super::CanEditChange(InProperty))
	{
		return false;
	}
	if (InProperty && InProperty->GetFName() == "EntryWidgetClass")
	{
		return false;
	}
	return true;
}

void UListViewEx::OnCreationFromPalette()
{
	IAssetRegistry& AssetRegistry = FAssetRegistryModule::GetRegistry();
	FAssetData AssetData = AssetRegistry.GetAssetByObjectPath(FSoftObjectPath(TEXT("/Game/Arts/UI_2/Blueprint/GM/EmptyEntry.EmptyEntry_C")));
	if (AssetData.IsValid())
	{
		if (UObject* Object = AssetData.FastGetAsset(true))
		{
			if (UBlueprint* Blueprint = Cast<UBlueprint>(Object))
			{
				EntryWidgetClass = Blueprint->GeneratedClass;
			}
		}
	}
}

#endif

UUserWidget& UListViewEx::OnGenerateEntryWidgetInternal(UObject* Item, TSubclassOf<UUserWidget> DesiredEntryClass, const TSharedRef<STableViewBase>& OwnerTable)
{
	UUserWidget& widget = Super::GenerateTypedEntry(DesiredEntryClass, OwnerTable);
	UWidget* root = widget.GetRootWidget();
	if(root == nullptr)
	{
		return widget;
	}
	UCanvasPanel* panel = Cast<UCanvasPanel>(root);
	if (panel != nullptr && ScrollWidget != nullptr)
	{
		if (panel->GetChildrenCount() > 0)
		{
			return widget;
		}
		UWidget* newWidget;
		if (curIndex == 0)
		{
			CaculateDesireSize();
		}
		UClass* wclass = ScrollWidget->GetClass();
		if (isUserWidget)
		{
			newWidget = widget.CreateWidgetInstance(widget, ScrollWidget->GetClass(), NAME_None);
		}
		else
		{
			newWidget = UUIFunctionLibrary::DeepDuplicateWidget(ScrollWidget, panel);
		}
		panel->AddChildToCanvas(newWidget);
		newWidget->SetVisibility(ESlateVisibility::Visible);
		UCanvasPanelSlot* slot = Cast<UCanvasPanelSlot>(newWidget->Slot);
		if (slot != nullptr)
		{
			if (KeepChildSize)
			{
				slot->SetSize(DesiredSize);
			}
			else
			{
				if (Orientation == EOrientation::Orient_Vertical)
				{
					FAnchors NewAnchor(0, 0, 1, 0);
					slot->SetAnchors(NewAnchor);
					slot->SetSize(FVector2d(0, DesiredSize.Y));
				}
				else if (Orientation == EOrientation::Orient_Horizontal)
				{
					FAnchors NewAnchor(0, 0, 0, 1);
					slot->SetAnchors(NewAnchor);
					slot->SetSize(FVector2d(DesiredSize.X, 0));
				}
			}
		}
		curIndex++;
	}
	return widget;
}

void UListViewEx::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	if (MyListView.IsValid())
	{
		MyListView->SetAllowOverscroll(AllowOverscroll ? EAllowOverscroll::Yes : EAllowOverscroll::No);
	}
	SetScrollbarVisibilityEx(bShowScrollBar);
	SetAllowLoopScroll(bAllowLoopScroll);
	SetScrollbarThickness(FVector2D(ScrollBarStyle.Thickness, ScrollBarStyle.Thickness));

	if (ScrollWidget != nullptr)
	{
#if WITH_EDITOR
		if ( ScrollWidget->IsDesignTime())
		{
			//ScrollWidget->SetVisibility(ESlateVisibility::Visible);
		}
		else
		{
			ScrollWidget->SetVisibility(ESlateVisibility::Hidden);
		}
#else
		ScrollWidget->SetVisibility(ESlateVisibility::Hidden);
#endif
	}
}

void UListViewEx::CaculateDesireSize()
{
	if(ScrollWidget == nullptr)
	{
		return;
	}
	UClass* wclass = ScrollWidget->GetClass();
	if (wclass->IsChildOf(UUserWidget::StaticClass()))
	{
		isUserWidget = true;
		UCanvasPanelSlot* itemSlot = Cast<UCanvasPanelSlot>(ScrollWidget->Slot);
		if(itemSlot)
		{
			if (itemSlot->GetAutoSize())
			{
				TSharedRef<SWidget> swidget = ScrollWidget->TakeWidget();
				DesiredSize = swidget->GetDesiredSize();
			}
			else
			{
				DesiredSize = itemSlot->GetSize();
			}
		}
		else
		{
			TSharedRef<SWidget> swidget = ScrollWidget->TakeWidget();
			DesiredSize = swidget->GetDesiredSize();
		}
	}
	else
	{
		UCanvasPanelSlot* itemSlot = Cast<UCanvasPanelSlot>(ScrollWidget->Slot);
		if(itemSlot)
		{
			DesiredSize = itemSlot->GetSize();
		}
		else
		{
			TSharedRef<SWidget> swidget = ScrollWidget->TakeWidget();
			DesiredSize = swidget->GetDesiredSize();
		}
		isUserWidget = false;
	}
}

TSharedRef<STableViewBase> UListViewEx::RebuildListWidget()
{
	return ConstructListView<SListViewEx>();
}

void UListViewEx::SetScrollbarVisibilityEx(bool InVisibility)
{
	
	if (InVisibility)
	{
		Super::SetScrollbarVisibility(ESlateVisibility::Visible);
		bShowScrollBar = true;
	}
	else
	{
		Super::SetScrollbarVisibility(ESlateVisibility::Hidden);
		bShowScrollBar = false;
	}
}
// float UListViewEx::GetScrollOffset()
// {
// 	if (MyListView.IsValid())
// 	{
// 		return MyListView->GetScrollOffset();
// 	}
// 	return 0.f;
// }

void UListViewEx::SetCurrentScrollOffsetDefault()
{
	if (MyListView.IsValid())
	{
		MyListView->SetCurrentScrollOffsetDefault();
	}
}

float UListViewEx::GetDistancePercent()
{
	if (MyListView.IsValid())
	{
		auto scrollDistance = MyListView->GetScrollDistance();
		return scrollDistance.Y - scrollDistance.X;
	}
	return 0.f;
}

float UListViewEx::GetDistancePercentRemaining()
{
	if (MyListView.IsValid())
	{
		auto scrollDistance = MyListView->GetScrollDistanceRemaining();
		return scrollDistance.Y - scrollDistance.X;
	}
	return 0.f;
}

void UListViewEx::OnListViewScrolledInternal(float ItemOffset, float DistanceRemaining)
{
	if (inAllowLoopScroll && (IsItemVisible(GetItemAt(GetNumItems() - 1))^ IsItemVisible(GetItemAt(0))))
	{
		//只多生成一次滚动列表来进行循环，并在铺不满的情况下不多生成不进行循环
		auto list = GetListItems();
		for (auto& item:list)
		{
			AddItem(item);
		}
		inAllowLoopScroll = false;
	}
	if (bAllowLoopScroll)
	{
		if (IsItemVisible(GetItemAt(0)) && !IsItemVisible(GetItemAt(GetNumItems() - 1)) && GetDistancePercent() < (1.0 / GetNumItems()))
		{
			//滑动到首个元素时，拖动到中间,元素会有重复，用<1/nums去除。
			auto list = GetListItems();
			auto offset = GetScrollOffset();
			if (offset < GetNumItems() / 2.0)
			{
				SetScrollOffset(GetScrollOffset() + GetNumItems() / 2.0);
			}
		}
		if (IsItemVisible(GetItemAt(GetNumItems() - 1)) && !IsItemVisible(GetItemAt(0)) && GetDistancePercentRemaining() < (1.0 / GetNumItems()))
		{
			//滑动到末位元素时，拖动到中间。
			auto list = GetListItems();
			auto offset = GetScrollOffset();
			if (offset > GetNumItems() / 2.0)
			{
				SetScrollOffset(GetScrollOffset() - GetNumItems() / 2.0);
			}
		}
	}
}

void UListViewEx::SetAllowOverscroll(bool NewAllowOverscroll)
{
	AllowOverscroll = NewAllowOverscroll;

	if (MyListView.IsValid())
	{
		MyListView->SetAllowOverscroll(AllowOverscroll ? EAllowOverscroll::Yes : EAllowOverscroll::No);
	}
}

void UListViewEx::SetAllowLoopScroll(bool NewAllowLoopScroll)
{
	bAllowLoopScroll = NewAllowLoopScroll;
	inAllowLoopScroll = NewAllowLoopScroll;
	if (GetScrollOffset() == 0.f)//保证向上滚动时能够滚动
	{
		//SetScrollOffset(FLT_MIN);滚轮不可感知，鼠标可感知
		SetScrollOffset(0.0001);//滚动可感知的极小值
	}
}

FString UListViewEx::GetEntryWidgetClassName()
{
	if (ScrollWidget)
	{
		return ScrollWidget->GetName();
//		下方的写法用意何在
// 		UClass* Class = ScrollWidget->GetClass();
// 		if (Class->IsChildOf(UUserWidget::StaticClass()))
// 		{
// 			if (Class->ClassGeneratedBy)
// 			{
// 				return Class->ClassGeneratedBy->GetName();
// 			}
// 			else
// 			{
// 				return Class->GetName();
// 			}
// 		}
	}
	return FString();
}

void UListViewEx::SetScrollbarThickness(const FVector2D& NewScrollbarThickness)
{
	if (MyListView.IsValid())
	{
		MyListView->SetScrollbarThickness(NewScrollbarThickness);
	}
#if WITH_EDITOR
	if (IsDesignTime())
	{
		RebuildWidget();
	}
#endif
}

void UListViewEx::ScrollToOffset(float Offset)
{
	if (MyListView.IsValid())
	{
		MyListView->ScrollToOffset(Offset);
	}
}

void UListViewEx::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	if (MyListView.IsValid())
	{
		MyListView.Reset();
	}
}
#undef LOCTEXT_NAMESPACE
