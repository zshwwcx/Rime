#include "C7/PaintingScratchImage.h"
#include "Log.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Engine/Canvas.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Misc/ObjCrashCollector.h"

void UPaintingScratchImage::Tick(float DeltaTime)
{
	if (!IsVisible() || RenderTargetScale.IsNearlyZero() || WidgetSize.IsNearlyZero() || !DrawMaterial.IsValid() || !DrawRenderTarget.IsValid())
	{
		return;
	}
	FVector2D CurMousePosition = UWidgetLayoutLibrary::GetMousePositionOnViewport(this);
	FVector2D ViewportSize = UWidgetLayoutLibrary::GetViewportSize(this->GetWorld());
	FVector2D CurDrawPosition = CurMousePosition - LeftTop;
	FVector2D DeltaPosition = CurDrawPosition - LastDrawPosition;

	FLinearColor InputPosition(
		CurDrawPosition.X / WidgetSize.X,
		CurDrawPosition.Y / WidgetSize.Y,
		bMouseButtonDown ? DeltaPosition.X : 0.0f,
		bMouseButtonDown ? DeltaPosition.Y : 0.0f
	);
	DrawMaterial->SetVectorParameterValue(FName("InputPosition"), InputPosition);
	UKismetRenderingLibrary::DrawMaterialToRenderTarget(this, DrawRenderTarget.Get(), DrawMaterial.Get());

	if (AdvertMaterial.IsValid() && AdvertRenderTarget.IsValid() && SimMaterial.IsValid() && SimRenderTarget.IsValid())
	{
		InputPosition.R = CurMousePosition.X / ViewportSize.X;
		InputPosition.G = CurMousePosition.Y / ViewportSize.Y;

		AdvertMaterial->SetVectorParameterValue(FName("InputPosition"), InputPosition);
		UKismetRenderingLibrary::DrawMaterialToRenderTarget(this, AdvertRenderTarget.Get(), AdvertMaterial.Get());
		SimMaterial->SetVectorParameterValue(FName("InputPosition"), InputPosition);
		UKismetRenderingLibrary::DrawMaterialToRenderTarget(this, SimRenderTarget.Get(), SimMaterial.Get());
	}
	
	LastDrawPosition = CurDrawPosition;

	if (!bMouseButtonDown || bReachPercent) return;
	
	const FVector2D HalfThickness = FVector2D(Thickness, Thickness);
	const FVector2D LocalMouse = CurMousePosition - LeftTop;
	const FVector2D LeftTopDraw = LocalMouse - HalfThickness;
	const FVector2D RightBottomDraw = LocalMouse + HalfThickness;

	int32 IndexXL = FMath::Max(LeftTopDraw.X / WidgetSize.X * SizeWidth, 0);
	int32 IndexXR = FMath::Min(RightBottomDraw.X / WidgetSize.X * SizeWidth, SizeWidth - 1);
	int32 IndexYL = FMath::Max(LeftTopDraw.Y / WidgetSize.Y * SizeHeight, 0);
	int32 IndexYR = FMath::Min(RightBottomDraw.Y / WidgetSize.Y * SizeHeight, SizeHeight - 1);
	for (int32 i = IndexXL; i <= IndexXR; i++)
	{
		for (int32 j = IndexYL; j <= IndexYR; j++)
		{
			if (PaintingCells[i][j] == 0)
			{
				PaintingCells[i][j] = 1;
				PaintingCellNum ++;
			}
		}
	}
	UE_LOG(LogTemp, Log, TEXT("[UPaintingScratchImage] Cur PaintingNum: %d, CellNum:%d, %d, InputPosition R:%.1f, G:%.1f, B:%.1f, A:%.1f"), PaintingCellNum, SizeWidth, SizeHeight, InputPosition.R, InputPosition.G, InputPosition.B, InputPosition.A);
	
	const int32 TotalRequiredCells = PaintingTotalPercent * SizeWidth * SizeHeight;
	if (PaintingCellNum >= TotalRequiredCells && OnPaintingScratchReachPercentEvent.IsBound())
	{
		bReachPercent = true;
		OnPaintingScratchReachPercentEvent.Execute();
	}
}

void UPaintingScratchImage::InitParameters(
	FVector2D InLeftTop,
	int32 InThickness,
	float InPaintingPercent,
	UTextureRenderTarget2D* InDrawRenderTarget,
	UMaterialInstanceDynamic* InDrawMaterial,
	UTextureRenderTarget2D* InAdvertRenderTarget,
	UMaterialInstanceDynamic* InAdvertMaterial,
	UTextureRenderTarget2D* InSimRenderTarget,
	UMaterialInstanceDynamic* InSimMaterial)
{
	c7_obj_check(InDrawRenderTarget);

	if (!IsValid(InDrawRenderTarget) || !IsValid(InDrawMaterial))
	{
		UE_LOG(LogTemp, Error, TEXT("Init failed: DrawRenderTarget is invalid"));
		return;
	}
	DrawRenderTarget = TWeakObjectPtr<UTextureRenderTarget2D>(InDrawRenderTarget);
	DrawMaterial = TWeakObjectPtr<UMaterialInstanceDynamic>(InDrawMaterial);
	AdvertRenderTarget = TWeakObjectPtr<UTextureRenderTarget2D>(InAdvertRenderTarget);
	AdvertMaterial = TWeakObjectPtr<UMaterialInstanceDynamic>(InAdvertMaterial);
	SimRenderTarget = TWeakObjectPtr<UTextureRenderTarget2D>(InSimRenderTarget);
	SimMaterial = TWeakObjectPtr<UMaterialInstanceDynamic>(InSimMaterial);

	LeftTop = InLeftTop;
	Thickness = FMath::Max(InThickness, 1);
	PaintingTotalPercent = InPaintingPercent;

	WidgetSize = GetCachedGeometry().GetLocalSize();
	SizeWidth = FMath::FloorToInt(WidgetSize.X / Thickness);
	SizeHeight = FMath::FloorToInt(WidgetSize.Y / Thickness);

	PaintingCells.Reset();
	PaintingCells.Reserve(SizeWidth);
	for (int32 i = 0; i < SizeWidth; ++i)
	{
		TArray<int32>& PaintingCell = PaintingCells.AddDefaulted_GetRef();
		PaintingCell.AddZeroed(SizeHeight);
	}

	PaintingCellNum = 0;
	bReachPercent = false;

	RenderTargetScale = WidgetSize.IsNearlyZero() ? FVector2D::ZeroVector
		: FVector2D(DrawRenderTarget->SizeX / WidgetSize.X, DrawRenderTarget->SizeY / WidgetSize.Y);
}

void UPaintingScratchImage::SetMouseButtonDown(bool bInMouseButtonDown)
{
	bMouseButtonDown = bInMouseButtonDown;
}

ETickableTickType UPaintingScratchImage::GetTickableTickType() const
{
	return HasAnyFlags(RF_ClassDefaultObject) ? ETickableTickType::Never : ETickableTickType::Always;
}

TStatId UPaintingScratchImage::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(UPaintingScratchImage, STATGROUP_Tickables);
}
