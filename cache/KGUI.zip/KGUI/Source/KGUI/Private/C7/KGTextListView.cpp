#include "C7/KGTextListView.h"

#include "UMG/Blueprint/KGUserWidget.h"

UKGRichTextBlock* IKGTextListEntry::GetRichTextBlock(UUserWidget* UserWidget)
{
	if (UserWidget == nullptr)
	{
		return nullptr;
	}
	if (auto NativeImplementation = Cast<IKGTextListEntry>(UserWidget))
	{
		return NativeImplementation->GetRichTextBlock();
	}
	else if (UserWidget->Implements<UKGTextListEntry>())
	{
		return Execute_GetRichTextBlock(UserWidget);
	}
	return nullptr;
}

#if WITH_EDITOR
void UKGTextListView::OnRefreshDesignerItems()
{
	Items.Empty();
	static FText PlaceholderPreviewText = FText::FromString(TEXT("Preview Text {0}"));
	auto& PreviewText = DesignerPreviewText;
	if (PreviewText.IsEmptyOrWhitespace())
	{
		PreviewText = PlaceholderPreviewText;
	}
	for (int Index = 0; Index < this->GetNumDesignerPreviewEntries(); Index++)
	{
		Items.Add({ Index, FText::Format(PreviewText, { Index }) });
	}
	Super::OnRefreshDesignerItems();
}
#endif

TSharedRef<STableViewBase> UKGTextListView::RebuildListWidget()
{
	auto ListView = ConstructListView<SKGTextListView>();
	ListView->SetContentPadding(GetContentPadding());

	auto ValidateEntryClass = [](UClass* EntryClass) -> bool {
		auto BPGC = Cast<UWidgetBlueprintGeneratedClass>(EntryClass);
		if (!BPGC)
		{
			return false;
		}
		auto CDO = BPGC->GetDefaultObject<UUserWidget>();
		if (!CDO)
		{
			return false;
		}
		if (Cast<IKGTextListEntry>(CDO) != nullptr || CDO->Implements<UKGTextListEntry>())
		{
			return true;
		}
		else
		{
			UE_LOG(LogKGUI, Error, TEXT("TextListView 's entry class '%s' must implement interface 'TextListEntry'!"), *EntryClass->GetPathName());
			return false;
		}
	};

	ValidateEntryClass(GetDefaultEntryClass().Get());
	for (const auto& EntryClass : GetMoreEntryWidgetClasses())
	{
		ValidateEntryClass(EntryClass.Get());
	}

	return ListView;
}

TSharedRef<ITableRow> UKGTextListView::HandleGenerateRow(ItemType Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	auto Row = Super::HandleGenerateRow(Item, OwnerTable);
	auto EntryWidget = StaticCastSharedRef<SKGObjectTableRow<ItemType>>(Row->AsWidget())->GetWidgetObject();
	if (auto RichTextBlock = IKGTextListEntry::GetRichTextBlock(EntryWidget))
	{
		auto Index = GetIndexForItem(Item);
		int32 Key = 0;
		if (ensure(Items.IsValidIndex(Index)))
		{
			Key = Items[Index].Key;
		}
		RichTextBlock->OnUrlActivated.AddWeakLambda(
			this,
			[Key, WeakThis = TWeakObjectPtr<UKGTextListView>(this)](const FString& Url, const int32 BeginIndex, const int32 EndIndex, const FVector2D ClickPosition)
			{
				if (auto This = WeakThis.Get())
				{
					This->OnUrlActivated.Broadcast(Key, Url);
				}
			}
		);
	}
	else
	{
		if (EntryWidget)
		{
			UE_LOG(LogKGUI, Error, TEXT("Failed to get rich text block widget from entry widget '%s'!"), *EntryWidget->GetPathName());
		}
	}
	return Row;
}

void UKGTextListView::HandleRowReleased(const TSharedRef<ITableRow>& Row)
{
	auto EntryWidget = StaticCastSharedRef<SKGObjectTableRow<ItemType>>(Row->AsWidget())->GetWidgetObject();
	if (auto RichTextBlock = IKGTextListEntry::GetRichTextBlock(EntryWidget))
	{
		RichTextBlock->OnUrlActivated.RemoveAll(this);
	}
	Super::HandleRowReleased(Row);
}

void UKGTextListView::HandleOnEntryInitializedInternal(ItemType Item, const TSharedRef<ITableRow>& TableRow)
{
	if (auto RichTextBlock = GetRichTextBlockForItem(Item))
	{
		auto Index = GetIndexForItem(Item);
		if (ensure(Items.IsValidIndex(Index)))
		{
			RichTextBlock->SetText(Items[Index].Text);
			RichTextBlock->SetVisibility(bIsTextClickable ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::HitTestInvisible);
		}
	}
	Super::HandleOnEntryInitializedInternal(Item, TableRow);
}

UKGRichTextBlock* UKGTextListView::GetRichTextBlockForItem(ItemType Item) const
{
	if (auto EntryWidget = GetEntryWidgetFromItem(Item))
	{
		return IKGTextListEntry::GetRichTextBlock(EntryWidget);
	}
	return nullptr;
}

TSharedPtr<SKGTextListView<UKGListView::ItemType>> UKGTextListView::GetListViewSlateWidget() const
{
	return StaticCastSharedPtr<SKGTextListView<ItemType>>(MyListView);
}

void UKGTextListView::SetTexts(const TArray<FKGTextListViewItemData>& InItems)
{
	Items = InItems;
	BP_SetListItems(Items.Num());
	if (MyListView.IsValid() && !MyListView->IsStartedTouchInteraction())
	{
		if (Items.Num() != 0)
		{
			ScrollIndexIntoView(Items.Num() - 1, 1);
		}
	}
}

int32 UKGTextListView::AddText(int32 Key, FText Text)
{
	Items.Add({ Key, Text });
	auto Index = Items.Num();
	AddItem();
	if (MyListView.IsValid() && !MyListView->IsStartedTouchInteraction())
	{
		ScrollIndexIntoView(Items.Num() - 1, 1);
	}
	return Index;
}

bool UKGTextListView::RemoveText(int32 Key)
{
	auto FoundIndex = Items.IndexOfByPredicate([Key](const FKGTextListViewItemData& Item) { return Item.Key == Key; });
	if (FoundIndex == INDEX_NONE)
	{
		return false;
	}
	Items.RemoveAt(FoundIndex);
	RemoveItem(FoundIndex);
	return true;
}

void UKGTextListView::ClearTexts()
{
	Items.Empty(32);
	BP_SetListItems(0);
}

void UKGTextListView::SetIsTextClickable(bool bClickable)
{
	bIsTextClickable = bClickable;
	if (MyListView.IsValid())
	{
		auto GeneratedTableRows = GetListViewSlateWidget()->GetGeneratedTableRows();
		for (const auto& TableRow : GeneratedTableRows)
		{
			if (auto EntryWidget = StaticCastSharedRef<SObjectTableRow<ItemType>>(TableRow->AsWidget())->GetWidgetObject())
			{
				if (auto RichTextBlock = IKGTextListEntry::GetRichTextBlock(EntryWidget))
				{
					RichTextBlock->SetVisibility(bIsTextClickable ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::HitTestInvisible);
				}
			}
		}
	}
}

bool UKGTextListView::GetIsTextClickable() const
{
	return bIsTextClickable;
}
