#include "SC7CyclingList.h"
#include "Widgets/Layout/SScaleBox.h"
#include "Components/Widget.h"
#include "Framework/Application/SlateApplication.h"
static const float VecMultiplier = 10.0f;
void SC7CyclingList::Construct(const FArguments& InArgs)
{
	ListSize = InArgs._ListSize;
	WidgetLength = InArgs._WidgetLength;
	LinearDescent = InArgs._LinearDescent;
	InitialDistance = InArgs._InitialDistance;
	ExpDescent = InArgs._ExpDescent;
	WidgetSize = InArgs._WidgetSize;
	DataSize = InArgs._DataSize;
	OnC7CyclingListItemFocus = InArgs._OnC7CyclingListItemFocus;
	OnC7CyclingListItemRefreshed = InArgs._OnC7CyclingListItemRefreshed;
	OnC7CyclingListItemInitialized = InArgs._OnC7CyclingListItemInitialized;
	OnGenerateC7CyclingListItem = InArgs._OnGenerateC7CyclingListItem;
	OnReleaseC7CyclingListItem = InArgs._OnReleaseC7CyclingListItem;
	OnEvaluateListItemLayout = InArgs._OnEvaluateListItemLayout;
	OnC7CyclingListItemComputeDesiredSize = InArgs._OnC7CyclingListItemComputeDesiredSize;
	BoxToAnchorIndexMap.Empty();
	BoxToDataIndexMap.Empty();
	//ChildSlot[
	//	SAssignNew(CanvasPanel, SConstraintCanvas)
	//];
	SConstraintCanvas::Construct(SConstraintCanvas::FArguments()
		.Visibility(InArgs._Visibility)
	);

	CursorInterval = 200.0f;
	EntryInterval.LeftIndex = 0;
	EntryInterval.RightIndex = ListSize - 1;
	/*
	for (int32 i = 0; i < ListSize; ++i)
	{
		TSharedPtr<SC7CyclingListItem> Box = SNew(SC7CyclingListItem, SharedThis(this)).Stretch(EStretch::UserSpecifiedWithClipping).UserSpecifiedScale(
			GetScale(ExpDescent, FMath::Abs(i - ListSize / 2)
			));
		Box->OnClicked.BindLambda(
			[this, Box]() {
				ScheduleScrollTo(Box);
				return FReply::Unhandled();
			}
		);
		BoxToAnchorIndexMap.Add(TTuple<TSharedPtr<SC7CyclingListItem>, int32>(Box, i));
		BoxToDataIndexMap.Add(TTuple<TSharedPtr<SC7CyclingListItem>, int32>(Box, i));
		FAnchorInfo Test = OnEvaluateListItemLayout.Execute(i, 0, false);
		AddSlot().Offset(Test.Offset).Anchors(Test.Anchor)
			.ZOrder(Test.ZOrder).Alignment(Test.Alignment)
			.AutoSize(true)[
			Box.ToSharedRef()
		];
	}*/
}
/*
void SC7CyclingList::AddAddAnchorElement(TObjectPtr<UWidget> Widget, int32 Index)
{
	if (DataSize > Index)
	{
		TSharedPtr<SWidget> BoxWidget = Children.GetChildAt(Index).ToSharedPtr();
		TSharedPtr<SC7CyclingListItem> Box = StaticCastSharedPtr<SC7CyclingListItem>(BoxWidget);
		Box->SetContentForItem(Widget->TakeWidget());
		
	}
}*/

void SC7CyclingList::SetDataNum(int32 Num, int32 SelectIndex)
{
	DataSize = Num;
	for (TMap<TSharedPtr<SC7CyclingListItem>, int32>::TIterator iter(BoxToAnchorIndexMap); iter; ++iter)
	{
		OnReleaseC7CyclingListItem.Execute(iter->Key.ToSharedRef());
	}
	BoxToAnchorIndexMap.Empty();
	BoxToDataIndexMap.Empty();
	EntryInterval.LeftIndex = 0;
	EntryInterval.RightIndex = ListSize - 1;
	ClearChildren();
	for (int32 Index = 0; Index < ListSize; ++Index)
	{
		AddSlotItemByIndex((Index + SelectIndex - ListSize / 2 + DataSize) % DataSize, Index, Index == ListSize / 2);
	}
	AnimationPlayMode = EAnimationPlayMode::None;
	bIsScrollingActiveTimerRegistered = false;
	if (UpdateScrollAnimationHandle.IsValid())
	{
		UnRegisterActiveTimer(UpdateScrollAnimationHandle.ToSharedRef());
		UpdateScrollAnimationHandle.Reset();
	}
	InertialScrollManager.ClearScrollVelocity();
	CumulativeStep = 0;
}

void SC7CyclingList::AddSlotItemByIndex(int32 DataIndex, int32 AnchorIndex, bool bFocus)
{
	TSharedRef<SWidget> ObjectWidget = OnGenerateC7CyclingListItem.Execute();
	TSharedPtr<SC7CyclingListItem> Box = SNew(SC7CyclingListItem, SharedThis(this)).Stretch(EStretch::UserSpecified);
	Box->SetOnClicked(FOnClicked::CreateLambda([WeakList = StaticCastWeakPtr<SC7CyclingList>(this->AsWeak()), WeakBox = StaticCastWeakPtr<SC7CyclingListItem>(Box->AsWeak())]() {
		auto List = WeakList.Pin();
		auto Box = WeakBox.Pin();
		if (List && Box)
		{
			List->ScheduleScrollTo(Box);
		}
		return FReply::Handled();
	}));
	FAnchorInfo Anchor = OnEvaluateListItemLayout.Execute(AnchorIndex, 0, true);
	AddSlot().Offset(Anchor.Offset).Anchors(Anchor.Anchor)
		.ZOrder(Anchor.ZOrder).Alignment(Anchor.Alignment)
		.AutoSize(true)[
			Box.ToSharedRef()
		];
	Box->SetContentForItem(ObjectWidget);
	Box->SetVisibility(EVisibility::Visible);
	Box->SetUserSpecifiedScale(Anchor.Scale);
	Box->SetRenderOpacity(Anchor.Opacity);
	if (AnchorIndex == ListSize / 2)
	{
		EntryInterval.Entry = Box;
		EntryInterval.SelectedIndex = DataIndex;
	}
	BoxToAnchorIndexMap.Add(TTuple<TSharedPtr<SC7CyclingListItem>, int32>(Box, AnchorIndex));
	BoxToDataIndexMap.Add(TTuple<TSharedPtr<SC7CyclingListItem>, int32>(Box, DataIndex));
	OnC7CyclingListItemInitialized.Execute(Box.ToSharedRef(), DataIndex, bFocus);
}

/*
void SC7CyclingList::SetWidgetAnchorElement(TObjectPtr<UWidget> Widget, int32 Index, bool bFocus)
{
	if (DataSize > Index)
	{
		TSharedPtr<SC7CyclingListItem> Box = SNew(SC7CyclingListItem, SharedThis(this)).Stretch(EStretch::UserSpecifiedWithClipping).UserSpecifiedScale(
			GetScale(ExpDescent, FMath::Abs(Index - ListSize / 2)
			));
		Box->SetOnClicked(FOnClicked::CreateLambda([this, Box]() {
			ScheduleScrollTo(Box);
			return FReply::Unhandled();
			}));
		BoxToAnchorIndexMap.Add(TTuple<TSharedPtr<SC7CyclingListItem>, int32>(Box, Index));
		BoxToDataIndexMap.Add(TTuple<TSharedPtr<SC7CyclingListItem>, int32>(Box, Index));
		FAnchorInfo Anchor = OnEvaluateListItemLayout.Execute(Index, 0, true);
		AddSlot().Offset(Anchor.Offset).Anchors(Anchor.Anchor)
			.ZOrder(Anchor.ZOrder).Alignment(Anchor.Alignment)
			.AutoSize(true)[
				Box.ToSharedRef()
			];
		Box->SetContentForItem(Widget->TakeWidget());


		Box->SetVisibility(EVisibility::Visible);
		Box->SetUserSpecifiedScale(Anchor.Scale);
		Box->SetRenderOpacity(Anchor.Opacity);
		if (bFocus)
		{
			EntryInterval.Entry = Box;
			EntryInterval.SelectedIndex = Index;
		}
	}
}
*/

void SC7CyclingList::ClearListItems()
{
	BoxToAnchorIndexMap.Empty();
	BoxToDataIndexMap.Empty();
	ClearChildren();
}

void SC7CyclingList::ReleaseSlate()
{
	for (TMap<TSharedPtr<SC7CyclingListItem>, int32>::TIterator iter(BoxToAnchorIndexMap); iter; ++iter)
	{
		TSharedPtr<SC7CyclingListItem> ThisBox = iter->Key;
		ThisBox->DetachChild();
	}
}

void SC7CyclingList::ScheduleScrollTo(TSharedPtr<SC7CyclingListItem> Box)
{
	AnimationPlayMode = EAnimationPlayMode::Schedule;
	TargetIndex = BoxToDataIndexMap[Box];
	bForwardSchedule = BoxToAnchorIndexMap[Box] < ListSize / 2;
	if (!UpdateScrollAnimationHandle.IsValid())
	{
		bIsScrollingActiveTimerRegistered = true;
		UpdateScrollAnimationHandle = RegisterActiveTimer(0.f, FWidgetActiveTimerDelegate::CreateSP(this, &SC7CyclingList::UpdateScrollAnimation));

	}
}


void SC7CyclingList::OnItemFocus(TSharedPtr<SC7CyclingListItem> Widget, bool bFocus)
{
	if (BoxToDataIndexMap.Find(Widget))
	{
		OnC7CyclingListItemFocus.ExecuteIfBound(Widget.ToSharedRef(), BoxToDataIndexMap[Widget], bFocus);
	}
}

void SC7CyclingList::OnItemRefreshed(TSharedPtr<SC7CyclingListItem> Widget)
{
	if (BoxToDataIndexMap.Find(Widget) && BoxToAnchorIndexMap.Find(Widget))
	{
		OnC7CyclingListItemRefreshed.ExecuteIfBound(Widget.ToSharedRef(), BoxToDataIndexMap[Widget]);
	}
}

FVector2D SC7CyclingList::ComputeDesiredSize(float LayoutScaleMultiplier) const
{
	return OnC7CyclingListItemComputeDesiredSize.Execute();
}
//#pragma optimize("",off)
void SC7CyclingList::ProcessScroll(float Delta)
{
	CumulativeStep += Delta;
	//UE_LOG(LogTemp, Log, TEXT("@bylizhemian, CumulativeStep: %f"), CumulativeStep)
	if (CumulativeStep >= CursorInterval)
	{
		for (TMap<TSharedPtr<SC7CyclingListItem>, int32>::TIterator iter(BoxToAnchorIndexMap); iter; ++iter)
		{
			iter->Value += 1;
			if (iter->Value >= ListSize)
			{
				iter->Value %= ListSize;
				BoxToDataIndexMap[iter->Key] = (EntryInterval.LeftIndex + DataSize - 1) % DataSize;
				EntryInterval.RightIndex = (EntryInterval.RightIndex + DataSize - 1) % DataSize;
				EntryInterval.LeftIndex = (EntryInterval.LeftIndex + DataSize - 1) % DataSize;
				FAnchorInfo Anchor = OnEvaluateListItemLayout.Execute(iter->Value, 0, false);
				TSharedPtr<SC7CyclingListItem> ThisBox = iter->Key;
				ThisBox->SetVisibility(EVisibility::Visible);

				ThisBox->SetUserSpecifiedScale(
					Anchor.Scale
				);
				ThisBox->SetRenderOpacity(
					Anchor.Opacity
				);
				for (int32 i = 0; i < Children.Num(); ++i)
				{
					if (Children.GetChildAt(i) == ThisBox)
					{
						Children[i].SetOffset(Anchor.Offset);
						Children[i].SetZOrder(Anchor.ZOrder);
						break;
					}
				}
				//BoxToAnchorIndexMap.Remove(iter->Key);
				//break;
				OnItemRefreshed(iter->Key);
				//BP_OnListItemRefresh.Broadcast(this, iter->Key, BoxToDataIndexMap[iter->Key], false);
			}

		}
		//UUIFunctionLibrary::ShiftChild(this, 0, GetChildAt(GetChildrenCount() - 1));
		CumulativeStep = 0;
	}
	else if (CumulativeStep <= -CursorInterval)
	{
		for (TMap<TSharedPtr<SC7CyclingListItem>, int32>::TIterator iter(BoxToAnchorIndexMap); iter; ++iter)
		{
			iter->Value += ListSize - 1;
			iter->Value %= ListSize;
			if (iter->Value >= ListSize - 1)
			{
				BoxToDataIndexMap[iter->Key] = (EntryInterval.RightIndex + 1) % DataSize;
				EntryInterval.RightIndex = (EntryInterval.RightIndex + 1) % DataSize;
				EntryInterval.LeftIndex = (EntryInterval.LeftIndex + 1) % DataSize;
				FAnchorInfo Anchor = OnEvaluateListItemLayout.Execute(iter->Value, 0, false);
				TSharedPtr<SC7CyclingListItem> ThisBox = iter->Key;
				ThisBox->SetVisibility(EVisibility::Visible);

				ThisBox->SetUserSpecifiedScale(
					Anchor.Scale
				);
				ThisBox->SetRenderOpacity(
					Anchor.Opacity
				);
				for (int32 i = 0; i < Children.Num(); ++i)
				{
					if (Children.GetChildAt(i) == ThisBox)
					{
						Children[i].SetOffset(Anchor.Offset);
						Children[i].SetZOrder(Anchor.ZOrder);
						break;
					}
				}
				//BoxToAnchorIndexMap.Remove(iter->Key);
				//break;
				OnItemRefreshed(iter->Key);
			//	BP_OnListItemRefresh.Broadcast(this, iter->Key, BoxToDataIndexMap[iter->Key], false);
			}
		}
		//UUIFunctionLibrary::ShiftChild(this, GetChildrenCount() - 1, GetChildAt(0));
		CumulativeStep = 0;
	}
	else
	{
		for (TMap<TSharedPtr<SC7CyclingListItem>, int32>::TIterator iter(BoxToAnchorIndexMap); iter; ++iter)
		{
			int32 AnchorIndex = iter->Value;
			TSharedPtr<SC7CyclingListItem> ThisBox = iter->Key;

			FAnchorInfo Anchor = OnEvaluateListItemLayout.Execute(AnchorIndex, FMath::Abs(CumulativeStep / CursorInterval), CumulativeStep > 0);

			ThisBox->SetVisibility(EVisibility::Visible);

			ThisBox->SetUserSpecifiedScale(
				Anchor.Scale
			);
			ThisBox->SetRenderOpacity(
				Anchor.Opacity
			);
			for (int32 i = 0; i < Children.Num(); ++i)
			{
				if (Children.GetChildAt(i) == ThisBox)
				{
					Children[i].SetOffset(Anchor.Offset);
					Children[i].SetZOrder(Anchor.ZOrder);
					break;
				}
			}
		}
	}
}
//#pragma optimize("",on)

void SC7CyclingList::BeginInertialScrolling()
{
	if (!UpdateScrollAnimationHandle.IsValid())
	{
		bIsScrollingActiveTimerRegistered = true;
		AnimationPlayMode = EAnimationPlayMode::Inertial;
		UpdateScrollAnimationHandle = RegisterActiveTimer(0.f, FWidgetActiveTimerDelegate::CreateSP(this, &SC7CyclingList::UpdateScrollAnimation));

	}

}

EActiveTimerReturnType SC7CyclingList::UpdateScrollAnimation(double InCurrentTime, float InDeltaTime)
{
	if (AnimationPlayMode == EAnimationPlayMode::Inertial)
	{
		return UpdateInertialScrolling(InCurrentTime, InDeltaTime);
	}
	else if (AnimationPlayMode == EAnimationPlayMode::Schedule)
	{
		return UpdateScheduleScrolling(InCurrentTime, InDeltaTime);
	}
	else if (AnimationPlayMode == EAnimationPlayMode::Forward || AnimationPlayMode == EAnimationPlayMode::Reverse)
	{
		return UpdateAttachScrolling(InCurrentTime, InDeltaTime);
	}
	else
	{
		AnimationPlayMode = EAnimationPlayMode::None;
		bIsScrollingActiveTimerRegistered = false;
		return EActiveTimerReturnType::Stop;
	}
}
#pragma optimize("",off)
EActiveTimerReturnType SC7CyclingList::UpdateScheduleScrolling(double InCurrentTime, float InDeltaTime)
{
	if (TargetIndex == INDEX_NONE)
	{
		AnimationPlayMode = EAnimationPlayMode::None;
		bIsScrollingActiveTimerRegistered = false;
		return EActiveTimerReturnType::Stop;
	}
	else
	{
		int32 MidIndex = (EntryInterval.LeftIndex + ListSize) == EntryInterval.RightIndex ? (EntryInterval.LeftIndex + EntryInterval.RightIndex) / 2
			: (EntryInterval.LeftIndex + ListSize / 2) % DataSize;
		/*
			(EntryInterval.LeftIndex < EntryInterval.RightIndex) ? (EntryInterval.LeftIndex + EntryInterval.RightIndex) / 2
			: (DataSize - EntryInterval.LeftIndex) > EntryInterval.RightIndex ? (EntryInterval.LeftIndex + EntryInterval.RightIndex + DataSize) / 2
			: (EntryInterval.LeftIndex + EntryInterval.RightIndex) % DataSize / 2;
		*/
		if (MidIndex == TargetIndex)
		{
			ProcessScroll(-CumulativeStep);
			AnimationPlayMode = EAnimationPlayMode::None;
			bIsScrollingActiveTimerRegistered = false;
			UnRegisterActiveTimer(UpdateScrollAnimationHandle.ToSharedRef());
			UpdateScrollAnimationHandle.Reset();
			for (TMap<TSharedPtr<SC7CyclingListItem>, int32>::TIterator iter(BoxToAnchorIndexMap); iter; ++iter)
			{
				if (iter->Value == ListSize / 2)
				{
					EntryInterval.SelectedIndex = BoxToDataIndexMap[iter->Key];
					EntryInterval.Entry = iter->Key;
					OnItemFocus(iter->Key, true);
					break;
				}
			}
			return EActiveTimerReturnType::Stop;
		}
		else if (bForwardSchedule)
		{
			int32 SpeedMultiplier = MidIndex - TargetIndex > 0 ? MidIndex - TargetIndex : DataSize + MidIndex - TargetIndex;
			UE_LOG(LogTemp, Log, TEXT("ScheduleScroll:%i"), SpeedMultiplier)
			ProcessScroll(SpeedMultiplier * 10.0f);
			return EActiveTimerReturnType::Continue;
		}
		else
		{
			int32 SpeedMultiplier = TargetIndex - MidIndex > 0 ? TargetIndex - MidIndex : DataSize + TargetIndex - MidIndex;
			UE_LOG(LogTemp, Log, TEXT("ScheduleScroll:%i"), SpeedMultiplier)
			ProcessScroll(- SpeedMultiplier * 10.0f);
			return EActiveTimerReturnType::Continue;
		}
	}
	return EActiveTimerReturnType::Stop;
}
#pragma optimize("",on)
EActiveTimerReturnType SC7CyclingList::UpdateAttachScrolling(double InCurrentTime, float InDeltaTime)
{
	if (FMath::Abs(CumulativeStep) < 5.0f)
	{
		ProcessScroll(AnimationPlayMode == EAnimationPlayMode::Forward  ? -CumulativeStep : CumulativeStep);
		StopAnimationScrolling(true);
		return EActiveTimerReturnType::Stop;
	}
	else if (FMath::Abs(CumulativeStep - CursorInterval) < 5.0f)
	{
		ProcessScroll(AnimationPlayMode == EAnimationPlayMode::Forward ? CursorInterval - CumulativeStep
		: CumulativeStep - CursorInterval);
		StopAnimationScrolling(true);
		return EActiveTimerReturnType::Stop;
	}
	else if (AnimationPlayMode == EAnimationPlayMode::Forward)
	{
		ProcessScroll(5.0f);
	}
	else if (AnimationPlayMode == EAnimationPlayMode::Reverse)
	{
		ProcessScroll(-5.0f);
	}
	return EActiveTimerReturnType::Continue;
}

EActiveTimerReturnType SC7CyclingList::UpdateInertialScrolling(double InCurrentTime, float InDeltaTime)
{
	InertialScrollManager.UpdateScrollVelocity(InDeltaTime);
	const float ScrolVelocity = InertialScrollManager.GetScrollVelocity();
	if (FMath::Abs(ScrolVelocity) < 300.0f * VecMultiplier)
	{
		EndInertialScrolling();
		SelectOptionOnScrollEnd();
	}
	else
	{
		ProcessScroll(ScrolVelocity * InDeltaTime / VecMultiplier);
	}
	return EActiveTimerReturnType::Continue;
}
void SC7CyclingList::EndInertialScrolling()
{
	InertialScrollManager.ClearScrollVelocity();
	//bNeedTickInertia = false;
}


void SC7CyclingList::SelectOptionOnScrollEnd()
{
	if (DataSize <= 0) {
		return;
	}
	if (FMath::IsNearlyZero(CumulativeStep))
	{
		ProcessScroll(-CumulativeStep);
		StopAnimationScrolling(true);
		return;
	}
	AnimationPlayMode = ((FMath::Abs(CumulativeStep / CursorInterval) > 0.5f) ^ (CumulativeStep < 0.0f)) ? EAnimationPlayMode::Forward : EAnimationPlayMode::Reverse;
}

void SC7CyclingList::StopAnimationScrolling(bool bFocus)
{
	for (TMap<TSharedPtr<SC7CyclingListItem>, int32>::TIterator iter(BoxToAnchorIndexMap); iter; ++iter)
	{
		if (iter->Value == ListSize / 2)
		{
			EntryInterval.SelectedIndex = BoxToDataIndexMap[iter->Key];
			EntryInterval.Entry = iter->Key;
			OnItemFocus(iter->Key, bFocus);
			break;
		}
	}
	AnimationPlayMode = EAnimationPlayMode::None;
	bIsScrollingActiveTimerRegistered = false;
	if (UpdateScrollAnimationHandle.IsValid())
	{
		UnRegisterActiveTimer(UpdateScrollAnimationHandle.ToSharedRef());
		UpdateScrollAnimationHandle.Reset();
	}
}

void SC7CyclingList::StartScrolling()
{
	//if (AnimationPlayMode != EAnimationPlayMode::FisrtTouch)
	{
		UE_LOG(LogTemp, Log, TEXT("@bylizhemian CumulativeStp:%f"), CumulativeStep)
		//AnimationPlayMode = EAnimationPlayMode::FisrtTouch;
		AnimationPlayMode = EAnimationPlayMode::Scrolling;
		OnItemFocus(EntryInterval.Entry, false);
		EntryInterval.SelectedIndex = -1;
		EntryInterval.Entry.Reset();
	}

}

bool SC7CyclingList::IsDetectScrolling() const
{
	return FSlateApplication::IsInitialized() && AmountScrolledWhileMouseDown >= FSlateApplication::Get().GetDragTriggerDistance();
}

//SWidget Interface
void SC7CyclingList::OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.IsTouchEvent())
	{
		if (!bStartedTouchInteraction)
		{
			if (MyGeometry.IsUnderLocation(MouseEvent.GetLastScreenSpacePosition()))
			{
				bStartedTouchInteraction = true;

			}
		}
	}
}

FReply SC7CyclingList::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		InertialScrollManager.ClearScrollVelocity();
		if (!bIsScrollingActiveTimerRegistered)
		{
			StartScrolling();
		}
		else
		{
			AnimationPlayMode = EAnimationPlayMode::None;
			bIsScrollingActiveTimerRegistered = false;
			UnRegisterActiveTimer(UpdateScrollAnimationHandle.ToSharedRef());
			UpdateScrollAnimationHandle.Reset();
			StartScrolling();
		}
		return FReply::Handled();// .CaptureMouse(SharedThis(this));
	}
	return FReply::Unhandled();
}

FReply SC7CyclingList::OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (FSlateApplication::Get().IsFakingTouchEvents())
	{
		return FReply::Unhandled();
	}
	if (MouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton) && !MouseEvent.IsTouchEvent())//PC
	{
		AmountScrolledWhileMouseDown += FMath::Abs(MouseEvent.GetCursorDelta().X / MyGeometry.Scale);
		if (!bIsScrollingActiveTimerRegistered)//(IsDetectScrolling())
		{
			if (AnimationPlayMode == EAnimationPlayMode::None)
			{
				StartScrolling();
				return HasMouseCapture() ? FReply::Handled() : FReply::Handled().CaptureMouse(AsShared());
			}
		//	UE_LOG(LogTemp, Log, TEXT("@bylizhemian OnMouseMove Geometry:%s MouseEvent:%s"), *MyGeometry.ToString(), *MouseEvent.ToText().ToString())
			InertialScrollManager.AddScrollSample(MouseEvent.GetCursorDelta().X / MyGeometry.Scale, FSlateApplication::Get().GetCurrentTime());
			ProcessScroll(MouseEvent.GetCursorDelta().X / MyGeometry.Scale);
			return HasMouseCapture() ? FReply::Handled() : FReply::Handled().CaptureMouse(AsShared());
		}
		else
		{
			AnimationPlayMode = EAnimationPlayMode::None;
			bIsScrollingActiveTimerRegistered = false;
			UnRegisterActiveTimer(UpdateScrollAnimationHandle.ToSharedRef());
			UpdateScrollAnimationHandle.Reset();
			StartScrolling();
		}
	}
	return FReply::Unhandled();
}

FReply SC7CyclingList::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	//UE_LOG(LogTemp, Warning, TEXT("@bylizhemian OnMouseButtonUp"))
	if (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		if (!bIsScrollingActiveTimerRegistered)
		{
			BeginInertialScrolling();
		}
		return FReply::Unhandled().ReleaseMouseCapture();
	}
	return FReply::Unhandled();
}

void SC7CyclingList::OnMouseLeave(const FPointerEvent& MouseEvent)
{
	//UE_LOG(LogTemp, Warning, TEXT("@bylizhemian OnMouseLeave"))
	SConstraintCanvas::OnMouseLeave(MouseEvent);
	bStartedTouchInteraction = false;
	if (!bIsScrollingActiveTimerRegistered)
	{
		BeginInertialScrolling();
	}
}


FReply SC7CyclingList::OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	bStartedTouchInteraction = false;
	if (!bIsScrollingActiveTimerRegistered)
	{
		BeginInertialScrolling();
	}
	if (HasMouseCapture())
	{
		return FReply::Unhandled().ReleaseMouseCapture();
	}
	return FReply::Unhandled();
}

FReply SC7CyclingList::OnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	return FReply::Unhandled();
}

FReply SC7CyclingList::OnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	if (bStartedTouchInteraction)
	{
		if (!bIsScrollingActiveTimerRegistered && !FMath::IsNearlyZero(InTouchEvent.GetCursorDelta().X))//(IsDetectScrolling())
		{
			if (AnimationPlayMode == EAnimationPlayMode::None)
			{
				StartScrolling();
				return HasMouseCapture() ? FReply::Handled() : FReply::Handled().CaptureMouse(AsShared());
			}
			//	UE_LOG(LogTemp, Log, TEXT("@bylizhemian OnMouseMove Geometry:%s MouseEvent:%s"), *MyGeometry.ToString(), *MouseEvent.ToText().ToString())
			InertialScrollManager.AddScrollSample(InTouchEvent.GetCursorDelta().X / MyGeometry.Scale, FSlateApplication::Get().GetCurrentTime());
			ProcessScroll(InTouchEvent.GetCursorDelta().X / MyGeometry.Scale);
			return HasMouseCapture() ? FReply::Handled() : FReply::Handled().CaptureMouse(AsShared());
		}
		else if(bIsScrollingActiveTimerRegistered)
		{
			AnimationPlayMode = EAnimationPlayMode::None;
			bIsScrollingActiveTimerRegistered = false;
			UnRegisterActiveTimer(UpdateScrollAnimationHandle.ToSharedRef());
			UpdateScrollAnimationHandle.Reset();
			StartScrolling();
		}
	}
	return FReply::Unhandled();
}



FReply SC7CyclingList::OnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.IsTouchEvent())
	{
		this->InertialScrollManager.ClearScrollVelocity();
		//AmountScrolledWhileRightMouseDown = 0;
		bStartedTouchInteraction = true;
		return FReply::Unhandled();
	}
	else
	{
		return FReply::Unhandled();
	}
}
void SC7CyclingList::OnMouseCaptureLost(const FCaptureLostEvent& CaptureLostEvent)
{
	UE_LOG(LogTemp, Log, TEXT("@bylizhemian OnMouseCaptureLost"));
	if (!bIsScrollingActiveTimerRegistered)
	{
		BeginInertialScrolling();
	}
	return;
}