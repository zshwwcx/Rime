#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Slate/SObjectWidget.h"
#include "Widgets/Layout/SScaleBox.h"
#include "Framework/SlateDelegates.h"

class SC7CyclingList;


class KGUI_API SC7CyclingListItem : public SScaleBox//ObjectWidgetObjectWidget
{
public:
	SLATE_BEGIN_ARGS(SC7CyclingListItem)
		: _Content(),
		_Stretch(EStretch::None),
		_UserSpecifiedScale(1.0f)
		{}
	SLATE_DEFAULT_SLOT(FArguments, Content)
	SLATE_ARGUMENT(EStretch::Type, Stretch)
	SLATE_ARGUMENT(float, UserSpecifiedScale)
	SLATE_EVENT(FOnClicked, OnClicked)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, TSharedPtr<SC7CyclingList> InOwnerList);

	TSharedPtr<SC7CyclingList> OwnerList;
public:
	FOnClicked OnClicked;
	bool bPressed = false;
	FVector2D PressPos;
	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	void SetContentForItem(TSharedRef<SWidget> InWidget);
	void SetOnClicked(FOnClicked InOnClicked);
	void DetachChild();
	UUserWidget* GetWidgetObject();
};