#pragma once

#include "CoreMinimal.h"
#include "Components/CanvasPanel.h"
#include "Blueprint/UserWidgetPool.h"
#include "SC7CyclingList.h"
#include "C7CyclingList.generated.h"


DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnCyclingListInitialzedDynamic, UObject*, Item, UWidget*, Widget, int32, Index, bool, Selected);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnCyclingListRefreshDynamic, UObject*, Item, UWidget*, Widget, int32, Index);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnCyclingListFocusDynamic, UObject*, Item, UWidget*, Widget, int32, Index, bool, Selected);

UCLASS()
class KGUI_API UC7CyclingList : public UWidget
{
	GENERATED_BODY()

public:
	UC7CyclingList(const FObjectInitializer& ObjectInitializer);

	void ReleaseSlateResources(bool bReleaseChildren) override;

public:
//#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 DataNum;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 PreviewNum;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float WidgetLength = 100.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float LinearDescent = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float InitialDistance = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ExpDescent = 1.0f;


	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D DesiredScrollWidgetSize;


	//以下接口，用于创建Entry对象
	UPROPERTY(Transient)
	FUserWidgetPool EntryWidgetPool;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSubclassOf<UUserWidget> EntryWidget;
	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//UCurveVector* SplineCurve;
//#endif


protected:
	TSharedPtr<SC7CyclingList> SlateList;

	virtual TSharedRef<SWidget> RebuildWidget() override;

	UFUNCTION(BlueprintCallable)
	void SetDataNum(int32 In, int32 SelectIndex = 0);

	UUserWidget* GenerateEntry();


private:
	UPROPERTY(BlueprintAssignable, Category = Events)
	FOnCyclingListRefreshDynamic BP_OnListItemRefresh;
	
	UPROPERTY(BlueprintAssignable, Category = Events)
	FOnCyclingListFocusDynamic BP_OnListItemFocus;

	UPROPERTY(BlueprintAssignable, Category = Events)
	FOnCyclingListInitialzedDynamic BP_OnListItemInitialized;

	void OnItemFocus(TSharedRef<SWidget> Entry, int32 DataIndex, bool bFocus);
	void OnItemInitialized(TSharedRef<SWidget> Entry, int32 DataIndex, bool bFocus);
	void OnItemRefreshed(TSharedRef<SWidget> Entry, int32 DataIndex);

	TSharedRef<SWidget> OnGenerateRow();
	void OnReleaseRow(TSharedRef<SWidget> Widget);
	FAnchorInfo OnEvaluate(int32 Index, float k, bool bForward);
	FVector2D OnComputeDesiredSize();
};