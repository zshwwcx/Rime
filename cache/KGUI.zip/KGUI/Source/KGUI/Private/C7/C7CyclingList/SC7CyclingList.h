#pragma once

#include "CoreMinimal.h"
#include "SC7CyclingListItem.h"
#include "Framework/Layout/InertialScrollManager.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SConstraintCanvas.h"

class UWidget;

DECLARE_DELEGATE_ThreeParams(FOnC7CyclingListItemFocus, TSharedRef<SWidget>, int32, bool);
DECLARE_DELEGATE_TwoParams(FOnC7CyclingListItemRefreshed, TSharedRef<SWidget>, int32);
DECLARE_DELEGATE_ThreeParams(FOnC7CyclingListItemInitialized, TSharedRef<SWidget>, int32, bool)
DECLARE_DELEGATE_RetVal(TSharedRef<SWidget>, FOnGenerateC7CyclingListItem);
DECLARE_DELEGATE_OneParam(FOnReleaseC7CyclingListItem, TSharedRef<SWidget>);
DECLARE_DELEGATE_RetVal(FVector2D, FOnC7CyclingListItemComputeDesiredSize);
struct FAnchorInfo;

DECLARE_DELEGATE_RetVal_ThreeParams(FAnchorInfo, FOnEvaluateListItemLayout, int32, float, bool);

struct FAnchorInfo {
	FVector2D Alignment;
	FAnchors Anchor;
	FMargin Offset;
	float Scale;
	float Opacity;
	int32 ZOrder;
	FAnchorInfo() : Alignment(FVector2D(0.5, 0)),
	Anchor(FAnchors(0, 0)), Offset(FMargin()), Scale(1.0f), ZOrder(0){}
};

struct FEntryInterval
{
	int32 LeftIndex;
	int32 RightIndex;
	int32 SelectedIndex;
	TSharedPtr<SC7CyclingListItem> Entry;
	FEntryInterval(int32 l = 0, int32 r = 0, int32 m = 0) 
		: LeftIndex(l), RightIndex(r), SelectedIndex(m) {
	}
};


enum class EAnimationPlayMode
{
	None,
	FisrtTouch,//DeltaDelta
	Scrolling,
	Forward,
	Reverse,
	Inertial,
	Schedule
};

class KGUI_API SC7CyclingList : public SConstraintCanvas
{
public:
	//Slot, Canvas
	SLATE_BEGIN_ARGS(SC7CyclingList)
		{
			_Visibility = EVisibility::SelfHitTestInvisible;
			_ListSize = 5;
			_WidgetLength = 100.0f;
			_LinearDescent = 0.0f;
			_InitialDistance = 0.0f;
			_ExpDescent = 1.0f;
			_DataSize = 15;
			_WidgetSize = FVector2D();
		}
		SLATE_ARGUMENT(int32, ListSize)
		SLATE_ARGUMENT(int32, DataSize)
		SLATE_ARGUMENT(float, LinearDescent)
		SLATE_ARGUMENT(float, WidgetLength)
		SLATE_ARGUMENT(float, InitialDistance)
		SLATE_ARGUMENT(float, ExpDescent)
		SLATE_ARGUMENT(FVector2D, WidgetSize)
		SLATE_EVENT(FOnC7CyclingListItemFocus, OnC7CyclingListItemFocus)
		SLATE_EVENT(FOnC7CyclingListItemRefreshed, OnC7CyclingListItemRefreshed)
		SLATE_EVENT(FOnGenerateC7CyclingListItem, OnGenerateC7CyclingListItem)
		SLATE_EVENT(FOnEvaluateListItemLayout, OnEvaluateListItemLayout)
		SLATE_EVENT(FOnReleaseC7CyclingListItem, OnReleaseC7CyclingListItem)
		SLATE_EVENT(FOnC7CyclingListItemComputeDesiredSize, OnC7CyclingListItemComputeDesiredSize)
		SLATE_EVENT(FOnC7CyclingListItemInitialized, OnC7CyclingListItemInitialized)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	//
	void ProcessScroll(float Delta);
	float CumulativeStep = 0.0f;
	int32 ListSize;
	int32 DataSize;
	float WidgetLength = 100.0f;
	float LinearDescent = 0.0f;
	float InitialDistance = 0.0f;
	float ExpDescent = 1.0f;
	FMargin LayoutOffset;//Offset
	FVector2D WidgetSize;
	FVector2D LeftMargin;
	FVector2D RightMargin;
	float CursorInterval;
	TMap<TSharedPtr<SC7CyclingListItem>, int32> BoxToAnchorIndexMap;
	TMap<TSharedPtr<SC7CyclingListItem>, int32> BoxToDataIndexMap;
	
	//TMap<TSharedPtr<SC7CyclingListItem>, TObjectPtr<UWidget>> BoxToWidgetIndexMap;
	
	FEntryInterval EntryInterval;

	FOnC7CyclingListItemFocus OnC7CyclingListItemFocus;
	FOnC7CyclingListItemRefreshed OnC7CyclingListItemRefreshed;
	FOnGenerateC7CyclingListItem OnGenerateC7CyclingListItem;
	FOnEvaluateListItemLayout OnEvaluateListItemLayout;
	FOnReleaseC7CyclingListItem OnReleaseC7CyclingListItem;
	FOnC7CyclingListItemComputeDesiredSize OnC7CyclingListItemComputeDesiredSize;
	FOnC7CyclingListItemInitialized OnC7CyclingListItemInitialized;

	TSharedPtr<SConstraintCanvas> CanvasPanel;
public:
	//
	//virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
	//virtual bool ComputeVolatility() const override;
	//virtual FReply OnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual void OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual void OnMouseLeave(const FPointerEvent& MouseEvent) override;

	virtual FReply OnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override;
	virtual FReply OnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override;
	virtual FReply OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override;

	virtual void OnMouseCaptureLost(const FCaptureLostEvent& CaptureLostEvent);

	bool bStartedTouchInteraction = false;
	FVector2f PressedScreenSpacePosition;

	bool IsDetectScrolling() const;
	float AmountScrolledWhileMouseDown;

	//void ReleaseFocus();
	//void SetFocus(TSharedPtr<SC7CyclingListItem> Widget, bool bFocus);
	void OnItemFocus(TSharedPtr<SC7CyclingListItem> Widget, bool bFocus);
	void OnItemRefreshed(TSharedPtr<SC7CyclingListItem> Widget);
	//
	FInertialScrollManager InertialScrollManager;
	void BeginInertialScrolling();
	EActiveTimerReturnType UpdateInertialScrolling(double InCurrentTime, float InDeltaTime);
	void EndInertialScrolling();
	bool bIsScrollingActiveTimerRegistered = false;
	TSharedPtr<FActiveTimerHandle> UpdateScrollAnimationHandle;

	EActiveTimerReturnType UpdateScrollAnimation(double InCurrentTime, float InDeltaTime);
	EActiveTimerReturnType UpdateAttachScrolling(double InCurrentTime, float InDeltaTime);
	EActiveTimerReturnType UpdateScheduleScrolling(double InCurrentTime, float InDeltaTime);
	
	void StopAnimationScrolling(bool bFocus = false);
	void StartScrolling();
	void ScheduleScrollTo(TSharedPtr<SC7CyclingListItem> Box);
	int32 TargetIndex = INDEX_NONE;
	bool bForwardSchedule = false;

	void SelectOptionOnScrollEnd();
	EAnimationPlayMode AnimationPlayMode;

protected:
	virtual FVector2D ComputeDesiredSize(float) const override;

public:
	void SetDataNum(int32 Num, int32 SelectIndex);

public:
	//void AddAddAnchorElement(TObjectPtr<UWidget> Widget, int32 Index);

	//void SetWidgetAnchorElement(TObjectPtr<UWidget> Widget, int32 Index, bool bFocus);
	void AddSlotItemByIndex(int32 DataIndex, int32 AnchorIndex, bool bFocus = false);
	void ClearListItems();
	void ReleaseSlate();
};