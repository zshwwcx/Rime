#include "SC7CyclingListItem.h"


void SC7CyclingListItem::Construct(const FArguments& InArgs, TSharedPtr<SC7CyclingList> InOwnerList)
{
	SScaleBox::Construct(SScaleBox::FArguments().UserSpecifiedScale(InArgs._UserSpecifiedScale).Stretch(InArgs._Stretch));
	SetVisibility(EVisibility::Visible);
	OwnerList = InOwnerList;
}



void SC7CyclingListItem::SetContentForItem(TSharedRef<SWidget> InWidget)
{
	SetContent(InWidget);
}

void SC7CyclingListItem::SetOnClicked(FOnClicked InOnClicked)
{
	OnClicked = InOnClicked;
}

void SC7CyclingListItem::DetachChild()
{
	ChildSlot.DetachWidget();
}

FReply SC7CyclingListItem::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	bPressed = true;
	PressPos = MyGeometry.GetAbsolutePosition();
	//UE_LOG(LogTemp, Log, TEXT("SC7CyclingListItem: OnMouseButtonDown"));
	return FReply::Unhandled();
}
FReply SC7CyclingListItem::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	//UE_LOG(LogTemp, Log, TEXT("SC7CyclingListItem: OnMouseButtonUp"));
	if (bPressed && (PressPos - MyGeometry.GetAbsolutePosition()).SquaredLength() < 10.0f)
	{
		bPressed = false;
		PressPos.X = -10;
		PressPos.Y = -10;
		if (OnClicked.IsBound())
		{
			FReply Reply = OnClicked.Execute();
			return Reply;
		}
		return FReply::Handled();
	}
	return FReply::Unhandled();
}

UUserWidget* SC7CyclingListItem::GetWidgetObject()
{
	TSharedRef<SWidget> Child = GetChildren()->GetChildAt(0);
	TSharedRef<SObjectWidget> ObjectWidget = StaticCastSharedRef<SObjectWidget>(Child);
	return ObjectWidget->GetWidgetObject();
}

