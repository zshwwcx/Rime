#include "C7CyclingList.h"
#include "Components/CanvasPanelSlot.h"
#include "Blueprint/WidgetTree.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "SC7CyclingList.h"



UC7CyclingList::UC7CyclingList(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer), EntryWidgetPool(*this)
{

}

//#pragma optimize("",off)
UUserWidget* UC7CyclingList::GenerateEntry()
{
	UUserWidget* ListEntryWidget = EntryWidgetPool.GetOrCreateInstance<UUserWidget>(*EntryWidget);
	ListEntryWidget->SetVisibility(ESlateVisibility::HitTestInvisible);
	//BP_OnListItemInitialized.Broadcast(this, ListEntryWidget);
	return ListEntryWidget;
}
//#pragma optimize("",on)

TSharedRef<SWidget> UC7CyclingList::RebuildWidget()
{
	EntryWidgetPool.ReleaseAll();
//#if WITH_EDITOR
	//ClearChildren();
	/*
	if (EntryWidget && DataNum > 0)//如果DataNum<=0表示数据未设置，不做添加，等lua设置数量
	{
		for (int32 i = 0; i < PreviewNum; ++i)
		{
			UUserWidget* DuplicateRoot;
			//DuplicateRoot = GenerateEntry();//UUserWidget::CreateWidgetInstance(*this, ScrollWidget->GetClass(), NAME_None);
			//AddChild(DuplicateRoot);
			//BP_OnListItemRefresh.Broadcast(this, DuplicateRoot, i);

			if (i == PreviewNum / 2)
			{
				//BP_OnListItemFocus.Broadcast(this, DuplicateRoot, i, true);
			}
		}
	}*/
//#endif
	TArray<UUserWidget*> ActiveWidgets = EntryWidgetPool.GetActiveWidgets();
	SlateList = SNew(SC7CyclingList).ListSize(PreviewNum).WidgetLength(WidgetLength).LinearDescent(LinearDescent)
		.InitialDistance(InitialDistance).ExpDescent(ExpDescent).WidgetSize(DesiredScrollWidgetSize).DataSize(DataNum)
		.OnC7CyclingListItemFocus_UObject(this, &UC7CyclingList::OnItemFocus)
		.OnC7CyclingListItemRefreshed_UObject(this, &UC7CyclingList::OnItemRefreshed)
		.OnC7CyclingListItemInitialized_UObject(this, &UC7CyclingList::OnItemInitialized)
		.OnGenerateC7CyclingListItem_UObject(this, &UC7CyclingList::OnGenerateRow)
		.OnReleaseC7CyclingListItem_UObject(this, &UC7CyclingList::OnReleaseRow)
		.OnEvaluateListItemLayout_UObject(this, &UC7CyclingList::OnEvaluate)
		.OnC7CyclingListItemComputeDesiredSize_UObject(this, &UC7CyclingList::OnComputeDesiredSize);
	/*
	for (int32 i = 0; i < ActiveWidgets.Num(); ++i)
	{

		ActiveWidgets[i]->TakeWidget();
		SlateList->AddAddAnchorElement(ActiveWidgets[i], i);
	}*/
#if WITH_EDITOR
	if (IsDesignTime())
	{
		SetDataNum(PreviewNum);
	}
#endif

	return SlateList.ToSharedRef();

}

TSharedRef<SWidget> UC7CyclingList::OnGenerateRow()
{
	UUserWidget* Widget = GenerateEntry();
	return Widget->TakeWidget();//理论上应该是CachedWidget，但是为了不写Tick貌似只能这么搞了
}

void UC7CyclingList::OnReleaseRow(TSharedRef<SWidget> Widget)
{
	if (TSharedPtr<SObjectWidget> ObjectWidget = StaticCastSharedPtr<SObjectWidget>(Widget.ToSharedPtr()))
	{
		EntryWidgetPool.Release(ObjectWidget->GetWidgetObject(), false);
	}
}

void UC7CyclingList::SetDataNum(int32 In, int32 SelectIndex)
{
	DataNum = In;
	if (SelectIndex < 0 || SelectIndex >= DataNum)
	{
		SelectIndex = PreviewNum / 2;
	}
	SlateList->SetDataNum(In, SelectIndex);
	/*
	SlateList->ClearListItems();
	EntryWidgetPool.ReleaseAll();
	for (int32 i = 0; i < PreviewNum; ++i)
	{
		UUserWidget* Entry = GenerateEntry();
		SlateList->SetWidgetAnchorElement(Entry, i, i == PreviewNum /2);
		BP_OnListItemInitialized.Broadcast(this, Entry, i, i == PreviewNum / 2);
	}
	*/
	/*
	TArray<UUserWidget*> ActiveWidgets = EntryWidgetPool.GetActiveWidgets();
	for (int32 i = 0; i < ActiveWidgets.Num(); ++i)
	{
		SlateList->SetWidgetAnchorElement(ActiveWidgets[i], i);
		BP_OnListItemRefresh.Broadcast(this, ActiveWidgets[i], i);
		if (i == ActiveWidgets.Num() / 2)
		{
			BP_OnListItemFocus.Broadcast(this, ActiveWidgets[i], i, true);
		}
	}*/
	
}

void UC7CyclingList::OnItemFocus(TSharedRef<SWidget> Entry, int32 DataIndex, bool bFocus)
{
	if (TSharedPtr<SC7CyclingListItem> ObjectWidget = StaticCastSharedPtr<SC7CyclingListItem>(Entry.ToSharedPtr()))
	{
		if (UUserWidget* UserWidget = ObjectWidget->GetWidgetObject())
		{
			BP_OnListItemFocus.Broadcast(this, UserWidget, DataIndex, bFocus);
		}
	}
}

void UC7CyclingList::OnItemInitialized(TSharedRef<SWidget> Entry, int32 DataIndex, bool bFocus)
{
	if (TSharedPtr<SC7CyclingListItem> ObjectWidget = StaticCastSharedPtr<SC7CyclingListItem>(Entry.ToSharedPtr()))
	{
		if (UUserWidget* UserWidget = ObjectWidget->GetWidgetObject())
		{
			BP_OnListItemInitialized.Broadcast(this, UserWidget, DataIndex, bFocus);
		}
	}
}

void UC7CyclingList::OnItemRefreshed(TSharedRef<SWidget> Entry, int32 DataIndex)
{
	if (TSharedPtr<SC7CyclingListItem> ObjectWidget = StaticCastSharedPtr<SC7CyclingListItem>(Entry.ToSharedPtr()))
	{
		if (UUserWidget* UserWidget = ObjectWidget->GetWidgetObject())
		{
			BP_OnListItemRefresh.Broadcast(this, UserWidget, DataIndex);
		}
	}
}

void UC7CyclingList::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	EntryWidgetPool.ResetPool();
	if (SlateList.IsValid())
	{
		SlateList->ReleaseSlate();
		SlateList.Reset();
	}
}


//#pragma optimize("",off)
FAnchorInfo UC7CyclingList::OnEvaluate(int32 Index, float k, bool bForward)
{
	Index += 1;
	PreviewNum += 2;
	FAnchorInfo BeginAnchor;
	{
		int32 SecondaryIndex = FMath::Abs(Index - PreviewNum / 2);
		BeginAnchor.Offset.Top = DesiredScrollWidgetSize.Y / 2 - DesiredScrollWidgetSize.Y * FMath::Pow(ExpDescent, SecondaryIndex) / 2;

		float OffsetFromCenter = SecondaryIndex * InitialDistance - SecondaryIndex * (SecondaryIndex - 1) / 2 * LinearDescent + (FMath::IsNearlyEqual(ExpDescent, 1.0f) ? (SecondaryIndex - 1) : ((ExpDescent - FMath::Pow(ExpDescent, SecondaryIndex)) / (1 - ExpDescent))) * DesiredScrollWidgetSize.X +
			DesiredScrollWidgetSize.X / 2 + FMath::Pow(ExpDescent, SecondaryIndex) * DesiredScrollWidgetSize.X / 2;
		SecondaryIndex = PreviewNum / 2;
		float HalfWidgetLength = SecondaryIndex * InitialDistance - SecondaryIndex * (SecondaryIndex - 1) / 2 * LinearDescent + (FMath::IsNearlyEqual(ExpDescent, 1.0f) ? (SecondaryIndex - 1) : ((ExpDescent - FMath::Pow(ExpDescent, SecondaryIndex)) / (1 - ExpDescent))) * DesiredScrollWidgetSize.X +
			DesiredScrollWidgetSize.X / 2 + FMath::Pow(ExpDescent, SecondaryIndex) * DesiredScrollWidgetSize.X;

		BeginAnchor.Offset.Left = HalfWidgetLength + ((Index - PreviewNum / 2) > 0 ? OffsetFromCenter : -OffsetFromCenter);
		BeginAnchor.Offset.Right = 0;
		BeginAnchor.Offset.Bottom = 0;
		BeginAnchor.ZOrder = PreviewNum / 2 - FMath::Abs(Index - PreviewNum / 2);
		BeginAnchor.Scale = FMath::Pow(ExpDescent, FMath::Abs(Index - PreviewNum / 2));
		BeginAnchor.Opacity = 0.25f - 3.0f / (PreviewNum * PreviewNum) * Index * Index + 3.0f / PreviewNum * Index;
	}
	FAnchorInfo EndAnchor;
	{
		/*if (bForward && Index == PreviewNum - 1)
		{
			EndAnchor = BeginAnchor;
		}
		else */if (bForward)
		{
			Index += 1;
			int32 SecondaryIndex = FMath::Abs(Index - PreviewNum / 2);
			EndAnchor.Offset.Top = DesiredScrollWidgetSize.Y / 2 - DesiredScrollWidgetSize.Y * FMath::Pow(ExpDescent, SecondaryIndex) / 2;

			float OffsetFromCenter = SecondaryIndex * InitialDistance - SecondaryIndex * (SecondaryIndex - 1) / 2 * LinearDescent + (FMath::IsNearlyEqual(ExpDescent, 1.0f) ? (SecondaryIndex - 1) : ((ExpDescent - FMath::Pow(ExpDescent, SecondaryIndex)) / (1 - ExpDescent))) * DesiredScrollWidgetSize.X +
				DesiredScrollWidgetSize.X / 2 + FMath::Pow(ExpDescent, SecondaryIndex) * DesiredScrollWidgetSize.X / 2;
			SecondaryIndex = PreviewNum / 2;
			float HalfWidgetLength = SecondaryIndex * InitialDistance - SecondaryIndex * (SecondaryIndex - 1) / 2 * LinearDescent + (FMath::IsNearlyEqual(ExpDescent, 1.0f) ? (SecondaryIndex - 1) : ((ExpDescent - FMath::Pow(ExpDescent, SecondaryIndex)) / (1 - ExpDescent))) * DesiredScrollWidgetSize.X +
				DesiredScrollWidgetSize.X / 2 + FMath::Pow(ExpDescent, SecondaryIndex) * DesiredScrollWidgetSize.X;

			EndAnchor.Offset.Left = HalfWidgetLength + ((Index - PreviewNum / 2) > 0 ? OffsetFromCenter : -OffsetFromCenter);
			EndAnchor.Offset.Right = 0;
			EndAnchor.Offset.Bottom = 0;
			EndAnchor.ZOrder = PreviewNum / 2 - FMath::Abs(Index - PreviewNum / 2);
			EndAnchor.Scale = FMath::Pow(ExpDescent, FMath::Abs(Index - PreviewNum / 2));
			EndAnchor.Opacity = 0.25f - 3.0f / (PreviewNum * PreviewNum) * Index * Index + 3.0f / PreviewNum * Index;
		}
		/*
		else if(!bForward && Index == 0)
		{
			EndAnchor = BeginAnchor;
		}*/
		else
		{
			Index -= 1;
			int32 SecondaryIndex = FMath::Abs(Index - PreviewNum / 2);
			EndAnchor.Offset.Top = DesiredScrollWidgetSize.Y / 2 - DesiredScrollWidgetSize.Y * FMath::Pow(ExpDescent, SecondaryIndex) / 2;

			float OffsetFromCenter = SecondaryIndex * InitialDistance - SecondaryIndex * (SecondaryIndex - 1) / 2 * LinearDescent + (FMath::IsNearlyEqual(ExpDescent, 1.0f) ? (SecondaryIndex - 1) : ((ExpDescent - FMath::Pow(ExpDescent, SecondaryIndex)) / (1 - ExpDescent))) * DesiredScrollWidgetSize.X +
				DesiredScrollWidgetSize.X / 2 + FMath::Pow(ExpDescent, SecondaryIndex) * DesiredScrollWidgetSize.X / 2;
			SecondaryIndex = PreviewNum / 2;
			float HalfWidgetLength = SecondaryIndex * InitialDistance - SecondaryIndex * (SecondaryIndex - 1) / 2 * LinearDescent + (FMath::IsNearlyEqual(ExpDescent, 1.0f) ? (SecondaryIndex - 1) : ((ExpDescent - FMath::Pow(ExpDescent, SecondaryIndex)) / (1 - ExpDescent))) * DesiredScrollWidgetSize.X +
				DesiredScrollWidgetSize.X / 2 + FMath::Pow(ExpDescent, SecondaryIndex) * DesiredScrollWidgetSize.X;

			EndAnchor.Offset.Left = HalfWidgetLength + ((Index - PreviewNum / 2) > 0 ? OffsetFromCenter : -OffsetFromCenter);
			EndAnchor.Offset.Right = 0;
			EndAnchor.Offset.Bottom = 0;
			EndAnchor.ZOrder = PreviewNum / 2 - FMath::Abs(Index - PreviewNum / 2);
			EndAnchor.Scale = FMath::Pow(ExpDescent, FMath::Abs(Index - PreviewNum / 2));
			EndAnchor.Opacity = 0.25f - 3.0f / (PreviewNum * PreviewNum) * Index * Index + 3.0f / PreviewNum * Index;
		}
	}
	FAnchorInfo Res;
	Res.Offset.Left = (1 - k) * BeginAnchor.Offset.Left + k * EndAnchor.Offset.Left;
	Res.Offset.Top = (1 - k) * BeginAnchor.Offset.Top + k * EndAnchor.Offset.Top;
	Res.Offset.Bottom = (1 - k) * BeginAnchor.Offset.Bottom + k * EndAnchor.Offset.Bottom;
	Res.Offset.Right = (1 - k) * BeginAnchor.Offset.Right + k * EndAnchor.Offset.Right;
	Res.ZOrder = k < 0.5f ?  BeginAnchor.ZOrder : EndAnchor.ZOrder;
	Res.Scale = (1 - k) * BeginAnchor.Scale + k * EndAnchor.Scale;
	Res.Opacity = (1 - k) * BeginAnchor.Opacity + k * EndAnchor.Opacity;

	PreviewNum -= 2;
	return Res;

}

FVector2D UC7CyclingList::OnComputeDesiredSize()
{
	FVector2D Res;
	int32 SecondaryIndex = FMath::Abs(PreviewNum / 2) + 1;
	Res.X = (SecondaryIndex * InitialDistance - SecondaryIndex * (SecondaryIndex - 1) / 2 * LinearDescent + (FMath::IsNearlyEqual(ExpDescent, 1.0f) ? (SecondaryIndex - 1) : ((ExpDescent - FMath::Pow(ExpDescent, SecondaryIndex)) / (1 - ExpDescent))) * DesiredScrollWidgetSize.X) * 2 +
		DesiredScrollWidgetSize.X + FMath::Pow(ExpDescent, SecondaryIndex) * DesiredScrollWidgetSize.X * 2;
	Res.Y = DesiredScrollWidgetSize.Y;
	return Res;
}
//#pragma optimize("",on)