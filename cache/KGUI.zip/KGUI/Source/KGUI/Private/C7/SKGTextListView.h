#pragma once

#include "Framework/Application/IInputProcessor.h"
#include "Slate/Views/SKGListView.h"

struct FKGTextListViewItemData;

template <typename ItemType>
class SKGTextListView;

template <typename ItemType>
class SKGTextListView : public SKGListView<ItemType>
{
	using Super = SKGListView<ItemType>;

public:

	TArray<TSharedRef<ITableRow>> GetGeneratedTableRows() const
	{
		TArray<TSharedRef<ITableRow>> TableRows;
		for (const auto& Pair : this->WidgetGenerator.ItemToWidgetMap)
		{
			TableRows.Add(Pair.Value);
		}
		return TableRows;
	}
};