// Fill out your copyright notice in the Description page of Project Settings.
#include "C7/KGUITickableSubsystem.h"

#include "Engine/Engine.h"

FKGUITickableObjectBase::FKGUITickableObjectBase()
{

}

FKGUITickableObjectBase::~FKGUITickableObjectBase()
{
    // if (UKGUITickableSubsystem* Subsystem = GEngine->GetEngineSubsystem<UKGUITickableSubsystem>())
    // {
    //     Subsystem->UnregisterTickableWidget(this);
    // }
}

void FKGUITickableObjectBase::RegisterTick()
{
    UKGUITickableSubsystem* Subsystem = GEngine->GetEngineSubsystem<UKGUITickableSubsystem>();
    if (IsValid(Subsystem))
    {
        Subsystem->RegisterTickableWidget(this);
    }
}

void FKGUITickableObjectBase::UnregisterTick()
{
    UKGUITickableSubsystem* Subsystem = GEngine->GetEngineSubsystem<UKGUITickableSubsystem>();
    if (IsValid(Subsystem))
    {
        Subsystem->UnregisterTickableWidget(this);
    }
}

void UKGUITickableSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
    Super::Initialize(Collection);
}

void UKGUITickableSubsystem::Deinitialize()
{
    Super::Deinitialize();
}

void UKGUITickableSubsystem::Tick(float DeltaTime)
{
    check(IsInGameThread());
    BuildNeedTickingObjects();
    for (auto* Obj : PendingTickObjects)
    {
        if (Obj)
        {
            Obj->Tick(DeltaTime);
        }
    }

    if (bNeedsCleanUp)
    {
        TickableObjects.RemoveAll([](const FKGUITickableObjectBase* Obj) { return Obj == nullptr; });
        bNeedsCleanUp = false;
    }

    bIsTickingObjects = false;
}

void UKGUITickableSubsystem::RegisterTickableWidget(FKGUITickableObjectBase* Widget)
{
    if (MapTickObjects.Contains(Widget))
    {
        return;
    }
    
    FScopeLock NewTickableObjectsLock(&NewTickableObjectsCritical);
    TickableObjects.AddUnique(Widget);
    MapTickObjects.Add(Widget, true);
}

void UKGUITickableSubsystem::UnregisterTickableWidget(FKGUITickableObjectBase* Widget)
{
    int32 Pos = TickableObjects.Find(Widget);
    if (Pos != INDEX_NONE)
    {
        MapTickObjects.Remove(Widget);
        TickableObjects[Pos] = nullptr;
        bNeedsCleanUp = true;
    }
}

void UKGUITickableSubsystem::BuildNeedTickingObjects()
{
    check(!bIsTickingObjects);
    FScopeLock NewTickableObjectsLock(&NewTickableObjectsCritical);
    PendingTickObjects.Empty(PendingTickObjects.Num());
    for (auto* Obj : TickableObjects)
    {
        if (Obj && Obj->IsTickable())
        {
            PendingTickObjects.Emplace(Obj);
        }
    }

    bIsTickingObjects = true;
}

