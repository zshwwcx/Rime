// Fill out your copyright notice in the Description page of Project Settings.



#include "UMGAsTextureRT.h"
#include "Blueprint/UserWidget.h"
#include "Components/Widget.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Framework/Application/SlateApplication.h"
#include "Slate/SObjectWidget.h"
#include "Widgets/SViewport.h"

DECLARE_CYCLE_STAT(TEXT("UUMGAsTextureRT Tick"),STAT_UMGAsTextureRTTick,STATGROUP_Game);
UUMGAsTextureRT::UUMGAsTextureRT()
{
}

void UUMGAsTextureRT::BeginDestroy()
{
	Window.Reset();
	SlateWidget.Reset();
	if (WidgetRenderer)
	{
		BeginCleanup(WidgetRenderer);
		WidgetRenderer = nullptr;
	}
	Super::BeginDestroy();
}

bool UUMGAsTextureRT::WidgetToTexture(UUserWidget* InWidget, const FVector2D& drawSize,bool UpdateEveryFrame)
{
	if (InWidget!=nullptr)
	{
		return SWidgetToTexture(InWidget->TakeWidget(), drawSize,UpdateEveryFrame);
	}
	return false;
}

void UUMGAsTextureRT::ReleaseResources()
{
	Widget = nullptr;

	SlateWidget.Reset();
	
	if (Window.IsValid())
	{
		Window->SetContent(SNullWidget::NullWidget);
		Window.Reset();
	}
	
	if (WidgetRenderer)
	{
		BeginCleanup(WidgetRenderer);
		WidgetRenderer = nullptr;
	}
}




bool UUMGAsTextureRT::SWidgetToTexture(TSharedRef<SWidget> InWidget, const FVector2D& drawSize,bool UpdateEveryFrame)
{
	if (FSlateApplication::IsInitialized())
	{
		SRGB = true;
		
		DrawSize = drawSize;
		if (Window == nullptr)
		{
			Window = SNew(SVirtualWindow).Size(DrawSize);
		}
		RenderTargetFormat = RTF_RGBA8_SRGB;
		
		Window->SetContent(InWidget);
		Window->Resize(DrawSize);
		Window->SetVisibility(EVisibility::HitTestInvisible);
		Window->SetShouldResolveDeferred(false);
		Window->SetIsFocusable(false);
	
		if (WidgetRenderer == nullptr)
		{
			WidgetRenderer = new FWidgetRenderer();
		}
		if (!WidgetRenderer) return false;

		WidgetRenderer->SetApplyColorDeficiencyCorrection(false);
		Window->SlatePrepass(1);
		// WidgetRenderer->SetIsPrepassNeeded(false);
		WidgetRenderer->SetClearHitTestGrid(false);
		WidgetRenderer->SetUseGammaCorrection(true);
		
		WidgetRenderer->DrawWindow(this, Window->GetHittestGrid(), Window.ToSharedRef(), 1.f,DrawSize, 0, false);
		// bool bRepaintedWidgets = WidgetRenderer->DrawInvalidationRoot(Window, this,InWidget, Context, false);
		return true;
	}
	return false;
}


uint32 UUMGAsTextureRT::CalcTextureMemorySizeEnum(ETextureMipCount Enum) const
{
	// Calculate size based on format.  All mips are resident on render targets so we always return the same value.
	EPixelFormat Format = GetFormat();
	int32 BlockSizeX = GPixelFormats[Format].BlockSizeX;
	int32 BlockSizeY = GPixelFormats[Format].BlockSizeY;
	int32 BlockBytes = GPixelFormats[Format].BlockBytes;
	int32 NumBlocksX = (SizeX + BlockSizeX - 1) / BlockSizeX;
	int32 NumBlocksY = (SizeY + BlockSizeY - 1) / BlockSizeY;
	int32 NumBytes = NumBlocksX * NumBlocksY * BlockBytes;
	return NumBytes;
}

void UUMGAsTextureRT::Tick(float DeltaTime)
{
	SCOPE_CYCLE_COUNTER(STAT_UMGAsTextureRTTick)
	if (WidgetRenderer)
	{
		WidgetRenderer->DrawWindow(this, Window->GetHittestGrid(), Window.ToSharedRef(), 1.f,DrawSize, DeltaTime, false);
	}
}


TStatId UUMGAsTextureRT::GetStatId() const
{
	return GetStatID();
}

bool UUMGAsTextureRT::IsTickable() const
{
	return WidgetRenderer!=nullptr && bUpdateEveryFrame;
}
