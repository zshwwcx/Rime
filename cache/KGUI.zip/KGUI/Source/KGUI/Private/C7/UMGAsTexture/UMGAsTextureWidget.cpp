// Fill out your copyright notice in the Description page of Project Settings.


#include "C7/UMGAsTexture/UMGAsTextureWidget.h"

#include "Engine/TextureRenderTarget2D.h"
#include "Materials/MaterialInstanceDynamic.h"

void UUMGAsTextureWidget::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	if (TextHelper)
	{
		TextHelper->ReleaseResources();
	}
}

void UUMGAsTextureWidget::SetWidgetAsTexture(UWidget* InWidget,
											UMaterialInterface* Material, FName& TextParamName,FVector2D& size)
{
	if(TextHelper == nullptr)
	{
		TextHelper = NewObject<UUMGAsTextureHelper>();
	}

	SetBrushFromMaterial(Material);
	UMaterialInstanceDynamic* DM = GetDynamicMaterial();
	if (!DM)
	{
		return;
	}
	
	UTextureRenderTarget2D* RenterTarget = TextHelper->WidgetToTexture(InWidget,size);
	if (RenterTarget)
	{
		DM->SetTextureParameterValue(TextParamName,RenterTarget);
	}

}
