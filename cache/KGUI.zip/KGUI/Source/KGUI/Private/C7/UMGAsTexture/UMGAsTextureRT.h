// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Slate/WidgetRenderer.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Tickable.h"

#include "UMGAsTextureRT.generated.h"


/**
 * 
 */
class UWidget;

UCLASS()
class KGUI_API UUMGAsTextureRT : public UTextureRenderTarget2D,public FTickableGameObject
{
	GENERATED_BODY()
	UUMGAsTextureRT();

	virtual void  BeginDestroy() override;
public:

	UFUNCTION(BlueprintCallable)
	bool WidgetToTexture(UUserWidget* InWidget, const FVector2D& drawSize,bool UpdateEveryFrame);

	bool SWidgetToTexture(TSharedRef<SWidget> InWidget, const FVector2D& drawSize,bool UpdateEveryFrame);
	
	UFUNCTION(BlueprintCallable, Category = RenderTexture)
	void ReleaseResources();
private:
	
	UPROPERTY()
	UUserWidget* Widget;

	TSharedPtr<SWidget> SlateWidget;

	UPROPERTY()
	FVector2D DrawSize;

	UPROPERTY()
	bool  bUpdateEveryFrame;
	
	TSharedPtr<class SVirtualWindow>  Window;

	virtual uint32 CalcTextureMemorySizeEnum(ETextureMipCount Enum) const override;
	
	virtual void Tick(float DeltaTime) override;
	virtual TStatId GetStatId() const override;
	virtual bool IsTickable() const override;

private:
	FWidgetRenderer* WidgetRenderer;
};


