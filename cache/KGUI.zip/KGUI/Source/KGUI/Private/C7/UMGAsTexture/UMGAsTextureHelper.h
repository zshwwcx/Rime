// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Slate/WidgetRenderer.h"
#include "Tickable.h"

#include "UMGAsTextureHelper.generated.h"

class UUserWidget;
/**
 * 
 */
class UWidget;

UCLASS()
class KGUI_API UUMGAsTextureHelper : public UObject,public FTickableGameObject
{
	GENERATED_BODY()
	UUMGAsTextureHelper();

	virtual void  BeginDestroy() override;
public:
	UFUNCTION(BlueprintCallable, Category = RenderTexture)
	class UTextureRenderTarget2D* WidgetToTexture(UWidget *const widget, const FVector2D &drawSize);
	
	UFUNCTION(BlueprintCallable, Category = RenderTexture)
	UTexture2D* GetTexture();
	
	UPROPERTY()
	UTexture2D* OutTexture;
	
	UFUNCTION(BlueprintCallable, Category = RenderTexture)
	void ReleaseResources();
private:

	// void RegisterWindow();
	// void UnregisterWindow();

	UPROPERTY()
	UWidget* Widget;

	TSharedPtr<SWidget> SlateWidget;

	UPROPERTY()
	FVector2D DrawSize;
	
	TSharedPtr<class SVirtualWindow>  Window;
	
	UPROPERTY()
	class UTextureRenderTarget2D* TextureRenderTarget;

	virtual void Tick(float DeltaTime) override;
	virtual TStatId GetStatId() const override;
	virtual bool IsTickable() const override;

private:
	FWidgetRenderer* WidgetRenderer;
};
