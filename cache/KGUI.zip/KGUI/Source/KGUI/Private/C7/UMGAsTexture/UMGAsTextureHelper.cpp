// Fill out your copyright notice in the Description page of Project Settings.


#include "C7/UMGAsTexture/UMGAsTextureHelper.h"
#include "Input/HittestGrid.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Blueprint/UserWidget.h"
#include "Components/Widget.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Framework/Application/SlateApplication.h"
#include "Slate/SObjectWidget.h"
#include "Widgets/SViewport.h"

DECLARE_CYCLE_STAT(TEXT("UUMGAsTextureHelper Tick"),STAT_UMGAsTextureHelperTick,STATGROUP_Game);
UUMGAsTextureHelper::UUMGAsTextureHelper()
{
}

void UUMGAsTextureHelper::BeginDestroy()
{
	TextureRenderTarget = nullptr;
	Window.Reset();
	SlateWidget.Reset();
	if (WidgetRenderer)
	{
		BeginCleanup(WidgetRenderer);
		WidgetRenderer = nullptr;
	}
	Super::BeginDestroy();
}

void UUMGAsTextureHelper::ReleaseResources()
{
	TextureRenderTarget = nullptr;
	Widget = nullptr;

	SlateWidget.Reset();
	
	if (Window.IsValid())
	{
		Window->SetContent(SNullWidget::NullWidget);
		Window.Reset();
	}
	
	if (WidgetRenderer)
	{
		BeginCleanup(WidgetRenderer);
		WidgetRenderer = nullptr;
	}
}


UTextureRenderTarget2D*  UUMGAsTextureHelper::WidgetToTexture(UWidget *const InWidget, const FVector2D &Size)
{
	// As long as the slate application is initialized and the widget passed in is not null continue...
	if (FSlateApplication::IsInitialized() && InWidget != nullptr)
	{
		Widget = InWidget;
	
		DrawSize = Size;
		if (Window == nullptr)
		{
			Window = SNew(SVirtualWindow).Size(DrawSize);
		}

		Window->SetContent(InWidget->TakeWidget());
		Window->Resize(DrawSize);
		// Window->SetContent(SlateWidget.ToSharedRef());
		
		if (WidgetRenderer == nullptr)
		{
			WidgetRenderer = new FWidgetRenderer();
		}
		if (!WidgetRenderer) return nullptr;
		
		// Update/Create the render target 2D.
		TextureRenderTarget = FWidgetRenderer::CreateTargetFor(DrawSize, TF_Bilinear, false);
		WidgetRenderer->DrawWindow(TextureRenderTarget, Window->GetHittestGrid(), Window.ToSharedRef(), 1.f,DrawSize, 0, false);
		return TextureRenderTarget;
	}
	else return nullptr;
}


UTexture2D* UUMGAsTextureHelper::GetTexture()
{
	return OutTexture;
}

void UUMGAsTextureHelper::Tick(float DeltaTime)
{
	SCOPE_CYCLE_COUNTER(STAT_UMGAsTextureHelperTick)
	if (TextureRenderTarget)
	{
		WidgetRenderer->DrawWindow(TextureRenderTarget, Window->GetHittestGrid(), Window.ToSharedRef(), 1.f,DrawSize, DeltaTime, false);
	}
}

TStatId UUMGAsTextureHelper::GetStatId() const
{
	return GetStatID();
}

bool UUMGAsTextureHelper::IsTickable() const
{
	return TextureRenderTarget!= nullptr;
}
