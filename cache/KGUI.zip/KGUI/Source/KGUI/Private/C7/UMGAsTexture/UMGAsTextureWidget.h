// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UMG/Components/KGImage.h"
#include "UMGAsTextureHelper.h"
#include "UMGAsTextureWidget.generated.h"

/**
 * 
 */
UCLASS()
class KGUI_API UUMGAsTextureWidget : public UKGImage
{
	GENERATED_BODY()
	
	void ReleaseSlateResources(bool bReleaseChildren) override;
	
	UFUNCTION()
	void SetWidgetAsTexture(UWidget* InWidget,UMaterialInterface* Material,FName& 
	TextParamName,FVector2D& size);

	UPROPERTY()
	UUMGAsTextureHelper* TextHelper;
};
