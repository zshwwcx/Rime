// Fill out your copyright notice in the Description page of Project Settings.


#include "C7/WorldWidget2/DistanceInfoLayer2.h"
#include "SceneView.h"
#include "Engine/GameViewportClient.h"
#include "GameFramework/Pawn.h"
#include "Components/SkeletalMeshComponent.h"

static bool IsInOval(const FVector2D& ScreenSize, const FVector2D& Pos, const FVector2D& OvalSize)
{
	FVector2D RelativeDir2D = Pos - ScreenSize / 2;
	if (FMath::Pow(RelativeDir2D.X, 2) / FMath::Pow(OvalSize.X, 2) + FMath::Pow(RelativeDir2D.Y, 2) / FMath::Pow(OvalSize.Y, 2) < 1)
	{
		return true;
	}
	return false;
}

static bool ProjectToOvalEdge(const FVector2D& ScreenSize, const FVector2D& Dir, const FVector2D& OvalSize, FVector2D& out_ScreenPos)
{
	FVector2D RelativeDir = Dir.GetSafeNormal();
	const float Oval = FMath::Pow(RelativeDir.X, 2) / FMath::Pow(OvalSize.X, 2) + FMath::Pow(RelativeDir.Y, 2) / FMath::Pow(OvalSize.Y, 2);

	const float Coefficient = FMath::Sqrt(1 / Oval);
	const FVector2D NewRelativePos = RelativeDir * Coefficient;

	out_ScreenPos = ScreenSize / 2 + NewRelativePos;
	return true;
}

void SWorldWidgetDistanceInfoLayer2::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	//QUICK_SCOPE_CYCLE_COUNTER(SWorldWidgetDistanceInfoLayer2_Tick);
	//SCOPED_NAMED_EVENT(SWorldWidgetDistanceInfoLayer2_Tick, FColor::Green);
	SCOPED_NAMED_EVENT_FSTRING(FString::Printf(TEXT("SWorldWidgetDistanceInfoLayer2_Tick WorldWidgetsArray[%d]"), WorldWidgetsArray.Num()), FColor::Green);

	if (APlayerController* PlayerController = PlayerContext.GetPlayerController())
	{
		APawn* Pawn = PlayerController->GetPawn();
		if (Pawn == nullptr)
		{
			return;
		}
		if (UGameViewportClient* ViewportClient = PlayerController->GetWorld()->GetGameViewport())
		{
			const FGeometry& ViewportGeometry = ViewportClient->GetGameLayerManager()->GetViewportWidgetHostGeometry();

			FSceneViewProjectionData ProjectionData;
			FMatrix ViewProjectionMatrix;
			bool bHasProjectionData = false;

			ULocalPlayer const* const LP = PlayerController->GetLocalPlayer();
			if (LP && LP->ViewportClient)
			{
				bHasProjectionData = LP->GetProjectionData(ViewportClient->Viewport, /*out*/ ProjectionData);
				if (bHasProjectionData)
				{
					ViewProjectionMatrix = ProjectionData.ComputeViewProjectionMatrix();
				}
			}

			//计算屏幕投影相关
			APlayerCameraManager* CameraManager = PlayerController->PlayerCameraManager;
			check(CameraManager);
			FVector CameraForward = CameraManager->GetActorForwardVector();
			check(CameraForward.IsNormalized());
			FVector ViewOrigin = ProjectionData.ViewOrigin;
			auto ViewportSize = ViewportGeometry.GetLocalSize();

			auto WorldPosToScreenPos = [CameraForward, ViewOrigin, ViewProjectionMatrix, ViewportSize](const FVector& RealWorldPos, const FVector& WorldPos, FVector2D& OutScreenPos, double& ViewDist, FVector2D& Dir)
				{
					ViewDist = FVector::DotProduct(CameraForward, (RealWorldPos - ViewOrigin));
					//要求这个Canvas尺寸和viewport尺寸一致才可以按照下面这样算。
					FPlane Result = ViewProjectionMatrix.TransformFVector4(FVector4(RealWorldPos, 1.f));

					double W = Result.W;

					// the result of this will be x and y coords in -1..1 projection space
					const float RHW = 1.0f / W;

					float NDC_X = Result.X * RHW;
					float NDC_Y = Result.Y * RHW;

					// Move from projection space to normalized 0..1 UI space
					const float NormalizedX = (NDC_X / 2.f) + 0.5f;
					const float NormalizedY = 1.f - (NDC_Y / 2.f) - 0.5f;
					OutScreenPos.X = NormalizedX * ViewportSize.X;
					OutScreenPos.Y = NormalizedY * ViewportSize.Y;

					Dir = FVector2D(NDC_X, -NDC_Y * (ViewportSize.Y / ViewportSize.X)).GetSafeNormal();
					//返回原坐标是否在视野范围内
					FPlane ViewResult = ViewProjectionMatrix.TransformFVector4(FVector4(WorldPos, 1.f));

					const float ViewRHW = 1.0f / ViewResult.W;

					float ViewNDC_X = ViewResult.X * ViewRHW;
					float ViewNDC_Y = ViewResult.Y * ViewRHW;
					if (ViewResult.W <= 0.f) return false;
					return (ViewNDC_X >= -1.f && ViewNDC_X <= 1.f && ViewNDC_Y >= -1.f && ViewNDC_Y <= 1.f);
				};
			int EndIndex = WorldWidgetsArray.Num();
			for (int i = 0; i < EndIndex; i++)
			{
				TSharedPtr<FWWorldLayerData2> WLData = WorldWidgetsArray[i];
				int32 WWID = WLData->WWID;
				if (SWorldWidget2* WWidget = WLData->SWorldWidget.Get())
				{
					if (WWidget->WorldWidgetParams.bVisibility)
					{
						FVector PawnLocation;
						if (USkeletalMeshComponent* SkeletalMeshComp = Pawn->FindComponentByClass<USkeletalMeshComponent>())
						{
							//和连线特效挂点相同的PawnLocation位置来计算中间位置
							PawnLocation = SkeletalMeshComp->GetSocketLocation(FName("spine_03"));
						}
						else
						{
							PawnLocation = Pawn->GetActorLocation();
						}

						FTransform newTF = WWidget->GetTransform();
						newTF = WWidget->WorldWidgetParams.RelativeOffset * newTF;
						FVector WorldLocation = newTF.GetLocation() + WWidget->WorldWidgetParams.WorldOffset;

						float Dist = FVector::Dist(PawnLocation, WorldLocation);
						float HiddenDistance = WWidget->WorldWidgetParams.HiddenDistance != -1 ? WWidget->WorldWidgetParams.HiddenDistance : TNumericLimits<float>::Max();

						bool bShouldShow = Dist > HiddenDistance; //这里如果距离小于HiddenDistance，说明两个对象之间距离近，不需要在显示了
						WWidget->SetIsInHiddenDistance(WWID, bShouldShow);

						FVector RealWorldLocation = (WorldLocation + PawnLocation) / 2; //取中间距离，如果位置在椭圆范围外，设置在椭圆edge

						if (bShouldShow)
						{
							FVector2D ScreenPos;
							double ViewDist;
							FVector2D Dir;
							const FVector2D OvalSize = ViewportSize * WWidget->WorldWidgetParams.ScreenConstrainPadding / 2;

							bool bInView = WorldPosToScreenPos(RealWorldLocation, WorldLocation, ScreenPos, ViewDist, Dir);
							WWidget->SetIsOnEdge(WWID, !bInView);
							if (!IsInOval(ViewportSize, ScreenPos, OvalSize) && WWidget->WorldWidgetParams.ScreenConstrainType == EWWConstrainType2::CONSTRAIN_IN_OVAL__OUT_OF_OVAL)
							{
								ProjectToOvalEdge(ViewportSize, Dir, OvalSize, ScreenPos);
							}
							auto GPUTurb = WLData->GPUTurb.Get();
							float Order = -ViewDist + WWidget->WorldWidgetParams.ZorderOffSet;
							if (WLData->GPUTurb.IsValid())
							{
								GPUTurb->SetBatchZOrder(Order);
							}

							if (!WWidget->WorldWidgetParams.bNoDepth)
							{
								if (WLData->GPUTurb.IsValid())
								{
									GPUTurb->SetGPUViewDepth(ViewDist);
								}
								else
								{
									WLData->SWorldWidget->SetSlateInViewDepth(ViewDist);
								}

							}
							float GPUTurboScale = WWidget->ScaleForGPUTurbo;
							if (WLData->GPUTurb.IsValid())
							{
								GPUTurb->SetGPUTransform(FWidgetTransform(ScreenPos, FVector2D(GPUTurboScale, GPUTurboScale), FVector2D::ZeroVector, 0));
							}
							else
							{
								if (SConstraintCanvas::FSlot* CanvasSlot = WLData->Slot) 
								{
									CanvasSlot->SetOffset(FMargin(ScreenPos.X, ScreenPos.Y, 0, 0));
								}
							}
							WLData->ContainerWidget->SetVisibility(EVisibility::SelfHitTestInvisible);
						}
						else
						{
							WLData->ContainerWidget->SetVisibility(EVisibility::Collapsed);
						}
					}
				}
			}
		}
	}
}

void SWorldWidgetDistanceInfoLayer2::Construct(const FArguments& InArgs, const FLocalPlayerContext& InPlayerContext)
{
	PlayerContext = InPlayerContext;
	bCanSupportFocus = false;
	ChildSlot[SAssignNew(Canvas, SConstraintCanvas)];
}

