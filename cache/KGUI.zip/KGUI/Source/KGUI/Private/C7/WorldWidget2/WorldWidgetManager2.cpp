#include "C7/WorldWidget2/WorldWidgetManager2.h"

#include "Core/Common.h"
#include "Engine/GameViewportClient.h"
#include "Curves/CurveFloat.h"
#include "SceneView.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "C7/WorldWidget2/DamageEffectLayer.h"
#include "Misc/CrashCollector.h"
#include "Components/SkeletalMeshComponent.h"
#include "Misc/ObjCrashCollector.h"
#include "3C/Util/KGUtils.h"
using namespace NS_SLUA;

namespace
NS_SLUA
{
	using namespace std;

	template <class T>
	struct TLuaUtilityValue
	{
		static void Fill(T& Out, lua_State* L, int32 Index)
		{
			Out = LuaObject::checkValue<T>(L, Index);
		}
	};

	template <class T>
	struct TLuaUtilityEnumValue
	{
		static void Fill(T& Out, lua_State* L, int32 Index)
		{
			Out = LuaObject::checkEnumValue<T>(L, Index);
		}
	};

	template <class T>
	struct TLuaUtilityObject
	{
		static void Fill(T*& Out, lua_State* L, int32 Index)
		{
			Out = LuaObject::checkUD<T>(L, Index);
		}
	};

	template <class T>
	struct TLuaUtility : conditional_t<is_base_of_v<UObject, T> || is_same_v<UObject, T>, TLuaUtilityObject<T>, conditional_t<is_enum_v<T>, TLuaUtilityEnumValue<T>, TLuaUtilityValue<T>>>
	{
	};

#define PARSE_FROM(prop) if (!FCStringAnsi::Strcmp(Key, #prop)) { TLuaUtility<remove_pointer_t<decltype(remove_cvref_t<decltype(Result)>::prop)>>::Fill(Result.prop, L, -1); continue; }

	template <>
	FWorldWidgetParams2 LuaObject::checkValue<FWorldWidgetParams2>(lua_State* L, int p)
	{
		AutoStack As(L);
		luaL_checktype(L, p, LUA_TTABLE);
		FWorldWidgetParams2 Result;
		lua_pushnil(L);
		while (lua_next(L, 2) != 0)
		{
			const char* Key = lua_tostring(L, -2);
			{
				ON_SCOPE_EXIT { lua_pop(L, 1); };
				PARSE_FROM(ID);
				PARSE_FROM(WType);
				PARSE_FROM(Widget);
				PARSE_FROM(Alignment);
				PARSE_FROM(WorldOffset);
				PARSE_FROM(bVisible);
				PARSE_FROM(HiddenDistance);
				PARSE_FROM(SocketName);
				PARSE_FROM(RefActorID);
				PARSE_FROM(WorldPos);
				PARSE_FROM(LayerName);
				PARSE_FROM(ScreenConstrainType);
				PARSE_FROM(ScreenConstrainPadding);
				PARSE_FROM(ZorderOffSet);
				PARSE_FROM(WidgetType);
				PARSE_FROM(MaterialPath);
				PARSE_FROM(bEnableDistanceScale);
				PARSE_FROM(DistanceScaleCurveName);
				PARSE_FROM(RelativeOffset);
				PARSE_FROM(bNoDepth);
				PARSE_FROM(bVisibility);
				PARSE_FROM(DebugName);
				PARSE_FROM(GPUTurb);
			}
		}

		return MoveTemp(Result);
	}
#undef PARSE_FROM
}

TWeakPtr<SWorldWidget2> FWorldWidgetMap2::GetFreeWidget()
{
	TSharedPtr<SWorldWidget2> NewWidget;
	if (FreeWidgets.Num() > 0)
	{
		NewWidget = FreeWidgets.Pop();
	}
	else
	{
		NewWidget = SNew(SWorldWidget2);
	}
	SWorldWidget2* WidgetPtr = NewWidget.Get();
	UseWidgetMap.Add(WidgetPtr, NewWidget.ToSharedRef());
	return NewWidget;
}

void FWorldWidgetMap2::ReleaseWidget(SWorldWidget2* InWidget)
{
	TSharedRef<SWorldWidget2>* WidgetRef = UseWidgetMap.Find(InWidget);
	if (WidgetRef)
	{
		//这个组件没必要缓存的样子
		// FreeWidgets.Push(*WidgetRef);
		UseWidgetMap.Remove(&WidgetRef->Get());
	}
}

void FWorldWidgetMap2::Cleanup()
{
	UseWidgetMap.Empty();
	FreeWidgets.Empty();
}

UWorldWidgetManager2::UWorldWidgetManager2(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

#pragma region KGBasicManager
void UWorldWidgetManager2::NativeInit()
{
	GIPtr = Cast<UGameInstance>(GetOuter());
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "CreateWorldWidget", &UWorldWidgetManager2::CreateWorldWidget);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "DeleteWorldWidget", &UWorldWidgetManager2::DeleteWorldWidget);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "StopWorldWidget", &UWorldWidgetManager2::StopWorldWidget);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "RestoreWorldWidget", &UWorldWidgetManager2::RestoreWorldWidget);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "SetWorldWidgetPosition", &UWorldWidgetManager2::SetWorldWidgetPosition);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "SetWorldWidgetWorldOffset", &UWorldWidgetManager2::SetWorldWidgetWorldOffset);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "SetWorldWidgetUID", &UWorldWidgetManager2::SetWorldWidgetUID);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "SetWorldWidgetSocket", &UWorldWidgetManager2::SetWorldWidgetSocket);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "SetWorldWidgetWorldHideDistance", &UWorldWidgetManager2::SetWorldWidgetWorldHideDistance);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "SetFogShowDistance", &UWorldWidgetManager2::SetFogShowDistance);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "SetWorldWidgetNoDepth", &UWorldWidgetManager2::SetWorldWidgetNoDepth);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "ReverseLayerContainer", &UWorldWidgetManager2::ReverseLayerContainer);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "LoadOrGetCurve", &UWorldWidgetManager2::LoadOrGetCurve);
    REG_EXTENSION_METHOD(UWorldWidgetManager2, "SetLayerVisibility", &UWorldWidgetManager2::SetLayerVisibility);
	REG_EXTENSION_METHOD(UWorldWidgetManager2, "SetWorldWidgetVisibilty", &UWorldWidgetManager2::SetWorldWidgetVisibilty);
}

void UWorldWidgetManager2::NativeUninit()
{
	IsOnEdgeChanged.Clear();
	DirectionChanged.Clear();
	HiddenDistance.Clear();
	WWidgetLayers.Empty();
	WWidgetDataMap.Empty();
	WorldWidgetPool.Cleanup();
}
#pragma endregion KGBasicManager

#pragma region WidgetManager
int32 UWorldWidgetManager2::CreateWorldWidget(FWorldWidgetParams2 InParams)
{
	SCOPED_NAMED_EVENT(WorldWidgetManager2_CreateWorldWidget, FColor::Red);
	FWorldWidgetData2 WidgetData;

	TWeakPtr<SWorldWidget2> NewWidget = WorldWidgetPool.GetFreeWidget();
	if (!NewWidget.IsValid())
	{
		return 0;
	}
	InParams.ID = GenerateWorldWidgetID();
	if (InParams.MaterialPath.IsEmpty()) InParams.MaterialPath = DefaultMaterialPath;
	SWorldWidget2* WWidget = NewWidget.Pin().Get();
	if (!WWidget || !UKismetSystemLibrary::IsValid(InParams.Widget)) return 0;
	WWidget->DistanceScaleCurve = GetCurve(InParams.DistanceScaleCurveName);
	WWidget->WorldWidgetParams = InParams;
	WWidget->OnIsOnEdgeChanged.BindUObject(this, &UWorldWidgetManager2::OnIsOnEdgeChanged);
	WWidget->OnDirectionChanged.BindUObject(this, &UWorldWidgetManager2::OnDirectionChanged);
	WWidget->OnHiddenDistance.BindUObject(this, &UWorldWidgetManager2::OnHiddenDistance);
	WidgetData.ID = InParams.ID;
	WidgetData.LayerName = DefaultWWidgetLayerName;
	if (!InParams.LayerName.IsEmpty())
	{
		WidgetData.LayerName = InParams.LayerName;
	}

	WidgetData.WorldWidgetPtr = NewWidget;
	WidgetData.ChildWidget = InParams.Widget;

	if (!WidgetData.LayerName.IsEmpty())
	{
		TWeakPtr<FWorldWidgetLayer2> LayerPTR = GetWorldWidgetLayer(WidgetData.LayerName);
		if (TSharedPtr<FWorldWidgetLayer2> Layer = LayerPTR.Pin())
		{
			Layer->AddWorldWidget(InParams.Widget, WidgetData.ID, NewWidget, InParams.GPUTurb);
			bool bVisible = Layer->HasChildren();
			if (Layer->isInvisible != bVisible)
			{
				Layer->isInvisible = bVisible;
				Layer->AsWidget()->SetVisibility(bVisible ? EVisibility::SelfHitTestInvisible : EVisibility::Collapsed);
			}
		}
	}

	TSharedPtr<SWidget> WidgetPtr = InParams.Widget->TakeWidget();
	check(WidgetPtr.IsValid());
	WWidget->AttachChildWidget(WidgetPtr.ToSharedRef());

	WWidgetDataMap.Add(WidgetData.ID, WidgetData);
	return WidgetData.ID;
}

void UWorldWidgetManager2::SetWorldWidgetPosition(int32 ID, FVector NewPos)
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(ID);
	if (!WWidgetData) return;

	SWorldWidget2* WorldWidget = WWidgetData->WorldWidgetPtr.Pin().Get();
	if (!WorldWidget)
	{
		return;
	}
	WorldWidget->WorldWidgetParams.WorldPos = NewPos;
}

void UWorldWidgetManager2::SetWorldWidgetWorldOffset(int32 ID, FVector NewOffset)
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(ID);
	if (!WWidgetData) return;

	SWorldWidget2* WorldWidget = WWidgetData->WorldWidgetPtr.Pin().Get();
	if (!WorldWidget)
	{
		return;
	}
	WorldWidget->WorldWidgetParams.WorldOffset = NewOffset;
}



void UWorldWidgetManager2::SetWorldWidgetUID(int32 ID, uint64 NewUID)
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(ID);
	if (!WWidgetData) return;
	SWorldWidget2* WorldWidget = WWidgetData->WorldWidgetPtr.Pin().Get();
	if (!WorldWidget)
	{
		return;
	}
	WorldWidget->WorldWidgetParams.RefActorID = NewUID;
}



void UWorldWidgetManager2::SetWorldWidgetSocket(int32 ID, const FName& SocketName)
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(ID);
	if (!WWidgetData) return;

	SWorldWidget2* WorldWidget = WWidgetData->WorldWidgetPtr.Pin().Get();
	if (!WorldWidget)
	{
		return;
	}
	WorldWidget->WorldWidgetParams.SocketName = SocketName;
}

void UWorldWidgetManager2::SetWorldWidgetWorldHideDistance(int32 ID, float Distance) 
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(ID);
	if (!WWidgetData) return;

	SWorldWidget2* WorldWidget = WWidgetData->WorldWidgetPtr.Pin().Get();
	if (!WorldWidget)
	{
		return;
	}
	WorldWidget->WorldWidgetParams.HiddenDistance = Distance;
}

void UWorldWidgetManager2::SetWorldWidgetVisibilty(int32 ID, bool Visibilty)
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(ID);
	if (!WWidgetData) return;

	SWorldWidget2* WorldWidget = WWidgetData->WorldWidgetPtr.Pin().Get();
	if (!WorldWidget)
	{
		return;
	}
	WorldWidget->WorldWidgetParams.bVisibility = Visibilty;
}

void UWorldWidgetManager2::SetWorldWidgetNoDepth(int32 ID, bool NoDepth)
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(ID);
	if (!WWidgetData) return;
	
	if (!WWidgetData->LayerName.IsEmpty() && WWidgetData->WorldWidgetPtr.IsValid())
	{
		TWeakPtr<FWorldWidgetLayer2> LayerPTR = GetWorldWidgetLayer(WWidgetData->LayerName);
		if (TSharedPtr<FWorldWidgetLayer2> Layer = LayerPTR.Pin())
		{
			SWorldWidget2* WorldWidget = WWidgetData->WorldWidgetPtr.Pin().Get();
			WorldWidget->WorldWidgetParams.bNoDepth = NoDepth;
			Layer->SetWorldWidgetNoDepth(ID, WorldWidget,NoDepth);
		}
	}
}

void UWorldWidgetManager2::SetLayerVisibility(EWorldWidgetLayerType2 LayerType, bool bVisible)
{
    FString LayerName = StaticEnum<EWorldWidgetLayerType2>()->GetNameStringByValue(static_cast<int64>(LayerType));
    if (WWidgetLayers.Contains(LayerName))
    {
        WWidgetLayers[LayerName]->AsWidget()->SetVisibility(bVisible ? EVisibility::SelfHitTestInvisible : EVisibility::Collapsed);
    }
}

TWeakObjectPtr<UCurveFloat> UWorldWidgetManager2::GetCurve(const FName& CurveName)
{
	if (UCurveFloat** C = Curves.Find(CurveName))
	{
		return TWeakObjectPtr<UCurveFloat>(*C);
	}
	return TWeakObjectPtr<UCurveFloat>();
}

void UWorldWidgetManager2::LoadOrGetCurve(const FName& CurveName)
{
	UCurveFloat* NewCurve = LoadObject<UCurveFloat>(this, *CurveName.ToString());
	Curves.Add(CurveName, NewCurve);
}

void UWorldWidgetManager2::DeleteWorldWidget(int32 ID)
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(ID);
	if (!WWidgetData) return;

	if (!WWidgetData->LayerName.IsEmpty())
	{
		TWeakPtr<FWorldWidgetLayer2> LayerPTR = GetWorldWidgetLayer(WWidgetData->LayerName);
		if (TSharedPtr<FWorldWidgetLayer2> Layer = LayerPTR.Pin())
		{
			Layer->RemoveWorldWidget(ID);
			bool visible = Layer->HasChildren();
			if (Layer->isInvisible != visible)
			{
				Layer->isInvisible = visible;
				Layer->AsWidget()->SetVisibility(visible ? EVisibility::SelfHitTestInvisible : EVisibility::Collapsed);
			}
		}
	}

	if (WWidgetData->WorldWidgetPtr.IsValid())
	{
		WWidgetData->WorldWidgetPtr.Pin()->AttachChildWidget(SNullWidget::NullWidget);
		WWidgetData->WorldWidgetPtr.Pin()->OnIsOnEdgeChanged.Unbind();
		WWidgetData->WorldWidgetPtr.Pin()->OnDirectionChanged.Unbind();
		WWidgetData->WorldWidgetPtr.Pin()->Reset();
		WorldWidgetPool.ReleaseWidget(WWidgetData->WorldWidgetPtr.Pin().Get());
	}

	WWidgetData->Reset();

	WWidgetDataMap.Remove(ID);
}

void UWorldWidgetManager2::StopWorldWidget(int32 ID)
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(ID);
	if (!WWidgetData) return;

	if (!WWidgetData->LayerName.IsEmpty())
	{
		TWeakPtr<FWorldWidgetLayer2> LayerPTR = GetWorldWidgetLayer(WWidgetData->LayerName);
		if (TSharedPtr<FWorldWidgetLayer2> Layer = LayerPTR.Pin())
		{
			Layer->StopWorldWidget(ID);
			bool visible = Layer->HasChildren();
			if (Layer->isInvisible != visible)
			{
				Layer->isInvisible = visible;
				Layer->AsWidget()->SetVisibility(visible ? EVisibility::SelfHitTestInvisible : EVisibility::Collapsed);
			}
		}
	}
}

void UWorldWidgetManager2::RestoreWorldWidget(FWorldWidgetParams2 InParams)
{
	FWorldWidgetData2* WWidgetData = WWidgetDataMap.Find(InParams.ID);
	if (!WWidgetData) return;
	TSharedPtr<SWorldWidget2> WorldWidgetPtr = WWidgetData->WorldWidgetPtr.Pin();
	if (!WWidgetData->LayerName.IsEmpty() && WorldWidgetPtr)
	{
		InParams.GPUTurb = WorldWidgetPtr->WorldWidgetParams.GPUTurb;
		InParams.Widget = WorldWidgetPtr->WorldWidgetParams.Widget;
		WorldWidgetPtr->WorldWidgetParams = InParams;
		TWeakPtr<FWorldWidgetLayer2> LayerPTR = GetWorldWidgetLayer(WWidgetData->LayerName);
		if (TSharedPtr<FWorldWidgetLayer2> Layer = LayerPTR.Pin())
		{
			Layer->RestoreWorldWidget(InParams.ID);
			bool visible = Layer->HasChildren();
			if (Layer->isInvisible != visible)
			{
				Layer->isInvisible = visible;
				Layer->AsWidget()->SetVisibility(visible ? EVisibility::SelfHitTestInvisible : EVisibility::Collapsed);
			}
		}
	}
}

void UWorldWidgetManager2::SetParentLayer(UCanvasPanel* InParentLayer)
{
	ParentLayer = InParentLayer;
}

void UWorldWidgetManager2::OnIsOnEdgeChanged(int32 ID, bool bOnEdge) const
{
	if (!IsOnEdgeChanged.ExecuteIfBound(ID, bOnEdge))
	{
		UE_LOG(LogKGUI, Warning, TEXT("IsOnEdgeChanged is unbounded"));
	}
}

void UWorldWidgetManager2::OnDirectionChanged(int32 ID, const FVector2D& Dir) const
{
	if (!DirectionChanged.ExecuteIfBound(ID, Dir.X, Dir.Y))
	{
		UE_LOG(LogKGUI, Warning, TEXT("DirectionChanged is unbounded"));
	}
}

void UWorldWidgetManager2::OnHiddenDistance(int32 ID, bool bIsEnter)
{
	if (!HiddenDistance.ExecuteIfBound(ID, bIsEnter))
	{
		UE_LOG(LogKGUI, Warning, TEXT("HiddenDistance is unbounded"));
	}
}

void UWorldWidgetManager2::SetFogShowDistance(float Distance)
{
	FString LayerName = StaticEnum<EWorldWidgetLayerType2>()->GetNameStringByValue(static_cast<int64>(EWorldWidgetLayerType2::HeadInfo));
	TWeakPtr<FWorldWidgetLayer2> Layer = GetWorldWidgetLayer(LayerName);
	if (Layer.IsValid()) 
	{
		Layer.Pin()->SetFogShowDistance(Distance);
	}
}

void UWorldWidgetManager2::ReverseLayerContainer(FString InName, int32 Num)
{
	auto Layer = GetWorldWidgetLayer(InName);
	if(Layer.IsValid())
	{
		Layer.Pin()->ReserveContainer(Num);
	}
}

bool UWorldWidgetManager2::InitWorldWidgetLayer(EWorldWidgetLayerType2 InLayerType, int32 LayerZOrder, int Count)
{
	UWorld* ThisWorld = GetWorld();
	if (ThisWorld && ThisWorld->IsGameWorld())
	{
		if (UGameViewportClient* ViewportClient = ThisWorld->GetGameViewport())
		{
			TSharedPtr<IGameLayerManager> LayerManager = ViewportClient->GetGameLayerManager();
			if (LayerManager.IsValid())
			{
				ULocalPlayer* LocPlayer = nullptr;
				if (GIPtr.IsValid())
				{
					LocPlayer = GIPtr->GetFirstGamePlayer();
				}
				if (LocPlayer)
				{
					FLocalPlayerContext PlayerContext(LocPlayer, ThisWorld);
					FString LayerName = StaticEnum<EWorldWidgetLayerType2>()->GetNameStringByValue(static_cast<int64>(InLayerType));
					if (ParentLayer.IsValid())
					{
						TSharedPtr<SConstraintCanvas> Canvas = ParentLayer->GetCanvasWidget();
						if (Canvas.IsValid())
						{
							TSharedRef<FWorldWidgetLayer2> NewLayer = MakeShareable(new FWorldWidgetLayer2(PlayerContext, InLayerType));
							Canvas->AddSlot()
								.Anchors(FAnchors(0, 0, 1, 1))
								.ZOrder(LayerZOrder)
								[NewLayer->AsWidget()];
							WWidgetLayers.Add(LayerName, NewLayer);
							NewLayer->AsWidget()->SetVisibility(EVisibility::Collapsed);
							NewLayer->EnableSmoothPosition(bEnableSmoothPosition, InnerSmoothRange, OuterSmoothRange, SmoothSpeed);
							return true;
						}
						UE_LOG(LogKGUI, Error, TEXT("No Canvas in %s"), *ParentLayer->GetPathName());
					}
				}
			}
		}
	}

	return false;
}

int32 UWorldWidgetManager2::GenerateWorldWidgetID()
{
	static int32 Index = 0;

	++Index;
	if (Index >= MAX_int32)
	{
		Index = 1;
	}

	return Index;
}

TWeakPtr<FWorldWidgetLayer2> UWorldWidgetManager2::GetWorldWidgetLayer(FString InName)
{
	if (TSharedRef<FWorldWidgetLayer2>* WWLayer = WWidgetLayers.Find(InName))
	{
		return *WWLayer;
	}

	return nullptr;
}

FString UWorldWidgetManager2::GetWorldWidgetLayerNameByEnum(EWorldWidgetLayerType2 InLayerType)
{
    return StaticEnum<EWorldWidgetLayerType2>()->GetNameStringByValue(static_cast<int64>(InLayerType));
}

int64 UWorldWidgetManager2::GetWorldWidgetLayerTypeByName(const FString& InLayerName)
{
    return StaticEnum<EWorldWidgetLayerType2>()->GetValueByNameString(InLayerName);
}

void UWorldWidgetManager2::EnableSmoothPosition(bool bEnable, float InnerRange, float OuterRange, float InterpSpeed)
{
	bEnableSmoothPosition = bEnable;
	InnerSmoothRange = InnerRange;
	OuterSmoothRange = OuterRange;
	SmoothSpeed = InterpSpeed;

	for (TTuple<FString, TSharedRef<FWorldWidgetLayer2>>& Layer : WWidgetLayers)
	{
		TSharedRef<FWorldWidgetLayer2> L = Layer.Value;

		L->EnableSmoothPosition(bEnableSmoothPosition, InnerSmoothRange, OuterSmoothRange, SmoothSpeed);
	}
}

void UWorldWidgetManager2::CreateWorldWidgetLayer(EWorldWidgetLayerType2 InLayerType, int32 InDepth)
{
	InitWorldWidgetLayer(InLayerType, InDepth);
}

#pragma endregion WidgetManager
