#include "C7/WorldWidget2/WorldWidget2.h"
#include "Core/Common.h"
#include "Curves/CurveFloat.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Slate/SRetainerWidget.h"
#include "Widgets/Layout/SBox.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Util/KGUtils.h"
#include "Engine/SkeletalMeshSocket.h"
#include "3C/Core/C7ActorInterface.h"
SLATE_IMPLEMENT_WIDGET(SWorldWidget2)

void SWorldWidget2::PrivateRegisterAttributes(FSlateAttributeInitializer& AttributeInitializer)
{
}

void SWorldWidget2::AttachChildWidget(TSharedRef<SWidget> InWidget)
{
	SCOPED_NAMED_EVENT(SWorldWidget2_AttachChildWidget, FColor::Blue);
	WidgetPrt = InWidget;

	if (ContainerSWidget.IsValid())
	{
		ClearChildren();
	}
	AddSlot()[SAssignNew(ContainerSWidget, SBox)
		[
			InWidget
		]];
}

void SWorldWidget2::RemoveChildWidget()
{
	ClearChildren();
}

void SWorldWidget2::Reset()
{
	ClearChildren();
	WidgetPrt.Reset();
	ContainerSWidget = nullptr;
	ResetData();
}

void SWorldWidget2::ResetData()
{
	lastPosition.SetIdentity();
	bIsOnEdge = false;
	IsInShowDist.Reset();
	TargetAlpha = 0;
	CurrentAlpha = 0;
}

float SWorldWidget2::GetShowAlpha(float InDeltaTime)
{
	if (!FMath::IsNearlyEqual(CurrentAlpha, TargetAlpha))
	{
		CurrentAlpha = FMath::FInterpTo(CurrentAlpha, TargetAlpha, InDeltaTime, FadeSpeed);
	}
	return CurrentAlpha;
}

void SWorldWidget2::SetTargetAlpha(float InAlpha)
{
	TargetAlpha = InAlpha;
}

void SWorldWidget2::Construct(const SWorldWidget2::FArguments& InArgs)
{
	Children.Reserve(InArgs._Slots.Num());
	for (const FSlot::FSlotArguments& Arg : InArgs._Slots)
	{
		const FSlotBase::FSlotArguments& ChildSlotArgument = static_cast<const FSlotBase::FSlotArguments&>(Arg);
		const SBoxPanel::FSlot::FSlotArguments& BoxSlotArgument = static_cast<const SBoxPanel::FSlot::FSlotArguments&>(ChildSlotArgument);
		Children.AddSlot(MoveTemp(const_cast<SBoxPanel::FSlot::FSlotArguments&>(BoxSlotArgument)));
	}
}

void SWorldWidget2::SetIsOnEdge(const int32 ID, bool bInIsOnEdge)
{
	if (bIsOnEdge != bInIsOnEdge)
	{
		bIsOnEdge = bInIsOnEdge;
		if (OnIsOnEdgeChanged.IsBound())
		{
			OnIsOnEdgeChanged.Execute(ID, bInIsOnEdge);
		}
	}
}

void SWorldWidget2::SetDirection(const int32 ID, FVector2D& Dir)
{
	if (OnDirectionChanged.IsBound())
	{
		OnDirectionChanged.Execute(ID, Dir);
	}
}

void SWorldWidget2::SetIsInHiddenDistance(const int32 ID, bool IsInDist)
{
	// 如果IsInShowDist未设置，或者值发生了变化
	if (!IsInShowDist.IsSet() || IsInShowDist.GetValue() != IsInDist)
	{
		IsInShowDist = IsInDist;

		if (OnHiddenDistance.IsBound())
		{
			OnHiddenDistance.Execute(ID, IsInShowDist.GetValue());
		}
	}
}

void SWorldWidget2::SetScale(float Scale)
{
	if (ContainerSWidget.IsValid())
	{
		// BEGIN ADD BY lishihao07@kuaishou.com: GPUTurbo HeadInfo UI
		if(bHasGPUTurboWidget)
		{
			//only record the scale, apply with translation later
			ScaleForGPUTurbo = Scale;
		}
		else
		// END ADD BY lishihao07@kuaishou.com: GPUTurbo HeadInfo UI
		{
			SetRenderTransform(FSlateRenderTransform(FScale2D(Scale, Scale)));
			SetRenderTransformPivot(FVector2D(WorldWidgetParams.Alignment.X, WorldWidgetParams.Alignment.Y));
		}
	}
}

void SWorldWidget2::SetDistance(float Distance)
{
	if (WorldWidgetParams.bEnableDistanceScale && DistanceScaleCurve.IsValid())
	{
		float Scale = DistanceScaleCurve->GetFloatValue(Distance);
		SetScale(Scale);
	}
	else
	{
		SetScale(1);
	}
}

FTransform SWorldWidget2::GetTransform()
{
	AActor* Actor = KGUtils::GetActorByID(WorldWidgetParams.RefActorID);
	if (!IsValid(Actor))
	{
		if (WorldWidgetParams.WorldPos != FVector::ZeroVector)
		{
			lastPosition.SetLocation(WorldWidgetParams.WorldPos);
		}
		return lastPosition;
	}
	
	IC7ActorInterface* c7ActorInterface = Cast<IC7ActorInterface>(Actor);

	//For BriefActor
	if (c7ActorInterface && c7ActorInterface->IsBriefActor() && c7ActorInterface->GetBriefActorTransform())
	{
		lastPosition = *c7ActorInterface->GetBriefActorTransform();
		return lastPosition;
	}
	
	USkeletalMeshComponent* Mesh = nullptr;
	if (!WorldWidgetParams.SocketName.IsNone() && c7ActorInterface)
	{
		if (Mesh == nullptr) Mesh = c7ActorInterface->GetMainMesh();
		if (Mesh && Mesh->GetSkeletalMeshAsset())
		{
			int32 Index = Mesh->GetBoneIndex(WorldWidgetParams.SocketName);
			if (Index == INDEX_NONE) 
			{
				const USkeletalMeshSocket* SkelMeshSocket = Mesh->GetSocketByName(WorldWidgetParams.SocketName);
				if (SkelMeshSocket)
				{
					lastPosition = SkelMeshSocket->GetSocketTransform(Mesh);
					return lastPosition;
				}
			}
			else 
			{
				lastPosition = Mesh->GetBoneTransform(Index);
				return lastPosition;
			}
		}
	}
	
	lastPosition = Actor->GetTransform();
	return lastPosition;
}
