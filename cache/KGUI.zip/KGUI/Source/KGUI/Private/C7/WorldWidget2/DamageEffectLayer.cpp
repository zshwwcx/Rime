#include "C7/WorldWidget2/DamageEffectLayer.h"

#include "SceneView.h"
#include "SlateSettings.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Util/KGUtils.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "Components/SkeletalMeshComponent.h"
#include "Core/Common.h"
#include "Engine/GameViewportClient.h"
#include "Engine/SkeletalMeshSocket.h"
#include "EntitySystem/MovieSceneEntityManager.h"
#include "Fonts/FontMeasure.h"
#include "Framework/Application/SlateApplication.h"
#include "GameFramework/Pawn.h"
#include "Widgets/SInvalidationPanel.h"

bool GKGDmgEffectLayerArrangeOp = true;
static FAutoConsoleVariableRef CVarKGDmgEffectLayerArrangeOp(
    TEXT("KGUI.DamageEffectLayerUsingArrangeOp"),
    GKGDmgEffectLayerArrangeOp,
    TEXT("True enables optimize algorithm for damage effect layer arrange children.")
);

int32 GKGDamageTextItemPoolSize = 256;
static FAutoConsoleVariableRef CVarKGDamageTextItemPoolSize(
    TEXT("KGUI.DamageTextItemPoolSize"),
    GKGDamageTextItemPoolSize,
    TEXT("The size of damage text item pool.")
);

UE_TRACE_EVENT_BEGIN(Cpu, SDamageEffectCanvasArrangChildren, NoSync)
UE_TRACE_EVENT_FIELD(int32, ActiveChildrenCount)
UE_TRACE_EVENT_END()

UE_TRACE_EVENT_BEGIN(Cpu, SDamageEffectLayerPaint, NoSync)
UE_TRACE_EVENT_FIELD(int32, DamageTextCount)
UE_TRACE_EVENT_END()

UE_TRACE_EVENT_BEGIN(Cpu, SDamageEffectLayerTick, NoSync)
UE_TRACE_EVENT_FIELD(int32, DamageTextCount)
UE_TRACE_EVENT_END()

struct FDamageTextItemSorter
{
    bool operator()(const SWorldWidgetDamageEffectLayer::FDamageTextItem& A, const SWorldWidgetDamageEffectLayer::FDamageTextItem& B) const
    {
        return A.ZOrder < B.ZOrder;
    }
};


FVector2D SWorldWidgetDamageEffectLayer::FDamageTextItem::GetDmgValTextSize(float InLayoutScaleMultiplierValue)
{
    if (!LayoutScaleMultiplierValue.IsSet()
        ||!FMath::IsNearlyEqual(InLayoutScaleMultiplierValue, LayoutScaleMultiplierValue.Get(-1.f)) 
        || DmgValSize.X < 0 || DmgSignSize.Y < 0)
    {
        LayoutScaleMultiplierValue = InLayoutScaleMultiplierValue;
        const float LocalOutLineSize = Style.Font.OutlineSettings.OutlineSize;
        if (FSlateApplication::Get().GetRenderer())
        {
            DmgValSize = FSlateApplication::Get().GetRenderer()->GetFontMeasureService()->Measure(DmgStr, Style.Font, InLayoutScaleMultiplierValue);
        }
        else
        {
            UE_LOG(LogKGUI, Error, TEXT("FSlateApplication::Get().GetRenderer() is nullptr, cannot measure damage text length, the length of damage text will be fallback length: (100, 30)"));
            DmgValSize.X = 100;
            DmgValSize.Y = 30;
        }
        DmgValSize.X += LocalOutLineSize * 2;
        DmgValSize.Y += LocalOutLineSize;
    }
    
    return DmgValSize;
}

FVector2D SWorldWidgetDamageEffectLayer::FDamageTextItem::GetDmgSignTextSize(float InLayoutScaleMultiplierValue)
{
    if (SignStr.IsEmpty())
    {
        return FVector2D::ZeroVector;
    }
    
    if (!LayoutScaleMultiplierValue.IsSet()
        || !FMath::IsNearlyEqual(InLayoutScaleMultiplierValue, LayoutScaleMultiplierValue.Get(-1.f)) 
        || DmgSignSize.X < 0 || DmgSignSize.Y < 0)
    {
        LayoutScaleMultiplierValue = InLayoutScaleMultiplierValue;
        const float LocalOutLineSize = Style.Font.OutlineSettings.OutlineSize;
        FStringView SignText = SignStr;
        if (FSlateApplication::Get().GetRenderer())
        {
            DmgSignSize = FSlateApplication::Get().GetRenderer()->GetFontMeasureService()->Measure(SignText, Style.Font, InLayoutScaleMultiplierValue);
        }
        else
        {
            UE_LOG(LogKGUI, Error, TEXT("FSlateApplication::Get().GetRenderer() is nullptr, cannot measure damage text sign length, the length of damage text sign will be fallback length: (17, 30)"));
            DmgValSize.X = 17;
            DmgValSize.Y = 30;
        }
        DmgSignSize.X += LocalOutLineSize * 2;
        DmgSignSize.Y += LocalOutLineSize;
    }
    
    return DmgSignSize;
}

uint32 SWorldWidgetDamageEffectLayer::FDamageTextItem::GenerateToken()
{
    static uint32 Token_Counter = 0;
    
    if (Token == INVALID_TOKEN)
    {
        Token_Counter = (++Token_Counter) % 0x7FFFFFFE;
        Token = Token_Counter;
    }
    
    return Token;
}

SWorldWidgetDamageEffectLayer::FDamageTextItem SWorldWidgetDamageEffectLayer::NullDamageText;

SWorldWidgetDamageEffectLayer::FDamageTextItem& SWorldWidgetDamageEffectLayer::FDamageTextItemPool::Obtain()
{
    if (!FreeSlots.IsEmpty())
    {
        int32 Index = INVALID_TOKEN;
        if (FreeSlots.Dequeue(Index))
        {
            check(Pool.IsValidIndex(Index))
           FDamageTextItem& Item = Pool[Index];
            Item.PoolSlotIndex = Index;
            Item.GenerateToken();
            return Item;
        }
    }
            
    if (LastValidIndex >= Pool.Num())
    {
        UE_LOG(LogKGUI, Error, TEXT("SWorldWidgetDamageEffectLayer::FDamageTextItemPool::Obtain() Pool is full, cannot allocate more damage text item"));
        return NullDamageText;
    }
            
    FDamageTextItem& Item = Pool[LastValidIndex];
    Item.PoolSlotIndex = LastValidIndex;
    Item.GenerateToken();
    LastValidIndex++;
    return Item;
}

void SWorldWidgetDamageEffectLayer::Construct(const FArguments& InArgs, const FLocalPlayerContext& InPlayerContext)
{
    PlayerContext = InPlayerContext;
    bCanSupportFocus = false;
    bUseSceneDepth = InArgs._UseSceneDepth.Get();
    LayerType = InArgs._LayerType.Get();
    DamageTextItemsPool.Init(GKGDamageTextItemPoolSize);
}

void SWorldWidgetDamageEffectLayer::AddWorldWidget(UUserWidget* UserWidget, int32 ID, TSharedRef<SWorldWidget2> NewWidget, UGPUTurboInvalidationBox* GPUTurbo)
{
	
}

void SWorldWidgetDamageEffectLayer::RemoveWorldWidget(int32 ID)
{
	
}

void SWorldWidgetDamageEffectLayer::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
    UE_TRACE_LOG_SCOPED_T(Cpu, SDamageEffectLayerTick, CpuChannel) << SDamageEffectLayerTick.DamageTextCount(ActivatedDamageTextItems.Num());
    APlayerController* PlayerController = PlayerContext.GetPlayerController();
    if (!PlayerController || !PlayerController->GetWorld())
    {
        return;
    }
    
    APawn* Pawn = PlayerController->GetPawn();
    if (Pawn == nullptr)
    {
        return;
    }

    UGameViewportClient* ViewportClient = PlayerController->GetWorld()->GetGameViewport();
    if (!ViewportClient)
    {
        return;
    }
    
    const FGeometry& ViewportGeometry = ViewportClient->GetGameLayerManager()->GetViewportWidgetHostGeometry();
    FSceneViewProjectionData ProjectionData;
    FMatrix ViewProjectionMatrix;
    bool bHasProjectionData = false;

    if (const auto* const LP = PlayerController->GetLocalPlayer())
    {
        bHasProjectionData = LP->GetProjectionData(ViewportClient->Viewport, /*out*/ ProjectionData);
        if (bHasProjectionData)
        {
            ViewProjectionMatrix = ProjectionData.ComputeViewProjectionMatrix();
        }
    }

    if (!bHasProjectionData)
    {
        for (auto Pair : ActivatedDamageTextItems)
        {
            if (Pair.Value && Pair.Value->CanTick())
            {
                Pair.Value->AppendVisibilityFlag(DTVisFlag_HideByNoProjData);
            }
        }
        return;
    }

    FProjectContext ProjectContext(PlayerController, ProjectionData, ViewProjectionMatrix, ViewportGeometry, Pawn->GetActorLocation());
    for (auto Pair : ActivatedDamageTextItems)
    {
        if (Pair.Value && Pair.Value->CanTick())
        {
            Pair.Value->RemoveVisibilityFlag(DTVisFlag_HideByNoProjData);
            DoProjectAndCulling(*Pair.Value, ProjectContext, AllottedGeometry, InDeltaTime);
        }
    }
}

int32 SWorldWidgetDamageEffectLayer::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
    UE_TRACE_LOG_SCOPED_T(Cpu, SDamageEffectLayerPaint, CpuChannel) << SDamageEffectLayerPaint.DamageTextCount(DamageTextItemsHeap.Num());
    
    TArray<FDamageTextItem*, TInlineAllocator64<100>> CopyData;
    CopyData.Reserve(DamageTextItemsHeap.Num());
    CopyData.Append(DamageTextItemsHeap);

    while (!CopyData.IsEmpty())
    {
        FDamageTextItem* TextItem = nullptr;
        CopyData.HeapPop(TextItem, FDamageTextItemSorter(), EAllowShrinking::No);
        if (TextItem && TextItem->IsVisible())
        {
            PaintDamageText(*TextItem, Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
        }
    }
    
    return LayerId + 1;
    
}

#pragma region DamageTextItem
bool SWorldWidgetDamageEffectLayer::IsNull(const FDamageTextItem& InItem)
{
    return &InItem == &NullDamageText;
}

bool SWorldWidgetDamageEffectLayer::IsNull(const FDamageTextItem* InItem)
{
    return InItem == &NullDamageText;
}

void SWorldWidgetDamageEffectLayer::PaintDamageText(FDamageTextItem& InItem, const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
    const float LayoutScaleMultiplier = GetPrepassLayoutScaleMultiplier();
    const FLinearColor LocalShadowColor = InItem.Style.ShadowColorAndOpacity;
    const FVector2D ShadowOffset = InItem.Style.ShadowOffset * InItem.Scale * LayoutScaleMultiplier;
    const bool bShouldDropShadow = LocalShadowColor.A > 0.f && ShadowOffset.SizeSquared() > 0.f;
    const bool bShouldBeEnabled = ShouldBeEnabled(bParentEnabled);
    
    FSlateFontInfo LocalFont = InItem.Style.Font;
    FString LocalText = FString::FromInt(InItem.DamageValue);
    
    FVector2D SignTextSize = InItem.GetDmgSignTextSize(1);
    FVector2D DmgTextSize = InItem.GetDmgValTextSize(1);
    FVector2D TextSize = SignTextSize + DmgTextSize;
    FVector2D LocationOffset = InItem.ActorPosOnLayer - TextSize * 0.5;
    
    FSlateRenderTransform RenderTransform(TScale2<float>(InItem.Scale), InItem.Location);
    
    const auto RenderPivot = UE::Slate::FDeprecateVector2DParameter::One() * 0.5;
    bool bHasSign = !InItem.SignStr.IsEmpty();
        
    FVector2D Offset = LocationOffset;
    Offset.X += SignTextSize.X;
    
    // draw shadow
    if (bShouldDropShadow)
    {
        FLinearColor Color = InWidgetStyle.GetColorAndOpacityTint() * LocalShadowColor;
        Color.A *= InItem.Opacity;
        
        const int32 OutlineSize = LocalFont.OutlineSettings.OutlineSize;
        if (!LocalFont.OutlineSettings.bApplyOutlineToDropShadows)
        {
            LocalFont.OutlineSettings.OutlineSize = 0;
        }
        
        // draw sign shadow
        if (bHasSign)
        {
            FGeometry SignShadowGeometry = AllottedGeometry.MakeChild(
                SignTextSize, 
                FSlateLayoutTransform(1, LocationOffset + ShadowOffset), 
                RenderTransform, RenderPivot);
            
            FSlateDrawElement::MakeText(
                OutDrawElements, 
                LayerId, 
                SignShadowGeometry.ToPaintGeometry(), 
                InItem.SignStr, 
                LocalFont, 
                bShouldBeEnabled ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect, 
                Color);
        }
        
        // draw damage value shadow
        FGeometry DmgShadowGeometry = AllottedGeometry.MakeChild(
            DmgTextSize, 
            FSlateLayoutTransform(1, Offset + ShadowOffset), 
            RenderTransform, RenderPivot);
        FSlateDrawElement::MakeText(
            OutDrawElements, 
            LayerId, 
            DmgShadowGeometry.ToPaintGeometry(), 
            InItem.DmgStr, 
            LocalFont, 
            bShouldBeEnabled ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect,
            Color);

        // Restore outline size for main text
        LocalFont.OutlineSettings.OutlineSize = OutlineSize;
        
        ++LayerId;
    }
    
    FLinearColor TintColor = InWidgetStyle.GetColorAndOpacityTint() * InItem.Style.ColorAndOpacity.GetColor(InWidgetStyle);
    TintColor.A *= InItem.Opacity;

    // Draw the sign text itself
    if (bHasSign)
    {
        auto SignGeometry = AllottedGeometry.MakeChild(
            SignTextSize, 
            FSlateLayoutTransform(1, LocationOffset), 
            RenderTransform, RenderPivot);
        FSlateDrawElement::MakeText(
            OutDrawElements, 
            LayerId, 
            SignGeometry.ToPaintGeometry(), 
            InItem.SignStr, 
            LocalFont, 
            bShouldBeEnabled ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect, 
            TintColor);
    }
    
    // Draw the damage value text itself
    FGeometry DmgGeometry = AllottedGeometry.MakeChild(
        DmgTextSize, FSlateLayoutTransform(1, Offset),
        RenderTransform, RenderPivot);
    FSlateDrawElement::MakeText(
        OutDrawElements, 
        LayerId, 
        DmgGeometry.ToPaintGeometry(), 
        InItem.DmgStr, 
        LocalFont, 
        bShouldBeEnabled ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect, 
        TintColor);
}

void SWorldWidgetDamageEffectLayer::DoProjectAndCulling(FDamageTextItem& InItem, const FProjectContext& ProjectContext, const FGeometry& AllottedGeometry, const float InDeltaTime)
{
    FTransform ActorTransform = GetActorTransform(InItem.RefActorID, InItem.SocketName, InItem.WorldPos);
    FVector WorldLocation = ActorTransform.GetLocation();
    FVector PlayerControllerPos = ProjectContext.PlayerControllerPos;

    bool bLastVisible = InItem.IsVisible();
    bool bProjected = false;
    FVector2D ScreenPosition2D = FVector2D::ZeroVector;
    float Dist = FVector::Dist(PlayerControllerPos, WorldLocation);
    if (FogShowDistance > 0)
    {
        if (Dist >= FogShowDistance)
        {
            InItem.AppendVisibilityFlag(DTVisFlag_HideByFogDistCheck);
        }
        else
        {
            InItem.RemoveVisibilityFlag(DTVisFlag_HideByFogDistCheck);
        }
    }
    else
    {
        if (HiddenDistance > -1.0)
        {
            InItem.AppendVisibilityFlag(EDamageTextVisFlag::DTVisFlag_HideByDistCheck);
        }
        else
        {
            InItem.RemoveVisibilityFlag(DTVisFlag_HideByDistCheck);
        }
    }

    if (!InItem.HasAnyVisibilityFlags(DTVisFlag_HideByOuterLogic))
    {
        bProjected = FSceneView::ProjectWorldToScreen(WorldLocation, ProjectContext.ProjData.GetConstrainedViewRect(), ProjectContext.ViewProjMat, ScreenPosition2D);
    }

    if (bProjected)
    {
        InItem.RemoveVisibilityFlag(DTVisFlag_HideByProjFailed);
        double ProjectionScale = 1;
        if (APlayerCameraManager* CameraManager = ProjectContext.PlayerController.IsValid() ? ProjectContext.PlayerController->PlayerCameraManager : nullptr)
        {
            FVector CameraForwardVector = CameraManager->GetActorForwardVector();
            FVector DirectionToTarget = (WorldLocation - ProjectContext.ProjData.ViewOrigin).GetSafeNormal();
            ProjectionScale = FVector::DotProduct(CameraForwardVector, DirectionToTarget);
        }
        const float ViewportDist = FVector::Dist(ProjectContext.ProjData.ViewOrigin, WorldLocation) * ProjectionScale;

        const FVector2D RoundedPosition2D(FMath::RoundToInt(ScreenPosition2D.X), FMath::RoundToInt(ScreenPosition2D.Y));
        FVector2D ViewportPosition2D;

        USlateBlueprintLibrary::ScreenToViewport(ProjectContext.PlayerController.Get(), RoundedPosition2D, ViewportPosition2D);
        bool bIsNewProject = InItem.IsVisible() && bLastVisible == false;

        FVector ViewportPosition(ViewportPosition2D.X, ViewportPosition2D.Y, ViewportDist);
        FVector2D AbsoluteProjectedLocation = ProjectContext.ViewportGeometry.LocalToAbsolute(FVector2D(ViewportPosition.X, ViewportPosition.Y));
        FVector2D LocalPosition = AllottedGeometry.AbsoluteToLocal(AbsoluteProjectedLocation);
        
        FVector2D OldPos = InItem.ActorPosOnLayer;
        FVector2D NewPos = LocalPosition;
        if (!bIsNewProject && bEnableSmoothPosition)
        {
            NewPos = SmoothPosition(NewPos, OldPos, InDeltaTime, InnerSmoothRange, OuterSmoothRange, SmoothSpeed);
        }

        InItem.ActorPosOnLayer = NewPos;
    }
    else
    {
        InItem.AppendVisibilityFlag(DTVisFlag_HideByProjFailed);
    }
}

FTransform SWorldWidgetDamageEffectLayer::GetActorTransform(uint64 ActorObjID, FName SocketName, const FVector& DefaultPos)
{
    FTransform Transform;
    AActor* Actor = KGUtils::GetActorByID(ActorObjID);
    if (!IsValid(Actor))
    {
        if (DefaultPos != FVector::ZeroVector)
        {
            Transform.SetLocation(DefaultPos);
        }
        return Transform;
    }
	
    IC7ActorInterface* c7ActorInterface = Cast<IC7ActorInterface>(Actor);

    //For BriefActor
    if (c7ActorInterface && c7ActorInterface->IsBriefActor() && c7ActorInterface->GetBriefActorTransform())
    {
        Transform = *c7ActorInterface->GetBriefActorTransform();
        return Transform;
    }

    if (!SocketName.IsNone() && c7ActorInterface)
    {
        if (const USkeletalMeshComponent* Mesh  = c7ActorInterface->GetMainMesh(); Mesh && Mesh->GetSkeletalMeshAsset())
        {
            int32 Index = Mesh->GetBoneIndex(SocketName); 
            if (Index == INDEX_NONE) 
            {
                if (const USkeletalMeshSocket* SkelMeshSocket = Mesh->GetSocketByName(SocketName))
                {
                    Transform = SkelMeshSocket->GetSocketTransform(Mesh);
                    return Transform;
                }
            }
            else 
            {
                Transform = Mesh->GetBoneTransform(Index);
                return Transform;
            }
        }
    }
	
    Transform = Actor->GetTransform();
    return Transform;
}

SWorldWidgetDamageEffectLayer::FDamageTextItem& SWorldWidgetDamageEffectLayer::GetDamageTextItem(int32 InToken)
{
    if (auto* TextItem = ActivatedDamageTextItems.Find(InToken))
    {
        return *(*TextItem);
    }
    
    return NullDamageText;
}

const SWorldWidgetDamageEffectLayer::FDamageTextItem& SWorldWidgetDamageEffectLayer::GetDamageTextItem(int32 InToken) const
{
    if (const auto* TextItem = ActivatedDamageTextItems.Find(InToken))
    {
        return *(*TextItem);
    }
    
    return NullDamageText;
}

int32 SWorldWidgetDamageEffectLayer::ShowDamageText(int64 RefActorID, int32 InDamageValue, const FString& InDamageValStr, const FDamageTextStyle& InStyle, int32 InSign, FName InSocketName)
{
    FDamageTextItem& Item = DamageTextItemsPool.Obtain();
    if (IsNull(Item))
    {
        return INVALID_TOKEN;
    }
    
    check(Item.Token != INVALID_TOKEN);
    check(!ActivatedDamageTextItems.Contains(Item.Token));
    ActivatedDamageTextItems.Emplace(Item.Token, &Item);
    DamageTextItemsHeap.HeapPush(&Item, FDamageTextItemSorter());
    
    Item.RefActorID = RefActorID;
    Item.Style = InStyle;
    Item.SocketName = InSocketName;
    Item.DamageValue = InDamageValue;
    Item.DmgStr = InDamageValStr;
    
    Item.GetDmgSignTextSize(GetPrepassLayoutScaleMultiplier());
    Item.GetDmgValTextSize(GetPrepassLayoutScaleMultiplier());
    
    SetVisibility(HasChildren() ? EVisibility::HitTestInvisible : EVisibility::Collapsed);
    
    return Item.Token;
}

void SWorldWidgetDamageEffectLayer::RemoveDamageText(int32 InToken, bool bRebuildHeap)
{
    FDamageTextItem& TextItem = GetDamageTextItem(InToken);
    if (IsNull(TextItem) || !TextItem.IsValid())
    {
        return;
    }
    
    ActivatedDamageTextItems.Remove(InToken);
    if (!bRebuildHeap)
    {
        DamageTextItemsHeap.RemoveSingle(&TextItem);
    }
    else
    {
        for (int32 Index = 0; Index < DamageTextItemsHeap.Num(); Index++)
        {
            if (DamageTextItemsHeap[Index] == &TextItem)
            {
                DamageTextItemsHeap.HeapRemoveAt(Index, FDamageTextItemSorter(), EAllowShrinking::No);
                break;
            }
        }
    }
    
    DamageTextItemsPool.Recycle(TextItem);
    SetVisibility(HasChildren() ? EVisibility::HitTestInvisible : EVisibility::Collapsed);
}

bool SWorldWidgetDamageEffectLayer::UpdateDamageText(int32 InToken, const FVector2D& InLocation, const FVector2D& InScale, float InOpacity,  bool bVisible, bool bCanTick)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid())
    {
        TextItem.Location = InLocation;
        TextItem.Scale = InScale;
        TextItem.Opacity = InOpacity;
        if (bVisible)
        {
            TextItem.RemoveVisibilityFlag(DTVisFlag_HideByOuterLogic);
        }
        else
        {
            TextItem.AppendVisibilityFlag(DTVisFlag_HideByOuterLogic);
        }
        
        TextItem.bCanTick = bCanTick;
        return true;
    }
    
    return false;
}

void SWorldWidgetDamageEffectLayer::SetDamageTextFontStyle(int32 InToken, const FDamageTextStyle& InStyle)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid())
    {
        TextItem.Style = InStyle;
    }
}

void SWorldWidgetDamageEffectLayer::SetDamageTextLocation(int32 InToken, const FVector2D& Location)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid())
    {
        TextItem.Location = Location;
    }
}

void SWorldWidgetDamageEffectLayer::SetDamageTextScale(int32 InToken, const FVector2D& Scale)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid())
    {
        TextItem.Scale = Scale;
    }
}

void SWorldWidgetDamageEffectLayer::SetDamageTextOpacity(int32 InToken, float InOpacity)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid())
    {
        TextItem.Opacity = InOpacity;
    }
}

void SWorldWidgetDamageEffectLayer::SetDamageTextVisibility(int32 InToken, bool bVisible)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid())
    {
        if (bVisible)
        {
            TextItem.RemoveVisibilityFlag(DTVisFlag_HideByOuterLogic);
        }
        else
        {
            TextItem.AppendVisibilityFlag(DTVisFlag_HideByOuterLogic);
        }
    }
}

void SWorldWidgetDamageEffectLayer::SetDamageTextCanTick(int32 InToken, bool bCanTick)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid())
    {
        TextItem.bCanTick = bCanTick;
    }
}

void SWorldWidgetDamageEffectLayer::SetDamageTextZOrder(int32 InToken, int32 InZOrder)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid() && TextItem.ZOrder != InZOrder)
    {
        TextItem.ZOrder = InZOrder;
        DamageTextItemsHeap.Heapify(FDamageTextItemSorter());
    }
}

void SWorldWidgetDamageEffectLayer::SetDamageTextRefActorID(int32 InToken, uint64 InActorID)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid())
    {
        TextItem.RefActorID = InActorID;
    }
}

void SWorldWidgetDamageEffectLayer::SetDamageTextSocketName(int32 InToken, FName InSocketName)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid() && TextItem.SocketName != InSocketName)
    {
        TextItem.SocketName = InSocketName;
    }
}

void SWorldWidgetDamageEffectLayer::SetDamageTextWorldPos(int32 InToken, const FVector& InWorldPos)
{
    auto& TextItem = GetDamageTextItem(InToken);
    if (!IsNull(TextItem) && TextItem.IsValid())
    {
        TextItem.WorldPos = InWorldPos;
    }
}

void SWorldWidgetDamageEffectLayer::RebuildDamageTextItemsHeap()
{
    DamageTextItemsHeap.Heapify(FDamageTextItemSorter());
}

#pragma endregion
