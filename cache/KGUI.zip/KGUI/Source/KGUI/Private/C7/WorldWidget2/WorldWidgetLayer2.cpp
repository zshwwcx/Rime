#include "C7/WorldWidget2/WorldWidgetLayer2.h"
#include "C7/WorldWidget2/HeadInfoLayer2.h"
#include "C7/WorldWidget2/DistanceInfoLayer2.h"
#include "GameFramework/Pawn.h"
#include "SceneView.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "C7/WorldWidget2/DamageEffectLayer.h"
#include "Engine/GameViewportClient.h"
#include "Widgets/SInvalidationPanel.h"

static int32 GSlateBatchZOrderInOneDrawCall2 = 0; // default disable slate batch zorder, if need enable, enable in DefaultEngine.ini
static FAutoConsoleVariableRef CVarSlateBatchZOrderInOneDrawCall2(TEXT("r.SlateBatchZOrderInOneDrawCall2"), GSlateBatchZOrderInOneDrawCall2, TEXT("Defines slate can use batchZOrder in one draw call feature.\n") TEXT(" 0: disable\n") TEXT(" 1: enable"), ECVF_Default);

//todo: 稳定后去除
static int32 GUseOldHeadInfoLayer = 0;
static FAutoConsoleVariableRef CVarUseOldHeadInfoLayer(
	TEXT("r.UseOldHeadInfoLayer"),
	GUseOldHeadInfoLayer,
	TEXT("Use OldHeadInfoLayer.\n"),
	ECVF_Default);

void SWorldWidgetLayer2::Construct(const FArguments& InArgs, const FLocalPlayerContext& InPlayerContext)
{
	PlayerContext = InPlayerContext;
	bCanSupportFocus = false;
	bUseSceneDepth = InArgs._UseSceneDepth.Get();
	LayerType = InArgs._LayerType.Get();

	ChildSlot[SAssignNew(Canvas, SConstraintCanvas)];

	if (GSlateBatchZOrderInOneDrawCall2)
	{
		Canvas->SetLocalExplicitCanvasChildZOrder(true);
	}
	else
	{
		Canvas->SetLocalExplicitCanvasChildZOrder(false);
	}
}

static bool ProjectToEdge2(const FVector2D& ScreenSize, const FVector2D& Dir, FVector2D& OutLoc)
{
	FVector2D ScreenCenter = ScreenSize / 2.f;
	float Ex = Dir.X > 0 ? ScreenSize.X : 0;
	float Ey = Dir.Y > 0 ? ScreenSize.Y : 0;

	float Tx = (Ex - ScreenCenter.X) / Dir.X;
	float TY = (Ey - ScreenCenter.Y) / Dir.Y;
	if (Tx <= TY)
	{
		OutLoc.X = Ex;
		OutLoc.Y = ScreenCenter.Y + Tx * Dir.Y;
	}
	else
	{
		OutLoc.X = ScreenCenter.X + TY * Dir.X;
		OutLoc.Y = Ey;
	}
	return true;
}

static bool IsInOval2(const FVector2D& ScreenSize, const FVector2D& Pos, const FVector2D& OvalSize)
{
	FVector2D RelativeDir2D = Pos - ScreenSize / 2;
	if (FMath::Pow(RelativeDir2D.X, 2) / FMath::Pow(OvalSize.X, 2) + FMath::Pow(RelativeDir2D.Y, 2) / FMath::Pow(OvalSize.Y, 2) < 1)
	{
		return true;
	}
	return false;
}

static bool ProjectToOvalEdge2(const FVector2D& ScreenSize, const FVector2D& Dir, const FVector2D& OvalSize, FVector2D& out_ScreenPos)
{
	FVector2D RelativeDir = Dir.GetSafeNormal();
	const float Oval = FMath::Pow(RelativeDir.X, 2) / FMath::Pow(OvalSize.X, 2) + FMath::Pow(RelativeDir.Y, 2) / FMath::Pow(OvalSize.Y, 2);

	const float Coefficient = FMath::Sqrt(1 / Oval);
	const FVector2D NewRelativePos = RelativeDir * Coefficient;

	out_ScreenPos = ScreenSize / 2 + NewRelativePos;
	return true;
}

static bool ProjectWorldToScreenFullRange2(const FVector& WorldPosition, FSceneViewProjectionData ProjData, const FMatrix& ViewProjectionMatrix, FVector2D& out_ScreenPos, FVector2D& OutProjDir)
{
	const FIntRect& ViewRect = ProjData.GetConstrainedViewRect();
	FPlane Result = ViewProjectionMatrix.TransformFVector4(FVector4(WorldPosition, 1.f));
	FVector2D ScreenSize(ViewRect.Width(), ViewRect.Height());
	bool InScreen = true;
	if (Result.W > 0.0f)
	{
		// the result of this will be x and y coords in -1..1 projection space
		const float RHW = 1.0f / Result.W;
		FPlane PosInScreenSpace = FPlane(Result.X * RHW, Result.Y * RHW, Result.Z * RHW, Result.W);

		// Move from projection space to normalized 0..1 UI space
		const float NormalizedX = (PosInScreenSpace.X / 2.f) + 0.5f;
		const float NormalizedY = 1.f - (PosInScreenSpace.Y / 2.f) - 0.5f;

		FVector2D RayStartViewRectSpace((NormalizedX * (float)ViewRect.Width()), (NormalizedY * (float)ViewRect.Height()));


		out_ScreenPos = RayStartViewRectSpace + FVector2D(static_cast<float>(ViewRect.Min.X), static_cast<float>(ViewRect.Min.Y));
		if (out_ScreenPos.X < 0 || out_ScreenPos.X > ViewRect.Width() || out_ScreenPos.Y < 0 || out_ScreenPos.Y > ViewRect.Height())
		{
			OutProjDir = FVector2D(Result.X, -Result.Y * ((float)ViewRect.Height() / (float)ViewRect.Width())).GetSafeNormal();
			return false;
		}
		return true;
	}

	OutProjDir = FVector2D(Result.X, -Result.Y * ((float)ViewRect.Height() / (float)ViewRect.Width())).GetSafeNormal();
	return false;
}

FVector2D SWorldWidgetLayer2::SmoothPosition(FVector2D& TargetPos, FVector2D& CurrentPos, const float InDeltaTime, const float InnerRange, const float OuterRange, const float InterpSpeed)
{
	FVector2D Dir = CurrentPos - TargetPos;
	float Dist = Dir.Size();
	if (Dist < InnerRange)
	{
		return CurrentPos;
	}
	else if (Dist < OuterRange)
	{
		return FMath::Vector2DInterpTo(CurrentPos, TargetPos, InDeltaTime, InterpSpeed);
	}
	else
	{
		return TargetPos + Dir.GetSafeNormal() * FMath::Max(0, OuterRange - 1);
	}
}

void SWorldWidgetLayer2::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	//QUICK_SCOPE_CYCLE_COUNTER(SWorldWidgetLayer_Tick);
	SCOPED_NAMED_EVENT_FSTRING(FString::Printf(TEXT("SWorldWidgetLayer2_Tick WorldWidgetsArray[%d]"), WorldWidgetsArray.Num()), FColor::Green);

	if (APlayerController* PlayerController = PlayerContext.GetPlayerController())
	{
		APawn* Pawn = PlayerController->GetPawn();
		if (Pawn == nullptr)
		{
			return;
		}
		if (UGameViewportClient* ViewportClient = PlayerController->GetWorld()->GetGameViewport())
		{
			const FGeometry& ViewportGeometry = ViewportClient->GetGameLayerManager()->GetViewportWidgetHostGeometry();

			FSceneViewProjectionData ProjectionData;
			FMatrix ViewProjectionMatrix;
			bool bHasProjectionData = false;

			ULocalPlayer const* const LP = PlayerController->GetLocalPlayer();
			if (LP && LP->ViewportClient)
			{
				bHasProjectionData = LP->GetProjectionData(ViewportClient->Viewport, /*out*/ ProjectionData);
				if (bHasProjectionData)
				{
					ViewProjectionMatrix = ProjectionData.ComputeViewProjectionMatrix();
				}
			}

			int EndIndex = WorldWidgetsArray.Num();
			for (int i = 0; i < EndIndex; i++)
			{
				TSharedPtr<FWWorldLayerData2> WLData = WorldWidgetsArray[i];
				int32 WWID = WLData->WWID;
				if (SWorldWidget2* WWidget = WLData->SWorldWidget.Get())
				{
					if (not WLData->SWorldWidget->WorldWidgetParams.bVisibility) 
					{
						return;
					}
					FTransform newTF = WWidget->GetTransform();
					newTF = WWidget->WorldWidgetParams.RelativeOffset * newTF;
					FVector WorldLocation = newTF.GetLocation() + WWidget->WorldWidgetParams.WorldOffset;

					FVector2D ScreenPosition2D;
					FVector2D ProjDir;
					bool IsOnEdge = false;
					float _FogShowDistance = FogShowDistance;

					const bool bProjected = [&Pawn , &WLData, bHasProjectionData, WWID, &WorldLocation, &ScreenPosition2D, &ProjectionData, &ViewProjectionMatrix, &IsOnEdge, &ProjDir, _FogShowDistance]()
						{
							if (!bHasProjectionData)
							{
								return false;
							}

							if (!WLData->SWorldWidget.IsValid())
							{
								return false;
							}

							float Dist = FVector::Dist(Pawn->GetActorLocation(), WorldLocation);
							if (_FogShowDistance > 0)
							{
								if (Dist >= _FogShowDistance)
								{
									WLData->SWorldWidget->SetIsInHiddenDistance(WWID, false);
								}
								else
								{
									WLData->SWorldWidget->SetIsInHiddenDistance(WWID, true);
								}
							}
							else 
							{
								if (WLData->SWorldWidget->WorldWidgetParams.HiddenDistance > -1.0)
								{
									if (Dist >= WLData->SWorldWidget->WorldWidgetParams.HiddenDistance)
									{
										WLData->SWorldWidget->SetIsInHiddenDistance(WWID, false);
									}
									else if (Dist < WLData->SWorldWidget->WorldWidgetParams.HiddenDistance)
									{
										WLData->SWorldWidget->SetIsInHiddenDistance(WWID, true);
									}
								}
								else
								{
									WLData->SWorldWidget->SetIsInHiddenDistance(WWID, true);
								}
							}
							
							if (!WLData->SWorldWidget->IsInShowDist.GetValue())
							{
								return false;
							}

							if (WLData->SWorldWidget->WorldWidgetParams.ScreenConstrainType == EWWConstrainType2::NONE)
							{
								return FSceneView::ProjectWorldToScreen(WorldLocation, ProjectionData.GetConstrainedViewRect(), ViewProjectionMatrix, ScreenPosition2D);
							}


							if (WLData->SWorldWidget->WorldWidgetParams.ScreenConstrainType == EWWConstrainType2::CONSTRAIN_IN_SCREEN)
							{
								if (!ProjectWorldToScreenFullRange2(WorldLocation, ProjectionData, ViewProjectionMatrix, ScreenPosition2D, ProjDir))
								{
									IsOnEdge = true;
									const FIntRect& ViewRect = ProjectionData.GetConstrainedViewRect();
									ProjectToEdge2(FVector2D((float)ViewRect.Width(), (float)ViewRect.Height()), ProjDir, ScreenPosition2D);
								}
								return true;
							}

							if (WLData->SWorldWidget->WorldWidgetParams.ScreenConstrainType == EWWConstrainType2::CONSTRAIN_IN_OVAL__OUT_OF_SCREEN)
							{
								if (!ProjectWorldToScreenFullRange2(WorldLocation, ProjectionData, ViewProjectionMatrix, ScreenPosition2D, ProjDir))
								{
									IsOnEdge = true;
									const FIntRect& ViewRect = ProjectionData.GetConstrainedViewRect();
									const FVector2D ViewRectSize((float)ViewRect.Width(), (float)ViewRect.Height());
									const FVector2D OvalSize = ViewRectSize * WLData->SWorldWidget->WorldWidgetParams.ScreenConstrainPadding / 2;
									ProjectToOvalEdge2(ViewRectSize, ProjDir, OvalSize, ScreenPosition2D);
								}
								return true;
							}

							if (WLData->SWorldWidget->WorldWidgetParams.ScreenConstrainType == EWWConstrainType2::CONSTRAIN_IN_OVAL__OUT_OF_OVAL)
							{
								bool bProjected = ProjectWorldToScreenFullRange2(WorldLocation, ProjectionData, ViewProjectionMatrix, ScreenPosition2D, ProjDir);
								const FIntRect& ViewRect = ProjectionData.GetConstrainedViewRect();
								const FVector2D ViewRectSize((float)ViewRect.Width(), (float)ViewRect.Height());
								const FVector2D OvalSize = ViewRectSize * WLData->SWorldWidget->WorldWidgetParams.ScreenConstrainPadding / 2;


								if (!bProjected || (bProjected && !IsInOval2(ViewRectSize, ScreenPosition2D, OvalSize)))
								{
									if (bProjected)
									{
										ProjDir = (ScreenPosition2D - ViewRectSize / 2).GetSafeNormal();
									}
									IsOnEdge = true;
									ProjectToOvalEdge2(ViewRectSize, ProjDir, OvalSize, ScreenPosition2D);
								}
								return true;
							}
							return false;
						}();

					if (bProjected)
					{
						WWidget->SetIsOnEdge(WWID, IsOnEdge);
						if (WLData->SWorldWidget->WorldWidgetParams.ScreenConstrainType != EWWConstrainType2::NONE && IsOnEdge)
						{
							WWidget->SetDirection(WWID, ProjDir);
						}

						double ProjectionScale = 1;
						APlayerCameraManager* CameraManager = PlayerController->PlayerCameraManager;
						if (CameraManager)
						{
							FVector CameraForwardVector = CameraManager->GetActorForwardVector();
							FVector DirectionToTarget = (WorldLocation - ProjectionData.ViewOrigin).GetSafeNormal();
							ProjectionScale = FVector::DotProduct(CameraForwardVector, DirectionToTarget);
						}
						const float ViewportDist = FVector::Dist(ProjectionData.ViewOrigin, WorldLocation) * ProjectionScale;

						const FVector2D RoundedPosition2D(FMath::RoundToInt(ScreenPosition2D.X), FMath::RoundToInt(ScreenPosition2D.Y));
						FVector2D ViewportPosition2D;

						USlateBlueprintLibrary::ScreenToViewport(PlayerController, RoundedPosition2D, ViewportPosition2D);
						bool bIsNewProject = WLData->ContainerWidget->GetVisibility() != EVisibility::SelfHitTestInvisible;
						WLData->ContainerWidget->SetVisibility(EVisibility::SelfHitTestInvisible);

						FVector ViewportPosition(ViewportPosition2D.X, ViewportPosition2D.Y, ViewportDist);
						if (WLData->SWorldWidget->WorldWidgetParams.ScreenConstrainType == EWWConstrainType2::CONSTRAIN_IN_SCREEN)
						{
							FVector2D CachedSize = WWidget->GetCachedGeometry().GetLocalSize();
							ViewportPosition.X = FMath::Max(ViewportPosition.X, 0 + CachedSize.X * WWidget->WorldWidgetParams.Alignment.X + WWidget->WorldWidgetParams.ScreenConstrainPadding.X);
							ViewportPosition.Y = FMath::Max(ViewportPosition.Y, 0 + CachedSize.Y * WWidget->WorldWidgetParams.Alignment.Y + WWidget->WorldWidgetParams.ScreenConstrainPadding.Y);
							ViewportPosition.X = FMath::Min(ViewportPosition.X, ViewportGeometry.Size.X - CachedSize.X * (1 - WWidget->WorldWidgetParams.Alignment.X) - WWidget->WorldWidgetParams.ScreenConstrainPadding.X);
							ViewportPosition.Y = FMath::Min(ViewportPosition.Y, ViewportGeometry.Size.Y - CachedSize.Y * (1 - WWidget->WorldWidgetParams.Alignment.Y) - WWidget->WorldWidgetParams.ScreenConstrainPadding.Y);
						}
						//大小变化
						FSlateRenderTransform NewTrans;

						if (SConstraintCanvas::FSlot* CanvasSlot = WLData->Slot)
						{
							FVector2D AbsoluteProjectedLocation = ViewportGeometry.LocalToAbsolute(FVector2D(ViewportPosition.X, ViewportPosition.Y));
							FVector2D LocalPosition = AllottedGeometry.AbsoluteToLocal(AbsoluteProjectedLocation);
							CanvasSlot->SetAutoSize(true);

							FMargin OldOffset = CanvasSlot->GetOffset();

							FVector2D OldPos = FVector2D(OldOffset.Left, OldOffset.Top);
							FVector2D NewPos = FVector2D(LocalPosition.X, LocalPosition.Y);
							if (!bIsNewProject && bEnableSmoothPosition)
							{
								NewPos = SmoothPosition(NewPos, OldPos, InDeltaTime, InnerSmoothRange, OuterSmoothRange, SmoothSpeed);
							}
							float Order = -ViewportPosition.Z + WWidget->WorldWidgetParams.ZorderOffSet;
							if (WLData->GPUTurb.IsValid())
							{
								WLData->GPUTurb->SetBatchZOrder(Order);
							}

							WWidget->SetDistance(ViewportPosition.Z);
							if (!WWidget->WorldWidgetParams.bNoDepth) 
							{
								if (WLData->GPUTurb.IsValid())
								{
									WLData->GPUTurb->SetGPUViewDepth(ViewportPosition.Z);
								}
								else
								{
									WLData->SWorldWidget->SetSlateInViewDepth(ViewportPosition.Z);
								}
							}

							CanvasSlot->SetAnchors(FAnchors(0, 0, 0, 0));
							CanvasSlot->SetAlignment(WWidget->WorldWidgetParams.Alignment);

							if (WLData->GPUTurb.IsValid())
							{
								CanvasSlot->SetOffset(FMargin(0, 0, 0, 0));
								float GPUTurboScale = WLData->SWorldWidget->ScaleForGPUTurbo;
								FVector2D GPUTurboPivot = FVector2D(WLData->SWorldWidget->WorldWidgetParams.Alignment.X, WLData->SWorldWidget->WorldWidgetParams.Alignment.Y);
								WLData->GPUTurb->SetGPUTransform(FWidgetTransform(NewPos, FVector2D(GPUTurboScale, GPUTurboScale), FVector2D::ZeroVector, 0));
								WLData->GPUTurb->SetGPUTransformPivot(GPUTurboPivot);
							}
							else
							{
								CanvasSlot->SetOffset(FMargin(NewPos.X, NewPos.Y, 0, 0));
							}
						}
					}
					else
					{
						WLData->ContainerWidget->SetVisibility(EVisibility::Collapsed);
					}
				}
			}
		}
	}
}

FVector2D SWorldWidgetLayer2::ComputeDesiredSize(float) const
{
	return FVector2D(0.0f, 0.0f);
}

int32 SWorldWidgetLayer2::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	return SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
}


void SWorldWidgetLayer2::EnableSmoothPosition(bool bEnable, float InnerRange, float OuterRange, float InterpSpeed)
{
	bEnableSmoothPosition = bEnable;
	InnerSmoothRange = InnerRange;
	OuterSmoothRange = OuterRange;
	SmoothSpeed = InterpSpeed;
}

void SWorldWidgetLayer2::StopWorldWidget(int32 ID)
{
	TSharedPtr<FWWorldLayerData2>* WLData = WorldWidgetsData.Find(ID);
	if (WLData != nullptr)
	{
		WLData->Get()->ContainerWidget->SetVisibility(EVisibility::Collapsed);
		WorldWidgetsArray.Remove(*WLData);
	}
}

void SWorldWidgetLayer2::RestoreWorldWidget(int32 ID)
{
	TSharedPtr<FWWorldLayerData2>* WLData = WorldWidgetsData.Find(ID);
	if (WLData != nullptr) 
	{
		WLData->Get()->ContainerWidget->SetVisibility(EVisibility::SelfHitTestInvisible);
		WorldWidgetsArray.Add(*WLData);
	}
}

void FWorldWidgetLayer2::AddWorldWidget(UUserWidget* Widget, int32 ID, TWeakPtr<SWorldWidget2> NewWidget, UGPUTurboInvalidationBox* GPUTurb/* = nullptr*/)
{
	if (!WorldWidgetMap.Contains(ID))
	{
		WorldWidgetMap.Add(ID, NewWidget);

		if (SWorldWidgetLayer2* Layer = WorldWidgetLayer.Pin().Get())
		{
			Layer->AddWorldWidget(Widget, ID, NewWidget.Pin().ToSharedRef(), GPUTurb);
		}
	}
}

void FWorldWidgetLayer2::RemoveWorldWidget(int32 ID)
{
	if (WorldWidgetMap.Contains(ID))
	{
		if (SWorldWidgetLayer2* Layer = WorldWidgetLayer.Pin().Get())
		{
			Layer->RemoveWorldWidget(ID);
		}

		WorldWidgetMap.Remove(ID);
	}
}

void FWorldWidgetLayer2::StopWorldWidget(int32 ID)
{
	if (SWorldWidgetLayer2* Layer = WorldWidgetLayer.Pin().Get())
	{
		Layer->StopWorldWidget(ID);
	}
}

void FWorldWidgetLayer2::RestoreWorldWidget(int32 ID)
{
	if (SWorldWidgetLayer2* Layer = WorldWidgetLayer.Pin().Get())
	{
		Layer->RestoreWorldWidget(ID);
	}
}

void FWorldWidgetLayer2::EnableSmoothPosition(bool bEnable, float InnerRange, float OuterRange, float InterpSpeed)
{
	if (SWorldWidgetLayer2* Layer = WorldWidgetLayer.Pin().Get())
	{
		Layer->EnableSmoothPosition(bEnable, InnerRange, OuterRange, InterpSpeed);
	}
}

void FWorldWidgetLayer2::SetFogShowDistance(float distance)
{
	if (SWorldWidgetLayer2* Layer = WorldWidgetLayer.Pin().Get())
	{
		Layer->FogShowDistance = distance;
	}
}

void FWorldWidgetLayer2::SetWorldWidgetNoDepth(int32 ID, SWorldWidget2* WorldWidget, bool NoDepth)
{
	if (WorldWidgetMap.Contains(ID))
	{
		if (SWorldWidgetLayer2* Layer = WorldWidgetLayer.Pin().Get())
		{
			Layer->SetWorldWidgetNoDepth(ID,WorldWidget,NoDepth);
		}
	}
}

void FWorldWidgetLayer2::ReserveContainer(int32 Num)
{
	if (TSharedPtr<SWorldWidgetLayer2> Layer = WorldWidgetLayer.Pin())
	{
		return Layer->ReserveContainer(Num);
	}
}

bool FWorldWidgetLayer2::HasChildren()
{
	if (TSharedPtr<SWorldWidgetLayer2> Layer = WorldWidgetLayer.Pin())
	{
		return Layer->HasChildren();
	}
	return false;
}

TSharedRef<SWidget> FWorldWidgetLayer2::AsWidget()
{
	if (TSharedPtr<SWorldWidgetLayer2> Layer = WorldWidgetLayer.Pin())
	{
		return Layer.ToSharedRef();
	}

    switch (LayerType)
    {
    case EWorldWidgetLayerType2::HeadInfo:
        {
            //todo: 稳定后去除
            if(GUseOldHeadInfoLayer)
            {
                TSharedRef<SWorldWidgetLayer2> NewWorldWidgetLayer = SNew(SWorldWidgetHeadInfoLayer2_Deprecate, LocalPlayerContext).LayerType(LayerType);
                WorldWidgetLayer = NewWorldWidgetLayer;
                return NewWorldWidgetLayer;
            }
            TSharedRef<SWorldWidgetLayer2> NewWorldWidgetLayer = SNew(SWorldWidgetHeadInfoLayer2, LocalPlayerContext);
            WorldWidgetLayer = NewWorldWidgetLayer;
            return NewWorldWidgetLayer;
        }
	case EWorldWidgetLayerType2::DistanceInfo:
        {
            TSharedRef<SWorldWidgetLayer2> NewWorldWidgetLayer = SNew(SWorldWidgetDistanceInfoLayer2, LocalPlayerContext);
            WorldWidgetLayer = NewWorldWidgetLayer;
            return NewWorldWidgetLayer;
        }
	case EWorldWidgetLayerType2::DamageEffect:
        {
            TSharedRef<SWorldWidgetLayer2> NewWorldWidgetLayer = SNew(SWorldWidgetDamageEffectLayer, LocalPlayerContext)
                .LayerType(LayerType);
            WorldWidgetLayer = NewWorldWidgetLayer; 
            return NewWorldWidgetLayer;
        }
	default:
        {
            TSharedRef<SWorldWidgetLayer2> NewWorldWidgetLayer = SNew(SWorldWidgetLayer2, LocalPlayerContext)
               .LayerType(LayerType);
            WorldWidgetLayer = NewWorldWidgetLayer;
            return NewWorldWidgetLayer;
        }
        break;
    }
}

int32 SWorldWidgetHeadInfoLayer2_Deprecate::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	SCOPED_NAMED_EVENT_TEXT("SWorldWidgetHeadInfoLayer2_Deprecate", FColor::Orange);
	auto NewArgs = Args.WithNewParent(this);
	const_cast<SWorldWidgetHeadInfoLayer2_Deprecate*>(this)->BeginGPUTurboPaint(NewArgs,LayerId);
	int32 OutLayerID = SWorldWidgetLayer2::OnPaint(NewArgs, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
	const_cast<SWorldWidgetHeadInfoLayer2_Deprecate*>(this)->EndGPUTurboPaint(OutDrawElements);
	return OutLayerID;

}