// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: lishihao07@kuaishou.com

#include "C7/WorldWidget2/HeadInfoLayer2.h"
#include "C7/WorldWidget2/HeadInfoUIConfiguration.h"

#include "KGUISettings.h"
#include "SceneView.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "Core/Common.h"
#include "Engine/GameViewportClient.h"
#include "Engine/UserInterfaceSettings.h"
#include "GameFramework/Pawn.h"
#include "PhysicsEngine/PhysicsSettings.h"
#include "Widgets/SInvalidationPanel.h"
#include "Async/ParallelFor.h"

// BEGIN ADD BY chengfeng@kuaishou.com : 
bool GEnableHeadInfoMultiThreadTick = false;
static FAutoConsoleVariableRef CVarEnableHeadInfoMultiThreadTick(TEXT("Slate.EnableHeadInfoMultiThreadTick"), 
	GEnableHeadInfoMultiThreadTick, 
	TEXT("EnableHeadInfoMultiThreadTick"), 
	ECVF_Default);
// END ADD BY chengfeng@kuaishou.com

FVector2D SHeadInfoFakeContainer::ComputeDesiredSize(float X) const
{
	return FVector2D::Zero();
}

int32 SHeadInfoFakeContainer::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	auto NewArgs = Args.WithNewParent(this);
	auto ChildWidget = ChildSlot.GetWidget();
	auto ChildDesiredSize = ChildWidget->GetDesiredSize();

	auto ChildGeometry = AllottedGeometry.MakeChild(
					// The child widget being arranged
					ChildWidget,
					// Child's local position (i.e. position within parent)
					FVector2D::Zero(),
					// Child's size
					ChildDesiredSize
				);
	return ChildGeometry.Widget->Paint(NewArgs,ChildGeometry.Geometry,MyCullingRect,OutDrawElements,LayerId,InWidgetStyle,bParentEnabled);
}

void SHeadInfoFakeContainer::SetReflectionDebugName(const FName& InName)
{
#if WIDGET_INCLUDE_RELFECTION_METADATA
	auto ReflectionData = GetMetaData<FReflectionMetaData>();
	if(ReflectionData.IsValid())
	{
		ReflectionData->Name = InName;
	}
	else
	{
		AddMetadata<FReflectionMetaData>(MakeShared<FReflectionMetaData>(InName, nullptr,nullptr,nullptr));
	}
#endif
}

void SWorldWidgetHeadInfoLayer2::Construct(const FArguments& InArgs, const FLocalPlayerContext& InPlayerContext)
{
	PlayerContext = InPlayerContext;
	bCanSupportFocus = false;

	Canvas = SNew(SConstraintCanvas);
	InvalidationPanel = SNew(SInvalidationPanel)
#if !UE_BUILD_SHIPPING
		.DebugName(TEXT("HeadInfoLayer"));
#else
		;
#endif
	InvalidationPanel->SetCanCache(true);
	InvalidationPanel->SetContent(Canvas.ToSharedRef());
	ChildSlot[InvalidationPanel.ToSharedRef()];

	//禁用Canvas的layerid递增，可以避免InvalidationBox因为一些layerid变化而触发的重画
	Canvas->SetLocalExplicitCanvasChildZOrder(true);
	//开启严格模式，防止InvalidationBox因为上层节点的隐藏，导致一些缓存dirty的widget没被Paint。
	InvalidationPanel->SetStrictPrepassMode(true);
	//用于在录像截屏等UI重渲染的时候把头顶UI过滤出来
	const uint32 HeadInfoRenderChannel = (0x02) | SLATE_RENDERCHANNLE_DEFAULT_VALUE;
	Canvas->SetRenderChannel(HeadInfoRenderChannel);

	ReadHeadInfoUIConfig();
	
	ReserveCacheContainer(200);

	Canvas->SetVisibility(EVisibility::HitTestInvisible);
}

void SWorldWidgetHeadInfoLayer2::ReserveCacheContainer(int Num)
{
	int OldNum = ContainerPool.Num();
	if(OldNum < Num)
	{
		ContainerPool.SetNum(Num);
		for(int i = OldNum; i < Num; i++)
		{
			//Slot是左上角对齐，后续headinfolayer tick算位置的时候 依赖于这件事。
			Canvas->AddSlot()
			.AutoSize(true)
			.Alignment(FVector2D(0.0,0.0))
			.Offset(FMargin(0,0,0,0))
			.Anchors(FAnchors(0, 0, 0, 0))
			.Expose(ContainerPool[i].Slot)
			[
				SAssignNew(ContainerPool[i].HeadInfoFakeContainer, SHeadInfoFakeContainer)
			];
		}
		
		TArray<int32> NewFreeContainers;
		NewFreeContainers.Reserve(Num);
		for(int i = Num - 1; i >= OldNum; i--)
		{
			NewFreeContainers.Add(i);
		}
		NewFreeContainers.Append(FreeContainer);
		FreeContainer = MoveTemp(NewFreeContainers);
	}
}

void SWorldWidgetHeadInfoLayer2::ReadHeadInfoUIConfig()
{
	auto KGUISetting =  GetDefault<UKGUISettings>();
	TMap<FName, FHeadInfoUIConfiguration> HeadInfoUIConfigMap;
	if (auto HeadInfoUIConfigTable = KGUISetting->HeadInfoUIConfigTable.LoadSynchronous())
	{
		if (HeadInfoUIConfigTable->RowStruct != nullptr)
		{
			if (HeadInfoUIConfigTable->RowStruct->IsChildOf(FHeadInfoUIConfiguration::StaticStruct()))
			{
				FHeadInfoUIConfiguration* Config = HeadInfoUIConfigTable->FindRow<FHeadInfoUIConfiguration>(FName("PC"),TEXT("Reading Data Table Row"));
				if (Config != nullptr)
				{
					HeadInfoUIConfig = *Config;
				}
			}
		}
	}
}

void SWorldWidgetHeadInfoLayer2::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SCOPED_NAMED_EVENT_FSTRING(FString::Printf(TEXT("SWorldWidgetHeadInfoLayer2_Tick WWIDToHeadInfoRootDataMap[%d]"), WWIDToHeadInfoRootDataMap.Num()), FColor::Green);

	if (GEnableHeadInfoMultiThreadTick)
	{
		Tick2(AllottedGeometry, InCurrentTime, InDeltaTime);
		return;
	}


	float BaseScale = 1.f;
	
	float DPIScale = HeadInfoUIConfig.DPIScale;
	if(DPIScale != 0.f)
	{
		BaseScale *= DPIScale / GetDefault<UUserInterfaceSettings>()->ApplicationScale;
	}

	if (APlayerController* PlayerController = PlayerContext.GetPlayerController())
	{
		APawn* Pawn = PlayerController->GetPawn();
		if (Pawn == nullptr)
		{
			return;
		}
		if (UGameViewportClient* ViewportClient = PlayerController->GetWorld()->GetGameViewport())
		{
			const FGeometry& ViewportGeometry = ViewportClient->GetGameLayerManager()->GetViewportWidgetHostGeometry();

			FSceneViewProjectionData ProjectionData;
			FMatrix ViewProjectionMatrix;
			bool bHasProjectionData = false;

			ULocalPlayer const* const LP = PlayerController->GetLocalPlayer();
			if (LP && LP->ViewportClient)
			{
				bHasProjectionData = LP->GetProjectionData(ViewportClient->Viewport, /*out*/ ProjectionData);
				if (bHasProjectionData)
				{
					ViewProjectionMatrix = ProjectionData.ComputeViewProjectionMatrix();
				}
			}
			
			FVector PawnLocation = Pawn->GetActorLocation();

			//计算屏幕投影相关
			APlayerCameraManager* CameraManager = PlayerController->PlayerCameraManager;
			check(CameraManager);
			FVector CameraForward = CameraManager->GetActorForwardVector();
			check(CameraForward.IsNormalized());
			FVector ViewOrigin = ProjectionData.ViewOrigin;
			auto ViewportSize = ViewportGeometry.GetLocalSize();
			auto WorldPosToScreenPos = [CameraForward, ViewOrigin, ViewProjectionMatrix, ViewportSize](const FVector& WorldPos, FVector2D& OutScreenPos, double& ViewDist)
			{
				ViewDist = FVector::DotProduct(CameraForward,(WorldPos-ViewOrigin));
				//要求这个Canvas尺寸和viewport尺寸一致才可以按照下面这样算。
				FPlane Result = ViewProjectionMatrix.TransformFVector4(FVector4(WorldPos, 1.f));
				bool bIsInsideView = Result.W > 0.0f;
				double W = Result.W;

				// If WorldPosition is outside the ViewProjectionMatrix and we don't force to calc the outside view position, stop the calcs.
				if (!bIsInsideView)
				{
					return false;
				}
				
				// the result of this will be x and y coords in -1..1 projection space
				const float RHW = 1.0f / W;
				FPlane PosInScreenSpace = FPlane(Result.X * RHW, Result.Y * RHW, Result.Z * RHW, W);

				// Move from projection space to normalized 0..1 UI space
				const float NormalizedX = ( PosInScreenSpace.X / 2.f ) + 0.5f;
				const float NormalizedY = 1.f - ( PosInScreenSpace.Y / 2.f ) - 0.5f;
				OutScreenPos.X = NormalizedX * ViewportSize.X;
				OutScreenPos.Y = NormalizedY * ViewportSize.Y;
				return true;
			};

			for(auto& KV:WWIDToHeadInfoRootDataMap)
			{
				int WWID = KV.Key;
				auto& RootData = KV.Value;
				if(SWorldWidget2* WWidget = RootData.WorldWidget.Get())
				{
					//todo:这个gettransform好像是这个大循环里面最费的。1000个在i9-14900k上需要0.4-0.5ms
					FTransform newTF = WWidget->GetTransform();
					newTF = WWidget->WorldWidgetParams.RelativeOffset * newTF;
					FVector WorldLocation = newTF.GetLocation() + WWidget->WorldWidgetParams.WorldOffset;
						
					float Dist = FVector::Dist(PawnLocation, WorldLocation);
					float HiddenDistance = WWidget->WorldWidgetParams.HiddenDistance != -1 ?  WWidget->WorldWidgetParams.HiddenDistance : TNumericLimits<float>::Max();
					if(FogShowDistance > 0) HiddenDistance = FogShowDistance;
					bool bShouldShow = Dist < HiddenDistance;
					//SetIsInHiddenDistance这个命名也太迷了，可恶
					//而且这个也不该在tick里面调用，里面可能广播了一大堆lua回调
					WWidget->SetIsInHiddenDistance(WWID, bShouldShow);
					bool bIsFinalVisible = WWidget->WorldWidgetParams.bVisibility;
					if(WWidget->CurrentAlpha>0 || bIsFinalVisible)
					{
						FVector2D ScreenPos;
						double ViewDist;
						auto bInView = WorldPosToScreenPos(WorldLocation,ScreenPos, ViewDist);
						if(bInView)
						{
							auto GPURoot = RootData.GPURoot.Get();
							float Order = -ViewDist + WWidget->WorldWidgetParams.ZorderOffSet;
							GPURoot->SetGPUZOrder(Order);
								
							float Scale = BaseScale;
							if (WWidget->WorldWidgetParams.bEnableDistanceScale && WWidget->DistanceScaleCurve.IsValid())
							{
								//这个一定要用曲线吗
								Scale *= WWidget->DistanceScaleCurve->GetFloatValue(ViewDist);
							}

							if (!WWidget->WorldWidgetParams.bNoDepth) 
							{
								GPURoot->SetGPUViewDepth(ViewDist);
							}

							//这个偏移计算，是因为头顶信息要求底部对齐挂接点，中心缩放。
							auto ContentSize = GPURoot->GetDesiredSize();
							auto AlignmentOffset = FVector2d(-ContentSize.X * 0.5, -ContentSize.Y*(1+Scale)*0.5);
								
							GPURoot->SetGPUTransform(FSlateRenderTransform(Scale,ScreenPos+AlignmentOffset));
						}
						bIsFinalVisible = bIsFinalVisible && bInView;
					}
					float Alpha = bIsFinalVisible ? 1 : 0;
					WWidget->SetTargetAlpha(Alpha);
					RootData.GPURoot->SetGPUOpacity(WWidget->GetShowAlpha(InDeltaTime));
				}
			}
		}
	}
}

void SWorldWidgetHeadInfoLayer2::Tick2(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	float BaseScale = 1.f;
	float DPIScale = HeadInfoUIConfig.DPIScale;
	if (DPIScale != 0.f)
	{
		BaseScale *= DPIScale / GetDefault<UUserInterfaceSettings>()->ApplicationScale;
	}

	APlayerController* PlayerController = PlayerContext.GetPlayerController();
	if (PlayerController == nullptr)
	{
		return;
	}

	APawn* Pawn = PlayerController->GetPawn();
	if (Pawn == nullptr)
	{
		return;
	}

	UWorld* w = PlayerController->GetWorld();
	if (w == nullptr)
	{
		return;
	}

	UGameViewportClient* ViewportClient = w->GetGameViewport();
	if (ViewportClient == nullptr)
	{
		return;
	}

	TSharedPtr<IGameLayerManager> glm = ViewportClient->GetGameLayerManager();
	if (glm.IsValid() == false)
	{
		return;
	}

	ULocalPlayer const* const LP = PlayerController->GetLocalPlayer();
	if (LP == nullptr || LP->ViewportClient == nullptr || PlayerController->PlayerCameraManager == nullptr)
	{
		return;
	}

	const FGeometry& ViewportGeometry = glm->GetViewportWidgetHostGeometry();
	FSceneViewProjectionData ProjectionData;
	FMatrix ViewProjectionMatrix;
	bool bHasProjectionData = false;

	bHasProjectionData = LP->GetProjectionData(ViewportClient->Viewport, /*out*/ ProjectionData);
	if (bHasProjectionData)
	{
		ViewProjectionMatrix = ProjectionData.ComputeViewProjectionMatrix();
	}

	FVector PawnLocation = Pawn->GetActorLocation();

	//计算屏幕投影相关
	APlayerCameraManager* CameraManager = PlayerController->PlayerCameraManager;
	FVector CameraForward = CameraManager->GetActorForwardVector();
	check(CameraForward.IsNormalized());
	FVector ViewOrigin = ProjectionData.ViewOrigin;
	UE::Slate::FDeprecateVector2DResult ViewportSize = ViewportGeometry.GetLocalSize();


	static FTickWorkContext TickContext;

	int Num = WWIDToHeadInfoRootDataMap.GetKeys(TickContext.KeyList);
	if (Num <= 0)
	{
		return;
	}

	TickContext.Reset(Num);

	TickContext.PawnLocation = PawnLocation;

	TickContext.CameraForward = CameraForward;
	TickContext.ViewOrigin = ViewOrigin;
	TickContext.ViewProjectionMatrix = ViewProjectionMatrix;
	TickContext.ViewportSize = ViewportSize;
	TickContext.BaseScale = BaseScale;
	TickContext.DeltaTime = InDeltaTime;

	//int ThreadNum = Num / GHeadInfoTickPerThread;
	//if (Num % GHeadInfoTickPerThread != 0)
	//{
	//	ThreadNum += 1;
	//}

	auto& Context = TickContext;

	{
		SCOPED_NAMED_EVENT_TCHAR(TEXT("Paralle Work"),FColor::Green);
		ParallelFor(Num, [this, &Context](int32 Index)
		{
			this->TickHeadInfoWidget(Context, Index);
		});
	}

	{
		SCOPED_NAMED_EVENT_TCHAR(TEXT("Apply Work"), FColor::Green);

		// do the apply work on main thread
		for (size_t i = 0; i < Num; i++)
		{
			int& wwid = TickContext.KeyList[i];
			FHeadInfoRootData& RootData = WWIDToHeadInfoRootDataMap[wwid];
			SWorldWidget2* WWidget = RootData.WorldWidget.Get();
			if (!WWidget)
			{
				continue;
			}
			SGPUTurboRootWidget* GPURoot = RootData.GPURoot.Get();
			if (!GPURoot)
			{
				continue;
			}


			WWidget->SetIsInHiddenDistance(wwid, TickContext.bNeedChangeVisibilityList[i]);

			if (TickContext.bInViewList[i])
			{
				GPURoot->SetGPUZOrder(TickContext.GPUZOrderList[i]);
				GPURoot->SetGPUTransform(TickContext.GPUTransformList[i]);
				if (!WWidget->WorldWidgetParams.bNoDepth)
				{
					GPURoot->SetGPUViewDepth(TickContext.GPUViewDepthList[i]);
				}
			}

			GPURoot->SetGPUOpacity(TickContext.GPUOpacityList[i]);
		}
	}

}

void SWorldWidgetHeadInfoLayer2::TickHeadInfoWidget(FTickWorkContext& TickContext, int idx)
{
	int& WWID = TickContext.KeyList[idx];
	auto& RootData = WWIDToHeadInfoRootDataMap[WWID];
	SWorldWidget2* WWidget = RootData.WorldWidget.Get();
	if (!WWidget)
	{
		return;
	}

		//todo:这个gettransform好像是这个大循环里面最费的。1000个在i9-14900k上需要0.4-0.5ms
	FTransform newTF = WWidget->GetTransform();
	newTF = WWidget->WorldWidgetParams.RelativeOffset * newTF;
	FVector WorldLocation = newTF.GetLocation() + WWidget->WorldWidgetParams.WorldOffset;

	float Dist = FVector::Dist(TickContext.PawnLocation, WorldLocation);
	float HiddenDistance = WWidget->WorldWidgetParams.HiddenDistance != -1 ? WWidget->WorldWidgetParams.HiddenDistance : TNumericLimits<float>::Max();
	if (FogShowDistance > 0)
	{
		HiddenDistance = FogShowDistance;
	}

	bool bShouldShow = Dist < HiddenDistance;
		//SetIsInHiddenDistance这个命名也太迷了，可恶
		//而且这个也不该在tick里面调用，里面可能广播了一大堆lua回调
	TickContext.bNeedChangeVisibilityList[idx] = bShouldShow;

		//WWidget->SetIsInHiddenDistance(WWID, bShouldShow);
	bool bIsFinalVisible = WWidget->WorldWidgetParams.bVisibility;
	if (WWidget->CurrentAlpha > 0 || bIsFinalVisible)
	{
		FVector2D ScreenPos;
		double ViewDist;
		//auto bInView = WorldPosToScreenPos(WorldLocation, ScreenPos, ViewDist);
		bool bInView = WorldToScreen(TickContext.CameraForward, TickContext.ViewOrigin, TickContext.ViewProjectionMatrix, TickContext.ViewportSize, WorldLocation, ScreenPos, ViewDist);
		if (bInView)
		{
			TickContext.bInViewList[idx] = true;

			auto GPURoot = RootData.GPURoot.Get();
			float Order = -ViewDist + WWidget->WorldWidgetParams.ZorderOffSet;
			//GPURoot->SetGPUZOrder(Order);
			TickContext.GPUZOrderList[idx] = Order;

			float Scale = TickContext.BaseScale;
			if (WWidget->WorldWidgetParams.bEnableDistanceScale && WWidget->DistanceScaleCurve.IsValid())
			{
					//这个一定要用曲线吗
				Scale *= WWidget->DistanceScaleCurve->GetFloatValue(ViewDist);
			}

			if (!WWidget->WorldWidgetParams.bNoDepth)
			{
				//GPURoot->SetGPUViewDepth(ViewDist);
				TickContext.GPUViewDepthList[idx] = ViewDist;
			}

			//这个偏移计算，是因为头顶信息要求底部对齐挂接点，中心缩放。
			auto ContentSize = GPURoot->GetDesiredSize();
			auto AlignmentOffset = FVector2d(-ContentSize.X * 0.5, -ContentSize.Y * (1 + Scale) * 0.5);

			//GPURoot->SetGPUTransform(FSlateRenderTransform(Scale, ScreenPos + AlignmentOffset));
			TickContext.GPUTransformList[idx] = FSlateRenderTransform(Scale, ScreenPos + AlignmentOffset);
		}
		bIsFinalVisible = bIsFinalVisible && bInView;
	}
	float Alpha = bIsFinalVisible ? 1 : 0;
	WWidget->SetTargetAlpha(Alpha);
	//RootData.GPURoot->SetGPUOpacity(WWidget->GetShowAlpha(InDeltaTime));
	TickContext.GPUOpacityList[idx] = WWidget->GetShowAlpha(TickContext.DeltaTime);

}

bool SWorldWidgetHeadInfoLayer2::WorldToScreen(const FVector& CameraForward, const FVector& ViewOrigin, const FMatrix& ViewProjectionMatrix, const UE::Slate::FDeprecateVector2DResult& ViewportSize,
	const FVector& WorldPos, FVector2D& OutScreenPos, double& ViewDist)
{
	ViewDist = FVector::DotProduct(CameraForward, (WorldPos - ViewOrigin));
	//要求这个Canvas尺寸和viewport尺寸一致才可以按照下面这样算。
	FPlane Result = ViewProjectionMatrix.TransformFVector4(FVector4(WorldPos, 1.f));
	bool bIsInsideView = Result.W > 0.0f;
	double W = Result.W;

	// If WorldPosition is outside the ViewProjectionMatrix and we don't force to calc the outside view position, stop the calcs.
	if (!bIsInsideView)
	{
		return false;
	}

	// the result of this will be x and y coords in -1..1 projection space
	const float RHW = 1.0f / W;
	FPlane PosInScreenSpace = FPlane(Result.X * RHW, Result.Y * RHW, Result.Z * RHW, W);

	// Move from projection space to normalized 0..1 UI space
	const float NormalizedX = (PosInScreenSpace.X / 2.f) + 0.5f;
	const float NormalizedY = 1.f - (PosInScreenSpace.Y / 2.f) - 0.5f;
	OutScreenPos.X = NormalizedX * ViewportSize.X;
	OutScreenPos.Y = NormalizedY * ViewportSize.Y;
	return true;
}

void SWorldWidgetHeadInfoLayer2::AddWorldWidget(UUserWidget* UserWidget, int32 ID, TSharedRef<SWorldWidget2> NewWidget, UGPUTurboInvalidationBox* GPUTurb)
{
	if(!WWIDToHeadInfoRootDataMap.Find(ID))
	{
		FHeadInfoRootData& RootData = WWIDToHeadInfoRootDataMap.Add(ID);
		RootData.WorldWidget = NewWidget;
		RootData.GPURoot = SNew(SGPUTurboRootWidget);
		if(FreeContainer.Num()==0)
		{
			ReserveCacheContainer(ContainerPool.Num()*2);
		}
		int FreeID = FreeContainer.Pop(false);
		RootData.ContainerID = FreeID;
		
		auto& Container = ContainerPool[FreeID];
		Container.HeadInfoFakeContainer->SetContent(RootData.GPURoot.ToSharedRef());
		Container.HeadInfoFakeContainer->SetReflectionDebugName(FName(NewWidget->WorldWidgetParams.DebugName));
		RootData.GPURoot->SetContent(NewWidget);
		if(NewWidget->WorldWidgetParams.bNoDepth)
		{
			RootData.GPURoot->EnableSceneOcclusion(false);
		}

	}
	else
	{
		UE_LOG(LogKGUI, Warning, TEXT("you are try to add an exist worldwidget(headinfowidget)"));
	}
}

void SWorldWidgetHeadInfoLayer2::RemoveWorldWidget(int32 ID)
{
	if(auto RootData = WWIDToHeadInfoRootDataMap.Find(ID))
	{
		FreeContainer.Push(RootData->ContainerID);
		auto& Container = ContainerPool[RootData->ContainerID].HeadInfoFakeContainer;
		Container->SetContent(SNullWidget::NullWidget);
		Container->SetReflectionDebugName(FName());
		RootData->GPURoot.Reset();
		RootData->WorldWidget.Reset();
		
		WWIDToHeadInfoRootDataMap.Remove(ID);
	}
	else
	{
		UE_LOG(LogKGUI, Warning, TEXT("you are try to remove a nonexistent worldwidget(headinfowidget)"));
	}
}

void SWorldWidgetHeadInfoLayer2::StopWorldWidget(int32 ID)
{
	if (WWIDToHeadInfoRootDataMap.Contains(ID))
	{
		auto RootData = WWIDToHeadInfoRootDataMap[ID];
		NoUseHeadInfoDataMap.Add(ID, RootData);
		WWIDToHeadInfoRootDataMap.Remove(ID);
		RootData.GPURoot->SetGPUOpacity(0);
		RootData.WorldWidget->ResetData();
	}
	else
	{
		UE_LOG(LogKGUI, Warning, TEXT("you are try to remove a nonexistent worldwidget(headinfowidget)"));
	}
}

bool SWorldWidgetHeadInfoLayer2::HasChildren()
{
	return WWIDToHeadInfoRootDataMap.Num() > 0;
}

void SWorldWidgetHeadInfoLayer2::RestoreWorldWidget(int32 ID)
{
	if (auto RootData = NoUseHeadInfoDataMap.Find(ID))
	{
		// 检查 ContainerID 是否有效
		if (!ContainerPool.IsValidIndex(RootData->ContainerID))
		{
			UE_LOG(LogKGUI, Error, TEXT("Invalid ContainerID: %d"), RootData->ContainerID);
			return;
		}

		WWIDToHeadInfoRootDataMap.Add(ID, *RootData);
		NoUseHeadInfoDataMap.Remove(ID);
		RootData->GPURoot->SetGPUOpacity(1);

		auto& Container = ContainerPool[RootData->ContainerID];
		Container.HeadInfoFakeContainer->SetReflectionDebugName(FName(RootData->WorldWidget->WorldWidgetParams.DebugName));
		RootData->GPURoot->EnableSceneOcclusion(!RootData->WorldWidget->WorldWidgetParams.bNoDepth);
	}
	else
	{
		UE_LOG(LogKGUI, Warning, TEXT("you are try to resotre an no exist worldwidget(headinfowidget)"));
	}
}

void SWorldWidgetHeadInfoLayer2::SetWorldWidgetNoDepth(int32 ID, SWorldWidget2* WorldWidget, bool bNoDepth)
{
	if(auto RootData = WWIDToHeadInfoRootDataMap.Find(ID))
	{
		RootData->GPURoot->EnableSceneOcclusion(!bNoDepth);
	}
}

int32 SWorldWidgetHeadInfoLayer2::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	SCOPED_NAMED_EVENT_TEXT("SWorldWidgetHeadInfoLayer", FColor::Orange);
	auto NewArgs = Args.WithNewParent(this);
	const_cast<SWorldWidgetHeadInfoLayer2*>(this)->BeginGPUTurboPaint(NewArgs,LayerId);
	int32 OutLayerID = SWorldWidgetLayer2::OnPaint(NewArgs, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
	const_cast<SWorldWidgetHeadInfoLayer2*>(this)->EndGPUTurboPaint(OutDrawElements);
	return OutLayerID;
}
