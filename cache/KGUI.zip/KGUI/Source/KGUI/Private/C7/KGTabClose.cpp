#include "C7/KGTabClose.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Components/Widget.h"
#include "Core/Common.h"
#include "Input/UKGInputProcessManager.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "UMG/Blueprint/UIFunctionLibrary.h"

#pragma  optimize("", off)

void UKGTabClose::NativeInit()
{
    Super::NativeInit();
    using namespace NS_SLUA;
    REG_MANAGER_FUNC(UKGTabClose, "SetTopUI", &UKGTabClose::SetTopUI);
    REG_MANAGER_FUNC(UKGTabClose, "AddPanelUIDIgnoreCheck", &UKGTabClose::AddPanelUIDIgnoreCheck);
    REG_MANAGER_FUNC(UKGTabClose, "AddPanelUIDsIgnoreCheck", &UKGTabClose::AddPanelUIDsIgnoreCheck);
    REG_MANAGER_FUNC(UKGTabClose, "RemovePanelUIDIgnoreCheck", &UKGTabClose::RemovePanelUIDIgnoreCheck);
    REG_MANAGER_FUNC(UKGTabClose, "ClearPanelUIDIgnoreCheck", &UKGTabClose::ClearPanelUIDIgnoreCheck);
    REG_MANAGER_FUNC(UKGTabClose, "AddIgnoreRightMouseButtonTag", &UKGTabClose::AddIgnoreRightMouseButtonTag);
    REG_MANAGER_FUNC(UKGTabClose, "RemoveIgnoreRightMouseButtonTag", &UKGTabClose::RemoveIgnoreRightMouseButtonTag);
    REG_MANAGER_FUNC(UKGTabClose, "ShouldIgnoreRightMouseButton", &UKGTabClose::ShouldIgnoreRightMouseButton);
    REG_MANAGER_FUNC(UKGTabClose, "AddPanelUIDIgnoreCheck", &UKGTabClose::AddPanelUIDIgnoreCheck);
    REG_MANAGER_FUNC(UKGTabClose, "IgnoreNextMouseUpEvent", &UKGTabClose::IgnoreNextMouseUpEvent);
}

void UKGTabClose::NativeUninit()
{
    Super::NativeUninit();
}



void UKGTabClose::OnPostLoadMapWithWorld(UWorld* World)
{
    if(World == nullptr || World->PersistentLevel == nullptr)
    {
        return;
    }
    // TabClose不需要Tick
    TickFunction.UnRegisterTickFunction();
    // TickFunction.Manager = this;
    // TickFunction.TickGroup = ETickingGroup::TG_PrePhysics;
    // TickFunction.RegisterTickFunction(World->PersistentLevel);
}

int32 UKGTabClose::PushItem(const FString& InItemId, int32 BlockPolicy, UKGUserWidget* UserWidgetBelonged, UWidget* WidgetTriggeredBy, bool bComponent)
{
    if (Items.Contains(InItemId))
    {
        UE_LOG(LogKGUI, Warning, TEXT("[TabClose]%s failed: %s is already exist"), ANSI_TO_TCHAR(__FUNCTION__), *InItemId);
        
        return Invalid_Token;
    }

    auto& Item = Items.Add(InItemId);
    Item.Token = GenerateToken();
    Item.ItemId = InItemId;
    Item.UserWidgetBelonged = UserWidgetBelonged;
    Item.WidgetTriggeredBy = WidgetTriggeredBy;
    Item.Policy = static_cast<ETabCloseBlockPolicy>(BlockPolicy);
    Item.bComponent = bComponent;

    if (WidgetTriggeredBy != nullptr
        && (BlockPolicy == static_cast<int32>(ETabCloseBlockPolicy::BlockOutsideBoundsExcludeRegions)
            || BlockPolicy == static_cast<int32>(ETabCloseBlockPolicy::UnblockOutsideBoundsExcludeRegions)))
    {
        Item.RectsExcluded.Add(WidgetTriggeredBy->GetCachedGeometry().GetRenderBoundingRect());
    }

    ItemStack.Push(InItemId);
    return Item.Token;
}

void UKGTabClose::UpdateItem(const FString& InItemName, UKGUserWidget* UserWidgetBelonged)
{
    if (Items.Contains(InItemName))
    {
        Items[InItemName].UserWidgetBelonged = UserWidgetBelonged;
    }
}

void UKGTabClose::RemoveItem(const FString& ItemId)
{
    Items.Remove(ItemId);
    ItemStack.Remove(ItemId);
}

void UKGTabClose::RemoveItemByToken(int32 InToken)
{
    for (auto Iter = Items.CreateIterator(); Iter; ++Iter)
    {
        if (Iter.Value().Token == InToken)
        {
            ItemStack.Remove(Iter.Value().ItemId);
            Iter.RemoveCurrent();
            break;
        }
    }
}

bool UKGTabClose::HandleMouseButtonDown(const FPointerEvent& PointerEvent)
{
    if (UWidgetBlueprintLibrary::IsDragDropping())
    {
        return false;
    }

    if (ShouldIgnoreRightMouseButton() && PointerEvent.GetEffectingButton() == EKeys::RightMouseButton)
    {
        return false;
    }
    
    ResetPointerEntry(PointerEvent.GetPointerIndex());
    
    auto* TopItemPtr = GetTopItem();
    if (!TopItemPtr)
    {
        return false;
    }

    auto& TopItem = *TopItemPtr;
    if (!InternalPreCheck(TopItem, PointerEvent))
    {
        return false;
    }

    RecordPointerEntry(PointerEvent);
    bMouseDown = true;
    bool bNeedCache = true;
    switch (HandlePolicy(TopItem, PointerEvent, false, bNeedCache))
    {
    case ETabCloseHandleResult::EventConsumed:
        return true;
    case ETabCloseHandleResult::Recheck:
        return ItemStack.Num() > 0;
    case ETabCloseHandleResult::EventResumePropagate:
    default:
        break;
    }
    
    return false;
}

bool UKGTabClose::HandleMouseButtonUp(const FPointerEvent& PointerEvent)
{
    if (UWidgetBlueprintLibrary::IsDragDropping())
    {
        bMouseDown = false;
        return false;
    }

    if (ShouldIgnoreRightMouseButton() && PointerEvent.GetEffectingButton() == EKeys::RightMouseButton)
    {
        return false;
    }

    if (bIgnoreNextMouseUpEvent)
    {
        bIgnoreNextMouseUpEvent = false;
        return false;
    }

    if (!IsPointerPreciseTapOrClick(PointerEvent))
    {
        UE_LOG(LogKGUI, Log, TEXT("[TabClose]%s: drag or moved, cannot do close"), ANSI_TO_TCHAR(__FUNCTION__));
        return false;
    }
    
    bool Result = TryClose(PointerEvent);
    bMouseDown = false;
    return Result;
}

void UKGTabClose::AddIgnoreRightMouseButtonTag(const FString& Tag)
{
    IgnoreRightMouseButtonTags.Add(Tag);
    
}

void UKGTabClose::RemoveIgnoreRightMouseButtonTag(const FString& Tag)
{
    IgnoreRightMouseButtonTags.Remove(Tag);
}

bool UKGTabClose::ShouldIgnoreRightMouseButton() const
{
    return IgnoreRightMouseButtonTags.Num() > 0;
}

void UKGTabClose::SetTopUI(const FString& InTopUI)
{
    TopPanelUID = InTopUI;
}

void UKGTabClose::AddPanelUIDIgnoreCheck(const FString& InPanelUID)
{
    IgnoreCheckPanelUIDs.AddUnique(InPanelUID);
}

void UKGTabClose::AddPanelUIDsIgnoreCheck(const TArray<FString>& InPanelUIDs)
{
    for (const auto& InPanelUID : InPanelUIDs)
    {
        IgnoreCheckPanelUIDs.AddUnique(InPanelUID);
    }
}

void UKGTabClose::RemovePanelUIDIgnoreCheck(const FString& InPanelUID)
{
    IgnoreCheckPanelUIDs.Remove(InPanelUID);
}

void UKGTabClose::ClearPanelUIDIgnoreCheck()
{
    IgnoreCheckPanelUIDs.Empty();
}

void UKGTabClose::IgnoreNextMouseUpEvent(const FString& Reason)
{
    bIgnoreNextMouseUpEvent = true;
}

void UKGTabClose::OnScreenInput(const FPointerEvent& PointerEvent)
{
    if (IsPointerUpEventProcessed(PointerEvent.GetPointerIndex()))
    {
        ResetPointerEntry(PointerEvent.GetPointerIndex());
        return;
    }

    if (!IsPointerPreciseTapOrClick(PointerEvent))
    {
        ResetPointerEntry(PointerEvent.GetPointerIndex());
        return;
    }

    if (auto* TopItemPtr = GetTopItem())
    {
        auto& TopItem = *TopItemPtr;
        if (InternalPreCheck(TopItem, PointerEvent))
        {
            DoClose(TopItem, true);
        }
    }
}

int32 UKGTabClose::GenerateToken()
{
    static int32 Token = 0;
    return ++Token;
}

bool UKGTabClose::CanClose(const FTabCloseItemData& Item) const
{
    if (IgnoreCheckPanelUIDs.Contains(TopPanelUID))
    {
        return true;
    }

    if (Item.bComponent && Item.ItemId.StartsWith(TopPanelUID))
    {
        return true;
    }

    return Item.ItemId == TopPanelUID;
}

bool UKGTabClose::InternalPreCheck(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent)
{
    if (Item.Policy == ETabCloseBlockPolicy::None)
    {
        return false;
    }

    if (!CanClose(Item))
    {
        return false;
    }

    FSlateRect ViewportRect = UUIFunctionLibrary::GetViewportBounds(GetWorld());
    if (ViewportRect.IsValid())
    {
        if (!ViewportRect.ContainsPoint(PointerEvent.GetScreenSpacePosition()))
        {
            return false;
        }
    }

    bool bInPanel = false;
    if (Item.UserWidgetBelonged.IsValid())
    {
        CallLuaFunction("LuaDoPrecheck", Item.ItemId, Item.Token);
        const FVector2D ScreenPos = PointerEvent.GetScreenSpacePosition();
        const uint32 UserIndex = PointerEvent.GetUserIndex();
        bInPanel = Item.UserWidgetBelonged->PanelRegionWidgets.Num() > 0
            ? Item.UserWidgetBelonged->IsPointerInPanel(ScreenPos.X, ScreenPos.Y, UserIndex)
            : UUIFunctionLibrary::IsPointerInWidget(Item.UserWidgetBelonged.Get(), ScreenPos.X, ScreenPos.Y, UserIndex);
    }
    
    return !bInPanel;
}

ETabClosePointerCheckResult UKGTabClose::DetectPointer(const FTabCloseItemData& Item, const FVector2D& PosInScreenSpace, bool bCheckExcluded)
{
    if (bCheckExcluded)
    {
        for (const auto& Rect : Item.RectsExcluded)
        {
            if (Rect.ContainsPoint(PosInScreenSpace))
            {
                return ETabClosePointerCheckResult::InsideExcluded;
            }
        }
    }
    
    return ETabClosePointerCheckResult::Outside;
}

ETabCloseHandleResult UKGTabClose::HandlePolicy(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bExecCloseAction, bool& bNeedCache)
{
    switch (Item.Policy)
    {
    case ETabCloseBlockPolicy::Unblock:
        {
            if (bExecCloseAction)
            {
                DoClose(Item, false);
            }
            bNeedCache = false;
            return ETabCloseHandleResult::EventResumePropagate;
        }
    case ETabCloseBlockPolicy::BlockOutsideBounds:
        return BlockOutsideBounds(Item, PointerEvent, bExecCloseAction, bNeedCache);
    case ETabCloseBlockPolicy::BlockOutsideBoundsExcludeRegions:
        return BlockOutsideExcludeRegions(Item, PointerEvent, bExecCloseAction, bNeedCache);
    case ETabCloseBlockPolicy::UnblockOutsideBounds:
        return UnblockOutside(Item, PointerEvent, bExecCloseAction, bNeedCache);
    case ETabCloseBlockPolicy::UnblockOutsideBoundsExcludeRegions:
        return UnblockOutsideExcludeRegions(Item, PointerEvent, bExecCloseAction, bNeedCache);
    default:
        bNeedCache = false;
        break;
    }
    return ETabCloseHandleResult::EventResumePropagate;
}

bool UKGTabClose::TryClose(const FPointerEvent& PointerEvent)
{
    auto* TopItemPtr = GetTopItem();
    if (!TopItemPtr)
    {
        return false;
    }

    auto& TopItem = *TopItemPtr;
    if (!InternalPreCheck(TopItem, PointerEvent))
    {
        return false;
    }

    UE_LOG(LogKGUI, Log, TEXT("[TabClose]%s %s"), ANSI_TO_TCHAR(__FUNCTION__), *TopItem.ItemId);

    if (bMouseDown)
    {
        bool bNeedCache = false;
        ETabCloseHandleResult Result = HandlePolicy(TopItem, PointerEvent, true, bNeedCache);

        SetPointerEntryUpEventProcessed(PointerEvent.GetPointerIndex(), bNeedCache);

        switch (Result)
        {
        case ETabCloseHandleResult::EventConsumed:
            return true;
        case ETabCloseHandleResult::Recheck:
            return ItemStack.Num() > 0;
        case ETabCloseHandleResult::EventResumePropagate:
        default:
            break;
        }
    }
    
    return false;
}

void UKGTabClose::DoClose(const FTabCloseItemData& Item, bool bScreenInput)
{
    CallLuaFunction("LuaDoClose", Item.ItemId, Item.Token, bScreenInput);
}

FTabCloseItemData* UKGTabClose::GetTopItem()
{
    if (ItemStack.Num() <= 0)
    {
        return nullptr;
    }
    
    const FString& ItemId = ItemStack.Last();
    return Items.Find(ItemId);
}

ETabCloseHandleResult UKGTabClose::BlockOutsideBounds(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bExecCloseAction, bool& bNeedCache)
{
    bNeedCache = false;
    ETabClosePointerCheckResult Result = DetectPointer(Item, PointerEvent.GetScreenSpacePosition(), false);
    if (Result == ETabClosePointerCheckResult::InsidePanel)
    {
        return ETabCloseHandleResult::EventResumePropagate;
    }

    if (bExecCloseAction)
    {
        DoClose(Item, false);
    }
    
    return  ETabCloseHandleResult::EventConsumed;
}

ETabCloseHandleResult UKGTabClose::BlockOutsideExcludeRegions(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bExecCloseAction, bool& bNeedCache)
{
    ETabClosePointerCheckResult Result = DetectPointer(Item, PointerEvent.GetScreenSpacePosition(), true);
    if (Result == ETabClosePointerCheckResult::InsidePanel)
    {
        bNeedCache = false;
        return ETabCloseHandleResult::EventResumePropagate;
    }

    if (bExecCloseAction)
    {
        DoClose(Item, false);
    }
    
    if (Result == ETabClosePointerCheckResult::InsideExcluded)
    {
        bNeedCache = true;
        return ETabCloseHandleResult::EventResumePropagate;
    }

    bNeedCache = false;
    return ETabCloseHandleResult::EventConsumed;
}

ETabCloseHandleResult UKGTabClose::UnblockOutside(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bExecCloseAction, bool& bNeedCache)
{
    ETabClosePointerCheckResult Result = DetectPointer(Item, PointerEvent.GetScreenSpacePosition(), false);
    if (Result == ETabClosePointerCheckResult::InsidePanel)
    {
        bNeedCache = false;
        return ETabCloseHandleResult::EventResumePropagate;
    }

    if (bExecCloseAction)
    {
        DoClose(Item, false);
    }
    
    bNeedCache = true;
    return ETabCloseHandleResult::EventResumePropagate;
}

ETabCloseHandleResult UKGTabClose::UnblockOutsideExcludeRegions(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bExecCloseAction, bool& bNeedCache)
{
    ETabClosePointerCheckResult Result = DetectPointer(Item, PointerEvent.GetScreenSpacePosition(), true);
    if (Result == ETabClosePointerCheckResult::InsidePanel)
    {
        bNeedCache = false;
        return ETabCloseHandleResult::EventResumePropagate;
    }

    if (bExecCloseAction)
    {
        DoClose(Item, false);
    }

    if (Result == ETabClosePointerCheckResult::InsideExcluded)
    {
        bNeedCache = false;
        return ETabCloseHandleResult::EventConsumed;
    }

    bNeedCache = true;
    return ETabCloseHandleResult::EventResumePropagate;
}

void UKGTabClose::ResetPointerEntry(int32 PointerIndex)
{
    if (PointerEntries.Contains(PointerIndex))
    {
        PointerEntries[PointerIndex].Reset();
    }
}

void UKGTabClose::RecordPointerEntry(const FPointerEvent& InPointerEvent)
{
    if (!PointerEntries.Contains(InPointerEvent.GetPointerIndex()))
    {
        auto& Entry = PointerEntries.Add(InPointerEvent.GetPointerIndex());
        Entry.PointerIndex = InPointerEvent.GetPointerIndex();
    }

    auto& PointerEntry = PointerEntries[InPointerEvent.GetPointerIndex()];
    PointerEntry.bUpEventProcessed = false;
    PointerEntry.PressedScreenSpacePosition = InPointerEvent.GetScreenSpacePosition();
    PointerEntry.bPressed = true;
        
}

bool UKGTabClose::IsPointerPreciseTapOrClick(const FPointerEvent& InPointerEvent)
{
    if (!PointerEntries.Contains(InPointerEvent.GetPointerIndex()))
    {
        return false;
    }

    auto& PointerEntry = PointerEntries[InPointerEvent.GetPointerIndex()];
    return !FSlateApplication::Get().HasTraveledFarEnoughToTriggerDrag(InPointerEvent, PointerEntry.PressedScreenSpacePosition);
}

void UKGTabClose::SetPointerEntryUpEventProcessed(int32 InPointerIndex, bool bProcessed)
{
    if (PointerEntries.Contains(InPointerIndex))
    {
        PointerEntries[InPointerIndex].bUpEventProcessed = bProcessed;
    }
}

bool UKGTabClose::IsPointerUpEventProcessed(int32 InPointerIndex)
{
    if (PointerEntries.Contains(InPointerIndex))
    {
        return PointerEntries[InPointerIndex].bUpEventProcessed;
    }
    
    return false;
}
#pragma  optimize("", on)
