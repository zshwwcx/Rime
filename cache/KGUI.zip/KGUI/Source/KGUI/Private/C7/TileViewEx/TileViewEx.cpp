#include "TileViewEx.h"
#include "Components/SlateWrapperTypes.h"
#include "Components/Image.h"
#include "Components/CanvasPanelSlot.h"
#include <Blueprint/UserWidget.h>

#include "AssetRegistry/AssetData.h"
#include "UMG/Blueprint/UIFunctionLibrary.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Engine/Blueprint.h"
#include "UObject/ConstructorHelpers.h"



#define LOCTEXT_NAMESPACE "UMG"

/////////////////////////////////////////////////////
// UTileViewEx

UTileViewEx::UTileViewEx(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	curIndex = 0;
	if (EntryWidgetClass == nullptr)
	{
		static ConstructorHelpers::FClassFinder<UUserWidget> bpclass(TEXT("/Game/Arts/UI_2/Blueprint/GM/EmptyEntry.EmptyEntry_C"));
		if (bpclass.Class != NULL)
		{
			EntryWidgetClass = bpclass.Class;
		}
	}
}

void UTileViewEx::HandleOnEntryInitializedInternal(UObject* Item, const TSharedRef<ITableRow>& TableRow)
{
	BP_OnEntryInitializedExt.Broadcast(Item, GetEntryWidgetFromItem(Item));
}

#if WITH_EDITOR
const FText UTileViewEx::GetPaletteCategory()
{
	return LOCTEXT("Custom", "Custom");
}

void UTileViewEx::OnCreationFromPalette()
{
	IAssetRegistry& AssetRegistry = FAssetRegistryModule::GetRegistry();
	FAssetData AssetData = AssetRegistry.GetAssetByObjectPath(FSoftObjectPath(TEXT("/Game/Arts/UI_2/Blueprint/GM/EmptyEntry.EmptyEntry_C")));
	if (AssetData.IsValid())
	{
		if (UObject* Object = AssetData.FastGetAsset(true))
		{
			if (UBlueprint* Blueprint = Cast<UBlueprint>(Object))
			{
				EntryWidgetClass = Blueprint->GeneratedClass;
			}
		}
	}
}

#endif

UUserWidget& UTileViewEx::OnGenerateEntryWidgetInternal(UObject* Item, TSubclassOf<UUserWidget> DesiredEntryClass, const TSharedRef<STableViewBase>& OwnerTable)
{
	UUserWidget& widget = Super::GenerateTypedEntry(DesiredEntryClass, OwnerTable);
	UWidget* root = widget.GetRootWidget();
	if(root == nullptr)
	{
		return widget;
	}
	UCanvasPanel* panel = Cast<UCanvasPanel>(root);
	if (panel != nullptr && ScrollWidget != nullptr)
	{
		if (panel->GetChildrenCount() > 0)
		{
			return widget;
		}
		UWidget* newWidget;
		if (curIndex == 0)
		{
			CaculateDesireSize();
		}
		UClass* wclass = ScrollWidget->GetClass();
		if (isUserWidget)
		{
			newWidget = widget.CreateWidgetInstance(widget, ScrollWidget->GetClass(), NAME_None);
		}
		else
		{
			newWidget = UUIFunctionLibrary::DeepDuplicateWidget(ScrollWidget, panel);
		}
		panel->AddChildToCanvas(newWidget);
		newWidget->SetVisibility(ESlateVisibility::Visible);
		UCanvasPanelSlot* slot = Cast<UCanvasPanelSlot>(newWidget->Slot);
		if (slot != nullptr)
		{
			slot->SetSize(DesiredSize);
		}
		SetEntryWidthEx(DesiredSize.X);
		SetEntryHeightEx(DesiredSize.Y);
		curIndex++;
	}
	return widget;
}


void UTileViewEx::CaculateDesireSize()
{
	if(ScrollWidget == nullptr)
	{
		return;
	}
	UClass* wclass = ScrollWidget->GetClass();
	if (wclass->IsChildOf(UUserWidget::StaticClass()))
	{
		isUserWidget = true;
		UCanvasPanelSlot* itemSlot = Cast<UCanvasPanelSlot>(ScrollWidget->Slot);
		if(itemSlot)
		{
			if (itemSlot->GetAutoSize())
			{
				TSharedRef<SWidget> swidget = ScrollWidget->TakeWidget();
				DesiredSize = swidget->GetDesiredSize();
			}
			else
			{
				DesiredSize = itemSlot->GetSize();
			}
		}
		else
		{
			TSharedRef<SWidget> swidget = ScrollWidget->TakeWidget();
			DesiredSize = swidget->GetDesiredSize();
		}
	}
	else
	{
		UCanvasPanelSlot* itemSlot = Cast<UCanvasPanelSlot>(ScrollWidget->Slot);
		if(itemSlot)
		{
			DesiredSize = itemSlot->GetSize();
		}
		else
		{
			TSharedRef<SWidget> swidget = ScrollWidget->TakeWidget();
			DesiredSize = swidget->GetDesiredSize();
		}
		isUserWidget = false;
	}
}

void UTileViewEx::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	if (MyTileView.IsValid())
	{
		MyTileView->SetAllowOverscroll(AllowOverscroll ? EAllowOverscroll::Yes : EAllowOverscroll::No);
	}
	SetScrollbarVisibilityEx(bShowScrollBar);

	if (ScrollWidget != nullptr)
	{
#if WITH_EDITOR
		if (ScrollWidget->IsDesignTime())
		{
			//ScrollWidget->SetVisibility(ESlateVisibility::Visible);
		}
		else
		{
			ScrollWidget->SetVisibility(ESlateVisibility::Hidden);
		}
#else
		ScrollWidget->SetVisibility(ESlateVisibility::Hidden);
#endif
	}
}

TSharedRef<STableViewBase> UTileViewEx::RebuildListWidget()
{
	return ConstructTileView<STileViewEx>();
}


void UTileViewEx::SetScrollbarVisibilityEx(bool InVisibility)
{
	
	if (InVisibility)
	{
		Super::SetScrollbarVisibility(ESlateVisibility::Visible);
		bShowScrollBar = true;
	}
	else
	{
		Super::SetScrollbarVisibility(ESlateVisibility::Collapsed);
		bShowScrollBar = false;
	}
}

float UTileViewEx::GetDistancePercent()
{
	if (MyTileView.IsValid())
	{
		auto scrollDistance = MyTileView->GetScrollDistance();
		return scrollDistance.Y - scrollDistance.X;
	}
	return 0.f;
}

float UTileViewEx::GetDistancePercentRemaining()
{
	if (MyTileView.IsValid())
	{
		auto scrollDistance = MyTileView->GetScrollDistanceRemaining();
		return scrollDistance.Y - scrollDistance.X;
	}
	return 0.f;
}

void UTileViewEx::SetAllowOverscroll(bool NewAllowOverscroll)
{
	AllowOverscroll = NewAllowOverscroll;

	if (MyTileView.IsValid())
	{
		MyTileView->SetAllowOverscroll(AllowOverscroll ? EAllowOverscroll::Yes : EAllowOverscroll::No);
	}
}

FString UTileViewEx::GetEntryWidgetClassName()
{
	if (ScrollWidget)
	{
		return ScrollWidget->GetName();
//		下方的写法用意何在
// 		UClass* Class = ScrollWidget->GetClass();
// 		if (Class->IsChildOf(UUserWidget::StaticClass()))
// 		{
// 			if (Class->ClassGeneratedBy)
// 			{
// 				return Class->ClassGeneratedBy->GetName();
// 			}
// 			else
// 			{
// 				return Class->GetName();
// 			}
// 		}
	}
	return FString();
}

void UTileViewEx::SetEntryHeightEx(float NewHeight)
{
	EntryHeight = NewHeight;
	if (MyTileView.IsValid())
	{
		MyTileView->SetItemHeight(GetTotalEntryHeight());
	}
}
// float UTileViewEx::GetScrollOffset()
// {
// 	if (MyTileView.IsValid())
// 	{
// 		return MyTileView->GetScrollOffset();
// 	}
// 	return 0.f;
// }

void UTileViewEx::SetCurrentScrollOffsetDefault()
{
	if (MyTileView.IsValid())
	{
		MyTileView->SetCurrentScrollOffsetDefault();
	}
}

float UTileViewEx::GetCurrentScrollOffset()
{
	if (MyTileView.IsValid())
	{
		return MyTileView->GetCurrentScrollOffset();
	}
	return 0.f;
}


float UTileViewEx::GetDesiredScrollOffset()
{
	if (MyTileView.IsValid())
	{
		return MyTileView->GetDesiredScrollOffset();
	}
	return 0.f;
}
void UTileViewEx::SetEntryWidthEx(float NewWidth)
{
	EntryWidth = NewWidth;
	if (MyTileView.IsValid())
	{
		MyTileView->SetItemWidth(GetTotalEntryWidth());
	}
}

void UTileViewEx::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);

	if (MyTileView.IsValid())
	{
		MyTileView.Reset();
	}
}
#undef LOCTEXT_NAMESPACE