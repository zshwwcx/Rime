#pragma once
#include "CoreMinimal.h"
#include "C7/ListViewEx/ListViewEx.h"
#include "Components/TileView.h"
#include "STileViewEx.h"
#include "TileViewEx.generated.h"

UCLASS()
class KGUI_API UTileViewEx : public UTileView
{
	GENERATED_UCLASS_BODY()

	IMPLEMENT_TYPED_UMG_LIST(UObject*, MyListView)

public:
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	/** Sets the height of every tile entry */
	UFUNCTION(BlueprintCallable, Category = TileView)
		void SetEntryHeightEx(float NewHeight);

	UFUNCTION(BlueprintCallable, Category = TileView)
		void SetEntryWidthEx(float NewWidth);

	UFUNCTION(BlueprintCallable, Category = TileView)
		float GetCurrentScrollOffset();

	UFUNCTION(BlueprintCallable, Category = TileView)
		float GetDesiredScrollOffset();
	template <typename RowWidgetT = UWidget>
	RowWidgetT* GetEntryWidgetFromItem(const UObject* Item) const
	{
		RowWidgetT* Widget = Item ? ITypedUMGListView<UObject*>::GetEntryWidgetFromItem<RowWidgetT>(const_cast<UObject*>(Item)) : nullptr;
		if (Widget != nullptr)
		{
			if (Widget->template IsA<UUserWidget>())
			{
				if(UUserWidget* UserWidget = Cast<UUserWidget>(Widget))
				{
					UWidget* root = UserWidget->GetRootWidget();
					if(root)
					{
						if(UCanvasPanel* panel = Cast<UCanvasPanel>(root))
						{
							return panel->GetChildAt(0);
						}
					}
				}
				
			}
		}
		return nullptr;
	}

	void HandleOnEntryInitializedInternal(UObject* Item, const TSharedRef<ITableRow>& TableRow);

#if WITH_EDITOR
	// UWidget interface
	virtual const FText GetPaletteCategory() override;
	// End UWidget interface
	virtual void OnCreationFromPalette() override;
#endif

	virtual UUserWidget& OnGenerateEntryWidgetInternal(UObject* Item, TSubclassOf<UUserWidget> DesiredEntryClass, const TSharedRef<STableViewBase>& OwnerTable) override;

	/** STileView construction helper - useful if using a custom STileView subclass */
	template <template<typename> class TileViewT = STileViewEx>
	TSharedRef<TileViewT<UObject*>> ConstructTileView()
	{
		FTileViewConstructArgs Args;
		Args.bAllowFocus = bIsFocusable;
		Args.SelectionMode = SelectionMode;
		Args.bClearSelectionOnClick = bClearSelectionOnClick;
		Args.ConsumeMouseWheel = ConsumeMouseWheel;
		Args.bReturnFocusToSelection = bReturnFocusToSelection;
		Args.TileAlignment = TileAlignment;
		Args.EntryHeight = EntryHeight;
		Args.EntryWidth = EntryWidth;
		Args.bWrapDirectionalNavigation = bWrapHorizontalNavigation;
		Args.Orientation = Orientation;

		MyListView = MyTileView = ITypedUMGListView<UObject*>::ConstructTileView<TileViewT>(this, ListItems, Args);
		MyTileView->SetOnEntryInitialized(SListView<UObject*>::FOnEntryInitialized::CreateUObject(this, &UTileViewEx::HandleOnEntryInitializedInternal));
		return StaticCastSharedRef<TileViewT<UObject*>>(MyTileView.ToSharedRef());
	}

	void SynchronizeProperties();

	UFUNCTION(BlueprintCallable, Category = TileView)
		void SetScrollbarVisibilityEx(bool InVisibility);

	UFUNCTION(BlueprintCallable, Category = TileView)
		float GetDistancePercent();

	//UFUNCTION(BlueprintCallable, Category = TileView)
	//	float GetScrollOffset();

	UFUNCTION(BlueprintCallable, Category = TileView)
		void SetCurrentScrollOffsetDefault();
	
	UFUNCTION(BlueprintCallable, Category = TileView)
		float GetDistancePercentRemaining();

	UFUNCTION(BlueprintCallable, Category = TileView)
		void SetAllowOverscroll(bool NewAllowOverscroll);

	UFUNCTION(BlueprintPure, Category = ListView)
	FString GetEntryWidgetClassName();

	//SlistViewEx add overscroll function
	TSharedPtr<STileViewEx<UObject*>> MyTileView;  // cppcheck:ignore 野指针作为模板类型参数

protected:
	UPROPERTY(EditAnywhere, Category = Content, meta = (MultiLine = "true"))
	UWidget* ScrollWidget;
	int curIndex;
	FVector2D DesiredSize;
	bool isUserWidget;
	void CaculateDesireSize();

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Content)
		bool bShowScrollBar = false;
	/** Called when a row widget is generated for a list item */
	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Entry Initialized"))
		FOnListEntryInitializedExtDynamic BP_OnEntryInitializedExt;
	virtual TSharedRef<STableViewBase> RebuildListWidget() override;
};