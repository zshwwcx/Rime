﻿#pragma once
#include "Framework/Layout/Overscroll.h"
#include "Widgets/Views/STileView.h"
#include "Widgets/Views/STableViewBase.h"

class STableViewBase;
//增加了是否过度滚动的功能
template <typename ItemType>
class KGUI_API STileViewEx : public STileView <ItemType>
{
public:
	EAllowOverscroll GetAllowOverscroll() const
	{
		return STableViewBase::AllowOverscroll;
	}

	double GetCurrentScrollOffset()
	{
		 return STableViewBase::CurrentScrollOffset;
	}
	
	void SetCurrentScrollOffsetDefault()
	{
		STableViewBase::CurrentScrollOffset= 0.;
	}
	double GetDesiredScrollOffset()
	{
		return STableViewBase::DesiredScrollOffset;
	}


	void SetAllowOverscroll(EAllowOverscroll NewAllowOverscroll)
	{
		STableViewBase::AllowOverscroll = NewAllowOverscroll;
		if (STableViewBase::AllowOverscroll == EAllowOverscroll::No)
		{
			STableViewBase::Overscroll.ResetOverscroll();
		}
	}
	
};