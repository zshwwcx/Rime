#include "Core/Common.h"

DEFINE_LOG_CATEGORY(LogKGUI)