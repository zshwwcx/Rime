#include "Core/ModuleFeature/KGModuleFeatureList.h"

void FKGModuleFeatureList::StartupModule()
{
	Broadcast([](auto Feature) { Feature->StartupModule(); });
}

void FKGModuleFeatureList::ShutdownModule()
{
	Broadcast([](auto Feature) { Feature->ShutdownModule(); });
}
