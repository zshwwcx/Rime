#include "Core/ModuleFeature/KGModuleFeature.h"

#include "Core/ModuleFeature/KGModuleFeatureList.h"

IKGModuleFeature* IKGModuleFeature::GetModuleFeaturePtr(FName InName) const
{
	check(FeatureListPtr != nullptr);
	auto Feature = FeatureListPtr->GetFeatureByName(InName);
	return Feature.Get();
}
