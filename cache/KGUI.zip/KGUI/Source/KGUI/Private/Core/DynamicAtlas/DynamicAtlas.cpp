#include "Core/DynamicAtlas/DynamicAtlas.h"
#include "Core/DynamicAtlas/DynamicAtlasSubsystem.h"
#include "Core/DynamicAtlas/DynamicAtlasSlot.h"
#include "ScreenRendering.h"
#include "CommonRenderResources.h"
#include "KGUISettings.h"
#include "RHIStaticStates.h"
#include "TextureResource.h"
#include "Core/DynamicAtlas/DynamicSprite.h"
#include "Engine/CanvasRenderTarget2D.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Math/GuardedInt.h"
#include "Modules/ModuleManager.h"
#include "GlobalRenderResources.h"
#include "DeviceProfiles/DeviceProfile.h"
#include "DeviceProfiles/DeviceProfileManager.h"
#include "Engine/TextureLODSettings.h"


uint32 UDynamicAtlasCanvasRenderTarget2D::CalcTextureMemorySizeEnum(ETextureMipCount Enum) const
{
	// BEGIN: 从UTextureRenderTarget2D::CalcTextureMemorySizeEnum复制来
	EPixelFormat Format = GetFormat();
	int32 BlockSizeX = GPixelFormats[Format].BlockSizeX;
	int32 BlockSizeY = GPixelFormats[Format].BlockSizeY;
	int32 BlockBytes = GPixelFormats[Format].BlockBytes;
	int32 NumBlocksX = (SizeX + BlockSizeX - 1) / BlockSizeX;
	int32 NumBlocksY = (SizeY + BlockSizeY - 1) / BlockSizeY;
	int32 NumBytes = NumBlocksX * NumBlocksY * BlockBytes;
	// END: 从UTextureRenderTarget2D::CalcTextureMemorySizeEnum复制来
	return NumBytes;
}

void UDynamicAtlas::DumpSlots() const
{
	UE_LOG(LogDynamicAtlas, Log, TEXT("Used Slots:"));
	TArray<FDynamicAtlasSlot> AllSlots;
	for (const auto& Slot : UsedSlots)
	{
		UE_LOG(LogDynamicAtlas, Log, TEXT("  %s"), *Slot.ToString());
		AllSlots.Add(Slot);
	}
	UE_LOG(LogDynamicAtlas, Log, TEXT("Free Slots:"));
	for (const auto& Slot : FreeSlots)
	{
		UE_LOG(LogDynamicAtlas, Log, TEXT("  %s"), *Slot.ToString());
		AllSlots.Add(Slot);
	}
	int Area = 0;
	for (int I = 0; I < AllSlots.Num(); I++)
	{
		FIntRect A(AllSlots[I].X, AllSlots[I].Y, AllSlots[I].X + AllSlots[I].Width, AllSlots[I].Y + AllSlots[I].Height);
		for (int J = I + 1; J < AllSlots.Num(); J++)
		{
			FIntRect B(AllSlots[J].X, AllSlots[J].Y, AllSlots[J].X + AllSlots[J].Width, AllSlots[J].Y + AllSlots[J].Height);

			if (A.Intersect(B))
			{
				UE_LOG(LogDynamicAtlas, Error, TEXT("  %s is Intersected with %s"), *AllSlots[I].ToString(), *AllSlots[J].ToString());
			}
		}
		Area += AllSlots[I].Width * AllSlots[I].Height;
	}
	if (Area != TextureSizeX * TextureSizeY)
	{
		UE_LOG(LogDynamicAtlas, Error, TEXT("Area Size: %d, Expected: %d"), Area, TextureSizeX * TextureSizeY);
	}
}

void UDynamicAtlas::SetConfiguration(const FDynamicAtlasGroupConfiguration& InConfiguration)
{
	Configuration = InConfiguration;
	TextureSizeX = Configuration.AtlasMinSize;
	TextureSizeY = Configuration.AtlasMinSize;

	AtlasTexture = CreateTexture();

	FDynamicAtlasSlot RootSlot(0, 0, TextureSizeX, TextureSizeY);
	FreeSlots.Add(RootSlot);
}

bool UDynamicAtlas::TryAddSprite(UDynamicSprite* Sprite, FDynamicAtlasSlot& OutSlot, FIntPoint& OutSize)
{
	UTexture2D* TextureChild = Sprite->GetSourceTexture();
	OutSize = FIntPoint(TextureChild->GetImportedSize().X, TextureChild->GetImportedSize().Y);
	FDynamicAtlasSlot Slot = AllocateSlot(OutSize);
	if (!Slot.IsValid())
	{
		ResizeTexture();
		Slot = AllocateSlot(OutSize);
		if (!Slot.IsValid())
		{
			return false;
		}
	}

	FTextureResource* SourceResource = TextureChild->GetResource();
	FTextureResource* DestResource = AtlasTexture->GetResource();
	auto TempConfiguration = Configuration;
	auto bCreatedWithCompressedTexture = GetDefault<UKGUISettings>()->IsDynamicAtlasCreatedWithCompressedTexture();

	ENQUEUE_RENDER_COMMAND(CopyTextureCommand)(
		[TempConfiguration, bCreatedWithCompressedTexture, SourceResource, DestResource, Slot, Size = OutSize](FRHICommandListImmediate& RHICmdList)
		{
			if (bCreatedWithCompressedTexture)
			{
#if 0  // 把Padding填上，不过效果并不是很好，BlockSize如果比较大，就可能把贴图中的实际内容赋值到Padding上。
				auto VerticalPadding = Slot.Width - Slot.ContentWidth;
				auto HorizontalPadding = Slot.Height - Slot.ContentHeight;
				if (VerticalPadding > 0)
				{
					CopyTexture(TempConfiguration, RHICmdList, SourceResource->TextureRHI, DestResource->TextureRHI, nullptr,
						Slot.X + Slot.ContentWidth, Slot.Y, VerticalPadding, Slot.ContentHeight, Slot.ContentWidth - VerticalPadding, 0);
				}
				if (HorizontalPadding > 0)
				{
					CopyTexture(TempConfiguration, RHICmdList, SourceResource->TextureRHI, DestResource->TextureRHI, nullptr,
						Slot.X, Slot.Y + Slot.ContentHeight, Slot.ContentWidth, HorizontalPadding, 0, Slot.ContentHeight - HorizontalPadding);
				}
				if (VerticalPadding > 0 && HorizontalPadding > 0)
				{
					CopyTexture(TempConfiguration, RHICmdList, SourceResource->TextureRHI, DestResource->TextureRHI, nullptr,
						Slot.X + Slot.ContentWidth, Slot.Y + Slot.ContentHeight, VerticalPadding, HorizontalPadding, Slot.ContentWidth - VerticalPadding, Slot.ContentHeight - HorizontalPadding);
				}
#endif
			}
			else
			{
				CopyTexture(TempConfiguration, RHICmdList, GTransparentBlackTexture->TextureRHI, DestResource->TextureRHI, nullptr,
					Slot.X, Slot.Y, Slot.Width, Slot.Height);
			}
			CopyTexture(TempConfiguration, RHICmdList, SourceResource->TextureRHI, DestResource->TextureRHI, nullptr,
				Slot.X, Slot.Y, Size.X, Size.Y);
		}
	);

	UE_LOG(LogDynamicAtlas, Log, TEXT("Dynamic Sprite %s has been Added Successfully. (%s)"), *Sprite->ToString(), *Slot.ToString());
	OutSlot = Slot;
	return true;
}

void UDynamicAtlas::RemoveSprite(UDynamicSprite* Sprite)
{
	if (Sprite == nullptr)
	{
		return;
	}
	const auto& ToBeRemoved= Sprite->GetSlot();
	for (TSet<FDynamicAtlasSlot>::TIterator Itr(UsedSlots); Itr; ++Itr)
	{
		const FDynamicAtlasSlot& Slot = *Itr;
		if (Slot.RectEquals(ToBeRemoved))
		{
			if (!MergeNeighborSlot(Slot))
			{
				FreeSlots.Add(Slot);
			}
			Itr.RemoveCurrent();
			UE_LOG(LogDynamicAtlas, Log, TEXT("Dynamic Sprite %s has been Removed. %s"), *Sprite->ToString(), *Slot.ToString());
			return;
		}
	}

	UE_LOG(LogDynamicAtlas, Error, TEXT("Failed to Remove Dynamic Sprite %s. %s"), *Sprite->ToString(), *ToBeRemoved.ToString());
}

void UDynamicAtlas::CopyTexture(FDynamicAtlasGroupConfiguration Configuration, FRHICommandList& RHICmdList, FTextureRHIRef SourceTexture, FTextureRHIRef DestTexture,
	FRHIGPUFence* Fence, uint32 DestX, uint32 DestY, uint32 Width, uint32 Height, int32 SrcX, int32 SrcY)
{
	SCOPED_NAMED_EVENT(UDynamicAtlas_CopyTexture, FColor::Green);

    if (GetDefault<UKGUISettings>()->IsDynamicAtlasCreatedWithCompressedTexture())
    {
		check(SourceTexture->GetDesc().Format == DestTexture->GetDesc().Format)
		RHICmdList.Transition(FRHITransitionInfo(SourceTexture, ERHIAccess::Unknown, ERHIAccess::CopySrc));
		RHICmdList.Transition(FRHITransitionInfo(DestTexture, ERHIAccess::Unknown, ERHIAccess::CopyDest));
		FRHICopyTextureInfo CopyInfo;
		CopyInfo.DestPosition = FIntVector(DestX, DestY, 0);
		CopyInfo.Size = FIntVector(Width, Height, 0);
		if (SrcX >= 0 && SrcY >= 0)
		{
			CopyInfo.SourcePosition = FIntVector(SrcX, SrcY, 0);
		}
		check(SourceTexture != DestTexture);
		RHICmdList.CopyTexture(SourceTexture, DestTexture, CopyInfo);
    }
    else
    {
	    IRendererModule* RendererModule = &FModuleManager::GetModuleChecked<IRendererModule>("Renderer");
	    
	    RHICmdList.Transition(FRHITransitionInfo(SourceTexture, ERHIAccess::Unknown, ERHIAccess::SRVMask));
	    RHICmdList.Transition(FRHITransitionInfo(DestTexture, ERHIAccess::Unknown, ERHIAccess::RTV));
	    
	    // source and destination are different. rendered copy
	    FRHIRenderPassInfo RPInfo(DestTexture, ERenderTargetActions::Load_Store);
        RHICmdList.BeginRenderPass(RPInfo, TEXT("PixelCapture::CopyTexture"));
        {
            FGlobalShaderMap* ShaderMap = GetGlobalShaderMap(GMaxRHIFeatureLevel);
            TShaderMapRef<FScreenVS> VertexShader(ShaderMap);
            TShaderMapRef<FScreenPS> PixelShader(ShaderMap);
   
            RHICmdList.SetViewport(0, 0, 0.0f, DestTexture->GetDesc().Extent.X, DestTexture->GetDesc().Extent.Y, 1.0f);
   
            FGraphicsPipelineStateInitializer GraphicsPSOInit;
            RHICmdList.ApplyCachedRenderTargets(GraphicsPSOInit);
            GraphicsPSOInit.BlendState = TStaticBlendState<>::GetRHI();
            GraphicsPSOInit.RasterizerState = TStaticRasterizerState<>::GetRHI();
            GraphicsPSOInit.DepthStencilState = TStaticDepthStencilState<false, CF_Always>::GetRHI();
            GraphicsPSOInit.BoundShaderState.VertexDeclarationRHI = GFilterVertexDeclaration.VertexDeclarationRHI;
            GraphicsPSOInit.BoundShaderState.VertexShaderRHI = VertexShader.GetVertexShader();
            GraphicsPSOInit.BoundShaderState.PixelShaderRHI = PixelShader.GetPixelShader();
            GraphicsPSOInit.PrimitiveType = PT_TriangleList;
            SetGraphicsPipelineState(RHICmdList, GraphicsPSOInit, 0);
   
			SetShaderParametersLegacyPS(RHICmdList, PixelShader, TStaticSamplerState<SF_Point>::GetRHI(), SourceTexture);
	    	
	    	RendererModule->DrawRectangle(RHICmdList,
				DestX, DestY, // Dest X, Y
				Width,			// Dest Width
				Height,			// Dest Height
				0, 0,										// Source U, V
				1, 1,										// Source USize, VSize
				FIntPoint(DestTexture->GetDesc().Extent.X, DestTexture->GetDesc().Extent.Y),							// Target buffer size
				FIntPoint(1, 1),							// Source texture size
				VertexShader, EDRF_Default);
        }
   
        RHICmdList.EndRenderPass();
	   
	    RHICmdList.Transition(FRHITransitionInfo(SourceTexture, ERHIAccess::SRVMask, ERHIAccess::CopySrc));
	    RHICmdList.Transition(FRHITransitionInfo(DestTexture, ERHIAccess::RTV, ERHIAccess::CopyDest));
    }

    if (Fence != nullptr)
    {
        RHICmdList.WriteGPUFence(Fence);
    }
}

FDynamicAtlasSlot UDynamicAtlas::AllocateSlot(const FIntPoint& Size)
{
	FDynamicAtlasSlot ReturnVal;

	int BlockSizeX = 1;
	int BlockSizeY = 1;

	if (auto Texture2D = Cast<UTexture2D>(AtlasTexture))
	{
		const FPixelFormatInfo& DestPixelFormatInfo = GPixelFormats[Texture2D->GetPixelFormat()];
		BlockSizeX = DestPixelFormatInfo.BlockSizeX;
		BlockSizeY = DestPixelFormatInfo.BlockSizeY;
	}

	// Account for padding on both sides
	const uint32 PaddedWidth = FMath::CeilToInt((float)(Size.X + Configuration.SlotPadding) / BlockSizeX) * BlockSizeX;
	const uint32 PaddedHeight = FMath::CeilToInt((float)(Size.Y + Configuration.SlotPadding) / BlockSizeY) * BlockSizeY;

	uint32 BestAreaFit = std::numeric_limits<uint32>::max();
	uint32 BestShortSideFit = std::numeric_limits<uint32>::max();
	
	for (FDynamicAtlasSlot CurSlot : FreeSlots)
	{
		if (CurSlot.Width >= PaddedWidth && CurSlot.Height >= PaddedHeight)
		{
			uint32 AreaFit = CurSlot.Width * CurSlot.Height - PaddedWidth * PaddedHeight;
			
			uint32 LeftoverHoriz = CurSlot.Width - PaddedWidth;
			uint32 LeftoverVert = CurSlot.Height - PaddedHeight;
			uint32 ShortSideFit = FMath::Min<uint32>(LeftoverHoriz, LeftoverVert);

			if (AreaFit < BestAreaFit || (AreaFit == BestAreaFit && ShortSideFit < BestShortSideFit))
			{
				ReturnVal = CurSlot;
				BestShortSideFit = ShortSideFit;
				BestAreaFit = AreaFit;
			}
		}
	}
	
	if (ReturnVal.IsValid())
	{
		// The width and height of the new child node
		const uint32 RemainingWidth =  FMath::Max<int32>(0, ReturnVal.Width - PaddedWidth);
		const uint32 RemainingHeight = FMath::Max<int32>(0, ReturnVal.Height - PaddedHeight);

		// New slots must have a minimum width/height, to avoid excessive slots i.e. excessive memory usage and iteration.
		// No glyphs seem to use slots this small, and cutting these slots out improves performance/memory-usage a fair bit
		const uint32 MinSlotDim = 2;

		// Split the remaining area around this slot into two children.
		if (RemainingHeight >= MinSlotDim || RemainingWidth >= MinSlotDim)
		{
			FDynamicAtlasSlot LeftSlot;
			FDynamicAtlasSlot RightSlot;

			if (RemainingHeight <= RemainingWidth)
			{
				if (RemainingHeight >= MinSlotDim)
				{
					LeftSlot.SetData(ReturnVal.X, ReturnVal.Y + PaddedHeight, PaddedWidth, RemainingHeight);
				}
				RightSlot.SetData(ReturnVal.X + PaddedWidth, ReturnVal.Y, RemainingWidth, ReturnVal.Height);
			}
			else
			{
				if (RemainingWidth >= MinSlotDim)
				{
					LeftSlot.SetData(ReturnVal.X + PaddedWidth, ReturnVal.Y, RemainingWidth, PaddedHeight);

				}
				RightSlot.SetData(ReturnVal.X, ReturnVal.Y + PaddedHeight, ReturnVal.Width, RemainingHeight);
			}

			// Replace the old slot within AtlasEmptySlots, with the new Left and Right slot, then add the old slot to AtlasUsedSlots
			if (LeftSlot.IsValid())
			{
				FreeSlots.Add(LeftSlot);
				FreeSlots.Add(RightSlot);
			}
			else
			{
				FreeSlots.Add(RightSlot);
			}
		}
		
		// Remove the old slot from AtlasEmptySlots, into AtlasUsedSlots
		FreeSlots.Remove(ReturnVal);
		ReturnVal.Width = PaddedWidth;
		ReturnVal.Height = PaddedHeight;
		UsedSlots.Add(ReturnVal);
	}
	return MoveTemp(ReturnVal);
}

UTexture* UDynamicAtlas::CreateTexture()
{
	auto AtlasTextureFilter = Configuration.AtlasTextureFilter;

	if (GetDefault<UKGUISettings>()->IsDynamicAtlasCreatedWithCompressedTexture())
	{
		auto Format = GetDefault<UKGUISettings>()->GetDynamicAtlasCompressionFormat();

		const int32 NumBlocksX = TextureSizeX / GPixelFormats[Format].BlockSizeX;
		const int32 NumBlocksY = TextureSizeY / GPixelFormats[Format].BlockSizeY;
		FGuardedInt64 BytesForImageValidation = FGuardedInt64(NumBlocksX) * NumBlocksY * GPixelFormats[Format].BlockBytes;
		int64 BytesForImage = BytesForImageValidation.Get(0);

		UTexture2D* Texture2D = NewObject<UTexture2D>(
			this,
			NAME_None,
			RF_Transient
		);

		Texture2D->LODGroup = TEXTUREGROUP_UI;
		Texture2D->Filter = AtlasTextureFilter;

		Texture2D->SetPlatformData(new FTexturePlatformData());
		Texture2D->GetPlatformData()->SizeX = TextureSizeX;
		Texture2D->GetPlatformData()->SizeY = TextureSizeY;
		Texture2D->GetPlatformData()->SetNumSlices(1);
		Texture2D->GetPlatformData()->PixelFormat = Format;

		FTexture2DMipMap* Mip = new FTexture2DMipMap(TextureSizeX, TextureSizeY, 1);
		Texture2D->GetPlatformData()->Mips.Add(Mip);
		Mip->BulkData.Lock(LOCK_READ_WRITE);
		void* DestImageData = Mip->BulkData.Realloc(BytesForImage);
		FMemory::Memset(DestImageData, 0, BytesForImage);
		Mip->BulkData.Unlock();
		Texture2D->UpdateResource();
		return Texture2D;
	}
	else
	{
		auto CanvasRenderTarget2D = UCanvasRenderTarget2D::CreateCanvasRenderTarget2D(
			this->GetWorld(), UDynamicAtlasCanvasRenderTarget2D::StaticClass(), TextureSizeX, TextureSizeY
		);

		CanvasRenderTarget2D->Filter = AtlasTextureFilter;

		CanvasRenderTarget2D->LODGroup = TEXTUREGROUP_UI;
		CanvasRenderTarget2D->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA8;
		CanvasRenderTarget2D->OverrideFormat = PF_R8G8B8A8; // Force use PF_R8G8B8A8 instead of PF_B8G8R8A8
		CanvasRenderTarget2D->UpdateResource();
		return CanvasRenderTarget2D;
	}
}

void UDynamicAtlas::ResizeTexture()
{
	if (!AtlasTexture)
	{
		UE_LOG(LogDynamicAtlas, Error, TEXT("Atlas Texture is null."));
		return;
	}

	auto Subsystem = UDynamicAtlasSubsystem::GetInstance(this);
	if (!Subsystem)
	{
		UE_LOG(LogDynamicAtlas, Error, TEXT("Dynamic Atlas Subsystem is null."));
		return;
	}
	
	if (TextureSizeX >= Configuration.AtlasMaxSize)
	{
		UE_LOG(LogDynamicAtlas, Warning, TEXT("The Atlas Texture Size is Already at its Maximum. (%d, %d)"), TextureSizeX, TextureSizeY);
		return;
	}

	FDynamicAtlasSlot RootSlot;
	if (TextureSizeX >= TextureSizeY)
	{
		uint32 MinY = 0;
		for (FDynamicAtlasSlot CurSlot : UsedSlots)
		{
			uint32 SlotBottom = CurSlot.Y + CurSlot.Height;
			if (SlotBottom > MinY)
			{
				MinY = SlotBottom;
			}
		}

		TextureSizeY *= 2;
		RootSlot.SetData(0, MinY, TextureSizeX, TextureSizeY-MinY);
		MergeFreeSlotsWithResizedSlot(RootSlot, false);
	}
	else
	{
		uint32 MinX = 0;
		for (FDynamicAtlasSlot CurSlot : UsedSlots)
		{
			uint32 SlotRight = CurSlot.X + CurSlot.Width;
			if (SlotRight > MinX)
			{
				MinX = SlotRight;
			}
		}

		TextureSizeX *= 2;
		RootSlot.SetData(MinX, 0, TextureSizeX-MinX, TextureSizeY);
		MergeFreeSlotsWithResizedSlot(RootSlot, true);
	}

	FreeSlots.Add(RootSlot);

	UTexture* NewAtlasTexture = CreateTexture();
	
	FTextureResource* SourceResource = AtlasTexture->GetResource();
	FTextureResource* DestResource = NewAtlasTexture->GetResource();

	auto TempConfiguration = Configuration;
	
	UE_LOG(LogDynamicAtlas, Log, TEXT("The Texture has been Resized to (%d, %d)."), TextureSizeX, TextureSizeY);

	if (GetDefault<UKGUISettings>()->bDumpDynamicAtlasSlotsWhenResizingTexture)
	{
		DumpSlots();
	}

	ENQUEUE_RENDER_COMMAND(CopyTextureCommand)(
	[TempConfiguration, SourceResource, DestResource](FRHICommandListImmediate& RHICmdList)
		{
			CopyTexture(TempConfiguration, RHICmdList, SourceResource->TextureRHI, DestResource->TextureRHI, nullptr,
				0, 0, SourceResource->GetSizeX(), SourceResource->GetSizeY());
		}
	);
	
	AtlasTexture = NewAtlasTexture;
	Subsystem->OnAtlasResized().Broadcast(this);
}

//slot被释放时，尝试合并周围slot，减少碎片
bool UDynamicAtlas::MergeNeighborSlot(const FDynamicAtlasSlot& Slot)
{
	FDynamicAtlasSlot ReplacedSlot;
	FDynamicAtlasSlot NewSlot;
	for (const auto& FreeSlot : FreeSlots)
	{
		if (FreeSlot.Width == Slot.Width && FreeSlot.X == Slot.X)
		{
			if (FreeSlot.Y + FreeSlot.Height == Slot.Y)
			{
				ReplacedSlot = FreeSlot;
				NewSlot = FDynamicAtlasSlot(FreeSlot.X, FreeSlot.Y, FreeSlot.Width, FreeSlot.Height + Slot.Height);
				break;
			}
			else if (Slot.Y + Slot.Height == FreeSlot.Y)
			{
				ReplacedSlot = FreeSlot;
				NewSlot = FDynamicAtlasSlot(Slot.X, Slot.Y, Slot.Width, FreeSlot.Height + Slot.Height);
				break;
			}
		}
		else if (FreeSlot.Height == Slot.Height && FreeSlot.Y == Slot.Y)
		{
			if (FreeSlot.X + FreeSlot.Width == Slot.X)
			{
				ReplacedSlot = FreeSlot;
				NewSlot = FDynamicAtlasSlot(FreeSlot.X, FreeSlot.Y, FreeSlot.Width + Slot.Width, FreeSlot.Height);
				break;
			}
			else if (Slot.X + Slot.Width == FreeSlot.X)
			{
				ReplacedSlot = FreeSlot;
				NewSlot = FDynamicAtlasSlot(Slot.X, Slot.Y, FreeSlot.Width + Slot.Width, Slot.Height);
				break;
			}
		}
	}
	if (ReplacedSlot.IsValid())
	{
		check(NewSlot.IsValid());
		FreeSlots.Remove(ReplacedSlot);

		if (Configuration.bMergeRecursively)
		{
			if (!MergeNeighborSlot(NewSlot))
			{
				FreeSlots.Add(NewSlot);
			}
		}
		else
		{
			FreeSlots.Add(NewSlot);
		}
		return true;
	}
	return false;
}

//扩容时的合并
void UDynamicAtlas::MergeFreeSlotsWithResizedSlot(const FDynamicAtlasSlot& ResizeSlot, bool bHorizontalOrVertical)
{
	TSet<FDynamicAtlasSlot> ToBeRemoveds;
	TSet<FDynamicAtlasSlot> ToBeAddeds;
	if (bHorizontalOrVertical)
	{
		for (auto Slot : FreeSlots)
		{
			if (Slot.X + Slot.Width > ResizeSlot.X)
			{
				ToBeRemoveds.Add(Slot);
				if (Slot.X < ResizeSlot.X)
				{
					Slot.Width = ResizeSlot.X - Slot.X;
					ToBeAddeds.Add(Slot);
				}
			}
		}
	}
	else
	{
		for (auto Slot : FreeSlots)
		{
			if (Slot.Y + Slot.Height > ResizeSlot.Y)
			{
				ToBeRemoveds.Add(Slot);
				if (Slot.Y < ResizeSlot.Y)
				{
					Slot.Height = ResizeSlot.Y - Slot.Y;
					ToBeAddeds.Add(Slot);
				}
			}
		}
	}
	for (auto ToBeRemoved : ToBeRemoveds)
	{
		FreeSlots.Remove(ToBeRemoved);
	}
	for (auto ToBeAdded : ToBeAddeds)
	{
		FreeSlots.Add(ToBeAdded);
	}
}
