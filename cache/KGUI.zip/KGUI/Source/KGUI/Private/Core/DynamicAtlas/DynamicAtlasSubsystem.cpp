#include "Core/DynamicAtlas/DynamicAtlasSubsystem.h"
#include "KGUISettings.h"
#include "Core/DynamicAtlas/DynamicAtlas.h"
#include "Engine/AssetManager.h"
#include "Engine/GameInstance.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "UObject/UObjectIterator.h"
#if WITH_EDITOR
#include "TextureCompiler.h"
#endif

DEFINE_LOG_CATEGORY(LogDynamicAtlas);

void UDynamicAtlasSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	auto Settings = GetDefault<UKGUISettings>();
	UE_LOG(LogDynamicAtlas, Log, TEXT("Dynamic Atlas Enabled: %d, Platform Name: %s"), IsEnabled(), *UGameplayStatics::GetPlatformName());

	Super::Initialize(Collection);
}

UDynamicAtlasSubsystem* UDynamicAtlasSubsystem::GetInstance(const UObject* InWorldContext)
{
	if (!IsValid(InWorldContext) || !IsValid(InWorldContext->GetWorld()))
	{
		return nullptr;
	}
	UGameInstance* GI = UGameplayStatics::GetGameInstance(InWorldContext);
	if (GI)
	{
		return GI->GetSubsystem<UDynamicAtlasSubsystem>();
	}
	return nullptr;
}

void UDynamicAtlasSubsystem::StartUp()
{
	UE_LOG(LogDynamicAtlas, Log, TEXT("Dynamic Atlas Started Up."));
	auto Settings = GetDefault<UKGUISettings>();
	GroupConfigurations = Settings->GenerateFinalDynamicAtlasGroupConfigurations();
	bStartedUp = true;
}

bool UDynamicAtlasSubsystem::IsEnabled() const
{
	return GetDefault<UKGUISettings>()->IsDynamicAtlasEnabled();
}

bool UDynamicAtlasSubsystem::AddSprite(UDynamicSprite* Sprite)
{
	return AddSprite(Sprite, UDynamicSprite::FOnInitialized());
}

bool UDynamicAtlasSubsystem::AddSprite(UDynamicSprite* Sprite, UDynamicSprite::FOnInitialized&& OnInitialized)
{
	if (!IsEnabled())
	{
		return false;
	}
	if (!IsStartedUp())
	{
		UE_LOG(LogDynamicAtlas,
			Error,
			TEXT("Dynamic Atlas Subsystem has not been started up when trying to add sprite%s."),
			*(Sprite ? FString::Printf(TEXT(" (%s)"), *Sprite->GetPathName()) : FString())
		);
		return false;
	}
	FName GroupName;
	if (!TryGetGroupName(Sprite, GroupName))
	{
		return false;
	}

	bool bSuccess = GetOrCreateAtlasGroup(GroupName).AddSprite(Sprite, MoveTemp(OnInitialized));
	if (!bSuccess)
	{
		DumpDynamicAtlasInfo();
	}
	return bSuccess;
}

bool UDynamicAtlasSubsystem::TryGetGroupNameByPackagePath(const FString& Path, FName& OutGroupName)
{
	// TODO: TTrieTree<FName>估计更高效（假设有TTrieTree，或者得自己实现下…）
	const auto& DynamicAtlasGroupConfigurations = GroupConfigurations;
	for (const auto& Pair : DynamicAtlasGroupConfigurations)
	{
		const auto& GroupName = Pair.Key;
		const auto& DynamicAtlasGroupConfiguration = Pair.Value;
		for (const auto& RootPackagePath : DynamicAtlasGroupConfiguration.AutomaticTextureDirectoryPaths)
		{
			if (Path.StartsWith(RootPackagePath))
			{
				OutGroupName = GroupName;
				return true;
			}
		}
	}
	return false;
}

bool UDynamicAtlasSubsystem::TryGetGroupName(UDynamicSprite* Sprite, FName& OutGroupName)
{
	if (Sprite->IsRuntimeCreated())
	{
		return TryGetGroupNameByPackagePath(Sprite->GetRuntimeSourceTexturePath().GetLongPackageName(), OutGroupName);
	}
	else
	{
		static FName DefaultDynamicAtlasGroupName = TEXT("Default");
		OutGroupName = DefaultDynamicAtlasGroupName;
		return true;
	}
}

FDynamicAtlasGroupConfiguration UDynamicAtlasSubsystem::GetGroupConfiguration(FName GroupName)
{
	const auto& DynamicAtlasGroupConfigurations = GroupConfigurations;
	auto Found = DynamicAtlasGroupConfigurations.Find(GroupName);
	if (Found == nullptr)
	{
		UE_LOG(LogDynamicAtlas, Warning, TEXT("No Group Configuration Named with \"%s\" Found. Fallback to DynamicAtlasGroupConfiguration's default value."), *GroupName.ToString());
		return FDynamicAtlasGroupConfiguration();
	}
	return *Found;
}


FDynamicAtlasGroup& UDynamicAtlasSubsystem::GetOrCreateAtlasGroup(FName GroupName)
{
	auto Found = AtlasGroups.Find(GroupName);
	if (Found != nullptr)
	{
		return *Found;
	}
	UE_LOG(LogDynamicAtlas, Log, TEXT("Group Named with \"%s\" was created."), *GroupName.ToString());
	return AtlasGroups.Add(GroupName, FDynamicAtlasGroup(this, GetGroupConfiguration(GroupName)));
}

#pragma region 动态加载

UDynamicSprite* UDynamicAtlasSubsystem::NewSprite(UTexture2D* Texture2D)
{
	return NewSprite(Texture2D, UDynamicSprite::FOnInitialized());
}

UDynamicSprite* UDynamicAtlasSubsystem::NewSprite(UTexture2D* Texture2D, UDynamicSprite::FOnInitialized&& OnInitialized)
{
	if (!IsEnabled())
	{
		return nullptr;
	}
	if (!IsStartedUp())
	{
		//UE_LOG(LogDynamicAtlas,
		//	Error,
		//	TEXT("Dynamic Atlas Subsystem has not been started up when trying to create a new sprite%s."),
		//	*(Texture2D ? FString::Printf(TEXT(" for (%s)"), *Texture2D->GetPathName()) : FString())
		//);
		return nullptr;
	}
	auto DynamicSprite = GetOrCreateRuntimeSprite(Texture2D);
	if (DynamicSprite == nullptr)
	{
		return nullptr;
	}
	AddSprite(DynamicSprite, MoveTemp(OnInitialized));
	return DynamicSprite;
}

UDynamicSprite* UDynamicAtlasSubsystem::GetOrCreateRuntimeSprite(UTexture2D* Texture2D)
{
	if (Texture2D == nullptr)
	{
		return nullptr;
	}
	FSoftObjectPath Path = Texture2D;
	FName GroupName;
	if (!TryGetGroupNameByPackagePath(Path.GetLongPackageName(), GroupName))
	{
		return nullptr;
	}
	auto Found = RuntimeSprites.Find(Path);
	if (Found)
	{
		if (auto Existed = Found->Get())
		{
			return Existed;
		}
	}
	auto NewDynamicSprite = NewObject<UDynamicSprite>(GetTransientPackage(), UDynamicSprite::StaticClass());
	NewDynamicSprite->SetSourceTextureInternal(Texture2D, true);
	if (Found)
	{
		*Found = NewDynamicSprite;
	}
	else
	{
		RuntimeSprites.Add(Path, NewDynamicSprite);
	}
	UE_LOG(LogDynamicAtlas, Log, TEXT("Runtime Dynamic Sprite %s is Created for %s."), *NewDynamicSprite->GetName(), *Texture2D->GetPathName());
	return NewDynamicSprite;
}

void UDynamicAtlasSubsystem::RemoveRuntimeSprite(FSoftObjectPath RuntimeSourceTexturePath)
{
	RuntimeSprites.Remove(RuntimeSourceTexturePath);
}


void UDynamicAtlasSubsystem::DumpDynamicAtlasInfo()
{
	UE_LOG(LogDynamicAtlas, Log, TEXT("%s"), *GetPathName());
	for (const auto& Pair : GetAtlasGroups())
	{
		UE_LOG(LogDynamicAtlas, Log, TEXT("# Group %s"), *Pair.Key.ToString());
		int Index = 0;
		for (const auto& Atlas : Pair.Value.GetAtlasList())
		{
			UE_LOG(LogDynamicAtlas, Log, TEXT("  # Page %d"), Index);
			Atlas->DumpSlots();
			Index++;
		}
	}
}

#pragma endregion

static FAutoConsoleCommand GDumpDynamicAtlasSlots
(
	TEXT("KGUI.DumpDynamicAtlasSlots"),
	TEXT("Dump dynamic atlas slot informations."),
	FConsoleCommandDelegate::CreateLambda([]()
	{
		for (TObjectIterator<UDynamicAtlasSubsystem> It; It; ++It)
		{
			auto* Subsystem = *It;
			Subsystem->DumpDynamicAtlasInfo();
		}
	})
);
