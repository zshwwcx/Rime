#include "Core/DynamicAtlas/DynamicAtlasGroup.h"

#include "KGUISettings.h"
#include "Core/DynamicAtlas/DynamicSprite.h"

bool FDynamicAtlasGroup::AddSprite(UDynamicSprite* Sprite, UDynamicSprite::FOnInitialized&& OnInitialized)
{
	check(Subsystem.Get() && Subsystem->IsEnabled() && Subsystem->IsStartedUp());
	if(Sprite->IsInitialized())
	{
		check(!Sprite->IsAtlased() || Sprite->IsInitialized());  // NOTE: 如果IsAtlased那一定应该IsInitialized
		return false;
	}
	FDynamicAtlasSlot Slot;
	FIntPoint Size;
	UDynamicAtlas* AvailableAtlas = nullptr;
	FString ErrorString;
	if (Sprite->IsAtlasable(Configuration, &ErrorString))
	{
		for (auto Atlas : AtlasList)
		{
			if (Atlas->TryAddSprite(Sprite, Slot, Size))
			{
				AvailableAtlas = Atlas;
				break;
			}
		}
		if (AvailableAtlas == nullptr)
		{
			if (auto NewAtlas = CreateAtlas())
			{
				if (NewAtlas->TryAddSprite(Sprite, Slot, Size))
				{
					AvailableAtlas = NewAtlas;
				}
			}
			else
			{
				UE_LOG(LogDynamicAtlas, Error, TEXT("Failed to create Dynamic Atlas. (Check error above)"));
			}
		}
	}
	if (AvailableAtlas != nullptr)
	{
		Sprite->InitializeInternal(Subsystem.Get(), AvailableAtlas, Slot, Size);
	}
	else
	{
		UE_LOG(LogDynamicAtlas, Error, TEXT("%s"), *ErrorString);
		Sprite->InitializeInternal(Subsystem.Get());
	}
	OnInitialized.ExecuteIfBound(Sprite);
	return AvailableAtlas != nullptr;
}

UDynamicAtlas* FDynamicAtlasGroup::CreateAtlas()
{
	check(Subsystem.Get());
	if (Configuration.AtlasMaxNum >= 0 && AtlasList.Num() >= Configuration.AtlasMaxNum)
	{
		UE_LOG(LogDynamicAtlas, Error, TEXT("Maximum limit (%d) of Dynamic Atlas has been reached."), Configuration.AtlasMaxNum);
		return nullptr;
	}

	UDynamicAtlas* DynamicAtlas = NewObject<UDynamicAtlas>(Subsystem.Get());
	DynamicAtlas->SetConfiguration(this->GetConfiguration());

	AtlasList.Add(DynamicAtlas);

	return DynamicAtlas;
}