#include "Core/DynamicAtlas/DynamicSprite.h"

#include "KGUISettings.h"
#include "Core/DynamicAtlas/DynamicAtlas.h"
#include "Core/DynamicAtlas/DynamicAtlasSubsystem.h"
#include "Engine/CanvasRenderTarget2D.h"
#if WITH_EDITOR
#include "TextureCompiler.h"
#endif

void UDynamicSprite::BeginDestroy() 
{
	TryRemoveFromAtlas();
	Super::BeginDestroy();
}

FSlateAtlasData UDynamicSprite::GetSlateAtlasData() const
{
	if (!IsAtlased() || !IsValid(Atlas->AtlasTexture))
	{
		if (SourceTexture == nullptr)
		{
			UE_LOG(LogDynamicAtlas, Error, TEXT("Dynamic Sprite %s 's Source Texture is null."), *this->ToString());
			return FSlateAtlasData(nullptr, FVector2D(0,0), FVector2D(0,0));
		}

#if WITH_EDITOR
		if (SourceTexture->IsCompiling())
		{
			FTextureCompilingManager::Get().FinishCompilation({ SourceTexture });
		}
#endif
		
		return FSlateAtlasData(SourceTexture, FVector2D(0,0), FVector2D(1,1));
	}

	const float SizeX = Atlas->TextureSizeX;
	const float SizeY = Atlas->TextureSizeY;
	const auto DesignPadding = Atlas->Configuration.DesignPadding;

	const FVector2D StartUV = FVector2D((float)(Slot.X + DesignPadding) / SizeX, (float)(Slot.Y + DesignPadding) / SizeY);
	const FVector2D SizeUV = FVector2D((float)(ContentSize.X - 2 * DesignPadding) / SizeX, (float)(ContentSize.Y - 2 * DesignPadding) / SizeY);

	return FSlateAtlasData(Atlas->AtlasTexture, StartUV, SizeUV);
}

void UDynamicSprite::InitializeInternal(UDynamicAtlasSubsystem* DynamicAtlasSubsystem, UDynamicAtlas* InAtlas, const FDynamicAtlasSlot& InSlot, const FIntPoint& InContentSize)
{
	Atlas = InAtlas;
	Slot = InSlot;
	ContentSize = InContentSize;
#if !WITH_EDITOR
	SourceTexture = nullptr;
#endif
	Subsystem = DynamicAtlasSubsystem;
}

void UDynamicSprite::InitializeInternal(UDynamicAtlasSubsystem* DynamicAtlasSubsystem)
{
	Subsystem = DynamicAtlasSubsystem;
}

void UDynamicSprite::TryRemoveFromAtlas()
{
	if (IsAtlased())
	{
		Atlas->RemoveSprite(this);
	}
	Atlas = nullptr;
	if (bRuntimeCreated)
	{
		if (Subsystem.Get())
		{
			Subsystem.Get()->RemoveRuntimeSprite(this->RuntimeSourceTexturePath);
		}
	}
}

void UDynamicSprite::Initialize(UDynamicAtlasSubsystem* DynamicAtlasSubsystem)
{
	Initialize(DynamicAtlasSubsystem, FOnInitialized());
}

void UDynamicSprite::Initialize(UDynamicAtlasSubsystem* DynamicAtlasSubsystem, FOnInitialized&& OnInitialized)
{
	if (IsInitialized())
	{
		OnInitialized.ExecuteIfBound(this);
		return;
	}
	DynamicAtlasSubsystem->AddSprite(this, MoveTemp(OnInitialized));
}

void UDynamicSprite::Uninitialize()
{
	TryRemoveFromAtlas();
	Subsystem.Reset();
}

bool UDynamicSprite::IsAtlasable(const FDynamicAtlasGroupConfiguration& InConfiguration, FString* OutError) const
{
	auto CompiledSourceTexture = this->GetSourceTexture();
	if (CompiledSourceTexture == nullptr)
	{
		*OutError = FString::Printf(TEXT("Dynamic Sprite %s 's Source Texture is missing."), *this->ToString());
		return false;
	}
	int32 TextureWidth = CompiledSourceTexture->GetSizeX();
	int32 TextureHeight = CompiledSourceTexture->GetSizeY();

	const auto SpriteMaxSize = InConfiguration.SpriteMaxSize;
	const auto bCreatedWithCompressedTexture = GetDefault<UKGUISettings>()->IsDynamicAtlasCreatedWithCompressedTexture();
	const auto CompressionFormat = GetDefault<UKGUISettings>()->GetDynamicAtlasCompressionFormat();

	if (TextureWidth > SpriteMaxSize.X || TextureHeight > SpriteMaxSize.Y)
	{
		if (OutError)
		{
			*OutError = FString::Printf(TEXT("Dynamic Sprite %s 's Source Texture (%d, %d) exceeds the size limit (%d, %d)."), *this->ToString(), TextureWidth, TextureHeight, SpriteMaxSize.X, SpriteMaxSize.Y);
		}
		return false;
	}

	if (bCreatedWithCompressedTexture)
	{
		if (CompiledSourceTexture->GetPixelFormat() != CompressionFormat)
		{
			if (OutError)
			{
				*OutError = FString::Printf(TEXT("Dynamic Sprite %s Source Texture 's Pixel Format is %d, not %d."), *this->ToString(), (int)CompiledSourceTexture->GetPixelFormat(), (int)CompressionFormat);
			}
			return false;
		}
	}

	return true;
}

UTexture2D* UDynamicSprite::GetSourceTexture() const
{
#if WITH_EDITOR
	if (SourceTexture)
	{
		FTextureCompilingManager::Get().FinishCompilation({ SourceTexture });
	}
#endif
	return SourceTexture;
}
