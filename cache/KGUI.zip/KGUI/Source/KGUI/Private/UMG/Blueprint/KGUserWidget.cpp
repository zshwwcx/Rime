// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Blueprint/KGUserWidget.h"

#include "AkAudioEvent.h"
#include "Manager/KGAkAudioManager.h"
#include "KGUIWidgetBlueprintGeneratedClassExtension.h"
#if WITH_EDITOR
#include "UI/KGUIPlatformCustomSetting.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Editor.h"
#include "Editor/EditorEngine.h"
extern UNREALED_API class UEditorEngine* GEditor;
#endif
#include "UI/KGUserWidgetAnimComponent.h"
#include "Blueprint/WidgetTree.h"
// #include "UMG/StateManagement/KGStateManagement.h"
#include "KGUI.h"
#include "KGUISettings.h"
#include "MovieScene.h"
#include "Animation/UMGSequencePlayer.h"
#include "Core/Common.h"
#include "EntitySystem/MovieSceneEntitySystemRunner.h"
#include "UMG/Skeletal/KGUserWidgetSkeletalWidget.h"
#include "UMG/Blueprint/UIFunctionLibrary.h"
#include "UMG/Animation/KGUserWidgetAnimationSection.h"
#include "UMG/Animation/KGUserWidgetAnimationTrack.h"

constexpr float FrameMinusInterval = 0.01f;

extern bool GPlayMainAndSubAnimAtTheSameTime;


void FKGWidgetSkelSubAnimTask::Start()
{
	if (UserWidget && WidgetAnimation)
	{
		float StartTime = WidgetAnimation->GetStartTime() + Delay - StartAtTime;
		float EndTime = WidgetAnimation->GetEndTime() + Delay - StartAtTime;
		if (StartTime <= 0.0f && EndTime > 0.f)
		{
			UserWidget->PlayAnimation(WidgetAnimation, FMath::Abs(StartTime), NumLoopsToPlay, PlayMode, PlaybackSpeed, bRestoreState);
			UE_LOG(LogKGUI, Log, TEXT("[KGUserWidget]%s %s %s"), ANSI_TO_TCHAR(__FUNCTION__),
				*UserWidget->GetName(),
				*WidgetAnimation->GetName());
			bRunning = false;
		}
		else
		{
			bRunning = true;
		}
	}
}

void FKGWidgetSkelSubAnimTask::Stop()
{
	if (UserWidget && WidgetAnimation)
	{
		UserWidget->StopAnimation(WidgetAnimation);
		bRunning = false;
	}
}

void FKGWidgetSkelSubAnimTask::Tick(float InDeltaTime)
{
	if (!bRunning)
	{
		return;
	}

	const float Last = Delay;
	Delay -= InDeltaTime;

	if (Last > 0 && Delay <= 0)
	{
		if (UserWidget && WidgetAnimation)
		{
			UserWidget->PlayAnimation(WidgetAnimation, FMath::Abs(Delay), NumLoopsToPlay, PlayMode, PlaybackSpeed, bRestoreState);
			UE_LOG(LogKGUI, Log, TEXT("[KGUserWidget]%s %s %s"), ANSI_TO_TCHAR(__FUNCTION__),
				*UserWidget->GetName(),
				*WidgetAnimation->GetName());
		}

		Delay = 0;
		bRunning = false;
	}
}

void FKGWidgetSkelAnimTask::Start()
{
	for (auto& SubAnim : SubAnims)
	{
		SubAnim.Start();
	}
	bRunning = true;
}

void FKGWidgetSkelAnimTask::Stop()
{
	for (auto& SubAnim : SubAnims)
	{
		SubAnim.Stop();
	}
}

void FKGWidgetSkelAnimTask::Tick(float InDeltaTime)
{
	if (!bRunning)
	{
		return;
	}
	
	bool bCurRunning = false;
	for (auto& SubAnim : SubAnims)
	{
		if (SubAnim.bRunning)
		{
			bCurRunning = true;
			SubAnim.Tick(InDeltaTime);
		}
	}

	bRunning = bCurRunning;
}

UKGUserWidget::UKGUserWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	// bHasScriptImplementedTick = true;
	bAutoRemoveFromWorld = true;
}


bool UKGUserWidget::Initialize()
{
	bool Result = Super::Initialize();
    CollectAnimTimeOffsetWidgets();
    return Result;
}

void UKGUserWidget::NativeOnInitialized()
{
	if (IsValid(WidgetTree))
	{
		for (auto& Path : PanelRegions)
		{
			if (!Path.WidgetName.IsEmpty())
			{
				if (auto* Widget = WidgetTree->FindWidget(FName(Path.WidgetName)))
				{
					PanelRegionWidgets.Add(Widget);
				}
			}
		}
	}
	
	Super::NativeOnInitialized();

	CollectSubAnimsFromZeorPosition();
}

void UKGUserWidget::InitPCStyle()
{
#if WITH_EDITOR
	const UKGUIPlatformCustomSetting* C7DPISettings = GetDefault<UKGUIPlatformCustomSetting>();
	if (C7DPISettings!= nullptr )
	{
		if (C7DPISettings->EditorPreviewPlatform == EDPIScalePreviewPlatforms::PC)
		{
			PreConstructPCStyle();
		}
	}
#elif PLATFORM_WINDOWS || PLATFORM_MAC
	PreConstructPCStyle();
#endif
}

// void UKGUserWidget::SetStateChanged(const FString& StateName, int Index)
// {
// 	UKGStateManagement* StateManagement = this->GetComponent<UKGStateManagement>();
// 	if (StateManagement)
// 	{
// 		StateManagement->ChangeState(StateName, Index);
// 	}
// }

void UKGUserWidget::PreSave(FObjectPreSaveContext ObjectSaveContext)
{
#if WITH_EDITOR
	auto* WidgetClass = GetClass();
	auto* WidgetSuperClass = WidgetClass->GetSuperClass();
	if(!HasAnyFlags(RF_ArchetypeObject | RF_ClassDefaultObject) || WidgetSuperClass->ClassGeneratedBy != NULL)
	{
		FObjectSaveOverride ObjectSaveOverride;

		auto MarkTransient = [&ObjectSaveOverride](const FName& PropertyName)
		{
			FProperty* OverrideProperty = FindFProperty<FProperty>(StaticClass(), PropertyName);
			check(OverrideProperty);
			FPropertySaveOverride PropOverride;
			PropOverride.PropertyPath = FFieldPath(OverrideProperty);
			PropOverride.bMarkTransient = true;
			ObjectSaveOverride.PropOverrides.Add(PropOverride);
		};

		MarkTransient(GET_MEMBER_NAME_CHECKED(UKGUserWidget, LuaBinder));
		MarkTransient(GET_MEMBER_NAME_CHECKED(UKGUserWidget, OpenMusicEvent));
		MarkTransient(GET_MEMBER_NAME_CHECKED(UKGUserWidget, OpenSoundEvent));

		if (!ObjectSaveOverride.PropOverrides.IsEmpty())
		{
			ObjectSaveContext.AddSaveOverride(this, ObjectSaveOverride);
		}
	}

#endif
	Super::PreSave(ObjectSaveContext);
}

void UKGUserWidget::NativePreConstruct()
{
	Super::NativePreConstruct();

	BuildSubAnimationsMap();
#if PLATFORM_WINDOWS || PLATFORM_MAC || WITH_EDITOR
	InitPCStyle();
#endif
}

void UKGUserWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

void UKGUserWidget::NativeDestruct()
{
	FKGUIModule::Get().RemoveWidgetComponentMap(MakeWeakObjectPtr(this));
	Super::NativeDestruct();
}

FReply UKGUserWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	OnMouseButtonDownMulti.Broadcast(InGeometry, InMouseEvent);
	if (OnMouseButtonDownEvent.IsBound()
#if WITH_EDITOR
		&& !(GEditor && GEditor->bIsSimulatingInEditor)
#endif
		)
	{
		return OnMouseButtonDownEvent.Execute(InGeometry, InMouseEvent).NativeReply;
	}
	return Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
}

FReply UKGUserWidget::NativeOnMouseButtonUp(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	OnMouseButtonUpMulti.Broadcast(InGeometry, InMouseEvent);
	if (OnMouseButtonUpEvent.IsBound()
#if WITH_EDITOR
		&& !(GEditor && GEditor->bIsSimulatingInEditor)
#endif
		)
	{
		return OnMouseButtonUpEvent.Execute(InGeometry, InMouseEvent).NativeReply;
	}
	return Super::NativeOnMouseButtonUp(InGeometry, InMouseEvent);
}

FReply UKGUserWidget::NativeOnMouseButtonDoubleClick(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (OnMouseButtonDoubleClickEvent.IsBound()
#if WITH_EDITOR
		&& !(GEditor && GEditor->bIsSimulatingInEditor)
#endif
		)
	{
		return OnMouseButtonDoubleClickEvent.Execute(InGeometry, InMouseEvent).NativeReply;
	}
	return Super::NativeOnMouseButtonDoubleClick(InGeometry, InMouseEvent);
}

void UKGUserWidget::SetEnableEsc(bool bEnable)
{
	if (bEnable)
	{
		SetIsFocusable(true);
	}
	bEnableEsc = bEnable;
}

void UKGUserWidget::NativeOnFocusLost(const FFocusEvent& InFocusEvent)
{
	if (OnFocusLostEvent.IsBound())
	{
		return OnFocusLostEvent.Execute(InFocusEvent);
	}
	Super::NativeOnFocusLost(InFocusEvent);
}

FReply UKGUserWidget::NativeOnTouchStarted(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	OnTouchStartedMulti.Broadcast(InGeometry, InGestureEvent);
	if (OnTouchStartedEvent.IsBound())
	{
		return OnTouchStartedEvent.Execute(InGeometry, InGestureEvent).NativeReply;
	}

	return Super::NativeOnTouchStarted(InGeometry, InGestureEvent);
}

FReply UKGUserWidget::NativeOnTouchMoved(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	OnTouchMovedMulti.Broadcast(InGeometry, InGestureEvent);
	if (OnTouchMovedEvent.IsBound())
	{
		return OnTouchMovedEvent.Execute(InGeometry, InGestureEvent).NativeReply;
	}

	return Super::NativeOnTouchMoved(InGeometry, InGestureEvent);
}

FReply UKGUserWidget::NativeOnTouchEnded(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	OnTouchEndedMulti.Broadcast(InGeometry, InGestureEvent);
	if (OnTouchEndedEvent.IsBound())
	{
		return OnTouchEndedEvent.Execute(InGeometry, InGestureEvent).NativeReply;
	}

	return Super::NativeOnTouchEnded(InGeometry, InGestureEvent);
}

void UKGUserWidget::NativeOnMouseEnter(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	if (OnMouseEnterEvent.IsBound()
#if WITH_EDITOR
		&& !(GEditor && GEditor->bIsSimulatingInEditor)
#endif
		)
	{
		OnMouseEnterEvent.Execute(InGeometry, InGestureEvent);
	}
	else
	{
		Super::NativeOnMouseEnter(InGeometry, InGestureEvent);
	}
}

FReply UKGUserWidget::NativeOnMouseMove(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	OnMouseMoveMulti.Broadcast(InGeometry, InGestureEvent);
	if (OnMouseMoveEvent.IsBound()
#if WITH_EDITOR
		&& !(GEditor && GEditor->bIsSimulatingInEditor)
#endif
		)
	{
		return OnMouseMoveEvent.Execute(InGeometry, InGestureEvent).NativeReply;
	}

	return Super::NativeOnMouseMove(InGeometry, InGestureEvent);
}

void UKGUserWidget::NativeOnMouseLeave(const FPointerEvent& InMouseEvent)
{
	if (OnMouseLeaveEvent.IsBound()
#if WITH_EDITOR
		&& !(GEditor && GEditor->bIsSimulatingInEditor)
#endif
	)
	{
		OnMouseLeaveEvent.Execute(InMouseEvent);
	}
	else
	{
		Super::NativeOnMouseLeave(InMouseEvent);
	}
}

FReply UKGUserWidget::NativeOnPreviewMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (OnPreviewMouseButtonDownEvent.IsBound())
	{
		return OnPreviewMouseButtonDownEvent.Execute(InGeometry, InMouseEvent).NativeReply;
	}

	return Super::NativeOnPreviewMouseButtonDown(InGeometry, InMouseEvent);
}

void UKGUserWidget::NativeOnDragEnter(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent,
                                      UDragDropOperation* InOperation)
{
	if (OnDragEnterEvent.IsBound())
	{
		OnDragEnterEvent.Execute(InGeometry, InDragDropEvent, InOperation);
	}
	else
	{
		Super::NativeOnDragEnter(InGeometry, InDragDropEvent, InOperation);
	}
}

bool UKGUserWidget::NativeOnDragOver(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent,
                                     UDragDropOperation* InOperation)
{
	if (OnDragOverEvent.IsBound())
	{
		return OnDragOverEvent.Execute(InGeometry, InDragDropEvent, InOperation);
	}

	return Super::NativeOnDragOver(InGeometry, InDragDropEvent, InOperation);
}

void UKGUserWidget::NativeOnDragLeave(const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation)
{
	if (OnDragLeaveEvent.IsBound())
	{
		OnDragLeaveEvent.Execute(InDragDropEvent, InOperation);
	}
	else
	{
		Super::NativeOnDragLeave(InDragDropEvent, InOperation);
	}
}

void UKGUserWidget::NativeOnDragCancelled(const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation)
{
	
	if (OnDragCancelledEvent.IsBound())
	{
		OnDragCancelledEvent.Execute(InDragDropEvent, InOperation);
	}
	else
	{
		Super::NativeOnDragCancelled(InDragDropEvent, InOperation);
	}
}

void UKGUserWidget::NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent,
                                         UDragDropOperation*& OutOperation)
{
	if (OnDragDetectedEvent.IsBound())
	{
		const auto Out = OnDragDetectedEvent.Execute(InGeometry, InMouseEvent);

		if (Out != nullptr)
		{
			OutOperation = Out;
		}
	}
	else
	{
		Super::NativeOnDragDetected(InGeometry, InMouseEvent, OutOperation);
	}
}

bool UKGUserWidget::NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent,
                                 UDragDropOperation* InOperation)
{
	if (OnDropEvent.IsBound())
	{
		return OnDropEvent.Execute(InGeometry, FPointerEvent(InDragDropEvent), InOperation);
	}

	return Super::NativeOnDrop(InGeometry, InDragDropEvent, InOperation);
}

int32 UKGUserWidget::NativePaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry,
                                 const FSlateRect& MyCullingRect,
                                 FSlateWindowElementList& OutDrawElements, int32 LayerId,
                                 const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	if (OnPaintEvent.IsBound())
	{
		const FPaintContext Context(AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle,
		                            bParentEnabled);

		OnPaintEvent.Execute(Context);
	}

	return Super::NativePaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle,
	                          bParentEnabled);
}

FReply UKGUserWidget::NativeOnMouseWheel(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (OnMouseWheelEvent.IsBound()
#if WITH_EDITOR
&& !(GEditor && GEditor->bIsSimulatingInEditor)
#endif
		)
	{
		return OnMouseWheelEvent.Execute(InGeometry, InMouseEvent).NativeReply;
	}

	return Super::NativeOnMouseWheel(InGeometry, InMouseEvent);
}


bool UKGUserWidget::NativeOnC7Touch(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	if (bBlockC7Touch)
		return true;
	if (OnC7TouchEvent.IsBound())
	{
		OnC7TouchEvent.Execute(MyGeometry, InTouchEvent);
	}

	//UE_LOG(LogTemp, Warning, TEXT("NativeOnC7Touch=%s"), *GetFullName());
	return false;
}

void UKGUserWidget::NativeTick(const FGeometry& InGeometry, float InDeltaTime)
{
	Super::NativeTick(InGeometry, InDeltaTime);

	for (auto& Pair : SkeletalAnimTasks)
	{
		Pair.Value.Tick(InDeltaTime);
	}
}

bool UKGUserWidget::NativeSupportsKeyboardFocus() const
{
#if WITH_EDITOR
	const bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#else
	const static bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#endif
	if (bDisableFocusableGlobally)
	{
		return false;
	}
	return Super::NativeSupportsKeyboardFocus();
}

#if WITH_EDITOR
void UKGUserWidget::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property &&
		(PropertyChangedEvent.Property->GetFName() == GET_MEMBER_NAME_CHECKED(UKGUserWidget, OpenMusicEvent) ||
		PropertyChangedEvent.Property->GetFName() == GET_MEMBER_NAME_CHECKED(UKGUserWidget, OpenSoundEvent)))
	{
		const auto& MusicSoftObjectPath = OpenMusicEvent.ToSoftObjectPath();
		if (MusicSoftObjectPath.IsValid())
		{
			// 音乐路径检查
			FString MusicEventName = MusicSoftObjectPath.GetAssetName();
			if (!MusicEventName.StartsWith("Set_MUS_"))
			{
				UE_LOG(LogTemp, Warning, TEXT("OpenMusicEvent can only set AkAudioEvent start with Set_MUS_"))
				OpenMusicEvent.Reset();
			}
		}

		const auto& SoundSoftObjectPath = OpenSoundEvent.ToSoftObjectPath();
		if (SoundSoftObjectPath.IsValid())
		{
			// 音乐路径检查
			FString SoundEventName = SoundSoftObjectPath.GetAssetName();
			if (SoundEventName.StartsWith("Set_MUS_"))
			{
				UE_LOG(LogTemp, Warning, TEXT("OpenMusicEvent cannot set AkAudioEvent start with Set_MUS_"))
				OpenSoundEvent.Reset();
			}
		}
	}
}

const FText UKGUserWidget::GetPaletteCategory()
{
	if (auto WidgetBlueprintGeneratedClass = Cast<UWidgetBlueprintGeneratedClass>(GetClass()))
	{
		if (auto Blueprint = Cast<UBlueprint>(WidgetBlueprintGeneratedClass->ClassGeneratedBy))
		{
			if (!Blueprint->BlueprintCategory.IsEmpty())
			{
				return FText::FromString(Blueprint->BlueprintCategory);
			}
		}
	}
	return Super::GetPaletteCategory();
}

#endif

void UKGUserWidget::PreviewTimeOffsetInDesignTime(const FString& InAnimName)
{
#if WITH_EDITOR
    if (!IsDesignTime())
    {
        return;
    }
    
    if (UWidgetAnimation* Anim = GetAnimationByName(InAnimName))
    {
        SetAnimTimeOffset(Anim);
    }
#endif
}

void UKGUserWidget::CheckTemplateBPAdaptation(float NewPaddingValue)
{
	TArray<UUserWidget*> TempChildren = UUIFunctionLibrary::GatherAllWBP(this);
	TArray<TWeakObjectPtr<UUserWidget>> Children;
	for (auto child : TempChildren)
	{
		if(child)
			Children.Add(child);
	}

	for(auto& element : paddingSubOffset)
	{
		if(!Children.Find(element.Key))
			paddingSubOffset.Remove(element.Key);
	}
	for(auto& child : Children)
	{
		if(child != this)
		{
			UKGUserWidget* kgChild = Cast<UKGUserWidget>(child);
			if(kgChild!=nullptr && kgChild->bAdaptForShapedScreen != EAdaptShapedScreenType::None)
			{
				if(!adaptDealingWBPList.Find(child))
					DoAdaptForNode(kgChild, kgChild->bAdaptForShapedScreen, NewPaddingValue);
			}
		}
	}
}

void UKGUserWidget::DoAdaptForNode(TWeakObjectPtr<UUserWidget> Node, EAdaptShapedScreenType bAdapt, float NewPaddingValue)
{
	float oldPaddingValue = 0;
	if(paddingSubOffset.Contains(Node))
		oldPaddingValue = paddingSubOffset[Node];
	float offset = NewPaddingValue - oldPaddingValue;
	if(offset == 0) return;

	bool leftPadding = false, rightPadding = false;
	if ((static_cast<uint8>(bAdapt) & 1) == 1)
		leftPadding = true;
	if ((static_cast<uint8>(bAdapt) >> 1) == 1)
		rightPadding = true;

	FMargin newMargin = Node->GetPadding() +
		FMargin(leftPadding ? offset : 0,
			0,
			rightPadding ? offset : 0,
			0);
	Node->SetPadding(newMargin);
	UKGUserWidget* kgNode = Cast<UKGUserWidget>(Node);
	if(kgNode != nullptr)
	{
		for(auto nodeName : kgNode->UnAdaptedNodeArr)
		{
			TWeakObjectPtr<UWidget> widget;
			widget = kgNode->GetWidgetFromName(FName(nodeName));
			if(widget != nullptr)
				// UnAdaptNode(widget, leftPadding, rightPadding, bChildUnAdapt ? offset : 2 * offset);
				UnAdaptNode(widget, leftPadding, rightPadding, offset);
		}
	}
	paddingSubOffset.Emplace(Node, NewPaddingValue);
}

void UKGUserWidget::UnAdaptNode(TWeakObjectPtr<UWidget> UnAdaptedNode, bool bLeftPadding, bool bRightPadding, float offset)
{
	if(UnAdaptedNode!=nullptr && UnAdaptedNode.IsValid())
	{
		if(UnAdaptedNode->IsA<UUserWidget>())
		{
			auto curNode = Cast<UUserWidget>(UnAdaptedNode);
			FMargin newMargin =curNode->GetPadding() +
				FMargin(bLeftPadding ? -offset : 0,
					0,
					bRightPadding ? -offset : 0,
					0);
			curNode->SetPadding(newMargin);
		}
		else if(UnAdaptedNode->GetParent() == nullptr)
		{
			if(UnAdaptedNode->IsA<UUserWidget>())
			{
				auto curNode = Cast<UUserWidget>(UnAdaptedNode);
				FMargin newMargin =curNode->GetPadding() +
					FMargin(bLeftPadding ? -offset : 0,
						0,
						bRightPadding ? -offset : 0,
						0);
				curNode->SetPadding(newMargin);
			}
		}
		else if(UnAdaptedNode->GetParent()->IsA<UOverlay>())
		{
			DealWithParentOverLay(Cast<UPanelWidget>(UnAdaptedNode), bLeftPadding, bRightPadding, offset);
		}
		else if(UnAdaptedNode->GetParent()->IsA<UCanvasPanel>())
		{
			DealWithParentCanvasPanel(Cast<UPanelWidget>(UnAdaptedNode), bLeftPadding, bRightPadding, offset);
		}
		else if(UnAdaptedNode->IsA<UCanvasPanel>() || UnAdaptedNode->IsA<UOverlay>() || UnAdaptedNode->IsA<UScaleBox>())
		{
			if (Cast<UPanelWidget>(UnAdaptedNode))
			{
				auto childrenWidget = Cast<UPanelWidget>(UnAdaptedNode)->GetAllChildren();
				for(auto child : childrenWidget)
					UnAdaptNode(Cast<UUserWidget>(child), bLeftPadding, bRightPadding, offset);
			}
		}
		
	}
}

void UKGUserWidget::DealWithParentOverLay(TWeakObjectPtr<UPanelWidget> UnAdaptedNode, bool bLeftPadding, bool bRightPadding, float offset)
{
	if(UnAdaptedNode == nullptr) return;
	auto slot = Cast<UOverlaySlot>(UnAdaptedNode->Slot);
	if(slot != nullptr)
	{
		FMargin newMargin = slot->GetPadding() +
			FMargin(bLeftPadding ? -offset : 0,
				0,
				bRightPadding ? -offset : 0,
				0);
		// FMargin oldMargin = slot->GetPadding();
		// FMargin newMargin = FMargin(bLeftPadding ? oldMargin.Left-offset : 0,
		// oldMargin.Top,
		// bRightPadding ? oldMargin.Right-offset : 0,
		// oldMargin.Bottom
		// 	);
		slot->SetPadding(newMargin);
	}
}

void UKGUserWidget::DealWithParentCanvasPanel(TWeakObjectPtr<UPanelWidget> UnAdaptedNode, bool bLeftPadding, bool bRightPadding, float offset)
{
	if(UnAdaptedNode == nullptr) return;
	auto slot = Cast<UCanvasPanelSlot>(UnAdaptedNode->Slot);
	if(slot != nullptr)
	{
		FMargin newMargin = slot->GetOffsets() +
			FMargin(bLeftPadding ? -offset : 0,
				0,
				bRightPadding ? -offset : 0,
				0);
		slot->SetOffsets(newMargin);
	}
}


void UKGUserWidget::C7CallUMGAnimationNotify(int32 Index)
{
	if (OnAnimationCustomEvent.IsBound()) 
	{
		OnAnimationCustomEvent.Broadcast(Index);
	}
	if (UMGAnimationNotifyEvents[Index])
	{
		UMGAnimationNotifyEvents[Index]->Delegate.ExecuteIfBound();
	}
}


#if WITH_EDITOR
TArray<FString> UKGUserWidget::GetAllAnimationNames() const
{
	TArray<FString> Anis;
	GetAllAnimationNames_Internal(Anis, GetWidgetTreeOwningClass(), "");
	// Update widget blueprint names
	return Anis;
}

void UKGUserWidget::GetAllAnimationNames_Internal(TArray<FString>& Anis, UWidgetBlueprintGeneratedClass* WidgetBlueprint, FString prefix) const
{
	//UWidgetBlueprintGeneratedClass* WidgetBlueprint = GetWidgetTreeOwningClass();
	TObjectPtr<UWidgetTree> WBP_WidgetTree = WidgetBlueprint->GetWidgetTreeArchetype();
	TArray<UWidget*> WidgetsNode;

	WBP_WidgetTree->GetAllWidgets(WidgetsNode);

	for (int j = 0; j < WidgetsNode.Num(); ++j)
	{
		if (UUserWidget* C7UserWidget = Cast<UUserWidget>(WidgetsNode[j]))
		{
			if (prefix.EndsWith("_lua/"))
			{
				prefix.RemoveFromEnd("_lua/");
				prefix = prefix + "/";
			}
			GetAllAnimationNames_Internal(Anis, C7UserWidget->GetWidgetTreeOwningClass(), prefix + (WidgetsNode[j]->GetDisplayLabel().Len() > 0 ? WidgetsNode[j]->GetDisplayLabel() : WidgetsNode[j]->GetName()) + "/");
		}
	}
	for (UWidgetAnimation* WidgetAnimation : WidgetBlueprint->Animations)
	{
		Anis.Add(prefix + WidgetAnimation->GetDisplayLabel());
	}
}
#endif

void UKGUserWidget::PlaySubAnimation(UWidgetAnimation* InAnimation, float StartAtTime, int32 NumberOfLoops, EUMGSequencePlayMode::Type PlayMode, float PlaybackSpeed, bool bRestoreState)

{
	SCOPED_NAMED_EVENT_TEXT("Widget::PlaySubAnimation", FColor::Emerald);
	if (InAnimation)
	{
		bool bDT = IsDesignTime();
		if (GPlayMainAndSubAnimAtTheSameTime && bDT == false)
		{
			QueuePlayAnimation(InAnimation, StartAtTime, NumberOfLoops, PlayMode, PlaybackSpeed, bRestoreState);
		}
		else
		{
			PlayAnimationInternal(InAnimation, StartAtTime, NumberOfLoops, PlayMode, PlaybackSpeed, bRestoreState);
		}	
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[UKGUserWidget::PlaySubAnimation] InAnimation is invalid."))
	}
	
	
}

void UKGUserWidget::Serialize(FArchive& Ar)
{
	if (Ar.IsCooking())
	{

	}
	else if (Ar.IsSaving() && !Ar.IsCooking())
	{
		CollectSubAnimations();
	}
	
	Super::Serialize(Ar);
}

void UKGUserWidget::PlayOpenMusic()
{
	RealPlayAudio(OpenMusicEvent);
}

void UKGUserWidget::PlayOpenSound()
{
	RealPlayAudio(OpenSoundEvent);
}

bool UKGUserWidget::HasOpenMusicOrSound()
{
	const auto& MusicSoftObjectPath = OpenMusicEvent.ToSoftObjectPath();
	const auto& SoundSoftObjectPath = OpenSoundEvent.ToSoftObjectPath();
	return MusicSoftObjectPath.IsValid() or SoundSoftObjectPath.IsValid();
}

void UKGUserWidget::RealPlayAudio(const TSoftObjectPtr<class UAkAudioEvent>& InSoftEvent)
{
	if (auto AudioManager = UKGAkAudioManager::GetInstance(this))
	{
		const auto& SoftEventPath = InSoftEvent.ToSoftObjectPath();
		if (SoftEventPath.IsValid())
		{
			AudioManager->InnerPostEvent3D(SoftEventPath.GetAssetName());
		}		
	}
}

TSharedRef<SWidget> UKGUserWidget::RebuildWidget()
{
	
#if WITH_EDITOR
	if (IsDesignTime())
	{
		// 编辑器环境下，检测下所有的umg动画timeline，获取到对应的UWidget，将它们的PixelSnapping属性置为Disabled:解决UMG动画播放过程中widget线条采样抖动的问题.
		UWidgetBlueprintGeneratedClass* MyWidgetBlueprint = GetWidgetTreeOwningClass();
		for (UWidgetAnimation* WidgetAnimation : MyWidgetBlueprint->Animations)
		{
			auto AnimationBindInfos = WidgetAnimation->AnimationBindings;
			for (const auto WidgetBindInfo: AnimationBindInfos)
			{
				FName WidgetName = WidgetBindInfo.WidgetName;
				if (WidgetTree)
				{
					if (UWidget* Widget = WidgetTree->FindWidget(WidgetName))
					{
						Widget->SetPixelSnapping(EWidgetPixelSnapping::Disabled);
					}	
				}
			}
		}
		// 预处理动画相关数据
		GetAllAutoAnimationInfo();
	}
#endif
	
	return Super::RebuildWidget();
}

#if WITH_EDITOR
void UKGUserWidget::GetAllAutoAnimationInfo()
{
	bHadAutoAnimationInfo = true;
	KGAnimInList.Empty();
	KGAnimOutList.Empty();
	FString AutoAnimationInName = GetDefault<UKGUISettings>()->OpenAnimationName;
	FString AutoAnimationOutName = GetDefault<UKGUISettings>()->CloseAnimationName;

	bool ContainChildAnimIn = true;		//是否播放子蓝图入场动画
	bool ContainChildAnimOut = true;		//是否播放子蓝图出场动画
	
	// 处理根节点蓝图动效
	if (UWidgetBlueprintGeneratedClass* BPRootGeneratedClass = this->GetWidgetTreeOwningClass())
	{
		for (int32 i = 0; i < BPRootGeneratedClass->Animations.Num(); i++)
		{
			TObjectPtr<UWidgetAnimation> Animation = BPRootGeneratedClass->Animations[i];
			if (Animation->GetMovieScene()->GetName() == AutoAnimationInName)
			{
				ContainChildAnimIn = false;
				float EndTime = Animation->GetEndTime();
				if (EndTime > KGAnimMaxInTime)
				{
					KGAnimMaxInTime = EndTime;
				}
				// KGAnimInList.Add(this->GetDisplayLabel());
			}
			
			if (Animation->GetMovieScene()->GetName() == AutoAnimationOutName)
			{
				ContainChildAnimOut = false;
				float EndTime = Animation->GetEndTime();
				if (EndTime > KGAnimMaxOutTime)
				{
					KGAnimMaxOutTime = EndTime;
				}
				// KGAnimOutList.Add(this->GetDisplayLabel());
			}
		}
	}

	if(!ContainChildAnimIn && !ContainChildAnimOut)
	{
		return;
	}
	
	// 遍历子节点蓝图动效
	if (TObjectPtr<UWidgetTree> WBPWidgetTree = this->WidgetTree)
	{
		TArray<UWidget*> Widgets;
		WBPWidgetTree->GetAllWidgets(Widgets);
		for (int32 Index = 0; Index < Widgets.Num(); ++Index)
		{
			UWidget* CWidget = Widgets[Index];
			if (CWidget == nullptr)
			{
				continue;
			}
			if (UUserWidget* UserWidget = Cast<UUserWidget>(CWidget))
			{
				if (UWidgetBlueprintGeneratedClass* BPGeneratedClass = UserWidget->GetWidgetTreeOwningClass())
				{
					for (int32 i = 0; i < BPGeneratedClass->Animations.Num(); i++)
					{
						TObjectPtr<UWidgetAnimation> Animation = BPGeneratedClass->Animations[i];
						if (ContainChildAnimIn && Animation->GetMovieScene()->GetName() == AutoAnimationInName)
						{
							float EndTime = Animation->GetEndTime();
							if (EndTime > KGAnimMaxInTime)
							{
								KGAnimMaxInTime = EndTime;
							}
							KGAnimInList.Add(UserWidget->GetDisplayLabel());
						}

						if (ContainChildAnimOut && Animation->GetMovieScene()->GetName() == AutoAnimationOutName)
						{
							float EndTime = Animation->GetEndTime();
							if (EndTime > KGAnimMaxOutTime)
							{
								KGAnimMaxOutTime = EndTime;
							}
							KGAnimOutList.Add(UserWidget->GetDisplayLabel());
						}
					}
				}
			}
		}
	}
}

void UKGUserWidget::ValidateCompiledWidgetTree(const UWidgetTree& BlueprintWidgetTree, class IWidgetCompilerLog& CompileLog) const
{
	FKGUIModule::Get().GetOnUserWidgetValidating().Broadcast(this, BlueprintWidgetTree, CompileLog);
	Super::ValidateCompiledWidgetTree(BlueprintWidgetTree, CompileLog);
}
#endif

UWidgetAnimation* UKGUserWidget::GetWidgetAnimationByName(UUserWidget* Widget, FString AnimationName)
{
	UWidgetBlueprintGeneratedClass* BPGeneratedClass = Widget->GetWidgetTreeOwningClass();
	TArray<TObjectPtr<UWidgetAnimation>>& WidgetAnimations = BPGeneratedClass->Animations;
	for (UWidgetAnimation* Animation : WidgetAnimations)
	{
		if (Animation && Animation->MovieScene && Animation->MovieScene->GetName() == AnimationName)
		{
			return Animation;
		}
	}

	if (SkeletalAnimInstances.Contains(AnimationName))
	{
		return SkeletalAnimInstances[AnimationName];
	}
	
	return nullptr;
}

#pragma region 特殊动画

bool UKGUserWidget::PlaySkeletalAnimation(const FString& AnimName, float StartAtTime, int32 NumLoopsToPlay, EUMGSequencePlayMode::Type PlayMode, float
PlaybackSpeed, bool bRestoreState)
{
	if (AnimName.IsEmpty())
	{
		return false;
	}

	if (UWidgetAnimation* Anim = FindOrCreateSkeletalAnimation(AnimName))
	{
		if (AnimName == GetDefault<UKGUISettings>()->OpenAnimationName && AnimFadeInDelayTimes.Num() > 0)
		{
			FKGWidgetSkelAnimTask& Task = SkeletalAnimTasks.FindOrAdd(AnimName);
			Task.SubAnims.Empty(Task.SubAnims.GetSlack());

			for (const auto& Pair : SubFadeInAnimations)
			{
				FKGWidgetSkelSubAnimTask& SubAnimTask = Task.SubAnims.AddDefaulted_GetRef();
				SubAnimTask.UserWidget = Pair.Key;
				SubAnimTask.WidgetAnimation = Pair.Value;
				SubAnimTask.Delay = AnimFadeInDelayTimes.Contains(Pair.Key->GetName()) ? AnimFadeInDelayTimes[Pair.Key->GetName()] : 0;
				SubAnimTask.StartAtTime = StartAtTime;
				SubAnimTask.NumLoopsToPlay = NumLoopsToPlay;
				SubAnimTask.PlayMode = PlayMode;
				SubAnimTask.PlaybackSpeed = PlaybackSpeed;
				SubAnimTask.bRestoreState = bRestoreState;
			}
			Task.Start();
		}
		
		PlayAnimation(Anim, StartAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed, bRestoreState);
		return true;
	}

	return false;
}

void UKGUserWidget::StopSkeletalAnimation(const FString& AnimName)
{
	if (UWidgetAnimation* Animation = GetSkeletalAnimation(AnimName, false))
	{
		StopAnimation(Animation);
	}
}

void UKGUserWidget::CollectSubAnimations()
{
	if (!IsValid(Skeletal))
	{
		return;
	}
	
	UWidgetBlueprintGeneratedClass* Class = GetWidgetTreeOwningClass();
	if (!Class || !Class->GetWidgetTreeArchetype())
	{
		return;
	}

	const FString& AnimFadeInName = GetDefault<UKGUISettings>()->OpenAnimationName;
	TArray<UWidget*> AllWidgets;
	Class->GetWidgetTreeArchetype()->GetAllWidgets(AllWidgets);
	for (UWidget* Widget : AllWidgets)
	{
		if (UKGUserWidget* UserWidget = Cast<UKGUserWidget>(Widget))
		{
			if (UWidgetBlueprintGeneratedClass* BPGeneratedClass = UserWidget->GetWidgetTreeOwningClass())
			{
				for (auto& Animation : BPGeneratedClass->Animations)
				{
					if (Animation->GetMovieScene()->GetName() == AnimFadeInName)
					{
						AnimFadeInDelayTimes.Add(UserWidget->GetName(), UserWidget->FadeInDelayTime);
					}
				}
			}
		}
	}
}

void UKGUserWidget::BuildSubAnimationsMap()
{
	if (Skeletal && WidgetTree && AnimFadeInDelayTimes.Num() > 0)
	{
		const FString& AnimFadeInName = GetDefault<UKGUISettings>()->OpenAnimationName;
		TArray<UWidget*> AllWidgets;
		WidgetTree->GetAllWidgets(AllWidgets);
		for (UWidget* Widget : AllWidgets)
		{
			if (AnimFadeInDelayTimes.Contains(Widget->GetName()) && Widget->IsA<UUserWidget>())
			{
				if (UUserWidget* UserWidget = Cast<UUserWidget>(Widget))
				{
					if (UWidgetBlueprintGeneratedClass* Class = UserWidget->GetWidgetTreeOwningClass())
					{
						for (auto& Anim : Class->Animations)
						{
							if (Anim && Anim->GetMovieScene()->GetName() == AnimFadeInName)
							{
								SubFadeInAnimations.Add(UserWidget, Anim);
							}
						}
					}
				}
			}
		}
	}
}

UWidgetAnimation* UKGUserWidget::GetSkeletalAnimation(const FString& AnimationName, bool bCreateOnFound)
{
	if (bCreateOnFound)
	{
		return FindOrCreateSkeletalAnimation(AnimationName);
	}

	if (SkeletalAnimInstances.Contains(AnimationName))
	{
		return SkeletalAnimInstances[AnimationName];
	}

	return nullptr;
}

UWidgetAnimation* UKGUserWidget::FindOrCreateSkeletalAnimation(const FString& AnimationName)
{
	TArray<UWidgetAnimation*> WidgetAnimations = GetAnimationsFromSkeletal();
	for (UWidgetAnimation* WidgetAnimation : WidgetAnimations)
	{
		if (WidgetAnimation->MovieScene)
		{
			FString AnimName = WidgetAnimation->MovieScene->GetName();
			if (AnimName == AnimationName)
			{
				return WidgetAnimation;
			}
		}
	}

	if (SkeletalAnimInstances.Contains(AnimationName))
	{
		return SkeletalAnimInstances[AnimationName];
	}

	if (auto* Instance = DuplicateAnimFromSkeletal(AnimationName))
	{
		SkeletalAnimInstances.Add(AnimationName, Instance);
		return Instance;
	}

	return nullptr;		
}

TArray<UWidgetAnimation*> UKGUserWidget::GetAnimationsFromSkeletal() const
{
	TArray<UWidgetAnimation*> WidgetAnimations;

	if(Skeletal)
	{
		if (UWidgetBlueprintGeneratedClass* Class = Skeletal->GetWidgetTreeOwningClass())
		{
			return Class->Animations;
		}
	}
	
	// FProperty* Property = GetClass()->PropertyLink;
	// while (Property)
	// {
	// 	if (Property->GetClass() == FObjectProperty::StaticClass())
	// 	{
	// 		FObjectProperty* ObjectProperty = CastField<FObjectProperty>(Property);
	// 		if (ObjectProperty->PropertyClass == UWidgetAnimation::StaticClass())
	// 		{
	// 			UObject* Obj = ObjectProperty->GetObjectPropertyValue_InContainer(this);
	// 			UWidgetAnimation* WidgetAnimation = Cast<UWidgetAnimation>(Obj);
	// 			if (WidgetAnimation)
	// 			{
	// 				WidgetAnimations.Add(WidgetAnimation);
	// 			}
	// 		}
	// 	}
	// 	Property = Property->PropertyLinkNext;
	// }

	return WidgetAnimations;
}

UWidgetAnimation* UKGUserWidget::DuplicateAnimFromSkeletal(const FString& InAnimName)
{
	TArray<UWidgetAnimation*> WidgetAnimations = GetAnimationsFromSkeletal();
	for (UWidgetAnimation* WidgetAnimation : WidgetAnimations)
	{
		UMovieScene* MovieScene = WidgetAnimation->GetMovieScene();
		if (MovieScene != nullptr && MovieScene->GetName() == InAnimName)
		{
			return CreateNewWidgetAnim(WidgetAnimation);
		}
	}

	return nullptr;
}

UWidgetAnimation* UKGUserWidget::CreateNewWidgetAnim(const UWidgetAnimation* CloneFrom)
{
	UWidgetAnimation* NewAnimation = NewObject<UWidgetAnimation>(this, FName(*CloneFrom->GetName()));
	NewAnimation->DefaultCompletionMode = CloneFrom->DefaultCompletionMode;

#if WITH_EDITOR
	NewAnimation->SetDisplayLabel(CloneFrom->GetDisplayLabel());
#endif

	//NewAnimation->PrecompiledEvaluationTemplate = CloneFrom->PrecompiledEvaluationTemplate;
	NewAnimation->MovieScene = CloneFrom->MovieScene;

	NewAnimation->AnimationBindings.Empty();
	NewAnimation->AnimationBindings.Append(CloneFrom->AnimationBindings);

	return NewAnimation;
}

UUMGSequencePlayer* UKGUserWidget::PlayAnimation(
	UWidgetAnimation* InAnimation,
	float StartAtTime,
	int32 NumLoopsToPlay,
	EUMGSequencePlayMode::Type PlayMode,
	float PlaybackSpeed,
	bool bRestoreState
)
{
	if (InAnimation == nullptr)
	{
		return nullptr;
	}
	return PlayAnimationInternal(InAnimation, StartAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed, bRestoreState);
}

UUMGSequencePlayer* UKGUserWidget::PlayAnimationInternal(
	UWidgetAnimation* InAnimation,
	float StartAtTime,
	int32 NumLoopsToPlay,
	EUMGSequencePlayMode::Type PlayMode,
	float PlaybackSpeed,
	bool bRestoreState
)
{
	if (IsValid(InAnimation))
	{
		SetAnimTimeOffset(InAnimation);
		auto Player = Super::PlayAnimation(InAnimation, StartAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed, bRestoreState);
		if (Player == nullptr)
		{
			UE_LOG(LogKGUI, Error, TEXT("未知原因导致播放动画失败，正在尝试播放%s动画。(%s)\n%s"), *InAnimation->GetName(), *this->GetClass()->GetPathName(), *FKGUIModule::GetLuaTraceback());
			return nullptr;
		}
		return Player;	
	}

	UE_LOG(LogTemp, Warning, TEXT("[UKGUserWidget::PlayAnimationInternal] InAnimation is invalid."))
	return nullptr;
}

float UKGUserWidget::PlayAnimationWithCallbacksInternal(
	UWidgetAnimation* InAnimation,
	float StartAtTime,
	int32 NumLoopsToPlay,
	EUMGSequencePlayMode::Type PlayMode,
	float PlaybackSpeed,
	bool bRestoreState,
	const FWidgetAnimationDynamicEvent& OnFinished,
	const FWidgetAnimationDynamicEvent& OnInterrupted
)
{
	if (IsValid(InAnimation))
	{
		// 先主动解绑下原先InAnimation上的所有回调，防止反复调用导致多次回调绑定
		UnbindAllFromAnimationFinished(InAnimation);
		UnbindAllFromAnimationInterrupted(InAnimation);

		if (OnFinished.IsBound())
		{
			BindToAnimationFinished(InAnimation, OnFinished);
		}

		if (OnInterrupted.IsBound())
		{
			BindToAnimationInterrupted(InAnimation, OnInterrupted);
		}

		auto Player = PlayAnimationInternal(InAnimation, StartAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed, bRestoreState);
		if (Player == nullptr)
		{
			return -1;
		}
		auto Animation = Player->GetAnimation();
		if (Animation == nullptr)
		{
			return -1;
		}
		return (Animation->GetEndTime() - Animation->GetStartTime()) / PlaybackSpeed;
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[UKGUserWidget::PlayAnimationWithCallbacksInternal] InAnimation is invalid."))
	}
	

	return .0f;
}

void UKGUserWidget::GotoAnimation(UWidgetAnimation* InAnimation, float TargetTime)
{
	if (IsValid(InAnimation))
	{
		SetAnimTimeOffset(InAnimation);
		PlayAnimationTimeRange(InAnimation, TargetTime, TargetTime + FrameMinusInterval);	
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[UKGUserWidget::GotoAnimation] InAnimation is invalid."))
	}
}

void UKGUserWidget::PlayAnimationToStart(UWidgetAnimation* InAnimation)
{
	if (IsValid(InAnimation))
	{
		SetAnimTimeOffset(InAnimation);
		PlayAnimationTimeRange(InAnimation, InAnimation->GetStartTime(), InAnimation->GetStartTime() + FrameMinusInterval);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[UKGUserWidget::PlayAnimationToStart] InAnimation is invalid."))
	}
}

void UKGUserWidget::PlayAnimationToEnd(UWidgetAnimation* InAnimation)
{
	if (IsValid(InAnimation))
	{
		SetAnimTimeOffset(InAnimation);
		PlayAnimationTimeRange(InAnimation, InAnimation->GetEndTime() - FrameMinusInterval, InAnimation->GetEndTime());	
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[UKGUserWidget::PlayAnimationToEnd] InAnimation is invalid."))
	}
    
}

float UKGUserWidget::PlayAnimationWithCallbacks(
	UWidgetAnimation* InAnimation,
	float StartAtTime,
	int32 NumLoopsToPlay,
	EUMGSequencePlayMode::Type PlayMode,
	float PlaybackSpeed,
	bool bRestoreState,
	const FWidgetAnimationDynamicEvent& InOnFinished,
	const FWidgetAnimationDynamicEvent& InOnInterrupted
)
{
	if (IsValid(InAnimation))
	{
		// 业务需求：如果当前动画正在播放，先执行一次打断回调，再将动画sequence重置到第一帧
		if (IsAnimationPlaying(InAnimation))
		{
			UE_LOG(LogTemp, Log, TEXT("[UKGUserWidget::PlayAnimationWithCallbacks] Widget:%s Play Same Animation when animation is not finished, call interrupted function."), *this->GetName());
			InOnInterrupted.ExecuteIfBound();
		}
		float ret = PlayAnimationWithCallbacksInternal(InAnimation, StartAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed, bRestoreState, InOnFinished, InOnInterrupted);

		PlaySubAnimFromZeroPosition(InAnimation);

		return ret;	
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[UKGUserWidget::PlayAnimationWithCallbacks] InAnimation is invalid."))
	}
	return .0f;
}

void UKGUserWidget::PlayAnimationWithID(UWidgetAnimation* InAnimation, float StartAtTime, int32 NumLoopsToPlay, EUMGSequencePlayMode::Type PlayMode, float PlaybackSpeed, bool bRestoreState, int32 OnFinishedID, int32 OnInterruptedID)
{
	if (IsValid(InAnimation))
	{
		FWidgetAnimationDynamicEvent OnFinished;
		// 业务需要：传递0默认不需要Finished Callback
		if (OnFinishedID != 0)
		{
			OnFinished.BindRawLambda([this, OnFinishedID](void*) { OnAnimationFinishedCallbackWithID(OnFinishedID);});	
		}
		FWidgetAnimationDynamicEvent OnInterrupted;
		// 业务需求: 传递0默认不需要Interrupted Callback
		if (OnInterruptedID != 0)
		{
			OnInterrupted.BindRawLambda([this, OnInterruptedID](void*) { OnAnimationInterruptedCallbackWithID(OnInterruptedID);});	
		}

		// 业务需求：如果当前动画正在播放，先执行一次打断回调，再将动画sequence重置到第一帧
		if (IsAnimationPlaying(InAnimation))
		{
			UE_LOG(LogTemp, Log, TEXT("[UKGUserWidget::PlayAnimationWithID] Widget:%s Play Same Animation when animation is not finished, call interrupted function."), *this->GetName());
			OnInterrupted.ExecuteIfBound();
		}

		PlayAnimationWithCallbacksInternal(InAnimation, StartAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed, bRestoreState, OnFinished, OnInterrupted);

		PlaySubAnimFromZeroPosition(InAnimation);	
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[UKGUserWidget::PlayAnimationWithID] InAnimation is invalid."))
	}
}

void UKGUserWidget::OnAnimationFinishedCallbackWithID(int32 ID)
{
	if (UWorld* World = GetWorld())
	{
		if (auto gameInstance = World->GetGameInstance())
		{
			if (NS_SLUA::LuaState* ls = NS_SLUA::LuaState::get(gameInstance))
			{
				ls->call("PublishFinishAnimationEvent", ID);
			}
		}
	}
}

void UKGUserWidget::OnAnimationInterruptedCallbackWithID(int32 ID)
{
	if (UWorld* World = GetWorld())
	{
		if (auto gameInstance = World->GetGameInstance())
		{
			if (NS_SLUA::LuaState* ls = NS_SLUA::LuaState::get(gameInstance))
			{
				ls->call("PublishInterruptedAnimationEvent", ID);
			}
		}
	}
}

void UKGUserWidget::ClearAnimationCallbacks()
{
	AnimationCallbacks.Empty();
}

void UKGUserWidget::StopAllAnimationsRecursively()
{
	StopAllAnimations();
	if (TObjectPtr<UWidgetTree> WBPWidgetTree = this->WidgetTree)
	{
		TArray<UWidget*> Widgets;
		WBPWidgetTree->GetAllWidgets(Widgets);
		for (int32 Index = 0; Index < Widgets.Num(); ++Index)
		{
			UWidget* CWidget = Widgets[Index];
			if (CWidget == nullptr)
			{
				continue;
			}
			if (UKGUserWidget* UserWidget = Cast<UKGUserWidget>(CWidget))
			{
				UserWidget->StopAllAnimationsRecursively();
			}
		}
	}
}

bool UKGUserWidget::VerifyAllAnimationsStoppedRecursively()
{
	if (bStoppingAllAnimations)
	{
		UE_LOG(LogKGUI, Error, TEXT("Animation is still been stopping! User Widget: %s."), *GetClass()->GetPathName());
		return false;
	}
	bool bOK = true;

	for (const auto& WidgetAnimationContext : WidgetAnimationContexts)
	{
		if (WidgetAnimationContext.Key.Get())
		{
			UE_LOG(LogKGUI, Error, TEXT("Animation context for %s should be removed! User Widget: %s."), *WidgetAnimationContext.Key->GetName(), *GetClass()->GetPathName());
		}
		bOK = false;
	}

	for (auto Player : ActiveSequencePlayers)
	{
		if (StoppedSequencePlayers.Contains(Player))
		{
			continue;
		}
		if (Player->IsStopping())
		{
			continue;
		}
		UE_LOG(LogKGUI, Error, TEXT("Player %s is not stopped! User Widget: %s."), *Player->GetPathName(), *GetClass()->GetPathName());
		bOK = false;
	}

	WidgetTree->ForEachWidget([&bOK](auto Widget)
	{
		if (auto UserWidget = Cast<UKGUserWidget>(Widget))
		{
			bOK &= UserWidget->VerifyAllAnimationsStoppedRecursively();
		}
	});
	return bOK;
}

bool UKGUserWidget::IsPointerInPanel(float PointerScreenPosX, float PointerScreenPosY, int32 UserIndex)
{
	UE::Slate::FDeprecateVector2DParameter PointerPos(PointerScreenPosX, PointerScreenPosY);

	for (auto* RegionWidget : PanelRegionWidgets)
	{
		if (IsValid(RegionWidget) && RegionWidget->IsVisible())
		{
			const FGeometry& CachedGeometry = RegionWidget->GetCachedGeometry();
			if (CachedGeometry.GetRenderBoundingRect().ContainsPoint(PointerPos))
			{
				return true;
			}
		}
	}

	return false;
}

void UKGUserWidget::AddPanelRegionWidget(UWidget* Widget)
{
	PanelRegionWidgets.AddUnique(Widget);
}

void UKGUserWidget::RemovePanelRegionWidget(UWidget* Widget)
{
	PanelRegionWidgets.Remove(Widget);
}

void UKGUserWidget::AddChildrenToPanelRegionWidgets(UPanelWidget* Widget, bool bJustVisible)
{
	if (!IsValid(Widget))
	{
		return;
	}

	for (auto* WidgetChild : Widget->GetAllChildren())
	{
		if (bJustVisible && WidgetChild->IsVisible() || !bJustVisible)
		{
			AddPanelRegionWidget(WidgetChild);
		}
	}
}

void UKGUserWidget::ClearPanelRegionWidget()
{
	PanelRegionWidgets.Empty();
}

void UKGUserWidget::SetAnimTimeOffset(UWidgetAnimation* InAnimation)
{
    if (!InAnimation || !IsValid(InAnimation) || AnimTimeOffsetMaterialParamName.IsEmpty() || AnimTimeOffsets.IsEmpty())
    {
        return ;
    }
    
    FString AnimName = InAnimation->GetName();
    AnimName = AnimName.Replace(TEXT("_INST"), TEXT(""));
    if (AnimName.IsEmpty())
    {
        return;
    }
    
    FName ParamName (AnimTimeOffsetMaterialParamName);
    
    float Time = UUIFunctionLibrary::GetTimeSinceEditorStartUp();
    Time = 0.f - FMath::Fmod(Time, FMath::Max(Period, KINDA_SMALL_NUMBER));
    
    for (auto& AnimTimeOffset : AnimTimeOffsets)
    {
        if (AnimTimeOffset.AnimName.Name.Equals(AnimName))
        {
            for (auto* Widget : AnimTimeOffset.Widgets)
            {
                if (Widget)
                {
                    if (Widget->IsA<UImage>())
                    {
                        if (UImage* Image = Cast<UImage>(Widget))
                        {
                            if (auto* Mat = Image->GetDynamicMaterial())
                            {
                                Mat->SetScalarParameterValue(ParamName, Time);
                            }
                        }
                    }
                    else if (Widget->IsA<UTextBlock>())
                    {
                        if (UTextBlock* TextBlock = Cast<UTextBlock>(Widget))
                        {
                            if (auto* Mat = TextBlock->GetDynamicFontMaterial())
                            {
                                Mat->SetScalarParameterValue(ParamName, Time);
                            }
                            if (auto* Mat = TextBlock->GetDynamicOutlineMaterial())
                            {
                                Mat->SetScalarParameterValue(ParamName, Time);
                            }
                        }
                    }
                    else if (Widget->IsA<URichTextBlock>())
                    {
                        if (URichTextBlock* TextBlock = Cast<URichTextBlock>(Widget))
                        {
                            if (auto* Mat = TextBlock->GetDefaultDynamicMaterial())
                            {
                                Mat->SetScalarParameterValue(ParamName, Time);
                            }
                        }
                    }
                }
            }
        }
    }
}

void UKGUserWidget::CollectAnimTimeOffsetWidgets()
{
    TSet<FName> WidgetNames;
    for (auto& AnimTimeOffset : AnimTimeOffsets)
    {
        for (auto& Name : AnimTimeOffset.WidgetsName)
        {
            WidgetNames.Add(Name.Name);
        }
    }
    
    if (WidgetTree)
    {
        TArray<UWidget*> Widgets;
        WidgetTree->GetAllWidgets(Widgets);
        
        TMap<FName, UWidget*> Name2Widget;
        for (auto* Widget : Widgets)
        {
            if (Widget && WidgetNames.Contains(Widget->GetFName()))
            {
                Name2Widget.Add(Widget->GetFName(), Widget);
            }
        }
        
        for (auto& AnimTimeOffset : AnimTimeOffsets)
        {
            for (auto& Name : AnimTimeOffset.WidgetsName)
            {
                if (UWidget** Widget = Name2Widget.Find(Name.Name))
                {
                    AnimTimeOffset.Widgets.Add(*Widget);
                }
            }
        }
    }
}

UWidgetAnimation* UKGUserWidget::GetAnimationByName(const FString& AnimationName) const
{
	UWidgetBlueprintGeneratedClass* WidgetBlueprintGeneratedClass = this->GetWidgetTreeOwningClass();
	if (WidgetBlueprintGeneratedClass == nullptr)
	{
		return nullptr;
	}
	for (auto Animation : WidgetBlueprintGeneratedClass->Animations)
	{
		if (Animation->GetMovieScene()->GetName() == AnimationName)
		{
			return Animation;
		}
	}
	return nullptr;
}

UWidgetAnimation* UKGUserWidget::GetAnimationBySpecialName(EKGSpecialWidgetAnimationName SpecialAnimationName) const
{
	switch (SpecialAnimationName)
	{
	case EKGSpecialWidgetAnimationName::Open:
		return GetAnimationByName("Open");
	case EKGSpecialWidgetAnimationName::Close:
		return GetAnimationByName("Close");
	}
	return nullptr;
}

void UKGUserWidget::OnAnimationStarted_Implementation(const UWidgetAnimation* Animation)
{
	OnAnimationStartedEvent.ExecuteIfBound(Animation->GetName());
}

void UKGUserWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	OnAnimationFinishedEvent.ExecuteIfBound(Animation->GetName());
}


void UKGUserWidget::PlaySubAnimFromZeroPosition(UWidgetAnimation* InMainAnim)
{
	if (GPlayMainAndSubAnimAtTheSameTime == false)
	{
		return;
	}


	if (InMainAnim == nullptr)
	{
		return;
	}

	const UMovieScene* MS = InMainAnim->GetMovieScene();
	if (MS == nullptr)
	{
		return;
	}

	FName AnimName = *(MS->GetName());
	FSubAnims* Anims = SubAnimMap.Find(AnimName);
	if (Anims == nullptr)
	{
		return;
	}

	for (size_t i = 0; i < Anims->SubAnims.Num(); i++)
	{
		FSubAnimNode& node = Anims->SubAnims[i];

		UKGUserWidget* W = node.SubWidget.Get();
		UWidgetAnimation* A = node.SubAnim.Get();

		if (W == nullptr || A == nullptr)
		{
			continue;
		}

		W->PlayAnimationInternal(A, 0, node.LoopNum, node.PlayMode, 1.0, false);

		// 可能还有子子动画
		if (W->SubAnimMap.Num() > 0)
		{
			W->PlaySubAnimFromZeroPosition(A);
		}
	}
}

void UKGUserWidget::CollectSubAnimsFromZeorPosition()
{
	SCOPED_NAMED_EVENT_TEXT("UKGUserWidget::CollectSubAnimsFromZeorPosition", FColor::Emerald);
	if (WidgetTree == nullptr)
	{
		return;
	}

	SubAnimMap.Empty();
	SubUserWidgetMap.Empty();

	FString SearchString(TEXT("WBP_"));
	FString SearchString2(TEXT("_INST"));

	UWidgetBlueprintGeneratedClass* WidgetBlueprintGeneratedClass = GetWidgetTreeOwningClass();
	if (WidgetBlueprintGeneratedClass == nullptr)
	{
		return;
	}

	//collect widget name - sub object map
	TArray<UWidget*> AllWidgets;
	WidgetTree->GetAllWidgets(AllWidgets);
	for (size_t i = 0; i < AllWidgets.Num(); i++)
	{
		UWidget* widget = AllWidgets[i];
		UKGUserWidget* kgWidget = Cast<UKGUserWidget>(widget);
		if (kgWidget == nullptr)
		{
			continue;
		}
		FName WidgetName(kgWidget->GetName());
		if(SubUserWidgetMap.Find(WidgetName) == nullptr)
		{
			SubUserWidgetMap.Emplace(WidgetName, kgWidget);
		}
		else
		{
			UE_LOG(LogKGUI, Warning, TEXT("CollectSubAnimsFromZeorPosition: widget name duplicate %s"), *(kgWidget->GetPathName()));
		}
	}


	for (size_t i = 0; i < WidgetBlueprintGeneratedClass->Animations.Num(); i++)
	{
		if (!WidgetBlueprintGeneratedClass->Animations[i])
		{
			continue;
		}

		UWidgetAnimation* anim = WidgetBlueprintGeneratedClass->Animations[i].Get();
		if (anim == nullptr)
		{
			continue;
		}

		UMovieScene* MS = anim->MovieScene.Get();
		if (MS == nullptr)
		{
			continue;
		}

		const FString& AnimName = MS->GetName();
		FName AnimName2 = FName(*AnimName);
		if (AnimName2 == NAME_None)
		{
			continue;
		}

		TArray<FMovieSceneBinding>& Bindings = MS->GetBindings();
		for (size_t j = 0; j < Bindings.Num(); j++)
		{
			FMovieSceneBinding& bind = Bindings[j];
			const FString& BindName = bind.GetName();
			UKGUserWidget* BindedWidget = GetSubWidgetByGUID(anim, bind.GetObjectGuid());
			if (BindedWidget == nullptr)
			{
				continue;
			}

			const TArray<UMovieSceneTrack*>& tracks = bind.GetTracks();
			for (size_t k = 0; k < tracks.Num(); k++)
			{
				UMovieSceneTrack* track = tracks[k];
				if (track == nullptr)
				{
					continue;
				}

				UKGUserWidgetAnimationTrack* kgTrack = Cast<UKGUserWidgetAnimationTrack>(track);
				if (kgTrack == nullptr)
				{
					continue;
				}

				const TArray<UMovieSceneSection*>& sections = kgTrack->GetAllSections();
				if (sections.Num() == 0 || sections[0] == nullptr)
				{
					continue;
				}

				UMovieSceneSection* mss = sections[0];
				UKGUserWidgetAnimationSection* kgSection = Cast<UKGUserWidgetAnimationSection>(mss);
				if (kgSection == nullptr)
				{
					continue;
				}

				FString SubAnimName = kgSection->AnimName;


				if (SubAnimName.EndsWith(GetData(SearchString2)) == false)
				{
					continue;
				}

				SubAnimName = SubAnimName.LeftChop(5);

				FFrameNumber fn = kgSection->GetInclusiveStartFrame();
				if (fn > 0)
				{
					continue;
				}

				UWidgetAnimation* SubAnim = BindedWidget->GetAnimationByName(SubAnimName);
				if (SubAnim == nullptr)
				{
					continue;
				}

				AddSubAnimFromZeroPosition(anim, BindedWidget, SubAnim, kgSection);
			}
		}
	}
}

UKGUserWidget* UKGUserWidget::GetSubWidgetByName(const FName& InWidgetName)
{
	if (SubUserWidgetMap.Contains(InWidgetName))
	{
		return Cast<UKGUserWidget>(SubUserWidgetMap[InWidgetName]);
	}
	return nullptr;
}

UKGUserWidget* UKGUserWidget::GetSubWidgetByGUID(UWidgetAnimation* InAnim, const FGuid& InBindGuid)
{
	if (InAnim == nullptr)
	{
		return nullptr;
	}

	for (size_t i = 0; i < InAnim->AnimationBindings.Num(); i++)
	{
		FWidgetAnimationBinding& bind = InAnim->AnimationBindings[i];
		if (bind.AnimationGuid == InBindGuid)
		{
			return GetSubWidgetByName(bind.WidgetName);
		}

	}

	return nullptr;
}

void UKGUserWidget::AddSubAnimFromZeroPosition(UWidgetAnimation* InMainAnim, UKGUserWidget* InSubWidget, 
	UWidgetAnimation* InSubAnim, UKGUserWidgetAnimationSection* InSection)
{
	if (InMainAnim == nullptr || InSubWidget == nullptr || InSubAnim == nullptr || InSection == nullptr)
	{
		return;
	}

	UMovieScene* MS = InMainAnim->GetMovieScene();
	if (MS == nullptr)
	{
		return;
	}

	FName Key = *(MS->GetName());
	FSubAnims& Node = SubAnimMap.FindOrAdd(Key);
	int idx = Node.SubAnims.AddZeroed();
	Node.SubAnims[idx].SubWidget = InSubWidget;
	Node.SubAnims[idx].SubAnim = InSubAnim;

	Node.SubAnims[idx].PlayMode = InSection->PlayMode;
	Node.SubAnims[idx].LoopNum = InSection->LoopNum;
}

#pragma endregion

#pragma region UObjects Count
// BEGIN ADD BY gushengyu@kuaishou.com [UObject Count]
int32 UKGUserWidget::GetUObjectNumFromWidgetTree()
{
	UObjectNum = 0;
	GetUObjectNumFromWidgetTree_Internal(this, UObjectNum);
	return UObjectNum;
}

int32 UKGUserWidget::GetUObjectNumFromWidgetTree_Internal(UWidget* Widget, int32& Res)
{
	if (!Widget)
	{
		return Res;
	}
	if (UUserWidget* UserWidget = Cast<UUserWidget>(Widget))
	{
		Res += 2;
		GetUObjectNumFromWidgetTree_Internal(UserWidget->GetRootWidget(), Res);
	}
	else if (UPanelWidget* Panel = Cast<UPanelWidget>(Widget))
	{
		Res += Panel->GetSlots().Num() + 1;//Slot数量
		for (int32 i = 0; i < Panel->GetChildrenCount(); ++i)
		{
			GetUObjectNumFromWidgetTree_Internal(Panel->GetChildAt(i), Res);
		}
	}
	else
	{
		Res += 1;
	}
	return Res;
}
// END ADD BY gushengyu@kuaishou.com [UObject Count]

#pragma endregion UObjects Count

#pragma region Style Sheet

void UKGUserWidget::OnWidgetRebuilt()
{
	Super::OnWidgetRebuilt();
	if (StyleSheetPreset != nullptr)
	{
		StyleSheetPreset->Apply(this);
	}
	StyleSheetInline.Apply(this, this);
}

void UKGUserWidget::SetStyleSheetPreset(UKGStyleSheetPreset* InStyleSheetPreset)
{
	if (InStyleSheetPreset == StyleSheetPreset)
	{
		return;
	}
	StyleSheetPreset = InStyleSheetPreset;
	if (StyleSheetPreset != nullptr)
	{
		StyleSheetPreset->Apply(this);
	}
	StyleSheetInline.Apply(this, this);
}

bool UKGUserWidget::HasAnyWidgetAnimationStyle(UWidgetAnimation* WidgetAnimation) const
{
	if (!WidgetAnimation)
	{
		return false;
	}
	if (auto BPGC = Cast<UWidgetBlueprintGeneratedClass>(this->GetClass()))
	{
		if (auto BPGCE = BPGC->GetExtension<UKGUIWidgetBlueprintGeneratedClassExtension>())
		{
			return BPGCE->HasAnyWidgetAnimationStyle(*this, *WidgetAnimation);
		}
	}
	return false;
}

bool UKGUserWidget::ApplyWidgetAnimationStyle(UWidgetAnimation* WidgetAnimation, EKGItemAnimationState AnimationState)
{
	if (!WidgetAnimation)
	{
		return false;
	}
	if (auto BPGC = Cast<UWidgetBlueprintGeneratedClass>(this->GetClass()))
	{
		if (auto BPGCE = BPGC->GetExtension<UKGUIWidgetBlueprintGeneratedClassExtension>())
		{
			switch (AnimationState)
			{
			case EKGItemAnimationState::Preparing:
			case EKGItemAnimationState::Playing:
				if (BPGCE->ApplyWidgetAnimationInitialStyle(*this, *WidgetAnimation))
				{
					return true;
				}
				break;
			case EKGItemAnimationState::Finished:
				if (BPGCE->ApplyWidgetAnimationTerminalStyle(*this, *WidgetAnimation))
				{
					return true;
				}
				break;
			default:
				break;
			}
		}
	}
	return false;
}

#pragma endregion
