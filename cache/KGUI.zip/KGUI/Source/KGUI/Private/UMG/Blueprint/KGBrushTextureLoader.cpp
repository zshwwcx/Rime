#include "UMG/Blueprint/KGBrushTextureLoader.h"

#include "TextureCompiler.h"
#include "Core/Common.h"
#include "Core/DynamicAtlas/DynamicAtlasSubsystem.h"
#include "Engine/AssetManager.h"
#include "Engine/Texture2D.h"
#include "Materials/MaterialInterface.h"

FKGBrushTextureLoader::FKGBrushTextureLoader(UWidget* InWidget, FOnGetBrush&& InOnGetBrush)
	: WeakWidget(InWidget)
	, OnGetBrush(InOnGetBrush)
{
	check(OnGetBrush.IsBound());
}

void FKGBrushTextureLoader::CancelImageStreaming()
{
	if (Handle.IsValid())
	{
		Handle->CancelHandle();
		Handle.Reset();
	}
	ObjectPath.Reset();
}

void FKGBrushTextureLoader::SetBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize)
{
	TSoftObjectPtr<UObject> SoftObject = TSoftObjectPtr<UObject>(SoftObjectPath);
	if (SoftObject.IsNull())
	{
		UE_LOG(LogKGUI, Warning, TEXT("Try to SetBrushFromSoftObject (%s) Which is Null!"), *SoftObjectPath);
		return;
	}
	SetBrushFromSoftObject(SoftObject, bMatchSize);
}

void FKGBrushTextureLoader::SetBrushFromSoftObject(TSoftObjectPtr<UObject> SoftObject, bool bMatchSize)
{
	if (SoftObject.IsNull())
	{
		UE_LOG(LogKGUI, Warning, TEXT("Try to SetBrushFromSoftObject Which is Null!"));
		return;
	}
	CancelImageStreaming();
	if (auto StrongObject = SoftObject.Get())
	{
		OnLoadingFinished(SoftObject, bMatchSize);
		return;
	}
	ObjectPath = SoftObject.ToSoftObjectPath();
	Handle = UAssetManager::GetStreamableManager().RequestAsyncLoad(
		ObjectPath,
		[WeakThis_ = this->AsWeak(), SoftObject, bMatchSize]()
		{
			if (auto StrongThis = WeakThis_.Pin())
			{
				if (StrongThis->ObjectPath != SoftObject.ToSoftObjectPath())
				{
					return;
				}
				StrongThis->OnLoadingFinished(SoftObject, bMatchSize);
			}
		},
		FStreamableManager::AsyncLoadHighPriority);
}

void FKGBrushTextureLoader::OnLoadingFinished(TSoftObjectPtr<UObject> SoftObject, bool bMatchSize)
{
	if (WeakWidget.Get() == nullptr)
	{
		return;
	}
	if (auto BrushPtr = OnGetBrush.Execute())
	{
		auto& Brush = *BrushPtr;
		auto StrongObject = SoftObject.Get();
		if (!StrongObject)
		{
			UE_LOG(LogKGUI, Error, TEXT("Failed to load %s"), *SoftObject.ToSoftObjectPath().ToString());
		}
		if (auto Texture2D = Cast<UTexture2D>(StrongObject))
		{
			this->SetBrushFromTextureTryingToUseDynamicSprite(Brush, Texture2D, bMatchSize);
		}
		else if (auto MaterialInterface = Cast<UMaterialInterface>(StrongObject))
		{
			this->SetBrushFromMaterial(Brush, MaterialInterface);
		}
		else if (auto AtlasInterface = Cast<ISlateTextureAtlasInterface>(StrongObject))
		{
			this->SetBrushFromAtlasInterface(Brush, StrongObject, bMatchSize);
		}
		else if (auto Texture2DDynamic = Cast<UTexture2DDynamic>(StrongObject))
		{
			this->SetBrushFromTextureDynamic(Brush, Texture2DDynamic, bMatchSize);
		}
		else
		{
			this->SetBrushFromTexture(Brush, nullptr);
		}
	}
}

void FKGBrushTextureLoader::SetBrushFromTextureTryingToUseDynamicSprite(FSlateBrush& Brush, UTexture2D* Texture, bool bMatchSize)
{
	if (auto DynamicAtlasSubsystem = UDynamicAtlasSubsystem::GetInstance(WeakWidget.Get()))
	{
		if (auto DynamicSprite = DynamicAtlasSubsystem->NewSprite(Texture))
		{
			this->SetBrushFromAtlasInterface(Brush, DynamicSprite, bMatchSize);
			return;
		}
	}
	this->SetBrushFromTexture(Brush, Texture, bMatchSize);
}

void FKGBrushTextureLoader::SetBrushFromMaterial(FSlateBrush& Brush, UMaterialInterface* Material)
{
	if (Brush.GetResourceObject() != Material)
	{
		CancelImageStreaming();
		Brush.SetResourceObject(Material);
		auto Widget = WeakWidget.Get();
		if (Widget != nullptr)
		{
			Widget->InvalidateLayoutAndVolatility();
		}
	}
}

void FKGBrushTextureLoader::SetBrushFromAtlasInterface(FSlateBrush& Brush, TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize)
{
	if (Brush.GetResourceObject() != AtlasRegion.GetObject())
	{
		CancelImageStreaming();
		Brush.SetResourceObject(AtlasRegion.GetObject());

		if (bMatchSize)
		{
			if (AtlasRegion)
			{
				FSlateAtlasData AtlasData = AtlasRegion->GetSlateAtlasData();
				Brush.ImageSize = AtlasData.GetSourceDimensions();
			}
			else
			{
				Brush.ImageSize = FVector2D(0, 0);
			}
		}
		auto Widget = WeakWidget.Get();
		if (Widget != nullptr)
		{
			Widget->InvalidateLayoutAndVolatility();
		}
	}
}

void FKGBrushTextureLoader::SetBrushFromTextureDynamic(FSlateBrush& Brush, UTexture2DDynamic* Texture, bool bMatchSize)
{
	if (Brush.GetResourceObject() != Texture)
	{
		CancelImageStreaming();
		Brush.SetResourceObject(Texture);

		if (bMatchSize && Texture)
		{
			Brush.ImageSize.X = Texture->SizeX;
			Brush.ImageSize.Y = Texture->SizeY;
		}
		auto Widget = WeakWidget.Get();
		if (Widget != nullptr)
		{
			Widget->InvalidateLayoutAndVolatility();
		}
	}
}

void FKGBrushTextureLoader::SetBrushFromTexture(FSlateBrush& Brush, UTexture2D* Texture, bool bMatchSize)
{
	CancelImageStreaming();

	if (Brush.GetResourceObject() != Texture)
	{
		Brush.SetResourceObject(Texture);

		if (Texture) // Since this texture is used as UI, don't allow it affected by budget.
		{
			Texture->bForceMiplevelsToBeResident = true;
			Texture->bIgnoreStreamingMipBias = true;
		}

		if (bMatchSize)
		{
			if (Texture)
			{
#if WITH_EDITOR
				FTextureCompilingManager::Get().FinishCompilation({ Texture });
#endif
				Brush.ImageSize.X = Texture->GetSizeX();
				Brush.ImageSize.Y = Texture->GetSizeY();
			}
			else
			{
				Brush.ImageSize = FVector2D(0, 0);
			}
		}
		auto Widget = WeakWidget.Get();
		if (Widget != nullptr)
		{
			Widget->InvalidateLayoutAndVolatility();
		}
	}
}