#include "UMG/Blueprint/KGSlice9Data.h"

#include "KGUISettings.h"

void UKGSlice9Data::TryApply(UImage* Image)
{
#if WITH_EDITOR
	const auto bEnableSlice9Data = GetDefault<UKGUISettings>()->bEnableSlice9Data;
#else
	const static auto bEnableSlice9Data = GetDefault<UKGUISettings>()->bEnableSlice9Data;
#endif
	if (!bEnableSlice9Data)
	{
		return;
	}
	if (Image == nullptr)
	{
		return;
	}
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	auto& Brush = Image->Brush;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	auto ResourceObject = Brush.GetResourceObject();
	if (IInterface_AssetUserData* AssetUserData = Cast<IInterface_AssetUserData>(ResourceObject))
	{
		if (auto Slice9Data = AssetUserData->GetAssetUserData<UKGSlice9Data>())
		{
			Brush.Margin = Slice9Data->Margin;
		}
	}
}

void UKGSlice9Data::TryApply(FSlateBrush& InBrush)
{
    
#if WITH_EDITOR
    const auto bEnableSlice9Data = GetDefault<UKGUISettings>()->bEnableSlice9Data;
#else
    const static auto bEnableSlice9Data = GetDefault<UKGUISettings>()->bEnableSlice9Data;
#endif
    if (!bEnableSlice9Data)
    {
        return;
    }

    auto ResourceObject = InBrush.GetResourceObject();
    if (IInterface_AssetUserData* AssetUserData = Cast<IInterface_AssetUserData>(ResourceObject))
    {
        if (auto Slice9Data = AssetUserData->GetAssetUserData<UKGSlice9Data>())
        {
            InBrush.Margin = Slice9Data->Margin;
        }
    }
}
