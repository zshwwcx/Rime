#include "UMG/Blueprint/KGVector2DReference.h"

void UKGVector2DReference::SetReferenceValue(FVector2D InValue)
{
	this->Value = InValue;
}