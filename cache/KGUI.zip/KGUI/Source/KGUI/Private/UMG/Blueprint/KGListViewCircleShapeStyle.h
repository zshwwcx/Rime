#pragma once

#include "CoreMinimal.h"
#include "UMG/Blueprint/KGListViewShapeStyle.h"

#include "KGListViewCircleShapeStyle.generated.h"

UCLASS(MinimalAPI, DisplayName = "Circle")
class UKGListViewCircleShapeStyle : public UKGListViewShapeStyle
{
	GENERATED_BODY()

protected:
	using Super::ItemType;
	virtual void RaiseOnModifyEntry(const FGeometry& Geometry, TSharedRef<SKGObjectTableRow<ItemType>> Entry) override;

	UPROPERTY(EditAnywhere, Category = "Circle")
	float CenterOffset = 0;

	UPROPERTY(EditAnywhere, Category = "Circle")
	float Radius = 200;

	UPROPERTY(EditAnywhere, Category = "Circle")
	float FinalOffset = 0;
};