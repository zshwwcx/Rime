#pragma once

#include "Layout/Margin.h"
#include "Math/Vector2D.h"
#include "Widgets/Views/STableViewBase.h"

struct FKGTileLayoutConfiguration;
struct FKGTreeItem;
class UKGTreeView;

struct FKGTreeTileLayoutState
{
public:
	FKGTreeTileLayoutState(const UKGTreeView* TreeView, const FKGTileLayoutConfiguration& TileLayoutConfiguration);

	int GetLineCellCapacity() const;
	FVector2D GetCellSize() const;
	float GetSpacing() const;
	FMargin GetPadding(bool bFirstLine, bool bLastLine) const;
	EOrientation GetLineOrientation() const;

	bool operator==(const FKGTreeTileLayoutState& Other) const;

private:
	float GetLineAxisWithoutPadding() const;

	EOrientation Orientation;
	EHorizontalAlignment TileLayoutHorizontalAlignment;
	EVerticalAlignment TileLayoutVerticalAlignment;
	FGeometry PanelGeometry;
	FVector2D TileLayoutCellSize;
	FVector2D EntrySpacing;
	FVector2D AdditionalEntrySpacing;
	FMargin TileLayoutPadding;
	FMargin ContentPadding;

	EOrientation LineOrientation;
	FTableViewDimensions PanelDimensions;
	FTableViewDimensions CellDimensions;
	FTableViewDimensions CellSpacingDimensions;
	FTableViewDimensions AdditionalCellSpacingDimensions;
	FTableViewDimensions TileLayoutPaddingTopLeftDimensions;
	FTableViewDimensions TileLayoutPaddingBottomRightDimensions;
	FTableViewDimensions ContentPaddingTopLeftDimensions;
	FTableViewDimensions ContentPaddingBottomRightDimensions;
};
