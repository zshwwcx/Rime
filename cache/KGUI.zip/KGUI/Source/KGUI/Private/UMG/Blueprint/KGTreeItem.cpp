#include "UMG/Blueprint/KGTreeItem.h"

#include "UMG/Components/KGTreeView.h"
#include "UMG/Blueprint/KGTreeTileLayoutState.h"

TSharedPtr<IKGTreeItem> IKGTreeItem::UnsafeCast(const TSharedPtr<FKGListItem>& Item)
{
	return StaticCastSharedPtr<IKGTreeItem>(Item);
}

TArray<TSharedPtr<FKGListItem>> FKGTreeItem::GetOutChildren()
{
	TArray<TSharedPtr<FKGListItem>> OutChildren;
	if (!ensure(!bChildrenDirty))
	{
		return OutChildren;
	}
	bool bChildLayouted = TreeView.Get() != nullptr && TreeView->bTileLayout && this->GetTreeLevel() + 1 == TreeView->TileLayoutNestingLevel;
	if (bChildLayouted)
	{
		auto TileLayoutConfiguration = TreeView.Get()->GetDefaultTileLayoutConfiguration();
		if (TreeView->OnGetTileLayoutConfigurationForItem.IsBound())
		{
			TileLayoutConfiguration = TreeView->OnGetTileLayoutConfigurationForItem.Execute(this->GetPath(), TileLayoutConfiguration);
		}
		if (TileLayoutConfiguration.bTileLayoutEnabled)
		{
			ChildLayoutItems.Empty();
			FKGTreeTileLayoutState TreeTileLayoutState(TreeView.Get(), TileLayoutConfiguration);
			int LineCellCapacity = TreeTileLayoutState.GetLineCellCapacity();
			TSharedPtr<FKGTreeTileLayoutItem> CurrentLine = nullptr;
			int ChildCount = Children.Num();
			for (int Index = 0; Index < ChildCount; Index++)
			{
				if (Index % LineCellCapacity == 0)
				{
					ChildLayoutItems.Add(CurrentLine = MakeShared<FKGTreeTileLayoutItem>());
					CurrentLine->SetCellSize(TreeTileLayoutState.GetCellSize());
					CurrentLine->SetSpacing(TreeTileLayoutState.GetSpacing());
					CurrentLine->SetPadding(TreeTileLayoutState.GetPadding(Index == 0, ChildCount - Index <= LineCellCapacity));
					CurrentLine->SetLineOrientation(TreeTileLayoutState.GetLineOrientation());
				}
				CurrentLine->AddTreeItem(this->GetChildAt(Index));
			}
			Algo::Transform(ChildLayoutItems, OutChildren, [](auto X)
			{
				return X;
			});
			return OutChildren;
		}
	}
	OutChildren = this->Children;
	return OutChildren;
}

void FKGTreeItem::AddChild(const TSharedPtr<FKGTreeItem>& InChild)
{
	InsertChild(this->Children.Num(), InChild);
}

void FKGTreeItem::InsertChild(int Index, const TSharedPtr<FKGTreeItem>& InChild)
{
	InChild->Parent = SharedThis(this);
	InChild->SetIndexInParent(Index);
	for (int I = Index; I < this->Children.Num(); I++)
	{
		auto Child = FKGTreeItem::UnsafeCast(this->Children[I]);
		Child->SetIndexInParent(Child->GetIndexInParent() + 1);
	}
	this->Children.Insert(InChild, Index);
	bChildrenDirty = true;
}

void FKGTreeItem::RemoveChild(int Index)
{
	this->Children.RemoveAt(Index);
	for (int I = Index; I < this->Children.Num(); I++)
	{
		auto Child = FKGTreeItem::UnsafeCast(this->Children[I]);
		Child->SetIndexInParent(Child->GetIndexInParent() - 1);
	}
	bChildrenDirty = true;
}

TArray<TSharedPtr<FKGListItem>>& FKGTreeItem::GetAccessibleChildren()
{
	ensure(!bChildrenDirty);
	return Children;
}

const TArray<TSharedPtr<FKGListItem>>& FKGTreeItem::GetChildren()
{
	ensure(!bChildrenDirty);
	return Children;
}

int FKGTreeItem::GetChildCount() const
{
	ensure(!bChildrenDirty);
	return Children.Num();
}

TSharedPtr<FKGTreeItem> FKGTreeItem::GetChildAt(int Index) const
{
	if (!ensure(!bChildrenDirty))
	{
		return nullptr;
	}
	check(Children.IsValidIndex(Index));
	return FKGTreeItem::UnsafeCast(Children[Index]);
}

TSharedPtr<FKGTreeItem> FKGTreeItem::UnsafeCast(const TSharedPtr<FKGListItem>& Item)
{
	auto TreeItemInterface = IKGTreeItem::UnsafeCast(Item);
	if (TreeItemInterface == nullptr || TreeItemInterface->GetTreeItemType() != EKGTreeItemType::Normal)
	{
		return nullptr;
	}
	return StaticCastSharedPtr<FKGTreeItem>(Item);
}

TArray<int> FKGTreeItem::GetPath() const
{
	TArray<int> Path;
	TSharedPtr<const FKGTreeItem> Current = SharedThis(this);
	while (Current != nullptr)
	{
		if (Current->IndexInParent == INDEX_NONE)
		{
			break;
		}
		Path.Add(Current->IndexInParent);
		Current = Current->GetParent();
	}
	Algo::Reverse(Path);
	return Path;
}

void FKGTreeItem::MakeChildren(int Num)
{
	if (!bChildrenDirty)
	{
		return;
	}
	if (Children.Num() > Num)
	{
		Children.RemoveAt(Num, Children.Num() - Num);
	}
	else if (Children.Num() < Num)
	{
		int MoreCount = Num - Children.Num();
		for (int Index = 0; Index < MoreCount; Index++)
		{
			this->AddChild(MakeShared<FKGTreeItem>(TreeView.Get()));
		}
	}
	bChildrenDirty = false;
}

int FKGTreeItem::GetTreeLevel() const
{
	return Parent == nullptr ? 0 : Parent.Pin()->GetTreeLevel() + 1;
}

const TArray<TSharedPtr<FKGTreeTileLayoutItem>>& FKGTreeItem::GetChildLayoutItems() const
{
	ensure(!bChildrenDirty);
	return ChildLayoutItems;
}

void FKGTreeTileLayoutItem::AddTreeItem(const TSharedPtr<FKGTreeItem>& InItem)
{
	TreeItems.Add(InItem);
	InItem->ParentLayoutItem = SharedThis(this);
}

TSharedPtr<FKGTreeTileLayoutItem> FKGTreeTileLayoutItem::UnsafeCast(const TSharedPtr<FKGListItem>& Item)
{
	auto TreeItemInterface = IKGTreeItem::UnsafeCast(Item);
	if (TreeItemInterface == nullptr || TreeItemInterface->GetTreeItemType() != EKGTreeItemType::TileLayout)
	{
		return nullptr;
	}
	return StaticCastSharedPtr<FKGTreeTileLayoutItem>(Item);
}