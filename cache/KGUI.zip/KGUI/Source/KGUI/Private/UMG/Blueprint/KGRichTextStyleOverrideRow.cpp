#include "UMG/Blueprint/KGRichTextStyleOverrideRow.h"

FTextBlockStyle FKGRichTextStyleOverrideRow::OverrideFromChain(TArray<TObjectPtr<UDataTable>> TextStyleOverrideDataTableChain, const FName& StyleName, const FTextBlockStyle* Default)
{
	FTextBlockStyle TextBlockStyle = Default == nullptr ? FTextBlockStyle() : *Default;
	for (auto DataTable : TextStyleOverrideDataTableChain)
	{
		if (DataTable == nullptr)
		{
			continue;
		}
		if (DataTable->GetRowStruct() != FKGRichTextStyleOverrideRow::StaticStruct())
		{
			UE_LOG(LogKGUI, Error, TEXT("%s 's row struct must be %s"), *DataTable->GetPathName(), *FKGRichTextStyleOverrideRow::StaticStruct()->GetName());
			continue;
		}
		auto RowData = DataTable->FindRow<FKGRichTextStyleOverrideRow>(StyleName, TEXT("Override Text Block Style From Chain"), false);
		if (RowData == nullptr)
		{
			continue;
		}
		RowData->TextStyleOverride.Override(TextBlockStyle);
	}
	return TextBlockStyle;
}
