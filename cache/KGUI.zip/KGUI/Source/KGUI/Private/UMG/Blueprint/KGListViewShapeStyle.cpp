#include "UMG/Blueprint/KGListViewShapeStyle.h"

void UKGListViewShapeStyle::RaiseOnModifyEntry(const FGeometry& Geometry, TSharedRef<SKGObjectTableRow<ItemType>> Entry)
{
	OnModifyEntry(Geometry, Entry->GetOwningListView(), Entry->GetUserWidget());
}

void UKGListViewShapeStyle::OnModifyEntry_Implementation(const FGeometry& Geometry, UListViewBase* ListView, UUserWidget* Widget)
{
}
