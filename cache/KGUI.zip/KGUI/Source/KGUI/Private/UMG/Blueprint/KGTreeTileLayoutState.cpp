#include "KGTreeTileLayoutState.h"

#include "UMG/Components/KGTreeView.h"

FKGTreeTileLayoutState::FKGTreeTileLayoutState(const UKGTreeView* TreeView, const FKGTileLayoutConfiguration& TileLayoutConfiguration)
	: Orientation(TreeView->GetOrientation())
	, TileLayoutHorizontalAlignment(TileLayoutConfiguration.TileLayoutHorizontalAlignment)
	, TileLayoutVerticalAlignment(TileLayoutConfiguration.TileLayoutVerticalAlignment)
	, PanelGeometry(TreeView->GetSlateTreeView()->GetCachedPanelGeometry())
	, TileLayoutCellSize(TileLayoutConfiguration.TileLayoutCellSize)
	, EntrySpacing(FVector2D(TreeView->GetHorizontalEntrySpacing(), TreeView->GetVerticalEntrySpacing()))
	, AdditionalEntrySpacing(FVector2D(TileLayoutConfiguration.AdditionalHorizontalEntrySpacing, TileLayoutConfiguration.AdditionalVerticalEntrySpacing))
	, TileLayoutPadding(TileLayoutConfiguration.TileLayoutPadding)
	, ContentPadding(TreeView->GetContentPadding())

	, LineOrientation(Orientation == EOrientation::Orient_Horizontal ? EOrientation::Orient_Vertical : EOrientation::Orient_Horizontal)
	, PanelDimensions(Orientation, PanelGeometry.GetLocalSize())
	, CellDimensions(Orientation, TileLayoutCellSize)
	, CellSpacingDimensions(Orientation, EntrySpacing)
	, AdditionalCellSpacingDimensions(Orientation, AdditionalEntrySpacing)
	, TileLayoutPaddingTopLeftDimensions(Orientation, TileLayoutPadding.GetTopLeft())
	, TileLayoutPaddingBottomRightDimensions(Orientation, FVector2D(TileLayoutPadding.Right, TileLayoutPadding.Bottom))
	, ContentPaddingTopLeftDimensions(Orientation, ContentPadding.GetTopLeft())
	, ContentPaddingBottomRightDimensions(Orientation, FVector2D(ContentPadding.Right, ContentPadding.Bottom))
{
}

int FKGTreeTileLayoutState::GetLineCellCapacity() const
{
	return FMath::Max((int)((GetLineAxisWithoutPadding () + GetSpacing()) / (CellDimensions.LineAxis + GetSpacing())), 1);
}

float FKGTreeTileLayoutState::GetLineAxisWithoutPadding() const
{
	return PanelDimensions.LineAxis
		- TileLayoutPaddingTopLeftDimensions.LineAxis
		- TileLayoutPaddingBottomRightDimensions.LineAxis
		- ContentPaddingTopLeftDimensions.LineAxis
		- ContentPaddingBottomRightDimensions.LineAxis;
}

FVector2D FKGTreeTileLayoutState::GetCellSize() const
{
	bool bFill = LineOrientation == EOrientation::Orient_Horizontal
		? (TileLayoutHorizontalAlignment == EHorizontalAlignment::HAlign_Fill)
		: (TileLayoutVerticalAlignment == EVerticalAlignment::VAlign_Fill);
	if (bFill)
	{
		return CellDimensions.ToVector2D() * ((GetLineAxisWithoutPadding() + GetSpacing()) / (float)GetLineCellCapacity() - GetSpacing()) / CellDimensions.LineAxis;
	}
	else
	{
		return CellDimensions.ToVector2D();
	}
}

float FKGTreeTileLayoutState::GetSpacing() const
{
	return (CellSpacingDimensions + AdditionalCellSpacingDimensions).LineAxis;
}

FMargin FKGTreeTileLayoutState::GetPadding(bool bFirstLine, bool bLastLine) const
{
	float LineAxisLowerValue = TileLayoutPaddingTopLeftDimensions.LineAxis;
	float LineAxisUpperValue = TileLayoutPaddingBottomRightDimensions.LineAxis;
	float ScrollAxisLowerValue = bFirstLine ? TileLayoutPaddingTopLeftDimensions.ScrollAxis : AdditionalCellSpacingDimensions.ScrollAxis;
	float ScrollAxisUpperValue = bLastLine ? TileLayoutPaddingBottomRightDimensions.ScrollAxis : 0;

	float LineAlignment = 0;
	if (LineOrientation == EOrientation::Orient_Horizontal)
	{
		switch (TileLayoutHorizontalAlignment)
		{
		case EHorizontalAlignment::HAlign_Center: LineAlignment = 0.5; break;
		case EHorizontalAlignment::HAlign_Right: LineAlignment = 1; break;
		default: LineAlignment = 0; break;
		}
	}
	else
	{
		switch (TileLayoutVerticalAlignment)
		{
		case EVerticalAlignment::VAlign_Center: LineAlignment = 0.5; break;
		case EVerticalAlignment::VAlign_Bottom: LineAlignment = 1; break;
		default: LineAlignment = 0; break;
		}
	}
	float AlignmentShift =
		(
			(GetLineAxisWithoutPadding() + GetSpacing())
			-
			(FTableViewDimensions(Orientation, GetCellSize()).LineAxis + GetSpacing()) * (float)GetLineCellCapacity()
		)
	* LineAlignment;
	LineAxisLowerValue += AlignmentShift;
	if (Orientation == EOrientation::Orient_Vertical)
	{
		return FMargin(LineAxisLowerValue, ScrollAxisLowerValue, LineAxisUpperValue, ScrollAxisUpperValue);
	}
	else
	{
		check(Orientation == EOrientation::Orient_Horizontal);
		return FMargin(ScrollAxisLowerValue, LineAxisLowerValue, ScrollAxisUpperValue, LineAxisUpperValue);
	}
}

EOrientation FKGTreeTileLayoutState::GetLineOrientation() const
{
	return LineOrientation;
}

bool FKGTreeTileLayoutState::operator==(const FKGTreeTileLayoutState& Other) const
{
	return
		Orientation == Other.Orientation &&
		TileLayoutHorizontalAlignment == Other.TileLayoutHorizontalAlignment &&
		TileLayoutVerticalAlignment == Other.TileLayoutVerticalAlignment &&
		PanelGeometry == Other.PanelGeometry &&
		TileLayoutCellSize == Other.TileLayoutCellSize &&
		EntrySpacing == Other.EntrySpacing &&
		AdditionalEntrySpacing == Other.AdditionalEntrySpacing &&
		TileLayoutPadding == Other.TileLayoutPadding &&
		ContentPadding == Other.ContentPadding;
}
