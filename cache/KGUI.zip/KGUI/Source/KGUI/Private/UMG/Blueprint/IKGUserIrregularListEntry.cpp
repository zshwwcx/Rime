#include "UMG/Blueprint/IKGUserIrregularListEntry.h"

#include "CoreMinimal.h"
#include "UMG/Slate/SKGObjectIrregularListEntry.h"

UKGUserIrregularListEntry::UKGUserIrregularListEntry(const FObjectInitializer& Initializer)
	: Super(Initializer)
{
}

bool IKGUserIrregularListEntry::IsListItemSelected() const
{
	UUserWidget* UserWidget = Cast<UUserWidget>(const_cast<IKGUserIrregularListEntry*>(this));
	TSharedPtr<const IKGObjectIrregularListEntry> Entry = IKGObjectIrregularListEntry::ObjectEntryFromUserWidget(UserWidget);
	if (Entry.IsValid())
	{
		return Entry->IsItemSelected();
	}
	return false;
}

UKGIrregularListView* IKGUserIrregularListEntry::GetOwningListView() const
{
	UUserWidget* UserWidget = Cast<UUserWidget>(const_cast<IKGUserIrregularListEntry*>(this));
	TSharedPtr<const IKGObjectIrregularListEntry> Entry = IKGObjectIrregularListEntry::ObjectEntryFromUserWidget(UserWidget);
	if (Entry.IsValid())
	{
		return Entry->GetOwningListView();
	}
	return NULL;
}

void IKGUserIrregularListEntry::ReleaseEntry(UUserWidget& ListEntryWidget)
{
	if (IKGUserIrregularListEntry* NativeImplementation = Cast<IKGUserIrregularListEntry>(&ListEntryWidget))
	{
		NativeImplementation->NativeOnEntryReleased();
	}
	else if (ListEntryWidget.Implements<UKGUserIrregularListEntry>())
	{
		Execute_OnEntryReleased(&ListEntryWidget);
	}
}

void IKGUserIrregularListEntry::UpdateItemSelection(UUserWidget& ListEntryWidget, bool bIsSelected, ESelectInfo::Type SelectInfo)
{
	if (IKGUserIrregularListEntry* NativeImplementation = Cast<IKGUserIrregularListEntry>(&ListEntryWidget))
	{
		NativeImplementation->NativeOnItemSelectionChanged(bIsSelected);
	}
	else if (ListEntryWidget.Implements<UKGUserIrregularListEntry>())
	{
		Execute_OnItemSelectionChanged(&ListEntryWidget, bIsSelected);
	}
}

void IKGUserIrregularListEntry::NativeOnItemSelectionChanged(bool bIsSelected)
{
	Execute_OnItemSelectionChanged(Cast<UObject>(this), bIsSelected);
}

void IKGUserIrregularListEntry::NativeOnEntryReleased()
{
	Execute_OnEntryReleased(Cast<UObject>(this));
}
