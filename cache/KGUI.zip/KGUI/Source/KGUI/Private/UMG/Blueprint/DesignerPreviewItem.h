#pragma once

#include "CoreMinimal.h"
#include "DesignerPreviewItem.generated.h"

UCLASS(Transient, BlueprintType, Blueprintable, MinimalAPI)
class UDesignerPreviewItem : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Index = -1;
};