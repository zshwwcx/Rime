#include "UMG/Blueprint/KGFloatReference.h"

void UKGFloatReference::SetReferenceValue(float InValue)
{
	this->Value = InValue;
}