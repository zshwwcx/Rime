#include "UMG/Blueprint/KGTemporarySprite.h"

#include "Engine/Texture2D.h"
#include "Materials/MaterialInterface.h"

bool UKGTemporarySprite::Supports(UObject* ResourceObject)
{
	return Cast<ISlateTextureAtlasInterface>(ResourceObject) || Cast<UTexture2D>(ResourceObject);
}

bool UKGTemporarySprite::IsValid() const
{
	return Supports(ResourceObject);
}

FSlateAtlasData UKGTemporarySprite::GetSlateAtlasData() const
{
	check(IsValid());
	if (auto SlateTextureAtlasInterface = Cast<ISlateTextureAtlasInterface>(ResourceObject))
	{
		auto SlateAtlasData = SlateTextureAtlasInterface->GetSlateAtlasData();
		return FSlateAtlasData(
			SlateAtlasData.AtlasTexture,
			SlateAtlasData.StartUV + SlateAtlasData.SizeUV * Padding.GetTopLeft(),
			SlateAtlasData.StartUV + SlateAtlasData.SizeUV *(FVector2D::One() - Padding.GetDesiredSize()),
			SlateAtlasData.BatchAtlasIndex
		);
	}
	else if (ResourceObject->IsA(UTexture2D::StaticClass()))
	{
		return FSlateAtlasData(
			Cast<UTexture2D>(ResourceObject),
			Padding.GetTopLeft(),
			FVector2D::One() - Padding.GetDesiredSize()
		);
	}
	return FSlateAtlasData(nullptr, FVector2D(0, 0), FVector2D(0, 0));
}
