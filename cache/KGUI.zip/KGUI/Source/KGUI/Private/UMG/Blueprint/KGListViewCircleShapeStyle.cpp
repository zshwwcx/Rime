#include "UMG/Blueprint/KGListViewCircleShapeStyle.h"

#include "UMG/Components/KGListView.h"

void UKGListViewCircleShapeStyle::RaiseOnModifyEntry(const FGeometry& Geometry, TSharedRef<SKGObjectTableRow<ItemType>> Entry)
{
	auto ListView = Cast<UKGListView>(Entry->GetOwningListView());
	if (!ListView)
	{
		return;
	}
	auto UserWidget = Entry->GetUserWidget();
	if (!UserWidget)
	{
		return;
	}
	auto Orientation = ListView->GetOrientation();
	const auto& ListViewGeometry = ListView->GetCachedGeometry();
	const auto& EntryGeometry = Geometry;
	auto EntryAbsolutePosition = EntryGeometry.GetAbsolutePosition() + EntryGeometry.GetAbsoluteSize() * 0.5;
	auto ListViewAbsolutePosition = ListViewGeometry.GetAbsolutePosition() + ListViewGeometry.GetAbsoluteSize() * 0.5;
	FVector2D CenterAbsolutePosition;
	if (Orientation == EOrientation::Orient_Vertical)
	{
		CenterAbsolutePosition = FVector2D(EntryAbsolutePosition.X, ListViewAbsolutePosition.Y);
	}
	else
	{
		CenterAbsolutePosition = FVector2D(ListViewAbsolutePosition.X, EntryAbsolutePosition.Y);
	}
	auto CenterLocalPosition = ListViewGeometry.AbsoluteToLocal(CenterAbsolutePosition);
	auto EntryLocalPosition = ListViewGeometry.AbsoluteToLocal(EntryAbsolutePosition);

	float Result = 0;

	CenterLocalPosition += (Orientation == EOrientation::Orient_Vertical ? FVector2D(1, 0) : FVector2D(0, 1)) * CenterOffset;
	if ((EntryLocalPosition - CenterLocalPosition).Length() < Radius)
	{
		float Delta = Orientation == EOrientation::Orient_Vertical
			? EntryLocalPosition.Y - CenterLocalPosition.Y
			: EntryLocalPosition.X - CenterLocalPosition.X;
		Result = FMath::Sqrt(Radius * Radius - Delta * Delta) * (CenterOffset >= 0 ? -1 : 1) + CenterOffset;
	}

	Result += FinalOffset;

	auto Padding = UserWidget->GetPadding();
	if (Orientation == EOrientation::Orient_Vertical)
	{
		Padding.Left = Result;
		Padding.Right = -Result;
	}
	else
	{
		Padding.Top = Result;
		Padding.Bottom = -Result;
	}
	UserWidget->SetPadding(Padding);
}
