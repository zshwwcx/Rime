#pragma once

#include "Core/Common.h"
#include "Engine/DataTable.h"
#include "UObject/ObjectMacros.h"
#include "Fonts/SlateFontInfo.h"
#include "Styling/SlateColor.h"
#include "Types/SlateVector2.h"
#include "Styling/SlateTypes.h"

#include "KGRichTextStyleOverrideRow.generated.h"


USTRUCT(BlueprintType)
struct FKGTextBlockStyleOverride
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (AllowedClasses = "/Script/Engine.Font", DisplayName = "Font Family", EditCondition = "bOverride_FontObject"))
	TObjectPtr<const UObject> FontObject;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Typeface", EditCondition = "bOverride_TypefaceFontName"))
	FName TypefaceFontName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = 1, ClampMax = 1000, EditCondition = "bOverride_Size"))
	float Size;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "bOverride_OutlineSettings"))
	FFontOutlineSettings OutlineSettings;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Appearance, meta = (DisplayName = "Color", EditCondition = "bOverride_ColorAndOpacity"))
	FSlateColor ColorAndOpacity;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Appearance, meta = (EditCondition = "bOverride_ShadowOffset"))
	FDeprecateSlateVector2D ShadowOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Appearance, meta = (EditCondition = "bOverride_ShadowColorAndOpacity"))
	FLinearColor ShadowColorAndOpacity;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Appearance, meta = (EditCondition = "bOverride_StrikeBrush"))
	FSlateBrush StrikeBrush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Appearance, meta = (EditCondition = "bOverride_UnderlineBrush"))
	FSlateBrush UnderlineBrush;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_FontObject : 1;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_TypefaceFontName : 1;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_Size : 1;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_OutlineSettings : 1;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_ColorAndOpacity : 1;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_ShadowOffset : 1;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_ShadowColorAndOpacity : 1;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_StrikeBrush : 1;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_UnderlineBrush : 1;

public:
	void Override(FTextBlockStyle& TextBlockStyle) const
	{
		if (bOverride_FontObject) { TextBlockStyle.Font.FontObject = FontObject; }
		if (bOverride_TypefaceFontName) { TextBlockStyle.Font.TypefaceFontName = TypefaceFontName; }
		if (bOverride_Size) { TextBlockStyle.Font.Size = Size; }
		if (bOverride_OutlineSettings) { TextBlockStyle.Font.OutlineSettings = OutlineSettings; }
		if (bOverride_ColorAndOpacity) { TextBlockStyle.ColorAndOpacity = ColorAndOpacity; }
		if (bOverride_ShadowOffset) { TextBlockStyle.ShadowOffset = ShadowOffset; }
		if (bOverride_ShadowColorAndOpacity) { TextBlockStyle.ShadowColorAndOpacity = ShadowColorAndOpacity; }
		if (bOverride_StrikeBrush) { TextBlockStyle.StrikeBrush = StrikeBrush; }
		if (bOverride_UnderlineBrush) { TextBlockStyle.UnderlineBrush = UnderlineBrush; }
	}
};

USTRUCT(BlueprintType)
struct FKGRichTextStyleOverrideRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = Appearance)
	FKGTextBlockStyleOverride TextStyleOverride;

	static FTextBlockStyle OverrideFromChain(TArray<TObjectPtr<UDataTable>> TextStyleOverrideDataTableChain, const FName& StyleName, const FTextBlockStyle* Default);
};