#pragma once

#include "Layout/Margin.h"
#include "Slate/SlateTextureAtlasInterface.h"

#include "KGTemporarySprite.generated.h"

UCLASS(Transient)
class UKGTemporarySprite : public UObject, public ISlateTextureAtlasInterface
{
	GENERATED_BODY()

public:
	static bool Supports(UObject* ResourceObject);
	bool IsValid() const;
	virtual FSlateAtlasData GetSlateAtlasData() const override;

	UPROPERTY(Transient)
	FMargin Padding;

	UPROPERTY(Transient)
	TObjectPtr<UObject> ResourceObject;
};
