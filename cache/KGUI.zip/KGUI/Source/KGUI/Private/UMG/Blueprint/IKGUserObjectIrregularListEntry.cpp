#include "UMG/Blueprint/IKGUserObjectIrregularListEntry.h"

#include "Blueprint/UserWidget.h"
#include "UMG/Slate/SKGObjectIrregularListEntry.h"
#include "UMG/Components/KGIrregularListView.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(IKGUserObjectIrregularListEntry)

UKGUserObjectIrregularListEntry::UKGUserObjectIrregularListEntry(const FObjectInitializer& Initializer)
	: Super(Initializer)
{
}

void IKGUserObjectIrregularListEntry::NativeOnListItemObjectSet(UObject* ListItemObject)
{
	Execute_OnListItemObjectSet(Cast<UObject>(this), ListItemObject);
}

UObject* IKGUserObjectIrregularListEntry::GetListItemObjectInternal() const
{
	return IKGUserObjectIrregularListEntry::GetListItemObject(Cast<UUserWidget>(const_cast<IKGUserObjectIrregularListEntry*>(this)));
}

void IKGUserObjectIrregularListEntry::SetListItemObject(UUserWidget& ListEntryWidget, UObject* ListItemObject)
{
	if (IKGUserObjectIrregularListEntry* NativeImplementation = Cast<IKGUserObjectIrregularListEntry>(&ListEntryWidget))
	{
		NativeImplementation->NativeOnListItemObjectSet(ListItemObject);
	}
	else if (ListEntryWidget.Implements<UKGUserObjectIrregularListEntry>())
	{
		Execute_OnListItemObjectSet(&ListEntryWidget, ListItemObject);
	}
}

UObject* IKGUserObjectIrregularListEntry::GetListItemObject(TScriptInterface<IKGUserObjectIrregularListEntry> UserObjectIrregularListEntry)
{
	if (UUserWidget* EntryWidget = Cast<UUserWidget>(UserObjectIrregularListEntry.GetObject()))
	{
		TSharedPtr<const IKGObjectIrregularListEntry> Entry = IKGObjectIrregularListEntry::ObjectEntryFromUserWidget(Cast<UUserWidget>(UserObjectIrregularListEntry.GetObject()));
		UKGIrregularListView* OwningListView = NULL;
		if (Entry.IsValid())
		{
			OwningListView = Entry->GetOwningListView();
		}
		if (const TObjectPtr<UObject>* ListItem = OwningListView ? OwningListView->ItemFromEntryWidget(*EntryWidget) : nullptr)
		{
			return *ListItem;
		}
	}
	return nullptr;
}