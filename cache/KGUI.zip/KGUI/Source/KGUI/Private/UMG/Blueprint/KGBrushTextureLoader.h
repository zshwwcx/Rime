#pragma once

#include "Components/Widget.h"
#include "Engine/StreamableManager.h"
#include "Engine/Texture2DDynamic.h"
#include "Slate/SlateTextureAtlasInterface.h"

struct FKGBrushTextureLoader : public TSharedFromThis<FKGBrushTextureLoader>
{
public:
	DECLARE_DELEGATE_RetVal(FSlateBrush*, FOnGetBrush);
	DECLARE_DELEGATE(FOnFinished);

	FKGBrushTextureLoader(UWidget* InWidget, FOnGetBrush&& InOnGetBrush);

	void CancelImageStreaming();
	void SetBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize);
	void SetBrushFromSoftObject(TSoftObjectPtr<UObject> SoftObject, bool bMatchSize);

protected:
	void OnLoadingFinished(TSoftObjectPtr<UObject> SoftObject, bool bMatchSize);
	void SetBrushFromTextureTryingToUseDynamicSprite(FSlateBrush& Brush, UTexture2D* Texture, bool bMatchSize = false);
	void SetBrushFromMaterial(FSlateBrush& Brush, UMaterialInterface* Material);
	void SetBrushFromAtlasInterface(FSlateBrush& Brush, TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize = false);
	void SetBrushFromTextureDynamic(FSlateBrush& Brush, UTexture2DDynamic* Texture, bool bMatchSize = false);
	void SetBrushFromTexture(FSlateBrush& Brush, UTexture2D* Texture, bool bMatchSize = false);

	TWeakObjectPtr<UWidget> WeakWidget;
	TSharedPtr<FStreamableHandle> Handle;
	FSoftObjectPath ObjectPath;

	FOnGetBrush OnGetBrush;
};
