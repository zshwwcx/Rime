// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Blueprint/KGBlackScreenUserWidget.h"

#include "Misc/CommonDefines.h"
//#include "UnrealEdGlobals.h"
#include "Core/Common.h"
//#include "Editor/UnrealEdEngine.h"
#include "UMG/Components/KGImage.h"
#include "3C/Util/KGUtils.h"

bool UKGBlackScreenUserWidget::Initialize()
{
    if (!HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
    {
        RegisterTick();
    }
    
    bool Result = Super::Initialize();
    if (ImgBackground)
    {
        ImgBackground->SetBrushTintColor(FLinearColor::Black);
    }
    
    return Result;
}

void UKGBlackScreenUserWidget::ReleaseSlateResources(bool bReleaseChildren)
{
    if (!HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
    {
        UnregisterTick();
    }
    
    Super::ReleaseSlateResources(bReleaseChildren);
    Curve = nullptr;
    bHasFading = false;
}

void UKGBlackScreenUserWidget::Tick(float DeltaTime)
{
    if (CurTime >= Duration || !bHasFading || !Curve)
    {
        return;
    }
    
    float LastTime = CurTime;
    CurTime = FMath::Clamp(DeltaTime + CurTime, 0, Duration);
    
    float Alpha;
    if (Duration <= EndOnCurve - StartOnCurve)
    {
        float Percent = FMath::Min(CurTime / FMath::Max(Duration, KINDA_SMALL_NUMBER), 1.f);
        float Time = FMath::Lerp(StartOnCurve, EndOnCurve, Percent);
        Alpha = Curve->GetFloatValue(Time);
    }
    else
    {
        if (bKeepOnEnding)
        {
            Alpha = StartOnCurve + CurTime <= EndOnCurve ? Curve->GetFloatValue(StartOnCurve + CurTime) :  ToAlpha;
        }
        else
        {
            float PreTime = Duration - (EndOnCurve - StartOnCurve);
            Alpha =  CurTime < PreTime ? FromAlpha : Curve->GetFloatValue(StartOnCurve + (CurTime - PreTime)); 
        }
    }
    
    Apply(Alpha);
    
    bHasFading = CurTime < Duration;
    if (LastTime < Duration && CurTime >= Duration)
    {
        OnFadeDone.Broadcast();
    }
    
    UE_LOG(LogKGUI, Log, TEXT("[BlackScreen]Alpha:%.3f time:%.3f deltaTime:%.3f"), Alpha, CurTime, DeltaTime);
}

bool UKGBlackScreenUserWidget::IsTickable() const
{
    if (HasAnyFlags(RF_ClassDefaultObject|RF_ArchetypeObject))
    {
        return false;
    }
    
    return Duration > 0 && bHasFading && IsValid(Curve);
}

void UKGBlackScreenUserWidget::SetCurve(UCurveFloat* InCurve)
{
    if (Curve != InCurve)
    {
        Curve = InCurve;
    }
}

bool UKGBlackScreenUserWidget::PlayCurve(float InDuration, float InStartOnCurve, float InLengthOnCurve, bool bInKeepOnEnding )
{
    if (!Curve)
    {
        return false;
    }
    
    Duration = FMath::Max(InDuration, 0.f);
    bKeepOnEnding = bInKeepOnEnding;
    
    float MinTime, MaxTime;
    Curve->GetTimeRange(MinTime, MaxTime);
    StartOnCurve = FMath::Clamp(InStartOnCurve, MinTime, MaxTime);
    EndOnCurve = InLengthOnCurve < 0 ? MaxTime : StartOnCurve + FMath::Min(InLengthOnCurve, MaxTime - StartOnCurve);
    
    FromAlpha = Curve->GetFloatValue(StartOnCurve);
    ToAlpha = Curve->GetFloatValue(EndOnCurve);
    
    CurTime = 0;
    float Alpha;
    if (FMath::IsNearlyZero(Duration))
    {
        bHasFading =  false;
        Alpha = ToAlpha;
    }
    else
    {
        bHasFading = true;
        Alpha = FromAlpha;
    }

    Apply(Alpha);
    
    if (!bHasFading)
    {
        OnFadeDone.Broadcast();
    }
    
    /*if (FromAlpha > ToAlpha)
    {
        GUnrealEd->SetPIEWorldsPaused(true);
        GUnrealEd->PlaySessionPaused();
        bHasFading = false;
    }*/
    
    
    return true;
}

void UKGBlackScreenUserWidget::Apply(float InAlpha) const
{
    FLinearColor Color = FLinearColor::Black;
    Color.A = InAlpha;
    
    if (ImgBackground)
    {
        ImgBackground->SetBrushTintColor(Color);
    }
    
    // if(APlayerCameraManager* CameraManager = UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0))
    // {
    //     CameraManager->SetManualCameraFade(Color.A, FLinearColor::Black, false);
    // }
}
