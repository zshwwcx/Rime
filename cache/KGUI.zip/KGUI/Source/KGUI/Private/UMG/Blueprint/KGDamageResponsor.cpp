// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Blueprint/KGDamageResponsor.h"
#include "Animation/WidgetAnimation.h"

FOnDamageResponsorBinded UKGDamageResponsor::OnDamageResponsorBinded;
FOnDamageResponsorBinded UKGDamageResponsor::OnDamageResponsorUnbinded;

void UKGDamageResponsor::Bind(int64 InEntityID, UWidgetAnimation* InAnimOnDamage)
{
	EntityID = InEntityID;
	AnimOnDamage = InAnimOnDamage;
	OnDamageResponsorBinded.Broadcast(InEntityID, this);
}

void UKGDamageResponsor::Unbind()
{
	OnDamageResponsorUnbinded.Broadcast(EntityID, this);

	EntityID = INDEX_NONE;
	AnimOnDamage = nullptr;
}

void UKGDamageResponsor::PlayDamage()
{
	if (AnimOnDamage)
	{
		PlayAnimation(AnimOnDamage);
	}
}
