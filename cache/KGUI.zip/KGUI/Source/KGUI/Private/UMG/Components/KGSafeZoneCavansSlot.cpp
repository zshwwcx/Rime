// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGSafeZoneCavansSlot.h"

#include "UMG/Components/KGSafeZoneCanvas.h"


void UKGSafeZoneCavansSlot::SynchronizeProperties()
{
	Super::SynchronizeProperties();

	if ( IsValid( Parent ) )
	{
		CastChecked< UKGSafeZoneCanvas >( Parent )->UpdateWidgetProperties();
	}
}
