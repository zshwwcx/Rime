﻿#include "UMG/Components/KGDelayLoadWidget.h"
#if WITH_EDITOR
#include "Editor/WidgetCompilerLog.h"
#endif
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"

#define LOCTEXT_NAMESPACE "KGUI"

void UKGDelayLoadWidget::CreateDelayWidgetAsync()
{
	CreateDelayWidget(true);
}

void UKGDelayLoadWidget::CreateDelayWidgetSync()
{
	CreateDelayWidget(false);
}

UKGUserWidget* UKGDelayLoadWidget::GetDelayWidget() 
{
	return DelayWidget;
}

bool UKGDelayLoadWidget::IsDelayWidgetLoaded()
{
	return IsValid(DelayWidget);
}

void UKGDelayLoadWidget::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	
	MyBox.Reset();
	if (StreamingHandle.IsValid())
	{
		StreamingHandle->CancelHandle();
		StreamingHandle.Reset();
	}
}

#if WITH_EDITOR
void UKGDelayLoadWidget::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	
	FName PropertyName = (PropertyChangedEvent.Property != nullptr) ? PropertyChangedEvent.Property->GetFName() : NAME_None;

	if (PropertyName == GET_MEMBER_NAME_CHECKED(UKGDelayLoadWidget, DelayWidgetClass))
	{
		if (DelayWidget)
		{
			DelayWidget->RemoveFromParent();
			DelayWidget = nullptr;
		
			if ( MyBox.IsValid())
			{
				MyBox->SetContent(SNullWidget::NullWidget);
			}
		}
		
		CreateDelayWidget(false);
	}
}

void UKGDelayLoadWidget::ValidateCompiledDefaults(IWidgetCompilerLog& CompileLog) const
{
	if (!DelayWidgetClass.IsValid() && !DelayWidgetClass.ToSoftObjectPath().IsValid())
	{
		CompileLog.Error(FText::Format(LOCTEXT("Error_KGDelayLoadWidget_MissingDelayWidgetClass", "{0} DelayWidgetClass = nullptr"), FText::FromString(GetName())));
	}
}
#endif

TSharedRef<SWidget> UKGDelayLoadWidget::RebuildWidget()
{
	if (!MyBox.IsValid())
	{
		MyBox = SNew(SBox);
	}

#if WITH_EDITOR
	if (IsDesignTime())
	{
		CreateDelayWidget(false);
		return MyBox.ToSharedRef();
	}
#endif

	if (DelayLoadType == EDelayLoadType::AutoLoadOnRebuild)
	{
		CreateDelayWidget(true);
	}

	return MyBox.ToSharedRef();
}

void UKGDelayLoadWidget::CreateDelayWidget(bool Async)
{
	if (!DelayWidgetClass.IsValid() && !DelayWidgetClass.ToSoftObjectPath().IsValid())
	{
		return;
	}

	if (StreamingHandle.IsValid() && !StreamingHandle->HasLoadCompleted())
	{
		return;
	}

	if (DelayWidget)
	{
		ShowWidget();
		return;
	}

	if (Async)
	{
		LoadWidgetAsync();
	}
	else
	{
		LoadWidgetSync();
	}
}

void UKGDelayLoadWidget::LoadWidgetAsync()
{
	FStreamableManager& StreamableManager = UAssetManager::GetStreamableManager();
	StreamingHandle = StreamableManager.RequestAsyncLoad(DelayWidgetClass.ToSoftObjectPath(), FStreamableDelegate::CreateUObject(this, &UKGDelayLoadWidget::OnWidgetClassAsyncLoaded), FStreamableManager::AsyncLoadHighPriority);
}

void UKGDelayLoadWidget::LoadWidgetSync()
{
	TSubclassOf<UKGUserWidget> LoadedWidgetClass = DelayWidgetClass.LoadSynchronous();
	if (!LoadedWidgetClass)
	{
		UE_LOG(LogTemp, Warning, TEXT("LoadedWidgetClass = nil, path = %s"), *DelayWidgetClass.ToSoftObjectPath().ToString());
		return;
	}
		
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogTemp, Warning, TEXT("World = nil"));
		return;
	}
		
	DelayWidget = CreateWidget<UKGUserWidget>(World, LoadedWidgetClass);
	ShowWidget();

	OnLoadFinishEvent.Broadcast(DelayWidget);
}

void UKGDelayLoadWidget::OnWidgetClassAsyncLoaded()
{
	if (!DelayWidgetClass.IsValid())
	{
		UE_LOG(LogTemp, Warning, TEXT("LoadedWidgetClass = nil, path = %s"), *DelayWidgetClass.ToSoftObjectPath().ToString());
		return;
	}

	TSubclassOf<UKGUserWidget> LoadedWidgetClass = DelayWidgetClass.Get();
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogTemp, Warning, TEXT("World = nil"));
		return;
	}
	
	DelayWidget = CreateWidget<UKGUserWidget>(World, LoadedWidgetClass);
	ShowWidget();

	OnLoadFinishEvent.Broadcast(DelayWidget);
}

void UKGDelayLoadWidget::ShowWidget()
{
	if ( MyBox.IsValid())
	{
		MyBox->SetContent(DelayWidget->TakeWidget());
	}

	InvalidateLayoutAndVolatility();
}

#undef LOCTEXT_NAMESPACE