#include "UMG/Components/KGRichTextBlockDecoratorSlateBrushGenerator.h"

#include "PaperSprite.h"
#include "PaperSpriteBlueprintLibrary.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Brushes/SlateNoResource.h"
#include "Components/RichTextBlockImageDecorator.h"
#include "Engine/Texture2D.h"
#include "Materials/Material.h"

void FKGRichTextBlockDecoratorSlateBrushGenerator::Initialize(const TArray<TObjectPtr<UDataTable>>& InRichImageDataTables)
{
	RichImageDataTables = InRichImageDataTables;
}

void FKGRichTextBlockDecoratorSlateBrushGenerator::RemoveBrush(FName RichImageRowID, const FString& ResourcePath)
{
	FKGRichTextBlockDecoratorSlateBrushKey Key;
	Key.RichImageRowID = RichImageRowID;
	Key.ResourcePath = ResourcePath;
	RemoveBrush(Key);
}

void FKGRichTextBlockDecoratorSlateBrushGenerator::RemoveBrush(const FString& ResourcePath)
{
	RemoveBrush(NAME_None, ResourcePath);
}

void FKGRichTextBlockDecoratorSlateBrushGenerator::RemoveBrush(FName RichImageRowID)
{
	RemoveBrush(RichImageRowID, FString());
}

void FKGRichTextBlockDecoratorSlateBrushGenerator::RemoveBrush(const FKGRichTextBlockDecoratorSlateBrushKey& Key)
{
	Brushes.Remove(Key);
	ResourceObjects.Remove(Key);
}

void FKGRichTextBlockDecoratorSlateBrushGenerator::Empty()
{
	Brushes.Empty();
	ResourceObjects.Empty();
}


bool FKGRichTextBlockDecoratorSlateBrushGenerator::IsRichImageRowValid(FName RichImageRowID, bool bWarnIfMissing) const
{
	if (RichImageRowID != NAME_None)
	{
		static FString ContextString = TEXT("FKGRichTextBlockDecoratorSlateBrushGenerator::IsRichImageRowValid");
		for (auto RichImageDataTable : RichImageDataTables)
		{
			auto RichImageRow = RichImageDataTable->FindRow<FRichImageRow>(RichImageRowID, ContextString, bWarnIfMissing);
			if (RichImageRow != nullptr)
			{
				return true;
			}
		}
	}
	return false;
}

void FKGRichTextBlockDecoratorSlateBrushGenerator::MakeBrushInternal(const FKGRichTextBlockDecoratorSlateBrushKey& Key, bool bWarnIfMissing)
{
	if (Brushes.Contains(Key))
	{
		return;
	}
	const auto& RowID = Key.RichImageRowID;
	const FSlateBrush* TemplateBrush = nullptr;
	if (RowID != NAME_None)
	{
		static FString ContextString = TEXT("FKGRichTextBlockDecoratorSlateBrushGenerator::MakeBrushInternal");
		for (int Index = RichImageDataTables.Num() - 1; Index >= 0; Index--)
		{
			auto RichImageDataTable = RichImageDataTables[Index];
			auto RichImageRow = RichImageDataTable->FindRow<FRichImageRow>(RowID, ContextString, bWarnIfMissing);
			if (RichImageRow != nullptr)
			{
				TemplateBrush = &RichImageRow->Brush;
				break;
			}
		}
	}
	const auto& ResourcePath = Key.ResourcePath;
	FSoftObjectPath ResourceSoftObjectPath = ResourcePath;
	TSoftObjectPtr<UObject> ResourceSoftObject = TSoftObjectPtr<UObject>(ResourceSoftObjectPath);
	auto ResourceObject = ResourceSoftObject.LoadSynchronous();
	bool bCreatedFromResourceObject = false;
	if (ResourceObject != nullptr)
	{
		if (auto Texture2D = Cast<UTexture2D>(ResourceObject))
		{
			if (TemplateBrush)
			{
				FSlateBrush TempBrush = *TemplateBrush;
				TempBrush.SetResourceObject(Texture2D);
				Brushes.Emplace(Key, MakeShared<FSlateBrush>(TempBrush));
			}
			else
			{
				Brushes.Emplace(Key, MakeShared<FSlateBrush>(UWidgetBlueprintLibrary::MakeBrushFromTexture(Texture2D)));
			}
			bCreatedFromResourceObject = true;
		}
		else if (auto PaperSprite = Cast<UPaperSprite>(ResourceObject))
		{
			if (TemplateBrush)
			{
				FSlateBrush TempBrush = *TemplateBrush;
				TempBrush.SetResourceObject(PaperSprite);
				Brushes.Emplace(Key, MakeShared<FSlateBrush>(TempBrush));
			}
			else
			{
				Brushes.Emplace(Key, MakeShared<FSlateBrush>(UPaperSpriteBlueprintLibrary::MakeBrushFromSprite(PaperSprite, 0, 0)));
			}
			bCreatedFromResourceObject = true;
		}
		else if (auto Material = Cast<UMaterial>(ResourceObject))
		{
			if (TemplateBrush)
			{
				FSlateBrush TempBrush = *TemplateBrush;
				TempBrush.SetResourceObject(Material);
				Brushes.Emplace(Key, MakeShared<FSlateBrush>(TempBrush));
			}
			else
			{
				Brushes.Emplace(Key, MakeShared<FSlateBrush>(UWidgetBlueprintLibrary::MakeBrushFromMaterial(Material)));
			}
			bCreatedFromResourceObject = true;
		}
		else
		{
			// Can not resolve this resource object type!
		}
	}
	if (bCreatedFromResourceObject)
	{
		ResourceObjects.Emplace(Key, ResourceObject);
	}
	else
	{
		if (TemplateBrush == nullptr)
		{
			Brushes.Emplace(Key, nullptr);
			ResourceObjects.Emplace(Key, nullptr);
		}
		else
		{
			Brushes.Emplace(Key, MakeShared<FSlateBrush>(*TemplateBrush));
			ResourceObjects.Emplace(Key, TemplateBrush->GetResourceObject());
		}
	}
}
