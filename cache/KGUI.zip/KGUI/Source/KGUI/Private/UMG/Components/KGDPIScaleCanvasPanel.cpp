// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGDPIScaleCanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include "UMG/Slate/SKGDPIConstraintCanvas.h"

TSharedRef<SWidget> UKGDPIScaleCanvasPanel::RebuildWidget() 
{
	
	MyCanvas = SNew(SKGDPIConstraintCanvas).bEnableDPIScale(bEnableDPIScale).DPIScale(UKGDPIScaleCanvasPanel::ApplicationScale);

	for ( UPanelSlot* PanelSlot : Slots )
	{
		if ( UCanvasPanelSlot* TypedSlot = Cast<UCanvasPanelSlot>(PanelSlot) )
		{
			TypedSlot->Parent = this;
			TypedSlot->BuildSlot(MyCanvas.ToSharedRef());
		}
	}

	return MyCanvas.ToSharedRef();

	
}

void UKGDPIScaleCanvasPanel::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);

	MyCanvas.Reset();
}


void UKGDPIScaleCanvasPanel::SynchronizeProperties()
{
	Super::SynchronizeProperties();

	if (!MyCanvas.IsValid())
	{
		return;
	}

	MyCanvas->SetEnableDPIScale(bEnableDPIScale);
	MyCanvas->SetRelativeDPIScale(ApplicationScale);
}

