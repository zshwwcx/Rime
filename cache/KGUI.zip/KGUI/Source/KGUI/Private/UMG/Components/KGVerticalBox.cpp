// Fill out your copyright notice in the Description page of Project Settings.

#include "UMG/Components/KGVerticalBox.h"
#include "Components/VerticalBoxSlot.h"

void UKGVerticalBox::OnSlotInserted(int32 Index, UPanelSlot* InSlot)
{
	// Add the child to the live canvas if it already exists
	if (MyVerticalBox.IsValid())
	{
		CastChecked<UVerticalBoxSlot>(InSlot)->InsertSlot(MyVerticalBox.ToSharedRef(), Index);
	}
}

void UKGVerticalBox::OnSlotMoved(int32 Index1, int32 Index2)
{
	if (MyVerticalBox.IsValid())
	{
		MyVerticalBox->MoveSlot(Index1, Index2);
	}
}

