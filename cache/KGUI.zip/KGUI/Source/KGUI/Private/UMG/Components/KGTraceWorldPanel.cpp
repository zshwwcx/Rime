#include "UMG/Components/KGTraceWorldPanel.h"
#include "SceneView.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "Engine/GameViewportClient.h"
#include "Slate/SGameLayerManager.h"
#include "Components/CanvasPanelSlot.h"
#include "GameFramework/Pawn.h"


/**
 * 计算一个点与椭圆圆心连线线段与椭圆的交点，返回值为交点是否在椭圆上
 *
 * @param Center 椭圆圆心
 * @param SemiMajor X半轴长
 * @param SemiMinor Y半轴长
 * @param Point 点
 * @param OutIntersection 交点 Point在椭圆内则为Point，反之为交点.
 * @return 返回值为交点是否在椭圆上
 */
static bool CalculateEllipseIntersectionWithPoint(const FVector2D& Center, float SemiMajor, float SemiMinor, const FVector2D& Point, FVector2D& OutIntersection, bool bUsePointAsResultWhenInEllipse = true)
{
	float dx = Point.X - Center.X;
	float dy = Point.Y - Center.Y;

	// 计算分母项，提前检查是否可能为0
	if (FMath::Abs(dx) < UE_SMALL_NUMBER && FMath::Abs(dy) < UE_SMALL_NUMBER)
	{
		// 点与椭圆中心重合，返回中心点作为交点
		OutIntersection = Center;
		return false;
	}

	// 轴长为0
	if (FMath::Abs(SemiMajor) < UE_SMALL_NUMBER || FMath::Abs(SemiMinor) < UE_SMALL_NUMBER)
	{
		OutIntersection = Center;
		return false;
	}

	float dxSquared = dx * dx;
	float dySquared = dy * dy;
	float semiMinorSquared = SemiMinor * SemiMinor;
	float semiMajorSquared = SemiMajor * SemiMajor;

	float denominatorTerm = dxSquared * semiMinorSquared + dySquared * semiMajorSquared;

	// 计算直线参数方程的解t, t取正即可.
	float sqrtDenominator = FMath::Sqrt(denominatorTerm);
	float t = (SemiMajor * SemiMinor) / sqrtDenominator;

	// t大于1表示Point在椭圆内
	if (t > 1)
	{
		if (bUsePointAsResultWhenInEllipse)
		{
			OutIntersection.X = Point.X;
			OutIntersection.Y = Point.Y;
			return false;
		}
		// 计算交点坐标
		OutIntersection.X = Center.X + t * dx;
		OutIntersection.Y = Center.Y + t * dy;
		return true;
	}

	// 计算交点坐标
	OutIntersection.X = Center.X + t * dx;
	OutIntersection.Y = Center.Y + t * dy;

	return true;
}

void UKGTraceWorldPanel::BeginDestroy()
{
	ClearTraceWidgetsInfo();
	Super::BeginDestroy();
}

bool UKGTraceWorldPanel::IsTickable() const
{
	return !TraceWidgets.IsEmpty();
}

void UKGTraceWorldPanel::Tick(float DeltaTime) 
{
	UWorld* World = GetWorld();
	if (World == nullptr) { 
		return;
	}
	APlayerController* PlayerController = World->GetFirstPlayerController();
	if (PlayerController == nullptr) {
		return;
	}

	if (UGameViewportClient* ViewportClient = PlayerController->GetWorld()->GetGameViewport())
	{
		const FGeometry& ViewportGeometry = ViewportClient->GetGameLayerManager()->GetViewportWidgetHostGeometry();
		FVector2D ViewportSize;
		ViewportClient->GetViewportSize(ViewportSize);

		FSceneViewProjectionData ProjectionData;
		FMatrix ViewProjectionMatrix;
		bool bHasProjectionData = false;

		ULocalPlayer const* const LP = PlayerController->GetLocalPlayer();
		if (LP && LP->ViewportClient)
		{
			bHasProjectionData = LP->GetProjectionData(ViewportClient->Viewport, /*out*/ ProjectionData);
			if (bHasProjectionData)
			{
				ViewProjectionMatrix = ProjectionData.ComputeViewProjectionMatrix();
			}
		}
		if (!bHasProjectionData) {
			return;
		}

		FVector PlayerPosition;
		if (APawn* ControlledPawn = PlayerController->GetPawn())
		{
			PlayerPosition =  ControlledPawn->GetActorLocation();
		}
		else
		{
			return;
		}

		// 保护椭圆相关参数计算
		const FIntRect& ViewRect = ProjectionData.GetConstrainedViewRect();
		const FVector2D ViewRectSize((float)ViewRect.Width(), (float)ViewRect.Height());
		float SemiMajor = ViewRect.Width() * ProtectCircleAxis.X;
		float SemiMinor = ViewRect.Height() * ProtectCircleAxis.Y;
		FVector2D EllipseCenter = FVector2D(ViewRect.Width() * ProtectCircleCenter.X, ViewRect.Height() * ProtectCircleCenter.Y);
		FVector2D EllipseCenterViewportPos;
		USlateBlueprintLibrary::ScreenToViewport(PlayerController, EllipseCenter, OUT EllipseCenterViewportPos);

		for (auto& WidgetPair : TraceWidgets)
		{
			UUserWidget* WidgetComponent = WidgetPair.Value.Get();
			if (!IsValid(WidgetComponent))
			{
				continue;
			}
			FTraceWidgetPersistentState& WidgetState = TraceWigdetsPersistentStates[WidgetPair.Key];
			FVector& WorldLocation = WidgetState.WorldPos;
			FVector2D ScreenPosition2D;
			const bool bProjected = FSceneView::ProjectWorldToScreen(WorldLocation, ProjectionData.GetConstrainedViewRect(), ViewProjectionMatrix, ScreenPosition2D, true);
			// 非透视情况下，不在高处的点，始终处于椭圆下方
			if (!bProjected && ScreenPosition2D.Y < EllipseCenter.Y && WorldLocation.Z - PlayerPosition.Z < HighPlaceDistance)
			{
				ScreenPosition2D.Y = ScreenPosition2D.Y + 2 * (EllipseCenter.Y - ScreenPosition2D.Y);
			}
			// 没变化，略过更新
			const FVector2D& LastScreenPos = WidgetState.ScreenPositionPos;
			if (FMath::Abs(LastScreenPos.X - ScreenPosition2D.X) < MinOpzChangeLength && (FMath::Abs(LastScreenPos.Y - ScreenPosition2D.Y) < MinOpzChangeLength))
			{
				WidgetState.bNeedUpdate = false;
				continue;
			}
			WidgetState.bNeedUpdate = true;
			WidgetState.ScreenPositionPos = ScreenPosition2D;

			UCanvasPanelSlot* WidgetSlot = Cast<UCanvasPanelSlot>(WidgetComponent->Slot);
			// if (bProjected && WidgetSlot)
			if (WidgetSlot)
			{
				FVector2D FinalScreenPos;
				bool bIsOnEdge = CalculateEllipseIntersectionWithPoint(EllipseCenter, SemiMajor, SemiMinor, ScreenPosition2D, FinalScreenPos, bProjected);
				WidgetState.bIsOnEdge = bIsOnEdge;
				WidgetState.bProjected = bProjected;

				USlateBlueprintLibrary::ScreenToViewport(PlayerController, ScreenPosition2D, OUT WidgetState.RawViewPortPos);
				USlateBlueprintLibrary::ScreenToViewport(PlayerController, FinalScreenPos, OUT WidgetState.FinalViewPortPos);
				// 透视范围内和外，两种角度指向，算法不一样
				if (bProjected)
				{
					FVector2D DirectionVec = WidgetState.RawViewPortPos - WidgetState.FinalViewPortPos;
					WidgetState.Direction = FMath::Atan2(DirectionVec.Y, DirectionVec.X);
				}
				else
				{
					FVector2D DirectionVec = WidgetState.FinalViewPortPos - EllipseCenterViewportPos;
					WidgetState.Direction = FMath::Atan2(DirectionVec.Y, DirectionVec.X);
				}
			}
		}

		// 局部调整多个控件位置至多个控件之间不相互遮挡
		// 这并不是一个完美的局部调整的算法，但是应该能cover大部分多指引的场景，并且它只是个UI表现
		TSet<int32> AdjustedWidgets;
		FVector2D ViewPortEllipseCenter;
		USlateBlueprintLibrary::ScreenToViewport(PlayerController, EllipseCenter, OUT ViewPortEllipseCenter);
		SemiMajor = SemiMajor * ViewPortEllipseCenter.X / EllipseCenter.X;
		SemiMinor = SemiMinor * ViewPortEllipseCenter.Y / EllipseCenter.Y;
		for (auto& WidgetStatePair : TraceWigdetsPersistentStates)
		{
			FTraceWidgetPersistentState& WidgetState = WidgetStatePair.Value;
			UUserWidget* AdjustWidget = TraceWidgets[WidgetState.TraceID].Get();
			if (!IsValid(AdjustWidget))
			{
				continue;
			}
			if (AdjustedWidgets.IsEmpty())
			{
				AdjustedWidgets.Add(WidgetState.TraceID);
				continue;
			}
			UCanvasPanelSlot* WidgetSlot = Cast<UCanvasPanelSlot>(AdjustWidget->Slot);
			if (WidgetSlot == nullptr)
			{
				continue;
			}

			int32 FirstInsertWidgetID = -1;
			FVector2D AdjustStartPos;
			for (int32 Step = 1; Step <= MaxAdaptSteps; Step++)
			{
				// 只与已经调整好的做比较
				bool bInsectWithWidgets = false;
				for (auto& CompareWidgetID : AdjustedWidgets)
				{
					UUserWidget* CompareWidget = TraceWidgets[CompareWidgetID].Get();
					const FTraceWidgetPersistentState& CompareWidgetState = TraceWigdetsPersistentStates[CompareWidgetID];

					FVector2D CurDistance = WidgetState.FinalViewPortPos - CompareWidgetState.FinalViewPortPos;
					bInsectWithWidgets = CurDistance.Size() < AdaptDistance;
					if (bInsectWithWidgets)
					{
						if (FirstInsertWidgetID == -1)
						{
							FirstInsertWidgetID = CompareWidgetID;
							AdjustStartPos = WidgetState.FinalViewPortPos;
						}
						break;
					}
				}
				if (!bInsectWithWidgets)
				{
					break;
				}
				// 按照上面计算的结果，做调整, 注意的是，每一步调整方向有可能是不一致的
				const FTraceWidgetPersistentState& FirstInsectWidgetState = TraceWigdetsPersistentStates[FirstInsertWidgetID];
				FVector2D AdjustNormal = WidgetState.FinalViewPortPos - FirstInsectWidgetState.FinalViewPortPos;
				bool bNormalizeSuc = AdjustNormal.Normalize();
				// 证明是重合了，随便找一个方向调整
				if (!bNormalizeSuc)
				{
					AdjustNormal.X = 0.6;
					AdjustNormal.Y = 0.8;
				}
				FVector2D RealViewPortPos = AdjustStartPos + AdaptDistance * AdaptRatio * Step * AdjustNormal;
				// 再次与保护椭圆求交
				WidgetState.bIsOnEdge = CalculateEllipseIntersectionWithPoint(ViewPortEllipseCenter, SemiMajor, SemiMinor, RealViewPortPos, WidgetState.FinalViewPortPos, WidgetState.bProjected);
				if (WidgetState.bProjected)
				{
					FVector2D DirectionVec = WidgetState.RawViewPortPos - WidgetState.FinalViewPortPos;
					WidgetState.Direction = FMath::Atan2(DirectionVec.Y, DirectionVec.X);
				}
				else
				{
					FVector2D DirectionVec = WidgetState.FinalViewPortPos - EllipseCenterViewportPos;
					WidgetState.Direction = FMath::Atan2(DirectionVec.Y, DirectionVec.X);
				}
			}
			AdjustedWidgets.Add(WidgetState.TraceID);
		}
		// 执行Tick级别的UI调整
		for (const auto& WidgetStatePair : TraceWigdetsPersistentStates)
		{
			const FTraceWidgetPersistentState& WidgetState = WidgetStatePair.Value;
			if (!WidgetState.bNeedUpdate)
			{
				continue;
			}
			const int32& TraceID = WidgetStatePair.Key;
			UUserWidget* WidgetComponent = TraceWidgets[WidgetState.TraceID].Get();
			if (!IsValid(WidgetComponent))
			{
				continue;
			}
			if (UCanvasPanelSlot* WidgetSlot = Cast<UCanvasPanelSlot>(WidgetComponent->Slot))
			{
				WidgetSlot->SetPosition(WidgetState.FinalViewPortPos);
			}

			// 指引箭头UI处理
			if (UWidget* ArrowImg = WidgetComponent->GetWidgetFromName(FName("CP_SmallArrow")))
			{
				if (WidgetState.bIsOnEdge)
				{
					ArrowImg->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
				}
				else
				{
					ArrowImg->SetVisibility(ESlateVisibility::Collapsed);
				}
				if (WidgetState.bIsOnEdge)
				{
					float Angle = WidgetState.Direction * 180 / PI - 90;
					ArrowImg->SetRenderTransformAngle(Angle);
				}
			}
		}
	}
}

int32 UKGTraceWorldPanel::AddWidget(UUserWidget* InWidget, const FVector& WorldPos)
{
	DynamicTraceID++;
	TraceWigdetsPersistentStates.Add(DynamicTraceID, FTraceWidgetPersistentState(DynamicTraceID, WorldPos));
	TraceWidgets.Add(DynamicTraceID, InWidget);

	if (UCanvasPanelSlot* WidgetSlot = Cast<UCanvasPanelSlot>(InWidget->Slot))
	{
		WidgetSlot->SetAlignment(FVector2D(0.5, 0.5));
		WidgetSlot->SetAnchors(FAnchors(0, 0));
	}

	return DynamicTraceID;
}

void UKGTraceWorldPanel::SetWorldPos(int32 TraceID, const FVector& InWorldPos)
{
	if (FTraceWidgetPersistentState* WidgetState = TraceWigdetsPersistentStates.Find(TraceID))
	{
		WidgetState->WorldPos = InWorldPos;
	}
}

void UKGTraceWorldPanel::RemoveWidget(int32 TraceID)
{
	TraceWigdetsPersistentStates.Remove(TraceID);
	TraceWidgets.Remove(TraceID);
}

void UKGTraceWorldPanel::ClearTraceWidgetsInfo()
{
	TraceWigdetsPersistentStates.Empty();
	TraceWidgets.Empty();
}
