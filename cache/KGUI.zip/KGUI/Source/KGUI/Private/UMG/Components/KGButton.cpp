// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGButton.h"

#include "AkAudioEvent.h"
#include "Manager/KGAkAudioManager.h"
#include "Components/ButtonSlot.h"
#include "Slate/Components/SKGButton.h"

TSharedRef<SWidget> UKGButton::RebuildWidget()
{
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
		MyButton = SNew(SKGButton)
		.OnClicked(BIND_UOBJECT_DELEGATE(FOnClicked, SlateHandleClicked))
		.OnPressed(BIND_UOBJECT_DELEGATE(FSimpleDelegate, SlateHandlePressed))
		.OnReleased(BIND_UOBJECT_DELEGATE(FSimpleDelegate, SlateHandleReleased))
		.OnHovered_UObject(this, &ThisClass::SlateHandleHovered)
		.OnUnhovered_UObject(this, &ThisClass::SlateHandleUnhovered)
		.ButtonStyle(&WidgetStyle)
		.ClickMethod(ClickMethod)
		.TouchMethod(TouchMethod)
		.PressMethod(PressMethod)
		.IsFocusable(IsFocusable)
		;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
		if (GetChildrenCount() > 0)
		{
			Cast<UButtonSlot>(GetContentSlot())->BuildSlot(MyButton.ToSharedRef());
		}

	TSharedRef<SKGButton> MyKGButton = StaticCastSharedRef<SKGButton>(MyButton.ToSharedRef());
	MyKGButton.Get().SetOnRightClicked(BIND_UOBJECT_DELEGATE(FOnClicked, SlateHandleRightClicked));
	if (HoverPressAnim.bEnable)
	{
		HoverPressAnimDriver = MakeShareable(new FKGInteractableArea(this, HoverPressAnim));
		HoverPressAnimDriver->OnWidgetRebuild();
	}

	if (WidgetAkEvent.ToSoftObjectPath().IsValid())
	{
		OnClicked.AddDynamic(this, &UKGButton::PostWidgetAudio);	
	}
	
	return MyKGButton;
}

void UKGButton::ReleaseSlateResources(bool bReleaseChildren)
{
	if (HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnReleaseSlateResources();
		HoverPressAnimDriver.Reset();
	}

	OnClicked.RemoveDynamic(this, &UKGButton::PostWidgetAudio);

	Super::ReleaseSlateResources(bReleaseChildren);
}

void UKGButton::SetOnClicked(const FOnButtonClickedUniCastEvent& InOnClicked)
{
	C7OnClicked = InOnClicked;
}

void UKGButton::SetOnRightClicked(const FOnButtonClickedUniCastEvent& InOnRightClicked)
{
	C7OnRightClicked = InOnRightClicked;
}

void UKGButton::PostWidgetAudio()
{
	if (UKGAkAudioManager* AkAudioMgr = UKGAkAudioManager::GetInstance(this))
	{
		if (WidgetAkEvent.ToSoftObjectPath().IsValid())
		{
		    AkAudioMgr->InnerPostEvent3D(WidgetAkEvent.GetAssetName());
		}
	}
}

FReply UKGButton::SlateHandleClicked()
{
	OnClicked.Broadcast();
	if (C7OnClicked.IsBound())
	{
		return C7OnClicked.Execute().NativeReply;
	}
	return FReply::Handled();
}

FReply UKGButton::SlateHandleRightClicked()
{
	C7OnRightClickedMulti.Broadcast();
	if (C7OnRightClicked.IsBound())
	{
		return C7OnRightClicked.Execute().NativeReply;
	}
	return FReply::Handled();
}

void UKGButton::SlateHandlePressed()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnPressed();
	}
	Super::SlateHandlePressed();
}

void UKGButton::SlateHandleReleased()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnReleased();
	}
	Super::SlateHandleReleased();
}

void UKGButton::SlateHandleHovered()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnHovered();
	}
	Super::SlateHandleHovered();
}

void UKGButton::SlateHandleUnhovered()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnUnhovered();
	}
	Super::SlateHandleUnhovered();
}
