#include "UMG/Components/KGMultiLineEditableText.h"

#include "AkAudioEvent.h"
#include "Manager/KGAkAudioManager.h"
#include "KGUI.h"
#include "Slate/Text/SKGMultiLineEditableText.h"
#include "Styling/DefaultStyleCache.h"
#include "UObject/ObjectSaveContext.h"

#if WITH_EDITOR
void UKGMultiLineEditableText::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	if (auto KGUI = FModuleManager::Get().GetModulePtr<FKGUIModule>("KGUI"))
	{
		KGUI->GetOnWidgetCreatedFromPalette().Broadcast(this);
	}
}
#endif

UKGMultiLineEditableText::UKGMultiLineEditableText(const FObjectInitializer& ObjectInitializer)
	: bCanInsertCarriageReturn(false)
	, DisallowedChars("\r\n")
{
	HintTextStyle = WidgetStyle;
	HintTextStyle.ColorAndOpacity = FLinearColor(1, 1, 1, 0.35);
	AllowContextMenu = false;
}

TSharedRef<SWidget> UKGMultiLineEditableText::RebuildWidget()
{
	auto MultiLineEditableText = ConstructWidget<SKGMultiLineEditableText>("SKGMultiLineEditableText");

	MultiLineEditableText->SetOnFocusReceived(BIND_UOBJECT_DELEGATE(SKGMultiLineEditableText::FOnFocusReceived, HandleOnFocusReceived));
	MultiLineEditableText->SetOnFocusLost(BIND_UOBJECT_DELEGATE(SKGMultiLineEditableText::FOnFocusLost, HandleOnFocusLost));

	MultiLineEditableText->SetHintTextStyleAttribute(
		TAttribute<FTextBlockStyle>::Create(
			TAttribute<FTextBlockStyle>::FGetter::CreateUObject(this, &UKGMultiLineEditableText::GetHintTextStyle)
		)
	);
	MultiLineEditableText->SetCanInsertCarriageReturn(bCanInsertCarriageReturn);
	MultiLineEditableText->SetOnIsCharAllowed(SKGMultiLineEditableText::FOnIsCharAllowed::CreateUObject(this, &UKGMultiLineEditableText::HandleOnIsCharAllowed));

	if (WidgetAkEvent.ToSoftObjectPath().IsValid())
	{
		OnFocusReceived.AddDynamic(this, &UKGMultiLineEditableText::PostWidgetAudio);
	}

	MyMultiLineEditableText = MultiLineEditableText;
	return MyMultiLineEditableText.ToSharedRef();
}

void UKGMultiLineEditableText::ReleaseSlateResources(bool bReleaseChildren)
{
	OnFocusReceived.RemoveDynamic(this, &UKGMultiLineEditableText::PostWidgetAudio);
	Super::ReleaseSlateResources(bReleaseChildren);
}

void UKGMultiLineEditableText::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	if (MyMultiLineEditableText)
	{
		MyMultiLineEditableText->SetAllowContextMenu(false);
	}
}

void UKGMultiLineEditableText::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);
	AllowContextMenu = false;
}

void UKGMultiLineEditableText::PostWidgetAudio(const FFocusEvent& FocusEvent)
{
	if (UKGAkAudioManager* AkAudioMgr = UKGAkAudioManager::GetInstance(this))
	{
		if (WidgetAkEvent.ToSoftObjectPath().IsValid())
		{
		    AkAudioMgr->InnerPostEvent3D(WidgetAkEvent.GetAssetName());
		}
	}
}

void UKGMultiLineEditableText::HandleOnFocusReceived(const FFocusEvent& FocusEvent)
{
	OnFocusReceived.Broadcast(FocusEvent);
}

void UKGMultiLineEditableText::HandleOnFocusLost(const FFocusEvent& FocusEvent)
{
	OnFocusLost.Broadcast(FocusEvent);
}

#pragma region HintText样式

void UKGMultiLineEditableText::SetHintTextStyle(const FTextBlockStyle& InHintTextStyle)
{
	HintTextStyle = InHintTextStyle;
}

FTextBlockStyle UKGMultiLineEditableText::GetHintTextStyle() const
{
	return HintTextStyle;
}

#pragma endregion

#pragma region 回车换行

void UKGMultiLineEditableText::SetCanInsertCarriageReturn(bool InbCanInsertCarriageReturn)
{
	bCanInsertCarriageReturn = InbCanInsertCarriageReturn;
	if (auto MultiLineEditableText = StaticCastSharedPtr<SKGMultiLineEditableText>(MyMultiLineEditableText))
	{
		MultiLineEditableText->SetCanInsertCarriageReturn(bCanInsertCarriageReturn);
	}
}

#pragma endregion

#pragma region 字符限制

void UKGMultiLineEditableText::SetDisallowedChars(const FString& InDisallowedChars)
{
	DisallowedChars = InDisallowedChars;
}

void UKGMultiLineEditableText::PostUpdateTextContent(const FText& InText, bool bUpdateSlateAnyway)
{
	auto NewString = InText.ToString();
	auto WeakThis = TWeakObjectPtr<UKGMultiLineEditableText>(this);
	bool bDirty = NewString.GetCharArray().RemoveAll([WeakThis](const TCHAR InChar) -> bool
	{
		if (InChar == 0 || !WeakThis.Get())
		{
			return false;
		}
		return !WeakThis->HandleOnIsCharAllowed(InChar);
	}) != 0;
	if (bDirty)
	{
		Super::PostUpdateTextContent(FText::FromString(NewString), true);
	}
	else
	{
		Super::PostUpdateTextContent(InText, false);
	}
}

bool UKGMultiLineEditableText::HandleOnIsCharAllowed(const TCHAR InChar) const
{
	if (MyMultiLineEditableText->IsComposing())
	{
		return true;
	}
	int32 Index = INDEX_NONE;
	return !DisallowedChars.FindChar(InChar, Index);
}

#pragma endregion
