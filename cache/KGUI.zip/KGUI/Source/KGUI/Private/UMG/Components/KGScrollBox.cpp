// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGScrollBox.h"

#include "Components/ScrollBoxSlot.h"
#include "Slate/Layout/SKGRotateBox.h"
#include "Slate/Layout/SKGScrollBox.h"
#include "UMG/Blueprint/KGUserWidget.h"

#if WITH_EDITOR
void UKGScrollBox::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	WidgetStyle.TopShadowBrush.DrawAs = ESlateBrushDrawType::NoDrawType;
	WidgetStyle.BottomShadowBrush.DrawAs = ESlateBrushDrawType::NoDrawType;
	WidgetStyle.LeftShadowBrush.DrawAs = ESlateBrushDrawType::NoDrawType;
	WidgetStyle.RightShadowBrush.DrawAs = ESlateBrushDrawType::NoDrawType;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	if (auto Settings = GetDefault<UKGUISettings>())
	{
		ScrollHintClassBefore = Settings->DefaultScrollHintClassBefore.LoadSynchronous();
		ScrollHintClassAfter = Settings->DefaultScrollHintClassAfter.LoadSynchronous();
	}
}
#endif

class SKGScrollBoxScrollHintWrapOverlay : public SOverlay
{
	using Super = SOverlay;

public:
	void Construct(const FArguments& InArgs, TSharedRef<SWidget> Content)
	{
		Super::Construct(InArgs);
		WeakContent = Content;
		this->bClippingProxy = true;
		this->AddSlot()
		[
			Content
		];
	}

protected:
	virtual void OnClippingChanged() override
	{
		auto Content = WeakContent.Pin();
		if (ensure(Content))
		{
			Content->SetClipping(this->Clipping);
		}
	}

private:
	TWeakPtr<SWidget> WeakContent;
};

TSharedRef<SWidget> UKGScrollBox::RebuildWidget()
{
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	auto ScrollBox = SNew(SKGScrollBox)
		.Style(&WidgetStyle)
		.ScrollBarStyle(&WidgetBarStyle)
		.Orientation(Orientation)
		.ConsumeMouseWheel(ConsumeMouseWheel)
		.NavigationDestination(NavigationDestination)
		.NavigationScrollPadding(NavigationScrollPadding)
		.ScrollWhenFocusChanges(ScrollWhenFocusChanges)
		.BackPadScrolling(BackPadScrolling)
		.FrontPadScrolling(FrontPadScrolling)
		.AnimateWheelScrolling(bAnimateWheelScrolling)
		.WheelScrollMultiplier(WheelScrollMultiplier)
		.OnUserScrolled(BIND_UOBJECT_DELEGATE(FOnUserScrolled, SlateHandleUserScrolled))
		.OnScrollBarVisibilityChanged(BIND_UOBJECT_DELEGATE(FOnScrollBarVisibilityChanged, SlateHandleScrollBarVisibilityChanged));
	MyScrollBox = ScrollBox;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
		for ( UPanelSlot* PanelSlot : Slots )
		{
			if ( UScrollBoxSlot* TypedSlot = Cast<UScrollBoxSlot>(PanelSlot) )
			{
				TypedSlot->Parent = this;
				TypedSlot->BuildSlot(MyScrollBox.ToSharedRef());
			}
		}

	MyScrollBox->SetOnUserTouchEnded(BIND_UOBJECT_DELEGATE(FOnUserTouchEnded, SlateHandleTouchEnded));

	TSharedRef<SWidget> Result = MyScrollBox.ToSharedRef();
	

	if (ScrollHintClassBefore.Get() != nullptr || ScrollHintClassAfter.Get() != nullptr)
	{
		auto Overlay = SNew(SKGScrollBoxScrollHintWrapOverlay, Result);
		WeakOverlay = Overlay;
		Result = Overlay;
		ScrollBox->SetOnDistanceFromBottomChanged(SKGScrollBox::FOnDistanceChanged::CreateUObject(this, &UKGScrollBox::HandleOnDistanceFromBottomChanged));
		ScrollBox->SetOnDistanceFromTopChanged(SKGScrollBox::FOnDistanceChanged::CreateUObject(this, &UKGScrollBox::HandleOnDistanceFromTopChanged));
	}

	return Result;
}

void UKGScrollBox::SlateHandleTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	if(OnUserTouchEnded.IsBound())
	{
		OnUserTouchEnded.Execute(MyGeometry, InTouchEvent);
	}
}

void UKGScrollBox::HandleOnDistanceFromTopChanged(float DistanceFromTop)
{
	UpdateScrollHintVisibility(EKGScrollBoxScrollHintType::Before, !FMath::IsNearlyEqual(DistanceFromTop, 0, 0.0001));
}

void UKGScrollBox::HandleOnDistanceFromBottomChanged(float DistanceFromBottom)
{
	UpdateScrollHintVisibility(EKGScrollBoxScrollHintType::After, !FMath::IsNearlyEqual(DistanceFromBottom, 0, 0.0001));
}

void UKGScrollBox::UpdateScrollHintVisibility(EKGScrollBoxScrollHintType ScrollHintType, bool bVisible)
{
	auto Overlay = WeakOverlay.Pin();
	if (!ensure(Overlay))
	{
		return;
	}
	TObjectPtr<UUserWidget>* ScrollHintPtr = nullptr;
	TWeakPtr<SWidget>* WeakScrollHintPtr = nullptr;
	TSubclassOf<UKGUserWidget> ScrollHintClass;
	switch (ScrollHintType)
	{
	case EKGScrollBoxScrollHintType::Before:
		ScrollHintPtr = &ScrollHintBefore;
		WeakScrollHintPtr = &WeakScrollHintBefore;
		ScrollHintClass = ScrollHintClassBefore;
		break;
	case EKGScrollBoxScrollHintType::After:
		ScrollHintPtr = &ScrollHintAfter;
		WeakScrollHintPtr = &WeakScrollHintAfter;
		ScrollHintClass = ScrollHintClassAfter;
		break;
	}
	if (!ScrollHintClass.Get())
	{
		return;
	}
	if (!ensure(ScrollHintPtr && WeakScrollHintPtr))
	{
		return;
	}
	auto& ScrollHintRef = *ScrollHintPtr;
	auto& WeakScrollHintRef = *WeakScrollHintPtr;
	if (WeakScrollHintRef.Pin() == nullptr)
	{
		if (ScrollHintRef == nullptr)
		{
			ScrollHintRef = CreateWidget(this, ScrollHintClass);
		}
		auto ScrollHintSlateWidget = ScrollHintRef->TakeWidget();
		WeakScrollHintRef = ScrollHintSlateWidget;
		SKGRotateBox::EType RotateType = SKGRotateBox::EType::NoRotate;
		PRAGMA_DISABLE_DEPRECATION_WARNINGS
		if (Orientation == Orient_Horizontal)
		{
			switch (ScrollHintType)
			{
			case EKGScrollBoxScrollHintType::Before:
				RotateType = SKGRotateBox::EType::Rotate270;
				break;
			case EKGScrollBoxScrollHintType::After:
				RotateType = SKGRotateBox::EType::Rotate90;
				break;
			}
		}
		else
		{
			switch (ScrollHintType)
			{
			case EKGScrollBoxScrollHintType::Before:
				RotateType = SKGRotateBox::EType::NoRotate;
				break;
			case EKGScrollBoxScrollHintType::After:
				RotateType = SKGRotateBox::EType::Rotate180;
				break;
			}
		}
		PRAGMA_ENABLE_DEPRECATION_WARNINGS
		Overlay->AddSlot()
		[
			SNew(SKGRotateBox)
			.Type(RotateType)
			.ScrollHintLineAxisPercentOffset(ScrollHintLineAxisPercentOffset)
			.ScrollHintScrollAxisOffset(ScrollHintScrollAxisOffset)
			[
				ScrollHintSlateWidget
			]
		];
	}
	ScrollHintRef->SetVisibility(bVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}
