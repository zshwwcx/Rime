#include "UMG/Components/KGBrushTextBlock.h"

#include "KGUI.h"
#include "KGUISettings.h"
#include "Fonts/FontMeasure.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Text/SlateTextRun.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SConstraintCanvas.h"
#include "Widgets/Layout/SSpacer.h"

#if WITH_EDITOR

void UKGBrushTextBlock::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	if (auto Settings = GetDefault<UKGUISettings>())
	{
		FallbackTextStyle = Settings->DefaultTextBlockStyle;
	}
	SetText(NSLOCTEXT("UMG", "TextBlockDefaultValue", "Text Block"));
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	if (auto KGUI = FModuleManager::Get().GetModulePtr<FKGUIModule>("KGUI"))
	{
		KGUI->GetOnWidgetCreatedFromPalette().Broadcast(this);
	}
}

#endif

TSharedRef<SWidget> UKGBrushTextBlock::RebuildWidget()
{
	RichTextBlock = SNew(SRichTextBlock);
	RichTextBlock->SetDecorators(TArray<TSharedRef<ITextDecorator>>{ MakeShared<FKGBrushCharRichTextDecorator>(this) });
	RichTextBlock->SetTextStyle(FallbackTextStyle);
	Super::SynchronizeTextLayoutProperties(*RichTextBlock);
	UpdateText();
	return RichTextBlock.ToSharedRef();
}

void UKGBrushTextBlock::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	RichTextBlock.Reset();
}

void UKGBrushTextBlock::OnShapedTextOptionsChanged(FShapedTextOptions InShapedTextOptions)
{
	Super::OnShapedTextOptionsChanged(InShapedTextOptions);
	if (RichTextBlock.IsValid())
	{
		InShapedTextOptions.SynchronizeShapedTextProperties(*RichTextBlock);
	}
}

void UKGBrushTextBlock::OnJustificationChanged(ETextJustify::Type InJustification)
{
	Super::OnJustificationChanged(InJustification);
	if (RichTextBlock.IsValid())
	{
		RichTextBlock->SetJustification(InJustification);
	}
}

void UKGBrushTextBlock::OnWrappingPolicyChanged(ETextWrappingPolicy InWrappingPolicy)
{
	Super::OnWrappingPolicyChanged(InWrappingPolicy);
	if (RichTextBlock.IsValid())
	{
		RichTextBlock->SetWrappingPolicy(InWrappingPolicy);
	}
}

void UKGBrushTextBlock::OnAutoWrapTextChanged(bool InAutoWrapText)
{
	Super::OnAutoWrapTextChanged(InAutoWrapText);
	if (RichTextBlock.IsValid())
	{
		RichTextBlock->SetAutoWrapText(InAutoWrapText);
	}
}

void UKGBrushTextBlock::OnWrapTextAtChanged(float InWrapTextAt)
{
	Super::OnWrapTextAtChanged(InWrapTextAt);
	if (RichTextBlock.IsValid())
	{
		RichTextBlock->SetWrapTextAt(InWrapTextAt);
	}
}

void UKGBrushTextBlock::OnLineHeightPercentageChanged(float InLineHeightPercentage)
{
	Super::OnLineHeightPercentageChanged(InLineHeightPercentage);
	if (RichTextBlock.IsValid())
	{
		RichTextBlock->SetLineHeightPercentage(InLineHeightPercentage);
	}
}

void UKGBrushTextBlock::OnApplyLineHeightToBottomLineChanged(bool InApplyLineHeightToBottomLine)
{
	Super::OnApplyLineHeightToBottomLineChanged(InApplyLineHeightToBottomLine);
	if (RichTextBlock.IsValid())
	{
		RichTextBlock->SetApplyLineHeightToBottomLine(InApplyLineHeightToBottomLine);
	}
}

void UKGBrushTextBlock::OnMarginChanged(const FMargin& InMargin)
{
	Super::OnMarginChanged(InMargin);
	if (RichTextBlock.IsValid())
	{
		RichTextBlock->SetMargin(InMargin);
	}
}

void UKGBrushTextBlock::SetText(const FText& InText)
{
#if WITH_EDITOR
	const bool bEnableTextBlockChangeCheck = GetDefault<UKGUISettings>()->bEnableTextBlockChangeCheck;
#else
	const static bool bEnableTextBlockChangeCheck = GetDefault<UKGUISettings>()->bEnableTextBlockChangeCheck;
#endif
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	if (bEnableTextBlockChangeCheck && /*!TextDelegate.IsBound() &&*/ (Text.IdenticalTo(InText) || (Text.IsInitializedFromString() && InText.IsInitializedFromString() && Text.EqualTo(InText))))
	{
		return;
	}
	PRAGMA_ENABLE_DEPRECATION_WARNINGS

	Text = InText;
	if (RichTextBlock.IsValid())
	{
		UpdateText();
	}
}

FText UKGBrushTextBlock::GetText() const
{
	return Text;
}

void UKGBrushTextBlock::UpdateText()
{
	if (BrushCharacters)
	{
		RichTextBlock->SetText(FText::FromString(ConvertToRichFormatText(Text.ToString())));
	}
	else
	{
		RichTextBlock->SetText(Text);
	}
}

FString UKGBrushTextBlock::ConvertToRichFormatText(const FString& HumanReadableString) const
{
	check(BrushCharacters);
	TStringBuilder<512> RichFormatText;
	TMap<TCHAR, bool> CharacterBrushableFastLookupTable;
	for (TCHAR Character : HumanReadableString)
	{
		if (!CharacterBrushableFastLookupTable.Contains(Character))
		{
			bool Brushable = BrushCharacters->FindRow<FKGBrushCharacterRow>(FName(*FString::Printf(TEXT("%c"), Character)), TEXT("Find Character Brush Row in Data Table"), false) != nullptr;
			CharacterBrushableFastLookupTable.Add(Character, Brushable);
		}
		if (CharacterBrushableFastLookupTable[Character])
		{
			RichFormatText.Append(TEXT("<Char value=\""));
			RichFormatText.AppendChar(Character);
			RichFormatText.Append(TEXT("\"/>"));
		}
		else
		{
			RichFormatText.AppendChar(Character);
		}
	}
	return RichFormatText.ToString();
}

#pragma region 计时动态效果

void UKGBrushTextBlock::SetCountDownTimeFormat(const FString& Format)
{
	GetOrCreateCountDownController().SetCountDownTimeFormat(Format);
}

void UKGBrushTextBlock::SetCountDownTimeFormatByCondition(
	double LowerBoundSeconds, EKGCountDownConditionIntervalType LowerIntervalType,
	double UpperBoundSeconds, EKGCountDownConditionIntervalType UpperIntervalType,
	const FString& Format)
{
	GetOrCreateCountDownController().SetCountDownTimeFormatByCondition(LowerBoundSeconds, LowerIntervalType, UpperBoundSeconds, UpperIntervalType, Format);
}

void UKGBrushTextBlock::SetCountDownTimeFormatByFirstNonzeroUnit(FName FirstNonzeroUnitName, const FString& Format)
{
	GetOrCreateCountDownController().SetCountDownTimeFormatByFirstNonzeroUnit(FirstNonzeroUnitName, Format);
}

void UKGBrushTextBlock::ClearCountDownTimeFormats()
{
	GetOrCreateCountDownController().ClearCountDownTimeFormats();
}

void UKGBrushTextBlock::PlayCountDown(double FromSeconds, double ToSeconds)
{
	GetOrCreateCountDownController().PlayCountDown(FromSeconds, ToSeconds);
}

void UKGBrushTextBlock::StopCountDown()
{
	GetOrCreateCountDownController().StopCountDown();
}

bool UKGBrushTextBlock::IsCountDownPlaying() const
{
	return GetOrCreateCountDownController().IsCountDownPlaying();
}

void UKGBrushTextBlock::BeginDestroy()
{
	ReleaseCountDown();
	Super::BeginDestroy();
}

void UKGBrushTextBlock::HandleOnCountDownFinished()
{
	BP_OnCountDownFinished.Broadcast();
}

void UKGBrushTextBlock::HandleOnCountDownTextChanged(FText&& InText)
{
	this->SetText(InText);
}

#pragma endregion

FKGBrushCharRichTextDecorator::FKGBrushCharRichTextDecorator(UKGBrushTextBlock* InOwner)
	: Owner(InOwner)
{
}

bool FKGBrushCharRichTextDecorator::Supports(const FTextRunParseResults& RunParseResult, const FString& OriginalText) const
{
	return GetMainBrushByRunInfo(RunParseResult, OriginalText) != nullptr;
}

TSharedRef<ISlateRun> FKGBrushCharRichTextDecorator::Create(const TSharedRef<class FTextLayout>& TextLayout, const FTextRunParseResults& RunParseResult, const FString& OriginalText, const TSharedRef<FString>& ModelText, const ISlateStyle* Style)
{
	check(Owner.Get());

	auto& FallbackTextStyle = Owner->FallbackTextStyle;

	FTextRange ModelRange;
	ModelRange.BeginIndex = ModelText->Len();

	FTextRunInfo RunInfo(RunParseResult.Name, FText::FromString(OriginalText.Mid(RunParseResult.ContentRange.BeginIndex, RunParseResult.ContentRange.EndIndex - RunParseResult.ContentRange.BeginIndex)));
	for (const TPair<FString, FTextRange>& Pair : RunParseResult.MetaData)
	{
		RunInfo.MetaData.Add(Pair.Key, OriginalText.Mid(Pair.Value.BeginIndex, Pair.Value.EndIndex - Pair.Value.BeginIndex));
	}

	auto* MainBrush = GetMainBrushByRunInfo(RunParseResult, OriginalText);
	if (MainBrush != nullptr && MainBrush->GetImageSize().X * MainBrush->GetImageSize().Y != 0)
	{
		*ModelText += TEXT('\u200B'); // Zero-Width Breaking Space
		ModelRange.EndIndex = ModelText->Len();

		// Calculate the baseline of the text within the owning rich text
		// Requested on demand as the font may not be loaded right now
		const FSlateFontInfo Font = FallbackTextStyle.Font;
		const float ShadowOffsetY = FMath::Min(0.0f, FallbackTextStyle.ShadowOffset.Y);

		TAttribute<int16> GetBaseline = TAttribute<int16>::CreateLambda([Font, ShadowOffsetY]()
		{
			const TSharedRef<FSlateFontMeasure> FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
			return FontMeasure->GetBaseline(Font) - ShadowOffsetY;
		});

		const TSharedRef<FSlateFontMeasure> FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();

		auto LineHeight = (float)FontMeasure->GetMaxCharacterHeight(FallbackTextStyle.Font, 1.0f);

		auto LetterSpacingScaled = FallbackTextStyle.Font.LetterSpacing * FallbackTextStyle.Font.Size / 1000;
		auto PaddingData = GetPaddingByRunInfo(RunParseResult, OriginalText);
		auto Padding = PaddingData == nullptr ? FMargin() : *PaddingData;
		Padding = Padding * (LineHeight / MainBrush->GetImageSize().Y);

		Padding.Left += LetterSpacingScaled * 0.5;
		Padding.Right += LetterSpacingScaled * 0.5;

		auto CharacterWidth = LineHeight * MainBrush->GetImageSize().X / MainBrush->GetImageSize().Y;

		TSharedPtr<SConstraintCanvas> Panel;

		auto ShadowOffset = FallbackTextStyle.ShadowOffset;

		auto Widget =
			SNew(SBox)
			.Padding(Padding)
			[
				SAssignNew(Panel, SConstraintCanvas)
			];

		if (auto ShadowBrush = GetShadowBrushByRunInfo(RunParseResult, OriginalText))
		{
			Panel->AddSlot()
			.AutoSize(true)
			.Anchors(FAnchors(ShadowOffset.X > 0 ? 0 : 1, ShadowOffset.Y > 0 ? 0 : 1))
			.Alignment(FVector2D(ShadowOffset.X > 0 ? 0 : 1, ShadowOffset.Y > 0 ? 0 : 1))
			.Offset(ShadowOffset)
			[
				SNew(SImage)
				.DesiredSizeOverride(FVector2D(CharacterWidth, LineHeight))
				.Visibility(EVisibility::SelfHitTestInvisible)
				.Image(ShadowBrush)
			];
		}
		else
		{
			Panel->AddSlot()
			[
				SNew(SSpacer)
			];
		}

		Panel->AddSlot()
		.AutoSize(true)
		.Anchors(FAnchors(ShadowOffset.X > 0 ? 0 : 1, ShadowOffset.Y > 0 ? 0 : 1))
		.Alignment(FVector2D(ShadowOffset.X > 0 ? 0 : 1, ShadowOffset.Y > 0 ? 0 : 1))
		[
			SNew(SImage)
			.DesiredSizeOverride(FVector2D(CharacterWidth, LineHeight))
			.Visibility(EVisibility::SelfHitTestInvisible)
			.Image(MainBrush)
		];

		FSlateWidgetRun::FWidgetRunInfo WidgetRunInfo(Widget, GetBaseline);
		return FSlateWidgetRun::Create(TextLayout, RunInfo, ModelText, WidgetRunInfo, ModelRange);;
	}
	else
	{
		ModelRange.EndIndex = ModelText->Len();
		return FSlateTextRun::Create(RunInfo, ModelText, FallbackTextStyle, ModelRange);
	}
}

const FKGBrushCharacterRow* FKGBrushCharRichTextDecorator::GetBrushCharacterRowByRunInfo(const FTextRunParseResults& RunInfo, const FString& OriginalText) const
{
	if (RunInfo.Name != TEXT("Char") || !RunInfo.MetaData.Contains("Value") || RunInfo.MetaData["Value"].Len() != 1)
	{
		return nullptr;
	}
	if (!Owner.Get() || !Owner->BrushCharacters)
	{
		return nullptr;
	}
	auto BrushCharacters = Owner->BrushCharacters;
	if (BrushCharacters->GetRowStruct() != FKGBrushCharacterRow::StaticStruct())
	{
		return nullptr;
	}
	auto ValueTextRange = RunInfo.MetaData["Value"];
	auto Character = OriginalText.Mid(ValueTextRange.BeginIndex, ValueTextRange.EndIndex - ValueTextRange.BeginIndex);
	return Owner->BrushCharacters->FindRow<FKGBrushCharacterRow>(FName(*Character), TEXT("Find Character Brush Row in Data Table"), false);
}

const FSlateBrush* FKGBrushCharRichTextDecorator::GetMainBrushByRunInfo(const FTextRunParseResults& RunInfo, const FString& OriginalText) const
{
	auto BrushCharacterRow = GetBrushCharacterRowByRunInfo(RunInfo, OriginalText);
	return BrushCharacterRow ? &BrushCharacterRow->MainBrush : nullptr;
}

const FSlateBrush* FKGBrushCharRichTextDecorator::GetShadowBrushByRunInfo(const FTextRunParseResults& RunInfo, const FString& OriginalText) const
{
	auto BrushCharacterRow = GetBrushCharacterRowByRunInfo(RunInfo, OriginalText);
	return BrushCharacterRow ? &BrushCharacterRow->ShadowBrush : nullptr;
}

const FMargin* FKGBrushCharRichTextDecorator::GetPaddingByRunInfo(const FTextRunParseResults& RunInfo, const FString& OriginalText) const
{
	auto BrushCharacterRow = GetBrushCharacterRowByRunInfo(RunInfo, OriginalText);
	return BrushCharacterRow ? &BrushCharacterRow->Padding : nullptr;
}
