// Fill out your copyright notice in the Description page of Project Settings.
#include "UMG/Components/KGRichTextBlockTextDecorator.h"

#include "UMG/Components/KGRichTextBlock.h"
#include "Framework/Text/SlateTextRun.h"
#include "Misc/DefaultValueHelper.h"
#include "UObject/UObjectGlobals.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Framework/Application/SlateApplication.h"
#include "Math/UnrealMathUtility.h"
#include "UMG/Blueprint/KGColorData.h"
#include "Widgets/Text/STextBlock.h"
#include "UMG/Blueprint/UIFunctionLibrary.h"

#define LOCTEXT_NAMESPACE "SATURDAY"

class SKGRichInlineText : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SKGRichInlineText)
	{}
	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, const FText& Content, const FTextBlockStyle& TextStyle, TOptional<int32> TextFontSize, TOptional<FSlateColor> Color)
	{
		FSlateFontInfo NewFontInfo = TextStyle.Font;
		if (TextFontSize.IsSet())
		{
			NewFontInfo.Size = TextFontSize.GetValue();
		}

		if (!Color.IsSet())
		{
			Color = TextStyle.ColorAndOpacity;
		}
		
		ChildSlot
		[
			SNew(STextBlock)
			.Text(Content)
			.TextStyle(&TextStyle)
			.Font(NewFontInfo)
			.ColorAndOpacity(Color.GetValue())
		];
	}
};

class FKGRichTextDecorator : public FRichTextDecorator
{
public:
	FKGRichTextDecorator(URichTextBlock* InOwner, UKGRichTextBlockTextDecorator* InDecorator)
		: FRichTextDecorator(InOwner)
		, Decorator(InDecorator)
	{
	}

	virtual bool Supports(const FTextRunParseResults& RunParseResult, const FString& Text) const override;


protected:
	virtual void CreateDecoratorText(const FTextRunInfo& RunInfo, FTextBlockStyle& InOutTextStyle, FString& InOutString) const override;
	
	const FTextBlockStyle* FindTextStyle(const FString& RowName, bool bWarnIfMissing) const;

private:
	UKGRichTextBlockTextDecorator* Decorator;
};



const FTextBlockStyle* FKGRichTextDecorator::FindTextStyle(const FString& RowName, bool bWarnIfMissing) const
{
	if (auto RichTextBlock = Cast<UKGRichTextBlock>(Owner))
	{
		if (auto StyleInstance = RichTextBlock->GetStyleInstanceInternal())
		{
			if (StyleInstance->HasWidgetStyle<FTextBlockStyle>(FName(RowName)))
			{
				return &StyleInstance->GetWidgetStyle<FTextBlockStyle>(FName(RowName));
			}
		}
	}
	return nullptr;
}

bool FKGRichTextDecorator::Supports(const FTextRunParseResults& RunParseResult, const FString& Text) const
{
	const bool bWarnIfMissing = false;
	
	return RunParseResult.Name == TEXT("_None_") || (FindTextStyle(RunParseResult.Name, bWarnIfMissing) != nullptr && RunParseResult.Name != TEXT("HyperLink"));
}


void FKGRichTextDecorator::CreateDecoratorText(const FTextRunInfo& RunInfo, FTextBlockStyle& InOutTextStyle, FString& InOutString) const
{
	InOutString.Append(RunInfo.Content.ToString()) ;
	bool bWarnIfMissing = true;
	const FString* StyleName = nullptr;
	if (RunInfo.Name == TEXT("_None_"))
	{
		StyleName = RunInfo.MetaData.Find(TEXT("stylename"));
	}
	else
	{
		StyleName = &RunInfo.Name;
	}

	if (StyleName != nullptr)
	{
		if (const auto NamedTextStyle = FindTextStyle(*StyleName, bWarnIfMissing))
		{
			InOutTextStyle = *NamedTextStyle;
		}
	}
		
	if (const FString* SizeString = RunInfo.MetaData.Find(TEXT("size")))
	{
		int32 Size;
		if (FDefaultValueHelper::ParseInt(*SizeString, Size) )
		{
			InOutTextStyle.SetFontSize(Size);
		}
	}
	
	if (const FString* ColorString = RunInfo.MetaData.Find(TEXT("color")))
	{
		FLinearColor NewColor = UUIFunctionLibrary::SRGBColorFromHex(*ColorString);
		InOutTextStyle.SetColorAndOpacity(FSlateColor(NewColor));
	}
	else if (const FString* TableColorString = RunInfo.MetaData.Find(TEXT("tablecolor")))
	{
		FString ColorTableName;
		FString ColorName;
		if(TableColorString->Split("_",&ColorTableName, &ColorName))
		{
			FString ColorTableDir = Decorator->GetColorTableDir();
			FPaths::NormalizeDirectoryName(ColorTableDir);
				
			const FString DTPath = "DataTable'/Game/" + ColorTableDir + "/" +"DT_" +ColorTableName + ".DT_" + ColorTableName + "'";
				
			UDataTable *ColorTable = LoadObject<UDataTable>(nullptr, *DTPath);
			if (ColorTable)
			{
				FString ContextString;
				FKGColorData* ColorRow = ColorTable->FindRow<FKGColorData>(FName(*ColorName), ContextString, bWarnIfMissing);
				if(ColorRow)
				{
					InOutTextStyle.SetColorAndOpacity(FSlateColor(ColorRow->Value));
				}
			}
		}
	}
	
}

/////////////////////////////////////////////////////
// USTRichTextImageDecorator

UKGRichTextBlockTextDecorator::UKGRichTextBlockTextDecorator(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	
}


TSharedPtr<ITextDecorator> UKGRichTextBlockTextDecorator::CreateDecorator(URichTextBlock* InOwner)
{
	return MakeShareable(new FKGRichTextDecorator(InOwner, this));
}

FString UKGRichTextBlockTextDecorator::GetColorTableDir()
{
	return ColorTableDir;
}

void UKGRichTextBlockTextDecorator::SetTextSet(UDataTable* InTextSet)
{
	TextSet = InTextSet;
}

void UKGRichTextBlockTextDecorator::SetColorDir(FString InColorTableDir)
{
	ColorTableDir = InColorTableDir;
}


/////////////////////////////////////////////////////

#undef LOCTEXT_NAMESPACE


