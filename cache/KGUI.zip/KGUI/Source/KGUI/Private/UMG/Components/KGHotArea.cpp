// Fill out your copyright notice in the Description page of Project Settings.

#include "UMG/Components/KGHotArea.h"
#include "Slate/UMGDragDropOp.h"
#include "Blueprint/DragDropOperation.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include <UMG/Slate/KGDragDropOp.h>
#include <Blueprint/WidgetBlueprintLibrary.h>
#include <UMG/Blueprint/KGUserWidget.h>
#include "AkAudioEvent.h"
#include "Manager/KGAkAudioManager.h"
#include "UMG/Components/KGInteractableArea.h"

TSharedRef<SWidget> UKGHotArea::RebuildWidget()
{
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	MyHotArea = SNew(SKGHotArea).OnClicked(BIND_UOBJECT_DELEGATE(FOnClicked, SlateHandleClicked))
		.OnRightClicked(BIND_UOBJECT_DELEGATE(FOnClicked, SlateHandleRightClicked))
		.OnPressed(BIND_UOBJECT_DELEGATE(FSimpleDelegate, SlateHandlePressed))
		.OnReleased(BIND_UOBJECT_DELEGATE(FSimpleDelegate, SlateHandleReleased))
		.OnHovered_UObject(this, &ThisClass::SlateHandleHovered)
		.OnUnhovered_UObject(this, &ThisClass::SlateHandleUnhovered)
		.OnFocusLostEvent_UObject(this, &ThisClass::SlateHandleOnFocusLost)
		.OnKeyDownEvent_UObject(this, &ThisClass::SlateHandleOnKeyDown)
		.OnKeyUpEvent_UObject(this, &ThisClass::SlateHandleOnKeyUp)
		.OnMouseButtonDownEvent_UObject(this, &ThisClass::SlateHandleOnMouseButtonDown)
		.OnMouseButtonDoubleClickEvent_UObject(this, &ThisClass::SlateHandleOnMouseButtonDoubleClick)
		.OnMouseButtonUpEvent_UObject(this, &ThisClass::SlateHandleOnMouseButtonUp)
		.OnMouseMoveEvent_UObject(this, &ThisClass::SlateHandleOnMouseMove)
		.OnMouseEnterEvent_UObject(this, &ThisClass::SlateHandleOnMouseEnter)
		.OnMouseLeaveEvent_UObject(this, &ThisClass::SlateHandleOnMouseLeave)
		.OnMouseCaptureLostEvent_UObject(this, &ThisClass::SlateHandleOnMouseCaptureLost)
		.OnFocusReceivedEvent_UObject(this, &ThisClass::SlateHandleOnFocusReceived)
		.OnKeyCharEvent_UObject(this, &ThisClass::SlateHandleOnKeyChar)
		.OnPreviewKeyDownEvent_UObject(this, &ThisClass::SlateHandleOnPreviewKeyDown)
		.OnPreviewMouseButtonDownEvent_UObject(this, &ThisClass::SlateHandleOnPreviewMouseButtonDown)
		.OnMouseWheelEvent_UObject(this, &ThisClass::SlateHandleOnMouseWheel)
		.OnDragDetectedEvent_UObject(this, &ThisClass::SlateHandleOnDragDetected)
		.OnDragEnterEvent_UObject(this, &ThisClass::SlateHandleOnDragEnter)
		.OnDragLeaveEvent_UObject(this, &ThisClass::SlateHandleOnDragLeave)
		.OnDragOverEvent_UObject(this, &ThisClass::SlateHandleOnDragOver)
		.OnDropEvent_UObject(this, &ThisClass::SlateHandleOnDrop)
		.OnTouchGestureEvent_UObject(this, &ThisClass::SlateHandleOnTouchGesture)
		.OnTouchStartedEvent_UObject(this, &ThisClass::SlateHandleOnTouchStarted)
		.OnTouchMovedEvent_UObject(this, &ThisClass::SlateHandleOnTouchMoved)
		.OnTouchEndedEvent_UObject(this, &ThisClass::SlateHandleOnTouchEnded)
		.OnTouchForceChangedEvent_UObject(this, &ThisClass::SlateHandleOnTouchForceChanged)
		.OnTouchFirstMoveEvent_UObject(this, &ThisClass::SlateHandleOnTouchFirstMove)
		.ClickMethod(ClickMethod)
		.TouchMethod(TouchMethod)
		.PressMethod(PressMethod)
		.IsFocusable(IsFocusable)
		;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS

	if (HoverPressAnim.bEnable)
	{
		HoverPressAnimDriver = MakeShareable(new FKGInteractableArea(this, HoverPressAnim));
		HoverPressAnimDriver->OnWidgetRebuild();
	}

	if (WidgetAkEvent.ToSoftObjectPath().IsValid())
	{
		OnClicked.AddDynamic(this, &UKGHotArea::PostWidgetAudio);	
	}
	
	return MyHotArea.ToSharedRef();
}

void UKGHotArea::SynchronizeProperties()
{
	Super::SynchronizeProperties();
}

void UKGHotArea::ReleaseSlateResources(bool bReleaseChildren)
{
	OnClicked.RemoveDynamic(this, &UKGHotArea::PostWidgetAudio);
	if (HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnReleaseSlateResources();
		HoverPressAnimDriver.Reset();
	}
	Super::ReleaseSlateResources(bReleaseChildren);
	if (LongPressTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(LongPressTimerHandle);
	}
	MyHotArea.Reset();
}

void UKGHotArea::PostLoad()
{
	Super::PostLoad();
}

PRAGMA_DISABLE_DEPRECATION_WARNINGS
bool UKGHotArea::GetIsFocusable() const
{
	return IsFocusable;
}
PRAGMA_ENABLE_DEPRECATION_WARNINGS

FReply UKGHotArea::SlateHandleClicked()
{
	if (bPressFlag == EUIPressFlagType::LongPress && OnLongPressed.IsBound())
	{
		bPressFlag = EUIPressFlagType::Unknown;
		return FReply::Handled();
	}
	bPressFlag = EUIPressFlagType::Unknown;
	if (OnMouseButtonDoubleClickEvent.IsBound()) 
	{
		if (waitForClick) 
		{
			OnMouseButtonDoubleClickEvent.Broadcast();
			waitForClick = false;
		}
		else 
		{
			waitForClick = true;
			GetWorld()->GetTimerManager().SetTimer(LongPressTimerHandle, this, &UKGHotArea::TryTriggleClick, DoubleClickSpan, false);
		}
		return FReply::Handled();
	}

	if (clickCd > 0) 
	{
		double cur = FPlatformTime::Seconds();
		if (cur - lastClickTime < clickCd) 
		{
			OnClickedInCD.Broadcast();
			return FReply::Handled();
		}
		lastClickTime = cur;
	}
	OnClicked.Broadcast();
	return FReply::Handled();
}

FReply UKGHotArea::SlateHandleRightClicked()
{
	OnRightClicked.Broadcast();
	return FReply::Handled();
}

void UKGHotArea::SlateHandlePressed()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnPressed();
	}
	bPressFlag = EUIPressFlagType::Press;
	OnPressed.Broadcast();
	if (OnLongPressed.IsBound()) 
	{
		GetWorld()->GetTimerManager().SetTimer(LongPressTimerHandle, this, &UKGHotArea::OnLongPressTimerHandle, LongPressSpan, false);
	}
}

void UKGHotArea::OnLongPressTimerHandle()
{
	if (bPressFlag == EUIPressFlagType::Press)
	{
		bPressFlag = EUIPressFlagType::LongPress;
		OnLongPressed.Broadcast();
	}
}

void UKGHotArea::SetClickCd(float cd)
{
	clickCd = cd;
}

void UKGHotArea::TryTriggleClick()
{
	if (waitForClick) 
	{
		waitForClick = false;
		if (clickCd > 0)
		{
			double cur = FPlatformTime::Seconds();
			if (cur - lastClickTime < clickCd)
			{
				OnClickedInCD.Broadcast();
				return;
			}
			lastClickTime = cur;
		}
		OnClicked.Broadcast();
	}
}

void UKGHotArea::SlateHandleReleased()
{
	if (LongPressTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(LongPressTimerHandle);
	}
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnReleased();
	}
	if (bPressFlag == EUIPressFlagType::LongPress)
	{
		OnLongReleased.Broadcast();
	}
	OnReleased.Broadcast();
}

void UKGHotArea::SlateHandleHovered()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnHovered();
	}
	OnHovered.Broadcast();
}

void UKGHotArea::SlateHandleUnhovered()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnUnhovered();
	}
	OnUnhovered.Broadcast();
}

void UKGHotArea::SlateHandleOnFocusLost(const FFocusEvent& InFocusEvent)
{
	OnFocusLostEvent.ExecuteIfBound(InFocusEvent);
}

FReply UKGHotArea::SlateHandleOnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if(OnKeyDownEvent.IsBound())
	{
		return OnKeyDownEvent.Execute(MyGeometry, InKeyEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (OnKeyUpEvent.IsBound())
	{
		return OnKeyUpEvent.Execute(MyGeometry, InKeyEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	MyHotArea->SetIsDrag(DefaultDragSource != nullptr);
	if (OnMouseButtonDownEvent.IsBound())
	{
		return OnMouseButtonDownEvent.Execute(MyGeometry, MouseEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (OnMouseButtonUpEvent.IsBound())
	{
		return OnMouseButtonUpEvent.Execute(MyGeometry, MouseEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (OnMouseMoveEvent.IsBound())
	{
		return OnMouseMoveEvent.Execute(MyGeometry, MouseEvent).NativeReply;
	}
	return FReply::Unhandled();
}

void UKGHotArea::SlateHandleOnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	OnMouseEnterEvent.ExecuteIfBound(MyGeometry, MouseEvent);
}

void UKGHotArea::SlateHandleOnMouseLeave(const FPointerEvent& MouseEvent)
{
	OnMouseLeaveEvent.ExecuteIfBound(MouseEvent);
}

void UKGHotArea::SlateHandleOnMouseCaptureLost(const FCaptureLostEvent& CaptureLostEvent)
{
	OnMouseCaptureLostEvent.ExecuteIfBound(CaptureLostEvent);
}

FReply UKGHotArea::SlateHandleOnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent)
{
	if (OnFocusReceivedEvent.IsBound())
	{
		return OnFocusReceivedEvent.Execute(MyGeometry, InFocusEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnKeyChar(const FGeometry& MyGeometry, const FCharacterEvent& InCharacterEvent)
{
	if (OnKeyCharEvent.IsBound())
	{
		return OnKeyCharEvent.Execute(MyGeometry, InCharacterEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnPreviewKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (OnKeyDownEvent.IsBound())
	{
		return OnKeyUpEvent.Execute(MyGeometry, InKeyEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (OnPreviewMouseButtonDownEvent.IsBound())
	{
		return OnPreviewMouseButtonDownEvent.Execute(MyGeometry, MouseEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (OnMouseWheelEvent.IsBound())
	{
		return OnMouseWheelEvent.Execute(MyGeometry, MouseEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (OnDragDetectedEvent.IsBound())
	{
		OnDragDetectedEvent.Execute(MyGeometry, MouseEvent);
	}
	if (DefaultDragSource != nullptr)
	{
		if (Operation == nullptr)
		{
			Operation = NewObject<UDragDropOperation>();
		}
		Operation->DefaultDragVisual = DefaultDragSource;
		FVector2D ScreenCursorPos = MouseEvent.GetScreenSpacePosition();
		FVector2D ScreenDrageePosition = MyGeometry.GetAbsolutePosition();

		float DPIScale = UWidgetLayoutLibrary::GetViewportScale(this);
		TSharedRef<FKGDragDropOp> DragDropOp = FKGDragDropOp::New(Operation, MouseEvent.GetPointerIndex(), ScreenCursorPos, ScreenDrageePosition, DPIScale, this);

		return FReply::Handled().BeginDragDrop(DragDropOp);
	}

	return FReply::Unhandled();
}

KGUI_API void UKGHotArea::OnDragCancelled(const FDragDropEvent& DragDropEvent, UDragDropOperation* DropOperation)
{
	if (OnDragCancelEvent.IsBound())
	{
		OnDragCancelEvent.Execute(DragDropEvent, DropOperation);
	}
}

void UKGHotArea::SlateHandleOnDragEnter(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	if (OnDragEnterEvent.IsBound())
	{
		TSharedPtr<FKGDragDropOp> NativeOp = DragDropEvent.GetOperationAs<FKGDragDropOp>();
		if (NativeOp.IsValid())
		{
			OnDragEnterEvent.Execute(MyGeometry, NativeOp->GetOperation());
		}
	}
}

void UKGHotArea::SlateHandleOnDragLeave(const FDragDropEvent& DragDropEvent)
{
	if (OnDragLeaveEvent.IsBound())
	{
		TSharedPtr<FKGDragDropOp> NativeOp = DragDropEvent.GetOperationAs<FKGDragDropOp>();
		if (NativeOp.IsValid())
		{
			OnDragLeaveEvent.Execute(NativeOp->GetOperation());
		}
	}
}

FReply UKGHotArea::SlateHandleOnDragOver(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	if (OnDragOverEvent.IsBound())
	{
		TSharedPtr<FKGDragDropOp> NativeOp = DragDropEvent.GetOperationAs<FKGDragDropOp>();
		if (NativeOp.IsValid())
		{
			return OnDragOverEvent.Execute(MyGeometry, NativeOp->GetOperation()).NativeReply;
		}
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	if (OnDropEvent.IsBound())
	{
		TSharedPtr<FKGDragDropOp> NativeOp = DragDropEvent.GetOperationAs<FKGDragDropOp>();
		if (NativeOp.IsValid())
		{
			return OnDropEvent.Execute(MyGeometry, NativeOp->GetOperation()).NativeReply;
		}
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnTouchGesture(const FGeometry& MyGeometry, const FPointerEvent& GestureEvent)
{
	if (OnTouchGestureEvent.IsBound())
	{
		return OnTouchGestureEvent.Execute(MyGeometry, GestureEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	if (OnTouchStartedEvent.IsBound())
	{
		return OnTouchStartedEvent.Execute(MyGeometry, InTouchEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	if (OnTouchMovedEvent.IsBound())
	{
		return OnTouchMovedEvent.Execute(MyGeometry, InTouchEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	if (OnTouchEndedEvent.IsBound())
	{
		return OnTouchEndedEvent.Execute(MyGeometry, InTouchEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnTouchForceChanged(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent)
{
	if (OnTouchForceChangedEvent.IsBound())
	{
		return OnTouchForceChangedEvent.Execute(MyGeometry, TouchEvent).NativeReply;
	}
	return FReply::Unhandled();
}

FReply UKGHotArea::SlateHandleOnTouchFirstMove(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent)
{
	if(OnTouchFirstMoveEvent.IsBound())
	{
		return OnTouchFirstMoveEvent.Execute(MyGeometry, TouchEvent).NativeReply;
	}
	return FReply::Unhandled();
}

PRAGMA_DISABLE_DEPRECATION_WARNINGS

void UKGHotArea::SetClickMethod(EButtonClickMethod::Type InClickMethod)
{
	ClickMethod = InClickMethod;
	if (MyHotArea.IsValid())
	{
		MyHotArea->SetClickMethod(ClickMethod);
	}
}

EButtonClickMethod::Type UKGHotArea::GetClickMethod() const
{
	return ClickMethod;
}

void UKGHotArea::SetTouchMethod(EButtonTouchMethod::Type InTouchMethod)
{
	TouchMethod = InTouchMethod;
	if (MyHotArea.IsValid())
	{
		MyHotArea->SetTouchMethod(TouchMethod);
	}
}

EButtonTouchMethod::Type UKGHotArea::GetTouchMethod() const
{
	return TouchMethod;
}

void UKGHotArea::SetPressMethod(EButtonPressMethod::Type InPressMethod)
{
	PressMethod = InPressMethod;
	if (MyHotArea.IsValid())
	{
		MyHotArea->SetPressMethod(PressMethod);
	}
}

EButtonPressMethod::Type UKGHotArea::GetPressMethod() const
{
	return PressMethod;
}

void UKGHotArea::SetDragSourceWidget(UKGUserWidget* Source)
{
	DefaultDragSource = Source;
}

void UKGHotArea::PostWidgetAudio()
{
	if (UKGAkAudioManager* AkAudioMgr = UKGAkAudioManager::GetInstance(this))
	{
		if (WidgetAkEvent.ToSoftObjectPath().IsValid())
		{
		    AkAudioMgr->InnerPostEvent3D(WidgetAkEvent.GetAssetName());
		}
	}
}

PRAGMA_ENABLE_DEPRECATION_WARNINGS
