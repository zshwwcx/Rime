#include "UMG/Components/KGMapTagLayer.h"
#include "Manager/KGCppAssetManager.h"
#include "Components/CanvasPanelSlot.h"
#include "3C/Util/KGUtils.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Core/Common.h"
#include "Layout/ArrangedChildren.h"
#include "Materials/MaterialInstance.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UMG/Slate/SKGMapTagLayer.h"
#include "UMG/WidgetComponent/KGMapTagInfoManager.h"

#define LOCTEXT_NAMESPACE "KGUI"

#if WITH_EDITOR
#pragma optimize("", off)
#endif

UE_TRACE_EVENT_BEGIN(Cpu, MapTagLayerUpdateTag, NoSync)
UE_TRACE_EVENT_FIELD(UE::Trace::WideString, TaskID)
UE_TRACE_EVENT_FIELD(UE::Trace::WideString, Asset)
UE_TRACE_EVENT_END()

static bool GKGMapTagLayerPaintOptimize = true;
FAutoConsoleVariableRef CVarC7MapTagLayerPaintOptimize(
	TEXT("KG.MapTagLayerPaintOptimize"),
	GKGMapTagLayerPaintOptimize,
	TEXT("True for optimize C7MapTagLayer paint")
	);


/********************************************************************/
/* UKGMapTagSlot                                                    */
/********************************************************************/
UKGMapTagLayerSlot::UKGMapTagLayerSlot(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Slot(nullptr)
{
PRAGMA_DISABLE_DEPRECATION_WARNINGS
	LayoutData.Offsets = FMargin(0.f, 0.f, 100.f, 30.f);
	LayoutData.Anchors = FAnchors(0.0f, 0.0f);
	LayoutData.Alignment = FVector2D(0.0f, 0.0f);
	bAutoSize = false;
	ZOrder = 0;
PRAGMA_ENABLE_DEPRECATION_WARNINGS
}

void UKGMapTagLayerSlot::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);

	Slot = nullptr;
}

void UKGMapTagLayerSlot::BuildSlot(TSharedRef<SKGMapTagLayer> MapTagLayer)
{
	MapTagLayer->AddSlot()
		.Expose(Slot)
		[
			Content == nullptr ? SNullWidget::NullWidget : Content->TakeWidget()
		];

	SynchronizeProperties();
}

#if WITH_EDITOR

bool UKGMapTagLayerSlot::NudgeByDesigner(const FVector2D& NudgeDirection, const TOptional<int32>& GridSnapSize)
{
	const FVector2D OldPosition = GetPosition();
	FVector2D NewPosition = OldPosition + NudgeDirection;

	// Determine the new position aligned to the grid.
	if (GridSnapSize.IsSet())
	{
		if (!FMath::IsNearlyZero(NudgeDirection.X))
		{
			NewPosition.X = static_cast<int32>(NewPosition.X) - (static_cast<int32>(NewPosition.X) % GridSnapSize.GetValue());
		}
		if (!FMath::IsNearlyZero(NudgeDirection.Y))
		{
			NewPosition.Y = static_cast<int32>(NewPosition.Y) - (static_cast<int32>(NewPosition.Y) % GridSnapSize.GetValue());
		}
	}

	// Offset the size by the same amount moved if we're anchoring along that axis.
	const FVector2D OldSize = GetSize();
	FVector2D NewSize = OldSize;
	if (GetAnchors().IsStretchedHorizontal())
	{
		NewSize.X -= NewPosition.X - OldPosition.X;
	}
	if (GetAnchors().IsStretchedVertical())
	{
		NewSize.Y -= NewPosition.Y - OldPosition.Y;
	}

	// Return false and early out if there are no effective changes.
	if (OldPosition == NewPosition && OldSize == NewSize)
	{
		return false;
	}

	Modify();

	SetPosition(NewPosition);
	SetSize(NewSize);

	return true;
}

bool UKGMapTagLayerSlot::DragDropPreviewByDesigner(const FVector2D& LocalCursorPosition, const TOptional<int32>& XGridSnapSize, const TOptional<int32>& YGridSnapSize)
{
	// If the widget is not constructed yet, we need to call ReleaseSlateResources
	bool bReleaseSlateResources = !Content->IsConstructed();

	// HACK UMG - This seems like a bad idea to call TakeWidget
	TSharedPtr<SWidget> SlateWidget = Content->TakeWidget();
	SlateWidget->SlatePrepass();
	const FVector2D& WidgetDesiredSize = SlateWidget->GetDesiredSize();

	static const FVector2D MinimumDefaultSize(100, 40);
	FVector2D LocalSize = FVector2D(FMath::Max(WidgetDesiredSize.X, MinimumDefaultSize.X), FMath::Max(WidgetDesiredSize.Y, MinimumDefaultSize.Y));

	FVector2D NewPosition = LocalCursorPosition;
	if (XGridSnapSize.IsSet())
	{
		NewPosition.X = static_cast<int32>(NewPosition.X) - (static_cast<int32>(NewPosition.X) % XGridSnapSize.GetValue());
	}
	if (YGridSnapSize.IsSet())
	{
		NewPosition.Y = static_cast<int32>(NewPosition.Y) - (static_cast<int32>(NewPosition.Y) % YGridSnapSize.GetValue());
	}

	bool LayoutChanged = true;
	// Return false and early out if there are no effective changes.
	if (GetSize() == LocalSize && GetPosition() == NewPosition)
	{
		LayoutChanged = false;
	}
	else
	{
		SetPosition(NewPosition);
		SetSize(LocalSize);
	}

	if (bReleaseSlateResources)
	{
		// When we are done, we free the Widget that was created by TakeWidget.
		Content->ReleaseSlateResources(true);
	}

	return LayoutChanged;
}

void UKGMapTagLayerSlot::SynchronizeFromTemplate(const UPanelSlot* const TemplateSlot)
{
	const ThisClass* const TemplateCanvasPanelSlot = CastChecked<ThisClass>(TemplateSlot);
	SetPosition(TemplateCanvasPanelSlot->GetPosition());
	SetSize(TemplateCanvasPanelSlot->GetSize());
}

#endif //WITH_EDITOR

PRAGMA_DISABLE_DEPRECATION_WARNINGS
void UKGMapTagLayerSlot::SetLayout(const FAnchorData& InLayoutData)
{
	LayoutData = InLayoutData;

	if ( Slot )
	{
		Slot->SetOffset(LayoutData.Offsets);
		Slot->SetAnchors(LayoutData.Anchors);
		Slot->SetAlignment(LayoutData.Alignment);
	}
}

FAnchorData UKGMapTagLayerSlot::GetLayout() const
{
	return LayoutData;
}

void UKGMapTagLayerSlot::SetPosition(FVector2D InPosition)
{
	FVector2f Position = UE::Slate::CastToVector2f(InPosition);
	LayoutData.Offsets.Left = Position.X;
	LayoutData.Offsets.Top = Position.Y;

	if ( Slot )
	{
		Slot->SetOffset(LayoutData.Offsets);
	}
}

FVector2D UKGMapTagLayerSlot::GetPosition() const
{
	if ( Slot )
	{
		FMargin Offsets = Slot->GetOffset();
		return {Offsets.Left, Offsets.Top};
	}

	return {LayoutData.Offsets.Left, LayoutData.Offsets.Top};
}

void UKGMapTagLayerSlot::SetSize(FVector2D InSize)
{
	FVector2f Size = UE::Slate::CastToVector2f(InSize);
	LayoutData.Offsets.Right = Size.X;
	LayoutData.Offsets.Bottom = Size.Y;

	if ( Slot )
	{
		Slot->SetOffset(LayoutData.Offsets);
	}
}

FVector2D UKGMapTagLayerSlot::GetSize() const
{
	if ( Slot )
	{
		FMargin Offsets = Slot->GetOffset();
		return {Offsets.Right, Offsets.Bottom};
	}

	return {LayoutData.Offsets.Right, LayoutData.Offsets.Bottom};
}

void UKGMapTagLayerSlot::SetOffsets(FMargin InOffset)
{
	LayoutData.Offsets = InOffset;
	if ( Slot )
	{
		Slot->SetOffset(InOffset);
	}
}

FMargin UKGMapTagLayerSlot::GetOffsets() const
{
	if ( Slot )
	{
		return Slot->GetOffset();
	}

	return LayoutData.Offsets;
}

void UKGMapTagLayerSlot::SetAnchors(const FAnchors& InAnchors)
{
	LayoutData.Anchors = InAnchors;
	if ( Slot )
	{
		Slot->SetAnchors(InAnchors);
	}
}

FAnchors UKGMapTagLayerSlot::GetAnchors() const
{
	if ( Slot )
	{
		return Slot->GetAnchors();
	}

	return LayoutData.Anchors;
}

void UKGMapTagLayerSlot::SetAlignment(FVector2D InAlignment)
{
	LayoutData.Alignment = InAlignment;
	if ( Slot )
	{
		Slot->SetAlignment(InAlignment);
	}
}

FVector2D UKGMapTagLayerSlot::GetAlignment() const
{
	if ( Slot )
	{
		return Slot->GetAlignment();
	}

	return LayoutData.Alignment;
}

void UKGMapTagLayerSlot::SetAutoSize(bool InbAutoSize)
{
	bAutoSize = InbAutoSize;
	if ( Slot )
	{
		Slot->SetAutoSize(InbAutoSize);
	}
}

bool UKGMapTagLayerSlot::GetAutoSize() const
{
	if ( Slot )
	{
		return Slot->GetAutoSize();
	}

	return bAutoSize;
}

void UKGMapTagLayerSlot::SetZOrder(int32 InZOrder)
{
	ZOrder = InZOrder;
	if ( Slot )
	{
		Slot->SetZOrder(static_cast<float>(InZOrder));
	}
}

int32 UKGMapTagLayerSlot::GetZOrder() const
{
	if ( Slot )
	{
		return FMath::TruncToInt32(Slot->GetZOrder());
	}

	return ZOrder;
}

void UKGMapTagLayerSlot::SetMinimum(FVector2D InMinimumAnchors)
{
	LayoutData.Anchors.Minimum = InMinimumAnchors;
	if ( Slot )
	{
		Slot->SetAnchors(LayoutData.Anchors);
	}
}

void UKGMapTagLayerSlot::SetMaximum(FVector2D InMaximumAnchors)
{
	LayoutData.Anchors.Maximum = InMaximumAnchors;
	if ( Slot )
	{
		Slot->SetAnchors(LayoutData.Anchors);
	}
}
PRAGMA_ENABLE_DEPRECATION_WARNINGS

void UKGMapTagLayerSlot::SynchronizeProperties()
{
PRAGMA_DISABLE_DEPRECATION_WARNINGS
	SetOffsets(LayoutData.Offsets);
	SetAnchors(LayoutData.Anchors);
	SetAlignment(LayoutData.Alignment);
	SetAutoSize(bAutoSize);
	SetZOrder(ZOrder);
PRAGMA_ENABLE_DEPRECATION_WARNINGS
}

#if WITH_EDITOR

void UKGMapTagLayerSlot::PreEditChange(FProperty* PropertyThatWillChange)
{
	Super::PreEditChange(PropertyThatWillChange);

	SaveBaseLayout();
}

void UKGMapTagLayerSlot::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{
	SynchronizeProperties();

	static FName AnchorsProperty(TEXT("Anchors"));

	if (FEditPropertyChain::TDoubleLinkedListNode* AnchorNode = PropertyChangedEvent.PropertyChain.GetHead()->GetNextNode())
	{
		if (FEditPropertyChain::TDoubleLinkedListNode* LayoutDataNode = AnchorNode->GetNextNode())
		{
			FProperty* AnchorProperty = LayoutDataNode->GetValue();
			if (AnchorProperty && AnchorProperty->GetFName() == AnchorsProperty)
			{
				RebaseLayout();
			}
		}
	}

	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

void UKGMapTagLayerSlot::SaveBaseLayout()
{
	// Get the current location
	if ( UKGMapTagLayer* Canvas = Cast<UKGMapTagLayer>(Parent) )
	{
		FGeometry Geometry;
		if ( Canvas->GetGeometryForSlot(this, Geometry) )
		{
			PreEditGeometry = Geometry;
			PreEditLayoutData = GetLayout();
		}
	}
}

void UKGMapTagLayerSlot::SetDesiredPosition(FVector2D InPosition)
{
	DesiredPosition = InPosition;
}

void UKGMapTagLayerSlot::RebaseLayout(bool PreserveSize)
{
	// Ensure we have a parent canvas
	if ( UKGMapTagLayer* MatTagLayer = Cast<UKGMapTagLayer>(Parent) )
	{
		FGeometry Geometry;
		if ( MatTagLayer->GetGeometryForSlot(this, Geometry) )
		{
			// Calculate the default anchor offset, ie where would this control be laid out if no offset were provided.
			FVector2D CanvasSize = MatTagLayer->GetMapTagLayerWidget()->GetCachedGeometry().Size;
			FAnchorData LocalLayoutData = GetLayout();
			FMargin AnchorPositions = FMargin(
				LocalLayoutData.Anchors.Minimum.X * CanvasSize.X,
				LocalLayoutData.Anchors.Minimum.Y * CanvasSize.Y,
				LocalLayoutData.Anchors.Maximum.X * CanvasSize.X,
				LocalLayoutData.Anchors.Maximum.Y * CanvasSize.Y);
			FVector2f DefaultAnchorPosition = FVector2f(AnchorPositions.Left, AnchorPositions.Top);

			// Determine the amount that would be offset from the anchor position if alignment was applied.
			FVector2f AlignmentOffset = UE::Slate::CastToVector2f(LocalLayoutData.Alignment) * PreEditGeometry.Size;

			// FVector2f MoveDelta = Geometry.Position - PreEditGeometry.Position;

			// Determine where the widget's new position needs to be to maintain a stable location when the anchors change.
			FVector2f LeftTopDelta = PreEditGeometry.Position - DefaultAnchorPosition;

			const bool bAnchorsMoved = PreEditLayoutData.Anchors.Minimum != LocalLayoutData.Anchors.Minimum || PreEditLayoutData.Anchors.Maximum != LocalLayoutData.Anchors.Maximum;
			const bool bMoved = !FMath::IsNearlyEqual(PreEditLayoutData.Offsets.Left, LocalLayoutData.Offsets.Left) || !FMath::IsNearlyEqual(PreEditLayoutData.Offsets.Top, LocalLayoutData.Offsets.Top);

			if ( bAnchorsMoved )
			{
				// Adjust the size to remain constant
				if ( !LocalLayoutData.Anchors.IsStretchedHorizontal() && PreEditLayoutData.Anchors.IsStretchedHorizontal() )
				{
					// Adjust the position to remain constant
					LocalLayoutData.Offsets.Left = LeftTopDelta.X + AlignmentOffset.X;
					LocalLayoutData.Offsets.Right = PreEditGeometry.Size.X;
				}
				else if ( !PreserveSize && LocalLayoutData.Anchors.IsStretchedHorizontal() && !PreEditLayoutData.Anchors.IsStretchedHorizontal() )
				{
					// Adjust the position to remain constant
					LocalLayoutData.Offsets.Left = 0;
					LocalLayoutData.Offsets.Right = 0;
				}
				else if ( LocalLayoutData.Anchors.IsStretchedHorizontal() )
				{
					// Adjust the position to remain constant
					LocalLayoutData.Offsets.Left = LeftTopDelta.X;
					LocalLayoutData.Offsets.Right = AnchorPositions.Right - ( AnchorPositions.Left + LocalLayoutData.Offsets.Left + PreEditGeometry.Size.X );
				}
				else
				{
					// Adjust the position to remain constant
					LocalLayoutData.Offsets.Left = LeftTopDelta.X + AlignmentOffset.X;
				}

				if ( !LocalLayoutData.Anchors.IsStretchedVertical() && PreEditLayoutData.Anchors.IsStretchedVertical() )
				{
					// Adjust the position to remain constant
					LocalLayoutData.Offsets.Top = LeftTopDelta.Y + AlignmentOffset.Y;
					LocalLayoutData.Offsets.Bottom = PreEditGeometry.Size.Y;
				}
				else if ( !PreserveSize && LocalLayoutData.Anchors.IsStretchedVertical() && !PreEditLayoutData.Anchors.IsStretchedVertical() )
				{
					// Adjust the position to remain constant
					LocalLayoutData.Offsets.Top = 0;
					LocalLayoutData.Offsets.Bottom = 0;
				}
				else if ( LocalLayoutData.Anchors.IsStretchedVertical() )
				{
					// Adjust the position to remain constant
					LocalLayoutData.Offsets.Top = LeftTopDelta.Y;
					LocalLayoutData.Offsets.Bottom = AnchorPositions.Bottom - ( AnchorPositions.Top + LocalLayoutData.Offsets.Top + PreEditGeometry.Size.Y );
				}
				else
				{
					// Adjust the position to remain constant
					LocalLayoutData.Offsets.Top = LeftTopDelta.Y + AlignmentOffset.Y;
				}
			}
			else if ( DesiredPosition.IsSet() )
			{
				FVector2f NewLocalPosition = UE::Slate::CastToVector2f(DesiredPosition.GetValue());

				LocalLayoutData.Offsets.Left = NewLocalPosition.X - AnchorPositions.Left;
				LocalLayoutData.Offsets.Top = NewLocalPosition.Y - AnchorPositions.Top;

				if ( LocalLayoutData.Anchors.IsStretchedHorizontal() )
				{
					LocalLayoutData.Offsets.Right -= LocalLayoutData.Offsets.Left - PreEditLayoutData.Offsets.Left;
				}
				else
				{
					LocalLayoutData.Offsets.Left += AlignmentOffset.X;
				}

				if ( LocalLayoutData.Anchors.IsStretchedVertical() )
				{
					LocalLayoutData.Offsets.Bottom -= LocalLayoutData.Offsets.Top - PreEditLayoutData.Offsets.Top;
				}
				else
				{
					LocalLayoutData.Offsets.Top += AlignmentOffset.Y;
				}

				DesiredPosition.Reset();
			}
			else if ( bMoved )
			{
				LocalLayoutData.Offsets.Left -= DefaultAnchorPosition.X;
				LocalLayoutData.Offsets.Top -= DefaultAnchorPosition.Y;

				// If the slot is stretched horizontally we need to move the right side as it no longer represents width, but
				// now represents margin from the right stretched side.
				if ( LocalLayoutData.Anchors.IsStretchedHorizontal() )
				{
					//LocalLayoutData.Offsets.Right = PreEditLayoutData.Offsets.Top;
				}
				else
				{
					LocalLayoutData.Offsets.Left += AlignmentOffset.X;
				}

				// If the slot is stretched vertically we need to move the bottom side as it no longer represents width, but
				// now represents margin from the bottom stretched side.
				if ( LocalLayoutData.Anchors.IsStretchedVertical() )
				{
					//LocalLayoutData.Offsets.Bottom -= MoveDelta.Y;
				}
				else
				{
					LocalLayoutData.Offsets.Top += AlignmentOffset.Y;
				}
			}
			SetLayout(LocalLayoutData);
		}

		// Apply the changes to the properties.
		SynchronizeProperties();
	}
}

#endif

/*
 * UKGMapTagLayer
 */
UKGMapTagLayer::UKGMapTagLayer(const FObjectInitializer& Initializer)
    : Super(Initializer)
    , CameraLocation()
    , CameraRotation()
    , CameraViewportSize()
    , CurrentCenterLocation()
    , ConstraintRadius(0)
    , TagUniformScale(1)
    , EntryWidgetPool(*this)
    , MapTagInfoManager(nullptr)
{
}

void UKGMapTagLayer::Tick(float DeltaTime)
{
    SCOPED_NAMED_EVENT(UKGMapTagLayer_Tick, FColor::Silver)
    if (MapTagInfoManager)
    {
        MapTagInfoManager->SetMapEdgeType(PanelMapEdgeType);
        MapTagInfoManager->SetCenterActor(CenterActorID);
        MapTagInfoManager->SetMode(Mode);
        MapTagInfoManager->UpdateCameraParams(CameraLocation, CameraRotation, CameraViewportSize, ViewportScale);
        MapTagInfoManager->SetFilterStrategyEnabled(bMiniMap);
        MapTagInfoManager->SetConstraintRadius(ConstraintRadius);
        MapTagInfoManager->SetConstraintRect(ConstraintRectangle);
        MapTagInfoManager->Tick(DeltaTime);

        for (const auto& TaskId : MapTagInfoManager->GetPendingRemoveList())
        {
            RemoveTagUI(TaskId);
        }
        
        for (const auto& Tag : MapTagInfoManager->GetPendingUpdateList())
        {
            UpdateTagUI(Tag);
        }
        
        for (const auto& Tag : MapTagInfoManager->GetPendingInstanceList())
        {
            InstanceTagUI(Tag);
        }
        
        if (MyMapTagLayer.IsValid())
        {
            MyMapTagLayer->MarkTagIconsDirty();
        }
    }
}

void UKGMapTagLayer::SetViewportScale(float InViewportScale)
{
    if (!FMath::IsNearlyZero(InViewportScale - ViewportScale))
    {
        bViewportStatChanged = true;
    }
    ViewportScale = InViewportScale;
}

void UKGMapTagLayer::SetCurrentCenterLocation(const FVector2D& InCurrentCenterLocation)
{
    if (!(CurrentCenterLocation - InCurrentCenterLocation).IsNearlyZero())
    {
        bViewportStatChanged = true;
    }
    
    CurrentCenterLocation = InCurrentCenterLocation;
}

EMapDisplayState UKGMapTagLayer::GetNewMapDisplayState(const FMapTagInfo& InMapTagInfoData)
{
    if (ViewportScale > InMapTagInfoData.ShowRatioInterval.Y || ViewportScale < InMapTagInfoData.ShowRatioInterval.X)
    {
        return EMapDisplayState::None;
    }
    
    if (InMapTagInfoData.bIgnoreConstraint)
    {
        return EMapDisplayState::Center;
    }
    
    FVector2D WidgetOffset = GetWidgetOffsetByMapTagInfo(InMapTagInfoData);
    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle && InRectangle(WidgetOffset) && InMapTagInfoData.MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        return EMapDisplayState::Center;
    }
    
    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle && !InRectangle(WidgetOffset) && InMapTagInfoData.MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        return EMapDisplayState::Edge;
    }
    
    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByCircle && InCircle(WidgetOffset) && InMapTagInfoData.MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        return EMapDisplayState::Center;
    }
    
    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByCircle && !InCircle(WidgetOffset) && InMapTagInfoData.MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        return EMapDisplayState::Edge;
    }
    
    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByCircle && InCircle(WidgetOffset) && InMapTagInfoData.MapEdgeType == EMapEdgeType::None)
    {
        return EMapDisplayState::Center;
    }
    
    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle && InRectangle(WidgetOffset) && InMapTagInfoData.MapEdgeType == EMapEdgeType::None)
    {
        return EMapDisplayState::Center;
    }
    
    return EMapDisplayState::None;
}

void UKGMapTagLayer::OnMapTagClassLoaded(int InLoadID, UObject* Asset)
{
    if (auto* Handle = AssetsInLoading.Find(InLoadID))
    {
        ensureMsgf(Asset, TEXT("Load map tag class faield, please check map tag class path: %s"), *Handle->Path);
        if (MapTagInfoManager && Asset)
        {
            for (const auto& TaskID : Handle->TaskIDs)
            {
                if (auto* Entry = TagWidgets.Find(TaskID))
                {
                    if (auto TagInfo = MapTagInfoManager->GetMapTagInfo(TaskID))
                    {
                        InstanceTagUIInternal(*Entry, Cast<UClass>(Asset), TagInfo->Offset, TagInfo->ZOrder);
                    }
                }
            }
        }

        UE_LOG(LogKGUI, Log, TEXT("[UKGMapTagLayer]OnMapTagClassLoaded assets:%s LoadId:%d"), *Handle->Path, InLoadID);
        AssetsInLoading.Remove(InLoadID);
    }
}

void UKGMapTagLayer::OnTagIconLoaded(int32 InLoadID, UObject* InAsset)
{
    if (auto* Handle = AssetsInLoading.Find(InLoadID))
    {
        for (const auto& TaskID : Handle->TaskIDs)
        {
            auto* Entry = TagWidgets.Find(TaskID);
            if (Entry && Entry->SimpleTagIconHandle != INDEX_NONE)
            {
                if (auto* SimpleTagIcon = SimpleTagIcons.Find(Entry->SimpleTagIconHandle))
                {
                	if (InAsset->IsA<UMaterialInterface>())
                	{
                		SimpleTagIcon->DynamicInstance = UMaterialInstanceDynamic::Create(Cast<UMaterialInterface>(InAsset), this);
                		SimpleTagIcon->Brush.SetResourceObject(SimpleTagIcon->DynamicInstance);
                	}
	                else
	                {
						SimpleTagIcon->Brush.SetResourceObject(InAsset);
	                }
                	
                    if (MyMapTagLayer.IsValid())
                    {
                        MyMapTagLayer->AddTagIcon(*SimpleTagIcon);
                    }
                }
                
            }
        }

        UE_LOG(LogKGUI, Log, TEXT("[UKGMapTagLayer]OnTagIconLoaded assets:%s LoadId:%d"), *Handle->Path, InLoadID);
        AssetsInLoading.Remove(InLoadID);
    }
}

UObject* UKGMapTagLayer::AsyncLoadUserWidgetClass(const FString& InPath, const FString& InTaskID)
{
    for (auto& Pair : AssetsInLoading)
    {
        if (Pair.Value.Path == InPath)
        {
            Pair.Value.TaskIDs.AddUnique(InTaskID);
            return nullptr;
        }
    }

    if (auto* AssetMgr = UKGCppAssetManager::GetInstance(GetWorld()))
    {
        UObject* Asset = nullptr;
        int32 LoadID = AssetMgr->AsyncLoadAsset(InPath, Asset, FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGMapTagLayer::OnMapTagClassLoaded), static_cast<int32>(EAssetLoadPriority::UI));
        if (Asset)
        {
            return Asset;
        }

        UE_LOG(LogTemp, Log, TEXT("[UKGMapTagLayer]Async load userwidget class assets:%s LoadId:%d"), *InPath, LoadID);
        auto& Handle = AssetsInLoading.FindOrAdd(LoadID);
        Handle.Path = InPath;
        Handle.TaskIDs.AddUnique(InTaskID);
    }

    return nullptr;
}

UObject* UKGMapTagLayer::AsyncLoadIcon(const FString& InTagIconPath, const FString& InTaskID)
{
    for (auto& Pair : AssetsInLoading)
    {
        if (Pair.Value.Path == InTagIconPath)
        {
            Pair.Value.TaskIDs.AddUnique(InTaskID);
            return nullptr;
        }
    }

    if (auto* AssetMgr = UKGCppAssetManager::GetInstance(GetWorld()))
    {
        UObject* Asset = nullptr;
        int32 LoadID = AssetMgr->AsyncLoadAsset(InTagIconPath, Asset, FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGMapTagLayer::OnTagIconLoaded), static_cast<int32>(EAssetLoadPriority::UI));
        if (Asset)
        {
            return Asset;
        }

        UE_LOG(LogTemp, Log, TEXT("[UKGMapTagLayer]Async load icon assets:%s LoadId:%d"), *InTagIconPath, LoadID);
        auto& Handle = AssetsInLoading.FindOrAdd(LoadID);
        Handle.Path = InTagIconPath;
        Handle.TaskIDs.AddUnique(InTaskID);
    }

    return nullptr;
}

void UKGMapTagLayer::UpdateTagUI(const FMapTagInfoPtr& InTag)
{
    if (!InTag.IsValid())
    {
        return;
    }
    
    if (!TagWidgets.Contains(InTag->TaskID))
    {
        InstanceTagUI(InTag);
        return;
    }

    SCOPED_NAMED_EVENT(UKGMapTagLayer_UpdateTagUI, FColor::Cyan)
    auto& Entry = TagWidgets[InTag->TaskID];
    Entry.Offset = InTag->Offset;
    if (Entry.SimpleTagIconHandle != INDEX_NONE)
    {
        if (auto* SimpleTagIcon = SimpleTagIcons.Find(Entry.SimpleTagIconHandle))
        {
            UpdateSimpleTagIcon(SimpleTagIcon, InTag.Get());
        }
        return;
    }
        
    if (Entry.UserWidget && IsValid(Entry.UserWidget))
    {
        if (TObjectPtr<UKGMapTagLayerSlot> CanvasPanelSlot = Cast<UKGMapTagLayerSlot>(Entry.UserWidget->Slot))
        {
            CanvasPanelSlot->SetAnchors(FAnchors(InTag->Offset.X, InTag->Offset.Y));
            CanvasPanelSlot->SetAlignment(FVector2D(0.5f, 0.5f));
            CanvasPanelSlot->SetAutoSize(true);
            CanvasPanelSlot->SetZOrder(InTag->ZOrder);
        }
    }
}

void UKGMapTagLayer::RemoveTagUI(const FString& TaskID)
{
    if (TagWidgets.Contains(TaskID))
    {
        RemoveTagUIInternal(TaskID);
        TagWidgets.Remove(TaskID);
    }    
}

int32 UKGMapTagLayer::AddSimpleTagIcon(const FString& TaskID, const FMapTagInfoPtr& TagInfo)
{
    ensure(TagInfo.IsValid());
    
    static int32 SimpleTagIconCounter = 0;
    ++SimpleTagIconCounter;

    auto& SimpleTagIcon = SimpleTagIcons.Add(SimpleTagIconCounter);
    SimpleTagIcon.SimpleTagIconHandle = SimpleTagIconCounter;
    SimpleTagIcon.TaskID = TaskID;
    SimpleTagIcon.Offset = TagInfo->Offset;
    SimpleTagIcon.Size.X = TagInfo->IconSizeX;
    SimpleTagIcon.Size.Y = TagInfo->IconSizeY;
    SimpleTagIcon.IconPath = TagInfo->TagIcon;
    SimpleTagIcon.Brush.SetResourceObject(AsyncLoadIcon(TagInfo->TagIcon, TaskID));
    SimpleTagIcon.Brush.SetImageSize(SimpleTagIcon.Size);
    SimpleTagIcon.Brush.DrawAs = ESlateBrushDrawType::Image;
    SimpleTagIcon.ZOrder = TagInfo->ZOrder;
    SimpleTagIcon.RotateAngle = TagInfo->RotateAngle;
    SimpleTagIcon.TintColor = TagInfo->TintColor;

    if (SimpleTagIcon.Brush.GetResourceObject() != nullptr)
    {
        if (MyMapTagLayer.IsValid())
        {
            MyMapTagLayer->AddTagIcon(SimpleTagIcon);
        }
    }
    
    return SimpleTagIconCounter;
}

void UKGMapTagLayer::RemoveSimpleTagIcon(int32 InSimpleTagIconHandle)
{
    if (SimpleTagIcons.Contains(InSimpleTagIconHandle))
    {
        if (MyMapTagLayer.IsValid())
        {
            MyMapTagLayer->RemoveTagIcon(InSimpleTagIconHandle);
        }
        
        SimpleTagIcons.Remove(InSimpleTagIconHandle);
    }
}

void UKGMapTagLayer::RemoveSimpleTagIcon(const FString& TaskID)
{
    if (auto* Entry = TagWidgets.Find(TaskID))
    {
        RemoveSimpleTagIcon(Entry->SimpleTagIconHandle);
    }
}

void UKGMapTagLayer::UpdateSimpleTagIcon(FKGMapSimpleTagIcon* TagIcon, const FMapTagInfo* TagInfo)
{
    SCOPED_NAMED_EVENT(UKGMapTagLayer_UpdateSimpleTagIcon, FColor::Blue)
    if (TagIcon && TagInfo)
    {
        TagIcon->Size.X = TagInfo->IconSizeX;
        TagIcon->Size.Y = TagInfo->IconSizeY;
        TagIcon->Offset = TagInfo->Offset;
        TagIcon->Brush.SetImageSize(TagIcon->Size);
    	TagIcon->bVisible = TagInfo->bVisible;
        TagIcon->RotateAngle = TagInfo->RotateAngle;
        bool bNeedUpdate = true;
        if (TagIcon->IconPath != TagInfo->TagIcon)
        {
            TagIcon->IconPath = TagInfo->TagIcon;
            
            UObject* BrushAsset = AsyncLoadIcon(TagInfo->TagIcon, TagInfo->TaskID);
            TagIcon->Brush.SetResourceObject(BrushAsset);
            if (BrushAsset == nullptr && MyMapTagLayer.IsValid())
            {
                MyMapTagLayer->RemoveTagIcon(TagIcon->SimpleTagIconHandle);
                bNeedUpdate = false;
            }
        }

        if (bNeedUpdate && MyMapTagLayer.IsValid())
        {
            MyMapTagLayer->AddTagIcon(*TagIcon);
        }
    }
}

void UKGMapTagLayer::InstanceTagUI(const FMapTagInfoPtr& InTag)
{
    if (!InTag.IsValid())
    {
        return;
    }
    
    if (TagWidgets.Contains(InTag->TaskID))
    {
        UpdateTagUI(InTag);
        return;
    }

    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer]InstanceTagUI %s"), *InTag->TaskID)
    SCOPED_NAMED_EVENT(UKGMapTagLayer_InstanceTagUI, FColor::Green)

    auto& Entry = TagWidgets.Add(InTag->TaskID);
    Entry.TaskID = InTag->TaskID;
    Entry.TypeID = InTag->TypeID;
    Entry.TemplateWidgetType = InTag->TemplateWidgetType;
    Entry.Offset = InTag->Offset;

    if (InTag->bSimpleTagIcon)
    {
        Entry.SimpleTagIconHandle = AddSimpleTagIcon(InTag->TaskID, InTag);
        return;
    }

    if (auto* Class = AsyncLoadUserWidgetClass(InTag->TemplateWidgetType, InTag->TaskID))
    {
        InstanceTagUIInternal(Entry, Cast<UClass>(Class), InTag->Offset, InTag->ZOrder);
    }
}

void UKGMapTagLayer::InstanceTagUIInternal(FKGMapTagWidgetEntry& Entry, TSubclassOf<UUserWidget> WidgetTemplate, const FVector2D& Offset, int32 InZOrder)
{
    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer]InstanceTagUIInternal %s[%d]"), *Entry.TaskID, Entry.TypeID);
    Entry.UserWidget = GetWidgetFromPool(Cast<UClass>(WidgetTemplate));
    if (Entry.UserWidget == nullptr)
    {
        UE_LOG(LogKGUI, Error, TEXT("[UKGMapTagLayer]InstanceTagUIInternal failed: has no user widget, taskID:%s, user widget class:%s"),
            *Entry.TaskID, WidgetTemplate.Get() ? *WidgetTemplate.Get()->GetName() : TEXT("nullptr"))
        return;
    }
    AddChild(Entry.UserWidget);
        
#if WITH_EDITOR
    auto Widget = Entry.UserWidget->TakeWidget();
    if (auto ReflectionData = Widget->GetMetaData<FReflectionMetaData>())
    {
        ReflectionData->Name = *FString::Printf(TEXT("%s[%s]"), *Entry.UserWidget->GetName(), *Entry.TaskID);
    }
#endif
    	
    OnMapTagInitializedDynamic.Broadcast(Entry.UserWidget, Entry.TypeID, Entry.TaskID, false);
        
    if (TObjectPtr<UKGMapTagLayerSlot> CanvasPanelSlot = Cast<UKGMapTagLayerSlot>(Entry.UserWidget->Slot))
    {
        CanvasPanelSlot->SetAnchors(FAnchors(static_cast<float>(Offset.X), static_cast<float>(Offset.Y)));
        CanvasPanelSlot->SetAlignment(FVector2D(0.5f, 0.5f));
        CanvasPanelSlot->SetAutoSize(true);
        CanvasPanelSlot->SetZOrder(InZOrder);
    }
}

void UKGMapTagLayer::RemoveTagUIInternal(const FString& TaskID)
{
    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer]RemoveTagUIInternal %s"), *TaskID)
    SCOPED_NAMED_EVENT(UKGMapTagLayer_RemoveTagUIInternal, FColor::Red)
    auto& Entry = TagWidgets[TaskID];
    if (Entry.SimpleTagIconHandle != INDEX_NONE)
    {
        RemoveSimpleTagIcon(Entry.SimpleTagIconHandle);
    }
    else
    {
        OnMapTagRemovedDynamic.Broadcast(Entry.UserWidget, Entry.TypeID, Entry.TaskID);
        RemoveChild(Entry.UserWidget);
        ReturnWidgetToPool(Entry.UserWidget);
    }
}

void UKGMapTagLayer::SetMode(EMapTagLayerMode InMode)
{
    Mode = InMode;
    if (MapTagInfoManager)
    {
        MapTagInfoManager->SetMode(InMode);
    }
}

void UKGMapTagLayer::SetCenterActor(int64 InCenterActorID)
{
    CenterActorID = InCenterActorID;
    if (MapTagInfoManager)
    {
        MapTagInfoManager->SetCenterActor(CenterActorID);
    }
}

void UKGMapTagLayer::ResetCenterActor()
{
    CenterActorID = 0;
    if (MapTagInfoManager)
    {
        MapTagInfoManager->ResetCenterActor();
    }
}

void UKGMapTagLayer::RegisterWidgetRotateInEdge(const FString& TaskID, UWidget* Widget, float Offset) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->RegisterWidgetRotateInEdge(TaskID, Widget, Offset);
    }
}

void UKGMapTagLayer::UnRegisterWidgetRotateInEdge(const FString& TaskID) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->UnRegisterWidgetRotateInEdge(TaskID);
    }
}

TObjectPtr<UUserWidget> UKGMapTagLayer::GetWidgetFromPool(TSubclassOf<UUserWidget> InWidgetType)
{
    return EntryWidgetPool.GetOrCreateInstance(InWidgetType);
}

void UKGMapTagLayer::ReturnWidgetToPool(TObjectPtr<UUserWidget> InUserWidget)
{
    EntryWidgetPool.Release(InUserWidget, true);
}


FVector2D UKGMapTagLayer::GetWidgetOffsetByMapTagInfo(const FMapTagInfo& MapTagInfo)
{
    FVector WorldLocation(.0f, .0f, .0f);
    AActor* Follower = KGUtils::GetActorByID(MapTagInfo.FollowerID);
    if (MapTagInfo.MapTagType == EMapTagType::Static)
    {
        WorldLocation = MapTagInfo.StaticLocation;
    }
    else if (IsValid(Follower))
    {
        WorldLocation = Follower->K2_GetActorLocation();
    }

	if (!bSameWithMapTexture)
	{
		//相机以Z轴负方向为Up，Y轴正方向为Right
		FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
		//FVector Forward = CameraRotation.RotateVector(FVector(1,0,0));
		FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
		FVector WorldVec = WorldLocation - CameraLocation;
		FVector2D ProjectedLoc = FVector2d(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;
		FVector2D Offset = ProjectedLoc - CurrentCenterLocation;
		Offset.X *=  static_cast<double>(MapTextureWidth) / ViewportScale / CameraViewportSize.X ;
		Offset.Y *=  static_cast<double>(MapTextureHeight) / ViewportScale / CameraViewportSize.Y ;

		FVector2D Size = GetCachedGeometry().GetLocalSize();
		if (Size.IsNearlyZero())
		{
			Size = UWidgetLayoutLibrary::GetViewportWidgetGeometry(GetWorld()).GetLocalSize();
			bNeedUpdateTagAfterWidgetRendered = true;
		}
		Offset += Size * 0.5f;
		Offset /= Size;
		return Offset;
	}
	
    //相机以Z轴负方向为Up，Y轴正方向为Right
    FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
    //FVector Forward = CameraRotation.RotateVector(FVector(1,0,0));
    FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
    FVector WorldVec = WorldLocation - CameraLocation;
    FVector2d ProjectedLoc = FVector2d(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;

    FVector2D ViewportRectangleLeftUp = CurrentCenterLocation - CameraViewportSize * ViewportScale * 0.5f;
    //FVector2D ViewportRectangleRightDown = CurrentCenterLocation + CameraViewportSize * ViewportScale;

    FVector2D ViewportPosition = ProjectedLoc - ViewportRectangleLeftUp;
    FVector2D res = FVector2D(ViewportPosition.X / CameraViewportSize.X / ViewportScale, ViewportPosition.Y / CameraViewportSize.Y / ViewportScale);
    
    return res;
}

FVector2D UKGMapTagLayer::GetWidgetPosByMapTagInfo(const FMapTagInfo& MapTagInfo) const
{
    FVector WorldLocation(.0f, .0f, .0f);
    AActor* Follower = KGUtils::GetActorByID(MapTagInfo.FollowerID);
    if (MapTagInfo.MapTagType == EMapTagType::Static)
    {
        WorldLocation = MapTagInfo.StaticLocation;
    }
    else if (IsValid(Follower))
    {
        WorldLocation = Follower->K2_GetActorLocation();
    }
    return GetWorldOffsetByWorldLocation(WorldLocation);
}

FVector2D UKGMapTagLayer::GetWorldOffsetByWorldLocation(const FVector& Location) const
{
    //相机以Z轴负方向为Up，Y轴正方向为Right
    FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
    //FVector Forward = CameraRotation.RotateVector(FVector(-1,0,0));右手坐标系
    FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
    FVector WorldVec = Location - CameraLocation;
    FVector2D ProjectedLoc = FVector2d(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;
    return ProjectedLoc;
}

FVector2D UKGMapTagLayer::DeprojectWidgetOffsetToWorldLocation(FVector2D WidgetOffset) const
{
    WidgetOffset = WidgetOffset * CameraViewportSize * ViewportScale;
    WidgetOffset += CurrentCenterLocation - CameraViewportSize * ViewportScale * 0.5f;
    FVector2D WorldOffset = WidgetOffset - CameraViewportSize * 0.5f;

    FVector4 LHS(WorldOffset.X, WorldOffset.Y, .0f, .0f);
    FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
    FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
    FVector Forward = CameraRotation.RotateVector(FVector(-1, 0, 0));
    FMatrix Mat;
    Mat.SetIdentity();
    Mat.SetColumn(0, Right);
    Mat.SetColumn(1, Up);
    Mat.SetColumn(2, Forward);
    FVector4 RHS = Mat.GetTransposed().TransformFVector4(LHS); //正交矩阵，转置就是逆
    FVector RHS3(RHS.X, RHS.Y, RHS.Z);
    RHS3 += CameraLocation;

    return FVector2D(RHS3.X, RHS3.Y);
}

FVector2D UKGMapTagLayer::GetWidgetOffsetByWorldLocation(const FVector& InLocation)
{	
	if (!bSameWithMapTexture)
	{
		//相机以Z轴负方向为Up，Y轴正方向为Right
		FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
		//FVector Forward = CameraRotation.RotateVector(FVector(1,0,0));
		FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
		FVector WorldVec = InLocation - CameraLocation;
		FVector2D ProjectedLoc = FVector2d(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;
		FVector2D Offset = ProjectedLoc - CurrentCenterLocation;
		Offset.X *=  static_cast<double>(MapTextureWidth) / ViewportScale / CameraViewportSize.X ;
		Offset.Y *=  static_cast<double>(MapTextureHeight) / ViewportScale / CameraViewportSize.Y ;

		FVector2D Size = GetCachedGeometry().GetLocalSize();
		if (Size.IsNearlyZero())
		{
			Size = UWidgetLayoutLibrary::GetViewportWidgetGeometry(GetWorld()).GetLocalSize();
			bNeedUpdateTagAfterWidgetRendered = true;
		}
		Offset += Size * 0.5f;
		Offset /= Size;
		return Offset;
	}
	
    //相机以Z轴负方向为Up，Y轴正方向为Right
    FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
    //FVector Forward = CameraRotation.RotateVector(FVector(1,0,0));
    FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
    FVector WorldVec = InLocation - CameraLocation;
    FVector2d ProjectedLoc = FVector2d(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;

    FVector2D ViewportRectangleLeftUp = CurrentCenterLocation - CameraViewportSize * ViewportScale * 0.5f;
    //FVector2D ViewportRectangleRightDown = CurrentCenterLocation + CameraViewportSize * ViewportScale;

    FVector2D ViewportPosition = ProjectedLoc - ViewportRectangleLeftUp;
    FVector2D res = FVector2D(ViewportPosition.X / CameraViewportSize.X / ViewportScale, ViewportPosition.Y / CameraViewportSize.Y / ViewportScale);
	
    return res;
}

FVector2D UKGMapTagLayer::GetWidgetOffsetByCenterAndWorldLocation(const FVector& Location)
{
	if (!bSameWithMapTexture)
	{
		//相机以Z轴负方向为Up，Y轴正方向为Right
		FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
		//FVector Forward = CameraRotation.RotateVector(FVector(1,0,0));
		FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
		FVector WorldVec = Location - CameraLocation;
		FVector2D ProjectedLoc = FVector2d(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;
		FVector2D Offset = ProjectedLoc - CurrentCenterLocation;
		Offset.X *=  static_cast<double>(MapTextureWidth) / ViewportScale / CameraViewportSize.X ;
		Offset.Y *=  static_cast<double>(MapTextureHeight) / ViewportScale / CameraViewportSize.Y ;

		FVector2D Size = GetCachedGeometry().GetLocalSize();
		if (Size.IsNearlyZero())
		{
			Size = UWidgetLayoutLibrary::GetViewportWidgetGeometry(GetWorld()).GetLocalSize();
			bNeedUpdateTagAfterWidgetRendered = true;
		}
		Offset += Size * 0.5f;
		Offset /= Size;
		return Offset;
	}
	
    //相机以Z轴负方向为Up，Y轴正方向为Right
    FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
    //FVector Forward = CameraRotation.RotateVector(FVector(1,0,0));
    FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
    FVector WorldVec = Location - CameraLocation;
    FVector2d ProjectedLoc = FVector2d(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;

    //FVector2D _CurrentCenterLocation = CameraViewportSize * ViewportScale * 0.5f;
    FVector2D ViewportRectangleLeftUp(.5f, .5f); // = _CurrentCenterLocation - CameraViewportSize * ViewportScale * 0.5f;
    //FVector2D ViewportRectangleRightDown = CurrentCenterLocation + CameraViewportSize * ViewportScale;

    FVector2D ViewportPosition = ProjectedLoc - ViewportRectangleLeftUp;
    FVector2D res = FVector2D(ViewportPosition.X / CameraViewportSize.X/* / ViewportScale*/, ViewportPosition.Y / CameraViewportSize.Y/* / ViewportScale*/);

    return res;
}

void UKGMapTagLayer::GetWidgetOffsetByCenterAndWorldLocationPlain(float WorldPosX, float WorldPosY, float WorldPosZ, float& X, float& Y)
{
    FVector WorldPos(WorldPosX, WorldPosY, WorldPosZ);
    FVector2D Location = GetWidgetOffsetByCenterAndWorldLocation(WorldPos);
    X = static_cast<float>(Location.X);
    Y = static_cast<float>(Location.Y);
}

float UKGMapTagLayer::GetWidgetShearByWorldRotation(const FRotator& Rotation)
{
    FVector ForwardVector = Rotation.Vector() * 1000;
    FVector2D Triangle = GetWidgetOffsetByWorldLocation(ForwardVector) - GetWidgetOffsetByWorldLocation(FVector::ZeroVector);
    Triangle.Normalize();
    if (Triangle.X > .0f)
    {
        return static_cast<float>(FMath::Acos(Triangle.Y));
    }
    else // if(Triangle.X < .0f)
    {
        return static_cast<float>(2.0 * UE_DOUBLE_PI - FMath::Acos(Triangle.Y));
    }
    // return .0f;
}


float UKGMapTagLayer::GetWidgetShearByTaskID(const FString& TaskID) const
{
    if (MapTagInfoManager)
    {
        return MapTagInfoManager->GetWidgetShearByTaskID(TaskID);
    }
    
    return .0f;
}

FVector2D UKGMapTagLayer::GetWidgetPosByTaskID(const FString& TaskID) const
{
    if (MapTagInfoManager)
    {
        return MapTagInfoManager->GetWidgetPosByTaskID(TaskID);
    }
    
    return FVector2D::Zero();
}

void UKGMapTagLayer::SetTagUniformScale(float InScaleX, float InScaleY)
{
    TagUniformScale.X = InScaleX;
    TagUniformScale.Y = InScaleY;
    for (auto Iter = TagWidgets.CreateIterator(); Iter; ++Iter)
    {
        if (IsValid(Iter->Value.UserWidget))
        {
            Iter->Value.UserWidget->SetRenderScale(FVector2D(InScaleX, InScaleY));
        }
    }
}

void UKGMapTagLayer::SetData(const TMap<FString, FMapTagInfo>& InMapTagInfoData)
{
    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer]SetData, tag count:%d"), InMapTagInfoData.Num())
    for (auto Iter = TagWidgets.CreateIterator(); Iter; ++Iter)
    {
        RemoveTagUIInternal(Iter->Key);
        Iter.RemoveCurrent();
    }

    if (MapTagInfoManager)
    {
        MapTagInfoManager->ClearAllTags();
        MapTagInfoManager->BatchAddTags(InMapTagInfoData);
    }
}

void UKGMapTagLayer::AddSingleTag(const FMapTagInfo& InMapTagInfo) const
{
    if (MapTagInfoManager)
    {
        UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer]AddSingleTag %s"), *InMapTagInfo.ToString())
        MapTagInfoManager->AddSingleTag(InMapTagInfo);
    }
}

void UKGMapTagLayer::ClearAllTags()
{
    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer]ClearAllTags"))
    for (auto Iter = TagWidgets.CreateIterator(); Iter; ++Iter)
    {
        RemoveTagUIInternal(Iter->Key);
        Iter.RemoveCurrent();
    }
    TagWidgets.Empty(TagWidgets.Num());

    if (MapTagInfoManager)
    {
        MapTagInfoManager->ClearAllTags();
    }
}

void UKGMapTagLayer::RemoveSingleTag(const FString& TaskID)
{
    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer]RemoveSingleTag %s"), *TaskID)
    RemoveTagUI(TaskID);

    if (MapTagInfoManager)
    {
        MapTagInfoManager->RemoveSingleTag(TaskID);
    }
}

void UKGMapTagLayer::SetSimpleTagIcon(const FString& TaskID, const FString& InIcon) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->SetSimpleTagIcon(TaskID, InIcon);
    }
}

void UKGMapTagLayer::SetSimpleTagIconSize(const FString& TaskID, float InSizeX, float InSizeY) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->SetSimpleTagIconSize(TaskID, InSizeX, InSizeY);
    }
}

void UKGMapTagLayer::SetSimpleTagVisible(const FString& TaskID, bool bInVisible) const
{
	if (MapTagInfoManager)
	{
		MapTagInfoManager->SetSimpleTagVisible(TaskID, bInVisible);
	}
}

void UKGMapTagLayer::SetSimpleTagMaterialFloatParam(const FString& InTaskID, const FString& ParamName, float InValue)
{
	for (auto& Pair : SimpleTagIcons)
	{
		if (Pair.Value.TaskID == InTaskID && Pair.Value.DynamicInstance)
		{
			Pair.Value.DynamicInstance->SetScalarParameterValue(FName(*ParamName), InValue);
			break;
		}
	}
}

void UKGMapTagLayer::SetSimpleTagMaterialVectorParam(const FString& InTaskID, const FString& ParamName, float InXorR, float InYorG, float InZorB, float InWorA)
{
	for (auto& Pair : SimpleTagIcons)
	{
		if (Pair.Value.TaskID == InTaskID && Pair.Value.DynamicInstance)
		{
			Pair.Value.DynamicInstance->SetVectorParameterValue(FName(*ParamName), FVector4(InXorR, InYorG, InZorB, InWorA));
			break;
		}
	}
}

void UKGMapTagLayer::SetSimpleTagMaterialTextureParam(const FString& InTaskID, const FString& ParamName, class UTexture* InTexture)
{
	for (auto& Pair : SimpleTagIcons)
	{
		if (Pair.Value.TaskID == InTaskID && Pair.Value.DynamicInstance)
		{
			Pair.Value.DynamicInstance->SetTextureParameterValue(FName(*ParamName), InTexture);
			break;
		}
	}
}

void UKGMapTagLayer::SetSimpleTagRotateAngle(const FString& InTaskID, float InRotateAngleInDegree) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->SetSimpleTagRotate(InTaskID, InRotateAngleInDegree);
    }
}

void UKGMapTagLayer::BatchAddTags(const TMap<FString, FMapTagInfo>& InMapTagInfos) const
{
    for (TMap<FString, FMapTagInfo>::TConstIterator Iter = InMapTagInfos.CreateConstIterator(); Iter; ++Iter)
    {
        AddSingleTag(Iter->Value);
    }
}

void UKGMapTagLayer::BatchRemoveTags(TArray<FString> TaskIDs)
{
    for (int32 Index = 0; Index < TaskIDs.Num(); ++Index)
    {
        RemoveSingleTag(TaskIDs[Index]);
    }
}

TArray<FString> UKGMapTagLayer::ReqTaskNearByByTaskID(const FString& TaskID, float ToleranceDistance) const
{
    TArray<FString> OutTasks;
    if (MapTagInfoManager)
    {
        OutTasks = MapTagInfoManager->GetNearbyTasksByTaskID(TaskID, ToleranceDistance);
    }
    
    return OutTasks;
}

TArray<FString> UKGMapTagLayer::ReqInteractableTaskNearByByTaskID(const FString& TaskID, float ToleranceDistance, bool bRequireCenter /* = true */) const
{
    TArray<FString> OutTasks;
    if (MapTagInfoManager)
    {
        OutTasks = MapTagInfoManager->GetNearbyInteractableTasksByTaskID(TaskID, ToleranceDistance, bRequireCenter);
    }

    return OutTasks;
}

void UKGMapTagLayer::InitMapTagInfoManager()
{
    if (ConstraintRadius > 0)
    {
        MapTagInfoManager = NewObject<UKGMapTagInfoManager>(this);
        if (MapTagInfoManager)
        {
            float ViewportSize = static_cast<float>(CameraViewportSize.X);
            const float GridSize = ConstraintRadius * ViewportSize * ViewportScale;
            MapTagInfoManager->Initialize(GridSize, this);
        }
    }
}



UKGMapTagLayerSlot* UKGMapTagLayer::AddChildToMapTagLayer(UWidget* Content)
{
    return Cast<UKGMapTagLayerSlot>( Super::AddChild(Content) );
}

TSharedPtr<class SKGMapTagLayer> UKGMapTagLayer::GetMapTagLayerWidget() const
{
    return MyMapTagLayer;
}

bool UKGMapTagLayer::GetGeometryForSlot(int32 SlotIndex, FGeometry& ArrangedGeometry) const
{
    UKGMapTagLayerSlot* PanelSlot = CastChecked<UKGMapTagLayerSlot>(Slots[SlotIndex]);
    return GetGeometryForSlot(PanelSlot, ArrangedGeometry);
}

bool UKGMapTagLayer::GetGeometryForSlot(const UKGMapTagLayerSlot* InSlot, FGeometry& ArrangedGeometry) const
{
    if ( InSlot->Content == nullptr )
    {
        return false;
    }

    TSharedPtr<SKGMapTagLayer> Canvas = GetMapTagLayerWidget();
    if ( Canvas.IsValid() )
    {
        FArrangedChildren ArrangedChildren(EVisibility::All);
        Canvas->ArrangeChildren(Canvas->GetCachedGeometry(), ArrangedChildren);

        for ( int32 ChildIndex = 0; ChildIndex < ArrangedChildren.Num(); ChildIndex++ )
        {
            if ( ArrangedChildren[ChildIndex].Widget == InSlot->Content->GetCachedWidget() )
            {
                ArrangedGeometry = ArrangedChildren[ChildIndex].Geometry;
                return true;
            }
        }
    }

    return false;
}

void UKGMapTagLayer::ReleaseSlateResources(bool bReleaseChildren)
{
    if (!HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
    {
        UnregisterTick();
    }
    
    EntryWidgetPool.ResetPool();
    MyMapTagLayer.Reset();
    Super::ReleaseSlateResources(bReleaseChildren);
}

#if WITH_EDITOR
const FText UKGMapTagLayer::GetPaletteCategory()
{
    return  LOCTEXT("KGUI", "KGUI");
}

#endif

void UKGMapTagLayer::SynchronizeProperties()
{
    Super::SynchronizeProperties();

    if (!MyMapTagLayer.IsValid())
    {
        return;
    }

    RegisterTick();
    MyMapTagLayer->SetLocalExplicitCanvasChildZOrder(bLocalExplicitCanvasChildZOrder);
}

void UKGMapTagLayer::SetLocalExplicitCanvasChildZOrder(bool InbLocalExplicitCanvasChildZOrder)
{
    bLocalExplicitCanvasChildZOrder = InbLocalExplicitCanvasChildZOrder;
    if (MyMapTagLayer.IsValid())
    {
        MyMapTagLayer->SetLocalExplicitCanvasChildZOrder(bLocalExplicitCanvasChildZOrder);
    }
}

TSharedRef<SWidget> UKGMapTagLayer::RebuildWidget()
{
    MyMapTagLayer = SNew(SKGMapTagLayer);
    RegisterTick();

    for ( UPanelSlot* PanelSlot : Slots )
    {
        if ( UKGMapTagLayerSlot* TypedSlot = Cast<UKGMapTagLayerSlot>(PanelSlot) )
        {
            TypedSlot->Parent = this;
            TypedSlot->BuildSlot(MyMapTagLayer.ToSharedRef());
        }
    }

    return MyMapTagLayer.ToSharedRef();
}

UClass* UKGMapTagLayer::GetSlotClass() const
{
    return UKGMapTagLayerSlot::StaticClass();
}

void UKGMapTagLayer::OnSlotAdded(UPanelSlot* InSlot)
{
    // Add the child to the live canvas if it already exists
    if ( MyMapTagLayer.IsValid() )
    {
        CastChecked<UKGMapTagLayerSlot>(InSlot)->BuildSlot(MyMapTagLayer.ToSharedRef());
    }
}

void UKGMapTagLayer::OnSlotRemoved(UPanelSlot* InSlot)
{
    // Remove the widget from the live slot if it exists.
    if ( MyMapTagLayer.IsValid() && InSlot->Content)
    {
        TSharedPtr<SWidget> Widget = InSlot->Content->GetCachedWidget();
        if ( Widget.IsValid() )
        {
            MyMapTagLayer->RemoveSlot(Widget.ToSharedRef());
        }
    }
}

void UKGMapTagLayer::RetargetTagLocation(const FString& TaskID, const FVector& Location) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->UpdateTagLocation(TaskID, Location);
    }
}

void UKGMapTagLayer::ReSetTaskTypeToFollowActor(const FString& TaskID, int64 ActorID) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->ResetTaskTypeToFollowActor(TaskID, ActorID);
    }
}

void UKGMapTagLayer::ReSetTaskTypeToStatic(const FString& TaskID) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->ResetTaskTypeToStatic(TaskID);
    }
}

void UKGMapTagLayer::SetTaskShowEdgeType(const FString& TaskID, EMapEdgeType ShowOnEdgeType) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->SetTaskShowEdgeType(TaskID, ShowOnEdgeType);
    }
}

void UKGMapTagLayer::SetTaskInteractable(const FString& TaskID, bool bInteractable) const
{
    if (MapTagInfoManager)
    {
        MapTagInfoManager->SetTaskInteractable(TaskID, bInteractable);
    }
}

#if WITH_EDITOR
#pragma optimize("", on)
#endif

#undef LOCTEXT_NAMESPACE