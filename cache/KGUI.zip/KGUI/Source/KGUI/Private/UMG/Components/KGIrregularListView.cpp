#include "UMG/Components/KGIrregularListView.h"

#include "Slate/Views/SKGIrregularListView.h"
#include "UMG/Slate/SKGObjectIrregularListEntry.h"
#include "Editor/WidgetCompilerLog.h"
#include "UMG/Blueprint/IKGUserIrregularListEntry.h"
#include "UMG/Blueprint/DesignerPreviewItem.h"
#include "UMG/IrregularListView/KGIrregularListViewShapeStyle.h"

#define LOCTEXT_NAMESPACE "KGUI"

#ifdef SYNCHRONIZE_SLATE_PROPERTY
#error "SYNCHRONIZE_SLATE_PROPERTY has been defined multiple times, please try renaming it."
#endif
#define SYNCHRONIZE_SLATE_PROPERTY(LISTVIEW, PROPERTY_NAME) \
	LISTVIEW->Set##PROPERTY_NAME(this->PROPERTY_NAME); \
	this->PROPERTY_NAME = LISTVIEW->Get##PROPERTY_NAME();

UKGIrregularListView::UKGIrregularListView(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, EntryWidgetPool(*this)
{
}

#if WITH_EDITOR

void UKGIrregularListView::ValidateCompiledDefaults(IWidgetCompilerLog& CompileLog) const
{
	if (!EntryWidgetClass)
	{
		CompileLog.Error(FText::Format(FText::FromString(TEXT("{0} has no EntryWidgetClass specified - required for any UKGIrregularListView to function.")), FText::FromString(GetName())));
	}

	// 关闭KGUserIrregularListEntry接口限制
	//else if (!EntryWidgetClass->ImplementsInterface(UKGUserIrregularListEntry::StaticClass()))
	//{
	//	CompileLog.Error(FText::Format(FText::FromString(TEXT("'{0}' has EntryWidgetClass property set to'{1}' and that Class doesn't implement User Irregular List Entry Interface - required for any UKGIrregularListView to function.")), FText::FromString(GetName()), FText::FromString(EntryWidgetClass->GetName())));
	//}
}

#endif

void UKGIrregularListView::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	if (MyListView.IsValid())
	{
		PRAGMA_DISABLE_DEPRECATION_WARNINGS
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, Step);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, ElasticStyle);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, ElasticStrain);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, Padding);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, ScrollPosition);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, InertiaEnabled);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, CyclicEnabled);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, EntryAnchors);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, SnapEnabled);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, SnapAlignment);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, SelectionMode);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, OverlayStyle);
		MyListView->SetOverlayIncrementalItems(OverlayIncrementalItems);
		PRAGMA_ENABLE_DEPRECATION_WARNINGS
	}

	#if WITH_EDITORONLY_DATA

	if (IsDesignTime() && MyListView.IsValid())
	{
		bool bRefresh = false;
		if (EntryWidgetClass && NumDesignerPreviewEntries > 0
			// 关闭KGUserIrregularListEntry接口限制
			//&& EntryWidgetClass->ImplementsInterface(UKGUserIrregularListEntry::StaticClass())
		)
		{
			if (ListItems.Num() < NumDesignerPreviewEntries)
			{
				while (ListItems.Num() < NumDesignerPreviewEntries)
				{
					UDesignerPreviewItem* PreviewItem = NewObject<UDesignerPreviewItem>(this);
					PreviewItem->Index = ListItems.Num();
					ListItems.Add(PreviewItem);
				}
				bRefresh = true;
			}
			else if (ListItems.Num() > NumDesignerPreviewEntries)
			{
				const int32 NumExtras = ListItems.Num() - NumDesignerPreviewEntries;
				ListItems.RemoveAtSwap(ListItems.Num() - (NumExtras + 1), NumExtras);
				bRefresh = true;
			}
		}
		else
		{
			ListItems.Reset();
			bRefresh = true;
		}
		if (bRefresh)
		{
			RequestRefresh();
		}
	}

	#endif
}

void UKGIrregularListView::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	MyListView.Reset();
	EntryWidgetPool.ResetPool();
}

#if WITH_EDITOR

void UKGIrregularListView::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	if (MyListView.IsValid())
	{
		PRAGMA_DISABLE_DEPRECATION_WARNINGS
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, Step);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, ElasticStyle);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, ElasticStrain);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, Padding);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, ScrollPosition);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, InertiaEnabled);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, CyclicEnabled);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, EntryAnchors);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, SnapEnabled);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, SnapAlignment);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, SelectionMode);
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, OverlayStyle);
		MyListView->SetOverlayIncrementalItems(OverlayIncrementalItems);
		PRAGMA_ENABLE_DEPRECATION_WARNINGS
	}
}

#endif

void UKGIrregularListView::AddItem(UObject* Item)
{
	if (Item == nullptr)
	{
		FFrame::KismetExecutionMessage(TEXT("Cannot add null item into IrregularListView."), ELogVerbosity::Warning, "NullIrregularListViewItem");
		return;
	}
	if (ListItems.Contains(Item))
	{
		FFrame::KismetExecutionMessage(TEXT("Cannot add duplicate item into IrregularListView."), ELogVerbosity::Warning, "DuplicateIrregularListViewItem");
		return;
	}
	ListItems.Add(Item);
	RequestRefresh();
}

void UKGIrregularListView::RemoveItem(UObject* Item)
{
	ListItems.Remove(Item);
	RequestRefresh();
}

int UKGIrregularListView::GetIndex(UObject* Item) const
{
	if (!MyListView.IsValid())
	{
		return INDEX_NONE;
	}
	return MyListView->GetItems().IndexOfByKey(Item);
}

UObject* UKGIrregularListView::GetItem(int Index) const
{
	if (!MyListView.IsValid())
	{
		return nullptr;
	}
	const auto& Items = MyListView->GetItems();
	if (Items.IsValidIndex(Index))
	{
		return MyListView->GetItems()[Index];
	}
	return nullptr;
}

void UKGIrregularListView::SetListItems(const TArray<UObject*>& InListItems)
{
	ClearListItems();
	ListItems.Reserve(InListItems.Num());
	for (const UObject* ListItem : InListItems)
	{
		if (ListItem != nullptr)
		{
			ListItems.Add((const TObjectPtr<UObject>&)ListItem);
		}
	}
	RequestRefresh();
}

void UKGIrregularListView::ClearListItems()
{
	ListItems.Reset();
	RequestRefresh();
}

void UKGIrregularListView::RequestRefresh()
{
	if (MyListView.IsValid())
	{
		MyListView->RequestListRefresh();
	}
}

const TObjectPtr<UObject>* UKGIrregularListView::ItemFromEntryWidget(const UUserWidget& EntryWidget) const
{
	if (ensure(EntryWidget.Implements<UKGUserIrregularListEntry>()) && MyListView)
	{
		TSharedPtr<SKGObjectIrregularListEntry> Entry = StaticCastSharedPtr<SKGObjectIrregularListEntry>(EntryWidget.GetCachedWidget());
		if (Entry.IsValid())
		{
			return MyListView->ItemFromWidget(&Entry->AsWidget().Get());
		}
	}
	return nullptr;
}

int32 UKGIrregularListView::BP_GetSelectedItem() const
{
	TArray<UObject*> SelectedItems;
	if (!GetSelectedItems(SelectedItems))
	{
		return INDEX_NONE;
	}
	if (SelectedItems.Num() == 0)
	{
		return INDEX_NONE;
	}
	return GetIndex(SelectedItems[0]);
}

bool UKGIrregularListView::BP_GetItemProgress(int Index, float& OutProgress) const
{
	if (MyListView.IsValid())
	{
		return MyListView->GetItemProgress(GetItem(Index), OutProgress);
	}
	return false;
}

TSharedRef<IKGIrregularListEntry> UKGIrregularListView::HandleGenerateRow(UObject* Item, const TSharedRef<SKGIrregularListView<UObject*>>& OwnerTable)
{
	if (EntryWidgetClass == NULL)
	{
		return MyListView->CreateDefaultListEntry(FText::FromString(TEXT("EntryWidgetClass is null.")));
	}
	UUserWidget* EntryWidget = EntryWidgetPool.GetOrCreateInstance<UUserWidget>(
		*EntryWidgetClass,
		[this, &OwnerTable](UUserWidget* WidgetObject, TSharedRef<SWidget> Content)  // cppcheck:ignore 这里必须捕获this，因为要传给SKGObjectIrregularListEntry的构造函数
		{
			return SNew(SKGObjectIrregularListEntry, OwnerTable, *WidgetObject, this)
			[
				Content
			];
		});
	TSharedPtr<SWidget> CachedWidget = EntryWidget->GetCachedWidget();
	CachedWidget->SetCanTick(true);
	return StaticCastSharedPtr<SKGObjectIrregularListEntry>(CachedWidget).ToSharedRef();
}

void UKGIrregularListView::HandleOnEntryInitialized(UObject* Item, const TSharedRef<IKGIrregularListEntry>& Entry)
{
	auto ObjectIrregularListEntry = StaticCastSharedRef<IKGObjectIrregularListEntry>(Entry);
	OnEntryInitialized.Broadcast(Item, ObjectIrregularListEntry->GetUserWidget());
}

void UKGIrregularListView::HandleOnEntryReleased(UObject* Item, const TSharedRef<IKGIrregularListEntry>& Entry)
{
	auto ObjectIrregularListEntry = StaticCastSharedRef<IKGObjectIrregularListEntry>(Entry);
	UUserWidget* EntryWidget = ObjectIrregularListEntry->GetUserWidget();
	if (ensure(EntryWidget))
	{
		EntryWidgetPool.Release(EntryWidget);
		OnEntryReleased.Broadcast(Item, EntryWidget);
	}
}

FVector2D UKGIrregularListView::HandleOnArrangeItemInternal(const FGeometry& Geometry, UObject* Item, float Progress)
{
	UUserWidget* Widget = GetEntryWidgetFromItem(Item);
	if (!Widget)
	{
		return FVector2D::Zero();
	}
	UKGIrregularListViewShapeStyle* ShapeStyle = this->GetComponent<UKGIrregularListViewShapeStyle>();
	if (ShapeStyle != NULL)
	{
		return ShapeStyle->RaiseOnArrangeItem(Geometry, Widget, Progress);
	}
	if (OnArrangeItem.IsBound())
	{
		auto Vector2DReference = GetVector2DReference();
		OnArrangeItem.Broadcast(Geometry, Widget, Progress, Vector2DReference);
		return Vector2DReference->Value;
	}
	return FVector2D::Zero();
}

float UKGIrregularListView::HandleOnDraggedInternal(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent)
{
	UKGIrregularListViewShapeStyle* ShapeStyle = this->GetComponent<UKGIrregularListViewShapeStyle>();
	if (ShapeStyle != NULL)
	{
		return ShapeStyle->RaiseOnDragged(MyGeometry, TouchEvent);
	}
	if (OnDragged.IsBound())
	{
		auto FloatReference = GetFloatReference();
		OnDragged.Broadcast(MyGeometry, TouchEvent, FloatReference);
		return FloatReference->Value;
	}
	return 0;
}

bool UKGIrregularListView::HandleOnDragStartingInternal(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent)
{
	UKGIrregularListViewShapeStyle* ShapeStyle = this->GetComponent<UKGIrregularListViewShapeStyle>();
	if (ShapeStyle != nullptr)
	{
		return ShapeStyle->RaiseOnDragStarting(MyGeometry, TouchEvent);
	}
	return true;
}

void UKGIrregularListView::HandleOnSelectionChangedInternal(UObject* Item, bool Selected, ESelectInfo::Type SelectInfo)
{
	OnItemSelectionChanged.Broadcast(Item, Selected);
}

void UKGIrregularListView::HandleOnScrollEndedInternal()
{
	OnScrollEnded.Broadcast();
}

void UKGIrregularListView::HandleOnItemSnappedInternal(UObject* Item)
{
	OnItemSnapped.Broadcast(Item);
}

void UKGIrregularListView::HandleOnScrollPositionChanged(float InScrollPosition, EKGIrregularListViewUpdateSource UpdateSource)
{
	OnScrollPositionChanged.Broadcast(InScrollPosition, UpdateSource);
}

void UKGIrregularListView::HandleOnInteractionStarted()
{
	OnInteractionStarted.Broadcast();
}

void UKGIrregularListView::HandleOnInteractionEnded()
{
	OnInteractionEnded.Broadcast();
}

TSharedPtr<SKGObjectIrregularListEntry> UKGIrregularListView::GetObjectRowFromItem(UObject* Item) const
{
	if (EntryWidgetClass == NULL)
	{
		return NULL;
	}
	if (!MyListView.IsValid())
	{
		return nullptr;
	}
	TSharedPtr<IKGIrregularListEntry> IrregularListEntry = MyListView->WidgetFromItem(Item);
	return StaticCastSharedPtr<SKGObjectIrregularListEntry>(IrregularListEntry);
}

UUserWidget* UKGIrregularListView::GetEntryWidgetFromItem(UObject* Item) const
{
	TSharedPtr<SKGObjectIrregularListEntry> ObjectEntry = GetObjectRowFromItem(Item);
	if (ObjectEntry.IsValid())
	{
		return Cast<UUserWidget>(ObjectEntry->GetWidgetObject());
	}
	return NULL;
}

TObjectPtr<UKGVector2DReference>& UKGIrregularListView::GetVector2DReference()
{
	if (Vector2DReferenceCache == NULL || !Vector2DReferenceCache->IsValidLowLevel())
	{
		Vector2DReferenceCache = NewObject<UKGVector2DReference>(this);
	}
	return Vector2DReferenceCache;
}

TObjectPtr<UKGFloatReference>& UKGIrregularListView::GetFloatReference()
{
	if (FloatReferenceCache == NULL || !FloatReferenceCache->IsValidLowLevel())
	{
		FloatReferenceCache = NewObject<UKGFloatReference>(this);
	}
	return FloatReferenceCache;
}

PRAGMA_DISABLE_DEPRECATION_WARNINGS

void UKGIrregularListView::SetScrollPosition(float InScrollPosition)
{
	ScrollPosition = InScrollPosition;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, ScrollPosition);
	}
}

float UKGIrregularListView::GetScrollPosition() const
{
	return ScrollPosition;
}

void UKGIrregularListView::SetStep(float InStep)
{
	Step = InStep;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, Step);
	}
}

float UKGIrregularListView::GetStep() const
{
	return Step;
}

void UKGIrregularListView::SetElasticStyle(EKGElasticStyle InElasticStyle)
{
	ElasticStyle = InElasticStyle;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, ElasticStyle);
	}
}

EKGElasticStyle UKGIrregularListView::GetElasticStyle() const
{
	return ElasticStyle;
}

void UKGIrregularListView::SetElasticStrain(float InElasticStrain)
{
	ElasticStrain = InElasticStrain;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, ElasticStrain);
	}
}

float UKGIrregularListView::GetElasticStrain() const
{
	return ElasticStrain;
}

void UKGIrregularListView::SetPadding(const FKGLinearMargin& InPadding)
{
	Padding = InPadding;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, Padding);
	}
}

FKGLinearMargin UKGIrregularListView::GetPadding() const
{
	return Padding;
}

void UKGIrregularListView::SetEntryAnchors(const FAnchors& InEntryAnchors)
{
	EntryAnchors = InEntryAnchors;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, EntryAnchors);
	}
}

FAnchors UKGIrregularListView::GetEntryAnchors() const
{
	return EntryAnchors;
}

void UKGIrregularListView::SetInertiaEnabled(bool InInertiaEnabled)
{
	InertiaEnabled = InInertiaEnabled;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, InertiaEnabled);
	}
}

bool UKGIrregularListView::GetInertiaEnabled() const
{
	return InertiaEnabled;
}

void UKGIrregularListView::SetCyclicEnabled(bool InCyclicEnabled)
{
	CyclicEnabled = InCyclicEnabled;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, CyclicEnabled);
	}
}

bool UKGIrregularListView::GetCyclicEnabled() const
{
	return CyclicEnabled;
}

void UKGIrregularListView::SetSnapEnabled(bool InSnapEnabled)
{
	SnapEnabled = InSnapEnabled;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, SnapEnabled);
	}
}

bool UKGIrregularListView::GetSnapEnabled() const
{
	return SnapEnabled;
}

void UKGIrregularListView::SetSnapAlignment(float InSnapAlignment)
{
	SnapAlignment = InSnapAlignment;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, SnapAlignment);
	}
}

float UKGIrregularListView::GetSnapAlignment() const
{
	return SnapAlignment;
}

void UKGIrregularListView::SetOverlayStyle(EKGOverlayStyle InOverlayStyle)
{
	OverlayStyle = InOverlayStyle;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, OverlayStyle);
	}
}

EKGOverlayStyle UKGIrregularListView::GetOverlayStyle() const
{
	return OverlayStyle;
}

void UKGIrregularListView::AddOverlayIncrementalItem(UObject* Item)
{
	OverlayIncrementalItems.AddUnique(Item);
	if (MyListView.IsValid())
	{
		MyListView->AddOverlayIncrementalItem(Item);
	}
}

void UKGIrregularListView::RemoveOverlayIncrementalItem(UObject* Item)
{
	OverlayIncrementalItems.Remove(Item);
	if (MyListView.IsValid())
	{
		MyListView->RemoveOverlayIncrementalItem(Item);
	}
}

void UKGIrregularListView::BP_AddOverlayIncrementalItem(int Index)
{
	if (ListItems.IsValidIndex(Index))
	{
		AddOverlayIncrementalItem(ListItems[Index]);
	}
}

void UKGIrregularListView::BP_RemoveOverlayIncrementalItem(int Index)
{
	if (ListItems.IsValidIndex(Index))
	{
		RemoveOverlayIncrementalItem(ListItems[Index]);
	}
}

PRAGMA_ENABLE_DEPRECATION_WARNINGS

bool UKGIrregularListView::ScrollToIndex(int ItemIndex, bool bAnimated)
{
	if (!MyListView.IsValid())
	{
		return false;
	}
	return MyListView->ScrollToIndex(ItemIndex, bAnimated);
}

bool UKGIrregularListView::ScrollToItem(UObject* Item, bool bAnimated)
{
	if (!MyListView.IsValid())
	{
		return false;
	}
	return MyListView->ScrollToItem(Item, bAnimated);
}

bool UKGIrregularListView::ScrollToPosition(float TargetScrollPosition, bool bAnimated)
{
	if (!MyListView.IsValid())
	{
		return false;
	}
	return MyListView->ScrollToPosition(TargetScrollPosition, bAnimated);
}

int UKGIrregularListView::GetScrollingTargetIndex()
{
	if (!MyListView.IsValid())
	{
		return INDEX_NONE;
	}
	return MyListView->GetScrollingTargetIndex();
}

UObject* UKGIrregularListView::GetScrollingTargetItem()
{
	if (!MyListView.IsValid())
	{
		return NULL;
	}
	return *MyListView->GetScrollingTargetItem();
}

PRAGMA_DISABLE_DEPRECATION_WARNINGS

void UKGIrregularListView::SetSelectionMode(ESelectionMode::Type InSelectionMode)
{
	SelectionMode = InSelectionMode;
	if (MyListView.IsValid())
	{
		SYNCHRONIZE_SLATE_PROPERTY(MyListView, SelectionMode);
	}
}

ESelectionMode::Type UKGIrregularListView::GetSelectionMode() const
{
	return SelectionMode;
}

PRAGMA_ENABLE_DEPRECATION_WARNINGS

void UKGIrregularListView::SetItemSelection(UObject* Item, bool bSelected)
{
	if (!MyListView.IsValid())
	{
		return;
	}
	MyListView->SetItemSelection(Item, bSelected);
}

void UKGIrregularListView::ClearSelection()
{
	if (!MyListView.IsValid())
	{
		return;
	}
	return MyListView->ClearSelection();
}

bool UKGIrregularListView::IsItemSelected(UObject* Item) const
{
	if (!MyListView.IsValid())
	{
		return false;
	}
	return MyListView->IsItemSelected(Item);
}

bool UKGIrregularListView::GetSelectedItems(TArray<UObject*>& Items) const
{
	if (!MyListView.IsValid())
	{
		return false;
	}
	const auto &SelectedItems = MyListView->GetSelectedItems();
	for (auto SelectedItem : SelectedItems)
	{
		Items.Add(SelectedItem);
	}
	return true;
}

void UKGIrregularListView::SetFadeInProgress(float Progress)
{
	FadeInProgress = Progress;
	if (MyListView.IsValid())
	{
		MyListView->Invalidate(EInvalidateWidget::Paint);
	}
}

void UKGIrregularListView::SetFadeOutProgress(float Progress)
{
	FadeOutProgress = Progress;
	if (MyListView.IsValid())
	{
		MyListView->Invalidate(EInvalidateWidget::Paint);
	}
}

void UKGIrregularListView::SetCustomScalarParameter0(float Progress)
{
	CustomScalarParameter0 = Progress;
	if (MyListView.IsValid())
	{
		MyListView->Invalidate(EInvalidateWidget::Paint);
	}
}

void UKGIrregularListView::SetCustomScalarParameter1(float Progress)
{
	CustomScalarParameter1 = Progress;
	if (MyListView.IsValid())
	{
		MyListView->Invalidate(EInvalidateWidget::Paint);
	}
}

void UKGIrregularListView::SetCustomScalarParameter2(float Progress)
{
	CustomScalarParameter2 = Progress;
	if (MyListView.IsValid())
	{
		MyListView->Invalidate(EInvalidateWidget::Paint);
	}
}

void UKGIrregularListView::SetCustomScalarParameter3(float Progress)
{
	CustomScalarParameter3 = Progress;
	if (MyListView.IsValid())
	{
		MyListView->Invalidate(EInvalidateWidget::Paint);
	}
}

void UKGIrregularListView::HandleOnHovered()
{
	OnHovered.Broadcast();
}

void UKGIrregularListView::HandleOnUnhovered()
{
	OnUnhovered.Broadcast();
}

void UKGIrregularListView::RebuildBackground()
{
	if (BackgroundClass)
	{
		BackgroundInstance = CreateWidget(this, BackgroundClass);
	}
	else
	{
		BackgroundInstance = nullptr;
	}
	if (BackgroundInstance)
	{
		check(MyListView.IsValid());
		MyListView->ConstructBackground(BackgroundInstance->TakeWidget());
	}
}

TSharedRef<SWidget> UKGIrregularListView::RebuildWidget()
{
	const TArray<UObject*>& TypedListItems = ListItems;
	TSharedRef<SKGIrregularListView<UObject*>> IrregularListView =
		SNew(SKGIrregularListView<UObject*>)
		.ListItemsSource(&TypedListItems)
		.OnGenerateWidget_UObject(this, &UKGIrregularListView::HandleGenerateRow)
		.OnEntryInitialized_UObject(this, &UKGIrregularListView::HandleOnEntryInitialized)
		.OnEntryReleased_UObject(this, &UKGIrregularListView::HandleOnEntryReleased)
		.OnArrangeItem_UObject(this, &UKGIrregularListView::HandleOnArrangeItemInternal)
		.OnDragged_UObject(this, &UKGIrregularListView::HandleOnDraggedInternal)
		.OnDragStarting_UObject(this, &UKGIrregularListView::HandleOnDragStartingInternal)
		.OnSelectionChanged_UObject(this, &UKGIrregularListView::HandleOnSelectionChangedInternal)
		.OnScrollEnded_UObject(this, &UKGIrregularListView::HandleOnScrollEndedInternal)
		.OnItemSnapped_UObject(this, &UKGIrregularListView::HandleOnItemSnappedInternal)
		.OnScrollPositionChanged_UObject(this, &UKGIrregularListView::HandleOnScrollPositionChanged)
		.OnInteractionStarted_UObject(this, &UKGIrregularListView::HandleOnInteractionStarted)
		.OnInteractionEnded_UObject(this, &UKGIrregularListView::HandleOnInteractionEnded)
		.OnHovered_UObject(this, &ThisClass::HandleOnHovered)
		.OnUnhovered_UObject(this, &ThisClass::HandleOnUnhovered)
		.bGenerateAllEntries(this->bGenerateAllEntries)
		.WheelScrollMultiplier(
			TAttribute<float>::Create(
				TAttribute<float>::FGetter::CreateUObject(this, &ThisClass::GetWheelScrollMultiplier)
			)
		)
		.ForceRefreshEveryFrame(
			TAttribute<bool>::Create(
				TAttribute<bool>::FGetter::CreateUObject(this, &ThisClass::IsForceRefreshEveryFrameEnabled)
			)
		)
		;
	MyListView = IrregularListView.ToSharedPtr();
	MyListView->SetAcceleration(Acceleration);
	RebuildBackground();
	return IrregularListView;
}

#undef SYNCHRONIZE_SLATE_PROPERTY
#undef LOCTEXT_NAMESPACE