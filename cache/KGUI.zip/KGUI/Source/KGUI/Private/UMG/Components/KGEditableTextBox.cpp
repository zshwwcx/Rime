// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGEditableTextBox.h"

#include "AkAudioEvent.h"
#include "Manager/KGAkAudioManager.h"
#include "KGUI.h"
#include "Components/EditableTextBox.h"
#include "Slate/Input/SKGEditableTextBox.h"
#include "Styling/DefaultStyleCache.h"
#include "UObject/ObjectSaveContext.h"
#include "Widgets/Input/SEditableTextBox.h"

UKGEditableTextBox::UKGEditableTextBox(FObjectInitializer const& ObjectInitializer)
	:Super(ObjectInitializer)
{
	HintTextStyle = WidgetStyle.TextStyle;
	HintTextStyle.ColorAndOpacity = FLinearColor(1, 1, 1, 0.35);
	AllowContextMenu = false;
}

#if WITH_EDITOR
void UKGEditableTextBox::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	if (auto KGUI = FModuleManager::Get().GetModulePtr<FKGUIModule>("KGUI"))
	{
		KGUI->GetOnWidgetCreatedFromPalette().Broadcast(this);
	}
}
#endif

void UKGEditableTextBox::GoTo(ETextLocation NewLocation)
{
	if (MyEditableTextBlock.IsValid())
	{
		MyEditableTextBlock->GoTo(NewLocation);
	}
}

void UKGEditableTextBox::KGSetClearKeyboardFocusOnCommit(bool bClearKeyboardFocusOnCommit)
{
	SetClearKeyboardFocusOnCommit(bClearKeyboardFocusOnCommit);
}

void UKGEditableTextBox::PostWidgetAudio(const FFocusEvent& FocusEvent)
{
	if (UKGAkAudioManager* AkAudioMgr = UKGAkAudioManager::GetInstance(this))
	{
		if (WidgetAkEvent.ToSoftObjectPath().IsValid())
		{
		    AkAudioMgr->InnerPostEvent3D(WidgetAkEvent.GetAssetName());
		}
	}
}

TSharedRef<SWidget> UKGEditableTextBox::RebuildWidget()
{
	auto EditableTextBox = ConstructWidget<SKGEditableTextBox>("SKGEditableTextBox");

	EditableTextBox->SetOnEditableTextFocusReceived(BIND_UOBJECT_DELEGATE(FOnEditableTextFocusReceived, HandleOnFocusReceived));
	EditableTextBox->SetOnEditableTextFocusLost(BIND_UOBJECT_DELEGATE(FOnEditableTextFocusLost, HandleOnFocusLost));

	EditableTextBox->SetHintTextStyleAttribute(
		TAttribute<FTextBlockStyle>::Create(
			TAttribute<FTextBlockStyle>::FGetter::CreateUObject(this, &UKGEditableTextBox::GetHintTextStyle)
		)
	);

	MyEditableTextBlock = EditableTextBox;

	if (WidgetAkEvent.ToSoftObjectPath().IsValid())
	{
		OnFocusReceived.AddDynamic(this, &UKGEditableTextBox::PostWidgetAudio);	
	}
	
	return MyEditableTextBlock.ToSharedRef();
}

void UKGEditableTextBox::ReleaseSlateResources(bool bReleaseChildren)
{
	OnFocusReceived.RemoveDynamic(this, &UKGEditableTextBox::PostWidgetAudio);
	Super::ReleaseSlateResources(bReleaseChildren);
}

void UKGEditableTextBox::SynchronizeProperties()
{
	Super::SynchronizeProperties();

	if (MyEditableTextBlock)
	{
		MyEditableTextBlock->SetAllowContextMenu(false);
	}
}

void UKGEditableTextBox::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);
	AllowContextMenu = false;
}

void UKGEditableTextBox::HandleOnFocusReceived(const FFocusEvent& FocusEvent)
{
	OnFocusReceived.Broadcast(FocusEvent);
}

void UKGEditableTextBox::HandleOnFocusLost(const FFocusEvent& FocusEvent)
{
	OnFocusLost.Broadcast(FocusEvent);
}

#pragma region HintText样式

void UKGEditableTextBox::SetHintTextStyle(const FTextBlockStyle& InHintTextStyle)
{
	HintTextStyle = InHintTextStyle;
}

FTextBlockStyle UKGEditableTextBox::GetHintTextStyle() const
{
	return HintTextStyle;
}

#pragma endregion