#include "UMG/Components/KGMultilineEditableRichText.h"

#include "RenderDeferredCleanup.h"
#include "Framework/Text/RichTextMarkupProcessing.h"
#include "Slate/Text/SKGMultilineEditableRichText.h"
#include "UMG/Components/KGRichTextBlockHyperlinkDecorator.h"
#include "UMG/Components/KGRichTextBlockImageDecorator.h"
#include "UMG/Components/KGRichTextBlockTextDecorator.h"
#include "UMG/Components/KGRichTextLayoutMarshaller.h"
#include "UMG/Components/KGRichTextSettings.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SSpacer.h"


UKGMultiLineEditableRichText::UKGMultiLineEditableRichText(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

TSharedRef<SWidget> UKGMultiLineEditableRichText::RebuildWidget()
{
	Box = SNew(SBox);
	return Box.ToSharedRef();
}

void UKGMultiLineEditableRichText::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	Box.Reset();
	TextLayout.Reset();
}

void UKGMultiLineEditableRichText::SetRichTextBlock(UKGRichTextBlock* InRichTextBlock)
{
	RichTextBlock = InRichTextBlock;
	InstanceDecorators.Empty();

	if (RichTextBlock == nullptr)
	{
		MyMultiLineEditableText.Reset();
		Box->SetContent(SNew(SSpacer));
		return;
	}

	// BEGIN: 创建InstanceDecorators，这里需要和KGRichTextBlock保持一致
	TArray<TSharedRef<ITextDecorator>> CreatedDecorators;
	for (auto DecoratorClass : RichTextBlock->GetDecoratorClasses())
	{
		if (UClass* ResolvedClass = DecoratorClass.Get())
		{
			if (!ResolvedClass->HasAnyClassFlags(CLASS_Abstract))
			{
				URichTextBlockDecorator* Decorator = NewObject<URichTextBlockDecorator>(this, ResolvedClass);
				InstanceDecorators.Add(Decorator);
			}
		}
	}
	auto RichImageDataTables = UKGRichTextBlock::GetRichImageDataTables(RichTextBlock);
	InstanceDecorators.Add(UKGRichTextBlock::CreateRichTextBlockTextDecorator(this));
	InstanceDecorators.Add(UKGRichTextBlock::CreateRichTextBlockImageDecorator(this, RichImageDataTables));
	InstanceDecorators.Add(UKGRichTextBlock::CreateRichTextBlockHyperlinkDecorator(this, RichImageDataTables));

	for (URichTextBlockDecorator* Decorator : InstanceDecorators)
	{
		if (Decorator)
		{
			TSharedPtr<ITextDecorator> TextDecorator = Decorator->CreateDecorator(RichTextBlock);
			if (TextDecorator.IsValid())
			{
				CreatedDecorators.Add(TextDecorator.ToSharedRef());
			}
		}
	}
	// END

	RichTextBlockWidgetStyle = RichTextBlock->GetCurrentDefaultTextStyle();

	auto Marshaller = FKGRichTextLayoutMarshaller::Create(
		FDefaultRichTextMarkupParser::GetStaticInstance(),
		FDefaultRichTextMarkupWriter::Create(), CreatedDecorators, RichTextBlock->GetStyleInstanceInternal().Get());

	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	auto MultiLineEditableText = SNew(SKGMultiLineEditableRichText)
		.TextStyle(&RichTextBlockWidgetStyle)
		.AllowContextMenu(AllowContextMenu)
		.IsReadOnly(bIsReadOnly)
		.SelectAllTextWhenFocused(SelectAllTextWhenFocused)
		.ClearTextSelectionOnFocusLoss(ClearTextSelectionOnFocusLoss)
		.RevertTextOnEscape(RevertTextOnEscape)
		.ClearKeyboardFocusOnCommit(ClearKeyboardFocusOnCommit)
		.VirtualKeyboardOptions(VirtualKeyboardOptions)
		.VirtualKeyboardDismissAction(VirtualKeyboardDismissAction)
		.OnTextChanged(BIND_UOBJECT_DELEGATE(FOnTextChanged, HandleOnTextChanged))
		.OnTextCommitted(BIND_UOBJECT_DELEGATE(FOnTextCommitted, HandleOnTextCommitted))
		.CreateSlateTextLayout(BIND_UOBJECT_DELEGATE(FCreateSlateTextLayout, HandleOnCreateSlateTextLayout))
		.Marshaller(Marshaller)
		.OnIsTypedCharValid(FOnIsTypedCharValid::CreateLambda([](const TCHAR) { return true; }))
		;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
		MultiLineEditableText->SetOnIsComposingChanged(ITextInputMethodContext::FOnIsComposingChanged::FDelegate::CreateUObject(this, &UKGMultiLineEditableRichText::HandleOnIsComposingChanged));

	MultiLineEditableText->SetOnFocusReceived(BIND_UOBJECT_DELEGATE(SKGMultiLineEditableRichText::FOnFocusReceived, HandleOnFocusReceived));
	MultiLineEditableText->SetOnFocusLost(BIND_UOBJECT_DELEGATE(SKGMultiLineEditableRichText::FOnFocusLost, HandleOnFocusLost));

	MultiLineEditableText->SetHintTextStyleAttribute(
		TAttribute<FTextBlockStyle>::Create(
			TAttribute<FTextBlockStyle>::FGetter::CreateUObject(this, &UKGMultiLineEditableRichText::GetHintTextStyle)
		)
	);
	MultiLineEditableText->SetCanInsertCarriageReturn(bCanInsertCarriageReturn);
	MultiLineEditableText->SetOnIsCharAllowed(SKGMultiLineEditableRichText::FOnIsCharAllowed::CreateUObject(this, &UKGMultiLineEditableRichText::HandleOnIsCharAllowed));
	MultiLineEditableText->SetOnKeyDownHandler(BIND_UOBJECT_DELEGATE(FOnKeyDown, HandleOnKeyDown));

	if (WidgetAkEvent.ToSoftObjectPath().IsValid())
	{
		OnFocusReceived.AddDynamic(this, &UKGMultiLineEditableRichText::PostWidgetAudio);
	}
	MyMultiLineEditableText = MultiLineEditableText;
	Box->SetContent(MultiLineEditableText);

	SynchronizeProperties();
}

FString UKGMultiLineEditableRichText::GetTextInternal(bool bWithSelectionRunInfoEditing, const FString& RunInfoName, const TMap<FString, FString>& RunInfoMetaData, FRunInfoEditCallback EditCallback, FRunInfoNormalizeCallback NormalizeCallback) const
{
	if (!MyMultiLineEditableText.IsValid())
	{
		return FString();
	}
	auto SelectedRuns = MyMultiLineEditableText->GetSelectedRuns();
	auto Selection = MyMultiLineEditableText->GetSelection();
	const auto& SourceLineModels = TextLayout->GetLineModels();

	TArray<IRichTextMarkupWriter::FRichTextLine> WriterLines;
	WriterLines.Reserve(SourceLineModels.Num());

	FRunInfo RunInfo;
	RunInfo.Name = RunInfoName;
	RunInfo.MetaData = RunInfoMetaData;

	auto SelectionBeginning = Selection.GetBeginning();
	auto SelectionEnd = Selection.GetEnd();

	for (int LineIndex = 0; LineIndex < SourceLineModels.Num(); LineIndex++)
	{
		const FTextLayout::FLineModel& LineModel = SourceLineModels[LineIndex];
		IRichTextMarkupWriter::FRichTextLine WriterLine;

		TArray<IRichTextMarkupWriter::FRichTextRun> Runs;

		auto RunInfoEquals = [](const FRunInfo& A, const FRunInfo& B)
		{
			if (A.Name != B.Name)
			{
				return false;
			}
			if (A.MetaData.Num() != B.MetaData.Num())
			{
				return false;
			}
			for (const auto& Pair : A.MetaData)
			{
				auto FoundInB = B.MetaData.Find(Pair.Key);
				if (FoundInB == nullptr)
				{
					return false;
				}
				if (*FoundInB != Pair.Value)
				{
					return false;
				}
			}
			return true;
		};

		auto AppendRun = [RunInfoEquals, NormalizeCallback](TArray<IRichTextMarkupWriter::FRichTextRun>& Runs, const FRunInfo& RunInfo, const FString& RunText)
		{
			if (RunText.Len() == 0)
			{
				return;
			}
			auto TempRunInfo = RunInfo;
			if (NormalizeCallback.IsBound())
			{
				TempRunInfo = NormalizeCallback.Execute(FKGRunInfo(TempRunInfo)).ToRunInfo();
			}
			if (Runs.Num() > 0)
			{
				auto& LastRun = Runs[Runs.Num() - 1];
				if (RunInfoEquals(LastRun.Info, TempRunInfo))
				{
					LastRun.Text = LastRun.Text + RunText;
					return;
				}
			}
			Runs.Emplace(IRichTextMarkupWriter::FRichTextRun(TempRunInfo, RunText));
		};

		for (const FTextLayout::FRunModel& RunModel : LineModel.Runs)
		{
			FString RunText;
			RunModel.AppendTextTo(RunText);

			auto RunBeginning = FTextLocation(LineIndex, RunModel.GetTextRange().BeginIndex);
			auto RunEnd = FTextLocation(LineIndex, RunModel.GetTextRange().EndIndex);

			auto EditingLeft = FMath::Max(SelectionBeginning, RunBeginning);
			auto EditingRight = FMath::Min(SelectionEnd, RunEnd);
			bool bInterested = EditingLeft < EditingRight;  // 相交且相交长度不为0
			if (!bInterested || !bWithSelectionRunInfoEditing)
			{
				AppendRun(Runs, RunModel.GetRun()->GetRunInfo(), RunText);
			}
			else
			{
				if (RunBeginning < SelectionBeginning)
				{
					check(RunBeginning.GetLineIndex() == SelectionBeginning.GetLineIndex());
					AppendRun(Runs, RunModel.GetRun()->GetRunInfo(), RunText.Left(SelectionBeginning.GetOffset() - RunBeginning.GetOffset()));
				}
				{
					check(EditingLeft.GetLineIndex() == EditingRight.GetLineIndex());

					auto TempRunInfo = RunInfo;
					if (EditCallback.IsBound())
					{
						TempRunInfo = EditCallback.Execute(FKGRunInfo(RunModel.GetRun()->GetRunInfo()), FKGRunInfo(RunInfo)).ToRunInfo();
					}

					AppendRun(Runs, TempRunInfo, RunText.Mid(EditingLeft.GetOffset() - RunBeginning.GetOffset(), EditingRight.GetOffset() - EditingLeft.GetOffset()));
				}
				if (SelectionEnd < RunEnd) // (RunEnd > SelectionEnd)
				{
					check(RunEnd.GetLineIndex() == SelectionEnd.GetLineIndex());
					AppendRun(Runs, RunModel.GetRun()->GetRunInfo(), RunText.Right(RunEnd.GetOffset() - SelectionEnd.GetOffset()));
				}
			}
		}
		WriterLine.Runs = Runs;
		WriterLines.Add(WriterLine);
	}

	FString TargetString;
	FDefaultRichTextMarkupWriter::Create()->Write(WriterLines, TargetString);
	return TargetString;
}

FString UKGMultiLineEditableRichText::GetTextWithSelectionRunInfoEditing(FString RunInfoName, TMap<FString, FString> RunInfoMetaData, FRunInfoEditCallback EditCallback) const
{
	return GetTextInternal(true, RunInfoName, RunInfoMetaData, EditCallback, FRunInfoNormalizeCallback());
}

FString UKGMultiLineEditableRichText::GetNormalizedText(FRunInfoNormalizeCallback NormalizeCallback) const
{
	return GetTextInternal(false, FString(), TMap<FString, FString>(), FRunInfoEditCallback(), NormalizeCallback);
}

void UKGMultiLineEditableRichText::SelectText(const FKGTextLocation& InSelectionStart, const FKGTextLocation& InCursorLocation)
{
	if (!MyMultiLineEditableText.IsValid())
	{
		return;
	}
	MyMultiLineEditableText->SelectText(InSelectionStart.ToTextLocation(), InCursorLocation.ToTextLocation());
}

FKGTextLocation UKGMultiLineEditableRichText::GetSelectionBeginning() const
{
	if (!MyMultiLineEditableText.IsValid())
	{
		return FKGTextLocation();
	}
	return MyMultiLineEditableText->GetSelection().GetBeginning();
}

FKGTextLocation UKGMultiLineEditableRichText::GetSelectionEnd() const
{
	if (!MyMultiLineEditableText.IsValid())
	{
		return FKGTextLocation();
	}
	return MyMultiLineEditableText->GetSelection().GetEnd();
}

TSharedRef<FSlateTextLayout> UKGMultiLineEditableRichText::HandleOnCreateSlateTextLayout(SWidget* InOwningWidget, const FTextBlockStyle& InDefaultTextStyle)
{
	TextLayout = FSlateTextLayout::Create(InOwningWidget, InDefaultTextStyle);
	return TextLayout.ToSharedRef();
}

FReply UKGMultiLineEditableRichText::HandleOnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (OnKeyDown.IsBound())
	{
		return OnKeyDown.Execute(MyGeometry, InKeyEvent).NativeReply;
	}
	return FReply::Handled();
}
