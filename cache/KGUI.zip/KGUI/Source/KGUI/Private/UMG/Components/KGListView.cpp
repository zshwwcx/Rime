#include "UMG/Components/KGListView.h"

#include "MovieScene.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "Core/Common.h"
#include "EntitySystem/MovieSceneEntitySystemRunner.h"
#include "Styling/DefaultStyleCache.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "UMG/Slate/SKGObjectTableRow.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(KGListView)

#define LOCTEXT_NAMESPACE "KGUI"

FKGItemAnimationEntryStyle FKGItemAnimationEntryStyle::Default;

void FKGItemAnimationConfiguration::SetSingleEntryStyle(const FKGItemAnimationEntryStyle& InEntryStyle)
{
	this->EntryStyles.Empty();
	this->EntryStyles.Add(InEntryStyle);
	this->bValid = true;
	RefreshRandomSeed();
}

void FKGItemAnimationConfiguration::SetEntryStyleArray(const TArray<FKGItemAnimationEntryStyle>& InEntryStyles)
{
	this->EntryStyles = InEntryStyles;
	this->bValid = true;
	RefreshRandomSeed();
}

void FKGItemAnimationConfiguration::RefreshRandomSeed() const
{
	FMath::RandInit(this->RandomSeed);
	this->RandomSeed = FMath::Rand32();
}

UKGListView::UKGListView(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Orientation(EOrientation::Orient_Vertical)
{
	WidgetStyle = UE::Slate::Private::FDefaultStyleCache::GetRuntime().GetListViewStyle();
	ScrollBarStyle = UE::Slate::Private::FDefaultStyleCache::GetRuntime().GetScrollBarStyle();

#if WITH_EDITOR 
	if (IsEditorWidget())
	{
		WidgetStyle = UE::Slate::Private::FDefaultStyleCache::GetEditor().GetListViewStyle();
		ScrollBarStyle = UE::Slate::Private::FDefaultStyleCache::GetEditor().GetScrollBarStyle();

		// The CDO isn't an editor widget and thus won't use the editor style, call post edit change to mark difference from CDO
		PostEditChange();
	}
#endif // WITH_EDITOR
}

#if WITH_EDITOR 
void UKGListView::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	if (auto Settings = GetDefault<UKGUISettings>())
	{
		ScrollHintClassBefore = Settings->DefaultScrollHintClassBefore.LoadSynchronous();
		ScrollHintClassAfter = Settings->DefaultScrollHintClassAfter.LoadSynchronous();
	}
}
#endif // WITH_EDITOR

void UKGListView::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	SetScrollBarVisibility(ScrollBarVisibility);
}

TSharedRef<STableViewBase> UKGListView::RebuildListWidget()
{
	auto ListView = ConstructListView<SKGListView>();
	ListView->SetContentPadding(GetContentPadding());
	return ListView;
}

void UKGListView::ReleaseSlateResources(bool bReleaseChildren)
{
	StopItemAnimationInternal();
	Super::ReleaseSlateResources(bReleaseChildren);
	MyListView.Reset();
}

UUserWidget& UKGListView::OnGenerateEntryWidgetInternal(ItemType Item, TSubclassOf<UUserWidget> DesiredEntryClass, const TSharedRef<STableViewBase>& OwnerTable)
{
#if WITH_EDITOR
	const bool bEnableListViewItemSelectionChangedDelegate = GetDefault<UKGUISettings>()->bEnableListViewItemSelectionChangedDelegate;
#else
	const static bool bEnableListViewItemSelectionChangedDelegate = GetDefault<UKGUISettings>()->bEnableListViewItemSelectionChangedDelegate;
#endif

	auto& Entry = GenerateTypedEntry<UUserWidget, SKGObjectTableRow<ItemType>, true>(DesiredEntryClass, OwnerTable, bEnableListViewItemSelectionChangedDelegate);
	auto ObjectTableRow = StaticCastSharedPtr<SKGObjectTableRow<ItemType>>(Entry.GetCachedWidget());

	check(ObjectTableRow.IsValid());

	ObjectTableRow->SetIsFocusable(this->bIsEntryFocusable);

	auto DesiredEntryClassIndex = Item->GetDesiredEntryClassIndex();  // 此时已经获取到DesiredEntryClass，所以DesiredEntryClassIndex是最新的。
	FKGEntryWidgetConfiguration CurrentEntryWidgetConfiguration;
	if (TryGetEntryWidgetConfiguration(DesiredEntryClassIndex, CurrentEntryWidgetConfiguration))
	{
		int Level = GetItemLevel(Item);
		auto HorizontalAlignment = IsEntryWidgetAlignmentAvailable(EOrientation::Orient_Horizontal, Level)
			? CurrentEntryWidgetConfiguration.HorizontalAlignment.GetValue()
			: EHorizontalAlignment::HAlign_Fill;
		ObjectTableRow->SetHorizontalAlignment(HorizontalAlignment);
		if (IsLengthOverrideAvailable(EOrientation::Orient_Horizontal, Level, HorizontalAlignment == EHorizontalAlignment::HAlign_Fill))
		{
			ObjectTableRow->SetChildWidthOverride(CurrentEntryWidgetConfiguration.bOverride_WidthOverride ? CurrentEntryWidgetConfiguration.WidthOverride : FOptionalSize());
		}
		else
		{
			ObjectTableRow->SetChildWidthOverride(FOptionalSize());
		}

		auto VerticalAlignment = IsEntryWidgetAlignmentAvailable(EOrientation::Orient_Vertical, Level)
			? CurrentEntryWidgetConfiguration.VerticalAlignment.GetValue()
			: EVerticalAlignment::VAlign_Fill;
		ObjectTableRow->SetVerticalAlignment(VerticalAlignment);
		if (IsLengthOverrideAvailable(EOrientation::Orient_Vertical, Level, VerticalAlignment == EVerticalAlignment::VAlign_Fill))
		{
			ObjectTableRow->SetChildHeightOverride(CurrentEntryWidgetConfiguration.bOverride_HeightOverride ? CurrentEntryWidgetConfiguration.HeightOverride : FOptionalSize());
		}
		else
		{
			ObjectTableRow->SetChildHeightOverride(FOptionalSize());
		}

		if (CurrentEntryWidgetConfiguration.StyleSheetPreset != nullptr)
		{
			CurrentEntryWidgetConfiguration.StyleSheetPreset->Apply(&Entry);
		}
	}
	auto StyleSheetRelativeViewPtr = StyleSheetRelativeViews.Find(DesiredEntryClass->GetFName());
	if (StyleSheetRelativeViewPtr != nullptr)
	{
		auto& StyleSheetRelativeView = *StyleSheetRelativeViewPtr;
		StyleSheetRelativeView.Apply(&Entry);
	}
	return Entry;
}

TSharedRef<ITableRow> UKGListView::HandleGenerateRow(ItemType Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	auto Row = ITypedUMGListView<TSharedPtr<FKGListItem>>::HandleGenerateRow(Item, OwnerTable);

#if WITH_EDITOR
	const bool bUpdateListViewCanTickStateOnGenerating = GetDefault<UKGUISettings>()->bUpdateListViewCanTickStateOnGenerating;
#else
	const static bool bUpdateListViewCanTickStateOnGenerating = GetDefault<UKGUISettings>()->bUpdateListViewCanTickStateOnGenerating;
#endif

	if (bUpdateListViewCanTickStateOnGenerating)
	{
		auto Widget = StaticCastSharedRef<SKGObjectTableRow<ItemType>>(Row->AsWidget());;
		if (auto WidgetObject = Widget->GetWidgetObject())
		{
			WidgetObject->UpdateCanTick();
		}
	}
	
	return Row;
}

void UKGListView::HandleOnEntryInitializedInternal(ItemType Item, const TSharedRef<ITableRow>& TableRow)
{
	auto EntryWidget = GetEntryWidgetFromItem(Item);
	BP_OnEntryInitialized.Broadcast(GetIndexForItem(Item), EntryWidget);
	if (ActiveItemAnimationConfiguration.IsValid())
	{
		ForceUpdateItemAnimation(ActiveItemAnimationConfiguration, Item);
	}
	else
	{
		if (GetDefault<UKGUISettings>()->bRestoreDefaultItemAnimationFinishStateOnEntryInitialized)
		{
			if (auto UserWidget = Cast<UKGUserWidget>(EntryWidget))
			{
				if (auto DefaultListItemAnimation = FindAnimation(UserWidget, GetDefaultItemAnimationEntryStyle(Item).AnimationName))
				{
					UserWidget->PlayAnimationToEnd(DefaultListItemAnimation);
				}
			}
		}
	}
}

void UKGListView::NativeOnEntryReleased(UUserWidget* EntryWidget)
{
	if (auto UserWidget = Cast<UKGUserWidget>(EntryWidget))
	{
		auto ActiveSequencePlayersCopy = EntryWidget->ActiveSequencePlayers;
		for (auto ActiveSequencePlayer : ActiveSequencePlayersCopy)
		{
			if (ActiveSequencePlayer->IsPlayingForward())
			{
				auto Animation = const_cast<UWidgetAnimation*>(ActiveSequencePlayer->GetAnimation());
				UserWidget->PlayAnimationToEnd(Animation);
			}
		}
		if (RemovingItemEntries.Contains(UserWidget))
		{
			auto ItemRemoveAnimation = FindAnimation(UserWidget, ItemRemoveAnimationName);
			UserWidget->PlayAnimationToStart(ItemRemoveAnimation);
		}
	}
	RemovingItemEntries.Remove(EntryWidget);
	Super::NativeOnEntryReleased(EntryWidget);
}

void UKGListView::OnSelectionChangedInternal(ItemType FirstSelectedItem)
{
	ITypedUMGListView::OnSelectionChangedInternal(FirstSelectedItem);
	// 不要在这里回调`BP_OnItemSelectionChanged`，这样无法支持多选类型
	// BP_OnItemSelectionChanged.Broadcast(ListItems.IndexOfByKey(FirstSelectedItem), FirstSelectedItem != nullptr);
}

void UKGListView::OnItemScrolledIntoViewInternal(ItemType ListItem, UUserWidget& EntryWidget)
{
	ITypedUMGListView::OnItemScrolledIntoViewInternal(ListItem, EntryWidget);
	BP_OnItemScrolledIntoView.Broadcast(GetIndexForItem(ListItem), &EntryWidget);
}

void UKGListView::OnListViewScrolledInternal(float ItemOffset, float DistanceRemaining)
{
	ITypedUMGListView::OnListViewScrolledInternal(ItemOffset, DistanceRemaining);
	BP_OnListViewScrolled.Broadcast(ItemOffset, DistanceRemaining);
}

void UKGListView::HandleOnSelectionsChangedInternal(const SKGListView<ItemType>::TItemSet& SelectedItems, ESelectInfo::Type SelectInfo)
{
	TArray<int32> SelectedIndexes;
	for (const auto& SelectedItem : SelectedItems)
	{
		SelectedIndexes.Add(GetIndexForItem(SelectedItem));
	}
	BP_OnSelectionsChanged.Broadcast(SelectedIndexes, SelectInfo);
}

void UKGListView::HandleOnItemSelectionChangedInternal(const NullableItemType& Item, bool bSelected)
{
	BP_OnItemSelectionChanged.Broadcast(ListItems.IndexOfByKey(Item), bSelected);
}

void UKGListView::OnItemClickedInternal(ItemType ListItem)
{
	ITypedUMGListView<TSharedPtr<FKGListItem>>::OnItemClickedInternal(ListItem);
	BP_OnItemClicked.Broadcast(GetIndexForItem(ListItem));
}

void UKGListView::OnItemDoubleClickedInternal(ItemType ListItem)
{
	ITypedUMGListView<TSharedPtr<FKGListItem>>::OnItemDoubleClickedInternal(ListItem);
	BP_OnItemDoubleClicked.Broadcast(GetIndexForItem(ListItem));
}

void UKGListView::HandleItemScrolledIntoView(ItemType Item, const TSharedPtr<ITableRow>& InWidget)
{
	// 覆盖基类，KGUI的列表不需要不提供返回UserWidget对象（主要原因是KGTreeView的TileLayout样式存在一些情况找不到Item对应的UserWidget，
	// 为了保持一致就在KGListView中完全禁用掉）
	// Super::HandleItemScrolledIntoView(Item, InWidget);
	// TODO: 如有需要，后续可以补充描述Item的“序号”或“序号列表”参数回调
}

void UKGListView::HandleOnItemsRefreshed(const FGeometry& AllottedGeometry)
{
	MarkShapeAsDirty();
	if (BP_OnItemsRefreshed.IsBound())
	{
		BP_OnItemsRefreshed.Broadcast(AllottedGeometry);
	}
	ProcessScrollingDelegates();
	FlushActionsOnItemsRefreshed();
}

void UKGListView::HandleOnUserScrollingStarted()
{
	BP_OnUserScrollingStarted.Broadcast();
}

void UKGListView::HandleOnUserScrollingEnded()
{
	BP_OnUserScrollingEnded.Broadcast();
}

void UKGListView::HandleOnOverscrollAmountChanged()
{
	BP_OnOverscrollUpdated.Broadcast(GetOverscroll());
}

UUserWidget* UKGListView::UserWidgetFromItem(const ItemType& Item) const
{
	if (!MyListView.IsValid())
	{
		return nullptr;
	}
	if (auto TableRow = MyListView->WidgetFromItem(Item))
	{
		if (auto UserWidget = StaticCastSharedPtr<IObjectTableRow>(TableRow)->GetUserWidget())
		{
			return UserWidget;
		}
	}
	return nullptr;
}

FMargin UKGListView::GetDesiredEntryPadding(ItemType Item) const
{
	if (SlateListItems.Num() > 0 && SlateListItems[0] != Item)
	{
		return
			Orientation == EOrientation::Orient_Horizontal
			? FMargin(HorizontalEntrySpacing, 0.f, 0.0f, 0.f)
			: FMargin(0.f, VerticalEntrySpacing, 0.f, 0.f);
	}
	return FMargin(0.f);
}

#if WITH_EDITOR
void UKGListView::OnRefreshDesignerItems()
{
	RefreshDesignerItems<ItemType>(ListItems, [WeakThis = TWeakObjectPtr<UKGListView>(this)]() { return WeakThis.Get()->SpawnItem(); });
	SlateListItems = ListItems;
}
#endif

UKGListView::ItemType UKGListView::SpawnItem() const
{
	return MakeShareable(new ItemType::ElementType);
}

void UKGListView::SetListItems(int Count)
{
	if (MyListView.IsValid() && MyListView->IsTicking())
	{
		UE_LOG(LogKGUI, Error, TEXT("Do not update list items when the widget is ticking! Widget: %s."), *this->GetPathName());
		return;
	}
	ClearListItems();
	ListItems.Reserve(Count);
	SlateListItems.Reserve(Count);
	for (int Index = 0; Index < Count; Index++)
	{
		auto NewItem = SpawnItem();
		ListItems.Add(NewItem);
		SlateListItems.Add(NewItem);
	}
	RequestRefresh();
}

bool UKGListView::AddItem()
{
	return InsertItem(ListItems.Num());
}

bool UKGListView::InsertItem(int32 Index)
{
	ItemType NewItem = MakeShareable(new ItemType::ElementType);
	return InsertListItem(Index, NewItem);
}

bool UKGListView::InsertListItem(int32 Index, ItemType NewItem)
{
	auto ClampedIndex = FMath::Clamp(Index, 0, ListItems.Num());
	if (ClampedIndex != Index)
	{
		UE_LOG(LogKGUI, Error, TEXT("InsertItem's input parameter `Index` is %d, which is out of range [0, %d)."), Index, ListItems.Num());
		return false;
	}
	OnInsertingListItem(Index, NewItem);
	ListItems.Insert(NewItem, Index);
	if (Index == 0)
	{
		SlateListItems.Insert(NewItem, 0);
		UpdateEntryPadding(1);
	}
	else
	{
		auto LastItem = ListItems[Index - 1];
		SlateListItems.Insert(NewItem, SlateListItems.IndexOfByKey(LastItem) + 1);
	}
	RequestRefresh();
	PostInsertItemInternal(NewItem);
	return true;
}

bool UKGListView::RemoveItem(int32 Index)
{
	return RemoveListItem(Index);
}

bool UKGListView::RemoveListItem(int32 Index)
{
	if (!ListItems.IsValidIndex(Index))
	{
		return false;
	}
	auto ItemToBeRemoved = ListItems[Index];
	ListItems.RemoveAt(Index);
	OnListItemRemoved(Index);

	TryPlayRemovingAnimationInternal(ItemToBeRemoved);
	return true;
}

void UKGListView::RemoveItemInternal(ItemType ItemToBeRemoved)
{
	SlateListItems.Remove(ItemToBeRemoved);  // 这里可能并没有啥效果（比如在KGTreeView中删除一个层级大于1的节点），但是调用后续的刷新逻辑是有必要的。
	UpdateEntryPadding(0);
	RequestRefresh();
}

UKGListView::ItemType UKGListView::GetItemAt(int32 Index) const
{
	return ListItems.IsValidIndex(Index) ? ListItems[Index] : nullptr;
}

int32 UKGListView::GetNumItems() const
{
	return ListItems.Num();
}

int32 UKGListView::GetIndexForItem(ItemType Item) const
{
	return ListItems.IndexOfByKey(Item);
}

void UKGListView::ClearListItems()
{
	ListItems.Reset();
	SlateListItems.Reset();
	RequestRefresh();
}

bool UKGListView::IsRefreshPending() const
{
	if (MyListView.IsValid())
	{
		return MyListView->IsPendingRefresh();
	}
	return false;
}

void UKGListView::ScrollIndexIntoView(int32 Index, float Alignment)
{
	BP_ScrollItemIntoView(Index, Alignment);
}

void UKGListView::SetSelectedItem(ItemType Item)
{
	ITypedUMGListView<ItemType>::SetSelectedItem(const_cast<ItemType&>(Item));
}

void UKGListView::SetSelectedIndex(int32 Index)
{
	SetSelectedItem(GetItemAt(Index));
}

void UKGListView::NavigateToIndex(int32 Index)
{
	RequestNavigateToItem(GetItemAt(Index));
}

void UKGListView::BP_SetSelectedItem(int32 Index)
{
	SetSelectedItem(GetItemAt(Index));
}

void UKGListView::BP_SetItemSelection(int32 Index, bool bSelected)
{
	SetItemSelection(GetItemAt(Index), bSelected);
}

void UKGListView::BP_ClearSelection()
{
	ClearSelection();
}

int32 UKGListView::BP_GetNumItemsSelected() const
{
	return GetNumItemsSelected();
}

bool UKGListView::BP_GetSelectedItems(TArray<int32>& Indexes) const
{
	TArray<ItemType> Items;
	GetSelectedItems(Items);
	Indexes.Empty(Items.Num());
	for (auto& Item : Items)
	{
		Indexes.Add(GetIndexForItem(Item));
	}
	return Indexes.Num() > 0;
}

bool UKGListView::BP_IsItemVisible(int32 Index) const
{
	auto Item = GetItemAt(Index);
	return IsItemVisible(Item);
}

void UKGListView::BP_NavigateToItem(int32 Index)
{
	if (auto Item = GetItemAt(Index))
	{
		RequestNavigateToItem(Item);
	}
}

void UKGListView::ScrollItemIntoViewInternal(int32 Index, bool bAutoAlignment, float Alignment)
{
	if (auto Item = GetItemAt(Index))
	{
		if (MyListView != NULL)
		{
			if (bAutoAlignment)
			{
				MyListView->RequestScrollIntoView(Item, GetOwningUserIndex());
			}
			else
			{
				MyListView->RequestScrollIntoView(Item, Alignment, GetOwningUserIndex());
			}
		}
	}
	else
	{
		UE_LOG(LogKGUI, Error, TEXT("List view (%s) 's ScrollItemIntoView requested an invalid index: %d"), *this->GetPathName(), Index);
	}
}

void UKGListView::BP_ScrollItemIntoView(int32 Index, float Alignment)
{
	ScrollItemIntoViewInternal(Index, false, Alignment);
}

void UKGListView::BP_ScrollItemIntoViewIfNeeded(int32 Index)
{
	ScrollItemIntoViewInternal(Index, true, 0);
}

void UKGListView::BP_CancelScrollIntoView()
{
	if (MyListView.IsValid())
	{
		MyListView->CancelScrollIntoView();
	}
}

void UKGListView::BP_SetListItems(int32 Count)
{
	SetListItems(Count);
}

int32 UKGListView::BP_GetSelectedItem() const
{
	return GetIndexForItem(GetSelectedItem());
}

FVector2D UKGListView::GetScrollDistanceRemaining() const
{
	if (MyListView == nullptr)
	{
		return FVector2D(0, 0);
	}
	return MyListView->GetScrollDistanceRemaining();
}

UKGListView::ItemType UKGListView::GetItemFromWidget(UUserWidget* Widget) const
{
	if (Widget == nullptr)
	{
		return nullptr;
	}
	if (!MyListView.IsValid())
	{
		return nullptr;
	}
	ItemType Found;
	auto CachedWidget = Widget->GetCachedWidget();
	MyListView->ForEachGeneratedItems(
		[WeakCachedWidget = CachedWidget.ToWeakPtr(), &Found](ItemType Item, TSharedRef<ITableRow> TableRow)
		{
			auto StrongCachedWidget = WeakCachedWidget.Pin();
			if (!StrongCachedWidget.IsValid())
			{
				return;
			}
			if (TableRow.Get().AsWidget() == StrongCachedWidget)
			{
				Found = Item;
			}
		}
	);
	return Found;
}

int UKGListView::GetIndexFromWidget(UUserWidget* Widget) const
{
	auto Item = GetItemFromWidget(Widget);
	if (!Item)
	{
		return INDEX_NONE;
	}
	return GetIndexForItem(Item);
}

void UKGListView::SetSelectionMode(TEnumAsByte<ESelectionMode::Type> InSelectionMode)
{
	SelectionMode = InSelectionMode;
	if (MyListView)
	{
		MyListView->SetSelectionMode(InSelectionMode);
	}
}

void UKGListView::SetScrollBarVisibility(EKGScrollBarVisibility InScrollBarVisibility)
{
	ScrollBarVisibility = InScrollBarVisibility;
	if (MyListView)
	{
		MyListView->SetScrollBarVisibility(InScrollBarVisibility);
	}
}

void UKGListView::UpdateEntryPadding(ItemType Item)
{
	auto EntryWidget = UserWidgetFromItem(Item);
	if (EntryWidget == nullptr)
	{
		return;
	}
	const FMargin DefaultPadding = EntryWidget->GetClass()->GetDefaultObject<UUserWidget>()->GetPadding();
	EntryWidget->SetPadding(DefaultPadding + GetDesiredEntryPadding(Item));
}

void UKGListView::UpdateEntryPadding(int Index)
{
	if (!SlateListItems.IsValidIndex(Index))
	{
		return;
	}
	UpdateEntryPadding(SlateListItems[Index]);
}

bool UKGListView::IsStartedTouchInteraction() const
{
	if (MyListView.IsValid())
	{
		return MyListView->IsStartedTouchInteraction();
	}
	return false;
}

TSubclassOf<UUserWidget> UKGListView::GetDesiredEntryClassForItem(ItemType Item) const
{
	if (MoreEntryWidgetClasses.Num() > 0)
	{
		if (OnGetEntryClassIndexForItem.IsBound())
		{
			int EntryClassIndex = OnGetEntryClassIndexForItem.Execute(GetIndexForItem(Item));
			if (EntryClassIndex < 0 || EntryClassIndex > MoreEntryWidgetClasses.Num())
			{
				UE_LOG(LogKGUI, Error, TEXT("Entry class index `%d` requested from OnGetEntryClassIndexForItem is not valid (minimum: %d, maximum: %d)."), EntryClassIndex, 0, MoreEntryWidgetClasses.Num());
				EntryClassIndex = 0;
			}
			if (EntryClassIndex != 0)
			{
				if (auto Class = MoreEntryWidgetClasses[EntryClassIndex - 1])
				{
					Item->SetDesiredEntryClassIndex(EntryClassIndex);
					return Class;
				}
			}
		}
	}
	Item->SetDesiredEntryClassIndex(INDEX_NONE);
	return ITypedUMGListView<TSharedPtr<FKGListItem>>::GetDesiredEntryClassForItem(Item);
}

void UKGListView::AddMoreEntryWidgetClass(TSubclassOf<UKGUserWidget> Entry)
{
	if (Entry.Get())
	{
		MoreEntryWidgetClasses.Add(Entry);
	}
	else
	{
		MoreEntryWidgetClasses.Add(EntryWidgetClass.Get());
	}
}

void UKGListView::ClearMoreEntryWidgetClasses()
{
	MoreEntryWidgetClasses.Reset();
}

void UKGListView::SetEntryWidgetClass(TSubclassOf<UKGUserWidget> Entry)
{
	if (Entry.Get())
	{
		EntryWidgetClass = Entry;
	}
	else
	{
		UE_LOG(LogKGUI, Error, TEXT("UKGListView::SetEntryWidgetClass Entry is nullptr"))
	}
}

bool UKGListView::TryGetEntryWidgetConfiguration(int EntryClassIndex, FKGEntryWidgetConfiguration& OutEntryWidgetConfiguration) const
{
	if (EntryClassIndex == 0 || EntryClassIndex == INDEX_NONE)
	{
		OutEntryWidgetConfiguration = EntryWidgetConfiguration;
		return true;
	}
	if (MoreEntryWidgetConfigurations.IsValidIndex(EntryClassIndex - 1))
	{
		OutEntryWidgetConfiguration = MoreEntryWidgetConfigurations[EntryClassIndex - 1];
		return true;
	}
	return false;
}

void UKGListView::SetStyleSheetRelativeView(FName EntryClassName, const FKGStyleSheetRelativeView& StyleSheetRelativeView)
{
	StyleSheetRelativeViews.FindOrAdd(EntryClassName) = StyleSheetRelativeView;
}

void UKGListView::SetStyleSheetRelativeView(FName EntryClassName, FKGStyleSheetRelativeView&& StyleSheetRelativeView)
{
	StyleSheetRelativeViews.FindOrAdd(EntryClassName) = MoveTemp(StyleSheetRelativeView);
}

void UKGListView::RemoveStyleSheetRelativeView(FName EntryClassName)
{
	StyleSheetRelativeViews.Remove(EntryClassName);
}

UWidgetAnimation* UKGListView::FindAnimation(UUserWidget* UserWidget, const FKGWidgetAnimationName& AnimationName)
{
	if (UserWidget == nullptr)
	{
		return nullptr;
	}
	UWidgetBlueprintGeneratedClass* WidgetClass = Cast<UWidgetBlueprintGeneratedClass>(UserWidget->GetClass());
	if (WidgetClass == nullptr)
	{
		return nullptr;
	}
	for (auto Animation : WidgetClass->Animations)
	{
		if (Animation->GetMovieScene()->GetName() == AnimationName)
		{
			return Animation;
		}
	}
	return nullptr;
}

#pragma region 子项动画

void UKGListView::PlayListItemAnimation(const FKGItemAnimationEntryStyle& InEntryStyle)
{
	if (IsRefreshPending())
	{
		ExecuteOnItemsRefreshed(FSimpleDelegate::CreateLambda([WeakThis = TWeakObjectPtr<UKGListView>(this), InEntryStyle]()
		{
			if (auto This = WeakThis.Get())
			{
				This->PlayListItemAnimation(InEntryStyle);
			}
		}));
		return;
	}
	StopItemAnimationInternal();
	ActiveItemAnimationConfiguration.SetSingleEntryStyle(InEntryStyle);
	PlayItemAnimationInternal();
}

void UKGListView::PlayListItemAnimationWithDefaultConfiguration()
{
	PlayListItemAnimation(DefaultListItemAnimationConfiguration);
}

void UKGListView::SeekListItemAnimationToStart(const FKGItemAnimationEntryStyle& InEntryStyle)
{
	StopItemAnimationInternal(false);
	ActiveItemAnimationConfiguration.SetSingleEntryStyle(InEntryStyle);
	auto StartTime = this->GetWorld()->GetTimeSeconds();
	this->OnItemAnimationTick(ActiveItemAnimationConfiguration, StartTime, true, EKGItemAnimationState::Preparing);
}

void UKGListView::SeekListItemAnimationToStartWithDefaultConfiguration()
{
	SeekListItemAnimationToStart(DefaultListItemAnimationConfiguration);
}

void UKGListView::StopListItemAnimation()
{
	StopItemAnimationInternal();
}

void UKGListView::PlayItemAnimationInternal()
{
	auto StartTime = this->GetWorld()->GetTimeSeconds();
	LastPassedTime = 0;
	if (this->OnItemAnimationTick(ActiveItemAnimationConfiguration, StartTime, true, EKGItemAnimationState::Unknown))
	{
		LastPassedTime = MAX_dbl;
		return;
	}
	this->GetWorld()->GetTimerManager().SetTimer(
		ItemAnimationTimerHandle,
		FTimerDelegate::CreateLambda([WeakThis = TWeakObjectPtr<UKGListView>(this), StartTime]()
			{
				if (auto This = WeakThis.Get())
				{
					if (This->OnItemAnimationTick(This->ActiveItemAnimationConfiguration, StartTime, false, EKGItemAnimationState::Unknown))
					{
						This->StopItemAnimationInternal(false);
					}
				}
			}),
		this->ActiveItemAnimationConfiguration.TickInterval,
		true
	);
}

void UKGListView::StopItemAnimationInternal(bool bRefresh)
{
	if (ItemAnimationTimerHandle.IsValid())
	{
		this->GetWorld()->GetTimerManager().ClearTimer(ItemAnimationTimerHandle);
		if (bRefresh)
		{
			this->OnItemAnimationTick(ActiveItemAnimationConfiguration, 0, false, EKGItemAnimationState::Finished);
		}
	}
	LastPassedTime = MAX_dbl;
	ActiveItemAnimationConfiguration.Invalidate();
}

bool UKGListView::IsItemAnimationPlaying(UUserWidget* UserWidget, UWidgetAnimation* WidgetAnimation)
{
	for (auto ActiveSequencePlayer : UserWidget->ActiveSequencePlayers)
	{
		if (ActiveSequencePlayer->GetAnimation() == WidgetAnimation)
		{
			return true;
		}
	}
	return false;
}

EKGItemAnimationState UKGListView::GetItemAnimationState(const ItemType& Item, double TriggerTime, double PassedTime, double AnimationDuration)
{
	if (PassedTime >= TriggerTime + AnimationDuration)
	{
		return EKGItemAnimationState::Finished;
	}
	else if (PassedTime >= TriggerTime)
	{
		return EKGItemAnimationState::Playing;
	}
	else
	{
		return EKGItemAnimationState::Preparing;
	}
}

EKGItemAnimationState UKGListView::UpdateItemAnimation(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item, double InLastPassedTime, double PassedTime, bool bForce, EKGItemAnimationState SpecificAnimationState)
{
	auto UserWidget = Cast<UKGUserWidget>(UserWidgetFromItem(Item));
	if (UserWidget == nullptr)
	{
		return EKGItemAnimationState::Finished;
	}

	const auto& EntryStyle = GetItemAnimationEntryStyle(Configuration, Item);

	auto Animation = FindAnimation(UserWidget, EntryStyle.AnimationName);
	if (Animation == nullptr)
	{
		return EKGItemAnimationState::Finished;
	}
	double TriggerTime = 0;

	switch (EntryStyle.TriggerStyle)
	{
	case EKGItemAnimationTriggerStyle::Linear:
		TriggerTime = GetItemAnimationTriggerTime_Linear(Configuration, Item);
		break;
	case EKGItemAnimationTriggerStyle::Chessboard:
		TriggerTime = GetItemAnimationTriggerTime_Chessboard(Configuration, Item);
		break;
	case EKGItemAnimationTriggerStyle::Random:
		TriggerTime = GetItemAnimationTriggerTime_Random(Configuration, Item);
		break;
	case EKGItemAnimationTriggerStyle::LineWise:
		TriggerTime = GetItemAnimationTriggerTime_LineWise(Configuration, Item);
		break;
	case EKGItemAnimationTriggerStyle::Blueprint:
		TriggerTime = GetItemAnimationTriggerTime_Blueprint(Configuration, Item);
		break;
	}
	auto Duration = Animation->GetEndTime() - Animation->GetStartTime();
	auto AnimationState = SpecificAnimationState == EKGItemAnimationState::Unknown ? GetItemAnimationState(Item, TriggerTime, PassedTime, Duration) : SpecificAnimationState;

	if (!bForce)
	{
		auto LastAnimationState = GetItemAnimationState(Item, TriggerTime, InLastPassedTime, Duration);
		if (LastAnimationState == AnimationState)
		{
			return LastAnimationState;
		}
	}

	auto Settings = GetDefault<UKGUISettings>();
	bool bUseWidgetAnimationStyle = false;
	if (Settings && Settings->bPreferToUseWidgetAnimationStyle)
	{
		SCOPED_NAMED_EVENT_TEXT("ListView - Flush Item Animation", FColor::Emerald);
		bUseWidgetAnimationStyle = UserWidget->HasAnyWidgetAnimationStyle(Animation);
		UserWidget->ApplyWidgetAnimationStyle(Animation, AnimationState);
	}

	switch (AnimationState)
	{
	case EKGItemAnimationState::Preparing:
		UserWidget->PlayAnimationToStart(Animation);
		break;
	case EKGItemAnimationState::Playing:
		UserWidget->PlayAnimation(Animation, PassedTime - TriggerTime);
		break;
	case EKGItemAnimationState::Finished:
		UserWidget->PlayAnimationToEnd(Animation);
		break;
	default:
		ensure(false);
	}

	if (Settings && !bUseWidgetAnimationStyle)
	{
		SCOPED_NAMED_EVENT_TEXT("ListView - Flush Item Animation", FColor::Emerald);
		if (Settings->bFlushAnimationOnListEntryRefreshed)
		{
			if (auto UMGSequenceTickManager = UUMGSequenceTickManager::Get(this))
			{
				if (!UMGSequenceTickManager->IsTicking())
				{
					UserWidget->FlushAnimations();
				}
			}
		}
	}
	
	return AnimationState;
}

void UKGListView::ForceUpdateItemAnimation(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item)
{
	UpdateItemAnimation(Configuration, Item, LastPassedTime, LastPassedTime, true, EKGItemAnimationState::Unknown);
}

bool UKGListView::OnItemAnimationTick(const FKGItemAnimationConfiguration& Configuration, double StartTime, bool bForce, EKGItemAnimationState SpecificAnimationState)
{
	if (!MyListView.IsValid())
	{
		return true;
	}
	auto CurrentTime = this->GetWorld()->GetTimeSeconds();
	auto PassedTime = CurrentTime - StartTime;
	bool bFinished = true;
	for (auto Item : MyListView->GetItems())
	{
		bFinished &= UpdateItemAnimation(Configuration, Item, LastPassedTime, PassedTime, bForce, SpecificAnimationState) == EKGItemAnimationState::Finished;
	}
	LastPassedTime = PassedTime;
	if (bFinished)
	{
		UE_LOG(LogKGUI, Log, TEXT("ListView's item animation finished: %s"), *this->GetName());
	}
	return bFinished;
}

int32 UKGListView::GetLocalItemIndex(const ItemType& Item) const
{
	if (MyListView == nullptr)
	{
		return -1;
	}
	return MyListView->GetItems().IndexOfByKey(Item);
}

int32 UKGListView::GetLocalNumItemsPerLine(const ItemType& Item) const
{
	if (MyListView == nullptr)
	{
		return 1;
	}
	return MyListView->GetNumItemsPerLine();
}

const FKGItemAnimationEntryStyle& UKGListView::GetItemAnimationEntryStyle(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const
{
	if (Configuration.EntryStyles.Num() > 0)
	{
		return Configuration.EntryStyles[0];
	}
	return FKGItemAnimationEntryStyle::Default;
}

double UKGListView::GetItemAnimationTriggerTime_Linear(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const
{
	const auto& EntryStyle = GetItemAnimationEntryStyle(Configuration, Item);
	return GetLocalItemIndex(Item) * EntryStyle.Interval + EntryStyle.Offset;
}

double UKGListView::GetItemAnimationTriggerTime_Chessboard(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const
{
	int Index = GetLocalItemIndex(Item);
	int NumItemsPerLine = GetLocalNumItemsPerLine(Item);
	check(NumItemsPerLine != 0);
	if (NumItemsPerLine % 2 == 0)
	{
		int LineIndex = Index / NumItemsPerLine;
		if (LineIndex % 2 == 0)
		{
			Index++;
		}
	}
	const auto& EntryStyle = GetItemAnimationEntryStyle(Configuration, Item);
	return EntryStyle.Interval * (Index % 2) + EntryStyle.Offset;
}

double UKGListView::GetItemAnimationTriggerTime_Random(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const
{
	int Index = GetLocalItemIndex(Item);
	const auto& EntryStyle = GetItemAnimationEntryStyle(Configuration, Item);
	return EntryStyle.Interval * ((Configuration.GetRandomSeed() ^ (Index * 3571 + 997)) % 11) + EntryStyle.Offset;
}

double UKGListView::GetItemAnimationTriggerTime_LineWise(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const
{
	const auto& EntryStyle = GetItemAnimationEntryStyle(Configuration, Item);
	int Index = GetLocalItemIndex(Item);
	int NumItemsPerLine = GetLocalNumItemsPerLine(Item);
	int LineIndex = Index / NumItemsPerLine;
	return LineIndex * EntryStyle.Interval + EntryStyle.Offset;
}

double UKGListView::GetItemAnimationTriggerTime_Blueprint(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const
{
	if (MyListView == nullptr)
	{
		return 0;
	}
	if (!OnGetListItemAnimationTriggerTime.IsBound())
	{
		return 0;
	}
	return OnGetListItemAnimationTriggerTime.Execute(GetIndexForItem(Item));
}

const FKGItemAnimationEntryStyle& UKGListView::GetDefaultItemAnimationEntryStyle(const ItemType& Item) const
{
	return DefaultListItemAnimationConfiguration;
}

#pragma endregion

#pragma region 插入删除动画

bool UKGListView::PostInsertItemInternal(ItemType ItemInserted)
{
	if (ItemInsertAnimationName.IsEmpty())
	{
		return false;
	}

	auto CurrentFrameCount = GFrameCounter;
	ExecuteOnItemsRefreshed(FSimpleDelegate::CreateLambda([WeakThis = TWeakObjectPtr<UKGListView>(this), WeakItemInserted = ItemInserted->AsWeak(), CurrentFrameCount]()
	{
		if (GFrameCounter > CurrentFrameCount)
		{
			return;
		}
		auto This = WeakThis.Get();
		if (!This)
		{
			return;
		}
		auto ItemInserted = WeakItemInserted.Pin();
		if (!ItemInserted)
		{
			return;
		}
		if (auto UserWidgetInserted = Cast<UKGUserWidget>(This->UserWidgetFromItem(ItemInserted)))
		{
			if (auto Animation = FindAnimation(UserWidgetInserted, This->ItemInsertAnimationName))
			{
				if (!UserWidgetInserted->ApplyWidgetAnimationStyle(Animation, EKGItemAnimationState::Preparing))
				{
					UE_LOG(LogKGUI, Warning, TEXT("Can not find item animation '%s' 's style data in generated class!"), *This->ItemInsertAnimationName.Name);
				}
				UserWidgetInserted->PlayAnimation(Animation);
			}
		}
	}));
	return true;  // 需要播放动画
}

bool UKGListView::TryPlayRemovingAnimationInternal(ItemType ItemToBeRemoved)
{
	auto UserWidgetToBeRemoved = Cast<UKGUserWidget>(UserWidgetFromItem(ItemToBeRemoved));
	if (UserWidgetToBeRemoved != nullptr)
	{
		check(!RemovingItemEntries.Contains(UserWidgetToBeRemoved));
		RemovingItemEntries.Add(UserWidgetToBeRemoved);
	}
	TWeakObjectPtr Widget = MakeWeakObjectPtr(this);
	auto OnFinishedOrInterrupted = 
	[
		Widget,
		WeakItemToBeRemoved = ItemToBeRemoved->AsWeak(),
		WeakUserWidgetToBeRemoved = TWeakObjectPtr<UKGUserWidget>(UserWidgetToBeRemoved)
	]()
	{
		if (Widget.IsValid())
		{
			if (WeakItemToBeRemoved.Pin())
			{
				if (auto UserWidgetToBeRemoved = WeakUserWidgetToBeRemoved.Get())
				{
					auto RemovingAnimation = FindAnimation(UserWidgetToBeRemoved, Widget->ItemRemoveAnimationName);
					if (RemovingAnimation != nullptr)
					{
						WeakUserWidgetToBeRemoved.Get()->PlayAnimationToStart(RemovingAnimation);
					}
					Widget->RemovingItemEntries.Remove(WeakUserWidgetToBeRemoved.Get());
				}
				Widget->RemoveItemInternal(WeakItemToBeRemoved.Pin());
			}	
		}
	};
	if (ItemRemoveAnimationName.IsEmpty())
	{
		OnFinishedOrInterrupted();
		return false;  // 可以立即删除
	}
	if (!UserWidgetToBeRemoved)
	{
		OnFinishedOrInterrupted();
		return false;
	}
	auto RemovingAnimation = FindAnimation(UserWidgetToBeRemoved, ItemRemoveAnimationName);
	if (RemovingAnimation == nullptr)
	{
		OnFinishedOrInterrupted();
		return false;
	}
	
	FWidgetAnimationDynamicEvent OnFinished;
	OnFinished.BindRawLambda([OnFinishedOrInterrupted](void*) { OnFinishedOrInterrupted();});
	FWidgetAnimationDynamicEvent OnInterrupted;
	OnInterrupted.BindRawLambda([OnFinishedOrInterrupted](void*) {OnFinishedOrInterrupted();});
	
	auto Time = UserWidgetToBeRemoved->PlayAnimationWithCallbacks(
		RemovingAnimation, RemovingAnimation->GetStartTime(), 1, EUMGSequencePlayMode::Forward, 1, false,
		OnFinished,
		OnInterrupted
	);
	if (Time < 0)
	{
		OnFinishedOrInterrupted();
		return false;
	}
	return true;
}

UKGListView::EItemContentIntersectionResult UKGListView::IsItemContentIntersectedByPosition(ItemType Item, float Position, int* OutLineIndex, int* OutNumLines, int* OutDirection, float* OutFromContent, float* OutToBoundary) const
{
	check(MyListView);
	if (Position < 0 || Position > 1)
	{
		return EItemContentIntersectionResult::OutOfRange;
	}
	auto NumItemsPerLine = GetLocalNumItemsPerLine(Item);
	auto LineIndex = SlateListItems.IndexOfByKey(Item) / NumItemsPerLine;
	auto NumLines = (SlateListItems.Num() % NumItemsPerLine == 0 ? 0 : 1) + SlateListItems.Num() / NumItemsPerLine;

	if (OutLineIndex)
	{
		*OutLineIndex = LineIndex;
	}
	if (OutNumLines)
	{
		*OutNumLines = NumLines;
	}

	auto TableRow = MyListView->WidgetFromItem(Item);
	if (TableRow == nullptr)
	{
		return EItemContentIntersectionResult::UnGenerated;
	}
	auto Padding = GetEntryFinalPadding(Item, TableRow.ToSharedRef());
	auto DesiredSize = TableRow->AsWidget()->GetDesiredSize();

	FTableViewDimensions LowerContentPaddingDimensions(this->Orientation, this->ContentPadding.GetTopLeft());
	FTableViewDimensions UpperContentPaddingDimensions(this->Orientation, this->ContentPadding.Right, this->ContentPadding.Bottom);
	FTableViewDimensions DesiredSizeDimensions(this->Orientation, DesiredSize);
	FTableViewDimensions LowerPaddingDimensions(this->Orientation, Padding.GetTopLeft());
	FTableViewDimensions UpperPaddingDimensions(this->Orientation, Padding.Right, Padding.Bottom);
	if (LineIndex == 0)
	{
		DesiredSizeDimensions.ScrollAxis += LowerContentPaddingDimensions.ScrollAxis;
		LowerPaddingDimensions.ScrollAxis += LowerContentPaddingDimensions.ScrollAxis;
	}
	if (LineIndex == NumLines - 1)
	{
		DesiredSizeDimensions.ScrollAxis += UpperContentPaddingDimensions.ScrollAxis;
		UpperPaddingDimensions.ScrollAxis += UpperContentPaddingDimensions.ScrollAxis;
	}

	auto ContentLowerBounding = LowerPaddingDimensions.ScrollAxis / DesiredSizeDimensions.ScrollAxis;
	if (ContentLowerBounding <= Position)
	{
		auto ContentUpperBounding = 1.0f - UpperPaddingDimensions.ScrollAxis / DesiredSizeDimensions.ScrollAxis;
		if (Position <= ContentUpperBounding)
		{
			// Case 0:
			// |------------------------------------------|---------------------------------|------------------------------------------|
			// |             Lower Padding                |             Content             |              Upper Padding               |
			// |------------------------------------------|---------------------------------|------------------------------------------|
			//                                            | <- Position is in this range -> |
			if (OutDirection)
			{
				*OutDirection = 0;
			}
			return EItemContentIntersectionResult::Intersected;
		}
		else
		{
			// Case 1:
			// |------------------------------------------|---------------------------------|------------------------------------------|
			// |             Lower Padding                |             Content             |              Upper Padding               |
			// |------------------------------------------|---------------------------------|------------------------------------------|
			//                                                                              | <-     Position is in this range      -> |
			//                                                                              |     From Content -> |     To Boundary -> |
			//                                                                                                    |
			//                                                                                                 Position
			if (OutDirection)
			{
				*OutDirection = 1;
			}
			if (OutFromContent)
			{
				*OutFromContent = (Position - ContentUpperBounding) * DesiredSizeDimensions.ScrollAxis;
			}
			if (OutToBoundary)
			{
				*OutToBoundary = (1 - Position) * DesiredSizeDimensions.ScrollAxis;
			}
			return EItemContentIntersectionResult::UnIntersected;
		}
	}
	else
	{
		// Case 2:
		// |------------------------------------------|---------------------------------|------------------------------------------|
		// |             Lower Padding                |             Content             |              Upper Padding               |
		// |------------------------------------------|---------------------------------|------------------------------------------|
		// | <-     Position is in this range      -> |
		// | <- To Boundary    | <- From Content      |
		//                     |
		//                  Position
		if (OutDirection)
		{
			*OutDirection = -1;
		}
		if (OutFromContent)
		{
			*OutFromContent = (Position - ContentLowerBounding) * DesiredSizeDimensions.ScrollAxis;
		}
		if (OutToBoundary)
		{
			*OutToBoundary = (0 - Position) * DesiredSizeDimensions.ScrollAxis;
		}
		return EItemContentIntersectionResult::UnIntersected;
	}
}

FMargin UKGListView::GetEntryFinalPadding(ItemType Item, TSharedRef<ITableRow> TableRow) const
{
	auto ObjectTableRow = StaticCastSharedPtr<IObjectTableRow>(TableRow.ToSharedPtr());
	auto EntryWidget = ObjectTableRow->GetUserWidget();
	if (ensure(EntryWidget))
	{
		return EntryWidget->GetPadding();
	}
	return FMargin();
}

void UKGListView::ProcessScrollingDelegates()
{
	if (MyListView == nullptr)
	{
		return;
	}
	auto FrontEdgeIntersection = GetFrontEdgeIntersectionListItem();
	if (LastFrontEdgeIntersection != FrontEdgeIntersection)
	{
		BP_OnFrontEdgeIntersectionListItemChanged.Broadcast(GetIndexForItem(FrontEdgeIntersection));
		LastFrontEdgeIntersection = FrontEdgeIntersection;
	}
	auto BackEdgeIntersection = GetBackEdgeIntersectionListItem();
	if (LastBackEdgeIntersection != BackEdgeIntersection)
	{
		BP_OnBackEdgeIntersectionListItemChanged.Broadcast(GetIndexForItem(BackEdgeIntersection));
		LastBackEdgeIntersection = BackEdgeIntersection;
	}
	auto bIsFrontEdgeReached = IsFrontEdgeReached();
	if (bLastIsFrontEdgeReached != bIsFrontEdgeReached)
	{
		BP_OnIsFrontEdgeReachedChanged.Broadcast(bIsFrontEdgeReached);
		bLastIsFrontEdgeReached = bIsFrontEdgeReached;
	}
	auto bIsBackEdgeReached = IsBackEdgeReached();
	if (bLastIsBackEdgeReached != bIsBackEdgeReached)
	{
		BP_OnIsBackEdgeReachedChanged.Broadcast(bIsBackEdgeReached);
		bLastIsBackEdgeReached = bIsBackEdgeReached;
	}
}

UKGListView::ItemType UKGListView::GetFrontEdgeIntersectionListItem() const
{
	return GetEdgeIntersectionListItem<ESide::Front>();
}

UKGListView::ItemType UKGListView::GetBackEdgeIntersectionListItem() const
{
	return GetEdgeIntersectionListItem<ESide::Back>();
}

UKGListView::ItemType UKGListView::GetFrontEdgeApproximateListItem() const
{
	return GetEdgeApproximateListItem<ESide::Front>();
}

UKGListView::ItemType UKGListView::GetBackEdgeApproximateListItem() const
{
	return GetEdgeApproximateListItem<ESide::Back>();
}

int UKGListView::GetFrontEdgeIntersectionListItemIndex() const
{
	return GetIndexForItem(GetFrontEdgeIntersectionListItem());
}

int UKGListView::GetBackEdgeIntersectionListItemIndex() const
{
	return GetIndexForItem(GetBackEdgeIntersectionListItem());
}

int UKGListView::GetFrontEdgeApproximateListItemIndex() const
{
	return GetIndexForItem(GetFrontEdgeApproximateListItem());
}

int UKGListView::GetBackEdgeApproximateListItemIndex() const
{
	return GetIndexForItem(GetBackEdgeApproximateListItem());
}

bool UKGListView::IsFrontEdgeReached() const
{
	if (MyListView == nullptr)
	{
		return false;
	}
	return MyListView->IsFrontEdgeReached(EdgeReachLengthThreshold);
}

bool UKGListView::IsBackEdgeReached() const
{
	if (MyListView == nullptr)
	{
		return false;
	}
	return MyListView->IsBackEdgeReached(EdgeReachLengthThreshold);;
}

float UKGListView::GetOverscroll() const
{
	if (MyListView == nullptr)
	{
		return 0;
	}
	return MyListView->GetOverscroll();
}

#pragma endregion

#pragma region 延迟事件用以解决子项延迟刷新的问题

void UKGListView::ExecuteOnItemsRefreshed(FSimpleDelegate&& Action)
{
	ActionsOnItemsRefreshed.Add(Action);
}

void UKGListView::FlushActionsOnItemsRefreshed()
{
	for (auto& Action : ActionsOnItemsRefreshed)
	{
		Action.ExecuteIfBound();
	}
	ActionsOnItemsRefreshed.Empty(4);
}

#pragma endregion

#pragma region 强制刷新

void UKGListView::RequestRefreshSynchronous()
{
	RequestRefresh();

	if (MyListView == nullptr)
	{
		return;
	}
	MyListView->Invalidate(EInvalidateWidgetReason::LayoutAndVolatility);
	MyListView->SlatePrepass();
	MyListView->RefreshSynchronous();
}

UUserWidget* UKGListView::GetOrCreateEntryWidgetFromItem(int Index)
{
	if (!MyListView.IsValid())
	{
		return nullptr;
	}
	auto Row = MyListView->GetOrCreateWidgetForItem(Index);
	auto ObjectRow = StaticCastSharedPtr<SKGObjectTableRow<ItemType>>(Row);
	if (!ObjectRow.IsValid())
	{
		return nullptr;
	}
	return ObjectRow->GetWidgetObject();
}

#pragma endregion

#pragma region 异形样式（提供区别于IrregularListView的简单的异形列表方案）

void UKGListView::RaiseOnModifyEntry(const FGeometry& Geometry, TSharedRef<SObjectTableRow<ItemType>> Entry)
{
	if (ShapeStyle != nullptr)
	{
		ShapeStyle->RaiseOnModifyEntry(Geometry, StaticCastSharedRef<SKGObjectTableRow<ItemType>>(Entry));
	}
}

void UKGListView::MarkShapeAsDirty()
{
	if (!MyListView.IsValid() || ShapeStyle == nullptr)
	{
		return;
	}
	MyListView->ForEachGeneratedItems(
		[](ItemType Item, TSharedRef<ITableRow> TableRow)
		{
			StaticCastSharedRef<SKGObjectTableRow<ItemType>>(TableRow)->MarkShapeAsDirty();
		}
	);
}

#pragma endregion

#pragma region 列表背景（充当字面意义的背景，或者充当描述列表热区）

void UKGListView::RebuildBackground()
{
	if (BackgroundClass)
	{
		BackgroundInstance = CreateWidget(this, BackgroundClass);
	}
	else
	{
		BackgroundInstance = nullptr;
	}
	check(MyListView.IsValid());
	SKGListView<ItemType>::FOnGenerateScrollHint OnGenerateScrollHint;
	if (ScrollHintClassBefore.Get() != nullptr || ScrollHintClassAfter.Get() != nullptr)
	{
		OnGenerateScrollHint = SKGListView<ItemType>::FOnGenerateScrollHint::CreateUObject(this, &UKGListView::HandleOnGenerateScrollHintInternal);
	}
	MyListView->ConstructExtra(BackgroundInstance ? BackgroundInstance->TakeWidget().ToSharedPtr() : nullptr, MoveTemp(OnGenerateScrollHint), ScrollHintScrollAxisOffset, ScrollHintLineAxisPercentOffset);
}

#pragma endregion

#pragma region 可滚动箭头

TSharedPtr<SWidget> UKGListView::HandleOnGenerateScrollHintInternal(EKGListViewScrollHintType ScrollHintType)
{
	switch (ScrollHintType)
	{
	case EKGListViewScrollHintType::Before:
		if (!ScrollHintBefore && ScrollHintClassBefore)
		{
			ScrollHintBefore = CreateWidget(this, ScrollHintClassBefore);
			BP_OnScrollHintGenerated.Broadcast(ScrollHintType, ScrollHintBefore);
		}
		return ScrollHintBefore ? ScrollHintBefore->TakeWidget().ToSharedPtr() : nullptr;
	case EKGListViewScrollHintType::After:
		if (!ScrollHintAfter && ScrollHintClassAfter)
		{
			ScrollHintAfter = CreateWidget(this, ScrollHintClassAfter);
			BP_OnScrollHintGenerated.Broadcast(ScrollHintType, ScrollHintAfter);
		}
		return ScrollHintAfter ? ScrollHintAfter->TakeWidget().ToSharedPtr() : nullptr;
	}
	return nullptr;
}

#pragma endregion

#undef LOCTEXT_NAMESPACE
