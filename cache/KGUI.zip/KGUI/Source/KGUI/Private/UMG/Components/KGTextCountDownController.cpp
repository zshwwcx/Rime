#include "UMG/Components/KGTextCountDownController.h"

#include "Manager/KGBasicManager.h"
#include "Misc/KGTime.h"
#include "Core/Common.h"
#include "Framework/Application/SlateApplication.h"

FKGTextCountDownController::FKGTextCountDownController(const UObject* InTarget)
	: Target(InTarget)
{
}

FKGTextCountDownController::~FKGTextCountDownController()
{
	UnregisterPreTick();
}

void FKGTextCountDownController::SetCountDownTimeFormat(const FString& Format)
{
	SCOPED_NAMED_EVENT_TEXT("TextBlockCountDown::SetCountDownTimeFormat", FColor::Magenta);
	CountDownTimeFormat = FTimeFormatCompiledData::Compile(Format);
	UpdateMergedSmallestUnitIndex();
}

void FKGTextCountDownController::SetCountDownTimeFormatByCondition(
	double LowerBoundSeconds, EKGCountDownConditionIntervalType LowerIntervalType,
	double UpperBoundSeconds, EKGCountDownConditionIntervalType UpperIntervalType,
	const FString& Format
)
{
	SCOPED_NAMED_EVENT_TEXT("TextBlockCountDown::SetCountDownTimeFormatByFirstNonzeroUnit", FColor::Magenta);
	FCountDownConditionalInfo CountDownConditionalInfo;
	CountDownConditionalInfo.LowerBoundSeconds = LowerBoundSeconds;
	CountDownConditionalInfo.LowerIntervalType = LowerIntervalType;
	CountDownConditionalInfo.UpperBoundSeconds = UpperBoundSeconds;
	CountDownConditionalInfo.UpperIntervalType = UpperIntervalType;
	CountDownConditionalTimeFormats.Add(
		TPair<FCountDownConditionalInfo, TSharedPtr<FTimeFormatCompiledData>>(
			CountDownConditionalInfo,
			FTimeFormatCompiledData::Compile(Format)
		)
	);
	//CountDownConditionalTimeFormats.StableSort([](const auto& A, const auto& B)
	//{
	//	return A.Key.LowerBoundSeconds > B.Key.LowerBoundSeconds;
	//});
	UpdateMergedSmallestUnitIndex();
}

void FKGTextCountDownController::SetCountDownTimeFormatByFirstNonzeroUnit(FName FirstNonzeroUnitName, const FString& Format)
{
	auto Found = CountDownConditionalInfos.Find(FirstNonzeroUnitName);
	if (!Found)
	{
		UE_LOG(LogKGUI, Error, TEXT("Set count down time format with an unknown unit name: %s!"), *FirstNonzeroUnitName.ToString());
		return;
	}
	SetCountDownTimeFormatByCondition(Found->LowerBoundSeconds, Found->LowerIntervalType, Found->UpperBoundSeconds, Found->UpperIntervalType, Format);
}

void FKGTextCountDownController::ClearCountDownTimeFormats()
{
	CountDownTimeFormat.Reset();
	CountDownConditionalTimeFormats.Empty();
	UpdateMergedSmallestUnitIndex();
}

void FKGTextCountDownController::PlayCountDown(double FromSeconds, double ToSeconds)
{
	if (bIsCountDownPlaying)
	{
		StopCountDown();
	}
	CountDownStartSystemTime = GetSystemTimeFixedInSameFrame();
	CountDownStartGameMilliseconds = GetGameMillisecondsFixedInSameFrame();
	CountDownFromSeconds = FromSeconds;
	CountDownToSeconds = ToSeconds;
	bIsCountDownPlaying = true;
	if (CountDownTimeFormat == nullptr)
	{
		auto StrongTarget = Target.Get();
		UE_LOG(LogKGUI, Error, TEXT("Text block '%s' 's count down time format is cleared."), StrongTarget  ? *StrongTarget->GetPathName() : TEXT("None"));
	}
	UpdateCountDownCurrentSeconds(CountDownFromSeconds, true);
	RegisterPreTick();
}

void FKGTextCountDownController::StopCountDown()
{
	if (!bIsCountDownPlaying)
	{
		return;
	}
	UnregisterPreTick();
	bIsCountDownPlaying = false;
}

int FKGTextCountDownController::GetGameMilliseconds()
{
	auto StrongTarget = Target.Get();
	if (!StrongTarget)
	{
		return -1;
	}
	auto World = StrongTarget->GetWorld();
	if (!World)
	{
		return -1;
	}
	auto TimeManager = Cast<UKGTime>(UKGBasicManager::GetManagerByType(World, EManagerType::EMT_Time));
	if (!TimeManager)
	{
		return -1;
	}
	return TimeManager->GetUTCTimeOfServer();
}

FDateTime FKGTextCountDownController::GetSystemTimeFixedInSameFrame()
{
	static FDateTime SystemTimeThisFrame;
	static int SystemTimeCacheFrameCount = -1;
	if (SystemTimeCacheFrameCount != GFrameCounter)
	{
		SystemTimeThisFrame = FDateTime::Now();
		SystemTimeCacheFrameCount = GFrameCounter;
	}
	return SystemTimeThisFrame;
}

int FKGTextCountDownController::GetGameMillisecondsFixedInSameFrame()
{
	static int64 GameMillisecondsThisFrame;
	static int GameMillisecondsCacheFrameCount = -1;
	if (GameMillisecondsCacheFrameCount != GFrameCounter)
	{
		GameMillisecondsThisFrame = GetGameMilliseconds();
		GameMillisecondsCacheFrameCount = GFrameCounter;
	}
	return GameMillisecondsThisFrame;
}

FName FKGTextCountDownController::UnitName_Day(TEXT("d"));
FName FKGTextCountDownController::UnitName_Hour(TEXT("H"));
FName FKGTextCountDownController::UnitName_Minute(TEXT("M"));
FName FKGTextCountDownController::UnitName_Second(TEXT("S"));
FName FKGTextCountDownController::UnitName_Millisecond(TEXT("f"));

double FKGTextCountDownController::SecondCount_Day = 60 * 60 * 24;
double FKGTextCountDownController::SecondCount_Hour = 60 * 60;
double FKGTextCountDownController::SecondCount_Minute = 60;
double FKGTextCountDownController::SecondCount_Second = 1;
double FKGTextCountDownController::MillisecondCount_Second = 1000;
double FKGTextCountDownController::SecondCount_Millisecond = 1.0 / MillisecondCount_Second;

TArray<TPair<FName, double>> FKGTextCountDownController::UnitSecondCounts =
{
	// 这里需要按照从大到小顺序
	{UnitName_Day, SecondCount_Day},
	{UnitName_Hour, SecondCount_Hour},
	{UnitName_Minute, SecondCount_Minute},
	{UnitName_Second, SecondCount_Second},
	{UnitName_Millisecond, SecondCount_Millisecond},
};

TMap<FName, FKGTextCountDownController::FCountDownConditionalInfo> FKGTextCountDownController::CountDownConditionalInfos
{
	{UnitName_Day,         FCountDownConditionalInfo(
		SecondCount_Day,         EKGCountDownConditionIntervalType::Closed,
		DBL_MAX,                 EKGCountDownConditionIntervalType::Unbounded)},
	{UnitName_Hour,        FCountDownConditionalInfo(
		SecondCount_Hour,        EKGCountDownConditionIntervalType::Closed,
		SecondCount_Day,         EKGCountDownConditionIntervalType::Open)},
	{UnitName_Minute,      FCountDownConditionalInfo(
		SecondCount_Minute,      EKGCountDownConditionIntervalType::Closed,
		SecondCount_Hour,        EKGCountDownConditionIntervalType::Open)},
	{UnitName_Second,      FCountDownConditionalInfo(
		SecondCount_Second,      EKGCountDownConditionIntervalType::Closed,
		SecondCount_Minute,      EKGCountDownConditionIntervalType::Open)},
	{UnitName_Millisecond, FCountDownConditionalInfo(
		SecondCount_Millisecond, EKGCountDownConditionIntervalType::Unbounded, 
		SecondCount_Second,      EKGCountDownConditionIntervalType::Open)},
};

TArray<FKGTextCountDownController::FTimeUnitInfo> FKGTextCountDownController::FTimeFormatCompiledData::TimeUnitInfos
{
	FTimeUnitInfo(TEXT('d'), SecondCount_Day, 0),
	FTimeUnitInfo(TEXT('H'), SecondCount_Hour, 2),
	FTimeUnitInfo(TEXT('M'), SecondCount_Minute, 2),
	FTimeUnitInfo(TEXT('S'), SecondCount_Second, 2),
	FTimeUnitInfo(TEXT('f'), SecondCount_Millisecond, 3),
};
void FKGTextCountDownController::FTimeFormatLiteralToken::AppendTo(FStringBuilderBase& StringBuilder, const FTimeData& TimeData) const
{
	StringBuilder.Append(this->Literal);
}

static constexpr uint64 Pow10[21] = {
	1ULL,  // 1位
	10ULL,
	100ULL,
	1000ULL,
	10000ULL,
	100000ULL,
	1000000ULL,
	10000000ULL,
	100000000ULL,
	1000000000ULL,
	10000000000ULL,
	100000000000ULL,
	1000000000000ULL,
	10000000000000ULL,
	100000000000000ULL,
	1000000000000000ULL,
	10000000000000000ULL,
	100000000000000000ULL,
	1000000000000000000ULL,
	10000000000000000000ULL,  // 20位
};

FORCEINLINE int32 CountDigits(uint64 Value)
{
	if (Value == 0)
	{
		return 1;
	}
	int32 Left = 0, Right = 20;
	while (Left < Right)
	{
		const int32 Middle = (Left + Right) >> 1;
		if (Value < Pow10[Middle])
		{
			Right = Middle;
		}
		else
		{
			Left = Middle + 1;
		}
	}
	return Left;
}

void FKGTextCountDownController::FTimeFormatEscapeToken::AppendTo(FStringBuilderBase& StringBuilder, const FTimeData& TimeData) const
{
	auto FoundUnitValue = TimeData.UnitValues.Find(this->UnitIndex);
	if (!ensure(FoundUnitValue))
	{
		return;
	}
	auto UnitValue = *FoundUnitValue;
	auto AbsoluteUnitValue = FMath::Abs(UnitValue);
	if (!ensure(UnitValue >= 0))
	{
		StringBuilder.AppendChar('-');
	}
	if (bZeroWithPad)
	{
		auto DigitNum = CountDigits((uint64)AbsoluteUnitValue);
		const auto& TimeUnitInfo = FTimeFormatCompiledData::TimeUnitInfos[this->UnitIndex];
		int ZeroCount = TimeUnitInfo.PadLength - DigitNum;
		if (ZeroCount > 0)
		{
			while (ZeroCount --)
			{
				StringBuilder.AppendChar('0');
			}
		}
	}
	StringBuilder.Appendf(TEXT("%lld"), AbsoluteUnitValue);
}

TSharedPtr<FKGTextCountDownController::FTimeFormatCompiledData> FKGTextCountDownController::FTimeFormatCompiledData::Compile(const FString& Format)
{
	auto CompiledData = MakeShared<FTimeFormatCompiledData>();
	auto FormatStringLength = Format.Len();
	int Current = 0;
	TSet<int> UnitIndexes;
	while (Current < FormatStringLength)
	{
		TSharedPtr<FTimeFormatToken> Token = nullptr;
		if ((Token = ParseLiteral(Format, Current)) != nullptr)
		{
		}
		else if ((Token = ParseEscape(Format, Current)) != nullptr)
		{
		}
		if (!ensure(Token))
		{
			break;
		}
		CompiledData->Tokens.Add(Token);
		if (auto EscapeToken = Token->AsEscapeToken())
		{
			UnitIndexes.Add(EscapeToken->GetUnitIndex());
		}
	}
	CompiledData->SortedUnitIndexes = UnitIndexes.Array();
	CompiledData->SortedUnitIndexes.Sort();
	if (Current < FormatStringLength - 1)
	{
		UE_LOG(LogKGUI, Error, TEXT("The time format '%s' ends with unexpected content from index %d!"), *Format, Current);
	}
	for (int Index = 0; Index < CompiledData->SortedUnitIndexes.Num() - 1; Index++)
	{
		if (CompiledData->SortedUnitIndexes[Index + 1] != CompiledData->SortedUnitIndexes[Index] + 1)
		{
			UE_LOG(LogKGUI, Error, TEXT("Format '%s' unit elements are not consecutive!"), *Format);
			break;
		}
	}
	return CompiledData;
}

FString FKGTextCountDownController::FTimeFormatCompiledData::Generate(double Seconds)
{
	FTimeData TimeData;
	for (int Index = 0; Index < SortedUnitIndexes.Num(); Index++)
	{
		auto UnitIndex = SortedUnitIndexes[Index];
		check(FTimeFormatCompiledData::TimeUnitInfos.IsValidIndex(UnitIndex));
		const auto& TimeUnitInfo = FTimeFormatCompiledData::TimeUnitInfos[UnitIndex];
		auto Current = FMath::FloorToInt64(Seconds / TimeUnitInfo.SecondCount);
		TimeData.UnitValues.Add(UnitIndex, Current);
		Seconds -= Current * TimeUnitInfo.SecondCount;
	}
	static TStringBuilder<128> StringBuilder;
	StringBuilder.Reset();
	for (const auto& Token : Tokens)
	{
		check(Token != nullptr);
		Token->AppendTo(StringBuilder, TimeData);
	}
	return StringBuilder.ToString();
}

TSharedPtr<FKGTextCountDownController::FTimeFormatToken> FKGTextCountDownController::FTimeFormatCompiledData::ParseLiteral(const FString& Format, int& Index)
{
	auto Start = Index;
	if (Index >= Format.Len()) { Index = Start; return nullptr; }
	while (Index < Format.Len() && Format[Index] != TEXT('%'))
	{
		Index++;
	}
	if (Start == Index)
	{
		Index = Start; return nullptr;
	}
	return MakeShared<FTimeFormatLiteralToken>(Format.Mid(Start, Index - Start));
}

TSharedPtr<FKGTextCountDownController::FTimeFormatToken> FKGTextCountDownController::FTimeFormatCompiledData::ParseEscape(const FString& Format, int& Index)
{
	auto Start = Index;
	if (Index >= Format.Len()) { Index = Start; return nullptr; }
	if (Format[Index] != TEXT('%'))
	{
		Index = Start; return nullptr;
	}
	Index++; if (Index >= Format.Len()) { Index = Start; return nullptr; }
	if (Format[Index] == TEXT('%'))
	{
		return MakeShared<FTimeFormatLiteralToken>(TEXT("%"));
	}
	bool bInZeroWithPad = true;
	if (Format[Index] == TEXT('-'))
	{
		bInZeroWithPad = false;
		Index++; if (Index >= Format.Len()) { Index = Start; return nullptr; }
	}
	auto MaybeEscapeChar = Format[Index];
	auto TimeUnitInfoIndex = TimeUnitInfos.IndexOfByPredicate([MaybeEscapeChar](const auto& TimeUnitInfo) { return TimeUnitInfo.EscapeChar == MaybeEscapeChar; });
	if (TimeUnitInfoIndex == INDEX_NONE)
	{
		Index = Start; return nullptr;
	}
	Index++;
	return MakeShared<FTimeFormatEscapeToken>(TimeUnitInfoIndex, bInZeroWithPad);
}

void FKGTextCountDownController::RegisterPreTick()
{
	if (ensure(!PreTickDelegateHandle.IsValid()))
	{
		if (ensure(FSlateApplication::IsInitialized()))
		{
			PreTickDelegateHandle = FSlateApplication::Get().OnPreTick().AddSP(this, &FKGTextCountDownController::OnPreTick);
		}
	}
}

void FKGTextCountDownController::UnregisterPreTick()
{
	if (!PreTickDelegateHandle.IsValid())
	{
		return;
	}
	if (ensure(FSlateApplication::IsInitialized()))
	{
		FSlateApplication::Get().OnPreTick().Remove(PreTickDelegateHandle);
	}
	PreTickDelegateHandle.Reset();
}

void FKGTextCountDownController::OnPreTick(float InDeltaTime)
{
	SCOPED_NAMED_EVENT_TEXT("TextBlockCountDown::OnPreTickCountDown", FColor::Orange);
	int Sign = (CountDownToSeconds > CountDownFromSeconds ? 1 : -1);
	float NewSeconds;
	
	switch (TimeType)
	{
	case EKGTextCountDownTimeType::Engine:
		NewSeconds = CountDownCurrentSeconds + InDeltaTime * Sign;
		break;
	case EKGTextCountDownTimeType::Game:
		if (CountDownStartGameMilliseconds >= 0)
		{
			auto NowGameServerMilliseconds = GetGameMillisecondsFixedInSameFrame();
			if (NowGameServerMilliseconds >= 0)
			{
				NewSeconds = CountDownFromSeconds + (NowGameServerMilliseconds - CountDownStartGameMilliseconds) * SecondCount_Millisecond * Sign;
				break;
			}
		}
	case EKGTextCountDownTimeType::System:
		{
			auto NowTime = GetSystemTimeFixedInSameFrame();
			NewSeconds = CountDownFromSeconds + (NowTime - CountDownStartSystemTime).GetTotalSeconds() * Sign;
		}
		break;
	default:
		check(false);
		return;
	}
	if (NewSeconds * Sign > CountDownToSeconds * Sign)
	{
		StopCountDown();
		(void) OnCountDownFinished.ExecuteIfBound();
	}
	UpdateCountDownCurrentSeconds(NewSeconds, false);
}

double FKGTextCountDownController::NormalizeToUnit(double Seconds, int UnitIndex) const
{
	check(UnitSecondCounts.IsValidIndex(UnitIndex));
	auto SmallestUnitSecondCount = UnitSecondCounts[UnitIndex].Value;
	int64 TotalUnitValue = 0;
	if (CountDownFromSeconds > CountDownToSeconds)
	{
		// https://docs.corp.kuaishou.com/k/home/VAzfgLyPGez8/fcACXWalzIUjGRyvPEFD50Slz#section=h.4uho1u6a7pfl
		TotalUnitValue = FMath::CeilToInt64(Seconds / SmallestUnitSecondCount);
	}
	else
	{
		TotalUnitValue = FMath::FloorToInt64(Seconds / SmallestUnitSecondCount);
	}
	return TotalUnitValue * SmallestUnitSecondCount;
}

void FKGTextCountDownController::UpdateCountDownCurrentSeconds(double CurrentSeconds, bool bForce)
{
	CountDownCurrentSeconds = CurrentSeconds;
	CountDownCurrentSeconds = FMath::Clamp(
		CountDownCurrentSeconds,
		FMath::Min(CountDownFromSeconds, CountDownToSeconds),
		FMath::Max(CountDownFromSeconds, CountDownToSeconds)
	);
	auto CurrentDisplaySeconds = CountDownCurrentSeconds;
	if (MergedSmallestUnitIndex != INDEX_NONE)
	{
		CurrentDisplaySeconds = NormalizeToUnit(CurrentDisplaySeconds, MergedSmallestUnitIndex);
	}
	auto CurrentDisplayMilliseconds = FMath::FloorToInt64(CurrentDisplaySeconds * MillisecondCount_Second);
	if (!bForce && LastDisplayMilliseconds == CurrentDisplayMilliseconds)
	{
		return;
	}
	LastDisplayMilliseconds = CurrentDisplayMilliseconds;
	UpdateCountDownText(LastDisplayMilliseconds / MillisecondCount_Second);
}

void FKGTextCountDownController::UpdateCountDownText(double DisplaySeconds)
{
	SCOPED_NAMED_EVENT_TEXT("TextBlockCountDown::UpdateCountDownText", FColor::Magenta);
	TSharedPtr<FTimeFormatCompiledData> FinalCountDownTimeFormat = CountDownTimeFormat;
	if (!CountDownConditionalTimeFormats.IsEmpty())
	{
		for (const auto& Pair : CountDownConditionalTimeFormats)
		{
			const auto& ConditionalInfo = Pair.Key;
			const auto& Format = Pair.Value;
			{
				bool bOK;
				switch (ConditionalInfo.LowerIntervalType)
				{
				case EKGCountDownConditionIntervalType::Unbounded:
					bOK = true;
					break;
				case EKGCountDownConditionIntervalType::Open:
					bOK = DisplaySeconds > ConditionalInfo.LowerBoundSeconds;
					break;
				case EKGCountDownConditionIntervalType::Closed:
					bOK = DisplaySeconds >= ConditionalInfo.LowerBoundSeconds;
					break;
				default:
					bOK = false;
				}
				if (!bOK)
				{
					continue;
				}
			}
			{
				bool bOK;
				switch (ConditionalInfo.UpperIntervalType)
				{
				case EKGCountDownConditionIntervalType::Unbounded:
					bOK = true;
					break;
				case EKGCountDownConditionIntervalType::Open:
					bOK = DisplaySeconds < ConditionalInfo.UpperBoundSeconds;
					break;
				case EKGCountDownConditionIntervalType::Closed:
					bOK = DisplaySeconds <= ConditionalInfo.UpperBoundSeconds;
					break;
				default:
					bOK = false;
				}
				if (!bOK)
				{
					continue;
				}
			}
			FinalCountDownTimeFormat = Format;
			break;
		}
	}
	if (FinalCountDownTimeFormat.IsValid())
	{
		if (bMinimumUnitCeilingPerFormat)
		{
			// 对每个格式的最后一位取整，否则只对所有格式配置的最小单位向上取整。
			auto SmallestUnitIndex = FinalCountDownTimeFormat->GetLastUnitIndex();
			if (SmallestUnitIndex != INDEX_NONE)
			{
				DisplaySeconds = NormalizeToUnit(DisplaySeconds, SmallestUnitIndex);
			}
		}
		OnTextChanged.ExecuteIfBound(FText::FromString(FinalCountDownTimeFormat->Generate(DisplaySeconds)));
	}
}

void FKGTextCountDownController::UpdateMergedSmallestUnitIndex()
{
	int SmallestUnitIndex = INDEX_NONE;
	if (CountDownTimeFormat != nullptr)
	{
		SmallestUnitIndex = FMath::Max(CountDownTimeFormat->GetLastUnitIndex(), SmallestUnitIndex);
	}
	for (const auto& Pair : CountDownConditionalTimeFormats)
	{
		if (Pair.Value == nullptr)
		{
			continue;
		}
		SmallestUnitIndex = FMath::Max(Pair.Value->GetLastUnitIndex(), SmallestUnitIndex);

		switch (Pair.Key.LowerIntervalType)
		{
		case EKGCountDownConditionIntervalType::Unbounded:
			SmallestUnitIndex = FMath::Max(UnitSecondCounts.Num() - 1, SmallestUnitIndex);
			break;
		case EKGCountDownConditionIntervalType::Closed:
		case EKGCountDownConditionIntervalType::Open:
			for (int Index = 0; Index < UnitSecondCounts.Num(); Index++)
			{
				if (UnitSecondCounts[Index].Get<1>() <= Pair.Key.LowerBoundSeconds)
				{
					SmallestUnitIndex = FMath::Max(Index, SmallestUnitIndex);
					break;
				}
			}
			break;
		}
	}
	MergedSmallestUnitIndex = SmallestUnitIndex;
}