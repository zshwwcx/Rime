#include "UMG/Components/KGTileView.h"

#include "Slate/Views/SKGTileView.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(KGTileView)

UKGTileView::UKGTileView(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bIsVariable = true;
}

void UKGTileView::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);

	MyTileView.Reset();
}

void UKGTileView::SetEntryHeight(float NewHeight)
{
	EntryHeight = NewHeight;
	if (MyTileView.IsValid())
	{
		MyTileView->SetItemHeight(GetTotalEntryHeight());
	}
}

void UKGTileView::SetEntryWidth(float NewWidth)
{
	EntryWidth = NewWidth;
	if (MyTileView.IsValid())
	{
		MyTileView->SetItemWidth(GetTotalEntryWidth());
	}
}

int UKGTileView::GetNumItemsPerLine() const
{
	if (!MyTileView.IsValid())
	{
		return INDEX_NONE;
	}
	return MyTileView->GetNumItemsPerLine();
}

bool UKGTileView::TryGetItemCoordinatesFromWidget(UUserWidget* ItemWidget, FIntPoint& OutCoordinates)
{
	if (!ItemWidget)
	{
		return false;
	}
	if (!MyTileView.IsValid())
	{
		return false;
	}
	auto CachedWidget = ItemWidget->GetCachedWidget();
	if (!CachedWidget.IsValid())
	{
		return false;
	}
	auto Index = GetIndexFromWidget(ItemWidget);
	if (Index == INDEX_NONE)
	{
		return false;
	}
	auto NumItemsPerLine = GetNumItemsPerLine();
	OutCoordinates.X = (int)(Index / NumItemsPerLine);
	OutCoordinates.Y = Index % NumItemsPerLine;
	return true;
}

bool UKGTileView::IsAligned() const
{
	return TileAlignment == EListItemAlignment::LeftAligned
		|| TileAlignment == EListItemAlignment::RightAligned
		|| TileAlignment == EListItemAlignment::CenterAligned;
}

float UKGTileView::GetTotalEntryHeight() const
{
	if (IsAligned() && !bEntrySizeIncludesEntrySpacing)
	{
		return EntryHeight + GetVerticalEntrySpacing();
	}
	else
	{
		return EntryHeight + GetVerticalEntrySpacing() * 0.5;
	}
}

float UKGTileView::GetTotalEntryWidth() const
{
	if (IsAligned() && !bEntrySizeIncludesEntrySpacing)
	{
		return EntryWidth + GetHorizontalEntrySpacing();
	}
	else
	{
		return EntryWidth + GetHorizontalEntrySpacing() * 0.5;
	}
}

TSharedRef<STableViewBase> UKGTileView::RebuildListWidget()
{
	auto TileView = ConstructTileView<SKGTileView>();
	TileView->SetContentPadding(this->GetContentPadding());
	return TileView;
}

FMargin UKGTileView::GetDesiredEntryPadding(ItemType Item) const
{
	return FMargin(GetHorizontalEntrySpacing() * 0.5f, GetVerticalEntrySpacing() * 0.5f);
}
