#include "UMG/Components/KGTreeView.h"

#include "Core/Common.h"
#include "Editor/WidgetCompilerLog.h"
#include "Slate/Views/SKGTreeView.h"
#include "Styling/DefaultStyleCache.h"
#include "UMG/Blueprint/KGTemporarySprite.h"
#include "UMG/Blueprint/KGTreeTileLayoutState.h"
#include "UMG/Blueprint/KGUserWidget.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(KGTreeView)

UKGTreeView::UKGTreeView(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	WidgetStyle = UE::Slate::Private::FDefaultStyleCache::GetRuntime().GetTreeViewStyle();
	TileLayoutBackground.DrawAs = ESlateBrushDrawType::NoDrawType;

#if WITH_EDITOR 
	if (IsEditorWidget())
	{
		WidgetStyle = UE::Slate::Private::FDefaultStyleCache::GetEditor().GetTreeViewStyle();
		PostEditChange();
	}
#endif // WITH_EDITOR
}

TSharedRef<STableViewBase> UKGTreeView::RebuildListWidget()
{
	InitializeTileLayoutBackgrounds();
	auto TreeView = ConstructTreeView<SKGTreeView>();
	TreeView->SetContentPadding(GetContentPadding());
	if (MyTreeView.IsValid())
	{
		UE_LOG(LogKGUI, Log, TEXT("[BUG#206836] %s 's Slate Tree View is Built."), *this->GetPathName());
	}
	return TreeView;
}

void UKGTreeView::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	if (MyTreeView.IsValid())
	{
		UE_LOG(LogKGUI, Log, TEXT("[BUG#206836] %s 's Slate Tree View is Released."), *this->GetPathName());
	}
	MyTreeView.Reset();
}

void UKGTreeView::SetItemExpansion(const TArray<int>& Path, bool bExpandItem)
{
	if (auto Item = GetItemAt(Path))
	{
		if (MyTreeView.IsValid())
		{
			MyTreeView->SetItemExpansion(Item, bExpandItem);
		}
	}
}

bool UKGTreeView::IsItemExpanded(const TArray<int>& Path)
{
	if (auto Item = GetItemAt(Path))
	{
		if (MyTreeView.IsValid())
		{
			return MyTreeView->IsItemExpanded(Item);
		}
	}
	return false;
}

void UKGTreeView::ExpandAllInternal(ItemType ListItem)
{
	if (ListItem == nullptr)
	{
		return;
	}
	MyTreeView->SetItemExpansion(ListItem, true);
	if (auto TreeItem = FKGTreeItem::UnsafeCast(ListItem))
	{
		(void)RequestGetChildren(TreeItem);  // 这里GetChildren的内容可能还未生成
		for (auto ChildItem : TreeItem->GetChildren())
		{
			ExpandAllInternal(ChildItem);
		}
	}
}

void UKGTreeView::ExpandAll()
{
	if (MyTreeView.IsValid())
	{
		for (ItemType ListItem : GetListItems())
		{
			ExpandAllInternal(ListItem);
		}
	}
}

void UKGTreeView::CollapseAll()
{
	if (MyTreeView.IsValid())
	{
		MyTreeView->ClearExpandedItems();
	}
}

void UKGTreeView::SetSelectedPath(const TArray<int>& Path)
{
	SetSelectedItem(GetItemAt(Path));
}

void UKGTreeView::NavigateToPath(const TArray<int>& Path)
{
	RequestNavigateToItem(GetItemAt(Path));
}

void UKGTreeView::BP_SetTreeItemSelection(const TArray<int>& Path, bool bSelected)
{
	SetItemSelection(GetItemAt(Path), bSelected);
}

bool UKGTreeView::AddItem()
{
	UE_LOG(LogKGUI, Error, TEXT("AddItem is unsupported in TreeView, use AddTreeItem instead!"));
	return false;
}

bool UKGTreeView::InsertItem(int32 Index)
{
	UE_LOG(LogKGUI, Error, TEXT("InsertItem is unsupported in TreeView, use InsertTreeItem instead!"));
	return false;
}

void UKGTreeView::OnInsertingListItem(int32 Index, ItemType Item)
{
	Super::OnInsertingListItem(Index, Item);
	for (int I = Index; I < ListItems.Num(); I++)
	{
		auto Child = FKGTreeItem::UnsafeCast(ListItems[I]);
		Child->SetIndexInParent(Child->GetIndexInParent() + 1);
	}
}

void UKGTreeView::OnListItemRemoved(int32 Index)
{
	Super::OnListItemRemoved(Index);
	for (int I = Index; I < ListItems.Num(); I++)
	{
		auto Child = FKGTreeItem::UnsafeCast(ListItems[I]);
		Child->SetIndexInParent(Child->GetIndexInParent() - 1);
	}
}

bool UKGTreeView::RemoveItem(int32 Index)
{
	UE_LOG(LogKGUI, Error, TEXT("RemoveItem is unsupported in TreeView, use RemoveTreeItem instead!"));
	return false;
}

FString UKGTreeView::ConvertPathToString(const TArray<int>& Path)
{
	TArray<FString> Names;
	Algo::Transform(Path, Names, [](auto Index) { return FString::FormatAsNumber(Index); });
	return FString::Join(Names, TEXT("/"));
}

bool UKGTreeView::AddTreeItem()
{
	return InsertTreeItem({ ListItems.Num() });
}

bool UKGTreeView::InsertTreeItem(const TArray<int>& Path)
{
	if (Path.Num() == 0)
	{
		return false;
	}
	if (Path.Num() == 1)
	{
		TSharedPtr<FKGListItem> NewItem = MakeShared<FKGTreeItem>(this);
		return InsertListItem(Path[0], NewItem);
	}
	TArray<int> ParentPath = TArray<int>(Path.GetData(), Path.Num() - 1);
	auto LocalIndex = Path[Path.Num() - 1];
	auto ParentItem = GetItemAt(ParentPath);
	if (ParentItem == nullptr)
	{
		UE_LOG(LogKGUI, Error, TEXT("InsertTreeItem's input parameter `Path` %s does not include the valid parent item."), *ConvertPathToString(Path));
		return false;
	}
	auto ClampedLocalIndex = FMath::Clamp(LocalIndex, 0, ParentItem->GetChildCount());
	if (ClampedLocalIndex != LocalIndex)
	{
		UE_LOG(LogKGUI, Error, TEXT("InsertTreeItem's input parameter `Path` is %s, which is out of range [0, %d)."), *ConvertPathToString(Path), ParentItem->GetChildCount());
		return false;
	}

	auto NewItem = MakeShared<FKGTreeItem>(this);
	ParentItem->InsertChild(LocalIndex, NewItem);

	RequestRefresh();
	PostInsertItemInternal(NewItem);
	return true;
}

bool UKGTreeView::RemoveTreeItem(const TArray<int>& Path)
{
	if (Path.Num() == 0)
	{
		return false;
	}
	if (Path.Num() == 1)
	{
		return RemoveListItem(Path[0]);
	}
	TArray<int> ParentPath = TArray<int>(Path.GetData(), Path.Num() - 1);
	auto LocalIndex = Path[Path.Num() - 1];
	auto ParentItem = GetItemAt(ParentPath);
	if (ParentItem == nullptr)
	{
		UE_LOG(LogKGUI, Error, TEXT("RemoveTreeItem's input parameter `Path` %s does not include the valid parent item."), *ConvertPathToString(Path));
		return false;
	}
	auto ClampedLocalIndex = FMath::Clamp(LocalIndex, 0, ParentItem->GetChildCount());
	if (ClampedLocalIndex != LocalIndex)
	{
		UE_LOG(LogKGUI, Error, TEXT("RemoveTreeItem's input parameter `Path` is %s, which is out of range [0, %d)."), *ConvertPathToString(Path), ParentItem->GetChildCount());
		return false;
	}

	auto ItemToBeRemoved = ParentItem->GetChildren()[LocalIndex];
	ParentItem->RemoveChild(LocalIndex);

	TryPlayRemovingAnimationInternal(ItemToBeRemoved);
	return false;
}

void UKGTreeView::ScrollTreeItemIntoViewInternal(const TArray<int>& Path, bool bAutoAlignment, float Alignment)
{
	if (auto Item = GetItemAt(Path))
	{
		if (MyTreeView.IsValid())
		{
			if (bAutoAlignment)
			{
				MyTreeView->RequestScrollIntoView(Item, GetOwningUserIndex());
			}
			else
			{
				MyTreeView->RequestScrollIntoView(Item, Alignment, GetOwningUserIndex());
			}
		}
	}
	else
	{
		TArray<FString> PathIndexStrings;
		for (auto Index : Path)
		{
			PathIndexStrings.Add(FString::FromInt(Index));
		}
		FString PathString = FString::Join(PathIndexStrings, TEXT(","));
		UE_LOG(LogKGUI, Error, TEXT("List view (%s) 's ScrollTreeItemIntoView requested an invalid path: [%s]"), *this->GetPathName(), *PathString);
	}
}

void UKGTreeView::BP_ScrollTreeItemIntoView(const TArray<int>& Path, float Alignment)
{
	ScrollTreeItemIntoViewInternal(Path, false, Alignment);
}

void UKGTreeView::BP_ScrollTreeItemIntoViewIfNeeded(const TArray<int>& Path)
{
	ScrollTreeItemIntoViewInternal(Path, true, 0);
}

void UKGTreeView::BP_CancelScrollIntoView()
{
	if (MyTreeView.IsValid())
	{
		MyTreeView->CancelScrollIntoView();
	}
}

TArray<int> UKGTreeView::GetNextLinearizedItemPath(const TArray<int>& CurrentPath)
{
	TArray<int> Result;
	PopulateNextLinearizedItemPath(CurrentPath, Result);
	return Result;
}

bool UKGTreeView::PopulateNextLinearizedItemPath(const TArray<int>& CurrentPath, TArray<int>& NextPath)
{
	NextPath.Empty();
	if (MyTreeView == nullptr)
	{
		return false;
	}
	auto InitialItem = GetItemAt(CurrentPath);
	if (InitialItem == nullptr)
	{
		return false;
	}
	for (auto CurrentItem = InitialItem->GetParent(); CurrentItem != nullptr; CurrentItem = CurrentItem->GetParent())
	{
		if (!MyTreeView->IsItemExpanded(CurrentItem))
		{
			return false;
		}
	}
	// 要么是自己的第一个子节点
	if (MyTreeView->IsItemExpanded(InitialItem))
	{
		if (InitialItem->GetChildCount() != 0)
		{
			NextPath = InitialItem->GetChildAt(0)->GetPath();
			return true;
		}
	}
	// 要么是自己或者祖先节点的第一个弟弟节点
	for (auto CurrentItem = InitialItem; CurrentItem != nullptr; CurrentItem = CurrentItem->GetParent())
	{
		auto ParentItem = CurrentItem->GetParent();
		TArray<TSharedPtr<FKGListItem>> Children;
		if (ParentItem != nullptr)
		{
			Children = ParentItem->GetChildren();
		}
		else
		{
			Children = ListItems;
		}
		int NewIndex = Children.IndexOfByKey(CurrentItem) + 1;
		if (Children.IsValidIndex(NewIndex))
		{
			NextPath = FKGTreeItem::UnsafeCast(Children[NewIndex])->GetPath();
			return true;
		}
	}
	return false;
}

TArray<int> UKGTreeView::GetPreviousLinearizedItemPath(const TArray<int>& CurrentPath)
{
	TArray<int> Result;
	PopulatePreviousLinearizedItemPath(CurrentPath, Result);
	return Result;
}

bool UKGTreeView::PopulatePreviousLinearizedItemPath(const TArray<int>& CurrentPath, TArray<int>& PreviousPath)
{
	PreviousPath.Empty();
	if (MyTreeView == nullptr)
	{
		return false;
	}
	auto InitialItem = GetItemAt(CurrentPath);
	if (InitialItem == nullptr)
	{
		return false;
	}
	for (auto CurrentItem = InitialItem->GetParent(); CurrentItem != nullptr; CurrentItem = CurrentItem->GetParent())
	{
		if (!MyTreeView->IsItemExpanded(CurrentItem))
		{
			return false;
		}
	}
	{
		auto CurrentItem = InitialItem;
		auto ParentItem = CurrentItem->GetParent();
		TArray<TSharedPtr<FKGListItem>> Children;
		if (ParentItem != nullptr)
		{
			Children = ParentItem->GetChildren();
		}
		else
		{
			Children = ListItems;
		}
		int NewIndex = Children.IndexOfByKey(CurrentItem) - 1;
		// 要么是最近的哥哥节点或者其前向遍历的最后一个节点（未展开的）
		if (Children.IsValidIndex(NewIndex))
		{
			auto LastItem = FKGTreeItem::UnsafeCast(Children[NewIndex]);
			while (MyTreeView->IsItemExpanded(LastItem) && LastItem->GetChildCount() > 0)
			{
				LastItem = LastItem->GetChildAt(LastItem->GetChildCount() - 1);
			}
			PreviousPath = LastItem->GetPath();
			return true;
		}
		// 要么是父节点
		if (ParentItem != nullptr)
		{
			PreviousPath = ParentItem->GetPath();
			return true;
		}
	}
	return false;
}

void UKGTreeView::SynchronizeProperties()
{
	UKGListView::SynchronizeProperties();

	if (MyTreeView.IsValid())
	{
		if (this->bTileLayout)
		{
			MyTreeView->SetOnGenerationEnding(SKGTreeView<ItemType>::FOnGenerationEnding::CreateUObject(this, &UKGTreeView::OnGenerationEnding));
			MyTreeView->SetRequestListRefreshOnPanelSizeChanged(true);
		}
	}
}

void UKGTreeView::OnGenerationEnding(const TArray<TObjectPtrWrapTypeOf<ItemType>>& ItemsWithGeneratedWidgets)
{
	TSet<TObjectPtrWrapTypeOf<ItemType>> ItemSet;
	for (auto Item : ItemsWithGeneratedWidgets)
	{
		ItemSet.Add(Item);
	}
	for (auto Item : ItemSet)
	{
		auto TreeTileLayoutItem = FKGTreeTileLayoutItem::UnsafeCast(Item);
		if (TreeTileLayoutItem == nullptr)
		{
			continue;
		}
		for (auto ChildItem : TreeTileLayoutItem->GetTreeItems())
		{
			if (ItemSet.Contains(ChildItem))
			{
				continue;
			}
			MyTreeView->SeeItem(ChildItem, MyTreeView->WidgetFromItem(ChildItem));
		}
	}
}

UKGTreeView::ItemType UKGTreeView::SpawnItem() const
{
	auto Item = MakeShared<FKGTreeItem>(this);
	Item->SetIndexInParent(ListItems.Num());
	return Item;
}

TSharedPtr<FKGTreeItem> UKGTreeView::GetItemAt(const TArray<int>& Path) const
{
	const TArray<ItemType>* Current = &ListItems;
	TSharedPtr<FKGListItem> Found = nullptr;
	for (int K = 0; K < Path.Num(); ++K)
	{
		int32 Index = Path[K];
		if (Current == nullptr || Index < 0 || Index >= Current->Num())
		{
			return nullptr;
		}
		Found = (*Current)[Index];
		if (K == Path.Num() - 1)
		{
			break;
		}
		auto Next = FKGTreeItem::UnsafeCast(Found);
		(void) RequestGetChildren(Next);  // 这里GetChildren的内容可能还未生成
		Current = &Next->GetChildren();
	}
	return FKGTreeItem::UnsafeCast(Found);
}

void UKGTreeView::OnItemClickedInternal(ItemType ListItem)
{
	Super::OnItemClickedInternal(ListItem);
	if (auto TreeItem = FKGTreeItem::UnsafeCast(ListItem))
	{
		BP_OnTreeItemClicked.Broadcast(TreeItem->GetPath());
	}
	if (ensure(MyTreeView.IsValid()))
	{
		TSharedPtr<ITableRow> RowWidget = MyTreeView->WidgetFromItem(ListItem);
		if (ensure(RowWidget.IsValid()) && RowWidget->DoesItemHaveChildren() > 0)
		{
			const bool bNewExpansionState = !MyTreeView->IsItemExpanded(ListItem);
			MyTreeView->SetItemExpansion(ListItem, bNewExpansionState);
		}
	}
}

void UKGTreeView::OnItemDoubleClickedInternal(ItemType ListItem)
{
	Super::OnItemDoubleClickedInternal(ListItem);
	if (auto TreeItem = FKGTreeItem::UnsafeCast(ListItem))
	{
		BP_OnTreeItemDoubleClicked.Broadcast(TreeItem->GetPath());
	}
}

void UKGTreeView::HandleOnEntryInitializedInternal(ItemType Item, const TSharedRef<ITableRow>& TableRow)
{
	auto TreeItem = FKGTreeItem::UnsafeCast(Item);
	if (TreeItem == nullptr)
	{
		return;
	}
	if (this->BP_OnEntryInitialized.IsBound())
	{
		// 表示TreeView的Item的参数是个整形数组，所以不能直接使用ListView的接口
		UE_LOG(LogKGUI, Warning, TEXT("Event `BP_OnEntryInitialized` is not supported in TreeView, try to use `BP_OnTreeEntryInitialized` instead."));
	}
	Super::HandleOnEntryInitializedInternal(Item, TableRow);
	BP_OnTreeEntryInitialized.Broadcast(TreeItem->GetPath(), GetEntryWidgetFromItem(Item));
}

void UKGTreeView::HandleOnItemSelectionChangedInternal(const NullableItemType& Item, bool bSelected)
{
	auto TreeItem = FKGTreeItem::UnsafeCast(Item);
	if (TreeItem == nullptr)
	{
		return;
	}
	if (this->BP_OnItemSelectionChanged.IsBound())
	{
		// 表示TreeView的Item的参数是个整形数组，所以不能直接使用ListView的接口
		UE_LOG(LogKGUI, Warning, TEXT("Event `BP_OnItemSelectionChanged` is not supported in TreeView, try to use `BP_OnTreeItemSelectionChanged` instead."));
	}
	Super::HandleOnItemSelectionChangedInternal(Item, bSelected);
	BP_OnTreeItemSelectionChanged.Broadcast(TreeItem->GetPath(), bSelected);
}

void UKGTreeView::HandleOnSelectionsChangedInternal(const SKGListView<ItemType>::TItemSet& SelectedItems, ESelectInfo::Type SelectInfo)
{
	if (this->BP_OnSelectionsChanged.IsBound())
	{
		// 表示TreeView的Item的参数是个整形数组，所以不能直接使用ListView的接口
		UE_LOG(LogKGUI, Warning, TEXT("Event `BP_OnSelectionsChanged` is not supported in TreeView."));
	}
	Super::HandleOnSelectionsChangedInternal(SelectedItems, SelectInfo);
}

void UKGTreeView::OnItemScrolledIntoViewInternal(ItemType ListItem, UUserWidget& EntryWidget)
{
	if (this->BP_OnItemScrolledIntoView.IsBound())
	{
		// 表示TreeView的Item的参数是个整形数组，所以不能直接使用ListView的接口
		UE_LOG(LogKGUI, Warning, TEXT("Event `BP_OnItemScrolledIntoView` is not supported in TreeView."));
	}
	Super::OnItemScrolledIntoViewInternal(ListItem, EntryWidget);
}

void UKGTreeView::OnItemExpansionChangedInternal(ItemType Item, bool bIsExpanded)
{
	auto TreeItem = FKGTreeItem::UnsafeCast(Item);
	if (TreeItem == nullptr)
	{
		return;
	}
	BP_OnItemExpansionChanged.Broadcast(TreeItem->GetPath(), bIsExpanded);
}

void UKGTreeView::OnGetChildrenInternal(ItemType Item, TArray<ItemType>& OutChildren) const
{
	if (!ensure(this->GetSlateTreeView().IsValid()))
	{
		// 尝试定位#206836，这个莫名其妙的闪退
		// 理论上U对象和S对象是成对出现的。S对象存在的时候，它对应的U对象应该会持有它。但是这个BUG出现时，U和S都在
		// 然而U上并不持有这个S对象了。怀疑是一些不正常的卸载逻辑下，U对象已经执行完ReleaseSlateResources，但是
		// 还没有被释放。而且此时S对象也因为一些原因（其他逻辑的引用）仍存在。
		UE_LOG(LogKGUI, Error, TEXT("[BUG#206836] %s 's Slate Tree View is Invalid"), *this->GetPathName());
		return;
	}
	if (RequestGetChildren(Item))
	{
		auto TreeItem = FKGTreeItem::UnsafeCast(Item);
		OutChildren = TreeItem->GetOutChildren();
	}
}

bool UKGTreeView::RequestGetChildren(ItemType Item) const
{
	auto TreeItem = FKGTreeItem::UnsafeCast(Item);
	if (TreeItem == nullptr)
	{
		return false;
	}
#if WITH_EDITORONLY_DATA
	if (!IsDesignTime() || bHierarchyPreviewableInDesignTime)
#endif
	{
		TArray<ItemType> TempChildren;
		int32 ChildrenCount = -1;
		if (BP_OnGetItemChildren.IsBound())
		{
			ChildrenCount = BP_OnGetItemChildren.Execute(TreeItem->GetPath());
		}
#if WITH_EDITORONLY_DATA
		else if (IsDesignTime())
		{
			check(bHierarchyPreviewableInDesignTime);
			//ChildrenCount = this->GetNumDesignerPreviewEntries();
			const auto& Path = TreeItem->GetPath();
			if (Path.Num() != 1)
			{
				ChildrenCount = 0;
			}
			else
			{
				if (!PreviewDetailData.IsValidIndex(Path[0]))
				{
					ChildrenCount = 0;
				}
				else
				{
					int Count = 0;
					for (const auto& ChildPreviewDetailData : PreviewDetailData[Path[0]].Children)
					{
						Count += ChildPreviewDetailData.Num;
					}
					ChildrenCount = Count;
				}
			}
		}
#endif
		if (ChildrenCount >= 0)
		{
			TreeItem->MakeChildren(ChildrenCount);
		}
		return true;
	}
	return false;
}

FMargin UKGTreeView::GetDesiredEntryPadding(ItemType Item) const
{
	auto TreeItem = FKGTreeItem::UnsafeCast(Item);
	if (TreeItem != nullptr)
	{
		// TileLayout的子节点的Spacing效果由它内部来实现，这里直接返回FMargin()；
		// 相关实现参考UKGTreeView::HandleGenerateRow。
		auto Parent = TreeItem->GetParentLayoutItem();
		if (Parent != nullptr)
		{
			return FMargin();
		}
	}
	return Super::GetDesiredEntryPadding(Item);
}

bool UKGTreeView::OnItemAnimationTick(const FKGItemAnimationConfiguration& Configuration, double StartTime, bool bForce, EKGItemAnimationState SpecificAnimationState)
{
	auto World = this->GetWorld();
	if (World == nullptr)
	{
		return false;
	}
	auto CurrentTime = World->GetTimeSeconds();
	auto PassedTime = CurrentTime - StartTime;
	bool bFinished = true;
	for (auto Item : MyListView->GetItems())
	{
		auto TreeItem = IKGTreeItem::UnsafeCast(Item);
		switch (TreeItem->GetTreeItemType())
		{
		case EKGTreeItemType::Normal:
		{
			bFinished &= UpdateItemAnimation(Configuration, Item, LastPassedTime, PassedTime, bForce, SpecificAnimationState) == EKGItemAnimationState::Finished;
		}
		break;
		case EKGTreeItemType::TileLayout:
		{
			auto TreeTileLayoutItem = FKGTreeTileLayoutItem::UnsafeCast(Item);
			for (auto ChildItem : TreeTileLayoutItem->GetTreeItems())
			{
				bFinished &= UpdateItemAnimation(Configuration, ChildItem, LastPassedTime, PassedTime, bForce, SpecificAnimationState) == EKGItemAnimationState::Finished;
			}
		}
		break;
		}
	}
	LastPassedTime = PassedTime;
	if (bFinished)
	{
		UE_LOG(LogKGUI, Log, TEXT("TreeView's item animation finished: %s"), *this->GetName());
	}
	return bFinished;
}

int32 UKGTreeView::GetLocalItemIndex(const ItemType& Item) const
{
	auto TreeItem = FKGTreeItem::UnsafeCast(Item);
	if (TreeItem == nullptr)
	{
		return -1;
	}
	auto Parent = TreeItem->GetParent();
	if (Parent != nullptr)
	{
		auto Index = Parent->GetChildren().IndexOfByKey(TreeItem);
		if (Index >= 0)
		{
			return Index;
		}
	}
	return Super::GetLocalItemIndex(Item);
}

int32 UKGTreeView::GetLocalNumItemsPerLine(const ItemType& Item) const
{
	auto TreeItem = FKGTreeItem::UnsafeCast(Item);
	if (TreeItem != nullptr)
	{
		auto ParentLayoutItem = TreeItem->GetParentLayoutItem();
		if (ParentLayoutItem != nullptr)
		{
			return FKGTreeTileLayoutItem::UnsafeCast(ParentLayoutItem)->GetTreeItems().Num();
		}
	}
	return Super::GetLocalNumItemsPerLine(Item);
}

double UKGTreeView::GetItemAnimationTriggerTime_Blueprint(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const
{
	if (MyListView == nullptr)
	{
		return 0;
	}
	if (OnGetListItemAnimationTriggerTime.IsBound())
	{
		UE_LOG(LogKGUI, Error, TEXT("Use OnGetTreeItemAnimationTriggerTime (specially defined for TreeView) instead!"));
	}
	if (!OnGetTreeItemAnimationTriggerTime.IsBound())
	{
		return 0;
	}
	auto TreeItem = FKGTreeItem::UnsafeCast(Item);
	return OnGetTreeItemAnimationTriggerTime.Execute(TreeItem->GetPath());
}

const FKGItemAnimationEntryStyle& UKGTreeView::GetItemAnimationEntryStyle(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const
{
	if (auto TreeItem = FKGTreeItem::UnsafeCast(Item))
	{
		int TreeLevel = TreeItem->GetTreeLevel();
		if (Configuration.EntryStyles.IsValidIndex(TreeLevel))
		{
			return Configuration.EntryStyles[TreeLevel];
		}
	}
	return FKGItemAnimationEntryStyle::Default;
}

const FKGItemAnimationEntryStyle& UKGTreeView::GetDefaultItemAnimationEntryStyle(const ItemType& Item) const
{
	if (auto TreeItem = FKGTreeItem::UnsafeCast(Item))
	{
		int TreeLevel = TreeItem->GetTreeLevel();
		if (DefaultTreeItemAnimationConfiguration.IsValidIndex(TreeLevel))
		{
			return DefaultTreeItemAnimationConfiguration[TreeLevel];
		}
	}
	return FKGItemAnimationEntryStyle::Default;
}

#if WITH_EDITOR
void UKGTreeView::OnRefreshDesignerItems()
{
	Super::OnRefreshDesignerItems();
	SetItemExpansion({ 0 }, true);
	SetItemExpansion({ 1 }, true);
}
#endif

TSubclassOf<UUserWidget> UKGTreeView::GetDesiredEntryClassForItem(ItemType Item) const
{
	auto TreeItem = FKGTreeItem::UnsafeCast(Item);
	if (!ensure(TreeItem))
	{
		return ITypedUMGListView<TSharedPtr<FKGListItem>>::GetDesiredEntryClassForItem(Item);
	}
	if (MoreEntryWidgetClasses.Num() > 0)
	{
		if (OnGetTreeEntryClassIndexForItem.IsBound())
		{
			int EntryClassIndex = OnGetTreeEntryClassIndexForItem.Execute(TreeItem->GetPath());
			if (EntryClassIndex < 0 || EntryClassIndex > MoreEntryWidgetClasses.Num())
			{
				UE_LOG(LogKGUI, Error, TEXT("Entry class index `%d` requested from OnGetTreeEntryClassIndexForItem is not valid (minimum: %d, maximum: %d)."), EntryClassIndex, 0, MoreEntryWidgetClasses.Num());
				EntryClassIndex = 0;
			}
			if (EntryClassIndex != 0)
			{
				if (auto Class = MoreEntryWidgetClasses[EntryClassIndex - 1])
				{
					Item->SetDesiredEntryClassIndex(EntryClassIndex);
					return Class;
				}
			}
		}
#if WITH_EDITORONLY_DATA
		else if (bHierarchyPreviewableInDesignTime)
		{
			auto Path = TreeItem->GetPath();
			int EntryWidgetClassIndex = INDEX_NONE;
			if (Path.Num() >= 1)
			{
				if (PreviewDetailData.IsValidIndex(Path[0]))
				{
					const auto& PreviewDetailDataItem = PreviewDetailData[Path[0]];
					EntryWidgetClassIndex = PreviewDetailDataItem.EntryWidgetClassIndex;
					if (Path.Num() >= 2)
					{
						int Count = 0;
						for (const auto& ChildPreviewDetailDataItem : PreviewDetailDataItem.Children)
						{
							Count += ChildPreviewDetailDataItem.Num;
							if (Count > Path[1])
							{
								EntryWidgetClassIndex = ChildPreviewDetailDataItem.EntryWidgetClassIndex;
								break;
							}
						}
					}
				}
			}
			if (MoreEntryWidgetClasses.IsValidIndex(EntryWidgetClassIndex - 1))
			{
				if (auto Class = MoreEntryWidgetClasses[EntryWidgetClassIndex - 1])
				{
					Item->SetDesiredEntryClassIndex(EntryWidgetClassIndex);
					return Class;
				}
			}
		}
#endif
	}
	Item->SetDesiredEntryClassIndex(INDEX_NONE);
	return ITypedUMGListView<TSharedPtr<FKGListItem>>::GetDesiredEntryClassForItem(Item);
}

template <typename ItemType>
class SKGTileLayoutTableRow : public IObjectTableRow, public SBox
{
public:
	SLATE_BEGIN_ARGS(SKGTileLayoutTableRow<ItemType>)
		: _Padding()
		, _Content()
		{}
		SLATE_ATTRIBUTE(FMargin, Padding)
		SLATE_DEFAULT_SLOT(typename SKGTileLayoutTableRow<ItemType>::FArguments, Content)
	SLATE_END_ARGS()

	void Construct(const typename SKGTileLayoutTableRow<ItemType>::FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTableView)
	{
		this->OwnerTablePtr = StaticCastSharedPtr< SListView<ItemType> >(InOwnerTableView.ToSharedPtr());
		this->SetContent(InArgs._Content.Widget);
		this->SetPadding(InArgs._Padding);
	}

	virtual void InitializeRow() override {}
	virtual void ResetRow() override {}

	virtual void SetIndexInList(int32 InIndexInList) override
	{
		IndexInList = InIndexInList;
	}

	virtual int32 GetIndexInList() override
	{
		return IndexInList;
	}

	virtual bool IsItemExpanded() const override  { return false; }
	virtual void ToggleExpansion() override {}
	virtual bool IsItemSelected() const override { return false; }

	virtual int32 GetIndentLevel() const override
	{
		return OwnerTablePtr.Pin()->Private_GetNestingDepth(IndexInList);
	}

	virtual int32 DoesItemHaveChildren() const override  { return false; }

	virtual TBitArray<> GetWiresNeededByDepth() const override
	{
		return OwnerTablePtr.Pin()->Private_GetWiresNeededByDepth(IndexInList);
	}

	virtual bool IsLastChild() const override
	{
		return OwnerTablePtr.Pin()->Private_IsLastChild(IndexInList);
	}

	virtual TSharedRef<SWidget> AsWidget() override
	{
		return SharedThis(this);
	}

	virtual TSharedPtr<SWidget> GetContent() override
	{
		return ChildSlot.GetWidget();
	}

	virtual void Private_OnExpanderArrowShiftClicked() override {}

	virtual FVector2D GetRowSizeForColumn(const FName& InColumnName) const override
	{
		return FVector2D::ZeroVector;
	}

	virtual UListViewBase* GetOwningListView() const override { return nullptr; }
	virtual UUserWidget* GetUserWidget() const override { return nullptr; }

protected:
	virtual ESelectionMode::Type GetSelectionMode() const override
	{
		const TSharedPtr< ITypedTableView<ItemType> > OwnerTable = OwnerTablePtr.Pin();
		return OwnerTable->Private_GetSelectionMode();
	}

	TWeakPtr< ITypedTableView<ItemType> > OwnerTablePtr;
	int32 IndexInList = 0;
};

TSharedRef<ITableRow> UKGTreeView::HandleGenerateRow(ItemType Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	if (auto TreeTileLayoutItem = FKGTreeTileLayoutItem::UnsafeCast(Item))
	{
		TSharedPtr<SStackBox> TileLayoutBox;
		TSharedRef<SWidget> Content =
			SAssignNew(TileLayoutBox, SStackBox)
			.Visibility(EVisibility::SelfHitTestInvisible)
			.Orientation(TreeTileLayoutItem->GetLineOrientation());
		auto SuperDesiredEntryPadding = Super::GetDesiredEntryPadding(TreeTileLayoutItem->GetTreeItems()[0]);
		Content = SNew(SBorder)
			.BorderImage_UObject(this, &UKGTreeView::GetTileLayoutBackground, TreeTileLayoutItem->IsFirstLine(), TreeTileLayoutItem->IsLastLine())
			.Padding(TreeTileLayoutItem->GetPadding() + (TreeTileLayoutItem->IsFirstLine() ? FMargin() : SuperDesiredEntryPadding))
			[
				Content
			];
		check(TreeTileLayoutItem->GetTreeItems().Num() != 0);
		auto TileLayoutRow =
			SNew(SKGTileLayoutTableRow<ItemType>, OwnerTable)
			.Visibility(EVisibility::SelfHitTestInvisible)
			.Padding(TreeTileLayoutItem->IsFirstLine() ? SuperDesiredEntryPadding : FMargin())
			[
				Content
			];
		TileLayoutRow->SetVisibility(EVisibility::SelfHitTestInvisible);
		bool bFirst = true;
		auto CellSize = TreeTileLayoutItem->GetCellSize();
		float Spacing = TreeTileLayoutItem->GetSpacing();
		for (auto ChildItem : TreeTileLayoutItem->GetTreeItems())
		{
			auto Entry = MyTreeView->WidgetFromItem(ChildItem);
			if (Entry == nullptr)
			{
				Entry = MyTreeView->GenerateNewWidget(ChildItem);
			}
			MyTreeView->SeeItem(ChildItem, Entry);
			TileLayoutBox->AddSlot()
			.AutoSize()
			.Padding(FMargin(bFirst ? 0 : Spacing, 0, 0, 0))
			[
				SNew(SBox)
				.WidthOverride(CellSize.X)
				.HeightOverride(CellSize.Y)
				[
					Entry->AsWidget()
				]
			];
			bFirst = false;
		}
		return TileLayoutRow;
	}
	return UKGListView::HandleGenerateRow(Item, OwnerTable);
}

void UKGTreeView::HandleRowReleased(const TSharedRef<ITableRow>& Row)
{
	UUserWidget* EntryWidget = StaticCastSharedRef<IObjectTableRow>(Row)->GetUserWidget();
	if (EntryWidget == nullptr)
	{
		return;
	}
	UKGListView::HandleRowReleased(Row);
}

void UKGTreeView::InitializeTileLayoutBackgrounds()
{
	TileLayoutFirstLineBackground = TileLayoutBackground;
	TileLayoutStretchableBackground = TileLayoutBackground;
	TileLayoutLastLineBackground = TileLayoutBackground;

	auto SourceMargin = TileLayoutBackground.GetMargin();
	if (UKGTemporarySprite::Supports(TileLayoutBackground.GetResourceObject()))
	{
		auto FirstLineBackgroundSprite = NewObject<UKGTemporarySprite>(this, UKGTemporarySprite::StaticClass(), TEXT("TileLayoutFirstLineBackground"));
		FirstLineBackgroundSprite->ResourceObject = TileLayoutBackground.GetResourceObject();
		FirstLineBackgroundSprite->Padding = FMargin(
			0,
			0,
			Orientation == Orient_Horizontal ? SourceMargin.Right : 0,
			Orientation == Orient_Vertical ? SourceMargin.Bottom : 0);
		TileLayoutFirstLineBackground.Margin = FMargin(
			SourceMargin.Left,
			SourceMargin.Top,
			Orientation == Orient_Horizontal ? 0 : SourceMargin.Right,
			Orientation == Orient_Vertical ? 0 : SourceMargin.Bottom);
		TileLayoutFirstLineBackground.SetResourceObject(FirstLineBackgroundSprite);

		auto StretchableBackgroundSprite = NewObject<UKGTemporarySprite>(this, UKGTemporarySprite::StaticClass(), TEXT("TileLayoutStretchableBackground"));
		StretchableBackgroundSprite->ResourceObject = TileLayoutBackground.GetResourceObject();
		StretchableBackgroundSprite->Padding = FMargin(
			Orientation == Orient_Horizontal ? SourceMargin.Left : 0,
			Orientation == Orient_Vertical ? SourceMargin.Top : 0,
			Orientation == Orient_Horizontal ? SourceMargin.Right : 0,
			Orientation == Orient_Vertical ? SourceMargin.Bottom : 0);
		TileLayoutStretchableBackground.Margin = FMargin(
			Orientation == Orient_Horizontal ? 0 : SourceMargin.Left,
			Orientation == Orient_Vertical ? 0 : SourceMargin.Top,
			Orientation == Orient_Horizontal ? 0 : SourceMargin.Right,
			Orientation == Orient_Vertical ? 0 : SourceMargin.Bottom);
		TileLayoutStretchableBackground.SetResourceObject(StretchableBackgroundSprite);

		auto LastLineBackgroundSprite = NewObject<UKGTemporarySprite>(this, UKGTemporarySprite::StaticClass(), TEXT("TileLayoutLastLineBackground"));
		LastLineBackgroundSprite->ResourceObject = TileLayoutBackground.GetResourceObject();
		LastLineBackgroundSprite->Padding = FMargin(
			Orientation == Orient_Horizontal ? SourceMargin.Left : 0,
			Orientation == Orient_Vertical ? SourceMargin.Top : 0,
			0,
			0);
		TileLayoutLastLineBackground.Margin = FMargin(
			Orientation == Orient_Horizontal ? 0 : SourceMargin.Left,
			Orientation == Orient_Vertical ? 0 : SourceMargin.Top,
			SourceMargin.Right,
			SourceMargin.Bottom);
		TileLayoutLastLineBackground.SetResourceObject(LastLineBackgroundSprite);
	}
}

void UKGTreeView::PlayListItemAnimation(const FKGItemAnimationEntryStyle& InEntryStyle)
{
	UE_LOG(LogKGUI, Error, TEXT("Use PlayTreeItemAnimation (specially defined for TreeView) instead!"));
}

void UKGTreeView::PlayListItemAnimationWithDefaultConfiguration()
{
	UE_LOG(LogKGUI, Error, TEXT("Use PlayTreeItemAnimationWithDefaultConfiguration (specially defined for TreeView) instead!"));
}

void UKGTreeView::SeekListItemAnimationToStart(const FKGItemAnimationEntryStyle& InEntryStyle)
{
	UE_LOG(LogKGUI, Error, TEXT("Use SeekTreeItemAnimationToStart (specially defined for TreeView) instead!"));
}

void UKGTreeView::SeekListItemAnimationToStartWithDefaultConfiguration()
{
	UE_LOG(LogKGUI, Error, TEXT("Use SeekTreeItemAnimationToStartWithDefaultConfiguration (specially defined for TreeView) instead!"));
}

void UKGTreeView::StopListItemAnimation()
{
	UE_LOG(LogKGUI, Error, TEXT("Use StopTreeItemAnimation (specially defined for TreeView) instead!"));
}

void UKGTreeView::PlayTreeItemAnimation(const TArray<FKGItemAnimationEntryStyle>& InEntryStyles)
{
	StopItemAnimationInternal();
	ActiveItemAnimationConfiguration.SetEntryStyleArray(InEntryStyles);
	PlayItemAnimationInternal();
}

void UKGTreeView::PlayTreeItemAnimationWithDefaultConfiguration()
{
	PlayTreeItemAnimation(DefaultTreeItemAnimationConfiguration);
}

void UKGTreeView::SeekTreeItemAnimationToStart(const TArray<FKGItemAnimationEntryStyle>& InEntryStyles)
{
	StopItemAnimationInternal(false);
	ActiveItemAnimationConfiguration.SetEntryStyleArray(InEntryStyles);
	auto StartTime = this->GetWorld()->GetTimeSeconds();
	this->OnItemAnimationTick(ActiveItemAnimationConfiguration, StartTime, true, EKGItemAnimationState::Preparing);
}

void UKGTreeView::SeekTreeItemAnimationToStartWithDefaultConfiguration()
{
	SeekTreeItemAnimationToStart(DefaultTreeItemAnimationConfiguration);
}

void UKGTreeView::StopTreeItemAnimation()
{
	StopItemAnimationInternal();
}

FMargin UKGTreeView::GetEntryFinalPadding(ItemType Item, TSharedRef<ITableRow> TableRow) const
{
	auto TreeTileLayoutItem = FKGTreeTileLayoutItem::UnsafeCast(Item);
	if (TreeTileLayoutItem != nullptr)
	{
		return GetDesiredEntryPadding(Item);
	}
	return Super::GetEntryFinalPadding(Item, TableRow);
}

TArray<int> UKGTreeView::GetFrontEdgeIntersectionTreeItemPath() const
{
	TArray<int> Path;
	PopulateFrontEdgeIntersectionTreeItemPathInternal(Path);
	return Path;
}

bool UKGTreeView::PopulateFrontEdgeIntersectionTreeItemPath(TArray<int>& Path)
{
	return PopulateFrontEdgeIntersectionTreeItemPathInternal(Path);
}

bool UKGTreeView::PopulateFrontEdgeIntersectionTreeItemPathInternal(TArray<int>& Path) const
{
	auto Item = GetFrontEdgeIntersectionListItem();
	return TryGetFirstTreeItemPathFromGenericItem(Item, Path);
}

TArray<int> UKGTreeView::GetBackEdgeIntersectionTreeItemPath() const
{
	TArray<int> Path;
	PopulateBackEdgeIntersectionTreeItemPathInternal(Path);
	return Path;
}

bool UKGTreeView::PopulateBackEdgeIntersectionTreeItemPath(TArray<int>& Path)
{
	return PopulateBackEdgeIntersectionTreeItemPathInternal(Path);
}

bool UKGTreeView::PopulateBackEdgeIntersectionTreeItemPathInternal(TArray<int>& Path) const
{
	auto Item = GetBackEdgeIntersectionListItem();
	return TryGetFirstTreeItemPathFromGenericItem(Item, Path);
}

TArray<int> UKGTreeView::GetFrontEdgeApproximateTreeItemPath() const
{
	TArray<int> Path;
	PopulateFrontEdgeApproximateTreeItemPathInternal(Path);
	return Path;
}

bool UKGTreeView::PopulateFrontEdgeApproximateTreeItemPath(TArray<int>& Path)
{
	return PopulateFrontEdgeApproximateTreeItemPathInternal(Path);
}

bool UKGTreeView::PopulateFrontEdgeApproximateTreeItemPathInternal(TArray<int>& Path) const
{
	auto Item = GetFrontEdgeApproximateListItem();
	return TryGetFirstTreeItemPathFromGenericItem(Item, Path);
}

TArray<int> UKGTreeView::GetBackEdgeApproximateTreeItemPath() const
{
	TArray<int> Path;
	PopulateBackEdgeApproximateTreeItemPathInternal(Path);
	return Path;
}

bool UKGTreeView::PopulateBackEdgeApproximateTreeItemPath(TArray<int>& Path)
{
	return PopulateBackEdgeApproximateTreeItemPathInternal(Path);
}

bool UKGTreeView::PopulateBackEdgeApproximateTreeItemPathInternal(TArray<int>& Path) const
{
	auto Item = GetBackEdgeApproximateListItem();
	return TryGetFirstTreeItemPathFromGenericItem(Item, Path);
}

bool UKGTreeView::TryGetFirstTreeItemPathFromGenericItem(ItemType Item, TArray<int>& Path)
{
	if (Item == nullptr)
	{
		return false;
	}
	if (auto TreeItem = FKGTreeItem::UnsafeCast(Item))
	{
		Path = TreeItem->GetPath();
		return true;
	}
	if (auto TreeTileLayoutItem = FKGTreeTileLayoutItem::UnsafeCast(Item))
	{
		const auto& TreeItems = TreeTileLayoutItem->GetTreeItems();
		if (TreeItems.Num() != 0)
		{
			Path = TreeItems[0]->GetPath();
			return true;
		}
	}
	return false;
}

#pragma region 强制刷新

UUserWidget* UKGTreeView::GetOrCreateTreeEntryWidgetFromItem(const TArray<int>& Path)
{
	if (!MyTreeView.IsValid())
	{
		return nullptr;
	}
	auto Item = GetItemAt(Path);
	if (Item == nullptr)
	{
		return nullptr;
	}
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	auto Items = MyTreeView->GetItems();
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	int Index = Items.Find(Item);
	if (Index == INDEX_NONE)
	{
		return nullptr;
	}
	return GetOrCreateEntryWidgetFromItem(Index);
}

#pragma endregion

#pragma region 复杂预览

#if WITH_EDITOR

void UKGTreeView::ValidateCompiledDefaults(class IWidgetCompilerLog& CompileLog) const
{
	Super::ValidateCompiledDefaults(CompileLog);

	for (const auto& PreviewDetailDataItem : PreviewDetailData)
	{
		if (PreviewDetailDataItem.EntryWidgetClassIndex < 0 || PreviewDetailDataItem.EntryWidgetClassIndex > MoreEntryWidgetClasses.Num())
		{
			CompileLog.Error(FText::FromString(FString::Printf(TEXT("Error Occured in %s: Preview Widget Class Index must be in Range [0, %d], not %d."), *this->GetName(), MoreEntryWidgetClasses.Num(), PreviewDetailDataItem.EntryWidgetClassIndex)));
		}
		for (const auto& ChildPreviewDetailDataItem : PreviewDetailDataItem.Children)
		{
			if (ChildPreviewDetailDataItem.EntryWidgetClassIndex < 0 || ChildPreviewDetailDataItem.EntryWidgetClassIndex > MoreEntryWidgetClasses.Num())
			{
				CompileLog.Error(FText::FromString(FString::Printf(TEXT("Error Occured in %s: Preview Widget Class Index must be in Range [0, %d], not %d."), *this->GetName(), MoreEntryWidgetClasses.Num(), ChildPreviewDetailDataItem.EntryWidgetClassIndex)));
			}
		}
	}
}

#endif

#pragma endregion

#pragma region 异形样式（提供区别于IrregularListView的简单的异形列表方案）

void UKGTreeView::MarkShapeAsDirty()
{
	// Super::MarkShapeAsDirty();

	if (!MyTreeView.IsValid() || ShapeStyle == nullptr)
	{
		return;
	}
	MyTreeView->ForEachGeneratedItems(
		[](ItemType Item, TSharedRef<ITableRow> TableRow)
		{
			if (auto TreeItem = FKGTreeItem::UnsafeCast(Item))
			{
				StaticCastSharedRef<SKGObjectTableRow<ItemType>>(TableRow)->MarkShapeAsDirty();
			}
		}
	);
}

#pragma endregion