#include "UMG/Components/KGRedPointUserWidget.h"

#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Blueprint/WidgetTree.h"
#include "Components/CanvasPanel.h"
#include "Components/Overlay.h"
#include "Components/ScaleBox.h"

void UKGRedPointUserWidget::ReleaseSlateResources(bool bReleaseChildren)
{

#if WITH_EDITOR
	SContent.Reset();
#endif

	Super::ReleaseSlateResources(bReleaseChildren);
}

#if WITH_EDITOR
TArray<FString> UKGRedPointUserWidget::GetCanvasAndOverlay()
{
	TArray<FString> Ans;
	TArray<UWidget*> Widgets;
	if (!WidgetTree) {
		return Ans;
	}
	WidgetTree->GetAllWidgets(Widgets);
	for (UWidget* Widget : Widgets)
	{
		if (Cast<UOverlay>(Widget) && RedPointState == EKGRedPointState::Overlay)
		{
			Ans.Add(Widget->GetName());
		}
		else if (Cast<UCanvasPanel>(Widget) && RedPointState == EKGRedPointState::Canvas)
		{
			Ans.Add(Widget->GetName());
		}
	}
	return Ans;
}

TSharedRef<SWidget> UKGRedPointUserWidget::RebuildWidget()
{
	TSharedRef<SWidget> SlateObject = Super::RebuildWidget();
	if (IsDesignTime())
	{
		RebuildRedPoint();
	}
	return SlateObject;
}

void UKGRedPointUserWidget::CheckRedPointIsValid()
{
	if (RedPointState == EKGRedPointState::None)
	{
		WidgetName = "";
		RedPointClass.Reset();
	}
	else if (RedPointState == EKGRedPointState::Overlay)
	{
		UWidget* Overlay = GetWidgetFromName(*WidgetName);
		if (!Cast<UOverlay>(Overlay))
		{
			WidgetName = "";
		}
	}
	else if (RedPointState == EKGRedPointState::Canvas)
	{
		UWidget* Canvas = GetWidgetFromName(*WidgetName);
		if (!Cast<UCanvasPanel>(Canvas))
		{
			WidgetName = "";
		}
	}
}

void UKGRedPointUserWidget::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::SynchronizeProperties();
	CheckRedPointIsValid();
	RebuildRedPoint();
}

void UKGRedPointUserWidget::ClearRedPoint()
{
	if (!SContent.IsValid())
	{
		return;
	}
	TArray<FString> Ans;
	TArray<UWidget*> Widgets;
	if (!WidgetTree) {
		return;
	}
	WidgetTree->GetAllWidgets(Widgets);
	for (UWidget* Widget : Widgets)
	{
		if (Cast<UOverlay>(Widget))
		{
			TSharedPtr<SWidget> CanvasOrOverlay = Widget->TakeWidget();//GetSlateWidgetFromName(*WidgetName);
			TSharedPtr<SOverlay> Overlay = StaticCastSharedPtr<SOverlay>(CanvasOrOverlay);
			if (Overlay)
			{
				Overlay->RemoveSlot(SContent.ToSharedRef());
			}
		}
		else if (Cast<UCanvasPanel>(Widget))
		{
			UCanvasPanel* Panel = Cast<UCanvasPanel>(Widget);
			TSharedPtr<SConstraintCanvas> Canvas = Panel->GetCanvasWidget();
			if (Canvas)
			{
				Canvas->RemoveSlot(SContent.ToSharedRef());
			}
		}
	}
	SContent.Reset();
}

void UKGRedPointUserWidget::RebuildRedPoint()
{
	if (IsDesignTime())
	{
		if (RedPointState == EKGRedPointState::None || !bShowRedPointInPreview)
		{
			ClearRedPoint();
		}
		else if (RedPointState == EKGRedPointState::Overlay)
		{
			ClearRedPoint();
			// UClass* Content = LoadClass<UUserWidget>(NULL, *RedPointClass.ToString());
			// UWidgetBlueprintGeneratedClass* UserWidget = Cast<UWidgetBlueprintGeneratedClass>(Content);
			UUserWidget* UserWidget = InstantiateRedPoint();
			// if (UserWidget && UserWidget->GetWidgetTreeArchetype() && UserWidget->GetWidgetTreeArchetype()->RootWidget)
			if (UserWidget)
			{
				UWidget* UCanvasOrOverlay = GetWidgetFromName(*WidgetName);
				if (!UCanvasOrOverlay)
				{
					return;
				}
				SContent = SNew(SScaleBox).Stretch(EStretch::UserSpecified).UserSpecifiedScale(DisplayScale)[
					// UserWidget->GetWidgetTreeArchetype()->RootWidget->TakeWidget()
					UserWidget->TakeWidget()
				];
				TSharedPtr<SWidget> CanvasOrOverlay = UCanvasOrOverlay->TakeWidget();//GetSlateWidgetFromName(*WidgetName);
				TSharedPtr<SOverlay> Overlay = StaticCastSharedPtr<SOverlay>(CanvasOrOverlay);
				if (!Overlay.IsValid()) {
					return;
				}
				Overlay->AddSlot()//.Expose(OverlaySlot)
					.HAlign(RedPointOverlayLayout.HorizontalAlignment)
					.VAlign(RedPointOverlayLayout.VerticalAlignment)
					.Padding(RedPointOverlayLayout.Padding)[
							SContent.ToSharedRef()			
					];
			}

		}
		else if (RedPointState == EKGRedPointState::Canvas)
		{
			ClearRedPoint();
			// UClass* Content = LoadClass<UUserWidget>(NULL, *RedPointClass.ToString());
			// UWidgetBlueprintGeneratedClass* UserWidget = Cast<UWidgetBlueprintGeneratedClass>(Content);
			UUserWidget* UserWidget = InstantiateRedPoint();
			// if (UserWidget && UserWidget->GetWidgetTreeArchetype() && UserWidget->GetWidgetTreeArchetype()->RootWidget)
			if (UserWidget)
			{
				UWidget* UCanvasOrOverlay = GetWidgetFromName(*WidgetName);
				if (!UCanvasOrOverlay) {
					return;
				}
				SContent = SNew(SScaleBox).Stretch(EStretch::UserSpecified).UserSpecifiedScale(DisplayScale)[
						// UserWidget->GetWidgetTreeArchetype()->RootWidget->TakeWidget()
						UserWidget->TakeWidget()
					];
				UCanvasPanel* Panel = Cast<UCanvasPanel>(UCanvasOrOverlay);
				if (!Panel) {
					return;
				}
				TSharedPtr<SConstraintCanvas> Canvas = Panel->GetCanvasWidget();
				if (!Canvas.IsValid()) {
					return;
				}
				Canvas->AddSlot()//.Expose(CanvasSlot)
					.AutoSize(RedPointCanvasLayout.bAutoSize)
					.ZOrder(RedPointCanvasLayout.ZOrder)
					.Alignment(RedPointCanvasLayout.Alignment)
					.Offset(RedPointCanvasLayout.Offset)
					.Anchors(RedPointCanvasLayout.Anchors)[
						SContent.ToSharedRef()
					];

			}
		}
	}
}
// 实例化一个红点蓝图对象（同一个界面可能多次使用，不能直接操作CDO）
UUserWidget* UKGRedPointUserWidget::InstantiateRedPoint()
{
	UWidgetBlueprintGeneratedClass* prefabClass = Cast<UWidgetBlueprintGeneratedClass>(LoadClass<UUserWidget>(nullptr, *RedPointClass.ToString()));
	if (prefabClass)
	{
		// 实例化一个新得出来
		UUserWidget* prefab = prefabClass->GetDefaultObject<UUserWidget>();
		UUserWidget* instance = UUserWidget::CreateWidgetInstance(*this, prefab->GetClass(), NAME_None);
		return instance;
	}
	return nullptr;
}



#endif