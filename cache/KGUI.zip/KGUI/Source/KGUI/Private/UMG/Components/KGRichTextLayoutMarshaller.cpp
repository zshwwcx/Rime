#include "UMG/Components/KGRichTextLayoutMarshaller.h"

#include "Components/RichTextBlockDecorator.h"
#include "Core/Common.h"
#include "Framework/Text/SlateTextRun.h"
#include "Framework/Text/SlateTextUnderlineLineHighlighter.h"
#include "Styling/ISlateStyle.h"
#include "UMG/Components/KGRichTextBlockDecoratorResourceReferencerInterface.h"


TSharedRef<FKGRichTextLayoutMarshaller> FKGRichTextLayoutMarshaller::Create(TArray< TSharedRef< ITextDecorator > > InDecorators, const ISlateStyle* const InDecoratorStyleSet)
{
	return MakeShareable(new FKGRichTextLayoutMarshaller(MoveTemp(InDecorators), InDecoratorStyleSet));
}

TSharedRef<FKGRichTextLayoutMarshaller> FKGRichTextLayoutMarshaller::Create(TSharedPtr< IRichTextMarkupParser > InParser, TSharedPtr< IRichTextMarkupWriter > InWriter, TArray< TSharedRef< ITextDecorator > > InDecorators, const ISlateStyle* const InDecoratorStyleSet)
{
	return MakeShareable(new FKGRichTextLayoutMarshaller(MoveTemp(InParser), MoveTemp(InWriter), MoveTemp(InDecorators), InDecoratorStyleSet));
}

void FKGRichTextLayoutMarshaller::SetInstanceDecorators(const TArray<TWeakObjectPtr<URichTextBlockDecorator>>& InInstanceDecorators)
{
	WeakInstanceDecorators = InInstanceDecorators;
}

FKGRichTextLayoutMarshaller::FKGRichTextLayoutMarshaller(TArray<TSharedRef<ITextDecorator>> InDecorators, const ISlateStyle* const InDecoratorStyleSet)
	: Super(InDecorators, InDecoratorStyleSet)
{
}

FKGRichTextLayoutMarshaller::FKGRichTextLayoutMarshaller(TSharedPtr<IRichTextMarkupParser> InParser, TSharedPtr<IRichTextMarkupWriter> InWriter, TArray<TSharedRef<ITextDecorator>> InDecorators, const ISlateStyle* const InDecoratorStyleSet)
	: Super(InParser, InWriter, InDecorators, InDecoratorStyleSet)
{
}

void FKGRichTextLayoutMarshaller::SetText(const FString& SourceString, FTextLayout& TargetTextLayout)
{
	for (const auto& WeakInstanceDecorator : WeakInstanceDecorators)
	{
		if (auto InstanceDecorator = WeakInstanceDecorator.Get())
		{
			if (InstanceDecorator->Implements<UKGRichTextBlockDecoratorResourceReferencerInterface>())
			{
				if (auto RichTextBlockDecoratorResourceReferencerInterface = Cast<IKGRichTextBlockDecoratorResourceReferencerInterface>(InstanceDecorator))
				{
					RichTextBlockDecoratorResourceReferencerInterface->ClearResourceReferences();
				}
			}
		}
	}
	FRichTextLayoutMarshaller::SetText(SourceString, TargetTextLayout);
}

void FKGRichTextLayoutMarshaller::AppendRunsForText(
	const int32 LineIndex,
	const FTextRunParseResults& TextRun,
	const FString& ProcessedString,
	const FTextBlockStyle& DefaultTextStyle,
	const TSharedRef<FString>& InOutModelText,
	FTextLayout& TargetTextLayout,
	TArray<TSharedRef<IRun>>& Runs,
	TArray<FTextLineHighlight>& LineHighlights,
	TMap<const FTextBlockStyle*, TSharedPtr<FSlateTextUnderlineLineHighlighter>>& CachedUnderlineHighlighters,
	TMap<const FTextBlockStyle*, TSharedPtr<FSlateTextStrikeLineHighlighter>>& CachedStrikeLineHighlighters
)
{
	// Copy from FRichTextLayoutMarshaller::AppendRunsForText

	TSharedPtr< ISlateRun > Run;
	TSharedPtr< ITextDecorator > Decorator = TryGetDecorator(ProcessedString, TextRun);

	// BEGIN ADD BY wuzhiwei05@kuaishou.com
	const FTextBlockStyle* TextBlockStyle = nullptr;
	FTextRange ModelRange;
	// END ADD BY wuzhiwei05@kuaishou.com

	if (Decorator.IsValid())
	{
		// Create run and update model string.

		// BEGIN CHANGE BY wuzhiwei05@kuaishou.com
#if 0
		Run = Decorator->Create(TargetTextLayout.AsShared(), TextRun, ProcessedString, InOutModelText, DecoratorStyleSet);
#else
		// FTextRange ModelRange;
		ModelRange.BeginIndex = InOutModelText->Len();
		Run = Decorator->Create(TargetTextLayout.AsShared(), TextRun, ProcessedString, InOutModelText, DecoratorStyleSet);
		ModelRange.EndIndex = InOutModelText->Len();

		if (Run.IsValid())
		{
			TextBlockStyle = FindTextBlockStyleByRunInfo(Run->GetRunInfo());
			if (TextBlockStyle == nullptr)
			{
				TextBlockStyle = &DefaultTextStyle;
			}
		}
#endif
		// END CHANGE BY wuzhiwei05@kuaishou.com
	}
	else
	{
		FRunInfo RunInfo(TextRun.Name);
		for (const TPair<FString, FTextRange>& Pair : TextRun.MetaData)
		{
			int32 Length = FMath::Max(0, Pair.Value.EndIndex - Pair.Value.BeginIndex);
			RunInfo.MetaData.Add(Pair.Key, ProcessedString.Mid(Pair.Value.BeginIndex, Length));
		}

		// BEGIN CHANGE BY wuzhiwei05@kuaishou.com
#if 0
		const FTextBlockStyle* TextBlockStyle;
		FTextRange ModelRange;
#endif
		// END CHANGE BY wuzhiwei05@kuaishou.com
		ModelRange.BeginIndex = InOutModelText->Len();
		if (!(TextRun.Name.IsEmpty()) && DecoratorStyleSet->HasWidgetStyle< FTextBlockStyle >(FName(*TextRun.Name)))
		{
			*InOutModelText += ProcessedString.Mid(TextRun.ContentRange.BeginIndex, TextRun.ContentRange.EndIndex - TextRun.ContentRange.BeginIndex);
			TextBlockStyle = &(DecoratorStyleSet->GetWidgetStyle< FTextBlockStyle >(FName(*TextRun.Name)));
		}
		else
		{
			*InOutModelText += ProcessedString.Mid(TextRun.OriginalRange.BeginIndex, TextRun.OriginalRange.EndIndex - TextRun.OriginalRange.BeginIndex);
			TextBlockStyle = &DefaultTextStyle;
		}
		ModelRange.EndIndex = InOutModelText->Len();

		// Create run.
		TSharedPtr< FSlateTextRun > SlateTextRun = FSlateTextRun::Create(RunInfo, InOutModelText, *TextBlockStyle, ModelRange);

		if (SlateTextRun)
		{
			// Apply the FontSizeMultiplier at the style use by the IRun
			SlateTextRun->ApplyFontSizeMultiplierOnTextStyle(FontSizeMultiplier);
		}
		Run = SlateTextRun;

		// BEGIN CHANGE BY wuzhiwei05@kuaishou.com
#if 0
		if (!TextBlockStyle->UnderlineBrush.GetResourceName().IsNone())
		{
			TSharedPtr<FSlateTextUnderlineLineHighlighter> UnderlineLineHighlighter = CachedUnderlineHighlighters.FindRef(TextBlockStyle);
			if (!UnderlineLineHighlighter.IsValid())
			{
				UnderlineLineHighlighter = FSlateTextUnderlineLineHighlighter::Create(TextBlockStyle->UnderlineBrush, TextBlockStyle->Font, TextBlockStyle->ColorAndOpacity, TextBlockStyle->ShadowOffset, TextBlockStyle->ShadowColorAndOpacity);
				CachedUnderlineHighlighters.Add(TextBlockStyle, UnderlineLineHighlighter);
			}

			LineHighlights.Add(FTextLineHighlight(LineIndex, ModelRange, FSlateTextUnderlineLineHighlighter::DefaultZIndex, UnderlineLineHighlighter.ToSharedRef()));
		}

		if (!TextBlockStyle->StrikeBrush.GetResourceName().IsNone())
		{
			TSharedPtr<FSlateTextStrikeLineHighlighter> StrikeLineHighlighter = CachedStrikeLineHighlighters.FindRef(TextBlockStyle);
			if (!StrikeLineHighlighter.IsValid())
			{
				StrikeLineHighlighter = FSlateTextStrikeLineHighlighter::Create(TextBlockStyle->StrikeBrush, TextBlockStyle->Font, TextBlockStyle->ColorAndOpacity, TextBlockStyle->ShadowOffset, TextBlockStyle->ShadowColorAndOpacity);
				CachedStrikeLineHighlighters.Add(TextBlockStyle, StrikeLineHighlighter);
			}

			LineHighlights.Add(FTextLineHighlight(LineIndex, ModelRange, FSlateTextStrikeLineHighlighter::DefaultZIndex, StrikeLineHighlighter.ToSharedRef()));
		}
#endif
		// END CHANGE BY wuzhiwei05@kuaishou.com
	}

	// BEGIN ADD BY wuzhiwei05@kuaishou.com
	if (TextBlockStyle != nullptr)
	{
		if (!TextBlockStyle->UnderlineBrush.GetResourceName().IsNone())
		{
			TSharedPtr<FSlateTextUnderlineLineHighlighter> UnderlineLineHighlighter = CachedUnderlineHighlighters.FindRef(TextBlockStyle);
			if (!UnderlineLineHighlighter.IsValid())
			{
				UnderlineLineHighlighter = FSlateTextUnderlineLineHighlighter::Create(TextBlockStyle->UnderlineBrush, TextBlockStyle->Font, TextBlockStyle->ColorAndOpacity, TextBlockStyle->ShadowOffset, TextBlockStyle->ShadowColorAndOpacity);
				CachedUnderlineHighlighters.Add(TextBlockStyle, UnderlineLineHighlighter);
			}

			LineHighlights.Add(FTextLineHighlight(LineIndex, ModelRange, FSlateTextUnderlineLineHighlighter::DefaultZIndex, UnderlineLineHighlighter.ToSharedRef()));
		}

		if (!TextBlockStyle->StrikeBrush.GetResourceName().IsNone())
		{
			TSharedPtr<FSlateTextStrikeLineHighlighter> StrikeLineHighlighter = CachedStrikeLineHighlighters.FindRef(TextBlockStyle);
			if (!StrikeLineHighlighter.IsValid())
			{
				StrikeLineHighlighter = FSlateTextStrikeLineHighlighter::Create(TextBlockStyle->StrikeBrush, TextBlockStyle->Font, TextBlockStyle->ColorAndOpacity, TextBlockStyle->ShadowOffset, TextBlockStyle->ShadowColorAndOpacity);
				CachedStrikeLineHighlighters.Add(TextBlockStyle, StrikeLineHighlighter);
			}

			LineHighlights.Add(FTextLineHighlight(LineIndex, ModelRange, FSlateTextStrikeLineHighlighter::DefaultZIndex, StrikeLineHighlighter.ToSharedRef()));
		}
	}
	// END ADD BY wuzhiwei05@kuaishou.com

	Runs.Add(Run.ToSharedRef());
}

const FTextBlockStyle* FKGRichTextLayoutMarshaller::FindTextBlockStyleByRunInfo(const FRunInfo& RunInfo) const
{
	auto FoundStyleName = RunInfo.MetaData.Find(TEXT("StyleName"));
	if (FoundStyleName != nullptr)
	{
		if (DecoratorStyleSet->HasWidgetStyle<FTextBlockStyle>(FName(*FoundStyleName)))
		{
			return &(DecoratorStyleSet->GetWidgetStyle<FTextBlockStyle>(FName(*FoundStyleName)));
		}
	}
	auto TextRunName = RunInfo.Name;
	if (!TextRunName.IsEmpty())
	{
		if (DecoratorStyleSet->HasWidgetStyle<FTextBlockStyle>(FName(*TextRunName)))
		{
			return &(DecoratorStyleSet->GetWidgetStyle<FTextBlockStyle>(FName(*TextRunName)));
		}
	}
	return nullptr;
}
