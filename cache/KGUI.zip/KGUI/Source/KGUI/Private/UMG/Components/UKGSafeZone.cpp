// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/UKGSafeZone.h"

// #if PLATFORM_IOS
// #include "IOS/IOSPlatformMisc.h"
// #include "IOS/IOSApplication.h"
// #elif PLATFORM_ANDROID
// #include "Android/AndroidPlatformMisc.h"
// ##include "Android/AndroidPlatform.h"
// #endif

