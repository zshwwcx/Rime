// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGInteractableArea.h"
#include "Components/CanvasPanelSlot.h"
#include "Framework/Application/SlateApplication.h"
#include "Curves/CurveFloat.h"
#include "KGUISettings.h"
#include "UMG/Components/KGButton.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Blueprint/WidgetTree.h"
#include "Engine/GameInstance.h"
#include "Kismet/GameplayStatics.h"
#include "Animation/WidgetAnimation.h"
#include "Core/Common.h"
#include "Components/Widget.h"
#include "Components/ContentWidget.h"
#include "Components/PanelWidget.h"
#include "Widgets/Layout/SBox.h"
#include "Slate/Components/SKGInteractableAnimArea.h"
#include "Components/CheckBox.h"

static FAutoConsoleVariable CVarKGInteractableAnimEnable(
	TEXT("KGUI.EnableInteractableAnim"),
	true,
	TEXT("Enable KGInteractable animation")
);

static FAutoConsoleVariable CVarKGInteractableAnimMode(
	TEXT("KGUI.InteractableAnimMode"),
	1,
	TEXT("Set KGInteractable animation mode: 0-set to target immediately, 1-Play the next animation right now 2-Play to the end of animation and then play next animation"));

static FAutoConsoleVariable CVarKGInteractableScaleMethod(
	TEXT("KGUI.InteractableScaleMethod"),
	0,
	TEXT("Set KGInteractable animation scale method:0-long side, 1-short side.default is 0(long side)"));


static FAutoConsoleVariable CVarKGInteractableScaleMode(
	TEXT("KGUI.InteractableAnimEnableGeometryScaling"),
	true,
	TEXT("Set KGInteractable animation enable geometry scaling.default is true"));




FKGInteractableAnimParams FKGInteractableAnimParams::Null{false, EKGInteractableAnimType::None};
bool FKGInteractableAnimParams::IsNull(const FKGInteractableAnimParams& CurveSet)
{
	return &CurveSet == &Null;
}

class FCurveAnimHandler;
class FGeometryScaleMode;
class FRenderScaleMode;

class IScalingMode
{
public:
	static IScalingMode& Get();

	virtual ~IScalingMode(){}
	virtual void Apply(FCurveAnimHandler& Handler, const FVector2D& Scale) = 0;
	virtual void OnBegin(FCurveAnimHandler& Handler) = 0;
	virtual void OnEnd(FCurveAnimHandler& Handler) = 0;
};

class FRenderScaleMode : public IScalingMode
{
public:
	virtual void Apply(FCurveAnimHandler& Handler, const FVector2D& Scale) override;
	virtual void OnBegin(FCurveAnimHandler& Handler) override;
	virtual void OnEnd(FCurveAnimHandler& Handler) override;
};

class FGeometryScaleMode : public IScalingMode
{
public:
	virtual void Apply(FCurveAnimHandler& Handler, const FVector2D& Scale);
	virtual void OnBegin(FCurveAnimHandler& Handler) override;
	virtual void OnEnd(FCurveAnimHandler& Handler) override;
};

IScalingMode& IScalingMode::Get()
{
	if (CVarKGInteractableScaleMode->GetBool())
	{
		static FGeometryScaleMode Instance;
		return Instance;
	}

	static FRenderScaleMode Instance;
	return Instance;
}

class FCurveAnimHandler : public FKGInteractableAnimHandlerBase
{
	friend class FRenderScaleMode;
	friend class FGeometryScaleMode;
public:
	FCurveAnimHandler(const FKGInteractableCurveAnimParams& InConfig)
		: Config(InConfig)
		, StartScale(1)
		, TargetScale(1)
		, StartOpacity(1)
		, TargetOpacity(1)
	{
		Type = EKGInteractableAnimType::Curve;
	}

	virtual void OnInitialize(UWidget* InWidget, UUserWidget* InUserWidget, const TArray<FKGWidgetName>& InVisualWidgetNames) override
	{
		if (!InWidget || !InUserWidget)
		{
			return;
		}

		VisualWidgets.Empty();

		FString ParentName;
		if (InWidget->IsA<UButton>())
		{
			UButton* Button = Cast<UButton>(InWidget);
			auto IsValidStyle = [](const FSlateBrush& Brush) -> bool
				{
					return Brush.DrawAs != ESlateBrushDrawType::Type::NoDrawType 
						&& (Brush.GetResourceObject() != nullptr || !Brush.GetResourceName().IsNone());
				};

			if (IsValidStyle(Button->GetStyle().Normal)
				|| IsValidStyle(Button->GetStyle().Hovered)
				|| IsValidStyle(Button->GetStyle().Pressed)
				|| IsValidStyle(Button->GetStyle().Disabled))
			{
				VisualWidgets.Emplace(InWidget);
				if (InWidget->Slot && InWidget->Slot->Parent)
				{
					ParentName = InWidget->Slot->Parent->GetName();
				}
			}
			else if (Button->GetContent())
			{
				VisualWidgets.Emplace(InWidget);
				if (InWidget->Slot && InWidget->Slot->Parent)
				{
					ParentName = InWidget->Slot->Parent->GetName();
				}
			}
		}
		else if (InWidget->IsA<UCheckBox>())
		{
			VisualWidgets.Emplace(InWidget);
			if (InWidget->Slot && InWidget->Slot->Parent)
			{
				ParentName = InWidget->Slot->Parent->GetName();
			}
		}

		UWidgetTree* WidgetTree = InUserWidget->WidgetTree;
		for (const auto& WidgetName : InVisualWidgetNames)
		{
			if (!ParentName.IsEmpty() && WidgetName.Name.ToString() == ParentName)
			{
				// 按钮的父节点已经在列表里面就移除按钮自身，防止按钮被多次缩放 
				VisualWidgets.RemoveAt(0);
			}

			VisualWidgets.Emplace(WidgetTree->FindWidget(WidgetName.Name));
		}
	}

	virtual FKGInteractableAnimHandlerBase& SetStartScale(const FVector2D& InScale) override
	{
		StartScale = InScale;
		return *this;
	}

	virtual FKGInteractableAnimHandlerBase& SetEndScale(const FVector2D& InScale) override
	{
		TargetScale = InScale;
		return *this;
	}
	
	virtual FKGInteractableAnimHandlerBase& SetStartOpacity(float InOpactiy) override
	{
		StartOpacity = InOpactiy;
		return *this;
	}
	
	virtual FKGInteractableAnimHandlerBase& SetEndOpacity(float InOpactiy) override
	{
		TargetOpacity = InOpactiy;
		return *this;
	}

	virtual void Play() override
	{
		bIsActive = true;
		CurrentTime = 0.f;

		BuildAnimAreas();

		IScalingMode::Get().OnBegin(*this);
		if (CVarKGInteractableAnimMode->GetInt() == static_cast<int32>(EKGInteractableAnimBreakMode::SetValue))
		{
			UpdateVisuals(Config.Duration);
			bIsActive = false;
		}
		else
		{
			UpdateVisuals(0);
		}
	}
	
	virtual void Tick(float DeltaTime) override
	{
		if (!bIsActive)
		{
			return;
		}

		CurrentTime += DeltaTime;
		const float Progress = FMath::Clamp(CurrentTime, 0.0f, Config.Duration);

		UpdateVisuals(Progress);

		if (CurrentTime >= Config.Duration)
		{
			bIsActive = false;
		}
	}

    virtual void PostTick(float DeltaTime) override
	{
	    BuildAnimAreas();
	}

	virtual bool IsDone() const override
	{
		return CurrentTime >= Config.Duration;
	}

	virtual void Reset() override
	{
		if (CVarKGInteractableAnimMode->GetInt() == static_cast<int32>(EKGInteractableAnimBreakMode::PlayAnimAfterSkipToEnd))
		{
			UpdateVisuals(Config.Duration);
		}

		IScalingMode::Get().OnEnd(*this);

		CurrentTime = 0;
		bIsActive = false;
		StartScale = FVector2D::One();
		TargetScale = FVector2D::One();
		StartOpacity = 1.f;
		TargetOpacity = 1.f;
	}

private:
	FKGInteractableCurveAnimParams Config;
	TArray<TWeakObjectPtr<UWidget>> VisualWidgets;
	TMap<TWeakObjectPtr<UWidget>, TSharedPtr<SKGInteractableAnimArea>> MapAnimAreas;
	float CurrentTime = 0.f;

	FVector2D StartScale;
	FVector2D TargetScale;
	float StartOpacity;
	float TargetOpacity;
	bool bIsActive = false;

private:
	void UpdateVisuals(float Time)
	{
		FVector2D Scale = FMath::Lerp(StartScale, TargetScale, GetCurveValue(Config.ScaleCurve, Time));
		//float CurOpacity = FMath::Lerp(StartOpacity, TargetOpacity, GetCurveValue(Config.OpacityCurve, Time));

		IScalingMode::Get().Apply(*this, Scale);
	}

	float GetCurveValue(UCurveFloat* InCurve, float InTime)
	{
		float Percent = 1.f;
		if (::IsValid(InCurve))
		{
			Percent = InCurve->GetFloatValue(InTime);
		}
		return Percent;
	}

	void BuildAnimAreas()
	{
		auto GetSlot = [](FChildren* Children, TSharedPtr<SWidget> Widget) -> FSlotBase*
			{
				if (Children)
				{
					for (int32 Idx = 0; Idx < Children->Num(); ++Idx)
					{
						if (Children->GetChildAt(Idx) == Widget)
						{
							return const_cast<FSlotBase*>(&Children->GetSlotAt(Idx));
						}
					}
				}

				return nullptr;
			};

		for (auto& Widget : VisualWidgets)
		{
			if (!Widget.IsValid())
			{
				continue;
			}

			if (MapAnimAreas.Contains(Widget))
			{
				continue;
			}

			TSharedPtr<SWidget> SlateWidget = Widget->GetCachedWidget();
			if (SlateWidget.IsValid())
			{
				TSharedPtr<SWidget> Parent = SlateWidget->GetParentWidget();
				TSharedPtr<SPanel> Panel = StaticCastSharedPtr<SPanel>(Parent);
				if (Panel.IsValid())
				{
					if (Panel->GetTypeAsString() == TEXT("SKGInteractableAnimArea"))
					{
						MapAnimAreas.Add(Widget, StaticCastSharedPtr<SKGInteractableAnimArea>(Parent));
						continue;
					}

					if (FSlotBase* Slot = GetSlot(Panel->GetChildren(), SlateWidget))
					{
						TSharedPtr<SKGInteractableAnimArea> AnimArea = SNew(SKGInteractableAnimArea);
						Slot->AttachWidget(AnimArea.ToSharedRef());
						AnimArea->SetContent(SlateWidget.ToSharedRef());
						MapAnimAreas.Add(Widget, AnimArea);
					}
				}
			}
		}
	}
};



void FRenderScaleMode::Apply(FCurveAnimHandler & Handler, const FVector2D & Scale)
{
	for (auto Widget : Handler.VisualWidgets)
	{
		if (Widget.IsValid())
		{
			Widget->SetRenderScale(Scale);
			//Widget->SetRenderOpacity(CurOpacity);
		}
	}
}

void FRenderScaleMode::OnBegin(FCurveAnimHandler& Handler)
{
	for (auto& Widget : Handler.VisualWidgets)
	{
		if (Widget.IsValid())
		{
			Widget->SetPixelSnapping(EWidgetPixelSnapping::Disabled);
		}
	}
}

void FRenderScaleMode::OnEnd(FCurveAnimHandler& Handler)
{
	for (auto& Widget : Handler.VisualWidgets)
	{
		if (Widget.IsValid())
		{
			Widget->SetPixelSnapping(EWidgetPixelSnapping::Inherit);
		}
	}
}

void FGeometryScaleMode::Apply(FCurveAnimHandler& Handler, const FVector2D& Scale)
{
	for (auto Pair : Handler.MapAnimAreas)
	{
		if (Pair.Key.IsValid() && Pair.Value.IsValid())
		{
			Pair.Value->SetScale(Scale.X);
		}
	}
}

void FGeometryScaleMode::OnBegin(FCurveAnimHandler& Handler)
{

}

void FGeometryScaleMode::OnEnd(FCurveAnimHandler& Handler)
{

}


class FWidgetAnimHandler : public FKGInteractableAnimHandlerBase
{
public:
	FWidgetAnimHandler(const FKGAnimName& InConfig)
		: Config(InConfig)
	{
		Type = EKGInteractableAnimType::Anim;
	}

	virtual void OnInitialize(UWidget* InWidget, UUserWidget* InUserWidget, const TArray<FKGWidgetName>& InVisualWidgetNames) override
	{
		check(InUserWidget);

		if (UWidgetBlueprintGeneratedClass* BPClass = InUserWidget->GetWidgetTreeOwningClass())
		{
			for (const TObjectPtr<UWidgetAnimation>& Anim : BPClass->Animations)
			{
#if WITH_EDITOR
				if (Anim->GetDisplayLabel() == Config.Name)
				{
					AnimationCache.Add(Anim->GetDisplayLabel(), Anim);
					break;
				}
#else
				FString Name = Anim->GetName();
				Name.RemoveFromEnd(TEXT("_INST"));
				if (Name == Config.Name.ToString())
				{
					AnimationCache.Add(Name, Anim);
					break;
				}
#endif
			}
		}
	}

	virtual FKGInteractableAnimHandlerBase& SetStartScale(const FVector2D& InScale) override
	{
		return *this;
	}

	virtual FKGInteractableAnimHandlerBase& SetEndScale(const FVector2D& InScale) override
	{
		return *this;
	}

	virtual FKGInteractableAnimHandlerBase& SetStartOpacity(float InOpactiy) override
	{
		return *this;
	}

	virtual FKGInteractableAnimHandlerBase& SetEndOpacity(float InOpactiy) override
	{
		return *this;
	}

	virtual void Play() override
	{
		if (TargetUserWidget.IsValid())
		{
			PlayInternal(Config.Name.ToString());
		}
	}

	virtual void Tick(float DeltaTime) override 
	{
		if (bActive)
		{
			CurTime += DeltaTime;
			CurTime = FMath::Clamp(CurTime, 0, Duration);
		}
	}

	virtual bool IsDone() const
	{
		return FMath::Abs(CurTime - Duration) < 1e-6f;
	}

	virtual void Reset() override
	{
		if (TargetUserWidget.IsValid() && PlayingAnimation.IsValid())
		{
			int32 BreakMode = CVarKGInteractableAnimMode->GetInt();
			if (BreakMode == static_cast<int32>(EKGInteractableAnimBreakMode::PlayAnimAfterSkipToEnd))
			{
				TargetUserWidget->PlayAnimationTimeRange(PlayingAnimation.Get(), PlayingAnimation->GetEndTime() - 0.001f, PlayingAnimation->GetEndTime());
			}
			else
			{
				TargetUserWidget->StopAnimation(PlayingAnimation.Get());
			}
			TargetUserWidget->SetPixelSnapping(EWidgetPixelSnapping::Inherit);
		}

		bActive = false;
		CurTime = 0.f;
		Duration = 0.f;
	}

private:
	FKGAnimName Config;
	TMap<FString, TWeakObjectPtr<UWidgetAnimation>> AnimationCache;
	TWeakObjectPtr<UWidgetAnimation> PlayingAnimation;
	float Duration = 0;
	float CurTime = 0;
	bool bActive = false;
private:
	UWidgetAnimation* GetAnimationByName(const FString& Name)
	{
		if (!TargetUserWidget.IsValid())
		{
			return nullptr;
		}

		if (UWidgetBlueprintGeneratedClass* BPClass = TargetUserWidget->GetWidgetTreeOwningClass())
		{
			for (const TObjectPtr<UWidgetAnimation>& Anim : BPClass->Animations)
			{
#if WITH_EDITOR
				if (Anim->GetDisplayLabel() == Name)
				{
					return Anim;
				}
#else
				FString AnimName = Anim->GetName();
				AnimName.RemoveFromEnd(TEXT("_INST"));
				if (AnimName == Name)
				{
					return Anim;
				}
#endif
			}
		}

		return nullptr;
	}

	void PlayInternal(const FString& AnimName)
	{
		if (bActive)
		{
			return;
		}

		UWidgetAnimation* Animation = nullptr;
		TWeakObjectPtr<UWidgetAnimation>* CachedAnim = AnimationCache.Find(AnimName);
		if (CachedAnim && CachedAnim->IsValid())
		{
			Animation = (*CachedAnim).Get();
		}

		if(!Animation)
		{
			if (auto* Anim = GetAnimationByName(AnimName))
			{
				AnimationCache.Add(AnimName, Anim);
				Animation = Anim;
			}
			else
			{
				UE_LOG(LogKGUI, Warning, TEXT("%s:Animation [%s] not found in widget class"), ANSI_TO_TCHAR(__FUNCTION__), *AnimName);
				return;
			}
		}

		CurTime = 0;
		bActive = true;
		Duration = Animation->GetEndTime() - Animation->GetStartTime();
		PlayingAnimation = Animation;
		TargetUserWidget->PlayAnimation(Animation);
		TargetUserWidget->SetPixelSnapping(EWidgetPixelSnapping::Disabled);
	}
};


FKGInteractableArea::FKGInteractableArea(UWidget* InOwnerWidget, const FKGHoverPressAnim& InAnimParams)
	: OwnerWidget(InOwnerWidget)
	, AnimParams(InAnimParams)
{
	const UKGUISettings* Settings = GetDefault<UKGUISettings>();
	const auto& HoverCurveParams = InAnimParams.Hovered.CurveAnim;
	if (HoverCurveParams.ScaleCurve == nullptr)
	{
		AnimParams.Hovered.CurveAnim.ScaleCurve = Settings->HoverScale.Get();
	}

	if (HoverCurveParams.OpacityCurve == nullptr)
	{
		AnimParams.Hovered.CurveAnim.OpacityCurve = Settings->HoverOpacity.Get();
	}

	if (HoverCurveParams.ExpansionSize == 0)
	{
		AnimParams.Hovered.CurveAnim.ExpansionSize = Settings->ExpansionSizeOnHovered;
	}

	if (InAnimParams.Hovered.ActiveAnim.IsEmpty())
	{
		AnimParams.Hovered.ActiveAnim = Settings->HoverAnimName;
	}

	if (InAnimParams.Hovered.DeactiveAnim.IsEmpty())
	{
		AnimParams.Hovered.DeactiveAnim = Settings->UnhoverAnimName;
	}

	if (InAnimParams.Pressed.CurveAnim.ScaleCurve == nullptr)
	{
		AnimParams.Pressed.CurveAnim.ScaleCurve = Settings->PressScale.Get();
	}

	if (InAnimParams.Pressed.CurveAnim.OpacityCurve == nullptr)
	{
		AnimParams.Pressed.CurveAnim.OpacityCurve = Settings->PressOpacity.Get();
	}

	if (InAnimParams.Pressed.CurveAnim.ExpansionSize == 0)
	{
		AnimParams.Pressed.CurveAnim.ExpansionSize = Settings->ExpansionSizeOnPressed;
	}

	if (InAnimParams.Pressed.ActiveAnim.IsEmpty())
	{
		AnimParams.Pressed.ActiveAnim = Settings->PressAnimName;
	}

	if (InAnimParams.Pressed.DeactiveAnim.IsEmpty())
	{
		AnimParams.Pressed.DeactiveAnim = Settings->ReleaseAnimName;
	}
}

FKGInteractableArea::~FKGInteractableArea()
{
	AnimationHandlers.Empty();
}

void FKGInteractableArea::OnHovered()
{
	UWidget* Widget = GetWidget();
	if (!Widget)
	{
		return;
	}

	double Scale = GetExpansionScale(AnimParams.Hovered.CurveAnim.ExpansionSize);
	UE_LOG(LogKGUI, Log, TEXT("[FKGInteractableArea]OnHover %s scale:%.3f"), *Widget->GetName(), Scale);
	if (auto* Handler = AnimationHandlers.Find(EKGInteractableAnimState::Hovered))
	{
		(*Handler)->SetStartScale(Widget->GetRenderTransform().Scale)
			.SetEndScale(FVector2D(Scale))
			.SetStartOpacity(Widget->GetRenderOpacity())
			.SetEndOpacity(1.f);
	}

	TransitionState(EKGInteractableAnimState::Hovered);
}

void FKGInteractableArea::OnUnhovered()
{
	UWidget* Widget = GetWidget();
	if (!Widget)
	{
		return;
	}
	
	if (auto* Handler = AnimationHandlers.Find(EKGInteractableAnimState::Unhovered))
	{
		(*Handler)->SetStartScale(Widget->GetRenderTransform().Scale)
			.SetEndScale(FVector2D::One())
			.SetStartOpacity(Widget->GetRenderOpacity())
			.SetEndOpacity(1.f);
	}

	TransitionState(EKGInteractableAnimState::Unhovered);
}

void FKGInteractableArea::OnPressed()
{
	UWidget* Widget = GetWidget();
	if (!Widget)
	{
		return;
	}
	
	double Scale = GetExpansionScale(AnimParams.Pressed.CurveAnim.ExpansionSize);
	if (auto* Handler = AnimationHandlers.Find(EKGInteractableAnimState::Pressed))
	{
		(*Handler)->SetStartScale(Widget->GetRenderTransform().Scale)
			.SetEndScale(FVector2D(Scale))
			.SetStartOpacity(Widget->GetRenderOpacity())
			.SetEndOpacity(1.f);
	}

	TransitionState(EKGInteractableAnimState::Pressed);
}

void FKGInteractableArea::OnReleased()
{
	UWidget* Widget = GetWidget();
	if (!Widget)
	{
		return;
	}

	if (auto* Handler = AnimationHandlers.Find(EKGInteractableAnimState::Released))
	{
		(*Handler)->SetStartScale(Widget->GetRenderTransform().Scale)
			.SetEndScale(FVector2D::One())
			.SetStartOpacity(Widget->GetRenderOpacity())
			.SetEndOpacity(1.f);
	}

	TransitionState(EKGInteractableAnimState::Released);
}


void FKGInteractableArea::OnSlatePreTick(float InDeltaTime)
{
	UWidget* Widget = GetWidget();
	if (Widget)
	{
		if (auto* Handler = AnimationHandlers.Find(CurState))
		{
			(*Handler)->Tick(InDeltaTime);
		}
	}
}

void FKGInteractableArea::OnSlatePostTick(float InDeltaTime)
{
    for (auto& Handler : AnimationHandlers)
    {
        Handler.Value->PostTick(InDeltaTime);
    }
    
	if (auto* Handler = AnimationHandlers.Find(CurState))
	{
		if ((*Handler)->IsDone())
		{
			TransitionState(EKGInteractableAnimState::Normal);
		}
	}
}

void FKGInteractableArea::OnWidgetRebuild()
{
	if (FSlateApplication::IsInitialized())
	{
		if (!FSlateApplication::Get().OnPreTick().IsBoundToObject(this))
		{
			FSlateApplication::Get().OnPreTick().AddSP(this, &FKGInteractableArea::OnSlatePreTick);
		}
	
		if (!FSlateApplication::Get().OnPostTick().IsBoundToObject(this))
		{
			FSlateApplication::Get().OnPostTick().AddSP(this, &FKGInteractableArea::OnSlatePostTick);
		}
	}

	FindUserWidget();
	InitializeHandlers();
}

void FKGInteractableArea::OnReleaseSlateResources()
{
    if (IsInGameThread())
    {
	    AnimationHandlers.Empty();
    }
    else
    {
        UE_LOG(LogKGUI, Warning, TEXT("[FKGInteractableArea] relase on non GameThread."));
    }

	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().OnPreTick().RemoveAll(this);
		FSlateApplication::Get().OnPostTick().RemoveAll(this);
	}
}

void FKGInteractableArea::FindUserWidget()
{
	UWidget* Widget = GetWidget();
	if (!Widget)
	{
		return;
	}

	UObject* Obj = Widget;
	while (Obj && !Obj->IsA(UWidgetTree::StaticClass()))
	{
		Obj = Obj->GetOuter();
	}

	if (Obj)
	{
		OwnerUserWidget = Cast<UUserWidget>(Obj->GetOuter());
	}
	
	if(!OwnerUserWidget.IsValid())
	{
		UE_LOG(LogKGUI, Warning, TEXT("%s:not found user widget.widget:%s"), ANSI_TO_TCHAR(__FUNCTION__), *Widget->GetFullName());
	}
}

UWidget* FKGInteractableArea::GetWidget() const
{
	if (OwnerWidget.IsValid())
	{
		return OwnerWidget.Get();
	}
	return nullptr;
}

void FKGInteractableArea::InitializeHandlers()
{
	AnimationHandlers.Empty();

	auto CreateHandler = [this](EKGInteractableAnimType InAnimType, const FKGInteractableCurveAnimParams& InCurveCfg, const FKGAnimName& InAnimName) -> TUniquePtr<FKGInteractableAnimHandlerBase>
		{
			TUniquePtr<FKGInteractableAnimHandlerBase> Ptr;
			switch (InAnimType)
			{
			case EKGInteractableAnimType::Curve:
				return MakeUnique<FCurveAnimHandler>(InCurveCfg);
			case EKGInteractableAnimType::Anim:
				return MakeUnique<FWidgetAnimHandler>(InAnimName);
			default:
				return nullptr;
			}
		};

	if (AnimParams.Hovered.AnimType != EKGInteractableAnimType::None)
	{
		TUniquePtr<FKGInteractableAnimHandlerBase> HoverHandler = CreateHandler(AnimParams.Hovered.AnimType, AnimParams.Hovered.CurveAnim, AnimParams.Hovered.ActiveAnim);
		if (HoverHandler)
		{
			HoverHandler->Initialize(OwnerWidget.Get(), OwnerUserWidget.Get(), AnimParams.VisualWidgetNames);
			AnimationHandlers.Add(EKGInteractableAnimState::Hovered, MoveTemp(HoverHandler));
		}

		auto UnhoverHandler = CreateHandler(AnimParams.Hovered.AnimType, AnimParams.Hovered.CurveAnim, AnimParams.Hovered.DeactiveAnim);
		if (UnhoverHandler)
		{
			UnhoverHandler->Initialize(OwnerWidget.Get(), OwnerUserWidget.Get(), AnimParams.VisualWidgetNames);
			AnimationHandlers.Add(EKGInteractableAnimState::Unhovered, MoveTemp(UnhoverHandler));
		}
	}

	if (AnimParams.Pressed.AnimType != EKGInteractableAnimType::None)
	{
		auto PressHandler = CreateHandler(AnimParams.Pressed.AnimType, AnimParams.Pressed.CurveAnim, AnimParams.Pressed.ActiveAnim);
		if (PressHandler)
		{
			PressHandler->Initialize(OwnerWidget.Get(), OwnerUserWidget.Get(), AnimParams.VisualWidgetNames);
			AnimationHandlers.Add(EKGInteractableAnimState::Pressed, MoveTemp(PressHandler));
		}

		auto ReleaseHandler = CreateHandler(AnimParams.Pressed.AnimType, AnimParams.Pressed.CurveAnim, AnimParams.Pressed.DeactiveAnim);
		if (ReleaseHandler)
		{
			ReleaseHandler->Initialize(OwnerWidget.Get(), OwnerUserWidget.Get(), AnimParams.VisualWidgetNames);
			AnimationHandlers.Add(EKGInteractableAnimState::Released, MoveTemp(ReleaseHandler));
		}
	}
}

void FKGInteractableArea::TransitionState(EKGInteractableAnimState NewState)
{
	if (CurState == NewState)
	{
		return;
	}

	// 结束旧状态动画
	if (auto* Handler = AnimationHandlers.Find(CurState))
	{
		(*Handler)->Reset();
	}

	// 开始新状态动画
	if (auto* Handler = AnimationHandlers.Find(NewState))
	{
		(*Handler)->Play();
	}

	CurState = NewState;
}

double FKGInteractableArea::GetExpansionScale(int32 InExpsionSize)
{
	UWidget* Widget = GetWidget();
	if (Widget)
	{
		FVector2D Size = Widget->GetCachedGeometry().GetLocalSize();
		double Len = CVarKGInteractableScaleMethod->GetInt() == 1 
			? FMath::Min(Size.X, Size.Y)
			: FMath::Max(Size.X, Size.Y);

		Len = FMath::Max(Len, 1e-5);

		if (InExpsionSize > Len)
		{
			InExpsionSize = Len;
		}

		double Scale = (Len + InExpsionSize * 2) / Len;
		return Scale;
	}

	return 1.0;
}
