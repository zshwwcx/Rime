// Fill out your copyright notice in the Description page of Project Settings.

#include "UMG/Components/KGCircleButton.h"

#include "Components/ButtonSlot.h"
#include "Widgets/Input/SButton.h"

#pragma optimize("",off)

FReply UKGCircleButton::SlateHandleClicked()
{
	FGeometry Geometry = GetCachedGeometry();
	float Radius = Geometry.GetLocalSize().X / 2.0f;
	FVector2D CenterPosition = Geometry.AbsoluteToLocal(GetCachedGeometry().GetAbsolutePosition()) + GetCachedGeometry().GetLocalSize() / 2.0f;
	SButton* MySButton = (SButton*)&(this->TakeWidget().Get());
	FVector2D ScreenSpacePosition = Geometry.AbsoluteToLocal(MySButton->GetPressedScreenSpacePosition());
	if ((CenterPosition - ScreenSpacePosition).SquaredLength() > Radius * Radius)
	{
		return FReply::Unhandled();
	}
	else 
	{
		return Super::SlateHandleClicked();
	}
}

#pragma optimize("", on)

