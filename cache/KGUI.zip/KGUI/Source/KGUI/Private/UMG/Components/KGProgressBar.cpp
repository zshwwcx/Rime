#include "UMG/Components/KGProgressBar.h"

#include "Core/Common.h"
#include "Slate/Components/SKGProgressBar.h"
#include "Styling/DefaultStyleCache.h"
#include "UMG/Blueprint/KGBrushTextureLoader.h"

float WrapAngle(float InAngle)
{
    float Angle = FMath::Fmod(InAngle, UE_TWO_PI);
    Angle = Angle < 0 ? Angle + UE_TWO_PI : Angle;
    Angle = Angle > UE_TWO_PI ? Angle - UE_TWO_PI : Angle;
    return Angle;
}


/////////////////////////////////////////////////////
// UKGProgressBarSlot

UKGProgressBarSlot::UKGProgressBarSlot(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
{
    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    Padding = FMargin(4.f, 2.f);

    HorizontalAlignment = HAlign_Center;
    VerticalAlignment = VAlign_Center;
    PRAGMA_ENABLE_DEPRECATION_WARNINGS
}

void UKGProgressBarSlot::ReleaseSlateResources(bool bReleaseChildren)
{
    Super::ReleaseSlateResources(bReleaseChildren);

    ProgressBar.Reset();
}

void UKGProgressBarSlot::BuildSlot(TSharedRef<SKGProgressBar> InProgressBar)
{
    ProgressBar = InProgressBar;

    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    InProgressBar->SetPadding(Padding);
    InProgressBar->SetHAlign(HorizontalAlignment);
    InProgressBar->SetVAlign(VerticalAlignment);
    PRAGMA_ENABLE_DEPRECATION_WARNINGS

    InProgressBar->SetContent(Content ? Content->TakeWidget() : SNullWidget::NullWidget);
}

PRAGMA_DISABLE_DEPRECATION_WARNINGS

FMargin UKGProgressBarSlot::GetPadding() const
{
    return Padding;
}

void UKGProgressBarSlot::SetPadding(FMargin InPadding)
{
    Padding = InPadding;
    if (ProgressBar.IsValid())
    {
        ProgressBar.Pin()->SetPadding(InPadding);
    }
}

EHorizontalAlignment UKGProgressBarSlot::GetHorizontalAlignment() const
{
    return HorizontalAlignment;
}

void UKGProgressBarSlot::SetHorizontalAlignment(EHorizontalAlignment InHorizontalAlignment)
{
    HorizontalAlignment = InHorizontalAlignment;
    if (ProgressBar.IsValid())
    {
        ProgressBar.Pin()->SetHAlign(InHorizontalAlignment);
    }
}

EVerticalAlignment UKGProgressBarSlot::GetVerticalAlignment() const
{
    return VerticalAlignment;
}

void UKGProgressBarSlot::SetVerticalAlignment(EVerticalAlignment InVerticalAlignment)
{
    VerticalAlignment = InVerticalAlignment;
    if (ProgressBar.IsValid())
    {
        ProgressBar.Pin()->SetVAlign(InVerticalAlignment);
    }
}

PRAGMA_ENABLE_DEPRECATION_WARNINGS

void UKGProgressBarSlot::SynchronizeProperties()
{
    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    SetPadding(Padding);
    SetHorizontalAlignment(HorizontalAlignment);
    SetVerticalAlignment(VerticalAlignment);
    PRAGMA_ENABLE_DEPRECATION_WARNINGS
}

/*
 * UKGProgressBar
 */
void UKGProgressBar::SetBackgroundBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize)
{
    if (!BackgroundBrushTextLoader.IsValid())
    {
        auto WeakThis = TWeakObjectPtr<UKGProgressBar>(this);
        BackgroundBrushTextLoader = MakeShared<FKGBrushTextureLoader>(this, FKGBrushTextureLoader::FOnGetBrush::CreateWeakLambda(this, [WeakThis]() -> FSlateBrush*
        {
            if (auto StrongThis = WeakThis.Get())
            {
                PRAGMA_DISABLE_DEPRECATION_WARNINGS
                return &StrongThis->WidgetStyle.BackgroundImage;
                PRAGMA_ENABLE_DEPRECATION_WARNINGS
            }
            return nullptr;
        }));
    }
    BackgroundBrushTextLoader->SetBrushFromSoftObject(SoftObjectPath, bMatchSize);
}

void UKGProgressBar::SetFillBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize)
{
    if (!FillBrushTextLoader.IsValid())
    {
        auto WeakThis = TWeakObjectPtr<UKGProgressBar>(this);
        FillBrushTextLoader = MakeShared<FKGBrushTextureLoader>(this, FKGBrushTextureLoader::FOnGetBrush::CreateWeakLambda(this, [WeakThis]() -> FSlateBrush*
        {
            if (auto StrongThis = WeakThis.Get())
            {
                PRAGMA_DISABLE_DEPRECATION_WARNINGS
                return &StrongThis->WidgetStyle.FillImage;
                PRAGMA_ENABLE_DEPRECATION_WARNINGS
            }
            return nullptr;
        }));
    }
    FillBrushTextLoader->SetBrushFromSoftObject(SoftObjectPath, bMatchSize);
}

void UKGProgressBar::SetThumbBrushFromSoftObject(const FString& InSoftObjectPath, bool bMatchSize)
{
    if (!ThumbBrushLoader.IsValid())
    {
        auto WeakThis = TWeakObjectPtr<UKGProgressBar>(this);
        ThumbBrushLoader = MakeShared<FKGBrushTextureLoader>(this, FKGBrushTextureLoader::FOnGetBrush::CreateWeakLambda(this, [WeakThis]() -> FSlateBrush*
        {
            if (auto StrongThis = WeakThis.Get())
            {
                PRAGMA_DISABLE_DEPRECATION_WARNINGS
                return &StrongThis->ThumbImage;
                PRAGMA_ENABLE_DEPRECATION_WARNINGS
            }
            return nullptr;
        }));
    }
    ThumbBrushLoader->SetBrushFromSoftObject(InSoftObjectPath, bMatchSize);
}

void UKGProgressBar::OnAbsoluteSizeChanged(const FVector2f& NewSize)
{
    UE_LOG(LogInit, Log, TEXT("[Progress] %s OnAbsoluteSizeChanged.Frame:%u"), *GetFullName(), GFrameNumber);
}

UKGProgressBar::UKGProgressBar(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
{
    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    SetWidgetStyle(UE::Slate::Private::FDefaultStyleCache::GetRuntime().GetProgressBarStyle());

#if WITH_EDITOR
    if (IsEditorWidget())
    {
        SetWidgetStyle(UE::Slate::Private::FDefaultStyleCache::GetEditor().GetProgressBarStyle());
    }
#endif // WITH_EDITOR

    WidgetStyle.FillImage.TintColor = FLinearColor::White;

    BarFillType = EKGProgressBarFillType::LeftToRight;
    BarFillStyle = EProgressBarFillStyle::Mask;
    bIsMarquee = false;
    Percent = 1;
    FillColorAndOpacity = FLinearColor::White;
    BorderPadding = FVector2D(0, 0);
    PRAGMA_ENABLE_DEPRECATION_WARNINGS
}

void UKGProgressBar::ReleaseSlateResources(bool bReleaseChildren)
{
    if (!HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
    {
        UnregisterTick();
    }
    
    Super::ReleaseSlateResources(bReleaseChildren);

    MyProgressBar.Reset();
}

TSharedRef<SWidget> UKGProgressBar::RebuildWidget()
{
    UE_LOG(LogInit, Log, TEXT("[Progress] %s RebuildWidget.Frame:%u"), *GetFullName(), GFrameNumber);
    float StartAngle = WrapAngle(FMath::DegreesToRadians(CircularStartAngle));
    float EndAngle = WrapAngle(FMath::DegreesToRadians(CircularEndAngle));
    if (StartAngle >= EndAngle)
    {
        StartAngle -= UE_TWO_PI;
    }

    MyProgressBar = SNew(SKGProgressBar).Style(&GetWidgetStyle()).ThumbImage(&GetThumbImage()).Percent(GetPercent()).BorderPadding(GetBorderPadding()).BarFillStyle(GetBarFillStyle()).BarFillStyle(GetBarFillStyle()).FillColorAndOpacity(GetFillColorAndOpacity()).RefreshRate(RefreshRate).CircularThickness(CircularThickness).CircularRadius(CircularRadius).CircularStartAngle(StartAngle).CircularEndAngle(EndAngle).ThumbOffset(ThumbOffset).AlwaysShowThumb(bAlwaysShowThumb).HasThumb(bHasThumb);

    MyProgressBar->GetOnAbsoluteSizeChanged().AddUObject(this, &UKGProgressBar::OnAbsoluteSizeChanged);
    if (GetChildrenCount() > 0)
    {
        Cast<UKGProgressBarSlot>(GetContentSlot())->BuildSlot(MyProgressBar.ToSharedRef());
    }

    return MyProgressBar.ToSharedRef();
}

PRAGMA_DISABLE_DEPRECATION_WARNINGS

void UKGProgressBar::SetRefreshRate(float InRefreshRate)
{
    RefreshRate = InRefreshRate;
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetRefreshRate(InRefreshRate);
    }
}

void UKGProgressBar::SetUseAnimOnValueChanged(bool bInUseAnim)
{
    bUseAnimOnValueChanged = bInUseAnim;
}

void UKGProgressBar::SynchronizeProperties()
{
    Super::SynchronizeProperties();

    if (!MyProgressBar.IsValid())
    {
        return;
    }

    TAttribute<TOptional<float>> PercentBinding = OPTIONAL_BINDING_CONVERT(float, Percent, TOptional<float>, ConvertFloatToOptionalFloat);
    TAttribute<FSlateColor> FillColorAndOpacityBinding = PROPERTY_BINDING(FSlateColor, FillColorAndOpacity);

    MyProgressBar->SetStyle(&GetWidgetStyle());

    MyProgressBar->SetBarFillType(GetBarFillType());
    MyProgressBar->SetBarFillStyle(GetBarFillStyle());
    MyProgressBar->SetPercent(UseMarquee() ? TOptional<float>() : PercentBinding);
    MyProgressBar->SetFillColorAndOpacity(FillColorAndOpacityBinding);
    MyProgressBar->SetBorderPadding(GetBorderPadding());
    MyProgressBar->SetCircularRadius(CircularRadius);

    float StartAngle = WrapAngle(FMath::DegreesToRadians(CircularStartAngle));
    float EndAngle = WrapAngle(FMath::DegreesToRadians(CircularEndAngle));
    if (StartAngle >= EndAngle)
    {
        StartAngle -= UE_TWO_PI;
    }

    MyProgressBar->SetCircularStartAngle(StartAngle);
    MyProgressBar->SetCircularEndAngle(EndAngle);

    MyProgressBar->SetCircularThickness(CircularThickness);
    MyProgressBar->SetThumbOffset(ThumbOffset);
    MyProgressBar->SetAlwaysShowThumb(bAlwaysShowThumb);
    MyProgressBar->SetHasThumb(bHasThumb);
}

const FProgressBarStyle& UKGProgressBar::GetWidgetStyle() const
{
    return WidgetStyle;
}

void UKGProgressBar::SetWidgetStyle(const FProgressBarStyle& InStyle)
{
    WidgetStyle = InStyle;
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetStyle(&WidgetStyle);
    }
}

const FSlateBrush& UKGProgressBar::GetThumbImage() const
{
    return ThumbImage;;
}

void UKGProgressBar::SetThumbImage(const FSlateBrush& InThumbImage)
{
    ThumbImage = InThumbImage;
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetThumbImage(&ThumbImage);
    }
}

float UKGProgressBar::GetPercent() const
{
    return Percent;
}

void UKGProgressBar::SetPercent(float InPercent)
{
    if (FMath::IsNearlyEqual(InPercent, GetPercent()))
    {
        return;
    }

    StartPercent = GetPercent();
    Percent = InPercent;
    if (!bUseAnimOnValueChanged)
    {
        CurPercent = GetPercent();
        if (MyProgressBar.IsValid())
        {
            MyProgressBar->SetPercent(InPercent);
        }
    }
    else
    {
        RegisterTick();
        bHasDuration = false;
    }
}

KGUI_API void UKGProgressBar::SetPercentWithDuration(float InPercent, float InDuration)
{
    StartPercent = GetPercent();
    CurPercent = StartPercent;
    Percent = InPercent;
    bHasDuration = true;
    Duration = FMath::Max(InDuration, KINDA_SMALL_NUMBER);
    CurTime = 0.f;
    bUseAnimOnValueChanged = true;
    RegisterTick();
}

EKGProgressBarFillType UKGProgressBar::GetBarFillType() const
{
    return BarFillType;
}

void UKGProgressBar::SetBarFillType(EKGProgressBarFillType InBarFillType)
{
    BarFillType = InBarFillType;
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetBarFillType(BarFillType);
    }
}

EProgressBarFillStyle::Type UKGProgressBar::GetBarFillStyle() const
{
    return BarFillStyle;
}

void UKGProgressBar::SetBarFillStyle(EProgressBarFillStyle::Type InBarFillStyle)
{
    BarFillStyle = InBarFillStyle;
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetBarFillStyle(BarFillStyle);
    }
}

bool UKGProgressBar::UseMarquee() const
{
    return bIsMarquee;
}

void UKGProgressBar::SetIsMarquee(bool InbIsMarquee)
{
    bIsMarquee = InbIsMarquee;
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetPercent(bIsMarquee ? TOptional<float>() : Percent);
    }
}

FVector2D UKGProgressBar::GetBorderPadding() const
{
    return BorderPadding;
}

void UKGProgressBar::SetBorderPadding(FVector2D InBorderPadding)
{
    BorderPadding = InBorderPadding;
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetBorderPadding(BorderPadding);
    }
}

FLinearColor UKGProgressBar::GetFillColorAndOpacity() const
{
    return FillColorAndOpacity;
}

void UKGProgressBar::SetFillColorAndOpacity(FLinearColor Color)
{
    FillColorAndOpacity = Color;
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetFillColorAndOpacity(FillColorAndOpacity);
    }
}


void UKGProgressBar::Tick(float DeltaTime)
{
    if (FMath::Abs(CurPercent - GetPercent()) <= KINDA_SMALL_NUMBER)
    {
        return;
    }

    FVector2D PixSize = GetCachedGeometry().GetLocalSize();
    if (PixSize.X <= 0 || PixSize.Y <= 0)
    {
        if (MyProgressBar.IsValid())
        {
            PixSize = MyProgressBar->GetDesiredSize();
        }
        else
        {
            return;
        }
    }
    
    float Size = 0.f;
    switch (GetBarFillType())
    {
    case EKGProgressBarFillType::LeftToRight:
    case EKGProgressBarFillType::RightToLeft:
        Size = PixSize.X - GetBorderPadding().X * 2;
        break;
    case EKGProgressBarFillType::FillFromCenterHorizontal:
        Size = (PixSize.X - GetBorderPadding().X * 2) / 2.f;
        break;
    case EKGProgressBarFillType::TopToBottom:
    case EKGProgressBarFillType::BottomToTop:
        Size = PixSize.Y - GetBorderPadding().Y * 2;
        break;
    case EKGProgressBarFillType::FillFromCenterVertical:
        Size = (PixSize.Y - GetBorderPadding().Y * 2) / 2.f;
        break;
    case EKGProgressBarFillType::FillFromCenter:
        Size = (PixSize.X - GetBorderPadding().X * 2) * (PixSize.Y - GetBorderPadding().Y * 2);
        break;
    case EKGProgressBarFillType::Radial:
        Size = CircularEndAngle - CircularStartAngle;
        break;
    }

    float delta = FMath::Abs(GetPercent() - CurPercent) * Size;
    float NewPercent;
    if (delta <= 1)
    {
        NewPercent = GetPercent();
    }
    else
    {
        if (bHasDuration)
        {
            CurTime += DeltaTime;
            float t = FMath::Min(CurTime / Duration, 1.f);
            NewPercent = FMath::Lerp(StartPercent, GetPercent(), t);
        }
        else
        {
            NewPercent = FMath::Lerp(CurPercent, GetPercent(), DeltaTime * AnimSpeed);
        }
    }

    CurPercent = FMath::Abs(NewPercent - GetPercent()) <= KINDA_SMALL_NUMBER ? GetPercent() : NewPercent;
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetPercent(CurPercent);
    }
}

UClass* UKGProgressBar::GetSlotClass() const
{
    return UKGProgressBarSlot::StaticClass();
}

void UKGProgressBar::OnSlotAdded(UPanelSlot* InSlot)
{
    if (MyProgressBar.IsValid())
    {
        CastChecked<UKGProgressBarSlot>(InSlot)->BuildSlot(MyProgressBar.ToSharedRef());
    }
}

void UKGProgressBar::OnSlotRemoved(UPanelSlot* InSlot)
{
    if (MyProgressBar.IsValid())
    {
        MyProgressBar->SetContent(SNullWidget::NullWidget);
    }
}

PRAGMA_ENABLE_DEPRECATION_WARNINGS

#if WITH_EDITOR
void UKGProgressBar::OnCreationFromPalette()
{
    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    FillColorAndOpacity = FLinearColor(1.f, 1.f, 1.0f);
    PRAGMA_ENABLE_DEPRECATION_WARNINGS
}
#endif
