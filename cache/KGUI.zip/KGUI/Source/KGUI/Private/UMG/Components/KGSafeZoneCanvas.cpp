// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGSafeZoneCanvas.h"
#include "UMG/Components/KGSafeZoneCavansSlot.h"

#if WITH_EDITOR
void UKGSafeZoneCanvas::OnDesignerChanged(const FDesignerChangedEventArgs& EventArgs)
{
	if ( EventArgs.bScreenPreview )
	{
		DesignerSize = EventArgs.Size;
	}
	else
	{
		DesignerSize = FVector2D(0, 0);
	}

	DesignerDpi = EventArgs.DpiScale;

	if ( MyCanvas.IsValid() )
	{
		MyCanvas->SetOverrideScreenInformation(DesignerSize, DesignerDpi);
	}
}

#endif

void UKGSafeZoneCanvas::UpdateWidgetProperties()
{
	if (MyCanvas.IsValid() && GetChildrenCount() > 0)
	{
		MyCanvas->SetSidesToPad( PadLeft, PadRight, PadTop, PadBottom );
	}
}



void UKGSafeZoneCanvas::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);

	MyCanvas.Reset();
}

void UKGSafeZoneCanvas::SynchronizeProperties()
{
	Super::SynchronizeProperties();

	// TODO: 填充SafeZone相关属性变更
}

TSharedRef<SWidget> UKGSafeZoneCanvas::RebuildWidget()
{
	MyCanvas = SNew(SKGSafeZoneConstraintCanvas)
		.PadLeft(PadLeft)
		.PadRight(PadRight)
		.PadTop(PadTop)
		.PadBottom(PadBottom)
#if WITH_EDITOR
		.OverrideScreenSize(DesignerSize)
		.OverrideDpiScale((DesignerDpi))
#endif
		;

	for ( UPanelSlot* PanelSlot : Slots )
	{
		if ( UCanvasPanelSlot* TypedSlot = Cast<UCanvasPanelSlot>(PanelSlot) )
		{
			TypedSlot->Parent = this;
			TypedSlot->BuildSlot(MyCanvas.ToSharedRef());
		}
	}

	return MyCanvas.ToSharedRef();
	
}

#pragma region SafeZone
void UKGSafeZoneCanvas::SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom)
{
	PadLeft = InPadLeft;
	PadRight = InPadRight;
	PadTop = InPadTop;
	PadBottom = InPadBottom;

	if (MyCanvas.IsValid() && GetChildrenCount() > 0)
	{
		MyCanvas->SetSidesToPad(PadLeft, PadRight, PadTop, PadBottom);
	}
}

void UKGSafeZoneCanvas::SetPadLeft(bool InPadLeft)
{
	if (PadLeft != InPadLeft)
	{
		SetSidesToPad(InPadLeft, PadRight, PadTop, PadBottom);
	}
}

bool UKGSafeZoneCanvas::GetPadLeft() const
{
	return PadLeft;
}

void UKGSafeZoneCanvas::SetPadRight(bool InPadRight)
{
	if (PadRight != InPadRight)
	{
		SetSidesToPad(PadLeft, InPadRight, PadTop, PadBottom);
	}
}

bool UKGSafeZoneCanvas::GetPadRight() const
{
	return PadRight;
}

void UKGSafeZoneCanvas::SetPadTop(bool InPadTop)
{
	if (PadTop != InPadTop)
	{
		SetSidesToPad(PadLeft, PadRight, InPadTop, PadBottom);
	}
}

bool UKGSafeZoneCanvas::GetPadTop() const
{
	return PadTop;
}

void UKGSafeZoneCanvas::SetPadBottom(bool InPadBottom)
{
	if (PadBottom != InPadBottom)
	{
		SetSidesToPad(PadLeft, PadRight, PadTop, InPadBottom);
	}
}

bool UKGSafeZoneCanvas::GetPadBottom() const
{
	return PadBottom;
}

#pragma endregion



