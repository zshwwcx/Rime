#include "UMG/Components/IKGTextCountDown.h"

void IKGTextCountDown::ReleaseCountDown() const
{
	TextCountDownController.Reset();
}

FKGTextCountDownController& IKGTextCountDown::GetOrCreateCountDownController() const
{
	if (!TextCountDownController.IsValid())
	{
		auto Object = Cast<UObject>(this);
		TextCountDownController = MakeShared<FKGTextCountDownController>(Object);
		TextCountDownController->SetOnCountDownFinished(TDelegate<void()>::CreateRaw(const_cast<IKGTextCountDown*>(this), &IKGTextCountDown::HandleOnCountDownFinished));
		TextCountDownController->SetOnTextChanged(TDelegate<void(FText&&)>::CreateRaw(const_cast<IKGTextCountDown*>(this), &IKGTextCountDown::HandleOnCountDownTextChanged));
	}
	return *TextCountDownController;
}
