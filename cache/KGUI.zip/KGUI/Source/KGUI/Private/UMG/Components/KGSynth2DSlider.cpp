#include "UMG/Components/KGSynth2DSlider.h"

#include "Materials/MaterialInstanceDynamic.h"
#include "UI/SSynth2DSlider.h"

UMaterialInstanceDynamic* UKGSynth2DSlider::GetBGImageDynamicMaterial()
{
	UMaterialInterface* Material = nullptr;
	UObject* Resource = WidgetStyle.BackgroundImage.GetResourceObject();
	
	Material = Cast<UMaterialInterface>(Resource);

	if ( Material )
	{
		UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(Material);

		if ( !DynamicMaterial )
		{
			DynamicMaterial = UMaterialInstanceDynamic::Create(Material, this);
			
			if (WidgetStyle.BackgroundImage.GetResourceObject() != DynamicMaterial)
			{
				WidgetStyle.BackgroundImage.SetResourceObject(DynamicMaterial);
				
				if (MySlider.IsValid())
				{
					MySlider->Invalidate(EInvalidateWidgetReason::Layout);
				}
			}
		}
		return DynamicMaterial;
	}

	return nullptr;
}
