// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: tangshenghao@kuaishou.com

#include "UMG/Components/KGPolygon.h"
//#define LOCTEXT_NAMESPACE "UMG"

void UKGPolygon::SynchronizeProperties() {
	Super::SynchronizeProperties();
	MyPolygon->SetBrush(&Brush);
}
void UKGPolygon::ReleaseSlateResources(bool bReleaseChildren) {
	MyPolygon.Reset();
}

#if WITH_EDITOR
/*const FText UKGPolygon::GetPaletteCategory() {
	return LOCTEXT("CustomCategory","C7Custom");
}*/
#endif

TSharedRef<SWidget> UKGPolygon::RebuildWidget() {
	MyPolygon = SNew(SPolygon)
		.Brush(&Brush)
		.PolygonPoints(PolygonPoints)
		.LineColor(LineColor)
		.FillColor(FillColor);
	return MyPolygon.ToSharedRef();
}

//#undef LOCTEXT_NAMESPACE
