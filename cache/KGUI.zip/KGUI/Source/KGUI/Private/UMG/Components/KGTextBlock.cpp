// Fill out your copyright notice in the Description page of Project Settings.

#include "UMG/Components/KGTextBlock.h"
#include "Engine/DataTable.h"
#include "Engine/World.h"
#include "UMG/Blueprint/KGTextBlockStyle.h"
//@C7 Code Begin (@pengwei03)
#include "KGUISettings.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Widgets/Text/STextBlock.h"
//@C7 Code End (@pengwei03)
#include "KGUI.h"
#include "Core/Common.h"
#include "Engine/GameInstance.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Text/TextLayout.h"
#include "Framework/Text/ILayoutBlock.h"
#include "Kismet/GameplayStatics.h"

//Modify By Bruce Start 2023.8.28
void UKGTextBlock::SetLatterSpaceAnim(float InLetterSpacing)
{
	FSlateFontInfo TempFont = GetFont();
	TempFont.LetterSpacing = static_cast<int32>(InLetterSpacing);
	SetFont(TempFont);
}
//Modify By Bruce End 2023.8.28

void UKGTextBlock::PostInitProperties()
{
	Super::PostInitProperties();
#if WITH_EDITOR
	UpdateFromStyle();
#endif
}

void UKGTextBlock::PostLoad()
{
	Super::PostLoad();
#if WITH_EDITOR
	UpdateFromStyle();
#endif
}

void UKGTextBlock::SynchronizeProperties()
{
#if WITH_EDITOR
	UpdateFromStyle();
#endif
	Super::SynchronizeProperties();
	//@C7 Code Begin (@pengwei03)
	if (MyTextBlock.IsValid())
	{
		SetAlwaysEllipsis(AlwaysEllipsis);
	}
	//@C7 Code End (@pengwei03)
}

void UKGTextBlock::Serialize(FArchive& Ar)
{
#if WITH_EDITORONLY_DATA
	if (Style && Ar.IsSaving())
	{
		UpdateFromStyle();
		Super::Serialize(Ar);
	}
	else
#endif
	{
		Super::Serialize(Ar);
	}
}

#if WITH_EDITOR

void UKGTextBlock::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	if (auto Settings = GetDefault<UKGUISettings>())
	{
		Font = Settings->DefaultTextBlockStyle.Font;
		ColorAndOpacity = Settings->DefaultTextBlockStyle.ColorAndOpacity;
		ShadowOffset = Settings->DefaultTextBlockStyle.ShadowOffset;
		ShadowColorAndOpacity = Settings->DefaultTextBlockStyle.ShadowColorAndOpacity;
		StrikeBrush = Settings->DefaultTextBlockStyle.StrikeBrush;
		TextTransformPolicy = Settings->DefaultTextBlockStyle.TransformPolicy;
		TextOverflowPolicy = Settings->DefaultTextBlockStyle.OverflowPolicy;
	}
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	if (auto KGUI = FModuleManager::Get().GetModulePtr<FKGUIModule>("KGUI"))
	{
		KGUI->GetOnWidgetCreatedFromPalette().Broadcast(this);
	}
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

bool UKGTextBlock::CanEditChange(const FProperty* InProperty) const
{
	if (Super::CanEditChange(InProperty))
	{
PRAGMA_DISABLE_DEPRECATION_WARNINGS
		if (Style)
		{
			static TArray<FName> InvalidPropertyWithStyle =
			{
				GET_MEMBER_NAME_CHECKED(UKGTextBlock, Font),
				GET_MEMBER_NAME_CHECKED(UKGTextBlock, Margin),
				GET_MEMBER_NAME_CHECKED(UKGTextBlock, LineHeightPercentage),
				GET_MEMBER_NAME_CHECKED(UKGTextBlock, ShadowOffset),
				GET_MEMBER_NAME_CHECKED(UKGTextBlock, ShadowColorAndOpacity)
			};
			return !InvalidPropertyWithStyle.Contains(InProperty->GetFName());
		}
PRAGMA_ENABLE_DEPRECATION_WARNINGS
		return true;
	}
	return false;
}
#endif

void UKGTextBlock::SetTextStyle(UKGTextBlockStyle* StyleAsset)
{
	Style = StyleAsset;
	UpdateFromStyle();
}

void UKGTextBlock::UpdateFromStyle()
{
	if (Style)
	{
		SetFont(Style->Font);
		Margin = Style->Margin;
		LineHeightPercentage = Style->LineHeightPercentage;
		SetShadowOffset(Style->ShadowOffset);
		SetShadowColorAndOpacity(Style->ShadowColorAndOpacity);
	}
}

//@C7 Code Begin (@pengwei03)
//Compute Text Block Size
FVector2D UKGTextBlock::GetTextScale(const FText& inText, bool useViewportScale)
{
	if (useViewportScale)
	{
		float inScale = UWidgetLayoutLibrary::GetViewportScale(GetWorld());
		return MyTextBlock->GetTextLayoutSize(inText, useViewportScale, inScale);
	}
	else
	{
		return MyTextBlock->GetTextLayoutSize(inText, useViewportScale, 0);
	}


}

//Center - RightEllipsis
void UKGTextBlock::SetAlwaysEllipsis(bool InAlwaysEllipsis)
{
	AlwaysEllipsis = InAlwaysEllipsis;
	MyTextBlock->SetAlwaysEllipsis(InAlwaysEllipsis);
}
bool UKGTextBlock::GetAlwaysEllipsis() const
{
	return AlwaysEllipsis;
}

//Adaptive Line
void UKGTextBlock::SetTextAdaptively(const FText& inText)
{
	MyTextBlock->SetAdaptiveOffset(0.0f);
	FVector2D textSize = GetTextScale(inText, true);
	if (MyTextBlock->GetLineModelNum() == 1)
	{
		float offset = 0.f;
		TArray<FVector2D> lineViewSize = MyTextBlock->GetLineViewsSize();
		if (lineViewSize.Num() > 1)
		{
			int32 lineNum = lineViewSize.Num();
			float maxWidth = 0;
			for (int i = 0; i < lineNum; i++)
			{
				if (lineViewSize[i].X > maxWidth)
				{
					maxWidth = lineViewSize[i].X;
				}
			}

			float lastLineWidth = lineViewSize[lineNum - 1].X;
			int32 leftlineNum = lineNum - 1;
			if (lastLineWidth < maxWidth * 0.3f && lineNum > 2)
			{
				offset = (0.3f * maxWidth - lastLineWidth) / (1.0f + 0.3f / leftlineNum);
			}
			else if (lastLineWidth < maxWidth * 0.2f && lineNum == 2)
			{
				offset = (0.2f * maxWidth - lastLineWidth) / 1.2f;
			}

			MyTextBlock->SetAdaptiveOffset(offset);
			FVector2D newSize = GetTextScale(inText, true);
			float k = 0;
		}

	}

	SetText(inText);
}

int32 UKGTextBlock::GetTextLineNum()
{
	if (MyTextBlock.IsValid())
	{
 		TArray<FVector2D> lineViewSize = MyTextBlock->GetLineViewsSize();
		return lineViewSize.Num();
	}
	else
	{
		return 0;
	}
}

//@C7 Code End(@pengwei03)

bool UKGTextBlock::GetRunLocationAndSizeByRange(const int32 BeginIndex, const int32 EndIndex, FVector2D& OutLocation, FVector2D& OutSize)
{
	if (!MyTextBlock.IsValid())
	{
		return false;
	}
	
	const TArray<FTextLayout::FLineView> lineViews = MyTextBlock->GetLayoutLineView();
	FTextRange RunRange(BeginIndex, EndIndex);
	for (FTextLayout::FLineView lineView : lineViews)
	{
		for(const TSharedRef<ILayoutBlock>& Block : lineView.Blocks)
		{
			const FTextRange Intersection = Block->GetTextRange().Intersect(RunRange);
			if (Intersection.BeginIndex >= RunRange.BeginIndex && Intersection.EndIndex <= RunRange.EndIndex && Intersection.BeginIndex < Intersection.EndIndex)
			{
				float InverseScale = Inverse(GetCachedGeometry().Scale);
				FVector2D SizePattern = Block->GetRun()->Measure(Intersection.BeginIndex, Intersection.EndIndex, GetCachedGeometry().Scale, 
				Block->GetTextContext());
				FVector2D Offset = Block->GetRun()->GetLocationAt(Block, Intersection.BeginIndex - Block->GetTextRange().BeginIndex, 
				GetCachedGeometry().Scale);
				Offset.Y = Block->GetLocationOffset().Y; // Because pattern text is on the same line of block, so offset Y is same with the offset Y of block.
				FGeometry& MutableGeometry = const_cast<FGeometry&>(GetCachedGeometry());
				FPaintGeometry PaintGeometry = MutableGeometry.ToPaintGeometry(
					TransformVector(InverseScale, SizePattern),
					FSlateLayoutTransform(TransformPoint(InverseScale, Offset))
				);
				OutLocation.Set(PaintGeometry.DrawPosition.X, PaintGeometry.DrawPosition.Y);
				OutSize = TransformVector(InverseScale, SizePattern);
				return true;
			}
		}
	}
	return false;
}

void UKGTextBlock::SetText(FText InText)
{
#if WITH_EDITOR
	const bool bEnableTextBlockChangeCheck = GetDefault<UKGUISettings>()->bEnableTextBlockChangeCheck;
#else
	const static bool bEnableTextBlockChangeCheck = GetDefault<UKGUISettings>()->bEnableTextBlockChangeCheck;
#endif
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	if (bEnableTextBlockChangeCheck && !TextDelegate.IsBound() && (Text.IdenticalTo(InText) || (Text.IsInitializedFromString() && InText.IsInitializedFromString() && Text.EqualTo(InText))))
	{
		return;
	}
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	Super::SetText(InText);
}

TSharedRef<SWidget> UKGTextBlock::RebuildWidget()
{
	return RebuildWidgetInternal<SKGTextBlock>("SKGTextBlock");
}

#pragma region 计时动态效果

void UKGTextBlock::SetCountDownTimeFormat(const FString& Format)
{
	GetOrCreateCountDownController().SetCountDownTimeFormat(Format);
}

void UKGTextBlock::SetCountDownTimeFormatByCondition(
	double LowerBoundSeconds, EKGCountDownConditionIntervalType LowerIntervalType,
	double UpperBoundSeconds, EKGCountDownConditionIntervalType UpperIntervalType,
	const FString& Format)
{
	GetOrCreateCountDownController().SetCountDownTimeFormatByCondition(LowerBoundSeconds, LowerIntervalType, UpperBoundSeconds, UpperIntervalType, Format);
}

void UKGTextBlock::SetCountDownTimeFormatByFirstNonzeroUnit(FName FirstNonzeroUnitName, const FString& Format)
{
	GetOrCreateCountDownController().SetCountDownTimeFormatByFirstNonzeroUnit(FirstNonzeroUnitName, Format);
}

void UKGTextBlock::ClearCountDownTimeFormats()
{
	GetOrCreateCountDownController().ClearCountDownTimeFormats();
}

void UKGTextBlock::PlayCountDown(double FromSeconds, double ToSeconds)
{
	GetOrCreateCountDownController().PlayCountDown(FromSeconds, ToSeconds);
}

void UKGTextBlock::StopCountDown()
{
	GetOrCreateCountDownController().StopCountDown();
}

bool UKGTextBlock::IsCountDownPlaying() const
{
	return GetOrCreateCountDownController().IsCountDownPlaying();
}

void UKGTextBlock::BeginDestroy()
{
	ReleaseCountDown();
	Super::BeginDestroy();
}

void UKGTextBlock::HandleOnCountDownFinished()
{
	BP_OnCountDownFinished.Broadcast();
}

void UKGTextBlock::HandleOnCountDownTextChanged(FText&& InText)
{
	this->SetText(InText);
}

#pragma endregion
