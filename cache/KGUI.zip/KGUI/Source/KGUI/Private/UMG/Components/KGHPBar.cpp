#include "UMG/Components/KGHPBar.h"

// Copyright Epic Games, Inc. All Rights Reserved.

#include "Components/ButtonSlot.h"
#include "Widgets/SNullWidget.h"
#include "Widgets/Input/SButton.h"
#include "Components/Widget.h"
#include "Core/Common.h"
#include "Slate/Components/SKGHPBar.h"
#include "UMG/Blueprint/KGSlice9Data.h"

#define LOCTEXT_NAMESPACE "KGUI"

/////////////////////////////////////////////////////
// UKGHpBarSlot

UKGHpBarSlot::UKGHpBarSlot(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
{
    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    Padding = FMargin(4.f, 2.f);

    HorizontalAlignment = HAlign_Center;
    VerticalAlignment = VAlign_Center;
    PRAGMA_ENABLE_DEPRECATION_WARNINGS
}

void UKGHpBarSlot::ReleaseSlateResources(bool bReleaseChildren)
{
    Super::ReleaseSlateResources(bReleaseChildren);

    HpBar.Reset();
}

void UKGHpBarSlot::BuildSlot(TSharedRef<SKGHPBar> InHpBar)
{
    HpBar = InHpBar;

    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    InHpBar->SetPadding(Padding);
    InHpBar->SetHAlign(HorizontalAlignment);
    InHpBar->SetVAlign(VerticalAlignment);
    PRAGMA_ENABLE_DEPRECATION_WARNINGS

    InHpBar->SetContent(Content ? Content->TakeWidget() : SNullWidget::NullWidget);
}

PRAGMA_DISABLE_DEPRECATION_WARNINGS

FMargin UKGHpBarSlot::GetPadding() const
{
    return Padding;
}

void UKGHpBarSlot::SetPadding(FMargin InPadding)
{
    Padding = InPadding;
    if (HpBar.IsValid())
    {
        HpBar.Pin()->SetPadding(InPadding);
    }
}

EHorizontalAlignment UKGHpBarSlot::GetHorizontalAlignment() const
{
    return HorizontalAlignment;
}

void UKGHpBarSlot::SetHorizontalAlignment(EHorizontalAlignment InHorizontalAlignment)
{
    HorizontalAlignment = InHorizontalAlignment;
    if (HpBar.IsValid())
    {
        HpBar.Pin()->SetHAlign(InHorizontalAlignment);
    }
}

EVerticalAlignment UKGHpBarSlot::GetVerticalAlignment() const
{
    return VerticalAlignment;
}

void UKGHpBarSlot::SetVerticalAlignment(EVerticalAlignment InVerticalAlignment)
{
    VerticalAlignment = InVerticalAlignment;
    if (HpBar.IsValid())
    {
        HpBar.Pin()->SetVAlign(InVerticalAlignment);
    }
}

PRAGMA_ENABLE_DEPRECATION_WARNINGS

void UKGHpBarSlot::SynchronizeProperties()
{
    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    SetPadding(Padding);
    SetHorizontalAlignment(HorizontalAlignment);
    SetVerticalAlignment(VerticalAlignment);
    PRAGMA_ENABLE_DEPRECATION_WARNINGS
}


//
// UKGHPBar 
//
UKGHPBar::UKGHPBar(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
{
    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    
    FillColorAndOpacity = FLinearColor::White;
    Size = FVector2D(120, 30);
    PRAGMA_ENABLE_DEPRECATION_WARNINGS
}

void UKGHPBar::SetPercent(FName InLayerName, float InPercent)
{
    if (auto* Layer = GetLayer(InLayerName))
    {
        Layer->Percent = InPercent;

        if (MyHpBar.IsValid())
        {
            MyHpBar->SetLayerPercent(InLayerName, InPercent);
        }
    }
}

void UKGHPBar::SetPercentWithAnim(FName InLayerName, float InPercent, float InDuration, bool bInKeepLastLeftTime)
{
    if (!bUsingPercentAnim)
    {
        SetPercent(InLayerName, InPercent);
        return;
    }
    
    if (auto* Layer = GetLayer(InLayerName))
    {
        Layer->Percent = InPercent;
        Layer->StartPercent = Layer->CurPercent;
        if (InDuration > 0.f)
        {
            float LeftTime = bInKeepLastLeftTime ? FMath::Max(Layer->Duration - Layer->CurTime, 0) : 0.f;
            Layer->Duration = InDuration + LeftTime;
            Layer->CurTime = 0;
        }
        else
        {
            Layer->Duration = 0.f;
            Layer->CurTime = 0.f;
        }
        
        LayerNamesAnimating.Add(InLayerName);
        bHasAnim = true;
        RegisterTick();
    }
}

void UKGHPBar::SetAnimStartPercent(FName InLayerName, float InPercent)
{
    if (auto* Layer = GetLayer(InLayerName))
    {
        Layer->CurPercent = InPercent;
        Layer->StartPercent = Layer->CurPercent;
    }
}

float UKGHPBar::GetLayerPercent(FName InLayerName) const
{
    if (auto* Layer = GetLayer(InLayerName))
    {
        return Layer->Percent;
    }

    return 0.f;
}

void UKGHPBar::SetLayerVisibility(FName InLayerName, bool bVisible)
{
    if (auto* Layer = GetLayer(InLayerName))
    {
        Layer->bVisible = bVisible;
        if (MyHpBar.IsValid())
        {
            MyHpBar->SetLayerVisibility(InLayerName, bVisible);
        }
    }
}

bool UKGHPBar::IsLayerVisible(FName InLayerName) const
{
    if (auto* Layer = GetLayer(InLayerName))
    {
        if (MyHpBar.IsValid())
        {
            return MyHpBar->IsLayerVisible(InLayerName);
        }

        return Layer->bVisible;
    }

    return false;
}

FLinearColor UKGHPBar::GetFillColorAndOpacity() const
{
    return FillColorAndOpacity;
}

void UKGHPBar::SetFillColorAndOpacity(FLinearColor InColor)
{
    FillColorAndOpacity = InColor;
    if (MyHpBar.IsValid())
    {
        MyHpBar->SetFillColorAndOpacity(InColor);
    }
}

void UKGHPBar::SynchronizeProperties()
{
    Super::SynchronizeProperties();
    if (MyHpBar.IsValid())
    {
        for (int32 Index = 0; Index < Layers.Num(); ++Index)
        {
            UKGSlice9Data::TryApply(Layers[Index].Brush);
            MyHpBar->SetLayer(Layers[Index].Name, Layers[Index]);
        }
        
        MyHpBar->SetFillColorAndOpacity(FillColorAndOpacity);
    }
}

void UKGHPBar::ReleaseSlateResources(bool bReleaseChildren)
{
    if (!HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
    {
        UnregisterTick();
    }
    
    if (MyHpBar.IsValid())
    {
        MyHpBar.Reset();
    }

    Super::ReleaseSlateResources(bReleaseChildren);
}

bool UKGHPBar::TweenPercent(FKGHPBarLayer& Layer, float DeltaTime)
{
    float Delta = Layer.Percent - Layer.CurPercent;
    if (FMath::Abs(Delta) <= KINDA_SMALL_NUMBER)
    {
        return false;
    }
    
    float NewPercent;
    if (Layer.Duration > 0.f)
    {
        float CurTime = Layer.CurTime + DeltaTime;
        Delta = CurTime > Layer.Duration ? Layer.Duration - Layer.CurTime : DeltaTime; 
        Layer.CurTime += Delta;
        NewPercent = FMath::Lerp(Layer.StartPercent, Layer.Percent, Layer.CurTime / Layer.Duration);
    }
    else
    {
        NewPercent = FMath::Lerp(Layer.CurPercent, Layer.Percent, Layer.AnimSpeed * DeltaTime);
        Layer.CurTime += DeltaTime;
    }
    
    bool bIsDone = false;
    if ( (NewPercent - Layer.Percent) * (NewPercent - Layer.CurPercent) >= 0 && NewPercent != Layer.CurPercent)
    {
        NewPercent = Layer.Percent;
        bIsDone = true;
    }

    Layer.CurPercent = NewPercent;
    UE_LOG(LogKGUI, Log, TEXT("UKGHPBar::TweenPercent %s Percent: %f curTime:%.4f"), *Layer.Name.ToString(), NewPercent, Layer.CurTime);
    
    if (MyHpBar.IsValid())
    {
        MyHpBar->SetLayerPercent(Layer.Name, NewPercent);
    }

    return !bIsDone;
}

void UKGHPBar::Tick(float DeltaTime)
{
    bool bHasAnimRunning = false;
    for (auto& Layer : Layers)
    {
        if (LayerNamesAnimating.Contains(Layer.Name))
        {
        	if (TweenPercent(Layer, DeltaTime))
        	{
        		bHasAnimRunning = true;
        	}
        	else
        	{
        		LayerNamesAnimating.Remove(Layer.Name);
        	}
        }
    }

    bHasAnim = bHasAnimRunning;
}

#if WITH_EDITOR
const FText UKGHPBar::GetPaletteCategory()
{
    return LOCTEXT("KGUI", "KGUI");
}

void UKGHPBar::OnCreationFromPalette()
{
    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    FillColorAndOpacity = FLinearColor(1.f, 1.f, 1.0f, 1.f);
    Size = FVector2D(120, 30);
    PRAGMA_ENABLE_DEPRECATION_WARNINGS
}

#endif

UClass* UKGHPBar::GetSlotClass() const
{
    return UKGHpBarSlot::StaticClass();
}

void UKGHPBar::OnSlotAdded(UPanelSlot* InSlot)
{
    if (MyHpBar.IsValid())
    {
        CastChecked<UKGHpBarSlot>(InSlot)->BuildSlot(MyHpBar.ToSharedRef());
    }
}

void UKGHPBar::OnSlotRemoved(UPanelSlot* InSlot)
{
    if (MyHpBar.IsValid())
    {
        MyHpBar->SetContent(SNullWidget::NullWidget);
    }
}

TSharedRef<SWidget> UKGHPBar::RebuildWidget()
{
    PRAGMA_DISABLE_DEPRECATION_WARNINGS
    MyHpBar = SNew(SKGHPBar);
    PRAGMA_ENABLE_DEPRECATION_WARNINGS

    if (MyHpBar.IsValid())
    {
        for (int32 Index = 0; Index < Layers.Num(); ++Index)
        {
            MyHpBar->SetLayer(Layers[Index].Name, Layers[Index]);
            
        }
        MyHpBar->SetFillColorAndOpacity(FillColorAndOpacity);
    }

    if (GetChildrenCount() > 0)
    {
        Cast<UKGHpBarSlot>(GetContentSlot())->BuildSlot(MyHpBar.ToSharedRef());
    }

    return MyHpBar.ToSharedRef();
}

FKGHPBarLayer* UKGHPBar::GetLayer(FName InLayerName)
{
    for (auto& Layer : Layers)
    {
        if (Layer.Name == InLayerName)
        {
            return &Layer;
        }
    }

    return nullptr;
}

const FKGHPBarLayer* UKGHPBar::GetLayer(FName InLayerName) const
{
    for (auto& Layer : Layers)
    {
        if (Layer.Name == InLayerName)
        {
            return &Layer;
        }
    }

    return nullptr;
}

#if WITH_ACCESSIBILITY
TSharedPtr<SWidget> UKGHPBar::GetAccessibleWidget() const
{
    return MyHpBar;
}
#endif


#undef LOCTEXT_NAMESPACE
