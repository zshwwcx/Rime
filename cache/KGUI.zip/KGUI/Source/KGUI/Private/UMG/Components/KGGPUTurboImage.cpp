#include "UMG/Components/KGGPUTurboImage.h"

#include "TextureCompiler.h"
#include "Core/Common.h"
#include "Core/DynamicAtlas/DynamicAtlasSubsystem.h"
#include "Core/DynamicAtlas/DynamicSprite.h"
#include "Engine/Texture2DDynamic.h"
#include "Framework/Application/SlateApplication.h"
#include "Materials/MaterialInterface.h"
#include "Widgets/SlateGPUTurboWidgets.h"

UKGGPUTurboImage::UKGGPUTurboImage(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
    , CurPercentForAnim(0.f)
    , StartPercentForAnim(0.f)
{
}

void UKGGPUTurboImage::SetGPUShowPercentWithAnim(float InPercentX, float InPercentY, float InDuration)
{
    if (!bUsingPercentAnim)
    {
        SetGPUShowPercent(FVector2f(InPercentX, InPercentY));
        return;
    }
    
    AnimTime = 0.f;
    AnimDuration = FMath::Max(InDuration, KINDA_SMALL_NUMBER);
    StartPercentForAnim = CurPercentForAnim;
    FVector2f TempPercent = GetGPUShowPercent();
    SetGPUShowPercent(FVector2f(InPercentX, InPercentY));
    if (MyImage.IsValid())
    {
        MyImage->SetGPUShowPercent(TempPercent);
    }
    
    bHasAnim = true;
    RegisterTick();
}

void UKGGPUTurboImage::SetCurPercentForAnim(float InPercentX, float InPercentY)
{
    // 强制取消Tween动画
    bHasAnim = false;
    
    CurPercentForAnim.X = InPercentX;
    CurPercentForAnim.Y = InPercentY;
}

float UKGGPUTurboImage::GetCurPercentXForAnim()
{
    return CurPercentForAnim.X;
}

float UKGGPUTurboImage::GetCurPercentYForAnim()
{
    return CurPercentForAnim.Y;
}

void UKGGPUTurboImage::ReleaseSlateResources(bool bReleaseChildren)
{
    if (!HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
    {
        UnregisterTick();
    }
	Super::ReleaseSlateResources(bReleaseChildren);

	if (auto DynamicAtlasSubsystem = UDynamicAtlasSubsystem::GetInstance(this))
	{
		TryUnregisterDynamicAtlasResizedDelegate(DynamicAtlasSubsystem);
	}
}

void UKGGPUTurboImage::SynchronizeProperties()
{
	if (auto DynamicSprite = Cast<UDynamicSprite>(GPUTurboBrush.MainTex))
	{
		TryInitializeDynamicSprite(DynamicSprite);
	}
	
	Super::SynchronizeProperties();
}

void UKGGPUTurboImage::SetBrushFromAtlasInterface(TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize)
{
	if (GPUTurboBrush.MainTex != AtlasRegion.GetObject())
	{
		if (auto DynamicSprite = Cast<UDynamicSprite>(AtlasRegion.GetObject()))
		{
			TryInitializeDynamicSprite(DynamicSprite);
		}
	}
	
	Super::SetBrushFromAtlasInterface(AtlasRegion, bMatchSize);
}

void UKGGPUTurboImage::SetBrushFromTexture(UTexture2D* Texture, bool bMatchSize)
{
	CancelImageStreaming();

	if (GPUTurboBrush.MainTex != Texture)
	{
		GPUTurboBrush.MainTex = Texture;
		// BroadcastFieldValueChanged(FFieldNotificationClassDescriptor::Brush);

		if (Texture) // Since this texture is used as UI, don't allow it affected by budget.
		{
			Texture->bForceMiplevelsToBeResident = true;
			Texture->bIgnoreStreamingMipBias = true;
#if WITH_EDITOR
			FTextureCompilingManager::Get().FinishCompilation({ Texture });
#endif
		}

		GPUTurboBrush.Update(bMatchSize);

		if (MyImage.IsValid())
		{
			MyImage->InvalidateImage();
		}
	}
}

bool UKGGPUTurboImage::SetBrushFromTextureTryingToUseDynamicSprite(UTexture2D* Texture, bool bMatchSize)
{
	if (auto DynamicAtlasSubsystem = UDynamicAtlasSubsystem::GetInstance(this))
	{
		if (auto DynamicSprite = DynamicAtlasSubsystem->NewSprite(Texture))
		{
			this->SetBrushFromAtlasInterface(DynamicSprite, bMatchSize);
			return true;
		}
	}
	this->SetBrushFromTexture(Texture, bMatchSize);
	return false;
}

void UKGGPUTurboImage::SetBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize, bool bHiddenDuringLoading)
{
	TSoftObjectPtr<UObject> SoftObject = TSoftObjectPtr<UObject>(SoftObjectPath);
	if (SoftObject.IsNull())
	{
		UE_LOG(LogKGUI, Warning, TEXT("Try to SetBrushFromSoftObject (%s) Which is Null!"), *SoftObjectPath);
		return;
	}
	SetBrushFromSoftObject(SoftObject, bMatchSize, bHiddenDuringLoading);
}

void UKGGPUTurboImage::SetBrushFromSoftObject(TSoftObjectPtr<UObject> SoftObject, bool bMatchSize, bool bHiddenDuringLoading)
{
	if (SoftObject.IsNull())
	{
		UE_LOG(LogKGUI, Warning, TEXT("Try to SetBrushFromSoftObject Which is Null!"));
		return;
	}
	CancelImageStreaming();  // IMPORTANT: 提前取消，才能重置Opacity，以便在下次RequestAsyncLoad之前恢复正确不透明度

	TWeakObjectPtr<UKGGPUTurboImage> WeakThis(this); // using weak ptr in case 'this' has gone out of scope by the time this lambda is called

	if (bHiddenDuringLoading)
	{
		CachedOpacity = GetColorAndOpacity().A;
		SetColorAndOpacity(GetColorAndOpacity().CopyWithNewOpacity(0));
	}

	RequestAsyncLoad(SoftObject,
		[WeakThis, SoftObject, bMatchSize, bHiddenDuringLoading]() {
			if (UKGGPUTurboImage* StrongThis = WeakThis.Get())
			{
				if (bHiddenDuringLoading)
				{
					if (ensure(StrongThis->CachedOpacity.IsSet()))
					{
						StrongThis->SetColorAndOpacity(StrongThis->GetColorAndOpacity().CopyWithNewOpacity(StrongThis->CachedOpacity.GetValue()));
					}
				}
				auto StrongObject = SoftObject.Get();
				if (!StrongObject)
				{
					UE_LOG(LogKGUI, Error, TEXT("Failed to load %s"), *SoftObject.ToSoftObjectPath().ToString());
				}
				if (auto Texture2D = Cast<UTexture2D>(StrongObject))
				{
					if (!StrongThis->SetBrushFromTextureTryingToUseDynamicSprite(Texture2D, bMatchSize))
					{
						UE_LOG(LogKGUI, Error, TEXT("The incoming resources need to be placed into a texture atlas to mitigate performance risks. (%s)"), *SoftObject.ToSoftObjectPath().ToString());
					}
				}
				else if (auto MaterialInterface = Cast<UMaterialInterface>(StrongObject))
				{
					// TODO: 
					// StrongThis->SetBrushFromMaterial(MaterialInterface);
					StrongThis->SetBrushFromTexture(nullptr);
					UE_LOG(LogKGUI, Error, TEXT("The incoming resources need to be placed into a texture atlas to mitigate performance risks. (%s)"), *SoftObject.ToSoftObjectPath().ToString());
				}
				else if (auto AtlasInterface = Cast<ISlateTextureAtlasInterface>(StrongObject))
				{
					StrongThis->SetBrushFromAtlasInterface(StrongObject, bMatchSize);
				}
				else if (auto Texture2DDynamic = Cast<UTexture2DDynamic>(StrongObject))
				{
					// TODO: 
					// StrongThis->SetBrushFromTextureDynamic(Texture2DDynamic, bMatchSize);
					StrongThis->SetBrushFromTexture(nullptr);
					UE_LOG(LogKGUI, Error, TEXT("The incoming resources need to be placed into a texture atlas to mitigate performance risks. (%s)"), *SoftObject.ToSoftObjectPath().ToString());
				}
				else
				{
					StrongThis->SetBrushFromTexture(nullptr);
				}
			}
		}
	);
}

void UKGGPUTurboImage::CancelImageStreaming()
{
	if (StreamingHandle.IsValid())
	{
		if (CachedOpacity.IsSet())
		{
			SetColorAndOpacity(GetColorAndOpacity().CopyWithNewOpacity(CachedOpacity.GetValue()));
			CachedOpacity.Reset();
		}
	}
	Super::CancelImageStreaming();
}

void UKGGPUTurboImage::Tick(float DeltaTime)
{
    if (!bHasAnim)
    {
        return;
    }
    
    AnimTime = FMath::Min(AnimTime + DeltaTime, AnimDuration);
    float t = AnimTime / AnimDuration;
    t = FMath::Clamp(t, 0.f, 1.f);
    CurPercentForAnim = FMath::Lerp(StartPercentForAnim, GetGPUShowPercent(), t);
    if (MyImage.IsValid())
    {
        MyImage->SetGPUShowPercent(CurPercentForAnim);
    }

    UE_LOG(LogKGUI, Log, TEXT("[UKGGPUTurboImage]Tick time:%.4f realtime:%.4f percent:%sf"), AnimTime, FSlateApplication::Get().GetCurrentTime(), *CurPercentForAnim.ToString());
    if (t >= 1 && bHasAnim)
    {
        bHasAnim = false;
    }
}

void UKGGPUTurboImage::TryInitializeDynamicSprite(UDynamicSprite* DynamicSprite)
{
	check(DynamicSprite);
	
	if (auto DynamicAtlasSubsystem = UDynamicAtlasSubsystem::GetInstance(this))
	{
		DynamicSprite->Initialize(DynamicAtlasSubsystem, UDynamicSprite::FOnInitialized::CreateUObject(this, &UKGGPUTurboImage::OnDynamicSpriteInitialized));
		TryRegisterDynamicAtlasResizedDelegate(DynamicAtlasSubsystem);
	}
}

void UKGGPUTurboImage::OnDynamicSpriteInitialized(UDynamicSprite* DynamicSprite)
{
	if (GPUTurboBrush.MainTex == DynamicSprite)
	{
		ForceRefreshBrushResourceObject();
		if (MyImage.IsValid())
		{
			MyImage->InvalidateImage();
		}
	}
}

void UKGGPUTurboImage::TryRegisterDynamicAtlasResizedDelegate(UDynamicAtlasSubsystem* DynamicAtlasSubsystem)
{
	if (DynamicAtlasResizedDelegateHandle.IsValid())
	{
		return;
	}
	DynamicAtlasResizedDelegateHandle = DynamicAtlasSubsystem->OnAtlasResized().AddUObject(this, &UKGGPUTurboImage::OnDynamicAtlasResized);
}

void UKGGPUTurboImage::TryUnregisterDynamicAtlasResizedDelegate(UDynamicAtlasSubsystem* DynamicAtlasSubsystem)
{
	if (!DynamicAtlasResizedDelegateHandle.IsValid())
	{
		return;
	}
	DynamicAtlasSubsystem->OnAtlasResized().Remove(DynamicAtlasResizedDelegateHandle);
	DynamicAtlasResizedDelegateHandle.Reset();
}

void UKGGPUTurboImage::OnDynamicAtlasResized(UDynamicAtlas* DynamicAtlas)
{
	UObject* ResourceObject = GPUTurboBrush.MainTex;

	if (auto DynamicSprite = Cast<UDynamicSprite>(ResourceObject))
	{
		if (DynamicSprite->GetAtlas() == DynamicAtlas)
		{
			ForceRefreshBrushResourceObject();
		}
	}
}

void UKGGPUTurboImage::ForceRefreshBrushResourceObject()
{
	// UObject* ResourceObject = GPUTurboBrush.MainTex;
	// GPUTurboBrush.MainTex = nullptr;;
	// GPUTurboBrush.MainTex = ResourceObject;
	if (MyImage.IsValid())
	{
		GPUTurboBrush.InvalidMainTexHandle();
		MyImage->InvalidateImage();
	}
}
