﻿// Fill out your copyright notice in the Description page of Project Settings.

// PRAGMA_DISABLE_OPTIMIZATION

#include "UMG/Components/KGPreviewCanvasPanel.h"
#include "Components/CanvasPanelSlot.h"

TSharedRef<SWidget> UKGPreviewCanvasPanel::RebuildWidget()
{

#if WITH_EDITORONLY_DATA
	if (IsDesignTime())
	{
		Super::RebuildWidget();

		ClearChildren();
		if (!KGPreviewList.IsEmpty())
		{
			if (KGPreviewShowIndex < 0 || KGPreviewShowIndex >= KGPreviewList.Num())
			{
				UE_LOG(LogTemp, Warning, TEXT("[KGPreviewCanvasPanel] Invalid KGPreviewShowIndex."));
			}
			else
			{
				FSoftClassPath& RefPath = KGPreviewList[KGPreviewShowIndex];
				auto WidgetClass = RefPath.TryLoadClass<UUserWidget>();
				if (WidgetClass)
				{
					UUserWidget* RealWidget = Cast<UUserWidget>(CreateWidget(this, WidgetClass));
					if (RealWidget)
					{
						UCanvasPanelSlot* PanelSlot = Cast<UCanvasPanelSlot>(AddChild(RealWidget));
						// 按照交互需求，预览的子蓝图UI只需要四角拉伸即可。(如果后续有扩展LayoutData自定义需求，可以直接在UPROPERTY暴露一个FAnchorData，应用到PanelSlot中)
						if (PanelSlot)
						{
							PanelSlot->SetAnchors(FAnchors(0,0,1,1));	
						}
					}	
				}
			}
		}
		return MyCanvas.ToSharedRef();
	}
#endif
	return Super::RebuildWidget();	
}

// PRAGMA_ENABLE_OPTIMIZATION