#include "UMG/Components/KGMeshWidget.h"

#include "Core/Common.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "UMG/Slate/SKGMeshWidget.h"

#if WITH_EDITOR
TArray<TWeakObjectPtr<UKGMeshWidget>> UKGMeshWidget::AllMeshWidgets = {};
#endif

UKGMeshWidget::UKGMeshWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ColorAndOpacity(FLinearColor::White)
{
#if WITH_EDITOR
	AllMeshWidgets.AddUnique(this);
#endif
}

void UKGMeshWidget::SynchronizeProperties()
{
	Super::SynchronizeProperties();

	if (MyMeshWidget.IsValid())
	{
		UpdateMaterial();
		CalculateFinalTransform();
		MyMeshWidget->SetInstanceData(FinalMeshTransform, ColorAndOpacity);
		MyMeshWidget->SetViewProjectionMatrix(VirtualCamera);
	}
}


void UKGMeshWidget::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	MyMeshWidget.Reset();
}

const FTransform& UKGMeshWidget::GetMeshTransform() const
{
	return MeshTransform;
}

void UKGMeshWidget::SetMeshTransform(FTransform InTransform)
{
	MeshTransform = InTransform;
	if (MyMeshWidget.IsValid())
	{
		CalculateFinalTransform();
		MyMeshWidget->SetInstanceData(FinalMeshTransform, ColorAndOpacity);
	}
}

void UKGMeshWidget::SetMeshOverlayRotator(FQuat InRotator)
{
	MeshOverlayRotator = InRotator;
	if (MyMeshWidget.IsValid())
	{
		CalculateFinalTransform();
		MyMeshWidget->SetInstanceData(FinalMeshTransform, ColorAndOpacity);
	}
}


void UKGMeshWidget::SetMeshPivot(FVector InPivot)
{
	MeshPivot = InPivot;
	if (MyMeshWidget.IsValid())
	{
		CalculateFinalTransform();
		MyMeshWidget->SetInstanceData(FinalMeshTransform, ColorAndOpacity);
	}
}

const FVector& UKGMeshWidget::GetMeshPivot() const
{
	return MeshPivot;
}

void UKGMeshWidget::CalculateFinalTransform()
{
	FTransform OriginTransform = FTransform(-MeshPivot);
	FTransform RestorePivotTransform = FTransform(MeshPivot);

	FQuat MeshRot = MeshTransform.GetRotation();
	FQuat OverlayRot = MeshOverlayRotator;
	// 世界空间叠加旋转
	FQuat FinalRot = MeshRot * OverlayRot;
	FinalRot.Normalize();
	FTransform MeshOverlayTransform;
	MeshOverlayTransform.SetRotation(FinalRot);
	MeshOverlayTransform.SetTranslation(MeshTransform.GetTranslation());
	MeshOverlayTransform.SetScale3D(MeshTransform.GetScale3D());
	FinalMeshTransform = RestorePivotTransform * MeshOverlayTransform * OriginTransform;
}

const FTransform& UKGMeshWidget::GetFinalMeshTransform() const
{
	return FinalMeshTransform;
}

const FLinearColor& UKGMeshWidget::GetColorAndOpacity() const
{
	return ColorAndOpacity;
}

void UKGMeshWidget::SetColorAndOpacity(FLinearColor InColorAndOpacity)
{
	ColorAndOpacity = InColorAndOpacity;
	if (MyMeshWidget.IsValid())
	{
		CalculateFinalTransform();
		MyMeshWidget->SetInstanceData(FinalMeshTransform, ColorAndOpacity);
	}
}

void UKGMeshWidget::SetMaterial(UMaterialInterface* Material)
{
	if (!IsValid(Material))
	{
		return;
	}

	if (Brush.GetResourceObject() != Material)
	{
		Brush.SetResourceObject(Material);
	}

	if (Material->IsA<UMaterialInstanceDynamic>())
	{
		RuntimeMaterial = Material;
	}
	else
	{
		RuntimeMaterial = UMaterialInstanceDynamic::Create(Material, this);
	}

	UpdateMaterial();
}

TSharedRef<SWidget> UKGMeshWidget::RebuildWidget()
{
	MyMeshWidget = SNew(SKGMeshWidget);
	MyMeshWidget->SetMesh(MeshAsset);
	return MyMeshWidget.ToSharedRef();
}

void UKGMeshWidget::UpdateMaterial()
{
	if (MyMeshWidget.IsValid())
	{
		//if (RuntimeMaterial != nullptr)
		//{
		//	MyMeshWidget->SetMaterial(RuntimeMaterial);
		//}
		//else
		{
			if (auto* Material = Cast<UMaterialInterface>(Brush.GetResourceObject()))
			{
				if (Material->IsA<UMaterialInstanceDynamic>())
				{
					RuntimeMaterial = Material;
					MyMeshWidget->SetMaterial(Material);
				}
				else
				{
					RuntimeMaterial = UMaterialInstanceDynamic::Create(Material, this);
					MyMeshWidget->SetMaterial(RuntimeMaterial);
					if (!IsDesignTime())
					{
						Brush.SetResourceObject(RuntimeMaterial);
					}
				}
			}
			else
			{
				UE_LOG(LogKGUI, Warning, TEXT("[KGMeshWidget]KGMeshWidget:%s has invalid material."), *GetFullName());
			}
		}
	}
}

UMaterialInstanceDynamic* UKGMeshWidget::GetDynamicMaterial()
{
	if (RuntimeMaterial && RuntimeMaterial->IsA<UMaterialInstanceDynamic>())
	{
		return Cast<UMaterialInstanceDynamic>(RuntimeMaterial);
	}

	if (auto* Material = Cast<UMaterialInterface>(Brush.GetResourceObject()))
	{
		if (Material->IsA<UMaterialInstanceDynamic>())
		{
			RuntimeMaterial = Material;
		}
		else
		{
			RuntimeMaterial = UMaterialInstanceDynamic::Create(Material, this);

			if (!IsDesignTime())
			{
				Brush.SetResourceObject(RuntimeMaterial);
			}
		}
		if (MyMeshWidget.IsValid())
		{
			MyMeshWidget->SetMaterial(RuntimeMaterial);
		}
	}

	return Cast<UMaterialInstanceDynamic>(RuntimeMaterial);
}

#if WITH_EDITOR
void UKGMeshWidget::OnObjectReimported(UObject* ReimportedObject)
{
	if (ReimportedObject == MeshAsset)
	{
		if (MyMeshWidget.IsValid())
		{
			MyMeshWidget->SetMesh(MeshAsset);
			UpdateMaterial();
			CalculateFinalTransform();
			MyMeshWidget->SetInstanceData(FinalMeshTransform, ColorAndOpacity);
		}
	}
}

void UKGMeshWidget::GetAllMeshWidgets(TArray<TWeakObjectPtr<UKGMeshWidget>>& OutMeshWidgets)
{
	OutMeshWidgets = AllMeshWidgets;
}

void UKGMeshWidget::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if(PropertyChangedEvent.Property)
	{
		if(PropertyChangedEvent.Property->GetFName() == GET_MEMBER_NAME_CHECKED(UKGMeshWidget, MeshAsset))
		{
			if (MyMeshWidget.IsValid())
			{
				MyMeshWidget->SetMesh(MeshAsset);
			}
			if (!Brush.GetResourceObject() && MeshAsset)
			{
				Brush.SetResourceObject(MeshAsset->GetMaterial(0));
			}
		}
		if (PropertyChangedEvent.MemberProperty->GetFName() == GET_MEMBER_NAME_CHECKED(UKGMeshWidget, Rotator))
		{
			MeshTransform.SetRotation(Rotator.Quaternion());
		}
	}
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif