#include "UMG/Components/KGSmartPositioningAreaSlot.h"

#include "Slate/Layout/SKGSmartPositioningArea.h"

void UKGSmartPositioningAreaSlot::SynchronizeProperties()
{
	Super::SynchronizeProperties();
}

void UKGSmartPositioningAreaSlot::BuildSlot(TSharedRef<SKGSmartPositioningArea> InSmartPositioningArea)
{
	SmartPositioningArea = InSmartPositioningArea;
	SynchronizeProperties();
	SmartPositioningArea.Pin()->SetContent(Content ? Content->TakeWidget() : SNullWidget::NullWidget);
}

void UKGSmartPositioningAreaSlot::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	SmartPositioningArea.Reset();
}
