// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGInvalidationBox.h"


#include "Slate/SKGInvalidationPanel.h"

void UKGInvalidationBox::SetNeedsSlowPath(bool bNeedsSlowPath)
{
	if (MyInvalidationPanel.IsValid())
	{
		StaticCastSharedPtr<SKGInvalidationPanel>(MyInvalidationPanel)->SetNeedsSlowPath_Public(bNeedsSlowPath);
	}
}

TSharedRef<SWidget> UKGInvalidationBox::RebuildWidget()
{
	MyInvalidationPanel = ConstructWidget<SKGInvalidationPanel>("SKGInvalidationPanel");
	return MyInvalidationPanel.ToSharedRef();
}
