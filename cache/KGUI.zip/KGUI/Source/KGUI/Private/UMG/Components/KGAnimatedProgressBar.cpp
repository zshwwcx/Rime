// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGAnimatedProgressBar.h"

void UKGAnimatedProgressBar::BeginDestroy()
{
	BlendTasks.Reset();
	Super::BeginDestroy();
}

void UKGAnimatedProgressBar::SetPercentWithBlend(float InPercent)
{
	bool bIsIncrease = InPercent > TargetPercent;
	float Speed = bIsIncrease? IncreaseSpeed:DecreaseSpeed;
	float Delay = bIsIncrease? AnimIncreaseStartDelay:AnimDecreaseStartDelay;
	SetPercentWithBlendCustomeSpeed(InPercent,AnimSpeedType,Speed,Delay);
}

void UKGAnimatedProgressBar::SetPercentWithBlendCustomeSpeed(float InPercent,
EKGAnimatedProgressBarSpeedType InSpeedType, float InSpeed,float InDelay)
{
	if (InSpeed==-1)
	{
		return;
	}
	float PercentDelta = InPercent - TargetPercent;
	TargetPercent = InPercent;
	
	FKGAnimatedProgressBarBlendTask NewTask;
	NewTask.bIsIncrease = PercentDelta > 0;
	NewTask.PercentDeltaReamin = FMath::Abs(PercentDelta);
	
	if (BlendType == EKGAnimatedProgressBarBlendType::OnWayAdditive)
	{
		CurrentIncreasing = TargetPercent > CurrentPercent;
		
		if (CurrentIncreasing != NewTask.bIsIncrease)
		{
			for(int i=0;i<BlendTasks.Num();i++)
			{
				FKGAnimatedProgressBarBlendTask& Task =  BlendTasks[BlendTasks.Num()-i-1];
		
				float Delta = FMath::Min(Task.PercentDeltaReamin,NewTask.PercentDeltaReamin);

				Task.PercentDeltaReamin -= Delta;
				NewTask.PercentDeltaReamin -= Delta;
				if (NewTask.PercentDeltaReamin <= 0)
				{
					return;
				}
				
			}
		}
	}
	//Calculate Speed
	if (InSpeedType == EKGAnimatedProgressBarSpeedType::TimeSecond )
	{
		NewTask.SpeedRatePerSec = InSpeed > 0 ? NewTask.PercentDeltaReamin/InSpeed : InSpeed;
		
	}else
	{
		NewTask.SpeedRatePerSec = InSpeed;
	}
	
	//Set Delay 
	NewTask.DelayRemain = InDelay;
	
	BlendTasks.Add(NewTask);
}

void UKGAnimatedProgressBar::SetPercentInstant(float InPercent)
{
	BlendTasks.Empty();
	SetPercent(InPercent);
	TargetPercent = InPercent;
}

void UKGAnimatedProgressBar::SetBlendType(EKGAnimatedProgressBarBlendType InBlendType)
{
	BlendType = InBlendType;
}

void UKGAnimatedProgressBar::SetIncreaseDelay(float InDelay)
{
	AnimIncreaseStartDelay = InDelay;
}

void UKGAnimatedProgressBar::SetDecreaseDelay(float InDelay)
{
	AnimDecreaseStartDelay = InDelay;
}

void UKGAnimatedProgressBar::SetPercentEachLoop(float& InLoop)
{
	PercentEeachLoop = InLoop;
}

void UKGAnimatedProgressBar::SetSpeed(EKGAnimatedProgressBarSpeedType InAnimSpeedType,float InIncreaseSpeed, float InDecreaseSpeed)
{
	AnimSpeedType = InAnimSpeedType;
	IncreaseSpeed = InIncreaseSpeed;
	DecreaseSpeed = InDecreaseSpeed;
}


void UKGAnimatedProgressBar::ProcessOneBlendTask(FKGAnimatedProgressBarBlendTask& Task,float& InCurrentPercent,float& DelatTime)
{
	Task.DelayRemain = FMath::Max(Task.DelayRemain - DelatTime,0);
	if (Task.DelayRemain > 0)
	{
		return;
	}
	
	float DeltaPercent = FMath::Min(DelatTime*Task.SpeedRatePerSec,Task.PercentDeltaReamin);
	if (DeltaPercent <=0)
	{
		DeltaPercent = Task.PercentDeltaReamin;
	}
	
	if (Task.bIsIncrease)
	{
		InCurrentPercent = InCurrentPercent + DeltaPercent;
	}
	else
	{
		InCurrentPercent = InCurrentPercent - DeltaPercent;
	}
	
	Task.PercentDeltaReamin = Task.PercentDeltaReamin - DeltaPercent;
}

void UKGAnimatedProgressBar::SetPercent(float InPercent)
{
	if (bLoopPercent)
	{
		int PrevLoop = CurrentLoop ;
		float ViewPercent = FMath::Fmod(InPercent,PercentEeachLoop)/PercentEeachLoop;
		CurrentPercent = InPercent;
		int NewLoop  = FMath::Floor(CurrentPercent/PercentEeachLoop);
		Super::SetPercent(ViewPercent);
		// if (FMath::IsNearlyEqual(ViewPercent,0,0.0001) && NewLoop>0)
		// {
		// 	NewLoop -= 1;
		// 	ViewPercent = 1;
		// }
		CurrentLoop = NewLoop;
		if (PrevLoop != NewLoop)
		{
			if(OnLoopNumChanged.IsBound() )
			{
				OnLoopNumChanged.Broadcast(CurrentLoop,NewLoop);
			}
		}
	

		if (OnPercentChanged.IsBound())
		{
			OnPercentChanged.Broadcast(ViewPercent);
		}
	}else
	{
		CurrentPercent = InPercent;
		Super::SetPercent(InPercent);
		if (OnPercentChanged.IsBound())
		{
			OnPercentChanged.Broadcast(InPercent);
		}
	}

}


void UKGAnimatedProgressBar::Tick(float DeltaTime)
{
	//Process Blend Task
	float CurPercent = CurrentPercent ;
	TArray<int> TasksToRemoveFromBlendQueue;
	if (BlendType == EKGAnimatedProgressBarBlendType::Additive ||
		BlendType == EKGAnimatedProgressBarBlendType::OnWayAdditive )
	{
		for(int i =0 ;i<BlendTasks.Num();i++)
		{
			ProcessOneBlendTask(BlendTasks[i],CurPercent,DeltaTime);
			if (BlendTasks[i].PercentDeltaReamin <= 0)
			{
				TasksToRemoveFromBlendQueue.Add(i);
			}
		}
	}else if(BlendType == EKGAnimatedProgressBarBlendType::OneByOne)
	{
		if (! BlendTasks.IsEmpty())
		{
			ProcessOneBlendTask(BlendTasks[0],CurPercent,DeltaTime);
		}
	}

	for(int i =TasksToRemoveFromBlendQueue.Num()-1 ;i>=0;i--)
	{
		BlendTasks.RemoveAt(i);
	}
	
	
    if(BlendTasks.Num()<=0)
    {
    	//去除误差
    	CurPercent = TargetPercent;  
    }


	SetPercent(CurPercent);
}

TStatId UKGAnimatedProgressBar::GetStatId() const
{
	return GetStatID();
}

bool UKGAnimatedProgressBar::IsTickable() const
{
	return BlendTasks.Num()>0;
}

