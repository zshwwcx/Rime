#include "UMG/Components/KGTextureLoader.h"

#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"

FKGTextureLoader::~FKGTextureLoader()
{
	ReleaseStreaming();
}

void FKGTextureLoader::RequestAsyncLoad(TSoftObjectPtr<UObject> SoftObject, FOnTextureLoadCompleted&& InOnLoadCompleted, FOnTextureLoadCancelled&& InOnLoadCancelled)
{
	CancelStreaming();

	OnLoadCompleted = MoveTemp(InOnLoadCompleted);
	OnLoadCancelled = MoveTemp(InOnLoadCancelled);

	StreamingObjectPath = SoftObject.ToSoftObjectPath();
	StreamingHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(
		StreamingObjectPath,
		[WeakThis = this->AsWeak(), SoftObject]()
		{
			if (auto This = WeakThis.Pin())
			{
				if (ensure(This->StreamingObjectPath == SoftObject.ToSoftObjectPath()))
				{
					(void)This->OnLoadCompleted.ExecuteIfBound();
					This->ReleaseStreaming();
				}
			}
		},
		FStreamableManager::AsyncLoadHighPriority
	);
}

void FKGTextureLoader::CancelStreaming()
{
	if (StreamingHandle.IsValid())
	{
		ReleaseStreaming();
		(void)OnLoadCancelled.ExecuteIfBound();
	}
}

void FKGTextureLoader::ReleaseStreaming()
{
	if (StreamingHandle.IsValid())
	{
		StreamingHandle->CancelHandle();
		StreamingHandle.Reset();
		StreamingObjectPath.Reset();
	}
}
