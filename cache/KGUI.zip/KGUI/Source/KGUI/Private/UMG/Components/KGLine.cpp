#include "UMG/Components/KGLine.h"

#include "Slate/Components/SKGLine.h"
#include "SlateOptMacros.h"
#include "Components/CanvasPanelSlot.h"
#include "Components/OverlaySlot.h"
#include "Components/VerticalBoxSlot.h"
#include "Core/Common.h"
#include "Rendering/DrawElements.h"
#include "Engine/World.h"

#if WITH_EDITOR
#include "Editor.h"
#endif

UKGLine::UKGLine(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
    , bUseBezierControl(true)
	, DefaultLineThickness(1.0f)
{
	CachedPoints.Empty(KGLINE_MAX_POINTS);
	// 添加第一个点(0,0)
	Point1 = FKGBezierPoint(FVector2f(0.0f, 0.0f), FVector2f(25.0f, 25.0f), 0.0f);
	CachedPoints.Emplace(Point1);

	// 添加第二个点(50,50)
	Point2 = FKGBezierPoint(FVector2f(50.0f, 50.0f), FVector2f(75.0f, 25.0f), 1.0f);
	CachedPoints.Emplace(Point2);
	PointCount = 2;
}

TSharedRef<SWidget> UKGLine::RebuildWidget()
{
    BezierPointsWidget = SNew(SKGLine)
        .Points(&CachedPoints)
        .DefaultLineThickness(DefaultLineThickness)
        .LineMaterial(&LineMaterial)
        .UseBezierControl(bUseBezierControl);
    
    return BezierPointsWidget.ToSharedRef();
}

void UKGLine::ReleaseSlateResources(bool bReleaseChildren)
{
    Super::ReleaseSlateResources(bReleaseChildren);
    BezierPointsWidget.Reset();
}

void UKGLine::SynchronizeProperties()
{
    Super::SynchronizeProperties();
    
    if (BezierPointsWidget.IsValid())
    {
        BezierPointsWidget->SetPoints(&CachedPoints);
        BezierPointsWidget->SetDefaultLineThickness(DefaultLineThickness);
        BezierPointsWidget->SetLineMaterial(&LineMaterial);
        BezierPointsWidget->SetUseBezierControl(bUseBezierControl);
    }
}

void UKGLine::PostLoad()
{
	Super::PostLoad();

	SyncCachedPoints();
}
void UKGLine::PostInitProperties()
{
	Super::PostInitProperties();

	SyncCachedPoints();
}
#if WITH_EDITOR
void UKGLine::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	FName PropertyName = PropertyChangedEvent.GetPropertyName();
	if (PropertyName == GET_MEMBER_NAME_CHECKED(UKGLine, Point1) ||
		PropertyName == GET_MEMBER_NAME_CHECKED(UKGLine, Point2) ||
		PropertyName == GET_MEMBER_NAME_CHECKED(UKGLine, Point3) ||
		PropertyName == GET_MEMBER_NAME_CHECKED(UKGLine, Point4) ||
		PropertyName == GET_MEMBER_NAME_CHECKED(FKGBezierPoint, Position) ||
		PropertyName == GET_MEMBER_NAME_CHECKED(FKGBezierPoint, ControlPoint))
	{
		SyncCachedPoints();
		UpdatePointsUV();
	}

	ConfigureSlotProperties();
}
void UKGLine::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();

	// 延迟调用配置函数
	TWeakObjectPtr<UKGLine> LocalThis = this;
	GEditor->GetTimerManager()->SetTimerForNextTick([LocalThis]()
		{
			if (LocalThis.IsValid())
			{
				LocalThis->ConfigureSlotProperties();
			}
		});
}

void UKGLine::ConfigureSlotProperties()
{
	//UPanelSlot* PanelSlot = Slot.Get();
	//if (PanelSlot->IsValidLowLevel())
	//{
	//	// 设置Slot属性...
	//	if (UCanvasPanelSlot* CanvasSlot = Cast<UCanvasPanelSlot>(PanelSlot))
	//	{
	//		CanvasSlot->SetAutoSize(true);
	//	}
	//}
}
const FText UKGLine::GetPaletteCategory()
{
    return NSLOCTEXT("KGUI", "BezierPointsWidget", "KGUI");
}
#endif

#if WITH_EDITOR
int32 UKGLine::AddPointEditor(const FVector2f& Position)
{
	return AddPointInternal(Position);
}
void UKGLine::RemovePointEditor(int32 PointIndex)
{
	RemovePointInternal(PointIndex);
}
#endif

int32 UKGLine::AddPointInternal(const FVector2f& Position)
{
	if (PointCount >= KGLINE_MAX_POINTS)
	{
		UE_LOG(LogKGUI, Error, TEXT("Only support %d points at max!"), KGLINE_MAX_POINTS);
		return -1;
	}
	const FVector2f ControlPoint = FVector2f(Position.X + 25.0f, Position.Y + 25.0f);
	FKGBezierPoint NewPoint(Position, ControlPoint, 0.0f);

	if (PointCount == 0) Point1 = NewPoint;
	if (PointCount == 1) Point2 = NewPoint;
	if (PointCount == 2) Point3 = NewPoint;
	if (PointCount == 3) Point4 = NewPoint;
	PointCount++;

	SyncCachedPoints();
	return PointCount - 1;
}
bool UKGLine::IsValidIndex(int32 PointIndex) const
{
	return PointIndex >= 0 && PointIndex < PointCount;
}
bool UKGLine::RemovePointInternal(int32 PointIndex)
{
	if (PointCount <= 0 || !IsValidIndex(PointIndex))
	{
		UE_LOG(LogKGUI, Error, TEXT("Invalid point index (%d, %d)!"), PointIndex, PointCount);
		return false;
	}

	// 注意：需要移动每个顶点的位置
	if (PointIndex == 0)
	{
		Point1 = Point2;
		Point2 = Point3;
		Point3 = Point4;
	}
	if (PointIndex == 1)
	{
		Point2 = Point3;
		Point3 = Point4;
	}
	if (PointIndex == 2)
	{
		Point3 = Point4;
	}
	//if (PointIndex == 3)
	PointCount--;

	SyncCachedPoints();
	return true;
}
int32 UKGLine::AddPoint(const FVector2f& Position)
{
    // 添加新点
	int32 NewIndex = AddPointInternal(Position);
    
    // 更新连线和UV
    UpdatePointsUV();

	// 如果有Slate实例，通知更新
	if (BezierPointsWidget.IsValid())
	{
		BezierPointsWidget->SetPoints(&CachedPoints);
	}
    
    return NewIndex;
}

bool UKGLine::RemovePoint(int32 PointIndex)
{
    if (!RemovePointInternal(PointIndex))
    {
        return false;
    }
    
    // 更新连接和UV
    UpdatePointsUV();
    
    // 如果有Slate实例，通知更新
    if (BezierPointsWidget.IsValid())
    {
        BezierPointsWidget->SetPoints(&CachedPoints);
    }
    
    return true;
}

bool UKGLine::MovePoint(int32 PointIndex, const FVector2f& Delta)
{
	if (!IsValidIndex(PointIndex))
	{
		return false;
	}

	// 注意：第1个点，焊死到(0,0)
	// if (PointIndex == 0) Point1.Position += Delta;
	if (PointIndex == 1) Point2.Position += Delta;
	if (PointIndex == 2) Point3.Position += Delta;
	if (PointIndex == 3) Point4.Position += Delta;

	SyncCachedPoints();

	// 更新UV
	UpdatePointsUV();

	// 如果有Slate实例，通知更新
	if (BezierPointsWidget.IsValid())
	{
		BezierPointsWidget->SetPoints(&CachedPoints);
	}

	return true;
}
bool UKGLine::MoveControl(int32 PointIndex, const FVector2f& Delta)
{
	if (!IsValidIndex(PointIndex))
	{
		return false;
	}

	if (PointIndex == 0) Point1.ControlPoint += Delta;
	if (PointIndex == 1) Point2.ControlPoint += Delta;
	if (PointIndex == 2) Point3.ControlPoint += Delta;
	if (PointIndex == 3) Point4.ControlPoint += Delta;

	SyncCachedPoints();

	// 如果有Slate实例，通知更新
	if (BezierPointsWidget.IsValid())
	{
		BezierPointsWidget->SetPoints(&CachedPoints);
	}

	return true;
}
void UKGLine::SetBezierPoint(int32 PointIndex, const FKGBezierPoint& InPoint)
{
	ensureMsgf(PointIndex >= 0 && PointIndex < KGLINE_MAX_POINTS, TEXT("SetBezierPoint: PointIndex >= 0 && PointIndex < KGLINE_MAX_POINTS, but it is: %d"), PointIndex);

	if (PointIndex == 0)
	{
		// 注意：第1个点，焊死到(0,0)
		// Point1.Position = InPoint.Position;
		Point1.Position = FVector2f::Zero();
		Point1.ControlPoint = InPoint.ControlPoint;
		if (CachedPoints.Num() > 0)
		{
			CachedPoints[0] = Point1;
		}
	}
	if (PointIndex == 1)
	{
		Point2.Position = InPoint.Position;
		Point2.ControlPoint = InPoint.ControlPoint;
		if (CachedPoints.Num() > 1)
		{
			CachedPoints[1] = Point2;
		}
	}
	if (PointIndex == 2)
	{
		Point3.Position = InPoint.Position;
		Point3.ControlPoint = InPoint.ControlPoint;
		if (CachedPoints.Num() > 2)
		{
			CachedPoints[2] = Point3;
		}
	}
	if (PointIndex == 3)
	{
		Point4.Position = InPoint.Position;
		Point4.ControlPoint = InPoint.ControlPoint;
		if (CachedPoints.Num() > 3)
		{
			CachedPoints[3] = Point4;
		}
	}

	if (CachedPoints.Num() != PointCount)
	{
		SyncCachedPoints();
	}

	// 如果有Slate实例，通知更新
	if (BezierPointsWidget.IsValid())
	{
		BezierPointsWidget->SetPoints(&CachedPoints);
	}
}
FKGBezierPoint UKGLine::GetBezierPoint(int32 PointIndex) const
{
	if (PointIndex == 0) return Point1;
	if (PointIndex == 1) return Point2;
	if (PointIndex == 2) return Point3;
	if (PointIndex == 3) return Point4;
	return FKGBezierPoint();
}
bool UKGLine::UpdatePoint(int32 PointIndex, const FVector2f& NewPosition)
{
    if (!IsValidIndex(PointIndex))
    {
        return false;
    }

	// 注意：第1个点，焊死到(0,0)
	// if (PointIndex == 0) Point1.Position = NewPosition;
	if (PointIndex == 1) Point2.Position = NewPosition;
	if (PointIndex == 2) Point3.Position = NewPosition;
	if (PointIndex == 3) Point4.Position = NewPosition;
	
	SyncCachedPoints();
    
    // 更新UV
    UpdatePointsUV();
    
    // 如果有Slate实例，通知更新
    if (BezierPointsWidget.IsValid())
    {
        BezierPointsWidget->SetPoints(&CachedPoints);
    }
    
    return true;
}

bool UKGLine::UpdateControl(int32 PointIndex, const FVector2f& ControlPoint)
{
	if (!IsValidIndex(PointIndex))
	{
		return false;
	}

	if (PointIndex == 0) Point1.ControlPoint = ControlPoint;
	if (PointIndex == 1) Point2.ControlPoint = ControlPoint;
	if (PointIndex == 2) Point3.ControlPoint = ControlPoint;
	if (PointIndex == 3) Point4.ControlPoint = ControlPoint;

	SyncCachedPoints();
    
    // 如果有Slate实例，通知更新
    if (BezierPointsWidget.IsValid())
    {
        BezierPointsWidget->SetPoints(&CachedPoints);
    }
    
    return true;
}

void UKGLine::ClearAll()
{
    // 清除所有点和连线
	PointCount = 0;
	SyncCachedPoints();
    
    // 如果有Slate实例，通知更新
    if (BezierPointsWidget.IsValid())
    {
        BezierPointsWidget->SetPoints(&CachedPoints);
    }
}

void UKGLine::SetLineMaterial(const FSlateBrush& InLineMaterial)
{
    LineMaterial = InLineMaterial;
    
    // 如果有Slate实例，通知更新
    if (BezierPointsWidget.IsValid())
    {
        BezierPointsWidget->SetLineMaterial(&LineMaterial);
    }
}

void UKGLine::SyncCachedPoints()
{
	CachedPoints.Empty(KGLINE_MAX_POINTS);
	if (PointCount > 0) CachedPoints.Emplace(Point1);
	if (PointCount > 1) CachedPoints.Emplace(Point2);
	if (PointCount > 2) CachedPoints.Emplace(Point3);
	if (PointCount > 3) CachedPoints.Emplace(Point4);
	ensureMsgf(PointCount >= 0 && PointCount <= KGLINE_MAX_POINTS, TEXT("PointCount >= 0 && PointCount <= KGLINE_MAX_POINTS, but it is: %d"), PointCount);
}
void UKGLine::UpdatePointsUV()
{
    if (PointCount <= 1)
    {
        // 如果只有0或1个点，设置唯一点的UV为0
        if (PointCount == 1)
        {
            Point1.UV = 0.0f;
			if (CachedPoints.Num() > 0)
			{
				CachedPoints[0].UV = 0.0f;
			}
        }
        return;
    }
	// 确保调用之前已经执行了SyncCachedPoints！
	ensureMsgf(PointCount == CachedPoints.Num(), TEXT("PointCount != CachedPoints.Num(), (%d !=  %d)"), PointCount, CachedPoints.Num());

    // 计算总长度
    float TotalLength = 0.0f;
    for (int32 i = 1; i < CachedPoints.Num(); ++i)
    {
        TotalLength += FVector2f::Distance(CachedPoints[i-1].Position, CachedPoints[i].Position);
    }

    if (TotalLength <= 0.0f)
    {
        // 所有点在同一位置，设置均匀分布的UV
        for (int32 i = 0; i < CachedPoints.Num(); ++i)
        {
			CachedPoints[i].UV = static_cast<float>(i) / static_cast<float>(CachedPoints.Num() - 1);
        }
    }
	else
	{
		// 计算每个点的UV
		float CurrentDistance = 0.0f;
		CachedPoints[0].UV = 0.0f; // 第一个点的UV始终为0

		for (int32 i = 1; i < CachedPoints.Num(); ++i)
		{
			CurrentDistance += FVector2f::Distance(CachedPoints[i - 1].Position, CachedPoints[i].Position);
			CachedPoints[i].UV = CurrentDistance / TotalLength;
		}

		// 确保最后一个点的UV为1.0
		if (CachedPoints.Num() > 1)
		{
			CachedPoints[CachedPoints.Num() - 1].UV = 1.0f;
		}
	}

	// 回填数据
	if (PointCount > 0) Point1 = CachedPoints[0];
	if (PointCount > 1) Point2 = CachedPoints[1];
	if (PointCount > 2) Point3 = CachedPoints[2];
	if (PointCount > 3) Point4 = CachedPoints[3];
    
    // 如果有Slate实例，通知更新
    if (BezierPointsWidget.IsValid())
    {
        BezierPointsWidget->SetPoints(&CachedPoints);
    }
}