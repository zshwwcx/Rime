#include "UMG/Components/KGCheckBox.h"

#include "AkAudioEvent.h"
#include "Manager/KGAkAudioManager.h"
#include "Slate/Components/SKGCheckBox.h"

void UKGCheckBox::ReleaseSlateResources(bool bReleaseChildren)
{
	if (HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnReleaseSlateResources();
		HoverPressAnimDriver.Reset();
	}

	OnCheckStateChanged.RemoveDynamic(this, &UKGCheckBox::PostWidgetAudio);

	Super::ReleaseSlateResources(bReleaseChildren);
}

TSharedRef<SWidget> UKGCheckBox::RebuildWidget()
{
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
		MyCheckbox = SNew(SKGCheckBox)
		.OnCheckStateChanged(BIND_UOBJECT_DELEGATE(FOnCheckStateChanged, SlateOnCheckStateChangedCallback))
		.Style(&WidgetStyle)
		.HAlign(HorizontalAlignment)
		.ClickMethod(ClickMethod)
		.TouchMethod(TouchMethod)
		.PressMethod(PressMethod)
		.IsFocusable(IsFocusable)
		.OnPressed(BIND_UOBJECT_DELEGATE(FSimpleDelegate, SlateHandlePressed))
		.OnReleased(BIND_UOBJECT_DELEGATE(FSimpleDelegate, SlateHandleReleased))
		.OnHovered(BIND_UOBJECT_DELEGATE(FSimpleDelegate, SlateHandleHovered))
		.OnUnhovered(BIND_UOBJECT_DELEGATE(FSimpleDelegate, SlateHandleUnhovered))
		;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS

	if (GetChildrenCount() > 0)
	{
		MyCheckbox->SetContent(GetContentSlot()->Content 
			? GetContentSlot()->Content->TakeWidget() 
			: SNullWidget::NullWidget);
	}

	if (HoverPressAnim.bEnable)
	{
		HoverPressAnimDriver = MakeShareable(new FKGInteractableArea(this, HoverPressAnim));
		HoverPressAnimDriver->OnWidgetRebuild();
	}

	if (WidgetAkEvent.ToSoftObjectPath().IsValid())
	{
		OnCheckStateChanged.AddDynamic(this, &UKGCheckBox::PostWidgetAudio);	
	}

	return MyCheckbox.ToSharedRef();
}

void UKGCheckBox::SlateHandlePressed()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnPressed();
	}
}

void UKGCheckBox::SlateHandleReleased()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnReleased();
	}
}

void UKGCheckBox::SlateHandleHovered()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnHovered();
	}
}

void UKGCheckBox::SlateHandleUnhovered()
{
	if (HoverPressAnim.bEnable && HoverPressAnimDriver.IsValid())
	{
		HoverPressAnimDriver->OnUnhovered();
	}
}

void UKGCheckBox::PostWidgetAudio(bool bIsChecked)
{
	if (UKGAkAudioManager* AkAudioMgr = UKGAkAudioManager::GetInstance(this))
	{
		if (WidgetAkEvent.ToSoftObjectPath().IsValid())
		{
		    AkAudioMgr->InnerPostEvent3D(WidgetAkEvent.GetAssetName());
		}
	}
}
