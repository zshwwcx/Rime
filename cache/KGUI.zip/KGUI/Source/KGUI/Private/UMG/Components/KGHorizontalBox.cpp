// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGHorizontalBox.h"
#include "Components/HorizontalBoxSlot.h"
void UKGHorizontalBox::OnSlotInserted(int32 Index, UPanelSlot* InSlot)
{
	// Add the child to the live canvas if it already exists
	if (MyHorizontalBox.IsValid())
	{
		CastChecked<UHorizontalBoxSlot>(InSlot)->InsertSlot(MyHorizontalBox.ToSharedRef(), Index);
	}
}

void UKGHorizontalBox::OnSlotMoved(int32 Index1, int32 Index2)
{
	if (MyHorizontalBox.IsValid())
	{
		MyHorizontalBox->MoveSlot(Index1, Index2);
	}
}