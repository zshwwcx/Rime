#include "UMG/Components/KGGPUTurboTextBlock.h"

#include "KGUI.h"

#if WITH_EDITOR
void UKGGPUTurboTextBlock::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	if (auto KGUI = FModuleManager::Get().GetModulePtr<FKGUIModule>("KGUI"))
	{
		KGUI->GetOnWidgetCreatedFromPalette().Broadcast(this);
	}
}
#endif