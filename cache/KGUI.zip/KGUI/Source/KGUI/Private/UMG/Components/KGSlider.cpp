// Fill out your copyright notice in the Description page of Project Settings.

#include "Widgets/Input/SSlider.h"
#include "UMG/Components/KGSlider.h"

#include "AkAudioEvent.h"
#include "Manager/KGAkAudioManager.h"

void UKGSlider::SetValueWithoutNotify(float InValue)
{
	if (MySlider.IsValid())
	{
		MySlider->SetValue(InValue);
	}
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	if (Value != InValue)
	{
		Value = InValue;
	}
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
}

void UKGSlider::PostWidgetAudio()
{
	if (UKGAkAudioManager* AkAudioMgr = UKGAkAudioManager::GetInstance(this))
	{
		if (WidgetAkEvent.ToSoftObjectPath().IsValid())
		{
		    AkAudioMgr->InnerPostEvent3D(WidgetAkEvent.GetAssetName());
		}
	}
}

TSharedRef<SWidget> UKGSlider::RebuildWidget()
{
	if (WidgetAkEvent.ToSoftObjectPath().IsValid())
	{
		OnMouseCaptureBegin.AddDynamic(this, &UKGSlider::PostWidgetAudio);
	}
	
	return Super::RebuildWidget();
}

void UKGSlider::ReleaseSlateResources(bool bReleaseChildren)
{
	OnMouseCaptureBegin.RemoveDynamic(this, &UKGSlider::PostWidgetAudio);
	Super::ReleaseSlateResources(bReleaseChildren);
}

#if WITH_EDITOR
void UKGSlider::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	this->bCaptureOnTouchStarted = true;  // 默认开启
}
#endif
