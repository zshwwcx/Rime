#include "UMG/Components/KGSmartPositioningArea.h"

#include "UMG/Components/KGSmartPositioningAreaSlot.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(KGSmartPositioningArea)

void UKGSmartPositioningArea::SynchronizeProperties()
{
	Super::SynchronizeProperties();
}

TSharedRef<SWidget> UKGSmartPositioningArea::RebuildWidget()
{
	MySmartPositioningArea = SNew(SKGSmartPositioningArea)
		.bIsDesignTime(IsDesignTime())
		.PrimaryOrientation(
			TAttribute<EKGSmartPositioningAreaOrientation>::Create(TAttribute<EKGSmartPositioningAreaOrientation>::FGetter::CreateUObject(this, &UKGSmartPositioningArea::GetPrimaryOrientation))
		)
		.SecondaryAlignment(
			TAttribute<EKGSmartPositioningAreaAlignment>::Create(TAttribute<EKGSmartPositioningAreaAlignment>::FGetter::CreateUObject(this, &UKGSmartPositioningArea::GetSecondaryAlignment))
		)
		.HorizontalPreferredDirection(
			TAttribute<EKGSmartPositioningAreaHorizontalPreferredDirection>::Create(TAttribute<EKGSmartPositioningAreaHorizontalPreferredDirection>::FGetter::CreateUObject(this, &UKGSmartPositioningArea::GetHorizontalPreferredDirection))
		)
		.VerticalPreferredDirection(
			TAttribute<EKGSmartPositioningAreaVerticalPreferredDirection>::Create(TAttribute<EKGSmartPositioningAreaVerticalPreferredDirection>::FGetter::CreateUObject(this, &UKGSmartPositioningArea::GetVerticalPreferredDirection))
		)
		;
	if (GetChildrenCount() > 0)
	{
		Cast<UKGSmartPositioningAreaSlot>(GetContentSlot())->BuildSlot(MySmartPositioningArea.ToSharedRef());
	}
	return MySmartPositioningArea.ToSharedRef();
}

void UKGSmartPositioningArea::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	MySmartPositioningArea.Reset();
}

UClass* UKGSmartPositioningArea::GetSlotClass() const
{
	return UKGSmartPositioningAreaSlot::StaticClass();
}

void UKGSmartPositioningArea::OnSlotAdded(UPanelSlot* InSlot)
{
	if (MySmartPositioningArea.IsValid())
	{
		CastChecked<UKGSmartPositioningAreaSlot>(InSlot)->BuildSlot(MySmartPositioningArea.ToSharedRef());
	}
}

void UKGSmartPositioningArea::OnSlotRemoved(UPanelSlot* InSlot)
{
	if (MySmartPositioningArea.IsValid())
	{
		MySmartPositioningArea->SetContent(SNullWidget::NullWidget);
	}
}

void UKGSmartPositioningArea::SetPrimaryOrientation(EKGSmartPositioningAreaOrientation InPrimaryOrientation)
{
	PrimaryOrientation = InPrimaryOrientation;
	if (MySmartPositioningArea.IsValid())
	{
		MySmartPositioningArea->Invalidate(EInvalidateWidgetReason::Paint);
	}
}

void UKGSmartPositioningArea::SetSecondaryAlignment(EKGSmartPositioningAreaAlignment InSecondaryAlignment)
{
	SecondaryAlignment = InSecondaryAlignment;
	if (MySmartPositioningArea.IsValid())
	{
		MySmartPositioningArea->Invalidate(EInvalidateWidgetReason::Paint);
	}
}

void UKGSmartPositioningArea::SetHorizontalPreferredDirection(EKGSmartPositioningAreaHorizontalPreferredDirection InHorizontalPreferredDirection)
{
	HorizontalPreferredDirection = InHorizontalPreferredDirection;
	if (MySmartPositioningArea.IsValid())
	{
		MySmartPositioningArea->Invalidate(EInvalidateWidgetReason::Paint);
	}
}

void UKGSmartPositioningArea::SetVerticalPreferredDirection(EKGSmartPositioningAreaVerticalPreferredDirection InVerticalPreferredDirection)
{
	VerticalPreferredDirection = InVerticalPreferredDirection;
	if (MySmartPositioningArea.IsValid())
	{
		MySmartPositioningArea->Invalidate(EInvalidateWidgetReason::Paint);
	}
}
