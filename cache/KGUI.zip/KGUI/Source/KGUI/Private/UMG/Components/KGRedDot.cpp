// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGRedDot.h"
#include "Slate/Components/SKGRedDot.h"

UKGRedDotSlot::UKGRedDotSlot(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Slot(nullptr)
{
	Offsets = FMargin(0.f, 0.f, 100.f, 30.f);
	Anchors = FAnchors(0.0f, 0.0f);
	Alignment = FVector2D(0.0f, 0.0f);
	
}

void UKGRedDotSlot::BuildSlot(TSharedRef<SKGRedDot> InRedDot)
{
	RedDot = InRedDot.ToWeakPtr();
	Slot = InRedDot->GetChildSlot();
	InRedDot->SetContentOffset(Offsets);
	InRedDot->SetContentAnchors(Anchors);
	InRedDot->SetContentAlignment(Alignment);
	InRedDot->SetContent(Content?Content->TakeWidget():SNullWidget::NullWidget);
}

void UKGRedDotSlot::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	if (RedDot.IsValid())
	{
		RedDot.Pin()->SetContentOffset(Offsets);
		RedDot.Pin()->SetContentAnchors(Anchors);
		RedDot.Pin()->SetContentAlignment(Alignment);
	}
}

void UKGRedDotSlot::ReleaseSlateResources(bool bReleaseChildren)
{
	Slot = nullptr;
	Super::ReleaseSlateResources(bReleaseChildren);
}

void UKGRedDotSlot::SetOffsets(const FMargin& InOffsets)
{
	Offsets = InOffsets;
	if (Slot)
	{
		Slot->SetOffset(InOffsets);
	}
}

void UKGRedDotSlot::SetAlignment(const FVector2D& InAlignment)
{
	Alignment = InAlignment;
	if (Slot)
	{
		Slot->SetAlignment(Alignment);
	}
}

void UKGRedDotSlot::SetAnchors(const FAnchors& InAnchors)
{
	Anchors = InAnchors;
	if (Slot)
	{
		Slot->SetAnchors(Anchors);
	}
}


/*
 *	UKGRedDot
 */

UKGRedDot::UKGRedDot(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Anchors(0, 0)
	, Offsets(0, 0, 0, 0)
	, Alignment(0, 0)
	, ColorAndOpacity(FLinearColor::White)
	, ColorForeground(FLinearColor::White)
{
	SetVisibility(ESlateVisibility::HitTestInvisible);
}

void UKGRedDot::SetContentScale(float InScale)
{
	ContentScale = InScale;
	if (MyRedDot.IsValid())
	{
		MyRedDot->SetContentScale(InScale);
	}
}

void UKGRedDot::SetOwnerWidget(UWidget* Widget)
{
	OwnerWidget = Widget;
	if (MyRedDot.IsValid() && Widget)
	{
		MyRedDot->SetOwnerWidget(Widget->TakeWidget());
	}
}

void UKGRedDot::SetAnchors(const FAnchors& InAnchors)
{
	Anchors = InAnchors;
	if (MyRedDot.IsValid())
	{
		MyRedDot->SetContentAnchors(InAnchors);
	}
}

void UKGRedDot::SetOffset(const FMargin& InOffset)
{
	Offsets = InOffset;
	if (MyRedDot.IsValid())
	{
		MyRedDot->SetContentOffset(InOffset);
	}
}

void UKGRedDot::SetAlignment(const FVector2D& InAlignment)
{
	Alignment = InAlignment;
	if (MyRedDot.IsValid())
	{
		MyRedDot->SetContentAlignment(InAlignment);
	}
}

void UKGRedDot::SetColorAndOpacity(const FLinearColor& InColor)
{
	ColorAndOpacity = InColor;
	if (MyRedDot.IsValid())
	{
		MyRedDot->SetColorAndOpacity(InColor);
	}
}

void UKGRedDot::SetForegroundColor(const FLinearColor& InColor)
{
	ColorForeground = InColor;
	if (MyRedDot.IsValid())
	{
		MyRedDot->SetForegroundColor(InColor);
	}
}

void UKGRedDot::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	if (MyRedDot.IsValid())
	{
		MyRedDot->SetContentOffset(Offsets);
		MyRedDot->SetContentAlignment(Alignment);
		MyRedDot->SetContentScale(ContentScale);
		MyRedDot->SetContentAnchors(Anchors);
		MyRedDot->SetColorAndOpacity(ColorAndOpacity);
		MyRedDot->SetForegroundColor(ColorForeground);
	}
}

void UKGRedDot::ReleaseSlateResources(bool bReleaseChildren)
{
	MyRedDot.Reset();
	Super::ReleaseSlateResources(bReleaseChildren);
}

UClass* UKGRedDot::GetSlotClass() const
{
	return UKGRedDotSlot::StaticClass();
}

void UKGRedDot::OnSlotAdded(UPanelSlot* InSlot)
{
	if (MyRedDot.IsValid())
	{
		CastChecked<UKGRedDotSlot>(InSlot)->BuildSlot(MyRedDot.ToSharedRef());
	}
}

void UKGRedDot::OnSlotRemoved(UPanelSlot* InSlot)
{
	if (MyRedDot.IsValid() && InSlot->Content)
	{
		TSharedPtr<SWidget> Widget = InSlot->Content->GetCachedWidget();
		if (Widget.IsValid())
		{
			MyRedDot->SetContent(SNullWidget::NullWidget);
		}
	}
}

TSharedRef<SWidget> UKGRedDot::RebuildWidget()
{
	MyRedDot = SNew(SKGRedDot)
		.Alignment(Alignment)
		.Offset(Offsets)
		.Anchor(Anchors)
		.ColorAndOpacity(ColorAndOpacity)
		.ColorForegound(ColorForeground);
	MyRedDot->SetContentScale(ContentScale);
	if (OwnerWidget)
	{
		MyRedDot->SetOwnerWidget(OwnerWidget->GetCachedWidget());
	}

	if ( GetChildrenCount() > 0 )
	{
		Cast<UKGRedDotSlot>(GetContentSlot())->BuildSlot(MyRedDot.ToSharedRef());
	}
	return MyRedDot.ToSharedRef();
}
