// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGRichTextBlockImageDecorator.h"
#include "PaperSprite.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "PaperSpriteBlueprintLibrary.h"
#include "Framework/Text/SlateTextRun.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Framework/Application/SlateApplication.h"
#include "Fonts/FontMeasure.h"
#include "Math/UnrealMathUtility.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Layout/SScaleBox.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/SOverlay.h"
#include "Misc/DefaultValueHelper.h"
#include "UObject/UObjectGlobals.h"
#include "Framework/Text/SlateWidgetRun.h"
#include "Components/RichTextBlock.h"
#include "Materials/Material.h"
#include "Styling/SlateTypes.h"
#include "Widgets/Text/STextBlock.h"
#include "Slate/Layout/SlateInlineTextImageRun.h"
#include "UMG/Components/KGRichTextBlock.h"
#include "Widgets/SlateGPUTurboWidgets.h" // ADD BY lishihao07@kuaishou.com: Support InlineImage in GPUTurboRichTextblock

class SKGRichInlineImage : public SCompoundWidget
{
public:
	// BEGIN CHANGE BY lishihao07@kuaishou.com: Support InlineImage in GPUTurboRichTextblock
	SLATE_BEGIN_ARGS(SKGRichInlineImage): _bInGPUTurbo(false)
	{}
	SLATE_ARGUMENT( bool, bInGPUTurbo )
	SLATE_END_ARGS()
	// END CHANGE BY lishihao07@kuaishou.com: Support InlineImage in GPUTurboRichTextblock

public:
	void Construct(const FArguments& InArgs, const FSlateBrush* Brush, const FTextBlockStyle& TextStyle, TOptional<int32> Width, TOptional<int32> Height, EStretch::Type Stretch)
	{
		if (ensure(Brush))
		{
			const TSharedRef<FSlateFontMeasure> FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
			float IconHeight = FMath::Min((float)FontMeasure->GetMaxCharacterHeight(TextStyle.Font, 1.0f), Brush->ImageSize.Y);
			float IconWidth = IconHeight;

			if (Width.IsSet())
			{
				IconWidth = Width.GetValue();
			}

			if (Height.IsSet())
			{
				IconHeight = Height.GetValue();
			}
			// BEGIN ADD BY lishihao07@kuaishou.com:  Support InlineImage in GPUTurboRichTextblock
			TSharedPtr<SImage> Image = InArgs._bInGPUTurbo ?
				(SNew(SGPUTurboInlineImage).Image(Brush)) :
				(SNew(SImage).Image(Brush));
			// END ADD BY lishihao07@kuaishou.com:  Support InlineImage in GPUTurboRichTextblock
			
			ChildSlot
			[
				SNew(SBox)
				.HeightOverride(IconHeight)
				.WidthOverride(IconWidth)
				[
					SNew(SScaleBox)
					.Stretch(Stretch)
					.StretchDirection(EStretchDirection::DownOnly)
					.VAlign(VAlign_Center)
					[
						// BEGIN CHANGE BY lishihao07@kuaishou.com:  Support InlineImage in GPUTurboRichTextblock
						Image.ToSharedRef()
						// END CHANGE BY lishihao07@kuaishou.com:  Support InlineImage in GPUTurboRichTextblock
					]
				]
			];
		}
		this->SetVisibility(EVisibility::HitTestInvisible);
	}
};

class FKGRichInlineImage : public FRichTextDecorator
{
public:
	FKGRichInlineImage(URichTextBlock* InOwner, UKGRichTextBlockImageDecorator* InDecorator)
		: FRichTextDecorator(InOwner)
		, Decorator(InDecorator)
	{
	}

	virtual bool Supports(const FTextRunParseResults& RunParseResult, const FString& Text) const override
	{
		if ((RunParseResult.Name == TEXT("img") || RunParseResult.Name == TEXT("Delete") || RunParseResult.Name == TEXT("Mark") || RunParseResult.Name == TEXT("Hide"))&& RunParseResult.MetaData.Contains(TEXT("id")))
		{
			const FTextRange& IdRange = RunParseResult.MetaData[TEXT("id")];
			const FString TagId = Text.Mid(IdRange.BeginIndex, IdRange.EndIndex - IdRange.BeginIndex);

			const bool bWarnIfMissing = false;
			return Decorator->GetSlateBrushGenerator().IsRichImageRowValid(*TagId, bWarnIfMissing);
		}
		
		if (HandleSupports(EC7BrushType::Texture2D, RunParseResult, Text))
		{
			return true;
		}

		if (HandleSupports(EC7BrushType::Sprite, RunParseResult, Text))
		{
			return true;
		}

		if (HandleSupports(EC7BrushType::Material, RunParseResult, Text))
		{
			return true;
		}

		return false;
	}

	virtual TSharedRef<ISlateRun> Create(const TSharedRef<class FTextLayout>& TextLayout, const FTextRunParseResults& RunParseResult, const FString& OriginalText, const TSharedRef< FString >& InOutModelText, const ISlateStyle* Style) override
	{
		FTextRange ModelRange;
		ModelRange.BeginIndex = InOutModelText->Len();

		FTextRunInfo RunInfo(RunParseResult.Name, FText::FromString(OriginalText.Mid(RunParseResult.ContentRange.BeginIndex, RunParseResult.ContentRange.EndIndex - RunParseResult.ContentRange.BeginIndex)));
		for (const TPair<FString, FTextRange>& Pair : RunParseResult.MetaData)
		{
			RunInfo.MetaData.Add(Pair.Key, OriginalText.Mid(Pair.Value.BeginIndex, Pair.Value.EndIndex - Pair.Value.BeginIndex));
		}

		const FTextBlockStyle& TextStyle = Owner->GetCurrentDefaultTextStyle();

		TSharedPtr<ISlateRun> SlateRun;
		TSharedPtr<SWidget> DecoratorWidget = CreateDecoratorWidget(RunInfo, TextStyle);
		if (DecoratorWidget.IsValid())
		{
			*InOutModelText += TEXT('\u200B'); // Zero-Width Breaking Space
			ModelRange.EndIndex = InOutModelText->Len();

			// Calculate the baseline of the text within the owning rich text
			// Requested on demand as the font may not be loaded right now
			const FSlateFontInfo Font = TextStyle.Font;
			const float ShadowOffsetY = FMath::Min(0.0f, TextStyle.ShadowOffset.Y);

			float VAlign = 1;
			FVector2D DesiredSize = FVector2D::Zero();
			if (auto VAlignValuePtr = RunInfo.MetaData.Find(TEXT("valign")))
			{
				DecoratorWidget->MarkPrepassAsDirty();
				DecoratorWidget->SlatePrepass(1.0);
				DesiredSize = DecoratorWidget->GetDesiredSize();
				FDefaultValueHelper::ParseFloat(*VAlignValuePtr, VAlign);
			}

			TAttribute<int16> GetBaseline = TAttribute<int16>::CreateLambda([Font, ShadowOffsetY, DesiredSize, VAlign]()
			{
				const TSharedRef<FSlateFontMeasure> FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
				return FontMeasure->GetBaseline(Font) - ShadowOffsetY + (FontMeasure->GetMaxCharacterHeight(Font) - DesiredSize.Y) * (1 - VAlign);
			});

			FSlateWidgetRun::FWidgetRunInfo WidgetRunInfo(DecoratorWidget.ToSharedRef(), GetBaseline);
			SlateRun = FSlateWidgetRun::Create(TextLayout, RunInfo, InOutModelText, WidgetRunInfo, ModelRange);
		}
		else
		{
			*InOutModelText += OriginalText.Mid(RunParseResult.ContentRange.BeginIndex, RunParseResult.ContentRange.EndIndex - RunParseResult.ContentRange.BeginIndex);
			ModelRange.EndIndex = InOutModelText->Len();
			const FSlateBrush* Brush = nullptr;
			const bool bWarnIfMissing = true;
			if (RunInfo.MetaData.Contains(TEXT("id")))
			{
				if (RunInfo.MetaData.Contains(TEXT("res")))
				{
					Brush = Decorator->GetSlateBrushGenerator().MakeBrush(*RunInfo.MetaData[TEXT("id")], RunInfo.MetaData[TEXT("res")], bWarnIfMissing);
				}
				else
				{
					Brush = Decorator->GetSlateBrushGenerator().MakeBrush(FName(*RunInfo.MetaData[TEXT("id")]), bWarnIfMissing);
				}
			}

			if (!Brush)
			{
				Brush = MakeBrush(EC7BrushType::Texture2D, RunInfo, bWarnIfMissing);
			}

			if (!Brush)
			{
				Brush = MakeBrush(EC7BrushType::Sprite, RunInfo, bWarnIfMissing);
			}

			if (!Brush)
			{
				Brush = MakeBrush(EC7BrushType::Material, RunInfo, bWarnIfMissing);
			}


			if (!Brush)
			{
				return FSlateTextRun::Create(RunInfo, InOutModelText, TextStyle, ModelRange);
			}

			EVerticalAlignment ImageVerticalAlignment = EVerticalAlignment::VAlign_Fill;
			if (RunInfo.Name == "Delete")
			{
				ImageVerticalAlignment = EVerticalAlignment::VAlign_Center;
			}
			
			if (const FString* StyleName = RunInfo.MetaData.Find(TEXT("stylename")))
			{
				if (const auto NamedTextStyle = FindTextStyle(*StyleName, bWarnIfMissing))
				{
					return FSlateInlineTextImageRun::Create(RunInfo, InOutModelText, *NamedTextStyle, ModelRange, Brush, ImageVerticalAlignment);
				}
			}
			return FSlateInlineTextImageRun::Create(RunInfo, InOutModelText, TextStyle, ModelRange, Brush, ImageVerticalAlignment);
		}

		return SlateRun.ToSharedRef();
	}

protected:
	virtual TSharedPtr<SWidget> CreateDecoratorWidget(const FTextRunInfo& RunInfo, const FTextBlockStyle& TextStyle) const override
	{

		if (RunInfo.Name == "Delete" || RunInfo.Name == "Mark" || RunInfo.Name == "Hide")
		{
			return TSharedPtr<SWidget>();
		}

		const FSlateBrush* Brush = nullptr;
		const bool bWarnIfMissing = true;
		if (RunInfo.MetaData.Contains(TEXT("id")))
		{
			if (RunInfo.MetaData.Contains(TEXT("res")))
			{
				Brush = Decorator->GetSlateBrushGenerator().MakeBrush(*RunInfo.MetaData[TEXT("id")], RunInfo.MetaData[TEXT("res")], bWarnIfMissing);
			}
			else
			{
				Brush = Decorator->GetSlateBrushGenerator().MakeBrush(FName(*RunInfo.MetaData[TEXT("id")]), bWarnIfMissing);
			}
		}

		if (!Brush)
		{
			Brush = MakeBrush(EC7BrushType::Texture2D,RunInfo,bWarnIfMissing);
		}
		
		if (!Brush)
		{
			Brush = MakeBrush(EC7BrushType::Sprite,RunInfo,bWarnIfMissing);
		}

		if (!Brush)
		{
			Brush = MakeBrush(EC7BrushType::Material,RunInfo,bWarnIfMissing);
		}

		TOptional<int32> Width;
		if (const FString* WidthString = RunInfo.MetaData.Find(TEXT("width")))
		{
			int32 WidthTemp;
			Width = FDefaultValueHelper::ParseInt(*WidthString, WidthTemp) ? WidthTemp : TOptional<int32>();
		}

		TOptional<int32> Height;
		if (const FString* HeightString = RunInfo.MetaData.Find(TEXT("height")))
		{
			int32 HeightTemp;
			Height = FDefaultValueHelper::ParseInt(*HeightString, HeightTemp) ? HeightTemp : TOptional<int32>();
		}

		EStretch::Type Stretch = EStretch::ScaleToFit;
		if (const FString* SstretchString = RunInfo.MetaData.Find(TEXT("stretch")))
		{
			static const UEnum* StretchEnum = StaticEnum<EStretch::Type>();
			int64 StretchValue = StretchEnum->GetValueByNameString(*SstretchString);
			if (StretchValue != INDEX_NONE)
			{
				Stretch = static_cast<EStretch::Type>(StretchValue);
			}
		}

		if (!Brush)
		{
			return nullptr;
		}
		// BEGIN CHANGE BY lishihao07@kuaishou.com:  Support InlineImage in GPUTurboRichTextblock
		bool bInGPUTurboRichTextBlock = Cast<UKGGPUTurboRichTextBlock>(Owner) != nullptr;
		return SNew(SKGRichInlineImage, Brush, TextStyle, Width, Height, Stretch).bInGPUTurbo(bInGPUTurboRichTextBlock);
		// END CHANGE BY lishihao07@kuaishou.com:  Support InlineImage in GPUTurboRichTextblock
	}

	const FTextBlockStyle* FindTextStyle(const FString& RowName, bool bWarnIfMissing) const
	{
		if (auto RichTextBlock = Cast<UKGRichTextBlock>(Owner))
		{
			if (auto StyleInstance = RichTextBlock->GetStyleInstanceInternal())
			{
				if (StyleInstance->HasWidgetStyle<FTextBlockStyle>(FName(RowName)))
				{
					return &StyleInstance->GetWidgetStyle<FTextBlockStyle>(FName(RowName));
				}
			}
		}
		return nullptr;
	}

private:
	bool HandleSupports(EC7BrushType Type, const FTextRunParseResults& RunParseResult, const FString& Text) const
	{
		FString MetaTag = Decorator->TypeTagMap[Type];
		if (RunParseResult.Name == TEXT("img") && RunParseResult.MetaData.Contains(*MetaTag))
		{
			const FTextRange& IdRange = RunParseResult.MetaData[*MetaTag];
			const FString ImagePath = Text.Mid(IdRange.BeginIndex, IdRange.EndIndex - IdRange.BeginIndex);

			const bool bWarnIfMissing = false;
			return MakeBrush(Type, *ImagePath, bWarnIfMissing) != nullptr;
		}

		return false;
	}

	const FSlateBrush* MakeBrush(EC7BrushType Type, const FString& ResourcePath, bool bWarn) const
	{
		switch (Type)
		{
		case EC7BrushType::Texture2D:
			return Decorator->GetSlateBrushGenerator().MakeBrush<UTexture2D>(ResourcePath, bWarn);
		case EC7BrushType::Sprite:
			return Decorator->GetSlateBrushGenerator().MakeBrush<UPaperSprite>(ResourcePath, bWarn);
		case EC7BrushType::Material:
			return Decorator->GetSlateBrushGenerator().MakeBrush<UMaterial>(ResourcePath, bWarn);
		}
		return nullptr;
	}

	const FSlateBrush* MakeBrush(EC7BrushType Type, const FTextRunInfo& RunInfo, bool bWarn) const
	{
		FString MetaTag = Decorator->TypeTagMap[Type];
		if (RunInfo.MetaData.Contains(*MetaTag))
		{
			FString ResourcePath = RunInfo.MetaData[*MetaTag];
			return MakeBrush(Type, ResourcePath, bWarn);
		}

		return nullptr;
	}
	
	TWeakObjectPtr<UKGRichTextBlockImageDecorator> Decorator;
};

/////////////////////////////////////////////////////
// KGRichTextBlockImageDecorator

UKGRichTextBlockImageDecorator::UKGRichTextBlockImageDecorator(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	TypeTagMap.Add(EC7BrushType::Texture2D, "tex2d");
	TypeTagMap.Add(EC7BrushType::Sprite, "sprite");
	TypeTagMap.Add(EC7BrushType::Material, "mat");
}

void UKGRichTextBlockImageDecorator::SetRichImageDataTables(const TArray<TObjectPtr<UDataTable>>& InRichImageDataTables)
{
	RichImageDataTables = InRichImageDataTables;
	SlateBrushGenerator.Initialize(RichImageDataTables);
}

void UKGRichTextBlockImageDecorator::ClearResourceReferences()
{
	SlateBrushGenerator.Empty();
}

TSharedPtr<ITextDecorator> UKGRichTextBlockImageDecorator::CreateDecorator(URichTextBlock* InOwner)
{
	return MakeShareable(new FKGRichInlineImage(InOwner, this));
}

