// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Components/KGImage.h"

#include "KGSprite.h"
#include "ImageUtils.h"
#include "PaperSprite.h"
#include "Core/Common.h"
#include "Core/DynamicAtlas/DynamicAtlasSubsystem.h"
#include "Core/DynamicAtlas/DynamicSprite.h"
#include "Engine/Texture2DDynamic.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Misc/Base64.h"
#include "UMG/Blueprint/KGSlice9Data.h"
#include "UMG/Components/KGTextureLoader.h"
#include "Widgets/Images/SImage.h"

PRAGMA_DISABLE_DEPRECATION_WARNINGS

#if WITH_EDITOR
void UKGImage::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}
#endif

void UKGImage::SynchronizeProperties()
{
	if (auto DynamicSprite = Cast<UDynamicSprite>(GetBrush().GetResourceObject()))
	{
		TryInitializeDynamicSprite(DynamicSprite);
	}
	UKGSlice9Data::TryApply(this);
	TryUpdateOverrideMaterialParam();
	Super::SynchronizeProperties();
}

TSharedRef<SWidget> UKGImage::RebuildWidget()
{
	OverrideMaterial();
	return Super::RebuildWidget();
}

void UKGImage::TryUpdateOverrideMaterialParam()
{
	SCOPED_NAMED_EVENT(UKGImage_TryUpdateOverrideMaterialParam, FColor::Red);
	// 如果当前没有任何OverrideMaterial操作，直接return
	if (!DynamicMaterialInstance)
	{
		return;
	}
	// 贴图没有变更，直接return
	if (GetBrush().GetResourceObject() == KGOverrideResourceObject.Get())
	{
		return;
	}
	// 保存下原来的Brush
	KGOverrideResourceObject = GetBrush().GetResourceObject();
	// UTexture2D更新OverrideMaterial
	if(GetBrush().GetResourceObject() && GetBrush().GetResourceObject()->IsA<UTexture>())
	{
		DynamicMaterialInstance->SetTextureParameterValue(FName(OverridePropertyMainTexName), Cast<UTexture>(GetBrush().GetResourceObject()));
		SetBrushFromMaterial(DynamicMaterialInstance);
		return;
	}
	// UPaperSprite更新OverrideMaterial
	if (GetBrush().GetResourceObject() && GetBrush().GetResourceObject()->IsA<UPaperSprite>())
	{
		UPaperSprite* Sprite = Cast<UPaperSprite>(GetBrush().GetResourceObject());
		DynamicMaterialInstance->SetTextureParameterValue(FName(OverridePropertyMainTexName), Sprite->GetBakedTexture());
		const FSlateAtlasData& AtlasData = Sprite->GetSlateAtlasData();
		DynamicMaterialInstance->SetVectorParameterValue(FName(OverridePropertyUVParamName), FVector4(AtlasData.SizeUV.X, AtlasData.SizeUV.Y, AtlasData.StartUV.X, AtlasData.StartUV.Y));
		SetBrushFromMaterial(DynamicMaterialInstance);
	}
	// KGSprite更新OverrideMaterial
	if (GetBrush().GetResourceObject() && GetBrush().GetResourceObject()->IsA<UKGSprite>())
	{
		UKGSprite* Sprite = Cast<UKGSprite>(GetBrush().GetResourceObject());
		DynamicMaterialInstance->SetTextureParameterValue(FName(OverridePropertyMainTexName), Sprite->GetTexture());
		const FSlateAtlasData& AtlasData = Sprite->GetSlateAtlasData();
		DynamicMaterialInstance->SetVectorParameterValue(FName(OverridePropertyUVParamName), FVector4(AtlasData.SizeUV.X, AtlasData.SizeUV.Y, AtlasData.StartUV.X, AtlasData.StartUV.Y));
		SetBrushFromMaterial(DynamicMaterialInstance);
	}
}

void UKGImage::OverrideMaterial()
{
	SCOPED_NAMED_EVENT(UKGImage_OverrideMaterial, FColor::Green);
	// 检查下KGMaterialInstance属性是否有被填充，如果有的话，进行OverrideMaterial操作
	if (KGMaterialInstancePtr)
	{
		// 保存下原来的Brush
		KGOverrideResourceObject = GetBrush().GetResourceObject();
		// 检查下FSlateBrushInfo是否是Texture2D
		if(GetBrush().GetResourceObject() && GetBrush().GetResourceObject()->IsA<UTexture>())
		{
			// 根据KGMaterialInstancePtr创建MID，并且将MID的OverridePropertyName属性设置为原先的Brush
			DynamicMaterialInstance = UMaterialInstanceDynamic::Create(KGMaterialInstancePtr, this);
			if (DynamicMaterialInstance)
			{
				DynamicMaterialInstance->SetTextureParameterValue(FName(OverridePropertyMainTexName), Cast<UTexture>(GetBrush().GetResourceObject()));
				SetBrushFromMaterial(DynamicMaterialInstance);
			}
		}
		else if (GetBrush().GetResourceObject() && GetBrush().GetResourceObject()->IsA<UPaperSprite>())
		{
			// 根据KGMaterialInstancePtr创建MID，并设置MID的MainTex参数与UVParam参数
			DynamicMaterialInstance = UMaterialInstanceDynamic::Create(KGMaterialInstancePtr, this);
			if (DynamicMaterialInstance)
			{
				UPaperSprite* Sprite = Cast<UPaperSprite>(GetBrush().GetResourceObject());
				DynamicMaterialInstance->SetTextureParameterValue(FName(OverridePropertyMainTexName), Sprite->GetBakedTexture());
				const FSlateAtlasData& AtlasData = Sprite->GetSlateAtlasData();
				DynamicMaterialInstance->SetVectorParameterValue(FName(OverridePropertyUVParamName), FVector4(AtlasData.SizeUV.X, AtlasData.SizeUV.Y, AtlasData.StartUV.X, AtlasData.StartUV.Y));
				SetBrushFromMaterial(DynamicMaterialInstance);
			}
		}
		else if (GetBrush().GetResourceObject() && GetBrush().GetResourceObject()->IsA<UKGSprite>())
		{
			// 根据KGMaterialInstancePtr创建MID，并设置MID的MainTex参数与UVParam参数
			DynamicMaterialInstance = UMaterialInstanceDynamic::Create(KGMaterialInstancePtr, this);
			if (DynamicMaterialInstance)
			{
				UKGSprite* Sprite = Cast<UKGSprite>(GetBrush().GetResourceObject());
				DynamicMaterialInstance->SetTextureParameterValue(FName(OverridePropertyMainTexName), Sprite->GetTexture());
				const FSlateAtlasData& AtlasData = Sprite->GetSlateAtlasData();
				DynamicMaterialInstance->SetVectorParameterValue(FName(OverridePropertyUVParamName), FVector4(AtlasData.SizeUV.X, AtlasData.SizeUV.Y, AtlasData.StartUV.X, AtlasData.StartUV.Y));
				SetBrushFromMaterial(DynamicMaterialInstance);
			}
		}
	}
}

void UKGImage::UpdateOverrideMaterialBrushFromTexture(UTexture2D* Texture, bool bMatchSize)
{
	Super::SetBrushFromTexture(Texture, bMatchSize);
	TryUpdateOverrideMaterialParam();
}

void UKGImage::UpdateOverrideMaterialBrushFromAtlasInterface(TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize)
{
	Super::SetBrushFromAtlasInterface(AtlasRegion, bMatchSize);
	TryUpdateOverrideMaterialParam();
}

void UKGImage::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);

	if (auto DynamicAtlasSubsystem = UDynamicAtlasSubsystem::GetInstance(this))
	{
		TryUnregisterDynamicAtlasResizedDelegate(DynamicAtlasSubsystem);
	}
}

void UKGImage::BroadcastFieldValueChanged(UE::FieldNotification::FFieldId InFieldId)
{
	UKGSlice9Data::TryApply(this);
	Super::BroadcastFieldValueChanged(InFieldId);
}

void UKGImage::SetBrushFromTexture(UTexture2D* Texture, bool bMatchSize)
{
	Super::SetBrushFromTexture(Texture, bMatchSize);
	OverrideMaterial();
}

void UKGImage::SetBrushFromAtlasInterface(TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize)
{
	if (GetBrush().GetResourceObject() != AtlasRegion.GetObject())
	{
		if (auto DynamicSprite = Cast<UDynamicSprite>(AtlasRegion.GetObject()))
		{
			TryInitializeDynamicSprite(DynamicSprite);
		}
	}
	Super::SetBrushFromAtlasInterface(AtlasRegion, bMatchSize);
}

bool UKGImage::HasSameResource(const FString& Path)
{
	UObject* ResObject = GetBrush().GetResourceObject();

	if (ResObject)
	{
		FString PathName = ResObject->GetPathName();
		return PathName == Path;
	}
	return false;
}

#pragma region 动态图集

void UKGImage::TryInitializeDynamicSprite(UDynamicSprite* DynamicSprite)
{
	check(DynamicSprite);
	
	if (auto DynamicAtlasSubsystem = UDynamicAtlasSubsystem::GetInstance(this))
	{
		DynamicSprite->Initialize(DynamicAtlasSubsystem, UDynamicSprite::FOnInitialized::CreateUObject(this, &UKGImage::OnDynamicSpriteInitialized));
		TryRegisterDynamicAtlasResizedDelegate(DynamicAtlasSubsystem);
	}
}

void UKGImage::OnDynamicSpriteInitialized(UDynamicSprite* DynamicSprite)
{
	if (GetBrush().GetResourceObject() == DynamicSprite)
	{
		ForceRefreshBrushResourceObject();
		if (MyImage.IsValid())
		{
			MyImage->InvalidateImage();
		}
	}
}

void UKGImage::TryRegisterDynamicAtlasResizedDelegate(UDynamicAtlasSubsystem* DynamicAtlasSubsystem)
{
	if (DynamicAtlasResizedDelegateHandle.IsValid())
	{
		return;
	}
	DynamicAtlasResizedDelegateHandle = DynamicAtlasSubsystem->OnAtlasResized().AddUObject(this, &UKGImage::OnDynamicAtlasResized);
}

void UKGImage::TryUnregisterDynamicAtlasResizedDelegate(UDynamicAtlasSubsystem* DynamicAtlasSubsystem)
{
	if (!DynamicAtlasResizedDelegateHandle.IsValid())
	{
		return;
	}
	DynamicAtlasSubsystem->OnAtlasResized().Remove(DynamicAtlasResizedDelegateHandle);
	DynamicAtlasResizedDelegateHandle.Reset();
}

void UKGImage::ForceRefreshBrushResourceObject()
{
	UObject* ResourceObject = GetBrush().GetResourceObject();
	SetBrushResourceObject(nullptr);
	SetBrushResourceObject(ResourceObject);
}

void UKGImage::SetBrushFromSoftDynamicSprite(TSoftObjectPtr<UDynamicSprite> SoftDynamicSprite, bool bMatchSize)
{
	TWeakObjectPtr<UKGImage> WeakThis(this); // using weak ptr in case 'this' has gone out of scope by the time this lambda is called

	RequestAsyncLoad(SoftDynamicSprite,
		[WeakThis, SoftDynamicSprite, bMatchSize]() {
			if (UKGImage* StrongThis = WeakThis.Get())
			{
				ensureMsgf(SoftDynamicSprite.Get(), TEXT("Failed to load %s"), *SoftDynamicSprite.ToSoftObjectPath().ToString());
				StrongThis->SetBrushFromAtlasInterface(SoftDynamicSprite.Get(), bMatchSize);
			}
		}
	);
}

void UKGImage::SetBrushFromSoftTextureTryingToUseDynamicSprite(TSoftObjectPtr<UTexture2D> SoftTexture, bool bMatchSize)
{
	TWeakObjectPtr<UKGImage> WeakThis(this); // using weak ptr in case 'this' has gone out of scope by the time this lambda is called

	RequestAsyncLoad(SoftTexture,
		[WeakThis, SoftTexture, bMatchSize]() {
			if (UKGImage* StrongThis = WeakThis.Get())
			{
				ensureMsgf(SoftTexture.Get(), TEXT("Failed to load %s"), *SoftTexture.ToSoftObjectPath().ToString());
				StrongThis->SetBrushFromTextureTryingToUseDynamicSprite(SoftTexture.Get(), bMatchSize);
			}
		}
	);
}

void UKGImage::SetBrushFromTextureTryingToUseDynamicSprite(UTexture2D* Texture, bool bMatchSize)
{
	if (auto DynamicAtlasSubsystem = UDynamicAtlasSubsystem::GetInstance(this))
	{
		if (auto DynamicSprite = DynamicAtlasSubsystem->NewSprite(Texture))
		{
			this->SetBrushFromAtlasInterface(DynamicSprite, bMatchSize);
			return;
		}
	}
	this->SetBrushFromTexture(Texture, bMatchSize);
}

void UKGImage::OnDynamicAtlasResized(UDynamicAtlas* DynamicAtlas)
{
	UObject* ResourceObject = GetBrush().GetResourceObject();

	if (auto DynamicSprite = Cast<UDynamicSprite>(ResourceObject))
	{
		if (DynamicSprite->GetAtlas() == DynamicAtlas)
		{
			ForceRefreshBrushResourceObject();
		}
	}
}

#pragma endregion

void UKGImage::CancelImageStreaming()
{
	if (StreamingHandle.IsValid())
	{
		PopOpacity(EKGImageOpacityCacheReason::Brush);
	}
	Super::CancelImageStreaming();
}

void UKGImage::SetBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize, bool bHiddenDuringLoading)
{
	TSoftObjectPtr<UObject> SoftObject = TSoftObjectPtr<UObject>(SoftObjectPath);
	if (SoftObject.IsNull())
	{
		UE_LOG(LogKGUI, Warning, TEXT("Try to SetBrushFromSoftObject (%s) Which is Null!"), *SoftObjectPath);
		return;
	}
	SetBrushFromSoftObject(SoftObject, bMatchSize, bHiddenDuringLoading);
	// 设置完毕，尝试更新overrideMaterial
	TryUpdateOverrideMaterialParam();
}

void UKGImage::SetBrushFromSoftObject(TSoftObjectPtr<UObject> SoftObject, bool bMatchSize, bool bHiddenDuringLoading)
{
	if (SoftObject.IsNull())
	{
		UE_LOG(LogKGUI, Warning, TEXT("Try to SetBrushFromSoftObject Which is Null!"));
		return;
	}
	CancelImageStreaming();  // IMPORTANT: 提前取消，才能重置Opacity，以便在下次RequestAsyncLoad之前恢复正确不透明度

	TWeakObjectPtr<UKGImage> WeakThis(this); // using weak ptr in case 'this' has gone out of scope by the time this lambda is called

	if (bHiddenDuringLoading)
	{
		PushOpacity(EKGImageOpacityCacheReason::Brush);
	}

	RequestAsyncLoad(SoftObject,
		[WeakThis, SoftObject, bMatchSize, bHiddenDuringLoading]() {

#if 0  // 调试用
			if (auto StrongThis = WeakThis.Get()) { FTimerHandle TimerHandle; StrongThis->GetWorld()->GetTimerManager().SetTimer(TimerHandle, FTimerDelegate::CreateLambda([&]() {
#endif

			if (UKGImage* StrongThis = WeakThis.Get())
			{
				if (bHiddenDuringLoading)
				{
					StrongThis->PopOpacity(EKGImageOpacityCacheReason::Brush);
				}
				auto StrongObject = SoftObject.Get();
				if (!StrongObject)
				{
					UE_LOG(LogKGUI, Error, TEXT("Failed to load %s"), *SoftObject.ToSoftObjectPath().ToString());
				}
				if (auto Texture2D = Cast<UTexture2D>(StrongObject))
				{
					StrongThis->SetBrushFromTextureTryingToUseDynamicSprite(Texture2D, bMatchSize);
				}
				else if (auto MaterialInterface = Cast<UMaterialInterface>(StrongObject))
				{
					StrongThis->SetBrushFromMaterial(MaterialInterface);
				}
				else if (auto AtlasInterface = Cast<ISlateTextureAtlasInterface>(StrongObject))
				{
					StrongThis->SetBrushFromAtlasInterface(StrongObject, bMatchSize);
				}
				else if (auto Texture2DDynamic = Cast<UTexture2DDynamic>(StrongObject))
				{
					StrongThis->SetBrushFromTextureDynamic(Texture2DDynamic, bMatchSize);
				}
				else
				{
					StrongThis->SetBrushFromTexture(nullptr);
				}
			}


#if 0  // 调试用
			}), 2, false); }
#endif

		}
	);
}

void UKGImage::SetMaterialTextureParameterFromSoftObject(const FName& ParameterName, const FString& SoftObjectPath, bool bAsync, bool bHiddenDuringLoading)
{
	TSoftObjectPtr<UObject> SoftObject = TSoftObjectPtr<UObject>(SoftObjectPath);
	if (SoftObject.IsNull())
	{
		UE_LOG(LogKGUI, Warning, TEXT("Try to SetMaterialTextureParameterFromSoftObject (%s) Which is Null!"), *SoftObjectPath);
		return;
	}
	SetMaterialTextureParameterFromSoftObject(ParameterName, SoftObject, bAsync, bHiddenDuringLoading);
}

void UKGImage::SetMaterialTextureParameterFromSoftObject(const FName& ParameterName, TSoftObjectPtr<UObject> SoftObject, bool bAsync, bool bHiddenDuringLoading)
{
	if (!bAsync)
	{
		SetMaterialTextureParameter(ParameterName, Cast<UTexture>(SoftObject.LoadSynchronous()));
	}
	else
	{
		if (!MaterialTextureLoader.IsValid())
		{
			MaterialTextureLoader = MakeShared<FKGTextureLoader>();
		}
		PushOpacity(EKGImageOpacityCacheReason::TextureParameter);
		MaterialTextureLoader->RequestAsyncLoad(
			SoftObject,
			FKGTextureLoader::FOnTextureLoadCompleted::CreateLambda([WeakThis = TWeakObjectPtr<UKGImage>(this), ParameterName, SoftObject]()
			{
#if 0  // 调试用
				if (auto StrongThis = WeakThis.Get()) { FTimerHandle TimerHandle; StrongThis->GetWorld()->GetTimerManager().SetTimer(TimerHandle, FTimerDelegate::CreateLambda([&]() {
#endif

				if (auto This = WeakThis.Get())
				{
					This->PopOpacity(EKGImageOpacityCacheReason::TextureParameter);
					This->SetMaterialTextureParameter(ParameterName, Cast<UTexture>(SoftObject.LoadSynchronous()));
				}

#if 0  // 调试用
				}), 2, false); }
#endif

			}),
			FKGTextureLoader::FOnTextureLoadCancelled::CreateLambda([WeakThis = TWeakObjectPtr<UKGImage>(this)]()
			{
				if (auto This = WeakThis.Get())
				{
					This->PopOpacity(EKGImageOpacityCacheReason::TextureParameter);
				}
			})
		);
	}
}

bool UKGImage::SetMaterialTextureParameter(const FName& ParameterName, UTexture* Texture)
{
	if (Texture)
	{
		if (auto MID = GetDynamicMaterial())
		{
			MID->SetTextureParameterValue(ParameterName, Texture);
			return true;
		}
		else
		{
			UE_LOG(LogKGUI, Warning, TEXT("Failed to call 'SetMaterialTextureParameterFromSoftObject': Material Instance Dynamic (MID) is null. Widget: %s."), *this->GetPathName());
		}
	}
	return false;
}

void UKGImage::SetBrushFromBase64(const FString& Base64String)
{
	if (TArray<uint8> ByteArray; FBase64::Decode(Base64String, ByteArray))
	{
		if (UTexture2D* Texture = FImageUtils::ImportBufferAsTexture2D(ByteArray))
		{
			SetBrushFromTexture(Texture);
		}
		else
		{
			UE_LOG(LogKGUI, Warning, TEXT("Failed to create texture from base64 string."));
		}
	}
	else
	{
		UE_LOG(LogKGUI, Warning, TEXT("Failed to decode base64 string."));
	}
}

bool FKGSlateBrush::Serialize(FArchive& Ar)
{
	if (bUseSoftObject &&Ar.IsCooking())
	{
		UObject* ResourceObj = Brush.GetResourceObject();
		if (ResourceObj)
		{
			Brush.SetResourceObject(nullptr);
			BrushResourceObj = ResourceObj;
		}
	}

	if (Ar.IsLoading() || Ar.IsSaving())
	{
		UScriptStruct* Struct = FKGSlateBrush::StaticStruct();
		Struct->SerializeTaggedProperties(Ar, (uint8*)this, Struct, nullptr);
	}
	
    return true;
}

void UKGImage::PushOpacity(EKGImageOpacityCacheReason InOpacityCacheReason)
{
	ensure(InOpacityCacheReason != EKGImageOpacityCacheReason::None);

	auto OldOpacityCacheReason = OpacityCacheReason;
	auto NewOpacityCacheReason = OpacityCacheReason | InOpacityCacheReason;

	if (OldOpacityCacheReason == NewOpacityCacheReason)
	{
		return;
	}
	if (OldOpacityCacheReason == EKGImageOpacityCacheReason::None)
	{
		ensure(!CachedOpacity.IsSet());
		CachedOpacity = GetColorAndOpacity().A;
		SetColorAndOpacity(GetColorAndOpacity().CopyWithNewOpacity(0));
	}
	OpacityCacheReason = NewOpacityCacheReason;
}

void UKGImage::PopOpacity(EKGImageOpacityCacheReason InOpacityCacheReason)
{
	ensure(InOpacityCacheReason != EKGImageOpacityCacheReason::None);

	auto OldOpacityCacheReason = OpacityCacheReason;
	auto NewOpacityCacheReason = OpacityCacheReason & (~InOpacityCacheReason);

	if (OldOpacityCacheReason == NewOpacityCacheReason)
	{
		return;
	}
	if (NewOpacityCacheReason == EKGImageOpacityCacheReason::None)
	{
		ensure(CachedOpacity.IsSet());
		if (CachedOpacity.IsSet())
		{
			SetColorAndOpacity(GetColorAndOpacity().CopyWithNewOpacity(CachedOpacity.GetValue()));
			CachedOpacity.Reset();
		}
	}
	OpacityCacheReason = NewOpacityCacheReason;
}
