// Fill out your copyright notice in the Description page of Project Settings.
#include "UMG/Components/KGRichTextBlock.h"

#include "Components/RichTextBlockDecorator.h"
#include "Styling/SlateStyle.h"
#include "Engine/World.h"

#include "UMG/Components/KGRichTextSettings.h"
#include "UMG/Components/KGRichTextBlockHyperlinkDecorator.h"
#include "UMG/Components/KGRichTextBlockImageDecorator.h"
#include "UMG/Components/KGRichTextBlockTextDecorator.h"

#include "Blueprint/SlateBlueprintLibrary.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Framework/Text/IRichTextMarkupParser.h"
#include "LuaCppBinding.h"
#include "RenderDeferredCleanup.h"
#include "Engine/GameInstance.h"
// BEGIN ADD BY lishihao07@kuaishou.com: GPUTurbo RichTextBlock
#include "KGUISettings.h"
#include "Core/Common.h"
#include "Framework/Text/RichTextLayoutMarshaller.h"
#include "UMG/Blueprint/KGRichTextStyleOverrideRow.h"
#include "UMG/Components/KGRichTextLayoutMarshaller.h"
#include "Widgets/SlateGPUTurboWidgets.h"
// END ADD BY lishihao07@kuaishou.com: GPUTurbo RichTextBlock

#include "KGUI.h"
#include "Slate/Text/SKGGPUTurboRichTextBlock.h"


namespace KG::RichTextBlock::Private
{
	template< class ObjectType >
	struct FDeferredDeletor : public FDeferredCleanupInterface
	{
	public:
		FDeferredDeletor(ObjectType* InInnerObjectToDelete)
			: InnerObjectToDelete(InInnerObjectToDelete)
		{
		}

		virtual ~FDeferredDeletor()
		{
			delete InnerObjectToDelete;
		}

	private:
		ObjectType* InnerObjectToDelete;
	};

	template< class ObjectType >
	FORCEINLINE TSharedPtr< ObjectType > MakeShareableDeferredCleanup(ObjectType* InObject)
	{
		return MakeShareable(InObject, [](ObjectType* ObjectToDelete) { BeginCleanup(new FDeferredDeletor<ObjectType>(ObjectToDelete)); });
	}
}

UKGRichTextBlock::UKGRichTextBlock(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	 if (const UKGRichTextSettings* Settings = GetDefault<UKGRichTextSettings>())
	 {
	 	UDataTable *RichTextStyle = LoadObject<UDataTable>(nullptr, *Settings->TextStyleSet.GetAssetPathString());
	 	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	 	TextStyleSet = RichTextStyle;
	 	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	 }

	 if (HasAnyFlags(RF_ArchetypeObject | RF_ClassDefaultObject))
	 {
		 using namespace NS_SLUA;
		 REG_EXTENSION_METHOD_IMP(UKGRichTextBlock, "GetTextBlockDesiredSize", {
				int32 NumParams = lua_gettop(L);
				CheckUD(UKGRichTextBlock, L, 1);
				const FText& inText = FText::FromString(LuaObject::checkValue<FString>(L, 2));
				bool useViewportScale = false;
				 if (NumParams > 2)
				 { 
					 useViewportScale = LuaObject::checkValue<bool>(L, 3);
				 }
				 FVector2D ret = UD->GetTextScale(inText, useViewportScale);
				 slua::LuaObject::push(L, ret.X);
				 slua::LuaObject::push(L, ret.Y);
				 return 2;
			 });
	 }
}

#if WITH_EDITOR
void UKGRichTextBlock::OnCreationFromPalette()
{
	Super::OnCreationFromPalette();
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	bUseRichFormatting = false;
	bOverrideDefaultStyle = true;
	if (auto Settings = GetDefault<UKGUISettings>())
	{
		DefaultTextStyleOverride = Settings->DefaultTextBlockStyle;
	}
	SetText(NSLOCTEXT("UMG", "TextBlockDefaultValue", "Text Block"));
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	if (auto KGUI = FModuleManager::Get().GetModulePtr<FKGUIModule>("KGUI"))
	{
		KGUI->GetOnWidgetCreatedFromPalette().Broadcast(this);
	}
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}
#endif


void UKGRichTextBlock::AddDefaultDecorators()
{
	// TODO: 这里还不如直接配置好颜色和图片两个表的资源对象（现在是配的路径，然后通过LoadObject加载的）
	if (DefaultTextDecorator == nullptr)
	{
		DefaultTextDecorator = CreateRichTextBlockTextDecorator(this);
	}
	auto RichImageDataTables = GetRichImageDataTables(this);
	if (DefaultImageDecorator == nullptr)
	{
		DefaultImageDecorator = CreateRichTextBlockImageDecorator(this, RichImageDataTables);
	}
	if (DefaultHyperlinkDecorator == nullptr)
	{
		DefaultHyperlinkDecorator = CreateRichTextBlockHyperlinkDecorator(this, RichImageDataTables);
	}

	InstanceDecorators.Add(DefaultTextDecorator);
	InstanceDecorators.Add(DefaultImageDecorator);
	InstanceDecorators.Add(DefaultHyperlinkDecorator);
}

void UKGRichTextBlock::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	InstanceDecorators.Reset();
}

TSharedRef<SWidget> UKGRichTextBlock::RebuildWidget()
{
	return RebuildWidgetInternal<SKGRichTextBlock>("SKGRichTextBlock");
}

UKGRichTextBlockTextDecorator* UKGRichTextBlock::CreateRichTextBlockTextDecorator(UObject* Outer)
{
	auto Decorator = NewObject<UKGRichTextBlockTextDecorator>(Outer, TEXT("RichTextBlockTextDecorator"));
	if (const UKGRichTextSettings* Settings = GetDefault<UKGRichTextSettings>())
	{
		Decorator->SetColorDir(*Settings->ColorTablesDir);
	}
	return Decorator;
}

UKGRichTextBlockImageDecorator* UKGRichTextBlock::CreateRichTextBlockImageDecorator(UObject* Outer, const TArray<TObjectPtr<UDataTable>>& RichImageDataTables)
{
	auto Decorator = NewObject<UKGRichTextBlockImageDecorator>(Outer, TEXT("RichTextBlockImageDecorator"));
	if (const UKGRichTextSettings* Settings = GetDefault<UKGRichTextSettings>())
	{
		Decorator->SetRichImageDataTables(RichImageDataTables);
	}
	return Decorator;
}

UKGRichTextBlockHyperlinkDecorator* UKGRichTextBlock::CreateRichTextBlockHyperlinkDecorator(UObject* Outer, const TArray<TObjectPtr<UDataTable>>& RichImageDataTables)
{
	auto Decorator = NewObject<UKGRichTextBlockHyperlinkDecorator>(Outer, TEXT("RichTextBlockHyperlinkDecorator"));
	if (const UKGRichTextSettings* Settings = GetDefault<UKGRichTextSettings>())
	{
		Decorator->SetColorDir(*Settings->ColorTablesDir);
		Decorator->SetRichImageDataTables(RichImageDataTables);
	}
	return Decorator;
}

TArray<TObjectPtr<UDataTable>> UKGRichTextBlock::GetRichImageDataTables(UKGRichTextBlock* RichTextBlock)
{
	TArray<TObjectPtr<UDataTable>> RichImageDataTables;
	if (const UKGRichTextSettings* Settings = GetDefault<UKGRichTextSettings>())
	{
		UDataTable* ImageSet = LoadObject<UDataTable>(nullptr, *Settings->ImgSet.GetAssetPathString());
		if (ImageSet)
		{
			RichImageDataTables.Add(ImageSet);
		}
	}
	if (RichTextBlock->ImageOverrideDataTable != nullptr)
	{
		RichImageDataTables.Add(RichTextBlock->ImageOverrideDataTable);
	}
	return RichImageDataTables;
}

void UKGRichTextBlock::SetText(const FText& InText)
{
#if WITH_EDITOR
	const bool bEnableTextBlockChangeCheck = GetDefault<UKGUISettings>()->bEnableTextBlockChangeCheck;
#else
	const static bool bEnableTextBlockChangeCheck = GetDefault<UKGUISettings>()->bEnableTextBlockChangeCheck;
#endif
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	if (bEnableTextBlockChangeCheck && /*!TextDelegate.IsBound() &&*/ (Text.IdenticalTo(InText) || (Text.IsInitializedFromString() && InText.IsInitializedFromString() && Text.EqualTo(InText))))
	{
		return;
	}
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	Super::SetText(InText);
}

void UKGRichTextBlock::UpdateStyleData()
{
	bool bRebuild = !StyleInstance.IsValid();
	Super::UpdateStyleData();
	if (bRebuild)
	{
		AddDefaultDecorators();
	}
}

void UKGRichTextBlock::ApplyUpdatedDefaultTextStyle()
{
	if (MyRichTextBlock.IsValid())
	{
		StaticCastSharedPtr<SKGRichTextBlock>(MyRichTextBlock)->MarkDecoratorStyleSetAsDirty();
	}
	Super::ApplyUpdatedDefaultTextStyle();
}

TArray<UDataTable*> UKGRichTextBlock::GetTextStyleSetArray()
{
	if (bUseMultiTextStyle)
	{
		return TextStyleSetArray;
	}
	TArray TempArray = {GetTextStyleSet()};
	return TempArray;
}

void UKGRichTextBlock::SetDefaultRowName(FName RowName)
{
	DefaultRowName = RowName;
	for (const auto StyleSet : GetTextStyleSetArray())
	{
		if (StyleSet)
		{
			auto RichTextStyle = StyleSet->FindRow<FRichTextStyleRow>(RowName, TEXT("Find Default Rich Text Row"));
			if (RichTextStyle != nullptr)
			{
				DefaultTextStyle = RichTextStyle->TextStyle;
			}
		}
	}
	ApplyUpdatedDefaultTextStyle();
}

//Modify By Bruce Start 2023.8.28
void UKGRichTextBlock::SetLatterSpaceAnim(float InLetterSpacing)
{
	BeginDefaultStyleOverride();

	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	DefaultTextStyleOverride.Font.LetterSpacing = static_cast<int32>(InLetterSpacing);
	PRAGMA_ENABLE_DEPRECATION_WARNINGS

	ApplyUpdatedDefaultTextStyle();
}
//Modify By Bruce End 2023.8.28

bool UKGRichTextBlock::GetRunLocationAndSize(const FString& Content, FVector2D& Location, FVector2D& Size)
{
	if(!MyRichTextBlock.IsValid() || Content.IsEmpty())
	{
		return false;
	}

	FString ContentString = Content;
	if(ContentString.StartsWith(TEXT("<")) && ContentString.Find(TEXT(">")) != INDEX_NONE && !ContentString.EndsWith(TEXT("</>")))
	{
		ContentString += TEXT("</>");
	}

	TSharedPtr<IRichTextMarkupParser> Parser = CreateMarkupParser();
	TArray<FTextLineParseResults> ResultParsed;
	FString ResultString;
	Parser->Process(ResultParsed, ContentString, ResultString);

	if(ResultString.IsEmpty() || ResultParsed[0].Runs.Num() <= 0)
	{
		return false;
	}

	const FTextRunParseResults& Pattern = ResultParsed[0].Runs[0];
	FString PatternStr;
	if (Pattern.ContentRange.BeginIndex == INDEX_NONE)
	{
		PatternStr = Content;
	}
	else
	{
		PatternStr = Content.Mid(Pattern.ContentRange.BeginIndex, Pattern.ContentRange.EndIndex - Pattern.ContentRange.BeginIndex);
	}
	
	struct FLineModelMatched
	{
		int32 LineModelIndex = INDEX_NONE;
		FTextRange Range; // text range, [start, end)
	};
	
	TArray<FLineModelMatched> LineModelMatched;
	const TArray<FTextLayout::FLineModel>& LineModels = MyRichTextBlock->GetLineModels();
	for(int32 Idx = 0; Idx < LineModels.Num(); Idx++)
	{
		const FTextLayout::FLineModel& LineModel = LineModels[Idx];
		int32 StartIndex = LineModel.Text->Find(PatternStr);
		if(StartIndex != INDEX_NONE && StartIndex + PatternStr.Len() - 1 < LineModel.Text->Len())
		{
			FLineModelMatched& Result = LineModelMatched.AddDefaulted_GetRef();
			Result.Range.BeginIndex = StartIndex;
			Result.Range.EndIndex = StartIndex + PatternStr.Len();
			Result.LineModelIndex = Idx;
		}
	}
	
	const TArray<FTextLayout::FLineView>& LineViews = MyRichTextBlock->GetLineViews();
	for(const FTextLayout::FLineView& LineView : LineViews)
	{
		for(const auto& LineModel : LineModelMatched)
		{
			if(LineView.ModelIndex != LineModel.LineModelIndex)
			{
				continue;
			}

			for(const TSharedRef<ILayoutBlock>& Block : LineView.Blocks)
			{
				FString StyleName = Block->GetRun()->GetRunInfo().Name;
				if(Pattern.Name.IsEmpty() || Pattern.Name == Block->GetRun()->GetRunInfo().Name)
				{
					const FTextRange Intersection = Block->GetTextRange().Intersect(LineModel.Range);
					if(Intersection.BeginIndex >= 0 && Intersection.BeginIndex < Intersection.EndIndex)
					{
						float InverseScale = Inverse(GetCachedGeometry().Scale);
						FVector2D SizePattern = Block->GetRun()->Measure(Intersection.BeginIndex, Intersection.EndIndex, GetCachedGeometry().Scale, 
						Block->GetTextContext());
						FVector2D Offset = Block->GetRun()->GetLocationAt(Block, Intersection.BeginIndex - Block->GetTextRange().BeginIndex, 
						GetCachedGeometry().Scale);
						Offset.Y = Block->GetLocationOffset().Y; // Because pattern text is on the same line of block, so offset Y is same with the offset Y of block.
						FGeometry& MutableGeometry = const_cast<FGeometry&>(GetCachedGeometry());
						FPaintGeometry PaintGeometry = MutableGeometry.ToPaintGeometry(
							TransformVector(InverseScale, SizePattern),
							FSlateLayoutTransform(TransformPoint(InverseScale, Offset))
						);
						Location.Set(PaintGeometry.DrawPosition.X, PaintGeometry.DrawPosition.Y);
						Size = TransformVector(InverseScale, SizePattern);
						return true;
					}
				}
			}
		}
	}

	return false;
}

bool UKGRichTextBlock::GetRunLocationAndSizeByRange(const int32 BeginIndex, const int32 EndIndex, FVector2D& Location, FVector2D& Size, bool bLimitByClickPosition, FVector2D LimitPosition)
{
	if (!MyRichTextBlock.IsValid())
	{
		UE_LOG(LogKGUI, Error, TEXT("[Code] Attempted to call GetRunLocationAndSizeByRange for RichTextBlock(%s) whose Slate widget hasn't been created!"), *this->GetPathName());
		return false;
	}
	const TArray<FTextLayout::FLineView> lineViews = MyRichTextBlock->GetLineViews();
	const TArray<FTextLayout::FLineModel> lineModel = MyRichTextBlock->GetLineModels();
	FTextRange RunRange(BeginIndex, EndIndex);
	FVector2D PixelPosition(0, 0);
	FVector2D ViewportStartPosition(0, 0);
	FVector2D ViewportEndPosition(0, 0);
	for (FTextLayout::FLineView lineView : lineViews)
	{
		for (int32 Index = 0; Index < lineView.Blocks.Num(); Index++)
		{
			const FTextRange Intersection = lineView.Blocks[Index]->GetTextRange().Intersect(RunRange);
			if (Intersection.BeginIndex >= RunRange.BeginIndex && Intersection.EndIndex <= RunRange.EndIndex && Intersection.BeginIndex < Intersection.EndIndex)
			{
				float InverseScale = Inverse(GetCachedGeometry().Scale);
				FGeometry& MutableGeometry = const_cast<FGeometry&>(GetCachedGeometry());
				FPaintGeometry PaintGeometry = MutableGeometry.ToPaintGeometry(
					TransformVector(InverseScale, lineView.Blocks[Index]->GetSize()),
					FSlateLayoutTransform(TransformPoint(InverseScale, lineView.Blocks[Index]->GetLocationOffset()))
				);
				
				Location.Set(PaintGeometry.DrawPosition.X, PaintGeometry.DrawPosition.Y);
				Size = TransformVector(InverseScale, lineView.Blocks[Index]->GetSize());
				USlateBlueprintLibrary::AbsoluteToViewport(GetGameInstance(), Location, PixelPosition, ViewportStartPosition);
				USlateBlueprintLibrary::AbsoluteToViewport(GetGameInstance(), Location + Size, PixelPosition, ViewportEndPosition); 
				if (bLimitByClickPosition)//根据鼠标位置选择block
				{
					if (LimitPosition.X >= ViewportStartPosition.X && LimitPosition.X <= ViewportEndPosition.X && LimitPosition.Y >= ViewportStartPosition.Y && LimitPosition.Y <= ViewportEndPosition.Y)
					{
						return true;
					}
				}
				else
				{
					return true;
				}
				
			}
		}
	}
	return false;
}

void UKGRichTextBlock::RebuildStyleInstance()
{
	if (!bUseRichFormatting)
	{
		return;
	}
	StyleInstance = KG::RichTextBlock::Private::MakeShareableDeferredCleanup(new FSlateStyleSet(TEXT("RichTextStyle")));
	TSet<FName> StyleNames;
	TArray<UDataTable*> FinalTextStyleSetArray = GetTextStyleSetArray();
	if (FinalTextStyleSetArray.Num() > 0)
	{
		for (const auto FinalTextStyleSet : FinalTextStyleSetArray)
		{
			if (!FinalTextStyleSet)
			{
				continue;
			}
			if (!ensure(FinalTextStyleSet->GetRowStruct() == FRichTextStyleRow::StaticStruct()))
			{
				continue;
			}
			for (const auto& Entry : FinalTextStyleSet->GetRowMap())
			{
				FRichTextStyleRow* RichTextStyleRow = (FRichTextStyleRow*)Entry.Value;
				if (DefaultRowName == Entry.Key)
				{
					DefaultTextStyle = RichTextStyleRow->TextStyle;
				}
				// TODO: 如何TextStyleSetArray里面存在两个TextStyleSet里面的Key相同整么办？
				StyleInstance->Set(Entry.Key, FKGRichTextStyleOverrideRow::OverrideFromChain(TextStyleOverrideDataTableChain, Entry.Key, &RichTextStyleRow->TextStyle));
				StyleNames.Add(Entry.Key);
			}
		}
	}
	if (TextStyleOverrideDataTableChain.Num() > 0)
	{
		for (auto TextStyleOverrideDataTable : TextStyleOverrideDataTableChain)
		{
			if (TextStyleOverrideDataTable == nullptr)
			{
				continue;
			}
			for (auto StyleName : TextStyleOverrideDataTable->GetRowNames())
			{
				if (!StyleNames.Contains(StyleName))
				{
					StyleInstance->Set(StyleName, FKGRichTextStyleOverrideRow::OverrideFromChain(TextStyleOverrideDataTableChain, StyleName, &GetCurrentDefaultTextStyle()));
					StyleNames.Add(StyleName);
				}
			}
		}
	}
}

void UKGRichTextBlock::HandleOnRebuildDecoratorStyleSet()
{
	RebuildStyleInstance();
	MyRichTextBlock->SetDecoratorStyleSet(StyleInstance.Get());
}

//Compute Text Block Size
FVector2D UKGRichTextBlock::GetTextScale(const FText& inText, bool useViewportScale)
{
	if (!MyRichTextBlock.IsValid())
	{
		UE_LOG(LogKGUI, Error, TEXT("[Code] Attempted to call GetTextScale for RichTextBlock(%s) whose Slate widget hasn't been created!"), *this->GetPathName());
		return FVector2D();
	}
	if (useViewportScale)
	{
		float inScale = UWidgetLayoutLibrary::GetViewportScale(GetWorld());
		return MyRichTextBlock->GetTextLayoutSize(inText, useViewportScale, inScale);
	}
	else
	{
		return MyRichTextBlock->GetTextLayoutSize(inText, useViewportScale, 0);
	}
}

//RichTextBlock AutoPaging
TArray<FKGRichTextBlockPageData> UKGRichTextBlock::GetAutoPages(const FText& inText, bool OnlyUseViewportScale)
{	
	TArray<FKGRichTextBlockPageData> PageDatas;
	if (!MyRichTextBlock.IsValid())
	{
		UE_LOG(LogKGUI, Error, TEXT("[Code] Attempted to call GetAutoPages for RichTextBlock(%s) whose Slate widget hasn't been created!"), *this->GetPathName());
		return PageDatas;
	}
	float inScale = 0;
	if (OnlyUseViewportScale)
	{
		inScale = UWidgetLayoutLibrary::GetViewportScale(GetWorld());
	}
	TArray <FPageView> pageView = MyRichTextBlock->GetAutoPage(inText, MaxWrapHeight, OnlyUseViewportScale, inScale);
	for (int page = 0; page < pageView.Num(); page++)
	{
		FKGRichTextBlockPageData newPage;
		newPage.BeginIndex = pageView[page].Range.BeginIndex;
		newPage.EndIndex = pageView[page].Range.EndIndex;
		newPage.StartAdd = pageView[page].PageStartAdd;
		newPage.EndAdd = pageView[page].PageEndAdd;
		PageDatas.Add(newPage);
	}
	return PageDatas;
}

//Center-Right Ellipsis
void UKGRichTextBlock::SetAlwaysEllipsis(bool InAlwaysEllipsis)
{
	AlwaysEllipsis = InAlwaysEllipsis;
	if (MyRichTextBlock.IsValid())
	{
		MyRichTextBlock->SetAlwaysEllipsis(InAlwaysEllipsis);
	}
}

bool UKGRichTextBlock::GetAlwaysEllipsis() const
{
	return AlwaysEllipsis;
}

//Adaptive Line
void UKGRichTextBlock::SetTextAdaptively(const FText& inText)
{
	if (!MyRichTextBlock.IsValid())
	{
		UE_LOG(LogKGUI, Error, TEXT("[Code] Attempted to call SetTextAdaptively for RichTextBlock(%s) whose Slate widget hasn't been created! Fallback to call SetText."), *this->GetPathName());
		SetText(inText);
		return;
	}
	MyRichTextBlock->SetAdaptiveOffset(0.0f);
	FVector2D textSize = GetTextScale(inText, true);
	if (MyRichTextBlock->GetLineModelNum() == 1)
	{
		float offset = 0.f;
		TArray<FVector2D> lineViewSize = MyRichTextBlock->GetLineViewsSize();
		if (lineViewSize.Num() > 1)
		{
			int32 lineNum = lineViewSize.Num();
			float maxWidth = 0;
			for (int i = 0; i < lineNum; i++)
			{
				if (lineViewSize[i].X > maxWidth)
				{
					maxWidth = lineViewSize[i].X;
				}
			}
			
			float lastLineWidth = lineViewSize[lineNum - 1].X;
			int32 leftlineNum = lineNum - 1;
			if (lastLineWidth < maxWidth * 0.3f && lineNum > 2)
			{
				offset = (0.3f * maxWidth - lastLineWidth) / (1.0f + 0.3f / leftlineNum);
			}
			else if (lastLineWidth < maxWidth * 0.2f && lineNum == 2)
			{
				offset = (0.2f * maxWidth - lastLineWidth) / 1.2f;
			}

			MyRichTextBlock->SetAdaptiveOffset(offset);
			FVector2D newSize = GetTextScale(inText, true);
			float k = 0;
		}
	}
	
	SetText(inText);
}

void UKGRichTextBlock::SwitchDefaultStyle(const FString& InTextStyleName)
{
	if (TArray<UDataTable*> TextSetArray = GetTextStyleSetArray(); TextSetArray.Num() > 0)
	{
		for (const auto* TextSet : TextSetArray)
		{
			if (TextSet)
			{
				for (const auto& Entry : TextSet->GetRowMap())
				{
					FName SubStyleName = Entry.Key;
					FRichTextStyleRow* RichTextStyle = reinterpret_cast<FRichTextStyleRow*>(Entry.Value);
					if (InTextStyleName == SubStyleName)
					{
						StyleInstance->Set(SubStyleName, RichTextStyle->TextStyle);
						SetDefaultTextStyle(RichTextStyle->TextStyle);
						break;
					}
				}
			}
		}
	}
}

void UKGRichTextBlock::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	
	if (MyRichTextBlock.IsValid())
	{
		SetAlwaysEllipsis(AlwaysEllipsis);
	}
	
}

#pragma region 计时动态效果

void UKGRichTextBlock::SetCountDownTimeFormat(const FString& Format)
{
	GetOrCreateCountDownController().SetCountDownTimeFormat(Format);
}

void UKGRichTextBlock::SetCountDownTimeFormatByCondition(
	double LowerBoundSeconds, EKGCountDownConditionIntervalType LowerIntervalType,
	double UpperBoundSeconds, EKGCountDownConditionIntervalType UpperIntervalType,
	const FString& Format)
{
	GetOrCreateCountDownController().SetCountDownTimeFormatByCondition(LowerBoundSeconds, LowerIntervalType, UpperBoundSeconds, UpperIntervalType, Format);
}

void UKGRichTextBlock::SetCountDownTimeFormatByFirstNonzeroUnit(FName FirstNonzeroUnitName, const FString& Format)
{
	GetOrCreateCountDownController().SetCountDownTimeFormatByFirstNonzeroUnit(FirstNonzeroUnitName, Format);
}

void UKGRichTextBlock::ClearCountDownTimeFormats()
{
	GetOrCreateCountDownController().ClearCountDownTimeFormats();
}

void UKGRichTextBlock::PlayCountDown(double FromSeconds, double ToSeconds)
{
	GetOrCreateCountDownController().PlayCountDown(FromSeconds, ToSeconds);
}

void UKGRichTextBlock::StopCountDown()
{
	GetOrCreateCountDownController().StopCountDown();
}

bool UKGRichTextBlock::IsCountDownPlaying() const
{
	return GetOrCreateCountDownController().IsCountDownPlaying();
}

void UKGRichTextBlock::BeginDestroy()
{
	ReleaseCountDown();
	Super::BeginDestroy();
}

void UKGRichTextBlock::HandleOnCountDownFinished()
{
	BP_OnCountDownFinished.Broadcast();
}

void UKGRichTextBlock::HandleOnCountDownTextChanged(FText&& InText)
{
	this->SetText(InText);
}

#pragma endregion


// BEGIN ADD BY lishihao07@kuaishou.com: GPUTurbo RichTextBlock
UKGGPUTurboRichTextBlock::UKGGPUTurboRichTextBlock(const FObjectInitializer& ObjectInitializer)
	: UKGRichTextBlock(ObjectInitializer)
	, GPUTransformPivot(0.5f,0.5f)
	, GPUColorAndOpacity(FLinearColor::White)
{
}

TSharedRef<SWidget> UKGGPUTurboRichTextBlock::RebuildWidget()
{
	return RebuildWidgetInternal<class SKGGPUTurboRichTextBlock>("SKGGPUTurboRichTextBlock");
}

void UKGGPUTurboRichTextBlock::SetGPUTransform(const FWidgetTransform& InTransform)
{
	GPUTransform = InTransform;
	if (MyRichTextBlock.IsValid())
	{
		auto SW = static_cast<SKGGPUTurboRichTextBlock*>(MyRichTextBlock.Get());
		SW->SetGPUTransform(GPUTransform.ToSlateRenderTransform());
	}
}

FWidgetTransform UKGGPUTurboRichTextBlock::GetGPUTransform() const 
{
	return GPUTransform;
}

void UKGGPUTurboRichTextBlock::SetGPUTransformPivot(const FVector2D& InPivot)
{
	GPUTransformPivot = InPivot;
	if (MyRichTextBlock.IsValid())
	{
		auto SW = static_cast<SKGGPUTurboRichTextBlock*>(MyRichTextBlock.Get());
		SW->SetGPUTransformPivot(FVector2f(GPUTransformPivot));
	}
}

FVector2D UKGGPUTurboRichTextBlock::GetGPUTransformPivot() const
{
	return GPUTransformPivot;
}

FLinearColor UKGGPUTurboRichTextBlock::GetGPUColorAndOpacity() const
{
	return GPUColorAndOpacity;
}

void UKGGPUTurboRichTextBlock::SetGPUColorAndOpacity(const FLinearColor& InColor)
{
	GPUColorAndOpacity = InColor;
	if (MyRichTextBlock.IsValid())
	{
		auto SW = static_cast<SKGGPUTurboRichTextBlock*>(MyRichTextBlock.Get());
		SW->SetGPUColorOpacity(GPUColorAndOpacity);
	}
}

void UKGGPUTurboRichTextBlock::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	
	if (MyRichTextBlock.IsValid())
	{
		auto SW = static_cast<SKGGPUTurboRichTextBlock*>(MyRichTextBlock.Get());
		SW->SetGPUTransform(GPUTransform.ToSlateRenderTransform());
		SW->SetGPUTransformPivot(FVector2f(GPUTransformPivot));
		SW->SetGPUColorOpacity(GPUColorAndOpacity);
	}
}
// END ADD BY lishihao07@kuaishou.com: GPUTurbo RichTextBlock
