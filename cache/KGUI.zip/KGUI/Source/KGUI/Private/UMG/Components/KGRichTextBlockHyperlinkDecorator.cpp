// Fill out your copyright notice in the Description page of Project Settings.
#include "UMG/Components/KGRichTextBlockHyperlinkDecorator.h"

#include "UMG/Components/KGRichTextBlock.h"
#include "Framework/Text/SlateHyperlinkRun.h"
#include "Misc/DefaultValueHelper.h"
#include "UObject/UObjectGlobals.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/Input/SRichTextHyperlink.h"
#include "Framework/Application/SlateApplication.h"
#include "UMG/Blueprint/KGColorData.h"
#include "Widgets/Text/STextBlock.h"
#include "UMG/Blueprint/UIFunctionLibrary.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Engine/GameInstance.h"

#include "PaperSpriteBlueprintLibrary.h"
#include "PaperSprite.h"
#include "Slate/Layout/SlateImageHyperLinkRun.h"
#include "Materials/Material.h"
#include "Slate/Layout/KGSlateHyperlinkRun.h"

#define LOCTEXT_NAMESPACE "KGUI"

class FKGHyperlinkData
{
public:
	FKGHyperlinkData(TWeakObjectPtr<UKGRichTextBlockHyperlinkDecorator> InDecorator, const FString& InUrl, const FTextRange& InModelRange)
		: Decorator(InDecorator)
		, Url(InUrl)
		, ModelRange(InModelRange)
	{
	}

	TWeakObjectPtr<UKGRichTextBlockHyperlinkDecorator> Decorator;
	FString Url;
	FTextRange ModelRange;

	void HandleOnClicked(const TMap<FString, FString>& MetaData) const
	{
		if (!Decorator.IsValid())
		{
			return;
		}
		Decorator->ClickFun(Url, ModelRange.BeginIndex, ModelRange.EndIndex, UWidgetLayoutLibrary::GetMousePositionOnViewport(Decorator->GetWorld()->GetGameInstance()));
	}
};

class FKGHyperlinkDecorator : public FRichTextDecorator
{
public:
	FKGHyperlinkDecorator(URichTextBlock* InOwner, UKGRichTextBlockHyperlinkDecorator* InDecorator)
		: FRichTextDecorator(InOwner)
		, Decorator(InDecorator)
		, WeakOwner(InOwner)
	{
	}

	virtual ~FKGHyperlinkDecorator() override {}

	virtual bool Supports(const FTextRunParseResults& RunParseResult, const FString& Text) const override;

	virtual TSharedRef<ISlateRun> Create(const TSharedRef<FTextLayout>& TextLayout,
		const FTextRunParseResults& RunParseResult, const FString& OriginalText,
		const TSharedRef<FString>& InOutModelText, const ISlateStyle* Style) override;

private:
	FHyperlinkStyle GenerateLinkStyle(const TMap<FString, FString>& MetaData) const
	{
		FHyperlinkStyle LinkStyle;
		bool bWarnIfMissing = true;

		bool bHasNamedTextStyle = false;
		if (const FString* StyleName = MetaData.Find(TEXT("stylename")))
		{
			if (auto NamedTextStyle = FindTextStyle(*StyleName, bWarnIfMissing))
			{
				LinkStyle.SetTextStyle(*NamedTextStyle);
				bHasNamedTextStyle = true;
			}
		}
		if (!bHasNamedTextStyle)
		{
			LinkStyle.SetTextStyle(Owner->GetCurrentDefaultTextStyle());
		}
		const FButtonStyle RichTextHyperlinkButton = FButtonStyle()
			.SetNormal(FSlateNoResource())
			.SetPressed(FSlateNoResource())
			.SetHovered(FSlateNoResource());
		LinkStyle.SetUnderlineStyle(RichTextHyperlinkButton);

		if (const FString* SizeString = MetaData.Find(TEXT("size")))
		{
			int32 Size;
			if (FDefaultValueHelper::ParseInt(*SizeString, Size))
			{
				LinkStyle.TextStyle.SetFontSize(Size);
			}
		}

		if (const FString* ColorString = MetaData.Find(TEXT("color")))
		{
			FLinearColor NewColor = UUIFunctionLibrary::SRGBColorFromHex(*ColorString);
			LinkStyle.TextStyle.SetColorAndOpacity(FSlateColor(NewColor));
		}
		else if (const FString* TableColorString = MetaData.Find(TEXT("tablecolor")))
		{
			FString ColorTableName;
			FString ColorName;
			if (TableColorString->Split("_", &ColorTableName, &ColorName))
			{
				FString ColorTableDir = Decorator->GetColorTableDir();
				FPaths::NormalizeDirectoryName(ColorTableDir);

				const FString DTPath = "DataTable'/Game/" + ColorTableDir + "/" + "DT_" + ColorTableName + ".DT_" + ColorTableName + "'";


				UDataTable* ColorTable = LoadObject<UDataTable>(nullptr, *DTPath);
				if (ColorTable)
				{
					FString ContextString;
					FKGColorData* ColorRow = ColorTable->FindRow<FKGColorData>(FName(*ColorName), ContextString, bWarnIfMissing);
					if (ColorRow)
					{
						LinkStyle.TextStyle.SetColorAndOpacity(FSlateColor(ColorRow->Value));
					}
				}
			}
		}
		return LinkStyle;
	}

	const FSlateBrush* MakeBrush(EC7BrushType Type, const FRunInfo& RunInfo, bool bWarn) const
	{
		FString MetaTag = Decorator->TypeTagMap[Type];
		if (RunInfo.MetaData.Contains(*MetaTag))
		{
			FString ResourcePath = RunInfo.MetaData[*MetaTag];
			switch (Type)
			{
			case EC7BrushType::Texture2D:
				return Decorator->GetSlateBrushGenerator().MakeBrush<UTexture2D>(ResourcePath, bWarn);
			case EC7BrushType::Sprite:
				return Decorator->GetSlateBrushGenerator().MakeBrush<UPaperSprite>(ResourcePath, bWarn);
			case EC7BrushType::Material:
				return Decorator->GetSlateBrushGenerator().MakeBrush<UMaterial>(ResourcePath, bWarn);
			}
		}

		return nullptr;
	}

protected:
	//virtual TSharedPtr<SWidget> CreateDecoratorWidget(const FTextRunInfo& RunInfo, const FTextBlockStyle& TextStyle) const override;

	const FTextBlockStyle* FindTextStyle(const FString& RowName, bool bWarnIfMissing) const;

private:
	TWeakObjectPtr<UKGRichTextBlockHyperlinkDecorator> Decorator;
	TWeakObjectPtr<URichTextBlock> WeakOwner;
};



const FTextBlockStyle* FKGHyperlinkDecorator::FindTextStyle(const FString& RowName, bool bWarnIfMissing) const
{
	if (auto RichTextBlock = Cast<UKGRichTextBlock>(Owner))
	{
		if (auto StyleInstance = RichTextBlock->GetStyleInstanceInternal())
		{
			if (StyleInstance->HasWidgetStyle<FTextBlockStyle>(FName(RowName)))
			{
				return &StyleInstance->GetWidgetStyle<FTextBlockStyle>(FName(RowName));
			}
		}
	}
	return nullptr;
}

bool FKGHyperlinkDecorator::Supports(const FTextRunParseResults& RunParseResult, const FString& Text) const
{
	if (!Decorator.IsValid())
		return false;
	return RunParseResult.Name == TEXT("HyperLink") || RunParseResult.Name == TEXT("Tips");
}

TSharedRef<ISlateRun> FKGHyperlinkDecorator::Create(const TSharedRef<FTextLayout>& TextLayout,
	const FTextRunParseResults& RunParseResult, const FString& OriginalText, const TSharedRef<FString>& InOutModelText,
	const ISlateStyle* Style)
{
	FTextRange ModelRange;
	ModelRange.BeginIndex = InOutModelText->Len();
	*InOutModelText += OriginalText.Mid(RunParseResult.ContentRange.BeginIndex, RunParseResult.ContentRange.EndIndex - RunParseResult.ContentRange.BeginIndex);
	ModelRange.EndIndex = InOutModelText->Len();

	FRunInfo RunInfo( RunParseResult.Name );
	for(const TPair<FString, FTextRange>& Pair : RunParseResult.MetaData)
	{
		RunInfo.MetaData.Add(Pair.Key, OriginalText.Mid( Pair.Value.BeginIndex, Pair.Value.EndIndex - Pair.Value.BeginIndex));
	}
	auto LinkStyle = GenerateLinkStyle(RunInfo.MetaData);

	const FSlateBrush* Brush = nullptr;
	const bool bWarnIfMissing = true;
	if (RunInfo.MetaData.Contains(TEXT("id")))
	{
		
		if (RunInfo.MetaData.Contains(TEXT("res")))
		{
			Brush = Decorator->GetSlateBrushGenerator().MakeBrush(*RunInfo.MetaData[TEXT("id")], RunInfo.MetaData[TEXT("res")], bWarnIfMissing);
		}
		else
		{
			Brush = Decorator->GetSlateBrushGenerator().MakeBrush(FName(*RunInfo.MetaData[TEXT("id")]), bWarnIfMissing);
		}
		if (!Brush)
		{
			Brush = MakeBrush(EC7BrushType::Texture2D, RunInfo, bWarnIfMissing);
		}

		if (!Brush)
		{
			Brush = MakeBrush(EC7BrushType::Sprite, RunInfo, bWarnIfMissing);
		}

		if (!Brush)
		{
			Brush = MakeBrush(EC7BrushType::Material, RunInfo, bWarnIfMissing);
		}
	}

	TSharedPtr<FKGHyperlinkData> HyperlinkData;
	if (const FString* Url = RunInfo.MetaData.Find(TEXT("u")))
	{
		HyperlinkData = MakeShared<FKGHyperlinkData>(Decorator, *Url, RunParseResult.OriginalRange);
	}
	else
	{
		HyperlinkData = MakeShared<FKGHyperlinkData>(Decorator, FString(""), RunParseResult.OriginalRange);
	}
	HyperlinkData->ModelRange = ModelRange;

	TDelegate<void(const TMap<FString, FString>&)> OnClicked;
	OnClicked.BindLambda([HyperlinkData](const FSlateImageHyperLinkRun::FMetadata& MetaData)
	{
		HyperlinkData->HandleOnClicked(MetaData);
	});

	if (RunInfo.Name == "Tips")
	{
		return FSlateImageHyperLinkRun::Create(RunInfo, InOutModelText, LinkStyle, OnClicked, nullptr, nullptr, ModelRange, Brush, EVerticalAlignment::VAlign_Bottom, WeakOwner.Get(), true);
	}
	else
	{
		return FKGSlateHyperlinkRun::Create(RunInfo, InOutModelText, LinkStyle, OnClicked, nullptr, nullptr, WeakOwner.Get(), ModelRange);
	}
}


/////////////////////////////////////////////////////
// USTRichTextImageDecorator

UKGRichTextBlockHyperlinkDecorator::UKGRichTextBlockHyperlinkDecorator(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, TextSet(nullptr)
{
	TypeTagMap.Add(EC7BrushType::Texture2D, "tex2d");
	TypeTagMap.Add(EC7BrushType::Sprite, "sprite");
	TypeTagMap.Add(EC7BrushType::Material, "mat");
}

TSharedPtr<ITextDecorator> UKGRichTextBlockHyperlinkDecorator::CreateDecorator(URichTextBlock* InOwner)
{
	RichTextBlock = Cast<UKGRichTextBlock>(InOwner);
	return MakeShareable(new FKGHyperlinkDecorator(InOwner, this));
}

FString UKGRichTextBlockHyperlinkDecorator::GetColorTableDir()
{
	return ColorTableDir;
}

void UKGRichTextBlockHyperlinkDecorator::SetTextSet(UDataTable* InTextSet)
{
	TextSet = InTextSet;
}

void UKGRichTextBlockHyperlinkDecorator::SetColorDir(FString InColorTableDir)
{
	ColorTableDir = InColorTableDir;
}

void UKGRichTextBlockHyperlinkDecorator::ClickFun_Implementation(const FString& Url, const int32 BeginIndex, const int32 EndIndex, const FVector2D ClickPosition)
{
	if (RichTextBlock.Get())
	{
		(void) RichTextBlock->OnRichTextLinkEvent.ExecuteIfBound(Url, BeginIndex, EndIndex, ClickPosition);
		RichTextBlock->OnUrlActivated.Broadcast(Url, BeginIndex, EndIndex, ClickPosition);
	}
	(void) OnUrlClicked.ExecuteIfBound(Url, BeginIndex, EndIndex, ClickPosition);
}
/////////////////////////////////////////////////////

void UKGRichTextBlockHyperlinkDecorator::SetRichImageDataTables(const TArray<TObjectPtr<UDataTable>>& InRichImageDataTables)
{
	RichImageDataTables = InRichImageDataTables;
	SlateBrushGenerator.Initialize(RichImageDataTables);
}

void UKGRichTextBlockHyperlinkDecorator::ClearResourceReferences()
{
	SlateBrushGenerator.Empty();
}

#undef LOCTEXT_NAMESPACE
