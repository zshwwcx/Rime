// Fill out your copyright notice in the Description page of Project Settings.

#include "UMG/Components/KGWrapBox.h"

void UKGWrapBox::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	if (!MyWrapBox.IsValid())
	{
		return;
	}
	MyWrapBox->SetLineStacking(LineStacking);
	MyWrapBox->SetVerticalAlignment(VerticalAlignment);
}

TSharedRef<SWidget> UKGWrapBox::RebuildWidget()
{
	auto Widget = Super::RebuildWidget();
	if (MyWrapBox.IsValid())
	{
		MyWrapBox->SetVerticalAlignment(VerticalAlignment);
	}
	return Widget;
}

EVerticalAlignment UKGWrapBox::GetVerticalAlignment() const
{
	return VerticalAlignment;
}

void UKGWrapBox::SetVerticalAlignment(EVerticalAlignment InVerticalAlignment)
{
	VerticalAlignment = InVerticalAlignment;
	if (MyWrapBox)
	{
		MyWrapBox->SetHorizontalAlignment(InVerticalAlignment);
	}
}