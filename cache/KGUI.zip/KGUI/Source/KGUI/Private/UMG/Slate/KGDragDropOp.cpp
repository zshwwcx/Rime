// Copyright Epic Games, Inc. All Rights Reserved.

#include "UMG/Slate/KGDragDropOp.h"
#include "Application/SlateApplicationBase.h"
#include "Engine/GameViewportClient.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SWidget.h"
#include "Widgets/Text/STextBlock.h"
#include "Blueprint/DragDropOperation.h"
#include "Slate/SObjectWidget.h"

#include "Widgets/Layout/SDPIScaler.h"
#include <UMG/Components/KGHotArea.h>


//////////////////////////////////////////////////////////////////////////
// FKGDragDropOp

FKGDragDropOp::FKGDragDropOp()
	: DragOperation(nullptr)
	, GameViewport(nullptr)
{
	StartTime = FSlateApplicationBase::Get().GetCurrentTime();
}

void FKGDragDropOp::AddReferencedObjects(FReferenceCollector& Collector)
{
	Collector.AddReferencedObject(DragOperation);
}

FString FKGDragDropOp::GetReferencerName() const
{
	return TEXT("FKGDragDropOp");
}

void FKGDragDropOp::Construct()
{

}

bool FKGDragDropOp::AffectedByPointerEvent(const FPointerEvent& PointerEvent)
{
	return DragOperation.Get() && PointerEvent.GetPointerIndex() == PointerIndex;
}

void FKGDragDropOp::OnDrop( bool bDropWasHandled, const FPointerEvent& MouseEvent )
{
	if ( DragOperation.Get() )
	{
		if ( bDropWasHandled && MouseEvent.GetPointerIndex() == PointerIndex )
		{
			DragOperation->Drop(MouseEvent);
		}
		else
		{
			if (HotArea.Get()) 
			{
				HotArea->OnDragCancelled(FDragDropEvent(MouseEvent, AsShared()), DragOperation.Get());
			}
			DragOperation->DragCancelled(MouseEvent);
		}
	}
	
	FDragDropOperation::OnDrop(bDropWasHandled, MouseEvent);
}

void FKGDragDropOp::OnDragged( const class FDragDropEvent& DragDropEvent )
{
	if ( DragOperation.Get() && DragDropEvent.GetPointerIndex() == PointerIndex)
	{
		DragOperation->Dragged(DragDropEvent);

		FVector2D CachedDesiredSize = DecoratorWidget->GetDesiredSize();
	
		FVector2D Position = DragDropEvent.GetScreenSpacePosition();
		Position += CachedDesiredSize * DragOperation->Offset;
	
		switch ( DragOperation->Pivot )
		{
		case EDragPivot::MouseDown:
			Position += MouseDownOffset;
			break;
	
		case EDragPivot::TopLeft:
			// Position is already Top Left.
			break;
		case EDragPivot::TopCenter:
			Position -= CachedDesiredSize * FVector2D(0.5f, 0);
			break;
		case EDragPivot::TopRight:
			Position -= CachedDesiredSize * FVector2D(1, 0);
			break;
	
		case EDragPivot::CenterLeft:
			Position -= CachedDesiredSize * FVector2D(0, 0.5f);
			break;
		case EDragPivot::CenterCenter:
			Position -= CachedDesiredSize * FVector2D(0.5f, 0.5f);
			break;
		case EDragPivot::CenterRight:
			Position -= CachedDesiredSize * FVector2D(1.0f, 0.5f);
			break;
	
		case EDragPivot::BottomLeft:
			Position -= CachedDesiredSize * FVector2D(0, 1);
			break;
		case EDragPivot::BottomCenter:
			Position -= CachedDesiredSize * FVector2D(0.5f, 1);
			break;
		case EDragPivot::BottomRight:
			Position -= CachedDesiredSize * FVector2D(1, 1);
			break;
		}
	
		const double AnimationTime = 0.150;
	
		double DeltaTime = FSlateApplicationBase::Get().GetCurrentTime() - StartTime;
	
		if ( DeltaTime < AnimationTime )
		{
			double T = DeltaTime / AnimationTime;
			FVector2D LerpPosition = ( Position - StartingScreenPos ) * T;
			
			DecoratorPosition = StartingScreenPos + LerpPosition;
		}
		else
		{
			DecoratorPosition = Position;
		}
	}
}

TSharedPtr<SWidget> FKGDragDropOp::GetDefaultDecorator() const
{
	return DecoratorWidget;
}

FCursorReply FKGDragDropOp::OnCursorQuery()
{
	FCursorReply CursorReply = FGameDragDropOperation::OnCursorQuery();

	if ( !CursorReply.IsEventHandled() )
	{
		CursorReply = CursorReply.Cursor(EMouseCursor::Default);
	}

	if ( UGameViewportClient* GameViewportPtr = GameViewport.Get() )
	{
		TOptional<TSharedRef<SWidget>> CursorWidget = GameViewportPtr->MapCursor(nullptr, CursorReply);
		if ( CursorWidget.IsSet() )
		{
			CursorReply.SetCursorWidget(GameViewportPtr->GetWindow(), CursorWidget.GetValue());
		}
	}

	return CursorReply;
}

TSharedRef<FKGDragDropOp> FKGDragDropOp::New(UDragDropOperation* InOperation, const int32 PointerIndex, const FVector2D &PointerPosition, const FVector2D &ScreenPositionOfDragee, float DPIScale, UKGHotArea* HotArea)
{
	check(InOperation);

	TSharedRef<FKGDragDropOp> Operation = MakeShareable(new FKGDragDropOp());
	Operation->PointerIndex = PointerIndex;
	Operation->MouseDownOffset = ScreenPositionOfDragee - PointerPosition;
	Operation->StartingScreenPos = ScreenPositionOfDragee;
	Operation->GameViewport = HotArea->GetWorld()->GetGameViewport();;
	Operation->DragOperation = InOperation;
	Operation->HotArea = HotArea;
	TSharedPtr<SWidget> DragVisual;
	if ( InOperation->DefaultDragVisual == nullptr )
	{
		DragVisual = SNew(STextBlock)
			.Text(FText::FromString(InOperation->Tag));
	}
	else
	{
		//TODO Make sure users are not trying to add a widget that already exists elsewhere.
		DragVisual = InOperation->DefaultDragVisual->TakeWidget();
	}

	Operation->DecoratorWidget =
		SNew(SDPIScaler)
		.DPIScale(DPIScale)
		[
			DragVisual.ToSharedRef()
		];

	Operation->DecoratorWidget->SlatePrepass();

	Operation->Construct();

	return Operation;
}
