// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Slate/SKGSafeZoneConstraintCanvas.h"
#include "Widgets/SViewport.h"
#include "SlateOptMacros.h"
#include "SlateSettings.h"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION

float KGSafeZoneScale = 1.0f;
static FAutoConsoleVariableRef CVarKGSafeZoneScale(
	TEXT("KGSafeZone.Scale"),
	KGSafeZoneScale,
	TEXT("The KG SafeZone Scale."),
	ECVF_Default
);

bool bKGEnableSafeZoneScale = false;
static FAutoConsoleVariableRef CVarKGEnableSafeZoneScale(
	TEXT("KGSafeZone.EnableScale"),
	bKGEnableSafeZoneScale,
	TEXT("Is the KG Safe Zone scale enabled?"),
	ECVF_Default
);

SKGSafeZoneConstraintCanvas::SKGSafeZoneConstraintCanvas()
	: Padding(*this, 0.f)
{
	SetCanTick(false);
	bCanSupportFocus = false;
}

SKGSafeZoneConstraintCanvas::~SKGSafeZoneConstraintCanvas()
{
	FCoreDelegates::OnSafeFrameChangedEvent.Remove(OnSafeFrameChangedHandle);
}

void SKGSafeZoneConstraintCanvas::SetGlobalSafeZoneScale(TOptional<float> InScale)
{
	float NewScale = InScale.Get(1.f);
	if (NewScale < 0)
	{
		NewScale = 1.f;
	}
	bKGEnableSafeZoneScale = InScale.IsSet();
	KGSafeZoneScale = NewScale;

	FCoreDelegates::OnSafeFrameChangedEvent.Broadcast();
}

TOptional<float> SKGSafeZoneConstraintCanvas::GetGlobalSafeZoneScale()
{
	if (bKGEnableSafeZoneScale)
	{
		return KGSafeZoneScale;
	}
	return TOptional<float>();
}


void SKGSafeZoneConstraintCanvas::Construct(const FArguments& InArgs)
{
	/*
	ChildSlot
	[
		// Populate the widget
	];
	*/
	// bEnableSafeZone = InArgs._bEnableSafeZone;
	Padding.Assign(*this, InArgs._Padding);
	SafeAreaScale = InArgs._SafeAreaScale;
	bIsTitleSafe = InArgs._IsTitleSafe;
	bPadLeft = InArgs._PadLeft;
	bPadRight = InArgs._PadRight;
	bPadTop = InArgs._PadTop;
	bPadBottom = InArgs._PadBottom;
	bSafeMarginNeedsUpdate = true;

#if WITH_EDITOR
	OverrideScreenSize = InArgs._OverrideScreenSize;
	OverrideDpiScale = InArgs._OverrideDpiScale;
	FSlateApplication::Get().OnDebugSafeZoneChanged.AddSP(this, &SKGSafeZoneConstraintCanvas::DebugSafeAreaUpdated);
#endif

	SetTitleSafe(bIsTitleSafe);

	OnSafeFrameChangedHandle = FCoreDelegates::OnSafeFrameChangedEvent.AddSP(this, &SKGSafeZoneConstraintCanvas::UpdateSafeMargin);


	SConstraintCanvas::Construct(SConstraintCanvas::FArguments());
}

void SKGSafeZoneConstraintCanvas::SetTitleSafe( bool InIsTitleSafe )
{
	UpdateSafeMargin();
}

void SKGSafeZoneConstraintCanvas::UpdateSafeMargin()
{
	bSafeMarginNeedsUpdate = true;

#if WITH_EDITOR
	if (OverrideScreenSize.IsSet() && !OverrideScreenSize.GetValue().IsZero())
	{
		FSlateApplication::Get().GetSafeZoneSize(SafeMargin, OverrideScreenSize.GetValue());
	}
	else
	{
		// Need to get owning viewport not display 
		// use pixel values (same as custom safe zone above)
		TSharedPtr<SViewport> GameViewport = FSlateApplication::Get().GetGameViewport();
		if (GameViewport.IsValid())
		{
			TSharedPtr<ISlateViewport> ViewportInterface = GameViewport->GetViewportInterface().Pin();
			if (ViewportInterface.IsValid())
			{
				const FIntPoint ViewportSize = ViewportInterface->GetSize();
				FSlateApplication::Get().GetSafeZoneSize(SafeMargin, ViewportSize);
			}
			else
			{
				return;
			}
		}
		else
		{
			return;
		}
	}
#else
	// The second parameter of GetSafeZoneSize is only used #if WITH_EDITOR
	FSlateApplication::Get().GetSafeZoneSize(SafeMargin, FDeprecateSlateVector2D());
#endif

	TOptional<float> SafeZoneScale = GetGlobalSafeZoneScale();
	if (SafeZoneScale.IsSet())
	{
		SafeMargin = SafeMargin * KGSafeZoneScale;
	}

	SafeMargin = FMargin(bPadLeft ? SafeMargin.Left : 0.0f, bPadTop ? SafeMargin.Top : 0.0f, bPadRight ? SafeMargin.Right : 0.0f, bPadBottom ? SafeMargin.Bottom : 0.0f);

	Invalidate(EInvalidateWidgetReason::Layout);
	bSafeMarginNeedsUpdate = false;
}

void SKGSafeZoneConstraintCanvas::SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom)
{
	bPadLeft = InPadLeft;
	bPadRight = InPadRight;
	bPadTop = InPadTop;
	bPadBottom = InPadBottom;

	SetTitleSafe(bIsTitleSafe);
}

#if WITH_EDITOR
void SKGSafeZoneConstraintCanvas::SetOverrideScreenInformation(TOptional<FVector2D> InScreenSize, TOptional<float> InOverrideDpiScale)
{
	OverrideScreenSize = InScreenSize;
	OverrideDpiScale = InOverrideDpiScale;
	SetTitleSafe(bIsTitleSafe);
}

void SKGSafeZoneConstraintCanvas::DebugSafeAreaUpdated(const FMargin& NewSafeZone, bool bShouldRecacheMetrics)
{
	UpdateSafeMargin();
}
#endif

FMargin SKGSafeZoneConstraintCanvas::GetSafeMargin(float InLayoutScale) const
{
	if (bSafeMarginNeedsUpdate)
	{
		const_cast<SKGSafeZoneConstraintCanvas*>(this)->UpdateSafeMargin();
	}

	const FMargin SlotPadding = Padding.Get() + (ComputeScaledSafeMargin(InLayoutScale) * SafeAreaScale);
	return SlotPadding;
}

void SKGSafeZoneConstraintCanvas::SetSafeAreaScale(FMargin InSafeAreaScale)
{
	SafeAreaScale = InSafeAreaScale;
}

FMargin SKGSafeZoneConstraintCanvas::ComputeScaledSafeMargin(float Scale) const
{
#if WITH_EDITOR
	const float InvScale = OverrideDpiScale.IsSet() ? 1.0f / OverrideDpiScale.GetValue() : 1.0f / Scale;
#else
	const float InvScale = 1.0f / Scale;
#endif

	const FMargin ScaledSafeMargin(
		FMath::RoundToFloat(SafeMargin.Left * InvScale),
		FMath::RoundToFloat(SafeMargin.Top * InvScale),
		FMath::RoundToFloat(SafeMargin.Right * InvScale),
		FMath::RoundToFloat(SafeMargin.Bottom * InvScale));
	return ScaledSafeMargin;
}

void SKGSafeZoneConstraintCanvas::OnArrangeChildren( const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren ) const
{
	FArrangedChildLayers ChildLayers;
	ArrangeLayeredChildren(AllottedGeometry, ArrangedChildren, ChildLayers);
}

void SKGSafeZoneConstraintCanvas::ArrangeLayeredChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren, FArrangedChildLayers& ArrangedChildLayers) const
{
	if (Children.Num() > 0)
	{
		// Using a Project setting here to decide whether we automatically put children in front of all previous children
		// or allow the explicit ZOrder value to place children in the same layer. This will allow users to have non-touching
		// children render into the same layer and have a chance of being batched by the Slate renderer for better performance.
#if WITH_EDITOR
		const bool bExplicitChildZOrder = GetDefault<USlateSettings>()->bExplicitCanvasChildZOrder;
#else
		const static bool bExplicitChildZOrder = GetDefault<USlateSettings>()->bExplicitCanvasChildZOrder;
#endif

		float LastZOrder = -FLT_MAX;

		const FMargin SlotPadding = GetSafeMargin(AllottedGeometry.Scale);

		// Arrange the children now in their proper z-order.
		for (int32 ChildIndex = 0; ChildIndex < Children.Num(); ++ChildIndex)
		{
			const SConstraintCanvas::FSlot& CurChild = Children[ChildIndex];
			const TSharedRef<SWidget>& CurWidget = CurChild.GetWidget();

			const EVisibility ChildVisibility = CurWidget->GetVisibility();
			if (ArrangedChildren.Accepts(ChildVisibility))
			{
				const FMargin Offset = CurChild.GetOffset() + SlotPadding;
				const FVector2D Alignment = CurChild.GetAlignment();
				const FAnchors Anchors = CurChild.GetAnchors();

				const bool AutoSize = CurChild.GetAutoSize();

				const FMargin AnchorPixels =
					FMargin(Anchors.Minimum.X * AllottedGeometry.GetLocalSize().X,
					Anchors.Minimum.Y * AllottedGeometry.GetLocalSize().Y,
					Anchors.Maximum.X * AllottedGeometry.GetLocalSize().X,
					Anchors.Maximum.Y * AllottedGeometry.GetLocalSize().Y);

				const bool bIsHorizontalStretch = Anchors.Minimum.X != Anchors.Maximum.X;
				const bool bIsVerticalStretch = Anchors.Minimum.Y != Anchors.Maximum.Y;

				const FVector2D SlotSize = FVector2D(Offset.Right, Offset.Bottom);

				const FVector2D Size = AutoSize ? CurWidget->GetDesiredSize() : SlotSize;

				// Calculate the offset based on the pivot position.
				FVector2D AlignmentOffset = Size * Alignment;

				// Calculate the local position based on the anchor and position offset.
				FVector2D LocalPosition, LocalSize;

				// Calculate the position and size based on the horizontal stretch or non-stretch
				if (bIsHorizontalStretch)
				{
					LocalPosition.X = AnchorPixels.Left + Offset.Left;
					LocalSize.X = AnchorPixels.Right - LocalPosition.X - Offset.Right;
				}
				else
				{
					LocalPosition.X = AnchorPixels.Left + Offset.Left - AlignmentOffset.X;
					LocalSize.X = Size.X;
				}

				// Calculate the position and size based on the vertical stretch or non-stretch
				if (bIsVerticalStretch)
				{
					LocalPosition.Y = AnchorPixels.Top + Offset.Top;
					LocalSize.Y = AnchorPixels.Bottom - LocalPosition.Y - Offset.Bottom;
				}
				else
				{
					LocalPosition.Y = AnchorPixels.Top + Offset.Top - AlignmentOffset.Y;
					LocalSize.Y = Size.Y;
				}

				// Add the information about this child to the output list (ArrangedChildren)
				ArrangedChildren.AddWidget(ChildVisibility, AllottedGeometry.MakeChild(
					// The child widget being arranged
					CurWidget,
					// Child's local position (i.e. position within parent)
					LocalPosition,
					// Child's size
					LocalSize
				));

				bool bNewLayer = true; 
				// BEGIN CHANGE BY chengkai03@kuaishou.com:  Canvas Local ExplicitCanvasChildZOrder
				if (bExplicitChildZOrder || bLocalExplicitCanvasChildZOrder)
				{
					// END CHANGE BY chengkai03@kuaishou.com
					// Split children into discrete layers for the paint method
					bNewLayer = false;
					if (CurChild.GetZOrder() > LastZOrder + DELTA)
					{
						if (ArrangedChildLayers.Num() > 0)
						{
							bNewLayer = true;
						}
						LastZOrder = CurChild.GetZOrder();
					}

				}
				ArrangedChildLayers.Add(bNewLayer);
			}
		}
	}
}

FVector2D SKGSafeZoneConstraintCanvas::ComputeDesiredSize(float LayoutScale) const
{
	FVector2D FinalDesiredSize(0,0);

	// Arrange the children now in their proper z-order.
	for ( int32 ChildIndex = 0; ChildIndex < Children.Num(); ++ChildIndex )
	{
		const SConstraintCanvas::FSlot& CurChild = Children[ChildIndex];
		const TSharedRef<SWidget>& Widget = CurChild.GetWidget();
		const EVisibility ChildVisibilty = Widget->GetVisibility();

		// As long as the widgets are not collapsed, they should contribute to the desired size.
		if ( ChildVisibilty != EVisibility::Collapsed )
		{
			const FMargin Offset = CurChild.GetOffset();
			const FVector2D Alignment = CurChild.GetAlignment();
			const FAnchors Anchors = CurChild.GetAnchors();

			const FVector2D SlotSize = FVector2D(Offset.Right, Offset.Bottom);

			const bool AutoSize = CurChild.GetAutoSize();

			const FVector2D Size = AutoSize ? Widget->GetDesiredSize() : SlotSize;

			const bool bIsDockedHorizontally = ( Anchors.Minimum.X == Anchors.Maximum.X ) && ( Anchors.Minimum.X == 0 || Anchors.Minimum.X == 1 );
			const bool bIsDockedVertically = ( Anchors.Minimum.Y == Anchors.Maximum.Y ) && ( Anchors.Minimum.Y == 0 || Anchors.Minimum.Y == 1 );

			FinalDesiredSize.X = FMath::Max(FinalDesiredSize.X, Size.X + ( bIsDockedHorizontally ? FMath::Abs(Offset.Left) : 0.0f ));
			FinalDesiredSize.Y = FMath::Max(FinalDesiredSize.Y, Size.Y + ( bIsDockedVertically ? FMath::Abs(Offset.Top) : 0.0f ));
		}
	}

	const FMargin SlotPadding = GetSafeMargin(LayoutScale);
	
	return FinalDesiredSize + SlotPadding.GetDesiredSize();
}




END_SLATE_FUNCTION_BUILD_OPTIMIZATION
