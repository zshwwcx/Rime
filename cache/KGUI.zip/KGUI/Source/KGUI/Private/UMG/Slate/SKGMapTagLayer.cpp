// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Slate/SKGMapTagLayer.h"
#include "Types/PaintArgs.h"
#include "Layout/ArrangedChildren.h"
#include "SlateSettings.h"
#include "Framework/Application/SlateApplication.h"
#include "Rendering/SlateRenderer.h"

#pragma optimize("", off)
PRAGMA_DISABLE_DEPRECATION_WARNINGS


UE_TRACE_EVENT_BEGIN(Cpu, SKGMapTagLayer_ComputeChildDesireSize, NoSync)UE_TRACE_EVENT_FIELD(UE::Trace::WideString, WidgetPath)UE_TRACE_EVENT_END()

UE_TRACE_EVENT_BEGIN(Cpu, SKGMapTagLayer_PaintChild, NoSync)UE_TRACE_EVENT_FIELD(UE::Trace::WideString, WidgetPath)UE_TRACE_EVENT_FIELD(int32, LayerId)UE_TRACE_EVENT_END()


void SKGMapTagLayer::FSlot::Construct(const FChildren& SlotOwner, FSlotArguments&& InArgs)
{
    TSlotBase<FSlot>::Construct(SlotOwner, MoveTemp(InArgs));
    if (InArgs._Offset.IsSet())
    {
        OffsetAttr = MoveTemp(InArgs._Offset);
    }
    if (InArgs._Anchors.IsSet())
    {
        AnchorsAttr = MoveTemp(InArgs._Anchors);
    }
    if (InArgs._Alignment.IsSet())
    {
        AlignmentAttr = MoveTemp(InArgs._Alignment);
    }
    if (InArgs._AutoSize.IsSet())
    {
        AutoSizeAttr = MoveTemp(InArgs._AutoSize);
    }
    ZOrder = InArgs._ZOrder.Get(ZOrder);
}

void SKGMapTagLayer::FSlot::SetZOrder(float InZOrder)
{
    if (SWidget* OwnerWidget = FSlotBase::GetOwnerWidget())
    {
        if (ZOrder != InZOrder)
        {
            static_cast<SKGMapTagLayer*>(OwnerWidget)->DirtyZOrder();
            ZOrder = InZOrder;
        }
    }
    else
    {
        ZOrder = InZOrder;
        ensureMsgf(false, TEXT("The order of the Slot could not be set because it's not added to an existing Widget."));
    }
}

PRAGMA_ENABLE_DEPRECATION_WARNINGS

/* **************************************************************************** */
/* SKGMapTagLayer interface                                                     */
/* **************************************************************************** */

SKGMapTagLayer::SKGMapTagLayer()
    : Children(this)
{
    SetCanTick(false);
    bCanSupportFocus = false;
    bLocalExplicitCanvasChildZOrder = false;
}

SKGMapTagLayer::~SKGMapTagLayer() = default;

void SKGMapTagLayer::Construct(const SKGMapTagLayer::FArguments& InArgs)
{
    bLocalExplicitCanvasChildZOrder = InArgs._bLocalExplicitCanvasChildZOrder.Get(false);


    // Sort the children based on ZOrder.
    TArray<FSlot::FSlotArguments>& Slots = const_cast<TArray<FSlot::FSlotArguments>&>(InArgs._Slots);
    auto SortOperator = [](const FSlot::FSlotArguments& A, const FSlot::FSlotArguments& B)
    {
        int32 AZOrder = A._ZOrder.Get(0);
        int32 BZOrder = B._ZOrder.Get(0);
        return AZOrder == BZOrder ? reinterpret_cast<UPTRINT>(&A) < reinterpret_cast<UPTRINT>(&B) : AZOrder < BZOrder;
    };
    Slots.StableSort(SortOperator);

    Children.AddSlots(MoveTemp(Slots));
    DirtyZOrder();
}

SKGMapTagLayer::FSlot::FSlotArguments SKGMapTagLayer::Slot()
{
    return FSlot::FSlotArguments(MakeUnique<FSlot>());
}

SKGMapTagLayer::FScopedWidgetSlotArguments SKGMapTagLayer::AddSlot()
{
    TWeakPtr<SKGMapTagLayer> WeakWidget = SharedThis(this);
    return FScopedWidgetSlotArguments{
        MakeUnique<FSlot>(), this->Children, INDEX_NONE, [WeakWidget](const FSlot* InNewSlot, int32 InsertedLocation)
        {
            if (TSharedPtr<SKGMapTagLayer> Pinned = WeakWidget.Pin())
            {
                int32 NewSlotZOrder = InNewSlot->GetZOrder();
                TPanelChildren<FSlot>& OwnerChildren = Pinned->Children;
                int32 ChildIndexDestination = 0;
                {
                    const int32 ChildrenNum = OwnerChildren.Num();
                    for (; ChildIndexDestination < ChildrenNum; ++ChildIndexDestination)
                    {
                        const FSlot& CurSlot = OwnerChildren[ChildIndexDestination];
                        if (NewSlotZOrder < CurSlot.GetZOrder() && &CurSlot != InNewSlot)
                        {
                            // Insert before
                            break;
                        }
                    }
                    if (ChildIndexDestination >= ChildrenNum)
                    {
                        const FSlot& CurSlot = OwnerChildren[ChildrenNum - 1];
                        if (&CurSlot == InNewSlot)
                        {
                            // No need to move, it's already at the end.
                            ChildIndexDestination = INDEX_NONE;
                        }
                    }
                }

                // Move the slot to the correct location
                if (ChildIndexDestination != INDEX_NONE && InsertedLocation != ChildIndexDestination)
                {
                    // TPanelChildren::Move does a remove before the insert, that may change the index location
                    if (ChildIndexDestination > InsertedLocation)
                    {
                        --ChildIndexDestination;
                        ensure(false); // we inserted at the end, that should not occurs.
                    }
                    OwnerChildren.Move(InsertedLocation, ChildIndexDestination);
                }
                Pinned->DirtyZOrder();
            }
        }
    };
}

void SKGMapTagLayer::ClearChildren()
{
    Children.Empty();
}

void SKGMapTagLayer::SetLocalExplicitCanvasChildZOrder(bool InLocalExplicitCanvasChildZOrder)
{
    bLocalExplicitCanvasChildZOrder = InLocalExplicitCanvasChildZOrder;
    Invalidate(EInvalidateWidgetReason::Paint);
}

void SKGMapTagLayer::AddTagIcon(const FKGMapSimpleTagIcon& InTagIcon)
{
    SCOPED_NAMED_EVENT(SKGMapTagLayer_AddTagIcon, FColor::Green);
    if (auto* TagIconOwned = TagIcons.Find(InTagIcon.SimpleTagIconHandle))
    {
        *TagIconOwned = InTagIcon;
    }
    else
    {
        auto& TagIcon = TagIcons.Add(InTagIcon.SimpleTagIconHandle);
        TagIcon = InTagIcon;
        TagIconOrder.Add(InTagIcon.SimpleTagIconHandle);
    }
    
    bNeedRepaint = true;
    // Invalidate(EInvalidateWidgetReason::Paint);
}

void SKGMapTagLayer::RemoveTagIcon(int32 InTagIconHandle)
{
    SCOPED_NAMED_EVENT(SKGMapTagLayer_RemoveTagIcon, FColor::Yellow);
    if (TagIcons.Contains(InTagIconHandle))
    {
        TagIconOrder.Remove(InTagIconHandle);
        TagIcons.Remove(InTagIconHandle);

        bNeedRepaint = true;
        // Invalidate(EInvalidateWidgetReason::Paint);
    }
}

void SKGMapTagLayer::ClearTagIcons()
{
    TagIcons.Empty(TagIcons.Num());
    Invalidate(EInvalidateWidgetReason::Paint);
}

void SKGMapTagLayer::MarkTagIconsDirty()
{
    if (bNeedRepaint || HasAnyUpdateFlags(EWidgetUpdateFlags::NeedsRepaint|EWidgetUpdateFlags::NeedsVolatilePaint))
    {
        SCOPED_NAMED_EVENT(SKGMapTagLayer_MarkTagIconsDirty, FColor::Cyan);
        TagIconOrder.Sort([this](int32 iconHandleA, int32 iconHandleB)
        {
            auto* iconA = this->TagIcons.Find(iconHandleA);
            auto* iconB = this->TagIcons.Find(iconHandleB);
            if (iconA && iconB)
            {
                if (iconA->ZOrder != iconB->ZOrder)
                {
                    return iconA->ZOrder < iconB->ZOrder;
                }
                
                return iconHandleA < iconHandleB;
            }
            
            if (iconA)
            {
                return false;
            }
            
            if (iconB)
            {
                return true;
            }
            
            return iconHandleA < iconHandleB;
        });

        Invalidate(EInvalidateWidgetReason::Paint);
        bNeedRepaint = false;
    }    
}

int32 SKGMapTagLayer::RemoveSlot(const TSharedRef<SWidget>& SlotWidget)
{
    Invalidate(EInvalidateWidget::Layout);

    for (int32 SlotIdx = 0; SlotIdx < Children.Num(); ++SlotIdx)
    {
        if (SlotWidget == Children[SlotIdx].GetWidget())
        {
            Children.RemoveAt(SlotIdx);
            return SlotIdx;
        }
    }

    DirtyZOrder();

    return -1;
}

void SKGMapTagLayer::OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const
{
    FArrangedChildLayers ChildLayers;
    ArrangeLayeredChildren(AllottedGeometry, ArrangedChildren, ChildLayers);
}

struct FSortSlotsByZOrder
{
    FORCEINLINE bool operator()(const SKGMapTagLayer::FChildZOrder& A, const SKGMapTagLayer::FChildZOrder& B) const
    {
        return A.ZOrder == B.ZOrder ? A.ChildIndex < B.ChildIndex : A.ZOrder < B.ZOrder;
    }
};

void SKGMapTagLayer::ArrangeLayeredChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren, FArrangedChildLayers& ArrangedChildLayers) const
{
    if (Children.Num() > 0)
    {
        SCOPED_NAMED_EVENT(ArrangeLayeredChildren, FColor::Cyan);
        // Using a Project setting here to decide whether we automatically put children in front of all previous children
        // or allow the explicit ZOrder value to place children in the same layer. This will allow users to have non-touching
        // children render into the same layer and have a chance of being batched by the Slate renderer for better performance.
#if WITH_EDITOR
        const bool bExplicitChildZOrder = GetDefault<USlateSettings>()->bExplicitCanvasChildZOrder;
#else
        const static bool bExplicitChildZOrder = GetDefault<USlateSettings>()->bExplicitCanvasChildZOrder;
#endif

        if (bZOrderDirty || SlotOrder.Num() != Children.Num())
        {
            SCOPED_NAMED_EVENT(SortZOrder, FColor::Emerald);

            SKGMapTagLayer* MutableThis = const_cast<SKGMapTagLayer*>(this);
            MutableThis->SlotOrder.Empty(Children.Num());

            for (int32 ChildIndex = 0; ChildIndex < Children.Num(); ++ChildIndex)
            {
                const FSlot& CurChild = Children[ChildIndex];

                FChildZOrder Order;
                Order.ChildIndex = ChildIndex;
                Order.ZOrder = CurChild.GetZOrder();
                MutableThis->SlotOrder.Add(Order);
            }

            MutableThis->SlotOrder.Sort(FSortSlotsByZOrder());
        }

        float LastZOrder = -FLT_MAX;

        // Arrange the children now in their proper z-order.
        for (int32 ChildIndex = 0; ChildIndex < Children.Num(); ++ChildIndex)
        {
            const FChildZOrder& CurSlot = SlotOrder[ChildIndex];
            const FSlot& CurChild = Children[CurSlot.ChildIndex];
            const TSharedRef<SWidget>& CurWidget = CurChild.GetWidget();

            const EVisibility ChildVisibility = CurWidget->GetVisibility();
            if (ArrangedChildren.Accepts(ChildVisibility))
            {
                const FMargin Offset = CurChild.GetOffset();
                const FVector2D Alignment = CurChild.GetAlignment();
                const FAnchors Anchors = CurChild.GetAnchors();

                const bool AutoSize = CurChild.GetAutoSize();

                const FMargin AnchorPixels = FMargin(Anchors.Minimum.X * AllottedGeometry.GetLocalSize().X, Anchors.Minimum.Y * AllottedGeometry.GetLocalSize().Y, Anchors.Maximum.X * AllottedGeometry.GetLocalSize().X, Anchors.Maximum.Y * AllottedGeometry.GetLocalSize().Y);

                const bool bIsHorizontalStretch = Anchors.Minimum.X != Anchors.Maximum.X;
                const bool bIsVerticalStretch = Anchors.Minimum.Y != Anchors.Maximum.Y;

                const FVector2D SlotSize = FVector2D(Offset.Right, Offset.Bottom);

                const FVector2D Size = AutoSize ? CurWidget->GetDesiredSize() : SlotSize;

                // Calculate the offset based on the pivot position.
                FVector2D AlignmentOffset = Size * Alignment;

                // Calculate the local position based on the anchor and position offset.
                FVector2D LocalPosition, LocalSize;

                // Calculate the position and size based on the horizontal stretch or non-stretch
                if (bIsHorizontalStretch)
                {
                    LocalPosition.X = AnchorPixels.Left + Offset.Left;
                    LocalSize.X = AnchorPixels.Right - LocalPosition.X - Offset.Right;
                }
                else
                {
                    LocalPosition.X = AnchorPixels.Left + Offset.Left - AlignmentOffset.X;
                    LocalSize.X = Size.X;
                }

                // Calculate the position and size based on the vertical stretch or non-stretch
                if (bIsVerticalStretch)
                {
                    LocalPosition.Y = AnchorPixels.Top + Offset.Top;
                    LocalSize.Y = AnchorPixels.Bottom - LocalPosition.Y - Offset.Bottom;
                }
                else
                {
                    LocalPosition.Y = AnchorPixels.Top + Offset.Top - AlignmentOffset.Y;
                    LocalSize.Y = Size.Y;
                }

                // Add the information about this child to the output list (ArrangedChildren)
                ArrangedChildren.AddWidget(ChildVisibility, AllottedGeometry.MakeChild(
                                               // The child widget being arranged
                                               CurWidget,
                                               // Child's local position (i.e. position within parent)
                                               LocalPosition,
                                               // Child's size
                                               LocalSize));

                bool bNewLayer = true;
                // BEGIN CHANGE BY chengkai03@kuaishou.com:  Canvas Local ExplicitCanvasChildZOrder
                if (bExplicitChildZOrder || bLocalExplicitCanvasChildZOrder)
                {
                    // END CHANGE BY chengkai03@kuaishou.com
                    // Split children into discrete layers for the paint method
                    bNewLayer = false;
                    if (CurSlot.ZOrder > LastZOrder + DELTA)
                    {
                        if (ArrangedChildLayers.Num() > 0)
                        {
                            bNewLayer = true;
                        }
                        LastZOrder = CurChild.GetZOrder();
                    }
                }
                ArrangedChildLayers.Add(bNewLayer);
            }
        }
    }
}

int32 SKGMapTagLayer::DrawTagIcons(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
    SCOPED_NAMED_EVENT(DrawTagIcons, FColor::Magenta);
    const ESlateDrawEffect DrawEffects = bParentEnabled ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect;

    for (auto IconHandle : TagIconOrder)
    {
        if (auto* Icon = TagIcons.Find(IconHandle))
        {
            const FSlateBrush& Brush = Icon->Brush;
            if (Brush.DrawAs != ESlateBrushDrawType::NoDrawType && Icon->bVisible)
            {
                FVector2D Size = { FMath::Abs(Icon->Size.X), FMath::Abs(Icon->Size.Y) };
                FVector2D Scale = FVector2D::One();
                Scale.X *= Icon->Size.X < 0 ? -1 : 1;
                Scale.Y *= Icon->Size.Y < 0 ? -1 : 1;
                FVector2D LocalOffset = AllottedGeometry.GetLocalSize() * Icon->Offset - Size * 0.5f;
                // FPaintGeometry PaintGeometry = AllottedGeometry.MakeChild(Size, FSlateLayoutTransform(1, LocalOffset)).ToPaintGeometry();
                // FSlateRenderTransform RenderTransform = PaintGeometry.GetAccumulatedRenderTransform();
                // FTransform2f TransScale = FTransform2f(Scale);
                // FTransform2f Rotate = FTransform2f(TQuat2(Icon->RotateAngle));
                // RenderTransform = TransScale.Concatenate(Rotate.Concatenate(RenderTransform));
                // PaintGeometry.SetRenderTransform(RenderTransform);
                // FSlateDrawElement::MakeBox(OutDrawElements, LayerId, PaintGeometry, &Brush, DrawEffects, InWidgetStyle.GetColorAndOpacityTint() * Icon->TintColor);
                FSlateRenderTransform RenderTransform(Scale);
                FSlateRenderTransform RenderTransformRot(TQuat2(Icon->RotateAngle));
                FSlateRenderTransform RenderTransformFinal = RenderTransform.Concatenate(RenderTransformRot);
                
                FGeometry ChildGeometry = AllottedGeometry.MakeChild(Size, FSlateLayoutTransform(1, LocalOffset), 
                RenderTransformFinal, UE::Slate::FDeprecateVector2DParameter::One() * 0.5f);
                FSlateDrawElement::MakeBox(OutDrawElements, LayerId, ChildGeometry.ToPaintGeometry(), &Brush, DrawEffects, 
                InWidgetStyle.GetColorAndOpacityTint() * Icon->TintColor);
            }
        }
    }

    return ++LayerId;
}

int32 SKGMapTagLayer::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
    SCOPED_NAMED_EVENT_TEXT("SKGMapTagLayer", FColor::Orange);

    FArrangedChildren ArrangedChildren(EVisibility::Visible);
    FArrangedChildLayers ChildLayers;
    ArrangeLayeredChildren(AllottedGeometry, ArrangedChildren, ChildLayers);

    const bool bForwardedEnabled = ShouldBeEnabled(bParentEnabled);

    // Because we paint multiple children, we must track the maximum layer id that they produced in case one of our parents
    // wants to an overlay for all of its contents.
    int32 MaxLayerId = LayerId;
    int32 ChildLayerId = LayerId;

    const FPaintArgs NewArgs = Args.WithNewParent(this);

    int32 LayerIdTagIcons = DrawTagIcons(NewArgs, AllottedGeometry, MyCullingRect, OutDrawElements, MaxLayerId, InWidgetStyle, bForwardedEnabled);
    MaxLayerId = FMath::Max(MaxLayerId, LayerIdTagIcons);


    for (int32 ChildIndex = 0; ChildIndex < ArrangedChildren.Num(); ++ChildIndex)
    {
        FArrangedWidget& CurWidget = ArrangedChildren[ChildIndex];

        if (!IsChildWidgetCulled(MyCullingRect, CurWidget))
        {
            // Bools in ChildLayers tell us whether to paint the next child in front of all previous
            if (ChildLayers[ChildIndex])
            {
                ChildLayerId = MaxLayerId + 1;
            }

            FString WidgetPath;
            if (auto ReflectionMetaData = CurWidget.Widget->GetMetaData<FReflectionMetaData>())
            {
                if (ReflectionMetaData->SourceObject.IsValid())
                {
                    WidgetPath = ReflectionMetaData->SourceObject->GetPathName();
                }
                else
                {
                    WidgetPath = ReflectionMetaData->GetWidgetDebugInfo(CurWidget.Widget.Get());
                }
            }

            UE_TRACE_LOG_SCOPED_T(Cpu, SKGMapTagLayer_PaintChild, CpuChannel) << SKGMapTagLayer_PaintChild.WidgetPath(*WidgetPath, WidgetPath.Len()) << SKGMapTagLayer_PaintChild.LayerId(ChildLayerId);

            const int32 CurWidgetsMaxLayerId = CurWidget.Widget->Paint(NewArgs, CurWidget.Geometry, MyCullingRect, OutDrawElements, ChildLayerId, InWidgetStyle, bForwardedEnabled);

            MaxLayerId = FMath::Max(MaxLayerId, CurWidgetsMaxLayerId);
        }
        else
        {
            //SlateGI - RemoveContent
        }
    }

    return MaxLayerId;
}

FVector2D SKGMapTagLayer::ComputeDesiredSize(float) const
{
    FVector2D FinalDesiredSize(0, 0);

    // Arrange the children now in their proper z-order.
    for (int32 ChildIndex = 0; ChildIndex < Children.Num(); ++ChildIndex)
    {
        const SKGMapTagLayer::FSlot& CurChild = Children[ChildIndex];
        const TSharedRef<SWidget>& Widget = CurChild.GetWidget();
        const EVisibility ChildVisibilty = Widget->GetVisibility();

        // As long as the widgets are not collapsed, they should contribute to the desired size.
        if (ChildVisibilty != EVisibility::Collapsed)
        {
            FString WidgetPath;
            if (auto ReflectionMetaData = GetMetaData<FReflectionMetaData>())
            {
                if (ReflectionMetaData->SourceObject.IsValid())
                {
                    WidgetPath = ReflectionMetaData->SourceObject->GetPathName();
                }
                else
                {
                    WidgetPath = ReflectionMetaData->GetWidgetDebugInfo(this);
                }
            }

            UE_TRACE_LOG_SCOPED_T(Cpu, SKGMapTagLayer_ComputeChildDesireSize, CpuChannel) << SKGMapTagLayer_ComputeChildDesireSize.WidgetPath(*WidgetPath, WidgetPath.Len());

            const FMargin Offset = CurChild.GetOffset();
            const FVector2D Alignment = CurChild.GetAlignment();
            const FAnchors Anchors = CurChild.GetAnchors();

            const FVector2D SlotSize = FVector2D(Offset.Right, Offset.Bottom);

            const bool AutoSize = CurChild.GetAutoSize();

            const FVector2D Size = AutoSize ? Widget->GetDesiredSize() : SlotSize;

            const bool bIsDockedHorizontally = (Anchors.Minimum.X == Anchors.Maximum.X) && (Anchors.Minimum.X == 0 || Anchors.Minimum.X == 1);
            const bool bIsDockedVertically = (Anchors.Minimum.Y == Anchors.Maximum.Y) && (Anchors.Minimum.Y == 0 || Anchors.Minimum.Y == 1);

            FinalDesiredSize.X = FMath::Max(FinalDesiredSize.X, Size.X + (bIsDockedHorizontally ? FMath::Abs(Offset.Left) : 0.0f));
            FinalDesiredSize.Y = FMath::Max(FinalDesiredSize.Y, Size.Y + (bIsDockedVertically ? FMath::Abs(Offset.Top) : 0.0f));
        }
    }

    return FinalDesiredSize;
}

FChildren* SKGMapTagLayer::GetChildren()
{
    return &Children;
}
#pragma optimize("", on)