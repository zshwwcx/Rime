#include "UMG/Slate/SKGObjectIrregularListEntry.h"

#include "UMG/Components/KGIrregularListView.h"
#include "UMG/Blueprint/IKGUserObjectIrregularListEntry.h"

TMap<TWeakObjectPtr<const UUserWidget>, TWeakPtr<const IKGObjectIrregularListEntry>> IKGObjectIrregularListEntry::ObjectEntriesByUserWidget;

void SKGObjectIrregularListEntry::Construct(const FArguments& InArgs, const TSharedRef<SKGIrregularListView<UObject*>>& InOwnerSlateListView, UUserWidget& InWidgetObject, UKGIrregularListView* InOwnerListView)
{
	OwnerListView = InOwnerListView;
	ObjectEntriesByUserWidget.Add(&InWidgetObject, SharedThis(this));

	TSharedPtr<SWidget> ContentWidget;
	ContentWidget = InArgs._Content.Widget;
	OwnerSlateListViewWeakPtr = InOwnerSlateListView;

	SObjectWidget::Construct(
		SObjectWidget::FArguments()
		.Content()
		[
			ContentWidget.ToSharedRef()
		], &InWidgetObject);
}

SKGObjectIrregularListEntry::~SKGObjectIrregularListEntry()
{
	ObjectEntriesByUserWidget.Remove(WidgetObject);
}

void SKGObjectIrregularListEntry::InitializeRow()
{
	if (const TObjectPtr<UObject>* ItemPtr = GetItemForThis(OwnerSlateListViewWeakPtr.Pin().ToSharedRef()))
	{
		IKGUserObjectIrregularListEntry::SetListItemObject(*WidgetObject, *ItemPtr);
	}
}

void SKGObjectIrregularListEntry::ResetRow()
{
	if (WidgetObject)
	{
		IKGUserIrregularListEntry::ReleaseEntry(*WidgetObject);
	}
}

void SKGObjectIrregularListEntry::SetIndexInList(int32 InIndexInList)
{
	IndexInList = InIndexInList;
}

int32 SKGObjectIrregularListEntry::GetIndexInList() const
{
	return IndexInList;
}

void SKGObjectIrregularListEntry::UpdateItemSelection(bool bIsSelected, ESelectInfo::Type SelectInfo)
{
	IKGUserIrregularListEntry::UpdateItemSelection(*WidgetObject, bIsSelected, SelectInfo);
}

bool SKGObjectIrregularListEntry::IsItemSelected() const
{
	TSharedRef<SKGIrregularListView<UObject*>> OwnerSlateListView = OwnerSlateListViewWeakPtr.Pin().ToSharedRef();
	if (const TObjectPtr<UObject>* ItemPtr = GetItemForThis(OwnerSlateListView))
	{
		return OwnerSlateListView->IsItemSelected(*ItemPtr);
	}
	return false;
}

TSharedRef<SWidget> SKGObjectIrregularListEntry::AsWidget()
{
	return SharedThis(this);
}

UKGIrregularListView* SKGObjectIrregularListEntry::GetOwningListView() const
{
	if (OwnerListView.IsValid())
	{
		return OwnerListView.Get();
	}
	return nullptr;
}

void SKGObjectIrregularListEntry::SetIrregularPosition(FVector2D InIrregularPosition)
{
	IrregularPosition = InIrregularPosition;
}

const TObjectPtr<UObject>* SKGObjectIrregularListEntry::GetItemForThis(const TSharedRef<SKGIrregularListView<UObject*>>& InOwnerListView) const
{
	const TObjectPtr<UObject>* MyItemPtr = InOwnerListView->ItemFromWidget(this);
	if (MyItemPtr)
	{
		return MyItemPtr;
	}
	else
	{
		checkf(InOwnerListView->IsPendingRefresh(), TEXT("We were unable to find the item for this widget. If it was removed from the source collection, the list should be pending a refresh. %s"), *FReflectionMetaData::GetWidgetPath(this, false, false));
	}

	return nullptr;
}

UUserWidget* SKGObjectIrregularListEntry::GetUserWidget() const
{
	return WidgetObject;
}