// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Skeletal/KGBoneWidget.h"
#include "UMG/Skeletal/KGUserWidgetSkeletalWidget.h"
#include "Blueprint/WidgetTree.h"


#if WITH_EDITOR
#include "WidgetBlueprint.h"
#endif

UKGBoneWidget::UKGBoneWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
#if WITH_EDITORONLY_DATA
	bLockedInDesigner = true;
	bCanRename = false;
#endif
}

void UKGBoneWidget::SynchronizeProperties()
{
	Super::SynchronizeProperties();
#if WITH_EDITOR
	if (IsDesignTime() && IsInSkeletal())
	{
		bCanRename = true;
	}
#endif
}

#if WITH_EDITOR

void UKGBoneWidget::SetCanRename(bool bNewCanRename)
{
	// Bone控件在骨架蓝图之外不允许修改
	if (IsDesignTime() && IsInSkeletal())
	{
		bCanRename = bNewCanRename;
	}
}

bool UKGBoneWidget::IsInSkeletal()
{
	UObject* Outer = GetOuter();
	if (Slot)
	{
		UPanelSlot* CurSlot = Slot;
		UPanelWidget* Panel = nullptr;
		while (CurSlot)
		{
			Panel = CurSlot->Parent;
			CurSlot = Panel ? CurSlot->Parent->Slot : nullptr;
		}

		if (CurSlot == nullptr && Panel)
		{
			Outer = Panel->GetOuter();
		}
	}

	if (UWidgetTree* WidgetTree = Cast<UWidgetTree>(Outer))
	{
		Outer = WidgetTree->GetOuter();
		if (Outer->IsA<UWidgetBlueprint>())
		{
			UWidgetBlueprint* BP = Cast<UWidgetBlueprint>(Outer);
			if (BP && BP->GeneratedClass)
			{
				UClass* CPPParentClass = nullptr;
				UClass* CurrentClass = BP->GeneratedClass;

				while (CurrentClass)
				{
					// 检查是否为原生C++类（非蓝图生成）
					if (!CurrentClass->ClassGeneratedBy)
					{
						CPPParentClass = CurrentClass;
						break;
					}

					CurrentClass = CurrentClass->GetSuperClass();
				}

				if (CPPParentClass && CPPParentClass->IsChildOf<UKGUserWidgetSkeletalWidget>())
				{
					return true;
				}
			}
		}
	}

	return false;
}
#endif
