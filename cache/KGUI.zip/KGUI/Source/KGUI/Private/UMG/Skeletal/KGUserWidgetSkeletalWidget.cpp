#include "UMG/Skeletal/KGUserWidgetSkeletalWidget.h"
#include "Blueprint/WidgetTree.h"


UKGUserWidgetSkeletalWidget::UKGUserWidgetSkeletalWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}


void UKGUserWidgetSkeletalWidget::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);
}

void UKGUserWidgetSkeletalWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
}

void UKGUserWidgetSkeletalWidget::OnWidgetRebuilt()
{
	Super::OnWidgetRebuilt();

	//WidgetTree->ForEachWidget([&](UWidget* Widget) {
	//	Widget->SetFlags(RF_Transient);
	//	});
}

