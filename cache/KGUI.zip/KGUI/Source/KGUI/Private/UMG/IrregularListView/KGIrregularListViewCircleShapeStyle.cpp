#include "UMG/IrregularListView/KGIrregularListViewCircleShapeStyle.h"

#include "Blueprint/UserWidget.h"
#include "Slate/Views/SKGIrregularListView.h"

FVector2D UKGIrregularListViewCircleShapeStyle::RaiseOnArrangeItem(const FGeometry& Geometry, UUserWidget* Widget, float Progress)
{
	auto ListView = GetIrregularListView();
	auto FinalVisualRadius = Radius + (ListView ? ListView->GetCustomScalarParameter1() : 0);
	float CurrentAngle = Direction - Angle * 0.5f + Angle * (Progress + (ListView ? ListView->GetCustomScalarParameter0() : 0));
	float Radians = FMath::DegreesToRadians(CurrentAngle);
	float X = FMath::Cos(Radians) * FinalVisualRadius;
	float Y = FMath::Sin(Radians) * FinalVisualRadius;
	Widget->SetRenderTransformAngle(!LocalRotationCompensationEnabled ? CurrentAngle + 90 : 0);
	auto LocalSize = this->GetIrregularListView()->GetCachedGeometry().GetLocalSize();
	return FVector2D(X, Y) + LocalSize * Offset + AbsoluteOffset;
}

float UKGIrregularListViewCircleShapeStyle::RaiseOnDragged(const FGeometry& Geometry, const FPointerEvent& TouchEvent)
{
	auto RelativePosition = GetTouchRelativePosition(Geometry, TouchEvent);
	auto CursorDelta =
		Geometry.AbsoluteToLocal(TouchEvent.GetCursorDelta()) -
		Geometry.AbsoluteToLocal(FVector2D(0, 0));
	float Delta = FVector2D::DotProduct(CursorDelta, FVector2D(-RelativePosition.Y, RelativePosition.X).GetSafeNormal());
	return FMath::Atan2(Delta * 0.5f, RelativePosition.Length()) * 2 / (UE_PI * 2) * Speed;
}

bool UKGIrregularListViewCircleShapeStyle::RaiseOnDragStarting(const FGeometry& Geometry, const FPointerEvent& TouchEvent)
{
	auto RelativePosition = GetTouchRelativePosition(Geometry, TouchEvent);
	if (Radius == 0)
	{
		return false;
	}
	auto RelativeRadius = RelativePosition.Length() / Radius;
	if (bInteractableAreaEnabled && (RelativeRadius < InteractableInnerRadius || RelativeRadius > InteractableOuterRadius))
	{
		return false;
	}
	return true;
}

FVector2D UKGIrregularListViewCircleShapeStyle::GetTouchRelativePosition(const FGeometry& Geometry, const FPointerEvent& TouchEvent) const
{
	auto TouchPosition = Geometry.AbsoluteToLocal(TouchEvent.GetScreenSpacePosition());
	FVector2D Center; FVector2D _;
	auto IrregularListView = StaticCastSharedPtr<SKGIrregularListView<UObject*>>(this->GetIrregularListView()->GetCachedWidget());
	IrregularListView->IrregularToLocal(
		Geometry,
		FVector2D::ZeroVector, FVector2D::ZeroVector,
		Center, _
	);
	auto LocalSize = Geometry.GetLocalSize();
	Center += LocalSize * Offset + AbsoluteOffset;
	return TouchPosition - Center;
}
