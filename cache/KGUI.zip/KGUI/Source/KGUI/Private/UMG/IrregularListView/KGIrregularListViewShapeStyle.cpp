#include "UMG/IrregularListView/KGIrregularListViewShapeStyle.h"

FVector2D UKGIrregularListViewShapeStyle::RaiseOnArrangeItem(const FGeometry& Geometry, UUserWidget* Widget, float Progress)
{
	return OnArrangeItem(Geometry, Widget, Progress);
}

float UKGIrregularListViewShapeStyle::RaiseOnDragged(const FGeometry& Geometry, const FPointerEvent& TouchEvent)
{
	return OnDragged(Geometry, TouchEvent);
}

bool UKGIrregularListViewShapeStyle::RaiseOnDragStarting(const FGeometry& Geometry, const FPointerEvent& TouchEvent)
{
	return OnDragStarting(Geometry, TouchEvent);
}

UKGIrregularListView* UKGIrregularListViewShapeStyle::GetIrregularListView() const
{
	return dynamic_cast<UKGIrregularListView*>(GetWidget());
}

FVector2D UKGIrregularListViewShapeStyle::OnArrangeItem_Implementation(const FGeometry& Geometry, UUserWidget* Widget, float Progress)
{
	return FVector2D();
}

float UKGIrregularListViewShapeStyle::OnDragged_Implementation(const FGeometry& Geometry, const FPointerEvent& TouchEvent)
{
	return 0;
}

bool UKGIrregularListViewShapeStyle::OnDragStarting_Implementation(const FGeometry& Geometry, const FPointerEvent& TouchEvent)
{
	return true;
}