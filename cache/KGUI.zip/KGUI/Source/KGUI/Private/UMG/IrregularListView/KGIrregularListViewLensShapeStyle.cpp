#include "UMG/IrregularListView/KGIrregularListViewLensShapeStyle.h"

#include "Blueprint/UserWidget.h"
#include "Slate/Views/SKGIrregularListView.h"

FVector2D UKGIrregularListViewLensShapeStyle::RaiseOnArrangeItem(const FGeometry& Geometry, UUserWidget* Widget, float Progress)
{
	float Normalized = Progress - 0.5f;
	float Base = FMath::Abs(Normalized) > LensRadius
		? (Normalized > 0 ? 1 : -1)
		: (LensRadius == 0 ? 0 : (Normalized / LensRadius));
	auto ItemSize = Widget->GetCachedGeometry().GetLocalSize();
	auto Length = bUseAbsoluteLength ? AbsoluteLength : Geometry.GetLocalSize().X;
	float Offset =
		Normalized * Length;
	if (this->MagnificationPower != 1)
	{
		Offset += (this->MagnificationPower - 1.0f) * ItemSize.X * 0.5f * FMath::Pow(FMath::Abs(Base), this->ShiftDistortion) * FMath::Sign(Base);
		Widget->SetRenderScale(
			FVector2D(1, 1)
			*
			(
				1.0f + (this->MagnificationPower - 1.0f) * FMath::Cos(Base * PI * 0.5f)
			)
		);
	}
	else
	{
		Widget->SetRenderScale(FVector2D(1, 1));
	}
	auto LocalSize = this->GetIrregularListView()->GetCachedGeometry().GetLocalSize();
	return FVector2D(Offset, 0) + FVector2D(LocalSize.X * 0.5f, LocalSize.Y * 0.5f);
}

float UKGIrregularListViewLensShapeStyle::RaiseOnDragged(const FGeometry& Geometry, const FPointerEvent& TouchEvent)
{
	auto CursorDelta =
		Geometry.AbsoluteToLocal(TouchEvent.GetCursorDelta()) -
		Geometry.AbsoluteToLocal(FVector2D(0, 0));
	auto Length = bUseAbsoluteLength ? AbsoluteLength : Geometry.GetLocalSize().X;
	if (Length == 0)
	{
		return 0;
	}
	return DragSpeed * CursorDelta.X / Length;
}