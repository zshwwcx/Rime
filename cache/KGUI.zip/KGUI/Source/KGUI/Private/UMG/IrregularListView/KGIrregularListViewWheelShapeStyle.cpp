#include "UMG/IrregularListView/KGIrregularListViewWheelShapeStyle.h"

#include "Blueprint/UserWidget.h"
#include "Slate/Views/SKGIrregularListView.h"

FVector2D UKGIrregularListViewWheelShapeStyle::RaiseOnArrangeItem(const FGeometry& Geometry, UUserWidget* Widget, float Progress)
{
	constexpr float Angle = 360.0f;
	constexpr float Direction = 0;
	float CurrentAngle = Direction - Angle * 0.5f + Angle * Progress;
	float Radians = FMath::DegreesToRadians(CurrentAngle);
	float Cosine = FMath::Cos(Radians);
	float Scale = Cosine;
	float Y = FMath::Sin(Radians) * Radius;
	float Distance = 1 - Cosine;
	Widget->SetRenderScale(FVector2D(1.0f / (Distance * this->Perspective + 1), FMath::Max(Scale, 0)));
	Widget->SetColorAndOpacity(FLinearColor(1, 1, 1, FMath::Clamp(Cosine, 0, Padding) / Padding));
	return FVector2D(0, Y);
}

float UKGIrregularListViewWheelShapeStyle::RaiseOnDragged(const FGeometry& Geometry, const FPointerEvent& TouchEvent)
{
	auto CursorDelta =
		Geometry.AbsoluteToLocal(TouchEvent.GetCursorDelta()) -
		Geometry.AbsoluteToLocal(FVector2D(0, 0));
	return FMath::Atan2(CursorDelta.Y * 0.5, Radius) * 2 / (UE_PI * 2);
}
