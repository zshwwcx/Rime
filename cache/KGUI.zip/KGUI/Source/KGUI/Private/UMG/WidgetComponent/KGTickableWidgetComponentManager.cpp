﻿#include "UMG/WidgetComponent/KGTickableWidgetComponentManager.h"

#include "UMG/WidgetComponent/KGTickableWidgetComponent.h"


#pragma region Important
//UKGTickableWidgetComponentManager* UKGTickableWidgetComponentManager::GetInstance(UObject* InContext)
//{
//	return UKGBasicManager::GetManager<UKGTickableWidgetComponentManager>(InContext);
//}

void UKGTickableWidgetComponentManager::NativeInit()
{
	Super::NativeInit();
}

void UKGTickableWidgetComponentManager::NativeUninit()
{
	WaitAddWidgetComponentList.Empty();
	WaitDeleteWidgetComponentList.Empty();
	WidgetComponentList.Empty();
	Super::NativeUninit();
}
#pragma endregion Important


void UKGTickableWidgetComponentManager::AddComponent(TWeakObjectPtr<UKGTickableWidgetComponent> Component)
{
	if (WaitDeleteWidgetComponentList.Contains(Component))
	{
		WaitDeleteWidgetComponentList.Remove(Component);
		return;
	}
	
	if (WaitAddWidgetComponentList.Contains(Component) || WidgetComponentList.Contains(Component))
	{
		return;
	}

	WaitAddWidgetComponentList.Add(Component);
}

void UKGTickableWidgetComponentManager::RemoveComponent(TWeakObjectPtr<UKGTickableWidgetComponent> Component)
{
	if (WaitAddWidgetComponentList.Contains(Component))
	{
		WaitAddWidgetComponentList.Remove(Component);
		return;
	}
	
	if (!WidgetComponentList.Contains(Component) || WaitDeleteWidgetComponentList.Contains(Component))
	{
		return;
	}

	WaitDeleteWidgetComponentList.Add(Component);
}

void UKGTickableWidgetComponentManager::Tick(float DeltaTime)
{
	if (WaitAddWidgetComponentList.Num() > 0)
	{
		for (auto WidgetComponent : WaitAddWidgetComponentList)
		{
			WidgetComponentList.Add(WidgetComponent);
		}
		WaitAddWidgetComponentList.Empty();
	}

	if (WaitDeleteWidgetComponentList.Num() > 0)
	{
		for (auto WidgetComponent : WaitDeleteWidgetComponentList)
		{
			WidgetComponentList.Remove(WidgetComponent);
		}
		WaitDeleteWidgetComponentList.Empty();
	}

	for (TSet<TWeakObjectPtr<UKGTickableWidgetComponent>>::TIterator Itr(WidgetComponentList); Itr; ++Itr)
	{
		if (Itr->IsValid())
		{
			Itr->Get()->Tick(DeltaTime);
		}
		else
		{
			Itr.RemoveCurrent();
		}
	}
}

void UKGTickableWidgetComponentManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_DuringPhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);
}