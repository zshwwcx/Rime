// Fill out your copyright notice in the Description page of Project Settings.

#include "UMG/WidgetComponent/KGMapTagInfoManager.h"

#include "Core/Common.h"
#include "UMG/Components/KGMapTagLayer.h"
#include "3C/Util/KGUtils.h"
#include "Misc/Paths.h"

#if WITH_EDITOR
#pragma optimize("", off)
#endif

int32 GKGMapTagLayerSubCellSize = 500;
static FAutoConsoleVariableRef CVarKGMapTagLayerSubCellSize(
    TEXT("KGUI.MapTagLayerSubCellSize"),
    GKGMapTagLayerSubCellSize,
    TEXT("Set KGMapTagLayer sub cell size, integer value, unit is cm.")
);

int32 GKGMapTagLayerMaxTagsCountInCell =  1;
static FAutoConsoleVariableRef CVarKGMapTagLayerMaxTagsCountInCell(
    TEXT("KGUI.MapTagLayerMaxTagsCountInCell"),
    GKGMapTagLayerMaxTagsCountInCell,
    TEXT("Set KGMapTagLayer max tags count in cell, integer value.")
);

float GKGMapTagLayerViewBoundRatio = 1.2f;
static FAutoConsoleVariableRef CVarKGMapTagLayerViewBoundRatio(
    TEXT("KGUI.MapTagLayerViewBoundRatio"),
    GKGMapTagLayerViewBoundRatio,
    TEXT("Set KGMapTagLayer view bound ratio, float value.")
);

struct FMapTagInfoSharedPtrSorter
{
    bool operator()(const FMapTagInfoPtr& A, const FMapTagInfoPtr& B) const
    {
        if (!A.IsValid())
        {
            return false;
        }
        
        if (!B.IsValid())
        {
            return true;
        }
        
        return *A < *B;
    }
};

FString FMapTagInfo::ToString(bool bSummary) const
{
    if (bSummary)
    {
        return FString::Printf(TEXT("%s[%d]"), *TaskID, TypeID);
    }

    FString Result = FString::Printf(TEXT("%s[%d]"), *TaskID, TypeID);
    Result += TEXT(": ");
    Result += StaticEnum<EMapTagType>()->GetNameStringByValue(static_cast<int64>(MapTagType)) + TEXT("/");
    Result += StaticLocation.ToString() + TEXT("/");
    Result += FPaths::GetBaseFilename(TemplateWidgetType);
    
    return Result;    
}

/*
 * UKGMapTagViewManager
 */
void UKGMapTagViewManager::Initialize(const FVector& InCameraLocation, const FRotator& InCameraRotation, const FVector2D& InCameraViewportSize, float InViewportScale, const FVector2D& InCurrentCenterLocation, float InConstraintRadius, const FVector4& InConstraintRectangle, EMapShowTypeOnEdge InPanelMapEdgeType)
{
    CameraLocation = InCameraLocation;
    CameraRotation = InCameraRotation;
    CameraViewportSize = InCameraViewportSize;
    ViewportScale = InViewportScale;
    CurrentCenterLocation = InCurrentCenterLocation;
    ConstraintRadius = InConstraintRadius;
    ConstraintRectangle = InConstraintRectangle;
    PanelMapEdgeType = InPanelMapEdgeType;
}


FVector2D UKGMapTagViewManager::GetWidgetOffsetByMapTagInfo(const FMapTagInfo& MapTagInfo) const
{
    FVector WorldLocation(.0f, .0f, .0f);
    AActor* Follower = KGUtils::GetActorByID(MapTagInfo.FollowerID);
    if (MapTagInfo.MapTagType == EMapTagType::Static)
    {
        WorldLocation = MapTagInfo.StaticLocation;
    }
    else if (IsValid(Follower))
    {
        WorldLocation = Follower->K2_GetActorLocation();
    }
    
    return GetWidgetOffsetByWorldLocation(WorldLocation);
}

FVector2D UKGMapTagViewManager::GetWidgetPosByMapTagInfo(const FMapTagInfo& MapTagInfo) const
{
    FVector WorldLocation(.0f, .0f, .0f);
    AActor* Follower = KGUtils::GetActorByID(MapTagInfo.FollowerID);
    if (MapTagInfo.MapTagType == EMapTagType::Static)
    {
        WorldLocation = MapTagInfo.StaticLocation;
    }
    else if (IsValid(Follower))
    {
        WorldLocation = Follower->K2_GetActorLocation();
    }
    return GetWorldOffsetByWorldLocation(WorldLocation);
}


FVector2D UKGMapTagViewManager::GetWidgetOffsetByWorldLocation(const FVector& Location) const
{
    //相机以Z轴负方向为Up，Y轴正方向为Right
    FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
    FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
    FVector WorldVec = Location - CameraLocation;
    FVector2D ProjectedLoc = FVector2D(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;

    FVector2D ViewportRectangleLeftUp = CurrentCenterLocation - CameraViewportSize * ViewportScale * 0.5f;
    FVector2D ViewportPosition = ProjectedLoc - ViewportRectangleLeftUp;
    FVector2D res = FVector2D(ViewportPosition.X / CameraViewportSize.X / ViewportScale, 
                              ViewportPosition.Y / CameraViewportSize.Y / ViewportScale);
    
    return res;
}

FVector2D UKGMapTagViewManager::GetWorldOffsetByWorldLocation(const FVector& Location) const
{
    //相机以Z轴负方向为Up，Y轴正方向为Right
    FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
    FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
    FVector WorldVec = Location - CameraLocation;
    FVector2D ProjectedLoc = FVector2d(WorldVec.Dot(Right), WorldVec.Dot(Up)) + CameraViewportSize * 0.5f;
    return ProjectedLoc;
}

FVector2D UKGMapTagViewManager::DeprojectWidgetOffsetToWorldLocation(const FVector2D& WidgetOffset) const
{
    FVector2D Offset = WidgetOffset * CameraViewportSize * ViewportScale;
    Offset += CurrentCenterLocation - CameraViewportSize * ViewportScale * 0.5f;
    FVector2D WorldOffset = Offset - CameraViewportSize * 0.5f;

    FVector4 LHS(WorldOffset.X, WorldOffset.Y, .0f, .0f);
    FVector Right = CameraRotation.RotateVector(FVector(0, 1, 0));
    FVector Up = CameraRotation.RotateVector(FVector(0, 0, -1));
    FVector Forward = CameraRotation.RotateVector(FVector(-1, 0, 0));

    FMatrix Mat;
    Mat.SetIdentity();
    Mat.SetColumn(0, Right);
    Mat.SetColumn(1, Up);
    Mat.SetColumn(2, Forward);

    FVector4 RHS = Mat.GetTransposed().TransformFVector4(LHS); //正交矩阵，转置就是逆
    FVector RHS3(RHS.X, RHS.Y, RHS.Z);
    RHS3 += CameraLocation;

    return FVector2D(RHS3.X, RHS3.Y);
}

bool UKGMapTagViewManager::UpdateCameraParams(const FVector& InCameraLocation, const FRotator& InCameraRotation, const FVector2D& InCameraViewportSize, float InViewportScale, const FVector2D& InCurrentCenterLocation)
{
    bool bViewChanged = false;
    if (!CameraLocation.Equals(InCameraLocation))
    {
        CameraLocation = InCameraLocation;
        bViewChanged = true;
    }

    if (!CameraRotation.Equals(InCameraRotation))
    {
        CameraRotation = InCameraRotation;
        bViewChanged = true;
    }

    if (!CameraViewportSize.Equals(InCameraViewportSize))
    {
        CameraViewportSize = InCameraViewportSize;
        bViewChanged = true;
    }

    if (!FMath::IsNearlyEqual(ViewportScale, InViewportScale))
    {
        ViewportScale = InViewportScale;
        bViewChanged = true;
    }

    if (!CurrentCenterLocation.Equals(InCurrentCenterLocation))
    {
        CurrentCenterLocation = InCurrentCenterLocation;
        bViewChanged = true;
    }
    
    return bViewChanged;
}

void UKGMapTagInfoManager::FGridCell::CollectVisibleTags(TSet<FMapTagInfoPtr>& OutTags)
{
    Tags.Heapify(FMapTagInfoSharedPtrSorter());
    int32 Count = 0;
    for (int32 Index = 0; Index < Tags.Num(); ++Index)
    {
        if (Tags[Index]->bVisible)
        {
            if (Tags[Index]->bSimpleTagIcon)
            {
                if (Count < GKGMapTagLayerMaxTagsCountInCell)
                {
                    Count++;
                    OutTags.Emplace(Tags[Index]);
                }
            }
            else
            {
                OutTags.Emplace(Tags[Index]);
            }
        }
    }
}

/*
 * UKGMapTagInfoManager
 */
void UKGMapTagInfoManager::Initialize(float InGridSize, UKGMapTagLayer* InOwnerLayer)
{
    GridSize = InGridSize;
    OwnerLayer = InOwnerLayer;
    CurrentCharacterGrid = FGridCellCoord(INT32_MAX - 1, INT32_MAX - 1);

    ViewManager = NewObject<UKGMapTagViewManager>(this);
    bFirstUpdate = true;
}

void UKGMapTagInfoManager::Tick(float DeltaTime)
{
    SCOPED_NAMED_EVENT(UKGMapTagInfoManager_Tick, FColor::Turquoise);
    AActor* CenterActor = KGUtils::GetActorByID(CenterActorID);
    FVector ViewPoint;
    if (IsValid(CenterActor))
    {
        ViewPoint = CenterActor->GetActorLocation();
    	CurrentCenterLocation = ViewManager->GetWorldOffsetByWorldLocation(CenterActor->GetActorLocation());
    }
    else
    {
        ViewPoint = CameraLocation;
    	CurrentCenterLocation = ViewManager->GetWorldOffsetByWorldLocation(CameraLocation);;
    }

    bool bViewChanged = false;
    if (ViewManager)
    {
        bViewChanged = ViewManager->UpdateCameraParams(CameraLocation, CameraRotation, CameraViewportSize, ViewportScale, CurrentCenterLocation);
    }
    
    UpdateFollowTagInfo();
	
    PendingUpdateList.Empty(PendingUpdateList.Num());
    PendingInstanceList.Empty(PendingInstanceList.Num());
    PendingRemoveList.Empty(PendingRemoveList.Num());
    if ((Mode == EMapTagLayerMode::ViewBound && (bViewChanged || bFirstUpdate)) || Mode == EMapTagLayerMode::Full)
    {
        if (bFirstUpdate)
        {
            bFirstUpdate = false;
        }
        
        TSet<FMapTagInfoPtr> LastUpdateList = TempUpdateList;
        
        TArray<FGridCellCoord> ShowCells;
        CalculateShowCells(ViewPoint, ShowCells);
    
        TempUpdateList.Empty();
        for (const auto& CellCoord : ShowCells)
        {
            if (auto* Cell = WorldSubGridMap.Find(CellCoord))
            {
                Cell->CollectVisibleTags(TempUpdateList);
            }
        }
        
        for (auto Iter = LastUpdateList.CreateIterator(); Iter; ++Iter)
        {
            auto& TagInfo = *Iter;
            if (TagInfo.IsValid())
            {
                if (!TempUpdateList.Contains(TagInfo))
                {
                    AddToPendingRemove(TagInfo->TaskID);
                }
            }
        }
    }
    
    for (auto& TagInfo : TempUpdateList)
    {
        AActor* Follower = KGUtils::GetActorByID(TagInfo->FollowerID);
        if (TagInfo->MapTagType == EMapTagType::FollowActor && !IsValid(Follower))
        {
            AddToPendingRemove(TagInfo->TaskID);
            continue;
        }
        
        if (MapTagInfoData.Contains(TagInfo->TaskID))
        {
            UpdateTagState(TagInfo);
        }
        else
        {
            AddToPendingRemove(TagInfo->TaskID);
        }
    }
    
    for (auto TaskID : FollowUpdateList)
    {
        if (!MapTagInfoData.Contains(TaskID))
        {
            AddToPendingRemove(TaskID);
        }
    }
    
    for (auto RotateWidgetInfo : RotateWidgetList)
    {
        ResetEdgeWidgetShear(RotateWidgetInfo.Value);
    }

    AdaptOverlappingCircles();

    // TempUpdateList.Empty(TempUpdateList.Num());
}

void UKGMapTagInfoManager::UpdateTagState(const FMapTagInfoPtr& TagInfo)
{
    SCOPED_NAMED_EVENT(UKGMapTagInfoManager_UpdateTagState, FColor::Magenta);
    // 计算Widget偏移
    FVector WorldLocation(0);
    GetTagWorldPos(TagInfo, WorldLocation);
    FVector2D WidgetOffset = ViewManager->GetWidgetOffsetByWorldLocation(WorldLocation);

    // 计算显示状态
    EMapDisplayState NewState = GetNewMapDisplayState(TagInfo, WidgetOffset);
    EMapDisplayState CurrentState = TagInfo->DisplayState;

    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer][UKGMapTagInfoManager]UpdateTagState %s, state:%s -> %s"), 
        *TagInfo->ToString(),
        *StaticEnum<EMapDisplayState>()->GetNameStringByValue(static_cast<int64>(CurrentState)),
        *StaticEnum<EMapDisplayState>()->GetNameStringByValue(static_cast<int64>(NewState))
    );
    // 状态未改变的情况
    if (NewState == CurrentState && NewState != EMapDisplayState::None)
    {
        HandleSameStateUpdate(TagInfo, NewState);
        return;
    }

    // 需要移除的Tag
    if (CurrentState != EMapDisplayState::None && NewState == EMapDisplayState::None)
    {
        TransitStateToNone(TagInfo);
        return;
    }
    
    // 状态转换处理
    if (CurrentState != NewState)
    {
        // 先移除现有UI
        if (CurrentState != EMapDisplayState::None)
        {
            TransitStateToNone(TagInfo);
        }
        
        // 创建新状态的UI
        if (NewState == EMapDisplayState::Center)
        {
            TransitStateToCenter(TagInfo);
        }
        else if (NewState == EMapDisplayState::Edge)
        {
            TransitStateToEdge(TagInfo);
        }
    }
}

// 相同状态下的更新处理
void UKGMapTagInfoManager::HandleSameStateUpdate(const FMapTagInfoPtr& TagInfoData, EMapDisplayState State)
{
    switch (State)
    {
    case EMapDisplayState::Center:
        {
            UpdateCenterTagPosition(TagInfoData);
        }
        break;
        
    case EMapDisplayState::Edge:
        {
            UpdateEdgeTagPosition(TagInfoData);
        }
        break;
        
    default:
        break;
    }
}

// 移除标签UI的内部逻辑
void UKGMapTagInfoManager::TransitStateToNone(const FMapTagInfoPtr& TagInfoData)
{
    TagInfoData->DisplayState = EMapDisplayState::None;
    EdgeList.Remove(TagInfoData->TaskID);
    AddToPendingRemove(TagInfoData->TaskID);
}

// 创建中心状态标签UI
void UKGMapTagInfoManager::TransitStateToCenter(const FMapTagInfoPtr& TagInfoData)
{
    TagInfoData->DisplayState = EMapDisplayState::Center;
   
    // 设置UI位置和属性
    check(ViewManager);
    TagInfoData->Offset = ViewManager->GetWidgetOffsetByMapTagInfo(*TagInfoData);
    AddToPendingInstance(TagInfoData);
}


// 更新中心状态标签位置
void UKGMapTagInfoManager::UpdateCenterTagPosition(const FMapTagInfoPtr& TagInfoData)
{
    check(ViewManager);
    FVector2D WidgetOffset = ViewManager->GetWidgetOffsetByMapTagInfo(*TagInfoData);
    TagInfoData->Offset = WidgetOffset;
    AddToPendingUpdate(TagInfoData);
}

// 创建边缘状态标签UI
void UKGMapTagInfoManager::TransitStateToEdge(const FMapTagInfoPtr& TagInfoData)
{
    TagInfoData->DisplayState = EMapDisplayState::Edge;
   
    // 设置UI位置和属性
    check(ViewManager);
    
    FVector2D WidgetOffset = ViewManager-> GetWidgetOffsetByMapTagInfo(*TagInfoData);
    
    if (TagInfoData->MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByCircle) // Circle
        {
            SetupCircleEdgeTag(TagInfoData, WidgetOffset);
        }
        else if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle)
        {
            SetupRectangleEdgeTag(TagInfoData, WidgetOffset);
        }
    }
    AddToPendingInstance(TagInfoData);
}

// 设置圆形边缘标签UI
void UKGMapTagInfoManager::SetupCircleEdgeTag(const FMapTagInfoPtr& TagInfoData, const FVector2D& WidgetOffset)
{
    static const FVector2D Origin(0.5f, 0.5f);
    FVector2D ConvertedOffset = ConstraintRange.Radius * (WidgetOffset - Origin).GetSafeNormal() + Origin;
    
    EdgeList.AddUnique(TagInfoData->TaskID);
    TagInfoData->Offset = ConvertedOffset;
}

// 设置矩形边缘标签UI
void UKGMapTagInfoManager::SetupRectangleEdgeTag(const FMapTagInfoPtr& TagInfoData, const FVector2D& WidgetOffset)
{
    static const FVector2D Origin(0.5f, 0.5f);
    FVector4 ConstraintRectangle = ConstraintRange.Rect;
    float Radians = FMath::IsNearlyZero(0.5f - ConstraintRectangle.Y) ? UE_DOUBLE_PI / 2.f : FMath::Atan((0.5f - ConstraintRectangle.X) / (0.5f - ConstraintRectangle.Y));
    float Cosine = FMath::Cos(Radians);
    float Sine = FMath::Sin(Radians);
    
    FVector2D DirectionVec = (WidgetOffset - Origin).GetSafeNormal();
    DirectionVec = CalculateConstrainedDirection(DirectionVec, Cosine, Sine, ConstraintRectangle);
    FVector2D ConvertedOffset = DirectionVec + Origin;
    
    EdgeList.AddUnique(TagInfoData->TaskID);
    TagInfoData->Offset = ConvertedOffset;
}

// 计算约束方向
FVector2D UKGMapTagInfoManager::CalculateConstrainedDirection(const FVector2D& DirectionVec, float Cosine, float Sine, const FVector4& ConstraintRectangle)
{
    FVector2D Result = DirectionVec;
    
    if (DirectionVec.Y <= -Cosine)
    {
        Result = FMath::Abs((0.5f - ConstraintRectangle.Y) / DirectionVec.Y) * DirectionVec;
    }
    else if (DirectionVec.Y >= Cosine)
    {
        Result = FMath::Abs((0.5f - ConstraintRectangle.W) / DirectionVec.Y) * DirectionVec;
    }
    else if (DirectionVec.X < -Sine)
    {
        Result = FMath::Abs((0.5f - ConstraintRectangle.X) / DirectionVec.X) * DirectionVec;
    }
    else if (DirectionVec.X > Sine)
    {
        Result = FMath::Abs((0.5f - ConstraintRectangle.Z) / DirectionVec.X) * DirectionVec;
    }
    
    return Result;
}

// 更新边缘状态标签位置
void UKGMapTagInfoManager::UpdateEdgeTagPosition(const FMapTagInfoPtr& TagInfoData)
{
    check(ViewManager);
    FVector2D WidgetOffset = ViewManager->GetWidgetOffsetByMapTagInfo(*TagInfoData);
    
    if (TagInfoData->MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByCircle)
        {
            SetupCircleEdgeTag(TagInfoData, WidgetOffset);
        }
        else if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle)
        {
            SetupRectangleEdgeTag(TagInfoData, WidgetOffset);
        }
    }

    AddToPendingUpdate(TagInfoData);
}

void UKGMapTagInfoManager::AddTagToGrid(const FMapTagInfoPtr& InTagInfo)
{
    if (!InTagInfo.IsValid())
    {
        return;
    }
    
    // TODO. 可以不用 AddSingleTag 而改成一次性对 MapTagInfoData 设置好映射关系
    // 从MapTagInfoData获取位置信息
    FVector Pos;
    GetTagWorldPos(InTagInfo, Pos);
    FGridCellCoord GridCoord = WorldToGrid(Pos);
    AddSingleTagToGridInternal(InTagInfo, GridCoord);
}


void UKGMapTagInfoManager::RegisterWidgetRotateInEdge(const FString& TaskID, UWidget* Widget, float Offset)
{
    RotateWidgetList.Add(TaskID, FMapEdgeRotateInfo(TaskID, Widget, Offset));
}

void UKGMapTagInfoManager::UnRegisterWidgetRotateInEdge(const FString& TaskID)
{
    RotateWidgetList.Remove(TaskID);
}

float UKGMapTagInfoManager::ConvertRotateAngle(float InRotateAngleInDegree)
{
    float RotateAngle = InRotateAngleInDegree;
    RotateAngle = FMath::DegreesToRadians(RotateAngle);
    RotateAngle = FMath::Fmod(RotateAngle, UE_TWO_PI);
    RotateAngle = RotateAngle < 0 ? RotateAngle + UE_TWO_PI : RotateAngle;
    RotateAngle = RotateAngle > UE_TWO_PI ? RotateAngle - UE_TWO_PI : RotateAngle;
    return RotateAngle;
}

void UKGMapTagInfoManager::ResetEdgeWidgetShear(const FMapEdgeRotateInfo& MapEdgeRotateInfo)
{
    if (auto TagInfo = GetMapTagInfo(MapEdgeRotateInfo.TaskID))
    {
        if (TagInfo->DisplayState == EMapDisplayState::Edge && MapEdgeRotateInfo.RotateWidget.IsValid())
        {
            float Shear = MapEdgeRotateInfo.Offset - GetWidgetShearByTaskID(MapEdgeRotateInfo.TaskID) / UE_DOUBLE_PI * 180.f;
            MapEdgeRotateInfo.RotateWidget->SetRenderTransformAngle(Shear);
        }
    }
}

void UKGMapTagInfoManager::SetSimpleTagIcon(const FString& TaskID, const FString& InIcon)
{
    if (MapTagInfoData.Contains(TaskID))
    {
        MapTagInfoData[TaskID]->TagIcon = InIcon;
        AddToPendingUpdate(MapTagInfoData[TaskID]);
    }
}

void UKGMapTagInfoManager::SetSimpleTagIconSize(const FString& TaskID, float InSizeX, float InSizeY)
{
    if (MapTagInfoData.Contains(TaskID))
    {
        MapTagInfoData[TaskID]->IconSizeX = InSizeX;
        MapTagInfoData[TaskID]->IconSizeY = InSizeY;
        AddToPendingUpdate(MapTagInfoData[TaskID]);
    }
}

void UKGMapTagInfoManager::SetSimpleTagVisible(const FString& TaskID, bool bInVisible)
{
	if (MapTagInfoData.Contains(TaskID))
	{
		MapTagInfoData[TaskID]->bVisible = bInVisible;
		AddToPendingUpdate(MapTagInfoData[TaskID]);
	}
}

void UKGMapTagInfoManager::SetSimpleTagRotate(const FString& TaskID, float InRotateAngleInDegree)
{
    if (MapTagInfoData.Contains(TaskID))
    {
        MapTagInfoData[TaskID]->RotateAngle = ConvertRotateAngle(InRotateAngleInDegree);
        AddToPendingUpdate(MapTagInfoData[TaskID]);
    }
}

EMapDisplayState UKGMapTagInfoManager::GetNewMapDisplayState(const FMapTagInfoPtr& MapTagInfo, const FVector2D& WidgetOffset) const
{
    // 实现状态判断逻辑（从原UKGMapTagLayer中迁移）
    if (ViewportScale > MapTagInfo->ShowRatioInterval.Y || ViewportScale < MapTagInfo->ShowRatioInterval.X)
    {
        return EMapDisplayState::None;
    }

    if (MapTagInfo->bIgnoreConstraint)
    {
        return EMapDisplayState::Center;
    }

    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle && InRectangle(WidgetOffset) && 
        MapTagInfo->MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        return EMapDisplayState::Center;
    }

    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle && !InRectangle(WidgetOffset) 
        && MapTagInfo->MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        return EMapDisplayState::Edge;
    }

    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByCircle && InCircle(WidgetOffset) 
        && MapTagInfo->MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        return EMapDisplayState::Center;
    }

    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByCircle && !InCircle(WidgetOffset) 
        && MapTagInfo->MapEdgeType == EMapEdgeType::ShowOnEdge)
    {
        return EMapDisplayState::Edge;
    }

    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByCircle && InCircle(WidgetOffset) 
        && MapTagInfo->MapEdgeType == EMapEdgeType::None)
    {
        return EMapDisplayState::Center;
    }

    if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle && InRectangle(WidgetOffset) 
        && MapTagInfo->MapEdgeType == EMapEdgeType::None)
    {
        return EMapDisplayState::Center;
    }

    return EMapDisplayState::None;
}

float UKGMapTagInfoManager::GetWidgetShearByTaskID(const FString& TaskID)
{
    if (MapTagInfoData.Contains(TaskID) && MapTagInfoData[TaskID].IsValid())
    {
        FVector2D Pos = ViewManager->GetWidgetOffsetByMapTagInfo(*MapTagInfoData[TaskID].Get());
        Pos.Y = 1 - Pos.Y;
        FVector2D Triangle = FVector2D(0.5f, 0.5f) - Pos;
        Triangle.Normalize();
        if (Triangle.Y > .0f)
        {
            return FMath::Acos(Triangle.X);
        }

        if (Triangle.Y < .0f)
        {
            return 2 * UE_DOUBLE_PI - FMath::Acos(Triangle.X);
        }
        /*
        else if (Triangle.Y > 0)
        {
            return .0f;
        }
        else
        {
            return UE_DOUBLE_PI;
        }*/
    }
    return .0f;
}

void UKGMapTagInfoManager::AdaptOverlappingCircles()
{
    EdgeList.Sort([&](const FString& A, const FString& B)
    {
        auto PtrA = GetMapTagInfo(A);
        auto PtrB = GetMapTagInfo(B);
        if (PtrA.IsValid() && PtrB.IsValid())
        {
            return PtrA->Offset.X < PtrB->Offset.X;
        }
        
        if (PtrA.IsValid() && !PtrB.IsValid())
        {
            return true;
        }
        
        return false;        
    });

    auto NearSquaredLength = PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle ? 0.002 : 0.0003;
    auto NearLength = PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle ? 0.0447 : 0.0173;
    
    for (int I = 0; I < EdgeList.Num(); I++)
    {
        auto TaskA = EdgeList[I];
        auto TagInfoDataA = GetMapTagInfo(TaskA);
        if (!TagInfoDataA.IsValid())
        {
            continue;
        }
        
        for (int J = I + 1; J < EdgeList.Num(); J++)
        {
            auto TaskB = EdgeList[J];
            auto TagInfoDataB = GetMapTagInfo(TaskB);
            if (!TagInfoDataB.IsValid())
            {
                continue;
            }
            
            auto SquaredLen = (TagInfoDataA->Offset - TagInfoDataB->Offset).SquaredLength();            
            if (SquaredLen < NearSquaredLength)
            {
                auto Len = FMath::Sqrt(SquaredLen);
                if (PanelMapEdgeType == EMapShowTypeOnEdge::ShowOnEdgeByRectangle && FMath::IsNearlyEqual(TagInfoDataA->Offset.X, TagInfoDataB->Offset.X))
                {
                    if (TagInfoDataA->Offset.Y < TagInfoDataB->Offset.Y)
                    {
                        FVector2D ConvertedOffset = TagInfoDataA->Offset;
                        ConvertedOffset.Y = ConvertedOffset.Y - (NearLength - Len);
                        TagInfoDataA->Offset = ConvertedOffset;
                        AddToPendingUpdate(TagInfoDataA);
                    }
                    else
                    {
                        FVector2D ConvertedOffset = TagInfoDataA->Offset;
                        ConvertedOffset.Y = ConvertedOffset.Y + (NearLength - Len);
                        TagInfoDataA->Offset = ConvertedOffset;
                        AddToPendingUpdate(TagInfoDataA);
                    }
                }
                else
                {
                    if (TagInfoDataA->Offset.X < TagInfoDataB->Offset.X)
                    {
                        TagInfoDataA->Offset = TagInfoDataA->Offset - (NearLength - Len);
                        AddToPendingUpdate(TagInfoDataA);
                    }
                    else
                    {
                        TagInfoDataA->Offset = TagInfoDataA->Offset + (NearLength - Len);
                        AddToPendingUpdate(TagInfoDataA);
                    }
                }
            }
        }
    }
}

UKGMapTagInfoManager::FGridCellCoord UKGMapTagInfoManager::WorldToGrid(const FVector& WorldLocation) const
{
    return FGridCellCoord(
        FMath::FloorToInt(WorldLocation.X / GridSize),
        FMath::FloorToInt(WorldLocation.Y / GridSize)
    );
}

UKGMapTagInfoManager::FGridCellCoord UKGMapTagInfoManager::WorldToSubGrid(float WorldLocationX, float WorldLocationY )
{
    return FGridCellCoord(
        FMath::FloorToInt(WorldLocationX / GKGMapTagLayerSubCellSize),
        FMath::FloorToInt(WorldLocationY / GKGMapTagLayerSubCellSize)
    );
}

void UKGMapTagInfoManager::AddSingleTag(const FMapTagInfo& InTagInfo)
{
    // clamp rotate angle in [0, 360]
    float RotateAngle = ConvertRotateAngle(InTagInfo.RotateAngle);
    
    FMapTagInfoPtr TagInfo;
	if (!MapTagInfoData.Contains(InTagInfo.TaskID))
	{
	    TagInfo = MapTagInfoData.Add(InTagInfo.TaskID, MakeShared<FMapTagInfo>(InTagInfo));
	    TagInfo->Token = GetToken();
	    TagInfo->RotateAngle = RotateAngle;
	}
    else
    {
        TagInfo = MapTagInfoData[InTagInfo.TaskID];
        RemoveTagFromGrid(TagInfo);
    
        EMapDisplayState CurState = TagInfo->DisplayState;
        EMapDisplayState LastState = TagInfo->LastDisplayState;
        int64 Token = TagInfo->Token;
        
        *TagInfo = InTagInfo;
        TagInfo->Token = Token;
        TagInfo->DisplayState = CurState;
        TagInfo->LastDisplayState = LastState;
        TagInfo->RotateAngle = RotateAngle;
    }

    if (InTagInfo.MapTagType == EMapTagType::FollowActor)
    {
        FollowUpdateList.Add(InTagInfo.TaskID);
    }

    AddTagToGrid(TagInfo);
    TryAddToUpdateList(TagInfo);
}

void UKGMapTagInfoManager::RemoveSingleTag(const FString& TaskID)
{
    if (MapTagInfoData.Find(TaskID))
    {
        auto Tag = MapTagInfoData[TaskID];
        PendingUpdateList.Remove(Tag);
        PendingInstanceList.Remove(Tag);
        PendingRemoveList.Remove(TaskID);
        
        FollowUpdateList.Remove(TaskID);
        RotateWidgetList.Remove(TaskID);
        EdgeList.Remove(TaskID);
        
        if (TaskIDToGridMap.Contains(TaskID))
        {
            FGridCellCoord Coord = TaskIDToGridMap[TaskID];
            TaskIDToGridMap.Remove(TaskID);
            if (WorldSubGridMap.Contains(Coord))
            {
                WorldSubGridMap[Coord].Tags.Remove(Tag);
            }
        }
        MapTagInfoData.Remove(TaskID);
    }
}

void UKGMapTagInfoManager::AddSingleTagToGridInternal(const FMapTagInfoPtr& InTagInfo, const FGridCellCoord& GridCoord)
{
    if (!InTagInfo.IsValid())
    {
        return;
    }
    
	// 添加到格子映射ddd
	if (!GridToTaskMap.Contains(GridCoord))
	{
		GridToTaskMap.Emplace(GridCoord);
	}
    
	if (!GridToTaskMap[GridCoord].Contains(InTagInfo))
	{
		GridToTaskMap[GridCoord].Add(InTagInfo);
	}
        
	// 添加到反向映射
	TaskIDToGridMap.Add(InTagInfo->TaskID, GridCoord);
    
    // 添加到子格子映射
    FVector Pos;
    if (GetTagWorldPos(InTagInfo, Pos))
    {
        FGridCellCoord SubGridCoord = WorldToSubGrid(Pos.X, Pos.Y);
        
        if (!WorldSubGridMap.Contains(SubGridCoord))
        {
            auto& Cell = WorldSubGridMap.Add(SubGridCoord);
            Cell.CellIndexX = SubGridCoord.X;
            Cell.CellIndexY = SubGridCoord.Y;
            Cell.Tags.Heapify(FMapTagInfoSharedPtrSorter());
        }
        
        auto& Cell = WorldSubGridMap[SubGridCoord];
        Cell.Tags.HeapPush(InTagInfo, FMapTagInfoSharedPtrSorter());
    }
    
}

void UKGMapTagInfoManager::RemoveTagFromGrid(const FMapTagInfoPtr& InTagInfo)
{
    if (!InTagInfo.IsValid())
    {
        return;
    }
    
    if (FGridCellCoord* GridCoord = TaskIDToGridMap.Find(InTagInfo->TaskID))
    {
        // 从格子映射中移除
        if (TArray<FMapTagInfoPtr>* Tags = GridToTaskMap.Find(*GridCoord))
        {
            Tags->Remove(InTagInfo);
            if (Tags->Num() == 0)
            {
                GridToTaskMap.Remove(*GridCoord);
            }
        }
        
        // 从反向映射中移除
        TaskIDToGridMap.Remove(InTagInfo->TaskID);
        
        // 从子格子映射中移除
        FVector Pos;
        if (GetTagWorldPos(InTagInfo, Pos))
        {
            FGridCellCoord SubGridCoord = WorldToSubGrid(Pos.X, Pos.Y);
            if (WorldSubGridMap.Contains(SubGridCoord))
            {
                int32 Index = WorldSubGridMap[SubGridCoord].Tags.Find(InTagInfo);
                if (Index != INDEX_NONE)
                {
                    WorldSubGridMap[SubGridCoord].Tags.HeapRemoveAt(Index, FMapTagInfoSharedPtrSorter());
                }
                
                if (WorldSubGridMap[SubGridCoord].Tags.IsEmpty())
                {
                    WorldSubGridMap.Remove(SubGridCoord);
                }
            }
        }
    }
}

bool UKGMapTagInfoManager::GetTagWorldPos(const FMapTagInfoPtr& InTagInfoData, FVector& OutPos)
{
    if (InTagInfoData->MapTagType == EMapTagType::Static)
    {
        OutPos = InTagInfoData->StaticLocation;
        return true;
    }
    
    if (InTagInfoData->MapTagType == EMapTagType::FollowActor)
    {
        AActor* Follower = KGUtils::GetActorByID(InTagInfoData->FollowerID);
        if (IsValid(Follower))
        {
            OutPos = Follower->K2_GetActorLocation();
            return true;
        }
    }

    return false;
}

int64 UKGMapTagInfoManager::GetToken()
{
    static int64 Token = 0;
    return ++Token;
}

void UKGMapTagInfoManager::CalculateShowCells(const FVector& InCenterInWorldSpace,TArray<FGridCellCoord>& OutSubCells)
{
    if (Mode == EMapTagLayerMode::Full)
    {
        for (auto& Pair : WorldSubGridMap)
        {
            OutSubCells.Add(Pair.Key);
        }
        return;
    }
    
    FGridCellCoord CenterGrid = WorldToSubGrid(InCenterInWorldSpace.X, InCenterInWorldSpace.Y);
    GetViewRangeBoundCell(CenterGrid, ViewBoundMinCell, ViewBoundMaxCell);
    for (auto& Pair : WorldSubGridMap)
    {
        if (Pair.Key.IsInRange(ViewBoundMinCell, ViewBoundMaxCell))
        {
            OutSubCells.Add(Pair.Key);
        }
    }
}

void UKGMapTagInfoManager::GetViewRangeBoundCell(const FGridCellCoord& InCenterCell, FGridCellCoord& OutBoundMinCell, FGridCellCoord& OutBoundMaxCell) const
{
    float Width = GridSize * GKGMapTagLayerViewBoundRatio;
    int32 RangeCellW = FMath::CeilToInt(Width / GKGMapTagLayerSubCellSize) + 1;
    const float aspectRatio = CameraViewportSize.X / CameraViewportSize.Y;
    int32 RangeCellH = FMath::CeilToInt(Width / (aspectRatio * GKGMapTagLayerSubCellSize)) + 1;
    OutBoundMinCell = FGridCellCoord(InCenterCell.X - RangeCellW, InCenterCell.Y - RangeCellH);
    OutBoundMaxCell = FGridCellCoord(InCenterCell.X + RangeCellW, InCenterCell.Y + RangeCellH);
}

void UKGMapTagInfoManager::TryAddToUpdateList(const FMapTagInfoPtr& InTagInfo)
{
    if (bValidViewBounds)
    {
        FVector Pos;
        if (GetTagWorldPos(InTagInfo, Pos))
        {
            FGridCellCoord GridCoord = WorldToSubGrid(Pos.X, Pos.Y);
            if (GridCoord.IsInRange(ViewBoundMinCell, ViewBoundMaxCell))
            {
                TempUpdateList.Emplace(InTagInfo);
            }
        }
    }
}

void UKGMapTagInfoManager::UpdateTagLocation(const FString& TaskID, const FVector& NewLocation)
{
	if (MapTagInfoData.IsEmpty() || !MapTagInfoData.Contains(TaskID))
	{
		return;
	}
    
    auto& TagInfo = MapTagInfoData[TaskID];
    if (!TagInfo.IsValid())
    {
        return;
    }
    
    FVector Location(0);
    GetTagWorldPos(TagInfo, Location);
    
    // 地图不需要非常精准的位置
    if (Location.Equals(NewLocation, 0.1f))
    {
        return;
    }
    
    // 先移除旧的格子映射
    RemoveTagFromGrid(TagInfo);
    
    // 更新MapTagInfoData中的位置
    TagInfo->StaticLocation = NewLocation;
    TryAddToUpdateList(TagInfo);
	
    // 重新添加到新的格子
    AddTagToGrid(TagInfo);
}

TArray<UKGMapTagInfoManager::FGridCellCoord> UKGMapTagInfoManager::GetSurroundingGrids(const FGridCellCoord& CenterGrid)
{
    TArray<FGridCellCoord> SurroundingGrids;
    
    for (int32 x = -1; x <= 1; x++)
    {
        for (int32 y = -1; y <= 1; y++)
        {
            SurroundingGrids.Add(FGridCellCoord(CenterGrid.X + x, CenterGrid.Y + y));
        }
    }
    
    return SurroundingGrids;
}

bool UKGMapTagInfoManager::FilterTasksByCharacterPosition(const FVector& CharacterLocation)
{
    FGridCellCoord NewCharacterGrid = WorldToGrid(CharacterLocation);
    
    // 如果角色还在同一个格子，不需要更新
    if (NewCharacterGrid == CurrentCharacterGrid)
    {
        return true;
    }

    SCOPED_NAMED_EVENT(UKGMapTagInfoManager_FilterTasksByCharacterPosition, FColor::Magenta);
    
    // 获取新旧九宫格范围
    TArray<FGridCellCoord> NewSurroundingGrids = GetSurroundingGrids(NewCharacterGrid);
    TArray<FGridCellCoord> OldSurroundingGrids = GetSurroundingGrids(CurrentCharacterGrid);
    
    TSet<FGridCellCoord> NewGridSet(NewSurroundingGrids);
    TSet<FGridCellCoord> OldGridSet(OldSurroundingGrids);
    
    // 找出需要卸载的格子
    for (const FGridCellCoord& OldGrid : OldGridSet)
    {
        if (!NewGridSet.Contains(OldGrid))
        {
            UnloadGrid(OldGrid);
        }
    }
    
    // 找出需要加载的格子
    for (const FGridCellCoord& NewGrid : NewGridSet)
    {
        if (!CurrentLoadedGrids.Contains(NewGrid))
        {
            LoadGrid(NewGrid);
        }
    }
    
    // 更新当前格子
    CurrentCharacterGrid = NewCharacterGrid;
    return false;
}

void UKGMapTagInfoManager::UpdateFollowTagInfo()
{
	if (MapTagInfoData.IsEmpty() || FollowUpdateList.IsEmpty())
    {
        return;
    }

    SCOPED_NAMED_EVENT(UKGMapTagInfoManager_UpdateFollowTagInfo, FColor::Emerald);
	// 每 LowFrequencyUpdateInterval 帧更新一次九宫格外的图标格子状态
	constexpr int32 LowFrequencyUpdateInterval = 5;
	bool bShouldDoLowFrequencyUpdate = false;
	static int32 LowFrequencyUpdateCounter = 0;
	LowFrequencyUpdateCounter = LowFrequencyUpdateCounter % LowFrequencyUpdateInterval;
    if (LowFrequencyUpdateCounter == 0)
    {
    	bShouldDoLowFrequencyUpdate = true;
    }
    LowFrequencyUpdateCounter++;
    
    // 遍历所有需要跟随更新的标签
    for (const FString& TaskID : FollowUpdateList)
    {
        // 获取标签信息
        auto TagInfo = GetMapTagInfo(TaskID);
        if (!TagInfo.IsValid())
        {
            continue;
        }
        
        // 计算新的格子坐标
        FGridCellCoord NewGridCoord;
    	if (TagInfo->MapTagType == EMapTagType::Static)
    	{
    		NewGridCoord = WorldToGrid(TagInfo->StaticLocation);
    	}
    	else if (TagInfo->MapTagType == EMapTagType::FollowActor)
    	{
    		AActor* Follower = KGUtils::GetActorByID(TagInfo->FollowerID);
    		if (IsValid(Follower))
    		{
    			NewGridCoord = WorldToGrid(Follower->K2_GetActorLocation());
    		}
    	}
	    else
	    {
		    UE_LOG(LogTemp, Log, TEXT("%s Invalid MapTagType: %d"), *TaskID, TagInfo->MapTagType);
	    	continue;
	    }
        
        // 检查标签是否在当前九宫格内
        const bool bIsInCurrentGrids = CurrentLoadedGrids.Contains(NewGridCoord);
        
        // 决定是否更新这个标签
        bool bShouldUpdateThisTag = false;
        if (bIsInCurrentGrids || bShouldDoLowFrequencyUpdate)
        {
            // 九宫格内的标签：每帧都更新
            // 九宫格外的标签：只在低频更新时处理
            bShouldUpdateThisTag = true;
        }
        
        if (!bShouldUpdateThisTag)
        {
            continue; // 跳过这个标签
        }
        
        // 获取任务在格子映射中的旧坐标
        FGridCellCoord* CurrentGridCoordPtr = TaskIDToGridMap.Find(TaskID);
    	
        // 如果任务在格子映射中的位置也需要更新
        if (CurrentGridCoordPtr && *CurrentGridCoordPtr != NewGridCoord)
        {
            // 从旧格子中移除
            RemoveTagFromGrid(TagInfo);

        	AddSingleTagToGridInternal(TagInfo, NewGridCoord);
        }
        else if (!CurrentGridCoordPtr)
        {
            // 这是一个新标签，还没有添加到格子映射中
        	AddSingleTagToGridInternal(TagInfo, NewGridCoord);
        }
    }
}

void UKGMapTagInfoManager::ClearAllTags()
{
    MapTagInfoData.Empty();
    FollowUpdateList.Empty();
    TempUpdateList.Empty();
    PendingUpdateList.Empty();
    PendingInstanceList.Empty();
    PendingRemoveList.Empty();
    RotateWidgetList.Empty();
    EdgeList.Empty();
    
	GridToTaskMap.Empty();
	TaskIDToGridMap.Empty();
	CurrentLoadedGrids.Empty();
	CurrentCharacterGrid = FGridCellCoord(INT32_MAX - 1, INT32_MAX - 1);
}

TArray<FString> UKGMapTagInfoManager::GetNearbyTasksByTaskID(const FString& TaskID, float ToleranceDistance)
{
    TArray<FString> OutTasks;
    if (!MapTagInfoData.Contains(TaskID) || !MapTagInfoData[TaskID].IsValid()
        || MapTagInfoData[TaskID]->MapTagType != EMapTagType::Static)
    {
        return OutTasks;
    }

    float SquaredDistance = ToleranceDistance * ToleranceDistance;
    // TODO: limunan, need to optimize distance detection
    FVector2D TargetLocation = ViewManager->GetWidgetOffsetByWorldLocation(MapTagInfoData[TaskID]->StaticLocation);
    for (auto Iter = MapTagInfoData.CreateIterator(); Iter; ++Iter)
    {
        if (!Iter->Value.IsValid() || Iter->Value->MapTagType != EMapTagType::Static)
        {
            continue;
        }
        if ((ViewManager->GetWidgetOffsetByWorldLocation(Iter->Value->StaticLocation) - TargetLocation).SquaredLength
        () < SquaredDistance)
        {
            OutTasks.Add(Iter->Key);
        }
    }
    return OutTasks;
}

TArray<FString> UKGMapTagInfoManager::GetNearbyInteractableTasksByTaskID(const FString& TaskID, float ToleranceDistance, bool bRequireCenter)
{
    TArray<FString> OutTasks;
    if (!MapTagInfoData.Contains(TaskID) 
        || (bRequireCenter && MapTagInfoData[TaskID]->DisplayState != EMapDisplayState::Center))
    {
        return OutTasks;
    }

    float SquaredDistance = ToleranceDistance * ToleranceDistance;
    // TODO: limunan, need to optimize distance detection
    FVector2D TargetLocation = ViewManager->GetWidgetOffsetByWorldLocation(MapTagInfoData[TaskID]->StaticLocation);
    for (auto Iter = MapTagInfoData.CreateIterator(); Iter; ++Iter)
    {
        if (!Iter->Value->bInteractable)
        {
            continue;
        }
        if ((ViewManager->GetWidgetOffsetByWorldLocation(Iter->Value->StaticLocation) - TargetLocation).SquaredLength
        () < SquaredDistance)
        {
            OutTasks.Add(Iter->Key);
        }
    }
    return OutTasks;
}

void UKGMapTagInfoManager::ResetTaskTypeToFollowActor(const FString& TaskID, int64 ActorID)
{
    if (auto Tag = GetMapTagInfo(TaskID))
    {
        Tag->MapTagType = EMapTagType::FollowActor;
        Tag->FollowerID = ActorID;
        TempUpdateList.Add(Tag);
    }
}

void UKGMapTagInfoManager::ResetTaskTypeToStatic(const FString& TaskID)
{
    if (auto Tag = GetMapTagInfo(TaskID))
    {
        Tag->MapTagType = EMapTagType::Static;
        Tag->FollowerID = 0;
        TempUpdateList.Add(Tag);
    }
}

void UKGMapTagInfoManager::SetTaskShowEdgeType(const FString& TaskID, EMapEdgeType ShowOnEdgeType)
{
    if (auto TagInfo = GetMapTagInfo(TaskID))
    {
        TagInfo->MapEdgeType = ShowOnEdgeType;
        TempUpdateList.Add(TagInfo);
    }
}

void UKGMapTagInfoManager::SetTaskInteractable(const FString& TaskID, bool bInteractable)
{
    auto TagInfo = GetMapTagInfo(TaskID);
    if (TagInfo.IsValid())
    {
        TagInfo->bInteractable = bInteractable;
        TempUpdateList.Add(TagInfo);
    }
}

FVector2D UKGMapTagInfoManager::GetWidgetPosByTaskID(const FString& TaskID)
{
    if (auto TagInfo = GetMapTagInfo(TaskID))
    {
        return ViewManager->GetWidgetPosByMapTagInfo(*TagInfo);
    }
    return FVector2D::Zero();
}

void UKGMapTagInfoManager::BatchAddTags(const TMap<FString, FMapTagInfo>& InBatchData)
{
    TempUpdateList.Empty();
    for (const auto& Pair : InBatchData)
    {
        auto TagInfo = MakeShared<FMapTagInfo>(Pair.Value);
        TagInfo->Token = GetToken();
        MapTagInfoData.Add(Pair.Key, TagInfo);
    }
    
    for (auto Iter = MapTagInfoData.CreateIterator(); Iter; ++Iter)
    {
        if (Iter->Value.IsValid() && Iter->Value->MapTagType == EMapTagType::FollowActor)
        {
            FollowUpdateList.Add(Iter->Key);
        }
        
        TempUpdateList.Add(Iter->Value);
    }
}

void UKGMapTagInfoManager::LoadGrid(const FGridCellCoord& GridCoord)
{
	if (MapTagInfoData.IsEmpty())
	{
		return;
	}
	
    if (TArray<FMapTagInfoPtr>* Tags = GridToTaskMap.Find(GridCoord))
    {
        for (const auto& Tag : *Tags)
        {
            TempUpdateList.Add(Tag);
            // 创建小地图图标UI，设置位置等
            UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer][UKGMapTagInfoManager]LoadGrid, add task: %s at grid (%d, %d)"), 
                   *Tag->TaskID, GridCoord.X, GridCoord.Y);
        }
    }
    
    CurrentLoadedGrids.Add(GridCoord);
}

void UKGMapTagInfoManager::UnloadGrid(const FGridCellCoord& GridCoord)
{
    if (TArray<FMapTagInfoPtr>* Tags = GridToTaskMap.Find(GridCoord))
    {
        for (const auto& Tag : *Tags)
        {
            // 在这里实现图标的卸载逻辑
            UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer][UKGMapTagInfoManager]UnloadGrid, remove task: %s from grid (%d, %d)"), 
                   *Tag->TaskID, GridCoord.X, GridCoord.Y);
            TempUpdateList.Add(Tag);
        }
    }
    
    CurrentLoadedGrids.Remove(GridCoord);
}

void UKGMapTagInfoManager::BuildCurrentTaskIDs(TSet<FString>& OutTaskIDs) const
{
    SCOPED_NAMED_EVENT(UKGMapTagInfoManager_BuildCurrentTaskIDs, FColor::Silver);
    
    for (const FGridCellCoord& Grid : CurrentLoadedGrids)
    {
        if (const TArray<FMapTagInfoPtr>* Tags = GridToTaskMap.Find(Grid))
        {
            for (auto& Tag : *Tags)
            {
                OutTaskIDs.Emplace(Tag->TaskID);
            }
        }
    }
}

FMapTagInfoPtr UKGMapTagInfoManager::GetMapTagInfo(const FString& TaskID) const
{
    if (MapTagInfoData.Contains(TaskID))
    {
        return  MapTagInfoData[TaskID];
    }
    
    return nullptr;
}

FMapTagInfoPtr UKGMapTagInfoManager::GetMapTagInfo(const FString& TaskID)
{
    if (MapTagInfoData.Contains(TaskID))
    {
        return MapTagInfoData[TaskID];
    }
    
    return nullptr;
}

void UKGMapTagInfoManager::UpdateCameraParams(const FVector& InCameraLocation, const FRotator& InCameraRotation, const FVector2D& InCameraViewportSize, float InViewportScale)
{
    CameraLocation = InCameraLocation;
    CameraRotation = InCameraRotation;
    CameraViewportSize = InCameraViewportSize;
    ViewportScale = InViewportScale;

    if (ViewManager)
    {
        ViewManager->UpdateCameraParams(InCameraLocation, InCameraRotation, InCameraViewportSize, InViewportScale, CurrentCenterLocation);
    }
}

void UKGMapTagInfoManager::AddToPendingInstance(const FMapTagInfoPtr& InTagInfo)
{
    int32 Index = PendingInstanceList.AddUnique(InTagInfo);
    PendingRemoveList.Remove(InTagInfo->TaskID);
#if WITH_EDITOR
    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer][UKGMapTagInfoManager]AddToPendingInstance %s"), *InTagInfo->TaskID);
    if (Index != PendingInstanceList.Num() - 1)
    {
        UE_LOG(LogKGUI, Warning, TEXT("[KGMapTagInfoManager]%s TaskID is already in PendingInstanceList"), *InTagInfo->TaskID);
    }
#endif
}

void UKGMapTagInfoManager::AddToPendingUpdate(const FMapTagInfoPtr& InTagInfo)
{
    int32 Index = PendingUpdateList.AddUnique(InTagInfo);
    PendingRemoveList.Remove(InTagInfo->TaskID);
#if WITH_EDITOR
    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer][UKGMapTagInfoManager]AddToPendingUpdate %s"), *InTagInfo->TaskID);
    if (Index != PendingUpdateList.Num() - 1)
    {
        UE_LOG(LogKGUI, Warning, TEXT("[KGMapTagInfoManager]%s TaskID is already in PendingUpdateList"), *InTagInfo->TaskID);
    }
#endif
}

void UKGMapTagInfoManager::AddToPendingRemove(const FString& TaskID)
{
    int32 Index = PendingRemoveList.AddUnique(TaskID);
    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer][UKGMapTagInfoManager]AddToPendingRemove %s"), *TaskID);
#if WITH_EDITOR
    if (Index != PendingRemoveList.Num() - 1)
    {
        UE_LOG(LogKGUI, Warning, TEXT("[KGMapTagInfoManager]%s TaskID is already in PendingRemoveList"), *TaskID);
    }
#endif
}

void UKGMapTagInfoManager::AddToFollowUpdate(const FString& TaskID)
{
    FollowUpdateList.Add(TaskID);
    UE_LOG(LogKGUI, Verbose, TEXT("[UKGMapTagLayer][UKGMapTagInfoManager]AddToFollowUpdate %s"), *TaskID);
}

bool UKGMapTagInfoManager::InRectangle(const FVector2D& InWidgetOffset) const
{
    const FVector4& ConstraintRectangle = ConstraintRange.Rect;
    return ConstraintRectangle.X < InWidgetOffset.X && InWidgetOffset.X < (1.0f - ConstraintRectangle.Z) 
    && ConstraintRectangle.Y < InWidgetOffset.Y && InWidgetOffset.Y < (1.0f - ConstraintRectangle.W);
}

bool UKGMapTagInfoManager::InCircle(const FVector2D& InWidgetOffset) const
{
	const float aspectRatio = CameraViewportSize.X / CameraViewportSize.Y;
	if (aspectRatio == 1)
	{
		return (InWidgetOffset - FVector2D(0.5f, 0.5f)).SquaredLength() < ConstraintRange.Radius * ConstraintRange.Radius;
	}

	const float xOffset = InWidgetOffset.X - 0.5f;
	const float yOffset = InWidgetOffset.Y - 0.5f;
	const float yConstraint = ConstraintRange.Radius * aspectRatio;
	return (xOffset * xOffset) / (ConstraintRange.Radius * ConstraintRange.Radius) + (yOffset * yOffset) / (yConstraint * yConstraint) < 1;
}

#if WITH_EDITOR
#pragma optimize("", on)
#endif