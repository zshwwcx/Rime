#include "UMG/WidgetComponent/KGRedDotComponent.h"

#include "Blueprint/UserWidget.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Components/ContentWidget.h"
#include "Components/Widget.h"
#include "Engine/AssetManager.h"
#include "Slate/Components/SKGRedDot.h"
#include "Components/PanelWidget.h"
#include "Components/Overlay.h"
#include "Components/OverlaySlot.h"
#include "Engine/Engine.h"
#include "Framework/Application/SlateApplication.h"
#include "UMG/Components/KGRedDot.h"


void IRedDotCounterInterface::SetCount(int32 InCount)
{
	Execute_OnSetCount(Cast<UObject>(this), InCount);
}


UKGRedDotComponent::UKGRedDotComponent(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	ColorAndOpacity = FLinearColor::White;
	ForegroundColor = FLinearColor::White;
}

void UKGRedDotComponent::SetVisibility(bool bVisible)
{
	if (bVisible != bIsVisible)
	{
		bIsVisible = bVisible;

		if (bIsVisible)
		{
			BuildRedDot();
		}

		if (RedDotWidget)
		{
			RedDotWidget->SetVisibility(bVisible ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
		}
	}
}

void UKGRedDotComponent::SetColorAndOpacity(const FLinearColor& InColorAndOpacity)
{
	if (RedDotWidget)
	{
		RedDotWidget->SetColorAndOpacity(InColorAndOpacity);
	}
}

void UKGRedDotComponent::SetForegroundColor(const FLinearColor& InColor)
{
	if (RedDotWidget)
	{
		RedDotWidget->SetForegroundColor(InColor);
	}
}

void UKGRedDotComponent::SetCount(int32 Count)
{
	if (Count != Counter)
	{
		Counter = Count;
		InternalSetCount(Count);
	}
}

void UKGRedDotComponent::SetRedDotClassFromString(const FString& RedDotClassPath)
{
	if (RedDotClassPath.IsEmpty())
	{
		return;
	}
	FSoftClassPath NewClassPath(RedDotClassPath);
	if (!NewClassPath.IsValid())
	{
		UE_LOG(LogTemp, Warning, TEXT("Invalid RedDot class path: %s"), *RedDotClassPath);
		return;
	}
	if (RedDotClass != NewClassPath)
	{
		RedDotClass = NewClassPath;
		if (RedDotWidget)
		{
			RemoveRedDot(true);
			if (bIsVisible)
			{
				BuildRedDot();
			}
		}
	}
}

void UKGRedDotComponent::SynchronizeProperties()
{
	Super::SynchronizeProperties();
	if (RedDotWidget)
	{
		RedDotWidget->SetContentScale(ContentScale);
		RedDotWidget->SetAlignment(Alignment);
		RedDotWidget->SetOffset(Offset);
		RedDotWidget->SetAnchors(Anchors);
		
		bool bVisible = bIsVisible;
#if WITH_EDITORONLY_DATA
		bVisible = bVisible || bShowRedDotInPreview;
#endif
		
		RedDotWidget->SetVisibility(bVisible ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
	}
}

void UKGRedDotComponent::OnSlatePostTick(float InDaltaTime)
{
	if (bDeferredCreateRedDont)
	{
		BuildRedDot();
		bDeferredCreateRedDont = false;
	}
}

void UKGRedDotComponent::OnWidgetRebuilt()
{
	Super::OnWidgetRebuilt();

	if (!HasAnyFlags(RF_ClassDefaultObject|RF_ArchetypeObject))
	{
		DelegateHandleOnSlatePostTick = FSlateApplication::Get().OnPostTick().AddUObject(this, &UKGRedDotComponent::OnSlatePostTick);
	}
	
	if (bIsVisible
#if WITH_EDITORONLY_DATA
		|| (GetWidget() && GetWidget()->IsDesignTime() && bShowRedDotInPreview)
#endif
	)
	{
		bDeferredCreateRedDont = true;
	}
}

void UKGRedDotComponent::ReleaseSlateResources(bool bReleaseChildren)
{
    if (OverlayWidget.IsValid())
    {
        if (RedDotWidget)
        {
            OverlayWidget->RemoveSlot(RedDotWidget->TakeWidget());
            RedDotWidget->ReleaseSlateResources(bReleaseChildren);
            RedDotWidget = nullptr;
        }
    }
    
	if (DelegateHandleOnSlatePostTick.IsValid())
	{
		if (FSlateApplication::IsInitialized())
		{
			FSlateApplication::Get().OnPostTick().Remove(DelegateHandleOnSlatePostTick);
		}

		DelegateHandleOnSlatePostTick.Reset();
	}
	
	Super::ReleaseSlateResources(bReleaseChildren);
    OverlayWidget.Reset();
}

#if WITH_EDITOR
void UKGRedDotComponent::PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);

	static const FName NAME_ShowRedDotInPreview = GET_MEMBER_NAME_CHECKED(ThisClass, bShowRedDotInPreview);

	auto IsProperty = [](FPropertyChangedChainEvent& PropertyChangedChainEvent, const FName& PropertyName)-> bool
	{
		if (PropertyChangedChainEvent.Property->GetName() == PropertyName)
		{
			return true;
		}

		if (PropertyChangedChainEvent.PropertyChain.GetActiveMemberNode())
		{
			auto* Property = PropertyChangedChainEvent.PropertyChain.GetActiveMemberNode()->GetValue();
			if (Property && Property->GetName() == PropertyName)
			{
				return true;
			}
		}
		return false;
	};
	
	const FName PropertyName = PropertyChangedEvent.Property->GetFName();
	if (PropertyName == NAME_ShowRedDotInPreview)
	{
		if (GetWidget() && GetWidget()->IsDesignTime())
		{
			if (bShowRedDotInPreview)
			{
				if (RedDotWidget)
				{
					RedDotWidget->SetVisibility(ESlateVisibility::HitTestInvisible);
					InternalSetCount(PreviewCount);
				}
				else
				{
					BuildRedDot();
				}
			}
			else
			{
				RemoveRedDot(false);
			}
		}
	}
	else if (IsProperty(PropertyChangedEvent, GET_MEMBER_NAME_CHECKED(UKGRedDotComponent, PreviewCount)))
	{
		InternalSetCount(PreviewCount);
	}
	else if (IsProperty(PropertyChangedEvent, GET_MEMBER_NAME_CHECKED(UKGRedDotComponent, Anchors)))
	{
		if (RedDotWidget)
		{
			RedDotWidget->SetAnchors(Anchors);
		}
	}
	else if (IsProperty(PropertyChangedEvent, GET_MEMBER_NAME_CHECKED(UKGRedDotComponent, Offset)))
	{
		if (RedDotWidget)
		{
			RedDotWidget->SetOffset(Offset);
		}
	}
	else if (IsProperty(PropertyChangedEvent, GET_MEMBER_NAME_CHECKED(UKGRedDotComponent, Alignment)))
	{
		if (RedDotWidget)
		{
			RedDotWidget->SetAlignment(Alignment);
		}
	}
	else if (IsProperty(PropertyChangedEvent, GET_MEMBER_NAME_CHECKED(UKGRedDotComponent, ColorAndOpacity)))
	{
		if (RedDotWidget)
		{
			RedDotWidget->SetColorAndOpacity(ColorAndOpacity);
		}
	}
	else if (IsProperty(PropertyChangedEvent, GET_MEMBER_NAME_CHECKED(UKGRedDotComponent, ForegroundColor)))
	{
		if (RedDotWidget)
		{
			RedDotWidget->SetForegroundColor(ColorAndOpacity);
		}
	}
	else if (IsProperty(PropertyChangedEvent, GET_MEMBER_NAME_CHECKED(UKGRedDotComponent, ContentScale)))
	{
		if (RedDotWidget)
		{
			RedDotWidget->SetContentScale(ContentScale);
		}
	}
}

#endif


void UKGRedDotComponent::OnFieldValueChanged(UObject* Object, UE::FieldNotification::FFieldId FieldId)
{
	if (!RedDotWidget)
	{
		return;
	}
	if (!bIsVisible)
	{
		return;
	}
	if (Object && Object == GetWidget())
	{
		if (FieldId == UWidget::FFieldNotificationClassDescriptor::Visibility)
		{
			RedDotWidget->SetVisibility(GetWidget()->GetVisibility());		
		}
		else if (FieldId == UWidget::FFieldNotificationClassDescriptor::bIsEnabled)
		{
			RedDotWidget->SetIsEnabled(GetWidget()->GetIsEnabled());
		}
	}
}

void UKGRedDotComponent::BuildRedDot()
{
	if (RedDotWidget ||!GetWidget() || !GetWidget()->IsValidLowLevel())
	{
		return;
	}

	RedDotInstance = Instance();
	if (!RedDotInstance)
	{
		RequestAsyncLoad(RedDotClass);
		return;
	}

	RedDotWidget = NewObject<UKGRedDot>(GetWidget(), UKGRedDot::StaticClass());
	if (RedDotWidget)
	{
		RedDotWidget->SetOwnerWidget(GetWidget());
		RedDotWidget->SetContent(RedDotInstance);
		RedDotWidget->SetAnchors(Anchors);
		RedDotWidget->SetOffset(Offset);
		RedDotWidget->SetAlignment(Alignment);
		RedDotWidget->SetContentScale(ContentScale);
		RedDotWidget->SetColorAndOpacity(ColorAndOpacity);
		RedDotWidget->SetForegroundColor(ForegroundColor);
	}
	
	if (GetWidget() )
	{
		using FFieldValueChangedDelegate = INotifyFieldValueChanged::FFieldValueChangedDelegate;
		GetWidget()->AddFieldValueChangedDelegate(UWidget::FFieldNotificationClassDescriptor::Visibility, FFieldValueChangedDelegate::CreateUObject(this, &UKGRedDotComponent::OnFieldValueChanged));

		GetWidget()->AddFieldValueChangedDelegate(UWidget::FFieldNotificationClassDescriptor::bIsEnabled, FFieldValueChangedDelegate::CreateUObject(this, &UKGRedDotComponent::OnFieldValueChanged));
		
		TSharedPtr<SWidget> SlateWidget = GetWidget()->GetCachedWidget();
		if (SlateWidget.IsValid())
		{
			TSharedPtr<SWidget> ParentWidget = SlateWidget->GetParentWidget();
			if (ParentWidget.IsValid())
			{
				if (FChildren* Children = ParentWidget->GetChildren())
				{
					FSlotBase* Slot = nullptr;
					for (int32 Idx = 0; Idx < Children->Num(); ++Idx)
					{
						if (Children->GetChildAt(Idx) == SlateWidget)
						{
							Slot = const_cast<FSlotBase*>(&Children->GetSlotAt(Idx));
							break;
						}
					}

					if (Slot)
					{
						SAssignNew(OverlayWidget, SOverlay)	
							+ SOverlay::Slot()
							.Padding(0)
							.HAlign(HAlign_Fill)
							.VAlign(VAlign_Fill)
							[
								SlateWidget.ToSharedRef()
							]
							+ SOverlay::Slot()
							.Padding(0)
							.HAlign(HAlign_Fill)
							.VAlign(VAlign_Fill)
							[
								RedDotWidget->TakeWidget()
							];
						Slot->AttachWidget(OverlayWidget.ToSharedRef());

						// ParentWidget->MarkPrepassAsDirty();
						// ParentWidget->SlatePrepass();
						ParentWidget->Invalidate(EInvalidateWidgetReason::LayoutAndVolatility);
					}
				}
			}
		}

#if WITH_EDITOR
		if ((GetWidget() && GetWidget()->IsDesignTime() && bShowRedDotInPreview))
		{
			InternalSetCount(PreviewCount);
		}
#endif
		
	}
}

void UKGRedDotComponent::RemoveRedDot(bool bDestroy)
{
	if (RedDotWidget)
	{
		if (bDestroy)
		{
			if (OverlayWidget.IsValid())
			{
				OverlayWidget->RemoveSlot(RedDotWidget->TakeWidget());
			}
			RedDotWidget = nullptr;
			RedDotInstance = nullptr;
		}
		else
		{
			RedDotWidget->SetVisibility(ESlateVisibility::Collapsed);
		}
	}
}

UUserWidget* UKGRedDotComponent::Instance() const
{
	if (UClass* Class = RedDotClass.ResolveClass())
	{
		UUserWidget* Instance = UWidgetBlueprintLibrary::Create(GetWidget(), Class, nullptr);
		return Instance;
	}
	return nullptr;
}

void UKGRedDotComponent::InternalSetCount(int32 InCount) const
{
	if (RedDotInstance && RedDotInstance->Implements<URedDotCounterInterface>())
	{
		IRedDotCounterInterface::Execute_OnSetCount(RedDotInstance, InCount);
	}
}

void UKGRedDotComponent::RequestAsyncLoad(const FSoftClassPath& SoftObject)
{
	CancelImageStreaming();
	if (SoftObject.ResolveObject())
	{
		BuildRedDot();
		return;  // No streaming was needed, complete immediately.
	}

	TWeakObjectPtr<UKGRedDotComponent> WeakThis(this);
	StreamingClassPath = SoftObject;
	StreamingHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(
		StreamingClassPath,
		[WeakThis, SoftObject]() {
			if (WeakThis.IsValid())
			{
				UKGRedDotComponent* StrongThis = WeakThis.Get();
				if (StrongThis->IsValidLowLevel() && StrongThis->StreamingClassPath == SoftObject)
				{
					StrongThis->BuildRedDot();
				}				
			}
		},
		FStreamableManager::AsyncLoadHighPriority);
}

void UKGRedDotComponent::CancelImageStreaming()
{
	if (StreamingHandle.IsValid())
	{
		StreamingHandle->CancelHandle();
		StreamingHandle.Reset();
	}

	StreamingClassPath.Reset();
}