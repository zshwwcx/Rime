#include "UMG/Tween/KGAlphaTween.h"
#include "UMG/Tween/KGEaseLerp.h"

void UKGAlphaTween::SetData(float From, float To)
{
	FromAlpha = From;
	ToAlpha = To;
}

void UKGAlphaTween::TweenUpdate(float InCurTime)
{
	CurAlpha = FromAlpha + (ToAlpha - FromAlpha) * UKGEaseLerp::Lerp(Ease, InCurTime, DurationTime);
	Widget->SetRenderOpacity(CurAlpha);
}
