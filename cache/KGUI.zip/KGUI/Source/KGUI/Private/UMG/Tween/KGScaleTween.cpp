#include "UMG/Tween/KGScaleTween.h"
#include "UMG/Tween/KGEaseLerp.h"

void UKGScaleTween::SetData(float From, float To)
{
	FromScale = From;
	ToScale = To;
}

void UKGScaleTween::TweenUpdate(float InCurTime)
{
	float LerpValue = UKGEaseLerp::Lerp(Ease, InCurTime, DurationTime);
	float Scale = FromScale + (ToScale - FromScale) * LerpValue;
	CurScale.X = Scale;
	CurScale.Y = Scale;

	Widget->SetRenderScale(CurScale);
}
