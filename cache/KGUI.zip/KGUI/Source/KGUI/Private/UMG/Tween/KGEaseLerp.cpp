#include "UMG/Tween/KGEaseLerp.h"

float UKGEaseLerp::Lerp(EaseType Type, float CurTime, float DurationTime)
{
	if (DurationTime == 0)
		return 1;
	
	switch (Type)
	{
		case EaseType::Linear:
			return CurTime/DurationTime;
		case EaseType::InSine:
			return -FMath::Cos(CurTime / DurationTime * PiOver2) + 1;
		case EaseType::OutSine:
			return FMath::Sin(CurTime / DurationTime * PiOver2);
		case EaseType::InOutSine:
			return -0.5f * (FMath::Cos(PI * CurTime / DurationTime) - 1);
		case EaseType::InQuad:
			CurTime /= DurationTime;
            return CurTime * CurTime;
        case EaseType::OutQuad:
        	CurTime /= DurationTime;
            return -(CurTime) * (CurTime - 2);
        case EaseType::InOutQuad:
            if ((CurTime /= DurationTime * 0.5f) < 1) return 0.5f * CurTime * CurTime;
			--CurTime;
            return -0.5f * ((CurTime) * (CurTime - 2) - 1);
        case EaseType::InCubic:
        	CurTime /= DurationTime;
            return (CurTime) * CurTime * CurTime;
        case EaseType::OutCubic:
        	CurTime = CurTime / DurationTime - 1;
            return ((CurTime) * CurTime * CurTime + 1);
        case EaseType::InOutCubic:
        	CurTime /= DurationTime * 0.5f;
            if ((CurTime) < 1) return 0.5f * CurTime * CurTime * CurTime;
			CurTime -= 2;
            return 0.5f * ((CurTime) * CurTime * CurTime + 2);
        case EaseType::InQuart:
        	CurTime /= DurationTime;
            return (CurTime) * CurTime * CurTime * CurTime;
        case EaseType::OutQuart:
        	CurTime = CurTime / DurationTime - 1;
            return -((CurTime) * CurTime * CurTime * CurTime - 1);
        case EaseType::InOutQuart:
        	CurTime /= DurationTime * 0.5f;
            if ((CurTime) < 1) return 0.5f * CurTime * CurTime * CurTime * CurTime;
			CurTime -= 2;
            return -0.5f * ((CurTime) * CurTime * CurTime * CurTime - 2);
        case EaseType::InQuint:
        	CurTime /= DurationTime;
            return (CurTime) * CurTime * CurTime * CurTime * CurTime;
        case EaseType::OutQuint:
        	CurTime = CurTime / DurationTime - 1;
            return ((CurTime) * CurTime * CurTime * CurTime * CurTime + 1);
        case EaseType::InOutQuint:
        	CurTime /= DurationTime * 0.5f;
            if ((CurTime) < 1) return 0.5f * CurTime * CurTime * CurTime * CurTime * CurTime;
			CurTime -= 2;
            return 0.5f * ((CurTime) * CurTime * CurTime * CurTime * CurTime + 2);
        case EaseType::InExpo:
            return (CurTime == 0) ? 0 : (float)FMath::Pow(2, 10 * (CurTime / DurationTime - 1));
        case EaseType::OutExpo:
            if (CurTime == DurationTime) return 1;
            return (-(float)FMath::Pow(2, -10 * CurTime / DurationTime) + 1);
        case EaseType::InOutExpo:
            if (CurTime == 0) return 0;
            if (CurTime == DurationTime) return 1;
			CurTime /= DurationTime;
            if ((CurTime * 0.5f) < 1) return 0.5f * (float)FMath::Pow(2, 10 * (CurTime - 1));
            return 0.5f * (-(float)FMath::Pow(2, -10 * --CurTime) + 2);
        case EaseType::InCirc:
        	CurTime /= DurationTime;
            return -((float)FMath::Sqrt(1 - (CurTime) * CurTime) - 1);
        case EaseType::OutCirc:
        	CurTime = CurTime / DurationTime - 1;
            return (float)FMath::Sqrt(1 - (CurTime) * CurTime);
        case EaseType::InOutCirc:
        	CurTime /= DurationTime * 0.5f;
            if ((CurTime) < 1) return -0.5f * ((float)FMath::Sqrt(1 - CurTime * CurTime) - 1);
			CurTime -= 2;
            return 0.5f * ((float)FMath::Sqrt(1 - (CurTime) * CurTime) + 1);
		default: ;
			return CurTime/DurationTime;
	}
}




            

