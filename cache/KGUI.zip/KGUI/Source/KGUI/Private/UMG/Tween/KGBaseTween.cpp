#include "UMG/Tween/KGBaseTween.h"

void UKGBaseTween::OnInit()
{
}

void UKGBaseTween::OnRelease()
{
	Widget = nullptr;
}

void UKGBaseTween::InitWidget()
{
	Widget = GetWidget();
}

void UKGBaseTween::Play()
{
	if (IsPlaying)
	{
		return;
	}

	InitWidget();
	SetTickEnable(true);
	IsPlaying = true;
	if (LoopTimes <= 0)
	{
		LoopTimes = 1;
	}
}

void UKGBaseTween::Stop()
{
	if (!IsPlaying)
	{
		return;
	}

	SetTickEnable(false);
	IsPlaying = false;
	CurTime = 0;
	LoopTimes = 0;
	ExecuteCallback();
}

void UKGBaseTween::Pause()
{
	SetTickEnable(false);
	IsPlaying = false;
}

void UKGBaseTween::Reset()
{
	CurTime = 0;
	InitWidget();
	TweenUpdate(0);
}

#if WITH_EDITOR
void UKGBaseTween::PlayEditor()
{
	Play();
}
#endif

void UKGBaseTween::SetEaseType(EaseType InType)
{
	Ease = InType;
}

void UKGBaseTween::SetLoopTime(int InLoopTimes)
{
	LoopTimes = InLoopTimes;
}

void UKGBaseTween::SetDurationTime(float InDuration)
{
	DurationTime = InDuration;
}


void UKGBaseTween::PlayFinish()
{
	if (!IsPlaying)
	{
		return;
	}

	CurTime = 0;
	if (LoopTimes > 1)
	{
		LoopTimes -= 1;
		return;
	}

	if (LoopTimes == -1)
	{
		return;
	}

	Stop();
}

void UKGBaseTween::ExecuteCallback()
{
	if (OnTweenFinishEvent.IsBound())
	{
		OnTweenFinishEvent.Execute();
	}
}

void UKGBaseTween::Tick(float DeltaTime)
{
	if (!IsPlaying)
	{
		return;
	}

	if (!Widget.IsValid())
	{
		return;
	}

	CurTime += DeltaTime;
	if (CurTime >= DurationTime)
	{
		CurTime = DurationTime;
		TweenUpdate(CurTime);
		PlayFinish();
		return;
	}
	
	TweenUpdate(CurTime);
}

void UKGBaseTween::TweenUpdate(float InCurTime)
{
}
