#include "UMG/Tween/KGPositionTween.h"
#include "Components/Widget.h"
#include "UMG/Tween/KGEaseLerp.h"

void UKGPositionTween::SetData(FVector2D InFrom, FVector2D InTo)
{
	From = InFrom;
	To = InTo;
}

void UKGPositionTween::TweenUpdate(float InCurTime)
{
	float LerpValue =UKGEaseLerp::Lerp(Ease, InCurTime, DurationTime);
	CurPos.X = From.X + (To.X- From.X) * LerpValue;
	CurPos.Y = From.Y + (To.Y - From.Y) * LerpValue;
	Widget->SetRenderTranslation(CurPos);
}
