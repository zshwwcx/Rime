#include "UMG/Tween/KGAngleTween.h"
#include "UMG/Tween/KGEaseLerp.h"

void UKGAngleTween::SetData(float From, float To)
{
	FromAngle = From;
	ToAngle = To;
}

void UKGAngleTween::TweenUpdate(float InCurTime)
{
	CurAngle = FromAngle + (ToAngle - FromAngle) * UKGEaseLerp::Lerp(Ease, InCurTime, DurationTime);
	Widget->SetRenderTransformAngle(CurAngle);
}
