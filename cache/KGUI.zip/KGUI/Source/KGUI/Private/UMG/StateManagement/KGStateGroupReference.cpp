#include "UMG/StateManagement/KGStateGroupReference.h"

#include "UMG/StateManagement/KGStateGroup.h"
#include "UMG/StateManagement/KGStateManagementUtility.h"

FKGStateGroupReference::FKGStateGroupReference()
	: Source(EKGStateGroupSource::Empty)
{
}

bool FKGStateGroupReference::IsReferenceOf(const FKGStateGroup& StateGroup) const
{
	return
		this->Name == StateGroup.Name &&
		this->GetWidget() == StateGroup.GetWidget();
}

bool FKGStateGroupReference::IsEmpty() const
{
	return Source == EKGStateGroupSource::Empty;
}

void FKGStateGroupReference::Initialize(UWidget* Self, UUserWidget* Owner)
{
	switch (Source)
	{
	case EKGStateGroupSource::Self:
		SetWidgetInternal(Self);
		break;
	case EKGStateGroupSource::Colleague:
		SetWidgetInternal(Colleague);
		break;
	case EKGStateGroupSource::Owner:
		SetWidgetInternal(Owner);
		break;
	}
}

UWidget* FKGStateGroupReference::GetWidget() const
{
	switch (Source)
	{
	case EKGStateGroupSource::Colleague:
		return Colleague;
	}
	return Widget.Get();
}

void FKGStateGroupReference::SetWidgetInternal(UWidget* InWidget)
{
	if (Source == EKGStateGroupSource::Colleague)
	{
		Colleague = InWidget;
		Widget = nullptr;
	}
	else
	{
		Widget = InWidget;
		Colleague = nullptr;
	}
	
}

FKGStateGroupReference FKGStateGroupReference::CreateInternal(UWidget* Source, UWidget* Target, FString StateGroupName)
{
	FKGStateGroupReference StateGroupReference;
	if (Source == Target)
	{
		StateGroupReference.Source = EKGStateGroupSource::Self;
	}
	else if (Source == FKGStateManagementUtility::GetOwnerUserWidget(Target))
	{
		StateGroupReference.Source = EKGStateGroupSource::Owner;
	}
	else
	{
		StateGroupReference.Source = EKGStateGroupSource::Colleague;
	}
	StateGroupReference.SetWidgetInternal(Source);
	StateGroupReference.Name = StateGroupName;
	return MoveTemp(StateGroupReference);
}

FKGStateGroupReference FKGStateGroupReference::GetEmpty()
{
	return FKGStateGroupReference();
}
