#include "UMG/StateManagement/KGScriptableStateGroup.h"

FKGScriptableStateGroupContext::FKGScriptableStateGroupContext()
	: Widget(NULL)
	, ScriptableStateGroup(NULL)
{
}
