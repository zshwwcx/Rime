#include "UMG/StateManagement/KGStateControllerSnapshot.h"

#include "UMG/StateManagement/KGStateManagement.h"

void FKGStateControllerSnapshot::ResetStateGroupCurrentIndices()
{
	for (auto& StateGroup : StateGroups)
	{
		StateGroup.Current = 0;
	}
}

void FKGStateControllerSnapshot::SynchronizeStateGroupCurrentIndices(FKGStateControllerSnapshot& TargetStateControllerSnapshot)
{
	TMap<FKGStateGroupReference, int> Indices;
	auto& TargetStateController = TargetStateControllerSnapshot.StateController;
	for (auto& StateGroup : StateGroups)
	{
		Indices.Add(StateController.CreateStateGroupReference(StateGroup), StateGroup.Current);
	}
	for (auto& StateGroup : TargetStateControllerSnapshot.StateGroups)
	{
		int* Found = Indices.Find(TargetStateController.CreateStateGroupReference(StateGroup));
		if (Found == NULL)
		{
			continue;
		}
		StateGroup.Current = *Found;
	}
}

int FKGStateControllerSnapshot::GetStraightenIndex()
{
	if (StateGroups.Num() == 0)
	{
		return -1;
	}
	int Index = 0;
	for (auto& StateGroup : StateGroups)
	{
		if (StateGroup.Current < 0 || StateGroup.Current >= StateGroup.States.Num())
		{
			return -1;
		}
		Index *= StateGroup.States.Num();
		Index += StateGroup.Current;
	}
	return Index;
}

int FKGStateControllerSnapshot::GetStraightenCount()
{
	if (StateGroups.Num() == 0)
	{
		return 0;
	}
	int Result = 1;
	for (auto& StateGroup : StateGroups)
	{
		Result *= StateGroup.States.Num();
	}
	return Result;
}

bool FKGStateControllerSnapshot::Increase()
{
	int StateGroupCount = StateGroups.Num();
	if (StateGroupCount == 0)
	{
		return false;
	}
	StateGroups[0].Current += 1;
	for (int i = 0; i < StateGroupCount; i++)
	{
		auto& StateGroup = StateGroups[i];
		int StateCount = StateGroup.States.Num();
		if (StateGroup.Current >= StateCount)
		{
			if (i + 1 >= StateGroupCount)
			{
				return false;
			}
			int Current = StateGroup.Current;
			StateGroup.Current = Current % StateCount;
			StateGroups[i + 1].Current += (int)(Current / StateCount);
		}
	}
	return true;
}

FKGStateControllerSnapshot FKGStateControllerSnapshot::Create(const FKGStateController& StateController)
{
	FKGStateControllerSnapshot Snapshot;
	auto ControllingStateGroupReferences = StateController.Widget->GetComponent<UKGStateManagement>()->GetControllingStateGroupReferences();
	for (auto& Reference : StateController.StateGroupReferences)
	{
		int Found = ControllingStateGroupReferences.Find(Reference);
		check(Found != INDEX_NONE);
		UKGStateManagement* StateManagement = Reference.GetWidget()->GetComponent<UKGStateManagement>();
		FKGStateGroup StateGroup = *StateManagement->FindStateGroup(Reference.Name);
		check(StateGroup.Widget == Reference.GetWidget());
		StateManagement->GetStateGroupCurrentValue(StateGroup.Name, StateGroup.Current);
		Snapshot.StateGroups.Add(StateGroup);
	}

	Snapshot.StateController = StateController;
	return MoveTemp(Snapshot);
}
