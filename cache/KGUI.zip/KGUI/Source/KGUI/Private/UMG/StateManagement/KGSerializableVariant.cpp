#include "UMG/StateManagement/KGSerializableVariant.h"

#include "KGUI.h"
#include "UMG/StateManagement/KGStateManagement.h"
#include "UMG/StateManagement/KGStateManagementCustomVersion.h"

FKGSerializableVariant::FKGSerializableVariant()
{
}

FKGSerializableVariant::FKGSerializableVariant(const FKGSerializableVariant& Other)
{
	Construct(Other.PropertyPath_);
	Copy(GetData<void>(), Other.GetData<void>());
}

FKGSerializableVariant::~FKGSerializableVariant()
{
	Destruct();
}

FKGSerializableVariant& FKGSerializableVariant::operator=(const FKGSerializableVariant& Other)
{
	Destruct();
	Construct(Other.PropertyPath_);
	Copy(GetData<void>(), Other.GetData<void>());
	return *this;
}

void FKGSerializableVariant::Copy(void* Dest, void const* Src)
{
	FProperty* Property = PropertyPath_.Get();
	if (Property == NULL)
	{
		return;
	}
	Property->CopyCompleteValue(Dest, Src);

	if (Property->IsA<FBoolProperty>())
	{
		FBoolProperty* BoolProperty = CastField<FBoolProperty>(Property);
		uint8* ByteValue = (uint8*)GetData<void>();
		uint8 FieldMask = BoolProperty->GetFieldMask();
		*ByteValue = (*ByteValue & FieldMask) ? 0xFF : 0;
	}
}

bool FKGSerializableVariant::Collect(UObject* Object, const TFieldPath<FProperty>& InPropertyPath)
{
	if (InPropertyPath.Get() == NULL)
	{
		return false;
	}
	Reinitialize(InPropertyPath);

	// QUESTION: 不能用CallGetter，因为这时候SWidget的内容还不是最新的…
	// PropertyPath_.Get()->CallGetter(Object, GetData<void>());

	// 另外，部分需要考虑的属性并没有定义Getter，只有Setter。这种情形其实也是可以作为状态控制属性的。

	// 需要直接从UPROPERTY字段的内存地址上拷贝过来
	FProperty* Property = PropertyPath_.Get();
	void* Ptr = Property->ContainerPtrToValuePtr<void>(Object);
	Copy(GetData<void>(), Ptr);
	return true;
}

bool FKGSerializableVariant::Apply(UObject* Object, const TFieldPath<FProperty>& InPropertyPath)
{
	check(InPropertyPath == PropertyPath_);
	auto StateControllerPropertyCustomization = GetStateControllerPropertyCustomization(InPropertyPath);
	if (StateControllerPropertyCustomization != nullptr)
	{
		auto Setter = StateControllerPropertyCustomization->Setter;
		check(Setter.IsBound());
		Setter.ExecuteIfBound(Object, GetData<void>());
	}
	else
	{
		InPropertyPath.Get()->CallSetter(Object, GetData<void>());
	}
	return true;
}

void FKGSerializableVariant::Reinitialize(const TFieldPath<FProperty>& InPropertyPath)
{
	auto Tempory = InPropertyPath;
	Destruct();
	Construct(Tempory);
}

void FKGSerializableVariant::Construct(const TFieldPath<FProperty>& InPropertyPath)
{
	check(PropertyPath_.Get() == NULL);
	PropertyPath_ = InPropertyPath;
	auto Property = PropertyPath_.Get();
	if (Property == NULL)
	{
		check(Data_.Num() == 0);
		return;
	}
	int Size = Property->GetSize();
	int Alignment = Property->GetMinAlignment();
	Size = (int)(((uint64)Size + Alignment - 1) & ~(Alignment - 1));
	Data_.SetNum(Size);
	if (!Property->HasAnyPropertyFlags(CPF_ZeroConstructor))
	{
		Property->InitializeValue(GetData<void*>());
	}
}

void FKGSerializableVariant::Destruct()
{
	FProperty* Property = PropertyPath_.Get();
	if (PropertyPath_.Get() == NULL)
	{
		check(Data_.Num() == 0);
		return;
	}
	auto Ptr = GetData<void*>();
	if (Ptr != nullptr)
	{
		Property->DestroyValue(Ptr);
	}
	Data_.Empty();
	PropertyPath_.Reset();
}

void FKGSerializableVariant::PreSave(FObjectPreSaveContext SaveContext)
{
	TryNormalizeBitwiseBooleanProperty();
}

void FKGSerializableVariant::PostLoad()
{
	TryNormalizeBitwiseBooleanProperty();
}

bool FKGSerializableVariant::Serialize(FArchive& Ar)
{
	Ar.UsingCustomVersion(FKGStateManagementCustomVersion::GUID);
	if (Ar.IsLoading())
	{
		if (Ar.CustomVer(FKGStateManagementCustomVersion::GUID) < FKGStateManagementCustomVersion::CustomSerializableVariantSerialization)
		{
			return false;
		}
	}
	TFieldPath<FProperty> Tempory = this->PropertyPath_;
	Ar << Tempory;
	FProperty* Property = Tempory.Get();
	if (Ar.IsLoading())
	{
		this->Reinitialize(Tempory);
	}
	if (Property != nullptr)
	{
		Property->SerializeItem(FStructuredArchiveFromArchive(Ar).GetSlot(), GetData<void*>());
	}
	return true;
}

void FKGSerializableVariant::PostSerialize(const FArchive& Ar)
{
	if (Ar.IsLoading())
	{
		if (Ar.CustomVer(FKGStateManagementCustomVersion::GUID) < FKGStateManagementCustomVersion::CustomSerializableVariantSerialization)
		{
			this->PropertyPath_ = this->PropertyPath;
			this->PropertyPath.Reset();
			auto Property = this->PropertyPath_.Get();
			if (Property != nullptr)
			{
				if (Property->IsA<FByteProperty>() ||
					Property->IsA<FInt8Property>() ||
					Property->IsA<FInt16Property>() ||
					Property->IsA<FIntProperty>() ||
					Property->IsA<FInt64Property>() ||
					Property->IsA<FUInt16Property>() ||
					Property->IsA<FUInt32Property>() ||
					Property->IsA<FUInt64Property>() ||
					Property->IsA<FFloatProperty>() ||
					Property->IsA<FDoubleProperty>() ||
					Property->IsA<FBoolProperty>() ||
					Property->IsA<FEnumProperty>())
				{
					this->Data_ = this->Data;
				}
				else
				{
					bool bReverted = false;
					if (Property->IsA<FStructProperty>())
					{
						auto StructProperty = CastField<FStructProperty>(Property);
						if (StructProperty->Struct == FSlateBrush::StaticStruct())
						{
							bReverted = true;
						}
					}
					if (Property->IsA<FTextProperty>())
					{
						bReverted = true;
					}
					if (!bReverted)
					{
						this->Data_ = this->Data;
					}
					else
					{
						// 忽略
						auto Tempory = this->PropertyPath_;
						Reinitialize(Tempory);

						UE_LOG(LogTemp, Warning, TEXT("State Management Controller Data `%s` Property Has Been Reverted."), *Property->GetPathName());
					}
				}
			}
			this->Data.Reset();
		}
	}
}

bool FKGSerializableVariant::ExportTextItem(FString& ValueStr, FKGSerializableVariant const& DefaultValue, UObject* Parent, int32 PortFlags, UObject* ExportRootScope) const
{
	ValueStr += "(";

	ValueStr += TEXT("\"");
	ValueStr += this->PropertyPath_.ToString();
	ValueStr += TEXT("\"");

	ValueStr += ",";

	auto Property = this->PropertyPath_.Get();
	auto Ptr = this->GetData<void>();
	if (Property != nullptr && Ptr != nullptr)
	{
		Property->ExportTextItem_Direct(ValueStr, Ptr, nullptr, Parent, PortFlags, ExportRootScope);
	}

	ValueStr += ")";

	return true;
}

bool FKGSerializableVariant::ImportTextItem(const TCHAR*& Buffer, int32 PortFlags, UObject* Parent, FOutputDevice* ErrorText)
{
	const TCHAR* BufferIt = Buffer;

	if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR('(')) return false;

	if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR('\"')) return false;

	const TCHAR* PathNameStartPtr = BufferIt;
	while (*BufferIt != TCHAR('\"'))
	{
		BufferIt++;
	}
	const TCHAR* PathNameEndPtr = BufferIt;
	FString PathName(PathNameEndPtr - PathNameStartPtr, PathNameStartPtr);
	this->PropertyPath_.Generate(*PathName);
	if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR('\"')) return false;

	if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR(',')) return false;

	auto Property = this->PropertyPath_.Get();
	Reinitialize(this->PropertyPath_);
	if (Property != nullptr)
	{
		if (!Property->ImportText_Direct(BufferIt, this->GetData<void>(), nullptr, PortFlags, ErrorText))
		{
			this->PropertyPath_.Reset();
			Reinitialize(this->PropertyPath_);
			return false;
		}
	}

	if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR(')')) return false;

	return true;
}

void FKGSerializableVariant::TryNormalizeBitwiseBooleanProperty()
{
	FProperty* Property = this->PropertyPath_.Get();
	if (Property == NULL)
	{
		return;
	}
	if (Property->IsA<FBoolProperty>())
	{
		FBoolProperty* BoolProperty = CastField<FBoolProperty>(Property);
		uint8* ByteValue = (uint8*)this->GetData<void*>();
		uint8 FieldMask = BoolProperty->GetFieldMask();
		*ByteValue = (*ByteValue & FieldMask) ? 0xFF : 0;
	}
}

TSharedPtr<FKGStateControllerPropertyCustomization> FKGSerializableVariant::GetStateControllerPropertyCustomization(const TFieldPath<FProperty>& InPropertyPath)
{
	return FKGUIModule::Get().GetStateControllerPropertyCustomization(InPropertyPath);
}
