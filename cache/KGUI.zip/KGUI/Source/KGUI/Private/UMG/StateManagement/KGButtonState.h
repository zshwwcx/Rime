#pragma once

#include "CoreMinimal.h"

#include "UMG/StateManagement/KGScriptableStateGroup.h"

class FKGButtonStateContext : public FKGScriptableStateGroupContext
{
public:
	FDelegateHandle DelegateHandle;
};

class FKGButtonState : public TKGScriptableStateGroup<UButton, FKGButtonStateContext>
{
	DECLARE_STATE_GROUP(FKGButtonState, Normal, Pressed, Hovered, Disabled)

public:
	virtual void Bind(UButton* Button, TSharedPtr<FKGButtonStateContext> Context) override
	{
		//FScriptDelegate ScriptDelegate;
		//ScriptDelegate.BindUFunction()
		//Button->OnClicked.Add(ScriptDelegate);

		//Button->OnClicked.Broadcast();

		check(!Context->DelegateHandle.IsValid());

		// `UButton`的`OnClicked`、`OnPressed`、`OnReleased`、`OnHovered`和`OnUnhovered`中可以用以监听相应的事件。
		// 但是，很难在C++上以一种不消耗UObject数量的方式做到这一点。不过对于按钮状态，可以使用下面的`RegisterPostStateListener`
		// 函数进行监听。
		// TODO: 但是比较优雅的方式，还是让`DynamicMulticastDelegate`能够绕过`UObject+FunctionName`进行纯C++注册。
		Context->DelegateHandle = Button->RegisterPostStateListener(
			UWidget::FOnWidgetStateBroadcast::FDelegate::CreateLambda(
				[WeakThis = StaticCastWeakPtr<FKGButtonState>(this->AsWeak()), Button](UWidget* Widget, const FWidgetStateBitfield& BitField)
				{
					if (auto This = WeakThis.Pin())
					{
						This->UpdateState(Button);
					}
				}
			),
			false
		);
	}

	virtual void Unbind(TSharedPtr<FKGButtonStateContext> Context) override
	{
		Context->AsWidget<UButton>()->UnregisterPostStateListener(Context->DelegateHandle);
		Context->DelegateHandle.Reset();
	}

	virtual int GetCurrent(UButton* Button) override
	{
		if (!Button->TakeWidget()->IsInteractable())                                     { return (int)FKGButtonState::EStates::Disabled; }
		else if (Button->IsPressed())                                                    { return (int)FKGButtonState::EStates::Pressed;  }
		else if (Button->IsHovered() && !FSlateApplication::Get().IsFakingTouchEvents()) { return (int)FKGButtonState::EStates::Hovered;  }
		else                                                                             { return (int)FKGButtonState::EStates::Normal;   }
	}
};