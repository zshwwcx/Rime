#include "UMG/StateManagement/KGStateManagementUtility.h"

#include "Components/Widget.h"
#include "Blueprint/WidgetTree.h"

UUserWidget* FKGStateManagementUtility::GetOwnerUserWidget(UWidget* Widget)
{
	auto MaybeWidgetTree = Widget->GetOuter();
	if (!MaybeWidgetTree->IsA<UWidgetTree>())
	{
		return NULL;
	}
	auto MaybeUserWidget = MaybeWidgetTree->GetOuter();
	UUserWidget* UserWidget = Cast<UUserWidget>(MaybeUserWidget);
	return UserWidget;
}