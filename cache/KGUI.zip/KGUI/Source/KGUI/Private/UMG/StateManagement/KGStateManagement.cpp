#include "UMG/StateManagement/KGStateManagement.h"

#include "UMG/Blueprint/KGUserWidget.h"
#include "UMG/StateManagement/KGScriptableStateGroup.h"

DEFINE_LOG_CATEGORY(LogStateManagement);

UKGStateManagement::FOnStateControllerApplied UKGStateManagement::OnStateControllerApplied;

void UKGStateManagement::OnWidgetRebuilt()
{
	UWidget* Self = this->GetWidget();
	UUserWidget* Owner = FKGStateManagementUtility::GetOwnerUserWidget(Self);
	for (auto& StateGroup : StateGroups)
	{
		StateGroup.Widget = Self;
		StateGroup.InitializeScriptableStateGroup();
	}
	for (auto& StateController : StateControllers)
	{
		StateController.Widget = Self;
		for (auto& StateGroupReference : StateController.StateGroupReferences)
		{
			StateGroupReference.Initialize(Self, Owner);
		}
	}
	for (auto& Pair : StateGroupCurrentValueOverrides)
	{
		int PreviousIndex;
		if (!GetStateGroupCurrentValue(Pair.Key, PreviousIndex, false))
		{
			continue;
		}
		if (PreviousIndex == Pair.Value)
		{
			continue;
		}
		ChangeState(Pair.Key, Pair.Value, true, true);
	}
	if (!this->GetWidget()->IsDesignTime())
	{
		for (auto& StateGroup : StateGroups)
		{
			if (StateGroup.ScriptableStateGroupContext == nullptr)
			{
				continue;
			}
			auto ScriptableStateGroupPinned = StateGroup.ScriptableStateGroupContext->ScriptableStateGroup.Pin();
			if (ScriptableStateGroupPinned)
			{
				ScriptableStateGroupPinned->__Internal_UpdateState(this->GetWidget(), true);
			}
		}
	}
}

void UKGStateManagement::OnBeginDestroy()
{
	for (auto& StateGroup : StateGroups)
	{
		StateGroup.UninitializeScriptableStateGroup();
	}
}

void UKGStateManagement::ApplyHierarchically(UWidget* Current, const FKGStateGroup& StateGroup, int Level)
{
	if (Current == NULL)
	{
		return;
	}
	UKGStateManagement* StateManagement = Current->GetComponent<UKGStateManagement>();
	if (StateManagement != NULL)
	{
		for (auto& StateController : StateManagement->StateControllers)
		{
			if (!StateController.ContainsStateGroup(StateController.CreateStateGroupReference(StateGroup)))
			{
				continue;
			}
			check(StateController.Widget == Current);
			if (!StateController.Apply())
			{
				auto* Property = StateController.PropertyPath.Get();
				UE_LOG(LogStateManagement, Error, TEXT("Apply property value failed, State Group: %s, Property Path: %s"), *StateGroup.Name, Property == NULL ? TEXT("Unset") : *Property->GetName());
			}
			else
			{
				OnStateControllerApplied.Broadcast(StateManagement, &StateController);
			}
		}
	}
	int NewLevel = Level + 1;
	UPanelWidget* Panel = dynamic_cast<UPanelWidget*>(Current);
	if (Panel != NULL)
	{
		int ChildrenCount = Panel->GetChildrenCount();
		for (int i = 0; i < ChildrenCount; i++)
		{
			UWidget* Child = Panel->GetChildAt(i);
			ApplyHierarchically(Child, StateGroup, NewLevel);
		}
		return;
	}
	if (Level == 0)
	{
		UUserWidget* UserWidget = dynamic_cast<UUserWidget*>(Current);
		if (UserWidget != NULL)
		{
			ApplyHierarchically(UserWidget->GetRootWidget(), StateGroup, NewLevel);
		}
	}
}

bool UKGStateManagement::ChangeState(const FString& Name, int Index, bool bForce)
{
	return ChangeState(Name, Index, false, bForce);
}

bool UKGStateManagement::ChangeState(const FString& Name, int Index, bool bUpdateOverrideAnyway, bool bForce)
{
	int PreviousIndex;
	if (!GetStateGroupCurrentValue(Name, PreviousIndex))
	{
		return false;
	}
	FKGStateGroup* Found = FindStateGroup(Name);
	if (Index < 0 || Index >= Found->States.Num())
	{
		return false;
	}
	if (PreviousIndex == Index && !bForce)
	{
		return false;
	}
	SetStateGroupCurrentValue(Name, Index, bUpdateOverrideAnyway);
	FKGStateGroup& StateGroup = *(FKGStateGroup*)Found;
	ApplyHierarchically(this->GetWidget(), StateGroup);
	return true;
}

#pragma region State Group

int UKGStateManagement::AddStateGroup(const FString& Name)
{
	StateGroups.Add(FKGStateGroup(this->GetWidget(), Name, 0));
	return StateGroups.Num() - 1;
}

bool UKGStateManagement::RemoveStateGroup(TArray<FKGStateGroup>::SizeType Index)
{
	if (Index < 0 || Index >= StateGroups.Num())
	{
		return false;
	}
	StateGroups.RemoveAt(Index);
	return true;
}

bool UKGStateManagement::RemoveStateGroup(const FString& Name)
{
	int Index = INDEX_NONE;
	for (int i = 0; i < StateGroups.Num(); i++)
	{
		if (StateGroups[i].Name == Name)
		{
			check(Index == INDEX_NONE);
			Index = i;
		}
	}
	if (Index == INDEX_NONE)
	{
		return false;
	}
	return RemoveStateGroup(Index);
}

FKGStateGroup* UKGStateManagement::FindStateGroup(const FString& Name)
{
	return StateGroups.FindByPredicate([Name](const FKGStateGroup& StateGroup) {
		return StateGroup.Name == Name;
	});
}

bool UKGStateManagement::GetStateGroupCurrentValue(const FString& Name, int& Current, bool bIncludeOverride)
{
	auto* StateGroup = FindStateGroup(Name);
	if (StateGroup == NULL)
	{
		return false;
	}
	int* Override = StateGroupCurrentValueOverrides.Find(Name);
	if (Override != NULL && bIncludeOverride)
	{
		Current = *Override;
	}
	else
	{
		Current = StateGroup->Current;
	}
	return true;
}

void UKGStateManagement::SetStateGroupCurrentValue(const FString& Name, int Current, bool bUpdateOverrideAnyway)
{
	auto* StateGroup = FindStateGroup(Name);
	if (StateGroup == NULL)
	{
		check(false);
		return;
	}
	if (bUpdateOverrideAnyway || StateGroupCurrentValueOverrides.Contains(Name))
	{
		StateGroupCurrentValueOverrides.FindOrAdd(Name) = Current;
	}
	else
	{
		StateGroup->Current = Current;
	}
}

int UKGStateManagement::GetStateGroupIndexByName(const FString& Name)
{
	return StateGroups.IndexOfByPredicate([Name](const FKGStateGroup& StateGroup) {
		return StateGroup.Name == Name;
	});
}

TArray<FKGStateGroupReference> UKGStateManagement::GetControllingStateGroupReferences()
{
	return GetControllingStateGroups<FKGStateGroupReference>([](UKGStateManagement* StateManagement, int Index) {
		auto& StateGroup = StateManagement->StateGroups[Index];
		return FKGStateGroupReference::CreateInternal(StateGroup.GetWidget(), StateManagement->GetWidget(), StateGroup.Name);
	});
}

#pragma endregion

#pragma region State Controller

int UKGStateManagement::AddStateController()
{
	StateControllers.Add(FKGStateController(this->GetWidget()));
	return StateControllers.Num() - 1;
}

bool UKGStateManagement::RemoveStateController(int Index)
{
	if (Index < 0 || Index >= StateControllers.Num())
	{
		return false;
	}
	StateControllers.RemoveAt(Index);
	return true;
}

#if WITH_EDITOR

bool UKGStateManagement::IsDeclarationReadOnly(UWidget* Widget)
{
	auto* WidgetClass = Widget->GetClass();
	auto* WidgetSuperClass = WidgetClass->GetSuperClass();
	return WidgetClass->IsChildOf(UUserWidget::StaticClass()) && (!Widget->HasAnyFlags(RF_ArchetypeObject | RF_ClassDefaultObject) || WidgetSuperClass->ClassGeneratedBy != NULL);
}

#endif

void UKGStateManagement::PreSave(FObjectPreSaveContext ObjectSaveContext)
{
#if WITH_EDITOR
	for (auto& StateController : StateControllers)
	{
		StateController.PreSave(ObjectSaveContext);
	}

	if (IsDeclarationReadOnly(this->GetWidget()))
	{
		auto GetTransientPropertyOverride = [](FName PropertyName) -> FPropertySaveOverride
		{
			FProperty* OverrideProperty = FindFProperty<FProperty>(UKGStateManagement::StaticClass(), PropertyName);
			check(OverrideProperty);
			FPropertySaveOverride PropOverride;
			PropOverride.PropertyPath = FFieldPath(OverrideProperty);
			PropOverride.bMarkTransient = true;
			return PropOverride;
		};
		FObjectSaveOverride ObjectSaveOverride;
		ObjectSaveOverride.PropOverrides.Add(GetTransientPropertyOverride(GET_MEMBER_NAME_CHECKED(UKGStateManagement, StateGroups)));
		ObjectSaveOverride.PropOverrides.Add(GetTransientPropertyOverride(GET_MEMBER_NAME_CHECKED(UKGStateManagement, StateControllers)));
		if (!ObjectSaveOverride.PropOverrides.IsEmpty())
		{
			ObjectSaveContext.AddSaveOverride(this, ObjectSaveOverride);
		}
		TSet<FString> Deprecateds;
		for (auto& Pair : StateGroupCurrentValueOverrides)
		{
			if (!FindStateGroup(Pair.Key))
			{
				Deprecateds.Add(Pair.Key);
			}
		}
		for (auto& Deprecated : Deprecateds)
		{
			StateGroupCurrentValueOverrides.Remove(Deprecated);
		}
	}
	else
	{
		StateGroupCurrentValueOverrides.Empty();
	}
#endif
	Super::PreSave(ObjectSaveContext);
}

void UKGStateManagement::PostLoad()
{
	Super::PostLoad();

	for (auto& StateController : StateControllers)
	{
		StateController.PostLoad();
	}
}

#pragma endregion
