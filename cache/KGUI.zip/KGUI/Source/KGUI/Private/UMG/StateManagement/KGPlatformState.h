#pragma once

#include "CoreMinimal.h"

#include "Platform/KGUIPlatformManager.h"
#include "UMG/StateManagement/KGScriptableStateGroup.h"

class FKGPlatformStateContext : public FKGScriptableStateGroupContext
{
public:
	FDelegateHandle DelegateHandle;
};

class FKGPlatformState : public TKGScriptableStateGroup<UUserWidget, FKGPlatformStateContext>
{
	DECLARE_STATE_GROUP(FKGPlatformState, Mobile, PC)

public:
	virtual void Bind(UUserWidget* UserWidget, TSharedPtr<FKGPlatformStateContext> Context) override
	{
		TWeakObjectPtr<UUserWidget> WeakUserWidget = UserWidget;
		FKGUIPlatformManager* UIPlatformManager = FKGUIPlatformManager::GetInstance();
		Context->DelegateHandle = UIPlatformManager->PlatformChanged.AddLambda([WeakUserWidget, WeakThis = StaticCastWeakPtr<FKGPlatformState>(AsWeak())](EKGUIPlatforms Platform) {
			auto UserWidget = WeakUserWidget.Get();
			if (UserWidget == nullptr)
			{
				return;
			}
			auto This = WeakThis.Pin();
			if (This != nullptr)
			{
				This->UpdateState(UserWidget);
			}
		});
	}

	virtual void Unbind(TSharedPtr<FKGPlatformStateContext> Context) override
	{
		FKGUIPlatformManager::GetInstance()->PlatformChanged.Remove(Context->DelegateHandle);
		Context->DelegateHandle.Reset();
	}

	virtual int GetCurrent(UUserWidget* UserWidget) override
	{
		return (int)FKGUIPlatformManager::GetInstance()->GetPlatform();
	}
};