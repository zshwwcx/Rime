#include "UMG/StateManagement/KGStateGroup.h"

#include "KGUI.h"
#include "UMG/StateManagement/KGScriptableStateGroup.h"

FKGStateGroup::FKGStateGroup()
	: FKGStateGroup(NULL)
{
}

FKGStateGroup::FKGStateGroup(TWeakObjectPtr<UWidget> InWidget)
	: Name()
	, Widget(InWidget)
	, ScriptableStateGroupContext(NULL)
{
	this->AddState();
	Current = 0;
	this->AddState();
}

FKGStateGroup::FKGStateGroup(TWeakObjectPtr<UWidget> InWidget, const FString& InName, int InCurrent)
	: FKGStateGroup(InWidget)
{
	this->Name = InName;
	this->Current = InCurrent;
}

TArray<FKGState>::SizeType FKGStateGroup::AddState()
{
	States.Add(FKGState());
	return States.Num() - 1;
}

bool FKGStateGroup::RemoveState(TArray<FKGState>::SizeType Index)
{
	if (Index < 0 || Index >= States.Num() || States.Num() <= 2)
	{
		return false;
	}
	States.RemoveAt(Index);
	return true;
}

UWidget* FKGStateGroup::GetWidget() const
{
	return Widget.Get();
}

void FKGStateGroup::InitializeScriptableStateGroup()
{
	TSharedPtr<IKGScriptableStateGroup> ScriptableStateGroup = FKGUIModule::Get().GetScriptableStateGroup(this->Widget->GetClass(), this->Name);
	if (ScriptableStateGroup == NULL)
	{
		return;
	}
	ScriptableStateGroupContext = ScriptableStateGroup->__Internal_Bind(this->Widget.Get());
}

void FKGStateGroup::UninitializeScriptableStateGroup()
{
	if (ScriptableStateGroupContext == NULL)
	{
		return;
	}
	auto ScriptableStateGroupPinned = ScriptableStateGroupContext->ScriptableStateGroup.Pin();
	if (ScriptableStateGroupPinned)
	{
		ScriptableStateGroupPinned->__Internal_Unbind(ScriptableStateGroupContext);
	}
	ScriptableStateGroupContext = NULL;
}

TSharedPtr<FKGScriptableStateGroupContext> FKGStateGroup::GetScriptableStateGroupContext()
{
	return ScriptableStateGroupContext;
}

bool FKGStateGroup::IsScriptableStateGroup()
{
	return ScriptableStateGroupContext != NULL;
}