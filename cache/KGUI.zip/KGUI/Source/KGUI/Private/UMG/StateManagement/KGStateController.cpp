#include "UMG/StateManagement/KGStateController.h"

#include "KGUI.h"
#include "UMG/StateManagement/KGStateControllerSnapshot.h"
#include "UMG/StateManagement/KGStateManagement.h"

FKGStateController::FKGStateController()
	: FKGStateController(NULL)
{
}

FKGStateController::FKGStateController(TWeakObjectPtr<UWidget> InWidget)
	: Widget(InWidget)
{
}

bool FKGStateController::ContainsStateGroup(const FKGStateGroupReference& Reference)
{
	if (StateGroupReferences.Find(Reference) == INDEX_NONE)
	{
		return false;
	}
	return true;
}

bool FKGStateController::AddStateGroup(const FKGStateGroupReference& Reference)
{
	if (StateGroupReferences.Find(Reference) != INDEX_NONE)
	{
		return false;
	}
	StateGroupReferences.Add(Reference);
	return true;
}

bool FKGStateController::RemoveStateGroup(const FKGStateGroupReference& Reference)
{
	if (!ContainsStateGroup(Reference))
	{
		return false;
	}
	StateGroupReferences.Remove(Reference);
	return true;
}

void FKGStateController::SetPropertyPath(const TFieldPath<FProperty>& InPropertyPath)
{
	this->PropertyPath = InPropertyPath;
	for (auto& PropertyValue : this->PropertyValues)
	{
		PropertyValue.Reinitialize(InPropertyPath);
	}
}

bool FKGStateController::ShouldCollect(FProperty* Property) const
{
	if (PropertyPath.Get() == Property)
	{
		return true;
	}
	auto Customization = FKGUIModule::Get().GetStateControllerPropertyCustomization(PropertyPath);
	if (Customization != nullptr)
	{
		if (Customization->WatchedPropertyPaths.Contains(Property))
		{
			return true;
		}
	}
	return false;
}

bool FKGStateController::Collect()
{
	FKGStateControllerSnapshot StateControllerSnapshot = FKGStateControllerSnapshot::Create(*this);
	int StraightenIndex = StateControllerSnapshot.GetStraightenIndex();
	if (StraightenIndex < 0 || StraightenIndex >= this->PropertyValues.Num())
	{
		return false;
	}
	UObject* Target = GetTarget();
	this->PropertyValues[StraightenIndex].Collect(Target, this->PropertyPath.Get());
	return true;
}

bool FKGStateController::Apply()
{
	if (!IsValid())
	{
		return false;
	}

	// TODO: 运行时采用引用方式的快照，并进行缓存，减少每次创建的开销
	FKGStateControllerSnapshot StateControllerSnapshot = FKGStateControllerSnapshot::Create(*this);

	int StraightenIndex = StateControllerSnapshot.GetStraightenIndex();
	if (StraightenIndex < 0 || StraightenIndex >= this->PropertyValues.Num())
	{
		return false;
	}
	FProperty* Property = this->PropertyPath.Get();
	if (Property == NULL)
	{
		return false;
	}
	UObject* Target = GetTarget();
	this->PropertyValues[StraightenIndex].Apply(Target, Property);
	return true;
}

UObject* FKGStateController::GetTarget()
{
	if (this->PropertyPath.Get()->GetOwnerClass()->IsChildOf(UPanelSlot::StaticClass()))
	{
		return Widget.Get()->Slot;
	}
	else
	{
		return Widget.Get();
	}
}

bool FKGStateController::IsValid()
{
	if (PropertyPath.Get() == NULL)
	{
		return false;
	}
	auto Target = GetTarget();
	if (Target == NULL)
	{
		return false;
	}
	return Target->IsA(PropertyPath.Get()->GetOwnerClass());
}

UWidget* FKGStateController::GetWidget() const
{
	return Widget.Get();
}

bool IsStateControllerProperty(FProperty* Property)
{
	if (!Property->HasSetter())
	{
		return false;
	}
	if (Property->IsA(FArrayProperty::StaticClass()) ||
		Property->IsA(FSetProperty::StaticClass()) ||
		Property->IsA(FMapProperty::StaticClass()))
	{
		// 依赖FPropertyChangeListener对这几个类型的支持
		return false;
	}
	return true;
}

TArray<TFieldPath<FProperty>> FKGStateController::GetStateControllerProperties(UWidget* Widget)
{
	TArray<TFieldPath<FProperty>> Properties;
	auto Slot = Widget->Slot;
	if (Slot != NULL)
	{
		auto SlotClass = Slot->GetClass();
		for (FProperty* Property = SlotClass->PropertyLink; Property; Property = Property->PropertyLinkNext)
		{
			if (!IsStateControllerProperty(Property))
			{
				continue;
			}
			Properties.Add(TFieldPath<FProperty>(Property));
		}
	}
	for (FProperty* Property = Widget->GetClass()->PropertyLink; Property; Property = Property->PropertyLinkNext)
	{
		if (!IsStateControllerProperty(Property))
		{
			continue;
		}
		Properties.Add(TFieldPath<FProperty>(Property));
	}
	auto StateControllerPropertyCustomizations = FKGUIModule::Get().GetStateControllerPropertyCustomizations(Widget->GetClass());
	for (auto StateControllerPropertyCustomization : StateControllerPropertyCustomizations)
	{
		Properties.Add(StateControllerPropertyCustomization->PropertyPath);
	}
	return MoveTemp(Properties);
}

FKGStateGroupReference FKGStateController::CreateStateGroupReference(const FKGStateGroup& StateGroup) const
{
	return FKGStateGroupReference::CreateInternal(StateGroup.GetWidget(), this->GetWidget(), StateGroup.Name);
}

void FKGStateController::PreSave(FObjectPreSaveContext SaveContext)
{
	for (auto& PropertyValue : this->PropertyValues)
	{
		PropertyValue.PreSave(SaveContext);
	}
}

void FKGStateController::PostLoad()
{
	for (auto& PropertyValue : this->PropertyValues)
	{
		PropertyValue.PostLoad();
	}
}
