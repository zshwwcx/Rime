#include "UMG/StateManagement/KGStateManagementCustomVersion.h"

#include "UObject/DevObjectVersion.h"

const FGuid FKGStateManagementCustomVersion::GUID(0x0CA90F25, 0xB7B54B04, 0xAE64EE7A, 0xAC5BC1BA);

FDevVersionRegistration GKGRegisterStateManagementCustomVersion(FKGStateManagementCustomVersion::GUID, FKGStateManagementCustomVersion::LatestVersion, TEXT("Dev-StateManagement"));
