#include "UMG/StyleSheet/KGStyleSheetRelativeView.h"

#include "UMG/Blueprint/KGUserWidget.h"

void FKGStyleSheetRelativeView::Apply(UObject* Object, bool bSetterPreferred) const
{
	auto StyleSheetPreset = Cast<UKGStyleSheetPreset>(Source);
	if (StyleSheetPreset == nullptr)
	{
		return;
	}
	const FKGStyleSheet& StyleSheetData = StyleSheetPreset->GetStyleSheetData();
	StyleSheetData.ApplyInternal(StyleSheetPreset, Object, &RelativePath, bSetterPreferred);
}
