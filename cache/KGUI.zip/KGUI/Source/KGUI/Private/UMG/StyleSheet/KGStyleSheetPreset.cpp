#include "UMG/StyleSheet/KGStyleSheetPreset.h"

#include "Core/Common.h"

void UKGStyleSheetPreset::Apply(UObject* Object)
{
	if (Object == nullptr)
	{
		return;
	}
	if (TargetClass != nullptr && !Object->IsA(TargetClass))
	{
		UE_LOG(LogKGUI, Warning, TEXT("The target type of the stylesheet %s does not match the current object (%s)."), *TargetClass->GetName(), *Object->GetClass()->GetName());
	}
	StyleSheet.Apply(this, Object);
}
