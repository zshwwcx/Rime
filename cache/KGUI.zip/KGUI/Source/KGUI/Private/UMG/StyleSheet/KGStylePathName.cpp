#include "UMG/StyleSheet/KGStylePathName.h"

FKGStylePathName FKGStylePathName::Create(FName InType, FName InArgument)
{
	check(InType != NAME_None);
	FKGStylePathName Name;
	Name.Type = InType;
	Name.Argument = InArgument;
	return MoveTemp(Name);
}