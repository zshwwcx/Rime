#include "UMG/StyleSheet/KGStylePathTypeCustomizationRegistry.h"

#include "Blueprint/UserWidget.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Blueprint/WidgetTree.h"
#include "Components/Widget.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "UMG/Components/KGListView.h"
#include "UMG/StyleSheet/KGStylePathName.h"
#include "UMG/StyleSheet/KGStylePathTypeCustomization.h"

const FName FKGStylePathBuiltinTypes::WidgetTreeChild(TEXT("WidgetTreeChild"));
const FName FKGStylePathBuiltinTypes::WidgetSlot(TEXT("WidgetSlot"));
const FName FKGStylePathBuiltinTypes::ListViewEntryClass(TEXT("ListViewEntryClass"));

class FKGStylePathTypeCustomization_WidgetTreeChild : public IKGStylePathTypeCustomization
{
public:
	FKGStylePathTypeCustomization_WidgetTreeChild()
	{
		Type = FKGStylePathBuiltinTypes::WidgetTreeChild;
	}

	virtual UObject* GetSuccessorObject(UObject* CurrentObject, const FKGStylePathName& Name) const override
	{
		check(Name.Type == GetType());
		auto UserWidget = Cast<UUserWidget>(CurrentObject);
		if (UserWidget == nullptr)
		{
			return nullptr;
		}
		if (UserWidget->WidgetTree != nullptr)
		{
			return UserWidget->WidgetTree->FindWidget(Name.Argument);
		}
		else
		{
			if (auto BPGC = Cast<UWidgetBlueprintGeneratedClass>(UserWidget->GetClass()))
			{
				return BPGC->GetWidgetTreeArchetype()->FindWidget(Name.Argument);
			}
		}
		return nullptr;
	}

	virtual void EnumerateSuccessorObjects(UObject* CurrentObject, const FKGStylePath& CurrentPath, const FOnSuccessorFound& OnSuccessorFound) const override
	{
		auto UserWidget = Cast<UUserWidget>(CurrentObject);
		if (UserWidget == nullptr)
		{
			return;
		}
		UWidgetTree* WidgetTree = nullptr;
		if (UserWidget->WidgetTree != nullptr)
		{
			WidgetTree = UserWidget->WidgetTree;
		}
		else
		{
			if (auto BPGC = Cast<UWidgetBlueprintGeneratedClass>(UserWidget->GetClass()))
			{
				WidgetTree = BPGC->GetWidgetTreeArchetype();
			}
		}
		if (WidgetTree == nullptr)
		{
			return;
		}
		WidgetTree->ForEachWidget([WeakThis = StaticCastWeakPtr<const FKGStylePathTypeCustomization_WidgetTreeChild>(this->AsWeak()), &CurrentPath, &OnSuccessorFound](UWidget* WidgetChild)
		{
			if (auto This = WeakThis.Pin())
			{
				OnSuccessorFound.ExecuteIfBound(WidgetChild, CurrentPath.CopyWithNameFollowing(FKGStylePathName::Create(This->GetType(), WidgetChild->GetFName())));
			}
		});	
	}

	virtual FString GetDisplayName(const FKGStylePathName& Name) const override
	{
		return FString::Printf(TEXT("#%s"), *Name.Argument.ToString());
	}
};

class FKGStylePathTypeCustomization_WidgetSlot : public IKGStylePathTypeCustomization
{
public:
	FKGStylePathTypeCustomization_WidgetSlot()
	{
		Type = FKGStylePathBuiltinTypes::WidgetSlot;
	}

	virtual UObject* GetSuccessorObject(UObject* CurrentObject, const FKGStylePathName& Name) const override
	{
		check(Name.Type == GetType());
		auto Widget = Cast<UWidget>(CurrentObject);
		return Widget != nullptr ? Widget->Slot : nullptr;
	}

	virtual void EnumerateSuccessorObjects(UObject* CurrentObject, const FKGStylePath& CurrentPath, const FOnSuccessorFound& OnSuccessorFound) const override
	{
		auto Widget = Cast<UWidget>(CurrentObject);
		if (Widget == nullptr)
		{
			return;
		}
		if (Widget->Slot != nullptr)
		{
			OnSuccessorFound.ExecuteIfBound(Widget->Slot, CurrentPath.CopyWithNameFollowing(FKGStylePathName::Create(GetType(), NAME_None)));
		}
	}

	virtual FString GetDisplayName(const FKGStylePathName& Name) const override
	{
		return FString::Printf(TEXT(".Slot"));
	}
};

class FKGStylePathTypeCustomization_ListViewEntryClass : public IKGStylePathTypeCustomization
{
public:
	FKGStylePathTypeCustomization_ListViewEntryClass()
	{
		Type = FKGStylePathBuiltinTypes::ListViewEntryClass;
	}

	virtual UObject* GetSuccessorObject(UObject* CurrentObject, const FKGStylePathName& Name) const override
	{
		check(Name.Type == GetType());
		if (auto ListViewBase = Cast<UListViewBase>(CurrentObject))
		{
			if (auto EntryClass = ListViewBase->GetEntryWidgetClass())
			{
				if (EntryClass->GetFName() == Name.Argument)
				{
					return EntryClass;
				}
			}
		}
		if (auto MoreEntryClassesListView = Cast<UKGListView>(CurrentObject))
		{
			auto MoreEntryClasses = MoreEntryClassesListView->GetMoreEntryWidgetClasses();
			for (auto MoreEntryClass : MoreEntryClasses)
			{
				if (MoreEntryClass->GetFName() == Name.Argument)
				{
					return MoreEntryClass;
				}
			}
		}
		return nullptr;
	}

	virtual void EnumerateSuccessorObjects(UObject* CurrentObject, const FKGStylePath& CurrentPath, const FOnSuccessorFound& OnSuccessorFound) const override
	{
		if (auto ListViewBase = Cast<UListViewBase>(CurrentObject))
		{
			if (auto EntryClass = ListViewBase->GetEntryWidgetClass())
			{
				if (EntryClass.Get())
				{
					OnSuccessorFound.ExecuteIfBound(EntryClass.Get(), CurrentPath.CopyWithNameFollowing(FKGStylePathName::Create(GetType(), EntryClass->GetFName())));
				}
			}
		}
		if (auto MoreEntryClassesListView = Cast<UKGListView>(CurrentObject))
		{
			auto MoreEntryClasses = MoreEntryClassesListView->GetMoreEntryWidgetClasses();
			for (auto MoreEntryClass : MoreEntryClasses)
			{
				if (MoreEntryClass.Get())
				{
					OnSuccessorFound.ExecuteIfBound(MoreEntryClass.Get(), CurrentPath.CopyWithNameFollowing(FKGStylePathName::Create(GetType(), MoreEntryClass->GetFName())));
				}
			}
		}
	}

	virtual FString GetDisplayName(const FKGStylePathName& Name) const override
	{
		auto EntryClassNameString = Name.Argument.ToString();
		EntryClassNameString.RemoveFromEnd("_C", ESearchCase::CaseSensitive);
		return FString::Printf(TEXT("[%s]"), *EntryClassNameString);
	}
};

FKGStylePathTypeCustomizationRegistry::FKGStylePathTypeCustomizationRegistry()
{
	RegisterStylePathTypeCustomization(MakeShared<FKGStylePathTypeCustomization_WidgetTreeChild>());
	RegisterStylePathTypeCustomization(MakeShared<FKGStylePathTypeCustomization_WidgetSlot>());
	RegisterStylePathTypeCustomization(MakeShared<FKGStylePathTypeCustomization_ListViewEntryClass>());
}

void FKGStylePathTypeCustomizationRegistry::RegisterStylePathTypeCustomization(const TSharedRef<IKGStylePathTypeCustomization>& StylePathTypeCustomization)
{
	auto Type = StylePathTypeCustomization->GetType();
	check(!this->StylePathTypeCustomizations.Contains(Type));
	this->StylePathTypeCustomizations.Add(Type, StylePathTypeCustomization);
}

const IKGStylePathTypeCustomization* FKGStylePathTypeCustomizationRegistry::GetStylePathTypeCustomization(FName Type) const
{
	auto Found = StylePathTypeCustomizations.Find(Type);
	if (!Found)
	{
		return nullptr;
	}
	return Found->Get();
}

FString FKGStylePathTypeCustomizationRegistry::GetStylePathNameDisplayName(const FKGStylePathName& Name) const
{
	auto StylePathTypeCustomization = GetStylePathTypeCustomization(Name.Type);
	if (StylePathTypeCustomization == nullptr)
	{
		return TEXT("?");
	}
	else
	{
		return StylePathTypeCustomization->GetDisplayName(Name);
	}
}

FText FKGStylePathTypeCustomizationRegistry::GetStylePathDisplayNameText(const FKGStylePath& Path) const
{
	TArray<FString> Strings;
	Strings.Add(TEXT("."));
	for (auto& Name : Path.Names)
	{
		Strings.Add(GetStylePathNameDisplayName(Name));
	}
	return FText::FromString(FString::Join(Strings, TEXT(" / ")));
}
