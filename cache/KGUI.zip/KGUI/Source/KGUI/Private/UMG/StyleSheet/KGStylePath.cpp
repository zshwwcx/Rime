#include "UMG/StyleSheet/KGStylePath.h"

#include "UMG/StyleSheet/KGStylePathTypeCustomization.h"
#include "KGUI.h"

void FKGStylePath::Reset()
{
	Names.Reset();
}

UObject* FKGStylePath::GetObject(UObject* Owner, FKGStylePathGetObjectContext& Context) const
{
	if (Owner == nullptr)
	{
		return nullptr;
	}
	UObject* Object = Owner;
	Context.Reset();
	int Index = -1;
	if (Context.RelativePath)
	{
		for (const auto& Name : Context.RelativePath->Names)
		{
			Index++;
			if (Names[Index] != Name)
			{
				return nullptr;
			}
		}
	}
	auto& Registry = FKGUIModule::Get().GetStylePathTypeCustomizationRegistry();
	do
	{
		// Process Object
		{
			if (auto Class = Cast<UClass>(Object))
			{
				if (!Context.bDeferred)
				{
					ensure(Context.OutDeferredPath.IsEmpty());
					for (int I = 0; I < Index; I++)
					{
						// TODO: OutDeferredPath的存储其实可以调整成仅仅存个序号，使用时再Resolve，不过需要确保序号只是临时的结果，长期持有可能存在失效的风险
						Context.OutDeferredPath.Names.Add(Names[I]);
					}
					Context.bDeferred = true;
				}
				if (Context.bRecordNearestClassPath)
				{
					Context.OutNearestClassPath.Reset();
					for (int I = 0; I < Index; I++)
					{
						Context.OutNearestClassPath.Names.Add(Names[I]);
					}
				}
				Object = Class->GetDefaultObject();
				if (!Object)
				{
					return nullptr;
				}
			}
		}
		// Next Object
		Index++;
		if (Index >= Names.Num())
		{
			break;
		}
		check(Names.IsValidIndex(Index));
		const auto& Name = Names[Index];
		auto StylePathTypeCustomization = Registry.GetStylePathTypeCustomization(Name.Type);
		if (!ensure(StylePathTypeCustomization != nullptr))
		{
			return nullptr;
		}
		Object = StylePathTypeCustomization->GetSuccessorObject(Object, Name);
	} while (true);
	return Object;
}

UObject* FKGStylePath::GetObject(UObject* Owner) const
{
	static FKGStylePathGetObjectContext Context;
	Context.Reset();
	return GetObject(Owner, Context);
}

void FKGStylePath::GetAvailablePathsInternal(const FKGStylePath& CurrentPath, UObject* CurrentObject, TArray<TSharedPtr<FKGStylePath>>& OutPaths, int Depth, UObject* SpecificObject)
{
	if (auto CurrentClass = Cast<UClass>(CurrentObject))
	{
		CurrentObject = CurrentClass->GetDefaultObject();
	}
	if (SpecificObject == nullptr || SpecificObject == CurrentObject)
	{
		OutPaths.Add(MakeShared<FKGStylePath>(CurrentPath));
	}
	if (Depth == 0)
	{
		return;
	}
	for (const auto& KeyValuePair : FKGUIModule::Get().GetStylePathTypeCustomizationRegistry().GetStylePathTypeCustomizations())
	{
		const auto& StylePathTypeCustomization = KeyValuePair.Value;
		StylePathTypeCustomization->EnumerateSuccessorObjects(CurrentObject, CurrentPath,
			IKGStylePathTypeCustomization::FOnSuccessorFound::CreateLambda([&OutPaths, Depth, SpecificObject](UObject* Object, const FKGStylePath& Path)
			{
				GetAvailablePathsInternal(Path, Object, OutPaths, Depth - 1, SpecificObject);
			})
		);
	}
}

FKGStylePath FKGStylePath::CopyWithNameFollowing(const FKGStylePathName& Name) const
{
	FKGStylePath StylePath = *this;
	StylePath.Names.Add(Name);
	return MoveTemp(StylePath);
}

bool FKGStylePath::TryGetParentPath(FKGStylePath& ParentPath) const
{
	if (this->Names.Num() == 0)
	{
		return false;
	}
	ParentPath.Reset();
	ParentPath.Names = TArray<FKGStylePathName>(&this->Names[0], this->Names.Num() - 1);
	return true;
}

bool FKGStylePath::IsChildOf(const FKGStylePath& MaybeParentPath) const
{
	if (Names.Num() < MaybeParentPath.Names.Num())
	{
		return false;
	}
	int Count = MaybeParentPath.Names.Num();
	for (int Index = 0; Index < Count;Index ++)
	{
		if (Names[Index] != MaybeParentPath.Names[Index])
		{
			return false;
		}
	}
	return true;
}

FKGStylePath FKGStylePath::GetRelativePathFrom(const FKGStylePath& ParentPath) const
{
	int Index = 0;
	while (Names.Num() > Index && ParentPath.Names.Num() > Index && Names[Index] == ParentPath.Names[Index])
	{
		Index++;
	}
	FKGStylePath RelativePath;
	for (int I = Index; I < ParentPath.Names.Num(); I++)
	{
		RelativePath.Names.Add(FKGStylePathName::Create(NAME_None, TEXT("..")));
	}
	for (int I = Index; I < Names.Num(); I++)
	{
		RelativePath.Names.Add(Names[I]);
	}
	return RelativePath;
}

const FName& FKGStylePath::GetType() const
{
	static FName None = NAME_None;
	if (IsEmpty())
	{
		return None;
	}
	return Names.Last().Type;
}

const FName& FKGStylePath::GetParentType() const
{
	static FName None = NAME_None;
	check(Names.Num() > 0);
	if (Names.Num() == 1)
	{
		return None;
	}
	else
	{
		return Names[Names.Num() - 2].Type;
	}
}

const FName& FKGStylePath::GetArgument() const
{
	static FName None = NAME_None;
	return Names.Num() == 0 ? None : Names.Last().Argument;
}

TArray<TSharedPtr<FKGStylePath>> FKGStylePath::GetAvailablePaths(UObject* Owner)
{
	TArray<TSharedPtr<FKGStylePath>> AvailablePaths;
	if (Owner != nullptr)
	{
		GetAvailablePathsInternal(FKGStylePath(), Owner, AvailablePaths);
	}
	return MoveTemp(AvailablePaths);
}

TSharedPtr<FKGStylePath> FKGStylePath::FindPath(UObject* Owner, UObject* Object)
{
	TArray<TSharedPtr<FKGStylePath>> AvailablePaths;
	if (Owner != nullptr)
	{
		GetAvailablePathsInternal(FKGStylePath(), Owner, AvailablePaths, -1, Object);
	}
	if (AvailablePaths.Num() > 0)
	{
		return AvailablePaths[0];
	}
	return nullptr;
}

TArray<TSharedPtr<FKGStylePath>> FKGStylePath::GetChildPaths(UObject* Owner, const FKGStylePath& ParentPath)
{
	auto Parent = ParentPath.GetObject(Owner);
	TArray<TSharedPtr<FKGStylePath>> ChildPaths;
	if (Parent != nullptr)
	{
		GetAvailablePathsInternal(ParentPath, Parent, ChildPaths, 1);
		ChildPaths.RemoveAt(0);
	}
	return ChildPaths;
}
