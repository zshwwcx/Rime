#include "UMG/StyleSheet/KGVariantValue.h"

FKGVariantValue::FKGVariantValue()
{
}

FKGVariantValue::FKGVariantValue(const FKGVariantValue& Other)
	: PropertyPath(Other.PropertyPath)
{
	Construct();
	Assign(Other.Data);
}

FKGVariantValue::~FKGVariantValue()
{
	Destruct();
}

FKGVariantValue& FKGVariantValue::operator=(const FKGVariantValue& Other)
{
	Destruct();
	PropertyPath = Other.PropertyPath;
	Construct();
	Assign(Other.Data);
	return *this;
}

bool FKGVariantValue::Get(const UObject* Object)
{
	if (!ensure(Object != nullptr && IsValid()))
	{
		return false;
	}
	check(Property != nullptr);
	if (!ensure(Object->GetClass()->IsChildOf(Property->GetOwnerClass())))
	{
		return false;
	}
	Property->GetValue_InContainer(Object, Data);
	this->Normalize();
	return true;
}

bool FKGVariantValue::Set(UObject* Object, bool bSetterPreferred) const
{
	if (!(Object != nullptr && IsValid()))
	{
		return false;
	}
	check(Property != nullptr);
	if (!ensure(Object->GetClass()->IsChildOf(Property->GetOwnerClass())))
	{
		return false;
	}
	if (bSetterPreferred)
	{
		Property->SetValue_InContainer(Object, this->Data);
	}
	else
	{
		Property->CopyCompleteValue(Property->ContainerPtrToValuePtr<void*>(Object, 0), this->Data);
	}
	return true;
}

void FKGVariantValue::SetPropertyPath(const TFieldPath<FProperty>& InPropertyPath)
{
	if (PropertyPath == InPropertyPath)
	{
		return;
	}
	Destruct();
	PropertyPath = InPropertyPath;
	Construct();
}

void FKGVariantValue::Construct()
{
	Property = PropertyPath.Get();
	if (!IsValid())
	{
		return;
	}
	Data = Property->AllocateAndInitializeValue();
}

void FKGVariantValue::Destruct()
{
	if (!IsValid())
	{
		return;
	}
	Property->DestroyAndFreeValue(Data);
	Property = nullptr;
	Data = nullptr;
}

bool FKGVariantValue::Assign(void const* Value)
{
	if (Value == nullptr || !IsValid())
	{
		return false;
	}
	Property->CopyCompleteValue(Data, Value);
	this->Normalize();
	return true;
}

void FKGVariantValue::Normalize()
{
	// 如果需要提供接口返回布尔型的数值，需要专门针对FieldMask机制做处理。
	if (const FBoolProperty* BoolProperty = CastField<FBoolProperty>(Property))
	{
		uint8* ByteValue = (uint8*)Data;
		uint8 FieldMask = BoolProperty->GetFieldMask();
		*ByteValue = (*ByteValue & FieldMask) ? 0xFF : 0;
	}
}

bool FKGVariantValue::Serialize(FArchive& Ar)
{
	TFieldPath<FProperty> Tempory = this->PropertyPath;
	Ar << Tempory;
	if (Ar.IsLoading())
	{
		SetPropertyPath(Tempory);
	}
	if (Property != nullptr)
	{
		Property->SerializeItem(FStructuredArchiveFromArchive(Ar).GetSlot(), Data);
	}
	return true;
}

bool FKGVariantValue::ExportTextItem(FString& ValueStr, FKGVariantValue const& DefaultValue, UObject* Parent, int32 PortFlags, UObject* ExportRootScope) const
{
	ValueStr += "(";
		ValueStr += TEXT("\"");
			ValueStr += this->PropertyPath.ToString();
		ValueStr += TEXT("\"");
		ValueStr += ",";
		if (IsValid())
		{
			Property->ExportTextItem_Direct(ValueStr, Data, nullptr, Parent, PortFlags, ExportRootScope);
		}
	ValueStr += ")";
	return true;
}

bool FKGVariantValue::ImportTextItem(const TCHAR*& Buffer, int32 PortFlags, UObject* Parent, FOutputDevice* ErrorText)
{
	SetPropertyPath(TFieldPath<FProperty>());

	const TCHAR* BufferIt = Buffer;
	if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR('(')) return false;
		if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR('\"')) return false;

		#pragma region PropertyPath
			const TCHAR* PathNameStartPtr = BufferIt;
			while (*BufferIt != TCHAR('\"'))
			{
				if (*BufferIt == TCHAR('\0'))
				{
					return false;
				}
				BufferIt++;
			}
			const TCHAR* PathNameEndPtr = BufferIt;
			FString PathName(PathNameEndPtr - PathNameStartPtr, PathNameStartPtr);
			this->PropertyPath.Generate(*PathName);
			Construct();
		#pragma endregion
		if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR('\"')) return false;
		if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR(',')) return false;
		#pragma region Data
			if (IsValid())
			{
				if (!Property->ImportText_Direct(BufferIt, Data, nullptr, PortFlags, ErrorText))
				{
					SetPropertyPath(TFieldPath<FProperty>());
					return false;
				}
			}
		#pragma endregion
	if (*BufferIt == TCHAR('\0') || *BufferIt++ != TCHAR(')')) return false;

	return true;
}
