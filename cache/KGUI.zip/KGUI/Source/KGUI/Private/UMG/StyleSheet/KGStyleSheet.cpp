#include "UMG/StyleSheet/KGStyleSheet.h"

#include "UMG/Blueprint/KGUserWidget.h"
#include "UMG/Components/KGListView.h"
#include "UMG/StyleSheet/KGStylePathTypeCustomization.h"

void FKGStyleSheet::ApplyInternal(UObject* Source, UObject* Object, const FKGStylePath* RelativePath, bool bSetterPreferred) const
{
	if (Object->IsA<UUserWidget>())
	{
		check(Object->GetClass()->GetDefaultObject() != Object);
	}
	FKGStylePathGetObjectContext Context;
	TSet<FKGStylePath> DeferredPaths;
	for (auto& Statement : Statements)
	{
		Context.RelativePath = RelativePath;
		auto Target = Statement.Path.GetObject(Object, Context);
		if (Target == nullptr)
		{
			continue;
		}
		if (Context.bDeferred)
		{
			DeferredPaths.Add(Context.OutDeferredPath);
			continue;
		}
		for (const auto& Value : Statement.Values)
		{
			Value.Set(Target, bSetterPreferred);
		}
	}
	if (!DeferredPaths.IsEmpty())
	{
		for (const auto& DeferredPath : DeferredPaths)
		{
			if (DeferredPath.GetType() == FKGStylePathBuiltinTypes::ListViewEntryClass)
			{
				FKGStylePath ParentPath;
				if (DeferredPath.TryGetParentPath(ParentPath))
				{
					auto Parent = ParentPath.GetObject(Object);
					if (auto ListView = Cast<UKGListView>(Parent))
					{
						FKGStyleSheetRelativeView StyleSheetRelativeView;
						StyleSheetRelativeView.RelativePath = DeferredPath;
						StyleSheetRelativeView.Source = Source;
						ListView->SetStyleSheetRelativeView(DeferredPath.GetArgument(), MoveTemp(StyleSheetRelativeView));
					}
				}
			}
		}
	}
}

void FKGStyleSheet::Apply(UKGStyleSheetPreset* SourceStyleSheetPreset, UObject* Object, bool bSetterPreferred) const
{
	return ApplyInternal(SourceStyleSheetPreset, Object, nullptr, bSetterPreferred);
}

void FKGStyleSheet::Apply(UKGUserWidget* SourceUserWidget, UObject* Object, bool bSetterPreferred) const
{
	return ApplyInternal(SourceUserWidget, Object, nullptr, bSetterPreferred);
}

bool FKGStyleSheet::HasValueFor(UObject* Object, const UObject* Target, const FProperty* Property) const
{
	for (auto& Statement : Statements)
	{
		if (Statement.Path.GetObject(Object) != Target)
		{
			continue;
		}
		for (auto& Value : Statement.Values)
		{
			if (Property == nullptr || Value.GetPropertyPath().Get() == Property)
			{
				return true;
			}
		}
	}
	return false;
}
