#include "UMG/Animation/Line/KGBezierPointTrack.h"
#include "UMG/Animation/Line/KGBezierPointSection.h"

UKGBezierPointTrack::UKGBezierPointTrack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
#if WITH_EDITORONLY_DATA
	TrackTint = FColor(180, 100, 120, 65); // Example color
#endif
	EvalOptions.bEvaluateNearestSection_DEPRECATED = EvalOptions.bCanEvaluateNearestSection = true;
	SupportedBlendTypes = FMovieSceneBlendTypeField::All();
}

bool UKGBezierPointTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UKGBezierPointSection::StaticClass();
}

UMovieSceneSection* UKGBezierPointTrack::CreateNewSection()
{
	return NewObject<UKGBezierPointSection>(this, NAME_None, RF_Transactional);
}