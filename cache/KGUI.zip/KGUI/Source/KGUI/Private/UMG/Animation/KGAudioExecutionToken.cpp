#include "UMG/Animation/KGAudioExecutionToken.h"
#include "UMG/Animation/KGAudioSection.h"

#include "IMovieScenePlayer.h"
#include "Manager/KGAkAudioManager.h"
#include "Evaluation/MovieScenePlayback.h"

void FKGAudioExecutionToken::Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player)
{
	// 如果没有播放
	if ((Context.GetStatus() != EMovieScenePlayerStatus::Playing && Context.GetStatus() != EMovieScenePlayerStatus::Scrubbing) || Context.HasJumped())
	{
		return;
	}

	UAkAudioEvent* Event = Section->GetEvent();
	if (!Event)
	{
		return;
	}

	if (Section->bPostOnChildActor)
	{
		TArrayView<TWeakObjectPtr<>> BoundObjects = Player.FindBoundObjects(Operand.ObjectBindingID, Operand.SequenceID);
		for (TWeakObjectPtr<> BoundObject : BoundObjects)
		{
			if (UChildActorComponent* ChildActorComp = Cast<UChildActorComponent>(BoundObject.Get()))
			{
				if (AActor* ChildActor = ChildActorComp->GetChildActor())
				{
					Event->PostOnActor(ChildActor, nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
				}
			}
		}
	}
	else
	{
		UKGAkAudioManager::PostTrackEvent(Player.AsUObject(), Event, Section->bEnableSync);
	}
}
