﻿#include "UMG/Animation/NiagaraUI/KGNiagaraUIParameterTrack.h"

void UKGNiagaraUIParameterTrack::AddSection(UMovieSceneSection& Section)
{
	Sections.Add(&Section);
}

const TArray<UMovieSceneSection*>& UKGNiagaraUIParameterTrack::GetAllSections() const
{
	return Sections;
}

bool UKGNiagaraUIParameterTrack::HasSection(const UMovieSceneSection& Section) const
{
	return Sections.Contains(&Section);
}

bool UKGNiagaraUIParameterTrack::IsEmpty() const
{
	return Sections.Num() != 0;
}

void UKGNiagaraUIParameterTrack::RemoveAllAnimationData()
{
	Sections.Empty();
}

void UKGNiagaraUIParameterTrack::RemoveSection(UMovieSceneSection& Section)
{
	Sections.Remove(&Section);
}

void UKGNiagaraUIParameterTrack::RemoveSectionAt(int32 SectionIndex)
{
	Sections.RemoveAt(SectionIndex);
}

const FNiagaraVariable& UKGNiagaraUIParameterTrack::GetParameter() const
{
	return Parameter;
}

void UKGNiagaraUIParameterTrack::SetParameter(FNiagaraVariable InParameter)
{
	Parameter = InParameter;
}

