#include "UMG/Animation/KGUserWidgetAnimationEvalTemplate.h"
#include "UMG/Animation/KGUserWidgetAnimationExecutionToken.h"


FKGUserWidgetAnimationEvalTemplate::FKGUserWidgetAnimationEvalTemplate()
{

}

FKGUserWidgetAnimationEvalTemplate::FKGUserWidgetAnimationEvalTemplate(const UKGUserWidgetAnimationSection* InSection):FMovieSceneEvalTemplate(), Section(InSection)
{
	
}

//void FKGUserWidgetAnimationEvalTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
//{
//	// 启动 FKGUserWidgetAnimationExecutionToken
//	ExecutionTokens.Add(FKGUserWidgetAnimationExecutionToken(Section));
//}

void FKGUserWidgetAnimationEvalTemplate::EvaluateSwept(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const TRange<FFrameNumber>& SweptRange, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	// Don't allow events to fire when playback is in a stopped state. This can occur when stopping 
	// playback and returning the current position to the start of playback. It's not desireable to have 
	// all the events from the last playback position to the start of playback be fired.
	if (Context.GetStatus() == EMovieScenePlayerStatus::Stopped || Context.IsSilent())
	{
		return;
	}
	const bool bBackwards = Context.GetDirection() == EPlayDirection::Backwards;
	if (bBackwards)
	{
		return;
	}
	
	TRange<FFrameNumber> Range = Section->GetRange();
	if (!Range.HasLowerBound() || !Range.HasUpperBound())
	{
		return;
	}
	FFrameNumber Lower = Range.GetLowerBoundValue();
	FFrameNumber Upper = Range.GetUpperBoundValue();
	FFrameNumber SweptLower = SweptRange.GetLowerBoundValue();
	FFrameNumber SweptUpper = SweptRange.GetUpperBoundValue();
	//UE_LOG(LogTemp, Warning, TEXT("FKGUserWidgetAnimationEvalTemplate::EvaluateSwept =>SweptLower:%d SweptUpper:%d, Lower:%d, Upper:%d"), SweptLower.Value, SweptUpper.Value, Lower.Value, Upper.Value);
#if WITH_EDITOR
	if(!bIsEditor)
	{
		if (SweptLower.Value <= Lower.Value + 1 && SweptUpper.Value > Lower.Value + 1)
		{
			ExecutionTokens.Add(FKGUserWidgetAnimationExecutionToken(Section, EKGUserWidgetAnimationSectionPosition::Start));
			return;
		}
	}
	else
	{
		if (SweptLower <= Lower && SweptUpper > Lower)
		{
			ExecutionTokens.Add(FKGUserWidgetAnimationExecutionToken(Section, EKGUserWidgetAnimationSectionPosition::Start));
			return;
		}
	}
#else
	if (SweptLower <= Lower && SweptUpper > Lower)     
	{
		ExecutionTokens.Add(FKGUserWidgetAnimationExecutionToken(Section, EKGUserWidgetAnimationSectionPosition::Start));
		return;
	}
#endif
	int32 UpperValue = SweptUpper.Value;
	int32 LowerValue = SweptLower.Value;
	int32 Value = Upper.Value - (UpperValue - LowerValue);
	if(LowerValue <= Value && UpperValue >= Value)
	{
		ExecutionTokens.Add(FKGUserWidgetAnimationExecutionToken(Section, EKGUserWidgetAnimationSectionPosition::End));
	}
}

void FKGUserWidgetAnimationEvalTemplate::Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	if (!Section)
	{
		return;
	}
	//UE_LOG(LogTemp, Warning, TEXT("FKGUserWidgetAnimationEvalTemplate::Setup Anim:%s"), *(Section->AnimName));
	UObject* PlaybackContext = Player.GetPlaybackContext();
	UWorld* World = PlaybackContext ? PlaybackContext->GetWorld() : nullptr;
	if(World)
	{
		const_cast<FKGUserWidgetAnimationEvalTemplate*>(this)->bIsEditor = false;
	}
	else
	{
		const_cast<FKGUserWidgetAnimationEvalTemplate*>(this)->bIsEditor = true;
	}
}

void FKGUserWidgetAnimationEvalTemplate::TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	if (!Section)
	{
		return;
	}

	//UE_LOG(LogTemp, Warning, TEXT("FKGUserWidgetAnimationEvalTemplate::TearDown Anim:%s"), *(Section->AnimName));
}
