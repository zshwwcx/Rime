﻿#include "UMG/Animation/NiagaraUI/KGNiagaraUIColorParameterTrack.h"
#include "Sections/MovieSceneColorSection.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "UMG/Animation/NiagaraUI/KGNiagaraUIColorParameterSectionTemplate.h"

bool UKGNiagaraUIColorParameterTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneColorSection::StaticClass();
}

UMovieSceneSection* UKGNiagaraUIColorParameterTrack::CreateNewSection()
{
	return NewObject<UMovieSceneColorSection>(this, NAME_None, RF_Transactional);
}

void UKGNiagaraUIColorParameterTrack::SetSectionChannelDefaults(UMovieSceneSection* Section, const TArray<uint8>& DefaultValueData) const
{
	UMovieSceneColorSection* ColorSection = Cast<UMovieSceneColorSection>(Section);
	if (ensureMsgf(ColorSection != nullptr, TEXT("Section must be a color section.")) && ensureMsgf(DefaultValueData.Num() == sizeof(FLinearColor), TEXT("DefaultValueData must be a FLinearColor.")))
	{
		FLinearColor DefaultValue = *((FLinearColor*)DefaultValueData.GetData());
		FMovieSceneChannelProxy& ColorChannelProxy = ColorSection->GetChannelProxy();
		SetChannelDefault(ColorChannelProxy, ColorSection->GetRedChannel(), DefaultValue.R);
		SetChannelDefault(ColorChannelProxy, ColorSection->GetGreenChannel(), DefaultValue.G);
		SetChannelDefault(ColorChannelProxy, ColorSection->GetBlueChannel(), DefaultValue.B);
		SetChannelDefault(ColorChannelProxy, ColorSection->GetAlphaChannel(), DefaultValue.A);
	}
}

FMovieSceneEvalTemplatePtr UKGNiagaraUIColorParameterTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	const UMovieSceneColorSection* ColorSection = Cast<UMovieSceneColorSection>(&InSection);
	if (ColorSection != nullptr)
	{
		return FKGNiagaraUIColorParameterSectionTemplate(GetParameter(), ColorSection->GetRedChannel(), ColorSection->GetGreenChannel(), ColorSection->GetBlueChannel(), ColorSection->GetAlphaChannel());
	}
	return FMovieSceneEvalTemplatePtr();
}
