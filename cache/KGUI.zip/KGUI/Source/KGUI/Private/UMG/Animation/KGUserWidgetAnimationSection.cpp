// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Animation/KGUserWidgetAnimationSection.h"

#include "MovieScene.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "UMG/Animation/KGUserWidgetAnimationTrack.h"
#include "Animation/MovieSceneUMGComponentTypes.h"
#include "Animation/WidgetAnimation.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Core/Common.h"
#include "UMG/Blueprint/KGUserWidget.h"

bool GPlayMainAndSubAnimAtTheSameTime = false;
FAutoConsoleVariableRef CVarAnimationBudgetMs(
	TEXT("UMG.PlayMainAndSubAnimAtTheSameTime"),
	GPlayMainAndSubAnimAtTheSameTime,
	TEXT("(Default: false)")
);

UKGUserWidgetAnimationSection::UKGUserWidgetAnimationSection(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	EvalOptions.EnableAndSetCompletionMode
	(GetLinkerCustomVersion(FSequencerObjectVersion::GUID) < FSequencerObjectVersion::WhenFinishedDefaultsToRestoreState ?
		EMovieSceneCompletionMode::KeepState :
		GetLinkerCustomVersion(FSequencerObjectVersion::GUID) < FSequencerObjectVersion::WhenFinishedDefaultsToProjectDefault ?
		EMovieSceneCompletionMode::RestoreState :
		EMovieSceneCompletionMode::ProjectDefault);
	BlendType = EMovieSceneBlendType::Relative;
	bSupportsInfiniteRange = true;

	FMovieSceneChannelProxyData Channels;

	//显示一个stringchannel
#if WITH_EDITOR
	//static FSubUIEditorData EditorData;
	//Channels.Add(Subtitle, EditorData.MetaData[0], EditorData.ExternalValues[0]);

#else //动行时
	//Channels.Add(Subtitle);
#endif

	ChannelProxy = MakeShared<FMovieSceneChannelProxy>(MoveTemp(Channels));
}

FString UKGUserWidgetAnimationSection::GetTitle()
{
	UEnum* const CompileModeEnum = StaticEnum<EUMGSequencePlayMode::Type>();
	auto AnimationName = this->AnimName;
	if (AnimationName.EndsWith(TEXT("_INST")))
	{
		AnimationName = AnimationName.LeftChop(5);
	}
	if (CompileModeEnum)
	{
		FString PlayModeDisplayContent;
		if (PlayMode != EUMGSequencePlayMode::Forward)
		{
			PlayModeDisplayContent =  FString::Printf(TEXT(" (模式: %s)"), *CompileModeEnum->GetDisplayNameTextByValue(PlayMode).ToString());
		}
		else
		{
			// 通常都是`EUMGSequencePlayMode::Forward`，这时候就不显示了，解决一些显示长度
			PlayModeDisplayContent = FString();
		}

		switch (this->ActionType)
		{
			case EKGUserWidgetAnimationActionType::PlayWithNum:
			{
				return FString::Printf(TEXT("播放%s动画 %d 次%s"), *AnimationName, this->LoopNum, *PlayModeDisplayContent);
			}
			case EKGUserWidgetAnimationActionType::PlayLoop:
			{
				return FString::Printf(TEXT("↺ 循环播放%s动画%s"), *AnimationName, *PlayModeDisplayContent);
			}
			case EKGUserWidgetAnimationActionType::PlayWithRange:
			{
				return FString::Printf(TEXT("在区间内播放%s动画%s"), *AnimationName, *PlayModeDisplayContent);
			}
			case EKGUserWidgetAnimationActionType::Stop:
			{
				return FString::Printf(TEXT("■ 停止%s动画"), *AnimationName);
			}
		};
	}
	return FString::Printf(TEXT("%s"), *AnimationName);
}

//FString UKGUserWidgetAnimationSection::GetSubtitle(FFrameTime Time) const
//{
//	if (Subtitle.GetNumKeys() > 0)
//	{
//		return *Subtitle.Evaluate(Time);
//	}
//	return FString();
//}

#if WITH_EDITOR
void UKGUserWidgetAnimationSection::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	//static const FName NAME_LoopNum = GET_MEMBER_NAME_CHECKED(UKGUserWidgetAnimationSection, LoopNum);
	//static const FName NAME_PlayMode = GET_MEMBER_NAME_CHECKED(UKGUserWidgetAnimationSection, PlayMode);
	//static const FName NAME_ActionType = GET_MEMBER_NAME_CHECKED(UKGUserWidgetAnimationSection, ActionType);
	//if (PropertyChangedEvent.Property != nullptr)
	//{
	//	if (PropertyChangedEvent.Property->GetFName() == NAME_LoopNum ||
	//		PropertyChangedEvent.Property->GetFName() == NAME_PlayMode ||
	//		PropertyChangedEvent.Property->GetFName() == NAME_ActionType)
	//	{
	//		UpdateProperties();
	//	}
	//}
}

void UKGUserWidgetAnimationSection::UpdateProperties(UWidgetAnimation* Animation)
{
	UMovieSceneTrack* Track = GetTypedOuter<UMovieSceneTrack>();
	UMovieScene* MovieScene = Track != nullptr ? Track->GetTypedOuter<UMovieScene>() : nullptr;
	if (this->LoopNum == 0)
	{
		this->Modify();
		this->LoopNum = 1;
		this->ActionType = EKGUserWidgetAnimationActionType::PlayLoop;
	}
	switch (this->ActionType)
	{
	case EKGUserWidgetAnimationActionType::PlayWithNum:
		{
			if (Animation != nullptr)
			{
				TRange<FFrameNumber> PlaybackRange = Animation->MovieScene->GetPlaybackRange();
				auto Range = this->GetRange();
				if (Range.HasLowerBound() && Range.HasUpperBound())
                {
                    Range.SetUpperBoundValue(Range.GetLowerBoundValue() + (PlaybackRange.GetUpperBoundValue() - PlaybackRange.GetLowerBoundValue()) * this->LoopNum);	
                }
				if (Range != this->GetRange())
				{
					this->Modify();
					this->SetRange(Range);
				}
			}
			break;
		}
	case EKGUserWidgetAnimationActionType::PlayWithRange:
		{
			break;
		}
	case EKGUserWidgetAnimationActionType::PlayLoop:
		{
			break;
		}
	case EKGUserWidgetAnimationActionType::Stop:
		{
			break;
		}
	}
}

#endif

void UKGUserWidgetAnimationSection::ComputeInitialUserWidgetAnims(UUserWidget* UserWidget)
{
	UWidgetBlueprintGeneratedClass* NewClass = UserWidget->GetWidgetTreeOwningClass();
	bool Found = false;
	for (UWidgetAnimation* WidgetAnimation : NewClass->Animations)
	{
		const FString& Name = WidgetAnimation->GetName();
		if (Name == AnimName)
		{
			Found = true;
			break;
		}
	}
	if (!Found)
	{
		UE_LOG(LogTemp, Error, TEXT("Can not find anim:%s in ui %s"), *AnimName, *UserWidget->GetName());
	}
}

void UKGUserWidgetAnimationSection::PlayAction(UKGUserWidget* UserWidget, EKGUserWidgetAnimationSectionPosition SectionPosition) const
{
	//FString Text = Section->GetSubtitle(Time);
	UWidgetBlueprintGeneratedClass* WidgetBlueprintGeneratedClass = UserWidget->GetWidgetTreeOwningClass();

	const auto& TempAnimName = this->AnimName;
	auto* FoundAnimation = WidgetBlueprintGeneratedClass->Animations.FindByPredicate([TempAnimName](const auto& Animation) { return Animation->GetMovieScene()->GetName() + "_INST" == TempAnimName; });
	if (FoundAnimation == nullptr || *FoundAnimation == nullptr)
	{
		UE_LOG(LogKGUI, Error, TEXT("控件蓝图`%s`中找不到名为`%s`的动画！"), *UserWidget->GetName(), *this->AnimName);
		return;
	}
	auto Animation = *FoundAnimation;
	ensure(Animation);

	FFrameNumber FN = this->GetInclusiveStartFrame();
	bool bDT = UserWidget->IsDesignTime();

	switch (this->ActionType)
	{
	case EKGUserWidgetAnimationActionType::PlayWithNum:
		{
			if (SectionPosition == EKGUserWidgetAnimationSectionPosition::Start)
			{
				//仅仅开启了这个功能并且起始帧是0 并且非UMG设计状态（编辑器下）的才会跟着主动画一起播放
				if (GPlayMainAndSubAnimAtTheSameTime == true && FN <= 0 && bDT == false)
				{

				}
				else
				{
					UserWidget->PlaySubAnimation(Animation, 0, this->LoopNum, this->PlayMode, 1.0, false);
				}
				
			}
			break;
		}
	case EKGUserWidgetAnimationActionType::PlayLoop:
		{
			if (SectionPosition == EKGUserWidgetAnimationSectionPosition::Start)
			{
				//仅仅开启了这个功能并且起始帧是0 并且非UMG设计状态（编辑器下）的才会跟着主动画一起播放
				if (GPlayMainAndSubAnimAtTheSameTime == true && FN == 0 && bDT == false)
				{

				}
				else
				{
					UserWidget->PlaySubAnimation(Animation, 0, 0, this->PlayMode, 1.0, false);
				}
			}
			else if (SectionPosition == EKGUserWidgetAnimationSectionPosition::End)
			{
			}
			break;
		}
	case EKGUserWidgetAnimationActionType::PlayWithRange:
		{
			if (SectionPosition == EKGUserWidgetAnimationSectionPosition::Start)
			{
				// UserWidget->StopAnimation(Animation);
				auto Range = GetRange();
				auto RangeDuration = Range.GetUpperBoundValue() - Range.GetLowerBoundValue();
				TRange<FFrameNumber> PlaybackRange = Animation->MovieScene->GetPlaybackRange();
				auto RangeLoopNum =FMath::CeilToInt((float)RangeDuration.Value / (PlaybackRange.GetUpperBoundValue() - PlaybackRange.GetLowerBoundValue()).Value);

				//仅仅开启了这个功能并且起始帧是0 并且非UMG设计状态（编辑器下）的才会跟着主动画一起播放
				if (GPlayMainAndSubAnimAtTheSameTime == true && FN == 0 && bDT == false)
				{

				}
				else
				{
					UserWidget->PlaySubAnimation(Animation, 0, RangeLoopNum, this->PlayMode, 1.0, false);
				}
				
			}
			else if (SectionPosition == EKGUserWidgetAnimationSectionPosition::End)
			{
				UserWidget->StopAnimation(Animation);
			}
			break;
		}
	case EKGUserWidgetAnimationActionType::Stop:
		{
			if (SectionPosition == EKGUserWidgetAnimationSectionPosition::Start)
			{
				UserWidget->StopAnimation(Animation);
			}
			break;
		}
	}
}
