#include "UMG/Animation/Line/KGBezierPointSection.h"

#include "Animation/MovieSceneUMGComponentTypes.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "EntitySystem/MovieSceneEntitySystemLinker.h"
#include "Tracks/MovieScenePropertyTrack.h"
#include "UMG/Animation/KGSequencerComponentTypes.h"
#include "UMG/Animation/Line/KGBezierPointTrack.h"

#if WITH_EDITOR
struct FKGBezierPointSectionEditorData
{
	FKGBezierPointSectionEditorData(EKGBezierPointChannel Mask)
	{
		MetaData.AddDefaulted(KGLINE_MAX_POINTS);
		ExternalValues.AddDefaulted(KGLINE_MAX_POINTS);

		FText PointGroup = NSLOCTEXT("BezierPointSection", "Point", "Point");
		FText ControlGroup = NSLOCTEXT("BezierPointSection", "Control", "Control");

		MetaData[0].SetIdentifiers("Position.X", FCommonChannelData::ChannelX, PointGroup);
		MetaData[0].SubPropertyPath = MetaData[0].Name;
		MetaData[0].bEnabled = EnumHasAllFlags(Mask, EKGBezierPointChannel::PositionX);
		MetaData[0].SortOrder = 0;
		MetaData[0].bCanCollapseToTrack = false;

		MetaData[1].SetIdentifiers("Position.Y", FCommonChannelData::ChannelY, PointGroup);
		MetaData[1].SubPropertyPath = MetaData[1].Name;
		MetaData[1].bEnabled = EnumHasAllFlags(Mask, EKGBezierPointChannel::PositionY);
		MetaData[1].SortOrder = 1;
		MetaData[1].bCanCollapseToTrack = false;

		MetaData[2].SetIdentifiers("Control.X", FCommonChannelData::ChannelX, ControlGroup);
		MetaData[2].SubPropertyPath = MetaData[2].Name;
		MetaData[2].bEnabled = EnumHasAllFlags(Mask, EKGBezierPointChannel::ControlPointX);
		MetaData[2].SortOrder = 2;
		MetaData[2].bCanCollapseToTrack = false;

		MetaData[3].SetIdentifiers("Control.Y", FCommonChannelData::ChannelY, ControlGroup);
		MetaData[3].SubPropertyPath = MetaData[3].Name;
		MetaData[3].bEnabled = EnumHasAllFlags(Mask, EKGBezierPointChannel::ControlPointY);
		MetaData[3].SortOrder = 3;
		MetaData[3].bCanCollapseToTrack = false;

		ExternalValues[0].OnGetExternalValue = ExtractPointX;
		ExternalValues[1].OnGetExternalValue = ExtractPointY;
		ExternalValues[2].OnGetExternalValue = ExtractControlX;
		ExternalValues[3].OnGetExternalValue = ExtractControlY;
	}

	static TOptional<float> ExtractPointX(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		return Bindings ? Bindings->GetCurrentValue<FKGBezierPoint>(InObject).Position.X : TOptional<float>();
	}
	static TOptional<float> ExtractPointY(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		return Bindings ? Bindings->GetCurrentValue<FKGBezierPoint>(InObject).Position.Y : TOptional<float>();
	}

	static TOptional<float> ExtractControlX(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		return Bindings ? Bindings->GetCurrentValue<FKGBezierPoint>(InObject).ControlPoint.X : TOptional<float>();
	}
	static TOptional<float> ExtractControlY(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		return Bindings ? Bindings->GetCurrentValue<FKGBezierPoint>(InObject).ControlPoint.Y : TOptional<float>();
	}

	TArray<FMovieSceneChannelMetaData>      MetaData;
	TArray<TMovieSceneExternalValue<float>> ExternalValues;
};

#endif	// WITH_EDITOR

UKGBezierPointSection::UKGBezierPointSection(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	EvalOptions.EnableAndSetCompletionMode
	(GetLinkerCustomVersion(FSequencerObjectVersion::GUID) < FSequencerObjectVersion::WhenFinishedDefaultsToRestoreState ?
		EMovieSceneCompletionMode::KeepState :
		GetLinkerCustomVersion(FSequencerObjectVersion::GUID) < FSequencerObjectVersion::WhenFinishedDefaultsToProjectDefault ?
		EMovieSceneCompletionMode::RestoreState :
		EMovieSceneCompletionMode::ProjectDefault);

	ActiveMask = EKGBezierPointChannel::All;

	BlendType = EMovieSceneBlendType::Absolute;
	bSupportsInfiniteRange = true;
}

FKGBezierPointMask UKGBezierPointSection::GetMask() const
{
	return ActiveMask;
}

void UKGBezierPointSection::SetMask(FKGBezierPointMask NewMask)
{
	ActiveMask = NewMask;
	ChannelProxy = nullptr;
}

EMovieSceneChannelProxyType UKGBezierPointSection::CacheChannelProxy()
{
	FMovieSceneChannelProxyData Channels;
#if WITH_EDITOR
	FKGBezierPointSectionEditorData EditorData(ActiveMask.GetChannels());

	Channels.Add(ChannelPositionX, EditorData.MetaData[0], EditorData.ExternalValues[0]);
	Channels.Add(ChannelPositionY, EditorData.MetaData[1], EditorData.ExternalValues[1]);
	Channels.Add(ChannelControlPointX, EditorData.MetaData[2], EditorData.ExternalValues[2]);
	Channels.Add(ChannelControlPointY, EditorData.MetaData[3], EditorData.ExternalValues[3]);
#else
	Channels.Add(ChannelPositionX);
	Channels.Add(ChannelPositionY);
	Channels.Add(ChannelControlPointX);
	Channels.Add(ChannelControlPointY);
#endif

	ChannelProxy = MakeShared<FMovieSceneChannelProxy>(MoveTemp(Channels));
	return EMovieSceneChannelProxyType::Dynamic;
}

FKGBezierPointMask UKGBezierPointSection::GetMaskByName(const FName& InName) const
{
	FKGBezierPointMask Mask;
	Mask.ActiveChannels = static_cast<uint32>(EKGBezierPointChannel::None);

	if (InName == TEXT("Position"))
	{
		Mask.ActiveChannels = static_cast<uint32>(EKGBezierPointChannel::PositionX | EKGBezierPointChannel::PositionY);
	}
	else if (InName == TEXT("Position.X"))
	{
		Mask.ActiveChannels = static_cast<uint32>(EKGBezierPointChannel::PositionX);
	}
	else if (InName == TEXT("Position.Y"))
	{
		Mask.ActiveChannels = static_cast<uint32>(EKGBezierPointChannel::PositionY);
	}
	else if (InName == TEXT("ControlPoint"))
	{
		Mask.ActiveChannels = static_cast<uint32>(EKGBezierPointChannel::ControlPointX | EKGBezierPointChannel::ControlPointY);
	}
	else if (InName == TEXT("ControlPoint.X"))
	{
		Mask.ActiveChannels = static_cast<uint32>(EKGBezierPointChannel::ControlPointX);
	}
	else if (InName == TEXT("ControlPoint.Y"))
	{
		Mask.ActiveChannels = static_cast<uint32>(EKGBezierPointChannel::ControlPointY);
	}

	return Mask;
}

FKGBezierPoint UKGBezierPointSection::GetCurrentValue(const UObject* Object) const
{
	UKGBezierPointTrack* Track = GetTypedOuter<UKGBezierPointTrack>();
	return Track->GetCurrentValue<FKGBezierPoint>(Object).Get(FKGBezierPoint{});
}

FKGBezierPoint UKGBezierPointSection::Eval(FFrameTime Time, const FKGBezierPoint& DefaultValue) const
{
	FKGBezierPoint Result = DefaultValue;

	float PosX = DefaultValue.Position.X;
	float PosY = DefaultValue.Position.Y;
	float CtrlX = DefaultValue.ControlPoint.X;
	float CtrlY = DefaultValue.ControlPoint.Y;

	if (ActiveMask.IsChannelActive(EKGBezierPointChannel::PositionX))
	{
		ChannelPositionX.Evaluate(Time, PosX);
	}
	if (ActiveMask.IsChannelActive(EKGBezierPointChannel::PositionY))
	{
		ChannelPositionY.Evaluate(Time, PosY);
	}
	if (ActiveMask.IsChannelActive(EKGBezierPointChannel::ControlPointX))
	{
		ChannelControlPointX.Evaluate(Time, CtrlX);
	}
	if (ActiveMask.IsChannelActive(EKGBezierPointChannel::ControlPointY))
	{
		ChannelControlPointY.Evaluate(Time, CtrlY);
	}

	Result.Position.X = PosX;
	Result.Position.Y = PosY;
	Result.ControlPoint.X = CtrlX;
	Result.ControlPoint.Y = CtrlY;

	// UV is not animated by this section currently

	return Result;
}

void UKGBezierPointSection::ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity)
{
	using namespace UE::MovieScene;

	// This section requires the property system
	UKGBezierPointTrack* Track = GetTypedOuter<UKGBezierPointTrack>();
	if (!Track)
	{
		return;
	}

	EKGBezierPointChannel Channels = ActiveMask.GetChannels();
	FBuiltInComponentTypes* Components = FBuiltInComponentTypes::Get();
	KGUI::FKGSequencerComponentTypes* UMGComponents = KGUI::FKGSequencerComponentTypes::Get();

	const bool ActiveChannelsMask[] = {
		EnumHasAllFlags(Channels, EKGBezierPointChannel::PositionX) && ChannelPositionX.HasAnyData(),
		EnumHasAllFlags(Channels, EKGBezierPointChannel::PositionY) && ChannelPositionY.HasAnyData(),
		EnumHasAllFlags(Channels, EKGBezierPointChannel::ControlPointX) && ChannelControlPointX.HasAnyData(),
		EnumHasAllFlags(Channels, EKGBezierPointChannel::ControlPointY) && ChannelControlPointY.HasAnyData()
	};

	if (!Algo::AnyOf(ActiveChannelsMask))
	{
		// None active track.
		return;
	}

	FGuid ObjectBindingID = Params.GetObjectBindingID();
	OutImportedEntity->AddBuilder(
		FEntityBuilder()
		.Add(Components->PropertyBinding, Track->GetPropertyBinding())
		.AddConditional(Components->GenericObjectBinding, ObjectBindingID, ObjectBindingID.IsValid())
		.AddConditional(Components->FloatChannel[0], &ChannelPositionX, ActiveChannelsMask[0])
		.AddConditional(Components->FloatChannel[1], &ChannelPositionY, ActiveChannelsMask[1])
		.AddConditional(Components->FloatChannel[2], &ChannelControlPointX, ActiveChannelsMask[2])
		.AddConditional(Components->FloatChannel[3], &ChannelControlPointY, ActiveChannelsMask[3])
		.AddTag(UMGComponents->BezierPoint.PropertyTag)
	);
} 