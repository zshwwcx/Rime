﻿#include "UMG/Animation//NiagaraUI/KGNiagaraUIFloatParameterSectionTemplate.h"
#include "NiagaraTypes.h"

FKGNiagaraUIFloatParameterSectionTemplate::FKGNiagaraUIFloatParameterSectionTemplate()
{
}

FKGNiagaraUIFloatParameterSectionTemplate::FKGNiagaraUIFloatParameterSectionTemplate(FNiagaraVariable InParameter, const FMovieSceneFloatChannel& InFloatChannel)
	: FKGNiagaraUIParameterSectionTemplate(InParameter)
	, FloatChannel(InFloatChannel)
{
}

void FKGNiagaraUIFloatParameterSectionTemplate::GetAnimatedParameterValue(FFrameTime InTime, const FNiagaraVariableBase& InTargetParameter, const TArray<uint8>& InCurrentValueData, TArray<uint8>& OutAnimatedValueData) const
{
	FNiagaraFloat const* CurrentValue = (FNiagaraFloat const*)InCurrentValueData.GetData();
	FNiagaraFloat AnimatedValue = *CurrentValue;

	FloatChannel.Evaluate(InTime, AnimatedValue.Value);

	OutAnimatedValueData.AddUninitialized(sizeof(FNiagaraFloat));
	FMemory::Memcpy(OutAnimatedValueData.GetData(), (uint8*)&AnimatedValue, sizeof(FNiagaraFloat));
}