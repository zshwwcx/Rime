// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Animation/KGAudioTrack.h"
#include "UMG/Animation/KGAudioEvalTemplate.h"
#include "UMG/Animation/KGAudioSection.h"
#include "Evaluation/MovieSceneEvaluationTrack.h"
#include "IMovieSceneTracksModule.h"
#include "MovieSceneSequencePlayer.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(KGAudioTrack)

UKGAudioTrack::UKGAudioTrack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	//SupportedBlendTypes.Add(EMovieSceneBlendType::Absolute);
	//bSupportsDefaultSections = false;
#if WITH_EDITORONLY_DATA
	TrackTint = FColor(48, 227, 255, 65);
#endif
}

bool UKGAudioTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UKGAudioSection::StaticClass();
}

#if WITH_EDITORONLY_DATA
FText UKGAudioTrack::GetDisplayName() const
{
	return NSLOCTEXT("KGAudioTrack", "KGAudioTrack", "KGAudioTrack");
}

FText UKGAudioTrack::GetTrackRowDisplayName(int32 RowIndex) const
{
	return FText::FromString(FString::Printf(TEXT("KGAudioEvents%d"), RowIndex));
}

#endif

FMovieSceneEvalTemplatePtr UKGAudioTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FKGAudioEvalTemplate(CastChecked<const UKGAudioSection>(&InSection));
}

void UKGAudioTrack::PostCompile(FMovieSceneEvaluationTrack& Track, const FMovieSceneTrackCompilerArgs& Args) const
{
	Track.SetEvaluationGroup(IMovieSceneTracksModule::GetEvaluationGroupName(EBuiltInEvaluationGroup::PostEvaluation));
	Track.SetEvaluationMethod(EEvaluationMethod::Swept);
}

UMovieSceneSection* UKGAudioTrack::CreateNewSection()
{
	return NewObject<UMovieSceneSection>(this, UKGAudioSection::StaticClass(), NAME_None, RF_Transactional);
}

FName UKGAudioTrack::GetTrackName() const
{
	static FName TrackName("KGAudioTrack");
	return TrackName;
}

