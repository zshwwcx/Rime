﻿#include "UMG/Animation/NiagaraUI/KGNiagaraUIIntegerParameterSectionTemplate.h"
#include "NiagaraTypes.h"


FKGNiagaraUIIntegerParameterSectionTemplate::FKGNiagaraUIIntegerParameterSectionTemplate()
{
}

FKGNiagaraUIIntegerParameterSectionTemplate::FKGNiagaraUIIntegerParameterSectionTemplate(FNiagaraVariable InParameter, const FMovieSceneIntegerChannel& InIntegerChannel)
	: FKGNiagaraUIParameterSectionTemplate(InParameter)
	, IntegerChannel(InIntegerChannel)
{
}

void FKGNiagaraUIIntegerParameterSectionTemplate::GetAnimatedParameterValue(FFrameTime InTime, const FNiagaraVariableBase& InTargetParameter, const TArray<uint8>& InCurrentValueData, TArray<uint8>& OutAnimatedValueData) const
{
	FNiagaraInt32 const* CurrentValue = (FNiagaraInt32 const*)InCurrentValueData.GetData();
	FNiagaraInt32 AnimatedValue = *CurrentValue;

	IntegerChannel.Evaluate(InTime, AnimatedValue.Value);

	OutAnimatedValueData.AddUninitialized(sizeof(FNiagaraInt32));
	FMemory::Memcpy(OutAnimatedValueData.GetData(), (uint8*)&AnimatedValue, sizeof(FNiagaraInt32));
}
