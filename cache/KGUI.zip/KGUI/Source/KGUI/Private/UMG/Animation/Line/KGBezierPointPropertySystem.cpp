#include "UMG/Animation/Line/KGBezierPointPropertySystem.h"
#include "UMG/Components/KGLine.h" // For FKGBezierPoint

#include "Systems/FloatChannelEvaluatorSystem.h"
#include "Systems/MovieScenePiecewiseDoubleBlenderSystem.h"
#include "UMG/Animation/KGSequencerComponentTypes.h"

UKGBezierPointPropertySystem::UKGBezierPointPropertySystem(const FObjectInitializer& ObjInitializer)
	: Super(ObjInitializer)
{
	BindToProperty(KGUI::FKGSequencerComponentTypes::Get()->BezierPoint);

	if (HasAnyFlags(RF_ClassDefaultObject))
	{
		DefineImplicitPrerequisite(UMovieScenePiecewiseDoubleBlenderSystem::StaticClass(), GetClass());
		DefineImplicitPrerequisite(UFloatChannelEvaluatorSystem::StaticClass(), GetClass());
	}
}

// This is a simplified OnRun, a full implementation would use the Entity-Component-System (ECS)
// to iterate over entities with FKGBezierPoint channels and apply the evaluated values.
void UKGBezierPointPropertySystem::OnRun(FSystemTaskPrerequisites& InPrerequisites, FSystemSubsequentTasks& Subsequents)
{
	using namespace UE::MovieScene;

	// This is a very basic example of how one might apply values.
	// A full implementation would use FMovieSceneContext, query components, and apply values efficiently.
	// For struct properties, the system usually breaks them down into individual float components in the ECS.

	// Example: Iterate through entities that have the FKGBezierPointPropertyTag and relevant channels.
	// This is pseudo-code and needs to be adapted to the actual ECS query and component structure.
	/*
	FMovieSceneContext Context = GetLinker()->GetContext();
	FMovieSceneEntityManager* EntityManager = GetLinker()->GetEntityManager();

	TSharedPtr<FObjectPropertyExtender> Extender = GetLinker()->FindExtension<FObjectPropertyExtender>();
	if (!Extender) { return; }

	// A more specific query for entities with our component tags would be needed.
	EntityManager->IterateEntities(Query(),
		[&](FMovieSceneEntityID EntityID, TRead<FGuid> ObjectBindingID, TRead<UObject*> BoundObject, TRead<FMovieSceneChannelValue<float>> PositionX, ...)
		{
			UObject* Object = BoundObject.Resolve(Extender->ObjectManager);
			UKGLine* LineWidget = Cast<UKGLine>(Object);
			if (LineWidget)
			{
				// Assuming PropertyName from the track has been correctly mapped to an entity property (e.g., Point1, Point2)
				// This part is complex and depends on how the track and property system are fully integrated.
				// For example, you might have a component on the entity that stores the FName of the Point (Point1, Point2 etc)
				// and another component for each channel value (PosX, PosY, CtrlX, CtrlY).

				// Placeholder: A real implementation would get the correct point based on entity data.
				FKGBezierPoint* TargetPoint = nullptr; 
				// if (property name on entity == "Point1") TargetPoint = &LineWidget->Point1;

				if (TargetPoint)
				{
					TargetPoint->Position.X = PositionX;
					// ... set other components ...
					LineWidget->SynchronizeProperties(); // Or a more targeted update
				}
			}
		});
	*/
	Super::OnRun(InPrerequisites, Subsequents); // Call if your system needs the base functionality
}

// Note: The PropertySystem for complex structs like FKGBezierPoint can be intricate.
// Unreal Engine's approach for FVector, FColor, FTransform etc. often involves breaking them down
// into individual float components at the Entity-Component-System level.
// UMovieScenePropertySystem has helpers like FSystemSubsequentTasks::Job and TEntityRangeBuilder
// for efficient processing. The above OnRun is a conceptual placeholder.
// A full implementation would require careful setup of Components for each channel of FKGBezierPoint
// (e.g., FKGBezierPointPositionXComponent, FKGBezierPointPositionYComponent, etc.)
// and then a system that reads these components and applies them to the target FKGBezierPoint struct property. 