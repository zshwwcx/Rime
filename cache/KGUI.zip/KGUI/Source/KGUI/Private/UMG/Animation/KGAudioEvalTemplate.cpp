#include "UMG/Animation/KGAudioEvalTemplate.h"
#include "UMG/Animation/KGAudioExecutionToken.h"

struct FKGAudioEventEvaluationData : IPersistentEvaluationData
{
	bool bExecuted = false;
};

FKGAudioEvalTemplate::FKGAudioEvalTemplate()
{
}

FKGAudioEvalTemplate::FKGAudioEvalTemplate(const UKGAudioSection* InSection)
	: Section(InSection)
{
}

void FKGAudioEvalTemplate::EvaluateSwept(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const TRange<FFrameNumber>& SweptRange, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	if (Context.GetDirection() == EPlayDirection::Backwards)
	{
		return;
	}

	if (Context.GetStatus() == EMovieScenePlayerStatus::Stopped || Context.IsSilent())
	{
		return;
	}

	if (!Section)
	{
		return;
	}

	if (FKGAudioEventEvaluationData* SectionData = PersistentData.FindSectionData<FKGAudioEventEvaluationData>())
	{
		const TRange<FFrameNumber>& SectionRange = Section->GetRange();
		if (SweptRange.Overlaps(SectionRange))
		{
			if (!SectionData->bExecuted)
			{
				SectionData->bExecuted = true;
				ExecutionTokens.Add(FKGAudioExecutionToken(Section));
			}
		}	
	}
}

void FKGAudioEvalTemplate::Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	if (Section)
	{
		PersistentData.AddSectionData<FKGAudioEventEvaluationData>();
	}
}
