// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Animation/KGUserWidgetAnimationTrack.h"
#include "UMG/Animation/KGUserWidgetAnimationEvalTemplate.h"
#include "UMG/Animation/KGUserWidgetAnimationSection.h"
#include "Evaluation/MovieSceneEvaluationTrack.h"
#include "IMovieSceneTracksModule.h"
#include "MovieSceneSequencePlayer.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(KGUserWidgetAnimationTrack)

UKGUserWidgetAnimationTrack::UKGUserWidgetAnimationTrack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	//SupportedBlendTypes.Add(EMovieSceneBlendType::Absolute);
	//bSupportsDefaultSections = false;
#if WITH_EDITORONLY_DATA
	TrackTint = FColor(48, 227, 255, 65);
#endif
}

bool UKGUserWidgetAnimationTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UKGUserWidgetAnimationSection::StaticClass();
}

#if WITH_EDITORONLY_DATA
FText UKGUserWidgetAnimationTrack::GetDisplayName() const
{
	if (InitialUserWidget)
	{
		// TODO: 这里没有用起来，找时间结合后面注释的代码看看这里
		return FText::FromString(FString::Printf(TEXT("%s Animations"), *InitialUserWidget->GetName()));
	}

	bool bOnlySingleRow = true;
	TSet<FString> AnimationNames;
	for (auto Section : this->GetAllSections())
	{
		if (Section == nullptr)
		{
			continue;
		}
		if (Section->GetRowIndex() != 0)
		{
			bOnlySingleRow = false;
		}
		auto UserWidgetAnimationSection = Cast<UKGUserWidgetAnimationSection>(Section);
		AnimationNames.Add(UserWidgetAnimationSection->AnimName);
	}

	if (AnimationNames.Num() == 0)
	{
		return NSLOCTEXT("KGUserWidgetAnimationTrack", "UserWidgetAnimationTrackTitle_NoSectionAdded", "动画列表 (没有添加片段)");
	}
	else if (bOnlySingleRow)
	{
		auto Title = FText::FromString(AnimationNames.Num() <= 1 ? TEXT("动画") : TEXT("动画列表"));
		return FText::Format(
			NSLOCTEXT("KGUserWidgetAnimationTrack", "UserWidgetAnimationTrackTitle_OneSectionAdded", "{0}: {1}"),
			{ Title, GetTrackRowDisplayName(0) }
		);
	}
	else
	{
		return NSLOCTEXT("KGUserWidgetAnimationTrack", "UserWidgetAnimationTrackTitle_Multiple", "动画列表");
	}
}

FText UKGUserWidgetAnimationTrack::GetTrackRowDisplayName(int32 RowIndex) const
{
	FString DisplayNameBuilder;
	TSet<FString> AnimationNames;
	for (auto Section : this->GetAllSections())
	{
		if (Section->GetRowIndex() != RowIndex)
		{
			continue;
		}
		auto UserWidgetAnimationSection = Cast<UKGUserWidgetAnimationSection>(Section);
		auto AnimationName = UserWidgetAnimationSection->AnimName;
		if (AnimationName.EndsWith(TEXT("_INST")))
		{
			AnimationName = AnimationName.LeftChop(5);
		}
		if (AnimationNames.Contains(AnimationName))
		{
			continue;
		}
		AnimationNames.Add(AnimationName);
		if (!DisplayNameBuilder.IsEmpty())
		{
			DisplayNameBuilder += ", ";
		}
		DisplayNameBuilder += AnimationName;
	}

	/*if(RowIndex < SectionNames.Num())
	{
		return FText::FromString(SectionNames[RowIndex]);
	}*/

	if (DisplayNameBuilder.IsEmpty())
	{
		DisplayNameBuilder = "该行没有片段";
	}
	return FText::FromString(DisplayNameBuilder);
}

#endif

FMovieSceneEvalTemplatePtr UKGUserWidgetAnimationTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FKGUserWidgetAnimationEvalTemplate(CastChecked<const UKGUserWidgetAnimationSection>(&InSection));
}

void UKGUserWidgetAnimationTrack::PostCompile(FMovieSceneEvaluationTrack& Track, const FMovieSceneTrackCompilerArgs& Args) const
{
	Track.SetEvaluationGroup(IMovieSceneTracksModule::GetEvaluationGroupName(EBuiltInEvaluationGroup::PostEvaluation));
	Track.SetEvaluationMethod(EEvaluationMethod::Swept);
}

UMovieSceneSection* UKGUserWidgetAnimationTrack::CreateNewSection()
{
	return NewObject<UMovieSceneSection>(this, UKGUserWidgetAnimationSection::StaticClass(), NAME_None, RF_Transactional);
}

FName UKGUserWidgetAnimationTrack::GetTrackName() const
{
	static FName TrackName("KGUserWidgetAnimation");
	return TrackName;
}

#if WITH_EDITOR
EMovieSceneSectionMovedResult UKGUserWidgetAnimationTrack::OnSectionMoved(UMovieSceneSection& Section, const FMovieSceneSectionMovedParams& Params)
{
	return EMovieSceneSectionMovedResult::None;
}

/*void UKGUserWidgetAnimationTrack::PreCompileImpl(FMovieSceneTrackPreCompileResult& OutPreCompileResult)
{
	if (UserWidgetBindingID.IsValid())
	{
		UMovieScene* MovieScene = GetTypedOuter<UMovieScene>();
		check(MovieScene);

		for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
		{
			if (Binding.GetObjectGuid() == UserWidgetBindingID.GetGuid())
			{
				UWidgetAnimation* Sequence = GetTypedOuter<UWidgetAnimation>();
				TArray<UObject*, TInlineAllocator<1>> BoundObjects;
				Sequence->LocateBoundObjects(Binding.GetObjectGuid(), nullptr, BoundObjects);
				if (!BoundObjects.IsEmpty())
				{
					UObject* Object = BoundObjects[0];
					if (UUserWidget* NewUserWidget = Cast<UUserWidget>(Object))
					{
						InitialUserWidget = NewUserWidget;
						break;
					}
				}
			}
		}
	}
	if(InitialUserWidget)
	{
		for (UMovieSceneSection* Section : Sections)
		{
			if (UKGUserWidgetAnimationSection* KGUserWidgetAnimationSection = CastChecked<UKGUserWidgetAnimationSection>(Section))
			{
				KGUserWidgetAnimationSection->ComputeInitialUserWidgetAnims(InitialUserWidget);
			}
		}
	}
}*/

#endif
