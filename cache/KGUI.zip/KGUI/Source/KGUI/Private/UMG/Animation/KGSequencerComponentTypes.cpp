#include "UMG/Animation/KGSequencerComponentTypes.h"
#include "EntitySystem/BuiltInComponentTypes.h"
#include "EntitySystem/MovieSceneEntityFactoryTemplates.h"
#include "EntitySystem/MovieSceneEntitySystemLinker.h"
#include "EntitySystem/MovieScenePropertyComponentHandler.h"
#include "Systems/MovieScenePiecewiseDoubleBlenderSystem.h"
#include "Templates/UniquePtr.h"

namespace KGUI
{
	static bool GKGSequencerComponentTypesDestroyed = false;
	static TUniquePtr<FKGSequencerComponentTypes> GKGSequencerComponentTypes;

	void ConvertOperationalProperty(const FKGIntermediateBezierPoint& In, FKGBezierPoint& Out)
	{
		Out.Position.X = In.PointX;
		Out.Position.Y = In.PointY;
		Out.ControlPoint.X = In.ControlX;
		Out.ControlPoint.Y = In.ControlY;
	}
	void ConvertOperationalProperty(const FKGBezierPoint& In, FKGIntermediateBezierPoint& Out)
	{
		Out.PointX = In.Position.X;
		Out.PointY = In.Position.Y;
		Out.ControlX = In.ControlPoint.X;
		Out.ControlY = In.ControlPoint.Y;
	}

	static FKGIntermediateBezierPoint GetBezierPoint(const UObject* Object, int32 Index)
	{
		FKGBezierPoint Point = CastChecked<const UKGLine>(Object)->GetBezierPoint(Index);
		FKGIntermediateBezierPoint IntermediatePoint{};
		ConvertOperationalProperty(Point, IntermediatePoint);
		return IntermediatePoint;
	}

	static void SetBezierPoint(UObject* Object, int32 Index, const FKGIntermediateBezierPoint& InPoint)
	{
		FKGBezierPoint RealPoint{};
		ConvertOperationalProperty(InPoint, RealPoint);
		CastChecked<UKGLine>(Object)->SetBezierPoint(Index, RealPoint);
	}

	static FKGIntermediateBezierPoint GetBezierPoint1(const UObject* Object)
	{
		return GetBezierPoint(Object, 0);
	}
	static FKGIntermediateBezierPoint GetBezierPoint2(const UObject* Object)
	{
		return GetBezierPoint(Object, 1);
	}
	static FKGIntermediateBezierPoint GetBezierPoint3(const UObject* Object)
	{
		return GetBezierPoint(Object, 2);
	}
	static FKGIntermediateBezierPoint GetBezierPoint4(const UObject* Object)
	{
		return GetBezierPoint(Object, 3);
	}
	static void SetBezierPoint1(UObject* Object, const FKGIntermediateBezierPoint& InPoint)
	{
		SetBezierPoint(Object, 0, InPoint);
	}
	static void SetBezierPoint2(UObject* Object, const FKGIntermediateBezierPoint& InPoint)
	{
		SetBezierPoint(Object, 1, InPoint);
	}
	static void SetBezierPoint3(UObject* Object, const FKGIntermediateBezierPoint& InPoint)
	{
		SetBezierPoint(Object, 2, InPoint);
	}
	static void SetBezierPoint4(UObject* Object, const FKGIntermediateBezierPoint& InPoint)
	{
		SetBezierPoint(Object, 3, InPoint);
	}

	FKGSequencerComponentTypes::FKGSequencerComponentTypes()
	{
		UE::MovieScene::FBuiltInComponentTypes* BuiltInComponents = UE::MovieScene::FBuiltInComponentTypes::Get();
		UE::MovieScene::FComponentRegistry* ComponentRegistry = UMovieSceneEntitySystemLinker::GetComponents();

		ComponentRegistry->NewPropertyType(BezierPoint, TEXT("FKGBezierPoint Property"));

		CustomBezierPointAccessors.Add(UKGLine::StaticClass(), "Point1", &GetBezierPoint1, &SetBezierPoint1);
		CustomBezierPointAccessors.Add(UKGLine::StaticClass(), "Point2", &GetBezierPoint2, &SetBezierPoint2);
		CustomBezierPointAccessors.Add(UKGLine::StaticClass(), "Point3", &GetBezierPoint3, &SetBezierPoint3);
		CustomBezierPointAccessors.Add(UKGLine::StaticClass(), "Point4", &GetBezierPoint4, &SetBezierPoint4);

		BuiltInComponents->PropertyRegistry.DefineCompositeProperty(BezierPoint, TEXT("Call UKGLine::SetBezierPoint"))
			.AddComposite(BuiltInComponents->DoubleResult[0], &FKGIntermediateBezierPoint::PointX)
			.AddComposite(BuiltInComponents->DoubleResult[1], &FKGIntermediateBezierPoint::PointY)
			.AddComposite(BuiltInComponents->DoubleResult[2], &FKGIntermediateBezierPoint::ControlX)
			.AddComposite(BuiltInComponents->DoubleResult[3], &FKGIntermediateBezierPoint::ControlY)
			.SetBlenderSystem<UMovieScenePiecewiseDoubleBlenderSystem>()
			.SetCustomAccessors(&CustomBezierPointAccessors)
			.Commit();
	}

	FKGSequencerComponentTypes::~FKGSequencerComponentTypes()
	{
	}

	void FKGSequencerComponentTypes::Destroy()
	{
		GKGSequencerComponentTypes.Reset();
		GKGSequencerComponentTypesDestroyed = true;
	}

	FKGSequencerComponentTypes* FKGSequencerComponentTypes::Get()
	{
		if (!GKGSequencerComponentTypes.IsValid())
		{
			check(!GKGSequencerComponentTypesDestroyed);
			GKGSequencerComponentTypes.Reset(new FKGSequencerComponentTypes);
		}
		return GKGSequencerComponentTypes.Get();
	}
} // namespace KGUI
