﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Animation/NiagaraUI/KGNiagaraUIIntegerParameterTrack.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "Sections/MovieSceneIntegerSection.h"
#include "UMG/Animation/NiagaraUI/KGNiagaraUIIntegerParameterSectionTemplate.h"

bool UKGNiagaraUIIntegerParameterTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneIntegerSection::StaticClass();
}

UMovieSceneSection* UKGNiagaraUIIntegerParameterTrack::CreateNewSection()
{
	return NewObject<UMovieSceneIntegerSection>(this, NAME_None, RF_Transactional);
}

void UKGNiagaraUIIntegerParameterTrack::SetSectionChannelDefaults(UMovieSceneSection* Section, const TArray<uint8>& DefaultValueData) const
{
	UMovieSceneIntegerSection* IntegerSection = Cast<UMovieSceneIntegerSection>(Section);
	if (ensureMsgf(IntegerSection != nullptr, TEXT("Section must be an integer section.")) && ensureMsgf(DefaultValueData.Num() == sizeof(int32), TEXT("DefaultValueData must be an int32.")))
	{
		FMovieSceneChannelProxy& IntegerChannelProxy = IntegerSection->GetChannelProxy();
		int32 DefaultValue = *((int32*)DefaultValueData.GetData());
		SetChannelDefault(IntegerChannelProxy, IntegerSection->GetChannel(), DefaultValue);
	}
}

FMovieSceneEvalTemplatePtr UKGNiagaraUIIntegerParameterTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	const UMovieSceneIntegerSection* IntegerSection = Cast<UMovieSceneIntegerSection>(&InSection);
	if (IntegerSection != nullptr)
	{
		return FKGNiagaraUIIntegerParameterSectionTemplate(GetParameter(), IntegerSection->GetChannel());
	}
	return FMovieSceneEvalTemplatePtr();
}
