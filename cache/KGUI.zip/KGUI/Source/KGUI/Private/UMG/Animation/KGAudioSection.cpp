// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Animation/KGAudioSection.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "UMG/Animation/KGAudioTrack.h"
#include "Animation/MovieSceneUMGComponentTypes.h"

UKGAudioSection::UKGAudioSection(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	EvalOptions.EnableAndSetCompletionMode
	(GetLinkerCustomVersion(FSequencerObjectVersion::GUID) < FSequencerObjectVersion::WhenFinishedDefaultsToRestoreState ?
		EMovieSceneCompletionMode::KeepState :
		GetLinkerCustomVersion(FSequencerObjectVersion::GUID) < FSequencerObjectVersion::WhenFinishedDefaultsToProjectDefault ?
		EMovieSceneCompletionMode::RestoreState :
		EMovieSceneCompletionMode::ProjectDefault);
	BlendType = EMovieSceneBlendType::Relative;
	bSupportsInfiniteRange = true;

	FMovieSceneChannelProxyData Channels;

	//显示一个stringchannel
#if WITH_EDITOR
	/*static FAkAudioEditorData EditorData;
	Channels.Add(Subtitle, EditorData.MetaData[0], EditorData.ExternalValues[0]);*/

#else //动行时
	//Channels.Add(Subtitle);
#endif

	ChannelProxy = MakeShared<FMovieSceneChannelProxy>(MoveTemp(Channels));
}

FString UKGAudioSection::GetTitle()
{
	if(!Event)
	{
		return FString::Printf(TEXT("Unnamed Section, Please select Audio"));
	}
	return Event->GetName();
}

FString UKGAudioSection::GetSubtitle(FFrameTime Time) const
{
	/*if (Subtitle.GetNumKeys() > 0)
	{
		return *Subtitle.Evaluate(Time);
	}*/
	return FString();
}

void UKGAudioSection::SetEvent(UAkAudioEvent* AudioEvent)
{
	Event = AudioEvent;
}

UAkAudioEvent* UKGAudioSection::GetEvent() const
{
	return Event;
}

