﻿#include "UMG/Animation/NiagaraUI/KGNiagaraUIFloatParameterTrack.h"
#include "Sections/MovieSceneFloatSection.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "Templates/Casts.h"
#include "UMG/Animation/NiagaraUI/KGNiagaraUIFloatParameterSectionTemplate.h"

bool UKGNiagaraUIFloatParameterTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneFloatSection::StaticClass();
}

UMovieSceneSection* UKGNiagaraUIFloatParameterTrack::CreateNewSection()
{
	return NewObject<UMovieSceneFloatSection>(this, NAME_None, RF_Transactional);
}

void UKGNiagaraUIFloatParameterTrack::SetSectionChannelDefaults(UMovieSceneSection* Section, const TArray<uint8>& DefaultValueData) const
{
	UMovieSceneFloatSection* FloatSection = Cast<UMovieSceneFloatSection>(Section);
	if (ensureMsgf(FloatSection != nullptr, TEXT("Section must be a float section.")) && ensureMsgf(DefaultValueData.Num() == sizeof(float), TEXT("DefaultValueData must be a float.")))
	{
		FMovieSceneChannelProxy& FloatChannelProxy = FloatSection->GetChannelProxy();
		float DefaultValue = *((float*)DefaultValueData.GetData());
		SetChannelDefault(FloatChannelProxy, FloatSection->GetChannel(), DefaultValue);
	}
}

FMovieSceneEvalTemplatePtr UKGNiagaraUIFloatParameterTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	const UMovieSceneFloatSection* FloatSection = Cast<UMovieSceneFloatSection>(&InSection);
	if (FloatSection != nullptr)
	{
		return FKGNiagaraUIFloatParameterSectionTemplate(GetParameter(), FloatSection->GetChannel());
	}
	return FMovieSceneEvalTemplatePtr();
}
