#include "KGUISettings.h"

#include "KGUI.h"
#include "Components/SlateWrapperTypes.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(KGUISettings)

UKGUISettings::UKGUISettings(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bUseSimplifiedListViewEntryTypeRestriction(true)
	, bUseImprovedScrollToViewImplementation(true)
	, OpenAnimationName(TEXT("Ani_Fadein"))
	, CloseAnimationName(TEXT("Ani_Fadeout"))
	, LoopAnimationName(TEXT("Ani_Loop"))
{
	FDynamicAtlasPlatformConfiguration DynamicAtlasPlatformConfiguration;
	DynamicAtlasPlatformConfiguration.CompressionFormat = EPixelFormat::PF_DXT5;
	DynamicAtlasPlatformConfiguration.bCreatedWithCompressedTexture = false;
	DynamicAtlasPlatformConfigurations.Add("Windows", DynamicAtlasPlatformConfiguration);
}

#pragma region 状态组模板

#if WITH_EDITOR

bool UKGUISettings::TryGetStateGroupDeclaration(const FString& Name, FKGStateGroupDeclaration& StateGroupDeclaration) const
{
	auto DataTable = GetStateGroupDeclarationDataTable();
	if (DataTable == nullptr)
	{
		return false;
	}
	FKGStateGroupDeclaration* StateGroupDeclarationPtr = DataTable->FindRow<FKGStateGroupDeclaration>(FName(Name), "UKGUISettings::TryGetStateGroupDeclaration", true);
	if (StateGroupDeclarationPtr == nullptr)
	{
		return false;
	}
	TArray<FText> OutErrorList;
	if (!ValidateStateGroupDeclaration(Name, StateGroupDeclarationPtr, &OutErrorList))
	{
		UE_LOG(LogStateManagement, Error, TEXT("检测到非法的状态组`%s`声明"), *Name);
		for (auto Error : OutErrorList)
		{
			UE_LOG(LogStateManagement, Error, TEXT("\t%s"), *Error.ToString());
		}
		return false;
	}
	StateGroupDeclaration = *StateGroupDeclarationPtr;
	StateGroupDeclaration.Name = Name;
	return true;
}

TArray<FKGStateGroupDeclaration> UKGUISettings::GetAllStateGroupDeclarationsInDataTable() const
{
	TArray<FKGStateGroupDeclaration> Results;
	TArray<FText> OutErrorList;
	if (!ValidateAllStateGroupDeclarationsInDataTable(&OutErrorList))
	{
		UE_LOG(LogStateManagement, Error, TEXT("在数据表中存在非法的状态组声明，预声明状态组模板功能暂时失效"));
		for (auto Error : OutErrorList)
		{
			UE_LOG(LogStateManagement, Error, TEXT("%s"), *Error.ToString());
		}
		return Results;
	}
	auto DataTable = GetStateGroupDeclarationDataTable();
	if (DataTable != nullptr)
	{
		if (ensure(DataTable->RowStruct != nullptr && DataTable->RowStruct->IsChildOf(FKGStateGroupDeclaration::StaticStruct())))
		{
			auto RowMap = DataTable->GetRowMap();
			for (auto KeyValuePair : RowMap)
			{
				FString StateGroupName = KeyValuePair.Key.ToString();
				FKGStateGroupDeclaration* StateGroupDeclarationPtr = (FKGStateGroupDeclaration*)KeyValuePair.Value;
				check(StateGroupDeclarationPtr != nullptr);
				FKGStateGroupDeclaration StateGroupDeclaration = *StateGroupDeclarationPtr;
				StateGroupDeclaration.Name = StateGroupName;
				Results.Add(StateGroupDeclaration);
			}
		}
	}
	return Results;
}

UDataTable* UKGUISettings::GetStateGroupDeclarationDataTable() const
{
	if (StateGroupDeclarationDataTablePath == CurrentStateGroupDeclarationDataTablePath)
	{
		return StateGroupDeclarationDataTable;
	}
	StateGroupDeclarationDataTable = LoadObject<UDataTable>(nullptr, *StateGroupDeclarationDataTablePath.GetAssetPathString());
	CurrentStateGroupDeclarationDataTablePath = StateGroupDeclarationDataTablePath;
	return StateGroupDeclarationDataTable;
}

bool UKGUISettings::ValidateAllStateGroupDeclarationsInDataTable(TArray<FText>* OutErrorList) const
{
	auto DataTable = GetStateGroupDeclarationDataTable();
	if (DataTable == nullptr)
	{
		return true;
	}
	if (!ensure(DataTable->RowStruct != nullptr && DataTable->RowStruct->IsChildOf(FKGStateGroupDeclaration::StaticStruct())))
	{
		return false;
	}
	bool bOK = true;
	auto RowMap = DataTable->GetRowMap();
	for (auto KeyValuePair : RowMap)
	{
		bOK &= ValidateStateGroupDeclaration(KeyValuePair.Key.ToString(), (FKGStateGroupDeclaration*)KeyValuePair.Value, OutErrorList);
	}
	return bOK;
}

bool UKGUISettings::ValidateStateGroupDeclaration(const FString& Name, FKGStateGroupDeclaration* StateGroupDeclarationPtr, TArray<FText>* OutErrorList) const
{
	bool bOK = true;
	auto Error = [OutErrorList, &bOK](const FText& ErrorText)
	{
		if (OutErrorList == nullptr)
		{
			return;
		}
		bOK = false;
		OutErrorList->Add(ErrorText);
	};
	if (FKGUIModule::Get().HasScriptableStateGroupByName(Name))
	{
		Error(FText::Format(
			FText::FromString(TEXT("已存在重名的内置状态组{0}")),
			FText::FromString(Name)
		));
	}
	if (StateGroupDeclarationPtr != nullptr)
	{
		FKGStateGroupDeclaration& StateGroupDeclaration = *StateGroupDeclarationPtr;
		const auto& StateInfos = StateGroupDeclaration.GetStateInfos();
		if (StateInfos.Num() < 2)
		{
			Error(FText::Format(
				FText::FromString(TEXT("{0}行定义的状态组状态数量过少（至少需要2个状态）")),
				FText::FromString(Name)
			));
		}
	}
	else
	{
		Error(FText::Format(
			FText::FromString(TEXT("{0}行的数据意外为空")),
			FText::FromString(Name)
		));
	}
	return bOK;
}

#endif

#pragma endregion

TMap<FName, FDynamicAtlasGroupConfiguration> UKGUISettings::GenerateFinalDynamicAtlasGroupConfigurations() const
{
	TMap<FName, FDynamicAtlasGroupConfiguration> MergedDynamicAtlasGroupConfigurations = DynamicAtlasGroupConfigurations;
	if (auto DynamicAtlasGroupConfigurationDataTable = DynamicAtlasGroupConfigurationDataTablePath.LoadSynchronous())
	{
		if (DynamicAtlasGroupConfigurationDataTable->RowStruct != nullptr)
		{
			if (DynamicAtlasGroupConfigurationDataTable->RowStruct->IsChildOf(FDynamicAtlasGroupConfiguration::StaticStruct()))
			{
				auto& RowMap = DynamicAtlasGroupConfigurationDataTable->GetRowMap();
				for (auto KeyValuePair : RowMap)
				{
					if (KeyValuePair.Value != nullptr)
					{
						MergedDynamicAtlasGroupConfigurations.Add(KeyValuePair.Key, *(FDynamicAtlasGroupConfiguration*)KeyValuePair.Value);
					}
				}
			}
		}
	}
	return MoveTemp(MergedDynamicAtlasGroupConfigurations);
}

bool UKGUISettings::IsDynamicAtlasCreatedWithCompressedTexture() const
{
	auto PlatformConfiguration = GetDynamicAtlasPlatformConfiguration();
	return PlatformConfiguration ? PlatformConfiguration->bCreatedWithCompressedTexture : false;
}

EPixelFormat UKGUISettings::GetDynamicAtlasCompressionFormat() const
{
	auto PlatformConfiguration = GetDynamicAtlasPlatformConfiguration();
	return PlatformConfiguration ? PlatformConfiguration->CompressionFormat.GetValue() : EPixelFormat::PF_Unknown;
}

const FDynamicAtlasPlatformConfiguration* UKGUISettings::GetDynamicAtlasPlatformConfiguration() const
{
	auto PlatformName = UGameplayStatics::GetPlatformName();
	return DynamicAtlasPlatformConfigurations.Find(PlatformName);
}