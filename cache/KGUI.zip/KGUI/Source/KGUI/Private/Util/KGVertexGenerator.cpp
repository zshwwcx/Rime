#include "Util/KGVertexGenerator.h"
#include "Engine/Texture.h"
#include "Framework/Application/SlateApplication.h"
#include "Rendering/RenderingPolicy.h"
#include "Rendering/SlateRenderer.h"
#include "Slate/SlateTextureAtlasInterface.h"
#include "Styling/SlateBrush.h"

#if WITH_EDITOR
#pragma  optimize("", off)
#endif

void FKGVertexGenerator::GetBrushUVRegion(const FSlateBrush* Brush, FVector2f& OutTopLeft, FVector2f& OutBottomRight)
{
	check(Brush);
	const auto& RenderHandle = Brush->GetRenderingResource();
	if (RenderHandle.IsValid())
	{
		OutTopLeft = RenderHandle.GetResourceProxy()->StartUV;
		OutBottomRight = OutTopLeft + RenderHandle.GetResourceProxy()->SizeUV;
	}
	else
	{
		UObject* Obj = Brush->GetResourceObject();
		if (Obj && IsValid(Obj))
		{
			if (Obj->IsA<UTexture>())
			{
				OutTopLeft = FVector2f::Zero();
				OutBottomRight = FVector2f::One();
			}
			else if (auto* SlateAtlasInterface = Cast<ISlateTextureAtlasInterface>(Obj))
			{
				FSlateAtlasData AtlasData = SlateAtlasInterface->GetSlateAtlasData();
				OutTopLeft.Set(AtlasData.StartUV.X, AtlasData.StartUV.Y);
				OutBottomRight.Set(AtlasData.StartUV.X + AtlasData.SizeUV.X, AtlasData.StartUV.Y + AtlasData.SizeUV.Y);
			}
		}
	}
}

FVector2f FKGVertexGenerator::GetBrushSize(const FSlateBrush* Brush)
{
	check(Brush);
	const auto& RenderHandle = Brush->GetRenderingResource();
	if (RenderHandle.IsValid())
	{
		return RenderHandle.GetResourceProxy()->ActualSize;
	}

	if (Brush)
	{
		return Brush->GetImageSize();
	}

	return FVector2f::One();
}

FVector2f FKGVertexGenerator::GetBrushTilingCount(const FSlateBrush* Brush, const FVector2f& Size)
{
	FVector2f BrushSize = GetBrushSize(Brush);
	FVector2f Tiling = FVector2f::One();
	switch (Brush->Tiling)
	{
	case ESlateBrushTileType::Type::Horizontal:
		{
			Tiling.X = Size.X / BrushSize.X;
		}
		break;
	case ESlateBrushTileType::Type::Vertical:
		{
			Tiling.Y = Size.Y / BrushSize.Y;
		}
		break;
	case ESlateBrushTileType::Both:
		{
			Tiling.X = Size.X / BrushSize.X;
			Tiling.Y = Size.Y / BrushSize.Y;
		}
		break;
	default: break;
	}

	return Tiling;
}

float FKGVertexGenerator::GetPixelCenterOffset()
{
	if (FSlateRenderer* SlateRenderer = FSlateApplication::Get().GetRenderer())
	{
		auto RenderingPolicy = SlateRenderer->GetRenderingPolicy();
		if (RenderingPolicy.IsValid())
		{
			return RenderingPolicy->GetPixelCenterOffset();
		}
	}

	return 0.f;
}

void FKGVertexGenerator::GenerateVertexDataForImage(const FSlateBrush* Brush, const FVector2f& InTopLeft, const FVector2f& InBottomRight,
	const FVector2f& InStartUV, const FVector2f& InEndUV, const FGeometry& AllottedGeometry, const FColor& InColor,
	TArray<FSlateVertex>& OutVertex, TArray<SlateIndex>& OutIndices)
{
	FVector2f TextureSize = GetBrushSize(Brush);
    FVector2f UVOrigTopLeft, UVOrigBottomRight;
    GetBrushUVRegion(Brush, UVOrigTopLeft, UVOrigBottomRight);
    
	const FVector2f TopRight(InBottomRight.X, InTopLeft.Y);
	const FVector2f BottomLeft(InTopLeft.X, InBottomRight.Y);

	float PixelCenterOffset = GetPixelCenterOffset();
	float TextureWidth = FMath::Abs(TextureSize.X) > 1e-3f ? TextureSize.X : 1.f;
	float TextureHeight = FMath::Abs(TextureSize.Y) > 1e-3f ? TextureSize.Y : 1.f;
	FVector2f HalfTexel = FVector2f(PixelCenterOffset / TextureWidth, PixelCenterOffset / TextureHeight);
	FVector2f UVTopLeft = InStartUV + HalfTexel;
	FVector2f UVBottomRight = InEndUV + HalfTexel;
	FVector2f UVTopRight(InEndUV.X + HalfTexel.X, InStartUV.Y + HalfTexel.Y);
	FVector2f UVBottomLeft(InStartUV.X + HalfTexel.X, InEndUV.Y + HalfTexel.Y);

	bool bHorizontalTiling = Brush->GetTiling() == ESlateBrushTileType::Type::Horizontal || Brush->GetTiling() == ESlateBrushTileType::Type::Both;
	bool bVerticalTiling = Brush->GetTiling() == ESlateBrushTileType::Type::Vertical || Brush->GetTiling() == ESlateBrushTileType::Type::Both;

	FVector2f Tiling = FVector2f::One();
	FVector4f UVRemap = FVector4f(0, 0, 1, 1);
	if (bHorizontalTiling)
	{
		Tiling.X =  (InBottomRight - InTopLeft).X / TextureWidth;
		UVRemap.X = UVOrigTopLeft.X;
		UVRemap.Z = UVOrigBottomRight.X - UVOrigTopLeft.X;

		UVTopLeft.X = 0;
		UVBottomLeft.X = 0;
		UVTopRight.X = 1;
		UVBottomRight.X = 1;
	}
	if (bVerticalTiling)
	{
		Tiling.Y = (InBottomRight - InTopLeft).Y / TextureHeight;
		UVRemap.Y = UVOrigTopLeft.Y;
		UVRemap.W = UVOrigBottomRight.Y - UVOrigTopLeft.Y;

		UVTopLeft.Y = 0;
		UVTopRight.Y = 0;
		UVBottomLeft.Y = 1;
		UVBottomRight.Y = 1;
	}

	FPaintGeometry PaintGeometry = AllottedGeometry.ToPaintGeometry();
	// 添加四个顶点
	OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(),
	                                                                 InTopLeft,
	                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
	                                                                 FVector4f(UVTopLeft, Tiling), InColor, FColor(), FVector2f::Zero(),
	                                                                 FVector4f::Zero(), UVRemap));

	OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(),
	                                                                 TopRight,
	                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
	                                                                 FVector4f(UVTopRight, Tiling), InColor, FColor(), FVector2f::Zero(),
	                                                                 FVector4f::Zero(), UVRemap));

	OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(),
	                                                                 InBottomRight,
	                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
	                                                                 FVector4f(UVBottomRight, Tiling), InColor, FColor(), FVector2f::Zero(),
	                                                                 FVector4f::Zero(), UVRemap));

	OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(),
	                                                                 BottomLeft,
	                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
	                                                                 FVector4f(UVBottomLeft, Tiling), InColor, FColor(), FVector2f::Zero(),
	                                                                 FVector4f::Zero(), UVRemap));

	// 添加两个三角形的索引（顺时针）
	OutIndices.Add(0);
	OutIndices.Add(1);
	OutIndices.Add(3);
	OutIndices.Add(1);
	OutIndices.Add(2);
	OutIndices.Add(3);
}

void FKGVertexGenerator::GenerateVertexDataForBox(const FSlateBrush* Brush, const FVector2f& InTopLeft, const FVector2f& InBottomRight,
	const FMargin& InPosMargin, const FVector2f& InStartUV, const FVector2f& InEndUV, const FMargin& InUVMargin, const FGeometry& AllottedGeometry,
	const FColor& InColor, TArray<FSlateVertex>& OutVertex, TArray<SlateIndex>& OutIndices)
{
    bool bHorizontalTiling = Brush->GetTiling() == ESlateBrushTileType::Type::Horizontal || Brush->GetTiling() == ESlateBrushTileType::Type::Both;
    bool bVerticalTiling = Brush->GetTiling() == ESlateBrushTileType::Type::Vertical || Brush->GetTiling() == ESlateBrushTileType::Type::Both;
    if ((bHorizontalTiling || bVerticalTiling)
        && (FMath::IsNearlyZero(Brush->Margin.Left) && FMath::IsNearlyZero(Brush->Margin.Right) && FMath::IsNearlyZero(Brush->Margin.Top) || FMath::IsNearlyZero(Brush->Margin.Bottom)))
    {
        return GenerateVertexDataForImage(Brush, InTopLeft, InBottomRight, InStartUV, InEndUV, AllottedGeometry, InColor, OutVertex, OutIndices);
    }
    
	FVector2f TextureSize = GetBrushSize(Brush);
    FVector2f UVOrigTopLeft, UVOrigBottomRight;
    GetBrushUVRegion(Brush, UVOrigTopLeft, UVOrigBottomRight);
    
	float TextureWidth = FMath::Abs(TextureSize.X) > 1e-3f ? TextureSize.X : 1.f;
	float TextureHeight = FMath::Abs(TextureSize.Y) > 1e-3f ? TextureSize.Y : 1.f;

	FVector2f Size = InBottomRight - InTopLeft;

	// 计算Box的九个区域（3x3网格）
	float LeftMargin = InPosMargin.Left;
	float RightMargin = InPosMargin.Right;
	float TopMargin = InPosMargin.Top;
	float BottomMargin = InPosMargin.Bottom;
	if (RightMargin < LeftMargin)
	{
		LeftMargin = RightMargin = Size.X / 2.f;
	}

	if (BottomMargin < TopMargin)
	{
		TopMargin = BottomMargin = Size.Y / 2.f;
	}
    
	FVector2f Tiling = FVector2f::One();
	if (bHorizontalTiling)
	{
		Tiling.X = Size.X / TextureWidth;
	}
	if (bVerticalTiling)
	{
		Tiling.Y = Size.Y / TextureHeight;
	}

	// Create 9 quads for the box element based on the following diagram
	//      ___LeftMargin     ___RightMargin
	//     /  1             2/
	//  0 +---+-------------+---+ 3
	//    |   |5            |6  | ___TopMargin
	//  4 +---o-------------o---+ 7
	//    |   |             |   |
	//    |   |9            |10 |
	//  8 +---o-------------o---+ 11
	//    |   |             |   | ___BottomMargin
	// 12 +---+-------------+---+ 15
	//        13            14

	const FVector2f Corners[16] = {
		InTopLeft,
		InTopLeft + FVector2f(LeftMargin, 0),
		InTopLeft + FVector2f(RightMargin, 0),
		InTopLeft + FVector2f(Size.X, 0),
		InTopLeft + FVector2f(0, TopMargin),
		InTopLeft + FVector2f(LeftMargin, TopMargin),
		InTopLeft + FVector2f(RightMargin, TopMargin),
		InTopLeft + FVector2f(Size.X, TopMargin),
		InTopLeft + FVector2f(0, BottomMargin),
		InTopLeft + FVector2f(LeftMargin, BottomMargin),
		InTopLeft + FVector2f(RightMargin, BottomMargin),
		InTopLeft + FVector2f(Size.X, BottomMargin),
		InTopLeft + FVector2f(0, Size.Y),
		InTopLeft + FVector2f(LeftMargin, Size.Y),
		InTopLeft + FVector2f(RightMargin, Size.Y), InBottomRight,
	};

	// UV
	float PixelCenterOffset = GetPixelCenterOffset();
	FVector2f HalfTexel = FVector2f(PixelCenterOffset / TextureWidth, PixelCenterOffset / TextureHeight);

	FVector2f StartUV = InStartUV + HalfTexel;
	FVector2f EndUV = InEndUV + HalfTexel;

	float LeftMarginU = StartUV.X + InUVMargin.Left + HalfTexel.X;
	float TopMarginV = StartUV.Y + InUVMargin.Top + HalfTexel.Y;
	float RightMarginU = StartUV.X + InUVMargin.Right + HalfTexel.X;
	float BottomMarginV = StartUV.Y + InUVMargin.Bottom + HalfTexel.Y;

	const FVector2f UVCorners[16] = {
		StartUV,
		FVector2f(LeftMarginU, StartUV.Y),
		FVector2f(RightMarginU, StartUV.Y),
		FVector2f(EndUV.X, StartUV.Y),
		FVector2f(StartUV.X, TopMarginV),
		FVector2f(LeftMarginU, TopMarginV),
		FVector2f(RightMarginU, TopMarginV),
		FVector2f(EndUV.X, TopMarginV),
		FVector2f(StartUV.X, BottomMarginV),
		FVector2f(LeftMarginU, BottomMarginV),
		FVector2f(RightMarginU, BottomMarginV),
		FVector2f(EndUV.X, BottomMarginV),
		FVector2f(StartUV.X, EndUV.Y),
		FVector2f(LeftMarginU, EndUV.Y),
		FVector2f(RightMarginU, EndUV.Y),
		FVector2f(EndUV.X, EndUV.Y),
	};

	static const IConsoleVariable* bEnableSpriteTilling = IConsoleManager::Get().FindConsoleVariable(TEXT("r.Slate.SpriteTilling"));
	FPaintGeometry PaintGeometry = AllottedGeometry.ToPaintGeometry();
	// 添加顶点
	if ((bHorizontalTiling || bVerticalTiling)
		&& (Brush->Margin.Left != 0 || Brush->Margin.Right != 0 || Brush->Margin.Top != 0 || Brush->Margin.Bottom != 0))
	{
		if (bEnableSpriteTilling->GetBool())
		{
			FVector2f UVRegionStart;
			FVector2f UVRegionEnd;
			GetBrushUVRegion(Brush, UVRegionStart, UVRegionEnd);
			FVector2f ActualSizeUV = FVector2f(
				(UVRegionEnd.X - UVRegionStart.X) * (1 - Brush->GetMargin().GetTotalSpaceAlong<Orient_Horizontal>()),
				(UVRegionEnd.Y - UVRegionStart.Y) * (1 - Brush->GetMargin().GetTotalSpaceAlong<Orient_Vertical>()));
			FVector2f ActualTilling = FVector2f::One();

			FVector4f LRUVRemap(0, 0, 1, 1);
			FVector4f TBUVRemap(0, 0, 1, 1);
			FVector4f MiddleUVRemap(0, 0, 1, 1);

			float TBStartMarginU = LeftMarginU;
			float TBEndMarginU = RightMarginU;
			float LRStartMarginV = TopMarginV;
			float LREndMarginV = BottomMarginV;

			float Denom = TextureWidth * (1 - Brush->GetMargin().GetTotalSpaceAlong<Orient_Horizontal>());
			if (bHorizontalTiling && !FMath::IsNearlyZero(Denom))
			{
				ActualTilling.X = (RightMargin - LeftMargin) / Denom;
			    float LM = UVRegionStart.X + Brush->Margin.Left * (UVRegionEnd.X - UVRegionStart.X);
				TBUVRemap = FVector4f(LM, 0, ActualSizeUV.X, 1);
				MiddleUVRemap.X = LM;
				MiddleUVRemap.Z = ActualSizeUV.X;
				TBStartMarginU = 0;  
				TBEndMarginU = 1;
			}

			Denom = TextureHeight * (1 - Brush->GetMargin().GetTotalSpaceAlong<Orient_Vertical>());
			if (bVerticalTiling && !FMath::IsNearlyZero(Denom))
			{
				ActualTilling.Y = (BottomMargin - TopMargin) / Denom;
			    float TM = UVRegionStart.Y + Brush->Margin.Top * (UVRegionEnd.Y - UVRegionStart.Y);
				LRUVRemap = FVector4f(0, TM, 1, ActualSizeUV.Y);
				MiddleUVRemap.Y = TM;
				MiddleUVRemap.W = ActualSizeUV.Y;
				LRStartMarginV = 0;
				LREndMarginV = 1;
			}

			const FVector2f CornerTiling(1, 1);
			const FVector2f LRBorderTiling(1, ActualTilling.Y);
			const FVector2f TBBorderTiling(ActualTilling.X, 1);

			// Top-Left Corner
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[0],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[0], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[1],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[1], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[4],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[4], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[5],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[5], CornerTiling), InColor));

			// Top-Middle
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[1],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBStartMarginU, StartUV.Y), TBBorderTiling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), TBUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[2],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBEndMarginU, StartUV.Y), TBBorderTiling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), TBUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[5],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBStartMarginU, TopMarginV), TBBorderTiling),
			                                                                 InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), TBUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[6],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBEndMarginU, TopMarginV), TBBorderTiling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), TBUVRemap));

			// Top-Right Corner
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[2],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[2], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[3],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[3], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[6],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[6], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[7],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[7], CornerTiling), InColor));

			// Middle-Left
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[4],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(StartUV.X, LRStartMarginV), LRBorderTiling), InColor,
			                                                                 FColor(),
			                                                                 FVector2f::Zero(), FVector4f::Zero(), LRUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[5],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(LeftMarginU, LRStartMarginV), LRBorderTiling),
			                                                                 InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), LRUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[8],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(StartUV.X, LREndMarginV), LRBorderTiling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), LRUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[9],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(LeftMarginU, LREndMarginV), LRBorderTiling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), LRUVRemap));

			// Middle-Middle
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[5],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBStartMarginU, LRStartMarginV), ActualTilling),
			                                                                 InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), MiddleUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[6],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBEndMarginU, LRStartMarginV), ActualTilling),
			                                                                 InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), MiddleUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[9],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBStartMarginU, LREndMarginV), ActualTilling),
			                                                                 InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), MiddleUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[10],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBEndMarginU, LREndMarginV), ActualTilling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), MiddleUVRemap));

			// Middle-Right
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[6],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(RightMarginU, LRStartMarginV), LRBorderTiling),
			                                                                 InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), LRUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[7],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(EndUV.X, LRStartMarginV), LRBorderTiling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), LRUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[10],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(RightMarginU, LREndMarginV), LRBorderTiling),
			                                                                 InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), LRUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[11],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(EndUV.X, LREndMarginV), LRBorderTiling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), LRUVRemap));

			// Bottom-Left Corner
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[8],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[8], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[9],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[9], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[12],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[12], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[13],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[13], CornerTiling), InColor));

			// Bottom-Middle
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[9],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBStartMarginU, BottomMarginV), TBBorderTiling),
			                                                                 InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), TBUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[10],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBEndMarginU, BottomMarginV), TBBorderTiling),
			                                                                 InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), TBUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[13],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBStartMarginU, EndUV.Y), TBBorderTiling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), TBUVRemap));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[14],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(FVector2f(TBEndMarginU, EndUV.Y), TBBorderTiling), InColor,
			                                                                 FColor(), FVector2f::Zero(), FVector4f::Zero(), TBUVRemap));

			// Bottom-Right Corner
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[10],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[10], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[11],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[11], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[14],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[14], CornerTiling), InColor));
			OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[15],
			                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                                 FVector4f(UVCorners[15], CornerTiling), InColor));

			// Index
			// Top-Left Corner
			OutIndices.Add(0);
			OutIndices.Add(1);
			OutIndices.Add(2);
			OutIndices.Add(2);
			OutIndices.Add(1);
			OutIndices.Add(3);
			// Top-Middle
			OutIndices.Add(4);
			OutIndices.Add(5);
			OutIndices.Add(6);
			OutIndices.Add(6);
			OutIndices.Add(5);
			OutIndices.Add(7);
			// Top-Right Corner
			OutIndices.Add(8);
			OutIndices.Add(9);
			OutIndices.Add(10);
			OutIndices.Add(10);
			OutIndices.Add(9);
			OutIndices.Add(11);
			// Middle-Left
			OutIndices.Add(12);
			OutIndices.Add(13);
			OutIndices.Add(14);
			OutIndices.Add(14);
			OutIndices.Add(13);
			OutIndices.Add(15);
			// Middle-Middle
			OutIndices.Add(16);
			OutIndices.Add(17);
			OutIndices.Add(18);
			OutIndices.Add(18);
			OutIndices.Add(17);
			OutIndices.Add(19);
			// Middle-Right
			OutIndices.Add(20);
			OutIndices.Add(21);
			OutIndices.Add(22);
			OutIndices.Add(22);
			OutIndices.Add(21);
			OutIndices.Add(23);
			// Bottom-Left Corner
			OutIndices.Add(24);
			OutIndices.Add(25);
			OutIndices.Add(26);
			OutIndices.Add(26);
			OutIndices.Add(25);
			OutIndices.Add(27);
			// Bottom-Middle
			OutIndices.Add(28);
			OutIndices.Add(29);
			OutIndices.Add(30);
			OutIndices.Add(30);
			OutIndices.Add(29);
			OutIndices.Add(31);
			// Bottom-Right Corner
			OutIndices.Add(32);
			OutIndices.Add(33);
			OutIndices.Add(34);
			OutIndices.Add(34);
			OutIndices.Add(33);
			OutIndices.Add(35);

			return;
		}
	}


    FVector4f UVRemap = FVector4f(0,0,1,1);
    if (bEnableSpriteTilling->GetBool())
    {
        if(bHorizontalTiling)
        {
            UVRemap.X = UVOrigTopLeft.X;
            UVRemap.Z = (UVOrigBottomRight - UVOrigTopLeft).X;
            StartUV.X = 0;
            EndUV.X = 1;
        }
        
        if(bVerticalTiling)
        {
            UVRemap.Y = UVOrigTopLeft.Y;
            UVRemap.W = (UVOrigBottomRight - UVOrigTopLeft).Y;
            StartUV.Y = 0;
            EndUV.Y = 1;
        }
    }
    
	for (int i = 0; i < 16; i++)
	{
		OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Corners[i],
		                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
		                                                                 FVector4f(UVCorners[i], Tiling), InColor, FColor(), FVector2f::Zero(), FVector4f::Zero(), UVRemap));
	}

	// 添加索引（每个区域两个三角形）
	static const int32 IndicesByRegion[9][6] = {
		{0, 1, 4, 1, 5, 4}, // 左上
		{1, 2, 5, 2, 6, 5}, // 上中
		{2, 3, 6, 3, 7, 6}, // 右上
		{4, 5, 8, 5, 9, 8}, // 左中
		{5, 6, 9, 6, 10, 9}, // 中中
		{6, 7, 10, 7, 11, 10}, // 右中
		{8, 9, 12, 9, 13, 12}, // 左下
		{9, 10, 13, 10, 14, 13}, // 中下
		{10, 11, 14, 11, 15, 14}, // 右下
	};

	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 6; j++)
		{
			OutIndices.Add(IndicesByRegion[i][j]);
		}
	}
        
}

void FKGVertexGenerator::GenerateVertexDataForBorder(const FSlateBrush* Brush, const FVector2f& InTopLeft, const FVector2f& InBottomRight,
	const FVector2f& InStartUV, const FVector2f& InEndUV, const FMargin& Margin, const FGeometry& AllottedGeometry,
	const FColor& InColor, TArray<FSlateVertex>& OutVertex, TArray<SlateIndex>& OutIndices)
{
	FVector2f TextureSize = GetBrushSize(Brush);
    FVector2f UVOrigTopLeft, UVOrigBottomRight;
    GetBrushUVRegion(Brush, UVOrigTopLeft, UVOrigBottomRight);
    
	FVector2f Size = InBottomRight - InTopLeft;
	// 计算Box的九个区域（3x3网格）
	const float LeftMargin = FMath::Min(Margin.Left, Size.X / 2);
	const float RightMargin = FMath::Min(Margin.Right, Size.X / 2);
	const float TopMargin = FMath::Min(Margin.Top, Size.Y / 2);
	const float BottomMargin = FMath::Min(Margin.Bottom, Size.Y / 2);

	const FVector2f Points[16] = {
		InTopLeft + FVector2f(0, 0), InTopLeft + FVector2f(LeftMargin, 0), InTopLeft + FVector2f(Size.X - RightMargin, 0),
		InTopLeft + FVector2f(Size.X, 0), InTopLeft + FVector2f(0, TopMargin), InTopLeft + FVector2f(LeftMargin, TopMargin),
		InTopLeft + FVector2f(Size.X - RightMargin, TopMargin), InTopLeft + FVector2f(Size.X, TopMargin),
		InTopLeft + FVector2f(0, Size.Y - BottomMargin), InTopLeft + FVector2f(LeftMargin, Size.Y - BottomMargin),
		InTopLeft + FVector2f(Size.X - RightMargin, Size.Y - BottomMargin), InTopLeft + FVector2f(Size.X, Size.Y - BottomMargin),
		InTopLeft + FVector2f(0, Size.Y), InTopLeft + FVector2f(LeftMargin, Size.Y), InTopLeft + FVector2f(Size.X - RightMargin, Size.Y),
		InTopLeft + FVector2f(Size.X, Size.Y),
	};

	// 获取Brush的UV范围
	float PixelCenterOffset = GetPixelCenterOffset();
	float TextureWidth = FMath::Abs(TextureSize.X) > 1e-3f ? TextureSize.X : 1.f;
	float TextureHeight = FMath::Abs(TextureSize.Y) > 1e-3f ? TextureSize.Y : 1.f;
	FVector2f HalfTexel = FVector2f(PixelCenterOffset / TextureWidth, PixelCenterOffset / TextureHeight);

	const FVector2f StartUV = InStartUV + HalfTexel;
	const FVector2f EndUV = InEndUV + HalfTexel;

	// 对应的UV坐标
	FVector2f SizeUV = EndUV - StartUV;
	float LeftMarginU = (Margin.Left > 0 ? Margin.Left / TextureWidth : 0) * SizeUV.X + HalfTexel.X;
	float TopMarginV = (Margin.Top > 0 ? Margin.Top / TextureHeight : 0) * SizeUV.Y + HalfTexel.Y;
	float RightMarginU = (TextureWidth - Margin.Right > 0 ? (TextureWidth - Margin.Right) / TextureWidth : 0) * SizeUV.X + HalfTexel.X;
	float BottomMarginV = (TextureHeight - Margin.Bottom > 0 ? (TextureHeight - Margin.Bottom) / TextureHeight : 0) * SizeUV.Y + HalfTexel.Y;

	const FVector2f UVs[16] = {
		StartUV, FVector2f(StartUV.X + LeftMarginU, StartUV.Y), FVector2f(StartUV.X + RightMarginU, StartUV.Y), FVector2f(EndUV.X, StartUV.Y),
		FVector2f(StartUV.X, StartUV.Y + TopMarginV), FVector2f(StartUV.X + LeftMarginU, StartUV.Y + TopMarginV),
		FVector2f(StartUV.X + RightMarginU, StartUV.Y + TopMarginV), FVector2f(EndUV.X, StartUV.Y + TopMarginV),
		FVector2f(StartUV.X, StartUV.Y + BottomMarginV), FVector2f(StartUV.X + LeftMarginU, StartUV.Y + BottomMarginV),
		FVector2f(StartUV.X + RightMarginU, StartUV.Y + BottomMarginV), FVector2f(EndUV.X, StartUV.Y + BottomMarginV), FVector2f(StartUV.X, EndUV.Y),
		FVector2f(StartUV.X + LeftMarginU, EndUV.Y), FVector2f(StartUV.X + RightMarginU, EndUV.Y), EndUV
	};
	
    FVector2f Tiling = FVector2f::One();
    bool bHorizontalTiling = Brush->GetTiling() == ESlateBrushTileType::Type::Horizontal || Brush->GetTiling() == ESlateBrushTileType::Type::Both;
    bool bVerticalTiling = Brush->GetTiling() == ESlateBrushTileType::Type::Vertical || Brush->GetTiling() == ESlateBrushTileType::Type::Both;
    if (bHorizontalTiling)
    {
        Tiling.X = Size.X / TextureWidth;
    }
    if (bVerticalTiling)
    {
        Tiling.Y = Size.Y / TextureHeight;
    }
    
	FPaintGeometry PaintGeometry = AllottedGeometry.ToPaintGeometry();
	// 添加顶点
	for (int i = 0; i < 16; i++)
	{
		OutVertex.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Points[i],
		                                                                 PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
		                                                                 FVector4f(UVs[i], Tiling), InColor));
	}

	// 添加索引（每个区域两个三角形）
	static const int32 IndicesByRegion[8][6] = {
		{0, 1, 4, 1, 5, 4}, // 左上
		{1, 2, 5, 2, 6, 5}, // 上中
		{2, 3, 6, 3, 7, 6}, // 右上
		{4, 5, 8, 5, 9, 8}, // 左中

		{6, 7, 10, 7, 11, 10}, // 右中
		{8, 9, 12, 9, 13, 12}, // 左下
		{9, 10, 13, 10, 14, 13}, // 中下
		{10, 11, 14, 11, 15, 14}, // 右下
	};

	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 6; j++)
		{
			OutIndices.Add(IndicesByRegion[i][j]);
		}
	}
}

void FKGVertexGenerator::GenerateVertexDataForRoundBox(const FSlateBrush* Brush, const FVector2f& InTopLeft, const FVector2f& InBottomRight,
	const FVector2f& InStartUV, const FVector2f& InEndUV, const FGeometry& AllottedGeometry, const FColor& InColor, TArray<FSlateVertex>& OutVertex,
	TArray<SlateIndex>& OutIndices)
{
	// NOT SUPPORT
}

void FKGVertexGenerator::GenerateRadialVerts(const FSlateBrush* Brush, const FGeometry& AllottedGeometry, const FVector2f Center, const float Radius,
	const float InnerRadius, float CircularStartAngle, float CircularEndAngle, const FVector2f& InStartUV, const FVector2f& InEndUV,
	const FColor& PackedColor, const float AnglePerSegment, const float ProgressAngle, const int32 ProgressSegments, TArray<FSlateVertex>& Verts,
	TArray<SlateIndex>& Indices)
{
	FVector2f TextureSize = GetBrushSize(Brush);
	FPaintGeometry PaintGeometry = AllottedGeometry.ToPaintGeometry();
	float PixelCenterOffset = GetPixelCenterOffset();
	float TextureWidth = FMath::Abs(TextureSize.X) > 1e-3f ? TextureSize.X : 1.f;
	float TextureHeight = FMath::Abs(TextureSize.Y) > 1e-3f ? TextureSize.Y : 1.f;
	FVector2f HalfTexel = FVector2f(PixelCenterOffset / TextureWidth, PixelCenterOffset / TextureHeight);

	FVector2f Tiling = GetBrushTilingCount(Brush, AllottedGeometry.GetLocalSize());
	FVector2f StartUV = InStartUV + HalfTexel;
	FVector2f EndUV = InEndUV + HalfTexel;
	FColor TransparentColor = PackedColor;
	TransparentColor.A /= 2;
	// 添加中心顶点（用于三角形扇）
	// Verts.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Center, PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale, FVector4f(0.5f, 0.5f, Tiling.X, Tiling.Y), PackedColor));

	// 添加圆弧上的顶点
	if (InnerRadius > 0)
	{
		float InnerUVRadius = InnerRadius / Radius;
		for (int32 i = 0; i <= ProgressSegments; i++)
		{
			const float Angle = CircularStartAngle + i * AnglePerSegment;
			const float ClampedAngle = FMath::Min(Angle, CircularStartAngle + ProgressAngle);

			const FVector2f Direction(FMath::Cos(ClampedAngle), FMath::Sin(ClampedAngle));
			const FVector2f OuterPoint = Center + Direction * Radius;
			const FVector2f InnerPoint = Center + Direction * InnerRadius;
			const FVector2f OuterPointHalfTexel = Center + Direction * (Radius + 0.5f);
			const FVector2f InnerPointHalfTexel = Center + Direction * (InnerRadius - 0.5f);

			// 计算UV坐标（基于角度和半径）
			FVector2f OuterUV, InnerUV;

			if (Brush != nullptr && Brush->DrawAs != ESlateBrushDrawType::NoDrawType)
			{
				// 映射到实际UV范围
				OuterUV = FVector2f(StartUV.X + (0.5f + 0.5f * Direction.X) * (EndUV.X - StartUV.X),
				                    StartUV.Y + (0.5f + 0.5f * Direction.Y) * (EndUV.Y - StartUV.Y)) + HalfTexel;
				InnerUV = FVector2f(StartUV.X + (0.5f + InnerUVRadius * 0.5 * Direction.X) * (EndUV.X - StartUV.X),
				                    StartUV.Y + (0.5f + InnerUVRadius * 0.5 * Direction.Y) * (EndUV.Y - StartUV.Y)) + HalfTexel;
			}
			else
			{
				// 默认UV计算
				OuterUV = FVector2f(0.5f + 0.5f * Direction.X, 0.5f + 0.5f * Direction.Y) + HalfTexel;
				InnerUV = FVector2f(0.5f + 0.4f * Direction.X, 0.5f + 0.4f * Direction.Y) + HalfTexel;
			}

			// 添加外圈顶点
			Verts.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), OuterPoint,
			                                                             PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                             FVector4f(OuterUV, Tiling), PackedColor));

			// 添加内圈顶点（用于厚度）
			Verts.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), InnerPoint,
			                                                             PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                             FVector4f(InnerUV, Tiling), PackedColor));

			Verts.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), OuterPointHalfTexel,
			                                                             PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                             FVector4f(OuterUV, Tiling), TransparentColor));

			// 添加内圈顶点（用于厚度）
			Verts.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), InnerPointHalfTexel,
			                                                             PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
			                                                             FVector4f(InnerUV, Tiling), TransparentColor));

			// 添加三角形索引（形成四边形条带）
			if (i > 0)
			{
				const int32 CurrentOuter = i * 4;
				const int32 CurrentInner = i * 4 + 1;
				const int32 CurrentOuterHalf = i * 4 + 2;
				const int32 CurrentInnerHalf = i * 4 + 3;
				const int32 PrevOuter = (i - 1) * 4;
				const int32 PrevInner = (i - 1) * 4 + 1;
				const int32 PreOuterHalf = (i - 1) * 4 + 2;
				const int32 PrevInnerHalf = (i - 1) * 4 + 3;

				Indices.Add(PrevInner);
				Indices.Add(PrevOuter);
				Indices.Add(CurrentOuter);
				Indices.Add(CurrentOuter);
				Indices.Add(CurrentInner);
				Indices.Add(PrevInner);

				Indices.Add(PrevOuter);
				Indices.Add(PreOuterHalf);
				Indices.Add(CurrentOuterHalf);
				Indices.Add(CurrentOuterHalf);
				Indices.Add(CurrentOuter);
				Indices.Add(PrevOuter);

				Indices.Add(PrevInnerHalf);
				Indices.Add(PrevInner);
				Indices.Add(CurrentInner);
				Indices.Add(CurrentInner);
				Indices.Add(CurrentInnerHalf);
				Indices.Add(PrevInnerHalf);
			}
		}
		return;
	}

	Verts.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(PaintGeometry.GetAccumulatedRenderTransform(), Center, PaintGeometry.GetLocalSize(),
	                                                             PaintGeometry.DrawScale,
	                                                             FVector4f(StartUV.X + 0.5f * (EndUV.X - StartUV.X),
	                                                                       StartUV.Y + 0.5f * (EndUV.Y - StartUV.Y), Tiling.X, Tiling.Y),
	                                                             PackedColor));
	for (int32 i = 0; i <= ProgressSegments; i++)
	{
		const float Angle = CircularStartAngle + i * AnglePerSegment;
		const float ClampedAngle = FMath::Min(Angle, CircularStartAngle + ProgressAngle);

		const FVector2f Direction(FMath::Cos(ClampedAngle), FMath::Sin(ClampedAngle));
		const FVector2f OuterPoint = Center + Direction * Radius;

		// 计算UV坐标（基于角度和半径）
		FVector2f OuterUV;
		if (Brush != nullptr && Brush->DrawAs != ESlateBrushDrawType::NoDrawType)
		{
			// 映射到实际UV范围
			OuterUV = FVector2f(StartUV.X + (0.5f + 0.5f * Direction.X) * (EndUV.X - StartUV.X),
			                    StartUV.Y + (0.5f + 0.5f * Direction.Y) * (EndUV.Y - StartUV.Y)) + HalfTexel;
		}
		else
		{
			// 默认UV计算
			OuterUV = FVector2f(0.5f + 0.5f * Direction.X, 0.5f + 0.5f * Direction.Y) + HalfTexel;
		}

		// 添加外圈顶点
		Verts.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(AllottedGeometry.ToPaintGeometry().GetAccumulatedRenderTransform(), OuterPoint,
		                                                             PaintGeometry.GetLocalSize(), PaintGeometry.DrawScale,
		                                                             FVector4f(OuterUV, Tiling), PackedColor));

		// 添加三角形索引（形成四边形条带）
		if (i > 0)
		{
			const int32 Current = i + 1;
			const int32 Prev = i;


			// 第一个三角形（外圈）
			Indices.Add(0);
			Indices.Add(Prev);
			Indices.Add(Current);
		}
	}
}


#if WITH_EDITOR
#pragma  optimize("", on)
#endif
