#include "KGUI/Public/Profiling/KGMemoryStatisticsObjectIdentity.h"


FKGMemoryStatisticsObjectIdentity::FKGMemoryStatisticsObjectIdentity()
	: Object(nullptr)
	, ID(0)
	, UserID(0)
{
}

FKGMemoryStatisticsObjectIdentity::FKGMemoryStatisticsObjectIdentity(UObject* InObject)
	: Object(InObject)
	, ID((uint64)InObject)
	, UserID(0)
{
	if (Object != nullptr)
	{
		ObjectName = Object->GetName();
		ObjectFullName = Object->GetFullName();
		ClassName = Object->GetClass()->GetName();
		ClassPathName = Object->GetClass()->GetPathName();
	}
}

FKGMemoryStatisticsObjectIdentity::FKGMemoryStatisticsObjectIdentity(uint64 InUserID)
	: Object(nullptr)
	, ID(0)
	, UserID(InUserID)
{
	check(InUserID != 0);
}

bool FKGMemoryStatisticsObjectIdentity::IsA(UClass* InClass) const
{
	if (ClassPathName == InClass->GetFullName())
	{
		return true;
	}
	UClass* Class = FindFirstObject<UClass>(*ClassPathName);
	if (Class != nullptr && Class->IsChildOf(InClass))
	{
		return true;
	}
	return false;
}