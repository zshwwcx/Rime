#include "Profiling/KGUIProfilingRecord.h"

#include "SceneInterface.h"
#include "TimerManager.h"
#include "Blueprint/GameViewportSubsystem.h"
#include "Core/Common.h"
#include "Engine/Font.h"
#include "Engine/World.h"
#include "Profiling/KGUMGMemorySnapshot.h"
#include "Stats/StatsData.h"

FKGUIProfilingCheckpoint FKGUIProfilingCheckpoint::CurrentCheckpoint;
FTimerHandle FKGUIProfilingCheckpoint::SnapshottingHandle;
TSharedPtr<FKGStatsPrimaryEnableScoped> FKGUIProfilingCheckpoint::StatsPrimaryEnableScoped;

FKGUIProfilingCheckpoint FKGUIProfilingRecord::LastBeginCheckpoint;
FKGUIProfilingCheckpoint FKGUIProfilingRecord::LastEndCheckpoint;

UE_DISABLE_OPTIMIZATION

#if STATS
struct FKGStackStatsTraverser
{
public:
	DECLARE_DELEGATE_OneParam(FKGStackStatsTraverseCallback, const FStatMessage&);

	FKGStackStatsTraverser(FStatsThreadState& InStats, int64 InFrame)
		: Stats(InStats)
	{
		Stats.UncondenseStackStats(InFrame, StackStatsRoot, nullptr, &NonStackStats);
	}

	void Traverse(const FKGStackStatsTraverseCallback& Callback)
	{
		for (auto NonStackStat : NonStackStats)
		{
			Callback.ExecuteIfBound(NonStackStat);
		}
		TraverseInternal(&StackStatsRoot, Callback);
	}

private:
	static void TraverseInternal(FRawStatStackNode* CurrentNode, const FKGStackStatsTraverseCallback& Callback)
	{
		Callback.ExecuteIfBound(CurrentNode->Meta);
		for (auto Pair : CurrentNode->Children)
		{
			TraverseInternal(Pair.Get<1>(), Callback);
		}
	}

	FStatsThreadState& Stats;
	FRawStatStackNode StackStatsRoot;
	TArray<FStatMessage> NonStackStats;
};

struct FKGStatMessageValueHelper
{
	static bool GetInt64(const FStatMessage& StatMessage, int64& OutValue)
	{
		EStatDataType::Type DataType = StatMessage.NameAndInfo.GetField<EStatDataType>();
		if (DataType != EStatDataType::ST_int64)
		{
			return false;
		}
		OutValue = StatMessage.GetValue_int64();
		return true;
	}

	static int64 GetInt64Checked(const FStatMessage& StatMessage)
	{
		int64 Result;
		GetInt64(StatMessage, Result);
		return Result;
	}

	static bool GetDouble(const FStatMessage& StatMessage, double& OutValue)
	{
		EStatDataType::Type DataType = StatMessage.NameAndInfo.GetField<EStatDataType>();
		if (DataType != EStatDataType::ST_double)
		{
			return false;
		}
		OutValue = StatMessage.GetValue_double();
		return true;
	}

	static double GetDoubleChecked(const FStatMessage& StatMessage)
	{
		double Result;
		GetDouble(StatMessage, Result);
		return Result;
	}
};

#endif

bool FKGUIProfilingCheckpoint::Snapshot(const FSimpleDelegate& InFinishCallback)
{
#if STATS
	if (SnapshottingHandle.IsValid())
	{
		return false;
	}
	check(!StatsPrimaryEnableScoped);
	StatsPrimaryEnableScoped = MakeShared<FKGStatsPrimaryEnableScoped>();
	GWorld->GetTimerManager().SetTimer(SnapshottingHandle, FTimerDelegate::CreateLambda([Checkpoint=*this, FinishCallback=InFinishCallback]()
	{
		CurrentCheckpoint.SnapshotInternal();
		FinishCallback.ExecuteIfBound();
		{
			SnapshottingHandle.Invalidate();
			FKGUIProfilingCheckpoint::StatsPrimaryEnableScoped = nullptr;
		}
	}), 1, false);
	return true;
#else
	return false;
#endif
}

bool FKGUIProfilingCheckpoint::SnapshotInternal()
{
#if STATS
	class FStatsThreadStateHelper : public FStatsThreadState
	{
	public:
		int64 GetLastFullFrameProcessed() const { return LastFullFrameProcessed; }
	};
	auto& Stats = (FStatsThreadStateHelper&)FStatsThreadState::GetLocalState();
	int64 LastFullFrame = Stats.GetLastFullFrameProcessed();
	if (Stats.IsFrameValid(LastFullFrame) == false)
	{
		Errors.Add(FString::Printf(TEXT("Invalid Last Full Processed Frame: %lld"), LastFullFrame));
		return false;
	}
	FKGStackStatsTraverser(Stats, LastFullFrame).Traverse(FKGStackStatsTraverser::FKGStackStatsTraverseCallback::CreateLambda(
		[this](const FStatMessage& StatMessage)  // cppcheck:ignore 这里传入this只会在FKGStackStatsTraverser::Traverse执行过程中持有，只会在这个SnapshotInternal函数的栈上持有
		{
			auto RawName = StatMessage.NameAndInfo.GetRawName();
			if (VisitedStatMessageNames.Contains(RawName))
			{
				Errors.Add(FString::Printf(TEXT("Stat Message `%s` has been visited."), *RawName.ToString()));
				return;
			}
			if (RawName == "STAT_SlatePrepass") { this->TickOverview.SlatePrepassTime = FKGStatMessageValueHelper::GetDoubleChecked(StatMessage); }
			if (RawName == "STAT_SlateDrawWindowTime") { this->TickOverview.SlateDrawWindowTime = FKGStatMessageValueHelper::GetDoubleChecked(StatMessage); }
			if (RawName == "STAT_SlateRenderingRTTime") { this->TickOverview.SlateRenderingTime = FKGStatMessageValueHelper::GetDoubleChecked(StatMessage); }
			if (RawName == "STAT_SlateNumBatches") { this->DrawingOverview.DrawCallCount = FKGStatMessageValueHelper::GetInt64Checked(StatMessage); }
			else
			{
				return;
			}
			VisitedStatMessageNames.Add(RawName);
		}
	));
	this->DrawingOverview.OverDrawAvgCount = GWorld->Scene->SlateOverDrawAvg;
	this->DrawingOverview.OverDrawMaxCount = GWorld->Scene->SlateMaxOverDrawCount;
#if ENABLE_LOW_LEVEL_MEM_TRACKER
	if (FLowLevelMemTracker::Get().IsEnabled())
	{
		this->MemoryOverview.TextureMemory = FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::Textures);
		this->MemoryOverview.TextMemory = FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, FName("UI_Text"), ELLMTagSet::None);
		this->MemoryOverview.OtherMemory =
			FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, FName("UI_Style"), ELLMTagSet::None) +
			FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, FName("UI_Texture"), ELLMTagSet::None) +
			FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, FName("UI_UMG"), ELLMTagSet::None) +
			FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, FName("UI_Slate"), ELLMTagSet::None);
	}
	auto GameViewport = UGameViewportSubsystem::Get(GWorld->GetWorld());
	MemorySnapshot = FKGUMGMemorySnapshot::GenerateMemoryStatisticsTree(GameViewport);
#endif
	if (Errors.Num() != 0)
	{
		return false;
	}
	bValid = true;
	return true;
#else
	return false;
#endif

}

bool FKGUIProfilingRecord::Begin(const FSimpleDelegate& InFinishCallback)
{
#if STATS
	if (FKGUIProfilingCheckpoint::IsSnapshotting())
	{
		return false;
	}
	auto& CurrentCheckpoint = FKGUIProfilingCheckpoint::ResetCurrentCheckpoint();
	return CurrentCheckpoint.Snapshot(FSimpleDelegate::CreateLambda([FinishCallback=InFinishCallback]()
	{
		auto& CurrentCheckpoint = FKGUIProfilingCheckpoint::GetCurrentCheckpoint();
		CurrentCheckpoint.Timestamp = FDateTime::Now();
		LastBeginCheckpoint = CurrentCheckpoint;
		FinishCallback.ExecuteIfBound();
	}));
#else
return false;
#endif

}

bool FKGUIProfilingRecord::End(const FSimpleDelegate& InFinishCallback)
{
#if STATS
	if (FKGUIProfilingCheckpoint::IsSnapshotting())
	{
		return false;
	}
	auto& CurrentCheckpoint = FKGUIProfilingCheckpoint::ResetCurrentCheckpoint();
	CurrentCheckpoint.Timestamp = FDateTime::Now();
	return CurrentCheckpoint.Snapshot(FSimpleDelegate::CreateLambda([FinishCallback = InFinishCallback]()
	{
		auto& CurrentCheckpoint = FKGUIProfilingCheckpoint::GetCurrentCheckpoint();
		LastEndCheckpoint = CurrentCheckpoint;
		FinishCallback.ExecuteIfBound();
	}));
#else
	return false;
#endif
}

FKGUIProfilingRecord FKGUIProfilingRecord::Create(const FKGUIProfilingCheckpoint& InBeginCheckpoint, const FKGUIProfilingCheckpoint& InEndCheckpoint)
{
	FKGUIProfilingRecord Record;
	Record.BeginCheckpoint = InBeginCheckpoint;
	Record.EndCheckpoint = InEndCheckpoint;
	;
	return MoveTemp(Record);
}

#if STATS
static FAutoConsoleCommand GDumpProfilingRecordBegin
(
	TEXT("KGUI.ProfilingRecord.Begin"),
	TEXT("Begin to dump profiling record."),
	FConsoleCommandDelegate::CreateLambda([]()
	{
		if (!FKGUIProfilingRecord::Begin())
		{
			UE_LOG(LogKGUI, Display, TEXT("Failed to Execute `KGUI.ProfilingRecord.Begin`."));
		}
	})
);

static FAutoConsoleCommand GDumpProfilingRecordEnd
(
	TEXT("KGUI.ProfilingRecord.End"),
	TEXT("End dumping profiling record."),
	FConsoleCommandDelegate::CreateLambda([]()
	{
		auto bOK = FKGUIProfilingRecord::End(FSimpleDelegate::CreateLambda([]()
		{
			auto& BeginCheckpoint = FKGUIProfilingRecord::GetLastBeginCheckpoint();
			auto& EndCheckpoint = FKGUIProfilingRecord::GetLastEndCheckpoint();
			bool bHasError = false;
			if (BeginCheckpoint.HasError())
			{
				UE_LOG(LogKGUI, Display, TEXT("Error Occurred in Begin Checkpoint:"))
				for (auto Error : BeginCheckpoint.Errors)
				{
					UE_LOG(LogKGUI, Display, TEXT("\t%s"), *Error);
				}
				bHasError = true;
			}
			if (EndCheckpoint.HasError())
			{
				UE_LOG(LogKGUI, Display, TEXT("Error Occurred in End Checkpoint:"))
				for (auto Error : EndCheckpoint.Errors)
				{
					UE_LOG(LogKGUI, Display, TEXT("\t%s"), *Error);
				}
				bHasError = true;
			}
			if (bHasError)
			{
				return;
			}
			auto Record = FKGUIProfilingRecord::Create(BeginCheckpoint, EndCheckpoint);
			FString DumpString;
			FKGUIProfilingRecord::StaticStruct()->ExportText(DumpString, &Record, nullptr, nullptr, PPF_None, nullptr);
			UE_LOG(LogKGUI, Display, TEXT("%s"), *DumpString);
		}));
		if (!bOK)
		{
			UE_LOG(LogKGUI, Display, TEXT("Failed to Execute `KGUI.ProfilingRecord.End`."));
		}
	})
);
#endif

UE_ENABLE_OPTIMIZATION