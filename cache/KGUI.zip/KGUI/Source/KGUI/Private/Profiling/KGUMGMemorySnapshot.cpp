#include "KGUI/Public/Profiling/KGUMGMemorySnapshot.h"

#include "KGSprite.h"
#include "MovieScene.h"
#include "NiagaraComponent.h"
#include "NiagaraSystemWidget.h"
#include "NiagaraUIComponent.h"
#include "PaperSprite.h"
#include "PaperSpriteAtlas.h"
#include "Blueprint/GameViewportSubsystem.h"
#include "Blueprint/UserWidget.h"
#include "Blueprint/WidgetTree.h"
#include "Engine/Font.h"
#include "Engine/FontFace.h"
#include "Slate/SlateTextureAtlasInterface.h"
#include "SpineAtlasAsset.h"
#include "SpineSkeletonDataAsset.h"
#include "Animation/WidgetAnimation.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Components/ListViewBase.h"
#include "Core/Common.h"
#include "Core/DynamicAtlas/DynamicAtlas.h"
#include "Core/DynamicAtlas/DynamicSprite.h"
#include "Extensions/WidgetBlueprintGeneratedClassExtension.h"
#include "UMG/Blueprint/KGTemporarySprite.h"

bool FKGUMGMemorySnapshot::IsWidgetFinalVisible(UWidget* Widget)
{
	if (!Widget->IsVisible())
	{
		return false;
	}
	auto Parent = Widget->GetParent();
	if (Parent != nullptr)
	{
		return IsWidgetFinalVisible(Parent);
	}
	if (auto WidgetTree = Cast<UWidgetTree>(Widget->GetOuter()))
	{
		if (auto UserWidget = Cast<UUserWidget>(WidgetTree->GetOuter()))
		{
			if (!IsWidgetFinalVisible(UserWidget))
			{
				return false;
			}
		}
	}
	return true;
}

FKGMemoryStatisticsTree FKGUMGMemorySnapshot::GenerateMemoryStatisticsTree(UObject* Object, TArray<UClass*> RejectedClasses)
{
	return
	FKGMemoryStatisticsTree::Build(Object, TDelegate<void(FKGMemoryStatisticsTree&, FKGMemoryStatisticsTreeNode&)>::CreateLambda(
		[RejectedClasses](FKGMemoryStatisticsTree& Tree, FKGMemoryStatisticsTreeNode& TreeNode)
		{
			static TArray PrimitiveObjectClasses = TArray<UClass*>{
				UTexture::StaticClass(),
				UMaterialInstance::StaticClass(),
				USlateTextureAtlasInterface::StaticClass(),
				UFont::StaticClass(),
				USpineAtlasAsset::StaticClass(),
				USpineSkeletonDataAsset::StaticClass(),
			};

			const auto& ObjectIdentity = TreeNode.GetObjectIdentity();
			auto Object = ObjectIdentity.GetObjectInternal();
			if (Object == nullptr)
			{
				return;
			}
			TreeNode.SetSize(Object->GetResourceSizeBytes(EResourceSizeMode::Exclusive));
			// UGameViewportSubsystem
			if (auto GameViewportSubsystem = Cast<UGameViewportSubsystem>(Object))
			{
				for (auto KeyValuePair : GameViewportSubsystem->GetViewportWidgets())
				{
					auto Widget = KeyValuePair.Key;
					TreeNode.AddDirectReferencingObject(Widget.ResolveObjectPtr(), RejectedClasses);
				}
				auto FontCache = FSlateApplication::Get().GetRenderer()->GetFontServices()->GetFontCache();
				for (uint8 Index = 0; Index < FontCache->GetNumAtlasPages(); Index++)
				{
					auto AtlasPageResource = FontCache->GetAtlasPageResource(Index);
					if (AtlasPageResource == nullptr)
					{
						continue;
					}
					auto& FontAtlasTreeNode = Tree.CreateUserTreeNode(TreeNode, (1 << 0) | Index);
					FontAtlasTreeNode.SetName(FString::Printf(TEXT("FontAtlas %d (%d×%d)"), Index, AtlasPageResource->GetWidth(), AtlasPageResource->GetHeight()));
					FontAtlasTreeNode.SetSize(AtlasPageResource->GetWidth() * AtlasPageResource->GetHeight());  // TODO: 没考虑ESlateFontAtlasContentType::Color
				}
			}
			// UUserWidget
			if (auto UserWidget = Cast<UUserWidget>(Object))
			{
				TreeNode.AddDirectReferencingObject(UserWidget->WidgetTree, RejectedClasses);
				TreeNode.AddDirectReferencingObject(UserWidget->GetClass(), RejectedClasses);
			}
			// UWidgetBlueprintGeneratedClass
			if (auto BPGC = Cast<UWidgetBlueprintGeneratedClass>(Object))
			{
				TreeNode.AddDirectReferencingObject(BPGC->GetWidgetTreeArchetype(), RejectedClasses);
				TreeNode.AppendDirectReferencingObjects(BPGC->GetExtensions(UWidgetBlueprintGeneratedClassExtension::StaticClass(), true), RejectedClasses);
				TreeNode.AppendDirectReferencingObjects(BPGC->Animations, RejectedClasses);
			}
			// UWidgetAnimation
			if (auto WidgetAnimation = Cast<UWidgetAnimation>(Object))
			{
				TreeNode.AddDirectReferencingObject(WidgetAnimation->GetMovieScene(), RejectedClasses);
			}
			// UMovieScene
			if (auto MovieScene = Cast<UMovieScene>(Object))
			{
				TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(MovieScene, TArray{ UMovieSceneTrack::StaticClass() });
				TreeNode.AppendDirectReferencingObjects(ReferencingObjects, RejectedClasses);
			}
			// UMovieSceneTrack
			if (auto MovieSceneTrack = Cast<UMovieSceneTrack>(Object))
			{
				TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(MovieSceneTrack, TArray{ UMovieSceneSection::StaticClass() });
				TreeNode.AppendDirectReferencingObjects(ReferencingObjects, RejectedClasses);
			}
			// UMovieSceneSection
			if (auto MovieSceneSection = Cast<UMovieSceneSection>(Object))
			{
				TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(MovieSceneSection, PrimitiveObjectClasses);
				TreeNode.AppendDirectReferencingObjects(ReferencingObjects, RejectedClasses);
			}
			// UWidgetTree
			if (auto WidgetTree = Cast<UWidgetTree>(Object))
			{
				TArray<UWidget*> AllWidgets;
				WidgetTree->GetAllWidgets(AllWidgets);
				for (auto Widget : AllWidgets)
				{
					TreeNode.AddDirectReferencingObject(Widget, RejectedClasses);
				}
			}
			// UWidget
			if (auto Widget = Cast<UWidget>(Object))
			{
				TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(Widget, PrimitiveObjectClasses);
				TreeNode.AppendDirectReferencingObjects(ReferencingObjects, RejectedClasses);
				TreeNode.AddDirectReferencingObject(Widget->Slot, RejectedClasses);
				TreeNode.SetName(FString::Printf(TEXT("%s %s"), IsWidgetFinalVisible(Widget) ? TEXT("■") : TEXT("□"), *Widget->GetName()));
			}
			// ListViewBase
			if (auto ListViewBase = Cast<UListViewBase>(Object))
			{
				TArray<TObjectPtr<UUserWidget>> ActiveWidgets;
				TArray<TObjectPtr<UUserWidget>> InactiveWidgets;
				FUserWidgetPool::StaticStruct()->FindPropertyByName("ActiveWidgets")->GetValue_InContainer(&ListViewBase->EntryWidgetPool, &ActiveWidgets);
				FUserWidgetPool::StaticStruct()->FindPropertyByName("InactiveWidgets")->GetValue_InContainer(&ListViewBase->EntryWidgetPool, &InactiveWidgets);
				TreeNode.AppendDirectReferencingObjects(ActiveWidgets, RejectedClasses);
				TreeNode.AppendDirectReferencingObjects(InactiveWidgets, RejectedClasses);
			}
			// UTexture
			if (auto Texture = Cast<UTexture>(Object))
			{
				TreeNode.SetBackgroundTexture(Texture);
				if (auto Texture2D = Cast<UTexture2D>(Object))
				{
					TreeNode.SetName(FString::Printf(TEXT("%s (%d×%d)"), *Texture2D->GetPathName(), Texture2D->GetSizeX(), Texture2D->GetSizeY()));
				}
				if (auto CanvasRenderTarget2D = Cast<UCanvasRenderTarget2D>(Object))
				{
					TreeNode.SetName(FString::Printf(TEXT("%s (%d×%d)"), *CanvasRenderTarget2D->GetName(), CanvasRenderTarget2D->SizeX, CanvasRenderTarget2D->SizeY));
				}
			}
			// UMaterialInstance
			if (auto MaterialInstance = Cast<UMaterialInstance>(Object))
			{
				TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(MaterialInstance, TArray<UClass*>{ UTexture::StaticClass() });
				TreeNode.AppendDirectReferencingObjects(ReferencingObjects, RejectedClasses);
			}
			// USlateTextureAtlasInterface
			if (auto SlateTextureAtlasInterface = Cast<ISlateTextureAtlasInterface>(Object))
			{
				if (auto PaperSprite = Cast<UPaperSprite>(SlateTextureAtlasInterface))
				{
					// 非编辑器下使用UPaperSpriteAtlas并不能获取争取的统计结果
					// TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(PaperSprite, TArray<UClass*>{ UPaperSpriteAtlas::StaticClass() });
					// TreeNode.AppendDirectReferencingObjects(ReferencingObjects);
					TreeNode.AddDirectReferencingObject(PaperSprite->GetSlateAtlasData().AtlasTexture, RejectedClasses);
				}
				else if (auto DynamicSprite = Cast<UDynamicSprite>(SlateTextureAtlasInterface))
				{
					if (DynamicSprite->IsAtlased())
					{
						if (auto DynamicAtlas = Cast<UDynamicAtlas>(DynamicSprite->GetAtlas()))
						{
							TreeNode.AddDirectReferencingObject(DynamicAtlas, RejectedClasses);
						}
					}
					else
					{
						TreeNode.AddDirectReferencingObject(DynamicSprite->GetSourceTexture(), RejectedClasses);
					}
				}
				else if (auto* KGSprite = Cast<UKGSprite>(SlateTextureAtlasInterface))
				{
					if (auto* Texture = KGSprite->GetTexture())
					{
						TreeNode.AddDirectReferencingObject(Texture, RejectedClasses);
					}
				}
				else if (auto TemporarySprite = Cast<UKGTemporarySprite>(SlateTextureAtlasInterface))
				{
					TreeNode.AddDirectReferencingObject(TemporarySprite->ResourceObject, RejectedClasses);
				}
				else
				{
					UE_LOG(LogKGUI, Warning, TEXT("Unsupported ISlateTextureAtlasInterface object, class is %s."), *Object->GetClass()->GetName());
				}
			}
			// 非编辑器下使用UPaperSpriteAtlas并不能获取争取的统计结果
			// // UPaperSpriteAtlas
			// if (auto PaperSpriteAtlas = Cast<UPaperSpriteAtlas>(Object))
			// {
			//   TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(PaperSpriteAtlas, TArray<UClass*>{ UTexture::StaticClass() });
			//	 TreeNode.AppendDirectReferencingObjects(ReferencingObjects);
			// }
			// UDynamicAtlas
			if (auto DynamicAtlas = Cast<UDynamicAtlas>(Object))
			{
				TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(DynamicAtlas, TArray<UClass*>{ UTexture::StaticClass() });
				TreeNode.AppendDirectReferencingObjects(ReferencingObjects, RejectedClasses);
			}
			// UFont
			if (auto Font = Cast<UFont>(Object))
			{
				auto ResolveFontFace = [&TreeNode, RejectedClasses](const FTypeface& Typeface)
				{
					for (const FTypefaceEntry& TypefaceEntry : Typeface.Fonts)
					{
						UFontFace* FontFace = ConstCast(TObjectPtr<const UFontFace>(Cast<UFontFace>(TypefaceEntry.Font.GetFontFaceAsset())));
						TreeNode.AddDirectReferencingObject(FontFace, RejectedClasses);
					}
				};
				ResolveFontFace(Font->CompositeFont.DefaultTypeface);
				for (const FCompositeSubFont& SubTypeface : Font->CompositeFont.SubTypefaces)
				{
					ResolveFontFace(SubTypeface.Typeface);
				}
			}
			// USpineAtlasAsset
			if (auto SpineAtlasAsset = Cast<USpineAtlasAsset>(Object))
			{
				TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(SpineAtlasAsset, TArray<UClass*>{ UTexture::StaticClass() });
				TreeNode.AppendDirectReferencingObjects(ReferencingObjects, RejectedClasses);
			}
			// USpineSkeletonDataAsset
			if (auto SpineSkeletonDataAsset = Cast<USpineSkeletonDataAsset>(Object))
			{
			}
			// UNiagaraSystemWidget
			if (auto NiagaraSystemWidget = Cast<UNiagaraSystemWidget>(Object))
			{
				TreeNode.AddDirectReferencingObject(NiagaraSystemWidget->GetNiagaraComponent(), RejectedClasses);
				TreeNode.AppendDirectReferencingObjects(Tree.GetUserData(ObjectIdentity).GetTransientReferencingObjects(), RejectedClasses);
			}
			// UKGMeshWidget
			if (auto MeshWidget = Cast<UKGMeshWidget>(Object))
			{
				TreeNode.AddDirectReferencingObject(MeshWidget->MeshAsset, RejectedClasses);
			}
		})
	);
}

FKGMemoryStatisticsTree FKGUMGMemorySnapshot::GenerateMemoryStatisticsTreeComprehensively(UObject* Object)
{
	TSet<UObject*> VisitedSet;
	return
	FKGMemoryStatisticsTree::Build(Object, TDelegate<void(FKGMemoryStatisticsTree&, FKGMemoryStatisticsTreeNode&)>::CreateLambda(
		[&VisitedSet](FKGMemoryStatisticsTree& Tree, FKGMemoryStatisticsTreeNode& TreeNode)
		{
			auto Object = TreeNode.GetObjectIdentity().GetObjectInternal();
			if (Object == nullptr)
			{
				return;
			}
			if (VisitedSet.Contains(Object))
			{
				return;
			}
			VisitedSet.Add(Object);

			// UGameViewportSubsystem
			if (auto GameViewportSubsystem = Cast<UGameViewportSubsystem>(Object))
			{
				for (auto KeyValuePair : GameViewportSubsystem->GetViewportWidgets())
				{
					auto Widget = KeyValuePair.Key;
					TreeNode.AddDirectReferencingObject(Widget.ResolveObjectPtr(), {});
				}
			}

			// Any Other
			TSet<UObject*> ReferencingObjects = Tree.ResolveReferencingObjects(Object, TArray<UClass*>{
				UObject::StaticClass(),
			});
			for (auto ReferencingObject : ReferencingObjects)
			{
				TreeNode.AddDirectReferencingObject(ReferencingObject, {});
			}
		})
	);
}

FString FKGUMGMemorySnapshot::GetDefaultMemoryStatisticsTreeDirectoryPath()
{
	return *(FPaths::ProfilingDir() / TEXT("MemoryStatisticsTrees"));
}

bool FKGUMGMemorySnapshot::GenerateDefaultMemoryStatisticsTreeFilePath(FString& FullPath)
{
	auto DirectoryPath = GetDefaultMemoryStatisticsTreeDirectoryPath();
	if (!IFileManager::Get().MakeDirectory(*DirectoryPath, true))
	{
		return false;
	}
	auto FileName = CreateProfileFilename(TEXT(""), TEXT(".memorystatisticstree"), true);
	FullPath = DirectoryPath / FileName;
	return true;
}

void FKGUMGMemorySnapshot::SaveMemoryStatisticsTree(const TArray<FString>& Args)
{
	FString FullPath;
	if (!GenerateDefaultMemoryStatisticsTreeFilePath(FullPath))
	{
		return;
	}
	SaveMemoryStatisticsTree(Args, FullPath);
}

void FKGUMGMemorySnapshot::SaveMemoryStatisticsTree(const TArray<FString>& Args, const FString& FilePath)
{
	auto RootObject = ResolveObjectWithCommandArguments(Args);
	auto Tree = FKGUMGMemorySnapshot::GenerateMemoryStatisticsTree(RootObject);
	{
#if UE_BUILD_SHIPPING
		TUniquePtr<FArchive> Ar;
#else
		TUniquePtr<FArchive> Ar = TUniquePtr<FArchive>(IFileManager::Get().CreateDebugFileWriter(*FilePath));
#endif
		if (!Ar)
		{
			UE_LOG(LogKGUI, Error, TEXT("Failed to Save Memory Statistics Tree File: %s"), *FilePath);
			return;
		}
		Ar->SetWantBinaryPropertySerialization(true);
		FKGMemoryStatisticsTree::StaticStruct()->SerializeItem(*Ar, &Tree, nullptr);
	}
	UE_LOG(LogKGUI, Log, TEXT("Memory Statistics Tree File Saved: %s"), *FilePath);
}

bool FKGUMGMemorySnapshot::LoadMemoryStatisticsTree(const FString& FullFilePath, FKGMemoryStatisticsTree& Tree)
{
	TUniquePtr<FArchive> Ar = TUniquePtr<FArchive>(IFileManager::Get().CreateFileReader(*FullFilePath));
	if (!Ar)
	{
		return false;
	}
	Ar->SetWantBinaryPropertySerialization(true);
	FKGMemoryStatisticsTree::StaticStruct()->SerializeItem(*Ar, &Tree, nullptr);
	return true;
}

UObject* FKGUMGMemorySnapshot::ResolveObjectWithCommandArguments(const TArray<FString>& Args)
{
	UObject* RootObject = nullptr;
	if (Args.Num() >= 1)
	{
		RootObject = FindFirstObject<UObject>(*Args[0]);

		if (!RootObject)
		{
			UE_LOG(LogKGUI, Error, TEXT("Can not resolve the input object name \"%s\"."), *Args[0]);
		}
		else
		{
			UE_LOG(LogKGUI, Log, TEXT("The input object name \"%s\" is resolved as \"%s\"."), *Args[0], *RootObject->GetFullName());
		}
	}
	else
	{
		RootObject = UGameViewportSubsystem::Get(GWorld->GetWorld());
		if (!RootObject)
		{
			UE_LOG(LogKGUI, Error, TEXT("GameViewportSubsystem object is missing."));
		}
	}
	return RootObject;
}

static FAutoConsoleCommand GSaveMemoryStatisticsTree
(
	TEXT("KGUI.SaveMemoryStatisticsTree"),
	TEXT("Save memory statistics tree to file."),
	FConsoleCommandWithArgsDelegate::CreateStatic(FKGUMGMemorySnapshot::SaveMemoryStatisticsTree)
);
