#include "Profiling/KGMemoryStatisticsTreeAnalyser.h"

#include "MovieSceneSection.h"
#include "MovieSceneTrack.h"
#include "PaperSprite.h"
#include "PaperSpriteAtlas.h"
#include "Blueprint/GameViewportSubsystem.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Components/PanelSlot.h"
#include "Core/Common.h"
#include "Core/DynamicAtlas/DynamicAtlas.h"
#include "Engine/Font.h"
#include "Profiling/KGUMGMemorySnapshot.h"
#include "Profiling/KGMemoryStatisticsObjectIdentity.h"
#include "Animation/WidgetAnimation.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInterface.h"

void FKGMemoryStatisticsTreeAnalyser::RebuildFullMergedUserData(const FKGMemoryStatisticsTree& MemoryStatisticsTree)
{
	FullMergedUserData = FKGMemoryStatisticsTreeUserData();
	for (const auto& Pair : MemoryStatisticsTree.GetUserDatas())
	{
		const auto& UserData = Pair.Get<1>();
		FullMergedUserData.MergeWith(UserData);
	}
}

TMap<FString, int> FKGMemoryStatisticsTreeAnalyser::GetObjectCountCache(const FKGMemoryStatisticsTree& MemoryStatisticsTree)
{
	TMap<FString, int> ObjectCountCache;
	for (auto& Pair : MemoryStatisticsTree.GetTreeNodeLookups())
	{
		auto ObjectIdentity = Pair.Get<0>();
		IncreaseObjectCountCache(ObjectCountCache, ObjectIdentity);
	}
	return ObjectCountCache;
}

void FKGMemoryStatisticsTreeAnalyser::IncreaseObjectCountCache(TMap<FString, int>& ObjectCountCache, const FKGMemoryStatisticsObjectIdentity& ObjectIdentity)
{
	FString ClassName;
	if (ObjectIdentity.IsA(UWidget::StaticClass())) { ClassName = UWidget::StaticClass()->GetName(); }
	else if (ObjectIdentity.IsA(UPanelSlot::StaticClass())) { ClassName = UPanelSlot::StaticClass()->GetName(); }
	else if (ObjectIdentity.IsA(UMovieSceneTrack::StaticClass())) { ClassName = UMovieSceneTrack::StaticClass()->GetName(); }
	else if (ObjectIdentity.IsA(UMovieSceneSection::StaticClass())) { ClassName = UMovieSceneSection::StaticClass()->GetName(); }
	else if (ObjectIdentity.GetID() != 0)
	{
		ClassName = ObjectIdentity.GetClassName();
	}
	if (!ClassName.IsEmpty())
	{
		if (!ObjectCountCache.Contains(ClassName))
		{
			ObjectCountCache.Add(ClassName, 0);
		}
		ObjectCountCache[ClassName] += 1;
	}
}

SIZE_T FKGMemoryStatisticsTreeAnalyser::GetSubTreeSize(const FKGMemoryStatisticsTree& MemoryStatisticsTree, const FKGMemoryStatisticsTreeNode& SubTreeRoot, EKGSubTreeSizeType SizeType, TSet<FKGMemoryStatisticsObjectIdentity>& ObjectIdentitySet)
{
	SIZE_T Size = 0;
	auto TryAdd = [&ObjectIdentitySet, &Size](const FKGMemoryStatisticsTreeNode& TreeNode)
	{
		auto ObjectIdentity = TreeNode.GetObjectIdentity();
		if (ObjectIdentity.GetID() != 0)
		{
			if (!ObjectIdentitySet.Contains(ObjectIdentity))
			{
				ObjectIdentitySet.Add(ObjectIdentity);
				Size += TreeNode.GetSize();
			}
			return true;
		}
		else if (ObjectIdentity.GetUserID() != 0)
		{
			Size += TreeNode.GetSize();
			return true;
		}
		return false;
	};
	TryAdd(SubTreeRoot);
	const TSet<FKGMemoryStatisticsObjectIdentity>* ReferencingObjectIdentitySet = nullptr;
	switch (SizeType)
	{
	case EKGSubTreeSizeType::Full:
		ReferencingObjectIdentitySet = &SubTreeRoot.GetFullReferencingObjectIdentities();
		break;
	case EKGSubTreeSizeType::Closure:
		ReferencingObjectIdentitySet = &SubTreeRoot.GetClosureReferencingObjectIdentities();
		break;
	}
	for (auto ReferencingObjectIdentity : *ReferencingObjectIdentitySet)
	{
		auto TreeNode = MemoryStatisticsTree.GetTreeNode(ReferencingObjectIdentity);
		TryAdd(TreeNode);
	}
	return Size;
}

struct FKGMemoryStatisticsObjectIdentityReferencingCache
{
	TMap<FKGMemoryStatisticsObjectIdentity, TSet<FKGMemoryStatisticsObjectIdentity>> ReferencingData;
	TMap<FKGMemoryStatisticsObjectIdentity, TSet<FKGMemoryStatisticsObjectIdentity>> ReversedReferencingData;

	bool IsReferencedByClass(const FKGMemoryStatisticsObjectIdentity& ReferencedObjectIdentity, UClass* ReferencingObjectClass)
	{
		auto* Found = ReversedReferencingData.Find(ReferencedObjectIdentity);
		if (Found == nullptr)
		{
			return false;
		}
		for (auto& ReversedReferencingObjectIdentity : *Found)
		{
			if (ReversedReferencingObjectIdentity.IsA(ReferencingObjectClass))
			{
				return true;
			}
		}
		return false;
	}
};

void FKGMemoryStatisticsTreeAnalyser::Analyse(const FKGMemoryStatisticsTree& MemoryStatisticsTree)
{
	const auto& MemorySnapshotTreeNodeLookups = MemoryStatisticsTree.GetTreeNodeLookups();
	FKGMemoryStatisticsObjectIdentityReferencingCache FullReferencingCache;
	for (auto Pair : MemorySnapshotTreeNodeLookups)
	{
		auto& ObjectIdentity = Pair.Get<0>();
		auto& TreeNode = Pair.Get<1>();
		for (auto& FullReferencingObjectIdentity : TreeNode.GetFullReferencingObjectIdentities())
		{
			FullReferencingCache.ReferencingData.FindOrAdd(ObjectIdentity).Add(FullReferencingObjectIdentity);
			FullReferencingCache.ReversedReferencingData.FindOrAdd(FullReferencingObjectIdentity).Add(ObjectIdentity);
		}
	}

	TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode> FontAssetMap;
	TMap<uint64, FKGMemoryStatisticsTreeNode> FontTextureMap;
	TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode> StaticAtlasMap;
	TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode> DynamicAtlasMap;
	TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode> MaterialReferencingUnpackedTextureMap;
	TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode> TextureMap;
	TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode> StaticMeshMap;
	TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode> MaterialMap;

	for (auto Pair : MemorySnapshotTreeNodeLookups)
	{
		auto& ObjectIdentity = Pair.Get<0>();
		auto& TreeNode = Pair.Get<1>();
		auto ID = ObjectIdentity.GetID();
		auto UserID = ObjectIdentity.GetUserID();
		/* Font */ if (ObjectIdentity.IsA(UFont::StaticClass()))
		{
			FontAssetMap.FindOrAdd(ObjectIdentity, TreeNode);
		}
		/* Font Texture */ else if (ID == 0 && TreeNode.GetName().Contains(TEXT("FontAtlas")))
		{
			if (FontTextureMap.Contains(UserID))
			{
				UE_LOG(LogKGUI, Error, TEXT("Duplicated Font Atlas 's User ID: %lld"), UserID);
			}
			else
			{
				FontTextureMap.Add(UserID, TreeNode);
			}
		}
		/* Static Mesh */ else if (ObjectIdentity.IsA(UStaticMesh::StaticClass()))
		{
			StaticMeshMap.FindOrAdd(ObjectIdentity, TreeNode);
		}
		// 非编辑器下使用UPaperSpriteAtlas并不能获取正确的统计结果
		// /* Paper Sprite Atlas */ else if (ObjectIdentity.IsA(UPaperSpriteAtlas::StaticClass()))
		// {
		// 	 StaticAtlasMap.FindOrAdd(ObjectIdentity, TreeNode);
		// }
		/* Texture */ else if (ObjectIdentity.IsA(UTexture::StaticClass()))
		{
			/* Paper Sprite Atlas (Both Available in Runtime or Editor) */ if (FullReferencingCache.IsReferencedByClass(ObjectIdentity, UPaperSprite::StaticClass()))
			{
				StaticAtlasMap.FindOrAdd(ObjectIdentity, TreeNode);
			}
			/* Unpacked Texture Referenced by Material */else if (FullReferencingCache.IsReferencedByClass(ObjectIdentity, UMaterialInterface::StaticClass()))
			{
				MaterialReferencingUnpackedTextureMap.FindOrAdd(ObjectIdentity, TreeNode);
			}
			if (ObjectIdentity.IsA(UDynamicAtlasCanvasRenderTarget2D::StaticClass()))
			{
				DynamicAtlasMap.FindOrAdd(ObjectIdentity, TreeNode);
			}
			TextureMap.FindOrAdd(ObjectIdentity, TreeNode);
		}
		/* Material */ else if (ObjectIdentity.IsA(UMaterialInterface::StaticClass()))
		{
			MaterialMap.FindOrAdd(ObjectIdentity, TreeNode);
	}
	}
	TSet<FKGMemoryStatisticsObjectIdentity> TotalObjectSetExceptUnpackedTexture;

	{
		FontAsset.Count = FontAssetMap.Num();
		for (auto& Pair : FontAssetMap)
		{
			auto Object = Pair.Get<0>();
			auto& TreeNode = Pair.Get<1>();
			FontAsset.Memory += GetSubTreeSize(MemoryStatisticsTree, TreeNode, EKGSubTreeSizeType::Full, FontAssetObjectSet);
		}
		TotalObjectSetExceptUnpackedTexture.Append(FontAssetObjectSet);
	}

	{
		FontTexture.Count = FontTextureMap.Num();
		for (auto& Pair : FontTextureMap)
		{
			auto& TreeNode = Pair.Get<1>();
			FontTexture.Memory += GetSubTreeSize(MemoryStatisticsTree, TreeNode, EKGSubTreeSizeType::Full, FontTextureObjectSet);
			FontTextureTreeNodeSet.Add(TreeNode);
		}
		TotalObjectSetExceptUnpackedTexture.Append(FontTextureObjectSet);
	}

	{
		StaticAtlas.Count = StaticAtlasMap.Num();
		for (auto& Pair : StaticAtlasMap)
		{
			auto& TreeNode = Pair.Get<1>();
			StaticAtlas.Memory += GetSubTreeSize(MemoryStatisticsTree, TreeNode, EKGSubTreeSizeType::Full, StaticAtlasObjectSet);
		}
		TotalObjectSetExceptUnpackedTexture.Append(StaticAtlasObjectSet);
	}

	{
		DynamicAtlas.Count = DynamicAtlasMap.Num();
		for (auto& Pair : DynamicAtlasMap)
		{
			auto& TreeNode = Pair.Get<1>();
			DynamicAtlas.Memory += GetSubTreeSize(MemoryStatisticsTree, TreeNode, EKGSubTreeSizeType::Full, DynamicAtlasObjectSet);
		}
		TotalObjectSetExceptUnpackedTexture.Append(DynamicAtlasObjectSet);
	}

	{
		StaticMesh.Count = StaticMeshMap.Num();
		for (auto& Pair : StaticMeshMap)
		{
			auto& TreeNode = Pair.Get<1>();
			StaticMesh.Memory += GetSubTreeSize(MemoryStatisticsTree, TreeNode, EKGSubTreeSizeType::Full, StaticMeshObjectSet);
		}
		TotalObjectSetExceptUnpackedTexture.Append(StaticMeshObjectSet);
	}

	{
		MaterialReferencingUnpackedTexture.Count = MaterialReferencingUnpackedTextureMap.Num();
		for (auto& Pair : MaterialReferencingUnpackedTextureMap)
		{
			auto& TreeNode = Pair.Get<1>();
			MaterialReferencingUnpackedTexture.Memory += GetSubTreeSize(MemoryStatisticsTree, TreeNode, EKGSubTreeSizeType::Full, MaterialReferencingUnpackedTextureObjectSet);
		}
	}

	{
		Material.Count = MaterialMap.Num();
		for (auto& Pair : MaterialMap)
		{
			auto& TreeNode = Pair.Get<1>();
			Material.Memory += GetSubTreeSize(MemoryStatisticsTree, TreeNode, EKGSubTreeSizeType::Full, MaterialObjectSet);
		}
		TotalObjectSetExceptUnpackedTexture.Append(MaterialObjectSet);
	}

	for (auto& Pair : TextureMap)
	{
		auto Object = Pair.Get<0>();
		auto& TreeNode = Pair.Get<1>();
		if (TotalObjectSetExceptUnpackedTexture.Contains(Object))
		{
			continue;
		}
		UnpackedTexture.Count++;
		UnpackedTexture.Memory += TreeNode.GetSize();
		UnpackedTextureObjectSet.Add(Object);
	}

	ObjectCountCache = GetObjectCountCache(MemoryStatisticsTree);

	ObjectCountFromWidgetBlueprintGeneratedClass = SumUpFromObjectCountCache(GetObjectCountCache<UWidgetBlueprintGeneratedClass>(MemoryStatisticsTree));
	ObjectCountFromWidgetAnimation = SumUpFromObjectCountCache(GetObjectCountCache<UWidgetAnimation>(MemoryStatisticsTree));

	RebuildFullMergedUserData(MemoryStatisticsTree);
}

template <typename TargetType = UObject>
void DisplayObjectSet(const FKGMemoryStatisticsTree& MemoryStatisticsTree, const TSet<FKGMemoryStatisticsObjectIdentity>& ObjectIdentitySet, int MaxCount = 10)
{
	TArray<FKGMemoryStatisticsObjectIdentity> ObjectArray;
	for (auto ObjectIdentity : ObjectIdentitySet.Array())
	{
		if (ObjectIdentity.IsA(TargetType::StaticClass()))
		{
			ObjectArray.Add(ObjectIdentity);
		}
	}
	ObjectArray.StableSort([&MemoryStatisticsTree](const FKGMemoryStatisticsObjectIdentity& A, const FKGMemoryStatisticsObjectIdentity& B)
	{
		int SizeA = 0;
		int SizeB = 0;
		if (MemoryStatisticsTree.ContainsTreeNode(A))
		{
			SizeA = MemoryStatisticsTree.GetTreeNode(A).GetSize();
		}
		if (MemoryStatisticsTree.ContainsTreeNode(B))
		{
			SizeB = MemoryStatisticsTree.GetTreeNode(B).GetSize();
		}
		return SizeA > SizeB;
	});
	for (int Index = 0; Index < ObjectArray.Num() && Index < MaxCount; Index++)
	{
		auto ObjectIdentity = ObjectArray[Index];
		auto Memory = MemoryStatisticsTree.GetTreeNode(ObjectIdentity).GetSize();
		if (Memory == 0)
		{
			return;
		}
		UE_LOG(LogKGUI, Display, TEXT("\t%s (%s)"), *ObjectIdentity.GetObjectFullName(), *FText::AsMemory(Memory).ToString());
	}
	if (ObjectArray.Num() > MaxCount)
	{
		UE_LOG(LogKGUI, Display, TEXT("\t(More %d %s...)"), ObjectArray.Num() - MaxCount, (ObjectArray.Num() - MaxCount > 1 ? TEXT("Objects") : TEXT("Object")));
	}
};

template <typename TargetType = UObject>
void DisplayObjectSetWithReferencingObjects(const FKGMemoryStatisticsTree& MemoryStatisticsTree, const TSet<FKGMemoryStatisticsObjectIdentity>& ObjectIdentitySet)
{
	TMap<FKGMemoryStatisticsObjectIdentity, int> MemoryCache;
	for (auto ObjectIdentity : ObjectIdentitySet)
	{
		if (ObjectIdentity.IsA(TargetType::StaticClass()))
		{
			auto& Memory = MemoryCache.FindOrAdd(ObjectIdentity);
			auto& TreeNode = MemoryStatisticsTree.GetTreeNode(ObjectIdentity);
			
			for (auto& ReferencingObjectIdentity : TreeNode.GetFullReferencingObjectIdentities())
			{
				if (ReferencingObjectIdentity.GetID() == 0 || ReferencingObjectIdentity == ObjectIdentity)
				{
					continue;
				}
				if (!MemoryStatisticsTree.ContainsTreeNode(ReferencingObjectIdentity))
				{
					continue;
				}
				auto& ReferencingTreeNode = MemoryStatisticsTree.GetTreeNode(ReferencingObjectIdentity);
				Memory += ReferencingTreeNode.GetSize();
			}
		}
	}
	auto MemoryArray = MemoryCache.Array();
	using MemoryArrayElementType = typename decltype(MemoryArray)::ElementType;
	MemoryArray.StableSort([](const MemoryArrayElementType& A, const MemoryArrayElementType& B)
	{
		return A.template Get<1>() > B.template Get<1>();
	});
	for (auto MemoryPair : MemoryArray)
	{
		auto ObjectIdentity = MemoryPair.template Get<0>();
		auto& Memory = MemoryPair.template Get<1>();
		UE_LOG(LogKGUI, Display, TEXT("\t%s"), *ObjectIdentity.GetObjectFullName());
		auto& TreeNode = MemoryStatisticsTree.GetTreeNode(ObjectIdentity);
		for (auto& ReferencingObjectIdentity : TreeNode.GetFullReferencingObjectIdentities())
		{
			if (ReferencingObjectIdentity.GetID() == 0 || ReferencingObjectIdentity == ObjectIdentity)
			{
				continue;
			}
			if (!MemoryStatisticsTree.ContainsTreeNode(ReferencingObjectIdentity))
			{
				continue;
			}
			auto& ReferencingTreeNode = MemoryStatisticsTree.GetTreeNode(ReferencingObjectIdentity);
			UE_LOG(LogKGUI, Display, TEXT("\t\t%s (%s)"), *ReferencingObjectIdentity.GetObjectFullName(), *FText::AsMemory(ReferencingTreeNode.GetSize()).ToString());
		}
	}
};

static FAutoConsoleCommand GAnalyseMemoryStatisticsTree
(
	TEXT("KGUI.AnalyseMemoryStatisticsTree"),
	TEXT("Analyse memory statistics tree and display in output."),
	FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
	{
		auto StartTime = FDateTime::Now();
		auto RootObject = FKGUMGMemorySnapshot::ResolveObjectWithCommandArguments(Args);
#if false  // 统计全量对象引用
		auto Tree = FKGUMGMemorySnapshot::GenerateMemoryStatisticsTreeComprehensively(RootObject);
#else
		auto Tree = FKGUMGMemorySnapshot::GenerateMemoryStatisticsTree(RootObject);
#endif
		FKGMemoryStatisticsTreeAnalyser Analyser(Tree);

		UE_LOG(LogKGUI, Display, TEXT("Font Asset: %s"), *Analyser.GetFontAsset().ToString());
		DisplayObjectSetWithReferencingObjects<UFont>(Tree, Analyser.GetFontAssetObjectSet());

		UE_LOG(LogKGUI, Display, TEXT("Font Texture: %s"), *Analyser.GetFontTexture().ToString());
		for (auto& FontTextureTreeNode : Analyser.GetFontTextureTreeNodeSet())
		{
			UE_LOG(LogKGUI, Display, TEXT("\t%s (%s)"), *FontTextureTreeNode.GetName(), *FText::AsMemory(FontTextureTreeNode.GetSize()).ToString());
		}

		UE_LOG(LogKGUI, Display, TEXT("Static Atlas: %s"), *Analyser.GetStaticAtlas().ToString());
		//DisplayObjectSetWithReferencingObjects<UPaperSpriteAtlas>(Tree, Analyser.GetStaticAtlasObjectSet());
		DisplayObjectSet<UTexture>(Tree, Analyser.GetStaticAtlasObjectSet());

		UE_LOG(LogKGUI, Display, TEXT("Dynamic Atlas: %s"), *Analyser.GetDynamicAtlas().ToString());
		DisplayObjectSet<UTexture>(Tree, Analyser.GetDynamicAtlasObjectSet());

		UE_LOG(LogKGUI, Display, TEXT("Unpacked Texture: %s"), *Analyser.GetUnpackedTexture().ToString());
		DisplayObjectSet<UTexture>(Tree, Analyser.GetUnpackedTextureObjectSet());

		UE_LOG(LogKGUI, Display, TEXT("Unpacked Texture (Material Referencing): %s"), *Analyser.GetMaterialReferencingUnpackedTexture().ToString());
		DisplayObjectSet<UTexture>(Tree, Analyser.GetMaterialReferencingUnpackedTextureObjectSet());

		UE_LOG(LogKGUI, Display, TEXT("Object Count:"));
		int NameLength = FString(TEXT("Total")).Len();
		FString TotalFromWidgetBlueprintGeneratedClass = TEXT("Total from WidgetBlueprintGeneratedClass");
		FString TotalFromWidgetAnimation = TEXT("Total from WidgetAnimation");
		for (auto& Pair : Analyser.GetObjectCountCache())
		{
			NameLength = FMath::Max(Pair.Get<0>().Len(), NameLength);
		}
		NameLength = FMath::Max(TotalFromWidgetBlueprintGeneratedClass.Len(), NameLength);
		NameLength = FMath::Max(TotalFromWidgetAnimation.Len(), NameLength);
		int TotalCount = 0;
		for (auto& Pair : Analyser.GetObjectCountCache())
		{
			UE_LOG(LogKGUI, Display, TEXT("\t%*s %d"), NameLength, *Pair.Get<0>(), Pair.Get<1>());
			TotalCount += Pair.Get<1>();
		}
		UE_LOG(LogKGUI, Display, TEXT("\t%*s %d"), NameLength, *TotalFromWidgetBlueprintGeneratedClass, Analyser.GetObjectCountFromWidgetBlueprintGeneratedClass());
		UE_LOG(LogKGUI, Display, TEXT("\t%*s %d"), NameLength, *TotalFromWidgetAnimation, Analyser.GetObjectCountFromWidgetAnimation());
		UE_LOG(LogKGUI, Display, TEXT("\t%*s %d"), NameLength, TEXT("Total"), TotalCount);
		UE_LOG(LogKGUI, Display, TEXT("Time Cost: %lf ms"), (FDateTime::Now() - StartTime).GetTotalMilliseconds());
	})
);