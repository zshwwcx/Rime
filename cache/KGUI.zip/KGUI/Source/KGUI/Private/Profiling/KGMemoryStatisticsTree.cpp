#include "KGUI/Public/Profiling/KGMemoryStatisticsTree.h"

#include "NiagaraComponent.h"
#include "NiagaraLightRendererProperties.h"
#include "NiagaraMeshRendererProperties.h"
#include "NiagaraSpriteRendererProperties.h"
#include "NiagaraSystemInstanceController.h"
#include "Engine/StaticMesh.h"
#include "Engine/Texture.h"


FName FKGMemoryStatisticsTreeUserDataKeys::Niagara_Count = TEXT("Niagara_Count");
FName FKGMemoryStatisticsTreeUserDataKeys::Niagara_EmitterCount = TEXT("Niagara_EmitterCount");
FName FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleCPUCount = TEXT("Niagara_ParticleCPUCount");
FName FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleGPUCount = TEXT("Niagara_ParticleGPUCount");
FName FKGMemoryStatisticsTreeUserDataKeys::Niagara_PrimitiveCount = TEXT("Niagara_PrimitiveCount");
FName FKGMemoryStatisticsTreeUserDataKeys::Niagara_StaticMeshPrimitiveCount = TEXT("Niagara_StaticMeshPrimitiveCount");
FName FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureCount = TEXT("Niagara_TextureCount");
FName FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureMemory = TEXT("Niagara_TextureMemory");
FName FKGMemoryStatisticsTreeUserDataKeys::Niagara_LightCount = TEXT("Niagara_LightCount");
FName FKGMemoryStatisticsTreeUserDataKeys::MeshWidget_PrimitiveCount = TEXT("MeshWidget_PrimitiveCount");

FKGMemoryStatisticsTree FKGMemoryStatisticsTree::Build(UObject* InObject, const TDelegate<void(FKGMemoryStatisticsTree&, FKGMemoryStatisticsTreeNode&)>& InCallback)
{
	if (!InObject)
	{
		return FKGMemoryStatisticsTree();
	}
	FKGMemoryStatisticsTree Tree;
	Tree.Callback = InCallback;
	Tree.BuildMemoryMapNodeData(FKGMemoryStatisticsObjectIdentity(InObject));
	Tree.RootObjectIdentity = FKGMemoryStatisticsObjectIdentity(InObject);
	auto& Root = Tree.GetTreeNode(Tree.RootObjectIdentity);
	Root.PrepareComputedData(Tree.Lookups);
	Tree.OnPostBuild();
	return MoveTemp(Tree);
}

TSet<UObject*> FKGMemoryStatisticsTree::ResolveReferencingObjects(UObject* Object, const TArray<UClass*>& WhiteList) const
{
	return ResolveReferencingObjectsInternal(Object, Object->GetClass(), WhiteList);
}

FKGMemoryStatisticsTreeNode& FKGMemoryStatisticsTree::CreateUserTreeNode(FKGMemoryStatisticsTreeNode& Parent, uint64 InUserID)
{
	FKGMemoryStatisticsObjectIdentity ObjectIdentity(InUserID);
	auto& TreeNode = Lookups.Add(ObjectIdentity, FKGMemoryStatisticsTreeNode(ObjectIdentity));
	Parent.DirectReferencingObjectIdentities.Add(ObjectIdentity);
	return TreeNode;
}

void FKGMemoryStatisticsTree::RefreshNiagaraUserDatas()
{
	for (auto& Pair : UserDatas)
	{
		auto& ObjectIdentity = Pair.Key;

		if (auto NiagaraComponent = Cast<UNiagaraComponent>(ObjectIdentity.GetObjectInternal()))
		{
			auto LocalUserData = GenerateMemoryStatisticsTreeUserData(NiagaraComponent);

			Pair.Value.SetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_Count, LocalUserData.GetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_Count));
			Pair.Value.SetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_EmitterCount, LocalUserData.GetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_EmitterCount));
			Pair.Value.SetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleCPUCount, LocalUserData.GetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleCPUCount));
			Pair.Value.SetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleGPUCount, LocalUserData.GetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleGPUCount));
			Pair.Value.SetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_PrimitiveCount, LocalUserData.GetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_PrimitiveCount));
			Pair.Value.SetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_StaticMeshPrimitiveCount, LocalUserData.GetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_StaticMeshPrimitiveCount));
			Pair.Value.SetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureCount, LocalUserData.GetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureCount));
			Pair.Value.SetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureMemory, LocalUserData.GetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureMemory));
			Pair.Value.SetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_LightCount, LocalUserData.GetValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_LightCount));
		}
		else
		{
			Pair.Value.ClearValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_Count);
			Pair.Value.ClearValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_EmitterCount);
			Pair.Value.ClearValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleCPUCount);
			Pair.Value.ClearValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleGPUCount);
			Pair.Value.ClearValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_PrimitiveCount);
			Pair.Value.ClearValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_StaticMeshPrimitiveCount);
			Pair.Value.ClearValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureCount);
			Pair.Value.ClearValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureMemory);
			Pair.Value.ClearValue(FKGMemoryStatisticsTreeUserDataKeys::Niagara_LightCount);
		}
	}
}

TSet<UObject*> FKGMemoryStatisticsTree::ResolveReferencingObjectsInternal(void* Container, UStruct* Struct, const TArray<UClass*>& WhiteList) const
{
	TSet<UObject*> Set;
	if (Container == nullptr)
	{
		return Set;
	}
	for (TFieldIterator<FProperty> It(Struct); It; ++It)
	{
		FProperty* Property = *It;
		Set.Append(ResolveReferencingObjectsInternal(Container, Property, WhiteList));
	}
	return MoveTemp(Set);
}

TSet<UObject*> FKGMemoryStatisticsTree::ResolveReferencingObjectsInternal(void* Container, FProperty* Property, const TArray<UClass*>& WhiteList) const
{
	TSet<UObject*> Set;
	if (Container == nullptr)
	{
		return Set;
	}
	if (auto StructProperty = CastField<FStructProperty>(Property))
	{
		auto StructValue = StructProperty->ContainerPtrToValuePtr<void>(Container);
		Set.Append(ResolveReferencingObjectsInternal(StructValue, StructProperty->Struct, WhiteList));
	}
	if (auto ObjectProperty = CastField<FObjectPropertyBase>(Property))
	{
		if (auto Object = ObjectProperty->GetObjectPropertyValue_InContainer(Container))
		{
			for (auto* WhiteClass : WhiteList)
			{
				if (WhiteClass->HasAnyClassFlags(CLASS_Interface))
				{
					if (Object->GetClass()->ImplementsInterface(WhiteClass))
					{
						Set.Add(Object);
						break;
					}
				}
				else
				{
					if (Object->IsA(WhiteClass))
					{
						Set.Add(Object);
						break;
					}
				}
			}
		}
	}
	if (auto ArrayProperty = CastField<FArrayProperty>(Property))
	{
		FScriptArrayHelper ArrayHelper(ArrayProperty, ArrayProperty->ContainerPtrToValuePtr<void>(Container));
		for (int Index = 0; Index < ArrayHelper.Num(); Index++)
		{
			Set.Append(ResolveReferencingObjectsInternal(ArrayHelper.GetElementPtr(Index), ArrayProperty->Inner, WhiteList));
		}
	}
	if (auto MapProperty = CastField<FMapProperty>(Property))
	{
		FScriptMapHelper MapHelper(MapProperty, MapProperty->ContainerPtrToValuePtr<void>(Container));
		for (int Index = 0; Index < MapHelper.Num(); Index++)
		{
			if (!MapHelper.IsValidIndex(Index))
			{
				continue;
			}
			Set.Append(ResolveReferencingObjectsInternal(MapHelper.GetPairPtr(Index), MapProperty->KeyProp, WhiteList));
			Set.Append(ResolveReferencingObjectsInternal(MapHelper.GetPairPtr(Index), MapProperty->ValueProp, WhiteList));
		}
	}
	return MoveTemp(Set);
}

void FKGMemoryStatisticsTree::BuildMemoryMapNodeData(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity)
{
	check(ObjectIdentity.IsValid());
	if (Lookups.Contains(ObjectIdentity))
	{
		return;
	}
	auto& MemoryStatisticsTreeNode = Lookups.Add(ObjectIdentity, FKGMemoryStatisticsTreeNode(ObjectIdentity.GetObjectInternal()));
	OnAdded(ObjectIdentity, MemoryStatisticsTreeNode);
	Callback.Execute(*this, MemoryStatisticsTreeNode);
	auto DirectReferencingObjectIdentities = MemoryStatisticsTreeNode.GetDirectReferencingObjectIdentities();
	for (auto DirectReferencingObjectIdentity : DirectReferencingObjectIdentities)
	{
		if (!DirectReferencingObjectIdentity.IsValid())
		{
			continue;
		}
		BuildMemoryMapNodeData(DirectReferencingObjectIdentity);
		auto& DirectReferencingTreeNode = GetTreeNode(DirectReferencingObjectIdentity);
		DirectReferencingTreeNode.DirectReferenceCount++;
		GetTreeNode(ObjectIdentity).FullReferencingObjectIdentities.Add(DirectReferencingObjectIdentity);
		GetTreeNode(ObjectIdentity).FullReferencingObjectIdentities.Append(DirectReferencingTreeNode.FullReferencingObjectIdentities);
	}
}

void FKGMemoryStatisticsTree::OnAdded(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity, FKGMemoryStatisticsTreeNode& MemoryStatisticsTreeNode)
{
	if (auto NiagaraComponent = Cast<UNiagaraComponent>(ObjectIdentity.GetObjectInternal()))
	{
		TryMergeWithNonEmptyUserData(ObjectIdentity, GenerateMemoryStatisticsTreeUserData(NiagaraComponent));
	}
	if (auto MeshWidget = Cast<UKGMeshWidget>(ObjectIdentity.GetObjectInternal()))
	{
		TryMergeWithNonEmptyUserData(ObjectIdentity, GenerateMemoryStatisticsTreeUserData(MeshWidget));
	}
}

void FKGMemoryStatisticsTree::OnPostBuild()
{
}

void FKGMemoryStatisticsTree::TryMergeWithNonEmptyUserData(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity, const FKGMemoryStatisticsTreeUserData& MemoryStatisticsTreeUserData)
{
	if (MemoryStatisticsTreeUserData.IsEmpty())
	{
		return;
	}
	UserDatas.FindOrAdd(ObjectIdentity).MergeWith(MemoryStatisticsTreeUserData);
}

FKGMemoryStatisticsTreeUserData FKGMemoryStatisticsTree::GenerateMemoryStatisticsTreeUserData(UNiagaraComponent* NiagaraComponent)
{
	FKGMemoryStatisticsTreeUserData MemoryStatisticsTreeUserData;
	if (NiagaraComponent == nullptr)
	{
		return MoveTemp(MemoryStatisticsTreeUserData);
	}
	MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::Niagara_Count, 1);
	auto SystemInstanceController = NiagaraComponent->GetSystemInstanceController();
	if (SystemInstanceController == nullptr || SystemInstanceController->GetSystemInstance_Unsafe() == nullptr)
	{
		return MoveTemp(MemoryStatisticsTreeUserData);
	}
	auto EmitterInstances = SystemInstanceController->GetSystemInstance_Unsafe()->GetEmitters();
	for (auto EmitterInstance : EmitterInstances)
	{
		if (!EmitterInstance->IsActive())
		{
			continue;
		}
		MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::Niagara_EmitterCount, 1);

		auto NumParticles = EmitterInstance->GetNumParticles();
		MemoryStatisticsTreeUserData.IncreaseInteger(
			EmitterInstance->GetGPUContext() ? FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleGPUCount : FKGMemoryStatisticsTreeUserDataKeys::Niagara_ParticleCPUCount,
			NumParticles
		);

		TSet<UTexture*> TotalReferencedTextures;

		auto VersionedEmitter = EmitterInstance->GetVersionedEmitter();
		if (VersionedEmitter.Emitter)
		{
			auto PropertiesArray = VersionedEmitter.GetEmitterData()->GetRenderers();
			for (auto Properties : PropertiesArray)
			{
				if (Properties == nullptr)
				{
					continue;
				}
				TArray<UMaterialInterface*> UsedMaterials;
				Properties->GetUsedMaterials(&EmitterInstance.Get(), UsedMaterials);
				for (auto UsedMaterial : UsedMaterials)
				{
					if (UsedMaterial == nullptr)
					{
						continue;
					}
					auto ReferencedObjects = UsedMaterial->GetReferencedTextures();
					for (TObjectPtr<UObject> ReferencedObject : ReferencedObjects)
					{
						if (auto ReferencedTexture = Cast<UTexture>(ReferencedObject))
						{
							TotalReferencedTextures.Add(ReferencedTexture);
						}
					}
				}
				if (auto MeshRendererProperties = Cast<UNiagaraMeshRendererProperties>(Properties))
				{
					for (auto MeshProperties : MeshRendererProperties->Meshes)
					{
						if (MeshProperties.Mesh == nullptr)
						{
							continue;
						}
						MemoryStatisticsTreeUserData.AddTransientReferencingObject(MeshProperties.Mesh);
						FStaticMeshRenderData* StaticMeshRenderData = MeshProperties.Mesh->GetRenderData();
						int32 NumSections = StaticMeshRenderData->LODResources.Num();
						// QUESTION: 不应该是把每级LOD的面数加起来吧？
						// for (int32 SectionIndex = 0; SectionIndex < NumSections; SectionIndex++)
						// {
						//	 MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::Niagara_PrimitiveCount, StaticMeshRenderData->LODResources[SectionIndex].GetNumTriangles());
						// }
						if (NumSections > 0)
						{
							auto PrimitiveCount = StaticMeshRenderData->LODResources[0].GetNumTriangles() * NumParticles;
							MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::Niagara_PrimitiveCount, PrimitiveCount); // 没考虑LOG和Culling
							MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::Niagara_StaticMeshPrimitiveCount, PrimitiveCount); // 没考虑LOG和Culling
						}
					}
				}
				if (auto LightRendererProperties = Cast<UNiagaraLightRendererProperties>(Properties))
				{
					MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::Niagara_LightCount, NumParticles);
				}
				if (auto SpriteRendererProperties = Cast<UNiagaraSpriteRendererProperties>(Properties))
				{
					int NumPrimitives = SpriteRendererProperties->GetNumIndicesPerInstance() / 3;
					MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::Niagara_PrimitiveCount, NumPrimitives * NumParticles);  // 没考虑Culling
				}
			}
		}

		MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureCount, TotalReferencedTextures.Num());
		for (auto ReferencedTexture : TotalReferencedTextures)
		{
			if (ReferencedTexture == nullptr)
			{
				continue;
			}
			MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::Niagara_TextureMemory, ReferencedTexture->GetResourceSizeBytes(EResourceSizeMode::Exclusive));
			MemoryStatisticsTreeUserData.AddTransientReferencingObject(ReferencedTexture);
		}
	}
	return MoveTemp(MemoryStatisticsTreeUserData);
}

FKGMemoryStatisticsTreeUserData FKGMemoryStatisticsTree::GenerateMemoryStatisticsTreeUserData(UKGMeshWidget* MeshWidget)
{
	FKGMemoryStatisticsTreeUserData MemoryStatisticsTreeUserData;
	if (MeshWidget == nullptr || MeshWidget->MeshAsset == nullptr)
	{
		return MoveTemp(MemoryStatisticsTreeUserData);
	}
	MemoryStatisticsTreeUserData.IncreaseInteger(FKGMemoryStatisticsTreeUserDataKeys::MeshWidget_PrimitiveCount, MeshWidget->MeshAsset->GetNumTriangles(0));
	MemoryStatisticsTreeUserData.AddTransientReferencingObject(MeshWidget->MeshAsset);
	return MoveTemp(MemoryStatisticsTreeUserData);
}
