#include "KGUI/Public/Profiling/KGMemoryStatisticsTreeNode.h"

#include "Engine/Texture.h"
#include "Styling/SlateBrush.h"
#include "Styling/SlateColor.h"

FKGMemoryStatisticsTreeNode::FKGMemoryStatisticsTreeNode()
	: ObjectIdentity(nullptr)
{
}

FKGMemoryStatisticsTreeNode::FKGMemoryStatisticsTreeNode(const FKGMemoryStatisticsObjectIdentity& InObjectIdentity)
	: ObjectIdentity(InObjectIdentity)
{
}

FKGMemoryStatisticsTreeNode::FKGMemoryStatisticsTreeNode(UObject* InObject)
	: ObjectIdentity(InObject)
{
}

void FKGMemoryStatisticsTreeNode::AddDirectReferencingObject(UObject* InDirectReferencingObject, TArray<UClass*> RejectedClasses)
{
	if (InDirectReferencingObject == nullptr)
	{
		return;
	}
	for (auto RejectedClass : RejectedClasses)
	{
		if (InDirectReferencingObject->IsA(RejectedClass))
		{
			return;
		}
	}
	DirectReferencingObjectIdentities.Add(FKGMemoryStatisticsObjectIdentity(InDirectReferencingObject));
}

void FKGMemoryStatisticsTreeNode::AppendDirectReferencingObjects(const TSet<UObject*>& InDirectReferencingObjects, TArray<UClass*> RejectedClasses)
{
	for (auto DirectReferencingObject : InDirectReferencingObjects)
	{
		AddDirectReferencingObject(DirectReferencingObject, RejectedClasses);
	}
}

void FKGMemoryStatisticsTreeNode::AppendDirectReferencingObjects(const TArray<UObject*>& InDirectReferencingObjects, TArray<UClass*> RejectedClasses)
{
	for (auto DirectReferencingObject : InDirectReferencingObjects)
	{
		AddDirectReferencingObject(DirectReferencingObject, RejectedClasses);
	}
}

void FKGMemoryStatisticsTreeNode::SetSize(SIZE_T InSize)
{
	Size = InSize;
}

void FKGMemoryStatisticsTreeNode::SetName(const FString& InName)
{
	Name = InName;
}

FString FKGMemoryStatisticsTreeNode::GetName() const
{
	return Name;
}

FString FKGMemoryStatisticsTreeNode::GetTitleString() const
{
	return FString::Printf(TEXT("%s: $(SIZE) (%s)"),
		Name.IsEmpty()
			? *this->GetObjectIdentity().GetObjectName()
			: *Name,
		*this->GetObjectIdentity().GetClassName());
}

void FKGMemoryStatisticsTreeNode::SetBackgroundTexture(UTexture* InTexture)
{
	BackgroundTexture = InTexture;
	if (BackgroundTexture.Get() != nullptr)
	{
		BackgroundTexturePath = FSoftObjectPath(BackgroundTexture.Get()).ToString();
	}
	else
	{
		BackgroundTexturePath.Empty();
	}
}

bool FKGMemoryStatisticsTreeNode::PrepareComputedData(TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode>& Lookups)
{
	if (bComputedDataPrepared)
	{
		return false;
	}
	bComputedDataPrepared = true;
	for (auto DirectReferencingObjectIdentity : DirectReferencingObjectIdentities)
	{
		if (!DirectReferencingObjectIdentity.IsValid())
		{
			continue;
		}
		auto DirectReferencingTreeNodePtr = Lookups.Find(DirectReferencingObjectIdentity);
		if (!DirectReferencingTreeNodePtr)
		{
			continue;
		}
		auto& DirectReferencingTreeNode = *DirectReferencingTreeNodePtr;
		AddFullReferenceCount(DirectReferencingTreeNode.GetObjectIdentity(), 1, Lookups);
		if (!DirectReferencingTreeNode.PrepareComputedData(Lookups))
		{
			continue;
		}
		for (auto& FullReferenceCountPair : DirectReferencingTreeNode.FullReferenceCounts)
		{
			auto FullReferenceCountObjectIdentity = FullReferenceCountPair.Get<0>();
			int FullReferenceCount = FullReferenceCountPair.Get<1>();
			if (DirectReferencingTreeNode.ClosureReferencingObjectIdentities.Contains(FullReferenceCountObjectIdentity))
			{
				continue;
			}
			AddFullReferenceCount(FullReferenceCountObjectIdentity, FullReferenceCount, Lookups);
		}
	}
	for (auto& FullReferenceCountPair : FullReferenceCounts)
	{
		auto FullReferenceCountObjectIdentity = FullReferenceCountPair.Get<0>();
		int FullReferenceCount = FullReferenceCountPair.Get<1>();
		auto FullReferencingTreeNodePtr = Lookups.Find(FullReferenceCountObjectIdentity);
		if (!FullReferencingTreeNodePtr)
		{
			continue;
		}
		auto& FullReferencingTreeNode = *FullReferencingTreeNodePtr;
		if (FullReferencingTreeNode.DirectReferenceCount <= FullReferenceCount)
		{
			ClosureReferencingObjectIdentities.Add(FullReferenceCountObjectIdentity);
			ensure(FullReferencingTreeNode.DirectReferenceCount == FullReferenceCount);
		}
	}
	return true;
}

void FKGMemoryStatisticsTreeNode::AddFullReferenceCount(const FKGMemoryStatisticsObjectIdentity& InObjectIdentity, int Count, const TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode>& Lookups)
{
	if (FullReferenceCounts.Contains(InObjectIdentity))
	{
		FullReferenceCounts[InObjectIdentity] += Count;
	}
	else
	{
		FullReferenceCounts.Add(InObjectIdentity, Count);
	}
}

TSharedPtr<FSlateBrush> FKGMemoryStatisticsTreeNode::GetBackgroundBrush()
{
	if (BackgroundTexture == nullptr)
	{
		if (!BackgroundTexturePath.IsEmpty())
		{
			BackgroundTexture = Cast<UTexture>(FSoftObjectPath(BackgroundTexturePath).TryLoad());
		}
	}
	if (BackgroundTexture.Get() == nullptr)
	{
		BackgroundBrush = nullptr;
	}
	else
	{
		if (BackgroundBrush == nullptr)
		{
			BackgroundBrush = MakeShared<FSlateBrush>();
		}
		BackgroundBrush->SetResourceObject(BackgroundTexture.Get());
		BackgroundBrush->TintColor = FSlateColor(FLinearColor(1, 1, 1, 0.3));
	}
	return BackgroundBrush;
}

