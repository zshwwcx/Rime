#include "HUD/KGUserWidgetPool.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(KGUserWidgetPool)


FKGUserWidgetPool::FKGUserWidgetPool(UWidget& InOwningWidget)
	: OwningWidget(&InOwningWidget)
{}

FKGUserWidgetPool::~FKGUserWidgetPool()
{
	ResetPool();
}

void FKGUserWidgetPool::SetOwningWidget(UWidget* InOwningWidget)
{
    if (IsValid(InOwningWidget))
    {
        OwningWidget = InOwningWidget;
    }
}

void FKGUserWidgetPool::SetWorld(UWorld* InOwningWorld)
{
	OwningWorld = InOwningWorld;
}

void FKGUserWidgetPool::SetDefaultPlayerController(APlayerController* InDefaultPlayerController)
{
	DefaultPlayerController = InDefaultPlayerController;
}

void FKGUserWidgetPool::RebuildWidgets()
{
	for (UUserWidget* Widget : ActiveWidgets)
	{
		CachedSlateByWidgetObject.Add(Widget, Widget->TakeWidget());
	}
}

void FKGUserWidgetPool::AddReferencedObjects(FReferenceCollector& Collector)
{
	Collector.AddReferencedObjects<UUserWidget>(ActiveWidgets, OwningWidget.Get());
	Collector.AddReferencedObjects<UUserWidget>(InactiveWidgets, OwningWidget.Get());
}

void FKGUserWidgetPool::Release(UUserWidget* Widget, bool bReleaseSlate)
{
	if (Widget != nullptr)
	{
		const int32 ActiveWidgetIdx = ActiveWidgets.Find(Widget);
		if (ActiveWidgetIdx != INDEX_NONE)
		{
		    InactiveWidgets.Push(Widget);
			ActiveWidgets.RemoveAt(ActiveWidgetIdx);

			if (bReleaseSlate)
			{
				CachedSlateByWidgetObject.Remove(Widget);
			}
		}
	}
}

void FKGUserWidgetPool::Release(TArray<UUserWidget*> Widgets, bool bReleaseSlate)
{
	for (UUserWidget* Widget : Widgets)
	{
		Release(Widget, bReleaseSlate);
	}
}

void FKGUserWidgetPool::ReleaseAll(bool bReleaseSlate)
{
	InactiveWidgets.Append(ActiveWidgets);
	ActiveWidgets.Empty();

	if (bReleaseSlate)
	{
		CachedSlateByWidgetObject.Reset();
	}
}

void FKGUserWidgetPool::ResetPool()
{
	InactiveWidgets.Reset();
	ActiveWidgets.Reset();
	CachedSlateByWidgetObject.Reset();
}

void FKGUserWidgetPool::ReleaseInactiveSlateResources()
{
	for (UUserWidget* InactiveWidget : InactiveWidgets)
	{
		CachedSlateByWidgetObject.Remove(InactiveWidget);
	}
}

void FKGUserWidgetPool::ReleaseAllSlateResources()
{
	CachedSlateByWidgetObject.Reset();
}

