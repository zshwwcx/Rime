// Fill out your copyright notice in the Description page of Project Settings.


#include "HUD/ClickEffect/ClickEffectPanel.h"

#include "Manager/KGBasicManager.h"
#include "Misc/CommonDefines.h"
#include "Kismet/KismetInputLibrary.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "Blueprint/WidgetLayoutLibrary.h"

int32 GVarClickEffectNumConsoleVariable = 3;
static FAutoConsoleVariableRef CVarClickEffectNumConsoleVariable(
	TEXT("KGUI.ClickEffectNum"),
	GVarClickEffectNumConsoleVariable,
	TEXT("The maximum display quantity of common click effects on the HUD."),
	ECVF_Default
);



void UClickEffectPanel::InitData(UKGBasicManager* KGInputProcessManager)
{

	//ClickEffects.Add(WBP_ClickEffect1);
	//ClickEffects.Add(WBP_ClickEffect2);
	//ClickEffects.Add(WBP_ClickEffect3);

	//for (int i = 1; i <= ClickEffects.Num(); i++)
	//{
	//	auto WidgetName = FString::Printf(TEXT("WBP_QTEClickEffect%d"), i);
	//	if (auto tClickEffectWidget = Cast<UKGUserWidget>(GetWidgetFromName(*WidgetName)))
	//	{
	//		ClickEffectsQte.Add(tClickEffectWidget);
	//	}
	//}
	
	if (auto InputProcessorManager = Cast<UUKGInputProcessManager>(KGInputProcessManager))
	{
		InputProcessorManager->OnGetMouseButtonUpNoReplyDelegate.AddUniqueDynamic(this, &UClickEffectPanel::OnClickEffectShow);
		
		bShowClickEffect = true;
	}

	//CurPlayNormalIndex = 0;
	//CurPlayQTEIndex = 0;

	//CurClickEffectType = 1;
}

void UClickEffectPanel::OnClickEffectShow(const FPointerEvent& MouseEvent)
{
	if (!bShowClickEffect)
	{
		return;
	}
	if (GVarClickEffectNumConsoleVariable == 0)
	{
		SetVisibility(ESlateVisibility::Collapsed);
		return;
	}
	auto screenPos = UKismetInputLibrary::PointerEvent_GetScreenSpacePosition(MouseEvent);
	//PlayAnimationByPosition(screenPos);

	if (mClickEffectWidget)
	{
		mClickEffectWidget->ActivateEffect(screenPos);
	}
}

void UClickEffectPanel::PlayAnimationByPosition(FVector2D Position)
{
	SCOPED_NAMED_EVENT(UClickEffectPanel_PlayAnimationByPosition, FColor::Blue);
	if (CurClickEffectType == 1)
	{
		PlayNormalAnimationByPos(Position);
	}
	else if (CurClickEffectType == 2)
	{
		PlayQTEAnimationByPos(Position);
	}
}

void UClickEffectPanel::SetTotalClickEffectNum(int32 Num)
{
	//if (Num <= ClickEffects.Num())
	//{
	//	GVarClickEffectNumConsoleVariable = Num;	
	//}
	//else
	//{
	//	UE_LOG(LogTemp, Warning, TEXT("[UClickEffectPanel::SetTotalClickEffectNum] Invalid Click Effect Num."));
	//}
}

void UClickEffectPanel::SetClickEffectVisibility(bool bVisible)
{
	if (bVisible == bShowClickEffect)
	{
		return;
	}
	bShowClickEffect = bVisible;
}

void UClickEffectPanel::SetClickEffectNumByConsoleCommand(IConsoleVariable* Variable)
{
	//if (Variable->GetInt() != 0 && Variable->GetInt() <= ClickEffects.Num())
	//{
	//	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	//	SetTotalClickEffectNum(Variable->GetInt());
	//}
	//else if (Variable->GetInt() == 0)
	//{
	//	SetVisibility(ESlateVisibility::Collapsed);
	//}
}

void UClickEffectPanel::OnClickEffectNormalAnimationFinished()
{
	//if (auto ClickEffectWidget  = ClickEffects[CurPlayNormalIndex])
	//{
	//	ClickEffectWidget->SetVisibility(ESlateVisibility::Collapsed);
	//	ClickEffectWidget->ForceVolatile(false);	
	//}
	//else
	//{
	//	UE_LOG(LogTemp, Warning, TEXT("[UClickEffectPanel::OnClickEffectNormalAnimationFinished] Cannot find Widget, CurPlayNormalIndex:%d"), CurPlayNormalIndex);
	//}
}

void UClickEffectPanel::PlayNormalAnimationByPos(FVector2D& Pos)
{
	SCOPED_NAMED_EVENT(UClickEffectPanel_PlayNormalAnimationByPos, FColor::Red);


	//if (!GEngine || !GEngine->GameViewport)
	//{
	//	// GameViewport不存在的情况下，直接不播.
	//	return;
	//}

	//// 先判断下touch Pos是否在Game Viewport范围内，如果不在，无需播放点击特效
	//FVector2D ViewportSize;
	//GEngine->GameViewport->GetViewportSize(ViewportSize);
	//auto Scale = UWidgetLayoutLibrary::GetViewportScale(this);
	//auto MousePos = UWidgetLayoutLibrary::GetMousePositionOnViewport(this);
	//auto RealTouchPosWithScale = MousePos * Scale;
	//if (RealTouchPosWithScale.X >= 0 && RealTouchPosWithScale.X <= ViewportSize.X && RealTouchPosWithScale.Y >= 0 && RealTouchPosWithScale.Y <= ViewportSize.Y)
	//{
	//	auto TouchPos = USlateBlueprintLibrary::AbsoluteToLocal(GetCachedGeometry(), Pos);
	//	CurPlayNormalIndex = (CurPlayNormalIndex + 1) % GVarClickEffectNumConsoleVariable;

	//	if (auto ClickEffectWidget = ClickEffects[CurPlayNormalIndex])
	//	{
	//		if (auto ClickEffectSlot = Cast<UCanvasPanelSlot>(ClickEffectWidget->Slot))
	//		{
	//			ClickEffectSlot->SetPosition(TouchPos);
	//		}
	//		if (auto WidgetAnimation = ClickEffectWidget->GetWidgetAnimationByName(ClickEffectWidget, TEXT("Ani_Click")))
	//		{
	//			ClickEffectWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	//			ClickEffectWidget->ForceVolatile(true);
	//			FWidgetAnimationDynamicEvent OnFinished;
	//			OnFinished.BindUFunction(this, "OnClickEffectNormalAnimationFinished");
	//			FWidgetAnimationDynamicEvent OnInterrupted;
	//			ClickEffectWidget->PlayAnimationWithCallbacks(WidgetAnimation, 0, 1, EUMGSequencePlayMode::Forward,1.0, false, OnFinished, OnInterrupted);
	//		}	
	//	}
	//	else
	//	{
	//		UE_LOG(LogTemp, Warning, TEXT("[UClickEffectPanel::PlayNormalAnimationByPos] Cannot find Widget, CurPlayNormalIndex:%d"), CurPlayNormalIndex);
	//	}
	//}
}

void UClickEffectPanel::PlayQTEAnimationByPos(FVector2D Pos)
{
	CurPlayQTEIndex = (CurPlayQTEIndex + 1) % GVarClickEffectNumConsoleVariable;
	if (auto ClickEffectWidget = ClickEffectsQte[CurPlayQTEIndex])
	{
		auto TouchPos = USlateBlueprintLibrary::AbsoluteToLocal(GetCachedGeometry(), Pos);
		if (auto ClickEffectSlot = Cast<UCanvasPanelSlot>(ClickEffectWidget->Slot))
		{
			ClickEffectSlot->SetPosition(TouchPos);
		}
		if (auto WidgetAnimation = ClickEffectWidget->GetWidgetAnimationByName(ClickEffectWidget, TEXT("Ani_Click")))
		{
			ClickEffectWidget->PlayAnimation(WidgetAnimation, 0, 1, EUMGSequencePlayMode::Forward);	
		}	
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[UClickEffectPanel::PlayQTEAnimationByPos] Cannot find Widget, CurPlayQTEIndex:%d"), CurPlayQTEIndex);
	}
}

void UClickEffectPanel::SwitchClickEffectType(int32 Type)
{
	//CurClickEffectType = Type;
	//if (Type == 1)
	//{
	//	for (auto HideWidget: ClickEffectsQte)
	//	{
	//		HideWidget->SetVisibility(ESlateVisibility::Collapsed);
	//	}
	//	for (auto ShowWidget: ClickEffects)
	//	{
	//		ShowWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	//	}
	//}
	//else if (Type == 2)
	//{
	//	for (auto HideWidget: ClickEffects)
	//	{
	//		HideWidget->SetVisibility(ESlateVisibility::Collapsed);
	//	}
	//	for (auto ShowWidget: ClickEffectsQte)
	//	{
	//		ShowWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	//	}
	//}
}

void UClickEffectPanel::DeInit()
{
	return;
}