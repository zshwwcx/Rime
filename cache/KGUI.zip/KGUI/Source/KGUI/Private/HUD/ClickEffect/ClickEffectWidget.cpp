#include "HUD/ClickEffect/ClickEffectWidget.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Math/UnrealMathUtility.h"

//////////////////////////////////////////////////////////////////////////
// SClickEffectWidget 实现
//////////////////////////////////////////////////////////////////////////

SClickEffectWidget::SClickEffectWidget()
	: MaxPoolSize(3)
	, EffectSizeValue(FVector2D(107, 107))
	, LatestEffectID(-1)
{
}

SClickEffectWidget::~SClickEffectWidget()
{
	EffectPool.Empty();
}

void SClickEffectWidget::Construct(const FArguments& InArgs)
{
	MaxPoolSize = FMath::Max(1, InArgs._MaxEffects);
	EffectSizeValue = InArgs._EffectSize;
	DynamicMaterials.AddZeroed(InArgs._DynamicMaterials.Num());
	for (size_t i = 0; i < InArgs._DynamicMaterials.Num(); i++)
	{
		DynamicMaterials[i] = InArgs._DynamicMaterials[i];
	}

	// 初始化对象池
	InitializeObjectPool();

	// 设置初始尺寸
	this->ChildSlot
		[
			SNullWidget::NullWidget
		];
}

int32 SClickEffectWidget::ActivateEffect(const FVector2D& Position, FName InParamName, float InParamValue, float InLifeTime)
{
	LatestEffectID += 1;
	if (LatestEffectID == 2147483646)
	{
		LatestEffectID = 0;
	}
	int idx = LatestEffectID % MaxPoolSize;
	FClickEffect& Effect = EffectPool[idx];

	Effect.Activate(LatestEffectID, Position, EffectSizeValue, InParamName, InParamValue, InLifeTime);

	UpdateTickState();

	// 请求重绘
	Invalidate(EInvalidateWidgetReason::Paint);

	return LatestEffectID;
}

void SClickEffectWidget::DeactivateAllEffects()
{
	// 停用所有效果
	for (auto& Effect : EffectPool)
	{
		if (Effect.bActive)
		{
			Effect.Deactivate();
		}
	}

	UpdateTickState();

	// 请求重绘
	Invalidate(EInvalidateWidgetReason::Paint);
}

int32 SClickEffectWidget::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry,
	const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements,
	int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	// 调用父类绘制
	//LayerId = SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);

	// 绘制所有激活的效果
	for (const FClickEffect& Effect : EffectPool)
	{
		if (!Effect.bActive) continue;

		// 使位置成为效果中心
		FVector2D DrawPosition = Effect.Position - (Effect.Size * 0.5f);

		// 创建效果几何体
		FGeometry EffectGeometry = AllottedGeometry.MakeChild(
			Effect.Size,
			FSlateLayoutTransform(DrawPosition)
		);

		// 检查是否在裁剪矩形内
		FSlateRect EffectRect = EffectGeometry.GetLayoutBoundingRect();
		if (!FSlateRect::DoRectanglesIntersect(EffectRect, MyCullingRect))
		{
			continue;
		}

		// 绘制效果
		FSlateDrawElement::MakeBox(
			OutDrawElements,
			LayerId,
			EffectGeometry.ToPaintGeometry(),
			&Effect.Brush,
			ESlateDrawEffect::None,
			InWidgetStyle.GetColorAndOpacityTint()
		);
	}

	return LayerId;
}

FVector2D SClickEffectWidget::ComputeDesiredSize(float LayoutScaleMultiplier) const
{
	return FVector2D(100.0f, 100.0f);
}

void SClickEffectWidget::InitializeObjectPool()
{
	EffectPool.Reserve(MaxPoolSize);
	for (size_t i = 0; i < MaxPoolSize; i++)
	{
		int idx = EffectPool.AddZeroed();
		EffectPool[idx].bActive = false;
		if (DynamicMaterials.IsValidIndex(i))
		{
			EffectPool[idx].DynamicMaterial = DynamicMaterials[i];
			EffectPool[idx].Brush = CreateEffectBrush(DynamicMaterials[i].Get(), EffectSizeValue);
		}
	}
}

void SClickEffectWidget::UpdateLifeTime(float delta)
{
	bool bChanged = false;
	for (size_t i = 0; i < EffectPool.Num(); i++)
	{
		FClickEffect& Effect = EffectPool[i];
		if (Effect.bActive)
		{
			Effect.LifeTime -= delta;
			if(Effect.LifeTime <= 0)
			{
				Effect.bActive = false;
				bChanged = true;
			}
		}
	}
	
	if (bChanged)
	{
		UpdateTickState();
	}
}

void SClickEffectWidget::UpdateTickState()
{
	for (size_t i = 0; i < EffectPool.Num(); i++)
	{
		FClickEffect& Effect = EffectPool[i];
		if (Effect.bActive)
		{
			this->SetCanTick(true);
			this->SetVisibility(EVisibility::HitTestInvisible);
			return;
		}
	}

	this->SetCanTick(false);
	this->SetVisibility(EVisibility::Collapsed);
}

void SClickEffectWidget::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SCompoundWidget::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);

	UpdateLifeTime(InDeltaTime);
}

FSlateBrush SClickEffectWidget::CreateEffectBrush(UMaterialInstanceDynamic* DynamicMaterial, const FVector2D& Size) const
{
	FSlateBrush Brush;

	if (DynamicMaterial)
	{
		Brush.SetResourceObject(DynamicMaterial);
		Brush.ImageSize = Size;
		Brush.DrawAs = ESlateBrushDrawType::Image;
		Brush.TintColor = FLinearColor::White;
	}

	return Brush;
}

//////////////////////////////////////////////////////////////////////////
// UClickEffectWidget 实现
//////////////////////////////////////////////////////////////////////////

UClickEffectWidget::UClickEffectWidget()
{
}

TSharedRef<SWidget> UClickEffectWidget::RebuildWidget()
{
	if (DynamicMaterials.Num() == 0)
	{
		if (BaseMaterial == nullptr)
		{
			UE_LOG(LogTemp, Warning, TEXT("UClickEffectWidget - BaseMaterial is null"));
		}
		else
		{
			DynamicMaterials.AddZeroed(MaxEffects);

			for (size_t i = 0; i < MaxEffects; i++)
			{
				DynamicMaterials[i] = UMaterialInstanceDynamic::Create(BaseMaterial, this);
			}
		}
	}

	ClickEffectSlateWidget = SNew(SClickEffectWidget)
		.MaxEffects(MaxEffects)
		.EffectSize(EffectSize)
		.DynamicMaterials(DynamicMaterials);

	return ClickEffectSlateWidget.ToSharedRef();
}

void UClickEffectWidget::SynchronizeProperties()
{
	Super::SynchronizeProperties();
}

void UClickEffectWidget::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	ClickEffectSlateWidget.Reset();
	DynamicMaterials.Empty();
}

int32 UClickEffectWidget::ActivateEffect(const FVector2D& ScreenPosition)
{
	if (!IsSlateWidgetValid() || !BaseMaterial)
	{
		return -1;
	}

	// 将屏幕坐标转换为本地坐标
	FVector2D LocalPosition = ConvertScreenToLocal(ScreenPosition);

	float t = FApp::GetCurrentTime() - GStartTime;
	// t = 0 - ((int)t % Period);
	t = 0.f - FMath::Fmod(t, FMath::Max(Period, KINDA_SMALL_NUMBER));
	
	// 激活效果
	return ClickEffectSlateWidget->ActivateEffect(LocalPosition, MaterialParameterNameToSet, t, LifeTime);
}

void UClickEffectWidget::DeactivateAllEffects()
{
	if (IsSlateWidgetValid())
	{
		ClickEffectSlateWidget->DeactivateAllEffects();
	}
}

FVector2D UClickEffectWidget::ConvertScreenToLocal(const FVector2D& ScreenPosition) const
{
	// 获取控件几何信息
	FGeometry WidgetGeometry = GetCachedGeometry();

	// 转换为本地坐标
	FVector2D LocalPosition = WidgetGeometry.AbsoluteToLocal(ScreenPosition);

	return LocalPosition;
}

bool UClickEffectWidget::IsSlateWidgetValid() const
{
	return ClickEffectSlateWidget.IsValid();
}