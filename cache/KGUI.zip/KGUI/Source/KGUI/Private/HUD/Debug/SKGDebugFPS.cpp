#include "HUD/Debug/SKGDebugFPS.h"

#include "Components/HorizontalBox.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBorder.h"
#if PLATFORM_WINDOWS
#include "DLSSLibrary.h"
#include "StreamlineLibraryDLSSG.h"
#endif

SKGDebugFPS::SKGDebugFPS()
{
}

SKGDebugFPS::~SKGDebugFPS()
{
}

void SKGDebugFPS::Construct(const FArguments& InArgs)
{
	SetVisibility(EVisibility::HitTestInvisible);

	ChildSlot
	[
		SNew(SBox)
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Bottom) 
		[
			SAssignNew(FPSTextBlock, STextBlock)
			.MinDesiredWidth(150.0f)
			.Margin(FMargin(10, 0, 10, 0))
			.Text(FText::FromString(TEXT("FPS: ") + FString::FromInt(CurrentFPS)))
			.Font(FCoreStyle::GetDefaultFontStyle("Bold", 20))
			.ColorAndOpacity(FLinearColor(1.0f, 1.0f, 1.0f, 0.7f))
			.Justification(ETextJustify::Left)
			.SimpleTextMode(true)
		]
	];

	SetCanTick(false);
}

void SKGDebugFPS::UpdateFPS(float InFPS)
{
	const int32 FPS = FMath::RoundToInt(InFPS);
	if (CurrentFPS != FPS)
	{
		CurrentFPS = FPS;
		if (FPSTextBlock.IsValid())
		{
			FPSTextBlock->SetText(FText::FromString(TEXT("FPS: ") + FString::FromInt(CurrentFPS)));
		}
	}
}

void SKGDebugFPS::OnTick(float DeltaTime)
{
#if PLATFORM_WINDOWS
	if (UDLSSLibrary::IsDLSSEnabled() && UStreamlineLibraryDLSSG::GetDLSSGMode() != EStreamlineDLSSGMode::Off)
	{
		float FrameRateInHertz = 0.0f;
		int32 FramesPresented = 0;
		UStreamlineLibraryDLSSG::GetDLSSGFrameTiming(FrameRateInHertz, FramesPresented);
		UpdateFPS(FrameRateInHertz);
		return;
	}
#endif
	if (!FMath::IsNearlyZero(DeltaTime))
	{
		UpdateFPS(1 / DeltaTime);
		return;
	}
}
