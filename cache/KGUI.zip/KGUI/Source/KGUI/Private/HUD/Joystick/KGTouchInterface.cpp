// Fill out your copyright notice in the Description page of Project Settings.


#include "HUD/Joystick/KGTouchInterface.h"
#include "HUD/Joystick/SKGVirtualJoystick.h"
#include "Slate/DeferredCleanupSlateBrush.h"

KGUI_API void UKGTouchInterface::Activate(TSharedPtr<SVirtualJoystick> VirtualJoystick)
{
	if (!VirtualJoystick.IsValid())
	{
		return;
	}

	UTouchInterface::Activate(VirtualJoystick);

	TSharedPtr<SKGVirtualJoystick> KGVirtualJoystick = StaticCastSharedPtr<SKGVirtualJoystick>(VirtualJoystick);
	if (KGVirtualJoystick.IsValid() && VirtualJoystick->GetType().ToString().Equals(TEXT("SKGVirtualJoystick")))
	{
		
		auto& LeftJoystickInfo = KGVirtualJoystick->GetLeftJoystick();

		TSharedRef<FDeferredCleanupSlateBrush> Brush = FDeferredCleanupSlateBrush::CreateBrush(LeftJoystick.BrushDirectionBgBig);
		LeftJoystickInfo.ImageDirBgBig = StaticCastSharedRef<ISlateBrushSource>(Brush);
		
		Brush = FDeferredCleanupSlateBrush::CreateBrush(LeftJoystick.BrushDirectionBig);
		LeftJoystickInfo.ImageDirBig = StaticCastSharedRef<ISlateBrushSource>(Brush);
		
		Brush = FDeferredCleanupSlateBrush::CreateBrush(LeftJoystick.BrushDirectionSmall);
		LeftJoystickInfo.ImageDirSmall = StaticCastSharedRef<ISlateBrushSource>(Brush);
		
		Brush = FDeferredCleanupSlateBrush::CreateBrush(LeftJoystick.BrushDirectionBgSmall);
		LeftJoystickInfo.ImageDirBgSmall = StaticCastSharedRef<ISlateBrushSource>(Brush);
		
		Brush = FDeferredCleanupSlateBrush::CreateBrush(LeftJoystick.BrushThumb);
		LeftJoystickInfo.ImageThumb = StaticCastSharedRef<ISlateBrushSource>(Brush);
		
		Brush = FDeferredCleanupSlateBrush::CreateBrush(LeftJoystick.BrushClosed);
		LeftJoystickInfo.ImageClosed = StaticCastSharedRef<ISlateBrushSource>(Brush);
		
		LeftJoystickInfo.VisualSize = LeftJoystick.VisualSize;
		LeftJoystickInfo.ThumbSize = LeftJoystick.ThumbSize;
		if (LeftJoystickInfo.InputScale.SizeSquared() > FMath::Square(UE_DELTA))
		{
			LeftJoystickInfo.InputScale = LeftJoystick.InputScale;
		}
		LeftJoystickInfo.InteractionZone = LeftJoystick.InteractionZone;
		LeftJoystickInfo.MainInputKey = LeftJoystick.MainInputKey;
		LeftJoystickInfo.AltInputKey = LeftJoystick.AltInputKey;
	}
}
