// FKGGestureRecognizer.cpp
#include "HUD/Joystick/KGGestureRecognizer.h"
#include "Math/UnrealMathUtility.h"

FKGGestureRecognizer::FKGGestureRecognizer()
    : GestureType(EKGGestureType::NONE)
    , GestureMask(0)
    , IsGestureActive(false)
    , MinPinchDistance(50.0f)
    , MinRotateAngle(10.0f)
    , MinPanDistance(30.0f)
    , MinSwipeDistance(100.0f)
    , MaxSwipeTime(500.0f)
    , InitialDistance(0.0f)
    , CurrentDistance(0.0f)
    , InitialAngle(0.0f)
    , CurrentAngle(0.0f)
    , InitialCenter(ForceInit)
    , CurrentCenter(ForceInit)
    , GestureStartTime(0.0)
    , MaxHistorySize(3)
{
}

FKGGestureRecognizer::~FKGGestureRecognizer()
{
}

bool FKGGestureRecognizer::ContainFinger(int32 FingerIdx) const
{
    for (const auto& Finger : GestureGroupFingers)
    {
        if (Finger.PointerIndex == FingerIdx)
        {
            return true;
        }
    }
    return false;
}

void FKGGestureRecognizer::StartGesture(const TArray<FTouchFingerInfo>& Fingers, double CurrentTime, int32 InGestureMask)
{
    IsGestureActive = true;
    GestureStartTime = CurrentTime;
    GestureGroupFingers = Fingers;
    GestureMask = InGestureMask;

    const FVector2D& Pos1 = Fingers[0].ScreenPos;
    const FVector2D& Pos2 = Fingers[1].ScreenPos;
    
    // 计算初始数据
    InitialDistance = CalculateDistance(Pos1, Pos2);
    CurrentDistance = InitialDistance;
    InitialAngle = CalculateAngle(Pos1, Pos2);
    CurrentAngle = InitialAngle;
    InitialCenter = CalculateCenter(Pos1, Pos2);
    CurrentCenter = InitialCenter;
    
    // 清空历史数据
    PositionHistory.Empty();
    AddToHistory(Pos1, Pos2, GestureStartTime);
    
    GestureType = EKGGestureType::NONE;
}

void FKGGestureRecognizer::UpdateGesture(double CurrentTime)
{
    if (!IsGestureActive || GestureGroupFingers.Num() < 2)
        return;
        
    const FVector2D& Pos1 = GestureGroupFingers[0].ScreenPos;
    const FVector2D& Pos2 = GestureGroupFingers[1].ScreenPos;
    
    // 更新当前数据
    CurrentDistance = CalculateDistance(Pos1, Pos2);
    CurrentAngle = CalculateAngle(Pos1, Pos2);
    CurrentCenter = CalculateCenter(Pos1, Pos2);
    
    // 添加到历史记录
    AddToHistory(Pos1, Pos2, CurrentTime);
    
    // 识别手势类型
    EKGGestureType DetectedGesture = DetectGesture();
    
    if (DetectedGesture != EKGGestureType::NONE)
    {
        GestureType = DetectedGesture;
    }
}

void FKGGestureRecognizer::EndGesture()
{
    GestureGroupFingers.Empty();
    IsGestureActive = false;
    GestureType = EKGGestureType::NONE;
    GestureMask = 0;
    PositionHistory.Empty();
}

EKGGestureType FKGGestureRecognizer::DetectGesture() const
{
    if (!IsGestureActive)
        return EKGGestureType::NONE;
    
    float DistanceChange = FMath::Abs(CurrentDistance - InitialDistance);
    float AngleChange = FMath::Abs(CurrentAngle - InitialAngle);
    float CenterMovement = CalculateDistance(InitialCenter, CurrentCenter);
    
    // 优先级：缩放 > 旋转 > 平移 > 滑动
    
    // 检测缩放手势
    if ((GestureMask & static_cast<int32>(EKGGestureType::PINCH)) != 0 && DistanceChange > MinPinchDistance)
    {
        return EKGGestureType::PINCH;
    }
    
    // 检测旋转手势
    if ((GestureMask & static_cast<int32>(EKGGestureType::ROTATE)) != 0 && 
        AngleChange > MinRotateAngle && DistanceChange < MinPinchDistance)
    {
        return EKGGestureType::ROTATE;
    }
    
    // 检测平移手势
    if ((GestureMask & static_cast<int32>(EKGGestureType::PAN)) != 0 && 
        CenterMovement > MinPanDistance && 
        DistanceChange < MinPinchDistance && 
        AngleChange < MinRotateAngle)
    {
        return EKGGestureType::PAN;
    }
    
    // 检测滑动手势
    if ((GestureMask & static_cast<int32>(EKGGestureType::SWIPE)) != 0)
    {
        double GestureTime = FPlatformTime::Seconds() * 1000 - GestureStartTime;
        if (GestureTime < MaxSwipeTime && CenterMovement > MinSwipeDistance)
        {
            float Velocity = CalculateVelocity();
            if (Velocity > 500.0f) // 像素/秒
            {
                return EKGGestureType::SWIPE;
            }
        }
    }
    
    return EKGGestureType::NONE;
}

FKGGestureData FKGGestureRecognizer::GetGestureData() const
{
    FKGGestureData Data;
    Data.Type = GestureType;
    Data.IsActive = IsGestureActive;
    
    switch (GestureType)
    {
    case EKGGestureType::PINCH:
        Data.Scale = CurrentDistance / InitialDistance;
        Data.Distance = CurrentDistance - InitialDistance;
        break;
        
    case EKGGestureType::ROTATE:
        Data.Rotation = CurrentAngle - InitialAngle;
        Data.RotationDelta = NormalizeAngle(CurrentAngle - InitialAngle);
        break;
        
    case EKGGestureType::PAN:
        Data.Translation = CurrentCenter - InitialCenter;
        Data.Center = CurrentCenter;
        break;
        
    case EKGGestureType::SWIPE:
        Data.Velocity = CalculateVelocity();
        Data.Direction = CalculateSwipeDirection();
        Data.Translation = CurrentCenter - InitialCenter;
        break;
        
    default:
        break;
    }
    
    return Data;
}

void FKGGestureRecognizer::AddToHistory(const FVector2D& Pos1, const FVector2D& Pos2, double Time)
{
    FPositionHistoryEntry Entry;
    Entry.Pos1 = Pos1;
    Entry.Pos2 = Pos2;
    Entry.Center = CalculateCenter(Pos1, Pos2);
    Entry.Time = Time;
    
    if (PositionHistory.Num() >= MaxHistorySize)
    {
        PositionHistory.RemoveAt(0);
    }
    
    PositionHistory.Add(Entry);
}

float FKGGestureRecognizer::CalculateVelocity() const
{
    if (PositionHistory.Num() < 2)
        return 0.0f;
    
    const FPositionHistoryEntry& Latest = PositionHistory.Last();
    const FPositionHistoryEntry& Previous = PositionHistory[PositionHistory.Num() - 2];
    
    float Distance = CalculateDistance(Latest.Center, Previous.Center);
    double TimeSpan = Latest.Time - Previous.Time;
    
    if (TimeSpan > 0)
    {
        return Distance / TimeSpan * 1000.0f; // 转换为像素/秒
    }
    
    return 0.0f;
}

FString FKGGestureRecognizer::CalculateSwipeDirection() const
{
    if (PositionHistory.Num() < 2)
        return TEXT("unknown");
    
    const FPositionHistoryEntry& Latest = PositionHistory.Last();
    const FPositionHistoryEntry& Initial = PositionHistory[0];
    
    float DX = Latest.Center.X - Initial.Center.X;
    float DY = Latest.Center.Y - Initial.Center.Y;
    
    float Angle = FMath::Atan2(DY, DX) * 180.0f / PI;
    
    // 将角度转换为方向
    if (Angle >= -45.0f && Angle < 45.0f)
        return TEXT("right");
    else if (Angle >= 45.0f && Angle < 135.0f)
        return TEXT("down");
    else if (Angle >= 135.0f || Angle < -135.0f)
        return TEXT("left");
    else
        return TEXT("up");
}

// 工具函数
float FKGGestureRecognizer::CalculateDistance(const FVector2D& Pos1, const FVector2D& Pos2)
{
    return FVector2D::Distance(Pos1, Pos2);
}

float FKGGestureRecognizer::CalculateAngle(const FVector2D& Pos1, const FVector2D& Pos2)
{
    FVector2D Direction = Pos2 - Pos1;
    return FMath::Atan2(Direction.Y, Direction.X) * 180.0f / PI;
}

FVector2D FKGGestureRecognizer::CalculateCenter(const FVector2D& Pos1, const FVector2D& Pos2)
{
    return (Pos1 + Pos2) * 0.5f;
}

float FKGGestureRecognizer::NormalizeAngle(float Angle)
{
    while (Angle > 180.0f)
        Angle -= 360.0f;
    while (Angle < -180.0f)
        Angle += 360.0f;
    return Angle;
}



