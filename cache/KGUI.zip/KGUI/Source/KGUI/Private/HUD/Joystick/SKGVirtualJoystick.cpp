// Fill out your copyright notice in the Description page of Project Settings.


#include "HUD/Joystick/SKGVirtualJoystick.h"
#include "GameFramework/PlayerController.h"
#include "AkAcousticTextureSetComponent.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "UMG/Blueprint/UIFunctionLibrary.h"
#include "Rendering/DrawElements.h"
#include "Framework/Application/SlateApplication.h"
#include "GenericPlatform/GenericPlatformInputDeviceMapper.h"
#include "InputCoreTypes.h"
#include "Misc/KGGameInstanceBase.h"
#include "UI/KGUIPlatformCustomSetting.h"
#include "Engine/GameViewportClient.h"
#include "Framework/Application/SlateUser.h"
#include "Slate/SceneViewport.h"
#include "Widgets/SViewport.h"

#pragma optimize("", off)

bool GKGEnableVirtualJoystick = false;
static FAutoConsoleVariableRef CVarKGEnableVirtualJoystick(
    TEXT("KG.EnableVirtualJoystick"),
    GKGEnableVirtualJoystick,
    TEXT("Enable KG virtual joystick.")
);

float GKGVirtualJoystickOpacityLerpRate = 3.f;
static FAutoConsoleVariableRef CVarKGVirtualJoystickOpacityLerpRate(
	TEXT("KG.VirtualJoystickOpacityLerpRate"),
	GKGVirtualJoystickOpacityLerpRate,
	TEXT("Virtual joystick opacity lerp rate.")
);

float GKGVirtualJoystickDebugging = false;
static FAutoConsoleVariableRef CVarKGVirtualJoystickDebug(
	TEXT("KG.VirtualJoystickDebugging"),
	GKGVirtualJoystickDebugging,
	TEXT("Virtual joystick debugging.")
	);

FKGCameraInputController::FKGCameraInputController(float InScaleRate, float InScaleX, float InScaleY, float InSlideRate, float InCameraMoveSizeX, float InCameraMoveSizeY, float InCameraDeadZoneOffset)
{
	CtrlParams.ScaleRate = InScaleRate;
	CtrlParams.ScaleX = InScaleX;
	CtrlParams.ScaleY = InScaleY;
	CtrlParams.SlideRate = InSlideRate;
	CtrlParams.CameraDeadZoneOffset = InCameraDeadZoneOffset;
	CtrlParams.CameraMoveSize.X = FMath::Max(InCameraMoveSizeX, KINDA_SMALL_NUMBER);
	CtrlParams.CameraMoveSize.Y = FMath::Max(InCameraMoveSizeY, KINDA_SMALL_NUMBER);
}

void FKGCameraInputController::OnGesturePinch(const FKGGestureData& GestureData) const
{
    if (GestureData.Type == EKGGestureType::PINCH)
    {
        float Scale = GestureData.Distance / CtrlParams.ScaleRate;
        ZoomCamera(Scale);
    }
}

void FKGCameraInputController::OnTouchStarted(const FVector2D& InScreenPos, const FGeometry& MyGeometry, const FPointerEvent& Event)
{
	TouchBeginPos = Event.GetScreenSpacePosition();
	CameraLastPos = TouchBeginPos;
	DeadZoneOffset = FVector2D::ZeroVector;
	DeadZoneLastPos = TouchBeginPos;
	bInDeadZone = true;
	// UE_LOG(LogInit, Log, TEXT("[FKGCameraInputController]%s"), ANSI_TO_TCHAR(__FUNCTION__));
}

void FKGCameraInputController::OnTouchMoved(const FVector2D& InScreenPos, const FVector2D& InDeltaPos, const FGeometry& MyGeometry, const FPointerEvent& Event)
{
    if (bInDeadZone)
	{
		DeadZoneOffset = DeadZoneOffset + InScreenPos - DeadZoneLastPos;
		DeadZoneLastPos = InScreenPos;
		
		if (DeadZoneOffset.Length() > CtrlParams.CameraDeadZoneOffset)
		{
			bInDeadZone = false;
			CameraLastPos = InScreenPos;
			RawValueAccumulator = FVector2D::ZeroVector;
		}
		return;
	}

	RawValueAccumulator += InDeltaPos;
	CameraLastPos = InScreenPos;
	// UE_LOG(LogInit, Log, TEXT("[FKGCameraInputController]%s deltaPos:%s RawValAccumulator:%s"), ANSI_TO_TCHAR(__FUNCTION__), *InDeltaPos.ToString(), *RawValueAccumulator.ToString());
}

void FKGCameraInputController::OnTouchEnded(const FVector2D& InScreenPos, const FGeometry& MyGeometry, const FPointerEvent& Event)
{
	bSendOneMoreEvent = true;
	RawValueAccumulator = FVector2D::ZeroVector;
	// UE_LOG(LogInit, Log, TEXT("[FKGCameraInputController]%s RawValueAccumulator:%s"), ANSI_TO_TCHAR(__FUNCTION__), *RawValueAccumulator.ToString());
}

void FKGCameraInputController::RotateCamera(const FVector2D& Input) const
{
	float XValue = Input.X; //* CtrlParams.ScaleX * CtrlParams.SlideRate;
	float YValue = Input.Y;// * CtrlParams.ScaleY * CtrlParams.SlideRate;

	// UE_LOG(LogInit, Log, TEXT("[FKGCameraInputController]%s x:%.4f y:%.4f"), ANSI_TO_TCHAR(__FUNCTION__), XValue, YValue);
	FSlateApplication::Get().SetAllUserFocus(GameViewportWidgetPath, EFocusCause::SetDirectly);
    //FSlateApplication::Get().SetAllUserFocusToGameViewport();

    {
        FInputDeviceId PrimaryInputDevice = IPlatformInputDeviceMapper::Get().GetPrimaryInputDeviceForUser(FSlateApplicationBase::SlateAppPrimaryPlatformUser);
        SCOPED_NAMED_EVENT(KGCameraInputController_RotateCamera_Analog, FColor::Green);
		FSlateApplication::Get().OnControllerAnalog(FGamepadKeyNames::RightAnalogY, FSlateApplicationBase::SlateAppPrimaryPlatformUser, PrimaryInputDevice, YValue);
		FSlateApplication::Get().OnControllerAnalog(FGamepadKeyNames::RightAnalogX, FSlateApplicationBase::SlateAppPrimaryPlatformUser, PrimaryInputDevice, XValue);
	}
}

void FKGCameraInputController::ZoomCamera(float InValue) const
{
	if (InValue == 0.f)
	{
		return;
	}

	FSlateApplication::Get().SetAllUserFocus(GameViewportWidgetPath, EFocusCause::SetDirectly);
	
	float Value = FMath::Clamp(InValue, -1.f, 1.f); 	
	FSlateApplication::Get().OnMouseWheel(Value);
}

void FKGCameraInputController::Tick(float InDeltaTime)
{
	SCOPED_NAMED_EVENT(KGCameraInputController_Tick, FColor::Cyan);
	if (RawValueAccumulator != LastRawValue || bSendOneMoreEvent)
	{
		LastRawValue = RawValueAccumulator;
		// RawValueAccumulator.X /= CtrlParams.CameraMoveSize.X;
		RawValueAccumulator.Y *= -1.f; //将Y轴反向 
		// RawValueAccumulator.Y /= -CtrlParams.CameraMoveSize.Y;
		// UE_LOG(LogInit, Log, TEXT("[FKGCameraInputController]%s RawValueAccumulator:%s"), ANSI_TO_TCHAR(__FUNCTION__), *RawValueAccumulator.ToString());
		RotateCamera(RawValueAccumulator);

		bSendOneMoreEvent = false;
	}

	RawValueAccumulator.X = 0.f;
	RawValueAccumulator.Y = 0.f;
}

void SKGVirtualJoystick::FJoystickData::Reset()
{
	VisualCenter = CorrectedCenter;
}


FVector2D SKGVirtualJoystick::FJoystickData::ComputeJoystickThumbPosition(const FVector2D& LocalCoord, float* OutDistanceToTouchSqr, float* OutDistanceToEdgeSqr) const
{
	float DistanceToTouchSqr = 0.0f;
	float DistanceToEdgeSqr = 0.0f;
	FVector2D Position;

	// figure out position around center
	FVector2D Offset = LocalCoord - VisualCenter;
	// only do work if we aren't at the center
	if (Offset == FVector2D(0, 0))
	{
		Position = Offset;
	}
	else
	{
		// clamp to the ellipse of the stick (snaps to the visual size, so, the art should go all the way to the edge of the texture)
		DistanceToTouchSqr = Offset.SizeSquared();
		float Angle = FMath::Atan2(Offset.Y, Offset.X);

		// length along line to ellipse: L = 1.0 / sqrt(((sin(T)/Rx)^2 + (cos(T)/Ry)^2))
		float CosAngle = FMath::Cos(Angle);
		float SinAngle = FMath::Sin(Angle);
		float XTerm = CosAngle / (CorrectedVisualSize.X * 0.5f);
		float YTerm = SinAngle / (CorrectedVisualSize.Y * 0.5f);
		float XYTermSqr = XTerm * XTerm + YTerm * YTerm;
		DistanceToEdgeSqr = 1.0f / XYTermSqr;

		// only clamp 
		if (DistanceToTouchSqr > DistanceToEdgeSqr)
		{
			float DistanceToEdge = FMath::InvSqrt(XYTermSqr);
			Position = FVector2D(DistanceToEdge * CosAngle, DistanceToEdge * SinAngle);
		}
		else
		{
			Position = Offset;
		}
	}

	if (OutDistanceToTouchSqr != nullptr)
	{
		*OutDistanceToTouchSqr = DistanceToTouchSqr;
	}

	if (OutDistanceToEdgeSqr != nullptr)
	{
		*OutDistanceToEdgeSqr = DistanceToEdgeSqr;
	}

	return Position;
}

SKGVirtualJoystick::SKGVirtualJoystick()
{
}

SKGVirtualJoystick::~SKGVirtualJoystick()
{
}

bool SKGVirtualJoystick::ShouldDisplayTouchInterface(APlayerController* PlayerController)
{
    if (PlayerController)
    {
        UGameInstance* GI = PlayerController->GetGameInstance();
        if (GI && GI->IsA<UKGGameInstanceBase>())
        {
            return true;
        }
    }
    
    return false;
}

void SKGVirtualJoystick::CacheGameViewportWidgetPath()
{
    GameViewportWidgetPath.Widgets.Empty();
    GameViewportWidgetPath.TopLevelWindow.Reset();

	TSharedPtr< SViewport > CurrentGameViewportWidget = FSlateApplication::Get().GetGameViewport();
	if (CurrentGameViewportWidget.IsValid())
	{
		FSlateWindowHelper::FindPathToWidget(FSlateApplication::Get().GetTopLevelWindows(), CurrentGameViewportWidget.ToSharedRef(), GameViewportWidgetPath);
	}

	if (CameraCtrl.IsValid())
	{
		CameraCtrl->SetGameViewportWidgetPath(GameViewportWidgetPath);
	}
}

void SKGVirtualJoystick::SetSafeZoneOffset(float LeftOffset, float TopOffset, float RightOffset, float BottomOffset)
{
	SafeZoneOffset.Left = LeftOffset;
	SafeZoneOffset.Top = TopOffset;
	SafeZoneOffset.Right = RightOffset;
	SafeZoneOffset.Bottom = BottomOffset;
	LeftJoystick.bHasBeenPositioned = false;
}

void SKGVirtualJoystick::SetFixedCenter(bool bFixed)
{
	bPreventReCenter = bFixed;
}

void SKGVirtualJoystick::SetThresholdForWalking(float InWalkValue)
{
	ThresholdForWalking = InWalkValue;
}

void SKGVirtualJoystick::SetDelayTimeForCancelRunning(float InDelayTime)
{
	DelayTimeForCancelRunning = InDelayTime;
}

void SKGVirtualJoystick::SetGesture(uint32 InGestureMask, float InPinchCheckInterval, int32 InMaxTouchFingerCount)
{
	GestureMask = InGestureMask;
	PinchCheckDuration = InPinchCheckInterval;
	MaxTouchFingersCount = InMaxTouchFingerCount;
}

void SKGVirtualJoystick::SetCameraControlParams(float InScaleRate, float InScaleX, float InScaleY, float InSlideRate, float InCameraMoveSizeX, float InCameraMoveSizeY, float InCameraDeadZoneOffset) const
{
	if (CameraCtrl.IsValid())
	{
		CameraCtrl->SetScaleRate(InScaleRate);
		CameraCtrl->SetScaleX(InScaleX);
		CameraCtrl->SetScaleY(InScaleY);
		CameraCtrl->SetSlideRate( InSlideRate);
		CameraCtrl->SetCameraMoveSize(InCameraMoveSizeX, InCameraMoveSizeY);
		CameraCtrl->SetCameraDeadZoneOffset(InCameraDeadZoneOffset);
	}
}

void SKGVirtualJoystick::SetCameraScaleRate(float InScaleRate) const
{
	if (CameraCtrl.IsValid())
	{
		CameraCtrl->SetScaleRate(InScaleRate);
	}
}

void SKGVirtualJoystick::SetScaleX(float InScaleX) const
{
	if (CameraCtrl.IsValid())
	{
		CameraCtrl->SetScaleX(InScaleX);
	}
}

void SKGVirtualJoystick::SetScaleY(float InScaleY) const
{
	if (CameraCtrl.IsValid())
	{
		CameraCtrl->SetScaleY(InScaleY);
	}
}

void SKGVirtualJoystick::SetSlideRate(float InSlideRate) const
{
	if (CameraCtrl.IsValid())
	{
		CameraCtrl->SetSlideRate(InSlideRate);
	}
}

void SKGVirtualJoystick::SetCameraDeadZoneOffset(float InCameraDeadZoneOffset) const
{
	if (CameraCtrl.IsValid())
	{
		CameraCtrl->SetCameraDeadZoneOffset(InCameraDeadZoneOffset);
	}
}

void SKGVirtualJoystick::SetCameraMoveSize(float InCameraMoveSizeX, float InCameraMoveSizeY) const
{
	if (CameraCtrl.IsValid())
	{
		CameraCtrl->SetCameraMoveSize(InCameraMoveSizeX, InCameraMoveSizeY);
	}
}

void SKGVirtualJoystick::ClearAllTouchData()
{
	if (LeftJoystick.CapturedPointerIndex != INDEX_NONE)
	{
		LeftJoystick.ThumbPosition = FVector2D(0, 0);
		LeftJoystick.CapturedPointerIndex = -1;

		// send one more joystick update for the centering
		LeftJoystick.bSendOneMoreEvent = true;

		// Pass event as unhandled if time is too short
		if (LeftJoystick.bNeedUpdatedCenter)
		{
			LeftJoystick.bNeedUpdatedCenter = false;
		}
		FSlateApplication::Get().GetUser(0)->ReleaseCapture(LeftJoystick.CapturedPointerIndex);
	}

	for (auto& Control : Controls)
	{
		if (Control.CapturedPointerIndex != -1)
		{
			// release and center the joystick
			Control.ThumbPosition = FVector2D(0, 0);
			Control.CapturedPointerIndex = -1;

			// send one more joystick update for the centering
			Control.bSendOneMoreEvent = true;

			// Pass event as unhandled if time is too short
			if (Control.bNeedUpdatedCenter)
			{
				Control.bNeedUpdatedCenter = false;
				
			}

			FSlateApplication::Get().GetUser(0)->ReleaseCapture(LeftJoystick.CapturedPointerIndex);
		}
	}

	for (auto Pair : TouchFingers)
	{
		Pair.Value.bIsPressed = false;
		Pair.Value.UpdateFrame = GFrameCounter;
		Pair.Value.bMoved = false;
		Pair.Value.bIsDrag = false;
		Pair.Value.MouseButton = FKey(); 
	}
}

void SKGVirtualJoystick::SetLockMouseOnDraggingCamera(bool bInLockMouseOnDraggingCamera)
{
    bLockMouseOnDraggingCamera = bInLockMouseOnDraggingCamera;
}

void SKGVirtualJoystick::Construct(const FArguments& InArgs)
{
    bVisible = true;
    bPreventReCenter = false;

	CameraCtrl = MakeShared<FKGCameraInputController>();
	if (CameraCtrl.IsValid() && SupportsTouchInput())
	{
		OnMainTouchFingerBegan.AddSP(CameraCtrl.ToSharedRef(), &FKGCameraInputController::OnTouchStarted);
		OnMainTouchFingerMoved.AddSP(CameraCtrl.ToSharedRef(), &FKGCameraInputController::OnTouchMoved);
		OnMainTouchFingerEnded.AddSP(CameraCtrl.ToSharedRef(), &FKGCameraInputController::OnTouchEnded);
	    OnGesturePinchEvent.AddSP(CameraCtrl.ToSharedRef(), &FKGCameraInputController::OnGesturePinch);
	}

    FSlateApplication::Get().GetPlatformApplication()->OnDisplayMetricsChanged().AddSP(this, &SKGVirtualJoystick::HandleDisplayMetricsChanged);
}

int32 SKGVirtualJoystick::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	SCOPED_NAMED_EVENT(KGVirtualJoystick_OnPaint, FColor::Orange);
	if (!bVisible)
	{
		return LayerId;
	}
	
	int32 OutLayerId = LayerId;
	FWidgetStyle WidgetStyle = FWidgetStyle(InWidgetStyle);
	WidgetStyle.BlendOpacity(CurrentOpacity);

	OutLayerId = DrawLeftJoystick(Args, AllottedGeometry, MyCullingRect, OutDrawElements, OutLayerId, WidgetStyle, bParentEnabled);
	OutLayerId = DrawControls(Args, AllottedGeometry, MyCullingRect, OutDrawElements, OutLayerId, WidgetStyle, bParentEnabled);

	if (GKGVirtualJoystickDebugging)
	{
		OutLayerId = DrawDebug(Args, AllottedGeometry, MyCullingRect, OutDrawElements, OutLayerId, WidgetStyle, bParentEnabled);
	}

	return OutLayerId;
}

FVector2D SKGVirtualJoystick::ComputeDesiredSize(float) const
{
    return FVector2D::One() * 100;
}

FReply SKGVirtualJoystick::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
    OnMainTouchFingerBegan.Broadcast(MouseEvent.GetScreenSpacePosition(), MyGeometry, MouseEvent);
    
	FReply Reply = FReply ::Handled();
    if (auto Viewport = FSlateApplication::Get().GetGameViewport())
    {
        Reply = Viewport->OnMouseButtonDown(Viewport->GetCachedGeometry(), MouseEvent);
    }
    
    if (Reply.IsEventHandled())
    {
        FReply Result = FReply ::Handled();
        if (Reply.GetMouseCaptor().IsValid())
        {
            Result.CaptureMouse(AsShared());
        }
        return Result;
    }
    
    return FReply ::Unhandled();
}

FReply SKGVirtualJoystick::OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
    if (MouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton) || MouseEvent.IsMouseButtonDown(EKeys::RightMouseButton))
    {
        // UE_LOG(LogInit, Log, TEXT("[InputMgr]SKGVirtualJoystick::OnMouseMove mouse pos:%s delta:%s"),
        //     *MouseEvent.GetScreenSpacePosition().ToString(), *MouseEvent.GetCursorDelta().ToString());
        OnMainTouchFingerMoved.Broadcast(MouseEvent.GetScreenSpacePosition(), MouseEvent.GetCursorDelta(), MyGeometry, MouseEvent);
    }
    
    FReply Reply = FReply ::Handled();
    if (auto Viewport = FSlateApplication::Get().GetGameViewport())
    {
        FWidgetPath LastPointerCaptorPath;
        bool bHasMouseCapture = HasMouseCapture();
        if (bHasMouseCapture)
        {
            auto SlateUser = FSlateApplication::Get().GetUser(MouseEvent);
            if (SlateUser.IsValid() && GameViewportWidgetPath.IsValid())
            {
                // Pointer captor设置为 viewport
                LastPointerCaptorPath = SlateUser->GetCaptorPath(MouseEvent.GetPointerIndex());
                SlateUser->SetPointerCaptor(MouseEvent.GetPointerIndex(), Viewport.ToSharedRef(), GameViewportWidgetPath);
            }
        }
        
        Reply = Viewport->OnMouseMove(Viewport->GetCachedGeometry(), MouseEvent);
        
        if (bHasMouseCapture && LastPointerCaptorPath.IsValid())
        {
            auto SlateUser = FSlateApplication::Get().GetUser(MouseEvent);
            if (SlateUser.IsValid() && GameViewportWidgetPath.IsValid())
            {
                // 将Pointer captor设置为SKGVirtualJoystick
                SlateUser->SetPointerCaptor(MouseEvent.GetPointerIndex(), AsShared(), LastPointerCaptorPath);
            }
        }
    }
    
    return Reply.IsEventHandled() ? FReply::Handled() : FReply ::Unhandled();
}

FReply SKGVirtualJoystick::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
    OnMainTouchFingerEnded.Broadcast(MouseEvent.GetScreenSpacePosition(), MyGeometry, MouseEvent);
    
    FReply Reply = FReply ::Handled();
    if (auto Viewport = FSlateApplication::Get().GetGameViewport())
    {
        Reply = Viewport->OnMouseButtonUp(Viewport->GetCachedGeometry(), MouseEvent);
    }
    
    if (Reply.IsEventHandled())
    {
        FReply Result = FReply ::Handled();
        if (Reply.GetMouseCaptor().IsValid())
        {
            Result.ReleaseMouseCapture();
        }
        
        return Result;
    }
    
    return FReply ::Unhandled();
}

FReply SKGVirtualJoystick::OnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& Event)
{
    if (Event.IsTouchEvent() && FSlateApplication::Get().IsFakingTouchEvents() && !SupportsTouchInput())
    {
        if (OwnerPlayerController.IsValid())
        {
            // UWidgetBlueprintLibrary::SetInputMode_GameOnly(OwnerPlayerController.Get(), false);
            FInputModeGameOnly InputMode;
            InputMode.SetConsumeCaptureMouseDown(false);
            OwnerPlayerController->SetInputMode(InputMode);
        }
        
        // 由于项目开启了FakingTouch，导致鼠标左键被模拟成了Touch，这里强行校正为鼠标事件
        FPointerEvent MouseEvent(
            FSlateApplication::Get().GetUserIndexForMouse(),
            Event.GetPointerIndex(),
            FSlateApplication::Get().GetCursorPos(),
            FSlateApplication::Get().GetLastCursorPos(),
            FSlateApplication::Get().GetPressedMouseButtons(),
            EKeys::LeftMouseButton,
            Event.GetWheelDelta(),
            FSlateApplication::Get().GetModifierKeys()
            );
        return OnMouseButtonDown(MyGeometry, MouseEvent);
    }
    
	FVector2D LocalCoord = MyGeometry.AbsoluteToLocal(Event.GetScreenSpacePosition());
	if (ShouldShowJoystick() && LeftJoystick.CapturedPointerIndex == INDEX_NONE)
	{
		if (PositionIsInside(LeftJoystick.CorrectedCenter, LocalCoord, LeftJoystick.CorrectedInteractionSize))
		{
			// Align Joystick inside of Screen
			AlignBoxIntoScreen(LocalCoord, LeftJoystick.CorrectedVisualSize, MyGeometry.GetLocalSize());

			LeftJoystick.CapturedPointerIndex = Event.GetPointerIndex();

			if (ActivationDelay == 0.f)
			{
				CurrentOpacity = ActiveOpacity;

				if (!bPreventReCenter)
				{
					LeftJoystick.VisualCenter = LocalCoord;
				}

				if (HandleJoystickTouch(LeftJoystick, LocalCoord, MyGeometry.GetLocalSize()))
				{
					return FReply::Handled().CaptureMouse(SharedThis(this));
				}
			}

			LeftJoystick.bNeedUpdatedCenter = true;
			LeftJoystick.ElapsedTime = 0.f;
			LeftJoystick.NextCenter = LocalCoord;

			return FReply::Unhandled();
		}
	}
	
    FReply Reply = SVirtualJoystick::OnTouchStarted(MyGeometry, Event);
	if (Reply.IsEventHandled())
	{
		return Reply;
	}

	RecordTouchFinger(MyGeometry, Event);
    
	if ( Event.GetEffectingButton() == EKeys::LeftMouseButton || Event.IsTouchEvent())
	{
		Reply = FReply::Handled();
		Reply.DetectDrag(AsShared(), EKeys::LeftMouseButton);
		Reply.CaptureMouse(AsShared());
	}
    else
    {
        Reply = FReply::Unhandled();
    }

    if (bLockMouseOnDraggingCamera && Reply.IsEventHandled())
    {
        // todo:limunan
        /*
        Game.me.CppEntity:KAPI_PlayerController_SetShowMouseCursor(false)
        if UIFunctionLibrary.IsCurrentlyFullscreen() then
            return reply
        else
            return WidgetBlueprintLibrary.LockMouse(reply, self.userWidget)
        end
         */
    }

	return Reply;
}

FReply SKGVirtualJoystick::OnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& Event)
{
	SCOPED_NAMED_EVENT(KGVirtualJoystick_OnTouchMoved, FColor::Magenta);
    if (Event.IsTouchEvent() && FSlateApplication::Get().IsFakingTouchEvents() && !SupportsTouchInput())
    {
        // 由于项目开启了FakingTouch，导致鼠标左键被模拟成了Touch，这里强行校正为鼠标事件
        auto Delta = Event.GetCursorDelta();
        if (FSlateApplication::Get().IsRawMouseMove())
        {
            Delta = FSlateApplication::GetRawMouseMoveDelta();
        }
        
        FPointerEvent MouseEvent(
            FSlateApplication::Get().GetUserIndexForMouse(), 
            Event.GetPointerIndex(), 
            FSlateApplication::Get().GetCursorPos(), 
            FSlateApplication::Get().GetLastCursorPos(), 
            Delta, 
            FSlateApplication::Get().GetPressedMouseButtons(), 
            FSlateApplication::Get().GetModifierKeys());

        return OnMouseMove(MyGeometry, MouseEvent);
    }
    
	FVector2D LocalCoord = MyGeometry.AbsoluteToLocal( Event.GetScreenSpacePosition() );
	if (ShouldShowJoystick() && LeftJoystick.CapturedPointerIndex == Event.GetPointerIndex())
	{
		if (LeftJoystick.bNeedUpdatedCenter)
		{
			return FReply::Unhandled();
		}

		if (HandleJoystickTouch(LeftJoystick, LocalCoord, MyGeometry.GetLocalSize()))
		{
			return FReply::Handled();
		}
	}
	
    FReply Reply = SVirtualJoystick::OnTouchMoved(MyGeometry, Event);
	if (Reply.IsEventHandled())
	{
		return Reply;
	}

	UpdateTouchFinger(MyGeometry, Event);
	return FReply::Handled();
}

FReply SKGVirtualJoystick::OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& Event)
{
    if (Event.IsTouchEvent() && FSlateApplication::Get().IsFakingTouchEvents() && !SupportsTouchInput())
    {
        if (OwnerPlayerController.IsValid())
        {
            UWidgetBlueprintLibrary::SetInputMode_GameAndUIEx(OwnerPlayerController.Get(), nullptr, EMouseLockMode::DoNotLock, false);
        }
        
        // 由于项目开启了FakingTouch，导致鼠标左键被模拟成了Touch，这里强行校正为鼠标事件
        FPointerEvent MouseEvent(
            FSlateApplication::Get().GetUserIndexForMouse(),
            Event.GetPointerIndex(),
            FSlateApplication::Get().GetCursorPos(),
            FSlateApplication::Get().GetLastCursorPos(),
            FSlateApplication::Get().GetPressedMouseButtons(),
            EKeys::LeftMouseButton,
            Event.GetWheelDelta(),
            FSlateApplication::Get().GetModifierKeys()
            );
        
        return OnMouseButtonUp(MyGeometry, MouseEvent);
    }
    
	// is this control the one captured to this pointer?
	if (ShouldShowJoystick() && LeftJoystick.CapturedPointerIndex == Event.GetPointerIndex())
	{
		// release and center the joystick
		LeftJoystick.ThumbPosition = FVector2D(0, 0);
		LeftJoystick.CapturedPointerIndex = -1;

		// send one more joystick update for the centering
		LeftJoystick.bSendOneMoreEvent = true;

		// Pass event as unhandled if time is too short
		if (LeftJoystick.bNeedUpdatedCenter)
		{
			LeftJoystick.bNeedUpdatedCenter = false;
			return FReply::Unhandled();
		}
		
		return FReply::Handled().ReleaseMouseCapture();
	}
	
    FReply Reply = SVirtualJoystick::OnTouchEnded(MyGeometry, Event);
	if (Reply.IsEventHandled())
	{
		return Reply;
	}

	RemoveTouchFinger(MyGeometry, Event);
	return FReply::Handled();
}

void SKGVirtualJoystick::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SCOPED_NAMED_EVENT(KGVirtualJoystick_Tick, FColor::Magenta);
	if (CameraCtrl.IsValid())
	{
	    if (!GameViewportWidgetPath.IsValid())
	    {
	        CacheGameViewportWidgetPath();
	    }
	    
		CameraCtrl->SetGameViewportWidgetPath(GameViewportWidgetPath);
		CameraCtrl->Tick(InDeltaTime);
	}
	
	LeftTimeForCancelRunning = FMath::Max(LeftTimeForCancelRunning - InDeltaTime, 0.f);
	if (!bVisible)
	{
		return;
	}
	
	if (State == State_WaitForStart || State == State_CountingDownToStart)
	{
		CurrentOpacity = 0.f;
	}
	else
	{
		// lerp to the desired opacity based on whether the user is interacting with the joystick
		CurrentOpacity = FMath::Lerp(CurrentOpacity, GetBaseOpacity(), GKGVirtualJoystickOpacityLerpRate * InDeltaTime);
	}

	// count how many controls are active
	int32 NumActiveControls = 0;

	// figure out how much to scale the control sizes
	float ScaleFactor = GetScaleFactor(AllottedGeometry);

	if (TickJoystick(LeftJoystick, AllottedGeometry, InCurrentTime, InDeltaTime, ScaleFactor) != INDEX_NONE)
	{
		NumActiveControls++;
	}

	for (int32 ControlIndex = 0; ControlIndex < Controls.Num(); ControlIndex++)
	{
		if (TickControl(Controls[ControlIndex], ControlIndex, AllottedGeometry, InCurrentTime, InDeltaTime, ScaleFactor) != INDEX_NONE)
		{
			NumActiveControls++;
		}
	}

	PreviousScalingFactor = ScaleFactor;

	if (NumActiveControls > 0 || bPreventReCenter)
	{
		State = State_Active;
	}
	else
	{
		switch (State)
		{
		case State_WaitForStart:
			{
				State = State_CountingDownToStart;
				Countdown = StartupDelay;
			}
			break;
		case State_CountingDownToStart:
			// update the countdown
			Countdown -= InDeltaTime;
			if (Countdown <= 0.0f)
			{
				State = State_Inactive;
			}
			break;
		case State_Active:
			if (NumActiveControls == 0)
			{
				// start going to inactive
				State = State_CountingDownToInactive;
				Countdown = TimeUntilDeactive;
			}
			break;

		case State_CountingDownToInactive:
			// update the countdown
			Countdown -= InDeltaTime;
			if (Countdown <= 0.0f)
			{
				// should we start counting down to a control reset?
				if (TimeUntilReset > 0.0f)
				{
					State = State_CountingDownToReset;
					Countdown = TimeUntilReset;
				}
				else
				{
					// if not, then just go inactive
					State = State_Inactive;
				}
			}
			break;

		case State_CountingDownToReset:
			Countdown -= InDeltaTime;
			if (Countdown <= 0.0f)
			{
				// reset all the controls
				for (int32 ControlIndex = 0; ControlIndex < Controls.Num(); ControlIndex++)
				{
					Controls[ControlIndex].Reset();
				}

				// finally, go inactive
				State = State_Inactive;
			}
			break;
		default:
			break;
		}
	}
}

bool SKGVirtualJoystick::SupportsKeyboardFocus() const
{
    return false;
}


void SKGVirtualJoystick::HandleDisplayMetricsChanged(const FDisplayMetrics& NewDisplayMetric)
{
    SVirtualJoystick::HandleDisplayMetricsChanged(NewDisplayMetric);
}

bool SKGVirtualJoystick::ShouldShowJoystick() const
{
    if (GKGEnableVirtualJoystick)
    {
        return true;
    }

    bool bAlwaysShowTouchInterface = false;
    GConfig->GetBool(TEXT("/Script/Engine.InputSettings"), TEXT("bAlwaysShowTouchInterface"), bAlwaysShowTouchInterface, GInputIni);

    if (FPlatformMisc::GetUseVirtualJoysticks() || bAlwaysShowTouchInterface)
    {
        return true;
    }

#if WITH_EDITOR
    if (UUIFunctionLibrary::GetPreviewPlatform() != EDPIScalePreviewPlatforms::PC)
    {
        return true;
    }
#endif
    
    return false;
}

bool SKGVirtualJoystick::SupportsTouchInput()
{
    if (FPlatformMisc::SupportsTouchInput())
    {
        return true;
    }

#if WITH_EDITOR
    if (UUIFunctionLibrary::GetPreviewPlatform() != EDPIScalePreviewPlatforms::PC)
    {
        return true;
    }
#endif
    
    return false;
}

int32 SKGVirtualJoystick::DrawLeftJoystick(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
    if (!ShouldShowJoystick())
    {
        return LayerId;
    }
    
	SCOPED_NAMED_EVENT(KGVirtualJoystick_DrawJoystick, FColor::Purple);
	int32 RetLayerId = LayerId;
	if (bVisible)
	{
		FLinearColor ColorAndOpacitySRGB = InWidgetStyle.GetColorAndOpacityTint();
		ColorAndOpacitySRGB.A = CurrentOpacity;

		TSharedPtr<ISlateBrushSource> ImageBg = LeftJoystick.Info.ImageDirBgSmall;
		TSharedPtr<ISlateBrushSource> ImageDir = LeftJoystick.Info.ImageDirSmall;

		if (LeftJoystick.bShowBigRange)
		{
			ImageBg = LeftJoystick.Info.ImageDirBgBig;
			ImageDir = LeftJoystick.Info.ImageDirBig;
		}

		FVector2D Size(172, 172);
		if (ImageBg.IsValid() && ImageBg->GetSlateBrush())
		{
			Size = ImageBg->GetSlateBrush()->GetImageSize();
			FSlateDrawElement::MakeBox(
				OutDrawElements,
				RetLayerId++,
				AllottedGeometry.ToPaintGeometry(
					ImageBg->GetSlateBrush()->GetImageSize(),
					FSlateLayoutTransform(LeftJoystick.VisualCenter - ImageBg->GetSlateBrush()->GetImageSize() * 0.5f)
				),
				ImageBg->GetSlateBrush(),
				ESlateDrawEffect::None,
				ColorAndOpacitySRGB
				);
		}

		if (ImageDir.IsValid() && ImageDir->GetSlateBrush())
		{
			//Draw direction arrow
			float AngleDeg = 0.f;
			if (!LeftJoystick.ThumbPosition.IsNearlyZero())
			{
				FVector2D Dir = LeftJoystick.ThumbPosition;
				Dir.Y *= -1.f; // UI的坐标系是X轴向右，Y轴下向下，摇杆的数值坐标系是X轴向右，Y轴向上，所以这里要将Y乘以-1
				Dir.Normalize();
				FVector2D Forward(0, 1);
				float CosTheta = FVector2D::DotProduct(Dir, Forward);
				float AngleRad = FMath::Acos(FMath::Clamp(CosTheta, -1.0f, 1.0f));
				float CrossZ = Dir.X * Forward.Y - Dir.Y * Forward.X;
				AngleDeg = FMath::RadiansToDegrees(AngleRad);
				AngleDeg = (CrossZ < 0) ? -AngleDeg : AngleDeg;
			}
						
			FGeometry ArrowGeometry = AllottedGeometry.MakeChild(
				LeftJoystick.CorrectedVisualSize,
				FSlateLayoutTransform(LeftJoystick.VisualCenter - LeftJoystick.CorrectedVisualSize * 0.5),
				::Concatenate(FScale2D(FVector2D::One()), FShear2D::FromShearAngles(FVector2D::Zero()), FQuat2D(FMath::DegreesToRadians(AngleDeg)), FVector2D::Zero()),
				FVector2f(0.5f, 0.5f)
				);

			// if (GKGVirtualJoystickDebugging)
			// {
			// 	FSlateDrawElement::MakeBox(
			// 	   OutDrawElements,
			// 	   RetLayerId++,
			// 	   ArrowGeometry.ToPaintGeometry(),
			// 	   ImageDir->GetSlateBrush(),
			// 	   ESlateDrawEffect::None,
			// 	   ColorAndOpacitySRGB
			// 	   );
			// }

			FVector2D Pos;
			Pos.X = LeftJoystick.VisualCenter.X - ImageDir->GetSlateBrush()->GetImageSize().X * 0.5;
			Pos.Y = LeftJoystick.VisualCenter.Y - Size.Y * 0.5;
			Pos.Y -= ImageDir->GetSlateBrush()->GetImageSize().Y * 0.5;
			Pos.X -= ArrowGeometry.Position.X;
			Pos.Y -= ArrowGeometry.Position.Y;
			FSlateDrawElement::MakeBox(
				OutDrawElements,
				RetLayerId++,
				ArrowGeometry.ToPaintGeometry(
					ImageDir->GetSlateBrush()->GetImageSize(),
					FSlateLayoutTransform(Pos)
				),
				ImageDir->GetSlateBrush(),
				ESlateDrawEffect::None,
				ColorAndOpacitySRGB
				);
		}

		if (LeftJoystick.Info.ImageThumb.IsValid())
		{
			FSlateDrawElement::MakeBox(
				OutDrawElements,
				RetLayerId++,
				AllottedGeometry.ToPaintGeometry(
					LeftJoystick.CorrectedThumbSize,
					FSlateLayoutTransform(LeftJoystick.VisualCenter + LeftJoystick.ThumbPosition - FVector2D(LeftJoystick.CorrectedThumbSize.X * 0.5f, LeftJoystick.CorrectedThumbSize.Y * 0.5f))
				),
				LeftJoystick.Info.ImageThumb->GetSlateBrush(),
				ESlateDrawEffect::None,
				ColorAndOpacitySRGB
				);
		}

		if (bPreventReCenter && LeftJoystick.Info.ImageClosed.IsValid()
			&& LeftJoystick.Info.ImageClosed->GetSlateBrush())
		{
			FVector2D SizeImage = LeftJoystick.Info.ImageClosed->GetSlateBrush()->GetImageSize(); 
			FSlateDrawElement::MakeBox(
				OutDrawElements,
				RetLayerId++,
				AllottedGeometry.ToPaintGeometry(
					SizeImage,
					FSlateLayoutTransform(LeftJoystick.VisualCenter + LeftJoystick.ThumbPosition - SizeImage * 0.5f)),
					LeftJoystick.Info.ImageClosed->GetSlateBrush(),
					ESlateDrawEffect::None,
					ColorAndOpacitySRGB);
		}
	}
	
	return RetLayerId;
}

int32 SKGVirtualJoystick::DrawControls(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	SCOPED_NAMED_EVENT(KGVirtualJoystick_DrawControls, FColor::Turquoise);
	for (int32 ControlIndex = 0; ControlIndex < Controls.Num(); ControlIndex++)
	{
		const FControlData& Control = Controls[ControlIndex];

		if (Control.Info.Image2.IsValid())
		{
			FSlateDrawElement::MakeBox(
				OutDrawElements,
				LayerId,
				AllottedGeometry.ToPaintGeometry(
					Control.CorrectedVisualSize,
					FSlateLayoutTransform(Control.VisualCenter - FVector2D(Control.CorrectedVisualSize.X * 0.5f, Control.CorrectedVisualSize.Y * 0.5f))
				),
				Control.Info.Image2->GetSlateBrush(),
				ESlateDrawEffect::None,
				InWidgetStyle.GetColorAndOpacityTint()
			);
		}

		if (Control.Info.Image1.IsValid())
		{
			FSlateDrawElement::MakeBox(
				OutDrawElements,
				LayerId + 1,
				AllottedGeometry.ToPaintGeometry(
					Control.CorrectedThumbSize,
					FSlateLayoutTransform(Control.VisualCenter + Control.ThumbPosition - FVector2D(Control.CorrectedThumbSize.X * 0.5f, Control.CorrectedThumbSize.Y * 0.5f))
				),
				Control.Info.Image1->GetSlateBrush(),
				ESlateDrawEffect::None,
				InWidgetStyle.GetColorAndOpacityTint()
			);
		}
	}

	return LayerId + 1; 
}

int32 SKGVirtualJoystick::DrawDebug(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	int OutLayerId = LayerId;
	// Thumb Box
	FVector2D TopLeft = AllottedGeometry.LocalToAbsolute(LeftJoystick.VisualCenter + LeftJoystick.ThumbPosition - LeftJoystick.CorrectedThumbSize * 0.5f);
	FVector2D BottomRight = AllottedGeometry.LocalToAbsolute(LeftJoystick.VisualCenter + LeftJoystick.ThumbPosition + LeftJoystick.CorrectedThumbSize * 0.5f);
	FSlateClippingZone ClippingZone(FSlateRect(TopLeft, BottomRight));
	TArray<FVector2f> Points;
	Points.Add(FVector2f(ClippingZone.TopLeft));
	Points.Add(FVector2f(ClippingZone.TopRight));
	Points.Add(FVector2f(ClippingZone.BottomRight));
	Points.Add(FVector2f(ClippingZone.BottomLeft));
	Points.Add(FVector2f(ClippingZone.TopLeft));

	FSlateDrawElement::MakeLines(OutDrawElements, OutLayerId++, FPaintGeometry(), MoveTemp(Points), ESlateDrawEffect::None, FLinearColor::Yellow, true, 2.0f);

	// Visual Box
	FVector2D VisualBoxTopLeft = AllottedGeometry.LocalToAbsolute(LeftJoystick.VisualCenter - LeftJoystick.CorrectedVisualSize * 0.5f);
	FVector2D VisualBoxBottomRight = AllottedGeometry.LocalToAbsolute(LeftJoystick.VisualCenter + LeftJoystick.CorrectedVisualSize * 0.5f);
	Points.Empty();
	Points.Add(FVector2f(VisualBoxTopLeft.X, VisualBoxTopLeft.Y));
	Points.Add(FVector2f(VisualBoxBottomRight.X, VisualBoxTopLeft.Y));
	Points.Add(FVector2f(VisualBoxBottomRight.X, VisualBoxBottomRight.Y));
	Points.Add(FVector2f(VisualBoxTopLeft.X, VisualBoxBottomRight.Y));
	Points.Add(FVector2f(VisualBoxTopLeft.X, VisualBoxTopLeft.Y));

	FSlateDrawElement::MakeLines(OutDrawElements, OutLayerId++, FPaintGeometry(), MoveTemp(Points), ESlateDrawEffect::None, FLinearColor::Blue, true, 2.0f);

	// Interaction Zone
	TopLeft = AllottedGeometry.LocalToAbsolute(LeftJoystick.CorrectedInteractionTopLeft);
	BottomRight = AllottedGeometry.LocalToAbsolute(LeftJoystick.CorrectedInteractionTopLeft + LeftJoystick.CorrectedInteractionSize);
	FSlateClippingZone ClippingInteraction(FSlateRect(TopLeft, BottomRight));

	Points.Empty();
	Points.Add(FVector2f(ClippingInteraction.TopLeft));
	Points.Add(FVector2f(ClippingInteraction.TopRight));
	Points.Add(FVector2f(ClippingInteraction.BottomRight));
	Points.Add(FVector2f(ClippingInteraction.BottomLeft));
	Points.Add(FVector2f(ClippingInteraction.TopLeft));

	FSlateDrawElement::MakeLines(OutDrawElements, OutLayerId++, FPaintGeometry(), MoveTemp(Points), ESlateDrawEffect::None, FLinearColor::Green, true, 2.0f);

	// Visual Center
	FVector2D Center = AllottedGeometry.LocalToAbsolute(LeftJoystick.VisualCenter);
	Points.Empty();
	Points.Add(FVector2f(Center.X, Center.Y - 25));
	Points.Add(FVector2f(Center.X, Center.Y + 25));
	FSlateDrawElement::MakeLines(OutDrawElements, OutLayerId++, FPaintGeometry(), MoveTemp(Points), ESlateDrawEffect::None, FLinearColor::Red, true, 2.f);

	Points.Empty();
	Points.Add(FVector2f(Center.X - 25, Center.Y));
	Points.Add(FVector2f(Center.X + 25, Center.Y));
	FSlateDrawElement::MakeLines(OutDrawElements, OutLayerId++, FPaintGeometry(), MoveTemp(Points), ESlateDrawEffect::None, FLinearColor::Red, true, 2.f);

	// direction from visual center to thumb position
	FVector2D ThumbPosInAbsolute = AllottedGeometry.LocalToAbsolute(LeftJoystick.ThumbPosition + LeftJoystick.VisualCenter);
	Points.Empty();
	Points.Add(FVector2f(Center.X, Center.Y));
	Points.Add(FVector2f(ThumbPosInAbsolute.X, ThumbPosInAbsolute.Y));
	FSlateDrawElement::MakeLines(OutDrawElements, OutLayerId++, FPaintGeometry(), MoveTemp(Points), ESlateDrawEffect::None, FLinearColor::Red, true, 2.f);
	return OutLayerId;
}

int32 SKGVirtualJoystick::TickJoystick(FJoystickData& Joystick, const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime, float ScaleFactor)
{
    if (!ShouldShowJoystick())
    {
        return 0;
    }
    
	SCOPED_NAMED_EVENT(KGVirtualJoystick_TickJoystick, FColor::Silver);
	FVector2D LocalSize = GetLocalSize(AllottedGeometry);
	if (LeftJoystick.bNeedUpdatedCenter)
	{
		LeftJoystick.ElapsedTime += InDeltaTime;
		if (LeftJoystick.ElapsedTime > ActivationDelay)
		{
			LeftJoystick.bNeedUpdatedCenter = false;
			CurrentOpacity = ActiveOpacity;

			if (!bPreventReCenter)
			{
				LeftJoystick.VisualCenter = LeftJoystick.NextCenter;
			}

			HandleJoystickTouch(LeftJoystick, LeftJoystick.NextCenter, LocalSize);
		}
	}

	// calculate absolute positions based on geometry
	// @todo: Need to manage geometry changing!
	if (!LeftJoystick.bHasBeenPositioned || ScaleFactor != PreviousScalingFactor)
	{
		const FJoystickInfo& ControlInfo = LeftJoystick.Info;

		// update all the sizes
		LeftJoystick.CorrectedVisualSize = FVector2D(ResolveRelativePosition(ControlInfo.VisualSize.X, LocalSize.X, ScaleFactor), ResolveRelativePosition(ControlInfo.VisualSize.Y, LocalSize.Y, ScaleFactor));

		float InteractionLeft = SafeZoneOffset.Left + ResolveRelativePosition(ControlInfo.InteractionZone.Left, LocalSize.X, ScaleFactor);
		float InteractionTop = SafeZoneOffset.Top + ResolveRelativePosition(ControlInfo.InteractionZone.Top, LocalSize.Y, ScaleFactor);
		float InteractionRight = SafeZoneOffset.Left + ResolveRelativePosition(ControlInfo.InteractionZone.Right, LocalSize.X, ScaleFactor);
		float InteractionBottom = SafeZoneOffset.Top + ResolveRelativePosition(ControlInfo.InteractionZone.Bottom, LocalSize.Y, ScaleFactor);
		LeftJoystick.CorrectedInteractionTopLeft = FVector2D(InteractionLeft, InteractionTop);
		LeftJoystick.CorrectedInteractionSize = FVector2D(InteractionRight - InteractionLeft, InteractionBottom - InteractionTop);

		LeftJoystick.CorrectedCenter.X = (InteractionLeft + InteractionRight) * 0.5;
		LeftJoystick.CorrectedCenter.Y = (InteractionTop + InteractionBottom) * 0.5;
		LeftJoystick.VisualCenter = LeftJoystick.CorrectedCenter;
		
		LeftJoystick.CorrectedThumbSize = FVector2D(
			ResolveRelativePosition(ControlInfo.ThumbSize.X, LocalSize.X, ScaleFactor),
			ResolveRelativePosition(ControlInfo.ThumbSize.Y, LocalSize.Y, ScaleFactor));
		LeftJoystick.CorrectedInputScale = ControlInfo.InputScale; // *ScaleFactor;
		LeftJoystick.bHasBeenPositioned = true;
	}

	if (LeftJoystick.CapturedPointerIndex >= 0 || LeftJoystick.bSendOneMoreEvent)
	{
        LeftJoystick.bSendOneMoreEvent = false;

		// Get the corrected thumb offset scale (now allows ellipse instead of assuming square)
		FVector2D ThumbScaledOffset = FVector2D(LeftJoystick.ThumbPosition.X * 2.0f / LeftJoystick.CorrectedVisualSize.X, LeftJoystick.ThumbPosition.Y * 2.0f / LeftJoystick.CorrectedVisualSize.Y);
		float ThumbSquareSum = ThumbScaledOffset.X * ThumbScaledOffset.X + ThumbScaledOffset.Y * ThumbScaledOffset.Y;
		float ThumbMagnitude = FMath::Sqrt(ThumbSquareSum);
		FVector2D ThumbNormalized = FVector2D(0.f, 0.f);
		if (ThumbSquareSum > SMALL_NUMBER)
		{
			const float Scale = 1.0f / ThumbMagnitude;
			ThumbNormalized = FVector2D(ThumbScaledOffset.X * Scale, ThumbScaledOffset.Y * Scale);
		}

		// Find the scale to apply to ThumbNormalized vector to project onto unit square
		float ToSquareScale = fabs(ThumbNormalized.Y) > fabs(ThumbNormalized.X) ? FMath::Sqrt((ThumbNormalized.X * ThumbNormalized.X) / (ThumbNormalized.Y * ThumbNormalized.Y) + 1.0f) : ThumbNormalized.X == 0.0f ? 1.0f : FMath::Sqrt((ThumbNormalized.Y * ThumbNormalized.Y) / (ThumbNormalized.X * ThumbNormalized.X) + 1.0f);

		// Apply proportional offset corrected for projection to unit square
		FVector2D NormalizedOffset = ThumbNormalized * LeftJoystick.CorrectedInputScale * ThumbMagnitude * ToSquareScale;

		// now pass the fake joystick events to the game
		const FGamepadKeyNames::Type XAxis = LeftJoystick.Info.MainInputKey.IsValid() ? LeftJoystick.Info.MainInputKey.GetFName() : FGamepadKeyNames::LeftAnalogX;
		const FGamepadKeyNames::Type YAxis = LeftJoystick.Info.AltInputKey.IsValid() ? LeftJoystick.Info.AltInputKey.GetFName() : FGamepadKeyNames::LeftAnalogY;

	    SetAllUserFocusToGameViewportFast();

		FVector2D LastInputValue = LeftJoystick.InputValue;
		LeftJoystick.InputValue = NormalizedOffset;
		ApplyInput(XAxis, NormalizedOffset.X, false, false);
		ApplyInput(YAxis, -NormalizedOffset.Y, false, false);

		if (LastInputValue.IsNearlyZero() && !NormalizedOffset.IsNearlyZero())
		{
			OnUsingLeftJoystick.Broadcast(true);
		}
		else if (!LastInputValue.IsNearlyZero() && NormalizedOffset.IsNearlyZero())
		{
			OnUsingLeftJoystick.Broadcast(false);
		}

		double Len = NormalizedOffset.Length();
		if (Len < ThresholdForWalking)
		{
			LeftJoystick.bShowBigRange = LeftTimeForCancelRunning > 0;
		}
		else
		{
			LeftTimeForCancelRunning = DelayTimeForCancelRunning;
			LeftJoystick.bShowBigRange = true;
		}
	}
	
	return Joystick.CapturedPointerIndex;
}

int32 SKGVirtualJoystick::TickControl(FControlData& Control, int32 ControlIndex, const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime, float ScaleFactor)
{
	SCOPED_NAMED_EVENT(KGVirtualJoystick_TickControl, FColor::Emerald);
	FVector2D LocalSize = GetLocalSize(AllottedGeometry);
	if (Control.bNeedUpdatedCenter)
	{
		Control.ElapsedTime += InDeltaTime;
		if (Control.ElapsedTime > ActivationDelay)
		{
			Control.bNeedUpdatedCenter = false;
			CurrentOpacity = ActiveOpacity;

			if (!bPreventReCenter)
			{
				Control.VisualCenter = Control.NextCenter;
			}

			HandleTouch(ControlIndex, Control.NextCenter, LocalSize);
		}
	}

	// calculate absolute positions based on geometry
	// @todo: Need to manage geometry changing!
	if (!Control.bHasBeenPositioned || ScaleFactor != PreviousScalingFactor)
	{
		const FControlInfo& ControlInfo = Control.Info;

		// update all the sizes
		Control.CorrectedCenter = FVector2D(
			ResolveRelativePosition(ControlInfo.Center.X, LocalSize.X, ScaleFactor),
			ResolveRelativePosition(ControlInfo.Center.Y, LocalSize.Y, ScaleFactor));
		Control.VisualCenter = Control.CorrectedCenter;
		Control.CorrectedVisualSize = FVector2D(
			ResolveRelativePosition(ControlInfo.VisualSize.X, LocalSize.X, ScaleFactor),
			ResolveRelativePosition(ControlInfo.VisualSize.Y, LocalSize.Y, ScaleFactor));
		Control.CorrectedInteractionSize = FVector2D(
			ResolveRelativePosition(ControlInfo.InteractionSize.X, LocalSize.X, ScaleFactor),
			ResolveRelativePosition(ControlInfo.InteractionSize.Y, LocalSize.Y, ScaleFactor));
		Control.CorrectedThumbSize = FVector2D(
			ResolveRelativePosition(ControlInfo.ThumbSize.X, LocalSize.X, ScaleFactor),
			ResolveRelativePosition(ControlInfo.ThumbSize.Y, LocalSize.Y, ScaleFactor));
		Control.CorrectedInputScale = ControlInfo.InputScale; // *ScaleFactor;
		Control.bHasBeenPositioned = true;
	}

	if (Control.CapturedPointerIndex >= 0 || Control.bSendOneMoreEvent)
	{
		// cache the key released state so we can send input pressed/released events later
		bool bButtonPressed = !Control.bSendOneMoreEvent;

		Control.bSendOneMoreEvent = false;

		// Get the corrected thumb offset scale (now allows ellipse instead of assuming square)
		FVector2D ThumbScaledOffset = FVector2D(Control.ThumbPosition.X * 2.0f / Control.CorrectedVisualSize.X, Control.ThumbPosition.Y * 2.0f / Control.CorrectedVisualSize.Y);
		float ThumbSquareSum = ThumbScaledOffset.X * ThumbScaledOffset.X + ThumbScaledOffset.Y * ThumbScaledOffset.Y;
		float ThumbMagnitude = FMath::Sqrt(ThumbSquareSum);
		FVector2D ThumbNormalized = FVector2D(0.f, 0.f);
		if (ThumbSquareSum > SMALL_NUMBER)
		{
			const float Scale = 1.0f / ThumbMagnitude;
			ThumbNormalized = FVector2D(ThumbScaledOffset.X * Scale, ThumbScaledOffset.Y * Scale);
		}

		// Find the scale to apply to ThumbNormalized vector to project onto unit square
		float ToSquareScale = fabs(ThumbNormalized.Y) > fabs(ThumbNormalized.X) ? FMath::Sqrt((ThumbNormalized.X * ThumbNormalized.X) / (ThumbNormalized.Y * ThumbNormalized.Y) + 1.0f)
			: ThumbNormalized.X == 0.0f ? 1.0f : FMath::Sqrt((ThumbNormalized.Y * ThumbNormalized.Y) / (ThumbNormalized.X * ThumbNormalized.X) + 1.0f);

		// Apply proportional offset corrected for projection to unit square
		FVector2D NormalizedOffset = ThumbNormalized * Control.CorrectedInputScale * ThumbMagnitude * ToSquareScale;

		// now pass the fake joystick events to the game
		const FGamepadKeyNames::Type XAxis = (Control.Info.MainInputKey.IsValid() ? Control.Info.MainInputKey.GetFName() : (ControlIndex == 0 ? FGamepadKeyNames::LeftAnalogX : FGamepadKeyNames::RightAnalogX));
		const FGamepadKeyNames::Type YAxis = (Control.Info.AltInputKey.IsValid() ? Control.Info.AltInputKey.GetFName() : (ControlIndex == 0 ? FGamepadKeyNames::LeftAnalogY : FGamepadKeyNames::RightAnalogY));

		SetAllUserFocusToGameViewportFast();
		ApplyInput(XAxis, NormalizedOffset.X, Control.Info.bTreatAsButton, bButtonPressed);

		// ignore the Y axis if this is a button
		if (!Control.Info.bTreatAsButton)
		{
			ApplyInput(YAxis, -NormalizedOffset.Y, false, bButtonPressed);
		}
	}

	return Control.CapturedPointerIndex;
}

void SKGVirtualJoystick::ApplyInput(const FGamepadKeyNames::Type KeyName, float Delta, bool bTreatAsButton, bool bPressed)
{
	SCOPED_NAMED_EVENT(KGVirtualJoystick_ApplyInput, FColor::Emerald);
	FInputDeviceId PrimaryInputDevice = IPlatformInputDeviceMapper::Get().GetPrimaryInputDeviceForUser(FSlateApplicationBase::SlateAppPrimaryPlatformUser);

	FKey Key(KeyName);
	if (Key.IsAnalog())
	{
		FSlateApplication::Get().OnControllerAnalog(KeyName, FSlateApplicationBase::SlateAppPrimaryPlatformUser, PrimaryInputDevice, Delta);
	}
	else if (bTreatAsButton)
	{
		if (bPressed)
		{
			FSlateApplication::Get().OnControllerButtonPressed(KeyName, FSlateApplicationBase::SlateAppPrimaryPlatformUser, PrimaryInputDevice, false);
		}
		else
		{
			FSlateApplication::Get().OnControllerButtonReleased(KeyName, FSlateApplicationBase::SlateAppPrimaryPlatformUser, PrimaryInputDevice, false);
		}
	}
	else if (Delta != 0.0f)
	{
		FSlateApplication::Get().OnControllerButtonPressed(KeyName, FSlateApplicationBase::SlateAppPrimaryPlatformUser, PrimaryInputDevice, false);
	}
	else
	{
		FSlateApplication::Get().OnControllerButtonReleased(KeyName, FSlateApplicationBase::SlateAppPrimaryPlatformUser, PrimaryInputDevice, false);
	}
}

bool SKGVirtualJoystick::HandleJoystickTouch(FJoystickData& Joystick, const FVector2D& LocalCoord, const FVector2D& ScreenSize)
{
	Joystick.ThumbPosition = LeftJoystick.ComputeJoystickThumbPosition(LocalCoord);

	FVector2D AbsoluteThumbPos = Joystick.ThumbPosition + Joystick.VisualCenter;
	AlignBoxIntoScreen(AbsoluteThumbPos, Joystick.CorrectedThumbSize, ScreenSize);
	Joystick.ThumbPosition = AbsoluteThumbPos - Joystick.VisualCenter;

	return true;
}

float SKGVirtualJoystick::ResolveRelativePosition(float Position, float RelativeTo, float ScaleFactor)
{
	// absolute from edge
	if (Position < -1.0f)
	{
		return RelativeTo + Position * ScaleFactor;
	}
	// relative from edge
	else if (Position < 0.0f)
	{
		return RelativeTo + Position * RelativeTo;
	}
	// relative from 0
	else if (Position <= 1.0f)
	{
		return Position * RelativeTo;
	}
	// absolute from 0
	else
	{
		return Position * ScaleFactor;
	}
}

float SKGVirtualJoystick::GetScaleFactor(const FGeometry& Geometry)
{
    constexpr float DesiredWidth = 1920.0f;

	float UndoDPIScaling = 1.0f / Geometry.Scale;
	return (Geometry.GetDrawSize().GetMax() / DesiredWidth) * UndoDPIScaling;
}

bool SKGVirtualJoystick::PositionIsInside(const FVector2D& Center, const FVector2D& Position, const FVector2D& BoxSize)
{
	return Position.X >= Center.X - BoxSize.X * 0.5f
	&& Position.X <= Center.X + BoxSize.X * 0.5f
	&& Position.Y >= Center.Y - BoxSize.Y * 0.5f
	&& Position.Y <= Center.Y + BoxSize.Y * 0.5f;
}

FTouchFingerInfo& SKGVirtualJoystick::EnsureTouchFinger(int32 PointerIndex)
{
	if (TouchFingers.Contains(PointerIndex))
	{
		return TouchFingers[PointerIndex];
	}

	auto& Info = TouchFingers.Add(PointerIndex);
	Info.PointerIndex = PointerIndex;
	return Info;
}

void SKGVirtualJoystick::RecordTouchFinger(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (TouchFingers.Num() >= MaxTouchFingersCount)
	{
		return;
	}

	FVector2D ScreenPos = MouseEvent.GetScreenSpacePosition();
	uint32 PointerIndex = MouseEvent.GetPointerIndex();
	auto& FingerInfo = EnsureTouchFinger(PointerIndex);
	FingerInfo = TouchFingers[PointerIndex];
	if (!FingerInfo.bIsPressed)
	{
		if (TouchFingers.Num() == 1)
		{
			MainTouchFingerIndex = PointerIndex;
			OnMainTouchFingerBegan.Broadcast(ScreenPos, MyGeometry, MouseEvent);
		}
	}

	FingerInfo.LastUpTime = FingerInfo.PressTime;
	FingerInfo.ScreenPos = ScreenPos;
	FingerInfo.PressTime = FSlateApplication::Get().GetCurrentTime();
	FingerInfo.UpdateFrame = GFrameCounter;
	FingerInfo.bIsPressed = true;
	FingerInfo.bMoved = false;
	FingerInfo.bIsDrag = false;
	FingerInfo.MouseButton = MouseEvent.GetEffectingButton();
	BindGestureGroup(PointerIndex);
}

void SKGVirtualJoystick::UpdateTouchFinger(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	uint32 PointerIndex = MouseEvent.GetPointerIndex();
	auto& FingerInfo = EnsureTouchFinger(PointerIndex);
	if (!FingerInfo.bIsPressed)
	{
		return;
	}

	if (GFrameCounter == FingerInfo.UpdateFrame)
	{
		return;
	}

	FVector2D LastPos = FingerInfo.ScreenPos;
	FingerInfo.ScreenPos = MouseEvent.GetScreenSpacePosition();
	FingerInfo.bMoved = true;
	FingerInfo.UpdateFrame = GFrameCounter;
	
	if (PointerIndex == MainTouchFingerIndex)
	{
		OnMainTouchFingerMoved.Broadcast(FingerInfo.ScreenPos, FingerInfo.ScreenPos - LastPos, MyGeometry, MouseEvent);
	}
	UpdateGestureGroupByFingerIndex(PointerIndex);
}

void SKGVirtualJoystick::RemoveTouchFinger(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	uint32 PointerIndex = MouseEvent.GetPointerIndex();
	if (!TouchFingers.Contains(PointerIndex))
	{
		return;
	}
	
	auto& FingerInfo = EnsureTouchFinger(PointerIndex);
	ClearTouchFinger(FingerInfo);
	if (PointerIndex == MainTouchFingerIndex)
	{
		FVector2D ScreenPos = MouseEvent.GetScreenSpacePosition();
		OnMainTouchFingerEnded.Broadcast(ScreenPos, MyGeometry, MouseEvent);
		MainTouchFingerIndex = INDEX_NONE;
	}
	UnbindGestureGroup(PointerIndex);
}

void SKGVirtualJoystick::ClearTouchFinger(const FTouchFingerInfo& TouchFingerInfo)
{
	TouchFingers.Remove(TouchFingerInfo.PointerIndex);
}

void SKGVirtualJoystick::BindGestureGroup(int32 PointerIndex)
{
	if (GestureMask == 0 || !TouchFingers.Contains(PointerIndex))
	{
		return ;
	}

	auto& CurFingerInfo = TouchFingers[PointerIndex];
	for (const auto& Pairs : TouchFingers)
	{
		if (Pairs.Key != PointerIndex)
		{
			int32 Mask = 0;
			if (Pairs.Value.bIsPressed)
			{
				if (CanTriggerGesture(EKGGestureType::PINCH)
					&& CurFingerInfo.PressTime - Pairs.Value.PressTime < PinchCheckDuration)
				{
					Mask = Mask | static_cast<uint8>(EKGGestureType::PINCH);
				}
			}

			if (Mask != 0)
			{
			    FKGGestureRecognizer GestureRecognizer;
			    TArray<FTouchFingerInfo> Fingers = {CurFingerInfo, Pairs.Value};
			    GestureRecognizer.StartGesture(Fingers, FPlatformTime::Seconds() * 1000, Mask);
			    GestureRecognizers.Add(GestureRecognizer);
			}
		}
	}
}

void SKGVirtualJoystick::UnbindGestureGroup(int32 PointerIndex)
{
    for (int32 i = GestureRecognizers.Num() - 1; i >= 0; i--)
    {
        if (GestureRecognizers[i].ContainFinger(PointerIndex))
        {
            GestureRecognizers[i].EndGesture();
            GestureRecognizers.RemoveAt(i);
        }
    }
}

bool SKGVirtualJoystick::CanTriggerGesture(EKGGestureType GestureType) const
{
	return (GestureMask & static_cast<uint8>(GestureType)) != 0;
}

void SKGVirtualJoystick::UpdateGestureGroupByFingerIndex(int32 PointerIndex)
{
    for (auto& GestureRecognizer : GestureRecognizers)
    {
        if (GestureRecognizer.ContainFinger(PointerIndex))
        {
            GestureRecognizer.UpdateGesture(FPlatformTime::Seconds() * 1000);
            
            // 处理识别到的手势
            FKGGestureData GestureData = GestureRecognizer.GetGestureData();
            if (GestureData.Type == EKGGestureType::PINCH)
            {
                // 触发捏合事件
                OnGesturePinchEvent.Broadcast(GestureData);
            }
            // 其他手势类型的处理...
        }
    }
}

void SKGVirtualJoystick::UpdateGestureRecognizers()
{
    for (auto& GestureRecognizer : GestureRecognizers)
    {
        GestureRecognizer.UpdateGesture(FPlatformTime::Seconds() * 1000);
        
        // 处理识别到的手势
        FKGGestureData GestureData = GestureRecognizer.GetGestureData();
        if (GestureData.Type == EKGGestureType::PINCH)
        {
            // 触发捏合事件
            OnGesturePinchEvent.Broadcast(GestureData);
        }
        // 其他手势类型的处理...
    }
}

void SKGVirtualJoystick::SetAllUserFocusToGameViewportFast()
{
	if (!GameViewportWidgetPath.IsValid())
	{
		CacheGameViewportWidgetPath();
	}

	if (GameViewportWidgetPath.IsValid())
	{
		FSlateApplication::Get().SetAllUserFocus(GameViewportWidgetPath, EFocusCause::SetDirectly);
	}

    //FSlateApplication::Get().SetAllUserFocusToGameViewport();
}

FVector2D SKGVirtualJoystick::GetLocalSize(const FGeometry& AllottedGeometry) const
{
	return AllottedGeometry.GetLocalSize() - SafeZoneOffset.GetDesiredSize();
}


#pragma optimize("", on)
