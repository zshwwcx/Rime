#include "Platform/KGUIPlatformManager.h"

TSharedPtr<FKGUIPlatformManager> FKGUIPlatformManager::Singleton = nullptr;

void FKGUIPlatformManager::SetPlatform(EKGUIPlatforms InPlatform)
{
	if (this->Platform == InPlatform)
	{
		return;
	}
	this->Platform = InPlatform;
	if (this->PlatformChanged.IsBound())
	{
		this->PlatformChanged.Broadcast(this->Platform);
	}
}

EKGUIPlatforms FKGUIPlatformManager::GetPlatform()
{
	return this->Platform;
}

FKGUIPlatformManager* FKGUIPlatformManager::GetInstance()
{
	if (Singleton == nullptr)
	{
		Singleton = MakeShared<FKGUIPlatformManager>();
	}
	return Singleton.Get();
}

void FKGUIPlatformManager::TryDestroyInstance()
{
	if (Singleton == nullptr)
	{
		return;
	}
	Singleton = nullptr;
}
