#include "KGUIWidgetBlueprintGeneratedClassExtension.h"

#include "MovieScene.h"
#include "Animation/WidgetAnimation.h"
#include "UMG/Blueprint/KGUserWidget.h"

FString UKGUIWidgetBlueprintGeneratedClassExtension::ExtensionName = TEXT("KGUI");

bool UKGUIWidgetBlueprintGeneratedClassExtension::ApplyWidgetAnimationInitialStyle(UKGUserWidget& Widget, UWidgetAnimation& WidgetAnimation)
{
	return ApplyWidgetAnimationStyle(Widget, WidgetAnimation, AnimationInitialStyles);
}

bool UKGUIWidgetBlueprintGeneratedClassExtension::ApplyWidgetAnimationTerminalStyle(UKGUserWidget& Widget, UWidgetAnimation& WidgetAnimation)
{
	return ApplyWidgetAnimationStyle(Widget, WidgetAnimation, AnimationTerminalStyles);
}

bool UKGUIWidgetBlueprintGeneratedClassExtension::HasAnyWidgetAnimationStyle(const UKGUserWidget& Widget, UWidgetAnimation& WidgetAnimation) const
{
	auto MovieScene = WidgetAnimation.GetMovieScene();
	if (!MovieScene)
	{
		return false;
	}
	auto Name = MovieScene->GetFName();
	return AnimationInitialStyles.Contains(Name) || AnimationTerminalStyles.Contains(Name);
}

bool UKGUIWidgetBlueprintGeneratedClassExtension::ApplyWidgetAnimationStyle(UKGUserWidget& Widget, UWidgetAnimation& WidgetAnimation, const TMap<FName, FKGStyleSheet>& Styles)
{
	auto MovieScene = WidgetAnimation.GetMovieScene();
	if (!MovieScene)
	{
		return false;
	}
	auto Found = Styles.Find(MovieScene->GetFName());
	if (!Found)
	{
		return false;
	}
	const auto& Style = *Found;
	Style.Apply(&Widget, &Widget, true);
	return true;
}
