#include "KGUI.h"

#include "KGUISettings.h"
#include "KGUIWidgetBlueprintGeneratedClassExtension.h"
#include "LuaState.h"
#include "Core/Common.h"
#include "Engine/AssetManager.h"
#include "Internationalization/StringTable.h"
#include "Internationalization/StringTableCore.h"
#include "Localization/KGStringTable.h"
#include "Platform/KGUIPlatformManager.h"
#include "UMG/Components/KGListView.h"
#include "UMG/StateManagement/KGStateManagement.h"
#include "UMG/StateManagement/KGButtonState.h"
#include "UMG/StateManagement/KGPlatformState.h"
#include "UMG/Blueprint/UIFunctionLibrary.h"

#if __has_include("CxxReflectionKGUI.h")
#include "CxxReflectionKGUI.h"
#endif

#define LOCTEXT_NAMESPACE "FKGUIModule"


FString FKGUIModule::NotInMainThreadTag = TEXT("NOT IN GAME-THREAD");
FString FKGUIModule::EmptyLuaStackTrace = TEXT("");
FString FKGUIModule::DefaultLuaStack = TEXT("stack traceback:");

#pragma region 状态组

void FKGUIModule::RegisterScriptableStateGroup(TSharedPtr<IKGScriptableStateGroup> ScriptableStateGroup)
{
	auto& StateGroupName = ScriptableStateGroup->GetStateGroupName();
	if (ScriptableStateGroups.Find(StateGroupName) == NULL)
	{
		ScriptableStateGroups.Add(StateGroupName, TArray<TSharedPtr<IKGScriptableStateGroup>>());
	}
	auto& Array = ScriptableStateGroups[StateGroupName];
	if (Array.FindByPredicate([ScriptableStateGroup](TSharedPtr<IKGScriptableStateGroup> Item) { return Item->GetClass() == ScriptableStateGroup->GetClass(); }) != NULL)
	{
		UE_LOG(LogStateManagement, Error, TEXT("Cannot register a duplicate state group ScriptableStateGroup, StateGroupName: %s"), *StateGroupName);
		return;
	}
	Array.Add(ScriptableStateGroup);
}

TSharedPtr<IKGScriptableStateGroup> FKGUIModule::GetScriptableStateGroup(UClass* Class, const FString& StateGroupName)
{
	TTuple<TWeakObjectPtr<UClass>, FString> FastLookupKey(Class, StateGroupName);
	auto* FastLookupValue = ScriptableStateGroupFastLookupTable.Find(FastLookupKey);
	if (FastLookupValue != NULL)
	{
		return *FastLookupValue;
	}

	auto* Array = ScriptableStateGroups.Find(StateGroupName);
	if (Array == NULL)
	{
		ScriptableStateGroupFastLookupTable.Add(FastLookupKey, NULL);
		return NULL;
	}
	TSharedPtr<IKGScriptableStateGroup>* Found = NULL;
	for (auto& ScriptableStateGroup : *Array)
	{
		if (!Class->IsChildOf(ScriptableStateGroup->GetClass()))
		{
			continue;
		}
		if (Found != NULL)
		{
			if (!ScriptableStateGroup->GetClass()->IsChildOf((*Found)->GetClass()))
			{
				continue;
			}
		}
		Found = &ScriptableStateGroup;
	}
	if (Found == NULL)
	{
		ScriptableStateGroupFastLookupTable.Add(FastLookupKey, NULL);
		return NULL;
	}
	ScriptableStateGroupFastLookupTable.Add(FastLookupKey, *Found);
	return *Found;
}

TArray<TSharedPtr<IKGScriptableStateGroup>> FKGUIModule::GetClassScriptableStateGroups(UClass* Class)
{
	TMap<FString, TSharedPtr<IKGScriptableStateGroup>> LookupTable;
	for (auto It = ScriptableStateGroups.CreateConstIterator(); It; ++It)
	{
		auto& Array = It.Value();
		for (auto& ScriptableStateGroup : Array)
		{
			if (!Class->IsChildOf(ScriptableStateGroup->GetClass()))
			{
				continue;
			}
			auto& StateGroupName = ScriptableStateGroup->GetStateGroupName();
			auto* Found = LookupTable.Find(StateGroupName);
			if (Found != NULL)
			{
				if (!Class->IsChildOf((*Found)->GetClass()))
				{
					continue;
				}
				LookupTable[StateGroupName] = ScriptableStateGroup;
			}
			else
			{
				LookupTable.Add(StateGroupName, ScriptableStateGroup);
			}
		}
	}
	TArray<TSharedPtr<IKGScriptableStateGroup>> ClassScriptableStateGroups;
	for (auto It = LookupTable.CreateConstIterator(); It; ++It)
	{
		ClassScriptableStateGroups.Add(It.Value());
	}
	ClassScriptableStateGroups.Sort([](TSharedPtr<IKGScriptableStateGroup> A, TSharedPtr<IKGScriptableStateGroup> B) {
		return A->GetStateGroupName().Compare(B->GetStateGroupName()) > 0;
	});
	return ClassScriptableStateGroups;
}

TArray<TSharedPtr<IKGScriptableStateGroup>> FKGUIModule::GetObjectAvailableScriptableStateGroups(UWidget* Widget)
{
	TArray<TSharedPtr<IKGScriptableStateGroup>> AvailableScriptableStateGroups;
	if (!ensure(Widget))
	{
		return AvailableScriptableStateGroups;
	}
	UKGStateManagement* StateManagement = Widget->GetComponent<UKGStateManagement>();
	if (!ensure(StateManagement))
	{
		return AvailableScriptableStateGroups;
	}
	for (auto& ScriptableStateGroup : GetClassScriptableStateGroups(Widget->GetClass()))
	{
		if (StateManagement->FindStateGroup(ScriptableStateGroup->GetStateGroupName()) == nullptr)
		{
			AvailableScriptableStateGroups.Add(ScriptableStateGroup);
		}
	}
	return AvailableScriptableStateGroups;
}

bool FKGUIModule::HasScriptableStateGroupByName(const FString& StateGroupName) const
{
	auto Found = ScriptableStateGroups.Find(StateGroupName);
	if (Found == nullptr)
	{
		return false;
	}
	if (Found->Num() == 0)
	{
		return false;
	}
	return true;
}

#if WITH_EDITOR

TArray<FKGStateGroupDeclaration> FKGUIModule::GetObjectAvailableStateGroupDeclarationsFromDataTable(UWidget* Widget) const
{
	TArray<FKGStateGroupDeclaration> AvailableStateGroupDeclarations;
	if (!ensure(Widget))
	{
		return AvailableStateGroupDeclarations;
	}
	UKGStateManagement* StateManagement = Widget->GetComponent<UKGStateManagement>();
	if (!ensure(StateManagement))
	{
		return AvailableStateGroupDeclarations;
	}
	auto Settings = GetDefault<UKGUISettings>();
	if (!ensure(Settings))
	{
		return AvailableStateGroupDeclarations;
	}
	const auto StateGroupDeclarations = Settings->GetAllStateGroupDeclarationsInDataTable();
	for (const auto& StateGroupDeclaration : StateGroupDeclarations)
	{
		if (StateManagement->FindStateGroup(StateGroupDeclaration.GetName()) == nullptr)
		{
			AvailableStateGroupDeclarations.Add(StateGroupDeclaration);
		}
	}
	return AvailableStateGroupDeclarations;
}

bool FKGUIModule::TryGetStateGroupDeclarationFromDataTable(const FString& StateGroupName, FKGStateGroupDeclaration& StateGroupDeclaration) const
{
	auto Settings = GetDefault<UKGUISettings>();
	if (!ensure(Settings))
	{
		return false;
	}
	return Settings->TryGetStateGroupDeclaration(StateGroupName, StateGroupDeclaration);
}

#endif

#pragma endregion

FKGUIModule& FKGUIModule::Get()
{
	return FModuleManager::LoadModuleChecked<FKGUIModule>("KGUI");
}

FKGStateControllerPropertyCustomization FKGStateControllerPropertyCustomization::Create(
	const TFieldPath<FProperty>& PropertyPath,
	const FKGStateControllerPropertyCustomSetter& Setter,
	const FText& DisplayName,
	const TSet<TFieldPath<FProperty>>& WatchedPropertyPaths
)
{
	FKGStateControllerPropertyCustomization StateControllerPropertyCustomization;
	StateControllerPropertyCustomization.PropertyPath = PropertyPath;
	StateControllerPropertyCustomization.Setter = Setter;
	StateControllerPropertyCustomization.DisplayName = DisplayName;
	StateControllerPropertyCustomization.WatchedPropertyPaths = WatchedPropertyPaths;
	return StateControllerPropertyCustomization;
}

#ifdef CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION
	#error CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION has duplicated definitions.
#endif
#define CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION(PROPERTY, DISPLAY_NAME) \
	FKGStateControllerPropertyCustomization::Create( \
		USizeBox::StaticClass()->FindPropertyByName(GET_MEMBER_NAME_CHECKED(USizeBox, bOverride_##PROPERTY)), \
		FKGStateControllerPropertyCustomization::FKGStateControllerPropertyCustomSetter::CreateLambda([](UObject* Object, const void* Value) \
		{ \
			check(Object != nullptr); \
			auto SizeBox = Cast<USizeBox>(Object); \
			if (SizeBox == nullptr) \
			{ \
				UE_LOG(LogKGUI, Error, TEXT("An internal error occurred: %s is not a SizeBox."), *Object->GetClass()->GetName()); \
				return; \
			} \
			SizeBox->bOverride_##PROPERTY = *(bool*)Value; \
			if (SizeBox->bOverride_##PROPERTY) \
			{ \
				SizeBox->Set##PROPERTY(SizeBox->PROPERTY); \
			} \
			else \
			{ \
				SizeBox->Clear##PROPERTY(); \
			} \
		}), \
		DISPLAY_NAME, \
		{ USizeBox::StaticClass()->FindPropertyByName(GET_MEMBER_NAME_CHECKED(USizeBox, PROPERTY)) } \
	)

void FKGUIModule::StartupModule()
{
#if __has_include("CxxReflectionKGUI.h") && !defined(KG_CXX_REFLECTING)
	REGISTER_LAZY_REGISTER(KGUI);
#endif
	UUIFunctionLibrary::RegisteFunctions();
	RegisterScriptableStateGroup(MakeShared<FKGButtonState>());
	RegisterScriptableStateGroup(MakeShared<FKGPlatformState>());
	
	FCoreDelegates::OnPostEngineInit.AddLambda([]() {
		if (const bool bExplicitChildZOrder = GetDefault<UKGUISettings>()->bUseSimplifiedListViewEntryTypeRestriction)
		{
			SimplifyListViewEntryTypeRestriction();
		}
		FKGUIPlatformManager::GetInstance();
	});
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	RegisterStateControllerPropertyCustomization(CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION(WidthOverride,    FText::FromString(TEXT("激活“宽度重载”"))));
	RegisterStateControllerPropertyCustomization(CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION(HeightOverride,   FText::FromString(TEXT("激活“高度重载”"))));
	RegisterStateControllerPropertyCustomization(CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION(MinDesiredWidth,  FText::FromString(TEXT("激活“所需最小宽度”"))));
	RegisterStateControllerPropertyCustomization(CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION(MinDesiredHeight, FText::FromString(TEXT("激活“所需最小高度”"))));
	RegisterStateControllerPropertyCustomization(CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION(MaxDesiredWidth,  FText::FromString(TEXT("激活“所需最大宽度”"))));
	RegisterStateControllerPropertyCustomization(CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION(MaxDesiredHeight, FText::FromString(TEXT("激活“所需最大高度”"))));
	RegisterStateControllerPropertyCustomization(CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION(MinAspectRatio,   FText::FromString(TEXT("激活“最小宽高比”"))));
	RegisterStateControllerPropertyCustomization(CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION(MaxAspectRatio,   FText::FromString(TEXT("激活“最大宽高比”"))));
	PRAGMA_ENABLE_DEPRECATION_WARNINGS

	IStringTableEngineBridge::SetOnPreLoadStringTableAsset(IStringTableEngineBridge::FKGOnPreLoadStringTableAsset::CreateRaw(this, &FKGUIModule::OnPreLoadStringTableAsset));
}

#undef CREATE_SIZE_BOX_STATE_CONTROLLER_PROPERTY_CUSTOMIZATION

void FKGUIModule::ShutdownModule()
{
	IStringTableEngineBridge::SetOnPreLoadStringTableAsset(IStringTableEngineBridge::FKGOnPreLoadStringTableAsset());
	FKGUIPlatformManager::TryDestroyInstance();
}

#pragma region 简化列表Entry类型限制

void FKGUIModule::SimplifyListViewEntryTypeRestriction()
{
#if WITH_EDITOR
	const FString KuaishouGameUserWidgetName = "/Script/KGUI.KGUserWidget";
	UClass* ThisClass = UKGListView::StaticClass();
	UClass* BaseClass = ThisClass;
	while (BaseClass != NULL)
	{
		BaseClass->SetMetaData("EntryInterface", TEXT("None"));
		BaseClass = BaseClass->GetSuperClass();
	}
	ThisClass->SetMetaData("EntryClass", *KuaishouGameUserWidgetName);
	ThisClass->FindPropertyByName("EntryWidgetClass")->SetMetaData("MustImplement", TEXT("None"));
#endif
	FModuleManager::GetModuleChecked<IUMGModule>("UMG").SetListViewEntryTypeRestrictionSimplified(true);
}

#pragma endregion

#pragma region 资源检查

FKGUIModule::FKGOnUserWidgetValidating& FKGUIModule::GetOnUserWidgetValidating()
{
	return OnUserWidgetValidating;
}

FString FKGUIModule::GetLuaTraceback()
{
	// only main-thread return a valid lua callstack string
	if (!IsInGameThread())
	{
		return NotInMainThreadTag;
	}
	NS_SLUA::LuaState* luaState = NS_SLUA::LuaState::get();
	if (luaState != nullptr)
	{
		lua_State* nativeLuaState = luaState->getLuaState();
		if (nativeLuaState != nullptr)
		{
			luaL_traceback(nativeLuaState, nativeLuaState, nullptr, 1);
			const char* luaTraceback = lua_tostring(nativeLuaState, -1);
			FString result(luaTraceback);
			lua_pop(nativeLuaState, 1);
			return result;
		}
	}
	return EmptyLuaStackTrace;
}

#pragma endregion


#pragma region UserWidgetMap

void FKGUIModule::SaveWidgetComponentMap(TWeakObjectPtr<UKGWidgetComponent> WidgetComponent, TWeakObjectPtr<UUserWidget> UserWidget)
{
	if (WidgetComponent.IsValid() && UserWidget.IsValid())
	{
		WidgetComponentToUserWidgetGroups.Add(WidgetComponent, UserWidget);	
	}
}

TWeakObjectPtr<UUserWidget> FKGUIModule::GetUserWidgetFromMapByWidgetComponent(TWeakObjectPtr<UKGWidgetComponent> WidgetComponent)
{
	for (const TPair<TWeakObjectPtr<UKGWidgetComponent>, TWeakObjectPtr<UUserWidget>>& Elem : WidgetComponentToUserWidgetGroups)
	{
		if (Elem.Key.IsValid() && Elem.Value.IsValid() && Elem.Key == WidgetComponent)
		{
			UE_LOG(LogTemp, Log, TEXT("WidgetComponent: %s, UserWidget: %s"), *Elem.Key->GetName(), *Elem.Value->GetName());
			return Elem.Value;
		}
	}
	
	return nullptr;
}

void FKGUIModule::RemoveWidgetComponentMap(TWeakObjectPtr<UUserWidget> UserWidget)
{
	TArray<TWeakObjectPtr<UKGWidgetComponent>> KeysToRemove;
	
	for (auto& Elem : WidgetComponentToUserWidgetGroups)
	{
		if (Elem.Key.IsValid() && Elem.Value.IsValid() && Elem.Value == UserWidget)
		{
			// WidgetComponentToUserWidgetGroups.Remove(Elem.Key);
			KeysToRemove.Add(Elem.Key);
		}
	}

	for (auto& Key: KeysToRemove)
	{
		WidgetComponentToUserWidgetGroups.Remove(Key);
	}
}

bool FKGUIModule::RegisterStateControllerPropertyCustomization(const FKGStateControllerPropertyCustomization& StateControllerPropertyCustomization)
{
	auto PropertyPath = StateControllerPropertyCustomization.PropertyPath;
	if (PropertyPath.Get() == nullptr)
	{
		UE_LOG(LogKGUI, Error, TEXT("Try to register state controller property customization with empty property path."));
		return false;
	}
	auto Class = PropertyPath->GetOwnerClass();
	if (Class == nullptr)
	{
		UE_LOG(LogKGUI, Error, TEXT("Try to register state controller property customization with empty class."));
		return false;
	}
	auto Setter = StateControllerPropertyCustomization.Setter;
	if (!Setter.IsBound())
	{
		UE_LOG(LogKGUI, Error, TEXT("Try to register state controller property customization with unbound setter delegate."));
		return false;
	}

	if (StateControllerPropertyCustomizationLookupTable.Contains(PropertyPath))
	{
		UE_LOG(LogKGUI, Error, TEXT("Try to register state controller property customization with class `%s` and property path `%s` which has been registered."), *Class->GetName(), *PropertyPath->GetPathName());
		return false;
	}
	auto NewStateControllerPropertyCustomization = MakeShared<FKGStateControllerPropertyCustomization>(StateControllerPropertyCustomization);
	StateControllerPropertyCustomizationLookupTable.Add(PropertyPath, NewStateControllerPropertyCustomization);
	return true;
}

TSharedPtr<FKGStateControllerPropertyCustomization> FKGUIModule::GetStateControllerPropertyCustomization(const TFieldPath<FProperty>& PropertyPath) const
{
	if (!StateControllerPropertyCustomizationLookupTable.Contains(PropertyPath))
	{
		return nullptr;
	}
	return StateControllerPropertyCustomizationLookupTable[PropertyPath];
}

TArray<TSharedPtr<FKGStateControllerPropertyCustomization>> FKGUIModule::GetStateControllerPropertyCustomizations(UClass* Class) const
{
	TArray<TSharedPtr<FKGStateControllerPropertyCustomization>> Customizations;
	for (const auto& KeyValuePair : StateControllerPropertyCustomizationLookupTable)
	{
		const auto& Key = KeyValuePair.Key;
		const auto& Value = KeyValuePair.Value;
		if (Class->IsChildOf(Key->GetOwnerClass()))
		{
			Customizations.Add(Value);
		}
	}
	return Customizations;
}

#pragma endregion

#pragma region 本地化

// Mirror from FStringTableEngineBridge::GetAssetReference
static FSoftObjectPath GetAssetReference(const FName InTableId)
{
	const FString StringTableAssetName = InTableId.ToString();

	FString StringTablePackageName = StringTableAssetName;
	{
		int32 DotIndex = INDEX_NONE;
		if (StringTablePackageName.FindChar(TEXT('.'), DotIndex))
		{
			StringTablePackageName.LeftInline(DotIndex, EAllowShrinking::No);
		}
	}

	FSoftObjectPath StringTableAssetReference;
	if (FPackageName::IsValidLongPackageName(StringTablePackageName, /*bIncludeReadOnlyRoots*/true) && FPackageName::DoesPackageExist(StringTablePackageName))
	{
		StringTableAssetReference.SetPath(StringTableAssetName);
	}

	return StringTableAssetReference;
}

// Mirror from FStringTableEngineBridge::LoadStringTableAssetImpl
int32 FKGUIModule::LoadStringTableAssetImpl(const FName InTableId, IStringTableEngineBridge::FLoadStringTableAssetCallback InLoadedCallback)
{
	const FSoftObjectPath StringTableAssetReference = GetAssetReference(InTableId);
	if (StringTableAssetReference.IsValid())
	{
		UStringTable* StringTableAsset = Cast<UStringTable>(StringTableAssetReference.ResolveObject());
		if (StringTableAsset)
		{
			// Already loaded
			if (InLoadedCallback)
			{
				InLoadedCallback(InTableId, StringTableAsset->GetStringTableId());
			}
			return INDEX_NONE;
		}

		// Not loaded - either load synchronously or asynchronously depending on the environment
		if (IsAsyncLoading())
		{
			const FString StringTableAssetPackageNameStr = StringTableAssetReference.GetLongPackageName();
			const FName StringTableAssetPackageName = *StringTableAssetPackageNameStr;

			{
				FScopeLock AsyncLoadingStringTablesLock(&AsyncLoadingStringTablesCS);

				// Already being asynchronously loaded? If so, merge the request
				if (FAsyncLoadingStringTable* AsyncLoadingState = AsyncLoadingStringTables.Find(StringTableAssetPackageName))
				{
					if (InLoadedCallback)
					{
						AsyncLoadingState->LoadedCallbacks.Add(InLoadedCallback);
					}
					return AsyncLoadingState->AsyncLoadingId;
				}

				// Prepare for an asynchronous load
				FAsyncLoadingStringTable& NewAsyncLoadingState = AsyncLoadingStringTables.Add(StringTableAssetPackageName);
				NewAsyncLoadingState.RequestedTableId = InTableId;
				if (InLoadedCallback)
				{
					NewAsyncLoadingState.LoadedCallbacks.Add(InLoadedCallback);
				}
			}

			// Begin an asynchronous load
			// Note: The LoadPackageAsync callback may fire immediately if the request is invalid. This would remove the entry from AsyncLoadingStringTables, so it's valid for the find request below to fail in that case
			// BEGIN CHANGE BY wuzhiwei05@kuaishou.com
#if 0
			const int32 AsyncLoadingId = LoadPackageAsync(StringTableAssetPackageNameStr, FLoadPackageAsyncDelegate::CreateRaw(this, &FStringTableEngineBridge::HandleStringTableAssetAsyncLoadCompleted));
#else
			const int32 AsyncLoadingId = LoadPackageAsync(StringTableAssetPackageNameStr, FLoadPackageAsyncDelegate::CreateRaw(this, &FKGUIModule::HandleStringTableAssetAsyncLoadCompleted));
#endif
			// END CHANGE BY wuzhiwei05@kuaishou.com

			if (AsyncLoadingId != INDEX_NONE)
			{
				// Load ongoing
				FScopeLock AsyncLoadingStringTablesLock(&AsyncLoadingStringTablesCS);
				if (FAsyncLoadingStringTable* AsyncLoadingState = AsyncLoadingStringTables.Find(StringTableAssetPackageName))
				{
					AsyncLoadingState->AsyncLoadingId = AsyncLoadingId;
				}
				return AsyncLoadingId;
			}

			// Load failed
			if (InLoadedCallback)
			{
				InLoadedCallback(InTableId, FName());
			}
			return INDEX_NONE;
		}
		else
		{
			// Attempt a synchronous load
			StringTableAsset = Cast<UStringTable>(StringTableAssetReference.TryLoad());
			if (InLoadedCallback)
			{
				InLoadedCallback(InTableId, StringTableAsset ? StringTableAsset->GetStringTableId() : FName());
			}
			return INDEX_NONE;
		}
	}

	// Not an asset - just say it's already loaded
	if (InLoadedCallback)
	{
		InLoadedCallback(InTableId, InTableId);
	}
	return INDEX_NONE;
}

// Mirror from FStringTableEngineBridge::HandleStringTableAssetAsyncLoadCompleted
void FKGUIModule::HandleStringTableAssetAsyncLoadCompleted(const FName& InLoadedPackageName, UPackage* InLoadedPackage, EAsyncLoadingResult::Type InLoadingResult)
{
	// Get the loading state to complete
	FAsyncLoadingStringTable AsyncLoadingState;
	{
		FScopeLock AsyncLoadingStringTablesLock(&AsyncLoadingStringTablesCS);
		AsyncLoadingStringTables.RemoveAndCopyValue(InLoadedPackageName, AsyncLoadingState);
	}

	// Calculate the name of the loaded string table based on the package name
	FName LoadedStringTableId;
	if (InLoadingResult == EAsyncLoadingResult::Succeeded)
	{
		check(InLoadedPackage);
		const FString LoadedPackageNameStr = InLoadedPackage->GetName();
		// BEGIN CHANGE BY wuzhiwei05@kuaishou.com
#if 0
		LoadedStringTableId = *FString::Printf(TEXT("%s.%s"), *LoadedPackageNameStr, *FPackageName::GetLongPackageAssetName(LoadedPackageNameStr));
#else
		LoadedStringTableId = *FString::Printf(TEXT("%s.%s_C:KGUI.StringTable"), *LoadedPackageNameStr, *FPackageName::GetLongPackageAssetName(LoadedPackageNameStr));
#endif
		// END CHANGE BY wuzhiwei05@kuaishou.com
	}

	// Notify any listeners of the result
	for (const IStringTableEngineBridge::FLoadStringTableAssetCallback& LoadedCallback : AsyncLoadingState.LoadedCallbacks)
	{
		check(LoadedCallback);
		LoadedCallback(AsyncLoadingState.RequestedTableId, LoadedStringTableId);
	}
}

bool FKGUIModule::OnPreLoadStringTableAsset(const FName InTableId, IStringTableEngineBridge::FLoadStringTableAssetCallback InLoadedCallback, int32& AsyncLoadingId)
{
	if (!InTableId.ToString().EndsWith(TEXT(":KGUI.StringTable")))
	{
		return false;
	}
	AsyncLoadingId = LoadStringTableAssetImpl(InTableId, InLoadedCallback);
	return true;
}

void FKGUIModule::InvalidateAllWidgets(bool bClearResourcesImmediately)
{
	FSlateApplication::Get().InvalidateAllWidgets(bClearResourcesImmediately);
}

void FKGUIModule::RequestDirtyTextRevision()
{
#if 1
	// 正确做法
	FTextLocalizationManager::Get().RequestDirtyTextRevision();
#else
	// 临时做法
	FInternationalization::FCultureStateSnapshot Snapshot;
	FInternationalization& I18N = FInternationalization::Get();
	I18N.BackupCultureState(Snapshot);
	I18N.SetCurrentLanguage(TEXT("it"));
	I18N.RestoreCultureState(Snapshot);
#endif
}

#pragma endregion

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FKGUIModule, KGUI)

static void HandleInvalidateAllWidgets(const TArray<FString>& Args)
{
	if (auto KGUI = FModuleManager::GetModulePtr<FKGUIModule>("KGUI"))
	{
		bool bClearResourcesImmediately = false;
		if (Args.Num() > 1)
		{
			if (Args[0] == TEXT("1"))
			{
				bClearResourcesImmediately = true;
			}
		}
		KGUI->InvalidateAllWidgets(bClearResourcesImmediately);
	}
}

static FAutoConsoleCommand GInvalidateAllWidgets(
	TEXT("KGUI.InvalidateAllWidgets"),
	TEXT("Invalidate All Widgets. Clear Resources Immediately if First Argument is \"1\"."),
	FConsoleCommandWithArgsDelegate::CreateStatic(&HandleInvalidateAllWidgets)
);

static void HandleRequestDirtyTextRevision(const TArray<FString>& Args)
{
	if (auto KGUI = FModuleManager::GetModulePtr<FKGUIModule>("KGUI"))
	{
		KGUI->RequestDirtyTextRevision();
	}
}

static FAutoConsoleCommand GRequestDirtyTextRevision(
	TEXT("KGUI.RequestDirtyTextRevision"),
	TEXT("Request Dirty Text Revision."),
	FConsoleCommandWithArgsDelegate::CreateStatic(&HandleRequestDirtyTextRevision)
);