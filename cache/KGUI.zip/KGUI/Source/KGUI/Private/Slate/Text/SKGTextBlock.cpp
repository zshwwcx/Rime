#include "Slate/Text/SKGTextBlock.h"

SLATE_IMPLEMENT_WIDGET(SKGTextBlock)
void SKGTextBlock::PrivateRegisterAttributes(FSlateAttributeInitializer& AttributeInitializer) {}
