#pragma once

#include "Slate/Text/SKGRichTextBlock.h"
#include "Widgets/SlateGPUTurboWidgets.h"

class SKGGPUTurboRichTextBlock : public SKGRichTextBlock, public FGPUTurboLeafWidget
{
	SLATE_DECLARE_WIDGET(SKGGPUTurboRichTextBlock, SKGRichTextBlock)

public:
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

private:
	int32 GPUPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled);

protected:
	virtual SWidget* GetSWidget() override { return this; }
};