#include "Slate/Text/SKGRichTextBlock.h"

SLATE_IMPLEMENT_WIDGET(SKGRichTextBlock)
void SKGRichTextBlock::PrivateRegisterAttributes(FSlateAttributeInitializer& AttributeInitializer) {}

FVector2D SKGRichTextBlock::ComputeDesiredSize(float LayoutScaleMultiplier) const
{
	if (bDecoratorStyleSetDirty)
	{
		(void) OnRebuildDecoratorStyleSet.ExecuteIfBound();
		bDecoratorStyleSetDirty = false;
	}
	return Super::ComputeDesiredSize(LayoutScaleMultiplier);
}
