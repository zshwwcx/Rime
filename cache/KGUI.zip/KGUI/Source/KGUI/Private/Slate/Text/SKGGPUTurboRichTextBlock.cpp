#include "Slate/Text/SKGGPUTurboRichTextBlock.h"

SLATE_IMPLEMENT_WIDGET(SKGGPUTurboRichTextBlock)
void SKGGPUTurboRichTextBlock::PrivateRegisterAttributes(FSlateAttributeInitializer& AttributeInitializer) {}

int32 SKGGPUTurboRichTextBlock::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	return const_cast<SKGGPUTurboRichTextBlock*>(this)->GPUPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
}

int32 SKGGPUTurboRichTextBlock::GPUPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled)
{
	FPaintArgs NewArgs = Args.WithNewParent(this);
	if (!BeginGPUTurboPaint(NewArgs, AllottedGeometry)) return LayerId;
	NewArgs.GPUTurboPaintArg.SetIsFont(true);
	return SRichTextBlock::OnPaint(NewArgs, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
}