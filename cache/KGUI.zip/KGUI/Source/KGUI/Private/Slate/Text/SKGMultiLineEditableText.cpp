#include "Slate/Text/SKGMultiLineEditableText.h"

FReply SKGMultiLineEditableText::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	auto Reply = Super::OnKeyDown(MyGeometry, InKeyEvent);
	if (Reply.IsEventHandled())
	{
		return Reply;
	}
	return FReply::Handled();
}

FReply SKGMultiLineEditableText::OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	auto Reply = Super::OnKeyUp(MyGeometry, InKeyEvent);
	if (Reply.IsEventHandled())
	{
		return Reply;
	}
	return FReply::Handled();
}

FReply SKGMultiLineEditableText::OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent)
{
	auto Reply = SMultiLineEditableText::OnFocusReceived(MyGeometry, InFocusEvent);
	(void)OnFocusReceivedDelegate.ExecuteIfBound(InFocusEvent);
	return MoveTemp(Reply);
}

void SKGMultiLineEditableText::OnFocusLost(const FFocusEvent& InFocusEvent)
{
	SMultiLineEditableText::OnFocusLost(InFocusEvent);
	(void)OnFocusLostDelegate.ExecuteIfBound(InFocusEvent);
}

#pragma region 回车换行

bool SKGMultiLineEditableText::CanInsertCarriageReturn() const
{
	if (!bCanInsertCarriageReturn)
	{
		return false;
	}
	return Super::CanInsertCarriageReturn();
}

void SKGMultiLineEditableText::SetCanInsertCarriageReturn(bool InbCanInsertCarriageReturn)
{
	bCanInsertCarriageReturn = InbCanInsertCarriageReturn;
}

#pragma endregion

#pragma region 字符限制

void SKGMultiLineEditableText::SetOnIsCharAllowed(const FOnIsCharAllowed& InOnIsCharAllowed)
{
	OnIsCharAllowed = InOnIsCharAllowed;
}

bool SKGMultiLineEditableText::IsCharAllowed(const TCHAR InChar) const
{
	if (!OnIsCharAllowed.IsBound())
	{
		return true;
	}
	return OnIsCharAllowed.Execute(InChar);
}

#pragma endregion