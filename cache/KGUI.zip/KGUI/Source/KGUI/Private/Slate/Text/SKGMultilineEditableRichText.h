#pragma once

#include "Slate/Text/SKGMultiLineEditableText.h"


class SKGMultiLineEditableRichText : public SKGMultiLineEditableText
{
	using Super = SKGMultiLineEditableText;
};
