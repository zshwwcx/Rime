#pragma once

#include "Widgets/SInvalidationPanel.h"

class SKGInvalidationPanel : public SInvalidationPanel
{
public:
	void SetNeedsSlowPath_Public(bool InbNeedsSlowPath)
	{
		this->SetNeedsSlowPath(InbNeedsSlowPath);
	}
};
