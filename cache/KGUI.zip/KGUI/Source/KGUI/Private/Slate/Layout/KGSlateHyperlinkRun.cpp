#include "Slate/Layout/KGSlateHyperlinkRun.h"

#include "Application/SlateApplicationBase.h"
#include "Components/RichTextBlock.h"
#include "Framework/Text/WidgetLayoutBlock.h"
#include "UMG/Components/KGRichTextBlock.h"
#include "Widgets/Input/SRichTextHyperlink.h"

TSharedRef<FKGSlateHyperlinkRun> FKGSlateHyperlinkRun::Create(const FRunInfo& InRunInfo, const TSharedRef<const FString>& InText, const FHyperlinkStyle& InStyle, FOnClick NavigateDelegate, FOnGenerateTooltip InTooltipDelegate, FOnGetTooltipText InTooltipTextDelegate, URichTextBlock* InRichTextBlock)
{
	return MakeShareable(new FKGSlateHyperlinkRun(InRunInfo, InText, InStyle, NavigateDelegate, InTooltipDelegate, InTooltipTextDelegate, InRichTextBlock));
}

TSharedRef<FKGSlateHyperlinkRun> FKGSlateHyperlinkRun::Create(const FRunInfo& InRunInfo, const TSharedRef<const FString>& InText, const FHyperlinkStyle& InStyle, FOnClick NavigateDelegate, FOnGenerateTooltip InTooltipDelegate, FOnGetTooltipText InTooltipTextDelegate, URichTextBlock* InRichTextBlock, const FTextRange& InRange)
{
	return MakeShareable(new FKGSlateHyperlinkRun(InRunInfo, InText, InStyle, NavigateDelegate, InTooltipDelegate, InTooltipTextDelegate, InRichTextBlock, InRange));
}

TSharedRef<IRun> FKGSlateHyperlinkRun::Clone() const
{
	return FKGSlateHyperlinkRun::Create(RunInfo, Text, Style, NavigateDelegate, TooltipDelegate, TooltipTextDelegate, WeakRichTextBlock.Get(), Range);
}

TSharedRef<ILayoutBlock> FKGSlateHyperlinkRun::CreateBlock(int32 StartIndex, int32 EndIndex, FVector2D Size, const FLayoutBlockTextContext& TextContext, const TSharedPtr<IRunRenderer>& Renderer)
{
	float Scale = 1;
	if (FSlateApplicationBase::IsInitialized())
	{
		Scale = FSlateApplicationBase::Get().GetApplicationScale();
	}
	return CreateBlockWithScale(StartIndex, EndIndex, Size, TextContext, Renderer, Scale);
}

TSharedRef<ILayoutBlock> FKGSlateHyperlinkRun::CreateBlockWithScale(int32 StartIndex, int32 EndIndex, FVector2D Size, const FLayoutBlockTextContext& TextContext, const TSharedPtr<IRunRenderer>& Renderer, float InScale)
{
	// Mirror from FSlateHyperlinkRun::CreateBlock

	FText ToolTipText;
	TSharedPtr<IToolTip> ToolTip;

	if (TooltipDelegate.IsBound())
	{
		ToolTip = TooltipDelegate.Execute(RunInfo.MetaData);
	}
	else
	{
		const FString* Url = RunInfo.MetaData.Find(TEXT("href"));
		if (TooltipTextDelegate.IsBound())
		{
			ToolTipText = TooltipTextDelegate.Execute(RunInfo.MetaData);
		}
		else if (Url != nullptr)
		{
			ToolTipText = FText::FromString(*Url);
		}
	}

	auto Widget = SNew(SRichTextHyperlink, ViewModel)
		.Style(&Style)
		.Text(FText::FromString(FString::ConstructFromPtrSize(**Text + StartIndex, EndIndex - StartIndex)))
		.ToolTip(ToolTip)
		.ToolTipText(ToolTipText)
		.OnNavigate(this, &FKGSlateHyperlinkRun::OnNavigate)
		.TextShapingMethod(TextContext.TextShapingMethod);

	if (auto StrongRichTextBlock = Cast<UKGRichTextBlock>(WeakRichTextBlock.Get()))
	{
		Widget->SetClickMethod(StrongRichTextBlock->GetClickMethod());
		Widget->SetTouchMethod(StrongRichTextBlock->GetTouchMethod());
		Widget->SetPressMethod(StrongRichTextBlock->GetPressMethod());
	}

	// We need to do a prepass here as CreateBlock can be called after the main Slate prepass has been run, 
	// which can result in the hyperlink widget not being correctly setup before it is painted
	// BEGIN CHANGE BY wuzhiwei05@kuaishou.com
#if 0
	Widget->SlatePrepass();
#else
	Widget->SlatePrepass(InScale);
#endif
	// END CHANGE BY wuzhiwei05@kuaishou.com

	Children.Add(Widget);

	return FWidgetLayoutBlock::Create(SharedThis(this), Widget, FTextRange(StartIndex, EndIndex), Size, TextContext, Renderer);
}
