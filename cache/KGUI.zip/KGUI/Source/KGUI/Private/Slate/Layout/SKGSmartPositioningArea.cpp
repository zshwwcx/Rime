#include "Slate/Layout/SKGSmartPositioningArea.h"

#include "Framework/Application/SlateApplication.h"
#include "Widgets/SViewport.h"

#include "Slate/SObjectWidget.h"
#include "Slate/Layout/KGRect.h"

SLATE_IMPLEMENT_WIDGET(SKGSmartPositioningArea)

void SKGSmartPositioningArea::PrivateRegisterAttributes(FSlateAttributeInitializer& AttributeInitializer)
{
	SLATE_ADD_MEMBER_ATTRIBUTE_DEFINITION_WITH_NAME(AttributeInitializer, "SlotPadding", ChildSlot.SlotPaddingAttribute, EInvalidateWidgetReason::Layout);
}

SKGSmartPositioningArea::SKGSmartPositioningArea()
	: ChildSlot(this)
	, bIsDesignTime(false)
{
}

void SKGSmartPositioningArea::Construct(const FArguments& InArgs)
{
	bIsDesignTime = InArgs._bIsDesignTime.Get();
	PrimaryOrientation = InArgs._PrimaryOrientation;
	SecondaryAlignment = InArgs._SecondaryAlignment;
	HorizontalPreferredDirection = InArgs._HorizontalPreferredDirection;
	VerticalPreferredDirection = InArgs._VerticalPreferredDirection;
}

void SKGSmartPositioningArea::SetContent(const TSharedRef<SWidget>& InContent)
{
	ChildSlot
	[
		InContent
	];
}

FChildren* SKGSmartPositioningArea::GetChildren()
{
	return &ChildSlot;
}

FVector2D SKGSmartPositioningArea::ComputeDesiredSize(float LayoutScaleMultiplier) const
{
	return FVector2D::ZeroVector;
}

void SKGSmartPositioningArea::OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const
{
	const SWidget* Screen = nullptr;
	if (bIsDesignTime)
	{
		Screen = GetDesignerViewWidget();
	}
	else
	{
		Screen = GetViewportWidget();
	}
	if (Screen == nullptr)
	{
		return;
	}
	auto ChildWidget = ChildSlot.GetWidget();
	const EVisibility ChildVisibility = ChildWidget->GetVisibility();
	if (ArrangedChildren.Accepts(ChildVisibility))
	{
		FVector2D ChildPosition;
		FVector2D LocalChildSize = ChildWidget->GetDesiredSize();

		auto ScreenRect = FKGRect::CreateAbsoluteRectangle(Screen->GetPaintSpaceGeometry());
		auto AreaRect = FKGRect::CreateAbsoluteRectangle(AllottedGeometry);
		FVector2D ChildSize = AllottedGeometry.LocalToAbsolute(LocalChildSize) - AllottedGeometry.LocalToAbsolute(FVector2D::ZeroVector);

		Place<EKGSmartPositioningAreaOrientation::Horizontal>(ScreenRect, AreaRect, ChildSize, PrimaryOrientation.Get(), SecondaryAlignment.Get(), ChildPosition);
		Place<EKGSmartPositioningAreaOrientation::Vertical>(ScreenRect, AreaRect, ChildSize, PrimaryOrientation.Get(), SecondaryAlignment.Get(), ChildPosition);
		FVector2D LocalChildPosition = AllottedGeometry.AbsoluteToLocal(ChildPosition);

		auto LocalAreaRect = FKGRect::CreateLocalRectangle(AllottedGeometry);
		Fill<EKGSmartPositioningAreaOrientation::Horizontal>(LocalAreaRect, LocalChildSize);
		Fill<EKGSmartPositioningAreaOrientation::Vertical>(LocalAreaRect, LocalChildSize);

		ArrangedChildren.AddWidget(
			AllottedGeometry.MakeChild(ChildWidget, LocalChildPosition, LocalChildSize)
		);
	}
}

const SWidget* SKGSmartPositioningArea::GetDesignerViewWidget() const
{
	check(bIsDesignTime);
	const SWidget* Iterator = this;
	const SWidget* DesignerView = nullptr;
	while (true)
	{
		auto TagMetaData = Iterator->GetMetaData<FTagMetaData>();
		if (TagMetaData != nullptr)
		{
			if (TagMetaData->Tag == TEXT("Designer"))
			{
				DesignerView = Iterator;
			}
		}
		auto Parent = Iterator->GetParentWidget().Get();
		if (Parent == nullptr)
		{
			break;
		}
		Iterator = Parent;
	}
	return DesignerView;
}

const SWidget* SKGSmartPositioningArea::GetViewportWidget() const
{
	if (!GameViewport.IsValid())
	{
		GameViewport = FSlateApplication::Get().GetGameViewport().ToWeakPtr();
	}
	return GameViewport.Pin().Get();
}
