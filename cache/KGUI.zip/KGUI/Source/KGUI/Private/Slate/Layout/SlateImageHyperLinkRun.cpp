// Copyright Epic Games, Inc. All Rights Reserved.

#include "Slate/Layout/SlateImageHyperLinkRun.h"

#include "Components/RichTextBlock.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Fonts/FontMeasure.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Text/WidgetLayoutBlock.h"
#include "UMG/Components/KGRichTextBlock.h"

#if WITH_FANCY_TEXT

#include "Slate/Layout/SKGRichTextImageHyperlink.h"
#include "Framework/Text/ShapedTextCache.h"
#include "Framework/Text/RunUtils.h"

TSharedRef< FSlateImageHyperLinkRun > FSlateImageHyperLinkRun::Create( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FHyperlinkStyle& InStyle, FOnClick NavigateDelegate, FOnGenerateTooltip InTooltipDelegate, FOnGetTooltipText InTooltipTextDelegate, const FSlateBrush* InBrush, EVerticalAlignment InImageVerticalAlignment, URichTextBlock* InRichTextBlock, bool InbBrushIsUnderline)
{
	return MakeShareable( new FSlateImageHyperLinkRun( InRunInfo, InText, InStyle, NavigateDelegate, InTooltipDelegate, InTooltipTextDelegate, InBrush, InImageVerticalAlignment, InRichTextBlock, InbBrushIsUnderline) );
}

TSharedRef< FSlateImageHyperLinkRun > FSlateImageHyperLinkRun::Create( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FHyperlinkStyle& InStyle, FOnClick NavigateDelegate, FOnGenerateTooltip InTooltipDelegate, FOnGetTooltipText InTooltipTextDelegate, const FTextRange& InRange, const FSlateBrush* InBrush, EVerticalAlignment InImageVerticalAlignment, URichTextBlock* InRichTextBlock, bool InbBrushIsUnderline)
{
	return MakeShareable( new FSlateImageHyperLinkRun( InRunInfo, InText, InStyle, NavigateDelegate, InTooltipDelegate, InTooltipTextDelegate, InRange, InBrush, InImageVerticalAlignment, InRichTextBlock, InbBrushIsUnderline) );
}

FTextRange FSlateImageHyperLinkRun::GetTextRange() const 
{
	return Range;
}

void FSlateImageHyperLinkRun::SetTextRange( const FTextRange& Value )
{
	Range = Value;
}

int16 FSlateImageHyperLinkRun::GetBaseLine( float Scale ) const 
{
	const TSharedRef< FSlateFontMeasure > FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
	return FontMeasure->GetBaseline( Style.TextStyle.Font, Scale ) - FMath::Min(0.0f, Style.TextStyle.ShadowOffset.Y * Scale);
}

int16 FSlateImageHyperLinkRun::GetMaxHeight( float Scale ) const 
{
	const TSharedRef< FSlateFontMeasure > FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
	return FontMeasure->GetMaxCharacterHeight( Style.TextStyle.Font, Scale ) + FMath::Abs(Style.TextStyle.ShadowOffset.Y * Scale);
}

FVector2D FSlateImageHyperLinkRun::Measure( int32 StartIndex, int32 EndIndex, float Scale, const FRunTextContext& TextContext ) const 
{
	const FVector2D ShadowOffsetToApply((EndIndex == Range.EndIndex) ? FMath::Abs(Style.TextStyle.ShadowOffset.X * Scale) : 0.0f, FMath::Abs(Style.TextStyle.ShadowOffset.Y * Scale));
	//BEGIN CHANGE BY pengwei03@kuaishou.com:修复超链接文本Outline计算遗漏
	const float ScaledOutlineSize = Style.TextStyle.Font.OutlineSettings.OutlineSize * Scale;
	const FVector2D OutlineSizeToApply((StartIndex == Range.BeginIndex ? ScaledOutlineSize : 0) + (EndIndex == Range.EndIndex ? ScaledOutlineSize : 0), ScaledOutlineSize);
	//END CHANGE BY pengwei03@kuaishou.com
	if ( EndIndex - StartIndex == 0 )
	{
		return FVector2D( ShadowOffsetToApply.X * Scale, GetMaxHeight( Scale ) );
	}
	//BEGIN CHANGE BY pengwei03@kuaishou.com:修复超链接文本Outline计算遗漏
	// Use the full text range (rather than the run range) so that text that spans runs will still be shaped correctly
	return ShapedTextCacheUtil::MeasureShapedText(TextContext.ShapedTextCache, FCachedShapedTextKey(FTextRange(0, Text->Len()), Scale, TextContext, Style.TextStyle.Font), FTextRange(StartIndex, EndIndex), **Text) + ShadowOffsetToApply + OutlineSizeToApply;
	//END CHANGE BY pengwei03@kuaishou.com
}

int8 FSlateImageHyperLinkRun::GetKerning( int32 CurrentIndex, float Scale, const FRunTextContext& TextContext ) const 
{
	return 0;
}

TSharedRef<ILayoutBlock> FSlateImageHyperLinkRun::CreateBlock(int32 StartIndex, int32 EndIndex, FVector2D Size, const FLayoutBlockTextContext& TextContext, const TSharedPtr<IRunRenderer>& Renderer)
{
	float Scale = 1;
	if (FSlateApplicationBase::IsInitialized())
	{
		Scale = FSlateApplicationBase::Get().GetApplicationScale();
	}
	return CreateBlockWithScale(StartIndex, EndIndex, Size, TextContext, Renderer, Scale);
}

TSharedRef< ILayoutBlock > FSlateImageHyperLinkRun::CreateBlockWithScale( int32 StartIndex, int32 EndIndex, FVector2D Size, const FLayoutBlockTextContext& TextContext, const TSharedPtr< IRunRenderer >& Renderer, float InScale )
{
	FText ToolTipText;
	TSharedPtr<IToolTip> ToolTip;
	
	if(TooltipDelegate.IsBound())
	{
		ToolTip = TooltipDelegate.Execute(RunInfo.MetaData);
	}
	else
	{
		const FString* Url = RunInfo.MetaData.Find(TEXT("href"));
		if(TooltipTextDelegate.IsBound())
		{
			ToolTipText = TooltipTextDelegate.Execute(RunInfo.MetaData);
		}
		else if(Url != nullptr)
		{
			ToolTipText = FText::FromString(*Url);
		}
	}

	auto RichTextBlock = Cast<UKGRichTextBlock>(WeakRichTextBlock.Get());

	auto LineHeightPercentage = RichTextBlock ? RichTextBlock->GetLineHeightPercentage() : 1.0f;
	FMargin ImagePadding;
	if (bBrushIsUnderline)
	{
		if (Brush)
		{
			ImagePadding.Bottom = (1.0f - LineHeightPercentage) * (Size.Y / InScale) * 0.5 - Brush->GetImageSize().Y * 0.5;
		}
	}

	auto Widget = SNew(SKGRichTextImageHyperlink, Brush, ImageVerticalAlignment, ImagePadding)
		.Style( &Style )
		.Text( FText::FromString( FString( EndIndex - StartIndex, **Text + StartIndex ) ) )
		.ToolTip( ToolTip )
		.ToolTipText( ToolTipText )
		.OnNavigate( this, &FSlateImageHyperLinkRun::OnNavigate )
		.TextShapingMethod( TextContext.TextShapingMethod );

	if (auto StrongRichTextBlock = Cast<UKGRichTextBlock>(WeakRichTextBlock.Get()))
	{
		Widget->SetClickMethod(StrongRichTextBlock->GetClickMethod());
		Widget->SetTouchMethod(StrongRichTextBlock->GetTouchMethod());
		Widget->SetPressMethod(StrongRichTextBlock->GetPressMethod());
	}
	
	// We need to do a prepass here as CreateBlock can be called after the main Slate prepass has been run, 
	// which can result in the hyperlink widget not being correctly setup before it is painted
#if 0
	Widget->SlatePrepass();
#else
	Widget->SlatePrepass(InScale);
#endif

	Children.Add( Widget );

	return FWidgetLayoutBlock::Create( SharedThis( this ), Widget, FTextRange( StartIndex, EndIndex ), Size, TextContext, Renderer );
}

void FSlateImageHyperLinkRun::OnNavigate()
{
	NavigateDelegate.Execute( RunInfo.MetaData );
}

int32 FSlateImageHyperLinkRun::OnPaint(const FPaintArgs& PaintArgs, const FTextArgs& TextArgs, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	const TSharedRef< FWidgetLayoutBlock > WidgetBlock = StaticCastSharedRef< FWidgetLayoutBlock >(TextArgs.Block);
	// The block size and offset values are pre-scaled, so we need to account for that when converting the block offsets into paint geometry
	const float InverseScale = Inverse(AllottedGeometry.Scale);

	//@C7 CODE - BEGIN ADD BY pengwei03@kuaishou.com:文本两端对齐
	if (TextArgs.Line.JustifyAlign)
	{
		TSharedPtr<SWidget> RichHyperLinkWidget = WidgetBlock->GetWidget();
		if (TSharedPtr <SKGRichTextImageHyperlink> RichHyperLink = StaticCastSharedPtr<SKGRichTextImageHyperlink>(RichHyperLinkWidget))
		{
			if (TSharedPtr<STextBlock> HyperLinkText = StaticCastSharedPtr<STextBlock>(RichHyperLink->GetHyperLinkTextBlock()))
			{
				const TArray<FTextLayout::FLineView>& NewLineViews = HyperLinkText->GetLayoutLineView();
				for (int index = 0; index < NewLineViews.Num(); index++)
				{
					for (int BlockIndex = 0; BlockIndex < NewLineViews[index].Blocks.Num(); BlockIndex++)
					{
						const float JustifyWidth = TextArgs.Block->GetModifySize().X;
						const float PreviousBlockJustifyWidth = TextArgs.Block->GetModifyOffset().X;
						const_cast<FTextLayout::FLineView&>(NewLineViews[index]).Blocks[BlockIndex]->SetModifySize(FVector2D(JustifyWidth, 0.0f));
						const_cast<FTextLayout::FLineView&>(NewLineViews[index]).Blocks[BlockIndex]->SetModifyOffset(FVector2D(PreviousBlockJustifyWidth, 0.0f));
						const_cast<FTextLayout::FLineView&>(NewLineViews[index]).JustifyAlign = true;
						const_cast<FTextLayout::FLineView&>(NewLineViews[index]).ModifyWidth = 0;
					}
				}
			}
		}
	}
	//@C7 CODE - END ADD BY pengwei03@kuaishou.com
	const FGeometry WidgetGeometry = AllottedGeometry.MakeChild(TransformVector(InverseScale, TextArgs.Block->GetSize()), FSlateLayoutTransform(TransformPoint(InverseScale, TextArgs.Block->GetLocationOffset())));
	return WidgetBlock->GetWidget()->Paint(PaintArgs, WidgetGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
}

const TArray< TSharedRef<SWidget> >& FSlateImageHyperLinkRun::GetChildren()
{
	return Children;
}

void FSlateImageHyperLinkRun::ArrangeChildren( const TSharedRef< ILayoutBlock >& Block, const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren ) const 
{
	const TSharedRef< FWidgetLayoutBlock > WidgetBlock = StaticCastSharedRef< FWidgetLayoutBlock >( Block );
	
	// The block size and offset values are pre-scaled, so we need to account for that when converting the block offsets into paint geometry
	const float InverseScale = Inverse(AllottedGeometry.Scale);

	ArrangedChildren.AddWidget(
		AllottedGeometry.MakeChild(WidgetBlock->GetWidget(), TransformVector(InverseScale, Block->GetSize()), FSlateLayoutTransform(TransformPoint(InverseScale, Block->GetLocationOffset())))
		);
}

int32 FSlateImageHyperLinkRun::GetTextIndexAt( const TSharedRef< ILayoutBlock >& Block, const FVector2D& Location, float Scale, ETextHitPoint* const OutHitPoint ) const
{
	const FVector2D& BlockOffset = Block->GetLocationOffset();
	const FVector2D& BlockSize = Block->GetSize();

	const float Left = BlockOffset.X;
	const float Top = BlockOffset.Y;
	const float Right = BlockOffset.X + BlockSize.X;
	const float Bottom = BlockOffset.Y + BlockSize.Y;

	const bool ContainsPoint = Location.X >= Left && Location.X < Right && Location.Y >= Top && Location.Y < Bottom;

	if ( !ContainsPoint )
	{
		return INDEX_NONE;
	}

	const FTextRange BlockRange = Block->GetTextRange();
	const FLayoutBlockTextContext BlockTextContext = Block->GetTextContext();

	// Use the full text range (rather than the run range) so that text that spans runs will still be shaped correctly
	const int32 Index = ShapedTextCacheUtil::FindCharacterIndexAtOffset(BlockTextContext.ShapedTextCache, FCachedShapedTextKey(FTextRange(0, Text->Len()), Scale, BlockTextContext, Style.TextStyle.Font), BlockRange, **Text, Location.X - BlockOffset.X);
	if (OutHitPoint)
	{
		*OutHitPoint = RunUtils::CalculateTextHitPoint(Index, BlockRange, BlockTextContext.TextDirection);
	}

	return Index;
}

FVector2D FSlateImageHyperLinkRun::GetLocationAt( const TSharedRef< ILayoutBlock >& Block, int32 Offset, float Scale ) const
{
	const FVector2D& BlockOffset = Block->GetLocationOffset();
	const FTextRange& BlockRange = Block->GetTextRange();
	const FLayoutBlockTextContext BlockTextContext = Block->GetTextContext();

	// Use the full text range (rather than the run range) so that text that spans runs will still be shaped correctly
	const FTextRange RangeToMeasure = RunUtils::CalculateOffsetMeasureRange(Offset, BlockRange, BlockTextContext.TextDirection);
	const FVector2D OffsetLocation = ShapedTextCacheUtil::MeasureShapedText(BlockTextContext.ShapedTextCache, FCachedShapedTextKey(FTextRange(0, Text->Len()), Scale, BlockTextContext, Style.TextStyle.Font), RangeToMeasure, **Text);

	return BlockOffset + OffsetLocation;
}

void FSlateImageHyperLinkRun::Move(const TSharedRef<FString>& NewText, const FTextRange& NewRange)
{
	Text = NewText;
	Range = NewRange;
}

TSharedRef<IRun> FSlateImageHyperLinkRun::Clone() const
{
	return FSlateImageHyperLinkRun::Create(RunInfo, Text, Style, NavigateDelegate, TooltipDelegate, TooltipTextDelegate, Range, Brush, ImageVerticalAlignment, WeakRichTextBlock.Get(), bBrushIsUnderline);
}

void FSlateImageHyperLinkRun::AppendTextTo(FString& AppendToText) const
{
	AppendToText.Append(**Text + Range.BeginIndex, Range.Len());
}

void FSlateImageHyperLinkRun::AppendTextTo(FString& AppendToText, const FTextRange& PartialRange) const
{
	check(Range.BeginIndex <= PartialRange.BeginIndex);
	check(Range.EndIndex >= PartialRange.EndIndex);

	AppendToText.Append(**Text + PartialRange.BeginIndex, PartialRange.Len());
}

const FRunInfo& FSlateImageHyperLinkRun::GetRunInfo() const
{
	return RunInfo;
}

ERunAttributes FSlateImageHyperLinkRun::GetRunAttributes() const
{
	return ERunAttributes::SupportsText;
}

FSlateImageHyperLinkRun::FSlateImageHyperLinkRun( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FHyperlinkStyle& InStyle, FOnClick InNavigateDelegate, FOnGenerateTooltip InTooltipDelegate, FOnGetTooltipText InTooltipTextDelegate, const FSlateBrush* InBrush, EVerticalAlignment InImageVerticalAlignment, URichTextBlock* InRichTextBlock, bool InbBrushIsUnderline)
	: RunInfo( InRunInfo )
	, Text( InText )
	, Range( 0, Text->Len() )
	, Style( InStyle )
	, NavigateDelegate( InNavigateDelegate )
	, TooltipDelegate( InTooltipDelegate )
	, TooltipTextDelegate( InTooltipTextDelegate )
	//, ViewModel( MakeShareable( new FSlateHyperlinkRun::FWidgetViewModel() ) )
	, Brush(InBrush)
	, ImageVerticalAlignment(InImageVerticalAlignment)
	, Children()
	, WeakRichTextBlock (InRichTextBlock)
	, bBrushIsUnderline(InbBrushIsUnderline)
{

}

FSlateImageHyperLinkRun::FSlateImageHyperLinkRun( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FHyperlinkStyle& InStyle, FOnClick InNavigateDelegate, FOnGenerateTooltip InTooltipDelegate, FOnGetTooltipText InTooltipTextDelegate, const FTextRange& InRange, const FSlateBrush* InBrush, EVerticalAlignment InImageVerticalAlignment, URichTextBlock* InRichTextBlock, bool InbBrushIsUnderline)
	: RunInfo( InRunInfo )
	, Text( InText )
	, Range( InRange )
	, Style( InStyle )
	, NavigateDelegate( InNavigateDelegate )
	, TooltipDelegate( InTooltipDelegate )
	, TooltipTextDelegate( InTooltipTextDelegate )
	//, ViewModel( MakeShareable( new FSlateHyperlinkRun::FWidgetViewModel() ) )
	, Brush(InBrush)
	, ImageVerticalAlignment(InImageVerticalAlignment)
	, Children()
	, WeakRichTextBlock(InRichTextBlock)
	, bBrushIsUnderline(InbBrushIsUnderline)
{

}

FSlateImageHyperLinkRun::FSlateImageHyperLinkRun( const FSlateImageHyperLinkRun& Run ) 
	: RunInfo( Run.RunInfo )
	, Text( Run.Text )
	, Range( Run.Range )
	, Style( Run.Style )
	, NavigateDelegate( Run.NavigateDelegate )
	, TooltipDelegate( Run.TooltipDelegate )
	, TooltipTextDelegate( Run.TooltipTextDelegate )
	//, ViewModel( MakeShareable( new FSlateHyperlinkRun::FWidgetViewModel() ) )
	, Brush(Run.Brush)
	, ImageVerticalAlignment(Run.ImageVerticalAlignment)
	, Children()
	, WeakRichTextBlock(Run.WeakRichTextBlock)
	, bBrushIsUnderline(Run.bBrushIsUnderline)
{

}



#endif //WITH_FANCY_TEXT
