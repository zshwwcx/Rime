// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: tangshenghao@kuaishou.com

#include "Slate/Layout/SPolygon.h"
#include "SlateOptMacros.h"
#include "Framework/Application/SlateApplication.h"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void SPolygon::Construct(const FArguments& InArgs)
{
	Brush = FInvalidatableBrushAttribute(InArgs._Brush);
	PolygonPoints = InArgs._PolygonPoints;
	LineColor = InArgs._LineColor;
	FillColor = InArgs._FillColor;
}
END_SLATE_FUNCTION_BUILD_OPTIMIZATION

int32 SPolygon::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect,
	FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle,
	bool bParentEnabled) const
{
	if (PolygonPoints.Num() <= 0)
		return LayerId;
	const FVector2D Pos = AllottedGeometry.GetAbsolutePosition();
	const FVector2D Size = AllottedGeometry.GetLocalSize();
	const FVector2D Center = 0.5f * Size;

	TArray<FVector2D> LinePoints;
	TArray<FVector2D> AreaPoints;
	LinePoints.Empty();
	AreaPoints.Empty();
	AreaPoints.Add(Center);
	for (const FVector2D p : PolygonPoints) {
		LinePoints.Add(p+Center);
		AreaPoints.Add(p+Center);
	}
	LinePoints.Add(PolygonPoints[0]+Center);

	FSlateDrawElement::MakeLines(
		OutDrawElements,
		LayerId++,
		AllottedGeometry.ToPaintGeometry(),
		LinePoints,
		ESlateDrawEffect::None,
		LineColor,
		true,
		2.0f
	);

	TArray < FSlateVertex> Vertices;
	TArray<SlateIndex> Indices;

	const FSlateBrush* SlateBrush = Brush.GetImage().Get();
	FLinearColor LinearColor = FillColor;//ColorAndOpacity.Get() * InWidgetStyle.GetColorAndOpacityTint() * SlateBrush->GetTint(InWidgetStyle);
	FColor FinalColorAndOpacity = LinearColor.ToFColor(true);

	const FSlateRenderTransform& RTrans = AllottedGeometry.GetAccumulatedRenderTransform();
	for (int i = 0; i < AreaPoints.Num(); i++) {
		/*Vertices.AddZeroed();
		FSlateVertex& OuterVert = Vertices.Last();
		OuterVert.Position = FVector2f(AreaPoints[i]);
		OuterVert.Color = FinalColorAndOpacity;*/
		Vertices.Add(FSlateVertex::Make<ESlateVertexRounding::Disabled>(RTrans, FVector2f(AreaPoints[i]), FVector2f(0, 0), FinalColorAndOpacity));
	}
	for (int i = 1; i < AreaPoints.Num(); i++) {
		Indices.Add(0);
		Indices.Add(i);
		if (i == AreaPoints.Num()-1) {
			Indices.Add(1);
		}
		else {
			Indices.Add(i + 1);
		}
	}

	const FSlateResourceHandle Handle = FSlateApplication::Get().GetRenderer()->GetResourceHandle(*SlateBrush);
	FSlateDrawElement::MakeCustomVerts(
		OutDrawElements,
		LayerId++,
		Handle,
		Vertices,
		Indices,
		nullptr,
		0,
		0
	);


	return LayerId;
}

void SPolygon::SetBrush(FSlateBrush* InBrush)
{
	Brush.SetImage(*this, InBrush);
}

void SPolygon::SetPoints(TArray<FVector2D> InPolygonPoints) {
	PolygonPoints.Empty();
	for (const FVector2D p : InPolygonPoints) {
		PolygonPoints.Add(p);
	}
}