#include "Slate/Layout/SKGRotateBox.h"

void SKGRotateBox::Construct(const SKGRotateBox::FArguments& InArgs)
{
	Type = InArgs._Type;
	ScrollHintScrollAxisOffset = InArgs._ScrollHintScrollAxisOffset;
	ScrollHintLineAxisPercentOffset = InArgs._ScrollHintLineAxisPercentOffset;
	ChildSlot
	[
		InArgs._Content.Widget
	];
	this->SetVisibility(EVisibility::SelfHitTestInvisible);
}

int32 SKGRotateBox::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	float Angle = 0;
	auto ParentSize = AllottedGeometry.GetLocalSize();
	FVector2D CachedDesiredSize = this->GetDesiredSize();
	FVector2D Translation = ParentSize * 0.5;
	FVector2D Size;
	switch (Type)
	{
	case EType::NoRotate:
		Translation += FVector2D(
			-ParentSize.X * 0.5 + (ScrollHintLineAxisPercentOffset - 0.5) * ParentSize.X,
			-ParentSize.Y * 0.5 + ScrollHintScrollAxisOffset
		);
		Angle = 0;
		Size = FVector2D(ParentSize.X, CachedDesiredSize.Y);
		break;
	case EType::Rotate90:
		Translation += FVector2D(
			+ParentSize.X * 0.5 - ParentSize.Y * 0.5 - CachedDesiredSize.Y * 0.5 - ScrollHintScrollAxisOffset,
			-CachedDesiredSize.Y * 0.5 + (ScrollHintLineAxisPercentOffset - 0.5) * ParentSize.Y
		);
		Angle = 90;
		Size = FVector2D(ParentSize.Y, CachedDesiredSize.Y);
		break;
	case EType::Rotate180:
		Translation += FVector2D(
			-ParentSize.X * 0.5 + (ScrollHintLineAxisPercentOffset - 0.5) * ParentSize.X,
			+ParentSize.Y * 0.5 - ScrollHintScrollAxisOffset - CachedDesiredSize.Y
		);
		Angle = 180;
		Size = FVector2D(ParentSize.X, CachedDesiredSize.Y);
		break;
	case EType::Rotate270:
		Translation += FVector2D(
			-ParentSize.X * 0.5 - ParentSize.Y * 0.5 + CachedDesiredSize.Y * 0.5 + ScrollHintScrollAxisOffset,
			-CachedDesiredSize.Y * 0.5 + (ScrollHintLineAxisPercentOffset - 0.5) * ParentSize.Y
		);
		Angle = 270;
		Size = FVector2D(ParentSize.Y, CachedDesiredSize.Y);
		break;
	}
	FSlateRenderTransform RotateTransform = FSlateRenderTransform(FQuat2D(FMath::DegreesToRadians(Angle)), Translation);
	auto NewAllottedGeometry = AllottedGeometry.MakeChild(Size, FSlateLayoutTransform(), RotateTransform, FVector2D(0.5, 0.5));
	return Super::OnPaint(Args, NewAllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
}