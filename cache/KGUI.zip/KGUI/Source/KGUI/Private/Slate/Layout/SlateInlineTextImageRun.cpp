// Copyright Epic Games, Inc. All Rights Reserved.

#include "Slate/Layout/SlateInlineTextImageRun.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Fonts/FontMeasure.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Text/WidgetLayoutBlock.h"

#if WITH_FANCY_TEXT

#include "Slate/Layout/SKGRichInlineTextImage.h"
#include "Framework/Text/ShapedTextCache.h"
#include "Framework/Text/RunUtils.h"

TSharedRef< FSlateInlineTextImageRun > FSlateInlineTextImageRun::Create( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FTextBlockStyle& InStyle, const FSlateBrush* InBrush, const EVerticalAlignment InImageVerticalAlignment)
{
	return MakeShareable( new FSlateInlineTextImageRun( InRunInfo, InText, InStyle, InBrush, InImageVerticalAlignment) );
}

TSharedRef< FSlateInlineTextImageRun > FSlateInlineTextImageRun::Create( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FTextBlockStyle& InStyle, const FTextRange& InRange, const FSlateBrush* InBrush, const EVerticalAlignment InImageVerticalAlignment)
{
	return MakeShareable( new FSlateInlineTextImageRun( InRunInfo, InText, InStyle, InRange, InBrush, InImageVerticalAlignment) );
}

FTextRange FSlateInlineTextImageRun::GetTextRange() const
{
	return Range;
}

void FSlateInlineTextImageRun::SetTextRange( const FTextRange& Value )
{
	Range = Value;
}

int16 FSlateInlineTextImageRun::GetBaseLine( float Scale ) const
{
	const TSharedRef< FSlateFontMeasure > FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
	return FontMeasure->GetBaseline( Style.Font, Scale ) - FMath::Min(0.0f, Style.ShadowOffset.Y * Scale);
}

int16 FSlateInlineTextImageRun::GetMaxHeight( float Scale ) const
{
	const TSharedRef< FSlateFontMeasure > FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
	return FontMeasure->GetMaxCharacterHeight( Style.Font, Scale ) + FMath::Abs(Style.ShadowOffset.Y * Scale);
}

FVector2D FSlateInlineTextImageRun::Measure( int32 StartIndex, int32 EndIndex, float Scale, const FRunTextContext& TextContext ) const
{
	const FVector2D ShadowOffsetToApply((EndIndex == Range.EndIndex) ? FMath::Abs(Style.ShadowOffset.X * Scale) : 0.0f, FMath::Abs(Style.ShadowOffset.Y * Scale));
	//BEGIN CHANGE BY pengwei03@kuaishou.com:修复超链接文本Outline计算遗漏
	const float ScaledOutlineSize = Style.Font.OutlineSettings.OutlineSize * Scale;
	const FVector2D OutlineSizeToApply((StartIndex == Range.BeginIndex ? ScaledOutlineSize : 0) + (EndIndex == Range.EndIndex ? ScaledOutlineSize : 0), ScaledOutlineSize);
	//END CHANGE BY pengwei03@kuaishou.com
	if ( EndIndex - StartIndex == 0 )
	{
		return FVector2D( ShadowOffsetToApply.X * Scale, GetMaxHeight( Scale ) );
	}
	//BEGIN CHANGE BY pengwei03@kuaishou.com:修复超链接文本Outline计算遗漏
	// Use the full text range (rather than the run range) so that text that spans runs will still be shaped correctly
	return ShapedTextCacheUtil::MeasureShapedText(TextContext.ShapedTextCache, FCachedShapedTextKey(FTextRange(0, Text->Len()), Scale, TextContext, Style.Font), FTextRange(StartIndex, EndIndex), **Text) + ShadowOffsetToApply + OutlineSizeToApply;
	//END CHANGE BY pengwei03@kuaishou.com
}

int8 FSlateInlineTextImageRun::GetKerning( int32 CurrentIndex, float Scale, const FRunTextContext& TextContext ) const
{
	return 0;
}

TSharedRef< ILayoutBlock > FSlateInlineTextImageRun::CreateBlock( int32 StartIndex, int32 EndIndex, FVector2D Size, const FLayoutBlockTextContext& TextContext, const TSharedPtr< IRunRenderer >& Renderer )
{
	
	TSharedRef< SWidget > Widget = SNew(SKGRichInlineTextImage, Brush, ImageVerticalAlignment)
		.Text(FText::FromString(FString(EndIndex - StartIndex, **Text + StartIndex)))
		.TextStyle(&Style);
	
	// We need to do a prepass here as CreateBlock can be called after the main Slate prepass has been run, 
	// which can result in the hyperlink widget not being correctly setup before it is painted
	Widget->SlatePrepass();

	Children.Add( Widget );

	return FWidgetLayoutBlock::Create( SharedThis( this ), Widget, FTextRange( StartIndex, EndIndex ), Size, TextContext, Renderer );
}

int32 FSlateInlineTextImageRun::OnPaint(const FPaintArgs& PaintArgs, const FTextArgs& TextArgs, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	const TSharedRef< FWidgetLayoutBlock > WidgetBlock = StaticCastSharedRef< FWidgetLayoutBlock >(TextArgs.Block);
	// The block size and offset values are pre-scaled, so we need to account for that when converting the block offsets into paint geometry
	const float InverseScale = Inverse(AllottedGeometry.Scale);
	const float textWidth = TransformVector(InverseScale, TextArgs.Block->GetSize()).X;
	TSharedPtr<SWidget> InlineTextImageWidget = WidgetBlock->GetWidget();
	if (TextArgs.Line.JustifyAlign)
	{
		TSharedPtr<SWidget> RichHyperLinkWidget = WidgetBlock->GetWidget();
		if (TSharedPtr <SKGRichInlineTextImage> RichHyperLink = StaticCastSharedPtr<SKGRichInlineTextImage>(RichHyperLinkWidget))
		{
			if (TSharedPtr<STextBlock> HyperLinkText = StaticCastSharedPtr<STextBlock>(RichHyperLink->GetImageTextBlock()))
			{
				const TArray<FTextLayout::FLineView>& NewLineViews = HyperLinkText->GetLayoutLineView();
				for (int index = 0; index < NewLineViews.Num(); index++)
				{
					for (int BlockIndex = 0; BlockIndex < NewLineViews[index].Blocks.Num(); BlockIndex++)
					{
						const float JustifyWidth = TextArgs.Block->GetModifySize().X;
						const float PreviousBlockJustifyWidth = TextArgs.Block->GetModifyOffset().X;
						const_cast<FTextLayout::FLineView&>(NewLineViews[index]).Blocks[BlockIndex]->SetModifySize(FVector2D(JustifyWidth, 0.0f));
						const_cast<FTextLayout::FLineView&>(NewLineViews[index]).Blocks[BlockIndex]->SetModifyOffset(FVector2D(PreviousBlockJustifyWidth, 0.0f));
						const_cast<FTextLayout::FLineView&>(NewLineViews[index]).JustifyAlign = true;
						const_cast<FTextLayout::FLineView&>(NewLineViews[index]).ModifyWidth = 0;
					}
				}
			}
		}
	}
	
	const FGeometry WidgetGeometry = AllottedGeometry.MakeChild(TransformVector(InverseScale, TextArgs.Block->GetSize()), FSlateLayoutTransform(TransformPoint(InverseScale, TextArgs.Block->GetLocationOffset())));
	return WidgetBlock->GetWidget()->Paint(PaintArgs, WidgetGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
}

const TArray< TSharedRef<SWidget> >& FSlateInlineTextImageRun::GetChildren()
{
	return Children;
}

void FSlateInlineTextImageRun::ArrangeChildren( const TSharedRef< ILayoutBlock >& Block, const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren ) const
{
	const TSharedRef< FWidgetLayoutBlock > WidgetBlock = StaticCastSharedRef< FWidgetLayoutBlock >( Block );
	
	// The block size and offset values are pre-scaled, so we need to account for that when converting the block offsets into paint geometry
	const float InverseScale = Inverse(AllottedGeometry.Scale);

	ArrangedChildren.AddWidget(
		AllottedGeometry.MakeChild(WidgetBlock->GetWidget(), TransformVector(InverseScale, Block->GetSize()), FSlateLayoutTransform(TransformPoint(InverseScale, Block->GetLocationOffset())))
		);
}

int32 FSlateInlineTextImageRun::GetTextIndexAt( const TSharedRef< ILayoutBlock >& Block, const FVector2D& Location, float Scale, ETextHitPoint* const OutHitPoint ) const
{
	const FVector2D& BlockOffset = Block->GetLocationOffset();
	const FVector2D& BlockSize = Block->GetSize();

	const float Left = BlockOffset.X;
	const float Top = BlockOffset.Y;
	const float Right = BlockOffset.X + BlockSize.X;
	const float Bottom = BlockOffset.Y + BlockSize.Y;

	const bool ContainsPoint = Location.X >= Left && Location.X < Right && Location.Y >= Top && Location.Y < Bottom;

	if ( !ContainsPoint )
	{
		return INDEX_NONE;
	}

	const FTextRange BlockRange = Block->GetTextRange();
	const FLayoutBlockTextContext BlockTextContext = Block->GetTextContext();

	// Use the full text range (rather than the run range) so that text that spans runs will still be shaped correctly
	const int32 Index = ShapedTextCacheUtil::FindCharacterIndexAtOffset(BlockTextContext.ShapedTextCache, FCachedShapedTextKey(FTextRange(0, Text->Len()), Scale, BlockTextContext, Style.Font), BlockRange, **Text, Location.X - BlockOffset.X);
	if (OutHitPoint)
	{
		*OutHitPoint = RunUtils::CalculateTextHitPoint(Index, BlockRange, BlockTextContext.TextDirection);
	}

	return Index;
}

FVector2D FSlateInlineTextImageRun::GetLocationAt( const TSharedRef< ILayoutBlock >& Block, int32 Offset, float Scale ) const
{
	const FVector2D& BlockOffset = Block->GetLocationOffset();
	const FTextRange& BlockRange = Block->GetTextRange();
	const FLayoutBlockTextContext BlockTextContext = Block->GetTextContext();

	// Use the full text range (rather than the run range) so that text that spans runs will still be shaped correctly
	const FTextRange RangeToMeasure = RunUtils::CalculateOffsetMeasureRange(Offset, BlockRange, BlockTextContext.TextDirection);
	const FVector2D OffsetLocation = ShapedTextCacheUtil::MeasureShapedText(BlockTextContext.ShapedTextCache, FCachedShapedTextKey(FTextRange(0, Text->Len()), Scale, BlockTextContext, Style.Font), RangeToMeasure, **Text);

	return BlockOffset + OffsetLocation;
}

void FSlateInlineTextImageRun::Move(const TSharedRef<FString>& NewText, const FTextRange& NewRange)
{
	Text = NewText;
	Range = NewRange;
}

TSharedRef<IRun> FSlateInlineTextImageRun::Clone() const
{
	return FSlateInlineTextImageRun::Create(RunInfo, Text, Style, Range, Brush, ImageVerticalAlignment);
}

void FSlateInlineTextImageRun::AppendTextTo(FString& AppendToText) const
{
	AppendToText.Append(**Text + Range.BeginIndex, Range.Len());
}

void FSlateInlineTextImageRun::AppendTextTo(FString& AppendToText, const FTextRange& PartialRange) const
{
	check(Range.BeginIndex <= PartialRange.BeginIndex);
	check(Range.EndIndex >= PartialRange.EndIndex);

	AppendToText.Append(**Text + PartialRange.BeginIndex, PartialRange.Len());
}

const FRunInfo& FSlateInlineTextImageRun::GetRunInfo() const
{
	return RunInfo;
}

ERunAttributes FSlateInlineTextImageRun::GetRunAttributes() const
{
	return ERunAttributes::SupportsText;
}

FSlateInlineTextImageRun::FSlateInlineTextImageRun( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FTextBlockStyle& InStyle, const FSlateBrush* InBrush, const EVerticalAlignment InImageVerticalAlignment)
	: RunInfo( InRunInfo )
	, Text( InText )
	, Range( 0, Text->Len() )
	, Style( InStyle )
	, Brush(InBrush)
	, Children()
	, ImageVerticalAlignment(InImageVerticalAlignment)
{

}

FSlateInlineTextImageRun::FSlateInlineTextImageRun( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FTextBlockStyle& InStyle, const FTextRange& InRange, const FSlateBrush* InBrush, const EVerticalAlignment InImageVerticalAlignment)
	: RunInfo( InRunInfo )
	, Text( InText )
	, Range( InRange )
	, Style( InStyle )
	, Brush(InBrush)
	, Children()
	, ImageVerticalAlignment(InImageVerticalAlignment)
{

}

FSlateInlineTextImageRun::FSlateInlineTextImageRun( const FSlateInlineTextImageRun& Run )
	: RunInfo( Run.RunInfo )
	, Text( Run.Text )
	, Range( Run.Range )
	, Style( Run.Style )
	, Brush(Run.Brush)
	, Children()
	, ImageVerticalAlignment(Run.ImageVerticalAlignment)
{

}



#endif //WITH_FANCY_TEXT
