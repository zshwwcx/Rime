#include "Slate/Layout/KGRect.h"

#include "Layout/Geometry.h"

FKGRect FKGRect::CreateAbsoluteRectangle(const FGeometry& Geometry)
{
	FKGRect Rectangle;
	Rectangle.Min = Geometry.GetAbsolutePositionAtCoordinates(FVector2D::ZeroVector);
	Rectangle.Max = Geometry.GetAbsolutePositionAtCoordinates(FVector2D::One());
	return MoveTemp(Rectangle);
}

FKGRect FKGRect::CreateLocalRectangle(const FGeometry& Geometry)
{
	FKGRect Rectangle;
	Rectangle.Min = Geometry.GetLocalPositionAtCoordinates(FVector2D::ZeroVector);
	Rectangle.Max = Geometry.GetLocalPositionAtCoordinates(FVector2D::One());
	return MoveTemp(Rectangle);
}
