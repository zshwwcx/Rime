#include "Slate/Layout/SKGScrollBox.h"

#include "SlateOptMacros.h"

void SKGScrollBox::Construct(const FArguments& InArgs)
{
	Super::Construct(InArgs);
	CachedDistanceFromTop = ScrollBar->DistanceFromTop();
	CachedDistanceFromBottom = ScrollBar->DistanceFromBottom();
}

void SKGScrollBox::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SScrollBox::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
	auto DistanceFromTop = ScrollBar->DistanceFromTop();
	if (CachedDistanceFromTop != DistanceFromTop)
	{
		CachedDistanceFromTop = DistanceFromTop;
		(void)OnDistanceFromTopChanged.ExecuteIfBound(DistanceFromTop);
	}
	auto DistanceFromBottom = ScrollBar->DistanceFromBottom();
	if (CachedDistanceFromBottom != DistanceFromBottom)
	{
		CachedDistanceFromBottom = DistanceFromBottom;
		(void)OnDistanceFromBottomChanged.ExecuteIfBound(DistanceFromBottom);
	}
}

FReply SKGScrollBox::OnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	SScrollBox::OnMouseWheel(MyGeometry, MouseEvent);
	return FReply::Handled();
}

void SKGScrollBox::SetOnDistanceFromTopChanged(FOnDistanceChanged&& InOnDistanceFromTopChanged)
{
	OnDistanceFromTopChanged = InOnDistanceFromTopChanged;
}

void SKGScrollBox::SetOnDistanceFromBottomChanged(FOnDistanceChanged&& InOnDistanceFromBottomChanged)
{
	OnDistanceFromBottomChanged = InOnDistanceFromBottomChanged;
}
