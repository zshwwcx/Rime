#include "Slate/Components/SKGSlider.h"

#include "KGUISettings.h"

bool SKGSlider::SupportsKeyboardFocus() const
{
#if WITH_EDITOR
	const bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#else
	const static bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#endif
	if (bDisableFocusableGlobally)
	{
		return false;
	}

	return Super::SupportsKeyboardFocus();
}
