#include "Slate/Components/SKGCheckBox.h"

#include "KGUISettings.h"
#include "Layout/WidgetPath.h"
#include "Framework/Application/MenuStack.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Layout/SBorder.h"


void SKGCheckBox::Construct(const SKGCheckBox::FArguments& InArgs)
{
	check(InArgs._Style != nullptr);
	Style = InArgs._Style;

	UncheckedImage = InArgs._UncheckedImage;
	UncheckedHoveredImage = InArgs._UncheckedHoveredImage;
	UncheckedPressedImage = InArgs._UncheckedPressedImage;

	CheckedImage = InArgs._CheckedImage;
	CheckedHoveredImage = InArgs._CheckedHoveredImage;
	CheckedPressedImage = InArgs._CheckedPressedImage;

	UndeterminedImage = InArgs._UndeterminedImage;
	UndeterminedHoveredImage = InArgs._UndeterminedHoveredImage;
	UndeterminedPressedImage = InArgs._UndeterminedPressedImage;

	BackgroundImage = InArgs._BackgroundImage;
	BackgroundHoveredImage = InArgs._BackgroundHoveredImage;
	BackgroundPressedImage = InArgs._BackgroundPressedImage;

	PaddingOverride = InArgs._Padding;
	ForegroundColorOverride = InArgs._ForegroundColor;
	BorderBackgroundColorOverride = InArgs._BorderBackgroundColor;
	CheckBoxTypeOverride = InArgs._Type;

	HorizontalAlignment = InArgs._HAlign;
	bCheckBoxContentUsesAutoWidth = InArgs._CheckBoxContentUsesAutoWidth;

	bIsPressed = false;
	bIsFocusable = InArgs._IsFocusable;

	BuildCheckBox(InArgs._Content.Widget);

	IsCheckboxChecked = InArgs._IsChecked;
	OnCheckStateChanged = InArgs._OnCheckStateChanged;

	ClickMethod = InArgs._ClickMethod;
	TouchMethod = InArgs._TouchMethod;
	PressMethod = InArgs._PressMethod;

	OnGetMenuContent = InArgs._OnGetMenuContent;

	HoveredSound = InArgs._HoveredSoundOverride.Get(InArgs._Style->HoveredSlateSound);
	CheckedSound = InArgs._CheckedSoundOverride.Get(InArgs._Style->CheckedSlateSound);
	UncheckedSound = InArgs._UncheckedSoundOverride.Get(InArgs._Style->UncheckedSlateSound);

	OnPressed = InArgs._OnPressed;
	OnReleased = InArgs._OnReleased;
	OnHovered = InArgs._OnHovered;
	OnUnhovered = InArgs._OnUnhovered;
}

FReply SKGCheckBox::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		Press();

		EButtonClickMethod::Type InputClickMethod = GetClickMethodFromInputType(MouseEvent);

		if (InputClickMethod == EButtonClickMethod::MouseDown)
		{
			ToggleCheckedState();
			const ECheckBoxState State = IsCheckboxChecked.Get();
			if (State == ECheckBoxState::Checked)
			{
				PlayCheckedSound();
			}
			else if (State == ECheckBoxState::Unchecked)
			{
				PlayUncheckedSound();
			}

			// Set focus to this button, but don't capture the mouse
			return FReply::Handled().SetUserFocus(AsShared(), EFocusCause::Mouse);
		}
		else
		{
			// Capture the mouse, and also set focus to this button
			return FReply::Handled().CaptureMouse(AsShared()).SetUserFocus(AsShared(), EFocusCause::Mouse);
		}
	}
	else if (MouseEvent.GetEffectingButton() == EKeys::RightMouseButton && OnGetMenuContent.IsBound())
	{
		FWidgetPath WidgetPath = MouseEvent.GetEventPath() != nullptr ? *MouseEvent.GetEventPath() : FWidgetPath();

		FSlateApplication::Get().PushMenu(
			AsShared(),
			WidgetPath,
			OnGetMenuContent.Execute(),
			MouseEvent.GetScreenSpacePosition(),
			FPopupTransitionEffect(FPopupTransitionEffect::ContextMenu)
		);

		return FReply::Handled();
	}
	else
	{
		return FReply::Unhandled();
	}
}

FReply SKGCheckBox::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	const EButtonClickMethod::Type InputClickMethod = GetClickMethodFromInputType(MouseEvent);
	const bool bMustBePressed = InputClickMethod == EButtonClickMethod::DownAndUp || InputClickMethod == EButtonClickMethod::PreciseClick;
	const bool bMeetsPressedRequirements = (!bMustBePressed || (bIsPressed && bMustBePressed));

	if (bMeetsPressedRequirements && ((MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton || MouseEvent.IsTouchEvent())))
	{
		Release();

		if (InputClickMethod == EButtonClickMethod::MouseDown)
		{
			// NOTE: If we're configured to click on mouse-down/precise-tap, then we never capture the mouse thus
			//       may never receive an OnMouseButtonUp() call.  We make sure that our bIsPressed
			//       state is reset by overriding OnMouseLeave().
		}
		else
		{
			const bool IsUnderMouse = MyGeometry.IsUnderLocation(MouseEvent.GetScreenSpacePosition());
			if (IsUnderMouse)
			{
				// If we were asked to allow the button to be clicked on mouse up, regardless of whether the user
				// pressed the button down first, then we'll allow the click to proceed without an active capture
				if (InputClickMethod == EButtonClickMethod::MouseUp || HasMouseCapture())
				{
					ToggleCheckedState();
					const ECheckBoxState State = IsCheckboxChecked.Get();
					if (State == ECheckBoxState::Checked)
					{
						PlayCheckedSound();
					}
					else if (State == ECheckBoxState::Unchecked)
					{
						PlayUncheckedSound();
					}
				}
			}
		}

		return FReply::Handled().ReleaseMouseCapture();
	}

	return FReply::Unhandled();
}

void SKGCheckBox::OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	const bool bWasHovered = IsHovered();
	
	SCompoundWidget::OnMouseEnter(MyGeometry, MouseEvent);
	if (!bWasHovered && IsHovered())
	{
		ExecuteHoverStateChanged(true);
	}
	Invalidate(EInvalidateWidgetReason::Prepass);
}

void SKGCheckBox::OnMouseLeave(const FPointerEvent& MouseEvent)
{
	const bool bWasHovered = IsHovered();
	SWidget::OnMouseLeave(MouseEvent);

	// If we're setup to click on mouse-down, then we never capture the mouse and may not receive a
	// mouse up event, so we need to make sure our pressed state is reset properly here
	if (ClickMethod == EButtonClickMethod::MouseDown || IsPreciseTapOrClick(MouseEvent))
	{
		Release();
	}
	
	if (bWasHovered && !IsHovered())
	{
		ExecuteHoverStateChanged(true);
	}

	Invalidate(EInvalidateWidgetReason::Prepass);
}

void SKGCheckBox::SetOnHovered(FSimpleDelegate InOnHovered)
{
	OnHovered = InOnHovered;
}

void SKGCheckBox::SetOnUnhovered(FSimpleDelegate InOnUnhovered)
{
	OnUnhovered = InOnUnhovered;
}

void SKGCheckBox::SetOnPressed(FSimpleDelegate InOnPressed)
{
	OnPressed = InOnPressed;
}

void SKGCheckBox::SetOnReleased(FSimpleDelegate InOnReleased)
{
	OnReleased = InOnReleased;
}

void SKGCheckBox::Press()
{
	if (!bIsPressed)
	{
		bIsPressed = true;
		OnPressed.ExecuteIfBound();
	}
}

void SKGCheckBox::Release()
{
	if (bIsPressed)
	{
		bIsPressed = false;
		OnReleased.ExecuteIfBound();
	}
}

void SKGCheckBox::ExecuteHoverStateChanged(bool bPlaySound)
{
	if (IsHovered())
	{
		if (bPlaySound)
		{
			PlayHoverSound();
		}
		OnHovered.ExecuteIfBound();
	}
	else
	{
		OnUnhovered.ExecuteIfBound();
	}
}

bool SKGCheckBox::SupportsKeyboardFocus() const
{
#if WITH_EDITOR
	const bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#else
	const static bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#endif
	if (bDisableFocusableGlobally)
	{
		return false;
	}

	return Super::SupportsKeyboardFocus();
}
