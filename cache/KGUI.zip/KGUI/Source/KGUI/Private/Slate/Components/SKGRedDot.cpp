#include "Slate/Components/SKGRedDot.h"
#include  "Widgets/SWidget.h"
#include "Layout/ArrangedChildren.h"

SLATE_IMPLEMENT_WIDGET(SKGRedDot)

void SKGRedDot::FOneChildSlot::Construct(const FChildren& SlotOwner, FSlotArguments&& InArgs)
{
	TSlotBase::Construct(SlotOwner, MoveTemp(InArgs));
	if (InArgs._Offset.IsSet())
	{
		OffsetAttr = MoveTemp(InArgs._Offset);
	}
	
	if (InArgs._Anchors.IsSet())
	{
		AnchorsAttr = MoveTemp(InArgs._Anchors);
	}

	if (InArgs._Alignment.IsSet())
	{
		AlignmentAttr = MoveTemp(InArgs._Alignment);
	}
}

void SKGRedDot::PrivateRegisterAttributes(FSlateAttributeInitializer& AttributeInitializer)
{
	SLATE_ADD_MEMBER_ATTRIBUTE_DEFINITION_WITH_NAME(AttributeInitializer, "ContentScale", ContentScaleAttribute, EInvalidateWidgetReason::Layout);
	SLATE_ADD_MEMBER_ATTRIBUTE_DEFINITION_WITH_NAME(AttributeInitializer, "ColorAndOpacity", ColorAndOpacityAttribute, EInvalidateWidgetReason::Paint);
	SLATE_ADD_MEMBER_ATTRIBUTE_DEFINITION_WITH_NAME(AttributeInitializer, "ForegroundColor", ForegroundColorAttribute, EInvalidateWidgetReason::Paint);
}

SKGRedDot::SKGRedDot()
	: ChildSlot(this)
	, ContentScaleAttribute(*this, 1.f)
	, ColorAndOpacityAttribute(*this, FLinearColor::White)
	, ForegroundColorAttribute( *this, FSlateColor::UseForeground() )
{
	SetCanTick(false);
	SetVisibility(EVisibility::HitTestInvisible);
}

void SKGRedDot::Construct(const FArguments& InArgs)
{
	bHasRelativeLayoutScale = true;
	ChildSlot.SetOffset(InArgs._Offset);
	ChildSlot.SetAlignment(InArgs._Alignment);
	ChildSlot.SetAnchors(InArgs._Anchor);
	ChildSlot[InArgs._Content.Widget];
	OwnerWidget = InArgs._OwnerWidget;
	SetContentScale(InArgs._ContentScale.Get());
	SetColorAndOpacity(InArgs._ColorAndOpacity);
}

void SKGRedDot::SetContent(TSharedRef<SWidget> InContent)
{
	if (ChildSlot.GetWidget() != InContent)
	{
		ChildSlot
		[
			InContent
		];

		Invalidate(EInvalidateWidgetReason::Layout | EInvalidateWidgetReason::Paint);
	}
}

void SKGRedDot::SetContentAlignment(const FVector2D& InAlignment)
{
	ChildSlot.SetAlignment(InAlignment);
}

void SKGRedDot::SetContentAnchors(const FAnchors& InAnchors)
{
	ChildSlot.SetAnchors(InAnchors);
}

void SKGRedDot::SetContentOffset(const FMargin& InOffset)
{
	ChildSlot.SetOffset(InOffset);
}

void SKGRedDot::OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const
{
	const EVisibility ChildVisibility = ChildSlot.GetWidget()->GetVisibility();
	if (ArrangedChildren.Accepts(ChildVisibility))
	{
		const FMargin Offset = ChildSlot.GetOffset();
		const FVector2D Alignment = ChildSlot.GetAlignment();
		const FAnchors Anchors = ChildSlot.GetAnchors();

		const FMargin AnchorPixels = FMargin(Anchors.Minimum.X * AllottedGeometry.GetLocalSize().X, Anchors.Minimum.Y * AllottedGeometry.GetLocalSize().Y, Anchors.Maximum.X * AllottedGeometry.GetLocalSize().X, Anchors.Maximum.Y * AllottedGeometry.GetLocalSize().Y);

		const bool bIsHorizontalStretch = Anchors.Minimum.X != Anchors.Maximum.X;
		const bool bIsVerticalStretch = Anchors.Minimum.Y != Anchors.Maximum.Y;
		
		const FVector2D Size = ChildSlot.GetWidget()->GetDesiredSize() * ContentScaleAttribute.Get();

		// Calculate the offset based on the pivot position.
		FVector2D AlignmentOffset = Size * Alignment;

		// Calculate the local position based on the anchor and position offset.
		FVector2D LocalPosition, LocalSize;

		// Calculate the position and size based on the horizontal stretch or non-stretch
		if (bIsHorizontalStretch)
		{
			LocalPosition.X = AnchorPixels.Left + Offset.Left;
			LocalSize.X = AnchorPixels.Right - LocalPosition.X - Offset.Right;
		}
		else
		{
			LocalPosition.X = AnchorPixels.Left + Offset.Left - AlignmentOffset.X;
			LocalSize.X = Size.X;
		}

		// Calculate the position and size based on the vertical stretch or non-stretch
		if (bIsVerticalStretch)
		{
			LocalPosition.Y = AnchorPixels.Top + Offset.Top;
			LocalSize.Y = AnchorPixels.Bottom - LocalPosition.Y - Offset.Bottom;
		}
		else
		{
			LocalPosition.Y = AnchorPixels.Top + Offset.Top - AlignmentOffset.Y;
			LocalSize.Y = Size.Y;
		}

		// Add the information about this child to the output list (ArrangedChildren)
		ArrangedChildren.AddWidget(ChildVisibility, AllottedGeometry.MakeChild(
			                           // The child widget being arranged
			                           ChildSlot.GetWidget(),
			                           // Child's local position (i.e. position within parent)
			                           LocalPosition / ContentScaleAttribute.Get(),
			                           // Child's size
			                           LocalSize / ContentScaleAttribute.Get(),
			                           ContentScaleAttribute.Get()));
	}
}

FChildren* SKGRedDot::GetChildren()
{
	return &ChildSlot;
}

int32 SKGRedDot::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	if (OwnerWidget.IsValid())
	{
		FArrangedChildren ArrangedChildren(EVisibility::Visible);
		ArrangeChildren(AllottedGeometry, ArrangedChildren);
	
		// There may be zero elements in this array if our child collapsed/hidden
		if( ArrangedChildren.Num() > 0 )
		{
			const bool bShouldBeEnabled = ShouldBeEnabled(bParentEnabled);

			check( ArrangedChildren.Num() == 1 );
			FArrangedWidget& TheChild = ArrangedChildren[0];

			{
				FWidgetStyle CompoundedWidgetStyle = FWidgetStyle(InWidgetStyle)
				                                     .BlendColorAndOpacityTint(GetColorAndOpacity())
				                                     .SetForegroundColor(bShouldBeEnabled ? GetForegroundColor() : GetDisabledForegroundColor() );
				int32 Layer = OwnerWidget->GetPersistentState().OutgoingLayerId;
				Layer = TheChild.Widget->Paint( Args.WithNewParent(this), TheChild.Geometry, MyCullingRect, OutDrawElements, Layer + 1, CompoundedWidgetStyle, bShouldBeEnabled);
			}
		}
	}
	
	return LayerId;
}

FSlateColor SKGRedDot::GetForegroundColor() const
{
	return ForegroundColorAttribute.Get();
}

float SKGRedDot::GetRelativeLayoutScale(int32 ChildIndex, float LayoutScaleMultiplier) const
{
	return ContentScaleAttribute.Get();
}

FVector2D SKGRedDot::ComputeDesiredSize(float LayoutScaleMultiplier) const
{
	if (OwnerWidget.IsValid())
	{
		const_cast<SKGRedDot*>(this)->SetClipping(OwnerWidget->GetClipping());
		return OwnerWidget->GetDesiredSize();
	}

	return FVector2D::Zero();
}
