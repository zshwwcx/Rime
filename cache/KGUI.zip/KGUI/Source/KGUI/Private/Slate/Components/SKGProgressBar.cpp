#include "Slate/Components/SKGProgressBar.h"

#include "Components/SlateWrapperTypes.h"
#include "Engine/Texture.h"
#include "Framework/Application/SlateApplication.h"
#include "Layout/LayoutUtils.h"
#include "Rendering/SlateRenderer.h"
#include "Util/KGVertexGenerator.h"

#if WITH_EDITOR
#pragma  optimize("", off)
#endif

void SKGProgressBar::Construct(const FArguments& InArgs)
{
    check(InArgs._Style);

    MarqueeOffset = 0.0f;

    Style = InArgs._Style;

    SetPercent(InArgs._Percent);
    BarFillType = InArgs._BarFillType;
    BarFillStyle = InArgs._BarFillStyle;

    BackgroundImage = InArgs._BackgroundImage;
    FillImage = InArgs._FillImage;
    MarqueeImage = InArgs._MarqueeImage;

    FillColorAndOpacity = InArgs._FillColorAndOpacity;
    BorderPadding = InArgs._BorderPadding;

    CurrentTickRate = 0.0f;
    MinimumTickRate = InArgs._RefreshRate;
    ThumbImage = InArgs._ThumbImage;

    // CircularRadius = InArgs._CircularRadius;
    CircularThickness = InArgs._CircularThickness;
    CircularStartAngle = InArgs._CircularStartAngle;
    CircularEndAngle = InArgs._CircularEndAngle;
    ThumbOffset = InArgs._ThumbOffset;
    bAlwaysShowThumb = InArgs._AlwaysShowThumb;

    SetCanTick(false);

    UpdateMarqueeActiveTimer();
}

int32 SKGProgressBar::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
    SCOPED_NAMED_EVENT(SKGProgressBar_OnPaint, FColor::Emerald);

    int32 RetLayerId = LayerId;

    bool bEnabled = ShouldBeEnabled(bParentEnabled);
    const ESlateDrawEffect DrawEffects = bEnabled ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect;

    TOptional<float> ProgressFraction = Percent.Get();

    // draw background
    if (const FSlateBrush* CurrentBackgroundImage = GetBackgroundImage())
    {
        FSlateDrawElement::MakeBox(OutDrawElements, RetLayerId++, AllottedGeometry.ToPaintGeometry(), CurrentBackgroundImage, DrawEffects, InWidgetStyle.GetColorAndOpacityTint() * CurrentBackgroundImage->GetTint(InWidgetStyle), Args.GetBatchZOrder(), Args.GetSlateInViewDepth());
    }

    EKGProgressBarFillType ComputedBarFillType = BarFillType;
    if (GSlateFlowDirection == EFlowDirection::RightToLeft)
    {
        switch (ComputedBarFillType)
        {
        case EKGProgressBarFillType::LeftToRight:
            ComputedBarFillType = EKGProgressBarFillType::RightToLeft;
            break;
        case EKGProgressBarFillType::RightToLeft:
            ComputedBarFillType = EKGProgressBarFillType::LeftToRight;
            break;
        default: break;
        }
    }

    // draw bar and maquee animation
    switch (ComputedBarFillType)
    {
    case EKGProgressBarFillType::FillFromCenter:
        RetLayerId = DrawFillFromCenter(OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, DrawEffects, Args.GetBatchZOrder(), Args.GetSlateInViewDepth());
        break;
    case EKGProgressBarFillType::FillFromCenterHorizontal:
        RetLayerId = DrawFillFromCenterHorizontal(OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, DrawEffects, Args.GetBatchZOrder(), Args.GetSlateInViewDepth());
        break;
    case EKGProgressBarFillType::FillFromCenterVertical:
        RetLayerId = DrawFillFromCenterVertical(OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, DrawEffects, Args.GetBatchZOrder(), Args.GetSlateInViewDepth());
        break;
    case EKGProgressBarFillType::TopToBottom:
        RetLayerId = DrawTopToBottom(OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, DrawEffects, Args.GetBatchZOrder(), Args.GetSlateInViewDepth());
        break;
    case EKGProgressBarFillType::BottomToTop:
        RetLayerId = DrawBottomToTop(OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, DrawEffects, Args.GetBatchZOrder(), Args.GetSlateInViewDepth());
        break;
    case EKGProgressBarFillType::RightToLeft:
        RetLayerId = DrawRightToLeft(OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, DrawEffects, Args.GetBatchZOrder(), Args.GetSlateInViewDepth());
        break;
    case EKGProgressBarFillType::Radial:
        RetLayerId = DrawRadial(OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, DrawEffects, Args.GetBatchZOrder(), Args.GetSlateInViewDepth());
        break;
    case EKGProgressBarFillType::LeftToRight: default:
        RetLayerId = DrawLeftToRight(OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, DrawEffects, Args.GetBatchZOrder(), Args.GetSlateInViewDepth());
        break;
    }
    
    if (bHasThumb)
    {
        float ActualPercent = ProgressFraction.IsSet() ? ProgressFraction.GetValue() : 1.f;
        if (bAlwaysShowThumb || 0.f < ActualPercent && ActualPercent < 1.f)
        {
            RetLayerId = SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, RetLayerId, InWidgetStyle, bEnabled);
        }
    }

    return RetLayerId;
}

FVector2D SKGProgressBar::ComputeDesiredSize(float LayoutScaleMultiplier) const
{
    FVector2D RetSize = FVector2D::Zero();
    if (const auto* BackgroundBrush = GetBackgroundImage())
    {
        RetSize.X = FMath::Max(BackgroundBrush->GetImageSize().X, RetSize.X);
        RetSize.Y = FMath::Max(BackgroundBrush->GetImageSize().Y, RetSize.Y);
    }

    if (const auto* FillBrush = GetFillImage())
    {
        RetSize.X = FMath::Max(FillBrush->GetImageSize().X, RetSize.X);
        RetSize.Y = FMath::Max(FillBrush->GetImageSize().Y, RetSize.Y);
    }

    if (const auto* MarqueeBrush = GetMarqueeImage())
    {
        RetSize.X = FMath::Max(MarqueeBrush->GetImageSize().X, RetSize.X);
        RetSize.Y = FMath::Max(MarqueeBrush->GetImageSize().Y, RetSize.Y);
    }

    return RetSize;
}

bool SKGProgressBar::ComputeVolatility() const
{
    return SCompoundWidget::ComputeVolatility() || Percent.IsBound() || FillColorAndOpacity.IsBound() || BorderPadding.IsBound();
}

void SKGProgressBar::SetThumbImage(const FSlateBrush* InThumbImage)
{
    if (ThumbImage != InThumbImage)
    {
        ThumbImage = InThumbImage;
        Invalidate(EInvalidateWidget::Layout);
    }
}

void SKGProgressBar::SetPercent(const TAttribute<TOptional<float>>& InPercent)
{
    if (!Percent.IdenticalTo(InPercent))
    {
        Percent = InPercent;
        UpdateMarqueeActiveTimer();
        Invalidate(EInvalidateWidget::Paint);
    }
}

void SKGProgressBar::SetStyle(const FProgressBarStyle* InStyle)
{
    Style = InStyle;

    if (Style == nullptr)
    {
        FArguments Defaults;
        Style = Defaults._Style;
    }

    check(Style);

    UpdateMarqueeActiveTimer();
    Invalidate(EInvalidateWidget::Layout);
}

void SKGProgressBar::SetBarFillType(EKGProgressBarFillType InBarFillType)
{
    if (BarFillType != InBarFillType)
    {
        BarFillType = InBarFillType;
        Invalidate(EInvalidateWidget::Paint);
    }
}

void SKGProgressBar::SetBarFillStyle(EProgressBarFillStyle::Type InBarFillStyle)
{
    if (BarFillStyle != InBarFillStyle)
    {
        BarFillStyle = InBarFillStyle;
        Invalidate(EInvalidateWidget::Paint);
    }
}

void SKGProgressBar::SetFillColorAndOpacity(const TAttribute<FSlateColor>& InFillColorAndOpacity)
{
    if (!FillColorAndOpacity.IdenticalTo(InFillColorAndOpacity))
    {
        FillColorAndOpacity = InFillColorAndOpacity;
        Invalidate(EInvalidateWidget::Paint);
    }
}

void SKGProgressBar::SetBorderPadding(const TAttribute<FVector2D>& InBorderPadding)
{
    if (!BorderPadding.IdenticalTo(InBorderPadding))
    {
        BorderPadding = InBorderPadding;
        Invalidate(EInvalidateWidget::Layout);
    }
}

void SKGProgressBar::SetBackgroundImage(const FSlateBrush* InBackgroundImage)
{
    if (BackgroundImage != InBackgroundImage)
    {
        BackgroundImage = InBackgroundImage;
        Invalidate(EInvalidateWidget::Layout);
    }
}

void SKGProgressBar::SetFillImage(const FSlateBrush* InFillImage)
{
    if (FillImage != InFillImage)
    {
        FillImage = InFillImage;
        Invalidate(EInvalidateWidget::Layout);
    }
}

void SKGProgressBar::SetMarqueeImage(const FSlateBrush* InMarqueeImage)
{
    if (MarqueeImage != InMarqueeImage)
    {
        MarqueeImage = InMarqueeImage;
        Invalidate(EInvalidateWidget::Layout);
    }
}

void SKGProgressBar::SetRefreshRate(float InRefreshRate)
{
    if (FMath::Abs(InRefreshRate - MinimumTickRate) < 0.000001f)
    {
        return;
    }

    MinimumTickRate = InRefreshRate;
    SetActiveTimerTickRate(InRefreshRate);
}

void SKGProgressBar::SetCircularThickness(float InCircularThickness)
{
    CircularThickness = InCircularThickness;
}

void SKGProgressBar::SetCircularRadius(float InCircularRadius)
{
    // CircularRadius = InCircularRadius;
}

void SKGProgressBar::SetCircularStartAngle(float InCircularStartAngle)
{
    CircularStartAngle = InCircularStartAngle;
}

void SKGProgressBar::SetCircularEndAngle(float InCircularEndAngle)
{
    CircularEndAngle = InCircularEndAngle;
}

void SKGProgressBar::SetThumbOffset(const FVector2D& InThumbOffset)
{
    if (ThumbOffset != InThumbOffset)
    {
        ThumbOffset = InThumbOffset;
        Invalidate(EInvalidateWidget::Paint);
    }
}

void SKGProgressBar::SetAlwaysShowThumb(bool InAlwaysShowThumb)
{
    if (InAlwaysShowThumb != bAlwaysShowThumb)
    {
        bAlwaysShowThumb = InAlwaysShowThumb;
        Invalidate(EInvalidateWidget::Paint);
    }
}

void SKGProgressBar::SetHasThumb(bool InHasThumb)
{
    if (InHasThumb != bHasThumb)
    {
        bHasThumb = InHasThumb;
        Invalidate(EInvalidateWidget::Paint);
    }
}


void SKGProgressBar::SetContent(TSharedRef<SWidget> InContent)
{
    ChildSlot[InContent];
}

TSharedRef<SWidget> SKGProgressBar::GetContent() const
{
    return ChildSlot.GetWidget();
}

void SKGProgressBar::ClearContent()
{
    ChildSlot.DetachWidget();
}

void SKGProgressBar::SetHAlign(EHorizontalAlignment HAlign)
{
    ChildSlot.SetHorizontalAlignment(HAlign);
}

void SKGProgressBar::SetVAlign(EVerticalAlignment VAlign)
{
    ChildSlot.SetVerticalAlignment(VAlign);
}

void SKGProgressBar::SetPadding(TAttribute<FMargin> InPadding)
{
    ChildSlot.SetPadding(InPadding);
}

void SKGProgressBar::OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const
{
    const EVisibility ChildVisibility = ChildSlot.GetWidget()->GetVisibility();
    if (ArrangedChildren.Accepts(ChildVisibility))
    {
        TOptional<float> ProgressFraction = Percent.Get();

        const FVector2D Size = AllottedGeometry.GetLocalSize() - BorderPadding.Get() * 2.0;
        float ActualPercent = 1.f;
        if (ProgressFraction.IsSet())
        {
            ActualPercent = FMath::Clamp(ProgressFraction.GetValue(), 0.f, 1.f);
        }
        
        FVector2D Offset;
        switch (BarFillType)
        {
        case EKGProgressBarFillType::FillFromCenter:

            break;
        case EKGProgressBarFillType::FillFromCenterHorizontal:

            break;
        case EKGProgressBarFillType::FillFromCenterVertical:

            break;
        case EKGProgressBarFillType::TopToBottom:
            Offset = FVector2D(0, Size.Y * ActualPercent);
            break;
        case EKGProgressBarFillType::BottomToTop:
            Offset = FVector2D(0, Size.Y * (1 - ActualPercent));
            break;
        case EKGProgressBarFillType::RightToLeft:
            Offset = FVector2D(Size.X * (1 - ActualPercent), 0);
            break;
        case EKGProgressBarFillType::Radial:
            {
                const FVector2D Center(Size.X * 0.5f + BorderPadding.Get().X, Size.Y * 0.5f + BorderPadding.Get().Y);
                const float Radius = FMath::Min(Size.X, Size.Y) * 0.5f; //FMath::Min(Size.X * 0.5f, CircularRadius);
                const float InnerRadius = Radius - FMath::Min(CircularThickness, Radius);

                float StartAngle = CircularStartAngle;
                float EndAngle = CircularEndAngle;
                while (EndAngle <= StartAngle)
                {
                    StartAngle -= 2 * PI;
                }

                float Angle = FMath::Lerp(StartAngle, EndAngle, ActualPercent);
                // ThumbOffset在圆形进度条里面偏移的坐标系：X轴为半径方向，Y轴为园切线方向，这里将ThumbOfset
                // 的X分量作为半径方向的偏移，ThumbOffset的Y分量分解到UI XY坐标轴上，后面添加到中心的坐标上
                float RadiusOffset = ThumbOffset.Y * FMath::Sin(Angle);
                float TengentOffset = ThumbOffset.Y * FMath::Cos(Angle);
                FVector2D ThumbCenter = Center + FVector2D(FMath::Cos(Angle), FMath::Sin(Angle)) * ((InnerRadius + Radius) * 0.5f + ThumbOffset.X);
                FVector2D LocalOffset = ThumbCenter + FVector2D(RadiusOffset, TengentOffset) - ChildSlot.GetWidget()->GetDesiredSize() * 0.5f;
                const FVector2D ChildSize = ChildSlot.GetWidget()->GetDesiredSize();
                const FVector2D ThisContentScale = GetContentScale();
                const FMargin SlotPadding(LayoutPaddingWithFlow(GSlateFlowDirection, ChildSlot.GetPadding()));
                const AlignmentArrangeResult XResult = AlignChild<Orient_Horizontal>(GSlateFlowDirection, ChildSize.X, ChildSlot, SlotPadding, ThisContentScale.X);
                const AlignmentArrangeResult YResult = AlignChild<Orient_Vertical>(ChildSize.Y, ChildSlot, SlotPadding, ThisContentScale.Y);
                FGeometry Geometry = AllottedGeometry.MakeChild(FVector2D(XResult.Size, YResult.Size), FSlateLayoutTransform(1, FVector2D(LocalOffset.X + XResult.Offset, LocalOffset.Y + YResult.Offset)));
                
                FSlateRenderTransform LocalRenderTransform = ::Concatenate(FScale2D(1), FShear2D::FromShearAngles(FVector2D::Zero()), FQuat2D(Angle), FVector2D::Zero());
                FGeometry GeometryRotated = Geometry.MakeChild(LocalRenderTransform, FVector2D::One() * 0.5f);
                ArrangedChildren.AddWidget(ChildVisibility, GeometryRotated.MakeChild(ChildSlot.GetWidget(), FVector2D::Zero(), FVector2D(XResult.Size, YResult.Size)));
                return;
            }
        case EKGProgressBarFillType::LeftToRight:
        default:
                Offset = FVector2D(Size.X * ActualPercent, 0);
            break;
        }

        Offset += BorderPadding.Get();
        const FVector2D ChildSize = ChildSlot.GetWidget()->GetDesiredSize();
        const FVector2D ThisContentScale = GetContentScale();
        const FMargin SlotPadding(LayoutPaddingWithFlow(GSlateFlowDirection, ChildSlot.GetPadding()));
        const AlignmentArrangeResult XResult = AlignChild<Orient_Horizontal>(GSlateFlowDirection, ChildSize.X, ChildSlot, SlotPadding, ThisContentScale.X);
        const AlignmentArrangeResult YResult = AlignChild<Orient_Vertical>(ChildSize.Y, ChildSlot, SlotPadding, ThisContentScale.Y);

        ArrangedChildren.AddWidget(ChildVisibility, AllottedGeometry.MakeChild(ChildSlot.GetWidget(), FVector2D(Offset.X + XResult.Offset, Offset.Y + YResult.Offset), FVector2D(XResult.Size, YResult.Size)));
    }
}

int SKGProgressBar::DrawThumb(float InCenterXInLocal, float InCenterYInLocal, float InAngle, FSlateWindowElementList& OutDrawElements, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth, float InPercent) const
{
    int32 RetLayerId = InLayerID;

    bool bShowThumb = false;
    if (bHasThumb)
    {
        bShowThumb = bAlwaysShowThumb ? true : (0.f < InPercent && InPercent < 1.f);
    }

    auto* ThumbBrush = GetThumbImage();
    if (ThumbBrush && bShowThumb)
    {
        FVector2D Location(InCenterXInLocal, InCenterYInLocal);
        FVector2D LocalOffset = ThumbOffset;
        LocalOffset -= ThumbBrush->GetImageSize() * 0.5f;

        FGeometry Geometry = AllottedGeometry.MakeChild(ThumbBrush->GetImageSize(), FSlateLayoutTransform(1, Location));
        FPaintGeometry PaintGeometry = Geometry.ToPaintGeometry();
        auto RenderTransform = PaintGeometry.GetAccumulatedRenderTransform();
        FSlateRenderTransform LocalRenderTransform = ::Concatenate(FScale2D(1), FShear2D::FromShearAngles(FVector2D::Zero()), FQuat2D(InAngle), FVector2D::Zero());
        LocalRenderTransform = FSlateRenderTransform(LocalOffset).Concatenate(LocalRenderTransform);
        RenderTransform = LocalRenderTransform.Concatenate(RenderTransform);
        PaintGeometry.SetRenderTransform(RenderTransform);

        FSlateDrawElement::MakeBox(OutDrawElements, RetLayerId++, PaintGeometry, ThumbBrush, InDrawEffects, InWidgetStyle.GetColorAndOpacityTint() * ThumbBrush->GetTint(InWidgetStyle), InBatchZOrder, InViewDepth);
    }
    
    return RetLayerId;
}

int32 SKGProgressBar::DrawLeftToRight(FSlateWindowElementList& OutDrawElements, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const
{
    int32 RetLayerId = InLayerID;
    TOptional<float> ProgressFraction = Percent.Get();

    const FSlateBrush* Brush = nullptr;
    float ActualPercent = 0.f;
    if (!ProgressFraction.IsSet())
    {
        Brush = GetMarqueeImage();
        ActualPercent = 1.f;
    }
    else
    {
        ActualPercent = FMath::Clamp(ProgressFraction.GetValue(), 0.f, 1.f);
        Brush = GetFillImage();
    }

    if (!Brush || Brush->GetDrawType() == ESlateBrushDrawType::Type::NoDrawType)
    {
        return RetLayerId;
    }

    const FVector2D Size = AllottedGeometry.GetLocalSize() - BorderPadding.Get() * 2.0;
    const FVector2D ProgressSize = FVector2D(Size.X * ActualPercent, Size.Y);

    FVector2f UVTopLeft(0, 0);
    FVector2f UVBottomRight(1, 1);
    FKGVertexGenerator::GetBrushUVRegion(Brush, UVTopLeft, UVBottomRight);
    FVector2f SizeUV = UVBottomRight - UVTopLeft;
    FVector2f BrushSize = FKGVertexGenerator::GetBrushSize(Brush);
    
    // 计算四个顶点位置
    const FVector2f TopLeft(BorderPadding.Get());
    const FVector2f BottomRight(TopLeft.X + ProgressSize.X, TopLeft.Y + ProgressSize.Y);
    float LeftMarginU = SizeUV.X * Brush->GetMargin().Left;
    float RightMarginU = SizeUV.X * (1 - Brush->GetMargin().Right);
    float LeftMargin = Brush->GetMargin().Left * BrushSize.X;
    float RightMargin = Size.X - Brush->GetMargin().Right * BrushSize.X;

    float TopMargin = Brush->GetMargin().Top * BrushSize.X;
    float TopMarginV = SizeUV.Y * Brush->GetMargin().Top;
    float BottomMargin = Size.Y - Brush->GetMargin().Bottom * BrushSize.Y;
    float BottomMarginV = SizeUV.Y - SizeUV.Y * Brush->GetMargin().Bottom;
    if (BottomMargin < TopMargin)
    {
        TopMargin = BottomMargin = ProgressSize.Y * 0.5f;
        TopMarginV = BottomMarginV = SizeUV.Y * 0.5f;
    }

    if (ProgressSize.X <= BrushSize.X * Brush->GetMargin().Left)
    {
        LeftMargin = ProgressSize.X * 0.5f;
        RightMargin = ProgressSize.X * 0.5f;
        LeftMarginU = ProgressSize.X / (BrushSize.X * Brush->GetMargin().Left) * Brush->GetMargin().Left * SizeUV.X * 0.5f;
        RightMarginU = LeftMarginU;
        UVBottomRight.X = UVTopLeft.X + LeftMarginU * 2;
    }
    else if (ProgressSize.X <= Size.X - BrushSize.X * Brush->GetMargin().Right)
    {
        LeftMargin = Brush->GetMargin().Left * BrushSize.X;
        RightMargin = ProgressSize.X;
        LeftMarginU = Brush->GetMargin().Left * SizeUV.X;
        float d = (ProgressSize.X - BrushSize.X * Brush->GetMargin().Left) / (Size.X - (Brush->GetMargin().Left + Brush->GetMargin().Right) * BrushSize.X);
        RightMarginU = LeftMarginU + d * (SizeUV.X - (Brush->GetMargin().Left * SizeUV.X + Brush->GetMargin().Right * SizeUV.X));
        UVBottomRight.X = UVTopLeft.X + RightMarginU;
    }
    else
    {
        LeftMargin = Brush->GetMargin().Left * BrushSize.X;
        RightMargin = Size.X - BrushSize.X * Brush->GetMargin().Right;
        LeftMarginU = Brush->GetMargin().Left * SizeUV.X;
        RightMarginU = SizeUV.X - Brush->GetMargin().Right * SizeUV.X;
        float d = (ProgressSize.X - (Size.X - BrushSize.X * Brush->GetMargin().Right)) / (Brush->GetMargin().Right * BrushSize.X);
        UVBottomRight.X = UVTopLeft.X + RightMarginU + d * SizeUV.X * Brush->GetMargin().Right;
    }

    FMargin MarginPos(LeftMargin, TopMargin, RightMargin, BottomMargin);
    FMargin MarginUV(LeftMarginU, TopMarginV, RightMarginU, BottomMarginV);

    // 计算顶点颜色（考虑父级不透明度和启用状态）
    const FLinearColor FinalColor(InWidgetStyle.GetColorAndOpacityTint() * FillColorAndOpacity.Get().GetColor(InWidgetStyle) * Brush->GetTint(InWidgetStyle));;

    const FColor PackedColor = FinalColor.ToFColor(true);

    TArray<FSlateVertex> Verts;
    TArray<SlateIndex> Indices;
    GenerateRectVertexData(AllottedGeometry, Brush, TopLeft, BottomRight, MarginPos, UVTopLeft, UVBottomRight, MarginUV, PackedColor, Verts, Indices);

    FSlateDrawElement::MakeCustomVerts(OutDrawElements, RetLayerId++, Brush->GetRenderingResource(), Verts, Indices, nullptr, 0, 0, InDrawEffects);

    if (ProgressFraction.IsSet())
    {
        RetLayerId = DrawThumb(BottomRight.X, ProgressSize.Y * 0.5f, 0.f, OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, InDrawEffects, InBatchZOrder, InViewDepth, ActualPercent);
    }

    return RetLayerId;
}

int32 SKGProgressBar::DrawRightToLeft(FSlateWindowElementList& OutDrawElements, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const
{
    int32 RetLayerId = InLayerID;
    TOptional<float> ProgressFraction = Percent.Get();

    const FSlateBrush* Brush = nullptr;
    float ActualPercent = 0.f;
    if (!ProgressFraction.IsSet())
    {
        Brush = GetMarqueeImage();
        ActualPercent = 1.f;
    }
    else
    {
        ActualPercent = FMath::Clamp(ProgressFraction.GetValue(), 0.f, 1.f);
        Brush = GetFillImage();
    }

    if (!Brush || Brush->GetDrawType() == ESlateBrushDrawType::Type::NoDrawType)
    {
        return RetLayerId;
    }

    const FVector2D Size = AllottedGeometry.GetLocalSize() - BorderPadding.Get() * 2.0;
    const FVector2D ProgressSize = FVector2D(Size.X * ActualPercent, Size.Y);

    FVector2f UVTopLeft(0, 0);
    FVector2f UVBottomRight(1, 1);
    FKGVertexGenerator::GetBrushUVRegion(Brush, UVTopLeft, UVBottomRight);
    FVector2f SizeUV = UVBottomRight - UVTopLeft;
    FVector2f BrushSize = FKGVertexGenerator::GetBrushSize(Brush);
    
    // 计算四个顶点位置
    const FVector2f BottomRight = AllottedGeometry.GetLocalSize() - BorderPadding.Get();
    const FVector2f TopLeft(BottomRight.X - ProgressSize.X, BottomRight.Y - ProgressSize.Y);
    float LeftMarginU = SizeUV.X * Brush->GetMargin().Left;
    float RightMarginU = SizeUV.X * (1 - Brush->GetMargin().Right);
    float LeftMargin = Brush->GetMargin().Left * BrushSize.X;
    float RightMargin = Size.X - Brush->GetMargin().Right * BrushSize.X;

    float TopMargin = Brush->GetMargin().Top * BrushSize.Y;
    float TopMarginV = SizeUV.Y * Brush->GetMargin().Top;
    float BottomMargin = Size.Y - Brush->GetMargin().Bottom * BrushSize.Y;
    float BottomMarginV = SizeUV.Y - SizeUV.Y * Brush->GetMargin().Bottom;
    if (BottomMargin < TopMargin)
    {
        TopMargin = BottomMargin = ProgressSize.Y * 0.5f;
        TopMarginV = BottomMarginV = SizeUV.Y * 0.5f;
    }

    if (TopLeft.X <= BrushSize.X * Brush->GetMargin().Left)
    {
        LeftMargin = BrushSize.X * Brush->GetMargin().Left - TopLeft.X;
        RightMargin = Size.X - BrushSize.X * Brush->GetMargin().Right - TopLeft.X;

        LeftMarginU = UVBottomRight.X - SizeUV.X * (1 - Brush->GetMargin().Left);
        RightMarginU = UVBottomRight.X - SizeUV.X * Brush->GetMargin().Right;
        UVTopLeft.X = LeftMarginU - (LeftMargin / (BrushSize.X * Brush->GetMargin().Left) * SizeUV.X * Brush->GetMargin().Left);
        LeftMarginU -= UVTopLeft.X;
        RightMarginU -= UVTopLeft.X;
    }
    else if (TopLeft.X <= Size.X - BrushSize.X * Brush->GetMargin().Right)
    {
        LeftMargin = 0;
        RightMargin = BottomRight.X - BrushSize.X * Brush->GetMargin().Right - TopLeft.X;

        RightMarginU = UVBottomRight.X - SizeUV.X * Brush->GetMargin().Right;
        LeftMarginU = RightMarginU - (ProgressSize.X - BrushSize.X * Brush->GetMargin().Right) / (Size.X - BrushSize.X * (Brush->GetMargin().Left + Brush->GetMargin().Right)) * SizeUV.X * (1 - Brush->GetMargin().Left - Brush->GetMargin().Right);
        UVTopLeft.X = LeftMarginU;
        LeftMarginU -= UVTopLeft.X;
        RightMarginU -= UVTopLeft.X;
    }
    else
    {
        LeftMargin = RightMargin = Size.X - ProgressSize.X * 0.5f - TopLeft.X;
        LeftMarginU = RightMarginU = UVBottomRight.X - SizeUV.X * Brush->GetMargin().Right * 0.5f * ProgressSize.X / (Brush->GetMargin().Right * BrushSize.X);
        UVTopLeft.X = UVBottomRight.X - SizeUV.X * Brush->GetMargin().Right * ProgressSize.X / (Brush->GetMargin().Right * BrushSize.X);
        LeftMarginU -= UVTopLeft.X;
        RightMarginU -= UVTopLeft.X;
    }

    FMargin MarginPos(LeftMargin, TopMargin, RightMargin, BottomMargin);
    FMargin MarginUV(LeftMarginU, TopMarginV, RightMarginU, BottomMarginV);

    // 计算顶点颜色（考虑父级不透明度和启用状态）
    const FLinearColor FinalColor(InWidgetStyle.GetColorAndOpacityTint() * FillColorAndOpacity.Get().GetColor(InWidgetStyle) * Brush->GetTint(InWidgetStyle));;

    const FColor PackedColor = FinalColor.ToFColor(true);

    TArray<FSlateVertex> Verts;
    TArray<SlateIndex> Indices;
    GenerateRectVertexData(AllottedGeometry, Brush, TopLeft, BottomRight, MarginPos, UVTopLeft, UVBottomRight, MarginUV, PackedColor, Verts, Indices);

    FSlateDrawElement::MakeCustomVerts(OutDrawElements, RetLayerId++, Brush->GetRenderingResource(), Verts, Indices, nullptr, 0, 0, InDrawEffects);

    if (ProgressFraction.IsSet())
    {
        RetLayerId = DrawThumb(TopLeft.X, ProgressSize.Y * 0.5f, 0.f, OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, InDrawEffects, InBatchZOrder, InViewDepth, ActualPercent);
    }

    return RetLayerId;
}

int32 SKGProgressBar::DrawTopToBottom(FSlateWindowElementList& OutDrawElements, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const
{
    int32 RetLayerId = InLayerID;
    TOptional<float> ProgressFraction = Percent.Get();

    const FSlateBrush* Brush = nullptr;
    float ActualPercent = 0.f;
    if (!ProgressFraction.IsSet())
    {
        Brush = GetMarqueeImage();
        ActualPercent = 1.f;
    }
    else
    {
        ActualPercent = FMath::Clamp(ProgressFraction.GetValue(), 0.f, 1.f);
        Brush = GetFillImage();
    }

    if (!Brush || Brush->GetDrawType() == ESlateBrushDrawType::Type::NoDrawType)
    {
        return RetLayerId;
    }

    const FVector2D Size = AllottedGeometry.GetLocalSize() - BorderPadding.Get() * 2.0;
    const FVector2D ProgressSize = FVector2D(Size.X, Size.Y * ActualPercent);
    FVector2f UVTopLeft(0, 0);
    FVector2f UVBottomRight(1, 1);
    FKGVertexGenerator::GetBrushUVRegion(Brush, UVTopLeft, UVBottomRight);
    FVector2f SizeUV = UVBottomRight - UVTopLeft;
    FVector2f BrushSize = FKGVertexGenerator::GetBrushSize(Brush);

    // 计算四个顶点位置
    const FVector2f TopLeft(BorderPadding.Get());
    const FVector2f BottomRight(TopLeft.X + ProgressSize.X, TopLeft.Y + ProgressSize.Y);
    float LeftMargin = BrushSize.X * Brush->GetMargin().Left;
    float RightMargin = Size.X - BrushSize.X * Brush->GetMargin().Right;
    float LeftMarginU = SizeUV.X * Brush->GetMargin().Left;
    float RightMarginU = SizeUV.X - SizeUV.X * Brush->GetMargin().Right;
    if (RightMargin < LeftMargin)
    {
        LeftMargin = RightMargin = ProgressSize.X * 0.5f;
        LeftMarginU = RightMarginU = SizeUV.X * 0.5f;
    }

    float TopMargin = Brush->GetMargin().Top * BrushSize.X;
    float TopMarginV = SizeUV.Y * Brush->GetMargin().Top;
    float BottomMargin = Size.Y - Brush->GetMargin().Bottom * BrushSize.Y;
    float BottomMarginV = SizeUV.Y - SizeUV.Y * Brush->GetMargin().Bottom;

    if (ProgressSize.Y <= BrushSize.Y * Brush->GetMargin().Top)
    {
        TopMargin = ProgressSize.Y * 0.5f;
        BottomMargin = ProgressSize.Y * 0.5f;

        TopMarginV = ProgressSize.Y / (BrushSize.Y * Brush->GetMargin().Top) * Brush->GetMargin().Top * SizeUV.Y * 0.5f;
        BottomMarginV = TopMarginV;
        UVBottomRight.Y = UVTopLeft.Y + TopMarginV * 2;
    }
    else if (ProgressSize.Y <= Size.Y - BrushSize.Y * Brush->GetMargin().Bottom)
    {
        TopMargin = Brush->GetMargin().Top * BrushSize.Y;
        BottomMargin = ProgressSize.Y;

        TopMarginV = Brush->GetMargin().Top * SizeUV.Y;
        float d = (ProgressSize.Y - BrushSize.Y * Brush->GetMargin().Top) / (Size.Y - (Brush->GetMargin().Top + Brush->GetMargin().Bottom) * BrushSize.Y);
        BottomMarginV = TopMarginV + d * (SizeUV.Y - (Brush->GetMargin().Top + Brush->GetMargin().Bottom) * SizeUV.Y);
        UVBottomRight.Y = UVTopLeft.Y + BottomMarginV;
    }
    else
    {
        TopMargin = Brush->GetMargin().Top * BrushSize.Y;
        BottomMargin = Size.Y - BrushSize.Y * Brush->GetMargin().Bottom;
        TopMarginV = Brush->GetMargin().Top * SizeUV.Y;
        BottomMarginV = SizeUV.Y - Brush->GetMargin().Bottom * SizeUV.Y;
        float d = (ProgressSize.Y - (Size.Y - BrushSize.Y * Brush->GetMargin().Bottom)) / (BrushSize.Y * Brush->GetMargin().Bottom);
        UVBottomRight.Y = UVTopLeft.Y + BottomMarginV + d * SizeUV.Y * Brush->GetMargin().Bottom;
    }

    FMargin PosMargin(LeftMargin, TopMargin, RightMargin, BottomMargin);
    FMargin Margin(LeftMarginU, TopMarginV, RightMarginU, BottomMarginV);
    // 计算顶点颜色（考虑父级不透明度和启用状态）
    const FLinearColor FinalColor(InWidgetStyle.GetColorAndOpacityTint() * FillColorAndOpacity.Get().GetColor(InWidgetStyle) * Brush->GetTint(InWidgetStyle));;

    const FColor PackedColor = FinalColor.ToFColor(true);
    TArray<FSlateVertex> Verts;
    TArray<SlateIndex> Indices;
    GenerateRectVertexData(AllottedGeometry, Brush, TopLeft, BottomRight, PosMargin, UVTopLeft, UVBottomRight, Margin, PackedColor, Verts, Indices);

    FSlateDrawElement::MakeCustomVerts(OutDrawElements, RetLayerId++, Brush->GetRenderingResource(), Verts, Indices, nullptr, 0, 0, InDrawEffects);

    if (ProgressFraction.IsSet())
    {
        RetLayerId = DrawThumb(ProgressSize.X * 0.5f, BottomRight.Y, 0.f, OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, InDrawEffects, InBatchZOrder, InViewDepth, ActualPercent);
    }

    return RetLayerId;
}

int32 SKGProgressBar::DrawBottomToTop(FSlateWindowElementList& OutDrawElements, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const
{
    int32 RetLayerId = InLayerID;
    TOptional<float> ProgressFraction = Percent.Get();

    const FSlateBrush* Brush = nullptr;
    float ActualPercent = 0.f;
    if (!ProgressFraction.IsSet())
    {
        Brush = GetMarqueeImage();
        ActualPercent = 1.f;
    }
    else
    {
        ActualPercent = FMath::Clamp(ProgressFraction.GetValue(), 0.f, 1.f);
        Brush = GetFillImage();
    }

    if (!Brush || Brush->GetDrawType() == ESlateBrushDrawType::Type::NoDrawType)
    {
        return RetLayerId;
    }

    const FVector2D Size = AllottedGeometry.GetLocalSize() - BorderPadding.Get() * 2.0;
    const FVector2D ProgressSize = FVector2D(Size.X, Size.Y * ActualPercent);

    FVector2f UVTopLeft(0, 0);
    FVector2f UVBottomRight(1, 1);
    FKGVertexGenerator::GetBrushUVRegion(Brush, UVTopLeft, UVBottomRight);
    FVector2f SizeUV = UVBottomRight - UVTopLeft;
    FVector2f BrushSize = FKGVertexGenerator::GetBrushSize(Brush);

    // 计算四个顶点位置
    const FVector2f BottomRight = AllottedGeometry.GetLocalSize() - BorderPadding.Get();
    const FVector2f TopLeft(BottomRight.X - ProgressSize.X, BottomRight.Y - ProgressSize.Y);
    float LeftMargin = BrushSize.X * Brush->GetMargin().Left;
    float RightMargin = Size.X - BrushSize.X * Brush->GetMargin().Right;
    float LeftMarginU = SizeUV.X * Brush->GetMargin().Left;
    float RightMarginU = SizeUV.X - SizeUV.X * Brush->GetMargin().Right;
    if (RightMargin < LeftMargin)
    {
        LeftMargin = RightMargin = ProgressSize.X * 0.5f;
        LeftMarginU = RightMarginU = SizeUV.X * 0.5f;
    }

    float TopMargin = Brush->GetMargin().Top * BrushSize.X;
    float TopMarginV = SizeUV.Y * Brush->GetMargin().Top;
    float BottomMargin = Size.Y - Brush->GetMargin().Bottom * BrushSize.Y;
    float BottomMarginV = SizeUV.Y - SizeUV.Y * Brush->GetMargin().Bottom;
    float P = TopLeft.Y - BorderPadding.Get().Y;
    if (P <= BrushSize.Y * Brush->GetMargin().Top)
    {
        TopMargin = Brush->GetMargin().Top * BrushSize.Y - TopLeft.Y;
        BottomMargin = BottomRight.Y - Brush->GetMargin().Bottom * BrushSize.Y - TopLeft.Y;

        TopMarginV = UVBottomRight.Y - SizeUV.Y * (1 - Brush->GetMargin().Top);
        BottomMarginV = UVBottomRight.Y - Brush->GetMargin().Bottom * SizeUV.Y;
        UVTopLeft.Y = TopMarginV - (TopMargin / (BrushSize.Y * Brush->GetMargin().Top) * SizeUV.Y * Brush->GetMargin().Top);
        TopMarginV -= UVTopLeft.Y;
        BottomMarginV -= UVTopLeft.Y;
    }
    else if (P <= Size.Y - BrushSize.Y * Brush->GetMargin().Bottom)
    {
        TopMargin = 0.f;
        BottomMargin = BottomRight.Y - Brush->GetMargin().Bottom * BrushSize.Y - TopLeft.Y;

        BottomMarginV = UVBottomRight.Y - Brush->GetMargin().Bottom * SizeUV.Y;
        float d = (ProgressSize.Y - BrushSize.Y * Brush->GetMargin().Bottom) / (Size.Y - (Brush->GetMargin().Top + Brush->GetMargin().Bottom) * BrushSize.Y);
        TopMarginV = BottomMarginV - d * (SizeUV.Y - (Brush->GetMargin().Top + Brush->GetMargin().Bottom) * SizeUV.Y);
        UVTopLeft.Y = TopMarginV;
        TopMarginV -= UVTopLeft.Y;
        BottomMarginV -= UVTopLeft.Y;
    }
    else
    {
        TopMargin = BottomMargin = BottomRight.Y - ProgressSize.Y * 0.5f - TopLeft.Y;
        TopMarginV = BottomMarginV = UVBottomRight.Y - ProgressSize.Y * 0.5f / (Brush->GetMargin().Bottom * BrushSize.Y) * Brush->GetMargin().Bottom * SizeUV.Y;
        UVTopLeft.Y = UVBottomRight.Y - ProgressSize.Y / (Brush->GetMargin().Bottom * BrushSize.Y) * Brush->GetMargin().Bottom * SizeUV.Y;
        TopMarginV -= UVTopLeft.Y;
        BottomMarginV -= UVTopLeft.Y;
    }

    FMargin PosMargin(LeftMargin, TopMargin, RightMargin, BottomMargin);
    FMargin Margin(LeftMarginU, TopMarginV, RightMarginU, BottomMarginV);
    // 计算顶点颜色（考虑父级不透明度和启用状态）
    const FLinearColor FinalColor(InWidgetStyle.GetColorAndOpacityTint() * FillColorAndOpacity.Get().GetColor(InWidgetStyle) * Brush->GetTint(InWidgetStyle));;

    const FColor PackedColor = FinalColor.ToFColor(true);
    TArray<FSlateVertex> Verts;
    TArray<SlateIndex> Indices;
    GenerateRectVertexData(AllottedGeometry, Brush, TopLeft, BottomRight, PosMargin, UVTopLeft, UVBottomRight, Margin, PackedColor, Verts, Indices);

    FSlateDrawElement::MakeCustomVerts(OutDrawElements, RetLayerId++, Brush->GetRenderingResource(), Verts, Indices, nullptr, 0, 0, InDrawEffects);

    if (ProgressFraction.IsSet() && 0.f < ActualPercent && ActualPercent < 1.f)
    {
        RetLayerId = DrawThumb(ProgressSize.X * 0.5f, TopLeft.Y, 0.f, OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, InDrawEffects, InBatchZOrder, InViewDepth, ActualPercent);
    }

    return RetLayerId;
}

int32 SKGProgressBar::DrawFillFromCenter(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const
{
    return InLayerID;
}

int32 SKGProgressBar::DrawFillFromCenterHorizontal(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const
{
    return InLayerID;
}

int32 SKGProgressBar::DrawFillFromCenterVertical(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const
{
    return InLayerID;
}


int32 SKGProgressBar::DrawRadial(FSlateWindowElementList& OutDrawElements, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const
{
    int32 RetLayerId = InLayerID;
    TOptional<float> ProgressFraction = Percent.Get();

    const FSlateBrush* Brush;
    float ActualProgress;
    if (!ProgressFraction.IsSet())
    {
        Brush = GetMarqueeImage();
        ActualProgress = 1.f;
    }
    else
    {
        ActualProgress = FMath::Clamp(ProgressFraction.GetValue(), 0.f, 1.f);
        Brush = GetFillImage();
    }

    if (!Brush || Brush->GetDrawType() == ESlateBrushDrawType::Type::NoDrawType)
    {
        return RetLayerId;
    }

    FVector2D Size = AllottedGeometry.GetLocalSize() - BorderPadding.Get() * 2.f;
    const FVector2f Center(Size.X * 0.5f, Size.Y * 0.5f);

    if (Size.X != Size.Y)
    {
        Size.X = Size.Y = FMath::Min(Size.X, Size.Y);
    }
    const float Radius = Size.X * 0.5f;//FMath::Min(Size.X * 0.5f, CircularRadius);
    const float InnerRadius = Radius - FMath::Min(CircularThickness, Radius);

    FVector2f StartUV(0, 0);
    FVector2f EndUV(1, 1);
    FKGVertexGenerator::GetBrushUVRegion(Brush, StartUV, EndUV);

    // 计算顶点颜色
    const FLinearColor FinalColor(InWidgetStyle.GetColorAndOpacityTint() * FillColorAndOpacity.Get().GetColor(InWidgetStyle) * Brush->GetTint(InWidgetStyle));;

    const FColor PackedColor = FinalColor.ToFColor(true);

    // 确定分段数（根据半径和进度动态调整）
    float StartAngle = CircularStartAngle;
    float EndAngle = CircularEndAngle;
    while (EndAngle <= StartAngle)
    {
        StartAngle -= 2 * PI;
    }

    static constexpr float MinAnglePerSegment = UE_PI / 90.f;
    const int32 Segments = FMath::Clamp(FMath::CeilToInt(Radius * 0.5f), 48, 128);
    const float AnglePerSegment = FMath::Max((EndAngle - StartAngle) / Segments, MinAnglePerSegment);
    const float ProgressAngle = (EndAngle - StartAngle) * ActualProgress;
    const int32 ProgressSegments = FMath::Max(FMath::CeilToInt(ProgressAngle / AnglePerSegment), 3);
    
    TArray<FSlateVertex> Verts;
    TArray<SlateIndex> Indices;

    FKGVertexGenerator::GenerateRadialVerts(Brush, AllottedGeometry, Center, Radius, InnerRadius, StartAngle, EndAngle, StartUV, EndUV, PackedColor, AnglePerSegment, ProgressAngle, ProgressSegments, Verts, Indices);

    FSlateDrawElement::MakeCustomVerts(OutDrawElements, RetLayerId++, Brush->GetRenderingResource(), Verts, Indices, nullptr, 0, 0, InDrawEffects);

    if (ProgressFraction.IsSet())
    {
        float Angle = FMath::Lerp(StartAngle, EndAngle, ActualProgress);
        FVector2f ThumbCenter = Center + FVector2f(FMath::Cos(Angle), FMath::Sin(Angle)) * (InnerRadius + Radius) * 0.5f;
        RetLayerId = DrawThumb(ThumbCenter.X, ThumbCenter.Y, Angle, OutDrawElements, AllottedGeometry, MyCullingRect, RetLayerId, InWidgetStyle, InDrawEffects, InBatchZOrder, InViewDepth, ActualProgress);
    }

    return RetLayerId;
}

void SKGProgressBar::GenerateRectVertexData(const FGeometry& AllottedGeometry, const FSlateBrush* Brush, const FVector2f& TopLeft, const FVector2f& BottomRight, const FMargin& InPosMargin, const FVector2f& UVTopLeft, const FVector2f& UVBottomRight, const FMargin& InUVMargin, const FColor& InColor, TArray<FSlateVertex>& OutVerts, TArray<SlateIndex>& OutIndices) const
{
    // 生成顶点数据
    switch (Brush->DrawAs)
    {
    case ESlateBrushDrawType::Type::Box:
        {
    		FKGVertexGenerator::GenerateVertexDataForBox(Brush, TopLeft, BottomRight, InPosMargin, UVTopLeft, UVBottomRight, InUVMargin, AllottedGeometry, InColor, OutVerts, OutIndices);
        }
        break;
    case ESlateBrushDrawType::Type::Border:
        {
    		FKGVertexGenerator::GenerateVertexDataForBorder(Brush, TopLeft, BottomRight, UVTopLeft, UVBottomRight, InUVMargin, AllottedGeometry, InColor, OutVerts, OutIndices);
        }
        break;
    case ESlateBrushDrawType::Type::RoundedBox:
    	FKGVertexGenerator::GenerateVertexDataForRoundBox(Brush, TopLeft, BottomRight, UVTopLeft, UVBottomRight, AllottedGeometry, InColor, OutVerts, OutIndices);
        break;
    case ESlateBrushDrawType::Type::Image:
    	FKGVertexGenerator::GenerateVertexDataForImage(Brush, TopLeft, BottomRight, UVTopLeft, UVBottomRight, AllottedGeometry, InColor, OutVerts, OutIndices);
        break;
    default:
        break;
    }
}

const FSlateBrush* SKGProgressBar::GetBackgroundImage() const
{
    return BackgroundImage ? BackgroundImage : &Style->BackgroundImage;
}

const FSlateBrush* SKGProgressBar::GetFillImage() const
{
    return FillImage ? FillImage : &Style->FillImage;
}

const FSlateBrush* SKGProgressBar::GetMarqueeImage() const
{
    return MarqueeImage ? MarqueeImage : &Style->MarqueeImage;
}

const FSlateBrush* SKGProgressBar::GetThumbImage() const
{
    return ThumbImage;
}

void SKGProgressBar::SetActiveTimerTickRate(float TickRate)
{
    if (CurrentTickRate != TickRate || !ActiveTimerHandle.IsValid())
    {
        CurrentTickRate = TickRate;

        TSharedPtr<FActiveTimerHandle> SharedActiveTimerHandle = ActiveTimerHandle.Pin();
        if (SharedActiveTimerHandle.IsValid())
        {
            UnRegisterActiveTimer(SharedActiveTimerHandle.ToSharedRef());
        }

        UpdateMarqueeActiveTimer();
    }
}

void SKGProgressBar::UpdateMarqueeActiveTimer()
{
    if (ActiveTimerHandle.IsValid())
    {
        UnRegisterActiveTimer(ActiveTimerHandle.Pin().ToSharedRef());
    }

    if ((!Percent.IsBound() && !Percent.Get().IsSet()) || Style->EnableFillAnimation)
    {
        // If percent is not bound or set then its marquee. Set the timer
        ActiveTimerHandle = RegisterActiveTimer(CurrentTickRate, FWidgetActiveTimerDelegate::CreateSP(this, &SKGProgressBar::ActiveTick));
    }
}

EActiveTimerReturnType SKGProgressBar::ActiveTick(double InCurrentTime, float InDeltaTime)
{
    MarqueeOffset = static_cast<float>(InCurrentTime - FMath::FloorToDouble(InCurrentTime));

    TOptional<float> PercentFraction = Percent.Get();
    if (PercentFraction.IsSet() && !Style->EnableFillAnimation)
    {
        SetActiveTimerTickRate(MinimumTickRate);
    }
    else
    {
        SetActiveTimerTickRate(0.0f);
    }

    Invalidate(EInvalidateWidget::Paint);

    return EActiveTimerReturnType::Continue;
}

#if WITH_EDITOR
#pragma optimize("", on)
#endif