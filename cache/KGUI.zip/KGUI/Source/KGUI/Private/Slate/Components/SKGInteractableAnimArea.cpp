
#include "Slate/Components/SKGInteractableAnimArea.h"
#include "Core/Common.h"
#include "Components/Widget.h"
#include "Components/ContentWidget.h"
#include "Components/PanelWidget.h"
#include "Widgets/Layout/SBox.h"
#include "Layout/ArrangedChildren.h"
#include "Layout/LayoutUtils.h"

SKGInteractableAnimArea::SKGInteractableAnimArea()
{
	SetCanTick(false);
	SetVisibility(EVisibility::SelfHitTestInvisible);
}

void SKGInteractableAnimArea::Construct(const FArguments& InArgs)
{
	bHasRelativeLayoutScale = true;
	SetVisibility(EVisibility::SelfHitTestInvisible);
	ChildSlot
		.HAlign(EHorizontalAlignment::HAlign_Fill)
		.VAlign(EVerticalAlignment::VAlign_Fill)
		.Padding(0)
		[
			InArgs._Content.Widget
		];
}

void SKGInteractableAnimArea::SetContent(TSharedRef<SWidget> InContent)
{
	ChildSlot
		.HAlign(EHorizontalAlignment::HAlign_Fill)
		.VAlign(EVerticalAlignment::VAlign_Fill)
		.Padding(0)
		[
			InContent
		];
}

void SKGInteractableAnimArea::SetScale(float Scale)
{
	// UE_LOG(LogKGUI, Log, TEXT("[AnimArea]%s %f"), ANSI_TO_TCHAR(__FUNCTION__), Scale);
	RelativeScale = Scale;
	Invalidate(EInvalidateWidgetReason::Layout);
}

void SKGInteractableAnimArea::OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const
{
	const EVisibility ChildVisibility = ChildSlot.GetWidget()->GetVisibility();
	if (ArrangedChildren.Accepts(ChildVisibility))
	{
		float FinalScale = RelativeScale.Get(1.f);
		const FMargin SlotPadding(ChildSlot.GetPadding());

		AlignmentArrangeResult XAlignmentResult = AlignChild<Orient_Horizontal>(AllottedGeometry.GetLocalSize().X, ChildSlot, SlotPadding);
		AlignmentArrangeResult YAlignmentResult = AlignChild<Orient_Vertical>(AllottedGeometry.GetLocalSize().Y, ChildSlot, SlotPadding);

		const FVector2f CurrentSize = FVector2f(XAlignmentResult.Size, YAlignmentResult.Size);
		if (CurrentSize.X > 0.0f && CurrentSize.Y > 0.0f)
		{
			FVector2f MaxSize = FVector2f(
				AllottedGeometry.Size.X - SlotPadding.GetTotalSpaceAlong<Orient_Horizontal>(),
				AllottedGeometry.Size.Y - SlotPadding.GetTotalSpaceAlong<Orient_Vertical>());

			const bool bXFillAlignment = ArrangeUtils::GetChildAlignment<Orient_Horizontal>::AsInt(EFlowDirection::LeftToRight, ChildSlot) == HAlign_Fill;
			const bool bYFillAlignment = ArrangeUtils::GetChildAlignment<Orient_Vertical>::AsInt(EFlowDirection::LeftToRight, ChildSlot) == HAlign_Fill;

			FVector2f NewSize = MaxSize;
			// Make sure they are inside the max available size
			if (NewSize.X > MaxSize.X)
			{
				float Scale = NewSize.X != 0.0f ? MaxSize.X / NewSize.X : 0.0f;
				NewSize *= Scale;
			}

			if (NewSize.Y > MaxSize.Y)
			{
				float Scale = NewSize.Y != 0.0f ? MaxSize.Y / NewSize.Y : 0.0f;
				NewSize *= Scale;
			}

			// The size changed, realign them. If it's Fill, then center it if needed.
			if (!bXFillAlignment)
			{
				XAlignmentResult = AlignChild<Orient_Horizontal>(AllottedGeometry.GetLocalSize().X, NewSize.X, ChildSlot, SlotPadding);
			}
			else
			{
				XAlignmentResult = ArrangeUtils::AlignCenter<Orient_Horizontal>(AllottedGeometry.GetLocalSize().X, NewSize.X, SlotPadding);
			}
			if (!bYFillAlignment)
			{
				YAlignmentResult = AlignChild<Orient_Vertical>(AllottedGeometry.GetLocalSize().Y, NewSize.Y, ChildSlot, SlotPadding);
			}
			else
			{
				YAlignmentResult = ArrangeUtils::AlignCenter<Orient_Vertical>(AllottedGeometry.GetLocalSize().Y, NewSize.Y, SlotPadding);
			}
		}

		ArrangedChildren.AddWidget(ChildVisibility, AllottedGeometry.MakeChild(
			ChildSlot.GetWidget(),
			FVector2D(XAlignmentResult.Offset - XAlignmentResult.Size * (FinalScale - 1) / 2, YAlignmentResult.Offset - YAlignmentResult.Size * (FinalScale - 1) / 2),
			FVector2D(XAlignmentResult.Size, YAlignmentResult.Size) /*/ FinalScale*/,
			FinalScale
		));
	}
}

int32 SKGInteractableAnimArea::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
    int32 OutLayerId = SBox::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
    return OutLayerId +  10;
}

float SKGInteractableAnimArea::GetRelativeLayoutScale(int32 ChildIndex, float LayoutScaleMultiplier) const
{
	return RelativeScale.IsSet() ? RelativeScale.GetValue() : 1.f;
}
