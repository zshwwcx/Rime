#include "Slate/Components/SKGLine.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Rendering/DrawElementPayloads.h"
#include "Rendering/DrawElements.h"
#include "Misc/App.h"
#include "Styling/CoreStyle.h"

SKGLine::SKGLine()
    : Points(nullptr)
    , DefaultLineThickness(1.0f)
    , LineMaterial(nullptr)
    , bUseBezierControl(true)
{
    SetCanTick(false);
    bCanSupportFocus = false;
    
    // 初始化默认的点渲染材质
    PointBrush = *FCoreStyle::Get().GetBrush("WhiteBrush");

	SetClipping(EWidgetClipping::Inherit);
}

void SKGLine::Construct(const FArguments& InArgs)
{
    Points = InArgs._Points;
	DefaultLineThickness = InArgs._DefaultLineThickness;
	LineMaterial = InArgs._LineMaterial;
	bUseBezierControl = InArgs._UseBezierControl;
}

FVector2D SKGLine::ComputeDesiredSize(float) const
{
	// 不占用布局
	return FVector2D(0.0f, 0.0f);
}

int32 SKGLine::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
    if (!Points || Points->Num() == 0)
    {
        return LayerId;
    }
    
	if (bUseBezierControl)
	{
		DrawBezierConnection(AllottedGeometry, OutDrawElements, LayerId, InWidgetStyle);
		// 绘制完连接后增加LayerId
		LayerId++;
	}
	else
	{
		DrawLineConnection(AllottedGeometry, OutDrawElements, LayerId, InWidgetStyle);
		// 绘制完连接后增加LayerId
		LayerId++;
	}
    
    return LayerId;
}

void SKGLine::SetPoints(const TArray<FKGBezierPoint>* InPoints)
{
	Points = InPoints;
	NotifyUpdatePoints();
}
void SKGLine::SetDefaultLineThickness(float InThickness)
{
	DefaultLineThickness = InThickness;
	Invalidate(EInvalidateWidgetReason::Paint);
}
void SKGLine::SetLineMaterial(const FSlateBrush* InBrush)
{
	LineMaterial = InBrush;
	Invalidate(EInvalidateWidgetReason::Paint);
}

void SKGLine::SetUseBezierControl(bool InUseBezierControl)
{
	if (bUseBezierControl == InUseBezierControl)
	{
		return;
	}
	bUseBezierControl = InUseBezierControl;
	NotifyUpdatePoints();
}
void SKGLine::NotifyUpdatePoints()
{
	Invalidate(EInvalidateWidgetReason::Layout);
	if (!bUseBezierControl)
	{
		LinePoints.Reset(Points->Num());
		LinePoints.AddUninitialized(Points->Num());
		for (int32 i = 0; i < Points->Num(); ++i)
		{
			LinePoints[i] = (*Points)[i].Position;
		}
	}
	else
	{
		BezierLines.Reset(Points->Num() - 1);
		BezierLines.AddUninitialized(Points->Num() - 1);	// n-1个线段
		for (int32 i = 1; i < Points->Num(); ++i)
		{
			const FVector2f& P0 = (*Points)[i - 1].Position;
			const FVector2f& P3 = (*Points)[i].Position;
			const FVector2f& C0 = (*Points)[i - 1].ControlPoint - P0;
			const FVector2f& C3 = (*Points)[i].ControlPoint - P3;
			FBezierSubLine& Line = BezierLines[i - 1];
			Line.StartPositionIndex = i - 1;
			Line.EndPositionIndex = i;
			Line.Control1 = P0 + C0.GetSafeNormal() * (C0.Size() * 0.3f);
			Line.Control2 = P3 - C3.GetSafeNormal() * (C3.Size() * 0.3f);
		}
	}
}

void SKGLine::DrawLineConnection(const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle) const
{
	if (!Points || LinePoints.Num() <= 0)
	{
		return;
	}
	const FLinearColor& LineColor = InWidgetStyle.GetColorAndOpacityTint();
	const float LineThickness = DefaultLineThickness;

	// 根据是否有材质选择不同的MakeLines重载
	if (LineMaterial && LineMaterial->DrawAs != ESlateBrushDrawType::NoDrawType && LineMaterial->GetResourceObject() != nullptr)
	{
		// 使用支持材质的MakeLines重载
		FSlateDrawElement::MakeLines(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToPaintGeometry(),
			LinePoints,
			LineMaterial,
			0,
			1,
			ESlateDrawEffect::None,
			LineColor,
			true,
			LineThickness
		);
	}
	else
	{
		// 使用标准MakeLines重载
		FSlateDrawElement::MakeLines(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToPaintGeometry(),
			LinePoints,
			ESlateDrawEffect::None,
			LineColor,
			true,
			LineThickness
		);
	}
}
void SKGLine::DrawBezierConnection(const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle) const
{
	const FLinearColor LineColor = InWidgetStyle.GetColorAndOpacityTint();
	const float LineThickness = DefaultLineThickness;

	for (int32 i = 0;i < BezierLines.Num();i++)
	{
		const FBezierSubLine& Line = BezierLines[i];
		const FKGBezierPoint& StartPoint = (*Points)[Line.StartPositionIndex];
		const FKGBezierPoint& EndPoint = (*Points)[Line.EndPositionIndex];

		// 计算控制点
		const FVector2f& P0 = StartPoint.Position;
		const FVector2f& P1 = Line.Control1;
		const FVector2f& P2 = Line.Control2;
		const FVector2f& P3 = EndPoint.Position;
		float StartUV = StartPoint.UV;
		float EndUV = EndPoint.UV;

		// 如果有材质，使用材质绘制
		if (LineMaterial && LineMaterial->DrawAs != ESlateBrushDrawType::NoDrawType && LineMaterial->GetResourceObject() != nullptr)
		{
			// 使用新的MakeCubicBezierSpline重载方法，支持FSlateBrush*
			FSlateDrawElement::MakeCubicBezierSpline(
				OutDrawElements,
				LayerId,
				AllottedGeometry.ToPaintGeometry(),
				P0, P1, P2, P3,
				LineMaterial,
				StartUV, EndUV,
				LineThickness,
				ESlateDrawEffect::None,
				LineColor
			);
		}
		else
		{
			// 使用基本贝塞尔曲线绘制
			FSlateDrawElement::MakeCubicBezierSpline(
				OutDrawElements,
				LayerId,
				AllottedGeometry.ToPaintGeometry(),
				P0, P1, P2, P3,
				LineThickness,
				ESlateDrawEffect::None,
				LineColor
			);
		}
	}
}