#include "Slate/Components/SKGButton.h"

#include "KGUISettings.h"

FReply SKGButton::OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	return SBorder::OnMouseButtonDoubleClick(InMyGeometry, InMouseEvent);
}

bool SKGButton::SupportsKeyboardFocus() const
{
#if WITH_EDITOR
	const bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#else
	const static bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#endif
	if (bDisableFocusableGlobally)
	{
		return false;
	}

	return Super::SupportsKeyboardFocus();
}
