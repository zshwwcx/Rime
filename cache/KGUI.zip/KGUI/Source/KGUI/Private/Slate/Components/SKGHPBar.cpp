#include "Slate/Components/SKGHPBar.h"
#include "Layout/ArrangedChildren.h"
#include "Layout/LayoutUtils.h"
#include "Util/KGVertexGenerator.h"

#if WITH_EDITOR
#pragma optimize( "", off)
#endif


void SKGHPBar::Construct(const FArguments& InArgs)
{
    Layers.Empty(InArgs._Layers.Get().Num());
    for (int32 i = 0; i < InArgs._Layers.Get().Num(); i++)
    {
        Layers.Add(InArgs._Layers.Get()[i]);
    }

    
    FillColorAndOpacity = InArgs._FillColorAndOpacity;

	//BEGIN ADD BY CHENGFENG@KUAISHOU.COM : DISABLE TICK BY DEFAULT
	SetCanTick(false);
	//END ADD BY CHENGFENG@KUAISHOU.COM
}

void SKGHPBar::SetContent(TSharedRef<SWidget> InContent)
{
	ChildSlot[InContent];
}

TSharedRef<SWidget> SKGHPBar::GetContent() const
{
	return ChildSlot.GetWidget();
}

void SKGHPBar::ClearContent()
{
	ChildSlot.DetachWidget();
}

void SKGHPBar::SetHAlign(EHorizontalAlignment HAlign)
{
	ChildSlot.SetHorizontalAlignment(HAlign);
}

void SKGHPBar::SetVAlign(EVerticalAlignment VAlign)
{
	ChildSlot.SetVerticalAlignment(VAlign);
}

void SKGHPBar::SetPadding(TAttribute<FMargin> InPadding)
{
	ChildSlot.SetPadding(InPadding);
}

int32 SKGHPBar::SetLayer(FName InLayerName, const FKGHPBarLayer& InLayer)
{
    for (int32 Index = 0; Index < Layers.Num(); Index++)
    {
        if (Layers[Index].Name == InLayerName)
        {
            
            Layers[Index] = InLayer;
            Invalidate(EInvalidateWidgetReason::Layout);
            return Index;
        }
    }
    
    int32 Index = Layers.Add(InLayer);
	Invalidate(EInvalidateWidgetReason::Layout);
	return Index;
}

void SKGHPBar::SetLayerBrush(FName InLayerName, const FSlateBrush& InBrush)
{
    auto* Layer = GetLayer(InLayerName);
	if (Layer && Layer->Brush != InBrush)
	{
		Layer->Brush = InBrush;
		Invalidate(EInvalidateWidgetReason::Layout);
	}
}

void SKGHPBar::SetLayerFillType(FName InLayerName, EKGHPBarFillType FillType)
{
    auto* Layer = GetLayer(InLayerName);
	if (Layer && Layer->FillType != FillType)
	{
		Layer->FillType = FillType;
		Invalidate(EInvalidateWidgetReason::Paint);
	}
}

void SKGHPBar::SetLayerPercent(FName InLayerName, float Percent)
{
    auto* Layer = GetLayer(InLayerName);
	if (Layer && Layer->Percent != Percent)
	{
		Layer->Percent = Percent;
		Invalidate(EInvalidateWidgetReason::Paint);
	}
}

void SKGHPBar::SetLayerAnimSpeed(FName InLayerName, float AnimSpeed)
{
    auto* Layer = GetLayer(InLayerName);
	if (Layer && Layer->AnimSpeed != AnimSpeed)
	{
		Layer->AnimSpeed = AnimSpeed;
		Invalidate(EInvalidateWidgetReason::Paint);
	}
}

void SKGHPBar::SetLayerVisibility(FName InLayerName, bool bVisible)
{
    auto* Layer = GetLayer(InLayerName);
	if (Layer && Layer->bVisible != bVisible)
	{
		Layer->bVisible = bVisible;
		Invalidate(EInvalidateWidgetReason::Paint);
	}
}

void SKGHPBar::SetLayerSize(FName InLayerName, const FVector2D& InSize)
{
    if (auto* Layer = GetLayer(InLayerName))
    {
        Layer->Size = InSize;
        Invalidate(EInvalidateWidgetReason::Layout);
    }
}

FVector2D SKGHPBar::GetLayerSize(FName InLayerName) const
{
    if (auto* Layer = GetLayer(InLayerName))
    {
        return Layer->Size;
    }
    return FVector2D::ZeroVector;
}

bool SKGHPBar::IsLayerVisible(FName InLayerName) const
{
    if (const auto* Layer = GetLayer(InLayerName))
    {
        return Layer->bVisible;
    }

    return false;
}

void SKGHPBar::SetFillColorAndOpacity(const TAttribute<FSlateColor>& InFillColorAndOpacity)
{
    if (!FillColorAndOpacity.IdenticalTo(InFillColorAndOpacity))
    {
        FillColorAndOpacity = InFillColorAndOpacity;
        Invalidate(EInvalidateWidgetReason::Paint);
    }
}

int32 SKGHPBar::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect,
                        FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
    bool bEnabled = ShouldBeEnabled(bParentEnabled);
    const ESlateDrawEffect DrawEffects = bEnabled ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect;

    int32 MaxLayerId = LayerId;
    for (const auto& Layer : Layers)
    {
        if (Layer.bVisible)
        {
            int32 ChildLayerId = DrawLayer(Layer, Args, AllottedGeometry, MyCullingRect, OutDrawElements, MaxLayerId, InWidgetStyle, DrawEffects, bParentEnabled);
            MaxLayerId = FMath::Max(MaxLayerId, ChildLayerId);
        }
    }
    
    FArrangedChildren ArrangedChildren(EVisibility::Visible);
    {
        this->ArrangeChildren(AllottedGeometry, ArrangedChildren);
    }

    if( ArrangedChildren.Num() > 0 )
    {
        const bool bShouldBeEnabled = ShouldBeEnabled(bParentEnabled);

        check( ArrangedChildren.Num() == 1 );
        FArrangedWidget& TheChild = ArrangedChildren[0];

        FWidgetStyle CompoundedWidgetStyle = FWidgetStyle(InWidgetStyle)
            .BlendColorAndOpacityTint(GetColorAndOpacity())
            .SetForegroundColor(bShouldBeEnabled ? GetForegroundColor() : GetDisabledForegroundColor() );

        int32 ChildLayerId;
        {
            SCOPED_NAMED_EVENT(HPBar_PainChild, FColor::Blue);
            ChildLayerId = TheChild.Widget->Paint( Args.WithNewParent(this), TheChild.Geometry, MyCullingRect, OutDrawElements, MaxLayerId, CompoundedWidgetStyle, bShouldBeEnabled);
        }
        MaxLayerId = FMath::Max(MaxLayerId, ChildLayerId);
    }
    
	return MaxLayerId;
}

FKGHPBarLayer* SKGHPBar::GetLayer(FName InLayerName)
{
    for (auto& Layer : Layers)
    {
        if (Layer.Name == InLayerName)
        {
            return &Layer;
        }
    }

    return nullptr;
}

const FKGHPBarLayer* SKGHPBar::GetLayer(FName InLayerName) const
{
    for (auto& Layer : Layers)
    {
        if (Layer.Name == InLayerName)
        {
            return &Layer;
        }
    }

    return nullptr;
}

FVector2D SKGHPBar::ComputeDesiredSize(float X) const
{
    FVector2D SizeDesired = FVector2D::ZeroVector;
    if (ChildSlot.GetWidget() != SNullWidget::NullWidget)
    {
        FVector2D ChildSize = SCompoundWidget::ComputeDesiredSize(X);
        SizeDesired.X = FMath::Max(ChildSize.X, SizeDesired.X);
        SizeDesired.Y = FMath::Max(ChildSize.Y, SizeDesired.Y);
    }

    for (const auto& Layer : Layers)
    {
        SizeDesired.X = FMath::Max(Layer.Size.X + Layer.Padding.GetTotalSpaceAlong<Orient_Horizontal>(), SizeDesired.X);
        SizeDesired.Y = FMath::Max(Layer.Size.Y + Layer.Padding.GetTotalSpaceAlong<Orient_Vertical>(), SizeDesired.Y);
    }
    
    return SizeDesired;
}

void SKGHPBar::OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const
{
    const EVisibility ChildVisibility = ChildSlot.GetWidget()->GetVisibility();
    if ( ArrangedChildren.Accepts(ChildVisibility) )
    {
        FVector2D Offset = FVector2D::ZeroVector;
        if (auto* MainLayer = GetMainLayer())
        {
            float Percent = FMath::Clamp(MainLayer->Percent, 0.f, 1.f);
            const FSlateBrush* Brush = &MainLayer->Brush;
            if (Brush && Brush->GetDrawType() != ESlateBrushDrawType::NoDrawType)
            {
                FVector2D Size;
                Size.X = AllottedGeometry.GetLocalSize().X - MainLayer->Padding.GetTotalSpaceAlong<Orient_Horizontal>();
                Size.Y = AllottedGeometry.GetLocalSize().Y - MainLayer->Padding.GetTotalSpaceAlong<Orient_Vertical>();
                switch (MainLayer->FillType)
                {
                case EKGHPBarFillType::RightToLeft:
                    Offset.X = Size.X * (1 - Percent);
                    break;
                case EKGHPBarFillType::TopToBottom:
                    Offset.Y = Size.Y * Percent;
                    break;
                case EKGHPBarFillType::BottomToTop:
                    Offset.Y = Size.Y * (1 - Percent);
                    break;
                case EKGHPBarFillType::LeftToRight:
                default:
                    Offset.X = Size.X * Percent;
                    break;
                }
            }
            Offset += FVector2D(MainLayer->Padding.Left, MainLayer->Padding.Top);
        }

        const FVector2D ChildSize = ChildSlot.GetWidget()->GetDesiredSize();
        const FVector2D ThisContentScale = GetContentScale();
        const FMargin SlotPadding(LayoutPaddingWithFlow(GSlateFlowDirection, ChildSlot.GetPadding()));
        const AlignmentArrangeResult XResult = AlignChild<Orient_Horizontal>(GSlateFlowDirection, ChildSize.X, ChildSlot, SlotPadding, ThisContentScale.X);
        const AlignmentArrangeResult YResult = AlignChild<Orient_Vertical>(ChildSize.Y, ChildSlot, SlotPadding, ThisContentScale.Y);

        ArrangedChildren.AddWidget( ChildVisibility, AllottedGeometry.MakeChild(
                ChildSlot.GetWidget(),
                FVector2D(Offset.X + XResult.Offset, Offset.Y + YResult.Offset),
                FVector2D(XResult.Size, YResult.Size)
        ) );
    }
}

int32 SKGHPBar::DrawLayer(const FKGHPBarLayer& InLayer, const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, bool bParentEnabled) const
{
    // TODO: limunan 丑陋的代码需要整理
    int32 RetLayerId = LayerId;
    float Percent = FMath::Clamp(InLayer.Percent, 0.f, 1.f);
    const FSlateBrush* Brush = &InLayer.Brush;
    if (!Brush || Brush->GetDrawType() == ESlateBrushDrawType::NoDrawType)
    {
        return LayerId;
    }

    FVector2D Size;
    Size.X = AllottedGeometry.GetLocalSize().X - InLayer.Padding.GetTotalSpaceAlong<Orient_Horizontal>();
    Size.Y = AllottedGeometry.GetLocalSize().Y - InLayer.Padding.GetTotalSpaceAlong<Orient_Vertical>();
    FVector2D BarSize = Size;
    FVector2f UVTopLeft(0.f, 0.f);
    FVector2f UVBottomRight(1.f, 1.f);
    FKGVertexGenerator::GetBrushUVRegion(Brush, UVTopLeft, UVBottomRight);
    
    FVector2f SizeUV = UVBottomRight - UVTopLeft;
    FVector2f SizeBrush = FKGVertexGenerator::GetBrushSize(Brush);

    FVector2f TopLeft = FVector2f::Zero();
    FVector2f BottomRight(BarSize.X, BarSize.Y);
    float LeftMargin = 0, RightMargin = 0, TopMargin = 0, BottomMargin = 0;
    float LeftMarginU = 0, RightMarginU = 0, TopMarginV = 0, BottomMarginV = 0;

    switch (InLayer.FillType)
    {
    case EKGHPBarFillType::LeftToRight:
        {
            BarSize.X = Size.X * Percent;
            TopLeft.X = 0;
            BottomRight.X = TopLeft.X + Size.X * Percent;
            
            LeftMargin = SizeBrush.X * Brush->GetMargin().Left;
            RightMargin = BarSize.X - Brush->GetMargin().Right * SizeBrush.X;
            TopMargin = SizeBrush.Y * Brush->GetMargin().Top;
            BottomMargin = BarSize.Y - SizeBrush.Y * Brush->GetMargin().Bottom;
            
            LeftMarginU = SizeUV.X * Brush->GetMargin().Left;
            RightMarginU = SizeUV.X * (1 - Brush->GetMargin().Right);
            TopMarginV = SizeUV.Y * Brush->GetMargin().Top;
            BottomMarginV = SizeUV.Y * (1 - Brush->GetMargin().Bottom);

            if (BottomMargin < TopMargin)
            {
                BottomMargin = TopMargin = Size.Y * 0.5f;
                TopMargin = BottomMarginV = SizeUV.Y * 0.5f;   
            }

            if (BarSize.X <= SizeBrush.X * Brush->GetMargin().Left)
            {
                LeftMargin = BarSize.X * 0.5f;
                RightMargin = BarSize.X * 0.5f;
                LeftMarginU = BarSize.X / (SizeBrush.X * Brush->GetMargin().Left) * Brush->GetMargin().Left * SizeUV.X * 0.5f;
                RightMarginU = LeftMarginU;
                UVBottomRight.X = UVTopLeft.X + LeftMarginU * 2;
            }
            else if (BarSize.X <= Size.X - SizeBrush.X * Brush->GetMargin().Right)
            {
                LeftMargin = Brush->GetMargin().Left * SizeBrush.X;
                RightMargin = BarSize.X;
                LeftMarginU = Brush->GetMargin().Left * SizeUV.X;
                float d = (BarSize.X - SizeBrush.X * Brush->GetMargin().Left) / (Size.X - (Brush->GetMargin().Left + Brush->GetMargin().Right) * SizeBrush.X);
                RightMarginU = LeftMarginU + d * (SizeUV.X - (Brush->GetMargin().Left * SizeUV.X + Brush->GetMargin().Right * SizeUV.X));
                UVBottomRight.X = UVTopLeft.X + RightMarginU;
            }
            else
            {
                LeftMargin = Brush->GetMargin().Left * SizeBrush.X;
                RightMargin = LeftMargin + (Size.X - SizeBrush.X * (Brush->GetMargin().Right + 
                Brush->GetMargin().Left));
                LeftMarginU = Brush->GetMargin().Left * SizeUV.X;
                RightMarginU = SizeUV.X - Brush->GetMargin().Right * SizeUV.X;
                float d = (BarSize.X - (Size.X - SizeBrush.X * Brush->GetMargin().Right)) / (Brush->GetMargin().Right * SizeBrush.X);
                UVBottomRight.X = UVTopLeft.X + RightMarginU + d * SizeUV.X * Brush->GetMargin().Right;
            }
        }
        break;
    case EKGHPBarFillType::RightToLeft:
        {
            BarSize.X = Size.X * Percent;
            TopLeft.X = Size.X * (1 - Percent);
            BottomRight.X = Size.X;

            LeftMargin = Brush->GetMargin().Left * SizeBrush.X;
            RightMargin = Size.X - Brush->GetMargin().Right * SizeBrush.X;
            TopMargin = Brush->GetMargin().Top * SizeBrush.Y;
            BottomMargin = Size.Y - Brush->GetMargin().Bottom * SizeBrush.Y;

            LeftMarginU = SizeUV.X * Brush->GetMargin().Left;
            RightMarginU = SizeUV.X * (1 - Brush->GetMargin().Right);
            TopMarginV = SizeUV.Y * Brush->GetMargin().Top;
            BottomMarginV = SizeUV.Y - SizeUV.Y * Brush->GetMargin().Bottom;
            
            if (BottomMargin < TopMargin)
            {
                TopMargin = BottomMargin = Size.Y * 0.5f;
                TopMarginV = BottomMarginV = SizeUV.Y * 0.5f;
            }

            if (TopLeft.X <= SizeBrush.X * Brush->GetMargin().Left)
            {
                LeftMargin = SizeBrush.X * Brush->GetMargin().Left - TopLeft.X;
                RightMargin = Size.X - SizeBrush.X * Brush->GetMargin().Right - TopLeft.X;

                LeftMarginU = UVBottomRight.X - SizeUV.X * (1 - Brush->GetMargin().Left);
                RightMarginU = UVBottomRight.X - SizeUV.X * Brush->GetMargin().Right;
                UVTopLeft.X = LeftMarginU - (LeftMargin / (SizeBrush.X * Brush->GetMargin().Left) * SizeUV.X * Brush->GetMargin().Left);
                LeftMarginU -= UVTopLeft.X;
                RightMarginU -= UVTopLeft.X;
            }
            else if (TopLeft.X <= Size.X - SizeBrush.X * Brush->GetMargin().Right)
            {
                LeftMargin = 0;
                RightMargin = BottomRight.X - SizeBrush.X * Brush->GetMargin().Right - TopLeft.X;

                RightMarginU = UVBottomRight.X - SizeUV.X * Brush->GetMargin().Right;
                LeftMarginU = RightMarginU - (BarSize.X - SizeBrush.X * Brush->GetMargin().Right) / (Size.X - SizeBrush.X * (Brush->GetMargin().Left + Brush->GetMargin().Right)) * SizeUV.X * (1 - Brush->GetMargin().Left - Brush->GetMargin().Right);
                UVTopLeft.X = LeftMarginU;
                LeftMarginU -= UVTopLeft.X;
                RightMarginU -= UVTopLeft.X;
            }
            else
            {
                LeftMargin = RightMargin = BottomRight.X - BarSize.X * 0.5f - TopLeft.X;
                LeftMarginU = RightMarginU = UVBottomRight.X - SizeUV.X * Brush->GetMargin().Right * 0.5f * BarSize.X / (Brush->GetMargin().Right * SizeBrush.X);
                UVTopLeft.X = UVBottomRight.X - SizeUV.X * Brush->GetMargin().Right * BarSize.X / (Brush->GetMargin().Right * SizeBrush.X);
                LeftMarginU -= UVTopLeft.X;
                RightMarginU -= UVTopLeft.X;
            }
        }
        break;
    case EKGHPBarFillType::TopToBottom:
        {
            BarSize.Y = Size.Y * Percent;
            TopLeft.Y = 0;
            BottomRight.Y = TopLeft.Y + Size.Y * Percent;

            LeftMargin = TopLeft.X + SizeBrush.X * Brush->GetMargin().Left;
            RightMargin = TopLeft.X + BarSize.X - Brush->GetMargin().Right * SizeBrush.X;
            TopMargin = TopLeft.Y + SizeBrush.Y * Brush->GetMargin().Top;
            BottomMargin = TopLeft.Y + BarSize.Y - SizeBrush.Y * Brush->GetMargin().Bottom;
            
            LeftMarginU = SizeUV.X * Brush->GetMargin().Left;
            RightMarginU = SizeUV.X * (1 - Brush->GetMargin().Right);
            TopMarginV = SizeUV.Y * Brush->GetMargin().Top;
            BottomMarginV = SizeUV.Y * (1 - Brush->GetMargin().Bottom);

            if (RightMargin < LeftMargin)
            {
                RightMargin = LeftMargin = Size.X * 0.5f;
                RightMarginU = LeftMarginU = SizeUV.X * 0.5f;   
            }

            if (BarSize.Y <= SizeBrush.Y * Brush->GetMargin().Top)
            {
                TopMargin = BarSize.Y * 0.5f;
                BottomMargin = BarSize.Y * 0.5f;

                TopMarginV = BarSize.Y / (SizeBrush.Y * Brush->GetMargin().Top) * Brush->GetMargin().Top * SizeUV.Y * 0.5f;
                BottomMarginV = TopMarginV;
                UVBottomRight.Y = UVTopLeft.Y + TopMarginV * 2;
            }
            else if (BarSize.Y <= Size.Y - SizeBrush.Y * Brush->GetMargin().Bottom)
            {
                TopMargin = Brush->GetMargin().Top * SizeBrush.Y;
                BottomMargin = BarSize.Y;

                TopMarginV = Brush->GetMargin().Top * SizeUV.Y;
                float d = (BarSize.Y - SizeBrush.Y * Brush->GetMargin().Top) / (Size.Y - (Brush->GetMargin().Top + Brush->GetMargin().Bottom) * SizeBrush.Y);
                BottomMarginV = TopMarginV + d * (SizeUV.Y - (Brush->GetMargin().Top + Brush->GetMargin().Bottom) * SizeUV.Y);
                UVBottomRight.Y = UVTopLeft.Y + BottomMarginV;
            }
            else
            {
                TopMargin = Brush->GetMargin().Top * SizeBrush.Y;
                BottomMargin = Size.Y - SizeBrush.Y * Brush->GetMargin().Bottom;
                TopMarginV = Brush->GetMargin().Top * SizeUV.Y;
                BottomMarginV = SizeUV.Y - Brush->GetMargin().Bottom * SizeUV.Y;
                float d = (BarSize.Y - (Size.Y - SizeBrush.Y * Brush->GetMargin().Bottom)) / (SizeBrush.Y * Brush->GetMargin().Bottom);
                UVBottomRight.Y = UVTopLeft.Y + BottomMarginV + d * SizeUV.Y * Brush->GetMargin().Bottom;
            }
        }
        break;
    case EKGHPBarFillType::BottomToTop:
        {
            BarSize.Y = Size.Y * Percent;
            TopLeft.Y = Size.Y * (1 - Percent);
            BottomRight.Y = Size.Y;

            LeftMargin = TopLeft.X + SizeBrush.X * Brush->GetMargin().Left;
            RightMargin = TopLeft.X + BarSize.X - Brush->GetMargin().Right * SizeBrush.X;
            TopMargin = TopLeft.Y + SizeBrush.Y * Brush->GetMargin().Top;
            BottomMargin = TopLeft.Y + BarSize.Y - SizeBrush.Y * Brush->GetMargin().Bottom;
            
            LeftMarginU = SizeUV.X * Brush->GetMargin().Left;
            RightMarginU = SizeUV.X * (1 - Brush->GetMargin().Right);
            TopMarginV = SizeUV.Y * Brush->GetMargin().Top;
            BottomMarginV = SizeUV.Y * (1 - Brush->GetMargin().Bottom);

            if (RightMargin < LeftMargin)
            {
                RightMargin = LeftMargin = Size.X * 0.5f;
                RightMarginU = LeftMarginU = SizeUV.X * 0.5f;   
            }

            if (TopLeft.Y <= SizeBrush.Y * Brush->GetMargin().Top)
            {
                TopMargin = Brush->GetMargin().Top * SizeBrush.Y - TopLeft.Y;
                BottomMargin = BottomRight.Y - Brush->GetMargin().Bottom * SizeBrush.Y - TopLeft.Y;

                TopMarginV = UVBottomRight.Y - SizeUV.Y * (1 - Brush->GetMargin().Top);
                BottomMarginV = UVBottomRight.Y - Brush->GetMargin().Bottom * SizeUV.Y;
                UVTopLeft.Y = TopMarginV - (TopMargin / (SizeBrush.Y * Brush->GetMargin().Top) * SizeUV.Y * Brush->GetMargin().Top);
                TopMarginV -= UVTopLeft.Y;
                BottomMarginV -= UVTopLeft.Y;
            }
            else if (TopLeft.Y <= Size.Y - SizeBrush.Y * Brush->GetMargin().Bottom)
            {
                TopMargin = 0.f;
                BottomMargin = BottomRight.Y - Brush->GetMargin().Bottom * SizeBrush.Y - TopLeft.Y;

                BottomMarginV = UVBottomRight.Y - Brush->GetMargin().Bottom * SizeUV.Y;
                float d = (BarSize.Y - SizeBrush.Y * Brush->GetMargin().Bottom) / (Size.Y - (Brush->GetMargin().Top + Brush->GetMargin().Bottom) * SizeBrush.Y);
                TopMarginV = BottomMarginV - d * (SizeUV.Y - (Brush->GetMargin().Top + Brush->GetMargin().Bottom) * SizeUV.Y);
                UVTopLeft.Y = TopMarginV;
                TopMarginV -= UVTopLeft.Y;
                BottomMarginV -= UVTopLeft.Y;
            }
            else
            {
                TopMargin = BottomMargin = BottomRight.Y - BarSize.Y * 0.5f - TopLeft.Y;
                TopMarginV = BottomMarginV = UVBottomRight.Y - BarSize.Y * 0.5f / (Brush->GetMargin().Bottom * SizeBrush.Y) * Brush->GetMargin().Bottom * SizeUV.Y;
                UVTopLeft.Y = UVBottomRight.Y - BarSize.Y / (Brush->GetMargin().Bottom * SizeBrush.Y) * Brush->GetMargin().Bottom * SizeUV.Y;
                TopMarginV -= UVTopLeft.Y;
                BottomMarginV -= UVTopLeft.Y;
            }
        }
        break;
    default:
        break;
    }

    FMargin MarginPos(LeftMargin, TopMargin, RightMargin, BottomMargin);
    FMargin MarginUV(LeftMarginU, TopMarginV, RightMarginU, BottomMarginV);

    // 计算顶点颜色（考虑父级不透明度和启用状态）
    const FLinearColor FinalColor(InWidgetStyle.GetColorAndOpacityTint() * FillColorAndOpacity.Get().GetColor(InWidgetStyle) * Brush->GetTint(InWidgetStyle));;

    const FColor PackedColor = FinalColor.ToFColor(true);

    FVector2f Offset(InLayer.Padding.Left, InLayer.Padding.Top);
    TArray<FSlateVertex> Verts;
    TArray<SlateIndex> Indices;
    GenerateRectVertexData(AllottedGeometry, Brush, TopLeft + Offset, BottomRight + Offset, MarginPos, UVTopLeft,
        UVBottomRight, MarginUV, PackedColor, Verts, Indices);

    FSlateDrawElement::MakeCustomVerts(OutDrawElements, RetLayerId++, Brush->GetRenderingResource(), Verts, Indices, nullptr, 0, 0, InDrawEffects);
    
    return RetLayerId;
}

void SKGHPBar::GenerateRectVertexData(const FGeometry& AllottedGeometry, const FSlateBrush* Brush, const FVector2f& TopLeft, const FVector2f& BottomRight, const FMargin& InPosMargin, const FVector2f& UVTopLeft, const FVector2f& UVBottomRight, const FMargin& InUVMargin, const FColor& InColor, TArray<FSlateVertex>& OutVerts, TArray<SlateIndex>& OutIndices) const
{
    // 生成顶点数据
    switch (Brush->DrawAs)
    {
    case ESlateBrushDrawType::Type::Box:
        {
    		FKGVertexGenerator::GenerateVertexDataForBox(Brush, TopLeft, BottomRight, InPosMargin, UVTopLeft, UVBottomRight, InUVMargin, AllottedGeometry, InColor, OutVerts, OutIndices);
        }
        break;
    case ESlateBrushDrawType::Type::Border:
        {
    		FKGVertexGenerator::GenerateVertexDataForBorder(Brush, TopLeft, BottomRight, UVTopLeft, UVBottomRight, InUVMargin, AllottedGeometry, InColor, OutVerts, OutIndices);
        }
        break;
    case ESlateBrushDrawType::Type::RoundedBox:
    	FKGVertexGenerator::GenerateVertexDataForRoundBox(Brush, TopLeft, BottomRight, UVTopLeft, UVBottomRight, AllottedGeometry, InColor, OutVerts, OutIndices);
        break;
    case ESlateBrushDrawType::Type::Image:
    	FKGVertexGenerator::GenerateVertexDataForImage(Brush, TopLeft, BottomRight, UVTopLeft, UVBottomRight, AllottedGeometry, InColor, OutVerts, OutIndices);
        break;
    default:

        break;
    }
}

const FKGHPBarLayer* SKGHPBar::GetMainLayer() const
{
    for (int32 Index = Layers.Num() - 1; Index >= 0; --Index)
    {
        if (Layers[Index].bMainLayer)
        {
            return &Layers[Index];
        }
    }

    return Layers.Num() > 0 ? &Layers.Last(): nullptr;
}

#if WITH_EDITOR
#pragma optimize( "", on)
#endif
