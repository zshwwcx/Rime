#include "Slate/Input/SKGEditableTextBox.h"

#include "KGUISettings.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/SViewport.h"

FReply SKGEditableTextBox::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	auto Settings = GetDefault<UKGUISettings>();
	if (Settings && Settings->bEditableTextBoxSetUserFocusToGameViewportOnEscape)
	{
		FKey Key = InKeyEvent.GetKey();
		if (Key == EKeys::Escape && EditableText.IsValid() && EditableText->HasKeyboardFocus())
		{
			if (FSlateApplication::IsInitialized())
			{
				if (auto GameViewport = FSlateApplication::Get().GetGameViewport())
				{
					return FReply::Handled().SetUserFocus(GameViewport->AsShared(), EFocusCause::Cleared);
				}
			}
		}
	}
	else
	{
		auto Reply = Super::OnKeyDown(MyGeometry, InKeyEvent);
		if (Reply.IsEventHandled())
		{
			return Reply;
		}
	}
	return FReply::Handled();
}

FReply SKGEditableTextBox::OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	auto Reply = Super::OnKeyUp(MyGeometry, InKeyEvent);
	if (Reply.IsEventHandled())
	{
		return Reply;
	}
	return FReply::Handled();
}
