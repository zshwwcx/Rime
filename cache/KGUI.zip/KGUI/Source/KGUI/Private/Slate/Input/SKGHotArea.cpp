// Copyright Epic Games, Inc. All Rights Reserved.

#include "Slate/Input/SKGHotArea.h"

#include "KGUISettings.h"
#include "Rendering/DrawElements.h"
#include "Framework/Application/SlateApplication.h"
#if WITH_ACCESSIBILITY
#include "Widgets/Accessibility/SlateAccessibleMessageHandler.h"
#endif

static FName SHotAreaTypeName("SKGHotArea");

SLATE_IMPLEMENT_WIDGET(SKGHotArea)
void SKGHotArea::PrivateRegisterAttributes(FSlateAttributeInitializer& AttributeInitializer)
{
	
}

int32 SKGHotArea::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect,
	FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle,
	bool bParentEnabled) const
{
	return LayerId + 1;
}

/**
 * Construct this widget
 *
 * @param	InArgs	The declaration data for this widget
 */
void SKGHotArea::Construct(const FArguments& InArgs)
{
	bIsPressed = false;
	bIsFocusable = InArgs._IsFocusable;
	OnClicked = InArgs._OnClicked;
	OnRightClicked = InArgs._OnRightClicked;
	OnPressed = InArgs._OnPressed;
	OnReleased = InArgs._OnReleased;
	OnHovered = InArgs._OnHovered;
	OnUnhovered = InArgs._OnUnhovered;
	OnFocusLostEvent = InArgs._OnFocusLostEvent;
	OnKeyDownEvent = InArgs._OnKeyDownEvent;
	OnKeyUpEvent = InArgs._OnKeyUpEvent;
	OnMouseButtonDownEvent = InArgs._OnMouseButtonDownEvent;
	OnMouseButtonDoubleClickEvent = InArgs._OnMouseButtonDoubleClickEvent;
	OnMouseButtonUpEvent = InArgs._OnMouseButtonUpEvent;
	OnMouseMoveEvent = InArgs._OnMouseMoveEvent;
	OnMouseEnterEvent = InArgs._OnMouseEnterEvent;
	OnMouseLeaveEvent = InArgs._OnMouseLeaveEvent;
	OnMouseCaptureLostEvent = InArgs._OnMouseCaptureLostEvent;
	OnFocusReceivedEvent = InArgs._OnFocusReceivedEvent;
	OnFocusChangingEvent = InArgs._OnFocusChangingEvent;
	OnKeyCharEvent = InArgs._OnKeyCharEvent;
	OnPreviewKeyDownEvent = InArgs._OnPreviewKeyDownEvent;
	OnPreviewMouseButtonDownEvent = InArgs._OnPreviewMouseButtonDownEvent;
	OnMouseWheelEvent = InArgs._OnMouseWheelEvent;
	OnDragDetectedEvent = InArgs._OnDragDetectedEvent;
	OnDragEnterEvent = InArgs._OnDragEnterEvent;
	OnDragLeaveEvent = InArgs._OnDragLeaveEvent;
	OnDragOverEvent = InArgs._OnDragOverEvent;
	OnDropEvent = InArgs._OnDropEvent;
	OnTouchGestureEvent = InArgs._OnTouchGestureEvent;
	OnTouchStartedEvent = InArgs._OnTouchStartedEvent;
	OnTouchMovedEvent = InArgs._OnTouchMovedEvent;
	OnTouchEndedEvent = InArgs._OnTouchEndedEvent;
	OnTouchForceChangedEvent = InArgs._OnTouchForceChangedEvent;
	OnTouchFirstMoveEvent = InArgs._OnTouchFirstMoveEvent;

	ClickMethod = InArgs._ClickMethod;
	TouchMethod = InArgs._TouchMethod;
	PressMethod = InArgs._PressMethod;

	// Only do this if we're exactly an SKGHotArea
	if (GetType() == SHotAreaTypeName)
	{
		SetCanTick(false);
	}
}

bool SKGHotArea::SupportsKeyboardFocus() const
{
#if WITH_EDITOR
	const bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#else
	const static bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#endif
	if (bDisableFocusableGlobally)
	{
		return false;
	}

	// Buttons are focusable by default
	return bIsFocusable;
}

void SKGHotArea::OnFocusLost(const FFocusEvent& InFocusEvent)
{
	Release();
	if(OnFocusLostEvent.IsBound())
	{
		OnFocusLostEvent.Execute(InFocusEvent);
	}
}

FReply SKGHotArea::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	FReply Reply = FReply::Unhandled();
	if (OnKeyDownEvent.IsBound())
	{
		Reply = OnKeyDownEvent.Execute(MyGeometry, InKeyEvent);
	}
	if (IsEnabled() && FSlateApplication::Get().GetNavigationActionFromKey(InKeyEvent) == EUINavigationAction::Accept)
	{
		Press();

		if (PressMethod == EButtonPressMethod::ButtonPress)
		{
			//execute our "OnClicked" delegate, and get the reply
			Reply = ExecuteOnClick(EKeys::LeftMouseButton);

			//You should ALWAYS handle the OnClicked event.
			ensure(Reply.IsEventHandled() == true);
		}
		else
		{
			Reply = FReply::Handled();
		}
	}
	else
	{
		Reply = SWidget::OnKeyDown(MyGeometry, InKeyEvent);
	}

	//return the constructed reply
	return Reply;
}

FReply SKGHotArea::OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	FReply Reply = FReply::Unhandled();
	if (OnKeyUpEvent.IsBound())
	{
		Reply = OnKeyUpEvent.Execute(MyGeometry, InKeyEvent);
	}
	if (IsEnabled() && FSlateApplication::Get().GetNavigationActionFromKey(InKeyEvent) == EUINavigationAction::Accept)
	{
		const bool bWasPressed = bIsPressed;

		Release();

		//@Todo Slate: This should check focus, however we don't have that API yet, will be easier when focus is unified.
		if (PressMethod == EButtonPressMethod::ButtonRelease || (PressMethod == EButtonPressMethod::DownAndUp && bWasPressed))
		{
			//execute our "OnClicked" delegate, and get the reply
			Reply = ExecuteOnClick(EKeys::LeftMouseButton);

			//You should ALWAYS handle the OnClicked event.
			ensure(Reply.IsEventHandled() == true);
		}
		else
		{
			Reply = FReply::Handled();
		}
	}
	//return the constructed reply
	return Reply;
}

FReply SKGHotArea::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FReply Reply = FReply::Unhandled();
	if (OnMouseButtonDownEvent.IsBound())
	{
		Reply = OnMouseButtonDownEvent.Execute(MyGeometry, MouseEvent);
	}
	if (IsEnabled() && (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton || MouseEvent.GetEffectingButton() == EKeys::RightMouseButton || MouseEvent.IsTouchEvent()))
	{
		Press();
		PressedScreenSpacePosition = MouseEvent.GetScreenSpacePosition();

		EButtonClickMethod::Type InputClickMethod = GetClickMethodFromInputType(MouseEvent);

		if (InputClickMethod == EButtonClickMethod::MouseDown)
		{
			//get the reply from the execute function
			Reply = ExecuteOnClick(MouseEvent.GetEffectingButton());

			//You should ALWAYS handle the OnClicked event.
			ensure(Reply.IsEventHandled() == true);
		}
		else if (InputClickMethod == EButtonClickMethod::PreciseClick)
		{
			// do not capture the pointer for precise taps or clicks
			// 
			Reply = FReply::Handled();
		}
		else
		{
			//we need to capture the mouse for MouseUp events
			Reply = FReply::Handled().CaptureMouse(AsShared());
		}
	}
	if (bIsDrag)
	{
		Reply.DetectDrag(this->AsShared(), MouseEvent.GetEffectingButton());
	}
	//return the constructed reply
	return Reply;
}

FReply SKGHotArea::OnMouseButtonDoubleClick(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FReply Reply = SWidget::OnMouseButtonDoubleClick(MyGeometry, MouseEvent);
	if (Reply.IsEventHandled())
	{
		return Reply;
	}
	if (MouseEvent.GetEffectingButton() == EKeys::RightMouseButton)
	{
		// 右键也当做单次点击，双击逻辑在UKGHotArea里面做。
		return OnMouseButtonDown(MyGeometry, MouseEvent);
	}
	if (OnMouseButtonDoubleClickEvent.IsBound())
	{
		return OnMouseButtonDoubleClickEvent.Execute(MyGeometry, MouseEvent);
	}
	// We didn't handle the double click, treat it as single click
	return OnMouseButtonDown(MyGeometry, MouseEvent);
}

FReply SKGHotArea::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FReply Reply = FReply::Unhandled();
	if (OnMouseButtonUpEvent.IsBound())
	{
		Reply = OnMouseButtonUpEvent.Execute(MyGeometry, MouseEvent);
	}
	const EButtonClickMethod::Type InputClickMethod = GetClickMethodFromInputType(MouseEvent);
	const bool bMustBePressed = InputClickMethod == EButtonClickMethod::DownAndUp || InputClickMethod == EButtonClickMethod::PreciseClick;
	const bool bMeetsPressedRequirements = (!bMustBePressed || (bIsPressed && bMustBePressed));

	if (bMeetsPressedRequirements && ((MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton || MouseEvent.GetEffectingButton() == EKeys::RightMouseButton || MouseEvent.IsTouchEvent())))
	{
		Release();

		if (IsEnabled())
		{
			if (InputClickMethod == EButtonClickMethod::MouseDown)
			{
				// NOTE: If we're configured to click on mouse-down/precise-tap, then we never capture the mouse thus
				//       may never receive an OnMouseButtonUp() call.  We make sure that our bIsPressed
				//       state is reset by overriding OnMouseLeave().
			}
			else
			{
				bool bEventOverButton = IsHovered();

				if (!bEventOverButton && MouseEvent.IsTouchEvent())
				{
					bEventOverButton = MyGeometry.IsUnderLocation(MouseEvent.GetScreenSpacePosition());
				}

				if (bEventOverButton)
				{
					// If we asked for a precise tap, all we need is for the user to have not moved their pointer very far.
					const bool bTriggerForTouchEvent = InputClickMethod == EButtonClickMethod::PreciseClick;

					// If we were asked to allow the button to be clicked on mouse up, regardless of whether the user
					// pressed the button down first, then we'll allow the click to proceed without an active capture
					const bool bTriggerForMouseEvent = (InputClickMethod == EButtonClickMethod::MouseUp || HasMouseCapture());

					if ((bTriggerForTouchEvent || bTriggerForMouseEvent))
					{
						Reply = ExecuteOnClick(MouseEvent.GetEffectingButton());
					}
				}
			}
		}

		//If the user of the button didn't handle this click, then the button's
		//default behavior handles it.
		if (Reply.IsEventHandled() == false)
		{
			Reply = FReply::Handled();
		}
	}

	//If the user hasn't requested a new mouse captor and the button still has mouse capture,
	//then the default behavior of the button is to release mouse capture.
	if (Reply.GetMouseCaptor().IsValid() == false && HasMouseCapture())
	{
		Reply.ReleaseMouseCapture();
	}
	return Reply;
}

FReply SKGHotArea::OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (IsPressed() && IsPreciseTapOrClick(MouseEvent) && FSlateApplication::Get().HasTraveledFarEnoughToTriggerDrag(MouseEvent, PressedScreenSpacePosition))
	{
		Release();
	}
	if (OnMouseMoveEvent.IsBound())
	{
		return OnMouseMoveEvent.Execute(MyGeometry, MouseEvent);
	}
	return FReply::Unhandled();
}

void SKGHotArea::OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	const bool bWasHovered = IsHovered();

	SWidget::OnMouseEnter(MyGeometry, MouseEvent);
	if (OnMouseEnterEvent.IsBound())
	{
		OnMouseEnterEvent.Execute(MyGeometry, MouseEvent);
	}
	if (!bWasHovered && IsHovered())
	{
		ExecuteHoverStateChanged();
	}
}

void SKGHotArea::ExecuteHoverStateChanged()
{
	if (IsHovered())
	{
		OnHovered.ExecuteIfBound();
	}
	else
	{
		OnUnhovered.ExecuteIfBound();
	}
}

void SKGHotArea::OnMouseLeave(const FPointerEvent& MouseEvent)
{
	const bool bWasHovered = IsHovered();

	// Call parent implementation
	SWidget::OnMouseLeave(MouseEvent);

	// If we're setup to click on mouse-down, then we never capture the mouse and may not receive a
	// mouse up event, so we need to make sure our pressed state is reset properly here
	if (ClickMethod == EButtonClickMethod::MouseDown || IsPreciseTapOrClick(MouseEvent))
	{
		Release();
	}
	if (OnMouseLeaveEvent.IsBound())
	{
		OnMouseLeaveEvent.Execute(MouseEvent);
	}
	if (bWasHovered && !IsHovered())
	{
		ExecuteHoverStateChanged();
	}
}

void SKGHotArea::OnMouseCaptureLost(const FCaptureLostEvent& CaptureLostEvent)
{
	Release();
	if (OnMouseCaptureLostEvent.IsBound())
	{
		return OnMouseCaptureLostEvent.Execute(CaptureLostEvent);
	}
}

KGUI_API FReply SKGHotArea::OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent)
{
	if (OnFocusReceivedEvent.IsBound())
	{
		return OnFocusReceivedEvent.Execute(MyGeometry, InFocusEvent);
	}
	return SWidget::OnFocusReceived(MyGeometry, InFocusEvent);
}

void SKGHotArea::OnFocusChanging(const FWeakWidgetPath& PreviousFocusPath, const FWidgetPath& NewWidgetPath,
	const FFocusEvent& InFocusEvent)
{
	if (OnFocusChangingEvent.IsBound())
	{
		return OnFocusChangingEvent.Execute(PreviousFocusPath, NewWidgetPath, InFocusEvent);
	}
	SWidget::OnFocusChanging(PreviousFocusPath, NewWidgetPath, InFocusEvent);
}

FReply SKGHotArea::OnKeyChar(const FGeometry& MyGeometry, const FCharacterEvent& InCharacterEvent)
{
	if (OnKeyCharEvent.IsBound())
	{
		return OnKeyCharEvent.Execute(MyGeometry, InCharacterEvent);
	}
	return SWidget::OnKeyChar(MyGeometry, InCharacterEvent);
}

FReply SKGHotArea::OnPreviewKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (OnPreviewKeyDownEvent.IsBound())
	{
		return OnPreviewKeyDownEvent.Execute(MyGeometry, InKeyEvent);
	}
	return SWidget::OnPreviewKeyDown(MyGeometry, InKeyEvent);
}

FReply SKGHotArea::OnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (OnPreviewMouseButtonDownEvent.IsBound())
	{
		return OnPreviewMouseButtonDownEvent.Execute(MyGeometry, MouseEvent);
	}
	return SWidget::OnPreviewMouseButtonDown(MyGeometry, MouseEvent);
}

FReply SKGHotArea::OnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (OnMouseWheelEvent.IsBound())
	{
		return OnMouseWheelEvent.Execute(MyGeometry, MouseEvent);
	}
	return SWidget::OnMouseWheel(MyGeometry, MouseEvent);
}

FReply SKGHotArea::OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (OnDragDetectedEvent.IsBound())
	{
		return OnDragDetectedEvent.Execute(MyGeometry, MouseEvent);
	}
	return SWidget::OnDragDetected(MyGeometry, MouseEvent);
}

void SKGHotArea::OnDragEnter(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	if (OnDragEnterEvent.IsBound())
	{
		return OnDragEnterEvent.Execute(MyGeometry, DragDropEvent);
	}
	SWidget::OnDragEnter(MyGeometry, DragDropEvent);
}

void SKGHotArea::OnDragLeave(const FDragDropEvent& DragDropEvent)
{
	if (OnDragLeaveEvent.IsBound())
	{
		return OnDragLeaveEvent.Execute(DragDropEvent);
	}
	SWidget::OnDragLeave(DragDropEvent);
}

FReply SKGHotArea::OnDragOver(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	if (OnDragOverEvent.IsBound())
	{
		return OnDragOverEvent.Execute(MyGeometry, DragDropEvent);
	}
	return SWidget::OnDragOver(MyGeometry, DragDropEvent);
}

FReply SKGHotArea::OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	if (OnDropEvent.IsBound())
	{
		return OnDropEvent.Execute(MyGeometry, DragDropEvent);
	}
	return SWidget::OnDrop(MyGeometry, DragDropEvent);
}

FReply SKGHotArea::OnTouchGesture(const FGeometry& MyGeometry, const FPointerEvent& GestureEvent)
{
	if (OnTouchGestureEvent.IsBound())
	{
		return OnTouchGestureEvent.Execute(MyGeometry, GestureEvent);
	}
	return SWidget::OnTouchGesture(MyGeometry, GestureEvent);
}

FReply SKGHotArea::OnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	if (OnTouchStartedEvent.IsBound())
	{
		return OnTouchStartedEvent.Execute(MyGeometry, InTouchEvent);
	}
	return SWidget::OnTouchStarted(MyGeometry, InTouchEvent);
}

FReply SKGHotArea::OnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	if (OnTouchMovedEvent.IsBound())
	{
		return OnTouchMovedEvent.Execute(MyGeometry, InTouchEvent);
	}
	return SWidget::OnTouchMoved(MyGeometry, InTouchEvent);
}

FReply SKGHotArea::OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	if (OnTouchEndedEvent.IsBound())
	{
		return OnTouchEndedEvent.Execute(MyGeometry, InTouchEvent);
	}
	return SWidget::OnTouchEnded(MyGeometry, InTouchEvent);
}

FReply SKGHotArea::OnTouchForceChanged(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent)
{
	if (OnTouchForceChangedEvent.IsBound())
	{
		return OnTouchForceChangedEvent.Execute(MyGeometry, TouchEvent);
	}
	return SWidget::OnTouchForceChanged(MyGeometry, TouchEvent);
}

FReply SKGHotArea::OnTouchFirstMove(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent)
{
	if(OnTouchFirstMoveEvent.IsBound())
	{
		return OnTouchFirstMoveEvent.Execute(MyGeometry, TouchEvent);
	}
	return SWidget::OnTouchFirstMove(MyGeometry, TouchEvent);
}

FNavigationReply SKGHotArea::OnNavigation(const FGeometry& MyGeometry, const FNavigationEvent& InNavigationEvent)
{
	if (OnNavigationEvent.IsBound())
	{
		return OnNavigationEvent.Execute(MyGeometry, InNavigationEvent);
	}
	return SLeafWidget::OnNavigation(MyGeometry, InNavigationEvent);
}

FReply SKGHotArea::ExecuteOnClick(FKey ButtonEffectType)
{
	FReply Reply = FReply::Unhandled();
	if (ButtonEffectType == EKeys::RightMouseButton)
	{
		if (OnRightClicked.IsBound())
		{
			Reply = OnRightClicked.Execute();
#if WITH_ACCESSIBILITY
			// @TODOAccessibility: This should pass the Id of the user that clicked the button but we don't want to change the regular Slate API just yet
			FSlateApplicationBase::Get().GetAccessibleMessageHandler()->OnWidgetEventRaised(FSlateAccessibleMessageHandler::FSlateWidgetAccessibleEventArgs(AsShared(), EAccessibleEvent::Activate));
#endif
			return Reply;
		}
		else
		{
			return FReply::Handled();
		}
	}
	else 
	{
		if (OnClicked.IsBound())
		{
			Reply = OnClicked.Execute();

#if WITH_ACCESSIBILITY
			// @TODOAccessibility: This should pass the Id of the user that clicked the button but we don't want to change the regular Slate API just yet
			FSlateApplicationBase::Get().GetAccessibleMessageHandler()->OnWidgetEventRaised(FSlateAccessibleMessageHandler::FSlateWidgetAccessibleEventArgs(AsShared(), EAccessibleEvent::Activate));
#endif
			return Reply;
		}
	}

	return FReply::Handled();
}

void SKGHotArea::Press()
{
	if (!bIsPressed)
	{
		bIsPressed = true;
		OnPressed.ExecuteIfBound();
	}
}

void SKGHotArea::Release()
{
	if (bIsPressed)
	{
		bIsPressed = false;
		OnReleased.ExecuteIfBound();
	}
}

bool SKGHotArea::IsInteractable() const
{
	return IsEnabled();
}

FVector2D SKGHotArea::ComputeDesiredSize(float) const
{
	return FVector2D::Zero();
}

TEnumAsByte<EButtonClickMethod::Type> SKGHotArea::GetClickMethodFromInputType(const FPointerEvent& MouseEvent) const
{
	if (MouseEvent.IsTouchEvent())
	{
		switch (TouchMethod)
		{
		case EButtonTouchMethod::Down:
			return EButtonClickMethod::MouseDown;
		case EButtonTouchMethod::DownAndUp:
			return EButtonClickMethod::DownAndUp;
		case EButtonTouchMethod::PreciseTap:
			return EButtonClickMethod::PreciseClick;
		}
	}

	return ClickMethod;
}

bool SKGHotArea::IsPreciseTapOrClick(const FPointerEvent& MouseEvent) const
{
	return GetClickMethodFromInputType(MouseEvent) == EButtonClickMethod::PreciseClick;
}


FVector2D SKGHotArea::GetPressedScreenSpacePosition()
{
	return PressedScreenSpacePosition;
}

void SKGHotArea::SetClickMethod(EButtonClickMethod::Type InClickMethod)
{
	ClickMethod = InClickMethod;
}

void SKGHotArea::SetTouchMethod(EButtonTouchMethod::Type InTouchMethod)
{
	TouchMethod = InTouchMethod;
}

void SKGHotArea::SetPressMethod(EButtonPressMethod::Type InPressMethod)
{
	PressMethod = InPressMethod;
}
