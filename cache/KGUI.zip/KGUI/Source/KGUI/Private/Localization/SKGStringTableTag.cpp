#include "Localization/SKGStringTableTag.h"

#include "KGUI.h"
#include "KGUISettings.h"
#include "Brushes/SlateColorBrush.h"
#include "Brushes/SlateRoundedBoxBrush.h"
#include "Components/EditableText.h"
#include "Components/EditableTextBox.h"
#include "Components/GPUTurboTextBlock.h"
#include "Components/MultiLineEditableText.h"
#include "Components/MultiLineEditableTextBox.h"
#include "Components/RichTextBlock.h"
#include "Components/Widget.h"
#include "Core/Common.h"
#include "Framework/Application/SlateApplication.h"
#include "Styling/SlateStyleMacros.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SConstraintCanvas.h"
#include "Widgets/Text/STextBlock.h"
#include "HAL/PlatformApplicationMisc.h"
#include "UMG/Components/KGTextBlock.h"
#include "UObject/UObjectIterator.h"

FKGStringTableTagResources::FKGStringTableTagResources()
{
	Good = MakeShared<FKGStringTableTagStyle>(FLinearColor(0, 0.6, 0, 0.5));
	Bad = MakeShared<FKGStringTableTagStyle>(FLinearColor(0.75, 0, 0, 0.5));
	GoodHovered = MakeShared<FKGStringTableTagStyle>(FLinearColor(0, 0.6, 0));
	BadHovered = MakeShared<FKGStringTableTagStyle>(FLinearColor(0.75, 0, 0));
	White = MakeShared<FKGStringTableTagStyle>(FLinearColor::Gray);
	WhiteHovered = MakeShared<FKGStringTableTagStyle>(FLinearColor::White);

	FSlateBrush NoneBrush;
	NoneBrush.DrawAs = ESlateBrushDrawType::NoDrawType;
	ButtonStyle = FButtonStyle()
		.SetNormal(NoneBrush)
		.SetHovered(NoneBrush)
		.SetPressed(NoneBrush)
		.SetDisabled(NoneBrush)
		.SetNormalPadding(FMargin(0))
		.SetPressedPadding(1);
}

FKGStringTableTagResources SKGStringTableTagItem::Resources;

class SHighLayerBorder : public SBorder
{
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override
	{
		auto TempArgs = Args;
		TempArgs.SetSlateRectFadePosition(FVector4f(0, 0, 1, 1));
		TempArgs.SetSlateRectFadeSize(FVector4f::Zero());
		SBorder::OnPaint(TempArgs, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId + 300000, InWidgetStyle, bParentEnabled);
		return LayerId;
	}
};

SLATE_IMPLEMENT_WIDGET(SKGStringTableTag)

void SKGStringTableTagItem::Construct(const FArguments& InArgs, TWeakObjectPtr<UWidget> InWeakWidget, const TFunction<FText(UWidget*)>& InPredicate)
{
	WeakWidget = InWeakWidget;
	Predicate = InPredicate;
	auto Args = InArgs;
	Args
	.ButtonStyle(&Resources.ButtonStyle)
	.Clipping(EWidgetClipping::ClipToBoundsWithoutIntersecting)
	.ContentPadding(FMargin(0))
	.OnClicked(this, &SKGStringTableTagItem::HandleOnButtonClicked)
	[
		SNew(SBorder)
		.Visibility(this, &SKGStringTableTagItem::GetTagVisibility)
		.BorderImage(this, &SKGStringTableTagItem::GetButtonBorderImage)
		[
			SNew(STextBlock)
			.Visibility(EVisibility::SelfHitTestInvisible)
			.ColorAndOpacity(FLinearColor::White)
			.Font(DEFAULT_FONT("Bold", 18))
			.Text(this, &SKGStringTableTagItem::GetKeyDisplayText)
		]
	];
	Super::Construct(Args);
}

bool SKGStringTableTagItem::IsTagValid() const
{
	static FString TempString;
	return GetStringTableKey(TempString);
}

FText SKGStringTableTagItem::GetText() const
{
	auto StrongWidget = this->WeakWidget.Get();
	if (!StrongWidget)
	{
		return FText::GetEmpty();
	}
	return Predicate(StrongWidget);
}

bool SKGStringTableTagItem::GetStringTableKey(FString& Key) const
{
	auto Text = GetText();
	if (Text.IsEmpty())
	{
		return false;
	}
	if (!Text.IsFromStringTable())
	{
		return false;
	}
	auto OptionalKey = FTextInspector::GetKey(Text);
	if (!OptionalKey.IsSet())
	{
		return false;
	}
	Key = OptionalKey.GetValue();
	return true;
}

FText SKGStringTableTagItem::GetKeyDisplayText() const
{
	FString TempString;
	if (!GetStringTableKey(TempString))
	{
		return FText::GetEmpty();
	}
	int SplitterIndex = INDEX_NONE;
	if (!TempString.FindChar('/', SplitterIndex))
	{
		return FText::FromString(TempString);
	}
	return FText::FromString(TempString.RightChop(SplitterIndex + 1));
}

EVisibility SKGStringTableTagItem::GetTagVisibility() const
{
	return IsTagValid() ? EVisibility::SelfHitTestInvisible : EVisibility::Collapsed;
}

FReply SKGStringTableTagItem::HandleOnButtonClicked() const
{
	static FString KeyString;
	GetStringTableKey(KeyString);
	FPlatformApplicationMisc::ClipboardCopy(*KeyString);
	if (GetDefault<UKGUISettings>()->bEnableMessageDialogOnClipboardCopyFinished)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("成功将文本键“%s”复制到剪切板。"), *KeyString)));
	}
	return FReply::Handled();
}

const FSlateBrush* SKGStringTableTagItem::GetFrameBorderImage() const
{
	return &(
		IsTagValid()
		? (this->IsHovered() ? Resources.GoodHovered : Resources.Good)
		: (this->IsHovered() ? Resources.BadHovered : Resources.Bad)
		)->FrameBorderImageBrush;
}

const FSlateBrush* SKGStringTableTagItem::GetButtonBorderImage() const
{
	return &(
		IsTagValid()
		? (this->IsHovered() ? Resources.GoodHovered : Resources.Good)
		: (this->IsHovered() ? Resources.BadHovered : Resources.Bad)
		)->ButtonBorderImageBrush;
}

void SKGStringTableTag::PrivateRegisterAttributes(FSlateAttributeInitializer& AttributeInitializer) {}

void SKGStringTableTag::ConstructInternal(const FArguments& InArgs, UWidget* InWidget, const TArray<TFunction<FText(UWidget*)>>& InPredicates)
{
	static FKGStringTableTagStyle FrameStyle(FLinearColor::White);

	this->WeakWidget = InWidget;
	this->SetVisibility(EVisibility::SelfHitTestInvisible);
	TSharedPtr<SHorizontalBox> BoxPanel;
	this->ChildSlot
	[
		SNew(SOverlay)
		.Visibility(EVisibility::SelfHitTestInvisible)
		+ SOverlay::Slot()
		[
			SNew(SHighLayerBorder)
			.Visibility(this, &SKGStringTableTag::GetTagVisibility)
			.BorderImage(&FrameStyle.FrameBorderImageBrush)
			[
				SNew(SBox)
				.Visibility(EVisibility::SelfHitTestInvisible)
				.MaxDesiredWidth(0)
				.MaxDesiredHeight(0)
				[
					SNew(SConstraintCanvas)
					+ SConstraintCanvas::Slot()
					.Alignment(FVector2D(0, 0))
					.Anchors(FAnchors(0, 1, 0, 1))
					.Offset(FVector2D(-2, 2))
					.AutoSize(true)
					[
						SAssignNew(BoxPanel, SHorizontalBox)
					]
				]
			]
		]
		+ SOverlay::Slot()
		[
			InArgs._Content.Widget
		]
	];

	OriginalWidget = InArgs._Content.Widget;

	if (FModuleManager::Get().LoadModulePtr<FKGUIModule>("KGUI") != nullptr)
	{
		TSharedPtr<SButton> JumpToButton;
		BoxPanel->AddSlot()
		[
			SAssignNew(JumpToButton, SButton)
			.ButtonStyle(&SKGStringTableTagItem::Resources.ButtonStyle)
			.OnClicked_Lambda([OriginalWidget = this->OriginalWidget]()
			{
				if (auto KGUI = FModuleManager::Get().LoadModulePtr<FKGUIModule>("KGUI"))
				{
					if (auto StrongOriginalWidget = OriginalWidget.Pin())
					{
						KGUI->OpenWidgetAsset(StrongOriginalWidget);
						return FReply::Handled();
					}
				}
				return FReply::Unhandled();
			})
			.ContentPadding(FMargin(0, 0, 0, 0))
		];

		auto Font = FAppStyle::Get().GetFontStyle("FontAwesome.10");
		Font.Size = 20;
		JumpToButton->SetContent(
			SNew(SBorder)
			.BorderImage_Lambda([WeakJumpToButton = JumpToButton->AsWeak()]()
			{
				auto JumpToButton = WeakJumpToButton.Pin();
				if (JumpToButton && JumpToButton->IsHovered())
				{
					return &SKGStringTableTagItem::Resources.WhiteHovered->ButtonBorderImageBrush;
				}
				return &SKGStringTableTagItem::Resources.White->ButtonBorderImageBrush;
			})
			.Padding(4, 2, 4, 0)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			[
				SNew(STextBlock)
				.Font(Font)
				.ColorAndOpacity(FLinearColor::Black)
				.Text(FText::FromString(FString(TEXT("\xF08E"))))	
			]
		);
	}

	for (const auto& Predicate : InPredicates)
	{
		auto TagItem = SNew(SKGStringTableTagItem, WeakWidget, Predicate);
		BoxPanel->AddSlot()
		.AutoWidth()
		.Padding(FMargin(5, 0, 0, 0))
		[
			TagItem
		];
		TagItems.Add(TagItem);
	}
}

EVisibility SKGStringTableTag::GetTagVisibility() const
{
	for (const auto& TagItem : TagItems)
	{
		if (!TagItem->GetText().IsEmpty())
		{
			return EVisibility::SelfHitTestInvisible;
		}
	}
	return EVisibility::Collapsed;
}

void FKGStringTableTagUtilities::ShowStringTableTag()
{
	UE_LOG(LogKGUI, Log, TEXT("Show String Table Tag"));
	for (TObjectIterator<UWidget> It; It; ++It)
	{
		UWidget* Widget = *It;
#if WITH_EDITOR
		if (Widget->IsDesignTime())
		{
			continue;
		}
#endif
		if (!IsValid(Widget))
		{
			continue;
		}
		GetOrCreateStringTableTag(Widget, nullptr);
	}
}

TSharedRef<SWidget> FKGStringTableTagUtilities::GetOrCreateStringTableTag(UWidget* Widget, TSharedPtr<SWidget> SlateWidget)
{
	if (SlateWidget.IsValid())
	{
		return GetOrCreateStringTableTagInternal(Widget, SlateWidget.ToSharedRef());
	}
	else
	{
		if (auto CachedWidget = Widget->GetCachedWidget())
		{
			if (CachedWidget->GetMetaData<FKGStringTableTagMetaData>())
			{
				return CachedWidget.ToSharedRef();
			}
			else
			{
				if (auto ParentWidget = CachedWidget->GetParentWidget())
				{
					if (auto Children = ParentWidget->GetChildren())
					{
						FSlotBase* Slot = nullptr;
						for (int32 Idx = 0; Idx < Children->Num(); ++Idx)
						{
							if (Children->GetChildAt(Idx) == CachedWidget)
							{
								Slot = const_cast<FSlotBase*>(&Children->GetSlotAt(Idx));
								break;
							}
						}
						if (Slot)
						{
							auto Result = GetOrCreateStringTableTagInternal(Widget, CachedWidget.ToSharedRef());
							if (Result != CachedWidget.ToSharedRef())
							{
								Slot->AttachWidget(Result);
								ParentWidget->MarkPrepassAsDirty();
								ParentWidget->SlatePrepass();
								ParentWidget->Invalidate(EInvalidateWidgetReason::LayoutAndVolatility);
								CachedWidget->AddMetadata(MakeShared<FKGStringTableTagMetaData>());
								return Result;
							}
						}
					}
				}
				return CachedWidget.ToSharedRef();
			}
		}
		else
		{
			return SNullWidget::NullWidget;
		}
	}
}

TSharedRef<SWidget> FKGStringTableTagUtilities::GetOrCreateStringTableTagInternal(UWidget* Widget, TSharedRef<SWidget> SlateWidget)
{
	if (auto TextBlock = Cast<UTextBlock>(Widget))
	{
		return SNew(SKGStringTableTag, TextBlock, 
			TArray { [](auto Widget) { return Widget->GetText(); } }
		) [ SlateWidget ];
	}
	else if (auto RichTextBlock = Cast<URichTextBlock>(Widget))
	{
		return SNew(SKGStringTableTag, RichTextBlock,
			TArray{ [](auto Widget) { return Widget->GetText(); } }
		)[SlateWidget];
	}
	else if (auto GPUTurboTextBlock = Cast<UGPUTurboTextBlock>(Widget))
	{
		return SNew(SKGStringTableTag, GPUTurboTextBlock,
			TArray{ [](auto Widget) { return Widget->GetText(); } }
		)[SlateWidget];
	}
	else if (auto EditableText = Cast<UEditableText>(Widget))
	{
		return SNew(SKGStringTableTag, EditableText,
			TArray<TFunction<FText(UEditableText*)>>{ [](auto Widget) { return Widget->GetText(); }, [](auto Widget) { return Widget->GetHintText(); } }
		)[SlateWidget];
	}
	else if (auto MultiLineEditableText = Cast<UMultiLineEditableText>(Widget))
	{
		return SNew(SKGStringTableTag, MultiLineEditableText,
			TArray<TFunction<FText(UMultiLineEditableText*)>>{ [](auto Widget) { return Widget->GetText(); }, [](auto Widget) { return Widget->GetHintText(); } }
		)[SlateWidget];
	}
	else if (auto EditableTextBox = Cast<UEditableTextBox>(Widget))
	{
		return SNew(SKGStringTableTag, EditableTextBox,
			TArray<TFunction<FText(UEditableTextBox*)>>{ [](auto Widget) { return Widget->GetText(); }, [](auto Widget) { return Widget->GetHintText(); } }
		)[SlateWidget];
	}
	else if (auto MultiLineEditableTextBox = Cast<UMultiLineEditableTextBox>(Widget))
	{
		return SNew(SKGStringTableTag, MultiLineEditableTextBox,
			TArray<TFunction<FText(UMultiLineEditableTextBox*)>>{ [](auto Widget) { return Widget->GetText(); }, [](auto Widget) { return Widget->GetHintText(); } }
		)[SlateWidget];
	}
	return SlateWidget;
}

static FAutoConsoleCommand GShowStringTableTagCommand
(
	TEXT("KGUI.Text.ShowStringTableTag"),
	TEXT("Show the String Table Entry on Text Widget."),
	FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
	{
		FKGStringTableTagUtilities::ShowStringTableTag();
	})
);
