#include "Localization/KGStringTable.h"

#include "KGUI.h"
#include "KGUISettings.h"
#include "KGUIWidgetBlueprintGeneratedClassExtension.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Core/Common.h"
#include "Internationalization/StringTableCore.h"
#include "Internationalization/StringTableRegistry.h"
#include "Modules/ModuleManager.h"
#include "UObject/Package.h"

class FKGStringTableEntry : public FStringTableEntry
{
public:
	FKGStringTableEntry(FStringTableConstRef InOwnerTable, FString InSourceString, FTextId InDisplayStringId)
		: FStringTableEntry(InOwnerTable, InSourceString, InDisplayStringId)
	{
	}

	static FStringTableEntryRef NewStringTableEntry(FStringTableConstRef InOwnerTable, FString InSourceString, FTextId InDisplayStringId)
	{
		return MakeShared<FKGStringTableEntry, ESPMode::ThreadSafe>(MoveTemp(InOwnerTable), MoveTemp(InSourceString), MoveTemp(InDisplayStringId));
	}

	virtual FTextConstDisplayStringPtr GetDisplayString() const override
	{
		if (FTextLocalizationManager::IsDisplayStringSupportEnabled())
		{
			auto TempDisplayStringId = GetDisplayStringId();
#if WITH_EDITOR
			const bool bEnableDisplayReplacementAtRuntime = GetDefault<UKGUISettings>()->bEnableDisplayReplacementAtRuntime;
#else
			const static bool bEnableDisplayReplacementAtRuntime = GetDefault<UKGUISettings>()->bEnableDisplayReplacementAtRuntime;
#endif
			if (bEnableDisplayReplacementAtRuntime)
			{
				if (auto KGUI = FModuleManager::GetModulePtr<FKGUIModule>("KGUI"))
				{
					if (auto WidgetBlueprintTextProvider = KGUI->GetWidgetBlueprintTextProvider())
					{
						if (auto DisplayStringPtr = WidgetBlueprintTextProvider->GetWidgetBlueprintTextDisplayString(TempDisplayStringId.GetKey().ToString()))
						{
							FString DisplayString = *DisplayStringPtr;
							return MakeTextDisplayString(MoveTemp(DisplayString));
						}
					}
				}
			}
			return FTextLocalizationManager::Get().GetDisplayString(TempDisplayStringId.GetNamespace(), TempDisplayStringId.GetKey(), nullptr);
		}
		return nullptr;
	}
};

class FKGStringTable : public FStringTable
{
public:
	static FStringTableRef NewStringTable(UKGStringTable* StringTableObject)
	{
		auto StringTable = MakeShared<FKGStringTable, ESPMode::ThreadSafe>();
		StringTable->WeakStringTable = StringTableObject;
		return StringTable;
	}

	virtual UStringTable* GetOwnerAsset() const override
	{
		return WeakStringTable.Get();
	}

	virtual FStringTableEntryRef CreateStringTableEntry(FStringTableConstRef InOwnerTable, FString InSourceString, FTextId InDisplayStringId) override
	{
		return FKGStringTableEntry::NewStringTableEntry(InOwnerTable, InSourceString, InDisplayStringId);
	}

protected:
	TWeakObjectPtr<UKGStringTable> WeakStringTable;
};

FString UKGStringTable::StringTableDefaultName = TEXT("StringTable");

FString UKGStringTable::GetWidgetBlueprintClassStringTablePathName(UWidgetBlueprintGeneratedClass* Class)
{
	if (Class == nullptr)
	{
		return FString();
	}
	auto ClassPathName = Class->GetPathName();
	return FString::Printf(TEXT("%s:%s.%s"), *ClassPathName, *UKGUIWidgetBlueprintGeneratedClassExtension::ExtensionName, *StringTableDefaultName);
}

UKGStringTable::UKGStringTable()
	: Super(FKGEmptyConstructionTag{})
{
	StringTable = FKGStringTable::NewStringTable(this);
	StringTableId = *GetPathName();

	StringTable->SetOwnerAsset(this);
	StringTable->IsLoaded(!HasAnyFlags(RF_NeedLoad | RF_NeedPostLoad));
	StringTable->SetNamespace(GetName());
}

void UKGStringTable::FinishDestroy()
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{
		UnregisterForGC();
		UnregisterStringTable();
	}
	StringTable.Reset();
	Super::Super::FinishDestroy();  // Super::Super is UStringTable::Super, so jump over the UStringTable::FinishDestroy
}

FString UKGStringTable::GenerateStringTableId() const
{
	return this->GetPathName();
}

void UKGStringTable::RegisterForGC()
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{
		if (bGCRegistered)
		{
			return;
		}
		if (auto InstancePtr = IStringTableEngineBridge::GetInstancePtr())
		{
			InstancePtr->RegisterForGC(this);
		}
		bGCRegistered = true;
	}
}

void UKGStringTable::UnregisterForGC()
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{
		if (!bGCRegistered)
		{
			return;
		}
		if (auto InstancePtr = IStringTableEngineBridge::GetInstancePtr())
		{
			InstancePtr->UnregisterForGC(this);
		}
		bGCRegistered = false;
	}
}

void UKGStringTable::RegisterStringTable()
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{
		auto TempStringTableId = GetStringTableId();
		if (*GenerateStringTableId() == TempStringTableId)
		{
			if (auto TempStringTable = FStringTableRegistry::Get().FindStringTable(TempStringTableId))
			{
				if (bStringTableRegistered && TempStringTable == StringTable)
				{
					return;
				}
				if (auto TempStringTableObject = Cast<UKGStringTable>(TempStringTable->GetOwnerAsset()))
				{
					if (TempStringTableObject->GetStringTableId() != TempStringTableObject->GenerateStringTableId())
					{
						TempStringTableObject->UnregisterStringTable();
					}
					else
					{
						UE_LOG(LogKGUI, Error, TEXT("String table '%s' have to be unregistered before destroy."), *TempStringTableId.ToString());
						TempStringTableObject->UnregisterStringTable();
					}
				}
				else
				{
					UE_LOG(LogKGUI, Error, TEXT("String table '%s' have to be unregistered without object."), *TempStringTableId.ToString());
					FStringTableRegistry::Get().UnregisterStringTable(TempStringTableId);
				}
			}
			ensureAlways(!FStringTableRegistry::Get().FindStringTable(TempStringTableId));
			UE_LOG(LogKGUI, Log, TEXT("[本地化] RegisterStringTable %s %p"), *TempStringTableId.ToString(), this);
			FStringTableRegistry::Get().RegisterStringTable(TempStringTableId, this->StringTable.ToSharedRef());
			bStringTableRegistered = true;
		}
	}
}

void UKGStringTable::UnregisterStringTable()
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{
		if (bStringTableRegistered)
		{
			auto TempStringTable = FStringTableRegistry::Get().FindStringTable(GetStringTableId());
			if (ensureAlways(TempStringTable && TempStringTable == StringTable))
			{
				UE_LOG(LogKGUI, Log, TEXT("[本地化] UnregisterStringTable %s %p"), *GetStringTableId().ToString(), this);
				FStringTableRegistry::Get().UnregisterStringTable(GetStringTableId());
			}
			bStringTableRegistered = false;
		}
	}
}

void UKGStringTable::PostLoad()
{
	RegisterStringTable();
	Super::PostLoad();
}
