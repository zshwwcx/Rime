#pragma once

#include "CoreMinimal.h"
#include "CoreGlobals.h"
#include "Internationalization/StringTableCore.h"
#include "Modules/ModuleManager.h" 

#include "UMG/StateManagement/KGStateManagement.h"
#include "UMG/StateManagement/KGScriptableStateGroup.h"
#include "UMG/StateManagement/KGStateGroupDeclaration.h"
#include "UMG/StyleSheet/KGStylePathTypeCustomizationRegistry.h"
#include "Localization/IWidgetBlueprintTextProvider.h"

class IWidgetBlueprintTextProvider;
class UKGUserWidget;

struct FKGStateControllerPropertyCustomization
{
	TFieldPath<FProperty> PropertyPath;

	DECLARE_DELEGATE_TwoParams(FKGStateControllerPropertyCustomSetter, UObject* Object, const void* Value);
	FKGStateControllerPropertyCustomSetter Setter;

	FText DisplayName;

	TSet<TFieldPath<FProperty>> WatchedPropertyPaths;

	static FKGStateControllerPropertyCustomization Create(
		const TFieldPath<FProperty>& PropertyPath,
		const FKGStateControllerPropertyCustomSetter& Setter,
		const FText& DisplayName,
		const TSet<TFieldPath<FProperty>>& WatchedPropertyPaths
	);
};

class FKGUIModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	static KGUI_API FKGUIModule& Get();

	#pragma region 用于编辑器的回调

public:
	// 在编辑器中创建控件时回调。不过由于没有修改UWidget（改Engine部分逻辑），这个回调的触发得在每个UWidget派生类的OnCreatedFromPalette中触发。
	DECLARE_MULTICAST_DELEGATE_OneParam(FOnWidgetCreatedFromPalette, UWidget*)

	FOnWidgetCreatedFromPalette& GetOnWidgetCreatedFromPalette()
	{
		return OnWidgetCreatedFromPalette;
	}

private:
	FOnWidgetCreatedFromPalette OnWidgetCreatedFromPalette;

	#pragma endregion

	#pragma region 状态组

public:
	KGUI_API void RegisterScriptableStateGroup(TSharedPtr<IKGScriptableStateGroup> ScriptableStateGroup);

	KGUI_API TSharedPtr<IKGScriptableStateGroup> GetScriptableStateGroup(UClass* Class, const FString& StateGroupName);
	KGUI_API TArray<TSharedPtr<IKGScriptableStateGroup>> GetClassScriptableStateGroups(UClass* Class);
	KGUI_API TArray<TSharedPtr<IKGScriptableStateGroup>> GetObjectAvailableScriptableStateGroups(UWidget* Widget);
	KGUI_API bool HasScriptableStateGroupByName(const FString& StateGroupName) const;

#if WITH_EDITOR
	KGUI_API TArray<FKGStateGroupDeclaration> GetObjectAvailableStateGroupDeclarationsFromDataTable(UWidget* Widget) const;
	KGUI_API bool TryGetStateGroupDeclarationFromDataTable(const FString& StateGroupName, FKGStateGroupDeclaration& StateGroupDeclaration) const;
#endif

	KGUI_API void SaveWidgetComponentMap(TWeakObjectPtr<UKGWidgetComponent> WidgetComponent,  TWeakObjectPtr<UUserWidget> UserWidget);
	KGUI_API TWeakObjectPtr<UUserWidget> GetUserWidgetFromMapByWidgetComponent(TWeakObjectPtr<UKGWidgetComponent> WidgetComponent);
	KGUI_API void RemoveWidgetComponentMap(TWeakObjectPtr<UUserWidget> UserWidget);

	KGUI_API bool RegisterStateControllerPropertyCustomization(const FKGStateControllerPropertyCustomization& StateControllerPropertyCustomization);
	KGUI_API TSharedPtr<FKGStateControllerPropertyCustomization> GetStateControllerPropertyCustomization(const TFieldPath<FProperty>& PropertyPath) const;
	KGUI_API TArray<TSharedPtr<FKGStateControllerPropertyCustomization>> GetStateControllerPropertyCustomizations(UClass* Class) const;

private:
	TMap<FString, TArray<TSharedPtr<IKGScriptableStateGroup>>> ScriptableStateGroups;
	TMap<TTuple<TWeakObjectPtr<UClass>, FString>, TSharedPtr<IKGScriptableStateGroup>> ScriptableStateGroupFastLookupTable;
	mutable TMap< TFieldPath<FProperty>, TSharedPtr<FKGStateControllerPropertyCustomization>> StateControllerPropertyCustomizationLookupTable;

	#pragma endregion

	// 在UserWidget RebuildWidget()阶段，存储下WidgetComponent和UserWiget的映射关系，方便WidgetComponent去反查对应的UserWidget
	TMap<TWeakObjectPtr<UKGWidgetComponent>, TWeakObjectPtr<UUserWidget>> WidgetComponentToUserWidgetGroups;

	#pragma region 简化列表Entry类型限制
	KGUI_API static void SimplifyListViewEntryTypeRestriction();
	#pragma endregion

	#pragma region 资源检查
public:
	DECLARE_MULTICAST_DELEGATE_ThreeParams(FKGOnUserWidgetValidating, const UKGUserWidget*, const UWidgetTree&, class IWidgetCompilerLog&);
	KGUI_API FKGOnUserWidgetValidating& GetOnUserWidgetValidating();

private:
	FKGOnUserWidgetValidating OnUserWidgetValidating;
	#pragma endregion

	#pragma region Style Sheet

public:
	inline FKGStylePathTypeCustomizationRegistry& GetStylePathTypeCustomizationRegistry() { return StylePathTypeCustomizationRegistry; }

private:
	FKGStylePathTypeCustomizationRegistry StylePathTypeCustomizationRegistry;

	#pragma endregion

	#pragma region 日志

public:
	static KGUI_API FString GetLuaTraceback();

	static FString NotInMainThreadTag;
	static FString EmptyLuaStackTrace;
	static FString DefaultLuaStack;
	#pragma endregion

	#pragma region 本地化

public:
	void SetWidgetBlueprintTextProvider(IWidgetBlueprintTextProvider* InWidgetBlueprintTextProvider)
	{
		WidgetBlueprintTextProvider = InWidgetBlueprintTextProvider;
	}

	IWidgetBlueprintTextProvider* GetWidgetBlueprintTextProvider() const
	{
		return WidgetBlueprintTextProvider.Get();
	}

	void SetOnOpenWidgetAsset(const TDelegate<void(TSharedPtr<SWidget>)>& InOnOpenWidgetAsset)
	{
		OnOpenWidgetAsset = InOnOpenWidgetAsset;
	}

	void OpenWidgetAsset(TSharedPtr<SWidget> Widget) const
	{
		if (OnOpenWidgetAsset.IsBound())
		{
			OnOpenWidgetAsset.Execute(Widget);
		}
	}

	bool IsOnOpenWidgetAssetDelegateBound() const { return OnOpenWidgetAsset.IsBound(); }

	void KGUI_API InvalidateAllWidgets(bool bClearResourcesImmediately);
	void KGUI_API RequestDirtyTextRevision();

private:
	TWeakInterfacePtr<IWidgetBlueprintTextProvider> WidgetBlueprintTextProvider;
	TDelegate<void(TSharedPtr<SWidget>)> OnOpenWidgetAsset;

	// 这块的部分代码来自StringTable.cpp并改动

private:

	struct FAsyncLoadingStringTable
	{
		int32 AsyncLoadingId = INDEX_NONE;
		FName RequestedTableId;
		TArray<IStringTableEngineBridge::FLoadStringTableAssetCallback> LoadedCallbacks;
	};

	TMap<FName, FAsyncLoadingStringTable> AsyncLoadingStringTables;
	mutable FCriticalSection AsyncLoadingStringTablesCS;

	bool OnPreLoadStringTableAsset(const FName InTableId, IStringTableEngineBridge::FLoadStringTableAssetCallback InLoadedCallback, int32& AsyncLoadingId);
	int32 LoadStringTableAssetImpl(const FName InTableId, IStringTableEngineBridge::FLoadStringTableAssetCallback InLoadedCallback);
	void HandleStringTableAssetAsyncLoadCompleted(const FName& InLoadedPackageName, UPackage* InLoadedPackage, EAsyncLoadingResult::Type InLoadingResult);

	#pragma endregion
};
