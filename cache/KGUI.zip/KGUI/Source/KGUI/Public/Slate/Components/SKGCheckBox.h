// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/Input/SCheckBox.h"
#include "Delegates/Delegate.h"

/**
 * SKGCheckBox
 */
class SKGCheckBox : public SCheckBox
{
	using Super = SCheckBox;
public:
	SLATE_BEGIN_ARGS(SKGCheckBox)
		: _Content()
		, _Style(&FCoreStyle::Get().GetWidgetStyle< FCheckBoxStyle >("Checkbox"))
		, _Type()
		, _OnCheckStateChanged()
		, _IsChecked(ECheckBoxState::Unchecked)
		, _HAlign(HAlign_Fill)
		, _CheckBoxContentUsesAutoWidth(true)
		, _Padding()
		, _ClickMethod(EButtonClickMethod::DownAndUp)
		, _TouchMethod(EButtonTouchMethod::DownAndUp)
		, _PressMethod(EButtonPressMethod::DownAndUp)
		, _ForegroundColor(FSlateColor::UseStyle())
		, _BorderBackgroundColor()
		, _IsFocusable(true)
		, _UncheckedImage(nullptr)
		, _UncheckedHoveredImage(nullptr)
		, _UncheckedPressedImage(nullptr)
		, _CheckedImage(nullptr)
		, _CheckedHoveredImage(nullptr)
		, _CheckedPressedImage(nullptr)
		, _UndeterminedImage(nullptr)
		, _UndeterminedHoveredImage(nullptr)
		, _UndeterminedPressedImage(nullptr)
		, _BackgroundImage(nullptr)
		, _BackgroundHoveredImage(nullptr)
		, _BackgroundPressedImage(nullptr)
		{
		}

		/** Content to be placed next to the check box, or for a toggle button, the content to be placed inside the button */
		SLATE_DEFAULT_SLOT(FArguments, Content)

		/** The style structure for this checkbox' visual style */
		SLATE_STYLE_ARGUMENT(FCheckBoxStyle, Style)

		/** Type of check box (set by the Style arg but the Style can be overridden with this) */
		SLATE_ARGUMENT(TOptional<ESlateCheckBoxType::Type>, Type)

		/** Called when the checked state has changed */
		SLATE_EVENT(FOnCheckStateChanged, OnCheckStateChanged)

		/** Whether the check box is currently in a checked state */
		SLATE_ATTRIBUTE(ECheckBoxState, IsChecked)

		/** How the content of the toggle button should align within the given space*/
		SLATE_ARGUMENT(EHorizontalAlignment, HAlign)

		/** Whether or not the content portion of the checkbox should layout using auto-width. When true the content will always be arranged at its desired size as opposed to resizing to the available space. */
		SLATE_ARGUMENT(bool, CheckBoxContentUsesAutoWidth)

		/** Spacing between the check box image and its content (set by the Style arg but the Style can be overridden with this) */
		SLATE_ATTRIBUTE(FMargin, Padding)

		/** Sets the rules to use for determining whether the button was clicked.  This is an advanced setting and generally should be left as the default. */
		SLATE_ARGUMENT(EButtonClickMethod::Type, ClickMethod)

		/** How should the button be clicked with touch events? */
		SLATE_ARGUMENT(EButtonTouchMethod::Type, TouchMethod)

		/** How should the button be clicked with keyboard/controller button events? */
		SLATE_ARGUMENT(EButtonPressMethod::Type, PressMethod)

		/** Foreground color for the checkbox's content and parts (set by the Style arg but the Style can be overridden with this) */
		SLATE_ATTRIBUTE(FSlateColor, ForegroundColor)

		/** The color of the background border (set by the Style arg but the Style can be overridden with this) */
		SLATE_ATTRIBUTE(FSlateColor, BorderBackgroundColor)

		SLATE_ARGUMENT(bool, IsFocusable)

		SLATE_EVENT(FOnGetContent, OnGetMenuContent)

		/** The sound to play when the check box is checked */
		SLATE_ARGUMENT(TOptional<FSlateSound>, CheckedSoundOverride)

		/** The sound to play when the check box is unchecked */
		SLATE_ARGUMENT(TOptional<FSlateSound>, UncheckedSoundOverride)

		/** The sound to play when the check box is hovered */
		SLATE_ARGUMENT(TOptional<FSlateSound>, HoveredSoundOverride)

		/** The unchecked image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, UncheckedImage)

		/** The unchecked hovered image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, UncheckedHoveredImage)

		/** The unchecked pressed image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, UncheckedPressedImage)

		/** The checked image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, CheckedImage)

		/** The checked hovered image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, CheckedHoveredImage)

		/** The checked pressed image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, CheckedPressedImage)

		/** The undetermined image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, UndeterminedImage)

		/** The undetermined hovered image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, UndeterminedHoveredImage)

		/** The undetermined pressed image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, UndeterminedPressedImage)

		/** The background image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, BackgroundImage)

		/** The background hovered image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, BackgroundHoveredImage)

		/** The background pressed image for the checkbox - overrides the style's */
		SLATE_ARGUMENT(const FSlateBrush*, BackgroundPressedImage)

		/** Called when the checkbox is pressed */
		SLATE_EVENT(FSimpleDelegate, OnPressed)

		/** Called when the checkbox is released */
		SLATE_EVENT(FSimpleDelegate, OnReleased)

		/** Called when the checkbox is hovered */
		SLATE_EVENT(FSimpleDelegate, OnHovered)

		/** Called when the checkbox is unhovered */
		SLATE_EVENT(FSimpleDelegate, OnUnhovered)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual void OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual void OnMouseLeave(const FPointerEvent& MouseEvent) override;

	void SetOnHovered(FSimpleDelegate InOnHovered);
	void SetOnUnhovered(FSimpleDelegate InOnUnhovered);
	void SetOnPressed(FSimpleDelegate InOnPressed);
	void SetOnReleased(FSimpleDelegate InOnReleased);
protected:
	void Press();
	void Release();
	void ExecuteHoverStateChanged(bool bPlaySound);
	virtual bool SupportsKeyboardFocus() const override;

private:
	/** The delegate to execute when the button is pressed */
	FSimpleDelegate OnPressed;

	/** The delegate to execute when the button is released */
	FSimpleDelegate OnReleased;

	/** The delegate to execute when the button is hovered */
	FSimpleDelegate OnHovered;

	/** The delegate to execute when the button exit the hovered state */
	FSimpleDelegate OnUnhovered;
};
