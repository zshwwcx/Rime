// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Styling/SlateBrush.h"
#include "Misc/Attribute.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Styling/SlateColor.h"
#include "Styling/SlateWidgetStyleAsset.h"
#include "Styling/SlateTypes.h"
#include "Styling/CoreStyle.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Notifications/SProgressBar.h"
#include "SKGProgressBar.generated.h"


/**
 * SProgressBar Fill Type 
 */
UENUM(BlueprintType)
enum class EKGProgressBarFillType : uint8
{
    // will fill up from the left side to the right
    LeftToRight,
    // will fill up from the right side to the left side
    RightToLeft,
    // will scale up from the midpoint to the outer edges both vertically and horizontally
    FillFromCenter,
    // will fill up from the centerline to the outer edges horizontally
    FillFromCenterHorizontal,
    // will fill up from the centerline to the outer edges vertically
    FillFromCenterVertical,
    // will fill up from the top to the the bottom
    TopToBottom,
    // will fill up from the bottom to the the top
    BottomToTop,
    // will fill clockwise
    Radial,
};

/**
 * SKGProgressBar
 */
class SKGProgressBar : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(SKGProgressBar)
            : _Style(&FAppStyle::Get().GetWidgetStyle<FProgressBarStyle>("ProgressBar"))
            , _BarFillType(EKGProgressBarFillType::LeftToRight)
            , _BarFillStyle(EProgressBarFillStyle::Mask)
            , _Percent(TOptional<float>())
            , _FillColorAndOpacity(FLinearColor::White)
            , _BorderPadding(FVector2D(0, 0))
            , _BackgroundImage(nullptr)
            , _FillImage(nullptr)
            , _MarqueeImage(nullptr)
            , _RefreshRate(2.0f)
            , _ThumbImage(nullptr)
            , _ThumbOffset(ForceInit)
            , _AlwaysShowThumb(false)
            , _HasThumb(false)
        {
            _Visibility = EVisibility::SelfHitTestInvisible;
        }

        /** Style used for the progress bar */
        SLATE_STYLE_ARGUMENT(FProgressBarStyle, Style)

        /** Defines the direction in which the progress bar fills */
        SLATE_ARGUMENT(EKGProgressBarFillType, BarFillType)

        /** Defines the visual style of the progress bar fill - scale or mask */
        SLATE_ARGUMENT(EProgressBarFillStyle::Type, BarFillStyle)

        /** Used to determine the fill position of the progress bar ranging 0..1 */
        SLATE_ATTRIBUTE(TOptional<float>, Percent)

        /** Fill Color and Opacity */
        SLATE_ATTRIBUTE(FSlateColor, FillColorAndOpacity)

        /** Border Padding around fill bar */
        SLATE_ATTRIBUTE(FVector2D, BorderPadding)

        /** The brush to use as the background of the progress bar */
        SLATE_ARGUMENT(const FSlateBrush*, BackgroundImage)

        /** The brush to use as the fill image */
        SLATE_ARGUMENT(const FSlateBrush*, FillImage)

        /** The brush to use as the marquee image */
        SLATE_ARGUMENT(const FSlateBrush*, MarqueeImage)

        /** Rate at which this widget is ticked when sleeping in seconds */
        SLATE_ARGUMENT(float, RefreshRate)

        SLATE_ARGUMENT(const FSlateBrush*, ThumbImage)

        SLATE_ARGUMENT(float, CircularThickness)
        SLATE_ARGUMENT(float, CircularRadius)
        SLATE_ARGUMENT(float, CircularStartAngle)
        SLATE_ARGUMENT(float, CircularEndAngle)
        SLATE_ARGUMENT(FVector2D, ThumbOffset)
        SLATE_ARGUMENT(bool, AlwaysShowThumb)
        SLATE_ARGUMENT(bool, HasThumb)
    SLATE_END_ARGS()

    KGUI_API void Construct(const FArguments& InArgs);

    KGUI_API virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;
    KGUI_API virtual FVector2D ComputeDesiredSize(float LayoutScaleMultiplier) const override;
    KGUI_API virtual bool ComputeVolatility() const override;

    KGUI_API void SetThumbImage(const FSlateBrush* InThumbImage);

    /** See attribute Percent */
    KGUI_API void SetPercent(const TAttribute<TOptional<float>>& InPercent);

    /** See attribute Style */
    KGUI_API void SetStyle(const FProgressBarStyle* InStyle);

    /** See attribute BarFillType */
    KGUI_API void SetBarFillType(EKGProgressBarFillType InBarFillType);

    /** See attribute BarFillStyle */
    KGUI_API void SetBarFillStyle(EProgressBarFillStyle::Type InBarFillStyle);

    /** See attribute SetFillColorAndOpacity */
    KGUI_API void SetFillColorAndOpacity(const TAttribute<FSlateColor>& InFillColorAndOpacity);

    /** See attribute BorderPadding */
    KGUI_API void SetBorderPadding(const TAttribute<FVector2D>& InBorderPadding);

    /** See attribute BackgroundImage */
    KGUI_API void SetBackgroundImage(const FSlateBrush* InBackgroundImage);

    /** See attribute FillImage */
    KGUI_API void SetFillImage(const FSlateBrush* InFillImage);

    /** See attribute MarqueeImage */
    KGUI_API void SetMarqueeImage(const FSlateBrush* InMarqueeImage);
    void SetRefreshRate(float InRefreshRate);

    void SetCircularThickness(float InCircularThickness);
    void SetCircularRadius(float InCircularRadius);
    void SetCircularStartAngle(float InCircularStartAngle);
    void SetCircularEndAngle(float InCircularEndAngle);

    void SetThumbOffset(const FVector2D& InThumbOffset);
    void SetAlwaysShowThumb(bool InAlwaysShowThumb);
    void SetHasThumb(bool InHasThumb);

    void SetContent( TSharedRef< SWidget > InContent );
    TSharedRef< SWidget > GetContent() const;
    void ClearContent();
    void SetHAlign(EHorizontalAlignment HAlign);
    void SetVAlign(EVerticalAlignment VAlign);
    void SetPadding(TAttribute<FMargin> InPadding);

protected:
    virtual void OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const override;
    virtual int DrawThumb(float InCenterXInLocal, float InCenterYInLocal, float InAngle, FSlateWindowElementList& OutDrawElements, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth, float InPercent) const;
    virtual int32 DrawLeftToRight(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const;
    virtual int32 DrawRightToLeft(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const;
    virtual int32 DrawTopToBottom(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const;
    virtual int32 DrawBottomToTop(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const;
    virtual int32 DrawFillFromCenter(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const;
    virtual int32 DrawFillFromCenterHorizontal(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const;
    virtual int32 DrawFillFromCenterVertical(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const;
    virtual int32 DrawRadial(FSlateWindowElementList& OutDrawElements, const FGeometry& Geometry, const FSlateRect& MyCullingRect, const int32 InLayerID, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, float InBatchZOrder, float InViewDepth) const;

    virtual void GenerateRectVertexData(const FGeometry& AllottedGeometry, const FSlateBrush* Brush, const FVector2f& TopLeft, const FVector2f& BottomRight, const FMargin& InPosMargin, const FVector2f& UVTopLeft, const FVector2f& UVBottomRight, const FMargin& UVMargin, const FColor& InColor, TArray<FSlateVertex>& OutVerts, TArray<SlateIndex>& OutIndices) const;
    /** Controls the speed at which the widget is ticked when in slate sleep mode */
    void SetActiveTimerTickRate(float TickRate);

    void UpdateMarqueeActiveTimer();

    /** Widgets active tick */
    EActiveTimerReturnType ActiveTick(double InCurrentTime, float InDeltaTime);

    /** Gets the current background image. */
    const FSlateBrush* GetBackgroundImage() const;
    /** Gets the current fill image */
    const FSlateBrush* GetFillImage() const;
    /** Gets the current marquee image */
    const FSlateBrush* GetMarqueeImage() const;

    /** Gets the current thumb image */
    const FSlateBrush* GetThumbImage() const;

protected:
    /** The style of the progress bar */
    const FProgressBarStyle* Style = nullptr;

    /** The text displayed over the progress bar */
    TAttribute<TOptional<float>> Percent;

    EKGProgressBarFillType BarFillType = EKGProgressBarFillType::LeftToRight;

    EProgressBarFillStyle::Type BarFillStyle = EProgressBarFillStyle::Mask;

    /** Background image to use for the progress bar */
    const FSlateBrush* BackgroundImage = nullptr;

    /** Foreground image to use for the progress bar */
    const FSlateBrush* FillImage = nullptr;

    /** Foreground image to use for the progress bar */
    const FSlateBrush* ThumbImage = nullptr;

    /** Image to use for marquee mode */
    const FSlateBrush* MarqueeImage = nullptr;

    /** Fill Color and Opacity */
    TAttribute<FSlateColor> FillColorAndOpacity;

    /** Border Padding */
    TAttribute<FVector2D> BorderPadding;

    /** Value to drive progress bar animation */
    float MarqueeOffset = 0.f;

    /** Reference to the widgets current active timer */
    TWeakPtr<FActiveTimerHandle> ActiveTimerHandle;

    /** Rate at which the widget is currently ticked when slate sleep mode is active */
    float CurrentTickRate = 0;

    /** The slowest that this widget can tick when in slate sleep mode */
    float MinimumTickRate = 2.f;

    float CircularRadius = 100.f;
    float CircularThickness = 20.f;
    float CircularStartAngle = 0.f;
    float CircularEndAngle = 360.f;
    FVector2D ThumbOffset = FVector2D(0.f, 0.f);
    bool bAlwaysShowThumb = false;
    bool bHasThumb = false;
};
