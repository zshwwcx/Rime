#pragma once

#include "CoreMinimal.h"
#include "Widgets/Input/SSlider.h"


class SKGSlider : public SSlider
{
	using Super = SSlider;

protected:
	virtual bool SupportsKeyboardFocus() const override;
};
