#pragma once

#include "CoreMinimal.h"
#include "Widgets/SLeafWidget.h"
#include "UMG/Components/KGLine.h"

// 存储单独某一个Bezier子线段的必要信息
struct FBezierSubLine
{
	int32 StartPositionIndex;
	FVector2f Control1;
	FVector2f Control2;
	int32 EndPositionIndex;
};

/**
 * 贝塞尔曲线Slate控件，用于渲染多端点连接
 */
class KGUI_API SKGLine : public SLeafWidget
{
public:
    SLATE_BEGIN_ARGS(SKGLine)
        : _Points(nullptr)
        , _DefaultLineThickness(1.0f)
        , _LineMaterial(nullptr)
        , _UseBezierControl(true)
    {}
        /** 端点列表 */
        SLATE_ARGUMENT(const TArray<FKGBezierPoint>*, Points)
        /** 默认线条粗细 */
		SLATE_ARGUMENT(float, DefaultLineThickness)
        /** 贝塞尔线渲染材质 */
		SLATE_ARGUMENT(const FSlateBrush*, LineMaterial)
        /** 是否使用贝塞尔曲线控制点 */
		SLATE_ARGUMENT(bool, UseBezierControl)
    SLATE_END_ARGS()

    /** 构造函数 */
    SKGLine();

    /** 初始化 */
    void Construct(const FArguments& InArgs);

    // SWidget接口
    virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;
    virtual FVector2D ComputeDesiredSize(float) const override;
    
    // 设置属性 
	void SetPoints(const TArray<FKGBezierPoint>* InPoints);
	void SetDefaultLineThickness(float InThickness);
	void SetLineMaterial(const FSlateBrush* InBrush);
	void SetUseBezierControl(bool InUseBezierControl);

private:
    /** 绘制曲线 */
    void DrawBezierConnection(const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle) const;
	void DrawLineConnection(const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle) const;

	// 更新顶点数组，防止频繁更新
	void NotifyUpdatePoints();
    
private:
    // 数据源
    const TArray<FKGBezierPoint>* Points;
	TArray<FVector2f> LinePoints;
	TArray<FBezierSubLine> BezierLines;
    
    // 样式属性
    float DefaultLineThickness;
    const FSlateBrush* LineMaterial;
    bool bUseBezierControl;
    
    // 点渲染材质
    FSlateBrush PointBrush;
}; 