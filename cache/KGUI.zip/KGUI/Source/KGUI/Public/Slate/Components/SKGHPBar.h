// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AkGameObject.h"
#include "Widgets/SCompoundWidget.h"
#include "SKGHPBar.generated.h"

UENUM(BlueprintType)
enum class EKGHPBarFillType : uint8
{
	LeftToRight = 0,
	RightToLeft = 1,
	TopToBottom = 2,
	BottomToTop = 3,
};


USTRUCT(BlueprintType)
struct FKGHPBarLayer
{
	GENERATED_BODY()

    UPROPERTY(EditAnywhere)
    FName Name;

    UPROPERTY(EditAnywhere)
    FVector2D Size = {100, 30};

    UPROPERTY(EditAnywhere)
    FMargin Padding;
    
	UPROPERTY(EditAnywhere)
	FSlateBrush Brush;
	
	UPROPERTY(EditAnywhere)
	EKGHPBarFillType FillType = EKGHPBarFillType::LeftToRight;

	UPROPERTY(EditAnywhere, meta=(UIMax = 1, UIMin = 0))
	float Percent = 1.f;

    float CurPercent = 1.f;
    float StartPercent = 1.f;
    float Duration = 0.f;
    float CurTime = 0.f;
    
	UPROPERTY(EditAnywhere)
	float AnimSpeed = 5.f;

	UPROPERTY(EditAnywhere)
	bool bVisible = true;

    UPROPERTY(EditAnywhere)
    bool bMainLayer = false;
};



/**
 * SKGHPBar
 */
class KGUI_API SKGHPBar : public SCompoundWidget
{
    struct FBarGeometryData
    {
        FVector2f TopLeft;
        FVector2f BottomRight;
        FMargin PosMargin;
        FMargin UVMargin;
    };
public:
    SLATE_BEGIN_ARGS( SKGHPBar )
        {}
        
        SLATE_ATTRIBUTE(TArray<FKGHPBarLayer>, Layers)
        SLATE_ATTRIBUTE(FSlateColor, FillColorAndOpacity)
    SLATE_END_ARGS()
    void Construct(const FArguments& InArgs);
	void SetContent( TSharedRef< SWidget > InContent );
	TSharedRef< SWidget > GetContent() const;
	void ClearContent();
	void SetHAlign(EHorizontalAlignment HAlign);
	void SetVAlign(EVerticalAlignment VAlign);
	void SetPadding(TAttribute<FMargin> InPadding);

	int32 SetLayer(FName InLayerName, const FKGHPBarLayer& InLayer);
	void SetLayerBrush(FName InLayerName, const FSlateBrush& InBrush);
	void SetLayerFillType(FName InLayerName, EKGHPBarFillType FillType);
	void SetLayerPercent(FName InLayerName, float Percent);
	void SetLayerAnimSpeed(FName InLayerName, float AnimSpeed);
	void SetLayerVisibility(FName InLayerName, bool bVisible);
    void SetLayerSize(FName InLayerName, const FVector2D& InSize);
    FVector2D GetLayerSize(FName InLayerName) const;
    bool IsLayerVisible(FName InLayerName) const;
    void SetFillColorAndOpacity(const TAttribute<FSlateColor>& InFillColorAndOpacity);
    
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

protected:
	virtual FVector2D ComputeDesiredSize(float) const override;
    virtual void OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const override;
    
    FKGHPBarLayer* GetLayer(FName InLayerName);
    const FKGHPBarLayer* GetLayer(FName InLayerName) const;
    
    int32 DrawLayer(const FKGHPBarLayer& InLayer, const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, ESlateDrawEffect InDrawEffects, bool bParentEnabled) const;

    void GenerateRectVertexData(const FGeometry& AllottedGeometry, const FSlateBrush* Brush, const FVector2f& TopLeft, const FVector2f& BottomRight, const FMargin& InPosMargin, const FVector2f& UVTopLeft, const FVector2f& UVBottomRight, const FMargin& InUVMargin, const FColor& InColor, TArray<FSlateVertex>& OutVerts, TArray<SlateIndex>& OutIndices) const;
    const FKGHPBarLayer* GetMainLayer() const;

protected:
	TArray<FKGHPBarLayer> Layers;
    TAttribute<FSlateColor> FillColorAndOpacity;
	
};
