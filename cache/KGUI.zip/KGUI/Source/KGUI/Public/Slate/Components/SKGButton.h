#pragma once

#include "CoreMinimal.h"
#include "Widgets/Input/SButton.h"


class SKGButton : public SButton
{
	using Super = SButton;

public:
	//BEGIN ADD by chengfeng : disalbe tick by default
	SKGButton()
	{
		SetCanTick(false);
	}
	//END ADD by chengfeng


	virtual FReply OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent) override;
	virtual bool SupportsKeyboardFocus() const override;
};