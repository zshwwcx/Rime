#pragma once

#include "CoreMinimal.h"
#include "Widgets/Layout/SBox.h"


class SKGInteractableAnimArea : public SBox
{
public:
	SLATE_BEGIN_ARGS(SKGInteractableAnimArea) {}
		SLATE_DEFAULT_SLOT(FArguments, Content)
	SLATE_END_ARGS()

	SKGInteractableAnimArea();
	virtual ~SKGInteractableAnimArea() {}
	void Construct(const FArguments& InArgs);

	void SetContent(TSharedRef<SWidget> InContent);
	void SetScale(float Scale);

	virtual void OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const override;
    virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

protected:
	virtual float GetRelativeLayoutScale(int32 ChildIndex, float LayoutScaleMultiplier) const override;

	TOptional<float> RelativeScale;
};

