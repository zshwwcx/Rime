#pragma once

#include "CoreMinimal.h"
#include "Widgets/SPanel.h"
#include "SlotBase.h"
#include "Misc/Attribute.h"
#include "Layout/Visibility.h"
#include "Layout/Margin.h"
#include "Layout/Geometry.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SWidget.h"
#include "Layout/Children.h"
#include "Widgets/Layout/Anchors.h"

class SKGRedDot : public SPanel
{
	SLATE_DECLARE_WIDGET_API(SKGRedDot, SWidget, KGUI_API)
public:
	class FOneChildSlot : public TSingleWidgetChildrenWithSlot<FOneChildSlot>
	{
		friend class SKGRedDot;
	public:
		FOneChildSlot(SWidget* InOwner)
			: TSingleWidgetChildrenWithSlot<FOneChildSlot>(InOwner)
			, OffsetAttr(FMargin(0, 0, 1, 1))
			, AnchorsAttr(FAnchors(0.0f, 0.0f))
			, AlignmentAttr(FVector2D(0.5f, 0.5f))
		{
		}

		SLATE_SLOT_BEGIN_ARGS(FOneChildSlot, TSlotBase<FOneChildSlot>)
			SLATE_ATTRIBUTE(FMargin, Offset)
			SLATE_ATTRIBUTE(FAnchors, Anchors)
			SLATE_ATTRIBUTE(FVector2D, Alignment)
		SLATE_SLOT_END_ARGS()

		void Construct(const FChildren& SlotOwner, FSlotArguments&& InArgs);

		void SetOffset( const TAttribute<FMargin>& InOffset )
		{
			SetAttribute(OffsetAttr, InOffset, EInvalidateWidgetReason::Layout);
		}

		FMargin GetOffset() const
		{
			return OffsetAttr.Get();
		}

		void SetAnchors( const TAttribute<FAnchors>& InAnchors )
		{
			SetAttribute(AnchorsAttr, InAnchors, EInvalidateWidgetReason::Layout);
		}

		FAnchors GetAnchors() const
		{
			return AnchorsAttr.Get();
		}

		void SetAlignment(const TAttribute<FVector2D>& InAlignment)
		{
			SetAttribute(AlignmentAttr, InAlignment, EInvalidateWidgetReason::Layout);
		}

		FVector2D GetAlignment() const
		{
			return AlignmentAttr.Get();
		}
	private:
		/** Offset */
		TAttribute<FMargin> OffsetAttr;

		/** Anchors */
		TAttribute<FAnchors> AnchorsAttr;

		/** Size */
		TAttribute<FVector2D> AlignmentAttr;
	};
	
	SLATE_BEGIN_ARGS(SKGRedDot)
		: _Content()
		, _OwnerWidget(nullptr)
		, _ContentScale(1.f)
		, _Anchor(FAnchors(0, 0))
		, _Offset(FMargin(0, 0, 1, 1))
		, _Alignment(FVector2D::Zero())
		, _ColorAndOpacity(FLinearColor::White)
		, _ColorForegound(FLinearColor::White)
	{
		_Visibility = EVisibility::HitTestInvisible;
	}
		SLATE_DEFAULT_SLOT(FArguments, Content)
		SLATE_ARGUMENT(TSharedPtr<SWidget>, OwnerWidget)
		SLATE_ATTRIBUTE(float, ContentScale)
		SLATE_ATTRIBUTE(FAnchors, Anchor)
		SLATE_ATTRIBUTE(FMargin, Offset)
		SLATE_ATTRIBUTE(FVector2D, Alignment)
		SLATE_ATTRIBUTE(FLinearColor, ColorAndOpacity)
		SLATE_ATTRIBUTE(FLinearColor, ColorForegound)
	SLATE_END_ARGS()

	SKGRedDot();

	void Construct(const FArguments& InArgs);
	void SetContent(TSharedRef<SWidget> InContent);

	void SetContentAlignment(const FVector2D& InAlignment);
	void SetContentAnchors(const FAnchors& InAnchors);
	void SetContentOffset(const FMargin& InOffset);
	
	void SetOwnerWidget(TSharedPtr<SWidget> InOwnerWidget)
	{
		OwnerWidget = InOwnerWidget;
	}
	
	void SetContentScale(TAttribute<float> InContentScale)
	{
		ContentScaleAttribute.Assign(*this, MoveTemp(InContentScale));
	}

	float GetContentScale() const
	{
		return ContentScaleAttribute.Get();
	}

	FLinearColor GetColorAndOpacity() const
	{
		return ColorAndOpacityAttribute.Get();
	}
	
	void SetColorAndOpacity( TAttribute<FLinearColor> InColorAndOpacity )
	{
		ColorAndOpacityAttribute.Assign(*this, MoveTemp(InColorAndOpacity));
	}

	void SetForegroundColor( TAttribute<FSlateColor> InForegroundColor )
	{
		ForegroundColorAttribute.Assign(*this, MoveTemp(InForegroundColor));
	}

	virtual void OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const override;
	virtual FChildren* GetChildren() override;
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;
	virtual FSlateColor GetForegroundColor() const override;
	virtual float GetRelativeLayoutScale(int32 ChildIndex, float LayoutScaleMultiplier) const;
	FOneChildSlot* GetChildSlot() { return &ChildSlot; }
protected:
	virtual FVector2D ComputeDesiredSize(float LayoutScaleMultiplier) const override;

	
	FOneChildSlot ChildSlot;
private:
	TSlateAttribute<float> ContentScaleAttribute;
	TSlateAttribute<FLinearColor> ColorAndOpacityAttribute;
	TSlateAttribute<FSlateColor> ForegroundColorAttribute;
	TSharedPtr<SWidget> OwnerWidget;
};
