#pragma once

#include "Widgets/Views/STileView.h"

template <typename ItemType>
class SKGTileView : public TTileView<ItemType, SKGListView>
{
	using Super = TTileView<ItemType, SKGListView>;

public:
	virtual int32 GetNumItemsPerLine() const override
	{
		FTableViewDimensions PanelDimensions(this->Orientation, this->PanelGeometryLastTick.GetLocalSize() - this->ContentPadding.GetDesiredSize2f());
		FTableViewDimensions TileDimensions = Super::GetTileDimensions();

		const int32 NumItemsPerLine = TileDimensions.LineAxis > 0 ? FMath::FloorToInt(PanelDimensions.LineAxis / TileDimensions.LineAxis) : 1;
		return FMath::Max(1, NumItemsPerLine);
	}

protected:
	virtual STableViewBase::FReGenerateResults ReGenerateItems( const FGeometry& MyGeometry ) override
	{
		// Clear all the items from our panel. We will re-add them in the correct order momentarily.
		this->ClearWidgets();
		
		const TArrayView<const ItemType> Items = this->GetItems();
		if (Items.Num() > 0)
		{
			// Item width and height is constant by design.
			FTableViewDimensions TileDimensions = Super::GetTileDimensions();
			FTableViewDimensions AllottedDimensions(this->Orientation, MyGeometry.GetLocalSize());
			FTableViewDimensions ContentPaddingDesiredSizeDimensions(this->Orientation, this->ContentPadding.GetDesiredSize2f());
			
			const int32 NumItems = Items.Num();
			const int32 NumItemsPerLine = GetNumItemsPerLine();
			const int32 NumItemsPaddedToFillLastLine = (NumItems % NumItemsPerLine != 0)
				? NumItems + NumItemsPerLine - NumItems % NumItemsPerLine
				: NumItems;

			const double LinesPerScreen = AllottedDimensions.ScrollAxis / TileDimensions.ScrollAxis;
			// BEGIN CHANGE BY wuzhiwei05@kuaishou.com: List View Content Padding
#if 0
			const double EndOfListOffset = NumItemsPaddedToFillLastLine - NumItemsPerLine * LinesPerScreen;
#else
			const int32 NumLinePaddedToFillLastLine = NumItemsPaddedToFillLastLine / NumItemsPerLine;
			FTableViewDimensions UpperPaddingDimensions(this->Orientation, this->ContentPadding.GetTopLeft());
			FTableViewDimensions LowerPaddingDimensions(this->Orientation, FVector2f(this->ContentPadding.Right, this->ContentPadding.Bottom));
			double EndOfListOffset;
			{
				auto TotalLengthScrollAxis = NumLinePaddedToFillLastLine * TileDimensions.ScrollAxis + UpperPaddingDimensions.ScrollAxis + LowerPaddingDimensions.ScrollAxis;
				auto EndOfListLengthOffset = TotalLengthScrollAxis - AllottedDimensions.ScrollAxis;
				if (NumLinePaddedToFillLastLine == 0)
				{
					EndOfListOffset = 0;
				}
				else if (NumLinePaddedToFillLastLine == 1)
				{
					EndOfListOffset = EndOfListLengthOffset / (UpperPaddingDimensions.ScrollAxis + LowerPaddingDimensions.ScrollAxis + TileDimensions.ScrollAxis) * NumItemsPerLine;
				}
				else if (EndOfListLengthOffset < UpperPaddingDimensions.ScrollAxis + TileDimensions.ScrollAxis)
				{
					EndOfListOffset = EndOfListLengthOffset / (UpperPaddingDimensions.ScrollAxis + TileDimensions.ScrollAxis) * NumItemsPerLine;
				}
				else if (TotalLengthScrollAxis - EndOfListLengthOffset < LowerPaddingDimensions.ScrollAxis + TileDimensions.ScrollAxis)
				{
					EndOfListOffset = 1.0 - (TotalLengthScrollAxis - EndOfListLengthOffset) / (LowerPaddingDimensions.ScrollAxis + TileDimensions.ScrollAxis) * NumItemsPerLine;
				}
				else
				{
					EndOfListOffset = ((EndOfListLengthOffset - (UpperPaddingDimensions.ScrollAxis + TileDimensions.ScrollAxis)) / TileDimensions.ScrollAxis + 1) * NumItemsPerLine;
				}
			}
#endif
			// END CHANGE BY wuzhiwei05@kuaishou.com
			const double ClampedScrollOffset = FMath::Clamp(this->CurrentScrollOffset, 0.0, EndOfListOffset);
			const float LayoutScaleMultiplier = MyGeometry.GetAccumulatedLayoutTransform().GetScale();
			
			// Once we run out of vertical and horizontal space, we stop generating widgets.
			FTableViewDimensions DimensionsUsedSoFar(this->Orientation);
			
			// Index of the item at which we start generating based on how far scrolled down we are
			int32 StartIndex = FMath::Max( 0, FMath::FloorToInt32(ClampedScrollOffset / NumItemsPerLine) * NumItemsPerLine);

			// Let the WidgetGenerator know that we are starting a pass so that it can keep track of data items and widgets.
			this->WidgetGenerator.OnBeginGenerationPass();

			// Actually generate the widgets.
			bool bIsAtEndOfList = false;
			bool bHasFilledAvailableArea = false;
			bool bNewLine = true;
			bool bFirstLine = true;
			double NumLinesShownOnScreen = 0;

			// BEGIN ADD BY wuzhiwei05@kuaishou.com: List View Content Padding
			this->SetItemsPanelFirstLineIndex(StartIndex / NumItemsPerLine);
			this->SetItemsPanelNumLines(NumLinePaddedToFillLastLine);
			float TotalGeneratedLineAxisSize = 0;
			// END ADD BY wuzhiwei05@kuaishou.com

			for( int32 ItemIndex = StartIndex; !bHasFilledAvailableArea && ItemIndex < NumItems; ++ItemIndex )
			{
				const ItemType& CurItem = Items[ItemIndex];

				if (bNewLine)
				{
					bNewLine = false;

					auto LineIndex = ItemIndex / NumItemsPerLine;
					auto TileDimensionsWithPadding = TileDimensions.ScrollAxis + (LineIndex == 0 ? UpperPaddingDimensions.ScrollAxis : 0) + (LineIndex == NumLinePaddedToFillLastLine - 1 ? LowerPaddingDimensions.ScrollAxis : 0);
					
					float LineFraction = 1.f;
					if (bFirstLine)
					{
						bFirstLine = false;
						LineFraction -= (float)FMath::Fractional(ClampedScrollOffset / NumItemsPerLine);
					}

					// BEGIN CHANGE BY wuzhiwei05@kuaishou.com: List View Content Padding
#if 0
					DimensionsUsedSoFar.ScrollAxis += TileDimensions.ScrollAxis * LineFraction;
					if (DimensionsUsedSoFar.ScrollAxis > AllottedDimensions.ScrollAxis)
					{
						NumLinesShownOnScreen += FMath::Max(1.0f - ((DimensionsUsedSoFar.ScrollAxis - AllottedDimensions.ScrollAxis) / TileDimensions.ScrollAxis), 0.0f);
					}
					else
					{
						NumLinesShownOnScreen += LineFraction;
					}
#else
					DimensionsUsedSoFar.ScrollAxis += TileDimensionsWithPadding * LineFraction;
					if (DimensionsUsedSoFar.ScrollAxis > AllottedDimensions.ScrollAxis)
					{
						auto LineFractionForBackfill = FMath::Max(1.0f - ((DimensionsUsedSoFar.ScrollAxis - AllottedDimensions.ScrollAxis) / TileDimensionsWithPadding), 0.0f);;
						NumLinesShownOnScreen += LineFractionForBackfill;
						TotalGeneratedLineAxisSize += LineFractionForBackfill * TileDimensionsWithPadding;
					}
					else
					{
						NumLinesShownOnScreen += LineFraction;
						TotalGeneratedLineAxisSize += LineFraction * TileDimensionsWithPadding;
					}
#endif
					// END CHANGE BY wuzhiwei05@kuaishou.com
				}

				SListView<ItemType>::GenerateWidgetForItem(CurItem, ItemIndex, StartIndex, LayoutScaleMultiplier);

				// The widget used up some of the available space for the current line
				DimensionsUsedSoFar.LineAxis += TileDimensions.LineAxis;

				bIsAtEndOfList = ItemIndex >= NumItems - 1;

				if (DimensionsUsedSoFar.LineAxis + TileDimensions.LineAxis > AllottedDimensions.LineAxis - ContentPaddingDesiredSizeDimensions.LineAxis)
				{
					// A new line of widgets was completed - time to start another one
					DimensionsUsedSoFar.LineAxis = 0;
					bNewLine = true;
				}

				if (bIsAtEndOfList || bNewLine)
				{
					// We've filled all the available area when we've finished a line that's partially clipped by the end of the view
					const float FloatPrecisionOffset = 0.001f;
					bHasFilledAvailableArea = DimensionsUsedSoFar.ScrollAxis > AllottedDimensions.ScrollAxis + FloatPrecisionOffset;
				}
			}

			// We have completed the generation pass. The WidgetGenerator will clean up unused Widgets.
			this->WidgetGenerator.OnEndGenerationPass();

			// BEGIN CHANGE BY wuzhiwei05@kuaishou.com: List View Content Padding
#if 0
			const float TotalGeneratedLineAxisSize = (float)(FMath::CeilToFloat(NumLinesShownOnScreen) * TileDimensions.ScrollAxis);
#endif
			// END CHANGE BY wuzhiwei05@kuaishou.com: List View Content Padding
			return STableViewBase::FReGenerateResults(ClampedScrollOffset, TotalGeneratedLineAxisSize, NumLinesShownOnScreen, bIsAtEndOfList && !bHasFilledAvailableArea);
		}

		return STableViewBase::FReGenerateResults(0, 0, 0, false);

	}

	virtual void ModifyWidgetDimensions(FTableViewDimensions& WidgetDimensions, int ItemIndex) const override
	{
		auto NumItemsPerLine = GetNumItemsPerLine();
		int LineIndex = ItemIndex / NumItemsPerLine;
		int IndexInLine = ItemIndex % NumItemsPerLine;
		auto NumLines = FMath::CeilToInt((float)this->GetItems().Num() / NumItemsPerLine);

		WidgetDimensions = WidgetDimensions
			+ Super::Multiple(
				FTableViewDimensions(this->Orientation, this->ContentPadding.GetTopLeft()),
				FTableViewDimensions(EOrientation::Orient_Vertical, IndexInLine == 0, LineIndex == 0 ? 1 : 0)
			)
			+ Super::Multiple(
				FTableViewDimensions(this->Orientation, FVector2f(this->ContentPadding.Right, this->ContentPadding.Bottom)),
				FTableViewDimensions(EOrientation::Orient_Vertical, IndexInLine == NumItemsPerLine - 1, LineIndex == NumLines - 1 ? 1 : 0)
			);
	}

	virtual typename SKGListView<ItemType>::EScrollIntoViewResult ScrollIntoView(const FGeometry& ListViewGeometry) override
	{
#if WITH_EDITOR
		const bool bUseImprovedScrollToViewImplementation = GetDefault<UKGUISettings>()->bUseImprovedScrollToViewImplementation;
#else
		const static bool bUseImprovedScrollToViewImplementation = GetDefault<UKGUISettings>()->bUseImprovedScrollToViewImplementation;
#endif
		if (!bUseImprovedScrollToViewImplementation)
		{
			return Super::ScrollIntoView(ListViewGeometry);
		}
		if (TListTypeTraits<ItemType>::IsPtrValid(this->ItemToScrollIntoView) && this->HasValidItemsSource())
		{
			const int32 IndexOfItem = this->GetItems().Find(TListTypeTraits<ItemType>::NullableItemTypeConvertToItemType(this->ItemToScrollIntoView));
			if (IndexOfItem != INDEX_NONE)
			{
				const float NumLinesInView = FTableViewDimensions(this->Orientation, ListViewGeometry.GetLocalSize()).ScrollAxis / this->GetTileDimensions().ScrollAxis;
				double NumLiveWidgets = this->GetNumLiveWidgets();
				if (NumLiveWidgets == 0 && this->IsPendingRefresh())
				{
					NumLiveWidgets = this->LastGenerateResults.ExactNumLinesOnScreen;
					if (NumLiveWidgets == 0)
					{
						return SKGListView<ItemType>::EScrollIntoViewResult::Deferred;
					}
				}
				this->EndInertialScrolling();
				// Override:
				
				const int32 NumItemsPerLine = GetNumItemsPerLine();
				const double ScrollLineOffset = this->GetTargetScrollOffset() / NumItemsPerLine;
				const int32 LineOfItem = FMath::FloorToInt((float)IndexOfItem / (float)NumItemsPerLine);
				const int32 NumFullLinesInView = FMath::FloorToInt32(ScrollLineOffset + NumLinesInView) - FMath::CeilToInt32(ScrollLineOffset);
				const double MinDisplayedLine = this->bNavigateOnScrollIntoView ? FMath::FloorToDouble(ScrollLineOffset) : FMath::CeilToDouble(ScrollLineOffset);
				const double MaxDisplayedLine = this->bNavigateOnScrollIntoView ? FMath::CeilToDouble(ScrollLineOffset + NumFullLinesInView) : FMath::FloorToDouble(ScrollLineOffset + NumFullLinesInView);
				const auto& Items = this->GetItems();
				const int NumLines = Items.Num() % NumItemsPerLine == 0 ? (Items.Num() / NumItemsPerLine) : FMath::CeilToInt((float)Items.Num() / NumItemsPerLine);

				do
				{
					float Alignment;
					if (this->bUseSpecificScrollIntoViewAlignment)
					{
						Alignment = FMath::Clamp(this->SpecificScrollIntoViewAlignment, 0, 1);
					}
					else
					{
						if (LineOfItem < MinDisplayedLine)
						{
							Alignment = 0;
						}
						else if (LineOfItem > MaxDisplayedLine)
						{
							Alignment = 1;
						}
						else
						{
							break;
						}
					}
					
					const float LayoutScaleMultiplier = ListViewGeometry.GetAccumulatedLayoutTransform().GetScale();
					const FTableViewDimensions ListViewDimensions(this->Orientation, ListViewGeometry.GetLocalSize());
					FTableViewDimensions UpperContentPadding(this->Orientation, this->ContentPadding.GetTopLeft());
					FTableViewDimensions LowerContentPadding(this->Orientation, this->ContentPadding.Right, this->ContentPadding.Bottom);
					
					float RemainingDistance = ListViewDimensions.ScrollAxis * Alignment;
					int LineIndex = LineOfItem + 1;

					bool bFirst = true;
					while (RemainingDistance >= 0 && LineIndex > 0)
					{
						LineIndex--;
						FTableViewDimensions WidgetDimensions = this->GetTileDimensions();
						ModifyWidgetDimensions(WidgetDimensions, LineIndex * NumItemsPerLine);
						if (LineIndex == NumLines - 1)
						{
							WidgetDimensions.ScrollAxis -= UpperContentPadding.ScrollAxis;
						}
						if (bFirst)
						{
							RemainingDistance -= WidgetDimensions.ScrollAxis * Alignment;
							bFirst = false;
						}
						else
						{
							RemainingDistance -= WidgetDimensions.ScrollAxis;
						}
					}
					FTableViewDimensions FirstRowWidgetDimensions = this->GetTileDimensions();
					ModifyWidgetDimensions(FirstRowWidgetDimensions, LineIndex * NumItemsPerLine);

					double NewScrollOffset = (float)LineIndex - RemainingDistance / FirstRowWidgetDimensions.ScrollAxis;

					NewScrollOffset = FMath::Max(NewScrollOffset, UpperContentPadding.ScrollAxis / FirstRowWidgetDimensions.ScrollAxis);
					NewScrollOffset = FMath::Min(NewScrollOffset, (float)NumLines - LowerContentPadding.ScrollAxis / FirstRowWidgetDimensions.ScrollAxis);

					const double MaxScrollOffset = FMath::Max(0.0, static_cast<double>(NumLines) - NumFullLinesInView);
					NewScrollOffset = FMath::Clamp<double>(NewScrollOffset, 0.0, MaxScrollOffset);
					this->SetScrollOffset((float)NewScrollOffset * (float)NumItemsPerLine);
				} while (false);

				// End of override.
				this->RequestListRefresh();
				this->ItemToNotifyWhenInView = this->ItemToScrollIntoView;
			}
			TListTypeTraits<ItemType>::ResetPtr(this->ItemToScrollIntoView);
		}
		if (TListTypeTraits<ItemType>::IsPtrValid(this->ItemToNotifyWhenInView))
		{
			if (this->bEnableAnimatedScrolling)
			{
				const bool bHasWidgetForItem = this->WidgetFromItem(TListTypeTraits<ItemType>::NullableItemTypeConvertToItemType(this->ItemToNotifyWhenInView)).IsValid();
				return bHasWidgetForItem ? SKGListView<ItemType>::EScrollIntoViewResult::Success : SKGListView<ItemType>::EScrollIntoViewResult::Deferred;
			}
		}
		return SKGListView<ItemType>::EScrollIntoViewResult::Success;
	}
};