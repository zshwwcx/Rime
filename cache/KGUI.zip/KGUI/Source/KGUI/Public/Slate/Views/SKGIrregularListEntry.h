#pragma once

#include "CoreMinimal.h"
#include "Widgets/SPanel.h"
#include "Widgets/Layout/SBorder.h"
#include "IKGIrregularListEntry.h"

template <typename ItemType> class SKGIrregularListView;

template <typename ItemType>
class SKGIrregularListEntry : public SBorder, public IKGIrregularListEntry
{
public:
	SKGIrregularListEntry()
		: IndexInList(0)
	{
#if WITH_ACCESSIBILITY
		AccessibleBehavior = EAccessibleBehavior::Summary;
		bCanChildrenBeAccessible = true;
#endif
	}

	void Construct(const typename SKGIrregularListEntry<ItemType>::FArguments& InArgs, const TSharedRef<SKGIrregularListView<ItemType>>& InOwnerListView)
	{
		ChildSlot
		[
			InArgs._Content.Widget
		];
		OwnerListViewPtr = InOwnerListView;
	}

	virtual void InitializeRow(void) override
	{
	}

	virtual void ResetRow(void) override
	{
	}

	virtual void SetIndexInList(int32 InIndexInList) override
	{
		IndexInList = InIndexInList;
	}

	virtual int32 GetIndexInList() const override
	{
		return IndexInList;
	}

	virtual void UpdateItemSelection(bool bIsSelected, ESelectInfo::Type SelectInfo) override
	{
	}

	virtual bool IsItemSelected() const override
	{
		TSharedRef<SKGIrregularListView<ItemType>> OwnerListView = OwnerListViewPtr.Pin().ToSharedRef();
		if (const TObjectPtrWrapTypeOf<ItemType>* MyItemPtr = GetItemForThis(OwnerListView))
		{
			return OwnerListView->IsItemSelected(*MyItemPtr);
		}
		return false;
	}

	virtual TSharedRef<SWidget> AsWidget() override
	{
		return SharedThis(this);
	}

	virtual void SetIrregularPosition(FVector2D InIrregularPosition) override
	{
		IrregularPosition = InIrregularPosition;
	}

protected:
	const TObjectPtrWrapTypeOf<ItemType>* GetItemForThis(const TSharedRef<SKGIrregularListView<ItemType>>& OwnerListView) const
	{
		const TObjectPtrWrapTypeOf<ItemType>* MyItemPtr = OwnerListView->ItemFromWidget(this);
		if (MyItemPtr)
		{
			return MyItemPtr;
		}
		else
		{
			checkf(OwnerListView->IsPendingRefresh(), TEXT("We were unable to find the item for this widget.  If it was removed from the source collection, the list should be pending a refresh."));
		}
		return nullptr;
	}

protected:
	TWeakPtr<SKGIrregularListView<ItemType>> OwnerListViewPtr;

	int32 IndexInList;
	FVector2D IrregularPosition;
};