#pragma once

#include "Widgets/Views/STreeView.h"

#include "UMG/Blueprint/KGTreeItem.h"

template <typename ItemType>
class SKGTreeView : public TTreeView<ItemType, SKGListView>
{
public:
	using Super = TTreeView<ItemType, SKGListView>;

	void SeeItem(ItemType Item, TSharedPtr<ITableRow> RowWidget)
	{
		this->WidgetGenerator.OnItemSeen(Item, RowWidget.ToSharedRef());
	}

	virtual ItemType GetScrollIntoViewLinearizedItem(ItemType Item)
	{
		if (!Item)
		{
			return nullptr;
		}
		auto TreeItem = FKGTreeItem::UnsafeCast(Item);
		check(TreeItem != nullptr);
		PRAGMA_DISABLE_DEPRECATION_WARNINGS
		const auto& Items = this->GetItems();
		PRAGMA_ENABLE_DEPRECATION_WARNINGS
		while (TreeItem != nullptr && !Items.Contains(TreeItem))
		{
			auto ParentLayoutItem = TreeItem->GetParentLayoutItem();
			if (Items.Contains(ParentLayoutItem))
			{
				return ParentLayoutItem;
			}
			TreeItem = TreeItem->GetParent();
		}
		return TreeItem;
	}

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override
	{
		FGeometry PanelGeometry;
		if (this->GetPanelGeometry(AllottedGeometry, PanelGeometry))
		{
			if (bRequestListRefreshOnPanelSizeChanged && PanelGeometry.GetLocalSize() != CachedPanelGeometry.GetLocalSize())
			{
				this->RequestListRefresh();
			}
		}
		CachedPanelGeometry = PanelGeometry;
		Super::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
	}

	const FGeometry& GetCachedPanelGeometry() const { return CachedPanelGeometry; }

	void SetRequestListRefreshOnPanelSizeChanged(bool InbRequestListRefreshOnPanelSizeChanged) { bRequestListRefreshOnPanelSizeChanged = InbRequestListRefreshOnPanelSizeChanged; }
	bool GetRequestListRefreshOnPanelSizeChanged() const { return bRequestListRefreshOnPanelSizeChanged; }

protected:
	virtual void NavigationSelect(const ItemType& InItemToSelect, const FInputEvent& InInputEvent) override
	{
		auto TreeItem = FKGTreeItem::UnsafeCast(InItemToSelect);
		if (TreeItem == nullptr)
		{
			if (auto TreeTileLayoutItem = FKGTreeTileLayoutItem::UnsafeCast(InItemToSelect))
			{
				auto TreeItems = TreeTileLayoutItem->GetTreeItems();
				if (TreeItems.Num() > 0)
				{
					Super::NavigationSelect(TreeItems[0], InInputEvent);
				}
			}
			return;
		}
		Super::NavigationSelect(InItemToSelect, InInputEvent);
	}

private:
	FGeometry CachedPanelGeometry;
	bool bRequestListRefreshOnPanelSizeChanged = false;
};