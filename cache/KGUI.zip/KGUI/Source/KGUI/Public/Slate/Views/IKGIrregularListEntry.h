#pragma once

#include "CoreMinimal.h"

class IKGIrregularListEntry
{
public:
	virtual void InitializeRow() = 0;
	virtual void ResetRow() = 0;
	virtual void SetIndexInList(int32 InIndexInList) = 0;
	virtual int32 GetIndexInList() const = 0;

	virtual void UpdateItemSelection(bool bIsSelected, ESelectInfo::Type SelectInfo) = 0;
	virtual bool IsItemSelected() const = 0;

	virtual TSharedRef<SWidget> AsWidget() = 0;

	virtual void SetIrregularPosition(FVector2D InSlotPosition) = 0;
};