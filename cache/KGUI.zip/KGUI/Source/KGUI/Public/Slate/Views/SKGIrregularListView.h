#pragma once

#include "CoreMinimal.h"
#include "Widgets/SPanel.h"

#include "IKGIrregularListEntry.h"
#include "KGUISettings.h"
#include "SKGIrregularListEntry.h"
#include "Slate/Layout/KGLinearMargin.h"
#include "Framework/SlateDelegates.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Views/IItemsSource.h"
#include "Framework/Views/TableViewTypeTraits.h"
#include "Layout/ArrangedChildren.h"

#include "UMG/Slate/SKGObjectIrregularListEntry.h"
#include "Widgets/Text/STextBlock.h"

UENUM(BlueprintType)
enum class EKGElasticStyle : uint8
{
	None,
	Simple,
	Spring,
};

UENUM(BlueprintType)
enum class EKGOverlayStyle : uint8
{
	None,
	Incremental,
	Specific,
};

UENUM(BlueprintType)
enum class EKGIrregularListViewUpdateSource : uint8
{
	Direct,
	Scrolling,
	Inertia,
	Elasticity,
};

template <typename T, typename Enable = void> struct TIrregularListViewTypeTraits
{
	class SerializerType {};

	static void AddReferencedObject(FReferenceCollector& Collector, T& Item)
	{
	}

	static void AddReferencedObjects(FReferenceCollector& Collector, TArray<T>& Items)
	{
	}

	static void AddReferencedObjects(FReferenceCollector& Collector, TSet<T>& Items)
	{
	}
};

template <typename T> struct TIrregularListViewTypeTraits<TObjectPtr<T>>
{
	typedef FGCObject SerializerType;

	static void AddReferencedObject(FReferenceCollector& Collector, TObjectPtr<T>& Item)
	{
		Collector.AddReferencedObject(Item);
	}

	static void AddReferencedObjects(FReferenceCollector& Collector, TArray<TObjectPtr<T>>& Items)
	{
		Collector.AddReferencedObjects(Items);
	}

	static void AddReferencedObjects(FReferenceCollector& Collector, TSet<TObjectPtr<T>>& Items)
	{
		Collector.AddReferencedObjects(Items);
	}
};

template <typename T>
struct TIrregularListViewTypeTraits<T*, typename TEnableIf<TPointerIsConvertibleFromTo<T, UObjectBase>::Value>::Type>
{
	typedef FGCObject SerializerType;

	static void AddReferencedObject(FReferenceCollector& Collector, TObjectPtr<T>& Item)
	{
		Collector.AddReferencedObject(Item);
	}

	static void AddReferencedObjects(FReferenceCollector& Collector, TArray<TObjectPtr<T>>& Items)
	{
		Collector.AddReferencedObjects(Items);
	}

	static void AddReferencedObjects(FReferenceCollector& Collector, TSet<TObjectPtr<T>>& Items)
	{
		Collector.AddReferencedObjects(Items);
	}
};

template <typename T>
struct TIrregularListViewTypeTraits<const T*, typename TEnableIf<TPointerIsConvertibleFromTo<T, UObjectBase>::Value>::Type>
{
	typedef FGCObject SerializerType;

	static void AddReferencedObject(FReferenceCollector& Collector, const TObjectPtr<T>& Item)
	{
		Collector.AddReferencedObject(Item);
	}

	static void AddReferencedObjects(FReferenceCollector& Collector, TArray<const TObjectPtr<T>>& Items)
	{
		Collector.AddReferencedObjects(Items);
	}

	static void AddReferencedObjects(FReferenceCollector& Collector, TSet<const TObjectPtr<T>>& Items)
	{
		Collector.AddReferencedObjects(Items);
	}
};

class SKGIrregularListViewBase : public SCompoundWidget
{
public:
	virtual FVector2D ComputeIrregularPosition(const FGeometry& AllottedGeometry, const TSharedRef<SWidget>& Widget) = 0;
	virtual int ComputeLayerIdIncrement(const TSharedRef<SWidget>& Widget) = 0;
	virtual bool IsPendingRefresh() const = 0;
	virtual FAnchors GetEntryAnchors() const = 0;
};

template <typename ItemType>
class SKGIrregularListPanel : public SPanel
{
	SLATE_BEGIN_ARGS(SKGIrregularListPanel)
		{}
	SLATE_END_ARGS()

	#pragma region Slot

	class FSlot : public TSlotBase<FSlot>
	{
	public:
		FSlot()
			: TSlotBase<FSlot>()
		{}

		SLATE_SLOT_BEGIN_ARGS(FSlot, TSlotBase<FSlot>)
		SLATE_SLOT_END_ARGS()
	};

	static typename FSlot::FSlotArguments Slot()
	{
		return FSlot::FSlotArguments(MakeUnique<FSlot>());
	}

	using FScopedWidgetSlotArguments = typename TPanelChildren<FSlot>::FScopedWidgetSlotArguments;
	FScopedWidgetSlotArguments AddSlot(int32 InsertAtIndex = INDEX_NONE)
	{
		return FScopedWidgetSlotArguments{ MakeUnique<FSlot>(), Children, InsertAtIndex };
	}

	void AppendWidget(TSharedRef<SWidget> ChildWidget)
	{
		this->AddSlot(Children.Num())[ChildWidget];
	}

	#pragma endregion
public:
	SKGIrregularListPanel()
		: Children(this)
	{
	}

	void Construct(FArguments Arguments, TSharedRef<SKGIrregularListViewBase> InListView)
	{
		this->ListView = InListView;
		this->SetVisibility(EVisibility::SelfHitTestInvisible);
	}

private:
	void ArrangeChild(const FGeometry& AllottedGeometry, const typename SKGIrregularListPanel<ItemType>::FSlot& ChildSlot, FArrangedChildren& ArrangedChildren) const
	{
		if (auto StrongListView = this->ListView.Pin())
		{
			FVector2D LocalPosition, LocalSize;
			const TSharedRef<SWidget>& CurWidget = ChildSlot.GetWidget();

			auto IrregularPosition = StrongListView->ComputeIrregularPosition(AllottedGeometry, CurWidget);
			IrregularToLocal(AllottedGeometry, IrregularPosition, CurWidget->GetDesiredSize(), LocalPosition, LocalSize);
			ArrangedChildren.AddWidget(CurWidget->GetVisibility(), AllottedGeometry.MakeChild(
				CurWidget,
				LocalPosition,
				LocalSize
			));
		}
	}

public:
	void IrregularToLocal(
		const FGeometry& IrregularListViewGeometry,
		FVector2D IrregularPosition, FVector2D IrregularSize,
		FVector2D& LocalPosition, FVector2D& LocalSize
	) const
	{
		const FMargin Offset = IrregularPosition;
		check(ListView.IsValid());
		const FAnchors Anchors = ListView.Pin()->GetEntryAnchors();

		const FMargin AnchorPixels =
			FMargin(
				Anchors.Minimum.X * IrregularListViewGeometry.GetLocalSize().X,
				Anchors.Minimum.Y * IrregularListViewGeometry.GetLocalSize().Y,
				Anchors.Maximum.X * IrregularListViewGeometry.GetLocalSize().X,
				Anchors.Maximum.Y * IrregularListViewGeometry.GetLocalSize().Y
			);

		const bool bIsHorizontalStretch = Anchors.Minimum.X != Anchors.Maximum.X;
		const bool bIsVerticalStretch = Anchors.Minimum.Y != Anchors.Maximum.Y;

		const FVector2D Size = IrregularSize;
		FVector2D AlignmentOffset = Size * FVector2D(0.5f, 0.5f);

		if (bIsHorizontalStretch)
		{
			LocalPosition.X = AnchorPixels.Left + Offset.Left;
			LocalSize.X = AnchorPixels.Right - LocalPosition.X - Offset.Right;
		}
		else
		{
			LocalPosition.X = AnchorPixels.Left + Offset.Left - AlignmentOffset.X;
			LocalSize.X = Size.X;
		}
		if (bIsVerticalStretch)
		{
			LocalPosition.Y = AnchorPixels.Top + Offset.Top;
			LocalSize.Y = AnchorPixels.Bottom - LocalPosition.Y - Offset.Bottom;
		}
		else
		{
			LocalPosition.Y = AnchorPixels.Top + Offset.Top - AlignmentOffset.Y;
			LocalSize.Y = Size.Y;
		}
	}

	virtual void OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const override
	{
		//TArray<int32> SelectedChildIndices;
		for (int32 ChildIndex = 0; ChildIndex < Children.Num(); ++ChildIndex)
		{
			auto& ChildSlot = Children[ChildIndex];
			const TSharedRef<SWidget>& CurWidget = ChildSlot.GetWidget();
			//const TObjectPtrWrapTypeOf<ItemType>* Item = ItemFromWidget(&CurWidget.Get());
			//if (IsItemSelected(*Item))
			//{
			//	SelectedChildIndices.Add(ChildIndex);
			//	continue;
			//}
			ArrangeChild(AllottedGeometry, ChildSlot, ArrangedChildren);
		}
		//for (auto SelectedChildIndex : SelectedChildIndices)
		//{
		//	ArrangeChild(AllottedGeometry, Children[SelectedChildIndex], ArrangedChildren);
		//}
	}

	virtual FVector2D ComputeDesiredSize(float) const override
	{
		return FVector2D(0, 0);
	}

	virtual FChildren* GetChildren() override
	{
		auto StrongListView = ListView.Pin();
		if (StrongListView && StrongListView->IsPendingRefresh())
		{
			return &FNoChildren::NoChildrenInstance;
		}
		else
		{
			return &Children;
		}
	}

	virtual FChildren* GetAllChildren() override
	{
		return &Children;
	}

	void ClearWidgets()
	{
		Children.Empty();
	}

protected:
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override
	{
		FArrangedChildren ArrangedChildren(EVisibility::Visible);
		ArrangeChildren(AllottedGeometry, ArrangedChildren);

		FPaintArgs NewArgs = Args.WithNewParent(this);
		if (GetSlateInViewDepth() != 0)
		{
			NewArgs.SetSlateInViewDepth(GetSlateInViewDepth());
		}
		if (GetBatchZOrder() != 0)
		{
			NewArgs.SetBatchZOrder(GetBatchZOrder());
		}
		int32 MaxLayerId = LayerId;

		const bool bShouldBeEnabled = ShouldBeEnabled(bParentEnabled);

		auto StrongListView = ListView.Pin();

		for (int32 ChildIndex = 0; ChildIndex < ArrangedChildren.Num(); ++ChildIndex)
		{
			const FArrangedWidget& CurWidget = ArrangedChildren[ChildIndex];

			if (!IsChildWidgetCulled(MyCullingRect, CurWidget))
			{
				const int32 CurWidgetsMaxLayerId = CurWidget.Widget->Paint(NewArgs, CurWidget.Geometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bShouldBeEnabled);
				MaxLayerId = FMath::Max(MaxLayerId, CurWidgetsMaxLayerId);
				LayerId = MaxLayerId + StrongListView->ComputeLayerIdIncrement(CurWidget.Widget);
			}
			else
			{
				//SlateGI - RemoveContent
			}
		}

		return MaxLayerId;
	}

	TPanelChildren<FSlot> Children;
	TWeakPtr<SKGIrregularListViewBase> ListView;
};

template <typename ItemType>
class SKGIrregularListView : public SKGIrregularListViewBase, TIrregularListViewTypeTraits<ItemType>::SerializerType
{
	using Super = SCompoundWidget;
public:
	DECLARE_DELEGATE_RetVal_TwoParams(TSharedRef<IKGIrregularListEntry>, FOnGenerateWidget, ItemType, const TSharedRef<class SKGIrregularListView<ItemType>>&);
	DECLARE_DELEGATE_TwoParams(FOnEntryInitialized, ItemType, const TSharedRef<IKGIrregularListEntry>&);
	DECLARE_DELEGATE_TwoParams(FOnEntryReleased, ItemType, const TSharedRef<IKGIrregularListEntry>&);
	DECLARE_DELEGATE_RetVal_ThreeParams(FVector2D, FOnArrangeItem, const FGeometry&, ItemType, float);
	DECLARE_DELEGATE_RetVal_TwoParams(float, FOnDragged, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(bool, FOnDragStarting, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_ThreeParams(FOnSelectionChanged, ItemType, bool, ESelectInfo::Type);
	DECLARE_DELEGATE(FOnScrollEnded);
	DECLARE_DELEGATE_OneParam(FOnItemSnapped, ItemType);
	DECLARE_DELEGATE_TwoParams(FOnScrollPositionChanged, float, EKGIrregularListViewUpdateSource);
	DECLARE_DELEGATE(FOnInteractionStarted);
	DECLARE_DELEGATE(FOnInteractionEnded);

	typedef typename TSlateDelegates<ItemType>::FOnItemToString_Debug FOnItemToString_Debug;

	SLATE_BEGIN_ARGS(SKGIrregularListView)
		: _ElasticStyle(EKGElasticStyle::None)
		, _WheelScrollMultiplier(1)
		{
		}

		SLATE_EVENT(FOnGenerateWidget, OnGenerateWidget)
		SLATE_EVENT(FOnEntryInitialized, OnEntryInitialized)
		SLATE_EVENT(FOnEntryReleased, OnEntryReleased)
		SLATE_EVENT(FOnArrangeItem, OnArrangeItem)
		SLATE_EVENT(FOnDragged, OnDragged)
		SLATE_EVENT(FOnDragStarting, OnDragStarting)
		SLATE_EVENT(FOnSelectionChanged, OnSelectionChanged)
		SLATE_EVENT(FOnScrollEnded, OnScrollEnded)
		SLATE_EVENT(FOnItemSnapped, OnItemSnapped)
		SLATE_EVENT(FOnItemToString_Debug, OnItemToString_Debug)
		SLATE_EVENT(FOnTableViewBadState, OnEnteredBadState);
		SLATE_EVENT(FOnScrollPositionChanged, OnScrollPositionChanged);
		SLATE_EVENT(FOnInteractionStarted, OnInteractionStarted);
		SLATE_EVENT(FOnInteractionEnded, OnInteractionEnded);
		SLATE_ATTRIBUTE(EKGElasticStyle, ElasticStyle);
		SLATE_EVENT(FSimpleDelegate, OnHovered)
		SLATE_EVENT(FSimpleDelegate, OnUnhovered)
		SLATE_ATTRIBUTE(float, WheelScrollMultiplier);
		SLATE_ARGUMENT(bool, bGenerateAllEntries);
		SLATE_ATTRIBUTE(bool, ForceRefreshEveryFrame)

		#pragma region SLATE_ITEMS_SOURCE_ARGUMENT(ItemType, ListItemsSource)

		private:
			const TArray<ItemType>* _ListItemsSource_ArrayPointer = nullptr;
			void _ResetListItemsSource()
			{
				_ListItemsSource_ArrayPointer = nullptr;
			}
		public:
			WidgetArgsType& ListItemsSource(const TArray<ItemType>* InArg)
			{
				_ResetListItemsSource();
				_ListItemsSource_ArrayPointer = InArg;
				return static_cast<WidgetArgsType*>(this)->Me();
			}
			TUniquePtr<::UE::Slate::ItemsSource::IItemsSource<ItemType>> MakeListItemsSource(TSharedRef<SKGIrregularListView> InWidget) const
			{
				if (_ListItemsSource_ArrayPointer)
				{
					return MakeUnique<::UE::Slate::ItemsSource::FArrayPointer<ItemType>>(_ListItemsSource_ArrayPointer);
				}
				return TUniquePtr<::UE::Slate::ItemsSource::IItemsSource<ItemType>>();
			}

		#pragma endregion

	SLATE_END_ARGS()

	SKGIrregularListView()
		: PressedScreenSpacePosition()
		, WidgetGenerator(this)
	{
	}

	static FOnItemToString_Debug GetDefaultDebugDelegate()
	{
		return FOnItemToString_Debug::CreateStatic(TListTypeTraits<ItemType>::DebugDump);
	}

	void Construct(const typename SKGIrregularListView::FArguments& InArgs)
	{
		this->OnGenerateWidget = InArgs._OnGenerateWidget;
		this->OnEntryInitialized = InArgs._OnEntryInitialized;
		this->OnEntryReleased = InArgs._OnEntryReleased;
		this->OnArrangeItem = InArgs._OnArrangeItem;
		this->OnDragged = InArgs._OnDragged;
		this->OnDragStarting = InArgs._OnDragStarting;
		this->OnSelectionChanged = InArgs._OnSelectionChanged;
		this->OnScrollEnded = InArgs._OnScrollEnded;
		this->OnScrollPositionChanged = InArgs._OnScrollPositionChanged;
		this->OnInteractionStarted = InArgs._OnInteractionStarted;
		this->OnInteractionEnded = InArgs._OnInteractionEnded;
		this->OnItemSnapped = InArgs._OnItemSnapped;
		this->SetItemsSource(InArgs.MakeListItemsSource(this->SharedThis(this)));
		this->OnItemToString_Debug = InArgs._OnItemToString_Debug.IsBound()
			? InArgs._OnItemToString_Debug
			: SKGIrregularListView<ItemType>::GetDefaultDebugDelegate();
		this->OnEnteredBadState = InArgs._OnEnteredBadState;
		this->SetElasticStyle(InArgs._ElasticStyle);
		this->bGenerateAllEntries = InArgs._bGenerateAllEntries;
		this->OnHovered = InArgs._OnHovered;
		this->OnUnhovered = InArgs._OnUnhovered;
		this->WheelScrollMultiplier = InArgs._WheelScrollMultiplier;
		this->bForceRefreshEveryFrameEnabled = InArgs._ForceRefreshEveryFrame;

		this->ChildSlot
		[
			SAssignNew(ListPanel, SKGIrregularListPanel<ItemType>, StaticCastSharedRef<SKGIrregularListView>(this->AsShared()))
		];
	}

	void ConstructBackground(TSharedRef<SWidget> InBackgroundWidget)
	{
		auto InternalContent = this->ChildSlot.GetWidget();
		BackgroundWidget = InBackgroundWidget;
		this->ChildSlot
		[
			SNew(SOverlay)
			+ SOverlay::Slot()
			[
				InBackgroundWidget
			]
			+ SOverlay::Slot()
			[
				InternalContent
			]
		];
	}

	virtual void AddReferencedObjects(FReferenceCollector& Collector)
	{
		TIrregularListViewTypeTraits<ItemType>::AddReferencedObjects(Collector, WidgetGenerator.ItemsWithGeneratedWidgets);
		for (auto& It : WidgetGenerator.EntryMapToItem)
		{
			TIrregularListViewTypeTraits<ItemType>::AddReferencedObject(Collector, It.Value);
		}
		TIrregularListViewTypeTraits<ItemType>::AddReferencedObjects(Collector, SelectedItems);
	}

	virtual FString GetReferencerName() const
	{
		return TEXT("SKGIrregularListView");
	}

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override
	{
		if (!bIsRefreshPending && !bForceRefreshEveryFrameEnabled.Get(false))
		{
			return;
		}
		ReGenerateItems(AllottedGeometry);
		bIsRefreshPending = false;

		#pragma region 拖拽中积累松手初速度需要逐渐削弱

		if (bStartedTouchInteraction)
		{
			Velocity = FMath::Lerp(Velocity, 0, InDeltaTime * 10);
			return;
		}

		#pragma endregion

		float MinScrollPosition = GetFinalMinScrollPosition();
		float MaxScrollPosition = GetFinalMaxScrollPosition();

		#pragma region 惯性

		if (Velocity != 0)
		{
			float Remaining = GetRemainingInertiaLengthByVelocity(Velocity);
			float Delta = 0;
			const float FinalDistance = Step * 0.1f;
			if (FMath::Abs(Remaining) < FinalDistance)
				// 小于一定距离时，匀速完成后续惯性…
			{
				Delta = GetVelocityByRemainingInertiaLength(FMath::Sign(Remaining) * FinalDistance) * InDeltaTime;
				Delta = FMath::Min(FMath::Abs(Remaining), FMath::Abs(Delta)) * FMath::Sign(Delta);
			}
			else
			{
				Delta = Velocity * InDeltaTime;
			}
			SetScrollPositionInternal(GetScrollPosition() + Delta, EKGIrregularListViewUpdateSource::Inertia, false);
			Velocity = GetVelocityByRemainingInertiaLength(Remaining - Delta);
			if (ScrollPosition < MinScrollPosition || ScrollPosition > MaxScrollPosition)
			{
				Velocity = FMath::Lerp(Velocity, 0, InDeltaTime * (float)1 / (0.035f));
			}
			if (FMath::Abs(Velocity) < Epsilon)
			{
				Velocity = 0;
				(void) OnScrollEnded.ExecuteIfBound();
			}
			TryUpdateSnappedIndex();
			return;
		}

		#pragma endregion

		#pragma region 回弹

		if (ScrollPosition < MinScrollPosition)
		{
			auto TargetScrollPosition = ScrollPosition + (MinScrollPosition - ScrollPosition) * FMath::Min((32.0f * InDeltaTime), 0.99f);
			if (FMath::IsNearlyEqual(TargetScrollPosition, MinScrollPosition))
			{
				TargetScrollPosition = MinScrollPosition;
			}
			SetScrollPositionInternal(TargetScrollPosition, EKGIrregularListViewUpdateSource::Elasticity, false);
		}
		else if (ScrollPosition > MaxScrollPosition)
		{
			auto TargetScrollPosition = ScrollPosition + (MaxScrollPosition - ScrollPosition) * FMath::Min((32 * InDeltaTime), 0.99f);
			if (FMath::IsNearlyEqual(TargetScrollPosition, MaxScrollPosition))
			{
				TargetScrollPosition = MaxScrollPosition;
			}
			SetScrollPositionInternal(TargetScrollPosition, EKGIrregularListViewUpdateSource::Elasticity, false);
		}

		#pragma endregion
	}

	#pragma region Irregular List View

public:
	void SetScrollPositionInternal(float InScrollPosition, EKGIrregularListViewUpdateSource UpdateSource, bool WithClamping)
	{
		if (WithClamping)
		{
			ScrollPosition = FMath::Clamp(InScrollPosition, GetFinalMinScrollPosition(), GetFinalMaxScrollPosition());
		}
		else
		{
			ScrollPosition = InScrollPosition;
		}
		RequestListRefresh();
		(void) OnScrollPositionChanged.ExecuteIfBound(ScrollPosition, UpdateSource);
	}

	void SetScrollPosition(float InScrollPosition)
	{
		Velocity = 0;
		SetScrollPositionInternal(InScrollPosition, EKGIrregularListViewUpdateSource::Direct, true);
	}

	float GetScrollPosition() const { return ScrollPosition; }

	void SetStep(float InStep)
	{
		Step = FMath::Clamp(InStep, 0, 1);
	}

	float GetStep() const { return Step; }

	void SetPadding(const FKGLinearMargin& InPadding)
	{
		Padding = InPadding;
	}

	const FKGLinearMargin& GetPadding() const { return Padding; }

	void SetElasticStyle(TAttribute<EKGElasticStyle> InElasticStyle)
	{
		ElasticStyle = InElasticStyle.Get();
	}

	EKGElasticStyle GetElasticStyle() const { return ElasticStyle; }

	void SetElasticStrain(float InElasticStrain)
	{
		ElasticStrain = InElasticStrain;
	}

	float GetElasticStrain() const { return ElasticStrain; }

	void SetEntryAnchors(TAttribute<FAnchors> InEntryAnchors)
	{
		EntryAnchors = InEntryAnchors.Get();
	}

	virtual FAnchors GetEntryAnchors() const override { return EntryAnchors; }

	int GetScrollingTargetIndex()
	{
		return GetTargetItemIndexByVelocity(Velocity);
	}

	const ItemType* GetScrollingTargetItem()
	{
		int Index = GetTargetItemIndexByVelocity(Velocity);
		if (Index < 0 || Index >= GetItems().Num())
		{
			return NULL;
		}
		return &GetItems()[Index];
	}

	bool ScrollToIndex(int ItemIndex, bool bAnimated = true)
	{
		if (ItemIndex < 0 || ItemIndex >= GetItems().Num())
		{
			return false;
		}
		float TargetScrollPosition = GetPerfectScrollPositionByItemIndex(ItemIndex);
		if (CyclicEnabled)
		{
			int T;
			int NearestItemIndex = GetNearestItemIndexByScrollPosition(ScrollPosition);
			GetCyclicSmartScrollPositionByFocusedProgress(ScrollPosition, SnapAlignment, T);
			if (NearestItemIndex - ItemIndex > GetItems().Num() * 0.5)
			{
				T++;
			}
			float Cycle = Padding.Upper + Padding.Lower + GetStep() * GetItems().Num();
			TargetScrollPosition += Cycle * T;
		}
		ScrollToPosition(TargetScrollPosition, bAnimated);
		return true;
	}

	bool ScrollToPosition(float TargetScrollPosition, bool bAnimated = true)
	{
		if (TargetScrollPosition < GetFinalMinScrollPosition() || TargetScrollPosition > GetFinalMaxScrollPosition())
		{
			return false;
		}
		bStartedTouchInteraction = false;
		if (bAnimated)
		{
			float CurrentScrollPosition = ScrollPosition;
			float Remaining = TargetScrollPosition - CurrentScrollPosition;
			Velocity = GetVelocityByRemainingInertiaLength(Remaining);
			RequestListRefresh();
		}
		else
		{
			Velocity = 0;
			SetScrollPositionInternal(TargetScrollPosition, EKGIrregularListViewUpdateSource::Scrolling, false);
		}
		return true;
	}

	bool ScrollToItem(ItemType Item, bool bAnimated = true)
	{
		int ItemIndex = GetItems().IndexOfByKey(Item);
		return ScrollToIndex(ItemIndex, bAnimated);
	}

	void SetInertiaEnabled(TAttribute<bool> InInertiaEnabled)
	{
		InertiaEnabled = InInertiaEnabled.Get();
	}

	bool GetInertiaEnabled() const { return InertiaEnabled; }

	void SetCyclicEnabled(TAttribute<bool> InCyclicEnabled)
	{
		CyclicEnabled = InCyclicEnabled.Get();
	}

	bool GetCyclicEnabled() const { return CyclicEnabled; }
	
	void SetSnapEnabled(TAttribute<bool> InSnapEnabled)
	{
		SnapEnabled = InSnapEnabled.Get();
	}

	bool GetSnapEnabled() const { return SnapEnabled; }

	void SetSnapAlignment(TAttribute<float> InSnapAlignment)
	{
		SnapAlignment = InSnapAlignment.Get();
	}

	float GetSnapAlignment() const { return SnapAlignment; }

	void SetAcceleration(float InAcceleration)
	{
		Acceleration = InAcceleration;
	}

	float GetAcceleration() const
	{
		return Acceleration;
	}

	void IrregularToLocal(
		const FGeometry& IrregularListViewGeometry,
		FVector2D IrregularPosition, FVector2D IrregularSize,
		FVector2D& LocalPosition, FVector2D& LocalSize
	) const
	{
		if (ensure(ListPanel))
		{
			ListPanel->IrregularToLocal(IrregularListViewGeometry, IrregularPosition, IrregularSize, LocalPosition, LocalSize);
		}
	}

protected:
	virtual float CalculateProgress(int ItemIndex) const
	{
		return CyclicEnabled
			? GetCyclicProgressByItemIndex(ItemIndex)
			: GetBasicProgressByItemIndex(ItemIndex);
	}

	virtual float GetBasicProgressByItemIndex(int ItemIndex) const
	{
		float ElasticValue = 0;
		float ElasticDistance = 0;
		int ElasticIndex = INDEX_NONE;
		if (ScrollPosition < GetFinalMinScrollPosition())
		{
			ElasticDistance = ScrollPosition - GetFinalMinScrollPosition();
			ElasticIndex = ItemIndex;
		}
		else if (ScrollPosition > GetFinalMaxScrollPosition())
		{
			ElasticDistance = ScrollPosition - GetFinalMaxScrollPosition();
			ElasticIndex = GetItems().Num() - 1 - ItemIndex;
		}
		if (ElasticDistance != 0)
		{
			switch (GetElasticStyle())
			{
			case EKGElasticStyle::None:
				ElasticValue = 0;
				break;
			case EKGElasticStyle::Simple:
				ElasticIndex = 0;
			case EKGElasticStyle::Spring:
				ElasticValue =
					FMath::Pow(0.6f, (float)ElasticIndex)
					*
					FMath::InterpCircularOut(
						0.f,
						Step * ElasticStrain,
						FMath::Clamp(FMath::Abs(ElasticDistance), 0.f, 1.f)
					)
					*
					-FMath::Sign(ElasticDistance);
				break;
			}
		}
		return Step * ItemIndex - ScrollPosition + ElasticDistance + ElasticValue;
	}

	virtual float GetCyclicProgressByItemIndex(int ItemIndex) const
	{
		float Cycle = Padding.Upper + Padding.Lower + GetStep() * GetItems().Num();
		float BasicProgress = Step * ItemIndex - ScrollPosition;
		float Upper = ((float)1.0f - BasicProgress) / Cycle;
		float Lower = -BasicProgress / Cycle;
		if (Upper < Lower)
		{
			return TNumericLimits<float>::Lowest();
		}
		else
		{
			return (float)FMath::CeilToInt(Lower) * Cycle + BasicProgress;
		}
	}

	float GetMinScrollPosition() const { return -Padding.Lower;	}

	float GetFinalMinScrollPosition() const
	{
		return CyclicEnabled
			? TNumericLimits<float>::Lowest()
			: GetMinScrollPosition();
	}

	float GetMaxScrollPosition() const
	{
		return FMath::Max(0, GetStep() * (GetItems().Num() - 1) - (1.0f - Padding.Upper - Padding.Lower)) + GetMinScrollPosition();
	}

	float GetFinalMaxScrollPosition() const
	{
		return CyclicEnabled
			? TNumericLimits<float>::Max()
			: GetMaxScrollPosition();
	}

	static constexpr float Epsilon = 0.001f;

#if 0
	// 之前实现的这种惯性太拖沓

	static const inline float Friction = 0.3f;  // 0.135f
	static const inline float LogeOfFriction = FMath::Loge(Friction);

	static float GetInertiaVelocityFromLastFrame(float LastVelocity, float DeltaTime)
	{
		return LastVelocity * FMath::Pow(Friction, DeltaTime);
	}

	static float GetRemainingInertiaTimeByVelocity(float Velocity)
	{
		if (Velocity == 0)
		{
			return 0;
		}
		return FMath::LogX(Friction, FMath::Abs(Epsilon / Velocity));
	}

	static float GetRemainingInertiaLengthByVelocity(float Velocity)
	{
		// `公式5`中`Epsilon`是一个无限趋近于0的值，`LogeOfFriction`是一个常数，惯性滚动的剩余距离只与当前速度有关：
		return -Velocity / LogeOfFriction;  // 公式6
#if 0
		// 通过将`RemainingTime`带入`公式4`：
		return (FMath::Abs(Epsilon / Velocity) - 1) * Velocity / LogeOfFriction;  // 公式5

		// 剩余惯性滑动的时间
		float RemainingTime = GetRemainingInertiaTimeByVelocity(Velocity);
		// 采用如下公式模拟惯性滚动单帧增量计算
		//   F(DeltaTime) = Velocity * FMath::Pow(Friction, DeltaTime)  // 公式1
		// `公式1`的积分为
		//   G(DeltaTime) = Velocity * FMath::Pow(Friction, DeltaTime) / FMath::Loge(Friction)  // 公式2
		// 所以剩余距离是
		//   G(RemainingTime) - G(0)  // 公式3
		return (FMath::Pow(Friction, RemainingTime) - FMath::Pow(Friction, 0)) * Velocity / FMath::Loge(Friction);  // 公式4
#endif
	}

	static float GetVelocityByRemainingInertiaLength(float Length)
	{
		// GetRemainingInertiaLengthByVelocity的反函数
		return -Length * LogeOfFriction;
	}

#else

	float GetInertiaVelocityFromLastFrame(float InLastVelocity, float InDeltaTime) const
	{
		return InLastVelocity - FMath::Sign(InLastVelocity) * Acceleration * InDeltaTime;
	}

	float GetRemainingInertiaTimeByVelocity(float InVelocity) const
	{
		return FMath::Abs(InVelocity) / Acceleration;
	}

	float GetRemainingInertiaLengthByVelocity(float InVelocity) const
	{
		return FMath::Abs(InVelocity) * InVelocity / Acceleration * 0.5f;
	}

	float GetVelocityByRemainingInertiaLength(float InLength) const
	{
		return FMath::Sqrt(FMath::Abs(InLength * Acceleration / 0.5f)) * FMath::Sign(InLength);
	}

#endif

	int GetTargetItemIndexByVelocity(float InVelocity) const
	{
		float Remaining = GetRemainingInertiaLengthByVelocity(InVelocity);
		float EndScrollPosition = ScrollPosition + Remaining;
		EndScrollPosition = FMath::Clamp(EndScrollPosition, GetFinalMinScrollPosition(), GetFinalMaxScrollPosition());
		return FMath::RoundToInt(EndScrollPosition / Step);
	}

	float GetPerfectVelocityByTargetItemIndex(int TargetItemIndex, float& Remaining) const
	{
		float EndScrollPosition = (float)TargetItemIndex * Step;
		Remaining = EndScrollPosition - ScrollPosition;
		return GetVelocityByRemainingInertiaLength(Remaining);
	}

	float GetPerfectScrollPositionByItemIndex(int ItemIndex)
	{
		check(ItemIndex >= 0 && ItemIndex < GetItems().Num());
		return ItemIndex * Step - SnapAlignment;
	}

	float GetCyclicSmartScrollPositionByFocusedProgress(float InScrollPosition, float FocusedProgress, int& T)
		// 返回和输入值循环滚动状态一致的滚动位置（某个位置经过整数周期到达的新位置和该位置循环滚动状态一致），表示在这
		// 个滚动位置下，关注的进度`FocusedProgress`真实值就是当前值（没有周期累计，从而可以使用非循环滚动下的各种接口）
	{
		int ItemCount = GetItems().Num();
		float Cycle = Padding.Upper + Padding.Lower + GetStep() * GetItems().Num();
		float Temp = InScrollPosition + Padding.Lower;
		int LowerT = FMath::FloorToFloat(Temp / Cycle);
		int UpperT = FMath::CeilToFloat(Temp / Cycle);
		float LowerScrollPosition = (Temp - LowerT * Cycle) - Padding.Lower;
		float UpperScrollPosition = (Temp - UpperT * Cycle) - Padding.Lower;
		int LowerIndex = FMath::RoundToInt((LowerScrollPosition + FocusedProgress) / Step);
		int UpperIndex = FMath::RoundToInt((UpperScrollPosition + FocusedProgress) / Step);
		int LowerDistance = TNumericLimits<int>::Max();
		int UpperDistance = TNumericLimits<int>::Max();
		if (LowerIndex >= 0 && LowerIndex < ItemCount)
		{
			T = LowerT;
			return LowerScrollPosition;
		}
		else
			LowerDistance = FMath::Min3(LowerDistance, FMath::Abs(LowerIndex), FMath::Abs(LowerIndex - ItemCount + 1));
		if (UpperIndex >= 0 && UpperIndex < ItemCount)
		{
			T = UpperT;
			return UpperScrollPosition;
		}
		else
			UpperDistance = FMath::Min3(UpperDistance, FMath::Abs(UpperIndex), FMath::Abs(UpperIndex - ItemCount + 1));
		if (LowerDistance < UpperDistance)
		{
			T = LowerT;
			return LowerScrollPosition;
		}
		else
		{
			T = UpperT;
			return UpperScrollPosition;
		}
	}

	int GetNearestItemIndexByScrollPosition(float InScrollPosition)
	{
		int ItemCount = GetItems().Num();
		if (ItemCount == 0)
		{
			return INDEX_NONE;
		}
		if (CyclicEnabled)
		{
			int _;
			InScrollPosition = GetCyclicSmartScrollPositionByFocusedProgress(InScrollPosition, SnapAlignment, _);
		}
		return FMath::Clamp(
			FMath::RoundToInt((InScrollPosition + SnapAlignment) / Step),
			0,
			ItemCount - 1);
	}

	void TryUpdateSnappedIndex()
	{
		if (!GetSnapEnabled())
		{
			return;
		}
		int Index = GetNearestItemIndexByScrollPosition(ScrollPosition);
		if (Index != SnappedIndex)
		{
			SnappedIndex = Index;
			if (SnappedIndex != INDEX_NONE)
			{
				auto& Item = GetItems()[SnappedIndex];
				OnItemSnapped.ExecuteIfBound(Item);
				SetItemSelectionDryly(Item, true, ESelectInfo::Direct);
			}
		}
	}

	virtual FVector2D ComputeIrregularPosition(const FGeometry& AllottedGeometry, const TSharedRef<SWidget>& CurWidget) override
	{
		const TObjectPtrWrapTypeOf<ItemType>* Item = ItemFromWidget(&CurWidget.Get());
		if (Item != NULL && OnArrangeItem.IsBound())
		{
			const IKGIrregularListEntry* IrregularListEntry = EntryFromWidget(&CurWidget.Get());
			float Progress = CalculateProgress(IrregularListEntry->GetIndexInList());
			return OnArrangeItem.Execute(AllottedGeometry, *Item, Progress);
		}
		return FVector2D();
	}

	virtual int ComputeLayerIdIncrement(const TSharedRef<SWidget>& Widget) override
	{
		switch (OverlayStyle)
		{
		case EKGOverlayStyle::None:
			break;
		case EKGOverlayStyle::Incremental:
			return 1;
			break;
		case EKGOverlayStyle::Specific:
			if (const TObjectPtrWrapTypeOf<ItemType>* Item = ItemFromWidget(&Widget.Get()))
			{
				if (OverlayIncrementalItems.Contains(*Item))
				{
					return 1;
				}
			}
			break;
		default:
			check(false);
		}
		return 0;
	}

	float ScrollPosition = 0;
	float Step = 0.1f;
	FKGLinearMargin Padding;
	EKGElasticStyle ElasticStyle = EKGElasticStyle::None;
	float ElasticStrain = 1.f;
	float Velocity = 0;
	bool InertiaEnabled = true;
	bool CyclicEnabled = false;
	float Acceleration = 1.f;

	FAnchors EntryAnchors = FAnchors(0.5f);
	FVector2D EntryAlignment = FVector2D(0.5f, 0.5f);

	bool SnapEnabled = false;
	float SnapAlignment = 0.5f;
	int SnappedIndex = INDEX_NONE;

	#pragma endregion

	#pragma region Interaction

	virtual FReply OnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		if (MouseEvent.IsTouchEvent())
		{
			if (!OnDragStarting.IsBound() || OnDragStarting.Execute(MyGeometry, MouseEvent))
			{
				PressedScreenSpacePosition = MouseEvent.GetScreenSpacePosition();
				bStartedTouchInteraction = true;
				Velocity = 0;
			}
			return FReply::Unhandled();
		}
		else
		{
			return FReply::Unhandled();
		}
	}

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		if (this->HasMouseCapture())
		{
			// Consume all mouse buttons while we are RMB-dragging.
			return FReply::Handled();
		}
		return FReply::Unhandled();
	}

	virtual void OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		const bool bWasHovered = IsHovered();
		Super::OnMouseEnter(MyGeometry, MouseEvent);
		if (MouseEvent.IsTouchEvent())
		{
			if (!bStartedTouchInteraction)
			{
				if (MyGeometry.IsUnderLocation(MouseEvent.GetLastScreenSpacePosition()))
				{
					if (!OnDragStarting.IsBound() || OnDragStarting.Execute(MyGeometry, MouseEvent))
					{
						bStartedTouchInteraction = true;
					}
				}
			}
		}

		if (!bWasHovered && IsHovered())
		{
			ExecuteHoverStateChanged();
		}
	}

	virtual void OnMouseLeave(const FPointerEvent& MouseEvent) override
	{
		const bool bWasHovered = IsHovered();
		Super::OnMouseLeave(MouseEvent);
		FinishTouchInteraction();

		if (bWasHovered && !IsHovered())
		{
			ExecuteHoverStateChanged();
		}
	}

	virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override { return FReply::Unhandled(); }

	virtual FReply OnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		auto FinalWheelScrollMultiplier = WheelScrollMultiplier.IsSet() ? WheelScrollMultiplier.Get() : 0;
		if (FinalWheelScrollMultiplier == 0.0f)
		{
			return FReply::Unhandled();
		}
		SetScrollPositionInternal(MouseEvent.GetWheelDelta() * FinalWheelScrollMultiplier + GetScrollPosition(), EKGIrregularListViewUpdateSource::Scrolling, false || ElasticStyle == EKGElasticStyle::None || CyclicEnabled);
		return FReply::Handled();
	}
	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override { return FReply::Unhandled(); }

	virtual FReply OnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override
	{
		// See OnPreviewMouseButtonDown()
		//     if (MouseEvent.IsTouchEvent())

		if (bStartedTouchInteraction)
		{
			(void)OnInteractionStarted.ExecuteIfBound();
		}
		return FReply::Handled();
	}

	virtual FReply OnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override
	{
		if (!bStartedTouchInteraction)
		{
			return FReply::Unhandled();
		}
		if (FSlateApplication::Get().HasTraveledFarEnoughToTriggerDrag(InTouchEvent, PressedScreenSpacePosition))
		{
			float DeltaProgress = 0;
			if (OnDragged.IsBound())
			{
				DeltaProgress = -OnDragged.Execute(MyGeometry, InTouchEvent);
			}
			float DeltaTime = FSlateApplication::Get().GetDeltaTime();
			Velocity = FMath::Lerp(Velocity, DeltaProgress / DeltaTime, DeltaTime * 10);
			SetScrollPositionInternal(DeltaProgress + GetScrollPosition(), EKGIrregularListViewUpdateSource::Scrolling, false || ElasticStyle == EKGElasticStyle::None || CyclicEnabled);
		}
		return FReply::Handled();
	}

	void FinishTouchInteraction()
	{
		if (!bStartedTouchInteraction)
		{
			return;
		}
		bStartedTouchInteraction = false;

		(void)OnInteractionEnded.ExecuteIfBound();

		if (!InertiaEnabled)
		{
			Velocity = 0;
		}

		if (GetSnapEnabled())
		{
			float Remaining = GetRemainingInertiaLengthByVelocity(Velocity);
			int ItemIndex = GetNearestItemIndexByScrollPosition(ScrollPosition + Remaining);
			if (CyclicEnabled)
			{
				#pragma region 如果是循环滚动，那拖拽结束时应该根据速度决定最终滚动位置，速度过快时，可能会经历多个周期
				int T;
				GetCyclicSmartScrollPositionByFocusedProgress(ScrollPosition + Remaining, SnapAlignment, T);
				float TargetScrollPosition = GetPerfectScrollPositionByItemIndex(ItemIndex);
				float Cycle = Padding.Upper + Padding.Lower + GetStep() * GetItems().Num();
				#pragma endregion
				ScrollToPosition(TargetScrollPosition + T * Cycle);
			}
			else
			{
				ScrollToIndex(ItemIndex);
			}
		}

		#pragma region 松手时如何就在回弹位置，则不再模拟惯性

		float MinScrollPosition = GetFinalMinScrollPosition();
		float MaxScrollPosition = GetFinalMaxScrollPosition();
		if (ScrollPosition < MinScrollPosition || ScrollPosition > MaxScrollPosition)
		{
			Velocity = 0;
			RequestListRefresh();
		}

		#pragma endregion

		if (Velocity == 0)
		{
			(void)OnScrollEnded.ExecuteIfBound();
		}
	}

	virtual FReply OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override
	{
		FinishTouchInteraction();
		return FReply::Unhandled();
	}

	bool bStartedTouchInteraction = false;
	FVector2f PressedScreenSpacePosition;

	#pragma endregion

	#pragma region ItemsSource

public:
	void SetListItemsSource(const TArray<ItemType>& InListItemsSource)
	{
		SetItemsSource(&InListItemsSource);
	}

	bool HasValidItemsSource() const
	{
		return ViewSource != nullptr;
	}

	TArrayView<const ItemType> GetItems() const
	{
		return ViewSource ? ViewSource->GetItems() : TArrayView<const ItemType>();
	}

private:
	void SetItemsSource(const TArray<ItemType>* InListItemsSource)
	{
		ensureMsgf(InListItemsSource, TEXT("The ListItems is invalid."));
		if (ViewSource == nullptr || !ViewSource->IsSame(reinterpret_cast<const void*>(InListItemsSource)))
		{
			if (InListItemsSource)
			{
				SetItemsSource(MakeUnique<UE::Slate::ItemsSource::FArrayPointer<ItemType>>(InListItemsSource));
			}
			else
			{
				ClearItemsSource();
			}
		}
	}

	void SetItemsSource(TUniquePtr<UE::Slate::ItemsSource::IItemsSource<ItemType>> Provider)
	{
		if (IsConstructed())
		{
			// TODO
			ClearItemsSource();
			//CancelScrollIntoView();
			ListPanel->ClearWidgets();

			ViewSource = MoveTemp(Provider);

			// TODO
			//RebuildList();
		}
		else
		{
			ViewSource = MoveTemp(Provider);
		}
	}

	void ClearItemsSource()
	{
		SetItemsSource(TUniquePtr<UE::Slate::ItemsSource::IItemsSource<ItemType>>());
	}

	TUniquePtr<UE::Slate::ItemsSource::IItemsSource<ItemType>> ViewSource;

	#pragma endregion

	#pragma region WidgetGenerator

private:

	friend class FWidgetGenerator;

	class FWidgetGenerator
	{
	public:
		FWidgetGenerator(SKGIrregularListView<ItemType>* InOwnerList)
			: OwnerList(InOwnerList)
		{
		}
		
		TSharedPtr<IKGIrregularListEntry> GetWidgetForItem(const ItemType& Item) const
		{
			const TSharedRef<IKGIrregularListEntry>* LookupResult = ItemToWidgetMap.Find(Item);
			return LookupResult ? TSharedPtr<IKGIrregularListEntry>(*LookupResult) : TSharedPtr<IKGIrregularListEntry>(nullptr);
		}

		void OnBeginGenerationPass()
		{
			ItemsToBeCleanedUp = ItemsWithGeneratedWidgets;
			ItemsWithGeneratedWidgets.Empty();
		}

		void OnEndGenerationPass()
		{
			ProcessItemCleanUp();
			ValidateWidgetGeneration();
		}

		void Clear()
		{
			ItemsToBeCleanedUp = ItemsWithGeneratedWidgets;
			ItemsWithGeneratedWidgets.Empty();
			ProcessItemCleanUp();
		}

		void OnItemSeen(ItemType InItem, TSharedRef<IKGIrregularListEntry> InGeneratedWidget)
		{
			TSharedRef<IKGIrregularListEntry>* LookupResult = ItemToWidgetMap.Find(InItem);
			const bool bWidgetIsNewlyGenerated = (LookupResult == nullptr);

			if (bWidgetIsNewlyGenerated)
			{
				ItemToWidgetMap.Add(InItem, InGeneratedWidget);
				EntryMapToItem.Add(&InGeneratedWidget.Get(), InItem);
				WidgetMapToEntry.Add(&InGeneratedWidget->AsWidget().Get(), InGeneratedWidget);
				InGeneratedWidget->InitializeRow();
				InGeneratedWidget->UpdateItemSelection(InGeneratedWidget->IsItemSelected(), ESelectInfo::Direct);
				OwnerList->OnEntryInitialized.ExecuteIfBound(InItem, InGeneratedWidget);
			}
			else
			{
				check(*EntryMapToItem.Find(&LookupResult->Get()) == InItem);
			}
			ItemsToBeCleanedUp.Remove(InItem);
			ItemsWithGeneratedWidgets.Add(InItem);
		}

		void ProcessItemCleanUp()
		{
			for (int32 ItemIndex = 0; ItemIndex < ItemsToBeCleanedUp.Num(); ++ItemIndex)
			{
				ItemType ItemToBeCleanedUp = ItemsToBeCleanedUp[ItemIndex];
				const TSharedRef<IKGIrregularListEntry>* FindResult = ItemToWidgetMap.Find(ItemToBeCleanedUp);
				if (FindResult != nullptr)
				{
					const TSharedRef<IKGIrregularListEntry> WidgetToCleanUp = *FindResult;
					ItemToWidgetMap.Remove(ItemToBeCleanedUp);
					EntryMapToItem.Remove(&WidgetToCleanUp.Get());
					WidgetMapToEntry.Remove(&WidgetToCleanUp->AsWidget().Get());
					if (ensureMsgf(OwnerList, TEXT("OwnerList is null, something is wrong.")))
					{
						//WidgetToCleanUp->ResetRow();
						OwnerList->OnEntryReleased.ExecuteIfBound(ItemToBeCleanedUp, WidgetToCleanUp);
					}
				}
				else if (!TListTypeTraits<ItemType>::IsPtrValid(ItemToBeCleanedUp))
				{
					auto EntryPtr = EntryMapToItem.FindKey(ItemToBeCleanedUp);
					if (EntryPtr != nullptr)
					{
						for (auto WidgetItemPair = ItemToWidgetMap.CreateIterator(); WidgetItemPair; ++WidgetItemPair)
						{
							const IKGIrregularListEntry* Entry = &(WidgetItemPair.Value().Get());
							if (Entry == *EntryPtr)
							{
								WidgetItemPair.RemoveCurrent();
								break;
							}
						}
						EntryMapToItem.Remove(*EntryPtr);
						TSharedRef<SWidget> Widget = const_cast<IKGIrregularListEntry*>(*EntryPtr)->AsWidget();
						auto WidgetPtr = &Widget.Get();
						OwnerList->OnEntryReleased.ExecuteIfBound(ItemType(), WidgetMapToEntry[WidgetPtr]);
						WidgetMapToEntry.Remove(WidgetPtr);
					}
				}
			}
			ItemsToBeCleanedUp.Reset();
		}

		void ValidateWidgetGeneration()
		{
			// TODO
			;
		}

	public:
		SKGIrregularListView<ItemType>* OwnerList;
		TMap<ItemType, TSharedRef<IKGIrregularListEntry>> ItemToWidgetMap;
		TMap<const IKGIrregularListEntry*, TObjectPtrWrapTypeOf<ItemType>> EntryMapToItem;
		TMap<const SWidget*, TSharedRef<IKGIrregularListEntry>> WidgetMapToEntry;
		TArray<TObjectPtrWrapTypeOf<ItemType>> ItemsWithGeneratedWidgets;
		TArray<ItemType> ItemsToBeCleanedUp;
	};

	struct FGenerationPassGuard
	{
		FWidgetGenerator& Generator;
		FGenerationPassGuard(FWidgetGenerator& InGenerator)
			: Generator(InGenerator)
		{
			Generator.OnBeginGenerationPass();
		}

		~FGenerationPassGuard()
		{
			Generator.OnEndGenerationPass();
		}
	};

	FWidgetGenerator WidgetGenerator;

	#pragma endregion

protected:
	EActiveTimerReturnType EnsureTickToRefresh(double InCurrentTime, float InDeltaTime)
	{
		return EActiveTimerReturnType::Stop;
	}

public:
	void RequestListRefresh()
	{
		if (!bIsRefreshPending)
		{
			if (!bIsRefreshPending)
			{
				RegisterActiveTimer(0.f, FWidgetActiveTimerDelegate::CreateSP(this, &SKGIrregularListView::EnsureTickToRefresh));
			}
			bIsRefreshPending = true;
		}
		Invalidate(EInvalidateWidget::Layout);
	}

	virtual void ReGenerateItems(const FGeometry& MyGeometry)
	{
		ListPanel->ClearWidgets();
		{
			FGenerationPassGuard GenerationPassGuard(WidgetGenerator);
			const TArrayView<const ItemType> Items = GetItems();
			const float LayoutScaleMultiplier = MyGeometry.GetAccumulatedLayoutTransform().GetScale();
			for (int32 ItemIndex = 0; ItemIndex < Items.Num(); ++ItemIndex)
			{
				float Progress = CalculateProgress(ItemIndex);
				if (!bGenerateAllEntries && (Progress < 0.f || Progress >= 1.f))
				{
					continue;
				}
				const ItemType& CurItem = Items[ItemIndex];
				GenerateWidgetForItem(CurItem, ItemIndex, LayoutScaleMultiplier);
			}
		}
		TryUpdateSnappedIndex();
	}

	TSharedPtr<IKGIrregularListEntry> WidgetFromItem(const ItemType& InItem) const
	{
		return WidgetGenerator.GetWidgetForItem(InItem);
	}

	const TObjectPtrWrapTypeOf<ItemType>* ItemFromEntry(const IKGIrregularListEntry* WidgetToFind) const
	{
		return WidgetGenerator.EntryMapToItem.Find(WidgetToFind);
	}

	const TObjectPtrWrapTypeOf<ItemType>* ItemFromWidget(const SWidget* WidgetToFind) const
	{
		return ItemFromEntry(EntryFromWidget(WidgetToFind));
	}

	const IKGIrregularListEntry* EntryFromWidget(const SWidget* WidgetToFind) const
	{
		auto* Found = WidgetGenerator.WidgetMapToEntry.Find(WidgetToFind);
		if (Found == NULL)
		{
			return NULL;
		}
		return &(*Found).Get();
	}

	virtual bool IsPendingRefresh() const override
	{
		return bIsRefreshPending;
	}

	bool GetItemProgress(ItemType Item, float& OutProgress)
	{
		auto Index = GetItems().Find(Item);
		OutProgress = CalculateProgress(Index);
		return Index != INDEX_NONE;
	}

	float GetItemProgressChecked(ItemType Item)
	{
		auto Index = GetItems().Find(Item);
		check(Index != INDEX_NONE);
		return CalculateProgress(Index);
	}

	float GetItemProgressChecked(int ItemIndex)
	{
		check(ItemIndex >= 0 && ItemIndex < GetItems().Num());
		return CalculateProgress(ItemIndex);
	}

private:
	void GenerateWidgetForItem(const ItemType& CurItem, int32 ItemIndex, float LayoutScaleMultiplier)
	{
		TSharedPtr<IKGIrregularListEntry> WidgetForItem = WidgetGenerator.GetWidgetForItem(CurItem);
		if (!WidgetForItem.IsValid())
		{
			WidgetForItem = this->GenerateNewWidget(CurItem);
		}
		WidgetForItem->SetIndexInList(ItemIndex);
		WidgetGenerator.OnItemSeen(CurItem, WidgetForItem.ToSharedRef());

		const TSharedRef<SWidget> NewlyGeneratedWidget = WidgetForItem->AsWidget();
		NewlyGeneratedWidget->MarkPrepassAsDirty();
		NewlyGeneratedWidget->SlatePrepass(LayoutScaleMultiplier);

		check(this->ListPanel.IsValid());
		this->ListPanel->AppendWidget(WidgetForItem->AsWidget());
	}

	virtual TSharedRef<IKGIrregularListEntry> GenerateNewWidget(ItemType InItem)
	{
		if (OnGenerateWidget.IsBound())
		{
			return OnGenerateWidget.Execute(InItem, SharedThis(this));
		}
		else
		{
			return CreateDefaultListEntry(NSLOCTEXT("SKGIrregularListView", "OnGenerateWidgetNotAssignedMessage", "OnGenerateWidget() not assigned."));
		}
	}

	bool bIsRefreshPending = false;
	FOnGenerateWidget OnGenerateWidget;
	FOnEntryInitialized OnEntryInitialized;
	FOnEntryReleased OnEntryReleased;
	FOnArrangeItem OnArrangeItem;
	FOnDragged OnDragged;
	FOnDragStarting OnDragStarting;
	FOnItemToString_Debug OnItemToString_Debug;
	FOnTableViewBadState OnEnteredBadState;
	TSharedPtr<SKGIrregularListPanel<ItemType>> ListPanel;
	TWeakPtr<SWidget> BackgroundWidget;
	TAttribute<bool> bForceRefreshEveryFrameEnabled;

public:
	typedef TSet<TObjectPtrWrapTypeOf<ItemType>> TItemSet;

	TItemSet SetItemSelectionDryly(ItemType Item, bool bSelected, ESelectInfo::Type SelectInfo = ESelectInfo::Direct)
	{
		switch (SelectionMode.Get())
		{
		case ESelectionMode::None:
			break;
		case ESelectionMode::Single:
			if (bSelected) { SelectedItems.Empty(); SelectedItems.Add(Item); }
			break;
		case ESelectionMode::SingleToggle:
			if (bSelected) { SelectedItems.Empty(); SelectedItems.Add(Item); }
			else { SelectedItems.Remove(Item); }
			break;
		case ESelectionMode::Multi:
			if (bSelected) { SelectedItems.Add(Item); }
			else { SelectedItems.Remove(Item); }
			break;
		default:
			break;
		}
		return SignalSelectionChanged(ESelectInfo::Direct);
	}

	void SetSelectionMode(TAttribute<ESelectionMode::Type> InSelectionMode)
	{
		this->SelectionMode = InSelectionMode;
	}

	ESelectionMode::Type GetSelectionMode() const
	{
		return this->SelectionMode.Get();
	}

	void SetItemSelection(ItemType Item, bool bSelected, ESelectInfo::Type SelectInfo = ESelectInfo::Direct)
	{
		if (SelectionMode.Get() == ESelectionMode::None)
		{
			return;
		}
		if (bSelected && GetSnapEnabled())
		{
			ScrollToItem(Item);
		}
		else
		{
			SetItemSelectionDryly(Item, bSelected, SelectInfo);
		}
	}

	void ClearSelection()
	{
		SelectedItems.Empty();
		SignalSelectionChanged(ESelectInfo::Direct);
	}

	bool IsItemSelected(const ItemType& InItem) const
	{
		return nullptr != SelectedItems.Find(InItem);
	}

	const TItemSet& GetSelectedItems() const
	{
		return SelectedItems;
	}

	virtual void RebuildList()
	{
		WidgetGenerator.Clear();
		RequestListRefresh();
	}

	EKGOverlayStyle GetOverlayStyle() const
	{
		return OverlayStyle;
	}

	void SetOverlayStyle(const EKGOverlayStyle& InOverlayStyle)
	{
		OverlayStyle = InOverlayStyle;
		Invalidate(EInvalidateWidgetReason::Layout);
	}

	void AddOverlayIncrementalItem(ItemType Item)
	{
		OverlayIncrementalItems.AddUnique(Item);
		Invalidate(EInvalidateWidgetReason::Layout);
	}

	void RemoveOverlayIncrementalItem(ItemType Item)
	{
		OverlayIncrementalItems.Remove(Item);
		Invalidate(EInvalidateWidgetReason::Layout);
	}

	void SetOverlayIncrementalItems(const TArray<ItemType>& InOverlayIncrementalItems)
	{
		OverlayIncrementalItems = InOverlayIncrementalItems;
		Invalidate(EInvalidateWidgetReason::Layout);
	}

protected:
	virtual TItemSet SignalSelectionChanged(ESelectInfo::Type SelectInfo)
	{
		for (auto& Item : AppearingSelectedItems.Difference(SelectedItems))
		{
			TSharedPtr<IKGIrregularListEntry> Widget = WidgetFromItem(Item);
			if (Widget.IsValid())
			{
				Widget->UpdateItemSelection(false, SelectInfo);
			}
			else
			{
			}
			OnSelectionChanged.ExecuteIfBound(Item, false, SelectInfo);
		}
		auto NewlySelectedItems = SelectedItems.Difference(AppearingSelectedItems);
		for (auto& Item : NewlySelectedItems)
		{
			TSharedPtr<IKGIrregularListEntry> Widget = WidgetFromItem(Item);
			if (Widget.IsValid())
			{
				Widget->UpdateItemSelection(true, SelectInfo);
			}
			else
			{
			}
			OnSelectionChanged.ExecuteIfBound(Item, true, SelectInfo);
		}
		AppearingSelectedItems = SelectedItems;
		return MoveTemp(NewlySelectedItems);
	}

	TItemSet SelectedItems;
	TItemSet AppearingSelectedItems;
	TAttribute<ESelectionMode::Type> SelectionMode = ESelectionMode::Single;
	EKGOverlayStyle OverlayStyle = EKGOverlayStyle::None;
	TArray<ItemType> OverlayIncrementalItems;
	FOnSelectionChanged OnSelectionChanged;
	FOnScrollEnded OnScrollEnded;
	FOnScrollPositionChanged OnScrollPositionChanged;
	FOnInteractionStarted OnInteractionStarted;
	FOnInteractionEnded OnInteractionEnded;
	FOnItemSnapped OnItemSnapped;
	bool bGenerateAllEntries = false;

public:
	TSharedRef<IKGIrregularListEntry> CreateDefaultListEntry(const FText& Text)
	{
		return
		SNew(SKGIrregularListEntry<ItemType>, SharedThis(this))
		.Content()
		[
			SNew(STextBlock).Text(Text)
		];
	}

protected:
	virtual bool SupportsKeyboardFocus() const override
	{
#if WITH_EDITOR
		const bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#else
		const static bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#endif
		if (bDisableFocusableGlobally)
		{
			return false;
		}

		return Super::SupportsKeyboardFocus();
	}

protected:
	void ExecuteHoverStateChanged()
	{
		if (IsHovered())
		{
			(void) OnHovered.ExecuteIfBound();
		}
		else
		{
			(void) OnUnhovered.ExecuteIfBound();
		}
	}

	FSimpleDelegate OnHovered;
	FSimpleDelegate OnUnhovered;

protected:
	TAttribute<float> WheelScrollMultiplier;
};