#pragma once

#include "KGUISettings.h"
#include "Widgets/Views/SListView.h"
#include "Components/Widget.h"
#include "Core/Common.h"
#include "Framework/Application/IInputProcessor.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Layout/SConstraintCanvas.h"
#include "Slate/Layout/SKGRotateBox.h"

UENUM(BlueprintType)
enum class EKGScrollBarVisibility : uint8
{
	Visible = 0,
	Collapsed = 1,
	Hidden = 2,
	HitTestInvisible = 3 UMETA(DisplayName = "Not Hit-Testable (Self & All Children)"),
	SelfHitTestInvisible = 4 UMETA(DisplayName = "Not Hit-Testable (Self Only)"),
	Auto = 5
};

UENUM(BlueprintType)
enum class EKGListViewScrollHintType : uint8
{
	Before,
	After,
};

template <typename ItemType>
class SKGListView : public SListView<ItemType>
{
	using Super = SListView<ItemType>;
	using typename Super::FReGenerateResults;

public:
	DECLARE_DELEGATE_OneParam(FKGOnItemsRefreshed, const FGeometry&);

	bool IsTicking() const { return bIsTicking; }

protected:
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override
	{
		bIsTicking = true;
		TickingAllottedGeometry = &AllottedGeometry;
		Super::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
		TickingAllottedGeometry = nullptr;
		bIsTicking = false;
	}

	const FGeometry& GetTickingAllottedGeometry() const
	{
		check(TickingAllottedGeometry);
		return *TickingAllottedGeometry;
	}

	const FGeometry* TickingAllottedGeometry = nullptr;
	bool bIsTicking = false;

	#pragma region 重写滚动到视口内功能，添加"Alignment"参数使得滚动的控制更丰富

public:
	using EScrollIntoViewResult = typename Super::EScrollIntoViewResult;

	SKGListView(ETableViewMode::Type InListMode = ETableViewMode::List)
		: SListView<ItemType>(InListMode)
		, SpecificScrollIntoViewAlignment(0)
		, bUseSpecificScrollIntoViewAlignment(false)
	{
		this->bClippingProxy = true;
		this->SetUseBetterSingleRowOverflowHandling(GetDefault<UKGUISettings>()->bUseBetterSingleRowOverflowHandling);
	}

	auto SetScrollbarDisabledVisibility(EVisibility DisabledVisibility)
	{
		if (this->ScrollBar.IsValid())
		{
			this->ScrollBar->SetScrollbarDisabledVisibility(DisabledVisibility);
		}
	}

	virtual void RequestScrollIntoView(ItemType ItemToView, const uint32 UserIndex = 0) override
	{
		Super::RequestScrollIntoView(ItemToView, UserIndex);
		bUseSpecificScrollIntoViewAlignment = false;
	}

	virtual void RequestScrollIntoView(ItemType ItemToView, const float Alignment, const uint32 UserIndex = 0)
	{
		Super::RequestScrollIntoView(ItemToView, UserIndex);
		bUseSpecificScrollIntoViewAlignment = true;
		SpecificScrollIntoViewAlignment = Alignment;
	}

	virtual ItemType GetScrollIntoViewLinearizedItem(ItemType Item)
	{
		return Item;
	}
	
	virtual EScrollIntoViewResult ScrollIntoView(const FGeometry& ListViewGeometry) override
	{
#if WITH_EDITOR
		const bool bUseImprovedScrollToViewImplementation = GetDefault<UKGUISettings>()->bUseImprovedScrollToViewImplementation;
#else
		const static bool bUseImprovedScrollToViewImplementation = GetDefault<UKGUISettings>()->bUseImprovedScrollToViewImplementation;
#endif
		if (!bUseImprovedScrollToViewImplementation)
		{
			return Super::ScrollIntoView(ListViewGeometry);
		}
		auto LinearizedItem = GetScrollIntoViewLinearizedItem(this->ItemToScrollIntoView);
		if (this->HasValidItemsSource() && TListTypeTraits<ItemType>::IsPtrValid(this->ItemToScrollIntoView))
		{
			const TArrayView<const ItemType> Items = this->GetItems();
			const int32 IndexOfItem = Items.Find( TListTypeTraits<ItemType>::NullableItemTypeConvertToItemType(LinearizedItem));
			if (IndexOfItem != INDEX_NONE)
			{
				double NumLiveWidgets = this->GetNumLiveWidgets();
				if (NumLiveWidgets == 0. && this->IsPendingRefresh())
				{
					NumLiveWidgets = this->LastGenerateResults.ExactNumLinesOnScreen;
					if (NumLiveWidgets == 0)
					{
						return EScrollIntoViewResult::Deferred;
					}
				}
				this->EndInertialScrolling();
				// Override:

				const int32 NumFullEntriesInView = (int32)(FMath::FloorToDouble(this->CurrentScrollOffset + NumLiveWidgets) - FMath::CeilToDouble(this->CurrentScrollOffset));
				const double MinDisplayedIndex = this->bNavigateOnScrollIntoView ? FMath::FloorToDouble(this->CurrentScrollOffset) : FMath::CeilToDouble(this->CurrentScrollOffset);
				const double MaxDisplayedIndex = this->bNavigateOnScrollIntoView ? FMath::CeilToDouble(this->CurrentScrollOffset + NumFullEntriesInView) : FMath::FloorToDouble(this->CurrentScrollOffset + NumFullEntriesInView);

				do
				{
					float Alignment;
					if (bUseSpecificScrollIntoViewAlignment)
					{
						Alignment = FMath::Clamp(SpecificScrollIntoViewAlignment, 0, 1);
					}
					else
					{
						if (IndexOfItem < MinDisplayedIndex)
						{
							Alignment = 0;
						}
						else if (IndexOfItem >= MaxDisplayedIndex)  // 这里也需要考虑等于的情况，因为如果是最大显示序号，一定是最后一个，那它最多是对齐于下边缘，否则和下边缘相交（相交时则需要滚动到下对齐）。
						{
							Alignment = 1;
						}
						else
						{
							break;
						}
					}
					const float LayoutScaleMultiplier = ListViewGeometry.GetAccumulatedLayoutTransform().GetScale();
					const FTableViewDimensions ListViewDimensions(this->Orientation, ListViewGeometry.GetLocalSize());
					FTableViewDimensions UpperContentPadding(this->Orientation, this->ContentPadding.GetTopLeft());
					FTableViewDimensions LowerContentPadding(this->Orientation, this->ContentPadding.Right, this->ContentPadding.Bottom);
					float RemainingDistance = ListViewDimensions.ScrollAxis * Alignment;
					int ItemIndex = IndexOfItem + 1;
					TSharedPtr<ITableRow> RowWidget;
					bool bFirst = true;
					while (RemainingDistance >= 0 && ItemIndex > 0)
					{
						ItemIndex--;
						const ItemType& CurItem = Items[ItemIndex];
						RowWidget = GetOrCreateWidgetForItemInternal(CurItem, ItemIndex, LayoutScaleMultiplier);
						FTableViewDimensions WidgetDimensions(this->Orientation, RowWidget->AsWidget()->GetDesiredSize());
						// ModifyWidgetDimensions(WidgetDimensions, ItemIndex);  不该调用这里，计算滚动位置需要原始不包括内容边距的尺寸。
						if (bFirst)
						{
							RemainingDistance -= WidgetDimensions.ScrollAxis * Alignment;
							bFirst = false;
						}
						else
						{
							RemainingDistance -= WidgetDimensions.ScrollAxis;
						}
						if (ItemIndex == 0)
						{
							RemainingDistance -= UpperContentPadding.ScrollAxis;
						}
					}
					TSharedPtr<ITableRow> FirstRowWidget = RowWidget;
					FTableViewDimensions FirstRowWidgetDimensions(this->Orientation, FirstRowWidget->AsWidget()->GetDesiredSize());
					ModifyWidgetDimensions(FirstRowWidgetDimensions, ItemIndex);
					double NewScrollOffset = (float)ItemIndex - RemainingDistance / FirstRowWidgetDimensions.ScrollAxis;

					// NewScrollOffset = FMath::Max(NewScrollOffset, UpperContentPadding.ScrollAxis / FirstRowWidgetDimensions.ScrollAxis);
					// NewScrollOffset = FMath::Min(NewScrollOffset, (float)Items.Num() - LowerContentPadding.ScrollAxis / FirstRowWidgetDimensions.ScrollAxis);

					// const double MaxScrollOffset = FMath::Max(0.0, static_cast<double>(Items.Num()) - NumLiveWidgets);
					// NewScrollOffset = FMath::Clamp<double>(NewScrollOffset, 0.0, MaxScrollOffset);
					NewScrollOffset = FMath::Max<double>(NewScrollOffset, 0.0);
					this->SetScrollOffset((float)NewScrollOffset);
				} while (false);

				// End of override.
				this->RequestLayoutRefresh();
				this->ItemToNotifyWhenInView = LinearizedItem;
			}
			else
			{
				UE_LOG(LogKGUI, Warning, TEXT("The ScrollIntoView requesting item does not exist in the present item list!"));
			}
			TListTypeTraits<ItemType>::ResetPtr(this->ItemToScrollIntoView);
		}
		if (TListTypeTraits<ItemType>::IsPtrValid(this->ItemToNotifyWhenInView))
		{
			if (this->bEnableAnimatedScrolling)
			{
				const bool bHasWidgetForItem = this->WidgetFromItem(TListTypeTraits<ItemType>::NullableItemTypeConvertToItemType(this->ItemToNotifyWhenInView)).IsValid();
				return bHasWidgetForItem ? EScrollIntoViewResult::Success : EScrollIntoViewResult::Deferred;
			}
		}
		else
		{
			return EScrollIntoViewResult::Failure;
		}
		return EScrollIntoViewResult::Success;
	}

	virtual int GetNumItemsPerLine() const override { return Super::GetNumItemsPerLine(); }

protected:
	float SpecificScrollIntoViewAlignment;
	bool bUseSpecificScrollIntoViewAlignment;

	#pragma endregion

	#pragma region 整理选中态逻辑，原生的选中控制有点凌乱

public:
	using NullableItemType = typename TListTypeTraits<ItemType>::NullableType;
	using TItemSet = TSet<ItemType, typename TListTypeTraits<ItemType>::SetKeyFuncs>;

	DECLARE_DELEGATE_TwoParams(FKGOnSelectionsChanged, const TItemSet&, ESelectInfo::Type)
	DECLARE_DELEGATE_TwoParams(FKGOnItemSelectionChanged, const NullableItemType&, bool);

protected:
	virtual void Private_SetItemSelection(ItemType TheItem, bool bShouldBeSelected, bool bWasUserDirected = false) override
	{
		switch (this->SelectionMode.Get())
		{
		case ESelectionMode::None:
			break;
		case ESelectionMode::Single:
		case ESelectionMode::SingleToggle:
			if (bShouldBeSelected == this->IsItemSelected(TheItem))
			{
				return;
			}
			Private_ClearSelection();
			Super::Private_SetItemSelection(TheItem, bShouldBeSelected, bWasUserDirected);
			OnItemSelectionChanged.ExecuteIfBound(TheItem, bShouldBeSelected);
			break;
		case ESelectionMode::Multi:
			if (bShouldBeSelected == this->IsItemSelected(TheItem))
			{
				return;
			}
			Super::Private_SetItemSelection(TheItem, bShouldBeSelected, bWasUserDirected);
			OnItemSelectionChanged.ExecuteIfBound(TheItem, bShouldBeSelected);
			break;
		}
	}

	virtual void Private_ClearSelection() override
	{
		auto TempSelectedItems = this->SelectedItems;
		Super::Private_ClearSelection();
		for (auto& SelectedItem : TempSelectedItems)
		{
			OnItemSelectionChanged.ExecuteIfBound(SelectedItem, false);
		}
	}

	virtual void Private_SelectRangeFromCurrentTo(ItemType InRangeSelectionEnd) override
	{
		auto LastSelectedItems = this->SelectedItems;
		Super::Private_SelectRangeFromCurrentTo(InRangeSelectionEnd);
		for (auto& Added : this->SelectedItems.Difference(LastSelectedItems))
		{
			OnItemSelectionChanged.ExecuteIfBound(Added, true);
		}
	}

	virtual void Private_SignalSelectionChanged(ESelectInfo::Type SelectInfo) override
	{
		Super::Private_SignalSelectionChanged(SelectInfo);
		if (this->SelectionMode.Get() == ESelectionMode::None)
		{
			return;
		}
		OnSelectionsChanged.ExecuteIfBound(this->SelectedItems, SelectInfo);
	}

private:
	virtual void Private_SetSelection(ItemType SoleSelectedItem, ESelectInfo::Type SelectInfo) override
	{
		Super::SetItemSelection(SoleSelectedItem, true, SelectInfo);
	}

public:
	void SetOnSelectionsChanged(FKGOnSelectionsChanged Callback)
	{
		OnSelectionsChanged = Callback;
	}

	void SetOnItemSelectionChanged(FKGOnItemSelectionChanged Callback)
	{
		OnItemSelectionChanged = Callback;
	}

protected:
	FKGOnSelectionsChanged OnSelectionsChanged;
	FKGOnItemSelectionChanged OnItemSelectionChanged;

	#pragma endregion

	#pragma region 滚动条显隐

public:
	void SetScrollBarVisibility(EKGScrollBarVisibility ScrollBarVisibility)
	{
		switch (ScrollBarVisibility)
		{
		case EKGScrollBarVisibility::Visible:
		case EKGScrollBarVisibility::Collapsed:
		case EKGScrollBarVisibility::Hidden:
		case EKGScrollBarVisibility::HitTestInvisible:
		case EKGScrollBarVisibility::SelfHitTestInvisible:
			this->ScrollBar->SetVisibility(UWidget::ConvertSerializedVisibilityToRuntime((ESlateVisibility)(uint8)ScrollBarVisibility));
			break;
		case EKGScrollBarVisibility::Auto:
			auto ScrollBar = StaticCastSharedRef<SScrollBar>(this->ScrollBar->AsShared());
			this->ScrollBar->SetVisibility(TAttribute<EVisibility>(ScrollBar, &SScrollBar::ShouldBeVisible));
			break;
		}
	}

	#pragma endregion

	#pragma region 滚动相关回调的补充

public:
	ItemType GetFrontEdgeIntersection(float& Position) const
	{
		auto LineIndex = GetFirstLineIndexOnScreen();
		Position = GetFirstItemPositionPerLine(LineIndex);
		return GetItemByIndex((int)(Position));
	}

	ItemType GetBackEdgeIntersection(float& Position) const
	{
		auto LineIndex = (float)(GetFirstLineIndexOnScreen() + this->LastGenerateResults.ExactNumLinesOnScreen);
		Position = GetFirstItemPositionPerLine(LineIndex);
		const auto Items = this->GetItems();
		if (Position >= Items.Num())
		{
			return GetItemByIndex(Items.Num() - 1);
		}
		return GetItemByIndex((int)(Position));
	}

	bool IsFrontEdgeReached(float EdgeReachLengthThreshold) const
	{
		auto LineIndex = GetFirstLineIndexOnScreen();
		if (LineIndex >= 1)
		{
			return false;
		}
		auto Widget = GetTableRowWidgetByIndex(0);
		if (Widget == nullptr)
		{
			return false;
		}
		FTableViewDimensions Size(this->Orientation, Widget->GetDesiredSize());
		ModifyWidgetDimensions(Size, 0);
		return Size.ScrollAxis < EdgeReachLengthThreshold || LineIndex * Size.ScrollAxis < EdgeReachLengthThreshold;
	}

	bool IsBackEdgeReached(float EdgeReachLengthThreshold) const
	{
		auto LineIndex = GetFirstLineIndexOnScreen() + this->LastGenerateResults.ExactNumLinesOnScreen;
		const int32 NumItemLines = this->GetNumItemsBeingObserved() / this->GetNumItemsPerLine();
		if (LineIndex < NumItemLines - 1)
		{
			return false;
		}
		auto Widget = GetTableRowWidgetByIndex(this->GetItems().Num() - 1);
		if (Widget == nullptr)
		{
			return false;
		}
		FTableViewDimensions Size(this->Orientation, Widget->GetDesiredSize());
		ModifyWidgetDimensions(Size, this->GetItems().Num() - 1);
		return Size.ScrollAxis < EdgeReachLengthThreshold || (NumItemLines - LineIndex) * Size.ScrollAxis < EdgeReachLengthThreshold;
	}

	float GetOverscroll() const
	{
		return this->Overscroll.GetOverscroll(this->GetTickSpaceGeometry());
	}

	void SetOnItemsRefreshed(const FKGOnItemsRefreshed& InOnItemsRefreshed)
	{
		OnItemsRefreshed = InOnItemsRefreshed;
	}

	float GetFirstLineIndexOnScreen() const
	{
		return this->CurrentScrollOffset / this->GetNumItemsPerLine();
	}

	float GetFirstItemPositionPerLine(float LineIndex) const
	{
		return (float)((int)(LineIndex) * this->GetNumItemsPerLine()) + (LineIndex - (int)LineIndex);
	}

	ItemType GetItemByIndex(int Index) const
	{
		const auto Items = this->GetItems();
		if (!Items.IsValidIndex(Index))
		{
			return nullptr;
		}
		return Items[Index];
	}

	TSharedPtr<SWidget> GetTableRowWidgetByIndex(int Index) const
	{
		auto Items = this->GetItems();
		if (!Items.IsValidIndex(Index))
		{
			return nullptr;
		}
		auto TableRow = this->WidgetFromItem(Items[Index]);
		if (TableRow == nullptr)
		{
			return nullptr;
		}
		return TableRow->AsWidget();
	}

private:
	virtual void NotifyOnItemsRefreshed() override
	{
		const TArrayView<const ItemType> Items = this->GetItems();
		int32 StartIndex = FMath::Clamp((int32)(FMath::FloorToDouble(this->CurrentScrollOffset)), 0, Items.Num() - 1);
		const int32 NumItemsPerLine = GetNumItemsPerLine();
		this->SetItemsPanelFirstLineIndex(StartIndex / NumItemsPerLine);
		this->SetItemsPanelNumLines(Items.Num() % NumItemsPerLine != 0 ? ((int)(Items.Num() / NumItemsPerLine) + 1) : (Items.Num() / NumItemsPerLine));
		this->UpdateScrollHints();
		if (OnItemsRefreshed.IsBound())
		{
			OnItemsRefreshed.Execute(GetTickingAllottedGeometry());
		}
	}

	FKGOnItemsRefreshed OnItemsRefreshed;

public:
	bool IsStartedTouchInteraction() const
	{
		return this->bStartedTouchInteraction;
	}

	void SetOnOverscrollAmountChanged(const FOverscroll::FKGOnOverscrollAmountChanged& InOnOverscrollAmountChanged)
	{
		this->Overscroll.SetOnOverscrollAmountChanged(InOnOverscrollAmountChanged);
	}

	#pragma endregion

	#pragma region 内容边距

protected:
	static FTableViewDimensions&& Multiple(FTableViewDimensions&& A, const FTableViewDimensions& B)
	{
		A.ScrollAxis *= B.ScrollAxis;
		A.LineAxis *= B.LineAxis;
		return MoveTemp(A);
	}

	virtual void ModifyWidgetDimensions(FTableViewDimensions& WidgetDimensions, int ItemIndex) const override
	{
		WidgetDimensions = WidgetDimensions
			+ Multiple(
				FTableViewDimensions(this->Orientation, this->ContentPadding.GetTopLeft()),
				FTableViewDimensions(EOrientation::Orient_Vertical, 1, ItemIndex == 0 ? 1 : 0)
			)
			+ Multiple(
				FTableViewDimensions(this->Orientation, FVector2f(this->ContentPadding.Right, this->ContentPadding.Bottom)),
				FTableViewDimensions(EOrientation::Orient_Vertical, 1, ItemIndex == this->GetItems().Num() - 1 ? 1 : 0)
			);
	}

	#pragma endregion

	#pragma region 强制刷新

public:
	void RefreshSynchronous()
	{
		this->Tick(this->GetPersistentState().DesktopGeometry, FSlateApplication::Get().GetCurrentTime(), 0);
	}

	TSharedPtr<ITableRow> GetOrCreateWidgetForItem(int ItemIndex)
	{
		const TArrayView<const ItemType> Items = this->GetItems();
		if (!Items.IsValidIndex(ItemIndex))
		{
			return nullptr;
		}
		const ItemType& CurItem = Items[ItemIndex];
		const float LayoutScaleMultiplier = this->PanelGeometryLastTick.GetAccumulatedLayoutTransform().GetScale();
		return GetOrCreateWidgetForItemInternal(CurItem, ItemIndex, LayoutScaleMultiplier);
	}

protected:
	TSharedPtr<ITableRow> GetOrCreateWidgetForItemInternal(const ItemType& CurItem, int ItemIndex, float LayoutScaleMultiplier)
	{
		auto RowWidget = this->WidgetGenerator.GetWidgetForItem(CurItem);
		if (!RowWidget.IsValid())
		{
			RowWidget = this->GenerateNewWidget(CurItem);
			RowWidget->SetIndexInList(ItemIndex);
			this->WidgetGenerator.OnItemSeen(CurItem, RowWidget.ToSharedRef());
			RowWidget->AsWidget()->MarkPrepassAsDirty();
			RowWidget->AsWidget()->SlatePrepass(LayoutScaleMultiplier);
		}
		return RowWidget;
	}

	#pragma endregion

	#pragma region 修复拖拽可能被SViewport逻辑Capture住的问题

	virtual FReply OnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override
	{
		BeginClicking();
		auto Reply = Super::OnTouchStarted(MyGeometry, InTouchEvent);
		if (auto Settings = GetDefault<UKGUISettings>())
		{
			if (Settings->bHandleTouchStartEventInScrollableListView)
			{
				if (!Reply.IsEventHandled() && Super::bIsPointerScrollingEnabled && Super::bEnableTouchScrolling && Super::bStartedTouchInteraction)
				{
					// 如果可以被拖拽滚动，那就Handled掉这个PointerEvent；不然被SViewport的逻辑Capture住，列表就没法拖拽滚动了。
					if (Super::AllowOverscroll == EAllowOverscroll::Yes)
					{
						return FReply::Handled();
					}
					if (Super::ScrollBar->ThumbSizeFraction() < (1.0f - KINDA_SMALL_NUMBER))
					{
						return FReply::Handled();
					}
				}
			}
		}
		return Reply;
	}

	#pragma endregion

	virtual bool SupportsKeyboardFocus() const override
	{
#if WITH_EDITOR
		const bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#else
		const static bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#endif
		if (bDisableFocusableGlobally)
		{
			return false;
		}

		return Super::SupportsKeyboardFocus();
	}

public:
	template <typename FCallback>
	void ForEachGeneratedItems(FCallback Callback)
	{
		for (auto Pair : this->WidgetGenerator.ItemToWidgetMap)
		{
			Callback(Pair.Key, Pair.Value);
		}
	}

	#pragma region 额外拓展节点

public:
	DECLARE_DELEGATE_RetVal_OneParam(TSharedPtr<SWidget>, FOnGenerateScrollHint, EKGListViewScrollHintType);

	void ConstructExtra(TSharedPtr<SWidget> InBackgroundWidget, FOnGenerateScrollHint&& InOnGenerateScrollHint, float InScrollHintScrollAxisOffset, float InScrollHintLineAxisOffset)
	{
		OnGenerateScrollHint = InOnGenerateScrollHint;
		ScrollHintScrollAxisOffset = InScrollHintScrollAxisOffset;
		ScrollHintLineAxisPercentOffset = InScrollHintLineAxisOffset;
		auto TempListViewContent = this->ChildSlot.GetWidget();
		WeakListViewContent = TempListViewContent;
		if (!InBackgroundWidget.IsValid() && !OnGenerateScrollHint.IsBound())
		{
			return;
		}
		auto Overlay = SNew(SOverlay);
		this->ChildSlot
		[
			Overlay
		];
		WeakOverlay = Overlay;
		if (InBackgroundWidget.IsValid())
		{
			Overlay->AddSlot()[InBackgroundWidget.ToSharedRef()];
		}
		Overlay->AddSlot()[TempListViewContent];
	}

protected:
	TWeakPtr<SWidget> WeakListViewContent;
	TWeakPtr<SOverlay> WeakOverlay;
	float ScrollHintScrollAxisOffset = 0;
	float ScrollHintLineAxisPercentOffset = 0.5;

	#pragma endregion

	#pragma region 修复列表拖拽意外关闭FakingTouch的问题

	virtual void OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		auto bOldStartedTouchInteraction = this->bStartedTouchInteraction;
		Super::OnMouseEnter(MyGeometry, MouseEvent);
		if (this->bStartedTouchInteraction != bOldStartedTouchInteraction && this->bStartedTouchInteraction)
		{
			this->PressedScreenSpacePosition = MouseEvent.GetScreenSpacePosition();
		}
	}

	#pragma endregion

	#pragma region 空白区域点击事件

public:
	DECLARE_DELEGATE_RetVal(bool, FOnListViewClicked)

	void SetOnClicked(const FOnListViewClicked& InOnClicked)
	{
		this->OnClicked = InOnClicked;
	}

	bool IsClicking() const
	{
		return bIsClicking;
	}

protected:
	void BeginClicking()
	{
		bIsClicking = true;
	}

	bool EndClicking(const FPointerEvent& MouseEvent)
	{
		if (bIsClicking)
		{
			if (!FSlateApplication::Get().HasTraveledFarEnoughToTriggerDrag(MouseEvent, this->PressedScreenSpacePosition, this->Orientation))
			{
				if (OnClicked.IsBound())
				{
					return OnClicked.Execute();
				}
			}
			bIsClicking = false;
		}
		return false;
	}

	void CancelClicking()
	{
		bIsClicking = false;
	}

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		BeginClicking();
		return Super::OnMouseButtonDown(MyGeometry, MouseEvent);
	}

	virtual FReply OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override
	{
		auto Reply = Super::OnTouchEnded(MyGeometry, InTouchEvent);
		if (EndClicking(InTouchEvent))
		{
			if (!Reply.IsEventHandled())
			{
				return FReply::Handled();
			}
		}
		return Reply;
	}

	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		auto Reply = Super::OnMouseButtonUp(MyGeometry, MouseEvent);
		if (EndClicking(MouseEvent))
		{
			if (!Reply.IsEventHandled())
			{
				return FReply::Handled();
			}
		}
		return Reply;
	}

	virtual void OnMouseLeave(const FPointerEvent& MouseEvent) override
	{
		CancelClicking();
		Super::OnMouseLeave(MouseEvent);
	}

	virtual float ScrollBy(const FGeometry& MyGeometry, float ScrollByAmountInSlateUnits, EAllowOverscroll InAllowOverscroll) override
	{
		CancelClicking();
		return Super::ScrollBy(MyGeometry, ScrollByAmountInSlateUnits, InAllowOverscroll);
	}

	virtual float ScrollTo(float InScrollOffset) override
	{
		CancelClicking();
		return Super::ScrollTo(InScrollOffset);
	}

	bool bIsClicking = false;
	FOnListViewClicked OnClicked;

	#pragma endregion

	#pragma region 可滚动箭头

protected:
	void SetScrollHintVisibilityInternal(TSharedPtr<SWidget>& ScrollHint, EVisibility InScrollHintVisibility, EKGListViewScrollHintType ScrollHintType)
	{
		auto Overlay = WeakOverlay.Pin();
		if (!ensure(Overlay && OnGenerateScrollHint.IsBound()))
		{
			return;
		}
		bool* bGeneratedPtr = nullptr;
		switch (ScrollHintType)
		{
		case EKGListViewScrollHintType::Before:
			bGeneratedPtr = &bIsScrollHintBeforeGenerated;
			break;
		case EKGListViewScrollHintType::After:
			bGeneratedPtr = &bIsScrollHintAfterGenerated;
			break;
		}
		if (!bGeneratedPtr)
		{
			return;
		}
		auto& bGenerated = *bGeneratedPtr;
		if (!bGenerated && InScrollHintVisibility == EVisibility::Collapsed)
		{
			return;
		}
		if (!bGenerated)
		{
			bGenerated = true;
			if (auto NewScrollHint = OnGenerateScrollHint.Execute(ScrollHintType))
			{
				SKGRotateBox::EType RotateType = SKGRotateBox::EType::NoRotate;
				
				if (this->Private_GetOrientation() == Orient_Horizontal)
				{
					switch (ScrollHintType)
					{
					case EKGListViewScrollHintType::Before:
						RotateType = SKGRotateBox::EType::Rotate270;
						break;
					case EKGListViewScrollHintType::After:
						RotateType = SKGRotateBox::EType::Rotate90;
						break;
					}
				}
				else
				{
					switch (ScrollHintType)
					{
					case EKGListViewScrollHintType::Before:
						RotateType = SKGRotateBox::EType::NoRotate;
						break;
					case EKGListViewScrollHintType::After:
						RotateType = SKGRotateBox::EType::Rotate180;
						break;
					}
				}
				Overlay->AddSlot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				[
					SNew(SKGRotateBox)
					.Type(RotateType)
					.ScrollHintLineAxisPercentOffset(ScrollHintLineAxisPercentOffset)
					.ScrollHintScrollAxisOffset(ScrollHintScrollAxisOffset)
					[
						NewScrollHint.ToSharedRef()
					]
				];
				ScrollHint = NewScrollHint;
			}
		}
		if (ScrollHint.IsValid())
		{
			ScrollHint->SetVisibility(InScrollHintVisibility);
		}
	}

	void SetScrollHintForwardVisibility(EVisibility InScrollHintVisibility)
	{
		SetScrollHintVisibilityInternal(ScrollHintBefore, InScrollHintVisibility, EKGListViewScrollHintType::Before);
	}

	void SetScrollHintBackwardVisibility(EVisibility InScrollHintVisibility)
	{
		SetScrollHintVisibilityInternal(ScrollHintAfter, InScrollHintVisibility, EKGListViewScrollHintType::After);
	}
	
	void UpdateScrollHints()
	{
		if (!OnGenerateScrollHint.IsBound())
		{
			return;
		}
		SetScrollHintForwardVisibility(FMath::IsNearlyEqual(this->GetScrollDistance().Y, 0, 0.0001) ? EVisibility::Hidden : EVisibility::SelfHitTestInvisible);
		SetScrollHintBackwardVisibility(FMath::IsNearlyEqual(this->GetScrollDistanceRemaining().Y, 0, 0.0001) || this->GetScrollDistanceRemaining().Y < 0 ? EVisibility::Hidden : EVisibility::SelfHitTestInvisible);
	}

	FOnGenerateScrollHint OnGenerateScrollHint;
	bool bIsScrollHintBeforeGenerated = false;
	bool bIsScrollHintAfterGenerated = false;
	TSharedPtr<SWidget> ScrollHintBefore;
	TSharedPtr<SWidget> ScrollHintAfter;

	#pragma endregion

	#pragma region 定制一个OnPreviewMouseButtonUp事件，应对OnPreviewMouseButtonDown的解注册处理

public:
	virtual ~SKGListView() override
	{
		Unregister();
	}

protected:
	class FKGTableViewPreviewMouseButtonUpInputProcessor : public IInputProcessor
	{
	public:
		FKGTableViewPreviewMouseButtonUpInputProcessor(TSharedRef<SKGListView<ItemType>> InListView)
			: ListView(InListView)
		{
		}

		virtual void Tick(const float DeltaTime, FSlateApplication& SlateApp, TSharedRef<ICursor> Cursor) override {}

		virtual bool HandleMouseButtonUpEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent) override
		{
			if (ListView.IsValid())
			{
				ListView.Pin()->OnPreviewMouseButtonUp(MouseEvent);
			}
			return false;
		}

	private:
		TWeakPtr<SKGListView<ItemType>> ListView;
	};

	void Register()
	{
		if (!PreviewMouseButtonUpInputProcessor.IsValid() && FSlateApplication::IsInitialized())
		{
			PreviewMouseButtonUpInputProcessor = MakeShared<FKGTableViewPreviewMouseButtonUpInputProcessor>(StaticCastSharedRef<SKGListView<ItemType>>(this->AsShared()));

			// IMPORTANT: 因为这里不会打断输入，所以优先级设置成0不会影响其他逻辑，而且还不会收到其他逻辑的影响…
			FSlateApplication::Get().RegisterInputPreProcessor(PreviewMouseButtonUpInputProcessor, 0);
		}
	}

	void Unregister()
	{
		if (PreviewMouseButtonUpInputProcessor.IsValid() && FSlateApplication::IsInitialized())
		{
			FSlateApplication::Get().UnregisterInputPreProcessor(PreviewMouseButtonUpInputProcessor);
			PreviewMouseButtonUpInputProcessor.Reset();
		}
	}

	virtual FReply OnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		Register();
		return Super::OnPreviewMouseButtonDown(MyGeometry, MouseEvent);
	}

	virtual void OnPreviewMouseButtonUp(const FPointerEvent& MouseEvent)
	{
		Unregister();
		this->bStartedTouchInteraction = false;
	}

private:
	TSharedPtr<IInputProcessor> PreviewMouseButtonUpInputProcessor;

	#pragma endregion
};