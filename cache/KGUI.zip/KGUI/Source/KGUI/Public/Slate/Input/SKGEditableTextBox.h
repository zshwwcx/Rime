#pragma once

#include "Widgets/Input/SEditableTextBox.h"

class SKGEditableTextBox : public SEditableTextBox
{
	using Super = SEditableTextBox;

public:
	// ReSharper disable once CppMemberFunctionMayBeConst
	void SetHintTextStyleAttribute(const TAttribute<FTextBlockStyle>& InHintTextStyleAttribute)
	{
		EditableText->SetHintTextStyleAttribute(InHintTextStyleAttribute);
	}

protected:
	// SWidget overrides
	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	virtual FReply OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
};