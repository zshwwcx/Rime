// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Misc/Attribute.h"
#include "Input/Reply.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Styling/SlateColor.h"
#include "Layout/Margin.h"
#include "Framework/SlateDelegates.h"
#include "Styling/SlateWidgetStyleAsset.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/SLeafWidget.h"

class FPaintArgs;
class FSlateWindowElementList;

/**
 * Slate's Buttons are clickable Widgets that can contain arbitrary widgets as its Content().
 */
class SKGHotArea : public SLeafWidget
{
	DECLARE_DELEGATE_OneParam(FOnFocusLost, const FFocusEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnKeyUp, const FGeometry&, const FKeyEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnMouseButtonDown, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnMouseButtonDoubleClick, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnMouseButtonUp, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnMouseMove, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_TwoParams(FOnMouseEnter, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_OneParam(FOnMouseLeave, const FPointerEvent&);
	DECLARE_DELEGATE_OneParam(FOnMouseCaptureLost, const FCaptureLostEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnFocusReceived, const FGeometry&, const FFocusEvent&);
	DECLARE_DELEGATE_ThreeParams(FOnFocusChanging, const FWeakWidgetPath&, const FWidgetPath&, const FFocusEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnPreviewKeyDown, const FGeometry&, const FKeyEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnPreviewMouseButtonDown, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnMouseWheel, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnTouchGesture, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnTouchStarted, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnTouchMoved, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnTouchEnded, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnTouchForceChanged, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FReply, FOnTouchFirstMove, const FGeometry&, const FPointerEvent&);
	DECLARE_DELEGATE_RetVal_TwoParams(FNavigationReply, FOnNavigationEvent, const FGeometry&, const FNavigationEvent&);

	SLATE_DECLARE_WIDGET_API(SKGHotArea, SLeafWidget, KGUI_API)
public:

	SLATE_BEGIN_ARGS(SKGHotArea)
		: _Content()
		, _HAlign(HAlign_Fill)
		, _VAlign(VAlign_Fill)
		, _ContentPadding(FMargin(4.0, 2.0))
		, _ClickMethod(EButtonClickMethod::DownAndUp)
		, _TouchMethod(EButtonTouchMethod::DownAndUp)
		, _PressMethod(EButtonPressMethod::DownAndUp)
		, _IsFocusable(true)
		{
		}
		SLATE_DEFAULT_SLOT(FArguments, Content)
		SLATE_ARGUMENT(EHorizontalAlignment, HAlign)
		SLATE_ARGUMENT(EVerticalAlignment, VAlign)
		SLATE_ATTRIBUTE(FMargin, ContentPadding)

		SLATE_EVENT(FOnClicked, OnClicked)
		SLATE_EVENT(FOnClicked, OnRightClicked)
		SLATE_EVENT(FSimpleDelegate, OnPressed)
		SLATE_EVENT(FSimpleDelegate, OnReleased)
		SLATE_EVENT(FSimpleDelegate, OnHovered)
		SLATE_EVENT(FSimpleDelegate, OnUnhovered)
		SLATE_EVENT(FOnFocusLost, OnFocusLostEvent)
		SLATE_EVENT(FOnKeyDown, OnKeyDownEvent)
		SLATE_EVENT(FOnKeyUp, OnKeyUpEvent)
		SLATE_EVENT(FOnMouseButtonDown, OnMouseButtonDownEvent)
		SLATE_EVENT(FOnMouseButtonDoubleClick, OnMouseButtonDoubleClickEvent)
		SLATE_EVENT(FOnMouseButtonUp, OnMouseButtonUpEvent)
		SLATE_EVENT(FOnMouseMove, OnMouseMoveEvent)
		SLATE_EVENT(FOnMouseEnter, OnMouseEnterEvent)
		SLATE_EVENT(FOnMouseLeave, OnMouseLeaveEvent)
		SLATE_EVENT(FOnMouseCaptureLost, OnMouseCaptureLostEvent)
		SLATE_EVENT(FOnFocusReceived, OnFocusReceivedEvent)
		SLATE_EVENT(FOnFocusChanging, OnFocusChangingEvent)
		SLATE_EVENT(FOnKeyChar, OnKeyCharEvent)
		SLATE_EVENT(FOnPreviewKeyDown, OnPreviewKeyDownEvent)
		SLATE_EVENT(FOnPreviewMouseButtonDown, OnPreviewMouseButtonDownEvent)
		SLATE_EVENT(FOnMouseWheel, OnMouseWheelEvent)
		SLATE_EVENT(FOnDragDetected, OnDragDetectedEvent)
		SLATE_EVENT(FOnDragEnter, OnDragEnterEvent)
		SLATE_EVENT(FOnDragLeave, OnDragLeaveEvent)
		SLATE_EVENT(FOnDragOver, OnDragOverEvent)
		SLATE_EVENT(FOnDrop, OnDropEvent)
		SLATE_EVENT(FOnTouchGesture, OnTouchGestureEvent)
		SLATE_EVENT(FOnTouchStarted, OnTouchStartedEvent)
		SLATE_EVENT(FOnTouchMoved, OnTouchMovedEvent)
		SLATE_EVENT(FOnTouchEnded, OnTouchEndedEvent)
		SLATE_EVENT(FOnTouchForceChanged, OnTouchForceChangedEvent)
		SLATE_EVENT(FOnTouchFirstMove, OnTouchFirstMoveEvent)

		/** Sets the rules to use for determining whether the button was clicked.  This is an advanced setting and generally should be left as the default. */
		SLATE_ARGUMENT(EButtonClickMethod::Type, ClickMethod)

		/** How should the button be clicked with touch events? */
		SLATE_ARGUMENT(EButtonTouchMethod::Type, TouchMethod)

		/** How should the button be clicked with keyboard/controller button events? */
		SLATE_ARGUMENT(EButtonPressMethod::Type, PressMethod)

		/** Sometimes a button should only be mouse-clickable and never keyboard focusable. */
		SLATE_ARGUMENT(bool, IsFocusable)
		SLATE_ARGUMENT(bool, IsPenetration)
		
	SLATE_END_ARGS()

public:
	bool IsPressed() const
	{
		return bIsPressed;
	}

	KGUI_API void Construct(const FArguments& InArgs);
	KGUI_API FVector2D GetPressedScreenSpacePosition();
	KGUI_API void SetClickMethod(EButtonClickMethod::Type InClickMethod);
	KGUI_API void SetTouchMethod(EButtonTouchMethod::Type InTouchMethod);
	KGUI_API void SetPressMethod(EButtonPressMethod::Type InPressMethod);

public:
	KGUI_API virtual bool SupportsKeyboardFocus() const override;
	KGUI_API virtual void OnFocusLost(const FFocusEvent& InFocusEvent) override;
	KGUI_API virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	KGUI_API virtual FReply OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	KGUI_API virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	KGUI_API virtual FReply OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent) override;
	KGUI_API virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	KGUI_API virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	KGUI_API virtual void OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	void ExecuteHoverStateChanged();
	KGUI_API virtual void OnMouseLeave(const FPointerEvent& MouseEvent) override;
	KGUI_API virtual void OnMouseCaptureLost(const FCaptureLostEvent& CaptureLostEvent) override;
	KGUI_API virtual FReply OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent) override;
	KGUI_API virtual void OnFocusChanging(const FWeakWidgetPath& PreviousFocusPath, const FWidgetPath& NewWidgetPath, const FFocusEvent& InFocusEvent) override;
	KGUI_API virtual FReply OnKeyChar(const FGeometry& MyGeometry, const FCharacterEvent& InCharacterEvent) override;
	KGUI_API virtual FReply OnPreviewKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	KGUI_API virtual FReply OnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	KGUI_API virtual FReply OnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	KGUI_API virtual FReply OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	KGUI_API virtual void OnDragEnter(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;
	KGUI_API virtual void OnDragLeave(const FDragDropEvent& DragDropEvent) override;
	KGUI_API virtual FReply OnDragOver(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;
	KGUI_API virtual FReply OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;
	KGUI_API virtual FReply OnTouchGesture(const FGeometry& MyGeometry, const FPointerEvent& GestureEvent) override;
	KGUI_API virtual FReply OnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override;
	KGUI_API virtual FReply OnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override;
	KGUI_API virtual FReply OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override;
	KGUI_API virtual FReply OnTouchForceChanged(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent) override;
	KGUI_API virtual FReply OnTouchFirstMove(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent) override;
	KGUI_API virtual FNavigationReply OnNavigation(const FGeometry& MyGeometry, const FNavigationEvent& InNavigationEvent) override;
	KGUI_API virtual bool IsInteractable() const override;
	virtual FVector2D ComputeDesiredSize(float) const override;
	void SetIsDrag(bool IsDrag)
	{
		bIsDrag = IsDrag;
	}
protected:

	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	/** Press the button */
	KGUI_API virtual void Press();

	/** Release the button */
	KGUI_API virtual void Release();

	/** Execute the "OnClicked" delegate, and get the reply */
	KGUI_API FReply ExecuteOnClick(FKey ButtonEffectType);

	/** Utility function to translate other input click methods to regular ones. */
	KGUI_API TEnumAsByte<EButtonClickMethod::Type> GetClickMethodFromInputType(const FPointerEvent& MouseEvent) const;

	/** Utility function to determine if the incoming mouse event is for a precise tap or click */
	KGUI_API bool IsPreciseTapOrClick(const FPointerEvent& MouseEvent) const;


	/** Set if this button can be focused */
	void SetIsFocusable(bool bInIsFocusable)
	{
		bIsFocusable = bInIsFocusable;
	}

private:
	FVector2D PressedScreenSpacePosition;
	FOnClicked OnClicked;
	FOnClicked OnRightClicked;
	FSimpleDelegate OnPressed;
	FSimpleDelegate OnReleased;
	FSimpleDelegate OnHovered;
	FSimpleDelegate OnUnhovered;
	FOnFocusLost OnFocusLostEvent;
	FOnKeyDown OnKeyDownEvent;
	FOnKeyUp OnKeyUpEvent;
	FOnMouseButtonDown OnMouseButtonDownEvent;
	FOnMouseButtonDoubleClick OnMouseButtonDoubleClickEvent;
	FOnMouseButtonUp OnMouseButtonUpEvent;
	FOnMouseMove OnMouseMoveEvent;
	FOnMouseEnter OnMouseEnterEvent;
	FOnMouseLeave OnMouseLeaveEvent;
	FOnMouseCaptureLost OnMouseCaptureLostEvent;
	FOnFocusReceived OnFocusReceivedEvent;
	FOnFocusChanging OnFocusChangingEvent;
	FOnKeyChar OnKeyCharEvent;
	FOnPreviewKeyDown OnPreviewKeyDownEvent;
	FOnPreviewMouseButtonDown OnPreviewMouseButtonDownEvent;
	FOnMouseWheel OnMouseWheelEvent;
	FOnDragDetected OnDragDetectedEvent;
	FOnDragEnter OnDragEnterEvent;
	FOnDragLeave OnDragLeaveEvent;
	FOnDragOver OnDragOverEvent;
	FOnDrop OnDropEvent;
	FOnTouchGesture OnTouchGestureEvent;
	FOnTouchStarted OnTouchStartedEvent;
	FOnTouchMoved OnTouchMovedEvent;
	FOnTouchEnded OnTouchEndedEvent;
	FOnTouchForceChanged OnTouchForceChangedEvent;
	FOnTouchFirstMove OnTouchFirstMoveEvent;
	FOnNavigationEvent OnNavigationEvent;
	TEnumAsByte<EButtonClickMethod::Type> ClickMethod;
	TEnumAsByte<EButtonTouchMethod::Type> TouchMethod;
	TEnumAsByte<EButtonPressMethod::Type> PressMethod;

	uint8 bIsFocusable : 1;
	uint8 bIsPressed : 1;
	uint8 bIsDrag : 1;
};
