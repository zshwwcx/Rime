#pragma once

#include "Widgets/Text/SlateEditableTextLayout.h"
#include "Widgets/Text/SMultiLineEditableText.h"

class SKGMultiLineEditableText : public SMultiLineEditableText
{
	using Super = SMultiLineEditableText;

public:
	DECLARE_DELEGATE_OneParam(FOnFocusReceived, const FFocusEvent&);
	DECLARE_DELEGATE_OneParam(FOnFocusLost, const FFocusEvent&);

	void SetOnFocusReceived(const FOnFocusReceived& InOnFocusReceived) { OnFocusReceivedDelegate = InOnFocusReceived; }
	void SetOnFocusLost(const FOnFocusLost& InOnFocusLost) { OnFocusLostDelegate = InOnFocusLost; }

	// ReSharper disable once CppMemberFunctionMayBeConst
	void SetHintTextStyleAttribute(const TAttribute<FTextBlockStyle>& InHintTextStyleAttribute)
	{
		EditableTextLayout->SetHintTextStyleAttribute(InHintTextStyleAttribute);
	}

protected:
	// SWidget overrides
	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	virtual FReply OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	virtual FReply OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent) override;
	virtual void OnFocusLost(const FFocusEvent& InFocusEvent) override;

protected:
	FOnFocusReceived OnFocusReceivedDelegate;
	FOnFocusLost OnFocusLostDelegate;

	#pragma region 回车换行

public:
	virtual bool CanInsertCarriageReturn() const override;
	void SetCanInsertCarriageReturn(bool InbCanInsertCarriageReturn);

private:
	bool bCanInsertCarriageReturn = true;

	#pragma endregion

	#pragma region 字符限制

public:
	DECLARE_DELEGATE_RetVal_OneParam(bool, FOnIsCharAllowed, const TCHAR);

	void SetOnIsCharAllowed(const FOnIsCharAllowed& InOnIsCharAllowed);

protected:
	virtual bool IsCharAllowed(const TCHAR InChar) const override;

private:
	FOnIsCharAllowed OnIsCharAllowed;

	#pragma endregion
};