#pragma once

#include "Widgets/Text/SRichTextBlock.h"

class SKGRichTextBlock : public SRichTextBlock
{
	SLATE_DECLARE_WIDGET(SKGRichTextBlock, SRichTextBlock)

public:
	//begin add by chengfeng : disable tick by default
	SKGRichTextBlock() 
	{
		SetCanTick(false);
	}
	//end add by chengfeng

	DECLARE_DELEGATE(FOnRebuildDecoratorStyleSet);

	void MarkDecoratorStyleSetAsDirty() { bDecoratorStyleSetDirty = true; }
	void SetOnRebuildDecoratorStyleSet(const FOnRebuildDecoratorStyleSet& InOnRebuildDecoratorStyleSet) { OnRebuildDecoratorStyleSet = InOnRebuildDecoratorStyleSet; }

protected:
	virtual FVector2D ComputeDesiredSize(float LayoutScaleMultiplier) const override;

	FOnRebuildDecoratorStyleSet OnRebuildDecoratorStyleSet;
	mutable bool bDecoratorStyleSetDirty = false;
};