#pragma once

#include "Widgets/Text/STextBlock.h"

class SKGTextBlock : public STextBlock
{
	SLATE_DECLARE_WIDGET(SKGTextBlock, STextBlock)
};