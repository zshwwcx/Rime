// Copyright Epic Games, Inc. All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "SlateGlobals.h"
#include "Widgets/SWidget.h"
#include "Styling/SlateTypes.h"
#include "Framework/Text/IRun.h"
#include "Framework/Text/TextLayout.h"
#include "Widgets/IToolTip.h"
#include "Framework/Text/ILayoutBlock.h"
#include "Framework/Text/ISlateRun.h"
#include "Widgets/Layout/SScaleBox.h"

class FArrangedChildren;
class FPaintArgs;
class FSlateWindowElementList;


#if WITH_FANCY_TEXT

class FSlateInlineTextImageRun : public ISlateRun, public TSharedFromThis< FSlateInlineTextImageRun >
{
public:

	typedef TMap< FString, FString > FMetadata;
	
public:

	static  TSharedRef< FSlateInlineTextImageRun > Create( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FTextBlockStyle& InStyle, const FSlateBrush* Brush, const EVerticalAlignment ImageVerticalAlignment);
																																	 
	static  TSharedRef< FSlateInlineTextImageRun > Create( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FTextBlockStyle& InStyle, const FTextRange& InRange, const FSlateBrush* Brush, const EVerticalAlignment ImageVerticalAlignment);

public:

	virtual ~FSlateInlineTextImageRun() {}

	 virtual FTextRange GetTextRange() const override;

	 virtual void SetTextRange( const FTextRange& Value ) override;

	 virtual int16 GetBaseLine( float Scale ) const override;

	 virtual int16 GetMaxHeight( float Scale ) const override;

	 virtual FVector2D Measure( int32 StartIndex, int32 EndIndex, float Scale, const FRunTextContext& TextContext ) const override;

	 virtual int8 GetKerning(int32 CurrentIndex, float Scale, const FRunTextContext& TextContext) const override;

	 virtual TSharedRef< ILayoutBlock > CreateBlock( int32 StartIndex, int32 EndIndex, FVector2D Size, const FLayoutBlockTextContext& TextContext, const TSharedPtr< IRunRenderer >& Renderer ) override;

	 virtual int32 OnPaint(const FPaintArgs& PaintArgs, const FTextArgs& TextArgs, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	 virtual const TArray< TSharedRef<SWidget> >& GetChildren() override;

	virtual void ArrangeChildren( const TSharedRef< ILayoutBlock >& Block, const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren ) const override;

	 virtual int32 GetTextIndexAt( const TSharedRef< ILayoutBlock >& Block, const FVector2D& Location, float Scale, ETextHitPoint* const OutHitPoint = nullptr ) const override;

	 virtual FVector2D GetLocationAt( const TSharedRef< ILayoutBlock >& Block, int32 Offset, float Scale ) const override;

	virtual void BeginLayout() override { Children.Empty(); }
	virtual void EndLayout() override {}

	 virtual void Move(const TSharedRef<FString>& NewText, const FTextRange& NewRange) override;
	 virtual TSharedRef<IRun> Clone() const override;

	 virtual void AppendTextTo(FString& AppendToText) const override;
	 virtual void AppendTextTo(FString& AppendToText, const FTextRange& PartialRange) const override;

	 virtual const FRunInfo& GetRunInfo() const override;

	 virtual ERunAttributes GetRunAttributes() const override;

protected:

	 FSlateInlineTextImageRun( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FTextBlockStyle& InStyle, const FSlateBrush* Brush, const EVerticalAlignment ImageVerticalAlignment);
																										 
	 FSlateInlineTextImageRun( const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FTextBlockStyle& InStyle, const FTextRange& InRange, const FSlateBrush* Brush, const EVerticalAlignment ImageVerticalAlignment);

	 FSlateInlineTextImageRun( const FSlateInlineTextImageRun& Run );

protected:

	FRunInfo RunInfo;
	TSharedRef< const FString > Text;
	FTextRange Range;
	FTextBlockStyle Style;
	const FSlateBrush* Brush;
	TArray< TSharedRef<SWidget> > Children;
	EVerticalAlignment ImageVerticalAlignment;
};

#endif //WITH_FANCY_TEXT
