// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Styling/SlateTypes.h"
#include "Widgets/Text/STextBlock.h"
#include "UObject/UObjectGlobals.h"
#include "Fonts/FontMeasure.h"
#include "Math/UnrealMathUtility.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Layout/SScaleBox.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Framework/Application/SlateApplication.h"
/**
 * 
 */
class SKGRichInlineTextImage : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SKGRichInlineTextImage)
		: _Text()
		, _Style(&FCoreStyle::Get().GetWidgetStyle< FTextBlockStyle >("NormalText"))
		, _TextStyle(nullptr)
		, _UnderlineStyle(nullptr)
		, _Padding()
		, _TextShapingMethod()
		, _TextFlowDirection()
		, _HighlightColor()
		, _HighlightShape()
		, _HighlightText()
		{}

		SLATE_ATTRIBUTE(FText, Text)
		SLATE_STYLE_ARGUMENT(FTextBlockStyle, Style)
		SLATE_STYLE_ARGUMENT(FTextBlockStyle, TextStyle)
		SLATE_STYLE_ARGUMENT(FButtonStyle, UnderlineStyle)
		SLATE_ATTRIBUTE(FMargin, Padding)
		SLATE_ARGUMENT(TOptional<ETextShapingMethod>, TextShapingMethod)
		SLATE_ARGUMENT(TOptional<ETextFlowDirection>, TextFlowDirection)
		SLATE_ATTRIBUTE(FLinearColor, HighlightColor)
		SLATE_ATTRIBUTE(const FSlateBrush*, HighlightShape)
		SLATE_ATTRIBUTE(FText, HighlightText)
	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, const FSlateBrush* Brush, EVerticalAlignment ImageVerticalAlignment)
	{
		if (ensure(Brush))
		{
			const FTextBlockStyle* TextStyle = InArgs._TextStyle != nullptr ? InArgs._TextStyle : InArgs._Style;
			const FTextBlockStyle& MeasureTextStyle = *TextStyle;
			const TSharedRef<FSlateFontMeasure> FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
			
			ChildSlot
				[
					SNew(SOverlay)
						+ SOverlay::Slot()
						[
							SAssignNew(MyImageTextBlock, STextBlock)
								.TextStyle(TextStyle)
								.Text(InArgs._Text)
								.HighlightColor(InArgs._HighlightColor)
								.HighlightShape(InArgs._HighlightShape)
								.HighlightText(InArgs._HighlightText)
						]
						+ SOverlay::Slot()
						.VAlign(ImageVerticalAlignment)
						.HAlign(HAlign_Fill)
						[
							
							SNew(SImage)
							.Image(Brush)
								
						]

				];
		}
	}
	TSharedPtr<STextBlock> GetImageTextBlock() {
		return MyImageTextBlock;
	}
protected:
	TSharedPtr<STextBlock> MyImageTextBlock;
};