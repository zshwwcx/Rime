#pragma once

#include "Widgets/SCompoundWidget.h"

class SKGRotateBox : public SCompoundWidget
{
public:
	using Super = SCompoundWidget;

	enum class EType
	{
		NoRotate,
		Rotate90,
		Rotate180,
		Rotate270,
	};

	SLATE_BEGIN_ARGS(SKGRotateBox)
		: _Content()
		, _Type(EType::NoRotate)
		, _ScrollHintScrollAxisOffset(0)
		, _ScrollHintLineAxisPercentOffset(0.5)
		{}
		SLATE_DEFAULT_SLOT(FArguments, Content)
		SLATE_ARGUMENT(EType, Type)
		SLATE_ARGUMENT(float, ScrollHintScrollAxisOffset)
		SLATE_ARGUMENT(float, ScrollHintLineAxisPercentOffset)
	SLATE_END_ARGS()

	void Construct(const SKGRotateBox::FArguments& InArgs);

protected:
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	EType Type = EType::NoRotate;
	float ScrollHintScrollAxisOffset = 0;
	float ScrollHintLineAxisPercentOffset = 0.5;
};