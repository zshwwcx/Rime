#pragma once

#include "CoreMinimal.h"
#include "SlateGlobals.h"
#include "Widgets/SWidget.h"
#include "Styling/SlateTypes.h"
#include "Framework/Text/IRun.h"
#include "Framework/Text/TextLayout.h"
#include "Framework/Text/SlateHyperlinkRun.h"

#if WITH_FANCY_TEXT

class URichTextBlock;

class FKGSlateHyperlinkRun : public FSlateHyperlinkRun
{
public:
	FKGSlateHyperlinkRun(const FRunInfo& InRunInfo, const TSharedRef<const FString>& InText, const FHyperlinkStyle& InStyle, const FOnClick& InNavigateDelegate, const FOnGenerateTooltip& InTooltipDelegate, const FOnGetTooltipText& InTooltipTextDelegate, URichTextBlock* InRichTextBlock)
		: FSlateHyperlinkRun(InRunInfo, InText, InStyle, InNavigateDelegate, InTooltipDelegate, InTooltipTextDelegate)
		, WeakRichTextBlock(InRichTextBlock)
	{
	}

	FKGSlateHyperlinkRun(const FRunInfo& InRunInfo, const TSharedRef<const FString>& InText, const FHyperlinkStyle& InStyle, const FOnClick& InNavigateDelegate, const FOnGenerateTooltip& InTooltipDelegate, const FOnGetTooltipText& InTooltipTextDelegate, URichTextBlock* InRichTextBlock, const FTextRange& InRange)
		: FSlateHyperlinkRun(InRunInfo, InText, InStyle, InNavigateDelegate, InTooltipDelegate, InTooltipTextDelegate, InRange)
		, WeakRichTextBlock(InRichTextBlock)
	{
	}

	explicit FKGSlateHyperlinkRun(const FSlateHyperlinkRun& Run)
		: FSlateHyperlinkRun(Run)
	{
	}

	virtual TSharedRef<IRun> Clone() const override;

	static KGUI_API TSharedRef<FKGSlateHyperlinkRun> Create(const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FHyperlinkStyle& InStyle, FOnClick NavigateDelegate, FOnGenerateTooltip InTooltipDelegate, FOnGetTooltipText InTooltipTextDelegate, URichTextBlock* InRichTextBlock);
	static KGUI_API TSharedRef<FKGSlateHyperlinkRun> Create(const FRunInfo& InRunInfo, const TSharedRef< const FString >& InText, const FHyperlinkStyle& InStyle, FOnClick NavigateDelegate, FOnGenerateTooltip InTooltipDelegate, FOnGetTooltipText InTooltipTextDelegate, URichTextBlock* InRichTextBlock, const FTextRange& InRange);

	KGUI_API virtual TSharedRef< ILayoutBlock > CreateBlock(int32 StartIndex, int32 EndIndex, FVector2D Size, const FLayoutBlockTextContext& TextContext, const TSharedPtr< IRunRenderer >& Renderer) override;
	KGUI_API virtual TSharedRef< ILayoutBlock > CreateBlockWithScale(int32 StartIndex, int32 EndIndex, FVector2D Size, const FLayoutBlockTextContext& TextContext, const TSharedPtr< IRunRenderer >& Renderer, float InScale) override;

protected:
	using FSlateHyperlinkRun::OnNavigate;

	TWeakObjectPtr<URichTextBlock> WeakRichTextBlock;
};

#endif //WITH_FANCY_TEXT