#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SScrollBox.h"

UENUM(BlueprintType)
enum class EKGScrollBoxScrollHintType : uint8
{
	Before,
	After,
};

class KGUI_API SKGScrollBox : public SScrollBox
{
public:
	using Super = SScrollBox;

	DECLARE_DELEGATE_OneParam(FOnDistanceChanged, float)

	void Construct(const FArguments& InArgs);
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
	virtual FReply OnMouseWheel( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent ) override;

	void SetOnDistanceFromTopChanged(FOnDistanceChanged&& InOnDistanceFromTopChanged);
	void SetOnDistanceFromBottomChanged(FOnDistanceChanged&& InOnDistanceFromBottomChanged);

private:
	FOnDistanceChanged OnDistanceFromTopChanged;
	FOnDistanceChanged OnDistanceFromBottomChanged;

	float CachedDistanceFromTop = 0;
	float CachedDistanceFromBottom = 0;
};
