// Copyright Epic Games, Inc. All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "SlateGlobals.h"
#include "Input/Reply.h"
#include "Layout/Margin.h"
#include "Styling/SlateTypes.h"
#include "Framework/Text/SlateHyperlinkRun.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Styling/CoreStyle.h"
#include "Widgets/Input/SHyperlink.h"
#include "Widgets/Images/SImage.h"


class FWidgetViewModel;
enum class ETextShapingMethod : uint8;

#if WITH_FANCY_TEXT

class SKGRichTextImageHyperlink : public SButton
{
public:

	SLATE_BEGIN_ARGS(SKGRichTextImageHyperlink)
		: _Text()
		, _Style(&FCoreStyle::Get().GetWidgetStyle< FHyperlinkStyle >("Hyperlink"))
		, _TextStyle(nullptr)
		, _UnderlineStyle(nullptr)
		, _Padding()
		, _OnNavigate()
		, _TextShapingMethod()
		, _TextFlowDirection()
		, _HighlightColor()
		, _HighlightShape()
		, _HighlightText()
		{}

		SLATE_ATTRIBUTE(FText, Text)
		SLATE_STYLE_ARGUMENT(FHyperlinkStyle, Style)
		SLATE_STYLE_ARGUMENT(FTextBlockStyle, TextStyle)
		SLATE_STYLE_ARGUMENT(FButtonStyle, UnderlineStyle)
		SLATE_ATTRIBUTE(FMargin, Padding)
		SLATE_EVENT(FSimpleDelegate, OnNavigate)
		SLATE_ARGUMENT(TOptional<ETextShapingMethod>, TextShapingMethod)
		SLATE_ARGUMENT(TOptional<ETextFlowDirection>, TextFlowDirection)
		SLATE_ATTRIBUTE(FLinearColor, HighlightColor)
		SLATE_ATTRIBUTE(const FSlateBrush*, HighlightShape)
		SLATE_ATTRIBUTE(FText, HighlightText)
	SLATE_END_ARGS()

public:

	void Construct( const FArguments& InArgs, const FSlateBrush* Brush, EVerticalAlignment ImageVerticalAlignment, FMargin ImagePadding)
	{
		this->OnNavigate = InArgs._OnNavigate;

		check(InArgs._Style);
		const FButtonStyle* UnderlineStyle = InArgs._UnderlineStyle != nullptr ? InArgs._UnderlineStyle : &InArgs._Style->UnderlineStyle;
		const FTextBlockStyle* TextStyle = InArgs._TextStyle != nullptr ? InArgs._TextStyle : &InArgs._Style->TextStyle;
		TAttribute<FMargin> Padding = InArgs._Padding.IsSet() ? InArgs._Padding : InArgs._Style->Padding;

		SButton::Construct(
			SButton::FArguments()
			.ContentPadding(Padding)
			.ButtonStyle(UnderlineStyle)
			.OnClicked(this, &SKGRichTextImageHyperlink::Hyperlink_OnClicked)
			.ForegroundColor(FSlateColor::UseForeground())
			.TextShapingMethod(InArgs._TextShapingMethod)
			.TextFlowDirection(InArgs._TextFlowDirection)
			[
					SNew(SOverlay)
					+ SOverlay::Slot()
					[
						//@C7 CODE - BEGIN CHANGE BY pengwei03@kuaishou.com:文本两端对齐
						SAssignNew(MyHyperLinkTextBlock, STextBlock)
						//@C7 CODE - END CHANGE BY pengwei03@kuaishou.com
						.TextStyle(TextStyle)
						.Text(InArgs._Text)
						.HighlightColor(InArgs._HighlightColor)
						.HighlightShape(InArgs._HighlightShape)
						.HighlightText(InArgs._HighlightText)
					]
					+ SOverlay::Slot()
					.VAlign(ImageVerticalAlignment)
					.HAlign(HAlign_Fill)
					.Padding(ImagePadding)
					[
						SNew(SImage)
						.Image(Brush)
					]

			]
		);
	}

public:

	// SWidget overrides

	virtual FCursorReply OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const override
	{
		return FCursorReply::Cursor(EMouseCursor::Hand);
	}
#if WITH_ACCESSIBILITY
	virtual TSharedRef<FSlateAccessibleWidget> CreateAccessibleWidget() override
	{
		return MakeShareable<FSlateAccessibleWidget>(new FSlateAccessibleHyperlink(SharedThis(this)));
	}
#endif
	//@C7 CODE - BEGIN ADD BY pengwei03@kuaishou.com:文本两端对齐
	TSharedPtr<STextBlock> GetHyperLinkTextBlock() {
		return MyHyperLinkTextBlock;
	}
	//@C7 CODE - END ADD BY pengwei03@kuaishou.com
protected:

	/** Invoke the OnNavigate method */
	FReply Hyperlink_OnClicked()
	{
		OnNavigate.ExecuteIfBound();

		return FReply::Handled();
	}

	/** The delegate to invoke when someone clicks the hyperlink */
	FSimpleDelegate OnNavigate;
	//@C7 CODE - BEGIN ADD BY pengwei03@kuaishou.com:文本两端对齐
	TSharedPtr<STextBlock> MyHyperLinkTextBlock;
	//@C7 CODE - END ADD BY pengwei03@kuaishou.com
};


#endif //WITH_FANCY_TEXT
