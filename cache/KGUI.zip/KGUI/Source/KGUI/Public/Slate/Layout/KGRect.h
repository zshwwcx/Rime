#pragma once

#include "KGRect.generated.h"

struct FGeometry;

USTRUCT(BlueprintType)
struct FKGRect
{
	GENERATED_USTRUCT_BODY()

public:
	static FKGRect CreateAbsoluteRectangle(const FGeometry& Geometry);
	static FKGRect CreateLocalRectangle(const FGeometry& Geometry);

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D Min;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D Max;
};