#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/SPanel.h"

#include "Slate/Layout/KGRect.h"

class SViewport;

UENUM(BlueprintType)
enum class EKGSmartPositioningAreaOrientation : uint8
{
	Horizontal,
	Vertical,
	CenterInViewport,
};

UENUM(BlueprintType)
enum class EKGSmartPositioningAreaAlignment : uint8
{
	LeftOrTop,
	Middle,
	RightOrBottom,
	Auto,
	Fill,
	LeftOrTopConstrainedInViewport UMETA(DisplayName = "Left or Top (Constrained in Viewport)"),
	MiddleConstrainedInViewport UMETA(DisplayName = "Middle (Constrained in Viewport)"),
	RightOrBottomConstrainedInViewport UMETA(DisplayName = "Right or Bottom (Constrained in Viewport)"),
};

UENUM(BlueprintType)
enum class EKGSmartPositioningAreaHorizontalPreferredDirection : uint8
{
	None,
	Left,
	Right,
};

UENUM(BlueprintType)
enum class EKGSmartPositioningAreaVerticalPreferredDirection : uint8
{
	None,
	Top,
	Bottom,
};

class SKGSmartPositioningArea : public SPanel
{
	SLATE_DECLARE_WIDGET_API(SKGSmartPositioningArea, SPanel, KGUI_API)

public:
	SLATE_BEGIN_ARGS(SKGSmartPositioningArea)
		: _bIsDesignTime(false)
		, _PrimaryOrientation(EKGSmartPositioningAreaOrientation::Horizontal)
		, _SecondaryAlignment(EKGSmartPositioningAreaAlignment::LeftOrTop)
		, _HorizontalPreferredDirection(EKGSmartPositioningAreaHorizontalPreferredDirection::None)
		, _VerticalPreferredDirection(EKGSmartPositioningAreaVerticalPreferredDirection::None)
		{
		}
		SLATE_DEFAULT_SLOT(FArguments, Content)
		SLATE_ATTRIBUTE(bool, bIsDesignTime)
		SLATE_ATTRIBUTE(EKGSmartPositioningAreaOrientation, PrimaryOrientation)
		SLATE_ATTRIBUTE(EKGSmartPositioningAreaAlignment, SecondaryAlignment)
		SLATE_ATTRIBUTE(EKGSmartPositioningAreaHorizontalPreferredDirection, HorizontalPreferredDirection)
		SLATE_ATTRIBUTE(EKGSmartPositioningAreaVerticalPreferredDirection, VerticalPreferredDirection)
	SLATE_END_ARGS()

	KGUI_API SKGSmartPositioningArea();
	KGUI_API void Construct(const FArguments& InArgs);
	KGUI_API void SetContent(const TSharedRef<SWidget>& InContent);
	KGUI_API virtual FChildren* GetChildren() override;
	KGUI_API virtual FVector2D ComputeDesiredSize(float LayoutScaleMultiplier) const override;
	KGUI_API virtual void OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const override;

protected:
	const SWidget* GetDesignerViewWidget() const;
	const SWidget* GetViewportWidget() const;

	struct FKGSmartPositioningAreaOneChildSlot : ::TSingleWidgetChildrenWithBasicLayoutSlot<EInvalidateWidgetReason::None> // we want to add it to the Attribute descriptor
	{
		friend SKGSmartPositioningArea;
		using ::TSingleWidgetChildrenWithBasicLayoutSlot<EInvalidateWidgetReason::None>::TSingleWidgetChildrenWithBasicLayoutSlot;
	};
	FKGSmartPositioningAreaOneChildSlot ChildSlot;

	bool bIsDesignTime;
	TAttribute<EKGSmartPositioningAreaOrientation> PrimaryOrientation;
	TAttribute<EKGSmartPositioningAreaAlignment> SecondaryAlignment;
	TAttribute<EKGSmartPositioningAreaHorizontalPreferredDirection> HorizontalPreferredDirection;
	TAttribute<EKGSmartPositioningAreaVerticalPreferredDirection> VerticalPreferredDirection;

	mutable TWeakPtr<SViewport> GameViewport;

protected:
	template <EKGSmartPositioningAreaOrientation Orientation>
	bool IsMinPrefered() const
	{
		switch (Orientation)
		{
		case EKGSmartPositioningAreaOrientation::Horizontal:
			return HorizontalPreferredDirection.Get() == EKGSmartPositioningAreaHorizontalPreferredDirection::Right;
		case EKGSmartPositioningAreaOrientation::Vertical:
			return VerticalPreferredDirection.Get() == EKGSmartPositioningAreaVerticalPreferredDirection::Bottom;
		default:
			check(false);
		}
		return false;
	}

	template <EKGSmartPositioningAreaOrientation Orientation>
	bool IsMaxPrefered() const
	{
		switch (Orientation)
		{
		case EKGSmartPositioningAreaOrientation::Horizontal:
			return HorizontalPreferredDirection.Get() == EKGSmartPositioningAreaHorizontalPreferredDirection::Left;
		case EKGSmartPositioningAreaOrientation::Vertical:
			return VerticalPreferredDirection.Get() == EKGSmartPositioningAreaVerticalPreferredDirection::Top;
		default:
			check(false);
		}
		return false;
	}

	static void UseMin(const bool& bPrimaryOrSecondary, const auto& ScreenMin, const auto& ScreenMax, const auto& AreaMin, const auto& AreaMax, auto& Min, auto& Max, auto& Alignment)
	{
		Min = ScreenMin;
		Max = bPrimaryOrSecondary ? AreaMin : AreaMax;
		Alignment = 1;
	}

	static void UseMax(const bool& bPrimaryOrSecondary, const auto& ScreenMin, const auto& ScreenMax, const auto& AreaMin, const auto& AreaMax, auto& Min, auto& Max, auto& Alignment)
	{
		Min = bPrimaryOrSecondary ? AreaMax : AreaMin;
		Max = ScreenMax;
		Alignment = 0;
	}

	template <EKGSmartPositioningAreaOrientation Orientation>
	void PlaceAuto(FKGRect ScreenRect, FKGRect AreaRect, FVector2D TargetSize2D, EKGSmartPositioningAreaOrientation InPrimaryOrientation, FVector2D& Output2D) const
	{
		constexpr int8 Dimension = (int8)Orientation;
		auto ScreenMin = ScreenRect.Min[Dimension];
		auto ScreenMax = ScreenRect.Max[Dimension];
		auto AreaMin = AreaRect.Min[Dimension];
		auto AreaMax = AreaRect.Max[Dimension];
		auto TargetSize = TargetSize2D[Dimension];
		auto& Output = Output2D[Dimension];
		bool bPrimaryOrSecondary = Orientation == InPrimaryOrientation;

		auto PaddingMin = AreaMin - ScreenMin;
		auto PaddingMax = ScreenMax - AreaMax;
		PaddingMin = FMath::Max(0, PaddingMin);
		PaddingMax = FMath::Max(0, PaddingMax);
		double Min = AreaMin, Max = AreaMax, Alignment = 0.5;
		bool bUsePreferred = false;
		if (IsMinPrefered<Orientation>())
		{
			UseMin(bPrimaryOrSecondary, ScreenMin, ScreenMax, AreaMin, AreaMax, Min, Max, Alignment);
			bUsePreferred = Max - Min >= TargetSize;
		}
		else if (IsMaxPrefered<Orientation>())
		{
			UseMax(bPrimaryOrSecondary, ScreenMin, ScreenMax, AreaMin, AreaMax, Min, Max, Alignment);
			bUsePreferred = Max - Min >= TargetSize;
		}
		if (!bUsePreferred)
		{
			if (PaddingMin > PaddingMax)
			{
				UseMin(bPrimaryOrSecondary, ScreenMin, ScreenMax, AreaMin, AreaMax, Min, Max, Alignment);
			}
			else
			{
				UseMax(bPrimaryOrSecondary, ScreenMin, ScreenMax, AreaMin, AreaMax, Min, Max, Alignment);
			}
		}
		double Size = Max - Min;
		if (Size <= 0)
		{
			Output = Min * (1 - Alignment) + Alignment * Max;
		}
		if (Size >= TargetSize)
		{
		}
		else
		{
			Alignment = 1 - Alignment;
		}
		Output = Min - (TargetSize - Size) * Alignment;
	}

	template <EKGSmartPositioningAreaOrientation Orientation>
	void PlaceAlignment(FKGRect ScreenRect, FKGRect AreaRect, FVector2D TargetSize2D, float Alignment, bool bConstrainedInViewport, FVector2D& Output2D) const
	{
		constexpr int8 Dimension = (int8)Orientation;
		auto Size = AreaRect.Max[Dimension] - AreaRect.Min[Dimension];
		Output2D[Dimension] = AreaRect.Min[Dimension] + Alignment * (Size - TargetSize2D[Dimension]);
		if (bConstrainedInViewport)
		{
			if (Output2D[Dimension] < ScreenRect.Min[Dimension])
			{
				Output2D[Dimension] = ScreenRect.Min[Dimension];
			}
			else if (Output2D[Dimension] > ScreenRect.Max[Dimension] - TargetSize2D[Dimension])
			{
				Output2D[Dimension] = ScreenRect.Max[Dimension] - TargetSize2D[Dimension];
			}
		}
	}

	template <EKGSmartPositioningAreaOrientation Orientation>
	void Place(FKGRect ScreenRect, FKGRect AreaRect, FVector2D TargetSize2D, EKGSmartPositioningAreaOrientation InPrimaryOrientation, EKGSmartPositioningAreaAlignment InSecondaryAlignment, FVector2D& Output2D) const
	{
		if (InPrimaryOrientation == EKGSmartPositioningAreaOrientation::CenterInViewport)
		{
			PlaceAlignment<Orientation>(ScreenRect, ScreenRect, TargetSize2D, 0.5, false, Output2D);
		}
		else if (InPrimaryOrientation == Orientation)
		{
			PlaceAuto<Orientation>(ScreenRect, AreaRect, TargetSize2D, InPrimaryOrientation, Output2D);
		}
		else
		{
			bool bUseDecimalAlignment = false;
			double DecimalAlignment = 0;
			bool bConstrainedInViewport = false;
			switch (InSecondaryAlignment)
			{
			case EKGSmartPositioningAreaAlignment::LeftOrTop:
			case EKGSmartPositioningAreaAlignment::LeftOrTopConstrainedInViewport:
				bUseDecimalAlignment = true;
				DecimalAlignment = 0.0;
				bConstrainedInViewport = InSecondaryAlignment == EKGSmartPositioningAreaAlignment::LeftOrTopConstrainedInViewport;
				break;
			case EKGSmartPositioningAreaAlignment::Middle:
			case EKGSmartPositioningAreaAlignment::MiddleConstrainedInViewport:
				bUseDecimalAlignment = true;
				DecimalAlignment = 0.5;
				bConstrainedInViewport = InSecondaryAlignment == EKGSmartPositioningAreaAlignment::MiddleConstrainedInViewport;
				break;
			case EKGSmartPositioningAreaAlignment::RightOrBottom:
			case EKGSmartPositioningAreaAlignment::RightOrBottomConstrainedInViewport:
				bUseDecimalAlignment = true;
				DecimalAlignment = 1.0;
				bConstrainedInViewport = InSecondaryAlignment == EKGSmartPositioningAreaAlignment::RightOrBottomConstrainedInViewport;
				break;
			case EKGSmartPositioningAreaAlignment::Auto:
				PlaceAuto<Orientation>(ScreenRect, AreaRect, TargetSize2D, InPrimaryOrientation, Output2D);
				break;
			case EKGSmartPositioningAreaAlignment::Fill:
				bUseDecimalAlignment = true;
				DecimalAlignment = 0;
				break;
			default:
				check(false);
			}
			if (bUseDecimalAlignment)
			{
				PlaceAlignment<Orientation>(ScreenRect, AreaRect, TargetSize2D, DecimalAlignment, bConstrainedInViewport, Output2D);
			}
		}
	}

	template <EKGSmartPositioningAreaOrientation Orientation>
	bool Fill(FKGRect AreaRect, FVector2D& ChildSize) const
	{
		constexpr int8 Dimension = (int8)Orientation;
		if (Orientation != PrimaryOrientation.Get())
		{
			if (SecondaryAlignment.Get() == EKGSmartPositioningAreaAlignment::Fill)
			{
				ChildSize[Dimension] = AreaRect.Max[Dimension] - AreaRect.Min[Dimension];
				return true;
			}
		}
		return false;
	}
};