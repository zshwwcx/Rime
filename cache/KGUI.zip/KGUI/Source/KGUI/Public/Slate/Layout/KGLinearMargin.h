#pragma once

#include "CoreMinimal.h"

#include "KGLinearMargin.generated.h"

USTRUCT(BlueprintType)
struct FKGLinearMargin
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Appearance)
	float Lower;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Appearance)
	float Upper;

public:
	FKGLinearMargin()
		: Lower(0.0f)
		, Upper(0.0f)
	{ }

	FKGLinearMargin(float UniformMargin)
		: Lower(UniformMargin)
		, Upper(UniformMargin)
	{
	}

	FKGLinearMargin(float InLower, float InUpper)
		: Lower(InLower)
		, Upper(InUpper)
	{
	}

public:
	FKGLinearMargin operator*(float Scale) const
	{
		return FKGLinearMargin(Lower * Scale, Upper * Scale);
	}

	FKGLinearMargin operator*(const FKGLinearMargin& InScale) const
	{
		return FKGLinearMargin(Lower * InScale.Lower, Upper * InScale.Upper);
	}

	FKGLinearMargin operator+(const FKGLinearMargin& InScale) const
	{
		return FKGLinearMargin(Lower + InScale.Lower, Upper + InScale.Upper);
	}

	FKGLinearMargin operator-(const FKGLinearMargin& InScale) const
	{
		return FKGLinearMargin(Lower - InScale.Lower, Upper - InScale.Upper);
	}

	bool operator==(const FKGLinearMargin& Other) const
	{
		return (Lower == Other.Lower) && (Upper == Other.Upper);
	}

	bool operator!=(const FKGLinearMargin& Other) const
	{
		return Lower != Other.Lower || Upper != Other.Upper;
	}
};