#pragma once

#include "CoreMinimal.h"
#include "Rendering/RenderingCommon.h"

struct FMargin;
struct FGeometry;
struct FSlateVertex;
struct FSlateBrush;

class FKGVertexGenerator
{
public:
	static void GetBrushUVRegion(const FSlateBrush* Brush, FVector2f& OutTopLeft, FVector2f& OutBottomRight);
	static FVector2f GetBrushSize(const FSlateBrush* Brush);
	static FVector2f GetBrushTilingCount(const FSlateBrush* Brush, const FVector2f& Size);
	static float GetPixelCenterOffset();
	
	static void GenerateVertexDataForImage(const FSlateBrush* Brush, const FVector2f& InTopLeft, const FVector2f& InBottomRight, const FVector2f& InStartUV, const FVector2f& InEndUV, const FGeometry& AllottedGeometry, const FColor& InColor, TArray<FSlateVertex>& OutVertex, TArray<SlateIndex>& OutIndices);
	
	static void GenerateVertexDataForBox(const FSlateBrush* Brush, const FVector2f& InTopLeft, const FVector2f& InBottomRight, const FMargin& InPosMargin, const FVector2f& InStartUV, const FVector2f& InEndUV, const FMargin& InUVMargin, const FGeometry& AllottedGeometry, const FColor& InColor, TArray<FSlateVertex>& OutVertex, TArray<SlateIndex>& OutIndices);

	static void GenerateVertexDataForBorder(const FSlateBrush* Brush, const FVector2f& InTopLeft, const FVector2f& InBottomRight, const FVector2f& InStartUV, const FVector2f& InEndUV, const FMargin& Margin, const FGeometry& AllottedGeometry, const FColor& InColor, TArray<FSlateVertex>& OutVertex, TArray<SlateIndex>& OutIndices);

	static  void GenerateVertexDataForRoundBox(const FSlateBrush* Brush, const FVector2f& InTopLeft, const FVector2f& InBottomRight, const FVector2f& InStartUV, const FVector2f& InEndUV, const FGeometry& AllottedGeometry, const FColor& InColor, TArray<FSlateVertex>& OutVertex, TArray<SlateIndex>& OutIndices);

	static void GenerateRadialVerts(const FSlateBrush* Brush, const FGeometry& AllottedGeometry, const FVector2f Center, const float Radius, const float InnerRadius, float CircularStartAngle, float CircularEndAngle, const FVector2f& InStartUV, const FVector2f& InEndUV, const FColor& PackedColor, const float AnglePerSegment, const float ProgressAngle, const int32 ProgressSegments, TArray<FSlateVertex>& Verts, TArray<SlateIndex>& Indices);
};
