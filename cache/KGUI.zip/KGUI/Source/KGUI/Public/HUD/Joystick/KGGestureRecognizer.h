// FKGGestureRecognizer.h
#pragma once

#include "CoreMinimal.h"
#include "InputCoreTypes.h"
#include "Math/Vector2D.h"

enum class EKGGestureType : uint8
{
    NONE = 0,
    PINCH = 1 << 1,      // 双指缩放
    ROTATE = 1 << 2,     // 双指旋转
    PAN = 1 << 3,        // 双指平移
    SWIPE = 1 << 4,      // 双指滑动
};

struct FKGGestureData
{
    EKGGestureType Type;
    bool IsActive;
    float Scale;
    float ScaleDelta;
    float Distance;
    float Rotation;
    float RotationDelta;
    FVector2D Translation;
    FVector2D Center;
    float Velocity;
    FString Direction;
};

struct FTouchFingerInfo
{
    FKey MouseButton;
    FVector2D ScreenPos;
    double LastUpTime;
    double PressTime;
    int32 UpdateFrame = 0;
    int32 PointerIndex = INDEX_NONE;
    bool bIsDrag = false;
    bool bMoved = false;
    bool bIsPressed = false;
};


class FKGGestureRecognizer
{
public:
    
public:
    FKGGestureRecognizer();
    ~FKGGestureRecognizer();

    bool ContainFinger(int32 FingerIdx) const;
    void StartGesture(const TArray<FTouchFingerInfo>& Fingers, double CurrentTime, int32 GestureMask);
    void UpdateGesture(double CurrentTime);
    void EndGesture();
    
    EKGGestureType DetectGesture() const;
    FKGGestureData GetGestureData() const;

    void SetPinchThreshold(float Threshold) { MinPinchDistance = Threshold; }
    void SetRotateThreshold(float Threshold) { MinRotateAngle = Threshold; }
    void SetPanThreshold(float Threshold) { MinPanDistance = Threshold; }
    void SetSwipeThreshold(float Distance, float Time) { MinSwipeDistance = Distance; MaxSwipeTime = Time; }

    // 工具函数
    static float CalculateDistance(const FVector2D& Pos1, const FVector2D& Pos2);
    static float CalculateAngle(const FVector2D& Pos1, const FVector2D& Pos2);
    static FVector2D CalculateCenter(const FVector2D& Pos1, const FVector2D& Pos2);
    static float NormalizeAngle(float Angle);

private:
    EKGGestureType GestureType;
    int32 GestureMask;
    bool IsGestureActive;
    
    // 手势参数
    float MinPinchDistance;
    float MinRotateAngle;
    float MinPanDistance;
    float MinSwipeDistance;
    float MaxSwipeTime;
    
    // 手势状态数据
    float InitialDistance;
    float CurrentDistance;
    float InitialAngle;
    float CurrentAngle;
    FVector2D InitialCenter;
    FVector2D CurrentCenter;
    double GestureStartTime;
    
    TArray<FTouchFingerInfo> GestureGroupFingers;
    
    // 历史数据用于速度计算
    struct FPositionHistoryEntry
    {
        FVector2D Pos1;
        FVector2D Pos2;
        FVector2D Center;
        double Time;
    };
    
    TArray<FPositionHistoryEntry> PositionHistory;
    int32 MaxHistorySize;
    
    void AddToHistory(const FVector2D& Pos1, const FVector2D& Pos2, double Time);
    float CalculateVelocity() const;
    FString CalculateSwipeDirection() const;
};