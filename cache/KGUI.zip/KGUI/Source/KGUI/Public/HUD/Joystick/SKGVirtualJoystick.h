// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KGGestureRecognizer.h"
#include "Widgets/Input/SVirtualJoystick.h"
#include "Layout/WidgetPath.h"
#include "GameFramework/PlayerController.h"

struct FGeometry;
class FSlateRect;

DECLARE_MULTICAST_DELEGATE_OneParam(FOnUsingLeftJoystick, bool);
DECLARE_MULTICAST_DELEGATE_ThreeParams(FOnPointerTouchEvent, const FVector2D&, const FGeometry&, const FPointerEvent&);
DECLARE_MULTICAST_DELEGATE_FourParams(FOnPointerTouchMovedEvent, const FVector2D&, const FVector2D&, const FGeometry&, const FPointerEvent&);
DECLARE_MULTICAST_DELEGATE_OneParam(FOnGesturePinchEvent, const FKGGestureData&);

class FKGCameraInputController : public TSharedFromThis<FKGCameraInputController>
{
public:
	struct FCameraControlParameters
	{
		float ScaleRate = 100;
		float ScaleX = 0.3f;
		float ScaleY = -0.1f;
		float SlideRate = 50.0f;
		float CameraDeadZoneOffset = 10.0f;
		FVector2D CameraMoveSize = FVector2D(100);
	};
public:
	FKGCameraInputController() = default;
	explicit FKGCameraInputController(float InScaleRate, float InScaleX, float InScaleY, float InSlideRate, float InCameraMoveSizeX, float InCameraMoveSizeY, float InCameraDeadZoneOffset);
	virtual ~FKGCameraInputController(){}

	void SetScaleRate(float InScaleRate){ CtrlParams.ScaleRate = InScaleRate; }
	void SetScaleX(float InScaleX){ CtrlParams.ScaleX = InScaleX; }
	void SetScaleY(float InScaleY){ CtrlParams.ScaleY = InScaleY; }
	void SetSlideRate(float InSlideRate){ CtrlParams.SlideRate = InSlideRate; }
	void SetCameraDeadZoneOffset(float InCameraDeadZoneOffset){ CtrlParams.CameraDeadZoneOffset = InCameraDeadZoneOffset; }
    void SetLockMouseOnDraggingCamera(bool bInLock) { bLockMouseOnDraggingCamera = bInLock; }
	void SetCameraMoveSize(float InCameraMoveSizeX, float InCameraMoveSizeY)
	{
		CtrlParams.CameraMoveSize.X = InCameraMoveSizeX;
		CtrlParams.CameraMoveSize.Y = InCameraMoveSizeY;
	}

	float GetScaleRate() const { return CtrlParams.ScaleRate; }
	float GetScaleX() const { return CtrlParams.ScaleX; }
	float GetScaleY() const { return CtrlParams.ScaleY; }
	float GetSlideRate() const { return CtrlParams.SlideRate; }
	float GetCameraDeadZoneOffset()  const { return CtrlParams.CameraDeadZoneOffset; }
	FVector2D GetCameraMoveSize() const	{ return CtrlParams.CameraMoveSize; }

	void OnGesturePinch(const FKGGestureData& GestureData) const;
	void OnTouchStarted(const FVector2D& InScreenPos, const FGeometry& MyGeometry, const FPointerEvent& Event);
	void OnTouchMoved(const FVector2D& InScreenPos, const FVector2D& InDeltaPos, const FGeometry& MyGeometry, const FPointerEvent& Event);
	void OnTouchEnded(const FVector2D& InScreenPos, const FGeometry& MyGeometry, const FPointerEvent& Event);
	
	void RotateCamera(const FVector2D& Input) const;
	void ZoomCamera(float InValue) const;
	void Tick(float InDeltaTime);
	void SetGameViewportWidgetPath(const FWidgetPath& InGameViewportWidgetPath) { GameViewportWidgetPath = InGameViewportWidgetPath; }
private:
	FCameraControlParameters CtrlParams;
	FWidgetPath GameViewportWidgetPath;
	FVector2D TouchBeginPos = FVector2D::ZeroVector;
	FVector2D CameraLastPos = FVector2D::ZeroVector;
	FVector2D DeadZoneOffset = FVector2D::ZeroVector;
	FVector2D DeadZoneLastPos = FVector2D::ZeroVector;
	FVector2D RawValueAccumulator = FVector2D::ZeroVector;
	FVector2D LastRawValue = FVector2D::ZeroVector;
	bool bInDeadZone = false;
    bool bLockMouseOnDraggingCamera = false;

	/** Whether or not to send one last "release" event next tick */
	bool bSendOneMoreEvent = false;
};

/**
 * SKGVirtualJoystick
 */
class SKGVirtualJoystick : public SVirtualJoystick
{
public:
    struct FJoystickInfo
    {
        TSharedPtr<ISlateBrushSource> ImageThumb;
        TSharedPtr<ISlateBrushSource> ImageDirBig;
        TSharedPtr<ISlateBrushSource> ImageDirBgBig;
        TSharedPtr<ISlateBrushSource> ImageDirSmall;
        TSharedPtr<ISlateBrushSource> ImageDirBgSmall;
        TSharedPtr<ISlateBrushSource> ImageClosed;
    	
        /** The size of a joystick that can be re-centered within InteractionSize area */
        FVector2D VisualSize = FVector2D::ZeroVector;

        /** The size of the thumb that can be re-centered within InteractionSize area */
        FVector2D ThumbSize = FVector2D::ZeroVector;

        /** The size of a the interactable area around Center */
        FMargin InteractionZone;

        /** The scale for control input */
        FVector2D InputScale = FVector2D(1.f, 1.f);

        /** The input to send from this control (for sticks, this is the horizontal/X input) */
        FKey MainInputKey;

        /** The secondary input (for sticks, this is the vertical/Y input, unused for buttons) */
        FKey AltInputKey;
    };

    struct FJoystickData
    {
        FJoystickInfo Info;
    	virtual ~FJoystickData(){}
        virtual void Validate() { bValid = true; }
        virtual void Reset();
    	virtual FVector2D ComputeJoystickThumbPosition(const FVector2D& LocalCoord, float* OutDistanceToTouchSqr = nullptr, float* OutDistanceToEdgeSqr = nullptr) const;

        /** The position of the thumb, in relation to the VisualCenter */
        FVector2D ThumbPosition = FVector2D::ZeroVector;

        /** For recentered joysticks, this is the re-center location */
        FVector2D VisualCenter = FVector2D::ZeroVector;

        /** The corrected actual center of the control */
        FVector2D CorrectedCenter = FVector2D::ZeroVector;

        /** The corrected size of a joystick that can be re-centered within InteractionSize area */
        FVector2D CorrectedVisualSize = FVector2D::ZeroVector;

        /** The corrected size of the thumb that can be re-centered within InteractionSize area */
        FVector2D CorrectedThumbSize = FVector2D::ZeroVector;

        /** The corrected size of the interactable area */
        FVector2D CorrectedInteractionSize = FVector2D::ZeroVector;

    	/** The corrected top-left location of the interactable area */
    	FVector2D CorrectedInteractionTopLeft = FVector2D::ZeroVector;

        /** The corrected scale for control input */
        FVector2D CorrectedInputScale = FVector2D::ZeroVector;

        /** Which pointer index is interacting with this control right now, or -1 if not interacting */
        int32 CapturedPointerIndex = -1;

        /** Time to activate joystick **/
        float ElapsedTime = 0.0f;

        /** Visual center to be updated */
        FVector2D NextCenter = FVector2D::ZeroVector;

    	/** Current input value */
    	FVector2D InputValue = FVector2D::ZeroVector;

        /** Whether or not to send one last "release" event next tick */
        bool bSendOneMoreEvent = false;

        /** Whether or not we need position the control against the geometry */
        bool bHasBeenPositioned = false;

        /** Whether or not to update center position */
        bool bNeedUpdatedCenter = false;

    	bool bShowBigRange = false;
    private:
        bool bValid = false;
    };

public:
	FOnUsingLeftJoystick OnUsingLeftJoystick;
	FOnPointerTouchEvent OnMainTouchFingerBegan;
	FOnPointerTouchEvent OnMainTouchFingerEnded;
	FOnPointerTouchMovedEvent OnMainTouchFingerMoved;
    FOnGesturePinchEvent OnGesturePinchEvent;
public:
	KGUI_API SKGVirtualJoystick();
	KGUI_API virtual ~SKGVirtualJoystick();

    SLATE_BEGIN_ARGS(SKGVirtualJoystick)
        { }

    SLATE_END_ARGS()

    KGUI_API void Construct(const FArguments& InArgs);

    static KGUI_API bool ShouldDisplayTouchInterface(class APlayerController* PlayerController);

	KGUI_API void CacheGameViewportWidgetPath();
	KGUI_API void SetSafeZoneOffset(float LeftOffset, float TopOffset, float RightOffset, float BottomOffset);
	KGUI_API void SetFixedCenter(bool bFixed);
	KGUI_API void SetThresholdForWalking(float InWalkValue);
	KGUI_API void SetDelayTimeForCancelRunning(float InDelayTime);
	KGUI_API void SetGesture(uint32 InGestureMask, float InPinchCheckInterval, int32 InMaxTouchFingerCount);
	KGUI_API void SetCameraControlParams(float InScaleRate, float InScaleX, float InScaleY, float InSlideRate, float InCameraMoveSizeX, float InCameraMoveSizeY, float InCameraDeadZoneOffset) const;
	KGUI_API void SetCameraScaleRate(float InScaleRate) const;
	KGUI_API void SetScaleX(float InScaleX) const;
	KGUI_API void SetScaleY(float InScaleY) const;
	KGUI_API void SetSlideRate(float InSlideRate) const;
	KGUI_API void SetCameraDeadZoneOffset(float InCameraDeadZoneOffset) const;
	KGUI_API void SetCameraMoveSize(float InCameraMoveSizeX, float InCameraMoveSizeY) const;
	KGUI_API void ClearAllTouchData();
	KGUI_API void SetLockMouseOnDraggingCamera(bool bInLockMouseOnDraggingCamera);
	
    KGUI_API FJoystickInfo& GetLeftJoystick() { return LeftJoystick.Info; }
    KGUI_API virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

    KGUI_API virtual FVector2D ComputeDesiredSize(float) const override;

	KGUI_API virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	KGUI_API virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	KGUI_API virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
    KGUI_API virtual FReply OnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& Event) override;
    KGUI_API virtual FReply OnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& Event) override;
    KGUI_API virtual FReply OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& Event) override;

    KGUI_API virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

    KGUI_API virtual bool SupportsKeyboardFocus() const override;
    KGUI_API void SetOwnerPlayerController(APlayerController* InPlayerController) { OwnerPlayerController = InPlayerController;}
protected:
    /** Callback for handling display metrics changes. */
    KGUI_API virtual void HandleDisplayMetricsChanged(const FDisplayMetrics& NewDisplayMetric);

    virtual bool ShouldShowJoystick() const;
    virtual int32 DrawLeftJoystick(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const;
    virtual int32 DrawControls(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const;
	virtual int32 DrawDebug(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const;
    virtual int32 TickJoystick(FJoystickData& Joystick, const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime, float ScaleFactor);
    virtual int32 TickControl(FControlData& Control, int32 ControlIndex, const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime, float ScaleFactor);
    virtual void ApplyInput(const FGamepadKeyNames::Type KeyName, float Delta, bool bTreatAsButton, bool bPressed);
	virtual bool HandleJoystickTouch(FJoystickData& Joystick, const FVector2D& LocalCoord, const FVector2D& ScreenSize);

	FORCEINLINE float GetBaseOpacity() const
    {
		return (State == State_Active || State == State_CountingDownToInactive) ? ActiveOpacity : InactiveOpacity;
	}

    static float ResolveRelativePosition(float Position, float RelativeTo, float ScaleFactor);
    static float GetScaleFactor(const FGeometry& Geometry);
    static bool PositionIsInside(const FVector2D& Center, const FVector2D& Point, const FVector2D& Size);
    static bool SupportsTouchInput();

	FTouchFingerInfo& EnsureTouchFinger(int32 PointerIndex);
	void RecordTouchFinger(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	void UpdateTouchFinger(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	void RemoveTouchFinger(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	void ClearTouchFinger(const FTouchFingerInfo& TouchFingerInfo);
    
	void BindGestureGroup(int32 PointerIndex);
	void UnbindGestureGroup(int32 PointerIndex);
	bool CanTriggerGesture(EKGGestureType GestureType) const;
	void UpdateGestureGroupByFingerIndex(int32 PointerIndex);
    void UpdateGestureRecognizers();
    
    void SetAllUserFocusToGameViewportFast();
private:
	FVector2D GetLocalSize(const FGeometry& AllottedGeometry) const;
protected:
    TWeakObjectPtr<APlayerController> OwnerPlayerController = nullptr;
    FJoystickData LeftJoystick;
	FWidgetPath GameViewportWidgetPath;
	TSharedPtr<FKGCameraInputController> CameraCtrl;
	FMargin SafeZoneOffset = {88, 40, 88, 40};
	float ThresholdForWalking = 0.5f;
	float DelayTimeForCancelRunning = 0.1f;
	float LeftTimeForCancelRunning = 0.f;
	float PinchCheckDuration = 0.06f;
	int32 MaxTouchFingersCount = 10;
	uint32 MainTouchFingerIndex = INDEX_NONE;
	uint32 GestureMask = static_cast<uint8>(EKGGestureType::PINCH);
	TMap<int32, FTouchFingerInfo> TouchFingers;
    TArray<FKGGestureRecognizer> GestureRecognizers;
    bool bLockMouseOnDraggingCamera = false;
};
