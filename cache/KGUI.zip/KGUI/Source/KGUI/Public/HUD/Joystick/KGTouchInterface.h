// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/TouchInterface.h"
#include "UObject/ObjectMacros.h"
#include "InputCoreTypes.h"
#include "Styling/SlateBrush.h"
#include "KGTouchInterface.generated.h"

USTRUCT()
struct FKGVirtualJoystick
{
    GENERATED_USTRUCT_BODY()

    /* 摇杆笔刷	*/
    UPROPERTY(EditAnywhere, Category="Appearance")
    FSlateBrush BrushThumb;

	/* 摇杆方向小箭头笔刷 */
    UPROPERTY(EditAnywhere, Category = "Appearance")
    FSlateBrush BrushDirectionSmall;

	/* 摇杆方向小箭头背景笔刷 */
    UPROPERTY(EditAnywhere, Category = "Appearance")
    FSlateBrush BrushDirectionBgSmall;

	/* 摇杆方向小箭头笔刷 */
    UPROPERTY(EditAnywhere, Category = "Appearance")
    FSlateBrush BrushDirectionBig;

	/* 摇杆方向小箭头背景笔刷 */
    UPROPERTY(EditAnywhere, Category = "Appearance")
    FSlateBrush BrushDirectionBgBig;

	/* 摇杆非激活态笔刷 */
    UPROPERTY(EditAnywhere, Category = "Appearance")
    FSlateBrush BrushClosed;
	
	/* 摇杆大小，<= 1.0时，为相对屏幕的百分大小，> 1.0时，为绝对大小 */
    UPROPERTY(EditAnywhere, Category = "Control", meta = (ToolTip = "The size of joystick (if <= 1.0, it's relative to screen, > 1.0 is absolute)"))
    FVector2D VisualSize;
    
	/* 摇杆中心大小，<= 1.0时，为相对屏幕的百分大小，> 1.0时，为绝对大小 */
    UPROPERTY(EditAnywhere, Category = "Control", meta = (ToolTip = "For sticks, the size of the thumb (if <= 1.0, it's relative to screen, > 1.0 is absolute)"))
    FVector2D ThumbSize;
    
	/* 摇杆交互区域，<= 1.0时，为相对屏幕的百分大小，> 1.0时，为绝对大小 */
    UPROPERTY(EditAnywhere, Category = "Control", meta = (ToolTip = "The interactive size of the control. Measured outward from Center. (if <= 1.0, it's relative to screen, > 1.0 is absolute)"))
    FMargin InteractionZone;
    
	/* 灵敏度 */
    UPROPERTY(EditAnywhere, Category = "Control", meta = (ToolTip = "The scale for control input"))
    FVector2D InputScale;

	/* 触发的输入事件 */
    UPROPERTY(EditAnywhere, Category = "Control", meta = (ToolTip = "The main input to send from this control (for sticks, this is the horizontal axis)"))
    FKey MainInputKey;

	/* 触发的输入事件*/
    UPROPERTY(EditAnywhere, Category = "Control", meta = (ToolTip = "The alternate input to send from this control (for sticks, this is the vertical axis)"))
    FKey AltInputKey;
};


/**
 * UKGTouchInterface 
 */
UCLASS(Blueprintable, BlueprintType)
class KGUI_API UKGTouchInterface : public UTouchInterface
{
    GENERATED_BODY()
    
	UPROPERTY(EditAnywhere)
	FKGVirtualJoystick LeftJoystick;

	virtual void Activate(TSharedPtr<SVirtualJoystick> VirtualJoystick) override;

};
