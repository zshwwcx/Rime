#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Text/STextBlock.h"

class SKGDebugFPS : public SCompoundWidget
{
public:
	KGUI_API SKGDebugFPS();
	KGUI_API virtual ~SKGDebugFPS();
	
	SLATE_BEGIN_ARGS(SKGDebugFPS) {}
	SLATE_END_ARGS()

	KGUI_API void Construct(const FArguments& InArgs);
	
	KGUI_API void OnTick(float DeltaTime);

private:
	// 每帧更新FPS值
	void UpdateFPS(float InFPS);

private:
	TSharedPtr<STextBlock> FPSTextBlock;
	int32 CurrentFPS = 999;
};
