// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "Input/UKGInputProcessManager.h"
#include "HUD/ClickEffect/ClickEffectWidget.h"
#include "ClickEffectPanel.generated.h"

class UKGBasicManager;

/**
 * 
 */
UCLASS(meta=( DontUseGenericSpawnObject="True", DisableNativeTick))
class KGUI_API UClickEffectPanel : public UKGUserWidget
{
	GENERATED_BODY()

public:
	void InitData(UKGBasicManager* KGInputProcessManager);

	void DeInit();

	UFUNCTION()
	void OnClickEffectShow(const FPointerEvent& MouseEvent);
	UFUNCTION()
	void SwitchClickEffectType(int32 Type);
	UFUNCTION()
	void PlayAnimationByPosition(FVector2D Position);


	UPROPERTY(meta = (BindWidget))
	UClickEffectWidget* mClickEffectWidget;
	
	// 点击特效类型， 1: Normal, 2:Qte
	UPROPERTY()
	int32 CurClickEffectType;
	// 当前正在播放的普通点击动效index
	UPROPERTY()
	int32 CurPlayNormalIndex;
	// 当前正在播放的qte点击动效index
	UPROPERTY()
	int32 CurPlayQTEIndex;
	//// 普通点击特效子蓝图1
	//UPROPERTY(meta=(BindWidget))
	//UKGUserWidget* WBP_ClickEffect1;
	//// 普通点击特效子蓝图2
	//UPROPERTY(meta=(BindWidget))
	//UKGUserWidget* WBP_ClickEffect2;
	//// 普通点击特效子蓝图3
	//UPROPERTY(meta=(BindWidget))
	//UKGUserWidget* WBP_ClickEffect3;
	// 普通点击动效节点列表
	//UPROPERTY()
	//TArray<UKGUserWidget*> ClickEffects;
	// Qte点击动效节点列表
	UPROPERTY()
	TArray<UKGUserWidget*> ClickEffectsQte;
	// 是否已经绑输入
	UPROPERTY()
	bool bShowClickEffect = false;
	
	void PlayNormalAnimationByPos(FVector2D& Pos);
	void PlayQTEAnimationByPos(FVector2D Pos);

	void SetTotalClickEffectNum(int32 Num);

	void SetClickEffectVisibility(bool bVisible);

	void SetClickEffectNumByConsoleCommand(IConsoleVariable* CVar);

	UFUNCTION()
	void OnClickEffectNormalAnimationFinished();
};
