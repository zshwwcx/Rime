#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Styling/SlateBrush.h"
#include "Components/Widget.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "ClickEffectWidget.generated.h"

// 前向声明
class UMaterialInterface;

// 点击效果数据结构
struct FClickEffect
{
	FSlateBrush Brush;                   // 画刷
	FVector2D Position;                  // 位置（相对于控件）
	FVector2D Size;                      // 效果尺寸
	bool bActive = false;                        // 是否激活
	FName ParamName = NAME_None;
	float ParamValue = 0;
	float LifeTime = 0;
	TWeakObjectPtr<UMaterialInstanceDynamic> DynamicMaterial; // 动态材质实例（复用）

	FClickEffect()
		:bActive(false)
	{
	}

	// 激活效果
	void Activate(int32 InEffectId, const FVector2D& InPosition, const FVector2D& InSize, FName InParamName, float InParamValue, float InLifeTime)
	{
		Position = InPosition;
		Size = InSize;
		ParamName = InParamName;
		ParamValue = InParamValue;
		bActive = true;
		LifeTime = InLifeTime;

		if (DynamicMaterial.IsValid())
		{
			DynamicMaterial->SetScalarParameterValue(ParamName, InParamValue);
		}
	}

	// 停用效果
	void Deactivate()
	{
		bActive = false;
	}
};

/**
 * Slate点击效果控件
 * 使用对象池复用效果和动态材质
 */
class KGUI_API SClickEffectWidget : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SClickEffectWidget)
		: _MaxEffects(3)
		, _EffectSize(FVector2D(107, 107))
		{
		}

		// 最大效果数量（对象池大小）
		SLATE_ARGUMENT(int32, MaxEffects)

		// 效果尺寸
		SLATE_ARGUMENT(FVector2D, EffectSize)

		// 基础材质（用于创建动态实例）
		SLATE_ARGUMENT(TArray<UMaterialInstanceDynamic*>, DynamicMaterials)


	SLATE_END_ARGS()

	// 构造函数
	SClickEffectWidget();

	// 析构函数
	virtual ~SClickEffectWidget() override;

	// 构建控件
	void Construct(const FArguments& InArgs);

	// 激活一个效果（复用对象池中的对象）
	int32 ActivateEffect(const FVector2D& Position, FName InParamName, float InParamValue, float InLifeTime);

	// 停用所有激活的效果
	void DeactivateAllEffects();

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime);

protected:
	// 重写绘制函数
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry,
		const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements,
		int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	// 重写计算期望尺寸
	virtual FVector2D ComputeDesiredSize(float LayoutScaleMultiplier) const override;

	void UpdateTickState();

private:
	

	// 对象池管理
	void InitializeObjectPool();

	void UpdateLifeTime(float delta);

	// 材质管理
	FSlateBrush CreateEffectBrush(UMaterialInstanceDynamic* DynamicMaterial, const FVector2D& Size) const;

private:
	// 对象池 - 固定大小的效果数组
	TArray<FClickEffect> EffectPool;

	// 属性
	int32 MaxPoolSize;
	FVector2D EffectSizeValue;
	TArray<TWeakObjectPtr<UMaterialInstanceDynamic>> DynamicMaterials;
	
	int32 LatestEffectID = -1;
};

/**
 * UMG点击效果控件
 * 可以在蓝图中使用的点击效果控件
 */
UCLASS(Blueprintable, BlueprintType)
class KGUI_API UClickEffectWidget : public UWidget
{
	GENERATED_BODY()

public:
	UClickEffectWidget();

	//~ UWidget接口
	virtual void SynchronizeProperties() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	//~ End UWidget接口

	/**
	 * 激活一个点击效果
	 * @param ScreenPosition 屏幕位置
	 * @return 效果ID，可用于后续控制效果，-1表示失败
	 */
	UFUNCTION(BlueprintCallable, Category = "Click Effect")
	int32 ActivateEffect(const FVector2D& ScreenPosition);

	/**
	 * 停用所有效果
	 */
	UFUNCTION(BlueprintCallable, Category = "Click Effect")
	void DeactivateAllEffects();


protected:
	//~ UWidget接口
	virtual TSharedRef<SWidget> RebuildWidget() override;
	//~ End UWidget接口

private:
	// 将屏幕坐标转换为控件本地坐标
	FVector2D ConvertScreenToLocal(const FVector2D& ScreenPosition) const;

	// 检查Slate控件是否有效
	bool IsSlateWidgetValid() const;

public:
	// 可编辑属性
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Click Effect", meta = (ClampMin = "1", ClampMax = "100"))
	int32 MaxEffects = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Click Effect")
	FVector2D EffectSize = FVector2D(107.0f, 107.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	UMaterialInterface* BaseMaterial = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	FName MaterialParameterNameToSet;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	int Period = 3600;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	float LifeTime = 0.3;

	

private:
	UPROPERTY(Transient)
	TArray<UMaterialInstanceDynamic*> DynamicMaterials;
	
	// Slate控件
	TSharedPtr<SClickEffectWidget> ClickEffectSlateWidget;
};