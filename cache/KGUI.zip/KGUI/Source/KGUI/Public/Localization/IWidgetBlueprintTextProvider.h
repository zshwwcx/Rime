#pragma once

#include "UObject/Interface.h"

#include "IWidgetBlueprintTextProvider.generated.h"

UINTERFACE(BlueprintType)
class KGUI_API UWidgetBlueprintTextProvider : public UInterface
{
	GENERATED_BODY()
};

class KGUI_API IWidgetBlueprintTextProvider
{
	GENERATED_BODY()

public:
	virtual const FString* GetWidgetBlueprintTextDisplayString(const FString& Key) = 0;
	virtual void ClearWidgetBlueprintTextDisplayStringCache() = 0;
};