#pragma once

#include "Widgets/Input/SButton.h"
#include "Widgets/SCompoundWidget.h"
#include "Brushes/SlateRoundedBoxBrush.h"

class UWidget;


struct FKGStringTableTagStyle
{
	FSlateRoundedBoxBrush FrameBorderImageBrush;
	FSlateRoundedBoxBrush ButtonBorderImageBrush;

	FKGStringTableTagStyle(FLinearColor PrimaryColor)
		: FrameBorderImageBrush(FLinearColor::Transparent)
		, ButtonBorderImageBrush(PrimaryColor)
	{
		FrameBorderImageBrush.OutlineSettings.RoundingType = ESlateBrushRoundingType::FixedRadius;
		FrameBorderImageBrush.OutlineSettings.CornerRadii = FVector4::Zero();
		FrameBorderImageBrush.OutlineSettings.Color = PrimaryColor;
		FrameBorderImageBrush.OutlineSettings.Width = 4;

		ButtonBorderImageBrush.OutlineSettings.RoundingType = ESlateBrushRoundingType::FixedRadius;
		ButtonBorderImageBrush.OutlineSettings.CornerRadii = FVector4::Zero();
		ButtonBorderImageBrush.OutlineSettings.Color = PrimaryColor;
		ButtonBorderImageBrush.OutlineSettings.Width = 4;
	}
};

struct FKGStringTableTagResources
{
	TSharedPtr<FKGStringTableTagStyle> Good;
	TSharedPtr<FKGStringTableTagStyle> Bad;

	TSharedPtr<FKGStringTableTagStyle> GoodHovered;
	TSharedPtr<FKGStringTableTagStyle> BadHovered;

	TSharedPtr<FKGStringTableTagStyle> White;
	TSharedPtr<FKGStringTableTagStyle> WhiteHovered;

	FButtonStyle ButtonStyle;

	FKGStringTableTagResources();
};

class FKGStringTableTagMetaData : public ISlateMetaData
{
public:
	SLATE_METADATA_TYPE(FKGStringTableTagMetaData, ISlateMetaData)
};

class KGUI_API SKGStringTableTagItem : public SButton
{
	friend class SKGStringTableTag;

public:
	using Super = SButton;
	void Construct(const FArguments& InArgs, TWeakObjectPtr<UWidget> InWeakWidget, const TFunction<FText(UWidget*)>& InPredicate);
	bool IsTagValid() const;
	FText GetText() const;

protected:
	bool GetStringTableKey(FString& Key) const;
	FText GetKeyDisplayText() const;
	EVisibility GetTagVisibility() const;

	FReply HandleOnButtonClicked() const;

	const FSlateBrush* GetFrameBorderImage() const;
	const FSlateBrush* GetButtonBorderImage() const;

	static FKGStringTableTagResources Resources;

private:
	TWeakObjectPtr<UWidget> WeakWidget;
	TFunction<FText(UWidget*)> Predicate;
};

class KGUI_API SKGStringTableTag : public SCompoundWidget
{
	SLATE_DECLARE_WIDGET(SKGStringTableTag, SCompoundWidget)

	SLATE_BEGIN_ARGS(SKGStringTableTag)
		: _Content()
		{}
		SLATE_DEFAULT_SLOT(FArguments, Content)
	SLATE_END_ARGS()

public:
	void ConstructInternal(const FArguments& InArgs, UWidget* InWidget, const TArray<TFunction<FText(UWidget*)>>& InPredicates);

	template <typename T, typename Pred>
	void Construct(const FArguments& InArgs, T* InWidget, TArray<Pred> InPredicates)
	{
		TArray<TFunction<FText(UWidget*)>> Predicates;
		for (const auto& Predicate : InPredicates)
		{
			Predicates.Add([Predicate](UWidget* Widget)
			{
				if (auto Target = Cast<T>(Widget))
				{
					return Predicate(Target);
				}
				return FText::GetEmpty();
			});
		}
		ConstructInternal(InArgs, Cast<UWidget>(InWidget), Predicates);
	}

protected:
	EVisibility GetTagVisibility() const;

private:
	TWeakObjectPtr<UWidget> WeakWidget;
	TArray<TSharedRef<SKGStringTableTagItem>> TagItems;
	TWeakPtr<SWidget> OriginalWidget;
};

class KGUI_API FKGStringTableTagUtilities
{
public:
	static void ShowStringTableTag();

private:
	static TSharedRef<SWidget> GetOrCreateStringTableTag(UWidget* Widget, TSharedPtr<SWidget> SlateWidget);
	static TSharedRef<SWidget> GetOrCreateStringTableTagInternal(UWidget* Widget, TSharedRef<SWidget> SlateWidget);
};