#pragma once

#include "Internationalization/StringTable.h"

#include "KGStringTable.generated.h"

class UWidgetBlueprintGeneratedClass;

UCLASS()
class KGUI_API UKGStringTable : public UStringTable
{
	GENERATED_BODY()

public:
	static FString StringTableDefaultName;
	static FString GetWidgetBlueprintClassStringTablePathName(UWidgetBlueprintGeneratedClass* Class);

	UKGStringTable();

	virtual void FinishDestroy() override;

	FString GenerateStringTableId() const;

	void RegisterForGC();
	void UnregisterForGC();

	void RegisterStringTable();
	void UnregisterStringTable();

protected:
	virtual void PostLoad() override;

private:

	bool bGCRegistered = false;
	bool bStringTableRegistered = false;
};