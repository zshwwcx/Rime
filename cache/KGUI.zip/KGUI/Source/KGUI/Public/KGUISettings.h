#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Engine/DeveloperSettings.h"
#include "Misc/Paths.h"
#include "PixelFormat.h"
#include "Core/DynamicAtlas/DynamicAtlasPlatformConfiguration.h"
#include "Core/DynamicAtlas/DynamicAtlasSubsystem.h"

#include "UMG/StateManagement/KGStateGroupDeclaration.h"
#include "Engine/Texture2D.h"

#include "KGUISettings.generated.h"

class UKGUserWidget;
class UDataTable;

// 不同分辨率
USTRUCT()
struct FKGUIResolution
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, Category = "Resolution", Config)
	int32 ResX;
	UPROPERTY(EditAnywhere, Category = "Resolution", Config)
	int32 ResY;
	UPROPERTY(EditAnywhere, Category = "Resolution", Config)
	FString Name;
	UPROPERTY(EditAnywhere, Category = "Resolution", Config)
	int32 DPI;
};

USTRUCT()
struct FKGTextPropertyPathEntry
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	FString Pattern;

	UPROPERTY(EditAnywhere)
	FString Alias;
};

UCLASS(Config = Game, DefaultConfig, /*MinimalAPI,*/ DisplayName = "KGUI")
class KGUI_API UKGUISettings : public UDeveloperSettings
{
	GENERATED_UCLASS_BODY()

#if WITH_EDITOR
	virtual FText GetSectionDescription() const override
	{
		return FText::FromString(TEXT("Settings for Kuaishou Game User Interface Framework."));
	}
#endif

	#pragma region 列表

public:
	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bUseSimplifiedListViewEntryTypeRestriction;

	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bUseImprovedScrollToViewImplementation;

	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bHandleTouchStartEventInScrollableListView = true;

	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bRestoreDefaultItemAnimationFinishStateOnEntryInitialized = true;

	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bFlushAnimationOnListEntryRefreshed = true;

	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bPreferToUseWidgetAnimationStyle = true;

	// 修复子项高度超过列表可视区域高度的一些问题
	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bUseBetterSingleRowOverflowHandling = true;

	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bFixScrollItemIntoViewErrorWhenListContentDecreasesAndIsScrolledToTheEnd = true;

	// 现在业务层不需要这个事件（ItemEntry上回调到其UserWidget上的事件，现在业务通过注册列表的事件在Lua层处理，不依赖这个事件），推荐关闭
	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bEnableListViewItemSelectionChangedDelegate = false;

	UPROPERTY(EditAnywhere, Category = "List View", Config)
	bool bUpdateListViewCanTickStateOnGenerating = true;

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild), Config)
	TSoftClassPtr<UKGUserWidget> DefaultScrollHintClassBefore;

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild), Config)
	TSoftClassPtr<UKGUserWidget> DefaultScrollHintClassAfter;

	#pragma endregion

	#pragma region Editor预览
#if WITH_EDITORONLY_DATA
	// Editor预览
	UPROPERTY(EditAnywhere, Category = "Common", Config)
	bool bEnableUIEditorPreview = false;
	UPROPERTY(EditAnywhere, Category = "Common", Config)
	float bViewportScaleFactor = 1.0;
	UPROPERTY(EditAnywhere, Category = "Preview", Config)
	bool bUseSafeArea = false;
	UPROPERTY(EditAnywhere, Category = "Preview", Config)
	bool bPCScale = true;
	UPROPERTY(EditAnywhere, Category = "Preview", meta=(AllowedClasses="Texture2D"), Config)
	TSoftObjectPtr<UTexture2D> SafeAreaTextureRef;
	UPROPERTY(EditAnywhere, Category = "Preview", Config)
	TArray<FKGUIResolution> ResolutionList;
	UPROPERTY(EditAnywhere, Category = "Preview", Config)
	int32 CurrentResolutionIndex = 0;
#endif
	#pragma endregion

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, Category = "Common", Config)
	bool bEnableNewUI = true;

	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "LuaGenerator", Config)
	FString LuaRootPath = TEXT("Script");

	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "LuaGenerator", Config)
	FString LuaComponentPath = TEXT("Framework/KGFramework/KGUI/Component");

	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "LuaGenerator", Config)
	FString LuaGameUIPath = TEXT("Gameplay/LogicSystem");

	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "LuaGenerator", Config)
	FString LuaSystemPath = TEXT("Gameplay/LogicSystem");

	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "LuaGenerator", Config)
	FString IntelliSensePath = FPaths::ProjectContentDir() / "IntelliSense";


	/** UMG界面使用的image资源目录 */
	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "UIResource", Config)
	TArray<FString> UIPanelResourceReferencePath = {
		TEXT("/Game/Arts/UI/Atlases"),
		TEXT("/Game/Arts/UI/DynamicAtlases"),
		TEXT("/Game/Arts/UI/Images"),
		TEXT("/Game/Arts/UI/Materials"),
	};

	/** UMG界面蓝图目录 */
	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "UIResource", Config)
	FString UIPanelBlueprintPath = TEXT("/Game/Arts/UI_2/Blueprint");

	/** UMG公共库蓝图目录 */
	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "UIResource", Config)
	FString UICommonBlueprintPath = TEXT("/Game/Arts/UI_2/Blueprint/Common");

	/** 是否打开UMG 资源过滤器 */
	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "UIResource", Config)
	bool UMGAssetFilterOpen = false;
	/** 是否打开UMG Class过滤器 */
	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnableNewUI", EditConditionHides), Category = "UIResource", Config)
	bool UMGClassFilterOpen = false;
	
	FString LuaRootDir() const { return FPaths::ProjectContentDir() / LuaRootPath; }
	FString LuaComponentDir() const { return LuaRootDir() / LuaComponentPath; }
	FString LuaGameUIDir() const { return LuaRootDir() / LuaGameUIPath; }
	FString LuaSystemDir() const { return LuaRootDir() / LuaSystemPath; }
	FString IntelliSenseDir() const { return IntelliSensePath; }
#endif

	UPROPERTY(EditAnywhere, Category = "DPI ApplicationScale", Config)
	float DPIApplicationScale = 0.85f; // PC包的DPI ApplicationScale，默认0.85

	#pragma region 文本

	UPROPERTY(EditAnywhere, Category = "Text", Config)
	FTextBlockStyle DefaultTextBlockStyle;

	UPROPERTY(EditAnywhere, Category = "Text", Config)
	bool bEnableTextBlockChangeCheck = true;

	#pragma endregion

	#pragma region 状态组模板

#if WITH_EDITORONLY_DATA

protected:
	UPROPERTY(Config, EditAnywhere, Category = StateManagement, meta = (AllowedClasses = "DataTable", RequiredAssetDataTags = "RowStructure=/Script/KGUI.KGStateGroupDeclaration", DisplayName = "State Group Declaration Data Table"))
	FSoftObjectPath StateGroupDeclarationDataTablePath;

	UPROPERTY(Transient)
	mutable UDataTable* StateGroupDeclarationDataTable = nullptr;

	UPROPERTY(Transient)
	mutable FSoftObjectPath CurrentStateGroupDeclarationDataTablePath;

#endif

#if WITH_EDITOR

public:
	bool TryGetStateGroupDeclaration(const FString& Name, FKGStateGroupDeclaration& StateGroupDeclaration) const;
	TArray<FKGStateGroupDeclaration> GetAllStateGroupDeclarationsInDataTable() const;

private:
	UDataTable* GetStateGroupDeclarationDataTable() const;
	bool ValidateAllStateGroupDeclarationsInDataTable(TArray<FText>* OutErrorList) const;
	bool ValidateStateGroupDeclaration(const FString& Name, FKGStateGroupDeclaration* StateGroupDeclarationPtr, TArray<FText>* OutErrorList) const;

#endif

	#pragma endregion

	#pragma region 动画
public:

	UPROPERTY(Config, EditAnywhere, Category = Animation)
	FString OpenAnimationName;

	UPROPERTY(Config, EditAnywhere, Category = Animation)
	FString CloseAnimationName;
	
	UPROPERTY(Config, EditAnywhere, Category = Animation)
	FString LoopAnimationName;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea")
	TArray<TSubclassOf<class UWidget>> ResponseWidgetsForAnimArea;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Hover")
	int32 ExpansionSizeOnHovered = 2;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Hover", meta = (DisplayName = "Scale Curve"))
	TSoftObjectPtr<class UCurveFloat> HoverScale;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Hover", meta = (DisplayName = "Opacity Curve"))
	TSoftObjectPtr<class UCurveFloat> HoverOpacity;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Hover", meta = (DisplayName = "Duration"))
	float HoverDuration = 0.1f;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Hover", meta = (DisplayName = "HoverAnimName"))
	FString HoverAnimName = "";

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Hover", meta = (DisplayName = "UnhoverAnimName"))
	FString UnhoverAnimName = "";

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Press")
	int32 ExpansionSizeOnPressed = 2;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Press", meta = (DisplayName = "Scale Curve"))
	TSoftObjectPtr< class UCurveFloat> PressScale;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Press", meta = (DisplayName = "Opacity Curve"))
	TSoftObjectPtr<class UCurveFloat> PressOpacity;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Press", meta = (DisplayName = "Duration"))
	float PressDuration = 0.1f;

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Press", meta = (DisplayName = "PressAnimName"))
	FString PressAnimName = "";

	UPROPERTY(Config, EditAnywhere, Category = "Animation|AnimArea|Hover", meta = (DisplayName = "ReleaseAnimName"))
	FString ReleaseAnimName = "";

	#pragma endregion

	#pragma region 动态图集

public:
	bool IsDynamicAtlasEnabled() const { return bDynamicAtlasEnabled; }
	TMap<FName, FDynamicAtlasGroupConfiguration> GenerateFinalDynamicAtlasGroupConfigurations() const;

public:
	bool IsDynamicAtlasCreatedWithCompressedTexture() const;
	EPixelFormat GetDynamicAtlasCompressionFormat() const;
	const FDynamicAtlasPlatformConfiguration* GetDynamicAtlasPlatformConfiguration() const;

protected:
	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	bool bDynamicAtlasEnabled = true;

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	TMap<FName, FDynamicAtlasGroupConfiguration> DynamicAtlasGroupConfigurations;

	UPROPERTY(Config, EditAnywhere, Category = "DynamicAtlas", meta = (AllowedClasses = "DataTable", RequiredAssetDataTags = "RowStructure=/Script/KGUI.DynamicAtlasGroupConfiguration", DisplayName = "Dynamic Atlas Group Configuration Data Table"))
	TSoftObjectPtr<UDataTable> DynamicAtlasGroupConfigurationDataTablePath;

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	TMap<FString, FDynamicAtlasPlatformConfiguration> DynamicAtlasPlatformConfigurations;

public:
	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	bool bDumpDynamicAtlasSlotsWhenResizingTexture = true;

	#pragma endregion

	#pragma region 性能优化及相关工具

public:
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	bool bDesignerViewProfilingInformation = true;

	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	bool bDesignerViewProfilingInformationObjectCountDetailsIncluded = false;

	// Object数量
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_Object_Count = 1500;

	// 字体资源数量
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_FontAsset_Count = MAX_int32;

	// 字体内存
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_FontAsset_Memory = 25 * 1024 * 1024;

	// 静态图集数量
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_StaticAtlas_Count = 2;

	// 静态图集内存
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_StaticAtlas_Memory = MAX_int32;

	// 散图数量
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_UnpackedTexture_Count = MAX_int32;

	// 材质引用的散图数量
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_UnpackedTexture_MaterialReferencingCount = MAX_int32;

	// StaticMesh面数（可能包括KGMeshWidget、Niagara引用的StaticMesh的统计）
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_StaticMesh_PrimitiveCount = MAX_int32;

	// Niagara方面采用 https://docs.corp.kuaishou.com/d/home/fcACBzl85g1iRrsjYjCabd2PB 中UI局外极高画质指标

	// 特效发射器数量
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_Niagara_EmitterCount = 24;

	// 特效CPU粒子数
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_Niagara_ParticleCPUCount = 120;

	// 特效GPU粒子数
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_Niagara_ParticleGPUCount = MAX_int32;

	// 特效模型面数
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_Niagara_PrimitiveCount = 10000;

	// 特效贴图数
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_Niagara_TextureCount = 30;

	// 材质数量
	UPROPERTY(EditAnywhere, Category = Profiling, Config)
	int ProfilingThreshold_Material_Count = MAX_int32;

	#pragma endregion

	#pragma region 九宫格数据

	UPROPERTY(EditAnywhere, Category="Slice 9", Config, DisplayName="Enable Slice 9 Data")
	bool bEnableSlice9Data = true;

	#pragma endregion

	#pragma region 输入

	UPROPERTY(EditAnywhere, Category = "Input", Config)
	bool bDisableFocusableGlobally = true;

	UPROPERTY(EditAnywhere, Category = "Input", Config)
	bool bEditableTextBoxSetUserFocusToGameViewportOnEscape = true;

	#pragma	endregion

	#pragma region 头顶UI

	UPROPERTY(Config, EditAnywhere, Category = "HeadInfoUI", meta = (AllowedClasses = "DataTable", RequiredAssetDataTags = "RowStructure=/Script/KGUI.HeadInfoUIConfiguration", DisplayName = "HeadInfoUI Configuration Data Table"))
	TSoftObjectPtr<UDataTable> HeadInfoUIConfigTable;
	
	#pragma endregion

	#pragma region 本地化

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	bool bEnableAutoMakeTextAvailableOnCreationFromPalette = false;

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	bool bEnableWidgetBlueprintExtension = false;  // 开关1

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	bool bEnableStringMapReplacementInWidgetBlueprint = false;  // 开关2: 依赖开关1

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	bool bEnableAutoUpdateStringMapReplacement = false;  // 开关3: 依赖开关1和开关2

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	bool bEnableStringTableGenerationDuringCompilation = false;  // 开关4: 依赖开关1和开关2

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	bool bEnableDisplayReplacementAtRuntime = false;  // 开关5: 开启后运行时生效

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	TArray<FKGTextPropertyPathEntry> TextPropertyPathAllowlist;

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	TArray<FString> TextPropertyPathBlocklist;

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	FString StaticTextGlobalTablePath;

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	FString StaticTextGlobalTableSheetName;

	UPROPERTY(Config, EditAnywhere, Category = Localization)
	bool bEnableMessageDialogOnClipboardCopyFinished = true;

	#pragma endregion

	#pragma region 资源校验

	UPROPERTY(EditAnywhere, Category = "Validation", Config)
	bool bEnforceLuaNamingForBlueprintFunctions = true;

	#pragma endregion
};