#pragma once

#include "CoreMinimal.h"
#include "KGMemoryStatisticsObjectIdentity.h"

#include "KGMemoryStatisticsTreeNode.generated.h"

struct FSlateBrush;
class UTexture;

USTRUCT()
struct KGUI_API FKGMemoryStatisticsTreeNode
{
	friend struct FKGMemoryStatisticsTree;
	friend class SKGMemoryMap;

	GENERATED_BODY()

public:
	FKGMemoryStatisticsTreeNode();
	explicit FKGMemoryStatisticsTreeNode(const FKGMemoryStatisticsObjectIdentity& InObjectIdentity);
	explicit FKGMemoryStatisticsTreeNode(UObject* InObject);

	FKGMemoryStatisticsObjectIdentity GetObjectIdentity() const { return ObjectIdentity; }

	void AddDirectReferencingObject(UObject* InDirectReferencingObject, TArray<UClass*> RejectedClasses);
	void AppendDirectReferencingObjects(const TSet<UObject*>& InDirectReferencingObjects, TArray<UClass*> RejectedClasses);
	void AppendDirectReferencingObjects(const TArray<UObject*>& InDirectReferencingObjects, TArray<UClass*> RejectedClasses);

	template <typename EnumerableType>
	void AppendDirectReferencingObjects(const EnumerableType& Enumerable, TArray<UClass*> RejectedClasses)
	{
		for (auto& Element : Enumerable)
		{
			AddDirectReferencingObject(Element, RejectedClasses);
		}
	}

	void SetSize(SIZE_T InSize);
	SIZE_T GetSize() const { return Size; }

	const TSet<FKGMemoryStatisticsObjectIdentity>& GetDirectReferencingObjectIdentities() const { return DirectReferencingObjectIdentities; }
	const TSet<FKGMemoryStatisticsObjectIdentity>& GetFullReferencingObjectIdentities() const { return FullReferencingObjectIdentities; }
	const TSet<FKGMemoryStatisticsObjectIdentity>& GetClosureReferencingObjectIdentities() const { return ClosureReferencingObjectIdentities; }

	void SetName(const FString& InName);
	FString GetName() const;
	FString GetTitleString() const;

	void SetBackgroundTexture(UTexture* InTexture);

private:
	bool PrepareComputedData(TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode>& Lookups);

	void AddFullReferenceCount(const FKGMemoryStatisticsObjectIdentity& InObjectIdentity, int Count, const TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode>& Lookups);

	TSharedPtr<FSlateBrush> GetBackgroundBrush();

private:
	UPROPERTY()
	FKGMemoryStatisticsObjectIdentity ObjectIdentity;

	UPROPERTY()
	uint64 Size = 0;

	UPROPERTY()
	TSet<FKGMemoryStatisticsObjectIdentity> DirectReferencingObjectIdentities;

	UPROPERTY()
	TSet<FKGMemoryStatisticsObjectIdentity> FullReferencingObjectIdentities;

	UPROPERTY()
	FString Name;

	UPROPERTY()
	FString BackgroundTexturePath;

	UPROPERTY(Transient)
	TWeakObjectPtr<UTexture> BackgroundTexture;

	TSharedPtr<FSlateBrush> BackgroundBrush;

	// TODO: 后面的内容其实可以在读回内存之后在生成

	UPROPERTY()
	int DirectReferenceCount = 0;

	UPROPERTY()
	TMap<FKGMemoryStatisticsObjectIdentity, int> FullReferenceCounts;

	UPROPERTY()
	bool bComputedDataPrepared = false;

	UPROPERTY()
	TSet<FKGMemoryStatisticsObjectIdentity> ClosureReferencingObjectIdentities;
};