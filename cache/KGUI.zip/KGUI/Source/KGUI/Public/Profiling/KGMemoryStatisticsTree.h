#pragma once

#include "CoreMinimal.h"

#include "KGMemoryStatisticsTreeNode.h"
#include "UMG/Components/KGMeshWidget.h"

#include "KGMemoryStatisticsTree.generated.h"


class UNiagaraComponent;

struct KGUI_API FKGMemoryStatisticsTreeUserDataKeys
{
	static FName Niagara_Count;
	static FName Niagara_EmitterCount;
	static FName Niagara_ParticleCPUCount;
	static FName Niagara_ParticleGPUCount;
	static FName Niagara_PrimitiveCount;
	static FName Niagara_StaticMeshPrimitiveCount;
	static FName Niagara_TextureCount;
	static FName Niagara_TextureMemory;
	static FName Niagara_LightCount;

	static FName MeshWidget_PrimitiveCount;
};

USTRUCT()
struct KGUI_API FKGMemoryStatisticsTreeVariantValue
{
	GENERATED_BODY()

	UPROPERTY()
	int Integer = 0;

	UPROPERTY()
	float Float = 0;

	UPROPERTY()
	FString String;

	int GetInteger() const { return Integer; }
	void SetInteger(int InInteger) { Integer = InInteger; }

	float GetFloat() const { return Float; }
	void SetFloat(float InFloat) { Float = InFloat; }

	const FString& GetString() const { return String; }
	void SetString(const FString& InString) { String = InString; }

	void MergeWith(const FKGMemoryStatisticsTreeVariantValue& MemoryStatisticsTreeVariantValue)
	{
		Integer += MemoryStatisticsTreeVariantValue.Integer;
		Float += MemoryStatisticsTreeVariantValue.Float;
		String += MemoryStatisticsTreeVariantValue.String;
	}
};

USTRUCT()
struct KGUI_API FKGMemoryStatisticsTreeUserData
{
	GENERATED_BODY()

	void IncreaseInteger(FName Name, int Integer)
	{
		Values.FindOrAdd(Name).SetInteger(Values.FindOrAdd(Name).GetInteger() + Integer);
	}

	void IncreaseFloat(FName Name, float Float)
	{
		Values.FindOrAdd(Name).SetFloat(Values.FindOrAdd(Name).GetFloat() + Float);
	}

	void MergeWith(const FKGMemoryStatisticsTreeUserData& MemoryStatisticsTreeUserData)
	{
		for (auto Pair : MemoryStatisticsTreeUserData.Values)
		{
			Values.FindOrAdd(Pair.Get<0>()).MergeWith(Pair.Get<1>());
		}
	}

	bool IsEmpty() const
	{
		return Values.IsEmpty();
	}

	const FKGMemoryStatisticsTreeVariantValue& GetValue(FName Name) const
	{
		return Values.FindOrAdd(Name);
	}

	void SetValue(FName Name, const FKGMemoryStatisticsTreeVariantValue& Value) const
	{
		Values.FindOrAdd(Name) = Value;
	}

	void ClearValue(FName Name)
	{
		Values.Remove(Name);
	}

	void AddTransientReferencingObject(UObject* Object)
	{
		TransientReferencingObjects.Add(Object);
	}

	const TSet<UObject*>& GetTransientReferencingObjects() const { return TransientReferencingObjects; }

private:
	UPROPERTY()
	mutable TMap<FName, FKGMemoryStatisticsTreeVariantValue> Values;

	UPROPERTY(Transient)
	TSet<UObject*> TransientReferencingObjects;
};

USTRUCT()
struct KGUI_API FKGMemoryStatisticsTree
{
	friend class SKGMemoryMap;

	GENERATED_BODY()

public:
	static FKGMemoryStatisticsTree Build(UObject* InObject, const TDelegate<void(FKGMemoryStatisticsTree&, FKGMemoryStatisticsTreeNode&)>& InCallback);

	FKGMemoryStatisticsTreeNode& GetTreeNode(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity)
	{
		auto Found = Lookups.Find(ObjectIdentity);
		check(Found);
		return *Found;
	}

	const FKGMemoryStatisticsTreeNode& GetTreeNode(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity) const
	{
		auto Found = Lookups.Find(ObjectIdentity);
		check(Found);
		return *Found;
	}

	bool ContainsTreeNode(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity) const { return Lookups.Find(ObjectIdentity) != nullptr; }

	TSet<UObject*> ResolveReferencingObjects(UObject* Object, const TArray<UClass*>& WhiteList = TArray<UClass*>{ UObject::StaticClass() }) const;

	FKGMemoryStatisticsTreeNode& CreateUserTreeNode(FKGMemoryStatisticsTreeNode& Parent, uint64 InUserID);

	const TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode>& GetTreeNodeLookups() const { return Lookups; }

	const auto& GetUserDatas() const { return UserDatas; }
	FKGMemoryStatisticsTreeUserData GetUserData(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity) const
	{
		auto Found = UserDatas.Find(ObjectIdentity);
		if (Found != nullptr)
		{
			return *Found;
		}
		return FKGMemoryStatisticsTreeUserData();
	}

	void RefreshNiagaraUserDatas();

private:
	TSet<UObject*> ResolveReferencingObjectsInternal(void* Container, UStruct* Struct, const TArray<UClass*>& WhiteList = TArray<UClass*>{ UObject::StaticClass() }) const;
	TSet<UObject*> ResolveReferencingObjectsInternal(void* Container, FProperty* Property, const TArray<UClass*>& WhiteList) const;

	void BuildMemoryMapNodeData(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity);
	void OnAdded(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity, FKGMemoryStatisticsTreeNode& MemoryStatisticsTreeNode);
	void OnPostBuild();

	void TryMergeWithNonEmptyUserData(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity, const FKGMemoryStatisticsTreeUserData& MemoryStatisticsTreeUserData);
	static FKGMemoryStatisticsTreeUserData GenerateMemoryStatisticsTreeUserData(UNiagaraComponent* NiagaraComponent);
	static FKGMemoryStatisticsTreeUserData GenerateMemoryStatisticsTreeUserData(UKGMeshWidget* NiagaraComponent);

private:
	UPROPERTY()
	TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeNode> Lookups;

	UPROPERTY()
	FKGMemoryStatisticsObjectIdentity RootObjectIdentity;

	TMap<TSharedPtr<FSlateBrush>, TWeakObjectPtr<UTexture>> TextureCache;
	TDelegate<void(FKGMemoryStatisticsTree&, FKGMemoryStatisticsTreeNode&)> Callback;

	UPROPERTY()
	TMap<FKGMemoryStatisticsObjectIdentity, FKGMemoryStatisticsTreeUserData> UserDatas;
};
