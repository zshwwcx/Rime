#pragma once

#include "CoreMinimal.h"

#include "KGUIProfilingObjectCapacity.generated.h"

USTRUCT()
struct FKGUIProfilingObjectCapacity
{
	GENERATED_BODY()

	UPROPERTY()
	int Count = 0;

	UPROPERTY()
	int Memory = 0;

	FString ToString(bool bSimple = false) const
	{
		if (bSimple)
		{
			return FString::Printf(TEXT("%d (%s)"), Count, *FText::AsMemory(Memory).ToString());
		}
		else
		{
			return FString::Printf(TEXT("COUNT: %d; MEMORY: %s"), Count, *FText::AsMemory(Memory).ToString());
		}
	}
};