#pragma once

#include "CoreMinimal.h"

#include "KGMemoryStatisticsObjectIdentity.generated.h"

USTRUCT()
struct KGUI_API FKGMemoryStatisticsObjectIdentity
{
	GENERATED_BODY()

public:
	FKGMemoryStatisticsObjectIdentity();
	explicit FKGMemoryStatisticsObjectIdentity(UObject* InObject);
	explicit FKGMemoryStatisticsObjectIdentity(uint64 InUserID);

	UObject* GetObjectInternal() const { return Object.Get(); }
	FString GetObjectName() const { return ObjectName; }
	FString GetObjectFullName() const { return ObjectFullName; }
	FString GetClassName() const { return ClassName; }
	FString GetClassPathName() const { return ClassPathName; }
	uint64 GetID() const { return ID; }
	uint64 GetUserID() const { return UserID; }

	bool IsValid() const { return ID != 0 || UserID != 0; }
	bool IsA(UClass* Class) const;

	FORCEINLINE bool operator==(const FKGMemoryStatisticsObjectIdentity& Other) const
	{
		return this->ID == Other.ID;
	}

private:
	UPROPERTY(Transient)
	TWeakObjectPtr<UObject> Object;

	UPROPERTY()
	uint64 ID;

	UPROPERTY()
	uint64 UserID;

	UPROPERTY()
	FString ObjectName;

	UPROPERTY()
	FString ObjectFullName;

	UPROPERTY()
	FString ClassName;

	UPROPERTY()
	FString ClassPathName;
};

FORCEINLINE uint32 GetTypeHash(const FKGMemoryStatisticsObjectIdentity& ObjectIdentity)
{
	uint32 Hash = 0;
	Hash = HashCombine(Hash, GetTypeHash(ObjectIdentity.GetID()));
	Hash = HashCombine(Hash, GetTypeHash(ObjectIdentity.GetUserID()));
	return Hash;
}
