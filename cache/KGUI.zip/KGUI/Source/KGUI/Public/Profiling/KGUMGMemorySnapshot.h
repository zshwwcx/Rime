#pragma once

#include "CoreMinimal.h"
#include "KGMemoryStatisticsTree.h"
#include "Components/Widget.h"

struct KGUI_API FKGUMGMemorySnapshot
{
public:
	static bool IsWidgetFinalVisible(UWidget* Widget);
	static FKGMemoryStatisticsTree GenerateMemoryStatisticsTree(UObject* Object, TArray<UClass*> RejectedClasses = {});
	static FKGMemoryStatisticsTree GenerateMemoryStatisticsTreeComprehensively(UObject* Object);
	static FString GetDefaultMemoryStatisticsTreeDirectoryPath();
	static bool GenerateDefaultMemoryStatisticsTreeFilePath(FString& FullPath);

	static void SaveMemoryStatisticsTree(const TArray<FString>& Args);
	static void SaveMemoryStatisticsTree(const TArray<FString>& Args, const FString& FilePath);
	static bool LoadMemoryStatisticsTree(const FString& FilePath, FKGMemoryStatisticsTree& Tree);

	static UObject* ResolveObjectWithCommandArguments(const TArray<FString>& Args);
};
