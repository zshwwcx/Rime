#pragma once

#include "CoreMinimal.h"

#include "KGMemoryStatisticsTree.h"
#include "KGUIProfilingObjectCapacity.h"

struct KGUI_API FKGMemoryStatisticsTreeAnalyser
{
public:
	FKGMemoryStatisticsTreeAnalyser()
		: ObjectCountFromWidgetBlueprintGeneratedClass(0)
		, ObjectCountFromWidgetAnimation(0)
	{
	}

	FKGMemoryStatisticsTreeAnalyser(const FKGMemoryStatisticsTree& MemoryStatisticsTree)
	{
		Analyse(MemoryStatisticsTree);
	}

	const TSet<FKGMemoryStatisticsObjectIdentity>& GetFontAssetObjectSet()       const { return FontAssetObjectSet; };
	const TSet<FKGMemoryStatisticsObjectIdentity>& GetFontTextureObjectSet()     const { return FontTextureObjectSet; };
	const TArray<FKGMemoryStatisticsTreeNode>& GetFontTextureTreeNodeSet()       const { return FontTextureTreeNodeSet; };
	const TSet<FKGMemoryStatisticsObjectIdentity>& GetStaticAtlasObjectSet()     const { return StaticAtlasObjectSet; };
	const TSet<FKGMemoryStatisticsObjectIdentity>& GetDynamicAtlasObjectSet()    const { return DynamicAtlasObjectSet; };
	const TSet<FKGMemoryStatisticsObjectIdentity>& GetUnpackedTextureObjectSet() const { return UnpackedTextureObjectSet; };
	const TSet<FKGMemoryStatisticsObjectIdentity>& GetMaterialReferencingUnpackedTextureObjectSet() const { return MaterialReferencingUnpackedTextureObjectSet; };
	const TSet<FKGMemoryStatisticsObjectIdentity>& GetMaterialObjectSet()        const { return MaterialObjectSet; };

	const FKGUIProfilingObjectCapacity& GetFontAsset()       const { return FontAsset; }
	const FKGUIProfilingObjectCapacity& GetFontTexture()     const { return FontTexture; }
	const FKGUIProfilingObjectCapacity& GetStaticAtlas()     const { return StaticAtlas; }
	const FKGUIProfilingObjectCapacity& GetDynamicAtlas()    const { return DynamicAtlas; }
	const FKGUIProfilingObjectCapacity& GetStaticMesh()      const { return StaticMesh; }
	const FKGUIProfilingObjectCapacity& GetUnpackedTexture() const { return UnpackedTexture; }
	const FKGUIProfilingObjectCapacity& GetMaterialReferencingUnpackedTexture() const { return MaterialReferencingUnpackedTexture; }
	const FKGUIProfilingObjectCapacity& GetMaterial()        const { return Material; }

	const TMap<FString, int>& GetObjectCountCache() const { return ObjectCountCache; }

	int GetObjectCountFromWidgetBlueprintGeneratedClass() const { return ObjectCountFromWidgetBlueprintGeneratedClass; }
	int GetObjectCountFromWidgetAnimation() const { return ObjectCountFromWidgetAnimation; }

	static int32 SumUpFromObjectCountCache(const TMap<FString, int>& InObjectCountCache)
	{
		int TotalCount = 0;
		for (auto& Pair : InObjectCountCache)
		{
			TotalCount += Pair.Get<1>();
		}

		return TotalCount;
	}

	// For UIAutomationProfile
	int32 GetObjectCountForAutomationProfile() const
	{
		return SumUpFromObjectCountCache(GetObjectCountCache());
	}

	const FKGMemoryStatisticsTreeUserData& GetFullMergedUserData() const { return FullMergedUserData; }

	void RebuildFullMergedUserData(const FKGMemoryStatisticsTree& MemoryStatisticsTree);

	static TMap<FString, int> GetObjectCountCache(const FKGMemoryStatisticsTree& MemoryStatisticsTree);
	static void IncreaseObjectCountCache(TMap<FString, int>& ObjectCountCache, const FKGMemoryStatisticsObjectIdentity& ObjectIdentity);

	template <typename SubTreeRootType>
	static TMap<FString, int> GetObjectCountCache(const FKGMemoryStatisticsTree& MemoryStatisticsTree)
	{
		TSet<FKGMemoryStatisticsObjectIdentity> FilteredObjectIdentities;
		for (auto& Pair : MemoryStatisticsTree.GetTreeNodeLookups())
		{
			auto ObjectIdentity = Pair.Get<0>();
			if (!ObjectIdentity.IsA(SubTreeRootType::StaticClass()))
			{
				continue;
			}
			auto& MemoryStatisticsTreeNode = Pair.Get<1>();
			FilteredObjectIdentities.Append(MemoryStatisticsTreeNode.GetFullReferencingObjectIdentities());
		}
		TMap<FString, int> ObjectCountCache;
		for (auto& FilteredObjectIdentity : FilteredObjectIdentities)
		{
			IncreaseObjectCountCache(ObjectCountCache, FilteredObjectIdentity);
		}
		return ObjectCountCache;
	}

private:
	enum class EKGSubTreeSizeType
	{
		Full,
		Closure,
	};

	static SIZE_T GetSubTreeSize(const FKGMemoryStatisticsTree& MemoryStatisticsTree, const FKGMemoryStatisticsTreeNode& SubTreeRoot, EKGSubTreeSizeType SizeType, TSet<FKGMemoryStatisticsObjectIdentity>& ObjectIdentitySet);
	void Analyse(const FKGMemoryStatisticsTree& MemoryStatisticsTree);

	TSet<FKGMemoryStatisticsObjectIdentity> FontAssetObjectSet;
	TSet<FKGMemoryStatisticsObjectIdentity> FontTextureObjectSet;
	TArray<FKGMemoryStatisticsTreeNode> FontTextureTreeNodeSet;
	TSet<FKGMemoryStatisticsObjectIdentity> StaticAtlasObjectSet;
	TSet<FKGMemoryStatisticsObjectIdentity> DynamicAtlasObjectSet;
	TSet<FKGMemoryStatisticsObjectIdentity> StaticMeshObjectSet;
	TSet<FKGMemoryStatisticsObjectIdentity> UnpackedTextureObjectSet;
	TSet<FKGMemoryStatisticsObjectIdentity> MaterialReferencingUnpackedTextureObjectSet;
	TSet<FKGMemoryStatisticsObjectIdentity> MaterialObjectSet;

	FKGUIProfilingObjectCapacity FontAsset;
	FKGUIProfilingObjectCapacity FontTexture;
	FKGUIProfilingObjectCapacity StaticAtlas;
	FKGUIProfilingObjectCapacity DynamicAtlas;
	FKGUIProfilingObjectCapacity StaticMesh;
	FKGUIProfilingObjectCapacity UnpackedTexture;
	FKGUIProfilingObjectCapacity MaterialReferencingUnpackedTexture;
	FKGUIProfilingObjectCapacity Material;

	TMap<FString, int> ObjectCountCache;
	int ObjectCountFromWidgetBlueprintGeneratedClass;
	int ObjectCountFromWidgetAnimation;

	FKGMemoryStatisticsTreeUserData FullMergedUserData;
};
