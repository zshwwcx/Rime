#pragma once

#include "CoreMinimal.h"
#include "KGMemoryStatisticsTree.h"
#include "KGUIProfilingObjectCapacity.h"

#include "KGUIProfilingRecord.generated.h"

struct FKGUIProfilingRecord;
struct FKGUIProfilingCheckpoint;

struct FKGStatsPrimaryEnableScoped
{
	FKGStatsPrimaryEnableScoped() { StatsPrimaryEnableAdd(); }
	~FKGStatsPrimaryEnableScoped() { StatsPrimaryEnableSubtract(); }
};

USTRUCT()
struct FKGUIProfilingTickOverview
{
	GENERATED_BODY()

	UPROPERTY()
	float SlatePrepassTime = 0;  // Slate::Prepass

	UPROPERTY()
	float SlateDrawWindowTime = 0;  // Slate::DrawWindow

	UPROPERTY()
	float SlateRenderingTime = 0;  // STAT_SlateRenderingRTTime
};

USTRUCT()
struct FKGUIProfilingMemoryOverview
{
	GENERATED_BODY()

	UPROPERTY()
	float TextureMemory = 0;  // TEXTUREGROUP_UI

	UPROPERTY()
	float TextMemory = 0;  // UI_Text

	UPROPERTY()
	float OtherMemory = 0;  // UI_Style + UI_Texture + UI_UMG + UI_Slate
};

USTRUCT()
struct FKGUIProfilingDrawingOverview
{
	GENERATED_BODY()

	UPROPERTY()
	int DrawCallCount = 0;

	UPROPERTY()
	int OverDrawMaxCount = 0;

	UPROPERTY()
	int OverDrawAvgCount = 0;
};

USTRUCT()
struct FKGUIProfilingCheckpoint
{
	GENERATED_BODY()

private:
	static FKGUIProfilingCheckpoint CurrentCheckpoint;
	static FTimerHandle SnapshottingHandle;
	static TSharedPtr<FKGStatsPrimaryEnableScoped> StatsPrimaryEnableScoped;

public:
	static FKGUIProfilingCheckpoint& ResetCurrentCheckpoint()
	{
		CurrentCheckpoint = FKGUIProfilingCheckpoint();
		return CurrentCheckpoint;
	}
	static FKGUIProfilingCheckpoint& GetCurrentCheckpoint() { return CurrentCheckpoint;	}

	static bool IsSnapshotting() { return SnapshottingHandle.IsValid(); }

	bool Snapshot(const FSimpleDelegate& FinishCallback);
	bool HasError() const { return !Errors.IsEmpty(); }

	UPROPERTY()
	bool bValid = false;

	UPROPERTY()
	FDateTime Timestamp;

	UPROPERTY()
	FKGUIProfilingTickOverview TickOverview;

	UPROPERTY()
	FKGUIProfilingMemoryOverview MemoryOverview;

	UPROPERTY()
	FKGUIProfilingDrawingOverview DrawingOverview;

	UPROPERTY()
	FKGMemoryStatisticsTree MemorySnapshot;

	UPROPERTY()
	FKGUIProfilingObjectCapacity FontAsset;

	UPROPERTY()
	FKGUIProfilingObjectCapacity FontTexture;

	UPROPERTY()
	FKGUIProfilingObjectCapacity StaticAtlas;

	UPROPERTY()
	FKGUIProfilingObjectCapacity DynamicAtlas;

	UPROPERTY()
	FKGUIProfilingObjectCapacity UnpackedTexture;

	UPROPERTY()
	int ObjectCount = 0;  // Object Count in Game Viewport

	UPROPERTY()
	TArray<FName> VisitedStatMessageNames;

	UPROPERTY()
	TArray<FString> Errors;

private:
	bool SnapshotInternal();
};

USTRUCT()
struct FKGUIProfilingRecord
{
	GENERATED_BODY()

private:
	static FKGUIProfilingCheckpoint LastBeginCheckpoint;
	static FKGUIProfilingCheckpoint LastEndCheckpoint;

public:
	static bool Begin(const FSimpleDelegate& InFinishCallback = FSimpleDelegate());
	static bool End(const FSimpleDelegate& InFinishCallback = FSimpleDelegate());
	static FKGUIProfilingCheckpoint& GetLastBeginCheckpoint() { return LastBeginCheckpoint; }
	static FKGUIProfilingCheckpoint& GetLastEndCheckpoint() { return LastEndCheckpoint; }

	static FKGUIProfilingRecord Create(const FKGUIProfilingCheckpoint& BeginCheckpoint, const FKGUIProfilingCheckpoint& EndCheckpoint);

	const FKGUIProfilingCheckpoint& GetBeginCheckpoint() const { return BeginCheckpoint; }
	const FKGUIProfilingCheckpoint& GetEndCheckpoint() const { return EndCheckpoint; }

private:
	UPROPERTY()
	FKGUIProfilingCheckpoint BeginCheckpoint;

	UPROPERTY()
	FKGUIProfilingCheckpoint EndCheckpoint;
};