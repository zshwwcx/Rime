#pragma once

#include "Extensions/WidgetBlueprintGeneratedClassExtension.h"
#include "UMG/StyleSheet/KGStyleSheet.h"

#include "KGUIWidgetBlueprintGeneratedClassExtension.generated.h"

class UWidgetAnimation;

UCLASS()
class KGUI_API UKGUIWidgetBlueprintGeneratedClassExtension : public UWidgetBlueprintGeneratedClassExtension
{
	GENERATED_BODY()

public:
	static FString ExtensionName;

	bool ApplyWidgetAnimationInitialStyle(UKGUserWidget& Widget, UWidgetAnimation& WidgetAnimation);
	bool ApplyWidgetAnimationTerminalStyle(UKGUserWidget& Widget, UWidgetAnimation& WidgetAnimation);
	bool HasAnyWidgetAnimationStyle(const UKGUserWidget& Widget, UWidgetAnimation& WidgetAnimation) const;

	UPROPERTY(VisibleAnywhere, Instanced, Category = "Localization")
	TObjectPtr<UStringTable> LocalStringTable;

	UPROPERTY(VisibleAnywhere, Category = "Animation")
	TMap<FName, FKGStyleSheet> AnimationInitialStyles;

	UPROPERTY(VisibleAnywhere, Category = "Animation")
	TMap<FName, FKGStyleSheet> AnimationTerminalStyles;

protected:
	bool ApplyWidgetAnimationStyle(UKGUserWidget& Widget, UWidgetAnimation& WidgetAnimation, const TMap<FName, FKGStyleSheet>& Styles);

};