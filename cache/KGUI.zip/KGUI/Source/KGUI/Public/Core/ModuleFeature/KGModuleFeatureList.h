#pragma once

#include "CoreMinimal.h"
#include "KGModuleFeature.h"

class KGUI_API FKGModuleFeatureList
{
public:
	virtual ~FKGModuleFeatureList() = default;
	virtual void StartupModule();
	virtual void ShutdownModule();

	template <typename FeatureType>
	bool RegisterFeature(FName Name = NAME_None)
	{
		auto Feature = MakeShared<FeatureType>();
		Feature->Name = Name;
		Feature->FeatureListPtr = this;
		Features.Add(Feature);
		if (Feature->Name != NAME_None)
		{
			check(!NamedFeatures.Contains(Feature->Name));
			NamedFeatures.Add(Feature->Name, Feature);
		}
		return true;
	}

	void UnregisterAll()
	{
		for (auto Feature : Features)
		{
			Feature->FeatureListPtr = nullptr;
		}
		Features.Empty();
		NamedFeatures.Empty();
	}

	template <typename FunctorType>
	void Broadcast(FunctorType&& Lambda)
	{
		for (auto& Feature : Features)
		{
			Lambda(Feature);
		}
	}

	TSharedPtr<IKGModuleFeature> GetFeatureByName(FName Name)
	{
		if (!NamedFeatures.Contains(Name))
		{
			return nullptr;
		}
		return NamedFeatures[Name];
	}

private:
	TArray<TSharedPtr<IKGModuleFeature>> Features;
	TMap<FName, TSharedPtr<IKGModuleFeature>> NamedFeatures;
};
