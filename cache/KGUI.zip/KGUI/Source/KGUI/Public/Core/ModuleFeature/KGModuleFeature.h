#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FKGModuleFeatureList;

class KGUI_API IKGModuleFeature : public TSharedFromThis<IKGModuleFeature>
{
	friend class FKGModuleFeatureList;

public:
	virtual ~IKGModuleFeature() = default;
	virtual void StartupModule() {}
	virtual void ShutdownModule() {}

protected:
	IKGModuleFeature* GetModuleFeaturePtr(FName InName) const;

	template <typename T>
	T& GetModuleFeatureChecked(FName InName)
	{
		return *(T*)GetModuleFeaturePtr(InName);
	}

	template <typename T>
	const T& GetModuleFeatureChecked(FName InName) const
	{
		return *(T*)GetModuleFeaturePtr(InName);
	}

private:
	FKGModuleFeatureList* FeatureListPtr = nullptr;
	FName Name;
};
