#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"

#include "DynamicAtlasSlot.generated.h"

USTRUCT(BlueprintType)
struct FDynamicAtlasSlot
{
	GENERATED_BODY()

	UPROPERTY()
	uint32 X = 0;

	UPROPERTY()
	uint32 Y = 0;

	UPROPERTY()
	uint32 Width = 0;

	UPROPERTY()
	uint32 Height = 0;

	FDynamicAtlasSlot() {}
	FDynamicAtlasSlot(uint32 InX, uint32 InY, uint32 InWidth, uint32 InHeight)
		: X(InX)
		, Y(InY)
		, Width(InWidth)
		, Height(InHeight)
	{
	}

	bool RectEquals(const FDynamicAtlasSlot& Other) const
	{
		return X == Other.X
			&& Y == Other.Y
			&& Width == Other.Width
			&& Height == Other.Height;
	}

	bool operator==(const FDynamicAtlasSlot& Other) const
	{
		return RectEquals(Other);
	}

	friend uint32 GetTypeHash(const FDynamicAtlasSlot& Slot)
	{
		uint32 Hash = 0;
		Hash = HashCombine(Hash, GetTypeHash(Slot.X));
		Hash = HashCombine(Hash, GetTypeHash(Slot.Y));
		Hash = HashCombine(Hash, GetTypeHash(Slot.Width));
		Hash = HashCombine(Hash, GetTypeHash(Slot.Height));
		return Hash;
	}

	void SetData(uint32 InX, uint32 InY, uint32 InWidth, uint32 InHeight)
	{
		X = InX;
		Y = InY;
		Width = InWidth;
		Height = InHeight;
	}

	bool IsValid() const
	{
		return Width > 0 && Height > 0;
	}

	FString ToString() const
	{
		return FString::Printf(TEXT("Position: (%d, %d) Size: (%d, %d)"), X, Y, Width, Height);
	}
};

