#pragma once

#include "DynamicAtlasGroupConfiguration.h"
#include "DynamicAtlasSlot.h"
#include "DynamicSprite.h"
#include "Engine/CanvasRenderTarget2D.h"

#include "DynamicAtlas.generated.h"

UCLASS()
class UDynamicAtlasCanvasRenderTarget2D : public UCanvasRenderTarget2D
{
	// UDynamicAtlasCanvasRenderTarget2D类型主要用于在MemReport等工具中可以按类型区分用途

	GENERATED_BODY()

	virtual uint32 CalcTextureMemorySizeEnum(ETextureMipCount Enum) const override;
};

UCLASS()
class UDynamicAtlas : public UObject
{
	GENERATED_BODY()

	friend class UDynamicSprite;

public:
	UFUNCTION()
	void DumpSlots() const;

	void SetConfiguration(const FDynamicAtlasGroupConfiguration& InConfiguration);
	bool TryAddSprite(UDynamicSprite* Sprite, FDynamicAtlasSlot& OutSlot, FIntPoint& OutSize);
	
private:
	static void CopyTexture(
		FDynamicAtlasGroupConfiguration Configuration,
		FRHICommandList& RHICmdList,
		FTextureRHIRef SourceTexture,
		FTextureRHIRef DestTexture,
		FRHIGPUFence* Fence,
		uint32 DestX, uint32 DestY, uint32 Width, uint32 Height, int32 SrcX = -1, int32 SrcY = -1);

	void RemoveSprite(UDynamicSprite* Sprite);

	FDynamicAtlasSlot AllocateSlot(const FIntPoint& Size);
	UTexture* CreateTexture();

	void ResizeTexture();
	
	bool MergeNeighborSlot(const FDynamicAtlasSlot& RemoveSlot);
	void MergeFreeSlotsWithResizedSlot(const FDynamicAtlasSlot& ResizeSlot, bool bHorizontalOrVertical);

private:
	TSet<FDynamicAtlasSlot> UsedSlots;
	TSet<FDynamicAtlasSlot> FreeSlots;

	UPROPERTY(Transient, VisibleAnywhere)
	TObjectPtr<UTexture> AtlasTexture;
	
	int TextureSizeX = 0;
	int TextureSizeY = 0;

	FDynamicAtlasGroupConfiguration Configuration;
};