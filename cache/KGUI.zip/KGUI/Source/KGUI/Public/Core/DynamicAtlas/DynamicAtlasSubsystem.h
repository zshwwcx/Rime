#pragma once

#include "Subsystems/GameInstanceSubsystem.h"

#include "DynamicAtlas.h"
#include "DynamicAtlasGroup.h"
#include "DynamicSprite.h"
#include "Containers/Queue.h"
#include "UMG/Components/KGImage.h"

#include "DynamicAtlasSubsystem.generated.h"

KGUI_API DECLARE_LOG_CATEGORY_EXTERN(LogDynamicAtlas, Log, All);

UCLASS()
class KGUI_API UDynamicAtlasSubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()
	
public:
	// ~Begin USubsystem
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	// ~End USubsystem

	UFUNCTION(BlueprintCallable, Category = DynamicAtlas)
	static UDynamicAtlasSubsystem* GetInstance(const UObject* InWorldContext);

	UFUNCTION(BlueprintCallable, Category=DynamicAtlas)
	void StartUp();

	UFUNCTION(BlueprintCallable, Category = DynamicAtlas)
	bool IsStartedUp() const { return bStartedUp; }

	UFUNCTION(BlueprintCallable, Category = DynamicAtlas)
	bool IsEnabled() const;

	UFUNCTION()
	bool AddSprite(UDynamicSprite* Sprite);

	bool AddSprite(UDynamicSprite* Sprite, UDynamicSprite::FOnInitialized&& OnInitialized);

	const TMap<FName, FDynamicAtlasGroup>& GetAtlasGroups() { return AtlasGroups; }

protected:
	bool TryGetGroupNameByPackagePath(const FString& Path, FName& OutGroupName);
	bool TryGetGroupName(UDynamicSprite* Sprite, FName& OutGroupName);
	FDynamicAtlasGroupConfiguration GetGroupConfiguration(FName GroupName);

	FDynamicAtlasGroup& GetOrCreateAtlasGroup(FName GroupName);

	UPROPERTY(Transient)
	bool bStartedUp = false;

	UPROPERTY(Transient)
	TMap<FName, FDynamicAtlasGroupConfiguration> GroupConfigurations;

	UPROPERTY(Transient)
	TMap<FName, FDynamicAtlasGroup> AtlasGroups;

public:
	DECLARE_EVENT_OneParam(UDynamicAtlasSubsystem, FOnAtlasResized, UDynamicAtlas*)
	FOnAtlasResized& OnAtlasResized() { return OnAtlasResizedEvent; }

private:
	FOnAtlasResized OnAtlasResizedEvent;

	#pragma region 动态加载

public:
	UFUNCTION()
	UDynamicSprite* NewSprite(UTexture2D* Texture2D);

	UDynamicSprite* NewSprite(UTexture2D* Texture2D, UDynamicSprite::FOnInitialized&& OnInitialized);

	UDynamicSprite* GetOrCreateRuntimeSprite(UTexture2D* Texture2D);

	void RemoveRuntimeSprite(FSoftObjectPath RuntimeSourceTexturePath);

	void DumpDynamicAtlasInfo();

private:
	UPROPERTY()
	TMap<FSoftObjectPath, TWeakObjectPtr<UDynamicSprite>> RuntimeSprites;

	#pragma endregion
};