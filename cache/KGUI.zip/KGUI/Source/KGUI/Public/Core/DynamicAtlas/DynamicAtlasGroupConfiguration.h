#pragma once

#include "Engine/TextureDefines.h"
#include "Engine/DataTable.h"

#include "DynamicAtlasGroupConfiguration.generated.h"


USTRUCT(Blueprintable, BlueprintType)
struct FDynamicAtlasGroupConfiguration : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	int AtlasMaxNum = 2;  // -1表示没有最大数量限制

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	int AtlasMinSize = 512;

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	int AtlasMaxSize = 2048;

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	int SlotPadding = 1;

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	float DesignPadding = 0;

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	bool bMergeRecursively = false;

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	FIntPoint SpriteMaxSize = FIntPoint(256, 256);

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	TEnumAsByte<enum TextureFilter> AtlasTextureFilter = TextureFilter::TF_Default;

	UPROPERTY(EditAnywhere, Category = "DynamicAtlas", Config)
	TArray<FString> AutomaticTextureDirectoryPaths;
};
