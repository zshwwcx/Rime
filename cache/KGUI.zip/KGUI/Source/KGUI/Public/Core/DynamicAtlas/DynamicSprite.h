#pragma once

#include "DynamicAtlasSlot.h"
#include "Engine/Texture2D.h"
#include "Slate/SlateTextureAtlasInterface.h"

#include "DynamicSprite.generated.h"

struct FDynamicAtlasGroupConfiguration;
class UDynamicAtlasSubsystem;
class UDynamicAtlas;

UCLASS(BlueprintType, meta=(DisplayThumbnail = "true"))
class KGUI_API UDynamicSprite : public UObject, public ISlateTextureAtlasInterface
{
	GENERATED_BODY()

public:
	friend class FDynamicSpriteDetailsCustomization;

	virtual void BeginDestroy() override;
	virtual FSlateAtlasData GetSlateAtlasData() const override;

	void InitializeInternal(UDynamicAtlasSubsystem* DynamicAtlasSubsystem, UDynamicAtlas* InAtlas, const FDynamicAtlasSlot& InSlot, const FIntPoint& InContentSize);
	void InitializeInternal(UDynamicAtlasSubsystem* DynamicAtlasSubsystem);
	void TryRemoveFromAtlas();
	void SetSourceTextureInternal(UTexture2D* InSourceTexture, bool InbRuntimeCreated)
	{
		SourceTexture = InSourceTexture;
		bRuntimeCreated = InbRuntimeCreated;
		if (InbRuntimeCreated)
		{
			RuntimeSourceTexturePath = InSourceTexture;
		}
	}

	UFUNCTION(BlueprintCallable)
	bool IsInitialized() const { return Subsystem.Get() != nullptr; }

	UFUNCTION(BlueprintCallable)
	bool IsAtlased() const { return Atlas.IsValid(); }

	UFUNCTION(BlueprintCallable)
	void Initialize(UDynamicAtlasSubsystem* DynamicAtlasSubsystem);

	DECLARE_DELEGATE_OneParam(FOnInitialized, UDynamicSprite*)
	void Initialize(UDynamicAtlasSubsystem* DynamicAtlasSubsystem, FOnInitialized&& OnInitialized);

	UFUNCTION(BlueprintCallable)
	void Uninitialize();

	UFUNCTION(BlueprintCallable)
	UDynamicAtlas* GetAtlas() const { return Atlas.Get(); }

	bool IsAtlasable(const FDynamicAtlasGroupConfiguration& InConfiguration, FString* OutError) const;

	UFUNCTION(BlueprintCallable)
	UTexture2D* GetSourceTexture() const;

	UFUNCTION(BlueprintCallable)
	const FDynamicAtlasSlot& GetSlot() const { return Slot; }

	UFUNCTION(BlueprintCallable)
	bool IsRuntimeCreated() const { return bRuntimeCreated; }

	UFUNCTION(BlueprintCallable)
	const FSoftObjectPath& GetRuntimeSourceTexturePath() const { return RuntimeSourceTexturePath; }

	UDynamicAtlasSubsystem* GetSubsystem() const { return Subsystem.Get(); }

	FString ToString() const
	{
		return FString::Printf(TEXT("%s(%s)"), *this->GetName(), *(this->SourceTexture ? this->SourceTexture->GetPathName() : TEXT("None")));
	}
	
protected:
	UPROPERTY(Transient, VisibleAnywhere)
	FDynamicAtlasSlot Slot;

	UPROPERTY(Transient, VisibleAnywhere)
	FIntPoint ContentSize;

	UPROPERTY(Transient, VisibleAnywhere)
	TWeakObjectPtr<UDynamicAtlas> Atlas;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category=Sprite, AssetRegistrySearchable)
	TObjectPtr<UTexture2D> SourceTexture;

	UPROPERTY(Transient)
	TWeakObjectPtr<UDynamicAtlasSubsystem> Subsystem;

	UPROPERTY(Transient)
	FSoftObjectPath RuntimeSourceTexturePath;

	UPROPERTY(Transient)
	bool bRuntimeCreated = false;
};