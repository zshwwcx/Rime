#pragma once

#include "DynamicAtlas.h"
#include "DynamicAtlasGroupConfiguration.h"

#include "DynamicAtlasGroup.generated.h"

class UDynamicAtlasSubsystem;

USTRUCT()
struct FDynamicAtlasGroup
{
	GENERATED_BODY()

public:
	FDynamicAtlasGroup() {}

	FDynamicAtlasGroup(UDynamicAtlasSubsystem* InSubsystem, const FDynamicAtlasGroupConfiguration& InConfiguration)
		: Subsystem(InSubsystem)
		, Configuration(InConfiguration)
	{
	}

	const FDynamicAtlasGroupConfiguration& GetConfiguration() const { return Configuration; }
	const TArray<TObjectPtr<UDynamicAtlas>>& GetAtlasList() const { return AtlasList; }

	bool AddSprite(UDynamicSprite* Sprite, UDynamicSprite::FOnInitialized&& OnInitialized);
	UDynamicAtlas* CreateAtlas();

protected:
	UPROPERTY(Transient)
	TWeakObjectPtr<UDynamicAtlasSubsystem> Subsystem;

	UPROPERTY(Transient)
	TArray<TObjectPtr<UDynamicAtlas>> AtlasList;

	UPROPERTY(Transient)
	FDynamicAtlasGroupConfiguration Configuration;
};
