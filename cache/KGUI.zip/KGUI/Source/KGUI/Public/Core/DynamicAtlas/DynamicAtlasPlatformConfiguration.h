#pragma once

#include "PixelFormat.h"

#include "DynamicAtlasPlatformConfiguration.generated.h"

USTRUCT()
struct FDynamicAtlasPlatformConfiguration
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, Config)
	bool bCreatedWithCompressedTexture;

	UPROPERTY(EditAnywhere, Config)
	TEnumAsByte<EPixelFormat> CompressionFormat = PF_Unknown;
};