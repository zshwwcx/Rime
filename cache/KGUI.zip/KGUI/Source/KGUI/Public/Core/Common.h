#pragma once

#include "CoreMinimal.h"

KGUI_API DECLARE_LOG_CATEGORY_EXTERN(LogKGUI, Log, All);