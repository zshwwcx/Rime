// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Layout/Geometry.h"
#include "UObject/ObjectMacros.h"
#include "UObject/Object.h"
#include "KGLuaBinder.generated.h"

USTRUCT()
struct FEventCallBack
{
	GENERATED_USTRUCT_BODY()
	UPROPERTY(EditAnywhere)
	bool IsLua;
	UPROPERTY(EditAnywhere)
	bool AutoBoundWidgetEvent;
	UPROPERTY(EditAnywhere)
	TFieldPath<FProperty> Property;

	UPROPERTY(EditAnywhere)
	FString LuaDelegate;

	UPROPERTY(EditAnywhere)
	TArray<FString> LuaDelegateParam;

	UPROPERTY(EditAnywhere)
	FString ReturnParam;
	 
	FString GetEventName()
	{
		return IsLua ? LuaDelegate : Property.Get()->GetName();
	}

	friend bool operator ==(const FEventCallBack& A, const FEventCallBack& B)
	{
		if(A.IsLua && B.IsLua)
		{
			return A.LuaDelegate == B.LuaDelegate;
		}else
		{
			return A.Property == B.Property;
		}
	}
};

USTRUCT()
struct FEventNode
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere)
	FName WidgetName;

	UPROPERTY(EditAnywhere)
	TArray<FEventCallBack> CallBackList;
};

USTRUCT()
struct FLuaBinder
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, Category = "LuaGenerate")
	FName LuaPath;
#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, Category = "EventsBinder")
	TMap<FName, FEventNode> BinderMap;
	UPROPERTY(EditAnywhere, Category = "OriginalClassName")
	FName OriginalClassName;
#endif
};