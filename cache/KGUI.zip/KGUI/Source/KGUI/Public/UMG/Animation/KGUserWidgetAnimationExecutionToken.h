#pragma once
#include "MovieSceneExecutionToken.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "KGUserWidgetAnimationSection.h"
#include "Components/PanelWidget.h"


struct FKGUserWidgetAnimationExecutionToken : IMovieSceneExecutionToken
{
	explicit FKGUserWidgetAnimationExecutionToken(const UKGUserWidgetAnimationSection* InSection, const EKGUserWidgetAnimationSectionPosition InSectionPosition)
		: Section(InSection), SectionPosition(InSectionPosition)
	{
	}
	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player)
	{
		// 如果没有播放
		if ((Context.GetStatus() != EMovieScenePlayerStatus::Playing && Context.GetStatus() != EMovieScenePlayerStatus::Scrubbing) || Context.HasJumped())
		{
			return;
		}
        //如果没有绑定的UUserWidget
        if (!Operand.ObjectBindingID.IsValid())
        {
            return;
        }

        UWidget* Widget = nullptr;
        for (TWeakObjectPtr<> WeakObject : Player.FindBoundObjects(Operand))
        {
            Widget = Cast<UWidget>(WeakObject.Get());
            if (Widget)
            {
                break;
            }
        }
        if (!Widget)
        {
            return;
        }
        UKGUserWidget* UserWidget = nullptr;
        if(UKGUserWidget* KGUserWidget = Cast<UKGUserWidget>(Widget))
        {
            UserWidget = KGUserWidget;
        }
        if (!UserWidget)
        {
            return;
        }

        Section->PlayAction(UserWidget, SectionPosition);
	}

	const UKGUserWidgetAnimationSection* Section;
    const EKGUserWidgetAnimationSectionPosition SectionPosition;
};