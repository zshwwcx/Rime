﻿#pragma once

#include "KGNiagaraUIParameterSectionTemplate.h"
#include "Channels/MovieSceneFloatChannel.h"
#include "KGNiagaraUIVectorParameterSectionTemplate.generated.h"

struct FNiagaraVariable;
struct FNiagaraVariableBase;

USTRUCT()
struct FKGNiagaraUIVectorParameterSectionTemplate : public FKGNiagaraUIParameterSectionTemplate
{
	GENERATED_BODY()

public:
	FKGNiagaraUIVectorParameterSectionTemplate();

	FKGNiagaraUIVectorParameterSectionTemplate(FNiagaraVariable InParameter, TArray<FMovieSceneFloatChannel>&& InVectorChannels, int32 InChannelsUsed);

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }

protected:
	virtual void GetAnimatedParameterValue(FFrameTime InTime, const FNiagaraVariableBase& InTargetParameter, const TArray<uint8>& InCurrentValueData, TArray<uint8>& OutAnimatedValueData) const override;
	virtual TArrayView<FNiagaraTypeDefinition> GetAlternateParameterTypes() const override;

private:
	UPROPERTY()
	FMovieSceneFloatChannel VectorChannels[4]; // cppcheck:ignore

	UPROPERTY()
	int32 ChannelsUsed;
};

