#pragma once

#include "CoreMinimal.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "KGUserWidgetAnimationTrack.h"
#include "KGUserWidgetAnimationEvalTemplate.generated.h"

class UKGUserWidgetAnimationTrack;
class UKGUserWidgetAnimationSection;

USTRUCT()
struct FKGUserWidgetAnimationEvalTemplate : public FMovieSceneEvalTemplate
{
    GENERATED_BODY()

public:
    FKGUserWidgetAnimationEvalTemplate();
    FKGUserWidgetAnimationEvalTemplate(const UKGUserWidgetAnimationSection* InSection);

private:
    virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
    //virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
    virtual void EvaluateSwept(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const TRange<FFrameNumber>& SweptRange, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
    virtual void Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
    virtual void TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
    virtual void SetupOverrides() override { EnableOverrides(RequiresSetupFlag | RequiresTearDownFlag); }

public:
    UPROPERTY()
    const UKGUserWidgetAnimationSection* Section = nullptr;

    UPROPERTY(Transient)
    bool bIsEditor = true;
};