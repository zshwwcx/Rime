#pragma once
#include "MovieSceneExecutionToken.h"
#include "KGAudioSection.h"
#include "AkAudioDevice.h"
#include "AkAudio/Classes/AkGameplayStatics.h"


struct KGUI_API FKGAudioExecutionToken : IMovieSceneExecutionToken
{
	explicit FKGAudioExecutionToken(const UKGAudioSection* InSection)
		: Section(InSection)
	{
	}

	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player);

	const UKGAudioSection* Section;
};
