#pragma once

#include "CoreMinimal.h"
#include "MovieSceneNameableTrack.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "Tracks/MovieScenePropertyTrack.h"
#include "KGBezierPointTrack.generated.h"

class UKGBezierPointSection;

/**
 * Handles animation of FKGBezierPoint properties in a movie scene
 */
UCLASS(MinimalAPI)
class UKGBezierPointTrack
	: public UMovieScenePropertyTrack
{
	GENERATED_BODY()

public:
	UKGBezierPointTrack(const FObjectInitializer& ObjectInitializer);

	//~ UMovieSceneTrack interface
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;
	virtual UMovieSceneSection* CreateNewSection() override;
}; 