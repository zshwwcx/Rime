#pragma once

#include "CoreMinimal.h"
#include "MovieSceneSection.h"
#include "Channels/MovieSceneFloatChannel.h"
#include "UMG/Animation/Line/KGBezierPointChannel.h" // Ensure this path is correct
#include "UMG/Components/KGLine.h"
#include "EntitySystem/IMovieSceneEntityProvider.h"
#include "KGBezierPointSection.generated.h"

UCLASS()
class KGUI_API UKGBezierPointSection
	: public UMovieSceneSection
	, public IMovieSceneEntityProvider
{
	GENERATED_UCLASS_BODY()

public:
	FKGBezierPointMask GetMask() const;
	void SetMask(FKGBezierPointMask NewMask);
	FKGBezierPointMask GetMaskByName(const FName& InName) const;

	/** Evaluate the section at a given time. */
	FKGBezierPoint Eval(FFrameTime Time, const FKGBezierPoint& DefaultValue) const;
	FKGBezierPoint GetCurrentValue(const UObject* Object) const;

protected:

	virtual EMovieSceneChannelProxyType CacheChannelProxy() override;

private:
	virtual void ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity) override;

public:
	/** Position X component */
	UPROPERTY()
	FMovieSceneFloatChannel ChannelPositionX;

	/** Position Y component */
	UPROPERTY()
	FMovieSceneFloatChannel ChannelPositionY;

	/** Control Point X component */
	UPROPERTY()
	FMovieSceneFloatChannel ChannelControlPointX;

	/** Control Point Y component */
	UPROPERTY()
	FMovieSceneFloatChannel ChannelControlPointY;

	/** Mask to control which channels are active */
	UPROPERTY()
	FKGBezierPointMask ActiveMask;
}; 