// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MovieSceneTrack.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "AkAudio/Classes/AkAudioEvent.h"
#include "KGAudioTrack.generated.h"

/**
 * 
 */
UCLASS()
class KGUI_API UKGAudioTrack : public UMovieSceneTrack, public IMovieSceneTrackTemplateProducer
{
	GENERATED_BODY()

public:

    UKGAudioTrack(const FObjectInitializer& ObjectInitializer);


    // UMovieSceneTrack interface
    /**
     * Generates a new section suitable for use with this track.
     *
     * @return a new section suitable for use with this track.
     */
    virtual UMovieSceneSection* CreateNewSection() override;
    /**
     * @return Whether or not this track supports multiple row indices.
     */
    virtual bool SupportsMultipleRows() const override { return true; }
    /**
     * @return The name that makes this track unique from other track of the same class.
     */
    virtual FName GetTrackName() const override;
    /**
      * Called when all the sections of the track need to be retrieved.
      *
      * @return List of all the sections in the track.
      */
    virtual const TArray<UMovieSceneSection*>& GetAllSections() const override { return Sections; }
    /*
     * Does this track support this section class type?

     * @param ClassType The movie scene section class type
     * @return Whether this track supports this section class type
     */
    virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;
#if WITH_EDITORONLY_DATA
    /**
    * Get the track's display name.
    *
    * @return Display name text.
    */
    virtual FText GetDisplayName() const override;

    /**
     * Get the track row's display name.
     *
     * @return Display name text.
     */
    virtual FText GetTrackRowDisplayName(int32 RowIndex) const override;

#endif

    /**
     * Generate a template for this track
     *
     * @param Args 			Compilation arguments
     */
    virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;
    virtual void PostCompile(FMovieSceneEvaluationTrack& Track, const FMovieSceneTrackCompilerArgs& Args) const override;

    // 下边这些是完全不用改

    /**
     * Removes animation data.
     */
    virtual void RemoveAllAnimationData() override { Sections.Empty(); }
    /**
      * Checks to see if the section is in this track.
      *
      * @param Section The section to query for.
      * @return True if the section is in this track.
      */
    virtual bool HasSection(const UMovieSceneSection& Section) const override { return Sections.Contains(&Section); }
    /**
     * Add a section to this track.
     *
     * @param Section The section to add.
     */
    virtual void AddSection(UMovieSceneSection& Section) override { Sections.Add(&Section); }
    /**
     * Removes a section from this track.
     *
     * @param Section The section to remove.
     */
    virtual void RemoveSection(UMovieSceneSection& Section) override 
    { 
        int32 Index;
       if(Sections.Find(&Section, Index))
       {
           Sections.RemoveAt(Index);
       }
    }
    /**
     * @return Whether or not this track has any data in it.
     */
    virtual bool IsEmpty() const override { return Sections.Num() == 0; }

protected:
    UPROPERTY()
    TArray<UMovieSceneSection*> Sections;

};
