// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MovieSceneSection.h"
#include "Channels/MovieSceneStringChannel.h"
#include "AkAudio/Classes/AkAudioEvent.h"
#include "KGAudioSection.generated.h"

/**
 * 
 */
UCLASS()
class KGUI_API UKGAudioSection : public UMovieSceneSection
{
	GENERATED_BODY()
	
public:

	UKGAudioSection(const FObjectInitializer& ObjectInitializer);
	FString GetTitle();
	FString GetSubtitle(FFrameTime Time) const;

	/** Associate a new AK audio event with this section. Also updates section time and audio source info. */
	void SetEvent(UAkAudioEvent* AudioEvent);
	UAkAudioEvent* GetEvent() const;
public:

	/** title */
	/*UPROPERTY()
	FMovieSceneStringChannel  Subtitle;*/

	/** The AkAudioEvent represented by this section */
	UPROPERTY(EditAnywhere, Category = "AkAudioEvent", meta = (NoResetToDefault))
	UAkAudioEvent* Event = nullptr;

	UPROPERTY(EditAnywhere, Category = "AkAudioEvent", DisplayName="启用音画同步")
	bool bEnableSync = false;

	UPROPERTY(EditAnywhere, Category = "AkAudioEvent", DisplayName="是否跟随父轨道对象播放")
	bool bPostOnChildActor = false;
};
