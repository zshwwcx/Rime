#pragma once

#include "CoreMinimal.h"
#include "Channels/MovieSceneChannel.h" // Include necessary base class or utility header if needed
#include "KGBezierPointChannel.generated.h"

/**
 * Defines the channels for animating FKGBezierPoint properties in Sequencer.
 */
UENUM(Meta = (Bitflags))
enum class EKGBezierPointChannel : uint8
{
	None = 0 UMETA(Hidden), // Required by Bitflags

	PositionX = 1 << 0,
	PositionY = 1 << 1,
	Position = PositionX | PositionY,
	ControlPointX = 1 << 2,
	ControlPointY = 1 << 3,
	ControlPoint = ControlPointX | ControlPointY,

	All = PositionX | PositionY | ControlPointX | ControlPointY UMETA(Hidden)
};
ENUM_CLASS_FLAGS(EKGBezierPointChannel)

/**
 * Mask structure used to identify specific channels within FKGBezierPoint animation data.
 */
USTRUCT()
struct KGUI_API FKGBezierPointMask
{
	GENERATED_BODY()

	/** Specifies which channels are active */
	UPROPERTY()
	uint32 ActiveChannels;	// EKGBezierPointChannel

	FKGBezierPointMask()
		: ActiveChannels(0)
	{
	}

	FKGBezierPointMask(EKGBezierPointChannel Channel)
		: ActiveChannels(static_cast<__underlying_type(EKGBezierPointChannel)>(Channel))
	{
	}

	/** Check if a specific channel is active */
	bool IsChannelActive(EKGBezierPointChannel Channel) const
	{
		return EnumHasAnyFlags(static_cast<EKGBezierPointChannel>(ActiveChannels), Channel);
	}

	EKGBezierPointChannel GetChannels() const
	{
		return static_cast<EKGBezierPointChannel>(ActiveChannels);
	}

	/** Set a specific channel's active state */
	void SetChannelActive(EKGBezierPointChannel Channel, bool bIsActive)
	{
		if (bIsActive)
		{
			ActiveChannels |= static_cast<uint32>(Channel);
		}
		else
		{
			ActiveChannels &= static_cast<uint32>(~Channel);
		}
	}
}; 