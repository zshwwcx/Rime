// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MovieSceneSection.h"
#include "Blueprint/UserWidget.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "KGUserWidgetAnimationSection.generated.h"

// 用于描述播放控制类型
UENUM(BlueprintType)
enum class EKGUserWidgetAnimationActionType : uint8
{
	PlayWithNum,  // 播放，次数取决于LoopNum属性
	PlayLoop,  // 循环播放
	PlayWithRange,  // 播放，次数取决于Range长度，Range结束时，播放停止
	Stop,  // 停止播放
};

enum class EKGUserWidgetAnimationSectionPosition : uint8
{
	Start,
	End,
};


UCLASS()
class KGUI_API UKGUserWidgetAnimationSection : public UMovieSceneSection
{
	GENERATED_UCLASS_BODY()

public:
	UKGUserWidgetAnimationSection();

	void SetAnim(FString Anim) { AnimName = Anim; }
	FString GetTitle();
	void SetPlayMode(EUMGSequencePlayMode::Type InPlayMode) { PlayMode = InPlayMode; }
	void SetLoopNum(int32 InLoopNum) { LoopNum = InLoopNum; }
	void SetDuration(int32 InDuration) { Duration = InDuration; }

	// FString GetSubtitle(FFrameTime Time) const;
	bool IsPingPong(){ return PlayMode == EUMGSequencePlayMode::Type::PingPong; }

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	void UpdateProperties(UWidgetAnimation* Animation);
#endif
	
	/**
	 * Computes the Anims of the bound userwidget at the section's start time.
	 * This is for internal use by UKGUserWidgetAnimationTrack during pre-compilation.
	 */
	void ComputeInitialUserWidgetAnims(UUserWidget* UserWidget);

	void PlayAction(UKGUserWidget* UserWidget, EKGUserWidgetAnimationSectionPosition SectionPosition) const;

public:

	/** title */
	//UPROPERTY()
	//FMovieSceneStringChannel  Subtitle;

	/** anim */
	UPROPERTY()
	FString AnimName;

	/** playmode */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Animation", meta = (EditCondition = "ActionType != EKGUserWidgetAnimationActionType::Stop", EditConditionHides))
	TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode;

	/** loopnum */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Animation", meta = (EditCondition = "ActionType == EKGUserWidgetAnimationActionType::PlayWithNum", EditConditionHides))
	int32 LoopNum;

	/** Duration */
	UPROPERTY()
	int32 Duration;  // 基本是编辑器时用

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Animation")
	EKGUserWidgetAnimationActionType ActionType;
};
