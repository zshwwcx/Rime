﻿#pragma once

#include "KGNiagaraUIParameterSectionTemplate.h"
#include "Channels/MovieSceneFloatChannel.h"
#include "KGNiagaraUIFloatParameterSectionTemplate.generated.h"

struct FNiagaraVariable;
struct FNiagaraVariableBase;

USTRUCT()
struct FKGNiagaraUIFloatParameterSectionTemplate : public FKGNiagaraUIParameterSectionTemplate
{
	GENERATED_BODY()

public:
	FKGNiagaraUIFloatParameterSectionTemplate();

	FKGNiagaraUIFloatParameterSectionTemplate(FNiagaraVariable InParameter, const FMovieSceneFloatChannel& InIntegerChannel);

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }

protected:
	virtual void GetAnimatedParameterValue(FFrameTime InTime, const FNiagaraVariableBase& InTargetParameter, const TArray<uint8>& InCurrentValueData, TArray<uint8>& OutAnimatedValueData) const override;

private:
	UPROPERTY()
	FMovieSceneFloatChannel FloatChannel;
};

