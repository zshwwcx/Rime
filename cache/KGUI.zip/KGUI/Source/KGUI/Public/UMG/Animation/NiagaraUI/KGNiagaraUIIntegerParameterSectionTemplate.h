﻿#pragma once

#include "KGNiagaraUIParameterSectionTemplate.h"
#include "Channels/MovieSceneIntegerChannel.h"
#include "KGNiagaraUIIntegerParameterSectionTemplate.generated.h"

struct FNiagaraVariable;
struct FNiagaraVariableBase;

USTRUCT()
struct FKGNiagaraUIIntegerParameterSectionTemplate : public FKGNiagaraUIParameterSectionTemplate
{
	GENERATED_BODY()

public:
	FKGNiagaraUIIntegerParameterSectionTemplate();

	FKGNiagaraUIIntegerParameterSectionTemplate(FNiagaraVariable InParameter, const FMovieSceneIntegerChannel& InIntegerChannel);

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }

protected:
	virtual void GetAnimatedParameterValue(FFrameTime InTime, const FNiagaraVariableBase& InTargetParameter, const TArray<uint8>& InCurrentValueData, TArray<uint8>& OutAnimatedValueData) const override;

private:
	UPROPERTY()
	FMovieSceneIntegerChannel IntegerChannel;
};

