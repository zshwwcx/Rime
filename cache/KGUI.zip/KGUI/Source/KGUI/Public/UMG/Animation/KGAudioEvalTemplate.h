#pragma once

#include "CoreMinimal.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "KGAudioTrack.h"
#include "KGAudioEvalTemplate.generated.h"

class UKGAudioTrack;
class UKGAudioSection;

USTRUCT()
struct FKGAudioEvalTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()

public:
	FKGAudioEvalTemplate();
	FKGAudioEvalTemplate(const UKGAudioSection* InSection);

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	virtual void EvaluateSwept(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const TRange<FFrameNumber>& SweptRange, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
	virtual void Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void SetupOverrides() override { EnableOverrides(RequiresSetupFlag); }

public:
	UPROPERTY()
	const UKGAudioSection* Section = nullptr;
};
