#pragma once

#include "CoreMinimal.h"
#include "Systems/MovieScenePropertySystem.h"
#include "UMG/Components/KGLine.h" // For FKGBezierPoint
#include "KGBezierPointPropertySystem.generated.h"

UCLASS(MinimalAPI)
class UKGBezierPointPropertySystem : public UMovieScenePropertySystem
{
	GENERATED_BODY()

public:
	UKGBezierPointPropertySystem(const FObjectInitializer& ObjInitializer);

	virtual void OnRun(FSystemTaskPrerequisites& InPrerequisites, FSystemSubsequentTasks& Subsequents) override;
}; 