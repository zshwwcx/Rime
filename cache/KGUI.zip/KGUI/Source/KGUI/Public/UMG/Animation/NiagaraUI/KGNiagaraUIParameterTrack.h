﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "MovieSceneNameableTrack.h"
#include "NiagaraTypes.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "KGNiagaraUIParameterTrack.generated.h"

/** A base class for tracks that animate niagara parameters. */
UCLASS(abstract)
class KGUI_API UKGNiagaraUIParameterTrack : public UMovieSceneNameableTrack
{
	GENERATED_BODY()
public:
	/** UMovieSceneTrack interface. */
	virtual void AddSection(UMovieSceneSection& Section) override;
	virtual const TArray<UMovieSceneSection*>& GetAllSections() const override;
	virtual bool HasSection(const UMovieSceneSection& Section) const override;
	virtual bool IsEmpty() const override;
	virtual void RemoveAllAnimationData() override;
	virtual void RemoveSection(UMovieSceneSection& Section) override;
	virtual void RemoveSectionAt(int32 SectionIndex) override;
	
	/** Gets the parameter for this parameter track. */
	const FNiagaraVariable& GetParameter() const;

	/** Sets the parameter for this parameter track .*/
	void SetParameter(FNiagaraVariable InParameter);

	virtual void SetSectionChannelDefaults(UMovieSceneSection* Section, const TArray<uint8>& DefaultValueData) const { }

protected:
	template<class ChannelType>
	static ChannelType* GetEditableChannelFromProxy(FMovieSceneChannelProxy& ChannelProxy, const ChannelType& Channel)
	{
		int32 ChannelIndex = ChannelProxy.FindIndex(Channel.StaticStruct()->GetFName(), &Channel);
		if (ChannelIndex != INDEX_NONE)
		{
			return ChannelProxy.GetChannel<ChannelType>(ChannelIndex);
		}
		return nullptr;
	}

	template<class ChannelType, typename ValueType>
	static void SetChannelDefault(FMovieSceneChannelProxy& ChannelProxy, const ChannelType& TargetChannel, ValueType DefaultValue)
	{
		ChannelType* EditableTargetChannel = GetEditableChannelFromProxy(ChannelProxy, TargetChannel);
		if (EditableTargetChannel != nullptr)
		{
			EditableTargetChannel->SetDefault(DefaultValue);
		}
	}

	UPROPERTY()
	TArray<TObjectPtr<UMovieSceneSection>> Sections;

private:
	/** The parameter for the parameter this track animates. */
	UPROPERTY()
	FNiagaraVariable Parameter;
};
