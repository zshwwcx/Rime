﻿#pragma once

#include "KGNiagaraUIParameterTrack.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "KGNiagaraUIVectorParameterTrack.generated.h"

/**
 * 
 */
UCLASS()
class KGUI_API UKGNiagaraUIVectorParameterTrack : public UKGNiagaraUIParameterTrack, public IMovieSceneTrackTemplateProducer
{
	GENERATED_BODY()

public:
	/** UMovieSceneTrack interface. */
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;
	virtual UMovieSceneSection* CreateNewSection() override;
	virtual void SetSectionChannelDefaults(UMovieSceneSection* Section, const TArray<uint8>& DefaultValueData) const override;
	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;

	int32 GetChannelsUsed() const;
	void SetChannelsUsed(int32 InChannelsUsed);

private:
	UPROPERTY()
	int32 ChannelsUsed;
};
