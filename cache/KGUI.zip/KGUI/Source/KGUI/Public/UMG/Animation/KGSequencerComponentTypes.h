#pragma once

#include "EntitySystem/MovieScenePropertyMetaDataTraits.h"
#include "EntitySystem/MovieScenePropertySystemTypes.h"
#include "UMG/Components/KGLine.h"

namespace KGUI
{
	struct FKGIntermediateBezierPoint
	{
		double PointX;
		double PointY;
		double ControlX;
		double ControlY;
	};
	KGUI_API void ConvertOperationalProperty(const FKGIntermediateBezierPoint& In, FKGBezierPoint& Out);
	KGUI_API void ConvertOperationalProperty(const FKGBezierPoint& In, FKGIntermediateBezierPoint& Out);

	using FKGBezierPointPropertyTraits = UE::MovieScene::TIndirectPropertyTraits<FKGBezierPoint, FKGIntermediateBezierPoint>;

	struct FKGSequencerComponentTypes
	{
		KGUI_API ~FKGSequencerComponentTypes();

		UE::MovieScene::TPropertyComponents<FKGBezierPointPropertyTraits> BezierPoint;
		UE::MovieScene::TCustomPropertyRegistration<FKGBezierPointPropertyTraits, KGLINE_MAX_POINTS> CustomBezierPointAccessors;

		static KGUI_API void Destroy();
		static KGUI_API FKGSequencerComponentTypes* Get();

	private:
		FKGSequencerComponentTypes();
	};
} // namespace KGUI
