﻿#pragma once

#include "KGNiagaraUIParameterSectionTemplate.h"
#include "Channels/MovieSceneFloatChannel.h"
#include "KGNiagaraUIColorParameterSectionTemplate.generated.h"

struct FNiagaraVariable;
struct FNiagaraVariableBase;

USTRUCT()
struct FKGNiagaraUIColorParameterSectionTemplate : public FKGNiagaraUIParameterSectionTemplate
{
	GENERATED_BODY()

public:
	FKGNiagaraUIColorParameterSectionTemplate();

	FKGNiagaraUIColorParameterSectionTemplate(FNiagaraVariable InParameter,
		const FMovieSceneFloatChannel& InRedChannel, const FMovieSceneFloatChannel& InGreenChannel, const FMovieSceneFloatChannel& InBlueChannel, const FMovieSceneFloatChannel& InAlphaChannel);

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }

protected:
	virtual void GetAnimatedParameterValue(FFrameTime InTime, const FNiagaraVariableBase& InTargetParameter, const TArray<uint8>& InCurrentValueData, TArray<uint8>& OutAnimatedValueData) const override;

private:
	UPROPERTY()
	FMovieSceneFloatChannel RedChannel;

	UPROPERTY()
	FMovieSceneFloatChannel GreenChannel;

	UPROPERTY()
	FMovieSceneFloatChannel BlueChannel;

	UPROPERTY()
	FMovieSceneFloatChannel AlphaChannel;
};

