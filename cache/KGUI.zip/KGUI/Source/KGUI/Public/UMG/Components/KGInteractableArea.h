// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KGUISettings.h"
#include "Animation/AnimCurveTypes.h"
#include "Components/CanvasPanel.h"
#include "KGInteractableArea.generated.h"

UENUM(BlueprintType)
enum class EKGInteractableAnimState : uint8
{
	Normal = 0,
	Hovered = 1,
	Unhovered = 2,
	Pressed = 3,
	Released = 4
};

enum class EKGInteractableAnimBreakMode : uint8
{
	SetValue = 0,
	PlayAnimRightNow = 1,
	PlayAnimAfterSkipToEnd = 2
};

UENUM(BlueprintType)
enum class EKGInteractableAnimType : uint8
{
	None = 0,
	Curve = 1,
	Anim = 2,
};


USTRUCT(BlueprintType)
struct FKGWidgetName
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere)
	FName Name;

	bool IsEmpty() const
	{
		return !Name.IsValid() || Name.IsNone();
	}


	bool operator==(const FKGWidgetName &other) const
	{
		return Name == other.Name;
	}

	FKGWidgetName& operator=(const FString& InContent)
	{
		Name = *InContent;
		return *this;
	}
};

USTRUCT(BlueprintType)
struct FKGAnimName
{
	GENERATED_BODY()

	UPROPERTY()
	FName Name;

	bool IsEmpty() const
	{
		return !Name.IsValid() || Name.IsNone();
	}

	bool operator==(const FKGAnimName& other) const
	{
		return Name == other.Name;
	}

	FKGAnimName& operator=(const FString& InContent)
	{
		Name = *InContent;
		return *this;
	}
};

USTRUCT(BlueprintType)
struct FKGInteractableCurveAnimParams
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	int32 ExpansionSize = 0;

	UPROPERTY(EditAnywhere)
	class UCurveFloat* ScaleCurve = nullptr;

	UPROPERTY(EditAnywhere)
	float Opacity = 1.f;

	UPROPERTY(EditAnywhere)
	class UCurveFloat* OpacityCurve = nullptr;

	UPROPERTY(EditAnywhere)
	float Duration = 0.1f;
};

USTRUCT(BlueprintType)
struct FKGInteractableAnimParams
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	bool bEnable = true;

	UPROPERTY(EditAnywhere)
	EKGInteractableAnimType AnimType = EKGInteractableAnimType::Curve;

	UPROPERTY(EditAnywhere, Category = "Curve", meta = (EditCondition = "AnimType == EKGInteractableAnimType::Curve"))
	FKGInteractableCurveAnimParams CurveAnim;
	
	UPROPERTY(EditAnywhere, Category = "Animation", meta = (EditCondition = "AnimType == EKGInteractableAnimType::Anim"))
	FKGAnimName ActiveAnim;

	UPROPERTY(EditAnywhere, Category = "Animation", meta = (EditCondition = "AnimType == EKGInteractableAnimType::Anim"))
	FKGAnimName DeactiveAnim;

	FKGInteractableAnimParams() = default;
	FKGInteractableAnimParams(bool bInEnable, EKGInteractableAnimType InType) : bEnable(bInEnable), AnimType(InType)
	{
	}

	static FKGInteractableAnimParams Null;
	static bool IsNull(const FKGInteractableAnimParams& CurveSet);
};

USTRUCT(BlueprintType)
struct FKGHoverPressAnim
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	bool bEnable = true;

	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnable"))
	FKGInteractableAnimParams Hovered;

	UPROPERTY(EditAnywhere, meta = (EditCondition = "bEnable"))
	FKGInteractableAnimParams Pressed;

	UPROPERTY(EditAnywhere)
	TArray<FKGWidgetName> VisualWidgetNames;
};

class FKGInteractableAnimHandlerBase
{
public:
	virtual ~FKGInteractableAnimHandlerBase() = default;
	void Initialize(UWidget* InOwnerWidget,UUserWidget* InUserWidget, const TArray<FKGWidgetName>& InVisualWidgetNames)
	{
		OwnerWidget = InOwnerWidget;
		TargetUserWidget = InUserWidget;
		OnInitialize(InOwnerWidget, InUserWidget, InVisualWidgetNames);
	}

	virtual void OnInitialize(UWidget* InWidget, UUserWidget* InUserWidget, const TArray<FKGWidgetName>& InVisualWidgetNames) = 0;
	virtual FKGInteractableAnimHandlerBase& SetStartScale(const FVector2D& InScale) = 0;
	virtual FKGInteractableAnimHandlerBase& SetEndScale(const FVector2D& InScale) = 0;
	virtual FKGInteractableAnimHandlerBase& SetStartOpacity(float InOpactiy) = 0;
	virtual FKGInteractableAnimHandlerBase& SetEndOpacity(float InOpactiy) = 0;
	virtual void Play() = 0;
	virtual void Tick(float DeltaTime) = 0;
    virtual void PostTick(float DeltaTime) {}
	virtual void Reset() = 0;
	virtual bool IsDone() const = 0;

	EKGInteractableAnimType GetHandlerType() const { return Type; }

protected:
	EKGInteractableAnimType Type = EKGInteractableAnimType::None;
	TWeakObjectPtr<UUserWidget> TargetUserWidget;
	TWeakObjectPtr<UWidget> OwnerWidget;
};

class FKGInteractableArea : public TSharedFromThis<FKGInteractableArea>
{
public:
	explicit FKGInteractableArea(UWidget* InOwnerWidget, const FKGHoverPressAnim& InAnimParams);
	virtual ~FKGInteractableArea();
	
	void OnHovered();
	void OnUnhovered();
	void OnPressed();
	void OnReleased();

	void OnWidgetRebuild();
	void OnReleaseSlateResources();
protected:
	void OnSlatePreTick(float InDeltaTime);
	void OnSlatePostTick(float InDeltaTime);


	void FindUserWidget();
	UWidget* GetWidget() const;

	void InitializeHandlers();
	void TransitionState(EKGInteractableAnimState NewState);
	double GetExpansionScale(int32 InExpsionSize);
private:
	TWeakObjectPtr<UWidget> OwnerWidget;
	TWeakObjectPtr <class UUserWidget> OwnerUserWidget;
	FKGHoverPressAnim AnimParams;
	EKGInteractableAnimState CurState = EKGInteractableAnimState::Normal;
	bool bPlayingAnim = false;
	TMap<EKGInteractableAnimState, TUniquePtr<FKGInteractableAnimHandlerBase>> AnimationHandlers;
};
