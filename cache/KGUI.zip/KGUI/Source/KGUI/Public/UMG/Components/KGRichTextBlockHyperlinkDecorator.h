// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Text/ITextDecorator.h"
#include "Components/RichTextBlockDecorator.h"
#include "Engine/DataTable.h"
#include "Components/RichTextBlock.h"
#include "UMG/Components/KGRichTextBlock.h"
#include "UMG/Components/KGRichTextBlockImageDecorator.h"
#include "KGRichTextBlockHyperlinkDecorator.generated.h" 

DECLARE_DYNAMIC_DELEGATE_FourParams(FOnUrlClicked, FString, Url, int32, BeginIndex, int32, EndIndex, FVector2D, ClickPosition);

UCLASS()
class UKGRichTextBlockHyperlinkDecorator : public URichTextBlockDecorator, public IKGRichTextBlockDecoratorResourceReferencerInterface
{
	GENERATED_BODY()

public:
	UKGRichTextBlockHyperlinkDecorator(const FObjectInitializer& ObjectInitializer);
	
	virtual TSharedPtr<ITextDecorator> CreateDecorator(URichTextBlock* InOwner) override;
	
	FString GetColorTableDir();

	void SetTextSet(UDataTable* InTextSet);

	void SetColorDir(FString InColorTableDir); 
	// void textFun(FTextRange testRange);

	UFUNCTION(BlueprintNativeEvent)
	void ClickFun(const FString& Url, const int32 BeginIndex, const int32 EndIndex, const FVector2D ClickPosition);

	UPROPERTY()
	FOnUrlClicked OnUrlClicked;

	TMap<EC7BrushType, FString> TypeTagMap;

	void SetRichImageDataTables(const TArray<TObjectPtr<UDataTable>>& InRichImageDataTables);

	virtual void ClearResourceReferences() override;

	FKGRichTextBlockDecoratorSlateBrushGenerator& GetSlateBrushGenerator() { return SlateBrushGenerator; }

protected:
	TWeakObjectPtr<UKGRichTextBlock> RichTextBlock;

	UPROPERTY(Transient)
	class UDataTable* TextSet;

	UPROPERTY(Transient)
	FString ColorTableDir;

	UPROPERTY(Transient)
	TArray<TObjectPtr<UDataTable>> RichImageDataTables;

	UPROPERTY(Transient)
	FKGRichTextBlockDecoratorSlateBrushGenerator SlateBrushGenerator;
};

