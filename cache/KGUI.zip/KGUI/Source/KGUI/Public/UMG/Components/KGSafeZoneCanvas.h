// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Components/CanvasPanel.h"
#include "UMG/Slate/SKGSafeZoneConstraintCanvas.h"
#include "Components/CanvasPanelSlot.h"
#include "KGSafeZoneCanvas.generated.h"

/**
 * 
 */
UCLASS()
class KGUI_API UKGSafeZoneCanvas : public UCanvasPanel
{
	GENERATED_BODY()

public:

	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	virtual void SynchronizeProperties() override;

	UFUNCTION(BlueprintCallable, Category = "KGSafeZoneCanvas")
	void SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom);

#if WITH_EDITOR
	virtual void OnDesignerChanged(const FDesignerChangedEventArgs& EventArgs) override;
#endif

	void UpdateWidgetProperties();
	
	/** If this safe zone should pad for the left side of the screen's safe zone */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category = "KGSafeZoneCanvas")
	bool PadLeft = true;
	
	/** If this safe zone should pad for the right side of the screen's safe zone */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category = "KGSafeZoneCanvas")
	bool PadRight = true;
	
	/** If this safe zone should pad for the top side of the screen's safe zone */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category = "KGSafeZoneCanvas")
	bool PadTop = true;
	
	/** If this safe zone should pad for the bottom side of the screen's safe zone */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category = "KGSafeZoneCanvas")
	bool PadBottom = true;

protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;

	void SetPadLeft(bool InPadLeft);
	bool GetPadLeft() const;

	void SetPadRight(bool InPadRight);
	bool GetPadRight() const;

	void SetPadTop(bool InPadTop);
	bool GetPadTop() const;

	void SetPadBottom(bool InPadBottom);
	bool GetPadBottom() const;

	TSharedPtr< class SKGSafeZoneConstraintCanvas> MyCanvas;

#if WITH_EDITOR
	TOptional<FVector2D> DesignerSize;
	TOptional<float> DesignerDpi;
#endif
};
