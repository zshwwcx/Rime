#pragma once

#include "CoreMinimal.h"
#include "UObject/UObjectGlobals.h"
#include "UObject/ObjectMacros.h"
#include "Misc/Attribute.h"
#include "Styling/SlateBrush.h"
#include "Components/Widget.h"
#include "KGLine.generated.h"

class SKGLine;
#define KGLINE_MAX_POINTS 4

/**
 * 一个端点结构，包含位置以及控制点参数
 */
USTRUCT(BlueprintType)
struct KGUI_API FKGBezierPoint
{
    GENERATED_BODY()

    /** 端点位置 */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoint", meta=(Interp))
	FVector2f Position;

    /** 控制点位置 */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoint", meta = (Interp))
	FVector2f ControlPoint;

    /** 该点在整个曲线上的UV坐标 (范围 [0,1]) */
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "KGUI|BezierPoint")
    float UV;

    FKGBezierPoint()
        : Position(FVector2f::ZeroVector)
        , ControlPoint(FVector2f(25.0f, 25.0f))
        , UV(0.0f)
    {
    }

    FKGBezierPoint(const FVector2f& InPosition)
        : Position(InPosition)
		, ControlPoint(FVector2f(25.0f, 25.0f))
        , UV(0.0f)
    {
    }

    FKGBezierPoint(const FVector2f& InPosition, const FVector2f& InControlPoint, float InUV)
        : Position(InPosition)
        , ControlPoint(InControlPoint)
        , UV(InUV)
    {
    }
};

/**
 * 可视化编辑的贝塞尔曲线连接控件，支持多个端点、控制点和各种连接方式
 * WARN：未支持（主要是顶点运行时可能被动效控制）Size跟随所有子节点覆盖的区域自动计算
 */
UCLASS(DisplayName = "Line (KGUI)", meta = (ToolTip = "线条"))
class KGUI_API UKGLine : public UWidget
{
    GENERATED_UCLASS_BODY()

public:
    /** 端点列表 */
    //UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoints", meta=(TitleProperty="Position", Interp))
    //TArray<FKGBezierPoint> Points;

	/** 由于使用TArray<>在UMG动画当中不好支持（需要自定义System、Token、Section以及自定义Evaluate全过程）
	 * 太费劲了，所以简单改成离散的4个点来支持，如果有更多需要再说
	 * 注意：要与KGLINE_MAX_POINTS的点数量匹配
	 */
	UPROPERTY(Interp, EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoints", meta = (TitleProperty = "Points1"))
	FKGBezierPoint Point1;
	UPROPERTY(Interp, EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoints", meta = (TitleProperty = "Points2"))
	FKGBezierPoint Point2;
	UPROPERTY(Interp, EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoints", meta = (TitleProperty = "Points3"))
	FKGBezierPoint Point3;
	UPROPERTY(Interp, EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoints", meta = (TitleProperty = "Points4"))
	FKGBezierPoint Point4;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoints")
	int32 PointCount;

    /** 是否使用贝塞尔曲线控制点 */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoints")
    bool bUseBezierControl;

    /** 默认线条粗细 */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoints")
    float DefaultLineThickness;

    /** 贝塞尔线渲染材质 */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "KGUI|BezierPoints")
    FSlateBrush LineMaterial;

protected:
    // Slate实现
    TSharedPtr<SKGLine> BezierPointsWidget;

	// 缓存的顶点，方便处理（如果这块内存太多了，到时候Profile下？）
	TArray<FKGBezierPoint> CachedPoints;
	//TStaticArray<FKGBezierPoint, KGLINE_MAX_POINTS> StaticPoints;

    // UWidget接口
    virtual TSharedRef<SWidget> RebuildWidget() override;
    virtual void ReleaseSlateResources(bool bReleaseChildren) override;
    virtual void SynchronizeProperties() override;

	void SyncCachedPoints();
	int32 AddPointInternal(const FVector2f& Position);
	bool RemovePointInternal(int32 PointIndex);
    
public:
	virtual void PostLoad() override;
	virtual void PostInitProperties() override;

#if WITH_EDITOR
	virtual void OnCreationFromPalette() override;
	virtual const FText GetPaletteCategory() override;
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	// 用于Editor Designer编辑
	int32 AddPointEditor(const FVector2f& Position);
	void RemovePointEditor(int32 PointIndex);
	void ConfigureSlotProperties();
#endif

	// WARN：注意下面修改Point顶点的API在runtime过程中调用时，要考虑对Animation动画的影响
	//	- 如：可能在Animation中K帧控制了，那么可能导致奇奇怪怪的效果；需要在制作之前明确要么代码控制&要么动画控制
    /** 添加一个新点 */
    UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
    int32 AddPoint(const FVector2f& Position);

	UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
	int32 GetPointCount() const { return PointCount; }

    /** 移除指定索引的端点 */
    UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
    bool RemovePoint(int32 PointIndex);

    /** 更新端点位置 */
    UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
    bool UpdatePoint(int32 PointIndex, const FVector2f& NewPosition);
	UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
	bool MovePoint(int32 PointIndex, const FVector2f& Delta);

    /** 更新端点贝塞尔控制参数 */
	UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
	bool UpdateControl(int32 PointIndex, const FVector2f& ControlPoint);
	UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
	bool MoveControl(int32 PointIndex, const FVector2f& Delta);

    /** 更新所有点的UV值 */
    UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
    void UpdatePointsUV();

    /** 清除所有点 */
    UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
    void ClearAll();

    /** 设置线条材质 */
    UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
    void SetLineMaterial(const FSlateBrush& InLineMaterial);
    
    /** 获取曲线粗细 */
    UFUNCTION(BlueprintCallable, Category = "KGUI|BezierPoints")
    float GetCurveThickness() const { return DefaultLineThickness; }
    
    /** 获取贝塞尔点数组 */
    const TArray<FKGBezierPoint>& GetCachedBezierPoints() const { return CachedPoints; }

	bool IsValidIndex(int32 PointIndex) const;

	// Sequencer Support
	void SetBezierPoint(int32 PointIndex, const FKGBezierPoint& InPoint);
	FKGBezierPoint GetBezierPoint(int32 PointIndex) const;
}; 