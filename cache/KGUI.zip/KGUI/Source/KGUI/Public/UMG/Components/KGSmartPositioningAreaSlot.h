#pragma once

#include "CoreMinimal.h"
#include "Components/ContentWidget.h"

#include "KGSmartPositioningAreaSlot.generated.h"

class SKGSmartPositioningArea;

UCLASS(MinimalAPI)
class UKGSmartPositioningAreaSlot : public UPanelSlot
{
	GENERATED_BODY()

public:
	KGUI_API virtual void SynchronizeProperties() override;
	KGUI_API void BuildSlot(TSharedRef<SKGSmartPositioningArea> InSmartPositioningArea);
	KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;

private:
	TWeakPtr<SKGSmartPositioningArea> SmartPositioningArea;
};
