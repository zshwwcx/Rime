// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/HorizontalBox.h"
#include "KGHorizontalBox.generated.h"

/**
 * 
 */
UCLASS(DisplayName = "Horizontal Box (KGUI)", meta = (ToolTip = "水平框"))
class KGUI_API UKGHorizontalBox : public UHorizontalBox
{
	GENERATED_BODY()
	virtual void OnSlotInserted(int32 Index, UPanelSlot* InSlot) override;
	virtual void OnSlotMoved(int32 Index1, int32 Index2) override;
#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif
	
};
