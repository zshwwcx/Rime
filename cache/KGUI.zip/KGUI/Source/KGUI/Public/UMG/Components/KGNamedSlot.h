// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/NamedSlot.h"
#include "KGNamedSlot.generated.h"

/**
 * 
 */
UCLASS(DisplayName = "Named Slot (KGUI)", meta = (ToolTip = "命名插槽"))
class KGUI_API UKGNamedSlot : public UNamedSlot
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif
	
};
