// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/SafeZone.h"
#include "UKGSafeZone.generated.h"

/**
 * 
 */
UCLASS()
class KGUI_API UUKGSafeZone : public USafeZone
{
	GENERATED_BODY()
};
