#pragma once

#include "Components/Widget.h"
#include "CoreMinimal.h"
#include "KGMeshWidget.generated.h"

UCLASS(DisplayName = "Mesh Widget (KGUI)", meta = (ToolTip = "模型"))
class KGUI_API UKGMeshWidget : public UWidget
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif
	
public:
	// 提供直接挂载StaticMesh的插槽
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "UIMesh")
	UStaticMesh* MeshAsset;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "UIMesh")
	FSlateBrush Brush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category = "UIMesh")
	FTransform MeshTransform;

	/** 旋转点中心,默认为0,0,0 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category = "UIMesh")
	FVector MeshPivot = FVector::ZeroVector;

	/** 骰子功能,播放sequence时,需要叠加一个额外的transform,但不影响到Sequence里k的transform.*/
	UPROPERTY()
	FQuat MeshOverlayRotator = FQuat::Identity;

	UPROPERTY()
	FTransform FinalMeshTransform = FTransform::Identity;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UIMesh")
	FMinimalViewInfo VirtualCamera;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category = "UIMesh", meta=( sRGB="true"))
	FLinearColor ColorAndOpacity;
	
public:
	UKGMeshWidget(const FObjectInitializer& ObjectInitializer);

	virtual void SynchronizeProperties() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	UFUNCTION(BlueprintCallable, Category = "UIMesh")
	const FTransform& GetMeshTransform() const;
	UFUNCTION(BlueprintCallable, Category = "UIMesh")
	void SetMeshTransform(FTransform InTransform);

	UFUNCTION(BlueprintCallable, Category = "UIMesh")
	const FTransform& GetFinalMeshTransform() const;

	UFUNCTION(BlueprintCallable, Category = "UIMesh")
	void SetMeshOverlayRotator(FQuat InRotator);

	UFUNCTION(BlueprintCallable, Category="UIMesh")
	void SetColorAndOpacity(FLinearColor InColorAndOpacity);

	UFUNCTION(BlueprintCallable, Category = "UIMesh")
	void SetMaterial(UMaterialInterface* Material);

	UFUNCTION(BlueprintCallable, Category = "UIMesh")
	void SetMeshPivot(FVector InPivot);

	UFUNCTION(BlueprintCallable, Category = "UIMesh")
	const FVector& GetMeshPivot() const;

	UFUNCTION(BlueprintCallable, Category = "UIMesh")
	class UMaterialInstanceDynamic* GetDynamicMaterial();

	UFUNCTION(BlueprintCallable, Category="UIMesh")
	const FLinearColor& GetColorAndOpacity() const;
	
	UFUNCTION(BlueprintCallable, Category = "UIMesh")
	void CalculateFinalTransform();

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	void OnObjectReimported(UObject* ReimportedObject);

	static void GetAllMeshWidgets(TArray<TWeakObjectPtr<UKGMeshWidget>>& OutMeshWidgets);
#endif

protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;
	void UpdateMaterial();

private:
	TSharedPtr<class SKGMeshWidget> MyMeshWidget;
	friend class SKGMeshWidget;

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, Category = "UIMesh")
	FRotator Rotator;
	
	static TArray<TWeakObjectPtr<UKGMeshWidget>> AllMeshWidgets;
#endif

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInterface> RuntimeMaterial;
};
