// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KGRichTextBlockDecoratorResourceReferencerInterface.h"
#include "KGRichTextBlockDecoratorSlateBrushGenerator.h"
#include "Components/RichTextBlockImageDecorator.h"

#include "KGRichTextBlockImageDecorator.generated.h"


enum class EC7BrushType : uint8
{
	Texture2D,
	Sprite,
	Material
};

UCLASS()
class KGUI_API UKGRichTextBlockImageDecorator : public URichTextBlockDecorator, public IKGRichTextBlockDecoratorResourceReferencerInterface
{
	GENERATED_BODY()
public:
	UKGRichTextBlockImageDecorator(const FObjectInitializer& ObjectInitializer);
	
	virtual TSharedPtr<ITextDecorator> CreateDecorator(URichTextBlock* InOwner) override;

	TMap<EC7BrushType,FString> TypeTagMap;

	void SetRichImageDataTables(const TArray<TObjectPtr<UDataTable>>& RichImageDataTables);

	virtual void ClearResourceReferences() override;

	FKGRichTextBlockDecoratorSlateBrushGenerator& GetSlateBrushGenerator() { return SlateBrushGenerator; }

protected:
	UPROPERTY(Transient)
	TArray<TObjectPtr<UDataTable>> RichImageDataTables;

	UPROPERTY(Transient)
	FKGRichTextBlockDecoratorSlateBrushGenerator SlateBrushGenerator;
};
