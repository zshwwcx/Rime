#pragma once

#include "UObject/SoftObjectPtr.h"

struct FStreamableHandle;

class FKGTextureLoader : public TSharedFromThis<FKGTextureLoader>
{
public:
	DECLARE_DELEGATE(FOnTextureLoadCompleted)
	DECLARE_DELEGATE(FOnTextureLoadCancelled)

	virtual ~FKGTextureLoader();

	void RequestAsyncLoad(TSoftObjectPtr<UObject> SoftObject, FOnTextureLoadCompleted&& InOnLoadCompleted, FOnTextureLoadCancelled&& InOnLoadCancelled);

	void CancelStreaming();
	void ReleaseStreaming();

private:
	FOnTextureLoadCompleted OnLoadCompleted;
	FOnTextureLoadCancelled OnLoadCancelled;

	TSharedPtr<FStreamableHandle> StreamingHandle;
	FSoftObjectPath StreamingObjectPath;
};
