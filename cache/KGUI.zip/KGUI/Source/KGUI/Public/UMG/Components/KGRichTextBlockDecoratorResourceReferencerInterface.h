#pragma once

#include "UObject/Interface.h"
#include "UObject/ObjectMacros.h"

#include "KGRichTextBlockDecoratorResourceReferencerInterface.generated.h"

UINTERFACE(MinimalAPI)
class UKGRichTextBlockDecoratorResourceReferencerInterface : public UInterface
{
	GENERATED_BODY()
};

class KGUI_API IKGRichTextBlockDecoratorResourceReferencerInterface
{
	GENERATED_BODY()

public:
	virtual void ClearResourceReferences() = 0;
};