#pragma once

#include "CoreMinimal.h"
#include "UMG/Components/KGEditableTextBox.h"
#include "UMG/Components/KGMultiLineEditableText.h"

#include "KGMultiLineEditableRichText.generated.h"

class UKGRichTextBlock;
class URichTextBlock;
class UDataTable;
class URichTextBlockDecorator;

USTRUCT(BlueprintType)
struct FKGTextLocation
{
	GENERATED_BODY()

	FKGTextLocation()
	{
		LineIndex = -1;
		Offset = -1;
	}

	FKGTextLocation(const FTextLocation& InTextLocation)
	{
		LineIndex = InTextLocation.GetLineIndex();
		Offset = InTextLocation.GetOffset();
	}

	UPROPERTY()
	int32 LineIndex;

	UPROPERTY()
	int32 Offset;

	FTextLocation ToTextLocation() const
	{
		return FTextLocation(LineIndex, Offset);
	}
};

USTRUCT(BlueprintType)
struct FKGRunInfo
{
	GENERATED_BODY()

	FKGRunInfo()
	{
	}

	explicit FKGRunInfo(const FRunInfo& InRunInfo)
		: Name(InRunInfo.Name)
		, MetaData(InRunInfo.MetaData)

	{
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<FString, FString> MetaData;

	FRunInfo ToRunInfo() const
	{
		auto RunInfo = FRunInfo();
		RunInfo.Name = Name;
		RunInfo.MetaData = MetaData;
		return RunInfo;
	}
};

UCLASS(DisplayName = "MultiLine Editable Rich Text (KGUI)", meta = (ToolTip = "富文本输入框 (多行)"))
class KGUI_API UKGMultiLineEditableRichText : public UKGMultiLineEditableText
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI.Experimental")); }
#endif

	UKGMultiLineEditableRichText(const FObjectInitializer& ObjectInitializer);

	//~ Begin UWidget Interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	// End of UWidget

public:
	UFUNCTION(BlueprintCallable)
	void SetRichTextBlock(UKGRichTextBlock* InRichTextBlock);

	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FKGRunInfo, FRunInfoEditCallback, const FKGRunInfo&, OriginalRunInfo, const FKGRunInfo&, NewRunInfo);
	DECLARE_DYNAMIC_DELEGATE_RetVal_OneParam(FKGRunInfo, FRunInfoNormalizeCallback, const FKGRunInfo&, OriginalRunInfo);
	FString GetTextInternal(bool bWithSelectionRunInfoEditing, const FString& RunInfoName, const TMap<FString, FString>& RunInfoMetaData, FRunInfoEditCallback EditCallback, FRunInfoNormalizeCallback NormalizeCallback) const;

	UFUNCTION(BlueprintCallable)
	FString GetTextWithSelectionRunInfoEditing(FString RunInfoName, TMap<FString, FString> RunInfoMetaData, FRunInfoEditCallback EditCallback) const;

	UFUNCTION(BlueprintCallable)
	FString GetNormalizedText(FRunInfoNormalizeCallback NormalizeCallback) const;

	UFUNCTION(BlueprintCallable)
	void SelectText(const FKGTextLocation& InSelectionStart, const FKGTextLocation& InCursorLocation);

	UFUNCTION(BlueprintCallable)
	FKGTextLocation GetSelectionBeginning() const;

	UFUNCTION(BlueprintCallable)
	FKGTextLocation GetSelectionEnd() const;

protected:

	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnKeyDownEvent, FGeometry, MyGeometry, FKeyEvent, InKeyEvent);

	UPROPERTY(EditAnywhere, Category = Events, meta = (IsBindableEvent))
	FOnKeyDownEvent OnKeyDown;

	TSharedRef<FSlateTextLayout> HandleOnCreateSlateTextLayout(SWidget* InOwningWidget, const FTextBlockStyle& InDefaultTextStyle);
	FReply HandleOnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent);

	UPROPERTY(Transient)
	TObjectPtr<UKGRichTextBlock> RichTextBlock;

	UPROPERTY(Transient)
	TArray<TObjectPtr<URichTextBlockDecorator>> InstanceDecorators;

	UPROPERTY(Transient)
	FTextBlockStyle RichTextBlockWidgetStyle;

	TSharedPtr<SBox> Box;

	TSharedPtr<FSlateTextLayout> TextLayout;
};