// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/InvalidationBox.h"
#include "KGInvalidationBox.generated.h"

/**
 * 
 */
UCLASS(DisplayName = "Invalidation Box (KGUI)")
class KGUI_API UKGInvalidationBox : public UInvalidationBox
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif

public:
	UFUNCTION(BlueprintCallable)
	void SetNeedsSlowPath(bool bNeedsSlowPath);

protected:
	//~ Begin UWidget interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	//~ End UWidget interface
};
