﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Text/ITextDecorator.h"
#include "Components/RichTextBlockDecorator.h"
#include "Engine/DataTable.h"
#include "Components/RichTextBlock.h"
#include "KGRichTextBlockTextDecorator.generated.h"



/**
 * 
 */
UCLASS()
class UKGRichTextBlockTextDecorator : public URichTextBlockDecorator
{
	GENERATED_BODY()
public:
	UKGRichTextBlockTextDecorator(const FObjectInitializer& ObjectInitializer);
	
	virtual TSharedPtr<ITextDecorator> CreateDecorator(URichTextBlock* InOwner) override;
	
	FString GetColorTableDir();

	void SetTextSet(UDataTable* InTextSet);

	void SetColorDir(FString InColorTableDir);

protected:
	UPROPERTY(EditAnywhere, Category=Appearance, meta = (RequiredAssetDataTags = "RowStructure=RichTextStyleRow"))
	class UDataTable* TextSet;

	UPROPERTY(EditAnywhere, Category=Appearance)
	FString ColorTableDir;
	
};

