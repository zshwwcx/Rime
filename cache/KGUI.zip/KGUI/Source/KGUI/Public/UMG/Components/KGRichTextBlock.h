// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KGTextBlock.h"
#include "Components/RichTextBlock.h"
#include "Styling/SlateStyle.h"

#include "UMG/Components/KGRichTextLayoutMarshaller.h"
#include "Slate/Text/SKGRichTextBlock.h"

#include "KGRichTextBlock.generated.h"

class UKGRichTextBlockTextDecorator;
class UKGRichTextBlockImageDecorator;
class UKGRichTextBlockHyperlinkDecorator;

DECLARE_DYNAMIC_DELEGATE_FourParams(FOnRichTextHyperlinkClicked, FString, Url, int32, BeginIndex, int32, EndIndex, FVector2D, ClickPosition);
/**
 * 
 */
 //@C7 Code Begin(@pengwei03)
//富文本自动分页--自定义数据结构
//分页数据
USTRUCT(BlueprintType)
struct FKGRichTextBlockPageData {
	GENERATED_USTRUCT_BODY()
	FKGRichTextBlockPageData():
	BeginIndex(0),
	EndIndex(0)
	{ }

	UPROPERTY(BlueprintReadOnly)
	int32 BeginIndex = 0;
	UPROPERTY(BlueprintReadOnly)
	int32 EndIndex = 0;
	UPROPERTY(BlueprintReadOnly)
	FString StartAdd;
	UPROPERTY(BlueprintReadOnly)
	FString EndAdd;
};
//@C7 Code End (@pengwei03)

UCLASS(DisplayName = "Rich Text Block (KGUI)", meta = (ToolTip = "富文本"), PrioritizeCategories = "Layout Componentization Accessibility Appearance")
class KGUI_API UKGRichTextBlock : public URichTextBlock, public IKGTextCountDown
{
	GENERATED_BODY()

	friend class FKGRichTextBlockCustomization;

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
	virtual void OnCreationFromPalette() override;
#endif

public: // ADD BY lishihao07@kuaishou.com: GPUTurbo RichTextBlock
	UKGRichTextBlock(const FObjectInitializer& ObjectInitializer);

	TSharedPtr<class FSlateStyleSet> GetStyleInstanceInternal() const { return StyleInstance; }
	void CreateDecoratorsInternal(TArray<TSharedRef<class ITextDecorator>>& OutDecorators)
	{
		CreateDecorators(OutDecorators);
	}

	const auto& GetInstanceDecorators() const { return InstanceDecorators; }
	const auto& GetDecoratorClasses() const { return DecoratorClasses; }

	static UKGRichTextBlockTextDecorator* CreateRichTextBlockTextDecorator(UObject* Outer);
	static UKGRichTextBlockImageDecorator* CreateRichTextBlockImageDecorator(UObject* Outer, const TArray<TObjectPtr<UDataTable>>& RichImageDataTables);
	static UKGRichTextBlockHyperlinkDecorator* CreateRichTextBlockHyperlinkDecorator(UObject* Outer, const TArray<TObjectPtr<UDataTable>>& RichImageDataTables);
	static TArray<TObjectPtr<UDataTable>> GetRichImageDataTables(UKGRichTextBlock* RichTextBlock);

	virtual void SetText(const FText& InText) override;

protected: // ADD BY lishihao07@kuaishou.com: GPUTurbo RichTextBlock
	virtual void UpdateStyleData() override;

private: // ADD BY lishihao07@kuaishou.com: GPUTurbo RichTextBlock
	virtual void AddDefaultDecorators();

	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	virtual TSharedRef<SWidget> RebuildWidget() override;

	//Modify By Bruce Start 2023.8.28
	/**
	* Sets Letter Spacing
	* @param InLetterSpacing		The new Letter Spacing
	*/
	UFUNCTION(BlueprintCallable, Category = "Appearance")
	void SetLatterSpaceAnim(float InLetterSpacing);
	//Modify By Bruce End 2023.8.28

	UFUNCTION(BlueprintCallable)
	bool GetRunLocationAndSize(const FString& Content, FVector2D& Location, FVector2D& Size);

	UFUNCTION(BlueprintCallable)
	bool GetRunLocationAndSizeByRange(const int32 BeginIndex, const int32 EndIndex, FVector2D& Location, FVector2D& Size, bool bLimitByClickPosition = false, FVector2D LimitPosition = FVector2D(0,0));

protected:
	virtual void RebuildStyleInstance() override;
	void HandleOnRebuildDecoratorStyleSet();

	template <typename SlateWidgetType = SKGRichTextBlock>
	auto RebuildWidgetInternal(const ANSICHAR* SlateWidgetTypeName)
	{
		static_assert(TIsDerivedFrom<SlateWidgetType, SKGRichTextBlock>::Value);
		UpdateStyleData();

		TArray<TSharedRef<class ITextDecorator>> CreatedDecorators;
		CreateDecorators(CreatedDecorators);

		auto Marshaller = FKGRichTextLayoutMarshaller::Create(CreateMarkupParser(), CreateMarkupWriter(), CreatedDecorators, StyleInstance.Get());

		TArray<TWeakObjectPtr<URichTextBlockDecorator>> WeakInstanceDecorators;
		for (const auto& InstanceDecorator : InstanceDecorators)
		{
			WeakInstanceDecorators.Add(InstanceDecorator);
		}
		Marshaller->SetInstanceDecorators(WeakInstanceDecorators);

		PRAGMA_DISABLE_DEPRECATION_WARNINGS
		auto RichTextBlock =
			SNew_WithTypeName(SlateWidgetType, SlateWidgetTypeName)
	        .Text(GetText())
			.TextStyle(bOverrideDefaultStyle ? &DefaultTextStyleOverride : &DefaultTextStyle)
			.Marshaller(Marshaller)
			.UseRichFormatting(bUseRichFormatting);  // ADD BY wuzhiwei05@kuaishou.com: Switch for whether enable the rich text feature
		PRAGMA_ENABLE_DEPRECATION_WARNINGS
		MyRichTextBlock = RichTextBlock;

		RichTextBlock->SetOnRebuildDecoratorStyleSet(SKGRichTextBlock::FOnRebuildDecoratorStyleSet::CreateUObject(this, &UKGRichTextBlock::HandleOnRebuildDecoratorStyleSet));

		return MyRichTextBlock.ToSharedRef();
	}

	virtual void ApplyUpdatedDefaultTextStyle() override;

public:
	TArray<UDataTable*> GetTextStyleSetArray();

	/** Text style to apply by default to text in this block */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetDefaultRowName", Category = RichFormatting, meta=(DesignerRebuild, EditCondition="!bOverrideDefaultStyle&&bUseRichFormatting", EditConditionHides))
	FName DefaultRowName = "Default";

	UFUNCTION(BlueprintCallable, Category = "RichFormatting")
	void SetDefaultRowName(FName RowName);

	UFUNCTION(BlueprintCallable, Category = "RichFormatting")
	FName GetDefaultRowName() const
	{
		return DefaultRowName;
	}

	//Whether to use multiple text styles for the text in this block
	UPROPERTY(EditAnywhere, Category = RichFormatting, meta = (EditCondition = bUseRichFormatting, EditConditionHides), DisplayName="Use Multiple Text Style Set")
	bool bUseMultiTextStyle = false;
	
	//@C7 Code Begin(@pengwei03)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetAlwaysEllipsis", Category = "Clipping", AdvancedDisplay)
	uint8 AlwaysEllipsis : 1;
	//RichTextBlock AutoPaging,Max height for per page
	UPROPERTY(EditAnywhere, Category = "Wrapping")
	int32 MaxWrapHeight;
	//RichTextBlock AutoPaging
	UFUNCTION(BlueprintCallable)
	TArray<FKGRichTextBlockPageData> GetAutoPages(const FText& inText, bool OnlyUseViewportScale);
	//Adaptive Line
	UFUNCTION(BlueprintCallable)
	void SetTextAdaptively(const FText& inText);
	//@C7 Code End (@pengwei03)

	UFUNCTION(BlueprintCallable)
	void SwitchDefaultStyle(const FString& InTextStyleName);

	using URichTextBlock::GetDefaultTextStyleOverride;

	float GetLineHeightPercentage() const { return this->LineHeightPercentage; }

protected:
	UPROPERTY(EditAnywhere, Category = RichFormatting, meta = (EditCondition = bUseRichFormatting, EditConditionHides, RequiredAssetDataTags = "RowStructure=/Script/UMG.RichTextStyleRow"))
	TArray<TObjectPtr<UDataTable>> TextStyleSetArray;

	UPROPERTY(EditAnywhere, Category = RichFormatting, meta = (EditCondition = bUseRichFormatting, EditConditionHides, RequiredAssetDataTags = "RowStructure=/Script/KGUI.KGRichTextStyleOverrideRow"))
	TArray<TObjectPtr<UDataTable>> TextStyleOverrideDataTableChain;

	UPROPERTY(EditAnywhere, Category = RichFormatting, meta = (EditCondition = bUseRichFormatting, EditConditionHides, RequiredAssetDataTags = "RowStructure=/Script/UMG.RichImageRow"))
	TObjectPtr<UDataTable> ImageOverrideDataTable;
	
	//Modify By Bruce Start 2023.8.28
	/**专门给动效使用*/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Performance", AdvancedDisplay)
	float LatterSpaceAnim;
	//Modify By Bruce End 2023.8.28

public:
	UPROPERTY(Transient)
	UKGRichTextBlockTextDecorator* DefaultTextDecorator;

	UPROPERTY(Transient)
	UKGRichTextBlockImageDecorator* DefaultImageDecorator;

	UPROPERTY(Transient)
	UKGRichTextBlockHyperlinkDecorator* DefaultHyperlinkDecorator;

	UPROPERTY(EditAnywhere)
	FOnRichTextHyperlinkClicked OnRichTextLinkEvent;

	DECLARE_MULTICAST_DELEGATE_FourParams(FOnUrlActivated, FString, int32, int32, FVector2D)
	FOnUrlActivated OnUrlActivated;
	
	//@C7 Code Begin 
	//Center-RightEllipsis (@pengwei03)
	bool GetAlwaysEllipsis() const;
	virtual void SynchronizeProperties() override;
	//Compute And Get TextBlock Size
	UFUNCTION(BlueprintCallable)
	FVector2D GetTextScale(const FText& inText, bool useViewportScale = false);

	UFUNCTION(BlueprintCallable, Category = "Appearance")
	void SetAlwaysEllipsis(bool InAlwaysEllipsis);
	//@C7 Code End (@pengwei03)
	

	#pragma region 计时动态效果
public:
	UFUNCTION(BlueprintCallable)
	virtual void SetCountDownTimeFormat(const FString& Format) override;

	UFUNCTION(BlueprintCallable)
	virtual void SetCountDownTimeFormatByCondition(
		double LowerBoundSeconds, EKGCountDownConditionIntervalType LowerIntervalType,
		double UpperBoundSeconds, EKGCountDownConditionIntervalType UpperIntervalType,
		const FString& Format
	) override;

	UFUNCTION(BlueprintCallable)
	virtual void SetCountDownTimeFormatByFirstNonzeroUnit(FName FirstNonzeroUnitName, const FString& Format) override;

	UFUNCTION(BlueprintCallable)
	virtual void ClearCountDownTimeFormats() override;

	UFUNCTION(BlueprintCallable)
	virtual void PlayCountDown(double FromSeconds, double ToSeconds) override;

	UFUNCTION(BlueprintCallable)
	virtual void StopCountDown() override;

	UFUNCTION(BlueprintCallable)
	virtual bool IsCountDownPlaying() const override;

protected:
	virtual void BeginDestroy() override;
	virtual void HandleOnCountDownFinished() override;
	virtual void HandleOnCountDownTextChanged(FText&& Text) override;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Count Down Finished"))
	FKGOnTextBlockCountDownFinishedDynamic BP_OnCountDownFinished;

	#pragma endregion

	#pragma region Click / Touch / Press Method

protected:
	UPROPERTY(EditAnywhere, Category = "Interaction", AdvancedDisplay)
	TEnumAsByte<EButtonClickMethod::Type> ClickMethod = EButtonClickMethod::PreciseClick;

	UPROPERTY(EditAnywhere, Category = "Interaction", AdvancedDisplay)
	TEnumAsByte<EButtonTouchMethod::Type> TouchMethod = EButtonTouchMethod::PreciseTap;

	UPROPERTY(EditAnywhere, Category = "Interaction", AdvancedDisplay)
	TEnumAsByte<EButtonPressMethod::Type> PressMethod = EButtonPressMethod::DownAndUp;

public:
	EButtonClickMethod::Type GetClickMethod() const { return ClickMethod; }
	EButtonTouchMethod::Type GetTouchMethod() const { return TouchMethod; }
	EButtonPressMethod::Type GetPressMethod() const { return PressMethod; }

	#pragma endregion
};

// BEGIN ADD BY lishihao07@kuaishou.com: GPUTurbo RichTextBlock
UCLASS(DisplayName = "Rich Text Block (GPU Turbo)")
class KGUI_API UKGGPUTurboRichTextBlock: public UKGRichTextBlock
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("GPU Turbo")); }
#endif
	
	UKGGPUTurboRichTextBlock(const FObjectInitializer& ObjectInitializer);
protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;
public:
private:
	UPROPERTY(EditAnywhere, Getter, Setter, Category="GPUTurbo")
	FWidgetTransform GPUTransform;

	UPROPERTY(EditAnywhere, Getter, Setter, Category="GPUTurbo")
	FVector2D GPUTransformPivot;
	
	UPROPERTY(EditAnywhere, Getter, Setter, Category="GPUTurbo")
	FLinearColor GPUColorAndOpacity;
	
public:
	virtual void SynchronizeProperties() override;
	
	UFUNCTION(BlueprintCallable, Category="GPUTurbo")
	void SetGPUTransform(const FWidgetTransform& InTransform);
	
	UFUNCTION(BlueprintCallable, Category="GPUTurbo")
	FWidgetTransform GetGPUTransform() const;

	UFUNCTION(BlueprintCallable, Category="GPUTurbo")
	void SetGPUTransformPivot(const FVector2D& InPivot);
	
	UFUNCTION(BlueprintCallable, Category="GPUTurbo")
	FVector2D GetGPUTransformPivot() const;

	UFUNCTION(BlueprintCallable, Category="GPUTurbo")
	FLinearColor GetGPUColorAndOpacity() const;

	UFUNCTION(BlueprintCallable, Category="GPUTurbo")
	void SetGPUColorAndOpacity(const FLinearColor& InColor);

};
// END ADD BY lishihao07@kuaishou.com: GPUTurbo RichTextBlock