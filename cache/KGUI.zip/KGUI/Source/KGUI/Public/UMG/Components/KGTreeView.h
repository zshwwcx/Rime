#pragma once

#include "KGListView.h"
#include "UMG/Blueprint/KGTreeItem.h"
#include "Slate/Views/SKGTreeView.h"

#include "KGTreeView.generated.h"

DECLARE_DYNAMIC_DELEGATE_RetVal_OneParam(int32, FKGOnGetItemChildrenDynamic, const TArray<int>&, Path);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnItemExpansionChangedDynamic, const TArray<int>&, Path, bool, bIsExpanded);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnTreeEntryInitializedDynamic, const TArray<int>&, Path, UUserWidget*, Widget);
DECLARE_DYNAMIC_DELEGATE_RetVal_OneParam(int, FKGOnGetTreeEntryClassIndexForItemDynamic, const TArray<int>&, Path);

USTRUCT(BlueprintType)
struct FKGTileLayoutConfiguration
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bTileLayoutEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D TileLayoutCellSize = FVector2D(200, 200);

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FMargin TileLayoutPadding = FMargin(0);

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<EHorizontalAlignment> TileLayoutHorizontalAlignment = EHorizontalAlignment::HAlign_Left;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<EVerticalAlignment> TileLayoutVerticalAlignment = EVerticalAlignment::VAlign_Top;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float AdditionalHorizontalEntrySpacing = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float AdditionalVerticalEntrySpacing = 0;
};

USTRUCT(BlueprintType)
struct FKGListItemPreviewDetailData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = 0))
	int EntryWidgetClassIndex;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = 0, ClampMax = 60))
	int Num;
};

USTRUCT(BlueprintType)
struct FKGTreeItemPreviewDetailData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(ClampMin = 0))
	int EntryWidgetClassIndex;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FKGListItemPreviewDetailData> Children;
};

DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FKGTileLayoutConfiguration, FKGOnGetTileLayoutConfigurationForItemDynamic, const TArray<int>&, ParentPath, const FKGTileLayoutConfiguration&, DefaultTileLayoutConfiguration);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnTreeItemSelectionChangedDynamic, const TArray<int>&, Path, bool, bIsSelected);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnTreeItemClickedDynamic, const TArray<int>&, Path);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnTreeItemDoubleClickedDynamic, const TArray<int>&, Path);

UCLASS(DisplayName = "Tree View (KGUI)", MinimalAPI, meta = (LuaComponent = "Framework.KGFramework.KGUI.Component.UITreeView.UITreeView", ToolTip = "树状列表"))
class UKGTreeView : public UKGListView
{
	friend struct FKGTreeItem;

public:
	using ItemType = TSharedPtr<FKGListItem>;

private:
	GENERATED_BODY()

public:
	KGUI_API UKGTreeView(const FObjectInitializer& ObjectInitializer);
	KGUI_API virtual TSharedRef<STableViewBase> RebuildListWidget() override;
	KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API void SetItemExpansion(const TArray<int>& Path, bool bExpandItem);

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API bool IsItemExpanded(const TArray<int>& Path);

private:
	KGUI_API void ExpandAllInternal(ItemType ListItem);

public:
	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API void ExpandAll();

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API void CollapseAll();

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API void SetSelectedPath(const TArray<int>& Path);

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API void NavigateToPath(const TArray<int>& Path);

	UFUNCTION(BlueprintCallable, Category = TreeView, meta = (AllowPrivateAccess = true, DisplayName = "Set Tree Item Selection"))
	KGUI_API void BP_SetTreeItemSelection(const TArray<int>& Path, bool bSelected);

	KGUI_API virtual bool AddItem() override;

	KGUI_API virtual bool InsertItem(int32 Index) override;

	KGUI_API virtual void OnInsertingListItem(int32 Index, ItemType Item) override;

	KGUI_API virtual void OnListItemRemoved(int32 Index) override;

	KGUI_API virtual bool RemoveItem(int32 Index) override;

	static FString ConvertPathToString(const TArray<int>& Path);

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API virtual bool AddTreeItem();

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API virtual bool InsertTreeItem(const TArray<int>& Path);

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API virtual bool RemoveTreeItem(const TArray<int>& Path);

	virtual bool IsInsertOrRemoveAnimationAvailable() override { return false; }

	void ScrollTreeItemIntoViewInternal(const TArray<int>& Path, bool bAutoAlignment, float Alignment);

	UFUNCTION(BlueprintCallable, Category = TreeView, meta = (AllowPrivateAccess = true, DisplayName = "Scroll Tree Item Into View"))
	KGUI_API void BP_ScrollTreeItemIntoView(const TArray<int>& Path, float Alignment);

	UFUNCTION(BlueprintCallable, Category = TreeView, meta = (AllowPrivateAccess = true, DisplayName = "Scroll Tree Item Into View If Need"))
	KGUI_API void BP_ScrollTreeItemIntoViewIfNeeded(const TArray<int>& Path);

	KGUI_API virtual void BP_CancelScrollIntoView() override;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API TArray<int> GetNextLinearizedItemPath(const TArray<int>& CurrentPath);

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API bool PopulateNextLinearizedItemPath(const TArray<int>& CurrentPath, UPARAM(ref) TArray<int>& NextPath);

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API TArray<int> GetPreviousLinearizedItemPath(const TArray<int>& CurrentPath);

	UFUNCTION(BlueprintCallable, Category = TreeView)
	KGUI_API bool PopulatePreviousLinearizedItemPath(const TArray<int>& CurrentPath, UPARAM(ref) TArray<int>& PreviousPath);

protected:
	template <template<typename> class TreeViewT = SKGTreeView>
	TSharedRef<TreeViewT<ItemType>> ConstructTreeView()
	{
		FTreeViewConstructArgs Args;
		Args.bClearSelectionOnClick = bClearSelectionOnClick;
		Args.SelectionMode = SelectionMode;
		Args.ConsumeMouseWheel = ConsumeMouseWheel;
		Args.bReturnFocusToSelection = bReturnFocusToSelection;
		Args.TreeViewStyle = &WidgetStyle;
		Args.ScrollBarStyle = &ScrollBarStyle;

		// NOTE: STreeView中Tick时，如果bAllowInvisibleItemSelection开关关闭，则会检查当前选中的Item是否已经被折叠。如果折叠则取消选中。
		// 这时会调用Private_SignalSelectionChanged，但是不会调用OnItemSelectionChanged。上层业务监听OnItemSelectionChanged能够获得
		// 更准确的选中状态变化（不会监听Private_SignalSelectionChanged触发的OnSelectionChanged）。所以这里不做“不可见则取消选中”的逻辑。
		// 这样一来也更加方便和Lua层的选中数据统一。
		Args.bAllowInvisibleItemSelection = true;

		MyListView = MyTreeView = ITypedUMGListView<ItemType>::ConstructTreeView<TreeViewT, SKGTreeView>(this, ListItems, Args);
		MyTreeView->SetOnEntryInitialized(SKGListView<ItemType>::FOnEntryInitialized::CreateUObject(this, &UKGTreeView::HandleOnEntryInitializedInternal));
		MyTreeView->SetOnClicked(SKGListView<ItemType>::FOnListViewClicked::CreateUObject(this, &UKGTreeView::HandleOnClickedInternal));

		MyTreeView->SetOnSelectionsChanged(SKGListView<ItemType>::FKGOnSelectionsChanged::CreateUObject(this, &UKGTreeView::HandleOnSelectionsChangedInternal));
		MyTreeView->SetOnItemSelectionChanged(SKGListView<ItemType>::FKGOnItemSelectionChanged::CreateUObject(this, &UKGTreeView::HandleOnItemSelectionChangedInternal));

		MyTreeView->SetOnItemsRefreshed(SKGListView<ItemType>::FKGOnItemsRefreshed::CreateUObject(this, &UKGTreeView::HandleOnItemsRefreshed));
		MyTreeView->SetOnUserScrollingStarted(FSimpleDelegate::CreateUObject(this, &UKGTreeView::HandleOnUserScrollingStarted));
		MyTreeView->SetOnUserScrollingEnded(FSimpleDelegate::CreateUObject(this, &UKGTreeView::HandleOnUserScrollingEnded));
		MyTreeView->SetOnOverscrollAmountChanged(FSimpleDelegate::CreateUObject(this, &UKGTreeView::HandleOnOverscrollAmountChanged));

		MyTreeView->SetScrollbarDisabledVisibility(EVisibility::Hidden);

		if (auto Settings = GetDefault<UKGUISettings>())
		{
			MyListView->SetFixScrollItemIntoViewErrorWhenListContentDecreasesAndIsScrolledToTheEnd(
				Settings->bFixScrollItemIntoViewErrorWhenListContentDecreasesAndIsScrolledToTheEnd
			);
		}

		RebuildBackground();

		return StaticCastSharedRef<TreeViewT<ItemType>>(MyTreeView.ToSharedRef());
	}

	KGUI_API virtual void SynchronizeProperties() override;

	KGUI_API void OnGenerationEnding(const TArray<TObjectPtrWrapTypeOf<ItemType>>& ItemsWithGeneratedWidgets);

	KGUI_API virtual ItemType SpawnItem() const override;
	KGUI_API TSharedPtr<FKGTreeItem> GetItemAt(const TArray<int>& Path) const;

	KGUI_API virtual void OnItemClickedInternal(ItemType ListItem) override;
	KGUI_API virtual void OnItemDoubleClickedInternal(ItemType ListItem) override;
	KGUI_API virtual void HandleOnEntryInitializedInternal(ItemType Item, const TSharedRef<ITableRow>& TableRow) override;

	KGUI_API virtual void HandleOnItemSelectionChangedInternal(const NullableItemType& Item, bool bSelected) override;
	KGUI_API virtual void HandleOnSelectionsChangedInternal(const SKGListView<ItemType>::TItemSet& SelectedItems, ESelectInfo::Type SelectInfo) override;
	KGUI_API virtual void OnItemScrolledIntoViewInternal(ItemType ListItem, UUserWidget& EntryWidget) override;

	KGUI_API virtual void OnItemExpansionChangedInternal(ItemType Item, bool bIsExpanded) override;
	KGUI_API virtual void OnGetChildrenInternal(ItemType Item, TArray<ItemType>& OutChildren) const override;

	bool RequestGetChildren(ItemType Item) const;

	virtual FMargin GetDesiredEntryPadding(ItemType Item) const override;

	TSharedPtr<SKGTreeView<ItemType>> MyTreeView;

public:
	TSharedPtr<SKGTreeView<ItemType>> GetSlateTreeView() const { return MyTreeView; }

private:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Events, meta = (IsBindableEvent, AllowPrivateAccess = true, DisplayName = "On Get Item Children"))
	FKGOnGetItemChildrenDynamic BP_OnGetItemChildren;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (AllowPrivateAccess = true, DisplayName = "On Item Expansion Changed"))
	FKGOnItemExpansionChangedDynamic BP_OnItemExpansionChanged;

	FOnItemExpansionChanged OnItemExpansionChangedEvent;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Tree Entry Initialized"))
	FKGOnTreeEntryInitializedDynamic BP_OnTreeEntryInitialized;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Tree Item Selection Changed"))
	FKGOnTreeItemSelectionChangedDynamic BP_OnTreeItemSelectionChanged;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Tree Item Clicked"))
	FKGOnTreeItemClickedDynamic BP_OnTreeItemClicked;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Tree Item Double Clicked"))
	FKGOnTreeItemDoubleClickedDynamic BP_OnTreeItemDoubleClicked;

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild))
	bool bHierarchyPreviewableInDesignTime = false;
#endif

#if WITH_EDITOR
	virtual void OnRefreshDesignerItems() override;
#endif

#pragma region 多类型子项

protected:
	virtual TSubclassOf<UUserWidget> GetDesiredEntryClassForItem(ItemType Item) const override;

private:
	UPROPERTY(EditAnywhere, Category = Events, meta = (IsBindableEvent, AllowPrivateAccess = true, DisplayName = "On Get Tree Entry Class For Item"))
	FKGOnGetTreeEntryClassIndexForItemDynamic OnGetTreeEntryClassIndexForItem;

#pragma endregion

#pragma region 网格布局

public:
	KGUI_API virtual TSharedRef<ITableRow> HandleGenerateRow(ItemType Item, const TSharedRef<STableViewBase>& OwnerTable) override;
	KGUI_API virtual void HandleRowReleased(const TSharedRef<ITableRow>& Row) override;

private:
	mutable TSharedPtr<FKGTreeTileLayoutState> TreeTileLayoutState;

	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild))
	bool bTileLayout = false;

	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild, EditCondition = bTileLayout, EditConditionHides))
	uint32 TileLayoutNestingLevel = 1;

	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild, EditCondition = bTileLayout, EditConditionHides))
	FVector2D TileLayoutCellSize = FVector2D(200, 200);

	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild, EditCondition = bTileLayout, EditConditionHides))
	FMargin TileLayoutPadding = FMargin(0);

	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild, EditCondition = bTileLayout, EditConditionHides))
	FSlateBrush TileLayoutBackground;

	#pragma region 网格布局背景笔刷缓存

	UPROPERTY(Transient)
	FSlateBrush TileLayoutFirstLineBackground;

	UPROPERTY(Transient)
	FSlateBrush TileLayoutStretchableBackground;

	UPROPERTY(Transient)
	FSlateBrush TileLayoutLastLineBackground;

	void InitializeTileLayoutBackgrounds();
	const FSlateBrush* GetTileLayoutFullBackground() const { return &TileLayoutBackground; }
	const FSlateBrush* GetTileLayoutFirstLineBackground() const { return &TileLayoutFirstLineBackground; }
	const FSlateBrush* GetTileLayoutStretchableBackground() const { return &TileLayoutStretchableBackground; }
	const FSlateBrush* GetTileLayoutLastLineBackground() const { return &TileLayoutLastLineBackground; }
	const FSlateBrush* GetTileLayoutBackground(bool bIsFirstLine, bool bIsLastLine) const
	{
		if (bIsFirstLine && bIsLastLine)
		{
			return GetTileLayoutFullBackground();
		}
		if (bIsFirstLine)
		{
			return GetTileLayoutFirstLineBackground();
		}
		if (bIsLastLine)
		{
			return GetTileLayoutLastLineBackground();
		}
		return GetTileLayoutStretchableBackground();
	}

	#pragma endregion

	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild, EditCondition = "bTileLayout && Orientation == EOrientation::Orient_Vertical", EditConditionHides))
	TEnumAsByte<EHorizontalAlignment> TileLayoutHorizontalAlignment = EHorizontalAlignment::HAlign_Left;

	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild, EditCondition = "bTileLayout && Orientation == EOrientation::Orient_Horizontal", EditConditionHides))
	TEnumAsByte<EVerticalAlignment> TileLayoutVerticalAlignment = EVerticalAlignment::VAlign_Top;

	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild, EditCondition = "bTileLayout && Orientation == EOrientation::Orient_Horizontal", EditConditionHides), DisplayName = "Tile Layout Additional Horizontal Entry Spacing")
	float AdditionalHorizontalEntrySpacing = 0;

	UPROPERTY(EditAnywhere, Category = TreeView, meta = (DesignerRebuild, EditCondition = "bTileLayout && Orientation == EOrientation::Orient_Vertical", EditConditionHides), DisplayName = "Tile Layout Additional Vertical Entry Spacing")
	float AdditionalVerticalEntrySpacing = 0;

	UPROPERTY(EditAnywhere, Category = Events, meta = (IsBindableEvent, AllowPrivateAccess = true))
	FKGOnGetTileLayoutConfigurationForItemDynamic OnGetTileLayoutConfigurationForItem;

	FKGTileLayoutConfiguration GetDefaultTileLayoutConfiguration() const
	{
		FKGTileLayoutConfiguration TileLayoutConfiguration;
		TileLayoutConfiguration.bTileLayoutEnabled = true;
		TileLayoutConfiguration.TileLayoutCellSize = TileLayoutCellSize;
		TileLayoutConfiguration.TileLayoutPadding = TileLayoutPadding;
		TileLayoutConfiguration.TileLayoutHorizontalAlignment = TileLayoutHorizontalAlignment;
		TileLayoutConfiguration.TileLayoutVerticalAlignment = TileLayoutVerticalAlignment;
		TileLayoutConfiguration.AdditionalHorizontalEntrySpacing = AdditionalHorizontalEntrySpacing;
		TileLayoutConfiguration.AdditionalVerticalEntrySpacing = AdditionalVerticalEntrySpacing;
		return TileLayoutConfiguration;
	}

#pragma endregion

#pragma region 子项动画

public:
	KGUI_API virtual void PlayListItemAnimation(const FKGItemAnimationEntryStyle& InEntryStyle) override;
	KGUI_API virtual void PlayListItemAnimationWithDefaultConfiguration() override;
	KGUI_API virtual void SeekListItemAnimationToStart(const FKGItemAnimationEntryStyle& InEntryStyle) override;
	KGUI_API virtual void SeekListItemAnimationToStartWithDefaultConfiguration() override;
	KGUI_API virtual void StopListItemAnimation() override;

	UFUNCTION(BlueprintCallable)
	KGUI_API void PlayTreeItemAnimation(const TArray<FKGItemAnimationEntryStyle>& InEntryStyles);

	UFUNCTION(BlueprintCallable)
	KGUI_API virtual void PlayTreeItemAnimationWithDefaultConfiguration();

	UFUNCTION(BlueprintCallable)
	KGUI_API void SeekTreeItemAnimationToStart(const TArray<FKGItemAnimationEntryStyle>& InEntryStyles);

	UFUNCTION(BlueprintCallable)
	KGUI_API virtual void SeekTreeItemAnimationToStartWithDefaultConfiguration();

	UFUNCTION(BlueprintCallable)
	KGUI_API void StopTreeItemAnimation();

protected:
	DECLARE_DYNAMIC_DELEGATE_RetVal_OneParam(double, FKGOnGetTreeItemAnimationTriggerTime, const TArray<int>&, Path);

	KGUI_API virtual bool OnItemAnimationTick(const FKGItemAnimationConfiguration& Configuration, double StartTime, bool bForce, EKGItemAnimationState SpecificAnimationState) override;
	KGUI_API virtual int32 GetLocalItemIndex(const ItemType& Item) const override;
	KGUI_API virtual int32 GetLocalNumItemsPerLine(const ItemType& Item) const override;
	KGUI_API virtual double GetItemAnimationTriggerTime_Blueprint(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const override;
	KGUI_API virtual const FKGItemAnimationEntryStyle& GetItemAnimationEntryStyle(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const override;
	KGUI_API virtual bool IsTreeViewInternal() const override { return true; }
	KGUI_API virtual const FKGItemAnimationEntryStyle& GetDefaultItemAnimationEntryStyle(const ItemType& Item) const override;

	UPROPERTY(EditAnywhere, Category = Events, meta = (IsBindableEvent, AllowPrivateAccess = true, DisplayName = "On Get Tree Item Animation Trigger Time"))
	FKGOnGetTreeItemAnimationTriggerTime OnGetTreeItemAnimationTriggerTime;

	UPROPERTY(EditAnywhere, Category = ItemAnimation)
	TArray<FKGItemAnimationEntryStyle> DefaultTreeItemAnimationConfiguration;

#pragma endregion

#pragma region 滚动相关回调的补充

protected:
	virtual FMargin GetEntryFinalPadding(ItemType Item, TSharedRef<ITableRow> TableRow) const override;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	TArray<int> GetFrontEdgeIntersectionTreeItemPath() const;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	bool PopulateFrontEdgeIntersectionTreeItemPath(UPARAM(ref) TArray<int>& Path);

	bool PopulateFrontEdgeIntersectionTreeItemPathInternal(TArray<int>& Path) const;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	TArray<int> GetBackEdgeIntersectionTreeItemPath() const;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	bool PopulateBackEdgeIntersectionTreeItemPath(UPARAM(ref) TArray<int>& Path);

	bool PopulateBackEdgeIntersectionTreeItemPathInternal(TArray<int>& Path) const;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	TArray<int> GetFrontEdgeApproximateTreeItemPath() const;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	bool PopulateFrontEdgeApproximateTreeItemPath(UPARAM(ref) TArray<int>& Path);

	bool PopulateFrontEdgeApproximateTreeItemPathInternal(TArray<int>& Path) const;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	TArray<int> GetBackEdgeApproximateTreeItemPath() const;

	UFUNCTION(BlueprintCallable, Category = TreeView)
	bool PopulateBackEdgeApproximateTreeItemPath(UPARAM(ref) TArray<int>& Path);

	bool PopulateBackEdgeApproximateTreeItemPathInternal(TArray<int>& Path) const;

	static bool TryGetFirstTreeItemPathFromGenericItem(ItemType Item, TArray<int>& Path);

#pragma endregion

#pragma region 子项实例参数配置

public:
	virtual bool IsEntryWidgetAlignmentAvailable(EOrientation InOrientation, int Level) const override
	{
		if (bTileLayout && Level == TileLayoutNestingLevel)
		{
			return false;
		}
		return Super::IsEntryWidgetAlignmentAvailable(InOrientation, Level);
	}

	virtual bool IsLengthOverrideAvailable(EOrientation InOrientation, int Level, bool bFill) const override
	{
		if (bTileLayout && Level == TileLayoutNestingLevel)
		{
			return false;
		}
		return Super::IsLengthOverrideAvailable(InOrientation, Level, bFill);
	}

	virtual int GetItemLevel(ItemType Item) const override
	{
		if (auto TreeItem = FKGTreeItem::UnsafeCast(Item))
		{
			return TreeItem->GetTreeLevel();
		}
		return Super::GetItemLevel(Item);
	}

#pragma endregion

#pragma region 强制刷新

	UFUNCTION(BlueprintCallable, Category = TreeView)
	UUserWidget* GetOrCreateTreeEntryWidgetFromItem(const TArray<int>& Path);

#pragma endregion

#pragma region 复杂预览

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, Category = ListEntries, meta = (DisplayAfter = "NumDesignerPreviewEntries"))
	TArray<FKGTreeItemPreviewDetailData> PreviewDetailData;
#endif

#if WITH_EDITOR
	virtual void ValidateCompiledDefaults(class IWidgetCompilerLog& CompileLog) const override;
#endif

#pragma endregion

#pragma region 异形样式（提供区别于IrregularListView的简单的异形列表方案）

public:
	virtual void MarkShapeAsDirty() override;

#pragma endregion
};