#pragma once

#include "CoreMinimal.h"

#include "UMG/Components/KGButton.h"
#include "Framework/SlateDelegates.h"

#include "KGCircleButton.generated.h"

/**
 *
 */
UCLASS(DisplayName = "KGCircleButton")
class KGUI_API UKGCircleButton : public UKGButton
{
	GENERATED_BODY()

private:
	/** The delegate to execute when the button is clicked */
	FOnClicked C7OnClicked;

protected:
	//override Button
	virtual FReply SlateHandleClicked() override;
};