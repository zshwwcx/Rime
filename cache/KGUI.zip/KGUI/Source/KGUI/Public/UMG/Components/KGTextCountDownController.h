#pragma once

#include "CoreUObject.h"
#include "Misc/DateTime.h"

#include "UMG/Components/KGCountDownConditionIntervalType.h"

class IKGTextCountDown;

enum class EKGTextCountDownTimeType
{
	Engine,
	System,
	Game,
};

class FKGTextCountDownController : public TSharedFromThis<FKGTextCountDownController>
{
public:
	/*
	 * %d：日
	 * %H: 时
	 * %M：分
	 * %S：秒
	 * %f：毫秒
	 */

	FKGTextCountDownController(const UObject* InTarget);
	virtual ~FKGTextCountDownController();

	void SetCountDownTimeFormat(const FString& Format);
	void SetCountDownTimeFormatByCondition(
		double LowerBoundSeconds, EKGCountDownConditionIntervalType LowerIntervalType,
		double UpperBoundSeconds, EKGCountDownConditionIntervalType UpperIntervalType,
		const FString& Format
	);
	void SetCountDownTimeFormatByFirstNonzeroUnit(FName FirstNonzeroUnitName, const FString& Format);
	void ClearCountDownTimeFormats();
	void PlayCountDown(double FromSeconds, double ToSeconds);
	void StopCountDown();
	bool IsCountDownPlaying() const { return bIsCountDownPlaying; }

	void SetOnCountDownFinished(const TDelegate<void()>& InOnCountDownFinished) { OnCountDownFinished = InOnCountDownFinished; }
	void SetOnTextChanged(const TDelegate<void(FText&&)>& InOnTextChanged) { OnTextChanged = InOnTextChanged; }

	void SetTimeType(EKGTextCountDownTimeType InTimeType) { TimeType = InTimeType; }
	void SetMinimumUnitCeilingPerFormat(bool bEnabled) { bMinimumUnitCeilingPerFormat = bEnabled; }

protected:
	int GetGameMilliseconds();
	FDateTime GetSystemTimeFixedInSameFrame();
	int GetGameMillisecondsFixedInSameFrame();

	static FName UnitName_Day;
	static FName UnitName_Hour;
	static FName UnitName_Minute;
	static FName UnitName_Second;
	static FName UnitName_Millisecond;

	static double SecondCount_Day;
	static double SecondCount_Hour;
	static double SecondCount_Minute;
	static double SecondCount_Second;
	static double MillisecondCount_Second;
	static double SecondCount_Millisecond;

	static TArray<TPair<FName, double>> UnitSecondCounts;

	struct FCountDownConditionalInfo;
	static TMap<FName, FCountDownConditionalInfo> CountDownConditionalInfos;

	class FTimeData
	{
	public:
		TMap<int, int64> UnitValues;
	};

	enum class ETimeFormatTokenType
	{
		Literal,
		Escape,
	};

	class FTimeFormatLiteralToken;
	class FTimeFormatEscapeToken;

	class FTimeFormatToken : public TSharedFromThis<FTimeFormatToken>
	{
	public:
		FTimeFormatToken(ETimeFormatTokenType InTokenType)
			: TokenType(InTokenType)
		{
		}

		virtual ~FTimeFormatToken() = default;
		virtual void AppendTo(FStringBuilderBase& StringBuilder, const FTimeData& TimeData) const = 0;
		ETimeFormatTokenType GetTokenType() const { return TokenType; }

		TSharedPtr<FTimeFormatLiteralToken> AsLiteralToken()
		{
			if (TokenType != ETimeFormatTokenType::Literal)
			{
				return nullptr;
			}
			return StaticCastSharedPtr<FTimeFormatLiteralToken>(AsShared().ToSharedPtr());
		}

		TSharedPtr<FTimeFormatEscapeToken> AsEscapeToken()
		{
			if (TokenType != ETimeFormatTokenType::Escape)
			{
				return nullptr;
			}
			return StaticCastSharedPtr<FTimeFormatEscapeToken>(AsShared().ToSharedPtr());
		}

	private:
		ETimeFormatTokenType TokenType;
	};

	class FTimeFormatLiteralToken : public FTimeFormatToken
	{
	public:
		FTimeFormatLiteralToken(const FString& InLiteral)
			: FTimeFormatToken(ETimeFormatTokenType::Literal)
			, Literal(InLiteral)
		{
		}

		virtual void AppendTo(FStringBuilderBase& StringBuilder, const FTimeData& TimeData) const override;

	private:
		FString Literal;
	};

	class FTimeFormatEscapeToken : public FTimeFormatToken
	{
	public:
		FTimeFormatEscapeToken(int InUnitIndex, bool bInZeroWithPad)
			: FTimeFormatToken(ETimeFormatTokenType::Escape)
			, UnitIndex(InUnitIndex)
			, bZeroWithPad(bInZeroWithPad)
		{
		}

		virtual void AppendTo(FStringBuilderBase& StringBuilder, const FTimeData& TimeData) const override;
		int GetUnitIndex() const { return UnitIndex; }

	private:
		int UnitIndex;
		bool bZeroWithPad;
	};

	struct FTimeUnitInfo
	{
		TCHAR EscapeChar = 0;
		double SecondCount = 0;
		int PadLength = 0;

		FTimeUnitInfo() {}
		FTimeUnitInfo(const TCHAR& InEscapeChar, double InSecondCount, int InPadLength)
			: EscapeChar(InEscapeChar)
			, SecondCount(InSecondCount)
			, PadLength(InPadLength)
		{
		}
	};

	class FTimeFormatCompiledData
	{
	public:
		static TArray<FTimeUnitInfo> TimeUnitInfos;

		static TSharedPtr<FTimeFormatCompiledData> Compile(const FString& Format);
		FString Generate(double Seconds);

		int GetFirstUnitIndex() const { return SortedUnitIndexes.IsEmpty() ? INDEX_NONE : SortedUnitIndexes[0]; }
		int GetLastUnitIndex() const { return SortedUnitIndexes.IsEmpty() ? INDEX_NONE : SortedUnitIndexes[SortedUnitIndexes.Num() - 1]; }

	private:
		static TSharedPtr<FTimeFormatToken> ParseLiteral(const FString& Format, int& Index);
		static TSharedPtr<FTimeFormatToken> ParseEscape(const FString& Format, int& Index);

		TArray<TSharedPtr<FTimeFormatToken>> Tokens;
		TArray<int> SortedUnitIndexes;
	};

	void RegisterPreTick();
	void UnregisterPreTick();
	void OnPreTick(float InDeltaTime);

	double NormalizeToUnit(double Seconds, int UnitIndex) const;
	void UpdateCountDownCurrentSeconds(double CurrentSeconds, bool bForce);
	void UpdateCountDownText(double DisplaySeconds);
	void UpdateMergedSmallestUnitIndex();

	TWeakObjectPtr<const UObject> Target;
	double CountDownFromSeconds = 0;
	double CountDownToSeconds = 0;
	double CountDownCurrentSeconds = 0;
	bool bIsCountDownPlaying = false;
	int64 LastDisplayMilliseconds = 0;
	FDateTime CountDownStartSystemTime = FDateTime::MinValue();
	int64 CountDownStartGameMilliseconds = 0;
	FDelegateHandle PreTickDelegateHandle;
	EKGTextCountDownTimeType TimeType = EKGTextCountDownTimeType::Game;
	bool bMinimumUnitCeilingPerFormat = true;

	struct FCountDownConditionalInfo
	{
		double LowerBoundSeconds = 0;
		EKGCountDownConditionIntervalType LowerIntervalType = EKGCountDownConditionIntervalType::Unbounded;
		double UpperBoundSeconds = 0;
		EKGCountDownConditionIntervalType UpperIntervalType = EKGCountDownConditionIntervalType::Unbounded;

		FCountDownConditionalInfo() = default;
		FCountDownConditionalInfo(
			double InLowerBoundSeconds, EKGCountDownConditionIntervalType InLowerIntervalType,
			double InUpperBoundSeconds, EKGCountDownConditionIntervalType InUpperIntervalType
		)
		{
			LowerBoundSeconds = InLowerBoundSeconds;
			LowerIntervalType = InLowerIntervalType;
			UpperBoundSeconds = InUpperBoundSeconds;
			UpperIntervalType = InUpperIntervalType;
		}
	};

	TSharedPtr<FTimeFormatCompiledData> CountDownTimeFormat;
	TArray<TPair<FCountDownConditionalInfo, TSharedPtr<FTimeFormatCompiledData>>> CountDownConditionalTimeFormats;
	int MergedSmallestUnitIndex = INDEX_NONE;

	TDelegate<void()> OnCountDownFinished;
	TDelegate<void(FText&&)> OnTextChanged;
};
