#pragma once

#include "CoreMinimal.h"
#include "Components/GPUTurboModifyBox.h"

#include "KGGPUTurboModifyBox.generated.h"

UCLASS(DisplayName = "Modify Box (GPU Turbo)")
class KGUI_API UKGGPUTurboModifyBox : public UGPUTurboModifyBox
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("GPU Turbo")); }
#endif
};

UCLASS(DisplayName = "Fallback Box (GPU Turbo)")
class KGUI_API UKGGPUTurboFallbackBox : public UGPUTurboFallbackBox
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("GPU Turbo")); }
#endif
};