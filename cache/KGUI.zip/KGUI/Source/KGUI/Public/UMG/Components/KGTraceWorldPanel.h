#pragma once

#include "CoreMinimal.h"
#include "KGCanvasPanel.h"
#include "KGTraceWorldPanel.generated.h"

/**
 * traceWidget相关信息
 */
struct FTraceWidgetPersistentState
{
	FTraceWidgetPersistentState(
		int32 InTraceID,
		const FVector& InWorldPos)
		: TraceID(InTraceID)
		, WorldPos(InWorldPos)
	{}

	int32 TraceID = 0;
	FVector WorldPos = FVector::ZeroVector;
	FVector2D ScreenPositionPos = FVector2D::ZeroVector;
	FVector2D RawViewPortPos = FVector2D::ZeroVector;
	FVector2D FinalViewPortPos = FVector2D::ZeroVector;

	bool bIsOnEdge = false;
	bool bProjected = false;
	bool bNeedUpdate = false;
	float Direction = 0.0f;
};


/**
 * 
 */
UCLASS(DisplayName = "Trace World Panel(KGUI)", meta = (ToolTip = "任务指引专属控件，支持子控件互不遮挡的显示"))
class KGUI_API UKGTraceWorldPanel : public UKGCanvasPanel, public FTickableGameObject
{
	GENERATED_BODY()
public:
	virtual void BeginDestroy() override;

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("SPECIAL")); }
#endif

	UFUNCTION()
	int32 AddWidget(UUserWidget* InWidget, const FVector& WorldPos);

	UFUNCTION()
	void RemoveWidget(int32 TraceID);

	UFUNCTION()
	void ClearTraceWidgetsInfo();

	UFUNCTION()
	void SetWorldPos(int32 TraceID, const FVector& InWorldPos);

	/** 保护椭圆圆心，在屏幕的位置比例，如(0.5, 0.5)为屏幕中心.*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TraceWidget", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	FVector2D ProtectCircleCenter;

	/** 保护椭圆双半轴长度，X为长半轴，屏幕宽的比例，Y为短半轴，屏幕高的比例.*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TraceWidget", meta = (ClampMin = "0.0", ClampMax = "0.5"))
	FVector2D ProtectCircleAxis;

	/** 定义高处的距离，单位cm，比主角高度低于此值时，且不在相机正面时，追踪点始终会保持在椭圆下方. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TraceWidget")
	float HighPlaceDistance = 1000;

	/** 调整控件遮挡时的平移距离和判断距离. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TraceWidget")
	float AdaptDistance = 60;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TraceWidget")
	float AdaptRatio = 1.2;

	/** 每个控件每帧最多的调整次数. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TraceWidget")
	int32 MaxAdaptSteps = 5;

	/** 优化常量，设置为0即关闭.*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TraceWidget")
	int32 MinOpzChangeLength = 4;

private:
	int32 DynamicTraceID = 0;

	TMap<int32, FTraceWidgetPersistentState> TraceWigdetsPersistentStates;

	UPROPERTY(Transient)
	TMap<int32, TWeakObjectPtr<UUserWidget>> TraceWidgets;

	virtual bool IsTickable() const override;
	virtual void Tick(float DeltaTime) override;

	virtual TStatId GetStatId() const override {
		return GetStatID();
	}
};
