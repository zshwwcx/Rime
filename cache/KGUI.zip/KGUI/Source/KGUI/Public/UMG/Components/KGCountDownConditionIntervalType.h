#pragma once

#include "Misc/DateTime.h"
#include "UObject/ObjectMacros.h"

#include "KGCountDownConditionIntervalType.generated.h"

UENUM()
enum class EKGCountDownConditionIntervalType
{
	Unbounded = 0,
	Open = 1,
	Closed = 2,
};