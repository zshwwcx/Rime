// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: tangshenghao@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "Slate/Layout/SPolygon.h"
#include "Components/Widget.h"
#include "KGPolygon.generated.h"

UCLASS()
class KGUI_API UKGPolygon : public UWidget
{
	GENERATED_BODY()

public: 
	virtual void SynchronizeProperties() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Appearance")
	FSlateBrush Brush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FVector2D> PolygonPoints;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor LineColor = FLinearColor::Red;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor FillColor = FLinearColor::Green;

#if WITH_EDITOR
	//virtual const FText GetPaletteCategory() override;
#endif

protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;
	TSharedPtr<SPolygon> MyPolygon;
private:
};