#pragma once

#include "CoreMinimal.h"
#include "IKGTextCountDown.h"
#include "KGTextBlock.h"
#include "Components/RichTextBlockDecorator.h"
#include "Components/TextWidgetTypes.h"
#include "Components/Widget.h"
#include "Engine/DataTable.h"
#include "Widgets/Text/SRichTextBlock.h"

#include "KGBrushTextBlock.generated.h"

class FKGBrushCharRichTextDecorator;

USTRUCT(Blueprintable, BlueprintType, DisplayName="Brush Character Row (KGUI)")
struct FKGBrushCharacterRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere)
	FSlateBrush MainBrush;

	UPROPERTY(EditAnywhere)
	FMargin Padding;

	UPROPERTY(EditAnywhere)
	FSlateBrush ShadowBrush;
};

UCLASS(DisplayName = "Brush Text Block (KGUI)", meta = (ToolTip = "笔刷文本"))
class KGUI_API UKGBrushTextBlock : public UTextLayoutWidget, public IKGTextCountDown
{
	GENERATED_BODY()

	friend class FKGBrushCharRichTextDecorator;

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
	virtual void OnCreationFromPalette() override;
#endif

protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

protected:
	//~ Begin UTextLayoutWidget Interface
	virtual void OnShapedTextOptionsChanged(FShapedTextOptions InShapedTextOptions) override;
	virtual void OnJustificationChanged(ETextJustify::Type InJustification) override;
	virtual void OnWrappingPolicyChanged(ETextWrappingPolicy InWrappingPolicy) override;
	virtual void OnAutoWrapTextChanged(bool InAutoWrapText) override;
	virtual void OnWrapTextAtChanged(float InWrapTextAt) override;
	virtual void OnLineHeightPercentageChanged(float InLineHeightPercentage) override;
	virtual void OnApplyLineHeightToBottomLineChanged(bool InApplyLineHeightToBottomLine) override;
	virtual void OnMarginChanged(const FMargin& InMargin) override;
	//~ End UTextLayoutWidget Interface

public:
	UFUNCTION(BlueprintCallable, Category = BrushTextBlock)
	void SetText(const FText& InText);

	UFUNCTION(BlueprintCallable, Category = BrushTextBlock)
	FText GetText() const;

protected:
	void UpdateText();
	FString ConvertToRichFormatText(const FString& HumanReadableString) const;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, BlueprintSetter = "SetText", BlueprintGetter = "GetText", Getter, Setter, Category = Content, meta = (DesignerRebuild))
	FText Text;

	UPROPERTY(EditAnywhere, Category = Appearance, meta = (DesignerRebuild))
	UDataTable* BrushCharacters;

	UPROPERTY(EditAnywhere, Category = Appearance, meta = (DesignerRebuild))
	FTextBlockStyle FallbackTextStyle;

	TSharedPtr<SRichTextBlock> RichTextBlock;

	#pragma region 计时动态效果

public:
	UFUNCTION(BlueprintCallable)
	virtual void SetCountDownTimeFormat(const FString& Format) override;

	UFUNCTION(BlueprintCallable)
	virtual void SetCountDownTimeFormatByCondition(
		double LowerBoundSeconds, EKGCountDownConditionIntervalType LowerIntervalType,
		double UpperBoundSeconds, EKGCountDownConditionIntervalType UpperIntervalType,
		const FString& Format
	) override;

	UFUNCTION(BlueprintCallable)
	virtual void SetCountDownTimeFormatByFirstNonzeroUnit(FName FirstNonzeroUnitName, const FString& Format) override;

	UFUNCTION(BlueprintCallable)
	virtual void ClearCountDownTimeFormats() override;

	UFUNCTION(BlueprintCallable)
	virtual void PlayCountDown(double FromSeconds, double ToSeconds) override;

	UFUNCTION(BlueprintCallable)
	virtual void StopCountDown() override;

	UFUNCTION(BlueprintCallable)
	virtual bool IsCountDownPlaying() const override;

protected:
	virtual void BeginDestroy() override;
	virtual void HandleOnCountDownFinished() override;
	virtual void HandleOnCountDownTextChanged(FText&& Text) override;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Count Down Finished"))
	FKGOnTextBlockCountDownFinishedDynamic BP_OnCountDownFinished;

	#pragma endregion
};

class FKGBrushCharRichTextDecorator : public ITextDecorator
{
public:
	FKGBrushCharRichTextDecorator(UKGBrushTextBlock* InOwner);
	virtual ~FKGBrushCharRichTextDecorator() override = default;
	virtual bool Supports(const FTextRunParseResults& RunInfo, const FString& Text) const override;
	virtual TSharedRef<ISlateRun> Create(const TSharedRef<class FTextLayout>& TextLayout, const FTextRunParseResults& RunInfo, const FString& OriginalText, const TSharedRef<FString>& ModelText, const ISlateStyle* Style) override;

protected:
	const FKGBrushCharacterRow* GetBrushCharacterRowByRunInfo(const FTextRunParseResults& RunInfo, const FString& OriginalText) const;
	const FSlateBrush* GetMainBrushByRunInfo(const FTextRunParseResults& RunInfo, const FString& OriginalText) const;
	const FSlateBrush* GetShadowBrushByRunInfo(const FTextRunParseResults& RunInfo, const FString& OriginalText) const;
	const FMargin* GetPaddingByRunInfo(const FTextRunParseResults& RunInfo, const FString& OriginalText) const;

	TWeakObjectPtr<UKGBrushTextBlock> Owner;
};