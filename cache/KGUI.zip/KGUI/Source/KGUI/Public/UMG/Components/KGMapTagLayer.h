#pragma once
#include "CoreMinimal.h"
#include "Blueprint/UserWidgetPool.h"
#include "C7/KGUITickableSubsystem.h"
#include "Components/CanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include "UMG/Slate/SKGMapTagLayer.h"
#include "UMG/WidgetComponent/KGMapTagInfoManager.h"
#include "KGMapTagLayer.generated.h"


UCLASS(MinimalAPI)
class UKGMapTagLayerSlot : public UPanelSlot
{
    GENERATED_UCLASS_BODY()

public:
    /** The anchoring information for the slot */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter="GetLayout", Setter="SetLayout", BlueprintGetter ="GetLayout", BlueprintSetter="SetLayout", Category = "Layout|MapTagLayer Slot")
	FAnchorData LayoutData;

    /** When AutoSize is true we use the widget's desired size */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter="GetAutoSize", Setter="SetAutoSize", BlueprintGetter="GetAutoSize", BlueprintSetter="SetAutoSize", Category = "Layout|MapTagLayer Slot", AdvancedDisplay, meta = (DisplayName = "Size To Content"))
	bool bAutoSize;

    /** The order priority this widget is rendered in.  Higher values are rendered last (and so they will appear to be on top). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintGetter="GetZOrder", BlueprintSetter="SetZOrder", Category="Layout|MapTagLayer Slot")
	int32 ZOrder;

public:
#if WITH_EDITOR
    KGUI_API virtual bool NudgeByDesigner(const FVector2D& NudgeDirection, const TOptional<int32>& GridSnapSize) override;
    KGUI_API virtual bool DragDropPreviewByDesigner(const FVector2D& LocalCursorPosition, const TOptional<int32>& XGridSnapSize, const TOptional<int32>& YGridSnapSize) override;
    KGUI_API virtual void SynchronizeFromTemplate(const UPanelSlot* const TemplateSlot) override;
#endif //WITH_EDITOR

    /** Sets the layout data of the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API void SetLayout(const FAnchorData& InLayoutData);

    /** Gets the layout data of the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API FAnchorData GetLayout() const;

    /** Sets the position of the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API void SetPosition(FVector2D InPosition);

    /** Gets the position of the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API FVector2D GetPosition() const;

    /** Sets the size of the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API void SetSize(FVector2D InSize);

    /** Gets the size of the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API FVector2D GetSize() const;

    /** Sets the offset data of the slot, which could be position and size, or margins depending on the anchor points */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API void SetOffsets(FMargin InOffset);

    /** Gets the offset data of the slot, which could be position and size, or margins depending on the anchor points */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API FMargin GetOffsets() const;

    /** Sets the anchors on the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API void SetAnchors(const FAnchors& InAnchors);

    /** Gets the anchors on the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API FAnchors GetAnchors() const;

    /** Sets the alignment on the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API void SetAlignment(FVector2D InAlignment);

    /** Gets the alignment on the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API FVector2D GetAlignment() const;

    /** Sets if the slot to be auto-sized */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API void SetAutoSize(bool InbAutoSize);

    /** Gets if the slot to be auto-sized */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API bool GetAutoSize() const;

    /** Sets the z-order on the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API void SetZOrder(int32 InZOrder);

    /** Gets the z-order on the slot */
    UFUNCTION(BlueprintCallable, Category="Layout|MapTagLayer Slot") 
    KGUI_API int32 GetZOrder() const;

public:
    /** Sets the anchors on the slot */
    UFUNCTION() 
    KGUI_API void SetMinimum(FVector2D InMinimumAnchors);

    /** Sets the anchors on the slot */
    UFUNCTION() 
    KGUI_API void SetMaximum(FVector2D InMaximumAnchors);

public:
    KGUI_API void BuildSlot(TSharedRef<SKGMapTagLayer> MapTagLayer);

    // UPanelSlot interface
    KGUI_API virtual void SynchronizeProperties() override;
    // End of UPanelSlot interface

    KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;

#if WITH_EDITOR
    // UObject interface
    using Super::PreEditChange;
    KGUI_API virtual void PreEditChange(FProperty* PropertyThatWillChange) override;
    KGUI_API virtual void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;
    // End of UObject interface

    /** Stores the current layout information about the slot and parent canvas. */
    KGUI_API void SaveBaseLayout();

    KGUI_API void SetDesiredPosition(FVector2D InPosition);

    /** Compares the saved base layout against the current state.  Updates the necessary properties to maintain a stable position. */
    KGUI_API void RebaseLayout(bool PreserveSize = true);
#endif

private:
    SKGMapTagLayer::FSlot* Slot;

#if WITH_EDITORONLY_DATA
    FGeometry PreEditGeometry;
    FAnchorData PreEditLayoutData;

    TOptional<FVector2D> DesiredPosition;
#endif
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnKGMapTagInitializedDynamic, UUserWidget*, Widget, int32, TypeID, FString, TaskID, bool, bInEdge);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnKGMapTagRemovedDynamic, UUserWidget*, Widget, int32, TypeID, FString, TaskID);


USTRUCT(BlueprintType)
struct FKGMapTagWidgetEntry
{
    GENERATED_BODY()

    UPROPERTY()
    FString TaskID;

    UPROPERTY()
    UUserWidget* UserWidget;

    UPROPERTY()
    int32 TypeID;
    
    UPROPERTY()
    FString TemplateWidgetType;

    UPROPERTY()
    FVector2D Offset;

    UPROPERTY()
    int32 SimpleTagIconHandle = INDEX_NONE;
};


UCLASS(meta = (ShortTooltip = "Specialized for calculate transform of Map Tags, should only be used in MapSystem"))
class KGUI_API UKGMapTagLayer : public UPanelWidget, public FKGUITickableObjectBase
{
    GENERATED_UCLASS_BODY()

public:
    bool bCanTick = false;;
    bool bNeedUpdateTagAfterWidgetRendered = false;
    bool bViewportStatChanged = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector CameraLocation;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FRotator CameraRotation;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector2D CameraViewportSize;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float ViewportScale = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector2D CurrentCenterLocation;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float CurrentRotationByClockWise = .0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float ConstraintRadius;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector4 ConstraintRectangle;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    EMapShowTypeOnEdge PanelMapEdgeType = EMapShowTypeOnEdge::ShowOnEdgeByRectangle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bMiniMap = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bSameWithMapTexture = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 MapTextureWidth = 2048;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 MapTextureHeight = 2048;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector2D TagUniformScale;

#pragma region PanelWidgetInterface

public:
    /**  */
	UFUNCTION(BlueprintCallable, Category="MapTagLayer Panel")
	UKGMapTagLayerSlot* AddChildToMapTagLayer(UWidget* Content);

    /** Gets the underlying native canvas widget if it has been constructed */
    TSharedPtr<class SKGMapTagLayer> GetMapTagLayerWidget() const;

    /** Computes the geometry for a particular slot based on the current geometry of the canvas. */
    bool GetGeometryForSlot(int32 SlotIndex, FGeometry& ArrangedGeometry) const;

    /** Computes the geometry for a particular slot based on the current geometry of the canvas. */
    bool GetGeometryForSlot(const UKGMapTagLayerSlot* InSlot, FGeometry& ArrangedGeometry) const;

    void ReleaseSlateResources(bool bReleaseChildren) override;

#if WITH_EDITOR
    // UWidget interface
    virtual const FText GetPaletteCategory() override;
    // End UWidget interface

    // UWidget interface
    virtual bool LockToPanelOnDrag() const override
    {
        return true;
    }

    // End UWidget interface
#endif

    // UObject interface
    virtual void SynchronizeProperties() override;
    // End UObject interface

public:
	UFUNCTION(BlueprintCallable, Category = "Performance")
	bool GetLocalExplicitCanvasChildZOrder() const { return bLocalExplicitCanvasChildZOrder; }

	UFUNCTION(BlueprintCallable, Category = "Performance")
	void SetLocalExplicitCanvasChildZOrder(bool InbLocalExplicitCanvasChildZOrder);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter = "GetLocalExplicitCanvasChildZOrder", Setter = "SetLocalExplicitCanvasChildZOrder", BlueprintGetter = "GetLocalExplicitCanvasChildZOrder", BlueprintSetter = "SetLocalExplicitCanvasChildZOrder", Category = "Performance")
	bool bLocalExplicitCanvasChildZOrder = false;

protected:
    // UWidget interface
    virtual TSharedRef<SWidget> RebuildWidget() override;
    // End of UWidget interface

    // UPanelWidget
    virtual UClass* GetSlotClass() const override;
    virtual void OnSlotAdded(UPanelSlot* InSlot) override;
    virtual void OnSlotRemoved(UPanelSlot* Slot) override;
    // End UPanelWidget

protected:
    TSharedPtr<class SKGMapTagLayer> MyMapTagLayer;
#pragma endregion PanelWidgetInterface

#pragma  region MapTagLyaer

public:
    UFUNCTION(BlueprintCallable)
    void InitMapTagInfoManager();

    UFUNCTION()
    void SetCameraLocation(const FVector& InCameraLocation)
    {
        if (!(CameraLocation - InCameraLocation).IsNearlyZero())
        {
            bViewportStatChanged = true;
        }
        CameraLocation = InCameraLocation;
    }

    UFUNCTION()
    FVector GetCameraLocation() const
    {
        return CameraLocation;
    }

    UFUNCTION()
    void SetCameraRotation(const FRotator& InCameraRotation)
    {
        if (!(CameraRotation - InCameraRotation).IsNearlyZero())
        {
            bViewportStatChanged = true;
        }
        CameraRotation = InCameraRotation;
    }

    UFUNCTION()
    FRotator GetCameraRotation() const
    {
        return CameraRotation;
    }

    UFUNCTION()
    void SetCameraViewportSize(const FVector2D& InCameraViewportSize)
    {
        if (!(CameraViewportSize - InCameraViewportSize).IsNearlyZero())
        {
            bViewportStatChanged = true;
        }
        CameraViewportSize = InCameraViewportSize;
    }

    UFUNCTION()
    FVector2D GetCameraViewportSize() const
    {
        return CameraViewportSize;
    }

    UFUNCTION()
    void SetViewportScale(float InViewportScale);
    UFUNCTION()
    float GetViewportScale() const
    {
        return ViewportScale;
    }

    UFUNCTION()
    void SetCurrentCenterLocation(const FVector2D& InCurrentCenterLocation);
    UFUNCTION()
    FVector2D GetCurrentCenterLocation() const
    {
        return CurrentCenterLocation;
    }

    UFUNCTION()
    bool CanTick() const { return bCanTick; }

    UFUNCTION()
    void SetCanTick(bool bInCanTick) { bCanTick = bInCanTick; }

private:
    virtual void Tick(float DeltaTime) override;

    virtual bool IsTickable() const override
    {
        return !HasAnyFlags(RF_BeginDestroyed | RF_ClassDefaultObject | RF_ArchetypeObject) && IsValidChecked(this) && bCanTick;
    }

    UPROPERTY(Transient)
    FUserWidgetPool EntryWidgetPool;

public:
    //UFUNCTION()
    TObjectPtr<UUserWidget> GetWidgetFromPool(TSubclassOf<UUserWidget> InWidgetType);

    //UFUNCTION()
    void ReturnWidgetToPool(TObjectPtr<UUserWidget> InUserWidget);

    //几个上下文之间的关系：WidgetOffset [0,1]x[0,1],只是CanvasPanel上Slot的范围
    //WorldOffset, 在相机平面上的Offset, 值域CameraViewportSize
    //WorldLocation，原本的世界位置[-\Infinity, \Infinity]^3
    UFUNCTION(BlueprintCallable) 
    FVector2D GetWidgetOffsetByMapTagInfo(const FMapTagInfo& MapTagInfo);

    UFUNCTION(BlueprintCallable) 
    FVector2D GetWidgetPosByMapTagInfo(const FMapTagInfo& MapTagInfo) const;

    UFUNCTION(BlueprintCallable) 
    FVector2D GetWidgetOffsetByWorldLocation(const FVector& InLocation);
    UFUNCTION(BlueprintCallable) 
    FVector2D GetWorldOffsetByWorldLocation(const FVector& Location) const;
    UFUNCTION(BlueprintCallable) 
    FVector2D DeprojectWidgetOffsetToWorldLocation(FVector2D WidgetOffset) const;

    UFUNCTION(BlueprintCallable) 
    FVector2D GetWidgetOffsetByCenterAndWorldLocation(const FVector& Location);

    UFUNCTION(BlueprintCallable) 
    void GetWidgetOffsetByCenterAndWorldLocationPlain(float WorldPosX, float WorldPosY, float WorldPosZ, float& X, float& Y);

    UFUNCTION(BlueprintCallable) 
    TArray<FString> ReqTaskNearByByTaskID(const FString& TaskID, float ToleranceDistance) const;
    UFUNCTION(BlueprintCallable) 
    TArray<FString> ReqInteractableTaskNearByByTaskID(const FString& TaskID, float ToleranceDistance, bool bRequireCenter = true) const;

    UFUNCTION(BlueprintCallable) 
    float GetWidgetShearByWorldRotation(const FRotator& Rotation);
    UFUNCTION(BlueprintCallable) 
    float GetWidgetShearByTaskID(const FString& TaskID) const;
    UFUNCTION(BlueprintCallable) 
    FVector2D GetWidgetPosByTaskID(const FString& TaskID) const;

    UFUNCTION(BlueprintCallable)
    void SetTagUniformScale(float InScaleX, float InScaleY);

    UFUNCTION(BlueprintCallable)
    FVector2D CircleConvert(const FVector2D& WidgetOffset) const
    {
        FVector2D Origin(0.5f, 0.5f);
        FVector2D ConvertedOffset = ConstraintRadius * (WidgetOffset - Origin).GetSafeNormal() + Origin;
        return ConvertedOffset;
    }

    UFUNCTION(BlueprintCallable) 
    FVector2D RectangleConvert(const FVector2D& WidgetOffset) const
    {
        FVector2D Origin(0.5f, 0.5f);
        FVector2D DirectionVec = (WidgetOffset - Origin).GetSafeNormal();
        DirectionVec = DirectionVec.X < (-0.5f + ConstraintRectangle.X) ? (-0.5f + ConstraintRectangle.X) / DirectionVec.X * DirectionVec : DirectionVec.Y > (0.5f - ConstraintRectangle.Y) ? (0.5f - ConstraintRectangle.Y) / DirectionVec.Y * DirectionVec : DirectionVec.X > (0.5f - ConstraintRectangle.Z) ? (0.5f - ConstraintRectangle.Z) / DirectionVec.X * DirectionVec : (-0.5f + ConstraintRectangle.W) / DirectionVec.Y * DirectionVec;
        FVector2D ConvertedOffset = DirectionVec + Origin;
        return ConvertedOffset;
    }

    UFUNCTION(BlueprintCallable)
    void SetData(const TMap<FString, FMapTagInfo>& InMapTagInfoData);

    UFUNCTION(BlueprintCallable) 
    void SetTaskShowEdgeType(const FString& TaskID, EMapEdgeType ShowOnEdgeType) const;

    UFUNCTION(BlueprintCallable)
    void RetargetTagLocation(const FString& TaskID, const FVector& Location) const;

    UFUNCTION(BlueprintCallable)
    void ReSetTaskTypeToFollowActor(const FString& TaskID, int64 ActorID) const;

    UFUNCTION(BlueprintCallable)
    void ReSetTaskTypeToStatic(const FString& TaskID) const;

    UFUNCTION(BlueprintCallable)
    void SetTaskInteractable(const FString& TaskID, bool bInteractable) const;

    UFUNCTION(BlueprintCallable)
    void AddSingleTag(const FMapTagInfo& _MapTagInfo) const;

    UFUNCTION(BlueprintCallable) 
    void ClearAllTags();

    UFUNCTION(BlueprintCallable)
    void BatchAddTags(const TMap<FString, FMapTagInfo>& InMapTagInfos) const;

    UFUNCTION(BlueprintCallable)
    void BatchRemoveTags(TArray<FString> TaskIDs);

    UFUNCTION(BlueprintCallable)
    void RemoveSingleTag(const FString& TaskID);

    UFUNCTION(BlueprintCallable) 
    void SetSimpleTagIcon(const FString& TaskID, const FString& InIcon) const;

    UFUNCTION(BlueprintCallable)
    void SetSimpleTagIconSize(const FString& TaskID, float InSizeX, float InSizeY) const;

    UFUNCTION(BlueprintCallable) 
    void SetSimpleTagVisible(const FString& TaskID, bool bInVisible) const;

    UFUNCTION(BlueprintCallable)
    void SetSimpleTagMaterialFloatParam(const FString& TaskID, const FString& ParamName, float InValue);

    UFUNCTION(BlueprintCallable)
    void SetSimpleTagMaterialVectorParam(const FString& TaskID, const FString& ParamName, float InXorR, float InYorG, float InZorB, float InWorA);

    UFUNCTION(BlueprintCallable) 
    void SetSimpleTagMaterialTextureParam(const FString& TaskID, const FString& ParamName, UTexture* InTexture);

    UFUNCTION(BlueprintCallable)
    void SetSimpleTagRotateAngle(const FString& TaskID, float InRotateAngleInDegree) const;

    UPROPERTY(Transient) 
    class UKGMapTagInfoManager* MapTagInfoManager;

    UPROPERTY(Transient)
    int64 CenterActorID = 0; //小地图中使用，中心位置由Actor位置决定
    
    UPROPERTY(Transient)
    EMapTagLayerMode Mode = EMapTagLayerMode::ViewBound;
    
    UFUNCTION(BlueprintCallable)
    void SetMode(EMapTagLayerMode InMode);
    
    UFUNCTION(BlueprintCallable) 
    void SetCenterActor(int64 InCenterActorID);

    UFUNCTION(BlueprintCallable)
    void ResetCenterActor();

    UFUNCTION(BlueprintCallable)
    void RegisterWidgetRotateInEdge(const FString& TaskID, UWidget* Widget, float Offset) const;

    UFUNCTION(BlueprintCallable)
    void UnRegisterWidgetRotateInEdge(const FString& TaskID) const;

    UPROPERTY(BlueprintAssignable, Category = Events)
    FOnKGMapTagInitializedDynamic OnMapTagInitializedDynamic;
    UPROPERTY(BlueprintAssignable, Category = Events)
    FOnKGMapTagRemovedDynamic OnMapTagRemovedDynamic;

    bool InRectangle(const FVector2D& InWidgetOffset) const
    {
        return InWidgetOffset.X > ConstraintRectangle.X && InWidgetOffset.Y > ConstraintRectangle.Y && InWidgetOffset.X < (1.0f - ConstraintRectangle.Z) && InWidgetOffset.Y < (1.0f - ConstraintRectangle.W);
    }

    bool InCircle(const FVector2D& InWidgetOffset) const
    {
        const float aspectRatio = CameraViewportSize.X / CameraViewportSize.Y;
        if (aspectRatio == 1)
        {
            return (InWidgetOffset - FVector2D(0.5f, 0.5f)).Length() < ConstraintRadius;
        }

        const float xOffset = InWidgetOffset.X - 0.5f;
        const float yOffset = InWidgetOffset.Y - 0.5f;
        const float yConstraint = ConstraintRadius * aspectRatio;
        return (xOffset * xOffset) / (ConstraintRadius * ConstraintRadius) + (yOffset * yOffset) / (yConstraint * yConstraint) < 1;
    }

    bool static InCenter(FVector2D WidgetOffset)
    {
        return WidgetOffset.X > 0.0f && WidgetOffset.Y > 0.0f && WidgetOffset.X < 1.0f && WidgetOffset.Y < 1.0f;
    }

    EMapDisplayState GetNewMapDisplayState(const FMapTagInfo& MapTagInfoData);

private:
    UFUNCTION() 
    void OnMapTagClassLoaded(int InLoadID, UObject* Asset);

    UFUNCTION() 
    void OnTagIconLoaded(int32 InLoadID, UObject* InAsset);

    UObject* AsyncLoadUserWidgetClass(const FString& InWidgetSoftClassPath, const FString& InTaskID);
    UObject* AsyncLoadIcon(const FString& InTagIconPath, const FString& InTaskID);

    void UpdateTagUI(const FMapTagInfoPtr& InTag);
    void RemoveTagUI(const FString& TaskID);
    void InstanceTagUI(const FMapTagInfoPtr& InTag);
    void InstanceTagUIInternal(FKGMapTagWidgetEntry& Entry, TSubclassOf<UUserWidget> WidgetTemplate, const FVector2D& Offset, int32 InZOrder);
    void RemoveTagUIInternal(const FString& TaskID);

    int32 AddSimpleTagIcon(const FString& TaskID, const FMapTagInfoPtr& TagInfo);
    void RemoveSimpleTagIcon(int32 InSimpleTagIconHandle);
    void RemoveSimpleTagIcon(const FString& TaskID);
    void UpdateSimpleTagIcon(FKGMapSimpleTagIcon* TagIcon, const FMapTagInfo* TagInfo);

private:
    struct FLoadingHandle
    {
        int32 LoadID;
        FString Path;
        TArray<FString> TaskIDs;
    };

    TMap<int32, FLoadingHandle> AssetsInLoading;

    UPROPERTY(Transient)
    TMap<int32, FKGMapSimpleTagIcon> SimpleTagIcons;

    UPROPERTY(Transient)
    TMap<FString, FKGMapTagWidgetEntry> TagWidgets;
#pragma endregion MapTagLyaer
};
