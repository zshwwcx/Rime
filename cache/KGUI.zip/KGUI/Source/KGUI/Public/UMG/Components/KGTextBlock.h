// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "IKGTextCountDown.h"
#include "Components/TextBlock.h"
#include "UMG/Blueprint/KGPreviewColor.h"
#include "UMG/Blueprint/KGTextBlockStyle.h"
#include "Slate/Text/SKGTextBlock.h"
#include "Widgets/SInvalidationPanel.h"

#include "KGTextBlock.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FKGOnTextBlockCountDownFinishedDynamic);

class UDataTable;
/**
 * C7文本组件，支持对文本字符间距K帧
 * 为了不影响引擎代码，以子类的方式实现
 */
UCLASS(DisplayName = "Text Block (KGUI)", meta = (ToolTip = "文本"))
class KGUI_API UKGTextBlock : public UTextBlock, public IKGTextCountDown
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif

public:
	//Modify By Bruce Start 2023.8.28
	/**
	* Sets Letter Spacing
	* @param InLetterSpacing		The new Letter Spacing
	*/
	UFUNCTION(BlueprintCallable, Category = "Appearance")
	void SetLatterSpaceAnim(float InLetterSpacing);
	//Modify By Bruce End 2023.8.28

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Appearance")
	bool IsBindColor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Appearance", meta = (EditCondition = "IsBindColor"))
	UDataTable* ColorTable;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Appearance", meta = (EditCondition = "IsBindColor", IsText = true))
	FKGPreviewColor PreviewColor;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Appearance", meta = (EditCondition = "IsBindColor"))
	FName ColorName;
	//@C7 Code Begin (@pengwei03)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetAlwaysEllipsis", Category = "Clipping", AdvancedDisplay)
	uint8 AlwaysEllipsis : 1;
	//@C7 Code End (@pengwei03)
	virtual void PostInitProperties() override;
	virtual void PostLoad() override;
	virtual void SynchronizeProperties() override;
	virtual void Serialize(FArchive& Ar) override;
#if WITH_EDITOR
	virtual void OnCreationFromPalette() override;
	virtual bool CanEditChange(const FProperty* InProperty) const override;
#endif

	UFUNCTION(BlueprintCallable, Category="Text Style")
	void SetTextStyle(UKGTextBlockStyle* StyleAsset);

	//@C7 Code Begin (@pengwei03)
	// RightEllipsis
	bool GetAlwaysEllipsis() const;
	
	UFUNCTION(BlueprintCallable, Category = "Appearance")
	void SetAlwaysEllipsis(bool InAlwaysEllipsis);

	//Compute And Get TextBlock Size
	UFUNCTION(BlueprintCallable)
	FVector2D GetTextScale(const FText& inText, bool useViewportScale);
	//Adaptive Line
	UFUNCTION(BlueprintCallable)
	void SetTextAdaptively(const FText& inText);
	//@C7 Code End (@pengwei03)

	//Get the actual number of text lines
	UFUNCTION(BlueprintCallable)
	int32 GetTextLineNum();
	
	UFUNCTION(BlueprintCallable)
	bool GetRunLocationAndSizeByRange(int32 BeginIndex, int32 EndIndex, FVector2D& OutLocation, FVector2D& OutSize);

	virtual void SetText(FText InText) override;

protected:
	//Modify By Bruce Start 2023.8.28
	/**专门给动效使用*/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Performance", AdvancedDisplay)
	float LatterSpaceAnim;
	//Modify By Bruce End 2023.8.28

	UPROPERTY(EditAnywhere, BlueprintReadWrite, BlueprintSetter = "SetTextStyle",Category = "Text Style")
	TObjectPtr<class UKGTextBlockStyle> Style;

	void UpdateFromStyle();

	template <typename SlateWidgetType = SKGTextBlock>
	TSharedRef<SWidget> RebuildWidgetInternal(const ANSICHAR* SlateWidgetTypeName)
	{
		if (bWrapWithInvalidationPanel && !IsDesignTime())
		{
			MyTextBlock =
				SNew_WithTypeName(SlateWidgetType, SlateWidgetTypeName)
				.SimpleTextMode(bSimpleTextMode);
			TSharedPtr<SWidget> RetWidget = SNew(SInvalidationPanel)
			[
				MyTextBlock.ToSharedRef()
			];
			return RetWidget.ToSharedRef();
		}
		else
		{
			MyTextBlock =
				SNew_WithTypeName(SlateWidgetType, SlateWidgetTypeName)
				.SimpleTextMode(bSimpleTextMode);

			//if (IsDesignTime())
			//{
			//	return SNew(SOverlay)

			//	+ SOverlay::Slot()
			//	[
			//		MyTextBlock.ToSharedRef()
			//	]

			//	+ SOverlay::Slot()
			//	.VAlign(VAlign_Top)
			//	.HAlign(HAlign_Right)
			//	[
			//		SNew(SImage)
			//		.Image(FCoreStyle::Get().GetBrush("Icons.Warning"))
			//		.Visibility_UObject(this, &ThisClass::GetTextWarningImageVisibility)
			//		.ToolTipText(LOCTEXT("TextNotLocalizedWarningToolTip", "This text is marked as 'culture invariant' and won't be gathered for localization.\nYou can change this by editing the advanced text settings."))
			//	];
			//}

			return MyTextBlock.ToSharedRef();
		}
	}

	TSharedPtr<SKGTextBlock> GetEnhancedWidget() const { return StaticCastSharedPtr<SKGTextBlock>(MyTextBlock); }

	virtual TSharedRef<SWidget> RebuildWidget() override;

	#pragma region 计时动态效果
public:
	UFUNCTION(BlueprintCallable)
	virtual void SetCountDownTimeFormat(const FString& Format) override;

	UFUNCTION(BlueprintCallable)
	virtual void SetCountDownTimeFormatByCondition(
		double LowerBoundSeconds, EKGCountDownConditionIntervalType LowerIntervalType,
		double UpperBoundSeconds, EKGCountDownConditionIntervalType UpperIntervalType,
		const FString& Format
	) override;

	UFUNCTION(BlueprintCallable)
	virtual void SetCountDownTimeFormatByFirstNonzeroUnit(FName FirstNonzeroUnitName, const FString& Format) override;

	UFUNCTION(BlueprintCallable)
	virtual void ClearCountDownTimeFormats() override;

	UFUNCTION(BlueprintCallable)
	virtual void PlayCountDown(double FromSeconds, double ToSeconds) override;

	UFUNCTION(BlueprintCallable)
	virtual void StopCountDown() override;

	UFUNCTION(BlueprintCallable)
	virtual bool IsCountDownPlaying() const override;

protected:
	virtual void BeginDestroy() override;
	virtual void HandleOnCountDownFinished() override;
	virtual void HandleOnCountDownTextChanged(FText&& Text) override;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Count Down Finished"))
	FKGOnTextBlockCountDownFinishedDynamic BP_OnCountDownFinished;

	#pragma endregion
};