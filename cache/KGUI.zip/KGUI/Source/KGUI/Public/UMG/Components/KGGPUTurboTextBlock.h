#pragma once

#include "CoreMinimal.h"
#include "Components/GPUTurboTextBlock.h"

#include "KGGPUTurboTextBlock.generated.h"

UCLASS(DisplayName = "Text Block (GPU Turbo)")
class KGUI_API UKGGPUTurboTextBlock : public UGPUTurboTextBlock
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("GPU Turbo")); }
	virtual void OnCreationFromPalette() override;
#endif
};