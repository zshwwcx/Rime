#pragma once

#include "KGListView.h"
#include "Slate/Views/SKGTileView.h"

#include "KGTileView.generated.h"

UCLASS(DisplayName = "Tile View (KGUI)", MinimalAPI, meta = (LuaComponent = "Framework.KGFramework.KGUI.Component.UIListView.UIListView", ToolTip = "网格列表"))
class UKGTileView : public UKGListView
{
public:
	using ItemType = TSharedPtr<FKGListItem>;

private:
	GENERATED_BODY()

public:
	KGUI_API UKGTileView(const FObjectInitializer& ObjectInitializer);
	KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	UFUNCTION(BlueprintCallable, Category = TileView)
	KGUI_API void SetEntryHeight(float NewHeight);

	UFUNCTION(BlueprintCallable, Category = TileView)
	KGUI_API void SetEntryWidth(float NewWidth);

	UFUNCTION(BlueprintPure, Category = TileView)
	float GetEntryHeight() const { return EntryHeight; }

	UFUNCTION(BlueprintPure, Category = TileView)
	float GetEntryWidth() const { return EntryWidth; }

	UFUNCTION(BlueprintCallable, Category = TileView)
	int GetNumItemsPerLine() const;

	UFUNCTION(BlueprintCallable, Category = TileView)
	bool TryGetItemCoordinatesFromWidget(UUserWidget* ItemWidget, UPARAM(ref) FIntPoint& OutCoordinates);

protected:
	UPROPERTY(EditAnywhere, Category = ListEntries)
	float EntryHeight = 128.f;

	UPROPERTY(EditAnywhere, Category = ListEntries)
	float EntryWidth = 128.f;

	UPROPERTY(EditAnywhere, Category = ListEntries)
	EListItemAlignment TileAlignment;

	UPROPERTY(EditAnywhere, Category = ListEntries, meta = (EditCondition = "IsAligned", ClampMin = 0, ClampMax = 1))
	float OverallAlignment;

	UPROPERTY(EditAnywhere, Category = Navigation)
	bool bWrapHorizontalNavigation = false;

private:
	UFUNCTION()
	KGUI_API bool IsAligned() const;

	UPROPERTY(EditAnywhere, Category = ListEntries, meta = (EditCondition = "IsAligned"))
	bool bEntrySizeIncludesEntrySpacing = true;

protected:
	template <template<typename> class TileViewT = SKGTileView>
	TSharedRef<TileViewT<ItemType>> ConstructTileView()
	{
		FTileViewConstructArgs Args;
		Args.bAllowFocus = bIsFocusable;
		Args.SelectionMode = SelectionMode;
		Args.bClearSelectionOnClick = bClearSelectionOnClick;
		Args.ConsumeMouseWheel = ConsumeMouseWheel;
		Args.bReturnFocusToSelection = bReturnFocusToSelection;
		Args.TileAlignment = TileAlignment;
		Args.OverallAlignment = OverallAlignment;
		Args.bWrapDirectionalNavigation = bWrapHorizontalNavigation;
		Args.Orientation = Orientation;
		Args.ScrollBarStyle = &ScrollBarStyle;

		if (IsAligned() && !bEntrySizeIncludesEntrySpacing)
		{
			Args.EntryWidth = GetTotalEntryWidth();
			Args.EntryHeight = GetTotalEntryHeight();
		}
		else
		{
			Args.EntryWidth = EntryWidth;
			Args.EntryHeight = EntryHeight;
		}

		MyListView = MyTileView = ITypedUMGListView<ItemType>::ConstructTileView<TileViewT, SKGTileView>(this, SlateListItems, Args);
		MyTileView->SetOnEntryInitialized(SKGListView<ItemType>::FOnEntryInitialized::CreateUObject(this, &UKGTileView::HandleOnEntryInitializedInternal));
		MyTileView->SetOnClicked(SKGListView<ItemType>::FOnListViewClicked::CreateUObject(this, &UKGTileView::HandleOnClickedInternal));

		MyTileView->SetOnSelectionsChanged(SKGListView<ItemType>::FKGOnSelectionsChanged::CreateUObject(this, &UKGTileView::HandleOnSelectionsChangedInternal));
		MyTileView->SetOnItemSelectionChanged(SKGListView<ItemType>::FKGOnItemSelectionChanged::CreateUObject(this, &UKGTileView::HandleOnItemSelectionChangedInternal));

		MyTileView->SetOnItemsRefreshed(SKGListView<ItemType>::FKGOnItemsRefreshed::CreateUObject(this, &UKGTileView::HandleOnItemsRefreshed));
		MyTileView->SetOnUserScrollingStarted(FSimpleDelegate::CreateUObject(this, &UKGTileView::HandleOnUserScrollingStarted));
		MyTileView->SetOnUserScrollingEnded(FSimpleDelegate::CreateUObject(this, &UKGTileView::HandleOnUserScrollingEnded));
		MyTileView->SetOnOverscrollAmountChanged(FSimpleDelegate::CreateUObject(this, &UKGTileView::HandleOnOverscrollAmountChanged));

		MyTileView->SetScrollbarDisabledVisibility(EVisibility::Hidden);

		RebuildBackground();

		return StaticCastSharedRef<TileViewT<ItemType>>(MyTileView.ToSharedRef());
	}

	KGUI_API float GetTotalEntryHeight() const;
	KGUI_API float GetTotalEntryWidth() const;

	KGUI_API virtual TSharedRef<STableViewBase> RebuildListWidget() override;
	KGUI_API virtual FMargin GetDesiredEntryPadding(ItemType Item) const override;

protected:
	TSharedPtr<SKGTileView<ItemType>> MyTileView;

#pragma region 子项实例参数配置

public:
	virtual bool IsEntryWidgetAlignmentAvailable(EOrientation InOrientation, int Level) const override { return false; }
	virtual bool IsLengthOverrideAvailable(EOrientation InOrientation, int Level, bool bFill) const override { return false; }

#pragma endregion
};