#pragma once

#include "CoreMinimal.h"
#include "AkGameObject.h"
#include "C7/KGUITickableSubsystem.h"
#include "Components/ContentWidget.h"
#include "Components/ProgressBar.h"
#include "Slate/Components/SKGProgressBar.h"

#include "KGProgressBar.generated.h"

class SKGProgressBar;
struct FKGBrushTextureLoader;


UCLASS(MinimalAPI)
class UKGProgressBarSlot : public UPanelSlot
{
    GENERATED_UCLASS_BODY()
public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter="SetPadding", Category="Layout|ProgressBar Slot")
    FMargin Padding;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter="SetHorizontalAlignment", Category="Layout|ProgressBar Slot")
    TEnumAsByte<EHorizontalAlignment> HorizontalAlignment;
	
    /** The alignment of the object vertically. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter="SetVerticalAlignment", Category="Layout|ProgressBar Slot")
    TEnumAsByte<EVerticalAlignment> VerticalAlignment;

    KGUI_API FMargin GetPadding() const;

    UFUNCTION(BlueprintCallable, Category="Layout|Button Slot")
    KGUI_API void SetPadding(FMargin InPadding);

    KGUI_API EHorizontalAlignment GetHorizontalAlignment() const;

    UFUNCTION(BlueprintCallable, Category="Layout|Button Slot")
    KGUI_API void SetHorizontalAlignment(EHorizontalAlignment InHorizontalAlignment);

    KGUI_API EVerticalAlignment GetVerticalAlignment() const;

    UFUNCTION(BlueprintCallable, Category="Layout|Button Slot")
    KGUI_API void SetVerticalAlignment(EVerticalAlignment InVerticalAlignment);

    // UPanelSlot interface
    KGUI_API virtual void SynchronizeProperties() override;
    // End of UPanelSlot interface

    /** Builds the underlying slot for the slate button. */
    KGUI_API void BuildSlot(TSharedRef<SKGProgressBar> InProgressBar);

    KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;

private:
    TWeakPtr<SKGProgressBar> ProgressBar;
};

/*
 * UKGProgressBar
 */
UCLASS(DisplayName = "Progress Bar (KGUI)", meta = (ToolTip = "进度条"))
class UKGProgressBar : public UContentWidget, public FKGUITickableObjectBase
{
    GENERATED_UCLASS_BODY()
public:
    /** The progress bar style */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category="Style", meta=( DisplayName="Style" ))
    FProgressBarStyle WidgetStyle;
    
    /** The progress bar style */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category="Style", meta = (EditCondition="bHasThumb", EditConditionHides))
    FSlateBrush ThumbImage;
    
    /** Used to determine the fill position of the progress bar ranging 0..1 */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, FieldNotify, Getter, Setter, BlueprintSetter="SetPercent", Category="Progress", meta = (UIMin = "0", UIMax = "1"))
    float Percent = 1;
    
    /** Defines the direction in which the progress bar fills */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category="Progress")
    EKGProgressBarFillType BarFillType;
    
    /** Defines the visual style of the progress bar fill - scale or mask */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category="Progress")
    TEnumAsByte<EProgressBarFillStyle::Type> BarFillStyle;
    
    /** */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, FieldNotify, Getter="UseMarquee", Setter="SetIsMarquee", BlueprintSetter="SetIsMarquee", Category="Progress")
    bool bIsMarquee;
    
    /** */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category="Progress")
    FVector2D BorderPadding;

    /** A bindable delegate to allow logic to drive the text of the widget */
    UPROPERTY()
    FGetFloat PercentDelegate;
    
    /** Fill Color and Opacity */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, FieldNotify, Getter, Setter, BlueprintSetter="SetFillColorAndOpacity", Category="Appearance")
    FLinearColor FillColorAndOpacity;

    /** */
    UPROPERTY()
    FGetLinearColor FillColorAndOpacityDelegate;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, Category="Progress")
    float RefreshRate;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Progress")
    float CircularThickness = 20.f;

    UPROPERTY(VisibleAnywhere, Category="Progress", meta=(EditCondition=false, EditConditionHides))
    float CircularRadius = 100.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Progress", meta = (UIMin = "0", UIMax = "360"))
    float CircularStartAngle = 0.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Progress", meta = (UIMin = "0", UIMax = "360"))
    float CircularEndAngle = 360.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Progress")
    bool bHasThumb = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Progress", meta = (EditCondition="bHasThumb", EditConditionHides))
    FVector2D ThumbOffset;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Progress", meta = (EditCondition="bHasThumb", EditConditionHides))
    bool bAlwaysShowThumb = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Progress", Getter="GetUseAnimOnValueChanged", Setter="SetUseAnimOnValueChanged")
    bool bUseAnimOnValueChanged = false;

    UPROPERTY(VisibleAnywhere, Category="Progress")
    float CurPercent = 0.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Progress", meta = (EditCondition="bUseAnimOnValueChanged"))
    float AnimSpeed = 5.f;
    
public:
    /** */
    KGUI_API const FProgressBarStyle& GetWidgetStyle() const;

    /**/
    KGUI_API void SetWidgetStyle(const FProgressBarStyle& InStyle);

    KGUI_API const FSlateBrush& GetThumbImage() const;
    KGUI_API void SetThumbImage(const FSlateBrush& InThumbImage);

    /** */
    KGUI_API float GetPercent() const;

    /** Sets the current value of the ProgressBar. */
    UFUNCTION(BlueprintCallable, Category="Progress")
    KGUI_API void SetPercent(float InPercent);

	UFUNCTION(BlueprintCallable, Category="Progress")
	KGUI_API float GetCurPercentForAnim() const { return CurPercent; }

	UFUNCTION(BlueprintCallable, Category="Progress")
	KGUI_API void SetPercentWithDuration(float InPercent, float InDuration);

    /** */
    KGUI_API EKGProgressBarFillType GetBarFillType() const;

    /** */
    KGUI_API void SetBarFillType(EKGProgressBarFillType InBarFillType);

    /** */
    KGUI_API EProgressBarFillStyle::Type GetBarFillStyle() const;

    /** */
    KGUI_API void SetBarFillStyle(EProgressBarFillStyle::Type InBarFillStyle);

    /** */
    KGUI_API bool UseMarquee() const;

    /** Sets the progress bar to show as a marquee. */
    UFUNCTION(BlueprintCallable, Category="Progress")
    KGUI_API void SetIsMarquee(bool InbIsMarquee);

    /** */
    KGUI_API FVector2D GetBorderPadding() const;

    /** */
    KGUI_API void SetBorderPadding(FVector2D InBorderPadding);

    /** */
    KGUI_API FLinearColor GetFillColorAndOpacity() const;

    /** Sets the fill color of the progress bar. */
    UFUNCTION(BlueprintCallable, Category="Progress")
    KGUI_API void SetFillColorAndOpacity(FLinearColor InColor);

    UFUNCTION(BlueprintCallable, Category="Progress")
    KGUI_API float GetRefreshRate() const { return RefreshRate; }

    UFUNCTION(BlueprintCallable, Category="Progress")
    KGUI_API void SetRefreshRate(float InRefreshRate);

    UFUNCTION(BlueprintCallable, Category="Progress")
    KGUI_API void SetUseAnimOnValueChanged(bool bInUseAnim);

    UFUNCTION(BlueprintCallable, Category="Progress")
    KGUI_API bool GetUseAnimOnValueChanged() const { return bUseAnimOnValueChanged; }

    UFUNCTION(BlueprintCallable, Category="Progress")
    KGUI_API void SetCurPercentForAnim(float InPercent) { CurPercent = InPercent; }
    public:
    //~ Begin UWidget Interface
    KGUI_API virtual void SynchronizeProperties() override;
    //~ End UWidget Interface

    //~ Begin UVisual Interface
    KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;
    //~ End UVisual Interface

#if WITH_EDITOR
    //~ Begin UWidget Interface
    virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
    KGUI_API virtual void OnCreationFromPalette() override;
    //~ End UWidget Interface
#endif

    KGUI_API virtual void Tick(float DeltaTime) override;

    KGUI_API virtual bool IsTickable() const override 
    {
        return !HasAnyFlags(RF_BeginDestroyed | RF_ClassDefaultObject | RF_ArchetypeObject) && IsValidChecked(this) && IsVisible() && bUseAnimOnValueChanged;
    }

protected:
    // UPanelWidget
    virtual UClass* GetSlotClass() const override;
    virtual void OnSlotAdded(UPanelSlot* Slot) override;
    virtual void OnSlotRemoved(UPanelSlot* InSlot) override;
    // End UPanelWidget
    
    /** Native Slate Widget */
    TSharedPtr<SKGProgressBar> MyProgressBar;
	float StartPercent = 1.f;
	float Duration = 0.f;
	float CurTime = 0.f;
	bool bHasDuration = false;

    //~ Begin UWidget Interface
    KGUI_API virtual TSharedRef<SWidget> RebuildWidget() override;
    //~ End UWidget Interface

    PROPERTY_BINDING_IMPLEMENTATION(FSlateColor, FillColorAndOpacity);

public:
    UFUNCTION(BlueprintCallable)
    void SetBackgroundBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize);

    UFUNCTION(BlueprintCallable)
    void SetFillBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize);

    UFUNCTION(BlueprintCallable)
    void SetThumbBrushFromSoftObject(const FString& InSoftObjectPath, bool bMatchSize);

    UFUNCTION()
    void OnAbsoluteSizeChanged(const FVector2f& NewSize);
private:
    TSharedPtr<FKGBrushTextureLoader> BackgroundBrushTextLoader;
    TSharedPtr<FKGBrushTextureLoader> FillBrushTextLoader;
    TSharedPtr<FKGBrushTextureLoader> ThumbBrushLoader;
};
