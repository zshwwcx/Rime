// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "KGRichTextSettings.generated.h"

/**
 * 
 */
UCLASS(Config = Game, defaultconfig, DisplayName = "KGUI Rich Text")
class KGUI_API UKGRichTextSettings : public UDeveloperSettings
{
	GENERATED_BODY()
public:
	UPROPERTY(Config,Category="Rich Text",EditAnywhere)
	FString ColorTablesDir="Default";

	UPROPERTY(Config,Category="Rich Text",EditAnywhere, meta = (AllowedClasses="DataTable",RequiredAssetDataTags = "RowStructure=RichImageRow"))
	FSoftObjectPath ImgSet;
	
	UPROPERTY(Config,Category="Rich Text",EditAnywhere, meta = (AllowedClasses="DataTable",RequiredAssetDataTags = "RowStructure=RichTextStyleRow"))
	FSoftObjectPath TextStyleSet;
};
