// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/Slider.h"
#include "KGSlider.generated.h"
class SSlider;
/**
 * 
 */
UCLASS(DisplayName = "Slider (KGUI)", meta = (ToolTip = "滑条"))
class KGUI_API UKGSlider : public USlider
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif

	/** Sets the current value of the slider. */
	UFUNCTION(BlueprintCallable, Category = "Behavior")
	void SetValueWithoutNotify(float InValue);

	UFUNCTION()
	void PostWidgetAudio();

protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

#if WITH_EDITOR
	virtual void OnCreationFromPalette() override;
#endif

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = KGAudio, DisplayName="点击音效")
	TSoftObjectPtr<class UAkAudioEvent> WidgetAkEvent;
};
