#pragma once

#include "CoreMinimal.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "UMG/Blueprint/KGRedPointOverlaySlotData.h"
#include "UMG/Blueprint/KGRedPointCanvasSlotData.h"

#include "KGRedPointUserWidget.generated.h"

UENUM(BlueprintType)
enum class EKGRedPointState : uint8
{
	None UMETA(DisplayName = "None"),
	Overlay UMETA(DisplayName = "Overlay"),
	Canvas UMETA(DisplayName = "Canvas"),
};


UCLASS(meta=( DontUseGenericSpawnObject="True", DisableNativeTick))
class KGUI_API UKGRedPointUserWidget : public UKGUserWidget
{
	GENERATED_BODY()

public:
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

protected:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Use Red Point"), Category = "Red Point Settings")
	EKGRedPointState RedPointState;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Target Widget", GetOptions = "GetCanvasAndOverlay", EditCondition = "RedPointState != EKGRedPointState::None", EditConditionHides), Category = "Red Point Settings")
	FString WidgetName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Red Point Class", MetaClass = "KGUserWidget", EditCondition = "RedPointState != EKGRedPointState::None", EditConditionHides), Category = "Red Point Settings")
	FSoftClassPath RedPointClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Display Scale", MetaClass = "KGUserWidget", EditCondition = "RedPointState != EKGRedPointState::None", EditConditionHides), Category = "Red Point Settings")
	float DisplayScale = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Overlay Layout", EditCondition = "RedPointState == EKGRedPointState::Overlay", EditConditionHides), Category = "Red Point Settings")
	FKGRedPointOverlaySlotData RedPointOverlayLayout;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Canvas Layout", EditCondition = "RedPointState == EKGRedPointState::Canvas", EditConditionHides), Category = "Red Point Settings")
	FKGRedPointCanvasSlotData RedPointCanvasLayout;

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "Show Red Point In Preview", EditCondition = "RedPointState != EKGRedPointState::None", EditConditionHides), Category = "Red Point Settings")
	bool bShowRedPointInPreview;
#endif

#if WITH_EDITOR

	TSharedPtr<SWidget> SContent;

	virtual void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;

	void RebuildRedPoint();

	void ClearRedPoint();

	void CheckRedPointIsValid();

	UUserWidget* InstantiateRedPoint();


	UFUNCTION()
	TArray<FString> GetCanvasAndOverlay();

	virtual TSharedRef<SWidget> RebuildWidget() override;
#endif
};