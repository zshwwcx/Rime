#pragma once

#include "Components/ListViewBase.h"

#include "Slate/Views/SKGListView.h"
#include "UMG/Blueprint/KGListViewShapeStyle.h"
#include "UMG/Blueprint/KGWidgetAnimationName.h"
#include "UMG/StyleSheet/KGStyleSheetRelativeView.h"

#include "KGListView.generated.h"

class UKGListView;

struct FKGListItem : TSharedFromThis<FKGListItem>
{
public:
	virtual ~FKGListItem() = default;

	void SetDesiredEntryClassIndex(int InDesiredEntryClassIndex)
	{
		DesiredEntryClassIndex = InDesiredEntryClassIndex;
	}

	int GetDesiredEntryClassIndex() const { return DesiredEntryClassIndex; }

private:
	int DesiredEntryClassIndex = INDEX_NONE;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGSimpleListItemEventDynamic, int32, Index);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnListEntryInitializedDynamic, int32, Index, UUserWidget*, Widget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnListItemSelectionChangedDynamic, int32, Index, bool, bIsSelected);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnListSelectionsChangedDynamic, const TArray<int32>&, Indexes, ESelectInfo::Type, SelectInfo);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnItemIsHoveredChangedDynamic, int32, Index, bool, bIsHovered);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnListItemScrolledIntoViewDynamic, int32, Index, UUserWidget*, Widget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnListViewScrolledDynamic, float, ItemOffset, float, DistanceRemaining);
DECLARE_DYNAMIC_DELEGATE_RetVal_OneParam(int, FKGOnGetEntryClassIndexForItemDynamic, int32, Index);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnListItemClickedDynamic, int32, Index);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnListItemDoubleClickedDynamic, int32, Index);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnEdgeIntersectionListItemChangedDynamic, int32, Index);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnIsEdgeReachedChangedDynamic, bool, bReached);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnOverscrollUpdatedDynamic, float, Overscroll);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnItemsRefreshedDynamic, const FGeometry&, Geometry);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnListViewScrollHintGeneratedDynamic, EKGListViewScrollHintType, ScrollHintType, UUserWidget*, Widget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FKGOnUserScrollingStartedDynamic);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FKGOnUserScrollingEndedDynamic);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FKGOnListViewClickedDynamic);

UENUM(BlueprintType)
enum class EKGItemAnimationTriggerStyle : uint8
{
	Linear,
	Chessboard,
	Random,
	LineWise,
	Blueprint = 255,
};


UENUM(BlueprintType)
enum class EKGItemAnimationState : uint8
{
	Unknown,
	Preparing,
	Playing,
	Finished,
};

USTRUCT(BlueprintType)
struct FKGItemAnimationEntryStyle
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "bEnabled", EditConditionHides))
	FKGWidgetAnimationName AnimationName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "bEnabled", EditConditionHides))
	EKGItemAnimationTriggerStyle TriggerStyle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "bEnabled && TriggerStyle != EKGItemAnimationTriggerStyle::Blueprint", EditConditionHides))
	float Offset = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "bEnabled && TriggerStyle != EKGItemAnimationTriggerStyle::Blueprint", EditConditionHides))
	float Interval = 0;

	static FKGItemAnimationEntryStyle Default;
};

USTRUCT(BlueprintType)
struct FKGItemAnimationConfiguration
{
	GENERATED_BODY()

public:
	UPROPERTY(BlueprintReadWrite)
	TArray<FKGItemAnimationEntryStyle> EntryStyles;

	void SetSingleEntryStyle(const FKGItemAnimationEntryStyle& EntryStyle);
	void SetEntryStyleArray(const TArray<FKGItemAnimationEntryStyle>& EntryStyles);

	UPROPERTY(BlueprintReadWrite)
	float TickInterval = 0.02;  // 通过调整这个值减轻可能的Tick性能开销

	void RefreshRandomSeed() const;

	int32 GetRandomSeed() const { return RandomSeed; }

	void Invalidate() { bValid = false; }
	bool IsValid() const { return bValid; }

private:

	UPROPERTY(Transient)
	bool bValid = false;

	mutable int32 RandomSeed = 0;
};

USTRUCT(BlueprintType)
struct FKGEntryWidgetConfiguration
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<EHorizontalAlignment> HorizontalAlignment = EHorizontalAlignment::HAlign_Fill;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<EVerticalAlignment> VerticalAlignment = EVerticalAlignment::VAlign_Fill;

	UPROPERTY(EditAnywhere, meta = (editcondition = "bOverride_WidthOverride"))
	float WidthOverride = 0.f;

	UPROPERTY(EditAnywhere, meta = (editcondition = "bOverride_HeightOverride"))
	float HeightOverride = 0.f;

	UPROPERTY(EditAnywhere)
	TObjectPtr<UKGStyleSheetPreset> StyleSheetPreset = nullptr;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_WidthOverride : 1 = false;

	UPROPERTY(EditAnywhere, meta = (InlineEditConditionToggle))
	uint8 bOverride_HeightOverride : 1 = false;
};

UCLASS(DisplayName = "List View (KGUI)", MinimalAPI, meta = (LuaComponent = "Framework.KGFramework.KGUI.Component.UIListView.UIListView", ToolTip = "列表"))
class UKGListView : public UListViewBase, public ITypedUMGListView<TSharedPtr<FKGListItem>>, public IKGShapedListView
{
public:
	friend struct FKGListViewItemAnimationPlayer;

	using ItemType = TSharedPtr<FKGListItem>;

private:
	GENERATED_BODY()
	IMPLEMENT_TYPED_UMG_LIST(ItemType, MyListView)

public:
	KGUI_API UKGListView(const FObjectInitializer& Initializer);

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
	virtual void OnCreationFromPalette() override;
#endif

protected:
	KGUI_API virtual void SynchronizeProperties() override;
	KGUI_API virtual TSharedRef<STableViewBase> RebuildListWidget() override;
	KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	KGUI_API virtual UUserWidget& OnGenerateEntryWidgetInternal(ItemType Item, TSubclassOf<UUserWidget> DesiredEntryClass, const TSharedRef<STableViewBase>& OwnerTable) override;
	KGUI_API virtual TSharedRef<ITableRow> HandleGenerateRow(ItemType Item, const TSharedRef<STableViewBase>& OwnerTable) override;
	KGUI_API virtual void HandleOnEntryInitializedInternal(ItemType Item, const TSharedRef<ITableRow>& TableRow);
	KGUI_API virtual void NativeOnEntryReleased(UUserWidget* EntryWidget) override;
	KGUI_API virtual void OnSelectionChangedInternal(ItemType FirstSelectedItem) override;
	KGUI_API virtual void OnItemScrolledIntoViewInternal(ItemType ListItem, UUserWidget& EntryWidget) override;
	KGUI_API virtual void OnListViewScrolledInternal(float ItemOffset, float DistanceRemaining) override;
	KGUI_API virtual void HandleOnSelectionsChangedInternal(const SKGListView<ItemType>::TItemSet& SelectedItems, ESelectInfo::Type SelectInfo);
	KGUI_API virtual void HandleOnItemSelectionChangedInternal(const NullableItemType& Item, bool bSelected);
	KGUI_API virtual void OnItemClickedInternal(ItemType ListItem) override;
	KGUI_API virtual void OnItemDoubleClickedInternal(ItemType ListItem) override;
	KGUI_API virtual void HandleItemScrolledIntoView(ItemType Item, const TSharedPtr<ITableRow>& InWidget) override;
	KGUI_API virtual void HandleOnItemsRefreshed(const FGeometry& AllottedGeometry);
	KGUI_API virtual void HandleOnUserScrollingStarted();
	KGUI_API virtual void HandleOnUserScrollingEnded();
	KGUI_API virtual void HandleOnOverscrollAmountChanged();

	UUserWidget* UserWidgetFromItem(const ItemType& Item) const;

	KGUI_API virtual FMargin GetDesiredEntryPadding(ItemType Item) const override;

	template <typename RowWidgetT = UUserWidget>
	RowWidgetT* GetEntryWidgetFromItem(const ItemType& Item) const
	{
		return Item ? ITypedUMGListView<ItemType>::GetEntryWidgetFromItem<RowWidgetT>(const_cast<ItemType&>(Item)) : nullptr;
	}

	template <template<typename> class ListViewT = SKGListView>
	TSharedRef<ListViewT<ItemType>> ConstructListView()
	{
		FListViewConstructArgs Args;
		Args.bAllowFocus = bIsFocusable;
		Args.SelectionMode = SelectionMode;
		Args.bClearSelectionOnClick = bClearSelectionOnClick;
		Args.ConsumeMouseWheel = ConsumeMouseWheel;
		Args.bReturnFocusToSelection = bReturnFocusToSelection;
		Args.Orientation = Orientation;
		Args.ListViewStyle = &WidgetStyle;
		Args.ScrollBarStyle = &ScrollBarStyle;

		MyListView = ITypedUMGListView<ItemType>::ConstructListView<ListViewT>(this, SlateListItems, Args);
		MyListView->SetOnEntryInitialized(SKGListView<ItemType>::FOnEntryInitialized::CreateUObject(this, &UKGListView::HandleOnEntryInitializedInternal));
		MyListView->SetOnClicked(SKGListView<ItemType>::FOnListViewClicked::CreateUObject(this, &UKGListView::HandleOnClickedInternal));

		MyListView->SetOnSelectionsChanged(SKGListView<ItemType>::FKGOnSelectionsChanged::CreateUObject(this, &UKGListView::HandleOnSelectionsChangedInternal));
		MyListView->SetOnItemSelectionChanged(SKGListView<ItemType>::FKGOnItemSelectionChanged::CreateUObject(this, &UKGListView::HandleOnItemSelectionChangedInternal));

		MyListView->SetOnItemsRefreshed(SKGListView<ItemType>::FKGOnItemsRefreshed::CreateUObject(this, &UKGListView::HandleOnItemsRefreshed));
		MyListView->SetOnUserScrollingStarted(FSimpleDelegate::CreateUObject(this, &UKGListView::HandleOnUserScrollingStarted));
		MyListView->SetOnUserScrollingEnded(FSimpleDelegate::CreateUObject(this, &UKGListView::HandleOnUserScrollingEnded));
		MyListView->SetOnOverscrollAmountChanged(FSimpleDelegate::CreateUObject(this, &UKGListView::HandleOnOverscrollAmountChanged));

		MyListView->SetScrollbarDisabledVisibility(EVisibility::Hidden);

		if (auto Settings = GetDefault<UKGUISettings>())
		{
			MyListView->SetFixScrollItemIntoViewErrorWhenListContentDecreasesAndIsScrolledToTheEnd(
				Settings->bFixScrollItemIntoViewErrorWhenListContentDecreasesAndIsScrolledToTheEnd
			);
		}

		RebuildBackground();

		return StaticCastSharedRef<ListViewT<ItemType>>(MyListView.ToSharedRef());
	}

#if WITH_EDITOR
	KGUI_API virtual void OnRefreshDesignerItems() override;
#endif

	KGUI_API virtual ItemType SpawnItem() const;

public:
	KGUI_API void SetListItems(int Count);

	KGUI_API const TArray<ItemType>& GetListItems() const { return ListItems; }

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API virtual bool AddItem();

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API virtual bool InsertItem(int32 Index);

protected:
	KGUI_API virtual bool InsertListItem(int32 Index, ItemType Item);
	KGUI_API virtual void OnInsertingListItem(int32 Index, ItemType Item) {}

	KGUI_API virtual bool RemoveListItem(int32 Index);
	KGUI_API virtual void OnListItemRemoved(int32 Index) {}

public:
	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API virtual bool RemoveItem(int32 Index);

	KGUI_API void RemoveItemInternal(ItemType ItemToBeRemoved);

	KGUI_API ItemType GetItemAt(int32 Index) const;

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API int32 GetNumItems() const;

	KGUI_API int32 GetIndexForItem(ItemType Item) const;

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API void ClearListItems();

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API bool IsRefreshPending() const;

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API void ScrollIndexIntoView(int32 Index, float Alignment);

	KGUI_API void SetSelectedItem(ItemType Item);

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API void SetSelectedIndex(int32 Index);

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API void NavigateToIndex(int32 Index);

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Set Selected Item"))
	KGUI_API void BP_SetSelectedItem(int32 Index);

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Set Item Selection"))
	KGUI_API void BP_SetItemSelection(int32 Index, bool bSelected);

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Clear Selection"))
	KGUI_API void BP_ClearSelection();

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Get Num Items Selected"))
	KGUI_API int32 BP_GetNumItemsSelected() const;

	UFUNCTION(BlueprintCallable, BlueprintPure = false, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "GetSelectedItems"))
	KGUI_API bool BP_GetSelectedItems(TArray<int32>& Indexes) const;

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Is Item Visible"))
	KGUI_API bool BP_IsItemVisible(int32 Index) const;

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Navigate To Item"))
	KGUI_API void BP_NavigateToItem(int32 Index);

	void ScrollItemIntoViewInternal(int32 Index, bool bAutoAlignment, float Alignment);

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Scroll Item Into View"))
	KGUI_API void BP_ScrollItemIntoView(int32 Index, float Alignment);

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Scroll Item Into View If Need"))
	KGUI_API void BP_ScrollItemIntoViewIfNeeded(int32 Index);

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Cancel Scroll Into View"))
	KGUI_API virtual void BP_CancelScrollIntoView();

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (AllowPrivateAccess = true, DisplayName = "Set List Items"))
	KGUI_API void BP_SetListItems(int32 Count);

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (DisplayName = "Get Selected Item", AllowPrivateAccess = true))
	KGUI_API int32 BP_GetSelectedItem() const;

	UFUNCTION(BlueprintCallable, Category = ListView, meta = (DisplayName = "Get Scroll Distance Remaining"))
	KGUI_API FVector2D GetScrollDistanceRemaining() const;

	KGUI_API ItemType GetItemFromWidget(UUserWidget* Widget) const;

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API int GetIndexFromWidget(UUserWidget* Widget) const;

	TSharedPtr<SKGListView<ItemType>> GetSlateListView() const { return MyListView; }

public:
	const FTableViewStyle& GetWidgetStyle() const { return WidgetStyle; }
	FTableViewStyle& GetWidgetStyle() { return WidgetStyle; }
	void SetWidgetStyle(const FTableViewStyle& InWidgetStyle) { WidgetStyle = InWidgetStyle; }

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView, meta = (DisplayName = "Style"))
	FTableViewStyle WidgetStyle;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView)
	FScrollBarStyle ScrollBarStyle;

	#pragma region Orientation

public:
	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API EOrientation GetOrientation() const { return Orientation; }

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView)
	TEnumAsByte<EOrientation> Orientation;

	#pragma endregion

	#pragma region Selection Mode

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API void SetSelectionMode(TEnumAsByte<ESelectionMode::Type> SelectionMode);

	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API ESelectionMode::Type GetSelectionMode() const { return SelectionMode; }

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView)
	TEnumAsByte<ESelectionMode::Type> SelectionMode = ESelectionMode::Single;

	#pragma endregion

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView)
	EConsumeMouseWheel ConsumeMouseWheel = EConsumeMouseWheel::WhenScrollingPossible;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView)
	bool bClearSelectionOnClick = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView)
	bool bIsFocusable = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView)
	bool bReturnFocusToSelection = false;

	TArray<ItemType> SlateListItems;  // 和Slate层使用SlateListItems对齐数据（相比于ListItems有可能存在删除中的子项）
	TArray<ItemType> ListItems;       // 和UMG上层使用ListItems对齐数据
	TSharedPtr<SKGListView<ItemType>> MyListView;

	#pragma region Scroll Bar Visibility

	KGUI_API virtual void SetScrollBarVisibility(EKGScrollBarVisibility ScrollBarVisibility);

	UPROPERTY(EditAnywhere, Category = ListView, DisplayName = "Scrollbar Visibility")
	EKGScrollBarVisibility ScrollBarVisibility = EKGScrollBarVisibility::Collapsed;

	#pragma endregion

private:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Getter, Category = ListView, meta = (DesignerRebuild, AllowPrivateAccess = "true"))
	float HorizontalEntrySpacing = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Getter, Category = ListView, meta = (DesignerRebuild, AllowPrivateAccess = "true"))
	float VerticalEntrySpacing = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Getter, Category = ListView, meta = (DesignerRebuild, AllowPrivateAccess = "true"))
	FMargin ContentPadding = 0.f;

	void UpdateEntryPadding(ItemType Item);
	void UpdateEntryPadding(int Index);

public:
	UFUNCTION(BlueprintCallable, Category = ListView)
	float GetHorizontalEntrySpacing() const { return HorizontalEntrySpacing; }

	UFUNCTION(BlueprintCallable, Category = ListView)
	float GetVerticalEntrySpacing() const { return VerticalEntrySpacing; }

	UFUNCTION(BlueprintCallable, Category = ListView)
	FMargin GetContentPadding() const { return ContentPadding; }

protected:
	// 脚本层通过`BP_OnEntryInitialized`监听可见Item的Entry刷新事件，通过`BP_OnEntryReleased`监听Entry的释放
	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Entry Initialized"))
	FKGOnListEntryInitializedDynamic BP_OnEntryInitialized;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Item Selection Changed"))
	FKGOnListItemSelectionChangedDynamic BP_OnItemSelectionChanged;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Selections Changed"))
	FKGOnListSelectionsChangedDynamic BP_OnSelectionsChanged;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Item Scrolled Into View"))
	FKGOnListItemScrolledIntoViewDynamic BP_OnItemScrolledIntoView;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On List View Scrolled"))
	FKGOnListViewScrolledDynamic BP_OnListViewScrolled;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Item Clicked"))
	FKGOnListItemClickedDynamic BP_OnItemClicked;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Item Double Clicked"))
	FKGOnListItemDoubleClickedDynamic BP_OnItemDoubleClicked;

	UFUNCTION(BlueprintCallable, Category = ListView)
	bool IsStartedTouchInteraction() const;

	#pragma region 多类型子项

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListEntries, meta = (DesignerRebuild, AllowPrivateAccess = true/*, MustImplement = "/Script/UMG.UserListEntry"*/, DisplayAfter = "NumDesignerPreviewEntries"))
	TArray<TSubclassOf<UKGUserWidget>> MoreEntryWidgetClasses;

	virtual TSubclassOf<UUserWidget> GetDesiredEntryClassForItem(ItemType Item) const override;

	UFUNCTION(BlueprintCallable)
	void AddMoreEntryWidgetClass(TSubclassOf<UKGUserWidget> Entry);

	UFUNCTION(BlueprintCallable)
	void ClearMoreEntryWidgetClasses();

	UFUNCTION(BlueprintCallable)
	void SetEntryWidgetClass(TSubclassOf<UKGUserWidget> Entry);

	UFUNCTION(BlueprintCallable)
	bool IsMoreEntryWidgetClassesEmpty() const { return MoreEntryWidgetClasses.Num() == 0; }

private:
	UPROPERTY(EditAnywhere, Category = Events, meta = (IsBindableEvent, AllowPrivateAccess = true, DisplayName = "On Get Entry Class For Item"))
	FKGOnGetEntryClassIndexForItemDynamic OnGetEntryClassIndexForItem;

	#pragma endregion

	#pragma region 子项实例参数配置

protected:
	UPROPERTY(EditAnywhere, Category = ListEntries, meta = (DesignerRebuild, AllowPrivateAccess = true, DisplayAfter = "EntryWidgetClass"))
	FKGEntryWidgetConfiguration EntryWidgetConfiguration;

	UPROPERTY(EditAnywhere, Category = ListEntries, meta = (DesignerRebuild, AllowPrivateAccess = true, DisplayAfter = "MoreEntryWidgetClasses", EditConditionHides, EditCondition = "!IsMoreEntryWidgetClassesEmpty()"))
	TArray<FKGEntryWidgetConfiguration> MoreEntryWidgetConfigurations;

	bool TryGetEntryWidgetConfiguration(int EntryClassIndex, FKGEntryWidgetConfiguration& OutEntryWidgetConfiguration) const;

public:
	virtual bool IsEntryWidgetAlignmentAvailable(EOrientation InOrientation, int Level) const { return Orientation != InOrientation; }
	virtual bool IsLengthOverrideAvailable(EOrientation InOrientation, int Level, bool bFill) const
	{
		return Orientation == InOrientation || !bFill;
	}
	virtual int GetItemLevel(ItemType Item) const { return 0; }

	#pragma endregion

	#pragma region Style Sheet

protected:
	UPROPERTY(Transient)
	TMap<FName, FKGStyleSheetRelativeView> StyleSheetRelativeViews;

public:
	const TArray<TSubclassOf<UKGUserWidget>>& GetMoreEntryWidgetClasses() const { return MoreEntryWidgetClasses; }

	UFUNCTION(BlueprintCallable)
	void SetStyleSheetRelativeView(FName EntryClassName, const FKGStyleSheetRelativeView& StyleSheetRelativeView);

	void SetStyleSheetRelativeView(FName EntryClassName, FKGStyleSheetRelativeView&& StyleSheetRelativeView);

	UFUNCTION(BlueprintCallable)
	void RemoveStyleSheetRelativeView(FName EntryClassName);

	#pragma endregion

	#pragma region 子动画播放的工具函数

	static UWidgetAnimation* FindAnimation(UUserWidget* UserWidget, const FKGWidgetAnimationName& AnimationName);

	#pragma endregion

	#pragma region 子项动画

public:
	UFUNCTION(BlueprintCallable)
	KGUI_API virtual void PlayListItemAnimation(const FKGItemAnimationEntryStyle& InEntryStyle);

	UFUNCTION(BlueprintCallable)
	KGUI_API virtual void PlayListItemAnimationWithDefaultConfiguration();

	UFUNCTION(BlueprintCallable)
	KGUI_API virtual void SeekListItemAnimationToStart(const FKGItemAnimationEntryStyle& InEntryStyle);

	UFUNCTION(BlueprintCallable)
	KGUI_API virtual void SeekListItemAnimationToStartWithDefaultConfiguration();

	UFUNCTION(BlueprintCallable)
	KGUI_API virtual void StopListItemAnimation();

protected:

	DECLARE_DYNAMIC_DELEGATE_RetVal_OneParam(double, FKGOnGetListItemAnimationTriggerTime, int, Index);

	KGUI_API void PlayItemAnimationInternal();
	KGUI_API void StopItemAnimationInternal(bool bRefresh = true);

	static bool IsItemAnimationPlaying(UUserWidget* UserWidget, UWidgetAnimation* WidgetAnimation);

	static EKGItemAnimationState GetItemAnimationState(const ItemType& Item, double TriggerTime, double PassedTime, double AnimationDuration);

	EKGItemAnimationState UpdateItemAnimation(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item, double InLastPassedTime, double PassedTime, bool bForce, EKGItemAnimationState SpecificAnimationState);
	void ForceUpdateItemAnimation(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item);
	KGUI_API virtual bool OnItemAnimationTick(const FKGItemAnimationConfiguration& Configuration, double StartTime, bool bForce, EKGItemAnimationState SpecificAnimationState);

	KGUI_API virtual int32 GetLocalItemIndex(const ItemType& Item) const;
	KGUI_API virtual int32 GetLocalNumItemsPerLine(const ItemType& Item) const;
	KGUI_API virtual const FKGItemAnimationEntryStyle& GetItemAnimationEntryStyle(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const;

	double GetItemAnimationTriggerTime_Linear(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const;
	double GetItemAnimationTriggerTime_Chessboard(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const;
	double GetItemAnimationTriggerTime_Random(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const;
	double GetItemAnimationTriggerTime_LineWise(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const;
	KGUI_API virtual double GetItemAnimationTriggerTime_Blueprint(const FKGItemAnimationConfiguration& Configuration, const ItemType& Item) const;

	KGUI_API virtual const FKGItemAnimationEntryStyle& GetDefaultItemAnimationEntryStyle(const ItemType& Item) const;

	UFUNCTION()
	virtual bool IsTreeViewInternal() const { return false; }

	UPROPERTY(Transient)
	FTimerHandle ItemAnimationTimerHandle;

	UPROPERTY(Transient)
	double LastPassedTime = 0;

	UPROPERTY(EditAnywhere, Category = Events, meta = (IsBindableEvent, AllowPrivateAccess = true, DisplayName = "On Get List Item Animation Trigger Time"))
	FKGOnGetListItemAnimationTriggerTime OnGetListItemAnimationTriggerTime;

	UPROPERTY(Transient)
	FKGItemAnimationConfiguration ActiveItemAnimationConfiguration;

	UPROPERTY(EditAnywhere, Category = ItemAnimation, meta = (EditCondition = "!IsTreeViewInternal()", EditConditionHides))
	FKGItemAnimationEntryStyle DefaultListItemAnimationConfiguration;

	#pragma endregion

	#pragma region 插入删除动画

	UPROPERTY(EditAnywhere, Category = ItemAnimation, meta = (EditCondition = "IsInsertOrRemoveAnimationAvailable()"))
	FKGWidgetAnimationName ItemInsertAnimationName;

	UPROPERTY(EditAnywhere, Category = ItemAnimation, meta = (EditCondition = "IsInsertOrRemoveAnimationAvailable()"))
	FKGWidgetAnimationName ItemRemoveAnimationName;

	UFUNCTION()
	virtual bool IsInsertOrRemoveAnimationAvailable() { return true; }

	bool PostInsertItemInternal(ItemType ItemInserted);
	bool TryPlayRemovingAnimationInternal(ItemType ItemToBeRemoved);

	UPROPERTY(Transient)
	TSet<UUserWidget*> RemovingItemEntries;

	#pragma endregion

	#pragma region 滚动相关回调的补充

protected:
	enum class EItemContentIntersectionResult
	{
		Intersected,
		OutOfRange,
		UnGenerated,
		UnIntersected,
	};

	EItemContentIntersectionResult IsItemContentIntersectedByPosition(ItemType Item, float Position, int* OutLineIndex = nullptr, int* OutNumLines = nullptr, int* OutDirection = nullptr, float* OutFromContent = nullptr, float* OutToBoundary = nullptr) const;
	virtual FMargin GetEntryFinalPadding(ItemType Item, TSharedRef<ITableRow> TableRow) const;
	FORCEINLINE void ProcessScrollingDelegates();

	ItemType GetFrontEdgeIntersectionListItem() const;
	ItemType GetBackEdgeIntersectionListItem() const;

	ItemType GetFrontEdgeApproximateListItem() const;
	ItemType GetBackEdgeApproximateListItem() const;

	UPROPERTY(EditAnywhere, Category = ListView, meta=(UIMin = 0, ClampMin = 0))
	float EdgeReachLengthThreshold = 0.5;

	UFUNCTION(BlueprintCallable, Category = ListView)
	int GetFrontEdgeIntersectionListItemIndex() const;

	UFUNCTION(BlueprintCallable, Category = ListView)
	int GetBackEdgeIntersectionListItemIndex() const;

	UFUNCTION(BlueprintCallable, Category = ListView)
	int GetFrontEdgeApproximateListItemIndex() const;

	UFUNCTION(BlueprintCallable, Category = ListView)
	int GetBackEdgeApproximateListItemIndex() const;

	UFUNCTION(BlueprintCallable, Category = ListView)
	bool IsFrontEdgeReached() const;

	UFUNCTION(BlueprintCallable, Category = ListView)
	bool IsBackEdgeReached() const;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Front Edge Intersection Changed"))
	FKGOnEdgeIntersectionListItemChangedDynamic BP_OnFrontEdgeIntersectionListItemChanged;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Back Edge Intersection Changed"))
	FKGOnEdgeIntersectionListItemChangedDynamic BP_OnBackEdgeIntersectionListItemChanged;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Is Front Edge Reached Changed"))
	FKGOnIsEdgeReachedChangedDynamic BP_OnIsFrontEdgeReachedChanged;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Is Back Edge Reached Changed"))
	FKGOnIsEdgeReachedChangedDynamic BP_OnIsBackEdgeReachedChanged;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Overscroll Updated"))
	FKGOnOverscrollUpdatedDynamic BP_OnOverscrollUpdated;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Items Refreshed"))
	FKGOnItemsRefreshedDynamic BP_OnItemsRefreshed;

protected:
	enum class ESide
	{
		Front,
		Back,
	};

	template <ESide Side>
	auto GetEdgeIntersection(float& Position) const
	{
		check(MyListView);
		if constexpr (Side == ESide::Front)
		{
			return MyListView->GetFrontEdgeIntersection(Position);
		}
		else if constexpr (Side == ESide::Back)
		{
			return MyListView->GetBackEdgeIntersection(Position);
		}
		else
		{
			return nullptr;
		}
	}

	template <ESide Side>
	ItemType GetEdgeIntersectionListItem() const
	{
		if (MyListView == nullptr)
		{
			return nullptr;
		}
		float EdgePosition = 0;
		auto EdgeIntersection = GetEdgeIntersection<Side>(EdgePosition);
		if (IsItemContentIntersectedByPosition(EdgeIntersection, EdgePosition - (int)EdgePosition) != EItemContentIntersectionResult::Intersected)
		{
			EdgeIntersection = nullptr;
		}
		return EdgeIntersection;
	}

	template <ESide Side>
	ItemType GetEdgeApproximateListItem() const
	{
		if (MyListView == nullptr)
		{
			return nullptr;
		}
		float EdgePosition = 0;
		return GetEdgeIntersection<Side>(EdgePosition);

		// TODO: implement the method to `Get Edge Nearest List Item`
		// Use `LineIndex`, `NumLines`, `Direction` to determine the neighbor (named with Test Item below)，Use `IsItemContentIntersectedByPosition` to TEST
		// for the `ToBoundary` value. And, use `FromContent`, `ToContent` and `ToBoundary` to figure out which (Edge Intersection Item or Test Item) is the
		// nearest.
		//
		// Two problem should be solved first:
		// 1. Make sure neighbor item active: the accuracy of `LineIndex` in function `GetBackEdgeIntersection` is not very perfect, so that the neighbor item
		//    may not be generated.
		// 2. Make sure item's padding is only used for ListView's entry spacing (not very sure).
		//
		// Case 1:
		// |                                               Edge Intersection Item                                                  |      Test Item       |
		// |------------------------------------------|---------------------------------|------------------------------------------|----------------------|
		// |             Lower Padding                |             Content             |              Upper Padding               |                      |
		// |------------------------------------------|---------------------------------|------------------------------------------|----------------------|
		//                                                                              | <-     Position is in this range      -> |                      |
		//                                                                              |     From Content -> |     To Boundary -> | <- Test To Boundary  |
		//
		// Case 2:
		// |      Test Item       |                                               Edge Intersection Item                                                  | 
		// |----------------------|------------------------------------------|---------------------------------|------------------------------------------|
		// |                      |             Lower Padding                |             Content             |              Upper Padding               |
		// |----------------------|------------------------------------------|---------------------------------|------------------------------------------|
		// |                      | <-     Position is in this range      -> |
		// |  Test To Boundary -> | <- To Boundary    | <- From Content      |
#if 0
		if (Direction > 0)
		{
			return FMath::Abs(FromContent) < FMath::Abs(ToBoundary) + FMath::Abs(TestToBoundary) ? EdgeIntersection : TestItem;
		}
		else
		{
			return FMath::Abs(TestToBoundary) + FMath::Abs(ToBoundary) > FMath::Abs(FromContent) ? EdgeIntersection : TestItem;
		}
#endif
	}

private:
	ItemType LastFrontEdgeIntersection = nullptr;
	ItemType LastBackEdgeIntersection = nullptr;
	bool bLastIsFrontEdgeReached = false;
	bool bLastIsBackEdgeReached = false;

protected:
	UFUNCTION(BlueprintCallable, Category = ListView)
	float GetOverscroll() const;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On User Scrolling Started"))
	FKGOnUserScrollingStartedDynamic BP_OnUserScrollingStarted;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On User Scrolling Ended"))
	FKGOnUserScrollingEndedDynamic BP_OnUserScrollingEnded;

	#pragma endregion

	#pragma region 延迟事件用以解决子项延迟刷新的问题

protected:
	void ExecuteOnItemsRefreshed(FSimpleDelegate&& Action);
	void FlushActionsOnItemsRefreshed();

	TArray<FSimpleDelegate> ActionsOnItemsRefreshed;

	#pragma endregion

	#pragma region 强制刷新

	// NOTE: 函数RequestRefreshSynchronous是个实验性质的接口，不确定会对正常流程造成多大的影响！
	UFUNCTION(BlueprintCallable, Category = ListView)
	KGUI_API void RequestRefreshSynchronous();

	UFUNCTION(BlueprintCallable, Category = ListView)
	UUserWidget* GetOrCreateEntryWidgetFromItem(int Index);

	#pragma endregion

	#pragma region 子项可聚焦

protected:
	UPROPERTY(EditAnywhere, Category = ListEntries)
	bool bIsEntryFocusable = true;

	#pragma endregion

	#pragma region 异形样式（提供区别于IrregularListView的简单的异形列表方案）

public:
	virtual UKGListViewShapeStyle* GetShapeStyle() override
	{
		return ShapeStyle;
	}

	virtual void RaiseOnModifyEntry(const FGeometry& Geometry, TSharedRef<SObjectTableRow<ItemType>> Entry) override;

	UFUNCTION(BlueprintCallable)
	virtual void MarkShapeAsDirty();

protected:
	UPROPERTY(EditAnywhere, Category = ListView, Instanced)
	TObjectPtr<UKGListViewShapeStyle> ShapeStyle;

	#pragma endregion

	#pragma region 列表背景（充当字面意义的背景，或者充当描述列表热区）

protected:
	void RebuildBackground();

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView, meta = (DesignerRebuild, AllowPrivateAccess = true))
	TSubclassOf<UUserWidget> BackgroundClass;

	UPROPERTY(Transient)
	TObjectPtr<UUserWidget> BackgroundInstance;
	#pragma endregion

	#pragma region 空白区域点击事件

protected:
	bool HandleOnClickedInternal() const
	{
		if (OnClicked.IsBound())
		{
			OnClicked.Broadcast();
			return true;
		}
		return false;
	}

	UPROPERTY(BlueprintAssignable, Category = "Event")
	FKGOnListViewClickedDynamic OnClicked;

	#pragma endregion

	#pragma region 可滚动箭头

protected:
	TSharedPtr<SWidget> HandleOnGenerateScrollHintInternal(EKGListViewScrollHintType ScrollHintType);

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild))
	TSubclassOf<UKGUserWidget> ScrollHintClassBefore;

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild))
	TSubclassOf<UKGUserWidget> ScrollHintClassAfter;

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild))
	float ScrollHintScrollAxisOffset = 0;

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild))
	float ScrollHintLineAxisPercentOffset = 0.5;

	UPROPERTY(BlueprintAssignable, Category = Events)
	FKGOnListViewScrollHintGeneratedDynamic BP_OnScrollHintGenerated;

	UPROPERTY()
	TObjectPtr<UUserWidget> ScrollHintBefore;

	UPROPERTY()
	TObjectPtr<UUserWidget> ScrollHintAfter;

	#pragma endregion
};