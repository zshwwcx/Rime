#pragma once

#include "CoreMinimal.h"
#include "Components/GPUTurboCanvasPanel.h"

#include "KGGPUTurboCanvasPanel.generated.h"

UCLASS(DisplayName = "Canvas Panel (GPU Turbo)")
class KGUI_API UKGGPUTurboCanvasPanel : public UGPUTurboCanvasPanel
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("GPU Turbo")); }
#endif
};