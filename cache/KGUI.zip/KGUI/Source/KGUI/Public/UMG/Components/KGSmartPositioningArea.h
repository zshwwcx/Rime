#pragma once

#include "CoreMinimal.h"
#include "Components/ContentWidget.h"
#include "Slate/Layout/SKGSmartPositioningArea.h"

#include "KGSmartPositioningArea.generated.h"

UCLASS(MinimalAPI, DisplayName = "Smart Positioning Area (KGUI)", meta = (ToolTip = "智能定位区域"))
class UKGSmartPositioningArea : public UContentWidget
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif

protected:
	KGUI_API virtual void SynchronizeProperties() override;
	KGUI_API virtual TSharedRef<SWidget> RebuildWidget() override;
	KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	KGUI_API virtual UClass* GetSlotClass() const override;
	KGUI_API virtual void OnSlotAdded(UPanelSlot* Slot) override;
	KGUI_API virtual void OnSlotRemoved(UPanelSlot* Slot) override;

public:
	UFUNCTION(BlueprintCallable, Category = SmartPositioningArea)
	KGUI_API EKGSmartPositioningAreaOrientation GetPrimaryOrientation() const { return PrimaryOrientation;	}

	UFUNCTION(BlueprintCallable, Category = SmartPositioningArea)
	KGUI_API void SetPrimaryOrientation(EKGSmartPositioningAreaOrientation InPrimaryOrientation);

	UFUNCTION(BlueprintCallable, Category = SmartPositioningArea)
	KGUI_API EKGSmartPositioningAreaAlignment GetSecondaryAlignment() const { return SecondaryAlignment; }

	UFUNCTION(BlueprintCallable, Category = SmartPositioningArea)
	KGUI_API void SetSecondaryAlignment(EKGSmartPositioningAreaAlignment InSecondaryAlignment);

	UFUNCTION(BlueprintCallable, Category = SmartPositioningArea)
	KGUI_API EKGSmartPositioningAreaHorizontalPreferredDirection GetHorizontalPreferredDirection() const { return HorizontalPreferredDirection; }

	UFUNCTION(BlueprintCallable, Category = SmartPositioningArea)
	KGUI_API void SetHorizontalPreferredDirection(EKGSmartPositioningAreaHorizontalPreferredDirection InHorizontalPreferredDirection);

	UFUNCTION(BlueprintCallable, Category = SmartPositioningArea)
	KGUI_API EKGSmartPositioningAreaVerticalPreferredDirection GetVerticalPreferredDirection() const { return VerticalPreferredDirection; }

	UFUNCTION(BlueprintCallable, Category = SmartPositioningArea)
	KGUI_API void SetVerticalPreferredDirection(EKGSmartPositioningAreaVerticalPreferredDirection InVerticalPreferredDirection);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetPrimaryOrientation", Category = SmartPositioningArea)
	EKGSmartPositioningAreaOrientation PrimaryOrientation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetSecondaryAlignment", Category = SmartPositioningArea, meta = (EditCondition="PrimaryOrientation!=EKGSmartPositioningAreaOrientation::CenterInViewport"))
	EKGSmartPositioningAreaAlignment SecondaryAlignment = EKGSmartPositioningAreaAlignment::Auto;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetHorizontalPreferredDirection", Category = SmartPositioningArea, meta = (EditCondition = "PrimaryOrientation!=EKGSmartPositioningAreaOrientation::CenterInViewport"))
	EKGSmartPositioningAreaHorizontalPreferredDirection HorizontalPreferredDirection;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetVerticalPreferredDirection", Category = SmartPositioningArea, meta = (EditCondition = "PrimaryOrientation!=EKGSmartPositioningAreaOrientation::CenterInViewport"))
	EKGSmartPositioningAreaVerticalPreferredDirection VerticalPreferredDirection;

protected:
	TSharedPtr<SKGSmartPositioningArea> MySmartPositioningArea;
};
