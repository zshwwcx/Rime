#pragma once

#include "CoreMinimal.h"
#include "AkGameObject.h"
#include "C7/KGUITickableSubsystem.h"
#include "Components/GPUTurboImage.h"
#include "Core/DynamicAtlas/DynamicAtlasSubsystem.h"
#include "KGGPUTurboImage.generated.h"


class UDynamicAtlas;
class UCanvasRenderTarget2D;

UCLASS(DisplayName = "Image (GPU Turbo)")
class KGUI_API UKGGPUTurboImage : public UGPUTurboImage, public FKGUITickableObjectBase
{
	GENERATED_UCLASS_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("GPU Turbo")); }
#endif

public:
    UFUNCTION(BlueprintCallable, Category="GPUTurbo")
    void SetUsingPercentAnim(bool bInAnim) { bUsingPercentAnim = bInAnim;}
    
    UFUNCTION(BlueprintCallable, Category="GPUTurbo")
    void SetGPUShowPercentWithAnim(float InPercentX, float InPercentY, float duration = 0.1f);
    
    UFUNCTION(BlueprintCallable, Category="GPUTurbo")
    void SetSpriteShowPercentWithAnim(float InPercentX, float InPercentY, float Duration = 0.1f){ SetGPUShowPercentWithAnim(InPercentX, InPercentY, Duration); }

    UFUNCTION(BlueprintCallable, Category="GPUTurbo")
    void SetCurPercentForAnim(float InPercentX, float InPercentY);

    UFUNCTION(BlueprintCallable, Category="GPUTurbo")
    float GetCurPercentXForAnim();

    UFUNCTION(BlueprintCallable, Category="GPUTurbo")
    float GetCurPercentYForAnim();
public:
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	virtual void SynchronizeProperties() override;
	virtual void SetBrushFromAtlasInterface(TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize = false) override;

	UFUNCTION(BlueprintCallable)
	virtual void SetBrushFromTexture(UTexture2D* Texture, bool bMatchSize = false);

	UFUNCTION(BlueprintCallable)
	bool SetBrushFromTextureTryingToUseDynamicSprite(UTexture2D* Texture, bool bMatchSize = false);

	// 这个接口和UKGImage::SetBrushFromSoftObject保持一致
	UFUNCTION(BlueprintCallable)
	void SetBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize, bool bHiddenDuringLoading);

	void SetBrushFromSoftObject(TSoftObjectPtr<UObject> SoftObject, bool bMatchSize, bool bHiddenDuringLoading);

	virtual void CancelImageStreaming() override;

    virtual void Tick(float DeltaTime) override;

    virtual bool IsTickable() const override 
    {
        return !HasAnyFlags(RF_BeginDestroyed | RF_ClassDefaultObject | RF_ArchetypeObject) 
        && IsValidChecked(this) 
        && IsVisible()
        && bUsingPercentAnim
        && bHasAnim;
    }
private:
	void TryInitializeDynamicSprite(UDynamicSprite* DynamicSprite);
	void OnDynamicSpriteInitialized(UDynamicSprite* DynamicSprite);
	void TryRegisterDynamicAtlasResizedDelegate(UDynamicAtlasSubsystem* DynamicAtlasSubsystem);
	void TryUnregisterDynamicAtlasResizedDelegate(UDynamicAtlasSubsystem* DynamicAtlasSubsystem);
	void OnDynamicAtlasResized(UDynamicAtlas* DynamicAtlas);
	void ForceRefreshBrushResourceObject();

private:
	FDelegateHandle DynamicAtlasResizedDelegateHandle;

	TOptional<float> CachedOpacity;
    FVector2f CurPercentForAnim;
    FVector2f StartPercentForAnim;
    float AnimDuration = 0;
    float AnimTime = 0;
    bool bHasAnim = false;
    bool bUsingPercentAnim = true;
};

