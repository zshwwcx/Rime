// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UMG/Components/KGInteractableArea.h"
#include "Components/Widget.h"
#include "Layout/WidgetPath.h"
#include "Slate/Input/SKGHotArea.h"
#include "KGHotArea.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnClickedEvent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnPressedEvent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnReleasedEvent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnHoverEvent);


enum class EUIPressFlagType : uint8
{
	Unknown = 0,
	Press = 1,
	LongPress = 2,
};
/**
 * 
 */
UCLASS(MinimalAPI, DisplayName = "Hot Area (KGUI)", meta = (ToolTip = "热区"))
class UKGHotArea : public UWidget
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif

	DECLARE_DYNAMIC_DELEGATE_OneParam(FOnFocusLost, const FFocusEvent&, InFocusEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnKeyDown, const FGeometry&, MyGeometry, const FKeyEvent&, InKeyEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnKeyUp, const FGeometry&, MyGeometry, const FKeyEvent&, InKeyEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnMouseButtonDown, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnMouseButtonDoubleClick, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnMouseButtonUp, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnMouseMove, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_TwoParams(FOnMouseEnter, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_OneParam(FOnMouseLeave, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_OneParam(FOnMouseCaptureLost, const FCaptureLostEvent&, InCaptureLostEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnFocusReceived, const FGeometry&, MyGeometry, const FFocusEvent&, InFocusEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnKeyChar, const FGeometry&, MyGeometry, const FCharacterEvent&, InCharacterEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnPreviewKeyDown, const FGeometry&, MyGeometry, const FKeyEvent&, InKeyEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnPreviewMouseButtonDown, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnMouseWheel, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnDragDetected, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_TwoParams(FOnDragCancel, const FPointerEvent&, InPointerEvent, const UDragDropOperation*, InDragDropOperation);
	DECLARE_DYNAMIC_DELEGATE_TwoParams(FOnDragEnter, const FGeometry&, MyGeometry, const UDragDropOperation*, InDragDropOperation);
	DECLARE_DYNAMIC_DELEGATE_OneParam(FOnDragLeave, const UDragDropOperation*, InDragDropOperation);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnDragOver, const FGeometry&, MyGeometry, const UDragDropOperation*, InDragDropOperation);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnDrop, const FGeometry&, MyGeometry, const UDragDropOperation*, InDragDropOperation);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnTouchGesture, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnTouchStarted, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnTouchMoved, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnTouchEnded, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnTouchForceChanged, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnTouchFirstMove, const FGeometry&, MyGeometry, const FPointerEvent&, InPointerEvent);

	KGUI_API virtual TSharedRef<SWidget> RebuildWidget() override;
public:

	UE_DEPRECATED(5.2, "Direct access to ClickMethod is deprecated. Please use the getter and setter.")
	/** The type of mouse action required by the user to trigger the buttons 'Click' */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetClickMethod", Category = "Interaction", AdvancedDisplay)
	TEnumAsByte<EButtonClickMethod::Type> ClickMethod;

	UE_DEPRECATED(5.2, "Direct access to TouchMethod is deprecated. Please use the getter and setter.")
	/** The type of touch action required by the user to trigger the buttons 'Click' */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetTouchMethod", Category = "Interaction", AdvancedDisplay)
	TEnumAsByte<EButtonTouchMethod::Type> TouchMethod;

	UE_DEPRECATED(5.2, "Direct access to PressMethod is deprecated. Please use the getter and setter.")
	/** The type of keyboard/gamepad button press action required by the user to trigger the buttons 'Click' */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetPressMethod", Category = "Interaction", AdvancedDisplay)
	TEnumAsByte<EButtonPressMethod::Type> PressMethod;

	UE_DEPRECATED(5.2, "Direct access to IsFocusable is deprecated. Please use the getter.")
	/** Sometimes a button should only be mouse-clickable and never keyboard focusable. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Getter, Category = "Interaction")
	bool IsFocusable;

	UPROPERTY()
	TObjectPtr<UWidget> DefaultDragSource;
	UPROPERTY()
	TObjectPtr<UDragDropOperation> Operation;
	UPROPERTY(EditAnywhere)
	bool DisableDoubleClick = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Hover&Press Anim")
	FKGHoverPressAnim HoverPressAnim;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = KGAudio, DisplayName="点击音效")
	TSoftObjectPtr<class UAkAudioEvent> WidgetAkEvent;

	UPROPERTY(Transient)
	FTimerHandle LongPressTimerHandle;

	EUIPressFlagType bPressFlag = EUIPressFlagType::Unknown;
	UPROPERTY(EditAnywhere)
	float LongPressSpan = 1.0f;

	UPROPERTY(EditAnywhere)
	float DoubleClickSpan = 0.5f;
private:
	TSharedPtr<FKGInteractableArea> HoverPressAnimDriver;
public:
	//~ SWidget overrides
	//~ Begin UWidget Interface
	KGUI_API virtual void SynchronizeProperties() override;
	//~ End UWidget Interface

	//~ Begin UVisual Interface
	KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	//~ End UVisual Interface

	//~ Begin UObject Interface
	KGUI_API virtual void PostLoad() override;
	//~ End UObject Interface

	UPROPERTY(BlueprintAssignable, Category = "Button|Event", meta = (AutoBoundWidgetEvent))
	FOnClickedEvent OnClicked;
	UPROPERTY()
	FOnClickedEvent OnClickedInCD;
	UPROPERTY()
	FOnClickedEvent OnRightClicked;
	UPROPERTY(BlueprintAssignable, Category = "Button|Event")
	FOnPressedEvent OnPressed;
	UPROPERTY(BlueprintAssignable, Category = "Button|Event")
	FOnPressedEvent OnLongPressed;
	UPROPERTY(BlueprintAssignable, Category = "Button|Event")
	FOnReleasedEvent OnReleased;
	UPROPERTY(BlueprintAssignable, Category = "Button|Event")
	FOnReleasedEvent OnLongReleased;
	UPROPERTY(BlueprintAssignable, Category = "Button|Event")
	FOnHoverEvent OnHovered;
	UPROPERTY(BlueprintAssignable, Category = "Button|Event")
	FOnHoverEvent OnUnhovered;
	UPROPERTY()
	FOnFocusLost OnFocusLostEvent;
	UPROPERTY()
	FOnKeyDown OnKeyDownEvent;
	UPROPERTY()
	FOnKeyUp OnKeyUpEvent;
	UPROPERTY()
	FOnMouseButtonDown OnMouseButtonDownEvent;
	UPROPERTY()
	FOnClickedEvent OnMouseButtonDoubleClickEvent;
	UPROPERTY()
	FOnMouseButtonUp OnMouseButtonUpEvent;
	UPROPERTY()
	FOnMouseMove OnMouseMoveEvent;
	UPROPERTY()
	FOnMouseEnter OnMouseEnterEvent;
	UPROPERTY()
	FOnMouseLeave OnMouseLeaveEvent;
	UPROPERTY()
	FOnMouseCaptureLost OnMouseCaptureLostEvent;
	UPROPERTY()
	FOnFocusReceived OnFocusReceivedEvent;
	UPROPERTY()
	FOnKeyChar OnKeyCharEvent;
	UPROPERTY()
	FOnPreviewKeyDown OnPreviewKeyDownEvent;
	UPROPERTY()
	FOnPreviewMouseButtonDown OnPreviewMouseButtonDownEvent;
	UPROPERTY()
	FOnMouseWheel OnMouseWheelEvent;
	UPROPERTY()
	FOnDragDetected OnDragDetectedEvent;
	UPROPERTY()
	FOnDragCancel OnDragCancelEvent;
	UPROPERTY()
	FOnDragEnter OnDragEnterEvent;
	UPROPERTY()
	FOnDragLeave OnDragLeaveEvent;
	UPROPERTY()
	FOnDragOver OnDragOverEvent;
	UPROPERTY()
	FOnDrop OnDropEvent;
	UPROPERTY()
	FOnTouchGesture OnTouchGestureEvent;
	UPROPERTY()
	FOnTouchStarted OnTouchStartedEvent;
	UPROPERTY()
	FOnTouchMoved OnTouchMovedEvent;
	UPROPERTY()
	FOnTouchEnded OnTouchEndedEvent;
	UPROPERTY()
	FOnTouchForceChanged OnTouchForceChangedEvent;
	UPROPERTY()
	FOnTouchFirstMove OnTouchFirstMoveEvent;

	TSharedPtr<SKGHotArea> MyHotArea;
	bool waitForClick = false;
	double clickCd = 0;
	double lastClickTime = 0;
	KGUI_API bool GetIsFocusable() const;
	KGUI_API virtual FReply SlateHandleClicked();
	KGUI_API virtual FReply SlateHandleRightClicked();
	KGUI_API virtual void SlateHandlePressed();
	KGUI_API virtual void SlateHandleReleased();
	KGUI_API virtual void SlateHandleHovered();
	KGUI_API virtual void SlateHandleUnhovered();
	KGUI_API virtual void SlateHandleOnFocusLost(const FFocusEvent& InFocusEvent);
	KGUI_API virtual FReply SlateHandleOnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent);
	KGUI_API virtual FReply SlateHandleOnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent);
	KGUI_API virtual FReply SlateHandleOnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	KGUI_API virtual FReply SlateHandleOnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent);
	KGUI_API virtual FReply SlateHandleOnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	KGUI_API virtual FReply SlateHandleOnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	KGUI_API virtual void SlateHandleOnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	KGUI_API virtual void SlateHandleOnMouseLeave(const FPointerEvent& MouseEvent);
	KGUI_API virtual void SlateHandleOnMouseCaptureLost(const FCaptureLostEvent& CaptureLostEvent);
	KGUI_API virtual FReply SlateHandleOnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent);
	KGUI_API virtual FReply SlateHandleOnKeyChar(const FGeometry& MyGeometry, const FCharacterEvent& InCharacterEvent);
	KGUI_API virtual FReply SlateHandleOnPreviewKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent);
	KGUI_API virtual FReply SlateHandleOnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	KGUI_API virtual FReply SlateHandleOnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	KGUI_API virtual FReply SlateHandleOnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	KGUI_API virtual void SlateHandleOnDragEnter(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent);
	KGUI_API virtual void SlateHandleOnDragLeave(const FDragDropEvent& DragDropEvent);
	KGUI_API virtual FReply SlateHandleOnDragOver(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent);
	KGUI_API virtual FReply SlateHandleOnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent);
	KGUI_API virtual FReply SlateHandleOnTouchGesture(const FGeometry& MyGeometry, const FPointerEvent& GestureEvent);
	KGUI_API virtual FReply SlateHandleOnTouchStarted(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent);
	KGUI_API virtual FReply SlateHandleOnTouchMoved(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent);
	KGUI_API virtual FReply SlateHandleOnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent);
	KGUI_API virtual FReply SlateHandleOnTouchForceChanged(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent);
	KGUI_API virtual FReply SlateHandleOnTouchFirstMove(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent);
	KGUI_API void OnDragCancelled(const FDragDropEvent& DragDropEvent, UDragDropOperation* Operation);

	UFUNCTION(BlueprintCallable, Category = "KGHotArea")
	KGUI_API void SetClickMethod(EButtonClickMethod::Type InClickMethod);

	KGUI_API EButtonClickMethod::Type GetClickMethod() const;

	UFUNCTION(BlueprintCallable, Category = "KGHotArea")
	KGUI_API void SetTouchMethod(EButtonTouchMethod::Type InTouchMethod);

	KGUI_API EButtonTouchMethod::Type GetTouchMethod() const;

	UFUNCTION(BlueprintCallable, Category = "KGHotArea")
	KGUI_API void SetPressMethod(EButtonPressMethod::Type InPressMethod);

	KGUI_API EButtonPressMethod::Type GetPressMethod() const;
	UFUNCTION()
	void SetDragSourceWidget(UKGUserWidget* Source);

	UFUNCTION()
	void PostWidgetAudio();
	void OnLongPressTimerHandle();
	UFUNCTION()
	void SetClickCd(float cd);
	void TryTriggleClick();
};
