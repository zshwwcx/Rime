// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/CheckBox.h"
#include "UMG/Components/KGInteractableArea.h"
#include "KGCheckBox.generated.h"

/**
 * 
 */
UCLASS(DisplayName = "Check Box (KGUI)", meta = (ToolTip = "复选框"))
class KGUI_API UKGCheckBox : public UCheckBox
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif
public:
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;
	void SlateHandlePressed();
	void SlateHandleReleased();
	void SlateHandleHovered();
	void SlateHandleUnhovered();

public:
	UFUNCTION()
	void PostWidgetAudio(bool bIsChecked);

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = KGAudio, DisplayName="点击音效")
	TSoftObjectPtr<class UAkAudioEvent> WidgetAkEvent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Hover&Press Anim")
	FKGHoverPressAnim HoverPressAnim;
private:
	TSharedPtr<FKGInteractableArea> HoverPressAnimDriver;
};
