// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "C7/KGUITickableSubsystem.h"
#include "Components/ContentWidget.h"
#include "KGHPBar.generated.h"

struct FKGHPBarLayer;
class SKGHPBar;

UCLASS(MinimalAPI)
class UKGHpBarSlot : public UPanelSlot
{
	GENERATED_UCLASS_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter="SetPadding", Category="Layout|HPBar Slot")
	FMargin Padding;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter="SetHorizontalAlignment", Category="Layout|HPBar Slot")
	TEnumAsByte<EHorizontalAlignment> HorizontalAlignment;
	
	/** The alignment of the object vertically. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter="SetVerticalAlignment", Category="Layout|HPBar Slot")
	TEnumAsByte<EVerticalAlignment> VerticalAlignment;

	KGUI_API FMargin GetPadding() const;

	UFUNCTION(BlueprintCallable, Category="Layout|Button Slot")
	KGUI_API void SetPadding(FMargin InPadding);

	KGUI_API EHorizontalAlignment GetHorizontalAlignment() const;

	UFUNCTION(BlueprintCallable, Category="Layout|Button Slot")
	KGUI_API void SetHorizontalAlignment(EHorizontalAlignment InHorizontalAlignment);

	KGUI_API EVerticalAlignment GetVerticalAlignment() const;

	UFUNCTION(BlueprintCallable, Category="Layout|Button Slot")
	KGUI_API void SetVerticalAlignment(EVerticalAlignment InVerticalAlignment);

	// UPanelSlot interface
	KGUI_API virtual void SynchronizeProperties() override;
	// End of UPanelSlot interface

	/** Builds the underlying slot for the slate button. */
	KGUI_API void BuildSlot(TSharedRef<SKGHPBar> InHpBar);

	KGUI_API virtual void ReleaseSlateResources(bool bReleaseChildren) override;

private:
	TWeakPtr<SKGHPBar> HpBar;
};


/**
 * UKGHPBar
 */
UCLASS()
class KGUI_API UKGHPBar : public UContentWidget, public FKGUITickableObjectBase
{
	GENERATED_UCLASS_BODY()
public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Appearance")
    FVector2D Size;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, FieldNotify, Getter, Setter, BlueprintSetter="SetFillColorAndOpacity", Category="Appearance")
    FLinearColor FillColorAndOpacity;
    
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Appearance")
	TArray<FKGHPBarLayer> Layers;

    UFUNCTION(BlueprintCallable)
    void SetUsingPercentAnim(bool bInAnim) { bUsingPercentAnim = bInAnim; }
    
	UFUNCTION(BlueprintCallable)
	void SetPercent(FName InLayerName, float InPercent);

    /*
     * 插值动画接口
     * 从上一次Tween动画设置的百分比，插值到InPercent值。
     * InDuration：插值动画时长。如果传入Duration为非零，会按照计时来计算插值动画；如果InDuration为零，按照AnimSpeed来计算插值动画。
     */
	UFUNCTION(BlueprintCallable)
	void SetPercentWithAnim(FName InLayerName, float InPercent, float InDuration = 0.f, bool bInKeepLastLeftTime = 
	true);

    UFUNCTION(BlueprintCallable)
    void SetAnimStartPercent(FName InLayerName, float InPercent);

    UFUNCTION(BlueprintCallable)
    float GetLayerPercent(FName InLayerName) const;

	UFUNCTION(BlueprintCallable)
	void SetLayerVisibility(FName InLayerName, bool bVisible);

	UFUNCTION(BlueprintCallable)
	bool IsLayerVisible(FName InLayerName)const;

    FLinearColor GetFillColorAndOpacity() const;

    /** Sets the fill color of the progress bar. */
    UFUNCTION(BlueprintCallable, Category="Progress")
    void SetFillColorAndOpacity(FLinearColor InColor);

	//~ Begin UWidget Interface
	virtual void SynchronizeProperties() override;
	//~ End UWidget Interface

	//~ Begin UVisual Interface
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	//~ End UVisual Interface

    bool TweenPercent(FKGHPBarLayer& Layer, float DeltaTime);
    virtual void Tick(float DeltaTime) override;

    virtual bool IsTickable() const override 
    {
        return !HasAnyFlags(RF_BeginDestroyed | RF_ClassDefaultObject | RF_ArchetypeObject) 
        && IsValidChecked(this)
        && bUsingPercentAnim
        && IsVisible() && bHasAnim;
    }

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override;
    virtual void OnCreationFromPalette() override;
#endif
protected:
	// UPanelWidget
	virtual UClass* GetSlotClass() const override;
	virtual void OnSlotAdded(UPanelSlot* Slot) override;
	virtual void OnSlotRemoved(UPanelSlot* Slot) override;
	// End UPanelWidget

	//~ Begin UWidget Interface
	virtual TSharedRef<SWidget> RebuildWidget() override;

	//~ End UWidget Interface

    FKGHPBarLayer* GetLayer(FName InLayerName);
    const FKGHPBarLayer* GetLayer(FName InLayerName) const;
#if WITH_ACCESSIBILITY
	virtual TSharedPtr<SWidget> GetAccessibleWidget() const override;
#endif

protected:
	TSet<FName> LayerNamesAnimating;
	TSharedPtr<SKGHPBar> MyHpBar;
    bool bHasAnim = false;
    bool bUsingPercentAnim = true;
};
