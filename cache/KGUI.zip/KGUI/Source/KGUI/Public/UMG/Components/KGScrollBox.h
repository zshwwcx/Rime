// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ScrollBox.h"
#include "Slate/Layout/SKGScrollBox.h"
#include "KGScrollBox.generated.h"

class SOverlay;
class UKGUserWidget;
DECLARE_DYNAMIC_DELEGATE_TwoParams(FTouchDelegat, const FGeometry&, MyGeometry, const FPointerEvent&, InMouseEvent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnScrollBoxScrollHintGeneratedDynamic, EKGScrollBoxScrollHintType, ScrollHintType, UUserWidget*, Widget);

UCLASS(DisplayName = "Scroll Box (KGUI)", meta = (ToolTip = "滚动框"))
class KGUI_API UKGScrollBox : public UScrollBox
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
	virtual void OnCreationFromPalette() override;
#endif

public:
	UPROPERTY(Transient)
	FTouchDelegat OnUserTouchEnded;
	
protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;

	void SlateHandleTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent);

	#pragma region 可滚动箭头

protected:
	void HandleOnDistanceFromTopChanged(float DistanceFromTop);
	void HandleOnDistanceFromBottomChanged(float DistanceFromBottom);
	void UpdateScrollHintVisibility(EKGScrollBoxScrollHintType ScrollHintType, bool bVisible);

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild))
	TSubclassOf<UKGUserWidget> ScrollHintClassBefore;

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild))
	TSubclassOf<UKGUserWidget> ScrollHintClassAfter;

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild))
	float ScrollHintScrollAxisOffset = 0;

	UPROPERTY(EditAnywhere, Category = Scrolling, meta = (DesignerRebuild))
	float ScrollHintLineAxisPercentOffset = 0.5;

	UPROPERTY(BlueprintAssignable, Category = Events)
	FKGOnScrollBoxScrollHintGeneratedDynamic BP_OnScrollHintGenerated;

	UPROPERTY()
	TObjectPtr<UUserWidget> ScrollHintBefore;

	UPROPERTY()
	TObjectPtr<UUserWidget> ScrollHintAfter;

	TWeakPtr<SOverlay> WeakOverlay;
	TWeakPtr<SWidget> WeakScrollHintBefore;
	TWeakPtr<SWidget> WeakScrollHintAfter;

	#pragma endregion
};
