#pragma once

#include "CoreMinimal.h"
#include "UMG/Components/KGCountDownConditionIntervalType.h"
#include "UMG/Components/KGTextCountDownController.h"
#include "UObject/Interface.h"
#include "UObject/ObjectMacros.h"

#include "IKGTextCountDown.generated.h"

UINTERFACE(MinimalAPI, BlueprintType)
class UKGTextCountDown : public UInterface
{
	GENERATED_BODY()
};

class KGUI_API IKGTextCountDown
{
	GENERATED_BODY()

public:
	virtual void SetCountDownTimeFormat(const FString& Format) = 0;

	virtual void SetCountDownTimeFormatByCondition(
		double LowerBoundSeconds, EKGCountDownConditionIntervalType LowerIntervalType,
		double UpperBoundSeconds, EKGCountDownConditionIntervalType UpperIntervalType,
		const FString& Format
	) = 0;

	virtual void SetCountDownTimeFormatByFirstNonzeroUnit(FName FirstNonzeroUnitName, const FString& Format) = 0;

	virtual void ClearCountDownTimeFormats() = 0;

	virtual void PlayCountDown(double FromSeconds, double ToSeconds) = 0;

	virtual void StopCountDown() = 0;

	virtual bool IsCountDownPlaying() const = 0;

	void ReleaseCountDown() const;

protected:
	virtual void HandleOnCountDownFinished() = 0;
	virtual void HandleOnCountDownTextChanged(FText&& Text) = 0;

	FKGTextCountDownController& GetOrCreateCountDownController() const;

private:
	mutable TSharedPtr<FKGTextCountDownController> TextCountDownController = nullptr;
};