// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/CanvasPanel.h"
#include "UMG/Blueprint/KGUserWidget.h"

#include "KGPreviewCanvasPanel.generated.h"

/** 新增预览包裹节点，继承自UCanvasPanel，普通的UserWidget使用当前节点包裹，可以实现运行时不参与构建，编辑时正常显示的预览效果
 * 
 */
UCLASS()
class KGUI_API UKGPreviewCanvasPanel : public UCanvasPanel
{
	GENERATED_BODY()

public:
	TSharedRef<SWidget> RebuildWidget();

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, meta = (DisplayName = "预览显示Index"))
	int32 KGPreviewShowIndex = 0;
	
	UPROPERTY(EditAnywhere, meta = (DisplayName = "动态加载路径列表"))
	TArray<FSoftClassPath> KGPreviewList;
#endif

};
