#pragma once

#include "CoreMinimal.h"
#include "KGEditableTextBox.h"
#include "Components/MultiLineEditableText.h"

#include "KGMultiLineEditableText.generated.h"

UCLASS(DisplayName = "MultiLine Editable Text (KGUI)", meta = (ToolTip = "输入框 (多行)"))
class KGUI_API UKGMultiLineEditableText : public UMultiLineEditableText
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
	virtual void OnCreationFromPalette() override;
#endif

protected:
	UKGMultiLineEditableText(const FObjectInitializer& ObjectInitializer);

	//~ Begin UWidget Interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	// End of UWidget

	virtual void SynchronizeProperties() override;
	virtual void PreSave(FObjectPreSaveContext SaveContext) override;

	UFUNCTION()
	void PostWidgetAudio(const FFocusEvent& FocusEvent);

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = KGAudio, DisplayName="点击音效")
	TSoftObjectPtr<class UAkAudioEvent> WidgetAkEvent;

	#pragma region Focus事件
protected:
	virtual void HandleOnFocusReceived(const FFocusEvent& FocusEvent);
	virtual void HandleOnFocusLost(const FFocusEvent& FocusEvent);

	UPROPERTY(BlueprintAssignable, Category = "MultiLineEditableText|Event")
	FKGOnFocusReceived OnFocusReceived;

	UPROPERTY(BlueprintAssignable, Category = "MultiLineEditableText|Event")
	FKGOnFocusLost OnFocusLost;
	#pragma endregion

	#pragma region HintText样式
protected:
	UFUNCTION(BlueprintCallable, Category= MultiLineEditableText)
	void SetHintTextStyle(const FTextBlockStyle& InHintTextStyle);

	UFUNCTION(BlueprintCallable, Category = MultiLineEditableText)
	FTextBlockStyle GetHintTextStyle() const;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, BlueprintSetter = SetHintTextStyle, Category = Content, meta = (DisplayAfter = "HintText"))
	FTextBlockStyle HintTextStyle;
	#pragma endregion

	#pragma region 回车换行

public:
	UFUNCTION(BlueprintCallable, Category= MultiLineEditableText)
	void SetCanInsertCarriageReturn(bool InbCanInsertCarriageReturn);

protected:
	UPROPERTY(Transient)
	bool bCanInsertCarriageReturn;

	#pragma endregion

	#pragma region 字符限制

public:
	UFUNCTION(BlueprintCallable, Category = MultiLineEditableText)
	void SetDisallowedChars(const FString& InDisallowedChars);

protected:
	virtual void PostUpdateTextContent(const FText& InText, bool bUpdateSlateAnyway) override;
	bool HandleOnIsCharAllowed(const TCHAR InChar) const;

	UPROPERTY(Transient)
	FString DisallowedChars;

	#pragma endregion

};