// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ContentWidget.h"
#include "UObject/ObjectMacros.h"
#include "Layout/Margin.h"
#include "Components/PanelSlot.h"
#include "Slate/Components/SKGRedDot.h"
#include "KGRedDot.generated.h"

class SKGRedDot;

UCLASS()
class KGUI_API UKGRedDotSlot : public UPanelSlot
{
	GENERATED_UCLASS_BODY()

	friend class UKGRedDot;
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FMargin Offsets;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FAnchors Anchors;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D Alignment = FVector2D::ZeroVector;

	void BuildSlot(TSharedRef<SKGRedDot> InRedDot);

	// UPanelSlot interface
	virtual void SynchronizeProperties() override;
	// End of UPanelSlot interface

	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	UFUNCTION(BlueprintCallable)
	void SetOffsets(const FMargin& InOffsets);

	UFUNCTION(BlueprintCallable)
	void SetAlignment(const FVector2D& InAlignment);

	UFUNCTION(BlueprintCallable)
	void SetAnchors(const FAnchors& InAnchors);
	
private:
	SKGRedDot::FOneChildSlot* Slot;
	TWeakPtr<SKGRedDot> RedDot;
};



/**
 * UKGRedDot
 */
UCLASS()
class KGUI_API UKGRedDot : public UContentWidget
{
	GENERATED_UCLASS_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ContentScale = 1.f;

	UPROPERTY(Transient)
	UWidget* OwnerWidget = nullptr; 

	UFUNCTION(BlueprintCallable)
	void SetContentScale(float InScale);

	UFUNCTION(BlueprintCallable)
	void SetOwnerWidget(UWidget* Widget);
	
	UFUNCTION(BlueprintCallable)
	void SetAnchors(const FAnchors& InAnchors);
		
	UFUNCTION(BlueprintCallable)
	void SetOffset(const FMargin& InOffset);

	UFUNCTION(BlueprintCallable)
	void SetAlignment(const FVector2D& InAlignment);

	UFUNCTION(BlueprintCallable)
	void SetColorAndOpacity(const FLinearColor& InColor);

	UFUNCTION(BlueprintCallable)
	void SetForegroundColor(const FLinearColor& InColor);

	
	//~ Begin UWidget Interface
	virtual void SynchronizeProperties() override;
	//~ End UWidget Interface

	//~ Begin UVisual Interface
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	//~ End UVisual Interface

protected:
	// UPanelWidget
	virtual UClass* GetSlotClass() const override;
	virtual void OnSlotAdded(UPanelSlot* Slot) override;
	virtual void OnSlotRemoved(UPanelSlot* Slot) override;
	// End UPanelWidget

	//~ Begin UWidget Interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	//~ End UWidget Interface

	TSharedPtr<SKGRedDot> MyRedDot;
	FAnchors Anchors;
	FMargin Offsets;
	FVector2D Alignment;
	FLinearColor ColorAndOpacity;
	FLinearColor ColorForeground;
};
