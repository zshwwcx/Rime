// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/CanvasPanel.h"
#include "Engine/UserInterfaceSettings.h"
#include "KGDPIScaleCanvasPanel.generated.h"

/**
 * 
 */
UCLASS()
class KGUI_API UKGDPIScaleCanvasPanel : public UCanvasPanel
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = KGUI)
	bool bEnableDPIScale = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = KGUI)
	float ApplicationScale = 1.0f;

	virtual TSharedRef<SWidget> RebuildWidget() override;

	virtual void SynchronizeProperties() override;

	void ReleaseSlateResources(bool bReleaseChildren) override;

protected:
	TSharedPtr<class SKGDPIConstraintCanvas> MyCanvas;
	
};
