#pragma once

#include "CoreMinimal.h"
#include "Core/Common.h"
#include "Styling/SlateBrush.h"
#include "UObject/ObjectMacros.h"

#include "KGRichTextBlockDecoratorSlateBrushGenerator.generated.h"

class UDataTable;

USTRUCT()
struct FKGRichTextBlockDecoratorSlateBrushKey
{
	GENERATED_BODY()

	UPROPERTY()
	FName RichImageRowID;

	UPROPERTY()
	FString ResourcePath;

	friend uint32 GetTypeHash(const FKGRichTextBlockDecoratorSlateBrushKey& Key)
	{
		return HashCombine(GetTypeHash(Key.RichImageRowID), GetTypeHash(Key.ResourcePath));
	}

	friend bool operator==(const FKGRichTextBlockDecoratorSlateBrushKey& Left, const FKGRichTextBlockDecoratorSlateBrushKey& Right)
	{
		return Left.RichImageRowID == Right.RichImageRowID && Left.ResourcePath.Compare(Right.ResourcePath, ESearchCase::CaseSensitive) == 0;
	}
};

USTRUCT()
struct FKGRichTextBlockDecoratorSlateBrushGenerator
{
	GENERATED_BODY()

public:
	void Initialize(const TArray<TObjectPtr<UDataTable>>& InRichImageDataTables);

	template <typename ResourceObjectType = UObject>
	const FSlateBrush* MakeBrush(FName RichImageRowID, const FString& ResourcePath, bool bWarnIfMissing = false)
	{
		FKGRichTextBlockDecoratorSlateBrushKey Key;
		Key.RichImageRowID = RichImageRowID;
		Key.ResourcePath = ResourcePath;
		return MakeBrush(Key, bWarnIfMissing);
	}

	template <typename ResourceObjectType = UObject>
	const FSlateBrush* MakeBrush(const FString& ResourcePath, bool bWarnIfMissing = false)
	{
		return MakeBrush(NAME_None, ResourcePath, bWarnIfMissing);
	}

	template <typename ResourceObjectType = UObject>
	const FSlateBrush* MakeBrush(FName RichImageRowID, bool bWarnIfMissing = false)
	{
		return MakeBrush(RichImageRowID, FString(), bWarnIfMissing);
	}

	void RemoveBrush(FName RichImageRowID, const FString& ResourcePath);
	void RemoveBrush(const FString& ResourcePath);
	void RemoveBrush(FName RichImageRowID);
	void Empty();

	bool IsRichImageRowValid(FName RichImageRowID, bool bWarnIfMissing) const;

protected:
	template <typename ResourceObjectType = UObject>
	const FSlateBrush* MakeBrush(const FKGRichTextBlockDecoratorSlateBrushKey& Key, bool bWarnIfMissing)
	{
		MakeBrushInternal(Key, bWarnIfMissing);
		auto Brush = Brushes[Key];
		if (Brush != nullptr && Cast<ResourceObjectType>(Brush->GetResourceObject()) == nullptr)
		{
			if (bWarnIfMissing)
			{
				FString ResourceObjectClass = TEXT("None");
				if (Brush->GetResourceObject() != nullptr)
				{
					ResourceObjectClass = Brush->GetResourceObject()->GetName();
				}
				UE_LOG(LogKGUI, Warning, TEXT("The brush 's resource object '%s' 's type does not match the template argument '%s'."),
					*ResourceObjectClass,
					*ResourceObjectType::StaticClass()->GetName()
				);
			}
			return nullptr;
		}
		return Brush.Get();
	}

	void RemoveBrush(const FKGRichTextBlockDecoratorSlateBrushKey& Key);
	void MakeBrushInternal(const FKGRichTextBlockDecoratorSlateBrushKey& Key, bool bWarnIfMissing);

	UPROPERTY(Transient)
	TArray<TObjectPtr<UDataTable>> RichImageDataTables;

	UPROPERTY(Transient)
	TMap<FKGRichTextBlockDecoratorSlateBrushKey, TObjectPtr<UObject>> ResourceObjects;

	TMap<FKGRichTextBlockDecoratorSlateBrushKey, TSharedPtr<FSlateBrush>> Brushes;
};