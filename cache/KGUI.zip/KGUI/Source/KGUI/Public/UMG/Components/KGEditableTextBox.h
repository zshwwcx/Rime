// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/EditableTextBox.h"
#include "Core/Common.h"

#include "KGEditableTextBox.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnFocusReceived, const FFocusEvent&, FocusEvent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGOnFocusLost, const FFocusEvent&, FocusEvent);

/**
 *
 */
UCLASS(DisplayName = "Editable Text Box (KGUI)", meta = (ToolTip = "输入框"))
class KGUI_API UKGEditableTextBox : public UEditableTextBox
{
    GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
	virtual void OnCreationFromPalette() override;
#endif

    UKGEditableTextBox(const FObjectInitializer& ObjectInitializer);

public:

    UFUNCTION(BlueprintCallable, Category = EditableTextBox, meta = (DisplayName = "Go To (Text Box)"))
	/** Move the cursor specified location */
    void GoTo(ETextLocation textLocation);

    UFUNCTION(BlueprintCallable)
    /** Move the cursor specified location */
    //Add by zhouyuye 2024-3-5
    void KGSetClearKeyboardFocusOnCommit(bool bClearKeyboardFocusOnCommit);
	
	UFUNCTION()
	void PostWidgetAudio(const FFocusEvent& FocusEvent);

protected:
	//~ Begin UWidget Interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	// End of UWidget

	virtual void SynchronizeProperties() override;
	virtual void PreSave(FObjectPreSaveContext SaveContext) override;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = KGAudio, DisplayName="点击音效")
	TSoftObjectPtr<class UAkAudioEvent> WidgetAkEvent;

	#pragma region Focus事件
protected:
	virtual void HandleOnFocusReceived(const FFocusEvent& FocusEvent);
	virtual void HandleOnFocusLost(const FFocusEvent& FocusEvent);

	UPROPERTY(BlueprintAssignable, Category = "EditableTextBox|Event")
	FKGOnFocusReceived OnFocusReceived;

	UPROPERTY(BlueprintAssignable, Category = "EditableTextBox|Event")
	FKGOnFocusLost OnFocusLost;
	#pragma endregion

	#pragma region HintText样式
protected:
	UFUNCTION(BlueprintCallable, Category = EditableTextBox)
	void SetHintTextStyle(const FTextBlockStyle& InHintTextStyle);

	UFUNCTION(BlueprintCallable, Category = EditableTextBox)
	FTextBlockStyle GetHintTextStyle() const;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, BlueprintSetter = SetHintTextStyle, Category = Content, meta = (DisplayAfter = "HintText"))
	FTextBlockStyle HintTextStyle;
	#pragma endregion
};