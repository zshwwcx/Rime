// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/Image.h"
#include "Core/DynamicAtlas/DynamicSprite.h"
#include "Engine/CanvasRenderTarget2D.h"
#include "Engine/DataTable.h"
#include "Styling/SlateBrush.h"
#include "UMG/Blueprint/KGPreviewColor.h"

#include "KGImage.generated.h"

class FKGTextureLoader;
class UDynamicAtlas;
class UCanvasRenderTarget2D;


USTRUCT(BlueprintType)
struct FKGSlateBrush
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Brush)
	FSlateBrush Brush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Brush)
	bool bUseSoftObject = false;

	UPROPERTY()
	TSoftObjectPtr<UObject> BrushResourceObj = nullptr;
public:
	bool Serialize(FArchive& Ar);
};

template<>
struct TStructOpsTypeTraits<FKGSlateBrush> : public TStructOpsTypeTraitsBase2<FKGSlateBrush>
{
	enum
	{
		WithSerializer = true,
	};
};

UENUM(BlueprintType, meta = (Bitflags))
enum class EKGImageOpacityCacheReason : uint8
{
	None = 0,
	Brush = 1 << 0,
	TextureParameter = 1 << 1,
};

ENUM_CLASS_FLAGS(EKGImageOpacityCacheReason);


/**
 * 
 */
UCLASS(DisplayName = "Image (KGUI)", meta = (ToolTip = "图片"))
class KGUI_API UKGImage : public UImage
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
	virtual void OnCreationFromPalette() override;
#endif

public:

	virtual void SynchronizeProperties() override;

	void OverrideMaterial();

	void TryUpdateOverrideMaterialParam();

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Appearance")
	bool IsBindColor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Appearance", meta = (EditCondition = "IsBindColor"))
	UDataTable* ColorTable;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Appearance", meta = (EditCondition = "IsBindColor"))
	FName ColorName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Appearance", meta = (EditCondition = "IsBindColor", IsText = false))
	FKGPreviewColor PreviewColor;
	
	inline static FString OverridePropertyMainTexName = "MainTex";
	inline static FString OverridePropertyUVParamName = "UVParam";
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "KGOverrideMaterial", meta = (Tooltip = "动效专用"))
	UMaterialInterface* KGMaterialInstancePtr;

	UPROPERTY(Transient, BlueprintReadOnly, Category = "KGOverrideMaterial", meta = (HideInDetailPanel))
	UMaterialInstanceDynamic* DynamicMaterialInstance;
	
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "KGOverrideMaterial", meta = (Tooltip = "动效专用"))
    TSoftObjectPtr<UObject> KGOverrideResourceObject;

	virtual void SetBrushFromTexture(UTexture2D* Texture, bool bMatchSize = false) override;
	virtual void SetBrushFromAtlasInterface(TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize = false) override;

	UFUNCTION()
	bool HasSameResource(const FString& Path);

	UFUNCTION(BlueprintCallable)
	void UpdateOverrideMaterialBrushFromTexture(UTexture2D* Texture, bool bMatchSize = false);

	UFUNCTION(BlueprintCallable)
	void UpdateOverrideMaterialBrushFromAtlasInterface(TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize = false);

protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;

public:
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	virtual void BroadcastFieldValueChanged(UE::FieldNotification::FFieldId InFieldId) override final;

	#pragma region 动态图集

public:
	void ForceRefreshBrushResourceObject();

	UFUNCTION(BlueprintCallable)
	void SetBrushFromSoftDynamicSprite(TSoftObjectPtr<UDynamicSprite> SoftDynamicSprite, bool bMatchSize);

	UFUNCTION(BlueprintCallable)
	void SetBrushFromSoftTextureTryingToUseDynamicSprite(TSoftObjectPtr<UTexture2D> SoftTexture, bool bMatchSize = false);

	UFUNCTION(BlueprintCallable)
	void SetBrushFromTextureTryingToUseDynamicSprite(UTexture2D* Texture, bool bMatchSize = false);

private:
	void TryInitializeDynamicSprite(UDynamicSprite* DynamicSprite);
	void OnDynamicSpriteInitialized(UDynamicSprite* DynamicSprite);
	void TryRegisterDynamicAtlasResizedDelegate(UDynamicAtlasSubsystem* DynamicAtlasSubsystem);
	void TryUnregisterDynamicAtlasResizedDelegate(UDynamicAtlasSubsystem* DynamicAtlasSubsystem);
	void OnDynamicAtlasResized(UDynamicAtlas* DynamicAtlas);

	FDelegateHandle DynamicAtlasResizedDelegateHandle;

	#pragma endregion
public:
	virtual void CancelImageStreaming() override;

	// 这个接口和UKGGPUTurboImage::SetBrushFromSoftObject保持一致
	UFUNCTION(BlueprintCallable)
	void SetBrushFromSoftObject(const FString& SoftObjectPath, bool bMatchSize, bool bHiddenDuringLoading);

	void SetBrushFromSoftObject(TSoftObjectPtr<UObject> SoftObject, bool bMatchSize, bool bHiddenDuringLoading);

	// 这个接口和UKGGPUTurboImage::SetMaterialTextureParameterFromSoftObject保持一致
	UFUNCTION(BlueprintCallable)
	void SetMaterialTextureParameterFromSoftObject(const FName& ParameterName, const FString& SoftObjectPath, bool bAsync, bool bHiddenDuringLoading);

	void SetMaterialTextureParameterFromSoftObject(const FName& ParameterName, TSoftObjectPtr<UObject> SoftObject, bool bAsync, bool bHiddenDuringLoading);

	UFUNCTION(BlueprintCallable)
	bool SetMaterialTextureParameter(const FName& ParameterName, UTexture* Texture);

	UFUNCTION(BlueprintCallable)
	void SetBrushFromBase64(const FString& Base64String);

	UFUNCTION(BlueprintCallable)
	EKGImageOpacityCacheReason GetOpacityCacheReason() const { return OpacityCacheReason; }

protected:
	void PushOpacity(EKGImageOpacityCacheReason InOpacityCacheReason);
	void PopOpacity(EKGImageOpacityCacheReason InOpacityCacheReason);

	EKGImageOpacityCacheReason OpacityCacheReason = EKGImageOpacityCacheReason::None;
	TOptional<float> CachedOpacity;
	TSharedPtr<FKGTextureLoader> MaterialTextureLoader;
};