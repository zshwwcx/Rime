// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/Button.h"
#include "UMG/Components/KGInteractableArea.h"
#include "KGButton.generated.h"

/**
 * 
 */

DECLARE_DYNAMIC_DELEGATE_RetVal(FEventReply, FOnButtonClickedUniCastEvent);

UCLASS(DisplayName = "Button (KGUI)", meta = (ToolTip = "按钮"))
class KGUI_API UKGButton : public UButton
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif

protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
private:
	/** The delegate to execute when the button is clicked */
	UPROPERTY()
	FOnButtonClickedUniCastEvent C7OnClicked;

	/** The delegate to execute when the button is RightClicked */
	UPROPERTY()
	FOnButtonClickedUniCastEvent C7OnRightClicked;

	UPROPERTY()
	FOnButtonClickedEvent C7OnRightClickedMulti;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = KGAudio, DisplayName="点击音效")
	TSoftObjectPtr<class UAkAudioEvent> WidgetAkEvent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Hover&Press Anim")
	FKGHoverPressAnim HoverPressAnim;
private:
	TSharedPtr<FKGInteractableArea> HoverPressAnimDriver;
protected:
	//override Button
	/** Handle the actual click event from slate and forward it on */
	virtual FReply SlateHandleClicked() override;
	virtual FReply SlateHandleRightClicked();//C7 Code
	virtual void SlateHandlePressed();
	virtual void SlateHandleReleased();
	virtual void SlateHandleHovered();
	virtual void SlateHandleUnhovered();
public:
	/** See OnRightClicked event */
	void  SetOnClicked(const FOnButtonClickedUniCastEvent& InOnRightClicked);

	/** See OnRightClicked event */
	void  SetOnRightClicked(const FOnButtonClickedUniCastEvent& InOnRightClicked);

public:
	UFUNCTION()
	void PostWidgetAudio();
};
