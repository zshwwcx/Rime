#pragma once

#include "CoreMinimal.h"
#include "Components/GPUTurboInvalidationBox.h"

#include "KGGPUTurboInvalidationBox.generated.h"

UCLASS(DisplayName = "Invalidation Box (GPU Turbo)")
class KGUI_API UKGGPUTurboInvalidationBox : public UGPUTurboInvalidationBox
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("GPU Turbo")); }
#endif
};