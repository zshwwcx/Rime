#pragma once

#include "CoreMinimal.h"
#include "Components/Widget.h"
#include "Blueprint/UserWidgetPool.h"

#include "UMG/Slate/SKGObjectIrregularListEntry.h"
#include "Slate/Views/SKGIrregularListView.h"
#include "UMG/Blueprint/KGVector2DReference.h"
#include "UMG/Blueprint/KGFloatReference.h"

#include "KGIrregularListView.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnIrregularListViewEntryInitializedDynamic, UObject*, Item, UUserWidget*, Widget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnIrregularListViewEntryReleasedDynamic, UObject*, Item, UUserWidget*, Widget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnIrregularListViewArrangeItemDynamic, const FGeometry&, InGeometry, UUserWidget*, InWidget, float, InProgress, UKGVector2DReference*, OutIrregularPosition);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnIrregularListViewDraggedDynamic, const FGeometry&, InGeometry, const FPointerEvent&, InTouchEvent, UKGFloatReference*, OutDeltaProgress);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnIrregularListItemSelectionChangedDynamic, UObject*, Item, bool, bIsSelected);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnIrregularListViewScrollEndedDynamic);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnIrregularListViewItemSnappedDynamic, UObject*, Item);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnIrregularListViewScrollPositionChangedDynamic, float, ScrollPosition, EKGIrregularListViewUpdateSource, UpdateSource);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnIrregularListViewInteractionStartedDynamic);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnIrregularListViewInteractionEndedDynamic);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnIrregularListViewHovered);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnIrregularListViewUnhovered);



UCLASS(meta = (EntryInterface = "/Script/KGUI.KGUserObjectIrregularListEntry", ToolTip = "异形列表", LuaComponent = "Framework.KGFramework.KGUI.Component.UIListView.UIIrregularListView"), MinimalAPI, DisplayName = "Irregular List View (KGUI)")
class UKGIrregularListView : public UWidget
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif

public:
	UKGIrregularListView(const FObjectInitializer& ObjectInitializer);

#if WITH_EDITOR
	virtual void ValidateCompiledDefaults(IWidgetCompilerLog& CompileLog) const override;
#endif
	virtual void SynchronizeProperties() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

public:
	TSubclassOf<UUserWidget> GetEntryWidgetClass() const { return EntryWidgetClass; }

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void AddItem(UObject* Item);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void RemoveItem(UObject* Item);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	int GetIndex(UObject* Item) const;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	UObject* GetItem(int Index) const;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	const TArray<UObject*>& GetListItems() const { return ListItems; }

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetListItems(const TArray<UObject*>& InListItems);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void ClearListItems();

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void RequestRefresh();

	const TObjectPtr<UObject>* ItemFromEntryWidget(const UUserWidget& EntryWidget) const;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View", meta = (DisplayName = "Get Selected Item", AllowPrivateAccess = true))
	int32 BP_GetSelectedItem() const;  // Keep the same name as ListView

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View", meta = (DisplayName = "Get Item Progress"))
	bool BP_GetItemProgress(int Index, float& OutProgress) const;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "List Entries", meta = (ClampMin = 0, ClampMax = 60))
	int32 NumDesignerPreviewEntries = 5;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Item Initialized"))
	FOnIrregularListViewEntryInitializedDynamic OnEntryInitialized;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Item Released"))
	FOnIrregularListViewEntryReleasedDynamic OnEntryReleased;

protected:
	virtual TSharedRef<SWidget> RebuildWidget() override;

	TSharedRef<IKGIrregularListEntry> HandleGenerateRow(UObject* Item, const TSharedRef<SKGIrregularListView<UObject*>>& OwnerTable);
	void HandleOnEntryInitialized(UObject* Item, const TSharedRef<IKGIrregularListEntry>& Entry);
	void HandleOnEntryReleased(UObject* Item, const TSharedRef<IKGIrregularListEntry>& Entry);
	FVector2D HandleOnArrangeItemInternal(const FGeometry& Geometry, UObject* Item, float Progress);
	float HandleOnDraggedInternal(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent);
	bool HandleOnDragStartingInternal(const FGeometry& MyGeometry, const FPointerEvent& TouchEvent);
	void HandleOnSelectionChangedInternal(UObject* Item, bool Selected, ESelectInfo::Type SelectInfo);
	void HandleOnScrollEndedInternal();
	void HandleOnItemSnappedInternal(UObject* Item);
	void HandleOnScrollPositionChanged(float InScrollPosition, EKGIrregularListViewUpdateSource UpdateSource);
	void HandleOnInteractionStarted();
	void HandleOnInteractionEnded();

	TSharedPtr<SKGObjectIrregularListEntry> GetObjectRowFromItem(UObject* Item) const;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	UUserWidget* GetEntryWidgetFromItem(UObject* Item) const;

	TSharedPtr<SKGIrregularListView<UObject*>> MyListView;  // cppcheck:ignore 野指针作为模板类型参数

	UPROPERTY(Transient)
	TObjectPtr<UKGVector2DReference> Vector2DReferenceCache;
	TObjectPtr<UKGVector2DReference>& GetVector2DReference();

	UPROPERTY(Transient)
	TObjectPtr<UKGFloatReference> FloatReferenceCache;
	TObjectPtr<UKGFloatReference>& GetFloatReference();

	UPROPERTY(Transient)
	TArray<TObjectPtr<UObject>> ListItems;

	UPROPERTY(Transient)
	FUserWidgetPool EntryWidgetPool;

protected:
	UPROPERTY(BlueprintAssignable, Category = "List View", meta = (DisplayName = "On Arrange Item"))
	FOnIrregularListViewArrangeItemDynamic OnArrangeItem;

	UPROPERTY(BlueprintAssignable, Category = "List View", meta = (DisplayName = "On Dragged"))
	FOnIrregularListViewDraggedDynamic OnDragged;

	UE_DEPRECATED(5.2, "Direct access to ScrollPosition is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetScrollPosition", Category = "List View")
	float ScrollPosition = 0;

public:
	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetScrollPosition(float InScrollPosition);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	float GetScrollPosition() const;

protected:
	UE_DEPRECATED(5.2, "Direct access to Step is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetStep", Category = "List View")
	float Step = 0.1f;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetStep(float InStep);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	float GetStep() const;

	UE_DEPRECATED(5.2, "Direct access to ElasticStyle is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetElasticStyle", Category = "List View")
	EKGElasticStyle ElasticStyle = EKGElasticStyle::Spring;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetElasticStyle(EKGElasticStyle InElasticStyle);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	EKGElasticStyle GetElasticStyle() const;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetElasticStrain", Category = "List View")
	float ElasticStrain = 1.0f;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetElasticStrain(float InElasticStrain);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	float GetElasticStrain() const;

	UE_DEPRECATED(5.2, "Direct access to Padding is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetPadding", Category = "List View")
	FKGLinearMargin Padding;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetPadding(const FKGLinearMargin& InPadding);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	FKGLinearMargin GetPadding() const;

	UPROPERTY(EditAnywhere, Category = "List View", meta=(ClampMin = 0.001))
	float Acceleration = 1.0;

	UPROPERTY(EditAnywhere, Category= "List View")
	bool bGenerateAllEntries = false;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "List Entries", meta = (DesignerRebuild, AllowPrivateAccess = true
		// 关闭KGUserIrregularListEntry接口限制
		//, MustImplement = "/Script/KGUI.KGUserIrregularListEntry"
	))
	TSubclassOf<UUserWidget> EntryWidgetClass;

	UE_DEPRECATED(5.2, "Direct access to EntryAnchors is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetEntryAnchors", Category = "List Entries")
	FAnchors EntryAnchors;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetEntryAnchors(const FAnchors& InEntryAnchors);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	FAnchors GetEntryAnchors() const;

protected:
	UE_DEPRECATED(5.2, "Direct access to InertiaEnabled is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetInertiaEnabled", Category = "List View")
	bool InertiaEnabled = false;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetInertiaEnabled(bool InInertiaEnabled);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	bool GetInertiaEnabled() const;
	
	UE_DEPRECATED(5.2, "Direct access to CyclicEnabled is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetCyclicEnabled", Category = "List View")
	bool CyclicEnabled = true;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetCyclicEnabled(bool InCyclicEnabled);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	bool GetCyclicEnabled() const;

protected:
	UE_DEPRECATED(5.2, "Direct access to SnapEnabled is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetSnapEnabled", Category = "List View")
	bool SnapEnabled = false;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetSnapEnabled(bool InSnapEnabled);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	bool GetSnapEnabled() const;

	UE_DEPRECATED(5.2, "Direct access to SnapAlignment is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetSnapAlignment", Category = "List View")
	float SnapAlignment = 0.5f;;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetSnapAlignment(float InSnapAlignment);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	float GetSnapAlignment() const;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetOverlayStyle", Category = "List View")
	EKGOverlayStyle OverlayStyle = EKGOverlayStyle::None;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void SetOverlayStyle(EKGOverlayStyle InOverlayStyle);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	EKGOverlayStyle GetOverlayStyle() const;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void AddOverlayIncrementalItem(UObject* Item);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void RemoveOverlayIncrementalItem(UObject* Item);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void BP_AddOverlayIncrementalItem(int Index);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	void BP_RemoveOverlayIncrementalItem(int Index);

	UPROPERTY(Transient)
	TArray<UObject*> OverlayIncrementalItems;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Item Snapped"))
	FOnIrregularListViewItemSnappedDynamic OnItemSnapped;

	UPROPERTY(BlueprintAssignable, Category = Events)
	FOnIrregularListViewScrollPositionChangedDynamic OnScrollPositionChanged;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	bool ScrollToIndex(int ItemIndex, bool bAnimated);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	bool ScrollToItem(UObject* Item, bool bAnimated);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	bool ScrollToPosition(float TargetScrollPosition, bool bAnimated);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	int GetScrollingTargetIndex();

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View")
	UObject* GetScrollingTargetItem();

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Scroll Ended"))
	FOnIrregularListViewScrollEndedDynamic OnScrollEnded;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Interaction Started"))
	FOnIrregularListViewInteractionStartedDynamic OnInteractionStarted;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Interaction Ended"))
	FOnIrregularListViewInteractionEndedDynamic OnInteractionEnded;

protected:
	UE_DEPRECATED(5.2, "Direct access to SelectionMode is deprecated. Please use the getter or setter.")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetSelectionMode", Category = "List View")
	TEnumAsByte<ESelectionMode::Type> SelectionMode = ESelectionMode::None;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View", meta = (AllowPrivateAccess = true))
	void SetSelectionMode(ESelectionMode::Type InSelectionMode);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View", meta = (AllowPrivateAccess = true))
	ESelectionMode::Type GetSelectionMode() const;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View", meta = (AllowPrivateAccess = true, DisplayName = "Set Item Selection"))
	void SetItemSelection(UObject* Item, bool bSelected);

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View", meta = (AllowPrivateAccess = true, DisplayName = "Clear Selection"))
	void ClearSelection();

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View", meta = (AllowPrivateAccess = true, DisplayName = "Set Item Selection"))
	bool IsItemSelected(UObject* Item) const;

	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Irregular List View", meta = (AllowPrivateAccess = true, DisplayName = "Get Selected Items"))
	bool GetSelectedItems(TArray<UObject*>& Items) const;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Item Selection Changed"))
	FOnIrregularListItemSelectionChangedDynamic OnItemSelectionChanged;

protected:
	UPROPERTY(Transient, EditAnywhere, Category=Animation, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetFadeInProgress")
	float FadeInProgress = 1;

	UFUNCTION(BlueprintCallable)
	void SetFadeInProgress(float Progress);

	UFUNCTION(BlueprintCallable)
	float GetFadeInProgress() const { return FadeInProgress; }

	UPROPERTY(Transient, EditAnywhere, Category = Animation, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetFadeOutProgress")
	float FadeOutProgress = 0;

	UFUNCTION(BlueprintCallable)
	void SetFadeOutProgress(float Progress);

	UFUNCTION(BlueprintCallable)
	float GetFadeOutProgress() const { return FadeOutProgress; }

protected:
	UPROPERTY(Transient, EditAnywhere, Category = Animation, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetCustomScalarParameter0")
	float CustomScalarParameter0 = 0;

public:
	UFUNCTION(BlueprintCallable)
	void SetCustomScalarParameter0(float Progress);

	UFUNCTION(BlueprintCallable)
	float GetCustomScalarParameter0() const { return CustomScalarParameter0; }

protected:
	UPROPERTY(Transient, EditAnywhere, Category = Animation, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetCustomScalarParameter1")
	float CustomScalarParameter1 = 0;

public:
	UFUNCTION(BlueprintCallable)
	void SetCustomScalarParameter1(float Progress);

	UFUNCTION(BlueprintCallable)
	float GetCustomScalarParameter1() const { return CustomScalarParameter1; }

protected:
	UPROPERTY(Transient, EditAnywhere, Category = Animation, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetCustomScalarParameter2")
	float CustomScalarParameter2 = 0;

public:
	UFUNCTION(BlueprintCallable)
	void SetCustomScalarParameter2(float Progress);

	UFUNCTION(BlueprintCallable)
	float GetCustomScalarParameter2() const { return CustomScalarParameter2; }

protected:
	UPROPERTY(Transient, EditAnywhere, Category = Animation, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetCustomScalarParameter3")
	float CustomScalarParameter3 = 0;

public:
	UFUNCTION(BlueprintCallable)
	void SetCustomScalarParameter3(float Progress);

	UFUNCTION(BlueprintCallable)
	float GetCustomScalarParameter3() const { return CustomScalarParameter3; }

protected:
	void HandleOnHovered();
	void HandleOnUnhovered();

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Hovered"))
	FOnIrregularListViewHovered OnHovered;

	UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On Unhovered"))
	FOnIrregularListViewUnhovered OnUnhovered;

	float GetWheelScrollMultiplier() const { return WheelScrollMultiplier; }

	UPROPERTY(EditAnywhere, Category = Scrolling)
	float WheelScrollMultiplier = 0;

protected:
	void RebuildBackground();

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = ListView, meta = (DesignerRebuild, AllowPrivateAccess = true))
	TSubclassOf<UUserWidget> BackgroundClass;

	UPROPERTY(Transient)
	TObjectPtr<UUserWidget> BackgroundInstance;

protected:
	UPROPERTY(EditAnywhere, Category = Performance)
	bool bForceRefreshEveryFrame = false;

public:
	UFUNCTION(BlueprintCallable)
	void SetForceRefreshEveryFrameEnabled(bool bEnabled) { bForceRefreshEveryFrame = bEnabled; }

	UFUNCTION(BlueprintCallable)
	bool IsForceRefreshEveryFrameEnabled() const { return bForceRefreshEveryFrame; }
};