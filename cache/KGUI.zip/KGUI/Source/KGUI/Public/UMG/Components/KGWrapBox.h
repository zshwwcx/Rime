// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/WrapBox.h"
#include "KGWrapBox.generated.h"

/**
 * 
 */
UCLASS(DisplayName = "Wrap Box (KGUI)", meta = (ToolTip = "包裹框"))
class KGUI_API UKGWrapBox : public UWrapBox
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif

protected:
	virtual void SynchronizeProperties() override;
	virtual TSharedRef<SWidget> RebuildWidget() override;

public:
	EVerticalAlignment GetVerticalAlignment() const;

	UFUNCTION(BlueprintCallable, Category = "Content Layout")
	void SetVerticalAlignment(EVerticalAlignment InVerticalAlignment);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Getter, Setter, BlueprintSetter = "SetVerticalAlignment", Category = "Content Layout", meta = (DisplayAfter = "HorizontalAlignment"))
	TEnumAsByte<EVerticalAlignment> VerticalAlignment = EVerticalAlignment::VAlign_Top;

	UPROPERTY(EditAnywhere, Category = "Content Layout", meta = (DisplayAfter = "VerticalAlignment"))
	EKGWrapBoxLineStacking LineStacking = EKGWrapBoxLineStacking::Forward;
};
