#pragma once

#include "CoreMinimal.h"
#include "Framework/Text/RichTextLayoutMarshaller.h"

class URichTextBlockDecorator;

class FKGRichTextLayoutMarshaller : public FRichTextLayoutMarshaller
{
	using Super = FRichTextLayoutMarshaller;

public:
	static TSharedRef<FKGRichTextLayoutMarshaller> Create(TArray<TSharedRef<ITextDecorator>> InDecorators, const ISlateStyle* const InDecoratorStyleSet);
	static TSharedRef<FKGRichTextLayoutMarshaller> Create(TSharedPtr<IRichTextMarkupParser> InParser, TSharedPtr<IRichTextMarkupWriter> InWriter, TArray<TSharedRef<ITextDecorator>> InDecorators, const ISlateStyle* const InDecoratorStyleSet);

	void SetInstanceDecorators(const TArray<TWeakObjectPtr<URichTextBlockDecorator>>& InInstanceDecorators);

protected:
	FKGRichTextLayoutMarshaller(TArray<TSharedRef<ITextDecorator>> InDecorators, const ISlateStyle* const InDecoratorStyleSet);
	FKGRichTextLayoutMarshaller(TSharedPtr<IRichTextMarkupParser> InParser, TSharedPtr<IRichTextMarkupWriter> InWriter, TArray<TSharedRef<ITextDecorator>> InDecorators, const ISlateStyle* const InDecoratorStyleSet);

	virtual void SetText(const FString& SourceString, FTextLayout& TargetTextLayout) override;

	virtual void AppendRunsForText(
		const int32 LineIndex,
		const FTextRunParseResults& TextRun,
		const FString& ProcessedString,
		const FTextBlockStyle& DefaultTextStyle,
		const TSharedRef<FString>& InOutModelText,
		FTextLayout& TargetTextLayout,
		TArray<TSharedRef<IRun>>& Runs,
		TArray<FTextLineHighlight>& LineHighlights,
		TMap<const FTextBlockStyle*, TSharedPtr<FSlateTextUnderlineLineHighlighter>>& CachedUnderlineHighlighters,
		TMap<const FTextBlockStyle*, TSharedPtr<FSlateTextStrikeLineHighlighter>>& CachedStrikeLineHighlighters
	) override;

	TArray<TWeakObjectPtr<URichTextBlockDecorator>> WeakInstanceDecorators;

	const FTextBlockStyle* FindTextBlockStyleByRunInfo(const FRunInfo& RunInfo) const;
};
