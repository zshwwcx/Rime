// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ScaleBox.h"
#include "KGScaleBox.generated.h"

/**
 * 
 */
UCLASS(DisplayName = "Scale Box (KGUI)", meta = (ToolTip = "缩放框"))
class KGUI_API UKGScaleBox : public UScaleBox
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif
	
};
