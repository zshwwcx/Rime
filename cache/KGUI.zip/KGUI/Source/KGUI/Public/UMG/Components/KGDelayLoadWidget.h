﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Widgets/SWidget.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "KGDelayLoadWidget.generated.h"

struct FStreamableHandle;
class SBox;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FLoadFinishDelegate, UKGUserWidget*, Widget);

UENUM()
enum class EDelayLoadType : uint8
{
	//自动加载，在RebuildWidget时
	AutoLoadOnRebuild,
	//手动加载，业务自定义
	CustomLoad,
};

UCLASS()
class KGUI_API UKGDelayLoadWidget : public UWidget
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	void CreateDelayWidgetAsync();
	UFUNCTION(BlueprintCallable)
	void CreateDelayWidgetSync();
	UFUNCTION(BlueprintCallable)
	UKGUserWidget* GetDelayWidget();
	UFUNCTION(BlueprintCallable)
	bool IsDelayWidgetLoaded();

protected:
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void ValidateCompiledDefaults(IWidgetCompilerLog& CompileLog) const override;
#endif
	virtual TSharedRef<SWidget> RebuildWidget() override;
	
private:
	void LoadWidgetAsync();
	void LoadWidgetSync();
	void OnWidgetClassAsyncLoaded();
	void ShowWidget();
	void CreateDelayWidget(bool Async);

public:
	UPROPERTY(BlueprintAssignable)
	FLoadFinishDelegate OnLoadFinishEvent;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UIDelayWidget")
	TSoftClassPtr<UKGUserWidget> DelayWidgetClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UIDelayWidget")
	EDelayLoadType DelayLoadType;
	
	UPROPERTY()
	TObjectPtr<UKGUserWidget> DelayWidget;

	TSharedPtr<FStreamableHandle> StreamingHandle;
	TSharedPtr<SBox> MyBox;
};