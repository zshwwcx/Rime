// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ProgressBar.h"
#include "Tickable.h"

#include "KGAnimatedProgressBar.generated.h"

UENUM()
enum class EKGAnimatedProgressBarBlendType : uint8
{
	Additive,
	OneByOne,
	OnWayAdditive,
};

UENUM()
enum class EKGAnimatedProgressBarSpeedType  : uint8
{
	TimeSecond,
	RatePerSecond
};


USTRUCT()
struct FKGAnimatedProgressBarBlendTask
{
	GENERATED_USTRUCT_BODY()
	bool bIsIncrease = false;
	float DelayRemain = 0;
	float PercentDeltaReamin = 0;
    float SpeedRatePerSec = 0;
};


DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnLoopNumChangedEvent, int,PrevLoop,int,CurrentLoop);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnPercentChanged, float,Percent);

/**
 * 
 */
UCLASS()
class KGUI_API UKGAnimatedProgressBar : public UProgressBar,public FTickableGameObject
{
	GENERATED_BODY()
public:
	virtual void BeginDestroy() override;

	UFUNCTION(BlueprintCallable)
	void SetPercentWithBlend(float InPercent);

	UFUNCTION(BlueprintCallable)
	void SetPercentWithBlendCustomeSpeed(float InPercent,EKGAnimatedProgressBarSpeedType AnimSpeedType 
	= EKGAnimatedProgressBarSpeedType::TimeSecond ,float Speed = 0,float Delay = 0);

	UFUNCTION(BlueprintCallable)
	void SetPercentInstant(float InPercent);

	UFUNCTION(BlueprintCallable)
	void SetBlendType(EKGAnimatedProgressBarBlendType InBlendType);

	UFUNCTION(BlueprintCallable)
	void SetIncreaseDelay(float InDelay);

	UFUNCTION(BlueprintCallable)
	void SetDecreaseDelay(float InDelay);

	UFUNCTION(BlueprintCallable)
	void SetPercentEachLoop(float& InLoop);

	UFUNCTION(BlueprintCallable)
	void SetSpeed(EKGAnimatedProgressBarSpeedType InAnimSpeedType,float InIncreaseSpeed,float InDecreaseSpeed);
	
	UPROPERTY(EditAnywhere,Category= "Animation")
	EKGAnimatedProgressBarBlendType BlendType = EKGAnimatedProgressBarBlendType::Additive;

	UPROPERTY(EditAnywhere,Category= "Animation")
	EKGAnimatedProgressBarSpeedType AnimSpeedType = EKGAnimatedProgressBarSpeedType::TimeSecond;
	
	UPROPERTY(EditAnywhere,Category= "Animation")
	float IncreaseSpeed = 0;

	UPROPERTY(EditAnywhere,Category= "Animation")
	float DecreaseSpeed = 0;
	
	UPROPERTY(EditAnywhere,Category= "Animation")
	float AnimIncreaseStartDelay = 0;

	UPROPERTY(EditAnywhere,Category= "Animation")
	float AnimDecreaseStartDelay = 0;

	UPROPERTY(EditAnywhere,Category= "Animation")
	bool bLoopPercent;
	
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category= "Animation", meta = (EditCondition= "bLoopPercent"))
	float PercentEeachLoop = 1;

	
	int CurrentLoop = 0;
	
	UPROPERTY(BlueprintCallable)
	FOnLoopNumChangedEvent OnLoopNumChanged;
	
	UPROPERTY(BlueprintCallable)
	FOnPercentChanged OnPercentChanged;
	
	//Tickable Object Override
	virtual void Tick(float DeltaTime) override;
	virtual TStatId GetStatId() const override;
	virtual bool IsTickable() const override;

	TArray<FKGAnimatedProgressBarBlendTask> BlendTasks;
private:
	void ProcessOneBlendTask(FKGAnimatedProgressBarBlendTask& Task,float& InCurrentPercent,float& DelatTime);

	void SetPercent(float InPercent);
	
	float TargetPercent;
	float CurrentPercent;
	
	bool CurrentIncreasing=false;

};
