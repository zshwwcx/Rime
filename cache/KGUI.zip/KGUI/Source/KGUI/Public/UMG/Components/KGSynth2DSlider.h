﻿#pragma once

#include "CoreMinimal.h"
#include "UI/Synth2DSlider.h"
#include "KGSynth2DSlider.generated.h"

/**
 * 
 */
UCLASS()
class KGUI_API UKGSynth2DSlider : public USynth2DSlider
{
	GENERATED_BODY()

public:
	UFUNCTION()
	UMaterialInstanceDynamic* GetBGImageDynamicMaterial();
};
