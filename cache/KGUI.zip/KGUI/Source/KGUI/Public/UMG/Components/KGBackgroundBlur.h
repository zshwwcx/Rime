#pragma once

#include "CoreMinimal.h"
#include "Components/BackgroundBlur.h"

#include "KGBackgroundBlur.generated.h"

UCLASS(DisplayName = "Background Blur (KGUI)", meta = (ToolTip = "背景模糊"))
class KGUI_API UKGBackgroundBlur : public UBackgroundBlur
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif
};
