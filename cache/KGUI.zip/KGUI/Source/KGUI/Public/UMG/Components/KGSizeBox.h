// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/SizeBox.h"
#include "KGSizeBox.generated.h"

/**
 * 
 */
UCLASS(DisplayName = "Size Box (KGUI)", meta = (ToolTip = "尺寸框"))
class KGUI_API UKGSizeBox : public USizeBox
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif

	
};
