// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/CanvasPanel.h"
#include "KGBoneWidget.generated.h"

/**
 * 
 */
UCLASS()
class KGUI_API UKGBoneWidget : public UCanvasPanel
{
	GENERATED_UCLASS_BODY()
public:
	virtual void SynchronizeProperties();
#if WITH_EDITOR
	virtual void SetCanRename(bool bNewCanRename);
private:
	bool IsInSkeletal();
#endif
};
