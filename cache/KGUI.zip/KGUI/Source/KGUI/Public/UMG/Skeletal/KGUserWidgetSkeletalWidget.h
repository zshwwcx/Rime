#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Blueprint/UserWidget.h"
#include "KGUserWidgetSkeletalWidget.generated.h"


UCLASS(Blueprintable, meta=( DontUseGenericSpawnObject="True", DisableNativeTick))
class KGUI_API UKGUserWidgetSkeletalWidget : public UUserWidget
{
	GENERATED_UCLASS_BODY()

public:
	virtual void PreSave(FObjectPreSaveContext SaveContext) override;

protected:
	virtual void NativePreConstruct() override;

	virtual void OnWidgetRebuilt() override;


public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	FSoftObjectPath AnimSkeletonWidget;
};
