#pragma once

#include "CoreMinimal.h"
#include "UMG/StateManagement/KGStateGroup.h"
#include "UMG/StateManagement/KGStateController.h"

struct KGUI_API FKGStateControllerSnapshot
{
public:
    TArray<FKGStateGroup> StateGroups;
    FKGStateController StateController;

    void ResetStateGroupCurrentIndices();
    void SynchronizeStateGroupCurrentIndices(FKGStateControllerSnapshot& TargetStateControllerSnapshot);
    int GetStraightenIndex();
    int GetStraightenCount();
    bool Increase();

public:
    static FKGStateControllerSnapshot Create(const FKGStateController& StateController);
};