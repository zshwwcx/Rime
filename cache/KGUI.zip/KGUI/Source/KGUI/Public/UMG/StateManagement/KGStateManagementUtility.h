#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"

class FKGStateManagementUtility
{
public:
	KGUI_API static UUserWidget* GetOwnerUserWidget(UWidget* Widget);
};
