#pragma once

#include "CoreMinimal.h"
#include "Engine/DataTable.h"

#include "KGStateGroupDeclaration.generated.h"

USTRUCT(Blueprintable)
struct FKGStateGroupStateInfo
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere)
	FString Name;
};

USTRUCT(Blueprintable, BlueprintType)
struct FKGStateGroupDeclaration : public FTableRowBase
{
	GENERATED_BODY()

	friend class UKGUISettings;

public:
	const TArray<FKGStateGroupStateInfo>& GetStateInfos() const { return StateInfos; }
	const FString& GetName() const { return Name; }

private:
	UPROPERTY(EditAnywhere)
	TArray<FKGStateGroupStateInfo> StateInfos;

	// 由DataTable的RowName决定，这里不序列化，通过接口获取时自动根据RowName补上Name的数据
	FString Name;
};