#pragma once

#include "CoreMinimal.h"
#include "UMG.h"

#include "KGState.generated.h"

USTRUCT()
struct FKGState
{
    GENERATED_USTRUCT_BODY()

    UPROPERTY(EditAnywhere)
    FString Name;
};