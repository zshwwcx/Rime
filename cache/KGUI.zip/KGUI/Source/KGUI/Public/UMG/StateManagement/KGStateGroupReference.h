#pragma once

#include "CoreMinimal.h"
#include "UMG.h"

#include "KGStateGroup.h"

#include "KGStateGroupReference.generated.h"

UENUM()
enum class EKGStateGroupSource : uint8
{
    Empty = 0,      // 空来源
    Self = 1,       // 状态控制上面设置的状态组数据指向的节点和状态控制所在的节点一致
    Colleague = 2,  // 状态控制所在的节点的WidgetTree上其他的节点
    Owner = 3,      // 状态控制所在的节点所在的UserWidget节点
};

USTRUCT()
struct KGUI_API FKGStateGroupReference
{
    GENERATED_USTRUCT_BODY()

public:
	FKGStateGroupReference();
    bool IsReferenceOf(const FKGStateGroup& StateGroup) const;
	bool IsEmpty() const;
	void Initialize(UWidget* Self, UUserWidget* Owner);

public:
	UPROPERTY(EditAnywhere)
	EKGStateGroupSource Source;

    UPROPERTY(EditAnywhere)
    TObjectPtr<UWidget> Colleague;

    UPROPERTY(EditAnywhere)
    FString Name;

	UWidget* GetWidget() const;
	void SetWidgetInternal(UWidget* Widget);

private:
	TWeakObjectPtr<UWidget> Widget;

public:
    friend bool operator==(const FKGStateGroupReference& A, const FKGStateGroupReference& B)
    {
        return
            A.GetWidget() == B.GetWidget() &&
            A.Name == B.Name;
    }

    friend uint32 GetTypeHash(const FKGStateGroupReference& Reference)
    {
        return GetTypeHash(Reference.GetWidget()) ^ GetTypeHash(Reference.Name);
    }

public:
    /// 创建状态组引用`StateGroupReference`仅传入必要参数的接口内部接口
    /// @param Source 状态组所在控件节点
    /// @param Target 状态控制所在控件节点
    /// @param StateGroupName 状态组名字
    /// @return 状态组引用数据
    static FKGStateGroupReference CreateInternal(UWidget* Source, UWidget* Target, FString StateGroupName);

public:
    static FKGStateGroupReference GetEmpty();
};