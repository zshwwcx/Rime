#pragma once

#include "CoreTypes.h"
#include "Misc/Guid.h"

struct FKGStateManagementCustomVersion
{
	enum Type
	{
		BeforeCustomVersionWasAdded = 0,

		CustomSerializableVariantSerialization,

		// -----<new versions can be added above this line>-------------------------------------------------
		VersionPlusOne,
		LatestVersion = VersionPlusOne - 1
	};

	KGUI_API const static FGuid GUID;

private:
	FKGStateManagementCustomVersion() {}
};
