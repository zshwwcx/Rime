#pragma once

#include "CoreMinimal.h"
#include "UObject/UnrealType.h"
#include "Misc/Variant.h"

#include "UMG/StateManagement/KGStateGroup.h"
#include "UMG/StateManagement/KGStateGroupReference.h"
#include "UMG/StateManagement/KGSerializableVariant.h"

#include "KGStateController.generated.h"

USTRUCT()
struct KGUI_API FKGStateController
{
    GENERATED_USTRUCT_BODY()

    friend class UKGStateManagement;
    friend struct FKGStateGroup;
    friend struct FKGStateControllerSnapshot;

    friend class SKGStateManagementField;
    friend class SKGStateControllerField;
    friend struct FKGStateManagementDependenceChangeSession;
	friend class SKGStateManagementTab;

public:
    FKGStateController();
    FKGStateController(TWeakObjectPtr<UWidget> InWidget);

public:
    UPROPERTY(EditAnywhere)
    TArray<FKGStateGroupReference> StateGroupReferences;

    bool ContainsStateGroup(const FKGStateGroupReference& Reference);
    bool AddStateGroup(const FKGStateGroupReference& Reference);
    bool RemoveStateGroup(const FKGStateGroupReference& Reference);

public:
    UPROPERTY(EditAnywhere)
    TFieldPath<FProperty> PropertyPath;
    void SetPropertyPath(const TFieldPath<FProperty>& InPropertyPath);

    UPROPERTY(EditAnywhere)
    TArray<FKGSerializableVariant> PropertyValues;

    bool ShouldCollect(FProperty* Property) const;

    bool Collect();
    bool Apply();
    UObject* GetTarget();
    bool IsValid();

public:
    UWidget* GetWidget() const;

private:
    TWeakObjectPtr<UWidget> Widget;

public:
    static TArray<TFieldPath<FProperty>> GetStateControllerProperties(UWidget* Widget);
	FKGStateGroupReference CreateStateGroupReference(const FKGStateGroup& StateGroup) const;

    void PreSave(FObjectPreSaveContext SaveContext);
    void PostLoad();
};