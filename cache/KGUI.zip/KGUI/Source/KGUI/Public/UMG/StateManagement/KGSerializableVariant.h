#pragma once

#include "CoreMinimal.h"

#include "KGSerializableVariant.generated.h"

struct FKGStateControllerPropertyCustomization;

USTRUCT(meta = (ShallowCopy))
struct KGUI_API FKGSerializableVariant
{
    GENERATED_USTRUCT_BODY()

    friend struct FKGStateManagementDependenceChangeSession;

public:
    FKGSerializableVariant();
    FKGSerializableVariant(const FKGSerializableVariant& SerializableVariant);
    ~FKGSerializableVariant();
    FKGSerializableVariant& operator=(const FKGSerializableVariant& Other);

    void Copy(void* Dest, void const* Src);

private:
    UPROPERTY()
    TArray<uint8> Data;

    UPROPERTY()
    TFieldPath<FProperty> PropertyPath;

public:
    TArray<uint8> Data_;
    TFieldPath<FProperty> PropertyPath_;

    template <typename ValueType>
    inline ValueType* GetData() { return (ValueType*)Data_.GetData(); }

    template <typename ValueType>
    inline const ValueType* GetData() const { return (ValueType*)Data_.GetData(); }

    template <typename ValueType>
    inline ValueType& GetValue() { return *GetData<ValueType>(); }

    template <typename ValueType>
    inline const ValueType& GetValue() const { return *GetData<ValueType>(); }

    bool Collect(UObject* Object, const TFieldPath<FProperty>& InPropertyPath);
    bool Apply(UObject* Object, const TFieldPath<FProperty>& InPropertyPath);
    void Reinitialize(const TFieldPath<FProperty>& InPropertyPath);
    void Construct(const TFieldPath<FProperty>& InPropertyPath);
    void Destruct();

    void PreSave(FObjectPreSaveContext SaveContext);
    void PostLoad();

    bool Serialize(FArchive& Ar);
    void PostSerialize(const FArchive& Ar);
    bool ExportTextItem(FString& ValueStr, FKGSerializableVariant const& DefaultValue, UObject* Parent, int32 PortFlags, UObject* ExportRootScope) const;
    bool ImportTextItem(const TCHAR*& Buffer, int32 PortFlags, UObject* Parent, FOutputDevice* ErrorText);

private:
    void TryNormalizeBitwiseBooleanProperty();
    TSharedPtr<FKGStateControllerPropertyCustomization> GetStateControllerPropertyCustomization(const TFieldPath<FProperty>& InPropertyPath);
};


template<>
struct TStructOpsTypeTraits<FKGSerializableVariant> : public TStructOpsTypeTraitsBase2<FKGSerializableVariant>
{
    enum
    {
        WithSerializer = true,
        WithPostSerialize = true,
        WithExportTextItem = true,
        WithImportTextItem = true,
    };
};