#pragma once

#include "CoreMinimal.h"
#include "CoreGlobals.h"
#include "UMG.h"

#include "UMG/StateManagement/KGStateManagement.h"

class IKGScriptableStateGroup;

struct FKGScriptableStateGroupContext : TSharedFromThis<FKGScriptableStateGroupContext>
{
public:
	FKGScriptableStateGroupContext();

	TWeakObjectPtr<UWidget> Widget;
	TWeakPtr<IKGScriptableStateGroup> ScriptableStateGroup;

	template<typename WidgetType>
	inline WidgetType* AsWidget()
	{
		return Cast<WidgetType>(Widget.Get());
	}
};

class IKGScriptableStateGroup : public TSharedFromThis<IKGScriptableStateGroup>
{
public:
	virtual ~IKGScriptableStateGroup() = default;
	virtual UClass* GetClass() = 0;
	virtual FTopLevelAssetPath GetClassName() = 0;
	virtual const FString& GetStateGroupName() = 0;
	virtual int GetStateCount() = 0;
	virtual const FString& GetStateDisplayName(int Index) = 0;
	virtual TSharedPtr<FKGScriptableStateGroupContext> __Internal_Bind(UWidget* Widget) = 0;
	virtual void __Internal_Unbind(TSharedPtr<FKGScriptableStateGroupContext> Context) = 0;
	virtual void __Internal_UpdateState(UWidget* Widget, bool bForce = false) = 0;
	virtual int GetCurrent(UWidget* Widget) = 0;
};

template<typename WidgetType, typename ContextType>
class TKGScriptableStateGroup : public IKGScriptableStateGroup
{
public:
	static_assert(TIsDerivedFrom<WidgetType, UWidget>::Value,
		"Declare state group ScriptableStateGroup with a type derived from UWidget");

	TKGScriptableStateGroup() {}

	virtual UClass* GetClass() override
	{
		return WidgetType::StaticClass();
	}

	virtual FTopLevelAssetPath GetClassName() override
	{
		return GetClass()->GetStructPathName();
	}

	virtual TSharedPtr<FKGScriptableStateGroupContext> __Internal_Bind(UWidget* Widget) override
	{
		TSharedPtr<FKGScriptableStateGroupContext> Context = MakeShared<ContextType>();
		Context->Widget = Widget;
		Context->ScriptableStateGroup = this->AsWeak();
		UE_LOG(LogStateManagement, Log, TEXT("Bind %s %p to state group \"%s\""), *Widget->GetName(), Widget, *GetClass()->GetName());
		Bind(Cast<WidgetType>(Widget), StaticCastSharedPtr<ContextType>(Context));
		return MoveTemp(Context);
	}

	virtual void Bind(WidgetType* Widget, TSharedPtr<ContextType> Context) = 0;

	virtual void __Internal_Unbind(TSharedPtr<FKGScriptableStateGroupContext> Context) override
	{
		auto* Widget = Context->Widget.Get();
		if (Widget != NULL)
		{
			UE_LOG(LogStateManagement, Log, TEXT("Unbind %s %p from state group \"%s\""), *Widget->GetName(), Widget, *GetClass()->GetName());
		}
		Unbind(StaticCastSharedPtr<ContextType>(Context));
	}

	virtual void Unbind(TSharedPtr<ContextType> Context) = 0;

	virtual void __Internal_UpdateState(UWidget* Widget, bool bForce = false) override
	{
		UpdateState(Cast<WidgetType>(Widget), bForce);
	}

	virtual int GetCurrent(UWidget* Widget) override { return GetCurrent(Cast<WidgetType>(Widget)); }

	virtual int GetCurrent(WidgetType* Widget) = 0;

	virtual const FString& GetStateGroupName() override
	{
		return StateGroupName;
	}

	virtual int GetStateCount() override
	{
		return StateDisplayNames.Num();
	}

	virtual const FString& GetStateDisplayName(int Index) override
	{
		return StateDisplayNames[Index];
	}

	void UpdateState(WidgetType* Widget, bool bForce=false)
	{
		UKGStateManagement* StateManagement = Widget->template GetComponent<UKGStateManagement>();
		if (StateManagement != NULL)
		{
			StateManagement->ChangeState(GetStateGroupName(), GetCurrent(Widget), false, bForce);
		}
	}

protected:
	FString StateGroupName;
	TArray<FString> StateDisplayNames;
};

inline FString GetUnprefixedName(const FString& Name)
{
	for (int Index = 0; Index < Name.Len() - 1; ++Index)
	{
		if (!FChar::IsUpper(Name[Index + 1]))
		{
			return Name.Mid(Index);
		}
	}
	return Name.Mid(Name.Len() - 1);
}

#define DECLARE_STATE_GROUP_EXPAND(...) __VA_ARGS__

#define DECLARE_STATE_GROUP_VARIADIC(NAME, V0, V1, V2, V3, V4, V5, V6, ...)  \
	public:                                                                  \
	enum class EStates                                                       \
	{                                                                        \
		V0 = 0, V1 = 1, V2 = 2, V3 = 3, V4 = 4, V5 = 5, V6 = 6, Unknown = -1 \
	};                                                                       \
	NAME()                                                                   \
	{                                                                        \
		StateGroupName = GetUnprefixedName(#NAME);                           \
		StateDisplayNames = { #V0, #V1, #V2, #V3, #V4, #V5, #V6 };           \
		for (int i = StateDisplayNames.Num() - 1; i >= 0; i--)               \
		{                                                                    \
			if (StateDisplayNames[i].StartsWith("__"))                       \
			{                                                                \
				StateDisplayNames.RemoveAt(i);                               \
			}                                                                \
		}                                                                    \
	}

#define DECLARE_STATE_GROUP(...) DECLARE_STATE_GROUP_EXPAND(DECLARE_STATE_GROUP_VARIADIC(__VA_ARGS__, __2, __3, __4, __5, __6))
