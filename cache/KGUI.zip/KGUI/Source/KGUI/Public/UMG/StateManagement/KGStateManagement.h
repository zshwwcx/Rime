#pragma once

#include "CoreMinimal.h"
#include "CoreGlobals.h"
#include "KGStateManagementUtility.h"
#include "Containers/ObservableArray.h"
#include "Componentization/KGWidgetComponent.h"

#include "UMG/StateManagement/KGStateGroup.h"
#include "UMG/StateManagement/KGStateController.h"

#include "KGStateManagement.generated.h"

KGUI_API DECLARE_LOG_CATEGORY_EXTERN(LogStateManagement, Log, All);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGOnStateGroupCurrentChanged, const FString&, StateGroupName, int, Index);

UCLASS(DisplayName = "State Management", meta = (DisallowMultipleComponent))
class KGUI_API UKGStateManagement : public UKGWidgetComponent
{
    GENERATED_BODY()

    friend class FKGUIEditorModule;

protected:
    virtual void OnWidgetRebuilt() override;
    virtual void OnBeginDestroy() override;
	static void ApplyHierarchically(UWidget* Current, const FKGStateGroup& StateGroup, int Level = 0);

public:
    UFUNCTION(BlueprintCallable, Category = "State Management")
    bool ChangeState(const FString& Name, int Index, bool bForce);

	bool ChangeState(const FString& Name, int Index, bool bUpdateOverrideAnyway, bool bForce);

    UPROPERTY(BlueprintAssignable, Category = Events, meta = (DisplayName = "On State Group Current Changed"))
    FKGOnStateGroupCurrentChanged OnStateGroupCurrentChanged;

    DECLARE_MULTICAST_DELEGATE_TwoParams(FOnStateControllerApplied, UKGStateManagement*, FKGStateController*);
    static FOnStateControllerApplied OnStateControllerApplied;

    #pragma region State Group

public:
    UPROPERTY(VisibleAnywhere)
    TArray<FKGStateGroup> StateGroups;

    int AddStateGroup(const FString& Name);
    bool RemoveStateGroup(TArray<FKGStateGroup>::SizeType Index);
    bool RemoveStateGroup(const FString& Name);
    FKGStateGroup* FindStateGroup(const FString& Name);

    bool GetStateGroupCurrentValue(const FString& Name, int& Current, bool bIncludeOverride = true);
	void SetStateGroupCurrentValue(const FString& Name, int Current, bool bUpdateOverrideAnyway);

public:
    template <typename OutputType>
    TArray<OutputType> GetControllingStateGroups(TFunction<OutputType(UKGStateManagement*, int)> Pred)
    {
        TArray<OutputType> StateGroupOutputs;
		auto Collect = [&StateGroupOutputs, &Pred](UWidget* Widget) {
			UKGStateManagement* StateManagement = Widget->GetComponent<UKGStateManagement>();
			if (StateManagement != NULL)
			{
				for (int I = StateManagement->StateGroups.Num() - 1; I >= 0; I--)
				{
					StateGroupOutputs.Insert(Pred(StateManagement, I), 0);
				}
			}
		};
		UWidget* Last = NULL;
        UWidget* Current = this->GetWidget();
        while (Current != NULL)
        {
			Collect(Current);
			Last = Current;
            Current = Current->GetParent();
        }
		UUserWidget* UserWidget = FKGStateManagementUtility::GetOwnerUserWidget(Last);
		if (UserWidget != NULL)
		{
			Collect(UserWidget);
		}
        return MoveTemp(StateGroupOutputs);
    }

    TArray<FKGStateGroupReference> GetControllingStateGroupReferences();

private:
    int GetStateGroupIndexByName(const FString& Name);

    #pragma endregion

	#pragma region State Group Current Value Override

public:
	UPROPERTY(VisibleAnywhere)
	TMap<FString, int> StateGroupCurrentValueOverrides;

	#pragma endregion

    #pragma region State Controller

public:
    UPROPERTY(VisibleAnywhere)
    TArray<FKGStateController> StateControllers;

    int AddStateController();
    bool RemoveStateController(int Index);

    #pragma endregion

public:

#if WITH_EDITOR
	static bool IsDeclarationReadOnly(UWidget* Widget);
#endif

	virtual void PreSave(FObjectPreSaveContext SaveContext) override;
    virtual void PostLoad() override;
};
