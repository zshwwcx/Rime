#pragma once

#include "CoreMinimal.h"

#include "KGState.h"

#include "KGStateGroup.generated.h"

struct FKGScriptableStateGroupContext;

USTRUCT()
struct KGUI_API FKGStateGroup
{
    GENERATED_USTRUCT_BODY()

public:
    friend class UKGStateManagement;
    friend struct FKGStateGroupReference;
    friend struct FKGStateController;
    friend struct FKGStateControllerSnapshot;

    friend class SKGStateGroupField;
    friend class SKGStateManagementField;
    friend struct FKGStateManagementDependenceChangeSession;

    FKGStateGroup();
    FKGStateGroup(TWeakObjectPtr<UWidget> InWidget);
    FKGStateGroup(TWeakObjectPtr<UWidget> InWidget, const FString& InName, int InCurrent);

public:
    UPROPERTY(EditAnywhere)
    FString Name;

    UPROPERTY(EditAnywhere)
    int Current;

    UPROPERTY(EditAnywhere)
    TArray<FKGState> States;

    TArray<FKGState>::SizeType AddState();
    bool RemoveState(TArray<FKGState>::SizeType Index);

public:
    UWidget* GetWidget() const;

private:
    TWeakObjectPtr<UWidget> Widget;

public:
    void InitializeScriptableStateGroup();
    void UninitializeScriptableStateGroup();
    TSharedPtr<FKGScriptableStateGroupContext> GetScriptableStateGroupContext();
    bool IsScriptableStateGroup();

private:
    TSharedPtr<FKGScriptableStateGroupContext> ScriptableStateGroupContext;
};