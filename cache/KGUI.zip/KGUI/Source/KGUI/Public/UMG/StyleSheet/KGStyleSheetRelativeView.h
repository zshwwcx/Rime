#pragma once

#include "KGStyleSheetPreset.h"

#include "KGStyleSheetRelativeView.generated.h"

USTRUCT(BlueprintType)
struct KGUI_API FKGStyleSheetRelativeView
{
	GENERATED_BODY()

	UPROPERTY(Transient)
	TObjectPtr<UObject> Source;

	UPROPERTY(Transient)
	FKGStylePath RelativePath;

public:
	void Apply(UObject* Object, bool bSetterPreferred = true) const;
};