#pragma once

#include "CoreMinimal.h"

#include "UMG/StyleSheet/KGStyleStatement.h"

#include "KGStyleSheet.generated.h"

class UKGUserWidget;
class UKGStyleSheetPreset;

USTRUCT(BlueprintType)
struct KGUI_API FKGStyleSheet
{
	GENERATED_BODY()

	friend struct FKGStyleSheetRelativeView;

	UPROPERTY(EditAnywhere)
	TArray<FKGStyleStatement> Statements;

public:
	void Apply(UKGStyleSheetPreset* SourceStyleSheetPreset, UObject* Object, bool bSetterPreferred = true) const;
	void Apply(UKGUserWidget* SourceUserWidget, UObject* Object, bool bSetterPreferred = true) const;
	bool HasValueFor(UObject* Object, const UObject* Target, const FProperty* Property = nullptr) const;

private:
	void ApplyInternal(UObject* Source, UObject* Object, const FKGStylePath* RelativePath, bool bSetterPreferred) const;
};