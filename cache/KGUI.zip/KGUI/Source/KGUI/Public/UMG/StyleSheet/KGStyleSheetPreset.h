#pragma once

#include "KGStyleSheet.h"
#include "Templates/SubclassOf.h"

#include "KGStyleSheetPreset.generated.h"

UCLASS(BlueprintType, Blueprintable)
class KGUI_API UKGStyleSheetPreset : public UObject
{
	GENERATED_BODY()

	friend class SKGWidgetStyleSheetTab;

public:
	UFUNCTION(BlueprintCallable)
	void Apply(UObject* Object);

	UFUNCTION(BlueprintCallable)
	TSubclassOf<UObject> GetTargetClass() const { return TargetClass; }

	const FKGStyleSheet& GetStyleSheetData() const { return StyleSheet; }

protected:
	UPROPERTY(EditAnywhere, Category = StyleSheet, meta = (DisplayPriority = 0))
	TSubclassOf<UObject> TargetClass;

	UPROPERTY(EditAnywhere, Category = StyleSheet, meta = (DisplayPriority = 1))
	FKGStyleSheet StyleSheet;
};