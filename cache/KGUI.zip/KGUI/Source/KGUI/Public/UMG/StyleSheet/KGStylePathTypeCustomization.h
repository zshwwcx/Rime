#pragma once

#include "UMG/StyleSheet/KGStylePath.h"

struct KGUI_API FKGStylePathBuiltinTypes
{
	static const FName WidgetTreeChild;
	static const FName WidgetSlot;
	static const FName ListViewEntryClass;
};

class IKGStylePathTypeCustomization : public TSharedFromThis<IKGStylePathTypeCustomization>
{
public:
	virtual ~IKGStylePathTypeCustomization() = default;

	DECLARE_DELEGATE_TwoParams(FOnSuccessorFound, UObject*, const FKGStylePath&);

public:
	FName GetType() const { return Type; }
	virtual UObject* GetSuccessorObject(UObject* CurrentObject, const FKGStylePathName& Name) const = 0;
	virtual void EnumerateSuccessorObjects(UObject* CurrentObject, const FKGStylePath& CurrentPath, const FOnSuccessorFound& OnSuccessorFound) const = 0;
	virtual FString GetDisplayName(const FKGStylePathName& Name) const = 0;

protected:
	FName Type;
};