#pragma once

#include "CoreMinimal.h"
#include "KGStylePath.h"
#include "KGVariantValue.h"

#include "KGStyleStatement.generated.h"

USTRUCT()
struct KGUI_API FKGStyleStatement
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere)
	FKGStylePath Path;

	UPROPERTY(EditAnywhere)
	TArray<FKGVariantValue> Values;
};