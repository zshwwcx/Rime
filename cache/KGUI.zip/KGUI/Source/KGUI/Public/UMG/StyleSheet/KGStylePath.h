#pragma once

#include "CoreMinimal.h"
#include "KGStylePathName.h"

#include "KGStylePath.generated.h"

struct FKGStylePathGetObjectContext;

USTRUCT()
struct KGUI_API FKGStylePath
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere)
	TArray<FKGStylePathName> Names;

	FKGStylePath() = default;

	FKGStylePath(const FKGStylePath& Other)
		: Names(Other.Names)
	{
	}

	FKGStylePath(FKGStylePath&& Other)
		: Names(MoveTemp(Other.Names))
	{
	}

	FKGStylePath& operator=(const FKGStylePath& Other)
	{
		Names = Other.Names;
		return *this;
	}

	FKGStylePath& operator=(FKGStylePath&& Other)
	{
		Names = MoveTemp(Other.Names);
		return *this;
	}

	FKGStylePath ToSubPath(int FromIndex, int ToIndex)
	{
		FKGStylePath SubPath;
		for (int I = FromIndex; I < ToIndex; I++)
		{
			if (!Names.IsValidIndex(I))
			{
				break;
			}
			// TODO: 子路径存储其实可以调整成仅仅存个序号，使用时再Resolve，不过需要确保序号只是临时的结果，长期持有可能存在失效的风险
			SubPath.Names.Add(Names[I]);
		}
		return SubPath;
	}

	bool IsEmpty() const { return Names.IsEmpty(); }
	void Reset();
	UObject* GetObject(UObject* Owner, FKGStylePathGetObjectContext& Context) const;
	UObject* GetObject(UObject* Owner) const;
	FKGStylePath CopyWithNameFollowing(const FKGStylePathName& Name) const;
	bool HasParent() const { return !Names.IsEmpty(); }
	bool TryGetParentPath(FKGStylePath& ParentPath) const;

	bool IsChildOf(const FKGStylePath& MaybeParentPath) const;
	FKGStylePath GetRelativePathFrom(const FKGStylePath& ParentPath) const;

	const FName& GetType() const;
	const FName& GetParentType() const;
	const FName& GetArgument() const;

	static TArray<TSharedPtr<FKGStylePath>> GetAvailablePaths(UObject* Owner);
	static TSharedPtr<FKGStylePath> FindPath(UObject* Owner, UObject* Object);
	static TArray<TSharedPtr<FKGStylePath>> GetChildPaths(UObject* Owner, const FKGStylePath& ParentPath);

	friend bool operator==(const FKGStylePath& A, const FKGStylePath& B)
	{
		return A.Names == B.Names;
	}

	friend uint32 GetTypeHash(const FKGStylePath& StylePath)
	{
		uint32 Hash = 0;
		for (auto& Name : StylePath.Names)
		{
			Hash ^= GetTypeHash(Name);
		}
		return Hash;
	}

private:
	static void GetAvailablePathsInternal(const FKGStylePath& CurrentPath, UObject* CurrentObject, TArray<TSharedPtr<FKGStylePath>>& OutPaths, int Depth = -1, UObject* SpecificObject = nullptr);
};

struct FKGStylePathGetObjectContext
{
	const FKGStylePath* RelativePath = nullptr;

	bool bRecordNearestClassPath = false;
	FKGStylePath OutNearestClassPath;

	bool bDeferred = false;
	FKGStylePath OutDeferredPath;

	void Reset()
	{
		RelativePath = nullptr;
		bRecordNearestClassPath = false;
		OutNearestClassPath.Reset();
		bDeferred = false;
		OutDeferredPath.Reset();
	}
};