#pragma once

#include "CoreMinimal.h"

#include "KGVariantValue.generated.h"

// ## 用来存储变体类型的结构体
// 得益于Unreal提供的反射机制，可以比较方便的对不同类型的属性进行一致性的处理，但是多种数据的存储变得比较困难。
// FKGVariantValue作为变体类型，可以储存任何数据类型。

// TODO
// 该实现和FKGSerializableVariant有异曲同工之妙，需要整合。
// 在状态组中使用的FKGSerializableVariant做了一些旧版本的兼容所以没有直接在这里使用。

USTRUCT(meta = (ShallowCopy))
struct KGUI_API FKGVariantValue
{
	GENERATED_BODY()

	friend class FKGVariantValuePropertyCustomization;

public:
	FKGVariantValue();
	FKGVariantValue(const FKGVariantValue& Other);
	~FKGVariantValue();
	FKGVariantValue& operator=(const FKGVariantValue& Other);

	bool operator==(const FKGVariantValue& Other) const
	{
		if (this->PropertyPath != Other.PropertyPath)
		{
			return false;
		}
		if (this->Property != Other.Property)
		{
			return false;
		}
		if (this->Property == nullptr)
		{
			return true;
		}
		if (this->Data == nullptr && Other.Data == nullptr)
		{
			return true;
		}
		else if (this->Data == nullptr || Other.Data == nullptr)
		{
			return false;
		}
		return this->Property->Identical_InContainer(this->Data, Other.Data);
	}

	bool operator!=(const FKGVariantValue& Other) const
	{
		return !this->operator==(Other);
	}

	bool IsValid() const { return Property != nullptr; }
	bool Get(const UObject* Object);
	bool Set(UObject* Object, bool bSetterPreferred = true) const;

	void SetPropertyPath(const TFieldPath<FProperty>& PropertyPath);
	const TFieldPath<FProperty>& GetPropertyPath() const { return PropertyPath; }

private:
	void Construct();
	void Destruct();

public:
	bool Assign(void const* Value);

private:
	void Normalize();

public:
	bool Serialize(FArchive& Ar);
	bool ExportTextItem(FString& ValueStr, FKGVariantValue const& DefaultValue, UObject* Parent, int32 PortFlags, UObject* ExportRootScope) const;
	bool ImportTextItem(const TCHAR*& Buffer, int32 PortFlags, UObject* Parent, FOutputDevice* ErrorText);

private:
	TFieldPath<FProperty> PropertyPath;
	FProperty* Property = nullptr;
	void* Data = nullptr;
};

template<>
struct TStructOpsTypeTraits<FKGVariantValue> : public TStructOpsTypeTraitsBase2<FKGVariantValue>
{
	enum
	{
		WithSerializer = true,
		WithExportTextItem = true,
		WithImportTextItem = true,
		WithCopy = true,
		WithIdenticalViaEquality = true,
	};
};