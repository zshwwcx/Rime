#pragma once

#include "KGStylePathName.h"
#include "KGStylePathTypeCustomization.h"

class KGUI_API FKGStylePathTypeCustomizationRegistry
{
public:
	FKGStylePathTypeCustomizationRegistry();
	void RegisterStylePathTypeCustomization(const TSharedRef<IKGStylePathTypeCustomization>& StylePathTypeCustomization);
	const IKGStylePathTypeCustomization* GetStylePathTypeCustomization(FName Type) const;
	FString GetStylePathNameDisplayName(const FKGStylePathName& Name) const;
	const TMap<FName, TSharedPtr<IKGStylePathTypeCustomization>>& GetStylePathTypeCustomizations() const { return StylePathTypeCustomizations; }
	FText GetStylePathDisplayNameText(const FKGStylePath& Path) const;
	
private:
	TMap<FName, TSharedPtr<IKGStylePathTypeCustomization>> StylePathTypeCustomizations;
};
