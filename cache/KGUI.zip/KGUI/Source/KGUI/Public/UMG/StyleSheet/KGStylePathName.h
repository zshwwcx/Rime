#pragma once

#include "CoreMinimal.h"

#include "KGStylePathName.generated.h"

USTRUCT()
struct KGUI_API FKGStylePathName
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere)
	FName Type;

	UPROPERTY(EditAnywhere)
	FName Argument;

	static FKGStylePathName Create(FName InType, FName InArgument);

	friend bool operator==(const FKGStylePathName& A, const FKGStylePathName& B)
	{
		return A.Type == B.Type && A.Argument == B.Argument;
	}

	friend uint32 GetTypeHash(const FKGStylePathName& StylePathName)
	{
		return GetTypeHash(StylePathName.Type) ^ GetTypeHash(StylePathName.Argument);
	}
};