// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Slate/SMeshWidget.h"
#include "Slate/SlateMeshBufferCollection.h"

struct FMinimalViewInfo;
/**
 * 
 */
class SKGMeshWidget : public SMeshWidget
{
public:
	SLATE_BEGIN_ARGS(SKGMeshWidget) { }
	SLATE_END_ARGS()

	void Construct(const FArguments& Args);
	
	void SetMesh(UStaticMesh* DataSource);
	void SetMaterial(UMaterialInterface* Material);
	void SetInstanceData(FTransform& Transform, FLinearColor& Tint);
	void SetViewProjectionMatrix(FMinimalViewInfo& ViewInfo);
	
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

protected:
	int32 MeshId = -1;

	FMatrix ViewProjectionMatrix;
	FMatrix TransformMatrix;

	FSlateMeshBufferHandle MeshVertexBufferHandle;
	FSlateMeshBufferHandle MeshIndexBufferHandle;
};