#pragma once

#include "Core/Common.h"
#include "Slate/SObjectTableRow.h"
#include "KGUISettings.h"
#include "UMG/Blueprint/KGShapedListView.h"
#include "Components/ListViewBase.h"

template <typename ItemType>
class SKGObjectTableRow : public SObjectTableRow<ItemType>
{
	using Super = SObjectTableRow<ItemType>;

public:
	void Construct(const typename Super::FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTableView, UUserWidget& InWidgetObject, UListViewBase* InOwnerListView = nullptr)
	{
		Super::Construct(InArgs, InOwnerTableView, InWidgetObject, InOwnerListView);
		if (auto ListView = this->GetOwningListView())
		{
			if (auto ListViewShapedInterface = Cast<IKGShapedListView>(ListView))
			{
				bOwnedByShapedListView = ListViewShapedInterface->GetShapeStyle() != nullptr;
			}
#if WITH_EDITOR
			bDesignTime = ListView->IsDesignTime();
#endif
		}
	}

	void SetIsFocusable(bool InbIsFocusable)
	{
		bIsFocusable = InbIsFocusable;
	}

protected:
	virtual bool SupportsKeyboardFocus() const override
	{
#if WITH_EDITOR
		const bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#else
		const static bool bDisableFocusableGlobally = GetDefault<UKGUISettings>()->bDisableFocusableGlobally;
#endif
		if (bDisableFocusableGlobally)
		{
			return false;
		}

		return bIsFocusable;
	}

	bool bIsFocusable = true;

protected:
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override
	{
		if (bTickOncePending)
		{
			if (this->WidgetObject)
			{
				this->WidgetObject->UpdateCanTick();
			}
			if (RequestTickOnceTimerHandle.IsValid())
			{
				this->UnRegisterActiveTimer(RequestTickOnceTimerHandle.ToSharedRef());
				RequestTickOnceTimerHandle = nullptr;
			}
			bTickOncePending = false;
		}
		else
		{
			ensure(!RequestTickOnceTimerHandle.IsValid());
		}

		Super::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
#if WITH_EDITOR
		if (bOwnedByShapedListView && (bShapeDirty || bDesignTime))
#else
		if (bOwnedByShapedListView && bShapeDirty)
#endif
		{
			if (auto ListViewShapedInterface = Cast<IKGShapedListView>(this->GetOwningListView()))
			{
				ListViewShapedInterface->RaiseOnModifyEntry(AllottedGeometry, StaticCastSharedRef<SObjectTableRow<ItemType>>(this->AsShared()));
			}
			bShapeDirty = false;
		}
	}

	bool bOwnedByShapedListView = false;
	bool bShapeDirty = false;
#if WITH_EDITOR
	bool bDesignTime = false;
#endif

public:
	void MarkShapeAsDirty()
	{
		if (bOwnedByShapedListView)
		{
			bShapeDirty = true;
			RequestTickOnce();
		}
	}

	void RequestTickOnce()
	{
		if (bTickOncePending)
		{
			return;
		}
		// 本来在`UListViewBase::HandleGenerateRow`里会调用`CachedWidget->SetCanTick(true);`，不过这一步操作似乎并没什么意义，反而有可能让其中的一些SWidget::Tick空跑。
		// 而且当UserWidget::UpdateCanTick之后，就会把一开始的SetCanTick(true)的状态覆盖掉。例如有动画的列表Entry就可能会把CanTick的结果变为false。最终使得部分Entry并不会
		// 执行Tick函数。
		// 如果希望只额外地Tick一次，就可以调用当前的RequestTickOnce函数。在Tick之后会调用UpdateCanTick重新恢复到正确CanTick状态。当然风险是如果在调用RequestTickOnce之后，
		// 尚未调用Tick之前CanTick又被覆盖掉。使用RegisterActiveTimer的方式能尽可能的减少这种情况的发生（即使发生也只能是该SWidget的其他ActiveTimer造成的，调用方应该确保这部
		// 分的逻辑清晰可靠）。
		bTickOncePending = true;
		this->SetCanTick(true);
		RequestTickOnceTimerHandle = this->RegisterActiveTimer(0.f, FWidgetActiveTimerDelegate::CreateSP(this, &SKGObjectTableRow::HandleOnRequestTickOnce));
	}

protected:
	EActiveTimerReturnType HandleOnRequestTickOnce(double InCurrentTime, float InDeltaTime)
	{
		this->SetCanTick(true);
		return EActiveTimerReturnType::Stop;
	}

	bool bTickOncePending = false;

	TSharedPtr<FActiveTimerHandle> RequestTickOnceTimerHandle = nullptr;

public:
	virtual FString ToString() const override
	{
		auto WidgetObject = this->GetWidgetObject();
		auto WidgetClass = WidgetObject ? WidgetObject->GetClass() : nullptr;
		TStringBuilder<256> StringBuilder;
		StringBuilder
			<< *this->GetTypeAsString()
			<< " ["
				<< *this->GetReadableLocation()
				<< ", "
				<< (WidgetObject == nullptr ? TEXT("nullptr") : *WidgetObject->GetName())
				<< "("
				<< (WidgetClass == nullptr ? TEXT("nullptr") : *WidgetClass->GetName())
				<< ")"
			<< "]";
		return FString(StringBuilder);
	}
};
