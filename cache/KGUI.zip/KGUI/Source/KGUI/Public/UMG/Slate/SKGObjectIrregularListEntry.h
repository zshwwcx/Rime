#pragma once

#include "CoreMinimal.h"
#include "Slate/SObjectWidget.h"

#include "Slate/Views/IKGIrregularListEntry.h"

class UKGIrregularListView;
class UUserWidget;
template <typename ItemType> class SKGIrregularListView;

class IKGObjectIrregularListEntry : public IKGIrregularListEntry
{
public:
	virtual UKGIrregularListView* GetOwningListView() const = 0;
	virtual UUserWidget* GetUserWidget() const = 0;

	static TSharedPtr<const IKGObjectIrregularListEntry> ObjectEntryFromUserWidget(const UUserWidget* RowUserWidget)
	{
		TWeakPtr<const IKGObjectIrregularListEntry>* ObjectEntry = ObjectEntriesByUserWidget.Find(RowUserWidget);
		if (ObjectEntry && ObjectEntry->IsValid())
		{
			return ObjectEntry->Pin();
		}
		return nullptr;
	}

protected:
	static TMap<TWeakObjectPtr<const UUserWidget>, TWeakPtr<const IKGObjectIrregularListEntry>> ObjectEntriesByUserWidget;
};

class SKGObjectIrregularListEntry : public SObjectWidget, public IKGObjectIrregularListEntry
{
public:
	SLATE_BEGIN_ARGS(SKGObjectIrregularListEntry)
		{
		}

		SLATE_DEFAULT_SLOT(FArguments, Content)

	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, const TSharedRef<SKGIrregularListView<UObject*>>& InOwnerSlateListView, UUserWidget& InWidgetObject, UKGIrregularListView* InOwnerListView = nullptr);

	virtual ~SKGObjectIrregularListEntry();

	virtual void InitializeRow() override final;

	virtual void ResetRow() override final;

	virtual void SetIndexInList(int32 InIndexInList) override;

	virtual int32 GetIndexInList() const override;

	virtual void UpdateItemSelection(bool bIsSelected, ESelectInfo::Type SelectInfo) override;

	virtual bool IsItemSelected() const override;

	virtual TSharedRef<SWidget> AsWidget() override;

	virtual UKGIrregularListView* GetOwningListView() const;

	virtual UUserWidget* GetUserWidget() const override;

	virtual void SetIrregularPosition(FVector2D InIrregularPosition) override;

protected:
	const TObjectPtr<UObject>* GetItemForThis(const TSharedRef<SKGIrregularListView<UObject*>>& OwnerListView) const;

	int32 IndexInList = INDEX_NONE;
	TWeakObjectPtr<UKGIrregularListView> OwnerListView;
	FVector2D IrregularPosition;
	TWeakPtr<SKGIrregularListView<UObject*>> OwnerSlateListViewWeakPtr;  // cppcheck:ignore 野指针作为模板类型参数
};