// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SConstraintCanvas.h"
#include "Layout/LayoutUtils.h"
#include "Framework/Application/SlateApplication.h"

/** 带SafeZone Padding属性的Canvas.
 * 
 */
class KGUI_API SKGSafeZoneConstraintCanvas : public SConstraintCanvas
{
public:
	SLATE_BEGIN_ARGS(SKGSafeZoneConstraintCanvas)
		// : _bEnableSafeZone(false)
		: _Padding( 0.0f )
		, _IsTitleSafe( false )
		, _SafeAreaScale(1,1,1,1)
		, _PadLeft( true )
		, _PadRight( true )
		, _PadTop( true )
		, _PadBottom( true )
#if WITH_EDITOR
		, _OverrideScreenSize()
		, _OverrideDpiScale()
#endif
		{
		}

		// SLATE_ARGUMENT(bool, bEnableSafeZone)

		/** Padding between the SBox and the content that it presents. Padding affects desired size. */
		SLATE_ATTRIBUTE( FMargin, Padding )
		
		/** True if the zone is TitleSafe, otherwise it's ActionSafe */
		SLATE_ARGUMENT( bool, IsTitleSafe )

		/**
		 * The scalar to apply to each side we want to have safe padding for.  This is a handy way 
		 * to ignore the padding along certain areas by setting it to 0, if you only care about asymmetric safe areas.
		 */
		SLATE_ARGUMENT(FMargin, SafeAreaScale)

		/** If this safe zone should pad for the left side of the screen's safe zone */
		SLATE_ARGUMENT( bool, PadLeft )

		/** If this safe zone should pad for the right side of the screen's safe zone */
		SLATE_ARGUMENT( bool, PadRight )

		/** If this safe zone should pad for the top of the screen's safe zone */
		SLATE_ARGUMENT( bool, PadTop )
		
		/** If this safe zone should pad for the bottom of the screen's safe zone */
		SLATE_ARGUMENT( bool, PadBottom )

#if WITH_EDITOR
		/** Force a particular screen size to be used instead of the reported device size. */
		SLATE_ARGUMENT( TOptional<FVector2D>, OverrideScreenSize )

		/** Force a particular screen size to be used instead of the reported device size. */
		SLATE_ARGUMENT(TOptional<float>, OverrideDpiScale )
#endif
		

	SLATE_END_ARGS()

public:
	SKGSafeZoneConstraintCanvas();
	virtual ~SKGSafeZoneConstraintCanvas();
	
	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs);

	void SetTitleSafe( bool bIsTitleSafe );
	void SetSafeAreaScale(FMargin InSafeAreaScale);

	void SetSidesToPad( bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom );

	FMargin GetSafeMargin(float InLayoutScale) const;

#if WITH_EDITOR
	void SetOverrideScreenInformation(TOptional<FVector2D> InScreenSize, TOptional<float> InOverrideDpiScale);
	void DebugSafeAreaUpdated(const FMargin& NewSafeZone, bool bShouldRecacheMetrics);
#endif

	virtual void OnArrangeChildren( const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren ) const override;
	virtual FVector2D ComputeDesiredSize(float LayoutScale) const override;

	static void SetGlobalSafeZoneScale(TOptional<float> InScale);
	static TOptional<float> GetGlobalSafeZoneScale();


private:

	void UpdateSafeMargin();
	FMargin ComputeScaledSafeMargin(float Scale) const;
	
	/** Cached values from the args */
	// bool bEnableSafeZone;
	TSlateAttribute<FMargin, EInvalidateWidgetReason::Layout> Padding;
	FMargin SafeAreaScale;
	bool bIsTitleSafe;
	bool bPadLeft;
	bool bPadRight;
	bool bPadTop;
	bool bPadBottom;

#if WITH_EDITOR
	TOptional<FVector2D> OverrideScreenSize;
	TOptional<float> OverrideDpiScale;
#endif
	
	/** Does the SafeMargin need an update? */
	mutable bool bSafeMarginNeedsUpdate;

	/** Screen space margin */
	mutable FMargin SafeMargin;

	FDelegateHandle OnSafeFrameChangedHandle;


	/** An array matching the length and order of ArrangedChildren. True means the child must be placed in a layer in front of all previous children. */
	typedef TArray<bool, TInlineAllocator<16>> FArrangedChildLayers;

	/** Like ArrangeChildren but also generates an array of layering information (see FArrangedChildLayers). */
	void ArrangeLayeredChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren, FArrangedChildLayers& ArrangedChildLayers) const;
};
