#include "SKGMeshWidget.h"
#include "SlateMaterialBrush.h"
#include "Engine/StaticMesh.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Slate/SlateDrawBufferCollection.h"
#include "Slate/SlateVectorArtInstanceData.h"

void SKGMeshWidget::Construct(const FArguments& Args)
{
	MeshId = -1;
}

void SKGMeshWidget::SetMesh(UStaticMesh* DataSource)
{
	RenderData.Empty();
	if (DataSource == nullptr)
	{
		return;
	}
	UMaterialInterface* Material = DataSource->GetMaterial(0);
#if !UE_BUILD_SHIPPING
	if (!Material)
	{
#if WITH_EDITOR || PLATFORM_WINDOWS
		UE_LOG(LogSlate, Error, TEXT("SKGMeshWidget::SetMesh NULL Material(0), Mesh Name(%s)"), *DataSource->GetName());
#else
		UE_LOG(LogSlate, Fatal, TEXT("SKGMeshWidget::SetMesh NULL Material(0), Mesh Name(%s)"), *DataSource->GetName());
#endif
	}
#endif
	MeshVertexBufferHandle = FSlateMeshBufferCollection::Get().GetVertexBuffer(DataSource, true);
	MeshIndexBufferHandle =  FSlateMeshBufferCollection::Get().GetIndexBuffer(DataSource);

	MeshId = AddMeshWithInstancing(Material, MeshVertexBufferHandle.GetVertexBuffer(), MeshIndexBufferHandle.GetIndexBuffer());
}

static const FVector2D DontCare(FVector2D(64, 64));
void SKGMeshWidget::SetMaterial(UMaterialInterface* Material)
{
	if (MeshId < 0 || RenderData.Num() <= 0)
	{
		return;
	}
	checkf(MeshId < RenderData.Num() && MeshId >= 0, TEXT("MeshId=%d is invalid, Maximun=%d"), MeshId, RenderData.Num());
	FRenderData& CurRenderData = RenderData[MeshId];
	if (CurRenderData.Brush == nullptr)
	{
		if  (Material != nullptr)
		{
			CurRenderData.Brush = MakeShared<FSlateMaterialBrush>(*Material, DontCare);
			CurRenderData.RenderingResourceHandle = FSlateApplication::Get().GetRenderer()->GetResourceHandle(*CurRenderData.Brush);
		}
	}
	else
	{
		CurRenderData.Brush->SetResourceObject(Material);
		CurRenderData.RenderingResourceHandle = FSlateApplication::Get().GetRenderer()->GetResourceHandle(*CurRenderData.Brush);
	}
}

void SKGMeshWidget::SetInstanceData(FTransform& Transform, FLinearColor& Tint)
{
	if (MeshId < 0 || RenderData.Num() <= 0)
	{
		return;
	}
	if(!Transform.IsValid())
	{
		UE_LOG(LogTemp, Warning, TEXT("SKGMeshWidget, Transform Is Invalid!"));
		return;
	}
	
	TransformMatrix = Transform.ToMatrixWithScale();
	FVector3f Position = FVector3f(Transform.GetLocation());
	FVector3f Scale = FVector3f(Transform.GetScale3D());
	FQuat4f Rotation = FQuat4f(Transform.GetRotation());
	
	using namespace UE::SlateMeshInstanceDataUtils;
	FSlateInstanceBufferData InstanceData;
	
	FVector4f Data[2]; // cppcheck:ignore
	PackPosition3D(Data, Position);
	PackRotation3D(Data, Rotation);
	PackColor(Data, Tint.ToFColor(true));
	PackScale3D(Data, Scale);
	PackSubImage(Data[0], 0, 1, 1);
	InstanceData.Append(Data, 2);
	UpdatePerInstanceBuffer(MeshId, InstanceData);
	Invalidate(EInvalidateWidgetReason::Paint);
}

void SKGMeshWidget::SetViewProjectionMatrix(FMinimalViewInfo& ViewInfo)
{
	FMatrix ViewMatrix, ProjectionMatrix;
	UGameplayStatics::GetViewProjectionMatrix(ViewInfo, ViewMatrix, ProjectionMatrix, ViewProjectionMatrix);
}

int32 SKGMeshWidget::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect,
                             FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	const FVector2D Location2D = AllottedGeometry.GetAbsolutePositionAtCoordinates(FVector2D(0.5f, 0.5f));
	const FMatrix2x2 RenderTransformMatrix = AllottedGeometry.GetAccumulatedRenderTransform().GetMatrix();
	// 模型在区间内的放大缩小
	const FVector2D CustomScale = AllottedGeometry.Size / 2;
	const FMatrix2x2 CustomMatrix = ::Concatenate(RenderTransformMatrix, FMatrix2x2(TScale2<float>(CustomScale.X, CustomScale.Y)));

	FMatrix DynamicTransformMatrix = TransformMatrix * ViewProjectionMatrix * FMatrix44d(FTransform2f(CustomMatrix, FVector2f(Location2D.X, Location2D.Y)).To3DMatrix());
	FMatrix44f Matrix(DynamicTransformMatrix);
	// const_cast<SKGMeshWidget*>(this)->SetDynamicTransform(Matrix);
	
	if (MeshId >= 0 && RenderData.Num() > 0 && RenderData[MeshId].Brush)
	{
		//防止编辑UIMesh时的同时修改引用的材质导致RenderingResource失效
		const_cast<SKGMeshWidget*>(this)->RenderData[MeshId].RenderingResourceHandle = RenderData[MeshId].Brush->GetRenderingResource();
		if (auto* Material = Cast<UMaterialInstanceDynamic>(RenderData[MeshId].Brush->GetResourceObject()))
		{
			Material->SetVectorParameterValue(TEXT("TransformMatRow1"), FVector4(Matrix.M[0][0], Matrix.M[0][1], Matrix.M[0][2], Matrix.M[0][3]));
			Material->SetVectorParameterValue(TEXT("TransformMatRow2"), FVector4(Matrix.M[1][0], Matrix.M[1][1], Matrix.M[1][2], Matrix.M[1][3]));
			Material->SetVectorParameterValue(TEXT("TransformMatRow3"), FVector4(Matrix.M[2][0], Matrix.M[2][1], Matrix.M[2][2], Matrix.M[2][3]));
			Material->SetVectorParameterValue(TEXT("TransformMatRow4"), FVector4(Matrix.M[3][0], Matrix.M[3][1], Matrix.M[3][2], Matrix.M[3][3]));
		}
	}
	
	return SMeshWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
}