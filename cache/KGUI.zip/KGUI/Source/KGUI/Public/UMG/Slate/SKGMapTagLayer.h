// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/Layout/SConstraintCanvas.h"
#include "SKGMapTagLayer.generated.h"

USTRUCT(BlueprintType)
struct FKGMapSimpleTagIcon
{
    GENERATED_BODY()

    UPROPERTY()
    FString TaskID;

    UPROPERTY()
    int32 SimpleTagIconHandle  = INDEX_NONE;
    
    UPROPERTY()
    FString IconPath;
    
    UPROPERTY()
    FSlateBrush Brush;

    UPROPERTY()
    FVector2D Size;

    UPROPERTY()
    FVector2D Offset;

    UPROPERTY()
    float RotateAngle; // 旋转角度，[0 - 360]

    UPROPERTY()
    FLinearColor TintColor;

    UPROPERTY()
    int32 ZOrder;
	
	UPROPERTY(Transient)
	class UMaterialInstanceDynamic* DynamicInstance = nullptr;
	
	UPROPERTY()
	bool bVisible = false;
};

/**
 * SKGMapTagLayer
 */
class KGUI_API SKGMapTagLayer : public SPanel
{
    friend struct FSortSlotsByZOrder;
public:
	/**
	 * ConstraintCanvas slots allow child widgets to be positioned and sized
	 */
	class KGUI_API FSlot : public TSlotBase<FSlot>
	{
	public:
		/** Default values for a slot. */
		FSlot()
			: OffsetAttr(FMargin(0, 0, 1, 1))
			, AnchorsAttr(FAnchors(0.0f, 0.0f))
			, AlignmentAttr(FVector2D(0.5f, 0.5f))
			, AutoSizeAttr(false)
			, ZOrder(0)
		{ }

		SLATE_SLOT_BEGIN_ARGS(FSlot, TSlotBase<FSlot>)
			SLATE_ATTRIBUTE(FMargin, Offset)
			SLATE_ATTRIBUTE(FAnchors, Anchors)
			SLATE_ATTRIBUTE(FVector2D, Alignment)
			SLATE_ATTRIBUTE(bool, AutoSize)
			SLATE_ARGUMENT(TOptional<float>, ZOrder)
		SLATE_SLOT_END_ARGS()

		void Construct(const FChildren& SlotOwner, FSlotArguments&& InArgs);

		void SetOffset( const TAttribute<FMargin>& InOffset )
		{
			SetAttribute(OffsetAttr, InOffset, EInvalidateWidgetReason::Paint);
		}

		FMargin GetOffset() const
		{
			return OffsetAttr.Get();
		}

		void SetAnchors( const TAttribute<FAnchors>& InAnchors )
		{
			// if (AnchorsAttr.IsSet() && AnchorsAttr.Get() != InAnchors.Get())
			// {
			// 	auto ContentWidget = GetWidget();
			// 	auto Reflection = ContentWidget->GetMetaData<FReflectionMetaData>();
			// 	if (Reflection.IsValid() && Reflection->Name.ToString().Contains("[MainPlayer]"))
			// 	{
			// 		UE_LOG(LogInit, Log, TEXT("[SetAnchors] MainPlayer %.3f,%.3f,%.3f,%.3f -> %.3f,%.3f,%.3f,%.3f"), AnchorsAttr.Get().Minimum.X, AnchorsAttr.Get().Minimum.Y, AnchorsAttr.Get().Maximum.X, AnchorsAttr.Get().Maximum.Y,
			// 			InAnchors.Get().Minimum.X, InAnchors.Get().Minimum.Y, InAnchors.Get().Maximum.X, InAnchors.Get().Maximum.Y);
			// 	}
			// }
			SetAttribute(AnchorsAttr, InAnchors, EInvalidateWidgetReason::Paint);
		}

		FAnchors GetAnchors() const
		{
			return AnchorsAttr.Get();
		}

		void SetAlignment(const TAttribute<FVector2D>& InAlignment)
		{
			SetAttribute(AlignmentAttr, InAlignment, EInvalidateWidgetReason::Paint);
		}

		FVector2D GetAlignment() const
		{
			return AlignmentAttr.Get();
		}

		void SetAutoSize(const TAttribute<bool>& InAutoSize)
		{
			SetAttribute(AutoSizeAttr, InAutoSize, EInvalidateWidgetReason::Layout);
		}

		bool GetAutoSize() const
		{
			return AutoSizeAttr.Get();
		}

		void SetZOrder(float InZOrder);

		float GetZOrder() const
		{
			return ZOrder;
		}

	private:
		/** Offset */
		TAttribute<FMargin> OffsetAttr;
		/** Anchors */
		TAttribute<FAnchors> AnchorsAttr;
		/** Size */
		TAttribute<FVector2D> AlignmentAttr;
		/** Auto-Size */
		TAttribute<bool> AutoSizeAttr;
	private:
		/** Z-Order */
		float ZOrder;
	};


	SLATE_BEGIN_ARGS( SKGMapTagLayer )
		{
			_Visibility = EVisibility::SelfHitTestInvisible;
			_bLocalExplicitCanvasChildZOrder = false;
		}

		SLATE_SLOT_ARGUMENT( FSlot, Slots)
		SLATE_ATTRIBUTE(bool, bLocalExplicitCanvasChildZOrder)
	SLATE_END_ARGS()

	SKGMapTagLayer();
	virtual ~SKGMapTagLayer();

	/**
	 * Construct this widget
	 *
	 * @param	InArgs	The declaration data for this widget
	 */
	void Construct( const FArguments& InArgs );

	static FSlot::FSlotArguments Slot();

	using FScopedWidgetSlotArguments = TPanelChildren<FSlot>::FScopedWidgetSlotArguments;
	/**
	 * Adds a content slot.
	 *
	 * @return The added slot.
	 */
	FScopedWidgetSlotArguments AddSlot();

	/**
	 * Removes a particular content slot.
	 *
	 * @param SlotWidget The widget in the slot to remove.
	 */
	int32 RemoveSlot( const TSharedRef<SWidget>& SlotWidget );

	/**
	 * Removes all slots from the panel.
	 */
	void ClearChildren();
	void SetLocalExplicitCanvasChildZOrder(bool InLocalExplicitCanvasChildZOrder);

    void AddTagIcon(const FKGMapSimpleTagIcon& InTagIcon);
    void RemoveTagIcon(int32 InTagIconHandle);
    void ClearTagIcons();
    void MarkTagIconsDirty();
public:

	// Begin SWidget overrides
	virtual void OnArrangeChildren( const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren ) const override;
	virtual int32 OnPaint( const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled ) const override;
	virtual FChildren* GetChildren() override;
	// End SWidget overrides

protected:
	// Begin SWidget overrides.
	virtual FVector2D ComputeDesiredSize(float) const override;
	// End SWidget overrides.
	
	/** The ConstraintCanvas widget's children. */
	TPanelChildren< FSlot > Children;
	
	bool bLocalExplicitCanvasChildZOrder = false;
    bool bNeedRepaint = false;
private:

	/** An array matching the length and order of ArrangedChildren. True means the child must be placed in a layer in front of all previous children. */
	typedef TArray<bool, TInlineAllocator<16>> FArrangedChildLayers;

	/** Like ArrangeChildren but also generates an array of layering information (see FArrangedChildLayers). */
	void ArrangeLayeredChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren, FArrangedChildLayers& ArrangedChildLayers) const;

	void DirtyZOrder() { bZOrderDirty = true;}
    int32 DrawTagIcons(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const;

	bool bZOrderDirty = false;

    struct FChildZOrder
    {
        int32 ChildIndex;
        float ZOrder;
    };

    TArray< FChildZOrder, TInlineAllocator<64>> SlotOrder;
    TMap<int32, FKGMapSimpleTagIcon> TagIcons;
    TArray<int32> TagIconOrder;
};
