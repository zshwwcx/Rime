#pragma once
#include "KGBaseTween.h"
#include "KGAngleTween.generated.h"

UCLASS(DisplayName = AngleTween, meta = (ComponentCategory = "Tween", DisallowMultipleComponent))
class KGUI_API UKGAngleTween : public UKGBaseTween
{
	GENERATED_BODY()
	
public:
	UFUNCTION()
	void SetData(float From, float To);

private:
	virtual void TweenUpdate(float InCurTime) override;

private:
	UPROPERTY(EditAnywhere, DisplayName="初始角度", Category="参数")
	float FromAngle;
	UPROPERTY(EditAnywhere, DisplayName="目标角度", Category="参数")
	float ToAngle;

	UPROPERTY(VisibleAnywhere, DisplayName="当前插值角度", Category="参数")
	float CurAngle;
};
