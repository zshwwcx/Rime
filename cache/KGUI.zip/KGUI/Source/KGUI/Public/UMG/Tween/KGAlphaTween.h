#pragma once
#include "KGBaseTween.h"
#include "KGAlphaTween.generated.h"

UCLASS(DisplayName = AlphaTween, meta = (ComponentCategory = "Tween", DisallowMultipleComponent))
class KGUI_API UKGAlphaTween : public UKGBaseTween
{
	GENERATED_BODY()
	
public:
	UFUNCTION()
	void SetData(float From, float To);
private:
	virtual void TweenUpdate(float InCurTime) override;

private:
	UPROPERTY(EditAnywhere, DisplayName="初始Alpha", Category="参数", meta=(ClampMin = 0, ClampMax = 1))
	float FromAlpha;
	UPROPERTY(EditAnywhere, DisplayName="目标Alpha", Category="参数", meta=(ClampMin = 0, ClampMax = 1))
	float ToAlpha;

	UPROPERTY(VisibleAnywhere, DisplayName="当前插值Alpha", Category="参数")
	float CurAlpha;
};
