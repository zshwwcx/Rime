#pragma once
#include "Components/Widget.h"

UENUM(BlueprintType)
enum class EaseType : uint8
{
	Linear,
	InSine,
	OutSine,
	InOutSine,
	InQuad,
	OutQuad,
	InOutQuad,
	InCubic,
	OutCubic,
	InOutCubic,
	InQuart,
	OutQuart,
	InOutQuart,
	InQuint,
	OutQuint,
	InOutQuint,
	InExpo,
	OutExpo,
	InOutExpo,
	InCirc,
	OutCirc,
	InOutCirc,
};

class KGUI_API UKGEaseLerp
{
public:
	static float Lerp(EaseType Type, float CurTime, float DurationTime);

	static constexpr float PiOver2 = PI * 0.5f;
	static constexpr float TwoPi = PI * 2;
};
