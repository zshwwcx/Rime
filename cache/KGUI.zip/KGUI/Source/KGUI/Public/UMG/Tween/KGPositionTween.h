#pragma once
#include "UMG/Tween/KGBaseTween.h"
#include "KGPositionTween.generated.h"

UCLASS(DisplayName = PositionTween, meta = (ComponentCategory = "Tween", DisallowMultipleComponent))
class KGUI_API UKGPositionTween : public UKGBaseTween
{
	GENERATED_BODY()
	
public:
	UFUNCTION()
	void SetData(FVector2D From, FVector2D To);

private:
	virtual void TweenUpdate(float InCurTime) override;

private:
	UPROPERTY(EditAnywhere, DisplayName="初始位置", Category="参数")
	FVector2D From;
	UPROPERTY(EditAnywhere, DisplayName="目标位置", Category="参数")
	FVector2D To;
	
	UPROPERTY(VisibleAnywhere, DisplayName="当前位置", Category="参数")
	FVector2D CurPos;
};

