#pragma once
#include "KGEaseLerp.h"
#include "Components/Widget.h"
#include "UMG/WidgetComponent/KGTickableWidgetComponent.h"
#include "KGBaseTween.generated.h"

DECLARE_DYNAMIC_DELEGATE(FTweenFinishDelegate);

UCLASS(Abstract)
class UKGBaseTween : public UKGTickableWidgetComponent
{
	GENERATED_BODY()
	
public:
	UFUNCTION(BlueprintCallable)
	void Play();
	UFUNCTION(BlueprintCallable)
	void Stop();
	UFUNCTION(CallInEditor, Category="播放控制")
	void Pause();
	UFUNCTION(CallInEditor, Category="播放控制")
	void Reset();

#if WITH_EDITOR
	UFUNCTION(CallInEditor, Category="播放控制")
	void PlayEditor();
#endif

	UFUNCTION(BlueprintCallable)
	void SetEaseType(EaseType InType);
	UFUNCTION(BlueprintCallable)
	void SetLoopTime(int InLoopTimes);
	UFUNCTION(BlueprintCallable)
	void SetDurationTime(float InDuration);

protected:
	virtual void OnInit() override;
	virtual void OnRelease() override;
	virtual void TweenUpdate(float InCurTime);
	void InitWidget();
	void PlayFinish();

	UPROPERTY(EditAnywhere, DisplayName="持续时间", Category="参数", meta=(ClampMin = 0))
	float DurationTime = 0;
	float CurTime = 0;
	UPROPERTY(EditAnywhere, DisplayName="循环次数", Category="参数", meta=(ClampMin = 0))
	int LoopTimes = 1;

	UPROPERTY()
	FTweenFinishDelegate OnTweenFinishEvent;
	
	UPROPERTY()
	TWeakObjectPtr<UWidget> Widget;
	
	UPROPERTY(EditAnywhere, DisplayName="曲线", Category="参数")
	EaseType Ease = EaseType::Linear;

private:
	virtual void Tick(float DeltaTime) override;
	
	UFUNCTION()
	void ExecuteCallback();

	bool IsPlaying;
};