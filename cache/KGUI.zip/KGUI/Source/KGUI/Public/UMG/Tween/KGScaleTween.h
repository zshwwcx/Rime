#pragma once
#include "KGBaseTween.h"
#include "KGScaleTween.generated.h"

UCLASS(DisplayName = ScaleTween, meta = (ComponentCategory = "Tween", DisallowMultipleComponent))
class KGUI_API UKGScaleTween : public UKGBaseTween
{
	GENERATED_BODY()
	
public:
	UFUNCTION()
	void SetData(float From, float To);

private:
	virtual void TweenUpdate(float InCurTime) override;

private:
	UPROPERTY(EditAnywhere, DisplayName="初始缩放", Category="参数", meta=(ClampMin = 0))
	float FromScale;
	UPROPERTY(EditAnywhere, DisplayName="目标缩放", Category="参数", meta=(ClampMin = 0))
	float ToScale;
	
	UPROPERTY(VisibleAnywhere, DisplayName="当前插值缩放", Category="参数")
	FVector2D CurScale;
};
