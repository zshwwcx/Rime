#pragma once

#include "CoreMinimal.h"

#include "UMG/IrregularListView/KGIrregularListViewShapeStyle.h"

#include "KGIrregularListViewLensShapeStyle.generated.h"

UCLASS(DisplayName = "Lens")
class KGUI_API UKGIrregularListViewLensShapeStyle : public UKGIrregularListViewShapeStyle
{
	GENERATED_BODY()

public:
	virtual FVector2D RaiseOnArrangeItem(const FGeometry& Geometry, UUserWidget* Widget, float Progress) override;
	virtual float RaiseOnDragged(const FGeometry& Geometry, const FPointerEvent& TouchEvent) override;

public:
	UPROPERTY(EditAnywhere, Category = "Arragement")
	float MagnificationPower = 1.2f;

	UPROPERTY(EditAnywhere, Category = "Arragement")
	float LensRadius = 0.2f;

	UPROPERTY(EditAnywhere, Category = "Arragement")
	float ShiftDistortion = 1;

	UPROPERTY(EditAnywhere, Category = "Arragement")
	bool bUseAbsoluteLength = false;

	UPROPERTY(EditAnywhere, Category = "Arragement", meta = (EditConditionHides, EditCondition="bUseAbsoluteLength"))
	float AbsoluteLength = 100;

	UPROPERTY(EditAnywhere, Category = "Interaction")
	float DragSpeed = 1.0f;
};