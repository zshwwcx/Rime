#pragma once

#include "CoreMinimal.h"

#include "UMG/IrregularListView/KGIrregularListViewShapeStyle.h"

#include "KGIrregularListViewCircleShapeStyle.generated.h"

UCLASS(DisplayName = "Circle")
class KGUI_API UKGIrregularListViewCircleShapeStyle : public UKGIrregularListViewShapeStyle
{
	GENERATED_BODY()

public:
	virtual FVector2D RaiseOnArrangeItem(const FGeometry& Geometry, UUserWidget* Widget, float Progress) override;
	virtual float RaiseOnDragged(const FGeometry& Geometry, const FPointerEvent& TouchEvent) override;
	virtual bool RaiseOnDragStarting(const FGeometry& Geometry, const FPointerEvent& TouchEvent) override;

	UPROPERTY(EditAnywhere, Category = "Common", DisplayName = "Relative Offset")
	FVector2D Offset = FVector2D::ZeroVector;

	UPROPERTY(EditAnywhere, Category = "Common", DisplayName = "Absolute Offset")
	FVector2D AbsoluteOffset = FVector2D::ZeroVector;

	UPROPERTY(EditAnywhere, Category = "Arrangement")
	float Direction = 0;

	UPROPERTY(EditAnywhere, Category = "Arrangement")
	float Angle = 180;

	UPROPERTY(EditAnywhere, Category = "Arrangement")
	float Radius = 200;

	UPROPERTY(EditAnywhere, Category = "Arrangement", DisplayName = "Local Rotation Compensation")
	bool LocalRotationCompensationEnabled = false;

	UPROPERTY(EditAnywhere, Category = "Drag", meta = (ClampMin = 0))
	float Speed = 1;

	UPROPERTY(EditAnywhere, Category = "Drag")
	bool bInteractableAreaEnabled = false;

	UPROPERTY(EditAnywhere, Category = "Drag", meta = (ClampMin = 0, ClampMax = 1))
	float InteractableInnerRadius = 0;

	UPROPERTY(EditAnywhere, Category = "Drag", meta = (ClampMin = 0, ClampMax = 1))
	float InteractableOuterRadius = 1;

private:
	FVector2D GetTouchRelativePosition(const FGeometry& Geometry, const FPointerEvent& TouchEvent) const;
};