#pragma once

#include "CoreMinimal.h"

#include "Componentization/KGWidgetComponent.h"
#include "UMG/Components/KGIrregularListView.h"

#include "KGIrregularListViewShapeStyle.generated.h"

UCLASS(Abstract, DisplayName = "Irregular List View Shape Style", meta = (DisallowMultipleComponent, RequireWidget = "/Script/KGUI.KGIrregularListView", ComponentCategory = "Irregular List View Shape Style"))
class KGUI_API UKGIrregularListViewShapeStyle : public UKGWidgetComponent
{
    GENERATED_BODY()

public:
    virtual FVector2D RaiseOnArrangeItem(const FGeometry& Geometry, UUserWidget* Widget, float Progress);
    virtual float RaiseOnDragged(const FGeometry& Geometry, const FPointerEvent& TouchEvent);
	virtual bool RaiseOnDragStarting(const FGeometry& Geometry, const FPointerEvent& TouchEvent);

	UFUNCTION(BlueprintCallable)
    UKGIrregularListView* GetIrregularListView() const;

public:
    UFUNCTION(BlueprintNativeEvent, Category = "Kuaishou Game Irregular List View")
    FVector2D OnArrangeItem(const FGeometry& Geometry, UUserWidget* Widget, float Progress);

    UFUNCTION(BlueprintNativeEvent, Category = "Kuaishou Game Irregular List View")
    float OnDragged(const FGeometry& Geometry, const FPointerEvent& TouchEvent);

	UFUNCTION(BlueprintNativeEvent, Category = "Kuaishou Game Irregular List View")
	bool OnDragStarting(const FGeometry& Geometry, const FPointerEvent& TouchEvent);
};