#pragma once

#include "CoreMinimal.h"

#include "UMG/IrregularListView/KGIrregularListViewShapeStyle.h"

#include "KGIrregularListViewWheelShapeStyle.generated.h"

UCLASS(DisplayName = "Wheel")
class KGUI_API UKGIrregularListViewWheelShapeStyle : public UKGIrregularListViewShapeStyle
{
	GENERATED_BODY()

public:
	virtual FVector2D RaiseOnArrangeItem(const FGeometry& Geometry, UUserWidget* Widget, float Progress) override;
	virtual float RaiseOnDragged(const FGeometry& Geometry, const FPointerEvent& TouchEvent) override;

public:
	UPROPERTY(EditAnywhere, Category = "Arragement")
	float Radius = 200;

	UPROPERTY(EditAnywhere, Category = "Arragement")
	float Perspective = 1;

	UPROPERTY(EditAnywhere, Category = "Arragement")
	float Padding = 0;
};