﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KGUserWidget.h"
#include "C7/KGUITickableSubsystem.h"
#include "KGBlackScreenUserWidget.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBlackScreenEvent);

class UKGImage;
/**
 * UKGBlackScreenUserWidget
 */
UCLASS(BlueprintType, Blueprintable, meta=( DontUseGenericSpawnObject="True", DisableNativeTick))
class KGUI_API UKGBlackScreenUserWidget : public UKGUserWidget, public FKGUITickableObjectBase
{
    GENERATED_BODY()
public:
    UPROPERTY(BlueprintReadWrite, EditAnywhere, meta=(BindWidgetOptional))
    UKGImage* ImgBackground;
    
    UPROPERTY(Transient, BlueprintReadOnly, VisibleAnywhere)
    float Duration = 1.f;
    
    UPROPERTY(Transient, BlueprintReadOnly, VisibleAnywhere)
    float CurTime = 0.f;
    
    UPROPERTY(Transient, BlueprintReadOnly, VisibleAnywhere)
    float TimeOffset = 0.f;
    
    UPROPERTY(Transient, BlueprintReadOnly, VisibleAnywhere)
    float FromAlpha = 0.f;
    
    UPROPERTY(Transient, BlueprintReadOnly, VisibleAnywhere)
    float ToAlpha= 1.f;
    
    UPROPERTY(Transient, BlueprintReadOnly, VisibleAnywhere)
    float StartOnCurve;
    
    UPROPERTY(Transient, BlueprintReadOnly, VisibleAnywhere)
    float EndOnCurve;
    
    UPROPERTY(Transient, BlueprintReadOnly, VisibleAnywhere)
    bool bHasFading = false;
    
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TObjectPtr<UCurveFloat> Curve = nullptr;
    
    UPROPERTY(Transient, BlueprintReadOnly, VisibleAnywhere)
    bool bKeepOnEnding = true;
    
    UPROPERTY(EditAnywhere, BlueprintAssignable)
    FBlackScreenEvent OnFadeDone;
    
    virtual bool Initialize() override;
    virtual void ReleaseSlateResources(bool bReleaseChildren) override;
    virtual void Tick( float DeltaTime )  override;
    virtual bool IsTickable() const override;
        
    UFUNCTION(BlueprintCallable)
    void SetCurve(UCurveFloat* InCurve);
    
    /** 
     * 播放黑屏
     * @param InDuration 黑屏持续时间
     * @param InStartOnCurve 在曲线上开始的时间点
     * @param InLengthOnCurve 在曲线上播放时间长度
     * @param bInKeepOnEnding 当InDuration > InLengthOnCurve时，将曲线上的效果放在开头/结尾。true表示放在开头，false表示放在末尾
     */
    UFUNCTION(BlueprintCallable)
    bool PlayCurve(float InDuration, float InStartOnCurve = 0.f, float InLengthOnCurve = -1.0f, bool bInKeepOnEnding = true);
private:
    void Apply(float InAlpha) const;
};
