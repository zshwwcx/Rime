#pragma once

#include "CoreMinimal.h"
#include "UMG/Slate/SKGObjectTableRow.h"

#include "KGListViewShapeStyle.generated.h"

struct FKGListItem;

UCLASS(Abstract, MinimalAPI, EditInlineNew, DisplayName = "List View Shape Style")
class UKGListViewShapeStyle : public UObject
{
	GENERATED_BODY()

protected:
	using ItemType = TSharedPtr<FKGListItem>;

public:
	virtual void RaiseOnModifyEntry(const FGeometry& Geometry, TSharedRef<SKGObjectTableRow<ItemType>> Entry);

	UFUNCTION(BlueprintNativeEvent, Category = "List View")
	void OnModifyEntry(const FGeometry& Geometry, UListViewBase* ListView, UUserWidget* Widget);
};