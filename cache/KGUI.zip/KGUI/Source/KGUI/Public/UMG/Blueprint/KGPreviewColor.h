#pragma once

#include "CoreMinimal.h"

#include "KGPreviewColor.generated.h"

USTRUCT(BlueprintType)
struct FKGPreviewColor {
	GENERATED_BODY()

	UPROPERTY()
	FLinearColor LinearColor = FLinearColor::Transparent;
};