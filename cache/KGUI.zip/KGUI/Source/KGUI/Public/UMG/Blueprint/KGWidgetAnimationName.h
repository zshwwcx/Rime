#pragma once

#include "KGWidgetAnimationName.generated.h"

USTRUCT(BlueprintType)
struct FKGWidgetAnimationName
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Name;

	operator const FString&() const { return Name; }

	bool IsEmpty() const { return Name.IsEmpty(); }


	FKGWidgetAnimationName& operator=(const FString& InContent)
	{
		Name = InContent;
		return *this;
	}
};