#pragma once

#include "CoreMinimal.h"
#include "Layout/Margin.h"
#include "Widgets/Layout/Anchors.h"

#include "KGRedPointOverlaySlotData.generated.h"

USTRUCT(BlueprintType)
struct KGUI_API FKGRedPointOverlaySlotData
{
public:
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DispalyName = "Overlay Layout:Padding", Category = "Red Point Settings"))
	FMargin Padding;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DispalyName = "Overlay Layout:HorizontalAlignment", Category = "Red Point Settings"))
	TEnumAsByte<EHorizontalAlignment> HorizontalAlignment = EHorizontalAlignment::HAlign_Right;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DispalyName = "Overlay Layout:VerticalAlignment", Category = "Red Point Settings"))
	TEnumAsByte<EVerticalAlignment> VerticalAlignment = EVerticalAlignment::VAlign_Top;

};