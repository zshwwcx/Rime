// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Blueprint/UserWidget.h"
#include "Components/PanelWidget.h"
#include "Engine/DirectionalLight.h"
#include "EngineUtils.h"
#include "Engine/Console.h"
#include "Engine/SceneCapture2D.h"
#include "Components/TextBlock.h"
#include "UMG/Components/KGRichTextBlock.h"
#include "Components/EditableText.h"
#include "Components/GPUTurboTextBlock.h"
#include "Components/Image.h"
#include "Components/MultiLineEditableText.h"
#include "Components/SpinBox.h"
#include "Core/Common.h"
#include "UMG/Components/KGCheckBox.h"
#include "UMG/Components/KGListView.h"
#include "UMG/Components/KGProgressBar.h"
#include "UMG/Components/KGSlider.h"

#include "UIFunctionLibrary.generated.h"


class UImage;
struct FSlateBrush;

UCLASS()
class KGUI_API UKGListObjectItem : public UObject
{
	GENERATED_BODY()
public:
	UPROPERTY()
		int Index;
};

USTRUCT(BlueprintType)
struct FKGPaperSpriteInfo
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY()
	FString PathName;
	UPROPERTY()
	int32 Size = 0;
	UPROPERTY()
	int32 Width = 0;
	UPROPERTY()
	int32 Height = 0;
};

USTRUCT(BlueprintType)
struct FKGPaperSpriteAtlasInfo
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY()
	FString Name;
	UPROPERTY()
	FString AssetPath;
	UPROPERTY()
	int32 Size = 0;
	UPROPERTY()
	int32 Width = 0;
	UPROPERTY()
	int32 Height = 0;
	UPROPERTY()
	TArray<FKGPaperSpriteInfo> PaperSpriteData;
};

UENUM(BlueprintType)
enum class EMaskDetectResult : uint8
{
	NotValid               UMETA(DisplayName = "Texture Not Valid"),
	UnsupportedFormat      UMETA(DisplayName = "Unsupported Format"),
	NotMask                UMETA(DisplayName = "Not a Mask"),
	Mask8Bit               UMETA(DisplayName = "Mask (8-bit)"),
	Mask16Bit              UMETA(DisplayName = "Mask (16-bit)")
};

/** 
 * 
 */
UCLASS()
class KGUI_API UUIFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION()
	static FLinearColor SRGBColorFromHex(const FString& HexStr);
	
	UFUNCTION(BlueprintCallable, Category = "UI")
		static FVector2D GetAbsolutePosition(UWidget * Widget,FVector2D& Coordinate);
	
	UFUNCTION(BlueprintCallable, Category = "UI")
		static FVector2D GetScreenSpacePosition(UWidget * Widget,FVector2D& Coordinate);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static FSlateColor LinerColorToSlateColor(FLinearColor& InColor);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static FSlateColor FColorToSlateColor(FColor& InColor);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static void SetBrushMatchSize(UImage* Image, const FSlateBrush& Brush);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static FKey GetKeyFromName(const FString& KeyName);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static UWidget* ConstructWidget(TSubclassOf<UWidget> WidgetClass,UUserWidget* ParentWidget,FName WidgetName);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static FString GetUserWidgetPackageName(UUserWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static FString GetWidgetFullPackageName(UWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static FString GetClassFullPackageName(UClass* Class);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static TArray<UUserWidget*> GatherAllWBP(UUserWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static FRuntimeFloatCurve GetDynamicFloatCurve(float OffsetX, float OffsetY, float Tangent);

	UFUNCTION(BlueprintCallable, Category = "UI")
		static void ReleaseAllPointerCapture();

	// 获取当前时间戳
	UFUNCTION(BlueprintCallable, Category = "Math")
	static int64 GetUtcSecond();
	
	UFUNCTION(BlueprintCallable, Category = "UI")
	static UTextureRenderTarget2D* NewRenderTarget2d(UWorld* World,FVector2D& Size);

	UFUNCTION(BlueprintCallable, Category = "UI")
	static void SetZOrder(UUserWidget* UserWidget, int Order);

	UFUNCTION(BlueprintCallable, Category = "UI")
	static void SetCanCache(UUserWidget* UserWidget);

	UFUNCTION(BlueprintCallable, Category = "UI")
	static TArray<UKGListObjectItem*> GetListObject(UObject* Outer, int Count);

	UFUNCTION(BlueprintCallable, Category = "UI")
	static UWidget* DeepDuplicateWidget(UWidget* pUWidget, UObject* Outer);

	UFUNCTION(BlueprintPure, Category = "UI")
	static UWidget* FindWidget(UWidget* Widget, const FName& Name);

	UFUNCTION(BlueprintPure, Category = "UI")
	static UWidget* C7CreateWidget(UUserWidget* UserWidget, UPanelWidget* Parent, UWidget* Widget);

#if WITH_EDITOR
	UFUNCTION(BlueprintPure, Category = "UI")
	static TArray<FKGPaperSpriteAtlasInfo> GetAllSpriteAssets();

	UFUNCTION(BlueprintPure, Category = "UI")
	static int64 GetSprintAssetsGroupSize(UPaperSpriteAtlas* SpriteAtlas);

	UFUNCTION(BlueprintPure, Category = "UI")
	static TArray<FKGPaperSpriteInfo> GetAtlasTextureSize(UPaperSpriteAtlas* SpriteAtlas);

	UFUNCTION(BlueprintPure, Category = "UI")
	static EMaskDetectResult IsMaskTexture(UTexture2D* Texture);
#endif

	UFUNCTION(BlueprintPure, Category = "UI")
	static bool IsAtlasLoaded(const FString& AtlasPath);
	
	UFUNCTION(BlueprintPure, Category = "UI")
	static int64 GetTextureSize(UTexture* Texture);

	UFUNCTION(BlueprintPure, Category = "UI")
	static TArray<UTexture*> GetWidgetTexture(UUserWidget* UserWidgetInstance);

	UFUNCTION(BlueprintPure, Category = "UI")
	static TArray<UPaperSprite*> GetWidgetPaperSprite(UUserWidget* UserWidgetInstance);

	UFUNCTION()
	static FString GetAppAbsolutePath(FString filePath);
	
	/**
	 * Swaps the child widget out of the slot, and replaces it with the new child widget.
	 * @param CurrentChild The existing child widget being removed.
	 * @param NewChild The new child widget being inserted.
	 * @return true if the CurrentChild was found and the swap occurred, otherwise false.
	 */
	UFUNCTION(BlueprintPure, Category = "UI")
	static bool ReplaceChild(UPanelWidget* Parent, UWidget* CurrentChild, UWidget* NewChild);

	/**
	 * Add a child widget. This does not update the live slate version, it requires
	 * a rebuild of the whole UI to see a change.
	 */
	UFUNCTION(BlueprintPure, Category = "UI")
	static UPanelSlot* AddChild(UPanelWidget* Parent, UWidget* Content);

	/**
	 * Moves the child widget from its current index to the new index provided.
	 */
	UFUNCTION(BlueprintCallable, Category = "UI")
	static void ShiftChild(UPanelWidget* Parent, int32 Index, UWidget* Child);

	UFUNCTION(BlueprintCallable, Category = "UI")
	static void SwapChild(UPanelWidget* Parent, int32 Index1, int32 Index2);

	UFUNCTION()
	static void RemoveChild(UPanelWidget* Parent, int Index);

	UFUNCTION()
	static UWidget* GetWidgetFromName(UUserWidget* UserWidget, const FName& Name);

	UFUNCTION()
	static UWidget* GetRootWidget(UUserWidget* UserWidget);

#if WITH_EDITOR
	UFUNCTION()
	static EDPIScalePreviewPlatforms GetPreviewPlatform();
#endif
	UFUNCTION()
	static void FlushRenderState();

	// 获取在2D屏幕的朝向角度
	UFUNCTION()
	static double DotProductWithForward2D(const FVector2D& InDirection);
	// 计算3D空间下Actor距离特定位置的Dist投影到2D平面距离
	UFUNCTION()
	static float Size2DBetweenActorAndAnchor(AActor* InActor, const FVector& InAnchorPoint);
	// 计算3D空间下Actor距离特定位置的距离
	UFUNCTION()
	static float DistanceBetweenActorAndAnchor(AActor* InActor, float X, float Y, float Z);
	// 计算3D空间下Actor距离另一个Actor的距离
	UFUNCTION()
	static float DistanceBetweenActorAndActor(AActor* InActor, AActor* InActor2);

	//dragDropOperation封装
	UFUNCTION()
	static UDragDropOperation* CreateDrag(UWidget* DefaultDragVisual, TSubclassOf<UDragDropOperation> Operation);

	UFUNCTION()
	static void OpenConsole();

	//实例化蓝图UserWidget
	UFUNCTION()
	static UUserWidget* InstanceBP(UUserWidget* SrcWidget);

	UFUNCTION()
	static UUserWidget* CreateWidgetWithName(UObject* WorldContextObject, TSubclassOf<UUserWidget> WidgetType, FName WidgetName);
	
	UFUNCTION()
	static UUserWidget* CreateWidgetWithID(UObject* WorldContextObject, int64 InID);
	//统计当前UObject数量
	UFUNCTION()
	static int GetObjectArrayNum();

	//动态设置材质贴图
	UFUNCTION()
	static UTexture* GetTextureInst(const FString& path);

	//保存string到对应文件中
	UFUNCTION()
	static void SaveStringToFile(const FString FFileName,const FString Content);


	//获取Tex对应坐标的颜色
	UFUNCTION()
	static FColor GetTextureColorAt(UTexture2D* InTex, const float CoordX,const float CoordY);

	UFUNCTION()
	static void ReplaceWidgetWithNode(UPanelWidget* SourceNode, UPanelWidget* TargetNode);

	UFUNCTION()
	static FString GetDeviceTypeName();

	UFUNCTION()
	static ADirectionalLight* GetDirectionalLight1(UWorld* World);

	UFUNCTION(BlueprintCallable, Category = "UI")
	static FVector2D GetMousePositionOnPlatform();

	UFUNCTION()
	static void MarkActorComponentRenderStateDirty(UActorComponent* ActorComponent);

	UFUNCTION()
	static void MarkComponentsRenderStateDirty(AActor* Actor);

	UFUNCTION()
	static bool CopyToClipBoard(const FString& CopyText);

	UFUNCTION()
	static FString PasteFromClipboard();
	
	UFUNCTION()
	static void GetAllAutoAnimationInfo(UUserWidget* WidgetRoot, float& MaxInTime, float& MaxOutTime, TArray<UUserWidget*>& AnimationInList, TArray<UUserWidget*>& AnimationOutList);

	UFUNCTION()
	static double GetFTimespanTotalSeconds(FTimespan Timespan);

	UFUNCTION()
	static int GetBatteryLevel();

	UFUNCTION()
	static bool IsRunningOnBattery();

	//begin add by tangzhangpeng@kuaishou.com[get battery state interface]
	UFUNCTION()
	static int32 GetBatteryStateID();
	//end add by tangzhangpeng@kuaishou.com[get battery state interface]

	static void RegisteFunctions();
    static void SetRenderTranslation(UWidget* Widget, float InPosX, float InPosY);
	static void SetRenderScale(UWidget* Widget, float ScaleX, float ScaleY);
	static void SetRenderTransformAngle(UWidget* Widget, float InAngle);
	static void SetRenderShear(UWidget* Widget, float ShearX, float ShearY);
	static float GetRenderOpacity(UWidget* Widget);
	static void SetRenderOpacity(UWidget* Widget, float InOpacity);
	static float EvaluateCurveValue(UCurveFloat* Curve, float InRatio);
	static void SetRenderScaleByCurveFloat(UWidget* Widget, UCurveFloat* Curve, float InRatio);
	static FSlateRect GetViewportBounds(UObject* WorldContext);
	static bool IsPointerInWidget(UWidget* Widget, float PointerScreenPosX, float PointerScreenPosY, int32 UserIndex);
	static FLinearColor GetColorAndOpacity(UWidget* Widget);
	static void SetColorAndOpacity(UWidget* Widget, const FLinearColor& InColor);
    static void SetOpacity(UWidget* Widget, float InOpacity);
    static float GetOpacity(UWidget* Widget);
	UFUNCTION()
	static TArray<UWidget*> GetVisibleChildren(UPanelWidget* Panel);
	
	UFUNCTION()
	static ASceneCapture2D* CreateSceneCapture2DActor(UWorld* World);

	UFUNCTION()
	static bool CaptureBlurImage(ASceneCapture2D* Capture, UImage* Image, FVector Location, FRotator Rotation);

	#pragma region 提供给交互的提供易用性的蓝图函数

	#pragma region 字体

	static const FSlateFontInfo& GetFontInfo(UWidget* Widget)
	{
		static FSlateFontInfo DefaultFontInfo;
		if (Widget == nullptr)
		{
			UE_LOG(LogKGUI, Error, TEXT("Cannot Get Font Info from None."));
			return DefaultFontInfo;
		}
		if (auto TextBlock = Cast<UTextBlock>(Widget))
		{
			return TextBlock->GetFont();
		}
		else if (auto EditableText = Cast<UEditableText>(Widget))
		{
			return EditableText->GetFont();
		}
		else if (auto GPUTurboTextBlock = Cast<UGPUTurboTextBlock>(Widget))
		{
			return GPUTurboTextBlock->GetFont();
		}
		else if (auto MultiLineEditableText = Cast<UMultiLineEditableText>(Widget))
		{
			return MultiLineEditableText->GetFont();
		}
		else if (auto SpinBox = Cast<USpinBox>(Widget))
		{
			return SpinBox->GetFont();
		}
		else if (auto RichTextBlock = Cast<UKGRichTextBlock>(Widget))
		{
			return RichTextBlock->GetDefaultTextStyleOverride().Font;
		}
		UE_LOG(LogKGUI, Error, TEXT("Unsupported widget type: %s, (when calling GetFontInfo)"), *Widget->GetClass()->GetName());
		return DefaultFontInfo;
	}

	static void SetFontInfo(UWidget* Widget, const FSlateFontInfo& FontInfo)
	{
		if (Widget == nullptr)
		{
			UE_LOG(LogKGUI, Error, TEXT("Cannot Set Font Info to None."));
			return;
		}
		if (auto TextBlock = Cast<UTextBlock>(Widget))
		{
			TextBlock->SetFont(FontInfo);
		}
		else if (auto Editable = Cast<UEditableText>(Widget))
		{
			Editable->SetFont(FontInfo);
		}
		else if (auto GPUTurboTextBlock = Cast<UGPUTurboTextBlock>(Widget))
		{
			GPUTurboTextBlock->SetFont(FontInfo);
		}
		else if (auto MultiLineEditableText = Cast<UMultiLineEditableText>(Widget))
		{
			MultiLineEditableText->SetFont(FontInfo);
		}
		else if (auto SpinBox = Cast<USpinBox>(Widget))
		{
			SpinBox->SetFont(FontInfo);
		}
		else if (auto RichTextBlock = Cast<UKGRichTextBlock>(Widget))
		{
			RichTextBlock->SetDefaultFont(FontInfo);
		}
		else
		{
			UE_LOG(LogKGUI, Error, TEXT("Unsupported widget type: %s, (when calling SetFontInfo)"), *Widget->GetClass()->GetName());
		}
	}

	static FVector2D GetTextShadowOffset(UWidget* Widget);

	UFUNCTION(BlueprintPure, Category = "UI|Font", DisplayName="Convert Font Size From 72 DPI To Native (KGUI)")
	static float ConvertFontSizeFrom72DPIToNative(float FontSize);

	static float ConvertFontSizeFromNativeTo72DPI(float FontSize);

	UFUNCTION(BlueprintCallable, Category = "UI|Font", DisplayName = "Get Font Size (72 DPI, KGUI)")
	static float GetFontSize72DPI(UWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI|Font", DisplayName = "Set Font Size (72 DPI, KGUI)")
	static void SetFontSize72DPI(UWidget* Widget, float FontSize);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static const UObject* GetFontFamily(UWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static void SetFontFamily(UWidget* Widget, UObject* FontObject);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static UObject* GetFontMaterial(UWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static void SetFontMaterial(UWidget* Widget, UObject* FontMaterial);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static const FFontOutlineSettings& GetFontOutlineSettings(UWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static void SetFontOutlineSettings(UWidget* Widget, const FFontOutlineSettings OutlineSettings);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static int32 GetFontLetterSpacing(UWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static void SetFontLetterSpacing(UWidget* Widget, int32 LetterSpacing);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static float GetFontSkewAmount(UWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static void SetFontSkewAmount(UWidget* Widget, float SkewAmount);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static FName GetFontTypefaceFontName(UWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static void SetFontTypefaceFontName(UWidget* Widget, FName TypefaceFontName);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static float GetFontLineHeightInSlateUnits(UWidget* Widget, float Scale);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static float GetFontLetterSpacingScaleFactor(UWidget* Widget);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static void SetTextLineSpacingInSlateUnits(UWidget* Widget, float LineSpacing, float Scale, float BaseLineHeightPercentage);

	UFUNCTION(BlueprintCallable, Category = "UI|Font")
	static void SetTextLetterSpacingInSlateUnits(UWidget* Widget, float LetterSpacing);

	#pragma endregion

	#pragma region 笔刷

	PRAGMA_DISABLE_DEPRECATION_WARNINGS

	#define GET_BRUSH_FIELD_WITH_PROPERTY(Owner, PropertyName, FieldName) \
	{ \
		using FieldType = decltype(Owner->PropertyName.FieldName); \
		if (Owner == nullptr) return FieldType(); \
		return Owner->PropertyName.FieldName; \
	}

	#define SET_BRUSH_FIELD_WITH_PROPERTY(Owner, PropertyName, FieldName) \
	{ \
		if (Owner == nullptr) return; \
		auto Brush = Owner->PropertyName; \
		Brush.FieldName = FieldName; \
		Owner->PropertyName = Brush; \
		if (auto Slate = Owner->GetCachedWidget()) { Slate->Invalidate(EInvalidateWidgetReason::Layout); } \
	}

	#define GET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Owner, PropertyName) \
	{ \
		using FieldType = decltype(Owner->PropertyName.GetResourceObject()); \
		if (Owner == nullptr) return FieldType(); \
		return Owner->PropertyName.GetResourceObject(); \
	}

	#define SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Owner, PropertyName, FieldName) \
	{ \
		if (Owner == nullptr) return; \
		auto Brush = Owner->PropertyName; \
		Brush.SetResourceObject(FieldName); \
		Owner->PropertyName = Brush; \
		if (auto Slate = Owner->GetCachedWidget()) { Slate->Invalidate(EInvalidateWidgetReason::Layout); } \
	}

	#define GET_BRUSH_FIELD_WITH_METHOD(Owner, Getter, FieldName) \
	{ \
		using FieldType = decltype(Owner->Getter.FieldName); \
		if (Owner == nullptr) return FieldType(); \
		return Owner->Getter.FieldName; \
	}

	#define SET_BRUSH_FIELD_WITH_METHOD(Owner, Getter, Setter, FieldName) \
	{ \
		if (Owner == nullptr) return; \
		auto Brush = Owner->Getter; \
		Brush.FieldName = FieldName; \
		Owner->Setter(Brush); \
	}

	#pragma region Image.Brush

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static UObject* GetImageBrushResourceObject(UKGImage* Image)
	{
		GET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Image, Brush)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetImageBrushResourceObject(UKGImage* Image, UObject* ResourceObject)
	{
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Image, Brush, ResourceObject)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushDrawType::Type GetImageBrushDrawAs(UKGImage* Image)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Image, Brush, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetImageBrushDrawAs(UKGImage* Image, ESlateBrushDrawType::Type DrawAs)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Image, Brush, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushTileType::Type GetImageBrushTiling(UKGImage* Image)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Image, Brush, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetImageBrushTiling(UKGImage* Image, ESlateBrushTileType::Type Tiling)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Image, Brush, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FVector2D GetImageBrushImageSize(UKGImage* Image)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Image, Brush, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetImageBrushImageSize(UKGImage* Image, const FVector2D& ImageSize)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Image, Brush, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FSlateBrushOutlineSettings GetImageBrushOutlineSettings(UKGImage* Image)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Image, Brush, OutlineSettings)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetImageBrushOutlineSettings(UKGImage* Image, const FSlateBrushOutlineSettings& OutlineSettings)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Image, Brush, OutlineSettings)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetImageKGBrush(UKGImage* Image, const FKGSlateBrush& InBrush, bool bMatchSize);

	#pragma endregion

	#pragma region ListView.WidgetStyle.BackgroundBrush

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static UObject* GetListViewBackgroundBrushResourceObject(UKGListView* ListView)
	{
		GET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetListViewBackgroundBrushResourceObject(UKGListView* ListView, UObject* ResourceObject)
	{
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush, ResourceObject)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushDrawType::Type GetListViewBackgroundBrushDrawAs(UKGListView* ListView)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetListViewBackgroundBrushDrawAs(UKGListView* ListView, ESlateBrushDrawType::Type DrawAs)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushTileType::Type GetListViewBackgroundBrushTiling(UKGListView* ListView)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetListViewBackgroundBrushTiling(UKGListView* ListView, ESlateBrushTileType::Type Tiling)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FVector2D GetListViewBackgroundBrushImageSize(UKGListView* ListView)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetListViewBackgroundBrushImageSize(UKGListView* ListView, const FVector2D& ImageSize)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FSlateBrushOutlineSettings GetListViewBackgroundBrushOutlineSettings(UKGListView* ListView)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush, OutlineSettings)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetListViewBackgroundBrushOutlineSettings(UKGListView* ListView, const FSlateBrushOutlineSettings& OutlineSettings)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(ListView, GetWidgetStyle().BackgroundBrush, OutlineSettings)
	}

	#pragma endregion

	#pragma region CheckBox.WidgetStyle.CheckedImage/CheckedHoveredImage/CheckedPressedImage

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static UObject* GetCheckBoxCheckedBrushResourceObject(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxCheckedBrushResourceObject(UKGCheckBox* CheckBox, UObject* ResourceObject)
	{
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage, ResourceObject)
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedHoveredImage, ResourceObject)
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedPressedImage, ResourceObject)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushDrawType::Type GetCheckBoxCheckedBrushDrawAs(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxCheckedBrushDrawAs(UKGCheckBox* CheckBox, ESlateBrushDrawType::Type DrawAs)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage, DrawAs)
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedHoveredImage, DrawAs)
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedPressedImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushTileType::Type GetCheckBoxCheckedBrushTiling(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxCheckedBrushTiling(UKGCheckBox* CheckBox, ESlateBrushTileType::Type Tiling)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage, Tiling)
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedHoveredImage, Tiling)
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedPressedImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FVector2D GetCheckBoxCheckedBrushImageSize(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxCheckedBrushImageSize(UKGCheckBox* CheckBox, const FVector2D& ImageSize)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage, ImageSize)
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedHoveredImage, ImageSize)
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedPressedImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FSlateBrushOutlineSettings GetCheckBoxCheckedBrushOutlineSettings(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage, OutlineSettings)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxCheckedBrushOutlineSettings(UKGCheckBox* CheckBox, const FSlateBrushOutlineSettings& OutlineSettings)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedImage, OutlineSettings)
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedHoveredImage, OutlineSettings)
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.CheckedPressedImage, OutlineSettings)
	}

	#pragma endregion

	#pragma region CheckBox.WidgetStyle.BackgroundImage

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static UObject* GetCheckBoxBackgroundBrushResourceObject(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxBackgroundBrushResourceObject(UKGCheckBox* CheckBox, UObject* ResourceObject)
	{
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage, ResourceObject)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushDrawType::Type GetCheckBoxBackgroundBrushDrawAs(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxBackgroundBrushDrawAs(UKGCheckBox* CheckBox, ESlateBrushDrawType::Type DrawAs)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushTileType::Type GetCheckBoxBackgroundBrushTiling(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxBackgroundBrushTiling(UKGCheckBox* CheckBox, ESlateBrushTileType::Type Tiling)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FVector2D GetCheckBoxBackgroundBrushImageSize(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxBackgroundBrushImageSize(UKGCheckBox* CheckBox, const FVector2D& ImageSize)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FSlateBrushOutlineSettings GetCheckBoxBackgroundBrushOutlineSettings(UKGCheckBox* CheckBox)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage, OutlineSettings)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetCheckBoxBackgroundBrushOutlineSettings(UKGCheckBox* CheckBox, const FSlateBrushOutlineSettings& OutlineSettings)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(CheckBox, WidgetStyle.BackgroundImage, OutlineSettings)
	}

	#pragma endregion

	#pragma region ProgressBar.WidgetStyle.FillImage

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static UObject* GetProgressBarFillBrushResourceObject(UKGProgressBar* ProgressBar)
	{
		GET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetProgressBarFillBrushResourceObject(UKGProgressBar* ProgressBar, UObject* ResourceObject)
	{
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage, ResourceObject)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushDrawType::Type GetProgressBarFillBrushDrawAs(UKGProgressBar* ProgressBar)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetProgressBarFillBrushDrawAs(UKGProgressBar* ProgressBar, ESlateBrushDrawType::Type DrawAs)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushTileType::Type GetProgressBarFillBrushTiling(UKGProgressBar* ProgressBar)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetProgressBarFillBrushTiling(UKGProgressBar* ProgressBar, ESlateBrushTileType::Type Tiling)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FVector2D GetProgressBarFillBrushImageSize(UKGProgressBar* ProgressBar)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetProgressBarFillBrushImageSize(UKGProgressBar* ProgressBar, const FVector2D& ImageSize)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FSlateBrushOutlineSettings GetProgressBarFillBrushOutlineSettings(UKGProgressBar* ProgressBar)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage, OutlineSettings)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetProgressBarFillBrushOutlineSettings(UKGProgressBar* ProgressBar, const FSlateBrushOutlineSettings& OutlineSettings)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(ProgressBar, WidgetStyle.FillImage, OutlineSettings)
	}

	#pragma endregion

	#pragma region Slider.WidgetStyle.NormalBarImage/HoveredBarImage/DisabledBarImage

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static UObject* GetSliderBarBrushResourceObject(UKGSlider* Slider)
	{
		GET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderBarBrushResourceObject(UKGSlider* Slider, UObject* ResourceObject)
	{
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage, ResourceObject)
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredBarImage, ResourceObject)
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledBarImage, ResourceObject)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushDrawType::Type GetSliderBarBrushDrawAs(UKGSlider* Slider)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderBarBrushDrawAs(UKGSlider* Slider, ESlateBrushDrawType::Type DrawAs)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage, DrawAs)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredBarImage, DrawAs)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledBarImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushTileType::Type GetSliderBarBrushTiling(UKGSlider* Slider)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderBarBrushTiling(UKGSlider* Slider, ESlateBrushTileType::Type Tiling)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage, Tiling)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredBarImage, Tiling)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledBarImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FVector2D GetSliderBarBrushImageSize(UKGSlider* Slider)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderBarBrushImageSize(UKGSlider* Slider, const FVector2D& ImageSize)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage, ImageSize)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredBarImage, ImageSize)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledBarImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FSlateBrushOutlineSettings GetSliderBarBrushOutlineSettings(UKGSlider* Slider)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage, OutlineSettings)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderBarBrushOutlineSettings(UKGSlider* Slider, const FSlateBrushOutlineSettings& OutlineSettings)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalBarImage, OutlineSettings)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredBarImage, OutlineSettings)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledBarImage, OutlineSettings)
	}

	#pragma endregion

	#pragma region Slider.WidgetStyle.NormalThumbImage/HoveredThumbImage/DisabledThumbImage

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static UObject* GetSliderThumbBrushResourceObject(UKGSlider* Slider)
	{
		GET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderThumbBrushResourceObject(UKGSlider* Slider, UObject* ResourceObject)
	{
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage, ResourceObject)
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredThumbImage, ResourceObject)
		SET_BRUSH_RESOURCE_OBJECT_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledThumbImage, ResourceObject)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushDrawType::Type GetSliderThumbBrushDrawAs(UKGSlider* Slider)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderThumbBrushDrawAs(UKGSlider* Slider, ESlateBrushDrawType::Type DrawAs)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage, DrawAs)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredThumbImage, DrawAs)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledThumbImage, DrawAs)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static ESlateBrushTileType::Type GetSliderThumbBrushTiling(UKGSlider* Slider)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderThumbBrushTiling(UKGSlider* Slider, ESlateBrushTileType::Type Tiling)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage, Tiling)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredThumbImage, Tiling)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledThumbImage, Tiling)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FVector2D GetSliderThumbBrushImageSize(UKGSlider* Slider)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderThumbBrushImageSize(UKGSlider* Slider, const FVector2D& ImageSize)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage, ImageSize)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredThumbImage, ImageSize)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledThumbImage, ImageSize)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static FSlateBrushOutlineSettings GetSliderThumbBrushOutlineSettings(UKGSlider* Slider)
	{
		GET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage, OutlineSettings)
	}

	UFUNCTION(BlueprintCallable, Category = "UI|Brush")
	static void SetSliderThumbBrushOutlineSettings(UKGSlider* Slider, const FSlateBrushOutlineSettings& OutlineSettings)
	{
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.NormalThumbImage, OutlineSettings)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.HoveredThumbImage, OutlineSettings)
		SET_BRUSH_FIELD_WITH_PROPERTY(Slider, WidgetStyle.DisabledThumbImage, OutlineSettings)
	}

	#pragma endregion

	#undef GET_BRUSH_FIELD_WITH_PROPERTY
	#undef SET_BRUSH_FIELD_WITH_PROPERTY
	#undef GET_BRUSH_FIELD_WITH_METHOD
	#undef SET_BRUSH_FIELD_WITH_METHOD

	PRAGMA_ENABLE_DEPRECATION_WARNINGS

	#pragma endregion

	#pragma endregion

	#pragma region 材质
	// UI材质节点那边的Time用的是Eidtor启动以后的时间,需要匹配一下,runtime使用也没有问题
	UFUNCTION(BlueprintCallable, Category = "Time")
	static float GetTimeSinceEditorStartUp();
	#pragma endregion

	#pragma region 玩家输入控制

	UFUNCTION(BlueprintCallable, Category = "Input")
	void FlushPressedKeys();

	#pragma endregion

	#pragma region 屏幕相关

	UFUNCTION(BlueprintPure, Category = "Window")
	static bool IsCurrentlyFullscreen();

	#pragma endregion

	#pragma region 音效

	UFUNCTION(BlueprintCallable, Category = "Audio")
	static void PostAudioEventInBlueprint(UObject* Context, TSoftObjectPtr<class UAkAudioEvent> AudioEvent);

	#pragma endregion

	#pragma region 全局

	UFUNCTION(BlueprintCallable, Category = "UI")
	static void InvalidateAllWidgets(bool bClearResourcesImmediately);

	UFUNCTION(BlueprintCallable, Category = "UI")
	static void RequestDirtyTextRevision();

	#pragma endregion
};


