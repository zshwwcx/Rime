#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Engine/AssetUserData.h"
#include "Layout/Margin.h"
#include "Components/Image.h"

#include "KGSlice9Data.generated.h"

UCLASS(BlueprintType)
class KGUI_API UKGSlice9Data : public UAssetUserData
{
	GENERATED_BODY()

public:
	static void TryApply(UImage* Image);
    static void TryApply(FSlateBrush& InBrush);
protected:
	UPROPERTY(EditAnywhere, Category = "Slice 9")
	FMargin Margin;
};