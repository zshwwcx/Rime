// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/Blueprint/UIFunctionLibrary.h"
#include "Framework/Application/SlateApplication.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Components/EditableText.h"
#include "Components/GPUTurboTextBlock.h"
#include "Components/MultiLineEditableText.h"
#include "Components/SpinBox.h"
#include "Styling/SlateBrush.h"
#include "Engine/Texture2D.h"
#include "Runtime/UMG/Public/Blueprint/WidgetTree.h"
#include "Slate/SlateTextureAtlasInterface.h"
#include "Misc/PackageName.h"
#include "Curves/CurveFloat.h"
#include "Components/CanvasPanelSlot.h"
#include "Blueprint/GameViewportSubsystem.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Kismet/KismetMathLibrary.h"
#include "Runtime/UMG/Public/Components/CanvasPanel.h"
#include "Blueprint/DragDropOperation.h"
#include "Components/InvalidationBox.h"
#include "DeviceProfiles/DeviceProfile.h"
#include "DeviceProfiles/DeviceProfileManager.h"
#include "HAL/PlatformApplicationMisc.h"
#include "PaperSprite.h"
#include "PaperSpriteAtlas.h"
#include "Components/PanelWidget.h"
#include "Engine/Engine.h"
#include "Misc/FileHelper.h"
#include "TextureResource.h"
#include "Components/PanelWidget.h"
#include "Manager/KGAkAudioManager.h"

#if WITH_EDITOR
#include "UI/KGUIPlatformCustomSetting.h"
#include <AssetRegistry/AssetRegistryModule.h>
#endif
#include <HAL/FileManagerGeneric.h>
#include "UMG/Components/KGImage.h"
#include "UMG/Components/KGButton.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Animation/WidgetAnimation.h"
#include "MovieScene.h"
#include "LuaCppBinding.h"
#include "AssetRegistry/AssetData.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "Components/Widget.h"
#include "Curves/CurveFloat.h"
#include "Components/PanelWidget.h"
#include "Engine/GameViewportClient.h"
#include "Widgets/SViewport.h"
#include "Components/GPUTurboImage.h"
#include "Runtime/CinematicCamera/Public/CineCameraActor.h"
#if PLATFORM_IOS
#include "IOS/IOSPlatformMisc.h"
#elif PLATFORM_ANDROID
#include "Android/AndroidPlatformMisc.h"
#endif
#include "KGUI.h"
#include "Components/SceneCaptureComponent2D.h"
#include "3C/Util/KGUtils.h"
#include "Core/Common.h"

FLinearColor UUIFunctionLibrary::SRGBColorFromHex(const FString& HexStr)

{
	FColor Color = FColor::FromHex(HexStr);
	float red = Color.R / 255.0f;
	float green = Color.G / 255.0f;
	float blue = Color.B / 255.0f;
	float alpha = Color.A / 255.0f;

	red = red <= 0.04045f ? red / 12.92f : FMath::Pow((red + 0.055f) / 1.055f, 2.4f);
	green = green <= 0.04045f ? green / 12.92f : FMath::Pow((green + 0.055f) / 1.055f, 2.4f);
	blue = blue <= 0.04045f ? blue / 12.92f : FMath::Pow((blue + 0.055f) / 1.055f, 2.4f);
	return FLinearColor(red, green, blue, alpha);
}


FVector2D UUIFunctionLibrary::GetAbsolutePosition(UWidget * Widget,FVector2D& Coordinate)
{
	if (Widget!= nullptr)
	{
		return Widget->GetCachedGeometry().GetAbsolutePositionAtCoordinates(Coordinate);
	}
	return FVector2D(0,0);
}

FVector2D UUIFunctionLibrary::GetScreenSpacePosition(UWidget * Widget,FVector2D& Coordinate)
{
	if (Widget!= nullptr)
	{
		FVector2D Absolute = Widget->GetPaintSpaceGeometry().GetAbsolutePositionAtCoordinates(Coordinate);
		
		FVector2D Pixel;		// DPI后的Pos
		FVector2D Viewport;		// DPI前的Pos

		USlateBlueprintLibrary::AbsoluteToViewport(
			Widget->GetWorld(),
			Absolute,
			Pixel,
			Viewport
		);
		
		return Pixel;
	}
	return FVector2D(0,0);
}


FSlateColor UUIFunctionLibrary::LinerColorToSlateColor(FLinearColor& InColor)
{
	return FSlateColor(InColor);
}

FSlateColor UUIFunctionLibrary::FColorToSlateColor(FColor& InColor)
{
	return FSlateColor(InColor);
}

void UUIFunctionLibrary::SetBrushMatchSize(UImage* Image, const FSlateBrush& Brush)
{
	if (Image)
	{
		FSlateBrush CpBrush = Brush;
		if (UTexture2D* Texture = Cast<UTexture2D>(Brush.GetResourceObject()))
		{
			CpBrush.ImageSize.X = Texture->GetSizeX();
			CpBrush.ImageSize.Y = Texture->GetSizeY();
		}
		else if (ISlateTextureAtlasInterface* AtlasRegion = Cast<ISlateTextureAtlasInterface>(Brush.GetResourceObject()))
		{
			FSlateAtlasData AtlasData = AtlasRegion->GetSlateAtlasData();
			CpBrush.ImageSize = AtlasData.GetSourceDimensions();
		}
		Image->SetBrush(CpBrush);
	}
}

FKey UUIFunctionLibrary::GetKeyFromName(const FString& KeyName)
{
	return FKey(FName(KeyName));
}


UWidget* UUIFunctionLibrary::ConstructWidget(TSubclassOf<UWidget> WidgetClass,UUserWidget* ParentWidget,FName WidgetName = NAME_None)
{
	if(ParentWidget && ParentWidget->WidgetTree)
	{
		return ParentWidget->WidgetTree->ConstructWidget<UWidget>(WidgetClass,WidgetName);
	}
	return nullptr;
}

FString UUIFunctionLibrary::GetUserWidgetPackageName(UUserWidget* Widget)
{
	if (Widget)
	{
		if (UClass* Class = Widget->GetClass())
		{
			if (UPackage* Package = Class->GetPackage())
			{
				FString Name = FPackageName::GetShortName(Package->GetName());;
				return Name;
			}
		}
	}
	return FString();
}


FString UUIFunctionLibrary::GetWidgetFullPackageName(UWidget* Widget)
{
	if (Widget)
	{
		return GetClassFullPackageName(Widget->GetClass());
	}
	return FString();
}

FString UUIFunctionLibrary::GetClassFullPackageName(UClass* Class)
{
	if (Class)
	{
		FString FullName = Class->GetPathName();
		return FullName;
	}
	return FString();
}

static void GatherAllWBP_R(UUserWidget* Widget, TArray<UUserWidget*>& OutArr)
{
	if (Widget)
	{
		if (!OutArr.Contains(Widget))
		{
			OutArr.Add(Widget);	
		}
		int32 Start = OutArr.Num();
		if (Widget->WidgetTree)
		{
			TArray<UWidget*> AllWidgets;
			Widget->WidgetTree->GetAllWidgets(AllWidgets);
			for (int32 I = 0; I < AllWidgets.Num(); ++I)
			{
				UWidget* CWidget = AllWidgets[I];
				if (CWidget == nullptr)
				{
					continue;
				}
				if (UUserWidget* UserWidget = Cast<UUserWidget>(CWidget))
				{
					if (!OutArr.Contains(UserWidget))
					{
						OutArr.Add(UserWidget);
					}
				}
			}

			int32 End = OutArr.Num();
			for (int32 I = Start; I < End; ++I)
			{
				GatherAllWBP_R(OutArr[I], OutArr);
			}
		}
	}
}

TArray<UUserWidget*> UUIFunctionLibrary::GatherAllWBP(UUserWidget* Widget)
{
	TArray<UUserWidget*> Result;
	if (Widget && Widget->WidgetTree)
	{
		GatherAllWBP_R(Widget, Result);
	}
	return Result;
}

FRuntimeFloatCurve UUIFunctionLibrary::GetDynamicFloatCurve(float OffsetX, float OffsetY, float Tangent)
{
	FRuntimeFloatCurve DynamicCurve;
	FKeyHandle FirstPointHandle = DynamicCurve.EditorCurveData.AddKey(0, 0);
	DynamicCurve.EditorCurveData.SetKeyInterpMode(FirstPointHandle, ERichCurveInterpMode::RCIM_Cubic);
	DynamicCurve.EditorCurveData.SetKeyTangentMode(FirstPointHandle, ERichCurveTangentMode::RCTM_User);
	DynamicCurve.EditorCurveData.SetKeyTangentWeightMode(FirstPointHandle, ERichCurveTangentWeightMode::RCTWM_WeightedNone);
	DynamicCurve.EditorCurveData.GetKey(FirstPointHandle).ArriveTangent = Tangent;
	DynamicCurve.EditorCurveData.GetKey(FirstPointHandle).LeaveTangent= Tangent;
	FKeyHandle MiddlePointHandle = DynamicCurve.EditorCurveData.AddKey(120, -50);
	DynamicCurve.EditorCurveData.SetKeyInterpMode(MiddlePointHandle, ERichCurveInterpMode::RCIM_Cubic);
	DynamicCurve.EditorCurveData.SetKeyTangentMode(MiddlePointHandle, ERichCurveTangentMode::RCTM_User);
	DynamicCurve.EditorCurveData.SetKeyTangentWeightMode(MiddlePointHandle, ERichCurveTangentWeightMode::RCTWM_WeightedNone);
	DynamicCurve.EditorCurveData.GetKey(MiddlePointHandle).ArriveTangent = 0;
	DynamicCurve.EditorCurveData.GetKey(MiddlePointHandle).LeaveTangent = 0;
	FKeyHandle LastPointHandle = DynamicCurve.EditorCurveData.AddKey(OffsetX, OffsetY);
	DynamicCurve.EditorCurveData.SetKeyInterpMode(LastPointHandle, ERichCurveInterpMode::RCIM_Cubic);
	DynamicCurve.EditorCurveData.SetKeyTangentMode(LastPointHandle, ERichCurveTangentMode::RCTM_User);
	DynamicCurve.EditorCurveData.SetKeyTangentWeightMode(LastPointHandle, ERichCurveTangentWeightMode::RCTWM_WeightedNone);
	DynamicCurve.EditorCurveData.GetKey(LastPointHandle).ArriveTangent = Tangent;
	DynamicCurve.EditorCurveData.GetKey(LastPointHandle).LeaveTangent = Tangent;
	return DynamicCurve;
}

void UUIFunctionLibrary::ReleaseAllPointerCapture() 
{
	FSlateApplication::Get().ReleaseAllPointerCapture();
}

int64 UUIFunctionLibrary::GetUtcSecond()
{
	FDateTime Current = FDateTime::UtcNow();
	int64 DeltaTicks = Current.GetTicks() - FDateTime(1970, 1, 1).GetTicks();

	return DeltaTicks / ETimespan::TicksPerSecond;
}

void UUIFunctionLibrary::SetZOrder(UUserWidget* UserWidget, int Order)
{
	if(UserWidget)
	{
		if (UCanvasPanelSlot* Slot = Cast<UCanvasPanelSlot>(UserWidget->Slot))
		{
			Slot->SetZOrder(Order);
		}
		else
		{
			if (UPanelSlot* PanelSlot = Cast<UPanelSlot>(UserWidget->Slot))
			{
				TObjectPtr<class UPanelWidget> Parent = PanelSlot->Parent;
				if (UCanvasPanelSlot* ParentSlot = Cast<UCanvasPanelSlot>(Parent->Slot))
				{
					ParentSlot->SetZOrder(Order);
				}
			}
		}
		
		return;
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::SetZOrder => UserWidget is nullptr"));
}

void UUIFunctionLibrary::SetCanCache(UUserWidget* UserWidget)
{
	if (UserWidget)
	{
		if (UCanvasPanelSlot* Slot = Cast<UCanvasPanelSlot>(UserWidget->Slot))
		{
			return;
		}
		else
		{
			if (UPanelSlot* PanelSlot = Cast<UPanelSlot>(UserWidget->Slot))
			{
				TObjectPtr<class UPanelWidget> Parent = PanelSlot->Parent;
				if (UInvalidationBox* Box = Cast<UInvalidationBox>(Parent))
				{
					Box->InvalidateRootChildOrder();
				}
			}
			return;
		}
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::SetCanCache => UserWidget is nullptr"));
}

UTextureRenderTarget2D* UUIFunctionLibrary::NewRenderTarget2d(UWorld* World,FVector2D& Size)
{
	if(World)
	{
		FName CustomName = MakeUniqueObjectName(World, UTextureRenderTarget2D::StaticClass(), TEXT("C7_UI_RT"));
		UTextureRenderTarget2D* RT = NewObject<UTextureRenderTarget2D>(World, *CustomName.ToString(), RF_Transient);
		RT->RenderTargetFormat = RTF_RGBA8_SRGB;
		RT->InitAutoFormat(Size.X, Size.Y);
		RT->UpdateResourceImmediate(true);
		return RT;
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::NewRenderTarget2d => World is nullptr"));
	return nullptr;
}

TArray<UKGListObjectItem*> UUIFunctionLibrary::GetListObject(UObject* Outer, int Count)
{
	TArray<UKGListObjectItem*> OutArray;
	if(Outer)
	{
		if (Count > 0)
		{
			for (int32 i = 1; i <= Count; ++i)
			{
				UKGListObjectItem* Obj = NewObject<UKGListObjectItem>(Outer);
				Obj->Index = i;
				OutArray.Add(Obj);
			}
			return OutArray;
		}
		UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::GetListObject => Count is less then 0 %d"), Count);
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::GetListObject => Outer is nullptr"));
	return OutArray;
}

UWidget* UUIFunctionLibrary::DeepDuplicateWidget(UWidget* pUWidget, UObject* Outer)
{
	if(pUWidget)
	{
		if(Outer)
		{
			UWidget* pNewWidget = DuplicateObject<UWidget>(pUWidget, Outer);
			UPanelWidget* pNewUPanelWidget = Cast<UPanelWidget>(pNewWidget);
			if (pNewUPanelWidget)
			{
				for (int ii = 0; ii < pNewUPanelWidget->GetChildrenCount(); ++ii)
				{
					UWidget* pChildUWidget = pNewUPanelWidget->GetChildAt(ii);
					UWidget* pNewChildWidget = DeepDuplicateWidget(pChildUWidget, pNewWidget);
					int32 nIndex = pNewUPanelWidget->GetChildIndex(pChildUWidget);

					if (nIndex != -1)
					{
						pNewUPanelWidget->ReplaceChildAt(nIndex, pNewChildWidget);
					}
				}
			}

			return pNewWidget;
		}
		UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::DeepDuplicateWidget => Outer is nullptr"));
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::DeepDuplicateWidget => pUWidget is nullptr"));
	return nullptr;
}

UWidget* UUIFunctionLibrary::FindWidget(UWidget* Widget, const FName& Name)
{
	if (Widget == nullptr)
	{
		return nullptr;
	}
	if (Widget->GetFName() == Name)
	{
		return Widget;
	}
	if (auto UserWidget = Cast<UUserWidget>(Widget))
	{
		return FindWidget(UserWidget->GetRootWidget(), Name);
	}
	else if (auto PanelWidget = Cast<UPanelWidget>(Widget))
	{
		for (int Index = 0; Index < PanelWidget->GetChildrenCount(); ++Index)
		{
			UWidget* ChildWidget = PanelWidget->GetChildAt(Index);
			if (auto Found = FindWidget(ChildWidget, Name))
			{
				return Found;
			}
		}
	}
	return nullptr;
}

UWidget* UUIFunctionLibrary::C7CreateWidget(UUserWidget* UserWidget, UPanelWidget* Parent, UWidget* Widget)
{
	if(UserWidget)
	{
		if(Widget)
		{
			if(Parent)
			{
				UUserWidget* pNewUUserWidget = Cast<UUserWidget>(Widget);
				UWidget* newWidget;
				if (pNewUUserWidget)
				{
					newWidget = UserWidget->CreateWidgetInstance(*UserWidget, Widget->GetClass(), NAME_None);
				}
				else
				{
					newWidget = UUIFunctionLibrary::DeepDuplicateWidget(Widget, UserWidget);
				}
				AddChild(Parent, newWidget);
				newWidget->SetVisibility(ESlateVisibility::Visible);
				return newWidget;
			}
			UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::C7CreateWidget => Parent is nullptr"));
		}
		UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::C7CreateWidget => Widget is nullptr"));
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::C7CreateWidget => UserWidget is nullptr"));
	return nullptr;
}

bool UUIFunctionLibrary::ReplaceChild(UPanelWidget* Parent, UWidget* CurrentChild, UWidget* NewChild)
{
	if(Parent)
	{
		if(CurrentChild)
		{
			if(NewChild)
			{
				int32 Index = Parent->GetChildIndex(CurrentChild);
				if (Index != -1)
				{
					return Parent->ReplaceChildAt(Index, NewChild);
				}
				return false;
			}
			UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::ReplaceChild => NewChild is nullptr"));
		}
		UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::ReplaceChild => CurrentChild is nullptr"));
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::ReplaceChild => Parent is nullptr"));
	return false;
}

UPanelSlot* UUIFunctionLibrary::AddChild(UPanelWidget* Parent, UWidget* Content)
{
	if(Parent)
	{
		if (Content)
		{
			if (Parent->IsA<UCanvasPanel>())
			{
				if(UCanvasPanel* Panel = Cast<UCanvasPanel>(Parent))
				{
					UCanvasPanelSlot* NewSlot = Panel->AddChildToCanvas(Content);
					NewSlot->SetAnchors(FAnchors(0, 0, 1, 1));
					NewSlot->SetOffsets(FMargin());
					return NewSlot;
				}
			}
			UPanelSlot* NewSlot = Parent->AddChild(Content);
			return NewSlot;
		}
		UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::InsertChildAt => Content is nullptr"));
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::InsertChildAt => Parent is nullptr"));
	return nullptr;
}


void UUIFunctionLibrary::ShiftChild(UPanelWidget* Parent, int32 Index, UWidget* Child)
{
	if (Parent)
	{
		if(Child)
		{
			int32 CurrentIndex = Parent->GetChildIndex(Child);
			auto Slots = Parent->GetSlots();
			Slots.RemoveAt(CurrentIndex);
			if (Index > Slots.Num())
			{
				Slots.Add(Child->Slot);
			}
			else
			{
				Slots.Insert(Child->Slot, FMath::Clamp(Index, 0, Slots.Num()));
			}
			Parent->InvalidateLayoutAndVolatility();
			return;
		}
		UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::ShiftChild => Child is nullptr"));
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::ShiftChild => Parent is nullptr"));
}

void UUIFunctionLibrary::SwapChild(UPanelWidget* Parent, int32 Index1, int32 Index2)
{
	if (Parent)
	{
		if (Index1 >=0)
		{
			if (Index2 >= 0)
			{
				Parent->SwapChild(Index1, Index2);
				return;
			}
			UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::SwapChild => Index2 is less then 0"));
		}
		UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::SwapChild => Index1 is less then 0"));
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::SwapChild => Parent is nullptr"));
}

void UUIFunctionLibrary::RemoveChild(UPanelWidget* Parent, int32 Index)
{
	if(Parent)
	{
		auto Slots = Parent->GetSlots();
		if(Index < 0 || Index >= Slots.Num())
		{
			UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::RemoveChild => Index is out of range %d"), Index);
			return;
		}
		Parent->RemoveChildAt(Index);
		return;
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::RemoveChild => Parent is nullptr"));
}

UWidget* UUIFunctionLibrary::GetWidgetFromName(UUserWidget* UserWidget, const FName& Name)
{
	if(UserWidget)
	{
		return UserWidget->GetWidgetFromName(Name);
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::GetWidgetFromName => UserWidget is nullptr"));
	return nullptr;
}

UWidget* UUIFunctionLibrary::GetRootWidget(UUserWidget* UserWidget)
{
	if (UserWidget)
	{
		return UserWidget->GetRootWidget();
	}
	UE_LOG(LogTemp, Warning, TEXT("UUIFunctionLibrary::GetRootWidget => UserWidget is nullptr"));
	return nullptr;
}

#if WITH_EDITOR
EDPIScalePreviewPlatforms UUIFunctionLibrary::GetPreviewPlatform()
{
	const  UKGUIPlatformCustomSetting* C7DPISettings = GetDefault<UKGUIPlatformCustomSetting>();
	if (C7DPISettings!= nullptr)
	{
		return C7DPISettings->EditorPreviewPlatform;
	}
	return EDPIScalePreviewPlatforms::PC;
}
#endif
//临时处理，分辨率变化时强制刷新渲染器，以后要改方案
void UUIFunctionLibrary::FlushRenderState()
{
	FSlateApplication::Get().FlushRenderState();
}

// 获取在2D屏幕的朝向角度
double UUIFunctionLibrary::DotProductWithForward2D(const FVector2D& InDirection)
{
	const auto Normal = UKismetMathLibrary::Normal2D(InDirection);
	auto Dot = UKismetMathLibrary::DotProduct2D(Normal, FVector2D(1, 0));
	auto Result = UKismetMathLibrary::DegAcos(Dot);
	if (Normal.Y < 0)
	{
		Result = 0 - Result;
	}
	return Result;
}

float UUIFunctionLibrary::Size2DBetweenActorAndAnchor(AActor* InActor, const FVector& InAnchorPoint)
{
	if (!InActor)
	{
		return 0;
	}
	auto ActorPosition = InActor->GetActorLocation();
	auto Result = (ActorPosition - InAnchorPoint).Size2D();
	return Result;
}

// 计算3D空间下Actor距离特定位置的距离
float UUIFunctionLibrary::DistanceBetweenActorAndAnchor(AActor* InActor, float X, float Y, float Z)
{
	if (!InActor)
	{
		return 0;
	}
	auto ActorPosition = InActor->GetActorLocation();
	return UKismetMathLibrary::Vector_Distance(ActorPosition, FVector(X,Y,Z));
}

// 计算3D空间下Actor距离另一个Actor的距离
float UUIFunctionLibrary::DistanceBetweenActorAndActor(AActor* InActor, AActor* InActor2)
{
	if (!InActor || !InActor2)
	{
		return 0;
	}
	auto ActorPosition = InActor->GetActorLocation();
	auto ActorPosition2 = InActor2->GetActorLocation();
	return UKismetMathLibrary::Vector_Distance(ActorPosition, ActorPosition2);
}

UDragDropOperation* UUIFunctionLibrary::CreateDrag(UWidget* DefaultDragVisual, TSubclassOf<UDragDropOperation> Operation)
{
	if (!DefaultDragVisual)
		return nullptr;
	UDragDropOperation* DragDropOperation = nullptr;
	if (Operation)
	{
		DragDropOperation = NewObject<UDragDropOperation>(GetTransientPackage(), Operation);
	}
	else
	{
		DragDropOperation = NewObject<UDragDropOperation>();
	}

	DragDropOperation->DefaultDragVisual = DefaultDragVisual;
	return DragDropOperation;
}

UUserWidget* UUIFunctionLibrary::InstanceBP(UUserWidget* SrcWidget) {
	UUserWidget* Result = nullptr;
	if (SrcWidget) {
		UUserWidget* pNewUUserWidget = Cast<UUserWidget>(SrcWidget);
		if (pNewUUserWidget)
		{
			Result = CreateWidget<UUserWidget>(SrcWidget, SrcWidget->GetClass());
			//UserWidget->CreateWidgetInstance(*UserWidget, Widget->GetClass(), NAME_None);
			//newWidget->SetVisibility(ESlateVisibility::Visible);
		}
	}
	return Result;
}

UUserWidget* UUIFunctionLibrary::CreateWidgetWithName(UObject* WorldContextObject, TSubclassOf<UUserWidget> WidgetType, FName WidgetName)
{
	if (WidgetName == "Name_None")
	{
		WidgetName = NAME_None;
	}
	if (UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull))
	{
		return CreateWidget(World, WidgetType, WidgetName);
	}
	return nullptr;
}

UUserWidget* UUIFunctionLibrary::CreateWidgetWithID(UObject* WorldContextObject, int64 InID)
{
	UClass* WidgetClass = Cast<UClass>(KGUtils::GetObjectByID(InID));
	if (WidgetClass && WidgetClass->IsChildOf(UUserWidget::StaticClass()))
	{
		return UWidgetBlueprintLibrary::Create(WorldContextObject, WidgetClass, nullptr);
	}
	return nullptr;
}

void UUIFunctionLibrary::OpenConsole() {
	if (GEngine && GEngine->GameViewport && GEngine->GameViewport->ViewportConsole) {
		GEngine->GameViewport->ViewportConsole->StartTyping("");
	}
}

int UUIFunctionLibrary::GetObjectArrayNum()
{
	return GUObjectArray.GetObjectArrayNum();
}

UTexture* UUIFunctionLibrary::GetTextureInst(const FString& path){
	FSoftObjectPath TextureRef(path);
	UObject* LoadedObj = TextureRef.TryLoad();
	UTexture* Texture = Cast<UTexture>(LoadedObj);

	return Texture;
}

void UUIFunctionLibrary::SaveStringToFile(const FString FFileName,	const FString Content)
{
	FString FileName = FPaths::Combine(FPaths::ProjectLogDir(), FFileName);
	FFileHelper::SaveStringToFile(Content, *FileName, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_Append);
}

FColor UUIFunctionLibrary::GetTextureColorAt(UTexture2D* InTex, const float CoordX,const float CoordY)
{
	FColor PixelColor(ForceInit);
	if (IsValid(InTex))
	{
		if (InTex->CompressionSettings!= TextureCompressionSettings::TC_VectorDisplacementmap)
		{
			return PixelColor;
		}
		if ( InTex->GetPlatformData()->Mips[0].BulkData.IsUnlocked())
		{
			const FColor* FormatedImageData = static_cast<const FColor*>( InTex->GetPlatformData()->Mips[0].BulkData.LockReadOnly());
			if(FormatedImageData)
			{
				const int64 X = FMath::FloorToInt64(CoordX * InTex->GetPlatformData()->Mips[0].SizeX);
				const int64 Y = FMath::FloorToInt64(CoordY * InTex->GetPlatformData()->Mips[0].SizeY);
	
				int64 idx =Y * InTex->GetPlatformData()->Mips[0].SizeX + X;
				UE_LOG(LogTemp,Log,TEXT("GetTextureColorAt CoordX:%.4f CorrdY:%.4f X:%lld Y:%lld  idx:%lld  MaxNum:%lld"),CoordX,CoordY,X,Y,idx,InTex->GetPlatformData()->Mips[0].BulkData.GetElementCount())
				idx = FMath::Clamp(idx,0,InTex->GetPlatformData()->Mips[0].BulkData.GetElementCount()-1);
				PixelColor = FormatedImageData[idx];
			}
			InTex->GetPlatformData()->Mips[0].BulkData.Unlock();
		}
	}
	return PixelColor;
}

void UUIFunctionLibrary::ReplaceWidgetWithNode(UPanelWidget* SourceNode, UPanelWidget* TargetNode)
{
	UPanelWidget* ParentNode = SourceNode->GetParent();
	const int32 SourceNodeIndex = ParentNode->GetChildIndex(SourceNode);
	auto ChildrenList = SourceNode->GetAllChildren();
	for (auto const ChildNode:ChildrenList)
	{
		ChildNode->RemoveFromParent();
		TargetNode->AddChild(ChildNode);
	}
	SourceNode->RemoveFromParent();
	// ParentNode->InsertChildAt(SourceNodeIndex, TargetNode);
	ParentNode->AddChild(TargetNode);
}

FString UUIFunctionLibrary::GetDeviceTypeName()
{
	return UDeviceProfileManager::Get().GetActiveDeviceProfileName();
}

ADirectionalLight* UUIFunctionLibrary::GetDirectionalLight1(UWorld* World)
{
	if (!World)
	{
		UE_LOG(LogTemp,Log,TEXT("In World is nullptr."));
		return nullptr;
	}
	ADirectionalLight* DirectionalLight = nullptr;
	for (TActorIterator<ADirectionalLight> It(World); It; ++It)
	{
		DirectionalLight = *It;
		break;
	}
    
	if (DirectionalLight)
	{
		return DirectionalLight;
	}
	return nullptr;
}

FVector2D UUIFunctionLibrary::GetMousePositionOnPlatform()
{
	if (FSlateApplication::IsInitialized())
	{
		if (FSlateApplication::Get().IsFakingTouchEvents())
		{
			return FSlateApplication::Get().GetPlatformApplication()->Cursor->GetPosition();
		}
		return FSlateApplication::Get().GetCursorPos();
	}

	return FVector2D(0, 0);
}

void UUIFunctionLibrary::MarkActorComponentRenderStateDirty(UActorComponent* ActorComponent)
{
	if (ActorComponent)
	{
		ActorComponent->MarkRenderStateDirty();
	}
}

void UUIFunctionLibrary::MarkComponentsRenderStateDirty(AActor* Actor)
{
	if (Actor)
	{
		Actor->MarkComponentsRenderStateDirty();
	}
}

bool UUIFunctionLibrary::CopyToClipBoard(const FString& CopyText)
{
	if( !CopyText.IsEmpty() )
	{
		FPlatformApplicationMisc::ClipboardCopy( *CopyText );
		return true;
	}
	return false;
}

FString UUIFunctionLibrary::PasteFromClipboard()
{
	FString PastedText;
	FPlatformApplicationMisc::ClipboardPaste(PastedText);
	return PastedText;
}

#if WITH_EDITOR
TArray<FKGPaperSpriteAtlasInfo> UUIFunctionLibrary::GetAllSpriteAssets()
{
	// AssetRegistryModule
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");

	// AssetData
	TArray<FAssetData> AssetData;

	// 
	FARFilter Filter;
	FTopLevelAssetPath AtlasClassPath("/Script/Paper2D", "PaperSpriteAtlas");

	Filter.ClassPaths.Add(AtlasClassPath);
	TArray<FKGPaperSpriteAtlasInfo> AtlasStatDataList;
	// 
	AssetRegistryModule.Get().GetAssets(Filter, AssetData);

	// 
	for (const FAssetData& Asset : AssetData)
	{
		// 
		FString AssetPath = Asset.GetObjectPathString();

		//  Sprite Atlas 
		UPaperSpriteAtlas* SpriteAtlas = LoadObject<UPaperSpriteAtlas>(nullptr, *AssetPath, nullptr, LOAD_None, nullptr);

		if (SpriteAtlas)
		{
			FKGPaperSpriteAtlasInfo AtlasStatData;
			AtlasStatData.Size = SpriteAtlas->GetResourceSizeBytes(EResourceSizeMode::EstimatedTotal);
			AtlasStatData.Name = SpriteAtlas->GetName();
			AtlasStatData.Width = SpriteAtlas->MaxWidth;
			AtlasStatData.Height = SpriteAtlas->MaxHeight;
			AtlasStatData.AssetPath = AssetPath;
			AtlasStatData.PaperSpriteData = UUIFunctionLibrary::GetAtlasTextureSize(SpriteAtlas);
			AtlasStatDataList.Add(AtlasStatData);
			//  SpriteAtlas 
			FString AtlasName = SpriteAtlas->GetName();
			UE_LOG(LogTemp, Warning, TEXT("Sprite Atlas Name: %s"), *AtlasName);
		}
	}
	return AtlasStatDataList;
}

int64 UUIFunctionLibrary::GetSprintAssetsGroupSize(UPaperSpriteAtlas* SpriteAtlas)
{
	return  SpriteAtlas->GetResourceSizeBytes(EResourceSizeMode::EstimatedTotal);
}

TArray<FKGPaperSpriteInfo> UUIFunctionLibrary::GetAtlasTextureSize(UPaperSpriteAtlas* SpriteAtlas)
{
	TArray<FKGPaperSpriteInfo> AtlasDataArray;

	TArray<FPaperSpriteAtlasSlot>& AtlasSlots = SpriteAtlas->AtlasSlots;
	for (int32 SlotIndex = 0; SlotIndex < AtlasSlots.Num(); ++SlotIndex)
	{
		FPaperSpriteAtlasSlot& AtlasSlot = AtlasSlots[SlotIndex];
		UPaperSprite* Sprite = Cast<UPaperSprite>(StaticLoadObject(UPaperSprite::StaticClass(), nullptr, *AtlasSlot.SpriteRef.ToString(), nullptr, LOAD_None, nullptr));
		if (Sprite)
		{
			// 
			FName PackageName = FName(*Sprite->GetOutermost()->GetName());

			// 
			FString AssetPath = FPackageName::LongPackageNameToFilename(PackageName.ToString(), FPackageName::GetAssetPackageExtension());

				// 
			IFileManager& FileManager = IFileManager::Get();
			int64 FileSize = FileManager.FileSize(*AssetPath);
			FKGPaperSpriteInfo PaperSpriteData;
			PaperSpriteData.PathName = *PackageName.ToString();
			PaperSpriteData.Size = FileSize;
			PaperSpriteData.Width = AtlasSlot.Width;
			PaperSpriteData.Height = AtlasSlot.Height;
			// 
			AtlasDataArray.Add(PaperSpriteData);
		}
		// UE_LOG(LogTemp, Error, TEXT("Get Sprite Assets Group Sub Texture Name %s size:%lld."), ad.TexturePath, ad.Size);
	}
	return AtlasDataArray;
}

EMaskDetectResult UUIFunctionLibrary::IsMaskTexture(UTexture2D* Texture)
{
	if (!Texture)
		return EMaskDetectResult::NotValid;

	FTextureSource& Source = Texture->Source;
	if (!Source.IsValid())
		return EMaskDetectResult::NotValid;

	const ETextureSourceFormat SrcFormat = Source.GetFormat();

	const int32 Width = Source.GetSizeX();
	const int32 Height = Source.GetSizeY();
	const int32 NumPixels = Width * Height;

	if (NumPixels <= 0)
		return EMaskDetectResult::NotValid;

	// 如果是单通道，直接通过
	if (SrcFormat == TSF_G8)
		return EMaskDetectResult::Mask8Bit;

	if (SrcFormat == TSF_G16)
		return EMaskDetectResult::Mask16Bit;

	// 如果是rgba, 就考虑rgba都一样 或者rgb一样且alpha全是0或1
	const uint8* Data = Source.LockMipReadOnly(0);

	const int32 Tol8 = 1;
	const int32 Tol16 = 256;

	EMaskDetectResult Result = EMaskDetectResult::NotValid;

	switch (SrcFormat)
	{
	case TSF_BGRA8:
	{
		const int32 BytesPerPixel = 4;

		bool bRGBAEqual = true;
		bool bRGBEqual = true;
		bool bAllAZero = true;
		bool bAllAOne = true;

		for (int32 i = 0; i < NumPixels; i += 1)
		{
			const int32 idx = i * BytesPerPixel;

			uint8 B = Data[idx + 0];
			uint8 G = Data[idx + 1];
			uint8 R = Data[idx + 2];
			uint8 A = Data[idx + 3];

			if (!(FMath::Abs(int32(R) - int32(G)) <= Tol8 &&
				FMath::Abs(int32(R) - int32(B)) <= Tol8))
			{
				bRGBEqual = false;
			}

			if (!(FMath::Abs(int32(R) - int32(G)) <= Tol8 &&
				FMath::Abs(int32(R) - int32(B)) <= Tol8 &&
				FMath::Abs(int32(R) - int32(A)) <= Tol8))
			{
				bRGBAEqual = false;
			}

			if (!(A <= Tol8))
				bAllAZero = false;

			if (!(FMath::Abs(int32(A) - 255) <= Tol8))
				bAllAOne = false;

			if (!bRGBAEqual && !bRGBEqual && !bAllAZero && !bAllAOne)
			{
				Source.UnlockMip(0);
				return EMaskDetectResult::NotMask;
			}
		}

		bool bCaseA = bRGBAEqual;
		bool bCaseB = bRGBEqual && (bAllAZero || bAllAOne);

		Result = (bCaseA || bCaseB) ? EMaskDetectResult::Mask8Bit : EMaskDetectResult::NotMask;
	}
	break;


	case TSF_RGBA16:
	{
		const uint16* Data16 = reinterpret_cast<const uint16*>(Data);
		const int32 Channels = 4;

		bool bRGBAEqual = true;
		bool bRGBEqual = true;
		bool bAllAZero = true;
		bool bAllAOne = true;

		for (int32 i = 0; i < NumPixels; i += 1)
		{
			const int32 idx = i * Channels;

			uint16 R16 = Data16[idx + 0];
			uint16 G16 = Data16[idx + 1];
			uint16 B16 = Data16[idx + 2];
			uint16 A16 = Data16[idx + 3];

			if (!(FMath::Abs(int32(R16) - int32(G16)) <= Tol16 &&
				FMath::Abs(int32(R16) - int32(B16)) <= Tol16))
			{
				bRGBEqual = false;
			}

			if (!(FMath::Abs(int32(R16) - int32(G16)) <= Tol16 &&
				FMath::Abs(int32(R16) - int32(B16)) <= Tol16 &&
				FMath::Abs(int32(R16) - int32(A16)) <= Tol16))
			{
				bRGBAEqual = false;
			}

			if (!(A16 <= Tol16))
				bAllAZero = false;

			if (!(FMath::Abs(int32(A16) - 65535) <= Tol16))
				bAllAOne = false;

			if (!bRGBAEqual && !bRGBEqual && !bAllAZero && !bAllAOne)
			{
				Source.UnlockMip(0);
				return EMaskDetectResult::NotMask;
			}
		}

		bool bCaseA = bRGBAEqual;
		bool bCaseB = bRGBEqual && (bAllAZero || bAllAOne);

		Result = (bCaseA || bCaseB) ? EMaskDetectResult::Mask16Bit : EMaskDetectResult::NotMask;
	}
	break;

	default:
		Source.UnlockMip(0);
		UE_LOG(LogTemp, Warning,
			TEXT("[IsMaskTexture] %s: Unsupported SourceFormat %d, not a mask."),
			*Texture->GetName(), (int32)SrcFormat);
		return EMaskDetectResult::UnsupportedFormat;
	}

	Source.UnlockMip(0);
	return Result;
}

#endif

bool  UUIFunctionLibrary::IsAtlasLoaded(const FString& AtlasPath)
{

	// 尝试加载 PaperSpriteAtlas 对象
	UPaperSpriteAtlas* LoadedAtlas = LoadObject<UPaperSpriteAtlas>(nullptr, *AtlasPath);

	// 如果加载成功，说明 PaperSpriteAtlas 尚未卸载
	if (LoadedAtlas)
	{
		//LoadedAtlas->ConditionalBeginDestroy();
		return true;
	}
	// 如果加载失败，说明 PaperSpriteAtlas 已经卸载
	else
	{
		return false;
	}
}

int64 UUIFunctionLibrary::GetTextureSize(UTexture* Texture)
{
	return Texture->GetResourceSizeBytes(EResourceSizeMode::Exclusive);
}


TArray<UTexture*> UUIFunctionLibrary::GetWidgetTexture(UUserWidget* UserWidgetInstance)
{
	TArray<UTexture*> textureArray;
	if (!UserWidgetInstance)
	{
		//  Widget 
		return textureArray;
	}

	//  WidgetTree
	UWidgetTree* WidgetTree = UserWidgetInstance->WidgetTree;

	if (!WidgetTree)
	{
		//  WidgetTree
		return textureArray;
	}

	//  WidgetTree 
	TArray<UWidget*> Widgets;
	WidgetTree->GetAllWidgets(Widgets);
	for (UWidget* Widget : Widgets)
	{
		//  UImage 
		UKGImage* ImageControl = Cast<UKGImage>(Widget);
		UTexture* ImageTexture = nullptr;
		if (ImageControl && ImageControl->GetBrush().GetResourceObject())
		{
			//  UImage 
			ImageTexture = Cast<UTexture>(ImageControl->GetBrush().GetResourceObject());
		}
		else 
		{
			UKGButton* ButtonControl = Cast<UKGButton>(Widget);
			if (ButtonControl)
			{
				// 
				const FSlateBrush& NormalBrush = ButtonControl->GetStyle().Normal;
				ImageTexture = Cast<UTexture>(NormalBrush.GetResourceObject());

			}
			else
			{
				UImage* ImageControl2 = Cast<UImage>(Widget);
				if (ImageControl2)
				{
					// 
					ImageTexture = Cast<UTexture>(ImageControl2->GetBrush().GetResourceObject());
				}
			}
		}
		if (ImageTexture)
		{
			// 
			FString ImagePath = ImageTexture->GetPathName();
			textureArray.Add(ImageTexture);
		}
	}
	return textureArray;
}

TArray<UPaperSprite*> UUIFunctionLibrary::GetWidgetPaperSprite(UUserWidget* UserWidgetInstance)
{
	TArray<UPaperSprite*> textureArray;
	if (!UserWidgetInstance)
	{
		//  Widget 
		return textureArray;
	}

	//  WidgetTree
	UWidgetTree* WidgetTree = UserWidgetInstance->WidgetTree;

	if (!WidgetTree)
	{
		//  WidgetTree
		return textureArray;
	}

	//  WidgetTree 
	TArray<UWidget*> Widgets;
	WidgetTree->GetAllWidgets(Widgets);
	for (UWidget* Widget : Widgets)
	{
		//  UImage 
		UKGImage* ImageControl = Cast<UKGImage>(Widget);
		UPaperSprite* PaperSprite = nullptr;
		if (ImageControl && ImageControl->GetBrush().GetResourceObject())
		{
			//  UImage 
			PaperSprite = Cast<UPaperSprite>(ImageControl->GetBrush().GetResourceObject());
		}
		else
		{
			UKGButton* ButtonControl = Cast<UKGButton>(Widget);
			if (ButtonControl)
			{
				// 
				const FSlateBrush& NormalBrush = ButtonControl->GetStyle().Normal;
				PaperSprite = Cast<UPaperSprite>(NormalBrush.GetResourceObject());

			}
			else
			{
				UImage* ImageControl2 = Cast<UImage>(Widget);
				if (ImageControl2)
				{
					// 
					PaperSprite = Cast<UPaperSprite>(ImageControl2->GetBrush().GetResourceObject());
				}
			}
		}
		if (PaperSprite)
		{
			FString ImagePath = PaperSprite->GetPathName();
			textureArray.Add(PaperSprite);
		}
		UUserWidget* UserWidget = Cast<UUserWidget>(Widget);
		if (UserWidget)
		{
			textureArray.Append(GetWidgetPaperSprite(UserWidget));
		}
	}
	return textureArray;
}

FString UUIFunctionLibrary::GetAppAbsolutePath(FString filePath)
{
	return IFileManager::Get().ConvertToAbsolutePathForExternalAppForWrite(*filePath);
}

void UUIFunctionLibrary::GetAllAutoAnimationInfo(UUserWidget* WidgetRoot, float& MaxInTime, float& MaxOutTime, TArray<UUserWidget*>& AnimationInList, TArray<UUserWidget*>& AnimationOutList)
{
// #if WITH_EDITOR
	if (!WidgetRoot)
	{
		return;
	}
	FString AutoAnimationInName = "Ani_Fadein";
	FString AutoAnimationOutName = "Ani_Fadeout";

	// 处理根节点蓝图动效
	UWidgetBlueprintGeneratedClass* BPRootGeneratedClass = WidgetRoot->GetWidgetTreeOwningClass();
	if (BPRootGeneratedClass)
	{
		for (int32 i = 0; i < BPRootGeneratedClass->Animations.Num(); i++)
		{
			TObjectPtr<UWidgetAnimation> Animation = BPRootGeneratedClass->Animations[i];
			if (Animation->GetMovieScene()->GetName() == AutoAnimationInName)
			{
				float EndTime = Animation->GetEndTime();
				if (EndTime > MaxInTime)
				{
					MaxInTime = EndTime;
				}
				AnimationInList.Add(WidgetRoot);
			}
			
			if (Animation->GetMovieScene()->GetName() == AutoAnimationOutName)
			{
				float EndTime = Animation->GetEndTime();
				if (EndTime > MaxOutTime)
				{
					MaxOutTime = EndTime;
				}
				AnimationOutList.Add(WidgetRoot);
			}
		}
	}
	bool ContainChildAnimIn = AnimationInList.Num() == 0;		//是否播放子蓝图入场动画
	bool ContainChildAnimOut = AnimationOutList.Num() == 0;		//是否播放子蓝图出场动画
	if(!ContainChildAnimIn && !ContainChildAnimOut)		//如果根节点有入场/出场动画 则忽略子蓝图对应的入场/出场动画
	{
		return;
	}

	// 遍历子节点蓝图动效
	TObjectPtr<UWidgetTree> WBPWidgetTree = WidgetRoot->WidgetTree;
	TArray<UWidget*> Widgets;
	if (WBPWidgetTree)
	{
		WBPWidgetTree->GetAllWidgets(Widgets);
		for (int32 Index = 0; Index < Widgets.Num(); ++Index)
		{
			UWidget* CWidget = Widgets[Index];
			if (CWidget == nullptr)
			{
				continue;
			}
			if (UUserWidget* UserWidget = Cast<UUserWidget>(CWidget))
			{
				UWidgetBlueprintGeneratedClass* BPGeneratedClass = UserWidget->GetWidgetTreeOwningClass();
				if (BPGeneratedClass)
				{
					for (int32 i = 0; i < BPGeneratedClass->Animations.Num(); i++)
					{
						TObjectPtr<UWidgetAnimation> Animation = BPGeneratedClass->Animations[i];
						if (ContainChildAnimIn && Animation->GetMovieScene()->GetName() == AutoAnimationInName)
						{
							float EndTime = Animation->GetEndTime();
							if (EndTime > MaxInTime)
							{
								MaxInTime = EndTime;
							}
							AnimationInList.Add(UserWidget);
						}

						if (ContainChildAnimOut && Animation->GetMovieScene()->GetName() == AutoAnimationOutName)
						{
							float EndTime = Animation->GetEndTime();
							if (EndTime > MaxOutTime)
							{
								MaxOutTime = EndTime;
							}
							AnimationOutList.Add(UserWidget);
						}
					}
				}
			}
		}
	}
// #endif
}

double UUIFunctionLibrary::GetFTimespanTotalSeconds(FTimespan Timespan)
{
	return Timespan.GetTotalSeconds();
}

int UUIFunctionLibrary::GetBatteryLevel()
{
#if PLATFORM_IOS
	return FIOSPlatformMisc::GetBatteryLevel();
#elif PLATFORM_ANDROID
	return FAndroidMisc::GetBatteryLevel();
#endif
	return 0;
}

bool UUIFunctionLibrary::IsRunningOnBattery()
{
#if PLATFORM_IOS
	return FIOSPlatformMisc::IsRunningOnBattery();
#elif PLATFORM_ANDROID
	return FAndroidMisc::IsRunningOnBattery();
#endif
	return false;
}

//begin add by tangzhangpeng@kuaishou.com[get battery state interface]
int32 UUIFunctionLibrary::GetBatteryStateID()
{
#if PLATFORM_IOS
	//https://developer.apple.com/documentation/uikit/uidevice/batterystate-swift.enum?language=objc
	return FIOSPlatformMisc::GetBatteryStateID();
#elif PLATFORM_ANDROID
	//https ://developer.android.com/reference/android/os/BatteryManager#BATTERY_STATUS_CHARGING
	return FAndroidMisc::GetBatteryStateID();
#endif
	return -1;
}
//end add by tangzhangpeng@kuaishou.com[get battery state interface]


void UUIFunctionLibrary::RegisteFunctions()
{
	using namespace NS_SLUA;
	REG_EXTENSION_METHOD_IMP_STATIC(UUIFunctionLibrary, "GetRenderScale", {
			auto * Widget = LuaObject::checkUD<UWidget>(L,1);
			if (IsValid(Widget))
			{
				const FVector2D& Scale = Widget->GetRenderTransform().Scale;
				LuaObject::push(L, Scale.X);
				LuaObject::push(L, Scale.Y);
				return 2;
			}
			return 0;
		});
    REG_EXTENSION_METHOD(UUIFunctionLibrary, "SetRenderTranslation", &UUIFunctionLibrary::SetRenderTranslation);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "SetRenderScale", &UUIFunctionLibrary::SetRenderScale);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "SetRenderTransformAngle", &UUIFunctionLibrary::SetRenderTransformAngle);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "SetRenderShear", &UUIFunctionLibrary::SetRenderShear);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "EvaluateCurveValue", &UUIFunctionLibrary::EvaluateCurveValue);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "SetRenderScaleByCurveFloat", &UUIFunctionLibrary::SetRenderScaleByCurveFloat);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "IsPointerInWidget", &UUIFunctionLibrary::IsPointerInWidget);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "GetColorAndOpacity", &UUIFunctionLibrary::GetColorAndOpacity);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "SetColorAndOpacity", &UUIFunctionLibrary::SetColorAndOpacity);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "GetRenderOpacity", &UUIFunctionLibrary::GetRenderOpacity);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "SetRenderOpacity", &UUIFunctionLibrary::SetRenderOpacity);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "SetOpacity", &UUIFunctionLibrary::SetOpacity);
	REG_EXTENSION_METHOD(UUIFunctionLibrary, "GetOpacity", &UUIFunctionLibrary::GetOpacity);
	REG_EXTENSION_METHOD_IMP_STATIC(UUIFunctionLibrary, "GetRenderingBoundingRect", {
			auto * Widget = LuaObject::checkUD<UWidget>(L, 1);
			if (IsValid(Widget))
			{
				FSlateRect Rect = Widget->GetCachedGeometry().GetRenderBoundingRect();
				LuaObject::push(L, Rect.Left);
				LuaObject::push(L, Rect.Right);
				LuaObject::push(L, Rect.Top);
				LuaObject::push(L, Rect.Bottom);
				return 4;
			}
			return 0;
		});
	REG_EXTENSION_METHOD_IMP_STATIC(UUIFunctionLibrary, "GetViewportBounds", {
			auto * Object = LuaObject::checkUD<UObject>(L, 1);
			if (IsValid(Object))
			{
				FSlateRect Bounds = UUIFunctionLibrary::GetViewportBounds(Object);
				if (Bounds.IsValid())
				{
					LuaObject::push(L, Bounds.Left);
					LuaObject::push(L, Bounds.Right);
					LuaObject::push(L, Bounds.Top);
					LuaObject::push(L, Bounds.Bottom);
					return 4;
				}
			}

			return 0;
		});

	REG_EXTENSION_METHOD_IMP_STATIC(UUIFunctionLibrary, "GetSequenceCameraPovInfo", {
		auto* Object = LuaObject::checkUD<UObject>(L, 1);
		if (IsValid(Object))
		{
			if (UWorld* World = Object->GetWorld())
			{
				if (auto* PC = World->GetFirstPlayerController())
				{
				    AActor* ViewTarget = PC->GetViewTarget();
				    if (auto* CineCamera = Cast<ACineCameraActor>(ViewTarget))
				    {
				        if (PC->PlayerCameraManager)
				        {
                            const auto& POV = PC->PlayerCameraManager->GetCameraCacheView();
                            FVector Pos = POV.Location;
                            FRotator Rot = POV.Rotation;

				            LuaObject::push(L, true);
                            LuaObject::push(L, Pos.X);
                            LuaObject::push(L, Pos.Y);
                            LuaObject::push(L, Pos.Z);
                            LuaObject::push(L, Rot.Pitch);
                            LuaObject::push(L, Rot.Yaw);
                            LuaObject::push(L, Rot.Roll);
                            LuaObject::push(L, POV.FOV);
				            LuaObject::push(L, POV.AspectRatio);
				            LuaObject::push(L, POV.bConstrainAspectRatio != 0);
                            return 10;
                        }
				    }

				    LuaObject::push(L, false);
				    return 1;
				}
			}	
		}
		
		LuaObject::pushNil(L);
		return 1;
	});
}

void UUIFunctionLibrary::SetRenderTranslation(UWidget* Widget, float InPosX, float InPosY)
{
    if (IsValid(Widget))
    {
        Widget->SetRenderTranslation(FVector2D(InPosX, InPosY));
    }
}

void UUIFunctionLibrary::SetRenderScale(UWidget* Widget, float ScaleX, float ScaleY)
{
	if (IsValid(Widget))
	{
		Widget->SetRenderScale(FVector2D(ScaleX, ScaleY));
	}
}

void UUIFunctionLibrary::SetRenderTransformAngle(UWidget* Widget, float InAngle)
{
	if (IsValid(Widget))
	{
		Widget->SetRenderTransformAngle(InAngle);
	}
}

void UUIFunctionLibrary::SetRenderShear(UWidget* Widget, float ShearX, float ShearY)
{
	if (IsValid(Widget))
	{
		Widget->SetRenderShear(FVector2D(ShearX, ShearY));
	}
}

float UUIFunctionLibrary::GetRenderOpacity(UWidget* Widget)
{
	if (IsValid(Widget))
	{
		return Widget->GetRenderOpacity();
	}
	return 0.0f;
}

void UUIFunctionLibrary::SetRenderOpacity(UWidget* Widget, float InOpacity)
{
	if (IsValid(Widget))
	{
		Widget->SetRenderOpacity(InOpacity);
	}
}

float UUIFunctionLibrary::EvaluateCurveValue(UCurveFloat* Curve, float InRatio)
{
	if (IsValid(Curve))
	{
		return Curve->GetFloatValue(InRatio);
	}
	return InRatio;
}

void UUIFunctionLibrary::SetRenderScaleByCurveFloat(UWidget* Widget, UCurveFloat* Curve, float InRatio)
{
	float Scale = EvaluateCurveValue(Curve, InRatio);
	SetRenderScale(Widget, Scale, Scale);
}

FSlateRect UUIFunctionLibrary::GetViewportBounds(UObject* WorldContext)
{
	FSlateRect Bounds;
	if (IsValid(WorldContext))
	{
		if (UWorld* World = WorldContext->GetWorld())
		{
			if (UGameViewportClient* Client = World->GetGameViewport())
			{
				TSharedPtr<class SViewport> ViewPort = Client->GetGameViewportWidget();
				if (ViewPort.IsValid())
				{
					Bounds = ViewPort->GetCachedGeometry().GetRenderBoundingRect();
				}
			}
		}
	}

	return Bounds;
}

bool UUIFunctionLibrary::IsPointerInWidget(UWidget* Widget, float PointerScreenPosX, float PointerScreenPosY, int32 UserIndex)
{
	if (!Widget || !::IsValid(Widget))
	{
		return false;
	}

	if (UWorld* World = Widget->GetWorld())
	{
		if (UGameViewportClient* GameViewportClient = World->GetGameViewport())
		{
			TSharedPtr<SWindow> Wnd = GameViewportClient->GetWindow();
			if (Wnd.IsValid())
			{
				//FSlateRect Bounds = Widget->GetCachedGeometry().GetRenderBoundingRect();
				//if (Bounds.ContainsPoint(UE::Slate::FDeprecateVector2DParameter(PointerScreenPosX, PointerScreenPosY)))
				//{
				//	return true;
				//}

				FWidgetPath WidgetsUnderPointer = FSlateApplication::Get().LocateWindowUnderMouse(UE::Slate::FDeprecateVector2DParameter(PointerScreenPosX, PointerScreenPosY), { Wnd.ToSharedRef() }, false, UserIndex);
				TSharedRef<SWidget> TargetWidget = Widget->TakeWidget();
				if (WidgetsUnderPointer.ContainsWidget(&TargetWidget.Get()))
				{
					return true;
				}	
			}
		}
	}

	return false;
}

FLinearColor UUIFunctionLibrary::GetColorAndOpacity(UWidget* Widget)
{
	if(IsValid(Widget))
	{
		if (Widget->IsA<UImage>())
		{
			return Cast<UImage>(Widget)->GetColorAndOpacity();
		}
		else if (Widget->IsA<UGPUTurboImage>())
		{
			return Cast<UGPUTurboImage>(Widget)->GetColorAndOpacity();
		}
	}

	return FLinearColor::White;
}

void UUIFunctionLibrary::SetColorAndOpacity(UWidget* Widget, const FLinearColor& InColor)
{
	if(IsValid(Widget))
	{
		if (Widget->IsA<UImage>())
		{
			Cast<UImage>(Widget)->SetColorAndOpacity(InColor);
		}
		else if (Widget->IsA<UGPUTurboImage>())
		{
			Cast<UGPUTurboImage>(Widget)->SetColorAndOpacity(InColor);
		}
	}
}

void UUIFunctionLibrary::SetOpacity(UWidget* Widget, float InOpacity)
{
	if (IsValid(Widget))
	{
		if (Widget->IsA<UImage>())
		{
			Cast<UImage>(Widget)->SetOpacity(InOpacity);
		}
		else if (Widget->IsA<UGPUTurboImage>())
		{
			FLinearColor Color = Cast<UGPUTurboImage>(Widget)->GetColorAndOpacity();
			Color.A = InOpacity;
			Cast<UGPUTurboImage>(Widget)->SetColorAndOpacity(Color);

		}
	}
}

float UUIFunctionLibrary::GetOpacity(UWidget* Widget)
{
	if (IsValid(Widget))
	{
		if (Widget->IsA<UImage>())
		{
			return Cast<UImage>(Widget)->GetColorAndOpacity().A;
		}
		else if (Widget->IsA<UGPUTurboImage>())
		{
			return Cast<UGPUTurboImage>(Widget)->GetColorAndOpacity().A;
		}

		return Widget->GetRenderOpacity();
	}

	return 0.0f;
}

TArray<UWidget*> UUIFunctionLibrary::GetVisibleChildren(UPanelWidget* Panel)
{
	TArray<UWidget*> Result;
	if (IsValid(Panel))
	{
		TArray<UWidget*> Children = Panel->GetAllChildren();
		for (auto* Widget : Children)
		{
			if (Widget && Widget->IsVisible())
			{
				Result.Emplace(Widget);
			}
		}
	}

	return Result;
}

ASceneCapture2D* UUIFunctionLibrary::CreateSceneCapture2DActor(UWorld* World)
{
	if (!World)
	{
		return nullptr;
	}

	ASceneCapture2D* SceneCapture2D = World->SpawnActor<ASceneCapture2D>();
#if WITH_EDITOR
	SceneCapture2D->SetActorLabel("BackGroundBlurSceneCapture2D");
#endif
	SceneCapture2D->SetFlags(RF_Transient);

	UTextureRenderTarget2D* TextureRenderTarget2D = NewObject<UTextureRenderTarget2D>();
	TextureRenderTarget2D->SetFlags(RF_Transient);
	TextureRenderTarget2D->InitAutoFormat(1024, 768);
		
	SceneCapture2D->GetCaptureComponent2D()->bCaptureEveryFrame = false;
	SceneCapture2D->GetCaptureComponent2D()->TextureTarget = TextureRenderTarget2D;

	return SceneCapture2D;
}

bool UUIFunctionLibrary::CaptureBlurImage(ASceneCapture2D* Capture, UImage* Image, FVector Location, FRotator Rotation)
{
	if (Capture)
	{
		Capture->SetActorLocation(Location);
		Capture->SetActorRotation(Rotation);
		Capture->GetCaptureComponent2D()->CaptureScene();
		FName CustomName = MakeUniqueObjectName(Image, UTexture2D::StaticClass(), TEXT("KGUI_Blur"));
		UTexture2D* TextureResult = Capture->GetCaptureComponent2D()->TextureTarget->ConstructTexture2D(Image, *CustomName.ToString(), RF_Transient);

		if (TextureResult == nullptr)
		{
			return false;
		}

		TextureResult->CompressionSettings = TC_Default;
		TextureResult->SRGB = true;
		TextureResult->LODGroup = TEXTUREGROUP_UI;

#if WITH_EDITOR
		TextureResult->CompressionNoAlpha = true;
		TextureResult->AdjustMinAlpha = 1;
		TextureResult->AdjustMaxAlpha = 1;
#endif
		TextureResult->UpdateResource();
		
		Image->SetBrushFromTexture(TextureResult, true);

		return true;
	}

	return false;
}

#pragma region 提供给交互的提供易用性的蓝图函数

FVector2D UUIFunctionLibrary::GetTextShadowOffset(UWidget* Widget)
{
	if (Widget == nullptr)
	{
		UE_LOG(LogKGUI, Error, TEXT("Cannot Get Text Shadow Offset from None."));
		return FVector2D::Zero();
	}
	if (auto TextBlock = Cast<UTextBlock>(Widget))
	{
		return TextBlock->GetShadowOffset();
	}
	else if (auto EditableText = Cast<UEditableText>(Widget))
	{
		return FVector2D::Zero();
	}
	else if (auto GPUTurboTextBlock = Cast<UGPUTurboTextBlock>(Widget))
	{
		return GPUTurboTextBlock->GetShadowOffset();
	}
	else if (auto MultiLineEditableText = Cast<UMultiLineEditableText>(Widget))
	{
		return MultiLineEditableText->WidgetStyle.ShadowOffset;
	}
	else if (auto RichTextBlock = Cast<UKGRichTextBlock>(Widget))
	{
		return RichTextBlock->GetCurrentDefaultTextStyle().ShadowOffset;
	}
	UE_LOG(LogKGUI, Error, TEXT("Unsupported widget type: %s, (when calling GetShadowOffset)"), *Widget->GetClass()->GetName());
	return FVector2D::Zero();
}

float UUIFunctionLibrary::ConvertFontSizeFrom72DPIToNative(float FontSize)
{
	return FontSize * 72 / static_cast<float>(FontConstants::RenderDPI);
}

float UUIFunctionLibrary::ConvertFontSizeFromNativeTo72DPI(float FontSize)
{
	return FontSize * static_cast<float>(FontConstants::RenderDPI) / 72;
}

float UUIFunctionLibrary::GetFontSize72DPI(UWidget* Widget)
{
	return ConvertFontSizeFromNativeTo72DPI(GetFontInfo(Widget).Size);
}

void UUIFunctionLibrary::SetFontSize72DPI(UWidget* Widget, float FontSize)
{
	auto FontInfo = GetFontInfo(Widget);
	FontInfo.Size = ConvertFontSizeFrom72DPIToNative(FontSize);
	SetFontInfo(Widget, FontInfo);
}

const UObject* UUIFunctionLibrary::GetFontFamily(UWidget* Widget)
{
	return GetFontInfo(Widget).FontObject;
}

void UUIFunctionLibrary::SetFontFamily(UWidget* Widget, UObject* FontObject)
{
	auto FontInfo = GetFontInfo(Widget);
	FontInfo.FontObject = FontObject;
	SetFontInfo(Widget, FontInfo);
}

UObject* UUIFunctionLibrary::GetFontMaterial(UWidget* Widget)
{
	return GetFontInfo(Widget).FontMaterial;
}

void UUIFunctionLibrary::SetFontMaterial(UWidget* Widget, UObject* FontMaterial)
{
	auto FontInfo = GetFontInfo(Widget);
	FontInfo.FontMaterial = FontMaterial;
	SetFontInfo(Widget, FontInfo);
}

const FFontOutlineSettings& UUIFunctionLibrary::GetFontOutlineSettings(UWidget* Widget)
{
	return GetFontInfo(Widget).OutlineSettings;
}

void UUIFunctionLibrary::SetFontOutlineSettings(UWidget* Widget, const FFontOutlineSettings OutlineSettings)
{
	auto FontInfo = GetFontInfo(Widget);
	FontInfo.OutlineSettings = OutlineSettings;
	SetFontInfo(Widget, FontInfo);
}

int32 UUIFunctionLibrary::GetFontLetterSpacing(UWidget* Widget)
{
	return GetFontInfo(Widget).LetterSpacing;
}

void UUIFunctionLibrary::SetFontLetterSpacing(UWidget* Widget, int32 LetterSpacing)
{
	auto FontInfo = GetFontInfo(Widget);
	FontInfo.LetterSpacing = LetterSpacing;
	SetFontInfo(Widget, FontInfo);
}

float UUIFunctionLibrary::GetFontSkewAmount(UWidget* Widget)
{
	return GetFontInfo(Widget).SkewAmount;
}

void UUIFunctionLibrary::SetFontSkewAmount(UWidget* Widget, float SkewAmount)
{
	auto FontInfo = GetFontInfo(Widget);
	FontInfo.SkewAmount = SkewAmount;
	SetFontInfo(Widget, FontInfo);
}

FName UUIFunctionLibrary::GetFontTypefaceFontName(UWidget* Widget)
{
	return GetFontInfo(Widget).TypefaceFontName;
}

void UUIFunctionLibrary::SetFontTypefaceFontName(UWidget* Widget, FName TypefaceFontName)
{
	auto FontInfo = GetFontInfo(Widget);
	FontInfo.TypefaceFontName = TypefaceFontName;
	SetFontInfo(Widget, FontInfo);
}

float UUIFunctionLibrary::GetFontLineHeightInSlateUnits(UWidget* Widget, float Scale)
{
	if (Widget == nullptr)
	{
		return 0;
	}
	auto& Font = GetFontInfo(Widget);
	auto ShadowOffset = GetTextShadowOffset(Widget);
	const TSharedRef< FSlateFontMeasure > FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
	auto MaxHeight = FontMeasure->GetMaxCharacterHeight(Font, Scale) + (FMath::Abs(ShadowOffset.Y) + Font.OutlineSettings.OutlineSize) * Scale;
	auto Baseline = FontMeasure->GetBaseline(Font, Scale) - (FMath::Min(0.0f, ShadowOffset.Y) + Font.OutlineSettings.OutlineSize) * Scale;
	return FMath::Max(0, MaxHeight + Baseline) + FMath::Max(0, -Baseline);
}

float UUIFunctionLibrary::GetFontLetterSpacingScaleFactor(UWidget* Widget)
{
	if (Widget == nullptr)
	{
		return 0;
	}
	auto& Font = GetFontInfo(Widget);
	return Font.Size / 1000;
}

void UUIFunctionLibrary::SetTextLineSpacingInSlateUnits(UWidget* Widget, float LineSpacing, float Scale, float BaseLineHeightPercentage)
{
	if (Widget == nullptr)
	{
		UE_LOG(LogKGUI, Error, TEXT("Cannot Set Text Line Spacing in Slate Units to None."));
		return;
	}
	auto LineHeight = GetFontLineHeightInSlateUnits(Widget, Scale);
	auto FinalLineHeightPercentage = (LineSpacing / LineHeight) + BaseLineHeightPercentage;
	if (auto TextBlock = Cast<UTextBlock>(Widget))
	{
		TextBlock->SetLineHeightPercentage(FinalLineHeightPercentage);
	}
	else if (auto GPUTurboTextBlock = Cast<UGPUTurboTextBlock>(Widget))
	{
		GPUTurboTextBlock->SetLineHeightPercentage(FinalLineHeightPercentage);
	}
	else if (auto MultiLineEditableText = Cast<UMultiLineEditableText>(Widget))
	{
		MultiLineEditableText->SetLineHeightPercentage(FinalLineHeightPercentage);
	}
	else if (auto RichTextBlock = Cast<UKGRichTextBlock>(Widget))
	{
		RichTextBlock->SetLineHeightPercentage(FinalLineHeightPercentage);
	}
	else
	{
		UE_LOG(LogKGUI, Error, TEXT("Unsupported widget type: %s, (when calling SetTextLineSpacingInSlateUnits)"), *Widget->GetClass()->GetName());
	}
}

void UUIFunctionLibrary::SetTextLetterSpacingInSlateUnits(UWidget* Widget, float LetterSpacing)
{
	if (Widget == nullptr)
	{
		UE_LOG(LogKGUI, Error, TEXT("Cannot Set Text Letter Spacing in Slate Units to None."));
		return;
	}
	auto Factor = GetFontLetterSpacingScaleFactor(Widget);
	auto FinalLetterSpacing = LetterSpacing / Factor;
	auto FontInfo = GetFontInfo(Widget);
	FontInfo.LetterSpacing = FinalLetterSpacing;
	SetFontInfo(Widget, FontInfo);
}

#pragma endregion

void UUIFunctionLibrary::SetImageKGBrush(UKGImage* Image, const FKGSlateBrush& InBrush, bool bMatchSize)
{
	if (Image)
	{
		if (InBrush.bUseSoftObject)
		{
			Image->SetBrushFromSoftObject(InBrush.BrushResourceObj, bMatchSize, false);
			return;
		}

		Image->SetBrush(InBrush.Brush);
	}
}

#pragma region 玩家输入控制

void UUIFunctionLibrary::FlushPressedKeys()
{
	auto ViewportClient = GEngine->GameViewport;
	if (!ViewportClient)
	{
		return;
	}
	auto ViewportWorld = ViewportClient->GetWorld();
	if (!ViewportWorld)
	{
		return;
	}
	for (FConstPlayerControllerIterator Iterator = ViewportWorld->GetPlayerControllerIterator(); Iterator; ++Iterator)
	{
		if (APlayerController* const PlayerController = Iterator->Get())
		{
			PlayerController->FlushPressedKeys();
		}
	}
}

#pragma endregion

#pragma region 屏幕相关

bool UUIFunctionLibrary::IsCurrentlyFullscreen()
{
	if (GEngine && GEngine->GameViewport)
	{
		if (TSharedPtr<SWindow> Window = GEngine->GameViewport->GetWindow())
		{
			const EWindowMode::Type Mode = Window->GetWindowMode();
			return Mode == EWindowMode::Fullscreen || Mode == EWindowMode::WindowedFullscreen;
		}
	}
	if (const UGameUserSettings* Settings = GEngine ? GEngine->GetGameUserSettings() : nullptr)
	{
		const EWindowMode::Type Mode = Settings->GetFullscreenMode();
		return Mode == EWindowMode::Fullscreen || Mode == EWindowMode::WindowedFullscreen;
	}
	return false;
}

#pragma endregion

#pragma region 音效

void UUIFunctionLibrary::PostAudioEventInBlueprint(UObject* Context, TSoftObjectPtr<class UAkAudioEvent> AudioEvent)
{
	if (auto AudioManager = UKGAkAudioManager::GetInstance(Context))
	{
		const auto& SoftEventPath = AudioEvent.ToSoftObjectPath();
		if (SoftEventPath.IsValid())
		{
			AudioManager->InnerPostEvent3D(SoftEventPath.GetAssetName());
		}
	}
}

#pragma endregion


#pragma region 材质相关
float UUIFunctionLibrary::GetTimeSinceEditorStartUp()
{
	float TimeSeconds = FApp::GetCurrentTime() - GStartTime;
	return TimeSeconds;
}
#pragma endregion


#pragma region 全局

void UUIFunctionLibrary::InvalidateAllWidgets(bool bClearResourcesImmediately)
{
	if (auto KGUI = FModuleManager::GetModulePtr<FKGUIModule>("KGUI"))
	{
		KGUI->InvalidateAllWidgets(bClearResourcesImmediately);
	}
}

void UUIFunctionLibrary::RequestDirtyTextRevision()
{
	if (auto KGUI = FModuleManager::GetModulePtr<FKGUIModule>("KGUI"))
	{
		KGUI->RequestDirtyTextRevision();
	}
}

#pragma endregion
