#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "Layout/Geometry.h"
#include "Slate/SObjectTableRow.h"

#include "KGShapedListView.generated.h"

class UKGListViewShapeStyle;
struct FKGListItem;

UINTERFACE()
class UKGShapedListView : public UInterface
{
	GENERATED_BODY()
};

class IKGShapedListView
{
	GENERATED_BODY()

protected:
	using ItemType = TSharedPtr<FKGListItem>;

public:
	virtual UKGListViewShapeStyle* GetShapeStyle() = 0;
	virtual void RaiseOnModifyEntry(const FGeometry& Geometry, TSharedRef<SObjectTableRow<ItemType>> Entry) = 0;
};