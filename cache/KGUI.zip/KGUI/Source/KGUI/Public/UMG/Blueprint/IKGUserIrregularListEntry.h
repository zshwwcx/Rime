#pragma once

#include "UObject/Interface.h"
#include "Types/SlateEnums.h"

#include "IKGUserIrregularListEntry.generated.h"

class UKGIrregularListView;
class UUserWidget;

UINTERFACE(BlueprintType, MinimalAPI, DisplayName = "Kuaishou Game User Irregular List Entry")
class UKGUserIrregularListEntry : public UInterface
{
	GENERATED_UINTERFACE_BODY()
};

class IKGUserIrregularListEntry : public IInterface
{
	GENERATED_IINTERFACE_BODY()

public:
	bool IsListItemSelected() const;
	UKGIrregularListView* GetOwningListView() const;
	virtual bool IsListItemSelectable() const { return true; }

public:
	static void ReleaseEntry(UUserWidget& ListEntryWidget);
	static void UpdateItemSelection(UUserWidget& ListEntryWidget, bool bIsSelected, ESelectInfo::Type SelectInfo);

protected:
	virtual void NativeOnItemSelectionChanged(bool bIsSelected);
	virtual void NativeOnEntryReleased();

	UFUNCTION(BlueprintImplementableEvent, Category = "Kuaishou Game User Irregular List Entry", meta = (DisplayName = "On Item Selection Changed"))
	void OnItemSelectionChanged(bool bIsSelected);

	UFUNCTION(BlueprintImplementableEvent, Category = "Kuaishou Game User Irregular List Entry", meta = (DisplayName = "On Entry Released"))
	void OnEntryReleased();
};