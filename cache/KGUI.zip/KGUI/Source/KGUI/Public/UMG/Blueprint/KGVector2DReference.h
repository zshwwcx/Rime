#pragma once

#include "CoreMinimal.h"

#include "KGVector2DReference.generated.h"

UCLASS(MinimalAPI, DisplayName = "Kuaishou Game Vector 2D Reference")
class UKGVector2DReference : public UObject
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Vector 2D Reference")
	void SetReferenceValue(FVector2D InValue);

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Kuaishou Game Vector 2D Reference")
	FVector2D Value;
};