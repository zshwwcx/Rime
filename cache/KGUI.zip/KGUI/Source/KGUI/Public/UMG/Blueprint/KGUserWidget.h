// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "KGWidgetAnimationName.h"
#include "Blueprint/UserWidget.h"
#include "Core/LuaBinder/KGLuaBinder.h"
#include "UMG/StateManagement/KGStateController.h"
#include "UMG/StyleSheet/KGStyleSheetPreset.h"
#include "UMG/Components/KGInteractableArea.h"

#include "KGUserWidget.generated.h"

struct FKGWidgetName;
class UKGUserWidgetSkeletalWidget;
class UWidgetAnimation;

DECLARE_DYNAMIC_DELEGATE(FKGWidgetAnimationEvent);
DECLARE_MULTICAST_DELEGATE_OneParam(FKGWidgetAnimationCallback, const UWidgetAnimation*);


UENUM()
enum class EKGWidgetAnimationEvent : uint8
{
	Started,
	Finished
};

UENUM(BlueprintType)
enum class EKGPanelLayout : uint8
{
	None = 0 UMETA(DisplayName = "子蓝图，无特殊布局"),
	Normal = 1 UMETA(DisplayName = "普通界面，无特殊布局"),
	FullScreen = 2 UMETA(DisplayName = "全屏"),
	FloatFullScreen = 3 UMETA(DisplayName = "半透浮窗全屏"),
	LeftHalfScreen = 4 UMETA(DisplayName = "左半屏"),
	RightHalfScreen = 5 UMETA(DisplayName = "右半屏"),

};

struct FKGAnimationEventBinding
{
public:
	FKGAnimationEventBinding() :
		Animation(nullptr), Delegate(),
		AnimationEvent(EKGWidgetAnimationEvent::Started)
	{}

	TWeakObjectPtr<UWidgetAnimation> Animation;
	FKGWidgetAnimationEvent Delegate;
	EKGWidgetAnimationEvent AnimationEvent;
};

USTRUCT(BlueprintType)
struct FKGUMGAnimationNotifyEventBinding
{
public:
	GENERATED_USTRUCT_BODY()

public:
	FKGUMGAnimationNotifyEventBinding() :
		Animation(nullptr), Delegate(){}
	TWeakObjectPtr<UWidgetAnimation> Animation;
	UPROPERTY()
	FKGWidgetAnimationEvent Delegate;
};

USTRUCT()
struct FKGUMGAnimationNotifyEvents
{
public:
	GENERATED_USTRUCT_BODY()
	
public:
	FKGUMGAnimationNotifyEvents() :
		First(), Second(){}
	UPROPERTY()
	FKGUMGAnimationNotifyEventBinding First;
	UPROPERTY()
	FKGUMGAnimationNotifyEventBinding Second;
	static const int32 Num = 2;
	FKGUMGAnimationNotifyEventBinding* operator[](const int32 Index)
	{
		return Index == 0 ? &First : (Index == 1 ? &Second : nullptr);
	}
};

USTRUCT(BlueprintType)
struct FKGUserWidgetRegion
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString WidgetName;
};

USTRUCT(BlueprintType)
struct FKGAnimTimeOffsetSettings
{
    GENERATED_USTRUCT_BODY()
    
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FKGWidgetAnimationName AnimName;
    
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TArray<FKGWidgetName> WidgetsName;
    
    UPROPERTY(Transient)
    TArray<UWidget*> Widgets;
};

/**
 *
 */
UENUM(BlueprintType)
enum class EAdaptShapedScreenType : uint8
{
	None UMETA(DisplayName = "不做适配"),
	LeftPadding UMETA(DisplayName = "左侧适配"),
	RightPadding UMETA(DisplayName = "右侧适配"),
	BioSidePadding UMETA(DisplayName = "双侧适配"),
};

USTRUCT(BlueprintType)
struct FPlatformScreenOffsetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Description;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float AdaptOffset;
};

#pragma region 动画

UENUM()
enum class EKGSpecialWidgetAnimationName
{
	Open,
	Close,
};

DECLARE_DELEGATE(FKGOnAnimationFinished);
DECLARE_DELEGATE(FKGOnAnimationInterrupted);
DECLARE_DYNAMIC_DELEGATE(FKGOnAnimationFinishedDynamic);
DECLARE_DYNAMIC_DELEGATE(FKGOnAnimationInterruptedDynamic);

USTRUCT()
struct FKGWidgetAnimationContext
{
	GENERATED_BODY()

public:
	FKGOnAnimationFinished OnFinished;
	FKGOnAnimationInterrupted OnInterrupted;
};

USTRUCT()
struct FKGWidgetSkelSubAnimTask
{
	GENERATED_BODY()

	UPROPERTY()
	UUserWidget* UserWidget;

	UPROPERTY()
	UWidgetAnimation* WidgetAnimation;

	UPROPERTY()
	float Delay;

	UPROPERTY()
	float StartAtTime = 0.0f;

	UPROPERTY()
	int32 NumLoopsToPlay = 1;

	UPROPERTY()
	float PlaybackSpeed = 1.0f;

	UPROPERTY()
	TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode = EUMGSequencePlayMode::Forward;

	UPROPERTY()
	bool bRestoreState = false;

	bool bRunning = false;
	void Start();
	void Stop();
	void Tick(float InDeltaTime);
};

USTRUCT()
struct FKGWidgetSkelAnimTask
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<FKGWidgetSkelSubAnimTask> SubAnims;

	UPROPERTY()
	FString AnimName;
	
	void Start();
	void Stop();
	void Tick(float InDeltaTime);
private:
	bool bRunning = false;
};

USTRUCT()
struct FSubAnimNode
{
	GENERATED_BODY()

	FName AnimName = NAME_None;

	UPROPERTY(Transient)
	TWeakObjectPtr<UKGUserWidget> SubWidget;

	UPROPERTY(Transient)
	TWeakObjectPtr<UWidgetAnimation> SubAnim;

	TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode;
	int32 LoopNum;
};

USTRUCT()
struct FSubAnims
{
	GENERATED_BODY()

	UPROPERTY(Transient)
	TArray<FSubAnimNode> SubAnims;
};



#pragma endregion

UCLASS(Abstract, editinlinenew, BlueprintType, Blueprintable, meta=( DontUseGenericSpawnObject="True", DisableNativeTick))
class KGUI_API UKGUserWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FTouchDelegat, const FGeometry&, MyGeometry,const FPointerEvent&, InGestureEvent);

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FTouchDelegateMulti, const FGeometry&, MyGeometry,const FPointerEvent&, InGestureEvent);

	DECLARE_DYNAMIC_DELEGATE_TwoParams(FTouchDelegatNoRet, const FGeometry&, MyGeometry, const FPointerEvent&, InMouseEvent);

	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(FEventReply, FOnMouseDelegate, const FGeometry&, MyGeometry,const FPointerEvent&, InMouseEvent);

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnMouseDelegateMulti, const FGeometry&, MyGeometry,const FPointerEvent&, InMouseEvent);

	DECLARE_DYNAMIC_DELEGATE_TwoParams(FOnMouseDelegateNoRet, const FGeometry&, MyGeometry, const FPointerEvent&, InMouseEvent);
	
	DECLARE_DYNAMIC_DELEGATE_OneParam(FMouseLeave, const FPointerEvent&, InMouseEvent);
	
	DECLARE_DYNAMIC_DELEGATE_OneParam(FOnAnimationDelegate, const FString&, InAnimatinName);
	
	DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(UDragDropOperation*, FDragDetectedEvent, const FGeometry&, MyGeometry,const FPointerEvent&, InDragDetectedEvent);

	DECLARE_DYNAMIC_DELEGATE_ThreeParams(FOnDragEnter, const FGeometry&, MyGeometry, const FPointerEvent&, InDragDetectedEvent, UDragDropOperation*, InDragDropOperation);

	DECLARE_DYNAMIC_DELEGATE_RetVal_ThreeParams(bool, FOnDragOver, const FGeometry&, InGeometry, const FPointerEvent&, InDragDropEvent, UDragDropOperation*, InOperation);

	DECLARE_DYNAMIC_DELEGATE_TwoParams(FOnDragLeave, const FPointerEvent&, InDragDropEvent, UDragDropOperation*, InDragDropOperation);

	DECLARE_DYNAMIC_DELEGATE_TwoParams(FOnDragCancelled, const FPointerEvent&, InDragDropEvent, UDragDropOperation*, InDragDropOperation);

	DECLARE_DYNAMIC_DELEGATE_RetVal_ThreeParams(bool, FOnDropEvent, const FGeometry&, InGeometry, const FPointerEvent&, InDropEvent, UDragDropOperation*, InDragDropOperation);

	DECLARE_DYNAMIC_DELEGATE_OneParam(FOnPaintEvent, const FPaintContext&, InContext);

	DECLARE_DYNAMIC_DELEGATE_OneParam(FOnFocusLost, const FFocusEvent&, InFocusEvent);
	
	DECLARE_DYNAMIC_DELEGATE_TwoParams(FOnTick, const FGeometry& ,MyGeometry, float, InDeltaTime);

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnAnimationNotify, int32, Index);

public:
	UKGUserWidget(const FObjectInitializer& ObjectInitializer);

	void PlaySubAnimation(UWidgetAnimation* InAnimation, float StartAtTime = 0.0f, int32 NumLoopsToPlay = 1, EUMGSequencePlayMode::Type PlayMode = EUMGSequencePlayMode::Forward, float PlaybackSpeed = 1.0f, bool bRestoreState = false);
	
	virtual void Serialize(FArchive& Ar) override;
public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category="Panel", DisplayName="是否为界面")
	bool IsPanel = false;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Panel", DisplayName="界面布局", meta = (EditCondition = "IsPanel"))
	EKGPanelLayout PanelLayout = EKGPanelLayout::Normal;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Panel", DisplayName = "界面有效交互区域", meta = (EditCondition = "IsPanel"))
	TArray<FKGUserWidgetRegion> PanelRegions;
	
	UPROPERTY(Transient)
	TArray<UWidget*> PanelRegionWidgets;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Panel", DisplayName = "面板打开音效")
	TArray<TSoftObjectPtr<class UAkAudioEvent>> OpenAudioEvents;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Panel", DisplayName = "面板打开音乐事件")
	TSoftObjectPtr<class UAkAudioEvent> OpenMusicEvent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Panel", DisplayName = "面板打开音效事件")
	TSoftObjectPtr<class UAkAudioEvent> OpenSoundEvent;

	UFUNCTION(BlueprintCallable)
	void PlayOpenMusic();

	UFUNCTION(BlueprintCallable)
	void PlayOpenSound();

	UFUNCTION(BlueprintCallable)
	bool HasOpenMusicOrSound();

	void RealPlayAudio(const TSoftObjectPtr<class UAkAudioEvent>& InSoftEvent);

	UPROPERTY(Transient)
	FOnAnimationDelegate OnAnimationStartedEvent;

	UPROPERTY(Transient)
	FOnAnimationDelegate OnAnimationFinishedEvent;
	
	UPROPERTY(Transient)
	FTouchDelegat OnTouchStartedEvent;

	UPROPERTY(Transient)
	FTouchDelegateMulti OnTouchStartedMulti;

	UPROPERTY(Transient)
	FTouchDelegat OnTouchMovedEvent;

	UPROPERTY(Transient)
	FTouchDelegateMulti OnTouchMovedMulti;

	UPROPERTY(Transient)
	FTouchDelegat OnTouchEndedEvent;

	UPROPERTY(Transient)
	FTouchDelegateMulti OnTouchEndedMulti;

	UPROPERTY(Transient)
	FOnMouseDelegateNoRet OnMouseEnterEvent;
	
	UPROPERTY(Transient)
	FOnMouseDelegate OnMouseMoveEvent;

	UPROPERTY(Transient)
	FOnMouseDelegateMulti OnMouseMoveMulti;

	UPROPERTY(Transient)
	FMouseLeave OnMouseLeaveEvent;

	UPROPERTY(Transient)
	FTouchDelegat OnPreviewMouseButtonDownEvent;

	UPROPERTY()
	FDragDetectedEvent OnDragDetectedEvent;
	
	UPROPERTY(Transient)
	FOnDragEnter OnDragEnterEvent;

	UPROPERTY(Transient)
	FOnDragOver OnDragOverEvent;
	
	UPROPERTY(Transient)
	FOnDragLeave OnDragLeaveEvent;

	UPROPERTY(Transient)
	FOnDragCancelled OnDragCancelledEvent;

	UPROPERTY(Transient)
	FOnDropEvent OnDropEvent;

	UPROPERTY(Transient)
	FOnPaintEvent OnPaintEvent;

	UPROPERTY(Transient)
	FOnMouseDelegate OnMouseButtonDownEvent;

	UPROPERTY(Transient)
	FOnMouseDelegateMulti OnMouseButtonDownMulti;

	UPROPERTY(Transient)
	FOnMouseDelegate OnMouseButtonUpEvent;

	UPROPERTY(Transient)
	FOnMouseDelegateMulti OnMouseButtonUpMulti;

	UPROPERTY(Transient)
	FOnMouseDelegate OnMouseButtonDoubleClickEvent;

	UPROPERTY(Transient)
	FOnFocusLost OnFocusLostEvent;
	
	UPROPERTY(Transient)
	FOnMouseDelegate OnMouseWheelEvent;
	
	UPROPERTY(Transient)
	FTouchDelegatNoRet OnC7TouchEvent;

	UPROPERTY(EditAnyWhere)
	bool bBlockC7Touch;

	UPROPERTY(EditAnyWhere)
	FOnAnimationNotify OnAnimationCustomEvent;
	
	UPROPERTY()
	FOnTick OnTick;
	UPROPERTY(EditAnywhere, Category = "KGLuaBinder")
	FLuaBinder LuaBinder;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "异形屏填充适配"), Category = "AdaptedScreen")
	EAdaptShapedScreenType bAdaptForShapedScreen = EAdaptShapedScreenType::None;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "无需适配节点"), Category = "AdaptedScreen")
	TArray<FString> UnAdaptedNodeArr;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "适配偏移", ClampMin="0.0", ClampMax="120.0", UIMin="0.0", UIMax="120.0"), Category = "AdaptedScreen")
	float DesignPaddingOffset;

	UPROPERTY(EditAnywhere)
	bool bEnableEsc;

    UPROPERTY(EditDefaultsOnly, Category="Animation", meta=(DisplayName="时间偏移材质参数名字"))
    FString AnimTimeOffsetMaterialParamName = TEXT("GlobalTimeOffset");
    
    UPROPERTY(EditDefaultsOnly, Category="Animation", meta=(DisplayName="周期",UIMin="1", ClampMin="1"))
    float Period = 3600;
    
    UPROPERTY(EditAnywhere, Category="Animation")
    TArray<FKGAnimTimeOffsetSettings> AnimTimeOffsets;
    
#if WITH_EDITOR
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual const FText GetPaletteCategory() override;
#endif
	
    UFUNCTION(Blueprintcallable)
    void PreviewTimeOffsetInDesignTime(const FString& InAnimName);
	
	UFUNCTION()
	void CheckTemplateBPAdaptation(float NewPaddingValue);
	UFUNCTION()
	void DoAdaptForNode(TWeakObjectPtr<UUserWidget> Node, EAdaptShapedScreenType bAdapt, float NewPaddingValue);
	UFUNCTION()
	static void UnAdaptNode(TWeakObjectPtr<UWidget> UnAdaptedNode, bool bLeftPadding, bool bRightPadding, float offset);
	UFUNCTION()
	static void DealWithParentOverLay(TWeakObjectPtr<UPanelWidget> UnAdaptedNode, bool bLeftPadding, bool bRightPadding, float offset);
	UFUNCTION()
	static void DealWithParentCanvasPanel(TWeakObjectPtr<UPanelWidget> UnAdaptedNode, bool bLeftPadding, bool bRightPadding, float offset);
	
	UFUNCTION()
	void SetEnableEsc(bool bEnable);

	UFUNCTION(BlueprintImplementableEvent)
	void PreConstructPCStyle();

	// UFUNCTION()
	// void SetStateChanged(const FString& StateName, int Index);
	
	TArray<FKGAnimationEventBinding> C7OnAnimationStateChangedEvents;
	
	UPROPERTY(BlueprintReadWrite, meta = (DisplayName = "Animation Notify Events Num"), Category = "C7Animation")
	int32 C7AnimationNotifyNum;

	UPROPERTY()
	FKGUMGAnimationNotifyEvents UMGAnimationNotifyEvents;

	UPROPERTY()
	int32 UObjectNum = 0;
	
	UFUNCTION()
	int32 GetUObjectNumFromWidgetTree();

	int32 GetUObjectNumFromWidgetTree_Internal(UWidget* Widget, int32& Res);

#pragma region 动画相关

	UPROPERTY()
	bool bHadAutoAnimationInfo;
	
	UPROPERTY()
	float KGAnimMaxInTime;

	UPROPERTY()
	float KGAnimMaxOutTime;

	// 默认入场动画名称列表，Lua侧ShowUI默认调用
	UPROPERTY()
	TArray<FString> KGAnimInList;

	// 默认出场动画名称列表，Lua侧HideUI默认调用
	UPROPERTY()
	TArray<FString> KGAnimOutList;

	UPROPERTY(Transient)
	TMap<FName, FSubAnims> SubAnimMap;

	//子蓝图表，用于通过控件名快速找到子蓝图
	UPROPERTY(Transient)
	TMap<FName, UKGUserWidget*> SubUserWidgetMap;

#pragma endregion 
	
#if WITH_EDITOR

	void GetAllAutoAnimationInfo();
	
	virtual void ValidateCompiledWidgetTree(const UWidgetTree& BlueprintWidgetTree, class IWidgetCompilerLog& CompileLog) const override;
#endif

	UFUNCTION(BlueprintCallable)
	UWidgetAnimation* GetWidgetAnimationByName(UUserWidget* Widget, FString AnimationName);

protected:
	virtual bool Initialize() override;
	
	virtual void NativeOnInitialized() override;
	virtual void PreSave(FObjectPreSaveContext ObjectSaveContext) override;

	virtual void NativePreConstruct() override;

	virtual void NativeConstruct() override;

	virtual void NativeDestruct() override;

	virtual FReply NativeOnMouseButtonDown( const FGeometry& InGeometry, const FPointerEvent& InMouseEvent ) override;

	virtual FReply NativeOnMouseButtonUp(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

	virtual FReply NativeOnMouseButtonDoubleClick(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;
	
	virtual void NativeOnFocusLost(const FFocusEvent& InFocusEvent) override;

	virtual FReply NativeOnTouchStarted(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;

	virtual FReply NativeOnTouchMoved(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;

	virtual FReply NativeOnTouchEnded(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;

	virtual void NativeOnMouseEnter(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

	virtual FReply NativeOnMouseMove(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

	virtual void NativeOnMouseLeave(const FPointerEvent& InMouseEvent) override;

	virtual FReply
	NativeOnPreviewMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

	virtual void NativeOnDragEnter(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent,
	                               UDragDropOperation* InOperation) override;

	virtual bool NativeOnDragOver(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent,
	                              UDragDropOperation* InOperation) override;

	virtual void NativeOnDragLeave(const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;

	virtual void NativeOnDragCancelled(const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;

	virtual void NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent,
	                                  UDragDropOperation*& OutOperation) override;

	virtual bool NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent,
	                          UDragDropOperation* InOperation) override;

	virtual int32 NativePaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry,
	                          const FSlateRect& MyCullingRect,
	                          FSlateWindowElementList& OutDrawElements, int32 LayerId,
	                          const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;
	
	virtual FReply NativeOnMouseWheel( const FGeometry& InGeometry, const FPointerEvent& InMouseEvent ) override;


	virtual bool NativeOnC7Touch(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override;

	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime)override;

	virtual bool NativeSupportsKeyboardFocus() const override;
	
	virtual void InitPCStyle();

	UFUNCTION(BlueprintCallable)
	void C7CallUMGAnimationNotify(int32 Index);

#if WITH_EDITOR
	UFUNCTION()
	TArray<FString> GetAllAnimationNames() const;

	void GetAllAnimationNames_Internal(TArray<FString>& Anis, UWidgetBlueprintGeneratedClass* WidgetBlueprint, FString prefix) const;
#endif
protected:
	UPROPERTY(EditDefaultsOnly)
	uint8 bAutoRemoveFromWorld : 1;

	// UWidget interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	// End of UWidget interface

	TMap<TWeakObjectPtr<UUserWidget>,float> paddingSubOffset;
	TMap<TWeakObjectPtr<UWidget>,bool> adaptDealingWBPList;
	float paddingOffset = 0;

#pragma region 骨骼动画

public:
	UPROPERTY(BlueprintReadWrite, EditDefaultsOnly, Category = "骨骼动画")
	UKGUserWidgetSkeletalWidget* Skeletal;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "骨骼动画", meta=(DisplayName = "淡入动画延迟时间", ToolTips = "在骨架动画中，淡入动画(Ani_Fadein)相对于骨架淡入动画的延迟时间"))
	float FadeInDelayTime = 0.f;

	UPROPERTY()
	TMap<FString, float> AnimFadeInDelayTimes;

	UPROPERTY(Transient)
	TMap<UUserWidget*, UWidgetAnimation*> SubFadeInAnimations;

	UPROPERTY(Transient)
	TMap<FString, FKGWidgetSkelAnimTask> SkeletalAnimTasks;

	UPROPERTY(Transient)
	TMap<FString, UWidgetAnimation*> SkeletalAnimInstances;

	FKGWidgetAnimationCallback OnAnimationStarted;
	FKGWidgetAnimationCallback OnAnimationFinished;
	
	UFUNCTION(BlueprintCallable)
	bool PlaySkeletalAnimation(const FString& AnimName, float StartAtTime = 0.0f, int32 NumLoopsToPlay = 1, EUMGSequencePlayMode::Type PlayMode = 
	EUMGSequencePlayMode::Forward, float PlaybackSpeed = 1.0f, bool bRestoreState = false);

	UFUNCTION(BlueprintCallable)
	void StopSkeletalAnimation(const FString& AnimName);

	UFUNCTION(BlueprintCallable)
	UWidgetAnimation* GetSkeletalAnimation(const FString& AnimationName, bool bCreateOnFound);

protected:
	TArray<UWidgetAnimation*> GetAnimationsFromSkeletal() const;
	UWidgetAnimation* FindOrCreateSkeletalAnimation(const FString& AnimationName);
	void CollectSubAnimations();
	void BuildSubAnimationsMap();

	UWidgetAnimation* DuplicateAnimFromSkeletal(const FString& InAnimName);
	UWidgetAnimation* CreateNewWidgetAnim(const UWidgetAnimation* CloneFrom);
#pragma endregion
	
#pragma region 动画
public:
	virtual UUMGSequencePlayer* PlayAnimation(
		UWidgetAnimation* InAnimation,
		float StartAtTime = 0.0f,
		int32 NumLoopsToPlay = 1,
		EUMGSequencePlayMode::Type PlayMode = EUMGSequencePlayMode::Forward,
		float PlaybackSpeed = 1.0f,
		bool bRestoreState = false
	) override;

	virtual UUMGSequencePlayer* PlayAnimationInternal(
		UWidgetAnimation* InAnimation,
		float StartAtTime = 0.0f,
		int32 NumLoopsToPlay = 1,
		EUMGSequencePlayMode::Type PlayMode = EUMGSequencePlayMode::Forward,
		float PlaybackSpeed = 1.0f,
		bool bRestoreState = false
	);

	float PlayAnimationWithCallbacksInternal(
		UWidgetAnimation* InAnimation,
		float StartAtTime,
		int32 NumLoopsToPlay,
		EUMGSequencePlayMode::Type PlayMode,
		float PlaybackSpeed,
		bool bRestoreState,
		const FWidgetAnimationDynamicEvent& InOnFinished,
		const FWidgetAnimationDynamicEvent& InOnInterrupted
	);

	UFUNCTION(BlueprintCallable)
	void GotoAnimation(UWidgetAnimation* InAnimation, float TargetTime);

	UFUNCTION(BlueprintCallable)
	void PlayAnimationToStart(UWidgetAnimation* InAnimation);

	UFUNCTION(BlueprintCallable)
	void PlayAnimationToEnd(UWidgetAnimation* InAnimation);

	UFUNCTION(BlueprintCallable)
	float PlayAnimationWithCallbacks(
		UWidgetAnimation* InAnimation,
		float StartAtTime,
		int32 NumLoopsToPlay,
		EUMGSequencePlayMode::Type PlayMode,
		float PlaybackSpeed,
		bool bRestoreState,
		const FWidgetAnimationDynamicEvent& InOnFinished,
		const FWidgetAnimationDynamicEvent& InOnInterrupted
	);

	UFUNCTION(BlueprintCallable)
	void PlayAnimationWithID(UWidgetAnimation* InAnimation, float StartAtTime, int32 NumLoopsToPlay, EUMGSequencePlayMode::Type PlayMode, float PlaybackSpeed, bool bRestoreState, int32 OnFinishedID = 0, int32 OnInterruptedID = 0);

	UFUNCTION(BlueprintCallable)
	void OnAnimationFinishedCallbackWithID(int32 ID);

	UFUNCTION(BlueprintCallable)
	void OnAnimationInterruptedCallbackWithID(int32 ID);

	UFUNCTION(BlueprintCallable)
	void ClearAnimationCallbacks();
	
	// 暂停所有当前UserWidget的动画，及其子动画
	UFUNCTION(BlueprintCallable)
	void StopAllAnimationsRecursively();

	UFUNCTION(BlueprintCallable)
	bool VerifyAllAnimationsStoppedRecursively();

	UFUNCTION(BlueprintCallable)
	bool IsPointerInPanel(float PointerScreenPosX, float PointerScreenPosY, int32 UserIndex);

	UFUNCTION(BlueprintCallable)
	void AddPanelRegionWidget(UWidget* Widget);

	UFUNCTION(BlueprintCallable)
	void RemovePanelRegionWidget(UWidget* Widget);

	UFUNCTION(BlueprintCallable)
	void AddChildrenToPanelRegionWidgets(UPanelWidget* Widget, bool bJustVisible);

	UFUNCTION(BlueprintCallable)
	void ClearPanelRegionWidget();

protected:
    void SetAnimTimeOffset(UWidgetAnimation* InAnimation);
    void CollectAnimTimeOffsetWidgets();
	UWidgetAnimation* GetAnimationByName(const FString& AnimationName) const;
	UWidgetAnimation* GetAnimationBySpecialName(EKGSpecialWidgetAnimationName SpecialAnimationName) const;

	virtual void OnAnimationStarted_Implementation(const UWidgetAnimation* Animation) override;
	
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void PlaySubAnimFromZeroPosition(UWidgetAnimation* InMainAnim);
	void CollectSubAnimsFromZeorPosition();
	void AddSubAnimFromZeroPosition(UWidgetAnimation* InMainAnim, UKGUserWidget* InSubWidget, UWidgetAnimation* InSubAnim, class UKGUserWidgetAnimationSection* InSection);
	UKGUserWidget* GetSubWidgetByName(const FName& InWidgetName);
	UKGUserWidget* GetSubWidgetByGUID(UWidgetAnimation* InAnim, const FGuid& InBindGuid);
	
private:
	TMap<TWeakObjectPtr<const UWidgetAnimation>, FKGWidgetAnimationContext> WidgetAnimationContexts;

	// 存放不同手机型号的适配参数
	TWeakObjectPtr<UDataTable> templatePlatformDataTable;

	#pragma endregion

	virtual void OnWidgetRebuilt() override;

	#pragma region Style Sheet

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Setter, BlueprintSetter = "SetStyleSheetPreset", Category = StyleSheet, meta = (DesignerRebuild, AllowPrivateAccess = "true", AllowedClasses = "/Script/KGUI.KGStyleSheetPreset"))
	TObjectPtr<UKGStyleSheetPreset> StyleSheetPreset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = StyleSheet, meta = (DesignerRebuild, AllowPrivateAccess = "true"))
	FKGStyleSheet StyleSheetInline;

	UFUNCTION(BlueprintCallable, Category = StyleSheet)
	void SetStyleSheetPreset(UKGStyleSheetPreset* InStyleSheetPreset);

	UFUNCTION(BlueprintCallable, Category = StyleSheet)
	bool HasAnyWidgetAnimationStyle(UWidgetAnimation* WidgetAnimation) const;

	UFUNCTION(BlueprintCallable, Category = StyleSheet)
	bool ApplyWidgetAnimationStyle(UWidgetAnimation* WidgetAnimation, EKGItemAnimationState AnimationState);

	#pragma endregion
};
