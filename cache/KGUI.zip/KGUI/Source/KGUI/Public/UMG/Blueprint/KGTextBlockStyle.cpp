#include "UMG/Blueprint/KGTextBlockStyle.h"

UKGTextBlockStyle::UKGTextBlockStyle()
{
	Margin = FMargin(0.0f);
	LineHeightPercentage = 1.0f;
}

