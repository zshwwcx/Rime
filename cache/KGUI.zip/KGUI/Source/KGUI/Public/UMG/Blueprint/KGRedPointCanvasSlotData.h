#pragma once

#include "CoreMinimal.h"
#include "Layout/Margin.h"
#include "Widgets/Layout/Anchors.h"

#include "KGRedPointCanvasSlotData.generated.h"

USTRUCT(BlueprintType)
struct KGUI_API FKGRedPointCanvasSlotData
{
public:
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DispalyName = "Canvas Layout:Offset", Category = "Red Point Settings"))
	FMargin Offset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DispalyName = "Canvas Layout:Anchors", Category = "Red Point Settings"))
	FAnchors Anchors = FAnchors(1.0f, 0.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DispalyName = "Canvas Layout:Alignment", Category = "Red Point Settings"))
	FVector2D Alignment =FVector2D(0.5f, 0.5f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DispalyName = "Canvas Layout:bAutoSize", Category = "Red Point Settings"))
	bool bAutoSize = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DispalyName = "Canvas Layout:ZOrder", Category = "Red Point Settings"))
	int32 ZOrder = 0;

};