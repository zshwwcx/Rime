#pragma once

#include "UMG/Components/KGListView.h"

struct FKGTreeTileLayoutState;
struct FKGTreeTileLayoutItem;
class UKGTreeView;

enum class EKGTreeItemType : uint8
{
	Normal,
	TileLayout,
};

struct IKGTreeItem : public FKGListItem
{
public:
	using Super = FKGListItem;
	virtual EKGTreeItemType GetTreeItemType() = 0;

	static TSharedPtr<IKGTreeItem> UnsafeCast(const TSharedPtr<FKGListItem>& Item);
};

struct FKGTreeItem : public IKGTreeItem
{
	friend struct FKGTreeTileLayoutItem;
	friend class UKGTreeView;

public:
	FKGTreeItem(const UKGTreeView* InTreeView)
		: TreeView(InTreeView)
	{
	}

	static TSharedPtr<FKGTreeItem> UnsafeCast(const TSharedPtr<FKGListItem>& Item);

	using Super = IKGTreeItem;
	virtual EKGTreeItemType GetTreeItemType() override { return EKGTreeItemType::Normal; }

	TArray<int> GetPath() const;
	void SetIndexInParent(int InIndexInParent) { IndexInParent = InIndexInParent; }
	int GetIndexInParent() const { return IndexInParent; }

	TArray<TSharedPtr<FKGListItem>>& GetAccessibleChildren();
	const TArray<TSharedPtr<FKGListItem>>& GetChildren();
	int GetChildCount() const;

	TSharedPtr<FKGTreeItem> GetChildAt(int Index) const;
	TSharedPtr<FKGTreeItem> GetParent() const { return Parent.Pin(); }

	int GetTreeLevel() const;
	const TArray<TSharedPtr<FKGTreeTileLayoutItem>>& GetChildLayoutItems() const;
	TSharedPtr<FKGTreeTileLayoutItem> GetParentLayoutItem() const { return ParentLayoutItem.Pin(); }

	TArray<TSharedPtr<FKGListItem>> GetOutChildren();
	void SetChildrenDirty() { bChildrenDirty = true; }

protected:
	void AddChild(const TSharedPtr<FKGTreeItem>& InChild);
	void InsertChild(int Index, const TSharedPtr<FKGTreeItem>& InChild);
	void RemoveChild(int Index);
	void MakeChildren(int Num);

	int IndexInParent = INDEX_NONE;
	TWeakPtr<FKGTreeItem> Parent;
	TArray<TSharedPtr<FKGListItem>> Children;

	TArray<TSharedPtr<FKGTreeTileLayoutItem>> ChildLayoutItems;
	TWeakPtr<FKGTreeTileLayoutItem> ParentLayoutItem;
	bool bChildrenDirty = true;

	TWeakObjectPtr<const UKGTreeView> TreeView;
	TSharedPtr<FKGTreeTileLayoutState> TreeTileLayoutStateCache;
};

struct FKGTreeTileLayoutItem : public IKGTreeItem
{
public:
	using Super = IKGTreeItem;
	virtual EKGTreeItemType GetTreeItemType() override { return EKGTreeItemType::TileLayout; }
	void AddTreeItem(const TSharedPtr<FKGTreeItem>& InTreeItem);
	const TArray<TSharedPtr<FKGTreeItem>>& GetTreeItems() const { return TreeItems; }
	static TSharedPtr<FKGTreeTileLayoutItem> UnsafeCast(const TSharedPtr<FKGListItem>& Item);

	bool IsFirstLine() const
	{
		check(this->GetTreeItems().Num() != 0);
		auto Parent = this->GetTreeItems()[0]->GetParent();
		check(Parent != nullptr && Parent->GetChildLayoutItems().Num() != 0);
		return Parent->GetChildLayoutItems()[0] == SharedThis(this);
	}

	bool IsLastLine() const
	{
		check(this->GetTreeItems().Num() != 0);
		auto Parent = this->GetTreeItems()[0]->GetParent();
		check(Parent != nullptr && Parent->GetChildLayoutItems().Num() != 0);
		return Parent->GetChildLayoutItems().Last() == SharedThis(this);
	}

protected:
	TArray<TSharedPtr<FKGTreeItem>> TreeItems;

public:
	void SetPadding(const FMargin& InPadding) { Padding = InPadding; }
	void SetCellSize(const FVector2D& InCellSize) { CellSize = InCellSize; }
	void SetSpacing(float InSpacing) { Spacing = InSpacing; }
	void SetLineOrientation(EOrientation InLineOrientation) { LineOrientation = InLineOrientation; }

	const FMargin& GetPadding() const { return Padding; }
	const FVector2D& GetCellSize() const { return CellSize; }
	float GetSpacing() const { return Spacing; }
	EOrientation GetLineOrientation() const { return LineOrientation; }

protected:
	FMargin Padding;
	FVector2D CellSize;
	float Spacing = 0;
	EOrientation LineOrientation = EOrientation::Orient_Horizontal;
};