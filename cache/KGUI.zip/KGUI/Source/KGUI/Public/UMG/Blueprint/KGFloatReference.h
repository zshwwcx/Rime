#pragma once

#include "CoreMinimal.h"

#include "KGFloatReference.generated.h"

UCLASS(MinimalAPI, DisplayName = "Kuaishou Game Float Reference")
class UKGFloatReference : public UObject
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "Kuaishou Game Float Reference")
	void SetReferenceValue(float InValue);

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Kuaishou Game Float Reference")
	float Value;
};