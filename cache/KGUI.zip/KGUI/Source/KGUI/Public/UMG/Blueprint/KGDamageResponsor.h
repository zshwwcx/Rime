// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UMG/Blueprint/KGUserWidget.h"
#include "Misc/CommonDefines.h"
#include "KGDamageResponsor.generated.h"

class UWidgetAnimation;

DECLARE_MULTICAST_DELEGATE_TwoParams(FOnDamageResponsorBinded, int64 /*EntityID*/, class UKGDamageResponsor* /*UserWidget*/);

// TODO: limunan,后续要改正UObject，由lua侧发业务起Bind与Unbind，不在使用继承方式
/**
 * UKGDamageResponsor 
 */
UCLASS(meta=( DontUseGenericSpawnObject="True", DisableNativeTick))
class KGUI_API UKGDamageResponsor : public UKGUserWidget
{
	GENERATED_BODY()
public:
	static FOnDamageResponsorBinded OnDamageResponsorBinded;
	static FOnDamageResponsorBinded OnDamageResponsorUnbinded;
	UPROPERTY()
	UWidgetAnimation* AnimOnDamage = nullptr;

	UPROPERTY()
	int64 EntityID = INDEX_NONE;

	UFUNCTION(BlueprintCallable)
	void Bind(int64 InEntityID, UWidgetAnimation* InAnimOnDamage);

	UFUNCTION(BlueprintCallable)
	void Unbind();

	UFUNCTION()
	bool IsBinded() const { return EntityID != INDEX_NONE; }

	UFUNCTION(BlueprintCallable)
	virtual void PlayDamage();

};
