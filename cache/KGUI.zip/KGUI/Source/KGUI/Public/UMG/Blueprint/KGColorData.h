// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataTable.h"

#include "KGColorData.generated.h"

/**
 * 
 */
USTRUCT(BlueprintType)
struct FKGColorData : public FTableRowBase
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FLinearColor Value  = FLinearColor::Transparent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Description;
};

//UCLASS()
//class C7_API UC7UIUtils : public UObject
//{
//	GENERATED_BODY()
//	
//};
