#pragma once

#include "IKGUserIrregularListEntry.h"

#include "IKGUserObjectIrregularListEntry.generated.h"

UINTERFACE(BlueprintType, MinimalAPI, DisplayName = "Kuaishou Game User Irregular List Entry")
class UKGUserObjectIrregularListEntry : public UKGUserIrregularListEntry
{
	GENERATED_UINTERFACE_BODY()
};

class IKGUserObjectIrregularListEntry : public IKGUserIrregularListEntry
{
	GENERATED_IINTERFACE_BODY()

protected:
	virtual void NativeOnListItemObjectSet(UObject* ListItemObject);

	UFUNCTION(BlueprintImplementableEvent, Category = "Kuaishou Game User Irregular List Entry")
	void OnListItemObjectSet(UObject* ListItemObject);

private:
	UObject* GetListItemObjectInternal() const;

	friend class SKGObjectIrregularListEntry;
	static void SetListItemObject(UUserWidget& ListEntryWidget, UObject* ListItemObject);

	static UObject* GetListItemObject(TScriptInterface<IKGUserObjectIrregularListEntry> UserObjectListEntry);
};