#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "Fonts/SlateFontInfo.h"
#include "Layout/Margin.h"

#include "KGTextBlockStyle.generated.h"

/**
 * 
 */
UCLASS(BlueprintType)
class KGUI_API UKGTextBlockStyle : public UDataAsset
{
	GENERATED_BODY()
public:
	UKGTextBlockStyle();
	
	UPROPERTY(EditDefaultsOnly, Category = "Appearance")
	FSlateFontInfo Font;

	UPROPERTY(EditDefaultsOnly, Category = "Appearance", AdvancedDisplay)
	FMargin Margin;

	UPROPERTY(EditDefaultsOnly, Category = "Appearance", AdvancedDisplay)
	float LineHeightPercentage;

	UPROPERTY(EditDefaultsOnly, Category = "Appearance")
	FVector2D ShadowOffset;

	UPROPERTY(EditDefaultsOnly, Category = "Appearance")
	FLinearColor ShadowColorAndOpacity;
};
