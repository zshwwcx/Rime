// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Runtime/CoreUObject/Public/UObject/Object.h"
#include "Templates/SubclassOf.h"
#include "KGMapTagInfoManager.generated.h"


class UWidget;
class UUserWidget;
class UKGMapTagLayer;

UENUM(BlueprintType)
enum class EMapTagType : uint8
{
	None,
	Static,
	FollowActor,
	Dynamic,
};

UENUM(BlueprintType)
enum class EMapTagLayerMode : uint8
{
    ViewBound = 0,
    Full
};

UENUM(BlueprintType)
enum class EMapEdgeType : uint8
{
	None,
	ShowOnEdge
};

UENUM(BlueprintType)
enum class EMapShowTypeOnEdge : uint8
{
	ShowOnEdgeByCircle,
	ShowOnEdgeByRectangle
};

UENUM(BlueprintType)
enum class EMapDisplayState : uint8
{
    Loading,
	None,
	Edge,
	Center
};

UENUM(BlueprintType)
enum class EMapRotateType : uint8
{
	Identity,
	RotateByActor
};

USTRUCT(BlueprintType)
struct FMapTagInfo
{
	GENERATED_BODY()
	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	FString TaskID = "";

	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	EMapTagType MapTagType = EMapTagType::Static;

	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	EMapEdgeType MapEdgeType = EMapEdgeType::None;

	//reg Static
	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	FVector StaticLocation;
	//end reg

	//reg FollowActor
	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	int64 FollowerID = 0;
	//end reg
	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	EMapRotateType MapRotateType = EMapRotateType::Identity;

	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	FString TemplateWidgetType;

    UPROPERTY(Transient)
    TSubclassOf<UUserWidget> WidgetClass;

	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	int32 TypeID = -1;

	//这两个属性只有C++需要
	UPROPERTY()
	TObjectPtr<UUserWidget> MyUserWidget = nullptr;
    
	EMapDisplayState DisplayState = EMapDisplayState::None;
    EMapDisplayState LastDisplayState = EMapDisplayState::None;

	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	FVector2D ShowRatioInterval = FVector2D(.0f, 1.0f);

	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	int32 ZOrder = 0;

	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	FVector2D Offset;

    UPROPERTY(EditAnyWhere, BlueprintReadWrite)
    FString TagIcon;
   
    UPROPERTY(EditAnyWhere, BlueprintReadWrite)
    float IconSizeX = 32;

    UPROPERTY(EditAnyWhere, BlueprintReadWrite)
    float IconSizeY = 32;

    UPROPERTY(EditAnyWhere, BlueprintReadWrite)
    float RotateAngle = 0.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FLinearColor TintColor = FLinearColor::White;

    UPROPERTY(EditAnyWhere, BlueprintReadWrite)
    bool bSimpleTagIcon = false; // 使用简单图标模式
	
	UPROPERTY(EditAnyWhere, BlueprintReadWrite)
	bool bVisible = true;
    
    // 由FMapTagInfoManager颁发的Token
    int64 Token = 0;

    UPROPERTY(EditAnyWhere, BlueprintReadWrite)
    bool bIgnoreConstraint = false;

    UPROPERTY(EditAnyWhere, BlueprintReadWrite)
    bool bInteractable = false;

    FString ToString(bool bSummary = true) const;

    bool operator<(const FMapTagInfo& Other) const
    {
        if (ZOrder != Other.ZOrder)
        {
            return ZOrder > Other.ZOrder;
        }
        
        if (Token != Other.Token)
        {
            return Token > Other.Token;
        }
        
        return false;
    }
};

typedef TSharedPtr<FMapTagInfo> FMapTagInfoPtr;

USTRUCT(BlueprintType)
struct FMapEdgeRotateInfo {

	GENERATED_BODY()

	UPROPERTY()
	FString TaskID = "";

	UPROPERTY()
	TWeakObjectPtr<UWidget> RotateWidget = nullptr;

	UPROPERTY()
	float Offset = 90.0f;

	FMapEdgeRotateInfo() = default;

	FMapEdgeRotateInfo(const FString& TaskID, UWidget* _RotateWidget, float _Offset) : TaskID(TaskID), RotateWidget(_RotateWidget),
		Offset(_Offset) {}
};

// 视野管理类
UCLASS()
class UKGMapTagViewManager : public UObject
{
    GENERATED_BODY()

public:
    void Initialize(const FVector& InCameraLocation, const FRotator& InCameraRotation, 
                   const FVector2D& InCameraViewportSize, float InViewportScale,
                   const FVector2D& InCurrentCenterLocation, float InConstraintRadius,
                   const FVector4& InConstraintRectangle, EMapShowTypeOnEdge InPanelMapEdgeType);
    FVector2D GetWidgetOffsetByMapTagInfo(const FMapTagInfo& MapTagInfo) const;
    FVector2D GetWidgetPosByMapTagInfo(const FMapTagInfo& MapTagInfo) const;
    FVector2D GetWidgetOffsetByWorldLocation(const FVector& Location) const;
    FVector2D GetWorldOffsetByWorldLocation(const FVector& Location) const;
    FVector2D DeprojectWidgetOffsetToWorldLocation(const FVector2D& WidgetOffset) const;
    
    bool UpdateCameraParams(const FVector& InCameraLocation, const FRotator& InCameraRotation,
                           const FVector2D& InCameraViewportSize, float InViewportScale,
                           const FVector2D& InCurrentCenterLocation);

private:
    FVector CameraLocation;
    FRotator CameraRotation;
    FVector2D CameraViewportSize = {2048, 2048};
    float ViewportScale = 1.f;
    FVector2D CurrentCenterLocation;
    float ConstraintRadius;
    FVector4 ConstraintRectangle;
    EMapShowTypeOnEdge PanelMapEdgeType;
};

// 重命名后的格子管理类
UCLASS()
class UKGMapTagInfoManager : public UObject
{
    GENERATED_BODY()
    // 格子坐标结构体
    struct FGridCellCoord
    {
        int32 X;
        int32 Y;
    
        FGridCellCoord(int32 InX = 0, int32 InY = 0) : X(InX), Y(InY) {}
    
        bool operator==(const FGridCellCoord& Other) const
        {
            return X == Other.X && Y == Other.Y;
        }
        
        bool IsInRange(const FGridCellCoord& InMin, const FGridCellCoord& InMax) const
        {
            return InMin.X <= X && X <= InMax.X && InMin.Y <= Y && Y <= InMax.Y;
        }
    
        // 用于TMap的哈希函数
        friend uint32 GetTypeHash(const FGridCellCoord& Coord)
        {
            return HashCombine(GetTypeHash(Coord.X), GetTypeHash(Coord.Y));
        }
    };
    
    struct FGridCell
    {
        int32 CellIndexX = INDEX_NONE;
        int32 CellIndexY = INDEX_NONE;
        TArray<FMapTagInfoPtr> Tags;
        
        void CollectVisibleTags(TSet<FMapTagInfoPtr>& OutTags);
    };
public:
    void Initialize(float InGridSize, UKGMapTagLayer* InOwnerLayer);;
    void Tick(float DeltaTime);
    void AddSingleTag(const FMapTagInfo& InTagInfo);
    void RemoveSingleTag(const FString& TaskID);
    void UpdateTagLocation(const FString& TaskID, const FVector& NewLocation);
    void SetMode(EMapTagLayerMode InMode) { Mode = InMode; }

    /* 返回true，表示没有格子变更，直接拿当前的格子的数据进行计算，返回false，表示有格子变动，不能使用当前格子数据*/
    bool FilterTasksByCharacterPosition(const FVector& CharacterLocation);
    void ClearAllTags();
    TArray<FString> GetNearbyTasksByTaskID(const FString& TaskID, float ToleranceDistance);
    TArray<FString> GetNearbyInteractableTasksByTaskID(const FString& TaskID, float ToleranceDistance, bool bRequireCenter);
    void ResetTaskTypeToFollowActor(const FString& TaskID, int64 ActorID);
    void ResetTaskTypeToStatic(const FString& TaskID);
    void SetTaskShowEdgeType(const FString& TaskID, EMapEdgeType ShowOnEdgeType);
    void SetTaskInteractable(const FString& TaskID, bool bInteractable);

    FVector2D GetWidgetPosByTaskID(const FString& TaskID);
    float GetWidgetShearByTaskID(const FString& TaskID);
    
    void BatchAddTags(const TMap<FString, FMapTagInfo>& InBatchData);
    // 获取当前九宫格内的所有TaskID
    void BuildCurrentTaskIDs(TSet<FString>& OutTaskIDs) const;
    
    // 通过TaskID获取FMapTagInfo
    FMapTagInfoPtr GetMapTagInfo(const FString& TaskID) const;
    FMapTagInfoPtr GetMapTagInfo(const FString& TaskID);

    void SetMapEdgeType(EMapShowTypeOnEdge InMapShowTypeOnEdge) { PanelMapEdgeType = InMapShowTypeOnEdge; }
    void UpdateCameraParams(const FVector& InCameraLocation, const FRotator& InCameraRotation, const FVector2D& InCameraViewportSize, float InViewportScale);
    void SetFilterStrategyEnabled(bool InEnabled) { bFilterStrategyEnabled = InEnabled; }
    
    const TArray<FMapTagInfoPtr>& GetPendingUpdateList() const { return PendingUpdateList; }
    const TArray<FString>& GetPendingRemoveList() const { return PendingRemoveList; }
    const TArray<FMapTagInfoPtr>& GetPendingInstanceList() const { return PendingInstanceList; }
    const TSet<FString>& GetFollowUpdateList() const { return FollowUpdateList; }

    void SetCenterActor(int64 InCenterActorID)
    {
        CenterActorID = InCenterActorID;
    }

    void ResetCenterActor()
    {
        CenterActorID = 0;
    }
    
    void SetupCircleEdgeTag(const FMapTagInfoPtr& TagInfoData, const FVector2D& WidgetOffset);
    void SetupRectangleEdgeTag(const FMapTagInfoPtr& TagInfoData, const FVector2D& WidgetOffset);

    void RegisterWidgetRotateInEdge(const FString& TaskID, UWidget* Widget, float Offset);
    void UnRegisterWidgetRotateInEdge(const FString& TaskID);
    static float ConvertRotateAngle(float InRotateAngleInDegree);
    void ResetEdgeWidgetShear(const FMapEdgeRotateInfo& MapEdgeRotateInfo);
    void SetConstraintRadius(float InConstraintRadius) { ConstraintRange.Radius = InConstraintRadius; }
    void SetConstraintRect(const FVector4& InConstraintRect) { ConstraintRange.Rect = InConstraintRect; }
    void SetSimpleTagIcon(const FString& TaskID, const FString& InIcon);
    void SetSimpleTagIconSize(const FString& TaskID, float InSizeX, float InSizeY);
	void SetSimpleTagVisible(const FString& TaskID, bool bInVisible);
    void SetSimpleTagRotate(const FString& TaskID, float InRotateAngleInDegree);
private:
    EMapDisplayState GetNewMapDisplayState(const FMapTagInfoPtr& MapTagInfo, const FVector2D& WidgetOffset) const;
    void AdaptOverlappingCircles();
    // 更新动态图标（FollowUpdateList）对应格子位置
    void UpdateFollowTagInfo();
    FGridCellCoord WorldToGrid(const FVector& WorldLocation) const;
    
    static TArray<FGridCellCoord> GetSurroundingGrids(const FGridCellCoord& CenterGrid);
    void LoadGrid(const FGridCellCoord& GridCoord);
    void UnloadGrid(const FGridCellCoord& GridCoord);
    void AddSingleTagToGridInternal(const FMapTagInfoPtr& InTagInfo, const FGridCellCoord& GridCoord);
    void UpdateTagState(const FMapTagInfoPtr& TagInfo);
    void HandleSameStateUpdate(const FMapTagInfoPtr& TagInfoData, EMapDisplayState State);
    void TransitStateToNone(const FMapTagInfoPtr& TagInfoData);
    void TransitStateToCenter(const FMapTagInfoPtr& TagInfoData);
    void UpdateCenterTagPosition(const FMapTagInfoPtr& TagInfoData);
    void TransitStateToEdge(const FMapTagInfoPtr& TagInfoData);

    void AddToPendingInstance(const FMapTagInfoPtr& TaskID);
    void AddToPendingUpdate(const FMapTagInfoPtr& InTagInfo);
    void AddToPendingRemove(const FString& TaskID);
    void AddToFollowUpdate(const FString& TaskID);
    bool InRectangle(const FVector2D& InWidgetOffset) const;
    bool InCircle(const FVector2D& InWidgetOffset) const;

    static FVector2D CalculateConstrainedDirection(const FVector2D& DirectionVec, float Cosine, float Sine, const FVector4& ConstraintRectangle);
    void UpdateEdgeTagPosition(const FMapTagInfoPtr& TagInfoData);

    void AddTagToGrid(const FMapTagInfoPtr& InTagInfo);
    void RemoveTagFromGrid(const FMapTagInfoPtr& InTagInfo);
    
    void CalculateShowCells(const FVector& InCenterInWorldSpace, TArray<FGridCellCoord>& OutSubCells);
    void GetViewRangeBoundCell(const FGridCellCoord& InCenterCell, FGridCellCoord& OutBoundMinCell, FGridCellCoord& 
    OutBoundMaxCell) const;
    void TryAddToUpdateList(const FMapTagInfoPtr& InTagInfo);
    
    static bool GetTagWorldPos(const FMapTagInfoPtr& InTagInfoData, FVector& OutPos);
    static int64 GetToken();
    static FGridCellCoord WorldToSubGrid(float WorldLocationX, float WorldLocationY);
private:
    // 数据管理
    TMap<FString, FMapTagInfoPtr> MapTagInfoData;
    TArray<FString> EdgeList;
    TSet<FMapTagInfoPtr> TempUpdateList;
    TSet<FString> FollowUpdateList;
    TArray<FMapTagInfoPtr> PendingUpdateList;
    TArray<FString> PendingRemoveList;
    TArray<FMapTagInfoPtr> PendingInstanceList;
    TMap<FString, FMapEdgeRotateInfo> RotateWidgetList;
    
    // 模式
    EMapTagLayerMode Mode = EMapTagLayerMode::ViewBound;
    
    // 视野管理
    UPROPERTY(Transient)
    TObjectPtr<UKGMapTagViewManager> ViewManager;
    
    // 格子大小
    float GridSize;
    
    // 格子到TaskID数组的映射
    TMap<FGridCellCoord, TArray<FMapTagInfoPtr>> GridToTaskMap;
    TMap<FGridCellCoord, FGridCell> WorldSubGridMap;
    
    // TaskID到格子的映射（用于快速查找）
    TMap<FString, FGridCellCoord> TaskIDToGridMap;
    
    // 当前加载的九宫格格子
    TSet<FGridCellCoord> CurrentLoadedGrids;
    
    // 当前角色所在的格子坐标
    FGridCellCoord CurrentCharacterGrid;
    
    // 引用所有者
    TWeakObjectPtr<UKGMapTagLayer> OwnerLayer;
    
    // 显示范围的格子
    FGridCellCoord ViewBoundMinCell;
    FGridCellCoord ViewBoundMaxCell;

    EMapShowTypeOnEdge PanelMapEdgeType = EMapShowTypeOnEdge::ShowOnEdgeByRectangle;
    int64 CenterActorID = 0;//小地图中使用，中心位置由Actor位置决定

    FVector CameraLocation;
    FRotator CameraRotation;
    FVector2D CameraViewportSize;
    FVector2D CurrentCenterLocation;
    float ViewportScale = 1.0f;
    
    struct FConstraintRange
    {
        float Radius;
        FVector4 Rect;

        FConstraintRange() : Radius(0), Rect(0.0f, 0.0f, 0.0f, 0.0f) {}
        FConstraintRange(const FConstraintRange& Other)
        {
            Radius = Other.Radius;
            Rect = Other.Rect;
        }
    };
    FConstraintRange ConstraintRange;

    bool bFilterStrategyEnabled = false;
    bool bFirstUpdate = true;
    bool bValidViewBounds = false;
};