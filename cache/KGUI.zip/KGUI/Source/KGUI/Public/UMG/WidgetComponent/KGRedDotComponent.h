// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Componentization/KGWidgetComponent.h"
#include "Layout/Margin.h"
#include "Widgets/Layout/Anchors.h"
#include "Engine/StreamableManager.h"
#include  "FieldNotificationId.h"
#include "UObject/Interface.h"
#include "KGRedDotComponent.generated.h"

UINTERFACE(BlueprintType, Blueprintable)
class KGUI_API URedDotCounterInterface : public UInterface
{
	GENERATED_BODY()
};

class IRedDotCounterInterface : public IInterface
{
	GENERATED_BODY()
public:
	virtual void SetCount(int32 InCount);

	UFUNCTION(BlueprintImplementableEvent, Category = RedDotCounter)
	void OnSetCount(int32 InCount);
};

/**
 * UKGRedDotComponent
 */
UCLASS()
class KGUI_API UKGRedDotComponent : public UKGWidgetComponent
{
	GENERATED_UCLASS_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSoftClassPath RedDotClass;
	
	/** Anchors. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Layout)
	FAnchors Anchors;

	/** Offset. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Layout)
	FMargin Offset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Layout)
	FVector2D Alignment = FVector2D::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Layout)
	float ContentScale = 1.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor ColorAndOpacity;

	UPROPERTY(editAnywhere, BlueprintReadWrite)
	FLinearColor ForegroundColor;

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bShowRedDotInPreview = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bShowRedDotInPreview", EditConditionHides))
	int32 PreviewCount = 1;
#endif

	UPROPERTY(Transient)
	UWidget* RedDotInstance = nullptr;

	UPROPERTY(Transient)
	class UKGRedDot* RedDotWidget = nullptr;
	
	TSharedPtr<class SOverlay> OverlayWidget;
	
public:
	UFUNCTION(BlueprintCallable)
	void SetVisibility(bool bVisible);

	UFUNCTION(BlueprintCallable)
	bool GetVisibility() { return bIsVisible; }

	UFUNCTION(BlueprintCallable)
	void SetColorAndOpacity(const FLinearColor& InColorAndOpacity);

	UFUNCTION(BlueprintCallable)
	void SetForegroundColor(const FLinearColor& InColor);

	UFUNCTION(BlueprintCallable)
	UWidget* GetRedDotUserWidget() { return RedDotInstance; }

	UFUNCTION(BlueprintCallable)
	void SetCount(int32 Count);

	UFUNCTION(BlueprintCallable)
	int32 GetCount() const { return Counter; }

	UFUNCTION(BlueprintCallable)
	void SetRedDotClassFromString(const FString& RedDotClassPath);
	
	virtual void SynchronizeProperties() override;
	void OnSlatePostTick(float InDaltaTime);
	virtual void OnWidgetRebuilt() override;
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	
#if WITH_EDITOR
	virtual void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;
#endif
	
	void OnFieldValueChanged(UObject* Object, UE::FieldNotification::FFieldId FieldId);
protected:
	void BuildRedDot();
	void RemoveRedDot(bool bDestroy);
	class UUserWidget* Instance() const;
	void InternalSetCount(int32 InCount) const;
	
	virtual void RequestAsyncLoad(const FSoftClassPath& SoftObject);
	virtual void CancelImageStreaming();

	TSharedPtr<FStreamableHandle> StreamingHandle;
	FSoftClassPath StreamingClassPath;
	FDelegateHandle DelegateHandleOnSlatePostTick;
private:
	bool bIsVisible = false;
	bool bDeferredCreateRedDont = false;
	int32 Counter = 0;
};