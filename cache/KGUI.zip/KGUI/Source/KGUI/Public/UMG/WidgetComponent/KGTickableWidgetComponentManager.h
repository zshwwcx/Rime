﻿#pragma once

#include "Manager/KGBasicManager.h"
#include "KGTickableWidgetComponentManager.generated.h"

class UKGTickableWidgetComponent;

UCLASS()
class KGUI_API UKGTickableWidgetComponentManager : public UKGBasicManager
{
	GENERATED_BODY()
#pragma region Important
public:
	//static UKGTickableWidgetComponentManager* GetInstance(UObject* InContext);

	void NativeInit() override;

	void NativeUninit() override;

	virtual EManagerType GetManagerType() { return EManagerType::EMT_TickableWidgetComponentManager; }
	static UKGTickableWidgetComponentManager* GetInstance(UObject* InContext)
	{
		return Cast<UKGTickableWidgetComponentManager>(GetManagerByType(InContext, EManagerType::EMT_TickableWidgetComponentManager));
	}

#pragma endregion Important

	void AddComponent(TWeakObjectPtr<UKGTickableWidgetComponent> Component);
	void RemoveComponent(TWeakObjectPtr<UKGTickableWidgetComponent> Component);

private:
	virtual void Tick(float DeltaTime) override;
	virtual void OnPostLoadMapWithWorld(UWorld* World) override;
	
private:
	TSet<TWeakObjectPtr<UKGTickableWidgetComponent>> WaitAddWidgetComponentList;
	TSet<TWeakObjectPtr<UKGTickableWidgetComponent>> WaitDeleteWidgetComponentList;
	TSet<TWeakObjectPtr<UKGTickableWidgetComponent>> WidgetComponentList;
};
