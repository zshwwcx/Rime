﻿#pragma once

#include "CoreMinimal.h"
#include "Componentization/KGWidgetComponent.h"
#include "KGTickableWidgetComponentManager.h"
#include "KGTickableWidgetComponent.generated.h"

class UWidget;

UCLASS(Abstract)
class KGUI_API UKGTickableWidgetComponent : public UKGWidgetComponent
{
	GENERATED_BODY()

	friend class UKGTickableWidgetComponentManager;

protected:
	virtual void OnInit() {}
	virtual void OnRelease() {}
	virtual void Tick(float DeltaTime) {}

	virtual void SetTickEnable(bool Enable)
	{
		auto Manager = UKGTickableWidgetComponentManager::GetInstance(this);
		if (!Manager)
		{
			return;
		}
		
		if (Enable)
		{
			Manager->AddComponent(this);
		}
		else
		{
			Manager->RemoveComponent(this);
		}
	}
	
	virtual void OnWidgetRebuilt() override
	{
		OnInit();
	}
	
	virtual void OnBeginDestroy() override
	{
		OnRelease();
	}
};
