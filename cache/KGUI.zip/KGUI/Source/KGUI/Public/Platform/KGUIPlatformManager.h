#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"

UENUM()
enum class EKGUIPlatforms : uint8
{
	Mobile,
	PC,
};

class KGUI_API FKGUIPlatformManager
{
protected:
	UPROPERTY(EditAnywhere, Category = "Platform")
	EKGUIPlatforms Platform = EKGUIPlatforms::Mobile;

public:
	DECLARE_MULTICAST_DELEGATE_OneParam(UKGUIPlatformChanged, EKGUIPlatforms);

	void SetPlatform(EKGUIPlatforms InPlatform);
	EKGUIPlatforms GetPlatform();

	UKGUIPlatformChanged PlatformChanged;

	static FKGUIPlatformManager* GetInstance();
	static void TryDestroyInstance();

private:
	static TSharedPtr<FKGUIPlatformManager> Singleton;
};