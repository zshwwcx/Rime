// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/SCompoundWidget.h"

class FUIAutoItem
{
public:
	FUIAutoItem() {}
	
	FUIAutoItem(const FString& InUIName, const FString& InOpenTimeMs, const FString& InLuaMemoryIncrease, const FString& InUObjectNum, const FString& InAtlasNum, const FString& InNumBatches, const FString& InAvgOverDraw, const FString& InAvgFPS, const FString& InUObjectsLeakInfo, const FString& InErrorInfo)
	: UIName(InUIName), OpenTimeMs(InOpenTimeMs), LuaMemoryIncrease(InLuaMemoryIncrease), UObjectNum(InUObjectNum), AtlasNum(InAtlasNum), NumBatches(InNumBatches), AvgOverDraw(InAvgOverDraw), AvgFPS(InAvgFPS), UObjectsLeakInfo(InUObjectsLeakInfo), ErrorInfo(InErrorInfo) {}
	
	// UI名称
	FString UIName;
	// 打开时间
	FString OpenTimeMs;
	// Lua内存增长
	FString LuaMemoryIncrease;
	// UObject数量
	FString UObjectNum;
	// 图集数量
	FString AtlasNum;
	// DrawCall数量
	FString NumBatches;
	// OverDraw
	FString AvgOverDraw;
	// 帧率
	FString AvgFPS;
	 // 内存泄漏
	FString UObjectsLeakInfo;
	// 抛错信息
	FString ErrorInfo;
};

/** 展示UI自动化性能跑测工具结果
 * 
 */
class KGUI_API SKGUIAutomationProfileWidget : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SKGUIAutomationProfileWidget)
		{
		}


	SLATE_ARGUMENT(TArray<TSharedPtr<FUIAutoItem>>, TableItems)

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs);

	void InitColNames();

	void UpdateListView() const;
	
private:
	// 列表展示的数据array
	TArray<TSharedPtr<FUIAutoItem>> Items;

	// 列名称
	TArray<FString> ColNames;

	// ListView指针
	TSharedPtr<SListView<TSharedPtr<FUIAutoItem>>> ListView;

	TSharedRef<ITableRow> OnGenerateRow(TSharedPtr<FUIAutoItem> Item, const TSharedRef<STableViewBase>& OwnerTable);
};
