#pragma once

#include "UMG/Components/KGListView.h"
#include "UMG/Components/KGRichTextBlock.h"
#include "C7/SKGTextListView.h"

#include "KGTextListView.generated.h"


DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FKGTextListViewUrlActivatedDynamic, int32, Key, FString, Url);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FKGTextListViewClickedDynamic);


USTRUCT(BlueprintType)
struct FKGTextListViewItemData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	int32 Key;

	UPROPERTY(EditAnywhere)
	FText Text;
};

UINTERFACE(MinimalAPI)
class UKGTextListEntry : public UInterface
{
	GENERATED_BODY()
};

class IKGTextListEntry
{
	GENERATED_BODY()

protected:
	UFUNCTION(BlueprintImplementableEvent, Category = "Text List View")
	UKGRichTextBlock* GetRichTextBlock();

public:
	static UKGRichTextBlock* GetRichTextBlock(UUserWidget* UserWidget);
};


UCLASS(DisplayName = "Text List View (C7)", MinimalAPI)
class UKGTextListView : public UKGListView
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("C7")); }
	virtual void OnRefreshDesignerItems() override;
#endif

	virtual TSharedRef<STableViewBase> RebuildListWidget() override;
	virtual TSharedRef<ITableRow> HandleGenerateRow(ItemType Item, const TSharedRef<STableViewBase>& OwnerTable) override;
	virtual void HandleRowReleased(const TSharedRef<ITableRow>& Row) override;
	virtual void HandleOnEntryInitializedInternal(ItemType Item, const TSharedRef<ITableRow>& TableRow) override;
	UKGRichTextBlock* GetRichTextBlockForItem(ItemType Item) const;
	TSharedPtr<SKGTextListView<ItemType>> GetListViewSlateWidget() const;

public:
	UFUNCTION(BlueprintCallable, Category = TextListView)
	void SetTexts(const TArray<FKGTextListViewItemData>& InItems);

	UFUNCTION(BlueprintCallable, Category = TextListView)
	int AddText(int32 Key, FText Text);

	UFUNCTION(BlueprintCallable, Category = TextListView)
	bool RemoveText(int32 Key);

	UFUNCTION(BlueprintCallable, Category = TextListView)
	void ClearTexts();

	UFUNCTION(BlueprintCallable, Category = TextListView)
	void SetIsTextClickable(bool bClickable);

	UFUNCTION(BlueprintCallable, Category = TextListView)
	bool GetIsTextClickable() const;

	UPROPERTY(BlueprintAssignable, Category = "Event")
	FKGTextListViewUrlActivatedDynamic OnUrlActivated;

private:
	UPROPERTY(VisibleAnywhere, Category = TextListView)
	TArray<FKGTextListViewItemData> Items;

	UPROPERTY(EditAnywhere, Getter = "GetIsTextClickable", Setter = "SetIsTextClickable", BlueprintSetter = "SetIsTextClickable", Category = TextListView)
	bool bIsTextClickable = true;

#if WITH_EDITORONLY_DATA

	UPROPERTY(EditAnywhere, Category = ListEntries, meta = (DesignerRebuild))
	FText DesignerPreviewText;
#endif
};
