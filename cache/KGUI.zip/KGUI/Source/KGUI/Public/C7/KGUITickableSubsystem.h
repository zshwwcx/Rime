// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Tickable.h"
#include "Runtime/Engine/Public/Subsystems/EngineSubsystem.h"
#include "KGUITickableSubsystem.generated.h"


DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FKGUITickableDynamicEvent, float, InDeltaTime);
DECLARE_MULTICAST_DELEGATE_OneParam(FKGUITickableEvent, float);

class FKGUITickableObjectBase
{
public:
    UE_NONCOPYABLE(FKGUITickableObjectBase);
    
    FKGUITickableObjectBase();
    virtual ~FKGUITickableObjectBase();
    virtual void Tick( float DeltaTime )  = 0;
    virtual bool IsTickable() const { return true; }
    void RegisterTick();
    void UnregisterTick();
};

/**
 * UKGUITickableSubsystem
 */
UCLASS()
class KGUI_API UKGUITickableSubsystem : public UEngineSubsystem, public FTickableGameObject
{
    friend class FKGUITickableObjectBase;
    GENERATED_BODY()
public:    
    /** Implement this for initialization of instances of the system */
    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    
    /** Implement this for deinitialization of instances of the system */
    virtual void Deinitialize() override;

    virtual void Tick(float DeltaTime) override;

    virtual bool IsTickable() const override 
    {
        if (HasAnyFlags(RF_BeginDestroyed | RF_ClassDefaultObject | RF_ArchetypeObject))
        {
            return false;
        }

        if (TickableObjects.IsEmpty())
        {
            return false;
        }

        return true;
    }

    virtual TStatId GetStatId() const override {
        return GetStatID();
    }

    virtual bool IsTickableInEditor() const override
    {
        return true;
    }

private:
    
    void RegisterTickableWidget(FKGUITickableObjectBase* Widget);
    void UnregisterTickableWidget(FKGUITickableObjectBase* Widget);

    void BuildNeedTickingObjects();
private:
    TMap<FKGUITickableObjectBase*, bool> MapTickObjects;
    TArray<FKGUITickableObjectBase*> TickableObjects;
    TArray<FKGUITickableObjectBase*> PendingTickObjects;
    FCriticalSection NewTickableObjectsCritical;
    bool bNeedsCleanUp = false;
    bool bIsTickingObjects = false;
};
