// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "Misc/CommonDefines.h"
#include "Layout/SlateRect.h"
#include "KGTabClose.generated.h"

class UWidget;
class UKGUserWidget;

UENUM(BlueprintType)
enum class ETabCloseBlockPolicy : uint8
{
    None = 0,                               
    Unblock = 1,                            // 不拦截输入事件
    BlockOutsideBounds = 2,                 // 面板范围外输入事件全被拦截
    BlockOutsideBoundsExcludeRegions = 3,   // 面板范围外输入事件在特定区域不被拦截，其余全拦截
    UnblockOutsideBounds = 4,               // 面板范围外输入事件不被拦截
    UnblockOutsideBoundsExcludeRegions = 5, // 面板范围外输入事件在特定区域被拦截，其余不拦截
};

UENUM(BlueprintType)
enum class ETabClosePointerCheckResult : uint8
{
    Outside = 0 UMETA(DisplayName = "Outside"),
    InsidePanel = 1 UMETA(DisplayName = "InsidePanel"),
    InsideExcluded = 2 UMETA(DisplayName = "InsideExcluded"),
};

enum class ETabCloseHandleResult : uint8
{
    EventResumePropagate = 0, // 事件继续传递
    EventConsumed = 1, // 事件被消费掉了，中断传递
    Recheck = 2, // 需要再次检查判断是否继续传递
};

using FTabCloseRect = FSlateRect;

USTRUCT(BlueprintType)
struct FTabCloseItemData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 Token = 0;
    
    UPROPERTY(BlueprintReadWrite, EditAnywhere, Transient)
    FString ItemId;
    
    UPROPERTY(BlueprintReadWrite, EditAnywhere, Transient)
    ETabCloseBlockPolicy Policy;
    
    UPROPERTY(BlueprintReadWrite, Transient)
    TWeakObjectPtr<UWidget> WidgetTriggeredBy;

    UPROPERTY(BlueprintReadWrite, Transient)
    TWeakObjectPtr<UKGUserWidget> UserWidgetBelonged;
    
    TArray<FSlateRect> RectsExcluded;
    
    UPROPERTY(BlueprintReadWrite, EditAnywhere, Transient)
    bool bComponent = false;
};

struct FPointerEntry
{
    int32 PointerIndex = INDEX_NONE;
    FVector2D PressedScreenSpacePosition;
    bool bPressed = false;
    bool bUpEventProcessed = false;

    void Reset()
    {
        PointerIndex = INDEX_NONE;
        bPressed = false;
        bUpEventProcessed = false;
        PressedScreenSpacePosition = FVector2D::Zero();
    }
};

/**
 * UKGTabClose
 */
UCLASS()
class KGUI_API UKGTabClose : public UKGBasicManager
{
    GENERATED_BODY()
public:
    static constexpr uint32 Invalid_Token = 0;
    
    virtual void NativeInit() override;
    virtual void NativeUninit() override;
    virtual EManagerType GetManagerType() override { return EManagerType::EMT_TabClose; }
    static UKGTabClose* Get(UObject* InContext)
    {
        return Cast<UKGTabClose>(GetManagerByType(InContext, EManagerType::EMT_TabClose));
    }

    virtual void OnPostLoadMapWithWorld(UWorld* World) override;
    
    /*
     * @param InItemId: item id
     * @param OwnerWidget: owner widget
     * @param BlockPolicy: ETabCloseBlockPolicy
     */
    UFUNCTION(BlueprintCallable, Category = "TabClose")
    int32 PushItem(const FString& InItemId, int32 BlockPolicy, UKGUserWidget* UserWidgetBelonged, UWidget* WidgetTriggeredBy, bool bComponent);

    UFUNCTION(BlueprintCallable, Category = "TabClose")
    void UpdateItem(const FString& InItemName, UKGUserWidget* UserWidgetBelonged);
    
    void RemoveItem(const FString& ItemId);

    UFUNCTION(BlueprintCallable, Category = "TabClose")
    void RemoveItemByToken(int32 InToken);
    
    // 处理鼠标按下事件
    UFUNCTION(BlueprintCallable)
    bool HandleMouseButtonDown(const FPointerEvent& PointerEvent);

    // 处理鼠标释放事件
    UFUNCTION(BlueprintCallable)
    bool HandleMouseButtonUp(const FPointerEvent& PointerEvent);
    
    // 忽略下一次右键
    void AddIgnoreRightMouseButtonTag(const FString& Tag);

    void RemoveIgnoreRightMouseButtonTag(const FString& Tag);

    // 检查是否应该忽略右键
    bool ShouldIgnoreRightMouseButton() const;
    
    void SetTopUI(const FString& InTopUI);
    void AddPanelUIDIgnoreCheck(const FString& InPanelUID);
    void AddPanelUIDsIgnoreCheck(const TArray<FString>& InPanelUIDs);
    void RemovePanelUIDIgnoreCheck(const FString& InPanelUID);
    void ClearPanelUIDIgnoreCheck();
    void IgnoreNextMouseUpEvent(const FString& Reason);
    void OnScreenInput(const FPointerEvent& PointerEvent);
private:
    static int32 GenerateToken();

    bool CanClose(const FTabCloseItemData& Item) const;
    bool InternalPreCheck(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent);
    // 检测指针位置
    static ETabClosePointerCheckResult DetectPointer(const FTabCloseItemData& Item, const FVector2D& PosInScreenSpace, bool bCheckExcluded);
        
    // 根据策略处理事件
    ETabCloseHandleResult HandlePolicy(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bIsMouseUp, bool& bNeedCache);

    bool TryClose(const FPointerEvent& PointerEvent);
    void DoClose(const FTabCloseItemData& Item, bool bScreenInput);
    FTabCloseItemData* GetTopItem();

    ETabCloseHandleResult BlockOutsideBounds(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bExecCloseAction, bool& bNeedCache);
    ETabCloseHandleResult BlockOutsideExcludeRegions(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bExecCloseAction, bool& bNeedCache);
    ETabCloseHandleResult UnblockOutside(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bExecCloseAction, bool& bNeedCache);
    ETabCloseHandleResult UnblockOutsideExcludeRegions(const FTabCloseItemData& Item, const FPointerEvent& PointerEvent, bool bExecCloseAction, bool& bNeedCache);

    void ResetPointerEntry(int32 PointerIndex);
    void RecordPointerEntry(const FPointerEvent& InPointerEvent);
    bool IsPointerPreciseTapOrClick(const FPointerEvent& InPointerEvent);
    void SetPointerEntryUpEventProcessed(int32 InPointerIndex, bool bProcessed);
    bool IsPointerUpEventProcessed(int32 InPointerIndex);
private:
    UPROPERTY(Transient)
    TMap<FString, FTabCloseItemData> Items;
    TMap<int32, FPointerEntry> PointerEntries;
    FVector2D PressedScreenSpacePosition;
    TArray<FString> ItemStack;
    TSet<FString> IgnoreRightMouseButtonTags;
    
    TArray<FString> IgnoreCheckPanelUIDs;
    FString TopPanelUID;
    bool bMouseDown =  false;
    bool bIgnoreNextMouseUpEvent = false;
};
