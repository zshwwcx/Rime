#pragma once

#include "CoreMinimal.h"
#include "Components/Image.h"
#include "Tickable.h"
#include "Engine/TextureRenderTarget2D.h"

#include "PaintingScratchImage.generated.h"

DECLARE_DYNAMIC_DELEGATE(FOnPaintingScratchReachPercent);

/**
 * 
 */
UCLASS(DisplayName = "Painting Scratch Image (KGUI)")
class KGUI_API UPaintingScratchImage : public UImage, public FTickableGameObject
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override { return FText::FromString(TEXT("KGUI")); }
#endif
	
public:
	virtual void Tick(float DeltaTime) override;
	
	UFUNCTION(BlueprintCallable)
	void InitParameters(FVector2D LeftTop, int32 Thickness, float PaintingPercent, UTextureRenderTarget2D* InDrawRenderTarget, 
		UMaterialInstanceDynamic* InDrawMaterial, UTextureRenderTarget2D* InAdvertRenderTarget, UMaterialInstanceDynamic* InAdvertMaterial,
		UTextureRenderTarget2D* InSimRenderTarget, UMaterialInstanceDynamic* InSimMaterial);

	UFUNCTION(BlueprintCallable)
	void SetMouseButtonDown(bool bInMouseButtonDown);

	virtual ETickableTickType GetTickableTickType() const override;
	
	virtual TStatId GetStatId() const override;

protected:
	UPROPERTY()
	FVector2D WidgetSize;

	UPROPERTY()
	TWeakObjectPtr<UMaterialInstanceDynamic> DrawMaterial;

	UPROPERTY()
	TWeakObjectPtr<UTextureRenderTarget2D> DrawRenderTarget;

	UPROPERTY()
	TWeakObjectPtr<UMaterialInstanceDynamic> AdvertMaterial;

	UPROPERTY()
	TWeakObjectPtr<UTextureRenderTarget2D> AdvertRenderTarget;

	UPROPERTY()
	TWeakObjectPtr<UMaterialInstanceDynamic> SimMaterial;

	UPROPERTY()
	TWeakObjectPtr<UTextureRenderTarget2D> SimRenderTarget;

	UPROPERTY()
	FOnPaintingScratchReachPercent OnPaintingScratchReachPercentEvent;
	
	TArray<TArray<int32>> PaintingCells;
	int32 PaintingCellNum;
	float PaintingTotalPercent;

	bool bMouseButtonDown;

	bool bReachPercent;
	
	FVector2D LastDrawPosition;

	FVector2D RenderTargetScale;

	FVector2D LeftTop;
	float Thickness;
	int32 SizeHeight;
	int32 SizeWidth;
};
