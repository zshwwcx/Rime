#pragma once

#include "CoreMinimal.h"
#include "Widgets/SBoxPanel.h"
#include "WorldWidgetEnums2.h"
#include "Components/GPUTurboInvalidationBox.h"
#include "WorldWidget2.generated.h"

USTRUCT(BlueprintType)
struct FWorldWidgetParams2
{
	GENERATED_BODY()

	//类型
	UPROPERTY(BlueprintReadWrite, Transient)
	int32 ID = 0;

	//类型
	UPROPERTY(BlueprintReadWrite, Transient)
	int32 WType = 0;

	//挂接的Widget(UUserWidget)
	UPROPERTY(BlueprintReadWrite, Transient)
	UUserWidget* Widget = nullptr;

	//校准点
	UPROPERTY(BlueprintReadWrite, Transient)
	FVector2D Alignment = FVector2D::ZeroVector;

	//世界偏移(暂时)
	UPROPERTY(BlueprintReadWrite, Transient)
	FVector WorldOffset = FVector::ZeroVector;

	//可见性
	UPROPERTY(BlueprintReadWrite, Transient)
	bool bVisible = true;

	//隐藏距离
	UPROPERTY(BlueprintReadWrite, Transient)
	float HiddenDistance = -1.0;

	//挂接位置(没有就视为Root)
	UPROPERTY(BlueprintReadWrite, Transient)
	FName SocketName;

	//对象
	UPROPERTY(Transient)
	uint64 RefActorID = 0;

	//位置(世界)
	UPROPERTY(BlueprintReadWrite, Transient)
	FVector WorldPos = FVector::ZeroVector;

	//2DUI放置的层(不填写放默认层)
	UPROPERTY(BlueprintReadWrite, Transient)
	FString LayerName;

	//限制在屏幕范围内
	UPROPERTY(Transient)
	EWWConstrainType2 ScreenConstrainType = EWWConstrainType2::NONE;
	UPROPERTY(Transient)
	FVector2D ScreenConstrainPadding = FVector2D::ZeroVector;

	//Zorder偏移
	UPROPERTY(Transient)
	int ZorderOffSet = 0;

	//Widget类型
	UPROPERTY(Transient)
	EWoldWidgetType2 WidgetType = EWoldWidgetType2::NONE;

	//材质路径
	UPROPERTY(Transient)
	FString MaterialPath = "";

	//随距离变化缩放
	UPROPERTY(Transient)
	bool bEnableDistanceScale = false;
	UPROPERTY(Transient)
	FName DistanceScaleCurveName;

	//RelativeOffset
	UPROPERTY(Transient)
	FTransform RelativeOffset;

	UPROPERTY(Transient)
	bool bNoDepth = false;
	UPROPERTY(Transient)
	bool bVisibility = true;
	UPROPERTY(Transient)
	UGPUTurboInvalidationBox* GPUTurb = nullptr;


	UPROPERTY(BlueprintReadWrite, Transient)
	FString DebugName;

    bool bCanTick = true;
};


class KGUI_API SWorldWidget2 : public SBoxPanel
{
	SLATE_DECLARE_WIDGET(SWorldWidget2, SBoxPanel)
	friend class UWorldWidgetManager2;
	friend class SWorldWidgetLayer2;
public:
	FWorldWidgetParams2 WorldWidgetParams;

	TSharedPtr<SWidget> ContainerSWidget;
	TSharedPtr<SWidget> WidgetPrt;
	TWeakObjectPtr<UCurveFloat> DistanceScaleCurve;
	DECLARE_DELEGATE_TwoParams(FOnIsOnEdgeChanged, int, bool)
	FOnIsOnEdgeChanged OnIsOnEdgeChanged;
	DECLARE_DELEGATE_TwoParams(FOnDirectionChanged, int, const FVector2D&)
	FOnDirectionChanged OnDirectionChanged;
	DECLARE_DELEGATE_TwoParams(FHiddenDistanceEvent, int, bool)
	FHiddenDistanceEvent OnHiddenDistance;
	bool bHasGPUTurboWidget = false;
	TOptional<bool> IsInShowDist; // 在显示范围里面
	bool bIsOnEdge = false;
	float ScaleForGPUTurbo = 1.f;
	FTransform lastPosition;
	float TargetAlpha = 0;
	float CurrentAlpha = 0;
	float FadeSpeed = 5.0f;
public:
	void AttachChildWidget(TSharedRef<SWidget> InWidget);
	void RemoveChildWidget();

	void Reset();
	void ResetData();
	float GetShowAlpha(float InDeltaTime);
	void SetTargetAlpha(float InAlpha);
public:
	class FSlot : public SBoxPanel::TSlot<FSlot>
	{
	public:
		SLATE_SLOT_BEGIN_ARGS(FSlot, SBoxPanel::TSlot<FSlot>)

			FSlotArguments& AutoHeight()
			{
				_SizeParam = FAuto();
				return Me();
			}

			FSlotArguments& FillHeight(TAttribute<float> InStretchCoefficient)
			{
				_SizeParam = FStretch(MoveTemp(InStretchCoefficient));
				return Me();
			}

			FSlotArguments& MaxHeight(TAttribute<float> InMaxHeight)
			{
				_MaxSize = MoveTemp(InMaxHeight);
				return Me();
			}

		SLATE_SLOT_END_ARGS()

		void SetAutoHeight()
		{
			SetSizeToAuto();
		}

		void SetFillHeight(TAttribute<float> InStretchCoefficient)
		{
			SetSizeToStretch(MoveTemp(InStretchCoefficient));
		}

		void SetMaxHeight(TAttribute<float> InMaxHeight)
		{
			SetMaxSize(MoveTemp(InMaxHeight));
		}

		void Construct(const FChildren& SlotOwner, FSlotArguments&& InArgs)
		{
			SBoxPanel::TSlot<FSlot>::Construct(SlotOwner, MoveTemp(InArgs));
		}
	};

	static FSlot::FSlotArguments Slot()
	{
		return FSlot::FSlotArguments(MakeUnique<FSlot>());
	}

	SLATE_BEGIN_ARGS(SWorldWidget2)
		{
			_Visibility = EVisibility::SelfHitTestInvisible;
		}

		SLATE_SLOT_ARGUMENT(SWorldWidget2::FSlot, Slots)
	SLATE_END_ARGS()

	using FScopedWidgetSlotArguments = SBoxPanel::FScopedWidgetSlotArguments<SWorldWidget2::FSlot>;

	FScopedWidgetSlotArguments AddSlot()
	{
		return InsertSlot(INDEX_NONE);
	}

	FScopedWidgetSlotArguments InsertSlot(int32 Index = INDEX_NONE)
	{
		return FScopedWidgetSlotArguments(MakeUnique<FSlot>(), this->Children, Index);
	}

	FORCENOINLINE SWorldWidget2()
		: SBoxPanel(Orient_Vertical)
	{
		SetCanTick(false);
		bCanSupportFocus = false;
	}

public:
	void Construct(const FArguments& InArgs);

	void SetIsOnEdge(const int32 ID, bool bInIsOnEdge);

	void SetDirection(const int32 ID, FVector2D& Dir);

	void SetIsInHiddenDistance(const int32 ID, bool IsInDist);

	void SetScale(float Scale);

	void SetDistance(float ZOrder);

	FTransform GetTransform();
};
