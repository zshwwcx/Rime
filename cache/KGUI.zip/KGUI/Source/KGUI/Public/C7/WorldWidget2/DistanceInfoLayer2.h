// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "C7/WorldWidget2/WorldWidgetLayer2.h"

class KGUI_API SWorldWidgetDistanceInfoLayer2 : public SWorldWidgetLayer2
{
public:
	SLATE_BEGIN_ARGS(SWorldWidgetDistanceInfoLayer2)
		{
			_Visibility = EVisibility::SelfHitTestInvisible;
		}
	SLATE_END_ARGS()

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	void Construct(const FArguments& InArgs, const FLocalPlayerContext& InPlayerContext);
};
