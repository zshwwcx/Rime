#pragma once

#include "CoreMinimal.h"
#include "Layout/Visibility.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Engine/LocalPlayer.h"
#include "Widgets/SCompoundWidget.h"
#include "Slate/SGameLayerManager.h"
#include "WorldWidgetEnums2.h"
#include "Widgets/Layout/SConstraintCanvas.h"
#include "WorldWidget2.h"
#include "Components/GPUTurboInvalidationBox.h"
#include "Widgets/SlateGPUTurboWidgets.h"

struct FWWorldLayerData2
{
public:
	TSharedPtr<SWidget> ContainerWidget;
	TSharedPtr<class SWorldWidget2> SWorldWidget;
	SConstraintCanvas::FSlot* Slot = nullptr;
	TWeakObjectPtr<UUserWidget> UserWidget;
	TWeakObjectPtr<UGPUTurboInvalidationBox> GPUTurb;
	int32 WWID = 0;

	// 在 FWWorldLayerData2 类定义中添加
	bool operator==(const FWWorldLayerData2& Other) const
	{
		// 根据你的实际数据结构定义比较逻辑
		// 例如，如果有一个唯一ID字段：
		return this->WWID == Other.WWID && this->ContainerWidget == Other.ContainerWidget 
			&& this->SWorldWidget == Other.SWorldWidget
			&& this->UserWidget == Other.UserWidget
			&& this->GPUTurb == Other.GPUTurb;
	}
};

class KGUI_API SWorldWidgetLayer2 : public SCompoundWidget
{
	SLATE_BEGIN_ARGS(SWorldWidgetLayer2)
		{
			_Visibility = EVisibility::SelfHitTestInvisible;
		}
		SLATE_ATTRIBUTE(bool, UseSceneDepth)
		SLATE_ATTRIBUTE(EWorldWidgetLayerType2, LayerType)
	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, const FLocalPlayerContext& InPlayerContext);

	void EnableSmoothPosition(bool bEnable, float InnerRange, float OuterRange, float InterpSpeed);
	virtual void StopWorldWidget(int32 ID);
	virtual void RestoreWorldWidget(int32 ID);
	// void GetOrLoadFloatCurves(FName FloatCurveName);

	FVector2D SmoothPosition(FVector2D& TargetPos, FVector2D& CurrentPos, const float InDeltaTime, const float InnerRange, const float OuterRange, const float InterpSpeed);
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
	virtual FVector2D ComputeDesiredSize(float) const override;
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	virtual void AddWorldWidget(UUserWidget* UserWidget, int32 ID, TSharedRef<SWorldWidget2> NewWidget, UGPUTurboInvalidationBox* GPUTurb = nullptr)
	{
		TSharedPtr<FWWorldLayerData2>& WLData = WorldWidgetsData.FindOrAdd(ID);
		if (!WLData.IsValid())
		{
			WLData = MakeShared<FWWorldLayerData2>();
		}
		WLData->SWorldWidget = NewWidget;
		WLData->UserWidget = UserWidget;
		WLData->GPUTurb = GPUTurb;
		WLData->WWID = ID;
		WLData->SWorldWidget->bHasGPUTurboWidget = GPUTurb != nullptr;
		WLData->SWorldWidget->ScaleForGPUTurbo = 1.f;
		if (GPUTurb != nullptr) 
		{
			WLData->GPUTurb->SetSceneOcclusion(not NewWidget->WorldWidgetParams.bNoDepth);
		}
		else
		{
			WLData->SWorldWidget->SetSlateInViewDepth(0);
		}
		TSharedRef<SWidget> Widget = StaticCastSharedRef<SWidget>(NewWidget);
		Canvas->AddSlot()
		.Expose(WLData->Slot)
		[
			SAssignNew(WLData->ContainerWidget, SBox)
		[
			Widget
		]
		];

		WorldWidgetsArray.Add(WLData);
	}
	
	virtual void RemoveWorldWidget(int32 ID)
	{
		TSharedPtr<FWWorldLayerData2>* WLData = WorldWidgetsData.Find(ID);
		if (WLData->IsValid() == false) return;

		if (TSharedPtr<SWidget> ContainerWidget = WLData->Get()->ContainerWidget)
		{
			Canvas->RemoveSlot(ContainerWidget.ToSharedRef());
		}
		
		WorldWidgetsArray.Remove(*WLData);
		WorldWidgetsData.Remove(ID);
	}

	virtual void SetWorldWidgetNoDepth(int32 ID, SWorldWidget2* WorldWidget, bool bNoDepth)
	{
		if (WorldWidget->WorldWidgetParams.GPUTurb != nullptr)
		{
			WorldWidget->WorldWidgetParams.GPUTurb->SetSceneOcclusion(!bNoDepth);
		}
		else
		{
			WorldWidget->SetSlateInViewDepth(0);
		}
	}

	virtual bool HasChildren() 
	{
		return WorldWidgetsArray.Num() > 0;
	}

	virtual void ReserveContainer(int32 Num){}
public:
	TMap<int32, bool> MarkWorldWidgetIDs;
	float FogShowDistance = -1;
protected:
	bool bEnableSmoothPosition = false;
	bool bUseSceneDepth = false;
	float InnerSmoothRange = 0;
	float OuterSmoothRange = 0;
	float SmoothSpeed = 10;
	FLocalPlayerContext PlayerContext;
	TSharedPtr<SConstraintCanvas> Canvas;
	TMap<int32, TSharedPtr<FWWorldLayerData2>> WorldWidgetsData;
	TArray<TSharedPtr<FWWorldLayerData2>> WorldWidgetsArray;
	EWorldWidgetLayerType2 LayerType;
	int TickIndex = 0;
};

class FWorldWidgetLayer2 : public IGameLayer
{
public:
	FWorldWidgetLayer2(const FLocalPlayerContext& PlayerContext, EWorldWidgetLayerType2 InLayerType)
		: LocalPlayerContext(PlayerContext)
		, LayerType(InLayerType)
	{
	}
	
	void AddWorldWidget(UUserWidget* Widget, int32 ID, TWeakPtr<SWorldWidget2> NewWidget, UGPUTurboInvalidationBox* GPUTurb = nullptr);
	void RemoveWorldWidget(int32 ID);
	void StopWorldWidget(int32 ID);
	void RestoreWorldWidget(int32 ID);
	void EnableSmoothPosition(bool bEnable,float InnerRange,float OuterRange,float InterpSpeed);

	void SetFogShowDistance(float distance);

	void SetWorldWidgetNoDepth(int32 ID, SWorldWidget2* WorldWidget, bool NoDepth);
	
	void ReserveContainer(int32 Num);
	virtual bool HasChildren();
	virtual ~FWorldWidgetLayer2() override {}
public:
	virtual TSharedRef<SWidget> AsWidget() override;
	bool isInvisible = false;
	TWeakPtr<SWorldWidgetLayer2> GetWorldWidgetLayer() { return WorldWidgetLayer; }
protected:
	TWeakPtr<SWorldWidgetLayer2> WorldWidgetLayer;
	FLocalPlayerContext LocalPlayerContext;

	TMap<int32, TWeakPtr<SWorldWidget2>> WorldWidgetMap;
	EWorldWidgetLayerType2 LayerType;
};

class KGUI_API SWorldWidgetHeadInfoLayer2_Deprecate : public SWorldWidgetLayer2, public FGPUTurboLayer
{
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;
};