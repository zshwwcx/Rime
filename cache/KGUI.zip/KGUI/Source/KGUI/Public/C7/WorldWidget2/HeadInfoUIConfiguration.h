﻿#pragma once

#include "Engine/TextureDefines.h"
#include "Engine/DataTable.h"

#include "HeadInfoUIConfiguration.generated.h"


USTRUCT(Blueprintable, BlueprintType)
struct FHeadInfoUIConfiguration : public FTableRowBase
{
	GENERATED_BODY()

public:
	//用于屏蔽ApplicationScale，0表示不屏蔽，其余表示缩放比例
	UPROPERTY(EditAnywhere, Category = "DPIScale", Config)
	float DPIScale = 0.f;
};
