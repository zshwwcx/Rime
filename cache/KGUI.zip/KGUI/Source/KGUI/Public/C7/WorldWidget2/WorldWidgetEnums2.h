#pragma once

#include "CoreMinimal.h"


UENUM(BlueprintType)
enum class EWWConstrainType2 : uint8
{
	NONE,								//不限制
	CONSTRAIN_IN_SCREEN,				//限制在屏幕范围内
	CONSTRAIN_IN_OVAL__OUT_OF_OVAL,		//限制在椭圆范围内，出椭圆范围就进行限制
	CONSTRAIN_IN_OVAL__OUT_OF_SCREEN,	//限制在椭圆范围内，但是出屏幕范围才会显示在椭圆内
};

UENUM(BlueprintType)
enum class EWoldWidgetType2 : uint8
{
	NONE,
	RETAINERWIDGET,
	SBOX,
	SELFRETAINERWIDGET
};

UENUM(BlueprintType)
enum class EWorldWidgetLayerType2 : uint8
{
	Normal = 0,
	HeadInfo = 1,
	FlameJump = 2,
	DamageEffect = 3,
	DistanceInfo = 4,
    Max
};
