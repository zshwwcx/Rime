#pragma once

#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "WorldWidgetEnums2.h"
#include "WorldWidget2.h"
#include "WorldWidgetLayer2.h"
#include "Components/CanvasPanel.h"
#include "WorldWidgetManager2.generated.h"

//WorldWidget运行状态数据
USTRUCT(BlueprintType)
struct FWorldWidgetData2
{
	GENERATED_BODY()

public:
	FWorldWidgetData2()
	{
		bVisibility = false;
	};


	//ID
	UPROPERTY(BlueprintReadWrite, Transient)
	int32 ID = 0;

	//参考位置
	UPROPERTY(BlueprintReadWrite, Transient)
	FVector Pos = FVector::ZeroVector;

	//显示
	UPROPERTY(BlueprintReadWrite, Transient)
	uint32 bVisibility : 1;

public:
	//关联的WorldWidget
	TWeakPtr<SWorldWidget2> WorldWidgetPtr;

	TWeakObjectPtr<UUserWidget> ChildWidget;

	FString LayerName;

public:
	void Reset()
	{
		ID = 0;
		Pos = FVector::ZeroVector;
		bVisibility = false;
		WorldWidgetPtr.Reset();
		ChildWidget.Reset();
	}
};

USTRUCT()
struct FWorldWidgetMap2
{
	GENERATED_BODY()
public:
	TWeakPtr<SWorldWidget2> GetFreeWidget();

	void ReleaseWidget(SWorldWidget2* InWidget);

	void Cleanup();

private:
	TArray<TSharedRef<SWorldWidget2>> FreeWidgets;

	TMap<SWorldWidget2*, TSharedRef<SWorldWidget2>> UseWidgetMap;
};

UDELEGATE()
DECLARE_DYNAMIC_DELEGATE_TwoParams(FWorldWidgetManager2_RemoveWorldWidget, int32, ID, UUserWidget*, ChildWidget);

UDELEGATE()
DECLARE_DYNAMIC_DELEGATE_TwoParams(FWorldWidgetManager2_IsOnEdgeChanged, int32, ID, bool, bOnEdge);

UDELEGATE()
DECLARE_DYNAMIC_DELEGATE_ThreeParams(FWorldWidgetManager2_DirectionChanged, int32, ID, float, DirX, float, DirY);

UDELEGATE()
DECLARE_DYNAMIC_DELEGATE_TwoParams(FWorldWidgetManager2_HiddenDistance, int32, ID, bool, bIsEnter);

UCLASS(Blueprintable, BlueprintType)
class KGUI_API UWorldWidgetManager2 : public UKGBasicManager
{
	GENERATED_UCLASS_BODY()
#pragma region KGBasicManager

public:
	virtual void NativeInit() override;
	virtual void NativeUninit() override;
	virtual EManagerType GetManagerType() override { return EManagerType::EMT_WorldWidgetManager2; }

	static UWorldWidgetManager2* GetInstance(UObject* InContext)
	{
		return Cast<UWorldWidgetManager2>(GetManagerByType(InContext, EManagerType::EMT_WorldWidgetManager2));
	}
#pragma endregion KGBasicManager

#pragma region Delegate
	UPROPERTY(Transient)
	FWorldWidgetManager2_IsOnEdgeChanged IsOnEdgeChanged;

	UPROPERTY(Transient)
	FWorldWidgetManager2_DirectionChanged DirectionChanged;

	UPROPERTY(Transient)
	FWorldWidgetManager2_HiddenDistance HiddenDistance;
#pragma endregion Delegate

public:

protected:

	UPROPERTY(Transient)
	UUserWidget* OwningWidget = nullptr;

	UPROPERTY(Transient)
	FString DefaultMaterialPath;

	UPROPERTY(Transient)
	TArray<FWorldWidgetParams2> PendingCreateWorldWidgetTasks;

	UPROPERTY(Transient)
	TArray<int32> PendingDeleteWorldWidgetTasks;

	TArray<TPair<int32, FVector>> PendingWTransformTasks;

#pragma region WidgetManager

public:
	/**
	 * 创建一个WorldWidget
	 * 返回 对应的WorldWidget 唯一ID
	 */
	int32 CreateWorldWidget(FWorldWidgetParams2 InParams);

	void DeleteWorldWidget(int32 ID);

	void StopWorldWidget(int32 ID);

	void RestoreWorldWidget(FWorldWidgetParams2 InParams);

	void SetWorldWidgetPosition(int32 ID, FVector NewPos);

	void SetWorldWidgetWorldOffset(int32 ID, FVector NewOffset);
	void SetWorldWidgetSocket(int32 ID, const FName& SocketName);
	void SetWorldWidgetWorldHideDistance(int32 ID, float Distance);

	void SetWorldWidgetVisibilty(int32 ID, bool Visibilty);

	void SetWorldWidgetNoDepth(int32 ID, bool NoDepth);
    void SetLayerVisibility(EWorldWidgetLayerType2 LayerType, bool bVisible);

	void SetWorldWidgetUID(int32 ID, uint64 NewUID);

	TWeakObjectPtr<UCurveFloat> GetCurve(const FName& CurveName);

	void LoadOrGetCurve(const FName& CurveName);

    TWeakPtr<FWorldWidgetLayer2> GetWorldWidgetLayer(FString InName);
    static FString GetWorldWidgetLayerNameByEnum(EWorldWidgetLayerType2 InLayerType);
    static int64 GetWorldWidgetLayerTypeByName(const FString& InLayerName);
public:
	UFUNCTION(BlueprintCallable)
	void SetParentLayer(UCanvasPanel* InParentLayer);

	UFUNCTION(BlueprintCallable)
	void OnIsOnEdgeChanged(int32 ID, bool bOnEdge) const;

	UFUNCTION(BlueprintCallable)
	void OnDirectionChanged(int32 ID, const FVector2D& Dir) const;

	void OnHiddenDistance(int32 ID, bool bIsEnter);

	void SetFogShowDistance(float Distance);

	void ReverseLayerContainer(FString InName, int32 Num);
public:
	//默认层名称("WorldWidgetLayer")
	UFUNCTION(BlueprintCallable)
	bool InitWorldWidgetLayer(EWorldWidgetLayerType2 InLayerType, int32 LayerZOrder = -100, int Count = 20);

protected:
	UFUNCTION(BlueprintCallable)
	static int32 GenerateWorldWidgetID();

	bool bEnableSmoothPosition = false;
	float InnerSmoothRange = 0;
	float OuterSmoothRange = 0;
	float SmoothSpeed = 10;
	UFUNCTION(BlueprintCallable)
	void EnableSmoothPosition(bool bEnable, float InnerRange, float OuterRange, float InterpSpeed);

public:

protected:
	UPROPERTY(BlueprintReadWrite, Transient)
	TMap<int32, FWorldWidgetData2> WWidgetDataMap;

	UPROPERTY(Transient)
	FWorldWidgetMap2 WorldWidgetPool;

	//2D UI Layer层
	TMap<FString, TSharedRef<FWorldWidgetLayer2>> WWidgetLayers;

	UPROPERTY(Transient)
	TMap<FName, UCurveFloat*> Curves;

	UPROPERTY(Transient)
	TWeakObjectPtr<UGameInstance> GIPtr;


	UPROPERTY(Transient)
	TWeakObjectPtr<UCanvasPanel> ParentLayer;

	FMatrix LastViewProjectionMatrix;

public:
	UFUNCTION(BlueprintCallable)
	void CreateWorldWidgetLayer(EWorldWidgetLayerType2 InLayerType, int32 InDepth);

	//初始默认层名称
	UPROPERTY(BlueprintReadWrite)
	FString DefaultWWidgetLayerName = "Normal";
#pragma endregion WidgetManager
};
