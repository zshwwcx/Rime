// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: lishihao07@kuaishou.com

#pragma once

#include "HeadInfoUIConfiguration.h"
#include "C7/WorldWidget2/WorldWidgetLayer2.h"


struct FTickWorkContext
{
	TArray<int32> KeyList;
	FVector PawnLocation;
	TArray<bool> bNeedChangeVisibilityList;
	TArray<bool> bInViewList;
	TArray<float> GPUViewDepthList;
	TArray<float> GPUZOrderList;
	TArray<float> GPUOpacityList;
	TArray<FSlateRenderTransform> GPUTransformList;

	float DeltaTime = 0.0f;
	FVector CameraForward;
	FVector ViewOrigin;
	FMatrix ViewProjectionMatrix;
	UE::Slate::FDeprecateVector2DResult ViewportSize;

	float BaseScale = 1.0;


	void Reset(int Num)
	{
		PawnLocation = FVector::ZeroVector;
		bNeedChangeVisibilityList.Reset();
		bNeedChangeVisibilityList.AddZeroed(Num);
		GPUViewDepthList.Reset();
		GPUViewDepthList.AddZeroed(Num);

		GPUZOrderList.Reset();
		GPUZOrderList.AddZeroed(Num);

		GPUTransformList.Reset();
		GPUTransformList.AddZeroed(Num);

		bInViewList.Reset();
		bInViewList.AddZeroed(Num);

		GPUOpacityList.Reset();
		GPUOpacityList.AddZeroed(Num);
		CameraForward = FVector::ZeroVector;
		ViewOrigin = FVector::ZeroVector;
		ViewProjectionMatrix = FMatrix::Identity;
		ViewportSize = UE::Slate::FDeprecateVector2DResult();
	}

};

//SHeadInfoFakeContainer是个特殊的Widget，预先批量挂在SWorldWidgetHeadInfoLayer2下，HeadInfoWorldWidget挂在这个Widget下，可以避免Canvas的子节点增删导致全canvas失效
//针对InvalidationBox的失效策略，做了一些防御性的hack
//1.DesiredSize不变可以防止该节点增删子节点导致的LayoutInvalidation传递到父节点
//2.不可Tick
class KGUI_API SHeadInfoFakeContainer : public SCompoundWidget
{
	SLATE_BEGIN_ARGS(SHeadInfoFakeContainer)
	{
		_Visibility = EVisibility::SelfHitTestInvisible;
	}
	SLATE_END_ARGS()
	
	virtual FVector2D ComputeDesiredSize(float) const override;
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

public:
	void Construct(const FArguments& InArgs)
	{
		SetCanTick(false);
	}
	void SetContent(TSharedRef<SWidget> InContent)
	{
		ChildSlot[InContent];
	}
	void SetReflectionDebugName(const FName& InName);
};

class KGUI_API SWorldWidgetHeadInfoLayer2 : public SWorldWidgetLayer2, public FGPUTurboLayer
{
public:
	SLATE_BEGIN_ARGS(SWorldWidgetHeadInfoLayer2)
	{
		_Visibility = EVisibility::SelfHitTestInvisible;
	}
	SLATE_END_ARGS()
	
	void Construct(const FArguments& InArgs, const FLocalPlayerContext& InPlayerContext);
	
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	//BEGIN ADD BY chengfeng@kuaishou.com : MULTTHREAD VERSION
	void Tick2(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime);
	//auto WorldPosToScreenPos = [CameraForward, ViewOrigin, ViewProjectionMatrix, ViewportSize]()
	bool WorldToScreen(const FVector& CameraForward, const FVector& ViewOrigin, const FMatrix& ViewProjectionMatrix, const UE::Slate::FDeprecateVector2DResult& ViewportSize,
		const FVector& WorldPos, FVector2D& OutScreenPos, double& ViewDist);
	void GetViewProjectionMatrix(FMatrix& OutMat);
	void TickHeadInfoWidget(FTickWorkContext& TickContext, int idx);
	//END BY chengfeng@kuaishou.com

	virtual FVector2D ComputeDesiredSize(float LayoutScaleMultiplier) const override { return FVector2D::Zero(); }
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	virtual void AddWorldWidget(UUserWidget* UserWidget, int32 ID, TSharedRef<SWorldWidget2> NewWidget, UGPUTurboInvalidationBox* GPUTurb) override;
	virtual void RemoveWorldWidget(int32 ID) override;
	virtual void StopWorldWidget(int32 ID) override;
	virtual void RestoreWorldWidget(int32 ID) override;
	virtual void SetWorldWidgetNoDepth(int32 ID, SWorldWidget2* WorldWidget, bool bNoDepth) override;
	virtual void ReserveContainer(int32 Num) override{ ReserveCacheContainer(Num); }
	virtual bool HasChildren() override;
private:
	void ReserveCacheContainer(int Num);
	
	TSharedPtr<SInvalidationPanel> InvalidationPanel;

	struct FContainerInfo
	{
		TSharedPtr<SHeadInfoFakeContainer> HeadInfoFakeContainer;
		SConstraintCanvas::FSlot* Slot = nullptr;
	};
	TArray<FContainerInfo> ContainerPool;
	TArray<int32> FreeContainer;


	struct FHeadInfoRootData
	{
		int32 ContainerID;
		TSharedPtr<SGPUTurboRootWidget> GPURoot;
		TSharedPtr<SWorldWidget2> WorldWidget;
	};

	TMap<int32, FHeadInfoRootData> WWIDToHeadInfoRootDataMap;
	TMap<int32, FHeadInfoRootData> NoUseHeadInfoDataMap;

private:
	void ReadHeadInfoUIConfig();
	FHeadInfoUIConfiguration HeadInfoUIConfig;
};