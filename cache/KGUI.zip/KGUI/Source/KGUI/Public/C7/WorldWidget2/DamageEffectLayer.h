// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "SceneView.h"
#include "C7/WorldWidget2/WorldWidgetLayer2.h"
#include "Misc/CommonDefines.h"
#include "DamageEffectLayer.generated.h"

USTRUCT(BlueprintType)
struct KGUI_API FDamageTextStyle
{
    GENERATED_USTRUCT_BODY()
    
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FSlateColor ColorAndOpacity = FLinearColor::White;
    
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FSlateFontInfo Font;
    
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FSlateBrush StrikeBrush;
    
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector2D ShadowOffset = FVector2D::UnitVector;
    
    UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=( DisplayName="Shadow Color" ))
    FLinearColor ShadowColorAndOpacity = FLinearColor::Transparent;
};

/**
 * SDamageEffectLayer
 */
class KGUI_API SWorldWidgetDamageEffectLayer : public SWorldWidgetLayer2
{
public:
    SLATE_BEGIN_ARGS(SWorldWidgetDamageEffectLayer)
    {
        _Visibility = EVisibility::SelfHitTestInvisible;
    }
        SLATE_ATTRIBUTE(bool, UseSceneDepth)
        SLATE_ATTRIBUTE(EWorldWidgetLayerType2, LayerType)
    SLATE_END_ARGS()

    void Construct(const FArguments& InArgs, const FLocalPlayerContext& InPlayerContext);
    virtual void AddWorldWidget(UUserWidget* UserWidget, int32 ID, TSharedRef<SWorldWidget2> NewWidget, UGPUTurboInvalidationBox* GPUTurbo = nullptr) override;
    virtual void RemoveWorldWidget(int32 ID) override;    

    virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
    virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;
    virtual bool HasChildren() override
    {
        return ActivatedDamageTextItems.Num() > 0;
    }
    
#pragma region DamageTextItem
private:
    struct FProjectContext
    {
        TWeakObjectPtr<APlayerController> PlayerController;
        FSceneViewProjectionData ProjData;
        FMatrix ViewProjMat;
        FGeometry ViewportGeometry;
        FVector PlayerControllerPos;
        
        FProjectContext() = default;
        explicit FProjectContext(APlayerController* InPlayerController, const FSceneViewProjectionData& InProjData, const FMatrix& InViewProjMat, const FGeometry& InViewportGeometry, const FVector& InPlayerControllerPos)
            : PlayerController(InPlayerController)
            , ProjData(InProjData)
            , ViewProjMat(InViewProjMat)
            , ViewportGeometry(InViewportGeometry)
            , PlayerControllerPos(InPlayerControllerPos)
        {
        }
    };
public:
    static constexpr int32 INVALID_TOKEN = -1;
    enum EDamageTextVisFlag
    {
        DTVisFlag_Visible = 0,
        DTVisFlag_HideByOuterLogic = 0x01 << 0,
        DTVisFlag_HideByDistCheck = 0x01 << 1,
        DTVisFlag_HideByNoProjData = 0x01 << 2,
        DTVisFlag_HideByFogDistCheck = 0x01 << 3,
        DTVisFlag_HideByProjFailed = 0x01 << 4,
    };
    struct FDamageTextItem
    {
        friend class SWorldWidgetDamageEffectLayer;
        friend struct FDamageTextItemPool;
        
        FVector2D Location = {0., 0.};
        FVector2D ActorPosOnLayer = {0., 0.0};
        FVector WorldPos = {0, 0, 0};
        FVector2D Scale = {1., 1.};
        
        float Opacity = 1.f;
        int32 DamageValue = 0;
        int32 ZOrder = -1;
        int64 RefActorID = KG_INVALID_ACTOR_ID;
        FName SocketName;
        FDamageTextStyle Style;
        FString DmgStr;
        FString SignStr;
        bool bCanTick = true;
        
    private:
        FVector2D DmgValSize = {-1., -1.};
        FVector2D DmgSignSize = {-1., -1.};
        
        int32 Token = INVALID_TOKEN;
        int32 PoolSlotIndex = INVALID_TOKEN;
        TOptional<float> LayoutScaleMultiplierValue;
        TEnumAsByte<EDamageTextVisFlag> VisibilityFlags = DTVisFlag_Visible;
    public:
        void Clear()
        {
            Token = INVALID_TOKEN;
            PoolSlotIndex = INVALID_TOKEN;
            WorldPos = {0, 0, 0};
            ActorPosOnLayer = {0, 0};
            Location = {0, 0};
            Scale = {1, 1};
            Opacity = 1.f;
            DamageValue = 0;
            DmgStr = TEXT("");
            SignStr = TEXT("");
            bCanTick = true;
            RefActorID = KG_INVALID_ACTOR_ID;
            LayoutScaleMultiplierValue.Reset();
            DmgValSize.X = -1.;
            DmgValSize.Y = -1.;
            DmgSignSize.X = -1.;
            DmgSignSize.Y = -1.;
            SocketName = NAME_None;
            VisibilityFlags = DTVisFlag_Visible;
        }
        
        bool operator<(const FDamageTextItem& Other) const
        {
            return ZOrder < Other.ZOrder;
        }
        
        FVector2D GetDmgValTextSize(float InLayoutScaleMultiplierValue);
        FVector2D GetDmgSignTextSize(float InLayoutScaleMultiplierValue);
        
        void SetVisibilityFlag(TEnumAsByte<EDamageTextVisFlag> InFlag)
        {
            VisibilityFlags = InFlag;
        }
        
        void AppendVisibilityFlag(EDamageTextVisFlag InFlag)
        {
            uint8 Value = VisibilityFlags.GetIntValue();
            Value |= InFlag;
            VisibilityFlags = static_cast<EDamageTextVisFlag>(Value);
        }
        
        void RemoveVisibilityFlag(EDamageTextVisFlag InFlag)
        {
            uint8 Value = VisibilityFlags.GetIntValue();
            Value &= ~InFlag;
            VisibilityFlags = static_cast<EDamageTextVisFlag>(Value);
        }
        
        bool HasAnyVisibilityFlags(EDamageTextVisFlag InFlags) const
        {
            return (VisibilityFlags.GetIntValue() & InFlags) != 0;
        }
        
        bool IsValid() const
        {
            return Token != INVALID_TOKEN;
        }
        
        bool IsVisible() const
        {
            return IsValid() && VisibilityFlags.GetIntValue() == 0;
        }
        
        bool CanTick() const
        {
            return IsValid() && bCanTick;
        }
        
        int32 GetToken() const { return Token; }
    private:
        uint32 GenerateToken();
    };
    static FDamageTextItem NullDamageText;
private:
    struct FDamageTextItemPool
    {
    private:
        TArray<FDamageTextItem> Pool;
        TQueue<int32> FreeSlots;
        int32 LastValidIndex = 0;
    public:
        void Init(int32 InAllocCount = 128)
        {
            Pool.Reserve(InAllocCount);
            Pool.AddDefaulted(InAllocCount);
            FreeSlots.Empty();
            LastValidIndex = 0;
        }
        
        FDamageTextItem& Obtain();
        
        bool Recycle(const FDamageTextItem& InTextItem)
        {
            int32 PoolSlotIndex = InTextItem.PoolSlotIndex;
            if(InTextItem.Token != INVALID_TOKEN && Pool.IsValidIndex(PoolSlotIndex))
            {
                Pool[PoolSlotIndex].Clear();
                FreeSlots.Enqueue(PoolSlotIndex);
                return true;
            }
            return false;
        }
    };

    FDamageTextItemPool DamageTextItemsPool;
    TMap<int32, FDamageTextItem*> ActivatedDamageTextItems;
    TArray<FDamageTextItem*> DamageTextItemsHeap;
    float HiddenDistance = -1.f; // 隐藏距离
protected:
    void PaintDamageText(FDamageTextItem& InItem, const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const;
    void DoProjectAndCulling(FDamageTextItem& InItem, const FProjectContext& ProjectContext, const FGeometry& AllottedGeometry, const float InDeltaTime);
    static FTransform GetActorTransform(uint64 ActorObjID, FName SocketName, const FVector& DefaultPos);
public:
    static bool IsNull(const FDamageTextItem& InItem);
    static bool IsNull(const FDamageTextItem* InItem);
    FDamageTextItem& GetDamageTextItem(int32 InToken);
    const FDamageTextItem& GetDamageTextItem(int32 InToken) const;
    int32 ShowDamageText(int64 RefActorID, int32 InDamageValue, const FString& InDamageValStr, const FDamageTextStyle& InStyle, int32 InSign, FName SocketName);
    void RemoveDamageText(int32 InToken, bool bRebuildHeap = false);
    bool UpdateDamageText(int32 InToken, const FVector2D& InLocation, const FVector2D& InScale, float InOpacity, bool bVisible, bool bCanTick);
    void SetDamageTextFontStyle(int32 InToken, const FDamageTextStyle& InStyle);
    void SetDamageTextLocation(int32 InToken, const FVector2D& Location);
    void SetDamageTextScale(int32 InToken, const FVector2D& Scale);
    void SetDamageTextOpacity(int32 InToken, float InOpacity);
    void SetDamageTextVisibility(int32 InToken, bool bVisible);
    void SetDamageTextCanTick(int32 InToken, bool bCanTick);
    void SetDamageTextZOrder(int32 InToken, int32 InZOrder);
    void SetDamageTextRefActorID(int32 InToken, uint64 InActorID);
    void SetDamageTextSocketName(int32 InToken, FName InSocketName);
    void SetDamageTextWorldPos(int32 InToken, const FVector& InWorldPos);
    
    void RebuildDamageTextItemsHeap();
#pragma endregion
};

