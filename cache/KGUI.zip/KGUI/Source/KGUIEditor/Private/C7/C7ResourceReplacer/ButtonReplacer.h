#pragma once
#include "ResourceReplacer.h"

class FButtonReplacer : public FResourceReplacer
{

};

