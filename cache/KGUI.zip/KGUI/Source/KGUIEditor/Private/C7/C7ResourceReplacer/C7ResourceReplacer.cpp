// Copyright Epic Games, Inc. All Rights Reserved.
#include "CoreMinimal.h"
#include "C7ResourceReplacer.h"
#include "C7ResourceReplacerStyle.h"
#include "C7ResourceReplacerCommands.h"
#include "LevelEditor.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"
#include "ToolMenus.h"
#include "Components/Button.h"
#include "UMG/Components/KGButton.h"
#include "UMG/Components/KGCheckBox.h"
#include "ResourceReplacer.h"
#include "ScopedTransaction.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Blueprint/UserWidget.h"
#include "Blueprint/WidgetTree.h"
#include "Components/GPUTurboImage.h"
#include "UMG/Components/KGHotArea.h"
#include "Misc/FileHelper.h"
#include "Containers/StringFwd.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "UMG/Components/KGGPUTurboImage.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Editor/BlueprintGraph/Classes/K2Node_Variable.h"
#include "EdGraph/EdGraphNode.h"
#include "K2Node_CallFunction.h"
#include "K2Node_DynamicCast.h"
#include "K2Node_FunctionEntry.h"
#include "Components/CanvasPanel.h"
#include "UMG/Components/KGInteractableArea.h"
#include "Components/PanelWidget.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "UObject/SavePackage.h"
#include "AssetDefinitionRegistry.h"
#include "EditorUtilityLibrary.h"
#include "Engine/DataTable.h"
#include "Engine/AssetManager.h"
#include "AssetRegistry/AssetIdentifier.h"
#include "PaperSpriteAtlas.h"
#include "DataTableEditorUtils.h"
#include "Core/Common.h"
#include "Components/NamedSlotInterface.h"
#include "Animation/WidgetAnimation.h"
#include "MovieScene.h"
#include "UObject/MetaData.h"
#include "Components/ListViewBase.h"

#pragma optimize("", off)

static const FName C7ResourceReplacerTabName("C7ResourceReplacer");

FAutoConsoleCommand KGUIAnimAreaTransfer(TEXT("KGUI.AnimAreaTransferWithFile"), TEXT("KGUI.AnimAreaTransferWithFile"),
	FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
		{
			const FString& FilePath = Args[0];
			TArray<FString> BlueprintNames;
			if (!FFileHelper::LoadFileToStringArray(BlueprintNames, *FilePath))
			{
				UE_LOG(LogTemp, Error, TEXT("[AnimAreaTransferWithFile]Failed to read input file: %s"), *FilePath);
				return ;
			}

			// 清理路径格式（移除空白行和注释）
			BlueprintNames.RemoveAll([](const FString& Line) {
				return Line.TrimStartAndEnd().IsEmpty() || Line.StartsWith("//");
				});

			auto FindUMGBlueprintsByName = [](const FString& Name, TArray<FAssetData>& OutAssets)
				{
					FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
					AssetRegistryModule.Get().SearchAllAssets(true);

					// 构建筛选条件
					FARFilter Filter;
					Filter.ClassPaths.Add(UWidgetBlueprint::StaticClass()->GetClassPathName());
					Filter.bRecursivePaths = true;

					TArray<FAssetData> AllUMGAssets;
					AssetRegistryModule.Get().GetAssets(Filter, AllUMGAssets);

					// 精确匹配资产名称（不包含路径）
					const FString TargetName = Name.TrimStartAndEnd();
					for (const FAssetData& Asset : AllUMGAssets)
					{
						if (Asset.AssetName.ToString().Equals(TargetName, ESearchCase::IgnoreCase))
						{
							OutAssets.Add(Asset);
						}
					}

					return OutAssets.Num() > 0;
				};

			FScopedSlowTask SlowTask(BlueprintNames.Num(), FText::FromString(TEXT("Processing Widget Blueprint...")));
			SlowTask.MakeDialog();

			// 遍历并处理每个蓝图
			int32 ProcessedCount = 0;
			for (const FString& Name : BlueprintNames)
			{
				SlowTask.EnterProgressFrame(1.0f);
				TArray<FAssetData> FoundAssets;
				if (!FindUMGBlueprintsByName(Name, FoundAssets))
				{
					UE_LOG(LogTemp, Warning, TEXT("[AnimAreaTransferWithFile]No UMG blueprint found with name: %s"), *Name);
					continue;
				}

				for (auto& Asset : FoundAssets)
				{
					const FString AssetPath = Asset.GetObjectPathString();

					// 加载蓝图
					UWidgetBlueprint* WidgetBP = LoadObject<UWidgetBlueprint>(nullptr, *AssetPath);
					if (!WidgetBP)
					{
						UE_LOG(LogTemp, Warning, TEXT("[AnimAreaTransferWithFile]Failed to load UMG blueprint: %s"), *AssetPath);
						continue;
					}

					// 执行自定义操作
					FAssetTypeActions_KGUI::ReplaceOrAddKGAnimArea(WidgetBP);

					// 保存蓝图包
					//UPackage* Package = WidgetBP->GetPackage();
					//FString PackageFileName = FPackageName::LongPackageNameToFilename(Package->GetName(), FPackageName::GetAssetPackageExtension());
					//FSavePackageArgs SaveArgs;
					//SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
					//SaveArgs.SaveFlags = SAVE_NoError;
					//bool bSaved = UPackage::SavePackage(Package, nullptr, *PackageFileName, SaveArgs);
					// if (!bSaved)
					// {
					// 	UE_LOG(LogTemp, Warning, TEXT("[AnimAreaTransferWithFile]Failed to save blueprint: %s"), *WidgetBP->GetName());
					// }
					ProcessedCount++;

					UE_LOG(LogTemp, Display, TEXT("[AnimAreaTransferWithFile]Processed: %s"), *AssetPath);
				}
			}

			UE_LOG(LogTemp, Display, TEXT("[AnimAreaTransferWithFile]Process done!!"));
		}));

#define LOCTEXT_NAMESPACE "FC7ResourceReplacerModule"

void FC7ResourceReplacerModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	
	FC7ResourceReplacerStyle::Initialize();
	FC7ResourceReplacerStyle::ReloadTextures();

	FC7ResourceReplacerCommands::Register();
	
	PluginCommands = MakeShareable(new FUICommandList);

	PluginCommands->MapAction(
		FC7ResourceReplacerCommands::Get().OpenPluginWindow,
		FExecuteAction::CreateRaw(this, &FC7ResourceReplacerModule::PluginButtonClicked),
		FCanExecuteAction());

	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FC7ResourceReplacerModule::RegisterMenus));
	
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(C7ResourceReplacerTabName, FOnSpawnTab::CreateRaw(this, &FC7ResourceReplacerModule::OnSpawnPluginTab))
		.SetDisplayName(LOCTEXT("FC7ResourceReplacerTabTitle", "C7ResourceReplacer"))
		.SetMenuType(ETabSpawnerMenuType::Hidden);

	ResourceReplacer = FResourceReplacer::GetReplacer();
	ProcessPath = "/Arts/UI_2/Blueprint/Mail/Test";


	IAssetTools& AssetToolsModule = FAssetToolsModule::GetModule().Get();
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_KGUI(EAssetTypeCategories::Type::UI)));
}

void FC7ResourceReplacerModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.

	UToolMenus::UnRegisterStartupCallback(this);

	UToolMenus::UnregisterOwner(this);

	FC7ResourceReplacerStyle::Shutdown();

	FC7ResourceReplacerCommands::Unregister();

	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(C7ResourceReplacerTabName);
}

TSharedRef<SDockTab> FC7ResourceReplacerModule::OnSpawnPluginTab(const FSpawnTabArgs& SpawnTabArgs)
{
	FText WidgetText = FText::Format(
		LOCTEXT("WindowWidgetText", "Add code to {0} in {1} to override this window's contents"),
		FText::FromString(TEXT("FC7ResourceReplacerModule::OnSpawnPluginTab")),
		FText::FromString(TEXT("C7ResourceReplacer.cpp"))
		);

	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		[
			// Put your tab content here!
			/*SNew(SBox)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			[
				SNew(STextBlock)
				.Text(WidgetText)
			]*/
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.Padding(10)
				.AutoWidth()
				[
					SNew(STextBlock)
					.Text(LOCTEXT("", "Path: /Game"))
				]
				+SHorizontalBox::Slot()
				.FillWidth(1.0f)
				[
					SNew(SEditableTextBox)
					.Text(FText::FromString(ProcessPath))
					.OnTextChanged_Raw(this, &FC7ResourceReplacerModule::OnPathChanged)
				]
				+ SHorizontalBox::Slot()
				.FillWidth(0.5f)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("", "DefaultPath: /Game/Arts/UI_2/Blueprint"))
				]
			]
			+SVerticalBox::Slot()
			.FillHeight(10)
			[
				SNew(SBox)
			]
			+SVerticalBox::Slot()
			.VAlign(VAlign_Bottom)
			.FillHeight(1)
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				
				[
					SNew(SButton)
					.Text(LOCTEXT("", "ReplaceButton"))
					.OnClicked(FOnClicked::CreateRaw(this, &FC7ResourceReplacerModule::ButtonReplaceClicked))
				]
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				.AutoWidth()
				[
				SNew(SButton)
				.Text(LOCTEXT("", "ReplaceCheckBox"))
				.OnClicked(FOnClicked::CreateRaw(this, &FC7ResourceReplacerModule::CheckBoxReplaceClicked))
				]
				/*+ SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				.AutoWidth()
				[
					SNew(SButton)
					.Text(LOCTEXT("", "BatchSetAudio"))
				.OnClicked(FOnClicked::CreateRaw(this, &FC7ResourceReplacerModule::BatchSetAudioClicked))
				]*/
			]
		];
}

void FC7ResourceReplacerModule::PluginButtonClicked()
{
	FGlobalTabmanager::Get()->TryInvokeTab(C7ResourceReplacerTabName);
	//ResourceReplacer->GetResource(EResourceType::Button, "/Game/Arts/UI_2/Blueprint/Mail/Test");
	//ResourceReplacer->StartReplace(EResourceType::Button, "/Game/Arts/UI_2/Blueprint/Common");
	//ResourceReplacer->StartReplace(EResourceType::Button, "/Game/Arts/UI_2/Blueprint");
	
	//ResourceReplacer->BatchSetAudioTags();

}

void FC7ResourceReplacerModule::RegisterMenus()
{
	// Owner will be used for cleanup in call to UToolMenus::UnregisterOwner
	FToolMenuOwnerScoped OwnerScoped(this);

	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Window");
		{
			FToolMenuSection& Section = Menu->FindOrAddSection("WindowLayout");
			Section.AddMenuEntryWithCommandList(FC7ResourceReplacerCommands::Get().OpenPluginWindow, PluginCommands);
		}
	}

	{
		UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar");
		{
			FToolMenuSection& Section = ToolbarMenu->FindOrAddSection("Settings");
			{
				FToolMenuEntry& Entry = Section.AddEntry(FToolMenuEntry::InitToolBarButton(FC7ResourceReplacerCommands::Get().OpenPluginWindow));
				Entry.SetCommandList(PluginCommands);
			}
		}
	}
}

FReply FC7ResourceReplacerModule::ButtonReplaceClicked()
{
	if (!ProcessPath.IsEmpty())
	{
		ResourceReplacer->ReplaceWidgets(UButton::StaticClass(), UKGButton::StaticClass(), GetFullProcessPath());
	}
	
	return FReply::Handled();
}
FReply FC7ResourceReplacerModule::CheckBoxReplaceClicked()
{
	if (!ProcessPath.IsEmpty())
	{
		ResourceReplacer->ReplaceWidgets(UCheckBox::StaticClass(), UKGCheckBox::StaticClass(), GetFullProcessPath());
	}

	return FReply::Handled();
}
FReply FC7ResourceReplacerModule::BatchSetAudioClicked()
{
	if (!ProcessPath.IsEmpty())
	{
		ResourceReplacer->BatchSetAudioTags();
		/*FString o = FString("btn");
		FString n = FString("btn");
		ResourceReplacer->ReplaceWidgetName(o, n, GetFullProcessPath());*/
	}
	return FReply::Handled();
}

void FC7ResourceReplacerModule::OnPathChanged(const FText& NewString)
{
	if (!NewString.IsEmpty())
		ProcessPath = NewString.ToString();
	else
		ProcessPath = "/Arts/UI_2/Blueprint";
}

FString FC7ResourceReplacerModule::GetFullProcessPath()
{
	return "/Game" + ProcessPath;
}




FAssetTypeActions_KGUI::FAssetTypeActions_KGUI(EAssetTypeCategories::Type InAssetCategory)
{
}

FText FAssetTypeActions_KGUI::GetName() const
{
	return LOCTEXT("AssetTypeActions_WidgetBlueprint", "Widget Blueprint");
}

FColor FAssetTypeActions_KGUI::GetTypeColor() const
{
	return FColor(44, 89, 180);
}

UClass* FAssetTypeActions_KGUI::GetSupportedClass() const
{
	return UWidgetBlueprint::StaticClass();
}

void FAssetTypeActions_KGUI::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{
	TArray<TWeakObjectPtr<UWidgetBlueprint>> WidgetBlueprints;
	for (auto& Object : InObjects)
	{
		if (Object && Object->IsA<UWidgetBlueprint>())
		{
			WidgetBlueprints.Add(Cast<UWidgetBlueprint>(Object));
		}
	}
	if (WidgetBlueprints.Num() <= 0)
	{
		return;
	}

	MenuBuilder.AddMenuEntry(
		LOCTEXT("ScanButtonsAndHotArea", "Scane buttons and hot areas"),
		LOCTEXT("ScanButtonsAndHotAreaTips", "ScanButtonsAndHotArea"),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(
			this, &FAssetTypeActions_KGUI::ExecuteScaneButtonsAndHotareas, WidgetBlueprints)));

	MenuBuilder.AddMenuEntry(
		LOCTEXT("ScanVisibleWidget", "Scan visible widgets"),
		LOCTEXT("ScanVisibleWidgetTips", "Scan visible widgets"),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(
			this, &FAssetTypeActions_KGUI::ExecuteScanVisibleWidget, WidgetBlueprints)));

	MenuBuilder.AddMenuEntry(
	LOCTEXT("ReplaceGPUTurboImageWithKGGPUTurboImage", "Replace GPUTurboImage with KGGPUTurboImage"),
	LOCTEXT("ReplaceGPUTurboImageWithKGGPUTurboImageTips", "Replace GPUTurboImage with KGGPUTurboImage"),
	FSlateIcon(),
	FUIAction(FExecuteAction::CreateSP(
		this, &FAssetTypeActions_KGUI::ExecuteReplaceGPUTurboImageWithKGGPUTurboImage, WidgetBlueprints))
		);

	MenuBuilder.AddMenuEntry(
		LOCTEXT("AddHoverPressAnimToButton", "Add hover/press anim to button/hotarea"),
		LOCTEXT("AddHoverPressAnimToButtonTips", "Add hover/press anim to button/hotarea"),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(
			this, &FAssetTypeActions_KGUI::ExecuteReplaceButtonWithKGAnimArea, WidgetBlueprints))
	);

	MenuBuilder.AddMenuEntry(
		LOCTEXT("用KG控件替换引擎原生控件", "用KG控件替换引擎原生控件"),
		LOCTEXT("用KG控件替换引擎原生控件", "用KG控件替换引擎原生控件"),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(
			this, &FAssetTypeActions_KGUI::ExecuteReplaceWidgetWithKGWidget, WidgetBlueprints))
	);

}

uint32 FAssetTypeActions_KGUI::GetCategories()
{
	return EAssetTypeCategories::Type::UI;
}

void FAssetTypeActions_KGUI::Merge(UObject* BaseAsset, UObject* RemoteAsset, UObject* LocalAsset, const FOnMergeResolved& ResolutionCallback)
{
	if (BaseAsset == nullptr || RemoteAsset == nullptr || LocalAsset == nullptr)
	{
		return FAssetTypeActions_Base::Merge(BaseAsset, RemoteAsset, LocalAsset, ResolutionCallback);
	}

	// Fallback to engine default merge tool
	UClass* AssetClass = UWidgetBlueprint::StaticClass(); // BaseAsset->StaticClass();
	auto* AssetDefinition = UAssetDefinitionRegistry::Get()->GetAssetDefinitionForClass(AssetClass);
	if (AssetDefinition != nullptr)
	{
		FAssetManualMergeArgs MergeArgs;
		MergeArgs.LocalAsset = LocalAsset;
		MergeArgs.BaseAsset = BaseAsset;
		MergeArgs.RemoteAsset = RemoteAsset;
		MergeArgs.ResolutionCallback = FOnAssetMergeResolved::CreateLambda([ResolutionCallback](const FAssetMergeResults& Results)
			{
				ResolutionCallback.Execute(Results.MergedPackage, static_cast<EMergeResult::Type>(Results.Result));
			});

		(void)AssetDefinition->Merge(MergeArgs);
		return;
	}
	return FAssetTypeActions_Base::Merge(BaseAsset, RemoteAsset, LocalAsset, ResolutionCallback);
}

void FAssetTypeActions_KGUI::PerformAssetDiff(UObject* OldAsset, UObject* NewAsset, const struct FRevisionInfo& OldRevision, const struct FRevisionInfo& NewRevision) const
{
	if (OldAsset == nullptr || NewAsset == nullptr)
	{
		return FAssetTypeActions_Base::PerformAssetDiff(OldAsset, NewAsset, OldRevision, NewRevision);
	}

	// Fallback to engine default diff tool
	UClass* AssetClass = UWidgetBlueprint::StaticClass(); // OldAsset->StaticClass();
	auto* AssetDefinition = UAssetDefinitionRegistry::Get()->GetAssetDefinitionForClass(AssetClass);
	if (AssetDefinition != nullptr)
	{
		FAssetDiffArgs DiffArgs;
		DiffArgs.OldAsset = OldAsset;
		DiffArgs.NewAsset = NewAsset;
		DiffArgs.OldRevision = OldRevision;
		DiffArgs.NewRevision = NewRevision;
		std::ignore = AssetDefinition->PerformAssetDiff(DiffArgs);
		return;
	}
	return FAssetTypeActions_Base::PerformAssetDiff(OldAsset, NewAsset, OldRevision, NewRevision);
}
void FAssetTypeActions_KGUI::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	for (auto* Obj : InObjects)
	{
		UWidgetBlueprint* Blueprint = Cast<UWidgetBlueprint>(Obj);
		if (Blueprint && Blueprint->SkeletonGeneratedClass && Blueprint->GeneratedClass)
		{
			TSharedRef<FWidgetBlueprintEditor> NewBlueprintEditor(new FWidgetBlueprintEditor);

			const bool bShouldOpenInDefaultsMode = false;
			TArray<UBlueprint*> Blueprints;
			Blueprints.Add(Blueprint);

			NewBlueprintEditor->InitWidgetBlueprintEditor(EToolkitMode::Type::Standalone, EditWithinLevelEditor, Blueprints, bShouldOpenInDefaultsMode);
		}
	}
}

void FAssetTypeActions_KGUI::ExecuteScaneButtonsAndHotareas(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects)
{
	for (auto UserWidget : InObjects)
	{
		if (!UserWidget.IsValid())
		{
			continue;
		}

		TArray<UWidget*> Widgets;
		UserWidget->WidgetTree->GetAllWidgets(Widgets);
		for (auto Widget : Widgets)
		{
			if(Widget->IsA<UButton>())
			{
				bool bHasChild = false;
				UButton* Button = Cast<UButton>(Widget);
				if (Button)
				{
					bHasChild = Button->GetContent() != nullptr;
				}

				UE_LOG(LogInit, Log, TEXT("[KGUI]Scan:%s,Button,%s,%s"), 
					*Widget->GetFullName(), *Widget->GetPackage()->GetPathName(),
					bHasChild ? TEXT("true") : TEXT("false"));
			}
			else if (Widget->IsA<UKGHotArea>())
			{
				UE_LOG(LogInit, Log, TEXT("[KGUI]Scan:%s,HotArea,%s,false"),
					*Widget->GetFullName(), *Widget->GetPackage()->GetPathName());
			}
		}
		
	}
}

void FAssetTypeActions_KGUI::ExecuteScanVisibleWidget(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects)
{
	FString OutputContent;
	OutputContent.Append(TEXT("FullName,Package,Class,IsContentWidget,IsPanel\n"));

	TStringBuilder<1024> Line;

	// 创建进度条
	FScopedSlowTask SlowTask(InObjects.Num(), FText::FromString(TEXT("Processing Blueprints...")));
	SlowTask.MakeDialog();

	for (auto UserWidget : InObjects)
	{
		SlowTask.EnterProgressFrame(1);
		if (!UserWidget.IsValid())
		{
			continue;
		}

		TArray<UWidget*> Widgets;
		UserWidget->WidgetTree->GetAllWidgets(Widgets);
		for (auto Widget : Widgets)
		{
			Line.Reset();
			if (Widget->GetVisibility() == ESlateVisibility::Visible)
			{
				// 收集信息
				FString FullName = Widget->GetFullName();
				FString PackageName = Widget->GetPackage()->GetName();
				FString ClassName = Widget->GetClass()->GetName();
				bool bIsContentWidget = Widget->IsA<UContentWidget>();
				bool bIsPanelWidget = Widget->IsA<UPanelWidget>();

				// 格式化CSV行
				Line.Appendf(
					TEXT("%s,%s,%s,%s,%s\n"),
					*FullName,
					*PackageName,
					*ClassName,
					bIsContentWidget ? TEXT("true") : TEXT("false"),
					bIsPanelWidget ? TEXT("true") : TEXT("false")
				);

				OutputContent.Append(Line);
			}
		}
	}

	// 写入文件
	FString FilePath = FPaths::ProjectSavedDir() / TEXT("VisibleWidgetsReport.csv");
	FFileHelper::SaveStringToFile(OutputContent, *FilePath);

	UE_LOG(LogTemp, Warning, TEXT("[KGUI]ScanVisibleWidget is done！Output file path：%s"), *FilePath);
}

void FAssetTypeActions_KGUI::ExecuteReplaceGPUTurboImageWithKGGPUTurboImage(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects)
{
	for (auto UserWidget : InObjects)
	{
		if (!UserWidget.IsValid())
		{
			continue;
		}

		ReplaceWidget(UserWidget.Get(), UGPUTurboImage::StaticClass(), UKGGPUTurboImage::StaticClass());
	}
}

void FAssetTypeActions_KGUI::ExecuteReplaceButtonWithKGAnimArea(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects)
{
	for (auto UserWidget : InObjects)
	{
		if (!UserWidget.IsValid())
		{
			continue;
		}

		ReplaceOrAddKGAnimArea(UserWidget.Get());
	}
}

void FAssetTypeActions_KGUI::ExecuteReplaceWidgetWithKGWidget(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects)
{
	TArray<FString> ValidWidgetName = {
		"CanvasPanel",
		"TextBlock",
		"CheckBox",
		"EditableTextBox",
		"NamedSlot",
		"ProgressBar",
		"Slider",
		"HorizontalBox",
		"VerticalBox",
		"ScaleBox",
		"ScrollBox",
		"SizeBox",
		"WarpBox",
	};

	FScopedSlowTask SlowTask(InObjects.Num(), FText::FromString(TEXT("Replace widget with KGWidget ...")));
	SlowTask.MakeDialog();

	for (auto Object : InObjects)
	{
		SlowTask.EnterProgressFrame(1.0f);

		if (Object.IsValid())
		{
			UWidgetBlueprint* WidgetBlueprint = Object.Get();
			if (!WidgetBlueprint || !WidgetBlueprint->WidgetTree)
			{
				UE_LOG(LogKGUI, Log, TEXT("ExecuteReplaceWidgetWithKGWidget: widgetblueprint is invalid"));
				continue;
			}

			UWidgetTree* WidgetTree = WidgetBlueprint->WidgetTree;
			if (!WidgetTree)
			{
				UE_LOG(LogKGUI, Log, TEXT("ExecuteReplaceWidgetWithKGWidget: widgetblueprint has no widget tree"));
				continue;
			}

			TMap<UClass*, UClass*> ClassesToReplace;
			WidgetTree->ForEachWidget([&](UWidget* Widget)
				{
					if (!Widget)
					{
						return;
					}

					FString ClassName = Widget->GetClass()->GetName();
					if (ValidWidgetName.Contains(ClassName) && !ClassName.StartsWith(TEXT("KG")))
					{
						FString KGClassName = TEXT("KG") + ClassName;
						UClass* KGClass = FindObject<UClass>(nullptr, *KGClassName);
						if (KGClass)
						{
							if (!ClassesToReplace.Contains(Widget->GetClass()))
							{
								ClassesToReplace.Add(Widget->GetClass(), KGClass);
							}
						}
						else
						{
							UE_LOG(LogKGUI, Log, TEXT("ExecuteReplaceWidgetWithKGWidget: %s is a U%s, but has no KGWidget"), *Widget->GetFullName(), *ClassName);
						}
					}
				});

			for (auto& Pair : ClassesToReplace)
			{
				ReplaceWidget(WidgetBlueprint, Pair.Key, Pair.Value);
			}
		}
	}
}

void FAssetTypeActions_KGUI::ReplaceOrAddKGAnimArea(UWidgetBlueprint* UserWidget)
{
	UWidgetTree* WidgetTree = UserWidget->WidgetTree;
	if (!WidgetTree)
	{
		return;
	}

	TArray<UPanelWidget*> Parents;
	TArray<UWidget*> WidgetsToReplace;
	WidgetTree->ForEachWidget([&](UWidget* Widget)
		{
			if (!Widget)
			{
				return;
			}

			bool bValidWidget = false;
			for (auto& Cls : GetDefault<UKGUISettings>()->ResponseWidgetsForAnimArea)
			{
				if (Widget->IsA(Cls.Get()))
				{
					bValidWidget = true;
					break;
				}
			}

			if (Widget && bValidWidget)
			{
				bool bValid = true;
				if (Widget->GetParent())
				{
					if (Parents.Contains(Widget->GetParent()))
					{
						UE_LOG(LogTemp, Error, TEXT("[AnimArea]%s,MultiButton"), *Widget->GetFullName());
						bValid = false;
					}
					else
					{
						Parents.Add(Widget->GetParent());
					}
				}

				if (bValid)
				{
					WidgetsToReplace.Add(Widget);
				}
			}
		});

	auto Process = [UserWidget,WidgetTree](UWidget* Widget, UPanelWidget* Parent, TArray<FKGWidgetName>& OutNames)
	{
		// 标记蓝图开始修改（支持撤销）
		const FScopedTransaction Transaction(FText::FromString("Add KGAnimArea"));
		UserWidget->Modify();
		
		FKGWidgetName Name{ Parent->GetFName() };
		OutNames.AddUnique(Name);
	};

	for (UWidget* Widget : WidgetsToReplace)
	{
		UPanelWidget* Parent = Widget->GetParent();
		bool bIsValidWidget = Widget == WidgetTree->RootWidget.Get() || Parent;
		if (!bIsValidWidget)
		{
			continue;
		}

		if (Widget == WidgetTree->RootWidget.Get())
		{
			// 作为蓝图根节点的按钮一定是控制自己的子控件树，按钮子控件树的动画
			// 默认在FKGInteractableArea中进行驱动不需要额外处理，而热区控件没有子树，
			// 所以这个情况下不需要对按钮/热区进行处理
		}
		else
		{
			// 非蓝图根节点点的情况下，按钮/热区一定有父控件
			if (Widget->IsA<UButton>() && Cast<UButton>(Widget)->GetContent())
			{
				// 按钮有子树时，意味着按钮只会控制自己子控件树，不存在控制兄弟控件，也就不需要处理了
			}
			else if (Parent)
			{
				// 没有子控件树的按钮和热区控件，直接控制父节点进行缩放等动画处理
				if (Widget->IsA<UKGButton>())
				{
					UKGButton* Button = Cast<UKGButton>(Widget);
					Process(Widget, Parent, Button->HoverPressAnim.VisualWidgetNames);
				}
				else if (Widget->IsA<UKGHotArea>())
				{
					UKGHotArea* HotArea = Cast<UKGHotArea>(Widget);
					Process(Widget, Parent, HotArea->HoverPressAnim.VisualWidgetNames);
				}
				else if (Widget->IsA<UButton>())
				{
					UE_LOG(LogTemp, Error, TEXT("[AnimArea]%s,Button"), *Widget->GetFullName());
				}
				else
				{
					UE_LOG(LogTemp, Error, TEXT("[AnimArea]%s,Unknown"), *Widget->GetFullName());
				}
			}
		}
	}

	// 编译并保存
	FBlueprintEditorUtils::MarkBlueprintAsModified(UserWidget);
	FKismetEditorUtilities::CompileBlueprint(UserWidget);
}

int FAssetTypeActions_KGUI::ReplaceWidget(UWidgetBlueprint* InWidgetBlueprint, UClass* OrigClass, UClass* NewClass, bool bTest)
{
	if (!InWidgetBlueprint) return -1;

	TArray<UWidget*> WidgetsToReplace;

	// 获取蓝图的Widget Tree
	UWidgetTree* WidgetTree = InWidgetBlueprint->WidgetTree;
	if (!WidgetTree) return -1;

	if (OrigClass == NewClass)
	{
		return 0;
	}

	TArray<INamedSlotInterface*> NameSlotInterfaces;
	// 遍历所有控件，收集需要替换的UGPUTurboImage实例
	WidgetTree->ForEachWidget([&](UWidget* Widget) {
		if (INamedSlotInterface* NameSlot = Cast<INamedSlotInterface>(Widget))
		{
			NameSlotInterfaces.Emplace(NameSlot);
		}

		if (Widget && Widget->GetClass() == OrigClass)
		{
			WidgetsToReplace.Add(Widget);
		}
	});

	if (bTest || WidgetsToReplace.Num() == 0)
	{
		return WidgetsToReplace.Num();
	}

	// 标记蓝图开始修改（支持撤销）
	const FScopedTransaction Transaction(FText::FromString("Replace Widget"));
	InWidgetBlueprint->Modify();

	// 遍历并替换控件
	for (UWidget* OldWidget : WidgetsToReplace)
	{
		if (OldWidget->GetClass() == NewClass)
		{
			continue;
		}

		// 生成临时唯一名称（避免冲突）
		const FName TempWidgetName = MakeUniqueObjectName(
			WidgetTree,
			NewClass,
			FName(OldWidget->GetName() + TEXT("_TEMP"))
		);
		
		// 创建新的控件
		UWidget* NewWidget = WidgetTree->ConstructWidget<UWidget>(
			NewClass,
			TempWidgetName
		);

		// 复制属性（关键步骤）
		UEngine::CopyPropertiesForUnrelatedObjects(OldWidget, NewWidget);
		if (UPanelWidget* NewPanel = Cast<UPanelWidget>(NewWidget))
		{
			if (UPanelWidget* OldPanel = Cast<UPanelWidget>(NewWidget))
			{
				for (int32 Index = 0; Index < OldPanel->GetChildrenCount(); ++Index)
				{
					auto* Child = OldPanel->GetChildAt(Index);
					if (Child)
					{
						UPanelSlot* OldSlot = Child->Slot;
						for (int32 IdxNewSlot = 0; IdxNewSlot < NewPanel->GetChildrenCount(); ++IdxNewSlot)
						{
							auto* NewSlot = NewPanel->GetSlots()[IdxNewSlot];

							// 在上面属性拷贝时，已经将子控件的数据拷贝到了新的slot里面，但是子控件自身持有的Slot信息
							// 还是旧的Panel和旧的PanelSlot，所以这里需要调用ReplaceChildAt来刷新子控件上相关信息。
							if (NewSlot && NewSlot->Content == Child)
							{
								NewPanel->ReplaceChildAt(IdxNewSlot, Child);
								ReplaceAnimBindings(InWidgetBlueprint, OldSlot, NewSlot, OldSlot->GetName(), Child->Slot->GetName());
								break;
							}
						}
					}
				}
			}
		}

		// 替换控件在Tree中的位置
		if (OldWidget == WidgetTree->RootWidget)
		{
			WidgetTree->RootWidget = NewWidget;
		}
		else if (UPanelWidget* ParentPanel = OldWidget->GetParent())
		{
			const int32 Index = ParentPanel->GetChildIndex(OldWidget);
			ParentPanel->ReplaceChild(OldWidget, NewWidget);
		}
		else
		{
			for (auto* NameSlotInterface : NameSlotInterfaces)
			{
				FName SlotName = NameSlotInterface->FindSlotForContent(OldWidget);
				if (SlotName != NAME_None)
				{
					NameSlotInterface->SetContentForSlot(SlotName, NewWidget);
				}
			}
		}
		
		FString Name = OldWidget->GetName();

		// 删除旧控件
		WidgetTree->RemoveWidget(OldWidget);
		
		// 将OldWidget从当前蓝图中移除
		if (OldWidget)
		{
			FString TempName = FString::Printf(TEXT("%s_%s_%d"), *InWidgetBlueprint->GetName(), *Name, FMath::Rand());
			OldWidget->Rename(*TempName, nullptr, REN_DontCreateRedirectors | REN_ForceNoResetLoaders);
		}

		// 将新控件重命名为原始名称
		const bool bRenameSuccess = NewWidget->Rename(
			*Name, // 目标名称
			nullptr, // 保持当前Outer（WidgetTree）
			REN_ForceNoResetLoaders | REN_DontCreateRedirectors
		);

		// 更新蓝图变量和节点引用（见步骤3）
		ReplaceVariableAndNodeReferences(InWidgetBlueprint, OldWidget, NewWidget, TempWidgetName);
		// 替换函数、参数、节点中的类型引用
		ReplaceFunctionReferences(InWidgetBlueprint, OrigClass, NewClass);

		// 替换委托签名
		ReplaceDelegateSignatures(InWidgetBlueprint, OrigClass, NewClass);
		
		// 替换动画绑定
		ReplaceAnimBindings(InWidgetBlueprint, OldWidget, NewWidget, Name, Name);

		// 将OldWidget从当前蓝图中移除
		if (OldWidget)
		{
			FString TempName = FString::Printf(TEXT("%s_%s_%d"), *InWidgetBlueprint->GetName(), *Name, FMath::Rand());
			OldWidget->Rename(*TempName, GetTransientPackage(), REN_DontCreateRedirectors | REN_ForceNoResetLoaders);
			OldWidget->MarkAsGarbage();
		}

		if (!bRenameSuccess)
		{
			UE_LOG(LogTemp, Error, TEXT("重命名失败：%s"), *OldWidget->GetName());
			continue;
		}
	}

	// 编译并保存
	ReconstructNodes(InWidgetBlueprint);
	FBlueprintEditorUtils::MarkBlueprintAsModified(InWidgetBlueprint);
	FKismetEditorUtilities::CompileBlueprint(InWidgetBlueprint, EBlueprintCompileOptions::SkipGarbageCollection);

	return WidgetsToReplace.Num();
}

void FAssetTypeActions_KGUI::ReplaceWidgetWithKGWidgetForPath(const TArray<FString>& InPaths)
{
}

void FAssetTypeActions_KGUI::ScanWBPUsingEngineWidget(const TArray<FString>& InPaths)
{
	// 获取资产注册模块
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");

	// 构建筛选条件
	FARFilter Filter;
	for (const auto& TargetPath : InPaths)
	{
		FString Path = TargetPath.Replace(TEXT("/All"), TEXT(""));
		Filter.PackagePaths.Add(*Path); // 目标路径如"/Game/UI"
	}

	Filter.ClassPaths.Add(UWidgetBlueprint::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true; // 递归子目录

	TArray<FAssetData> WidgetAssets;
	AssetRegistryModule.Get().GetAssets(Filter, WidgetAssets);

	// 遍历所有Widget蓝图
	for (const FAssetData& Asset : WidgetAssets)
	{
		if (UWidgetBlueprint* WidgetBP = Cast<UWidgetBlueprint>(Asset.GetAsset()))
		{
			bool bHasNativeWidget = false;
			TArray<UWidget*> AllWidgets;

			// 获取所有控件实例
			if (WidgetBP->WidgetTree)
			{
				WidgetBP->WidgetTree->GetAllWidgets(AllWidgets);
			}

			// 检查每个控件是否来自引擎原生类
			for (UWidget* Widget : AllWidgets)
			{
				if (Widget->GetClass()->GetPackage()->GetName().StartsWith(TEXT("/Script/UMG")))
				{
					bHasNativeWidget = true;
					break;
				}
			}

			// 处理符合条件的蓝图
			if (bHasNativeWidget)
			{
				// 添加元数据标签
				UPackage* Package = WidgetBP->GetPackage();
				if (Package)
				{
					Package->GetMetaData()->SetValue(
						WidgetBP,
						TEXT("KGUI.UseEngineNativeWidget"),
						TEXT("true")
					);
					Package->MarkPackageDirty();

					FString PackageName = Package->GetName();
					FString PackageFileName = FPackageName::LongPackageNameToFilename(PackageName, FPackageName::GetAssetPackageExtension());
					FSavePackageArgs SaveArgs;
					SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
					SaveArgs.SaveFlags = SAVE_NoError;
					UPackage::SavePackage(Package, WidgetBP, *PackageFileName, SaveArgs);
				}

				// 输出日志
				UE_LOG(LogKGUI, Log, TEXT("Found native widget in: %s"), *Asset.PackageName.ToString());
			}
		}
	}
}

void FAssetTypeActions_KGUI::ScanWBP(const TArray<FString>& Params)
{
	FString ClassName;
	bool bExactlyMatch = false;
	bool bOutputListItem = false;
	for (const auto& Param : Params)
	{
		if (Param.StartsWith(TEXT("-class")))
		{
			FParse::Value(*Param, TEXT("-class="), ClassName);
		}
		else if (Param == TEXT("-exactly"))
		{
			bExactlyMatch = true;
		}
		else if (Param == TEXT("-listitem"))
		{
			bOutputListItem = true;
		}
	}

	if (ClassName.IsEmpty())
	{
		UE_LOG(LogKGUI, Log, TEXT("ScanWBP failed: class is null"));
		return;
	}

	FString Path = TEXT("/Script/UMG.") + ClassName;
	UClass* Class = FindObject<UClass>(nullptr, *Path);
	if (!Class)
	{
		Path = TEXT("/Script/KGUI.") + ClassName;
		Class = FindObject<UClass>(nullptr, *Path);
		if(!Class)
		{
			UE_LOG(LogKGUI, Log, TEXT("ScanWBP failed: class U%s is not found"), *ClassName);
			return;
		}
	}

	// 获取资产注册模块
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");

	// 构建筛选条件
	FARFilter Filter;
	Filter.PackagePaths.Add(TEXT("/Game/Arts/UI_2/Blueprint")); // 目标路径如"/Game/UI"
	Filter.ClassPaths.Add(UWidgetBlueprint::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true; // 递归子目录

	TArray<FAssetData> WidgetAssets;
	AssetRegistryModule.Get().GetAssets(Filter, WidgetAssets);

	FScopedSlowTask SlowTask(WidgetAssets.Num(), FText::FromString(TEXT("Scan widget blueprint...")));
	// 遍历所有Widget蓝图
	for (const FAssetData& Asset : WidgetAssets)
	{
		SlowTask.EnterProgressFrame(1, FText::FromString(Asset.AssetName.ToString()));
		if (UWidgetBlueprint* WidgetBP = Cast<UWidgetBlueprint>(Asset.GetAsset()))
		{
			bool bHasNativeWidget = false;
			TArray<UWidget*> AllWidgets;

			// 获取所有控件实例
			if (WidgetBP->WidgetTree)
			{
				WidgetBP->WidgetTree->GetAllWidgets(AllWidgets);
			}

			// 检查每个控件是否为目标类型
			for (UWidget* Widget : AllWidgets)
			{
				if ((bExactlyMatch && Widget->GetClass() == Class) 
					|| (!bExactlyMatch && Widget->GetClass()->IsChildOf(Class)))
				{
					FString StrLog = FString::Printf(TEXT("%s,%s"), *Widget->GetFullName(), *Widget->GetName());
					

					if (bOutputListItem && Widget->GetClass()->IsChildOf(UListViewBase::StaticClass()))
					{
						auto* List = Cast<UListViewBase>(Widget);
						if (UClass* EntryWidgetClass = List->GetEntryWidgetClass())
						{
							StrLog.Append(TEXT(","));
							StrLog.Append(EntryWidgetClass->GetName());
							StrLog.Append(TEXT(","));
							StrLog.Append(*EntryWidgetClass->GetPathName());
						}						
					}

					UE_LOG(LogKGUI, Log, TEXT("[ScanWBP]%s"), *StrLog);
				}
			}
		}
	}
}

void FAssetTypeActions_KGUI::ReplaceVariableAndNodeReferences(UWidgetBlueprint* Blueprint, UWidget* OldWidget, UWidget* NewWidget, const FName& TempName)
{
	// 更新变量类型（需要处理临时名称阶段）
	for (FBPVariableDescription& Variable : Blueprint->NewVariables)
	{
		if (Variable.VarType.PinSubCategoryObject == OldWidget->GetClass())
		{
			Variable.VarType.PinSubCategoryObject = NewWidget->GetClass();
			// 注意：此时NewWidget可能处于临时名称阶段，需延迟设置默认值
		}
	}

	// 替换所有图表节点中的引用
	for (UEdGraph* Graph : Blueprint->UbergraphPages)
	{
		TArray<UEdGraphNode*> AllNodes;
		Graph->GetNodesOfClass(AllNodes);

		for (UEdGraphNode* Node : AllNodes)
		{
			// 处理变量节点
			if (UK2Node_Variable* VarNode = Cast<UK2Node_Variable>(Node))
			{
				if (VarNode->VariableReference.GetMemberName() == OldWidget->GetFName())
				{
					VarNode->Modify();
					VarNode->VariableReference.SetSelfMember(NewWidget->GetFName());
				}
			}

			// 处理绑定中的文本引用（如动态绑定的函数名）
			if (Node->GetNodeTitle(ENodeTitleType::FullTitle).ToString().Contains(OldWidget->GetName()))
			{
				FString NewNodeTitle = Node->GetNodeTitle(ENodeTitleType::FullTitle).ToString();
				NewNodeTitle.ReplaceInline(*OldWidget->GetName(), *NewWidget->GetName());
				// Node->SetNodeTitle(ENodeTitleType::FullTitle, FText::FromString(NewNodeTitle));
			}
		}
	}
}

void FAssetTypeActions_KGUI::ReconstructNodes(UWidgetBlueprint* Blueprint)
{
	if (Blueprint == nullptr)
	{
		return;
	}
	TArray<UEdGraph*> AllGraphs;
	Blueprint->GetAllGraphs(AllGraphs);

	for (UEdGraph* Graph : AllGraphs)
	{
		if (Graph == nullptr)
		{
			continue;
		}
		const UEdGraphSchema* Schema = Graph->GetSchema();
		if (Schema == nullptr)
		{
			continue;
		}
		TArray<UEdGraphNode*> Nodes = Graph->Nodes;

		for (UEdGraphNode* Node : Nodes)
		{
			if (Node == nullptr)
			{
				continue;
			}
			const bool bCurDisableOrphanSaving = Node->bDisableOrphanPinSaving;
			Node->bDisableOrphanPinSaving = true;

			Schema->ReconstructNode(*Node);
			Node->ClearCompilerMessage();

			Node->bDisableOrphanPinSaving = bCurDisableOrphanSaving;
		}
	}
}

void FAssetTypeActions_KGUI::ReplaceFunctionReferences(UWidgetBlueprint* Blueprint, UClass* OldClass, UClass* NewClass)
{
    // 遍历所有图表（函数、事件、宏）
    TArray<UEdGraph*> AllGraphs;
    Blueprint->GetAllGraphs(AllGraphs);

    for (UEdGraph* Graph : AllGraphs)
    {
        TArray<UEdGraphNode*> Nodes = Graph->Nodes;

        for (UEdGraphNode* Node : Nodes)
        {
            // 处理函数入口节点（参数和返回值）
            if (UK2Node_FunctionEntry* FunctionEntry = Cast<UK2Node_FunctionEntry>(Node))
            {
                for (FBPVariableDescription& Variable : FunctionEntry->LocalVariables)
                {
                    if (Variable.VarType.PinSubCategoryObject == OldClass)
                    {
                        Variable.VarType.PinSubCategoryObject = NewClass;
                    }
                }
            }

            // 处理所有针脚（Pin）的类型
            for (UEdGraphPin* Pin : Node->Pins)
            {
                if (Pin->PinType.PinSubCategoryObject == OldClass)
                {
                    Pin->Modify();
                    Pin->PinType.PinSubCategoryObject = NewClass;
                    
                    // 更新针脚默认值中的对象引用
                    if (Pin->DefaultObject == OldClass->GetDefaultObject())
                    {
                        Pin->DefaultObject = NewClass->GetDefaultObject();
                    }
                }
            }

            // 处理特殊节点（如类型转换节点）
            if (UK2Node_DynamicCast* CastNode = Cast<UK2Node_DynamicCast>(Node))
            {
                if (CastNode->TargetType == OldClass)
                {
                    CastNode->TargetType = NewClass;
                    CastNode->ReconstructNode();
                }
            }

            // 处理函数调用节点（如生成对象）
            if (UK2Node_CallFunction* CallFunctionNode = Cast<UK2Node_CallFunction>(Node))
            {
                UFunction* Function = CallFunctionNode->FunctionReference.ResolveMember<UFunction>(Blueprint);
                if (Function && Function->GetReturnProperty() && Function->GetReturnProperty()->GetClass()->GetName() == OldClass->GetName())
                {
                    // 需替换函数引用为返回新类型的新函数（需自定义逻辑）
                    ReplaceFunctionReturnType(CallFunctionNode, NewClass);
                }
            }
        }
    }
}

void FAssetTypeActions_KGUI::ReplaceDelegateSignatures(UBlueprint* Blueprint, UClass* OldClass, UClass* NewClass)
{
	// for (FBPDelegateDelegateBinding& Binding : Blueprint->DelegateBindings)
	// {
	// 	if (Binding.DelegateSignatureClass == OldClass)
	// 	{
	// 		Binding.DelegateSignatureClass = NewClass;
	// 	}
	// }
}

void FAssetTypeActions_KGUI::ReplaceFunctionReturnType(UK2Node_CallFunction* Node, UClass* NewClass)
{
	// 假设已存在返回新类型的对应函数
	if (UFunction* NewFunction = NewClass->FindFunctionByName(Node->FunctionReference.GetMemberName()))
	{
		Node->FunctionReference.SetFromField<UFunction>(NewFunction, false);
		Node->ReconstructNode();
	}
}

void FAssetTypeActions_KGUI::ReplaceAnimBindings(UWidgetBlueprint* Blueprint, UObject* OldObj, UObject* NewObj, const FString& OldName, const FString& 
NewName)
{
	FString Name = NewName.IsEmpty() ? OldName : NewName;

	for (auto& Anim : Blueprint->Animations)
	{
		auto& MovieScene = Anim->MovieScene;
		for (auto& Binding : MovieScene->GetBindings())
		{
			if (Binding.GetName() == OldName && OldObj != NewObj)
			{
				if(auto* Possessable = MovieScene->FindPossessable(Binding.GetObjectGuid()))
				{
					FMovieScenePossessable NewPossessable = *Possessable;
					NewPossessable.SetName(Name);
					NewPossessable.SetPossessedObjectClass(NewObj->GetClass());

					MovieScene->ReplacePossessable(Binding.GetObjectGuid(), NewPossessable);
				}
			}
		}
	}
}

FAutoConsoleCommand KGUIOutputDataTableReferenceAtlas(
	TEXT("KGUI.OutputDataTableReferenceAtlas"),
	TEXT("KGUI.OutputDataTableReferenceAtlas"),
	FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
		{
			TArray<UObject*> SelectedAssets = UEditorUtilityLibrary::GetSelectedAssets();
			if (SelectedAssets.Num() > 0)
			{
				if (UDataTable* DataTable = Cast<UDataTable>(SelectedAssets[0]))
				{
					// 获取所有行键（Row Names）
					TArray<FName> RowNames = DataTable->GetRowNames();

					UScriptStruct* RowStruct = DataTable->RowStruct;
					if (!RowStruct)
					{
						UE_LOG(LogTemp, Warning, TEXT("RowStruct is invalid!"));
						return;
					}

					// 遍历每一行
					for (const FName& RowName : RowNames)
					{
						// 获取行数据指针
						void* RowData = DataTable->FindRowUnchecked(RowName);
						if (!RowData)
						{
							continue;
						}

						// 输出行键
						UE_LOG(LogTemp, Log, TEXT("Row: %s"), *RowName.ToString());

						// 反射遍历结构体属性（列）
						for (TFieldIterator<FProperty> It(RowStruct); It; ++It)
						{
							FProperty* Property = *It;
							if (!Property || Property->GetName() == "RowType") // 跳过继承的 FTableRowBase 字段
							{
								continue;
							}

							if (FStructProperty* StructProp = CastField<FStructProperty>(Property))
							{
								if (StructProp->Struct == FSlateBrush::StaticStruct())
								{
									// 获取 FSlateBrush 数据指针
									const FSlateBrush* Brush = StructProp->ContainerPtrToValuePtr<FSlateBrush>(RowData);

									if (Brush && Brush->GetResourceObject())
									{
										UAssetManager& AssetManager = UAssetManager::Get();
										auto& AssetRegistry = UAssetManager::Get().GetAssetRegistry();

										FString PackageName = Brush->GetResourceObject()->GetPackage()->GetPathName();
										TArray<FAssetIdentifier> Dependencies;
										AssetRegistry.GetDependencies(FAssetIdentifier(FName(*PackageName)), Dependencies);
										while (Dependencies.Num() > 0)
										{
											FAssetIdentifier Indentifier = Dependencies.Pop(false);

											FString Path = Indentifier.ToString();
											int32 Index = INDEX_NONE;
											if (Path.FindLastChar(TEXT('/'), Index))
											{
												Path += TEXT(".") + Path.Right(Path.Len() - 1 - Index);
											}

											FAssetData AssetData;
											if (AssetManager.GetAssetDataForPath(Path, AssetData))
											{
												UObject* Obj = AssetData.GetAsset();
												if (Obj && Obj->IsA<UPaperSpriteAtlas>())
												{
													UE_LOG(LogInit, Log, TEXT("[KGUI]%s: %s referenced:%s"),
														ANSI_TO_TCHAR(__FUNCTION__), *RowName.ToString(), *Indentifier.ToString());
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		})
);

FAutoConsoleCommand KGUIMigrateComBtnDataTable(
	TEXT("KGUI.MigrateComBtnDataTable"),
	TEXT("KGUI.MigrateComBtnDataTable"),
	FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
		{
			if (Args.Num() <= 0)
			{
				return;
			}

			FString StructPath = Args[0];
			FAssetData AssetData;
			if (!UAssetManager::Get().GetAssetDataForPath(StructPath, AssetData))
			{
				return;
			}

			UObject* Obj = AssetData.GetAsset();
			UScriptStruct* Struct = Cast<UScriptStruct>(Obj);
			if (!Struct)
			{
				return;
			}

			TArray<UObject*> SelectedAssets = UEditorUtilityLibrary::GetSelectedAssets();
			if (SelectedAssets.Num() <= 0)
			{
				return;
			}

			UDataTable* DataTable = Cast<UDataTable>(SelectedAssets[0]);
			if (!DataTable)
			{
				return;
			}

			FString PackageName = SelectedAssets[0]->GetPackage()->GetPathName();
			FString NewPackage;
			FString NewDataTableName;
			int32 Index = INDEX_NONE;
			if (PackageName.FindLastChar(TEXT('/'), Index))
			{
				FString FileName = PackageName.Right(PackageName.Len() - 1 - Index);
				FileName = FileName.Append(TEXT("_New"));
				NewPackage = PackageName.Left(Index + 1) + FileName;
				NewDataTableName = FileName;
			}

			if (NewPackage.IsEmpty())
			{
				return;
			}

			UScriptStruct* RowStruct = DataTable->RowStruct;
			if (!RowStruct)
			{
				UE_LOG(LogTemp, Warning, TEXT("RowStruct is invalid!"));
				return;
			}

			UPackage* Package = CreatePackage(*NewPackage);
			UDataTable* NewDataTable = NewObject<UDataTable>(Package, *NewDataTableName, RF_Public | RF_Standalone);
			NewDataTable->RowStruct = Struct;

			TArray<FName> RowNames = DataTable->GetRowNames();
			for (const FName& RowName : RowNames)
			{
				// 获取行数据指针
				void* RowData = DataTable->FindRowUnchecked(RowName);
				if (!RowData)
				{
					continue;
				}

				UE_LOG(LogTemp, Log, TEXT("Row: %s"), *RowName.ToString());
				uint8* NewData = FDataTableEditorUtils::AddRow(NewDataTable, RowName);

				for (TFieldIterator<FProperty> It(RowStruct); It; ++It)
				{
					FProperty* Property = *It;
					if (!Property || Property->GetName() == "RowType") // 跳过继承的 FTableRowBase 字段
					{
						continue;
					}

					FString PropertyName = Property->GetName();
					int32 IdxS = INDEX_NONE;
					if (PropertyName.FindChar(TEXT('_'), IdxS))
					{
						PropertyName = PropertyName.Left(IdxS);
					}
			
					for (TFieldIterator<FProperty> PropIt(Struct); PropIt; ++PropIt)
					{
						FProperty* PropertyInStruct = *PropIt;
						FString PropertyNameInNewStruct = PropertyInStruct->GetName();
						if (PropertyNameInNewStruct.FindChar(TEXT('_'), IdxS))
						{
							PropertyNameInNewStruct = PropertyNameInNewStruct.Left(IdxS);
						}

						if (PropertyNameInNewStruct == PropertyName)
						{
							if (FStructProperty* StructProp = CastField<FStructProperty>(Property))
							{
								if (StructProp->Struct == FSlateBrush::StaticStruct())
								{
									FStructProperty* NewStructProp = CastField<FStructProperty>(PropertyInStruct);
									if (NewStructProp && NewStructProp->Struct == FKGSlateBrush::StaticStruct())
									{
										FSlateBrush* Data = StructProp->ContainerPtrToValuePtr<FSlateBrush>(RowData);
										FKGSlateBrush Brush;
										Brush.Brush = *Data;
										NewStructProp->SetValue_InContainer(static_cast<void*>(NewData), &Brush);
									}
									else
									{
										ensure(false);
									}
									break;
								}
								else if (StructProp->Struct == FSlateFontInfo::StaticStruct())
								{
									FStructProperty* NewFontProp = CastField<FStructProperty>(PropertyInStruct);
									FSlateFontInfo* Data = StructProp->ContainerPtrToValuePtr<FSlateFontInfo>(RowData);
									FSlateFontInfo NewFont = *Data;
									NewFontProp->SetValue_InContainer(static_cast<void*>(NewData), &NewFont);
									break;
								}
							}
							
							if (Property->IsA<FTextProperty>())
							{
								void* ValuePtr = Property->ContainerPtrToValuePtr<void>(RowData);
								const auto& Value = CastField<FTextProperty>(Property)->GetPropertyValue(ValuePtr);
								if (!Value.IsEmpty())
								{
									FText Text = FText::FromString(Value.ToString());
									ValuePtr = PropertyInStruct->ContainerPtrToValuePtr<void>(NewData);
									CastField<FTextProperty>(PropertyInStruct)->SetPropertyValue(ValuePtr, Text);
								}
							}
							else if (Property->IsA<FStrProperty>())
							{
								void* ValuePtr = Property->ContainerPtrToValuePtr<void>(RowData);
								FString Str = CastField<FStrProperty>(Property)->GetPropertyValue(ValuePtr);
								ValuePtr = PropertyInStruct->ContainerPtrToValuePtr<void>(NewData);
								CastField<FStrProperty>(PropertyInStruct)->SetPropertyValue(ValuePtr, Str);
							}
							else if(Property->IsA<FNameProperty>())
							{
								void* ValuePtr = Property->ContainerPtrToValuePtr<void>(RowData);
								const auto& Value = CastField<FNameProperty>(Property)->GetPropertyValue(ValuePtr);
								FName NameStr(*Value.ToString());
								ValuePtr = PropertyInStruct->ContainerPtrToValuePtr<void>(NewData);
								CastField<FNameProperty>(PropertyInStruct)->SetPropertyValue(ValuePtr, NameStr);
							}
							else if (Property->IsA<FObjectProperty>())
							{
								void* ValuePtr = Property->ContainerPtrToValuePtr<void>(RowData);
								const auto& Value = CastField<FObjectProperty>(Property)->GetPropertyValue(ValuePtr);
								ValuePtr = PropertyInStruct->ContainerPtrToValuePtr<void>(NewData);
								CastField<FObjectProperty>(PropertyInStruct)->SetPropertyValue(ValuePtr, Value);
							}
							else
							{							
								void* Data = FMemory::Malloc(Property->GetSize());
								Property->GetValue_InContainer(RowData, Data);
								PropertyInStruct->SetValue_InContainer(NewData, Data);
								FMemory::Free(Data);
							}

							break;
						}
					}
				}
			}

			Package->MarkPackageDirty();
			
			FString PackageFileName = FPackageName::LongPackageNameToFilename(Package->GetName(), FPackageName::GetAssetPackageExtension());
			FSavePackageArgs SaveArgs;
			SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
			SaveArgs.SaveFlags = SAVE_NoError;
			UPackage::SavePackage(Package, NewDataTable, *PackageFileName, SaveArgs);
		})
);

FAutoConsoleCommand KGUIScanWBP(
	TEXT("KGUI.ScanWBP"),
	TEXT("Usage: KGUI.ScanWBP -class=widgetclass [-exactly] [-listitem]"),
	FConsoleCommandWithArgsDelegate::CreateStatic(&FAssetTypeActions_KGUI::ScanWBP));

#undef LOCTEXT_NAMESPACE

#pragma optimize("", on)