// Copyright Epic Games, Inc. All Rights Reserved.

#include "C7ResourceReplacerCommands.h"

#define LOCTEXT_NAMESPACE "FC7ResourceReplacerModule"

void FC7ResourceReplacerCommands::RegisterCommands()
{
	UI_COMMAND(OpenPluginWindow, "C7ResourceReplacer", "Bring up C7ResourceReplacer window", EUserInterfaceActionType::Button, FInputChord());
}

#undef LOCTEXT_NAMESPACE
