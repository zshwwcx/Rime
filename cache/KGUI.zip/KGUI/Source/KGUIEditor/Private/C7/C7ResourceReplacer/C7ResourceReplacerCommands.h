// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"
#include "C7ResourceReplacerStyle.h"

class FC7ResourceReplacerCommands : public TCommands<FC7ResourceReplacerCommands>
{
public:

	FC7ResourceReplacerCommands()
		: TCommands<FC7ResourceReplacerCommands>(TEXT("C7ResourceReplacer"), NSLOCTEXT("Contexts", "C7ResourceReplacer", "C7ResourceReplacer Plugin"), NAME_None, FC7ResourceReplacerStyle::GetStyleSetName())
	{
	}

	// TCommands<> interface
	virtual void RegisterCommands() override;

public:
	TSharedPtr< FUICommandInfo > OpenPluginWindow;
};