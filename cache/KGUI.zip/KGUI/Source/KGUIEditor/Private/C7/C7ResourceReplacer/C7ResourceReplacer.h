// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Core/ModuleFeature/KGModuleFeature.h"
#include "Input/Reply.h"
#include "Modules/ModuleManager.h"
#include "AssetTypeActions_Base.h"
#include "K2Node_CallFunction.h"
#include "Components/Widget.h"

class FToolBarBuilder;
class FMenuBuilder;

class FC7ResourceReplacerModule : public IKGModuleFeature
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
	
	/** This function will be bound to Command (by default it will bring up plugin window) */
	void PluginButtonClicked();

	
	
	
private:

	FReply ButtonReplaceClicked();

	FReply CheckBoxReplaceClicked();

	FReply BatchSetAudioClicked();

	FString GetFullProcessPath();

	void OnPathChanged(const FText& NewString);

	FString ProcessPath;

	void RegisterMenus();

	TSharedRef<class SDockTab> OnSpawnPluginTab(const class FSpawnTabArgs& SpawnTabArgs);

private:
	TSharedPtr<class FUICommandList> PluginCommands;

	class FResourceReplacer* ResourceReplacer;
};



class KGUIEDITOR_API FAssetTypeActions_KGUI : public FAssetTypeActions_Base
{
public:
	FAssetTypeActions_KGUI(EAssetTypeCategories::Type InAssetCategory);

	virtual ~FAssetTypeActions_KGUI() {}

	virtual FText GetName() const override;

	virtual FColor GetTypeColor() const override;

	virtual UClass* GetSupportedClass() const override;

	virtual bool HasActions(const TArray<UObject*>& InObjects) const override { return true; }
	//virtual bool IsAssetDefinitionInDisguise() const override { return true; }	// return true to keep Engine default UMG AssetTool

	virtual void GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder) override;

	virtual uint32 GetCategories() override;

	virtual void OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor = TSharedPtr<IToolkitHost>()) override;
	virtual void PerformAssetDiff(UObject* OldAsset, UObject* NewAsset, const struct FRevisionInfo& OldRevision, const struct FRevisionInfo& NewRevision) const override;
	virtual void Merge(UObject* BaseAsset, UObject* RemoteAsset, UObject* LocalAsset, const FOnMergeResolved& ResolutionCallback) override;

	void ExecuteScaneButtonsAndHotareas(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects);

	void ExecuteScanVisibleWidget(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects);

	void ExecuteReplaceGPUTurboImageWithKGGPUTurboImage(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects);
	void ExecuteReplaceButtonWithKGAnimArea(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects);
	void ExecuteReplaceWidgetWithKGWidget(TArray<TWeakObjectPtr<class UWidgetBlueprint>> InObjects);

	static void ReplaceOrAddKGAnimArea(class UWidgetBlueprint* WidgetBlueprint);
	static int ReplaceWidget(UWidgetBlueprint* InWidgetBlueprint, UClass* OrigClass, UClass* NewClass, bool bTest = false);

	static void ReplaceWidgetWithKGWidgetForPath(const TArray<FString>& InPaths);

	static void ScanWBPUsingEngineWidget(const TArray<FString>& InPaths);
	static void ScanWBP(const TArray<FString>& Params);
private:
	
	static void ReplaceVariableAndNodeReferences(UWidgetBlueprint* Blueprint, UWidget* OldWidget, UWidget* NewWidget, const FName& TempName);
	static void ReconstructNodes(UWidgetBlueprint* Blueprint);
	static void ReplaceFunctionReferences(UWidgetBlueprint* Blueprint, UClass* OldClass, UClass* NewClass);
	static void ReplaceDelegateSignatures(UBlueprint* Blueprint, UClass* OldClass, UClass* NewClass);
	static void ReplaceFunctionReturnType(UK2Node_CallFunction* Node, UClass* NewClass);
	static void ReplaceAnimBindings(UWidgetBlueprint* Blueprint, UObject* OldObj, UObject* NewObj, const FString& OldName, const FString& NewName = TEXT(""));

};
