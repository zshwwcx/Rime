#pragma once

#include "CoreMinimal.h"



class C7ResourceCleaner
{
public:

	void WriteToFile(FString Data, FString FileName, FString Header = "");

	FString GetReferencedObjectsList(const FName& SelectedPackageName, const TArray<FString>& Args);
	FString GetReferencingObjectsList(const FName& SelectedPackageName, const TArray<FString>& Args);
	
	void DoAssetClean(const TArray<FString>& Args);

	void DoAssetCleanWithV2(const TArray<FString>& Args);

	void RefreshAssetCleanTag(const TArray<FString>& Args);
	void RefreshAssetTag(const FName& SelectedPackageName, const TArray<FString>& Args, FString Tag);

	// 资源扫描过程中，遇到的完全没有任何Hard Referenced的资源
	TArray<FString> PackagesWithNoHardReferenced;
	TArray<FString> PackagesWithNoSoftReferenced;
	// 资源扫描过程中，遇到的完全没有任何Hared Referencing的资源
	TArray<FString> PackagesWithNoHardReferencing;
	TArray<FString> PackagesWithNoSoftReferencing;

	void CleanCacheData()
	{
		PackagesWithNoHardReferenced.Empty();
		PackagesWithNoSoftReferenced.Empty();
		PackagesWithNoHardReferencing.Empty();
		PackagesWithNoSoftReferencing.Empty();
	}
}; 
