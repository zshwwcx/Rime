﻿#pragma once

#include "CoreMinimal.h"
#include "Core/ModuleFeature/KGModuleFeature.h"
#include "C7ResourceCleanerV2.h"
#include "C7ResourceCleaner.h"

/**
 * C7资源清理工具:文档 https://docs.corp.kuaishou.com/d/home/fcACFWYs5ALuD9p6dpMKm1mZw
 * Author: zhangsuohao@kuaishou.com
 */
class FC7ResourceCleanerFeature: public IKGModuleFeature
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
	
	void RegisterConsoleCommand();

private:
	TSharedPtr<C7ResourceCleanerV2> Cleaner = nullptr;
};


