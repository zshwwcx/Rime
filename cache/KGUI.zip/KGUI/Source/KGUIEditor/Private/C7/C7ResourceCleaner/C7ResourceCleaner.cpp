#include "C7ResourceCleaner.h"
#include "EditorAssetLibrary.h"
#include "AssetRegistry/AssetData.h"
#include "UObject/SavePackage.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "UObject/MetaData.h"


void C7ResourceCleaner::WriteToFile(FString Data, FString FileName, FString Header)
{
	// FDateTime CurTime = FDateTime::Now();
	// 获取项目路径
	FString FilePath = FPaths::ProjectSavedDir() + "/UICleaner/" + FileName + ".txt";

	if (!Header.IsEmpty())
	{
		Data = Header + "\n" + Data;
	}

	// 写入文件
	if (FFileHelper::SaveStringToFile(Data, *FilePath))
	{
		UE_LOG(LogTemp, Log, TEXT("[KGUIStaticScanTools] 成功写入文件: %s"), *FilePath);
	}
}

// 默认版本，不过滤文件夹，遍历每一个uasset文件，筛选对应类型，处理引用关系
void C7ResourceCleaner::DoAssetClean(const TArray<FString>& Args)
{
	// 先清理一下临时数据
	CleanCacheData();

	// 获取完整的目录路径
	FString FullDirectoryPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir() + Args[0]);

	IFileManager& FileManager = IFileManager::Get();
	FString FinalPath = FPaths::Combine(FullDirectoryPath, TEXT("*"));
	TArray<FString> FoundDirectories;
	FileManager.FindFiles(FoundDirectories, *FinalPath, false, true);

	for (const FString& DirectoryName : FoundDirectories)
	{
		FString FullPath = FPaths::Combine(FullDirectoryPath, DirectoryName);
		// 遍历指定目录下的文件
		TArray<FString> FileNames;
		IFileManager::Get().FindFilesRecursive(FileNames, *FullPath, TEXT("*.uasset"), true, false);

		for (const FString& FileName : FileNames)
		{
			// 获取完整的文件路径
			FString FullFilePath = FPaths::Combine(FString(""), FileName);
			FString PackageName;
			FString SubRightString;
			FullFilePath.Split("/Client/Content/", &PackageName, &SubRightString);
			SubRightString.Split(".uasset", &PackageName, &SubRightString);
			PackageName = "/Game/" + PackageName;

			if (Args[1] == "Referenced")
			{
				FString ReferencedObjectsResult = GetReferencedObjectsList(FName(*PackageName), Args);
				
				// FString CombinedString = FString::Join(PackagesWithNoHardReferenced, TEXT("\n"));
				// WriteToFile(CombinedString, "UIReferencedInfo");
			}
			else if (Args[1] == "Referencing")
			{
				FString ReferencedObjectsResult = GetReferencingObjectsList(FName(*PackageName), Args);
				// FString CombinedString = FString::Join(PackageWithNoHardReferencing, TEXT("\n"));
				// WriteToFile(CombinedString, "UIReferencingInfo");
			}
		}

	}
	if(!PackagesWithNoHardReferenced.IsEmpty())
	{
		FString FinalString;
		for (auto PackageName: PackagesWithNoHardReferenced)
		{
			if (PackagesWithNoSoftReferenced.Contains(PackageName))
			{
				FinalString += PackageName + "\n";
			}
		}
		WriteToFile(FinalString, "UIReferencedInfo");
	}
	if(!PackagesWithNoHardReferencing.IsEmpty())
	{
		FString FinalString;
		for (auto PackageName: PackagesWithNoHardReferencing)
		{
			if (PackagesWithNoSoftReferencing.Contains(PackageName))
			{
				FinalString += PackageName + "\n";
			}
		}
		WriteToFile(FinalString, "UIReferencingInfo");
	}
}

// 2024/09/24迭代 CleanWithV2版本： 先遍历目录，获取所有文件，判断当前文件是否_2结尾，如果是_2结尾，默认跳过；如果不是_2结尾，检查下是否同时存在_2结尾的同名文件，如果不存在_2结尾的同名文件夹，则该文件也跳过。
void C7ResourceCleaner::DoAssetCleanWithV2(const TArray<FString>& Args)
{
	// 先清理一下临时数据
	CleanCacheData();
	
	// 获取完整的目录路径
	FString FullDirectoryPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir() + Args[0]);

	IFileManager& FileManager = IFileManager::Get();
	FString FinalPath = FPaths::Combine(FullDirectoryPath, TEXT("*"));
	TArray<FString> FoundDirectories;
	FileManager.FindFiles(FoundDirectories, *FinalPath, false, true);

	for (const FString& DirectoryName : FoundDirectories)
	{
		if (!DirectoryName.EndsWith("_2"))
		{
			FString FullPath_V2 = FPaths::Combine(FullDirectoryPath, DirectoryName + "_2");
			if (FileManager.DirectoryExists(*FullPath_V2))
			{
				FString FullPath = FPaths::Combine(FullDirectoryPath, DirectoryName);
				// 遍历指定目录下的文件
				TArray<FString> FileNames;
				IFileManager::Get().FindFilesRecursive(FileNames, *FullPath, TEXT("*.uasset"), true, false);

				for (const FString& FileName : FileNames)
				{
					// 获取完整的文件路径
					FString FullFilePath = FPaths::Combine(FString(""), FileName);
					FString PackageName;
					FString SubRightString;
					FullFilePath.Split("/Client/Content/", &PackageName, &SubRightString);
					SubRightString.Split(".uasset", &PackageName, &SubRightString);
					PackageName = "/Game/" + PackageName;

					if (Args[1] == "Referenced")
					{
						FString ReferencedObjectsResult = GetReferencedObjectsList(FName(*PackageName), Args);
						
						// FString CombinedString = FString::Join(PackagesWithNoHardReferenced, TEXT("\n"));
						// WriteToFile(CombinedString, "UIReferencedInfo");
					}
					else if (Args[1] == "Referencing")
					{
						FString ReferencedObjectsResult = GetReferencingObjectsList(FName(*PackageName), Args);
						// FString CombinedString = FString::Join(PackageWithNoHardReferencing, TEXT("\n"));
						// WriteToFile(CombinedString, "UIReferencingInfo");
					}
				}
			}	
		}
	}
	if(!PackagesWithNoHardReferenced.IsEmpty())
	{
		FString FinalString;
		for (auto PackageName: PackagesWithNoHardReferenced)
		{
			if (PackagesWithNoSoftReferenced.Contains(PackageName))
			{
				FinalString += PackageName + "\n";
			}
		}
		WriteToFile(FinalString, "UIReferencedInfo");
	}
	if(!PackagesWithNoHardReferencing.IsEmpty())
	{
		FString FinalString;
		for (auto PackageName: PackagesWithNoHardReferencing)
		{
			if (PackagesWithNoSoftReferencing.Contains(PackageName))
			{
				FinalString += PackageName + "\n";
			}
		}
		WriteToFile(FinalString, "UIReferencingInfo");
	}
}


// 获取指定package被哪些资源引用到了
FString C7ResourceCleaner::GetReferencedObjectsList(const FName& SelectedPackageName, const TArray<FString>& Args)
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	
	// -- Args[2]匹配资源类型, like Texture2D
	TArray<FAssetData> AssetsInPackage;
	AssetRegistryModule.Get().GetAssetsByPackageName(SelectedPackageName, AssetsInPackage);
	FName AssetType;
	if (AssetsInPackage.Num() > 0)
	{
		const FAssetData& FirstAsset = AssetsInPackage[0];

		AssetType = FirstAsset.AssetClassPath.GetAssetName();
        
		// 资产类型筛选过滤，如静态网格StaticMesh、纹理Texture2D、蓝图WidgetBlueprint等。
		if (Args.Num() >=3 && !Args[2].IsEmpty() && !FirstAsset.AssetClassPath.GetAssetName().ToString().Equals(Args[2]))
		{
			return "";
		}
		// 如果资产不存在AssetCleanTag MetaData，则默认它是新增资产，不需要走过滤操作
		UPackage* AssetPackage = FirstAsset.GetPackage();
		UObject* Object = FirstAsset.GetAsset();
		if (AssetPackage && Object)
		{
			UMetaData* MetaData = AssetPackage->GetMetaData();
			if (IsValid(MetaData))
			{
				FString DataValue = MetaData->GetValue(Object, TEXT("AssetCleanTag"));
				if (DataValue.IsEmpty())
				{
					return "";
				}
			}
		}
	}
	// -- 过滤结束
	
	FString ReferencedObjectsList;
	
	TArray<FName> HardDependencies;
	AssetRegistryModule.Get().GetDependencies(SelectedPackageName, HardDependencies, UE::AssetRegistry::EDependencyCategory::Package, UE::AssetRegistry::EDependencyQuery::Hard);
		
	TArray<FName> SoftDependencies;
	AssetRegistryModule.Get().GetDependencies(SelectedPackageName, SoftDependencies, UE::AssetRegistry::EDependencyCategory::Package, UE::AssetRegistry::EDependencyQuery::Soft);

	ReferencedObjectsList += FString::Printf(TEXT("[%s AssetType:%s - Dependencies]\n"), *SelectedPackageName.ToString(), *AssetType.ToString());

	int32 HardCount = 0;
	int32 SoftCount = 0;
	if (HardDependencies.Num() > 0)
	{
		ReferencedObjectsList += TEXT("  [HARD]\n");
		for (const FName& HardDependency : HardDependencies)
		{
			const FString PackageString = HardDependency.ToString();
			// if ((PackageString.Equals(TEXT("/Script/SlateCore"))) || (PackageString.Equals(TEXT("/Script/UMG"))) || (PackageString.Equals(TEXT("/Script/UMGEditor"))) || (PackageString.Equals(TEXT("/Script/C7")))) {
			// 	
			// }
			// else
			// {
			ReferencedObjectsList += FString::Printf(TEXT("    %s.%s\n"), *PackageString, *FPackageName::GetLongPackageAssetName(PackageString));
			HardCount++;
			// }
		}
	}
	// 默认编辑器资源都会有一个C7PrimaryLabel，所以这里做一个剔除
	if (SoftDependencies.Num() > 0)
	{
		ReferencedObjectsList += TEXT("  [SOFT]\n");
		for (const FName& SoftDependency : SoftDependencies)
		{
			const FString PackageString = SoftDependency.ToString();
			if (PackageString.Equals(TEXT("/Game/ChunkLabels/pakchunk1000")))
			{
				
			}
			else
			{
				ReferencedObjectsList += FString::Printf(TEXT("    %s.%s\n"), *PackageString, *FPackageName::GetLongPackageAssetName(PackageString));
				SoftCount++;	
			}
		}
	}

	if (SoftCount == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("No Soft Referenced except C7PrimaryLabel Object: %s"), *SelectedPackageName.ToString());
		PackagesWithNoSoftReferenced.Add(SelectedPackageName.ToString());
	}

	if (HardCount == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("No Hard Referenced Object: %s"), *SelectedPackageName.ToString());
		PackagesWithNoHardReferenced.Add(SelectedPackageName.ToString());
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("Hard Referenced Object: %s"), *ReferencedObjectsList);
	}

	return ReferencedObjectsList;
}

// 获取指定package引用了哪些资源
FString C7ResourceCleaner::GetReferencingObjectsList(const FName& SelectedPackageName, const TArray<FString>& Args)
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	
	// -- Args[2]匹配资源类型, like Texture2D
	TArray<FAssetData> AssetsInPackage;
	AssetRegistryModule.Get().GetAssetsByPackageName(SelectedPackageName, AssetsInPackage);
	FName AssetType;
	if (AssetsInPackage.Num() > 0)
	{
		const FAssetData& FirstAsset = AssetsInPackage[0];

		AssetType = FirstAsset.AssetClassPath.GetAssetName();
		// 资产类型筛选过滤，如静态网格StaticMesh、纹理Texture2D、蓝图WidgetBlueprint等。
		if (Args.Num() >=3 && !Args[2].IsEmpty() && !AssetType.ToString().Equals(Args[2]))
		{
			return "";
		}
		// 如果资产不存在AssetCleanTag MetaData，则默认它是新增资产，不需要走过滤操作
		UPackage* AssetPackage = FirstAsset.GetPackage();
		UObject* Object = FirstAsset.GetAsset();
		if (AssetPackage && Object)
		{
			UMetaData* MetaData = AssetPackage->GetMetaData();
			if (IsValid(MetaData))
			{
				FString DataValue = MetaData->GetValue(Object, TEXT("AssetCleanTag"));
				if (DataValue.IsEmpty())
				{
					return "";
				}
			}
		}
	}
	// -- 过滤结束

	FString ReferencingObjectsList;

	TArray<FName> HardDependencies;
	AssetRegistryModule.Get().GetReferencers(SelectedPackageName, HardDependencies, UE::AssetRegistry::EDependencyCategory::Package, UE::AssetRegistry::EDependencyQuery::Hard);

	TArray<FName> SoftDependencies;
	AssetRegistryModule.Get().GetReferencers(SelectedPackageName, SoftDependencies, UE::AssetRegistry::EDependencyCategory::Package, UE::AssetRegistry::EDependencyQuery::Soft);

	ReferencingObjectsList += FString::Printf(TEXT("[%s AssetType:%s - Dependencies]\n"), *SelectedPackageName.ToString(), *AssetType.ToString());
	int32 HardCount = 0;
	int32 SoftCount = 0;
	
	if (HardDependencies.Num() > 0)
	{
		ReferencingObjectsList += TEXT("  [HARD]\n");
		for (const FName& HardDependency : HardDependencies)
		{
			const FString PackageString = HardDependency.ToString();
			// if ((PackageString.Equals(TEXT("/Script/SlateCore"))) || (PackageString.Equals(TEXT("/Script/UMG"))) || (PackageString.Equals(TEXT("/Script/UMGEditor"))) || (PackageString.Equals(TEXT("/Script/C7")))) {
			// 	
			// }
			// else
			// {
			ReferencingObjectsList += FString::Printf(TEXT("    %s.%s\n"), *PackageString, *FPackageName::GetLongPackageAssetName(PackageString));
			HardCount++;
			// }
		}
	}
	// 默认编辑器资源都会有一个C7PrimaryLabel，所以这里做一个剔除
	if (SoftDependencies.Num() > 0)
	{
		ReferencingObjectsList += TEXT("  [SOFT]\n");
		for (const FName& SoftDependency : SoftDependencies)
		{
			const FString PackageString = SoftDependency.ToString();
			if (PackageString.Equals(TEXT("/Game/ChunkLabels/pakchunk1000")))
			{
				
			}
			else
			{
				ReferencingObjectsList += FString::Printf(TEXT("    %s.%s\n"), *PackageString, *FPackageName::GetLongPackageAssetName(PackageString));
				SoftCount++;
			}
		}
	}

	if (SoftCount == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("No Soft Referencing except C7PrimaryLabel Object: %s"), *SelectedPackageName.ToString());
		PackagesWithNoSoftReferencing.Add(SelectedPackageName.ToString());
	}

	if (HardCount == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("No Hard Referencing Object: %s"), *SelectedPackageName.ToString());
		PackagesWithNoHardReferencing.Add(SelectedPackageName.ToString());
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("Hard Referencing Object: %s"), *ReferencingObjectsList);
	}

	return ReferencingObjectsList;
	
}

void C7ResourceCleaner::RefreshAssetTag(const FName& SelectedPackageName, const TArray<FString>& Args, FString Tag)
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	
	// -- Args[2]匹配资源类型, like Texture2D
	TArray<FAssetData> AssetsInPackage;
	AssetRegistryModule.Get().GetAssetsByPackageName(SelectedPackageName, AssetsInPackage);
	FName AssetType;
	if (AssetsInPackage.Num() > 0)
	{
		const FAssetData& FirstAsset = AssetsInPackage[0];

		AssetType = FirstAsset.AssetClassPath.GetAssetName();
        
		// 资产类型筛选过滤，如静态网格StaticMesh、纹理Texture2D、蓝图WidgetBlueprint等。
		if (Args.Num() >=2 && !Args[1].IsEmpty() && !AssetType.ToString().Equals(Args[1]))
		{
			return;
		}

		UPackage* AssetPackage = FirstAsset.GetPackage();
		UObject* Object = FirstAsset.GetAsset();
		if (AssetPackage && Object)
		{
			UMetaData* MetaData = AssetPackage->GetMetaData();
			if (IsValid(MetaData))
			{
				MetaData->SetValue(Object, TEXT("AssetCleanTag"), *Tag);
				FSavePackageArgs SaveArgs;
				SaveArgs.TopLevelFlags = RF_Standalone;
				UPackage::SavePackage(AssetPackage, nullptr, *(SelectedPackageName.ToString()), SaveArgs);
			}
		}
	}
}

void C7ResourceCleaner::RefreshAssetCleanTag(const TArray<FString>& Args)
{
	 // 获取完整的目录路径
	FString FullDirectoryPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir() + Args[0]);

	IFileManager& FileManager = IFileManager::Get();
	FString FinalPath = FPaths::Combine(FullDirectoryPath, TEXT("*"));
	TArray<FString> FoundDirectories;
	FileManager.FindFiles(FoundDirectories, *FinalPath, false, true);

	for (const FString& DirectoryName : FoundDirectories)
	{
		FString FullPath = FPaths::Combine(FullDirectoryPath, DirectoryName);
		// 遍历指定目录下的文件
		TArray<FString> FileNames;
		IFileManager::Get().FindFilesRecursive(FileNames, *FullPath, TEXT("*.uasset"), true, false);

		for (const FString& FileName : FileNames)
		{
			// 获取完整的文件路径
			FString FullFilePath = FPaths::Combine(FString(""), FileName);
			FString PackageName;
			FString SubRightString;
			FullFilePath.Split("/Client/Content/", &PackageName, &SubRightString);
			SubRightString.Split(".uasset", &PackageName, &SubRightString);
			PackageName = "/Game/" + PackageName;
			
			RefreshAssetTag(FName(*PackageName), Args, FDateTime::Now().ToString());
		}

	}
}
