﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "HAL/IConsoleManager.h"

struct FC7UICleanObject
{
	
	// 资产ID
	int32 ID = 0;
	// 资产名字
	FString AssetName = "";
	// 资产路径
	FString AssetPath = "";
	// 资产类型
	FString AssetType = "";
	// 资源大小
	float AssetSize = 0.0f;
	// 是否清理
	bool ShouldDelete = false;
	
	FC7UICleanObject() {}
	
	FC7UICleanObject(int32 InID, FString InName, FString InPath, FString InType, int32 InSize)
		: ID(InID), AssetName(InName), AssetPath(InPath), AssetType(InType), AssetSize(InSize) {}
	
};

struct FC7AtlasInfoObject
{
	// 资产ID
	int32 ID = 0;
	// 资产名字
	FString AssetName = "";
	// 被使用的次数
	int32 UseCount = 0;
	// 资产路径
	FString AssetPath = "";
	// 被使用到的地方
	TArray<FName> ReferencerArray;
};

/**
 * 
 */

class C7ResourceCleanerV2
{

public:

	C7ResourceCleanerV2()
	{
		// 蓝图资源引用关系扫描，输出当前没有被任何地方所引用过的蓝图资产
		IConsoleManager::Get().RegisterConsoleCommand(
			TEXT("C7DoAssetClean"),
			TEXT("用例\n"
		   "C7DoAssetClean"),
			FConsoleCommandWithArgsDelegate::CreateRaw(this, &C7ResourceCleanerV2::ScanWidgetBlueprints),
			ECVF_Default
		);
		
		// Common图集信息统计，输出csv格式数据，用于统计图集中每一张sprite的使用情况
		IConsoleManager::Get().RegisterConsoleCommand(
			TEXT("C7DoAtlasAnalysis"),
			TEXT("用例\n"
				"C7DoAtlasAnalysis [AssetPath]"),
				FConsoleCommandWithArgsDelegate::CreateRaw(this, &C7ResourceCleanerV2::AnalysisCommonAtlas),
			ECVF_Default
			);
	};

	~C7ResourceCleanerV2()
	{
		IConsoleManager::Get().UnregisterConsoleObject(TEXT("C7DoAssetClean"));
	}

	TArray<FC7UICleanObject> CleanObjArray;
	
	int32 CurIndex = 0;

	const float InvToMb = 1.0 / (1024 * 1024);
	
	void ResetCacheData();

	void ExportToCSV(FString CSVName);

	// 扫描所有的WidgetBlueprint资产，输出没有任何Referencers的Object，供后续python处理
	void ScanWidgetBlueprints(const TArray<FString>& TempScanPath);

	TArray<FC7AtlasInfoObject> AtlasInfoArray;

	// 统计指定Common Sprite Atlas Group的所有信息
	void AnalysisCommonAtlas(const TArray<FString>& Args);

	void ExportAtlasInfoArrayToCSV(FString CSVName);
	
};
