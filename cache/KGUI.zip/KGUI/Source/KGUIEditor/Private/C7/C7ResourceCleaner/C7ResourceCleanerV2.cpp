﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "C7ResourceCleanerV2.h"

#include "PaperSpriteAtlas.h"
#include "AssetRegistry/AssetData.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "Misc/ConfigCacheIni.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "AssetRegistry/AssetRegistryModule.h"


void C7ResourceCleanerV2::ResetCacheData()
{

	if (!CleanObjArray.IsEmpty())
	{
		CleanObjArray.Empty();
		CleanObjArray.Reserve(10000);
	}

	if (!AtlasInfoArray.IsEmpty())
	{
		AtlasInfoArray.Empty();
		AtlasInfoArray.Reserve(2000);
	}
	
	CurIndex = 0;
}

void C7ResourceCleanerV2::ExportToCSV(FString CSVName)
{
	FString CSVContent;
	CSVContent += "ID,AssetName,AssetPath,AssetType,AssetSize(Mb),NeedClean";
	CSVContent += "\n";

	for (const FC7UICleanObject& Data: CleanObjArray)
	{
		FString CSVString;
		CSVString += FString::Printf(TEXT("%d,"), Data.ID);
		CSVString += Data.AssetName + TEXT(",");
		CSVString += Data.AssetPath + TEXT(",");
		CSVString += Data.AssetType + TEXT(",");
		CSVString += FString::Printf(TEXT("%f,"), Data.AssetSize);
		CSVString += FString::Printf(TEXT("%s,"), Data.ShouldDelete ? TEXT("TRUE"): TEXT("FALSE"));
		CSVContent += CSVString + TEXT("\n");
	}
	
	const FString FilePath = FPaths::ProjectSavedDir() / CSVName;
	FFileHelper::SaveStringToFile(CSVContent, *FilePath);
}

void C7ResourceCleanerV2::ScanWidgetBlueprints(const TArray<FString>& TempScanPath)
{
	// 先清理一下临时数据
	ResetCacheData();

	FString ScanPath = "";
	GConfig->GetString(TEXT("/Script/UMGEditor.UMGEditorProjectSettings"), TEXT("DefaultUIScanPath"), ScanPath, GEditorIni);

	// 获取资产注册表模块
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

	// 查询指定文件夹下的所有资产
	TArray<FAssetData> AssetDataList;
	FARFilter Filter;
	Filter.PackagePaths.Add(FName(*ScanPath));
	Filter.bRecursivePaths = true;
	AssetRegistry.GetAssets(Filter, AssetDataList);

	for (const FAssetData& AssetData: AssetDataList)
	{
		// 获取资产的强弱引用
		TArray<FName> HardReferencers;
		AssetRegistryModule.Get().GetReferencers(AssetData.PackageName, HardReferencers, UE::AssetRegistry::EDependencyCategory::Package, UE::AssetRegistry::EDependencyQuery::Hard);

		TArray<FName> SoftReferencers;
		AssetRegistryModule.Get().GetReferencers(AssetData.PackageName, SoftReferencers, UE::AssetRegistry::EDependencyCategory::Package, UE::AssetRegistry::EDependencyQuery::Soft);

		// 资产在UE编辑器侧无Outer使用，则将其输出到CSV中.
		if (HardReferencers.IsEmpty() && SoftReferencers.IsEmpty())
		{
			CurIndex++;
			// 构造FC7UICleanObject对象
			FC7UICleanObject RecordObj = FC7UICleanObject();
			RecordObj.ID = CurIndex;
			RecordObj.AssetName = AssetData.AssetName.ToString();
			RecordObj.AssetPath = AssetData.PackagePath.ToString();
			RecordObj.AssetType = AssetData.AssetClassPath.GetAssetName().ToString();
			if (TOptional<FAssetPackageData> PackageData = AssetRegistry.GetAssetPackageDataCopy(AssetData.PackageName))
			{
				RecordObj.AssetSize = InvToMb * PackageData->DiskSize;
			}
			CleanObjArray.Add(RecordObj);
			UE_LOG(LogTemp, Log, TEXT("[UC7ResourceCleanerV2_ScanWidgetBlueprints] Find WidgetBlueprint: %s"), *AssetData.PackagePath.ToString());
		}
	}

	ExportToCSV(TEXT("C7UIClean_WidgetBlueprint.csv"));
}


void C7ResourceCleanerV2::ExportAtlasInfoArrayToCSV(FString CSVName)
{
	FString CSVContent;
	CSVContent += "ID,AssetName,UseCount,AssetPath,ReferencerName";
	CSVContent += "\n";

	int IDIndex = 1;

	for (const FC7AtlasInfoObject& Data: AtlasInfoArray)
	{
		FString CSVString;
		// ID
		CSVString += FString::Printf(TEXT("%d,"), IDIndex);
		// AssetName
		CSVString += Data.AssetName + TEXT(",");
		// UseCount
		CSVString += FString::Printf(TEXT("%d,"), Data.UseCount);
		// AssetPath
		CSVString += Data.AssetPath + TEXT(",");
		// Referencer Name
		for (int32 Index = 0; Index < Data.ReferencerArray.Num(); Index++)
		{
			if (Index == 0)
			{
				CSVString += Data.ReferencerArray[Index].ToString() + TEXT(",");
			}
			else
			{
				CSVString += TEXT(" , , , ,");
				CSVString += Data.ReferencerArray[Index].ToString() + TEXT(",");
			}

			CSVString += TEXT("\n");
		}
		
		CSVContent += CSVString + TEXT("\n");

		IDIndex++;
	}
	
	const FString FilePath = FPaths::ProjectSavedDir() / CSVName;
	FFileHelper::SaveStringToFile(CSVContent, *FilePath);
}

void C7ResourceCleanerV2::AnalysisCommonAtlas(const TArray<FString>& Args)
{
	ResetCacheData();

	FString AtlasDirectoryPath = Args[0];
	
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	
	FAssetData AssetData = AssetRegistry.GetAssetByObjectPath(FSoftObjectPath(*AtlasDirectoryPath));
	if (AssetData.IsValid())
	{
		// 先获取AtlasGroup持有的所有UPaperSprite信息
		TArray<FName> AtlasReferencerList;
		AssetRegistry.GetReferencers(AssetData.PackageName, AtlasReferencerList, UE::AssetRegistry::EDependencyCategory::Package, UE::AssetRegistry::EDependencyQuery::Hard);

		for (FName SpritePackageName: AtlasReferencerList)
		{
			TArray<FAssetData> SpriteAssetDataList;
			AssetRegistry.GetAssetsByPackageName(SpritePackageName, SpriteAssetDataList);
			
			for (auto SpriteAsset: SpriteAssetDataList)
			{
				if (SpriteAsset.IsValid())
				{
					TArray<FName> SpriteReferencerList;
					AssetRegistry.GetReferencers(SpriteAsset.PackageName, SpriteReferencerList, UE::AssetRegistry::EDependencyCategory::Package, UE::AssetRegistry::EDependencyQuery::Hard);

					CurIndex++;
					
					FC7AtlasInfoObject Obj;
					Obj.ID = CurIndex;
					Obj.AssetName = SpriteAsset.AssetName.ToString();
					Obj.UseCount = SpriteReferencerList.Num();
					Obj.AssetPath = SpriteAsset.PackagePath.ToString();
					Obj.ReferencerArray = SpriteReferencerList;

					AtlasInfoArray.Add(Obj);
				}
			}
		}

		auto CmpFunction = [](const FC7AtlasInfoObject A, const FC7AtlasInfoObject B)
		{
			return A.UseCount < B.UseCount;
		};
		
		AtlasInfoArray.Sort(CmpFunction);
		
		FString CSVName = AssetData.AssetName.ToString() + TEXT(".csv");

		ExportAtlasInfoArrayToCSV(CSVName);
	}
}
