#include "C7ResourceCleanerFeature.h"

#include "C7ResourceCleanerV2.h"
#include "HAL/IConsoleManager.h"


void FC7ResourceCleanerFeature::StartupModule()
{
#if UE_EDITOR
	RegisterConsoleCommand();
#endif
}

void FC7ResourceCleanerFeature::RegisterConsoleCommand()
{
	Cleaner = MakeShareable(new C7ResourceCleanerV2());
	
}

void FC7ResourceCleanerFeature::ShutdownModule()
{
	
}

