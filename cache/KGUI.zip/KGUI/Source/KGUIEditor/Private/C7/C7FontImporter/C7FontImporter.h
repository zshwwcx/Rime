﻿#pragma once
#include "Engine/TimerHandle.h"
#include "Core/ModuleFeature/KGModuleFeature.h"
#include "Subsystems/ImportSubsystem.h"
#include "ObjectTools.h"
#include "Editor.h"
#include "EditorAssetLibrary.h"

class FC7FontImporter : public IKGModuleFeature
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;


	FTimerHandle TimerHandle;
	
	TArray<FString> Files;
	
	FString DestinationPath;
	
	FString FontName;
	
	// 自动重新导入Font到编辑器中，替换原先的uasset资产
	void ReImportFont(const TArray<FString>& ImportArgs);
	
};
