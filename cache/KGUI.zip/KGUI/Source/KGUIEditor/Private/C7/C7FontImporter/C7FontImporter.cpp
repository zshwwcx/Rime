﻿#include "C7FontImporter.h"
#include "Engine/TimerHandle.h"
#include "HAL/IConsoleManager.h"

void FC7FontImporter::StartupModule()
{
	// FontFace ReImporter
	IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("C7ReImportFont"),
		TEXT("用例\n"
	   "C7ReImportFont {Files} {DestinationPath}"),
		FConsoleCommandWithArgsDelegate::CreateRaw(this, &FC7FontImporter::ReImportFont),
		ECVF_Default
	);
}

void FC7FontImporter::ShutdownModule()
{
	
}


/**
 * 
 * @param InImportArgs
 *  Args[0] Source File Path
 *  Args[1] Import Destination
 *  Args[2] FontName
 */
void FC7FontImporter::ReImportFont(const TArray<FString>& InImportArgs)
{
	if (InImportArgs.Num() < 3)
	{
		UE_LOG(LogTemp, Error, TEXT("C7ReImportFont Error: Args less than 3."));
		return;
	}

	Files.Empty();
	Files.Add(InImportArgs[0]);
 
	DestinationPath = InImportArgs[1];

	FontName = InImportArgs[2];

	GEditor->GetEditorSubsystem<UImportSubsystem>()->ImportNextTick(Files, DestinationPath);

	// 保存资产
	GEditor->GetTimerManager()->SetTimer(TimerHandle, [this] ()
	{
		FString PackageName = ObjectTools::SanitizeInvalidChars(DestinationPath + TEXT("/") + FontName, INVALID_LONGPACKAGE_CHARACTERS);
		//Check if package exist in memory
		UPackage* Pkg = FindPackage(nullptr, *PackageName);
		if (Pkg)
		{
			bool SaveResult = Pkg->MarkPackageDirty();
			UEditorAssetLibrary::SaveAsset(PackageName);
		}
	}, 1.0f, false, 1.0f);
}