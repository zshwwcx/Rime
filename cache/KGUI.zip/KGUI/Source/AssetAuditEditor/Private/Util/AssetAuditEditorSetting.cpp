#include "AssetAuditEditorSetting.h"

FName FUserWidgetState::FilePathName = FName("FilePath");
FName FUserWidgetState::WidgetKeyName = FName("WidgetKey");
FName FUserWidgetState::CostRatioName = FName("CostRatio");
FName FUserWidgetState::WidgetCostName = FName("WidgetCost");
FName FUserWidgetState::AnimationTotalName = FName("AnimationTotal");
FName FUserWidgetState::AnimationMaxName = FName("AnimationMax");

int32 FUserWidgetState::GetCostByName(FName CostName) const
{
	if (CostName == CostRatioName)
	{
		return CostRatio;
	}

	if (CostName == WidgetCostName)
	{
		return Widget;
	}
	if (CostName == AnimationTotalName)
	{
		return Animation;
	}
	if (CostName == AnimationMaxName)
	{
		return AnimationMax;
	}

	if (auto Cost = WidgetCosts.Find(CostName))
	{
		return *Cost;
	}

	return 0;
}

int32 FUserWidgetState::GetThresoldByName(FName CostName) const
{
	if (CostName == WidgetCostName)
	{
		return StaticCast<int32>(Config->WidgetThreshold);
	}
	if (CostName == AnimationTotalName)
	{
		return StaticCast<int32>(Config->AnimationTotalThreshod);
	}
	if (CostName == AnimationMaxName)
	{
		return StaticCast<int32>(Config->AnimationMaxThreshod);
	}

	if (auto Cost = Config->WidgetThresholds.Find(CostName))
	{
		return StaticCast<int32>(*Cost);
	}

	return 0;
}

FString FUserWidgetState::GetCostDisplay(FName CostName) const
{
	auto V = GetCostByName(CostName);
	FString Display;

	if (CostName == CostRatioName)
	{
		Display = FString::Printf(TEXT("%.2f"), V / 100.0f);
	}
	else
	{
		if (auto T = GetThresoldByName(CostName); V > T)
		{
			Display = FString::Format(TEXT("N: {0} ({1})"), {V, T});
		}
		else
		{
			Display = FString::Format(TEXT("Y: {0} ({1})"), {V, T});
		}
	}

	return Display;
}

void FUserWidgetState::Calculate()
{
	if (!Config) return;

	TArray<float> WRatios;
	WRatios.Add(StaticCast<float>(Widget) / StaticCast<int32>(Config->WidgetThreshold));
	WRatios.Add(StaticCast<float>(Animation) / StaticCast<int32>(Config->AnimationTotalThreshod));
	WRatios.Add(StaticCast<float>(AnimationMax) / StaticCast<int32>(Config->AnimationMaxThreshod));

	for (auto KV : WidgetCosts)
	{
		int32 WT = 0;
		if (auto T = Config->WidgetThresholds.Find(KV.Key))
		{
			WT = StaticCast<int32>(*T);
		}

		auto WCost = StaticCast<float>(KV.Value);
		auto WRatio = WT > 0 ? WCost / WT : 0;

		WRatios.Add(WRatio);
	}

	bool bInv = false;
	for (auto R : WRatios)
	{
		if (R > 1)
		{
			bInv = true;
			break;
		}
	}

	float Ratio = 0.0f;
	for (auto R : WRatios)
	{
		Ratio += bInv ? FMath::Max(R, 1) : R;
	}

	CostRatio = Ratio * 100 / WRatios.Num();
}

void FUserWidgetState::ResetCost()
{
	Widget = 0;
	Animation = 0;
	AnimationMax = 0;
	CostRatio = 0;
	WidgetCosts.Empty();
	Binds.Empty();
}

EInvalidateType* FUWidgetConfig::GetInvalidate(FName PropertyPath)
{
	auto Inv = PropertyInvalidates.Find(PropertyPath);
	if (!Inv)
	{
		auto PPathStr = PropertyPath.ToString();
		int32 Pos;
		PPathStr.FindChar('.', Pos);
		if (Pos >= 0)
		{
			PropertyPath = FName(PPathStr.Mid(0, Pos));
			Inv = PropertyInvalidates.Find(PropertyPath);
		}
	}

	return Inv;
}

UAssetAuditEditorSetting::UAssetAuditEditorSetting(const FObjectInitializer& ObjectInitializer) :
	Super(ObjectInitializer)
{
	RefreshSetting();
}

FUWidgetConfig* UAssetAuditEditorSetting::GetWidgetConfig(const UVisual* Widget)
{
	auto Cls = Widget->GetClass();

	for (int i = 0; i < MaxWidgetChainLoop; ++i)
	{
		if (!Cls || Cls == UVisual::StaticClass())
		{
			break;
		}

		auto CName = Cls->GetFName();
		if (auto WC = WidgetConfigs.Find(CName))
		{
			return WC;
		};

		Cls = Cls->GetSuperClass();
	}

	return nullptr;
}

EInvalidateType* UAssetAuditEditorSetting::GetWidgetPropertyInv(const UVisual* Widget, FName Property)
{
	auto Cls = Widget->GetClass();

	for (int i = 0; i < MaxWidgetChainLoop; ++i)
	{
		if (!Cls || Cls == UVisual::StaticClass())
		{
			break;
		}

		auto CName = Cls->GetFName();
		if (auto WC = WidgetConfigs.Find(CName))
		{
			if (auto Inv = WC->GetInvalidate(Property))
			{
				return Inv;
			}
		};

		Cls = Cls->GetSuperClass();
	}

	return nullptr;
}

FUserWidgetConfig* UAssetAuditEditorSetting::GetUserWidgetConfig(UWidgetBlueprint* Blueprint)
{
	return GetUserWidgetConfigByPackage(Blueprint->GetPackage()->GetFName());
}

FUserWidgetConfig* UAssetAuditEditorSetting::GetUserWidgetConfigByPackage(FName Package)
{
	auto Num = UserWidgetConfigs.Num();

	for (int i = 0; i < Num; ++i)
	{
		auto C = &UserWidgetConfigs[i];
		if (C->Specifics.Contains(Package))
		{
			return C;
		}

		auto InPath = false;
		auto PN = Package.ToString();
		for (auto P : C->Path)
		{
			if (PN.StartsWith(P))
			{
				InPath = true;
				break;
			}
		}

		if (!InPath)
		{
			continue;
		}

		auto WithSuffix = C->Suffix.Num() == 0;
		if (!WithSuffix)
		{
			for (auto S : C->Suffix)
			{
				if (PN.EndsWith(S))
				{
					WithSuffix = true;
					break;
				}
			}
		}

		if (!WithSuffix)
		{
			continue;
		}

		return C;
	}

	return &FallbackUserWidgetConfig;
}

FUserWidgetConfig* UAssetAuditEditorSetting::GetUserWidgetConfig(FName WidgetKey)
{
	auto Num = UserWidgetConfigs.Num();

	for (int i = 0; i < Num; ++i)
	{
		auto C = &UserWidgetConfigs[i];
		if (C->Key == WidgetKey)
		{
			return C;
		}
	}

	return &FallbackUserWidgetConfig;
}

void UAssetAuditEditorSetting::RefreshSetting()
{
	auto Max = 1;
	for (auto KV : InvalidateConfigs)
	{
		auto Cost = StaticCast<int32>(KV.Value.Cost);
		if (Cost > Max)
		{
			Max = Cost;
		}
	}

	InvMaxCost = Max;
}
