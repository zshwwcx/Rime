#pragma once
#include "Styling/SlateStyle.h"

class FAssetAuditStyle : public FSlateStyleSet
{
public:
	FAssetAuditStyle();
	virtual ~FAssetAuditStyle() override;

	static TSharedPtr<ISlateStyle> GetInstance()
	{
		if (!Instance.IsValid())
		{
			Instance = MakeShared<FAssetAuditStyle>();
		}

		return Instance;
	}

private:
	static TSharedPtr<ISlateStyle> Instance;
	
};
