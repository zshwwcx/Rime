#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "AssetAuditEditorPreference.generated.h"

UCLASS(config=EditorPerProjectUserSettings)
class ASSETAUDITEDITOR_API UAssetAuditEditorPreference : public UObject
{
	GENERATED_BODY()

public:
	UAssetAuditEditorPreference(const FObjectInitializer& ObjectInitializer)
	{
		DisplayInDesign = false;
		EnableAutoRefresh = false;
	}

	UPROPERTY(Config, EditAnywhere)
	bool DisplayInDesign;

	UPROPERTY(Config, EditAnywhere)
	bool EnableAutoRefresh;

	static UAssetAuditEditorPreference* GetInstance()
	{
		return GetMutableDefault<UAssetAuditEditorPreference>();
	}
};
