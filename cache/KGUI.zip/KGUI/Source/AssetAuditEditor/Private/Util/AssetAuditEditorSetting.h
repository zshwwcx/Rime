#pragma once

#include "CoreMinimal.h"
#include "WidgetBlueprint.h"
#include "Components/Widget.h"
#include "UObject/Object.h"
#include "AssetAuditEditorSetting.generated.h"

constexpr int MaxWidgetChainLoop = 8;

UENUM()
enum class EAuditCostType
{
	X0 = 0,
	X1 = 1,
	X2 = 2,
	X4 = 4,
	X8 = 8,
	X16 = 16,
	X32 = 32,
	X64 = 64,
	X128 = 128,
	X256 = 256,
	X512 = 512,
	Forbidden = 9999,
};

UENUM()
enum class EInvalidateType
{
	Layout = 1,
	Paint = 2,
	Volatility = 3,
	ChildOrder = 4,
	RenderTransform = 5,
	Visibility = 6,
	AttributeRegistration = 7,
	Prepass = 8
};

USTRUCT()
struct FUWidgetConfig
{
	GENERATED_BODY()

	FUWidgetConfig() : WidgetCost(EAuditCostType::X0)
	{
	}

	UPROPERTY(EditAnywhere)
	EAuditCostType WidgetCost;

	UPROPERTY(EditAnywhere)
	TMap<FName, EInvalidateType> PropertyInvalidates;

	EInvalidateType* GetInvalidate(FName Property);
};

USTRUCT()
struct FInvalidateConfig
{
	GENERATED_BODY()

	FInvalidateConfig() :
		Cost(EAuditCostType::X8)
	{
	}

	UPROPERTY(EditAnywhere)
	EAuditCostType Cost;
};

USTRUCT()
struct FUserWidgetConfig
{
	GENERATED_BODY()

	FUserWidgetConfig() :
		WidgetThreshold(EAuditCostType::X16),
		AnimationTotalThreshod(EAuditCostType::X16),
		AnimationMaxThreshod(EAuditCostType::X4)
	{
	}

	UPROPERTY(EditAnywhere)
	FName Key;

	UPROPERTY(EditAnywhere)
	TArray<FString> Path;

	UPROPERTY(EditAnywhere)
	TArray<FString> Suffix;

	UPROPERTY(EditAnywhere)
	TSet<FName> Specifics;

	UPROPERTY(EditAnywhere)
	EAuditCostType WidgetThreshold;

	UPROPERTY(EditAnywhere)
	EAuditCostType AnimationTotalThreshod;

	UPROPERTY(EditAnywhere)
	EAuditCostType AnimationMaxThreshod;

	UPROPERTY(EditAnywhere)
	TMap<FName, EAuditCostType> WidgetThresholds;
};

USTRUCT()
struct FAuditAnimationState
{
	GENERATED_BODY()

	int32 Cost;
	int32 TrackCount;
};

USTRUCT()
struct FAuditAnimationBind
{
	GENERATED_BODY()
	FAuditAnimationBind() : TotalCost(0), MaxCost(0)
	{
	}

	int32 TotalCost;
	int32 MaxCost;
	TMap<FName, int32> PropertyCosts;
};

USTRUCT()
struct FUserWidgetState
{
	GENERATED_BODY()

	FUserWidgetState() :
		Widget(0), Animation(0), AnimationMax(0), AnimationCurrent(0),
		CostRatio(0), Config(nullptr)
	{
	}

	static FName FilePathName;
	static FName WidgetKeyName;
	static FName CostRatioName;
	static FName WidgetCostName;
	static FName AnimationTotalName;
	static FName AnimationMaxName;

	int32 Widget;
	int32 Animation;
	int32 AnimationMax;
	int32 AnimationCurrent;

	TMap<FName, int32> WidgetCosts;

	FString TargetAnimation;
	TMap<FGuid, FAuditAnimationBind> Binds;

	int32 CostRatio;

	FSoftObjectPath ObjectPath;
	FUserWidgetConfig* Config;

	int32 GetCostByName(FName CostName) const;
	int32 GetThresoldByName(FName CostName) const;
	FString GetCostDisplay(FName CostName) const;

	void Calculate();
	void ResetCost();
};

UCLASS(config=AssetAuditEditor, defaultconfig, meta=(DisplayName="AssetAuditEditorSetting"))
class ASSETAUDITEDITOR_API UAssetAuditEditorSetting : public UObject
{
	GENERATED_BODY()

public:
	UAssetAuditEditorSetting(const FObjectInitializer& ObjectInitializer);

	UPROPERTY(Config, EditAnywhere, Category="User Widget")
	TMap<FName, FUWidgetConfig> WidgetConfigs;
	UPROPERTY(Config, EditAnywhere, Category="User Widget")
	TMap<EInvalidateType, FInvalidateConfig> InvalidateConfigs;
	UPROPERTY(Config, EditAnywhere, Category="User Widget")
	TArray<FUserWidgetConfig> UserWidgetConfigs;
	UPROPERTY(Config, EditAnywhere, Category="User Widget")
	FUserWidgetConfig FallbackUserWidgetConfig;

	int32 InvMaxCost;

	static UAssetAuditEditorSetting* GetInstance()
	{
		return GetMutableDefault<UAssetAuditEditorSetting>();
	}

	FUWidgetConfig* GetWidgetConfig(const UVisual* Widget);

	EInvalidateType* GetWidgetPropertyInv(const UVisual* Widget, FName Property);

	FUserWidgetConfig* GetUserWidgetConfig(UWidgetBlueprint* Blueprint);

	FUserWidgetConfig* GetUserWidgetConfigByPackage(FName Package);

	FUserWidgetConfig* GetUserWidgetConfig(FName WidgetKey);

	void RefreshSetting();
};
