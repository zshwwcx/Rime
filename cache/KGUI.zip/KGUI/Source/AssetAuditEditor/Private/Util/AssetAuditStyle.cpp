#include "AssetAuditStyle.h"
#include "Interfaces/IPluginManager.h"
#include "Styling/SlateStyleRegistry.h"

#define IMAGE_BRUSH(RelativePath, ...) FSlateImageBrush(RootToContentDir(RelativePath, TEXT(".png")), __VA_ARGS__)

TSharedPtr<ISlateStyle> FAssetAuditStyle::Instance = nullptr;

FAssetAuditStyle::FAssetAuditStyle()
	: FSlateStyleSet("AssetAuditStyle")
{
	const FVector2D Icon40x(40, 40);
	FSlateStyleSet::SetContentRoot(IPluginManager::Get().FindPlugin("KGUI")->GetBaseDir() / TEXT("Resources"));
	Set("AuditEditor.IconAudit", new IMAGE_BRUSH("Icons/audit_40x", Icon40x));
	Set("AuditEditor.IconLine", new IMAGE_BRUSH("Icons/line_40x", Icon40x));
	FSlateStyleRegistry::RegisterSlateStyle(*this);
}

FAssetAuditStyle::~FAssetAuditStyle()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*this);
}
