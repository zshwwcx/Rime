#pragma once
#include "MVVM/ViewModels/OutlinerIndicators/OutlinerIndicatorBuilderBase.h"

using namespace UE::Sequencer;

class FAuditTrackOutlinerIndicator : public FOutlinerIndicatorBuilderBase
{
public:
	FAuditTrackOutlinerIndicator();

	virtual FName GetIndicatorName() const override;

	virtual bool IsItemCompatibleWithIndicator(const FCreateOutlinerColumnParams& InParams) const override;

	virtual TSharedPtr<SWidget> CreateIndicatorWidget(
		const FCreateOutlinerColumnParams& InParams, const TSharedRef<ISequencerTreeViewRow>& TreeViewRow,
		const TSharedRef<IOutlinerColumn>& OutlinerColumn, const int32 NumCompatibleIndicators) override;
};
