#pragma once
#include "IHasDesignerExtensibility.h"

class FAuditUserWidgetExtensionFactory :
	public IDesignerExtensionFactory,
	public TSharedFromThis<FAuditUserWidgetExtensionFactory>
{
public:
	FAuditUserWidgetExtensionFactory()
	{
	}

	virtual ~FAuditUserWidgetExtensionFactory() override
	{
	}

	virtual TSharedRef<FDesignerExtension> CreateDesignerExtension() const override;
};
