#include "AuditUserWidgetExtensionFactory.h"

#include "AuditUserWidgetExtension.h"

TSharedRef<FDesignerExtension> FAuditUserWidgetExtensionFactory::CreateDesignerExtension() const
{
	return StaticCastSharedRef<FAuditUserWidgetExtension>(MakeShared<FAuditUserWidgetExtension>());
}
