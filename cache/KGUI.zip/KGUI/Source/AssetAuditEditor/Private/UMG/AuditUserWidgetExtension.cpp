#include "AuditUserWidgetExtension.h"
#include "WidgetBlueprint.h"
#include "WidgetBlueprintEditor.h"
#include "Animation/WidgetAnimation.h"
#include "Core/AuditManager.h"
#include "Toolkits/ToolkitManager.h"
#include "Util/AssetAuditEditorPreference.h"

static constexpr FLinearColor NormalColor(0.7, 0.7, 0.7, 0.3);
//static constexpr FLinearColor WarnColor(1, 0.6, 0, 0.4);
static constexpr FLinearColor ErrorColor(1, 0, 0, 0.6);
static constexpr int32 PaddingX = 6;
static constexpr int32 LineHeight = 14;

void FAuditUserWidgetExtension::Initialize(IUMGDesigner* InDesigner, UWidgetBlueprint* InBlueprint)
{
	FDesignerExtension::Initialize(InDesigner, InBlueprint);

	auto AssetEditor = FToolkitManager::Get().FindEditorForAsset(Blueprint.Get());
	if (auto Editor = StaticCastSharedPtr<FWidgetBlueprintEditor>(AssetEditor))
	{
		BlueprintEditor = Editor.ToWeakPtr();
		Editor->OnSelectedAnimationChanged.AddRaw(this, &FAuditUserWidgetExtension::OnSelectedAnimationChanged);
	}

	Blueprint->OnChanged().AddRaw(this, &FAuditUserWidgetExtension::OnBlueprintChanged);

	Audit = MakeShareable(new FAuditUserWidget());

	UAssetAuditEditorSetting::GetInstance()->RefreshSetting();
	State = MakeShareable(new FUserWidgetState());
	State->ObjectPath = InBlueprint->GetPathName();

	FAuditUserWidget::StateCache.FindOrAdd(State);

	AuditImp();

	UE_LOG(LogTemp, Log, TEXT("Init %s"), *InBlueprint->GetPackage()->GetName());
}

void FAuditUserWidgetExtension::Uninitialize()
{
	FAuditUserWidget::StateCache.Remove(State);

	Audit.Reset();
	State.Reset();

	if (BlueprintEditor.IsValid())
	{
		BlueprintEditor.Pin()->OnSelectedAnimationChanged.RemoveAll(this);
	}

	if (Blueprint.IsValid())
	{
		UE_LOG(LogTemp, Log, TEXT("UnInit %s"), *Blueprint->GetPackage()->GetName());
		Blueprint->OnChanged().RemoveAll(this);
		for (auto CAnim : Blueprint->Animations)
		{
			CAnim->OnSignatureChanged().RemoveAll(this);
		}
	}

	FDesignerExtension::Uninitialize();
}

void FAuditUserWidgetExtension::PreviewContentChanged(TSharedRef<SWidget> NewContent)
{
}

bool FAuditUserWidgetExtension::CanExtendSelection(const TArray<FWidgetReference>& Selection) const
{
	//UE_LOG(LogTemp, Log, TEXT("Select %d"), Selection.Num());
	return false;
}

void FAuditUserWidgetExtension::ExtendSelection(
	const TArray<FWidgetReference>& Selection, TArray<TSharedRef<FDesignerSurfaceElement>>& SurfaceElements)
{
}

inline FLinearColor GetColor(int32 Cost, int32 Threshold)
{
	return Cost > Threshold ? ErrorColor : NormalColor;
}

inline FLinearColor GetColor(int32 Cost, EAuditCostType Threshold)
{
	return GetColor(Cost, StaticCast<int32>(Threshold));
}

void FAuditUserWidgetExtension::Paint(
	const TSet<FWidgetReference>& Selection, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect,
	FSlateWindowElementList& OutDrawElements, int32 LayerId) const
{
	if (!UAssetAuditEditorPreference::GetInstance()->DisplayInDesign) return;

	auto Config = UAssetAuditEditorSetting::GetInstance()->GetUserWidgetConfig(Blueprint.Get());
	if (!Config) return;

	LayerId += 100;

	auto FontInfo = FAppStyle::Get().GetFontStyle("NormalFontBold");
	FontInfo.Size = 9;

	int32 Y = 75;

	FSlateDrawElement::MakeText(
		OutDrawElements, LayerId,
		AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(FVector2D(PaddingX, Y))),
		FString::Printf(TEXT("Rate: %.2f"), State->CostRatio / 100.0f),
		FontInfo, ESlateDrawEffect::None, GetColor(State->CostRatio, 100)
	);

	FSlateDrawElement::MakeText(
		OutDrawElements, LayerId,
		AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(FVector2D(PaddingX, Y += LineHeight))),
		FString::Printf(TEXT("Widget: %d (%d)"), State->Widget, Config->WidgetThreshold),
		FontInfo, ESlateDrawEffect::None, GetColor(State->Widget, Config->WidgetThreshold)
	);

	if (State->Animation > 0)
	{
		FSlateDrawElement::MakeText(
			OutDrawElements, LayerId,
			AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(FVector2D(PaddingX, Y += LineHeight))),
			FString::Printf(TEXT("Animation Total: %d (%d)"), State->Animation, Config->AnimationTotalThreshod),
			FontInfo, ESlateDrawEffect::None, GetColor(State->Animation, Config->AnimationTotalThreshod)
		);

		FSlateDrawElement::MakeText(
			OutDrawElements, LayerId,
			AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(FVector2D(PaddingX, Y += LineHeight))),
			FString::Printf(TEXT("Animation Max: %d (%d)"), State->AnimationMax, Config->AnimationMaxThreshod),
			FontInfo, ESlateDrawEffect::None, GetColor(State->AnimationMax, Config->AnimationMaxThreshod)
		);
	}

	if (!State->TargetAnimation.IsEmpty())
	{
		FSlateDrawElement::MakeText(
			OutDrawElements, LayerId,
			AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(FVector2D(PaddingX, Y += LineHeight))),
			FString::Printf(TEXT("Animation Current: %d (%d)"), State->AnimationCurrent, Config->AnimationMaxThreshod),
			FontInfo, ESlateDrawEffect::None, GetColor(State->AnimationCurrent, Config->AnimationMaxThreshod)
		);
	}

	for (auto& [Key, Value] : State->WidgetCosts)
	{
		auto Threshold = Config->WidgetThresholds.Find(Key);
		if (!Threshold) continue;

		FSlateDrawElement::MakeText(
			OutDrawElements, LayerId,
			AllottedGeometry.ToPaintGeometry(FSlateLayoutTransform(FVector2D(PaddingX, Y += LineHeight))),
			FString::Printf(TEXT("%s: %d (%d)"), *Key.ToString(), Value, *Threshold),
			FontInfo, ESlateDrawEffect::None, GetColor(Value, *Threshold)
		);
	}
}

void FAuditUserWidgetExtension::OnBlueprintChanged(UBlueprint* BP)
{
	if (!UAssetAuditEditorPreference::GetInstance()->EnableAutoRefresh)
	{
		return;
	}

	AuditImp();
}

void FAuditUserWidgetExtension::OnSelectedAnimationChanged()
{
	if (!BlueprintEditor.IsValid() || !Blueprint.IsValid())
	{
		return;
	}

	if (auto Anim = BlueprintEditor.Pin()->GetCurrentAnimation())
	{
		State->TargetAnimation = Anim->GetDisplayLabel();

		for (auto CAnim : Blueprint->Animations)
		{
			CAnim->OnSignatureChanged().RemoveAll(this);
		}

		if (!State->TargetAnimation.IsEmpty())
		{
			AuditImp();
			Anim->OnSignatureChanged().AddRaw(this, &FAuditUserWidgetExtension::OnAnimationChanged);
		}
	}
	else
	{
		State->TargetAnimation = FString();
	}
}

void FAuditUserWidgetExtension::OnAnimationChanged()
{
	if (!UAssetAuditEditorPreference::GetInstance()->EnableAutoRefresh)
	{
		return;
	}

	//UE_LOG(LogTemp, Log, TEXT("Audit Animation Change %s"), *Blueprint->GetPackage()->GetName());
	AuditImp();
}

bool FAuditUserWidgetExtension::AuditImp()
{
	if (!UAssetAuditEditorPreference::GetInstance()->DisplayInDesign)
	{
		return true;
	}

	if (!Blueprint.IsValid() || !State.IsValid())
	{
		return false;
	}

	State->Config = UAssetAuditEditorSetting::GetInstance()->GetUserWidgetConfig(Blueprint.Get());

	if (!State->Config)
	{
		return true;
	}

	//UE_LOG(LogTemp, Log, TEXT("Audit Refresh %s"), *Blueprint->GetPackage()->GetName());

	State->ResetCost();
	Audit->AuditBP(Blueprint.Get(), State.Get());
	State->Calculate();

	return true;
}
