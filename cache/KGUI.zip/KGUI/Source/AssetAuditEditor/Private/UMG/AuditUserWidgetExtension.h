#pragma once
#include "DesignerExtension.h"
#include "Widget/AuditUserWidget.h"

class FAuditUserWidgetExtension : public FDesignerExtension
{
public:
	FAuditUserWidgetExtension() : BlueprintEditor(nullptr), Audit(nullptr)
	{
	}

	virtual ~FAuditUserWidgetExtension() override
	{
	}

	virtual void Initialize(IUMGDesigner* InDesigner, UWidgetBlueprint* InBlueprint) override;
	virtual void Uninitialize() override;

	virtual void PreviewContentChanged(TSharedRef<SWidget> NewContent) override;

	virtual bool CanExtendSelection(const TArray<FWidgetReference>& Selection) const override;

	virtual void ExtendSelection(
		const TArray<FWidgetReference>& Selection,
		TArray<TSharedRef<FDesignerSurfaceElement>>& SurfaceElements) override;

	virtual void Paint(
		const TSet<FWidgetReference>& Selection, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect,
		FSlateWindowElementList& OutDrawElements, int32 LayerId) const override;

private:
	TWeakPtr<FWidgetBlueprintEditor> BlueprintEditor;

	TSharedPtr<FAuditUserWidget> Audit;
	TSharedPtr<FUserWidgetState> State;

	void OnBlueprintChanged(UBlueprint* BP);
	void OnSelectedAnimationChanged();
	void OnAnimationChanged();

	bool AuditImp();
};
