#include "AuditTrackOutlinerIndicator.h"
#include "Core/AuditManager.h"
#include "MVVM/Extensions/IObjectBindingExtension.h"
#include "MVVM/Extensions/IOutlinerExtension.h"
#include "MVVM/Extensions/ITrackExtension.h"
#include "MVVM/ViewModels/EditorViewModel.h"
#include "MVVM/ViewModels/OutlinerColumns/IOutlinerColumn.h"
#include "Tracks/MovieScenePropertyTrack.h"
#include "Util/AssetAuditEditorPreference.h"
#include "Util/AssetAuditEditorSetting.h"

static const FName IndicatorName("Audit Track");

static constexpr FLinearColor MinColor(0, 1, 0, 0.4);
static constexpr FLinearColor MaxColor(1, 0, 0, 0.6);

using namespace UE::Sequencer;

FAuditTrackOutlinerIndicator::FAuditTrackOutlinerIndicator()
{
}

FName FAuditTrackOutlinerIndicator::GetIndicatorName() const
{
	return IndicatorName;
}

bool FAuditTrackOutlinerIndicator::IsItemCompatibleWithIndicator(const FCreateOutlinerColumnParams& InParams) const
{
	if (!UAssetAuditEditorPreference::GetInstance()->DisplayInDesign) return false;

	if (InParams.OutlinerExtension.AsModel()->CastThis<IObjectBindingExtension>())
	{
		return true;
	}
	else if (InParams.OutlinerExtension.AsModel()->CastThis<ITrackExtension>())
	{
		return true;
	}

	return false;
}

void GetPropertyInvalidate(FGuid Guid, FName PropertyPath, int32& Max, int32& Sum)
{
	for (auto State : FAuditUserWidget::StateCache)
	{
		if (!State.IsValid()) continue;

		if (auto Bind = State->Binds.Find(Guid))
		{
			if (PropertyPath.IsNone())
			{
				Max = Bind->MaxCost;
				Sum = Bind->TotalCost;
				return;
			}

			if (auto Cost = Bind->PropertyCosts.Find(PropertyPath))
			{
				Max = *Cost;
				Sum = *Cost;
				return;
			}
		}
	}

	Max = 0;
	Sum = 0;
}

TSharedPtr<SWidget> FAuditTrackOutlinerIndicator::CreateIndicatorWidget(
	const FCreateOutlinerColumnParams& InParams, const TSharedRef<ISequencerTreeViewRow>& TreeViewRow,
	const TSharedRef<IOutlinerColumn>& OutlinerColumn, const int32 NumCompatibleIndicators)
{
	int MaxCost = 0;
	int SumCost = 0;

	if (auto BindModel = InParams.OutlinerExtension.AsModel()->CastThis<IObjectBindingExtension>())
	{
		GetPropertyInvalidate(BindModel->GetObjectGuid(), FName(), MaxCost, SumCost);
		//UE_LOG(LogTemp, Log, TEXT("Animation B %s %d"), *BindModel->GetObjectGuid().ToString(), InvCost);
	}
	else if (auto TrackModel = InParams.OutlinerExtension.AsModel()->CastThis<ITrackExtension>())
	{
		if (auto T = TrackModel->GetTrack())
		{
			if (auto PT = Cast<UMovieScenePropertyTrack>(T))
			{
				GetPropertyInvalidate(T->FindObjectBindingGuid(), PT->GetPropertyPath(), MaxCost, SumCost);
				//UE_LOG(LogTemp, Log, TEXT("Animation P %s %s %d"), *T->FindObjectBindingGuid().ToString(),*PT->GetPropertyPath().ToString(), InvCost);
			}
			else
			{
				GetPropertyInvalidate(T->FindObjectBindingGuid(), T->GetFName(), MaxCost, SumCost);
			}
		}
	}

	auto Max = UAssetAuditEditorSetting::GetInstance()->InvMaxCost;
	float Ratio = MaxCost / StaticCast<float>(Max);
	auto Tip = FString::Printf(TEXT("Cost: X%d "), SumCost);

	auto Color = FLinearColor::LerpUsingHSV(MinColor, MaxColor, Ratio);
	return SNew(SOverlay)
		+ SOverlay::Slot()
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(SBox)
			.HeightOverride(16)
			[
				SNew(SImage)
				.Image(FSlateIcon("AssetAuditStyle", "AuditEditor.IconLine").GetIcon())
				.ColorAndOpacity(FSlateColor(Color))
				.ToolTip(SNew(SToolTip).Text(FText::FromString(Tip)))
			]
		];
}
