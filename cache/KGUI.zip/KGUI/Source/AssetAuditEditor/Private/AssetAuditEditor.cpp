﻿#include "AssetAuditEditor.h"
#include "ContentBrowserModule.h"
#include "ISequencerModule.h"
#include "ISettingsModule.h"
#include "LevelEditor.h"
#include "UMGEditorModule.h"
#include "WorkspaceMenuStructure.h"
#include "WorkspaceMenuStructureModule.h"
#include "Core/AuditManager.h"
#include "Engine/AssetManager.h"
#include "UMG/AuditTrackOutlinerIndicator.h"
#include "UMG/AuditUserWidgetExtensionFactory.h"
#include "Util/AssetAuditEditorPreference.h"
#include "Util/AssetAuditEditorSetting.h"
#include "Util/AssetAuditStyle.h"

#define LOCTEXT_NAMESPACE "FAssetAuditEditorModule"

const FName FAssetAuditEditorModule::AssetAuditTabName = TEXT("KAssetAudit");

FDelegateHandle AuditTrackHandle;

void RegisterSettings()
{
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->RegisterSettings(
			"Project", "Plugins", "Asset Audit Editor",
			FText::FromString("Asset Audit"),
			FText::FromString("Asset Audit Editor Settings"),
			GetMutableDefault<UAssetAuditEditorSetting>());

		SettingsModule->RegisterSettings(
			"Editor", "Plugins", "Asset Audit Editor",
			FText::FromString("Asset Audit"),
			FText::FromString("Asset Audit Editor Preferences"),
			GetMutableDefault<UAssetAuditEditorPreference>());
	}
}

void UnregisterSettings()
{
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->UnregisterSettings("Project", "Plugins", "Asset Audit Editor");
		SettingsModule->UnregisterSettings("Editor", "Plugins", "Asset Audit Editor");
	}
}

void FAssetAuditEditorModule::ShowEditorSettings()
{
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->ShowViewer("Project", "Plugins", "Asset Audit Editor");
	}
}

void FAssetAuditEditorModule::ShowEditorPreferences()
{
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->ShowViewer("Editor", "Plugins", "Asset Audit Editor");
	}
}

void FAssetAuditEditorModule::StartupModule()
{
	Style = FAssetAuditStyle::GetInstance();

	auto& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");

	auto& FolderMenuExtenders = ContentBrowserModule.GetAllPathViewContextMenuExtenders();
	FolderMenuExtenders.Add(
		FContentBrowserMenuExtender_SelectedPaths::CreateStatic(&FAssetAuditEditorModule::OnExtendFolderContextMenu));

	auto& AssetMenuExtenders = ContentBrowserModule.GetAllAssetViewContextMenuExtenders();
	AssetMenuExtenders.Add(
		FContentBrowserMenuExtender_SelectedAssets::CreateStatic(&FAssetAuditEditorModule::OnExtendAssetContextMenu));

	ExtendLevelMenu();

	FGlobalTabmanager::Get()->
		RegisterNomadTabSpawner(
			AssetAuditTabName,
			FOnSpawnTab::CreateRaw(this, &FAssetAuditEditorModule::SpawnAssetAuditTab))
		.SetDisplayName(LOCTEXT("KAssetAuditTitle", "KAsset Audit"))
		.SetTooltipText(LOCTEXT("KAssetAuditTooltip", "Open Asset Audit window"))
		.SetGroup(WorkspaceMenu::GetMenuStructure().GetDeveloperToolsAuditCategory())
		.SetIcon(FSlateIcon("AssetAuditStyle", "AuditEditor.IconAudit"));

	FGlobalTabmanager::Get()->RegisterDefaultTabWindowSize(AssetAuditTabName, FVector2D(1080, 600));

	FCoreDelegates::OnPostEngineInit.AddLambda([this]() { RegisterSettings(); });

	auto& UMGModule = FModuleManager::LoadModuleChecked<IUMGEditorModule>("UMGEditor");
	auto Designer = UMGModule.GetDesignerExtensibilityManager();
	Designer->AddDesignerExtensionFactory(MakeShared<FAuditUserWidgetExtensionFactory>());

	auto& SequencerModule = FModuleManager::LoadModuleChecked<ISequencerModule>("Sequencer");
	AuditTrackHandle = SequencerModule.RegisterOutlinerIndicator(FOnCreateOutlinerIndicator::CreateStatic([]
	{
		return TSharedRef<UE::Sequencer::IOutlinerIndicatorBuilder>(
			MakeShared<FAuditTrackOutlinerIndicator>());
	}));
}

void FAssetAuditEditorModule::ShutdownModule()
{
	UnregisterSettings();

	FEditorDelegates::OnEditorInitialized.Remove(LevelMenuHandle);

	auto& SequencerModule = FModuleManager::LoadModuleChecked<ISequencerModule>("Sequencer");
	SequencerModule.UnregisterOutlinerIndicator(AuditTrackHandle);
}

TSharedRef<FExtender> FAssetAuditEditorModule::OnExtendFolderContextMenu(const TArray<FString>& SelectedPaths)
{
	TSharedRef<FExtender> Extender(new FExtender());
	Extender->AddMenuExtension(
		"PathContextBulkOperations",
		EExtensionHook::After,
		nullptr,
		FMenuExtensionDelegate::CreateStatic(&FAssetAuditEditorModule::CreateCustomMenuEntry, SelectedPaths)
	);

	return Extender;
}

void FAssetAuditEditorModule::CreateCustomMenuEntry(FMenuBuilder& MenuBuilder, TArray<FString> SelectedPaths)
{
	MenuBuilder.AddMenuEntry(
		FText::FromString("KAudit Assets"),
		FText::FromString("Audit Assets"),
		FSlateIcon("AssetAuditStyle", "AuditEditor.IconAudit"),
		FUIAction(FExecuteAction::CreateLambda([SelectedPaths]()
		{
			FAuditManager::Audit(SelectedPaths);
		})));
}

TSharedRef<FExtender> FAssetAuditEditorModule::OnExtendAssetContextMenu(const TArray<FAssetData>& SelectedAssets)
{
	TSharedRef<FExtender> Extender(new FExtender());

	Extender->AddMenuExtension(
		"AssetContextReferences",
		EExtensionHook::After,
		nullptr,
		FMenuExtensionDelegate::CreateStatic(&FAssetAuditEditorModule::CreateCustomMenuEntry, SelectedAssets));

	return Extender;
}

void FAssetAuditEditorModule::CreateCustomMenuEntry(FMenuBuilder& MenuBuilder, TArray<FAssetData> SelectedAssets)
{
	MenuBuilder.AddMenuEntry(
		FText::FromString("KAudit Asset"),
		FText::FromString("Audit asset"),
		FSlateIcon("AssetAuditStyle", "AuditEditor.IconAudit"),
		FUIAction(FExecuteAction::CreateLambda([SelectedAssets]()
		{
			FAuditManager::Audit(SelectedAssets);
		})));
}

void FAssetAuditEditorModule::ExtendLevelMenu()
{
	const TSharedPtr<FExtender> Extender = MakeShareable(new FExtender);
	Extender->AddMenuExtension(
		FName(TEXT("Instrumentation")),
		EExtensionHook::After,
		MakeShareable(new FUICommandList),
		FNewMenuDelegate::CreateLambda([](FMenuBuilder& MenuBuilder)
		{
			MenuBuilder.AddSubMenu(
				FText::FromString("KAudit"), FText::FromString(""),
				FNewMenuDelegate::CreateLambda([](FMenuBuilder& SubMenuBuilder)
				{
					SubMenuBuilder.AddMenuEntry(
						FText::FromString("Open Settings"),
						FText::FromString(""),
						FSlateIcon(),
						FUIAction(FExecuteAction::CreateLambda([]()
						{
							ShowEditorSettings();
						})));

					SubMenuBuilder.AddMenuEntry(
						FText::FromString("Open Preferences"),
						FText::FromString(""),
						FSlateIcon(),
						FUIAction(FExecuteAction::CreateLambda([]()
						{
							ShowEditorPreferences();
						})));
				}),
				false,
				FSlateIcon("AssetAuditStyle", "AuditEditor.IconAudit"));
		}));
	auto& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	LevelEditorModule.GetMenuExtensibilityManager()->AddExtender(Extender);
}

TSharedRef<SDockTab> FAssetAuditEditorModule::SpawnAssetAuditTab(const FSpawnTabArgs& Args)
{
	check(UAssetManager::IsInitialized());

	TSharedRef<SDockTab> DockTab = SAssignNew(AssetAuditTab, SDockTab).TabRole(NomadTab)
		[
			SAssignNew(AssetAuditView, SAssetBrowserView)
		];

	DockTab->SetOnTabClosed(SDockTab::FOnTabClosedCallback::CreateLambda([this](TSharedRef<SDockTab>)
	{
	}));

	return DockTab;
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FAssetAuditEditorModule, AssetAuditEditor)
