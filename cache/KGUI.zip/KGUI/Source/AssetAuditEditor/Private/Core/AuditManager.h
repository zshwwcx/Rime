#pragma once

#include "CoreMinimal.h"
#include "Widget/AuditUserWidget.h"

class ASSETAUDITEDITOR_API FAuditManager
{
public:
	FAuditManager();
	~FAuditManager();

	static FAuditManager* GetInstance();

	TSharedPtr<FAuditUserWidget> UserWidget;

	static void Audit(TArray<FString> Paths);
	static void Audit(TArray<FAssetData> Assets);
	static void Export();
private:
	static FAuditManager* Instance;
};
