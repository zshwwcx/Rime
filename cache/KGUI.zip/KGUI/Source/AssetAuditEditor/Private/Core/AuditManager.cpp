#include "AuditManager.h"
#include "Widget/AuditUserWidget.h"

FAuditManager* FAuditManager::Instance = nullptr;

FAuditManager* FAuditManager::GetInstance()
{
	if (!Instance)
	{
		Instance = new FAuditManager();
	}

	return Instance;
}

FAuditManager::FAuditManager()
{
	UserWidget = MakeShareable(new FAuditUserWidget());
}

FAuditManager::~FAuditManager()
{
	UserWidget.Reset();
}

void FAuditManager::Audit(TArray<FString> Paths)
{
	GetInstance()->UserWidget->Audit(Paths);
}

void FAuditManager::Audit(TArray<FAssetData> Assets)
{
	GetInstance()->UserWidget->Audit(Assets);
}

void FAuditManager::Export()
{
	GetInstance()->UserWidget->Export();
}
