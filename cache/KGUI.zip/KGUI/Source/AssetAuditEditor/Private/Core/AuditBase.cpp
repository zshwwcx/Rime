#include "AuditBase.h"

FAuditBase::FAuditBase()
{
}

FAuditBase::~FAuditBase()
{
}

void FAuditBase::Audit(TArray<FAssetData>& Datas)
{
}

void FAuditBase::Audit(TArray<FString>& Paths)
{
}

void FAuditBase::Export()
{
}
