#pragma once

#include "CoreMinimal.h"

class ASSETAUDITEDITOR_API FAuditBase
{
public:
	FAuditBase();
	virtual ~FAuditBase();
	virtual void Audit(TArray<FAssetData>& Datas);
	virtual void Audit(TArray<FString>& Paths);
	virtual void Export();
};
