#pragma once

#include "CoreMinimal.h"
#include "WidgetBlueprint.h"
#include "Core/AuditBase.h"
#include "Util/AssetAuditEditorSetting.h"

class ASSETAUDITEDITOR_API FAuditUserWidget : public FAuditBase
{
public:
	FAuditUserWidget();
	virtual ~FAuditUserWidget() override;

	TArray<FUserWidgetState> States;

	static TSet<TSharedPtr<FUserWidgetState>> StateCache;

	virtual void Audit(TArray<FAssetData>& Datas) override;
	virtual void Audit(TArray<FString>& Paths) override;
	virtual void Export() override;

	static void AuditBP(UWidgetBlueprint* WB, FUserWidgetState* State);

	static void GetWidgetBlueprintsFromFolder(const FString& FolderPath, TArray<FAssetData>& OutAssetData);
};
