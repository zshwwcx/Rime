#include "AuditUserWidget.h"
#include "AssetAuditEditor.h"
#include "MovieScene.h"
#include "WidgetBlueprint.h"
#include "Animation/WidgetAnimation.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Blueprint/WidgetTree.h"
#include "Tracks/MovieScenePropertyTrack.h"
#include "Util/AssetAuditEditorSetting.h"

TSet<TSharedPtr<FUserWidgetState>> FAuditUserWidget::StateCache;

FAuditUserWidget::FAuditUserWidget()
{
}

FAuditUserWidget::~FAuditUserWidget()
{
}

static TSet<FString> TempWidgetClassChains;

static UWidgetBlueprint* GetWidgetBP(const UWidget* Widget)
{
	if (auto Cls = Widget->GetClass())
	{
		if (auto BPCls = Cast<UBlueprintGeneratedClass>(Cls))
		{
			if (auto SubBP = UBlueprint::GetBlueprintFromClass(BPCls))
			{
				if (auto SubWB = Cast<UWidgetBlueprint>(SubBP))
				{
					return SubWB;
				}
			}
		}
	}

	return nullptr;
}

static FString FormatClassChain(const UVisual* Widget)
{
	FString CC;

	auto Cls = Widget->GetClass();

	for (int i = 0; i < MaxWidgetChainLoop; ++i)
	{
		if (!Cls || Cls == UVisual::StaticClass())
		{
			break;
		}

		if (!Cls->ClassGeneratedBy)
		{
			CC.Append(Cls->GetName() + ";");
		}

		Cls = Cls->GetSuperClass();
	}

	return CC;
}

void FAuditUserWidget::AuditBP(UWidgetBlueprint* WB, FUserWidgetState* State)
{
	auto S = UAssetAuditEditorSetting::GetInstance();
	auto Tree = WB->WidgetTree;

	TMap<FName, UVisual*> Widgets;
	TMap<FName, FName> SlotWidgets;
	Tree->ForEachWidget([S, &Widgets, &SlotWidgets, State](UWidget* Widget)
	{
		Widgets.Add(Widget->GetFName(), Widget);
		//UE_LOG(LogTemp, Log, TEXT("Widget Name: %s"), *Widget->GetName());
		if (Widget->Slot)
		{
			auto SlotName = Widget->Slot.GetFName();
			Widgets.Add(SlotName, Widget->Slot);
			SlotWidgets.Add(SlotName, Widget->GetFName());
		}

		if (auto SubWB = GetWidgetBP(Widget))
		{
			AuditBP(SubWB, State);
			return;
		}

		State->Widget += 1;

		auto WClsName = Widget->GetClass()->GetFName();

		if (auto WC = S->WidgetConfigs.Find(WClsName))
		{
			if (WC->WidgetCost != EAuditCostType::X0)
			{
				auto Cost = StaticCast<int32>(WC->WidgetCost);
				if (auto Sum = State->WidgetCosts.Find(WClsName))
				{
					State->WidgetCosts[WClsName] = *Sum + Cost;
				}
				else
				{
					State->WidgetCosts.Add(WClsName, Cost);
				}
			}
		}
	});

	for (auto& Anim : WB->Animations)
	{
		int32 AnimationCost = 0;

		bool bBind = Anim->GetDisplayLabel() == State->TargetAnimation;

		TMap<FGuid, FName> GuidToName;
		for (auto& AB : Anim->GetBindings())
		{
			if (!AB.SlotWidgetName.IsNone())
			{
				GuidToName.Add(AB.AnimationGuid, AB.SlotWidgetName);
			}
			else if (!AB.WidgetName.IsNone())
			{
				GuidToName.Add(AB.AnimationGuid, AB.WidgetName);
			}
		}

		for (auto& SB : Anim->GetMovieScene()->GetBindings())
		{
			//UE_LOG(LogTemp, Log, TEXT("SB %s %s"), *SB.GetName(), *SB.GetObjectGuid().ToString());
			auto OGuid = SB.GetObjectGuid();
			auto WName = GuidToName.Find(OGuid);
			if (!WName)
			{
				UE_LOG(LogTemp, Warning, TEXT("Can not find Guid: %s %s"), *OGuid.ToString(), *SB.GetName());
				continue;
			}

			auto WPtr = Widgets.Find(*WName);
			if (!WPtr)
			{
				UE_LOG(LogTemp, Warning, TEXT("Can not find Widget: %s %s"), *SB.GetName(), *WName->ToString());
				continue;
			}

			auto W = *WPtr;

			FAuditAnimationBind Bind;

			for (auto ST : SB.GetTracks())
			{
				int32 ICost = 0;
				FName PPath;

				if (auto PT = Cast<UMovieScenePropertyTrack>(ST))
				{
					//UE_LOG(LogTemp, Log, TEXT("B %s"), *PT->GetPropertyPath().ToString());
					PPath = PT->GetPropertyPath();
					auto Inv = S->GetWidgetPropertyInv(W, PPath);
					if (!Inv)
					{
						TempWidgetClassChains.Add(FormatClassChain(W) + ": " + PPath.ToString());
						continue;
					}

					auto IC = S->InvalidateConfigs.Find(*Inv);
					if (!IC)
					{
						UE_LOG(LogTemp, Warning, TEXT("Can not find Invalid: %d"), *Inv);
						continue;
					}

					ICost = StaticCast<int32>(IC->Cost);
				}
				else
				{
					ICost = 1;
					PPath = ST->GetFName();
				}

				if (bBind)
				{
					if (ICost > Bind.MaxCost)
					{
						Bind.MaxCost = ICost;
					}

					Bind.TotalCost += ICost;
					Bind.PropertyCosts.FindOrAdd(PPath, ICost);
				}

				//UE_LOG(LogTemp, Log, TEXT("Bind %s %s %d"), *OGuid.ToString(), *PPath.ToString(), ICost);
				AnimationCost += ICost;
			}

			if (bBind)
			{
				State->Binds.Add(OGuid, Bind);
			}
		}

		if (bBind)
		{
			TMap<FName, FGuid> WidgetGuid;
			TMap<FGuid, FName> GuidToSlot;
			for (auto& AB : Anim->GetBindings())
			{
				//UE_LOG(LogTemp, Log, TEXT("AB %s %s"), *AB.WidgetName.ToString(), *AB.SlotWidgetName.ToString());
				if (!AB.SlotWidgetName.IsNone())
				{
					GuidToSlot.Add(AB.AnimationGuid, AB.SlotWidgetName);
				}
				else if (!AB.WidgetName.IsNone())
				{
					WidgetGuid.Add(AB.WidgetName, AB.AnimationGuid);
				}
			}

			for (auto& [Key, Value] : GuidToSlot)
			{
				if (auto WidgetName = SlotWidgets.Find(Value))
				{
					if (auto WGuid = WidgetGuid.Find(*WidgetName))
					{
						auto SlotBind = State->Binds.Find(Key);
						if (!SlotBind) continue;
						auto WidgetBind = State->Binds.Find(*WGuid);
						if (!WidgetBind) continue;

						WidgetBind->TotalCost += SlotBind->TotalCost;
					}
				}
			}

			State->AnimationCurrent = AnimationCost;
		}

		State->Animation += AnimationCost;
		if (AnimationCost > State->AnimationMax)
		{
			State->AnimationMax = AnimationCost;
		}
	}
}

void FAuditUserWidget::Audit(TArray<FString>& Paths)
{
	TArray<FAssetData> Datas;
	for (auto Path : Paths)
	{
		GetWidgetBlueprintsFromFolder(Path, Datas);
	}

	Audit(Datas);
}

void FAuditUserWidget::Audit(TArray<FAssetData>& Datas)
{
	TempWidgetClassChains.Reset();
	if (!States.IsEmpty())
	{
		States.Empty();
	}
	auto S = UAssetAuditEditorSetting::GetInstance();
	for (auto& Data : Datas)
	{
		UWidgetBlueprint* WB = Cast<UWidgetBlueprint>(Data.GetAsset());
		if (!WB) continue;

		FUserWidgetState State;
		State.ObjectPath = Data.GetSoftObjectPath();
		State.Config = S->GetUserWidgetConfigByPackage(Data.PackageName);

		AuditBP(WB, &State);
		State.Calculate();

		States.Add(State);
		//UE_LOG(LogTemp, Log, TEXT("%s %s Cost Sum: %d"), *State.Config->Key.ToString(), *Data.PackageName.ToString(), State.Total);

		for (auto CC : TempWidgetClassChains)
		{
			UE_LOG(LogTemp, Log, TEXT("Unset Widget Config: %s"), *CC);
		}
	}

	States.Sort([](const FUserWidgetState& A, const FUserWidgetState& B)
	{
		return A.CostRatio > B.CostRatio;
	});

	FGlobalTabmanager::Get()->TryInvokeTab(FAssetAuditEditorModule::AssetAuditTabName);
}

void FAuditUserWidget::GetWidgetBlueprintsFromFolder(const FString& FolderPath, TArray<FAssetData>& OutAssetData)
{
	auto& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	auto& AssetRegistry = AssetRegistryModule.Get();

	TArray<FString> PathsToScan;
	PathsToScan.Add(FolderPath);
	AssetRegistry.ScanPathsSynchronous(PathsToScan);

	FARFilter Filter;
	Filter.ClassPaths.Add(UWidgetBlueprint::StaticClass()->GetClassPathName());
	Filter.PackagePaths.Add(*FolderPath);
	Filter.bRecursivePaths = true;

	AssetRegistry.GetAssets(Filter, OutAssetData);
}

void FAuditUserWidget::Export()
{
	TArray<FString> Lines;
	auto Header = FString::Format(
		TEXT("{0},{1},{2},{3},{4},{5}"),
		{
			FUserWidgetState::FilePathName.ToString(),
			FUserWidgetState::WidgetKeyName.ToString(),
			FUserWidgetState::CostRatioName.ToString(),
			FUserWidgetState::WidgetCostName.ToString(),
			FUserWidgetState::AnimationTotalName.ToString(),
			FUserWidgetState::AnimationMaxName.ToString()
		});

	TArray<FName> WidgetNames;
	for (auto& [Key, Value] : UAssetAuditEditorSetting::GetInstance()->WidgetConfigs)
	{
		if (Value.WidgetCost == EAuditCostType::X0)
		{
			continue;
		}

		WidgetNames.Add(Key);
		auto KeyStr = Key.ToString();
		Header += FString::Printf(TEXT(",%s"), *KeyStr);
	}

	Lines.Add(Header);

	auto SNum = States.Num();
	for (int i = 0; i < SNum; ++i)
	{
		auto S = &States[i];
		auto L = FString::Format(
			TEXT("{0},{1},{2},{3},{4},{5}"),
			{
				S->ObjectPath.GetLongPackageName(),
				S->Config->Key.ToString(),
				S->GetCostDisplay(FUserWidgetState::CostRatioName),
				S->GetCostDisplay(FUserWidgetState::WidgetCostName),
				S->GetCostDisplay(FUserWidgetState::AnimationTotalName),
				S->GetCostDisplay(FUserWidgetState::AnimationMaxName)
			});

		for (auto WN : WidgetNames)
		{
			L += FString::Printf(TEXT(",%s"), *S->GetCostDisplay(WN));
		}

		Lines.Add(L);
	}

	auto Path = FPaths::Combine(FPaths::ProjectSavedDir(), "Audit/UserWidget.csv");
	FFileHelper::SaveStringArrayToFile(Lines, *Path);
}
