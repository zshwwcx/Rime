#pragma once

#include "IContentBrowserSingleton.h"
#include "Util/AssetAuditEditorSetting.h"
#include "Widgets/SCompoundWidget.h"

class SAssetBrowserView : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SAssetBrowserView)
		{
		}

	SLATE_END_ARGS()

void Construct(const FArguments& InArgs);

protected:
	static const FString SettingsIniSection;
	
	FSyncToAssetsDelegate SyncToAssetsDelegate;
	FGetCurrentSelectionDelegate GetCurrentSelectionDelegate;
	FSetARFilterDelegate SetFilterDelegate;

	TSet<FName> AssetRegistryTagsToIgnore;
	TSharedPtr<FUICommandList> Commands;

	FAssetPickerConfig Config;
	
	TArray<FAssetData> AssetDatas;
	TMap<FName, FUserWidgetState> WidgetStateMap;

	void InitAssets();
	void InitPickerConfig();

	static void OnRequestOpenAsset(const FAssetData& AssetData);
	TSharedPtr<SWidget> OnGetAssetContextMenu(const TArray<FAssetData>& SelectedAssets) const;

	void FindInContentBrowser() const;
	bool IsAnythingSelected() const;

	bool CanShowColumnForAssetTag(FName AssetType, FName TagName) const;
	bool HandleFilterAsset(const FAssetData& InAssetData) const;

	void AddValueColumn(FName Column, FText Name, FText Tip);
	int32 GetAssetColumnIntValue(const FAssetData& AssetData, FName ColumnName);
	FString GetStringValueForValueColumn(FAssetData& AssetData, FName ColumnName);
	FText GetDisplayTextForValueColumn(FAssetData& AssetData, FName ColumnName);

	FString GetAssetColumnStringValue(FAssetData& AssetData, FName ColumnName);
	FString GetStringValueForStateColumn(FAssetData& AssetData, FName ColumnName);
	FText GetDisplayTextForStateColumn(FAssetData& AssetData, FName ColumnName);
};
