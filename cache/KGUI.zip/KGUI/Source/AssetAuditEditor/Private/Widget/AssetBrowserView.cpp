#include "AssetBrowserView.h"
#include "AssetManagerEditorModule.h"
#include "ContentBrowserDataSource.h"
#include "ContentBrowserModule.h"
#include "Core/AuditManager.h"
#include "Engine/AssetManager.h"
#include "Toolkits/GlobalEditorCommonCommands.h"

#define LOCTEXT_NAMESPACE "KAssetBrowserView"

const FString SAssetBrowserView::SettingsIniSection = TEXT("AssetBrowserView");

void SAssetBrowserView::Construct(const FArguments& InArgs)
{
	check(UAssetManager::IsInitialized());

	InitAssets();
	InitPickerConfig();

	AssetRegistryTagsToIgnore.Add(FPrimaryAssetId::PrimaryAssetTypeTag);
	AssetRegistryTagsToIgnore.Add(FPrimaryAssetId::PrimaryAssetNameTag);
	AssetRegistryTagsToIgnore.Add(FBlueprintTags::ParentClassPath);
	AssetRegistryTagsToIgnore.Add(FBlueprintTags::BlueprintType);
	AssetRegistryTagsToIgnore.Add(FBlueprintTags::NumReplicatedProperties);
	AssetRegistryTagsToIgnore.Add(FBlueprintTags::NativeParentClassPath);
	AssetRegistryTagsToIgnore.Add(FBlueprintTags::IsDataOnly);
	AssetRegistryTagsToIgnore.Add(FBlueprintTags::NumNativeComponents);
	AssetRegistryTagsToIgnore.Add(FBlueprintTags::NumBlueprintComponents);
	AssetRegistryTagsToIgnore.Add(TEXT("PropertyBindings"));
	AssetRegistryTagsToIgnore.Add(TEXT("TickFrequency"));
	AssetRegistryTagsToIgnore.Add(TEXT("TickPrediction"));
	AssetRegistryTagsToIgnore.Add(TEXT("TickPredictionReason"));

	Commands = MakeShareable(new FUICommandList());
	Commands->MapAction(
		FGlobalEditorCommonCommands::Get().FindInContentBrowser,
		FUIAction(FExecuteAction::CreateSP(this, &SAssetBrowserView::FindInContentBrowser),
		          FCanExecuteAction::CreateSP(this, &SAssetBrowserView::IsAnythingSelected)));

	auto& ContentBrowserModule = FModuleManager::Get().LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));

	this->ChildSlot
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBorder)
			.Padding(FMargin(3))
			.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Fill)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.AutoWidth()
					[
						SNew(SButton)
						.HAlign(HAlign_Center)
						.VAlign(VAlign_Center)
						.Text(LOCTEXT("ExportCSV", "Export CSV"))
						.OnClicked_Lambda([]()
						{
							FAuditManager::Export();
							return FReply::Handled();
						})
					]
				]
			]
		]
		+ SVerticalBox::Slot()
		.FillHeight(1.f)
		[
			SNew(SBorder)
			.Padding(FMargin(3))
			.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
			[
				ContentBrowserModule.Get().CreateAssetPicker(Config)
			]
		]
	];
}

void SAssetBrowserView::InitPickerConfig()
{
	Config.SaveSettingsName = SettingsIniSection;
	Config.InitialAssetViewType = EAssetViewType::Column;
	Config.bAddFilterUI = true;
	Config.bShowPathInColumnView = true;
	Config.bSortByPathInColumnView = true;
	Config.bCanShowClasses = false;
	Config.bFocusSearchBoxWhenOpened = false;

	Config.HiddenColumnNames.Add(TEXT("Class"));
	Config.HiddenColumnNames.Add(TEXT("Path"));
	Config.HiddenColumnNames.Add(ContentBrowserItemAttributes::ItemDiskSize.ToString());
	Config.HiddenColumnNames.Add(IAssetManagerEditorModule::ManagedDiskSizeName.ToString());
	Config.HiddenColumnNames.Add(IAssetManagerEditorModule::TotalUsageName.ToString());

	Config.SyncToAssetsDelegates.Add(&SyncToAssetsDelegate);
	Config.GetCurrentSelectionDelegates.Add(&GetCurrentSelectionDelegate);
	Config.SetFilterDelegates.Add(&SetFilterDelegate);

	Config.OnAssetDoubleClicked = FOnAssetDoubleClicked::CreateStatic(&SAssetBrowserView::OnRequestOpenAsset);
	Config.OnGetAssetContextMenu = FOnGetAssetContextMenu::CreateSP(this, &SAssetBrowserView::OnGetAssetContextMenu);
	Config.OnAssetTagWantsToBeDisplayed = FOnShouldDisplayAssetTag::CreateSP(
		this, &SAssetBrowserView::CanShowColumnForAssetTag);
	Config.OnShouldFilterAsset = FOnShouldFilterAsset::CreateSP(this, &SAssetBrowserView::HandleFilterAsset);

	Config.CustomColumns.Emplace(
		FUserWidgetState::WidgetKeyName, FText::FromString("Key"), FText(),
		UObject::FAssetRegistryTag::TT_Alphabetical,
		FOnGetCustomAssetColumnData::CreateSP(this, &SAssetBrowserView::GetStringValueForStateColumn),
		FOnGetCustomAssetColumnDisplayText::CreateSP(this, &SAssetBrowserView::GetDisplayTextForStateColumn));

	AddValueColumn(FUserWidgetState::CostRatioName, FText::FromString("Ratio"), FText());
	AddValueColumn(FUserWidgetState::WidgetCostName, FText::FromString("Widget"), FText());
	AddValueColumn(FUserWidgetState::AnimationTotalName, FText::FromString("Animation Total"), FText());
	AddValueColumn(FUserWidgetState::AnimationMaxName, FText::FromString("Animation Max"), FText());

	auto S = UAssetAuditEditorSetting::GetInstance();
	for (auto KV : S->WidgetConfigs)
	{
		if (KV.Value.WidgetCost == EAuditCostType::X0)
		{
			continue;
		}

		auto KeyStr = KV.Key.ToString();
		AddValueColumn(KV.Key, FText::FromString(KeyStr), LOCTEXT("", ""));
	}
}

void SAssetBrowserView::AddValueColumn(FName Column, FText Name, FText Tip)
{
	Config.CustomColumns.Emplace(
		Column, Name, Tip, UObject::FAssetRegistryTag::TT_Numerical,
		FOnGetCustomAssetColumnData::CreateSP(this, &SAssetBrowserView::GetStringValueForValueColumn),
		FOnGetCustomAssetColumnDisplayText::CreateSP(this, &SAssetBrowserView::GetDisplayTextForValueColumn));
}

void SAssetBrowserView::InitAssets()
{
	auto& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	auto& AssetRegistry = AssetRegistryModule.Get();

	auto Auit = FAuditManager::GetInstance();
	if (auto& States = Auit->UserWidget->States; !States.IsEmpty())
	{
		for (auto S : States)
		{
			auto Data = AssetRegistry.GetAssetByObjectPath(S.ObjectPath);
			AssetDatas.Add(Data);
			WidgetStateMap.Add(Data.PackageName, S);
		}
	}
}

void SAssetBrowserView::OnRequestOpenAsset(const FAssetData& AssetData)
{
	if (!AssetData.IsValid())
	{
		return;
	}

	GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(AssetData.GetSoftObjectPath());
}

TSharedPtr<SWidget> SAssetBrowserView::OnGetAssetContextMenu(const TArray<FAssetData>& SelectedAssets) const
{
	FMenuBuilder MenuBuilder(true, Commands);

	MenuBuilder.BeginSection(TEXT("Asset"), NSLOCTEXT("ReferenceViewerSchema", "AssetSectionLabel", "Asset"));
	{
		MenuBuilder.AddMenuEntry(FGlobalEditorCommonCommands::Get().FindInContentBrowser);
	}
	MenuBuilder.EndSection();

	return MenuBuilder.MakeWidget();
}

void SAssetBrowserView::FindInContentBrowser() const
{
	TArray<FAssetData> CurrentSelection = GetCurrentSelectionDelegate.Execute();
	if (CurrentSelection.Num() > 0)
	{
		FContentBrowserModule& ContentBrowserModule =
			FModuleManager::Get().LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
		ContentBrowserModule.Get().SyncBrowserToAssets(CurrentSelection);
	}
}

bool SAssetBrowserView::IsAnythingSelected() const
{
	TArray<FAssetData> CurrentSelection = GetCurrentSelectionDelegate.Execute();
	return CurrentSelection.Num() > 0;
}

bool SAssetBrowserView::CanShowColumnForAssetTag(FName AssetType, FName TagName) const
{
	return !AssetRegistryTagsToIgnore.Contains(TagName);
}

bool SAssetBrowserView::HandleFilterAsset(const FAssetData& InAssetData) const
{
	if (InAssetData.PackagePath == IAssetManagerEditorModule::PrimaryAssetFakeAssetDataPackagePath)
	{
		return false;
	}

	if (WidgetStateMap.Contains(InAssetData.PackageName))
	{
		return false;
	}

	return true;
}

int32 SAssetBrowserView::GetAssetColumnIntValue(const FAssetData& AssetData, const FName ColumnName)
{
	if (auto S = WidgetStateMap.Find(AssetData.PackageName))
	{
		return S->GetCostByName(ColumnName);
	}

	return 0;
}

FString SAssetBrowserView::GetStringValueForValueColumn(FAssetData& AssetData, FName ColumnName)
{
	if (auto V = GetAssetColumnIntValue(AssetData, ColumnName))
	{
		return FString::FromInt(V);
	}

	return FString();
}

FText SAssetBrowserView::GetDisplayTextForValueColumn(FAssetData& AssetData, FName ColumnName)
{
	if (auto S = WidgetStateMap.Find(AssetData.PackageName))
	{
		return FText::FromString(S->GetCostDisplay(ColumnName));
	}

	return FText();
}

FString SAssetBrowserView::GetAssetColumnStringValue(FAssetData& AssetData, FName ColumnName)
{
	if (auto S = WidgetStateMap.Find(AssetData.PackageName))
	{
		if (ColumnName == FUserWidgetState::WidgetKeyName)
		{
			if (S->Config)
			{
				return S->Config->Key.ToString();
			}
		}
	}

	return FString();
}

FString SAssetBrowserView::GetStringValueForStateColumn(FAssetData& AssetData, FName ColumnName)
{
	return GetAssetColumnStringValue(AssetData, ColumnName);
}

FText SAssetBrowserView::GetDisplayTextForStateColumn(FAssetData& AssetData, FName ColumnName)
{
	return FText::FromString(GetAssetColumnStringValue(AssetData, ColumnName));
}

#undef LOCTEXT_NAMESPACE
