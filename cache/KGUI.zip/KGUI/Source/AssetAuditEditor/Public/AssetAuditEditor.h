﻿#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "Widget/AssetBrowserView.h"

ASSETAUDITEDITOR_API DECLARE_LOG_CATEGORY_EXTERN(LogAssetAuditEditor, Log, All);

class FAssetAuditEditorModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	static TSharedRef<FExtender> OnExtendFolderContextMenu(const TArray<FString>& SelectedPaths);
	static void CreateCustomMenuEntry(FMenuBuilder& MenuBuilder, TArray<FString> SelectedPaths);

	static TSharedRef<FExtender> OnExtendAssetContextMenu(const TArray<FAssetData>& SelectedAssets);
	static void CreateCustomMenuEntry(FMenuBuilder& MenuBuilder, TArray<FAssetData> SelectedAssets);

	static const FName AssetAuditTabName;
	TWeakPtr<SDockTab> AssetAuditTab;
	TWeakPtr<SAssetBrowserView> AssetAuditView;
	TSharedRef<SDockTab> SpawnAssetAuditTab(const FSpawnTabArgs& Args);

	FDelegateHandle LevelMenuHandle;
	static void ExtendLevelMenu();

	static void ShowEditorSettings();
	static void ShowEditorPreferences();

	TSharedPtr<ISlateStyle> Style;
};
