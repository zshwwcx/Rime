// Fill out your copyright notice in the Description page of Project Settings.


#include "C7/AutomationProfile/SKGUIAutomationProfileWidget.h"
#include "SlateOptMacros.h"
#include "Widgets/Layout/SScrollBox.h"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION


void SKGUIAutomationProfileWidget::Construct(const FArguments& InArgs)
{

	// InitColNames();
	//
	// ListView = SNew(SListView<TSharedPtr<FUIAutoItem>>)
	// 	.ListItemsSource(&InArgs._TableItems)
	// 	.OnGenerateRow(this, &SKGUIAutomationProfileWidget::OnGenerateRow)
	// 	.HeaderRow(
	// 		SNew(SHeaderRow)
	// 		);
	//
	// ListView->GetHeaderRow()->ClearColumns();
	//
	// for (auto ColName: ColNames)
	// {
	// 	ListView->GetHeaderRow()->AddColumn(SHeaderRow::Column(FName(ColName)));
	// }
	//
	// UpdateListView();

	Items = InArgs._TableItems;

	ChildSlot
	[
		// Populate the widget
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.Padding(10, 0)
		.AutoHeight()
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SScrollBox)
			.Orientation(EOrientation::Orient_Horizontal)
			+ SScrollBox::Slot()
			[
			SNew(SListView<TSharedPtr<FUIAutoItem>>)
				.ListItemsSource(&Items)
				.OnGenerateRow(this, &SKGUIAutomationProfileWidget::OnGenerateRow)
				.HeaderRow(
				SNew(SHeaderRow)
				+ SHeaderRow::Column("UIName")
				.DefaultLabel(FText::FromString("UIName"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)
				
				+ SHeaderRow::Column("OpenTimeMs")
				.DefaultLabel(FText::FromString("OpenTimeMs"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)

				+ SHeaderRow::Column("LuaMemoryIncreaseOnOpen")
				.DefaultLabel(FText::FromString("LuaMemoryIncreaseOnOpen"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)

				+ SHeaderRow::Column("UObjectNum")
				.DefaultLabel(FText::FromString("UObjectNum"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)

				+ SHeaderRow::Column("AtlasNum")
				.DefaultLabel(FText::FromString("AtlasNum"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)

				+ SHeaderRow::Column("DrawCall")
				.DefaultLabel(FText::FromString("DrawCall"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)

				+ SHeaderRow::Column("OverDraw")
				.DefaultLabel(FText::FromString("OverDraw"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)

				+ SHeaderRow::Column("LuaMemoryInCreaseOnClose")
				.DefaultLabel(FText::FromString("LuaMemoryInCreaseOnClose"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)

				+ SHeaderRow::Column("UObjectsLeak")
				.DefaultLabel(FText::FromString("UObjectsLeak"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)

				+ SHeaderRow::Column("Error")
				.DefaultLabel(FText::FromString("Error"))
				.HAlignHeader(EHorizontalAlignment::HAlign_Left)
				)
			.ExternalScrollbar(
				SNew(SScrollBar)
				.Orientation(Orient_Vertical)
				)
			]
		]
	];
	
	
}

void SKGUIAutomationProfileWidget::InitColNames()
{
	ColNames.Add(TEXT("UIName"));
	ColNames.Add(TEXT("OpenTimeMs"));
	ColNames.Add(TEXT("LuaMemoryIncreaseOnOpen"));
	ColNames.Add(TEXT("UObjectNum"));
	ColNames.Add(TEXT("AtlasNum"));
	ColNames.Add(TEXT("DrawCall"));
	ColNames.Add(TEXT("OverDraw"));
	ColNames.Add(TEXT("LuaMemoryInCreaseOnClose"));
	ColNames.Add(TEXT("UObjectsLeak"));
	ColNames.Add(TEXT("Error"));
}


void SKGUIAutomationProfileWidget::UpdateListView() const
{
	if (ListView.IsValid())
	{
		ListView->RebuildList();
	}
}

TSharedRef<ITableRow> SKGUIAutomationProfileWidget::OnGenerateRow(TSharedPtr<FUIAutoItem> Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	return SNew(STableRow<TSharedRef<FUIAutoItem>>, OwnerTable)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString(Item->UIName))
			]
			.Padding(20.0)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString("[OpenTimeMs]" + Item->OpenTimeMs))
			]
			.Padding(20.0)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString("[LuaMemoryIncrease]" + Item->LuaMemoryIncrease))
			]
			.Padding(20.0)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString("[UObjectNum]" + Item->UObjectNum))
			]
			.Padding(20.0)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString("[AtlasNum]" + Item->AtlasNum))
			]
			.Padding(20.0)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString("[NumBatches]" + Item->NumBatches))
			]
			.Padding(20.0)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString("[AvgOverDraw]" + Item->AvgOverDraw))
			]
			.Padding(20.0)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString("[AvgFPS]" + Item->AvgFPS))
			]
			.Padding(20.0)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString("[UObjectsLeakInfo]" + Item->UObjectsLeakInfo))
			]
			.Padding(20.0)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(STextBlock)
				.Text(FText::FromString("[ErrorInfo]" + Item->ErrorInfo))
			]
		];

	
	// auto layout = SNew(SHorizontalBox);
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->UIName)));
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->OpenTimeMs)));
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->LuaMemoryIncrease)));
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->UObjectNum)));
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->AtlasNum)));
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->NumBatches)));
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->AvgOverDraw)));
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->AvgFPS)));
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->UObjectsLeakInfo)));
	//
	// layout->AddSlot()
	// .AutoWidth()
	// .AttachWidget(SNew(STextBlock).Text(FText::FromString(Item->ErrorInfo)));
	//
	//
	// return SNew(STableRow<TSharedPtr<FUIAutoItem>>, OwnerTable).Padding(2.0f)
	// 	[
	// 		layout.ToSharedRef()
	// 	];
}



END_SLATE_FUNCTION_BUILD_OPTIMIZATION
