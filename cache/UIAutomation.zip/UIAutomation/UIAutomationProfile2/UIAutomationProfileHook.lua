--- Hook逻辑，添加一些runtime不需要，但是ui_perf的时候需要的hook逻辑

UIAutomationProfileHook = DefineClass("UIAutomationProfileHook")
local UIComponent = kg_require("Framework.KGFramework.KGUI.Core.UIComponent").UIComponent
local UKGInvalidationBox = import("KGInvalidationBox")

function UIAutomationProfileHook:HookLogic()
	-- 修改打开UI规则锁，默认全部可以解锁
	Game.OpenPanelCheckSystem.CanOpen = function(self, uid)
		return true
	end

	-- 关掉UIManager对于WorldRendering的控制
	Game.NewUIManager.UpdateWorldRendering = function()
		return
	end
	
	-- 关掉UIManager面板预加载逻辑
	Game.NewUIManager.WarmPanel = function(self, uid) 
		return
	end

	-- Cache下OpenPanel函数
	Game.NewUIManager.CacheOpenPanelFunc = Game.NewUIManager.OpenPanel

	Game.NewUIManager.CacheInvokePanel = Game.NewUIManager.InvokePanel

	Game.GvGSystem.GetSelfCampInfo = function(self) 
		---@type CampBriefInfo
		local campBriefInfo = {
			CampID = 1400030,
			CampIdx = 1,
			CampScore = 0,
			ResNum = 0,
			ResLevel = 0,
			TotalResNum = 0,
			EntityPoses = 0,
		}
		return campBriefInfo
	end

	Game.GvGSystem.GetCampIndex = function(self, camp)
		return 1
	end

	Game.GvGSystem.GetBriefInfo = function(self)
		if self.model.BriefInfo == nil then
			self:EnterGvG_Star()
			self:EnterGvG()
		end
		return self.model.BriefInfo
	end

	Game.BagSystem.GetItemInfoWithGbId = function(self, gbId)
		return {
			bound = false,
			count = 1,
			itemId = 2000040,
			quality = 3,
			index = 1,
			gbId = gbId,
		}
	end
	Game.MountSystem.GetFashionMountRefine = function(self, fashionMountID) 
		return {
			Exp = 0,
			RefinementCountList = nil,
			SchemeList = {
				[1] = {}
			},
			CurrentScheme = 1,
			RichScheme = 1
		}
	end

	Game.MountSystem.GetMountFashionValue = function(self)
		return 0
	end
	
	
	-- 关掉UIManager缓存cache的逻辑
	Game.NewUIManager.processPanelClose = function(self, panel)
		table.removeItem(self._openPanelStack, panel)
		self:processPanelAudio(panel, false)
		local uid = panel.uid
		self:updateUILayoutInfo(uid, false)
		self:processMutualUIClose(uid)
		self._openPanelMap[uid] = nil
		panel:Hide()
		panel:Close()
		panel:SetCloseStatus(false)
		if true then
			panel:Destroy()
		else
			self._uiCachePool:PushPanel(panel)
		end
	end
	
	-- UIComponent ClosePanel同时移除掉对应的UserWidget
	UIComponent.Destroy = function(self, bDontDestroyWidget)
		if self.isDestroyed then
			Log.ErrorFormat("[UIFrame : UIComponent]:Destroy, %s Has Destroy %s", self.__cname, Game.NewUIManager:GetScriptAuth(self.uid))
			return
		end
		if not IsValid_L(self.userWidget) then
			Log.ErrorFormat("[UIFrame : UIComponent]:Destroy 资源已经销毁， Lua组件发生泄露 %s %s", self.__cname, Game.NewUIManager:GetScriptAuth(self.uid))
			return
		end
		if self:IsOpened() then
			self:Close()
		end
		self:OnDestroy()
		self:ClearAllUIEvent()
		for _, comp in ipairs(self._childComponents) do
			comp:Destroy(true)
		end
		if true then
			if _G.InvalidationBox and self:IsPanel() and not Game.NewUIManager:GetUIConfig(self.uid).volatile then
				local parent = self.userWidget:GetParent()
				if parent then
					parent:RemoveFromParent()
				end
			else
				self.widget:RemoveFromParent()
			end
		end
		self:DebugComponentLog("Destroy")
		self:delete()
	end
	
	UIUtil.InvalidatePanel = function(panel)
		local userWidget = panel.userWidget
		local maybeInvalidationRoot = userWidget:GetParent()
		if maybeInvalidationRoot and maybeInvalidationRoot:IsA(UKGInvalidationBox) then
			maybeInvalidationRoot:SetNeedsSlowPath(true)
		end
	end
end 
