---@class UIAutomationProfileFSM
local TimerBase = kg_require("Framework.KGFramework.KGCore.TimerManager.TimerBase").TimerBase

UIAutomationProfileFSM = DefineClass("UIAutomationProfileFSM", TimerBase)
local AutoConst = kg_require("Tools.UIAutomationProfile2.UIAutoConfig.UIAutomationProfileConst").UIAutomationProfileConst
local UIAutoState_OpenPanel = kg_require("Tools.UIAutomationProfile2.UIAutoStates.UIAutoState_OpenPanel").UIAutoState_OpenPanel
local UIAutoState_SlateStats = kg_require("Tools.UIAutomationProfile2.UIAutoStates.UIAutoState_SlateStats").UIAutoState_SlateStats
local UIAutoState_SnapShot = kg_require("Tools.UIAutomationProfile2.UIAutoStates.UIAutoState_SnapShot").UIAutoState_SnapShot
local UIAutoState_OverDraw = kg_require("Tools.UIAutomationProfile2.UIAutoStates.UIAutoState_OverDraw").UIAutoState_OverDraw
local UIAutoState_OverDrawSnapshot = kg_require("Tools.UIAutomationProfile2.UIAutoStates.UIAutoState_OverDrawSnapShot").UIAutoState_OverDrawSnapShot
local UIAutoState_ClosePanel = kg_require("Tools.UIAutomationProfile2.UIAutoStates.UIAutoState_ClosePanel").UIAutoState_ClosePanel

-- 构造函数
function UIAutomationProfileFSM:ctor(parent)
	self.parent = parent
	self.uiConfig = nil
	self.states = {
		[AutoConst.StatesEnum.STATE_OPEN_PANEL] = UIAutoState_OpenPanel.new(self), 
		[AutoConst.StatesEnum.STATE_START_STAT_PROFILE] = UIAutoState_SlateStats.new(self),
		[AutoConst.StatesEnum.STATE_SNAP_SHOT] = UIAutoState_SnapShot.new(self),
		[AutoConst.StatesEnum.STATE_START_OVERDRAW_PROFILE] = UIAutoState_OverDraw.new(self),
		[AutoConst.StatesEnum.STATE_OVERDRAW_SNAP_SHOT] = UIAutoState_OverDrawSnapshot.new(self),
		[AutoConst.StatesEnum.STATE_CLOSE_PANEL] = UIAutoState_ClosePanel.new(self),
	}
	self.curState = nil
	self.curStateID = nil
	self.recordData = {}
	self.tickTimer = self:AddTickTimer(-1, "Tick")
end

function UIAutomationProfileFSM:StartProfileSingleUI(UIConfig, Index)
	Log.DebugFormat("[UIAutomationProfileFSM:StartProfileSingleUI], uid=%s, Index=%d", UIConfig.uid, Index)
	self.uiConfig = UIConfig
	self:InitAllStates()
	self.curState = self.states[AutoConst.StatesEnum.STATE_OPEN_PANEL]
	self.curStateID = 1
	self.recordData = {}
	
	self.curState:OnEnter()
end 

function UIAutomationProfileFSM:InitAllStates()
	for index, state in ipairs(self.states) do
		state:InitState()
	end
end

function UIAutomationProfileFSM:Tick(deltaTime)
	if self.curState then
		self.curState:OnTick(deltaTime * 1000)
		self:TransitState()
	end
end

function UIAutomationProfileFSM:GetNextState()
	if self.curStateID and self.curStateID < #self.states then
		return self.states[self.curStateID + 1] or nil
	end
end

function UIAutomationProfileFSM:TransitState()
	if self.curState and self.curState:CanTransit() then
		self.curState:OnExit()
		self.curState = self:GetNextState()
		self.curStateID = self.curStateID + 1
		Log.Debug("[UIAutomationProfileFSM:TransitState] Start next stage: %d", self.curStateID)
		self.curState:OnEnter()
	end
end 

function UIAutomationProfileFSM:ReportErrorOnStage(stageName, errMsg)
	Log.Debug("[UIAutomationProfileFSM_OnStageError] Profile UI:%s countered error in stage:%s, Error:%s.", self.uiConfig.uid, stageName, errMsg)
	self.curState = nil
	self.parent:ReportErrorOnStage(stageName, errMsg)
end

function UIAutomationProfileFSM:OnFinish()
	Log.DebugFormat("[UIAutomationProfileFSM_OnFinish] Finish UI:%s profile, start next UI profile.", self.uiConfig.uid)
	self.curState = nil
	self.parent:ProfileNextUI()
end
