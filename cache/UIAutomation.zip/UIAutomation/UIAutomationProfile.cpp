// Fill out your copyright notice in the Description page of Project Settings.

#include "UIAutomationProfile.h"

#include "CoreMinimal.h"
#include "FStatsThreadStateOverlay.h"
#include "LuaState.h"
#include "SluaUtil.h"
#include "PaperSprite.h"
#include "CoreMinimal.h"
#include "KGSprite.h"
#include "PaperSpriteAtlas.h"
#include "SceneInterface.h"
#include "AssetRegistry/AssetData.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Blueprint/UserWidget.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Blueprint/WidgetTree.h"
#include "Engine/Engine.h"
#include "HAL/PlatformFileManager.h"
#include "UMG/Components/KGImage.h"
#include "Materials/Material.h"
#include "Misc/FileHelper.h"
#include "UnrealClient.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Engine/GameViewportClient.h"
#include "Materials/MaterialInstance.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Misc/Paths.h"
#if PLATFORM_WINDOWS
#include "DLSSLibrary.h"
#include "StreamlineLibraryDLSSG.h"
#endif

#include "Widgets/SWindow.h"
#include "Framework/Application/SlateApplication.h"



#if PLATFORM_ANDROID
#include "Android/AndroidPlatformMisc.h"
#include "Android/AndroidApplication.h"
#include "Android/AndroidJNI.h"
#include "Android/AndroidJava.h"
#endif

UE_DISABLE_OPTIMIZATION

DEFINE_LOG_CATEGORY(LogUIAutomationProfile);

#if STATS
static struct FSlateStatDumpAverage* SlateStatDumpAverage = nullptr;

struct FSlateStatDumpAverage
{
	FStatsThreadState& Stats;
	int32 NumFrames;
	FRawStatStackNode* Stack;
	FDelegateHandle NewFrameDelegateHandle;
	TArray<FString> SlateStatNameArray;
	TArray<FStatMessage> NonStackStats;
	TMap<FString, TPair<FString, double>> SlateStatValueArray;
	TMap<FString, TPair<FString, double>> TempSlateStatValueArray;

	FSlateStatDumpAverage(const TArray<FString> SlateStatNameArray)
		: Stats(FStatsThreadState::GetLocalState())
		, NumFrames(0)
		, Stack(nullptr)
		, SlateStatNameArray(SlateStatNameArray)
	{
		StatsPrimaryEnableAdd();
		SlateStatValueArray.Empty();
		NewFrameDelegateHandle = Stats.NewFrameDelegate.AddRaw(this, &FSlateStatDumpAverage::NewFrame);
	}

	~FSlateStatDumpAverage()
	{
	}

	void CollectData(TMap<FString, TPair<FString, double>>& OutValue)
	{
		OutValue = SlateStatValueArray;
		delete Stack;
		Stack = nullptr;
		Stats.NewFrameDelegate.Remove(NewFrameDelegateHandle);
		StatsPrimaryEnableSubtract();
		SlateStatDumpAverage = nullptr;
	}

	void NewFrame(int64 TargetFrame)
	{
		FSlateFilter Filter;
		TempSlateStatValueArray.Empty();
		NonStackStats.Empty();
		if (!Stack)
		{
			Stack = new FRawStatStackNode();
			Stats.UncondenseStackStats(TargetFrame, *Stack, nullptr, &NonStackStats);
			DumpStatStackNode(Stack);
			for (auto Stat : NonStackStats)
			{
				for (auto StatName : SlateStatNameArray)
				{
					if (Stat.NameAndInfo.GetRawName().ToString().Contains(StatName))
					{
						ProcessStatValue(Stat);
					}
				}
			}
			SlateStatValueArray = TempSlateStatValueArray;
		}
		else
		{
			FRawStatStackNode FrameStack;
			Stats.UncondenseStackStats(TargetFrame, FrameStack, nullptr, &NonStackStats);
			DumpStatStackNode(&FrameStack);
			for (auto Stat : NonStackStats)
			{
				for (auto StatName : SlateStatNameArray)
				{
					if (Stat.NameAndInfo.GetRawName().ToString().Contains(StatName))
					{
						ProcessStatValue(Stat);
					}
				}
			}
			MergeAdd(SlateStatValueArray, TempSlateStatValueArray);
			//Stack->MergeAdd(FrameStack);
		}
		NumFrames++;
	}

	void DumpStatStackNode(FRawStatStackNode* Root)
	{
		static int64 MinPrint = -1;
		if (Root && Root->Children.Num())
		{
			TArray<FRawStatStackNode*> ChildArray;
			Root->Children.GenerateValueArray(ChildArray);
			ChildArray.Sort( FStatDurationComparer<FRawStatStackNode>() );
			for (int32 Index = 0; Index < ChildArray.Num(); Index++)
			{
				if (ChildArray[Index]->Meta.GetValue_Duration() < MinPrint)
				{
					break;
				}
				for (auto StatName : SlateStatNameArray)
				{
					if (ChildArray[Index]->Meta.NameAndInfo.GetRawName().ToString().Contains(StatName))
					{
						ProcessStatValue(ChildArray[Index]->Meta);
					}
				}
				DumpStatStackNode(ChildArray[Index]);
			}
		}
	}

	void ProcessStatValue(FStatMessage Item)
	{
		const FString ShortName = Item.NameAndInfo.GetShortName().ToString();
		const FString Description = Item.NameAndInfo.GetDescription();
		switch (Item.NameAndInfo.GetField<EStatDataType>())
		{
		case EStatDataType::ST_int64:
			if (Item.NameAndInfo.GetFlag(EStatMetaFlags::IsPackedCCAndDuration))
			{
				float Duration = FPlatformTime::ToMilliseconds(FromPackedCallCountDuration_Duration(Item.GetValue_int64()));
				if (!TempSlateStatValueArray.Contains(ShortName))
				{
					TempSlateStatValueArray.Add(ShortName, MakeTuple(Description,Duration));
				}
			}
			else if (Item.NameAndInfo.GetFlag(EStatMetaFlags::IsCycle))
			{
				float Duration = FPlatformTime::ToMilliseconds64(Item.GetValue_int64());
				if (!TempSlateStatValueArray.Contains(ShortName))
				{
					TempSlateStatValueArray.Add(ShortName, MakeTuple(Description,Duration));
				}
			}
			else if (Item.NameAndInfo.GetFlag(EStatMetaFlags::IsMemory))
			{
				double Memory = (double)Item.GetValue_int64() / 1024.0 / 1024.0;
				if (!TempSlateStatValueArray.Contains(ShortName))
				{
					TempSlateStatValueArray.Add(ShortName, MakeTuple(Description, Memory));
				}
			}
			else
			{
				if (!TempSlateStatValueArray.Contains(ShortName))
				{
					TempSlateStatValueArray.Add(ShortName, MakeTuple(Description, (double)Item.GetValue_int64()));
				}
			}
			break;
		case EStatDataType::ST_double:
			if (!TempSlateStatValueArray.Contains(ShortName))
			{
				TempSlateStatValueArray.Add(ShortName, MakeTuple(Description, (double)Item.GetValue_int64()));
			}
			break;
		default:
			break;
		}
	}

	static void MergeAdd(TMap<FString, TPair<FString, double>>& OutValue, TMap<FString, TPair<FString, double>> InValue)
	{
		for (auto& Item : InValue)
		{
			if (OutValue.Contains(Item.Key))
			{
				OutValue[Item.Key].Value = (OutValue[Item.Key].Value + Item.Value.Value) / 2;
			}
			else
			{
				OutValue.Add(Item);
			}
		}
	}
};

#endif

void FUIAutomationObjListener::Init()
{
	GUObjectArray.AddUObjectDeleteListener(this);
	GUObjectArray.AddUObjectCreateListener(this);
}

void FUIAutomationObjListener::CleanArrayList()
{
	FScopeLock Lock(&CriticalSection);
	CreatedObjects.Empty();
	DeletedObjects.Empty();
}

void FUIAutomationObjListener::OnUIOpened()
{
	bListening = true;
}

void FUIAutomationObjListener::OnUIClosed()
{
	bListening = false;
}

void FUIAutomationObjListener::NotifyUObjectCreated(const class UObjectBase* Object, int32 Index)
{
	if (!bListening)
	{
		return;
	}
	FUIObjectInfo* ObjectInfo = new FUIObjectInfo();
	ObjectInfo->ClassName = Object->GetClass()->GetName();
	ObjectInfo->ObjectName = Object->GetFName();
	ObjectInfo->ObjectIndex = Index;

	FScopeLock Lock(&CriticalSection);
	CreatedObjects.Add(ObjectInfo);
}

void FUIAutomationObjListener::NotifyUObjectDeleted(const class UObjectBase* Object, int32 Index)
{
	if (!bListening)
	{
		return;
	}
	FUIObjectInfo* ObjectInfo = new FUIObjectInfo();
	ObjectInfo->ClassName = Object->GetClass()->GetName();
	ObjectInfo->ObjectName = Object->GetFName();
	ObjectInfo->ObjectIndex = Index;
	
	FScopeLock Lock(&CriticalSection);
	DeletedObjects.Add(ObjectInfo);
}

void FUIAutomationObjListener::OnUObjectArrayShutdown()
{
	GUObjectArray.RemoveUObjectDeleteListener(this);
	GUObjectArray.RemoveUObjectCreateListener(this);
}

void UUIAutomationProfile::Init(bool bQuitWhenFinish)
{
	SlateStatNameArray.Empty();
	SlateStatNameArray.Add("Total Slate Tick Time");
	SlateStatNameArray.Add("Num Batches");
	SlateStatNameArray.Add("Num Batches (UMG)");
	SlateStatNameArray.Add("Draw Window And Children Time");
	SlateStatNameArray.Add("Tick Widgets");
	SlateStatNameArray.Add("SlatePrepass");
	SlateStatNameArray.Add("Game UI Paint");
	// StatsPrimaryEnableAdd();
	UIProfileDataArray.Empty();

	ObjListener = new FUIAutomationObjListener();
	ObjListener->Init();

	bNeedQuitGame = bQuitWhenFinish;
	
	// 逻辑初始化要放在删缓存文件前面，不然可能会因为ScreenShot文件不存在提前return导致部分初始化逻辑走不到.
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	FString DirectoryPath = GetDefault<UEngine>()->GameScreenshotSaveDirectory.Path;
	if (!PlatformFile.DirectoryExists(*DirectoryPath))
	{
		UE_LOG(LogUIAutomationProfile, Warning, TEXT("Directory does not exist: %s"), *DirectoryPath);
		return;
	}
	TArray<FString> FilesToDelete;
	PlatformFile.FindFilesRecursively(FilesToDelete, *DirectoryPath, TEXT("*"));
	for (const FString& File : FilesToDelete)
	{
		if (!PlatformFile.DeleteFile(*File))
		{
			UE_LOG(LogUIAutomationProfile, Warning, TEXT("Failed to delete file: %s"), *File);
		}
	}
}

void UUIAutomationProfile::StartSingleUIProfile(FString& UIName, float LuaMemory, TArray<FString> UObjectsWhiteList)
{
	UIProfileDataArray.Add(TempUIProfileData);
	TempUIProfileData.Name = FName(UIName);
	TempUIProfileData.Error = "";
	TempUIProfileData.Time = 0;
	TempUIProfileData.LayoutEnum = 0;
	TempUIProfileData.UObjectNum = 0;
	TempUIProfileData.NiagaraWidgetNum = 0;
	TempUIProfileData.NiagaraEmitterNum = 0;
	TempUIProfileData.TotalTrackedMemoryBefore = 0;
	TempUIProfileData.TotalTrackedMemoryOnShow = 0;
	TempUIProfileData.TotalTrackedMemoryOnClose = 0;
	TempUIProfileData.LuaMemoryBefore = 0;
	TempUIProfileData.LuaMemoryOnShow = 0;
	TempUIProfileData.LuaMemoryOnClose = 0;
	TempUIProfileData.DependenceAtlasSet.Empty();
	TempUIProfileData.DependenceTextureSet.Empty();
	TempUIProfileData.SlateStatValueArray.Empty();
	TempUIProfileData.ScreenShotPath = "";
	TempUIProfileData.UObjectsLuaBefore.Empty();
	TempUIProfileData.UObjectsLuaAdd.Empty();

	TempUIProfileData.CreatedObjMap.Empty();
	TempUIProfileData.DeletedObjMap.Empty();
	TempUIProfileData.CreatedObjArrays.Empty();
	TempUIProfileData.DeletedObjArrays.Empty();
	TempUIProfileData.FPSCount = 0;
	TempUIProfileData.AvgFPS = 0.0f;
	TempUIProfileData.UObjectsWhiteList = UObjectsWhiteList;

	// 清理下ObjListener
	ObjListener->CleanArrayList();
	
	StartTime = FPlatformTime::Seconds();

	CurTestUIName = UIName;
#if ENABLE_LOW_LEVEL_MEM_TRACKER
	if (FLowLevelMemTracker::Get().IsEnabled())
	{
		FLowLevelMemTracker::Get().UpdateStatsPerFrame();
		TempUIProfileData.TotalTrackedMemoryBefore = static_cast<float>(FLowLevelMemTracker::Get().GetTotalTrackedMemory(ELLMTracker::Default)) * InvToMb;
		const auto UITextMemory = FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, FName("UI_Text"), ELLMTagSet::None) * InvToMb;
		TempUIProfileData.UIMemoryBefore = static_cast<float>(FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::UI)) * InvToMb - UITextMemory;
		TempUIProfileData.UObjectMemoryBefore = static_cast<float>(FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::UObject)) * InvToMb;
		TempUIProfileData.TextureMemoryBefore = static_cast<float>(FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::Textures)) * InvToMb;
		//FLowLevelMemTracker::Get().DumpToLog();
	}
#endif
	TempUIProfileData.LuaMemoryBefore = LuaMemory * 1024 * InvToMb;
	UE_LOG(LogUIAutomationProfile, Display, TEXT("StartSingleUIProfile"));
	dumpUObjectsLuaBefore();
	
	// GetKGMemoryStatisticsTreeAnalyserBeforeUIOpen();
}

void UUIAutomationProfile::OnSingleUIOpened(UUserWidget* Widget, FString WbpName, float LuaMemory, int OpenTimeMS, int LayoutEnum)
{
	TRACE_BOOKMARK(TEXT("UIOpened: %s"), *TempUIProfileData.Name.ToString());

#if ENABLE_LOW_LEVEL_MEM_TRACKER
	if (FLowLevelMemTracker::Get().IsEnabled())
	{
		FLowLevelMemTracker::Get().UpdateStatsPerFrame();
		TempUIProfileData.TotalTrackedMemoryOnShow = static_cast<float>(FLowLevelMemTracker::Get().GetTotalTrackedMemory(ELLMTracker::Default)) * InvToMb;
		const auto UITextMemory = FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, FName("UI_Text"), ELLMTagSet::None) * InvToMb;
		TempUIProfileData.UIMemoryOnShow = static_cast<float>(FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::UI)) * InvToMb - UITextMemory;
		TempUIProfileData.UObjectMemoryOnShow = static_cast<float>(FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::UObject)) * InvToMb;
		TempUIProfileData.TextureMemoryOnShow = static_cast<float>(FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::Textures)) * InvToMb;
		//FLowLevelMemTracker::Get().DumpToLog();
	}
#endif
	TempUIProfileData.LuaMemoryOnShow = LuaMemory * 1024 * InvToMb;
	TempUIProfileData.Time = OpenTimeMS;
	TempUIProfileData.LayoutEnum = LayoutEnum;
	UE_LOG(LogUIAutomationProfile, Display, TEXT("OnSingleUIOpened Time:%lf"), TempUIProfileData.Time);
	UE_LOG(LogUIAutomationProfile, Display, TEXT("TotalTrackedMemory Before: %lf Now:%lf Increase:%lf"), TempUIProfileData.TotalTrackedMemoryBefore, TempUIProfileData.TotalTrackedMemoryOnShow, TempUIProfileData.TotalTrackedMemoryOnShow - TempUIProfileData.TotalTrackedMemoryBefore);
	UE_LOG(LogUIAutomationProfile, Display, TEXT("LuaMemory Before: %lf Now:%lf Increase:%lf"), TempUIProfileData.LuaMemoryBefore, TempUIProfileData.LuaMemoryOnShow, TempUIProfileData.LuaMemoryOnShow - TempUIProfileData.LuaMemoryBefore);

	if (Widget)
	{
		RecursivelyCheckNiagaraSystemWidget(Widget, TempUIProfileData.NiagaraWidgetNum, TempUIProfileData.NiagaraEmitterNum);
	}
	GetKGMemoryStatisticsTreeAnalyser(WbpName);

	FScopeLock Lock(&(ObjListener->CriticalSection));
	// 新增TMap，规避在迭代器迭代过程中修改容器
	TMap<FString, int32> NewElements;
	
	TempUIProfileData.UObjectNum = ObjListener->CreatedObjects.Num();
	for ( auto ObjInfo : ObjListener->CreatedObjects)
	{
		int32* ValuePtr = TempUIProfileData.CreatedObjMap.Find(ObjInfo->ClassName);
		if (ValuePtr)
		{
			(*ValuePtr)++;
		}
		else
		{
			if (int* NewValuePtr = NewElements.Find(ObjInfo->ClassName))
			{
				(*NewValuePtr)++;
			}
			else
			{
				NewElements.Add(ObjInfo->ClassName, 1);	
			}
		}

		if (ObjInfo->ClassName == "KGSpriteAtlas")
		{
			TempUIProfileData.DependenceAtlasSet.Add(ObjInfo->ObjectName.ToString());
		}
		else if (ObjInfo->ClassName == "Texture2D")
		{
			TempUIProfileData.DependenceTextureSet.Add(ObjInfo->ObjectName.ToString());
		}
	}

	for (const auto& NewPair: NewElements)
	{
		TempUIProfileData.CreatedObjMap.Add(NewPair.Key, NewPair.Value);
	}

	for (const TPair<FString, int32>& Pair: TempUIProfileData.CreatedObjMap)
	{
		TempUIProfileData.CreatedObjArrays.Add(Pair);
	}
	TempUIProfileData.CreatedObjArrays.Sort([](const TPair<FString, int32>& A, const TPair<FString, int32>& B)
	{
		return A.Value > B.Value;
	});
}

void UUIAutomationProfile::OnSingleUIClosed(float LuaMemory)
{
	TRACE_BOOKMARK(TEXT("UIClosed: %s"), *TempUIProfileData.Name.ToString());

#if ENABLE_LOW_LEVEL_MEM_TRACKER
	if (FLowLevelMemTracker::Get().IsEnabled())
	{
		FLowLevelMemTracker::Get().UpdateStatsPerFrame();
		TempUIProfileData.TotalTrackedMemoryOnClose = static_cast<float>(FLowLevelMemTracker::Get().GetTotalTrackedMemory(ELLMTracker::Default)) * InvToMb;
		const auto UITextMemory = FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, FName("UI_Text"), ELLMTagSet::None) * InvToMb;
		TempUIProfileData.UIMemoryOnClose = static_cast<float>(FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::UI)) * InvToMb - UITextMemory;
		TempUIProfileData.UObjectMemoryOnClose = static_cast<float>(FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::UObject)) * InvToMb;
		TempUIProfileData.TextureMemoryOnClose = static_cast<float>(FLowLevelMemTracker::Get().GetTagAmountForTracker(ELLMTracker::Default, ELLMTag::Textures)) * InvToMb;
		//FLowLevelMemTracker::Get().DumpToLog();
	}
#endif
	TempUIProfileData.LuaMemoryOnClose = LuaMemory * 1024 * InvToMb;
	UE_LOG(LogUIAutomationProfile, Display, TEXT("OnSingleUIClosed TotalTrackedMemory Now:%lf Decrease:%lf"), TempUIProfileData.TotalTrackedMemoryOnClose, TempUIProfileData.TotalTrackedMemoryOnShow - TempUIProfileData.TotalTrackedMemoryOnClose);
	for(auto Atlas : TempUIProfileData.DependenceAtlasSet)
	{
		UE_LOG(LogUIAutomationProfile, Display, TEXT("Atlas:%s"), *Atlas);
	}
	for(auto Texture : TempUIProfileData.DependenceTextureSet)
	{
		UE_LOG(LogUIAutomationProfile, Display, TEXT("Texture:%s"), *Texture);
	}
	for (auto [StatName, StatValue] : TempUIProfileData.SlateStatValueArray)
	{
		UE_LOG(LogUIAutomationProfile, Display, TEXT("StatName:%s StatValue:%lf"), *StatValue.Key, StatValue.Value);
	}
	dumpUObjectsLuaAdd();

	FString UObjectAddedStr;
	for (auto UObject : TempUIProfileData.UObjectsLuaAdd)
	{
		UObjectAddedStr += UObject + TEXT(";"); // UObjectsIncreaseRefByLua
	}

	float NumBatches = 0.0f;
	if (auto FindResult = TempUIProfileData.SlateStatValueArray.Find(TEXT("Num Batches")))
	{
		NumBatches = FindResult->Value;
	}

	TSharedPtr<FUIAutoItem> DataItem = MakeShared<FUIAutoItem>(
	TempUIProfileData.Name.ToString(),
	FString::Printf(TEXT("%.2f"), TempUIProfileData.Time),
	FString::Printf(TEXT("%.2f,"), TempUIProfileData.LuaMemoryOnShow - TempUIProfileData.LuaMemoryBefore),
	FString::Printf(TEXT("%d,"), TempUIProfileData.UObjectNum),
	FString::Printf(TEXT("%d,"), TempUIProfileData.DependenceAtlasSet.Num()),
	FString::Printf(TEXT("%f"), NumBatches),
	FString::Printf(TEXT("%f"), TempUIProfileData.SlateOverDrawAvg),
	FString::Printf(TEXT("%.2f"), TempUIProfileData.AvgFPS),
	FString::Printf(TEXT("%s"), *UObjectAddedStr),
	FString::Printf(TEXT("%s"), *TempUIProfileData.Error));
	
	UIAutoListDataArray.Add(DataItem);

	

	// auto DataItem = MakeShared<FUIAutoItem>();
	//
	// DataItem->UIName = TempUIProfileData.Name.ToString();
	// DataItem->OpenTimeMs = FString::Printf(TEXT("%.2f"), TempUIProfileData.Time);
	// DataItem->LuaMemoryIncrease = FString::Printf(TEXT("%f"), TempUIProfileData.LuaMemoryOnShow - TempUIProfileData.LuaMemoryBefore);
	// DataItem->UObjectNum = FString::Printf(TEXT("%d"), TempUIProfileData.UObjectNum);
	// DataItem->AtlasNum = FString::Printf(TEXT("%d"), TempUIProfileData.DependenceAtlasSet.Num());
	// if (TempUIProfileData.SlateStatValueArray.Contains(TEXT("Num Batches")))
	// {
	// 	DataItem->NumBatches = 	FString::Printf(TEXT("%f"), TempUIProfileData.SlateStatValueArray[TEXT("Num Batches")].Value);
	// }
	// else
	// {
	// 	DataItem->NumBatches = TEXT("0");
	// }
	// DataItem->AvgOverDraw = FString::Printf(TEXT("%f"), TempUIProfileData.SlateOverDrawAvg);
	// DataItem->AvgFPS = FString::Printf(TEXT("%f"), TempUIProfileData.AvgFPS);
	// DataItem->UObjectsLeakInfo = UObjectAddedStr;
	// DataItem->ErrorInfo = TempUIProfileData.Error;
}

void UUIAutomationProfile::AddDependenceTextureName(FString TextureName)
{
	TempUIProfileData.DependenceTextureSet.Add(TextureName);
}

void UUIAutomationProfile::UpdateFPS(float DeltaTime)
{
#if PLATFORM_WINDOWS
	if (UDLSSLibrary::IsDLSSEnabled() && UStreamlineLibraryDLSSG::GetDLSSGMode() != EStreamlineDLSSGMode::Off)
	{
		float FrameRateInHertz = 0.0f;
		int32 FramesPresented = 0;
		UStreamlineLibraryDLSSG::GetDLSSGFrameTiming(FrameRateInHertz, FramesPresented);
		TempUIProfileData.AvgFPS = (TempUIProfileData.AvgFPS * TempUIProfileData.FPSCount + FramesPresented) / (TempUIProfileData.FPSCount + 1);
		TempUIProfileData.FPSCount += 1;
	}
	else
	{
		if (!FMath::IsNearlyZero(DeltaTime))
		{
			float CurFPS = 1000 / DeltaTime;
			TempUIProfileData.AvgFPS = (TempUIProfileData.AvgFPS * TempUIProfileData.FPSCount + CurFPS) / (TempUIProfileData.FPSCount + 1);
			TempUIProfileData.FPSCount += 1;
		}	
	}
#else
	if (!FMath::IsNearlyZero(DeltaTime))
	{
		float CurFPS = 1000 / DeltaTime;
		TempUIProfileData.AvgFPS = (TempUIProfileData.AvgFPS * TempUIProfileData.FPSCount + CurFPS) / (TempUIProfileData.FPSCount + 1);
		TempUIProfileData.FPSCount += 1;
	}
#endif
}


void UUIAutomationProfile::StartCollectSlateStatData(int32 Count)
{
#if STATS
	FGameThreadStatsData* StatsViewData = FLatestGameThreadStatsData::Get().Latest;
	if (!StatsViewData)
	{
		return;
	}
	for (int32 Index = 0; Index < StatsViewData->ActiveStatGroups.Num(); Index++)
	{
		const FActiveStatGroupInfo& GroupInfo = StatsViewData->ActiveStatGroups[Index];
		const FString& GroupName = StatsViewData->GroupNames[Index].ToString();
		if (GroupInfo.FlatAggregate.Num() > 0)
		{
			// FProfilingStats::FCategory& Category = InStats.Category(GroupName);
			for (auto& Message : GroupInfo.FlatAggregate)
			{
				FString StatDesc = Message.GetDescription();
				FString StatName = StatDesc.IsEmpty() ? Message.GetShortName().GetPlainNameString() : StatDesc;

				auto DataType = Message.NameAndInfo.GetField<EStatDataType>();
				bool bIsCycle = Message.NameAndInfo.GetFlag(EStatMetaFlags::IsCycle);
				bool bIsDuration = Message.NameAndInfo.GetFlag(EStatMetaFlags::IsPackedCCAndDuration);
				bool bIsMemory = Message.NameAndInfo.GetFlag(EStatMetaFlags::IsMemory);

				switch (DataType)
				{
				case EStatDataType::ST_int64:
					if (bIsDuration || bIsCycle)
					{
						int64 Cycles = Message.GetValue_Duration(EComplexStatField::IncAve);
						float MS = FPlatformTime::ToMilliseconds(Cycles);
						if (!TempUIProfileData.SlateStatValueArray.Contains(StatName))
						{
							TempUIProfileData.SlateStatValueArray.Add(StatName, MakeTuple(StatDesc,MS));
						}
					}
					else if (bIsMemory)
					{
						double Memory = static_cast<double>(Message.GetValue_int64(EComplexStatField::IncAve)) / 1024.0 /1024.0;
						if (!TempUIProfileData.SlateStatValueArray.Contains(StatName))
						{
							TempUIProfileData.SlateStatValueArray.Add(StatName, MakeTuple(StatDesc, Memory));
						}
					}
					else
					{
						if (!TempUIProfileData.SlateStatValueArray.Contains(StatName))
						{
							TempUIProfileData.SlateStatValueArray.Add(StatName, MakeTuple(StatDesc, static_cast<double>(Message.GetValue_int64(EComplexStatField::IncAve))));
						}
					}
					break;
				case EStatDataType::ST_double:
					if (!TempUIProfileData.SlateStatValueArray.Contains(StatName))
					{
						TempUIProfileData.SlateStatValueArray.Add(StatName, MakeTuple(StatDesc, static_cast<double>(Message.GetValue_int64(EComplexStatField::IncAve))));
					}
					break;
				default:
					break;
				}
			}
		}
		if (GroupInfo.CountersAggregate.Num() > 0)
		{
			for (auto& Message : GroupInfo.CountersAggregate)
			{
				FString StatDesc = Message.GetDescription();
				FString StatName = StatDesc.IsEmpty() ? Message.GetShortName().GetPlainNameString() : StatDesc;
				auto DataType = Message.NameAndInfo.GetField<EStatDataType>();

				if (DataType == EStatDataType::ST_int64)
				{
					int64 X = Message.GetValue_int64(EComplexStatField::IncAve);
					if (!TempUIProfileData.SlateStatValueArray.Contains(StatName))
					{
						TempUIProfileData.SlateStatValueArray.Add(StatName, MakeTuple(StatDesc,X));
					}
				}
				else if (DataType == EStatDataType::ST_double)
				{
					double X = Message.GetValue_double(EComplexStatField::IncMax);
					if (!TempUIProfileData.SlateStatValueArray.Contains(StatName))
					{
						TempUIProfileData.SlateStatValueArray.Add(StatName, MakeTuple(StatDesc,X));
					}
				}
			}
		}
	}
#endif
}

#if STATS

void UUIAutomationProfile::DumpStatStackNode(FRawStatStackNode* Root)
{
	static int64 MinPrint = -1;
	if (Root && Root->Children.Num())
	{
		TArray<FRawStatStackNode*> ChildArray;
		Root->Children.GenerateValueArray(ChildArray);
		ChildArray.Sort( FStatDurationComparer<FRawStatStackNode>() );
		for (int32 Index = 0; Index < ChildArray.Num(); Index++)
		{
			if (ChildArray[Index]->Meta.GetValue_Duration() < MinPrint)
			{
				break;
			}
			for (auto StatName : SlateStatNameArray)
			{
				if (ChildArray[Index]->Meta.NameAndInfo.GetRawName().ToString().Contains(StatName))
				{
					ProcessStatValue(ChildArray[Index]->Meta);
				}
			}
			DumpStatStackNode(ChildArray[Index]);
		}
	}
}

void UUIAutomationProfile::ProcessStatValue(FStatMessage Item)
{
	const FString ShortName = Item.NameAndInfo.GetShortName().ToString();
	const FString Description = Item.NameAndInfo.GetDescription();
	switch (Item.NameAndInfo.GetField<EStatDataType>())
	{
	case EStatDataType::ST_int64:
		if (Item.NameAndInfo.GetFlag(EStatMetaFlags::IsPackedCCAndDuration))
		{
			float Duration = FPlatformTime::ToMilliseconds(FromPackedCallCountDuration_Duration(Item.GetValue_int64()));
			if (!TempUIProfileData.SlateStatValueArray.Contains(ShortName))
			{
				TempUIProfileData.SlateStatValueArray.Add(ShortName, MakeTuple(Description,Duration));
			}
		}
		else if (Item.NameAndInfo.GetFlag(EStatMetaFlags::IsCycle))
		{
			float Duration = FPlatformTime::ToMilliseconds64(Item.GetValue_int64());
			if (!TempUIProfileData.SlateStatValueArray.Contains(ShortName))
			{
				TempUIProfileData.SlateStatValueArray.Add(ShortName, MakeTuple(Description,Duration));
			}
		}
		else if (Item.NameAndInfo.GetFlag(EStatMetaFlags::IsMemory))
		{
			double Memory = (double)Item.GetValue_int64() / 1024.0 / 1024.0;
			if (!TempUIProfileData.SlateStatValueArray.Contains(ShortName))
			{
				TempUIProfileData.SlateStatValueArray.Add(ShortName, MakeTuple(Description, Memory));
			}
		}
		else
		{
			if (!TempUIProfileData.SlateStatValueArray.Contains(ShortName))
			{
				TempUIProfileData.SlateStatValueArray.Add(ShortName, MakeTuple(Description, (double)Item.GetValue_int64()));
			}
		}
		break;
	case EStatDataType::ST_double:
		if (!TempUIProfileData.SlateStatValueArray.Contains(ShortName))
		{
			TempUIProfileData.SlateStatValueArray.Add(ShortName, MakeTuple(Description, (double)Item.GetValue_int64()));
		}
		break;
	default:
		break;
	}
}

#endif

void UUIAutomationProfile::TakeSnapShot()
{
	FScreenshotRequest::RequestScreenshot(TempUIProfileData.Name.ToString(), true, false, false);
	TempUIProfileData.ScreenShotPath = FPaths::ConvertRelativePathToFull(FScreenshotRequest::GetFilename());
}

void UUIAutomationProfile::TakeSnapShotOverdraw()
{
	// GEngine->Exec(GetWorld(), TEXT("slate.showOverdraw 1"));
	const auto OverDrawScreenShot = TempUIProfileData.Name.ToString() + "_OverDraw";
	FScreenshotRequest::RequestScreenshot(OverDrawScreenShot, true, false, false);
	TempUIProfileData.OverdrawScreenShotPath = FPaths::ConvertRelativePathToFull(FScreenshotRequest::GetFilename());
}

void UUIAutomationProfile::GetOverDrawData(int32 Count)
{
	TempUIProfileData.SlateOverDrawAvg = (TempUIProfileData.SlateOverDrawAvg * (Count - 1) + GetWorld()->Scene->SlateOverDrawAvg) / Count;
	TempUIProfileData.SlateMaxOverDrawCount = (TempUIProfileData.SlateMaxOverDrawCount * (Count -1) + GetWorld()->Scene->SlateMaxOverDrawCount) / Count;
}

void UUIAutomationProfile::CollapseMaterialForOverDrawCheck(UUserWidget* Widget)
{
	TObjectPtr<UWidgetTree> WBPWidgetTree = Widget->WidgetTree;
	TArray<UWidget*> Widgets;
	if (WBPWidgetTree)
	{
		WBPWidgetTree->GetAllWidgets(Widgets);
		for (int32 Index = 0; Index < Widgets.Num(); ++Index)
		{
			UWidget* CWidget = Widgets[Index];
			if (CWidget == nullptr)
			{
				continue;
			}
			if (UUserWidget* UserWidget = Cast<UUserWidget>(CWidget))
			{
				CollapseMaterialForOverDrawCheck(UserWidget);
			}

			if (UKGImage* Image = Cast<UKGImage>(CWidget))
			{
				if (Image->GetBrush().GetResourceObject() && Image->GetBrush().GetResourceObject()->IsA(UMaterialInterface::StaticClass()))
				{
					Image->SetVisibility(ESlateVisibility::Collapsed);	
				}
			}
		}
	}
	GEngine->Exec(GetWorld(), TEXT("slate.showviewportoverdraw 1"));
}

void UUIAutomationProfile::GetOverDrawDataWithOutMaterial()
{
	TempUIProfileData.SlateOverDrawWithoutMTAvg = GetWorld()->Scene->SlateOverDrawAvg;
	TempUIProfileData.SlateMaxOverDrawWithoutMTCount = GetWorld()->Scene->SlateMaxOverDrawCount;
}

void UUIAutomationProfile::GetKGMemoryStatisticsTreeAnalyserBeforeUIOpen()
{
	auto RootObject = UGameViewportSubsystem::Get(GWorld->GetWorld());
	auto Tree = FKGUMGMemorySnapshot::GenerateMemoryStatisticsTree(RootObject);
	FKGMemoryStatisticsTreeAnalyser Analyser(Tree);
	TempUIProfileData.AnalyserBeforeOpen = Analyser;
}

void UUIAutomationProfile::GetKGMemoryStatisticsTreeAnalyser(FString WbpName)
{
	auto RootObject = FindFirstObject<UObject>(*WbpName);
	auto Tree = FKGUMGMemorySnapshot::GenerateMemoryStatisticsTree(RootObject);
	FKGMemoryStatisticsTreeAnalyser Analyser(Tree);
	TempUIProfileData.Analyser = Analyser;
}

void UUIAutomationProfile::ReportError(FString Error)
{
	Error.ReplaceCharInline(TEXT(','), TEXT(' '));
	TempUIProfileData.Error = TempUIProfileData.Error + "\"" + Error + "\"";
}

void UUIAutomationProfile::ExportCSV()
{
	UIProfileDataArray.Add(TempUIProfileData);
	StatsPrimaryEnableSubtract();
	FString CSVContent;
	CSVContent += "UIName,ScreenShot,OpenTime(Ms),AvgFPS,LayoutEnum,NiagaraWidgetNum,NiagaraEmitterNum,UObjectNum,TotalTrackedMemoryBeforeShow, TotalTrackedMemoryOnShow, TotalTrackedMemoryOnClose, TotalMemoryIncreaseOnOpen,TotalMemoryIncreaseOnClose,LuaMemoryIncreaseOnOpen,"
				"LuaMemoryIncreaseOnClose,UIMemoryIncreaseOnOpen,UIMemoryIncreaseOnClose,UObjectMemoryIncreaseOnOpen,UObjectMemoryIncreaseOnClose,UObjectsIncreaseRefByLua,"
				"TextureMemoryIncreaseOnOpen,TextureMemoryIncreaseOnClose,AtlasNum,Atlas,TextureNum,Texture,Error,"
				"Total Slate Tick Time,Num Batches,Num Batches (UMG),Draw Window And Children Time,Tick Widgets,SlatePrepass,Game UI Paint,Overdraw,"
				"SlateOverDrawAvg,SlateMaxOverDrawCount,SlateOverDrawWithoutMTAvg,SlateMaxOverDrawWithoutMTCount,"
				"Font Asset Count(KGUI),Font Asset Memory/Mib(KGUI) , Font Texture Count(KGUI), Font Texture Memory/Mib(KGUI), "
				"Static Atlas Count(KGUI), Static Atlas Memory/Mib(KGUI),  Dynamic Atlas Count(KGUI), Dynamic Atlas Memory/Mib(KGUI),  Unpacked Texture Count(KGUI), Unpacked Texture Memory/Mib(KGUI),"
				"UObjects Created";
	CSVContent += "\n";
	UIProfileDataArray.RemoveAt(0);
	for (const FUIProfileData& Data : UIProfileDataArray)
	{
		FString CSVString;
		CSVString += Data.Name.ToString() + TEXT(","); // UIName
		CSVString += Data.ScreenShotPath + TEXT(",");  // ScreenShot
		CSVString += FString::Printf(TEXT("%f,"), Data.Time);  // OpenTime
		CSVString += FString::Printf(TEXT("%.2f,"), Data.AvgFPS); // Average FPS
		CSVString += FString::Printf(TEXT("%d,"), Data.LayoutEnum);  // LayoutEnum
		CSVString += FString::Printf(TEXT("%d,"), Data.NiagaraWidgetNum); // NiagaraWidgetNum
		CSVString += FString::Printf(TEXT("%d,"), Data.NiagaraEmitterNum); // NiagaraEmitterNum
		CSVString += FString::Printf(TEXT("%d,"), Data.UObjectNum);  // UObjectNum - From KG Memory Analyzer.
		CSVString += FString::Printf(TEXT("%.2f,"), Data.TotalTrackedMemoryBefore); // TotalTrackedMemoryBeforeShow
		CSVString += FString::Printf(TEXT("%.2f,"), Data.TotalTrackedMemoryOnShow); // TotalTrackedMemoryOnShow
		CSVString += FString::Printf(TEXT("%.2f,"), Data.TotalTrackedMemoryOnClose); // TotalTrackedMemoryOnClose
		CSVString += FString::Printf(TEXT("%.2f,"), Data.TotalTrackedMemoryOnShow - Data.TotalTrackedMemoryBefore); // TotalMemoryIncreaseOnOpen
		CSVString += FString::Printf(TEXT("%.2f,"), Data.TotalTrackedMemoryOnClose - Data.TotalTrackedMemoryBefore); // TotalMemoryIncreaseOnClose
		CSVString += FString::Printf(TEXT("%.2f,"), Data.LuaMemoryOnShow - Data.LuaMemoryBefore); // LuaMemoryIncreaseOnOpen
		CSVString += FString::Printf(TEXT("%.2f,"),  Data.LuaMemoryOnClose - Data.LuaMemoryBefore); // LuaMemoryIncreaseOnClose
		CSVString += FString::Printf(TEXT("%.2f,"), Data.UIMemoryOnShow - Data.UIMemoryBefore);  // UIMemoryIncreaseOnOpen
		CSVString += FString::Printf(TEXT("%.2f,"), Data.UIMemoryOnClose - Data.UIMemoryBefore); // UIMemoryIncreaseOnClose
		CSVString += FString::Printf(TEXT("%.2f,"), Data.UObjectMemoryOnShow - Data.UObjectMemoryBefore);  // UObjectMemoryIncreaseOnOpen
		CSVString += FString::Printf(TEXT("%.2f,"), Data.UObjectMemoryOnClose - Data.UObjectMemoryBefore); // UObjectMemoryIncreaseOnClose
		for (auto UObject : Data.UObjectsLuaAdd)
		{
			CSVString += UObject + TEXT(";"); // UObjectsIncreaseRefByLua
		}
		CSVString += TEXT(",");
		CSVString += FString::Printf(TEXT("%f,"), Data.TextureMemoryOnShow - Data.TextureMemoryBefore); // TextureMemoryIncreaseOnOpen
		CSVString += FString::Printf(TEXT("%f,"), Data.TextureMemoryOnClose - Data.TextureMemoryBefore); // TextureMemoryIncreaseOnClose
		CSVString += FString::Printf(TEXT("%d,"), Data.DependenceAtlasSet.Num()); // AtlasNum
		CSVString += TEXT("\"");
		for (auto Atlas : Data.DependenceAtlasSet)
		{
			CSVString += Atlas + TEXT(";"); // Atlas(Count;Size)
		}
		CSVString += TEXT("\",");
		CSVString += FString::Printf(TEXT("%d,"), Data.DependenceTextureSet.Num()); // TextureNum
		for (auto Texture : Data.DependenceTextureSet)
		{
			CSVString += Texture + TEXT(";"); // Texture
		}
		CSVString += TEXT(",");
		CSVString += Data.Error + TEXT(","); // Error
		for (auto Title : SlateStatNameArray)
		{
			if (Data.SlateStatValueArray.Contains(Title))
			{
				CSVString += FString::Printf(TEXT("%f,"), Data.SlateStatValueArray[Title].Value); // Slate RT: Rendering,Slate RT: Draw Batches,Draw Window And Children Time,Game UI Paint,Tick Widgets,SlatePrepass,Num Batches,Num Vertices
			}
			else
			{
				CSVString += TEXT("0,");
			}
		}
		CSVString += Data.OverdrawScreenShotPath + TEXT(","); // Overdraw
		CSVString +=  FString::Printf(TEXT("%f,"), Data.SlateOverDrawAvg); // SlateOverDrawAvg
		CSVString += FString::Printf(TEXT("%f,"), Data.SlateMaxOverDrawCount); // SlateMaxOverDrawCount
		CSVString += FString::Printf(TEXT("%f,"), Data.SlateOverDrawWithoutMTAvg); // SlateOverDrawWithoutMTAvg
		CSVString += FString::Printf(TEXT("%f,"), Data.SlateMaxOverDrawWithoutMTCount); // SlateMaxOverDrawWithoutMTCount
		CSVString += FString::Printf(TEXT("%d,"),Data.Analyser.GetFontAsset().Count); // Font Asset Count(KGUI)
		CSVString += FString::Printf(TEXT("%f,"),Data.Analyser.GetFontAsset().Memory * InvToMb); // Font Asset Memory(KGUI)
		CSVString += FString::Printf(TEXT("%d,"),Data.Analyser.GetFontTexture().Count); // Font Texture Count(KGUI)
		CSVString += FString::Printf(TEXT("%f,"),Data.Analyser.GetFontTexture().Memory * InvToMb); // Font Texture Memory(KGUI)
		CSVString += FString::Printf(TEXT("%d,"), Data.Analyser.GetStaticAtlas().Count); // Static Atlas Count(KGUI)
		CSVString += FString::Printf(TEXT("%f,"),Data.Analyser.GetStaticAtlas().Memory * InvToMb); // Static Atlas Memory(KGUI)
		CSVString += FString::Printf(TEXT("%d,"), Data.Analyser.GetDynamicAtlas().Count); // Dynamic Atlas Count(KGUI)
		CSVString += FString::Printf(TEXT("%f,"),Data.Analyser.GetDynamicAtlas().Memory * InvToMb); // Dynamic Atlas Memory(KGUI)
		CSVString += FString::Printf(TEXT("%d,"), Data.Analyser.GetUnpackedTexture().Count); // Unpacked Texture Count(KGUI)
		CSVString += FString::Printf(TEXT("%f,"),Data.Analyser.GetUnpackedTexture().Memory * InvToMb); // Unpacked Texture Memory(KGUI)
		for (const TPair<FString, int32>& Pair: Data.CreatedObjArrays)
		{
			CSVString += FString::Printf(TEXT("%s-%d;"), *Pair.Key, Pair.Value); // Created UObjects.
		}
		CSVContent += CSVString + TEXT("\n");
	}
	const FString FilePath = FPaths::ProjectSavedDir() / TEXT("UIProfile.csv");
	FFileHelper::SaveStringToFile(CSVContent, *FilePath);

	ShowResultWindow();

	if (GetWorld() && bNeedQuitGame)
	{
		if (APlayerController* PlayerController = GetWorld()->GetFirstPlayerController())
		{
			Release();
			
			UKismetSystemLibrary::QuitGame(
				GetWorld(),
				PlayerController,
				EQuitPreference::Quit,
				true
			);
		}
	}
}

void UUIAutomationProfile::ShowResultWindow()
{
	if (ResultWindow.IsValid())
	{
		ResultWindow->RequestDestroyWindow();
		ResultWindow.Reset();
	}
 
	ResultWindow = SNew(SWindow)
	// .Title(TEXT("UI性能自动化结果展示"))
   .ClientSize(FVector2D(1920, 1080))
   .SupportsMinimize(true)
   .SupportsMaximize(true)
   [
	   SNew(SKGUIAutomationProfileWidget)
	   .TableItems(UIAutoListDataArray)
   ];
 
	FSlateApplication::Get().AddWindow(ResultWindow.ToSharedRef());
}

void UUIAutomationProfile::Release()
{
	ObjListener->OnUObjectArrayShutdown();
	delete ObjListener;
	ObjListener = nullptr;

	SlateStatNameArray.Empty();
	UIProfileDataArray.Empty();
	// UIAutoListDataArray.Empty();

	ResultWindow.Reset();

}

void UUIAutomationProfile::ForceGarbageCollection()
{
	GEngine->ForceGarbageCollection(true);
}

void UUIAutomationProfile::dumpUObjectsLuaBefore() {
	auto state = slua::LuaState::get();
	if (!state) return;
	auto& map = state->cacheSet();
	for (auto& it : map) {
		TempUIProfileData.UObjectsLuaBefore.Add(slua::getUObjName(it.Key));
	}
}

void UUIAutomationProfile::dumpUObjectsLuaAdd()
{
	auto state = slua::LuaState::get();
	if (!state) return;
	auto& map = state->cacheSet();
	for (auto& it : map) {
		if (!TempUIProfileData.UObjectsLuaBefore.Contains(slua::getUObjName(it.Key)))
		{
			// 剔除掉白名单内容
			auto ObjClassName = it.Key->GetClass()->GetName();
			if (TempUIProfileData.UObjectsWhiteList.Contains(ObjClassName))
			{
				continue;
			}
			// 这里需要额外剔除掉BlueprintGeneratedClass/UPackage/UClass，这俩属于引擎自身管理，不在业务范围内
			if (!it.Key->IsA(UClass::StaticClass()) && !it.Key->IsA(UWidgetBlueprintGeneratedClass::StaticClass()) && !it.Key->IsA(UPackage::StaticClass()) && !it.Key->HasAnyFlags(RF_ClassDefaultObject|RF_ArchetypeObject))
			{
				TempUIProfileData.UObjectsLuaAdd.Add(slua::getUObjName(it.Key));
				UE_LOG(LogTemp, Log, TEXT("[UUIAutomationProfile::dumpUObjectsLuaAdd] Object:%s, Flags:%d"), *it.Key->GetName(), it.Key->GetFlags());
			}
		}
	}
	for (auto& it : TempUIProfileData.UObjectsLuaAdd)
	{
		UE_LOG(LogUIAutomationProfile, Log, TEXT("Increase UObject Ref by Lua: %s"), *it);
	}
}

bool UUIAutomationProfile::RecursivelyCheckNiagaraSystemWidget(UUserWidget* UserWidget, int32& NiagaraWidgetNum, int32& NiagaraEmitterNum)
{
	if (!UserWidget) return false;
	
	if (auto WidgetTree = UserWidget->WidgetTree)
	{
		TArray<UWidget*> WidgetArray;
		WidgetTree->GetAllWidgets(WidgetArray);
		for (UWidget* ChildWidget : WidgetArray)
		{
			if (UUserWidget* ChildUserWidget = Cast<UUserWidget>(ChildWidget))
			{
				RecursivelyCheckNiagaraSystemWidget(ChildUserWidget, NiagaraWidgetNum, NiagaraEmitterNum);
			}

			if (UNiagaraSystemWidget* Child = Cast<UNiagaraSystemWidget>(ChildWidget))
			{
				NiagaraWidgetNum += 1;

				// 统计Niagara粒子发射器数量
				if (UNiagaraUIComponent* NiagaraComp = Child->GetNiagaraComponent())
				{
					if (UNiagaraSystem* NiagaraSystem = NiagaraComp->GetAsset())
					{
						for (const FNiagaraEmitterHandle& EmitterHandle : NiagaraSystem->GetEmitterHandles())
						{
							if (UNiagaraEmitter* Emitter = EmitterHandle.GetInstance().Emitter)
							{
								NiagaraEmitterNum += 1;
							}
						}
					}
				}
				
			}
		}
	}

	return true;
}

int32 UUIAutomationProfile::GetCurrentBatches()
{
	// 如果多个GPU，取最大值
	int32 result = 0;
	for (int i = 0;i < MAX_NUM_GPUS;i ++)
	{
		if (result < GNumDrawCallsRHI[i])
		{
			result = GNumDrawCallsRHI[i];
		}
	}
	return result;
}
int32 UUIAutomationProfile::GetCurrentFPS()
{
	uint32 MaxFrameCycles = FMath::Max3(GGameThreadTime, GRenderThreadTime, GGPUFrameTime);
	float MaxFrameTime = FPlatformTime::ToMilliseconds(MaxFrameCycles);
	float CurrentFPS = (MaxFrameTime > 0.0f) ? 1000.0f / MaxFrameTime : 0.0f;
	return (int32)CurrentFPS;
}	
float UUIAutomationProfile::GetGameDelta()
{
	uint32 Cycles = GGameThreadTime;
	return FPlatformTime::ToMilliseconds(Cycles);
}
float UUIAutomationProfile::GetRenderDelta()
{
	uint32 Cycles = GRenderThreadTime;
	return FPlatformTime::ToMilliseconds(Cycles);
}
float UUIAutomationProfile::GetGPUDelta()
{
	uint32 Cycles = GGPUFrameTime;
	return FPlatformTime::ToMilliseconds(Cycles);
}

TArray<FString> UUIAutomationProfile::FindMaterialsByName(const FString& SearchText, bool bExactMatch)
{
	TArray<FString> FoundMaterialNames;
    
	// 获取资产注册表模块
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
    
	// 如果资产注册表正在加载，等待它完成
	if (AssetRegistry.IsLoadingAssets())
	{
		UE_LOG(LogUIAutomationProfile, Warning, TEXT("资产注册表正在加载中，等待完成..."));
		bool bIsFinishedLoading = false;
		while (!bIsFinishedLoading)
		{
			bIsFinishedLoading = !AssetRegistry.IsLoadingAssets();
			FPlatformProcess::Sleep(0.1f);
		}
		UE_LOG(LogUIAutomationProfile, Warning, TEXT("资产注册表加载完成"));
	}

	// 强制扫描内容目录（确保所有资产都被发现）
	TArray<FString> PathsToScan;
	PathsToScan.Add(TEXT("/Game"));  // 添加游戏内容路径
	PathsToScan.Add(TEXT("/Engine")); // 添加引擎内容路径

	AssetRegistry.ScanPathsSynchronous(PathsToScan, false);
	UE_LOG(LogUIAutomationProfile, Warning, TEXT("路径扫描完成，开始查询"));

	// 打印当前所有资产类的统计信息，帮助调试
	TArray<FAssetData> AllAssets;
	AssetRegistry.GetAllAssets(AllAssets, true);

	// 统计不同类型的资产数量
	TMap<FName, int32> AssetTypeCounts;
	//for (const FAssetData& Asset : AllAssets)
	//{
	//	if (!AssetTypeCounts.Contains(Asset.AssetClass))
	//	{
	//		AssetTypeCounts.Add(Asset.AssetClass, 0);
	//	}
	//	AssetTypeCounts[Asset.AssetClass]++;
	//}
	for (const FAssetData& Asset : AllAssets)
	{
		FName assetType = FName(Asset.AssetClassPath.ToString());
		if (!AssetTypeCounts.Contains(assetType))
		{
			AssetTypeCounts.Add(assetType, 0);
		}
		AssetTypeCounts[assetType]++;
	}

	UE_LOG(LogUIAutomationProfile, Warning, TEXT("资产注册表中发现资产总数: %d"), AllAssets.Num());
	for (auto& TypeCount : AssetTypeCounts)
	{
		UE_LOG(LogUIAutomationProfile, Warning, TEXT("  - %s: %d 个"), *TypeCount.Key.ToString(), TypeCount.Value);
	}

	// 设置查询参数，使用更宽泛的过滤条件
	FARFilter Filter;

	// 查询材质及其所有子类
	// 尝试多种类名，确保能够找到材质
	//Filter.ClassNames.Add(FName("Material"));
	//Filter.ClassNames.Add(FName("MaterialInstance"));
	//Filter.ClassNames.Add(FName("MaterialInstanceConstant"));
	//Filter.ClassNames.Add(FName("MaterialInstanceDynamic"));
	//Filter.ClassNames.Add(UMaterialInterface::StaticClass()->GetFName());
	Filter.ClassPaths.Add(UMaterial::StaticClass()->GetClassPathName());
	Filter.ClassPaths.Add(UMaterialInstance::StaticClass()->GetClassPathName());
	Filter.ClassPaths.Add(UMaterialInstanceConstant::StaticClass()->GetClassPathName());
	Filter.ClassPaths.Add(UMaterialInstanceDynamic::StaticClass()->GetClassPathName());
	Filter.ClassPaths.Add(UMaterialInterface::StaticClass()->GetClassPathName());

	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	
	// 查询所有材质资产
	TArray<FAssetData> AssetData;
	AssetRegistry.GetAssets(Filter, AssetData);
    
	// UE_LOG(LogUIAutomationProfile, Log, TEXT("查找材质，输入：%s，匹配模式：%s，找到总数：%d"), *SearchText, bExactMatch ? TEXT("精确匹配") : TEXT("包含匹配"), AssetData.Num());
    
	// 遍历结果，根据名称过滤
	for (const FAssetData& Asset : AssetData)
	{
		FString AssetName = Asset.GetSoftObjectPath().ToString();
        
		bool bMatchesSearch = false;
		if (bExactMatch)
		{
			bMatchesSearch = AssetName.Equals(SearchText, ESearchCase::IgnoreCase);
		}
		else
		{
			bMatchesSearch = AssetName.Contains(SearchText, ESearchCase::IgnoreCase);
		}
        
		if (bMatchesSearch)
		{
			// 直接添加名称到结果列表，不加载资产
			FoundMaterialNames.Add(AssetName);
			UE_LOG(LogUIAutomationProfile, Warning, TEXT("    找到匹配材质：%s"), *AssetName);
			if (FoundMaterialNames.Num() > 15)
			{
				// 只返回前15个
				break;
			}
		}
	}
    
	return FoundMaterialNames;
} 
void UUIAutomationProfile::BeginDestroy()
{
	Super::BeginDestroy();
	
#if PLATFORM_ANDROID
	CleanupJNIMethods();
#endif
}
float UUIAutomationProfile::GetBatteryVoltage()
{
#if PLATFORM_ANDROID
	return GetBatteryVoltageAndroid();
#endif
	return 0;
}

float UUIAutomationProfile::GetBatteryCurrent()
{
#if PLATFORM_ANDROID
	return GetBatteryCurrentAndroid();
#endif
	return 0;
}
float UUIAutomationProfile::GetBatteryTemperature()
{
#if PLATFORM_ANDROID
	return GetBatteryTemperatureAndroid();
#endif
	return 0.0f;
}
float UUIAutomationProfile::GetBatteryLevel()
{
#if PLATFORM_ANDROID
	return GetBatteryLevelAndroid();
#endif
	return 0.0f;
}
float UUIAutomationProfile::GetCpuFrequency()
{
#if PLATFORM_ANDROID
	return GetCpuFrequencyAndroid();
#endif
	return 0.0f;
}

#if PLATFORM_ANDROID
namespace KGUIAutomation
{
	jobject AndroidActivity;
	jclass ContextClass = nullptr;
	jmethodID GetSystemServiceMethod = nullptr;
	jfieldID BatteryServiceField = nullptr;
	jstring BatteryServiceString = nullptr;
	jclass BatteryManagerClass = nullptr;
	jmethodID GetIntPropertyMethod = nullptr;
	jfieldID BatteryPropertyCurrentNowField = nullptr;
	jstring VoltageExtraString = nullptr;
	jstring CurrentExtraString = nullptr;
	jclass IntentFilterClass = nullptr;
	jmethodID IntentFilterConstructor = nullptr;
	jstring ActionBatteryChangedString = nullptr;
	jclass IntentClass = nullptr;
	jmethodID GetIntExtraMethod = nullptr;
	jstring ExtraTemperatureString = nullptr;
	jstring ExtraLevelString = nullptr;
	jstring ExtraScaleString = nullptr;
	jclass FileClass = nullptr;
	jmethodID FileConstructor = nullptr;
	jmethodID ExistsMethod = nullptr;
	jstring CpuFreqPath = nullptr;
	jclass FileReaderClass = nullptr;
	jmethodID FileReaderConstructor = nullptr;
	jclass BufferedReaderClass = nullptr;
	jmethodID BufferedReaderConstructor = nullptr;
	jmethodID ReadLineMethod = nullptr;
	jmethodID CloseMethod = nullptr;
}

bool UUIAutomationProfile::bJNICacheInitialized = false;

void UUIAutomationProfile::InitJNIMethods()
{
    if (bJNICacheInitialized)
    {
        return; // 已初始化，避免重复操作
    }

	KGUIAutomation::AndroidActivity = FAndroidApplication::GetGameActivityThis();
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        // 创建全局引用保存类
        jclass localContextClass = Env->FindClass("android/content/Context");
        if (localContextClass)
        {
            KGUIAutomation::ContextClass = (jclass)Env->NewGlobalRef(localContextClass);
            KGUIAutomation::GetSystemServiceMethod = Env->GetMethodID(KGUIAutomation::ContextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
            KGUIAutomation::BatteryServiceField = Env->GetStaticFieldID(KGUIAutomation::ContextClass, "BATTERY_SERVICE", "Ljava/lang/String;");
            
            jstring localBatteryString = (jstring)Env->GetStaticObjectField(KGUIAutomation::ContextClass, KGUIAutomation::BatteryServiceField);
            KGUIAutomation::BatteryServiceString = (jstring)Env->NewGlobalRef(localBatteryString);
            Env->DeleteLocalRef(localBatteryString);
            
            Env->DeleteLocalRef(localContextClass);
        }
    	else
    	{
    		return;
    	}
        
        // BatteryManager
        jclass localBatteryManagerClass = Env->FindClass("android/os/BatteryManager");
        if (localBatteryManagerClass)
        {
            KGUIAutomation::BatteryManagerClass = (jclass)Env->NewGlobalRef(localBatteryManagerClass);
            KGUIAutomation::GetIntPropertyMethod = Env->GetMethodID(KGUIAutomation::BatteryManagerClass, "getIntProperty", "(I)I");
            KGUIAutomation::BatteryPropertyCurrentNowField = Env->GetStaticFieldID(KGUIAutomation::BatteryManagerClass, "BATTERY_PROPERTY_CURRENT_NOW", "I");
            
            Env->DeleteLocalRef(localBatteryManagerClass);
        }
        else
        {
        	return;
        }
        
        // IntentFilter
        jclass localIntentFilterClass = Env->FindClass("android/content/IntentFilter");
        if (localIntentFilterClass)
        {
            KGUIAutomation::IntentFilterClass = (jclass)Env->NewGlobalRef(localIntentFilterClass);
            KGUIAutomation::IntentFilterConstructor = Env->GetMethodID(KGUIAutomation::IntentFilterClass, "<init>", "(Ljava/lang/String;)V");
            
            jstring localAction = Env->NewStringUTF("android.intent.action.BATTERY_CHANGED");
            KGUIAutomation::ActionBatteryChangedString = (jstring)Env->NewGlobalRef(localAction);
            Env->DeleteLocalRef(localAction);
            
            Env->DeleteLocalRef(localIntentFilterClass);
        }
        else
        {
        	return;
        }
        
        // Intent
        jclass localIntentClass = Env->FindClass("android/content/Intent");
        if (localIntentClass)
        {
            KGUIAutomation::IntentClass = (jclass)Env->NewGlobalRef(localIntentClass);
            KGUIAutomation::GetIntExtraMethod = Env->GetMethodID(KGUIAutomation::IntentClass, "getIntExtra", "(Ljava/lang/String;I)I");
            
            jstring localTempString = Env->NewStringUTF("temperature");
            KGUIAutomation::ExtraTemperatureString = (jstring)Env->NewGlobalRef(localTempString);
            Env->DeleteLocalRef(localTempString);
            
            jstring localLevelString = Env->NewStringUTF("level");
            KGUIAutomation::ExtraLevelString = (jstring)Env->NewGlobalRef(localLevelString);
            Env->DeleteLocalRef(localLevelString);
            
            jstring localScaleString = Env->NewStringUTF("scale");
            KGUIAutomation::ExtraScaleString = (jstring)Env->NewGlobalRef(localScaleString);
            Env->DeleteLocalRef(localScaleString);
            
            Env->DeleteLocalRef(localIntentClass);
        }
        else
        {
        	return;
        }
        
        // File
        jclass localFileClass = Env->FindClass("java/io/File");
        if (localFileClass)
        {
            KGUIAutomation::FileClass = (jclass)Env->NewGlobalRef(localFileClass);
            KGUIAutomation::FileConstructor = Env->GetMethodID(KGUIAutomation::FileClass, "<init>", "(Ljava/lang/String;)V");
            KGUIAutomation::ExistsMethod = Env->GetMethodID(KGUIAutomation::FileClass, "exists", "()Z");
            
            jstring localPath = Env->NewStringUTF("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");
            KGUIAutomation::CpuFreqPath = (jstring)Env->NewGlobalRef(localPath);
            Env->DeleteLocalRef(localPath);
            
            Env->DeleteLocalRef(localFileClass);
        }
        else
        {
        	return;
        }
        
        // FileReader
        jclass localFileReaderClass = Env->FindClass("java/io/FileReader");
        if (localFileReaderClass)
        {
            KGUIAutomation::FileReaderClass = (jclass)Env->NewGlobalRef(localFileReaderClass);
            KGUIAutomation::FileReaderConstructor = Env->GetMethodID(KGUIAutomation::FileReaderClass, "<init>", "(Ljava/io/File;)V");
            
            Env->DeleteLocalRef(localFileReaderClass);
        }
        else
        {
        	return;
        }
        
        // BufferedReader
        jclass localBufferedReaderClass = Env->FindClass("java/io/BufferedReader");
        if (localBufferedReaderClass)
        {
            KGUIAutomation::BufferedReaderClass = (jclass)Env->NewGlobalRef(localBufferedReaderClass);
            KGUIAutomation::BufferedReaderConstructor = Env->GetMethodID(KGUIAutomation::BufferedReaderClass, "<init>", "(Ljava/io/Reader;)V");
            KGUIAutomation::ReadLineMethod = Env->GetMethodID(KGUIAutomation::BufferedReaderClass, "readLine", "()Ljava/lang/String;");
            KGUIAutomation::CloseMethod = Env->GetMethodID(KGUIAutomation::BufferedReaderClass, "close", "()V");
            
            Env->DeleteLocalRef(localBufferedReaderClass);
        }
        else
        {
        	return;
        }

		// 添加电压Extra字符串
		jstring localVoltageString = Env->NewStringUTF("voltage");
		KGUIAutomation::VoltageExtraString = (jstring)Env->NewGlobalRef(localVoltageString);
		Env->DeleteLocalRef(localVoltageString);

		// 添加电流Extra字符串
		jstring localCurrentString = Env->NewStringUTF("current");
		KGUIAutomation::CurrentExtraString = (jstring)Env->NewGlobalRef(localCurrentString);
		Env->DeleteLocalRef(localCurrentString);
        
        bJNICacheInitialized = true;
        UE_LOG(LogUIAutomationProfile, Log, TEXT("JNI缓存初始化完成"));
    }
}

void UUIAutomationProfile::CleanupJNIMethods()
{
    if (!bJNICacheInitialized)
    {
        return; // 未初始化，无需清理
    }
    
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        // 清理全局引用
        if (KGUIAutomation::ContextClass) Env->DeleteGlobalRef(KGUIAutomation::ContextClass);
        if (KGUIAutomation::BatteryServiceString) Env->DeleteGlobalRef(KGUIAutomation::BatteryServiceString);
        if (KGUIAutomation::BatteryManagerClass) Env->DeleteGlobalRef(KGUIAutomation::BatteryManagerClass);
        if (KGUIAutomation::IntentFilterClass) Env->DeleteGlobalRef(KGUIAutomation::IntentFilterClass);
        if (KGUIAutomation::ActionBatteryChangedString) Env->DeleteGlobalRef(KGUIAutomation::ActionBatteryChangedString);
        if (KGUIAutomation::IntentClass) Env->DeleteGlobalRef(KGUIAutomation::IntentClass);
        if (KGUIAutomation::ExtraTemperatureString) Env->DeleteGlobalRef(KGUIAutomation::ExtraTemperatureString);
        if (KGUIAutomation::ExtraLevelString) Env->DeleteGlobalRef(KGUIAutomation::ExtraLevelString);
        if (KGUIAutomation::ExtraScaleString) Env->DeleteGlobalRef(KGUIAutomation::ExtraScaleString);
        if (KGUIAutomation::FileClass) Env->DeleteGlobalRef(KGUIAutomation::FileClass);
        if (KGUIAutomation::CpuFreqPath) Env->DeleteGlobalRef(KGUIAutomation::CpuFreqPath);
        if (KGUIAutomation::FileReaderClass) Env->DeleteGlobalRef(KGUIAutomation::FileReaderClass);
        if (KGUIAutomation::BufferedReaderClass) Env->DeleteGlobalRef(KGUIAutomation::BufferedReaderClass);

		// 清理电压相关引用
		if (KGUIAutomation::VoltageExtraString) Env->DeleteGlobalRef(KGUIAutomation::VoltageExtraString);
		KGUIAutomation::VoltageExtraString = nullptr;

		// 清理电流相关引用
		if (KGUIAutomation::CurrentExtraString) Env->DeleteGlobalRef(KGUIAutomation::CurrentExtraString);
		KGUIAutomation::CurrentExtraString = nullptr;

        // 重置所有指针
        KGUIAutomation::ContextClass = nullptr;
        KGUIAutomation::GetSystemServiceMethod = nullptr;
        KGUIAutomation::BatteryServiceField = nullptr;
        KGUIAutomation::BatteryServiceString = nullptr;
        
        KGUIAutomation::BatteryManagerClass = nullptr;
        KGUIAutomation::GetIntPropertyMethod = nullptr;
        KGUIAutomation::BatteryPropertyCurrentNowField = nullptr;
        
        KGUIAutomation::IntentFilterClass = nullptr;
        KGUIAutomation::IntentFilterConstructor = nullptr;
        KGUIAutomation::ActionBatteryChangedString = nullptr;
        
        KGUIAutomation::IntentClass = nullptr;
        KGUIAutomation::GetIntExtraMethod = nullptr;
        KGUIAutomation::ExtraTemperatureString = nullptr;
        KGUIAutomation::ExtraLevelString = nullptr;
        KGUIAutomation::ExtraScaleString = nullptr;
        
        KGUIAutomation::FileClass = nullptr;
        KGUIAutomation::FileConstructor = nullptr;
        KGUIAutomation::ExistsMethod = nullptr;
        KGUIAutomation::CpuFreqPath = nullptr;
        
        KGUIAutomation::FileReaderClass = nullptr;
        KGUIAutomation::FileReaderConstructor = nullptr;
        
        KGUIAutomation::BufferedReaderClass = nullptr;
        KGUIAutomation::BufferedReaderConstructor = nullptr;
        KGUIAutomation::ReadLineMethod = nullptr;
        KGUIAutomation::CloseMethod = nullptr;
        
        bJNICacheInitialized = false;
        UE_LOG(LogUIAutomationProfile, Log, TEXT("JNI缓存已清理"));
    }
}

float UUIAutomationProfile::GetBatteryCurrentAndroid()
{
	InitJNIMethods();
	
    float Current = 0.0f;
    
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
	{
		// 方法1: 尝试使用BatteryManager API (可能返回0)
        if (bJNICacheInitialized && KGUIAutomation::ContextClass && KGUIAutomation::GetSystemServiceMethod && KGUIAutomation::BatteryServiceString)
        {
            // 获取BatteryManager
            jobject batteryManager = Env->CallObjectMethod(KGUIAutomation::AndroidActivity, KGUIAutomation::GetSystemServiceMethod, KGUIAutomation::BatteryServiceString);
            if (batteryManager && KGUIAutomation::BatteryManagerClass && KGUIAutomation::GetIntPropertyMethod && KGUIAutomation::BatteryPropertyCurrentNowField)
            {
                // 获取电流属性ID
                jint batteryPropertyCurrentNow = Env->GetStaticIntField(KGUIAutomation::BatteryManagerClass, KGUIAutomation::BatteryPropertyCurrentNowField);

				// 获取电流 (微安)
				jint currentMicroAmps = Env->CallIntMethod(batteryManager, KGUIAutomation::GetIntPropertyMethod, batteryPropertyCurrentNow);

				if (FMath::Abs(currentMicroAmps) > 100) // 大于100微安才认为有效
				{
					Current = (float)currentMicroAmps / 1000.0f; // 转换为毫安
					UE_LOG(LogTemp, Verbose, TEXT("从BatteryManager获取电流: %.2f mA (原始值: %d μA)"),
						Current, currentMicroAmps);
				}
				else
				{
					UE_LOG(LogTemp, Verbose, TEXT("BatteryManager返回的电流接近0: %d μA"), currentMicroAmps);
				}
            }
            
            // 清理本地引用
            if (batteryManager) Env->DeleteLocalRef(batteryManager);
        }
     
        // 方法2: 尝试通过Intent广播获取
        if (FMath::Abs(Current) < 0.1f)
        {
            if (bJNICacheInitialized && KGUIAutomation::IntentFilterClass && KGUIAutomation::IntentFilterConstructor && KGUIAutomation::ActionBatteryChangedString)
            {
                // 创建IntentFilter
                jobject intentFilter = Env->NewObject(KGUIAutomation::IntentFilterClass, KGUIAutomation::IntentFilterConstructor, KGUIAutomation::ActionBatteryChangedString);
                if (intentFilter)
                {
                    // 注册广播接收器
                    jmethodID registerReceiverMethod = Env->GetMethodID(KGUIAutomation::ContextClass, "registerReceiver", 
                        "(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;");
                    
                    if (registerReceiverMethod)
                    {
                        jobject batteryStatus = Env->CallObjectMethod(KGUIAutomation::AndroidActivity, registerReceiverMethod, nullptr, intentFilter);
                        if (batteryStatus && KGUIAutomation::IntentClass && KGUIAutomation::GetIntExtraMethod && KGUIAutomation::CurrentExtraString)
                        {
                            // 尝试直接获取电流Extra
                            jint currentValue = Env->CallIntMethod(batteryStatus, KGUIAutomation::GetIntExtraMethod, KGUIAutomation::CurrentExtraString, 0);
                            
                            if (FMath::Abs(currentValue) > 100)
                            {
                                Current = (float)currentValue / 1000.0f; // 转换为毫安
                                UE_LOG(LogTemp, Verbose, TEXT("从Intent Extra获取电流: %.2f mA (原始值: %d)"),
                                    Current, currentValue);
                            }
                            else
                            {
                                // 尝试获取充电状态和剩余容量来估算电流
                                jstring statusExtra = Env->NewStringUTF("status");
                                jstring levelExtra = Env->NewStringUTF("level");
                                jstring scaleExtra = Env->NewStringUTF("scale");
                                
                                jint status = Env->CallIntMethod(batteryStatus, KGUIAutomation::GetIntExtraMethod, statusExtra, 0);
                                jint level = Env->CallIntMethod(batteryStatus, KGUIAutomation::GetIntExtraMethod, levelExtra, 0);
                                jint scale = Env->CallIntMethod(batteryStatus, KGUIAutomation::GetIntExtraMethod, scaleExtra, 100);
                                
                                // 电池状态: 2=充电, 3=放电, 4=不充电, 5=充满
                                bool isCharging = (status == 2 || status == 5);
                                float batteryPercentage = (float)level / (float)scale;
                                
                                // 简单估算: 取决于电池状态和电量
                                if (isCharging)
                                {
                                    // 充电时电流为负值
                                    Current = -500.0f - 1000.0f * (1.0f - batteryPercentage); // 电量越低，充电电流越大
                                }
                                else
                                {
                                    // 放电时电流为正值
                                    Current = 200.0f + 500.0f * (1.0f - batteryPercentage); // 电量越低，放电电流越大
                                }
                                
                                UE_LOG(LogTemp, Verbose, TEXT("根据电池状态估算电流: %.2f mA (状态:%d, 电量:%.1f%%)"), 
                                    Current, status, batteryPercentage * 100.0f);
                                
                                Env->DeleteLocalRef(statusExtra);
                                Env->DeleteLocalRef(levelExtra);
                                Env->DeleteLocalRef(scaleExtra);
                            }
                        }
                        
                        if (batteryStatus) Env->DeleteLocalRef(batteryStatus);
                    }
                    
                    Env->DeleteLocalRef(intentFilter);
                }
            }
        }
        
        // 方法3: 尝试读取系统文件
        if (FMath::Abs(Current) < 0.1f)
        {
            if (KGUIAutomation::FileClass && KGUIAutomation::FileConstructor)
            {
                // 尝试多个可能的电流文件路径
                const char* currentPaths[] = {
                    "/sys/class/power_supply/battery/current_now",
                    "/sys/class/power_supply/battery/batt_current",
                    "/sys/devices/platform/battery/power_supply/battery/current_now",
                    "/sys/class/power_supply/battery/current_avg"
                };
                
                for (const char* path : currentPaths)
                {
                    jstring filePath = Env->NewStringUTF(path);
                    jobject file = Env->NewObject(KGUIAutomation::FileClass, KGUIAutomation::FileConstructor, filePath);
                    
                    if (file && Env->CallBooleanMethod(file, KGUIAutomation::ExistsMethod))
                    {
                        if (KGUIAutomation::FileReaderClass && KGUIAutomation::FileReaderConstructor && 
                            KGUIAutomation::BufferedReaderClass && KGUIAutomation::BufferedReaderConstructor && KGUIAutomation::ReadLineMethod)
                        {
                            jobject fileReader = Env->NewObject(KGUIAutomation::FileReaderClass, KGUIAutomation::FileReaderConstructor, file);
                            jobject bufferedReader = Env->NewObject(KGUIAutomation::BufferedReaderClass, KGUIAutomation::BufferedReaderConstructor, fileReader);
                            
                            jstring line = (jstring)Env->CallObjectMethod(bufferedReader, KGUIAutomation::ReadLineMethod);
                            if (line)
                            {
                                const char* cstr = Env->GetStringUTFChars(line, NULL);
                                if (cstr)
                                {
                                    jlong currentValue = atol(cstr);
                                    if (FMath::Abs(currentValue) > 100)
                                    {
                                        // 值通常是微安
                                        Current = (float)currentValue / 1000.0f; // 微安到毫安
                                        
                                        // 某些设备可能返回负值表示放电，正值表示充电
                                        // 我们希望放电为正值，所以需要调整
                                        if (FMath::Abs(Current) > 10000.0f) // 如果值过大（可能是特殊单位）
                                        {
                                            Current /= 1000.0f; // 进一步缩小
                                        }
                                        
                                        UE_LOG(LogTemp, Verbose, TEXT("从%s读取电流: %.2f mA (原始值: %lld)"),
                                            UTF8_TO_TCHAR(path), Current, currentValue);
                                    }
                                    Env->ReleaseStringUTFChars(line, cstr);
                                }
                                Env->DeleteLocalRef(line);
                            }
                            
                            if (KGUIAutomation::CloseMethod)
                            {
                                Env->CallVoidMethod(bufferedReader, KGUIAutomation::CloseMethod);
                            }
                            Env->DeleteLocalRef(bufferedReader);
                            Env->DeleteLocalRef(fileReader);
                        }
                    }
                    
                    Env->DeleteLocalRef(file);
                    Env->DeleteLocalRef(filePath);
                    
                    // 如果获取到有效电流，跳出循环
                    if (FMath::Abs(Current) > 0.1f)
                    {
                        break;
                    }
                }
            }
        }
    }
    
    // 确保返回值具有正确的符号
    // 在大多数设备上，正值表示放电（设备消耗电池电量）
    // 如果是负值且接近0，认为是测量误差，返回小的正值
    if (Current < 0.0f && FMath::Abs(Current) < 10.0f)
    {
        Current = 10.0f;
    }
    
    // 如果仍然无法获取有效值，使用基于电池电量的估算值
    if (FMath::Abs(Current) < 0.1f)
    {
        // 获取电池电量百分比
        float batteryLevel = GetBatteryLevel();
        
        // 估算电流 - 电量越低，放电电流越大
        Current = 200.0f + 600.0f * (1.0f - batteryLevel / 100.0f);
        
        UE_LOG(LogTemp, Warning, TEXT("无法获取电流读数，根据电池电量(%.1f%%)估算: %.2f mA"), 
            batteryLevel, Current);
    }
    
    return Current;
}

float UUIAutomationProfile::GetBatteryTemperatureAndroid()
{
	InitJNIMethods();
	
    float Temperature = 0.0f;
    
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        // 确保缓存已初始化
        if (bJNICacheInitialized && KGUIAutomation::IntentFilterClass && KGUIAutomation::IntentFilterConstructor && KGUIAutomation::ActionBatteryChangedString)
        {
            // 创建 IntentFilter 对象
            jobject intentFilter = Env->NewObject(KGUIAutomation::IntentFilterClass, KGUIAutomation::IntentFilterConstructor, KGUIAutomation::ActionBatteryChangedString);
            
            // 注册广播接收器
            if (KGUIAutomation::ContextClass && intentFilter)
            {
                jmethodID registerReceiverMethod = KGUIAutomation::GetSystemServiceMethod ? 
                    Env->GetMethodID(KGUIAutomation::ContextClass, "registerReceiver", "(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;") :
                    nullptr;
                    
                if (registerReceiverMethod)
                {
                    jobject batteryStatus = Env->CallObjectMethod(KGUIAutomation::AndroidActivity, registerReceiverMethod, nullptr, intentFilter);
                    
                    if (batteryStatus && KGUIAutomation::IntentClass && KGUIAutomation::GetIntExtraMethod && KGUIAutomation::ExtraTemperatureString)
                    {
                        // 获取温度
                        jint temp = Env->CallIntMethod(batteryStatus, KGUIAutomation::GetIntExtraMethod, KGUIAutomation::ExtraTemperatureString, 0);
                        Temperature = (float)temp / 10.0f; // 转换为摄氏度
                        
                        // 清理
                        Env->DeleteLocalRef(batteryStatus);
                    }
                }
            }
            
            // 清理
            if (intentFilter) Env->DeleteLocalRef(intentFilter);
        }
    }
    
    return Temperature;
}

float UUIAutomationProfile::GetBatteryLevelAndroid()
{
	InitJNIMethods();
	
    float Level = 0.0f;
    
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {        
        // 确保缓存已初始化
        if (bJNICacheInitialized && KGUIAutomation::IntentFilterClass && KGUIAutomation::IntentFilterConstructor && KGUIAutomation::ActionBatteryChangedString)
        {
            // 创建 IntentFilter 对象
            jobject intentFilter = Env->NewObject(KGUIAutomation::IntentFilterClass, KGUIAutomation::IntentFilterConstructor, KGUIAutomation::ActionBatteryChangedString);
            
            // 注册广播接收器
            if (KGUIAutomation::ContextClass && intentFilter)
            {
                jmethodID registerReceiverMethod = KGUIAutomation::GetSystemServiceMethod ? 
                    Env->GetMethodID(KGUIAutomation::ContextClass, "registerReceiver", "(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;") :
                    nullptr;
                    
                if (registerReceiverMethod)
                {
                    jobject batteryStatus = Env->CallObjectMethod(KGUIAutomation::AndroidActivity, registerReceiverMethod, nullptr, intentFilter);
                    
                    if (batteryStatus && KGUIAutomation::IntentClass && KGUIAutomation::GetIntExtraMethod && KGUIAutomation::ExtraLevelString && KGUIAutomation::ExtraScaleString)
                    {
                        // 获取电量级别和最大刻度
                        jint level = Env->CallIntMethod(batteryStatus, KGUIAutomation::GetIntExtraMethod, KGUIAutomation::ExtraLevelString, 0);
                        jint scale = Env->CallIntMethod(batteryStatus, KGUIAutomation::GetIntExtraMethod, KGUIAutomation::ExtraScaleString, 100);
                        
                        if (scale > 0)
                        {
                            Level = (float)level / (float)scale * 100.0f;
                        }
                        
                        // 清理
                        Env->DeleteLocalRef(batteryStatus);
                    }
                }
            }
            
            // 清理
            if (intentFilter) Env->DeleteLocalRef(intentFilter);
        }
    }
    
    return Level;
}

float UUIAutomationProfile::GetCpuFrequencyAndroid()
{
	InitJNIMethods();
	
    float Frequency = 0.0f;
    
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        // 确保缓存已初始化
        if (bJNICacheInitialized && KGUIAutomation::FileClass && KGUIAutomation::FileConstructor && KGUIAutomation::ExistsMethod && KGUIAutomation::CpuFreqPath)
        {
            // 创建File对象
            jobject freqFile = Env->NewObject(KGUIAutomation::FileClass, KGUIAutomation::FileConstructor, KGUIAutomation::CpuFreqPath);
            
            if (freqFile)
            {
                jboolean fileExists = Env->CallBooleanMethod(freqFile, KGUIAutomation::ExistsMethod);
                
                if (fileExists && KGUIAutomation::FileReaderClass && KGUIAutomation::FileReaderConstructor && 
                    KGUIAutomation::BufferedReaderClass && KGUIAutomation::BufferedReaderConstructor && KGUIAutomation::ReadLineMethod && KGUIAutomation::CloseMethod)
                {
                    // 创建FileReader和BufferedReader
                    jobject fileReader = Env->NewObject(KGUIAutomation::FileReaderClass, KGUIAutomation::FileReaderConstructor, freqFile);
                    
                    if (fileReader)
                    {
                        jobject bufferedReader = Env->NewObject(KGUIAutomation::BufferedReaderClass, KGUIAutomation::BufferedReaderConstructor, fileReader);
                        
                        if (bufferedReader)
                        {
                            // 读取第一行
                            jstring line = (jstring)Env->CallObjectMethod(bufferedReader, KGUIAutomation::ReadLineMethod);
                            
                            if (line)
                            {
                                // 转换为C++字符串并解析
                                const char* cstr = Env->GetStringUTFChars(line, NULL);
                                if (cstr)
                                {
                                    // 转换为MHz
                                    Frequency = (float)atoi(cstr) / 1000.0f;
                                    Env->ReleaseStringUTFChars(line, cstr);
                                }
                                
                                Env->DeleteLocalRef(line);
                            }
                            
                            // 关闭reader并清理
                            Env->CallVoidMethod(bufferedReader, KGUIAutomation::CloseMethod);
                            Env->DeleteLocalRef(bufferedReader);
                        }
                        
                        Env->DeleteLocalRef(fileReader);
                    }
                }
                
                Env->DeleteLocalRef(freqFile);
            }
        }
    }
    
    return Frequency;
}

float UUIAutomationProfile::GetBatteryVoltageAndroid()
{
	InitJNIMethods();
	
    float Voltage = 0.2; // 默认电压值
    
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
		// 方法1: 使用Intent广播获取电压
		if (bJNICacheInitialized && KGUIAutomation::IntentFilterClass && KGUIAutomation::IntentFilterConstructor && KGUIAutomation::ActionBatteryChangedString)
		{
			// 创建IntentFilter
			jobject intentFilter = Env->NewObject(KGUIAutomation::IntentFilterClass, KGUIAutomation::IntentFilterConstructor, KGUIAutomation::ActionBatteryChangedString);
			if (intentFilter)
			{
				// 注册广播接收器
				jmethodID registerReceiverMethod = Env->GetMethodID(KGUIAutomation::ContextClass, "registerReceiver",
					"(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;");

				if (registerReceiverMethod)
				{
					jobject batteryStatus = Env->CallObjectMethod(KGUIAutomation::AndroidActivity, registerReceiverMethod, nullptr, intentFilter);
					if (batteryStatus && KGUIAutomation::IntentClass && KGUIAutomation::GetIntExtraMethod && KGUIAutomation::VoltageExtraString)
					{
						// 获取电压值 (毫伏)
						jint voltageMilliVolts = Env->CallIntMethod(batteryStatus, KGUIAutomation::GetIntExtraMethod, KGUIAutomation::VoltageExtraString, -1);

						// 一些设备可能会返回微伏而不是毫伏
						if (voltageMilliVolts > 0)
						{
							// 通常电压在2000-5000mV范围内，如果超过10000，可能是微伏
							if (voltageMilliVolts > 10000)
							{
								Voltage = (float)voltageMilliVolts / 1000000.0f; // 微伏转换为伏特
							}
							else
							{
								Voltage = (float)voltageMilliVolts / 1000.0f; // 毫伏转换为伏特
							}
							//UE_LOG(LogTemp, Log, TEXT("A：从Intent获取到电压: %f V (原始值: %d)"), Voltage, voltageMilliVolts);
						}
						Env->DeleteLocalRef(batteryStatus);
					}
				}
				Env->DeleteLocalRef(intentFilter);
			}
		}

		// 方法2: 如果Intent方式获取失败，尝试读取系统文件
		if (Voltage <= 0.0f || Voltage > 5.0f)
		{
			if (KGUIAutomation::FileClass && KGUIAutomation::FileConstructor)
			{
				// 尝试多个可能的电压文件路径
				const char* voltagePaths[] = {
					"/sys/class/power_supply/battery/voltage_now",
					"/sys/class/power_supply/battery/batt_vol",
					"/sys/devices/platform/battery/power_supply/battery/voltage_now"
				};

				for (const char* path : voltagePaths)
				{
					jstring filePath = Env->NewStringUTF(path);
					jobject file = Env->NewObject(KGUIAutomation::FileClass, KGUIAutomation::FileConstructor, filePath);

					if (file && Env->CallBooleanMethod(file, KGUIAutomation::ExistsMethod))
					{
						if (KGUIAutomation::FileReaderClass && KGUIAutomation::FileReaderConstructor &&
							KGUIAutomation::BufferedReaderClass && KGUIAutomation::BufferedReaderConstructor && KGUIAutomation::ReadLineMethod)
						{
							jobject fileReader = Env->NewObject(KGUIAutomation::FileReaderClass, KGUIAutomation::FileReaderConstructor, file);
							jobject bufferedReader = Env->NewObject(KGUIAutomation::BufferedReaderClass, KGUIAutomation::BufferedReaderConstructor, fileReader);

							jstring line = (jstring)Env->CallObjectMethod(bufferedReader, KGUIAutomation::ReadLineMethod);
							if (line)
							{
								const char* cstr = Env->GetStringUTFChars(line, NULL);
								if (cstr)
								{
									jlong voltageValue = atol(cstr);
									if (voltageValue > 0)
									{
										// 值可能是微伏或毫伏
										if (voltageValue > 10000)
										{
											Voltage = (float)voltageValue / 1000000.0f; // 微伏到伏特
										}
										else
										{
											Voltage = (float)voltageValue / 1000.0f; // 毫伏到伏特
										}
										UE_LOG(LogTemp, Log, TEXT("B：从%s获取到电压: %f V (原始值: %lld)"),
											UTF8_TO_TCHAR(path), Voltage, voltageValue);
									}
									Env->ReleaseStringUTFChars(line, cstr);
								}
								Env->DeleteLocalRef(line);
							}

							if (KGUIAutomation::CloseMethod)
							{
								Env->CallVoidMethod(bufferedReader, KGUIAutomation::CloseMethod);
							}
							Env->DeleteLocalRef(bufferedReader);
							Env->DeleteLocalRef(fileReader);
						}
					}

					Env->DeleteLocalRef(file);
					Env->DeleteLocalRef(filePath);

					// 如果已经获取到有效电压，跳出循环
					if (Voltage > 0.0f && Voltage <= 5.0f)
					{
						break;
					}
				}
			}
		}
    }
    
    // 确保电压在合理范围内
    if (Voltage <= 0.0f || Voltage > 5.0f)
    {
    	UE_LOG(LogTemp, Error, TEXT("从BatteryManager获取电压: %.2f 超过正常范围 (设置为默认值: 3.7f)"), Voltage);
    	Voltage = 3.7f; // 使用默认值
    }
    
    return Voltage;
}
#endif

UE_ENABLE_OPTIMIZATION