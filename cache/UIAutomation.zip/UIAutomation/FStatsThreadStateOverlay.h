// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#if STATS

#include "CoreMinimal.h"
#include "Stats/StatsData.h"

struct FSlateGroupFilter : IItemFilter
{
	TSet<FName> const& EnabledItems;

	FSlateGroupFilter(TSet<FName> const& InEnabledItems)
		: EnabledItems(InEnabledItems)
	{
	}

	virtual bool Keep(FStatMessage const& Item)
	{
		const FName MessageName = Item.NameAndInfo.GetRawName();
		if (EnabledItems.Num() > 0)
		{
			return EnabledItems.Contains(MessageName);
		}
		else
		{
			return false;
		}
	}
};

struct FSlateFilter : public IItemFilter
{
	FSlateFilter()
	{
	}

	virtual bool Keep(FStatMessage const& Item)
	{
		return Item.NameAndInfo.GetRawName().ToString().Contains("Slate");
	}
};
/**
 * 
 */
class KGUI_API FStatsThreadStateOverlay : public FStatsThreadState
{
public:
	int64 GetLastFullFrameProcessed() const
	{
		return LastFullFrameProcessed;
	}
};

#endif
