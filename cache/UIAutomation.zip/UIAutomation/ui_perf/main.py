import zipfile
import os
import shutil
import time
import subprocess
import pandas as pd
from datetime import datetime

from openpyxl import load_workbook

from auto.cases.test_check_in_scene import check_in_scene
from utils.docs import DocsApi
from utils.pc_log import get_crash_log, get_run_log
from utils.ci.jenkins import JenkinsExecutor
from utils.device.win.dev_mgr import WinMgr
from auto.cases.test_login import test_login
from auto.cases.test_create_character import test_create_character
from utils.notify.kim import Kim
from utils.log import get_logger
from utils.param import env, OSType
from ui_perf.csv2excel import csv2excel, csv2excel2
from ui_perf.redmine import issues_redmine, sub_sheet_redmine
from utils.lua.mgr import LuaMgr
from config import PROJ_DIR, get_log_name
from utils.cloud_server import  direct_restart
from utils.report import only_notify

logger = get_logger()
# TOKEN = "e41aa141-6c1c-4dfd-9cb0-afa7eb909d78"
# TOKEN = "872133de-21e8-4f80-8806-d13c12b5a7fb"
jenkins_runner = JenkinsExecutor()
TOKEN = "aa327785-71e5-4a56-9bb5-0515be4213ab" # 发到@张帅要求的群聊
TWO_TOKEN = "57bc95b9-a06f-43f9-8d72-5c17a1850546" # 发到UI性能自动化群聊
URL = "https://kim-robot.kwaitalk.com/api/robot/send?key="
URL_upload = 'https://kim-robot.kwaitalk.com/api/robot/upload?key='
CONTENT = "UI性能test"
SOURCE_FILE = os.path.join("lordofmysteries", "Saved", "UIProfile.csv")
FTP = r"\\172.31.141.230\share\QA\C7\report\client\ui_perf"
LOG = os.path.join("C7", "Saved", "Logs", get_log_name(OSType.WINDOWS))

DATA_TYPE = [
    "LayoutEnum", # 25-10-30新增，标记UI的类型(全/半屏)
    "UIName",
    "OpenTime",
    "UObjectNum",
    "TotalMemoryIncreaseOnOpen",
    "TotalMemoryDecreaseOnClose",
    "LuaMemoryIncreaseOnOpen",
    "LuaMemoryDecreaseOnClose",
    "UIMemoryIncreaseOnOpen",
    "UIMemoryDecreaseOnClose",
    "UObjectMemoryIncreaseOnOpen",
    "UObjectMemoryDecreaseOnClose",
    # UObjectsIncreaseRefByLua
    "TextureMemoryIncreaseOnOpen",
    "TextureMemoryDecreaseOnOpen",
    "AtlasNum",
    # Atlas(Count;Size)
    "TextureNum",
    # Texture
    # Error
    "SlateRTRendering",
    "SlateRTDrawBatches",
    "DrawWindowAndChildrenTime",
    "GameUIPaint",
    "TickWidgets",
    "SlatePrepass",
    "NumBatches",
    "NumVertices",
    "SlateOverDrawAvg",
    "SlateMaxOverDrawCount",
    "SlateOverDrawWithoutMTAvg",
    "SlateMaxOverDrawWithoutMTCount",
    "FontAssetCount_KGUI",
    "FontAssetMemory_Mib_KGUI",
    "FontTextureCount_KGUI",
    "FontTextureMemory_Mib_KGUI",
    "StaticAtlasCount_KGUI",
    "StaticAtlasMemory_Mib_KGUI",
    "DynamicAtlasCount_KGUI",
    "DynamicAtlasMemory_Mib_KGUI",
    "UnpackedTextureCount_KGUI",
    "UnpackedTextureMemory_Mib_KGUI"
]


def remove_folder(pkg_path):
    logger.info("删除文件")
    pkg_dir = os.path.join(pkg_path, "..")
    for root, dirs, files in os.walk(pkg_dir):
        os.chmod(root, 0o777)  # 修改文件夹权限
        for file in files:
            file_path = os.path.join(root, file)
            os.chmod(file_path, 0o777)  # 修改文件权限
    # 删除子文件夹和文件
    shutil.rmtree(pkg_dir)
    os.mkdir(pkg_dir)


def zipfile_unzip(pkg_path):
    logger.info("解压包体")
    unzip_path = os.path.splitext(pkg_path)[0]
    zip_ref = zipfile.ZipFile(pkg_path, "r")
    zip_ref.extractall(unzip_path)
    zip_ref.close()
    del zip_ref
    for root, dirs, files in os.walk(unzip_path):
        os.chmod(root, 0o777)  # 修改文件夹权限
        for file in files:
            file_path = os.path.join(root, file)
            os.chmod(file_path, 0o777)  # 修改文件权限
    logger.info(unzip_path)
    return unzip_path


def populate_ui():
    lua = LuaMgr()
    lua.connect()
    dev_mgr = env.dev_mgr
    ue = env.ue_driver
    # 升级
    # dev_mgr.cmd_ue("ExecGM SetLevel 39")
    lua.gm("SetLevel 39")
    time.sleep(2)
    # 解锁所有系统
    # dev_mgr.cmd_ue("ExecGM UnlockAllModule")
    lua.gm("`UnlockAllModule`")
    # 加好友
    # dev_mgr.cmd_ue("ExecGM GMAddFriend huj1,huj2,huj3,huj4,huj5,huj6,huj7,huj8,huj9")
    lua.gm("GMAddFriendslnDB")
    # 发宝箱
    # lua.gm("GMBatchAddItems 2000262 2000264 2000042 2000043 2000041 1")
    # 穿装备
    # dev_mgr.cmd_ue("ExecGM TestUSeItem 2 2000262 1")
    # dev_mgr.cmd_ue("ExecGM TestUSeItem 2 2000264 1")
    # dev_mgr.cmd_ue("ExecGM TestUSeItem 2 2000042 1")
    # dev_mgr.cmd_ue("ExecGM GMPutOnAllEquipIfCan")
    # lua.gm("TestUSeItem 2 2000262 1")
    # lua.gm("TestUSeItem 2 2000264 1")
    # lua.gm("TestUSeItem 2 2000042 1`")
    # lua.gm("TestUSeItem 2 2000043 1")
    # lua.gm("TestUSeItem 2 2000041 1")
    # while ue(text="点击空白处关闭").wait(5).exists():
    #     ue(text="点击空白处关闭").click()
    # lua.gm("GMPutOnAllEquipIfCan")
    # 加满材料
    # dev_mgr.cmd_ue("ExecGM AddAllMaterial")
    lua.gm("AddAllMaterial")
    # 加满伙伴
    # dev_mgr.cmd_ue("ExecGM AddAllFellow")
    lua.gm("AddAllFellow")
    # 加满背包
    # dev_mgr.cmd_ue("ExecGM GMNewBagAddItem 2000296 1999")
    lua.gm("GMNewBagAddItem 2000296 1999")
    # 俱乐部
    # dev_mgr.cmd_ue("ExecGM CreateGuild")
    # dev_mgr.cmd_ue("ExecGM BuildGuild")
    lua.gm("CreateGuild")
    lua.gm("BuildGuild")
    # 加满队友
    lua.gm("TeamAddAllMembers")
    lua.disconnect()


# 临时测试使用，检查为啥UI性能机器。经常出现lua连接错误
def check_port_usage(port):
    import psutil
    """检查端口占用情况并输出对应进程信息"""
    for conn in psutil.net_connections():
        if conn.laddr and conn.laddr.port == port:
            pid = conn.pid
            print(f"端口 {port} 被占用，PID = {pid}")

            try:
                proc = psutil.Process(pid)
                print(f"  进程名: {proc.name()}")
                print(f"  可执行文件: {proc.exe()}")
                print(f"  命令行: {' '.join(proc.cmdline())}")
            except Exception as e:
                print(f"  无法读取进程信息: {e}")

            print("-" * 50)
            return

    print(f"端口 {port} 未被占用。")
    print("-" * 50)


def check_ports():
    check_port_usage(20001)
    check_port_usage(20002)


def run_exe(unzip_path):
    exe_path = os.path.join(unzip_path, "Lord of Mysteries.exe")
    time.sleep(2)
    # sp = cmd_raw([exe_path, "-log", "-llm", "-UIAutomationProfile", "-SkipAllInSDK"])
    sp = subprocess.Popen([exe_path, "-llm -llmcsv", "-SkipAllInSdk"], stdin=subprocess.PIPE, shell=True,
                          cwd=unzip_path)

    time.sleep(20)
    env.dev_mgr = WinMgr()
    env.ue_driver = env.dev_mgr.ue_driver(title="Lord of Mysteries")
    env.ui_driver = env.dev_mgr.ui_driver(name="lordofmysteries")
    try:
        # account_name = "UIAutomationTest" + "".join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=5))
        account_name = "UIAutomationTest"
        if datetime.now().weekday() == 4:
            # 周五使用指定账号跑测
            account_name = "UIAutoTest"
        svr = "172.28.212.180:31625" # 云私服要和重启的云私服地址保持一致
        if not os.getenv("PKG_PATH", "") and int(env.ver) > 1:
            direct_restart("zhangtiancheng-ui-perf", "wb_zhangtiancheng05", env.ver)
        test_login(svr, account_name, "")
        logger.info("登录成功")
        test_create_character()
        lua = LuaMgr()
        lua.connect()
        check_in_scene(lua, 5200055)
        check_ports()
        logger.info("进入游戏场景成功")
        time.sleep(30)
        logger.info("填充UI数据成功")
        lua.console("ExecGM DoUIAutomationProfile")
        logger.info("执行gm成功")
    except:
        logger.exception("执行UI性能失败")
        logger.info("未走登入流程")
        raise Exception("执行UI性能失败")
    # dev = connect_device("Windows:///?title_re=诡秘之主.*")
    # try:
    #     pos = ocr_pos_wait("^同意$", 20)
    # except:
    #     logger.info("未找到同意按钮")
    #     pos = (1430, 920)
    # pyautogui.click(*pos)
    sp.wait(timeout=60 * 60 * 4)
    time.sleep(3)


def upload_ftp(src_path):
    # path, dirname = os.path.split(src_path)
    subprocess.Popen(f"xcopy {src_path} {FTP} /H/C").wait()


def get_data(path):
    df = pd.read_excel(path)

    def name_adjust(name):
        return name.replace(" ", "").replace(":", "")

    df = df.rename(columns=name_adjust)
    data_type = list(set(DATA_TYPE) & set(df.columns.tolist()))
    data = df[data_type].to_dict('records')
    return data


# def upload_manual():
#     for i in os.listdir(DATA_DIR):
#         path = os.path.join(DATA_DIR, i)
#         ver = i.split(".")[0]
#         data = get_data(path)
#         ver_time = get_ver_time(ver)
#         for j in data:
#             j["Version"] = ver
#             j["Time"] = ver_time
#         upload_data(data)  # 结果上传到db


def ui_perf_run(pkg_path, ver):
    try:
        docs = DocsApi()
        env.ver = ver = str(ver)
        pkg_abspath = os.path.abspath(pkg_path)
        breakpoint_pkg_path = os.getenv("PKG_PATH", "")
        env.unzip_path = unzip_path = breakpoint_pkg_path if breakpoint_pkg_path else zipfile_unzip(pkg_abspath)
        if breakpoint_pkg_path:
            env.ver = ver = breakpoint_pkg_path.split("_")[-1]
        env.os_type = OSType.WINDOWS
        run_exe(unzip_path)
        source_abspath = os.path.join(unzip_path, SOURCE_FILE)
        if not os.path.exists(source_abspath):
            # 没有生成csv文件，发消息到大群，并再执行一次
            ci_info = jenkins_runner.query_ci_job_info("PC_UI_Perf")
            last_stable_build_id = ci_info.get('lastSuccessfulBuild', {}).get('number')
            build_data = jenkins_runner.get_build_data("PC_UI_Perf", last_stable_build_id)
            now = datetime.now()
            midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
            if int(build_data['timestamp']) < int(midnight.timestamp() * 1000): # 如果上次运行是昨天，需要重启
                last_ci_pkg_path = None
            else: # 如果不是昨天，就根据上一次的pkg_path来判断
                last_ci_pkg_path = jenkins_runner.get_jenkins_parameter(build_data, 'PKG_PATH')
            if not last_ci_pkg_path:
                # 重启条件。1. 上一次成功是昨天  2. 上一次成功是今天，但是pkg为空
                jenkins_runner.run_ci("PC_UI_Perf", {
                    "PKG_PATH": unzip_path,
                    "VERSION": -1
                })
                only_notify(f"**UI性能自动化**\n测试版本：{ver}\n未生成csv文件，已重试", token="2e713f00-0534-4712-a43f-430856871614")
                return 
            get_crash_log(os_type=OSType.WINDOWS, base_dir=unzip_path)
            get_run_log(os_type=OSType.WINDOWS, base_dir=unzip_path)
            # 发到另外一个群，详情可咨询@张帅
            only_notify(f"**UI性能自动化**\n测试版本：{ver}\n未生成csv文件", username=['zhangshuai15'], token=TOKEN, is_send_files=True)
            # 发到UI性能自动化群
            only_notify(f"**UI性能自动化**\n测试版本：{ver}\n未生成csv文件", username=['zhangshuai15', 'zhangsuohao', 'wb_zhangtiancheng05'], token=TWO_TOKEN, is_send_files=True)
            raise Exception("未生成csv文件")
        target_abspath = source_abspath.replace("UIProfile", ver).replace("csv", "xlsx")
        target_abspath2 = source_abspath.replace("UIProfile", "SubSheet").replace("csv", "xlsx")
        logger.info(f"source_abspath: {source_abspath}")
        logger.info(f"target_abspath: {target_abspath}")
        logger.info(f"target_abspath2: {target_abspath2}")
        csv2excel(source_abspath, target_abspath)
        csv2excel2(source_abspath, target_abspath2)
        # upload_ftp(target_abspath)  # 结果上传到FTP
        data = get_data(target_abspath)
        for i in data:
            i["Version"] = ver
            i["Time"] = datetime.now()
        # upload_data(data)  # 结果上传到db
        # issues_redmine(data, UICONFIG_PATH, ver, 101553)  # 针对问题提单
        content = (f"UI性能自动化：PC-{ver}\n<@=username(zhangshuai15)=> <@=username(huangjinbao)=> <@=username(zhangsuohao)=> <@=username(wb_zhangtiancheng05)=>\n"
                   f"[趋势查看](https://qa2-admin.staging.kuaishou.com/grafana/d/TA0KH2ZNk/uixing-neng?orgId=1)")
        Kim.send_msg(content=content, token=TOKEN)
        Kim.send_msg(content=content, token=TWO_TOKEN)
        if os.path.exists(target_abspath):
            Kim.send_file(target_abspath, TOKEN)
            Kim.send_file(target_abspath, TWO_TOKEN)
        # 把分指标表格数据也发送出去
        if os.path.exists(target_abspath2):
            Kim.send_file(target_abspath2, TOKEN)
            Kim.send_file(target_abspath2, TWO_TOKEN)
            current_datetime = datetime.now()
            formatted_date = current_datetime.strftime("%Y-%m-%d")
            docs.excel_upload(f"SubSheet_{ver}_{formatted_date}.xlsx", target_abspath2, "wb_zhangtiancheng05", "VYxy2pzXynd8")
            # if current_datetime.weekday() == 4:
            #     # 提单新逻辑，周五才提单
            #     data_source = {}
            #     wb = load_workbook(target_abspath2)
            #     for sheet_name in wb.sheetnames:
            #         ws = wb[sheet_name]
            #         logger.info(f"=== Sheet: {sheet_name} ===")
            #         data_source[sheet_name] = []
            #         for row in ws.iter_rows(values_only=True):
            #             if "UIName" not in row:
            #                 data_source[sheet_name].append(row)
            #     sub_sheet_redmine(data_source)
        target_log = os.path.join(unzip_path, LOG)
        # print(target_log)
        if os.path.exists(target_log):
            Kim.send_file(target_log, TOKEN)
            Kim.send_file(target_log, TWO_TOKEN)
    except:
        logger.exception("ui_perf failed, please check!")
        # msg = f"ui_perf失败<@=username(wb_zhangtiancheng05)=>\n"
        # Kim.send_msg(msg, token="2e713f00-0534-4712-a43f-430856871614")
        k = Kim()
        k.send_mix_card_ue_auto_error(f"ui_perf", director="wb_zhangtiancheng05")
    # remove_folder(pkg_abspath)

if __name__ == '__main__':
    PKG_PATH = r"E:\project\Tools\QATools\ue_auto\pkg\C7_Windows_Development_509703"
    os.environ["PKG_PATH"] = PKG_PATH
    ui_perf_run(pkg_path=PKG_PATH, ver="526897")

