# coding=utf-8
import json
import os
import re
import subprocess
import time
from datetime import datetime

import pandas as pd
from openpyxl.reader.excel import load_workbook

from config import PROJ_DIR
from utils.P4_utils import p4cmd
from utils.redmine import RedmineRequest
from utils.log import get_logger
from utils.report import Kim
from utils.param import env
from utils.docs import DocsApi, revert_pd

logger = get_logger()


PANEL_AUTH = {
}

P4RED = {
}


UI_WHITELIST = [
    # qusicheng03 为了送审做的，功能之后都要重做
    "P_Recharge",
    # shijingzhe 纯UObject相关的增长非常少, 不确定是全屏UI触发了什么东西
    "P_BlackMask",
    # chengxu 临时测试页面目前不用
    "P_DLCPanel",
    # yechengying 老装备界面，后面不用了
    "P_Equipment",
    "P_EquipmentEntry",
    # 重构 tianjia
    "P_MailDetail",
    # tianjia 要删掉
    "P_SequenceScence",
    "P_SequenceReason",
    # zhangyoujun 废弃
    "P_RankMain",
    # liuruilin GM面板,不是正式运行时的内容
    "P_GMCombatData"
]

# UI布局枚举类型为：1-普通界面，2-全屏，3-半透浮窗全屏，4-左半屏，5-右半屏，6-提示框
"""
提单标准：
1. key为需要检查的列，值为筛选条件
2. 列表中的元组，第一个值为，UI布局类型，第二个值为阈值
以SlateOverDrawAvg为例。
则UI类型为4,5的，SlateOverDrawAvg值超过2.5则提单
UI类型为2,3的，SlateOverDrawAvg值超过9则提单
"""
UI_PERF_IND = {
    "SlateOverDrawAvg": [("4,5", 2.5),("2,3", 9)]
}

QA_NAME = "wb_zhangtiancheng05"  # 默认QA同学
QA_ID = 1198  # 默认QA同学redmine id
PARENT_REDMINE_ID = 101553
UICONFIG_PATH_CLIENT = "//C7/Development/Mainline/Client/Content/Script/Data/Config/UIConfig/UIPanelConfig.lua"
UICONFIG_PATH = os.path.join(PROJ_DIR, r"Client\Content\Script\Data\Config\UIConfig\UIPanelConfig.lua")
SHEET_COSMO_ID = "fcAAqRNl8wIWSLlfhTcwBxHvz"
SHEET_INDEX_ID = 0
docs = DocsApi()


def is_exists_redmine(ui_name, sheet_name):
    redmine_request = RedmineRequest()
    all_open_redmine = redmine_request.get_filtered_issues({
        "status_id": "29|7|10|44|31",  # 包含 未开始&进行中&完成待测试&完成并自测，转QA测试
        "parent_id": PARENT_REDMINE_ID
    })
    is_exists = False
    for open_redmine in all_open_redmine:
        desc = open_redmine['description']
        subject = open_redmine['subject']
        if ui_name in desc and sheet_name in subject:
            is_exists = True
            break
    return is_exists


def get_auth(key_prefix):
    p4cmd(f"p4 sync {UICONFIG_PATH_CLIENT}")
    with open(UICONFIG_PATH, 'r', encoding='utf-8') as file:
        lua_content = file.readlines()
    for line_index in range(len(lua_content)):
        # 在UIPanelConfig内，替换key
        is_break = False
        if lua_content[line_index].strip() == "UIPanelConfig = {":
            # 搜索是否存在需要将UI替换的情况
            while lua_content[line_index].strip() != "}":
                line_index += 1
                if key_prefix in lua_content[line_index] and " = " in lua_content[line_index]:
                    key_prefix = lua_content[line_index].strip().split(" = ")[0]
                    is_break = True
                    break
        if is_break:
            break

    ui_name_submitter_config = []
    for line_index in range(len(lua_content)):
        if "PanelConfig = {" == lua_content[line_index].strip():
            ui_name_submitter_config = lua_content[line_index:]
            break
    # 在PanelConfig中根据对应的UIName找到对应的auth
    for line_index in range(len(ui_name_submitter_config)):
        if f"{key_prefix}]" in ui_name_submitter_config[line_index]:
            # 找到该UI对应的配置文件块了
            for target_submitter_line in ui_name_submitter_config[line_index + 1:line_index + 30]:
                if "[UIPanelConfig." in target_submitter_line:
                    # 该代码段结束的标志
                    return  QA_NAME
                if "auth" in target_submitter_line:
                    match = re.search(r'auth\s*=\s*"([^"]+)"', target_submitter_line)
                    if match:
                        name = match.group(1)
                        return name
                    return QA_NAME
    return QA_NAME


def cmd_exec(cmd_line):
    if isinstance(cmd_line, list):
        cmd_line = " ".join(cmd_line)
    return subprocess.Popen(cmd_line, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def get_users():
    cmd = "p4 users"
    ret = cmd_exec(cmd).communicate()[0]
    items = ret.decode("utf-8").splitlines()
    users = {}
    for i in items:
        item = i.split(" ")
        users[item[0]] = item[2][1:-1]
    return users


def check_performance_metrics(ui_profile, config_dir):
    ret = {}
    ins = RedmineRequest()
    p4_users = get_users()
    for metrics in ui_profile:
        exceeded_info = []
        ui_name = metrics["UIName"]
        if ui_name in UI_WHITELIST:
            logger.info(f"{ui_name} 在白名单跳过检查")
            continue
        
        # 通过UI_PERF_IND开单，无需修改代码，只需在其中增加对应指标和阈值即可
        for ui_perf_standard_key in UI_PERF_IND.keys(): # 需要开单的指标
            if ui_perf_standard_key in metrics.keys(): # 确保该行数据存在
                for ui_type in UI_PERF_IND[ui_perf_standard_key]:
                    current_ui_type = str(metrics['LayoutEnum'])
                    current_compare_value = metrics[ui_perf_standard_key]
                    if current_ui_type in ui_type[0]: # UI类型匹配
                        current_max_value = ui_type[1]
                        if current_compare_value >= current_max_value: # 比较阈值
                            exceeded_info.append(f"UIName：{ui_name} 其中 {ui_perf_standard_key}({current_compare_value}) 超过了 阈值({current_max_value}) ")
                            break
        
        if exceeded_info:
            exceeded_info_str = "\n".join(exceeded_info)
            submitter = get_auth(ui_name)
            if submitter in P4RED.keys():
                submitter = P4RED[submitter]
            if submitter in p4_users:
                submitter = p4_users[submitter]
            submitter_id = ins.get_user_id_by_name(submitter)
            if submitter_id is None:
                submitter_id = QA_ID
            if submitter_id not in ret.keys():
                ret[submitter_id] = []
            ret[submitter_id].append(exceeded_info_str)
    return ret


# 通过redmine单主题获取责任人id
def subject_id(subject):
    try:
        ret = re.search("\(ID:(.*?)\)", subject)
        if ret:
            return int(ret.group(1))
    except:
        return -1
    return -1


def issues_redmine(ui_profile, config_dir, vcs_ver, parent_id):
    vcs_ver = str(vcs_ver)
    issues = check_performance_metrics(ui_profile, config_dir)
    ins = RedmineRequest()
    filter_param = {
        "status_id": "29|7|10|44|31",  # 包含 未开始&进行中&完成待测试&完成并自测，转QA测试
        "parent_id": parent_id  # 需修改母单
    }
    redmine_issues = ins.get_filtered_issues(filter_param)
    # 有单子但没有问题，代表问题已修复，关闭单子
    for i in redmine_issues:
        # submitter_id = i["assigned_to"]["id"]
        submitter_id = subject_id(i["subject"])
        if submitter_id == -1:
            continue
        if int(submitter_id) not in issues.keys():
            logger.info(f"{submitter_id}无问题关单")
            if i["status"]["id"] == 44:
                config = {
                    "issue": {
                        "status_id": 9  # 关闭
                    }
                }
            else:
                config = {
                    "issue": {
                        "status_id": 15  # 废弃
                    }
                }
            ins.update_redmine_issue(i["id"], config)
    for k, v in issues.items():
        redmine_exist = False
        for j in redmine_issues:
            # 问题有对应人的单子则不重复提，而是更新单子
            # if k == j["assigned_to"]["id"]:
            if k == subject_id(j["subject"]):
                redmine_exist = True
                cl_18 = 0
                for field in j["custom_fields"]:
                    if field["name"] == '修复版本':
                        cl_18 = field["value"]
                        break
                if j["status"]["id"] == 44 and int(cl_18) > int(vcs_ver):
                    break
                config = {
                    "issue": {
                        "priority_id": 4,  # 默认优先级P1
                        "status_id": 29,  # 未开始
                        "description": "\n".join(v),
                        "custom_fields": [
                            {"id": 13, "value": vcs_ver},
                        ]
                    }
                }
                if j["status"]["id"] != 29 and j["status"]["id"] != 35:
                    config["issue"]["status_id"] = 7
                ins.update_redmine_issue(j["id"], config)
                break
        # 问题没有对应人的单子，则新提单
        if not redmine_exist:
            issue_config = {
                "issue": {
                    "project_id": 8,  # 默认C7项目
                    "assigned_to_id": k,  # 指派人：需要传入
                    "tracker_id": 75,  # 默认跟踪类型 *程序自主任务
                    "status_id": 29,  # 默认状态 未开始
                    "fixed_version_id": ins.get_fixed_version_id(),
                    # 目标版本 需要传入 https://c7-game-redmine.corp.kuaishou.com/projects/c7/settings/versions
                    "priority_id": 4,  # 默认优先级P1
                    "subject": "UI性能数据超标(ID:%s)" % k,  # 主题
                    "description": "\n".join(v),  # 描述
                    "category_id": 47,
                    # 默认分类 https://c7-game-redmine.corp.kuaishou.com/projects/c7/settings/categories
                    "parent_issue_id": parent_id,  # 默认母单 101553
                    "custom_fields": [
                        {"id": 23, "value": "提交到主干"},  # 默认提交主干
                        # {"id": 13, "value": vcs_ver},  # 发现版本
                        {'id': 3, "value": QA_ID},  # 跟进QA
                    ]
                }
            }
            ins.create_redmine_issue(issue_config)


def subsheet_redmine_data_clean(data_source):
    # 将UI的auth汇总到一起
    new_data_source = {}
    for sheet_name in data_source.keys():
        current_sheet_name = new_data_source[sheet_name] = {}
        for item in data_source[sheet_name]:
            auth = get_auth(item[0])
            current_auth = current_sheet_name.get(auth, [])
            current_auth.append(item)
            current_sheet_name[auth] = current_auth
    return new_data_source


def get_description(data, sheet_name):
    tail_map = {
        "UObjectsIncreaseRefByLua": "泄露",
        "Error": "抛错",
    }
    tail_text = tail_map.get(sheet_name, "超标")
    desc = f"以下UIName {sheet_name} {tail_text}\n\n"
    for item in data:
        for sub_item in item:
            desc += f"\t{sub_item}"
        desc += "\n"
    return desc


def create_redmine(blame, data, sheet_name, write_xlsx):
    ins = RedmineRequest()
    submitter_id = ins.get_user_id_by_name(blame)
    if not submitter_id:
        Kim.send_msg("无效的提交人：%s" % blame)
        return
    today = datetime.fromtimestamp(int(time.time()))
    res = ins.create_redmine_issue(issue_config={
        "issue": {
            "project_id": 8,  # 默认C7项目
            "assigned_to_id": submitter_id,  # 指派人
            "tracker_id": 4,  # 默认跟踪类型 *BUG
            "status_id": 7,  # 默认状态 进行中
            "fixed_version_id": ins.get_target_week_version(1 if today.weekday() == 3 else 0),
            "priority_id": 3,  # 默认优先级P2
            "subject": f"【UI性能数据超标】【{sheet_name}】- owner({blame})",  # 主题
            "description": get_description(data, sheet_name),
            "category_id": 47,
            "parent_issue_id": PARENT_REDMINE_ID,
            "custom_fields": [
                {"id": 23, "value": "提交到主干"},  # 默认提交主干
                {'id': 3, "value": QA_ID},  # 跟进QA
                {"id": 13, "value": env.ver}  # 发现版本
            ]
        }
    })
    res = res.json()
    if res.get("issue", None):
        for item in data:
            write_xlsx.append([item[0], f"{sheet_name}({item[1]})", res['issue']['id']])


def get_docs_data():
    ins = RedmineRequest()
    docs.get_max_row_and_col(SHEET_COSMO_ID, SHEET_INDEX_ID)
    docs_content = docs.get_cells_data(SHEET_COSMO_ID, SHEET_INDEX_ID, data_range=f"R2C1:{docs.max_sheet_range}")
    docs_content = revert_pd(docs_content, ["UI名称", "超标情况", "单号", "额外参数", "是否完成", "优化后数据"])
    for index, row in docs_content.iterrows():
        if row['是否完成'] is None or pd.isna(row["是否完成"]):
            # 需要获取状态
            redmine_info = ins.get_issue(row["单号"])
            if redmine_info['status']['id'] == 9:
                docs_content.loc[index, '是否完成'] = '已完成'
    return docs_content


def get_form(cell_pos, col_index, item):
    form = {
        "rangeForm": {
            "range": f"{SHEET_INDEX_ID}!{cell_pos}:{cell_pos}",
            "ifR1C1Range": "true",
            "ifSheetId": "false"
        },
        "cellValue": {
            "type": "STRING",
            "value": item,
        }
    }
    if col_index == 3:
        # 设置超链接样式
        form['cellValue'] = {
            "type": "HYPERLINK",
            "value": item,
            "hyperlink": f"https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/{item}"
        }
    return form


def sub_sheet_redmine(data_source):
    write_xlsx = []
    un_auth = []
    bath_write_cell = []
    white_sheet_name = [] # 暂不提单类型
    for sheet_name in data_source.keys():
        if sheet_name in white_sheet_name:
            continue
        for blame in data_source[sheet_name].keys():
            if blame == QA_NAME:
                un_auth.extend(data_source[sheet_name][blame])
            create_redmine(blame, data_source[sheet_name][blame], sheet_name, write_xlsx)
    if un_auth:
        msg = "以下UIName未找到Auth"
        msg += "\n" + "\n".join([ui_item[0] for ui_item in un_auth])
        logger.error(msg)
        Kim.send_msg(msg, "2e713f00-0534-4712-a43f-430856871614")
    next_line_row = 2
    # 获取云文档的数据
    exists_redmine_data = get_docs_data()
    # 清空云文档
    version = docs.get_sheet_meta_data(SHEET_COSMO_ID)['revision']
    docs.delete_row_ranks(SHEET_COSMO_ID, version, len(exists_redmine_data), sheet_index=SHEET_INDEX_ID)
    # 将本次新开的单子，写入到云文档
    for row_index, line in enumerate(write_xlsx, 2):
        next_line_row = row_index
        for col_index, item in enumerate(line, 1):
            cell_pos = f"R{row_index}C{col_index}"
            bath_write_cell.append(get_form(cell_pos, col_index, item))
    exists_redmine_data = exists_redmine_data.sort_values(by="是否完成", na_position="first")
    # 将云文档中的记录更新后，再写回云文档
    for line_index, line in exists_redmine_data.iterrows():
        next_line_row += 1
        for col_index, col in enumerate(line, 1):
            if pd.isna(col) or col is None:
                continue
            cell_pos = f"R{next_line_row}C{col_index}"
            bath_write_cell.append(get_form(cell_pos, col_index, col))
    version = docs.get_sheet_meta_data(SHEET_COSMO_ID)['revision']
    docs.batch_edit_cell(SHEET_COSMO_ID, version, bath_write_cell)
    

if __name__ == '__main__':
    data_source = {}
    wb = load_workbook(r"D:\Kim Cache\Kim file\2026-01\SubSheet.xlsx")
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        logger.info(f"=== Sheet: {sheet_name} ===")
        data_source[sheet_name] = []
        for row in ws.iter_rows(values_only=True):
            if "UIName" not in row:
                data_source[sheet_name].append(row)
    sub_sheet_redmine(subsheet_redmine_data_clean(data_source))
