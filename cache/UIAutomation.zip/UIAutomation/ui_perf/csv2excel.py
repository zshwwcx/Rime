import os.path

import pandas as pd
import xlsxwriter
from PIL import Image
import io

# 从csv生成完整的excel
def csv2excel(source_file_path, target_file_path):
    df = pd.read_csv(source_file_path, index_col=False)

    workbook = xlsxwriter.Workbook(target_file_path)
    worksheet = workbook.add_worksheet()

    column_headers = df.columns.tolist()
    for col_num, header in enumerate(column_headers):
        header = header.strip(" ").replace(" ", "")
        header = header.replace("/", "_")
        header = header.replace("(KGUI)", "_KGUI")
        worksheet.write(0, col_num, header)

    red_format = workbook.add_format({'bg_color': '#FFC7CE'})
    default_row_height_points = 15

    for row_num, (index, row) in enumerate(df.iterrows(), start=1):
        row_height_points = default_row_height_points
        for col_num, cell_value in enumerate(row):
            if col_num == df.columns.get_loc('ScreenShot') and pd.notnull(cell_value):
                if type(cell_value) == str:
                    if os.path.exists(cell_value):
                        image = Image.open(cell_value)
                        if image.mode == 'RGBA':
                            image = image.convert('RGB')
                        image_width_px, image_height_px = image.size
                        column_width_chars = max(column_headers[col_num].__len__(), int(image_width_px / 70))
                        row_height_points = int(image_height_px / 72 * 6)
                        
                        worksheet.set_column(col_num, col_num, column_width_chars)
                        worksheet.set_row(row_num, row_height_points)
        
                        with io.BytesIO() as output:
                            image.save(output, format='JPEG', quality=30)
                            image_data = output.getvalue()
        
                        worksheet.insert_image(row_num, col_num, 'image.jpg', {
                            'image_data': io.BytesIO(image_data),
                            'x_scale': 0.1, 
                            'y_scale': 0.1, 
                        })
            elif col_num == df.columns.get_loc('Overdraw') and pd.notnull(cell_value):
                if type(cell_value) == str:
                    image = Image.open(cell_value)
                    if image.mode == 'RGBA':
                        image = image.convert('RGB')
                    image_width_px, image_height_px = image.size
                    column_width_chars = max(column_headers[col_num].__len__(), int(image_width_px / 70))
                    row_height_points = int(image_height_px / 72 * 6)

                    worksheet.set_column(col_num, col_num, column_width_chars)
                    worksheet.set_row(row_num, row_height_points)
                    
                    with io.BytesIO() as output:
                        image.save(output, format='JPEG', quality=30)
                        image_data = output.getvalue()

                    worksheet.insert_image(row_num, col_num, 'image.jpg', {
                        'image_data': io.BytesIO(image_data),
                        'x_scale': 0.1, 
                        'y_scale': 0.1, 
                    })
            elif col_num == df.columns.get_loc('OpenTime(Ms)') and pd.notnull(cell_value):
                if int(cell_value) >= 5000:
                    cell_value = "超时"
                if pd.isnull(cell_value):
                    worksheet.write(row_num, col_num, "")
                else:
                    worksheet.write(row_num, col_num, cell_value)
            else:
                column_width_chars = column_headers[col_num].__len__()
                if isinstance(cell_value, str):
                    column_width_chars = max(column_headers[col_num].__len__(), cell_value.__len__())
                worksheet.set_column(col_num, col_num, column_width_chars)
                if pd.isnull(cell_value):
                    worksheet.write(row_num, col_num, "")
                else:
                    worksheet.write(row_num, col_num, cell_value)
            if col_num == df.columns.get_loc('Error') and pd.notnull(cell_value):
                worksheet.set_row(row_num, row_height_points, red_format)
                worksheet.write(row_num, col_num, cell_value)
        row_num += 1

    workbook.close()
    

# 独立分表数据， 1表示降序，0表示升序
CSV2_SHEET_LIST = {
    "OpenTime(Ms)" : {"des_sort" :1, "top_num":10, "filter_threshold_min": 300, "filter_threshold_max": 5000}, # 打开时间
    "LuaMemoryIncreaseOnOpen" : {"des_sort" :1, "top_num":10, "filter_threshold_min": 2}, # 内存增长
    "UObjectNum" : {"des_sort" :1, "top_num":15, "filter_threshold_min": 1000, "show_list": ["UObjectNum", "UObjects Created"]}, # UObject数量
    "AtlasNum" : {"des_sort" :1, "top_num":15, "filter_threshold_min": 2, "show_list": ["AtlasNum", "Atlas"]}, # 图集数量
    "TextureNum": {"des_sort" :1, "top_num":15, "filter_threshold_min": 10, "show_list": ["TextureNum", "Texture"]}, # 散图数量
    "Num Batches" : {"des_sort" :1, "top_num":15, "filter_threshold_min": 30}, # DrawCall数量
    "SlateOverDrawAvg" : {"des_sort" :1, "top_num":15, "filter_threshold_min": 3}, # OverDraw
    "AvgFPS" : {"des_sort" :0, "top_num":10, "filter_threshold_max": 60}, # 帧率 
    "LuaMemoryIncreaseOnClose": {"des_sort": 1, "top_num": 10, "filter_threshold_min": 1},  # 内存泄露总量
    "UObjectsIncreaseRefByLua" : {"des_sort" :1}, # UObject是否有泄露
    "Error" : {"des_sort" : 1}, # 是否有抛错
}

# 针对单个UI的独立指标， 当指标大于filter_threshold_min || 小于filter_threshold_max的时候，该UI会被认为是符合预期的.
CSV2_SINGLE_UI_FILTER_LIST = {
    # 测试样例 #
    # "PVPReady_Panel" : {"OpenTime(Ms)" : {"filter_threshold_max": 1610}, "UObjectNum": {"filter_threshold_max": 4000}},
    # "TaskAcceptPanel": {"UObjectNum": {"filter_threshold_max": 3120}},
}
    
# 从csv提取关键指标数据，降序排列，生成独立分表
def csv2excel2(source_file_path, target_file_path):
    df = pd.read_csv(source_file_path, index_col=False)
    workbook = xlsxwriter.Workbook(target_file_path)
    
    for sheet_name, profile_dict in CSV2_SHEET_LIST.items():
        worksheet = workbook.add_worksheet(sheet_name)
        # 填写表头
        worksheet.write(0, 0, "UIName")
        if not 'show_list' in profile_dict.keys():
            worksheet.write(0, 1, sheet_name)
        else:
            for index, value in enumerate(profile_dict['show_list']):
                worksheet.write(0, index + 1, value)
        
        # 拉长点表头间距
        worksheet.set_column(0, 0, 30)
        worksheet.set_column(1, 1, sheet_name.__len__())

        filtered_df = df
        # 筛选值下限
        if profile_dict.get('filter_threshold_min', None) is not None:
            filtered_df = filtered_df[filtered_df[sheet_name] > profile_dict['filter_threshold_min']]
        # 筛选值上限
        if profile_dict.get("filter_threshold_max", None) is not None:
            filtered_df = filtered_df[filtered_df[sheet_name] < profile_dict['filter_threshold_max']]
        # 剔除掉Error Sheet中的空字符串
        if sheet_name in ["Error", "UObjectsIncreaseRefByLua"]:
            filtered_df = filtered_df[filtered_df[sheet_name].isna() == False]
            
        # 排序
        sorted_df = filtered_df.sort_values(by=sheet_name, ascending=(profile_dict.get("des_sort", 0) == 0))
        
        # 输出排序内容
        cur_index = 1
        for row_num, (index, row) in enumerate(sorted_df.iterrows(), start=1):
            
            if cur_index > profile_dict.get("top_num", 10):
                break
            
            ui_name = row["UIName"]
            cell_value = row[sheet_name]
            # TODO: 判断下该UI是否在白名单指标内，以及是否可进入top列表
            if CSV2_SINGLE_UI_FILTER_LIST.get(ui_name, None) is not None:
                # 指标名
                UI_VALUES = CSV2_SINGLE_UI_FILTER_LIST.get(ui_name, None).get(sheet_name, None)
                if UI_VALUES is not None:
                    threshold_min = UI_VALUES.get("filter_threshold_min", None)
                    if threshold_min is not None:
                        if cell_value > threshold_min:
                            continue
                    threshold_max = UI_VALUES.get("filter_threshold_max", None)
                    if threshold_max is not None:
                        if cell_value < threshold_max:
                            continue
                
            worksheet.write(cur_index, 0, ui_name)
            if not 'show_list' in profile_dict.keys():
                if pd.isnull(cell_value):
                    worksheet.write(cur_index, 1, "")
                else:
                    worksheet.write(cur_index, 1, cell_value)
            else:
                for index, value in enumerate(profile_dict['show_list']):
                    cell_value = row[value]
                    if pd.isnull(cell_value):
                        worksheet.write(cur_index, index + 1, "")
                    else:
                        worksheet.write(cur_index, index + 1, cell_value)
                        
            cur_index += 1

    workbook.close()

if __name__ == '__main__':
    # csv2excel(r".\csv\UIProfile.csv", r".\csv\output.xlsx")
    csv2excel2(r".\csv\UIProfile.csv", r".\csv\output2.xlsx")
