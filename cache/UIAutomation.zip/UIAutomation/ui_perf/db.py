from sqlalchemy import create_engine, Column, BigInteger, Integer, Float, String, DateTime
from sqlalchemy.orm import DeclarativeBase, scoped_session, sessionmaker


SQL_INFO = 'mysql+pymysql://grafana:Ztest_2122@172.28.204.58:3306/grafana'
engine = create_engine(SQL_INFO)

db_session = scoped_session(
    sessionmaker(
        autoflush=False,
        bind=engine
    )
)


class Base(DeclarativeBase):
    pass


class UIPerf(Base):
    __tablename__ = "ui_perf"
    ID = Column(BigInteger, autoincrement=True, primary_key=True)
    Version = Column(String(50), index=True)  # 版本号
    Time = Column(DateTime)
    UIName = Column(String(100), index=True)
    OpenTime = Column(Float)
    UObjectNum = Column(Integer)
    TotalMemoryIncreaseOnOpen = Column(Float)
    TotalMemoryDecreaseOnClose = Column(Float)
    LuaMemoryIncreaseOnOpen = Column(Float)
    LuaMemoryDecreaseOnClose = Column(Float)
    UIMemoryIncreaseOnOpen = Column(Float)
    UIMemoryDecreaseOnClose = Column(Float)
    UObjectMemoryIncreaseOnOpen = Column(Float)
    UObjectMemoryDecreaseOnClose = Column(Float)
    # UObjectsIncreaseRefByLua
    TextureMemoryIncreaseOnOpen = Column(Float)
    TextureMemoryDecreaseOnOpen = Column(Float)
    AtlasNum = Column(Integer)
    # Atlas(Count;Size)
    TextureNum = Column(Integer)
    # Texture
    # Error
    SlateRTRendering = Column(Float)
    SlateRTDrawBatches = Column(Float)
    DrawWindowAndChildrenTime = Column(Float)
    GameUIPaint = Column(Float)
    TickWidgets = Column(Float)
    SlatePrepass = Column(Float)
    NumBatches = Column(Integer)
    NumVertices = Column(Integer)
    SlateOverDrawAvg = Column(Float)
    SlateMaxOverDrawCount = Column(Float)
    SlateOverDrawWithoutMTAvg = Column(Float)
    SlateMaxOverDrawWithoutMTCount = Column(Float)
    FontAssetCount_KGUI = Column(Float)
    FontAssetMemory_Mib_KGUI = Column(Float)
    FontTextureCount_KGUI = Column(Float)
    FontTextureMemory_Mib_KGUI = Column(Float)
    StaticAtlasCount_KGUI = Column(Float)
    StaticAtlasMemory_Mib_KGUI = Column(Float)
    DynamicAtlasCount_KGUI = Column(Float)
    DynamicAtlasMemory_Mib_KGUI = Column(Float)
    UnpackedTextureCount_KGUI = Column(Float)
    UnpackedTextureMemory_Mib_KGUI = Column(Float)


def create_table():
    Base.metadata.create_all(bind=engine)


def upload_data(data):
    items = []
    for i in data:
        items.append(UIPerf(**i))
    db_session.add_all(items)
    db_session.commit()


if __name__ == '__main__':
    create_table()
    # upload_data([{"Version": 1, "UIName": "test", "SlateOverDrawAvg": -1}])
