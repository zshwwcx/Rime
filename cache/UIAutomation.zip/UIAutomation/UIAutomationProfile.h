// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "KGUI/Public/Profiling/KGUMGMemorySnapshot.h"
#include "KGUI/Public/Profiling/KGMemoryStatisticsTree.h"
#include "KGUI/Public/Profiling/KGMemoryStatisticsTreeAnalyser.h"
#include "Blueprint/GameViewportSubsystem.h"
#include "Core/Common.h"
#include "UObject/UObjectArray.h"
#include "NiagaraSystemWidget.h"
#include "NiagaraUIComponent.h"
#include "NiagaraSystem.h"
#include "KGSprite.h"
#include "KGSpriteAtlas.h"
#include "C7/AutomationProfile/SKGUIAutomationProfileWidget.h"
#include "UIAutomationProfile.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogUIAutomationProfile, Log, All);


struct FUIObjectInfo
{
	FString ClassName;
	FName ObjectName;
	int32 ObjectIndex;
};


class FUIAutomationObjListener : public FUObjectArray::FUObjectCreateListener, public FUObjectArray::FUObjectDeleteListener
{
public:

	bool bListening = true;
	
	TArray<FUIObjectInfo*> CreatedObjects;
	TArray<FUIObjectInfo*> DeletedObjects;
	
	virtual void NotifyUObjectCreated(const class UObjectBase* Object, int32 Index) override;
	virtual void NotifyUObjectDeleted(const class UObjectBase* Object, int32 Index) override;
	FORCEINLINE virtual void OnUObjectArrayShutdown() override;
	
	void Init();

	void CleanArrayList();

	void OnUIOpened();

	void OnUIClosed();
	
	FCriticalSection CriticalSection;
};

USTRUCT()
struct FUIProfileData
{
	GENERATED_BODY()

	FName Name;
	double Time = .0f;
	int32 LayoutEnum = 0;
	int32 UObjectNum = 0;
	int32 NiagaraWidgetNum = 0;
	int32 NiagaraEmitterNum = 0;
	float TotalTrackedMemoryBefore = .0f;
	float TotalTrackedMemoryOnShow = .0f;
	float TotalTrackedMemoryOnClose = .0f;
	float LuaMemoryBefore = .0f;
	float LuaMemoryOnShow = .0f;
	float LuaMemoryOnClose = .0f;
	float UIMemoryBefore = .0f;
	float UIMemoryOnShow = .0f;
	float UIMemoryOnClose = .0f;
	float UObjectMemoryBefore = .0f;
	float UObjectMemoryOnShow = .0f;
	float UObjectMemoryOnClose = .0f;
	float TextureMemoryBefore = .0f;
	float TextureMemoryOnShow = .0f;
	float TextureMemoryOnClose = .0f;
	TSet<FString> DependenceAtlasSet;
	TSet<FString> DependenceTextureSet;
	TMap<FString, TPair<FString, double>> SlateStatValueArray;
	FString Error;
	FString ScreenShotPath;
	FString OverdrawScreenShotPath;
	TSet<FString> UObjectsLuaBefore;
	TArray<FString> UObjectsLuaAdd;
	TArray<FString> UObjectsWhiteList;
	float SlateOverDrawAvg = .0f; 
	float SlateMaxOverDrawCount = .0f;
	float SlateOverDrawWithoutMTAvg;
	float SlateMaxOverDrawWithoutMTCount;

	FKGMemoryStatisticsTreeAnalyser AnalyserBeforeOpen;
	FKGMemoryStatisticsTreeAnalyser Analyser;

	TMap<FString, int32> CreatedObjMap;
	TMap<FString, int32> DeletedObjMap;

	TArray<TPair<FString, int32>> CreatedObjArrays;
	TArray<TPair<FString, int32>> DeletedObjArrays;

	int32 FPSCount;
	float AvgFPS;
};
/**
 * 
 */
UCLASS(BlueprintType)
class KGUI_API UUIAutomationProfile : public UObject
{
	GENERATED_BODY()
	
public:
	UFUNCTION(BlueprintCallable)
	void Init(bool bQuitWhenFinish);
	
	UFUNCTION(BlueprintCallable)
	void StartSingleUIProfile(FString& UIName, float LuaMemory, TArray<FString> UObjectsWhiteList);

	UFUNCTION(BlueprintCallable)
	void OnSingleUIOpened(UUserWidget* Widget, FString WbpName, float LuaMemory, int OpenTimeMS = 0, int LayoutEnum = 0);

	UFUNCTION(BlueprintCallable)
	void OnSingleUIClosed(float LuaMemory);

	UFUNCTION(BlueprintCallable)
	void AddDependenceTextureName(FString TextureName);

	UFUNCTION(BlueprintCallable)
	void StartCollectSlateStatData(int32 Count);

	UFUNCTION(BlueprintCallable)
	void UpdateFPS(float DeltaTime);

#if STATS
	void DumpStatStackNode(struct FRawStatStackNode* Root);
	void ProcessStatValue(FStatMessage Item);
#endif

	UFUNCTION(BlueprintCallable)
	void TakeSnapShot();

	UFUNCTION(BlueprintCallable)
	void TakeSnapShotOverdraw();

	UFUNCTION(BlueprintCallable)
	void GetOverDrawData(int32 Count);

	UFUNCTION(BlueprintCallable)
	void CollapseMaterialForOverDrawCheck(UUserWidget* Widget);

	UFUNCTION(BlueprintCallable)
	void GetOverDrawDataWithOutMaterial();

	UFUNCTION(BlueprintCallable)
	void GetKGMemoryStatisticsTreeAnalyserBeforeUIOpen();

	UFUNCTION(BlueprintCallable)
	void GetKGMemoryStatisticsTreeAnalyser(FString WbpName);

	UFUNCTION()
	bool RecursivelyCheckNiagaraSystemWidget(UUserWidget* UserWidget, int32& NiagaraWidgetNum, int32& NiagaraEmitterNum);

	UFUNCTION(BlueprintCallable)
	void ReportError(FString Error);

	UFUNCTION(BlueprintCallable)
	void ExportCSV();

	FString CurTestUIName;

	UFUNCTION(BlueprintCallable)
	void ForceGarbageCollection();

	void dumpUObjectsLuaBefore();
	void dumpUObjectsLuaAdd();

	// add by fanggang for material profile
	UFUNCTION(BlueprintCallable)
	static int32 GetCurrentBatches();
	UFUNCTION(BlueprintCallable)
	static int32 GetCurrentFPS();
	UFUNCTION(BlueprintCallable)
	static float GetGameDelta();
	UFUNCTION(BlueprintCallable)
	static float GetRenderDelta();
	UFUNCTION(BlueprintCallable)
	static float GetGPUDelta();
	UFUNCTION(BlueprintCallable)
	static float GetBatteryCurrent();
	UFUNCTION(BlueprintCallable)
	static float GetBatteryVoltage();
	UFUNCTION(BlueprintCallable)
	static float GetBatteryTemperature();
	UFUNCTION(BlueprintCallable)
	static float GetBatteryLevel();
	UFUNCTION(BlueprintCallable)
	static float GetCpuFrequency();
	UFUNCTION(BlueprintCallable)
	static TArray<FString> FindMaterialsByName(const FString& SearchText, bool bExactMatch = false);

	// 析构函数中清理资源
	virtual void BeginDestroy() override;

	void Release();

	void ShowResultWindow();
	
private:
	bool bEnabled = false;
	double StartTime;
	TArray<FString> SlateStatNameArray;
	TArray<FUIProfileData> UIProfileDataArray;
	FUIProfileData TempUIProfileData;

	FUIAutoItem UIAutoItem;
	TArray<TSharedPtr<FUIAutoItem>> UIAutoListDataArray;

	TSharedPtr<SWindow> ResultWindow;
	
	const float InvToMb = 1.0 / (1024 * 1024);

	bool bNeedQuitGame = false;

	FUIAutomationObjListener* ObjListener;
	
	// Android JNI相关
	// 前置声明JNI类型
#if PLATFORM_ANDROID
	static bool bJNICacheInitialized;
	// 初始化JNI方法
	static void InitJNIMethods();
	// 清理JNI缓存
    static void CleanupJNIMethods();
	// 获取电池电流(mA)
	static float GetBatteryCurrentAndroid();
	// 获取电池电压
	static float GetBatteryVoltageAndroid();
    
	// 获取电池温度
	static float GetBatteryTemperatureAndroid();
	// 获取电池电量
	static float GetBatteryLevelAndroid();
	// 获取CPU频率
	static float GetCpuFrequencyAndroid();
#endif
	
};

