VehicleGameplayOperateType = {
    ACCELERATE = 1
}

VehicleGameplayOperateParam = {
    ACCELERATE_DURATION = 1,
    ACCELERATE_CD = 2,
    ACCELERATE_BUFFID = 3,
    GAMEPLAY_TYPE = 4,
}

VehicleGameplayType = {
    BIG_WORLD = 0,
    ACCELERATE = 1,
}