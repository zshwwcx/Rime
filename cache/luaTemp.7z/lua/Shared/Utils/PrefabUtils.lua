PrefabType = {
    Poster = 1,           -- 海报
    MonsterChase = 2,     -- 追蝴蝶
    StarGraph = 3,        -- 星象仪
}
