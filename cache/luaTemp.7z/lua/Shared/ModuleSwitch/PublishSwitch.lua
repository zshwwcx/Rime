
-- 正式环境下的开关默认值
-- Debug开关不用在此处设置,默认为nil
-- 线上可以用gm针对不同的服进行调整
SwitchValue = {
    -- 开关名  -> 覆盖值

    EnableLoginDefsCompare = true,  -- 客户端def版本检查

    EnableGMAuthCheck = true,  -- 开启GM鉴权

    EnableRoleNameCheck = true,  -- 开启命名检查


}
