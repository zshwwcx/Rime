DUNGEON_ENTER_LIMIT = {
    NO_LIMIT = 0,       -- 无限制
    SINGLE_PLAYER = 1,  -- 必须单人
    TEAM = 2,           -- 必须组队
    GROUP = 3,          -- 必须组队
}

LEVEL_SEQUENCE_TYPE = {
    STOP_AT_LAST_Frame = 0,  --停在最后一帧
}
