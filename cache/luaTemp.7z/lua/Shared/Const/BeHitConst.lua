-- 受击相关的常量

LIGHT_HIT_ANIM_ASSERT_TYPE = "LightHitFullBody"

SPECIAL_BONE = "SpineBaseBone"