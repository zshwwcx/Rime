---@class SceneActorConst
local SceneActorConst = {}
--------------------------------------

SceneActorConst.DROP_ITEM_MAX_BULLET_PER_SEC = 10

return SceneActorConst
