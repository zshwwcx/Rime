--- 输入枚举
---
LOCO_INPUT_CONST = {
    DODGE_ACTION_NAME = "Dodge_Action",
    JUMP_ACTION_NAME = "Jump_Action"
}

BLOCK_ACTION_SLOT_CONST =
{
    Move = 1,
    Dodge = 2,
    Jump = 3,
    Skill = 4,
    MouseMove = 5,
    System = 6
}


