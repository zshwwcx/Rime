---@class P_Lib_AutomationTest : UIController
---@field public View WBP_LibView
local P_Lib_AutomationTest = DefineClass("P_Lib_AutomationTest", UIController)

function P_Lib_AutomationTest:OnCreate()
    
end

return P_Lib_AutomationTest
