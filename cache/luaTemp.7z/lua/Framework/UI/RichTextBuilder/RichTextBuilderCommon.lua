local RichTextBuilderCommon = {}

local EImageTypes = {
    Texture2D = 1,
    Sprite = 2,
    Material = 3,
    DataTable =4
}


RichTextBuilderCommon.EImageTypes = EImageTypes
return RichTextBuilderCommon