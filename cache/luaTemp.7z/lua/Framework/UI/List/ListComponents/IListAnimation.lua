---@class IListAnimation
local IListAnimation = DefineClass("IListAnimation")

function IListAnimation:PlayListGroupAnimation(key, cells, callback)
    
end

function IListAnimation:StopListAnimation(key)
    
end

function IListAnimation:EnableAutoAnimation(key)
    
end

function IListAnimation:DisableAutoAnimation(key)
    
end

function IListAnimation:PlayStateAnimation(index, state)
    
end
return IListAnimation