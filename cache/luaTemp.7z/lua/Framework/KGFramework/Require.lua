---------------------------------------------------------------------
--- 项目可配置内容 >>>>

UE = kg_require("Framework.KGFramework.KGCore.UE")

UIPanelConfig = kg_require("Framework.KGFramework.KGUI.Core.Config.UIPanelConfig")

UICellConfig = kg_require("Framework.KGFramework.KGUI.Core.Config.UICellConfig")

UISafeZoneConfig = kg_require("Framework.KGFramework.KGUI.Core.Config.UISafeZoneConfig")

UIConst = kg_require("Framework.KGFramework.KGUI.Core.Config.UIConst")

StateGroupConst = kg_require("Data.Config.UI.StateGroupConst")