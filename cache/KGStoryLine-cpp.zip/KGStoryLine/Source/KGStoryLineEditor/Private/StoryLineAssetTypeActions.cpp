#include "StoryLineAssetTypeActions.h"

#include "DialogueEditor/DialogueAssetBrowser.h"
#include "KGStoryLineEditorModule.h"
#include "DialogueEditor/KGStoryLineEditorSubSystem.h"

FStoryLineAssetDefinitionWrapper::FStoryLineAssetDefinitionWrapper(UClass* InClass)
{
	Class = InClass;
}

FText FStoryLineAssetDefinitionWrapper::GetName() const
{
	const UAssetDefinition* AssetDefinition = UAssetDefinitionRegistry::Get()->GetAssetDefinitionForClass(GetSupportedClass()); // checked
	if (!AssetDefinition)
		return {};
	return AssetDefinition->GetAssetDisplayName();
}

FColor FStoryLineAssetDefinitionWrapper::GetTypeColor() const
{
	const UAssetDefinition* AssetDefinition = UAssetDefinitionRegistry::Get()->GetAssetDefinitionForClass(GetSupportedClass()); // checked
	if (!AssetDefinition)
		return {};
	return AssetDefinition->GetAssetColor().ToFColor(false);
}

bool FStoryLineAssetDefinitionWrapper::ShouldForceWorldCentric()
{
	const UAssetDefinition* AssetDefinition = UAssetDefinitionRegistry::Get()->GetAssetDefinitionForClass(GetSupportedClass()); // checked
	if (!AssetDefinition)
		return false;

	const FAssetOpenSupport AssetOpenSupport = AssetDefinition->GetAssetOpenSupport(FAssetOpenSupportArgs());
	if (AssetOpenSupport.RequiredToolkitMode.IsSet())
		return AssetOpenSupport.RequiredToolkitMode == EToolkitMode::Type::WorldCentric;
	
	return FAssetTypeActions_Base::ShouldForceWorldCentric();
}

void FStoryLineAssetDefinitionWrapper::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	const UAssetDefinition* AssetDefinition = UAssetDefinitionRegistry::Get()->GetAssetDefinitionForClass(GetSupportedClass()); // checked
	if (!AssetDefinition)
		return;

	TArray<FAssetData> AssetDataList;
	for (UObject* InObject : InObjects)
	{
		AssetDataList.Emplace(InObject);
	}

	FAssetOpenArgs Args;
	Args.OpenMethod = EAssetOpenMethod::Edit;
	Args.ToolkitHost = EditWithinLevelEditor;
	Args.Assets = AssetDataList;
	AssetDefinition->OpenAssets(Args);
}

bool FStoryLineAssetDefinitionWrapper::SupportsOpenedMethod(const EAssetTypeActivationOpenedMethod OpenedMethod) const
{
	if (!FAssetTypeActions_Base::SupportsOpenedMethod(OpenedMethod))
		return false;

	return FKGStoryLineEditorModule::CanTypeOfAssetOpen(Class.Get());
}
