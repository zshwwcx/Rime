// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#include "StoryLineEditorConfig.h"

TObjectPtr<UStoryLineEditorConfig> UStoryLineEditorConfig::Instance = nullptr;

void UStoryLineEditorConfig::Initialize()
{
	if (!Instance)
	{
		Instance = NewObject<UStoryLineEditorConfig>();
		Instance->LoadEditorConfig();
		Instance->AddToRoot();
	}
}

void UStoryLineEditorConfig::UpdateRecentlyUsedCustomSection(const FString& Content)
{
	if (Content.IsEmpty())
	{
		return;
	}
	
	int32 ExistingIndex = RecentlyUsedCustomSection.Find(Content);
	
	if (ExistingIndex != INDEX_NONE)
	{
		RecentlyUsedCustomSection.RemoveAt(ExistingIndex);
		RecentlyUsedCustomSection.Insert(Content, 0);
	}
	else
	{
		RecentlyUsedCustomSection.Insert(Content, 0);
		if (RecentlyUsedCustomSection.Num() > MaxCacheSize)
		{
			RecentlyUsedCustomSection.RemoveAt(MaxCacheSize);
		}
	}
	
	// 保存配置
	SaveEditorConfig();
}

TArray<FString> UStoryLineEditorConfig::GetLatestRecentlyUsedCustomSection() const
{
	return RecentlyUsedCustomSection;
}
