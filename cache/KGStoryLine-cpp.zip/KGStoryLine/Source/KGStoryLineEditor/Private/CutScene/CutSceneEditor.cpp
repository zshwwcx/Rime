#include "CutScene/CutSceneEditor.h"

#include "CutScene/RenderVideo/C7CutsceneGameInstance.h"
#include "Editor.h"
#include "Subsystems/UnrealEditorSubsystem.h"
#include "CutScene/CutSceneEditorLuaGameInstance.h"
#include "CutScene/CutSceneEditorSettings.h"
#include "CutScene/Utils/FCutsceneEditorUtils.h"
#include "HeadMountedDisplayTypes.h"
#include "KGStoryLineEditorModule.h"
#include "LevelSequence.h"
#include "LuaBlueprintLibrary.h"
#include "MovieRenderPipelineSettings.h"
#include "MovieScene.h"
#include "MovieSceneObjectBindingID.h"
#include "CutScene/RenderVideo/UC7MoviePipelinePIEExecutor.h"
#include "Editor/Sequencer/Private/Sequencer.h"
#include "Engine/DataTable.h"
#include "LevelInstance/LevelInstanceInterface.h"
#include "LevelInstance/LevelInstanceSubsystem.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"

//TSharedPtr<FKGEditorLua> gCutSceneKGLuaPtr = nullptr;

#define LOCTEXT_NAMESPACE "CutSceneEditor"


FCutSceneEditor::FCutSceneEditor()
{
}

FCutSceneEditor::~FCutSceneEditor()
{
	UninitPostProcessPreview();
	UnInitLuaEnvironment();
	UninitializeRoleComposite();
}

void FCutSceneEditor::InitLuaEnvironment()
{
    if (LuaEnv)
	{
		UE_LOG(LogKGStoryLineEditor, Error, TEXT("KGLuaPtr has been created already!"));
	}
	
	if (UWorld* EditorWorld = GEditor->GetEditorWorldContext().World())
	{
		LuaEnv = UEditorLuaEnv::CreateLuaEnv(EditorWorld, UCutSceneEditorLuaGameInstance::StaticClass());	
	}

	UE_LOG(LogKGStoryLineEditor, Log, TEXT("Create new lua-environment, %p"), LuaEnv);
}

void FCutSceneEditor::InitializeCharacterLighting() const
{
	if (!LuaEnv || !GEditor)
		return;
	
	UCutSceneEditorLuaGameInstance* LuaGameInstance = Cast<UCutSceneEditorLuaGameInstance>(LuaEnv->GetLuaGameInstance());
	const UWorld* EditorWorld = GEditor->GetEditorWorldContext().World();
	if (LuaGameInstance && EditorWorld)
	{
		if (const ULevel* PersistentLevel = EditorWorld->PersistentLevel)
		{
			const FString LevelPackageName = PersistentLevel->GetOutermost()->GetName();
			FString SequencePath = LevelSequence.IsValid() ? LevelSequence->GetPathName() : "";
			LuaGameInstance->InitializeCharacterLighting(LevelPackageName, SequencePath);
		}
	}
}

void FCutSceneEditor::UnInitLuaEnvironment()
{
	if (!LuaEnv)
	{
		UE_LOG(LogKGStoryLineEditor, Error, TEXT("KGLuaPtr invalid!"));
	}
	else
	{
		UE_LOG(LogKGStoryLineEditor, Log, TEXT("Destroy lua-environment, %p"), LuaEnv);
		if (FUObjectThreadContext::Get().IsRoutingPostLoad)
		{
			FCutsceneEditorUtils::CreateNotification(FText::FromString(TEXT("Sequence 关闭过程中, 出现意外情况, 请重新启动UE")), false, 10, 10);
			LuaEnv = nullptr;			
			return;
		}
		
		UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
	}
}

void FCutSceneEditor::InitializeRoleComposite(TWeakPtr<ISequencer> InSequencer, TWeakObjectPtr<ULevelSequence> InLevelSequence)
{
	UninitializeRoleComposite();
	if (!InSequencer.IsValid() || !InLevelSequence.IsValid())
		return;

	Sequencer = InSequencer;
	LevelSequence = InLevelSequence;
	RoleCompositeHandler = Sequencer.Pin()->OnMovieSceneBindingsChanged().AddRaw(this, &FCutSceneEditor::IterateTagsForRoleComposite);
	CameraCutHandler = Sequencer.Pin()->OnCameraCut().AddRaw(this, &FCutSceneEditor::OnCameraCut);
	LevelSequence->EventHandlers.Link(MovieSceneModified, this);
	
	UUnrealEditorSubsystem* UnrealEditorSubsystem = GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>();
	if (UnrealEditorSubsystem && LuaEnv)
	{
		InitializeCharacterLighting();
	}
	
	if (TSharedPtr<ISequencer> SharedSequencer = InSequencer.Pin())
	{
		SharedSequencer->OnActorAddedToSequencer().Remove(OnActorAddedHandle);
		OnActorAddedHandle = SharedSequencer->OnActorAddedToSequencer().AddStatic(&FCutSceneEditor::OnActorAddedToSequencer, InSequencer);
	}
}

void FCutSceneEditor::UninitializeRoleComposite()
{
	if (RoleCompositeHandler.IsValid() && Sequencer.IsValid())
	{
		Sequencer.Pin()->OnMovieSceneBindingsChanged().Remove(RoleCompositeHandler);
		RoleCompositeHandler.Reset();
		Sequencer.Pin()->OnCameraCut().Remove(CameraCutHandler);
		CameraCutHandler.Reset();
		Sequencer.Pin()->OnActorAddedToSequencer().Remove(OnActorAddedHandle);
	}
	Sequencer = nullptr;
	LevelSequence = nullptr;
	RoleTagMap.Empty();
	MovieSceneModified.Unlink();
}

void FCutSceneEditor::OnActorAddedToSequencer(AActor* Actor, FGuid Guid, TWeakPtr<ISequencer> WeakSequencer)
{
	if (ILevelInstanceInterface* LevelInstance = Cast<ILevelInstanceInterface>(Actor))
	{
		for (int i = 0; i < 3; i++)
			FCutsceneEditorUtils::CreateNotification(FText::FromString(TEXT("禁止向CutScene中添加LevelInstance!")), false, 10, 10);
		
		if (TSharedPtr<ISequencer> Seq = WeakSequencer.Pin())
		{
			if (UMovieSceneSequence* Sequence = Seq->GetFocusedMovieSceneSequence())
			{
				if (UMovieScene* MovieScene = Sequence->GetMovieScene())
				{
					MovieScene->RemovePossessable(Guid);
					MovieScene->RemoveSpawnable(Guid);
				}
			}
		}
	}
}

void FCutSceneEditor::ModifyViewportClientView(FEditorViewportViewModifierParams& Params)
{
	if (!LuaEnv)
		return;
	UUnrealEditorSubsystem* UnrealEditorSubsystem = GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>();
	if (UnrealEditorSubsystem)
	{
		UWorld* SceneWorld = UnrealEditorSubsystem->GetEditorWorld();
		if (UPostProcessManager* PostProcessManager = UPostProcessManager::GetInstance(SceneWorld))
		{
			const TArray<float>* CameraAnimPPBlendWeightsPtr = nullptr;
			const TArray<FPostProcessSettings>* CameraAnimPPSettingsPtr = nullptr;
			PostProcessManager->GetCachedPostProcessBlends(CameraAnimPPSettingsPtr, CameraAnimPPBlendWeightsPtr);
			if (CameraAnimPPBlendWeightsPtr && CameraAnimPPSettingsPtr)
			{
				auto& CameraAnimPPSettings = *CameraAnimPPSettingsPtr;
				auto& CameraAnimPPBlendWeights = *CameraAnimPPBlendWeightsPtr;
				check(CameraAnimPPSettings.Num() == CameraAnimPPBlendWeights.Num());
				for (int32 PPIdx = 0; PPIdx < CameraAnimPPSettings.Num(); ++PPIdx)
				{
					Params.AddPostProcessBlend(CameraAnimPPSettings[PPIdx], CameraAnimPPBlendWeights[PPIdx]);
				}
			}
		}
	}
}

void FCutSceneEditor::InitPostProcessPreview()
{
	FViewport* Viewport = GEditor->GetActiveViewport();
	if (!Viewport)
	{
		return;
	}
	FViewportClient* ViewportClient = Viewport->GetClient();
	

	if (!ViewportClient)
	{
		return;
	}



	for (FEditorViewportClient* LevelVC : GEditor->GetLevelViewportClients())
	{
		if (LevelVC)
		{
			LevelVC->ViewModifiers.AddRaw(this, &FCutSceneEditor::ModifyViewportClientView);
		}
	}
}

void FCutSceneEditor::UninitPostProcessPreview()
{
	FViewport* Viewport = GEditor->GetActiveViewport();
	if (!Viewport)
	{
		return;
	}
	FViewportClient* ViewportClient = Viewport->GetClient();


	if (!ViewportClient)
	{
		return;
	}

	for (FEditorViewportClient* LevelVC : GEditor->GetLevelViewportClients())
	{
		if (LevelVC)
		{
			LevelVC->ViewModifiers.RemoveAll(this);
		}
	}
}


void FCutSceneEditor::IterateTagsForRoleComposite()
{
	if (!Sequencer.IsValid() || !LevelSequence.IsValid())
		return;

	if (FacadeControlIDs.Num() == 0)
	{
		GetFacadeControlIDs(FacadeControlIDs);
	}
	
	const TSharedPtr<ISequencer> Seq = Sequencer.Pin();	
	const TMap<FName, FMovieSceneObjectBindingIDs>& Tuples = LevelSequence->GetMovieScene()->AllTaggedBindings();
	TMap<FMovieSceneObjectBindingID, TArray<FName>> BindingTags;
	for (const TPair<FName, FMovieSceneObjectBindingIDs>& Pair : Tuples)
	{
		for (FMovieSceneObjectBindingID ID : Pair.Value.IDs)
		{
			BindingTags.FindOrAdd(ID).Add(Pair.Key);
		}
	}
	
	for (auto Tuple : Tuples)
	{
		const int32 FacadeControlID = FCString::Atoi(*Tuple.Key.ToString());
		const bool bIsRoleFacadeID = FacadeControlID != 0 && FacadeControlIDs.Contains(FacadeControlID);
		for (FMovieSceneObjectBindingID ID : Tuple.Value.IDs)
		{
			for (TWeakObjectPtr<> WeakObject : Seq->FindBoundObjects(ID.GetGuid(), ID.GetRelativeSequenceID()))
			{
				if (RoleTagMap.Contains(WeakObject) && RoleTagMap[WeakObject].Contains(Tuple.Key))
					continue;
				
				// 这里就不限制Class为BP_CutSceneDynamicActor_C了, 在Lua里面去看
				if (!WeakObject.IsValid() || !WeakObject->IsA<AActor>())
					continue;

				const TArray<FName> Tags = BindingTags.Contains(ID) ? BindingTags[ID] : TArray<FName>();
				if(bIsRoleFacadeID)
					RequestRoleComposite(Cast<AActor>(WeakObject.Get()), Tuple.Key.ToString(), Tags);
				else
					RequestObjectComposite(Cast<AActor>(WeakObject.Get()), Tuple.Key.ToString(), Tags);
				RoleTagMap.FindOrAdd(WeakObject).Add(Tuple.Key);
			}
		}
	}
}

void FCutSceneEditor::RequestRoleComposite(AActor* Actor, const FString& Tag, TArray<FName> Tags) const
{
	TRACE_CPUPROFILER_EVENT_SCOPE(FCutSceneEditor::RequestRoleComposite)
	using namespace NS_SLUA;
	LuaState* State = nullptr;
	if (!LuaEnv)
	{
		if (Actor)
		{
			UWorld* World = Actor->GetWorld();
			if (UGameInstance* GI = UGameplayStatics::GetGameInstance(Actor))
			{
				State = LuaState::get(GI);	
			}	
		}
	}
	else
	{
		State = LuaState::get(LuaEnv->GetLuaState());
	}
	
	if (!State || !Actor->IsValidLowLevel() || Actor->IsPendingKillPending() || Tag.IsEmpty())
	{
		return;
	}
	
	LuaVar Result = State->call("RequestCutsceneActorComposite", Actor, Tag, false, Tags);
}

void FCutSceneEditor::RequestObjectComposite(AActor* Actor, const FString& Tag, TArray<FName> Tags) const
{
	TRACE_CPUPROFILER_EVENT_SCOPE(FCutSceneEditor::RequestObjectComposite)
	using namespace NS_SLUA;
	LuaState* State = nullptr;
	if (!LuaEnv)
	{
		if (Actor)
		{
			UWorld* World = Actor->GetWorld();
			if (UGameInstance* GI = UGameplayStatics::GetGameInstance(Actor))
			{
				State = LuaState::get(GI);	
			}	
		}
	}
	else
	{
		State = LuaState::get(LuaEnv->GetLuaState());
	}
	
	if (!State || !Actor->IsValidLowLevel() || Actor->IsPendingKillPending() || Tag.IsEmpty())
	{
		return;
	}
	
	LuaVar Result = State->call("RequestCutsceneObjectComposite", Actor, Tag, false, Tags);
}

bool FCutSceneEditor::GetFacadeControlIDs(TMap<int32, FString>& FacadeControlID) const
{
	using namespace NS_SLUA;
	if (!LuaEnv)
		return false;

	LuaState* LuaState = LuaState::get(LuaEnv->GetLuaState());
	if (!LuaState)
		return false;

	LuaVar Result = LuaState->call("GetFacadeControlData");
	if (Result.isValid())
		FacadeControlID = Result.castTo<TMap<int32, FString>>();
	return !FacadeControlID.IsEmpty();
}

void FCutSceneEditor::OnModifiedIndirectly(UMovieSceneSignedObject* Obj)
{
	// Sequence 没有对Tag修改做专门的回调, 所以这里用通用的回调触发, 扫描出有修改的Tag, 然后刷新外观.
	IterateTagsForRoleComposite();
}

void FCutSceneEditor::BuildToolbar(FToolBarBuilder& ToolBarBuilder)
{
	ToolBarBuilder.BeginSection("Export");
	ToolBarBuilder.AddComboButton(
		FUIAction(),
		FOnGetContent::CreateLambda([](){
			const UCutSceneEditorSettings* Settings = GetDefault<UCutSceneEditorSettings>();
			FMenuBuilder MenuBuilder(true, nullptr);
			if (UDataTable* DataTable = Settings->FixLightDataTable.LoadSynchronous())
			{
				TArray<FName> Names = DataTable->GetRowNames();
				for (FName Key : Names)
				{
					MenuBuilder.AddMenuEntry(
						FText::FromName(Key),
						FText::GetEmpty(),
						FSlateIcon(),
						FUIAction(
							FExecuteAction::CreateLambda([Key]()
							{
								FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
								TSharedPtr<FCutSceneEditor> CutSceneEditor = KGStoryLineEditorModule.GetCutSceneEditorPtr();
								if (!CutSceneEditor.IsValid())
									return;
								if (!CutSceneEditor->LuaEnv || !GEditor)
									return;

								if (auto LuaGameInstance = Cast<UCutSceneEditorLuaGameInstance>(CutSceneEditor->LuaEnv->GetLuaGameInstance()))
								{
									FString SequencePath = CutSceneEditor->LevelSequence.IsValid() ? CutSceneEditor->LevelSequence->GetPathName() : "";
									LuaGameInstance->InitializeCharacterLighting(Key.ToString(), SequencePath);
								}
							})
						)
					);
				}
			}
			return MenuBuilder.MakeWidget();
		}),
		LOCTEXT("LightFixLabel", "LightFix")
	);
	ToolBarBuilder.EndSection();
}

void FCutSceneEditor::ExtendMenu()
{
	ISequencerModule& SequencerModule = FModuleManager::Get().LoadModuleChecked<ISequencerModule>("Sequencer");

	TSharedPtr<FExtensibilityManager> ExtensionManager = SequencerModule.GetToolBarExtensibilityManager();

	TSharedPtr<FUICommandList> CommandList = MakeShareable(new FUICommandList);

	TSharedPtr<FExtender> ToolbarExtender = MakeShareable(new FExtender);
	TSharedPtr<const FExtensionBase> ToolbarExtension = ToolbarExtender->AddToolBarExtension(
		"BaseCommands",
		EExtensionHook::After,
		CommandList,
		FToolBarExtensionDelegate::CreateStatic(&FCutSceneEditor::BuildToolbar)
	);

	ExtensionManager->AddExtender(ToolbarExtender);
}

void FCutSceneEditor::Tick(float DeltaTime)
{
    if (LuaEnv && LuaEnv->GetLuaGameInstance())
	{
		UEditorLuaGameInstanceBase* EditorLuaGameInstance = LuaEnv->GetLuaGameInstance();
		EditorLuaGameInstance->Tick(DeltaTime);
	}
}

TStatId FCutSceneEditor::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(FCutSceneEditor, STATGROUP_Tickables);
}

void FCutSceneEditor::InitializeRenderPipeline()
{
	UMovieRenderPipelineProjectSettings* ProjectSettings = GetMutableDefault<UMovieRenderPipelineProjectSettings>();
	ProjectSettings->DefaultLocalExecutor = UC7MoviePipelinePIEExecutor::StaticClass();
}

void FCutSceneEditor::OnCameraCut(UObject* Object, bool bArg) const
{
    if (!LuaEnv)
		return;

	if (UCutSceneEditorLuaGameInstance* LuaGameInstance = Cast<UCutSceneEditorLuaGameInstance>(LuaEnv->GetLuaGameInstance()))
	{
		LuaGameInstance->SetCurrentCamera(Object, bArg);
	}
}
	
TWeakPtr<ISequencer> FCutSceneEditor::GetSequencer()
{
	return Sequencer;
}
TWeakObjectPtr<ULevelSequence> FCutSceneEditor::GetLevelSequence()
{
	return LevelSequence;
}

#undef LOCTEXT_NAMESPACE

