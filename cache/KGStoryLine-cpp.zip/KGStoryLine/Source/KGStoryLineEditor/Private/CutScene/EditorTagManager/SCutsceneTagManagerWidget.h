// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "EditorUndoClient.h"
#include "CutScene/EditorTagManager/FTagManagerData.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/STextComboBox.h"
#include "ISequencer.h"
#include "LevelSequence.h"
#include "CutScene/EditorTagManager/SCutsceneBindingTreeWidget.h"

class SWrapBox;


class SCutsceneTagManagerWidget : public SCompoundWidget, public FSelfRegisteringEditorUndoClient
{
public:
	SLATE_BEGIN_ARGS(SCutsceneTagManagerWidget) {}
	SLATE_END_ARGS()

	SCutsceneTagManagerWidget();
	void Construct(const FArguments& InArgs, const TSharedRef<ISequencer>& Sequencer, const FMovieSceneObjectBindingID& CurrentActorBindingID);

	virtual void PostUndo(bool bSuccess) override;
	virtual void PostRedo(bool bSuccess) override;

protected:
	// ======== 数据成员 ========
	TSharedRef<FTagManagerData> TagManagerData; // 标签管理器数据
	
	TArray<TSharedPtr<FString>> ActorOptions; // Actor下拉框选项
	TArray<FMovieSceneObjectBindingID> ActorBindingIDs; // 对应ActorOptions的id列表

	// ======== UI控件引用 ========
	TSharedPtr<SWrapBox> AddedTagsWrapBox;
	TSharedPtr<SWrapBox> QuickTagsWrapBox;
	TSharedPtr<STextComboBox> ActorComboBox; // Actor下拉框

	// 输入区
	TSharedPtr<SEditableTextBox> InputAnyTag;
	TSharedPtr<SEditableTextBox> InputNPCTag;
	TSharedPtr<SEditableTextBox> InputObjectTag;
	TSharedPtr<SCutsceneBindingTreeWidget> TreeWidget;

	// ======== UI刷新方法 ========
	void RebuildTagList();
	void RebuildAddedTagList();
	void RebuildQuickTagList();
	void RebuildActorComboBox();

	// ======== 事件处理方法 ========
	FReply HandleAddTag(const FString& NewTag);
	void HandleRemoveTag(FName TagName);
	void HandleQuickTagClicked(const FName TagName);
	void HandleActorSelectionChanged(TSharedPtr<FString>, ESelectInfo::Type);
	void HandleActorSelectedFromTree(FMovieSceneObjectBindingID SelectedActorBindingID);
};
