// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Views/STreeView.h"
#include "Widgets/Views/ITableRow.h"
#include "ObjectBindingTagCache.h"
#include "Textures/SlateIcon.h"

struct FTagManagerData;
class ISequencer;
class UMovieSceneSequence;
class UMovieScene;
class SObjectBindingTag;

/** 自定义的绑定节点，使用TagManagerData作为数据源 */
struct FCutsceneBindingNode
{
	enum class ENodeType
	{
		Sequence,
		Actor
	};
	
	FString DisplayName;
	FSlateIcon Icon;
	FMovieSceneObjectBindingID BindingID;
	TArray<FName> Tags;
	ENodeType NodeType;
	TArray<TSharedRef<FCutsceneBindingNode>> Children;
	
	FCutsceneBindingNode(const FString& InDisplayName, const FMovieSceneObjectBindingID& InBindingID, ENodeType InNodeType, const TArray<FName>& InTags, const FSlateIcon& InIcon)
		: DisplayName(InDisplayName)
		, Icon(InIcon)
		, BindingID(InBindingID)
		, Tags(InTags)
		, NodeType(InNodeType)
	{}
	
	/** 添加子节点 */
	void AddChild(TSharedRef<FCutsceneBindingNode> Child)
	{
		Children.Add(Child);
	}
	
	/** 判断是否有子节点 */
	bool HasChildren() const
	{
		return Children.Num() > 0;
	}
};

/**
 * Widget that displays a tree view of object bindings and their tags, similar to SObjectBindingTagManager
 * but adapted for the KGStoryLine plugin's cutscene editor.
 */
class SCutsceneBindingTreeWidget : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnActorSelected, FMovieSceneObjectBindingID);
	
	SLATE_BEGIN_ARGS(SCutsceneBindingTreeWidget) {}
		/** Called when an actor is selected in the tree */
		SLATE_EVENT(FOnActorSelected, OnActorSelected)
	SLATE_END_ARGS()

	virtual ~SCutsceneBindingTreeWidget() override
	{
		UE_LOG(LogTemp, Warning, TEXT("SCutsceneBindingTreeWidget destroyed"));
	}

	void ExpandTreeView();
	/** Constructs this widget */
	void Construct(const FArguments& InArgs, const TWeakPtr<ISequencer>& InWeakSequencer, const TSharedRef<FTagManagerData>& InTagManagerData);
	
	void ForceRefreshTreeView();
	void RefreshCurrentItem(FMovieSceneObjectBindingID BindingID);
	
private:
	TSharedRef<ITableRow> OnGenerateRow(TSharedRef<FCutsceneBindingNode> CutsceneBindingNode, const TSharedRef<STableViewBase>& TableViewBase);
	TSharedRef<SHorizontalBox> CreateRowContent(const TSharedRef<FCutsceneBindingNode>& BindingNode);
	
	/** The sequencer we're associated with */
	TWeakPtr<ISequencer> WeakSequencer;

	/** The tag manager data */
	TSharedPtr<FTagManagerData> TagManagerData;

	/** The tree view widget */
	TSharedPtr<STreeView<TSharedRef<FCutsceneBindingNode>>> TreeView;
	TArray<TSharedRef<FCutsceneBindingNode>> TreeItems;
	
	TMap<TSharedPtr<FCutsceneBindingNode>, TWeakPtr<SBox>> NodeToWidgetMap;

	/** Called when an actor is selected */
	FOnActorSelected OnActorSelected;
};