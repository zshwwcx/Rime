// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#include "CutScene/EditorTagManager/SObjectBindingTagWidget.h"

#include "EditorFontGlyphs.h"
#include "Components/HorizontalBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"
#include "SlateOptMacros.h"
#include "Widgets/Layout/SBox.h"

#define LOCTEXT_NAMESPACE "SObjectBindingTagWidget"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void SObjectBindingTagWidget::Construct(const FArguments& InArgs)
{
	OnDeleted = InArgs._OnDeleted;
	OnAdded = InArgs._OnAdded;

	TSharedRef<SHorizontalBox> ContentBox = SNew(SHorizontalBox);

	ContentBox->AddSlot()
	.VAlign(VAlign_Center)
	[
		SNew(STextBlock)
		.Font(FAppStyle::GetFontStyle("TinyText"))
		.Text(InArgs._Text)
	];

	// Add button
	if (OnAdded.IsBound())
	{
		ContentBox->AddSlot()
		.Padding(FMargin(5.f, 0.f, 0.f, 0.f))
		.VAlign(VAlign_Fill)
		.HAlign(HAlign_Right)
		.AutoWidth()
		[
			SNew(SButton)
			.ContentPadding(FMargin(0.f))
			.ButtonStyle(FAppStyle::Get(), "HoverHintOnly")
			.OnClicked(this, &SObjectBindingTagWidget::HandleAddButtonClicked)
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Center)
			[
				SNew(SBox)
				.MinDesiredWidth(18)
				.Padding(0, 3, 0, 0)
				[
					SNew(STextBlock)
					.Justification(ETextJustify::Center)
					.Font(FAppStyle::Get().GetFontStyle("FontAwesome.12"))
					.Text(FEditorFontGlyphs::Plus)
				]
			]
		];
	}
	
	// Delete button
	if (OnDeleted.IsBound())
	{
		ContentBox->AddSlot()
		.Padding(FMargin(2.f, 0.f, 0.f, 0.f))
		.VAlign(VAlign_Fill)
		.HAlign(HAlign_Right)
		.AutoWidth()
		[
			SNew(SButton)
			.ContentPadding(FMargin(0.f))
			.ButtonStyle(FAppStyle::Get(), "HoverHintOnly")
			.OnClicked(this, &SObjectBindingTagWidget::HandleDeleteButtonClicked)
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Center)
			[
				SNew(SBox)
				.MinDesiredWidth(18)
				.Padding(0, 3, 0, 0)
				[
					SNew(STextBlock)
					.Justification(ETextJustify::Center)
					.Font(FAppStyle::Get().GetFontStyle("FontAwesome.12"))
					.Text(FEditorFontGlyphs::Times)
				]
			]
		];
	}

	const uint32 StringHash = GetTypeHash(InArgs._Text.Get().ToString());
	const float Hue = (static_cast<double>(StringHash) / MAX_uint32) * 360.f;
	constexpr float GSequencerTagSaturation = 0.6f;
	const FLinearColor ColorTintRGB = FLinearColor(Hue, GSequencerTagSaturation, .5f).HSVToLinearRGB();
	
	// Since OnClicked is removed, we always use a border
	ChildSlot
	[
		SNew(SBorder)
		.ToolTipText(InArgs._ToolTipText)
		.BorderImage(FAppStyle::GetBrush("Sequencer.ExposedNamePill_BG"))
		.BorderBackgroundColor(ColorTintRGB)
		.Padding(FMargin(8.f, 2.f))
		[
			ContentBox
		]
	];
}
END_SLATE_FUNCTION_BUILD_OPTIMIZATION

FReply SObjectBindingTagWidget::HandleAddButtonClicked() const
{
	OnAdded.ExecuteIfBound();
	return FReply::Handled();
}

FReply SObjectBindingTagWidget::HandleDeleteButtonClicked() const
{
	OnDeleted.Execute();
	return FReply::Handled();
}

#undef LOCTEXT_NAMESPACE