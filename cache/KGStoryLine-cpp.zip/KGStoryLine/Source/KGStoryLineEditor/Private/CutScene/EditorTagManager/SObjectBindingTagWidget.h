// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once

#include "CoreTypes.h"
#include "Widgets/SCompoundWidget.h"

/** A single named tag widget for an object binding within a sequence, represented as a rounded 'pill' */
class SObjectBindingTagWidget : public SCompoundWidget
{
public:

	DECLARE_DELEGATE_OneParam(FOnCreateNew, FName)

	SLATE_BEGIN_ARGS(SObjectBindingTagWidget) : _ColorTint(FLinearColor::White) {}

		/** (Optional) When bound, shows a small delete button on the tag that invokes this delegate when clicked */
		SLATE_EVENT(FSimpleDelegate, OnDeleted)

		/** (Optional) When bound, the text portion of the tag will be a text input allowing the user to create a new named tag */
		SLATE_EVENT(FSimpleDelegate, OnAdded)

		/** Text to display on the tag (when OnCreateNew is not specified) */
		SLATE_ATTRIBUTE(FText, Text)

		/** Tool tip text for this whole widget */
		SLATE_ATTRIBUTE(FText, ToolTipText)

		/** Color tint for the whole widget */
		SLATE_ATTRIBUTE(FSlateColor, ColorTint)

	SLATE_END_ARGS()

	/**
	 * Construct this widget
	 */
	void Construct(const FArguments& InArgs);

private:

	FReply HandleAddButtonClicked() const;

	FReply HandleDeleteButtonClicked() const;

	virtual FVector2D ComputeDesiredSize(float LayoutScaleMultiplier) const override
	{
		const float DesiredX = SCompoundWidget::ComputeDesiredSize(LayoutScaleMultiplier).X;
		return FVector2D(DesiredX, 24.f);
	}

private:
	FSimpleDelegate OnAdded;
	FSimpleDelegate OnDeleted;

	TSharedPtr<class SEditableTextBox> EditableText;
};