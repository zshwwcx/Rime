// Copyright Epic Games, Inc. All Rights Reserved.

#include "CutScene/EditorTagManager/SCutsceneBindingTreeWidget.h"

#include "CutScene/EditorTagManager/FTagManagerData.h"
#include "ISequencer.h"
#include "CutScene/EditorTagManager/SObjectBindingTagWidget.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Layout/SScrollBorder.h"
#include "Widgets/Text/STextBlock.h"

#include "Styling/AppStyle.h"


#define LOCTEXT_NAMESPACE "SCutsceneBindingTreeWidget"

/** 递归构建TreeView的层级结构 */
void BuildTreeHierarchy(const FSequenceTagInfo& SequenceInfo, TArray<TSharedRef<FCutsceneBindingNode>>& OutTreeItems)
{
	OutTreeItems.Reset();
	// 创建Sequence节点
	TSharedRef<FCutsceneBindingNode> SequenceNode = MakeShareable(new FCutsceneBindingNode(
		SequenceInfo.SequenceName,
		FMovieSceneObjectBindingID(),
		FCutsceneBindingNode::ENodeType::Sequence,
		{},
		FSlateIcon()
	));
	
	// 添加当前Sequence中的角色
	for (const FActorTagInfo& ActorInfo : SequenceInfo.Actors)
	{
		TSharedRef<FCutsceneBindingNode> ActorNode = MakeShareable(new FCutsceneBindingNode(
			ActorInfo.ActorName,
			ActorInfo.BindingID,
			FCutsceneBindingNode::ENodeType::Actor,
			ActorInfo.Tags,
			ActorInfo.ActorIcon
		));
		SequenceNode->AddChild(ActorNode);
	}
	
	// 递归添加子Sequence
	for (const FSequenceTagInfo& ChildSequence : SequenceInfo.ChildSequences)
	{
		TArray<TSharedRef<FCutsceneBindingNode>> ChildNodes;
		BuildTreeHierarchy(ChildSequence, ChildNodes);
		for (TSharedRef<FCutsceneBindingNode> ChildNode : ChildNodes)
		{
			SequenceNode->AddChild(ChildNode);
		}
	}
	
	// 只有当Sequence有内容时才添加到树中
	if (SequenceNode->HasChildren())
	{
		OutTreeItems.Add(SequenceNode);
	}
}

void SCutsceneBindingTreeWidget::ExpandTreeView()
{
	struct FInternal
	{
		static void ExpandAll(TSharedRef<FCutsceneBindingNode> Node, STreeView<TSharedRef<FCutsceneBindingNode>>* InTreeView)
		{
			InTreeView->SetItemExpansion(Node, true);
			for (TSharedRef<FCutsceneBindingNode> Child : Node->Children)
			{
				ExpandAll(Child, InTreeView);
			}
		}
	};
	if (TreeItems.Num() > 0)
		FInternal::ExpandAll(TreeItems[0], TreeView.Get());
}

void SCutsceneBindingTreeWidget::Construct(const FArguments& InArgs, const TWeakPtr<ISequencer>& InWeakSequencer, const TSharedRef<FTagManagerData>& InTagManagerData)
{
	WeakSequencer = InWeakSequencer;
	TagManagerData = InTagManagerData;
	OnActorSelected = InArgs._OnActorSelected;

	// 从TagManagerData构建层级结构
	if (TagManagerData.IsValid())
	{
		BuildTreeHierarchy(TagManagerData->RootSequence, TreeItems);
	}

	TreeView = SNew(STreeView<TSharedRef<FCutsceneBindingNode>>)
		.OnGenerateRow(this, &SCutsceneBindingTreeWidget::OnGenerateRow)
		.OnGetChildren_Lambda([](TSharedRef<FCutsceneBindingNode> InNode, TArray<TSharedRef<FCutsceneBindingNode>>& OutChildren)
		{
			OutChildren = InNode->Children;
		})
		.OnSelectionChanged_Lambda([this](TSharedPtr<FCutsceneBindingNode> InNode, ESelectInfo::Type)
		{
			if (!InNode || InNode->NodeType == FCutsceneBindingNode::ENodeType::Sequence)
				return;
			OnActorSelected.ExecuteIfBound(InNode->BindingID);
		})
		.TreeItemsSource(&TreeItems);
	
	ExpandTreeView();
	
	ChildSlot
	[
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
			[
				SNew(SScrollBorder, TreeView.ToSharedRef())
				[
					TreeView.ToSharedRef()
				]
			]
		]
	];
}

void SCutsceneBindingTreeWidget::ForceRefreshTreeView()
{
	// 从TagManagerData构建层级结构
	if (TagManagerData.IsValid())
	{
		BuildTreeHierarchy(TagManagerData->RootSequence, TreeItems);
	}
	
	if (TreeView.IsValid())
		TreeView->RequestTreeRefresh();
	
	ExpandTreeView();
}

void SCutsceneBindingTreeWidget::RefreshCurrentItem(const FMovieSceneObjectBindingID BindingID)
{
	for (TPair<TSharedPtr<FCutsceneBindingNode>, TWeakPtr<SBox>> Pair : NodeToWidgetMap)
	{
		if (Pair.Key.IsValid() && Pair.Key->BindingID == BindingID && Pair.Value.IsValid())
		{
			Pair.Value.Pin()->SetContent(CreateRowContent(Pair.Key.ToSharedRef()));
			break;
		}
	}
}

TSharedRef<SHorizontalBox> SCutsceneBindingTreeWidget::CreateRowContent(const TSharedRef<FCutsceneBindingNode>& BindingNode)
{
	TSharedRef<SHorizontalBox> RowContent = SNew(SHorizontalBox)
		
		+ SHorizontalBox::Slot()
		.VAlign(VAlign_Center)
		.Padding(FMargin(0.f, 0.f, 5.f, 0.f))
		.AutoWidth()
		[
			SNew(SImage)
			.Image(BindingNode->Icon.GetIcon())
		]
		
		+ SHorizontalBox::Slot()
		.VAlign(VAlign_Center)
		.Padding(FMargin(0.f, 0.f, 5.f, 0.f))
		.AutoWidth()
		[
			SNew(STextBlock)
			.Text(FText::FromString(BindingNode->DisplayName))
		];

	// 只有Actor节点才显示标签
	if (BindingNode->NodeType == FCutsceneBindingNode::ENodeType::Actor)
	{
		if (TagManagerData.IsValid())
		{
			if (FActorTagInfo* ActorTagInfo = TagManagerData->FindActorByBindingID(BindingNode->BindingID))
			{
				const TArray<FName>& Tags = ActorTagInfo->Tags;
				for (const FName& TagName : Tags)
				{
					RowContent->AddSlot()
					          .VAlign(VAlign_Center)
					          .AutoWidth()
					          .Padding(FMargin(2.f, 0.f, 0.f, 0.f))
					[
						SNew(SObjectBindingTagWidget)
						.Text(FText::FromName(TagName))
					];
				}
			}
		}
	}
	return RowContent;
}

TSharedRef<ITableRow> SCutsceneBindingTreeWidget::OnGenerateRow(TSharedRef<FCutsceneBindingNode> BindingNode, const TSharedRef<STableViewBase>& TableViewBase)
{
	const TSharedRef<SBox> Box = SNew(SBox)
	.HeightOverride(22.0f)
	[
		CreateRowContent(BindingNode)
	];
	
	NodeToWidgetMap.Add(BindingNode, Box);
	
	return SNew(STableRow<TSharedRef<FCutsceneBindingNode>>, TableViewBase)
	[
		Box
	];
}


#undef LOCTEXT_NAMESPACE
