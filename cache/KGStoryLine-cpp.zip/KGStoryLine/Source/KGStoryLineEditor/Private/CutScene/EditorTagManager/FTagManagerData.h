// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "CoreMinimal.h"
#include "CutScene/CutSceneEditorSettings.h"
#include "ISequencer.h"
#include "LevelSequence.h"
#include "MovieSceneObjectBindingID.h"

struct FActorTagInfo
{
	/** 名称 */
	FString ActorName;
	
	/** 图标 */
	FSlateIcon ActorIcon;
	
	/** Binding ID */
	FMovieSceneObjectBindingID BindingID;
	
	/** 适用类型 */
	ECutsceneTagFitType FitType = ECutsceneTagFitType::Spawnable;
	
	/** 绑定的Actor实例 */
	TWeakObjectPtr<AActor> BindingActor;
	
	/** 已拥有的标签 */
	TArray<FName> Tags;

	void AddTag(const FName& Tag)
	{
		if (!Tags.Contains(Tag))
			Tags.Add(Tag);
	}

	void RemoveTag(const FName& TagName)
	{
		Tags.Remove(TagName);
	}

	bool HasTag(const FName& TagName) const
	{
		return Tags.Contains(TagName);
	}
	
	bool IsFitTag(const ECutsceneTagFitType InFitType) const
	{
		return static_cast<int32>(FitType) <= static_cast<int32>(InFitType);
	}
};

/** Sequence标签信息 */
struct FSequenceTagInfo
{
	FString SequenceName;      // Sequence名称
	FString SequencePath;      // Sequence路径
	TArray<FActorTagInfo> Actors; // Sequence中的角色列表
	TWeakObjectPtr<ULevelSequence> Sequence; // Sequence引用
	FGuid SubSequenceSignature; // SubSequence标识符
	TArray<FSequenceTagInfo> ChildSequences; // 子Sequence列表
	
	FActorTagInfo* FindActor(const FMovieSceneObjectBindingID& BindingID);
	
	bool ForeachActor(const TFunction<bool(FSequenceTagInfo&, FActorTagInfo&)>& Func);
};

/** 标签管理器数据 */
struct FTagManagerData
{
	// 弱引用到Sequencer
	TWeakPtr<ISequencer> WeakSequencer;
	
	// 弱引用到根LevelSequence
	TWeakObjectPtr<ULevelSequence> WeakRootSequence;
	
	FSequenceTagInfo RootSequence; // 根Sequence
	TArray<FCutsceneTagDefine> QuickTags; // 常用Tags
	FMovieSceneObjectBindingID CurrentActorID;        // 当前选中的角色ID
	TMap<int32, FString> FacadeControlIDs;

	// 默认快捷标签
	static TArray<FCutsceneTagDefine> GetDefaultQuickTags()
	{
		const UCutsceneEditorAssetSettings* Settings = GetDefault<UCutSceneEditorSettings>()->GetAssetSettingsChecked();
		return Settings->Tags;
	}

	FTagManagerData()
	{
		QuickTags = GetDefaultQuickTags();
		UE_LOG(LogTemp, Warning, TEXT("FTagManagerData::FTagManagerData()"));
	}
	
	~FTagManagerData()
	{
		UE_LOG(LogTemp, Warning, TEXT("FTagManagerData::~FTagManagerData()"));
	}

	// ======== 数据管理方法 ========
	
	/** 使用ISequencer和ULevelSequence初始化 */
	bool Initialize(const TSharedRef<ISequencer>& InSequencer, ULevelSequence* InRootSequence);
	void Reinitialize();
	
	/** 从LevelSequence构建层级结构 */
	void BuildHierarchyFromSequence(FSequenceTagInfo& SequenceInfo, const FGuid& Signature, ULevelSequence* InSequence, const TMap<FMovieSceneObjectBindingID, TArray<FName>>& BindingTags);
	
	/** 有一些Possessable是Spawnable来的 */
	void BuildPossessableSpawnable(FSequenceTagInfo& SequenceInfo, const FGuid& Signature, ULevelSequence* InSequence, const TMap<FMovieSceneObjectBindingID, TArray<FName>>& BindingTags);
	
	/** 设置当前选中的角色 */
	void SetCurrentActor(const FMovieSceneObjectBindingID& BindingID);

	/** 获取当前选中的角色 */
	FActorTagInfo* GetCurrentActor();
	FMovieSceneSequenceID FindSequenceIDBySequence(const ULevelSequence* InSequence, const FGuid& Signature) const;
	FSequenceTagInfo*  FindSequenceDataByActor(const FMovieSceneObjectBindingID& BindingID);

	/** 添加标签到当前角色 */
	bool AddTagToCurrentActor(const FName& Tag);

	/** 从当前角色移除标签 */
	bool RemoveTagFromCurrentActor(const FName& TagName);

	/** 获取当前角色的标签列表 */
	TArray<FName> GetCurrentActorTags();

	/** 获取快捷标签列表, 当前角色已经拥有的Tag除外 */
	TArray<FCutsceneTagDefine> GetCurrentQuickTags();

	FActorTagInfo* FindActorByBindingID(FMovieSceneObjectBindingID BindingID);
	void BuildActorSimpleList(TArray<FString>& OutActorDisplayNames, TArray<FMovieSceneObjectBindingID>& OutActorIDs);

	// 自动规范大小写
	static void AutoAdjustTagCase(const ULevelSequence* InSequence);
	
private:
	TSet<FGuid> TempSpawnableGuids;
};