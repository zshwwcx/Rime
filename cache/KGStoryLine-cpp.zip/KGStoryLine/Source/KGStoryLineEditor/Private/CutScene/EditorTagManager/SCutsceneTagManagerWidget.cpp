// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#include "CutScene/EditorTagManager/SCutsceneTagManagerWidget.h"

#include "Editor.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "MovieSceneSequence.h"
#include "LevelSequence.h"
#include "ISequencer.h"
#include "CutScene/EditorTagManager/SCutsceneBindingTreeWidget.h"
#include "SObjectBindingTag.h"
#include "CutScene/EditorTagManager/SObjectBindingTagWidget.h"
#include "Compilation/MovieSceneCompiledDataManager.h"
#include "Engine/World.h"
#include "Sections/MovieSceneSubSection.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "Tracks/MovieSceneSubTrack.h"
#include "SlateOptMacros.h"
#include "CutScene/Utils/FCutsceneEditorUtils.h"

#define LOCTEXT_NAMESPACE "SC7TagManagerWidget"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION

SCutsceneTagManagerWidget::SCutsceneTagManagerWidget()
	: TagManagerData(MakeShared<FTagManagerData>())
{
}

void SCutsceneTagManagerWidget::Construct(const FArguments& InArgs, const TSharedRef<ISequencer>& Sequencer, const FMovieSceneObjectBindingID& CurrentActorBindingID)
{
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(Sequencer->GetRootMovieSceneSequence());
	if (!LevelSequence)
		return;
	
	TagManagerData->Initialize(Sequencer, LevelSequence);
	TagManagerData->SetCurrentActor(CurrentActorBindingID);
	
	ChildSlot
	[
		SNew(SSplitter)
		.Orientation(Orient_Horizontal)

		+ SSplitter::Slot()
		.Resizable(true)
		.Value(0.4f)
		[
			SAssignNew(TreeWidget, SCutsceneBindingTreeWidget, Sequencer, TagManagerData)
				.OnActorSelected(this, &SCutsceneTagManagerWidget::HandleActorSelectedFromTree)
		]

		+ SSplitter::Slot()
		.Resizable(true)
		.Value(0.6f)
		[
			SNew(SBox)
			[
				SNew(SVerticalBox)
				
				// 头部栏
				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SBorder)
					[
						SNew(SHorizontalBox)

						+ SHorizontalBox::Slot()
						.AutoWidth()
						.VAlign(VAlign_Center)
						[
							SNew(STextBlock)
							.Text(LOCTEXT("SelectActor", "选择Actor:"))
						]
						
						+ SHorizontalBox::Slot()
						.FillWidth(1)
						.VAlign(VAlign_Center)
						.Padding(5, 0)
						[
							SAssignNew(ActorComboBox, STextComboBox)
							.OptionsSource(&ActorOptions)
							.OnSelectionChanged(this, &SCutsceneTagManagerWidget::HandleActorSelectionChanged)
							.ToolTipText(LOCTEXT("ActorComboBoxTooltip", "选择要管理标签的Actor"))
						]

						// 刷新按钮
						+ SHorizontalBox::Slot()
						.AutoWidth()
						.VAlign(VAlign_Fill)
						.HAlign(HAlign_Right)
						[
							SNew(SButton)
							.OnClicked_Lambda([this]
							{
								this->PostRedo(true);
								return FReply::Handled();
							})
							[
								SNew(SImage)
								.Image(FAppStyle::GetBrush("Icons.Refresh"))
							]
						]
						
						// Docs 链接按钮
						+ SHorizontalBox::Slot()
						.AutoWidth()
						.VAlign(VAlign_Fill)
						.HAlign(HAlign_Right)
						[
							SNew(SButton)
							.OnClicked_Lambda([]
							{
								FPlatformProcess::LaunchURL(TEXT("https://docs.corp.kuaishou.com/d/home/fcADWFYqJN4MqSaC_1KRL-clM"), nullptr, nullptr);
								return FReply::Handled();
							})
							[
								SNew(SImage)
								.Image(FAppStyle::GetBrush("Icons.Help"))
							]
						]
						
						// 设置按钮
						+ SHorizontalBox::Slot()
						.AutoWidth()
						.VAlign(VAlign_Fill)
						.HAlign(HAlign_Right)
						[
							SNew(SButton)
							.OnClicked_Lambda([]
							{
								UCutsceneEditorAssetSettings* Settings = UCutSceneEditorSettings::GetAssetSettingsChecked();
								GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(Settings);
								return FReply::Handled();
							})
							[
								SNew(SImage)
								.Image(FAppStyle::GetBrush("Icons.Toolbar.Settings"))
							]
						]
					]
				]

				// 已添加标签
				+ SVerticalBox::Slot()
				.AutoHeight()
				.FillHeight(0.33)
				[
					SNew(SBorder)
					[
						SNew(SBox)
						.Padding(5)
						.MinDesiredHeight(100)
						[
							SNew(SVerticalBox)
						
							+ SVerticalBox::Slot()
							.AutoHeight()
							[
								SNew(STextBlock)
								.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12)) // 设置大小
								.Text(LOCTEXT("AddedTag", "已添加Tag:"))
							]
				
							+ SVerticalBox::Slot()
							.Padding(0, 5)
							.VAlign(VAlign_Fill)
							[
								SAssignNew(AddedTagsWrapBox, SWrapBox)
								.UseAllottedSize(true)
							]
						]
					]
				]
				
				// 快捷添加
				+ SVerticalBox::Slot()
				.AutoHeight()
				.FillHeight(0.33)
				[
					SNew(SBorder)
					[
						SNew(SBox)
						.Padding(5)
						.MinDesiredHeight(100)
						[
							SNew(SVerticalBox)
							
							+ SVerticalBox::Slot()
							.AutoHeight()
							[
								SNew(STextBlock)
								.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12)) // 设置大小
								.Text(LOCTEXT("QuickAddTitle", "快捷添加:"))
							]
							
							+ SVerticalBox::Slot()
							.Padding(0, 5)
							.VAlign(VAlign_Fill)
							[
								SAssignNew(QuickTagsWrapBox, SWrapBox)
								.UseAllottedSize(true)
							]
						]
					]
				]
				
				// 格式添加
				+ SVerticalBox::Slot()
				.AutoHeight()
				.FillHeight(0.33)
				[
					SNew(SBorder)
					[
						SNew(SBox)
						.Padding(5)
						[
							SNew(SVerticalBox)
							
							+ SVerticalBox::Slot()
							.AutoHeight()
							[
								SNew(STextBlock)
								.Font(FCoreStyle::GetDefaultFontStyle("Bold", 12)) // 设置大小
								.Text(LOCTEXT("FormatAddTitle", "格式添加:"))
							]
							
							+ SVerticalBox::Slot()
							.AutoHeight()
							[
								SNew(SVerticalBox)

								// 任意输入
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 5)
								[
									SNew(SHorizontalBox)
									+ SHorizontalBox::Slot()
									.FillWidth(0.2)
									[
										SNew(STextBlock).Text(LOCTEXT("Any", "任意输入:"))
									]
									
									+ SHorizontalBox::Slot()
									.FillWidth(1)
									[
										SAssignNew(InputAnyTag, SEditableTextBox)
										.OnTextCommitted_Lambda([this](const FText& InText, ETextCommit::Type CommitType)
										{
											if (CommitType == ETextCommit::OnEnter)
											{
												HandleAddTag(InText.ToString());
												FSlateApplication::Get().SetKeyboardFocus(InputAnyTag.ToSharedRef());
											}
										})
									]
									+ SHorizontalBox::Slot()
									.AutoWidth()
									[
										SNew(SButton).Text(LOCTEXT("Add", "添加"))
										.OnClicked_Lambda([this]
										{
											return HandleAddTag(InputAnyTag->GetText().ToString());
										})
									]
								]

								// NPC
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 5)
								[
									SNew(SHorizontalBox)
									+ SHorizontalBox::Slot()
									.FillWidth(0.2)
									[
										SNew(STextBlock)
										.Text(LOCTEXT("NPCLabel", "NPC_"))
									]
									
									+ SHorizontalBox::Slot()
									.FillWidth(1)
									[
										SAssignNew(InputNPCTag, SEditableTextBox)
										.OnTextCommitted_Lambda([this](const FText& InText, ETextCommit::Type CommitType)
										{
											if (CommitType == ETextCommit::OnEnter)
											{
												HandleAddTag(TEXT("NPC_") + InText.ToString());
												FSlateApplication::Get().SetKeyboardFocus(InputNPCTag.ToSharedRef());
											}
										})
									]
									+ SHorizontalBox::Slot()
									.AutoWidth()
									[
										SNew(SButton).Text(LOCTEXT("Add", "添加"))
										.OnClicked_Lambda([this]
										{
											return HandleAddTag(TEXT("NPC_") + InputNPCTag->GetText().ToString());
										})
									]
								]

								// Object
								+ SVerticalBox::Slot()
								.AutoHeight()
								.Padding(0, 5)
								[
									SNew(SHorizontalBox)
									
									+ SHorizontalBox::Slot()
									.FillWidth(0.2)
									[
										SNew(STextBlock)
										.Text(LOCTEXT("ObjectLabel", "Object_"))
									]
									
									+ SHorizontalBox::Slot()
									.FillWidth(1)
									[
										SAssignNew(InputObjectTag, SEditableTextBox)
										.OnTextCommitted_Lambda([this](const FText& InText, ETextCommit::Type CommitType)
										{
											if (CommitType == ETextCommit::OnEnter)
											{
												HandleAddTag(TEXT("Object_") + InText.ToString());
												FSlateApplication::Get().SetKeyboardFocus(InputObjectTag.ToSharedRef());
											}
										})
									]
									+ SHorizontalBox::Slot()
									.AutoWidth()
									[
										SNew(SButton).Text(LOCTEXT("Add", "添加"))
										.OnClicked_Lambda([this]
										{
											return HandleAddTag(TEXT("Object_") + InputObjectTag->GetText().ToString());
										})
									]
								]
							]
						]
					]
				]
			]
		]
	];

	// 初始化 UI
	RebuildActorComboBox();
	RebuildTagList();
}

void SCutsceneTagManagerWidget::PostUndo(bool bSuccess)
{
	TagManagerData->Reinitialize();
	RebuildActorComboBox();
	RebuildTagList();
	if (TreeWidget)
		TreeWidget->ForceRefreshTreeView();
}

void SCutsceneTagManagerWidget::PostRedo(bool bSuccess)
{
	TagManagerData->Reinitialize();
	RebuildActorComboBox();
	RebuildTagList();
	if (TreeWidget)
		TreeWidget->ForceRefreshTreeView();
}

END_SLATE_FUNCTION_BUILD_OPTIMIZATION

void SCutsceneTagManagerWidget::RebuildTagList()
{
	RebuildAddedTagList();
	RebuildQuickTagList();
}

void SCutsceneTagManagerWidget::RebuildAddedTagList()
{
	AddedTagsWrapBox->ClearChildren();

	FActorTagInfo* CurrentActor = TagManagerData->GetCurrentActor();
	if (!CurrentActor)
	{
		return;
	}

	for (const FName& TagName : CurrentActor->Tags)
	{
		if (const FCutsceneTagDefine* FoundDefine = TagManagerData->QuickTags.FindByPredicate([TagName](const FCutsceneTagDefine& InTag) { return InTag.TagName == TagName; }))
		{
			if (!CurrentActor->IsFitTag(FoundDefine->FitType))
			{
				FCutsceneEditorUtils::CreateNotification(FText::FromString(FString::Printf(
					TEXT("标签'%s'仅适用于'%s' \n当前Actor类型为'%s', 不适配Tag类型, 可能无效"), 
					*TagName.ToString(),
					*FoundDefine->GetAllFitTypeString(),
					*FoundDefine->GetFitTypeString(CurrentActor->FitType)
				)), false, 5, 10);
			}
		}
		AddedTagsWrapBox->AddSlot()
		[
			SNew(SObjectBindingTagWidget)
			.Text(FText::FromName(TagName))
			.OnDeleted(this, &SCutsceneTagManagerWidget::HandleRemoveTag, TagName)
		];
	}
}

void SCutsceneTagManagerWidget::RebuildQuickTagList()
{
	QuickTagsWrapBox->ClearChildren();
	
	FActorTagInfo* CurrentActor = TagManagerData->GetCurrentActor();
	if (!CurrentActor)
		return;
	
	for (const FCutsceneTagDefine& TagName : TagManagerData->GetCurrentQuickTags())
	{
		if (!CurrentActor->IsFitTag(TagName.FitType))
			continue;
		
		QuickTagsWrapBox->AddSlot()
		[
			SNew(SObjectBindingTagWidget)
			// .ColorTint(BindingCache->GetTagColor(TagName))
			.Text(FText::FromName(TagName.TagName))
			.ToolTipText(TagName.TipInfo)
			.OnAdded(this, &SCutsceneTagManagerWidget::HandleQuickTagClicked, TagName.TagName)
		];
	}
}

FReply SCutsceneTagManagerWidget::HandleAddTag(const FString& NewTag)
{
	if (NewTag.IsEmpty()) 
		return FReply::Handled();
	
	TagManagerData->AddTagToCurrentActor(FName(*NewTag));
	RebuildTagList();
	if (TreeWidget)
		TreeWidget->RefreshCurrentItem(TagManagerData->CurrentActorID);
	
	return FReply::Handled();
}

void SCutsceneTagManagerWidget::HandleRemoveTag(const FName TagName)
{
	TagManagerData->RemoveTagFromCurrentActor(TagName);
	RebuildTagList();
	if (TreeWidget)
		TreeWidget->RefreshCurrentItem(TagManagerData->CurrentActorID);
}

void SCutsceneTagManagerWidget::HandleQuickTagClicked(const FName TagName)
{
	TagManagerData->AddTagToCurrentActor(TagName);
	RebuildTagList();
	if (TreeWidget)
		TreeWidget->RefreshCurrentItem(TagManagerData->CurrentActorID);
}

void SCutsceneTagManagerWidget::RebuildActorComboBox()
{
	ActorOptions.Reset();

	// 获取所有Actor的显示名称
	TArray<FString> OutActorDisplayNames;
	TagManagerData->BuildActorSimpleList(OutActorDisplayNames, ActorBindingIDs);
	
	if (OutActorDisplayNames.Num() == 0)
	{
		// 如果没有Actor，添加一个占位符选项
		ActorOptions.Add(MakeShared<FString>(TEXT("无可用Actor")));
	}
	else
	{
		// 添加所有Actor到选项列表
		for (const FString& DisplayName : OutActorDisplayNames)
		{
			ActorOptions.Add(MakeShared<FString>(DisplayName));
		}
	}

	// 刷新下拉框
	if (ActorComboBox.IsValid())
	{
		ActorComboBox->RefreshOptions();

		const int32 Index = ActorBindingIDs.IndexOfByKey(TagManagerData->CurrentActorID);
		if (Index >= 0)
			ActorComboBox->SetSelectedItem(ActorOptions[Index]);
		else if (ActorOptions.Num() > 0)
			ActorComboBox->SetSelectedItem(ActorOptions[0]);
	}
}

void SCutsceneTagManagerWidget::HandleActorSelectionChanged(TSharedPtr<FString> ActorDisplayName, ESelectInfo::Type)
{
	if (!ActorDisplayName.IsValid()) return;
	
	const int32 Index = ActorOptions.IndexOfByKey(ActorDisplayName);
	if (Index >= 0 && Index < ActorBindingIDs.Num())
	{
		TagManagerData->SetCurrentActor(ActorBindingIDs[Index]);
	}
	RebuildTagList();
}

void SCutsceneTagManagerWidget::HandleActorSelectedFromTree(FMovieSceneObjectBindingID SelectedActorBindingID)
{
	TagManagerData->SetCurrentActor(SelectedActorBindingID);
	RebuildActorComboBox();
	RebuildTagList();
	
	if (TagManagerData->WeakSequencer.IsValid())
	{
		const TSharedPtr<ISequencer> Sequencer = TagManagerData->WeakSequencer.Pin();
		// Sequencer->EmptySelection();
		// Sequencer->SelectObject(SelectedActorBindingID.GetGuid());
	}
}

#undef LOCTEXT_NAMESPACE
