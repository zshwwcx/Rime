// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#include "CutScene/EditorTagManager/FTagManagerData.h"

#include "KGStoryLineEditorModule.h"
#include "ScopedTransaction.h"
#include "Bindings/MovieSceneSpawnableActorBinding.h"
#include "Compilation/MovieSceneCompiledDataManager.h"
#include "CutScene/Utils/FCutsceneEditorUtils.h"
#include "Sections/MovieSceneSubSection.h"
#include "Styling/SlateIconFinder.h"
#include "Tracks/MovieSceneSubTrack.h"

#define LOCTEXT_NAMESPACE "SC7TagManagerWidget"

FActorTagInfo* FSequenceTagInfo::FindActor(const FMovieSceneObjectBindingID& BindingID)
{
	FActorTagInfo* Ret = Actors.FindByPredicate([&BindingID](const FActorTagInfo& Actor) { return Actor.BindingID == BindingID; });
	if (!Ret)
	{
		for (FSequenceTagInfo& ChildSequence : ChildSequences)
		{
			Ret = ChildSequence.FindActor(BindingID);
			if (Ret) break;
		}
	}
	return Ret;
}

bool FSequenceTagInfo::ForeachActor(const TFunction<bool(FSequenceTagInfo&, FActorTagInfo&)>& Func)
{
	for (FActorTagInfo& Actor : Actors)
	{
		if (Func(*this, Actor))
			return true;
	}
	
	for (FSequenceTagInfo& ChildSequence : ChildSequences)
	{
		if (ChildSequence.ForeachActor(Func))
			return true;
	}
	
	return false;
}

bool FTagManagerData::Initialize(const TSharedRef<ISequencer>& InSequencer, ULevelSequence* InRootSequence)
{
	if (!InRootSequence)
		return false;
	
	WeakSequencer = InSequencer;
	WeakRootSequence = InRootSequence;

	const UMovieScene* MovieScene = InRootSequence->MovieScene; 
	if (!MovieScene)
		return false;
	
	AutoAdjustTagCase(InRootSequence);
	
	TMap<FName, FMovieSceneObjectBindingIDs> Tuples = MovieScene->AllTaggedBindings();
	TMap<FMovieSceneObjectBindingID, TArray<FName>> BindingTags;
	for (const auto& Tuple : Tuples)
	{
		for (const FMovieSceneObjectBindingID& ID : Tuple.Value.IDs)
		{
			TArray<FName>& Names = BindingTags.FindOrAdd(ID);
			if (!Names.Contains(Tuple.Key))
				Names.Add(Tuple.Key);
		}
	}
	
	BuildHierarchyFromSequence(RootSequence, FGuid(), InRootSequence, BindingTags);
	BuildPossessableSpawnable(RootSequence, FGuid(), InRootSequence, BindingTags);
	
	CurrentActorID = FMovieSceneObjectBindingID();

	if (FacadeControlIDs.IsEmpty())
	{
		FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
		TSharedPtr<FCutSceneEditor> CutSceneEditor = KGStoryLineEditorModule.GetCutsceneEditor();
		if (CutSceneEditor != nullptr)
		{
			CutSceneEditor->GetFacadeControlIDs(FacadeControlIDs);
		}
	}
	
	return true;
}

void FTagManagerData::Reinitialize()
{
	if (WeakRootSequence.IsValid() && WeakSequencer.IsValid())
	{
		Initialize(WeakSequencer.Pin().ToSharedRef(), WeakRootSequence.Get());
	}
}

void FTagManagerData::BuildHierarchyFromSequence(FSequenceTagInfo& SequenceInfo, const FGuid& Signature, ULevelSequence* InSequence, const TMap<FMovieSceneObjectBindingID, TArray<FName>>& BindingTags)
{
	if (!InSequence->IsValidLowLevel())
		return;
	
	SequenceInfo.Sequence = InSequence;
	SequenceInfo.SequenceName = InSequence->GetName();
	SequenceInfo.SequencePath = InSequence->GetPathName();
	SequenceInfo.SubSequenceSignature = Signature;
	SequenceInfo.ChildSequences.Reset();
	SequenceInfo.Actors.Reset();
	
	UMovieScene* MovieScene = InSequence->GetMovieScene(); 
	if (!MovieScene)
		return;
	
	const FMovieSceneBindingReferences* BindingReferences = InSequence->GetBindingReferences();
	if (!BindingReferences)
		return;
	
	const FMovieSceneSequenceID& SequenceID = FindSequenceIDBySequence(InSequence, Signature);
	if (!SequenceID.IsValid())
		return;
	
	const UCutsceneEditorAssetSettings* Settings = UCutSceneEditorSettings::GetAssetSettingsChecked();
	TArray<UClass*> IgnoredActorTypes;
	for (auto IgnoredActorType : Settings->IgnoredActorTypes)
	{
		if (UClass* Class = IgnoredActorType.LoadSynchronous())
			IgnoredActorTypes.Add(Class);
	}
	
	const TArrayView<const FMovieSceneBindingReference>& ReferenceArray = BindingReferences->GetAllReferences();
	for (const FMovieSceneBindingReference& Reference : ReferenceArray)
	{
		AActor* Actor = nullptr;
		ECutsceneTagFitType FitType;
		if (UMovieSceneSpawnableActorBinding* ActorBinding = Cast<UMovieSceneSpawnableActorBinding>(Reference.CustomBinding))
		{
			Actor = Cast<AActor>(ActorBinding->GetObjectTemplate());
			FitType = ECutsceneTagFitType::Spawnable;
		}
		else
		{
			Actor = Cast<AActor>(Reference.Locator.SyncLoad());
			FitType = ECutsceneTagFitType::Possessable;
		}
		
		if (Actor)
		{
			if (IgnoredActorTypes.FindByPredicate(
				[&Actor](const UClass* Class){return Actor->IsA(Class);}))
				continue;
			
			FActorTagInfo& ActorInfo = SequenceInfo.Actors.AddDefaulted_GetRef();
			ActorInfo.BindingID = UE::MovieScene::FRelativeObjectBindingID(Reference.ID, SequenceID, -1);
			ActorInfo.ActorName = Actor->GetActorLabel();
			ActorInfo.Tags = BindingTags.FindRef(ActorInfo.BindingID);
			ActorInfo.ActorIcon = FSlateIconFinder::FindIconForClass(Actor->GetClass());
			ActorInfo.FitType = FitType;
			
			if (FitType == ECutsceneTagFitType::Spawnable)
			{
				TempSpawnableGuids.Add(Reference.ID);
			}
		}
	}
	
	TArray<UMovieSceneTrack*> MovieSceneTracks = MovieScene->GetTracks();
	for (UMovieSceneTrack* MovieSceneTrack : MovieSceneTracks)
	{
		if (!MovieSceneTrack->IsA<UMovieSceneSubTrack>())
			continue;

		UMovieSceneSubTrack* SubTrack = Cast<UMovieSceneSubTrack>(MovieSceneTrack);
		for (UMovieSceneSection* Section : SubTrack->GetAllSections())
		{
			if (!Section->IsA<UMovieSceneSubSection>())
				continue;

			UMovieSceneSubSection* MovieSceneSubSection = Cast<UMovieSceneSubSection>(Section);
			ULevelSequence* ChildLevelSequence = Cast<ULevelSequence>(MovieSceneSubSection->GetSequence());
			if (!ChildLevelSequence)
				continue;

			FSequenceTagInfo& ChildSeq = SequenceInfo.ChildSequences.AddDefaulted_GetRef();
			BuildHierarchyFromSequence(ChildSeq, Section->GetSignature(), ChildLevelSequence, BindingTags);
		}
	}
}

void FTagManagerData::BuildPossessableSpawnable(FSequenceTagInfo& SequenceInfo, const FGuid& Signature, ULevelSequence* InSequence, const TMap<FMovieSceneObjectBindingID, TArray<FName>>& BindingTags)
{
	if (!InSequence->IsValidLowLevel())
		return;
	
	UMovieScene* MovieScene = InSequence->GetMovieScene(); 
	if (!MovieScene)
		return;
	
	const FMovieSceneSequenceID& SequenceID = FindSequenceIDBySequence(InSequence, Signature);
	if (!SequenceID.IsValid())
		return;
	
	const UCutsceneEditorAssetSettings* Settings = UCutSceneEditorSettings::GetAssetSettingsChecked();
	TArray<UClass*> IgnoredActorTypes;
	for (auto IgnoredActorType : Settings->IgnoredActorTypes)
	{
		if (UClass* Class = IgnoredActorType.LoadSynchronous())
			IgnoredActorTypes.Add(Class);
	}
	
	for (int i = 0; i < MovieScene->GetPossessableCount(); i++)
	{
		const FMovieScenePossessable& Possessable = MovieScene->GetPossessable(i);
		FMovieSceneObjectBindingID SpawnableObjectBindingID = Possessable.GetSpawnableObjectBindingID();
		if (SpawnableObjectBindingID.IsValid() && TempSpawnableGuids.Contains(SpawnableObjectBindingID.GetGuid()))
		{
			const UClass* ActorClass = Possessable.GetPossessedObjectClass();
			if (!ActorClass || !Cast<AActor>(ActorClass->GetDefaultObject()))
				continue;
			
			const AActor* Actor = Cast<AActor>(ActorClass->GetDefaultObject());
		
			if (IgnoredActorTypes.FindByPredicate(
				[&Actor](const UClass* Class){return Actor->IsA(Class);}))
				continue;
		
			FActorTagInfo& ActorInfo = SequenceInfo.Actors.AddDefaulted_GetRef();
			ActorInfo.BindingID = UE::MovieScene::FRelativeObjectBindingID(Possessable.GetGuid(), SequenceID, -1);
			ActorInfo.ActorName = Actor->GetActorLabel();
			ActorInfo.Tags = BindingTags.FindRef(ActorInfo.BindingID);
			ActorInfo.ActorIcon = FSlateIconFinder::FindIconForClass(Actor->GetClass());
			ActorInfo.FitType = ECutsceneTagFitType::PossessableSpawnable;
		}
	}
	
	int32 SeqIndex = 0;
	TArray<UMovieSceneTrack*> MovieSceneTracks = MovieScene->GetTracks();
	for (UMovieSceneTrack* MovieSceneTrack : MovieSceneTracks)
	{
		if (!MovieSceneTrack->IsA<UMovieSceneSubTrack>())
			continue;

		UMovieSceneSubTrack* SubTrack = Cast<UMovieSceneSubTrack>(MovieSceneTrack);
		for (UMovieSceneSection* Section : SubTrack->GetAllSections())
		{
			if (!Section->IsA<UMovieSceneSubSection>())
				continue;

			UMovieSceneSubSection* MovieSceneSubSection = Cast<UMovieSceneSubSection>(Section);
			ULevelSequence* ChildLevelSequence = Cast<ULevelSequence>(MovieSceneSubSection->GetSequence());
			if (!ChildLevelSequence)
				continue;
			
			if (SequenceInfo.ChildSequences.IsValidIndex(SeqIndex))
			{
				FSequenceTagInfo& ChildSeq = SequenceInfo.ChildSequences[SeqIndex++];
				BuildPossessableSpawnable(ChildSeq, Section->GetSignature(), ChildLevelSequence, BindingTags);				
			}
		}
	}
}

void FTagManagerData::SetCurrentActor(const FMovieSceneObjectBindingID& BindingID)
{
	CurrentActorID = BindingID;
}

FActorTagInfo* FTagManagerData::GetCurrentActor()
{
	return RootSequence.FindActor(CurrentActorID);
}

FMovieSceneSequenceID FTagManagerData::FindSequenceIDBySequence(const ULevelSequence* InSequence, const FGuid& Signature) const
{
	if (!WeakRootSequence.IsValid())
		return FMovieSceneSequenceID();
	
	const FMovieSceneCompiledDataID DataID = UMovieSceneCompiledDataManager::GetPrecompiledData()->Compile(WeakRootSequence.Get());
	const FMovieSceneSequenceHierarchy* Hierarchy = UMovieSceneCompiledDataManager::GetPrecompiledData()->FindHierarchy(DataID);
	if (!Hierarchy)
	{
		return MovieSceneSequenceID::Root;
	}
	
	if (InSequence == WeakRootSequence)
	{
		return MovieSceneSequenceID::Root;
	}

	for (const TPair<FMovieSceneSequenceID, FMovieSceneSubSequenceData>& Pair : Hierarchy->AllSubSequenceData())
	{
		if (Pair.Value.GetSequence() == InSequence && Pair.Value.GetSubSectionSignature() == Signature)
		{
			return Pair.Key;
		}
	}
	return FMovieSceneSequenceID();
}

FSequenceTagInfo* FTagManagerData::FindSequenceDataByActor(const FMovieSceneObjectBindingID& BindingID)
{
	FSequenceTagInfo* Ret = nullptr;
	RootSequence.ForeachActor([&BindingID, &Ret](FSequenceTagInfo& Seq, const FActorTagInfo& Actor)
	{
		if (Actor.BindingID == BindingID)
		{
			Ret = &Seq;
			return true;
		}
		return false;
	});
	
	return Ret;
}

bool FTagManagerData::AddTagToCurrentActor(const FName& Tag)
{
	if (!WeakRootSequence.IsValid() || !WeakSequencer.IsValid())
		return false;

	TObjectPtr<UMovieScene> MovieScene = WeakRootSequence->MovieScene;
	if (!MovieScene)
		return false;
	
	if (FacadeControlIDs.Num() > 0)
	{
		// 如果Tag是纯七位数字, 则判断是否在 FacadeControlIDs 中
		if (Tag.ToString().IsNumeric() && Tag.ToString().Len() == 7)
		{
			// 转换成int
			int32 FacadeControlID = FCString::Atoi(*Tag.ToString());
			if (!FacadeControlIDs.Contains(FacadeControlID))
			{
				FCutsceneEditorUtils::CreateNotification(FText::FromString(TEXT("FacadeControlID 不在配置表中，请检查ID是否正确")), false, 10, 10);
			}
		}
	}
	
	if (FActorTagInfo* CurrentActor = GetCurrentActor())
	{
		if (FSequenceTagInfo* SequenceData = FindSequenceDataByActor(CurrentActorID))
		{
			if (SequenceData->Sequence.IsValid())
			{
				FMovieSceneSequenceID MovieSceneSequenceID = FindSequenceIDBySequence(SequenceData->Sequence.Get(), SequenceData->SubSequenceSignature);
				if (MovieSceneSequenceID.IsValid())
				{
					FScopedTransaction Transaction(FText::Format(LOCTEXT("CreateBindingTag", "Add new tag {0} to binding(s)"), FText::FromName(Tag)));
					MovieScene->Modify();
					MovieScene->TagBinding(Tag, UE::MovieScene::FFixedObjectBindingID(
						CurrentActor->BindingID.GetGuid(), 
						CurrentActor->BindingID.GetRelativeSequenceID()
					));
					CurrentActor->AddTag(Tag);
					return true;
				}
			}
		}
	}
	return false;
}

bool FTagManagerData::RemoveTagFromCurrentActor(const FName& TagName)
{
	if (!WeakRootSequence.IsValid() || !WeakSequencer.IsValid())
		return false;

	TObjectPtr<UMovieScene> MovieScene = WeakRootSequence->MovieScene;
	if (!MovieScene)
		return false;
	
	if (FActorTagInfo* CurrentActor = GetCurrentActor())
	{
		if (FSequenceTagInfo* SequenceData = FindSequenceDataByActor(CurrentActorID))
		{
			if (SequenceData->Sequence.IsValid())
			{
				FMovieSceneSequenceID MovieSceneSequenceID = FindSequenceIDBySequence(SequenceData->Sequence.Get(), SequenceData->SubSequenceSignature);
				if (MovieSceneSequenceID.IsValid())
				{
					FScopedTransaction Transaction(FText::Format(LOCTEXT("RemoveBindingTag", "Remove tag {0} from binding(s)"), FText::FromName(TagName)));
					MovieScene->Modify();
					MovieScene->UntagBinding(TagName, UE::MovieScene::FFixedObjectBindingID(
						CurrentActor->BindingID.GetGuid(), 
						CurrentActor->BindingID.GetRelativeSequenceID()
					));
					CurrentActor->RemoveTag(TagName);
				}
			}
		}
	}
	return true;
}

TArray<FName> FTagManagerData::GetCurrentActorTags()
{
	if (const FActorTagInfo* CurrentActor = GetCurrentActor())
	{
		return CurrentActor->Tags;
	}
	return TArray<FName>();
}

TArray<FCutsceneTagDefine> FTagManagerData::GetCurrentQuickTags()
{
	TArray<FCutsceneTagDefine> Result = QuickTags;
	if (FActorTagInfo* CurrentActor = GetCurrentActor())
	{
		for (int i = Result.Num() - 1; i >= 0; --i)
		{
			if (CurrentActor->HasTag(Result[i].TagName))
			{
				Result.RemoveAt(i);
			}
		}
	}
	return Result;
}

FActorTagInfo* FTagManagerData::FindActorByBindingID(FMovieSceneObjectBindingID BindingID)
{
	FActorTagInfo* Ret = nullptr;
	RootSequence.ForeachActor([&BindingID, &Ret](FSequenceTagInfo& Seq, FActorTagInfo& Actor)
	{
		if (Actor.BindingID == BindingID)
		{
			Ret = &Actor;
			return true;
		}
		return false;
	});
	
	return Ret;
}

void FTagManagerData::BuildActorSimpleList(TArray<FString>& OutActorDisplayNames, TArray<FMovieSceneObjectBindingID>& OutActorIDs)
{
	OutActorDisplayNames.Reset();
	OutActorIDs.Reset();
	RootSequence.ForeachActor([&](const FSequenceTagInfo& Seq, const FActorTagInfo& Actor)
	{
		OutActorDisplayNames.Add(FString::Printf(TEXT("%s: %s"), *Seq.SequenceName, *Actor.ActorName));
		OutActorIDs.Add(Actor.BindingID);
		return false;
	});
}

void FTagManagerData::AutoAdjustTagCase(const ULevelSequence* InSequence)
{
	if (GIsTransacting)
		return;
	
	if (!InSequence)
		return;
	
	UMovieScene* MovieScene = InSequence->MovieScene;
	if (!MovieScene)
		return;

	const UCutsceneEditorAssetSettings* Settings = UCutSceneEditorSettings::GetAssetSettingsChecked();
	const TArray<FCutsceneTagDefine>& TagDefines = Settings->Tags;
	
	FScopedTransaction Transaction(LOCTEXT("AdjustTagCase", "Adjust Tag Case"));
	bool bChanged = false;
	TMap<FName, FMovieSceneObjectBindingIDs> AllTags = MovieScene->AllTaggedBindings();
	for (auto& Pair : AllTags)
	{
		if (const FCutsceneTagDefine* Define = TagDefines.FindByPredicate([&Pair](const FCutsceneTagDefine& D){ return D.TagName == Pair.Key; }))
		{
			if (!Pair.Key.IsEqual(Pair.Key, ENameCase::CaseSensitive))
			{
				for (const FMovieSceneObjectBindingID& ID : Pair.Value.IDs)
				{
					UE::MovieScene::FFixedObjectBindingID Binding(ID.GetGuid(), ID.GetRelativeSequenceID());
					MovieScene->UntagBinding(Pair.Key, Binding);
					MovieScene->TagBinding(Define->TagName, Binding);
					bChanged = true;
				}
			}
		}
	}
	
	if (bChanged)
		MovieScene->Modify();
	else
		Transaction.Cancel();
}

#undef LOCTEXT_NAMESPACE
