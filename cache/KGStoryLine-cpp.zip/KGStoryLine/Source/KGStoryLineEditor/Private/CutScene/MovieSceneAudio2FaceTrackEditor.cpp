#include "CutScene/MovieSceneAudio2FaceTrackEditor.h"

#include "ISequencer.h"
#include "LevelSequence.h"
#include "SequencerSectionPainter.h"
#include "EditorStyleSet.h"
#include "Misc/KGCoreEditorFunctionLibrary.h"
#include "KGEditorStyle.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "CutScene/MovieSceneAudio2FaceTrack.h"
#include "CutScene/ACutSceneActor.h"
#include "3C/Character/BaseCharacter.h"
#include "CutScene/MovieSceneAudio2FaceSection.h"
#include "CutScene/CutSceneDefine.h"

#define LOCTEXT_NAMESPACE "MovieSceneAudio2FaceTrackEditor"

FMovieSceneAudio2FaceTrackEditor::FMovieSceneAudio2FaceTrackEditor(TSharedRef<ISequencer> InSequencer)
	: FMovieSceneTrackEditor(InSequencer)
{
}

FMovieSceneAudio2FaceTrackEditor::~FMovieSceneAudio2FaceTrackEditor()
{
}

const FSlateBrush* FMovieSceneAudio2FaceTrackEditor::GetIconBrush() const
{
	return FAppStyle::GetBrush(TEXT("SocketIcon.Bone"));
}

TSharedRef<ISequencerSection> FMovieSceneAudio2FaceTrackEditor::MakeSectionInterface(UMovieSceneSection& SectionObject,
	UMovieSceneTrack& Track,
	FGuid ObjectBinding)
{
	check(SupportsType(SectionObject.GetOuter()->GetClass()));
	return MakeShareable(new FMovieSceneAudio2FaceSection(SectionObject, GetSequencer()));
}

bool FMovieSceneAudio2FaceTrackEditor::SupportsType(TSubclassOf<UMovieSceneTrack> Type) const
{
	return Type == UMovieSceneAudio2FaceTrack::StaticClass();
}

bool FMovieSceneAudio2FaceTrackEditor::SupportsSequence(UMovieSceneSequence* InSequence) const
{
	return InSequence->IsA(ULevelSequence::StaticClass());
}

bool FMovieSceneAudio2FaceTrackEditor::IsResizable(UMovieSceneTrack* InTrack) const
{
	return false;
}

bool FMovieSceneAudio2FaceTrackEditor::OnAllowDrop(const FDragDropEvent& DragDropEvent,
	FSequencerDragDropParams& DragDropParams)
{
	return false;
}

FReply FMovieSceneAudio2FaceTrackEditor::OnDrop(const FDragDropEvent& DragDropEvent,
	const FSequencerDragDropParams& DragDropParams)
{
	return FReply::Handled();
}

void FMovieSceneAudio2FaceTrackEditor::BuildAddTrackMenu(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.AddMenuEntry(
		LOCTEXT("AddAudio2FaceTrack_BuildAddTrackMenu", "Audio2Face"),
		LOCTEXT("AddAudio2FaceTrackTooltip_BuildAddTrackMenu", "Audio2Face."),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateLambda([=, this]
			{
				auto FocusedMovieScene = GetFocusedMovieScene();

				if (FocusedMovieScene == nullptr)
				{
					return;
				}

				const FScopedTransaction Transaction(LOCTEXT("AddAudio2FaceTrack_Transaction_BuildAddTrackMenu", "Audio2Face"));
				FocusedMovieScene->Modify();

				auto NewTrack = FocusedMovieScene->AddTrack<UMovieSceneAudio2FaceTrack>();
				ensure(NewTrack);
				//NewTrack->SetIsAMasterTrack(true);

				GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
			}))
	);
}

void FMovieSceneAudio2FaceTrackEditor::BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	auto ObjectBinding = ObjectBindings[0];

	if (ObjectClass->IsChildOf(ABaseCharacter::StaticClass()))
	{
		MenuBuilder.AddMenuEntry(
			LOCTEXT("AddAudio2FaceTrack_BuildObjectBindingTrackMenu", "AddAudio2FaceTrack"),
			LOCTEXT("AddAudio2FaceTrackTooltip_BuildObjectBindingTrackMenu", "Adds Audio2Face track."),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateLambda([this, ObjectBinding = MoveTemp(ObjectBinding)]
				{
					UMovieScene* FocusedMovieScene = GetFocusedMovieScene();

					if (FocusedMovieScene == nullptr)
					{
						return;
					}

					const FScopedTransaction Transaction(LOCTEXT("AddAudio2FaceTrack_Transaction_BuildObjectBindingTrackMenu", "Add Audio2Face Track"));
					FocusedMovieScene->Modify();

					const UMovieSceneAudio2FaceTrack* NewTrack = FocusedMovieScene->AddTrack<UMovieSceneAudio2FaceTrack>(ObjectBinding);
					ensure(NewTrack);

					GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
				}))
		);

		TSharedPtr<ISequencer> SequencerPtr = GetSequencer();
		if (SequencerPtr.IsValid())
		{
			if (UObject* Object = SequencerPtr->FindSpawnedObjectOrTemplate(ObjectBinding))
			{
				if (ABaseCharacter* Character = Cast<ABaseCharacter>(Object))
				{

					bool bAddConvertMan(true);
					bool bAddConvertWoman(true);
					if (Character->ActorHasTag(NAME_CutSceneActorSex_ManTag))
					{
						bAddConvertWoman = true;
						bAddConvertMan = false;
					}
					else if (Character->ActorHasTag(NAME_CutSceneActorSex_WomanTag))
					{
						bAddConvertMan = true;
						bAddConvertWoman = false;
					}

					{
						if (bAddConvertMan)
						{
							MenuBuilder.AddMenuEntry(
								LOCTEXT("Sex Select Man", "Sex Select Man"),
								LOCTEXT("Sex Select ManTooltip", "Sex Select Man"),
								FSlateIcon(),
								FUIAction(FExecuteAction::CreateLambda([this, ObjectBinding = MoveTemp(ObjectBinding), Character]
									{
										Character->Tags.Remove(NAME_CutSceneActorSex_WomanTag);
										Character->Tags.AddUnique(NAME_CutSceneActorSex_ManTag);
										FString ClassName = Character->GetClass()->GetName();
										ClassName.RemoveFromEnd("_C");
										FString Name = ClassName + "_" + FString::FromInt(Character->GetUniqueID());
										Character->SetActorLabel(Name + "_" + NAME_CutSceneActorSex_ManTag.ToString());
										GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
									}))
							);
						}
						if (bAddConvertWoman)
						{
							MenuBuilder.AddMenuEntry(
								LOCTEXT("Sex Select Woman", "Sex Select Woman"),
								LOCTEXT("Sex Select WomanTooltip", "Sex Select Woman"),
								FSlateIcon(),
								FUIAction(FExecuteAction::CreateLambda([this, ObjectBinding = MoveTemp(ObjectBinding), Character]
									{
										Character->Tags.Remove(NAME_CutSceneActorSex_ManTag);
										Character->Tags.AddUnique(NAME_CutSceneActorSex_WomanTag);

										FString ClassName = Character->GetClass()->GetName();
										ClassName.RemoveFromEnd("_C");
										FString Name = ClassName + "_" + FString::FromInt(Character->GetUniqueID());
										Character->SetActorLabel(Name + "_" + NAME_CutSceneActorSex_WomanTag.ToString());
										GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
									}))
							);
						}
					}
				}
			}
		}
	}
}

FMovieSceneAudio2FaceSection::FMovieSceneAudio2FaceSection(UMovieSceneSection& InSection,
	TWeakPtr<ISequencer> InSequencer)
	: Section(&InSection)
{

}

FMovieSceneAudio2FaceSection::~FMovieSceneAudio2FaceSection()
{
}

UMovieSceneSection* FMovieSceneAudio2FaceSection::GetSectionObject()
{
	return Section.Get();
}

FText FMovieSceneAudio2FaceSection::GetSectionTitle() const
{
	if (UMovieSceneSection* _Section = Section.Get())
	{
		if (UMovieSceneAudio2FaceSection* Audio2FaceSection = Cast<UMovieSceneAudio2FaceSection>(_Section))
		{
			return FText::FromString(Audio2FaceSection->FaceAnimID);
		}
	}

	return FText::FromString("Audio2Face Section");
}

FText FMovieSceneAudio2FaceSection::GetSectionToolTip() const
{
	return FText::FromString("Audio2Face Section");
}

float FMovieSceneAudio2FaceSection::GetSectionHeight() const
{
	return 30;
}

int32 FMovieSceneAudio2FaceSection::OnPaintSection(FSequencerSectionPainter& Painter) const
{
	return Painter.PaintSectionBackground();
}


void FMovieSceneAudio2FaceSection::BeginResizeSection()
{
}

void FMovieSceneAudio2FaceSection::ResizeSection(ESequencerSectionResizeMode ResizeMode,
	FFrameNumber ResizeTime)
{
	ISequencerSection::ResizeSection(ResizeMode, ResizeTime);
}

void FMovieSceneAudio2FaceSection::GenerateSectionLayout(class ISectionLayoutBuilder& LayoutBuilder)
{
}

void FMovieSceneAudio2FaceSection::BeginSlipSection()
{
}

void FMovieSceneAudio2FaceSection::SlipSection(FFrameNumber SlipTime)
{
	ISequencerSection::SlipSection(SlipTime);
}

#undef LOCTEXT_NAMESPACE
