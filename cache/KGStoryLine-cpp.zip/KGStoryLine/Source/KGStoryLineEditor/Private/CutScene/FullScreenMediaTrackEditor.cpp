#include "CutScene/FullScreenMediaTrackEditor.h"

#include "BinkMediaSource.h"
#include "CutScene/FullScreenMediaTrack.h"

#include "IContentBrowserSingleton.h"
#include "ContentBrowserModule.h"
#include "Sequencer/MediaTrackEditor.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "MVVM/Views/ViewUtilities.h"
#include "Runtime/MediaAssets/Public/MediaSource.h"

#define LOCTEXT_NAMESPACE "FFullScreenMediaTrackEditor"

FFullScreenMediaTrackEditor::FFullScreenMediaTrackEditor(TSharedRef<ISequencer> InSequencer)
	: FMediaTrackEditor(InSequencer)
{
}

bool FFullScreenMediaTrackEditor::SupportsType(TSubclassOf<UMovieSceneTrack> TrackClass) const
{
	return TrackClass.Get() && TrackClass.Get()->IsChildOf(UFullScreenMediaTrack::StaticClass());
}

FFullScreenMediaTrackEditor::~FFullScreenMediaTrackEditor()
{
}

void FFullScreenMediaTrackEditor::BuildAddTrackMenu(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.AddMenuEntry(
		LOCTEXT("AddTrack", "FullScreen Bink Media Track"),
		LOCTEXT("AddTooltip", "Adds a new media track that can play media sources."),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "Sequencer.Tracks.Media"),
		FUIAction(FExecuteAction::CreateRaw(this, &FFullScreenMediaTrackEditor::OnAddTrackClicked)));
}

TSharedPtr<SWidget> FFullScreenMediaTrackEditor::BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params)
{
	UFullScreenMediaTrack* MediaTrack = Cast<UFullScreenMediaTrack>(Track);

	if (MediaTrack == nullptr)
	{
		return SNullWidget::NullWidget;
	}

	auto CreatePicker = [this, MediaTrack]
	{
		UMovieSceneSequence* Sequence = GetSequencer() ? GetSequencer()->GetFocusedMovieSceneSequence() : nullptr;

		FAssetPickerConfig AssetPickerConfig;
		{
			AssetPickerConfig.OnAssetSelected = FOnAssetSelected::CreateLambda([this, MediaTrack](const FAssetData& AssetData)
			{
				this->AddNewSection(AssetData, MediaTrack);
			});
			AssetPickerConfig.OnAssetEnterPressed = FOnAssetEnterPressed::CreateLambda([this, MediaTrack](const TArray<FAssetData>& AssetData)
			{
				this->AddNewSectionEnterPressed(AssetData, MediaTrack);
			});
			AssetPickerConfig.bAllowNullSelection = false;
			AssetPickerConfig.bAddFilterUI = true;
			AssetPickerConfig.InitialAssetViewType = EAssetViewType::List;
			AssetPickerConfig.Filter.bRecursiveClasses = true;
			AssetPickerConfig.Filter.ClassPaths.Add(UBinkMediaSource::StaticClass()->GetClassPathName());
			AssetPickerConfig.SaveSettingsName = TEXT("SequencerAssetPicker");
			AssetPickerConfig.AdditionalReferencingAssets.Add(FAssetData(Sequence));
		}

		FContentBrowserModule& ContentBrowserModule = FModuleManager::Get().LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));

		TSharedRef<SBox> Picker = SNew(SBox)
			.WidthOverride(300.0f)
			.HeightOverride(300.f)
			[
				ContentBrowserModule.Get().CreateAssetPicker(AssetPickerConfig)
			];

		// Create menu.
		FMenuBuilder MenuBuilder(true, NULL);
		MenuBuilder.AddSubMenu(
			LOCTEXT("MediaSourceLabel", "Bink Media Source"),
			LOCTEXT("MediaSourceTooltip", "Add media from a media source."),
			FNewMenuDelegate::CreateLambda([Picker](FMenuBuilder& InMenuBuilder)
		{
			InMenuBuilder.AddWidget(Picker, FText::GetEmpty(), true);
		}));
		
		return MenuBuilder.MakeWidget();
	};

	return UE::Sequencer::MakeAddButton(LOCTEXT("AddMediaSection_Text", "Media"), FOnGetContent::CreateSPLambda(this, CreatePicker), Params.ViewModel);
}

bool FFullScreenMediaTrackEditor::HandleAssetAdded(UObject* Asset, const FGuid& TargetObjectGuid)
{
	return false;
}

void FFullScreenMediaTrackEditor::OnAddTrackClicked() const
{
	UMovieScene* FocusedMovieScene = GetFocusedMovieScene();
	if (FocusedMovieScene == nullptr || FocusedMovieScene->IsReadOnly())
		return;

	const FScopedTransaction Transaction(NSLOCTEXT("Sequencer", "AddMediaTrack_Transaction", "Add Media Track"));
	FocusedMovieScene->Modify();

	UFullScreenMediaTrack* NewTrack = FocusedMovieScene->AddTrack<UFullScreenMediaTrack>();
	ensure(NewTrack);
	NewTrack->SetDisplayName(LOCTEXT("MediaTrackName", "FullScreen Bink Media"));

	if (GetSequencer().IsValid())
	{
		GetSequencer()->OnAddTrack(NewTrack, FGuid());
	}
}
#undef LOCTEXT_NAMESPACE
