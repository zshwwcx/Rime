#include "CutScene/MovieSceneCustomTrackEditor.h"

#include "AnimatedRange.h"
#include "CutScene/CutSceneEditorSettings.h"
#include "Editor.h"
#include "ISequencer.h"
#include "LevelSequence.h"
#include "SequencerSectionPainter.h"
#include "EditorStyleSet.h"

#include "CutScene/MovieSceneCustomSection.h"
#include "CutScene/MovieSceneCustomTrack.h"

#include "CutScene/CustomSectionEditors/CustomSectionEditor.h"
#include "CutScene/CustomSectionEditors/SCustomSectionSetupPanel.h"
#include "CutScene/EditorTagManager/SCutsceneTagManagerWidget.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Modules/ModuleManager.h"
#include "MVVM/ViewModels/SequencerEditorViewModel.h"
#include "MVVM/Views/ViewUtilities.h"
#include "Widgets/Input/SButton.h"

#define LOCTEXT_NAMESPACE "FMovieSceneCustomTrackEditor"

TSharedRef<ISequencerTrackEditor> FMovieSceneCustomTrackEditor::CreateTrackEditor(TSharedRef<ISequencer> InSequencer)
{
	return MakeShareable(new FMovieSceneCustomTrackEditor(InSequencer));
}

FMovieSceneCustomTrackEditor::FMovieSceneCustomTrackEditor(TSharedRef<ISequencer> InSequencer)
	: FMovieSceneTrackEditor(InSequencer)
{
}

FMovieSceneCustomTrackEditor::~FMovieSceneCustomTrackEditor()
{
}

const FSlateBrush* FMovieSceneCustomTrackEditor::GetIconBrush() const
{
	return FAppStyle::GetBrush("DebugConsole.Icon");
}

TSharedRef<ISequencerSection> FMovieSceneCustomTrackEditor::MakeSectionInterface(UMovieSceneSection& SectionObject,
	UMovieSceneTrack& Track,
	FGuid ObjectBinding)
{
	check(SupportsType(SectionObject.GetOuter()->GetClass()));
	return MakeShareable(new FMovieSceneCustomSection(SectionObject, GetSequencer()));
}

bool FMovieSceneCustomTrackEditor::SupportsType(TSubclassOf<UMovieSceneTrack> Type) const
{
	return Type == UMovieSceneCustomTrack::StaticClass();
}

bool FMovieSceneCustomTrackEditor::SupportsSequence(UMovieSceneSequence* InSequence) const
{
	return InSequence->IsA(ULevelSequence::StaticClass());
}

bool FMovieSceneCustomTrackEditor::IsResizable(UMovieSceneTrack* InTrack) const
{
	return false;
}

TSharedPtr<SWidget> FMovieSceneCustomTrackEditor::BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params)
{
	if (Track && Track->GetSupportedBlendTypes().Num() > 0)
	{
		TWeakPtr<ISequencer> WeakSequencer = GetSequencer();

		const int32 RowIndex = Params.TrackInsertRowIndex;
		auto SubMenuCallback = [Track, WeakSequencer, RowIndex]() -> TSharedRef<SWidget>
		{
			FMenuBuilder MenuBuilder(true, nullptr);
			PopulateMenu_CreateNewSection(MenuBuilder, RowIndex, Track, WeakSequencer);
			return MenuBuilder.MakeWidget();
		};

		return UE::Sequencer::MakeAddButton(NSLOCTEXT("MovieSceneTrackEditor", "AddSection", "Section"), FOnGetContent::CreateLambda(SubMenuCallback), Params.ViewModel);
	}
	else
	{
		return TSharedPtr<SWidget>(); 
	}
}

// Copy From FSequencerUtilities
void FMovieSceneCustomTrackEditor::PopulateMenu_CreateNewSection(FMenuBuilder& MenuBuilder, int32 RowIndex, UMovieSceneTrack* Track, TWeakPtr<ISequencer> InSequencer)
{
	if (!Track->IsValidLowLevel() || !InSequencer.IsValid())
	{
		return;
	}
	
	auto CreateNewSection = [Track, InSequencer, RowIndex](EMovieSceneBlendType BlendType)
	{
		TSharedPtr<ISequencer> Sequencer = InSequencer.Pin();
		if (!Sequencer.IsValid())
		{
			return;
		}

		FQualifiedFrameTime CurrentTime = Sequencer->GetLocalTime();
		FFrameNumber PlaybackEnd = UE::MovieScene::DiscreteExclusiveUpper(Sequencer->GetFocusedMovieSceneSequence()->GetMovieScene()->GetPlaybackRange());
		
		UMovieSceneSection* NewSection;
		int32 SpecifiedRowIndex = RowIndex;
		{
			FScopedTransaction Transaction(LOCTEXT("AddSectionTransactionText", "Add Section"));
			NewSection = Track->CreateNewSection();
			if (NewSection)
			{
				int32 OverlapPriority = 0;
				TMap<int32, int32> NewToOldRowIndices;
				//if creating with an override force the row index to be last
				if (Track->GetSupportedBlendTypes().Contains(EMovieSceneBlendType::Override))
				{
					SpecifiedRowIndex = Track->GetMaxRowIndex() + 1;
				}
				for (UMovieSceneSection* Section : Track->GetAllSections())
				{
					OverlapPriority = FMath::Max(Section->GetOverlapPriority() + 1, OverlapPriority);				

					// Move existing sections on the same row or beyond so that they don't overlap with the new section
					if (Section != NewSection && Section->GetRowIndex() >= SpecifiedRowIndex)
					{
						int32 OldRowIndex = Section->GetRowIndex();
						int32 NewRowIndex = Section->GetRowIndex() + 1;
						NewToOldRowIndices.FindOrAdd(NewRowIndex, OldRowIndex);
						Section->Modify();
						Section->SetRowIndex(NewRowIndex);
					}
				}

				Track->Modify();

				Track->OnRowIndicesChanged(NewToOldRowIndices);

				if (Sequencer->GetInfiniteKeyAreas() && NewSection->GetSupportsInfiniteRange())
				{
					NewSection->SetRange(TRange<FFrameNumber>::All());
				}
				else
				{
					FFrameNumber NewSectionRangeEnd = PlaybackEnd;
					if (PlaybackEnd <= CurrentTime.Time.FrameNumber)
					{
						const FAnimatedRange ViewRange = Sequencer->GetViewRange();
						const FFrameRate TickResolution = Sequencer->GetFocusedTickResolution();
						NewSectionRangeEnd = (ViewRange.GetUpperBoundValue() * TickResolution).FloorToFrame();
					}

					NewSection->SetRange(TRange<FFrameNumber>(CurrentTime.Time.FrameNumber, NewSectionRangeEnd));
				}

				NewSection->SetOverlapPriority(OverlapPriority);
				NewSection->SetRowIndex(SpecifiedRowIndex);
				NewSection->SetBlendType(BlendType);

				Track->AddSection(*NewSection);
				Track->UpdateEasing();

				if (UMovieSceneNameableTrack* NameableTrack = Cast<UMovieSceneNameableTrack>(Track))
				{
					NameableTrack->SetTrackRowDisplayName(FText::GetEmpty(), SpecifiedRowIndex);
				}

				Sequencer->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
			}
			else
			{
				Transaction.Cancel();
			}
		}

		if (NewSection)
		{
			SetupSection(nullptr, Cast<UMovieSceneCustomTrack>(Track), Cast<UMovieSceneCustomSection>(NewSection), InSequencer);
		}
	};

	FText NameOverride		= Track->GetSupportedBlendTypes().Num() == 1 ? LOCTEXT("AddSectionText", "Add New Section") : FText();
	FText TooltipOverride	= Track->GetSupportedBlendTypes().Num() == 1 ? LOCTEXT("AddSectionToolTip", "Adds a new section") : FText();

	const UEnum* MovieSceneBlendType = FindObjectChecked<UEnum>(nullptr, TEXT("/Script/MovieScene.EMovieSceneBlendType"));
	for (EMovieSceneBlendType BlendType : Track->GetSupportedBlendTypes())
	{
		FText DisplayName = MovieSceneBlendType->GetDisplayNameTextByValue(static_cast<int64>(BlendType));
		FName EnumValueName = MovieSceneBlendType->GetNameByValue(static_cast<int64>(BlendType));
		MenuBuilder.AddMenuEntry(
			NameOverride.IsEmpty() ? DisplayName : NameOverride,
			TooltipOverride.IsEmpty() ? FText::Format(LOCTEXT("AddSectionFormatToolTip", "Adds a new {0} section"), DisplayName) : TooltipOverride,
			FSlateIcon(FAppStyle::GetAppStyleSetName(), EnumValueName),
			FUIAction(
				FExecuteAction::CreateLambda(CreateNewSection, BlendType),
				FCanExecuteAction::CreateLambda([InSequencer] { return InSequencer.IsValid() && !InSequencer.Pin()->IsReadOnly(); })
			)
		);
	}
}

bool FMovieSceneCustomTrackEditor::OnAllowDrop(const FDragDropEvent& DragDropEvent,
	FSequencerDragDropParams& DragDropParams)
{
	return false;
}

FReply FMovieSceneCustomTrackEditor::OnDrop(const FDragDropEvent& DragDropEvent,
	const FSequencerDragDropParams& DragDropParams)
{
	return FReply::Handled();
}

void FMovieSceneCustomTrackEditor::SetupSection(UMovieScene* const FocusedMovieScene, UMovieSceneCustomTrack* NewTrack, UMovieSceneCustomSection* NewSection, const TWeakPtr<ISequencer>& WeakSeq)
{
	if (!NewTrack || !NewSection || !WeakSeq.IsValid())
		return;
	
	TSharedRef<SWindow> Window = SNew(SWindow)
		.Title(LOCTEXT("SetupCustomSection", "SetupCustomSection"))
		.SizingRule(ESizingRule::UserSized)
		.AutoCenter(EAutoCenter::PreferredWorkArea)
		.ClientSize(FVector2D(800, 600));

	const TSharedPtr<ISequencer> PinSeq = WeakSeq.Pin();
	const TSharedRef<SCustomSectionSetupPanel> SetupPanel = SNew(SCustomSectionSetupPanel, NewSection, WeakSeq);
	bool bSaved = false;

	Window->SetContent(
		SNew(SBorder)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			[
				SetupPanel
			]

			+ SVerticalBox::Slot()
			.FillHeight(0.1f)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("SetupCustomSection_OK", "OK"))
				.OnClicked(FOnClicked::CreateLambda([&Window, &bSaved]()
				{
					bSaved = true;
					Window->RequestDestroyWindow();
					return FReply::Handled();
				}))
			]
		]
	);

	// 阻塞
	GEditor->EditorAddModalWindow(Window);

	// 保存 / 移除
	if (bSaved)
	{
		SetupPanel->OnSave();
		PinSeq->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::TrackValueChanged);	
	}
	else
	{
		if (FocusedMovieScene)
		{
			FocusedMovieScene->RemoveTrack(*NewTrack);	
		}
		else
		{
			NewTrack->RemoveSection(*NewSection);
		}
		
		PinSeq->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemRemoved);
	}
}

void FMovieSceneCustomTrackEditor::BuildObjectBindingContextMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	TSharedRef<FExtender> Extender = MakeShared<FExtender>();
	
	Extender->AddMenuExtension(TEXT("Organize"), EExtensionHook::Position::After, nullptr,
		FMenuExtensionDelegate::CreateLambda([WeakSequencer = GetSequencer().ToWeakPtr(), ObjectBindings](FMenuBuilder& MenuBuilder)
		{
			MenuBuilder.AddMenuEntry(
				LOCTEXT("TagManager_MenuItem", "打开C7 Tag管理器"),
				LOCTEXT("TagManager_Tooltip", "打开C7 Tag管理器"),
				FSlateIcon(),
				FUIAction(FExecuteAction::CreateStatic(&FMovieSceneCustomTrackEditor::OpenTagManager, WeakSequencer, ObjectBindings))
			);
		})
	);

	MenuBuilder.PushExtender(Extender);
}

void FMovieSceneCustomTrackEditor::OpenTagManager(TWeakPtr<ISequencer> WeakSequencer, TArray<FGuid> BindObjects)
{
	if (!WeakSequencer.IsValid() || BindObjects.Num() != 1)
		return;

	TSharedPtr<ISequencer> Sequencer = WeakSequencer.Pin();
	UMovieSceneSequence* Sequence = Sequencer->GetRootMovieSceneSequence();
	if (!Sequence)
		return;

	FMovieSceneSequenceID SequenceID = Sequencer->GetFocusedTemplateID();
	
	// 创建一个子窗口，使用与 SObjectBindingTagManager 相同的方式
	const TSharedRef<SWindow> Window = SNew(SWindow)
		.Title(FText::FromString(FString::Printf(TEXT("C7 Tag管理器 in %s"), *Sequence->GetName())))
		.SupportsMaximize(false)
		.ClientSize(FVector2D(800.f, 500.f))
		.Content()
		[
			SNew(SCutsceneTagManagerWidget, WeakSequencer.Pin().ToSharedRef(), FMovieSceneObjectBindingID(UE::MovieScene::FRelativeObjectBindingID(BindObjects[0], SequenceID, -1)))
		];

	// 查找父窗口并作为子窗口添加
	if (const TSharedPtr<SWindow> ParentWindow = FSlateApplication::Get().FindWidgetWindow(Sequencer->GetSequencerWidget()))
	{
		FSlateApplication::Get().AddWindowAsNativeChild(Window, ParentWindow.ToSharedRef());
	}
	else
	{
		FSlateApplication::Get().AddWindow(Window);
	}
}

void FMovieSceneCustomTrackEditor::OnAddCustomTrackAndSection(const FGuid ObjectBinding) const
{
	const TSharedPtr<ISequencer> Seq = GetSequencer();
	if (!ensure(Seq.IsValid()))
		return;
	
	UMovieScene* const FocusedMovieScene = GetFocusedMovieScene();
	if (FocusedMovieScene == nullptr)
		return;
	
	UMovieSceneCustomTrack* NewTrack;
	UMovieSceneCustomSection* NewSection;
	{
		// Scope 很重要
		const FScopedTransaction Transaction(LOCTEXT("AddCustomTrack_Transaction_BuildAddTrackMenu", "Add Custom Track"));
		FocusedMovieScene->Modify();

		NewTrack = ObjectBinding.IsValid()
			? FocusedMovieScene->AddTrack<UMovieSceneCustomTrack>(ObjectBinding)
			: FocusedMovieScene->AddTrack<UMovieSceneCustomTrack>();
	
		NewSection = Cast<UMovieSceneCustomSection>(NewTrack->CreateNewSection());
		NewTrack->AddSection(*NewSection);

		// 设置 Section 位置和长度
		const FFrameNumber PlaybackEnd = UE::MovieScene::DiscreteExclusiveUpper(FocusedMovieScene->GetPlaybackRange());
		const FFrameRate FrameResolution = FocusedMovieScene->GetTickResolution();
		const FFrameNumber SpawnSectionStartTime = Seq->GetLocalTime().ConvertTo(FrameResolution).RoundToFrame();
		const FFrameTime SpawnSectionDuration = FrameResolution.AsFrameTime(5.0);
		FFrameNumber SpawnSectionEndTime = (SpawnSectionStartTime + SpawnSectionDuration).RoundToFrame();
		if (SpawnSectionEndTime > PlaybackEnd && SpawnSectionStartTime < PlaybackEnd)
			SpawnSectionEndTime = PlaybackEnd;
		NewSection->SetRange(TRange<FFrameNumber>(SpawnSectionStartTime, SpawnSectionEndTime));

		GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
	}

	if (NewSection)
	{
		SetupSection(FocusedMovieScene, NewTrack, NewSection, GetSequencer());
	}
}

void FMovieSceneCustomTrackEditor::BuildAddTrackMenu(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.AddMenuEntry(
		LOCTEXT("AddCustomTrack_BuildAddTrackMenu", "CustomTrack"),
		LOCTEXT("AddCustomTrackTooltip_BuildAddTrackMenu", "Adds a Custom track."),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateRaw(this, &FMovieSceneCustomTrackEditor::OnAddCustomTrackAndSection, FGuid())
	));
}

void FMovieSceneCustomTrackEditor::BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	FGuid ObjectBinding = ObjectBindings[0];
	
	if (ObjectClass->IsChildOf(AActor::StaticClass()) || ObjectClass->IsChildOf(USceneComponent::StaticClass()))
	{
		MenuBuilder.AddMenuEntry(
			LOCTEXT("AddCustomTrack_BuildObjectBindingTrackMenu", "Custom"),
			LOCTEXT("AddCustomTrackTooltip_BuildObjectBindingTrackMenu", "Adds an Custom track."),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateRaw(this, &FMovieSceneCustomTrackEditor::OnAddCustomTrackAndSection, ObjectBinding))
		);
	}
}

FMovieSceneCustomSection::FMovieSceneCustomSection(UMovieSceneSection& InSection, const TWeakPtr<ISequencer>& InSequencer)
	: Section(Cast<UMovieSceneCustomSection>(&InSection))
	, Sequencer(InSequencer)
{
	CreateCustomEditor();
}

FMovieSceneCustomSection::~FMovieSceneCustomSection()
{
}

UMovieSceneSection* FMovieSceneCustomSection::GetSectionObject()
{
	return Section.Get();
}

FText FMovieSceneCustomSection::GetSectionTitle() const
{
	UMovieSceneCustomSection* CustomSection = Cast<UMovieSceneCustomSection>(Section);

	if (CustomEditor.IsValid() && CustomEditor->IsSectionValid() &&
		CustomEditor->HasMethod(UCustomSectionEditor::EMethodType::Title))
		return CustomEditor->GetSectionTitle();

	if (IsValid(CustomSection->CustomData))
	{
		return FText::FromString(CustomSection->CustomData->DisplayName != "" ? CustomSection->CustomData->DisplayName : CustomSection->CustomData->ActionName);
	}
	return FText::FromString("Custom Section");
}

FText FMovieSceneCustomSection::GetSectionToolTip() const
{
	if (CustomEditor.IsValid() && CustomEditor->IsSectionValid() &&
		 CustomEditor->HasMethod(UCustomSectionEditor::EMethodType::ToolTip))
		return CustomEditor->GetSectionToolTip();
	
	return FText::FromString("Custom Section");
}

float FMovieSceneCustomSection::GetSectionHeight(const UE::Sequencer::FViewDensityInfo& ViewDensity) const
{
	if (CustomEditor.IsValid() && CustomEditor->IsSectionValid() &&
		 CustomEditor->HasMethod(UCustomSectionEditor::EMethodType::Height))
		return CustomEditor->GetSectionHeight();
	
	return 40;
}

int32 FMovieSceneCustomSection::OnPaintSection(FSequencerSectionPainter& Painter) const
{
	return Painter.PaintSectionBackground();
}


void FMovieSceneCustomSection::BeginResizeSection()
{
}

void FMovieSceneCustomSection::ResizeSection(ESequencerSectionResizeMode ResizeMode,
	FFrameNumber ResizeTime)
{
	ISequencerSection::ResizeSection(ResizeMode, ResizeTime);
}

void FMovieSceneCustomSection::GenerateSectionLayout(class ISectionLayoutBuilder& LayoutBuilder)
{
}

void FMovieSceneCustomSection::BeginSlipSection()
{
}

void FMovieSceneCustomSection::SlipSection(FFrameNumber SlipTime)
{
	ISequencerSection::SlipSection(SlipTime);
}

TSharedRef<SWidget> FMovieSceneCustomSection::GenerateSectionWidget()
{
	if (CustomEditor.IsValid() && CustomEditor->IsSectionValid() &&
		 CustomEditor->HasMethod(UCustomSectionEditor::EMethodType::Widget))
	{
		return CustomEditor->GenerateSectionWidget();
	}
	
	return ISequencerSection::GenerateSectionWidget();
}

void FMovieSceneCustomSection::BuildSectionContextMenu(FMenuBuilder& MenuBuilder, const FGuid& ObjectBinding)
{
	if (CustomEditor.IsValid() && CustomEditor->IsSectionValid() &&
		 CustomEditor->HasMethod(UCustomSectionEditor::EMethodType::Menu))
	{
		CustomEditor->BuildSectionContextMenu(MenuBuilder, ObjectBinding);
	}

	if (Section->IsValidLowLevel() && Section->CustomData)
	{
		MenuBuilder.AddSubMenu(
			LOCTEXT("Label自定义数据", "自定义数据"),
			LOCTEXT("Tooltip自定义数据", "编辑自定义轨道的数据"),
			FNewMenuDelegate::CreateSP(this, &FMovieSceneCustomSection::BuildCustomDataMenu)
		);

		const TSharedRef<FMultiBox> MultiBox = MenuBuilder.GetMultiBox();
		const TSharedRef<const FMultiBlock> Block = MultiBox->GetBlocks().Last();
		MultiBox->AddMultiBlockToFront(Block);	
	}
}

void FMovieSceneCustomSection::BuildCustomDataMenu(FMenuBuilder& MenuBuilder)
{
	if (!Section.IsValid() || !Section->CustomData->IsValidLowLevel())
		return;
	
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	FDetailsViewArgs DetailsViewArgs;
	{
		DetailsViewArgs.bCustomFilterAreaLocation = true;
		DetailsViewArgs.bCustomNameAreaLocation = true;
		DetailsViewArgs.bHideSelectionTip = true;
		DetailsViewArgs.bSearchInitialKeyFocus = true;
		DetailsViewArgs.ColumnWidth = 0.45f;
		DetailsViewArgs.NotifyHook = this;
	}
	const TSharedRef<IDetailsView> CustomDetailsView = PropertyModule.CreateDetailView(DetailsViewArgs);
	CustomDetailsView->SetObject(Section->CustomData);
	
	MenuBuilder.BeginSection(TEXT("CustomData"));
	{
		MenuBuilder.AddWidget(CustomDetailsView, FText::GetEmpty(), true);
	}
	MenuBuilder.EndSection();
}

void FMovieSceneCustomSection::AddReferencedObjects(FReferenceCollector& Collector)
{
	if (CustomEditor.IsValid() && CustomEditor->IsSectionValid() &&
		 CustomEditor.IsValid())
		Collector.AddReferencedObject(CustomEditor);
}

FString FMovieSceneCustomSection::GetReferencerName() const
{
	return TEXT("FMovieSceneCustomSection");
}

void FMovieSceneCustomSection::OnCustomSectionPostEditChangeProperty()
{
	if (Sequencer.IsValid())
	{
		TSharedPtr<ISequencer> Seq = Sequencer.Pin();
		Seq->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::TrackValueChanged);
	}

	if (Section.IsValid())
	{
		Section->Modify();
	}
	
	if (CustomEditor.IsValid() && CustomEditor->IsSectionValid() &&
		CustomEditor->HasMethod(UCustomSectionEditor::EMethodType::PostEdit))
		CustomEditor->OnPostEditChange();
}

void FMovieSceneCustomSection::CreateCustomEditor()
{
	if (!Section.IsValid() || !Sequencer.IsValid())
		return;

	CustomEditor = nullptr;
	if (const UClass* Class = UCustomSectionEditor::GetEditorClassForSection(Section.Get()))
	{
		CustomEditor = UCustomSectionEditor::CreateEditorInstanceForSection(Class, Section, Sequencer);
	}
}

void FMovieSceneCustomSection::NotifyPostChange(const FPropertyChangedEvent& PropertyChangedEvent, FProperty* PropertyThatChanged)
{
	OnCustomSectionPostEditChangeProperty();
}

void FMovieSceneCustomSection::Tick(const FGeometry& AllottedGeometry, const FGeometry& ClippedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	if (Section.IsValid() && Section->CustomData->IsValidLowLevel())
	{
		const FString& ActionName = Section->CustomData->ActionName;
		if (ActionName != PrevActionName)
		{
			if (CustomEditor.IsValid() && CustomEditor->SupportCustomSectionName() != ActionName)
			{
				CustomEditor = nullptr;
			}

			if (!CustomEditor.IsValid())
			{
				CreateCustomEditor();
			}
		}
	}
}

#undef LOCTEXT_NAMESPACE
