// Copyright Epic Games, Inc. All Rights Reserved.

#include "CutScene/LookAtPropertyTrackEditor.h"

#include "CutScene/Utils/FCutsceneEditorUtils.h"
#include "LevelSequence.h"
#include "Channels/MovieSceneBoolChannel.h"
#include "KeyPropertyParams.h"
#include "Misc/Guid.h"
#include "Misc/Optional.h"
#include "3C/Character/BaseCharacter.h"
#include "CutScene/LookAtPropertySection.h"
#include "CutScene/MovieSceneGazeTrack.h"
#include "SequencerUtilities.h"

class ISequencer;
class ISequencerSection;
class ISequencerTrackEditor;
class UMovieSceneSection;
class UMovieSceneTrack;

#define LOCTEXT_NAMESPACE "LookAtPropertyTrackEditor"

TSharedRef<ISequencerTrackEditor> FLookAtPropertyTrackEditor::CreateTrackEditor( TSharedRef<ISequencer> InSequencer)
{
	return MakeShareable(new FLookAtPropertyTrackEditor(InSequencer));
}

TSharedPtr<SWidget> FLookAtPropertyTrackEditor::BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params)
{
	return SNullWidget::NullWidget;
}

bool FLookAtPropertyTrackEditor::SupportsSequence(UMovieSceneSequence* InSequence) const
{
	return InSequence->IsA(ULevelSequence::StaticClass());
}

void FLookAtPropertyTrackEditor::BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	if (ObjectClass != nullptr && ObjectClass->IsChildOf(ABaseCharacter::StaticClass()))
	{
		MenuBuilder.AddMenuEntry(
			NSLOCTEXT("Sequencer", "AddLookAtTrack", "LookAt"),
			NSLOCTEXT("Sequencer", "AddLookAtTooltip", "Adds a LookAt track."),
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateSP(this, &FLookAtPropertyTrackEditor::AddTransformKeysForHandle, ObjectBindings, EMovieSceneLookAtChannel::All, ESequencerKeyMode::ManualKey)
			)
		);
	}
}

TSharedRef<ISequencerSection> FLookAtPropertyTrackEditor::MakeSectionInterface(UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding)
{
	return MakeShared<FLookAtSection>(SectionObject, GetSequencer());
}


void FLookAtPropertyTrackEditor::GenerateKeysFromPropertyChanged( const FPropertyChangedParams& PropertyChangedParams, UMovieSceneSection* SectionToKey, FGeneratedTrackKeys& OutGeneratedKeys )
{
	// Invert the property key since the underlying property is actually 'hidden'
	/*bool KeyedValue = !PropertyChangedParams.GetPropertyValue<bool>();
	OutGeneratedKeys.Add(FMovieSceneChannelValueSetter::Create<FMovieSceneBoolChannel>(0, KeyedValue, true));*/
}

void FLookAtPropertyTrackEditor::AddTransformKeysForHandle(TArray<FGuid> ObjectHandles, EMovieSceneLookAtChannel ChannelToKey, ESequencerKeyMode KeyMode)
{
	const FScopedTransaction Transaction(NSLOCTEXT("Sequencer", "AddLookAtTrack_AddTransformKeysForHandle", "Add LookAt Track"));

	UMovieScene* FocusedMovieScene = GetFocusedMovieScene();
	if (!FocusedMovieScene)
		return;
	
	for (FGuid ObjectHandle : ObjectHandles)
	{
		FMovieSceneBinding* MovieSceneBinding = FocusedMovieScene->FindBinding(ObjectHandle);
		if (!ensure(MovieSceneBinding)) continue;
		
		const TArray<UMovieSceneTrack*>& Tracks = MovieSceneBinding->GetTracks();
		bool bFound = false;
		for (const UMovieSceneTrack* Track : Tracks)
		{
			if (Track && (Track->IsA<UMovieSceneLookAtTrack>() || Track->IsA<UMovieSceneGazeTrack>()))
			{
				FCutsceneEditorUtils::CreateNotification(LOCTEXT("AddLookAtConflict", "已经存在一条LookAt轨道，不能再添加！"), false);
				bFound = true;
				break;
			}
		}
		if (bFound) continue;
		
		for (TWeakObjectPtr<UObject> Object : GetSequencer()->FindObjectsInCurrentSequence(ObjectHandle))
		{
			//AddTransformKeysForObject(Object.Get(), ChannelToKey, KeyMode);
			AddDefaultSystemTracks(Object.Get(), ObjectHandle);
		}
	}
}

void FLookAtPropertyTrackEditor::AddDefaultSystemTracks(const UObject* Object, const FGuid& Binding)
{
	ULookAtComponent* LookAtComponent = LookAtComponentFromRuntimeObject(Object);
	if(LookAtComponent == nullptr) return;
	const TSharedPtr<ISequencer> Sequencer1 = GetSequencer();
	UMovieSceneSequence* Sequence1 = Sequencer1->GetFocusedMovieSceneSequence();
	UMovieScene* MovieScene = Sequence1->GetMovieScene();

	UClass* TrackClass = UMovieSceneLookAtTrack::StaticClass();
	UMovieSceneTrack* NewTrack = MovieScene->FindTrack(TrackClass, Binding);
	if (!NewTrack)
	{
		MovieScene->Modify();
		NewTrack = MovieScene->AddTrack(TrackClass, Binding);
		//NewTrack->SetDisplayName(LOCTEXT("LookAtTrackName", "LookAt"));

#if WITH_EDITORONLY_DATA
		if (!NewTrack->SupportsDefaultSections())
		{
			return;
		}
#endif

		UMovieSceneSection* NewSection;
		if (NewTrack->GetAllSections().Num() > 0)
		{
			NewSection = NewTrack->GetAllSections()[0];
		}
		else
		{
			NewSection = NewTrack->CreateNewSection();
			NewTrack->AddSection(*NewSection);
		}

		UMovieSceneLookAtSection* MovieSceneLookAtSection = Cast<UMovieSceneLookAtSection>(NewSection);

		FRotator Eye = LookAtComponent->GetEye();
		FVector EyeScale = LookAtComponent->GetEyeScale();
		FRotator Head = LookAtComponent->GetHead();
		FRotator Body = LookAtComponent->GetBody();
		FRotator Spine_01 = LookAtComponent->GetSpine_01();
		FRotator Spine_02 = LookAtComponent->GetSpine_02();
		FRotator Spine_03 = LookAtComponent->GetSpine_03();

		TArrayView<FMovieSceneDoubleChannel*> DoubleChannels = MovieSceneLookAtSection->GetChannelProxy().GetChannels<FMovieSceneDoubleChannel>();
		DoubleChannels[0]->SetDefault(Eye.Euler().X);
		DoubleChannels[1]->SetDefault(Eye.Euler().Y);
		DoubleChannels[2]->SetDefault(EyeScale.Z);

		DoubleChannels[3]->SetDefault(Head.Euler().X);
		DoubleChannels[4]->SetDefault(Head.Euler().Y);
		DoubleChannels[5]->SetDefault(Head.Euler().Z);

		DoubleChannels[6]->SetDefault(Body.Euler().X);
		DoubleChannels[7]->SetDefault(Body.Euler().Y);
		DoubleChannels[8]->SetDefault(Body.Euler().Z);

		DoubleChannels[9]->SetDefault(Spine_01.Euler().X);
		DoubleChannels[10]->SetDefault(Spine_01.Euler().Y);
		DoubleChannels[11]->SetDefault(Spine_01.Euler().Z);

		DoubleChannels[12]->SetDefault(Spine_02.Euler().X);
		DoubleChannels[13]->SetDefault(Spine_02.Euler().Y);
		DoubleChannels[14]->SetDefault(Spine_02.Euler().Z);

		DoubleChannels[15]->SetDefault(Spine_03.Euler().X);
		DoubleChannels[16]->SetDefault(Spine_03.Euler().Y);
		DoubleChannels[17]->SetDefault(Spine_03.Euler().Z);

		/*if (Sequencer->GetInfiniteKeyAreas())
		{
			NewSection->SetRange(TRange<FFrameNumber>::All());
		}*/
		FFrameRate FrameResolution = MovieScene->GetTickResolution();
		FFrameTime SpawnSectionStartTime = Sequencer1->GetLocalTime().ConvertTo(FrameResolution);
		FFrameTime SpawnSectionDuration = FrameResolution.AsFrameTime(5.0);

		MovieSceneLookAtSection->SetRange(TRange<FFrameNumber>(
			SpawnSectionStartTime.RoundToFrame(),
			(SpawnSectionStartTime + SpawnSectionDuration).RoundToFrame()));

		Sequencer1->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
	}
}

ULookAtComponent* FLookAtPropertyTrackEditor::LookAtComponentFromRuntimeObject(const UObject* Object)
{
	const ABaseCharacter* Actor = Cast<ABaseCharacter>(Object);
	if(Actor)
	{
		ULookAtComponent* LookAtComponent = Actor->GetComponentByClass<ULookAtComponent>();
		if(LookAtComponent)
		{
			return LookAtComponent;
		}
	}
	return nullptr;
}

#undef LOCTEXT_NAMESPACE