// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com


#include "CutScene/MovieSceneBatchMaterialTrackEditor.h"

#include "MaterialEditorModule.h"
#include "Sections/ComponentMaterialParameterSection.h"
#include "CutScene/MovieSceneBatchMaterialParameterSection.h"
#include "CutScene/MovieSceneBatchMaterialTrack.h"
#include "Components/PrimitiveComponent.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "GameFramework/Actor.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstance.h"
#include "Modules/ModuleManager.h"
#include "Sections/ParameterSection.h"
#include "MVVM/Views/ViewUtilities.h"
#include "CutScene/CutsceneUtils.h"

#define LOCTEXT_NAMESPACE "BatchMaterialTrackEditor"

FMovieSceneBatchMaterialTrackEditor::FMovieSceneBatchMaterialTrackEditor( TSharedRef<ISequencer> InSequencer )
	:FMaterialTrackEditor(InSequencer)
{
}

TSharedRef<ISequencerTrackEditor> FMovieSceneBatchMaterialTrackEditor::CreateTrackEditor(TSharedRef<ISequencer> OwningSequencer)
{
	return MakeShareable( new FMovieSceneBatchMaterialTrackEditor( OwningSequencer ) );
}

TSharedRef<ISequencerSection> FMovieSceneBatchMaterialTrackEditor::MakeSectionInterface(UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding)
{
	UMovieSceneBatchMaterialParameterSection* BatchMaterialParameterSection = Cast<UMovieSceneBatchMaterialParameterSection>(&SectionObject);
	UMovieSceneParameterSection* ParameterSection = Cast<UMovieSceneParameterSection>(&SectionObject);
	checkf( BatchMaterialParameterSection != nullptr || ParameterSection != nullptr, TEXT("Unsupported section type.") );

	if (BatchMaterialParameterSection)
	{
		//reuse FComponentMaterialParameterSection for UMovieSceneBatchMaterialParameterSection, same data, same UI
		return MakeShareable(new FComponentMaterialParameterSection(*BatchMaterialParameterSection, GetSequencer()));
	}
	else
	{
		return MakeShareable(new FParameterSection(*ParameterSection, GetSequencer()));
	}
}

void FMovieSceneBatchMaterialTrackEditor::BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	if (ObjectClass->IsChildOf(AActor::StaticClass()) || ObjectClass->IsChildOf(UPrimitiveComponent::StaticClass()))
	{
		MenuBuilder.AddMenuEntry(
			LOCTEXT("AddBatchMaterialTrack", "BatchEditMaterialTrack"),
			LOCTEXT("AddBatchMaterialTrackTooltip", "Adds a new track that can edit all materials on the actor at the same time."),
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateSP(this, &FMovieSceneBatchMaterialTrackEditor::AddNewBatchMaterialTrack, ObjectBindings)
				)
		);
	}
}

bool FMovieSceneBatchMaterialTrackEditor::SupportsType(TSubclassOf<UMovieSceneTrack> Type) const
{
	return Type == UMovieSceneBatchMaterialTrack::StaticClass();
}

void FMovieSceneBatchMaterialTrackEditor::AddScalarParameter(FGuid ObjectBinding, UMovieSceneMaterialTrack* MaterialTrack, FMaterialParameterInfo ParameterInfo, FString InLayerName, FString InAssetName)
{
	FFrameNumber KeyTime = GetTimeForKey();

	UObject* Object = GetSequencer()->FindSpawnedObjectOrTemplate(ObjectBinding);
	TArray<UPrimitiveComponent*> PrimitiveComponents;
	AActor* Actor = Cast<AActor>(Object);

	if (!Actor)
	{
		UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(Object);
		if (!PrimitiveComponent)
		{
			return;
		}
		PrimitiveComponents.Add(PrimitiveComponent);
	}
	else
	{
		Actor->GetComponents(UPrimitiveComponent::StaticClass(), PrimitiveComponents);
	}

	UMovieSceneBatchMaterialTrack* BatchMaterialTrack = Cast<UMovieSceneBatchMaterialTrack>(MaterialTrack);
	if (BatchMaterialTrack &&
		!BatchMaterialTrack->SlotName.IsEmpty())
	{
		bool Founded = false;
		for (auto PrimitiveComponent : PrimitiveComponents)
		{
			UCutsceneUtils::ForEachMaterialOnComponentBySlotName(PrimitiveComponent, BatchMaterialTrack->SlotName, [Sequencer=GetSequencer(), &ParameterInfo, &MaterialTrack, &KeyTime, &InLayerName, &InAssetName, &Founded](UMaterialInterface* MaterialInterface) {
				const FScopedTransaction Transaction(LOCTEXT("AddScalarParameter", "Add scalar parameter"));
				float ParameterValue;
				if (MaterialInterface->GetScalarParameterValue(ParameterInfo, ParameterValue))
				{
					//there may be plenty of params matches on all materials, but we just need one here
					MaterialTrack->Modify();
					MaterialTrack->AddScalarParameterKey(ParameterInfo, KeyTime, ParameterValue, InLayerName, InAssetName);
					Sequencer->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
					Founded = true;
					return;
				}
			});
			if (Founded)
			{
				return;
			}
		}
	}
	else {
		for (auto PrimitiveComponent : PrimitiveComponents)
		{
			TArray<UMaterialInterface*> UsedMaterials;
			PrimitiveComponent->GetUsedMaterials(UsedMaterials);
			for (auto MaterialInterface : UsedMaterials)
			{
				const FScopedTransaction Transaction(LOCTEXT("AddScalarParameter", "Add scalar parameter"));
				float ParameterValue;
				if (MaterialInterface->GetScalarParameterValue(ParameterInfo, ParameterValue))
				{
					//there may be plenty of params matches on all materials, but we just need one here
					MaterialTrack->Modify();
					MaterialTrack->AddScalarParameterKey(ParameterInfo, KeyTime, ParameterValue, InLayerName, InAssetName);
					GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
					return;
				}
			}
		}
	}
}

void FMovieSceneBatchMaterialTrackEditor::AddColorParameter(FGuid ObjectBinding, UMovieSceneMaterialTrack* MaterialTrack, FMaterialParameterInfo ParameterInfo, FString InLayerName, FString InAssetName)
{
	FFrameNumber KeyTime = GetTimeForKey();

	UObject* Object = GetSequencer()->FindSpawnedObjectOrTemplate(ObjectBinding);
	TArray<UPrimitiveComponent*> PrimitiveComponents;
	AActor* Actor = Cast<AActor>(Object);

	if (!Actor)
	{
		UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(Object);
		if (!PrimitiveComponent)
		{
			return;
		}
		PrimitiveComponents.Add(PrimitiveComponent);
	}
	else
	{
		Actor->GetComponents(UPrimitiveComponent::StaticClass(), PrimitiveComponents);
	}

	UMovieSceneBatchMaterialTrack* BatchMaterialTrack = Cast<UMovieSceneBatchMaterialTrack>(MaterialTrack);
	if (BatchMaterialTrack &&
		!BatchMaterialTrack->SlotName.IsEmpty())
	{
		bool Founded = false;
		for (auto PrimitiveComponent : PrimitiveComponents)
		{
			UCutsceneUtils::ForEachMaterialOnComponentBySlotName(PrimitiveComponent, BatchMaterialTrack->SlotName, [Sequencer = GetSequencer(), &ParameterInfo, &MaterialTrack, &KeyTime, &InLayerName, &InAssetName, &Founded](UMaterialInterface* MaterialInterface) {
				const FScopedTransaction Transaction(LOCTEXT("AddColorParameter", "Add color parameter"));
				FLinearColor ParameterValue;
				if (MaterialInterface->GetVectorParameterValue(ParameterInfo, ParameterValue))
				{
					//there may be plenty of params matches on all materials, but we just need one here
					MaterialTrack->Modify();
					MaterialTrack->AddColorParameterKey(ParameterInfo, KeyTime, ParameterValue, InLayerName, InAssetName);
					Sequencer->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
					Founded = true;
					return;
				}
				});
			if (Founded)
			{
				return;
			}
		}
	}
	else {
		for (auto PrimitiveComponent : PrimitiveComponents)
		{
			TArray<UMaterialInterface*> UsedMaterials;
			PrimitiveComponent->GetUsedMaterials(UsedMaterials);
			for (auto MaterialInterface : UsedMaterials)
			{
				const FScopedTransaction Transaction(LOCTEXT("AddColorParameter", "Add color parameter"));
				FLinearColor ParameterValue;
				if (MaterialInterface->GetVectorParameterValue(ParameterInfo, ParameterValue))
				{
					//there may be plenty of params matches on all materials, but we just need one here
					MaterialTrack->Modify();
					MaterialTrack->AddColorParameterKey(ParameterInfo, KeyTime, ParameterValue, InLayerName, InAssetName);
					GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
					return;
				}
			}
		}
	}
}

struct FBatchParameterInfoAndAction
{
	FMaterialParameterInfo ParameterInfo;
	FText ParameterDisplayName;
	FUIAction Action;

	FBatchParameterInfoAndAction(const FMaterialParameterInfo& InParameterInfo, FText InParameterDisplayName, FUIAction InAction )
	{
		ParameterInfo = InParameterInfo;
		ParameterDisplayName = InParameterDisplayName;
		Action = InAction;
	}

	bool operator<(FBatchParameterInfoAndAction const& Other) const
	{
		if (ParameterInfo.Index == Other.ParameterInfo.Index)
		{
			if (ParameterInfo.Association == Other.ParameterInfo.Association)
			{
				return ParameterInfo.Name.LexicalLess(Other.ParameterInfo.Name);
			}
			return ParameterInfo.Association < Other.ParameterInfo.Association;
		}
		return ParameterInfo.Index < Other.ParameterInfo.Index;
	}
};

void FMovieSceneBatchMaterialTrackEditor::OnBuildAddParameterMenu(FMenuBuilder& MenuBuilder, FGuid ObjectBinding, UMovieSceneMaterialTrack* MaterialTrack)
{
	UObject* Object = GetSequencer()->FindSpawnedObjectOrTemplate(ObjectBinding);
	TArray<UPrimitiveComponent*> PrimitiveComponents;
	AActor* Actor = Cast<AActor>(Object);

	if (!Actor)
	{
		UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(Object);
		if (!PrimitiveComponent)
		{
			return;
		}
		PrimitiveComponents.Add(PrimitiveComponent);
	}
	else 
	{
		Actor->GetComponents(UPrimitiveComponent::StaticClass(), PrimitiveComponents);
	}
	
	TArray<FBatchParameterInfoAndAction> ParameterInfosAndActions;
	TSet<FMaterialParameterInfo>	ScalarParameterInfoSet;
	TSet<FMaterialParameterInfo>	ColorParameterInfoSet;
	TArray<FMaterialParameterInfo> ScalarParameterInfos;
	TArray<FGuid> ScalarParameterGuids;
	TArray<FMaterialParameterInfo> ColorParameterInfos;
	TArray<FGuid> ColorParameterGuids;
	TArray<FMaterialParameterInfo> VisibleExpressions;

	IMaterialEditorModule* MaterialEditorModule = &FModuleManager::LoadModuleChecked<IMaterialEditorModule>( "MaterialEditor" );
	UMovieSceneBatchMaterialTrack* BatchMaterialTrack = Cast<UMovieSceneBatchMaterialTrack>(MaterialTrack);

	auto DoExtractParameters = [&ScalarParameterInfos, &ScalarParameterGuids, &ColorParameterInfos, 
			&ColorParameterGuids, &VisibleExpressions, &MaterialEditorModule, 
			&ScalarParameterInfoSet, &ColorParameterInfoSet](UMaterialInterface* MaterialInterface) 
		{
			UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>(MaterialInterface);
			UMaterial* Material = MaterialInstance ? MaterialInstance->GetMaterial() : nullptr;
			if (Material == nullptr)
			{
				return;
			}

			ScalarParameterInfos.Empty();
			ScalarParameterGuids.Empty();
			ColorParameterInfos.Empty();
			ColorParameterGuids.Empty();
			VisibleExpressions.Empty();

			bool bCollectedVisibleParameters = false;
			if (MaterialEditorModule && MaterialInstance)
			{
				MaterialEditorModule->GetVisibleMaterialParameters(Material, MaterialInstance, VisibleExpressions);
				bCollectedVisibleParameters = true;
			}

			MaterialInterface->GetAllScalarParameterInfo(ScalarParameterInfos, ScalarParameterGuids);
			// In case we need to grab layer names.
			FMaterialLayersFunctions Layers;
			MaterialInterface->GetMaterialLayers(Layers);

			for (int32 ScalarParameterIndex = 0; ScalarParameterIndex < ScalarParameterInfos.Num(); ++ScalarParameterIndex)
			{
				FMaterialParameterInfo ScalarParameterInfo = ScalarParameterInfos[ScalarParameterIndex];
				ScalarParameterInfoSet.Add(ScalarParameterInfo);
			}

			MaterialInterface->GetAllVectorParameterInfo(ColorParameterInfos, ColorParameterGuids);
			for (int32 ColorParameterIndex = 0; ColorParameterIndex < ColorParameterInfos.Num(); ++ColorParameterIndex)
			{
				FMaterialParameterInfo ColorParameterInfo = ColorParameterInfos[ColorParameterIndex];
				ColorParameterInfoSet.Add(ColorParameterInfo);
			}
	};

	if (BatchMaterialTrack && 
		!BatchMaterialTrack->SlotName.IsEmpty())
	{
		for (auto PrimitiveComponent : PrimitiveComponents)
		{
			UCutsceneUtils::ForEachMaterialOnComponentBySlotName(PrimitiveComponent, BatchMaterialTrack->SlotName, DoExtractParameters);
		}
	}
	else {
		for (auto PrimitiveComponent : PrimitiveComponents)
		{
			TArray<UMaterialInterface*> UsedMaterials;
			PrimitiveComponent->GetUsedMaterials(UsedMaterials);
			for (auto MaterialInterface : UsedMaterials)
			{
				DoExtractParameters(MaterialInterface);
			}
		}
	}

	// Sort the parameter infos by name and then by index.
	ParameterInfosAndActions.Reserve(ScalarParameterInfoSet.Num() + ColorParameterInfoSet.Num());
	for (auto ScalarParameterInfo : ScalarParameterInfoSet)
	{
		// FMaterialParameterInfo ScalarParameterInfo = ScalarParameterInfos[ScalarParameterIndex];
		FText ParameterDisplayName = FText::FromName(ScalarParameterInfo.Name);
		FUIAction AddParameterMenuAction( FExecuteAction::CreateSP( this, &FMovieSceneBatchMaterialTrackEditor::AddScalarParameter, ObjectBinding, MaterialTrack, ScalarParameterInfo, FString(TEXT("")), FString(TEXT("")) ));
		FBatchParameterInfoAndAction InfoAndAction(ScalarParameterInfo, ParameterDisplayName, AddParameterMenuAction );
		ParameterInfosAndActions.Add(InfoAndAction);
	}
	for (auto ColorParameterInfo : ColorParameterInfoSet)
	{
		// FMaterialParameterInfo ColorParameterInfo = ColorParameterInfos[ColorParameterIndex];
		FText ParameterDisplayName = FText::FromName(ColorParameterInfo.Name);
		FUIAction AddParameterMenuAction( FExecuteAction::CreateSP( this, &FMovieSceneBatchMaterialTrackEditor::AddColorParameter, ObjectBinding, MaterialTrack, ColorParameterInfo, FString(TEXT("")), FString(TEXT("")) ));
		FBatchParameterInfoAndAction InfoAndAction(ColorParameterInfo, ParameterDisplayName, AddParameterMenuAction );
		ParameterInfosAndActions.Add(InfoAndAction);
	}

	// Sort and generate menu.
	ParameterInfosAndActions.Sort();

	for (FBatchParameterInfoAndAction InfoAndAction : ParameterInfosAndActions)
	{
		MenuBuilder.AddMenuEntry(InfoAndAction.ParameterDisplayName, FText(), FSlateIcon(), InfoAndAction.Action );
	}
}

UMaterialInterface* FMovieSceneBatchMaterialTrackEditor::GetMaterialInterfaceForTrack(FGuid ObjectBinding, UMovieSceneMaterialTrack* MaterialTrack)
{
	return nullptr;
}

void FMovieSceneBatchMaterialTrackEditor::AddNewBatchMaterialTrack(TArray<FGuid> ObjectBindings)
{
	FScopedTransaction AddSpawnTrackTransaction(LOCTEXT("AddBatchMaterialTrack_Transaction", "Add BatchMaterialTrack"));
	
	UMovieScene* MovieScene = GetSequencer()->GetFocusedMovieSceneSequence()->GetMovieScene();
	UClass* TrackClass = UMovieSceneBatchMaterialTrack::StaticClass();
	
	for (FGuid ObjectBinding : ObjectBindings)
	{
		AddTrack(GetSequencer()->GetFocusedMovieSceneSequence()->GetMovieScene(), ObjectBinding, UMovieSceneBatchMaterialTrack::StaticClass(), NAME_None);			
	}
	GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
}

#undef LOCTEXT_NAMESPACE