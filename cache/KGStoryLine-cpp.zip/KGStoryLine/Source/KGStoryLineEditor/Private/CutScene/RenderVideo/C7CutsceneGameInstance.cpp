// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#include "CutScene/RenderVideo/C7CutsceneGameInstance.h"

#include "CutScene/CutSceneEditor.h"
#include "KGStoryLineEditorModule.h"
#include "LevelSequenceActor.h"
#include "Modules/ModuleManager.h"
#include "EngineUtils.h"
#include "ILevelSequenceEditorToolkit.h"
#include "LevelSequence.h"
#include "LevelSequencePlayer.h"
#include "Bindings/MovieSceneSpawnableActorBinding.h"
#include "Camera/CameraComponent.h"
#include "Components/SkeletalMeshComponent.h"


TWeakObjectPtr<ULevelSequence> UCutSceneRenderLuaGameInstance::TargetSequence = nullptr; 

void UCutSceneRenderLuaGameInstance::Tick(float DeltaTime)
{
	OnLuaTick(DeltaTime);
	InitializeBindings();

	if (LevelSequencePlayer.IsValid())
	{
		if (UCameraComponent* CameraComponent = LevelSequencePlayer->GetActiveCameraComponent())
		{
			SetCurrentCamera(CameraComponent->GetOwner(), true);	
		}
	}
}

TStatId UCutSceneRenderLuaGameInstance::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(UCutSceneRenderLuaGameInstance, STATGROUP_Tickables);
}

void UCutSceneRenderLuaGameInstance::OnCameraCut(UCameraComponent* CameraComponent)
{
	if (!CameraComponent)
		return;
	
	this->SetCurrentCamera(CameraComponent->GetOwner(), true);	
}

void UCutSceneRenderLuaGameInstance::InitializeBindings()
{
	if (bBindingInitialized)
		return;
	
	if (!WorldContext.IsValid() || !WorldContext->GetWorld())
		return;

	ALevelSequenceActor* SequenceActor = nullptr;
	LevelSequencePlayer = nullptr;
	for (auto It = TActorIterator<ALevelSequenceActor>(WorldContext->GetWorld()); It; ++It)
	{
		if (It->GetSequence() == TargetSequence)
		{
			SequenceActor = *It;
			LevelSequencePlayer = SequenceActor->GetSequencePlayer();
		}
	}

	if (!ensure(SequenceActor && LevelSequencePlayer.IsValid()))
		return;

	if (!bBoundCameraCut)
	{
		bBoundCameraCut = true;
		LevelSequencePlayer->OnCameraCut.AddDynamic(this, &UCutSceneRenderLuaGameInstance::OnCameraCut);	
	}
	
	ULevelSequence* Sequence = SequenceActor->GetSequence();
	if(!Sequence)
		return;
	UMovieScene* MovieScene = Sequence->GetMovieScene();
	if (!MovieScene)
		return;

	const TMap<FName, FMovieSceneObjectBindingIDs>& BindingGroups = MovieScene->AllTaggedBindings();
	TMap<FMovieSceneObjectBindingID, AActor*> BindingActors;
	TMap<FMovieSceneObjectBindingID, TArray<FName>> BindingTags;
	for (const TPair<FName, FMovieSceneObjectBindingIDs>& Pair : BindingGroups)
	{
		for (FMovieSceneObjectBindingID ID : Pair.Value.IDs)
		{
			BindingTags.FindOrAdd(ID).Add(Pair.Key);
		}
	}
	
	UWorld* World = SequenceActor->GetWorld();
	for (auto [Tag, Bindings] : BindingGroups)
	{
		for (FMovieSceneObjectBindingID Binding : Bindings.IDs)
		{
			if (!Binding.IsValid()) continue;

			AActor* Actor = nullptr;

			FMovieSceneSequenceID SequenceID = Binding.ResolveSequenceID(MovieSceneSequenceID::Root, *LevelSequencePlayer);
			if (UMovieSceneSequence* SubSequence = LevelSequencePlayer->State.FindSequence(SequenceID))
			{
				if (UMovieScene* SubMovieScene = SubSequence->GetMovieScene())
				{
					if (FMovieSceneSpawnable* Spawnable = SubMovieScene->FindSpawnable(Binding.GetGuid()))
					{
						Actor = Cast<AActor>(Spawnable->GetObjectTemplate());
					}
				}
			}
			
			FMovieSceneSpawnable* MovieSceneSpawnable = MovieScene->FindSpawnable(Binding.GetGuid());
			if (!Actor && MovieSceneSpawnable && MovieSceneSpawnable->GetObjectTemplate() && MovieSceneSpawnable->GetObjectTemplate()->IsA<AActor>())
			{
				Actor = Cast<AActor>(MovieSceneSpawnable->GetObjectTemplate());
			}

			if (!Actor)
			{
				if (const FMovieSceneBindingReferences* References = Sequence->GetBindingReferences())
				{
					if (const UMovieSceneCustomBinding* CustomBinding = References->GetCustomBinding(Binding.GetGuid(), 0))
					{
						if (const UMovieSceneSpawnableActorBinding* ActorBinding = Cast<UMovieSceneSpawnableActorBinding>(CustomBinding))
						{
							Actor = Cast<AActor>(const_cast<UMovieSceneSpawnableActorBinding*>(ActorBinding)->GetObjectTemplate());
						}
					}
				}
			}

			if (!Actor)
			{
				if (UMovieSceneSequence* SubSequence = LevelSequencePlayer->State.FindSequence(SequenceID))
				{
					if (const FMovieSceneBindingReferences* References = SubSequence->GetBindingReferences())
					{
						if (const UMovieSceneCustomBinding* CustomBinding = References->GetCustomBinding(Binding.GetGuid(), 0))
						{
							if (const UMovieSceneSpawnableActorBinding* ActorBinding = Cast<UMovieSceneSpawnableActorBinding>(CustomBinding))
							{
								Actor = Cast<AActor>(const_cast<UMovieSceneSpawnableActorBinding*>(ActorBinding)->GetObjectTemplate());
							}
						}
					}
				}
			}

			if (Actor)
			{
				bBindingInitialized = true;
				UClass* InClass = Actor->GetClass();

				FActorSpawnParameters SpawnParameters;
				SpawnParameters.Template = Actor;
				FVector Location = FVector(1e9, 1e9, 1e9);
				FRotator Rotation = Actor->GetActorRotation();
				if (!BindingActors.Contains(Binding))
				{
					AActor* SpawnActor = World->SpawnActor(InClass, &Location, &Rotation, SpawnParameters);
					SequenceActor->SetBinding(Binding, {SpawnActor});
					BindingActors.Add(Binding, SpawnActor);
				}
				
				const TArray<FName> Tags = BindingTags.Contains(Binding) ? BindingTags[Binding] : TArray<FName>();
				RequestBindingTagActor(BindingActors[Binding], Tag, Tags);
			}
		}
	}

	// 更新一下组件, 否则第一帧出来会不对.
	for (TPair<FMovieSceneObjectBindingID, AActor*> Pair : BindingActors)
	{
		AActor* Actor = Pair.Value;
		if (Actor->IsValidLowLevel())
		{
			for (auto Comp : Actor->K2_GetComponentsByClass(USkeletalMeshComponent::StaticClass()))
			{
				USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(Comp);
				SkeletalMeshComponent->RecreateRenderState_Concurrent();
				SkeletalMeshComponent->TickAnimation(0.0f, false);
				SkeletalMeshComponent->RefreshBoneTransforms();
				SkeletalMeshComponent->FinalizeBoneTransform();
				SkeletalMeshComponent->UpdateComponentToWorld();
				SkeletalMeshComponent->MarkRenderTransformDirty();
				SkeletalMeshComponent->MarkRenderDynamicDataDirty();
				SkeletalMeshComponent->SendRenderTransform_Concurrent();
			}
		}
		
	}

	if (const ULevel* PersistentLevel = World->PersistentLevel)
	{
		const FString LevelPackageName = PersistentLevel->GetOutermost()->GetName();
		// InitializeCharacterLighting(LevelPackageName);
	}
}

void UC7CutsceneGameInstance::OnStart()
{
	Super::OnStart();

	FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
	TSharedPtr<FCutSceneEditor> CutSceneEditor = KGStoryLineEditorModule.GetCutSceneEditorPtr();
	if (CutSceneEditor.IsValid())
	{
		// Destroy Editor LuaEnv
		CutSceneEditor->UnInitLuaEnvironment();
	};

	UWorld* World = GetWorld();

	// Create Render Lua Environment
	InitLuaEnv();
	UClass* LuaEnvClass = LuaEnv->GetClass();
	if (FProperty* Property = LuaEnvClass->FindPropertyByName("LuaGI"))
	{
		ULuaGameInstance* LuaGameInstance = nullptr;
		Property->GetValue_InContainer(LuaEnv, &LuaGameInstance);
		if (LuaGameInstance->IsValidLowLevel())
		{
			LuaGameInstance->Uninit();
		}

		LuaGameInstance = NewObject<UCutSceneRenderLuaGameInstance>(this);
		LuaGameInstance->SetLuaEnv(LuaEnv);
		LuaGameInstance->Init(this);
		Property->SetValue_InContainer(LuaEnv, &LuaGameInstance);
	}
	
	// LuaEditorEnv = UEditorLuaEnv::CreateLuaEnv(World, UCutSceneRenderLuaGameInstance::StaticClass());
    UCutSceneRenderLuaGameInstance *RenderLuaGameInstance = Cast<UCutSceneRenderLuaGameInstance>(LuaEnv->GetLuaGameInstance());
	if (ensure(RenderLuaGameInstance))
    {
    	RenderLuaGameInstance->WorldContext = World;
    	RenderLuaGameInstance->BeginPlay(this);   
    }
}

void UC7CutsceneGameInstance::Shutdown()
{
	if (LuaEnv)
		UninitLuaEnv();

	// Re-Create Editor Environment
	FTimerHandle DelayUpdateTimer;
	GEditor->GetTimerManager()->SetTimer(DelayUpdateTimer, []()
	{
		FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
		TSharedPtr<FCutSceneEditor>& CutSceneEditor = KGStoryLineEditorModule.GetCutSceneEditorPtr();
		if (!CutSceneEditor.IsValid() || !CutSceneEditor->LevelSequence.IsValid())
			return;
		ULevelSequence* LevelSequence = CutSceneEditor->LevelSequence.Get();
		CutSceneEditor.Reset();
		CutSceneEditor = MakeShareable(new FCutSceneEditor());
		IAssetEditorInstance* AssetEditor = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(LevelSequence, false);
		ILevelSequenceEditorToolkit* LevelSequenceEditor = static_cast<ILevelSequenceEditorToolkit*>(AssetEditor);
		TSharedPtr<ISequencer> Sequencer = LevelSequenceEditor ? LevelSequenceEditor->GetSequencer() : nullptr;
		if (!Sequencer.IsValid())
			return;
		CutSceneEditor->UninitializeRoleComposite();
		CutSceneEditor->InitLuaEnvironment();
		CutSceneEditor->InitializeRoleComposite(Sequencer, LevelSequence);
		CutSceneEditor->InitPostProcessPreview();
		CutSceneEditor->InitializeRenderPipeline();
		CutSceneEditor->IterateTagsForRoleComposite();
	}, 1, false, 1);
	
	Super::Shutdown();
}

bool UC7CutsceneGameInstance::IsPIE() const
{
	return true;
} 