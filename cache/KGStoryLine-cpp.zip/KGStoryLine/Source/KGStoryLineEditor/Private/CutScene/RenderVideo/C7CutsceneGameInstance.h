// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#pragma once

#include "CoreMinimal.h"
#include "Misc/KGGameInstanceBase.h"
#include "Camera/CameraComponent.h"
#include "C7CutsceneGameInstance.generated.h"

class ULevelSequence;
class ULevelSequencePlayer;

/**
 * 目前游戏里有好多逻辑默认这样处理:
 * 当有 GameInstance 的时候, 这个 GameInstance 就应该是 UKGGameInstanceBase.
 * 而 UKGGameInstanceBase 的 LuaEnv 的类型是 ULuaEnv.
 *
 * LevelSequence的录制流程比会启动一个GameInstance, 所以目前这里还是用不了编辑器那一套.
 * 目前还是得用运行时的这一套.
 */
UCLASS(BlueprintType, Blueprintable)
class KGSTORYLINEEDITOR_API UCutSceneRenderLuaGameInstance : public ULuaGameInstance, public FTickableGameObject
{
	GENERATED_BODY()

public:
	virtual FString GetLuaFilePath_Implementation() const override
	{
		return TEXT("Gameplay.CinematicSystem.CutScene.Editor.CutSceneEditorLuaGameInstance");
	}
	
	UFUNCTION(BlueprintImplementableEvent)
	void OnLuaTick(float DeltaTime);
	
	UFUNCTION(BlueprintImplementableEvent)
	void RequestBindingTagActor(AActor* Actor, FName Tag, const TArray<FName>& Tags);

	UFUNCTION()
	bool bIsRenderGameInstance() { return true; }
	
	UFUNCTION(BlueprintImplementableEvent)
	void InitializeCharacterLighting(const FString& LevelPath);
	
	UFUNCTION(BlueprintImplementableEvent)
	void SetCurrentCamera(UObject* Object, bool bArg);
	
	virtual void Tick(float DeltaTime) override;
	virtual TStatId GetStatId() const override;
	
	TWeakObjectPtr<UObject> WorldContext;
	TWeakObjectPtr<ULevelSequencePlayer> LevelSequencePlayer;
	static TWeakObjectPtr<ULevelSequence> TargetSequence;

private:
	UFUNCTION()
	void OnCameraCut(UCameraComponent* CameraComponent);
	
	void InitializeBindings();
	bool bBindingInitialized = false;
	bool bBoundCameraCut = false;
};

UCLASS()
class KGSTORYLINEEDITOR_API UC7CutsceneGameInstance : public UKGGameInstanceBase
{
	GENERATED_BODY()

public:
	// virtual void Init() override; // Init 时机太早了, 应该在OnStart开始搞Lua
	virtual void OnStart() override;
	virtual void Shutdown() override;

	UFUNCTION(BlueprintCallable)
	bool IsPIE() const;
};
