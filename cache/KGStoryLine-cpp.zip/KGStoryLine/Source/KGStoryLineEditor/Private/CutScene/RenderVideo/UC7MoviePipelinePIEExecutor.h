// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "MoviePipelinePIEExecutor.h"
#include "UC7MoviePipelinePIEExecutor.generated.h"

UCLASS()
class UC7MoviePipelinePIEExecutor : public UMoviePipelinePIEExecutor
{
	GENERATED_BODY()
protected:
	virtual void Start(const UMoviePipelineExecutorJob* InJob) override;
};
