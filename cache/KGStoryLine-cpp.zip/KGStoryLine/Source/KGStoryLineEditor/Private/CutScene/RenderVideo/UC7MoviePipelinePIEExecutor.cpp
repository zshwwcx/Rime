// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#include "CutScene/RenderVideo/UC7MoviePipelinePIEExecutor.h"

#include "CutScene/RenderVideo/C7CutsceneGameInstance.h"
#include "Editor.h"
#include "LevelSequence.h"
#include "MoviePipelineOutputSetting.h"
#include "MoviePipelineQueue.h"
#include "Framework/Application/SlateApplication.h"

void UC7MoviePipelinePIEExecutor::Start(const UMoviePipelineExecutorJob* InJob)
{
	// 配置了一个PIE, 但是还没开始跑.
	Super::Start(InJob);

	if (!InJob)
		return;

	UMoviePipelinePrimaryConfig* Config = InJob->GetConfiguration();
	if (!Config)
		return;

	FVector2D OutputResolution = FVector2D::Zero();
	TArray<UMoviePipelineSetting*> UserSettings = Config->GetUserSettings();
	for (UMoviePipelineSetting* UserSetting : UserSettings)
	{
		if (UMoviePipelineOutputSetting* OutputSetting = Cast<UMoviePipelineOutputSetting>(UserSetting))
		{
			OutputResolution = OutputSetting->OutputResolution;
			break;
		}
	}

	if (ensure(OutputResolution != FVector2D::Zero()))
	{
		TArray<TSharedRef<SWindow>> Windows = FSlateApplication::Get().GetTopLevelWindows();
		for (TSharedRef<SWindow> Window : Windows)
		{
			UClass* SuperClass = GetClass()->GetSuperClass();
			if (SuperClass && Window->GetCreatedInLocation().ToString().Contains(SuperClass->GetName()))
			{
				FVector2D CurrentPos = Window->GetPositionInScreen();
				FVector2D CurrentSize = Window->GetSizeInScreen();
				// Make New Size Center
				FVector2D NewPos = FVector2D(CurrentPos.X + (CurrentSize.X - OutputResolution.X) / 2, CurrentPos.Y + (CurrentSize.Y - OutputResolution.Y) / 2);
				Window->ReshapeWindow(NewPos, OutputResolution);
			}
		}
	}
	
	// 为PIE设置一个Cutscene GameInstance进行控制, 主要是需要一个Lua虚拟机.
	const TOptional<FRequestPlaySessionParams>& Params = GEditor->GetPlaySessionRequest();
	if (ensure(Params.IsSet()))
	{
		// const_cast 问题不大, 因为就在Super里面刚刚才创建好设置GEditor的. 这里再重新拿出来改改问题不大.
		FRequestPlaySessionParams Info = Params.GetValue();
		Info.GameInstanceClass = UC7CutsceneGameInstance::StaticClass();
		UCutSceneRenderLuaGameInstance::TargetSequence = Cast<ULevelSequence>(InJob->Sequence.TryLoad());
		GEditor->RequestPlaySession(Info);
	}
}