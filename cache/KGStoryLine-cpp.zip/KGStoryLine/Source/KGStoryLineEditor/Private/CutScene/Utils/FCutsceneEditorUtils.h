// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "CoreMinimal.h"

class FCutsceneEditorUtils
{
public:
	static void CreateNotification(const FText& Message, bool bSuccess, float FadeOutDuration = 1.5f, float ExpireDuration = 1.5f, bool bWarning = false);
};
