// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/LevelStreaming.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "CutSceneEditorFunctionLibrary.generated.h"

class UAnimSequence;
class USkeleton;
class USkeletalMesh;
class ISequencer;
class UMovieSceneSection;
/**
 * Methods used in Editor Lua
 */
UCLASS(Blueprintable)
class KGSTORYLINEEDITOR_API UCutSceneEditorFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:
	UFUNCTION()
	static void SetDisplayRate(int64 SectionID, int32 Fps);

	UFUNCTION()
	static int32 GetDisplayRate(int64 SectionID);

	UFUNCTION()
	static void SetLockToFrame(int64 SectionID, bool bLockToFrame);

	UFUNCTION()
	static bool GetLockToFrame(int64 SectionID);

	/**
	 * 编辑器切换子关卡的可见性
	 * @param LevelName 子关卡名称
	 * @param bVisible 可见性
	 */
	UFUNCTION()
	static void SetLevelVisibility(const FString& LevelName, bool bVisible);

	/**
	 * 获取子关卡的可见性
	 * @param LevelName 子关卡名称
	 * @return 可见性
	 */
	UFUNCTION()
	static bool GetLevelVisibility(const FString& LevelName);
	
	UFUNCTION(BlueprintCallable)
	static UAnimSequence* ImportAnimationFromFbx(const FString FbxPath, const FString SaveAssetPath, USkeletalMesh* RetargetMesh, USkeleton* Skeleton);

	UFUNCTION(BlueprintCallable)
	static void TryInvokeTab(const FName TabName);
	
	UFUNCTION(BlueprintCallable)
	static void OpenUDPTransform();
	
	UFUNCTION(BlueprintCallable)
	static bool IsMayaLiveLinkConnected();
	
	UFUNCTION(BlueprintCallable)
	static bool InitializeMayaLiveLink();
	
	UFUNCTION(BlueprintCallable)
	static bool SetMayaLiveLinkAnimClass(int64 InActorID, FName SubjectName);
	
private:
	static TSharedPtr<ISequencer> GetSequencer(const UObject* InObj);
	static ULevelStreaming* GetLevelByName(const FString& LevelName);
};
