// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "MovieScene.h"
#include "PropertyCustomizationHelpers.h"
#include "ReferenceSkeleton.h"
#include "Animation/AnimData/IAnimationDataController.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Tracks/MovieSceneSkeletalAnimationTrack.h"
#include "AnimSeqRootFixTool.generated.h"

class SEditableTextBox;
class UAnimSequence;
class ULevelSequence;

class SAnimSeqRootFixTool : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SAnimSeqRootFixTool) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);
	
	TSharedRef<SWidget> CreateRootFixWidget();
	TSharedRef<SWidget> CreateCopyWidget();
	
private:
	FString AnimPath;
	FString SequencePath;
	
	FString TagSequencePath;
	FTransform MoveTransform;
	TSharedPtr<SEditableTextBox> TargetFolderTextBox;
};

UCLASS(Blueprintable)
class UAnimSeqRootFixTool : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
public:

	static void OpenPanel();
	
	static FVector CalcNewLocation(const FReferenceSkeleton& RefSkeleton, const int32 RootBoneIndex, TFunction<FVector(const FName BoneName)> GetWorldBoneLocation, int32& MainBoneIndex);

	/** 调单个AnimSequence */
	UFUNCTION(BlueprintCallable)
	static bool AdjustAnimationRootToFeet(UAnimSequence* AnimSequence, USkeletalMesh* SkeletalMesh, FVector& OutDeltaTranslation, bool bNewImported);

	/** 调一整个Level Sequence */
	UFUNCTION(BlueprintCallable)
	static bool AdjustSequenceRootToFeet(ULevelSequence* LevelSequence);

	/** 把位移数据设置到AnimSequence的MetaData中 */
	UFUNCTION(BlueprintCallable)
	static void SetDeltaLocationMetaData(const UObject* AnimSequence, FTransform MainBoneTransform, const FVector& DeltaLocation, const FString& KeyPostFix = TEXT(""));

	/** 从AnimSequence的MetaData中获取位移数据 */
	UFUNCTION(BlueprintCallable)
	static bool GetDeltaLocationMetaData(const UObject* AnimSequence, FTransform MainBoneTransform, FVector& OutDeltaLocation, const FString& KeyPostFix = TEXT(""));

	/** 把在子Sequence中设置的Tag全部复制到主Sequence中 */
	UFUNCTION(BlueprintCallable)
	static void MergeTaggedBindingsToMainSequence(ULevelSequence* SourceSequence);

	UFUNCTION(BlueprintCallable)
	static void DuplicateAssetsAndFixReferences(const TArray<FString>& SourcePaths, const FString& TargetFolder);

	UFUNCTION(BlueprintCallable)
	static void AttachActorsToRoot(ULevelSequence* LevelSequence);

	inline static bool bProcessBLevel = false;
	
private:
	static void ProcessBindingActor(ULevelSequence* InSequence, FGuid BindingID, const FString& Name, const AActor* ActorTemplate);
	static FTransform MakeAdditiveTransform(const FRotator& ActorRot, const FVector& DeltaTranslation);
	static bool MoveBoneTransforms(const FVector& OutDeltaTranslation, const IAnimationDataModel* DataModel, const FReferenceSkeleton& RefSkeleton, double Tolerance, int32 MainBoneIndex, const FTransform& ParentTransform, const TScriptInterface<IAnimationDataController>& Controller, int ChildBoneIndex);
	static void CollectTaggedBindingsRecursive(ULevelSequence* Sequence, const FMovieSceneSequenceHierarchy* Hierarchy, FMovieSceneSequenceID SequenceID, TMap<FName, FMovieSceneObjectBindingIDs>& OutMap);
	
	static void ForEachLevelSequenceRecursive(ULevelSequence* LevelSequence, int32 ParentIndex, const TFunctionRef<void(ULevelSequence*, int32)>& Func);
	static void ForeachSpawnableActorGuid(const ULevelSequence* LevelSequence, const TFunctionRef<void(UMovieScene*, FGuid, FString, AActor*)>& Func);
	static FGuid MovieSceneAddSpawnable(UMovieScene* MovieScene, const FName& Name, const TSubclassOf<AActor>& ActorClass);
	static AActor* GetActorFromAnimationTrack(const ULevelSequence* Sequence, const UMovieSceneSkeletalAnimationTrack* AnimationTrack);
	static TArray<FName> GetUsedBonesInMesh(USkeletalMesh* SkeletalMesh);
};

