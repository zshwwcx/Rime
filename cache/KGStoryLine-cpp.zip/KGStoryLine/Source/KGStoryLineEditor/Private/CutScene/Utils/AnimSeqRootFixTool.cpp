#include "CutScene/Utils/AnimSeqRootFixTool.h"

#include "AnimationRuntime.h"
#include "AssetToolsModule.h"
#include "ContentBrowserModule.h"
#include "Editor.h"
#include "FileHelpers.h"
#include "IContentBrowserSingleton.h"
#include "ILevelSequenceModule.h"
#include "LevelSequence.h"
#include "MovieScene.h"
#include "SAdvancedTransformInputBox.h"
#include "Animation/AnimSequence.h"
#include "Animation/SkeletalMeshActor.h"
#include "Animation/Skeleton.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Bindings/MovieSceneSpawnableActorBinding.h"
#include "Components/SkeletalMeshComponent.h"
#include "Framework/Application/SlateApplication.h"
#include "Sections/MovieSceneSubSection.h"
#include "Sections/MovieScene3DTransformSection.h"
#include "Tracks/MovieScene3DTransformTrack.h"
#include "Tracks/MovieSceneSkeletalAnimationTrack.h"
#include "Tracks/MovieSceneSubTrack.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "Channels/MovieSceneDoubleChannel.h"
#include "Compilation/MovieSceneCompiledDataManager.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Sections/MovieSceneBoolSection.h"
#include "Serialization/ArchiveReplaceObjectRef.h"
#include "Tracks/MovieScene3DAttachTrack.h"
#include "Tracks/MovieSceneSpawnTrack.h"
#include "UObject/MetaData.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Notifications/SNotificationList.h"

#define LOCTEXT_NAMESPACE "AnimSeqRootFixTool"

void SAnimSeqRootFixTool::Construct(const FArguments& InArgs)
{
	ChildSlot
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SBorder)
			.BorderBackgroundColor(FLinearColor(0.2f, 0.2f, 0.2f, 1.f)) 
			.Padding(5)
			[
				CreateRootFixWidget()	
			]
		]
		
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SBorder)
			.Padding(5)
			[
				CreateCopyWidget()	
			]
		]
	];
}

TSharedRef<SWidget> SAnimSeqRootFixTool::CreateRootFixWidget()
{
	return SNew(SVerticalBox)
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SObjectPropertyEntryBox)
			.AllowedClass(UAnimSequence::StaticClass())
			.ObjectPath_Lambda([this]()
			{
				return AnimPath;
			})
			.OnObjectChanged_Lambda([this](const FAssetData& InAssetData)
			{
				AnimPath = InAssetData.GetObjectPathString();
			})
		]
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SButton).Text(FText::FromString(TEXT("调整动画Root偏移"))).OnClicked_Lambda([this]()
			{
				UAnimSequence* AnimSequence = Cast<UAnimSequence>(FSoftObjectPath(*AnimPath).TryLoad());
				FVector DeltaTranslation;
				UAnimSeqRootFixTool::AdjustAnimationRootToFeet(AnimSequence, nullptr, DeltaTranslation, false);
				return FReply::Handled();
			})
		]
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SButton).Text(FText::FromString(TEXT("调整动画Root偏移(动画重新导入之后)"))).OnClicked_Lambda([this]()
			{
				UAnimSequence* AnimSequence = Cast<UAnimSequence>(FSoftObjectPath(*AnimPath).TryLoad());
				FVector DeltaTranslation;
				UAnimSeqRootFixTool::AdjustAnimationRootToFeet(AnimSequence, nullptr, DeltaTranslation, true);
				return FReply::Handled();
			})
		]
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SObjectPropertyEntryBox)
			.AllowedClass(ULevelSequence::StaticClass())
			.ObjectPath_Lambda([this]()
			{
				return SequencePath;
			})
			.OnObjectChanged_Lambda([this](const FAssetData& InAssetData)
			{
				SequencePath = InAssetData.GetObjectPathString();
			})
		]

		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SCheckBox)
			.OnCheckStateChanged_Lambda([](ECheckBoxState NewState)
			{
				UAnimSeqRootFixTool::bProcessBLevel = NewState == ECheckBoxState::Checked;
			})
			.IsChecked_Lambda([]()
			{
				return UAnimSeqRootFixTool::bProcessBLevel ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
			})
			.Content()
			[
				SNew(STextBlock).Text(FText::FromString(TEXT("是否处理BLevel")))
			]
		]
		
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SButton).Text(FText::FromString(TEXT("调整Sequence Root偏移(包含所有动画及对应角色)"))).OnClicked_Lambda([this]()
			{
				if (ULevelSequence* LevelSequence = Cast<ULevelSequence>(FSoftObjectPath(*SequencePath).TryLoad()))
				{
					UAnimSeqRootFixTool::AdjustSequenceRootToFeet(LevelSequence);
				}
				return FReply::Handled();
			})
		]
		
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SButton).Text(FText::FromString(TEXT("获取子Sequence标签"))).OnClicked_Lambda([this]()
			{
				if (ULevelSequence* LevelSequence = Cast<ULevelSequence>(FSoftObjectPath(*SequencePath).TryLoad()))
				{
					UAnimSeqRootFixTool::MergeTaggedBindingsToMainSequence(LevelSequence);
				}
				return FReply::Handled();
			})
		]
		
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SButton).Text(FText::FromString(TEXT("给Sequence添加一个根Actor"))).OnClicked_Lambda([this]()
			{
				if (ULevelSequence* LevelSequence = Cast<ULevelSequence>(FSoftObjectPath(*SequencePath).TryLoad()))
				{
					UAnimSeqRootFixTool::AttachActorsToRoot(LevelSequence);
				}
				return FReply::Handled();
			})
		]
	
		+ SVerticalBox::Slot().AutoHeight().Padding(5)
		[
			SNew(SButton).Text(FText::FromString(TEXT("Revert All Dirty Packages"))).OnClicked_Lambda([this]()
			{
				TArray<UPackage*> DirtyPackages;
				FEditorFileUtils::GetDirtyContentPackages(DirtyPackages);
				UPackageTools::ReloadPackages(DirtyPackages);
				return FReply::Handled();
			})
		];
}

TSharedRef<SWidget> SAnimSeqRootFixTool::CreateCopyWidget()
{
	return SNew(SVerticalBox)

	+ SVerticalBox::Slot()
	.AutoHeight()
	.Padding(2)
	[
		SAssignNew(TargetFolderTextBox, SEditableTextBox)
		.HintText(NSLOCTEXT("DuplicateAssets", "TargetFolderHint", "/Game/MyNewFolder"))
	]

	// 按钮：执行复制
	+ SVerticalBox::Slot()
	.AutoHeight()
	.Padding(2)
	[
		SNew(SButton)
		.Text(NSLOCTEXT("DuplicateAssets", "DuplicateButton", "复制选中的内容到指定目录"))
		.OnClicked_Lambda([this]()
		{
			// 获取目标目录
			FString TargetFolder = TargetFolderTextBox->GetText().ToString();

			if (TargetFolder.IsEmpty())
			{
				UE_LOG(LogTemp, Warning, TEXT("Target folder is empty!"));
				return FReply::Handled();
			}

			// 获取Content Browser中当前选中的资产和文件夹
			TArray<FString> SelectedPaths;
			{
				FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
				TArray<FAssetData> SelectedAssets;
				TArray<FString> SelectedFolders;

				ContentBrowserModule.Get().GetSelectedAssets(SelectedAssets);
				ContentBrowserModule.Get().GetSelectedFolders(SelectedFolders);

				for (const FAssetData& AssetData : SelectedAssets)
				{
					SelectedPaths.Add(AssetData.GetObjectPathString());
				}
				for (const FString& Folder : SelectedFolders)
				{
					SelectedPaths.Add(Folder);
				}
			}

			if (SelectedPaths.Num() == 0)
			{
				UE_LOG(LogTemp, Warning, TEXT("No assets or folders selected in Content Browser!"));
				return FReply::Handled();
			}

			// 调用工具函数
			UAnimSeqRootFixTool::DuplicateAssetsAndFixReferences(SelectedPaths, TargetFolder);

			return FReply::Handled();
			
		})
	];
}

void UAnimSeqRootFixTool::OpenPanel()
{
	TSharedRef<SWindow> Window = SNew(SWindow)
		.Title(FText::FromString(TEXT("Adjust Root Bone To Feet")))
		.SizingRule(ESizingRule::UserSized)
		.ClientSize(FVector2D(480, 480))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.IsTopmostWindow(true)
		[
			SNew(SAnimSeqRootFixTool)
		];
		
	FSlateApplication::Get().AddWindow(Window);
}

FVector UAnimSeqRootFixTool::CalcNewLocation(const FReferenceSkeleton& RefSkeleton, const int32 RootBoneIndex, TFunction<FVector(const FName BoneName)> GetWorldBoneLocation, int32& MainBoneIndex)
{
	FVector RootBoneLocation = GetWorldBoneLocation(RefSkeleton.GetRefBoneInfo()[0].Name);
	FName LeftFootBoneName = TEXT("foot_l");
	FName RightFootBoneName = TEXT("foot_r");
	MainBoneIndex = INDEX_NONE;
	
	// 获取脚部骨骼索引, 计算两脚的位置和Root的位置
	const int32 LeftFootIndex = RefSkeleton.FindBoneIndex(LeftFootBoneName);
	const int32 RightFootIndex = RefSkeleton.FindBoneIndex(RightFootBoneName);
	
	TArray<int32> DirectChildren;
	RefSkeleton.GetDirectChildBones(RootBoneIndex, DirectChildren);
		
	if (DirectChildren.Num() == 0)
	{
		return RootBoneLocation;
	}

	// 找到child最多的骨骼
	int32 MaxChildCount = -1;
	for (int32 ChildIndex : DirectChildren)
	{
		// 递归计算该骨骼的所有子骨骼数量
		int32 TotalChildCount = 0;
		TArray<int32> Queue = {ChildIndex};
			
		for (int32 i = 0; i < Queue.Num(); i++)
		{
			int32 CurrentBone = Queue[i];
			TArray<int32> Children;
			RefSkeleton.GetDirectChildBones(CurrentBone, Children);
			Queue.Append(Children);
			TotalChildCount += Children.Num();
		}
			
		if (TotalChildCount > MaxChildCount)
		{
			MaxChildCount = TotalChildCount;
			MainBoneIndex = ChildIndex;
		}
	}
	
	// 如果找不到左右脚骨骼，使用备用方法
	if (LeftFootIndex == INDEX_NONE || RightFootIndex == INDEX_NONE)
	{
		// 备用方法：找到root下child最多的骨骼，计算其children的平均位置和最低点
		
		if (MainBoneIndex == INDEX_NONE)
		{
			return RootBoneLocation;
		}

		// 获取该骨骼的所有子骨骼
		TArray<int32> AllChildren = {MainBoneIndex};
		
		for (int32 i = 0; i < AllChildren.Num(); i++)
		{
			int32 CurrentBone = AllChildren[i];
			TArray<int32> Children;
			RefSkeleton.GetDirectChildBones(CurrentBone, Children);
			AllChildren.Append(Children);
		}
		
		if (AllChildren.Num() == 0)
		{
			return RootBoneLocation;
		}

		// 计算所有子骨骼的世界位置
		float MinZ = FLT_MAX;
		
		for (int32 ChildBoneIndex : AllChildren)
		{
			FName ChildBoneName = RefSkeleton.GetBoneName(ChildBoneIndex);
			FVector WorldLocation = GetWorldBoneLocation(ChildBoneName);
			
			MinZ = FMath::Min(MinZ, WorldLocation.Z);
		}
		
		// 计算目标位置：XY + 最低Z
		FVector SelectedBoneLocation = GetWorldBoneLocation(RefSkeleton.GetBoneName(MainBoneIndex));
		return FVector(SelectedBoneLocation.X, SelectedBoneLocation.Y, MinZ);
	}
	else
	{
		// 原有逻辑：使用左右脚计算目标位置
		const FVector LeftFootPos = GetWorldBoneLocation(LeftFootBoneName);
		const FVector RightFootPos = GetWorldBoneLocation(RightFootBoneName);
		
		// 计算目标位置: 水平中心 + 垂直最低点
		return FVector(
			(LeftFootPos.X + RightFootPos.X) / 2,  // X中心
			(LeftFootPos.Y + RightFootPos.Y) / 2,  // Y中心
			FMath::Min(LeftFootPos.Z, RightFootPos.Z) // Z最低点
		);
	}
}

bool UAnimSeqRootFixTool::MoveBoneTransforms(const FVector& OutDeltaTranslation, const IAnimationDataModel* DataModel, const FReferenceSkeleton& RefSkeleton,
	const double Tolerance, const int32 MainBoneIndex, const FTransform& ParentTransform, const TScriptInterface<IAnimationDataController>& Controller, const int ChildBoneIndex)
{
	const TArray<FTransform>& RefBonePose = RefSkeleton.GetRefBonePose();
	if (!ensure(RefBonePose.IsValidIndex(ChildBoneIndex)))
		return false;

	const bool bIsMainBone = ChildBoneIndex == MainBoneIndex;
	const FName ChildBoneName = RefSkeleton.GetBoneName(ChildBoneIndex);
	FTransform RefTransform = RefBonePose[ChildBoneIndex];

	TArray<FTransform> OutTransforms;
	DataModel->GetBoneTrackTransforms(ChildBoneName, OutTransforms);
			
	TArray<FVector3f> Positions;
	TArray<FQuat4f> Rotations;
	TArray<FVector3f> Scales;

	// 没有动画帧的跳过
	if (OutTransforms.Num() == 0)
	{
		OutTransforms = {RefTransform};
		if (bIsMainBone)
		{
			UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Skip this Bone: %s, No Animation Frame! "), *ChildBoneName.ToString());
			return false;	
		}	
	}

	// 也在原本的位置上, 这种也跳过, 但是要看看它的子骨骼有没有在远处.
	if (OutTransforms.Num() > 0)
	{
		if (RefBonePose[ChildBoneIndex].GetLocation().Equals(OutTransforms[0].GetLocation(), Tolerance))
		{
			bool bSame = true;
			for (const FTransform& Key : OutTransforms)
			{
				if (!Key.GetLocation().Equals(OutTransforms[0].GetLocation(), Tolerance))
				{
					bSame = false;
					break;
				}
			}
			if (bSame)
			{
				if (bIsMainBone)
				{
					UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Skip this Bone: %s, Same Position With RefSkeleton!"), *ChildBoneName.ToString());
					return false;
				}
				OutTransforms = {RefTransform};
			}
		}
	}

	// 挪回来
	for (FTransform& Transform : OutTransforms)
	{
		const FVector LocalPos = Transform.GetLocation();
		const FVector OldWorldPos = ParentTransform.TransformPosition(LocalPos);
		const FVector NewWorldPos = OldWorldPos - OutDeltaTranslation;
		const FVector NewLocalPos = ParentTransform.InverseTransformPosition(NewWorldPos);
		Transform.SetLocation(NewLocalPos);

		// 写回用
		Positions.Add(FVector3f(Transform.GetLocation()));
		Rotations.Add(FQuat4f(Transform.GetRotation()));
		Scales.Add(FVector3f(Transform.GetScale3D()));
	}

	UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Adjust Bone: %s"), *ChildBoneName.ToString());
	Controller->SetBoneTrackKeys(ChildBoneName, Positions, Rotations, Scales, false);
	return true;
}

TArray<FTransform> GetFirstFrameBoneTransforms(USkeletalMesh* SkeletalMesh, UAnimSequence* AnimSequence)
{
	UWorld* World = GEditor->GetEditorWorldContext().World();
	if (!World || !SkeletalMesh || !AnimSequence)
	{
		UE_LOG(LogTemp, Warning, TEXT("Invalid input."));
		return {};
	}

	AActor* TempActor = World->SpawnActor(ASkeletalMeshActor::StaticClass());
	USkeletalMeshComponent* SkelComp = Cast<USkeletalMeshComponent>(TempActor->GetComponentByClass(USkeletalMeshComponent::StaticClass())); 
	SkelComp->SetSkeletalMesh(SkeletalMesh);
	SkelComp->RegisterComponentWithWorld(World);
	SkelComp->SetAnimationMode(EAnimationMode::AnimationSingleNode);

	// 绑定动画并设置到第一帧
	SkelComp->SetAnimation(AnimSequence);
	SkelComp->SetPosition(0.0f, false); // 第0秒（第一帧）
	SkelComp->bPauseAnims = true;       // 暂停，防止自动更新

	// 触发骨骼更新
	SkelComp->TickAnimation(0.0f, false);
	SkelComp->RefreshBoneTransforms();
	TArray<FTransform> ComponentSpaceTransforms = SkelComp->GetComponentSpaceTransforms();
	TempActor->Destroy();
	return ComponentSpaceTransforms;
}

bool UAnimSeqRootFixTool::AdjustAnimationRootToFeet(UAnimSequence* AnimSequence, USkeletalMesh* SkeletalMesh, FVector& OutDeltaTranslation, const bool bNewImported)
{
	if (!AnimSequence) return false;
		
	// 获取动画数据模型和骨架
	IAnimationDataModel* DataModel = AnimSequence->GetDataModel();
	USkeleton* Skeleton = AnimSequence->GetSkeleton();
	if (!DataModel || !Skeleton) return false;

	const FReferenceSkeleton& RefSkeleton = SkeletalMesh ? SkeletalMesh->GetRefSkeleton() : Skeleton->GetReferenceSkeleton();
	constexpr int32 RootBoneIndex = 0;
	const FName RootBoneName = RefSkeleton.GetBoneName(RootBoneIndex);
	bool bUseSkeletalMeshBoneTransform = false;
	TArray<FTransform> ComponentSpaceTransforms = GetFirstFrameBoneTransforms(SkeletalMesh, AnimSequence);
	auto GetWorldBoneLocation = [&](const FName BoneName) -> FVector
	{
		const int32 BoneIndex = RefSkeleton.FindBoneIndex(BoneName);
		if (BoneIndex == INDEX_NONE) return FVector::ZeroVector;
		if (bUseSkeletalMeshBoneTransform && ComponentSpaceTransforms.IsValidIndex(BoneIndex))
		{
			return ComponentSpaceTransforms[BoneIndex].GetLocation();
		}
		else
		{
			FTransform BoneTransform = DataModel->GetBoneTrackTransform(BoneName, 0);
			int32 ParentIndex = RefSkeleton.GetParentIndex(BoneIndex);
			while (ParentIndex != INDEX_NONE)
			{
				FTransform ParentTransform = DataModel->GetBoneTrackTransform(RefSkeleton.GetBoneName(ParentIndex), 0);
				BoneTransform = BoneTransform * ParentTransform; // 子骨骼变换 * 父骨骼变换
				if (ParentIndex == 0)
					break;
				ParentIndex = RefSkeleton.GetParentIndex(ParentIndex);
			}

			return  BoneTransform.GetLocation();
		}
	};

	constexpr double Tolerance = 0.01; // 和RefPose进行比较时的误差值
	int32 MainBoneIndex = INDEX_NONE;
	
	TArray<FName> UsedNames = GetUsedBonesInMesh(SkeletalMesh);
	
	FVector DeltaTranslation = CalcNewLocation(RefSkeleton, RootBoneIndex, GetWorldBoneLocation, MainBoneIndex);
	if (MainBoneIndex == INDEX_NONE)
		return false;
	FName MainBoneName = RefSkeleton.GetBoneName(MainBoneIndex);
	
	TArray<FTransform> OutMainBoneTransforms;
	DataModel->GetBoneTrackTransforms(MainBoneName, OutMainBoneTransforms);
	if (OutMainBoneTransforms.Num() == 0)
		return false;
	if (!bNewImported && GetDeltaLocationMetaData(AnimSequence, OutMainBoneTransforms[0], OutDeltaTranslation))
	{
		return true;
	}
	if (UsedNames.Num() > 0 && !ensure(UsedNames.Contains(MainBoneName)))
		return false;
	
	bUseSkeletalMeshBoneTransform = true;
	OutDeltaTranslation = CalcNewLocation(RefSkeleton, RootBoneIndex, GetWorldBoneLocation, MainBoneIndex);
	
	// Root骨骼在动的, 不适用这个Fix.
	FTransform RootTransform;
	TArray<FTransform> RootTransforms;
	DataModel->GetBoneTrackTransforms(RootBoneName, RootTransforms);
	if (RootTransforms.Num() > 0)
	{
		for (const FTransform& Key : RootTransforms)
		{
			if (!Key.Equals(RootTransforms[0]))
			{
				UE_LOG(LogTemp, Warning, TEXT("[FAnimSeqRootFixTool] Root bone has Animation! Skip this %s"), *AnimSequence->GetPathName());
				return false;
			}
		}
		RootTransform = RootTransforms[0];
	}
	else if (RefSkeleton.GetRefBonePose().IsValidIndex(RootBoneIndex))
	{
		RootTransform = RefSkeleton.GetRefBonePose()[RootBoneIndex];
	}
		
	UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Processing Anim... %s"), *AnimSequence->GetName());
	
	TScriptInterface<IAnimationDataController> Controller = DataModel->GetController();
	Controller->OpenBracket(FText::FromString(TEXT("Adjust Root Bone To Feet")));

	// root骨骼有位移的时候, 直接挪root点
	bool bResult = false;
	if (!RootTransform.GetLocation().IsNearlyZero(10))
	{
		OutDeltaTranslation = RootTransform.GetLocation();
		bResult = MoveBoneTransforms(OutDeltaTranslation, DataModel, RefSkeleton, Tolerance, MainBoneIndex, FTransform::Identity, Controller, RootBoneIndex);
	}
	else
	{
		TArray<int32> BoneIndicesQueue = {RootBoneIndex}; // 在原本位置的骨骼, 从Root开始.
		for (int j = 0; j < BoneIndicesQueue.Num(); j++)
		{
			int32 ParentBoneIndex = BoneIndicesQueue[j];

			// 要把所有的子骨骼从远处拉回来!
			TArray<int32> ChildBones;
			int32 ChildNum = RefSkeleton.GetDirectChildBones(ParentBoneIndex, ChildBones);
			int32 MainBoneArrayIndex = ChildBones.Find(MainBoneIndex);
			if (MainBoneArrayIndex != INDEX_NONE && MainBoneArrayIndex != 0)
			{
				ChildBones.Swap(0, MainBoneArrayIndex);
			}
			
			for (int i = 0; i < ChildNum; i++)
			{
				int ChildBoneIndex = ChildBones[i];
				FName BoneName = RefSkeleton.GetBoneName(ChildBoneIndex);
				if (!UsedNames.IsEmpty() && !UsedNames.Contains(BoneName))
					continue;
				
				// auto WorldDelta = RootTransform.Rotator().GetInverse().RotateVector(DeltaTranslation);
				bool bBoneResult  = MoveBoneTransforms(OutDeltaTranslation, DataModel, RefSkeleton, Tolerance, MainBoneIndex, RootTransform, Controller, ChildBoneIndex);
				if (MainBoneIndex == ChildBoneIndex)
				{
					bResult = bBoneResult;
				}
			}
		}

		// if (!bComponentSpaceTransformsValid)
		// {
		// 	FRotator Rotator = RootTransform.Rotator();
		// 	if (!Rotator.IsNearlyZero(0.1))
		// 	{
		// 		OutDeltaTranslation = Rotator.RotateVector(OutDeltaTranslation);
		// 	}	
		// }
	}
		
	Controller->CloseBracket();
	if (!bResult)
	{
		UE_LOG(LogTemp, Error, TEXT("[FAnimSeqRootFixTool] MoveBoneTransforms Fail! %s"), *AnimSequence->GetPathName());
		return false;
	}
	
	AnimSequence->Modify();

	OutMainBoneTransforms.Reset();
	DataModel->GetBoneTrackTransforms(MainBoneName, OutMainBoneTransforms);
	check(OutMainBoneTransforms.Num() > 0);
	SetDeltaLocationMetaData(AnimSequence, OutMainBoneTransforms[0], OutDeltaTranslation);

	UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Process Anim Done: %s, Vector: %s"), *AnimSequence->GetName(), *OutDeltaTranslation.ToString());
	return true;
}

void UAnimSeqRootFixTool::ProcessBindingActor(ULevelSequence* InSequence, const FGuid BindingID, const FString& Name, const AActor* ActorTemplate)
{
	if (!InSequence || !InSequence->MovieScene)
		return;

	UMovieScene* MovieScene = InSequence->MovieScene;
	
	if (!ActorTemplate) return;
	
	if (!ActorTemplate->GetComponentByClass<USkeletalMeshComponent>())
	{
		return;
	}

	const bool bIsBLevel = ActorTemplate->GetClass()->GetName().Contains("BLevel");
	if (!bProcessBLevel && bIsBLevel)
	{
		UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Skipping Spawnable %s (BLevel)"), *Name);
		return;
	}

	// 2.
	UMovieScene3DTransformTrack* TransformTrack = MovieScene->FindTrack<UMovieScene3DTransformTrack>(BindingID);
	UMovieScene3DTransformSection* AnimRootSection = nullptr;
	FRotator ActorRotator;	

	if (TransformTrack)
	{
		bool bHasTransform = false;
		bool bHasRotation = false;
		bool bHasMultiRotation = false;
		bool bHasScale = false;
		for (UMovieSceneSection* const& Section : TransformTrack->GetAllSections())
		{
			if (Section->GetName() == TEXT("AnimRoot_Additive"))
				continue;
				// return; // 通刷的时候, 不考虑已经刷过的, 因为可能已经被美术瞎鸡儿改过.
			
			UMovieScene3DTransformSection* TransformSection = Cast<UMovieScene3DTransformSection>(Section);
			if (!TransformSection)
				continue;
			
			// 可以有旋转, 但是只能有一帧.
			FMovieSceneChannelProxy& ChannelProxy = TransformSection->GetChannelProxy();
			TArray<double> RotationData;
			for (int i = 3; i < 6; i++)
			{
				if (FMovieSceneDoubleChannel* MovieSceneDoubleChannel = ChannelProxy.GetChannel<FMovieSceneDoubleChannel>(i))
				{
					if (MovieSceneDoubleChannel->GetNumKeys() > 1)
					{
						bHasMultiRotation = true;
					}
					else if (MovieSceneDoubleChannel->GetValues().Num() > 0)
					{
						RotationData.Add(MovieSceneDoubleChannel->GetValues()[0].Value);
					}
					else
					{
						RotationData.Add(MovieSceneDoubleChannel->GetDefault().GetValue());
					}
				}
			}
			
			if (RotationData.Num() == 3)
			{
				ActorRotator = FRotator(RotationData[1], RotationData[2], RotationData[0]);
				if (!ActorRotator.IsNearlyZero(0.1))
					bHasRotation = true;
			}
			
			TArray<double> TransformData;
			for (int i = 0; i < 3; i++)
			{
				if (FMovieSceneDoubleChannel* MovieSceneDoubleChannel = ChannelProxy.GetChannel<FMovieSceneDoubleChannel>(i))
				{
					if (MovieSceneDoubleChannel->GetNumKeys() > 1)
					{
						bHasTransform = true;
					}
					else if (MovieSceneDoubleChannel->GetValues().Num() > 0)
					{
						TransformData.Add(MovieSceneDoubleChannel->GetValues()[0].Value);
					}
					else
					{
						TransformData.Add(MovieSceneDoubleChannel->GetDefault().GetValue());
					}
				}
			}
			
			if (TransformData.Num() == 3)
			{
				auto ActorTransform = FVector(TransformData[1], TransformData[2], TransformData[0]);
				if (!ActorTransform.IsNearlyZero(1))
					bHasTransform = true;
			}

			// 不能有缩放
			for (int i = 6; i < 9; i++)
			{
				if (FMovieSceneDoubleChannel* MovieSceneDoubleChannel = ChannelProxy.GetChannel<FMovieSceneDoubleChannel>(i))
				{
					if (MovieSceneDoubleChannel->HasAnyData() &&
						!FMath::IsNearlyEqual(1, MovieSceneDoubleChannel->GetDefault().GetValue()))
					{
						bHasScale = true;
					}

					if (MovieSceneDoubleChannel->GetNumKeys() > 1)
					{
						bHasScale = true;
					}
				}
			}

			if (bHasScale || bHasMultiRotation)
			{
				UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Skipping Spawnable %s (has rotation or scale)"), *Name);
				return;	
			}

			if (bHasRotation && bHasTransform)
			{
				UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Skipping Spawnable %s (both has transform and rotation)"), *Name);
				return;
			}
		}
	}
		
	// 3. 查找所有 Animation 轨道
	TArray<UMovieSceneTrack*> AnimationTracks = MovieScene->FindTracks(UMovieSceneSkeletalAnimationTrack::StaticClass(), BindingID);
	for (UMovieSceneTrack* Track : AnimationTracks)
	{
		if (Track->IsEvalDisabled())
			continue;
		
		UMovieSceneSkeletalAnimationTrack* AnimationTrack = Cast<UMovieSceneSkeletalAnimationTrack>(Track);
		check(AnimationTrack);

		AActor* ThisActor = GetActorFromAnimationTrack(InSequence, AnimationTrack);
		USkeletalMesh* SkeletalMesh = nullptr;
		if (ThisActor)
		{
			USkeletalMeshComponent* MeshComponent = ThisActor->FindComponentByClass<USkeletalMeshComponent>();
			if (MeshComponent && MeshComponent->GetSkeletalMeshAsset())
				SkeletalMesh = MeshComponent->GetSkeletalMeshAsset();
		}
		
		for (UMovieSceneSection* Section : AnimationTrack->GetAllSections())
		{
			UMovieSceneSkeletalAnimationSection* AnimSection = Cast<UMovieSceneSkeletalAnimationSection>(Section);
			if (!AnimSection)
				continue;

			if (AnimSection->Params.SlotName != "DefaultSlot")
				continue;

			UAnimSequence* AnimSequence = Cast<UAnimSequence>(AnimSection->Params.Animation);
			if (!AnimSequence)
				continue;

			FString PathName = AnimSequence->GetPathName();
			if (!PathName.StartsWith(TEXT("/Game/Arts/Cinematics/")))
				continue;
			
			FVector OutDeltaTranslation;
			
			if (AdjustAnimationRootToFeet(AnimSequence, SkeletalMesh, OutDeltaTranslation, false))
			{
				if (bIsBLevel)
				{
					const double Temp = OutDeltaTranslation.X;
					OutDeltaTranslation.X = OutDeltaTranslation.Y;
					OutDeltaTranslation.Y = -Temp;
				}
				
				if (!TransformTrack)
				{
					TransformTrack = MovieScene->AddTrack<UMovieScene3DTransformTrack>(BindingID);
				}

				bool bIsEvalDisabled = TransformTrack->IsEvalDisabled();

				if (!AnimRootSection)
				{
					// 查找所有Transform轨道，检查是否有名为"AnimRoot_Additive"的轨道
					TArray<UMovieSceneSection*> TransformSections = TransformTrack->GetAllSections();
					for (UMovieSceneSection* SubSection : TransformSections)
					{
						if (SubSection->GetName() == TEXT("AnimRoot_Additive"))
						{
							AnimRootSection = Cast<UMovieScene3DTransformSection>(SubSection);
							FMovieSceneChannelProxy& ChannelProxy = AnimRootSection->GetChannelProxy();
							for (int32 i = 0; i < 3; i++)
							{
								if (FMovieSceneDoubleChannel* Channel = ChannelProxy.GetChannel<FMovieSceneDoubleChannel>(i))
								{
									Channel->Reset();
								}
							}
							break;
						}
					}
						
					if (!AnimRootSection)
					{
						const int32 TrackRowIndex = TransformTrack->GetAllSections().Num();
						AnimRootSection = NewObject<UMovieScene3DTransformSection>(TransformTrack, TEXT("AnimRoot_Additive"), RF_Transactional);
						AnimRootSection->SetBlendType(EMovieSceneBlendType::Additive);
						AnimRootSection->SetRange(TRange<FFrameNumber>::All());
						AnimRootSection->SetRowIndex(TrackRowIndex);
						TransformTrack->AddSection(*AnimRootSection);
						TransformTrack->SetTrackRowDisplayName(FText::FromString(TEXT("AnimRoot_Additive")), TrackRowIndex);
						TransformTrack->SetRowEvalDisabled(false, TrackRowIndex);
					}
				}
				
				FMovieSceneChannelProxy& ChannelProxy = AnimRootSection->GetChannelProxy();
						
				// 设置位置通道
				auto FinalTranslation = MakeAdditiveTransform(ActorRotator, OutDeltaTranslation).GetLocation();
				const FFrameNumber StartFrame = AnimSection->GetInclusiveStartFrame();
				for (int32 i = 0; i < 3; i++)
				{
					if (FMovieSceneDoubleChannel* Channel = ChannelProxy.GetChannel<FMovieSceneDoubleChannel>(i))
					{
						Channel->AddConstantKey(StartFrame, FinalTranslation[i]);
					}
				}

				TransformTrack->SetEvalDisabled(bIsEvalDisabled);
				MovieScene->Modify();
				UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Added AnimRoot Transform Track: %s (%s)"), *Name, *FinalTranslation.ToString());
			}
		}
	}
}

bool UAnimSeqRootFixTool::AdjustSequenceRootToFeet(ULevelSequence* LevelSequence)
{
	if (!LevelSequence)
		return false;

	UMovieScene* MovieScene = LevelSequence->MovieScene;
	if (!MovieScene) return false;

	// 0. 处理当前 MovieScene 的所有 SubSequence
	TArray<UMovieSceneTrack*> MovieSceneTracks = MovieScene->GetTracks();
	for (UMovieSceneTrack* MovieSceneTrack : MovieSceneTracks)
	{
		if (!MovieSceneTrack->IsA<UMovieSceneSubTrack>())
			continue;

		UMovieSceneSubTrack* SubTrack = Cast<UMovieSceneSubTrack>(MovieSceneTrack);
		for (UMovieSceneSection* Section : SubTrack->GetAllSections())
		{
			if (!Section->IsA<UMovieSceneSubSection>())
				continue;

			UMovieSceneSubSection* MovieSceneSubSection = Cast<UMovieSceneSubSection>(Section);
			if (!MovieSceneSubSection->GetSequence())
				continue;

			AdjustSequenceRootToFeet(Cast<ULevelSequence>(MovieSceneSubSection->GetSequence()));
		}
	}
	
	UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Processing... %s"), *LevelSequence->GetName());
	
	// 1. 处理当前 MovieScene 的所有 Spawnable

	const FMovieSceneBindingReferences* BindingReferences = LevelSequence->GetBindingReferences();
	if (!BindingReferences)
	{
		UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] No BindingReferences found in LevelSequence %s"), *LevelSequence->GetName());
		return false;
	}
	
	TArrayView<const FMovieSceneBindingReference> AllReferences = BindingReferences->GetAllReferences();
	for (const FMovieSceneBindingReference& Reference : AllReferences)
	{
		if (UMovieSceneSpawnableActorBinding* ActorBinding = Cast<UMovieSceneSpawnableActorBinding>(Reference.CustomBinding))
		{
			FGuid BindingID = Reference.ID;
			FMovieSceneBinding* MovieSceneBinding = MovieScene->FindBinding(BindingID);
			FString Name = MovieSceneBinding ? MovieSceneBinding->GetName() : TEXT("Unknown");
			AActor* ActorTemplate = Cast<AActor>(ActorBinding->GetObjectTemplate());
			ProcessBindingActor(LevelSequence, BindingID, Name, ActorTemplate);
		}
	}
	
	const int32 SpawnableCount = MovieScene->GetSpawnableCount();
	for (int32 SpawnableIndex = 0; SpawnableIndex < SpawnableCount; ++SpawnableIndex)
	{
		FMovieSceneSpawnable& Spawnable = MovieScene->GetSpawnable(SpawnableIndex);
		FGuid BindingID = Spawnable.GetGuid();
		FString Name = Spawnable.GetName();
		const AActor* ActorTemplate = Cast<AActor>(Spawnable.GetObjectTemplate());
		ProcessBindingActor(LevelSequence, BindingID, Name, ActorTemplate);
	}

	UE_LOG(LogTemp, Log, TEXT("[FAnimSeqRootFixTool] Processing Done %s"), *LevelSequence->GetName());
	
	return true;
}

FTransform UAnimSeqRootFixTool::MakeAdditiveTransform(const FRotator& ActorRot, const FVector& DeltaTranslation)
{
	FTransform AdditiveTransform;
	AdditiveTransform.SetTranslation(ActorRot.RotateVector(DeltaTranslation));
	AdditiveTransform.SetRotation(FQuat::Identity);
	AdditiveTransform.SetScale3D(FVector(1.f, 1.f, 1.f));

	return AdditiveTransform;
}

void UAnimSeqRootFixTool::SetDeltaLocationMetaData(const UObject* AnimSequence, FTransform MainBoneTransform, const FVector& DeltaLocation, const FString& KeyPostFix)
{
	if (!AnimSequence) return;

	// 获取MetaData对象
	UMetaData* MetaData = AnimSequence->GetOutermost()->GetMetaData();
	if (!MetaData) return;

	// 转换 FVector -> FString
	const FString ValueString = FString::Printf(TEXT("%f,%f,%f"), DeltaLocation.X, DeltaLocation.Y, DeltaLocation.Z);
	const FString CurrentHash = FString::Printf(TEXT("%u"), GetTypeHash(MainBoneTransform));

	// 设置Key/Value
	MetaData->SetValue(AnimSequence, *(TEXT("DeltaLocation") + KeyPostFix), *ValueString);
	MetaData->SetValue(AnimSequence, *(TEXT("MainBoneTransformHash") + KeyPostFix), *CurrentHash);

	// 标记资产已修改
	AnimSequence->MarkPackageDirty();
}

bool UAnimSeqRootFixTool::GetDeltaLocationMetaData(const UObject* AnimSequence, FTransform MainBoneTransform, FVector& OutDeltaLocation, const FString& KeyPostFix)
{
	if (!AnimSequence) return false;

	UMetaData* MetaData = AnimSequence->GetOutermost()->GetMetaData();
	if (!MetaData) return false;

	FString ValueString = MetaData->GetValue(AnimSequence, *(TEXT("DeltaLocation") + KeyPostFix));
	if (ValueString.IsEmpty()) return false;

	const FString HashString = MetaData->GetValue(AnimSequence, *(TEXT("MainBoneTransformHash") + KeyPostFix));
	const FString CurrentHash = FString::Printf(TEXT("%u"), GetTypeHash(MainBoneTransform));
	if (!HashString.IsEmpty() && HashString != CurrentHash)
		return false;
	
	FVector& Result = OutDeltaLocation;
	TArray<FString> Parts;
	ValueString.ParseIntoArray(Parts, TEXT(","), true);

	if (Parts.Num() == 3)
	{
		Result.X = FCString::Atof(*Parts[0]);
		Result.Y = FCString::Atof(*Parts[1]);
		Result.Z = FCString::Atof(*Parts[2]);
	}

	return true;
}

void UAnimSeqRootFixTool::MergeTaggedBindingsToMainSequence(ULevelSequence* Sequence)
{
    if (!Sequence) return;

	const FMovieSceneCompiledDataID DataID = UMovieSceneCompiledDataManager::GetPrecompiledData()->Compile(Sequence);
	const FMovieSceneSequenceHierarchy* Hierarchy = UMovieSceneCompiledDataManager::GetPrecompiledData()->FindHierarchy(DataID);
	if (!Hierarchy)
		return;
	
    TMap<FName, FMovieSceneObjectBindingIDs> Collected;
    CollectTaggedBindingsRecursive(Sequence, Hierarchy, MovieSceneSequenceID::Root, Collected);
	
    if (UMovieScene* MovieScene = Sequence->GetMovieScene())
    {
        for (const TPair<FName, FMovieSceneObjectBindingIDs>& Pair : Collected)
        {
            const FName& Tag = Pair.Key;
            const FMovieSceneObjectBindingIDs& BindingIDs = Pair.Value;

            for (const FMovieSceneObjectBindingID& BindingID : BindingIDs.IDs)
            {
            	UE::MovieScene::FFixedObjectBindingID NewBindingID(BindingID.GetGuid(), BindingID.GetRelativeSequenceID());
            	MovieScene->TagBinding(Tag, NewBindingID);   
            }
        }

    	MovieScene->Modify();
    }
}

void UAnimSeqRootFixTool::CollectTaggedBindingsRecursive(ULevelSequence* Sequence, const FMovieSceneSequenceHierarchy* Hierarchy, FMovieSceneSequenceID SequenceID, TMap<FName, FMovieSceneObjectBindingIDs>& OutMap)
{
	if (!Sequence) return;
	
	if (const UMovieScene* MovieScene = Sequence->GetMovieScene())
	{		
		// 收集当前 Sequence 的所有 Tagged Bindings
		for (const TPair<FName, FMovieSceneObjectBindingIDs>& Pair : MovieScene->AllTaggedBindings())
		{
			const FName& Tag = Pair.Key;
			const FMovieSceneObjectBindingIDs& BindingIDs = Pair.Value;

			if (!OutMap.Contains(Tag))
				OutMap.Add(Tag, {});

			TArray<FMovieSceneObjectBindingID>& ExistingIDs = OutMap[Tag].IDs;

			for (FMovieSceneObjectBindingID BindingID : BindingIDs.IDs)
			{
				if (BindingID.GetRelativeSequenceID() == MovieSceneSequenceID::Root)
				{
					ExistingIDs.Add(UE::MovieScene::FRelativeObjectBindingID(BindingID.GetGuid(), SequenceID));	
				}
			}
		}

		const TMap<FMovieSceneSequenceID, FMovieSceneSubSequenceData>& OutSubSequenceData = Hierarchy->AllSubSequenceData();

		// 遍历子序列
		for (UMovieSceneTrack* Track : MovieScene->GetTracks())
		{
			if (const UMovieSceneSubTrack* SubTrack = Cast<UMovieSceneSubTrack>(Track))
			{
				for (UMovieSceneSection* Section : SubTrack->GetAllSections())
				{
					if (const UMovieSceneSubSection* SubSection = Cast<UMovieSceneSubSection>(Section))
					{
						if (ULevelSequence* SubSequence = Cast<ULevelSequence>(SubSection->GetSequence()))
						{
							for (const auto& Pair : OutSubSequenceData)
							{
								if (Pair.Value.GetSequence() == SubSequence)
								{
									CollectTaggedBindingsRecursive(SubSequence, Hierarchy, Pair.Key, OutMap);
									break;
								}
							}
						}
					}
				}
			}
		}
	}
}

void UAnimSeqRootFixTool::DuplicateAssetsAndFixReferences(const TArray<FString>& SourcePaths, const FString& TargetFolder)
{
    if (SourcePaths.Num() == 0)
    {
        UE_LOG(LogTemp, Warning, TEXT("No source paths provided"));
        return;
    }

    FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
    IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

    // 1. 收集所有源资产路径
    TMap<FString, FString> SourceToTargetMap;
    TArray<FAssetData> AllAssetsToCopy;

    for (FString Path : SourcePaths)
    {
    	// 判断是否是文件夹
    	TArray<FAssetData> AssetsInPath;
        Path.RemoveFromStart(TEXT("/All"));
    	AssetRegistry.GetAssetsByPath(FName(Path), AssetsInPath, /*bRecursive=*/true);

    	if (AssetsInPath.Num() > 0) // 说明是个文件夹
    	{
        	
            FString LastFolderName;
            Path.Split(TEXT("/"), nullptr, &LastFolderName, ESearchCase::IgnoreCase, ESearchDir::FromEnd);

            for (const FAssetData& AssetData : AssetsInPath)
            {
                FString AssetPath = AssetData.GetObjectPathString();

                // 构建相对路径：去掉SourcePath前缀
                FString RelativePath = AssetPath;
                RelativePath.RemoveFromStart(Path);

                FString TargetPath = TargetFolder / LastFolderName + RelativePath;
                SourceToTargetMap.Add(AssetPath, TargetPath);
                AllAssetsToCopy.Add(AssetData);
            }
        }
        else // 单个资产
        {
            FAssetData AssetData = AssetRegistry.GetAssetByObjectPath(FSoftObjectPath(Path));
            if (AssetData.IsValid())
            {
                FString AssetName = AssetData.AssetName.ToString();
                FString TargetPath = TargetFolder / AssetName + "." + AssetName;
                SourceToTargetMap.Add(Path, TargetPath);
                AllAssetsToCopy.Add(AssetData);
            }
            else
            {
                UE_LOG(LogTemp, Warning, TEXT("Invalid asset path: %s"), *Path);
            }
        }
    }

    if (AllAssetsToCopy.Num() == 0)
    {
        UE_LOG(LogTemp, Warning, TEXT("No assets found to copy"));
        return;
    }

    // 2. 批量复制
    TArray<UObject*> NewAssets;
    {
        FAssetToolsModule& AssetToolsModule = FAssetToolsModule::GetModule();
    	IAssetTools& AssetTools = AssetToolsModule.Get();

    	FScopedSlowTask SlowTask(AllAssetsToCopy.Num(), FText::FromString(TEXT("Duplicate Assets...")));
    	SlowTask.MakeDialog();
    	
        for (const FAssetData& AssetData : AllAssetsToCopy)
        {
        	SlowTask.EnterProgressFrame();
            FString SourceAssetPath = AssetData.GetObjectPathString();
            FString TargetFullPath = SourceToTargetMap[SourceAssetPath];
            FString TargetPackagePath, TargetAssetName;
            TargetFullPath.Split(TEXT("."), &TargetPackagePath, &TargetAssetName);
        	TargetPackagePath = FPaths::GetPath(TargetPackagePath);
        	
            if (UObject* DuplicatedAsset = AssetTools.DuplicateAsset(TargetAssetName, TargetPackagePath, AssetData.GetAsset()))
        	{
        		NewAssets.Add(DuplicatedAsset);
        	}
        	else
        	{
        		UE_LOG(LogTemp, Warning, TEXT("Failed to duplicate asset: %s"), *SourceAssetPath);
        	}
        }
    }

	// 3. 替换引用
	FScopedSlowTask SlowTask(AllAssetsToCopy.Num(), FText::FromString(TEXT("Duplicate Assets...")));
	SlowTask.MakeDialog();

    for (UObject* NewAsset : NewAssets)
    {
        SlowTask.EnterProgressFrame();
        if (!NewAsset) continue;

        TMap<UObject*, UObject*> ReplacementMap;
        for (const TPair<FString, FString>& Pair : SourceToTargetMap)
        {
            UObject* OldObject = LoadObject<UObject>(nullptr, *Pair.Key);
            UObject* NewObject = LoadObject<UObject>(nullptr, *Pair.Value);
            if (OldObject && NewObject)
            {
                ReplacementMap.Add(OldObject, NewObject);
            }
        }
    	
    	constexpr EArchiveReplaceObjectFlags ReplaceFlags = EArchiveReplaceObjectFlags::IgnoreOuterRef | EArchiveReplaceObjectFlags::IgnoreArchetypeRef;
        FArchiveReplaceObjectRef<UObject> ReplaceAr(NewAsset, ReplacementMap, ReplaceFlags);
    }

    // 4. 保存
    TArray<UPackage*> PackagesToSave;
    for (UObject* NewAsset : NewAssets)
    {
        if (NewAsset)
        {
            PackagesToSave.Add(NewAsset->GetPackage());
        }
    }
    FEditorFileUtils::PromptForCheckoutAndSave(PackagesToSave, false, false);
}

void UAnimSeqRootFixTool::ForEachLevelSequenceRecursive(ULevelSequence* LevelSequence, const int32 ParentIndex, const TFunctionRef<void(ULevelSequence*, int32)>& Func)
{
	if (!LevelSequence) return;

	Func(LevelSequence, ParentIndex);

	const UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (!MovieScene) return;

	for (UMovieSceneTrack* Track : MovieScene->GetTracks())
	{
		if (const UMovieSceneSubTrack* SubTrack = Cast<UMovieSceneSubTrack>(Track))
		{
			for (UMovieSceneSection* Section : SubTrack->GetAllSections())
			{
				if (const UMovieSceneSubSection* SubSection = Cast<UMovieSceneSubSection>(Section))
				{
					if (ULevelSequence* SubLevelSequence = Cast<ULevelSequence>(SubSection->GetSequence()))
					{
						ForEachLevelSequenceRecursive(SubLevelSequence, ParentIndex + 1, Func);
					}
				}
			}
		}
	}
}

void UAnimSeqRootFixTool::ForeachSpawnableActorGuid(const ULevelSequence* LevelSequence, const TFunctionRef<void(UMovieScene*, FGuid, FString, AActor*)>& Func)
{
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	const FMovieSceneBindingReferences* BindingReferences = LevelSequence->GetBindingReferences();
	if (!BindingReferences || !MovieScene)
	{
		return;
	}
	
	TArrayView<const FMovieSceneBindingReference> AllReferences = BindingReferences->GetAllReferences();
	for (const FMovieSceneBindingReference& Reference : AllReferences)
	{
		if (UMovieSceneSpawnableActorBinding* ActorBinding = Cast<UMovieSceneSpawnableActorBinding>(Reference.CustomBinding))
		{
			FGuid BindingID = Reference.ID;
			const FMovieSceneBinding* MovieSceneBinding = MovieScene->FindBinding(BindingID);
			const FString Name = MovieSceneBinding ? MovieSceneBinding->GetName() : TEXT("Unknown");
			AActor* ActorTemplate = Cast<AActor>(ActorBinding->GetObjectTemplate());
			Func(MovieScene, BindingID, Name, ActorTemplate);
		}
	}
	
	const int32 SpawnableCount = MovieScene->GetSpawnableCount();
	for (int32 SpawnableIndex = 0; SpawnableIndex < SpawnableCount; ++SpawnableIndex)
	{
		FMovieSceneSpawnable& Spawnable = MovieScene->GetSpawnable(SpawnableIndex);
		const FGuid BindingID = Spawnable.GetGuid();
		const FString Name = Spawnable.GetName();
		AActor* ActorTemplate = Cast<AActor>(Spawnable.GetObjectTemplate());
		Func(MovieScene, BindingID, Name, ActorTemplate);
	}
}

void UAnimSeqRootFixTool::AttachActorsToRoot(ULevelSequence* LevelSequence)
{
	if (!LevelSequence) return;

	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (!MovieScene) return;

	// 1. 创建一个新的空Actor作为Root Spawnable
	const FName RootName = TEXT("RootActor");

	FGuid RootGuid;
	const FMovieSceneSpawnable* RootSpawnable = MovieScene->FindSpawnable([RootName](const FMovieSceneSpawnable& Spawnable)
	{
		return Spawnable.GetName() == RootName;
	});
	
	if (RootSpawnable)
	{
		RootGuid = RootSpawnable->GetGuid();
	}

	if (!RootGuid.IsValid())
	{
		RootGuid = MovieSceneAddSpawnable(MovieScene,RootName, AActor::StaticClass());
		// RootGuid = MovieScene->AddSpawnable(RootName.ToString(), *AActor::StaticClass());	

		if (RootGuid.IsValid())
		{
			UMovieScene3DTransformTrack* TransformTrack = MovieScene->AddTrack<UMovieScene3DTransformTrack>(RootGuid);
			if (TransformTrack && TransformTrack->GetAllSections().Num() == 0)
			{
				UMovieScene3DTransformSection* TransformSection = NewObject<UMovieScene3DTransformSection>(TransformTrack, TEXT("RootTransform"), RF_Transactional);
				TransformSection->SetBlendType(EMovieSceneBlendType::Additive);
				TransformSection->SetRange(TRange<FFrameNumber>::All());
				TransformSection->SetRowIndex(0);
				TransformTrack->AddSection(*TransformSection);
				TransformTrack->SetTrackRowDisplayName(FText::FromString(TEXT("RootTransform")), 0);
			}
		}
	}

	ForEachLevelSequenceRecursive(LevelSequence, 0, [&](ULevelSequence* SubLevelSequence, int32 SubSequenceParentIndex)
	{
		ForeachSpawnableActorGuid(SubLevelSequence, [&](UMovieScene* SubMovieScene, FGuid Guid, FString, AActor*)
		{
			if (!SubMovieScene) return;
			if (Guid == RootGuid) return;

			UMovieScene3DAttachTrack* AttachTrack = SubMovieScene->FindTrack<UMovieScene3DAttachTrack>(Guid);
			if (AttachTrack)
				return;

			// 3. 添加 Attach Track，让它附加到 RootActor
			AttachTrack = SubMovieScene->AddTrack<UMovieScene3DAttachTrack>(Guid);
			if (AttachTrack)
			{
				const FFrameNumber AttachEndTime = SubMovieScene->GetPlaybackRange().GetUpperBoundValue();
				constexpr FFrameNumber KeyTime(0);
				const int32 Duration = FMath::Max(0, (AttachEndTime - KeyTime).Value);
				UE::MovieScene::FRelativeObjectBindingID ID(RootGuid, MovieSceneSequenceID::Root, SubSequenceParentIndex);
				AttachTrack->AddConstraint(KeyTime, Duration, NAME_None, NAME_None, ID);
			}
		});
	});
}

FGuid UAnimSeqRootFixTool::MovieSceneAddSpawnable(UMovieScene* MovieScene, const FName& Name, const TSubclassOf<AActor>& ActorClass)
{
	if (!MovieScene) return {};
	
	TArray<TSharedRef<IMovieSceneObjectSpawner>> ObjectSpawners;
	ILevelSequenceModule& LevelSequenceModule = FModuleManager::LoadModuleChecked<ILevelSequenceModule>("LevelSequence");
	LevelSequenceModule.GenerateObjectSpawners(ObjectSpawners);
	
	TValueOrError<FNewSpawnable, FText> Result = MakeError(LOCTEXT("NoSpawnerFound", "No spawner found to create new spawnable type"));
	
	UActorFactory* ActorFactory = GEditor->FindActorFactoryForActorClass(ActorClass);
	for (TSharedRef<IMovieSceneObjectSpawner> Spawner : ObjectSpawners)
	{
		TValueOrError<FNewSpawnable, FText> CurResult = Spawner->CreateNewSpawnableType(*ActorClass.Get(), *MovieScene, ActorFactory);
		if (CurResult.IsValid())
		{
			Result = CurResult;
			break;
		}
	}
	
	if (!Result.IsValid())
	{
		FNotificationInfo Info(Result.GetError());
		Info.ExpireDuration = 3.0f;
		FSlateNotificationManager::Get().AddNotification(Info);
		return {};
	}

	FNewSpawnable& NewSpawnable = Result.GetValue();
	NewSpawnable.Name = MovieSceneHelpers::MakeUniqueSpawnableName(MovieScene, Name.ToString());			
	const FGuid NewGuid = MovieScene->AddSpawnable(NewSpawnable.Name, *NewSpawnable.ObjectTemplate);
	
	// Create a new spawn section.
	if (ensure(NewGuid.IsValid()))
	{
		UMovieSceneSpawnTrack* NewSpawnTrack = Cast<UMovieSceneSpawnTrack>(MovieScene->AddTrack(UMovieSceneSpawnTrack::StaticClass(), NewGuid));
		UMovieSceneBoolSection* NewSpawnSection = Cast<UMovieSceneBoolSection>(NewSpawnTrack->CreateNewSection());
		NewSpawnSection->GetChannel().SetDefault(true);
		NewSpawnSection->SetRange(TRange<FFrameNumber>::All());
		NewSpawnTrack->AddSection(*NewSpawnSection);
		NewSpawnTrack->SetObjectId(NewGuid);
	}

	return NewGuid;
}

AActor* UAnimSeqRootFixTool::GetActorFromAnimationTrack(const ULevelSequence* Sequence, const UMovieSceneSkeletalAnimationTrack* AnimationTrack)
{
	if (!Sequence) return nullptr;
	const TObjectPtr<UMovieScene> MovieScene = Sequence->MovieScene;
	if (!MovieScene || !AnimationTrack) return nullptr;
	
	for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
	{
		for (UMovieSceneTrack* Track : Binding.GetTracks())
		{
			if (Track == AnimationTrack)
			{
				FGuid ObjectGuid = Binding.GetObjectGuid();
				if (const FMovieSceneBindingReferences* References = Sequence->GetBindingReferences())
					if (const FMovieSceneBindingReference* Reference = References->GetReference(ObjectGuid, 0))
						if (Reference->CustomBinding->IsA<UMovieSceneSpawnableActorBinding>())
							return Cast<AActor>(Cast<UMovieSceneSpawnableActorBinding>(Reference->CustomBinding)->GetObjectTemplate());
			}
		}
	}

	return nullptr;
}

TArray<FName> UAnimSeqRootFixTool::GetUsedBonesInMesh(USkeletalMesh* SkeletalMesh)
{
	TArray<FName> Result;
	if (!SkeletalMesh)
		return Result;

	FSkeletalMeshRenderData* RenderData = SkeletalMesh->GetResourceForRendering();
	if (!RenderData || RenderData->LODRenderData.Num() == 0)
	{
		return Result;
	}

	const FSkeletalMeshLODRenderData& LODData = RenderData->LODRenderData[0];
	TSet<int32> UsedBoneIndices;
	
	const FReferenceSkeleton& RefSkeleton = SkeletalMesh->GetRefSkeleton();
	for (const auto& RefBoneInfo : RefSkeleton.GetRefBoneInfo())
	{
		int32 BoneIndex = RefSkeleton.FindBoneIndex(RefBoneInfo.Name);
		if (BoneIndex == INDEX_NONE)
			continue;
		
		int32 Index = LODData.ActiveBoneIndices.Find(IntCastChecked<FBoneIndexType>(BoneIndex));
		if (Index != INDEX_NONE)
		{
			UsedBoneIndices.Add(BoneIndex);
		}
	}

	for (int32 BoneIndex : UsedBoneIndices)
	{
		FName BoneName = RefSkeleton.GetBoneName(BoneIndex);
		Result.AddUnique(BoneName);
	}

	return Result;
}

#undef LOCTEXT_NAMESPACE