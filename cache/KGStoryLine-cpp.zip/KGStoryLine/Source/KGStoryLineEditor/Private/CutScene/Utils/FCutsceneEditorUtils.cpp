#include "CutScene/Utils/FCutsceneEditorUtils.h"

#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"

void FCutsceneEditorUtils::CreateNotification(const FText& Message, bool bSuccess, float FadeOutDuration, float ExpireDuration, bool bWarning)
{
	FNotificationInfo Info(Message);
	Info.bFireAndForget = true;
	Info.FadeOutDuration = FadeOutDuration;
	Info.ExpireDuration = ExpireDuration;
	Info.bUseSuccessFailIcons = true;
	if (bWarning)
	{
		Info.Image = FAppStyle::GetBrush("MessageLog.Warning"); 
	}

	const TSharedPtr<SNotificationItem> Notification = FSlateNotificationManager::Get().AddNotification(Info);
	if (Notification.IsValid())
	{
		if (bSuccess)
		{
			Notification->SetCompletionState(SNotificationItem::ECompletionState::CS_Success);
		}
		else
		{
			Notification->SetCompletionState(SNotificationItem::ECompletionState::CS_Fail);
		}
	}
}
