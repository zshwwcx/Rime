// Fill out your copyright notice in the Description page of Project Settings.


#include "CutScene/Utils/CutSceneEditorFunctionLibrary.h"

#include "AssetImportTask.h"
#include "Editor.h"
#include "ILevelSequenceEditorToolkit.h"
#include "ISequencerModule.h"
#include "LevelSequence.h"
#include "MovieScene.h"
#include "MovieSceneSection.h"
#include "Engine/LevelStreaming.h"
#include "Modules/ModuleManager.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "3C/Util/KGUtils.h"
#include "Animation/AnimSequence.h"
#include "Engine/SkeletalMesh.h"
#include "Animation/Skeleton.h"
#include "AssetToolsModule.h"
#include "CutScene/CutSceneEditorSettings.h"
#include "ILiveLinkClient.h"
#include "ISettingsCategory.h"
#include "ISettingsContainer.h"
#include "ISettingsModule.h"
#include "ISettingsSection.h"
#include "LiveLinkSourceFactory.h"
#include "MayaLiveLinkMessageBusSource.h"
#include "MayaLiveLinkSourceFactory.h"
#include "ObjectTools.h"
#include "Animation/AnimBlueprint.h"
#include "Animation/AnimInstance.h"
#include "Components/SkeletalMeshComponent.h"
#include "Factories/FbxAnimSequenceImportData.h"
#include "Factories/FbxFactory.h"
#include "Factories/FbxImportUI.h"
#include "Features/IModularFeatures.h"
#include "Framework/Application/SlateApplication.h"
#include "GameFramework/Character.h"
#include "UObject/Class.h"
#include "UObject/UnrealType.h"

#define VoidReturn
#define GetObjectByIDCast(OutName, OutType, InID, DefaultRet) \
	OutType* OutName = Cast<OutType>(KGUtils::GetObjectByID(InID)); \
	if (!OutName->IsValidLowLevel()) \
	{ \
		UE_LOG(LogTemp, Error, TEXT("UCutSceneEditorFunctionLibrary: Object with ID %d not found"), InID); \
		return DefaultRet; \
	}

class ISettingsModule;

void UCutSceneEditorFunctionLibrary::SetDisplayRate(const int64 SectionID, const int32 Fps)
{
	GetObjectByIDCast(OutSection, UMovieSceneSection, SectionID, VoidReturn);
	if (UMovieScene* MovieScene = OutSection->GetTypedOuter<UMovieScene>())
	{
		MovieScene->SetDisplayRate(FFrameRate(Fps, 1));
	}
}

int32 UCutSceneEditorFunctionLibrary::GetDisplayRate(const int64 SectionID)
{
	GetObjectByIDCast(OutSection, UMovieSceneSection, SectionID, -1);
	if (const UMovieScene* MovieScene = OutSection->GetTypedOuter<UMovieScene>())
	{
		return MovieScene->GetDisplayRate().Numerator;
	}
	return -1;
}

void UCutSceneEditorFunctionLibrary::SetLockToFrame(const int64 SectionID, const bool bLockToFrame)
{
	GetObjectByIDCast(OutSection, UMovieSceneSection, SectionID, VoidReturn);
	if (UMovieScene* MovieScene = OutSection->GetTypedOuter<UMovieScene>())
	{
		MovieScene->SetEvaluationType(bLockToFrame ? EMovieSceneEvaluationType::FrameLocked : EMovieSceneEvaluationType::WithSubFrames);
	}
}

bool UCutSceneEditorFunctionLibrary::GetLockToFrame(const int64 SectionID)
{
	GetObjectByIDCast(OutSection, UMovieSceneSection, SectionID, false);
	if (const UMovieScene* MovieScene = OutSection->GetTypedOuter<UMovieScene>())
	{
		return MovieScene->GetEvaluationType() == EMovieSceneEvaluationType::FrameLocked;
	}
	return false;
}

ULevelStreaming* UCutSceneEditorFunctionLibrary::GetLevelByName(const FString& LevelName)
{
	if (!GIsEditor || GEditor->GetPIEWorldContext()) return nullptr;

	const UWorld* World = GEditor->GetEditorWorldContext().World();
	if (!World) return nullptr;

	for (ULevelStreaming* LevelStreaming : World->GetStreamingLevels())
	{
		if (LevelStreaming && LevelStreaming->GetWorldAssetPackageName().EndsWith(LevelName, ESearchCase::IgnoreCase))
		{
			return LevelStreaming;
		}
	}
	return nullptr;
}

void UCutSceneEditorFunctionLibrary::SetLevelVisibility(const FString& LevelName, const bool bVisible)
{
	ULevelStreaming* Level = GetLevelByName(LevelName);
	if (!Level)
		return;

	Level->SetShouldBeVisibleInEditor(bVisible);
	Level->GetWorld()->FlushLevelStreaming();

	// Iterate over the level's actors
	ULevel* LoadedLevel = Level->GetLoadedLevel();
	if (LoadedLevel != nullptr)
	{
		auto& Actors = LoadedLevel->Actors;
		for (int32 ActorIndex = 0; ActorIndex < Actors.Num(); ++ActorIndex)
		{
			if (AActor* Actor = Actors[ActorIndex])
			{
				if (Actor->bHiddenEdLevel == bVisible)
				{
					Actor->bHiddenEdLevel = !bVisible;
					if (bVisible)
					{
						Actor->ReregisterAllComponents();
					}
					else
					{
						Actor->UnregisterAllComponents();
					}
				}
			}
		}
	}
}

bool UCutSceneEditorFunctionLibrary::GetLevelVisibility(const FString& LevelName)
{
	const ULevelStreaming* Level = GetLevelByName(LevelName);
	if (!Level)
		return false;

	return Level->GetShouldBeVisibleInEditor();
}

UAnimSequence* UCutSceneEditorFunctionLibrary::ImportAnimationFromFbx(const FString FbxPath, const FString SaveAssetPath, USkeletalMesh* RetargetMesh, USkeleton* Skeleton)
{
	if (!GEditor)
	{
		UE_LOG(LogTemp, Error, TEXT("UCutSceneEditorFunctionLibrary::ImportAnimationFromFbx: GEditor is null"));
		return nullptr;
	}

	if (!Skeleton)
	{
		UE_LOG(LogTemp, Error, TEXT("UCutSceneEditorFunctionLibrary::ImportAnimationFromFbx: Skeleton is null"));
		return nullptr;
	}

	if (FbxPath.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("UCutSceneEditorFunctionLibrary::ImportAnimationFromFbx: FbxPath is empty"));
		return nullptr;
	}

	if (SaveAssetPath.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("UCutSceneEditorFunctionLibrary::ImportAnimationFromFbx: SaveAssetPath is empty"));
		return nullptr;
	}

	// 使用UE5.5的高级API导入FBX动画
	// 创建导入任务
	FAssetToolsModule& AssetToolsModule = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools");
	
	UAssetImportTask* ImportTask = NewObject<UAssetImportTask>();
	ImportTask->AddToRoot();
	ON_SCOPE_EXIT
	{
		if (ImportTask->IsValidLowLevel())
			ImportTask->RemoveFromRoot();
	};
	
	// 创建FBX导入UI选项
	UFbxImportUI* ImportUI = NewObject<UFbxImportUI>();
	ImportUI->MeshTypeToImport = FBXIT_Animation;
	ImportUI->bImportAnimations = true;
	ImportUI->Skeleton = Skeleton;
	
	// 设置动画导入选项
	ImportUI->AnimSequenceImportData->bImportMeshesInBoneHierarchy = false;
	ImportUI->AnimSequenceImportData->bImportBoneTracks = true;
	ImportUI->AnimSequenceImportData->bImportCustomAttribute = true;
	ImportUI->AnimSequenceImportData->bDeleteExistingMorphTargetCurves = false;
	ImportUI->AnimSequenceImportData->bDeleteExistingCustomAttributeCurves = false;
	ImportUI->AnimSequenceImportData->bDeleteExistingNonCurveCustomAttributes = false;

	// 创建FBX工厂
	UFbxFactory* FbxFactory = NewObject<UFbxFactory>();
	FbxFactory->ImportUI = ImportUI;
	
	// 设置工厂的导入UI
	ImportTask->Factory = FbxFactory;
	ImportTask->Options = ImportUI;
	ImportTask->bAutomated = true;
	ImportTask->bSave = true;
	ImportTask->Filename = FbxPath;
	ImportTask->DestinationPath = SaveAssetPath;
	ImportTask->DestinationName = FPaths::GetBaseFilename(FbxPath).Replace(TEXT(".fbx"), TEXT(""), ESearchCase::IgnoreCase);
	ImportTask->bReplaceExisting = true;

	AssetToolsModule.Get().ImportAssetTasks({ImportTask});

	if (ImportTask->ImportedObjectPaths.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("UCutSceneEditorFunctionLibrary::ImportAnimationFromFbx: Failed to import animation from FBX file"));
		return nullptr;
	}

	// 查找导入的动画序列
	UAnimSequence* ImportedAnimSequence = nullptr;
	for (const auto& ImportedObjectPath : ImportTask->ImportedObjectPaths)
	{
		if (UAnimSequence* AnimSequence = LoadObject<UAnimSequence>(nullptr, *ImportedObjectPath))
		{
			ImportedAnimSequence = AnimSequence;
			break;
		}
	}

	if (!ImportedAnimSequence)
	{
		UE_LOG(LogTemp, Error, TEXT("UCutSceneEditorFunctionLibrary::ImportAnimationFromFbx: No AnimSequence found in imported objects"));
		return nullptr;
	}

	// 设置重定向网格（如果提供）
	if (RetargetMesh)
	{
		ImportedAnimSequence->SetRetargetSourceAsset(RetargetMesh);
	}

	UE_LOG(LogTemp, Log, TEXT("UCutSceneEditorFunctionLibrary::ImportAnimationFromFbx: Successfully imported animation to: %s"), *SaveAssetPath);
	return ImportedAnimSequence;
}

void UCutSceneEditorFunctionLibrary::TryInvokeTab(const FName TabName)
{
	if (!GIsEditor) return;
	FGlobalTabmanager::Get()->TryInvokeTab(TabName);
}

void UCutSceneEditorFunctionLibrary::OpenUDPTransform()
{
	if (!GIsEditor)
	{
		UE_LOG(LogTemp, Warning, TEXT("OpenUDPTransform: Not in editor mode."));
		return;
	}

	// 使用反射获取 UUdpMessagingSettings 类
	UClass* UdpSettingsClass = StaticLoadClass(UObject::StaticClass(), nullptr, TEXT("/Script/UdpMessaging.UdpMessagingSettings"));
	if (!UdpSettingsClass)
	{
		UE_LOG(LogTemp, Error, TEXT("OpenUDPTransform: Failed to load UdpMessagingSettings class."));
		return;
	}

	// 获取默认对象
	UObject* DefaultObject = UdpSettingsClass->GetDefaultObject();
	if (!DefaultObject)
	{
		UE_LOG(LogTemp, Error, TEXT("OpenUDPTransform: Failed to get default object of UdpMessagingSettings."));
		return;
	}

	// 查找 EnableTunnel 属性
	FBoolProperty* EnableTransport = CastField<FBoolProperty>(UdpSettingsClass->FindPropertyByName(TEXT("EnableTransport")));
	if (!EnableTransport)
	{
		UE_LOG(LogTemp, Error, TEXT("OpenUDPTransform: Failed to find EnableTunnel property."));
		return;
	}

	// 设置属性值为 true
	EnableTransport->SetPropertyValue_InContainer(DefaultObject, true);

	// 保存配置
	DefaultObject->SaveConfig();

	ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings");
	if (SettingsModule != nullptr)
	{
		if (TSharedPtr<ISettingsContainer> Container = SettingsModule->GetContainer(TEXT("Project")))
		{
			if (TSharedPtr<ISettingsCategory> Category = Container->GetCategory(TEXT("Plugins")))
			{
				if (TSharedPtr<ISettingsSection> SettingsSection = Category->GetSection(TEXT("UdpMessaging")))
				{
					SettingsSection->Save();
				}
			}
		}
	}
}

bool UCutSceneEditorFunctionLibrary::IsMayaLiveLinkConnected()
{
	if (!IModularFeatures::Get().IsModularFeatureAvailable(ILiveLinkClient::ModularFeatureName))
	{
		return false;
	}

	const ILiveLinkClient& LiveLinkClient = IModularFeatures::Get().GetModularFeature<ILiveLinkClient>(ILiveLinkClient::ModularFeatureName);
	const TArray<FGuid>& Sources = LiveLinkClient.GetSources();
	for (const FGuid& Source : Sources)
	{
		if (LiveLinkClient.IsSourceStillValid(Source))
		{
			if (ULiveLinkSourceSettings* Settings = LiveLinkClient.GetSourceSettings(Source))
			{
				if (Settings->Factory == UMayaLiveLinkSourceFactory::StaticClass())
					return true;
			}
		}
	}
	return false;
}

bool UCutSceneEditorFunctionLibrary::InitializeMayaLiveLink()
{
	static TWeakPtr<SWindow> WeakWindow;
	if (!IModularFeatures::Get().IsModularFeatureAvailable(ILiveLinkClient::ModularFeatureName))
	{
		return false;
	}
	
	if (WeakWindow.IsValid())
		return false;
	
	const UMayaLiveLinkSourceFactory* Factory = GetDefault<UMayaLiveLinkSourceFactory>();
	TSharedPtr<SWindow> Window = SNew(SWindow)
		.Title(FText::FromString(TEXT("Select Maya LiveLink Source")))
		// .IsPopupWindow(true)
		.IsTopmostWindow(true)
		.AutoCenter(EAutoCenter::PreferredWorkArea)
		.ClientSize(FVector2D(400.0f, 300.0f));
	
	const TSharedPtr<SWidget> Widget = Factory->BuildCreationPanel(
		ULiveLinkSourceFactory::FOnLiveLinkSourceCreated::CreateLambda([Window](TSharedPtr<ILiveLinkSource> NewSource, FString ConnectionString)
		{
			if (NewSource.IsValid())
			{
				ILiveLinkClient& LiveLinkClient = IModularFeatures::Get().GetModularFeature<ILiveLinkClient>(ILiveLinkClient::ModularFeatureName);
				if (!IsMayaLiveLinkConnected())
				{
					const FGuid NewSourceGuid = LiveLinkClient.AddSource(NewSource);
					if (NewSourceGuid.IsValid())
					{
						if (ULiveLinkSourceSettings* Settings = LiveLinkClient.GetSourceSettings(NewSourceGuid))
						{
							Settings->ConnectionString = ConnectionString;
							Settings->Factory = UMayaLiveLinkSourceFactory::StaticClass();
						}
					}
				}
			}
			
			if (Window && !Window->IsDestroyed())
			{
				FSlateApplication::Get().RequestDestroyWindow(Window.ToSharedRef());
			}
		})
	);
	
	if (Widget.IsValid())
	{
		WeakWindow = Window;
		Window->SetContent(Widget.ToSharedRef());
		FSlateApplication::Get().AddWindow(Window.ToSharedRef());
	}
	return true;
}

bool UCutSceneEditorFunctionLibrary::SetMayaLiveLinkAnimClass(int64 InActorID, FName SubjectName)
{
	ACharacter* Character = Cast<ACharacter>(KGUtils::GetActorByID(InActorID));
	if (!Character || Character->IsPendingKillPending()) return false;
	
	USkeletalMeshComponent* MeshComponent = Character->GetMesh();
	if (!MeshComponent) return false;
	
	const UCutSceneEditorSettings* CutSceneSettings = GetDefault<UCutSceneEditorSettings>();
	const UAnimBlueprint* AnimBp = CutSceneSettings->MayaLiveLinkAnimBlueprint.LoadSynchronous();
	if (!AnimBp) return false;
	
	MeshComponent->SetAnimationMode(EAnimationMode::AnimationBlueprint);
	MeshComponent->SetAnimInstanceClass(AnimBp->GeneratedClass);
	
	UAnimInstance* AnimInstance = MeshComponent->GetAnimInstance();
	if (!AnimInstance)
	{
		UE_LOG(LogTemp, Error, TEXT("UCutSceneEditorFunctionLibrary::SetMayaLiveLinkAnimClass: Failed to get AnimInstance"))
		return false;
	}
	const UClass* AnimClass = AnimInstance->GetClass();
	if (!AnimClass) return false;
	
	FProperty* FoundProperty = AnimClass->FindPropertyByName(TEXT("SubjectName"));
	if (!FoundProperty || !FoundProperty->IsA<FNameProperty>())
		return false;
	
	FoundProperty->SetValue_InContainer(AnimInstance, &SubjectName);
	return true;
}

TSharedPtr<ISequencer> UCutSceneEditorFunctionLibrary::GetSequencer(const UObject* InObj)
{
	if (!InObj) return nullptr;
	
	ULevelSequence* LevelSequence = InObj->GetTypedOuter<ULevelSequence>();
	if (!LevelSequence) return nullptr;

	IAssetEditorInstance* Editor = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(LevelSequence, /*bFocusIfOpen*/false);
	if (!Editor) return nullptr;

	if (Editor->GetEditorName() != TEXT("LevelSequenceEditor")) return nullptr;
	ILevelSequenceEditorToolkit* LSKit = static_cast<ILevelSequenceEditorToolkit*>(Editor);
	if (!LSKit) return nullptr;

	TSharedPtr<ISequencer> Sequencer = LSKit->GetSequencer();
	return Sequencer;
}
