// Copyright Epic Games, Inc. All Rights Reserved.


#include "CutScene/LookAtPropertySection.h"

#include "Containers/ArrayView.h"
#include "Delegates/Delegate.h"
#include "Framework/Commands/UIAction.h"
#include "Framework/Commands/UICommandInfo.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "ISequencer.h"
#include "Internationalization/Internationalization.h"
#include "Misc/EnumClassFlags.h"
#include "Misc/Guid.h"
#include "MovieSceneSection.h"
#include "ScopedTransaction.h"
#include "CutScene/MovieSceneLookAtSection.h"
#include "Styling/SlateTypes.h"
#include "Templates/Casts.h"
#include "Textures/SlateIcon.h"
#include "UObject/NameTypes.h"
#include "UObject/UnrealNames.h"
#include "UObject/WeakObjectPtr.h"
#include "UObject/WeakObjectPtrTemplates.h"

#include "Sections/MovieScene3DTransformSection.h"


class UObject;
enum class EMovieSceneLookAtChannel : uint32;

#define LOCTEXT_NAMESPACE "FLookAtSection"



void FLookAtSection::BuildSectionContextMenu(FMenuBuilder& MenuBuilder, const FGuid& InObjectBinding)
{
	UMovieSceneLookAtSection* TransformSection = CastChecked<UMovieSceneLookAtSection>(WeakSection.Get());
	TSharedPtr<ISequencer> SequencerPtr = WeakSequencer.Pin();

	auto MakeUIAction = [=](EMovieSceneLookAtChannel ChannelsToToggle)
	{
		return FUIAction(
			FExecuteAction::CreateLambda([=]
				{
					FScopedTransaction Transaction(LOCTEXT("SetActiveChannelsTransaction", "Set Active Channels"));
					TransformSection->Modify();
					EMovieSceneLookAtChannel Channels = TransformSection->GetMask().GetChannels();

					if (EnumHasAllFlags(Channels, ChannelsToToggle) || (Channels & ChannelsToToggle) == EMovieSceneLookAtChannel::None)
					{
						TransformSection->SetMask(TransformSection->GetMask().GetChannels() ^ ChannelsToToggle);
					}
					else
					{
						TransformSection->SetMask(TransformSection->GetMask().GetChannels() | ChannelsToToggle);
					}

					// Restore pre-animated state for the bound objects so that inactive channels will return to their default values.
					for (TWeakObjectPtr<> WeakObject : SequencerPtr->FindBoundObjects(InObjectBinding, SequencerPtr->GetFocusedTemplateID()))
					{
						if (UObject* Object = WeakObject.Get())
						{
							SequencerPtr->RestorePreAnimatedState();
						}
					}

					SequencerPtr->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemsChanged);
				}
			),
			FCanExecuteAction(),
			FGetActionCheckState::CreateLambda([=]
			{
				EMovieSceneLookAtChannel Channels = TransformSection->GetMask().GetChannels();
				if (EnumHasAllFlags(Channels, ChannelsToToggle))
				{
					return ECheckBoxState::Checked;
				}
				else if (EnumHasAnyFlags(Channels, ChannelsToToggle))
				{
					return ECheckBoxState::Undetermined;
				}
				return ECheckBoxState::Unchecked;
			})
		);
	};

	MenuBuilder.BeginSection(NAME_None, LOCTEXT("TransformChannelsText", "Active Channels"));
	{
		MenuBuilder.AddSubMenu(
			LOCTEXT("AllEye", "Eye"), LOCTEXT("AllEye_ToolTip", "Causes this section to affect the Eye of the transform"),
			FNewMenuDelegate::CreateLambda([=](FMenuBuilder& SubMenuBuilder){
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("EyeX", "Roll (X)"), LOCTEXT("EyeX_ToolTip", "Causes this section to affect the  roll (X) channel of the transform's Eye"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::EyeX), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("EyeY", "Pitch (Y)"), LOCTEXT("EyeY_ToolTip", "Causes this section to affect the Pitch (Y) channel of the transform's Eye"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::EyeY), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("EyeZ", "Scale (Z)"), LOCTEXT("EyeZ_ToolTip", "Causes this section to affect the Scale (Z) channel of the transform's Eye"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::EyeZ), NAME_None, EUserInterfaceActionType::ToggleButton);
			}),
			MakeUIAction(EMovieSceneLookAtChannel::Eye),
			NAME_None,
			EUserInterfaceActionType::ToggleButton);

		MenuBuilder.AddSubMenu(
			LOCTEXT("AllHead", "Head"), LOCTEXT("AllHead_ToolTip", "Causes this section to affect the Head of the transform"),
			FNewMenuDelegate::CreateLambda([=](FMenuBuilder& SubMenuBuilder){
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("HeadX", "Roll (X)"), LOCTEXT("HeadX_ToolTip", "Causes this section to affect the roll (X) channel the transform's Head"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::HeadX), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("HeadY", "Pitch (Y)"), LOCTEXT("HeadY_ToolTip", "Causes this section to affect the pitch (Y) channel the transform's Head"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::HeadY), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("HeadZ", "Yaw (Z)"), LOCTEXT("HeadZ_ToolTip", "Causes this section to affect the yaw (Z) channel the transform's Head"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::HeadZ), NAME_None, EUserInterfaceActionType::ToggleButton);
			}),
			MakeUIAction(EMovieSceneLookAtChannel::Head),
			NAME_None,
			EUserInterfaceActionType::ToggleButton);

		MenuBuilder.AddSubMenu(
			LOCTEXT("AllBody", "Body"), LOCTEXT("AllBody_ToolTip", "Causes this section to affect the Body of the transform"),
			FNewMenuDelegate::CreateLambda([=](FMenuBuilder& SubMenuBuilder){
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("BodyX", "Roll (X)"), LOCTEXT("BodyX_ToolTip", "Causes this section to affect the roll (X) channel of the transform's Body"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::BodyX), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("BodyY", "Pitch (Y)"), LOCTEXT("BodyY_ToolTip", "Causes this section to affect the pitch (Y) channel of the transform's Body"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::BodyY), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("BodyZ", "Yaw (Z)"), LOCTEXT("BodyZ_ToolTip", "Causes this section to affect the yaw (Z) channel of the transform's Body"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::BodyZ), NAME_None, EUserInterfaceActionType::ToggleButton);
			}),
			MakeUIAction(EMovieSceneLookAtChannel::Body),
			NAME_None,
			EUserInterfaceActionType::ToggleButton);

		MenuBuilder.AddSubMenu(
			LOCTEXT("AllSpine_01", "Spine_01"), LOCTEXT("AllSpine_01_ToolTip", "Causes this section to affect the Spine_01 of the transform"),
			FNewMenuDelegate::CreateLambda([=](FMenuBuilder& SubMenuBuilder) {
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("Spine_01X", "Roll (X)"), LOCTEXT("Spine_01X_ToolTip", "Causes this section to affect the roll (X) channel of the transform's Spine_01"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Spine_01X), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("Spine_01Y", "Pitch (Y)"), LOCTEXT("Spine_01Y_ToolTip", "Causes this section to affect the pitch (Y) channel of the transform's Spine_01"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Spine_01Y), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("Spine_01Z", "Yaw (Z)"), LOCTEXT("Spine_01Z_ToolTip", "Causes this section to affect the yaw (Z) channel of the transform's Spine_01"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Spine_01Z), NAME_None, EUserInterfaceActionType::ToggleButton);
				}),
			MakeUIAction(EMovieSceneLookAtChannel::Spine_01),
			NAME_None,
			EUserInterfaceActionType::ToggleButton);
		
		MenuBuilder.AddSubMenu(
			LOCTEXT("AllSpine_02", "Spine_02"), LOCTEXT("AllSpine_02_ToolTip", "Causes this section to affect the Spine_02 of the transform"),
			FNewMenuDelegate::CreateLambda([=](FMenuBuilder& SubMenuBuilder) {
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("Spine_02X", "Roll (X)"), LOCTEXT("Spine_02X_ToolTip", "Causes this section to affect the roll (X) channel of the transform's Spine_02"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Spine_02X), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("Spine_02Y", "Pitch (Y)"), LOCTEXT("Spine_02Y_ToolTip", "Causes this section to affect the pitch (Y) channel of the transform's Spine_02"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Spine_02Y), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("Spine_02Z", "Yaw (Z)"), LOCTEXT("Spine_02Z_ToolTip", "Causes this section to affect the yaw (Z) channel of the transform's Spine_02"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Spine_02Z), NAME_None, EUserInterfaceActionType::ToggleButton);
				}),
			MakeUIAction(EMovieSceneLookAtChannel::Spine_02),
			NAME_None,
			EUserInterfaceActionType::ToggleButton);

		MenuBuilder.AddSubMenu(
			LOCTEXT("AllSpine_03", "Spine_03"), LOCTEXT("AllSpine_03_ToolTip", "Causes this section to affect the Spine_03 of the transform"),
			FNewMenuDelegate::CreateLambda([=](FMenuBuilder& SubMenuBuilder){
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("Spine_03X", "Roll (X)"), LOCTEXT("Spine_03X_ToolTip", "Causes this section to affect the roll (X) channel of the transform's Spine_03"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Spine_03X), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("Spine_03Y", "Pitch (Y)"), LOCTEXT("Spine_03Y_ToolTip", "Causes this section to affect the pitch (Y) channel of the transform's Spine_03"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Spine_03Y), NAME_None, EUserInterfaceActionType::ToggleButton);
				SubMenuBuilder.AddMenuEntry(
					LOCTEXT("Spine_03Z", "Yaw (Z)"), LOCTEXT("Spine_03Z_ToolTip", "Causes this section to affect the yaw (Z) channel of the transform's Spine_03"),
					FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Spine_03Z), NAME_None, EUserInterfaceActionType::ToggleButton);
			}),
			MakeUIAction(EMovieSceneLookAtChannel::Spine_03),
			NAME_None,
			EUserInterfaceActionType::ToggleButton);
		MenuBuilder.AddMenuEntry(
			LOCTEXT("Weight", "Weight"), LOCTEXT("Weight_ToolTip", "Causes this section to be applied with a user-specified weight curve"),
			FSlateIcon(), MakeUIAction(EMovieSceneLookAtChannel::Weight), NAME_None, EUserInterfaceActionType::ToggleButton);
	}
	MenuBuilder.EndSection();
}

bool FLookAtSection::RequestDeleteCategory(const TArray<FName>& CategoryNamePaths)
{
	UMovieSceneLookAtSection* TransformSection = CastChecked<UMovieSceneLookAtSection>(WeakSection.Get());
	TSharedPtr<ISequencer> SequencerPtr = WeakSequencer.Pin();
		
	const FScopedTransaction Transaction( LOCTEXT( "DeleteTransformCategory", "Delete transform category" ) );

	if (TransformSection->TryModify())
	{
		FName CategoryName = CategoryNamePaths[CategoryNamePaths.Num()-1];
		
		EMovieSceneLookAtChannel Channel = TransformSection->GetMask().GetChannels();
		EMovieSceneLookAtChannel ChannelToRemove = TransformSection->GetMaskByName(CategoryName).GetChannels();

		Channel &= ~ChannelToRemove;

		TransformSection->SetMask(Channel);
			
		SequencerPtr->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemsChanged);
		return true;
	}

	return false;
}

bool FLookAtSection::RequestDeleteKeyArea(const TArray<FName>& KeyAreaNamePaths)
{
	UMovieSceneLookAtSection* TransformSection = CastChecked<UMovieSceneLookAtSection>(WeakSection.Get());
	TSharedPtr<ISequencer> SequencerPtr = WeakSequencer.Pin();

	const FScopedTransaction Transaction( LOCTEXT( "DeleteTransformChannel", "Delete transform channel" ) );

	if (TransformSection->TryModify())
	{
		// Only delete the last key area path which is the channel. ie. TranslationX as opposed to Translation
		FName KeyAreaName = KeyAreaNamePaths[KeyAreaNamePaths.Num()-1];

		EMovieSceneLookAtChannel Channel = TransformSection->GetMask().GetChannels();
		EMovieSceneLookAtChannel ChannelToRemove = TransformSection->GetMaskByName(KeyAreaName).GetChannels();

		Channel &= ~ChannelToRemove;

		TransformSection->SetMask(Channel);
					
		SequencerPtr->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemsChanged);
		return true;
	}

	return true;
}

#undef LOCTEXT_NAMESPACE