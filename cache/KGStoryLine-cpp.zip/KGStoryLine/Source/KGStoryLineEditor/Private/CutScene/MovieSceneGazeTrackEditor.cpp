#include "CutScene/MovieSceneGazeTrackEditor.h"

#include "3C/Character/BaseCharacter.h"
#include "CutScene/Utils/FCutsceneEditorUtils.h"
#include "ISequencerModule.h"
#include "LevelSequence.h"
#include "CutScene/MovieSceneGazeTrack.h"
#include "CutScene/MovieSceneLookAtTrack.h"
#include "SSearchableComboBox.h"
#include "Widgets/Input/STextComboBox.h"
#include "Widgets/Input/SVectorInputBox.h"
#include "Components/SkeletalMeshComponent.h"

#define LOCTEXT_NAMESPACE "MovieSceneGazeTrackEditor"

bool FMovieSceneGazeTrackEditor::SupportsType(TSubclassOf<UMovieSceneTrack> TrackClass) const
{
	return TrackClass == UMovieSceneGazeTrack::StaticClass();
}

bool FMovieSceneGazeTrackEditor::SupportsSequence(UMovieSceneSequence* InSequence) const
{
	return InSequence && InSequence->IsA(ULevelSequence::StaticClass());
}

void FMovieSceneGazeTrackEditor::BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	if (ObjectClass == nullptr || !ObjectClass->IsChildOf(ABaseCharacter::StaticClass()))
		return;
	if (ObjectBindings.Num() == 0)
		return;
	FGuid ObjectBinding = ObjectBindings[0];
	MenuBuilder.AddMenuEntry(
		NSLOCTEXT("Sequencer", "AddGazeTrack", "LookAtTarget"),
		NSLOCTEXT("Sequencer", "AddGazeTooltip", "Adds a LookAtTarget track."),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateLambda([this, ObjectBinding = MoveTemp(ObjectBinding)]
		{
			UMovieScene* FocusedMovieScene = GetFocusedMovieScene();
			const TSharedPtr<ISequencer> Sequencer = GetSequencer();
			if (FocusedMovieScene == nullptr || !Sequencer)
				return;
		
			FMovieSceneBinding* MovieSceneBinding = FocusedMovieScene->FindBinding(ObjectBinding);
			if (!ensure(MovieSceneBinding))
				return;

			const TArray<UMovieSceneTrack*>& Tracks = MovieSceneBinding->GetTracks();
			for (const UMovieSceneTrack* Track : Tracks)
			{
				if (Track && (Track->IsA<UMovieSceneLookAtTrack>() || Track->IsA<UMovieSceneGazeTrack>()))
				{
					FCutsceneEditorUtils::CreateNotification(LOCTEXT("AddLookAtConflict", "已经存在一条LookAt轨道，不能再添加！"), false);
					return;
				}
			}
		
			const FScopedTransaction Transaction(LOCTEXT("AddGazeTrakc_Transaction", "Add Audio2Face Track"));
			FocusedMovieScene->Modify();

			UMovieSceneGazeTrack* NewTrack = FocusedMovieScene->AddTrack<UMovieSceneGazeTrack>(ObjectBinding);
			ensure(NewTrack);

			UMovieSceneSection* NewSection = NewTrack->CreateNewSection();
			NewTrack->AddSection(*NewSection);
		
			FFrameNumber PlaybackEnd = UE::MovieScene::DiscreteExclusiveUpper(FocusedMovieScene->GetPlaybackRange());
			FFrameRate FrameResolution = FocusedMovieScene->GetTickResolution();
			FFrameNumber SpawnSectionStartTime = Sequencer->GetLocalTime().ConvertTo(FrameResolution).RoundToFrame();
			FFrameTime SpawnSectionDuration = FrameResolution.AsFrameTime(5.0);
			FFrameNumber SpawnSectionEndTime = (SpawnSectionStartTime + SpawnSectionDuration).RoundToFrame();
			if (SpawnSectionEndTime > PlaybackEnd && SpawnSectionStartTime < PlaybackEnd)
				SpawnSectionEndTime = PlaybackEnd;
			NewSection->SetRange(TRange<FFrameNumber>(SpawnSectionStartTime, SpawnSectionEndTime));

			Sequencer->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
		}))
	);
}

TSharedPtr<SWidget> FMovieSceneGazeTrackEditor::BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params)
{
	return FMovieSceneTrackEditor::BuildOutlinerEditWidget(ObjectBinding, Track, Params);
}

TSharedRef<ISequencerSection> FMovieSceneGazeTrackEditor::MakeSectionInterface(UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding)
{
	return MakeShared<FGazeSection>(GetSequencer(), SectionObject);
}

FGazeSection::FGazeSection(const TSharedPtr<ISequencer>& InSequencer, UMovieSceneSection& InSection)
	: FSequencerSection(InSection)
	, WeakSequencer(InSequencer)
	, CurrentActorIndex(0)
	, CurrentBoneIndex(0)
{
	UpdateCandidates();
}

void FGazeSection::OnGazeActorChanged(TSharedPtr<FString> String, ESelectInfo::Type Arg)
{
	if (!WeakSection.IsValid() || !WeakSequencer.IsValid())
		return;

	CurrentActorIndex = CandidateObjectNames.IndexOfByPredicate([&String](const TSharedPtr<FString>& Name) { return String->Equals(*Name); });
	if (CurrentActorIndex == INDEX_NONE)
	{
		CurrentActorIndex = 0;
		UpdateCandidates();
		return;
	}

	if (UMovieSceneGazeSection* Section = Cast<UMovieSceneGazeSection>(WeakSection.Get()))
	{
		Section->ObjectBindingId = CandidateObjectBindings[CurrentActorIndex];
		// WeakSequencer.Pin()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemsChanged);
	}
	
	UpdateCandidates();
}

void FGazeSection::RefreshCandidateBones(const TWeakObjectPtr<AActor> InActor)
{
	TArray<TSharedPtr<FString>>& Names = CandidateBoneNames;
	Names.Empty();
	Names.Add(MakeShared<FString>(TEXT("root")));
	if (InActor.IsValid())
	{
		USkeletalMeshComponent* SkeletalMeshComponent = InActor->GetComponentByClass<USkeletalMeshComponent>();
		if (SkeletalMeshComponent && SkeletalMeshComponent->GetSkeletalMeshAsset())
		{
			FReferenceSkeleton ReferenceSkeleton = SkeletalMeshComponent->GetSkeletalMeshAsset()->GetRefSkeleton();
			for (int32 BoneIndex = 0; BoneIndex < ReferenceSkeleton.GetNum(); BoneIndex++)
			{
				FString BoneName = ReferenceSkeleton.GetBoneName(BoneIndex).ToString();
				Names.Add(MakeShared<FString>(BoneName));
			}
		}
	}

	UE_LOG(LogTemp, Log, TEXT("RefreshCandidateBones: %d"), Names.Num());
}

TSharedRef<SWidget> FGazeSection::MakeWidgetFromString(TSharedPtr<FString> InString)
{
	return SNew(STextBlock)
		.Text(FText::FromString(*InString));
}

FText FGazeSection::GetCurrentBoneName() const
{
	return FText::FromString(*CandidateBoneNames[CurrentBoneIndex]);
}

FText FGazeSection::GetCurrentActorName() const
{
	return FText::FromString(*CandidateObjectNames[CurrentActorIndex]);
}

void FGazeSection::OnBoneChanged(TSharedPtr<FString> String, ESelectInfo::Type Arg)
{
	if (!WeakSection.IsValid() || !WeakSequencer.IsValid())
		return;

	CurrentBoneIndex = CandidateBoneNames.IndexOfByPredicate([&String](const TSharedPtr<FString>& Name) { return String->Equals(*Name); });
	if (CurrentBoneIndex == INDEX_NONE)
		CurrentBoneIndex = 0;

	UMovieSceneGazeSection* MovieSceneGazeSection = Cast<UMovieSceneGazeSection>(WeakSection);
	if (ensure(MovieSceneGazeSection != nullptr))
	{
		MovieSceneGazeSection->BoneName = *CandidateBoneNames[CurrentBoneIndex];
		if (UMovieSceneGazeTrack* Track = WeakSection->GetTypedOuter<UMovieSceneGazeTrack>())
		{
			Track->bDataModified = true;	
		}
		WeakSequencer.Pin()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemsChanged);
	}
	
}

TOptional<float> FGazeSection::GetOffset(int I) const
{
	if (!WeakSection.IsValid() || !WeakSequencer.IsValid())
		return 0;

	UMovieSceneGazeSection* MovieSceneGazeSection = Cast<UMovieSceneGazeSection>(WeakSection);
	if (ensure(MovieSceneGazeSection != nullptr))
	{
		return MovieSceneGazeSection->Offset[I];
	}
	return 0;
}

void FGazeSection::SetOffset(float X, int I) const
{
	if (!WeakSection.IsValid() || !WeakSequencer.IsValid())
		return;

	UMovieSceneGazeSection* MovieSceneGazeSection = Cast<UMovieSceneGazeSection>(WeakSection);
	if (ensure(MovieSceneGazeSection != nullptr))
	{
		MovieSceneGazeSection->Offset[I] = X;
		if (UMovieSceneGazeTrack* Track = WeakSection->GetTypedOuter<UMovieSceneGazeTrack>())
		{
			Track->bDataModified = true;	
		}
		WeakSequencer.Pin()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemsChanged);
	}
}

void FGazeSection::UpdateCandidates()
{
	if (!WeakSection.IsValid() || !WeakSequencer.IsValid())
		return;

	TSharedPtr<ISequencer> Sequencer = WeakSequencer.Pin();
	UMovieSceneGazeSection* Section = Cast<UMovieSceneGazeSection>(this->WeakSection.Get());
	if (!ensure(Section != nullptr))
		return;
	
	CurrentActorIndex = 0;
	TargetActor = nullptr;
	CandidateObjectNames.Empty();
	CandidateObjectBindings.Empty();
	CandidateObjectNames.Add(MakeShared<FString>(TEXT("None")));
	CandidateObjectBindings.Add(FGuid());
	ULevelSequence* LevelSequence = Section->GetTypedOuter<ULevelSequence>();
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (ensure(LevelSequence && MovieScene))
	{
		const TArray<FMovieSceneBinding>& Bindings = MovieScene->GetBindings();
		for (const FMovieSceneBinding& Binding : Bindings)
		{
			FGuid ObjectBindingID = Binding.GetObjectGuid();

			FMovieSceneSequenceID SequenceID = Sequencer->GetFocusedTemplateID();
			TArrayView<TWeakObjectPtr<>> WeakObjectPtrs = Sequencer->FindBoundObjects(ObjectBindingID, SequenceID);
			for (auto BoundObject : WeakObjectPtrs)
			{
				if (BoundObject.IsValid() && BoundObject->IsA(AActor::StaticClass()))
				{
					AActor* Actor = Cast<AActor>(BoundObject.Get());
					CandidateObjectNames.Add(MakeShared<FString>(Actor->GetActorLabel()));
					CandidateObjectBindings.Add(ObjectBindingID);
					if (ObjectBindingID == Section->ObjectBindingId)
					{
						CurrentActorIndex = CandidateObjectNames.Num() - 1;
						TargetActor = Actor;
					}
				}
			}
		}
	}

	RefreshCandidateBones(TargetActor);
	CurrentBoneIndex = CandidateBoneNames.IndexOfByPredicate([&Section](const TSharedPtr<FString>& InBoneName) {return InBoneName->Equals(Section->BoneName); });
	if (CurrentBoneIndex == INDEX_NONE)
		CurrentBoneIndex = 0;

	if (BoneBox)
		BoneBox->RefreshOptions();
}

void FGazeSection::BuildEditGazeSubMenu(FMenuBuilder& MenuBuilder)
{
	UpdateCandidates();
	
	MenuBuilder.BeginSection(TEXT("Gaze Settings"), LOCTEXT("Gaze Settings", "LookAtTarget配置"));
	MenuBuilder.AddWidget(
		SNew(SSearchableComboBox)
		.OptionsSource(&CandidateObjectNames)
		.InitiallySelectedItem(CandidateObjectNames[CurrentActorIndex])
		.OnSelectionChanged(this->AsShared(), &FGazeSection::OnGazeActorChanged)
		.OnGenerateWidget_Static(&FGazeSection::MakeWidgetFromString)
		[
			SNew(STextBlock)
				.Text(this->AsShared(), &FGazeSection::GetCurrentActorName)
		],
		LOCTEXT("GazeActorLabel1", "Target Actor")
	);
	
	MenuBuilder.AddWidget(
		SAssignNew(BoneBox, SSearchableComboBox)
		.OptionsSource(&CandidateBoneNames)
		.InitiallySelectedItem(CandidateBoneNames[CurrentBoneIndex])
		.OnSelectionChanged(this->AsShared(), &FGazeSection::OnBoneChanged)
		.OnGenerateWidget_Static(&FGazeSection::MakeWidgetFromString)
		[
			SNew(STextBlock)
				.Text(this->AsShared(), &FGazeSection::GetCurrentBoneName)
		],
		LOCTEXT("GazeActorLabel2", "Bone Name")
	);
	
	MenuBuilder.AddWidget(
		SNew(SVectorInputBox)
		.AllowSpin(true)
		.X(this, &FGazeSection::GetOffset, 0)
		.OnXChanged(this, &FGazeSection::SetOffset, 0)
		.Y(this, &FGazeSection::GetOffset, 1)
		.OnYChanged(this, &FGazeSection::SetOffset, 1)
		.Z(this, &FGazeSection::GetOffset, 2)
		.OnZChanged(this, &FGazeSection::SetOffset, 2),
		LOCTEXT("GazeActorLabel3", "Offset")
	);
	MenuBuilder.EndSection();
}

void FGazeSection::BuildSectionContextMenu(FMenuBuilder& MenuBuilder, const FGuid& ObjectBinding)
{
	MenuBuilder.AddSubMenu(
		LOCTEXT("GazeSettingsLabel", "LookAtTarget配置"),
		LOCTEXT("GazePropertyTooltip", "Edit Gaze Property"),
		FNewMenuDelegate::CreateSP(this, &FGazeSection::BuildEditGazeSubMenu)
	);
}

FText FGazeSection::GetSectionText() const
{
	if (CandidateObjectNames.IsValidIndex(CurrentActorIndex) && CandidateBoneNames.IsValidIndex(CurrentBoneIndex))
		return FText::FromString(FString::Printf(TEXT("%s\n%s"), **CandidateObjectNames[CurrentActorIndex], **CandidateBoneNames[CurrentBoneIndex]));
	return FText::GetEmpty();
}

TSharedRef<SWidget> FGazeSection::GenerateSectionWidget()
{
	if (CandidateObjectNames.Num() == 1 && *CandidateObjectNames[0] == TEXT("None") ||
		!(CandidateObjectNames.IsValidIndex(CurrentActorIndex) && CandidateBoneNames.IsValidIndex(CurrentBoneIndex)))
	{
		UpdateCandidates();
	}
	return SNew(STextBlock).Text(this, &FGazeSection::GetSectionText);
		
}

#undef LOCTEXT_NAMESPACE
