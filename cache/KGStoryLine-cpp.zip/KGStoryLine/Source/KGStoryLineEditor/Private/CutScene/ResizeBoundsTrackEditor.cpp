#include "CutScene/ResizeBoundsTrackEditor.h"
#include "CutScene/MovieSceneResizeBoundsSection.h"
#include "CutScene/MovieSceneResizeBoundsTrack.h"
#include "Animation/SkeletalMeshActor.h"
#include "GameFramework/Character.h"
#include "Tracks/MovieSceneSkeletalAnimationTrack.h"

#define LOCTEXT_NAMESPACE "ResizeBoundsTrackEditor"


FResizeBoundsTrackEditor::FResizeBoundsTrackEditor(TSharedRef<ISequencer> InSequencer)
	: FMovieSceneTrackEditor(InSequencer)
{
}

FResizeBoundsTrackEditor::~FResizeBoundsTrackEditor()
{
}

TSharedRef<ISequencerTrackEditor> FResizeBoundsTrackEditor::CreateTrackEditor(TSharedRef<ISequencer> OwningSequencer)
{
	return MakeShareable(new FResizeBoundsTrackEditor(OwningSequencer));
}


bool FResizeBoundsTrackEditor::SupportsType(TSubclassOf<UMovieSceneTrack> Type) const
{
	//lizhang@kuaishou.com，修正以前的错误代码，不能简单return true，必须匹配类型，不然会导致其他类似条件的轨道不生效
	//return true
	return Type == UMovieSceneResizeBoundsTrack::StaticClass();
}

void FResizeBoundsTrackEditor::OnInitialize()
{
	if (!GetSequencer().IsValid())
	{
		return;
	}
	GetSequencer()->OnPreSave().AddRaw(this, &FResizeBoundsTrackEditor::OnPreSave);
	GetSequencer()->OnActorAddedToSequencer().AddRaw(this, &FResizeBoundsTrackEditor::OnActorAddedToSequencer);
}

void FResizeBoundsTrackEditor::OnRelease()
{
	if (!GetSequencer().IsValid())
	{
		return;
	}
	GetSequencer()->OnPreSave().RemoveAll(this);
	GetSequencer()->OnActorAddedToSequencer().RemoveAll(this);
}

void FResizeBoundsTrackEditor::OnPreSave(ISequencer& InSequencer)
{
	UMovieSceneSequence* MovieSceneSequence = InSequencer.GetFocusedMovieSceneSequence();
	UMovieScene* MovieScene = MovieSceneSequence ? MovieSceneSequence->GetMovieScene() : nullptr;
	if (MovieScene)
	{
		const TArray<FMovieSceneBinding>& Bindings = MovieScene->GetBindings();
		for (const FMovieSceneBinding& Binding : Bindings)
		{
			TRange<FFrameNumber> TotalRange;
			
			if (GetSkeletalAnimationSectionTotalRange(MovieScene, Binding.GetObjectGuid(), TotalRange))
			{
				if (UMovieSceneResizeBoundsTrack* Track = MovieScene->FindTrack<UMovieSceneResizeBoundsTrack>(Binding.GetObjectGuid()))
				{
					if (Track->GetAllSections().IsEmpty())
					{
						UMovieSceneResizeBoundsSection* NewSection = Cast<UMovieSceneResizeBoundsSection>(Track->CreateNewSection());
						Track->AddSection(*NewSection);
						NewSection->SetRange(TotalRange);
					}
					else
					{
						if (UMovieSceneResizeBoundsSection* Section = Cast<UMovieSceneResizeBoundsSection>(Track->GetAllSections().Last()))
						{
							Section->SetRange(TotalRange);
							Section->SetIsActive(true);
						}
					}
				}
				else
				{
					AddDefaultResizeBoundsTrack(MovieScene, Binding.GetObjectGuid(), TotalRange);
				}
			}
			else
			{
				if (UMovieSceneResizeBoundsTrack* Track = MovieScene->FindTrack<UMovieSceneResizeBoundsTrack>(Binding.GetObjectGuid()))
				{
					const FScopedTransaction Transaction(LOCTEXT("ResizeBoundsTrackEditor_Transaction_OnPreSave", "Auto Remove Resize Bounds Track"));
					MovieScene->Modify();

					MovieScene->RemoveTrack(*Track);
					InSequencer.NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemRemoved);
				}
			}
		}
	}	
}

void FResizeBoundsTrackEditor::OnActorAddedToSequencer(AActor* Actor, const FGuid ObjectBinding)
{
	if (Actor->IsA(ACharacter::StaticClass()) || Actor->IsA(ASkeletalMeshActor::StaticClass()))
	{
		if (UMovieScene* MovieScene = GetFocusedMovieScene())
		{
			TRange<FFrameNumber> TotalRange = TRange<FFrameNumber>::All();
			AddDefaultResizeBoundsTrack(MovieScene, ObjectBinding, TotalRange);
		}
	}
}

void FResizeBoundsTrackEditor::AddDefaultResizeBoundsTrack(UMovieScene* MovieScene, const FGuid& ObjectBinding, TRange<FFrameNumber>& Range)
{
	if (MovieScene)
	{
		const FScopedTransaction Transaction(LOCTEXT("ResizeBoundsTrackEditor_Transaction_AddDefaultResizeBoundsTrack", "Auto Add Resize Bounds Track"));
		MovieScene->Modify();
			
		UMovieSceneResizeBoundsTrack* Track = MovieScene->AddTrack<UMovieSceneResizeBoundsTrack>(ObjectBinding);
		if (ensure(Track))
		{
			UMovieSceneResizeBoundsSection* NewSection = Cast<UMovieSceneResizeBoundsSection>(Track->CreateNewSection());
			Track->AddSection(*NewSection);
			NewSection->SetRange(Range);
		}
		if (GetSequencer().IsValid())
		{
			GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
		}
	}
}

bool FResizeBoundsTrackEditor::GetSkeletalAnimationSectionTotalRange(UMovieScene* MovieScene, const FGuid& ObjectBinding, TRange<FFrameNumber>& OutRange)
{
	OutRange = TRange<FFrameNumber>::Empty();
	TArray<UMovieSceneTrack*> Tracks = MovieScene->FindTracks(UMovieSceneSkeletalAnimationTrack::StaticClass(), ObjectBinding);
	for (UMovieSceneTrack* Track : Tracks)
	{
		if (UMovieSceneSkeletalAnimationTrack* SkeletalAnimationTrack = CastChecked<UMovieSceneSkeletalAnimationTrack>(Track))
		{
			for (UMovieSceneSection* Section : SkeletalAnimationTrack->GetAllSections())
			{
				if (Section)
				{
					if (OutRange.IsEmpty())
					{
						OutRange = Section->GetRange();
					}
					else
					{
						OutRange.SetLowerBound(TRangeBound<FFrameNumber>::MinLower(OutRange.GetLowerBound(), Section->GetRange().GetLowerBound()));
						OutRange.SetUpperBound(TRangeBound<FFrameNumber>::MaxUpper(OutRange.GetUpperBound(), Section->GetRange().GetUpperBound()));
					}
				}
			}
		}
	}
	return !OutRange.IsEmpty();
}


#undef LOCTEXT_NAMESPACE



