#include "CutScene/MovieSceneQTETrackEditor.h"
#include "ISequencer.h"
#include "LevelSequence.h"
#include "SequencerSectionPainter.h"
#include "EditorStyleSet.h"

#include "CutScene/MovieSceneQTESection.h"
#include "CutScene/MovieSceneQTETrack.h"

#include "Misc/KGCoreEditorFunctionLibrary.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"

#define LOCTEXT_NAMESPACE "FMovieSceneQTETrackEditor"

TSharedRef<ISequencerTrackEditor> FMovieSceneQTETrackEditor::CreateTrackEditor(TSharedRef<ISequencer> InSequencer)
{
	return MakeShareable(new FMovieSceneQTETrackEditor(InSequencer));
}

FMovieSceneQTETrackEditor::FMovieSceneQTETrackEditor(TSharedRef<ISequencer> InSequencer)
	: FMovieSceneTrackEditor(InSequencer)
{
}

FMovieSceneQTETrackEditor::~FMovieSceneQTETrackEditor()
{
}

const FSlateBrush* FMovieSceneQTETrackEditor::GetIconBrush() const
{
	return FAppStyle::GetBrush("DebugConsole.Icon");
}

TSharedRef<ISequencerSection> FMovieSceneQTETrackEditor::MakeSectionInterface(UMovieSceneSection& SectionObject,
	UMovieSceneTrack& Track,
	FGuid ObjectBinding)
{
	check(SupportsType(SectionObject.GetOuter()->GetClass()));
	return MakeShareable(new FMovieSceneQTESection(SectionObject, GetSequencer()));
}

bool FMovieSceneQTETrackEditor::SupportsType(TSubclassOf<UMovieSceneTrack> Type) const
{
	return Type == UMovieSceneQTETrack::StaticClass();
}

bool FMovieSceneQTETrackEditor::SupportsSequence(UMovieSceneSequence* InSequence) const
{
	return InSequence->IsA(ULevelSequence::StaticClass());
}

bool FMovieSceneQTETrackEditor::IsResizable(UMovieSceneTrack* InTrack) const
{
	return false;
}

bool FMovieSceneQTETrackEditor::OnAllowDrop(const FDragDropEvent& DragDropEvent,
	FSequencerDragDropParams& DragDropParams)
{
	return false;
}

FReply FMovieSceneQTETrackEditor::OnDrop(const FDragDropEvent& DragDropEvent,
	const FSequencerDragDropParams& DragDropParams)
{
	return FReply::Handled();
}

void FMovieSceneQTETrackEditor::BuildAddTrackMenu(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.AddMenuEntry(
		LOCTEXT("AddQTETrack", "QTETrack"),
		LOCTEXT("AddQTETrackTooltip", "Adds a QTE track."),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateLambda([=,this]
			{
				auto FocusedMovieScene = GetFocusedMovieScene();

	if (FocusedMovieScene == nullptr)
	{
		return;
	}

	const FScopedTransaction Transaction(LOCTEXT("AddQTETrack_Transaction", "Add QTE Track"));
	FocusedMovieScene->Modify();

	auto NewTrack = FocusedMovieScene->AddTrack<UMovieSceneQTETrack>();
	ensure(NewTrack);
	//NewTrack->SetIsAMasterTrack(true);

	GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
			}))
	);
}

void FMovieSceneQTETrackEditor::BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder,
	const TArray<FGuid>& ObjectBindings,
	const UClass* ObjectClass)
{
	if (ObjectClass != nullptr && ObjectClass->IsChildOf(AActor::StaticClass()))
	{
	}
	return;
}

void FMovieSceneQTETrackEditor::HandleAddTrackOnActorMenuEntryExecute(FMenuBuilder& MenuBuilder,
	TArray<FGuid> ObjectBindings)
{
}


FMovieSceneQTESection::FMovieSceneQTESection(UMovieSceneSection& InSection,
	TWeakPtr<ISequencer> InSequencer)
	: Section(&InSection)
	, Sequencer(InSequencer)
{
	if (UMovieSceneQTESection* MovieSceneQTESection = Cast<UMovieSceneQTESection>(Section))
	{
		MovieSceneQTESection->OnQTESectionPostEditChangePropertyDelegate.BindRaw(this, &FMovieSceneQTESection::OnQTESectionPostEditChangeProperty);
	}
	
}

FMovieSceneQTESection::~FMovieSceneQTESection()
{
}

UMovieSceneSection* FMovieSceneQTESection::GetSectionObject()
{
	return Section.Get();
}

FText FMovieSceneQTESection::GetSectionTitle() const
{
	return FText::FromString("QTE Section");
}

FText FMovieSceneQTESection::GetSectionToolTip() const
{
	return FText::FromString("QTE Section");
}

float FMovieSceneQTESection::GetSectionHeight() const
{
	return 40;
}

int32 FMovieSceneQTESection::OnPaintSection(FSequencerSectionPainter& Painter) const
{
	return Painter.PaintSectionBackground();
}


void FMovieSceneQTESection::BeginResizeSection()
{
}

void FMovieSceneQTESection::ResizeSection(ESequencerSectionResizeMode ResizeMode,
	FFrameNumber ResizeTime)
{
	ISequencerSection::ResizeSection(ResizeMode, ResizeTime);
}

void FMovieSceneQTESection::GenerateSectionLayout(class ISectionLayoutBuilder& LayoutBuilder)
{
}

void FMovieSceneQTESection::BeginSlipSection()
{
}

void FMovieSceneQTESection::SlipSection(FFrameNumber SlipTime)
{
	ISequencerSection::SlipSection(SlipTime);
}

void FMovieSceneQTESection::OnQTESectionPostEditChangeProperty()
{
	if (UMovieSceneQTESection* MovieSceneQTESection = Cast<UMovieSceneQTESection>(Section))
	{
		UBSQTEData* QTEData = MovieSceneQTESection->QTEData;
		if (QTEData)
		{
			TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());
			UKGCoreEditorFunctionLibrary::ExportObjectToJson(QTEData, JsonObject);
			FString FileWriteData;
			TSharedPtr<TJsonWriter<TCHAR>> JsonWriter;

			JsonWriter = TJsonWriterFactory<TCHAR>::Create(&FileWriteData);
			FJsonSerializer::Serialize(JsonObject.ToSharedRef(), *JsonWriter);
			MovieSceneQTESection->QTEDataString = FileWriteData;
		}
		else
		{
			MovieSceneQTESection->QTEDataString = TEXT("");
		}
	}
	
}

#undef LOCTEXT_NAMESPACE
