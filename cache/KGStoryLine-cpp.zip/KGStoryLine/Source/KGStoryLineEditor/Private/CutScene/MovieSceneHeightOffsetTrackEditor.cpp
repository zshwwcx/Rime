#include "CutScene/MovieSceneHeightOffsetTrackEditor.h"

#include "BonePose.h"
#include "3C/Character/BaseCharacter.h"
#include "CutScene/Utils/FCutsceneEditorUtils.h"
#include "ISequencerModule.h"
#include "LevelSequence.h"
#include "CutScene/MovieSceneHeightOffsetTrack.h"
#include "CutScene/MovieSceneLookAtTrack.h"
#include "SSearchableComboBox.h"
#include "Widgets/Input/STextComboBox.h"
#include "Widgets/Input/SVectorInputBox.h"
#include "Components/SkeletalMeshComponent.h"
#include "Runtime/AvatarCreatorFunctionLibrary.h"
#include "Runtime/FaceControlComponent.h"
#include "Sections/MovieSceneSubSection.h"
#include "Tracks/MovieSceneSkeletalAnimationTrack.h"
#include "Tracks/MovieSceneSubTrack.h"
#include "3C/Util/KGUtils.h"
#include "Widgets/Input/SButton.h"

#define LOCTEXT_NAMESPACE "MovieSceneHeightOffsetTrackEditor"

bool FMovieSceneHeightOffsetTrackEditor::SupportsType(TSubclassOf<UMovieSceneTrack> TrackClass) const
{
	return TrackClass == UMovieSceneHeightOffsetTrack::StaticClass();
}

bool FMovieSceneHeightOffsetTrackEditor::SupportsSequence(UMovieSceneSequence* InSequence) const
{
	return InSequence && InSequence->IsA(ULevelSequence::StaticClass());
}

void FMovieSceneHeightOffsetTrackEditor::BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	if (ObjectClass == nullptr)
		return;
	if (ObjectBindings.Num() == 0)
		return;
	FGuid ObjectBinding = ObjectBindings[0];
	MenuBuilder.AddMenuEntry(
		NSLOCTEXT("Sequencer", "AddHeightOffsetTrack", "高度偏移"),
		NSLOCTEXT("Sequencer", "AddHeightOffsetTooltip", "添加高度偏移轨道, 用于根据玩家捏角色身高动态调整绑定对象的高度."),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateLambda([this, ObjectBinding = MoveTemp(ObjectBinding)]
		{
			UMovieScene* FocusedMovieScene = GetFocusedMovieScene();
			const TSharedPtr<ISequencer> Sequencer = GetSequencer();
			if (FocusedMovieScene == nullptr || !Sequencer)
				return;
		
			FMovieSceneBinding* MovieSceneBinding = FocusedMovieScene->FindBinding(ObjectBinding);
			if (!ensure(MovieSceneBinding))
				return;

			const FScopedTransaction Transaction(LOCTEXT("AddHeightOffsetTrack_Transaction", "Add Height Offset Track"));
			FocusedMovieScene->Modify();

			UMovieSceneHeightOffsetTrack* NewTrack = FocusedMovieScene->AddTrack<UMovieSceneHeightOffsetTrack>(ObjectBinding);
			ensure(NewTrack);

			UMovieSceneSection* NewSection = NewTrack->CreateNewSection();
			NewTrack->AddSection(*NewSection);
		
			FFrameNumber PlaybackEnd = UE::MovieScene::DiscreteExclusiveUpper(FocusedMovieScene->GetPlaybackRange());
			FFrameRate FrameResolution = FocusedMovieScene->GetTickResolution();
			FFrameNumber SpawnSectionStartTime = Sequencer->GetLocalTime().ConvertTo(FrameResolution).RoundToFrame();
			FFrameTime SpawnSectionDuration = FrameResolution.AsFrameTime(5.0);
			FFrameNumber SpawnSectionEndTime = (SpawnSectionStartTime + SpawnSectionDuration).RoundToFrame();
			if (SpawnSectionEndTime > PlaybackEnd && SpawnSectionStartTime < PlaybackEnd)
				SpawnSectionEndTime = PlaybackEnd;
			NewSection->SetRange(TRange<FFrameNumber>(SpawnSectionStartTime, SpawnSectionEndTime));

			Sequencer->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
		}))
	);
}

TSharedPtr<SWidget> FMovieSceneHeightOffsetTrackEditor::BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params)
{
	return FMovieSceneTrackEditor::BuildOutlinerEditWidget(ObjectBinding, Track, Params);
}

TSharedRef<ISequencerSection> FMovieSceneHeightOffsetTrackEditor::MakeSectionInterface(UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding)
{
	return MakeShared<FHeightOffsetSection>(GetSequencer(), SectionObject);
}

FHeightOffsetSection::FHeightOffsetSection(const TSharedPtr<ISequencer>& InSequencer, UMovieSceneSection& InSection)
	: FSequencerSection(InSection)
	, WeakSequencer(InSequencer)
	, CurrentActorIndex(0)
	, CurrentBoneIndex1(0)
	, CurrentBoneIndex2(0)
{
	UpdateCandidates();
}

void FHeightOffsetSection::OnHeightOffsetActorChanged(TSharedPtr<FString> String, ESelectInfo::Type Arg)
{
	if (!WeakSection.IsValid() || !WeakSequencer.IsValid())
		return;

	CurrentActorIndex = CandidateObjectNames.IndexOfByPredicate([&String](const TSharedPtr<FString>& Name) { return String->Equals(*Name); });
	if (CurrentActorIndex == INDEX_NONE)
	{
		CurrentActorIndex = 0;
		UpdateCandidates();
		return;
	}

	if (UMovieSceneHeightOffsetSection* Section = Cast<UMovieSceneHeightOffsetSection>(WeakSection.Get()))
	{
		Section->ObjectBindingId = CandidateObjectBindings[CurrentActorIndex];
		// WeakSequencer.Pin()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemsChanged);
	}
	
	UpdateCandidates();
}

void FHeightOffsetSection::RefreshCandidateBones(const TWeakObjectPtr<AActor> InActor)
{
	TArray<TSharedPtr<FString>>& Names = CandidateBoneNames;
	Names.Empty();
	Names.Add(MakeShared<FString>(TEXT("root")));
	if (InActor.IsValid())
	{
		USkeletalMeshComponent* SkeletalMeshComponent = InActor->GetComponentByClass<USkeletalMeshComponent>();
		if (SkeletalMeshComponent && SkeletalMeshComponent->GetSkeletalMeshAsset())
		{
			FReferenceSkeleton ReferenceSkeleton = SkeletalMeshComponent->GetSkeletalMeshAsset()->GetRefSkeleton();
			for (int32 BoneIndex = 0; BoneIndex < ReferenceSkeleton.GetNum(); BoneIndex++)
			{
				FString BoneName = ReferenceSkeleton.GetBoneName(BoneIndex).ToString();
				Names.Add(MakeShared<FString>(BoneName));
			}
		}
	}

	UE_LOG(LogTemp, Log, TEXT("RefreshCandidateBones: %d"), Names.Num());
}

TSharedRef<SWidget> FHeightOffsetSection::MakeWidgetFromString(TSharedPtr<FString> InString)
{
	return SNew(STextBlock)
		.Text(FText::FromString(*InString));
}

FText FHeightOffsetSection::GetCurrentBoneName(const bool bUpper) const
{
	return FText::FromString(*CandidateBoneNames[bUpper ? CurrentBoneIndex1 : CurrentBoneIndex2]);
}

FText FHeightOffsetSection::GetCurrentActorName() const
{
	return FText::FromString(*CandidateObjectNames[CurrentActorIndex]);
}

void FHeightOffsetSection::OnBoneChanged(TSharedPtr<FString> String, ESelectInfo::Type Arg, const bool bUpper)
{
	if (!WeakSection.IsValid() || !WeakSequencer.IsValid())
		return;

	int32& BoneIndex = bUpper ? CurrentBoneIndex1 : CurrentBoneIndex2;
	BoneIndex = CandidateBoneNames.IndexOfByPredicate([&String](const TSharedPtr<FString>& Name) { return String->Equals(*Name); });
	if (BoneIndex == INDEX_NONE)
		BoneIndex = 0;

	UMovieSceneHeightOffsetSection* MovieSceneHeightOffsetSection = Cast<UMovieSceneHeightOffsetSection>(WeakSection);
	if (ensure(MovieSceneHeightOffsetSection != nullptr))
	{
		FString& BoneName = bUpper ? MovieSceneHeightOffsetSection->UpperBone : MovieSceneHeightOffsetSection->LowerBone;
		BoneName = *CandidateBoneNames[BoneIndex];
		RefreshBoneHeight();
		WeakSequencer.Pin()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemsChanged);
	}
}

void FHeightOffsetSection::ForeachSubMovieScene(const UMovieScene* MovieScene, const TFunction<void(UMovieScene*)>& InFunction)
{
	for (UMovieSceneTrack* Track : MovieScene->GetTracks())
	{
		if (UMovieSceneSubTrack* SubTrack = Cast<UMovieSceneSubTrack>(Track))
		{
			for (UMovieSceneSection* OneSection : SubTrack->GetAllSections())
			{
				if (const UMovieSceneSubSection* SubSection = Cast<UMovieSceneSubSection>(OneSection))
				{
					if (UMovieSceneSequence* SubSeq = SubSection->GetSequence())
					{
						if (UMovieScene* SubMovieScene = SubSeq->GetMovieScene())
						{
							InFunction(SubMovieScene);
						}
					}
				}
			}
		}
	}
}

void FHeightOffsetSection::RefreshBoneHeight()
{
	if (!WeakSection.IsValid() || !WeakSequencer.IsValid())
		return;

	UMovieSceneHeightOffsetSection* Section = Cast<UMovieSceneHeightOffsetSection>(this->WeakSection.Get());
	if (!Section)
		return;

	const ULevelSequence* LevelSequence = Section->GetTypedOuter<ULevelSequence>();
	if (!LevelSequence) return;
	
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (!MovieScene) return;
	
	const TSharedPtr<ISequencer> Sequencer = WeakSequencer.Pin();
	FMovieSceneSequenceID SequenceID = Sequencer->GetFocusedTemplateID();
	FMovieSceneBinding* Binding = MovieScene->FindBinding(Section->ObjectBindingId);
	if (!Binding)
	{
		ForeachSubMovieScene(MovieScene, [&Sequencer, &SequenceID, &Binding, &Section](UMovieScene* SubMovieScene)
		{
			if (FMovieSceneBinding* SubBinding = SubMovieScene->FindBinding(Section->ObjectBindingId))
			{
				Binding = SubBinding;
				SequenceID = Sequencer->State.FindSequenceId(SubMovieScene->GetTypedOuter<UMovieSceneSequence>());
			}
		});
		if (!Binding)
			return;
	}

	TArrayView<TWeakObjectPtr<>> WeakObjectPtrs = Sequencer->FindBoundObjects(Section->ObjectBindingId, SequenceID); // 正常只有一个
	if (WeakObjectPtrs.Num() == 0) return;

	ACharacter* Character = Cast<ACharacter>(WeakObjectPtrs[0].Get());
	if (!Character) return;

	USkeletalMeshComponent* SkeletalMeshComponent = Character->GetMesh();
	UFaceControlComponent* FaceControlComponent = Character->GetComponentByClass<UFaceControlComponent>();
	if (!FaceControlComponent || !SkeletalMeshComponent) return;
	FaceControlComponent->CalcHeightData(FaceControlComponent->PresetProfileName, FName(Section->UpperBone), FName(Section->LowerBone));

	Section->InitHeight = FaceControlComponent->GetCurHeight();

	Section->SampleHeights.Reset();

	if (Section->bUseContinuedHeights)
	{
		const TRange<FFrameNumber> Range = Section->GetTrueRange();
		const FFrameNumber SectionStart = Range.GetLowerBoundValue();
		const FFrameNumber SectionEnd = Range.GetUpperBoundValue();
		FFrameRate TickResolution = MovieScene->GetTickResolution();
		const float StartSecond = TickResolution.AsSeconds(SectionStart);
		const float EndSecond = TickResolution.AsSeconds(SectionEnd);

		TArray<float>& SampleHeights = Section->SampleHeights;
	
		SampleHeights.Reserve(static_cast<int32>((EndSecond - StartSecond) / Section->SampleRate));
		for (float CurrentSecond = StartSecond; CurrentSecond <= EndSecond; CurrentSecond += Section->SampleRate)
		{
			Sequencer->SetLocalTime(TickResolution.AsFrameTime(CurrentSecond));
			Character->Tick(0.f);
			SkeletalMeshComponent->TickComponent(0.f, ELevelTick::LEVELTICK_All, nullptr);
			float DeltaHeight = UAvatarCreatorFunctionLibrary::CalcBoneHeight(
				KGUtils::GetIDByObject(SkeletalMeshComponent), FName(Section->UpperBone), FName(Section->LowerBone));
			SampleHeights.Add(DeltaHeight);
		}
	}
}

TOptional<float> FHeightOffsetSection::GetHeightOffset() const
{
	if (!WeakSection.IsValid())
		return 0;

	UMovieSceneHeightOffsetSection* Section = Cast<UMovieSceneHeightOffsetSection>(this->WeakSection.Get());
	if (!Section)
		return 0;

	return Section->InitHeight;
}

void FHeightOffsetSection::OnHeightOffsetChanged(const float X) const
{
	if (!WeakSection.IsValid())
		return;
	
	UMovieSceneHeightOffsetSection* Section = Cast<UMovieSceneHeightOffsetSection>(this->WeakSection.Get());
	if (!Section)
		return;

	Section->InitHeight = X;
}

void FHeightOffsetSection::UpdateCandidates()
{
	if (!WeakSection.IsValid() || !WeakSequencer.IsValid())
		return;

	TSharedPtr<ISequencer> Sequencer = WeakSequencer.Pin();
	UMovieSceneHeightOffsetSection* Section = Cast<UMovieSceneHeightOffsetSection>(this->WeakSection.Get());
	if (!ensure(Section != nullptr))
		return;
	
	CurrentActorIndex = 0;
	TargetActor = nullptr;
	CandidateObjectNames.Empty();
	CandidateObjectBindings.Empty();
	CandidateObjectNames.Add(MakeShared<FString>(TEXT("None")));
	CandidateObjectBindings.Add(FGuid());
	ULevelSequence* LevelSequence = Section->GetTypedOuter<ULevelSequence>();
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();

	if (ensure(LevelSequence && MovieScene))
	{
		// const TArray<FMovieSceneBinding>& Bindings = MovieScene->GetBindings();
		// for (const FMovieSceneBinding& Binding : Bindings)
		// {
		// 	FGuid ObjectBindingID = Binding.GetObjectGuid();
		//
		// 	FMovieSceneSequenceID SequenceID = Sequencer->GetFocusedTemplateID();
		// 	TArrayView<TWeakObjectPtr<>> WeakObjectPtrs = Sequencer->FindBoundObjects(ObjectBindingID, SequenceID);
		// 	for (auto BoundObject : WeakObjectPtrs)
		// 	{
		// 		if (BoundObject.IsValid() && BoundObject->IsA(AActor::StaticClass()))
		// 		{
		// 			AActor* Actor = Cast<AActor>(BoundObject.Get());
		// 			CandidateObjectNames.Add(MakeShared<FString>(Actor->GetActorLabel()));
		// 			CandidateObjectBindings.Add(ObjectBindingID);
		// 			if (ObjectBindingID == Section->ObjectBindingId)
		// 			{
		// 				CurrentActorIndex = CandidateObjectNames.Num() - 1;
		// 				TargetActor = Actor;
		// 			}
		// 		}
		// 	}
		// }

		FMovieSceneSequenceID SequenceID = Sequencer->GetFocusedTemplateID();
		TArray<UMovieScene*> MovieScenes;
		TArray<FMovieSceneSequenceID> SequenceIDs;
		MovieScenes.Add(MovieScene);
		SequenceIDs.Add(SequenceID);
		
		// 遍历所有轨道
		for (UMovieSceneTrack* Track : MovieScene->GetTracks())
		{
			if (UMovieSceneSubTrack* SubTrack = Cast<UMovieSceneSubTrack>(Track))
			{
				// 遍历 Sub Track 里的 Section
				for (UMovieSceneSection* OneSection : SubTrack->GetAllSections())
				{
					if (const UMovieSceneSubSection* SubSection = Cast<UMovieSceneSubSection>(OneSection))
					{
						if (UMovieSceneSequence* SubSeq = SubSection->GetSequence())
						{
							if (const ULevelSequence* SubLevelSeq = Cast<ULevelSequence>(SubSeq))
							{
								MovieScenes.Add(SubLevelSeq->GetMovieScene());
								SequenceIDs.Add(Sequencer->State.FindSequenceId(SubLevelSeq));
							}
						}
					}
				}
			}
		}

		for (int i = 0; i < MovieScenes.Num(); ++i)
		{
			UMovieScene* CurrentMovieScene = MovieScenes[i];
			const TArray<FMovieSceneBinding>& OtherBindings = CurrentMovieScene->GetBindings();
			for (const FMovieSceneBinding& Binding : OtherBindings)
			{
				FGuid ObjectBindingID = Binding.GetObjectGuid();

				TArrayView<TWeakObjectPtr<>> WeakObjectPtrs = Sequencer->FindBoundObjects(ObjectBindingID, SequenceIDs[i]);
				for (auto BoundObject : WeakObjectPtrs)
				{
					if (BoundObject.IsValid() && BoundObject->IsA(AActor::StaticClass()))
					{
						AActor* Actor = Cast<AActor>(BoundObject.Get());
						CandidateObjectNames.Add(MakeShared<FString>(Actor->GetActorLabel()));
						CandidateObjectBindings.Add(ObjectBindingID);
						if (ObjectBindingID == Section->ObjectBindingId)
						{
							CurrentActorIndex = CandidateObjectNames.Num() - 1;
							TargetActor = Actor;
						}
					}
				}
			}
		}
		
	}

	RefreshCandidateBones(TargetActor);
	CurrentBoneIndex1 = CandidateBoneNames.IndexOfByPredicate([&Section](const TSharedPtr<FString>& InBoneName) {return InBoneName->Equals(Section->UpperBone); });
	if (CurrentBoneIndex1 == INDEX_NONE)
		CurrentBoneIndex1 = 0;
	CurrentBoneIndex2 = CandidateBoneNames.IndexOfByPredicate([&Section](const TSharedPtr<FString>& InBoneName) {return InBoneName->Equals(Section->LowerBone); });
	if (CurrentBoneIndex2 == INDEX_NONE)
		CurrentBoneIndex2 = 0;

	if (BoneBox1)
		BoneBox1->RefreshOptions();
	if (BoneBox2)
		BoneBox2->RefreshOptions();
}

void FHeightOffsetSection::BuildEditHeightOffsetSubMenu(FMenuBuilder& MenuBuilder)
{
	UpdateCandidates();
	
	MenuBuilder.BeginSection(TEXT("HeightOffset Settings"), LOCTEXT("HeightOffset Settings", "高度偏移设置"));
	MenuBuilder.AddWidget(
		SNew(SSearchableComboBox)
		.OptionsSource(&CandidateObjectNames)
		.InitiallySelectedItem(CandidateObjectNames[CurrentActorIndex])
		.OnSelectionChanged(this->AsShared(), &FHeightOffsetSection::OnHeightOffsetActorChanged)
		.OnGenerateWidget_Static(&FHeightOffsetSection::MakeWidgetFromString)
		[
			SNew(STextBlock)
				.Text(this->AsShared(), &FHeightOffsetSection::GetCurrentActorName)
		],
		LOCTEXT("HeightOffsetActorLabel1", "目标角色")
	);
	
	MenuBuilder.AddWidget(
		SAssignNew(BoneBox1, SSearchableComboBox)
		.OptionsSource(&CandidateBoneNames)
		.InitiallySelectedItem(CandidateBoneNames[CurrentBoneIndex1])
		.OnSelectionChanged(this->AsShared(), &FHeightOffsetSection::OnBoneChanged, true)
		.OnGenerateWidget_Static(&FHeightOffsetSection::MakeWidgetFromString)
		[
			SNew(STextBlock)
				.Text(this->AsShared(), &FHeightOffsetSection::GetCurrentBoneName, true)
		],
		LOCTEXT("HeightOffsetActorLabel2", "上骨骼")
	);
	
	MenuBuilder.AddWidget(
		SAssignNew(BoneBox2, SSearchableComboBox)
		.OptionsSource(&CandidateBoneNames)
		.InitiallySelectedItem(CandidateBoneNames[CurrentBoneIndex2])
		.OnSelectionChanged(this->AsShared(), &FHeightOffsetSection::OnBoneChanged, false)
		.OnGenerateWidget_Static(&FHeightOffsetSection::MakeWidgetFromString)
		[
			SNew(STextBlock)
				.Text(this->AsShared(), &FHeightOffsetSection::GetCurrentBoneName, false)
		],
		LOCTEXT("HeightOffsetActorLabel2", "下骨骼")
	);
	
	MenuBuilder.AddWidget(
		SNew(SNumericEntryBox<float>)
		.AllowSpin(false)
		.Value(this, &FHeightOffsetSection::GetHeightOffset)
		.OnValueChanged(this, &FHeightOffsetSection::OnHeightOffsetChanged),
		LOCTEXT("HeightOffsetActorLabel2", "高度差")
	);

	MenuBuilder.AddWidget(
		SNew(SButton)
		.Text(LOCTEXT("RefreshButtonLabel", "刷新"))
		.OnClicked_Lambda([this]()
		{
			RefreshBoneHeight();
			return FReply::Handled();
		}),
		LOCTEXT("RefreshButtonLabel", "刷新")
	);
	
	MenuBuilder.EndSection();
}

void FHeightOffsetSection::BuildSectionContextMenu(FMenuBuilder& MenuBuilder, const FGuid& ObjectBinding)
{
	MenuBuilder.AddSubMenu(
		LOCTEXT("HeightOffsetSettingsLabel", "高度偏移配置"),
		LOCTEXT("HeightOffsetPropertyTooltip", "Edit HeightOffset Property"),
		FNewMenuDelegate::CreateSP(this, &FHeightOffsetSection::BuildEditHeightOffsetSubMenu)
	);
}

FText FHeightOffsetSection::GetSectionText() const
{
	if (CandidateObjectNames.IsValidIndex(CurrentActorIndex) && CandidateBoneNames.IsValidIndex(CurrentBoneIndex1))
		return FText::FromString(FString::Printf(TEXT("%s\n%s"), **CandidateObjectNames[CurrentActorIndex], **CandidateBoneNames[CurrentBoneIndex1]));
	return FText::GetEmpty();
}

TSharedRef<SWidget> FHeightOffsetSection::GenerateSectionWidget()
{
	if (CandidateObjectNames.Num() == 1 && *CandidateObjectNames[0] == TEXT("None") ||
		!(CandidateObjectNames.IsValidIndex(CurrentActorIndex) && CandidateBoneNames.IsValidIndex(CurrentBoneIndex1)))
	{
		UpdateCandidates();
	}
	return SNew(STextBlock).Text(this, &FHeightOffsetSection::GetSectionText);
		
}

#undef LOCTEXT_NAMESPACE
