#include "CutScene/CustomSectionEditors/SChooseActorHelper.h"

#include "ISequencer.h"
#include "LevelSequence.h"
#include "MovieScene.h"
#include "MovieSceneBinding.h"
#include "SSearchableComboBox.h"


void SChooseActorHelper::Construct(const FArguments& InArgs, const TWeakPtr<ISequencer>& InSequencer, const FGuid InCurrentBindActorGuid)
{
	WeakSequencer = InSequencer;
	BindActorGuid = InCurrentBindActorGuid;
	OnGuidChanged = InArgs._OnGuidChanged;
	UpdateCandidates();
		
	TSharedRef<SSearchableComboBox> SearchableComboBox = SNew(SSearchableComboBox)
		.OptionsSource(&CandidateObjectNames)
		.InitiallySelectedItem(CandidateObjectNames[CurrentActorIndex])
		.OnSelectionChanged(this, &SChooseActorHelper::OnCurrentActorChanged)
		.OnGenerateWidget_Static(&SChooseActorHelper::MakeWidgetFromString)
		[
			SNew(STextBlock)
			.Text(this, &SChooseActorHelper::GetCurrentActorName)
		];

	ChildSlot
	[
		SearchableComboBox
	];
}

FText SChooseActorHelper::GetCurrentActorName() const
{
	if (CandidateObjectNames.IsValidIndex(CurrentActorIndex))
		return FText::FromString(*CandidateObjectNames[CurrentActorIndex]);
	return FText::FromString(TEXT("None"));
}

void SChooseActorHelper::OnCurrentActorChanged(TSharedPtr<FString> String, ESelectInfo::Type Arg)
{
	if (!WeakSequencer.IsValid())
		return;

	CurrentActorIndex = CandidateObjectNames.IndexOfByPredicate([&String](const TSharedPtr<FString>& Name) { return String->Equals(*Name); });
	if (CurrentActorIndex == INDEX_NONE)
	{
		CurrentActorIndex = 0;
	}

	if (CandidateObjectBindings.IsValidIndex(CurrentActorIndex) && CandidateObjectNames[CurrentActorIndex].IsValid())
	{
		BindActorGuid = CandidateObjectBindings[CurrentActorIndex];
		OnGuidChanged.ExecuteIfBound(CandidateObjectBindings[CurrentActorIndex], *CandidateObjectNames[CurrentActorIndex]);
	}
		
	UpdateCandidates();
}

TSharedRef<SWidget> SChooseActorHelper::MakeWidgetFromString(TSharedPtr<FString> InString)
{
	return SNew(STextBlock)
		.Text(FText::FromString(*InString));
}

void SChooseActorHelper::UpdateCandidates()
{
	if (!WeakSequencer.IsValid())
		return;

	TSharedPtr<ISequencer> Sequencer = WeakSequencer.Pin();
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(Sequencer->GetFocusedMovieSceneSequence());
	
	CurrentActorIndex = 0;
	CandidateObjectNames.Empty();
	CandidateObjectBindings.Empty();
	CandidateObjectNames.Add(MakeShared<FString>(TEXT("None")));
	CandidateObjectBindings.Add(FGuid());
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (ensure(LevelSequence && MovieScene))
	{
		const TArray<FMovieSceneBinding>& Bindings = MovieScene->GetBindings();
		for (const FMovieSceneBinding& Binding : Bindings)
		{
			FGuid ObjectBindingID = Binding.GetObjectGuid();

			FMovieSceneSequenceID SequenceID = Sequencer->GetFocusedTemplateID();
			TArrayView<TWeakObjectPtr<>> WeakObjectPtrs = Sequencer->FindBoundObjects(ObjectBindingID, SequenceID);
			for (auto BoundObject : WeakObjectPtrs)
			{
				if (BoundObject.IsValid() && BoundObject->IsA(AActor::StaticClass()))
				{
					AActor* Actor = Cast<AActor>(BoundObject.Get());
					CandidateObjectNames.Add(MakeShared<FString>(Actor->GetActorLabel()));
					CandidateObjectBindings.Add(ObjectBindingID);
					if (ObjectBindingID == BindActorGuid)
					{
						CurrentActorIndex = CandidateObjectNames.Num() - 1;
					}
				}
			}
		}
	}
}
