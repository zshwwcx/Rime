// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "Widgets/SCompoundWidget.h"

class ISequencer;
class IDetailsView;
class UMovieSceneCustomSection;

class SCustomSectionSetupPanel : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SCustomSectionSetupPanel) {}
		
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, UMovieSceneCustomSection* InCustomSection, TWeakPtr<ISequencer> InSequencer);
	void OnSave() const;

private:
	TWeakObjectPtr<UClass> CurrentClass;
	TWeakObjectPtr<UMovieSceneCustomSection> CustomSection;
	TSharedPtr<IDetailsView> DetailsView;
	TWeakPtr<ISequencer> WeakSequencer;

	void OnSelectClass(ECheckBoxState CheckBoxState, UClass* Class);
	ECheckBoxState IsClassChecked(UClass* Class) const;
	
	static TSortedMap<FString, UClass*> GetAllUMovieSceneCustomDataClasses();
	static FString GetClassName(const UClass* InClass);
};
