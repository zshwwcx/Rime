// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#pragma once

#include "CoreMinimal.h"
#include "CutScene/CustomSectionEditors/CustomSectionEditor.h"
#include "MayaLiveLinkSectionEditor.generated.h"

class SChooseActorHelper;
/**
 * 
 */
UCLASS()
class KGSTORYLINEEDITOR_API UMayaLiveLinkSectionEditor : public UCustomSectionEditor
{
	GENERATED_BODY()

public:
	virtual void Initialize(TWeakObjectPtr<UMovieSceneCustomSection>, TWeakPtr<ISequencer> InSequencer) override;
	virtual FName SupportCustomSectionName() const override;
	virtual EMethodType GetSupportedMethods() const override;
	virtual FText GetSectionTitle() const override;
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;
	
	FName GetCustomDataSubjectName(UObject* Data) const;
	void SetCustomDataSubjectName(UObject* Data, FName InName) const;
	void RefreshSubjectNames();
	
	FName CurrentNamePropertyName = "SubjectName";
	FName CurrentSubjectName;
	TArray<FName> Subjects;
};
