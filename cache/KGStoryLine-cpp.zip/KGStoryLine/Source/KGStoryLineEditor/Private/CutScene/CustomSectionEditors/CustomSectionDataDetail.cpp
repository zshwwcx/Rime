#include "CutScene/CustomSectionEditors/CustomSectionDataDetail.h"

#include "CutScene/CustomSectionEditors/CustomSectionEditor.h"
#include "DetailLayoutBuilder.h"
#include "CutScene/MovieSceneCustomSection.h"

TSharedRef<IDetailCustomization> FCustomSectionDataDetail::MakeInstance()
{
	return MakeShareable(new FCustomSectionDataDetail);
}

void FCustomSectionDataDetail::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	TArray<TWeakObjectPtr<UObject>> Objects;
	DetailBuilder.GetObjectsBeingCustomized(Objects);
	if (Objects.Num() != 1 || !Objects[0].IsValid())
		return;

	if (DetailBuilder.HasClassDefaultObject())
		return;

	DetailBuilder.HideCategory("Important");
	DetailBuilder.HideCategory("MovieSceneCustomData");
	
	if (const UMovieSceneCustomSection* CustomSection = Objects[0]->GetTypedOuter<UMovieSceneCustomSection>())
	{
		if (UCustomSectionEditor* CustomSectionEditor = UCustomSectionEditor::FindEditorInstanceForSection(CustomSection))
		{
			if (CustomSectionEditor->HasMethod(UCustomSectionEditor::EMethodType::Detail))
			{
				CustomSectionEditor->CustomizeDetails(DetailBuilder);
			}
		}
	}
}
