#include "CutScene/CustomSectionEditors/SCustomSectionSetupPanel.h"
#include "Widgets/Layout/SSplitter.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/SBoxPanel.h"
#include "PropertyEditorModule.h"
#include "IDetailsView.h"
#include "ISequencer.h"
#include "CutScene/MovieSceneCustomSection.h"
#include "CutScene/MovieSceneCustomTrackEditor.h"
#include "StoryLineEditorConfig.h"
#include "AssetRegistry/AssetData.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Engine/Blueprint.h"
#include "Modules/ModuleManager.h"
#include "MVVM/SectionModelStorageExtension.h"
#include "MVVM/ViewModels/SectionModel.h"
#include "MVVM/ViewModels/SequenceModel.h"
#include "MVVM/ViewModels/SequencerEditorViewModel.h"
#include "Styling/ToolBarStyle.h"
#include "Widgets/Layout/SSeparator.h"
#include "Widgets/Text/STextBlock.h"

void SCustomSectionSetupPanel::Construct(const FArguments& InArgs, UMovieSceneCustomSection* InCustomSection, TWeakPtr<ISequencer> InSequencer)
{
	if (!InCustomSection->IsValidLowLevel())
		return;
	
	FPropertyEditorModule& PropertyEditorModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	FDetailsViewArgs DetailsViewArgs;
	{
		DetailsViewArgs.bCustomFilterAreaLocation = true;
		DetailsViewArgs.bCustomNameAreaLocation = true;
		DetailsViewArgs.bHideSelectionTip = true;
		DetailsViewArgs.bSearchInitialKeyFocus = true;
		DetailsViewArgs.ColumnWidth = 0.45f;
	}

	DetailsView = PropertyEditorModule.CreateDetailView(DetailsViewArgs);
	DetailsView->SetObject(InCustomSection);
	CustomSection = InCustomSection;
	WeakSequencer = InSequencer;

	UStoryLineEditorConfig::Initialize();
	UStoryLineEditorConfig* Config = UStoryLineEditorConfig::Get(); // non-nullptr

	TSharedRef<SVerticalBox> Menus = SNew(SVerticalBox);
	TArray<FString> LatestSections = Config->GetLatestRecentlyUsedCustomSection();
	TSortedMap<FString, UClass*> Classes = GetAllUMovieSceneCustomDataClasses();
	
	const FToolBarStyle& ToolBarStyle = FAppStyle::Get().GetWidgetStyle<FToolBarStyle>("AssetEditorToolbar");
	auto AddClassToMenus = [&Menus, this, &ToolBarStyle](const FString& ClassName, UClass* DataClass)
	{
		Menus->AddSlot()
		.AutoHeight()
		.Padding(0.0f, 0.0f, 0.0f, 0.0f)
		[
			SNew(SCheckBox)
			.Style(&ToolBarStyle.ToggleButton)
			.OnCheckStateChanged(this, &SCustomSectionSetupPanel::OnSelectClass, DataClass)
			.IsChecked(this, &SCustomSectionSetupPanel::IsClassChecked, DataClass)
			.Content()
			[
				SNew(STextBlock)
				.Text(FText::FromString(ClassName))
			]
		];
	};
	
	for (int32 i = LatestSections.Num() - 1; i >= 0; i--)
	{
		FString ClassName = LatestSections[i];
		if (Classes.Contains(ClassName) && Classes[ClassName]->IsValidLowLevel())
		{
			AddClassToMenus(ClassName, Classes[ClassName]);
		}
		else
		{
			LatestSections.RemoveAt(i);
		}
	}

	if (LatestSections.Num() > 0)
	{
		// 分割线
		Menus->AddSlot()
		.AutoHeight()
		.Padding(2)
		[
			SNew(SSeparator)
			.Orientation(Orient_Horizontal)
			.Thickness(2.0f)
			.ColorAndOpacity(FLinearColor(0.4f, 0.4f, 0.4f))
		];
	}

	for (auto& Pair : Classes)
	{
		if (!LatestSections.Contains(Pair.Key) && Pair.Value->IsValidLowLevel())
		{
			AddClassToMenus(Pair.Key, Pair.Value);
		}
	}	
	
	ChildSlot
	[
		SNew(SSplitter)
		.Orientation(Orient_Horizontal)
		+ SSplitter::Slot()
		.Value(0.3f)
		[
			SNew(SScrollBox)
			+ SScrollBox::Slot()
			[
				Menus
			]
		]
		+ SSplitter::Slot()
		.Value(0.7f)
		[
			DetailsView.ToSharedRef()
		]
	];

	if (LatestSections.Num() > 0)
	{
		OnSelectClass(ECheckBoxState::Checked, Classes[LatestSections[0]]);
	}
}

void SCustomSectionSetupPanel::OnSave() const
{
	if (!CurrentClass.IsValid())
		return;
	
	UStoryLineEditorConfig::Initialize();
	UStoryLineEditorConfig* Config = UStoryLineEditorConfig::Get();
	Config->UpdateRecentlyUsedCustomSection(GetClassName(CurrentClass.Get()));
}

void SCustomSectionSetupPanel::OnSelectClass(ECheckBoxState CheckBoxState, UClass* Class)
{
	if (!Class->IsValidLowLevel() || !CustomSection.IsValid() || !WeakSequencer.IsValid())
		return;
	
	if (CurrentClass.IsValid() && CurrentClass == Class)
		return;

	if (CheckBoxState == ECheckBoxState::Checked)
	{
		CurrentClass = Class;
		CustomSection->CustomData = NewObject<UMovieSceneCustomData>(CustomSection.Get(), Class, NAME_None, RF_Transactional);
		CustomSection->Modify();

		using namespace UE::Sequencer;
		if (TSharedPtr<FSequencerEditorViewModel> EditorViewModel = WeakSequencer.Pin()->GetViewModel())
		{
			if (TViewModelPtr<FSequenceModel> SequenceModel = EditorViewModel->GetRootSequenceModel())
			{
				if (FSectionModelStorageExtension* SectionModelStorage = SequenceModel->CastDynamic<FSectionModelStorageExtension>())
				{
					if (TSharedPtr<FSectionModel> SectionModel = SectionModelStorage->FindModelForSection(CustomSection.Get()))
					{
						if (TSharedPtr<ISequencerSection> SectionInterface = SectionModel->GetSectionInterface())
						{
							TSharedPtr<FMovieSceneCustomSection> CustomSectionInterface = StaticCastSharedPtr<FMovieSceneCustomSection>(SectionInterface);
							CustomSectionInterface->CreateCustomEditor();
						}
					}
				}
			}
		}
		
		if (DetailsView)
		{
			DetailsView->SetObject(CustomSection->CustomData);
		}
	}
}

ECheckBoxState SCustomSectionSetupPanel::IsClassChecked(UClass* Class) const
{
	const bool bIsCurrent = CurrentClass.IsValid() && Class->IsValidLowLevel() && CurrentClass == Class;
	return bIsCurrent ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

TSortedMap<FString, UClass*> SCustomSectionSetupPanel::GetAllUMovieSceneCustomDataClasses()
{
	TArray<UClass*> DerivedClasses;

	FString BlueprintDir = TEXT("/Game/Blueprint/Cutscene");
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

	// 搜索目录下所有资产
	FARFilter Filter;
	Filter.PackagePaths.Add(*BlueprintDir);
	Filter.bRecursivePaths = true;
	Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());

	TArray<FAssetData> AssetDataList;
	AssetRegistry.GetAssets(Filter, AssetDataList);

	for (const FAssetData& AssetData : AssetDataList)
	{
		// 转成 UBlueprint
		UBlueprint* BP = Cast<UBlueprint>(AssetData.GetAsset());
		if (!BP || !BP->GeneratedClass) continue;

		UClass* BPClass = BP->GeneratedClass;

		if (BPClass->IsChildOf(UMovieSceneCustomData::StaticClass()))
		{
			DerivedClasses.Add(BPClass);
		}
	}

	DerivedClasses.Sort([](const UClass& A, const UClass& B) {
		return A.GetName() < B.GetName();
	});

	// 转成一个OrderedMap
	TSortedMap<FString, UClass*> OrderedMap;
	for (UClass* Class : DerivedClasses)
	{
		OrderedMap.Add(GetClassName(Class), Class);
	}
	
	return OrderedMap;
}

FString SCustomSectionSetupPanel::GetClassName(const UClass* InClass)
{
	if (!InClass || !InClass->IsChildOf(UMovieSceneCustomData::StaticClass()))
		return TEXT("");

	const UMovieSceneCustomData* Data = InClass->GetDefaultObject<UMovieSceneCustomData>();
	if (!Data->DisplayName.IsEmpty())
		return Data->DisplayName;
		
	if (!Data->ActionName.IsEmpty())
		return Data->ActionName;
	
	return InClass->GetName();
}
