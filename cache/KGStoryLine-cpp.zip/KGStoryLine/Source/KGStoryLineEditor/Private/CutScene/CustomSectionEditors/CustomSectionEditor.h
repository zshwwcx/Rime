// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "DetailLayoutBuilder.h"
#include "CutScene/MovieSceneCustomSection.h"
#include "UObject/Object.h"
#include "CustomSectionEditor.generated.h"

class UMovieSceneCustomSection;
class ISequencer;
class FMenuBuilder;
class SWidget;
class UMovieSceneSection;

/**
 * 基类：用于扩展 Custom Section 在编辑器中的表现
 */
UCLASS(Abstract)
class UCustomSectionEditor : public UObject
{
	GENERATED_BODY()

public:
	enum class EMethodType : uint8
	{
		None      = 0 UMETA(Hidden),
		Title     = 1 << 0,
		ToolTip   = 1 << 1,
		Height    = 1 << 2,
		Widget    = 1 << 3,
		Menu      = 1 << 4,
		PostEdit  = 1 << 5,
		Detail    = 1 << 6,
	};

	/** 初始化 */
	virtual void Initialize(TWeakObjectPtr<UMovieSceneCustomSection>, TWeakPtr<ISequencer> InSequencer);

	/** 注册的 CustomSection 类型 */
	virtual FName SupportCustomSectionName() const PURE_VIRTUAL(UCustomSectionEditor::SupportCustomSectionName, return NAME_None;)

	/** 支持的功能 */
	virtual EMethodType GetSupportedMethods() const PURE_VIRTUAL(UCustomSectionEditor::GetSupportedMethods, return EMethodType::None;)

	/** Section Title */
	virtual FText GetSectionTitle() const;

	/** Section ToolTip */
	virtual FText GetSectionToolTip() const;

	/** Section Height */
	virtual float GetSectionHeight() const;

	/** 自定义 Detail 面板 */
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder);
	
	/** 自定义编辑属性的 Widget */
	virtual TSharedRef<SWidget> GenerateSectionWidget();

	/** 自定义右键菜单 */
	virtual void BuildSectionContextMenu(FMenuBuilder& MenuBuilder, const FGuid& ObjectBinding);

	/** 编辑 Section 属性后调用 */
	virtual void OnPostEditChange();

	/** 检查是否有效 */
	virtual bool IsSectionValid() const;

	bool HasMethod(EMethodType Method);

	static UClass* GetEditorClassForSection(const UMovieSceneCustomSection* InSection);
	static UCustomSectionEditor* FindEditorInstanceForSection(const UMovieSceneCustomSection* InSection);
	static TWeakObjectPtr<UCustomSectionEditor> CreateEditorInstanceForSection(const UClass* InClass, TWeakObjectPtr<UMovieSceneCustomSection> InWeakSection, const TWeakPtr<ISequencer>& InWeakSequencer);
	static FName GetEditorNameForSection(const UMovieSceneCustomSection* InSection);

protected:
	/** Weak Custom Section */
	TWeakObjectPtr<UMovieSceneCustomSection> Section;

	/** Weak Sequencer */
	TWeakPtr<ISequencer> Sequencer;
	
private:
	EMethodType SupportedMethods;
	TMap<FName, TWeakObjectPtr<UClass>> ClassMap;
};
