// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"

class STextBlock;
class ISequencer;

/**
 * 方便选择Sequence里面的Actor
 * 有也选择Actor身上的骨骼的功能, 但是这里先不加, 后面用到再加
 */
class SChooseActorHelper final : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_TwoParams(FOnGuidChanged, FGuid, FString);
	
	SLATE_BEGIN_ARGS(SChooseActorHelper) {}
		SLATE_EVENT(FOnGuidChanged, OnGuidChanged)
	SLATE_END_ARGS()
	
	TWeakPtr<ISequencer> WeakSequencer;
	FGuid BindActorGuid;

	TArray<TSharedPtr<FString>> CandidateObjectNames;
	TArray<FGuid> CandidateObjectBindings;
	int32 CurrentActorIndex = 0;
	FOnGuidChanged OnGuidChanged;
	
	void Construct(const FArguments& InArgs, const TWeakPtr<ISequencer>& InSequencer, const FGuid InCurrentBindActorGuid);

	FText GetCurrentActorName() const;

	void OnCurrentActorChanged(TSharedPtr<FString> String, ESelectInfo::Type Arg);

	static TSharedRef<SWidget> MakeWidgetFromString(TSharedPtr<FString> InString);

	void UpdateCandidates();
};
