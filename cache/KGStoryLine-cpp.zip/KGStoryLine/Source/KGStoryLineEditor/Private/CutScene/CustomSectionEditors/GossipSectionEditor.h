// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CutScene/CustomSectionEditors/CustomSectionEditor.h"
#include "GossipSectionEditor.generated.h"

class SChooseActorHelper;
/**
 * 
 */
UCLASS()
class KGSTORYLINEEDITOR_API UGossipSectionEditor : public UCustomSectionEditor
{
	GENERATED_BODY()

public:
	virtual void Initialize(TWeakObjectPtr<UMovieSceneCustomSection>, TWeakPtr<ISequencer> InSequencer) override;
	virtual FName SupportCustomSectionName() const override;
	virtual EMethodType GetSupportedMethods() const override;
	virtual FText GetSectionTitle() const override;
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;
	FGuid GetCustomDataGuid(UObject* Data) const;
	void SetCustomDataGuid(UObject* Data, FGuid Guid) const;

private:
	FName BindActorPropertyName;
	FGuid BindActorGuid;
	FString BindActorName;
	TSharedPtr<SChooseActorHelper> ChooseActorHelper;

	void OnBindActorChanged(FGuid Guid, FString Name);
};
