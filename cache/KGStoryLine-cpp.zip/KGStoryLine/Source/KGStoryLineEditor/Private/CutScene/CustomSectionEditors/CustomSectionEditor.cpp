#include "CutScene/CustomSectionEditors/CustomSectionEditor.h"

#include "CutScene/MovieSceneCustomSection.h"

void UCustomSectionEditor::Initialize(const TWeakObjectPtr<UMovieSceneCustomSection> InSection, const TWeakPtr<ISequencer> InSequencer)
{
	Section = InSection;
	Sequencer = InSequencer;
	SupportedMethods = GetSupportedMethods();
}

FText UCustomSectionEditor::GetSectionTitle() const
{
	return FText::GetEmpty();
}

FText UCustomSectionEditor::GetSectionToolTip() const
{
	return FText::GetEmpty();
}

float UCustomSectionEditor::GetSectionHeight() const
{
	return 40.f;
}

void UCustomSectionEditor::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
}

TSharedRef<SWidget> UCustomSectionEditor::GenerateSectionWidget()
{
	return SNullWidget::NullWidget;
}

void UCustomSectionEditor::BuildSectionContextMenu(FMenuBuilder& MenuBuilder, const FGuid& ObjectBinding)
{
}

void UCustomSectionEditor::OnPostEditChange()
{
}

bool UCustomSectionEditor::IsSectionValid() const
{
	return Section.IsValid() && Sequencer.IsValid();
}

bool UCustomSectionEditor::HasMethod(EMethodType Method)
{
	return (static_cast<int32>(SupportedMethods) & static_cast<int32>(Method)) > 0;
}

UClass* UCustomSectionEditor::GetEditorClassForSection(const UMovieSceneCustomSection* InSection)
{
	UCustomSectionEditor* MutableDefault = GetMutableDefault<UCustomSectionEditor>();
	if (!MutableDefault || !InSection || !InSection->CustomData)
		return nullptr;

	TMap<FName, TWeakObjectPtr<UClass>>& ClassMap = MutableDefault->ClassMap;
	if (ClassMap.IsEmpty())
	{
		TArray<UClass*> DerivedClasses;
		GetDerivedClasses(StaticClass(), DerivedClasses);

		for (UClass* Class : DerivedClasses)
		{
			if (!Class->HasAnyClassFlags(CLASS_Abstract))
			{
				if (const UCustomSectionEditor* CustomSectionEditor = Class->GetDefaultObject<UCustomSectionEditor>())
				{
					FName SectionName = CustomSectionEditor->SupportCustomSectionName();
					ClassMap.Add(SectionName, Class);
				}
			}
		}
	}
	
	FName SectionEditorName = FName(InSection->CustomData->ActionName);
	if (ClassMap.Contains(SectionEditorName) && ClassMap[SectionEditorName].IsValid())
	{
		return ClassMap[SectionEditorName].Get();
	}

	return nullptr;
}

UCustomSectionEditor* UCustomSectionEditor::FindEditorInstanceForSection(const UMovieSceneCustomSection* InSection)
{
	if (!InSection->IsValidLowLevel())
		return nullptr;
		
	UCustomSectionEditor* Editor = FindObject<UCustomSectionEditor>((UObject*)GetTransientPackage(), *GetEditorNameForSection(InSection).ToString());
	if (!Editor->IsValidLowLevel())
		return nullptr;
	
	return Editor;
}

TWeakObjectPtr<UCustomSectionEditor> UCustomSectionEditor::CreateEditorInstanceForSection(const UClass* InClass, TWeakObjectPtr<UMovieSceneCustomSection> InWeakSection, const TWeakPtr<ISequencer>& InWeakSequencer)
{
	if (!InWeakSection.IsValid() || !InWeakSequencer.IsValid())
		return {};
	if (UCustomSectionEditor* ExistsEditor = FindEditorInstanceForSection(InWeakSection.Get()))
	{
		ExistsEditor->Initialize(InWeakSection, InWeakSequencer);
		return ExistsEditor;
	}
	UCustomSectionEditor* CustomEditor = NewObject<UCustomSectionEditor>((UObject*)GetTransientPackage(), InClass, GetEditorNameForSection(InWeakSection.Get()));
	CustomEditor->Initialize(InWeakSection, InWeakSequencer);
	return CustomEditor;
}

FName UCustomSectionEditor::GetEditorNameForSection(const UMovieSceneCustomSection* InSection)
{
	if (!ensure(InSection))
		return NAME_None;

	const uint32 UniqueID = InSection->GetUniqueID();
	return FName(FString::Printf(TEXT("CustomSectionEditor_%u"), UniqueID));
}

