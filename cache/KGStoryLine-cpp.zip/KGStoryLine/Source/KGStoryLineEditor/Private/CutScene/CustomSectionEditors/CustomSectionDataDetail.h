// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "CoreMinimal.h"
#include "IDetailCustomization.h"

class FCustomSectionDataDetail final : public IDetailCustomization
{
public:
	static TSharedRef<IDetailCustomization> MakeInstance();
	
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;
};
