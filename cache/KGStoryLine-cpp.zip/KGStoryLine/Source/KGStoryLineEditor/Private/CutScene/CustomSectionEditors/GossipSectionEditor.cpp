// Fill out your copyright notice in the Description page of Project Settings.


#include "CutScene/CustomSectionEditors/GossipSectionEditor.h"

#include "DetailCategoryBuilder.h"
#include "DetailWidgetRow.h"
#include "ISequencer.h"
#include "CutScene/MovieSceneCustomSection.h"
#include "CutScene/CustomSectionEditors/SChooseActorHelper.h"
#include "Widgets/Text/STextBlock.h"

void UGossipSectionEditor::Initialize(TWeakObjectPtr<UMovieSceneCustomSection> MovieSceneCustomSection, TWeakPtr<ISequencer> InSequencer)
{
	Super::Initialize(MovieSceneCustomSection, InSequencer);

	BindActorPropertyName = TEXT("BindActor");

	BindActorGuid = GetCustomDataGuid(Section->CustomData);
	ChooseActorHelper = SNew(SChooseActorHelper, Sequencer, BindActorGuid);	
}

FName UGossipSectionEditor::SupportCustomSectionName() const
{
	return TEXT("Gossip");
}

UCustomSectionEditor::EMethodType UGossipSectionEditor::GetSupportedMethods() const
{
	return static_cast<EMethodType>(
		static_cast<int32>(EMethodType::Detail) +
		static_cast<int32>(EMethodType::Title)
	);
}

FText UGossipSectionEditor::GetSectionTitle() const
{
	if (BindActorName.IsEmpty() && ChooseActorHelper.IsValid())
	{
		if (ChooseActorHelper->CurrentActorIndex == 0)
		{
			ChooseActorHelper->UpdateCandidates();
		}
		return FText::FromString("Gossip\n" + ChooseActorHelper->GetCurrentActorName().ToString());
	}
	return FText::FromString("Gossip\n" + BindActorName);
}

void UGossipSectionEditor::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	if (!Section.IsValid() || !Section->CustomData->IsValidLowLevel())
		return;

	BindActorGuid = GetCustomDataGuid(Section->CustomData);

	DetailBuilder.EditCategory("BindActor")
		.AddCustomRow(FText::FromString("BindActor"))
		.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString("BindActor"))
		]
		.ValueContent()
		[
			SAssignNew(ChooseActorHelper, SChooseActorHelper, Sequencer, BindActorGuid)
			.OnGuidChanged_UObject(this, &UGossipSectionEditor::OnBindActorChanged)
		];
}

FGuid UGossipSectionEditor::GetCustomDataGuid(UObject* Data) const
{
	if (!Section.IsValid() || !Section->CustomData->IsValidLowLevel())
		return {};
	
	if (!Data || !Data->GetClass())
		return {};
	
	FProperty* Property = Data->GetClass()->FindPropertyByName(BindActorPropertyName);

	if (Property && Property->IsA<FStructProperty>())
	{
		FStructProperty* StructProperty = CastField<FStructProperty>(Property);
		if (StructProperty->Struct == TBaseStructure<FGuid>::Get())
		{
			return *StructProperty->ContainerPtrToValuePtr<FGuid>(Data);
		}
	}

	return {};
}

void UGossipSectionEditor::SetCustomDataGuid(UObject* Data, const FGuid Guid) const
{
	if (!Data || !Data->GetClass())
		return;
	
	FProperty* Property = Data->GetClass()->FindPropertyByName(BindActorPropertyName);

	if (Property && Property->IsA<FStructProperty>())
	{
		FStructProperty* StructProperty = CastField<FStructProperty>(Property);
		if (StructProperty->Struct == TBaseStructure<FGuid>::Get())
		{
			StructProperty->SetValue_InContainer(Data, &Guid);
		}
	}
}

void UGossipSectionEditor::OnBindActorChanged(const FGuid Guid, FString Name)
{
	if (!IsSectionValid())
		return;

	if (!Section->CustomData->IsValidLowLevel())
		return;
	
	SetCustomDataGuid(Section->CustomData, Guid);
	BindActorName = Name;
	Section->Modify();
}
