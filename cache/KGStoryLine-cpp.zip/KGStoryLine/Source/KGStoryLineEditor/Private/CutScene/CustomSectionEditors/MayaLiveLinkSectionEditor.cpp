// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#include "CutScene/CustomSectionEditors/MayaLiveLinkSectionEditor.h"

#include "DetailCategoryBuilder.h"
#include "DetailWidgetRow.h"
#include "ILiveLinkClient.h"
#include "ISequencer.h"
#include "CutScene/MovieSceneCustomSection.h"
#include "CutScene/Utils/CutSceneEditorFunctionLibrary.h"
#include "CutScene/Utils/FCutsceneEditorUtils.h"
#include "Features/IModularFeatures.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SComboBox.h"

void UMayaLiveLinkSectionEditor::Initialize(TWeakObjectPtr<UMovieSceneCustomSection> MovieSceneCustomSection, TWeakPtr<ISequencer> InSequencer)
{
	Super::Initialize(MovieSceneCustomSection, InSequencer);
	
	UCutSceneEditorFunctionLibrary::OpenUDPTransform();
	if (!UCutSceneEditorFunctionLibrary::IsMayaLiveLinkConnected())
	{
		UCutSceneEditorFunctionLibrary::InitializeMayaLiveLink();
		if (!UCutSceneEditorFunctionLibrary::IsMayaLiveLinkConnected())
		{
			CurrentSubjectName = TEXT("Not Connected");
		}
	}
}

FName UMayaLiveLinkSectionEditor::SupportCustomSectionName() const
{
	return TEXT("MayaLiveLink");
}

UCustomSectionEditor::EMethodType UMayaLiveLinkSectionEditor::GetSupportedMethods() const
{
	return static_cast<EMethodType>(
		static_cast<int32>(EMethodType::Detail) +
		static_cast<int32>(EMethodType::Title)
	);
}

FText UMayaLiveLinkSectionEditor::GetSectionTitle() const
{
	return FText::FromString("MayaLiveLink\n" + CurrentSubjectName.ToString());
}

void UMayaLiveLinkSectionEditor::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	if (!Section.IsValid() || !Section->CustomData->IsValidLowLevel())
		return;
	
	if (!UCutSceneEditorFunctionLibrary::IsMayaLiveLinkConnected())
		UCutSceneEditorFunctionLibrary::InitializeMayaLiveLink();
	
	CurrentSubjectName = GetCustomDataSubjectName(Section->CustomData);
	RefreshSubjectNames();
	if (!Subjects.Contains(CurrentSubjectName))
	{
		CurrentSubjectName = NAME_None;
		if (Subjects.Num() == 0)
			CurrentSubjectName = TEXT("No Subjects Found");
	}
	
	for (int i = Subjects.Num() - 1; i >= 0; i--)
	{
		if (Subjects.Find(Subjects[i]) < i)
			Subjects.RemoveAt(i);
	}
	
	DetailBuilder.EditCategory(TEXT("Link对象"))
		.AddCustomRow(FText::FromString(TEXT("Link对象")))
		.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Link对象")))
		]
		.ValueContent()
		[
			SNew(SComboBox<FName>)
			.ContentPadding(2)
			.OptionsSource(&Subjects)
			.OnGenerateWidget_Lambda([](FName InName) { return SNew(STextBlock).Text(FText::FromName(InName)); })
			.OnSelectionChanged_Lambda([this](FName ChangedName, ESelectInfo::Type)
			{
				if (!Section.IsValid() || !Section->CustomData->IsValidLowLevel())
					return;
				CurrentSubjectName = ChangedName;
				SetCustomDataSubjectName(Section->CustomData, ChangedName);
				Section->Modify();
			})
			[
				SNew(STextBlock)
				.Text_Lambda([this]()
				{
					return FText::FromName(CurrentSubjectName);
				})
			]
		];
}

FName UMayaLiveLinkSectionEditor::GetCustomDataSubjectName(UObject* Data) const
{
	if (!Section.IsValid() || !Section->CustomData->IsValidLowLevel())
		return {};
	
	if (!Data || !Data->GetClass())
		return {};

	const FProperty* Property = Data->GetClass()->FindPropertyByName(CurrentNamePropertyName);
	if (Property && Property->IsA<FNameProperty>())
	{
		return *Property->ContainerPtrToValuePtr<FName>(Data);
	}

	return {};
}

void UMayaLiveLinkSectionEditor::SetCustomDataSubjectName(UObject* Data, const FName InName) const
{
	if (!Data || !Data->GetClass())
		return;

	const FProperty* Property = Data->GetClass()->FindPropertyByName(CurrentNamePropertyName);
	if (Property && Property->IsA<FNameProperty>())
	{
		Property->SetValue_InContainer(Data, &InName);
	}
}

void UMayaLiveLinkSectionEditor::RefreshSubjectNames()
{
	if (IModularFeatures::Get().IsModularFeatureAvailable(ILiveLinkClient::ModularFeatureName))
	{
		if (const ILiveLinkClient* Client = &IModularFeatures::Get().GetModularFeature<ILiveLinkClient>(ILiveLinkClient::ModularFeatureName))
		{
			Subjects.Reset();
			TArray<FLiveLinkSubjectKey> SubjectKeys = Client->GetSubjects(true, true);
			for (const FLiveLinkSubjectKey& Key : SubjectKeys)
			{
				Subjects.Add(Key.SubjectName);
			}
		}
		else
		{
			FCutsceneEditorUtils::CreateNotification(FText::FromString("LiveLink client not connected"), false);
		}
	}
	else
	{
		FCutsceneEditorUtils::CreateNotification(FText::FromString("LiveLink not available"), false);
	}
}
