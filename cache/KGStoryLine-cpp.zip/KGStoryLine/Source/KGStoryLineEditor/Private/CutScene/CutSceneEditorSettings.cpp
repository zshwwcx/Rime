// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#include "CutScene/CutSceneEditorSettings.h"
#include "UObject/Package.h"

UCutsceneEditorAssetSettings* UCutSceneEditorSettings::GetAssetSettingsChecked()
{
	const UCutSceneEditorSettings* CutsceneSettings = GetDefault<UCutSceneEditorSettings>();
	if (CutsceneSettings->AssetSettings.IsNull())
	{
		// Temp Code
		FString PackageName = TEXT("/Game/Editor/Settings/CutsceneSettings");
		UPackage* Package = CreatePackage(*PackageName);
		auto Settings = FindObject<UCutsceneEditorAssetSettings>(Package, TEXT("CutsceneSettings"));
		if (Settings == nullptr)
		{
			Settings = NewObject<UCutsceneEditorAssetSettings>(Package, UCutsceneEditorAssetSettings::StaticClass(), TEXT("CutsceneSettings"), RF_Public | RF_Standalone);
		}
		return Settings;
	}
	return CutsceneSettings->AssetSettings.LoadSynchronous();
}
