// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#include "CutScene/CutsceneCustomObjectBinding.h"

#include "CutScene/CutsceneEditorSettings.h"
#include "ISequencer.h"
#include "LevelSequence.h"
#include "SceneOutlinerModule.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Modules/ModuleManager.h"
#include "Editor.h"
#include "KGStoryLineEditorModule.h"
#include "MovieScene.h"
#include "CutScene/MovieSceneCustomTrack.h"
#include "PropertyCustomizationHelpers.h"
#include "Selection.h"
#include "SequencerUtilities.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Components/SplineComponent.h"
#include "Editor/Sequencer/Private/Sequencer.h"
#include "Engine/Blueprint.h"
#include "Engine/BlueprintGeneratedClass.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Notifications/SNotificationList.h"

#define LOCTEXT_NAMESPACE "CutsceneCustomObjectBinding"

FCutsceneCustomObjectBinding::FCutsceneCustomObjectBinding(const TSharedRef<ISequencer>& InSequencer)
	: Sequencer(InSequencer)
{
}

void FCutsceneCustomObjectBinding::BuildSequencerAddMenu(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.AddSubMenu(
		LOCTEXT("AddActor_Label", "Add Actor Blueprints"),
		LOCTEXT("AddActor_ToolTip", "Fast Add Blueprints to Sequencer"),
		FNewMenuDelegate::CreateRaw(this, &FCutsceneCustomObjectBinding::AddBlueprintsMenuExtensions),
		false /*bInOpenSubMenuOnClick*/,
		FSlateIcon("LevelSequenceEditorStyle", "LevelSequenceEditor.PossessNewActor")
		);
}

bool FCutsceneCustomObjectBinding::SupportsSequence(UMovieSceneSequence* InSequence) const
{
	return InSequence->GetClass() == ULevelSequence::StaticClass();
}

void FCutsceneCustomObjectBinding::AddBlueprintsMenuExtensions(FMenuBuilder& MenuBuilder)
{
	const UCutSceneEditorSettings* Settings = GetDefault<UCutSceneEditorSettings>();
	
	MenuBuilder.BeginSection(TEXT("With Tags"), LOCTEXT("TagActorsHeader", "Tag Actors"));
	for (const auto& Obj : Settings->CutsceneDynamicActors)
	{
		if (Obj.LoadSynchronous())
		{
			MenuBuilder.AddMenuEntry(
				FText::FromName(Obj->GetFName()),
				FText::GetEmpty(),
				FSlateIcon(),
				FExecuteAction::CreateRaw(this, &FCutsceneCustomObjectBinding::AddCutsceneDynamicActor, Obj.Get())
			);	
		}
	}
	MenuBuilder.EndSection();
	
	MenuBuilder.BeginSection(TEXT("Common Actors"), LOCTEXT("CommonActorsHeader", "Common Actors"));
	for (auto Obj : Settings->CommonCutsceneActors)
	{
		if (Obj.LoadSynchronous())
		{
			MenuBuilder.AddMenuEntry(FText::FromName(Obj->GetFName()), FText::GetEmpty(), FSlateIcon(),
				FExecuteAction::CreateRaw(this, &FCutsceneCustomObjectBinding::AddCommonActor, Cast<UObject>(Obj.Get())));	
		}
	}
	MenuBuilder.EndSection();

	InitializeLightTemplates();

	MenuBuilder.BeginSection(TEXT("Light Template"), LOCTEXT("LightTemplateHeader", "Light Template"));
	if (LightTemplates.Num() > 15)
	{
		MenuBuilder.AddSubMenu(
			LOCTEXT("AddLightTemplate_Label", "Add Light Template"),
			LOCTEXT("AddLightTemplate_ToolTip", "Fast Add Light Template to Sequencer"),
			FNewMenuDelegate::CreateRaw(this, &FCutsceneCustomObjectBinding::AddLightTemplateMenuExtensions),
			false /*bInOpenSubMenuOnClick*/,
			FSlateIcon("LevelSequenceEditorStyle", "LevelSequenceEditor.PossessNewActor")
			);
	}
	else
	{
		AddLightTemplateMenuExtensions(MenuBuilder);
	}
}

void FCutsceneCustomObjectBinding::AddLightTemplateMenuExtensions(FMenuBuilder& MenuBuilder)
{
	for (TWeakObjectPtr<UBlueprint> Obj : LightTemplates)
	{
		if (Obj.IsValid())
		{
			MenuBuilder.AddMenuEntry(
				FText::FromName(Obj->GetFName()),
				FText::GetEmpty(),
				FSlateIcon(),
				FExecuteAction::CreateRaw(this, &FCutsceneCustomObjectBinding::AddLightTemplate, Obj.Get())
			);	
		}
	}
}

void FCutsceneCustomObjectBinding::AddCutsceneDynamicActor(UBlueprint* Bp)
{
	// 整个窗口, 然后设置一些数据, 然后再添加 Spawnable
	TSharedRef<SWindow> Window = SNew(SWindow)
		.Title(LOCTEXT("AddCutsceneDynamicActorTitle", "Add CutsceneDynamicActor"))
		.SizingRule(ESizingRule::UserSized)
		.AutoCenter(EAutoCenter::PreferredWorkArea)
		.ClientSize(FVector2D(350, 400));

	InitFacadeControlIDs();
	// const UCutSceneEditorSettings* Settings = GetDefault<UCutSceneEditorSettings>();
	UObject* ActorBlueprint = Cast<UObject>(Bp);
	FString FacadeControlID = "";
	TArray<FString> OtherTags;
	bool bOkClicked = false;
	
	constexpr double LabelWidth = 0.5;
	Window->SetContent(
		SNew(SBorder)
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(3)
			[
				SNew(SHorizontalBox)

				+ SHorizontalBox::Slot()
				.FillWidth(LabelWidth)
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("ActorNameLabel", "Facade Control ID: "))
				]

				+ SHorizontalBox::Slot()
				[
					SNew(SEditableTextBox)
					.OnTextChanged_Lambda([&FacadeControlID](const FText& InText)
					{
						FacadeControlID = InText.ToString();
						if (FacadeControlID.Len() >= NAME_SIZE)
							FacadeControlID = FacadeControlID.Left(NAME_SIZE - 1);
					})
					.Text_Lambda([&FacadeControlID]()
					{
						return FText::FromString(FacadeControlID);
					})
				]
			]

			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("ErrorHintText", "Facade Control ID not Exist."))
				.ColorAndOpacity(FLinearColor::Yellow)
				.Visibility_Lambda([&FacadeControlID, this]()
				{
					const int32 ID = FCString::Atoi(*FacadeControlID);
					if (ID == 0 || FacadeControlIDs.Num() == 0 || FacadeControlIDs.Contains(ID))
					{
						return EVisibility::Collapsed;
					}
					return EVisibility::Visible;
				})
			]

			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(3)
			[
				SNew(SHorizontalBox)

				+ SHorizontalBox::Slot()
				.FillWidth(LabelWidth)
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("OtherTagsLabel", "Other Tags: "))
				]

				+ SHorizontalBox::Slot()
				[
					SNew(SEditableTextBox)
					.HintText(LOCTEXT("OtherTagsHintText", "ex. Model_123; Player; Man"))
					.Text_Lambda([&OtherTags]()
					{
						return FText::FromString(FString::Join(OtherTags, TEXT("; ")));
					})
					.OnTextCommitted_Lambda([&OtherTags](const FText& InText, ETextCommit::Type _)
					{
						InText.ToString().ParseIntoArray(OtherTags, TEXT(";"), true);
						for (FString& OtherTag : OtherTags)
						{
							if (OtherTag.Len() >= NAME_SIZE)
								OtherTag = OtherTag.Left(NAME_SIZE - 1);
						}
					})
				]
			]

			+SVerticalBox::Slot()
			
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(3)
			[
				SNew(SHorizontalBox)

				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				[
					SNew(SButton)
					.Text(LOCTEXT("AddButtonText", "Add"))
					.OnClicked_Lambda([&Window, &bOkClicked]()
					{
						bOkClicked = true;
						Window->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
			]
		]
	);

	// 阻塞
	GEditor->EditorAddModalWindow(Window);

	if (!bOkClicked)
		return;
	
	if (ActorBlueprint != nullptr && ensure(Sequencer.IsValid()))
	{
		const TSharedPtr<ISequencer> Seq = Sequencer.Pin();
		const FGuid NewGuid = AddSpawnable(*Seq, *ActorBlueprint, nullptr);
		const FMovieSceneSequenceID& FocusedTemplateID = Seq->GetFocusedTemplateID();
		UMovieSceneSequence* RootSequence = Seq->GetRootMovieSceneSequence();
		if (NewGuid.IsValid() && RootSequence)
		{
			if (UMovieScene* MovieScene = RootSequence->GetMovieScene())
			{
				if (!FacadeControlID.IsEmpty())
				{
					MovieScene->TagBinding(FName(FacadeControlID), UE::MovieScene::FFixedObjectBindingID(NewGuid, FocusedTemplateID));
				}
					
				for (const auto& OtherTag : OtherTags)
				{
					MovieScene->TagBinding(FName(OtherTag), UE::MovieScene::FFixedObjectBindingID(NewGuid, FocusedTemplateID));
				}
				FMovieSceneSpawnable* NewSpawnable = MovieScene->FindSpawnable(NewGuid);
				if(NewSpawnable)
				{
					UObject* TemplateObject = NewSpawnable->GetObjectTemplate();
					if(ActorBlueprint->GetName().Contains("BP_SequenceSpline"))
					{
						if(AActor* ActorBP = Cast<AActor>(TemplateObject))
						{
							if(!ActorBP->GetComponentByClass(USplineComponent::StaticClass()))
							{
								// 创建并附加新的 SplineComponent
								USplineComponent* SplineComp = NewObject<USplineComponent>(ActorBP, USplineComponent::StaticClass(), TEXT("SplineComponent"));
								SplineComp->SetupAttachment(ActorBP->GetRootComponent());
								ActorBP->AddInstanceComponent(SplineComp);
								SplineComp->RegisterComponent();
								Sequencer.Pin()->Save();
							}
						}
					}
				}
				CreateNotification(LOCTEXT("AddSpawnableSuccess", "Add Spawnable Success."), true);
				Seq->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
				MovieScene->Modify();
				return;
			}
		}
	}

	CreateNotification(LOCTEXT("AddSpawnableFail", "Add Spawnable Fail."), false);
}

void FCutsceneCustomObjectBinding::AddCommonActor(UObject* Obj) const
{
	if (!ensure(Obj) || !ensure(Sequencer.IsValid()))
		return;
	
	const TSharedPtr<ISequencer> Seq = Sequencer.Pin();
	UActorFactory* ActorFactory = GEditor->FindActorFactoryForActorClass(AActor::StaticClass());
	if (Obj->IsA<UBlueprintGeneratedClass>()) // Get Bp From BpClass
	{
		if (UObject* Bp = Cast<UBlueprintGeneratedClass>(Obj)->ClassGeneratedBy)
		{
			Obj = Bp;
		}
	}
	const FGuid NewGuid = AddSpawnable(*Seq, *Obj, ActorFactory);
	if (NewGuid.IsValid())
	{
		CreateNotification(LOCTEXT("AddSpawnableSuccess", "Add Spawnable Success."), true);
	}
	else
	{
		CreateNotification(LOCTEXT("AddSpawnableFail", "Add Spawnable Fail."), false);
	}
}

void FCutsceneCustomObjectBinding::AddLightTemplate(UBlueprint* Blueprint)
{
	if (!Blueprint || !Blueprint->GeneratedClass || !Sequencer.IsValid())
		return;
	
	// 整个窗口, 然后设置一些数据, 然后再添加 Spawnable
	TSharedRef<SWindow> Window = SNew(SWindow)
		.Title(LOCTEXT("AddLightTemplateTitle", "Add Light Template"))
		.SizingRule(ESizingRule::UserSized)
		.AutoCenter(EAutoCenter::PreferredWorkArea)
		.ClientSize(FVector2D(350, 200));

	bool bAttachCamera = true;
	bool bHideOutsideSection = true;
	bool bOkClicked = false;
	
	Window->SetContent(
		SNew(SBorder)
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
			.AutoHeight()
			.VAlign(VAlign_Center)
			[
				SNew(SCheckBox)
				.OnCheckStateChanged_Lambda([&bAttachCamera](ECheckBoxState InState)
				{
					bAttachCamera = InState == ECheckBoxState::Checked;
				})
				.IsChecked_Lambda([&bAttachCamera]()
				{
					return bAttachCamera ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
				})
				[
					SNew(STextBlock)
					.Text(LOCTEXT("AttachCameraLabel", "在 LightControl 片段内自动附加到相机"))
				]
			]

			+ SVerticalBox::Slot()
			[
				SNew(SCheckBox)
				.OnCheckStateChanged_Lambda([&bHideOutsideSection](ECheckBoxState InState)
				{
					bHideOutsideSection = InState == ECheckBoxState::Checked;
				})
				.IsChecked_Lambda([&bHideOutsideSection]()
				{
					return bHideOutsideSection ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
				})
				[
					SNew(STextBlock)
					.Text(LOCTEXT("HideOutsideSectionLabel", "在 LightControl 片段范围外自动隐藏"))
				]
			]

			+SVerticalBox::Slot()
			
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(3)
			[
				SNew(SHorizontalBox)

				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				[
					SNew(SButton)
					.Text(LOCTEXT("AddButtonText", "Add"))
					.OnClicked_Lambda([&Window, &bOkClicked]()
					{
						bOkClicked = true;
						Window->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
			]
		]
	);

	// 阻塞
	GEditor->EditorAddModalWindow(Window);

	if (!bOkClicked)
		return;
	
	const TSharedPtr<ISequencer> Seq = Sequencer.Pin();
	UActorFactory* ActorFactory = GEditor->FindActorFactoryForActorClass(Blueprint->GeneratedClass);
	const FGuid NewGuid = AddSpawnable(*Seq, *Blueprint, ActorFactory);

	UMovieSceneSequence* Sequence = Seq->GetFocusedMovieSceneSequence();
	if (!Sequence)
		return;

	UMovieScene* MovieScene = Sequence->GetMovieScene();
	if (!MovieScene)
		return;

	UMovieSceneCustomTrack* CustomTrack = MovieScene->AddTrack<UMovieSceneCustomTrack>(NewGuid);
	UMovieSceneCustomSection* CustomSection = NewObject<UMovieSceneCustomSection>(CustomTrack, NAME_None, RF_Transactional);

	FFrameNumber StartFrame = Seq->GetLocalTime().Time.FrameNumber;
	FFrameNumber EndFrame = MovieScene->GetPlaybackRange().GetUpperBoundValue();
	CustomSection->SetRange(TRange<FFrameNumber>::Inclusive(StartFrame, EndFrame));
	
	const UCutSceneEditorSettings* Settings = GetDefault<UCutSceneEditorSettings>();
	UMovieSceneCustomData* CustomData = NewObject<UMovieSceneCustomData>(CustomSection, Settings->LightControlClass, NAME_None, RF_Transactional);
	
	if (const FBoolProperty* Prop = FindFProperty<FBoolProperty>(Settings->LightControlClass, TEXT("bHideOutsideSection")))
	{
		Prop->SetPropertyValue_InContainer(CustomData, bHideOutsideSection);
	}
	
	if (const FBoolProperty* Prop = FindFProperty<FBoolProperty>(Settings->LightControlClass, TEXT("bAlwaysAttachToCamera")))
	{
		Prop->SetPropertyValue_InContainer(CustomData, bAttachCamera);
	}
	
	CustomSection->CustomData = CustomData;
	
	CustomTrack->AddSection(*CustomSection);
	
	AActor* Spawnable = Cast<AActor>(Seq->FindSpawnedObjectOrTemplate(NewGuid));
	if (!Spawnable)
		return;
	
	Spawnable->GetRootComponent()->SetVisibility(!bHideOutsideSection, true);
	Spawnable->SetActorTransform(FTransform());
	
	if (NewGuid.IsValid())
	{
		CreateNotification(LOCTEXT("AddSpawnableSuccess", "Add Spawnable Success."), true);
	}
	else
	{
		CreateNotification(LOCTEXT("AddSpawnableFail", "Add Spawnable Fail."), false);
	}
}

FGuid FCutsceneCustomObjectBinding::AddSpawnable(ISequencer& Sequencer, UObject& Obj, UActorFactory* ActorFactory)
{
	UE::Sequencer::FCreateBindingParams Params;
	Params.BindingNameOverride = Obj.GetName();
	Params.bSpawnable = true;
	Params.bReplaceable = true;
	Params.ActorFactory = ActorFactory;
	return Sequencer.CreateBinding(Obj, Params);
}

void FCutsceneCustomObjectBinding::InitFacadeControlIDs()
{
	if (FacadeControlIDs.Num() > 0)
		return;
	
	FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
	TSharedPtr<FCutSceneEditor> CutSceneEditor = KGStoryLineEditorModule.GetCutsceneEditor();
	if (CutSceneEditor != nullptr)
	{
		CutSceneEditor->GetFacadeControlIDs(FacadeControlIDs);
	}
}

void FCutsceneCustomObjectBinding::InitializeLightTemplates()
{
	if (LightTemplates.Num() > 0)
		return;

	const UCutSceneEditorSettings* Settings = GetDefault<UCutSceneEditorSettings>();
	FName Path = Settings->LightTemplateDir;
	TArray<FAssetData> AssetDatas;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	FARFilter Filter;
	Filter.PackagePaths.Add(Path);
	Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
	AssetRegistryModule.Get().GetAssets(Filter, AssetDatas);
	for (const FAssetData& AssetData : AssetDatas)
	{
		UBlueprint* Bp = Cast<UBlueprint>(AssetData.GetAsset());
		if (Bp != nullptr)
		{
			LightTemplates.Add(Bp);
		}
	}
}

void FCutsceneCustomObjectBinding::CreateNotification(const FText& Message, const bool bSuccess, const float FadeOutDuration, const float ExpireDuration, const bool bWarning)
{
	FNotificationInfo Info(Message);
	Info.bFireAndForget = true;
	Info.FadeOutDuration = FadeOutDuration;
	Info.ExpireDuration = ExpireDuration;
	Info.bUseSuccessFailIcons = true;
	if (bWarning)
	{
		Info.Image = FAppStyle::GetBrush("MessageLog.Warning"); 
	}

	const TSharedPtr<SNotificationItem> Notification = FSlateNotificationManager::Get().AddNotification(Info);
	if (Notification.IsValid())
	{
		if (bSuccess)
		{
			Notification->SetCompletionState(SNotificationItem::ECompletionState::CS_Success);
		}
		else
		{
			Notification->SetCompletionState(SNotificationItem::ECompletionState::CS_Fail);
		}
	}
}

#undef LOCTEXT_NAMESPACE
