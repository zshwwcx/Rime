#include "DialogueEditor/DialogueEditorToolbar.h"

#include "ToolMenus.h"
#include "WorkflowOrientedApp/SModeWidget.h"

#include "KGEditorStyle.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorCommands.h"   
#include "DialogueEditor/DialogueEditorSettings.h"



#define LOCTEXT_NAMESPACE "DialogueEditorToolbar"



void FDialogueEditorToolbar::SetupToolbar(TSharedPtr<FExtender> Extender, TSharedPtr<FDialogueEditor> InEditor)
{
	CachedEditor = InEditor;

	PlayIcon = FSlateIcon(FAppStyle::GetAppStyleSetName(), FName(TEXT("Animation.Forward")));
	PauseIcon = FSlateIcon(FAppStyle::GetAppStyleSetName(), FName(TEXT("Animation.Pause")));
}

void FDialogueEditorToolbar::AddTimelineToolbar(TSharedPtr<FExtender> Extender)
{
	Extender->AddToolBarExtension
	(
		"Asset",
		EExtensionHook::After,
		CachedEditor.Pin()->GetToolkitCommands(),
		FToolBarExtensionDelegate::CreateSP(this, &FDialogueEditorToolbar::FillTimelineModeToolbar)
	);
}

void FDialogueEditorToolbar::FillTimelineModeToolbar(FToolBarBuilder& ToolbarBuilder)
{
	// 不确定这里为啥会崩 先加个报错兼容 看看报错信息
	try
	{
		FDialogueEditorCommands::Register();
	TSharedPtr<FBindingContext> Context = FInputBindingManager::Get().GetContextByName(FDialogueEditorCommands::Get()
	.GetContextName());
		const FDialogueEditorCommands& Commands = FDialogueEditorCommands::Get();
		
		ToolbarBuilder.BeginSection("Timeline");
		{
			UDialogueEditorSettings* DialogueEditorSettings = GetMutableDefault<UDialogueEditorSettings>();
			if (DialogueEditorSettings->bShowPreviewViewport)
			{
				ToolbarBuilder.AddToolBarButton
				(
					Commands.Play,
					NAME_None,
					TAttribute<FText>(this, &FDialogueEditorToolbar::GetPlayText),
					TAttribute<FText>(this, &FDialogueEditorToolbar::GetPlayToolTip),
					TAttribute<FSlateIcon>(this, &FDialogueEditorToolbar::GetPlayIcon)
				);
			}

			ToolbarBuilder.AddToolBarButton
			(
				Commands.PlayBigworld,
				NAME_None,
				TAttribute<FText>(this, &FDialogueEditorToolbar::GetBigworldPlayText),
				TAttribute<FText>(this, &FDialogueEditorToolbar::GetPlayToolTip),
				TAttribute<FSlateIcon>(this, &FDialogueEditorToolbar::GetPlayIcon)
			);
			ToolbarBuilder.AddToolBarButton(Commands.Stop);
			ToolbarBuilder.AddToolBarButton(Commands.Import);
			ToolbarBuilder.AddToolBarButton(Commands.SyncTemplate);
			ToolbarBuilder.AddToolBarButton(Commands.SaveAsTemplate);
			ToolbarBuilder.AddToolBarButton(Commands.Audio2FaceAutoMatch);
			ToolbarBuilder.AddToolBarButton(Commands.CreateAutoCuts);
		}
		ToolbarBuilder.EndSection();
		
	}
	catch (const std::exception& e)
	{
		FString Message(e.what());
		UE_LOG(LogTemp, Error, TEXT("FDialogueEditorCommands Error :%s"), *Message);
	}
}

TSharedRef<SWidget> FDialogueEditorToolbar::GenerateDataProcessMenu()
{
	TSharedPtr<FUICommandList> InCommandList = nullptr;
	TSharedPtr<FExtender> MenuExtender = nullptr;

	FToolMenuContext MenuContext(InCommandList, MenuExtender);
	return UToolMenus::Get()->GenerateWidget("DialogueEditor.DialogueEditorToolBar.AutoCamera", MenuContext);
}

FText FDialogueEditorToolbar::GetPlayText() const
{
	if (CachedEditor.Pin()->IsPlaying())
	{
		if (CachedEditor.Pin()->IsPaused())
			return LOCTEXT("TimelineCommand_Resume_GetPlayText", "Resume");
		return LOCTEXT("TimelineCommand_Pause_GetPlayText", "Pause");
	}

	return LOCTEXT("TimelineCommand_Play_GetPlayText", "Play");
}

FText FDialogueEditorToolbar::GetBigworldPlayText() const
{
	if (CachedEditor.Pin()->IsPlaying())
	{
		if (CachedEditor.Pin()->IsPaused())
			return LOCTEXT("TimelineCommand_Resume_GetBigworldPlayText", "Resume");
		return LOCTEXT("TimelineCommand_Pause_GetBigworldPlayText", "Pause");
	}

	return LOCTEXT("TimelineCommand_PlayBigworld_GetBigworldPlayText", "PlayBigworld");
}

FText FDialogueEditorToolbar::GetPlayToolTip() const
{
	if (CachedEditor.Pin()->IsPlaying())
		return LOCTEXT("TimelineCommandToolTip_PauseDialogue_GetPlayToolTip", "Pause Dialogue.");

	return LOCTEXT("TimelineCommandToolTip_PlayDialogue_GetPlayToolTip", "Play Dialogue.");
}

FSlateIcon FDialogueEditorToolbar::GetPlayIcon() const
{
	if (CachedEditor.Pin()->IsPlaying())
		return PauseIcon;

	return PlayIcon;
}



#undef LOCTEXT_NAMESPACE