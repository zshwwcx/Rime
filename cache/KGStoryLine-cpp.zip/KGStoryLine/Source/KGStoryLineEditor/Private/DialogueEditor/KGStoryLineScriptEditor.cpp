#include "DialogueEditor/KGStoryLineScriptEditor.h"

#include "DialogueEditor/DialogueEditorSettings.h"
#include "IDocumentation.h"
#include "KGStoryLineDefine.h"
#include "ScopedTransaction.h"
#include "DialogueEditor/Widgets/SKGSLScriptEdListViewSettings.h"
#include "DialogueEditor/Widgets/SKGStoryLineScriptListViewRow.h"
#include "DialogueEditor/Widgets/SKGStoryLineScriptLineEditor.h"
#include "Fonts/FontMeasure.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Commands/GenericCommands.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Misc/FileHelper.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Input/SHyperlink.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Misc/FeedbackContext.h"
#include "Widgets/SToolTip.h"
#include "DialogueEditor/Util/KGSLEdUtil.h"
#include "Widgets/Images/SLayeredImage.h"

#pragma optimize("", off)

#define LOCTEXT_NAMESPACE "KGStoryLineScriptEditor"

const FName FKGStoryLineScriptEditor::ScriptEditorIdentifier("KGStoryLineScriptEditor");
const FName FKGStoryLineScriptEditor::ScriptTabId("KGStoryLineScriptEditor_Script");
const FName FKGStoryLineScriptEditor::RowEditorTabId("KGStoryLineScriptEditor_RowEditor");
const FName FKGStoryLineScriptEditor::RowNameColumnId("RowName");
const FName FKGStoryLineScriptEditor::RowNumberColumnId("RowNumber");
const FName FKGStoryLineScriptEditor::RowDragDropColumnId("RowDragDrop");


FKGStoryLineScriptEditor::FKGStoryLineScriptEditor()
    : INotifyOnKGSLDataChanged(EKGSLDataChangeInfo::LineAdded, EKGSLDataChangeInfo::LineRemoved,
        EKGSLDataChangeInfo::LineSwapped, EKGSLDataChangeInfo::LineData, EKGSLDataChangeInfo::EditorFieldOrderChanged)
{
}

FKGStoryLineScriptEditor::~FKGStoryLineScriptEditor()
{
    GEditor->UnregisterForUndo(this);
}

void FKGStoryLineScriptEditor::RegisterTabSpawners(const TSharedRef<FTabManager>& InTabManager)
{
    WorkspaceMenuCategory = InTabManager->AddLocalWorkspaceMenuCategory(
        LOCTEXT("WorkspaceMenu_KGStoryLine Script Editor", "Script Editor"));

    ToolBarExtensibilityManager = MakeShareable(new FExtensibilityManager);

    FAssetEditorToolkit::RegisterTabSpawners(InTabManager);
    CreateAndRegisterScriptTab(InTabManager);
    CreateAndRegisterRowEditorTab(InTabManager);
}

void FKGStoryLineScriptEditor::UnregisterTabSpawners(const TSharedRef<FTabManager>& InTabManager)
{
    FAssetEditorToolkit::UnregisterTabSpawners(InTabManager);
    InTabManager->UnregisterTabSpawner(ScriptTabId);
    InTabManager->UnregisterTabSpawner(RowEditorTabId);

    ScriptTabWidget.Reset();
    RowEditorTabWidget.Reset();
}

void FKGStoryLineScriptEditor::InitScriptEditor(const EToolkitMode::Type Mode,
                                                const TSharedPtr<IToolkitHost>& InitToolkitHost,
                                                UDialogueAsset* DialogueAsset, int32 EpisodeID, UStruct* StructClass)
{
    TemplateClass = StructClass;

    EditingEpisodeID = EpisodeID;
    TSharedRef<FTabManager::FLayout> StandaloneDefaultLayout = FTabManager::NewLayout(
        "Standalone_DialogueScript_Layout");
    StandaloneDefaultLayout->AddArea(
        FTabManager::NewPrimaryArea()->SetOrientation(Orient_Horizontal)
                                     ->Split
                                     (
                                         FTabManager::NewStack()
                                         ->AddTab(ScriptTabId, ETabState::OpenedTab)
                                         ->SetForegroundTab(ScriptTabId)
                                     )
                                     ->Split
                                     (
                                         FTabManager::NewStack()
                                         ->AddTab(RowEditorTabId, ETabState::OpenedTab)
                                     )
    );

    InitAssetEditor(Mode, InitToolkitHost, ScriptEditorIdentifier, StandaloneDefaultLayout,
                    true, true, DialogueAsset);

    auto OwnerTab = TabManager->GetOwnerTab();
    if (OwnerTab.IsValid())
    {
        FText Label = OwnerTab->GetTabLabel();
        OwnerTab->SetLabel(FText::Format(LOCTEXT("ScriptEditorTabLabel", "{0} Episode:{1} "), Label, EditingEpisodeID));
    }

    TSharedPtr<FExtender> ToolbarExtender = ToolBarExtensibilityManager->GetAllExtenders(
        GetToolkitCommands(), GetEditingObjects());
    ToolbarExtender->AddToolBarExtension(
        "Asset",
        EExtensionHook::After,
        GetToolkitCommands(),
        FToolBarExtensionDelegate::CreateSP(this, &FKGStoryLineScriptEditor::FillToolbar)
    );
    AddToolbarExtender(ToolbarExtender);

    RegenerateMenusAndToolbars();

    GEditor->RegisterForUndo(this);

    ToolkitCommands->MapAction(FGenericCommands::Get().Copy,
                               FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::CopySelectedLine),
                               FCanExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::CanEditScript));
    ToolkitCommands->MapAction(FGenericCommands::Get().Paste, FExecuteAction::CreateSP(this,
                                   &FKGStoryLineScriptEditor::Paste), FCanExecuteAction::CreateSP(this,
                                   &FKGStoryLineScriptEditor::CanPaste));
    ToolkitCommands->MapAction(FGenericCommands::Get().Duplicate,
                               FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::DuplicateSelectedLine),
                               FCanExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::CanEditScript));
    ToolkitCommands->MapAction(FGenericCommands::Get().Delete,
                               FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::DeleteSelectedLine),
                               FCanExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::CanEditScript));
}

FName FKGStoryLineScriptEditor::GetToolkitFName() const
{
    return ScriptEditorIdentifier;
}

FText FKGStoryLineScriptEditor::GetBaseToolkitName() const
{
    return LOCTEXT("KGStoryLineScriptEditorLabel", "KGStoryLine Script Editor");
}

FString FKGStoryLineScriptEditor::GetWorldCentricTabPrefix() const
{
    return LOCTEXT("KGStoryLineScriptEditorWorldCentricTabPrefix", "KGStoryLineScriptEditor").ToString();
}

FLinearColor FKGStoryLineScriptEditor::GetWorldCentricTabColorScale() const
{
    return FLinearColor(0.1f, 0.25f, 0.5f, 0.5f);
}

void FKGStoryLineScriptEditor::OnClose()
{
    FAssetEditorToolkit::OnClose();
}

void FKGStoryLineScriptEditor::SaveAsset_Execute()
{
    if (auto Editor = UKGStoryLineEditorSubSystem::Get().GetEditor(GetEditingAsset()))
    {
        Editor->SaveAsset_Execute();
    }
}

void FKGStoryLineScriptEditor::PostUndo(bool bSuccess)
{
    HandleUndoRedo();
}

void FKGStoryLineScriptEditor::PostRedo(bool bSuccess)
{
    HandleUndoRedo();
}

void FKGStoryLineScriptEditor::HandleUndoRedo()
{
    if (GetEditingAsset())
    {
        HandlePostChange();
        CallbackOnUndoRedo.ExecuteIfBound();
    }
}

void FKGStoryLineScriptEditor::PreChange(const class UUserDefinedStruct* Struct,
                                         FStructureEditorUtils::EStructureEditorChangeInfo Info)
{
}

void FKGStoryLineScriptEditor::PostChange(const class UUserDefinedStruct* Struct,
                                          FStructureEditorUtils::EStructureEditorChangeInfo Info)
{
    const UDialogueAsset* Asset = GetEditingAsset();
    if (Asset && Struct && GetDefault<UDialogueEditorSettings>()->ExtensionClass.Get() == Struct->StaticClass())
    {
        HandlePostChange();
    }
}

void FKGStoryLineScriptEditor::PreChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo Info)
{
}

void FKGStoryLineScriptEditor::PostChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo Info)
{
	switch (Info)
	{
	case EKGSLDataChangeInfo::LineAdded:
	case EKGSLDataChangeInfo::LineRemoved:
	case EKGSLDataChangeInfo::LineSwapped:
	case EKGSLDataChangeInfo::LineData:
		{
			const UDialogueAsset* Asset = GetEditingAsset();
			if (Asset == Changed && Asset)
			{
				HandlePostChange();
			}
		}
		break;
	case EKGSLDataChangeInfo::EditorFieldOrderChanged:
		HandleFieldOrderChanged();
		break;
	default: break;
	}
}

void FKGStoryLineScriptEditor::SelectionChange(const UDialogueAsset* Changed, int32 EpisodeID, FName RowName)
{
    const UDialogueAsset* Asset = GetEditingAsset();
    if (Asset && Asset == Changed && EditingEpisodeID == EpisodeID)
    {
        const bool bSelectionChanged = HighlightedRowName != RowName;
        SetHighlightedRow(RowName);
        if (bSelectionChanged)
        {
            CallbackOnLineHighlighted.ExecuteIfBound(HighlightedRowName);
        }
    }
}

UDialogueAsset* FKGStoryLineScriptEditor::GetEditingAsset() const
{
    return Cast<UDialogueAsset>(GetEditingObject());
}

void FKGStoryLineScriptEditor::HandlePostChange()
{
    const FName CachedSelection = HighlightedRowName;
    HighlightedRowName = NAME_None;
    RefreshCachedLine(CachedSelection, true);
}

bool FKGStoryLineScriptEditor::CanEditLines() const
{
    return true;
}

bool FKGStoryLineScriptEditor::CanEditScript() const
{
    return HighlightedRowName != NAME_None;
}

bool FKGStoryLineScriptEditor::CanPaste() const
{
    if (CanEditScript())
    {
        return true;
    }

    FString Clipboard;
    FPlatformApplicationMisc::ClipboardPaste(Clipboard);
    if (!Clipboard.IsEmpty())
    {
        return true;
    }

    return false;
}

void FKGStoryLineScriptEditor::CopySelectedLine() const
{
    UDialogueAsset* Asset = GetEditingAsset();
    if (Asset && IsValid(Asset) && HighlightedRowName != NAME_None)
    {
        int32 LineIndex = RowId2LineIndex(HighlightedRowName);
        if (UKGSLDialogueLine* Line = Asset->GetDialogueLine(EditingEpisodeID, LineIndex))
        {
            FString ClipboardValue;
            UKGSLDialogueLine::ExportText(ClipboardValue, Line, Line, Asset, PPF_Copy, nullptr);
            FPlatformApplicationMisc::ClipboardCopy(*ClipboardValue);
        }
    }
}

void FKGStoryLineScriptEditor::Paste()
{
    if (CanEditScript())
    {
        PasteOnSelectedLine();
        return;
    }

    PasteFromClipboard();
}

void FKGStoryLineScriptEditor::PasteOnSelectedLine()
{
    UDialogueAsset* Asset = GetEditingAsset();
    if (Asset && IsValid(Asset) && HighlightedRowName != NAME_None)
    {
        int32 LineIndex = RowId2LineIndex(HighlightedRowName);
        UKGSLDialogueLine* Line = Asset->GetDialogueLine(EditingEpisodeID, LineIndex);
        if (!Line || !IsValid(Line))
        {
            return;
        }

        const FScopedTransaction Transaction(LOCTEXT("PasteScriptLine", "Paste Line"));
        Asset->Modify();

        FString ClipboardValue;
        FPlatformApplicationMisc::ClipboardPaste(ClipboardValue);

        UKGStoryLineEditorSubSystem::BroadcastPreChanged(Asset, EKGSLDataChangeInfo::LineData);
        bool bFailed;
        {
            int64 GUID = Line->GUID;
        	FGuid UniqueID = Line->UniqueID;
            const TCHAR* Result = UKGSLDialogueLine::ImportText(*ClipboardValue, Line,
                                                                Cast<UObject>(Asset), PPF_Copy, GWarn,
                                                                TEXT("FDialogueLine"));
            Line->GUID = GUID;
        	Line->UniqueID = UniqueID;
            bFailed = Result == nullptr;
        }

        Asset->MarkPackageDirty();
        UKGStoryLineEditorSubSystem::BroadcastPostChanged(Asset, EKGSLDataChangeInfo::LineData);

        if (bFailed)
        {
            FNotificationInfo Info(LOCTEXT("FailedPaste_KGStoryLineScriptEditor", "Failed to paste line"));
            FSlateNotificationManager::Get().AddNotification(Info);
        }
    }
}

void FKGStoryLineScriptEditor::PasteFromClipboard()
{
    FString Clipboard;
    FPlatformApplicationMisc::ClipboardPaste(Clipboard);
    if (Clipboard.IsEmpty())
    {
        return;
    }

    TArray<FString> Tokens;
    if (Clipboard.ParseIntoArray(Tokens, TEXT("\n"), true) <= 0)
    {
        return;
    }

    if (UDialogueAsset* Asset = GetEditingAsset())
    {
        if (UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EditingEpisodeID))
        {
            int32 Count = Episode->DialogueLines.Num();
            FName NewName(*FString::FromInt(Count + 1));

            UKGStoryLineEditorSubSystem::BroadcastPreChanged(Asset, EKGSLDataChangeInfo::LineAdded);
            Asset->Modify();

            for (FString& Token : Tokens)
            {
                UKGSLDialogueLine* NewLine = Episode->InstanceLine(Token, TEXT(""));
                Episode->AddLine(NewLine);
            }

            Asset->Modify();
            Asset->MarkPackageDirty();

            UKGStoryLineEditorSubSystem::BroadcastPostChanged(Asset, EKGSLDataChangeInfo::LineAdded);
            UKGStoryLineEditorSubSystem::SelectLine(Asset, EditingEpisodeID, NewName);

            SetDefaultSort();
        }
    }
}

void FKGStoryLineScriptEditor::DuplicateSelectedLine()
{
    UDialogueAsset* Asset = GetEditingAsset();
    if (Asset && IsValid(Asset) && HighlightedRowName != NAME_None)
    {
        int32 LineIndex = RowId2LineIndex(HighlightedRowName);
        if (UKGStoryLineEditorSubSystem::DuplicateLine(Asset, EditingEpisodeID, LineIndex))
        {
            UKGStoryLineEditorSubSystem::SelectLine(Asset, EditingEpisodeID, LineIndex2RowId(LineIndex));
        }
    }
}

void FKGStoryLineScriptEditor::DeleteSelectedLine()
{
    UDialogueAsset* Asset = GetEditingAsset();
    if (Asset && IsValid(Asset) && HighlightedRowName != NAME_None)
    {
        int32 LineIndex = RowId2LineIndex(HighlightedRowName);
        UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EditingEpisodeID);
        if (UKGStoryLineEditorSubSystem::RemoveLine(Asset, EditingEpisodeID, LineIndex))
        {
            LineIndex = FMath::Clamp(LineIndex, 0, Episode->DialogueLines.Num() - 1);
            if (VisibleRows.IsValidIndex(LineIndex))
            {
                SelectRow(VisibleRows[LineIndex]->RowId);
            }
            else
            {
                CellsListView->RequestListRefresh();
            }
        }
    }
}

void FKGStoryLineScriptEditor::SelectRow(FName RowID) const
{
    UKGStoryLineEditorSubSystem::SelectLine(GetEditingAsset(), EditingEpisodeID, RowID);
}

void FKGStoryLineScriptEditor::MoveRow(FName RowID, FDataTableEditorUtils::ERowMoveDirection Direction, int32 NumRowsToMoveBy) const
{
	UKGStoryLineEditorSubSystem::MoveRow(GetEditingAsset(), EditingEpisodeID, RowId2LineIndex(RowID), Direction, NumRowsToMoveBy);
}

void FKGStoryLineScriptEditor::AddRowAboveOrBelow(FName RowID, ERowInsertionPosition InsertPosition) const
{
	if (RowID == NAME_None)
	{
		return;
	}

	int32 LineIndex = RowId2LineIndex(RowID) + static_cast<int32>(InsertPosition);
	UKGStoryLineEditorSubSystem::InsertLine(GetEditingAsset(), EditingEpisodeID, LineIndex);
}

void FKGStoryLineScriptEditor::RefreshCachedLine(const FName InCachedSelection, const bool bUpdateEvenIfValid)
{
    UDialogueAsset* Asset = GetEditingAsset();
    TArray<FDataTableEditorColumnHeaderDataPtr> PreviousColumns = AvailableColumns;

    CacheScript(Asset, EditingEpisodeID, AvailableColumns, AvailableRows);

    // Update the desired width of the row names and numbers column
    // This prevents it growing or shrinking as you scroll the list view
    RefreshRowNumberColumnWidth();
    RefreshRowNameColumnWidth();

    // Set up the default auto-sized columns
    ColumnWidths.SetNum(AvailableColumns.Num());
    for (int32 ColumnIndex = 0; ColumnIndex < AvailableColumns.Num(); ++ColumnIndex)
    {
        const FDataTableEditorColumnHeaderDataPtr& ColumnData = AvailableColumns[ColumnIndex];
        FColumnWidth& ColumnWidth = ColumnWidths[ColumnIndex];
        ColumnWidth.CurrentWidth = FMath::Clamp(ColumnData->DesiredColumnWidth, 10.0f, 400.0f);
        // Clamp auto-sized columns to a reasonable limit
    }

    // Load the persistent column widths from the layout data
    {
        const TSharedPtr<FJsonObject>* LayoutColumnWidths = nullptr;
        if (LayoutData.IsValid() && LayoutData->TryGetObjectField(TEXT("ColumnWidths"), LayoutColumnWidths))
        {
            for (int32 ColumnIndex = 0; ColumnIndex < AvailableColumns.Num(); ++ColumnIndex)
            {
                const FDataTableEditorColumnHeaderDataPtr& ColumnData = AvailableColumns[ColumnIndex];

                double LayoutColumnWidth = 0.0f;
                if ((*LayoutColumnWidths)->TryGetNumberField(ColumnData->ColumnId.ToString(), LayoutColumnWidth))
                {
                    FColumnWidth& ColumnWidth = ColumnWidths[ColumnIndex];
                    ColumnWidth.bIsAutoSized = false;
                    ColumnWidth.CurrentWidth = static_cast<float>(LayoutColumnWidth);
                }
            }
        }
    }

    static constexpr TCHAR VariableType[] = TEXT("Shared/Editor/Blueprint/VariableTypes");
    if (PreviousColumns != AvailableColumns || bUpdateEvenIfValid)
    {
        ColumnNamesHeaderRow->ClearColumns();

        if (CanEditLines())
        {
            TSharedRef<SToolTip> ToolTip = IDocumentation::Get()->CreateToolTip(
                LOCTEXT("ScriptLineHandleTooltip", "Drag Drop Handles"),
                nullptr,
                VariableType,
                TEXT("ScriptLineHandle"));

            ColumnNamesHeaderRow->AddColumn(
                SHeaderRow::Column(RowDragDropColumnId)
                [
                    SNew(SBox)
                    .VAlign(VAlign_Fill)
                    .HAlign(HAlign_Fill)
                    .ToolTip(ToolTip)
                    [
                        SNew(STextBlock)
                        .Text(FText::GetEmpty())
                    ]
                ]
            );
        }
        //
        // ColumnNamesHeaderRow->AddColumn(
        //     SHeaderRow::Column(RowNumberColumnId)
        //     .SortMode(this, &FKGStoryLineScriptEditor::GetColumnSortMode, RowNumberColumnId)
        //     .OnSort(this, &FKGStoryLineScriptEditor::OnColumnNumberSortModeChanged)
        //     .ManualWidth(this, &FKGStoryLineScriptEditor::GetRowNumberColumnWidth)
        //     .OnWidthChanged(this, &FKGStoryLineScriptEditor::OnRowNumberColumnResized)
        //     [
        //         SNew(SBox)
        //         .VAlign(VAlign_Fill)
        //         .HAlign(HAlign_Fill)
        //         .ToolTip(IDocumentation::Get()->CreateToolTip(
        //             LOCTEXT("ScriptLineIndexTooltip", "Line Index"),
        //             nullptr,
        //             VariableType,
        //             TEXT("ScriptLineIndex")))
        //         [
        //             SNew(STextBlock)
        //             .Text(FText::GetEmpty())
        //         ]
        //     ]
        // );

        ColumnNamesHeaderRow->AddColumn(
            SHeaderRow::Column(RowNameColumnId)
            .DefaultLabel(LOCTEXT("ScriptLineName", "Line Index"))
            .ManualWidth(this, &FKGStoryLineScriptEditor::GetRowNameColumnWidth)
            .OnWidthChanged(this, &FKGStoryLineScriptEditor::OnRowNameColumnResized)
            .SortMode(this, &FKGStoryLineScriptEditor::GetColumnSortMode, RowNameColumnId)
            .OnSort(this, &FKGStoryLineScriptEditor::OnColumnNameSortModeChanged)
        );
    	
        for (int32 ColumnIndex = 0; ColumnIndex < AvailableColumns.Num(); ++ColumnIndex)
        {
            const FDataTableEditorColumnHeaderDataPtr& ColumnData = AvailableColumns[ColumnIndex];

            ColumnNamesHeaderRow->AddColumn(
                SHeaderRow::Column(ColumnData->ColumnId)
                .DefaultLabel(ColumnData->DisplayName)
                .ManualWidth(TAttribute<float>::Create(
                    TAttribute<float>::FGetter::CreateSP(this, &FKGStoryLineScriptEditor::GetColumnWidth, ColumnIndex)))
                .OnWidthChanged(this, &FKGStoryLineScriptEditor::OnColumnResized, ColumnIndex)
                .SortMode(this, &FKGStoryLineScriptEditor::GetColumnSortMode, ColumnData->ColumnId)
                .OnSort(this, &FKGStoryLineScriptEditor::OnColumnSortModeChanged)
                [
                    SNew(SBox)
                    .Padding(FMargin(0, 4, 0, 4))
                    .VAlign(VAlign_Fill)
                    .ToolTip(IDocumentation::Get()->CreateToolTip(
                        FDataTableEditorUtils::GetRowTypeInfoTooltipText(ColumnData), nullptr,
                        VariableType,
                        FDataTableEditorUtils::GetRowTypeTooltipDocExcerptName(ColumnData)))
                    [
                        SNew(STextBlock)
                        .Justification(ETextJustify::Center)
                        .Text(ColumnData->DisplayName)
                    ]
                ]
            );
        }
    }

    UpdateVisibleRows(InCachedSelection, bUpdateEvenIfValid);

    if (PropertyView.IsValid())
    {
        PropertyView->SetObject(Asset);
    }
}

void FKGStoryLineScriptEditor::CreateAndRegisterScriptTab(const TSharedRef<class FTabManager>& InTabManager)
{
    ScriptTabWidget = CreateScriptContentWidget();

    InTabManager->RegisterTabSpawner(ScriptTabId,
                                     FOnSpawnTab::CreateSP(this, &FKGStoryLineScriptEditor::SpawnTab_Script))
                .SetDisplayName(LOCTEXT("ScriptEditorTab", "Script"))
                .SetGroup(WorkspaceMenuCategory.ToSharedRef());
}

void FKGStoryLineScriptEditor::CreateAndRegisterRowEditorTab(const TSharedRef<class FTabManager>& InTabManager)
{
    RowEditorTabWidget = CreateRowEditorWidget();

    InTabManager->RegisterTabSpawner(RowEditorTabId,
                                     FOnSpawnTab::CreateSP(this, &FKGStoryLineScriptEditor::SpawnTab_RowEditor))
                .SetDisplayName(LOCTEXT("LineEditorTab_KGStoryLineScriptEditor", "Line Editor"))
                .SetGroup(WorkspaceMenuCategory.ToSharedRef());
}

void FKGStoryLineScriptEditor::OnInsertNewRow(ERowInsertionPosition RowInsertionPosition)
{
    OnAddClicked();
}

void FKGStoryLineScriptEditor::OnClearAllLiens()
{
    if (UDialogueAsset* Asset = GetEditingAsset())
    {
        if (UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EditingEpisodeID))
        {
            UKGStoryLineEditorSubSystem::BroadcastPreChanged(Asset, EKGSLDataChangeInfo::LineRemoved);
            Asset->Modify();
            Episode->DialogueLines.Empty();
            SetHighlightedRow(NAME_None);
            UKGStoryLineEditorSubSystem::BroadcastPostChanged(Asset, EKGSLDataChangeInfo::LineRemoved);
        }
    }
}

TSharedPtr<SWidget> FKGStoryLineScriptEditor::MakeEmptyZoneActionMenu()
{
    FMenuBuilder MenuBuilder(true, GetToolkitCommands());

    MenuBuilder.AddMenuEntry(
        LOCTEXT("KGSLScriptEditorRowMenuActions_InsertNewRow", "Insert New Line"),
        LOCTEXT("KGSLScriptEditorRowMenuActions_InsertNewRowTooltip", "Insert a new line"),
        FSlateIcon(FAppStyle::GetAppStyleSetName(), "DataTableEditor.Add"),
        FUIAction(FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::OnInsertNewRow,
                                           ERowInsertionPosition::Bottom))
    );

    MenuBuilder.AddMenuEntry(FGenericCommands::Get().Paste);

    MenuBuilder.AddMenuSeparator();

    MenuBuilder.AddMenuEntry(
        LOCTEXT("KGSLScriptEditorRowMenuActions_ClearAllLines", "Clear All Lines"),
        LOCTEXT("KGSLScriptEditorRowMenuActions_ClearAllLinesTooltip", "Clear all lines."),
        FSlateIcon(FAppStyle::GetAppStyleSetName(), "Symbols.DoubleUpArrow"),
        FUIAction(FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::OnClearAllLiens))
    );


    return MenuBuilder.MakeWidget();
}

void FKGStoryLineScriptEditor::OnListViewSettingsOpenChanged(bool bOpened)
{
	if (!ListViewSettings.IsValid())
	{
		return;
	}
	
	if (!bOpened)
	{
		TArray<FString> Orders;
		ListViewSettings->GetColumnDatas(Orders);
		if (Orders.Num() > 0)
		{
			bool bDifferent = false;
			int32 Count = FMath::Min(Orders.Num(), ColumnOrders.Num());
			for (int32 i = 0; i < Count; ++i)
			{
				if (ColumnOrders[i] != Orders[i])
				{
					bDifferent = true;
				}
			}
			
			if (bDifferent || ColumnOrders.Num() <= 0)
			{
				UKGStoryLineEditorSubSystem::BroadcastPreChanged(GetEditingAsset(), EKGSLDataChangeInfo::EditorFieldOrderChanged);
				ColumnOrders = Orders;
				// RefreshCachedLine(NAME_None, true);

				if (!LayoutData.IsValid())
				{
					LayoutData = MakeShareable(new FJsonObject());
				}
					
				TArray<TSharedPtr<FJsonValue>> LayoutColumnOrder;
				for (const FString& Order : ColumnOrders)
				{
					LayoutColumnOrder.Add(MakeShareable(new FJsonValueString(Order)));
				}
				LayoutData->RemoveField(TEXT("ColumnOrder"));
				LayoutData->SetArrayField(TEXT("ColumnOrder"), LayoutColumnOrder);

				SaveLayoutData();
				UKGStoryLineEditorSubSystem::BroadcastPostChanged(GetEditingAsset(), EKGSLDataChangeInfo::EditorFieldOrderChanged);
			}
		}
	}
	else
	{
		TArray<FString> DisplayNames;
		DisplayNames.Reserve(ColumnOrders.Num());
		for (const auto& Order : ColumnOrders)
		{
			FDataTableEditorColumnHeaderDataPtr* Data = AvailableColumns.FindByPredicate([&Order](const FDataTableEditorColumnHeaderDataPtr& Column)
			{
				return Column.IsValid() && Column->ColumnId.ToString().Equals(Order);
			});
			if (Data)
			{
				DisplayNames.Add((*Data)->DisplayName.ToString());
			}
		}
		
		ListViewSettings->SetColumnDatas(ColumnOrders, DisplayNames);
	}
}

TSharedRef<SVerticalBox> FKGStoryLineScriptEditor::CreateScriptContentWidget()
{
    TSharedRef<SScrollBar> HorizontalScrollBar = SNew(SScrollBar)
        .Orientation(Orient_Horizontal)
        .Thickness(FVector2D(12.0f, 12.0f));

    TSharedRef<SScrollBar> VerticalScrollBar = SNew(SScrollBar)
        .Orientation(Orient_Vertical)
        .Thickness(FVector2D(12.0f, 12.0f));

    ColumnNamesHeaderRow = SNew(SHeaderRow);

    CellsListView = SNew(SListView<FDataTableEditorRowListViewDataPtr>)
        .ListItemsSource(&VisibleRows)
        .HeaderRow(ColumnNamesHeaderRow)
        .OnGenerateRow(this, &FKGStoryLineScriptEditor::MakeRowWidget)
        .OnSelectionChanged(this, &FKGStoryLineScriptEditor::OnRowSelectionChanged)
        .OnContextMenuOpening(this, &FKGStoryLineScriptEditor::MakeEmptyZoneActionMenu)
        .ExternalScrollbar(VerticalScrollBar)
        .ConsumeMouseWheel(EConsumeMouseWheel::Always)
        .SelectionMode(ESelectionMode::Single)
        .AllowOverscroll(EAllowOverscroll::No);

    LoadLayoutData();
    RefreshCachedLine();

	TArray<FString> ColumnNames;
	TArray<FString> DisplayNames;
	for (auto& Column : AvailableColumns)
	{
		if (Column->Property != nullptr && !Column->Property->HasAnyPropertyFlags(CPF_Transient))
		{
			ColumnNames.Emplace(Column->ColumnId.ToString());
			DisplayNames.Emplace(Column->DisplayName.ToString());
		}
	}

    SAssignNew(ListViewSettings, SKGSLScriptEdListViewSettings)
	.ColumnNames(ColumnNames)
	.DisplayNames(DisplayNames);
	
	TSharedPtr<SLayeredImage> FilterImage = SNew(SLayeredImage)
		 .Image(FAppStyle::Get().GetBrush("DetailsView.ViewOptions"))
		 .ColorAndOpacity(FSlateColor::UseForeground());
	
    TSharedRef<SVerticalBox> VerticalBox = SNew(SVerticalBox)
        + SVerticalBox::Slot()
        .AutoHeight()
        [
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            [
                SNew(SSearchBox)
                .InitialText(this, &FKGStoryLineScriptEditor::GetFilterText)
                .OnTextChanged(this, &FKGStoryLineScriptEditor::OnFilterTextChanged)
                .OnTextCommitted(this, &FKGStoryLineScriptEditor::OnFilterTextCommitted)
            ]
	        + SHorizontalBox::Slot()
	        .Padding(2)
	        .AutoWidth()
	        .HAlign(HAlign_Right)
	        .VAlign(VAlign_Center)
	        [
	        	SNew( SComboButton )
				.HasDownArrow(false)
				.ContentPadding(0.0f)
				.ForegroundColor( FSlateColor::UseForeground() )
				.ButtonStyle( FAppStyle::Get(), "SimpleButton" )
				.AddMetaData<FTagMetaData>(FTagMetaData(TEXT("ViewOptions")))
		        .OnMenuOpenChanged(this, &FKGStoryLineScriptEditor::OnListViewSettingsOpenChanged)
				.MenuContent()
				[
					SNew(SBorder)
					.Padding(5)
					.VAlign(VAlign_Fill)
					.HAlign(HAlign_Fill)
					.BorderImage( FAppStyle::GetBrush( "ToolPanel.GroupBorder" ) )
					[
						SNew(SBox)
						.WidthOverride(500)
						.HeightOverride(400)
						[
							ListViewSettings.ToSharedRef()
						]	
					]
				]
				.ButtonContent()
				[
					FilterImage.ToSharedRef()
				]
	        ]
        ]
        + SVerticalBox::Slot()
        [
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            [
                SNew(SScrollBox)
                .Orientation(Orient_Horizontal)
                .ExternalScrollbar(HorizontalScrollBar)
                + SScrollBox::Slot()
                [
                    CellsListView.ToSharedRef()
                ]
            ]
            + SHorizontalBox::Slot()
            .AutoWidth()
            [
                VerticalScrollBar
            ]
        ]
        + SVerticalBox::Slot()
        .AutoHeight()
        [
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            [
                HorizontalScrollBar
            ]
        ];

    return VerticalBox;
}

TSharedRef<SWidget> FKGStoryLineScriptEditor::CreateRowEditorWidget()
{
    UDialogueAsset* Asset = GetEditingAsset();

    // Support undo/redo
    if (Asset)
    {
        Asset->SetFlags(RF_Transactional);
    }

    auto RowEditor = SNew(SKGStoryLineScriptLineEditor, Asset, EditingEpisodeID);
    RowEditor->RowSelectedCallback.BindSP(this, &FKGStoryLineScriptEditor::SetHighlightedRow);
    CallbackOnLineHighlighted.BindSP(RowEditor, &SKGStoryLineScriptLineEditor::SelectRow);
    CallbackOnUndoRedo.BindSP(RowEditor, &SKGStoryLineScriptLineEditor::HandleUndoRedo);
    return RowEditor;
}

TSharedRef<ITableRow> FKGStoryLineScriptEditor::MakeRowWidget(FDataTableEditorRowListViewDataPtr InRowDataPtr,
                                                              const TSharedRef<STableViewBase>& OwnerTable)
{
    return
            SNew(SKGStoryLineScriptListViewRow, OwnerTable)
            .ScritpEditor(SharedThis(this))
            .RowDataPtr(InRowDataPtr)
            .IsEditable(CanEditLines());
}

TSharedRef<SWidget> FKGStoryLineScriptEditor::MakeCellWidget(FDataTableEditorRowListViewDataPtr InRowDataPtr,
                                                             const int32 InRowIndex, const FName& InColumnId)
{
    int32 ColumnIndex = 0;
    for (; ColumnIndex < AvailableColumns.Num(); ++ColumnIndex)
    {
        const FDataTableEditorColumnHeaderDataPtr& ColumnData = AvailableColumns[ColumnIndex];
        if (ColumnData->ColumnId == InColumnId)
        {
            break;
        }
    }

    // Valid column ID?
    if (AvailableColumns.IsValidIndex(ColumnIndex) && InRowDataPtr->CellData.IsValidIndex(ColumnIndex))
    {
        return SNew(SBox)
            .Padding(FMargin(4, 2, 4, 2))
            [
                SNew(STextBlock)
                .TextStyle(FAppStyle::Get(), "DataTableEditor.CellText")
                .ColorAndOpacity(this, &FKGStoryLineScriptEditor::GetRowTextColor, InRowDataPtr->RowId)
                .Text(this, &FKGStoryLineScriptEditor::GetCellText, InRowDataPtr, ColumnIndex)
                .HighlightText(this, &FKGStoryLineScriptEditor::GetFilterText)
                .ToolTipText(this, &FKGStoryLineScriptEditor::GetCellToolTipText, InRowDataPtr, ColumnIndex)
            ];
    }

    return SNullWidget::NullWidget;
}

TSharedRef<SDockTab> FKGStoryLineScriptEditor::SpawnTab_Script(const FSpawnTabArgs& Args)
{
    check(Args.GetTabId().TabType == ScriptTabId);

    // Support undo/redo
    if (UDialogueAsset* Asset = GetEditingAsset())
    {
        Asset->SetFlags(RF_Transactional);
    }

    return SNew(SDockTab)
        .Label(LOCTEXT("ScriptTabTitle", "Script"))
        .TabColorScale(GetTabColorScale())
        [
            SNew(SBorder)
            .Padding(2)
            .BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
            [
                ScriptTabWidget.ToSharedRef()
            ]
        ];
}

TSharedRef<SDockTab> FKGStoryLineScriptEditor::SpawnTab_RowEditor(const FSpawnTabArgs& Args) const
{
    check(Args.GetTabId().TabType == RowEditorTabId);

    return SNew(SDockTab)
        .Label(LOCTEXT("RowEditorTitle", "Line Editor"))
        .TabColorScale(GetTabColorScale())
        [
            SNew(SBorder)
            .Padding(2)
            .VAlign(VAlign_Top)
            .HAlign(HAlign_Fill)
            .BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
            [
                RowEditorTabWidget.ToSharedRef()
            ]
        ];
}

void FKGStoryLineScriptEditor::OnRowSelectionChanged(FDataTableEditorRowListViewDataPtr InNewSelection,
                                                     ESelectInfo::Type InSelectInfo)
{
    const bool bSelectionChanged = !InNewSelection.IsValid() || InNewSelection->RowId != HighlightedRowName;
    const FName NewRowName = (InNewSelection.IsValid()) ? InNewSelection->RowId : NAME_None;

    SetHighlightedRow(NewRowName);

    if (bSelectionChanged)
    {
        CallbackOnLineHighlighted.ExecuteIfBound(HighlightedRowName);
    }
}

void FKGStoryLineScriptEditor::SetHighlightedRow(FName Name)
{
    if (Name == HighlightedRowName)
    {
        return;
    }

    if (Name.IsNone())
    {
        HighlightedRowName = NAME_None;
        CellsListView->ClearSelection();
        HighlightedVisibleRowIndex = INDEX_NONE;
    }
    else
    {
        HighlightedRowName = Name;

        FDataTableEditorRowListViewDataPtr* NewSelectionPtr = nullptr;
        for (HighlightedVisibleRowIndex = 0; HighlightedVisibleRowIndex < VisibleRows.Num(); ++
             HighlightedVisibleRowIndex)
        {
            if (VisibleRows[HighlightedVisibleRowIndex]->RowId == Name)
            {
                NewSelectionPtr = &(VisibleRows[HighlightedVisibleRowIndex]);

                break;
            }
        }


        // Synchronize the list views
        if (NewSelectionPtr)
        {
            CellsListView->SetSelection(*NewSelectionPtr);

            CellsListView->RequestScrollIntoView(*NewSelectionPtr);
        }
        else
        {
            CellsListView->ClearSelection();
        }
    }
}

void FKGStoryLineScriptEditor::LoadLayoutData()
{
    LayoutData.Reset();

    const UDialogueAsset* Asset = GetEditingAsset();
    if (!Asset)
    {
        return;
    }

	const TArray<FString>& DefaultColumns = GetDefault<UDialogueEditorSettings>()->DefaultColumns; 
    const FString LayoutDataFilename = FPaths::ProjectSavedDir() / TEXT("AssetData") /
        TEXT("KGStoryLineScriptEditorLayout.json");

    FString JsonText;
    if (FFileHelper::LoadFileToString(JsonText, *LayoutDataFilename))
    {
    	ColumnOrders.Empty();
        TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(JsonText);
        FJsonSerializer::Deserialize(JsonReader, LayoutData);
    	const TArray<TSharedPtr<FJsonValue>>* Order = nullptr;
    	if (LayoutData->TryGetArrayField(TEXT("ColumnOrder"), Order))
        {
    		const TArray<TSharedPtr<FJsonValue>>& ColumnOrder = *Order;
	         for (int32 ColumnIndex = 0; ColumnIndex < ColumnOrder.Num(); ++ColumnIndex)
	         {
	         	FString Name(TEXT("Unknown"));
	         	ColumnOrder[ColumnIndex]->TryGetString(Name);
	         	if (DefaultColumns.Contains(Name))
	         	{
	         		ColumnOrders.Emplace(Name);
	         	}
	         }
        }

    	if (ColumnOrders.Num() != DefaultColumns.Num())
    	{
    		for (const auto& Column : DefaultColumns)
    		{
    			ColumnOrders.AddUnique(Column);
    		}

    		ColumnOrders.Sort([&DefaultColumns](const FString& A, const FString& B)
			{
				int32 IndexA = DefaultColumns.IndexOfByKey(A);
				int32 IndexB = DefaultColumns.IndexOfByKey(B);
				return IndexA < IndexB;
			});
    	}
    	
    	if (ColumnOrders.Num() > 0)
    	{
    		return;
    	}
    }

	ColumnOrders = DefaultColumns;
}

void FKGStoryLineScriptEditor::SaveLayoutData() const
{
    const UDialogueAsset* Asset = GetEditingAsset();
    if (!Asset || !LayoutData.IsValid())
    {
        return;
    }

    const FString LayoutDataFilename = FPaths::ProjectSavedDir() / TEXT("AssetData") /
        TEXT("KGStoryLineScriptEditorLayout.json");

    FString JsonText;
    TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>> JsonWriter = TJsonWriterFactory<
        TCHAR, TPrettyJsonPrintPolicy<TCHAR>>::Create(&JsonText);
    if (FJsonSerializer::Serialize(LayoutData.ToSharedRef(), JsonWriter))
    {
        FFileHelper::SaveStringToFile(JsonText, *LayoutDataFilename);
    }
}

void FKGStoryLineScriptEditor::CacheKGSLDialogueLine(UDialogueAsset* Asset,
                                                     TArray<FDataTableEditorColumnHeaderDataPtr>& OutAvailableColumns,
                                                     TArray<FDataTableEditorRowListViewDataPtr>&
                                                     OutAvailableRows,
                                                     TArray<FDataTableEditorRowListViewDataPtr>& OldRows,
                                                     const TArray<const FProperty*>& StructProps,
                                                     TSharedRef<FSlateFontMeasure> FontMeasure,
                                                     const FTextBlockStyle& CellTextStyle,
                                                     const float& CellPadding) const
{
    UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EditingEpisodeID);
    if (!Episode)
    {
        OutAvailableRows.Empty();
        return ;
    }

    // Populate the row data
    OutAvailableRows.Reset(Episode->DialogueLines.Num());
    int32 Idx = 0;
    for (auto RowIt = Episode->DialogueLines.CreateConstIterator(); RowIt; ++RowIt, ++Idx)
    {
        FString StrIndex = FString::FromInt(Idx + 1);
        FText RowName = FText::FromString(StrIndex);
        FName RowId = FName(StrIndex);
        FDataTableEditorRowListViewDataPtr CachedRowData;

        // If at all possible, attempt to reuse previous rows if their data has not changed.
        if (Idx >= OldRows.Num() || OldRows[Idx]->RowId != RowId || !OldRows[Idx]->DisplayName.
            EqualTo(RowName))
        {
            CachedRowData = MakeShareable(new FDataTableEditorRowListViewData());
            CachedRowData->RowId = RowId;
            CachedRowData->DisplayName = RowName;
            CachedRowData->CellData.Reserve(StructProps.Num());
        }
        else
        {
            CachedRowData = OldRows[Idx];
            CachedRowData->CellData.Reset(StructProps.Num());
        }

        CachedRowData->DesiredRowHeight = FontMeasure->GetMaxCharacterHeight(CellTextStyle.Font) + 4;
        CachedRowData->RowNum = Idx + 1;

        // Always rebuild cell data
    	for (int32 i = 0; i < OutAvailableColumns.Num(); i++)
        {
            UKGSLDialogueLine* Line = *RowIt;
    		const FProperty* Property = nullptr;
    		for (int32 PropIndex = 0; PropIndex < StructProps.Num(); ++PropIndex)
    		{
    			const FProperty* Prop = StructProps[PropIndex];
    			if (Prop && Prop->GetName() == OutAvailableColumns[i]->ColumnId)
    			{
    				Property = Prop;
    				break;
    			}
    		}

            if(Property)
            {
            	UObject* Data = Line;
            	FDataTableEditorColumnHeaderDataPtr CachedColumnData = OutAvailableColumns[i];

            	const FText CellText = KGStoryLineEditor::GetUObjectPropertyValueAsText(Property, Data);
            	CachedRowData->CellData.Add(CellText);

            	const FVector2D CellTextSize = FontMeasure->Measure(CellText, CellTextStyle.Font);

            	CachedRowData->DesiredRowHeight = static_cast<float>(FMath::Max(
					CachedRowData->DesiredRowHeight, CellTextSize.Y));

            	const float CellWidth = static_cast<float>(CellTextSize.X + CellPadding);
            	CachedColumnData->DesiredColumnWidth = FMath::Max(CachedColumnData->DesiredColumnWidth, CellWidth);
            }
    		else
    		{
    			UE_LOG(LogKGSL, Warning, TEXT("[KGSL]UClass UKGSLDialogueLine has no field:%s"), *OutAvailableColumns[i]->ColumnId.ToString())
    		}
        }

        OutAvailableRows.Add(CachedRowData);
    }
}

void FKGStoryLineScriptEditor::CacheScript(UDialogueAsset* Asset, int32 EpisodeID,
                                           TArray<FDataTableEditorColumnHeaderDataPtr>& OutAvailableColumns,
                                           TArray<FDataTableEditorRowListViewDataPtr>& OutAvailableRows)
{
    if (!Asset || !IsValid(Asset) || !KGStoryLine::IsValidEpisodeID(EpisodeID) || !TemplateClass.IsValid())
    {
        OutAvailableColumns.Empty();
        OutAvailableRows.Empty();
        return;
    }

	UKGSLDialogueLine* Line = nullptr;
	if (auto* Episode = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		Line = Episode->GetLine(0);
	}

	const TArray<FString> DefaultColumns = GetDefault<UDialogueEditorSettings>()->DefaultColumns;
    TArray<FDataTableEditorColumnHeaderDataPtr> OldColumns = OutAvailableColumns;
    TArray<FDataTableEditorRowListViewDataPtr> OldRows = OutAvailableRows;
	
    // First build array of properties
	auto FindProp = [Line](const UStruct* Class,const FString& PropName) -> const FProperty*
	{
		TArray<const FProperty*> PendingCheckProps;
		for (TFieldIterator<const FProperty> It(Class); It; ++It)
		{
			const FProperty* Prop = *It;
			if (!Prop->HasMetaData(FName(TEXT("HideFromDataTableEditorColumn")))
				&& !Prop->HasAnyPropertyFlags(CPF_Transient))
			{
				if (PropName == Prop->GetName())
				{
					return Prop;
				}

				if (Prop->IsA<FObjectProperty>() && Prop->ArrayDim == 1)
				{
					UClass* SubPropClass = nullptr;
					if (IsValid(Line))
					{
						const FObjectProperty* ObjProp = CastField<FObjectProperty>(Prop);
						void* ObjectContainer = ObjProp->ContainerPtrToValuePtr<void>(Line);
						UObject* Object = ObjProp->GetObjectPropertyValue(ObjectContainer);
						SubPropClass = Object->GetClass(); 
					}
					else
					{
						SubPropClass = GetDefault<UDialogueEditorSettings>()->ExtensionClass;
					}
					
					if (IsValid(SubPropClass))
					{
						const FProperty* Prop2 = SubPropClass->FindPropertyByName(FName(PropName));
						if (Prop2
							&& !Prop2->HasMetaData(FName(TEXT("HideFromDataTableEditorColumn")))
							&& !Prop2->HasAnyPropertyFlags(CPF_Transient))
						{
							return Prop2;
						}
					}
				}
			}
		}
		
		return nullptr;
	};
	
    TArray<const FProperty*> StructProps;
	for (const auto& Column : ColumnOrders)
	{
		if (const FProperty* Prop = FindProp(TemplateClass.Get(), Column))
		{
			StructProps.Add(Prop);
		}
	}

    TSharedRef<FSlateFontMeasure> FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
    const FTextBlockStyle& CellTextStyle = FAppStyle::GetWidgetStyle<FTextBlockStyle>("DataTableEditor.CellText");
    static constexpr float CellPadding = 20.0f;

    // Populate the column data
    OutAvailableColumns.Reset(StructProps.Num());
    for (int32 Index = 0; Index < StructProps.Num(); ++Index)
    {
        const FProperty* Prop = StructProps[Index];
        const FText PropertyDisplayName = DataTableUtils::GetPropertyDisplayName(
            Prop, FName::NameToDisplayString(Prop->GetName(), Prop->IsA<FBoolProperty>()));

        FDataTableEditorColumnHeaderDataPtr CachedColumnData;

        // If at all possible, attempt to reuse previous columns if their data has not changed
        if (Index >= OldColumns.Num()
        	|| OldColumns[Index]->ColumnId != Prop->GetFName()
        	|| !OldColumns[Index]->DisplayName.EqualTo(PropertyDisplayName))
        {
            CachedColumnData = MakeShareable(new FDataTableEditorColumnHeaderData());
            CachedColumnData->ColumnId = Prop->GetFName();
            CachedColumnData->DisplayName = PropertyDisplayName;
            CachedColumnData->Property = Prop;
        }
        else
        {
            CachedColumnData = OldColumns[Index];

            // Need to update property hard pointer in case it got reconstructed
            CachedColumnData->Property = Prop;
        }

        CachedColumnData->DesiredColumnWidth = FontMeasure->Measure(CachedColumnData->DisplayName, CellTextStyle.Font).X
            + CellPadding;

        OutAvailableColumns.Add(CachedColumnData);
    }

	if (ColumnOrders.Num() > 0)
	{
		OutAvailableColumns.Sort([&](const FDataTableEditorColumnHeaderDataPtr& A, const FDataTableEditorColumnHeaderDataPtr& B)
		{
			FString ColumnNameA = A->ColumnId.ToString();
			int32 OrderA = ColumnOrders.IndexOfByPredicate([&ColumnNameA](const FString& Name) { return Name.Equals(ColumnNameA); });

			FString ColumnNameB = B->ColumnId.ToString();
			int32 OrderB = ColumnOrders.IndexOfByPredicate([&ColumnNameB](const FString& Name){ return Name.Equals(ColumnNameB); });
			return OrderA < OrderB;
		});
	}

    if (TemplateClass == UKGSLDialogueLine::StaticClass())
    {
        CacheKGSLDialogueLine(Asset, OutAvailableColumns, OutAvailableRows, OldRows,
                              StructProps, FontMeasure, CellTextStyle, CellPadding);
    }
}

void FKGStoryLineScriptEditor::UpdateVisibleRows(const FName InCachedSelection, const bool bUpdateEvenIfValid)
{
    if (ActiveFilterText.IsEmptyOrWhitespace())
    {
        VisibleRows = AvailableRows;
    }
    else
    {
        VisibleRows.Empty(AvailableRows.Num());

        const FString& ActiveFilterString = ActiveFilterText.ToString();
        for (const FDataTableEditorRowListViewDataPtr& RowData : AvailableRows)
        {
            bool bPassesFilter = false;

            if (RowData->DisplayName.ToString().Contains(ActiveFilterString))
            {
                bPassesFilter = true;
            }
            else
            {
                for (const FText& CellText : RowData->CellData)
                {
                    if (CellText.ToString().Contains(ActiveFilterString))
                    {
                        bPassesFilter = true;
                        break;
                    }
                }
            }

            if (bPassesFilter)
            {
                VisibleRows.Add(RowData);
            }
        }
    }

    CellsListView->RequestListRefresh();
    RestoreCachedSelection(InCachedSelection, bUpdateEvenIfValid);
}

FText FKGStoryLineScriptEditor::GetFilterText() const
{
    return ActiveFilterText;
}

void FKGStoryLineScriptEditor::OnFilterTextChanged(const FText& InFilterText)
{
    ActiveFilterText = InFilterText;
    UpdateVisibleRows();
}

void FKGStoryLineScriptEditor::OnFilterTextCommitted(const FText& NewText, ETextCommit::Type CommitInfo)
{
    if (CommitInfo == ETextCommit::OnCleared)
    {
        SearchBoxWidget->SetText(FText::GetEmpty());
        OnFilterTextChanged(FText::GetEmpty());
    }
}


FSlateColor FKGStoryLineScriptEditor::GetRowTextColor(FName RowName) const
{
    if (RowName == HighlightedRowName)
    {
        return FSlateColor(FColorList::Orange);
    }
    return FSlateColor::UseForeground();
}

FText FKGStoryLineScriptEditor::GetCellText(FDataTableEditorRowListViewDataPtr InRowDataPointer,
                                            int32 ColumnIndex) const
{
	
    if (InRowDataPointer.IsValid() && ColumnIndex < InRowDataPointer->CellData.Num())
    {
        return InRowDataPointer->CellData[ColumnIndex];
    }

    return FText();
}

FText FKGStoryLineScriptEditor::GetCellToolTipText(FDataTableEditorRowListViewDataPtr InRowDataPointer,
                                                   int32 ColumnIndex) const
{
    FText TooltipText;

    if (ColumnIndex < AvailableColumns.Num())
    {
        TooltipText = AvailableColumns[ColumnIndex]->DisplayName;
    }

    if (InRowDataPointer.IsValid() && ColumnIndex < InRowDataPointer->CellData.Num())
    {
        TooltipText = FText::Format(LOCTEXT("ColumnRowNameFmt", "{0}: {1}"),
                                    TooltipText, InRowDataPointer->CellData[ColumnIndex]);
    }

    return TooltipText;
}

float FKGStoryLineScriptEditor::GetRowNameColumnWidth() const
{
    return RowNameColumnWidth;
}

void FKGStoryLineScriptEditor::RefreshRowNameColumnWidth()
{
    TSharedRef<FSlateFontMeasure> FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
    const FTextBlockStyle& CellTextStyle = FAppStyle::GetWidgetStyle<FTextBlockStyle>("DataTableEditor.CellText");
    static constexpr float CellPadding = 10.0f;

    for (const FDataTableEditorRowListViewDataPtr& RowData : AvailableRows)
    {
        const float RowNameWidth = (float)FontMeasure->Measure(RowData->DisplayName, CellTextStyle.Font).X +
            CellPadding;
        RowNameColumnWidth = FMath::Max(RowNameColumnWidth, RowNameWidth);
    }
}

float FKGStoryLineScriptEditor::GetRowNumberColumnWidth() const
{
    return RowNumberColumnWidth;
}

void FKGStoryLineScriptEditor::RefreshRowNumberColumnWidth()
{
    TSharedRef<FSlateFontMeasure> FontMeasure = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
    const FTextBlockStyle& CellTextStyle = FAppStyle::GetWidgetStyle<FTextBlockStyle>("DataTableEditor.CellText");

    for (const FDataTableEditorRowListViewDataPtr& RowData : AvailableRows)
    {
        constexpr float CellPadding = 10.0f;
        const float RowNumberWidth = (float)FontMeasure->Measure(FString::FromInt(RowData->RowNum), CellTextStyle.Font).
                                                         X + CellPadding;
        RowNumberColumnWidth = FMath::Max(RowNumberColumnWidth, RowNumberWidth);
    }
}

float FKGStoryLineScriptEditor::GetColumnWidth(const int32 ColumnIndex) const
{
    if (ColumnWidths.IsValidIndex(ColumnIndex))
    {
        return ColumnWidths[ColumnIndex].CurrentWidth;
    }
    return 0.0f;
}

void FKGStoryLineScriptEditor::OnColumnResized(const float NewWidth, const int32 ColumnIndex)
{
    if (ColumnWidths.IsValidIndex(ColumnIndex))
    {
        FColumnWidth& ColumnWidth = ColumnWidths[ColumnIndex];
        ColumnWidth.bIsAutoSized = false;
        ColumnWidth.CurrentWidth = NewWidth;

        // Update the persistent column widths in the layout data
        {
            if (!LayoutData.IsValid())
            {
                LayoutData = MakeShareable(new FJsonObject());
            }

            TSharedPtr<FJsonObject> LayoutColumnWidths;
            if (!LayoutData->HasField(TEXT("ColumnWidths")))
            {
                LayoutColumnWidths = MakeShareable(new FJsonObject());
                LayoutData->SetObjectField(TEXT("ColumnWidths"), LayoutColumnWidths);
            }
            else
            {
                LayoutColumnWidths = LayoutData->GetObjectField(TEXT("ColumnWidths"));
            }

            const FString& ColumnName = AvailableColumns[ColumnIndex]->ColumnId.ToString();
            LayoutColumnWidths->SetNumberField(ColumnName, NewWidth);
        }
    }
}

void FKGStoryLineScriptEditor::OnRowNameColumnResized(const float NewWidth)
{
    RowNameColumnWidth = NewWidth;
}

void FKGStoryLineScriptEditor::OnRowNumberColumnResized(const float NewWidth)
{
    RowNumberColumnWidth = NewWidth;
}

void FKGStoryLineScriptEditor::SetDefaultSort()
{
    SortMode = EColumnSortMode::Ascending;
    SortByColumn = RowNameColumnId;
}


EColumnSortMode::Type FKGStoryLineScriptEditor::GetColumnSortMode(const FName ColumnId) const
{
    if (SortByColumn != ColumnId)
    {
        return EColumnSortMode::None;
    }

    return SortMode;
}

void FKGStoryLineScriptEditor::OnColumnSortModeChanged(const EColumnSortPriority::Type SortPriority,
                                                       const FName& ColumnId, const EColumnSortMode::Type InSortMode)
{
    int32 ColumnIndex;

    SortMode = InSortMode;
    SortByColumn = ColumnId;

    for (ColumnIndex = 0; ColumnIndex < AvailableColumns.Num(); ++ColumnIndex)
    {
        if (AvailableColumns[ColumnIndex]->ColumnId == ColumnId)
        {
            break;
        }
    }

    if (AvailableColumns.IsValidIndex(ColumnIndex))
    {
        if (InSortMode == EColumnSortMode::Ascending)
        {
            VisibleRows.Sort([ColumnIndex](const FDataTableEditorRowListViewDataPtr& first,
                                           const FDataTableEditorRowListViewDataPtr& second)
            {
                int32 Result = (first->CellData[ColumnIndex].ToString()).Compare(
                    second->CellData[ColumnIndex].ToString());

                if (!Result)
                {
                    return first->RowNum < second->RowNum;
                }

                return Result < 0;
            });
        }
        else if (InSortMode == EColumnSortMode::Descending)
        {
            VisibleRows.Sort([ColumnIndex](const FDataTableEditorRowListViewDataPtr& first,
                                           const FDataTableEditorRowListViewDataPtr& second)
            {
                int32 Result = (first->CellData[ColumnIndex].ToString()).Compare(
                    second->CellData[ColumnIndex].ToString());

                if (!Result)
                {
                    return first->RowNum > second->RowNum;
                }

                return Result > 0;
            });
        }
    }

    CellsListView->RequestListRefresh();
}

void FKGStoryLineScriptEditor::OnColumnNumberSortModeChanged(const EColumnSortPriority::Type SortPriority,
                                                             const FName& ColumnId,
                                                             const EColumnSortMode::Type InSortMode)
{
    SortMode = InSortMode;
    SortByColumn = ColumnId;

    if (InSortMode == EColumnSortMode::Ascending)
    {
        VisibleRows.Sort([](const FDataTableEditorRowListViewDataPtr& first,
                            const FDataTableEditorRowListViewDataPtr& second)
        {
            return first->RowNum < second->RowNum;
        });
    }
    else if (InSortMode == EColumnSortMode::Descending)
    {
        VisibleRows.Sort([](const FDataTableEditorRowListViewDataPtr& first,
                            const FDataTableEditorRowListViewDataPtr& second)
        {
            return first->RowNum > second->RowNum;
        });
    }

    CellsListView->RequestListRefresh();
}

void FKGStoryLineScriptEditor::OnColumnNameSortModeChanged(const EColumnSortPriority::Type SortPriority,
                                                           const FName& ColumnId,
                                                           const EColumnSortMode::Type InSortMode)
{
    SortMode = InSortMode;
    SortByColumn = ColumnId;

    if (InSortMode == EColumnSortMode::Ascending)
    {
        VisibleRows.Sort([](const FDataTableEditorRowListViewDataPtr& first,
                            const FDataTableEditorRowListViewDataPtr& second)
        {
            return (first->DisplayName).ToString() < (second->DisplayName).ToString();
        });
    }
    else if (InSortMode == EColumnSortMode::Descending)
    {
        VisibleRows.Sort([](const FDataTableEditorRowListViewDataPtr& first,
                            const FDataTableEditorRowListViewDataPtr& second)
        {
            return (first->DisplayName).ToString() > (second->DisplayName).ToString();
        });
    }

    CellsListView->RequestListRefresh();
}

FReply FKGStoryLineScriptEditor::OnMoveRowClicked(FDataTableEditorUtils::ERowMoveDirection MoveDirection)
{
    if (!CanEditScript())
    {
        return FReply::Handled();
    }

    if (UDialogueAsset* Asset = GetEditingAsset())
    {
        UKGStoryLineEditorSubSystem::MoveRow(Asset, EditingEpisodeID, RowId2LineIndex(HighlightedRowName),
                                             MoveDirection);
    }
    return FReply::Handled();
}

FReply FKGStoryLineScriptEditor::OnMoveToExtentClicked(FDataTableEditorUtils::ERowMoveDirection MoveDirection)
{
    if (UDialogueAsset* Asset = GetEditingAsset())
    {
        UKGStoryLineEditorSubSystem::MoveRow(Asset, EditingEpisodeID, RowId2LineIndex(HighlightedRowName),
                                             MoveDirection);
        UKGStoryLineEditorSubSystem::SelectLine(Asset, EditingEpisodeID, HighlightedRowName);

        SetDefaultSort();
    }
    return FReply::Handled();
}

void FKGStoryLineScriptEditor::OnAddClicked()
{
    if (UDialogueAsset* Asset = GetEditingAsset())
    {
        if (UKGStoryLineEditorSubSystem::AddLine(Asset, EditingEpisodeID))
        {
            SetDefaultSort();
        }
    }
}

void FKGStoryLineScriptEditor::OnRemoveClicked()
{
    DeleteSelectedLine();
}


void FKGStoryLineScriptEditor::OnCopyClicked()
{
    if (GetEditingAsset())
    {
        CopySelectedLine();
    }
}

void FKGStoryLineScriptEditor::OnPasteClicked()
{
    Paste();
}

void FKGStoryLineScriptEditor::OnDuplicateClicked()
{
    if (GetEditingAsset())
    {
        DuplicateSelectedLine();
    }
}


void FKGStoryLineScriptEditor::RestoreCachedSelection(const FName InCachedSelection, const bool bUpdateEvenIfValid)
{
    // Validate the requested selection to see if it matches a known row
    bool bSelectedRowIsValid = false;
    if (!InCachedSelection.IsNone())
    {
        bSelectedRowIsValid = VisibleRows.ContainsByPredicate(
            [&InCachedSelection](const FDataTableEditorRowListViewDataPtr& RowData) -> bool
            {
                return RowData->RowId == InCachedSelection;
            });
    }

    // Apply the new selection (if required)
    if (!bSelectedRowIsValid)
    {
        SetHighlightedRow((VisibleRows.Num() > 0) ? VisibleRows[0]->RowId : NAME_None);
        CallbackOnLineHighlighted.ExecuteIfBound(HighlightedRowName);
    }
    else if (bUpdateEvenIfValid)
    {
        SetHighlightedRow(InCachedSelection);
        CallbackOnLineHighlighted.ExecuteIfBound(HighlightedRowName);
    }
}

void FKGStoryLineScriptEditor::FillToolbar(FToolBarBuilder& ToolbarBuilder)
{
    ToolbarBuilder.BeginSection("DataTableCommands");
    {
        ToolbarBuilder.AddToolBarButton(
            FUIAction(FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::OnAddClicked)),
            NAME_None,
            LOCTEXT("AddIconText", "Add"),
            LOCTEXT("AddRowToolTip_KGStoryLineScriptEditor", "Add a new lien to the script"),
            FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Plus"));
        ToolbarBuilder.AddToolBarButton(
            FUIAction(
                FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::OnCopyClicked),
                FCanExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::CanEditScript)),
            NAME_None,
            LOCTEXT("CopyIconText", "Copy"),
            LOCTEXT("CopyToolTip_KGStoryLineScriptEditor", "Copy the currently selected line"),
            FSlateIcon(FAppStyle::GetAppStyleSetName(), "GenericCommands.Copy"));
        ToolbarBuilder.AddToolBarButton(
            FUIAction(
                FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::OnPasteClicked),
                FCanExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::CanPaste)),
            NAME_None,
            LOCTEXT("PasteIconText", "Paste"),
            LOCTEXT("PasteToolTip_KGStoryLineScriptEditor", "Paste on the currently selected line"),
            FSlateIcon(FAppStyle::GetAppStyleSetName(), "GenericCommands.Paste"));
        ToolbarBuilder.AddToolBarButton(
            FUIAction(
                FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::OnDuplicateClicked),
                FCanExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::CanEditScript)),
            NAME_None,
            LOCTEXT("DuplicateIconText", "Duplicate"),
            LOCTEXT("DuplicateToolTip_KGStoryLineScriptEditor", "Duplicate the currently selected line"),
            FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Duplicate"));
        ToolbarBuilder.AddToolBarButton(
            FUIAction(
                FExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::OnRemoveClicked),
                FCanExecuteAction::CreateSP(this, &FKGStoryLineScriptEditor::CanEditScript)),
            NAME_None,
            LOCTEXT("RemoveRowIconText", "Remove"),
            LOCTEXT("RemoveRowToolTip_KGStoryLineScriptEditor", "Remove the currently selected line from the script"),
            FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Delete"));
    }
    ToolbarBuilder.EndSection();
}

int32 FKGStoryLineScriptEditor::RowId2LineIndex(const FName RowID)
{
    int32 Index = FCString::Atoi(*RowID.ToString()) - 1;
    if (Index < 0)
    {
        Index = 0;
    }

    return Index;
}

FName FKGStoryLineScriptEditor::LineIndex2RowId(int32 LineIndex)
{
    // LineIndex starts from 0, but RowID starts from 1
    return FName(FString::FromInt(LineIndex + 1));
}


void FKGStoryLineScriptEditor::HandleFieldOrderChanged()
{
	LoadLayoutData();
	RefreshCachedLine(NAME_None, true);	
}



#undef LOCTEXT_NAMESPACE

#pragma optimize("", on)
