#include "DialogueEditor/TabFactory/SDialogueEditorDetailTab.h"

#include "DialogueEditor/Dialogue/Actions/DialogueAutoCameraCut.h"
#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "Engine/Selection.h"
#include "Modules/ModuleManager.h"
#include "PropertyEditorModule.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorDelegates.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/DialogueEditorEnums.h"
#include "LevelSequence.h"
#include "MovieScene.h"
#include "DialogueEditor/Dialogue/Actions/DialogueAnimation.h"
#include "DialogueEditor/Dialogue/Actions/DialogueShotAction.h"
#include "Misc/MessageDialog.h"


void SDialogueEditorDetailTab::Construct(const FArguments& InArgs)
{
	FDetailsViewArgs DetailsViewArgs;
	DetailsViewArgs.NameAreaSettings = FDetailsViewArgs::HideNameArea;
	DetailsViewArgs.bHideSelectionTip = true;
	DetailsViewArgs.DefaultsOnlyVisibility = EEditDefaultsOnlyNodeVisibility::Show;

	FPropertyEditorModule& PropertyEditorModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	DetailsView = PropertyEditorModule.CreateDetailView(DetailsViewArgs);
	DetailsView->OnFinishedChangingProperties().AddSP(this, &SDialogueEditorDetailTab::OnFinishedChangingProperties);

	TSharedRef<SVerticalBox> Content = SNew(SVerticalBox);

	if (InArgs._TopContent.IsValid())
	{
		Content->AddSlot()
		.AutoHeight()
		[
			InArgs._TopContent.ToSharedRef()
		];
	}

	Content->AddSlot()
	.FillHeight(1.0f)
	[
		DetailsView.ToSharedRef()
	];

	if (InArgs._BottomContent.IsValid())
	{
		Content->AddSlot()
		.AutoHeight()
		[
			InArgs._BottomContent.ToSharedRef()
		];
	}

	ChildSlot
	[
		Content
	];
}

void SDialogueEditorDetailTab::SetDetailObject(UObject* InObject)
{
	if(InObject == nullptr)
		DetailsView->SetObject(nullptr);
	if (UDialogueSpawnableTrack* DialogueSpawnableTrack = Cast<UDialogueSpawnableTrack>(InObject))
	{
		if (UDialogueEntity* DialogueEntity = DialogueSpawnableTrack->GetDialogueEntity())
		{
			if (UDialogueActor* DialogueActor = Cast<UDialogueActor>(DialogueEntity))
			{
				if (DialogueEditor.IsValid())
				{
					DialogueActor->IdleAnimLibAssetID.SetAnimID(DialogueEditor.Pin()->GetDialogueEditorManager()->GetAnimIDByAppearanceID(DialogueActor->AppearanceID));
				}
			}
			DialogueEntity->SetFlags(RF_Transactional);
			DetailsView->SetObject(DialogueEntity);
		}
	}
	else if (UDialogueActionBase* DialogueActionSection = Cast<UDialogueActionBase>(InObject))
	{
		if (DialogueEditor.IsValid() && DialogueActionSection->IsA<UDialogueAnimation>())
		{
			if (FProperty* AnimLibItem = DialogueActionSection->GetClass()->FindPropertyByName(TEXT("AnimLibItem")))
			{
				if (const FStructProperty* StructProperty = CastField<FStructProperty>(AnimLibItem))
				{
					if (StructProperty->Struct->IsChildOf(FAnimLibAssetID::StaticStruct()))
					{
						void* DataAddress = AnimLibItem->ContainerPtrToValuePtr<void>(DialogueActionSection);
						if (FAnimLibAssetID* AnimLibAssetID = static_cast<FAnimLibAssetID*>(DataAddress))
						{
							AnimLibAssetID->SetAnimID(DialogueEditor.Pin()->GetDialogueEditorManager()->GetAnimIDByActionSection(DialogueActionSection));
						}
					}
				}
			}
		    
		    if (UDialogueAnimation* AnimSection = Cast<UDialogueAnimation>(InObject))
		    {
		        AnimSection->OnPreDetailShown();
		    }
		}
		DialogueActionSection->OnSectionDataChange.BindSP(this, &SDialogueEditorDetailTab::OnChangeSectionData);
		DetailsView->SetObject(DialogueActionSection);
	}
}

void SDialogueEditorDetailTab::OnFinishedChangingProperties(const FPropertyChangedEvent& PropertyChangedEvent)
{
	const TArray<TWeakObjectPtr<UObject>>& SelectedObjects = DetailsView->GetSelectedObjects();
	if (SelectedObjects.Num() == 0)
	{
		return;
	}

	if (SelectedObjects.Num() > 1)
	{
		FString Msg = TEXT("不能同时编辑多个轨道!");;
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Msg));
		return;
	}

	UObject* SelectedObject = SelectedObjects[0].Get();
	if (!IsValid(SelectedObject))
	{
		return;
	}
	
	FString PropName = PropertyChangedEvent.GetPropertyName().ToString();

	if (UDialogueEditorManager* DialogueEditorManager = DialogueEditor.Pin()->GetDialogueEditorManager())
	{
		DialogueEditorManager->OnObjectFinishChangeProperty(SelectedObject, PropName,
			PropertyChangedEvent.GetNumObjectsBeingEdited() > 0 ? PropertyChangedEvent.GetObjectBeingEdited(0) : nullptr);
	}

	UObject* EditObject = SelectedObject;
	if (PropertyChangedEvent.GetNumObjectsBeingEdited() > 0)
	{
		EditObject = const_cast<UObject*>(PropertyChangedEvent.GetObjectBeingEdited(0));
	}
	
	if (UDialogueEntity* DialogueEntity = Cast<UDialogueEntity>(EditObject))
	{
		// 对于Actor属性编辑有两个地方,资产左侧Detail中的面板,以及选中具体的ActorTrack后右侧的Detail面板,二者需要互相同步
		if (PropName.Equals("AppearanceID") || PropName.Equals("IdleAnimLibAssetID") || PropName.Equals("bIsPlayer") || PropName.Equals("UseSceneActor"))
		{
			UDialogueActor* DialogueActor = Cast<UDialogueActor>(SelectedObject);
			if (DialogueActor && PropName.Equals("AppearanceID"))
			{
				DialogueActor->IdleAnimLibAssetID.SetAnimID(DialogueEditor.Pin()->GetDialogueEditorManager()->GetAnimIDByAppearanceID(DialogueActor->AppearanceID));
			}
			CopyTrackActorInfo(PropName, DialogueActor);
		}
		
		DialogueEditor.Pin()->GetDialogueEditorManager()->OnEntityInfoChange(DialogueEntity, PropName);
		if (const UDialogueCamera* CameraEntity = Cast<UDialogueCamera>(DialogueEntity))
		{
			if (ACameraActor* CameraActor = CameraEntity->GetCamera())
			{
				if (DialogueEditor.Pin()->ClickCameraEntity.Get() == CameraEntity)
				{
					DialogueEditor.Pin()->SetViewportParamByCameraActor(CameraActor);	
				}
			}
		}
		GEditor->NoteSelectionChange();
	}
	else if (UDialogueShotAction* DialogueShotAction = Cast<UDialogueShotAction>(EditObject))
	{
		if (PropName.Equals("TargetCamera"))
		{
			DetailsView->ForceRefresh();
		}
	}
}

void SDialogueEditorDetailTab::OnChangeSectionData(class UDialogueActionBase* DialogueActionSection, FName PropertyName)
{
	if (DialogueActionSection)
	{
		if(UDialogueAutoCameraCut* CameraCut = Cast<UDialogueAutoCameraCut>(DialogueActionSection))
		{
			FString ProName = PropertyName.ToString();
			if (ProName.Contains("Actor1P") || ProName.Contains("Actor2P") || ProName.Contains("DepthOfFieldFocusActor"))
				FDialogueEditorDelegates::SectionInstanceNoticeLua.Broadcast(CameraCut, AutoCameraEvent::UpdateCameraParam);
			else if(ProName.Contains("AutoCameraType") || ProName.Contains("OnePersonTemplate")|| ProName.Contains("TwoPersonTypeOneTemplate")
				|| ProName.Contains("TwoPersonTypeTwoTemplate"))
			{
				FDialogueEditorDelegates::SectionInstanceNoticeLua.Broadcast(CameraCut, AutoCameraEvent::UpdateCameraTemplate);
				TMap<FString, FString> AutoCameraTableData;
				if(CameraCut->AutoCameraType == EDialogueAutoCameraType::OneActor)
				{
					AutoCameraTableData =  DialogueEditor.Pin()->GetDialogueEditorManager()->GetAutoCameraTableData(static_cast<int32>(CameraCut->AutoCameraType), static_cast<int32>(CameraCut->OnePersonTemplate));
				}
				else if(CameraCut->AutoCameraType == EDialogueAutoCameraType::TwoActorTypeOne)
				{
					AutoCameraTableData = DialogueEditor.Pin()->GetDialogueEditorManager()->GetAutoCameraTableData(static_cast<int32>(CameraCut->AutoCameraType), static_cast<int32>(CameraCut->TwoPersonTypeOneTemplate));
				}
				else
				{
					AutoCameraTableData = DialogueEditor.Pin()->GetDialogueEditorManager()->GetAutoCameraTableData(static_cast<int32>(CameraCut->AutoCameraType), static_cast<int32>(CameraCut->TwoPersonTypeTwoTemplate));
				}
#if WITH_EDITOR
				CameraCut->OnSetTableData(AutoCameraTableData);
#endif
				
			}
		}
		if(DialogueActionSection->GetName().Contains("BPS_DialogueSequenceCut"))
		{
			if(PropertyName.ToString() == TEXT("SequenceAssetID"))
			{
				UClass* ObjClass = DialogueActionSection->GetClass();
				if (FIntProperty* IntProperty = FindFieldChecked<FIntProperty>(ObjClass, TEXT("SequenceAssetID")))
				{
					void* PropertyAddress = IntProperty->ContainerPtrToValuePtr<void>(DialogueActionSection);
					if (PropertyAddress)
					{
						int32 SequenceAssetID = IntProperty->GetPropertyValue(PropertyAddress);
						FString SequencePath = DialogueEditor.Pin()->GetDialogueEditorManager()->GetDialogueSequenceTableData(SequenceAssetID);
						ULevelSequence* LevelSequence = LoadObject<ULevelSequence>(nullptr, *SequencePath);

						if (LevelSequence)
						{
							UMovieScene* MovieScene = LevelSequence->GetMovieScene();
							if (MovieScene)
							{
								TRange<FFrameNumber> PlayRange = MovieScene->GetPlaybackRange();
								const FFrameRate TickResolution = MovieScene->GetTickResolution();

								float Duration = (PlayRange.GetUpperBoundValue() - PlayRange.GetLowerBoundValue()) / TickResolution;
								DialogueActionSection->SetDuration(Duration);
							}
						}
					}
				}
			}
		}
		if (PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UDialogueActionBase, StartTime) ||
			PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UDialogueActionBase, Duration))
		{
			if (UDialogueActionTrack* DialogueAction = DialogueActionSection->GetDialogueAction())
			{
				if (!GetDefault<UDialogueEditorSettings>()->EnableSectionOverlap)
				{
					DialogueAction->AdjustOtherSectionData(DialogueActionSection);
				}
			}
		}
	}
}

void SDialogueEditorDetailTab::CopyTrackActorInfo(const FString& PropName, const UDialogueActor* DialogueActor)
{
	if (!IsValid(DialogueActor))
	{
		return;
	}

	UDialogueAsset* DialogueAsset = DialogueEditor.Pin()->GetDialogueAsset();
	if (!IsValid(DialogueAsset))
	{
		return;
	}

	for (auto& ActorInfo : DialogueAsset->ActorInfos)
	{
		if (ActorInfo.PerformerName == DialogueActor->TrackName)
		{
			if (PropName.Equals("AppearanceID"))
			{
				if (ActorInfo.AppearanceID.ApperanceID != DialogueActor->AppearanceID)
				{
					ActorInfo.AppearanceID.ApperanceID = DialogueActor->AppearanceID;
				}
				ActorInfo.IdleAnimation.SetAnimID(DialogueActor->IdleAnimLibAssetID.AnimID);
			}
			else if (PropName.Equals("IdleAnimLibAssetID"))
			{
				if (ActorInfo.IdleAnimation.AssetID != DialogueActor->IdleAnimLibAssetID.AssetID)
				{
					ActorInfo.IdleAnimation.SetAssetID(DialogueActor->IdleAnimLibAssetID.AssetID);
				}
				ActorInfo.IdleAnimation.SetAnimID(DialogueActor->IdleAnimLibAssetID.AnimID);
			}
			else if (PropName.Equals("bIsPlayer"))
			{
				if (ActorInfo.bIsPlayer != DialogueActor->IsPlayer())
				{
					ActorInfo.bIsPlayer = DialogueActor->IsPlayer();
				}
			}
			else if (PropName.Equals("UseSceneActor"))
			{
				if (ActorInfo.UseSceneActor != DialogueActor->UseSceneActor)
				{
					ActorInfo.UseSceneActor = DialogueActor->UseSceneActor;
				}
			}
		}
	}
}
