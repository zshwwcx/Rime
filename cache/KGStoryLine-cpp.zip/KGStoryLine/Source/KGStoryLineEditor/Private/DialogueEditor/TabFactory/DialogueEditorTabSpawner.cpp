#include "DialogueEditor/Modes/DialogueEditorMode.h"

#include "DialogueEditor/TabFactory/SDialogueEditorDetailTab.h"
#include "DialogueEditor/TabFactory/SDialogueEditorAssetViewers.h"
#include "DialogueEditor/TabFactory/SDialogueEditorTimelineTab.h"
#include "DialogueEditor/TabFactory/SDialogueEditorAssetBrowserTab.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorPreviewSettings.h"
#include "DialogueEditor/Widgets/KGSLSOptionConditionWindow.h"
#include "DialogueEditor/Graph/SEpisodeGraph.h"
#include "DialogueEditor/TabFactory/SDialogueEditorOperationPanel.h"


#define DECLARE_TAB_SUMMONER_BEGIN(SummonerName, TabIdentify) \
struct SummonerName : public FWorkflowTabFactory \
{ \
public: \
	static TSharedRef<class FWorkflowTabFactory> Create(const TSharedRef<class FWorkflowCentricApplication>& InHostingApp) \
	{ \
		return MakeShareable(new SummonerName(InHostingApp)); \
	} \
public: \
	SummonerName(TSharedPtr<class FAssetEditorToolkit> InHostingApp) \
		: FWorkflowTabFactory(TabIdentify, InHostingApp) {}

#define DECLARE_TAB_SUMMONER_END };


// 创建时间轴
DECLARE_TAB_SUMMONER_BEGIN(FDialogueAssetEditSummoner, DialogueEditorEditorTabs::AssetEdit)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FDialogueEditor> DialogueEditor = StaticCastSharedPtr<FDialogueEditor>(HostingApp.Pin());
	TSharedRef<SDialogueEditorTimelineTab> TimelineTab = SNew(SDialogueEditorTimelineTab, DialogueEditor);
	DialogueEditor->DialogueEditorTimelineTab = TimelineTab;
	return TimelineTab;
}
DECLARE_TAB_SUMMONER_END

// 创建EpisodeGraph区域
DECLARE_TAB_SUMMONER_BEGIN(FDialogueAssetEpisodeGraph, DialogueEditorEditorTabs::AssetGraph)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FDialogueEditor> DialogueEditor = StaticCastSharedPtr<FDialogueEditor>(HostingApp.Pin());
	return SNew(SEpisodeGraph, DialogueEditor);
}
DECLARE_TAB_SUMMONER_END

// 创建选项编辑器区域
DECLARE_TAB_SUMMONER_BEGIN(FDialogueOptionGraph, DialogueEditorEditorTabs::OptionGraph)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FDialogueEditor> DialogueEditor = StaticCastSharedPtr<FDialogueEditor>(HostingApp.Pin());
	return SNew(KGSLSOptionConditionWindow)
		.DialogueAssetEditing(DialogueEditor->GetDialogueAsset());
}
DECLARE_TAB_SUMMONER_END

// 创建资源属性面板
DECLARE_TAB_SUMMONER_BEGIN(FDialogueAssetDetailSummoner, DialogueEditorEditorTabs::AssetDetails)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FDialogueEditor> DialogueEditor = StaticCastSharedPtr<FDialogueEditor>(HostingApp.Pin());
	return SNew(SDialogueEditorAssetPropertyTabBody, DialogueEditor.ToSharedRef());
}
DECLARE_TAB_SUMMONER_END

// 创建操作区域
DECLARE_TAB_SUMMONER_BEGIN(FDialogueOperationPanel, DialogueEditorEditorTabs::AssetOperationPanel)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FDialogueEditor> DialogueEditor = StaticCastSharedPtr<FDialogueEditor>(HostingApp.Pin());
	return SNew(SDialogueEditorOperationPanel, DialogueEditor.ToSharedRef());
}
DECLARE_TAB_SUMMONER_END



// 创建属性面板
DECLARE_TAB_SUMMONER_BEGIN(FDialogueDetailTabSummoner, DialogueEditorEditorTabs::Details)
TSharedRef<SWidget> CreateTabBody(const FWorkflowTabSpawnInfo& Info) const
{
	TSharedPtr<FDialogueEditor> DialogueEditor = StaticCastSharedPtr<FDialogueEditor>(HostingApp.Pin());

	TSharedPtr<SDialogueEditorDetailTab> DetailsTab = SNew(SDialogueEditorDetailTab);
	DetailsTab->DialogueEditor = DialogueEditor;
	DialogueEditor->SetDetailWidget(DetailsTab);

	return DetailsTab.ToSharedRef();
}
DECLARE_TAB_SUMMONER_END




void FDialogueEditorMode_Main::CreateModeTabs(const TSharedRef<FDialogueEditor> HostingAppPt, FWorkflowAllowedTabSet& OutTabFactories)
{
	OutTabFactories.RegisterFactory(FDialogueAssetEditSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FDialogueAssetDetailSummoner::Create(HostingAppPt));
	
	OutTabFactories.RegisterFactory(FDialogueOperationPanel::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FDialogueDetailTabSummoner::Create(HostingAppPt));
	
	OutTabFactories.RegisterFactory(FDialogueAssetEpisodeGraph::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FDialogueOptionGraph::Create(HostingAppPt));
}

void FDialogueEditorMode_Template::CreateModeTabs(const TSharedRef<FDialogueEditor> HostingAppPt, FWorkflowAllowedTabSet& OutTabFactories)
{
	OutTabFactories.RegisterFactory(FDialogueAssetEditSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FDialogueAssetDetailSummoner::Create(HostingAppPt));

	OutTabFactories.RegisterFactory(FDialogueDetailTabSummoner::Create(HostingAppPt));

}

