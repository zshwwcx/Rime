
#include "DialogueEditor/TabFactory/SDialogueEditorOperationPanel.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorSceneProxy.h"
#include "Application/SlateApplicationBase.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "Widgets/SCanvas.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "SAssetView.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "PropertyCustomizationHelpers.h"
#include "ScopedTransaction.h"


#define LOCTEXT_NAMESPACE "SDialogueEditorTimelineTab"

void SDialogueEditorOperationPanel::Construct(const FArguments& InArgs, TSharedPtr<class FDialogueEditor> InEditor)
{
	DialogueEditor = InEditor;

	TSharedRef<SVerticalBox> VertialBox = SNew(SVerticalBox);

	ConstructCopySymmetryAsset(VertialBox);
	ConstructEditorCommands(VertialBox);

	VertialBox->AddSlot().VAlign(EVerticalAlignment::VAlign_Top).AutoHeight()
		.MaxHeight(30)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			[
			SNew(STextBlock).Text(LOCTEXT("PlayStartDialogueLine", "PlayStartDialogueLine"))
			.ToolTip(FSlateApplicationBase::Get().MakeToolTip(FText::FromString(TEXT("从第几句台词开始播放"))))
			]
			+ SHorizontalBox::Slot().HAlign(EHorizontalAlignment::HAlign_Left)
			[
				SNew(SEditableTextBox)
				.MinDesiredWidth(200.0f)
				.Text(FText::FromString(TEXT("-1")))
				.Font(FAppStyle::Get().GetFontStyle("NormalFontBold"))
				.OnTextCommitted(this, &SDialogueEditorOperationPanel::OnStartDialogueLineCommited)
				.OnTextChanged(this, &SDialogueEditorOperationPanel::OnStartDialogueLineCommited, ETextCommit::Default)
			]
		];
	VertialBox->AddSlot().VAlign(EVerticalAlignment::VAlign_Top).AutoHeight()
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			[
			SNew(STextBlock).Text(LOCTEXT("PlayStartTime", "PlayStartTime"))
			.ToolTip(FSlateApplicationBase::Get().MakeToolTip(FText::FromString(TEXT("填入指定时间点开始预览对话"))))
			]
			+ SHorizontalBox::Slot().HAlign(EHorizontalAlignment::HAlign_Left)
			[
			SNew(SEditableTextBox)
			.MinDesiredWidth(200.0f)
			.Text(FText::FromString(TEXT("0")))
			.Font(FAppStyle::Get().GetFontStyle("NormalFontBold"))
			.OnTextCommitted(this, &SDialogueEditorOperationPanel::OnStartTimeCommited)
			.OnTextChanged(this, &SDialogueEditorOperationPanel::OnStartTimeCommited, ETextCommit::Default)
			]
		];

	this->ChildSlot
		[
		SNew(SBox)
			.Padding(20.0f)
			[
				VertialBox
			]
		];

}

void SDialogueEditorOperationPanel::OnStartTimeCommited(const FText& InText, ETextCommit::Type InCommitType)
{
	DialogueEditor.Pin()->PlayStartTime = FCString::Atof(*InText.ToString());
}

void SDialogueEditorOperationPanel::OnStartDialogueLineCommited(const FText& InText, ETextCommit::Type InCommitType)
{
	DialogueEditor.Pin()->PlayStartDialogueLineIndex = FCString::Atoi(*InText.ToString());
}

void SDialogueEditorOperationPanel::OnSymmetryAssetChanged(const FAssetData& InAssetData)
{
	if (InAssetData.GetAsset())
	{
		CopyAsset = Cast<UDialogueAsset>(InAssetData.GetAsset());
	}
}

bool SDialogueEditorOperationPanel::ShouldSymmetryAssetFilter(const FAssetData& InAssetData)
{
	if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(InAssetData.GetAsset()))
	{
		UDialogueBaseAsset* ToAsset = DialogueEditor.Pin()->GetEditingAsset();
		return DialogueAsset == ToAsset;
	}
	return false;
}

FString SDialogueEditorOperationPanel::GetSymmetryAssetPath() const
{
	if (CopyAsset.IsValid())
	{
		FSoftObjectPath path(CopyAsset.Get());
		return path.GetAssetPathString();
	}
	return TEXT("");
}

FReply SDialogueEditorOperationPanel::OnClickCopySymmetryAssetData()
{
	UDialogueEditorManager* DialogueEditorManager = DialogueEditor.Pin()->GetDialogueEditorManager();

	UDialogueBaseAsset* ToAsset = DialogueEditor.Pin()->GetEditingAsset();
	if (!CopyAsset.IsValid() || ToAsset == nullptr)
		return FReply::Handled();

	{
		FScopedTransaction Transaction(FText::FromString(TEXT("Copy Symmetry Asset")));

		ToAsset->SetFlags(EObjectFlags::RF_Transactional);
		ToAsset->Modify();

		TArray<UDialogueEntity*> AllEntities = ToAsset->GetAllEntities();
		for (UDialogueEntity* Entity : AllEntities)
		{
			Entity->SetFlags(EObjectFlags::RF_Transactional);
			Entity->Modify();
		}

		DialogueEditorManager->CopyDataFromSymmetryAsset(CopyAsset.Get(), ToAsset);
	}


	DialogueEditor.Pin()->GetPreviewScene()->DestroyPreviewActors();
	DialogueEditor.Pin()->GetPreviewScene()->SpawnPreviewActors();
	return FReply::Handled();
}

void SDialogueEditorOperationPanel::ConstructCopySymmetryAsset(TSharedRef<SVerticalBox> VertialBox)
{
	UDialogueEditorManager* DialogueEditorManager = DialogueEditor.Pin()->GetDialogueEditorManager();

	TSharedPtr<SObjectPropertyEntryBox> PropertyEditorAsset;

	SAssignNew(PropertyEditorAsset, SObjectPropertyEntryBox)
		.AllowedClass(UDialogueAsset::StaticClass())
		.OnObjectChanged(this, &SDialogueEditorOperationPanel::OnSymmetryAssetChanged)
		.ObjectPath(this, &SDialogueEditorOperationPanel::GetSymmetryAssetPath)
		.OnShouldFilterAsset(this, &SDialogueEditorOperationPanel::ShouldSymmetryAssetFilter)
		;

	VertialBox->AddSlot().VAlign(EVerticalAlignment::VAlign_Top).AutoHeight()
		.MaxHeight(30)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot().FillWidth(0.3f)
			[
			PropertyEditorAsset.ToSharedRef()
			]
			+ SHorizontalBox::Slot().AutoWidth()
			[
				SNew(SButton).VAlign(EVerticalAlignment::VAlign_Top)
				.Text(FText::FromString(TEXT("拷贝数据")))
				.OnClicked(this, &SDialogueEditorOperationPanel::OnClickCopySymmetryAssetData)
				.ToolTipText(FText::FromString(TEXT("点击将目标资产的数据拷贝到本资产中")))
			]
		];
}

void SDialogueEditorOperationPanel::ConstructEditorCommands(TSharedRef<SVerticalBox> VertialBox)
{
	UDialogueEditorManager* DialogueEditorManager = DialogueEditor.Pin()->GetDialogueEditorManager();

	TArray<FDialogueEditorCommand> Commands;
	if (DialogueEditorManager)
	{
		DialogueEditorManager->GetEditorCommands(Commands);

		for (int i = 0; i < Commands.Num(); ++i)
		{
			FString CommandName = Commands[i].Name;
			FString CommandFunction = Commands[i].HandlerFunction;
			FString CommandCheckVisible = Commands[i].CheckVisibleFunction;
			VertialBox->AddSlot().VAlign(EVerticalAlignment::VAlign_Top).AutoHeight()
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot().AutoWidth()
				[
					SNew(SButton).VAlign(EVerticalAlignment::VAlign_Top)
					.Text(FText::FromString(CommandName))
				.Visibility_Lambda([DialogueEditorManager, CommandCheckVisible]()
					{
						bool Visible = DialogueEditorManager->CallEditorCommand(CommandCheckVisible);
						return Visible ? EVisibility::Visible : EVisibility::Collapsed;
					}
				)
				.OnClicked_Lambda([DialogueEditorManager, CommandFunction]()
					{
						DialogueEditorManager->CallEditorCommand(CommandFunction);
						return FReply::Handled();
					})
				]
				];
		}
	}
}

#undef LOCTEXT_NAMESPACE