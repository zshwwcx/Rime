#include "DialogueEditor/TabFactory/SDialogueEditorAssetViewers.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/DialogueEditorManager.h"

#include "DialogueEditor/DialogueEditor.h"
#include "PropertyEditorModule.h"
//#include "DialogueEditorPreviewSettings.h"



#define LOCTEXT_NAMESPACE "DialogueEditorAssetViewers"



void SDialogueEditorAssetPropertyTabBody::Construct(const FArguments& InArgs, TSharedPtr<FDialogueEditor> InEditor)
{
	CachedEditor = InEditor;
	
	SSingleObjectDetailsPanel::Construct(SSingleObjectDetailsPanel::FArguments().HostCommandList(CachedEditor.Pin()->GetToolkitCommands()), true, true);
	
	PropertyView->OnFinishedChangingProperties().AddSP(this, &SDialogueEditorAssetPropertyTabBody::OnFinishedChangingProperties);

	if(UDialogueAsset* Asset = Cast<UDialogueAsset>(GetObjectToObserve()))
	{
		Asset->OnDialogueEpisodeChanged().AddSP(this, &SDialogueEditorAssetPropertyTabBody::OnEpisodeChanged);
		for (FDialogueActorInfo& Info : Asset->ActorInfos)
		{
			Info.IdleAnimation.SetAnimID(CachedEditor.Pin()->GetDialogueEditorManager()->GetAnimIDByAppearanceID(Info.AppearanceID.ApperanceID));
		}
	}
}

UObject* SDialogueEditorAssetPropertyTabBody::GetObjectToObserve() const
{
	if(CachedEditor.IsValid())
	{
		return Cast<UObject>(CachedEditor.Pin()->GetEditingAsset());
	}
	
	return nullptr;
}

TSharedRef<SWidget> SDialogueEditorAssetPropertyTabBody::PopulateSlot(TSharedRef<SWidget> PropertyEditorWidget)
{
	return 
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush(TEXT("Graph.TitleBackground")))
			.HAlign(HAlign_Center)
			.Visibility(this, &SDialogueEditorAssetPropertyTabBody::GetAssetDisplayNameVisibility)
		]
		+ SVerticalBox::Slot()
		.FillHeight(1)
		[
			PropertyEditorWidget
		];
}

EVisibility SDialogueEditorAssetPropertyTabBody::GetAssetDisplayNameVisibility() const
{
	return (GetObjectToObserve() != NULL) ? EVisibility::Hidden : EVisibility::Collapsed;
}

void SDialogueEditorAssetPropertyTabBody::OnFinishedChangingProperties(const FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.GetPropertyName() == FName(TEXT("AppearanceID")))
	{
		if (UDialogueAsset* DialogueAsset = CachedEditor.Pin()->GetDialogueAsset())
		{
			for (FDialogueActorInfo& Info : DialogueAsset->ActorInfos)
			{
				for (UDialogueActor* DialogueEntity : DialogueAsset->PerformerList)
				{
					if (DialogueEntity->TrackName == Info.PerformerName)
					{
						if (DialogueEntity->AppearanceID != Info.AppearanceID.ApperanceID)
						{
							DialogueEntity->AppearanceID = Info.AppearanceID.ApperanceID;
							Info.IdleAnimation.SetAnimID(CachedEditor.Pin()->GetDialogueEditorManager()->GetAnimIDByAppearanceID(Info.AppearanceID.ApperanceID));
							DialogueEntity->IdleAnimLibAssetID.SetAnimID(Info.IdleAnimation.AnimID);
							
							//更改外观后，由lua进行外观刷新等处理，同时自动设置Animation
							CachedEditor.Pin()->GetDialogueEditorManager()->OnEntityInfoChange(DialogueEntity, PropertyChangedEvent.GetPropertyName().ToString());
							break;
						}
					}
				}
			}
		}
	}
	else if (PropertyChangedEvent.GetPropertyName() == FName(TEXT("IdleAnimation"))
		|| PropertyChangedEvent.GetPropertyName() == FName(TEXT("bIsPlayer")))
	{//DialogueAsset的ActorInfos里面的ApprearaneID
		if (UDialogueAsset* DialogueAsset = CachedEditor.Pin()->GetDialogueAsset())
		{
			for (FDialogueActorInfo& Info : DialogueAsset->ActorInfos)
			{
				for (UDialogueActor* DialogueEntity : DialogueAsset->PerformerList)
				{
					if (DialogueEntity->TrackName == Info.PerformerName)
					{
						bool change = false;
						if (DialogueEntity->IdleAnimLibAssetID.AssetID != Info.IdleAnimation.AssetID)
						{
							DialogueEntity->IdleAnimLibAssetID.SetAssetID(Info.IdleAnimation.AssetID);
							change = true;
						}

						if (DialogueEntity->IsPlayer() != Info.bIsPlayer)
						{
							DialogueEntity->SetIsPlayer(Info.bIsPlayer);
							change = true;
						}
						if (change)
							CachedEditor.Pin()->GetDialogueEditorManager()->OnEntityInfoChange(DialogueEntity, PropertyChangedEvent.GetPropertyName().ToString());
						break;
					}
				}
			}
		}
	}
	CachedEditor.Pin()->GetDialogueEditorManager()->OnAssetPostEdit(CachedEditor.Pin()->GetEditingAsset(), PropertyChangedEvent.GetPropertyName().ToString());
}

void SDialogueEditorAssetPropertyTabBody::OnEpisodeChanged() const
{
	if(PropertyView.IsValid())
	{
		PropertyView->ForceRefresh();
	}
}

FText SDialogueEditorAssetPropertyTabBody::GetAssetDisplayName() const
{
	return LOCTEXT("DialogueAssetProperty", "Asset Properties");
}



void SDialogueEditorSettingsTabBody::Construct(const FArguments& InArgs, TSharedPtr<FDialogueEditor> InEditor)
{
	CachedEditor = InEditor;

	SSingleObjectDetailsPanel::Construct(SSingleObjectDetailsPanel::FArguments().HostCommandList(CachedEditor.Pin()->GetToolkitCommands()), true, true);
}

//UObject* SDialogueEditorSettingsTabBody::GetObjectToObserve() const
//{
//	return Cast<UObject>(CachedEditor.Pin()->GetPreviewSettings());
//}

TSharedRef<SWidget> SDialogueEditorSettingsTabBody::PopulateSlot(TSharedRef<SWidget> PropertyEditorWidget)
{
	return 
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush(TEXT("Graph.TitleBackground")))
			.HAlign(HAlign_Center)
			.Visibility(this, &SDialogueEditorSettingsTabBody::GetAssetDisplayNameVisibility)
		]
		+ SVerticalBox::Slot()
		.FillHeight(1)
		[
			PropertyEditorWidget
		];
}

EVisibility SDialogueEditorSettingsTabBody::GetAssetDisplayNameVisibility() const
{
	return (GetObjectToObserve() != NULL) ? EVisibility::Hidden : EVisibility::Collapsed;
}

FText SDialogueEditorSettingsTabBody::GetAssetDisplayName() const
{
	return LOCTEXT("DialogueEditorSettings", "Editor Settings");
}



#undef LOCTEXT_NAMESPACE
