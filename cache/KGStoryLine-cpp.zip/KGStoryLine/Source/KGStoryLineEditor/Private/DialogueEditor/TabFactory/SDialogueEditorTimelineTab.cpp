#include "DialogueEditor/TabFactory/SDialogueEditorTimelineTab.h"
#include "Widgets/Layout/SSpacer.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SSeparator.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Widgets/TimeLineBase/SAnimTimeline.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"

#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorMenuContext.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/DialogueEditorUtilities.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "ToolMenu.h"
#include "ToolMenus.h"


#define LOCTEXT_NAMESPACE "SDialogueEditorTimelineTab"


void SDialogueEditorEpisode::Construct(const FArguments& InArgs, const TSharedPtr<FDialogueEditor>& InAssetEditorToolkit, const TSharedPtr<SDialogueEditorTimelineTab>& AssetEditWidget, int32 InEpisodeIndex)
{
	CachedEditor = InAssetEditorToolkit;
	CachedEditTab = AssetEditWidget;

	bool bEnableCameraList = false;
	if (const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>())
	{
		if (EditorSettings->bNewLayout)
		{
			bEnableCameraList = true;
		}
	}

	//// 创建时间轴
	TimelineController = MakeShared<FDialogueEditorTimelineController>();
	TimelineController->Initialize(CachedEditor.Pin(), CachedEditor.Pin()->GetPreviewProxy(), InEpisodeIndex);
	TimelineWidget = SNew(SAnimTimeline, TimelineController.ToSharedRef());
	CachedEditor.Pin()->DialogueTimelineController = TimelineController;

	TSharedPtr<SBorder> BodyContent = SNew(SBorder).BorderBackgroundColor(FLinearColor::Transparent);

	if (bEnableCameraList)
	{
		CameraListController = MakeShared<FDialogueEditorTimelineController>();
		CameraListController->TracksRefreshedEvent.AddRaw(this, & SDialogueEditorEpisode::OnCameraListRefreshed);
		TimelineController->TracksRefreshedEvent.AddRaw(this, & SDialogueEditorEpisode::OnNormalListRefreshed);
		CameraListController->Initialize(CachedEditor.Pin(), CachedEditor.Pin()->GetPreviewProxy(), InEpisodeIndex, true);
		CameraListWidget = SNew(SAnimTimeline, CameraListController.ToSharedRef(), true);
		BodyContent->SetContent(
			SNew(SSplitter)
			+ SSplitter::Slot()
			.Value(0.3f)
			[
				SNew(SBox)
				.MinDesiredHeight(370)
				.Padding(FMargin(0, 2, 0, 2))
				.Visibility_Lambda([]
				{
					if (const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>())
					{
						if (EditorSettings->bShowCameraList)
						{
							return EVisibility::Visible;
						}
					}
					return EVisibility::Collapsed;
				})
				[
					CameraListWidget.ToSharedRef()
				]
			]
				
			+ SSplitter::Slot()
			.Value(0.7f)
			[
				SNew(SBox)
				.MinDesiredHeight(370)
				.Padding(FMargin(0, 2, 0, 2))
				[
					TimelineWidget.ToSharedRef()
				]
			]);
	}
	else
	{
		BodyContent->SetContent(
			SNew(SBox)
			.MinDesiredHeight(370)
			.Padding(FMargin(0, 2, 0, 2))
			[
				TimelineWidget.ToSharedRef()
			]);
	}

	TSharedRef<SWidget> SettingsButton = SNew(SComboButton)
			.ComboButtonStyle( FAppStyle::Get(), "SimpleComboButtonWithIcon" ) // Use the tool bar item style for this button
			.OnGetMenuContent( this, &SDialogueEditorEpisode::GetSettingsButtonContent)
			.HasDownArrow(false)
			.ButtonContent()
			[
				SNew(SImage)
				.ColorAndOpacity(FSlateColor::UseForeground())
				.Image( FAppStyle::Get().GetBrush("Icons.Settings") )
			];

	this->ChildSlot
	[
		SNew(SBorder)
		.BorderBackgroundColor( FLinearColor::Transparent )
		.Padding(0.0f)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SBorder)
				.BorderBackgroundColor(FLinearColor::Transparent)
				.Padding(0.0f)
				[
					SNew(SBox)
					.Padding(2.0f)
					[
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
						.VAlign(VAlign_Center)
						.HAlign(HAlign_Left)
						.Padding(2.0f, 1.0f)
						.AutoWidth()
						[
							SNew(SInlineEditableTextBlock)
							.IsReadOnly(true)
							.Text_Raw(this, &SDialogueEditorEpisode::GetEpisodeName)
						]

						+ SHorizontalBox::Slot()
						.VAlign(VAlign_Center)
						.HAlign(HAlign_Left)
						.Padding(10.0f, 1.0f, 2.0f, 1.0f)
						.AutoWidth()
						[
							SNew(STextBlock)
							.Text(FText::FromString(TEXT("Duration:")))
						]

						+ SHorizontalBox::Slot()
						.VAlign(VAlign_Center)
						.HAlign(HAlign_Left)
						.Padding(1.0f, 1.0f)
						.AutoWidth()
						[
							SNew(SEditableTextBox)
							.Text_Raw(this, &SDialogueEditorEpisode::GetEpisodeDuration)
							.OnTextCommitted(this, &SDialogueEditorEpisode::ChangeEpisodeDuration)
						]

						+ SHorizontalBox::Slot()
						.AutoWidth()
						.VAlign(VAlign_Center)
						.HAlign(HAlign_Left)
						.Padding(60.0f, 0.0f)
						[
							SNew(SComboButton)
							.HasDownArrow(false)
							.ButtonStyle(FAppStyle::Get(), "HoverHintOnly")
							.ForegroundColor(FSlateColor::UseForeground())
							.OnGetMenuContent(FOnGetContent::CreateSP(this, &SDialogueEditorEpisode::BuildEpisodeSubMenu))
							.ContentPadding(FMargin(5, 2))
							.HAlign(HAlign_Center)
							.VAlign(VAlign_Center)
							.ButtonContent()
							[
								SNew(SHorizontalBox)
								+ SHorizontalBox::Slot()
								.VAlign(VAlign_Center)
								.Padding(FMargin(0, 0))
								[
									SNew(SImage)
									.ColorAndOpacity(FSlateColor::UseForeground())
									.Image(FAppStyle::GetBrush("ComboButton.Arrow"))
								]
								+ SHorizontalBox::Slot()
								.AutoWidth()
								.VAlign(VAlign_Center)
								.Padding(FMargin(0, 0))
								[
									SNew(STextBlock)
									.Text(LOCTEXT("AddTrack", "Actions"))
								]
							]
						]

						// + SHorizontalBox::Slot()
						// .FillWidth(1.f)

						+ SHorizontalBox::Slot()
						.FillWidth(1.f)
						.VAlign(VAlign_Center)
						.HAlign(HAlign_Right)
						// .Padding(60.0f, 0.0f)
						[
							SettingsButton
						]
					]
				]
			]
			+ SVerticalBox::Slot()
			.FillHeight(1.0f)
			[
				BodyContent.ToSharedRef()
			]
		]
	];
}

void SDialogueEditorEpisode::OnCameraListRefreshed()
{
	// 当相机列表刷新时，需要同步刷新普通列表
	TimelineController->RefreshTracksImplementation(false);
}

void SDialogueEditorEpisode::OnNormalListRefreshed()
{
	CameraListController->RefreshTracksImplementation(false);
}

void SDialogueEditorEpisode::ToggleLayout(bool bNewLayout)
{
	UDialogueEditorPerProjectUserSettings* EditorSettings = GetMutableDefault<UDialogueEditorPerProjectUserSettings>();
	if (EditorSettings->bNewLayout != bNewLayout)
	{
		EditorSettings->bNewLayout = bNewLayout;
		EditorSettings->SaveConfig();
	}
}

bool SDialogueEditorEpisode::IsUsedNewLayout() const
{
	const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>();
	return EditorSettings->bNewLayout;
}

TSharedRef<SWidget> SDialogueEditorEpisode::GetSettingsButtonContent()
{
	RegisterGetSettingsButtonMenu();
	TSharedPtr<FExtender> MenuExtender = MakeShared<FExtender>();
	FMenuBuilder MenuBuilder(true, nullptr, MenuExtender);

	UDialogueEditorTrackMenuContext* Context = NewObject<UDialogueEditorTrackMenuContext>();
	Context->EpisodeView = SharedThis(this);
	FToolMenuContext MenuContext(nullptr, MenuExtender, Context);

	return UToolMenus::Get()->GenerateWidget("DialogueEditor.TrackSettingsOptions", MenuContext);
}

void SDialogueEditorEpisode::RegisterGetSettingsButtonMenu()
{
	if (!UToolMenus::Get()->IsMenuRegistered("DialogueEditor.TrackSettingsOptions"))
	{
		UToolMenu* Menu = UToolMenus::Get()->RegisterMenu("DialogueEditor.TrackSettingsOptions");
		Menu->bCloseSelfOnly = true;
		Menu->AddDynamicSection("DynamicContent", FNewToolMenuDelegate::CreateLambda([](UToolMenu* InMenu)
		{
			if (UDialogueEditorTrackMenuContext* Context = InMenu->FindContext<UDialogueEditorTrackMenuContext>())
			{
				if (Context->EpisodeView.IsValid())
				{
					Context->EpisodeView.Pin()->PopulateSettingsButtonMenu(InMenu);
				}
			}
		}));
	}
}

void SDialogueEditorEpisode::PopulateSettingsButtonMenu(UToolMenu* Menu)
{
	{
		FToolMenuSection& Section = Menu->AddSection("LayoutType", LOCTEXT("LayoutTypeHeading", "布局风格"));
		Section.AddMenuEntry(
			"OldLayout",
			LOCTEXT("OldLayoutOption", "旧"),
			LOCTEXT("OldLayoutOptionToolTip", "点击后需要关闭当前资源再打开才能生效"),
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateSP( this, &SDialogueEditorEpisode::ToggleLayout, false),
				FCanExecuteAction(),
				FIsActionChecked::CreateLambda([]
				{
					const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>();
					return !EditorSettings->bNewLayout;
				})
				),
			EUserInterfaceActionType::RadioButton
			);

		Section.AddMenuEntry(
			"NewLayout",
			LOCTEXT("NewLayoutOption", "新"),
			LOCTEXT("NewLayoutOptionToolTip", "点击后需要关闭当前资源再打开才能生效"),
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateSP( this, &SDialogueEditorEpisode::ToggleLayout, true ),
				FCanExecuteAction(),
				FIsActionChecked::CreateLambda([]
				{
					const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>();
					return EditorSettings->bNewLayout;
				})
				),
			EUserInterfaceActionType::RadioButton
			);
	}
	
	
	{
		FToolMenuSection& Section = Menu->AddSection("CustomPanel", LOCTEXT("CustomPanel", "自定义布局"));
		Section.AddMenuEntry(
				"ToggleCameraListPanel",
				LOCTEXT("ToggleCameraListPanel", "显示镜头列表"),
				LOCTEXT("ToggleCameraListPanel_Tooltip", "显示或者隐藏镜头列表"),
				TAttribute<FSlateIcon>(),
				FUIAction(
					FExecuteAction::CreateLambda([] ()
					{
						UDialogueEditorPerProjectUserSettings* EditorSettings = GetMutableDefault<UDialogueEditorPerProjectUserSettings>();
						EditorSettings->bShowCameraList = !EditorSettings->bShowCameraList;
						EditorSettings->SaveConfig();
					}),
					FCanExecuteAction(),
					FIsActionChecked::CreateLambda([]() -> bool
					{
						const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>();
						return EditorSettings->bShowCameraList;
					}
					)),
				EUserInterfaceActionType::ToggleButton
			);
	}
}

void SDialogueEditorEpisode::ChangeEpisodeDuration(const FText& InText, ETextCommit::Type CommitInfo)
{
	if (InText.IsEmpty())
		return;

	if (UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		Asset->ChangeEpisodeDuration(TimelineController->GetEpisodeID(), FCString::Atof(*InText.ToString()));
	}
}

TSharedRef<SWidget> SDialogueEditorEpisode::BuildEpisodeSubMenu()
{
	FMenuBuilder MenuBuilder(true, nullptr);
	TimelineController->BuildTrackActionMenu(MenuBuilder, false);

	return MenuBuilder.MakeWidget();
}

FText SDialogueEditorEpisode::GetEpisodeName() const
{
	if (UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		if (FDialogueEpisode* DialogueEpisode = Asset->GetEpisodePointerByIndex(TimelineController->GetEpisodeID()))
		{
			return FText::FromString(FString::Printf(TEXT("Episode:%d"), DialogueEpisode->EpisodeID));
		}
	}

	return FText::FromString(TEXT("None"));
}

FText SDialogueEditorEpisode::GetEpisodeDuration() const
{
	if (UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		if (FDialogueEpisode* EpisodePtr = Asset->GetEpisodePointerByIndex(TimelineController->GetEpisodeID()))
		{
			return FText::FromString(FString::SanitizeFloat(EpisodePtr->Duration));
		}
	}

	return FText::FromString(TEXT("1"));
}

void SDialogueEditorEpisode::FillNewTrackMenu(FMenuBuilder& MenuBuilder)
{
	FDialogueEditorUtilities::MakeNewTrackPicker(MenuBuilder, FOnClassPicked::CreateSP(this, &SDialogueEditorEpisode::AddNewTrack));
}

void SDialogueEditorEpisode::AddNewTrack(UClass* InTrackClass)
{
	TimelineController->AddNewTrack(InTrackClass);
}

void SDialogueEditorEpisode::DeleteEpisode()
{
	if (UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		Asset->RemoveEpisode(TimelineController->GetEpisodeID());

		CachedEditTab.Pin()->Update();
	}
}

//====================================================================

void SDialogueEditorTimelineTab::Construct(const FArguments& InArgs, const TSharedPtr<FDialogueEditor>& InAssetEditorToolkit)
{
	CachedEditor = InAssetEditorToolkit;
	this->ChildSlot
	[
		SAssignNew(BorderWidgetArea, SBorder)
		.Visibility(EVisibility::SelfHitTestInvisible)
		.BorderImage(FAppStyle::GetBrush("NoBorder"))
		.Padding(FMargin(0.f, 0.f))
		.ColorAndOpacity(FLinearColor::White)
	];

	Update();
	if (CachedEditor.IsValid())
	{
		CachedEditor.Pin()->GetGenarateDaialogueEvent().AddRaw(this, &SDialogueEditorTimelineTab::Update);
	}
}

void SDialogueEditorTimelineTab::Update()
{
	if (!CachedEditor.IsValid())
		return;
	if (UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		EpisodeWidget.Reset();

		int32 EpisodeIndex = 0;
		if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(Asset))
		{
			const int32 CurrentSelectEpisodeID = DialogueAsset->GetCurrentSelectEpisodeID();
			for (int32 i = 0; i < DialogueAsset->GetEpisodeNum(); i++)
			{
				FDialogueEpisode* Episode = DialogueAsset->GetEpisodePointerByIndex(i);
				if (CurrentSelectEpisodeID == Episode->EpisodeID)
				{
					//找到选中的那个Episode，把它显示在Timeline区域
					EpisodeIndex = i;
					break;
				}
			}
		}
		EpisodeWidget = SNew(SDialogueEditorEpisode, CachedEditor.Pin(), SharedThis(this), EpisodeIndex);
		BorderWidgetArea->SetContent
		(
			EpisodeWidget.ToSharedRef()
		);
	}
}

FReply SDialogueEditorTimelineTab::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	return FReply::Unhandled();
}

FReply SDialogueEditorTimelineTab::OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	return FReply::Unhandled();
}

TSharedPtr<ITimeSliderController> SDialogueEditorTimelineTab::GetAnimTimeSliderController()
{
	if (EpisodeWidget.IsValid() && EpisodeWidget->TimelineWidget.IsValid())
	{
		return EpisodeWidget->TimelineWidget->GetTimeSliderController();
	}
	return nullptr;
}


#undef LOCTEXT_NAMESPACE
