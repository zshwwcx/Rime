#include "DialogueEditor/Widgets/KGSLSOptionConditionWindow.h"
#include "SlateOptMacros.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Editor.h"
#include "SResetToDefaultPropertyEditor.h"
#include "DetailWidgetRow.h"
#include "Modules/ModuleManager.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Input/STextComboBox.h"

#define LOCTEXT_NAMESPACE "KGSLSOptionConditionWindow"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void KGSLSOptionConditionWindow::Construct(const FArguments& InArgs)
{
	DialogueAsset = InArgs._DialogueAssetEditing;
	CurrentEditEpisodeID = DialogueAsset->GetCurrentSelectEpisodeID();

	// 绑定事件
	if (DialogueAsset.IsValid())
	{
		DialogueAsset->OnDialogueEpisodeChanged().AddSP(this, &KGSLSOptionConditionWindow::OnCurrentEditEpisodeChanged);
	}
	
	// 生成选项列表
	GenerateComboOptionsOnCurrentEpisode();
	if (ComboOptions.IsEmpty())
	{
		return;
	}
	
	ConditionComboBox = SNew(STextComboBox)
		.OptionsSource(&ComboOptions)
		.OnSelectionChanged(this, &KGSLSOptionConditionWindow::OnSelectionChanged)
		.InitiallySelectedItem(ComboOptions[0]);
	
	OptionGraph = SNew(SOptionGraph)
		.Condition(Condition)
		.ExtraAction(ExtraAction)
		.EpisodeID(CurrentEditEpisodeID)
		.DialogueLineIndex(DialogueLineIndex)
		.DialogueAssetEditing(DialogueAsset);

	OnSelectionChanged(ComboOptions[0], ESelectInfo::Type::Direct);
	
	ChildSlot
	[
		SAssignNew(GraphContainer, SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.Padding(5.f)
			.AutoWidth()
			[
				ConditionComboBox.ToSharedRef()
			]
		]
		+ SVerticalBox::Slot()
		.FillHeight(1.f)
		[
			OptionGraph.ToSharedRef()
		]
	];
}

void KGSLSOptionConditionWindow::OnCurrentEditEpisodeChanged()
{
	CurrentEditEpisodeID = DialogueAsset->GetCurrentSelectEpisodeID();
	GenerateComboOptionsOnCurrentEpisode();
	if (ComboOptions.IsEmpty())
	{
		return;
	}

	if (ConditionComboBox.IsValid())
	{
		ConditionComboBox->RefreshOptions();
		ConditionComboBox->SetSelectedItem(ComboOptions[0]);	
	}
}

void KGSLSOptionConditionWindow::GenerateComboOptionsOnCurrentEpisode()
{
	UKGSLDialogueEpisode* Episode = DialogueAsset->GetDialogueEpisodeByEpisodeID(CurrentEditEpisodeID);
	if (!Episode)
	{
		return;
	}

	ComboOptions.Empty();
	ComboOptions2Option.Empty();
	for (auto& Option : Episode->Options)
	{
		FString ComboStr = FString::FromInt(Option->Item.ID) + " " + Option->DialogueText;

		int32 SameStrNum = 0;
		for (auto& ComboOption : ComboOptions)
		{
			if (ComboOption->Equals(ComboStr))
			{
				++SameStrNum;	
			}
		}

		if (SameStrNum > 0)
		{
			ComboStr += "_" + FString::FromInt(SameStrNum);
		}
		
		ComboOptions.Add(MakeShared<FString>(ComboStr));
		ComboOptions2Option.Add(ComboStr, Option);
	}
}

void KGSLSOptionConditionWindow::OnSelectionChanged(TSharedPtr<FString> NewSelect, ESelectInfo::Type SelectInfo)
{
	if (!NewSelect.IsValid())
	{
		return;
	}
	
	UKGSLDialogueEpisode* Episode = DialogueAsset->GetDialogueEpisodeByEpisodeID(CurrentEditEpisodeID);
	if (!Episode)
	{
		return;
	}

	UKGSLDialogueOption* NewSelectOption = nullptr;
	if (ComboOptions2Option.Find(*NewSelect))
	{
		NewSelectOption = ComboOptions2Option[*NewSelect].Get();
	}

	if (!NewSelectOption)
	{
		Condition = TEXT("");
		OptionJumpEpisodeID = 0;
		ExtraAction.Empty();
		DialogueLineIndex = 0;
	}
	else
	{
		Condition = NewSelectOption->Condition;
		OptionJumpEpisodeID = NewSelectOption->EpisodeID;
		ExtraAction = NewSelectOption->Item.ExtraAction;
		DialogueLineIndex = NewSelectOption->DialogueLineIndex;
	}

	if (OptionGraph.IsValid())
	{
		OptionGraph->SetCondition(Condition, ExtraAction, OptionJumpEpisodeID, DialogueLineIndex, DialogueAsset);	
	}
}

END_SLATE_FUNCTION_BUILD_OPTIMIZATION

#undef LOCTEXT_NAMESPACE
