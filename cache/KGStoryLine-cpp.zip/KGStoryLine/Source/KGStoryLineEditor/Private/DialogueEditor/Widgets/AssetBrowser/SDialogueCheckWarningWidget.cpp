// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/Widgets/AssetBrowser/SDialogueCheckWarningWidget.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SButton.h"
#include "Framework/Application/SlateApplication.h"

#include "SlateOptMacros.h"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION

void SDialogueCheckWarningWidget::Construct(const FArguments& InArgs)
{
	ChildSlot
	[
		// Populate the widget
		SNew(SBorder)
		.Padding(10)
		.BorderImage(FCoreStyle::Get().GetBrush("ToolPanel.GroupBorder"))
		[
			SNew(SBox)
			.WidthOverride(400.0f)
			[
				SNew(SScrollBox)
				+ SScrollBox::Slot()
				.AutoSize()[
					SNew(SVerticalBox)
					// Error Message Slot
					+ SVerticalBox::Slot()
					.AutoHeight()
					.Padding(0.0f, 0.0f, 0.0f, 10.0f)
					[
						SNew(STextBlock)
						.Text(InArgs._ErrorMessage)
						.ColorAndOpacity(FSlateColor(FLinearColor::Red)) // Set text color to red
						.AutoWrapText(true)
					]
					// Warning Message Slot
					+ SVerticalBox::Slot()
					.AutoHeight()
					[
						SNew(STextBlock)
						.Text(InArgs._WarnMessage)
						.AutoWrapText(true)
					]
					+ SVerticalBox::Slot()
					.AutoHeight()
					.Padding(10.0f, 10.0f, 0.0f, 0.0f)
					[
						SNew(SButton)
						.HAlign(HAlign_Center)
						.Text(FText::FromString("OK"))
						.OnClicked_Lambda([]() -> FReply
						{
							FSlateApplication::Get().GetActiveTopLevelWindow()->RequestDestroyWindow();
							return FReply::Handled();
						})
					]
				]
			]
		]
	];
}

END_SLATE_FUNCTION_BUILD_OPTIMIZATION
