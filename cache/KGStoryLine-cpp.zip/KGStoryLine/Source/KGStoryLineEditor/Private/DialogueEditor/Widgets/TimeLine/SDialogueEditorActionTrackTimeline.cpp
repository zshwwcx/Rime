#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackTimeline.h"

#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueActionTrackEditor.h"
#include "Widgets/Input/SNumericEntryBox.h"
#include "Framework/Application/SlateApplication.h"

#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"

#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTrack.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"

#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineDragDropOp.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueTrackEditor.h"
#include "ScopedTransaction.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorShotActionNode.h"
#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "DialogueEditor/Dialogue/Actions/DialogueShotAction.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "Framework/Notifications/NotificationManager.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "Widgets/SOverlay.h"


#define LOCTEXT_NAMESPACE "SDialogueEditorActionTrackTimeline"



#pragma region Important
void SDialogueEditorActionTrackTimeline::Construct(const FArguments& InArgs)
{
	SetClipping(EWidgetClipping::ClipToBounds);

	CachedEditor = InArgs._CachedEditor;
	CachedTrack = InArgs._Task;

	ViewInputMin = InArgs._ViewInputMin;
	ViewInputMax = InArgs._ViewInputMax;
	InputMin = InArgs._InputMin;
	InputMax = InArgs._InputMax;

	TrackIndex = InArgs._TrackIndex;
	TimelinePlayLength = InArgs._TimelinePlayLength.Get();

	SetInputViewRangeEvent = InArgs._OnSetInputViewRange;

	SelectActionSectionEvent = InArgs._OnSelectActionSection;

	DeleteSectionEvent = InArgs._OnDeleteSection;
	AddNewSectionEvent = InArgs._OnAddNewSection;
	AddNewSecondTypeSectionEvent = InArgs._OnAddNewSecondTypeSection;
	AddCameraSectionAtViewPositionEvent = InArgs._OnAddCameraSectionAtViewPosition;
	this->ChildSlot
		[
			SAssignNew(TrackArea, SBorder)
			.Visibility(EVisibility::SelfHitTestInvisible)
		.BorderImage(FAppStyle::GetBrush("NoBorder"))
		.Padding(FMargin(0.f, 0.f))
		.ColorAndOpacity(FLinearColor::Green)
		];

	UpdateLayout();
}

void SDialogueEditorActionTrackTimeline::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	UpdateCachedGeometry(AllottedGeometry);
}

int32 SDialogueEditorActionTrackTimeline::GetTrackIndex() const
{
	return TrackIndex;
}

TArray<TSharedPtr<SDialogueEditorActionTrackNode>> SDialogueEditorActionTrackTimeline::GetActionNodes() const
{
	return ActionNodes;
}

#pragma endregion Important



#pragma region Render
int32 SDialogueEditorActionTrackTimeline::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	int32 CustomLayerId = LayerId + 1;
	FSlateDrawElement::MakeLines
	(
		OutDrawElements, 
		CustomLayerId, 
		AllottedGeometry.ToPaintGeometry(),
		{ FVector2D(0.0f, AllottedGeometry.GetLocalSize().Y), FVector2D(AllottedGeometry.GetLocalSize().X, AllottedGeometry.GetLocalSize().Y) },
		ESlateDrawEffect::None, 
		FLinearColor(1.0f, 1.0f, 0.1f, 0.6f)
	);

	++CustomLayerId;

	for (int i = 0; i < ActionNodes.Num(); ++i)
	{
		if (!ActionNodes[i]->BeingDragged())
		{
			ActionNodes[i]->UpdateSizeAndPosition(AllottedGeometry);
		}
	}

	FChildren* Children = NodeSlots->GetChildren();
	for (int i = 0; i < Children->Num(); ++i)
	{
		SOverlay::FOverlaySlot* Slot = static_cast<SOverlay::FOverlaySlot*>(const_cast<FSlotBase*>(&Children->GetSlotAt(i)));
		SDialogueEditorActionTrackNode* ParentWidget = static_cast<SDialogueEditorActionTrackNode*>(&Slot->GetWidget().Get());
		Slot->SetPadding(ParentWidget->GetNotifyTrackPadding());
	}

	return SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, CustomLayerId, InWidgetStyle, bParentEnabled);
}

void SDialogueEditorActionTrackTimeline::UpdateLayout()
{
	TrackArea->ClearContent();
	TrackArea->SetContent
	(
		SAssignNew(NodeSlots, SOverlay)
	);
	if (CachedTrack == nullptr)
		return;

	ActionNodes.Empty();

	for (int32 i = 0; i < CachedTrack->ActionSections.Num(); ++i)
	{
		TSharedPtr<SDialogueEditorActionTrackNode> ActionNode;
		UDialogueActionBase* Action = CachedTrack->ActionSections[i];
		if (Action->IsConstant())
		{
			SAssignNew(ActionNode, SDialogueEditorActionTrackSectionNode)
			.CachedEditor(CachedEditor)
			.Track(CachedTrack.Get())
			.Section(CachedTrack->ActionSections[i])
			.ViewInputMin(ViewInputMin)
			.ViewInputMax(ViewInputMax)
			.TimelinePlayLength(TimelinePlayLength)
			.OnStartDragNode(this, &SDialogueEditorActionTrackTimeline::OnNotifyNodeDragStarted)
			.OnDeleteSelectedSection(this, &SDialogueEditorActionTrackTimeline::OnNotifyDeleteSelectedNode)
			.NodeLeftMouseButtonUp(this, &SDialogueEditorActionTrackTimeline::OnNodeLeftMouseButtonUp);
		}
		else
		{
			if (UDialogueShotAction* DialogueShot = Cast<UDialogueShotAction>(Action))
			{
				SAssignNew(ActionNode, SDialogueEditorShotActionNode, SharedThis(this))
				.CachedEditor(CachedEditor)
				.Track(CachedTrack.Get())
				.Section(CachedTrack->ActionSections[i])
				.ViewInputMin(ViewInputMin)
				.ViewInputMax(ViewInputMax)
				.TimelinePlayLength(TimelinePlayLength)
				.OnStartDragNode(this, &SDialogueEditorActionTrackTimeline::OnNotifyNodeDragStarted)
				.OnDeleteSelectedSection(this, &SDialogueEditorActionTrackTimeline::OnNotifyDeleteSelectedNode)
				.NodeLeftMouseButtonUp(this, &SDialogueEditorActionTrackTimeline::OnNodeLeftMouseButtonUp);
				if (DialogueShot->IsSmooth())
				{
					TSharedPtr<SDialogueEditorActionTrackNode> CameraSmoothNode;
					SAssignNew(CameraSmoothNode, SDialogueEditorShotSmoothActionNode)
					.CachedEditor(CachedEditor)
					.Track(CachedTrack.Get())
					.Section(CachedTrack->ActionSections[i])
					.ViewInputMin(ViewInputMin)
					.ViewInputMax(ViewInputMax)
					.TimelinePlayLength(TimelinePlayLength);
					ActionNodes.EmplaceAt(0, CameraSmoothNode);
				}
			}
			else
			{
				SAssignNew(ActionNode, SDialogueEditorActionTrackKeyFrameNode)
				.CachedEditor(CachedEditor)
				.Track(CachedTrack.Get())
				.Section(CachedTrack->ActionSections[i])
				.ViewInputMin(ViewInputMin)
				.ViewInputMax(ViewInputMax)
				.TimelinePlayLength(TimelinePlayLength)
				.OnStartDragNode(this, &SDialogueEditorActionTrackTimeline::OnNotifyNodeDragStarted)
				.OnDeleteSelectedSection(this, &SDialogueEditorActionTrackTimeline::OnNotifyDeleteSelectedNode)
				.NodeLeftMouseButtonUp(this, &SDialogueEditorActionTrackTimeline::OnNodeLeftMouseButtonUp);
			}
		}
		ActionNodes.Add(ActionNode);
	}
	for (auto ActionNode : ActionNodes)
	{
		ActionNode->AddSlotToTimeline(NodeSlots);
	}
}

#pragma endregion Render



#pragma region Menu
TSharedPtr<SWidget> SDialogueEditorActionTrackTimeline::SummonContextMenu(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FVector2D CursorPos = MouseEvent.GetScreenSpacePosition();
	LastClickedTime = CalculateTime(MyGeometry, MouseEvent.GetScreenSpacePosition());

	FMenuBuilder MenuBuilder(true, nullptr);
	MenuBuilder.BeginSection("Track", LOCTEXT("NotifyHeading", "Track Actions"));
	{
		MenuBuilder.AddMenuEntry
		(
			NSLOCTEXT("AddTaskSubMenu", "AddTaskSubMenuAddNotify", "添加Section"),
			NSLOCTEXT("AddTaskSubMenu", "AddTaskSubMenuAddNotifyToolTip", "添加Section"),
			FSlateIcon(),
			FUIAction
			(
				FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackTimeline::AddNewSection)
			),
			NAME_None,
			EUserInterfaceActionType::Button
		);
		if (const UDialogueEditorSettings* DialogueEditorSettings = GetDefault<UDialogueEditorSettings>())
		{
			if (CachedTrack.IsValid())
			{
				TWeakObjectPtr<UDialogueActionTrack> CachedDialogueTrack = CachedTrack;
				bool ContainsTrack = DialogueEditorSettings->NeedAddAllSectionCommandTracks.ContainsByPredicate([CachedDialogueTrack](const UClass* DialogueActionTrackClass)
					{
						if (DialogueActionTrackClass && CachedDialogueTrack->GetClass()->IsChildOf(DialogueActionTrackClass))
						{
							return true;
						}
						return false;
					});
				if (ContainsTrack)
				{
					MenuBuilder.AddMenuEntry
					(
						NSLOCTEXT("AddTaskSubMenu", "AddAllSectionsForLine", "批量添加关联Section"),
						NSLOCTEXT("AddTaskSubMenu", "AddAllSectionsForLineToolTip", "批量添加关联Section"),
						FSlateIcon(),
						FUIAction
						(
							FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackTimeline::AddAllSectionsForLine)
						),
						NAME_None,
						EUserInterfaceActionType::Button
					);

				}
			}
			
		}
		if (CachedTrack.IsValid() && CachedTrack->IsA(UDialogueCameraCutTrack::StaticClass()))
		{
			MenuBuilder.AddMenuEntry
					(
						NSLOCTEXT("AddTaskSubMenu", "AddAutoCameraSection", "添加自动相机Section"),
						NSLOCTEXT("AddTaskSubMenu", "AddAutoCameraSectionToolTip", "添加自动相机Section"),
						FSlateIcon(),
						FUIAction
						(
							FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackTimeline::AddAutoCameraSection)
						),
						NAME_None,
						EUserInterfaceActionType::Button
					);
			MenuBuilder.AddMenuEntry
					(
						NSLOCTEXT("AddTaskSubMenu", "AddCameraSectionAtViewPosition", "添加当前画面相机及Section"),
						NSLOCTEXT("AddTaskSubMenu", "AddCameraSectionAtViewPositionToolTip", "添加当前画面相机及Section"),
						FSlateIcon(),
						FUIAction
						(
							FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackTimeline::AddCameraSectionAtViewPosition)
						),
						NAME_None,
						EUserInterfaceActionType::Button
					);
		}
	}
	MenuBuilder.EndSection();

	FWidgetPath WidgetPath = MouseEvent.GetEventPath() != nullptr ? *MouseEvent.GetEventPath() : FWidgetPath();
	FSlateApplication::Get().PushMenu(SharedThis(this), WidgetPath, MenuBuilder.MakeWidget(), CursorPos, FPopupTransitionEffect(FPopupTransitionEffect::ContextMenu));

	return TSharedPtr<SWidget>();
}

void SDialogueEditorActionTrackTimeline::AddNewSection()
{
	AddNewSectionEvent.ExecuteIfBound(LastClickedTime);
}

void SDialogueEditorActionTrackTimeline::AddAutoCameraSection()
{
	AddNewSecondTypeSectionEvent.ExecuteIfBound(LastClickedTime);
}

void SDialogueEditorActionTrackTimeline::AddCameraSectionAtViewPosition()
{
	AddCameraSectionAtViewPositionEvent.ExecuteIfBound(LastClickedTime);
}

void SDialogueEditorActionTrackTimeline::AddAllSectionsForLine()
{
	if (!CachedEditor.IsValid() || !CachedTrack.IsValid())
		return;

	UDialogueEditorManager* DialogueEditorManager = CachedEditor->GetDialogueEditorManager();
	if (DialogueEditorManager == nullptr)
		return;

	UDialogueBaseAsset* CurrentAsset = CachedEditor->GetEditingAsset();
	if (CurrentAsset == nullptr)
		return;

	int CurrentEpisodeID = DialogueEditorManager->GetCurrentEpisodeID();

	UDialogueTrackBase* DialogueTrack = CurrentAsset->FindEpisodeTrackByTrackClass(CurrentEpisodeID, UDialogueDialogueTrack::StaticClass());
	if (DialogueTrack == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can not find Dialogue Action In Current Episode"));
		return;
	}
	UDialogueActionTrack* DialogueAction = Cast<UDialogueActionTrack>(DialogueTrack);
	if (DialogueAction == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Can not find Dialogue Action In Current Episode"));
		return;
	}

	if (DialogueAction->ActionSections.Num() == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("Dialogue Action Sections:Num() == 0"));
		return;
	}

	FString ScopeText = FString::Printf(TEXT("Dialogue AddAllSectionsForLine, Track %s"), *(CachedTrack->GetTrackName().ToString()));
	CachedTrack->SetFlags(EObjectFlags::RF_Transactional);
	FScopedTransaction Transaction(FText::FromString(ScopeText));

	for (UDialogueActionBase* DialogueSection : DialogueAction->ActionSections)
	{
		if (DialogueSection)
		{
			bool ShouldGenerateSectionForLine = true;
			//遍历DialogueAction, 查看是否已经存在链接了GUID的Section，如果已经存在，则不添加
			for (UDialogueActionBase* ActionSection : CachedTrack->ActionSections)
			{
				if (ActionSection && ActionSection->LineUniqueIDLinked == DialogueSection->LineUniqueIDLinked)
				{
					ShouldGenerateSectionForLine = false;
					break;
				}
			}
			if (ShouldGenerateSectionForLine)
			{
				CachedTrack->Modify();
				if (UDialogueActionBase* NewActionSection = CurrentAsset->AddSection(CurrentEpisodeID, CachedTrack.Get()))
				{
					NewActionSection->StartTime = DialogueSection->StartTime;
					if (NewActionSection->IsConstant())
					{
						NewActionSection->Duration = DialogueSection->Duration;
					}
					NewActionSection->LineUniqueIDLinked = DialogueSection->LineUniqueIDLinked;
				}
			}
		}
	}
	CachedEditor->DialogueTimelineController.Pin()->RefreshTracks();
}

#pragma endregion Menu



#pragma region Widget
const FGeometry& SDialogueEditorActionTrackTimeline::GetCachedGeometry() const
{
	return CachedGeometry;
}

void SDialogueEditorActionTrackTimeline::UpdateCachedGeometry(const FGeometry& InGeometry)
{
	CachedGeometry = InGeometry;

	for (int i = 0; i < ActionNodes.Num(); ++i)
	{
		ActionNodes[i]->CachedTrackGeometry = InGeometry;
	}
}

FTrackScaleInfo SDialogueEditorActionTrackTimeline::GetCachedScaleInfo() const
{
	return FTrackScaleInfo(ViewInputMin.Get(), ViewInputMax.Get(), 0.f, 0.f, CachedGeometry.GetLocalSize());
}

FVector2D SDialogueEditorActionTrackTimeline::ComputeDesiredSize(float) const
{
	FVector2D Size;
	Size.X = 200;
	Size.Y = FDialogueEditorTrack::NotificationTrackHeight;
	return Size;
}

bool SDialogueEditorActionTrackTimeline::SupportsKeyboardFocus() const
{
	return true;
}

FReply SDialogueEditorActionTrackTimeline::OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::LeftControl || InKeyEvent.GetKey() == EKeys::RightControl)
	{
		bIsCtrlDown = false;
		return FReply::Unhandled();	// 不阻碍Ctrl多选逻辑
	}
	if (InKeyEvent.GetKey() == EKeys::LeftShift || InKeyEvent.GetKey() == EKeys::RightShift)
	{
		return FReply::Unhandled();
	}
	if(InKeyEvent.GetKey() == EKeys::Delete)
	{
		if(FDialogueMainEditor* MainEditor = StaticCast<FDialogueMainEditor*>(CachedEditor.Get()))
		{
			MainEditor->DeleteSelectObject();
		}
	}
	if (InKeyEvent.GetKey() == EKeys::C)
	{
		if(FDialogueMainEditor* MainEditor = StaticCast<FDialogueMainEditor*>(CachedEditor.Get()))
		{
			MainEditor->CopySelectObject();
		}
	}
	if (InKeyEvent.GetKey() == EKeys::V)
	{
		if(FDialogueMainEditor* MainEditor = StaticCast<FDialogueMainEditor*>(CachedEditor.Get()))
		{
			MainEditor->PasteSelectObject();
		}
	}
	return FReply::Unhandled();
}

FReply SDialogueEditorActionTrackTimeline::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::LeftControl || InKeyEvent.GetKey() == EKeys::RightControl)
	{
		bIsCtrlDown = true;
		return FReply::Unhandled();	// 不阻碍Ctrl多选逻辑
	}
	if (InKeyEvent.GetKey() == EKeys::LeftShift || InKeyEvent.GetKey() == EKeys::RightShift)
	{
		return FReply::Unhandled();
	}

	if (InKeyEvent.GetKey() == EKeys::Platform_Delete)
	{
		OnDeleteKeyPressed();
		return FReply::Handled();
	}

	if (bIsCtrlDown && InKeyEvent.GetKey() == EKeys::C)
	{
		return FReply::Handled();
	}
	if (InKeyEvent.GetKey() == EKeys::Left || InKeyEvent.GetKey() == EKeys::Right)
	{
		return FReply::Handled();
	}

	return FReply::Unhandled();
}

FReply SDialogueEditorActionTrackTimeline::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FVector2D CursorPos = MouseEvent.GetScreenSpacePosition();
	CursorPos = MyGeometry.AbsoluteToLocal(CursorPos);

	if (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		return FReply::Handled();
	}
	else if (MouseEvent.GetEffectingButton() == EKeys::RightMouseButton)
	{
		return FReply::Handled();
	}

	return FReply::Handled();
}

FReply SDialogueEditorActionTrackTimeline::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	bool bLeftMouseButton = MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton;
	bool bRightMouseButton = MouseEvent.GetEffectingButton() == EKeys::RightMouseButton;

	if (bRightMouseButton)
	{
		TSharedPtr<SWidget> WidgetToFocus = SummonContextMenu(MyGeometry, MouseEvent);

		return (WidgetToFocus.IsValid())
			? FReply::Handled().ReleaseMouseCapture().SetUserFocus(WidgetToFocus.ToSharedRef(), EFocusCause::SetDirectly)
			: FReply::Handled().ReleaseMouseCapture();

	}
	else if (bLeftMouseButton)
	{
		FVector2D CursorPos = MouseEvent.GetScreenSpacePosition();
		CursorPos = MyGeometry.AbsoluteToLocal(CursorPos);

		LastClickedTime = CalculateTime(MyGeometry, MouseEvent.GetScreenSpacePosition());

		return FReply::Handled();
	}

	return FReply::Unhandled();
}

FCursorReply SDialogueEditorActionTrackTimeline::OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const
{
	return FCursorReply::Unhandled();
}

void SDialogueEditorActionTrackTimeline::HandleNodeDrop(TSharedPtr<SDialogueEditorActionTrackNode> Node, float Offset)
{
	float LocalX = CachedGeometry.AbsoluteToLocal(Node->GetScreenPosition() + Offset).X;
	float Time = GetCachedScaleInfo().LocalXToInput(LocalX);
	if(Node->GetActionNodeDataPtr())
	{
		const UDialogueEditorSettings* DialogueEditorSettings = GetDefault<UDialogueEditorSettings>();
		if (UDialogueActionBase* DialogueActionSection = Node->GetActionNodeDataPtr()->CachedSection.Get())
		{
			TSharedPtr<FDialogueEditor> DialogueEditor = Node->GetActionNodeDataPtr()->CachedEditor.Pin();
			float RealStartTime = DialogueEditor->GetDialogueEditorManager()->OnSectionChange_DragMoveCheck(DialogueEditor->GetDialogueAsset(), DialogueActionSection, Time);

			if (!FMath::IsNearlyEqual(RealStartTime, DialogueActionSection->GetStartTime()))
			{
				FString ScopeText = FString::Printf(TEXT("Dialogue Section Adjust Position, Track %s"), *(DialogueActionSection->SectionName.ToString()));
				FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);

				DialogueActionSection->SetFlags(EObjectFlags::RF_Transactional);
				DialogueActionSection->Modify();

				float OldStartTime = DialogueActionSection->GetStartTime();

				DialogueEditor->GetDialogueEditorManager()->OnSectionChange_DragMove(DialogueEditor->GetDialogueAsset(), DialogueActionSection, RealStartTime - OldStartTime);
			}
		}
	}
}

void SDialogueEditorActionTrackTimeline::SelectActionNode(TSharedRef<SDialogueEditorActionTrackNode> NotifyNode)
{
	SelectActionSectionEvent.ExecuteIfBound(NotifyNode->ActionNodeData.GetAction());
}

void SDialogueEditorActionTrackTimeline::DeleteSelectedSection()
{
	UpdateLayout();
}

void SDialogueEditorActionTrackTimeline::OnDeleteKeyPressed()
{
	if (HasKeyboardFocus() || HasFocusedDescendants())
	{
		DeleteSelectedSection();
	}
}

float SDialogueEditorActionTrackTimeline::CalculateTime(const FGeometry& MyGeometry, FVector2D NodePos, bool bInputIsAbsolute)
{
	if (bInputIsAbsolute)
	{
		NodePos = MyGeometry.AbsoluteToLocal(NodePos);
	}

	FTrackScaleInfo ScaleInfo(ViewInputMin.Get(), ViewInputMax.Get(), 0, 0, MyGeometry.Size);
	return FMath::Clamp<float>(ScaleInfo.LocalXToInput(NodePos.X), 0.f, TimelinePlayLength);
}

FMargin SDialogueEditorActionTrackTimeline::GetNotifyTrackPadding(SDialogueEditorActionTrackNode* ActionNode) const
{
	float LeftMargin = ActionNode->GetWidgetPosition().X;
	float RightMargin = CachedGeometry.GetLocalSize().X - ActionNode->GetWidgetPosition().X - ActionNode->GetSize().X;

	return FMargin(LeftMargin, 0, RightMargin, 0);
}

FReply SDialogueEditorActionTrackTimeline::OnNotifyNodeDragStarted(TSharedRef<SDialogueEditorActionTrackNode> NotifyNode, const FPointerEvent& MouseEvent, const FVector2D& ScreenNodePosition, const bool bDragOnMarker, const float TrackMinOffset)
{
	if (!bDragOnMarker)
	{
		SelectActionNode(NotifyNode);

		TArray<TSharedPtr<SDialogueEditorActionTrackNode>> NodesToDrag;
		NodesToDrag.Add(NotifyNode);
		
		TArray<TSharedPtr<SDialogueEditorActionTrackTimeline>> NotifyAnimTracks;
		NotifyAnimTracks.Add(SharedThis(this));
		
		for (auto TimelineTrack : CachedEditor.Get()->DialogueTimelineController.Pin()->GetAllTracks())
		{
			if(FDialogueEditorTrack* EditorTrack = StaticCast<FDialogueEditorTrack*>( &(TimelineTrack.Get())))
			{
				if(FDialogueTrackEditor* TrackEditor = StaticCast<FDialogueTrackEditor*>( EditorTrack->GetTrackEditor().Get()))
				{
					//  StaticCast 不能准确判断轨道是否为FDialogueActionTrackEditor 这里额外加上判断条件
					if(Cast<UDialogueSpawnableTrack>(TrackEditor->GetCacheTrack()))
					{
						continue;
					}
					EDialogueTrack::Type TrackType = TrackEditor->GetCacheTrack()->GetType();
					if (TrackType == EDialogueTrack::Type::Camera || TrackType == EDialogueTrack::Type::Actor || TrackType ==  EDialogueTrack::Type::RoutePoint)
					{
						continue;
					}
					if(FDialogueActionTrackEditor* ActionTrackEditor = StaticCast<FDialogueActionTrackEditor*>(TrackEditor))
                    {
                    	for (TSharedPtr<SDialogueEditorActionTrackNode> SectionAction : ActionTrackEditor->GetTrackWidget()->GetActionNodes())
                    	{
                    		if (!SectionAction->CanSelected())
                    		{
                    			continue;
                    		}
                    		UDialogueActionBase* SectionObject = SectionAction.Get()->ActionNodeData.CachedSection.Get();
                    		if(CachedEditor.Get()->CurrentSelectSection.Contains(SectionObject)  && SectionAction != NotifyNode)
                    		{
                    			NotifyAnimTracks.Add(ActionTrackEditor->GetTrackWidget());
                    			NodesToDrag.Add(SectionAction);
                    		}
                    	}
                    }
				}
			}
		}
		
		FVector2D DecoratorPosition = NodesToDrag[0]->GetWidgetPosition();
		DecoratorPosition = CachedGeometry.LocalToAbsolute(DecoratorPosition);

		TSharedRef<SOverlay> NodeDragDecoratorOverlay = SNew(SOverlay);
		TSharedRef<SBorder> NodeDragDecorator =
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
			[
				NodeDragDecoratorOverlay
			];

		FBox2D OverlayBounds(NodesToDrag[0]->GetScreenPosition(), NodesToDrag[0]->GetScreenPosition() + FVector2D(NodesToDrag[0]->GetDurationSize(), 0.0f));
		for (int32 Idx = 1; Idx < NodesToDrag.Num(); ++Idx)
		{
			TSharedPtr<SDialogueEditorActionTrackNode> Node = NodesToDrag[Idx];
			FVector2D NodePosition = Node->GetScreenPosition();
			float NodeDuration = Node->GetDurationSize();

			OverlayBounds += FBox2D(NodePosition, NodePosition + FVector2D(NodeDuration, 0.0f));
		}

		FVector2D OverlayOrigin = OverlayBounds.Min;
		FVector2D OverlayExtents = OverlayBounds.GetSize();

		for (TSharedPtr<SDialogueEditorActionTrackNode> Node : NodesToDrag)
		{
			FVector2D OffsetFromFirst(Node->GetScreenPosition() - OverlayOrigin);

			NodeDragDecoratorOverlay->AddSlot()
				.Padding(FMargin(OffsetFromFirst.X, OffsetFromFirst.Y, 0.0f, 0.0f))
				[
					Node->AsShared()
				];
		}
		

		FRefreshPanel UpdateDelegate;

		return FReply::Handled().BeginDragDrop
		(
			FDialogueEditorSectionDragDropOp::New
			(
				CachedEditor.Get()->DialogueTimelineController.Pin(),
				NodesToDrag, NodeDragDecorator, NotifyAnimTracks,
				TimelinePlayLength, MouseEvent.GetScreenSpacePosition(),
				OverlayOrigin, OverlayExtents, CurrentDragXPosition, UpdateDelegate, TrackMinOffset
			)
		);
	}
	else
	{
		return FReply::Handled().CaptureMouse(NotifyNode).UseHighPrecisionMouseMovement(NotifyNode);
	}
}

void SDialogueEditorActionTrackTimeline::OnNotifyDeleteSelectedNode(TSharedRef<SDialogueEditorActionTrackNode> NotifyNode, bool NeedRefresh)
{
	DeleteSectionEvent.Execute(NotifyNode, NeedRefresh);
}

FReply SDialogueEditorActionTrackTimeline::OnNodeLeftMouseButtonUp(TSharedRef<SDialogueEditorActionTrackNode> NotifyNode)
{
	SelectActionNode(NotifyNode);
	return FReply::Handled();
}

#pragma endregion Widget



#undef LOCTEXT_NAMESPACE
