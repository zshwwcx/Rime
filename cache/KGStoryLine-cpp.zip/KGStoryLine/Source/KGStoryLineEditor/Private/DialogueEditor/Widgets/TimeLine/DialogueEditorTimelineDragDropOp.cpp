#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineDragDropOp.h"
#include "Framework/Application/SlateApplication.h"

#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"

#include "DialogueEditor/Dialogue/DialogueTrackBase.h"



#define LOCTEXT_NAMESPACE "FDialogueEditorTimelineDragDropOp"

FDialogueEditorTrackDragDropOp::FDialogueEditorTrackDragDropOp()
{

}

void FDialogueEditorTrackDragDropOp::Construct()
{
	MouseCursor = EMouseCursor::GrabHandClosed;

	FDragDropOperation::Construct();
}

TSharedRef<FDialogueEditorTrackDragDropOp> FDialogueEditorTrackDragDropOp::New(const TSharedPtr<FDialogueEditorTimelineController>& InTimelineController, UDialogueTrackBase* InTrack, TSharedPtr<SWidget> Decorator)
{
	TSharedRef<FDialogueEditorTrackDragDropOp> Operation = MakeShareable(new FDialogueEditorTrackDragDropOp);
	Operation->TimelineController = InTimelineController;
	Operation->CachedTrack = InTrack;
	Operation->Decorator = Decorator;
	Operation->Construct();

	return Operation;
}

void FDialogueEditorTrackDragDropOp::OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent)
{
	if (!bDropWasHandled)
	{

	}
}

void FDialogueEditorTrackDragDropOp::OnDragged(const class FDragDropEvent& DragDropEvent)
{
	if (CursorDecoratorWindow.IsValid())
	{
		CursorDecoratorWindow->MoveWindowTo(DragDropEvent.GetScreenSpacePosition());
	}
}

TSharedPtr<SWidget> FDialogueEditorTrackDragDropOp::GetDefaultDecorator() const
{
	return Decorator;
}

void FDialogueEditorTrackDragDropOp::SetCanDropHere(bool bCanDropHere)
{
	MouseCursor = bCanDropHere ? EMouseCursor::TextEditBeam : EMouseCursor::SlashedCircle;
}

void FDialogueEditorTrackDragDropOp::ChangeTrackPosition(UDialogueTrackBase* TargetTrack, EItemDropZone DropZone)
{
	TimelineController.Pin()->ChangeTrackPosition(CachedTrack.Get(), TargetTrack, DropZone);
}



FDialogueEditorSectionDragDropOp::FDialogueEditorSectionDragDropOp(float& InCurrentDragXPosition) :SelectionTimeLength(0.0f), CurrentDragXPosition(InCurrentDragXPosition)
{

}

TSharedRef<FDialogueEditorSectionDragDropOp> FDialogueEditorSectionDragDropOp::New
(	TSharedPtr<FDialogueEditorTimelineController> DialogueTimelineController,
	TArray<TSharedPtr<SDialogueEditorActionTrackNode>> NotifyNodes, TSharedPtr<SWidget> Decorator,
	const TArray<TSharedPtr<SDialogueEditorActionTrackTimeline>>& NotifyTracks, float InViewPlayLength,
	const FVector2D& CursorPosition, const FVector2D& SelectionScreenPosition, 
	const FVector2D& SelectionSize, float& CurrentDragXPosition, FRefreshPanel& RefreshPanel, const float TrackMinOffset
)
{
	TSharedRef<FDialogueEditorSectionDragDropOp> Operation = MakeShareable(new FDialogueEditorSectionDragDropOp(CurrentDragXPosition));
	Operation->ViewPlayLength = MAX_FLT;
	Operation->RefreshPanelEvent = RefreshPanel;

	Operation->NodeGroupPosition = SelectionScreenPosition;
	Operation->NodeGroupSize = SelectionSize;
	Operation->DragOffset = SelectionScreenPosition - CursorPosition;
	Operation->Decorator = Decorator;
	Operation->SelectedNodes = NotifyNodes;
	Operation->TimelineController = DialogueTimelineController;
	Operation->TrackSpan = NotifyTracks.Last()->GetTrackIndex() - NotifyTracks[0]->GetTrackIndex();
	Operation->TrackMinOffset = TrackMinOffset;

	float BeginTime = MAX_flt;
	for (TSharedPtr<SDialogueEditorActionTrackNode> Node : NotifyNodes)
	{
		float NotifyTime = Node->GetActionNodeData().GetStartTime();

		if (NotifyTime < BeginTime)
		{
			BeginTime = NotifyTime;
		}
	}

	for (TSharedPtr<SDialogueEditorActionTrackNode> Node : NotifyNodes)
	{
		float NotifyTime = Node->GetActionNodeData().GetStartTime();

		Operation->NodeTimeOffsets.Add(NotifyTime - BeginTime);
		Operation->NodeTimes.Add(NotifyTime);
		Operation->NodeXOffsets.Add(Node->GetNotifyPositionOffset().X);

		Operation->SelectionTimeLength = FMath::Max(Operation->SelectionTimeLength, NotifyTime + Node->GetActionNodeData().GetDuration() - BeginTime);
	}

	Operation->Construct();

	for (int32 i = 0; i < NotifyTracks.Num(); ++i)
	{
		FTrackClampInfo Info;
		Info.NotifyTrack = NotifyTracks[i];
		const FGeometry& CachedGeometry = Info.NotifyTrack->GetCachedGeometry();
		Info.TrackPos = CachedGeometry.AbsolutePosition.Y;
		Info.TrackSnapTestPos = Info.TrackPos + (CachedGeometry.Size.Y / 2);
		Operation->ClampInfos.Add(Info);
	}

	Operation->CursorDecoratorWindow->SetOpacity(0.5f);
	return Operation;
}

void FDialogueEditorSectionDragDropOp::OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent)
{
	if (bDropWasHandled == false)
	{
		int32 NumNodes = SelectedNodes.Num();

		for (int32 CurrentNode = 0; CurrentNode < NumNodes; ++CurrentNode)
		{
			TSharedPtr<SDialogueEditorActionTrackNode> Node = SelectedNodes[CurrentNode];
			FTrackClampInfo& ClampInfo = GetTrackClampInfo(Node->GetScreenPosition());
			if(CurrentNode < ClampInfos.Num())
				ClampInfo = ClampInfos[CurrentNode];
			float NodePositionOffset = NodeXOffsets[CurrentNode];
			ClampInfo.NotifyTrack->HandleNodeDrop(Node, NodePositionOffset);
			Node->DragCancelled();
		}

		RefreshPanelEvent.ExecuteIfBound();
	}

	FDragDropOperation::OnDrop(bDropWasHandled, MouseEvent);
}

void FDialogueEditorSectionDragDropOp::OnDragged(const class FDragDropEvent& DragDropEvent)
{
	NodeGroupPosition = DragDropEvent.GetScreenSpacePosition() + DragOffset;

	FTrackClampInfo* SelectionPositionClampInfo = &GetTrackClampInfo(DragDropEvent.GetScreenSpacePosition());
	if ((SelectionPositionClampInfo->NotifyTrack->GetTrackIndex() + TrackSpan) >= ClampInfos.Num())
	{
		SelectionPositionClampInfo = &ClampInfos[ClampInfos.Num() - TrackSpan - 1];
	}

	const FGeometry& TrackGeom = SelectionPositionClampInfo->NotifyTrack->GetCachedGeometry();
	const FTrackScaleInfo& TrackScaleInfo = SelectionPositionClampInfo->NotifyTrack->GetCachedScaleInfo();

	const FVector2D& NotifyPositionOffset = SelectedNodes[0]->GetNotifyPositionOffset();
	const FVector2D& WidgetAndStartTimeOffset = SelectedNodes[0]->GetWidgetAndStartTimeOffset();
	FVector2D SelectionBeginPosition = TrackGeom.LocalToAbsolute(TrackGeom.AbsoluteToLocal(NodeGroupPosition) + NotifyPositionOffset);
	

	float LocalTrackMin = TrackScaleInfo.InputToLocalX(0.f) + TrackMinOffset;
	float LocalTrackMax = TrackScaleInfo.InputToLocalX(ViewPlayLength);

	float SnapMovement = 0.0f;
	float SelectionBeginLocalPositionX = TrackGeom.AbsoluteToLocal(SelectionBeginPosition).X;
	const float ClampedEnd = FMath::Clamp(SelectionBeginLocalPositionX + NodeGroupSize.X, LocalTrackMin, LocalTrackMax);
	const float ClampedBegin = FMath::Clamp(SelectionBeginLocalPositionX, LocalTrackMin, LocalTrackMax);
	if (ClampedBegin > SelectionBeginLocalPositionX)
	{
		SelectionBeginLocalPositionX = ClampedBegin;
	}
	else if (ClampedEnd < SelectionBeginLocalPositionX + NodeGroupSize.X)
	{
		SelectionBeginLocalPositionX = ClampedEnd - NodeGroupSize.X;
	}

	SelectionBeginPosition.X = TrackGeom.LocalToAbsolute(FVector2D(SelectionBeginLocalPositionX, 0.0f)).X;

	bool bSnapped = false;
	for (int32 NodeIdx = 0; NodeIdx < SelectedNodes.Num() && !bSnapped; ++NodeIdx)
	{
		TSharedPtr<SDialogueEditorActionTrackNode> CurrentNode = SelectedNodes[NodeIdx];

		const FTrackClampInfo& NodeClamp = GetTrackClampInfo(CurrentNode->GetScreenPosition());

		FVector2D EventPosition = SelectionBeginPosition + FVector2D(TrackScaleInfo.PixelsPerInput * NodeTimeOffsets[NodeIdx], 0.0f);

		SelectionBeginPosition.Y = SelectionPositionClampInfo->TrackPos - 1.0f;
	}

	SelectionBeginPosition.X += SnapMovement;

	CurrentDragXPosition = TrackGeom.AbsoluteToLocal(FVector2D(SelectionBeginPosition.X, 0.0f)).X;

	TimelineController->SetDragSectionPosX(CurrentDragXPosition);
	CursorDecoratorWindow->MoveWindowTo(TrackGeom.LocalToAbsolute(TrackGeom.AbsoluteToLocal(SelectionBeginPosition) - NotifyPositionOffset - WidgetAndStartTimeOffset));
	NodeGroupPosition = SelectionBeginPosition;
}

FText FDialogueEditorSectionDragDropOp::GetHoverText() const
{
	FText HoverText = LOCTEXT("Invalid", "Invalid");

	if (SelectedNodes[0].IsValid())
	{
		HoverText = FText::FromName(SelectedNodes[0]->GetActionNodeData().GetActionName());
	}

	return HoverText;
}

FDialogueEditorSectionDragDropOp::FTrackClampInfo& FDialogueEditorSectionDragDropOp::GetTrackClampInfo(const FVector2D NodePos)
{
	int32 ClampInfoIndex = 0;
	int32 SmallestNodeTrackDist = FMath::Abs(ClampInfos[0].TrackSnapTestPos - NodePos.Y);
	for (int32 i = 0; i < ClampInfos.Num(); ++i)
	{
		int32 Dist = FMath::Abs(ClampInfos[i].TrackSnapTestPos - NodePos.Y);
		if (Dist < SmallestNodeTrackDist)
		{
			SmallestNodeTrackDist = Dist;
			ClampInfoIndex = i;
		}
	}

	return ClampInfos[ClampInfoIndex];
}


#undef LOCTEXT_NAMESPACE
