#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTrackGroup.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"

ANIMTIMELINE_IMPLEMENT_TRACK(FDialogueEditorTrackGroup);

FDialogueEditorTrackGroup::FDialogueEditorTrackGroup(const TSharedRef<FDialogueEditorTimelineController>& InModel, FDialogueTrackGroup* InGroupData, const FText& InDisplayName, const FText& InToolTipText)
	: FAnimTimelineTrack(InModel, InDisplayName, InToolTipText, true), GroupData(InGroupData)
{

}