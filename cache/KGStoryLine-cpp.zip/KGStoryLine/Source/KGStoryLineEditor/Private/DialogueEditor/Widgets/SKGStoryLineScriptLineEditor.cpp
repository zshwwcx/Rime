#include "DialogueEditor/Widgets/SKGStoryLineScriptLineEditor.h"
#include "DataTableUtils.h"
#include "DetailsViewArgs.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "IStructureDetailsView.h"
#include "DialogueEditor/KGStoryLineEditorSubSystem.h"
#include "DialogueEditor/KGStoryLineScriptEditor.h"
#include "Internationalization/Internationalization.h"
#include "Layout/Margin.h"
#include "Misc/AssertionMacros.h"
#include "Misc/Attribute.h"
#include "Misc/MessageDialog.h"
#include "Modules/ModuleManager.h"
#include "PropertyEditorModule.h"
#include "SlotBase.h"
#include "Styling/AppStyle.h"
#include "Styling/SlateColor.h"
#include "UObject/Class.h"
#include "UObject/StructOnScope.h"
#include "UObject/UnrealNames.h"
#include "UObject/WeakObjectPtrTemplates.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Text/STextBlock.h"

class FProperty;
class SWidget;
class UPackage;
struct FPropertyChangedEvent;

#define LOCTEXT_NAMESPACE "SKGStoryLineScriptLineEditor"

SKGStoryLineScriptLineEditor::SKGStoryLineScriptLineEditor() 
	: SCompoundWidget()
	, INotifyOnKGSLDataChanged(EKGSLDataChangeInfo::LineAdded, EKGSLDataChangeInfo::LineRemoved,
		EKGSLDataChangeInfo::LineSwapped, EKGSLDataChangeInfo::LineData)
{
}

SKGStoryLineScriptLineEditor::~SKGStoryLineScriptLineEditor()
{
}

void SKGStoryLineScriptLineEditor::NotifyPreChange( FProperty* PropertyAboutToChange )
{
	check(Asset.IsValid());
	Asset->Modify();

	UKGStoryLineEditorSubSystem::BroadcastPreChanged(Asset.Get(), EKGSLDataChangeInfo::LineData);
}

void SKGStoryLineScriptLineEditor::NotifyPostChange( const FPropertyChangedEvent& PropertyChangedEvent, FProperty* PropertyThatChanged )
{
	check(Asset.IsValid());
	
	Asset->MarkPackageDirty();

	UKGStoryLineEditorSubSystem::BroadcastPostChanged(Asset.Get(), EKGSLDataChangeInfo::LineData);
}

void SKGStoryLineScriptLineEditor::PreChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo Info)
{
	if (Changed == Asset.Get()
		&& (EKGSLDataChangeInfo::LineAdded == Info
			|| EKGSLDataChangeInfo::LineRemoved == Info
			|| EKGSLDataChangeInfo::LineSwapped == Info))
	{
		CleanBeforeChange();
	}
}

void SKGStoryLineScriptLineEditor::PostChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo Info)
{
	if (Changed == Asset.Get()
		&& (EKGSLDataChangeInfo::LineAdded == Info
			|| EKGSLDataChangeInfo::LineRemoved == Info
			|| EKGSLDataChangeInfo::LineSwapped == Info))
	{
		RefreshNameList();
		Restore();
	}
}

void SKGStoryLineScriptLineEditor::CleanBeforeChange()
{
	if(PropertyView.IsValid())
	{
		PropertyView->SetObject(nullptr);
	}
}

void SKGStoryLineScriptLineEditor::RefreshNameList()
{
	CachedRowNames.Empty();
	if (Asset.IsValid() && KGStoryLine::IsValidEpisodeID(EpisodeID))
	{
		if(UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID))
		{
			for (int32 i = 0; i < Episode->DialogueLines.Num(); i++)
			{
				CachedRowNames.Add(MakeShareable(new FName(FKGStoryLineScriptEditor::LineIndex2RowId(i))));
			}
		}
	}
}

void SKGStoryLineScriptLineEditor::Restore()
{
	if (!SelectedName.IsValid() || !SelectedName->IsNone())
	{
		if (SelectedName.IsValid())
		{
			auto CurrentName = *SelectedName;
			SelectedName = nullptr;
			for (auto Element : CachedRowNames)
			{
				if (*Element == CurrentName)
				{
					SelectedName = Element;
					break;
				}
			}
		}

		if (!SelectedName.IsValid() && CachedRowNames.Num() && CachedRowNames[0].IsValid())
		{
			SelectedName = CachedRowNames[0];
		}

		if (RowComboBox.IsValid())
		{
			RowComboBox->SetSelectedItem(SelectedName);
		}
	}
	else
	{
		if (RowComboBox.IsValid())
		{
			RowComboBox->ClearSelection();
		}
	}

	auto FinalName = SelectedName.IsValid() ? *SelectedName : NAME_None;
	if(PropertyView.IsValid())
	{
		int32 LineIndex = FKGStoryLineScriptEditor::RowId2LineIndex(FinalName);
		UKGSLDialogueLine* Line = Asset->GetDialogueLine(EpisodeID, LineIndex);
		PropertyView->SetObject(Line);
	}
	
	RowSelectedCallback.ExecuteIfBound(FinalName);
}

FName SKGStoryLineScriptLineEditor::GetCurrentName() const
{
	return SelectedName.IsValid() ? *SelectedName : NAME_None;
}

FText SKGStoryLineScriptLineEditor::GetCurrentNameAsText() const
{
	return FText::FromName(GetCurrentName());
}

TSharedRef<SWidget> SKGStoryLineScriptLineEditor::OnGenerateWidget(TSharedPtr<FName> InItem)
{
	return SNew(STextBlock).Text(FText::FromName(InItem.IsValid() ? *InItem : NAME_None));
}

void SKGStoryLineScriptLineEditor::OnSelectionChanged(TSharedPtr<FName> InItem, ESelectInfo::Type InSeletionInfo)
{
	if (InItem.IsValid() && InItem != SelectedName)
	{
		CleanBeforeChange();

		SelectedName = InItem;

		Restore();
	}
}

void SKGStoryLineScriptLineEditor::SelectRow(FName InName)
{
	TSharedPtr<FName> NewSelectedName;
	for (auto Name : CachedRowNames)
	{
		if (Name.IsValid() && (*Name == InName))
		{
			NewSelectedName = Name;
		}
	}
	if (!NewSelectedName.IsValid())
	{
		NewSelectedName = MakeShareable(new FName(InName));
	}
	OnSelectionChanged(NewSelectedName, ESelectInfo::Direct);
}

void SKGStoryLineScriptLineEditor::HandleUndoRedo()
{
	RefreshNameList();
	Restore();
}

FReply SKGStoryLineScriptLineEditor::OnAddClicked()
{
	if (Asset.IsValid())
	{
		if(UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID))
		{
			FName NewName = FKGStoryLineScriptEditor::LineIndex2RowId(Episode->DialogueLines.Num() + 1);
			UKGStoryLineEditorSubSystem::AddLine(Asset.Get(), EpisodeID);
			SelectRow(NewName);
		}		
	}
	
	return FReply::Handled();
}

FReply SKGStoryLineScriptLineEditor::OnRemoveClicked()
{
	if (Asset.IsValid())
	{
		const FName RowToRemove = GetCurrentName();
		const int32 RowToRemoveIndex = CachedRowNames.IndexOfByPredicate([&](const TSharedPtr<FName>& InRowName) -> bool
		{
			return *InRowName == RowToRemove;
		});

		if (UKGStoryLineEditorSubSystem::RemoveLine(Asset.Get(), EpisodeID,
		                                            FKGStoryLineScriptEditor::RowId2LineIndex(RowToRemove)))
		{
			// Try and keep the same line index selected
			const int32 RowIndexToSelect = FMath::Clamp(RowToRemoveIndex, 0, CachedRowNames.Num() - 1);
			if (CachedRowNames.IsValidIndex(RowIndexToSelect))
			{
				SelectRow(*CachedRowNames[RowIndexToSelect]);
			}
		}
	}
	return FReply::Handled();
}

FReply SKGStoryLineScriptLineEditor::OnMoveRowClicked(FDataTableEditorUtils::ERowMoveDirection MoveDirection)
{
	if (Asset.IsValid())
	{
		const FName RowToMove = GetCurrentName();

		UKGStoryLineEditorSubSystem::MoveRow(Asset.Get(), EpisodeID,
		                                     FKGStoryLineScriptEditor::RowId2LineIndex(RowToMove), MoveDirection);
	}
	return FReply::Handled();
}

FReply SKGStoryLineScriptLineEditor::OnMoveToExtentClicked(FDataTableEditorUtils::ERowMoveDirection MoveDirection)
{
	if (Asset.IsValid())
	{
		if(UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID))
		{
			// We move by the line map size, as UKGStoryLineEditorSubSystem::MoveRow will automatically clamp this as appropriate
			const FName RowToMove = GetCurrentName();
			
			UKGStoryLineEditorSubSystem::MoveRow(Asset.Get(), EpisodeID,
			                                     FKGStoryLineScriptEditor::RowId2LineIndex(RowToMove),
			                                     MoveDirection,
			                                     Episode->DialogueLines.Num());
		}
	}
	return FReply::Handled();
}

void SKGStoryLineScriptLineEditor::OnRowRenamed(const FText& Text, ETextCommit::Type CommitType)
{
	if (!GetCurrentNameAsText().EqualTo(Text) && Asset.IsValid())
	{
		if (Text.IsEmptyOrWhitespace() || !FName::IsValidXName(Text.ToString(), INVALID_NAME_CHARACTERS))
		{
			// Only pop up the error dialog if the rename was caused by the user's action
			if ((CommitType == ETextCommit::OnEnter) || (CommitType == ETextCommit::OnUserMovedFocus ))
			{
				// popup an error dialog here
				const FText Message = FText::Format(LOCTEXT("InvalidLineName", "'{0}' is not a valid line name"), Text);
				FMessageDialog::Open(EAppMsgType::Ok, Message);
			}
			return;
		}
		const FName NewName = DataTableUtils::MakeValidName(Text.ToString());
		if (NewName == NAME_None)
		{
			// popup an error dialog here
			const FText Message = FText::Format(LOCTEXT("InvalidLineName", "'{0}' is not a valid line name"), Text);
			FMessageDialog::Open(EAppMsgType::Ok, Message);

			return;
		}
		for (auto Name : CachedRowNames)
		{
			if (Name.IsValid() && (*Name == NewName))
			{
				//the name already exists
				// popup an error dialog here
				const FText Message = FText::Format(LOCTEXT("DuplicateLineName", "'{0}' is already used as a line name in this table"), Text);
				FMessageDialog::Open(EAppMsgType::Ok, Message);
				return;
			}
		}

		const FName OldName = GetCurrentName();
		// TODO: limunan - rename
		// FDataTableEditorUtils::RenameRow(Asset.Get(), OldName, NewName);
		SelectRow(NewName);
	}
}

FReply SKGStoryLineScriptLineEditor::OnResetToDefaultClicked()
{
	if (Asset.IsValid() && SelectedName.IsValid())
	{
		// TODO: limunan - reset to default
		// FDataTableEditorUtils::ResetToDefault(Asset.Get(), *SelectedName.Get());
	}

	return FReply::Handled();
}

EVisibility SKGStoryLineScriptLineEditor::GetResetToDefaultVisibility() const
{
	EVisibility VisibleState = EVisibility::Collapsed;

	if (Asset.IsValid() && SelectedName.IsValid())
	{
		// TODO: limunan - diff from default
		// if (FDataTableEditorUtils::DiffersFromDefault(Asset.Get(), *SelectedName.Get()))
		{
			VisibleState = EVisibility::Visible;
		}
	}

	return VisibleState;
}

void SKGStoryLineScriptLineEditor::Construct(const FArguments& InArgs, UDialogueAsset* Changed, int32 InEpisodeID)
{
	ConstructInternal(Changed, InEpisodeID);
}

void SKGStoryLineScriptLineEditor::ConstructInternal(UDialogueAsset* Changed, int32 InEpisodeID)
{
	Asset = Changed;
	EpisodeID = InEpisodeID;
	{
		FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
		FDetailsViewArgs ViewArgs;
		ViewArgs.bAllowSearch = true;
		ViewArgs.bHideSelectionTip = true;
		ViewArgs.bShowObjectLabel = false;
		ViewArgs.NameAreaSettings = FDetailsViewArgs::HideNameArea;
		ViewArgs.NotifyHook = this;

		PropertyView = PropertyModule.CreateDetailView(ViewArgs);
	}

	RefreshNameList();
	Restore();
	const float ButtonWidth = 85.0f;
	ChildSlot
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2)
			[
				SNew(SBox)
				.WidthOverride(2 * ButtonWidth)
				.ToolTipText(LOCTEXT("SelectedRowTooltip", "Select a line to edit"))
				[
					SAssignNew(RowComboBox, SComboBox<TSharedPtr<FName>>)
					.OptionsSource(&CachedRowNames)
					.OnSelectionChanged(this, &SKGStoryLineScriptLineEditor::OnSelectionChanged)
					.OnGenerateWidget(this, &SKGStoryLineScriptLineEditor::OnGenerateWidget)
					.Content()
					[
						SNew(STextBlock).Text(this, &SKGStoryLineScriptLineEditor::GetCurrentNameAsText)
					]
				]
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2)
			[
				SNew(SButton)
				.OnClicked(this, &SKGStoryLineScriptLineEditor::OnResetToDefaultClicked)
				.Visibility(this, &SKGStoryLineScriptLineEditor::GetResetToDefaultVisibility)
				.ContentPadding(FMargin(5.f, 0.f))
				.ToolTipText(LOCTEXT("ResetToDefaultToolTip", "Reset to Default"))
				.ButtonStyle(FAppStyle::Get(), "NoBorder")
				.ForegroundColor(FSlateColor::UseForeground())
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Content()
				[
					SNew(SImage)
					.Image(FAppStyle::GetBrush("PropertyWindow.DiffersFromDefault"))
				]
			]

		]
		+ SVerticalBox::Slot()
		[
			PropertyView.ToSharedRef()
		]
	];
}

bool SKGStoryLineScriptLineEditor::IsMoveRowUpEnabled() const
{
	return true;
}

bool SKGStoryLineScriptLineEditor::IsMoveRowDownEnabled() const
{
	return true;
}

bool SKGStoryLineScriptLineEditor::IsAddRowEnabled() const
{
	return true;
}

bool SKGStoryLineScriptLineEditor::IsRemoveRowEnabled() const
{
	return true;
}

EVisibility SKGStoryLineScriptLineEditor::GetRenameVisibility() const
{
	return EVisibility::Visible;
}

#undef LOCTEXT_NAMESPACE
