#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueTrackEditor.h"

FDialogueTrackEditor::FDialogueTrackEditor(const TWeakPtr<FTimelineController> InModel, const TWeakPtr<class FDialogueEditor>& InAssetEditor, UDialogueTrackBase* InTrack)
	:TimelineController(InModel), CachedEditor(InAssetEditor), CachedTrack(InTrack)
{

}

TWeakObjectPtr<UDialogueTrackBase> FDialogueTrackEditor::GetCacheTrack()
{
	return CachedTrack;
}