#include "DialogueEditor/Widgets/AssetBrowser/DialogueAssetViewTypes.h"

#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "EditorActorFolders.h"
#include "DialogueEditor/Widgets/AssetBrowser/SDialogueAssetTreeView.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Text/STextBlock.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "DialogueEditor/LuaAsset/LuaAssetHelper.h"
#include "Widgets/Input/SEditableText.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Misc/MessageDialog.h"

#define LOCTEXT_NAMESPACE "DialogueAssetViewTypes"

void IDialogueAssetViewItem::CreateFolder(class FDialogueFolderViewItem* ParentItem, TSharedPtr<SDialogueAssetTreeView> DialogueAssetTreeView)
{
	TSharedPtr<FDialogueFolderViewItem> Item = MakeShared<FDialogueFolderViewItem>();
	Item->LeafName = "NewFolder";
	Item->Path = FPaths::Combine(ParentItem->Path, Item->LeafName);
	ParentItem->AddChild(Item.ToSharedRef());
	DialogueAssetTreeView->RebuildList();
}

void IDialogueAssetViewItem::CreateDialogue(class FDialogueFolderViewItem* ParentItem, TSharedPtr<SDialogueAssetTreeView> DialogueAssetTreeView)
{
	// TSharedPtr<FDialogueLuaAssetViewItem> Item = MakeShared<FDialogueLuaAssetViewItem>();
	// TSharedPtr<FKGSLAssetCreateGuide> Guide = MakeShareable(new FKGSLAssetCreateGuide());
	// Guide->OpenGuideWindow(true);
	// FString AssetName;
	// FString StoryLineID;
	// FString TemplatePath;
	// if(Guide->GetParameters(AssetName, StoryLineID, TemplatePath))
	// {
	// 	Item->AssetName = AssetName;
	// 	ParentItem->AddChild(Item.ToSharedRef());
	// 	DialogueAssetTreeView->RebuildList();
	// 	FLuaAssetHelper::CreateAndOpenDialogueLuaAsset(AssetName, ParentItem->Path, StoryLineID, TemplatePath);
	// }
}


FString FDialogueFolderViewItem::GetDisplayString() const
{
	return LeafName;
}

TSharedRef<SWidget> FDialogueFolderViewItem::GenerateLabelWidget(class SDialogueAssetBrowser& Outliner, const STableRow<FDialogueAssetTreeItemPtr>& InRow)
{
	TSharedRef<SWidget> Widget =
		SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				.Padding(FMargin(0.f, 1.f, 6.f, 1.f))
				[
					SNew(SBox)
					.WidthOverride(16)
					.HeightOverride(16)
					[
						SNew(SImage)
						.Image(this, &FDialogueFolderViewItem::GetIcon)
						.ColorAndOpacity(FSlateColor::UseForeground())
					]
				]
			+SHorizontalBox::Slot()
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Left)
			.AutoWidth()
			.Padding(4.0f, 1.0f)
			[
				SNew(SInlineEditableTextBlock)
				.Font(FAppStyle::Get().GetFontStyle("NormalFontBold"))
				.Text(FText::FromString(GetDisplayString()))
				.IsSelected(FIsSelected::CreateSP(&InRow, &STableRow<FDialogueAssetTreeItemPtr>::IsSelectedExclusively))
				.IsReadOnly(true)
			];
	return Widget;
}

bool FDialogueFolderViewItem::IsLabelReadOnly() const
{
	for (auto Child: GetChildren())
	{
		if (!Child->IsFolderItem() || Child->IsLabelReadOnly())
		{
			return true;
		}
	}
	return false;
}

void FDialogueFolderViewItem::OnLabelCommitted(const FText& InLabel, ETextCommit::Type InCommitInfo)
{
}

const FSlateBrush* FDialogueFolderViewItem::GetIcon() const
{
	if (this->Flags.bIsExpanded && this->GetChildren().Num())
	{
		return FAppStyle::Get().GetBrush(TEXT("SceneOutliner.FolderOpen"));
	}
	else
	{
		return FAppStyle::Get().GetBrush(TEXT("SceneOutliner.FolderClosed"));
	}
}

TSharedPtr<SWidget> FDialogueFolderViewItem::CreateContextMenu(TSharedPtr<SDialogueAssetTreeView> DialogueAssetTreeView)
{
	UDialogueEditorPerProjectUserSettings* EditorSettings = GetMutableDefault<UDialogueEditorPerProjectUserSettings>();
	FMenuBuilder MenuBuilder(true, nullptr, nullptr);
	if (bool bFavoriteView = DialogueAssetTreeView->GetBrowserPtr().Pin()->GetCurrentViewType() == EDialogueAssetViewType::Favorite)
	{
		MenuBuilder.AddMenuEntry(
			FText::FromString(TEXT("从收藏夹移除")),
			TAttribute<FText>(),
			FSlateIcon(FAppStyle::GetAppStyleSetName(), "PropertyWindow.Favorites_Disabled"),
			FExecuteAction::CreateLambda([this, EditorSettings, DialogueAssetTreeView]()
			{
				int32 PathIndex = INDEX_NONE;
				for (int32 Index = 0; Index < EditorSettings->FavoriteFolderPaths.Num(); ++Index)
				{
					FString LeftStr;
					FString RightStr;
					FString FolderPath = EditorSettings->FavoriteFolderPaths[Index];
					FolderPath.Split(TEXT("/"), &LeftStr, &RightStr);
					if (RightStr == LeafName)
					{
						PathIndex = Index;
						break;
					}
				}
				if (PathIndex != INDEX_NONE)
				{
					EditorSettings->FavoriteFolderPaths.RemoveAt(PathIndex);
					EditorSettings->SaveConfig();
					if (DialogueAssetTreeView->GetBrowserPtr().IsValid())
					{
						DialogueAssetTreeView->GetBrowserPtr().Pin()->RefreshTreeView();
					}
				}
			})
		);
	}
	else
	{
		if (!Path.Contains("/"))
		{
			return SNullWidget::NullWidget;
		}
		if (EditorSettings->FavoriteFolderPaths.Contains(Path))
		{
			MenuBuilder.AddMenuEntry(
				FText::FromString(TEXT("从收藏夹移除")),
				TAttribute<FText>(),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "PropertyWindow.Favorites_Disabled"),
				FExecuteAction::CreateLambda([this, EditorSettings, DialogueAssetTreeView]()
				{
					EditorSettings->FavoriteFolderPaths.Remove(Path);
					EditorSettings->SaveConfig();
				})
			);
		}
		else
		{
			MenuBuilder.AddMenuEntry(
				FText::FromString(TEXT("添加到收藏")),
				TAttribute<FText>(),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Star"),
				FExecuteAction::CreateLambda([this, EditorSettings, DialogueAssetTreeView]()
				{
					EditorSettings->FavoriteFolderPaths.Add(Path);
					EditorSettings->SaveConfig();
				})
			);
		}
	}
	
	return MenuBuilder.MakeWidget();
}

bool FDialogueLuaAssetViewItem::IsAssetValid() const
{
	FString AssetName = DialogueAssetData.StoryLineID;
	if (AssetName.IsEmpty())
	{
		return false;
	}
	FString Directory = FPaths::ProjectContentDir() + FString("Script/Data/Config/Dialogue");
	FString DialogueLuaPath = FPaths::Combine(Directory, AssetName + ".lua");
	if (FPaths::FileExists(DialogueLuaPath))
	{
		return true;
	}
	return false;
}

bool FDialogueLuaAssetViewItem::IsSimpleDialogue() const
{
	return DialogueAssetData.bSimpleDialogue;
}

FString FDialogueLuaAssetViewItem::GetToolTipText() const
{
	if (IsSimpleDialogue())
	{
		return TEXT("简单对话，无法预览");
	}
	return TEXT("");
}

FSlateColor FDialogueLuaAssetViewItem::GetColorAndOpacity() const
{
	return IsSimpleDialogue() ? FSlateColor(FColor(152, 255, 152)) : FSlateColor(FColor::White);
}

TSharedRef<SWidget> FDialogueLuaAssetViewItem::GenerateLabelWidget(class SDialogueAssetBrowser& Outliner, const STableRow<FDialogueAssetTreeItemPtr>& InRow)
{
	const FSlateBrush* IconBrush = FAppStyle::GetBrush("ContentBrowser.ColumnViewAssetIcon");
	const float IconOverlaySize = IconBrush->ImageSize.X * 0.6f;
	FSlateColor Color = GetColorAndOpacity();
	FString ToolTipText = GetToolTipText();
	FString DisplayString = GetDialogueIDString();
	if (DisplayString.IsEmpty())
	{
		DisplayString = TEXT("Null");
	}
	TSharedRef<SWidget> Widget =
		SNew(SHorizontalBox)
		.ToolTipText(FText::FromString(ToolTipText))
		+SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(0, 0, 4, 0)
		[
			SNew(SOverlay)
				
			// The actual icon
			+SOverlay::Slot()
			[
				SNew(SImage)
				.Image(IconBrush)
				.ColorAndOpacity(Color)
			]

			// Dirty state
			+SOverlay::Slot()
			.HAlign(HAlign_Left)
			.VAlign(VAlign_Bottom)
			[
				SNew(SBox)
				.WidthOverride(IconOverlaySize)
				.HeightOverride(IconOverlaySize)
				[
					SNew(SImage)
					.Image(this, &FDialogueLuaAssetViewItem::GetDirtyImage)
				]
			]
		]
		+SHorizontalBox::Slot()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Left)
		.AutoWidth()
		.Padding(4.0f, 1.0f)
		[
			SNew(STextBlock)
			.Font(FAppStyle::Get().GetFontStyle("NormalFontBold"))
			.Text(FText::FromString(DisplayString))
			.HighlightText_Lambda([&Outliner]()
			{
				return Outliner.GetFilterText();
			})
			.ColorAndOpacity(Color)
		];
	return Widget;
}

const FSlateBrush* FDialogueLuaAssetViewItem::GetDirtyImage() const
{
	return IsDirty() ? FAppStyle::GetBrush("ContentBrowser.ContentDirty") : nullptr;
}

FString FDialogueLuaAssetViewItem::GetDisplayString() const
{
	return DialogueAssetData.StoryLineID;
}

TSharedPtr<SWidget> FDialogueLuaAssetViewItem::CreateContextMenu(TSharedPtr<SDialogueAssetTreeView> DialogueAssetTreeView)
{
	FString Directory = FPaths::Combine(FPaths::ProjectContentDir(), FLuaAssetHelper::LuaAssetPrePath);
	FString FileName = GetDisplayString();
	FString DialogueLuaPath = FPaths::Combine(Directory, FileName + ".lua");
	const bool bFileExists = FPaths::FileExists(DialogueLuaPath);
	const bool bSimpleDialogue = IsSimpleDialogue();
	const FString SubString = TEXT("BEGIN Copy Dialogue Asset!\n");
	FMenuBuilder MenuBuilder(true, nullptr, nullptr);
	FUIAction CopyUIAction;
	CopyUIAction.ExecuteAction = FExecuteAction::CreateLambda([this, SubString]()
		{
			FString CopyString;
			CopyString += SubString;
			CopyString += GetDisplayString();
			FPlatformApplicationMisc::ClipboardCopy(*CopyString);
		});
	CopyUIAction.CanExecuteAction =
			FCanExecuteAction::CreateLambda([this, bFileExists]()
			{
				return bFileExists;
			}
		);
	TAttribute<FText> DynamicCopyTooltipAttribute = TAttribute<FText>::CreateLambda([bFileExists]()
	{
		if (bFileExists)
		{
			return LOCTEXT("CopyDialogueAssetToolTips", "复制选中对话资产");
		}
		return LOCTEXT("CannotCopyDialogueAssetToolTips", "当前对话没有资产，无法复制");
	});
	MenuBuilder.AddMenuEntry(
				FText::FromString(TEXT("复制资产")),
				DynamicCopyTooltipAttribute,
				FSlateIcon(),
				CopyUIAction
			);
	
	FString PasteString;
	FPlatformApplicationMisc::ClipboardPaste(PasteString);
	bool bCanPaste = PasteString.Contains(SubString);
	FString SourceDialogueID;
	bool bSameDialogueID = false;
	if (bCanPaste)
	{
		SourceDialogueID = PasteString.Replace(*SubString, TEXT(""));
		bSameDialogueID = SourceDialogueID == DialogueAssetData.StoryLineID;
		// 复制的ID和当前选中粘贴的ID一致是无法进行粘贴
		if (bSameDialogueID)
		{
			bCanPaste = false;
		}
	}
	
	FUIAction PasteUIAction;
	PasteUIAction.ExecuteAction = FExecuteAction::CreateLambda([this, bFileExists, bSimpleDialogue, SourceDialogueID]()
		{
			bool bPaste = true;
			FString DialogText;
			if (bFileExists && bSimpleDialogue)
			{
				DialogText = FString::Printf(TEXT("当前对话为简单对话,且已有资产,是否粘贴覆盖当前已有资产?"));
				
			}
			else if (bFileExists)
			{
				DialogText = FString::Printf(TEXT("当前对话已有资产,是否覆盖当前已有资产?"));
			}
			else if (bSimpleDialogue)
			{
				DialogText = FString::Printf(TEXT("当前对话为简单对话,是否为简单对话粘贴资产,粘贴后请调整表内【简单对话】配置,让资产正常播放?"));
			}
			if (!DialogText.IsEmpty())
			{
				bPaste = FMessageDialog::Open(EAppMsgType::YesNo, FText::FromString(DialogText)) == EAppReturnType::Yes;
			}
			if (bPaste)
			{
				FLuaAssetHelper::CopyDialogue(SourceDialogueID, DialogueAssetData.StoryLineID);
			}
		});
	PasteUIAction.CanExecuteAction =
			FCanExecuteAction::CreateLambda([this, bCanPaste]()
			{
				return bCanPaste;
			}
		);
	TAttribute<FText> DynamicPasteTooltipAttribute = TAttribute<FText>::CreateLambda([bCanPaste, bSameDialogueID]()
	{
		if (bSameDialogueID)
		{
			return LOCTEXT("SameCannotPasteDialogueAssetToolTips", "复制的资产ID和当前一致,无法进行粘贴");
		}
		if (bCanPaste)
		{
			return LOCTEXT("PasteDialogueAssetToolTips", "粘贴对话资产");
		}
		return LOCTEXT("CannotPasteDialogueAssetToolTips", "没有复制对话资产，无法进行粘贴");
	});
	TAttribute<FText> DynamicPasteLabelAttribute = TAttribute<FText>::CreateLambda([SourceDialogueID]()
	{
		if (!SourceDialogueID.IsEmpty())
		{
			return FText::Format(LOCTEXT("PasteDialogueWithIDLabel", "粘贴资产({0})"), FText::FromString(SourceDialogueID));
		}
		return LOCTEXT("PasteDialogueLabel", "粘贴资产");
	});
	MenuBuilder.AddMenuEntry(
		DynamicPasteLabelAttribute,
		DynamicPasteTooltipAttribute,
		FSlateIcon(),
		PasteUIAction
	);
	
	if (bFileExists && !bSimpleDialogue)
	{
		MenuBuilder.AddMenuEntry(
			FText::FromString(TEXT("删除并重新生成对话资源")),
			TAttribute<FText>(),
			FSlateIcon(),
			FExecuteAction::CreateLambda([this]()
			{
				if (!IDialogueEditor::ProcessOtherOpen())
				{
					return;
				}
				if (FLuaAssetHelper::CreateAndOpenDialogueLuaAsset(DialogueAssetData.StoryLineID))
				{
					UDialogueEditorPerProjectUserSettings* EditorSettings = GetMutableDefault<UDialogueEditorPerProjectUserSettings>();
					EditorSettings->AddHistoryAsset(DialogueAssetData.StoryLineID);
				}
			})
		);
	}
	
	return MenuBuilder.MakeWidget();
}

#undef LOCTEXT_NAMESPACE