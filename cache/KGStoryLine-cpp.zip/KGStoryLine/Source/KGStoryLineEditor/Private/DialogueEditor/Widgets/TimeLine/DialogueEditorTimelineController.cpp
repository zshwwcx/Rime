#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/DialogueEditorPreviewProxy.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTrack.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/Dialogue/DialogueCameraTrack.h"
#include "DialogueEditor/DialogueEditorUtilities.h"
#include "Camera/CameraActor.h"
#include "SClassViewer.h"
#include "Misc/MessageDialog.h"
#include "ScopedTransaction.h"
#include "ClassViewerFilter.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueActorTrackEditor.h"
#include "DialogueEditor/Dialogue/Actions/DialogueAutoCameraCut.h"
#include "Widgets/Views/STableRow.h"
#include "DialogueEditor/DialogueEditorDelegates.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "DialogueEditor/DialogueEditorPreviewSettings.h"
#include "Framework/Application/SlateApplication.h"
#include "Modules/ModuleManager.h"

#pragma optimize("",off)

#define LOCTEXT_NAMESPACE "FDialogueEditorTimelineController"

FDialogueEditorTimelineController::FDialogueEditorTimelineController()
{
}

FDialogueEditorTimelineController::~FDialogueEditorTimelineController()
{
	if (CachedEditor.IsValid())
	{
		CachedEditor.Pin()->GetGenarateDaialogueEvent().RemoveAll(this);
	}
}

void FDialogueEditorTimelineController::Initialize(const TSharedPtr<FDialogueEditor>& InAssetEditorToolkit, TSharedPtr<FDialogueEditorPreviewProxy> InPreviewProxy, int32 InEpisodeIndex, bool bAsCameraList)
{
	CachedEditor = InAssetEditorToolkit;
	CachedPreviewProxy = InPreviewProxy;
	EpisodeIndex = InEpisodeIndex;
	bCameraList = bAsCameraList;
	if (const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>())
	{
		if (EditorSettings->bNewLayout)
		{
			bEnableCameraList = true;
		}
	}
	SnapViewToPlayRange();
	CachedEditor.Pin()->GetGenarateDaialogueEvent().AddRaw(this, &FDialogueEditorTimelineController::RefreshTracks);
}


TSharedRef<FDialogueEditorTrack> FDialogueEditorTimelineController::RoamTrack(UDialogueTrackBase* InTrack, bool bInCameraList)
{
	TSharedRef<FDialogueEditorTrack> NewTrack = MakeShareable(new FDialogueEditorTrack(SharedThis(this), CachedEditor, InTrack, InTrack->GetTrackName(), LOCTEXT("Track_Tooltip", "Track")));
	for (int32 j = 0; j < InTrack->Actions.Num(); ++j)
	{
		if (bEnableCameraList && bInCameraList)
		{
			continue;
		}
		UDialogueActionTrack* Action = InTrack->Actions[j];
		TSharedRef<FDialogueEditorTrack> NewAction = MakeShareable(new FDialogueEditorTrack(SharedThis(this), CachedEditor, Action, Action->GetTrackName(), LOCTEXT("Track_Tooltip", "Track")));
		NewTrack->AddChild(NewAction);
	}
	for (int32 i = 0; i < InTrack->Childs.Num(); ++i)
	{
		UDialogueTrackBase* Child = InTrack->Childs[i];
		auto ChildType = Child->GetType();
		if (bEnableCameraList)
		{
			if (bInCameraList)
			{
				if (ChildType != EDialogueTrack::Type::Camera && ChildType!=EDialogueTrack::Type::Actor)
				{
					continue;
				}
			}else
			{
				if (ChildType == EDialogueTrack::Type::Camera)
				{
					continue;
				}
			}
		}
		NewTrack->AddChild(RoamTrack(Child, bInCameraList));
	}
	return NewTrack;
}

void FDialogueEditorTimelineController::GetAllTracks(const TSharedRef<class FAnimTimelineTrack>& Parent, TArray<TSharedRef<class FAnimTimelineTrack>>& Ret)
{
	Ret.Add(Parent);
	const TArray<TSharedRef<FAnimTimelineTrack>>& ParentChildren = Parent->GetChildren();
	for (const TSharedRef<FAnimTimelineTrack>& Child : ParentChildren)
	{
		GetAllTracks(Child, Ret);
	}
}

TArray<TSharedRef<class FAnimTimelineTrack>> FDialogueEditorTimelineController::GetAllTracks()
{
	TArray<TSharedRef<class FAnimTimelineTrack>> AllTracks;
	for (int32 i = 0; i < RootTracks.Num(); i++) GetAllTracks(RootTracks[i], AllTracks);
	return AllTracks;
}

void FDialogueEditorTimelineController::RefreshTracksImplementation(bool NeedNotifyRefreshed)
{
	if (!CachedEditor.IsValid() || !CachedPreviewProxy.IsValid()) return;

	UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (!Asset) return;

	FDialogueEpisode* EpisodePtr = Asset->GetEpisodePointerByIndex(EpisodeIndex);
	if (!EpisodePtr) return;
	CachedEditor.Pin()->SetTrackSelected(nullptr);

	// 清除轨道选取信息
	ClearTrackSelection();

	// 记录轨道的展开信息
	// 需要通过GetChildren 获取所有子项的展开信息
	TMap<FString, bool> GroupExpandStateMap;
	TArray<TSharedRef<class FAnimTimelineTrack>> AllTracks = GetAllTracks();
	for (TSharedRef<class FAnimTimelineTrack> ChildTrack : AllTracks)
	{
		if (FAnimTimelineTrack* tGroup = &ChildTrack.Get())
		{
			if (FDialogueEditorTrack* DialogueEditorTrack = static_cast<FDialogueEditorTrack*>(tGroup))
			{
				UObject* DialogueCachedTrack = DialogueEditorTrack->GetCachedTrack();
				if (UDialogueTrackBase* DialogueTrackBase = Cast<UDialogueTrackBase>(DialogueCachedTrack))
				{
					GroupExpandStateMap.Add(DialogueTrackBase->GetTrackName().ToString(), tGroup->IsExpanded());
				}
			}
		}
	}

	// 清除所有轨道
	RootTracks.Empty();

	// 重新创建各个轨道
	for (int32 k = 0; k < EpisodePtr->TrackList.Num(); ++k)
	{
		UDialogueTrackBase* TheTrack = EpisodePtr->TrackList[k];
		if (bEnableCameraList && bCameraList)
		{
			if (TheTrack->GetType() != EDialogueTrack::Type::Camera && TheTrack->GetType() != EDialogueTrack::Type::Actor)
			{
				continue;
			}
		}
		TSharedRef<FDialogueEditorTrack> RoamTrackPtr = RoamTrack(TheTrack, bCameraList);
		if (TheTrack->IsA(UDialogueDialogueTrack::StaticClass()))
		{
			RootTracks.Insert(RoamTrackPtr, 0);
		}
		else
		{
			RootTracks.Add(RoamTrackPtr);
		}
	}

	//重建后，恢复折叠信息
	AllTracks = GetAllTracks();
	for (TSharedRef<class FAnimTimelineTrack> ChildTrack : AllTracks)
	{
		if (FAnimTimelineTrack* tGroup = &ChildTrack.Get())
		{
			if (FDialogueEditorTrack* DialogueEditorTrack = static_cast<FDialogueEditorTrack*>(tGroup))
			{
				UObject* DialogueCachedTrack = DialogueEditorTrack->GetCachedTrack();
				if (UDialogueTrackBase* DialogueTrackBase = Cast<UDialogueTrackBase>(DialogueCachedTrack))
				{
					bool* OldExpand = GroupExpandStateMap.Find(DialogueTrackBase->GetTrackName().ToString());
					if (OldExpand) tGroup->SetExpanded(*OldExpand);
					else tGroup->SetExpanded(true);
				}
			}
		}
	}

	TracksChangedEvent.Broadcast();

	if (NeedNotifyRefreshed)
	{
		TracksRefreshedEvent.Broadcast();
	}
}

void FDialogueEditorTimelineController::RefreshTracks()
{
	RefreshTracksImplementation();
}

float FDialogueEditorTimelineController::GetPlayLength() const
{
	UDialogueBaseAsset* Asset = CachedPreviewProxy->GetPreviewAsset();
	if (::IsValid(Asset))
	{
		if (auto* Episode = Asset->GetEpisodePointerByIndex(EpisodeIndex))
		{
			return Episode->Duration;
		}
	}

	return 0.f;
}

double FDialogueEditorTimelineController::GetFrameRate() const
{
	return 30.0f;
}

int32 FDialogueEditorTimelineController::GetEpisodeID()
{
	return EpisodeIndex;
}

FFrameNumber FDialogueEditorTimelineController::GetScrubPosition() const
{
	if (!CachedPreviewProxy.IsValid()) return FFrameNumber(0);
	if (CachedPreviewProxy->IsPlaying())
	{
		//正在播放
		float CurTime = CachedPreviewProxy->GetCurrentTime(0) * GetTickResolution();
		return FFrameNumber(FMath::RoundToInt(CurTime));
	}
	float CurTime = CachedPreviewProxy->GetCachedEditor().Pin()->PlayStartTime * GetTickResolution();
	return FFrameNumber(FMath::RoundToInt(CurTime));
}

void FDialogueEditorTimelineController::SetScrubPosition(FFrameTime NewScrubPostion) const
{
	float TickResolution = GetTickResolution();
	float PreviewStartTime = NewScrubPostion.FrameNumber.Value / TickResolution;
	//防止拖成负数
	PreviewStartTime = PreviewStartTime < 0 ? 0 : PreviewStartTime;
	CachedPreviewProxy->GetCachedEditor().Pin()->SetPlayStartTime(PreviewStartTime);
}

TArray<float> FDialogueEditorTimelineController::GetAssistLinePosX()
{
	TArray<float> Ret;
	if (const UDialogueEditorPreviewSettings* DialogueEditorPreviewSettings = GetDefault<UDialogueEditorPreviewSettings>())
	{
		bool CollectAssistLines = false;
		if (DialogueEditorPreviewSettings->AssistLineShowStrategy == EAssistLineShowStrategy::AlwaysShow)
		{
			//辅助线始终显示
			CollectAssistLines = true;
		}
		else if (DialogueEditorPreviewSettings->AssistLineShowStrategy == EAssistLineShowStrategy::NeverShow)
		{
			//从不显示
			CollectAssistLines = false;
		}
		else if (DialogueEditorPreviewSettings->AssistLineShowStrategy == EAssistLineShowStrategy::DragShowAll || DialogueEditorPreviewSettings->AssistLineShowStrategy == EAssistLineShowStrategy::DragShowNearest)
		{
			//拖拽显示
			for (TSharedRef<FAnimTimelineTrack> ChildTrack : GetAllTracks())
			{
				if (FAnimTimelineTrack* AnimTimelineTrack = &ChildTrack.Get())
				{
					if (FDialogueEditorTrack* DialogueEditorTrack = static_cast<FDialogueEditorTrack*>(AnimTimelineTrack))
					{
						if (DialogueEditorTrack->IsSectionBeDragged())
						{
							CollectAssistLines = true;
							break;
						}
					}
				}
			}
		}

		if (CollectAssistLines)
		{
			for (TSharedRef<FAnimTimelineTrack> ChildTrack : GetAllTracks())
			{
				if (FAnimTimelineTrack* AnimTimelineTrack = &ChildTrack.Get())
				{
					if (FDialogueEditorTrack* DialogueEditorTrack = static_cast<FDialogueEditorTrack*>(AnimTimelineTrack))
					{
						Ret += DialogueEditorTrack->GetAssistLinePosX();
					}
				}
			}
		}
	}

	return Ret;
}

FLinearColor FDialogueEditorTimelineController::GetAssistLineColor()
{
	if (const UDialogueEditorSettings* DialogueEditorSettings = GetDefault<UDialogueEditorSettings>())
	{
		return DialogueEditorSettings->AssistLineColor;
	}
	return FLinearColor::Yellow;
}

void FDialogueEditorTimelineController::OnClassPicked(UClass* InTrackClass)
{
	if (CanAddTrack(InTrackClass))
	{
		AddNewTrack(InTrackClass);
	}
	FSlateApplication::Get().DismissAllMenus();
}

void FDialogueEditorTimelineController::OnActorOnlyTrackClassPicked(UClass* InTrackClass)
{
	if (CanAddTrack(InTrackClass))
	{
		TSharedPtr<FAnimTimelineTrack> SelectTrack = SelectedTracks.Array()[0];
		TSharedPtr<FDialogueEditorTrack> DialogueEditorTrack = StaticCastSharedPtr<FDialogueEditorTrack>(SelectTrack);
		if (!DialogueEditorTrack)
		{
			UE_LOG(LogTemp, Error, TEXT("Track Type Error"));
			return;
		}

		TSharedPtr<FDialogueTrackEditor> TrackEditor = DialogueEditorTrack.Get()->GetTrackEditor();
		if (TSharedPtr<FDialogueActorTrackEditor> ActorTrackEditor = StaticCastSharedPtr<FDialogueActorTrackEditor>(TrackEditor))
		{
			ActorTrackEditor->AddActorSubTrack(InTrackClass);
		}
	}
}

UDialogueEntity* FDialogueEditorTimelineController::AddNewTrack(UClass* InTrackClass, FString DetermineTrackName, const FVector& InSpawnLocation, const FRotator& InSpawnRotation, const bool& UseParentTransform)
{
	UE_LOG(LogTemp, Log, TEXT("Execute AddNewTrack %s"), *InTrackClass->GetName());
	if (TrackClassPickWidget.IsValid())
	{
		SClassViewer* ClassView = static_cast<SClassViewer*>(TrackClassPickWidget.Pin().Get());
		ClassView->ClearSelection();
	}

	UDialogueBaseAsset* Asset = CachedPreviewProxy->GetPreviewAsset();
	if (!IsValid(Asset)) return nullptr;

	UDialogueEntity* DialogueEntity = nullptr;

	//以下代码做了如下几件事情
	//1. NewObject Track
	//2. for SpawnableTrack, NewObject Entity, Create EntityActor 建立Track和Entity的联系
	//3. for SpawnableTrack, 在每个Episode下面创建副本
	//4. for Action Track, Add To Episode TrackList
	//Track类型由蓝图配置而来
	if (UDialogueTrackBase* NewTrack = NewObject<UDialogueTrackBase>(Asset, InTrackClass, NAME_None, RF_Transactional))
	{
		FString ScopeText = FString::Printf(TEXT("Dialogue Add New Track %s"), *(InTrackClass->GetName()));
		FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);

		Asset->SetFlags(EObjectFlags::RF_Transactional);
		Asset->Modify();

		NewTrack->FromTemplate = !Asset->IsA(UDialogueAsset::StaticClass());
		UDialogueEditorSettings* DESettings = GetMutableDefault<UDialogueEditorSettings>();
		UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(NewTrack);
		if (SpawnableTrack)
		{
			//Track对应生成的Entity，Class由Settings配置得到
			TSubclassOf<UDialogueEntity>* TrackEntityClass = DESettings->TrackEntityClass.Find(SpawnableTrack->GetClass());
			if (TrackEntityClass)
			{
				FString AvailableTrackName = GenerateAvailableTrackName(Asset, SpawnableTrack->NamePrefix);
				if (DetermineTrackName != "") AvailableTrackName = DetermineTrackName;
				NewTrack->SetTrackName(FText::FromString(AvailableTrackName));

				DialogueEntity = NewObject<UDialogueEntity>(Asset, *TrackEntityClass, NAME_None, RF_Transactional);

				if (CopyTrackInfo.IsValid())
				{
					//如果是从这个轨道复制出来的，则拷贝Entity信息
					DialogueEntity->DuplicateFromEntityInfo(CopyTrackInfo.Get()->GetDialogueEntity());
				}
				//绑定Track和Entity的对应关系
				SpawnableTrack->SetDialogueEntity(DialogueEntity);
				//创建Entity后，加入到Asset的列表中
				Asset->AddDialogueEntity(DialogueEntity);
			}
		}


		//为了保证每个Episode都有相同的Actor Camera，所有的Episode都要有新加的Track
		if (SpawnableTrack && SpawnableTrack->ExistInPerEpisode)
		{
			//这些需要复制到其他Episode的，默认加入第0个Episode里面
			//然后其他Episode也分别添加
			Asset->AddTrack(0, NewTrack, 0);
			if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(Asset))
			{
				//从第1个开始Roam，把这个Track Roam到后面的Episode里面去
				for (int i = 1; i < DialogueAsset->Episodes.Num(); ++i)
				{
					UDialogueTrackBase* NewEpisodeTrack = DialogueAsset->RoamTrack(NewTrack);
					DialogueAsset->AddTrack(i, NewEpisodeTrack, 0);
				}

				//添加Actor 轨道后，需要更新ActorInfos
				DialogueAsset->UpdateActorInfosData();
			}

			if (MenuFromTrack.IsEmpty() && Asset->Episodes.Num() > 0)
			{
				//从全局添加的Track
				//我们计算是否已经有一个锚点了，如果有，则要将USpawnable的Track加入到锚点下面
				for (int i = Asset->Episodes[0].TrackList.Num() - 1; i >= 0; --i)
				{
					UDialogueTrackBase* Track = Asset->Episodes[0].TrackList[i];
					if (UDialogueSpawnableTrack* IsSpawnableTrack = Cast<UDialogueSpawnableTrack>(Track))
					{
						//已经有一个锚点了，说明有多个锚点同级别，需要将新建的Track挂到它下面
						MenuFromTrack = Track->GetTrackName().ToString();
						break;
					}
				}
			}

			if (!MenuFromTrack.IsEmpty())
			{
				//如果是从某个Track上创建的，应该是加入到这个Track下面
				UE_LOG(LogTemp, Log, TEXT("spawn track from exist track %s, now add to track as child"), *MenuFromTrack);
				for (FDialogueEpisode& Episode : Asset->Episodes)
				{
					ChangeEpisodeTrackPosition(&Episode, NewTrack->GetTrackName().ToString(), MenuFromTrack, EItemDropZone::OntoItem);
				}

				if (!CopyTrackInfo.IsValid())
				{
					//不是直接拷贝的，则需要放置到Parent的原点
					//加为子Track，并设置移动为0
					if (UseParentTransform)
					{
						SpawnableTrack->GetDialogueEntity()->SpawnTransform = FTransform::Identity;
					}
					else 
					{
						SpawnableTrack->GetDialogueEntity()->SpawnTransform = FTransform(InSpawnRotation
							.Quaternion(), InSpawnLocation) * SpawnableTrack->GetDialogueEntity()->GetParentTransform().Inverse();
					}
					SpawnableTrack->GetDialogueEntity()->OnSpawnTransformChanged();
					UE_LOG(LogTemp, Log, TEXT("spawn track from exist track %s, now add to track as child"), *(SpawnableTrack->GetDialogueEntity()->GetParentTransform()* SpawnableTrack->GetDialogueEntity()->GetParentTransform().Inverse()).ToString());
				}
			}
			if (CopyTrackInfo.IsValid())
			{
				//如果是从这个轨道复制出来的，需要重置Transform新，因为这个Transform可能被拖拽操作给修改了
				SpawnableTrack->GetDialogueEntity()->SpawnTransform = CopyTrackInfo.Get()->GetDialogueEntity()->SpawnTransform;
				SpawnableTrack->GetDialogueEntity()->OnSpawnTransformChanged();
			}
		}
		else
		{
			//不需要复制的，直接添加在当前Episode
			//插在第0个位置，免得Actor数量多了之后，每次都要下拉很久再拖到锚点下面
			if (UDialogueActionTrack* TrackAction = Cast<UDialogueActionTrack>(NewTrack))
			{
				if (UDialogueAutoCameraCutTrack* AutoCameraCutAction = Cast<UDialogueAutoCameraCutTrack>(TrackAction))
				{
					TMap<FString, UDialogueCameraTrack*> CameraTracksBefore = Asset->GetEpisodePointerByIndex(EpisodeIndex)->GetTrackCameras();
					if (!CameraTracksBefore.Contains(TEXT("AutoCamera")))
					{
						AddNewTrack(UDialogueCameraTrack::StaticClass(),TEXT("AutoCamera"));
					}
					//还没跟策划梳理好顺序逻辑 先单独对AutoCamera处理下
					Asset->AddTrack(EpisodeIndex, NewTrack, Asset->GetCameraCutIndex(EpisodeIndex) + 1);
				}
				else
				{
					Asset->AddTrack(EpisodeIndex, NewTrack, 0);
				}
			}
			else Asset->AddTrack(EpisodeIndex, NewTrack, 0);
		}

		RefreshTracks();
		//FDialogueEditorDelegates::AddTaskEvent.Broadcast(NewTrack);
	}

	if (UDialogueEditorManager* DialogueEditorManager = CachedEditor.Pin()->GetDialogueEditorManager())
	{
		DialogueEditorManager->OnAssetPostEdit(Asset);
	}
	if (DialogueEntity)
	{
		//往预览场景中生成一个EntityActor
		CachedEditor.Pin()->AddDialogueActor(DialogueEntity);
	}
	return DialogueEntity;
}

void FDialogueEditorTimelineController::RemoveAllSelectedTracks()
{
	TArray<TSharedRef<FAnimTimelineTrack>> RemovedTracks;
	for (TSharedRef<FAnimTimelineTrack>& SelectedItem : SelectedTracks)
	{
		RemovedTracks.Add(SelectedItem);
	}

	for (int32 i = 0; i < RemovedTracks.Num(); ++i)
	{
	    if (Cast<UDialogueTrackBase>(RemovedTracks[i]->GetCachedTrack()))
	    {
	        RemoveTrack(Cast<UDialogueTrackBase>(RemovedTracks[i]->GetCachedTrack()));
	    }
	    else
	    {
	        checkf(false, TEXT("Only support UDialogueTrackBase, track:%s"), *RemovedTracks[i]->GetLabel().ToString());
	    }
	}
}

void FDialogueEditorTimelineController::CopySelectedTrack()
{
	if (SelectedTracks.Num() > 0)
	{
		TSharedPtr<class FAnimTimelineTrack> SelectTrack = SelectedTracks.Array()[0];

		if (TSharedPtr<class FDialogueEditorTrack> EditorTrack = StaticCastSharedPtr<class FDialogueEditorTrack>(SelectTrack))
		{
			if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(EditorTrack->GetCachedTrack()))
			{
				CopyTrackInfo = SpawnableTrack;
			}
		}
	}
}

void FDialogueEditorTimelineController::PasteCopyTrack()
{
	if (CopyTrackInfo.IsValid())
	{
		//所谓的Paste，其实就相当于在当前所选择的Track的parent右键菜单，添加新Track，然后设置上下文的CopyTrackInfo
		//拷贝的时候，我们拷贝到当前所选择的Track的parent去（而不是拷贝的目标的Track的Parent）
		if (SelectedTracks.Num() > 0)
		{
			TSharedPtr<class FAnimTimelineTrack> SelectTrack = SelectedTracks.Array()[0];

			if (TSharedPtr<class FDialogueEditorTrack> EditorTrack = StaticCastSharedPtr<class FDialogueEditorTrack>(SelectTrack))
			{
				if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(EditorTrack->GetCachedTrack()))
				{
					if (SpawnableTrack->Parent) MenuFromTrack = SpawnableTrack->Parent->GetTrackName().ToString();

					//拷贝的时候，需要拷贝Track对应的Entity信息
					//注意，这里只拷贝了Entity信息，没有Roam整个Track信息
					AddNewTrack(CopyTrackInfo.Get()->GetClass());
					CopyTrackInfo = nullptr;
				}
			}
		}
	}
}

bool RemoveChildTrack(UDialogueTrackBase* Parent, const FString& ToRemoveTrackName)
{
	if (Parent == nullptr) return false;
	for (UDialogueTrackBase* Child : Parent->Childs)
	{
		if (Child->GetTrackName().ToString() == ToRemoveTrackName)
		{
			Parent->Modify();
			Parent->Childs.Remove(Child);
			return true;
		}
		if (RemoveChildTrack(Child, ToRemoveTrackName)) return true;
	}
	return false;
}

void FDialogueEditorTimelineController::RemoveTrack(UDialogueTrackBase* Track)
{
	UDialogueBaseAsset* Asset = CachedPreviewProxy->GetPreviewAsset();
	if (::IsValid(Asset))
	{
		FString ScopeText = FString::Printf(TEXT("Dialogue Remove Action Track %s"), IsValid(Track) ? *(Track->GetTrackName().ToString()) : TEXT("InvalidTrack"));
		FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);
		Asset->SetFlags(EObjectFlags::RF_Transactional);
		Asset->Modify();

		if (UDialogueActionTrack* DialogueAction = Cast<UDialogueActionTrack>(Track))
		{
			//删除普通的行为类轨道，只需要删除自身即可，将自己从Parent里面移除
			if (DialogueAction->Parent)
			{
				//这个Action在一个Parent里面
				//为什么这个Modify处理不提升到上一个scope？因为如果是SpawnableTrack，则处理本身Parent还不够，必须处理同名的Track的Parent，因此Action和SpawnableTrack分开处理
				Track->Parent->SetFlags(EObjectFlags::RF_Transactional);
				Track->Parent->Modify();
				DialogueAction->Parent->RemoveAction(DialogueAction);
			}
			else
			{
				//不在Parent里面，说明是Root级别的Track
				//只删除当前Episode的Track，因为Action类型的Track不会在Episode之间复制，所以只删除当前的即可
				if (FDialogueEpisode* EpisodeRef = Asset->GetEpisodePointerByIndex(EpisodeIndex))
				{
					EpisodeRef->TrackList.Remove(Track);
				}
			}
		}
		else if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(Track))
		{
			//下面这一堆代码，其实就干了两件事
			//1. 修改DialogueAsset的Entity数组
			//2. 将Track从Parent的Track里面删除
			//所以Undo Redo要处理的有两个目标，1个Asset本身，这是由于Entity
			// 第2个Track的Parent，因为可能一次性删除多个同名Track，所以多个Parent都要Modify
			TArray<UDialogueTrackBase*> AllChildTracks;
			Track->GetAllChildTracks(AllChildTracks);

			//删除一个Tracks，需要删除它所有的子Track对应的Entity数据
			for (UDialogueTrackBase* ChildBaseTrack : AllChildTracks)
			{
				if (UDialogueSpawnableTrack* ChildSpawnableTrack = Cast<UDialogueSpawnableTrack>(ChildBaseTrack))
				{
					Asset->RemoveDialogueEntity(ChildSpawnableTrack->GetDialogueEntity());
					CachedEditor.Pin()->RemoveDialogueActor(ChildSpawnableTrack->GetDialogueEntity());
					//ChildSpawnableTrack->SetDialogueEntity(nullptr);
					UE_LOG(LogTemp, Warning, TEXT("Remove ChildSpawnableTrack %s ,同时移除子Track %s"), *Track->GetTrackName().ToString(), *ChildBaseTrack->GetTrackName().ToString())
				}
				else
				{
					UE_LOG(LogTemp, Warning, TEXT("Remove ChildSpawnableTrack %s ，它的子Track %s不是SpawnableTrack !!"), *Track->GetTrackName().ToString(), *ChildBaseTrack->GetTrackName().ToString())
				}
			}
			//再删除本Track对应的Entity数据
			Asset->RemoveDialogueEntity(SpawnableTrack->GetDialogueEntity());
			CachedEditor.Pin()->RemoveDialogueActor(SpawnableTrack->GetDialogueEntity());
			//SpawnableTrack->SetDialogueEntity(nullptr);

			//删除一个Track(Actor Or Camera)，要删除所有Episode里面的Track数据
			//因为所有Episode的Track对应的Entity是通用的，我们在上面的处理中已经删除了Entity，所以接下来只要删除Track本身即可
			for (FDialogueEpisode& Episode : Asset->Episodes)
			{
				int RemoveCount = Episode.TrackList.RemoveAll([Track](UDialogueTrackBase* Element) { return Element->GetTrackName().ToString() == Track->GetTrackName().ToString(); });
				if (RemoveCount == 0)
				{
					for (UDialogueTrackBase* TrackBase : Episode.TrackList)
					{
						if (RemoveChildTrack(TrackBase, Track->GetTrackName().ToString())) break;
					}
				}
			}
			//删除一个Track(Actor Or Camera)，更新对应的ActorsInfo
			if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(Asset))
			{
				DialogueAsset->UpdateActorInfosData();
			}
		}

		RefreshTracks();
		if (UDialogueEditorManager* DialogueEditorManager = CachedEditor.Pin()->GetDialogueEditorManager())
		{
			DialogueEditorManager->OnAssetPostEdit(Asset);
		}
	}
}

void FDialogueEditorTimelineController::BuildContextMenu(FMenuBuilder& InMenuBuilder)
{
	UE_LOG(LogTemp, Log, TEXT("FDialogueEditorTimelineController::BuildContextMenu"));
	if (SelectedTracks.Num() > 0)
	{
		TSharedPtr<class FAnimTimelineTrack> SelectTrack = SelectedTracks.Array()[0];

		if (TSharedPtr<class FDialogueEditorTrack> EditorTrack = StaticCastSharedPtr<class FDialogueEditorTrack>(SelectTrack))
		{
			UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(EditorTrack->GetCachedTrack());

			InMenuBuilder.BeginSection("Edit Actions", LOCTEXT("NotifiesMenuSection_BuildContextMenu", "Edit"));
			InMenuBuilder.AddMenuEntry(LOCTEXT("Action_RemoveTrack_Lable", "Remove Track"), LOCTEXT("Action_RemoveTrack_Tooltip", "Remove the track"), FSlateIcon(), FUIAction(FExecuteAction::CreateSP(this, &FDialogueEditorTimelineController::RemoveAllSelectedTracks)), NAME_None, EUserInterfaceActionType::Button);
			if (SpawnableTrack)
			{
				//只有SpawnableTrack才显示Copy Paste
				if (CopyTrackInfo.IsValid())
				{
					//如果已经拷贝了，显示粘贴命令
					InMenuBuilder.AddMenuEntry(LOCTEXT("Action_PasteTrack_Lable", "Paste Track"), LOCTEXT("Action_PasteTrack_Tooltip", "Pastethe track"), FSlateIcon(), FUIAction(FExecuteAction::CreateSP(this, &FDialogueEditorTimelineController::PasteCopyTrack)), NAME_None, EUserInterfaceActionType::Button);
				}
				else
				{
                    
                    if(SpawnableTrack->CanCopy())
                    {
                        //没有拷贝目标，显示拷贝命令
                        InMenuBuilder.AddMenuEntry(LOCTEXT("Action_CopyTrack_Lable", "Copy Track"), LOCTEXT("Action_CopyTrack_Tooltip", "Copy the track"), FSlateIcon(), FUIAction(FExecuteAction::CreateSP(this, &FDialogueEditorTimelineController::CopySelectedTrack)), NAME_None, EUserInterfaceActionType::Button);
                    }
				}
			}
			InMenuBuilder.EndSection();

			if (SpawnableTrack)
			{
				//只有SpawnableTrack才能添加子Track
				BuildTrackActionMenu(InMenuBuilder, true);
				MenuFromTrack = SpawnableTrack->GetTrackName().ToString();
			}
		}
	}


	FTimelineController::BuildContextMenu(InMenuBuilder);
}

void FDialogueEditorTimelineController::BuildTrackActionMenu(FMenuBuilder& InMenuBuilder, bool FromActorTrack)
{
	UE_LOG(LogTemp, Log, TEXT("FDialogueEditorTimelineController::BuildTrackActionMenu"));

	InMenuBuilder.BeginSection("Track Actions", LOCTEXT("NotifiesMenuSection_BuildTrackActionMenu", "Tracks"));
	{
		InMenuBuilder.AddSubMenu(LOCTEXT("Action_AddTrack_Label_AddTrack", "Add Track"), LOCTEXT("Action_AddTrack_Tooltip_AddTrack", "Add a new track"), FNewMenuDelegate::CreateRaw(this, &FDialogueEditorTimelineController::FillNewTrackMenu, FromActorTrack));
		if (!FromActorTrack)
		{
			InMenuBuilder.AddSubMenu(LOCTEXT("Action_AddTrack_Label_AddSpecialTrack", "Add Special Track"), LOCTEXT("Action_AddTrack_Tooltip_AddSpecialTrack", "Add a new Special track"), FNewMenuDelegate::CreateRaw(this, &FDialogueEditorTimelineController::FillSpecialTrackMenu, CachedEditor.Pin()->IsTemplateMode()));
			InMenuBuilder.AddSubMenu(LOCTEXT("Action_AddTrack_Label_AllTrack", "All Track"), LOCTEXT("Action_AddTrack_Tooltip_AllTrack", "All Track"), FNewMenuDelegate::CreateRaw(this, &FDialogueEditorTimelineController::FillAllTracks));
			InMenuBuilder.AddSubMenu(LOCTEXT("Action_AddTrack_Label_OnlyActorCanCreateTrack", "Only Actor Can Create Track"), LOCTEXT("Action_AddTrack_Tooltip_OnlyActorCanCreateTrack", "Only Actor Can Create Track"), FNewMenuDelegate::CreateRaw(this, &FDialogueEditorTimelineController::FillActorOnlyTracks));
		}
	}
	InMenuBuilder.EndSection();
	MenuFromTrack.Reset();
}

void FDialogueEditorTimelineController::FillNewTrackMenu(class FMenuBuilder& MenuBuilder, bool FromActorTrack)
{
	TrackClassPickWidget = FDialogueEditorUtilities::MakeNewTrackPicker(MenuBuilder, FOnClassPicked::CreateSP(this, &FDialogueEditorTimelineController::OnClassPicked), CachedEditor.Pin()->IsTemplateMode(), FromActorTrack);
}

void FDialogueEditorTimelineController::FillSpecialTrackMenu(class FMenuBuilder& MenuBuilder, bool IsTemplateMode)
{
	class FNotifyStateClassFilter : public IClassViewerFilter
	{
	public:
		FNotifyStateClassFilter(bool IsTemplateMode)
			: bTemplateMode(IsTemplateMode)
		{
		}

		bool IsClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const UClass* InClass, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			const bool bMatchesFlags = !InClass->HasAnyClassFlags(CLASS_Hidden | CLASS_HideDropDown | CLASS_Deprecated | CLASS_Abstract);

			UDialogueEditorSettings* DialogueEditorSettings = GetMutableDefault<UDialogueEditorSettings>();
			bool ClassValid = DialogueEditorSettings->SpecialSubTracks.Contains(InClass);

			bool bChildOfObjectClass = (!bTemplateMode && ClassValid);

			return bChildOfObjectClass && bMatchesFlags;
		}

		virtual bool IsUnloadedClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const TSharedRef<const IUnloadedBlueprintData> InUnloadedClassData, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			return false;
		}

	private:
		bool bTemplateMode;
	};

	if (MenuBuilder.GetMultiBox()->GetBlocks().Num() > 1)
	{
		MenuBuilder.AddMenuSeparator();
	}

	FClassViewerInitializationOptions InitOptions;
	InitOptions.Mode = EClassViewerMode::ClassPicker;
	InitOptions.bShowObjectRootClass = false;
	InitOptions.bShowUnloadedBlueprints = true;
	InitOptions.bShowNoneOption = false;
	InitOptions.bEnableClassDynamicLoading = true;
	InitOptions.bExpandRootNodes = true;
	InitOptions.NameTypeToDisplay = EClassViewerNameTypeToDisplay::DisplayName;
	InitOptions.ClassFilters.Add(MakeShared<FNotifyStateClassFilter>(IsTemplateMode));
	InitOptions.bShowBackgroundBorder = false;

	FClassViewerModule& ClassViewerModule = FModuleManager::LoadModuleChecked<FClassViewerModule>("ClassViewer");
	TSharedRef<SWidget> ClassViewWidget = ClassViewerModule.CreateClassViewer(InitOptions, FOnClassPicked::CreateSP(this, &FDialogueEditorTimelineController::OnClassPicked));
	MenuBuilder.AddWidget(SNew(SBox).MinDesiredWidth(300.0f).MaxDesiredHeight(400.0f)
	[
		ClassViewWidget
	], FText(), true, false);
}

void FDialogueEditorTimelineController::FillAllTracks(FMenuBuilder& MenuBuilder)
{
	class FStoryLineTrackClassFilter : public IClassViewerFilter
	{
	public:
		FStoryLineTrackClassFilter()
		{
		}

		virtual bool IsClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const UClass* InClass, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			// 几个类特殊处理
			if (InClass->GetName().Equals("DialogueAction") || InClass->GetName().Equals("DialogueBPTrack"))
			{
				return false;
			}

			const bool bMatchesFlags = !InClass->HasAnyClassFlags(CLASS_Hidden | CLASS_HideDropDown | CLASS_Deprecated | CLASS_Abstract);

			bool bDeprecated = false;
			if (const UDialogueEditorSettings* DialogueEditorSettings = GetDefault<UDialogueEditorSettings>())
			{
				if (DialogueEditorSettings->DeprecatedTrackClass.Contains(InClass))
				{
					bDeprecated = true;
				}
			}

			return InClass->IsChildOf(UDialogueTrackBase::StaticClass()) && bMatchesFlags && !bDeprecated;
		}

		virtual bool IsUnloadedClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const TSharedRef<const IUnloadedBlueprintData> InUnloadedClassData, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			return false;
		}
	};

	FClassViewerInitializationOptions InitOptions;
	InitOptions.Mode = EClassViewerMode::ClassPicker;
	InitOptions.bShowObjectRootClass = false;
	InitOptions.bShowUnloadedBlueprints = true;
	InitOptions.bShowNoneOption = false;
	InitOptions.bEnableClassDynamicLoading = true;
	InitOptions.bExpandRootNodes = true;
	InitOptions.NameTypeToDisplay = EClassViewerNameTypeToDisplay::DisplayName;
	InitOptions.ClassFilters.Add(MakeShared<FStoryLineTrackClassFilter>());
	InitOptions.bShowBackgroundBorder = false;

	FClassViewerModule& ClassViewerModule = FModuleManager::LoadModuleChecked<FClassViewerModule>("ClassViewer");
	TSharedRef<SWidget> ClassViewWidget = ClassViewerModule.CreateClassViewer(InitOptions, FOnClassPicked::CreateSP(this, &FDialogueEditorTimelineController::OnClassPicked));
	MenuBuilder.AddWidget(SNew(SBox).MinDesiredWidth(300.0f).MaxDesiredHeight(400.0f)
	[
		ClassViewWidget
	], FText(), true, false);
}

void FDialogueEditorTimelineController::FillActorOnlyTracks(FMenuBuilder& MenuBuilder)
{
	class FStoryLineTrackClassFilter : public IClassViewerFilter
	{
	public:
		FStoryLineTrackClassFilter()
		{
		}

		virtual bool IsClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const UClass* InClass, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			const bool bMatchesFlags = !InClass->HasAnyClassFlags(CLASS_Hidden | CLASS_HideDropDown | CLASS_Deprecated | CLASS_Abstract);

			if (UDialogueEditorSettings* Settings = GetMutableDefault<UDialogueEditorSettings>())
			{
				TArray<TSubclassOf<UDialogueActionTrack>>* ActorSubTracks = nullptr;
				for (auto& SubTrackSetting : Settings->ActorSubTracks)
				{
					if (SubTrackSetting.ActorTrackClass == UDialogueActorTrack::StaticClass())
					{
						ActorSubTracks = &SubTrackSetting.SubTrackClasses;
						break;
					}
				}

				if (ActorSubTracks)
				{
					return (*ActorSubTracks).Contains(InClass) && bMatchesFlags;
				}
			}

			return false;
		}

		virtual bool IsUnloadedClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const TSharedRef<const IUnloadedBlueprintData> InUnloadedClassData, TSharedRef<FClassViewerFilterFuncs> InFilterFuncs) override
		{
			return false;
		}
	};

	FClassViewerInitializationOptions InitOptions;
	InitOptions.Mode = EClassViewerMode::ClassPicker;
	InitOptions.bShowObjectRootClass = false;
	InitOptions.bShowUnloadedBlueprints = true;
	InitOptions.bShowNoneOption = false;
	InitOptions.bEnableClassDynamicLoading = true;
	InitOptions.bExpandRootNodes = true;
	InitOptions.NameTypeToDisplay = EClassViewerNameTypeToDisplay::DisplayName;
	InitOptions.ClassFilters.Add(MakeShared<FStoryLineTrackClassFilter>());
	InitOptions.bShowBackgroundBorder = false;

	FClassViewerModule& ClassViewerModule = FModuleManager::LoadModuleChecked<FClassViewerModule>("ClassViewer");
	TSharedRef<SWidget> ClassViewWidget = ClassViewerModule.CreateClassViewer(InitOptions, FOnClassPicked::CreateSP(this, &FDialogueEditorTimelineController::OnActorOnlyTrackClassPicked));
	MenuBuilder.AddWidget(SNew(SBox).MinDesiredWidth(300.0f).MaxDesiredHeight(400.0f)
	[
		ClassViewWidget
	], FText(), true, false);
}

void FDialogueEditorTimelineController::ChangeEpisodeTrackPosition(FDialogueEpisode* Episode, const FString& SrcTrackName, const FString& DestTrackName, EItemDropZone DropZone)
{
	if (SrcTrackName == DestTrackName) return;
	TArray<UDialogueTrackBase*> AllTracks = Episode->GetAllTracks();

	UDialogueTrackBase* SrcTrack = nullptr;
	UDialogueTrackBase* DestTrack = nullptr;
	if (UDialogueTrackBase** SrcTrackPtr = AllTracks.FindByPredicate([SrcTrackName](UDialogueTrackBase* Track) { return Track->GetTrackName().ToString() == SrcTrackName; })) SrcTrack = *SrcTrackPtr;
	if (UDialogueTrackBase** DestTrackPtr = AllTracks.FindByPredicate([DestTrackName](UDialogueTrackBase* Track) { return Track->GetTrackName().ToString() == DestTrackName; })) DestTrack = *DestTrackPtr;
	if (SrcTrack == nullptr || DestTrack == nullptr) return;

	UDialogueTrackBase* SrcParent = SrcTrack->Parent;
	UDialogueTrackBase* DestParent = DestTrack->Parent;

	UDialogueSpawnableTrack* SrcSpawnableTrack = Cast<UDialogueSpawnableTrack>(SrcTrack);
	UDialogueSpawnableTrack* DestSpawnableTrack = Cast<UDialogueSpawnableTrack>(DestTrack);

	UDialogueSpawnableTrack* SrcParentSpawnableTrack = Cast<UDialogueSpawnableTrack>(SrcParent);
	UDialogueSpawnableTrack* DestParentSpawnableTrack = Cast<UDialogueSpawnableTrack>(DestParent);

	if (SrcParent)
	{
		SrcParent->Modify();
		SrcParent->Childs.Remove(SrcTrack);
	}

	if (SrcSpawnableTrack)
	{
		SrcSpawnableTrack->GetDialogueEntity()->SetParent(nullptr);
		SrcSpawnableTrack->GetDialogueEntity()->UpdateSpawnTransform();
	}

	SrcTrack->Parent = nullptr;

	if (DropZone == EItemDropZone::AboveItem || DropZone == EItemDropZone::BelowItem)
	{
		if (DestParent)
		{
			DestParent->Modify();
			int32 Index = DestParent->Childs.Find(DestTrack);
			if (DropZone == EItemDropZone::AboveItem)
			{
				DestParent->Childs.Insert(SrcTrack, Index);
			}
			else
			{
				DestParent->Childs.Insert(SrcTrack, Index + 1);
			}
			SrcTrack->Parent = DestParent;
			if (SrcSpawnableTrack && DestParentSpawnableTrack)
			{
				SrcSpawnableTrack->GetDialogueEntity()->SetParent(DestParentSpawnableTrack->GetDialogueEntity());
				SrcSpawnableTrack->GetDialogueEntity()->UpdateSpawnTransform();
			}
		}
		else
		{
			Episode->TrackList.Remove(SrcTrack);
			int32 Index = Episode->TrackList.Find(DestTrack);
			if (DropZone == EItemDropZone::AboveItem)
			{
				Episode->TrackList.Insert(SrcTrack, Index);
			}
			else
			{
				Episode->TrackList.Insert(SrcTrack, Index + 1);
			}
		}
	}
	else if (DropZone == EItemDropZone::OntoItem)
	{
		DestTrack->Modify();
		DestTrack->AddChild(SrcTrack);
		SrcTrack->Parent = DestTrack;

		if (SrcSpawnableTrack && DestSpawnableTrack)
		{
			SrcSpawnableTrack->GetDialogueEntity()->SetParent(DestSpawnableTrack->GetDialogueEntity());
			SrcSpawnableTrack->GetDialogueEntity()->UpdateSpawnTransform();
		}
	}

	if (SrcTrack->Parent && Episode->TrackList.Contains(SrcTrack))
	{
		Episode->TrackList.Remove(SrcTrack);
	}
}

void FDialogueEditorTimelineController::ChangeTrackPosition(UDialogueTrackBase* SrcTrack, UDialogueTrackBase* DestTrack, EItemDropZone DropZone)
{
	if (SrcTrack == DestTrack) return;

	if (SrcTrack == nullptr || DestTrack == nullptr) return;

	if (!CachedEditor.Pin()->IsStopped()) return;

	UDialogueSpawnableTrack* SrcSpawnableTrack = Cast<UDialogueSpawnableTrack>(SrcTrack);
	UDialogueSpawnableTrack* DestSpawnableTrack = Cast<UDialogueSpawnableTrack>(DestTrack);

	if (SrcSpawnableTrack == nullptr)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("不能改变非Actor轨道的挂接关系")));
		return;
	}

	if (DestSpawnableTrack == nullptr)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("不能挂接到行为类轨道上")));
		return;
	}


	TArray<UDialogueTrackBase*> SrcTrackChildren;
	SrcTrack->GetAllChildTracks(SrcTrackChildren);

	if (SrcTrackChildren.Contains(DestTrack))
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("不能将父级拖到子级上")));
		return;
	}

	UDialogueBaseAsset* Asset = CachedPreviewProxy->GetPreviewAsset();
	if (!IsValid(Asset)) return;

	for (FDialogueEpisode& Episode : Asset->Episodes)
	{
		ChangeEpisodeTrackPosition(&Episode, SrcTrack->GetTrackName().ToString(), DestTrack->GetTrackName().ToString(), DropZone);
	}


	RefreshTracks();

	Asset->GetPackage()->MarkPackageDirty();
}

void FDialogueEditorTimelineController::SetTrackSelected(const TSharedRef<FAnimTimelineTrack>& InTrack, bool bIsSelected)
{
	if (bIsSelected)
	{
		if (CachedEditor.IsValid())
		{
			CachedEditor.Pin()->SetTrackSelected(InTrack->GetCachedTrack());
		}
	}

	bool CtrlSelect = bIsSelected; //CachedEditor.Pin()->CurrentSelectObject.Contains(InTrack->GetCachedTrack());
	FTimelineController::SetTrackSelected(InTrack, CtrlSelect);

	TSharedRef<FDialogueEditorTrack> DialogueTimelineController = ConstCastSharedRef<FDialogueEditorTrack>(StaticCastSharedRef<FDialogueEditorTrack>(InTrack));
	DialogueTimelineController->SetIsSelect(CtrlSelect);
}

void FDialogueEditorTimelineController::SetTrackSelected(UObject* InTrack, bool bSelectActor)
{
	TArray<TSharedRef<class FAnimTimelineTrack>> AllTracks = GetAllTracks();

	for (auto track : AllTracks)
	{
		bool IsSelect = track->GetCachedTrack() == InTrack;
		if (IsSelect)
		{
			if (CachedEditor.IsValid())
			{
				CachedEditor.Pin()->SetTrackSelected(track->GetCachedTrack(), bSelectActor);
			}
		}

		FTimelineController::SetTrackSelected(track, IsSelect);

		TSharedRef<FDialogueEditorTrack> DialogueTimelineController = ConstCastSharedRef<FDialogueEditorTrack>(StaticCastSharedRef<FDialogueEditorTrack>(track));
		DialogueTimelineController->SetIsSelect(IsSelect);
	}
}

void FDialogueEditorTimelineController::DoubleClickTrack(const TSharedRef<class FAnimTimelineTrack>& InTrack)
{
	UE_LOG(LogTemp, Log, TEXT("FDialogueEditorTimelineController::DoubleClickTrack"));
	DoubleClickTrack(InTrack->GetCachedTrack());
}

void FDialogueEditorTimelineController::DoubleClickTrack(UObject* InTrack)
{
	TArray<TSharedRef<class FAnimTimelineTrack>> AllTracks = GetAllTracks();

	for (auto track : AllTracks)
	{
		bool IsSelect = track->GetCachedTrack() == InTrack;
		if (IsSelect)
		{
			if (CachedEditor.IsValid())
			{
				CachedEditor.Pin()->DoubleClickTrack(track->GetCachedTrack());
			}
		}

		FTimelineController::SetTrackSelected(track, IsSelect);

		TSharedRef<FDialogueEditorTrack> DialogueTimelineController = ConstCastSharedRef<FDialogueEditorTrack>(StaticCastSharedRef<FDialogueEditorTrack>(track));
		DialogueTimelineController->SetIsSelect(IsSelect);
	}
}

class FDialogueEditor* FDialogueEditorTimelineController::GetCachedEditor()
{
	if (CachedEditor.IsValid()) return CachedEditor.Pin().Get();
	return nullptr;
}

void FDialogueEditorTimelineController::ClearTrackSelection()
{
	for (TSharedRef<class FAnimTimelineTrack> track : SelectedTracks)
	{
		TSharedRef<FDialogueEditorTrack> DialogueTimelineController = StaticCastSharedRef<FDialogueEditorTrack>(track);
		DialogueTimelineController->SetIsSelect(false);
	}
	FTimelineController::ClearTrackSelection();
}

void FDialogueEditorTimelineController::OnTrackNameChanged()
{
	if (CachedEditor.IsValid())
	{
		UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
		Asset->MarkPackageDirty();
	}
}

void FDialogueEditorTimelineController::OnLockCameraClicked(class UDialogueCamera* DialogueEntityCamera, bool IsLockAutoCamera)
{
	CachedEditor.Pin()->OnLockCameraClicked(DialogueEntityCamera, IsLockAutoCamera);
}

void FDialogueEditorTimelineController::OnInternalAddAutoCameraTrack()
{
	UDialogueBaseAsset* Asset = CachedPreviewProxy->GetPreviewAsset();
	if (!IsValid(Asset))
	{
		return;
	}

	TMap<FString, UDialogueCameraTrack*> CameraTracksBefore = Asset->GetEpisodePointerByIndex(EpisodeIndex)->GetTrackCameras();
	if (!CameraTracksBefore.Contains(TEXT("AutoCamera")))
	{
		AddNewTrack(UDialogueCameraTrack::StaticClass(), "AutoCamera");
	}
}

FString FDialogueEditorTimelineController::GenerateAvailableTrackName(class UDialogueBaseAsset* pAsset, const FString& Prefix)
{
	if (pAsset == nullptr) return TEXT("");
	TArray<UDialogueTrackBase*> AllTracks = pAsset->GetAllEpisodeTracks(0);

	int AvailableIndex = 0;
	FString Ret;
	while (true)
	{
		//探测一个可用的TrackIndex
		AvailableIndex++;

		bool Continue = false;
		Ret = FString::Printf(TEXT("%s%d"), *Prefix, AvailableIndex);
		for (UDialogueTrackBase* TrackBase : AllTracks)
		{
			if (TrackBase->GetTrackName().ToString() == Ret)
			{
				Continue = true;
				break;
			}
		}
		if (!Continue) break;
	}
	return Ret;
}

#pragma region TrackAddCheck


bool FDialogueEditorTimelineController::CanAddTrack(UClass* InTrackClass)
{
	if (!CachedEditor.IsValid())
	{
		return false;
	}

	if (!MetCommonCondition(InTrackClass))
	{
		return false;
	}

	if (IsActorOnlyTrack(InTrackClass))
	{
		return MetActorOnlyCondition(InTrackClass);
	}

	return true;
}

bool FDialogueEditorTimelineController::MetCommonCondition(UClass* InTrackClass)
{
	UDialogueBaseAsset* Asset = CachedPreviewProxy->GetPreviewAsset();
	if (!IsValid(Asset))
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("没有正在打开的对话资产")));
		return false;
	}

	UDialogueEditorSettings* Settings = GetMutableDefault<UDialogueEditorSettings>();
	TArray<UDialogueTrackBase*> AllTracks = Asset->GetAllEpisodeTracks(EpisodeIndex);
	bool AlreadyExists = AllTracks.ContainsByPredicate([InTrackClass](UDialogueTrackBase* Track)
	{
		return Track->GetClass() == InTrackClass;
	});

	if (AlreadyExists && Settings->UniqueTracks.Contains(InTrackClass))
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("不能重复添加这种类型的轨道")));
		return false;
	}

	if (bEnableCameraList)
	{
		if (bCameraList)
		{
			if (InTrackClass != UDialogueCameraTrack::StaticClass())
			{
				return false;
			}
		}else
		{
			if (InTrackClass == UDialogueCameraTrack::StaticClass())
			{
				return false;
			}
		}
	}
	
	return true;
}

bool FDialogueEditorTimelineController::MetActorOnlyCondition(UClass* InTrackClass)
{
	if (SelectedTracks.IsEmpty() || SelectedTracks.Num() != 1)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("只能在选中一个Actor轨道时,才能在添加该类型轨道")));
		return false;
	}

	TSharedPtr<FAnimTimelineTrack> SelectTrack = SelectedTracks.Array()[0];
	TSharedPtr<FDialogueEditorTrack> DialogueEditorTrack = StaticCastSharedPtr<FDialogueEditorTrack>(SelectTrack);
	if (!DialogueEditorTrack)
	{
		UE_LOG(LogTemp, Error, TEXT("Track Type Error"));
		return false;
	}

	if (!DialogueEditorTrack->GetCachedTrack()->IsA(UDialogueActorTrack::StaticClass()))
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("只能在选中Actor轨道的情况下添加这个类型的子轨道")));
		return false;
	}

	if (!InTrackClass->IsChildOf(UDialogueActionTrack::StaticClass()))
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("该类型子轨道不能添加到Actor的轨道下")));
		return false;
	}

	return true;
}

bool FDialogueEditorTimelineController::IsActorOnlyTrack(UClass* InTrackClass)
{
	if (UDialogueEditorSettings* Settings = GetMutableDefault<UDialogueEditorSettings>())
	{
		TArray<TSubclassOf<UDialogueActionTrack>>* ActorSubTracks = nullptr;
		for (auto& SubTrackSetting : Settings->ActorSubTracks)
		{
			if (SubTrackSetting.ActorTrackClass == UDialogueActorTrack::StaticClass())
			{
				ActorSubTracks = &SubTrackSetting.SubTrackClasses;
				break;
			}
		}

		if (ActorSubTracks)
		{
			return (*ActorSubTracks).Contains(InTrackClass);
		}
	}

	return false;
}


#pragma endregion TrackAddCheck

#pragma optimize("",on)

#undef LOCTEXT_NAMESPACE
