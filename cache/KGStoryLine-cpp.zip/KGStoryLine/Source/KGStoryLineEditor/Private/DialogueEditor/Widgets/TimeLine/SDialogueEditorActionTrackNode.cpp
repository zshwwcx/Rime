#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackNode.h"

#include "Widgets/TimeLineBase/AnimTimeSliderController.h"
#include "Fonts/FontMeasure.h"
#include "Styling/CoreStyle.h"
#include "Widgets/Layout/SBox.h"
#include "Preferences/PersonaOptions.h"
#include "Framework/Application/SlateApplication.h"

#include "Widgets/TimeLineBase/SAnimTimeline.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTrack.h"

#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/DialogueEditor.h"
#include "Brushes/SlateBoxBrush.h"
#include "ScopedTransaction.h"
#include "DialogueEditor/TabFactory/SDialogueEditorTimelineTab.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "Misc/MessageDialog.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"
#include "DialogueEditor/Dialogue/Actions/DialogueAutoCameraCut.h"
#include "DialogueEditor/Context/KGSLEdCtxSectionAutoLinkLine.h"
#include "DialogueEditor/Dialogue/Actions/DialogueGossipBuble.h"
#include "UObject/UnrealTypePrivate.h"



#define LOCTEXT_NAMESPACE "SDialogueEditorActionTrackNode"

namespace
{
	constexpr float NotifyHeightOffset = 0.f;
	constexpr float DrawBoxHeightOffset = -4.0f;
	const float NotifyHeight = FDialogueEditorTrack::NotificationTrackHeight;
	const FVector2D ScrubHandleSize(12.0f, 12.0f);
	const FVector2D AlignmentMarkerSize(10.f, 20.f);
	const FVector2D TextBorderSize(1.f, 4.f);

	const FString CameraCutBlueprintPath = TEXT("/Game/Blueprint/DialogueSystem/Section/BPS_CameraCut.BPS_CameraCut_C");
}

const FVector2d SDialogueEditorActionTrackKeyFrameNode::KeySizePx = FVector2d(24, 24);
const float SDialogueEditorActionTrackKeyFrameNode::HalfKeySize = SDialogueEditorActionTrackKeyFrameNode::KeySizePx.X / 2.f;
const float SDialogueEditorActionTrackKeyFrameNode::KeyBrushBorderWidth = 4.f;
const float SDialogueEditorActionTrackKeyFrameNode::KeyPositionOffsetY = 4.f;


FDialogueEditorActionNodeData::FDialogueEditorActionNodeData()
{
	if (UClass* Class = LoadObject<UClass>(nullptr, *CameraCutBlueprintPath))
	{
		CameraCutBlueprintClass = Class;
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("Failed to load %s "), *CameraCutBlueprintPath);
	}
}

void FDialogueEditorActionNodeData::SetActionNodeData(UDialogueActionBase* InSection)
{
	CachedSection = InSection;
}

UDialogueActionBase* FDialogueEditorActionNodeData::GetAction() const
{
	return CachedSection.Get();
}

FName FDialogueEditorActionNodeData::GetActionName() const
{
	TSharedPtr<FDialogueEditor> DialogueEditor = CachedEditor.Pin();
	UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(DialogueEditor->GetEditingAsset());
	UDialogueActionBase* Obj = CachedSection.Get();
	UClass* Class = IsValid(Obj) ? Obj->GetClass() : nullptr;
	if (!DialogueEditor.IsValid() || !IsValid(DialogueAsset) || !IsValid(Obj) || !IsValid(Class))
	{
		return CachedSection.IsValid() ? FName(*CachedSection->GetSectionName().ToString()) : NAME_Error;
	}

	FProperty* Prop = nullptr;
	FString ClassName = Class->GetName();
	if (ClassName.Contains("BPS_CameraCut") && Obj->IsA(CameraCutBlueprintClass.Get()))
	{
		Prop = Class->FindPropertyByName("TargetCamera");
	}
	else if (ClassName.Contains("BPS_ActorDirection"))
	{
		Prop = Class->FindPropertyByName("Target");
	}
	else if (ClassName.Contains("BPS_CameraMove"))
	{
		Prop = Class->FindPropertyByName("TargetCamera");
	}
	else if (ClassName.Contains("BPS_LookAt"))
	{
		Prop = Class->FindPropertyByName("TalkerLookAtTarget");
	}
	else if (ClassName.Contains("BPS_ParticleAttachment"))
	{
		Prop = Class->FindPropertyByName("AttachActor");
	}
	else if (ClassName.Contains("BPS_Transform"))
	{
		Prop = Class->FindPropertyByName("MoveTarget");
	}
    else if (Obj->IsA<UDialogueGossipBuble>())
    {
        FString DisplayName;
        if (auto* GossipBubble = Cast<UDialogueGossipBuble>(Obj))
        {
            if (UDialogueEditorManager* DialogueEditorManager = DialogueEditor->GetDialogueEditorManager())
            {
               DisplayName = FString::Printf(TEXT("%d: %s"), GossipBubble->GossipBubbleID,*DialogueEditorManager->GetGossipBubbleTextFromLua(GossipBubble->GossipBubbleID)); 
            }
        }
        return *DisplayName;
    }
	
	if (FStructProperty* StructProp = CastField<FStructProperty>(Prop))
	{
		FString DisplayName;
		if (StructProp->Struct == FDialogueCameraSelector::StaticStruct())
		{
			if (FDialogueCameraSelector* StructValue = Prop->ContainerPtrToValuePtr<FDialogueCameraSelector>(Obj))
			{
				FString CameraName = StructValue->CameraName;
				DisplayName = CameraName;
				if (UKGSLDialogueEpisode* Episode = DialogueAsset->CurrentEpisode)
				{
					TArray<UDialogueTrackBase*> Tracks = DialogueAsset->GetAllTacksByEpisodeID(Episode->EpisodeID);
					for (auto& Track : Tracks)
					{
						if (*FTextInspector::GetSourceString(Track->GetTrackName()) == CameraName)
						{
							DisplayName = Track->GetEditorPreviewFullName();
							break;
						}
					}
				}
			}
		}
		else if (StructProp->Struct == FBehaviorActorSelector::StaticStruct())
		{
			if (FBehaviorActorSelector* StructValue = Prop->ContainerPtrToValuePtr<FBehaviorActorSelector>(Obj))
			{
				FString TrackName = StructValue->TrackName.ToString();
				DisplayName = TrackName;
				if (UKGSLDialogueEpisode* Episode = DialogueAsset->CurrentEpisode)
				{
					TArray<UDialogueTrackBase*> Tracks = DialogueAsset->GetAllTacksByEpisodeID(Episode->EpisodeID);
					for (auto& Track : Tracks)
					{
						if (*FTextInspector::GetSourceString(Track->GetTrackName()) == TrackName)
						{
							DisplayName = Track->GetEditorPreviewFullName();
							break;
						}
					}
				}
			}
		}
		else if (StructProp->Struct == FDialoguePerformerSelector::StaticStruct())
		{
			if (FDialoguePerformerSelector* StructValue = Prop->ContainerPtrToValuePtr<FDialoguePerformerSelector>(Obj))
			{
				FString TrackName = StructValue->PerformerName;
				DisplayName = TrackName;
				if (UKGSLDialogueEpisode* Episode = DialogueAsset->CurrentEpisode)
				{
					TArray<UDialogueTrackBase*> Tracks = DialogueAsset->GetAllTacksByEpisodeID(Episode->EpisodeID);
					for (auto& Track : Tracks)
					{
						if (*FTextInspector::GetSourceString(Track->GetTrackName()) == TrackName)
						{
							DisplayName = Track->GetEditorPreviewFullName();
							break;
						}
					}
				}	
			}
		}
		
		if (!DisplayName.IsEmpty())
		{
			return FName(*DisplayName);
		}
	}

	return CachedSection.IsValid() ? FName(*CachedSection->GetSectionName().ToString()) : NAME_Error;
}

TOptional<FLinearColor> FDialogueEditorActionNodeData::GetColor() const
{
	const UDialogueEditorSettings* DialogueEditorSettings = GetDefault<UDialogueEditorSettings>();
	if (!CachedEditor.IsValid())
		return TOptional<FLinearColor>(FLinearColor::Red);
	TSharedPtr<FDialogueEditor> DialogueEditor = CachedEditor.Pin();

	if (!CachedSection.IsValid())
		return TOptional<FLinearColor>(DialogueEditorSettings->SectionInValidColor);

	//选中，绿色
	if(DialogueEditor->CurrentSelectSection.Contains(CachedSection.Get()))
		return TOptional<FLinearColor>(DialogueEditorSettings->SectionSelectColor);

	// 左键双击自动关联台本模式时，粉色
	if (bLinkTarget)
	{
		return TOptional(GetDefault<UDialogueEditorSettings>()->SectionAutoLinkColor);
	}

	//选中一个Section，高亮所有相同LinkGUID的Section，黄色
	if (CachedSection.Get()->LineUniqueIDLinked.IsValid()
			&& DialogueEditor->CurrentSelectSection.ContainsByPredicate(
		[this](TWeakObjectPtr<UDialogueActionBase> Section) {return Section.IsValid() && Section->LineUniqueIDLinked == CachedSection.Get()->LineUniqueIDLinked; }))
	{
		return TOptional<FLinearColor>(DialogueEditorSettings->SectionSameLinkGUIDColor);
	}

	//普通，青色或者section类中自定义的颜色
	if (CachedSection.Get()->Enable)
	{
		return TOptional<FLinearColor>(CachedSection->GetSectionColor());
	}
	return TOptional<FLinearColor>(FColor(120, 0, 0));
}

FText FDialogueEditorActionNodeData::GetNodeTooltip() const
{
	if (!CachedTrack.IsValid())
		return FText();

	if (!CachedSection.IsValid())
		return FText();

	FString ToolTipString = FString::Printf(TEXT("start: %.2f, dura:%.2f \nSectionName: %s\nActionClass: %s\nSectionClass: %s"), 
		GetStartTime(),
		GetDuration(),
		*GetActionName().ToString(),
		*CachedTrack->GetClass()->GetToolTipText().ToString(),
		*CachedSection->GetClass()->GetToolTipText().ToString()
		);

	if (!CachedSection->CanAdjustDurationInEditor)
	{
		ToolTipString = TEXT("Section长度没有实际意义\n") + ToolTipString;
	}
	return FText::FromString(ToolTipString);
}

float FDialogueEditorActionNodeData::GetStartTime() const
{
	return CachedSection.IsValid() ? CachedSection->StartTime : 0.f;
}

float FDialogueEditorActionNodeData::GetEditorStartTime()
{
	return CachedSection.IsValid() ? CachedSection->GetEditorStartTime() : 0.f;
}

void FDialogueEditorActionNodeData::SetStartTime(float Time)
{
	if (CachedSection.IsValid())
	{
		CachedSection->SetStartTime(Time);
	}
}

void FDialogueEditorActionNodeData::SetEditorStartTime(float Time)
{
	if (CachedSection.IsValid())
	{
		CachedSection->SetEditorStartTime(Time);
	}
}

float FDialogueEditorActionNodeData::GetDuration()  const
{
	if (!CachedSection.IsValid())
	{
		return 0.f;
	}

	return CachedSection->Duration;
}

float FDialogueEditorActionNodeData::GetEditorDuration() const
{
	return CachedSection.IsValid() ? CachedSection->GetEditorDuration() : 0.f;
}

void FDialogueEditorActionNodeData::SetDuration(float InDuration)
{
	if (CachedSection.IsValid())
	{
		CachedSection->SetDuration(InDuration);
	}
}

void FDialogueEditorActionNodeData::SetEditorDuration(float InDuration)
{
	if (CachedSection.IsValid())
	{
		CachedSection->SetEditorDuration(InDuration);
	}
}

#pragma region Important
void SDialogueEditorActionTrackNode::Construct(const FArguments& InArgs)
{
	Font = FCoreStyle::GetDefaultFontStyle("Regular", 10);
	bSelected = false;
	bBeingDragged = false;
	CurrentDragHandle = ENotifyStateHandleHit::None;
	bDrawTooltipToRight = true;
	DragMarkerTransactionIdx = INDEX_NONE;

	ActionNodeData.SetActionNodeData(InArgs._Section);
	ActionNodeData.CachedTrack = InArgs._Track;
	ActionNodeData.CachedEditor = InArgs._CachedEditor;
	if (UDialogueDialogue* DialogueAction = Cast<UDialogueDialogue>(InArgs._Section))
	{
		auto Context = InArgs._CachedEditor->GetEditorContextMgr().GetContext<FKGSLEdCtxSectionAutoLinkLine>();
		if (Context.IsValid() && Context->IsValid())
		{
			ActionNodeData.bLinkTarget = Context->IsCurrentLinkTarget(DialogueAction);
		}
	}
	
	//RefreshPanelEvent = InArgs._OnRefreshPanel;
	StartDragNodeEvent = InArgs._OnStartDragNode;
	DeleteSelectedSectionEvent = InArgs._OnDeleteSelectedSection;
	NodeLeftMouseButtonUpEvent = InArgs._NodeLeftMouseButtonUp;
	NodeMouseButtonDoubleClickEvent = InArgs._NodeMouseButtonDoubleClickEvent;

	ViewInputMin = InArgs._ViewInputMin;
	ViewInputMax = InArgs._ViewInputMax;
	TimelinePlayLength = InArgs._TimelinePlayLength.Get();
	UnpinBrush = *FAppStyle::GetBrush(TEXT("Icons.Unpinned"));

	SetClipping(EWidgetClipping::ClipToBounds);

	SetToolTipText(TAttribute<FText>(this, &SDialogueEditorActionTrackNode::GetNodeTooltip));
	if (InArgs._Section && InArgs._Section->IsFixed())
	{
		SetEnabled(false);
	}
}

SDialogueEditorActionTrackNode::~SDialogueEditorActionTrackNode()
{
}

FDialogueEditorActionNodeData* SDialogueEditorActionTrackNode::GetActionNodeDataPtr()
{
	return &ActionNodeData;
}

TSharedPtr<class FDialogueEditor> SDialogueEditorActionTrackNode::GetDialogueEditor()
{
	if (!ActionNodeData.CachedEditor.IsValid())
		return nullptr;
	return ActionNodeData.CachedEditor.Pin();
}

const FDialogueEditorActionNodeData& SDialogueEditorActionTrackNode::GetActionNodeData() const
{
	return ActionNodeData;
}

#pragma endregion Important



#pragma region Render
static FSlateBrush* GetSectionRoundBoxBrush()
{
	static FSlateBoxBrush* SectionBrush = nullptr;
	if (SectionBrush == nullptr)
	{
		SectionBrush = new FSlateBoxBrush("Common/TextBox_Special", FMargin(8.0f / 32.0f));
		SectionBrush->DrawAs = ESlateBrushDrawType::Type::RoundedBox;
	}
	return SectionBrush;
}

int32 SDialogueEditorActionTrackNode::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	return LayerId;
}

void SDialogueEditorActionTrackNode::DrawHandleOffset(const float& Offset, const float& HandleCentre, FSlateWindowElementList& OutDrawElements, int32 MarkerLayer, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FLinearColor NodeColor) const
{
	FVector2D MarkerPosition;
	FVector2D MarkerSize = AlignmentMarkerSize;

	if (Offset < 0.f)
	{
		MarkerPosition.Set(HandleCentre - AlignmentMarkerSize.X, (NotifyHeight - AlignmentMarkerSize.Y) / 2.f);
	}
	else
	{
		MarkerPosition.Set(HandleCentre + AlignmentMarkerSize.X, (NotifyHeight - AlignmentMarkerSize.Y) / 2.f);
		MarkerSize.X = -AlignmentMarkerSize.X;
	}

	FSlateLayoutTransform SlateLayoutTransform(1.0f, TransformPoint(1.0f, UE::Slate::CastToVector2f(MarkerPosition)));

	FSlateDrawElement::MakeBox
	(
		OutDrawElements, MarkerLayer,
		AllottedGeometry.ToPaintGeometry(MarkerSize, SlateLayoutTransform),
		FAppStyle::GetBrush(TEXT("BSA.Timeline.NotifyAlignmentMarker")),
		ESlateDrawEffect::None, NodeColor
	);
}


FNavigationReply SDialogueEditorActionTrackNode::OnNavigation(const FGeometry& MyGeometry, const FNavigationEvent& InNavigationEvent)
{
	return FNavigationReply::Stop();
}
#pragma endregion Render



#pragma region Parameter
bool SDialogueEditorActionTrackNode::IsSelected() const
{
	return bSelected;
}

FText SDialogueEditorActionTrackNode::GetNotifyText() const
{
	return FText::FromName(ActionNodeData.GetActionName());
}

FText SDialogueEditorActionTrackNode::GetNodeTooltip() const
{
	return ActionNodeData.GetNodeTooltip();
}

FVector2D SDialogueEditorActionTrackNode::GetSize() const
{
	return WidgetSize;
}

const FVector2D& SDialogueEditorActionTrackNode::GetScreenPosition() const
{
	return ScreenPosition;
}

float SDialogueEditorActionTrackNode::GetDurationSize() const
{
	return NotifyDurationSizeX;
}

FVector2D SDialogueEditorActionTrackNode::GetWidgetPosition() const
{
	return FVector2D(WidgetX, NotifyHeightOffset);
}

FVector2D SDialogueEditorActionTrackNode::GetNotifyPosition() const
{
	return FVector2D(NotifyTimePositionX, NotifyHeightOffset);
}

FVector2D SDialogueEditorActionTrackNode::GetNotifyPositionOffset() const
{
	return GetNotifyPosition() - GetWidgetPosition();
}

FVector2D SDialogueEditorActionTrackNode::GetWidgetAndStartTimeOffset() const
{
	return FVector2D(0.f, 0.f);
}

void SDialogueEditorActionTrackNode::AddSlotToTimeline(TSharedPtr<SOverlay> NodeSlots)
{
	NodeSlots->AddSlot()
		.Padding(TAttribute<FMargin>::Create(TAttribute<FMargin>::FGetter::CreateSP(this, &SDialogueEditorActionTrackNode::GetNotifyTrackPadding)))
		[
			this->AsShared()
		];
}

FMargin SDialogueEditorActionTrackNode::GetNotifyTrackPadding()
{
	const float LeftMargin = GetWidgetPosition().X;
	const float RightMargin = CachedTrackGeometry.GetLocalSize().X - LeftMargin - GetSize().X;
	return FMargin(LeftMargin, 0, RightMargin, 0);
}

FVector2D SDialogueEditorActionTrackNode::ComputeDesiredSize(float) const
{
	return GetSize();
}

void SDialogueEditorActionTrackNode::UpdateSizeAndPosition(const FGeometry& AllottedGeometry)
{
	FTrackScaleInfo ScaleInfo(ViewInputMin.Get(), ViewInputMax.Get(), 0, 0, AllottedGeometry.Size);

	// Cache the geometry information, the alloted geometry is the same size as the track.
	CachedAllotedGeometrySize = AllottedGeometry.Size * AllottedGeometry.Scale;

	NotifyTimePositionX = ScaleInfo.InputToLocalX(ActionNodeData.GetEditorStartTime());
	NotifyDurationSizeX = ScaleInfo.PixelsPerInput * ActionNodeData.GetEditorDuration();

	const TSharedRef< FSlateFontMeasure > FontMeasureService = FSlateApplication::Get().GetRenderer()->GetFontMeasureService();
	TextSize = FontMeasureService->Measure(GetNotifyText(), Font);

	//将字体显示裁剪，避免显示过长
	if (ActionNodeData.GetDuration() > 1.0f && TextSize.X > NotifyDurationSizeX)
		TextSize.X = NotifyDurationSizeX;

	LabelWidth = TextSize.X + (TextBorderSize.X * 2.f) + (ScrubHandleSize.X / 2.f);

	//Calculate scrub handle box size (the notional box around the scrub handle and the alignment marker)
	float NotifyHandleBoxWidth = FMath::Max(ScrubHandleSize.X, AlignmentMarkerSize.X * 2);

	// Work out where we will have to draw the tool tip
	FVector2D Size = GetSize();
	float LeftEdgeToNotify = NotifyTimePositionX;
	float RightEdgeToNotify = AllottedGeometry.Size.X - NotifyTimePositionX;
	bDrawTooltipToRight = NotifyDurationSizeX > 0.0f || ((RightEdgeToNotify > LabelWidth) || (RightEdgeToNotify > LeftEdgeToNotify));

	// Calculate widget width/position based on where we are drawing the tool tip
	WidgetX = bDrawTooltipToRight ? (NotifyTimePositionX ) : (NotifyTimePositionX - LabelWidth);
	float MaxSizeX = FMath::Max(NotifyDurationSizeX, TextSize.X);
	WidgetSize = bDrawTooltipToRight ? FVector2D(NotifyDurationSizeX, NotifyHeight) : FVector2D(LabelWidth + MaxSizeX, NotifyHeight);

	// Widget position of the notify marker
	NotifyScrubHandleCentre = bDrawTooltipToRight ? NotifyHandleBoxWidth / 2.f : LabelWidth;
}

#pragma endregion Parameter



FReply SDialogueEditorActionTrackNode::OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent)
{
	return FReply::Handled().SetUserFocus(AsShared(), EFocusCause::SetDirectly, true);
}

void SDialogueEditorActionTrackNode::OnFocusLost(const FFocusEvent& InFocusEvent)
{
	if (CurrentDragHandle != ENotifyStateHandleHit::None)
	{
		CurrentDragHandle = ENotifyStateHandleHit::None;

		if (DragMarkerTransactionIdx != INDEX_NONE)
		{
			GEditor->EndTransaction();
			DragMarkerTransactionIdx = INDEX_NONE;
		}
	}
}

bool SDialogueEditorActionTrackNode::SupportsKeyboardFocus() const
{
	return true;
}

ENotifyStateHandleHit::Type SDialogueEditorActionTrackNode::DurationHandleHitTest(const FVector2D& CursorTrackPosition) const
{
	ENotifyStateHandleHit::Type MarkerHit = ENotifyStateHandleHit::None;

	// 计算点击位置与ActionNode的相对位置，来判断能否对Task产生影响，以及产生什么影响
	if (NotifyDurationSizeX > 0.0f)
	{
		float ScrubHandleHalfWidth = ScrubHandleSize.X / 2.0f;

		FVector2D NotifyNodePosition( - ScrubHandleHalfWidth, 0.0f);
		FVector2D NotifyNodeSize(NotifyDurationSizeX + ScrubHandleHalfWidth * 2.0f, NotifyHeight);

		FVector2D MouseRelativePosition(CursorTrackPosition - GetWidgetPosition());

		if (MouseRelativePosition.ComponentwiseAllGreaterThan(NotifyNodePosition) && MouseRelativePosition.ComponentwiseAllLessThan(NotifyNodePosition + NotifyNodeSize))
		{
			// 该次拖动想要修改开始时间
			if (MouseRelativePosition.X <= (NotifyNodePosition.X + ScrubHandleSize.X))
			{
				MarkerHit = ENotifyStateHandleHit::Start;
			}
			// 该次拖动想要修改时长
			else if (MouseRelativePosition.X >= (NotifyNodePosition.X + NotifyNodeSize.X - ScrubHandleSize.X))
			{
				MarkerHit = ENotifyStateHandleHit::End;
			}
		}
	}

	return MarkerHit;
}

bool SDialogueEditorActionTrackNode::BeingDragged() const
{
	if (bBeingDragged)
		return true;
	//bool IsAdjustSectionEdge = ActionNodeData.CachedSection.IsValid() ? ActionNodeData.CachedSection->IsAdjustingEdge() : false;
	return false;
}

void SDialogueEditorActionTrackNode::OnCurrentLinkSectionChanged(UDialogueDialogue* Last, UDialogueDialogue* Current)
{
	if (!ActionNodeData.GetAction())
	{
		return;
	}
	
	if (ActionNodeData.GetAction() == Last && ActionNodeData.GetAction() != Current)
	{
		ActionNodeData.bLinkTarget = false;
		return;
	}

	if (ActionNodeData.GetAction() == Current && ActionNodeData.GetAction() != Last)
	{
		ActionNodeData.bLinkTarget = true;
	}
}

FReply SDialogueEditorActionTrackNode::OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	if (!ActionNodeData.CachedEditor.IsValid())
	{
		return FReply::Handled();
	}
	
	UDialogueAsset* DialogueAsset = ActionNodeData.CachedEditor.Pin()->GetDialogueAsset();
	if (DialogueAsset == nullptr)
	{
		return FReply::Handled();
	}

	TSharedPtr<FDialogueEditor> DialogueEditor = ActionNodeData.CachedEditor.Pin();
	if (DialogueEditor.IsValid())
	{
		if (auto* Action = ActionNodeData.GetAction())
		{
			if (UDialogueDialogue* DialogueAction = Cast<UDialogueDialogue>(Action))
			{
				TSharedPtr<FKGSLEdCtxSectionAutoLinkLine> Context = DialogueEditor->GetEditorContextMgr().PushContext<FKGSLEdCtxSectionAutoLinkLine>();
				if (!Context->IsCurrentLinkTarget(DialogueAction))
				{
					Context->OnCurrentLinkSectionChanged.AddSP(SharedThis(this), &SDialogueEditorActionTrackNode::OnCurrentLinkSectionChanged);
					Context->SetCurrentLinkSection(DialogueAction);
				}
				else
				{
					Context->SetCurrentLinkSection(nullptr);
					DialogueEditor->GetEditorContextMgr().PopContext(Context);
				}
			}
		}
	}
	
	if (NodeMouseButtonDoubleClickEvent.IsBound())
	{
		FReply Reply = NodeMouseButtonDoubleClickEvent.Execute(SharedThis(this), InMouseEvent);
		if (Reply.IsEventHandled())
		{
			return Reply;
		}
	}
	
	return SLeafWidget::OnMouseButtonDoubleClick(InMyGeometry, InMouseEvent);
}

FReply SDialogueEditorActionTrackNode::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FVector2D CursorPos = MouseEvent.GetScreenSpacePosition();
	CursorPos = CachedTrackGeometry.AbsoluteToLocal(CursorPos);

	if (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		SetLastMouseDownPosition(CursorPos);

		return FReply::Handled().DetectDrag(SharedThis(this), EKeys::LeftMouseButton);
	}
	else if (MouseEvent.GetEffectingButton() == EKeys::RightMouseButton)
	{
		return FReply::Handled();
	}

	return FReply::Handled();
}

FReply SDialogueEditorActionTrackNode::OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	UDialogueActionBase* DialogueActionSection = ActionNodeData.GetAction();
	if (DialogueActionSection == nullptr)
		return FReply::Handled();

	FVector2D ScreenNodePosition = FVector2D(MyGeometry.AbsolutePosition);

	bool bDragOnMarker = false;
	bBeingDragged = true;

	if (GetDurationSize() > 0.0f)
	{
		ENotifyStateHandleHit::Type MarkerHit = DurationHandleHitTest(LastMouseDownPosition);
		if (MarkerHit == ENotifyStateHandleHit::Start || MarkerHit == ENotifyStateHandleHit::End)
		{
			DialogueActionSection->SetFlags(EObjectFlags::RF_Transactional);
			FString ScopeText = FString::Printf(TEXT("Dialogue Section Drag, Track %s"), *(DialogueActionSection->SectionName.ToString()));
			if (GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo)
			{
				DragMarkerTransactionIdx = GEditor->BeginTransaction(FText::FromString(ScopeText));
				DialogueActionSection->Modify();
			}
			CurrentDragHandle = MarkerHit;
			bBeingDragged = false;
			bDragOnMarker = true;
		}
	}
	return StartDragNodeEvent.Execute(SharedThis(this), MouseEvent, ScreenNodePosition, bDragOnMarker, 0.f);
}

void SDialogueEditorActionTrackNode::DragCancelled()
{
	bBeingDragged = false;

}

void SDialogueEditorActionTrackNode::SetLastMouseDownPosition(const FVector2D& CursorPosition)
{
	LastMouseDownPosition = CursorPosition;
}

FReply SDialogueEditorActionTrackNode::OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (CurrentDragHandle == ENotifyStateHandleHit::None)
	{
		FSlateApplication::Get().ReleaseAllPointerCapture();
		return FReply::Handled();
	}
	if (!ActionNodeData.CachedEditor.IsValid())
		return FReply::Handled();
	UDialogueAsset* DialogueAsset = ActionNodeData.CachedEditor.Pin()->GetDialogueAsset();
	if (DialogueAsset == nullptr)
		return FReply::Handled();
	UDialogueActionBase* DialogueActionSection = ActionNodeData.GetAction();
	if (DialogueActionSection == nullptr)
		return FReply::Handled();

	UDialogueEditorManager* DialogueEditorManager = ActionNodeData.CachedEditor.Pin()->GetDialogueEditorManager();

	FTrackScaleInfo ScaleInfo(ViewInputMin.Get(), ViewInputMax.Get(), 0, 0, CachedAllotedGeometrySize);

	float XPositionInTrack = MyGeometry.AbsolutePosition.X - CachedTrackGeometry.AbsolutePosition.X;

	// 对Task的起始时间进行修改
	if (CurrentDragHandle == ENotifyStateHandleHit::Start)
	{
		float NewDisplayTime = ScaleInfo.LocalXToInput((FVector2f(MouseEvent.GetScreenSpacePosition()) - MyGeometry.AbsolutePosition + XPositionInTrack).X);

		float ValidStartTime = DialogueEditorManager->OnSectionChange_DragStartCheck(DialogueAsset, ActionNodeData.CachedSection.Get(), NewDisplayTime);

		if (! FMath::IsNearlyEqual(ActionNodeData.GetEditorStartTime(), ValidStartTime))
		{
			//Line1 & Line2 主要是为了在拖动起始时间的时候，调整Duration，如果不需要调整Duration，则去掉Line1 & Line2 即可
			float StartTimeOffset = ValidStartTime - ActionNodeData.GetEditorStartTime();//Line 1
			ActionNodeData.SetEditorStartTime(ValidStartTime);
			//UE_LOG(LogTemp, Log, TEXT("SetEditorStartTime: %f"), ValidStartTime);
			ActionNodeData.SetEditorDuration(ActionNodeData.GetEditorDuration() - StartTimeOffset); //Line2

			ActionNodeData.CachedEditor.Pin()->DialogueTimelineController.Pin()->SetDragSectionPosX(GetWidgetPosition().X);
		}
	}
	// 对Task的时长进行修改
	else
	{
		float NewEndTime = ScaleInfo.LocalXToInput((FVector2f(MouseEvent.GetScreenSpacePosition()) - MyGeometry.AbsolutePosition + XPositionInTrack).X);

		float ValidEndTime = DialogueEditorManager->OnSectionChange_DragEndCheck(DialogueAsset, ActionNodeData.CachedSection.Get(), NewEndTime);
		if (!FMath::IsNearlyEqual(ActionNodeData.GetEditorStartTime() + ActionNodeData.GetEditorDuration(), ValidEndTime))
		{
			ActionNodeData.CachedSection->SetEditorDuration(ValidEndTime - ActionNodeData.GetEditorStartTime());
			//UE_LOG(LogTemp, Log, TEXT("SetEditorDuration: %f"), ValidEndTime - ActionNodeData.GetEditorStartTime());
			ActionNodeData.CachedEditor.Pin()->DialogueTimelineController.Pin()->SetDragSectionPosX(GetWidgetPosition().X + GetDurationSize());
		}
	}

	return FReply::Handled();
}

FReply SDialogueEditorActionTrackNode::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (!ActionNodeData.CachedEditor.IsValid())
		return FReply::Handled();
	UDialogueAsset* DialogueAsset = ActionNodeData.CachedEditor.Pin()->GetDialogueAsset();
	if (DialogueAsset == nullptr)
		return FReply::Handled();

	UDialogueEditorManager* DialogueEditorManager = ActionNodeData.CachedEditor.Pin()->GetDialogueEditorManager();

	bool bLeftButton = MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton;
	bool bRightMouseButton = MouseEvent.GetEffectingButton() == EKeys::RightMouseButton;
	if (bRightMouseButton)
	{
		TSharedPtr<SWidget> WidgetToFocus = SummonContextMenu(MyGeometry, MouseEvent);

		return (WidgetToFocus.IsValid())
			? FReply::Handled().ReleaseMouseCapture().SetUserFocus(WidgetToFocus.ToSharedRef(), EFocusCause::SetDirectly)
			: FReply::Handled().ReleaseMouseCapture();
	}
	else if (bLeftButton)
	{
		FReply Reply = NodeLeftMouseButtonUpEvent.Execute(SharedThis(this));

		if (CurrentDragHandle != ENotifyStateHandleHit::None)
		{
			if(CurrentDragHandle == ENotifyStateHandleHit::Start)
				DialogueEditorManager->OnSectionChange_DragStart(DialogueAsset, ActionNodeData.CachedSection.Get(), ActionNodeData.GetEditorStartTime());
			else if(CurrentDragHandle == ENotifyStateHandleHit::End)
				DialogueEditorManager->OnSectionChange_DragEnd(DialogueAsset, ActionNodeData.CachedSection.Get(), ActionNodeData.GetEditorStartTime() + ActionNodeData.GetEditorDuration());

			CurrentDragHandle = ENotifyStateHandleHit::None;


			// End drag transaction before handing mouse back
			if(DragMarkerTransactionIdx != INDEX_NONE)
			{

				GEditor->EndTransaction();
				DragMarkerTransactionIdx = INDEX_NONE;
			}

			return FReply::Handled().ReleaseMouseCapture();
		}

		return Reply;
	}

	return FReply::Unhandled();
}

TSharedPtr<SWidget> SDialogueEditorActionTrackNode::SummonContextMenu(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FVector2D CursorPos = MouseEvent.GetScreenSpacePosition();

	FMenuBuilder MenuBuilder(true, nullptr);
	MenuBuilder.BeginSection("Track", LOCTEXT("NotifyHeading", "Section Actions"));
	{
		MenuBuilder.AddMenuEntry
		(
			NSLOCTEXT("DeleteSectionSubMenu", "DeleteSectionNotify", "Delete Section"),
			NSLOCTEXT("DeleteSectionSubMenu", "DeleteSectionNotifyToolTip", "Delete Section"),
			FSlateIcon(),
			FUIAction
			(
				FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackNode::DeleteSelectedSection)
			),
			NAME_None,
			EUserInterfaceActionType::Button
		);
		MenuBuilder.AddMenuEntry
		(
			NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotify_EnableDisableSection", "Enable/Disable Section"),
			NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotifyToolTip_EnableDisableSection", "Enable/Disable Section"),
			FSlateIcon(),
			FUIAction
			(
				FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackNode::SetSelectedSectionEnable)
			),
			NAME_None,
			EUserInterfaceActionType::Button
		);
		if (TSharedPtr<FDialogueEditor> DialogueEditorSharedPtr = GetDialogueEditor())
		{
			if (UDialogueActionBase* DialogueActionSection = ActionNodeData.CachedSection.Get())
			{
				if (!DialogueActionSection->IsA(UDialogueDialogue::StaticClass()))
				{//台本Section不允许Paster
					if(DialogueEditorSharedPtr->CurrentCopySectionLinkUniqueID.IsValid())
					{//只有当前已经Copy了一个合法的LinkGUID,才显示Paste按钮
						MenuBuilder.AddMenuEntry
						(
							NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotify_PasteLinkGUID", "PasteLinkGUID"),
							NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotifyToolTip_PasteLinkGUID", "将剪贴板的LinkGUID拷贝到选择的Sections"),
							FSlateIcon(),
							FUIAction
							(
								FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackNode::PasteSectionLinkGUID)
							),
							NAME_None,
							EUserInterfaceActionType::Button
						);
					}

					if (DialogueActionSection->LineUniqueIDLinked.IsValid())
					{
						MenuBuilder.AddMenuEntry(
						   NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotify_ClearLinkGUID", "ClearLinkGUID"),
						   NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotifyToolTip_ClearLinkGUID", "清除Section关联的台本"),
						   FSlateIcon(),
						   FUIAction
						   (
							   FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackNode::ClearSectionLinkGUID)
						   ),
						   NAME_None,
						   EUserInterfaceActionType::Button
						   );
					}
				}
			}
		}
		if (UDialogueActionBase* DialogueActionSection = ActionNodeData.GetAction())
		{
			if (DialogueActionSection->LineUniqueIDLinked.IsValid())
			{//只有自己的LinkedGUID 合法，才可以有Copy功能
				MenuBuilder.AddMenuEntry
				(
					NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotify_CopyLinkGUID", "CopyLinkGUID"),
					NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotifyToolTip_CopyLinkGUID", "拷贝Section对应的LinkGUID到剪贴板"),
					FSlateIcon(),
					FUIAction
					(
						FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackNode::CopySectionLinkGUID)
					),
					NAME_None,
					EUserInterfaceActionType::Button
				);
			}
			if (!DialogueActionSection->IsConstant())
			{
				MenuBuilder.AddMenuEntry
				(
					NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotify_FocusToSection", "快速定位"),
					NSLOCTEXT("EnableSectionSubMenu", "EnableSectionNotifyToolTip_FocusToSection", "快速定位当前section区域,方便拖拽和选中"),
					FSlateIcon(),
					FUIAction
					(
						FExecuteAction::CreateSP(this, &SDialogueEditorActionTrackNode::QuickFocusSection)
					),
					NAME_None,
					EUserInterfaceActionType::Button
				);
			}
		}
	}
	MenuBuilder.EndSection();

	FWidgetPath WidgetPath = MouseEvent.GetEventPath() != nullptr ? *MouseEvent.GetEventPath() : FWidgetPath();
	FSlateApplication::Get().PushMenu(SharedThis(this), WidgetPath, MenuBuilder.MakeWidget(), CursorPos, FPopupTransitionEffect(FPopupTransitionEffect::ContextMenu));

	return TSharedPtr<SWidget>();
}

void SDialogueEditorActionTrackNode::DeleteSelectedSection()
{
	DeleteSelectedSectionEvent.Execute(SharedThis(this),true);
}

void SDialogueEditorActionTrackNode::SetSelectedSectionEnable()
{
	if (UDialogueActionBase* DialogueActionSection = ActionNodeData.GetAction())
	{
		FString ScopeText = FString::Printf(TEXT("Dialogue EnableSection, Track %s"), *(DialogueActionSection->SectionName.ToString()));
		FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);

		DialogueActionSection->SetFlags(EObjectFlags::RF_Transactional);
		DialogueActionSection->Modify();
		DialogueActionSection->SetEnable(!DialogueActionSection->Enable);
	}
}

void SDialogueEditorActionTrackNode::CopySectionLinkGUID()
{
	if (TSharedPtr<FDialogueEditor> SharedPtrDialogueEditor = GetDialogueEditor())
	{
		if (UDialogueActionBase* DialogueActionSection = ActionNodeData.GetAction())
		{
			SharedPtrDialogueEditor->CurrentCopySectionLinkUniqueID = DialogueActionSection->LineUniqueIDLinked;
		}
	}
}

void SDialogueEditorActionTrackNode::PasteSectionLinkGUID()
{
	if (TSharedPtr<FDialogueEditor> SharedPtrDialogueEditor = GetDialogueEditor())
	{
		TArray<TWeakObjectPtr<UDialogueActionBase>> TargetSections = SharedPtrDialogueEditor->CurrentSelectSection;
		TargetSections.AddUnique(ActionNodeData.GetAction());

		bool ExecutePaste = true;

		for (TWeakObjectPtr<UDialogueActionBase> Section : TargetSections)
		{
			if (Section->LineUniqueIDLinked.IsValid())
			{//如果已经有Section链接了一个LinkGUID，执行重新链接时，弹窗提示
				if (FMessageDialog::Open(EAppMsgType::YesNo, FText::FromString(TEXT("已有LinkGUID，要重新链接吗？"))) == EAppReturnType::No)
				{
					ExecutePaste = false;
				}
				//只判断一次
				break;
			}
		}

		if (ExecutePaste)
		{
			FString PasterGUIDSectionsNames;
			for (TWeakObjectPtr<UDialogueActionBase> Section : TargetSections)
			{
				PasterGUIDSectionsNames.Append(TEXT("\n"));
				PasterGUIDSectionsNames.Append(Section->GetSectionName().ToString());
			}

			FString ScopeText = FString::Printf(TEXT("Dialogue Paste Section LinkGUID, Track %s"), *PasterGUIDSectionsNames);
			FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);

			for (TWeakObjectPtr<UDialogueActionBase> Section : TargetSections)
			{
				Section->SetFlags(EObjectFlags::RF_Transactional);
				Section->Modify();

				Section->LineUniqueIDLinked = SharedPtrDialogueEditor->CurrentCopySectionLinkUniqueID;
			}
			UE_LOG(LogTemp, Log, TEXT("%s"), *ScopeText);
		}
	}
}

void SDialogueEditorActionTrackNode::ClearSectionLinkGUID()
{
	if (TSharedPtr<FDialogueEditor> SharedPtrDialogueEditor = GetDialogueEditor())
	{
		TArray<TWeakObjectPtr<UDialogueActionBase>> TargetSections = SharedPtrDialogueEditor->CurrentSelectSection;
		TargetSections.AddUnique(ActionNodeData.GetAction());

		auto Result = FMessageDialog::Open(EAppMsgType::OkCancel, FText::FromString(TEXT("确定清除这些Section对台本的关联吗？")));
		if (Result == EAppReturnType::Ok)
		{
			FString ScopeText(TEXT("Dialogue Clear link GUID"));
			FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);

			for (TWeakObjectPtr<UDialogueActionBase> Section : TargetSections)
			{
				if (Section.IsValid())
				{
					Section->SetFlags(EObjectFlags::RF_Transactional);
					Section->Modify();
					Section->LineUniqueIDLinked.Invalidate();
				}
			}
		}
	}
}

void SDialogueEditorActionTrackNode::QuickFocusSection()
{
	if (ActionNodeData.CachedEditor.IsValid())
	{
		TSharedPtr<ITimeSliderController> TimeSliderController = ActionNodeData.CachedEditor.Pin()->DialogueEditorTimelineTab.Pin()->GetAnimTimeSliderController();
		if (FAnimTimeSliderController* AnimTimeSliderController = StaticCast<FAnimTimeSliderController*>(TimeSliderController.Get()))
		{
			if (UDialogueActionTrack* OwnerDialogueAction = ActionNodeData.CachedSection->GetDialogueAction())
			{
				const float StartTime = ActionNodeData.GetStartTime();
				TArray<UDialogueActionBase*> OrderedActions = OwnerDialogueAction->GetOrderedSections();
				const int32 Index = OrderedActions.Find(ActionNodeData.CachedSection.Get());
				if (Index != INDEX_NONE)
				{
					float DeltaTime = MAX_FLT;
					if (Index > 0)
					{
						DeltaTime = FMath::Min(DeltaTime, StartTime - OrderedActions[Index - 1]->GetStartTime());
					}
					if (Index < OrderedActions.Num() - 1)
					{
						DeltaTime = FMath::Min(DeltaTime, OrderedActions[Index + 1]->GetStartTime() - StartTime);
					}
					if (DeltaTime < MAX_FLT)
					{
						const float NewSize = DeltaTime * 20;
						const TRange<double> LocalViewRange = AnimTimeSliderController->GetViewRange().GetAnimationTarget();
						const double LocalViewRangeMax = LocalViewRange.GetUpperBoundValue();
						const double LocalViewRangeMin = LocalViewRange.GetLowerBoundValue();
						const double OutputViewSize = LocalViewRangeMax - LocalViewRangeMin;
						if (NewSize < OutputViewSize)
						{
							const double OutputChange = NewSize - OutputViewSize;
							const double Fraction = (StartTime - LocalViewRangeMin) / OutputViewSize;
							double NewViewOutputMin = LocalViewRangeMin - (OutputChange * Fraction);
							double NewViewOutputMax = LocalViewRangeMax + (OutputChange * (1.f - Fraction));
							if (NewViewOutputMin < NewViewOutputMax)
							{
								AnimTimeSliderController->ClampViewRange(NewViewOutputMin, NewViewOutputMax);
								AnimTimeSliderController->SetViewRange(NewViewOutputMin, NewViewOutputMax, EViewRangeInterpolation::Animated);
							}
						}
					}
				}
			}
		}
	}
}

FCursorReply SDialogueEditorActionTrackNode::OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const
{
	if (IsHovered() && GetDurationSize() > 0.0f)
	{
		FVector2D RelMouseLocation = MyGeometry.AbsoluteToLocal(CursorEvent.GetScreenSpacePosition());

		const float HandleHalfWidth = ScrubHandleSize.X / 2.0f;
		const float DistFromFirstHandle = FMath::Abs(RelMouseLocation.X);
		const float DistFromSecondHandle = FMath::Abs(RelMouseLocation.X - NotifyDurationSizeX);

		if (DistFromFirstHandle < HandleHalfWidth || DistFromSecondHandle < HandleHalfWidth || CurrentDragHandle != ENotifyStateHandleHit::None)
		{
			return FCursorReply::Cursor(EMouseCursor::ResizeLeftRight);
		}
	}

	return FCursorReply::Unhandled();
}


int32 SDialogueEditorActionTrackSectionNode::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	int32 MarkerLayer = LayerId + 1;
	int32 ScrubHandleID = MarkerLayer + 1;
	int32 TextLayerID = ScrubHandleID + 1;
	int32 BranchPointLayerID = TextLayerID + 1;

	const FSlateBrush* StyleInfo = GetSectionRoundBoxBrush();

	UDialogueActionBase* DialogueActionSection = ActionNodeData.CachedSection.Get();
	if (DialogueActionSection == nullptr)
		return TextLayerID;

	FText Text = GetNotifyText();
	FLinearColor BoxColor = ActionNodeData.GetColor().GetValue();

	auto CreateBoxLambda = [=, &OutDrawElements,this](const FVector2f& DurationBoxSize, const FVector2f& Offset, const FLinearColor& BoxColor)
	{
		FVector2f DurationBoxPosition = FVector2f(0, (NotifyHeight - TextSize.Y) * 0.5f + DrawBoxHeightOffset);
		FSlateLayoutTransform SlateLayoutTransform(1.0f, TransformPoint(1.0f, DurationBoxPosition + Offset));
		FSlateDrawElement::MakeBox
		(
			OutDrawElements, LayerId,
			AllottedGeometry.ToPaintGeometry(DurationBoxSize, SlateLayoutTransform),
			StyleInfo, ESlateDrawEffect::None, BoxColor
		);
	};

	if (DialogueActionSection->IsAdjustingEdge())
	{
		BoxColor = GetDefault<UDialogueEditorSettings>()->SectionAdjustEdgeColor; //拖拽的时候变色
	}

	// 根据时长创建一个Box
	if (NotifyDurationSizeX > 0.f)
	{
		FVector2f DurationBoxSize = FVector2f(NotifyDurationSizeX, TextSize.Y + TextBorderSize.Y * 2.f);

		if (DialogueActionSection->CanAdjustDurationInEditor)
		{
			CreateBoxLambda(DurationBoxSize, FVector2f::Zero(), BoxColor);
		}
		else
		{
			CreateBoxLambda(DurationBoxSize, FVector2f::Zero(), FLinearColor::Gray);
			CreateBoxLambda(DurationBoxSize - FVector2f(10.0f, 0.0f), FVector2f(5.0f, 0.0f), BoxColor);
		}
		// 重叠部分
		if(UDialogueActionTrack* OwnerDialogueAction = ActionNodeData.CachedSection->GetDialogueAction())
		{
			TArray<UDialogueActionBase*> OrderedActions = OwnerDialogueAction->GetOrderedSections();
			TArray<TPair<float, float>> UnderlappingSections;
			UDialogueActionBase* ThisAction = ActionNodeData.CachedSection.Get();
			float ThisActionStartTime = ThisAction->GetStartTime();
			float ThisActionDuration = ThisAction->GetEndTime() - ThisActionStartTime;
			for (auto Action : OrderedActions)
			{
				if (Action && Action != ThisAction)
				{
					float MaxStartTime = FMath::Max(Action->GetStartTime(), ThisAction->GetStartTime());
					float MinEndTime = FMath::Min(Action->GetEndTime(), ThisAction->GetEndTime());
					if (MaxStartTime < MinEndTime)
					{
						UnderlappingSections.Add(TPair<float, float>(MaxStartTime, MinEndTime));
					}
				}
			}
			// 绘制重叠部分
			FLinearColor SectionOverlapColor = GetDefault<UDialogueEditorSettings>()->SectionOverlapColor;
			if (ThisActionDuration > 0)
			{
				for (auto Section : UnderlappingSections)
				{
					float SectionDuration = Section.Value - Section.Key;

					FVector2D GripSize(SectionDuration / ThisActionDuration * DurationBoxSize.X, DurationBoxSize.Y);
					FVector2d Position((Section.Key - ThisActionStartTime) / ThisActionDuration * DurationBoxSize.X, (NotifyHeight - TextSize.Y) * 0.5f + DrawBoxHeightOffset);

					FSlateDrawElement::MakeBox(
						OutDrawElements, LayerId++,
						AllottedGeometry.ToPaintGeometry(GripSize, FSlateLayoutTransform(Position)),
						StyleInfo, ESlateDrawEffect::None, SectionOverlapColor);
				}
			}
		}
	}

	// 背景
	float HalfScrubHandleWidth = ScrubHandleSize.X / 2.0f;
	FVector2D LabelSize = TextSize + TextBorderSize * 2.f;
	LabelSize.X += HalfScrubHandleWidth;
	FVector2D LabelPosition(bDrawTooltipToRight ? NotifyScrubHandleCentre : NotifyScrubHandleCentre - LabelSize.X, (NotifyHeight - TextSize.Y) * 0.5f);

	FSlateLayoutTransform SlateLayoutTransform(1.0f, TransformPoint(1.0f, UE::Slate::CastToVector2f(LabelPosition)));

	if (NotifyDurationSizeX == 0.f)
	{
		CreateBoxLambda(FVector2f(LabelSize.X, LabelSize.Y), FVector2f::Zero(), FLinearColor(255, 255, 0));
	}

	float PinOffset = 0.f;
	if (ActionNodeData.bLinkTarget)
	{
		SlateLayoutTransform = FSlateLayoutTransform(1.0f, TransformPoint(1.0f, UE::Slate::CastToVector2f(FVector2D(LabelPosition.X + TextBorderSize
		.X, 4))));
		FSlateDrawElement::MakeBox(OutDrawElements, TextLayerID,
			AllottedGeometry.ToPaintGeometry(UnpinBrush.GetImageSize(), SlateLayoutTransform),
			&UnpinBrush);
		PinOffset = UnpinBrush.GetImageSize().X * 0.5f + 2;
	}

	// 文字
	FVector2D TextPosition = LabelPosition + TextBorderSize;
	if (bDrawTooltipToRight)
	{
		TextPosition.X += HalfScrubHandleWidth;
	}
	TextPosition.X += PinOffset;
	TextPosition.Y += DrawBoxHeightOffset;

	FVector2D DrawTextSize;
	DrawTextSize.X = TextSize.X - PinOffset;
	DrawTextSize.Y = TextSize.Y;

	SlateLayoutTransform = FSlateLayoutTransform(1.0f, TransformPoint(1.0f, UE::Slate::CastToVector2f(TextPosition)));

	FSlateDrawElement::MakeText
	(
		OutDrawElements, TextLayerID,
		AllottedGeometry.ToPaintGeometry(DrawTextSize, SlateLayoutTransform),
		Text, Font, ESlateDrawEffect::None, FLinearColor::White
	);

	return TextLayerID;
}

void SDialogueEditorActionTrackSectionNode::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	ScreenPosition = FVector2D(AllottedGeometry.AbsolutePosition);
}

int32 SDialogueEditorActionTrackKeyFrameNode::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	const FSlateBrush* BorderBrush = FAppStyle::GetBrush(TEXT("Sequencer.KeyDiamondBorder"));
	const FSlateBrush* FillBrush = FAppStyle::GetBrush(TEXT("Sequencer.KeyDiamond"));
	FLinearColor FillTint = ActionNodeData.GetColor().GetValue();
	FLinearColor BorderTint = FLinearColor::White;

	// 绘制边界
	FSlateDrawElement::MakeBox(
		OutDrawElements,
		bSelected ? LayerId + 1 : LayerId,
		AllottedGeometry.ToPaintGeometry(
			KeySizePx,
			FSlateLayoutTransform(FVector2d(0, KeyPositionOffsetY))
		),
		BorderBrush,
		ESlateDrawEffect::None,
		BorderTint
	);

	// 绘制内部
	FSlateDrawElement::MakeBox(
		OutDrawElements,
		bSelected ? LayerId + 2 : LayerId + 1,
		AllottedGeometry.ToPaintGeometry(
			KeySizePx - 2.0f * KeyBrushBorderWidth,
			FSlateLayoutTransform(
				FVector2D(
					KeyBrushBorderWidth, KeyPositionOffsetY + KeyBrushBorderWidth
				)
			)
		),
		FillBrush,
		ESlateDrawEffect::None,
		FillTint
	);
	return LayerId;
}

void SDialogueEditorActionTrackKeyFrameNode::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	ScreenPosition = FVector2D(AllottedGeometry.AbsolutePosition) + HalfKeySize;
}

void SDialogueEditorActionTrackKeyFrameNode::UpdateSizeAndPosition(const FGeometry& AllottedGeometry)
{
	SDialogueEditorActionTrackNode::UpdateSizeAndPosition(AllottedGeometry);
	WidgetSize.X = KeySizePx.X;
}

FMargin SDialogueEditorActionTrackKeyFrameNode::GetNotifyTrackPadding()
{
	const float LeftMargin = GetWidgetPosition().X - HalfKeySize;
	const float RightMargin = CachedTrackGeometry.GetLocalSize().X - LeftMargin - GetSize().X;
	return FMargin(LeftMargin, 0, RightMargin, 0);
}

FVector2D SDialogueEditorActionTrackKeyFrameNode::GetWidgetAndStartTimeOffset() const
{
	return FVector2D(HalfKeySize, 0.f);
}

FReply SDialogueEditorActionTrackKeyFrameNode::OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FVector2D ScreenNodePosition = FVector2D(MyGeometry.AbsolutePosition);
	bBeingDragged = true;
	return StartDragNodeEvent.Execute(SharedThis(this), MouseEvent, ScreenNodePosition, false, -HalfKeySize);
}

FCursorReply SDialogueEditorActionTrackKeyFrameNode::OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const
{
	return FCursorReply::Unhandled();
}

#undef LOCTEXT_NAMESPACE
