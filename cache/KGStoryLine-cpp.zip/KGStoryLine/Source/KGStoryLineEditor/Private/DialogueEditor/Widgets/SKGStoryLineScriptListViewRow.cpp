#include "DialogueEditor/Widgets/SKGStoryLineScriptListViewRow.h"
#include "AssetRegistry/AssetData.h"
#include "Containers/Map.h"
#include "DialogueEditor/KGStoryLineScriptEditor.h"
#include "DataTableUtils.h"
#include "Editor.h"
#include "Engine/DataTable.h"
#include "Framework/Application/MenuStack.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Commands/GenericCommands.h"
#include "Framework/Commands/UIAction.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "HAL/PlatformCrt.h"
#include "Input/Events.h"
#include "Internationalization/Internationalization.h"
#include "Layout/Children.h"
#include "Layout/Margin.h"
#include "Layout/WidgetPath.h"
#include "Misc/AssertionMacros.h"
#include "Misc/Attribute.h"
#include "Misc/MessageDialog.h"
#include "SlotBase.h"
#include "Styling/AppStyle.h"
#include "Styling/CoreStyle.h"
#include "Styling/ISlateStyle.h"
#include "Templates/Casts.h"
#include "Textures/SlateIcon.h"
#include "UObject/UnrealNames.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SNullWidget.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Views/SHeaderRow.h"

class STableViewBase;
class SWidget;
struct FGeometry;
struct FSlateBrush;

#define LOCTEXT_NAMESPACE "SKGStoryLineScriptListViewRow"

void SKGStoryLineScriptListViewRow::Construct(const FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTableView)
{
	RowDataPtr = InArgs._RowDataPtr;
	CurrentName = MakeShareable(new FName(RowDataPtr->RowId));
	ScriptEditor = InArgs._ScritpEditor;
	IsEditable = InArgs._IsEditable;
	SMultiColumnTableRow<FDataTableEditorRowListViewDataPtr>::Construct(
		FSuperRowType::FArguments()
		.Style(FAppStyle::Get(), "DataTableEditor.CellListViewRow")
		.OnDrop(this, &SKGStoryLineScriptListViewRow::OnRowDrop)
		.OnDragEnter(this, &SKGStoryLineScriptListViewRow::OnRowDragEnter)
		.OnDragLeave(this, &SKGStoryLineScriptListViewRow::OnRowDragLeave),
		InOwnerTableView
	);

	SetBorderImage(TAttribute<const FSlateBrush*>(this, &SKGStoryLineScriptListViewRow::GetBorder));

}

FReply SKGStoryLineScriptListViewRow::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (IsEditable && MouseEvent.GetEffectingButton() == EKeys::RightMouseButton && RowDataPtr.IsValid() && FEditorDelegates::OnOpenReferenceViewer.IsBound() && ScriptEditor.IsValid())
	{
		if(ScriptEditor.IsValid())
		{
			ScriptEditor.Pin()->SelectRow(RowDataPtr->RowId);
		}

		TSharedRef<SWidget> MenuWidget = MakeRowActionsMenu();

		FWidgetPath WidgetPath = MouseEvent.GetEventPath() != nullptr ? *MouseEvent.GetEventPath() : FWidgetPath();
		FSlateApplication::Get().PushMenu(AsShared(), WidgetPath, MenuWidget, MouseEvent.GetScreenSpacePosition(), FPopupTransitionEffect::ContextMenu);
		return FReply::Handled();
	}

	return STableRow::OnMouseButtonUp(MyGeometry, MouseEvent);
}

void SKGStoryLineScriptListViewRow::OnInsertNewRow(ERowInsertionPosition InsertPosition)
{
	if (ScriptEditor.IsValid() && RowDataPtr.IsValid())
	{
		if (FKGStoryLineScriptEditor* Editor = ScriptEditor.Pin().Get())
		{
			UDialogueAsset* Asset = Editor->GetEditingAsset();

			if (Asset && KGStoryLine::IsValidEpisodeID(Editor->EditingEpisodeID))
			{
				if (auto* Episode = Asset->GetDialogueEpisodeByEpisodeID(Editor->EditingEpisodeID))
				{
					FName NewRowName = FKGStoryLineScriptEditor::LineIndex2RowId(Episode->DialogueLines.Num());
					if (InsertPosition == ERowInsertionPosition::Bottom)
					{
						Editor->OnAddClicked();
					}
					else if (GetCurrentName() != NAME_None)
					{
						Editor->AddRowAboveOrBelow(GetCurrentName(), InsertPosition);
					}
				}
			}
		}
	}
}

FReply SKGStoryLineScriptListViewRow::OnRowDrop(const FDragDropEvent& DragDropEvent)
{
	bIsHoveredDragTarget = false;

	TSharedPtr<FKGStoryLineScriptRowDragDropOp> DropOp = DragDropEvent.GetOperationAs< FKGStoryLineScriptRowDragDropOp >();
	TSharedPtr<SKGStoryLineScriptListViewRow> RowPtr = nullptr;
	if (DropOp.IsValid() && DropOp->Row.IsValid())
	{
		RowPtr = DropOp->Row.Pin();
	}
	if (!RowPtr.IsValid())
	{
		return FReply::Unhandled();
	}

	int32 JumpCount = (RowPtr->RowDataPtr)->RowNum - RowDataPtr->RowNum;

	if (!JumpCount)
	{
		return FReply::Handled();
	}

	FDataTableEditorUtils::ERowMoveDirection Direction = JumpCount > 0 ? FDataTableEditorUtils::ERowMoveDirection::Up : FDataTableEditorUtils::ERowMoveDirection::Down;

	if (FKGStoryLineScriptEditor* Editor = ScriptEditor.Pin().Get())
	{
		UDialogueAsset* Asset = Editor->GetEditingAsset();

		if (Asset && KGStoryLine::IsValidEpisodeID(Editor->EditingEpisodeID))
		{
			FName& RowId = (RowPtr->RowDataPtr)->RowId;

			Editor->MoveRow(RowId, Direction, FMath::Abs<int32>(JumpCount));
			Editor->SelectRow(RowId);

			Editor->SortMode = EColumnSortMode::Ascending;
			Editor->SortByColumn = FKGStoryLineScriptEditor::RowNameColumnId;

			return FReply::Handled();
		}
	}

	return FReply::Unhandled();
}

FReply SKGStoryLineScriptListViewRow::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	FKey Key = InKeyEvent.GetKey();

	if (Key == EKeys::Escape && InlineEditableText.IsValid() && InlineEditableText->HasKeyboardFocus())
	{
		// Clear focus
		return FReply::Handled().SetUserFocus(SharedThis(this), EFocusCause::Cleared);
	}

	return FReply::Unhandled();
}

void SKGStoryLineScriptListViewRow::OnRowRenamed(const FText& Text, ETextCommit::Type CommitType)
{
	UDataTable* DataTable = Cast<UDataTable>(ScriptEditor.Pin()->GetEditingObject());

	if (!GetCurrentNameAsText().EqualTo(Text) && DataTable)
	{
		if (FKGStoryLineScriptEditor* Editor = ScriptEditor.Pin().Get())
		{

			const TArray<FName> RowNames = DataTable->GetRowNames();

			if (Text.IsEmptyOrWhitespace() || !FName::IsValidXName(Text.ToString(), INVALID_NAME_CHARACTERS))
			{
				// Only pop up the error dialog if the rename was caused by the user's action
				if ((CommitType == ETextCommit::OnEnter) || (CommitType == ETextCommit::OnUserMovedFocus))
				{
					// popup an error dialog here
					const FText Message = FText::Format(LOCTEXT("InvalidRowName", "'{0}' is not a valid row name"), Text);
					FMessageDialog::Open(EAppMsgType::Ok, Message);
				}
				return;
			}
			const FName NewName = DataTableUtils::MakeValidName(Text.ToString());
			if (NewName == NAME_None)
			{
				// popup an error dialog here
				const FText Message = FText::Format(LOCTEXT("InvalidRowName", "'{0}' is not a valid row name"), Text);
				FMessageDialog::Open(EAppMsgType::Ok, Message);

				return;
			}
			for (const FName& Name : RowNames)
			{
				if (Name.IsValid() && (Name == NewName))
				{
					//the name already exists
					// popup an error dialog here
					const FText Message = FText::Format(LOCTEXT("DuplicateRowName", "'{0}' is already used as a row name in this table"), Text);
					FMessageDialog::Open(EAppMsgType::Ok, Message);
					return;

				}
			}

			const FName OldName = GetCurrentName();
			FDataTableEditorUtils::RenameRow(DataTable, OldName, NewName);
			FDataTableEditorUtils::SelectRow(DataTable, NewName);

			Editor->SetDefaultSort();

			*CurrentName = NewName;
		}
	}
}

TSharedRef<SWidget> SKGStoryLineScriptListViewRow::GenerateWidgetForColumn(const FName& ColumnName)
{
	TSharedPtr<FKGStoryLineScriptEditor> Editor = ScriptEditor.Pin();
	return (Editor.IsValid())
		? MakeCellWidget(IndexInList, ColumnName)
		: SNullWidget::NullWidget;
}

TSharedRef<SWidget> SKGStoryLineScriptListViewRow::MakeCellWidget(const int32 InRowIndex, const FName& InColumnId)
{
	const FName RowDragDropColumnId("RowDragDrop");

	int32 ColumnIndex = 0;

	FKGStoryLineScriptEditor* Editor = ScriptEditor.Pin().Get();
	TArray<FDataTableEditorColumnHeaderDataPtr>& AvailableColumns = Editor->AvailableColumns;

	if (InColumnId.IsEqual(RowDragDropColumnId))
	{
		return SNew(SKGStoryLineScriptRowHandle)
			.Content()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.Padding(5.0f, 1.0f)
				[
					SNew(SImage)
					.Image(FCoreStyle::Get().GetBrush("VerticalBoxDragIndicatorShort"))
				]
			]
			.ParentRow(SharedThis(this));
	}

	const FName RowNumberColumnId("RowNumber");

	if (InColumnId.IsEqual(RowNumberColumnId))
	{
		return SNew(SBox)
			.Padding(FMargin(4, 2, 4, 2))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "DataTableEditor.CellText")
				.Text(FText::FromString(FString::FromInt(RowDataPtr->RowNum)))
				.ColorAndOpacity(Editor, &FKGStoryLineScriptEditor::GetRowTextColor, RowDataPtr->RowId)
				.HighlightText(Editor, &FKGStoryLineScriptEditor::GetFilterText)
			];
	}

	const FName RowNameColumnId("RowName");

	if (InColumnId.IsEqual(RowNameColumnId))
	{
		return SNew(SBox)
			.Padding(FMargin(4, 2, 4, 2))
			[
				SAssignNew(InlineEditableText, SInlineEditableTextBlock)
				.Text(RowDataPtr->DisplayName)
				.OnTextCommitted(this, &SKGStoryLineScriptListViewRow::OnRowRenamed)
				.HighlightText(Editor, &FKGStoryLineScriptEditor::GetFilterText)
				.ColorAndOpacity(Editor, &FKGStoryLineScriptEditor::GetRowTextColor, RowDataPtr->RowId)
				.IsReadOnly(true)
			];
	}

	for (; ColumnIndex < AvailableColumns.Num(); ++ColumnIndex)
	{
		const FDataTableEditorColumnHeaderDataPtr& ColumnData = AvailableColumns[ColumnIndex];
		if (ColumnData->ColumnId == InColumnId)
		{
			break;
		}
	}
	 
	// Valid column ID?
	if (AvailableColumns.IsValidIndex(ColumnIndex) && RowDataPtr->CellData.IsValidIndex(ColumnIndex))
	{
		return SNew(SBox)
			.Padding(FMargin(4, 2, 4, 2))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "DataTableEditor.CellText")
				.ColorAndOpacity(Editor, &FKGStoryLineScriptEditor::GetRowTextColor, RowDataPtr->RowId)
				.Text(Editor, &FKGStoryLineScriptEditor::GetCellText, RowDataPtr, ColumnIndex)
				.HighlightText(Editor, &FKGStoryLineScriptEditor::GetFilterText)
				.ToolTipText(Editor, &FKGStoryLineScriptEditor::GetCellToolTipText, RowDataPtr, ColumnIndex)
			];
	}

	return SNullWidget::NullWidget;
}

FName SKGStoryLineScriptListViewRow::GetCurrentName() const
{
	return CurrentName.IsValid() ? *CurrentName : NAME_None;

}

uint32 SKGStoryLineScriptListViewRow::GetCurrentIndex() const
{
	return RowDataPtr.IsValid() ? RowDataPtr->RowNum : -1;
}

const TArray<FText>& SKGStoryLineScriptListViewRow::GetCellValues() const
{
	check(RowDataPtr)
	return RowDataPtr->CellData;
}

FReply SKGStoryLineScriptListViewRow::OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	if (InlineEditableText.IsValid() && InlineEditableText->IsHovered())
	{
		InlineEditableText->EnterEditingMode();
	}

	return FReply::Handled();
}

void SKGStoryLineScriptListViewRow::SetRowForRename()
{
	if (InlineEditableText.IsValid())
	{
		InlineEditableText->EnterEditingMode();
	}
}

const FDataTableEditorRowListViewDataPtr& SKGStoryLineScriptListViewRow::GetRowDataPtr() const
{
	return RowDataPtr;
}

FText SKGStoryLineScriptListViewRow::GetCurrentNameAsText() const
{
	return FText::FromName(GetCurrentName());
}

void SKGStoryLineScriptRowHandle::Construct(const FArguments& InArgs)
{
	ParentRow = InArgs._ParentRow;

	ChildSlot
		[
			InArgs._Content.Widget
		];
}

FReply SKGStoryLineScriptRowHandle::OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton))
	{
		TSharedPtr<FDragDropOperation> DragDropOp = CreateDragDropOperation(ParentRow.Pin());
		if (DragDropOp.IsValid())
		{
			return FReply::Handled().BeginDragDrop(DragDropOp.ToSharedRef());
		}
	}

	return FReply::Unhandled();

}

TSharedPtr<FKGStoryLineScriptRowDragDropOp> SKGStoryLineScriptRowHandle::CreateDragDropOperation(TSharedPtr<SKGStoryLineScriptListViewRow> InRow)
{
	TSharedPtr<FKGStoryLineScriptRowDragDropOp> Operation = MakeShareable(new FKGStoryLineScriptRowDragDropOp(InRow));

	return Operation;
}

void SKGStoryLineScriptListViewRow::SetIsDragDrop(bool bInIsDragDrop)
{
	bIsDragDropObject = bInIsDragDrop;
}


void SKGStoryLineScriptListViewRow::OnRowDragEnter(const FDragDropEvent& DragDropEvent)
{
	bIsHoveredDragTarget = true;
}

void SKGStoryLineScriptListViewRow::OnRowDragLeave(const FDragDropEvent& DragDropEvent)
{
	bIsHoveredDragTarget = false;
}


const FSlateBrush* SKGStoryLineScriptListViewRow::GetBorder() const
{
	if (bIsDragDropObject)
	{
		return FAppStyle::GetBrush("DataTableEditor.DragDropObject");
	}
	else if (bIsHoveredDragTarget)
	{
		return FAppStyle::GetBrush("DataTableEditor.DragDropHoveredTarget");
	}
	else
	{
		return STableRow::GetBorder();
	}
}

void SKGStoryLineScriptListViewRow::OnMoveToExtentClicked(FDataTableEditorUtils::ERowMoveDirection MoveDirection)
{
	if (ScriptEditor.IsValid())
	{
		TSharedPtr<FKGStoryLineScriptEditor> Editor = ScriptEditor.Pin();
		Editor->OnMoveToExtentClicked(MoveDirection);
	}
}


TSharedRef<SWidget> SKGStoryLineScriptListViewRow::MakeRowActionsMenu()
{
	FMenuBuilder MenuBuilder(true, ScriptEditor.Pin()->GetToolkitCommands());

	MenuBuilder.AddMenuEntry(
		LOCTEXT("KGSLScriptEditorRowMenuActions_InsertNewRow", "Insert New Line"),
		LOCTEXT("KGSLScriptEditorRowMenuActions_InsertNewRowTooltip", "Insert a new line"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "DataTableEditor.Add"), 
		FUIAction(FExecuteAction::CreateSP(this, &SKGStoryLineScriptListViewRow::OnInsertNewRow, ERowInsertionPosition::Bottom))
	);
	
	MenuBuilder.AddMenuEntry(
		LOCTEXT("KGSLScriptEditorRowMenuActions_InsertNewRowAbove", "Insert New Line Above"),
		LOCTEXT("KGSLScriptEditorRowMenuActions_InsertNewRowAboveTooltip", "Insert a new line above the current selection"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "DataTableEditor.Add"),
		FUIAction(FExecuteAction::CreateSP(this, &SKGStoryLineScriptListViewRow::OnInsertNewRow, ERowInsertionPosition::Above))
	);
	
	MenuBuilder.AddMenuEntry(
		LOCTEXT("KGSLScriptEditorRowMenuActions_InsertNewRowBelow", "Insert New line Below"),
		LOCTEXT("KGSLScriptEditorRowMenuActions_InsertNewRowBelowTooltip", "Insert a new line below the current selection"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "DataTableEditor.Add"),
		FUIAction(FExecuteAction::CreateSP(this, &SKGStoryLineScriptListViewRow::OnInsertNewRow, ERowInsertionPosition::Below))
	);

	MenuBuilder.AddMenuEntry(FGenericCommands::Get().Copy);
	MenuBuilder.AddMenuEntry(FGenericCommands::Get().Paste);
	MenuBuilder.AddMenuEntry(FGenericCommands::Get().Duplicate);
	MenuBuilder.AddMenuEntry(FGenericCommands::Get().Delete);

	MenuBuilder.AddMenuSeparator();

	MenuBuilder.AddMenuEntry(
		LOCTEXT("KGSLScriptEditorRowMenuActions_MoveToTopAction", "Move Line to Top"),
		LOCTEXT("KGSLScriptEditorRowMenuActions_MoveToTopActionTooltip", "Move selected line to the top"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "Symbols.DoubleUpArrow"), 
		FUIAction(FExecuteAction::CreateSP(this, &SKGStoryLineScriptListViewRow::OnMoveToExtentClicked, FDataTableEditorUtils::ERowMoveDirection::Up))
	);
	
	MenuBuilder.AddMenuEntry(
		LOCTEXT("KGSLScriptEditorRowMenuActions_MoveToBottom", "Move Line To Bottom"),
		LOCTEXT("KGSLScriptEditorRowMenuActions_MoveToBottomTooltip", "Move selected line to the bottom"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "Symbols.DoubleDownArrow"), 
		FUIAction(FExecuteAction::CreateSP(this, &SKGStoryLineScriptListViewRow::OnMoveToExtentClicked, FDataTableEditorUtils::ERowMoveDirection::Down))
	);
	
	return MenuBuilder.MakeWidget();
}

FKGStoryLineScriptRowDragDropOp::FKGStoryLineScriptRowDragDropOp(TSharedPtr<SKGStoryLineScriptListViewRow> InRow)
{
	Row = InRow;

	TSharedPtr<SKGStoryLineScriptListViewRow> RowPtr = nullptr;
	if (Row.IsValid())
	{
		RowPtr = Row.Pin();
		RowPtr->SetIsDragDrop(true);

		DecoratorWidget = SNew(SBorder)
			.Padding(8.f)
			.BorderImage(FAppStyle::GetBrush("Graph.ConnectorFeedback.Border"))
			.Content()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::Format(NSLOCTEXT("DataTableDragDrop", "PlaceRowHere", "Place Row {0} Here"), FText::AsNumber(InRow->GetCurrentIndex())))
				]
			];

		Construct();
	}
}

void FKGStoryLineScriptRowDragDropOp::OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent)
{
	FDecoratedDragDropOp::OnDrop(bDropWasHandled, MouseEvent);

	TSharedPtr<SKGStoryLineScriptListViewRow> RowPtr = nullptr;
	if (Row.IsValid())
	{
		RowPtr = Row.Pin();
		RowPtr->SetIsDragDrop(false);
	}
}

#undef LOCTEXT_NAMESPACE
