#include "DialogueEditor/Widgets/AssetBrowser/SDialogueAssetTreeView.h"

#include "DialogueEditor/Widgets/AssetBrowser/SDialogueAssetBrowser.h"


void SDialogueAssetTreeView::Construct(const SDialogueAssetTreeView::FArguments& InArgs, TSharedRef<SDialogueAssetBrowser> Owner)
{
	DialogueAssetBrowserWeak = Owner;
	STreeView::Construct(InArgs);
}

void SDialogueAssetTreeRow::Construct(const FArguments& InArgs, const TSharedRef<SDialogueAssetTreeView>& DialogueAssetTreeView, TSharedRef<class SDialogueAssetBrowser> DialogueAssetBrowser)
{
	Item = InArgs._Item->AsShared();
	DialogueAssetBrowserWeak = DialogueAssetBrowser;

	auto Args = FSuperRowType::FArguments()
		.Style(&FAppStyle::Get().GetWidgetStyle<FTableRowStyle>("SceneOutliner.TableViewRow"));


	// Args.OnDragDetected_Static(HandleOnDragDetected, TWeakPtr<SSceneOutlinerTreeView>(OutlinerTreeView));

	SMultiColumnTableRow<FDialogueAssetTreeItemPtr>::Construct(Args, DialogueAssetTreeView);
}

TSharedRef<SWidget> SDialogueAssetTreeRow::GenerateWidgetForColumn(const FName& ColumnName)
{
	auto Browser = DialogueAssetBrowserWeak.Pin().Get();
	if (ColumnName == DialogueAssetBrowserColumnConstants::DialogueID)
	{
		
		TSharedRef<SWidget> NewItemWidget = Item.Pin()->GenerateLabelWidget(*Browser, *this);
		return SNew(SBox)
			[
				SNew( SHorizontalBox )

				+SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(6, 0, 0, 0)
				[
					SNew( SExpanderArrow, SharedThis(this) ).IndentAmount(12)
				]

				+SHorizontalBox::Slot()
				.FillWidth(1.0f)
				[
					NewItemWidget
				]
			];
	}

	if (ColumnName == DialogueAssetBrowserColumnConstants::AuthorName)
	{
		return SNew(STextBlock)
			.Font(FAppStyle::Get().GetFontStyle("NormalFontBold"))
			.Text(FText::FromString(Item.Pin()->GetDialogueAuthorName()))
			.HighlightText_Lambda([Browser]()
			{
				return Browser->GetFilterText();
			});
	}

	if (ColumnName == DialogueAssetBrowserColumnConstants::Description)
	{
		return SNew(STextBlock)
			.Font(FAppStyle::Get().GetFontStyle("NormalFontBold"))
			.Text(FText::FromString(Item.Pin()->GetDescription()))
			.HighlightText_Lambda([Browser]()
			{
				return Browser->GetFilterText();
			});
	}
	

	{
		// Other columns just get widget content -- no expansion arrow needed
		return SNullWidget::NullWidget;
	}
}
