#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorTrackOutliner.h"
#include "Framework/Application/SlateApplication.h"

#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineDragDropOp.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTrack.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"


#define LOCTEXT_NAMESPACE "SDialogueEditorTrackOutliner"



void SDialogueEditorTrackOutliner::Construct(const FArguments& InArgs, const TSharedPtr<FTimelineController>& InTimelineController, UDialogueTrackBase* InTrack, TSharedPtr<class FDialogueEditorTrack> InDialogueEditorTrack)
{
	TimelineController = StaticCastSharedPtr<FDialogueEditorTimelineController>(InTimelineController);

	CachedTrack = InTrack;

	CachedDialogueEditorTrack = InDialogueEditorTrack;

	TrackPanelArea = InArgs._TrackPanelArea;
	OutlineWidget = InArgs._OutlineWidget;
	InlineEditableTextBlock = InArgs._InlineEditableTextBlock;
	ExtraTextBlock = InArgs._ExtraTextBlock;

	/*this->ChildSlot
	[
		TrackPanelArea.ToSharedRef()
	];*/

	this->ChildSlot
		[
			OutlineWidget.ToSharedRef()
		];

	//UpdateLayout();
}


void SDialogueEditorTrackOutliner::UpdateLayout()
{
	TSharedPtr<SHorizontalBox> ParentOutlinerWidget =
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.FillWidth(1.0f)
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Left)
		.Padding(20.0f, 0.0f, 0.0f, 0.0f)
		[
			InlineEditableTextBlock.ToSharedRef()
		]
		+SHorizontalBox::Slot()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Left)
		.Padding(2.0f, 1.0f)
		.AutoWidth()
		[
			ExtraTextBlock.ToSharedRef()
		];
	TrackPanelArea->SetContent(ParentOutlinerWidget.ToSharedRef());
}

FReply SDialogueEditorTrackOutliner::OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	bool bWasDropHandled = false;

	TSharedPtr<FDragDropOperation> Operation = DragDropEvent.GetOperation();
	if (!Operation.IsValid())
	{

	}
	else if (Operation->IsOfType<FDialogueEditorTrackDragDropOp>())
	{
		/*const auto& FrameDragDropOp = StaticCastSharedPtr<FDialogueEditorTrackDragDropOp>(Operation);
		FrameDragDropOp->ChangeTrackPosition(CachedTrack.Get());
		bWasDropHandled = true;*/
	}
	
	return bWasDropHandled ? FReply::Handled() : FReply::Unhandled();
}

void SDialogueEditorTrackOutliner::OnDragEnter(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	TSharedPtr<FDragDropOperation> Operation = DragDropEvent.GetOperation();
	if (Operation->IsOfType<FDialogueEditorTrackDragDropOp>())
	{
		const auto& FrameDragDropOp = StaticCastSharedPtr<FDialogueEditorTrackDragDropOp>(Operation);
		if (CachedTrack == FrameDragDropOp->CachedTrack)
		{
			return;
		}
		
	}
}

void SDialogueEditorTrackOutliner::OnDragLeave(const FDragDropEvent& DragDropEvent)
{
	TSharedPtr<FDragDropOperation> Operation = DragDropEvent.GetOperation();
	if (Operation->IsOfType<FDialogueEditorTrackDragDropOp>())
	{
		const auto& FrameDragDropOp = StaticCastSharedPtr<FDialogueEditorTrackDragDropOp>(Operation);
		if (CachedTrack == FrameDragDropOp->CachedTrack)
		{
			return;
		}

	}
}

FReply SDialogueEditorTrackOutliner::OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton))
	{
		UDialogueSpawnableTrack* DialogueSpawnableTrack = Cast<UDialogueSpawnableTrack>(CachedTrack.Get());
		if (DialogueSpawnableTrack == nullptr)
		{
			FNotificationInfo Info(FText::FromString(TEXT("不能拖拽行为类轨道")));
			Info.bFireAndForget = true;
			Info.ExpireDuration = 3.0f;
			Info.bUseSuccessFailIcons = false;
			Info.bUseLargeFont = false;
			FSlateNotificationManager::Get().AddNotification(Info);
			return FReply::Unhandled();
		}
		
		TSharedRef<SOverlay> NodeDragDecoratorOverlay = SNew(SOverlay);
		TSharedRef<SBorder> NodeDragDecorator = 
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
			.BorderBackgroundColor(FLinearColor(.0f, 1.f, .0f))
			[
				NodeDragDecoratorOverlay
			];

		FVector2D OffsetFromFirst(2, 2);

		TSharedPtr<SWidget> NodeWidget = SNullWidget::NullWidget;

		if (CachedDialogueEditorTrack.IsValid())
		{
			NodeWidget = CachedDialogueEditorTrack.Pin()->GenerateOnDragContainerWidgetForOutliner();
		}

		NodeDragDecoratorOverlay->
			AddSlot()
			.Padding(FMargin(OffsetFromFirst.X, OffsetFromFirst.Y, 0.0f, 0.0f))
			[
				NodeWidget.ToSharedRef()
			];

		return FReply::Handled().BeginDragDrop(FDialogueEditorTrackDragDropOp::New(TimelineController.Pin().ToSharedRef(), CachedTrack.Get(), NodeDragDecorator));
	}

	return FReply::Unhandled();
}

FReply SDialogueEditorTrackOutliner::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		if (CachedTrack.IsValid() && TimelineController.IsValid() && TimelineController.Pin()->GetCachedEditor())
		{
			TimelineController.Pin()->SetTrackSelected(CachedTrack.Get(), true);
		}
		return FReply::Handled().DetectDrag(SharedThis(this), EKeys::LeftMouseButton);
	}

	return FReply::Unhandled();
}

FReply SDialogueEditorTrackOutliner::OnMouseButtonDoubleClick(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		if (CachedTrack.IsValid() && TimelineController.IsValid() && TimelineController.Pin()->GetCachedEditor())
		{
			TimelineController.Pin()->DoubleClickTrack(CachedTrack.Get());
		}
		return FReply::Handled().DetectDrag(SharedThis(this), EKeys::LeftMouseButton);
	}

	return FReply::Unhandled();
}

FReply SDialogueEditorTrackOutliner::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	/*if(InKeyEvent.GetKey() == EKeys::LeftControl || InKeyEvent.GetKey() == EKeys::RightControl)
	{
		TimelineController.Pin()->GetCachedEditor()->IsTrackPressCtrl = true;
	}*/
	return FReply::Handled();
}
FReply SDialogueEditorTrackOutliner::OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	/*if(InKeyEvent.GetKey() == EKeys::LeftControl || InKeyEvent.GetKey() == EKeys::RightControl)
	{
		TimelineController.Pin()->GetCachedEditor()->IsTrackPressCtrl = false;
	}*/
	return FReply::Handled();
}


#undef LOCTEXT_NAMESPACE
