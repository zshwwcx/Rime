#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueActorTrackEditor.h"
#include "Widgets/Input/SCheckBox.h"
#include "LevelEditorViewport.h"
#include "Widgets/TimeLineBase/TimelineController.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "KGSLEditorStyle.h"


#define LOCTEXT_NAMESPACE "DialogueActorTrackEditor"


void FDialogueActorTrackEditor::BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder)
{
	UDialogueEditorSettings* DialogueSettings = GetMutableDefault<UDialogueEditorSettings>();


	TArray<TSubclassOf<class UDialogueActionTrack>>* SubTracks = nullptr;
	
	for (auto& TrackSetting : DialogueSettings->ActorSubTracks)
	{
		if (TrackSetting.ActorTrackClass == CachedTrack->GetClass())
		{
			SubTracks = &(TrackSetting.SubTrackClasses);
			break;
		}
	}
	if(SubTracks == nullptr)
		return;
	for (TSubclassOf<UDialogueActionTrack> ActorSubTrackCls : *SubTracks)
	{
		InMenuBuilder.AddMenuEntry
		(
			ActorSubTrackCls->GetDisplayNameText(),
			FText::FromString(ActorSubTrackCls->GetDescription()),
			FSlateIcon(),
			FUIAction
			(
				FExecuteAction::CreateSP(this, &FDialogueActorTrackEditor::AddActorSubTrack, ActorSubTrackCls)
			),
			NAME_None,
			EUserInterfaceActionType::Button
		);
	}
}

void FDialogueActorTrackEditor::AddActorSubTrack(TSubclassOf<class UDialogueActionTrack> TrackCls)
{
	UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (!Asset)
		return;
	UObject* Outer = CachedTrack.IsValid() ? CachedTrack.Get() : Cast<UObject>(Asset);
	UDialogueActionTrack* NewTrack = NewObject<UDialogueActionTrack>(Outer, TrackCls, NAME_None, RF_Transactional);
	CachedTrack->AddAction(NewTrack);
	Asset->GetPackage()->MarkPackageDirty();
	TimelineController.Pin()->RefreshTracks();
}

const FSlateBrush* FDialogueActorTrackEditor::GetIconBrush() const
{
	return FKGSLEditorStyle::Get().GetBrush("KGSL.Tracks.Actor");
}

#undef LOCTEXT_NAMESPACE