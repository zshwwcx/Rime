// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/Widgets/SKGSLScriptEdListViewSettings.h"

#include "DataTableEditorUtils.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "KGSLEditorStyle.h"
#include "DialogueEditor/KGStoryLineScriptEditor.h"
#include "LandscapeHeightfieldCollisionComponent.h"
#include "Widgets/Input/SButton.h"

#define LOCTEXT_NAMESPACE "KGSLScriptEdListViewSettings"

const FName SKGSLScriptEdListViewSettingsRow::RowDragDropColumnId = TEXT("RowDragDropColumn");
const FName SKGSLScriptEdListViewSettingsRow::RowNumberColumnId = TEXT("RowNumberColumn");
const FName SKGSLScriptEdListViewSettingsRow::NameColumnId = TEXT("Name");


//
// SKGSLScriptEdListViewSettingsRow
//
FReply SKGSLScriptEdListViewSettingsRow::OnRowDrop(const FDragDropEvent& DragDropEvent)
{
	TSharedPtr<SKGSLScriptEdListViewSettingsRowDragDropOp> DropOp = DragDropEvent.GetOperationAs<SKGSLScriptEdListViewSettingsRowDragDropOp>();
	TSharedPtr<SKGSLScriptEdListViewSettingsRow> RowPtr = nullptr;
	if (DropOp.IsValid() && DropOp->Row.IsValid())
	{
		RowPtr = DropOp->Row.Pin();
	}
	if (!RowPtr.IsValid())
	{
		return FReply::Unhandled();
	}

	int32 JumpCount = (RowPtr->RowData)->RowNum - RowData->RowNum;

	if (!JumpCount)
	{
		return FReply::Handled();
	}

	FDataTableEditorUtils::ERowMoveDirection Direction = JumpCount > 0 ? FDataTableEditorUtils::ERowMoveDirection::Up : FDataTableEditorUtils::ERowMoveDirection::Down;

	if (ViewSettings.IsValid())
	{
		if (auto View = ViewSettings.Pin())
		{
			View->MoveRow(RowPtr->RowData->RowNum, Direction, FMath::Abs(JumpCount));
			View->SelectRow(RowPtr->RowData->RowNum);
			return FReply::Handled();
		}
	}

	return FReply::Unhandled();
}

void SKGSLScriptEdListViewSettingsRow::OnRowDragEnter(const FDragDropEvent& DragDropEvent)
{
	bIsHoveredDragTarget = true;
}

void SKGSLScriptEdListViewSettingsRow::OnRowDragLeave(const FDragDropEvent& DragDropEvent)
{
	bIsHoveredDragTarget = false;
}

void SKGSLScriptEdListViewSettingsRow::Construct(const FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTable)
{
	ViewSettings = InArgs._ViewSettings;
	RowData = InArgs._RowDataPtr;
	ColumnName = InArgs._ColumnName;
	Order = InArgs._Order;
	SMultiColumnTableRow::Construct(
		FSuperRowType::FArguments()
		.Style(FAppStyle::Get(), "DataTableEditor.CellListViewRow")
		.OnDrop(this, &SKGSLScriptEdListViewSettingsRow::OnRowDrop)
		.OnDragEnter(this, &SKGSLScriptEdListViewSettingsRow::OnRowDragEnter)
		.OnDragLeave(this, &SKGSLScriptEdListViewSettingsRow::OnRowDragLeave)
		, InOwnerTable
		);
	
	SetBorderImage(TAttribute<const FSlateBrush*>(this, &SKGSLScriptEdListViewSettingsRow::GetBorder));
}

const FSlateBrush* SKGSLScriptEdListViewSettingsRow::GetBorder() const
{
	if (bIsDragDropObject)
	{
		return FAppStyle::GetBrush("DataTableEditor.DragDropObject");
	}

	if (bIsHoveredDragTarget)
	{
		return FAppStyle::GetBrush("DataTableEditor.DragDropHoveredTarget");
	}

	return STableRow::GetBorder();
}

FSlateColor SKGSLScriptEdListViewSettingsRow::GetRowTextColor() const
{
	return bSelected ? FSlateColor(FColorList::Orange) : FSlateColor::UseForeground();
}

FText SKGSLScriptEdListViewSettingsRow::GetColumnNameText() const
{
	return FText::FromString(RowData.IsValid() ? RowData->DisplayName : FString(""));
}

FReply SKGSLScriptEdListViewSettingsRow::OnMoveUpClicked()
{
	if (ViewSettings.IsValid() && RowData.IsValid())
	{
		ViewSettings.Pin()->MoveRow(RowData->RowNum, FDataTableEditorUtils::ERowMoveDirection::Up);
	}
	
	return FReply::Handled();
}

FReply SKGSLScriptEdListViewSettingsRow::OnMoveDownClicked()
{
	if (ViewSettings.IsValid() && RowData.IsValid())
	{
		ViewSettings.Pin()->MoveRow(RowData->RowNum, FDataTableEditorUtils::ERowMoveDirection::Down);
	}
	
	return FReply::Handled();
}

FText SKGSLScriptEdListViewSettingsRow::GetOrderText() const
{
	if (RowData.IsValid())
	{
		return FText::FromString(FString::FromInt(RowData->RowNum));
	}
	
	return FText::FromString("");
}

TSharedRef<SWidget> SKGSLScriptEdListViewSettingsRow::GenerateWidgetForColumn(const FName& InColumnName)
{
	if (!RowData.IsValid())
	{
		return SNullWidget::NullWidget;
	}

	
	if (InColumnName.IsEqual(RowDragDropColumnId))
	{
		return SNew(SKGSLScriptEdListViewSettingsRowHandle)
			.Content()
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.Padding(5.f, 1.f)
				.AutoWidth()
				.VAlign(VAlign_Center)
				[
					SNew(SImage)
					.Image(FCoreStyle::Get().GetBrush("VerticalBoxDragIndicatorShort"))
				]
			]
			.ParentRow(SharedThis(this));
	}
	
	if (InColumnName.IsEqual(RowNumberColumnId))
	{
		return SNew(SBox)
			.Padding(FMargin(4, 2, 4, 2))
			.VAlign(VAlign_Center)
			[
				SNew(STextBlock)
				.TextStyle(FKGSLEditorStyle::Get(), "KGSL.NormalText")
				.Text(this, &SKGSLScriptEdListViewSettingsRow::GetOrderText)
				.ColorAndOpacity(this, &SKGSLScriptEdListViewSettingsRow::GetRowTextColor)
			];
	}
	
	if (InColumnName.IsEqual(NameColumnId))
	{
		return SNew(SBox)
			.Padding(FMargin(4, 2, 4, 2))
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.Padding(FMargin(4, 2, 4, 2))
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Left)
				[
					SNew(STextBlock)
					.TextStyle(FKGSLEditorStyle::Get(), "KGSL.NormalText")
					.ColorAndOpacity(this, &SKGSLScriptEdListViewSettingsRow::GetRowTextColor)
					.Text(this, &SKGSLScriptEdListViewSettingsRow::GetColumnNameText)	
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.MaxWidth(24)
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Right)
				.Padding(FMargin(2, 2, 2, 2))
				[
					SNew(SButton)
					.ContentPadding(0)
					.OnClicked(this, &SKGSLScriptEdListViewSettingsRow::OnMoveUpClicked)
					.ButtonStyle(FKGSLEditorStyle::Get(), "KGSL.ButtonStyle")
					[
						SNew(SImage)
						.Image(FKGSLEditorStyle::Get().GetBrush("KGSL.DoubleUpArrow"))
						.ColorAndOpacity(FSlateColor::UseForeground() )
					]
				]
				+SHorizontalBox::Slot()
				.AutoWidth()
				.MaxWidth(24)
				.Padding(FMargin(2, 2, 2, 2))
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Right)
				[
					SNew(SButton)
					.ContentPadding(0)
					.OnClicked(this, &SKGSLScriptEdListViewSettingsRow::OnMoveDownClicked)
					.ButtonStyle(FKGSLEditorStyle::Get(), "KGSL.ButtonStyle")
					[
						SNew(SImage)
						.Image(FKGSLEditorStyle::Get().GetBrush("KGSL.DoubleDownArrow"))
						.ColorAndOpacity(FSlateColor::UseForeground() )
					]
				]
			];
	}

	return SNullWidget::NullWidget;
}

void SKGSLScriptEdListViewSettingsRow::SetIsDragDrop(bool bInIsDragDrop)
{
	bIsDragDropObject = bInIsDragDrop;
}

uint32 SKGSLScriptEdListViewSettingsRow::GetCurrentIndex() const
{
	return RowData.IsValid() ? RowData->RowNum : -1;
}

//
// SKGSLScriptEdListViewSettingsRowDragDropOp
//
SKGSLScriptEdListViewSettingsRowDragDropOp::SKGSLScriptEdListViewSettingsRowDragDropOp(TSharedPtr<SKGSLScriptEdListViewSettingsRow> InRow)
{
	Row = InRow;
	if (InRow.IsValid())
	{
		InRow->SetIsDragDrop(true);

		DecoratorWidget = SNew(SBorder)
			.Padding(8)
			.BorderImage(FAppStyle::GetBrush("Graph.ConnectorFeedback.Border"))
			.Content()
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::Format(NSLOCTEXT("DataTableDragDrop", "PlaceRowHere", "Place Row {0} Here"), FText::AsNumber(InRow->GetCurrentIndex())))
				]
			];

		FDecoratedDragDropOp::Construct();
	}
}

void SKGSLScriptEdListViewSettingsRowDragDropOp::OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent)
{
	FDecoratedDragDropOp::OnDrop(bDropWasHandled, MouseEvent);
	if (Row.IsValid())
	{
		Row.Pin()->SetIsDragDrop(false);
	}
}

//
// SKGSLScriptEdListViewSettingsRowHandle
//

void SKGSLScriptEdListViewSettingsRowHandle::Construct(const FArguments& InArgs)
{
	ParentRow = InArgs._ParentRow;

	ChildSlot
		[
			InArgs._Content.Widget
		];
}

FReply SKGSLScriptEdListViewSettingsRowHandle::OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton))
	{
		TSharedPtr<FDragDropOperation> DragDropOp = CreateDragDropOperation(ParentRow.Pin());
		if (DragDropOp.IsValid())
		{
			return FReply::Handled().BeginDragDrop(DragDropOp.ToSharedRef());
		}
	}

	return FReply::Unhandled();
}

TSharedPtr<SKGSLScriptEdListViewSettingsRowDragDropOp> SKGSLScriptEdListViewSettingsRowHandle::CreateDragDropOperation(TSharedPtr<SKGSLScriptEdListViewSettingsRow> InRow)
{
	TSharedPtr<SKGSLScriptEdListViewSettingsRowDragDropOp> Operation = MakeShareable(new SKGSLScriptEdListViewSettingsRowDragDropOp(InRow));

	return Operation;
}

//
// SKGSLScriptEdListViewSettings
//

TSharedRef<ITableRow> SKGSLScriptEdListViewSettings::MakeRowWidget(FKGSLScriptEdListViewSettingsRowDataPtr InRowDataPtr, const TSharedRef<STableViewBase>& OwnerTable)
{
	return SNew(SKGSLScriptEdListViewSettingsRow, OwnerTable)
		.RowDataPtr(InRowDataPtr)
		.ViewSettings(SharedThis(this));
}

void SKGSLScriptEdListViewSettings::OnColumnOrderSortModeChanged(EColumnSortPriority::Type InArg, const FName& ColumnId, EColumnSortMode::Type 
InSortMode)
{
	SortMode = InSortMode;
	SortByColumn = ColumnId;

	if (InSortMode == EColumnSortMode::Ascending)
	{
		ColumnNames.Sort([](const FKGSLScriptEdListViewSettingsRowDataPtr& first,
							const FKGSLScriptEdListViewSettingsRowDataPtr& second)
		{
			return first->RowNum < second->RowNum;
		});
	}
	else if (InSortMode == EColumnSortMode::Descending)
	{
		ColumnNames.Sort([](const FKGSLScriptEdListViewSettingsRowDataPtr& first,
							const FKGSLScriptEdListViewSettingsRowDataPtr& second)
		{
			return first->RowNum > second->RowNum;
		});
	}

	CellsListView->RequestListRefresh();
}

EColumnSortMode::Type SKGSLScriptEdListViewSettings::GetSortMode(FName InColumnName) const
{
	if (SortByColumn != InColumnName)
	{
		return EColumnSortMode::None;
	}

	return SortMode;
}

void SKGSLScriptEdListViewSettings::Construct(const FArguments& InArgs)
{
	int32 Count = FMath::Min(InArgs._ColumnNames.Num(), InArgs._DisplayNames.Num());
	for (int32 Index = 0; Index < Count; ++Index)
	{
		FKGSLScriptEdListViewSettingsRowDataPtr Data = MakeShareable(new FKGSLScriptEdListViewSettingsRowData());
		Data->ColumnName = InArgs._ColumnNames[Index];
		Data->DisplayName = InArgs._DisplayNames[Index];
		Data->RowNum = Index;
		ColumnNames.Emplace(Data);
	}
	
	ColumnNamesHeaderRow = SNew(SHeaderRow);
	ColumnNamesHeaderRow->ClearColumns();
	ColumnNamesHeaderRow->AddColumn(
		SHeaderRow::Column(SKGSLScriptEdListViewSettingsRow::RowDragDropColumnId)
		[
			SNew(SBox)
			.VAlign(VAlign_Fill)
			.HAlign(HAlign_Fill)
			[
				SNew(STextBlock).Text(FText::GetEmpty())
			]
		]);

	ColumnNamesHeaderRow->AddColumn(
		SHeaderRow::Column(SKGSLScriptEdListViewSettingsRow::RowNumberColumnId)
			.DefaultLabel(LOCTEXT("KGSLScriptEdListViewSettings", "Order"))
			.ManualWidth(100)
			.SortMode(this, &SKGSLScriptEdListViewSettings::GetSortMode, SKGSLScriptEdListViewSettingsRow::RowNumberColumnId)
			.OnSort(this, &SKGSLScriptEdListViewSettings::OnColumnOrderSortModeChanged)
		);
	
	ColumnNamesHeaderRow->AddColumn(
		SHeaderRow::Column(SKGSLScriptEdListViewSettingsRow::NameColumnId)
		.DefaultLabel(LOCTEXT("ScriptLineName", "Field Name"))
		.ManualWidth(300)
		.SortMode(EColumnSortMode::None)
	);
	
	CellsListView = SNew(SListView<FKGSLScriptEdListViewSettingsRowDataPtr>)
	.ListItemsSource(&ColumnNames)
	.HeaderRow(ColumnNamesHeaderRow)
	.OnGenerateRow(this, &SKGSLScriptEdListViewSettings::MakeRowWidget)
	.ConsumeMouseWheel(EConsumeMouseWheel::Always)
	.SelectionMode(ESelectionMode::Single)
	.AllowOverscroll(EAllowOverscroll::No);

	ChildSlot
	[
		SNew(SBorder)
		.Padding(2)
		.VAlign(VAlign_Fill)
		.HAlign(HAlign_Fill)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		[
			CellsListView.ToSharedRef()
		]
	];
}

void SKGSLScriptEdListViewSettings::SelectRow(int32 ColumnIndex)
{
}

void SKGSLScriptEdListViewSettings::MoveRow(int32 ColumnIndex, FDataTableEditorUtils::ERowMoveDirection InDirection, int32 InMoveCount)
{
	if (!ColumnNames.IsValidIndex(ColumnIndex))
	{
		return;
	}

	FKGSLScriptEdListViewSettingsRowDataPtr Data = ColumnNames[ColumnIndex];
	if (!Data.IsValid())
	{
		return;
	}

	int32 NewColumnIndex = INDEX_NONE;
	switch (InDirection)
	{
	case FDataTableEditorUtils::ERowMoveDirection::Up:
		NewColumnIndex = FMath::Clamp(ColumnIndex - InMoveCount, 0, ColumnNames.Num() - 1);
		break;

	case FDataTableEditorUtils::ERowMoveDirection::Down:
		NewColumnIndex = FMath::Clamp(ColumnIndex + InMoveCount, 0, ColumnNames.Num() - 1);
		break;

	default:
		break;
	}

	if (NewColumnIndex == INDEX_NONE || NewColumnIndex == ColumnIndex)
	{
		return;
	}
	
	ColumnNames.RemoveAt(ColumnIndex, 1, EAllowShrinking::No);
	ColumnNames.Insert(Data, NewColumnIndex);
	int32 Index = 0;
	for (auto& Column : ColumnNames)
	{
		if (Column.IsValid())
		{
			Column->RowNum = Index;
			++Index;
		}
	}

	if (CellsListView.IsValid())
	{
		CellsListView->RequestListRefresh();
	}
}

void SKGSLScriptEdListViewSettings::SetColumnDatas(const TArray<FString>& InColumnNames, const TArray<FString>& InDisplayNames)
{
	ColumnNames.Empty();
	int32 Count = FMath::Min(InColumnNames.Num(), InDisplayNames.Num());
	for (int32 Index = 0; Index < Count; ++Index)
	{
		FKGSLScriptEdListViewSettingsRowDataPtr Data = MakeShareable(new FKGSLScriptEdListViewSettingsRowData());
		Data->ColumnName = InColumnNames[Index];
		Data->DisplayName = InDisplayNames[Index];
		Data->RowNum = Index;
		ColumnNames.Emplace(Data);
	}

	if (CellsListView.IsValid())
	{
		CellsListView->RequestListRefresh();
	}
}

bool SKGSLScriptEdListViewSettings::GetColumnDatas(TArray<FString>& OutColumnNames) const
{
	for (const auto& Column : ColumnNames)
	{
		if (Column.IsValid())
		{
			OutColumnNames.Emplace(Column->ColumnName);
		}
	}

	return true;
}

#undef LOCTEXT_NAMESPACE
