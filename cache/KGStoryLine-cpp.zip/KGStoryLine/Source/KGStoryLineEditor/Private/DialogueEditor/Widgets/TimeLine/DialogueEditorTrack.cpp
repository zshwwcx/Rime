#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTrack.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Widgets/TimeLineBase/SAnimOutlinerItem.h"
#include "DialogueEditor/DialogueEditorUtilities.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueCameraTrackEditor.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueActorTrackEditor.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueActionTrackEditor.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueCameraCutTrackEditor.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorTrackOutliner.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineDragDropOp.h"
#include "Kismet/KismetMathLibrary.h"
#include "Misc/MessageDialog.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueRoutePointTrackEditor.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackTimeline.h"
#include "DialogueEditor/DialogueEditorPreviewSettings.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "Widgets/Layout/SSpacer.h"


#pragma optimize("",off)
#define LOCTEXT_NAMESPACE "DialogueEditorTrack"

ANIMTIMELINE_IMPLEMENT_TRACK(FDialogueEditorTrack);

const float FDialogueEditorTrack::NotificationTrackHeight = 38.0f;
const float FDialogueEditorTrack::SectionSnappingDeltaTime = 0.15f;

FDialogueEditorTrack::FDialogueEditorTrack(const TSharedRef<FDialogueEditorTimelineController>& InModel, const TWeakPtr<class FDialogueEditor>& InAssetEditor, UDialogueTrackBase* InTrack, const FText& InDisplayName, const FText& InToolTipText)
	: FAnimTimelineTrack(InModel, InDisplayName, InToolTipText, true), CachedTrack(InTrack), CachedEditor(InAssetEditor)
{
	SetHeight(30.0f);
}

TSharedRef<SWidget> FDialogueEditorTrack::GenerateContainerWidgetForTimeline()
{
	if (TrackEditor.IsValid())
	{
		return TrackEditor->GenerateContainerWidgetForTimeline();
	}
	return SNullWidget::NullWidget;
}

TArray<float> FDialogueEditorTrack::GetAssistLinePosX()
{
	TArray<float> ret;
	if (CachedTrack.IsValid() && TrackEditor.IsValid())
	{
		const UDialogueEditorPreviewSettings* DialogueEditorPreviewSettings = GetDefault<UDialogueEditorPreviewSettings>();
		const UDialogueEditorSettings* DialogueEditorSettings = GetDefault<UDialogueEditorSettings>();
		if(DialogueEditorSettings->AllSectionAssistLine || DialogueEditorSettings->NeedDrawAssistLineSections.Contains(CachedTrack->GetClass()))
		{
			//哪些轨道需要显示辅助线，可以配置
			TSharedRef<SWidget> TrackTimelineWidget = TrackEditor->GenerateContainerWidgetForTimeline();
			if (TrackTimelineWidget != SNullWidget::NullWidget)
			{
				TSharedPtr<SDialogueEditorActionTrackTimeline> TrackTimeline(StaticCastSharedPtr< SDialogueEditorActionTrackTimeline >(TrackTimelineWidget.ToSharedPtr()));

				const FTrackScaleInfo& TrackScaleInfo = TrackTimeline->GetCachedScaleInfo();
				const TArray<TSharedPtr<SDialogueEditorActionTrackNode>>& ActionNodes = TrackTimeline->GetActionNodes();

				int DragCurrentPosX = TimelineController.Pin()->GetDragSectionPosX();
				int NearestPosX = DragCurrentPosX;
				int MinDistance = INT_MAX;
				for (TSharedPtr<SDialogueEditorActionTrackNode> TrackNodeWidget : ActionNodes)
				{
					TWeakObjectPtr<class UDialogueActionBase> CachedSection = TrackNodeWidget->GetActionNodeData().CachedSection;
					if (CachedSection.IsValid())
					{
						int TempPosX = TrackNodeWidget->GetNotifyPosition().X;
						int TempEndPosX = TempPosX + TrackNodeWidget->GetDurationSize();

						//计算开头
						int TempDistance = UKismetMathLibrary::Abs(TempPosX - DragCurrentPosX);
						if (TempDistance < MinDistance)
						{
							NearestPosX = TempPosX;
							MinDistance = TempDistance;
						}
						//计算结尾
						TempDistance = UKismetMathLibrary::Abs(TempEndPosX - DragCurrentPosX);
						if (TempDistance < MinDistance)
						{
							NearestPosX = TempEndPosX;
							MinDistance = TempDistance;
						}

						if (DialogueEditorPreviewSettings->AssistLineShowStrategy != EAssistLineShowStrategy::DragShowNearest)
						{
							ret.Add(TempPosX);
							ret.Add(TempEndPosX);
						}
					}
				}
				if (DialogueEditorPreviewSettings->AssistLineShowStrategy == EAssistLineShowStrategy::DragShowNearest)
				{
					if (TrackScaleInfo.PixelsPerInput > 0)
					{
						// 只有当可吸附的时候，才显示辅助线
						float MinTimeDistance = MinDistance / TrackScaleInfo.PixelsPerInput;
						if (MinTimeDistance < SectionSnappingDeltaTime)
						{
							ret.Add(NearestPosX);
						}
					}
				}
			}
		}
	}

	
	return ret;
}

bool FDialogueEditorTrack::IsSectionBeDragged()
{
	if (TrackEditor.IsValid())
	{
		TSharedRef<SWidget> TrackTimelineWidget = TrackEditor->GenerateContainerWidgetForTimeline();
		if (TrackTimelineWidget != SNullWidget::NullWidget)
		{
			TSharedPtr<SDialogueEditorActionTrackTimeline> TrackTimeline(StaticCastSharedPtr< SDialogueEditorActionTrackTimeline >(TrackTimelineWidget.ToSharedPtr()));

			const TArray<TSharedPtr<SDialogueEditorActionTrackNode>>& ActionNodes = TrackTimeline->GetActionNodes();

			for (TSharedPtr<SDialogueEditorActionTrackNode> TrackNodeWidget : ActionNodes)
			{
				if (TrackNodeWidget->BeingDragged() || (TrackNodeWidget->GetActionNodeData().CachedSection.IsValid() && TrackNodeWidget->GetActionNodeData().CachedSection->IsAdjustingEdge()))
				{
					return true;
				}
			}
		}
	}


	return false;
}

void FDialogueEditorTrack::FillInnerHorizontalBox(TSharedPtr<SHorizontalBox> InnerHorizontalBox, TAttribute<FText> HighlightText)
{
	if (TrackEditor.IsValid())
	{
		// 在新布局下，尝试加入图标
		if (const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>())
		{
			if (EditorSettings->bNewLayout)
			{
				if (const FSlateBrush* Brush = TrackEditor->GetIconBrush())
				{
					InnerHorizontalBox->AddSlot()
					.VAlign(VAlign_Center)
					.HAlign(HAlign_Left)
					.Padding(2.0f, 1.0f)
					.AutoWidth()
					[
						SNew(SImage)
						.Image(Brush)
					];
				}
			}
		}
	}
	
	InnerHorizontalBox->AddSlot()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Left)
		.Padding(2.0f, 1.0f)
		.AutoWidth()
		[
			SNew(SInlineEditableTextBlock)
			.IsReadOnly(this, &FDialogueEditorTrack::IsTrackReadOnly)
			.Text(this, &FDialogueEditorTrack::GetName)
			.OnTextCommitted(this, &FDialogueEditorTrack::HandleNameCommitted)
			.HighlightText(HighlightText)
		];

	InnerHorizontalBox->AddSlot()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Left)
		.Padding(2.0f, 1.0f)
		.AutoWidth()
		[
			SNew(STextBlock)
			.Text(this, &FDialogueEditorTrack::GetTrackPreivewName)
			.HighlightText(HighlightText)
		];
		
	InnerHorizontalBox->AddSlot()
		.AutoWidth()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		.Padding(OutlinerRightPadding, 1.0f)
		[
			FDialogueEditorUtilities::MakeTrackButton
			(
				LOCTEXT("DialogueTrack", "Actions"),
				FOnGetContent::CreateSP(this, &FDialogueEditorTrack::BuildTrackSubMenu),
				MakeAttributeSP(this, &FDialogueEditorTrack::IsHovered)
			)
		];

	if (TrackEditor.IsValid())
	{
		TSharedPtr<SWidget> CustomWidget = TrackEditor->BuildOutlinerEditWidget();
		InnerHorizontalBox->AddSlot()
			.AutoWidth()
			.HAlign(HAlign_Right)
			.VAlign(VAlign_Center)
			.Padding(OutlinerRightPadding, 1.0f)
			[
				CustomWidget.ToSharedRef()
			];
	}
}

TSharedRef<SWidget> FDialogueEditorTrack::GenerateContainerWidgetForOutliner(const TSharedRef<SAnimOutlinerItem>& InRow)
{
	if (!CachedTrack.IsValid())
	{
		UE_LOG(LogTemp, Warning, TEXT("Invalid track:pending kill or destroyed"))
		return SNullWidget::NullWidget;
	}
	TSharedPtr<SBorder> OuterBorder;
	TSharedPtr<SHorizontalBox> InnerHorizontalBox;
	TSharedRef<SWidget> OutlinerWidget = GenerateStandardOutlinerWidget(InRow, false, OuterBorder, InnerHorizontalBox);
	BackgroundBorder = OuterBorder;
	SetIsSelect(bSelect);

	if (CachedTrack->GetType() == EDialogueTrack::Type::Camera)
	{
		TrackEditor = MakeShareable
		(
			new FDialogueCameraTrackEditor(TimelineController, CachedEditor, CachedTrack.Get())
		);
	}
	else if (CachedTrack->GetType() == EDialogueTrack::Type::Actor)
	{
		TrackEditor = MakeShareable
		(
			new FDialogueActorTrackEditor(TimelineController, CachedEditor, CachedTrack.Get())
		);
	}
	else if (CachedTrack->GetType() == EDialogueTrack::Type::RoutePoint)
	{
		TrackEditor = MakeShareable
		(
			new FDialogueRoutePointTrackEditor(TimelineController, CachedEditor, CachedTrack.Get())
		);
	}
	else if (CachedTrack->GetType() == EDialogueTrack::Type::CameraCut)
	{
		TrackEditor = MakeShareable
		(
			new FDialogueCameraCutTrackEditor(TimelineController, CachedEditor, CachedTrack.Get())
		);
	}
	else if(UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(CachedTrack))
	{
		//新的Entity，默认都是Actor子类，所以就用ActorTrackEditor
		TrackEditor = MakeShareable
		(
			new FDialogueActorTrackEditor(TimelineController, CachedEditor, CachedTrack.Get())
		);
	}
	else
	{
		TrackEditor = MakeShareable
		(
			new FDialogueActionTrackEditor(TimelineController, CachedEditor, CachedTrack.Get())
		);
	}
	
	FillInnerHorizontalBox(InnerHorizontalBox, InRow->GetHighlightText());

	TSharedRef<SWidget> TrackOutliner =
		SNew(SDialogueEditorTrackOutliner, GetEditorTimelineController(), CachedTrack.Get(), SharedThis(this))
		.TrackPanelArea(OuterBorder)
		.OutlineWidget(OutlinerWidget)
		.InlineEditableTextBlock
		(
			SNew(SInlineEditableTextBlock)
			.Text_Lambda([this]() {return DisplayName; })
			.IsSelected(FIsSelected::CreateLambda([]() { return true; }))
			.OnTextCommitted(this, &FDialogueEditorTrack::HandleNameCommitted)
		)
		.ExtraTextBlock
		(
			SNew(STextBlock)
			.Text(this, &FDialogueEditorTrack::GetTrackPreivewName)
			.HighlightText(InRow->GetHighlightText())
		);

	return TrackOutliner;
}

TSharedRef<SWidget> FDialogueEditorTrack::GenerateOnDragContainerWidgetForOutliner()
{
	TSharedPtr<SBorder> OuterBorder;
	TSharedPtr<SHorizontalBox> InnerHorizontalBox;
	TSharedRef<SWidget> OutlinerWidget = SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("Sequencer.Section.BackgroundTint"))
		.BorderBackgroundColor(FAppStyle::GetColor("AnimTimeline.Outliner.ItemColor"))
		[
			SAssignNew(InnerHorizontalBox, SHorizontalBox)
			+SHorizontalBox::Slot()
			.VAlign(VAlign_Center)
			.AutoWidth()
			.Padding(4.0f, 1.0f)
			[
				SNew(SSpacer)
				.Size(FVector2D(1, 30))
			]
		];
	
	FillInnerHorizontalBox(InnerHorizontalBox, FText());

	return OutlinerWidget;
}

bool FDialogueEditorTrack::SupportsSelection() const
{
	return true;
}

void FDialogueEditorTrack::AddToContextMenu(FMenuBuilder& InMenuBuilder, TSet<FName>& InOutExistingMenuTypes) const
{
	/*InMenuBuilder.BeginEpisode("Editor", LOCTEXT("NotifiesMenuEpisode", "Editor"));
	{
		AddTrackMenuEntry(InMenuBuilder);
	}
	InMenuBuilder.EndEpisode();*/
}

void FDialogueEditorTrack::AddTrackMenuEntry(FMenuBuilder& InMenuBuilder)const
{
	if (TrackEditor.IsValid())
	{
		TrackEditor->BuildOutlinerTrackActions(InMenuBuilder);
	}
}

TSharedRef<SWidget> FDialogueEditorTrack::BuildTrackSubMenu()
{
	FMenuBuilder MenuBuilder(true, nullptr);

	MenuBuilder.BeginSection("Track Actions", LOCTEXT("NotifiesMenuSection", "Tracks"));
	{
		AddTrackMenuEntry(MenuBuilder);
	}
	MenuBuilder.EndSection();


	return MenuBuilder.MakeWidget();
}

void FDialogueEditorTrack::RemoveTrack() const
{
	if (FDialogueEditorTimelineController* DialogueEditorController = StaticCast<FDialogueEditorTimelineController*>(TimelineController.Pin().Get()))
	{
		DialogueEditorController->RemoveTrack(CachedTrack.Get());
	}
}

UObject* FDialogueEditorTrack::GetCachedTrack()
{
	return CachedTrack.Get();
}

TSharedPtr<class FDialogueTrackEditor> FDialogueEditorTrack::GetTrackEditor()
{
	return TrackEditor;
}

TOptional<EItemDropZone> FDialogueEditorTrack::OnCanAcceptDrop(const FDragDropEvent& DragDropEvent, EItemDropZone InItemDropZone, TSharedRef<FAnimTimelineTrack> InItem)
{
	return InItemDropZone;
}

FReply FDialogueEditorTrack::OnAcceptDrop(const FDragDropEvent& DragDropEvent, EItemDropZone DropZone, TSharedRef<FAnimTimelineTrack> TargetItem)
{
	TSharedPtr<FDragDropOperation> Operation = DragDropEvent.GetOperation();
	const auto& FrameDragDropOp = StaticCastSharedPtr<FDialogueEditorTrackDragDropOp>(Operation);
	FrameDragDropOp->ChangeTrackPosition(CachedTrack.Get(), DropZone);
	return FReply::Handled();
}

FText FDialogueEditorTrack::GetName() const
{
	if (!CachedTrack.IsValid())
	{
		return FText::FromString(TEXT("Invalid track:pending kill or destroyed"));
	}

	if (CachedTrack->IsA(UDialogueSpawnableTrack::StaticClass()))
	{
		return CachedTrack->GetTrackName();	
	}
	else
	{
		return FText::FromString(CachedTrack->GetClass()->GetMetaData("DisplayName"));
	}
}

FText FDialogueEditorTrack::GetTrackPreivewName() const
{
	FString RetName = CachedTrack->GetEditorPreviewName();
	if (RetName.IsEmpty())
	{
		return FText();
	}
	return FText::FromString(FString::Printf(TEXT("(%s)"), *CachedTrack->GetEditorPreviewName()));
}

void FDialogueEditorTrack::HandleNameCommitted(const FText& NewText, ETextCommit::Type CommitInfo)
{
	if (NewText.ToString() == "")
		return;
	FText OldName = CachedTrack->GetTrackName();
	if (OldName.EqualTo(NewText))
		return;

	UDialogueBaseAsset* DialogueBaseAsset = CachedEditor.Pin()->GetEditingAsset();

	if (DialogueBaseAsset->IsNewTrackNameValid(NewText.ToString()))
	{
		DialogueBaseAsset->RenameTrackName(OldName.ToString(), NewText.ToString());

		if (FDialogueEditorTimelineController* DialogueEditorController = StaticCast<FDialogueEditorTimelineController*>(TimelineController.Pin().Get()))
		{
			DialogueEditorController->OnTrackNameChanged();
		}
	}
	else
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("不允许重名！")));
	}
}

bool FDialogueEditorTrack::IsTrackReadOnly() const
{
	if (TrackEditor.IsValid())
	{
		return TrackEditor->IsTrackReadOnly();
	}
	return false;
}


void FDialogueEditorTrack::SetIsSelect(bool InSelect)
{
	this->bSelect = InSelect;
	if (BackgroundBorder.IsValid())
	{
		if (InSelect)
			BackgroundBorder.Pin()->SetBorderBackgroundColor(FLinearColor(0.5f, 0.5f, 0.0f, 0.5f));
		else
			BackgroundBorder.Pin()->SetBorderBackgroundColor(FAppStyle::GetColor("AnimTimeline.Outliner.HeaderColor"));
	}
}

#undef LOCTEXT_NAMESPACE

#pragma optimize("",on)
