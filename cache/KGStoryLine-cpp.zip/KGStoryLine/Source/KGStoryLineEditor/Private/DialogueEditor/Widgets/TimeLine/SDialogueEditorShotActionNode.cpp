#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorShotActionNode.h"

#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTrack.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackTimeline.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Dialogue/Actions/DialogueShotAction.h"
#include "DialogueEditor/DialogueEditor.h"


FString SDialogueEditorShotActionNode::TargetCameraPropertyName = TEXT("TargetCamera");

int32 SDialogueEditorShotSmoothActionNode::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	if (!CachedPreAction.IsValid())
	{
		return LayerId;
	}
	const FSlateBrush* BorderBrush = FAppStyle::GetBrush(TEXT("SpecialEditableTextImageNormal"));
	FLinearColor BorderTint = FLinearColor(FColor(0, 130, 130));
	FSlateDrawElement::MakeBox(OutDrawElements, LayerId++, AllottedGeometry.ToPaintGeometry(FVector2d(WidgetSize.X, SDialogueEditorActionTrackKeyFrameNode::KeySizePx.Y), FSlateLayoutTransform(FVector2d(0, 4))), BorderBrush, ESlateDrawEffect::None, BorderTint);
	return LayerId;
}

void SDialogueEditorShotSmoothActionNode::UpdateSizeAndPosition(const FGeometry& AllottedGeometry)
{
	if (const UDialogueShotAction* CameraCut = Cast<UDialogueShotAction>(ActionNodeData.CachedSection))
	{
		CachedPreAction = GetPreCameraCutAction();
		if (CachedPreAction.IsValid())
		{
			float SmoothTime;
			float StartTime;
			if (UDialogueShotAction* PreShot = Cast<UDialogueShotAction>(CachedPreAction))
			{
				StartTime = PreShot->StartTime + PreShot->Duration;
				SmoothTime = CameraCut->StartTime - StartTime;
			}
			else
			{
				StartTime = CachedPreAction->StartTime;
				SmoothTime = CameraCut->StartTime - CachedPreAction->StartTime;
			}
			
			const FTrackScaleInfo ScaleInfo(ViewInputMin.Get(), ViewInputMax.Get(), 0, 0, AllottedGeometry.Size);
			WidgetX = ScaleInfo.InputToLocalX(StartTime);
			WidgetSize.X = ScaleInfo.PixelsPerInput * SmoothTime;
		}
	}
}

FMargin SDialogueEditorShotSmoothActionNode::GetNotifyTrackPadding()
{
	return SDialogueEditorActionTrackNode::GetNotifyTrackPadding();
}

FReply SDialogueEditorShotSmoothActionNode::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	return FReply::Unhandled();
}

FReply SDialogueEditorShotSmoothActionNode::OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	return FReply::Unhandled();
}

FReply SDialogueEditorShotSmoothActionNode::OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	return FReply::Unhandled();
}

FReply SDialogueEditorShotSmoothActionNode::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	return FReply::Unhandled();
}

FText SDialogueEditorShotSmoothActionNode::GetNodeTooltip() const
{
	return FText::FromString("");
}

UDialogueActionBase* SDialogueEditorShotSmoothActionNode::GetPreCameraCutAction()
{
	if (UDialogueShotAction* CameraCut = Cast<UDialogueShotAction>(ActionNodeData.CachedSection))
	{
		TArray<UDialogueActionBase*> OrderedActions = CameraCut->GetDialogueAction()->GetOrderedSections();
		int32 Index = OrderedActions.Find(CameraCut);
		if (Index > 0)
		{
			return OrderedActions[Index - 1];
		}
	}
	return nullptr;
}

SDialogueEditorShotActionNode::~SDialogueEditorShotActionNode()
{
	if (ActionNodeData.CachedSection.IsValid())
	{
		if (UDialogueShotAction* CameraCut = Cast<UDialogueShotAction>(ActionNodeData.CachedSection))
		{
			if (CameraCut->OnDialogueShotSwitchTypeChangedEvent.IsBoundToObject(this))
			{
				CameraCut->OnDialogueShotSwitchTypeChangedEvent.Unbind();
			}
		}
	}
}

void SDialogueEditorShotActionNode::Construct(const FArguments& InArgs, TSharedRef<SDialogueEditorActionTrackTimeline> InTimeline)
{
	SDialogueEditorActionTrackKeyFrameNode::Construct(InArgs);
	CachedTimeline = InTimeline;
	if (ActionNodeData.CachedSection.IsValid())
	{
		if (UDialogueShotAction* CameraCut = Cast<UDialogueShotAction>(ActionNodeData.CachedSection))
		{
			CameraCut->OnDialogueShotSwitchTypeChangedEvent.BindRaw(this, &SDialogueEditorShotActionNode::OnDialogueCameraCutSwitchTypeChanged);
		}
	}
}

void SDialogueEditorShotActionNode::OnDialogueCameraCutSwitchTypeChanged()
{
	if (CachedTimeline.IsValid())
	{
		CachedTimeline.Pin()->UpdateLayout();
	}
}

bool SDialogueEditorShotActionNode::IsBreathNode() const
{
	if (ActionNodeData.CachedSection.IsValid())
	{
		if (const UDialogueShotAction* DialogueShotAction = Cast<UDialogueShotAction>(ActionNodeData.CachedSection))
		{
			if (DialogueShotAction->IsBreathShot())
			{
				return true;
			}
		}
	}
	return false;
}

FReply SDialogueEditorShotActionNode::OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	if (ActionNodeData.CachedSection.IsValid() && ActionNodeData.CachedEditor.IsValid())
	{
		if (UDialogueShotAction* DialogueShot = Cast<UDialogueShotAction>(ActionNodeData.CachedSection))
		{
			const FString CameraTrackName = DialogueShot->GetSectionName().ToString();
			FDialogueEditor* DialogueEditor = ActionNodeData.CachedEditor.Pin().Get();
			UDialogueAsset* DialogueAsset = DialogueEditor->GetDialogueAsset();
			const int32 CurrentEpisodeID = DialogueEditor->GetCurrentEpisodeID();
			if (UDialogueCameraTrack* CameraTrack = Cast<UDialogueCameraTrack>(DialogueAsset->FindEpisodeTrackByName(CurrentEpisodeID, FName(CameraTrackName))))
			{
				DialogueEditor->OnLockCameraClicked(Cast<UDialogueCamera>(CameraTrack->GetDialogueEntity()), false);
			}
		}
	}
	return SDialogueEditorActionTrackKeyFrameNode::OnMouseButtonDoubleClick(InMyGeometry, InMouseEvent);
}

int32 SDialogueEditorShotActionNode::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	if (ActionNodeData.CachedSection.IsValid())
	{
		if (const UDialogueShotAction* CameraCut = Cast<UDialogueShotAction>(ActionNodeData.CachedSection))
		{
			if (CameraCut->IsBreathShot())
			{
				LayerId++;
				const FSlateBrush* BorderBrush = FAppStyle::GetBrush(TEXT("SpecialEditableTextImageNormal"));
				FLinearColor BorderTint = FLinearColor(FColor(164, 120, 100));
				FSlateDrawElement::MakeBox(OutDrawElements, LayerId++, AllottedGeometry.ToPaintGeometry(FVector2d(BreathLocalSizeX, KeySizePx.Y), FSlateLayoutTransform(FVector2d(HalfKeySize, KeyPositionOffsetY))), BorderBrush, ESlateDrawEffect::None, BorderTint);
			}
		}
	}
	
	return SDialogueEditorActionTrackKeyFrameNode::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
}

void SDialogueEditorShotActionNode::UpdateSizeAndPosition(const FGeometry& AllottedGeometry)
{
	SDialogueEditorActionTrackKeyFrameNode::UpdateSizeAndPosition(AllottedGeometry);
	if (ActionNodeData.CachedSection.IsValid())
	{
		if (const UDialogueShotAction* CameraCut = Cast<UDialogueShotAction>(ActionNodeData.CachedSection))
		{
			if (CameraCut->IsBreathShot())
			{
				const FTrackScaleInfo ScaleInfo(ViewInputMin.Get(), ViewInputMax.Get(), 0, 0, AllottedGeometry.Size);
				WidgetX = ScaleInfo.InputToLocalX(ActionNodeData.GetEditorStartTime());
				BreathLocalSizeX = ScaleInfo.PixelsPerInput * ActionNodeData.GetEditorDuration();
				WidgetSize.X = FMath::Max(BreathLocalSizeX + HalfKeySize, KeySizePx.X);
			}
		}
	}
}

FReply SDialogueEditorShotActionNode::OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (IsBreathNode())
	{
		return SDialogueEditorActionTrackNode::OnDragDetected(MyGeometry, MouseEvent);
	}
	return SDialogueEditorActionTrackKeyFrameNode::OnDragDetected(MyGeometry, MouseEvent);
}

ENotifyStateHandleHit::Type SDialogueEditorShotActionNode::DurationHandleHitTest(const FVector2D& CursorScreenPosition) const
{
	if (IsBreathNode())
	{
		ENotifyStateHandleHit::Type MarkerHit = ENotifyStateHandleHit::None;

		// 计算点击位置与ActionNode的相对位置，来判断能否对Task产生影响，以及产生什么影响
		if (NotifyDurationSizeX > 0.0f)
		{
			float ScrubHandleHalfWidth = 6.f;

			FVector2D NotifyNodePosition( - HalfKeySize, 0.0f);
			FVector2D NotifyNodeSize(NotifyDurationSizeX + HalfKeySize, FDialogueEditorTrack::NotificationTrackHeight);

			FVector2D MouseRelativePosition(CursorScreenPosition - GetWidgetPosition());

			if (MouseRelativePosition.ComponentwiseAllGreaterThan(NotifyNodePosition) && MouseRelativePosition.ComponentwiseAllLessThan(NotifyNodePosition + NotifyNodeSize))
			{
				// 该次拖动想要修改开始时间
				if (MouseRelativePosition.X <= (NotifyNodePosition.X + ScrubHandleHalfWidth))
				{
					MarkerHit = ENotifyStateHandleHit::Start;
				}
				// 该次拖动想要修改时长
				else if (MouseRelativePosition.X >= (NotifyNodePosition.X + NotifyNodeSize.X - ScrubHandleHalfWidth))
				{
					MarkerHit = ENotifyStateHandleHit::End;
				}
			}
		}

		return MarkerHit;
	}
	return SDialogueEditorActionTrackKeyFrameNode::DurationHandleHitTest(CursorScreenPosition);
}

FCursorReply SDialogueEditorShotActionNode::OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const
{
	if (IsBreathNode())
	{
		if (IsHovered() && GetDurationSize() > 0.0f)
		{
			FVector2D RelMouseLocation = MyGeometry.AbsoluteToLocal(CursorEvent.GetScreenSpacePosition());

			constexpr float HandleHalfWidth = 6.f;
			const float DistFromFirstHandle = FMath::Abs(RelMouseLocation.X);
			const float DistFromSecondHandle = FMath::Abs(RelMouseLocation.X - NotifyDurationSizeX - HalfKeySize);

			if (DistFromFirstHandle < HandleHalfWidth || DistFromSecondHandle < HandleHalfWidth || CurrentDragHandle != ENotifyStateHandleHit::None)
			{
				return FCursorReply::Cursor(EMouseCursor::ResizeLeftRight);
			}
		}
		return FCursorReply::Unhandled();
	}
	return SDialogueEditorActionTrackKeyFrameNode::OnCursorQuery(MyGeometry, CursorEvent);
}

FReply SDialogueEditorShotActionNode::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FReply Result = SDialogueEditorActionTrackKeyFrameNode::OnMouseButtonUp(MyGeometry, MouseEvent);
	if (IsBreathNode())
	{
		if (UDialogueShotAction* DialogueShotAction = Cast<UDialogueShotAction>(ActionNodeData.CachedSection))
		{
			DialogueShotAction->UpdateDurationToBreathTime();
		}
	}
	return Result;
}
