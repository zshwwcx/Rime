#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueActionTrackEditor.h"

#include "DialogueEditor/Dialogue/Actions/DialogueAutoCameraCut.h"
#include "Widgets/Input/SCheckBox.h"
#include "LevelEditorViewport.h"
#include "Widgets/TimeLineBase/TimelineController.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackTimeline.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackNode.h"
#include "ScopedTransaction.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/DialogueEditorManager.h"

#define LOCTEXT_NAMESPACE "DialogueActionTrackEditor"


void FDialogueActionTrackEditor::BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder)
{
	InMenuBuilder.AddMenuEntry
	(
		LOCTEXT("Action_Section_Lable", "Section"),
		LOCTEXT("Action_Section_Tooltip", "Section"),
		FSlateIcon(),
		FUIAction
		(
			FExecuteAction::CreateSP(this, &FDialogueActionTrackEditor::AddSection, 0.0f)
		),
		NAME_None,
		EUserInterfaceActionType::Button
	);
}

void FDialogueActionTrackEditor::AddSection(float StartTime)
{
	CreateSection(StartTime);
}

void FDialogueActionTrackEditor::AddNewSecondTypeSection(float StartTime)
{
	CreateSection(StartTime, true);
}

void FDialogueActionTrackEditor::AddCameraSectionAtViewPosition(float StartTime)
{
	UWorld* World = GCurrentLevelEditingViewportClient ? GCurrentLevelEditingViewportClient->GetWorld() : nullptr;
	if (!World)
	{
		return;
	}
	if (!CachedEditor.IsValid())
	{
		return;
	}
    
    const FVector& Location = GCurrentLevelEditingViewportClient->GetViewLocation();
    const FRotator& Rotation = GCurrentLevelEditingViewportClient->GetViewRotation();
    
    UDialogueEntity* DialogueEntity = CachedEditor.Pin()->DialogueTimelineController.Pin()->AddNewTrack(UDialogueCameraTrack::StaticClass(), "", Location, Rotation, false);
	UDialogueActionBase* CameraSection = CreateSection(StartTime);
    float FOV = GCurrentLevelEditingViewportClient->ViewFOV;
	CachedEditor.Pin()->GetDialogueEditorManager()->SetViewPositionCameraParams(DialogueEntity, CameraSection, Location, Rotation, FOV);
}


TSharedPtr<class SDialogueEditorActionTrackTimeline> FDialogueActionTrackEditor::GetTrackWidget()
{
	return TrackWidget;
}

UDialogueActionBase* FDialogueActionTrackEditor::CreateSection(float StartTime, bool bSecondType)
{
	if (!CachedEditor.IsValid())
	{
		return nullptr;
	}
	
	UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	UDialogueActionBase* NewActionSection = nullptr;
	UDialogueActionTrack* CachedAction = Cast<UDialogueActionTrack>(CachedTrack);
	if (CachedAction && CachedAction->SectionType)
	{
		float NewSectionDuration = GetDefault<UDialogueActionBase>(CachedAction->SectionType)->Duration;
		//检测要新加的Section是否会和后续Section重叠，如果重叠，则缩短Duration
		TArray<UDialogueActionBase*> AllSections = CachedAction->ActionSections;
		//对AllSection进行时间从小到大的排序，方便后续迭代
		Algo::Sort(AllSections, [](UDialogueActionBase* A, UDialogueActionBase* B)
			{
				return A->StartTime < B->StartTime;
			});
		for (UDialogueActionBase* DialogueActionSection : AllSections)
		{
			if (DialogueActionSection->StartTime > StartTime)
			{//找到新加Section后面的Section了
				if (DialogueActionSection->StartTime - StartTime < NewSectionDuration)
				{
					NewSectionDuration = DialogueActionSection->StartTime - StartTime;
					UE_LOG(LogTemp, Log, TEXT("NewSection Duration is too long, need adjust, new duration is %.2f"), NewSectionDuration);
				}
				break;
			}
		}

		FString ScopeText = FString::Printf(TEXT("Dialogue AddSection, Track %s"), *(CachedTrack->GetTrackName().ToString()));
		CachedTrack->SetFlags(EObjectFlags::RF_Transactional);
		FScopedTransaction Transaction(FText::FromString(ScopeText));
		CachedTrack->Modify();
		int32 EpisodeID = Asset->IsA(UDialogueAsset::StaticClass())
			                  ? Cast<UDialogueAsset>(Asset)->GetCurrentSelectEpisodeID()
			                  : 0;
		if (bSecondType)
		{
			NewActionSection = Asset->AddSecondTypeSection(EpisodeID, CachedAction);
		}
		else
		{
			NewActionSection = Asset->AddSection(EpisodeID, CachedAction);
		}
		NewActionSection->StartTime = StartTime;
		NewActionSection->Duration = NewSectionDuration;
		if(UDialogueAutoCameraCut* AutoCameraCut = Cast<UDialogueAutoCameraCut>(NewActionSection))
		{
			AutoCameraCut->CameraName = "AutoCamera";	
		}
		
		TimelineController.Pin()->RefreshTracks();

		CachedEditor.Pin()->GetEditorContextMgr().OnActionSectionAdded(CachedEditor.Pin()->GetDialogueAsset(), NewActionSection);
		CachedEditor.Pin()->GetDialogueEditorManager()->OnSectionChange_AddSection(CachedEditor.Pin()->GetDialogueAsset(), NewActionSection);

		CachedEditor.Pin()->GetDialogueEditorManager()->OnAssetPostEdit(Asset);
	}

	return NewActionSection;
}

TSharedRef<SWidget> FDialogueActionTrackEditor::GenerateContainerWidgetForTimeline()
{
	if (!TrackWidget.IsValid())
	{
		UDialogueActionTrack* CachedAction = Cast<UDialogueActionTrack>(CachedTrack);
		TrackWidget =
			SNew(SDialogueEditorActionTrackTimeline)
			.CachedEditor(CachedEditor.Pin())
			.Task(CachedAction)
			.InputMin(this, &FDialogueActionTrackEditor::GetMinInput)
			.InputMax(this, &FDialogueActionTrackEditor::GetMaxInput)
			.ViewInputMin(this, &FDialogueActionTrackEditor::GetViewMinInput)
			.ViewInputMax(this, &FDialogueActionTrackEditor::GetViewMaxInput)
			.TimelinePlayLength(TimelineController.Pin()->GetPlayLength())
			.FrameRate(TimelineController.Pin()->GetFrameRate())
			.OnSetInputViewRange(this, &FDialogueActionTrackEditor::InputViewRangeChanged)
			.OnSelectActionSection(this, &FDialogueActionTrackEditor::OnSelectActionSection)
			.OnDeleteSection(this, &FDialogueActionTrackEditor::RemoveSelectedSection)
			.OnAddNewSection(this, &FDialogueActionTrackEditor::AddSection)
			.OnAddNewSecondTypeSection(this, &FDialogueActionTrackEditor::AddNewSecondTypeSection)
			.OnAddCameraSectionAtViewPosition(this, &FDialogueActionTrackEditor::AddCameraSectionAtViewPosition);
	}

	return TrackWidget.ToSharedRef();
}

float FDialogueActionTrackEditor::GetMaxInput() const
{
	return TimelineController.Pin()->GetPlayLength();
}

float FDialogueActionTrackEditor::GetViewMinInput() const
{
	return TimelineController.Pin()->GetViewRange().GetLowerBoundValue();
}
float FDialogueActionTrackEditor::GetViewMaxInput() const
{
	return TimelineController.Pin()->GetViewRange().GetUpperBoundValue();
}

void FDialogueActionTrackEditor::OnSetInputViewRange(float ViewMin, float ViewMax)
{

}

void FDialogueActionTrackEditor::InputViewRangeChanged(float ViewMin, float ViewMax)
{

}

void FDialogueActionTrackEditor::OnSelectActionSection(UDialogueActionBase* Section)
{
	CachedEditor.Pin()->SetSectionSelected(Section);
}
void FDialogueActionTrackEditor::OnSelectSectionChange(TArray<TWeakObjectPtr<UDialogueActionBase>> CurrentSelects)
{
	CopyNode.Empty();
}

void FDialogueActionTrackEditor::RemoveSelectedSection(TSharedRef<SDialogueEditorActionTrackNode> NotifyNode, bool NeedRefreshTrack)
{
	/*FString ScopeText = FString::Printf(TEXT("Dialogue RemoveSection, Track %s"), *(CachedTrack->GetTrackName().ToString()));
	FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);*/

	CachedTrack->SetFlags(EObjectFlags::RF_Transactional);
	CachedTrack->Modify();

	UDialogueActionBase* Section = NotifyNode->GetActionNodeData().GetAction();
	UDialogueActionTrack* CachedAction = Cast<UDialogueActionTrack>(CachedTrack);

	CachedAction->RemoveSection(Section);



	UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	CachedEditor.Pin()->GetDialogueEditorManager()->OnAssetPostEdit(Asset);
	CachedEditor.Pin()->GetDialogueEditorManager()->OnSectionChange_DeleteSection(CachedEditor.Pin()->GetDialogueAsset(), Section);
	if(NeedRefreshTrack)
		TimelineController.Pin()->RefreshTracks();
}

void FDialogueActionTrackEditor::OnCopySection(TSharedPtr<class SDialogueEditorActionTrackNode> Node)
{
	CopyNode.Add(Node);
}

void FDialogueActionTrackEditor::OnPasteSection()
{
	TSharedPtr<SDialogueEditorActionTrackNode> LastNode =  CopyNode.Num() > 0? CopyNode[ CopyNode.Num()-1]:nullptr;
	float CurrentStartTime = LastNode? LastNode.Get()->GetActionNodeData().GetStartTime() + LastNode.Get()->GetActionNodeData().GetDuration():0;
	for (auto Node : CopyNode)
	{
		UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
		UDialogueActionBase* NewActionSection = nullptr;
		UDialogueActionTrack* CachedAction = Cast<UDialogueActionTrack>(CachedTrack);
		if (CachedAction && CachedAction->SectionType)
		{
			float NewSectionDuration = Node->GetActionNodeData().GetDuration();
			//检测要新加的Section是否会和后续Section重叠，如果重叠，则缩短Duration
			TArray<UDialogueActionBase*> AllSections = CachedAction->ActionSections;
			//对AllSection进行时间从小到大的排序，方便后续迭代
			Algo::Sort(AllSections, [](UDialogueActionBase* A, UDialogueActionBase* B)
				{
					return A->StartTime < B->StartTime;
				});

			for (UDialogueActionBase* DialogueActionSection : AllSections)
			{
				if (DialogueActionSection->StartTime > CurrentStartTime)
				{//找到新加Section后面的Section了
					if (DialogueActionSection->StartTime - CurrentStartTime < NewSectionDuration)
					{
						NewSectionDuration = DialogueActionSection->StartTime - CurrentStartTime;
						UE_LOG(LogTemp, Log, TEXT("NewSection Duration is too long, need adjust, new duration is %.2f"), NewSectionDuration);
					}
					break;
				}
			}
			

			//FString ScopeText = FString::Printf(TEXT("Dialogue AddSection, Track %s"), *(CachedTrack->GetTrackName().ToString()));
			CachedTrack->SetFlags(EObjectFlags::RF_Transactional);
			//FScopedTransaction Transaction(FText::FromString(ScopeText));
			CachedTrack->Modify();
			NewActionSection = Asset->CopySection(0, Node->GetActionNodeData().GetAction(),CachedAction);
			NewActionSection->StartTime = CurrentStartTime;
			NewActionSection->Duration = NewSectionDuration;
			
		}
		CurrentStartTime += Node.Get()->GetActionNodeData().GetDuration();
	}
	TimelineController.Pin()->RefreshTracks();
}

#undef LOCTEXT_NAMESPACE