#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueCameraTrackEditor.h"
#include "DialogueEditor/Dialogue/DialogueCameraTrack.h"
#include "Widgets/Input/SCheckBox.h"
#include "LevelEditorViewport.h"
#include "Widgets/TimeLineBase/TimelineController.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "KGSLEditorStyle.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "Camera/CameraActor.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "Widgets/Images/SImage.h"

#define LOCTEXT_NAMESPACE "DialogueCameraTrackEditor"


void FDialogueCameraTrackEditor::BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder)
{
	UDialogueEditorSettings* DialogueSettings = GetMutableDefault<UDialogueEditorSettings>();
	for (TSubclassOf<UDialogueActionTrack> CameraSubTrackCls : DialogueSettings->CameraSubTracks)
	{
		InMenuBuilder.AddMenuEntry
		(
			CameraSubTrackCls->GetDisplayNameText(),
			FText::FromString(CameraSubTrackCls->GetDescription()),
			FSlateIcon(),
			FUIAction
			(
				FExecuteAction::CreateSP(this, &FDialogueCameraTrackEditor::AddCameraSubTrack, CameraSubTrackCls)
			),
			NAME_None,
			EUserInterfaceActionType::Button
		);
	}
}

TSharedPtr<SWidget> FDialogueCameraTrackEditor::BuildOutlinerEditWidget()
{
	const FSlateBrush* FocusImage   = FAppStyle::GetBrush("Kismet.VariableList.ExposeForInstance");
	const FSlateBrush* UnFocusImage = FAppStyle::GetBrush("Kismet.VariableList.HideForInstance");
	return SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.HAlign(HAlign_Fill)
		.AutoWidth()
		.Padding(FMargin(3))
		[
			SNew(SImage)
			.Image(FAppStyle::GetBrush("ClassIcon.SplineComponent"))
			.Visibility(this, &FDialogueCameraTrackEditor::GetCameraCurveVisible)
		] 

	+ SHorizontalBox::Slot()
		.HAlign(HAlign_Fill)
		.AutoWidth()
		.Padding(FMargin(3))
		[
			SNew(SCheckBox)
			.Style(&FAppStyle::Get().GetWidgetStyle<FCheckBoxStyle>("ToggleButtonCheckBoxAlt"))
		.Type(ESlateCheckBoxType::CheckBox)
		.Padding(FMargin(0.f))
		.IsFocusable(false)
		.IsChecked(this, &FDialogueCameraTrackEditor::IsCameraFocus)
		.OnCheckStateChanged(this, &FDialogueCameraTrackEditor::OnFocusCameraClicked)
		.ToolTipText(this, &FDialogueCameraTrackEditor::GetFocusCameraToolTip)
		.CheckedImage(FocusImage)
		.CheckedHoveredImage(FocusImage)
		.CheckedPressedImage(FocusImage)
		.UncheckedImage(UnFocusImage)
		.UncheckedHoveredImage(UnFocusImage)
		.UncheckedPressedImage(UnFocusImage)
		]


		+ SHorizontalBox::Slot()
		.HAlign(HAlign_Fill)
		.AutoWidth()
		.Padding(FMargin(3))
		[
			SNew(SCheckBox)
			.Style(&FAppStyle::Get().GetWidgetStyle<FCheckBoxStyle>("ToggleButtonCheckBoxAlt"))
			.Type(ESlateCheckBoxType::CheckBox)
			.Padding(FMargin(0.f))
			.IsFocusable(false)
			.IsChecked(this, &FDialogueCameraTrackEditor::IsCameraLocked)
			.OnCheckStateChanged(this, &FDialogueCameraTrackEditor::OnLockCameraClicked)
			.ToolTipText(this, &FDialogueCameraTrackEditor::GetLockCameraToolTip)
			.CheckedImage(FAppStyle::GetBrush("Sequencer.LockCamera"))
			.CheckedHoveredImage(FAppStyle::GetBrush("Sequencer.LockCamera"))
			.CheckedPressedImage(FAppStyle::GetBrush("Sequencer.LockCamera"))
			.UncheckedImage(FAppStyle::GetBrush("Sequencer.UnlockCamera"))
			.UncheckedHoveredImage(FAppStyle::GetBrush("Sequencer.UnlockCamera"))
			.UncheckedPressedImage(FAppStyle::GetBrush("Sequencer.UnlockCamera"))
		]
	 ;
}

const FSlateBrush* FDialogueCameraTrackEditor::GetIconBrush() const
{
	return FKGSLEditorStyle::Get().GetBrush("KGSL.Tracks.CameraActor");
}

void FDialogueCameraTrackEditor::AddTransformTrack()
{

}


void FDialogueCameraTrackEditor::OnLockCameraClicked(ECheckBoxState CheckBoxState)
{
	LockCameraBinding(CheckBoxState == ECheckBoxState::Checked);
}

void FDialogueCameraTrackEditor::OnFocusCameraClicked(ECheckBoxState CheckBoxState)
{
	UDialogueCameraTrack* TrackCamera = Cast<UDialogueCameraTrack>(CachedTrack);
	if (TrackCamera == nullptr || TrackCamera->GetDialogueEntity() == nullptr)
		return;

	AActor* CameraActor = CachedEditor.Pin()->GetDialogueEditorManager()->GetEntityActor(TrackCamera->GetDialogueEntity()->TrackName);
	FDialogueEditorTimelineController* DialogueEditorController = StaticCast<FDialogueEditorTimelineController*>(TimelineController.Pin().Get());
	if (CheckBoxState == ECheckBoxState::Checked)
	{
		CachedEditor.Pin()->SetFocusCamera(CameraActor);
	}
	else
	{
		CachedEditor.Pin()->SetFocusCamera(nullptr);
	}
}

void FDialogueCameraTrackEditor::LockCameraBinding(bool bLock)
{
	UDialogueCameraTrack* TrackCamera = Cast<UDialogueCameraTrack>(CachedTrack);
	if(TrackCamera==nullptr || TrackCamera->GetDialogueEntity()==nullptr)
		return;

	
	AActor* CameraActor = CachedEditor.Pin()->GetDialogueEditorManager()->GetEntityActor(TrackCamera->GetDialogueEntity()->TrackName);
	FDialogueEditorTimelineController* DialogueEditorController = StaticCast<FDialogueEditorTimelineController*>(TimelineController.Pin().Get());
	// Lock the active viewport to the camera
	if (bLock)
	{
		// Set the active viewport or any viewport if there is no active viewport
		DialogueEditorController->OnLockCameraClicked(Cast<UDialogueCamera>(TrackCamera->GetDialogueEntity()), TrackCamera->GetTrackName().ToString() ==("AutoCamera"));
	}
	// Otherwise, clear all locks on the camera
	else
	{
		ClearLockedCameras(CameraActor);
		DialogueEditorController->OnLockCameraClicked(nullptr);
	}
}

void FDialogueCameraTrackEditor::ClearLockedCameras(AActor* LockedActor)
{
	for (FLevelEditorViewportClient* LevelVC : GEditor->GetLevelViewportClients())
	{
		if (LevelVC && LevelVC->GetViewMode() != VMI_Unknown && LevelVC->AllowsCinematicControl())
		{
			if (LevelVC->IsActorLocked(LockedActor))
			{
				LevelVC->SetCinematicActorLock(nullptr);
				LevelVC->SetActorLock(nullptr);
				LevelVC->bLockedCameraView = false;
				LevelVC->ViewFOV = LevelVC->FOVAngle;
				LevelVC->RemoveCameraRoll();
				LevelVC->UpdateViewForLockedActor();
				LevelVC->Invalidate();
			}
		}
	}
}

ECheckBoxState FDialogueCameraTrackEditor::IsCameraLocked() const
{
	if (CachedTrack == nullptr)
		return ECheckBoxState::Unchecked;
	UDialogueEntity* DialogueEntity = (Cast<UDialogueCameraTrack>(CachedTrack))->GetDialogueEntity();
	if (DialogueEntity == nullptr)
		return ECheckBoxState::Unchecked;
	if (CachedEditor.Pin()->ClickCameraEntity.Get() == DialogueEntity)
	{
		return ECheckBoxState::Checked;
	}
	else
	{
		return ECheckBoxState::Unchecked;
	}
	return ECheckBoxState::Checked;
}

ECheckBoxState FDialogueCameraTrackEditor::IsCameraFocus() const
{
	if (CachedTrack == nullptr)
		return ECheckBoxState::Unchecked;
	UDialogueEntity* DialogueEntity = (Cast<UDialogueCameraTrack>(CachedTrack))->GetDialogueEntity();
	if (DialogueEntity == nullptr)
		return ECheckBoxState::Unchecked;
	if (CachedEditor.Pin()->GetFocusCamera() == CachedEditor.Pin()->GetDialogueEditorManager()->GetEntityActor(DialogueEntity->TrackName))
	{
		return ECheckBoxState::Checked;
	}
	return ECheckBoxState::Unchecked;
}

FText FDialogueCameraTrackEditor::GetFocusCameraToolTip() const
{
	FText Tooltip = IsCameraFocus() == ECheckBoxState::Checked ?
		LOCTEXT("CancelFocus", "Cancel Focus This Camera, All Camera Will be Show") :
		LOCTEXT("Focus", "Focus This Camera, Other Camera Will Be Hidden");

	return Tooltip;
}

FText FDialogueCameraTrackEditor::GetLockCameraToolTip() const
{
	//const TSharedRef<const FInputChord> FirstActiveChord = FCameraCutTrackCommands::Get().ToggleLockCamera->GetFirstValidChord();

	FText Tooltip = IsCameraLocked() == ECheckBoxState::Checked ?
		LOCTEXT("UnlockCamera", "Unlock Viewport from Camera Cuts") :
		LOCTEXT("LockCamera", "Lock Viewport to Camera Cuts");

	/*if (FirstActiveChord->IsValidChord())
	{
		return FText::Join(FText::FromString(TEXT(" ")), Tooltip, FirstActiveChord->GetInputText());
	}*/
	return Tooltip;
}

EVisibility FDialogueCameraTrackEditor::GetCameraCurveVisible() const
{
	EVisibility Empty = EVisibility::Collapsed;
	EVisibility Curve = EVisibility::SelfHitTestInvisible;
	if (CachedTrack == nullptr)
		return Empty;
	UDialogueEntity* DialogueEntity = (Cast<UDialogueCameraTrack>(CachedTrack))->GetDialogueEntity();
	if (DialogueEntity == nullptr)
		return Empty;
	UDialogueCamera* DialogueCamera = Cast<UDialogueCamera>(DialogueEntity);
	if (DialogueCamera == nullptr)
		return Empty;
	AActor* EntityActor = CachedEditor.Pin()->GetEntityActor(DialogueCamera);
	if (EntityActor == nullptr)
		return Empty;
	USplineComponent* SplineComponent = EntityActor->GetComponentByClass<USplineComponent>();
	if(SplineComponent == nullptr)
		return Empty;
	if(SplineComponent->GetNumberOfSplinePoints() >= 2)
		return Curve;
	return Empty;
}

void FDialogueCameraTrackEditor::AddCameraSubTrack(TSubclassOf<class UDialogueActionTrack> TrackCls)
{
	UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (!Asset)
		return;
	UDialogueActionTrack* NewTrack = NewObject<UDialogueActionTrack>(Asset, TrackCls, NAME_None, RF_Transactional);
	CachedTrack->AddAction(NewTrack);
	Asset->GetPackage()->MarkPackageDirty();
	TimelineController.Pin()->RefreshTracks();
}

#undef LOCTEXT_NAMESPACE