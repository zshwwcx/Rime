
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueRoutePointTrackEditor.h"
#include "LevelEditorViewport.h"
#include "Widgets/TimeLineBase/TimelineController.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"

#define LOCTEXT_NAMESPACE "DialogueActorTrackEditor"


void FDialogueRoutePointTrackEditor::BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder)
{
	UDialogueEditorSettings* DialogueSettings = GetMutableDefault<UDialogueEditorSettings>();
	for (TSubclassOf<UDialogueActionTrack> SubTrackCls : DialogueSettings->RouterPointSubTracks)
	{
		InMenuBuilder.AddMenuEntry
		(
			SubTrackCls->GetDisplayNameText(),
			FText::FromString(SubTrackCls->GetDescription()),
			FSlateIcon(),
			FUIAction
			(
				FExecuteAction::CreateSP(this, &FDialogueRoutePointTrackEditor::AddSubTrack, SubTrackCls)
			),
			NAME_None,
			EUserInterfaceActionType::Button
		);
	}
}




void FDialogueRoutePointTrackEditor::AddSubTrack(TSubclassOf<class UDialogueActionTrack> TrackCls)
{
	UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (!Asset)
		return;
	UDialogueActionTrack* NewTrack = NewObject<UDialogueActionTrack>(Asset, TrackCls, NAME_None, RF_Transactional);
	CachedTrack->AddAction(NewTrack);
	Asset->GetPackage()->MarkPackageDirty();
	TimelineController.Pin()->RefreshTracks();
}

#undef LOCTEXT_NAMESPACE