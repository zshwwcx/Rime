#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueCameraCutTrackEditor.h"
#include "DialogueEditor/DialogueEditor.h"
#include "KGSLEditorStyle.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "DialogueEditor/DialogueEditorManager.h"

#define LOCTEXT_NAMESPACE "DialogueCameraCutTrackEditor"


void FDialogueCameraCutTrackEditor::BuildOutlinerTrackActions(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.AddSubMenu
	(
		LOCTEXT("NewBinding", "New Binding"),
		LOCTEXT("NewBinding_Tip", "Add a new camera cut by creating a new binding to an object in the world."),
		FNewMenuDelegate::CreateLambda
		(
			[this](FMenuBuilder& InMenuBuilder)
			{
				UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
				FDialogueEpisode* Episode1 = Asset->GetEpisodePointerByIndex(0);
				TArray<UDialogueTrackBase*> AllTracks = Episode1->GetAllTracks();
				for (int32 i = 0; i < AllTracks.Num(); ++i)
				{
					UDialogueTrackBase* Track = AllTracks[i];
					if (Track->GetType() == EDialogueTrack::Type::Camera)
					{
						InMenuBuilder.AddMenuEntry
						(
							Track->GetTrackName(),
							LOCTEXT("Action_Section_Tooltip", "Section"),
							FSlateIcon(),
							FUIAction
							(
								FExecuteAction::CreateSP(this, &FDialogueCameraCutTrackEditor::OnAddCameraCutSection, Track)
							),
							NAME_None,
							EUserInterfaceActionType::Button
						);
					}
				}
				
			}
		)
	);
}

TSharedPtr<SWidget> FDialogueCameraCutTrackEditor::BuildOutlinerEditWidget()
{
	return FDialogueTrackEditor::BuildOutlinerEditWidget();
}

const FSlateBrush* FDialogueCameraCutTrackEditor::GetIconBrush() const
{
	return FKGSLEditorStyle::Get().GetBrush("KGSL.Tracks.CameraCut");
}

void FDialogueCameraCutTrackEditor::OnAddCameraCutSection(UDialogueTrackBase* Track)
{
	if (Track == nullptr)
		return;
	if(UDialogueActionBase* Section = CreateSection(0.0f))
	{
		if (CachedEditor.IsValid())
		{
			CachedEditor.Pin()->GetDialogueEditorManager()->OnAddCameraCutSectionFromTrack(Section, Track->GetTrackName().ToString());
		}
	}
}

void FDialogueCameraCutTrackEditor::OnLockCameraClicked(ECheckBoxState CheckBoxState)
{
}


ECheckBoxState FDialogueCameraCutTrackEditor::IsCameraLocked() const
{
	if (CachedEditor.Pin()->IsViewportCameraCutEnabled())
	{
		return ECheckBoxState::Checked;
	}
	else
	{
		return ECheckBoxState::Unchecked;
	}
}

FText FDialogueCameraCutTrackEditor::GetLockCameraToolTip() const
{
	//const TSharedRef<const FInputChord> FirstActiveChord = FCameraCutTrackCommands::Get().ToggleLockCamera->GetFirstValidChord();

	FText Tooltip = IsCameraLocked() == ECheckBoxState::Checked ?
		LOCTEXT("UnlockCamera", "Unlock Viewport from Camera Cuts") :
		LOCTEXT("LockCamera", "Lock Viewport to Camera Cuts");

	/*if (FirstActiveChord->IsValidChord())
	{
		return FText::Join(FText::FromString(TEXT(" ")), Tooltip, FirstActiveChord->GetInputText());
	}*/
	return Tooltip;
}

#undef LOCTEXT_NAMESPACE