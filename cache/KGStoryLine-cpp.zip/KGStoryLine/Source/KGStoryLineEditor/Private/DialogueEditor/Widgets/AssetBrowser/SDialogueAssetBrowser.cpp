#include "DialogueEditor/Widgets/AssetBrowser/SDialogueAssetBrowser.h"

#include "AssetToolsModule.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorLuaGameInstance.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "Editor.h"
#include "ShaderPrintParameters.h"
#include "DialogueEditor/Widgets/AssetBrowser/DialogueAssetViewContextMenuContext.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Filters/SFilterSearchBox.h"
#include "Internationalization/Regex.h"
#include "DialogueEditor/LuaAsset/LuaAssetHelper.h"
#include "Misc/FileHelper.h"
#include "Misc/MessageDialog.h"
#include "RevisionControlStyle/RevisionControlStyle.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Views/STreeView.h"

#define LOCTEXT_NAMESPACE "SDialogueAssetBrowser"

namespace
{
	bool SortItemFunc(const TSharedPtr<IDialogueAssetViewItem>& A, const TSharedPtr<IDialogueAssetViewItem>& B)
	{
		FDialogueLuaAssetViewItem* AssetItemA = A->CastToLuaAssetViewItem();
		FDialogueLuaAssetViewItem* AssetItemB = B->CastToLuaAssetViewItem();
		FDialogueFolderViewItem* FolderItemA = A->CastToFolderItem();
		FDialogueFolderViewItem* FolderItemB = B->CastToFolderItem();
		if (AssetItemA && AssetItemB)
		{
			return AssetItemA->DialogueAssetData.StoryLineID < AssetItemB->DialogueAssetData.StoryLineID;
		}
		if (AssetItemA && FolderItemB)
		{
			return false;
		}
		if (AssetItemB && FolderItemA)
		{
			return true;
		}
		return FolderItemA->GetLeafName() < FolderItemB->GetLeafName();
	}

	bool SortHistoryItemFunc(const TSharedPtr<IDialogueAssetViewItem>& A, const TSharedPtr<IDialogueAssetViewItem>& B)
	{
		FDialogueLuaAssetViewItem* AssetItemA = A->CastToLuaAssetViewItem();
		FDialogueLuaAssetViewItem* AssetItemB = B->CastToLuaAssetViewItem();
		
		if (AssetItemA && AssetItemB)
		{
			const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>();
			int32 IndexA = EditorSettings->HistoryAssets.Find(AssetItemA->DialogueAssetData.StoryLineID);
			int32 IndexB = EditorSettings->HistoryAssets.Find(AssetItemB->DialogueAssetData.StoryLineID);
			return IndexA > IndexB;
		}
		
		return true;
	}
}

void SDialogueAssetBrowser::Construct(const FArguments& InArgs)
{
	if (const UDialogueEditorPerProjectUserSettings* EditorSettings = GetDefault<UDialogueEditorPerProjectUserSettings>())
	{
		CurrentViewType = EditorSettings->AssetViewType;
	}
	GetDialogueAssetData();
	this->OnOpenDialogueByDoubleClick = InArgs._OnOpenDialogueByDoubleClick;
	this->OnCreateDialogueByDoubleClick = InArgs._OnCreateDialogueByDoubleClick;
	DialogueAssetItems.Empty();
	HeaderRowWidget = SNew(SHeaderRow);

	SearchBoxFilter = CreateTextFilter();
	FilterTextBoxWidget = SNew(SFilterSearchBox)
		.Visibility(EVisibility::Visible)
		.HintText(LOCTEXT("FilterSearch", "搜索..."))
		.ToolTipText(LOCTEXT("FilterSearchHint", "支持ID、备注、负责策划的模糊搜索,支持'=*'的形式搜索文本内容(星号代表要搜索的内容,需要敲回车)"))
		.OnTextChanged(this, &SDialogueAssetBrowser::OnFilterTextChanged)
		.OnTextCommitted(this, &SDialogueAssetBrowser::OnFilterTextCommitted);

	auto Toolbar = SNew(SHorizontalBox);

	Toolbar->AddSlot().VAlign(VAlign_Center)[FilterTextBoxWidget.ToSharedRef()];

	FColor SelectedColor = FColor(0,164,180);
	FColor NormalColor = FColor::White;
	const FSlateFontInfo FontInfo = FSlateFontInfo(FCoreStyle::GetDefaultFont(), 11);

	auto ViewTypeWidget = SNew(SHorizontalBox)
		+SHorizontalBox::Slot()
		.AutoWidth()
		.HAlign(HAlign_Center)
		.FillWidth(0.06f)
		[
			SNew(SButton)
			.ButtonStyle(FAppStyle::Get(), "NoBorder")
			.ForegroundColor_Lambda([this, SelectedColor, NormalColor]()
			{
				return GetCurrentViewType() == EDialogueAssetViewType::Folder ? SelectedColor : NormalColor;
			})
			.OnClicked_Lambda([this]()
			{
				SetCurrentViewTypeFromMenu(EDialogueAssetViewType::Folder);
				return FReply::Handled();
			})
			.ToolTipText(LOCTEXT("FolderViewOptionToolTip", "显示文件夹结构"))
			[
				SNew(STextBlock)
				.Font(FontInfo)
				.Text(LOCTEXT("Folder", "目录"))
			]
		]
		+SHorizontalBox::Slot()
		.AutoWidth()
		.HAlign(HAlign_Center)
		.FillWidth(0.06f)
		[
			SNew(SButton)
			.ButtonStyle(FAppStyle::Get(), "NoBorder")
			.ForegroundColor_Lambda([this, SelectedColor, NormalColor]()
			{
				return GetCurrentViewType() == EDialogueAssetViewType::Asset ? SelectedColor : NormalColor;
			})
			.OnClicked_Lambda([this]()
			{
				SetCurrentViewTypeFromMenu(EDialogueAssetViewType::Asset);
				return FReply::Handled();
			})
			.ToolTipText(LOCTEXT("ListViewOptionToolTip", "显示资产列表"))
			[
				SNew(STextBlock)
				.Font(FontInfo)
				.Text(LOCTEXT("List", "列表"))
			]
		]
		+SHorizontalBox::Slot()
		.AutoWidth()
		.HAlign(HAlign_Center)
		.FillWidth(0.06f)
		[
			SNew(SButton)
			.ButtonStyle(FAppStyle::Get(), "NoBorder")
			.ForegroundColor_Lambda([this, SelectedColor, NormalColor]()
			{
				return GetCurrentViewType() == EDialogueAssetViewType::Favorite ? SelectedColor : NormalColor;
			})
			.OnClicked_Lambda([this]()
			{
				SetCurrentViewTypeFromMenu(EDialogueAssetViewType::Favorite);
				return FReply::Handled();
			})
			.ToolTipText(LOCTEXT("FavoriteViewOptionToolTip", "显示收藏夹"))
			[
				SNew(STextBlock)
				.Font(FontInfo)
				.Text(LOCTEXT("Favorite", "收藏"))
			]
		]
		+SHorizontalBox::Slot()
		.AutoWidth()
		.HAlign(HAlign_Center)
		.FillWidth(0.06f)
		[
			SNew(SButton)
			.ButtonStyle(FAppStyle::Get(), "NoBorder")
			.ForegroundColor_Lambda([this, SelectedColor, NormalColor]()
			{
				return GetCurrentViewType() == EDialogueAssetViewType::History ? SelectedColor : NormalColor;
			})
			.OnClicked_Lambda([this]()
			{
				SetCurrentViewTypeFromMenu(EDialogueAssetViewType::History);
				return FReply::Handled();
			})
			.ToolTipText(LOCTEXT("HistoryViewOptionToolTip", "显示最近浏览文件"))
			[
				SNew(STextBlock)
				.Font(FontInfo)
				.Text(LOCTEXT("History", "最近"))
			]
		]
		+SHorizontalBox::Slot()
		.FillWidth(1.f)
		;

	TSharedRef<SVerticalBox> VerticalBox = SNew(SVerticalBox);

	ChildSlot
	[
		VerticalBox
	];
	VerticalBox->AddSlot().AutoHeight()[Toolbar];
	
	VerticalBox->AddSlot().AutoHeight()[ViewTypeWidget];

	VerticalBox->AddSlot().FillHeight(1.0)[SNew(SOverlay)
	+ SOverlay::Slot()
	[
		SNew(SBorder).BorderImage(FAppStyle::Get().GetBrush("Brushes.Recessed"))
	]
	+ SOverlay::Slot()
	[
		SNew(SBorder).Padding(FMargin(3)).BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		[
			SAssignNew(TreeView, SDialogueAssetTreeView, StaticCastSharedRef<SDialogueAssetBrowser>(AsShared()))
			.ItemHeight(16.0f)
			.TreeItemsSource(&DialogueAssetItems)
			.HeaderRow(SNew(SHeaderRow)
			+ SHeaderRow::Column(DialogueAssetBrowserColumnConstants::VersionState).FillWidth(0.2f).HAlignHeader(HAlign_Center).VAlignHeader(VAlign_Center).HAlignCell(HAlign_Center).VAlignCell(VAlign_Center)
			[
				SNew(SImage).ColorAndOpacity(FLinearColor(1.0f, 1.0f, 1.0f, 0.4f)).ToolTipText(LOCTEXT("RevisionState", "RevisionState")).Image(FRevisionControlStyleManager::Get().GetBrush("RevisionControl.Icon"))
			]
			+ SHeaderRow::Column(DialogueAssetBrowserColumnConstants::DialogueID).FillWidth(3.f).HAlignHeader(HAlign_Left).VAlignHeader(VAlign_Center).HAlignCell(HAlign_Left).VAlignCell(VAlign_Center)
			[
				SNew(STextBlock).Text(LOCTEXT("DialogueID", "对话ID"))
			]
			+ SHeaderRow::Column(DialogueAssetBrowserColumnConstants::Description).FillWidth(3.f).HAlignHeader(HAlign_Left).VAlignHeader(VAlign_Center).HAlignCell(HAlign_Left).VAlignCell(VAlign_Center)
			[
				SNew(STextBlock).Text(LOCTEXT("Description", "备注"))
			]
			+ SHeaderRow::Column(DialogueAssetBrowserColumnConstants::AuthorName).FillWidth(1.f).HAlignHeader(HAlign_Left).VAlignHeader(VAlign_Center).HAlignCell(HAlign_Left).VAlignCell(VAlign_Center)
			[
				SNew(STextBlock).Text(LOCTEXT("AuthorName", "负责策划"))
			])
			.OnGetChildren(this, &SDialogueAssetBrowser::OnGetChildrenForTree)
			.OnGenerateRow(this, &SDialogueAssetBrowser::OnGenerateRowForTree)
			.SelectionMode(ESelectionMode::Single)
			.OnMouseButtonDoubleClick(this, &SDialogueAssetBrowser::OnListMouseButtonDoubleClick)
			.OnExpansionChanged(this, &SDialogueAssetBrowser::OnItemExpansionChanged)
			.OnContextMenuOpening(this, &SDialogueAssetBrowser::OnOpenContextMenu)
		]
	]];

	RefreshItemsByDialogueAssetData([](const FDialogueAssetData& DialogueAssetData){return true;});
}

// 双击条目，打开对话文件，文件不存在时，询问是否创建
void SDialogueAssetBrowser::OnListMouseButtonDoubleClick(FDialogueAssetTreeItemPtr ViewItem)
{
	if (ViewItem->IsFolderItem())
	{
		return;
	}

	FDialogueLuaAssetViewItem* LuaAssetViewItem = ViewItem->CastToLuaAssetViewItem();
	check(LuaAssetViewItem);
	
	FString FileName = LuaAssetViewItem->GetDisplayString();
	bool bSimpleDialogue = LuaAssetViewItem->IsSimpleDialogue();
	
	FLuaAssetHelper::OpenOrCreateDialogueByFileNameInternal(FileName,bSimpleDialogue,
	[this]()
	{
		if (OnOpenDialogueByDoubleClick.IsBound())
		{
			OnOpenDialogueByDoubleClick.Execute();
		}
	},
	[this]()
	{
		if (OnCreateDialogueByDoubleClick.IsBound())
		{
			OnCreateDialogueByDoubleClick.Execute();
		}
	});
}

TSharedPtr<DialogueItemTextFilter> SDialogueAssetBrowser::CreateTextFilter() const
{
	auto Delegate = DialogueItemTextFilter::FItemToStringArray::CreateSP( this, &SDialogueAssetBrowser::PopulateSearchStrings );

	return MakeShareable( new DialogueItemTextFilter( Delegate ) );
}

void SDialogueAssetBrowser::PopulateSearchStrings(const IDialogueAssetViewItem& Item, TArray<FString>& OutSearchStrings) const
{
	
}

bool SDialogueAssetBrowser::FilterByContent(const FDialogueAssetData& DialogueAssetData, const FString& Content)
{
	if (Content.IsEmpty())
	{
		return false;
	}
	const FString LuaPath = FPaths::ProjectContentDir() + TEXT("Script/Data/Config/Dialogue");
	TArray<FString> FileNames;
	FString FileName = FPaths::Combine(LuaPath, DialogueAssetData.StoryLineID + ".lua");
	FString FileData = "";
	FFileHelper::LoadFileToString(FileData, *FileName);
	if (!FileData.Contains("ContentString="))
	{
		return false;
	}
	FRegexPattern ContentPattern(TEXT("ContentString=\\\\\"(.*?)\\\\\""));
	FRegexMatcher Matcher(ContentPattern, FileData);
	while (Matcher.FindNext())
	{
		// 获取双引号内的内容
		FString QuotedContent = Matcher.GetCaptureGroup(1);
		if (QuotedContent.Contains(Content))
		{
			return true;
		}
	}
	return false;
}

bool SDialogueAssetBrowser::FilterCommon(const FString& FilterStr, const FDialogueAssetData& DialogueAssetData)
{
	if (FilterStr.IsEmpty())
	{
		return true;
	}
	if (DialogueAssetData.StoryLineID.Contains(FilterStr))
	{
		return true;
	}
	if (DialogueAssetData.Description.Contains(FilterStr))
	{
		return true;
	}
	if (DialogueAssetData.AuthorName.Contains(FilterStr))
	{
		return true;
	}
	return false;
}

void SDialogueAssetBrowser::ExpandAllItems()
{
	if (CurrentViewType == EDialogueAssetViewType::Folder || CurrentViewType == EDialogueAssetViewType::Favorite)
	{
		for (FDialogueAssetTreeItemPtr& Item : DialogueAssetItems)
		{
			TreeView->SetItemExpansion(Item, true);
			for (FDialogueAssetTreeItemPtr& ChildItem : Item->Children)
			{
				if (ChildItem.IsValid())
				{
					TreeView->SetItemExpansion(ChildItem, true);
				}
			}
		}
	}
}

void SDialogueAssetBrowser::OnFilterTextChanged(const FText& InFilterText)
{
	FString FilterStr = InFilterText.ToString();
	RefreshItemsByDialogueAssetData([&FilterStr](const FDialogueAssetData& DialogueAssetData)
	{
		return SDialogueAssetBrowser::FilterCommon(FilterStr, DialogueAssetData);
	});

	// 展开搜索到的文件
	if (!FilterStr.IsEmpty())
	{
		ExpandAllItems();
	}
}

void SDialogueAssetBrowser::OnFilterTextCommitted(const FText& InFilterText, ETextCommit::Type CommitInfo)
{
	FString FilterStr = InFilterText.ToString();
	FString ContentFilterStr = "=";
	if (FilterStr.StartsWith(ContentFilterStr))
	{
		FString SearchStr = FilterStr.Mid(ContentFilterStr.Len(), FilterStr.Len() - ContentFilterStr.Len());
		RefreshItemsByDialogueAssetData([&SearchStr](const FDialogueAssetData& DialogueAssetData)
		{
			return SDialogueAssetBrowser::FilterByContent(DialogueAssetData, SearchStr);
		});
		// 展开搜索到的文件
		ExpandAllItems();
	}
}

FText SDialogueAssetBrowser::GetFilterText() const
{
	return FilterTextBoxWidget->GetText();
}

void SDialogueAssetBrowser::GetDialogueAssetData()
{
	UWorld* DummyWorld = NewObject<UWorld>();
    UEditorLuaEnv *LuaEnv = UEditorLuaEnv::CreateLuaEnv(DummyWorld, UDialogueEditorLuaGameInstance::StaticClass());
	UDialogueEditorManager* DialogueEditorManager = NewObject<UDialogueEditorManager>(DummyWorld);
	DialogueEditorManager->Initialize();
	CachedDialogueAssetData.Empty();
	DialogueEditorManager->GetDialogueAssetData(CachedDialogueAssetData);
    UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
}

void SDialogueAssetBrowser::RefreshItemsByDialogueAssetData(TFunctionRef<bool(const FDialogueAssetData& DialogueAssetData)> FilterFunc)
{
	DialogueAssetItems.Empty();
	TMap<FString, TSharedPtr<FDialogueFolderViewItem>> DialogueFolderViewItems;
	UDialogueEditorPerProjectUserSettings* EditorSettings = GetMutableDefault<UDialogueEditorPerProjectUserSettings>();
	for (const TTuple<FString, FDialogueAssetData>& AssetData : CachedDialogueAssetData)
	{
		FString AssetName = AssetData.Key;
		if (!FilterFunc(AssetData.Value))
		{
			continue;
		}
		if (CurrentViewType == EDialogueAssetViewType::Asset)
		{
			TSharedPtr<FDialogueLuaAssetViewItem> AssetItem = MakeShared<FDialogueLuaAssetViewItem>(AssetData.Value);
			DialogueAssetItems.Add(AssetItem);
		}
		else if (CurrentViewType == EDialogueAssetViewType::History)
		{
			if (EditorSettings->HistoryAssets.Contains(AssetData.Value.StoryLineID))
			{
				TSharedPtr<FDialogueLuaAssetViewItem> AssetItem = MakeShared<FDialogueLuaAssetViewItem>(AssetData.Value);
				DialogueAssetItems.Add(AssetItem);
			}
		}
		else
		{
			TArray<FString> PathArray;
			FString DialogueType = AssetData.Value.DialogueType;
			FString SubFolder = AssetData.Value.SubFolder;
			
			if (DialogueType.IsEmpty())
			{
				DialogueType = TEXT("未分类");
			}

			FString AssetPath = DialogueType;
			PathArray.Add(DialogueType);
			if (!SubFolder.IsEmpty())
			{
				AssetPath += "/" + SubFolder;
				PathArray.Add(SubFolder);
			}

			if (CurrentViewType == EDialogueAssetViewType::Favorite)
			{
				bool bIsFavorite = false;
				for (FString Path : EditorSettings->FavoriteFolderPaths)
				{
					// 只有子目录允许收藏,处理zhu'mu'l
					if (Path.Contains("/") && AssetPath == Path)
					{
						bIsFavorite = true;
						break;
					}
				}
				if (!bIsFavorite)
				{
					continue;
				}
				PathArray.Empty();
				PathArray.Add(SubFolder);
			}
			TSharedPtr<FDialogueLuaAssetViewItem> AssetItem = MakeShared<FDialogueLuaAssetViewItem>(AssetData.Value);
			FString CurrentPath;
			FDialogueFolderViewItem* CurrentItem = nullptr;
			for (int32 i = 0; i < PathArray.Num(); i++)
			{
				CurrentPath += PathArray[i];
				if (!DialogueFolderViewItems.Contains(CurrentPath))
				{
					TSharedPtr<FDialogueFolderViewItem> Item = MakeShared<FDialogueFolderViewItem>();
					DialogueFolderViewItems.Add(CurrentPath, Item);
					Item->Path = CurrentPath;
					Item->LeafName = PathArray[i];
					if (CurrentItem)
					{
						CurrentItem->AddChild(Item.ToSharedRef());
					}
					else
					{
						DialogueAssetItems.Add(Item);
					}
					CurrentItem = Item.Get();
				}
				else
				{
					CurrentItem = DialogueFolderViewItems[CurrentPath].Get();
				}
				CurrentPath += "/";
			}
			if (CurrentItem)
			{
				CurrentItem->AddChild(AssetItem.ToSharedRef());
			}
			else
			{
				DialogueAssetItems.Add(AssetItem);
			}
		}
	}

	if (CurrentViewType == EDialogueAssetViewType::History)
	{
		DialogueAssetItems.Sort(SortHistoryItemFunc);
	}
	else
	{
		DialogueAssetItems.Sort(SortItemFunc);
	}
	
	TreeView->RebuildList();
}

void SDialogueAssetBrowser::RefreshTreeView()
{
	OnFilterTextChanged(FilterTextBoxWidget->GetText());
}

void SDialogueAssetBrowser::OnGetChildrenForTree(FDialogueAssetTreeItemPtr InParent, TArray<FDialogueAssetTreeItemPtr>& OutChildren)
{
	for (auto& Child : InParent->GetChildren())
	{
		OutChildren.Add(Child);
	}
	OutChildren.Sort(SortItemFunc);
}

TSharedRef<ITableRow> SDialogueAssetBrowser::OnGenerateRowForTree(FDialogueAssetTreeItemPtr Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	return SNew(SDialogueAssetTreeRow, TreeView.ToSharedRef(), SharedThis(this)).Item(Item);
}

void SDialogueAssetBrowser::OnItemExpansionChanged(FDialogueAssetTreeItemPtr TreeItem, bool bIsExpanded) const
{
	TreeItem->Flags.bIsExpanded = bIsExpanded;

	// Expand any children that are also expanded
	for (auto Child : TreeItem->GetChildren())
	{
		if (Child.IsValid() && Child->Flags.bIsExpanded)
		{
			TreeView->SetItemExpansion(Child, true);
		}
	}
}

TSharedPtr<SWidget> SDialogueAssetBrowser::OnOpenContextMenu()
{
	TArray<FDialogueAssetTreeItemPtr> SelectedItems = TreeView->GetSelectedItems();
	if (SelectedItems.IsEmpty())
	{
		return SNullWidget::NullWidget;
	}

	FDialogueAssetTreeItemPtr SelectedItem = SelectedItems[0];

	return SelectedItem->CreateContextMenu(TreeView);
}

void SDialogueAssetBrowser::SetCurrentViewTypeFromMenu(EDialogueAssetViewType NewType)
{
	if (NewType != CurrentViewType)
	{
		SetCurrentViewType(NewType);
	}
}

bool SDialogueAssetBrowser::IsCurrentViewType(EDialogueAssetViewType ViewType) const
{
	return GetCurrentViewType() == ViewType;
}

EDialogueAssetViewType SDialogueAssetBrowser::GetCurrentViewType() const
{
	return CurrentViewType;
}

void SDialogueAssetBrowser::SetCurrentViewType(EDialogueAssetViewType NewType)
{
	CurrentViewType = NewType;
	UDialogueEditorPerProjectUserSettings* EditorSettings = GetMutableDefault<UDialogueEditorPerProjectUserSettings>();
	EditorSettings->AssetViewType = CurrentViewType;
	EditorSettings->SaveConfig();
	RefreshTreeView();
}

bool SDialogueAssetBrowser::OpenDialogueIsGamePreview()
{
	for (const FWorldContext& Context : GEngine->GetWorldContexts())
	{
		if (Context.WorldType == EWorldType::Game
			|| Context.WorldType == EWorldType::GamePreview
			|| Context.WorldType == EWorldType::PIE)
		{
			return true;
		}
	}

	return false;
}
#undef LOCTEXT_NAMESPACE
