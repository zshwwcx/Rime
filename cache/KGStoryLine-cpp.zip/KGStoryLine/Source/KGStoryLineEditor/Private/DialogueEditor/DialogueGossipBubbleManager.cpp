#include "DialogueEditor/DialogueGossipBubbleManager.h"

#include "3C/Character/BaseCharacter.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorSceneProxy.h"
#include "DialogueEditor/DialogueEditorUtilities.h"
#include "Manager/KGBasicManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "SceneView.h"
#include "SLevelViewport.h"
#include "Components/SkeletalMeshComponent.h"
#include "Blueprint/UserWidget.h"
#include "Components/CanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include "Slate/SGameLayerManager.h"


void UDialogueGossipBubbleManager::Init(TWeakPtr<FDialogueEditor> InEditor)
{
    CachedEditor = InEditor;
}

bool UDialogueGossipBubbleManager::CalculateWidgetPositionInScreenSpace(const APlayerController* InPlayerController, int64 InEntityUID, UUserWidget* InUserWidget, FVector2D& OutScreenPos)
{
    if (auto* UEActorMgr = Cast<UKGUEActorManager>(UKGBasicManager::GetManagerByType(this, EManagerType::EMT_UEActorManager)))
    {
        if (ABaseCharacter* Character = Cast<ABaseCharacter>(UEActorMgr->GetActorByEntityID(InEntityUID)))
        {
            FVector PawnLocation;
            if (USkeletalMeshComponent* SkeletalMeshComp = Character->FindComponentByClass<USkeletalMeshComponent>())
            {
                //和挂点相同的PawnLocation位置计算中间位置
                PawnLocation = SkeletalMeshComp->GetSocketLocation(FName(TEXT("TOP_LOGO")));
            }
            else
            {
                PawnLocation = Character->GetActorLocation();
            }
            
            InPlayerController->ProjectWorldLocationToScreen(PawnLocation, OutScreenPos);
            return true;
        }
    }

    return false;
}

void UDialogueGossipBubbleManager::Tick(float DeltaTime)
{
    if (!CachedEditor.IsValid())
    {
        return;
    }
    TSharedPtr<FDialogueEditor> DialogueEditor = CachedEditor.Pin();
    TSharedPtr<FDialogueEditorSceneProxy> SceneProxy = DialogueEditor->GetPreviewScene();
    if (!SceneProxy.IsValid() || !SceneProxy->PlayerController.IsValid())
    {
        return;
    }

    FEditorViewportClient* ViewportClient = DialogueEditor->GetActiveViewportClient();
    if (!ViewportClient)
    {
        return;
    }
    
    // 创建场景视图
    FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
        ViewportClient->Viewport,
        ViewportClient->GetScene(),
        ViewportClient->EngineShowFlags)
        .SetRealtimeUpdate(ViewportClient->IsRealtime()));
    
    FSceneView* SceneView = ViewportClient->CalcSceneView(&ViewFamily);
    
    for (auto Iter = GossipBubbleMap.CreateIterator(); Iter; ++Iter)
    {
        Iter->Value.Widget->SetDesiredSizeInViewport(Iter->Value.Widget->GetDesiredSize());

        if (auto* UEActorMgr = Cast<UKGUEActorManager>(UKGBasicManager::GetManagerByType(this, EManagerType::EMT_UEActorManager)))
        {
            if (ABaseCharacter* Character = Cast<ABaseCharacter>(UEActorMgr->GetActorByEntityID(Iter->Key)))
            {
                FVector PawnLocation;
                if (USkeletalMeshComponent* SkeletalMeshComp = Character->FindComponentByClass<USkeletalMeshComponent>())
                {
                    //和挂点相同的PawnLocation位置计算中间位置
                    PawnLocation = SkeletalMeshComp->GetSocketLocation(FName(TEXT("TOP_LOGO")));
                }
                else
                {
                    PawnLocation = Character->GetActorLocation();
                }
            
                FVector2D ViewportPosition;
                if (SceneView->WorldToPixel(PawnLocation, ViewportPosition))
                {
                    // TSharedPtr<SGameLayerManager> GameLayerMgr = ViewportClient->GetEditorViewportWidget();
                    TSharedPtr<SEditorViewport> EditorViewport = ViewportClient->GetEditorViewportWidget();
                    if (auto LevelViewport = StaticCastSharedPtr<SLevelViewport>(EditorViewport))
                    {
                        if (auto OverlayWidget = LevelViewport->GetPIEViewportOverlayWidget())
                        {
                            FVector2D ViewportSize;
                            if (ViewportClient->Viewport)
                            {
                                ViewportSize = ViewportClient->Viewport->GetSizeXY();
                            }
                            ViewportPosition = OverlayWidget->GetTickSpaceGeometry().GetLocalSize() * (ViewportPosition / ViewportSize);
                            ViewportPosition = OverlayWidget->GetTickSpaceGeometry().LocalToAbsolute(ViewportPosition);
                        }
                    }
                    ViewportPosition = RootCanvas->GetCachedGeometry().AbsoluteToLocal(ViewportPosition);
                    Iter->Value.Slot->SetPosition(ViewportPosition);
                }
            }
        }       
    }
}

void UDialogueGossipBubbleManager::SetUIRoot(UWidget* InUIRoot)
{
    UIRoot = InUIRoot;
    if (UIRoot)
    {
        RootCanvas = NewObject<UCanvasPanel>(UIRoot, UCanvasPanel::StaticClass());
        FDialogueEditorUtilities::AddOverlayWidgetToViewport(RootCanvas->TakeWidget());
    }
}

UUserWidget* UDialogueGossipBubbleManager::CreateGossipBubble(KGEntityID InEntityUid, const FString& InWidgetBPPath)
{
    if (!UIRoot || !IsValid(UIRoot))
    {
        return nullptr;
    }
    
    if (auto* UEActorMgr = Cast<UKGUEActorManager>(UKGBasicManager::GetManagerByType(this, EManagerType::EMT_UEActorManager)))
    {
        if (Cast<ABaseCharacter>(UEActorMgr->GetActorByEntityID(InEntityUid)))
        {
            if (GossipBubbleMap.Contains(InEntityUid))
            {
                return GossipBubbleMap[InEntityUid].Widget;
            }
            
            FSoftClassPath ClassPath = InWidgetBPPath;
            if (UClass* ClassWidget = ClassPath.TryLoadClass<UUserWidget>())
            {
                UUserWidget* UserWidget = UUserWidget::CreateWidgetInstance(*UIRoot, ClassWidget, FName(NAME_None));
                FDialogueGossipBubble& Bubble = GossipBubbleMap.Add(InEntityUid);
                Bubble.Widget = UserWidget;
                Bubble.EntityID = InEntityUid;
                if (RootCanvas)
                {
                    auto* Slot = RootCanvas->AddChildToCanvas(UserWidget);
                    Slot->SetAutoSize(true);
                    Slot->SetAlignment(FVector2D(0.5f, 1.f));
                    Bubble.Slot = Slot;
                }
                
                return UserWidget;
            }
        }
    }
    
    return nullptr;
}

void UDialogueGossipBubbleManager::RemoveGossipBubble(KGEntityID InEntityUID)
{
    if (GossipBubbleMap.Contains(InEntityUID))
    {
        GossipBubbleMap[InEntityUID].Widget->RemoveFromParent();
        GossipBubbleMap.Remove(InEntityUID);
    }
}

void UDialogueGossipBubbleManager::ClearAllGossipBubbles()
{
    for (auto& Pair : GossipBubbleMap)
    {
        Pair.Value.Widget->RemoveFromParent();
        Pair.Value.Widget = nullptr;
    }
    GossipBubbleMap.Empty();
}

void UDialogueGossipBubbleManager::DestroyRootCanvas()
{
    if (RootCanvas)
    {
        FDialogueEditorUtilities::RemoveOverlayWidgetToViewport(RootCanvas->TakeWidget());
        RootCanvas = nullptr;
    }
}
