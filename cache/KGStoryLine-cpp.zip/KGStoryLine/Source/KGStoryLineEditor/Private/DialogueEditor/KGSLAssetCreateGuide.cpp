#include "DialogueEditor/KGSLAssetCreateGuide.h"

#include "AssetToolsModule.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Editor.h"
#include "ObjectTools.h"
#include "AssetRegistry/AssetData.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "Framework/Application/SlateApplication.h"
#include "Misc/MessageDialog.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/STextComboBox.h"
#include "Widgets/Text/STextBlock.h"

void FKGSLAssetCreateGuide::OpenGuideWindow(bool bAsModal)
{
	CloseGuideWindow();

	GetAllTemplates();

	bCreateSuccess = false;

	GuideWindow = SNew(SWindow)
		.IsTopmostWindow(true)
		.Title(FText::FromString(TEXT("快捷创建StoryLine资产")))
		.ClientSize(FVector2D(400, 120));


	GuideWindow->SetOnWindowClosed(FOnWindowClosed::CreateRaw(this, &FKGSLAssetCreateGuide::OnGuideWindowClosed));

	TSharedPtr<SVerticalBox> VerticalBox = SNew(SVerticalBox);

	VerticalBox->AddSlot()
	           .FillHeight(0.25f)
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.FillWidth(0.3f)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.TextStyle(FAppStyle::Get(), "MessageLog")
			.Text(FText::FromString(TEXT("  对话资产名称")))
		]
		+ SHorizontalBox::Slot()
		.FillWidth(0.7f)
		[
			SAssignNew(AssetNameText, SEditableTextBox)
		]
	];

	VerticalBox->AddSlot()
	           .FillHeight(0.25f)
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.FillWidth(0.3f)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.TextStyle(FAppStyle::Get(), "MessageLog")
			.Text(FText::FromString(TEXT("  对话配表ID")))
		]
		+ SHorizontalBox::Slot()
		.FillWidth(0.7f)
		[
			SAssignNew(StoryLineIDText, SEditableTextBox)
		]
	];

	VerticalBox->AddSlot()
	           .FillHeight(0.25f)
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.FillWidth(0.3f)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.TextStyle(FAppStyle::Get(), "MessageLog")
			.Text(FText::FromString(TEXT("  对话模板类型")))
		]
		+ SHorizontalBox::Slot()
		.FillWidth(0.7f)
		[
			SAssignNew(TemplateComboBox, STextComboBox)
			.OptionsSource(&TemplateNames)
			.InitiallySelectedItem(TemplateNames[0])
		]
	];

	VerticalBox->AddSlot()
	           .FillHeight(0.25f)
	[
		SNew(SButton)
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Center)
		.Text(FText::FromString(TEXT("创建")))
		.OnClicked(this, &FKGSLAssetCreateGuide::OnCreateBtnClicked)
	];

	GuideWindow->SetContent(VerticalBox.ToSharedRef());

	if(bAsModal)
	{
		GEditor->EditorAddModalWindow(GuideWindow.ToSharedRef());
	}
	else
	{
		FSlateApplication::Get().AddWindow(GuideWindow.ToSharedRef());
	}
}

void FKGSLAssetCreateGuide::CloseGuideWindow()
{
	if (GuideWindow.IsValid())
	{
		GuideWindow->RequestDestroyWindow();
		GuideWindow.Reset();
	}
}

void FKGSLAssetCreateGuide::SetStoryLineAsset(UObject* AssetObj)
{
	InCreatingAssetObj = AssetObj;
}

bool FKGSLAssetCreateGuide::GetParameters(FString& OutAssetName, FString& OutStoryLineID, FString& OutTemplateName) const
{
	if(bCreateSuccess)
	{
		OutAssetName = ValidAssetName;
		OutStoryLineID = StoryLineID;
		
		if (TemplateName2Path.Contains(TemplateName))
		{
			OutTemplateName = TemplateName2Path[TemplateName];
		}
	}
	
	return bCreateSuccess;
}

FReply FKGSLAssetCreateGuide::OnCreateBtnClicked()
{
	const FString AssetName = AssetNameText->GetText().ToString();
	const FString StoryLineIDInput = StoryLineIDText->GetText().ToString();
	const FString TemplateNameInput = *TemplateComboBox->GetSelectedItem();

	if (!StoryLineIDInput.IsNumeric())
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("[对话配表ID]格式有误,请检查.")));
	}
	else if (AssetName.IsEmpty())
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("[对话资产名称]未填写,请检查.")));
	}
	else if (TemplateNameInput.IsEmpty())
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("[对话模板类型]未选择,请检查.")));
	}
	else if (!AssetName.Contains(StoryLineIDInput))
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("[对话资产名称]中必须包含[对话配表ID],请检查.")));
	}
	else
	{
		UE_LOG(LogTemp, Log, TEXT("%s going to create asset:%s, id:%s, template:%s"), *FString(__FUNCTION__), *AssetName, *StoryLineIDInput, *TemplateNameInput);
		bCreateSuccess = true;
		ValidAssetName = AssetName;
		StoryLineID = StoryLineIDInput;
		TemplateName = TemplateNameInput;
		CloseGuideWindow();
	}

	return FReply::Handled();
}

void FKGSLAssetCreateGuide::OnGuideWindowClosed(const TSharedRef<SWindow>& Window)
{
	if (!InCreatingAssetObj.IsValid())
	{
		return;
	}

	if (bCreateSuccess)
	{
		const FString AssetName = AssetNameText->GetText().ToString();
		const FString StoryLineIDInput = StoryLineIDText->GetText().ToString();
		const FString TemplateNameInput = *TemplateComboBox->GetSelectedItem();
		ApplyOnAsset(AssetName, FCString::Atoi(*StoryLineIDInput), TemplateNameInput);
	}
	else
	{
		FAssetData AssetData(InCreatingAssetObj.Get());
		ObjectTools::DeleteAssets({AssetData}, false);
		InCreatingAssetObj.Reset();
	}
}

void FKGSLAssetCreateGuide::GetAllTemplates()
{
	TemplateName2Path.Empty();
	TemplateNames.Empty();

	// 默认添加一个[[无模板]]
	TemplateNames.Add(MakeShared<FString>("NoTemplate"));

	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();
	AssetRegistry.SearchAllAssets(true);

	FARFilter Filter;
	Filter.PackagePaths.Add("/Game/Blueprint/DialogueSystem/Template");
	Filter.ClassPaths.Add(UDialogueTemplateAsset::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;

	TArray<FAssetData> AssetDatas;
	AssetRegistry.GetAssets(Filter, AssetDatas);

	for (auto& AssetData : AssetDatas)
	{
		if (UDialogueTemplateAsset* Template = Cast<UDialogueTemplateAsset>(AssetData.GetAsset()))
		{
			TemplateName2Path.Add(Template->GetName(), Template->GetPathName());
			TemplateNames.Add(MakeShared<FString>(Template->GetName()));
		}
	}
}

void FKGSLAssetCreateGuide::ApplyOnAsset(const FString& AssetName, const int32 InStoryLineID, const FString& InTemplateName)
{
	if (!InCreatingAssetObj.IsValid())
	{
		return;
	}

	if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(InCreatingAssetObj))
	{
		DialogueAsset->StoryLineID = InStoryLineID;
		if (TemplateName2Path.Contains(InTemplateName))
		{
			FString TemplatePath = TemplateName2Path[InTemplateName];
			UDialogueTemplateAsset* TemplateAsset = LoadObject<UDialogueTemplateAsset>(nullptr, *TemplatePath);
			DialogueAsset->DialogueTemplate = TemplateAsset;
		}

		FString TargetPath = FPackageName::GetLongPackagePath(InCreatingAssetObj->GetPackage()->GetPathName());
		FAssetToolsModule& AssetToolsModule = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools");
		FAssetRenameData AssetRenameData(InCreatingAssetObj, TargetPath, AssetName);
		AssetToolsModule.Get().RenameAssets({AssetRenameData});
	}
}
