#include "DialogueEditor/DialogueEditorPreviewProxy.h"

#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorDelegates.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "DialogueEditor/DialogueEditorSceneProxy.h"


#pragma region Important
FDialogueEditorPreviewProxy::FDialogueEditorPreviewProxy(UDialogueBaseAsset* InAsset, const TSharedPtr<FDialogueEditor>& InEditor) : CachedAsset(InAsset), CachedEditor(InEditor)
{
	FDialogueEditorDelegates::SectionInstanceNoticeLua.AddRaw(this, &FDialogueEditorPreviewProxy::OnSectionInstanceNoticeLua);
}

FDialogueEditorPreviewProxy::~FDialogueEditorPreviewProxy()
{
	FDialogueEditorDelegates::SectionInstanceNoticeLua.RemoveAll(this);
}

float FDialogueEditorPreviewProxy::GetCurrentTime(int32 EpisodeID)
{
	return GetDialogueEditorManager()->GetDialogueRunningTime();
}

void FDialogueEditorPreviewProxy::OnPreviewEnd()
{
	bPlaying = false;
	bPause = false;

	FDialogueEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);
}

#pragma endregion Important



#pragma region Preview
UDialogueBaseAsset* FDialogueEditorPreviewProxy::GetPreviewAsset() const
{ 
	return CachedAsset.Get(); 
}

class UDialogueEditorManager* FDialogueEditorPreviewProxy::GetDialogueEditorManager()
{
	UDialogueEditorManager* Ret = CachedEditor.Pin()->GetPreviewScene()->GetDialogueEditorManager();
	return Ret;
}

void FDialogueEditorPreviewProxy::Play(int StartEpisode, float StartTime)
{
	// 如果当前启动了PIE，则不允许播放
	const bool bIsInPIEOrSimulate = GEditor->PlayWorld != NULL || GEditor->bIsSimulatingInEditor;
	if (bIsInPIEOrSimulate)
	{
		FPlatformMisc::MessageBoxExt(EAppMsgType::Ok, TEXT("Can't Preview Ability When PIE Is Running!"), TEXT("Error"));

		return;
	}
	GetDialogueEditorManager()->OnBeginPlay(CachedAsset.Get());
	GetDialogueEditorManager()->ActivateDialogue(CachedAsset.Get(), StartEpisode, StartTime);

	bPlaying = true;
	bPause = false;
	
	FDialogueEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);
}

bool FDialogueEditorPreviewProxy::IsPlaying() const
{
	return bPlaying;
}

void FDialogueEditorPreviewProxy::Pause()
{
	bPause = true;
	GetDialogueEditorManager()->SetDialoguePause(bPause);

	FDialogueEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);
}

bool FDialogueEditorPreviewProxy::IsPaused() const
{
	return bPlaying && bPause;
}

void FDialogueEditorPreviewProxy::Resume()
{
	bPause = false;

	GetDialogueEditorManager()->SetDialoguePause(bPause);

	FDialogueEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);
}

void FDialogueEditorPreviewProxy::ForwardStep()
{
	//GetDialogueEditorManager()->ForwardStep(0.01667f);
}

void FDialogueEditorPreviewProxy::BackwardStep()
{
	//GetDialogueEditorManager()->BackwardStep(0.01667f);
}

void FDialogueEditorPreviewProxy::Stop()
{
	bPlaying = false;
	bPause = false;
	GetDialogueEditorManager()->OnStop(CachedAsset.Get());

	FDialogueEditorDelegates::PreviewStateChangedEvent.Broadcast(bPlaying, bPause);
}

bool FDialogueEditorPreviewProxy::IsStopped() const
{
	return !bPlaying;
}

void FDialogueEditorPreviewProxy::ResetWorld()
{
	Stop();
}

void FDialogueEditorPreviewProxy::OnSectionInstanceNoticeLua(UDialogueActionBase* DialogueActionSection, int32 Param)
{
	GetDialogueEditorManager()->OnActionNoticeToSectionInstance(Param);
}
#pragma endregion Preview