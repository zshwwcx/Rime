#include "DialogueEditor/DialogueEditorLuaGameInstance.h"

#include "DialogueEditor/DialogueEditorUtilities.h"
#include "Slate/SceneViewport.h"
#include "Modules/ModuleManager.h"

FString UDialogueEditorLuaGameInstance::GetLuaFilePath_Implementation() const
{
    return TEXT("Editor.DialogueEditor.DialogueEditorGameInstance");
}

void UDialogueEditorLuaGameInstance::AddUI(UUserWidget* Widget)
{
	if (Widget == nullptr)
		return;
	TSharedRef<SWidget> SWidget = Widget->TakeWidget();

	//const FName NAME_LevelEditorName = "LevelEditor";
	//FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>(NAME_LevelEditorName);
	//TSharedPtr<class SLevelViewport> ActiveLevelViewport = LevelEditorModule.GetFirstActiveLevelViewport();
	//if (ActiveLevelViewport.IsValid())
	//	ActiveLevelViewport->AddOverlayWidget(SWidget);
	FDialogueEditorUtilities::AddOverlayWidgetToViewport(SWidget);
}

void UDialogueEditorLuaGameInstance::RemoveUI(UUserWidget* Widget)
{
	if (Widget == nullptr)
		return;
	TSharedRef<SWidget> SWidget = Widget->TakeWidget();
	//const FName NAME_LevelEditorName = "LevelEditor";
	//FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>(NAME_LevelEditorName);

	// caution by fanggang@kuaishou.com: make sure remove properly when you use 'GetFirstActiveLevelViewport'  
	// TSharedPtr<class SLevelViewport> ActiveLevelViewport = LevelEditorModule.GetFirstActiveLevelViewport();
	// if (ActiveLevelViewport.IsValid())
	// 	ActiveLevelViewport->RemoveOverlayWidget(SWidget);
	//TSharedPtr<ILevelEditor> LevelEditor = LevelEditorModule.GetFirstLevelEditor();
	//if (LevelEditor.IsValid())
	//{
	//	TArray<TSharedPtr<SLevelViewport>> LevelViewports = LevelEditor->GetViewports();
	//	for (auto const& Viewport : LevelViewports)
	//	{
	//		if (Viewport.IsValid())
	//		{
	//			Viewport->RemoveOverlayWidget(SWidget);
	//		}
	//	}
	//}
	FDialogueEditorUtilities::RemoveOverlayWidgetToViewport(SWidget);
}

FVector2D UDialogueEditorLuaGameInstance::GetViewportSize()
{
	const FName NAME_LevelEditorName = "LevelEditor";
	FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>(NAME_LevelEditorName);
	TSharedPtr<class SLevelViewport> ActiveLevelViewport = LevelEditorModule.GetFirstActiveLevelViewport();
	if (ActiveLevelViewport.IsValid())
	{
		TSharedPtr<FSceneViewport> SceneViewport = ActiveLevelViewport->GetSceneViewport();
		if (SceneViewport.IsValid())
		{
			return SceneViewport->GetSize();
		}
	}
	FVector2D ViewportSize(1, 1);
	return ViewportSize;
}