#include "DialogueEditor/DialogueEditorUtilities.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"
#include "ClassViewerFilter.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "LevelEditor.h"
#include "SLevelViewport.h"
#include "SClassViewer.h"
#include "Modules/ModuleManager.h"
#include "Widgets/Input/SComboButton.h"


TSharedRef<SWidget> FDialogueEditorUtilities::MakeTrackButton(FText HoverText, FOnGetContent MenuContent, const TAttribute<bool>& HoverState)
{
	FSlateFontInfo SmallLayoutFont = FCoreStyle::GetDefaultFontStyle("Regular", 8);

	TSharedRef<STextBlock> ComboButtonText =
		SNew(STextBlock)
		.Text(HoverText)
		.Font(SmallLayoutFont)
		.ColorAndOpacity(FSlateColor::UseForeground());


	TSharedRef<SComboButton> ComboButton =
		SNew(SComboButton)
		.HasDownArrow(false)
		.ButtonStyle(FAppStyle::Get(), "HoverHintOnly")
		.ForegroundColor(FSlateColor::UseForeground())
		.OnGetMenuContent(MenuContent)
		.ContentPadding(FMargin(5, 2))
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		.ButtonContent()
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(FMargin(0, 0, 2, 0))
		[
			SNew(SImage)
			.ColorAndOpacity(FSlateColor::UseForeground())
		.Image(FAppStyle::GetBrush("ComboButton.Arrow"))
		]
	+ SHorizontalBox::Slot()
		.VAlign(VAlign_Center)
		[
			ComboButtonText
		]
		];


	auto GetRolloverVisibility = [WeakComboButton = TWeakPtr<SComboButton>(ComboButton), HoverState]()
	{
		TSharedPtr<SComboButton> ComboButton = WeakComboButton.Pin();
		if (ComboButton->IsHovered() || ComboButton->IsOpen())
		{
			return EVisibility::SelfHitTestInvisible;
		}
		else
		{
			return EVisibility::Collapsed;
		}
	};


	TAttribute<EVisibility> Visibility = TAttribute<EVisibility>::Create(TAttribute<EVisibility>::FGetter::CreateLambda(GetRolloverVisibility));
	ComboButtonText->SetVisibility(Visibility);


	return ComboButton;
}

TWeakPtr<SWidget> FDialogueEditorUtilities::MakeNewTrackPicker(FMenuBuilder& MenuBuilder, const FOnClassPicked& OnTrackClassPicked, bool IsTemplateMode, bool FromActorTrack)
{
	class FNotifyStateClassFilter : public IClassViewerFilter
	{
	public:
		FNotifyStateClassFilter(bool IsTemplateMode, bool FromActorTrack):bTemplateMode(IsTemplateMode), FromActorTrack(FromActorTrack){}

		bool IsClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const UClass* InClass, TSharedRef< FClassViewerFilterFuncs > InFilterFuncs) override
		{
			const bool bMatchesFlags = !InClass->HasAnyClassFlags(CLASS_Hidden | CLASS_HideDropDown | CLASS_Deprecated | CLASS_Abstract);
			bool bChildOfObjectClass = false;
			if (FromActorTrack)
			{
				bChildOfObjectClass = InClass->IsChildOf(UDialogueSpawnableTrack::StaticClass());
			}
			else
			{
				TArray<UClass*> ValidClassArray
				{
					UDialogueDialogueTrack::StaticClass(),
				};
				//如果是蓝图Track，也支持
				UDialogueEditorSettings* DialogueEditorSettings = GetMutableDefault<UDialogueEditorSettings>();
				bool ClassValid = ValidClassArray.Contains(InClass) || (!InClass->HasAnyClassFlags(EClassFlags::CLASS_Native) && DialogueEditorSettings->BlueprintTracks.Contains(InClass));
				bChildOfObjectClass = InClass->IsChildOf(UDialogueSpawnableTrack::StaticClass()) || (!bTemplateMode && ClassValid);
			}
			return bChildOfObjectClass && bMatchesFlags;

		}

		virtual bool IsUnloadedClassAllowed(const FClassViewerInitializationOptions& InInitOptions, const TSharedRef< const IUnloadedBlueprintData > InUnloadedClassData, TSharedRef< FClassViewerFilterFuncs > InFilterFuncs) override
		{
			const bool bChildOfObjectClass = InUnloadedClassData->IsChildOf(UDialogueSpawnableTrack::StaticClass()) || (bTemplateMode && (InUnloadedClassData->IsChildOf(UDialogueCameraCutTrack::StaticClass()) || InUnloadedClassData->IsChildOf(UDialogueDialogueTrack::StaticClass())));
			const bool bMatchesFlags = !InUnloadedClassData->HasAnyClassFlags(CLASS_Hidden | CLASS_HideDropDown | CLASS_Deprecated | CLASS_Abstract);

			return bChildOfObjectClass && bMatchesFlags;
		}
	private:
		bool bTemplateMode;
		bool FromActorTrack;
	};


	if (MenuBuilder.GetMultiBox()->GetBlocks().Num() > 1)
	{
		MenuBuilder.AddMenuSeparator();
	}


	FClassViewerInitializationOptions InitOptions;
	InitOptions.Mode = EClassViewerMode::ClassPicker;
	InitOptions.bShowObjectRootClass = false;
	InitOptions.bShowUnloadedBlueprints = true;
	InitOptions.bShowNoneOption = false;
	InitOptions.bEnableClassDynamicLoading = true;
	InitOptions.bExpandRootNodes = true;
	InitOptions.NameTypeToDisplay = EClassViewerNameTypeToDisplay::DisplayName;
	InitOptions.ClassFilters.Add(MakeShared<FNotifyStateClassFilter>(IsTemplateMode, FromActorTrack));
	InitOptions.bShowBackgroundBorder = false;


	FClassViewerModule& ClassViewerModule = FModuleManager::LoadModuleChecked<FClassViewerModule>("ClassViewer");
	TSharedRef<SWidget> ClassViewWidget = ClassViewerModule.CreateClassViewer(InitOptions, OnTrackClassPicked);
	MenuBuilder.AddWidget
	(
		SNew(SBox)
		.MinDesiredWidth(300.0f)
		.MaxDesiredHeight(400.0f)
		[
			ClassViewWidget
		],
		FText(), true, false
	);
	return ClassViewWidget;
}
void FDialogueEditorUtilities::AddOverlayWidgetToViewport(TSharedRef<SWidget> OverlaidWidget)
{
	const FName NAME_LevelEditorName = "LevelEditor";
	FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>(NAME_LevelEditorName);

	// keep in sync with ALLOW_PLAY_IN_VIEWPORT_GAMEUI at SLevelViewport.cpp
#define ALLOW_PLAY_IN_VIEWPORT_GAMEUI 1
#if ALLOW_PLAY_IN_VIEWPORT_GAMEUI
	TSharedPtr<class SLevelViewport> LevelViewport = LevelEditorModule.GetFirstActiveLevelViewport();
	if (LevelViewport.IsValid())
	{
		TSharedPtr<SOverlay> PIEViewportOverlayWidget = LevelViewport->GetPIEViewportOverlayWidget();
		if (PIEViewportOverlayWidget.IsValid())
		{
			PIEViewportOverlayWidget->AddSlot()
				[
					OverlaidWidget
				];
		}
	}
#endif
}
void FDialogueEditorUtilities::RemoveOverlayWidgetToViewport(TSharedRef<SWidget> OverlaidWidget)
{
	const FName NAME_LevelEditorName = "LevelEditor";
	FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>(NAME_LevelEditorName);

	// keep in sync with ALLOW_PLAY_IN_VIEWPORT_GAMEUI at SLevelViewport.cpp
#define ALLOW_PLAY_IN_VIEWPORT_GAMEUI 1
#if ALLOW_PLAY_IN_VIEWPORT_GAMEUI
	TSharedPtr<ILevelEditor> LevelEditor = LevelEditorModule.GetFirstLevelEditor();
	if (LevelEditor.IsValid())
	{
		TArray<TSharedPtr<SLevelViewport>> LevelViewports = LevelEditor->GetViewports();
		for (auto const& LevelViewport : LevelViewports)
		{
			if (LevelViewport.IsValid())
			{
				TSharedPtr<SOverlay> PIEViewportOverlayWidget = LevelViewport->GetPIEViewportOverlayWidget();
				if (PIEViewportOverlayWidget.IsValid())
				{
					PIEViewportOverlayWidget->RemoveSlot(OverlaidWidget);
				}
			}
		}
	}
#endif
}

UDialogueAsset* FDialogueEditorUtilities::GetDialogueAsset(const UObject* InObject)
{
	if (!InObject || !IsValid(InObject))
	{
		return nullptr;
	}

	UDialogueAsset* DialogueAsset = nullptr;
	UObject* Outer = InObject->GetOuter();
	while(Outer && IsValid(Outer))
	{
		if(Outer->IsA(UDialogueAsset::StaticClass()))
		{
			DialogueAsset = Cast<UDialogueAsset>(Outer);
			break;
		}

		Outer = Outer->GetOuter();
	}
	
	return DialogueAsset;
}
