#include "DialogueEditor/DialogueEditorSceneProxy.h"
#include "EngineSettings.h"
#include "GameFramework/GameStateBase.h"
#include "GameFramework/GameModeBase.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorDelegates.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "DialogueEditor/DialogueEditorPreviewSettings.h"
#include "DialogueEditor/DialogueGossipBubbleManager.h"
#include "Kismet/GameplayStatics.h"
#include "Subsystems/UnrealEditorSubsystem.h"
#include "Evaluation/MovieSceneCameraShakePreviewer.h"
#include "Camera/CameraShakeBase.h"
#include "Camera/CameraShakeSourceComponent.h"
#include "EditorActorFolders.h"
#include "LevelEditorViewport.h"
#include "Blueprint/UserWidget.h"
#include "DialogueEditor/Dialogue/Actions/DialogueGossipBuble.h"

FDialogueEditorSceneProxy::FDialogueEditorSceneProxy(TSharedPtr<FDialogueEditor> InEditor)
{
	CachedEditor = InEditor;
	// 注册关心的事件
	GEngine->OnActorMoved().AddRaw(this, &FDialogueEditorSceneProxy::OnActorMoved);

	// 注册事件
	FDialogueEditorDelegates::PreviewStateChangedEvent.AddRaw(this, &FDialogueEditorSceneProxy::OnPreviewStateChanged);
}

void FDialogueEditorSceneProxy::CreateDialogueEditorManager()
{
	UWorld* World = CachedEditor.Pin()->GetWorld();
	DialogueEditorManager = NewObject<UDialogueEditorManager>(World);
	DialogueEditorManager->DialogueEditor = CachedEditor;
	DialogueEditorManager->Initialize();
}

FDialogueEditorSceneProxy::~FDialogueEditorSceneProxy()
{
}

void FDialogueEditorSceneProxy::SpawnPlayerController()
{
	if (!PlayerController.IsValid())
	{
		const UDialogueEditorSettings* EditorSettings = GetDefault<UDialogueEditorSettings>();
		if (EditorSettings == nullptr)
		{
			return;
		}
		const UGameMapsSettings* GameMapSettings = GetDefault<UGameMapsSettings>();
		if (GameMapSettings == nullptr)
		{
			return;
		}

		FSoftClassPath GameModeClassPath = GameMapSettings->GetGlobalDefaultGameMode();
		const UClass* GameModeClass = GameModeClassPath.TryLoadClass<AGameModeBase>();
		if (GameModeClass == nullptr)
		{
			return;
		}
		AGameModeBase* DefaultGameMode = GameModeClass ? Cast<AGameModeBase>(GameModeClass->GetDefaultObject()) : nullptr;
		if (DefaultGameMode == nullptr)
		{
			return;
		}

		UWorld* World = GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>()->GetEditorWorld();

		if (World == nullptr)
		{
			return;
		}

		// 查询PlayerController的类
		UClass* PlayerControllerClass = EditorSettings->PlayerControllerClass.Get() ? EditorSettings->PlayerControllerClass.Get() : (DefaultGameMode ? DefaultGameMode->PlayerControllerClass.Get() : nullptr);
		if (PlayerControllerClass == nullptr)
		{
			PlayerControllerClass = APlayerController::StaticClass();
		}

		// 创建PlayerController并设置摄像机
		PlayerController = World->SpawnActorDeferred<APlayerController>(PlayerControllerClass, FTransform::Identity);
		PlayerController->SetFlags(EObjectFlags::RF_Transient);
		if (PlayerController == nullptr)
		{
			return;
		}

		if (EditorSettings->CameraManagerClass)
		{
			PlayerController->PlayerCameraManagerClass = EditorSettings->CameraManagerClass.Get();
		}

		PlayerController->bAutoManageActiveCameraTarget = true;
		PlayerController->FinishSpawning(FTransform::Identity);
		PlayerController->AddToRoot();

		InitializeCameraManager();
	}
}

void FDialogueEditorSceneProxy::SpawnGossipBubbleManager()
{
    if (UWorld* World = GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>()->GetEditorWorld())
    {
        auto* Manager = NewObject<UDialogueGossipBubbleManager>(World, UDialogueGossipBubbleManager::StaticClass(), NAME_None, RF_Transient);
        Manager->Init(CachedEditor);
        Manager->AddToRoot();
        GossipBubbleManager = Manager;
    }
}

void FDialogueEditorSceneProxy::InitializeCameraManager() const
{
	// 初始化镜头
	if (PlayerController.IsValid() && PlayerController->PlayerCameraManager)
	{
		PlayerController->PlayerCameraManager->DispatchBeginPlay();
		PlayerController->PlayerCameraManager->bDebugClientSideCamera = true;
		PlayerController->PlayerCameraManager->SetFlags(EObjectFlags::RF_Transient);
	}
}

void FDialogueEditorSceneProxy::DestroyPlayerController()
{
	if (PlayerController.IsValid())
	{
		PlayerController->RemoveFromRoot();
		PlayerController->Destroy();
		PlayerController.Reset();
	}
}

void FDialogueEditorSceneProxy::DestroyGossipBubbleManager()
{
    if (GossipBubbleManager.IsValid())
    {
        GossipBubbleManager->ClearAllGossipBubbles();
        GossipBubbleManager->DestroyRootCanvas();
        GossipBubbleManager->RemoveFromRoot();
        GossipBubbleManager->MarkAsGarbage();
        GossipBubbleManager.Reset();
    }
}

void FDialogueEditorSceneProxy::ResetPreviewWorld()
{
	DestroyPreviewActors();
	DestroyPlayerController();

    if (GossipBubbleManager.IsValid())
    {
        GossipBubbleManager->ClearAllGossipBubbles();
    }

	SpawnPreviewActors();
	RefreshAppearanceTable();

	SpawnPlayerController();
}

void FDialogueEditorSceneProxy::DestroyPreviewActors(bool NeedDeleteFolder) const
{
	DialogueEditorManager->RemoveAllEditorDialogueActors();


	if (NeedDeleteFolder)
	{
		if (UWorld* World = DialogueEditorManager->GetBigWorld())
		{
			if (ActorFolder.GetActorFolder())
			{
				ActorFolder.GetActorFolder()->GetPackage()->MarkPackageDirty();
			}

			FActorFolders::Get().DeleteFolder(*World, ActorFolder);

			if (ActorFolder.GetActorFolder())
			{
				ActorFolder.GetActorFolder()->GetPackage()->ClearDirtyFlag();
			}
		}
	}
	CachedEditor.Pin()->OnLockCameraClicked(nullptr);
}

void FDialogueEditorSceneProxy::DestroyDialogueActors() const
{
	DestroyPreviewActors();
}

class FCameraShakePreviewer* FDialogueEditorSceneProxy::GetOrCreateShakePreviewer()
{
	if (CameraShakePreviewer == nullptr)
	{
		CameraShakePreviewer = new FCameraShakePreviewer(GetWorld());
	}
	return CameraShakePreviewer;
}

void FDialogueEditorSceneProxy::DestroyShakePreviewer()
{
	if (CameraShakePreviewer)
	{
		delete CameraShakePreviewer;
		CameraShakePreviewer = nullptr;
	}
}

void FDialogueEditorSceneProxy::SpawnPreviewActors()
{
	GetDialogueEditorManager()->PreCreatePreviewSceneActors();

	if (UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset())
	{
		if (UWorld* World = DialogueEditorManager->GetBigWorld())
		{
			ActorFolderName = FName(Asset->GetName());
			if (!ActorFolder.IsValid())
			{
				ActorFolder = FFolder(FFolder::GetWorldRootFolder(World).GetRootObject(), *Asset->GetName());
				FActorFolders::Get().CreateFolder(*World, ActorFolder);
			}
		}

		DialogueEditorManager->SpawnAllDialogueActors(Asset);
	}
}

void FDialogueEditorSceneProxy::Tick(const float DeltaTime)
{
	TickWorld(DeltaTime);
	if (CameraShakePreviewer)
	{
		CameraShakePreviewer->Update(DeltaTime, true);
	}

    if (GossipBubbleManager.IsValid())
    {
        GossipBubbleManager->Tick(DeltaTime);
    }
}

bool FDialogueEditorSceneProxy::IsTickable() const
{
	return true;
}

TStatId FDialogueEditorSceneProxy::GetStatId() const
{
	return TStatId();
}

void FDialogueEditorSceneProxy::TickWorld(const float DeltaSeconds) const
{
	if (DialogueEditorManager.IsValid())
	{
		DialogueEditorManager->ReceiveTick(DeltaSeconds);
	}
	if (TSharedPtr<FDialogueEditor> DialogueEditor = CachedEditor.Pin())
	{
		FEditorViewportClient* CurrentViewportClient = CachedEditor.Pin()->GetActiveViewportClient();
		if (CurrentViewportClient == nullptr)
		{
			return;
		}
		const FVector& ViewLocation = CurrentViewportClient->GetViewLocation();
		const FRotator& ViewRotation = CurrentViewportClient->GetViewRotation();
		UDialogueEditorPreviewSettings* PreviewSettings = GetMutableDefault<UDialogueEditorPreviewSettings>();
		PreviewSettings->ViewportTransform.SetLocation(ViewLocation);
		PreviewSettings->ViewportTransform.SetRotation(ViewRotation.Quaternion());
		if (DialogueEditor->SelectCameraComponent.Get())
		{
			//选中了子相机
			DialogueEditor->SelectCameraComponent->SetWorldLocationAndRotation(ViewLocation, ViewRotation.Quaternion());
		}
		else if (UDialogueCamera* DialogueCameraEntity = DialogueEditor->ClickCameraEntity.Get())
		{
			if (AActor* EntityActor = CachedEditor.Pin()->GetEntityActor(DialogueCameraEntity))
			{
				FTransform EntityActorTransform = EntityActor->GetTransform();
				if (!EntityActorTransform.Equals(PreviewSettings->ViewportTransform))
				{
					DialogueCameraEntity->SpawnTransform = PreviewSettings->ViewportTransform * DialogueCameraEntity->GetParentTransform().Inverse();
					DialogueCameraEntity->OnSpawnTransformChanged();
				}
			}
		}
	}
	
}

void FDialogueEditorSceneProxy::RefreshAppearanceTable() const
{
	if (UDialogueAsset* Asset = Cast<UDialogueAsset>(CachedEditor.Pin()->GetEditingAsset()))
	{
		Asset->AppearanceTableData = DialogueEditorManager->GetAppearanceTableData();
	}
}

void FDialogueEditorSceneProxy::SpawnDialogueActor(UDialogueActor* DialogueActorInfo) const
{
	DialogueEditorManager->SpawnEditorDialogueActor(DialogueActorInfo);
}

void FDialogueEditorSceneProxy::RemoveDialogueActor(UDialogueActor* DialogueActorInfo) const
{
	DialogueEditorManager->RemoveEditorDialogueActor(DialogueActorInfo);
}

void FDialogueEditorSceneProxy::SpawnDialogueSplineActor(class UDialogueEntity* DialogueEntity) const
{
	DialogueEditorManager->SpawnEditorDialogueActor(DialogueEntity);
}

void FDialogueEditorSceneProxy::SetPreviewActorsActive(bool IsActive)
{
	if (IsActive)
	{
		if (CachedEditor.IsValid())
		{
			DestroyPreviewActors(true);
		}
	}
	else
	{
		ResetPreviewWorld();
	}
}

void FDialogueEditorSceneProxy::RemoveDialogueSplineActor(class UDialogueEntity* DialogueEntity) const
{
	DialogueEditorManager->RemoveEditorDialogueActor(DialogueEntity);
}

void FDialogueEditorSceneProxy::SpawnRoutePointActor(class UDialogueEntity* DialogueEntity) const
{
	DialogueEditorManager->SpawnEditorDialogueActor(DialogueEntity);
}

void FDialogueEditorSceneProxy::RemoveRoutePoint(class UDialogueEntity* RoutePoint) const
{
	DialogueEditorManager->RemoveEditorDialogueActor(RoutePoint);
}

void FDialogueEditorSceneProxy::SpawnCamera(UDialogueCamera* CameraInfo) const
{
	DialogueEditorManager->SpawnEditorDialogueActor(CameraInfo);
}

void FDialogueEditorSceneProxy::RemoveCamera(UDialogueCamera* CameraInfo) const
{
	DialogueEditorManager->RemoveEditorDialogueActor(CameraInfo);
}

void FDialogueEditorSceneProxy::SpawnNewEntity(class UDialogueEntity* EntityInfo) const
{
	DialogueEditorManager->SpawnEditorDialogueActor(EntityInfo);
}

void FDialogueEditorSceneProxy::RemoveNewEntity(class UDialogueEntity* EntityInfo) const
{
	DialogueEditorManager->RemoveEditorDialogueActor(EntityInfo);
}

void FDialogueEditorSceneProxy::OnSpawnedEntity(const FString& EntityName, AActor* EntityActor) const
{
	if (EntityActor == nullptr) return;
	UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (Asset == nullptr) return;

	UDialogueEntity* DialogueEntity = Asset->FindAssetEntity(EntityName);
	if (DialogueEntity == nullptr) return;
	DialogueEntity->SetEntity(EntityActor);

	EntityActor->ClearFlags(EntityActor->GetFlags());
	EntityActor->SetFlags(EObjectFlags::RF_Transient);
	EntityActor->EditorTags.Add("KGStoryLine");
	EntityActor->SetFolderPath_Recursively(ActorFolderName);
}

void FDialogueEditorSceneProxy::OnActorMoved(AActor* InActor) const
{
	if (!CachedEditor.IsValid()) return;
	if (CachedEditor.Pin()->IsPlaying())
	{
		UE_LOG(LogTemp, Log, TEXT("播放过程中不允许移动Actor"));
		return;
	}

	UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (!Asset) return;
	if (DialogueEditorManager.IsValid())
	{
		DialogueEditorManager->OnActorMoved(Asset, InActor);
	}
}

void FDialogueEditorSceneProxy::OnPreviewStateChanged(bool InPlaying, bool InPause) const
{
	if (!CachedEditor.IsValid()) return;


	UDialogueBaseAsset* Asset = CachedEditor.Pin()->GetEditingAsset();
	if (!Asset) return;
	for (int32 i = 0; i < Asset->CameraList.Num(); ++i)
	{
		AActor* EntityActor = CachedEditor.Pin()->GetEntityActor(Asset->CameraList[i]);

		if (EntityActor == nullptr)
		{
			UE_LOG(LogTemp, Log, TEXT("entity actor is nullptr!"));
		}
		else
		{
			EntityActor->GetRootComponent()->SetVisibility(!InPlaying);
		}
	}
}

UDialogueEditorManager* FDialogueEditorSceneProxy::GetDialogueEditorManager() const
{
	if (DialogueEditorManager.IsValid())
	{
		return DialogueEditorManager.Get();
	}
	return nullptr;
}

void FDialogueEditorSceneProxy::DestroyPreviewScene()
{
	if (GetWorld())
	{
		DestroyPreviewActors(true);
		DialogueEditorManager->UnInitialize();
		RemoveDialogueWidget();
	}

    DestroyGossipBubbleManager();
    
	// 注销关心的事件
	GEngine->OnActorMoved().RemoveAll(this);
	// 注册事件
	FDialogueEditorDelegates::PreviewStateChangedEvent.RemoveAll(this);
	DestroyPlayerController();
	DestroyShakePreviewer();
}

UWorld* FDialogueEditorSceneProxy::GetWorld() const
{
	return CachedEditor.Pin()->GetWorld();
}

class UCameraShakeBase* FDialogueEditorSceneProxy::AddCameraShake(TSubclassOf<UCameraShakeBase> ShakeClass, UCameraShakeSourceComponent* ShakeSourceComponent)
{
	GetOrCreateShakePreviewer();
	return nullptr;
}

void FDialogueEditorSceneProxy::AddCameraFrameRadio(bool InBVertical)
{
	BFrameRadio = true;
	BVertical = InBVertical;
}

void FDialogueEditorSceneProxy::RemoveCameraFrameRadio()
{
	BFrameRadio = false;
}

bool FDialogueEditorSceneProxy::IsInRadioPreviewer() const
{
	return BFrameRadio;
}

bool FDialogueEditorSceneProxy::IsFrameRadioVertical() const
{
	return BVertical;
}

void FDialogueEditorSceneProxy::AddReferencedObjects(FReferenceCollector& Collector)
{
	Collector.AddReferencedObject(DialogueEditorManager);
}

void FDialogueEditorSceneProxy::AddDialogueWidget()
{
	if (DialogueWidget == nullptr)
	{
		DialogueWidget = DialogueEditorManager->ShowUIInEditor();
	}
}

void FDialogueEditorSceneProxy::RemoveDialogueWidget()
{
	if (DialogueWidget.IsValid())
	{
		DialogueWidget->StopAnimationsAndLatentActions();
		DialogueWidget->FlushAnimations();
		DialogueWidget.Reset();
	}
}