#include "DialogueEditor/DialogueEditorDelegates.h"


FDialogueEditorDelegates::FPreviewStateChanged FDialogueEditorDelegates::PreviewStateChangedEvent;

FDialogueEditorDelegates::FSectionInstanceNoticeLua FDialogueEditorDelegates::SectionInstanceNoticeLua;

FDialogueEditorDelegates::FOnTabActive FDialogueEditorDelegates::OnTabActive;

FDialogueEditorDelegates::FOnSectionSelect FDialogueEditorDelegates::OnSectionSelect;