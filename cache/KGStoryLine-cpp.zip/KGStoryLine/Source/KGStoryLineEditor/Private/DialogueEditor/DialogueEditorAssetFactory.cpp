#include "DialogueEditor/DialogueEditorAssetFactory.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/KGSLAssetCreateGuide.h"


UDialogueTemplateAssetFactory::UDialogueTemplateAssetFactory(const FObjectInitializer& ObjectInitializer)
{
	bCreateNew = true;
	bEditAfterNew = true;
	SupportedClass = UDialogueTemplateAsset::StaticClass();
}

UObject* UDialogueTemplateAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	UDialogueTemplateAsset* NewDialogue = NewObject<UDialogueTemplateAsset>(InParent, Class, Name, Flags | RF_Transactional);
	return NewDialogue;
}

UObject* UDialogueTemplateAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	return FactoryCreateNew(Class, InParent, Name, Flags, Context, Warn, NAME_None);
}

UDialogueAssetFactory::UDialogueAssetFactory(const FObjectInitializer& ObjectInitializer)
{
	bCreateNew = true;
	bEditAfterNew = true;
	if(HasAnyFlags(RF_ClassDefaultObject|RF_ArchetypeObject))
	{
		SupportedClass = UDialogueAsset::StaticClass();
	}
	else
	{
		const UDialogueEditorSettings* EditorSettings = GetDefault<UDialogueEditorSettings>();
		SupportedClass = EditorSettings->DialogueAssetClass;
	}
}

bool UDialogueAssetFactory::ConfigureProperties()
{
	const UDialogueEditorSettings* EditorSettings = GetDefault<UDialogueEditorSettings>();
	SupportedClass = EditorSettings->DialogueAssetClass;
	ConcreteClass = EditorSettings->DialogueAssetClass;
	
	TSharedPtr<FKGSLAssetCreateGuide> Guide = MakeShareable(new FKGSLAssetCreateGuide());
	Guide->OpenGuideWindow(true);
	if(Guide->GetParameters(AssetName, StoryLineID, TemplatePath))
	{
		return true;
	}
	
	return false;
}

FString UDialogueAssetFactory::GetDefaultNewAssetName() const
{
	if(!AssetName.IsEmpty())
	{
		return AssetName;
	}

	if(IsValid(ConcreteClass))
	{
		return FString(TEXT("New")) + ConcreteClass->GetName();
	}
	
	return FString(TEXT("New")) + GetSupportedClass()->GetName();
}

UObject* UDialogueAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext)
{
	UDialogueAsset* NewDialogue = NewObject<UDialogueAsset>(InParent, Class, Name, Flags | RF_Transactional);
	NewDialogue->StoryLineID = FCString::Atoi(*StoryLineID);
	NewDialogue->DialogueTemplate = LoadObject<UDialogueTemplateAsset>(nullptr, *TemplatePath);
	
	return NewDialogue;
}

UObject* UDialogueAssetFactory::FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	return FactoryCreateNew(Class, InParent, Name, Flags, Context, Warn, NAME_None);
}

const FString& UDialogueAssetFactory::GetAssetName() const
{
	return AssetName;
}
