#include "DialogueEditor/CustomLayout/DialogueCustomLayoutDialogueShotAction.h"

#include "DetailCategoryBuilder.h"
#include "DetailLayoutBuilder.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Dialogue/Actions/DialogueShotAction.h"

TArray<FString> FDialogueCustomLayoutDialogueShotAction::ShowDialogueCameraPropNames = {
	TEXT("FOV"),
	TEXT("bEnableLookAt"),
	TEXT("LookAtTarget"),
	TEXT("BoneName"),
	TEXT("OffsetZ"),
	TEXT("bOverride_DepthOfField"),
	TEXT("DepthOfFieldFocusActor"),
	TEXT("DepthOfFieldFocalDistance"),
	TEXT("DepthOfFieldFStop"),
	TEXT("DepthOfFieldSensorWidth"),
	};

TSharedRef<IDetailCustomization> FDialogueCustomLayoutDialogueShotAction::MakeInstance()
{
	return MakeShareable(new FDialogueCustomLayoutDialogueShotAction());
}

void FDialogueCustomLayoutDialogueShotAction::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	TArray<TWeakObjectPtr<UObject>> ObjectsCustomized;
	DetailBuilder.GetObjectsBeingCustomized(ObjectsCustomized);
	ensure(ObjectsCustomized.Num() == 1);

	TWeakObjectPtr<UObject> ObjCustomized = ObjectsCustomized[0];
	if(!ObjCustomized.IsValid())
	{
		return;
	}

	UDialogueShotAction* DialogueShotAction = Cast<UDialogueShotAction>(ObjCustomized.Get());
	if(!DialogueShotAction || !IsValid(DialogueShotAction))
	{
		return;
	}

	auto* DialogueAsset = GetDialogueAsset(DialogueShotAction);
	if (DialogueAsset && IsValid(DialogueAsset))
	{
		const FString CameraTrackName = DialogueShotAction->GetSectionName().ToString();	
		if (UDialogueCameraTrack* CameraTrack = Cast<UDialogueCameraTrack>(DialogueAsset->FindEpisodeTrackByName(1, FName(CameraTrackName))))
		{
			UDialogueEntity* DialogueEntity = CameraTrack->GetDialogueEntity();
			if (DialogueEntity == nullptr)
			{
				return;
			}
			TArray<FName> CategoryNames;
			DetailBuilder.GetCategoryNames(CategoryNames);
			int32 MaxSortOrder = 0;
			for (const auto& CategoryName : CategoryNames)
			{
				auto& CategoryBuilder = DetailBuilder.EditCategory(CategoryName);
				if (CategoryBuilder.GetSortOrder() >= MaxSortOrder)
				{
					MaxSortOrder = CategoryBuilder.GetSortOrder();
				}
			}

			// create detail panel
			static const FName LineCategoryName(TEXT("机位"));
			auto& BuilderLine = DetailBuilder.EditCategory(LineCategoryName, FText::GetEmpty(),
														   ECategoryPriority::Default);
			BuilderLine.SetSortOrder(MaxSortOrder + 1);

			FAddPropertyParams AddPropertyParams;
			AddPropertyParams.HideRootObjectNode(true);
			AddPropertyParams.AllowChildren(true);
			AddPropertyParams.CreateCategoryNodes(true);
			
			for (TFieldIterator<FProperty> PropIt(DialogueEntity->GetClass()); PropIt; ++PropIt)
			{
				if (!PropIt->HasAnyPropertyFlags(CPF_Transient) && ShowDialogueCameraPropNames.Contains(PropIt->GetName()))
				{
					BuilderLine.AddExternalObjectProperty({DialogueEntity}, PropIt->GetFName(), EPropertyLocation::Default, AddPropertyParams);
				}
			}
		}
	}
}

UDialogueAsset* FDialogueCustomLayoutDialogueShotAction::GetDialogueAsset(UDialogueShotAction* Section)
{
	if(!Section || !IsValid(Section))
	{
		return nullptr;
	}

	UDialogueAsset* DialogueAsset = nullptr;
	UObject* Outer = Section;
	while(Outer && IsValid(Outer))
	{
		if(Outer->IsA(UDialogueAsset::StaticClass()))
		{
			DialogueAsset = Cast<UDialogueAsset>(Outer);
			break;
		}

		Outer = Outer->GetOuter();
	}

	if(DialogueAsset && IsValid(DialogueAsset))
	{
		return DialogueAsset;
	}
	
	return nullptr;
}