#include "DialogueEditor/CustomLayout/DialogueCustomLayoutBehaviorSelector.h"
#include "PropertyCustomizationHelpers.h"
#include "IDetailChildrenBuilder.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Widgets/Input/SSearchBox.h"


#define LOCTEXT_NAMESPACE "DialogueCustomLayout"

#pragma  optimize("",off)

class SActorCameraPicker : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnPickCameraDelegate, FName);
	DECLARE_DELEGATE_RetVal(bool, FIsSelectorValid);

	TSharedPtr<IPropertyHandle> PropertyHandle;
private:
	TArray<TSharedPtr<FName>> NameList;
	TMap<FName, FText> NameMap;
	TSharedPtr<SComboBox<TSharedPtr<FName>>> NameListBox;

	FOnPickCameraDelegate OnPickName;

	FIsSelectorValid IsSelectorValid;

public:
	SLATE_BEGIN_ARGS(SActorCameraPicker) {}
		SLATE_ARGUMENT(TSharedPtr<IPropertyHandle>, PropertyHandle)
		SLATE_EVENT(FOnPickCameraDelegate, OnPickName)
		SLATE_EVENT(FIsSelectorValid, IsSelectorValid)
		SLATE_END_ARGS()

public:
	FBehaviorActorSelector* GetRawStruct() const
	{
		FBehaviorActorSelector* Ret = nullptr;
		if (PropertyHandle)
		{
			void* RawData = nullptr;
			PropertyHandle->GetValueData(RawData);
			if (RawData)
			{
				Ret = static_cast<FBehaviorActorSelector*>(RawData);
			}
		}
		return Ret;
	}
	TSharedRef<SWidget> OnGenerateComboWidget(TSharedPtr<FName> InComboID)
	{
		if (InComboID.IsValid() && FBehaviorActorSelector::Owner.IsValid())
		{
			 if (UDialogueTrackBase* TargetTrack = FBehaviorActorSelector::Owner->FindTrackByName(0, *InComboID))
				 return SNew(STextBlock).Text(FText::FromName(*TargetTrack->GetEditorPreviewFullName()));
			 return SNew(STextBlock).Text(FText::FromName(*InComboID));
		}

		return SNew(STextBlock).Text(FText());
	}

	void OnComboSelectionChanged(TSharedPtr<FName> NewValue, ESelectInfo::Type SelectInfo)
	{
		if (GetRawStruct() && NewValue.IsValid())
		{
			FName Name;
			FText* NameText = NameMap.Find(*NewValue.Get());
			if (NameText)
			{
				Name = FName(*FTextInspector::GetSourceString(*NameText));
			}
			OnPickName.ExecuteIfBound(Name);
		}
	}

	FText GetSelectName() const
	{
		if (IsSelectorValid.IsBound() && !IsSelectorValid.Execute())
		{
			return FText();
		}
		FBehaviorActorSelector* Selector = GetRawStruct();
		if (Selector == nullptr)
		{
			return FText();
		}

		if (!Selector->TrackName.IsNone() && FBehaviorActorSelector::Owner.IsValid())
		{
			auto Tracks = FBehaviorActorSelector::Owner->GetAllTracks(0);
			for (const auto& Track : Tracks)
			{
				if (*FTextInspector::GetSourceString(Track->GetTrackName()) == Selector->TrackName)
				{
					return FText::FromString(Track->GetEditorPreviewFullName());
				}
			}
		}

		return FText();
	}

	void RefreshNameList()
	{
		NameList.Empty();
		NameMap.Empty();
		FBehaviorActorSelector* Selector = GetRawStruct();
		if (!Selector || !FBehaviorActorSelector::Owner.IsValid())
			return;

		FDialogueEpisode* Episode = FBehaviorActorSelector::Owner->GetEpisodePointerByIndex(0);

		TArray<UDialogueTrackBase*> Tracks = Episode->GetAllTracks();
		NameList.Add(MakeShared<FName>(TEXT("")));
		NameMap.Emplace(FName(), FText::GetEmpty());
		for (int32 i = 0; i < Tracks.Num(); ++i)
		{
			if (Tracks[i]->IsA(UDialogueSpawnableTrack::StaticClass()))
			{
				FString Name = Tracks[i]->GetTrackName().ToString();
				NameList.Add(MakeShared<FName>(*Name));
				NameMap.Emplace(FName(Name), Tracks[i]->GetTrackName());
			}
		}
	}

	void Construct(const FArguments& InArgs)
	{
		this->PropertyHandle = InArgs._PropertyHandle;
		this->OnPickName = InArgs._OnPickName;
		this->IsSelectorValid = InArgs._IsSelectorValid;

		RefreshNameList();

		this->ChildSlot
			[
				SAssignNew(NameListBox, SComboBox<TSharedPtr<FName>>)
				.OptionsSource(&NameList)
			.OnComboBoxOpening(this, &SActorCameraPicker::RefreshNameList)
			.OnGenerateWidget(this, &SActorCameraPicker::OnGenerateComboWidget)
			.OnSelectionChanged(this, &SActorCameraPicker::OnComboSelectionChanged)
			[
				SNew(STextBlock)
				.Text(this, &SActorCameraPicker::GetSelectName)
			]
			];
	}
};

void FDialogueBehaviorSelectorLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
	.ValueContent()
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			[
				SNew(SActorCameraPicker)
		.PropertyHandle(InPropertyHandle.ToSharedPtr())
		.OnPickName(this, &FDialogueBehaviorSelectorLayout::SetName)
		.IsSelectorValid(this, &FDialogueBehaviorSelectorLayout::IsSelectorValid)
			]
		]
		;
}
void FDialogueBehaviorSelectorLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{

}

FBehaviorActorSelector* FDialogueBehaviorSelectorLayout::GetRawStructData(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = nullptr;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
	{
		FBehaviorActorSelector* Selector = static_cast<FBehaviorActorSelector*>(RawData);
		return Selector;
	}

	return nullptr;
}

void FDialogueBehaviorSelectorLayout::SetName(FName InName)
{
	if (FBehaviorActorSelector* CameraSelector = GetRawStructData(PropertyHandle.ToSharedRef()))
	{
	    CameraSelector->TrackName = InName;
	    PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

bool FDialogueBehaviorSelectorLayout::IsSelectorValid()
{
	if (!PropertyHandle.IsValid())
		return false;
	FBehaviorActorSelector* Selector = GetRawStructData(PropertyHandle.ToSharedRef());
	if (Selector == nullptr)
		return false;
	return true;
}
#undef LOCTEXT_NAMESPACE

#pragma  optimize("",on)
