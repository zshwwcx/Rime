// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/CustomLayout/KGSLEdCustomLayoutDialogueLine.h"

#include "DetailLayoutBuilder.h"
#include "DetailWidgetRow.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "IDetailChildrenBuilder.h"
#include "IDetailGroup.h"
#include "KGStoryLineDefine.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"

/*
 * FKGSLEdDialogueLineLayout
 */

TSharedRef<IPropertyTypeCustomization> FKGSLEdDialogueLineLayout::MakeInstance()
{
	return MakeShareable(new FKGSLEdDialogueLineLayout());
}

void FKGSLEdDialogueLineLayout::CustomizeHeader(TSharedRef<IPropertyHandle> PropertyHandle,
                                                FDetailWidgetRow& HeaderRow,
                                                IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	FString Name(TEXT("台本"));
	TSharedPtr<IPropertyHandleArray> ArrayHandle = PropertyHandle->GetParentHandle()->AsArray();
	if (ArrayHandle.IsValid() && PropertyHandle->GetArrayIndex() != INDEX_NONE)
	{
		Name.Appendf(TEXT("[%d]"), PropertyHandle->GetArrayIndex());
	}

	FString Content;
	TSharedPtr<IPropertyHandle> ContentHandler = PropertyHandle->GetChildHandle(TEXT("ContentString"));
	if(ContentHandler.IsValid())
	{
		ContentHandler->GetValue(Content);
	}

	FSlateFontInfo FontStyle = FAppStyle::GetFontStyle(TEXT("PropertyWindow.NormalFont"));
	
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget(FText::FromString(Name))
		]
		.ValueContent()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Left)
		.MinDesiredWidth(300)
		[
			SNew(SBox)
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Center)
			[
				SNew(STextBlock)
				.Text(FText::FromString(Content))
				.Font(FontStyle)
			]
		];
}

void FKGSLEdDialogueLineLayout::ExtractExtensionData(IDetailChildrenBuilder& ChildBuilder, TMap<FName, IDetailGroup*>& MapGroups, TSharedPtr<IPropertyHandle> HandleExtension)
{
	uint32 ChildrenCount = 0;
	HandleExtension->GetNumChildren(ChildrenCount);
	for(uint32 ChildIndex = 0; ChildIndex < ChildrenCount; ChildIndex++)
	{
		auto ChildPropertyHandle = HandleExtension->GetChildHandle(ChildIndex);

		auto Name = ChildPropertyHandle->GetPropertyDisplayName();
		uint32 Count = 0;
		ChildPropertyHandle->GetNumChildren(Count);
		if(ChildPropertyHandle->GetProperty() == nullptr && Count > 0)
		{
			ExtractExtensionData(ChildBuilder, MapGroups, ChildPropertyHandle);
			continue;
		}
		
		FText CategoryText = ChildPropertyHandle->GetDefaultCategoryText();
		if(CategoryText.IsEmpty())
		{
			continue;
		}
		
		FName CategoryName( CategoryText.ToString());
		if(CategoryText.ToString().Equals(TEXT("Default"), ESearchCase::IgnoreCase))
		{
			// 将Default分类的属性平铺
			ChildBuilder.AddProperty(ChildPropertyHandle.ToSharedRef());
			// uint32 SubCount = 0;
			// ChildPropertyHandle->GetNumChildren(SubCount);
			// for(uint32 Index = 0; Index < SubCount; Index++)
			// {
			// 	auto SubHandle = ChildPropertyHandle->GetChildHandle(Index);
			// 	ChildBuilder.AddProperty(SubHandle.ToSharedRef());
			// }
		}
		else
		{
			int32 Index = CategoryText.ToString().Find(TEXT("|"), ESearchCase::IgnoreCase); 
			if(Index != INDEX_NONE)
			{
				CategoryName = FName(CategoryText.ToString().Mid(Index + 1));
			}

			if(!MapGroups.Contains(CategoryName))
			{
				IDetailGroup& Group = ChildBuilder.AddGroup(CategoryName, FText::FromName(CategoryName));
				MapGroups.Add(CategoryName, &Group);
			}
			
			if(MapGroups.Contains(CategoryName) && MapGroups[CategoryName])
			{
				MapGroups[CategoryName]->AddPropertyRow(ChildPropertyHandle.ToSharedRef());
			}
			else
			{
				ChildBuilder.AddProperty(ChildPropertyHandle.ToSharedRef());
			}
		}
	}
}

TSharedPtr<IPropertyHandle> FKGSLEdDialogueLineLayout::FindRealExtensionProperty(TSharedPtr<IPropertyHandle> HandleExtension)
{
	if(!HandleExtension.IsValid())
	{
		return nullptr;
	}

	TSharedPtr<IPropertyHandle> Handle = HandleExtension->GetChildHandle(FName(TEXT("EpisodeID")));
	if(Handle.IsValid())
	{
		return  Handle->GetParentHandle();
	}

	return nullptr;
}

void FKGSLEdDialogueLineLayout::CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle,
                                                  IDetailChildrenBuilder& ChildBuilder,
                                                  IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	static const FName ObjectName = UKGSLDialogueLine::StaticClass()->GetFName();

	FName NameGUID(TEXT("GUID"));
	TSharedPtr<IPropertyHandle> Handle = PropertyHandle->GetChildHandle(NameGUID);
	if(!Handle.IsValid())
	{
		return;
	}


	TSharedPtr<IPropertyHandle> LinePropertyHandle = Handle->GetParentHandle();
	if(!LinePropertyHandle.IsValid())
	{
		return;
	}
		
	TMap<FName, IDetailGroup*> MapGroups;
	uint32 ChildrenCount = 0;
	LinePropertyHandle->GetNumChildren(ChildrenCount);
	
	for (uint32 ChildIndex = 0; ChildIndex < ChildrenCount; ++ChildIndex)
	{
		auto ChildPropertyHandle = LinePropertyHandle->GetChildHandle(ChildIndex);
		FName CategoryName = ChildPropertyHandle->GetDefaultCategoryName();
		if (!CategoryName.IsEqual(ObjectName) && !MapGroups.Contains(CategoryName))
		{
			IDetailGroup* Group = &ChildBuilder.AddGroup(CategoryName, FText::FromName(CategoryName));
			MapGroups.Add(CategoryName, Group);
		}
		
		if(MapGroups.Contains(CategoryName) && MapGroups[CategoryName])
		{
			MapGroups[CategoryName]->AddPropertyRow(ChildPropertyHandle.ToSharedRef());	
		}
		else
		{
			ChildBuilder.AddProperty(ChildPropertyHandle.ToSharedRef());
		}
	}
}

/*
 * FKGSLEdCustomizationLayoutDialogueLine
 */

TSharedRef<IDetailCustomization> FKGSLEdCustomLayoutDialogueLine::MakeInstance()
{
	return MakeShareable(new FKGSLEdCustomLayoutDialogueLine());
}

void FKGSLEdCustomLayoutDialogueLine::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	FString FirstCategoryStr;
	if(UClass* Class = DetailBuilder.GetBaseClass())
	{
		FirstCategoryStr = Class->GetName();
	}

	if(FirstCategoryStr.IsEmpty())
	{
		return;
	}

	FName FirstCategoryName(FirstCategoryStr);
	IDetailCategoryBuilder& CategoryBase = DetailBuilder.EditCategory(FirstCategoryName);
	
	TArray<FName> CategoryNames;
	DetailBuilder.GetCategoryNames(CategoryNames);
	CategoryNames.Remove(FirstCategoryName);

	TMap<FString, TArray<TSharedRef<IPropertyHandle>>> MapSubCategories;
	for(FName CategoryName : CategoryNames)
	{
		IDetailCategoryBuilder& CategoryBuilder = DetailBuilder.EditCategory(CategoryName);
		TArray<TSharedRef<IPropertyHandle>> OutAllProperties;
		CategoryBuilder.GetDefaultProperties(OutAllProperties);
		for(auto PropertyHandle : OutAllProperties)
		{
			if(PropertyHandle->GetDefaultCategoryName().IsEqual(TEXT("Default")))
			{				
				CategoryBase.AddProperty(PropertyHandle, EPropertyLocation::Common);
				DetailBuilder.HideCategory(CategoryName);
			}
			else
			{
				FString StrCategoryName = CategoryName.ToString();
				int32 Index = StrCategoryName.Find(TEXT("|")); 
				if( Index != INDEX_NONE)
				{
					DetailBuilder.HideCategory(CategoryName);
					StrCategoryName = StrCategoryName.Mid(Index + 1);
				}

				TArray<TSharedRef<IPropertyHandle>>& PropertyHandles = MapSubCategories.FindOrAdd(StrCategoryName);
				PropertyHandles.Add(PropertyHandle);
			}
		}
	}
	
	for(auto Iter : MapSubCategories)
	{
		IDetailCategoryBuilder& Category = DetailBuilder.EditCategory(FName(Iter.Key));
		for(auto PropertyHandle : Iter.Value)
		{
			Category.AddProperty(PropertyHandle);
		}
	}
}
