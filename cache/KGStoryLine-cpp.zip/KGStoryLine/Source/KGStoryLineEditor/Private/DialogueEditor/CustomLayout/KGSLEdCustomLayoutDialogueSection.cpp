#include "DialogueEditor/CustomLayout/KGSLEdCustomLayoutDialogueSection.h"

#include "AkWaapiClient.h"
#include "DetailCategoryBuilder.h"
#include "DetailLayoutBuilder.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "Debug/ReporterGraph.h"

TSharedRef<IDetailCustomization> FKGSLEdCustomLayoutDialogueSection::MakeInstance()
{
	return MakeShareable(new FKGSLEdCustomLayoutDialogueSection());
}

void FKGSLEdCustomLayoutDialogueSection::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	TArray<TWeakObjectPtr<UObject>> ObjectsCustomized;
	DetailBuilder.GetObjectsBeingCustomized(ObjectsCustomized);
	ensure(ObjectsCustomized.Num() == 1);

	TWeakObjectPtr<UObject> ObjCustomized = ObjectsCustomized[0];
	if(!ObjCustomized.IsValid())
	{
		return;
	}

	UDialogueDialogue* DialogueSection = Cast<UDialogueDialogue>(ObjCustomized.Get());
	if(!DialogueSection || !IsValid(DialogueSection))
	{
		return;
	}

	if(DialogueSection->FromLineIndex == INDEX_NONE)
	{
		return;
	}

	auto* DialogueAsset = GetDialogueAsset(DialogueSection);
	if (DialogueAsset && IsValid(DialogueAsset))
	{
		// find the line
		if (auto* LineSelected = DialogueAsset->GetDialogueLine(DialogueSection->OwnedEpisodeID,
		                                                        DialogueSection->FromLineIndex))
		{
			TArray<FName> CategoryNames;
			DetailBuilder.GetCategoryNames(CategoryNames);
			int32 MaxSortOrder = 0;
			for (const auto& CategoryName : CategoryNames)
			{
				auto& CategoryBuilder = DetailBuilder.EditCategory(CategoryName);
				if (CategoryBuilder.GetSortOrder() >= MaxSortOrder)
				{
					MaxSortOrder = CategoryBuilder.GetSortOrder();
				}
			}

			// create detail panel
			static const FName LineCategoryName(TEXT("台本"));
			auto& BuilderLine = DetailBuilder.EditCategory(LineCategoryName, FText::GetEmpty(),
			                                               ECategoryPriority::Default);
			BuilderLine.SetSortOrder(MaxSortOrder + 1);

			TArray<UObject*> Objects = {LineSelected};

			FAddPropertyParams AddPropertyParams;
			AddPropertyParams.HideRootObjectNode(true);
			AddPropertyParams.AllowChildren(true);
			AddPropertyParams.CreateCategoryNodes(true);
			
			for (TFieldIterator<FProperty> it(LineSelected->StaticClass()); it; ++it)
			{
				if (!it->HasAnyPropertyFlags(CPF_Transient))
				{
					BuilderLine.AddExternalObjectProperty(Objects, it->GetFName(),
													  EPropertyLocation::Default, AddPropertyParams);
				}
			}
		}
	}
}

UDialogueAsset* FKGSLEdCustomLayoutDialogueSection::GetDialogueAsset(UDialogueDialogue* Section)
{
	if(!Section || !IsValid(Section))
	{
		return nullptr;
	}

	UDialogueAsset* DialogueAsset = nullptr;
	UObject* Outer = Section;
	while(Outer && IsValid(Outer))
	{
		if(Outer->IsA(UDialogueAsset::StaticClass()))
		{
			DialogueAsset = Cast<UDialogueAsset>(Outer);
			break;
		}

		Outer = Outer->GetOuter();
	}

	if(DialogueAsset && IsValid(DialogueAsset))
	{
		return DialogueAsset;
	}
	
	return nullptr;
}
