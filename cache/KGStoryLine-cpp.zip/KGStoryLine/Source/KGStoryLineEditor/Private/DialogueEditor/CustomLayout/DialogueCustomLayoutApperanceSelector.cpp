#include "DialogueEditor/CustomLayout/DialogueCustomLayoutApperanceSelector.h"
#include "PropertyCustomizationHelpers.h"
#include "IDetailChildrenBuilder.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Widgets/Input/SSearchBox.h"
#include "SSearchableComboBox.h"


#define LOCTEXT_NAMESPACE "DialogueCustomLayout"

#pragma  optimize("",off)

class SApperancePicker : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnPickAppearanceDelegate, FAppreanceDataItem);
	DECLARE_DELEGATE_RetVal(bool, FIsSelectorValid);

private:
	//目标ApperanceID 属性Handle
	TWeakPtr<IPropertyHandle> PropertyHandle;

	//类型下拉框要显示的列表
	TArray<TSharedPtr<FString>> ApperanceTableTypeList;

	//外观下拉框要显示的列表
	TArray<TSharedPtr<FString>> ApperanceIDListSearch;

	//外界传入的所有外观数据
	TMap<FString, FAppreanceTableData> AppearanceDataTable;

	//外观下拉框组件
	TSharedPtr<SSearchableComboBox> ApperanceIDSearchComboBox;

	FOnPickAppearanceDelegate OnPickApperanceID;

	FIsSelectorValid IsSelectorValid;

	//选择一个外观类型后，这个就是外观类型的值如 玩家
	FString          FilterString;

public:
	SLATE_BEGIN_ARGS(SApperancePicker){}
		SLATE_EVENT(FOnPickAppearanceDelegate, OnPickApperanceID)
		SLATE_EVENT(FIsSelectorValid, IsSelectorValid)
		SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, TSharedRef<IPropertyHandle> InPropertyHandle)
	{
		this->OnPickApperanceID = InArgs._OnPickApperanceID;
		this->IsSelectorValid = InArgs._IsSelectorValid;
		PropertyHandle = InPropertyHandle;

		FDialogueAppearanceSelector* AppearanceSelector = GetAppearanceSelector();
		AppearanceDataTable = AppearanceSelector->Owner->AppearanceTableData;

		RefreshAppearanceTypeList();

		if (AppearanceSelector->ApperanceID)
		{
			for (auto& [key, value] : AppearanceDataTable)
			{
				if (const FAppreanceDataItem* Item = value.FindID(AppearanceSelector->ApperanceID))
				{
					FilterString = key;
					break;
				}
			}
		}
		RefreshAppearanceTableIDList();
		this->ChildSlot
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
			.Padding(2.0f, 2.0f)
			.VAlign(VAlign_Fill)
			.FillWidth(0.4f)
			[
				SNew(SComboBox<TSharedPtr<FString>>)
				.OptionsSource(&ApperanceTableTypeList)
			.OnComboBoxOpening(this, &SApperancePicker::RefreshAppearanceTypeList)
			.OnGenerateWidget(this, &SApperancePicker::OnGenerateTypeComboWidget)
			.OnSelectionChanged(this, &SApperancePicker::OnTypeComboSelectionChanged)
			[
				SNew(STextBlock)
				.Text(this, &SApperancePicker::GetSelectAppearanceType)
			]
			]
		+ SHorizontalBox::Slot()
			.Padding(2.0f, 2.0f)
			.VAlign(VAlign_Fill)
			.FillWidth(0.6f)
			[
				SAssignNew(ApperanceIDSearchComboBox, SSearchableComboBox)
				.OptionsSource(&ApperanceIDListSearch)
			.OnComboBoxOpening(this, &SApperancePicker::RefreshAppearanceTableIDList)
			.OnGenerateWidget(this, &SApperancePicker::OnGenerateAppreanceItem)
			.OnSelectionChanged(this, &SApperancePicker::OnApperanceItemChange)
			[
				SNew(STextBlock)
				.Text(this, &SApperancePicker::GetSelectAppearanceID)
			]
			]
			];
	}
	TSharedRef<SWidget> OnGenerateAppreanceItem(TSharedPtr<FString> InComboID)
	{
		if (InComboID.IsValid())
		{
			return SNew(STextBlock).Text(FText::FromString(*InComboID));
		}
		return SNew(STextBlock).Text(FText());
	}
	FDialogueAppearanceSelector* GetAppearanceSelector() const
	{
		void* RawData = nullptr;
		PropertyHandle.Pin()->GetValueData(RawData);

		if (RawData)
		{
			FDialogueAppearanceSelector* Ret = static_cast<FDialogueAppearanceSelector*>(RawData);
			return Ret;
		}
		return nullptr;
	}
	TSharedRef<SWidget> OnGenerateTypeComboWidget(TSharedPtr<FString> InComboID)
	{
		if (InComboID.IsValid())
			return SNew(STextBlock).Text(FText::FromString(*InComboID));

		return SNew(STextBlock).Text(FText());
	}

	void OnTypeComboSelectionChanged(TSharedPtr<FString> NewValue, ESelectInfo::Type SelectInfo)
	{
		if (GetAppearanceSelector() && NewValue.IsValid())
			FilterString = *NewValue;
		//类型改变后，需要更新具体的外观列表，并默认选中第一个外观
		RefreshAppearanceTableIDList();
		OnApperanceItemChange(ApperanceIDListSearch[0], ESelectInfo::Type::Direct);
	}

	void OnApperanceItemChange(TSharedPtr<FString> NewValue, ESelectInfo::Type SelectInfo)
	{
		if (GetAppearanceSelector() && NewValue.IsValid())
		{
			TArray<FString> StrArray;
			NewValue->ParseIntoArray(StrArray, TEXT(" "));
			int IDValue = FCString::Atoi(*StrArray[0]);

			TArray<FAppreanceTableData> IDList;
			AppearanceDataTable.GenerateValueArray(IDList);
			for (auto& Data : IDList)
			{
				if (const FAppreanceDataItem* Item = Data.FindID(IDValue))
				{
					OnPickApperanceID.ExecuteIfBound(*Item);
				}
			}
		}
	}

	FText GetSelectAppearanceID() const
	{
		if (IsSelectorValid.IsBound() && !IsSelectorValid.Execute())
		{
			return FText();
		}
		FDialogueAppearanceSelector* AppearanceSelector = GetAppearanceSelector();
		if (AppearanceSelector != nullptr && AppearanceSelector->ApperanceID != 0)
		{
			for (auto& [key, value] : AppearanceDataTable)
			{
				if (const FAppreanceDataItem* Item = value.FindID(AppearanceSelector->ApperanceID))
				{
					return FText::FromString(FString::Printf(TEXT("%d %s"), Item->ID, *Item->Name));
				}
			}
			return FText::FromString(FString::FromInt(AppearanceSelector->ApperanceID));
		}
		return FText();
	}

	FText GetSelectAppearanceType() const
	{
		if (IsSelectorValid.IsBound() && !IsSelectorValid.Execute())
		{
			return FText();
		}
		FDialogueAppearanceSelector* AppearanceSelector = GetAppearanceSelector();
		if (AppearanceSelector != nullptr)
		{
			for (auto& [key, value] : AppearanceDataTable)
			{
				if (const FAppreanceDataItem* Item = value.FindID(AppearanceSelector->ApperanceID))
				{
					if (key != FilterString)
					{//filter竟然不一致，说明是代码自行修改了AppearanceID，没有走UI修改，这里需要重新ApperanceID列表元素
						MutableThis()->FilterString = key;
						MutableThis()->RefreshAppearanceTableIDList();
					}
					break;
				}
			}
		}

		return FText::FromString(FilterString);
	}

	SApperancePicker* MutableThis() const
	{
		return const_cast<SApperancePicker*>(this);
	}

	void RefreshAppearanceTypeList()
	{
		FDialogueAppearanceSelector* AppearanceSelector = GetAppearanceSelector();
		if (!AppearanceSelector || !AppearanceSelector->Owner)
			return;

		ApperanceTableTypeList.Empty();

		TArray<FString> KeyArray;
		AppearanceSelector->Owner->AppearanceTableData.GenerateKeyArray(KeyArray);
		for (auto& Type : KeyArray)
			ApperanceTableTypeList.Add(MakeShared<FString>(Type));
	}

	void RefreshAppearanceTableIDList()
	{
		FDialogueAppearanceSelector* AppearanceSelector = GetAppearanceSelector();
		if (!AppearanceSelector || !AppearanceSelector->Owner)
			return;
		ApperanceIDListSearch.Empty();
		if (const FAppreanceTableData* Data = AppearanceDataTable.Find(FilterString))
		{
			for (auto& AppearanceItem : Data->AppreanceID)
			{
				ApperanceIDListSearch.Add(MakeShared<FString>(FString::Printf(TEXT("%d %s"), AppearanceItem.ID, *AppearanceItem.Name)));
			}
		}

		if (ApperanceIDSearchComboBox)
			ApperanceIDSearchComboBox->RefreshOptions();
	}

	
};

void FDialogueAppearanceSelectorLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;

	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
	.ValueContent()
		[
			SNew(SApperancePicker, InPropertyHandle)
		.OnPickApperanceID(this, &FDialogueAppearanceSelectorLayout::SetAppearanceID)
		.IsSelectorValid(this, &FDialogueAppearanceSelectorLayout::IsSelectorValid)
		];
}
void FDialogueAppearanceSelectorLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{

}

FDialogueAppearanceSelector* FDialogueAppearanceSelectorLayout::GetRawStructData(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
	{
		FDialogueAppearanceSelector* AppearanceSelector = static_cast<FDialogueAppearanceSelector*>(RawData);
		return AppearanceSelector;
	}

	return NULL;
}

void FDialogueAppearanceSelectorLayout::SetAppearanceID(FAppreanceDataItem InAppearanceID)
{
	if (FDialogueAppearanceSelector* AppearanceSelector = GetRawStructData(PropertyHandle.ToSharedRef()))
	{
		AppearanceSelector->ApperanceID = InAppearanceID.ID;

		UDialogueAsset* Asset = AppearanceSelector->Owner;
		TArray<UDialogueTrackBase*> AllTracks = Asset->GetAllTracks(0);

		PropertyHandle->NotifyFinishedChangingProperties();
	}
}

bool FDialogueAppearanceSelectorLayout::IsSelectorValid()
{
	if (PropertyHandle.IsValid())
	{
		FDialogueAppearanceSelector* AppearanceSelector = GetRawStructData(PropertyHandle.ToSharedRef());
		if (!AppearanceSelector)
		{
			return false;
		}
	}
	else {
		return false;
	}
	return true;
}

#undef LOCTEXT_NAMESPACE

#pragma  optimize("",on)
