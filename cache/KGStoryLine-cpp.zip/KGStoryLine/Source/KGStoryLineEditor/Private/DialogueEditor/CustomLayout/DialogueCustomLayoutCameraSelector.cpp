#include "DialogueEditor/CustomLayout/DialogueCustomLayoutCameraSelector.h"
#include "PropertyCustomizationHelpers.h"
#include "IDetailChildrenBuilder.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "IPropertyUtilities.h"
#include "Widgets/Input/SSearchBox.h"


#define LOCTEXT_NAMESPACE "DialogueCustomLayout"

#pragma  optimize("",off)
#define FROM_STRING_TEXT(STR) FText::Format(FText::FromString(TEXT("{0}")), FText::FromString(STR))

class SCameraPicker : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnPickCameraDelegate, FName);
	DECLARE_DELEGATE_RetVal(bool, FIsSelectorValid);

private:

	TArray<FName> CameraDisplayNameList;
	TMap<FName, FText> CameraNameMap;
	TSharedPtr<SComboBox<FName>> NameListBox;

	TWeakPtr<IPropertyHandle> PropertyHandle;
	FOnPickCameraDelegate OnPickCameraName;

	FIsSelectorValid IsSelectorValid ;

public:
	SLATE_BEGIN_ARGS(SCameraPicker){}
		SLATE_EVENT(FOnPickCameraDelegate, OnPickCameraName)
		SLATE_EVENT(FIsSelectorValid, IsSelectorValid)
		SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, TSharedRef<IPropertyHandle> InPropertyHandle)
	{
		this->OnPickCameraName = InArgs._OnPickCameraName;
		this->IsSelectorValid = InArgs._IsSelectorValid;
		PropertyHandle = InPropertyHandle;
		RefreshCameraNameList();

		this->ChildSlot
			[
				SAssignNew(NameListBox, SComboBox<FName>)
				.OptionsSource(&CameraDisplayNameList)
				.OnComboBoxOpening(this, &SCameraPicker::RefreshCameraNameList)
				.OnGenerateWidget(this, &SCameraPicker::OnGenerateComboWidget)
				.OnSelectionChanged(this, &SCameraPicker::OnComboSelectionChanged)
				[
					SNew(STextBlock)
					.Text(this, &SCameraPicker::GetSelectCameraName)
				]
			];
	}
	FDialogueCameraSelector* GetCameraSelector() const
	{
		if (!PropertyHandle.IsValid())
		{
			return nullptr;
		}
		
		void* RawData = nullptr;
		PropertyHandle.Pin()->GetValueData(RawData);

		if (RawData)
		{
			FDialogueCameraSelector* Ret = static_cast<FDialogueCameraSelector*>(RawData);
			return Ret;
		}
		return nullptr;
	}
	TSharedRef<SWidget> OnGenerateComboWidget(FName InComboID)
	{
		if (InComboID.IsValid())
			return SNew(STextBlock).Text(FText::FromName(InComboID));

		return SNew(STextBlock).Text(FText());
	}

	void OnComboSelectionChanged(FName NewValue, ESelectInfo::Type SelectInfo)
	{
		FDialogueCameraSelector* CameraSelector = GetCameraSelector();

		if (CameraSelector && NewValue.IsValid())
		{
			OnPickCameraName.ExecuteIfBound(FName(*FTextInspector::GetSourceString(CameraNameMap[NewValue])));
			//comment by kanzhengjie 不明白为什么这里选择Camera还要通知Editor选中Track？
			//CameraSelector->Owner->OnCustomSelectorChanged(NewValue.Get()->ToString());
		}
	}

	FText GetSelectCameraName() const
	{
		if (IsSelectorValid.IsBound() && !IsSelectorValid.Execute())
		{
			return FText();
		}
		
		if (FDialogueCameraSelector* CameraSelector = GetCameraSelector())
		{
			if (!CameraSelector->CameraName.IsEmpty())
			{
				auto Name = FName(*CameraSelector->CameraName);
				for (const auto& Pair : CameraNameMap)
				{
					if (CameraSelector->CameraName == *FTextInspector::GetSourceString(Pair.Value))
					{
						return FText::FromName(Pair.Key);
					}
				}
			}
		}
		
		return FText();
	}

	void RefreshCameraNameList()
	{
		CameraNameMap.Empty();
		CameraDisplayNameList.Empty();

		FDialogueCameraSelector* CameraSelector = GetCameraSelector();
		if (!CameraSelector || !FBehaviorActorSelector::Owner.IsValid())
			return;

		FDialogueEpisode* Episode = FBehaviorActorSelector::Owner->GetEpisodePointerByIndex(0);

		TMap<FString, UDialogueCameraTrack*> Cameras = Episode->GetTrackCameras();
		TArray<FString> CameraNames;
		Cameras.GenerateKeyArray(CameraNames);
		FName NewName = TEXT("");
		CameraDisplayNameList.Add(NewName);
		CameraNameMap.Add(NewName, FText::GetEmpty());
		for (auto& Elem : Cameras)
		{
			FName Name = FName(Elem.Value->GetEditorPreviewFullName());
			CameraDisplayNameList.Add(Name);
			CameraNameMap.Add(Name, Elem.Value->GetTrackName());
		}
	}

};

void FDialogueCameraSelectorLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;

	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
	.ValueContent()
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		[
			SNew(SCameraPicker, InPropertyHandle)
		.OnPickCameraName(this, &FDialogueCameraSelectorLayout::SetCameraName)
		.IsSelectorValid(this, &FDialogueCameraSelectorLayout::IsSelectorValid)
		]
		]
		;
}
void FDialogueCameraSelectorLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyUtilities = CustomizationUtils.GetPropertyUtilities();
}

FDialogueCameraSelector* FDialogueCameraSelectorLayout::GetRawStructData(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
	{
		FDialogueCameraSelector* CameraSelector = static_cast<FDialogueCameraSelector*>(RawData);
		return CameraSelector;
	}

	return NULL;
}

void FDialogueCameraSelectorLayout::SetCameraName(FName InName)
{
	if (FDialogueCameraSelector* CameraSelector = GetRawStructData(PropertyHandle.ToSharedRef()))
	{
		CameraSelector->CameraName = InName.ToString();
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
		TArray<UObject*> OuterObjects;
		PropertyHandle->GetOuterObjects(OuterObjects);
		if (PropertyUtilities.IsValid() && !OuterObjects.IsEmpty())
		{
			FPropertyChangedEvent ChangeEvent(PropertyHandle->GetProperty(), EPropertyChangeType::ValueSet, OuterObjects);
			PropertyUtilities->NotifyFinishedChangingProperties(ChangeEvent);
		}
		else
		{
			PropertyHandle->NotifyFinishedChangingProperties();
		}
	}
}

bool FDialogueCameraSelectorLayout::IsSelectorValid()
{
	if (PropertyHandle.IsValid())
	{
		FDialogueCameraSelector* CameraSelector = GetRawStructData(PropertyHandle.ToSharedRef());
		if (!CameraSelector)
		{
			return false;
		}
	}
	else {
		return false;
	}
	return true;
}

#undef LOCTEXT_NAMESPACE

#pragma  optimize("",on)
