
#include "DialogueEditor/CustomLayout/DialogueCustomLayoutPerformerSelector.h"
#include "PropertyCustomizationHelpers.h"
#include "IDetailChildrenBuilder.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "IPropertyUtilities.h"
#include "Widgets/Input/SSearchBox.h"


#define LOCTEXT_NAMESPACE "DialogueCustomLayout"

#pragma  optimize("",off)

#define FROM_STRING_TEXT(STR) FText::Format(FText::FromString(TEXT("{0}")), FText::FromString(STR))

class SPerformerPicker : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnPickPerformerDelegate, FName);
	DECLARE_DELEGATE_RetVal(bool, FIsSelectorValid);

private:
	FDialoguePerformerSelector* PrivatePerformerSelector = NULL;

	TArray<TSharedPtr<FName>> PerformerNameList;
	TMap<FName, FText> MapPerfomerName;
	TSharedPtr<SComboBox<TSharedPtr<FName>>> NameListBox;

	TWeakPtr<IPropertyHandle> PropertyHandle;
	FOnPickPerformerDelegate OnPickPerformerName;

	FIsSelectorValid IsSelectorValid;

public:
	SLATE_BEGIN_ARGS(SPerformerPicker) : _PrivatePerformerSelector(NULL) {}
	SLATE_ARGUMENT(FDialoguePerformerSelector*, PrivatePerformerSelector)
		SLATE_EVENT(FOnPickPerformerDelegate, OnPickPerformerName)
		SLATE_EVENT(FIsSelectorValid, IsSelectorValid)
		SLATE_END_ARGS()

public:

	void Construct(const FArguments& InArgs, TSharedRef<IPropertyHandle> InPropertyHandle)
	{
		this->PrivatePerformerSelector = InArgs._PrivatePerformerSelector;
		this->OnPickPerformerName = InArgs._OnPickPerformerName;
		this->IsSelectorValid = InArgs._IsSelectorValid;
		PropertyHandle = InPropertyHandle;
		RefreshPerformerNameList();

		this->ChildSlot
			[
				SAssignNew(NameListBox, SComboBox<TSharedPtr<FName>>)
				.OptionsSource(&PerformerNameList)
			.OnComboBoxOpening(this, &SPerformerPicker::RefreshPerformerNameList)
			.OnGenerateWidget(this, &SPerformerPicker::OnGenerateComboWidget)
			.OnSelectionChanged(this, &SPerformerPicker::OnComboSelectionChanged)
			[
				SNew(STextBlock)
				.Text(this, &SPerformerPicker::GetSelectPerformerName)
			]
			];
	}

	TSharedRef<SWidget> OnGenerateComboWidget(TSharedPtr<FName> InComboID)
	{
		FDialoguePerformerSelector* PerformerSelector = GetPerformerSelector();
		if (InComboID.IsValid() && FBehaviorActorSelector::Owner.IsValid())
		{
			if (UDialogueTrackBase* TargetTrack = FBehaviorActorSelector::Owner->FindTrackByName(0, *InComboID))
				return SNew(STextBlock).Text(FROM_STRING_TEXT(TargetTrack->GetEditorPreviewFullName()));
			return SNew(STextBlock).Text(FROM_STRING_TEXT(InComboID->ToString()));
		}

		return SNew(STextBlock).Text(FText());
	}

	FDialoguePerformerSelector* GetPerformerSelector() const 
	{
		void* RawData = nullptr;
		PropertyHandle.Pin()->GetValueData(RawData);

		if (RawData)
		{
			FDialoguePerformerSelector* Ret = static_cast<FDialoguePerformerSelector*>(RawData);
			return Ret;
		}
		return nullptr;
	}

	void OnComboSelectionChanged(TSharedPtr<FName> NewValue, ESelectInfo::Type SelectInfo)
	{
		FDialoguePerformerSelector* PerformerSelector = GetPerformerSelector();
		if (PerformerSelector && NewValue.IsValid() && FBehaviorActorSelector::Owner.IsValid())
		{
			FName Name;
			FText* TextName = MapPerfomerName.Find(*NewValue.Get());
			if (TextName)
			{
				Name = FName(*FTextInspector::GetSourceString(*TextName));
			}
			OnPickPerformerName.ExecuteIfBound(Name);
		}
	}

	FText GetSelectPerformerName() const
	{
		FDialoguePerformerSelector* PerformerSelector = GetPerformerSelector();
		if (PerformerSelector == nullptr || FBehaviorActorSelector::Owner == nullptr)
			return FText();
		if (IsSelectorValid.IsBound() && !IsSelectorValid.Execute())
		{
			return FText();
		}
		if (!PerformerSelector->PerformerName.IsEmpty())
		{
			
			if (PerformerSelector->PerformerName == TEXT("Asider"))
				return FROM_STRING_TEXT(PerformerSelector->PerformerName);

			auto Tracks = FBehaviorActorSelector::Owner->GetAllTracks(0);
			for (auto* Track : Tracks)
			{
				if (*FTextInspector::GetSourceString(Track->GetTrackName()) == PerformerSelector->PerformerName)
				{
					return FROM_STRING_TEXT(Track->GetEditorPreviewFullName());
				}
			}
		}

		return FROM_STRING_TEXT(TEXT("None"));
	}

	void RefreshPerformerNameList()
	{
		PerformerNameList.Empty();
		MapPerfomerName.Empty();
		FDialoguePerformerSelector* PerformerSelector = GetPerformerSelector();

		if (!PerformerSelector || !FBehaviorActorSelector::Owner.IsValid())
			return;

		FDialogueEpisode* Episode = FBehaviorActorSelector::Owner->GetEpisodePointerByIndex(0);
		if (Episode == nullptr)
			return;

		TMap<FString, UDialogueActorTrack*> Actors = Episode->GetTrackActors();
		TArray<FString> ActorNames;
		Actors.GenerateKeyArray(ActorNames);
		PerformerNameList.Add(MakeShared<FName>(TEXT("")));
		MapPerfomerName.Add(FName(), FText::GetEmpty());
		PerformerNameList.Add(MakeShared<FName>(TEXT("Asider")));  //旁白者
		MapPerfomerName.Emplace(FName(TEXT("Asider")), FText::FromString(TEXT("Asider")));
		for (int32 i = 0; i < ActorNames.Num(); ++i)
		{
			PerformerNameList.Add(MakeShared<FName>(ActorNames[i]));
			auto* TrackActor = Actors[ActorNames[i]];
			MapPerfomerName.Emplace(FName(ActorNames[i]), TrackActor->GetTrackName());
		}
	}

};

void FDialoguePerformerSelectorLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	bool bCanEdit = true;
	if (auto* Property = PropertyHandle->GetProperty())
	{
		bCanEdit &= !Property->HasAnyPropertyFlags(EPropertyFlags::CPF_BlueprintReadOnly | EPropertyFlags::CPF_EditConst);
	}

	HeaderRow
	.NameContent()
	[
		PropertyHandle->CreatePropertyNameWidget()
	]
	.ValueContent()
	[
	SNew(SHorizontalBox)
	+SHorizontalBox::Slot()
		[
			SNew(SPerformerPicker, InPropertyHandle)
			.PrivatePerformerSelector(GetRawStructData(InPropertyHandle))
			.OnPickPerformerName(this, &FDialoguePerformerSelectorLayout::SetPerformerName)
			.IsSelectorValid(this, &FDialoguePerformerSelectorLayout::IsSelectorValid)
			.IsEnabled(bCanEdit)
		]
	];

	if (FDialoguePerformerSelector* Selector = GetRawStructData(InPropertyHandle))
	{
		Selector->OnStructChange.BindLambda([this]()
		{
			FDialoguePerformerSelector* Performer = this->GetRawStructData(PropertyHandle.ToSharedRef());
			PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
		});
	}
}
void FDialoguePerformerSelectorLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyUtilities = CustomizationUtils.GetPropertyUtilities();
}

FDialoguePerformerSelector* FDialoguePerformerSelectorLayout::GetRawStructData(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = nullptr;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
	{
		FDialoguePerformerSelector* PerformerSelector = static_cast<FDialoguePerformerSelector*>(RawData);
		return PerformerSelector;
	}
	return nullptr;
}

void FDialoguePerformerSelectorLayout::SetPerformerName(FName InName)
{
	if (FDialoguePerformerSelector* PerformerSelector = GetRawStructData(PropertyHandle.ToSharedRef()))
	{
		PerformerSelector->PerformerName = InName.ToString();
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
		TArray<UObject*> OuterObjects;
		PropertyHandle->GetOuterObjects(OuterObjects);
		if (PropertyUtilities.IsValid() && !OuterObjects.IsEmpty())
		{
			FPropertyChangedEvent ChangeEvent(PropertyHandle->GetProperty(), EPropertyChangeType::ValueSet, OuterObjects);
			PropertyUtilities->NotifyFinishedChangingProperties(ChangeEvent);
		}
		else
		{
			PropertyHandle->NotifyFinishedChangingProperties();
		}
	}
}

bool FDialoguePerformerSelectorLayout::IsSelectorValid()
{
	if (PropertyHandle.IsValid())
	{
		FDialoguePerformerSelector* PerformerSelector = GetRawStructData(PropertyHandle.ToSharedRef());
		if (!PerformerSelector)
		{
			return false;
		}
	}
	else 
	{
		return false;
	}
	return true;
}
#undef LOCTEXT_NAMESPACE

#pragma  optimize("",on)
