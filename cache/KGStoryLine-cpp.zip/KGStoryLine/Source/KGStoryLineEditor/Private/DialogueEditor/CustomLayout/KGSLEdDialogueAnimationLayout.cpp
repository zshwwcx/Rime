// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/CustomLayout/KGSLEdDialogueAnimationLayout.h"

#include "AnimationEditorViewportClient.h"
#include "DetailWidgetRow.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "IStructureDetailsView.h"
#include "PropertyHandle.h"
#include "SEditorViewportToolBarMenu.h"
#include "Modules/ModuleManager.h"

#define LOCTEXT_NAMESPACE "KGSLEdDialogueAnimationLayout"

class FStructFromDialogueAnimations : public FStructOnScope
{
	TSharedPtr<IPropertyHandle> AnimProperty;

public:
	FStructFromDialogueAnimations(TSharedPtr<IPropertyHandle> InAnimProperty)
		: AnimProperty(InAnimProperty)
	{
	}

	virtual uint8* GetStructMemory() override
	{
		if(AnimProperty.IsValid())
		{
			void* Data;
			if(AnimProperty->GetValueData(Data) == FPropertyAccess::Result::Success)
			{
				return static_cast<uint8*>(Data);
			}
		}
		
		return nullptr;
	}

	virtual const uint8* GetStructMemory() const override
	{
		if(AnimProperty.IsValid())
		{
			void* Data;
			if(AnimProperty->GetValueData(Data) == FPropertyAccess::Result::Success)
			{
				return static_cast<const uint8*>(Data);
			}
		}
		
		return nullptr;
	}

	
	virtual const UScriptStruct* GetStruct() const override
	{
		return FDialogueAnimations::StaticStruct();
	}

	virtual UPackage* GetPackage() const override
	{
		return nullptr;
	}

	virtual void SetPackage(UPackage* InPackage) override
	{
	}

	virtual bool IsValid() const override
	{
		return AnimProperty.IsValid();
	}

	virtual void Destroy() override
	{
		AnimProperty = nullptr;
	}
};


TSharedRef<IPropertyTypeCustomization> FKGSLEdDialogueAnimationLayout::MakeInstance()
{
	return MakeShareable(new FKGSLEdDialogueAnimationLayout());
}

FKGSLEdDialogueAnimationLayout::~FKGSLEdDialogueAnimationLayout()
{
	if(StructureDetailsView.IsValid())
	{
		StructureDetailsView->SetStructureData(nullptr);
	}

	if(CurrentStructScope.IsValid())
	{
		CurrentStructScope->Destroy();
		CurrentStructScope.Reset();
	}
}

void FKGSLEdDialogueAnimationLayout::CustomizeHeader(TSharedRef<IPropertyHandle> PropertyHandle,
                                                     FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	AnimProperty = PropertyHandle;
	ConstructStructureDetailView(PropertyHandle);
	
	FString Name;
	TSharedPtr<IPropertyHandleArray> ArrayHandle = PropertyHandle->GetParentHandle()->AsArray();
	if (ArrayHandle.IsValid() && PropertyHandle->GetArrayIndex() != INDEX_NONE)
	{
		Name.Appendf(TEXT("%s[%d]"),
		             *PropertyHandle->GetParentHandle()->GetPropertyDisplayName().ToString(),
		             PropertyHandle->GetArrayIndex());
	}
	
	FString ValueStr;
	TSharedPtr<IPropertyHandle> PerformerHandle = PropertyHandle->GetChildHandle(TEXT("Performer"));
	if(PerformerHandle.IsValid())
	{
		TSharedPtr<IPropertyHandle> PerformerNameHandle = PerformerHandle->GetChildHandle(TEXT("PerformerName"));
		if(PerformerNameHandle.IsValid())
		{
			PerformerNameHandle->GetValue(ValueStr);
		}
	}
	
	FString AnimID;
	TSharedPtr<IPropertyHandle> SingleAnimationHandle = PropertyHandle->GetChildHandle(TEXT("SingleAnimation"));
	if(SingleAnimationHandle.IsValid())
	{
		TSharedPtr<IPropertyHandle> AnimHandle = SingleAnimationHandle->GetChildHandle(TEXT("AssetID"));
		if(AnimHandle.IsValid())
		{
			AnimHandle->GetValue(AnimID);
		}
	}

	if(!AnimID.IsEmpty())
	{
		ValueStr.Appendf( TEXT("/%s"), *AnimID);
	}
	
	FSlateFontInfo FontStyle = FAppStyle::GetFontStyle(TEXT("PropertyWindow.NormalFont"));

	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget(FText::FromString(Name))
		]
		.ValueContent()
		.MinDesiredWidth(350)
		.HAlign(HAlign_Fill)
		[
			SNew(SBox)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Fill)
			[
				StructureDetailsView->GetWidget().ToSharedRef()
			]
		];
}

void FKGSLEdDialogueAnimationLayout::CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle,
	IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	// uint32 ChildrenCount = 0;
	// PropertyHandle->GetNumChildren(ChildrenCount);
	// for(uint32 ChildIndex = 0; ChildIndex < ChildrenCount; ChildIndex++)
	// {
	// 	ChildBuilder.AddProperty(PropertyHandle->GetChildHandle(ChildIndex).ToSharedRef());
	// }
}

void FKGSLEdDialogueAnimationLayout::NotifyPreChange(FProperty* PropertyAboutToChange)
{
	if(AnimProperty.IsValid() && AnimProperty->IsValidHandle())
	{
		AnimProperty->NotifyPreChange();
	}
}

void FKGSLEdDialogueAnimationLayout::NotifyPostChange(const FPropertyChangedEvent& PropertyChangedEvent,
	FProperty* PropertyThatChanged)
{
	if(AnimProperty.IsValid() && AnimProperty->IsValidHandle())
	{
		AnimProperty->NotifyPostChange(PropertyChangedEvent.ChangeType);
	}
}

void FKGSLEdDialogueAnimationLayout::ConstructStructureDetailView(TSharedPtr<IPropertyHandle> InAnimProperty)
{
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	FDetailsViewArgs ViewArgs;
	ViewArgs.bAllowSearch = false;
	ViewArgs.bHideSelectionTip = false;
	ViewArgs.bShowObjectLabel = false;
	ViewArgs.NotifyHook = this;

	FStructureDetailsViewArgs StructureViewArgs;
	StructureViewArgs.bShowObjects = false;
	StructureViewArgs.bShowAssets = true;
	StructureViewArgs.bShowClasses = true;
	StructureViewArgs.bShowInterfaces = false;


	CurrentStructScope =  MakeShareable(new FStructFromDialogueAnimations(InAnimProperty));
		
	StructureDetailsView = PropertyModule.CreateStructureDetailView(ViewArgs, StructureViewArgs, CurrentStructScope, LOCTEXT("DialogueAnimationLayoutTitle", "Animation"));
}

#undef LOCTEXT_NAMESPACE