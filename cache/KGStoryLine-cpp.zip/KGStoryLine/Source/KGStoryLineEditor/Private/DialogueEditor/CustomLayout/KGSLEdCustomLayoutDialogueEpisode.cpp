// Fill out your copyright notice in the Description page of Project Settings.
#include "DialogueEditor/CustomLayout/KGSLEdCustomLayoutDialogueEpisode.h"
#include "PropertyCustomizationHelpers.h"
#include "DetailLayoutBuilder.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "IDetailChildrenBuilder.h"
#include "DialogueEditor/KGStoryLineScriptEditor.h"
#include "Widgets/Input/SButton.h"
#include "IDetailGroup.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SComboBox.h"
#include "Widgets/Input/SSpinBox.h"


#define LOCTEXT_NAMESPACE "KGSLEdDialogueEpisodeDetails"

FKGSLEdDialogueEpisodeDetails::FKGSLEdDialogueEpisodeDetails()
	: INotifyOnKGSLDataChanged(EKGSLDataChangeInfo::LineData, EKGSLDataChangeInfo::LineAdded, EKGSLDataChangeInfo::LineRemoved,
		EKGSLDataChangeInfo::LineSwapped, EKGSLDataChangeInfo::OptionData, EKGSLDataChangeInfo::OptionAdded, EKGSLDataChangeInfo::OptionRemoved,
		EKGSLDataChangeInfo::OptionSwapped, EKGSLDataChangeInfo::ImportDialog)
{
}

FKGSLEdDialogueEpisodeDetails::~FKGSLEdDialogueEpisodeDetails()
{
    if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
    {
        DialogueAsset->OnDialogueEpisodeChanged().Remove(EpisodeChangedHandle);
    }
}

TSharedRef<IPropertyTypeCustomization> FKGSLEdDialogueEpisodeDetails::MakeInstance()
{
    return MakeShareable(new FKGSLEdDialogueEpisodeDetails());
}

void FKGSLEdDialogueEpisodeDetails::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle,
                                                    FDetailWidgetRow& HeaderRow,
                                                    IPropertyTypeCustomizationUtils& CustomizationUtils)
{
    PropertyHandle = InPropertyHandle;
    UKGSLDialogueEpisode* Episode = GetEpisode();
    if (!IsValid(Episode))
    {
        return;
    }

    LineBoxes = SNew(SVerticalBox);
    OptionBoxes = SNew(SVerticalBox);

    FString StrEpisode = FString::Printf(TEXT("%s  %d"),
                                         *GET_MEMBER_NAME_CHECKED(UKGSLDialogueEpisode, EpisodeID).ToString(),
                                         Episode->GetEpisodeID());
    SAssignNew(TextBlockEpisode, STextBlock)
    .Text(FText::FromString(StrEpisode));

    Rebuild();
    if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
    {
        EpisodeChangedHandle = DialogueAsset->OnDialogueEpisodeChanged().AddSP(
            this, &FKGSLEdDialogueEpisodeDetails::OnEpisodeChanged);
    }

    PropertyOptionsHandle = InPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(UKGSLDialogueEpisode, Options));


    HeaderRow.NameContent()
        [
            PropertyHandle->CreatePropertyNameWidget()
        ]
        .ValueContent()
        [
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            .VAlign(VAlign_Center)
            .Padding(FMargin(2.0f, 0.f))
            .FillWidth(1.0f)
            [
                TextBlockEpisode.ToSharedRef()
            ]
        ];
}

void FKGSLEdDialogueEpisodeDetails::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle,
                                                      IDetailChildrenBuilder& ChildBuilder,
                                                      IPropertyTypeCustomizationUtils& CustomizationUtils)
{
    UKGSLDialogueEpisode* Episode = GetEpisode();
    if (!IsValid(Episode))
    {
        return;
    }

	/*uint32 NumChildProps = 0;
	InPropertyHandle->GetNumChildren(NumChildProps);

	TMap<FName, TSharedPtr<IPropertyHandle>> PropertyHandles;
	for (uint32 Idx = 0; Idx < NumChildProps; Idx++)
	{
		TSharedPtr<IPropertyHandle> PropHandle = InPropertyHandle->GetChildHandle(Idx);
		ChildBuilder.AddProperty(PropHandle.ToSharedRef());
		const FName PropertyName = PropHandle->GetProperty()->GetFName();
		PropertyHandles.Add(PropertyName, PropHandle);
	}*/

    TArray<UObject*> Objects = {Episode};
    for (TFieldIterator<FProperty> It(Episode->StaticClass()); It; ++It)
    {
        if(It->ShouldPort(PPF_PropertyWindow))
        {
            ChildBuilder.AddExternalObjectProperty(Objects, FName(It->GetName()));
        }
    }

	FDialogueEpisode* DialogueEpisode = GetDialogueEpisode();
	if (DialogueEpisode != nullptr)
	{
		TSharedRef<FStructOnScope> FDialogueEpisodeStruct = MakeShared<FStructOnScope>(FDialogueEpisode::StaticStruct(), (uint8*)DialogueEpisode);
		ChildBuilder.AddExternalStructureProperty(FDialogueEpisodeStruct, FName(TEXT("LoopTimes")));
	}

    IDetailGroup& LineGroup = ChildBuilder.AddGroup(TEXT("DialogueLines"), LOCTEXT("台本新", "台本新"));
    LineGroup.AddWidgetRow()
             .WholeRowContent()
    [
        SAssignNew(PropertyLineContent, SBox)
    ];

    PropertyLineContent->SetContent(LineBoxes.ToSharedRef());
    //LineGroup.AddWidgetRow()
			 //.ValueContent()
    //[
    //    SNew(SButton)
    //    .Text(FText::FromString(TEXT("打开台本编辑器")))
    //    .ContentPadding(FMargin(5, 2))
    //    .HAlign(HAlign_Center)
    //    .VAlign(VAlign_Center)
    //    .OnClicked(FOnClicked::CreateRaw(this, &FKGSLEdDialogueEpisodeDetails::OpenDialogueLinesEditor))
    //];

    IDetailGroup& OptionGroup = ChildBuilder.AddGroup(TEXT("Options"), LOCTEXT("选项", "选项"));
	OptionGroup.AddWidgetRow()
		.NameContent()
		[
			SNew(STextBlock)
				.Text(FText::FromString(FString::Printf(TEXT("选项类型"))))
		]
		.ValueContent()
		[
			SNew(SComboBox<TSharedPtr<FString>>)
				.IsEnabled(false)
				.OptionsSource(&OptionTypes)
				.OnSelectionChanged(this, &FKGSLEdDialogueEpisodeDetails::OnSelectionChanged)
				.OnGenerateWidget(this, &FKGSLEdDialogueEpisodeDetails::OnGenerateWidget)
				.InitiallySelectedItem(GetSelectedItem())
				.Content()
				[
					SNew(STextBlock)
						.Text(this, &FKGSLEdDialogueEpisodeDetails::GetSelectedValue)
				]
		];
	OptionGroup.AddWidgetRow()
		.NameContent()
		[
			SNew(STextBlock)
				.Text(FText::FromString(FString::Printf(TEXT("时间限制"))))
		]
		.ValueContent()
		[
			SNew(SSpinBox<double>)
				.IsEnabled(false)
				.MinValue(0)
				.Value(this, &FKGSLEdDialogueEpisodeDetails::OnGetTimeLimit)
				.OnValueCommitted(this, &FKGSLEdDialogueEpisodeDetails::OnTimeLimitCommitted)
		];

	TimeOutDefaultChoices.Empty();
	TimeOutDefaultChoices.Add(MakeShared<FString>(TEXT("随机选择")));
	int Num = Episode->Options.Num();
	for (int Idx = 0; Idx < Num; Idx++)
	{
		auto* line = Episode->Options[Idx];
		TimeOutDefaultChoices.Add(MakeShared<FString>(FString::Printf(TEXT("%d"), line->DialogueID)));
	}
	OptionGroup.AddWidgetRow()
		.NameContent()
		[
			SNew(STextBlock)
				.Text(FText::FromString(FString::Printf(TEXT("超时默认选项"))))
		]
		.ValueContent()
		[
		/*	SNew(STextBlock)
				.Text(FText::FromString(FString::Printf(TEXT("%d"), Episode->TimeOutDefaultChoice)))*/
			SNew(SComboBox<TSharedPtr<FString>>)
				.IsEnabled(false)
				.OptionsSource(&TimeOutDefaultChoices)
				.OnSelectionChanged(this, &FKGSLEdDialogueEpisodeDetails::OnTimeOutDefaultChoicesChanged)
				.OnGenerateWidget(this, &FKGSLEdDialogueEpisodeDetails::OnGenerateTimeOutDefaultChoicesWidget)
				.InitiallySelectedItem(GetTimeOutDefaultChoicesSelectedItem())
				.Content()
				[
					SNew(STextBlock)
						.Text(this, &FKGSLEdDialogueEpisodeDetails::GetTimeOutDefaultChoicesSelectedValue)
				]
		];

    OptionGroup.AddWidgetRow()
               .WholeRowContent()
    [
        SAssignNew(PropertyOptionContent, SBox)
    ];

    PropertyOptionContent->SetContent(OptionBoxes.ToSharedRef());
}

void FKGSLEdDialogueEpisodeDetails::PreChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType)
{
}

void FKGSLEdDialogueEpisodeDetails::PostChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType)
{
    switch (ChangedType)
    {
    case EKGSLDataChangeInfo::LineData:
    case EKGSLDataChangeInfo::LineAdded:
    case EKGSLDataChangeInfo::LineRemoved:
    case EKGSLDataChangeInfo::LineSwapped:
        RebuildLinesBox();
        break;
	case EKGSLDataChangeInfo::OptionData:
	case EKGSLDataChangeInfo::OptionAdded:
	case EKGSLDataChangeInfo::OptionRemoved:
	case EKGSLDataChangeInfo::OptionSwapped:
		RebuildOptionsBox();
		break;
	case EKGSLDataChangeInfo::ImportDialog:
		Rebuild();
		break;
    default:
        break;
    };
}


UDialogueAsset* FKGSLEdDialogueEpisodeDetails::GetDialogueAsset() const
{
    if (!PropertyHandle.IsValid() || !PropertyHandle->IsValidHandle())
    {
        return nullptr;
    }

    UObject* Obj = nullptr;
    TArray<UObject*> CustomizedObjects;
    PropertyHandle->GetOuterObjects(CustomizedObjects);
    if (CustomizedObjects.Num() > 0)
    {
        Obj = CustomizedObjects[0];
    }
    UDialogueAsset* DialogueAsset = nullptr;
    if (IsValid(Obj) && Obj->IsA<UDialogueAsset>())
    {
        return Cast<UDialogueAsset>(Obj);
    }
    return nullptr;
}

UKGSLDialogueEpisode* FKGSLEdDialogueEpisodeDetails::GetEpisode() const
{
    if (!PropertyHandle.IsValid() || !PropertyHandle->IsValidHandle())
    {
        return nullptr;
    }

    UObject* Obj = nullptr;
    //PropertyHandle->GetValue(Obj);
    TArray<UObject*> CustomizedObjects;
    PropertyHandle->GetOuterObjects(CustomizedObjects);
    if(CustomizedObjects.Num() > 0)
    {
        Obj = CustomizedObjects[0];
    }
    UDialogueAsset* DialogueAsset = nullptr;
    UKGSLDialogueEpisode* DialogueEpisode = nullptr;
    if (IsValid(Obj) && Obj->IsA<UDialogueAsset>())
    {
        DialogueAsset = Cast<UDialogueAsset>(Obj);
        DialogueEpisode = DialogueAsset->CurrentEpisode;
    }

    return DialogueEpisode;
}

struct FDialogueEpisode* FKGSLEdDialogueEpisodeDetails::GetDialogueEpisode() const
{
	UDialogueAsset* DialogueAsset = GetDialogueAsset();
	if (DialogueAsset == nullptr)
		return nullptr;

	UKGSLDialogueEpisode* KGSLDialogueEpisode = GetEpisode();
	if (KGSLDialogueEpisode == nullptr)
		return nullptr;

	FDialogueEpisode* DialogueEpisode = DialogueAsset->GetEpisodePointerByID(KGSLDialogueEpisode->EpisodeID);
	return DialogueEpisode;
}

FReply FKGSLEdDialogueEpisodeDetails::OpenDialogueLinesEditor() const
{
    UDialogueAsset* Asset = GetDialogueAsset();
    UKGSLDialogueEpisode* Episode = GetEpisode();
    if (IsValid(Asset) && IsValid(Episode))
    {
        TSharedRef<FKGStoryLineScriptEditor> ScriptEditor(new FKGStoryLineScriptEditor());
        ScriptEditor->InitScriptEditor(EToolkitMode::Standalone,
                                       TSharedPtr<IToolkitHost>(), Asset, Episode->GetEpisodeID(),
                                       UKGSLDialogueLine::StaticClass());
    }
    return FReply::Handled();
}

void FKGSLEdDialogueEpisodeDetails::RebuildLinesBox() const
{
    UKGSLDialogueEpisode* Episode = GetEpisode();
    if (Episode == nullptr || !IsValid(Episode))
    {
        return;
    }

    LineBoxes->ClearChildren();
    int Num = Episode->DialogueLines.Num();
    for (int Idx = 0; Idx < Num; Idx++)
    {
        FString Title;
        FString Content;
        UKGSLDialogueLine* Line = Episode->DialogueLines[Idx];
        if (!IsValid(Line))
        {
            continue;
        }

        Title.Appendf(TEXT("%-2d %-10s "),
                      Idx + 1, Line->TalkerName.IsEmpty() ? *Line->Talker.PerformerName : *Line->TalkerName);

        Content.Append(Line->ContentString);

        TSharedPtr<SHorizontalBox> HorizontalBox = SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            .Padding(FMargin(2.0f, 0.f))
            .FillWidth(8.0f)
            [
                SNew(STextBlock)
                .Text(FText::FromString(Title))
            ]
            + SHorizontalBox::Slot()
            .Padding(FMargin(2.0f, 0.f))
            .FillWidth(20.0f)
            [
                SNew(SVerticalBox)
                + SVerticalBox::Slot()
                .Padding(FMargin(2.0f, 0.f))
                .FillHeight(2.0f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(Content))
                    .AutoWrapText(true)
                ]
            ];

        LineBoxes->AddSlot()
                 .Padding(2.0f, 1.0f)
                 .AutoHeight()
        [
            HorizontalBox.ToSharedRef()
        ];
    }
}

void FKGSLEdDialogueEpisodeDetails::RebuildOptionsBox() const
{
     UKGSLDialogueEpisode* Episode = GetEpisode();
    if (Episode == nullptr || !IsValid(Episode))
    {
        return;
    }
    
    OptionBoxes->ClearChildren();
    int Num = Episode->Options.Num();
    for (int Idx = 0; Idx < Num; Idx++)
    {
        FString Title;
        FString Content;
        auto* line = Episode->Options[Idx];
        Title.Append(FString::Printf(TEXT("%-2d %-2d "), Idx + 1, line->DialogueID));
        Content.Append(line->DialogueText);
        OptionBoxes->AddSlot()
                   .Padding(2.0f, 1.0f)
                   .AutoHeight()
        [
            SNew(SHorizontalBox)
            + SHorizontalBox::Slot()
            .Padding(FMargin(2.0f, 0.f))
            .FillWidth(8.0f)
            [
                SNew(STextBlock)
                .Text(FText::FromString(Title))
            ]
            + SHorizontalBox::Slot()
            .Padding(FMargin(2.0f, 0.f))
            .FillWidth(20.0f)
            [
                SNew(SVerticalBox)
                + SVerticalBox::Slot()
                .Padding(FMargin(2.0f, 0.f))
                .FillHeight(2.0f)
                [
                    SNew(STextBlock)
                    .Text(FText::FromString(Content))
                    .AutoWrapText(true)
                ]
            ]
        ];
    }
}

void FKGSLEdDialogueEpisodeDetails::Rebuild() const
{
    UKGSLDialogueEpisode* Episode = GetEpisode();
    if (Episode == nullptr || !IsValid(Episode))
    {
        return;
    }

    FString StrEpisode = FString::Printf(TEXT("%s  %d"),
                                         *GET_MEMBER_NAME_CHECKED(UKGSLDialogueEpisode, EpisodeID).ToString(),
                                         Episode->GetEpisodeID());
    TextBlockEpisode->SetText(FText::FromString(StrEpisode));

    RebuildLinesBox();
    RebuildOptionsBox();
}

void FKGSLEdDialogueEpisodeDetails::OnEpisodeChanged() const
{
    Rebuild();
}

TSharedPtr<IPropertyHandle> FKGSLEdDialogueEpisodeDetails::FindRealEpisodeProperty(
    TSharedPtr<IPropertyHandle> InPropertyHandle)
{
    if (!InPropertyHandle.IsValid())
    {
        return nullptr;
    }

    uint32 ChildrenCount = 0;
    InPropertyHandle->GetNumChildren(ChildrenCount);
    TSharedPtr<IPropertyHandle> Handle = InPropertyHandle;
    FName PropertyNameEpisodeID = GET_MEMBER_NAME_CHECKED(UKGSLDialogueEpisode, EpisodeID);
    Handle = InPropertyHandle->GetChildHandle(PropertyNameEpisodeID);
    if (Handle.IsValid())
    {
        return Handle->GetParentHandle();
    }

    return nullptr;
}

void FKGSLEdDialogueEpisodeDetails::OnSelectionChanged(TSharedPtr<FString> Selection, ESelectInfo::Type SelectInfo)
{
	FString Value = *Selection.Get();
	UKGSLDialogueEpisode* Episode = GetEpisode();
	if (!IsValid(Episode))
	{
		return;
	}
	Episode->OptionType = OptionTypes.IndexOfByPredicate([&Value](const auto& Item) { return *Item == Value; });
}

TSharedRef<SWidget> FKGSLEdDialogueEpisodeDetails::OnGenerateWidget(TSharedPtr<FString> InItem)
{
	return SNew(STextBlock)
		.Text(FText::FromString(*InItem.Get()));
}

TSharedPtr<FString> FKGSLEdDialogueEpisodeDetails::GetSelectedItem() const
{
	UKGSLDialogueEpisode* Episode = GetEpisode();
	if (!IsValid(Episode))
	{
		return OptionTypes[0];
	}
	return OptionTypes[Episode->OptionType];
}

FText FKGSLEdDialogueEpisodeDetails::GetSelectedValue() const
{
	UKGSLDialogueEpisode* Episode = GetEpisode();
	if (!IsValid(Episode))
	{
		return FText::FromString(*OptionTypes[0]);
	}
	return FText::FromString(*OptionTypes[Episode->OptionType]);
}

double FKGSLEdDialogueEpisodeDetails::OnGetTimeLimit() const
{
	UKGSLDialogueEpisode* Episode = GetEpisode();
	if (!IsValid(Episode))
	{
		return 0;
	}
	return Episode->TimeLimit;
}

void FKGSLEdDialogueEpisodeDetails::OnTimeLimitCommitted(double NewValue, ETextCommit::Type CommitInfo)
{
	UKGSLDialogueEpisode* Episode = GetEpisode();
	if (!IsValid(Episode))
	{
		return;
	}
	Episode->TimeLimit = NewValue;
}

void FKGSLEdDialogueEpisodeDetails::OnTimeOutDefaultChoicesChanged(TSharedPtr<FString> Selection, ESelectInfo::Type SelectInfo)
{
	FString Value = *Selection.Get();
	UKGSLDialogueEpisode* Episode = GetEpisode();
	if (!IsValid(Episode))
	{
		return;
	}
	int32 Index = TimeOutDefaultChoices.IndexOfByPredicate([&Value](const auto& Item) { return *Item == Value; });
	if(Index > 0)
	{
		Episode->TimeOutDefaultChoice = FCString::Atoi(*Value);
	}
	else
	{
		Episode->TimeOutDefaultChoice = 0;
	}
}

TSharedRef<SWidget> FKGSLEdDialogueEpisodeDetails::OnGenerateTimeOutDefaultChoicesWidget(TSharedPtr<FString> InItem)
{
	return SNew(STextBlock)
		.Text(FText::FromString(*InItem.Get()));
}

TSharedPtr<FString> FKGSLEdDialogueEpisodeDetails::GetTimeOutDefaultChoicesSelectedItem() const
{
	UKGSLDialogueEpisode* Episode = GetEpisode();
	if (!IsValid(Episode))
	{
		return TimeOutDefaultChoices[0];
	}
	int32 Index = TimeOutDefaultChoices.IndexOfByPredicate([&Episode](const auto& Item) { return FCString::Atoi(**Item) == Episode->TimeOutDefaultChoice; });
	if(Index < 0)
	{
		return TimeOutDefaultChoices[0];
	}
	return TimeOutDefaultChoices[Index];
}

FText FKGSLEdDialogueEpisodeDetails::GetTimeOutDefaultChoicesSelectedValue() const
{
	UKGSLDialogueEpisode* Episode = GetEpisode();
	if (!IsValid(Episode))
	{
		return FText::FromString(*TimeOutDefaultChoices[0]);
	}
	int32 Index = TimeOutDefaultChoices.IndexOfByPredicate([&Episode](const auto& Item) { return FCString::Atoi(**Item) == Episode->TimeOutDefaultChoice; });
	if (Index < 0)
	{
		return FText::FromString(*TimeOutDefaultChoices[0]);
	}
	return FText::FromString(*TimeOutDefaultChoices[Index]);
}


#undef LOCTEXT_NAMESPACE
