#include "DialogueEditor/CustomLayout/KGSLIconPathLayout.h"
#include "DetailWidgetRow.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "IStructureDetailsView.h"
#include "PropertyHandle.h"
#include "Widgets/Layout/SBox.h"
#include "Containers/UnrealString.h"
#include "EditorClassUtils.h"
#include "PropertyCustomizationHelpers.h"
#include "UObject/Object.h"
#include "Widgets/DeclarativeSyntaxSupport.h"

TSharedRef<IPropertyTypeCustomization> FKGSLIconPathLayout::MakeInstance()
{
    return MakeShareable(new FKGSLIconPathLayout());
}

FKGSLIconPathLayout::~FKGSLIconPathLayout()
{
}

void FKGSLIconPathLayout::CustomizeHeader(TSharedRef<IPropertyHandle> PropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	TSharedPtr<IPropertyHandle> PropertyPathHandle = PropertyHandle->GetChildHandle(FName(TEXT("Path")));
	const FString& MetaClassName = PropertyPathHandle->GetMetaData("MetaClass");
	UClass* MetaClass = !MetaClassName.IsEmpty()
		? FEditorClassUtils::GetClassFromString(MetaClassName)
		: UObject::StaticClass();

	TSharedRef<SObjectPropertyEntryBox> ObjectPropertyEntryBox = SNew(SObjectPropertyEntryBox)
		.AllowedClass(MetaClass)
		.PropertyHandle(PropertyPathHandle)
		.ThumbnailPool(CustomizationUtils.GetThumbnailPool());

	float MinDesiredWidth, MaxDesiredWidth;
	ObjectPropertyEntryBox->GetDesiredWidth(MinDesiredWidth, MaxDesiredWidth);
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		.MinDesiredWidth(MinDesiredWidth)
		.MaxDesiredWidth(MaxDesiredWidth)
		[
			ObjectPropertyEntryBox
		];
}

void FKGSLIconPathLayout::CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}
