#include "DialogueEditor/Dialogue/Actions/DialogueStateControl.h"
#include "DialogueEditor/Dialogue/DialogueActorTrack.h"

UDialogueStateControlTrack::UDialogueStateControlTrack() :UDialogueActionTrack()
{
	TrackName = "StateControl";
	SetSectionType(UDialogueStateControl::StaticClass());
}

void UDialogueStateControlTrack::RemoveAllSectionGeneratedByLine()
{
	ActionSections.RemoveAll([](UDialogueActionBase* Section)
		{
			return Section && Section->FromLineIndex != KGStoryLine::INVALID_LINE_INDEX;
		});
}

EDialogueTrack::Type UDialogueStateControlTrack::GetType() const
{
	return EDialogueTrack::Type::StateControl;
}

void UDialogueStateControl::PostLoad()
{
	Super::PostLoad();
	if (!IsConstant())
	{
		Duration = 0.1f;
	}
}
