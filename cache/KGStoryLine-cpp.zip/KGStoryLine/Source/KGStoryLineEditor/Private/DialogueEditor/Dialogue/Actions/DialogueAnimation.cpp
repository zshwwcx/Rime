#include "DialogueEditor/Dialogue/Actions/DialogueAnimation.h"

#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "Editor.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Subsystems/AssetEditorSubsystem.h"

void UDialogueAnimation::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
    Super::PostEditChangeProperty(PropertyChangedEvent);
    const FName PropertyName = (PropertyChangedEvent.Property != nullptr) ? PropertyChangedEvent.Property->GetFName() : NAME_None;
    if (PropertyName == "AnimLibItem" || PropertyName == "HeadCullingDuration")
    {
        if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
        {
            if (IAssetEditorInstance* EditorInstance = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(DialogueAsset, true))
            {
                if (FDialogueEditor* DialogueEditor = StaticCast<FDialogueEditor*>(EditorInstance))
                {
                    float Result = DialogueEditor->GetDialogueEditorManager()->GetAnimationSectionAutoDuration(this);
                    if (Result > 0.f)
                    {
                        Duration = Result;
                    }
                    else
                    {
                        Duration = 1.f;
                    }
                }
            }
        }

        if (PropertyName == "AnimLibItem")
        {
            OnAnimLibItemChanged();
        }
    }
    else if (PropertyName == "BlendType")
    {
        OnBlendTypeChanged();
    }
    else if (PropertyName == "bCustomBlendIn" || PropertyName == "bCustomBlendOut")
    {
        OnCustomBlendChanged(PropertyChangedEvent.Property, PropertyName);
    }
    else if (PropertyName == "AnimLibBlendInDuration" || PropertyName == "AnimLibBlendInAlphaBlendOp" || PropertyName == "AnimLibBlendOutDuration" || PropertyName == "AnimLibBlendOutAlphaBlendOp")
    {
        OnBlendParamsChanged(PropertyName);
    }
}

void UDialogueAnimation::OnBlendTypeChanged()
{
    SetShowCustomBlend(FName("bCustomBlendIn"), FName("bShowBlendIn"), 
        FName("AnimLibBlendInDuration"), FName("AnimLibBlendInAlphaBlendOp"));
    SetShowCustomBlend(FName("bCustomBlendOut"), FName("bShowBlendOut"), 
        FName("AnimLibBlendOutDuration"), FName("AnimLibBlendOutAlphaBlendOp"));

    if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
    {
        if (IAssetEditorInstance* EditorInstance = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(DialogueAsset, true))
        {
            if (FDialogueEditor* DialogueEditor = StaticCast<FDialogueEditor*>(EditorInstance))
            {
                if (DialogueEditor->GetDialogueEditorManager()->TrySetAnimLibBlendParams(this))
                {
                    //强制刷新一下Detail面板
                    DialogueEditor->ShowObjectDetail(nullptr);
                    DialogueEditor->ShowObjectDetail(this);
                }
            }
        }
    }
}

void UDialogueAnimation::OnBlendParamsChanged(FName InPropertyName)
{
    if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
    {
        if (IAssetEditorInstance* EditorInstance = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(DialogueAsset, true))
        {
            if (FDialogueEditor* DialogueEditor = StaticCast<FDialogueEditor*>(EditorInstance))
            {
                DialogueEditor->GetDialogueEditorManager()->CheckSameWithAnimLibBlend(this);
            }
        }
    }
}


void UDialogueAnimation::OnAnimLibItemChanged()
{
    if (IsAnimLibBlend()) // 动作库混合
    {
        OnBlendTypeChanged();
    }
}

void UDialogueAnimation::OnCustomBlendChanged(FProperty* InProperty, FName InPropertyName)
{
    int8 BlendType = GetBlendType();
    bool bCustom = false;
    if (InPropertyName == "bCustomBlendIn")
    {
        SetShowCustomBlend(FName("bCustomBlendIn"), FName("bShowBlendIn"),
            FName("AnimLibBlendInDuration"), FName("AnimLibBlendInAlphaBlendOp"));
        if (FBoolProperty* BoolProperty = CastField<FBoolProperty>(InProperty))
        {
            const void* Address = BoolProperty->ContainerPtrToValuePtr<void*>(this);
            bCustom = BoolProperty->GetPropertyValue(Address);
            if (!bCustom)
            {
                // 取消自定义混合时，重新读取下动作库里面数据
                OnBlendTypeChanged();
            }
        }
    }
    else if (InPropertyName == "bCustomBlendOut")
    {
        SetShowCustomBlend(FName("bCustomBlendOut"), FName("bShowBlendOut"), 
            FName("AnimLibBlendOutDuration"), FName("AnimLibBlendOutAlphaBlendOp"));
        if (FBoolProperty* BoolProperty = CastField<FBoolProperty>(InProperty))
        {
            const void* Address = BoolProperty->ContainerPtrToValuePtr<void*>(this);
            bCustom = BoolProperty->GetPropertyValue(Address);
            if (!bCustom)
            {
                // 取消自定义混合时，重新读取下动作库里面数据
                OnBlendTypeChanged();
            }
        }
    }
}

int32 UDialogueAnimation::GetBlendType() const
{
    if (FProperty* Property = GetClass()->FindPropertyByName("BlendType"))
    {
        if (Property->IsA(FByteProperty::StaticClass()))
        {
            if (auto* ByteProperty = CastField<FByteProperty>(Property))
            {
                const void* Address = ByteProperty->ContainerPtrToValuePtr<void*>(this);
                uint8 BlendType = ByteProperty->GetPropertyValue(Address);
                return BlendType;
            }
        }
    }

    return INDEX_NONE;
}

bool UDialogueAnimation::IsAnimLibBlend() const
{
    return GetBlendType() == 1;
}

void UDialogueAnimation::SetShowCustomBlend(FName InPropertyName, FName InShowPropertyName, FName InDurationPropertyName, FName InBlendOpPropertyName)
{
    bool bAnimLibBlend = IsAnimLibBlend();
    if (FProperty* Property = GetClass()->FindPropertyByName(InPropertyName))
    {
        if (auto* BoolProperty = CastField<FBoolProperty>(Property))
        {
            const void* Address = BoolProperty->ContainerPtrToValuePtr<void*>(this);
            bool bCustom = BoolProperty->GetPropertyValue(Address);
            if (FProperty* PropertyShowBlendIn = GetClass()->FindPropertyByName(InShowPropertyName))
            {
                if (auto* BoolShowBlendIn = CastField<FBoolProperty>(PropertyShowBlendIn))
                {
                    void* NewAddress = BoolShowBlendIn->ContainerPtrToValuePtr<void*>(this);
                    BoolShowBlendIn->SetPropertyValue(NewAddress, bAnimLibBlend && bCustom);
                }
            }

            if (FProperty* PropertyDuration = GetClass()->FindPropertyByName(InDurationPropertyName))
            {
                if (bAnimLibBlend)
                {
                    PropertyDuration->RemoveMetaData(TEXT("EditConditionHides"));
                }
                else
                {
                    PropertyDuration->SetMetaData(TEXT("EditConditionHides"), TEXT(""));
                }
            }

            if (FProperty* PropertyDuration = GetClass()->FindPropertyByName(InBlendOpPropertyName))
            {
                if (bAnimLibBlend)
                {
                    PropertyDuration->RemoveMetaData(TEXT("EditConditionHides"));
                }
                else
                {
                    PropertyDuration->SetMetaData(TEXT("EditConditionHides"), TEXT(""));
                }
            }
        }
    }
}

void UDialogueAnimation::OnPreDetailShown()
{
    SetShowCustomBlend(FName("bCustomBlendIn"), FName("bShowBlendIn"), 
        FName("AnimLibBlendInDuration"), FName("AnimLibBlendInAlphaBlendOp"));
    SetShowCustomBlend(FName("bCustomBlendOut"), FName("bShowBlendOut"), 
        FName("AnimLibBlendOutDuration"), FName("AnimLibBlendOutAlphaBlendOp"));
}

