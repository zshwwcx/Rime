#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "KGStoryLineDefine.h"

EDialogueTrack::Type UDialogueActionTrack::GetType() const
{
	return EDialogueTrack::Type::Animation;
}

void UDialogueActionTrack::AddSection(UDialogueActionBase* Section)
{
	if (Section)
	{
		Section->DialogueAction = this;
		ActionSections.Add(Section);
	}
}

void UDialogueActionTrack::RemoveSection(UDialogueActionBase* Section)
{
	if (ActionSections.Contains(Section))
	{
		ActionSections.Remove(Section);
	}
}

void UDialogueActionTrack::AdjustOtherSectionData(class UDialogueActionBase* TargetSection)
{
	if (TargetSection == nullptr)
		return;

	TArray<UDialogueActionBase*> AllSections = ActionSections;

	AllSections.Remove(TargetSection);
	//对AllSection进行时间从小到大的排序，方便后续迭代
	Algo::Sort(ActionSections, [](UDialogueActionBase* A, UDialogueActionBase* B)
		{
			int32 RA = static_cast<int32>(IsValid(A));
			int32 RB = static_cast<int32>(IsValid(B));
			if (RA != 0 && RB != 0)
			{
				return A->StartTime < B->StartTime;
			}

			return RA > RB;
		});

	UDialogueActionBase* OverlapSection = nullptr;
	bool overlapA = false;
	float overlapBFraction = 0.0f;

	/*
	* 检测这种情况1 AB是原本的Section，C是新的Section
	*
	* ****---*-----  *******
	*   A |  *  C |  *  B  *
	* ****---*-----  *******
	*/
	for (int i = 0; i < AllSections.Num(); ++i)
	{
		UDialogueActionBase* Section = AllSections[i];
		if(Section == TargetSection)
			continue;
		if (overlapA)
		{//已经找到了重叠的Section，后面的Section只需要往后挪动即可
			if (overlapBFraction)
			{
				Section->Modify();
				Section->SetStartTime(Section->StartTime + overlapBFraction);
			}
		}
		else
		{//还没有找到重叠的Section，继续检测
			overlapA = FMath::IsWithin(TargetSection->StartTime, Section->StartTime, Section->GetEndTime());
			if (overlapA)
			{//本次重叠
				FString Tips = TEXT("section is overlap with pre section, now set to pre end");
				UE_LOG(LogTemp, Log, TEXT("%s"), *Tips);

				//首先把C放置到A的末尾
				TargetSection->SetStartTime(Section->StartTime + Section->Duration);
				//其次，计算C的新区间，是否和B重叠
				if (i + 1 < AllSections.Num())
				{
					UDialogueActionBase* SectionB = AllSections[i + 1];
					//直接计算C的末尾-B的Start数值，如果大于0，则说明和B重叠
					overlapBFraction = TargetSection->GetEndTime() - SectionB->StartTime;
					if (overlapBFraction < 0)
					{//小于0，意味着没有和B重叠，后续的不需要再处理了
						break;
					}
					else
					{
						Tips = TEXT("new duration is overlap with b, now adjust b");
						UE_LOG(LogTemp, Log, TEXT("%s"), *Tips);
					}
				}
			}
		}
	}

	bool overlapB = false;
	if (!overlapA)
	{//情况1不存在，检测下面这种情况
		/*
		* 检测这种情况2 AB是原本的Section，C是新的Section
		*
		* *****  -----**-*****
		*   A *  |  C * | B  *
		* *****  -----**-******
		*/
		for (int i = 0; i < AllSections.Num(); ++i)
		{
			UDialogueActionBase* Section = AllSections[i];
			if (Section == TargetSection)
				continue;
			if (overlapB)
			{//已经找到了重叠的Section，后面的Section只需要往后挪动即可
				Section->Modify();
				Section->SetStartTime(Section->StartTime + overlapBFraction);
			}
			else
			{//还没有找到重叠的Section，继续检测
				overlapB = FMath::IsWithin(Section->StartTime, TargetSection->StartTime, TargetSection->GetEndTime());
				if (overlapB)
				{//本次重叠
					FString Tips = TEXT("section is overlap with next section, now adjust next section");
					UE_LOG(LogTemp, Log, TEXT("%s"), *Tips);

					//直接计算C的末尾-B的Start数值,因为已经落在B的区间，所以肯定大于0
					overlapBFraction = TargetSection->GetEndTime() - Section->StartTime;
					Section->Modify();
					Section->SetStartTime(Section->StartTime + overlapBFraction);
				}
			}
		}
	}
}

TArray<UDialogueActionBase*> UDialogueActionTrack::GetOrderedSections()
{
	ActionSections.RemoveAll([](UDialogueActionBase* Section) { return Section == nullptr; }); //部分Section存在空指针，这里移除一下
	TArray<UDialogueActionBase*> AllSections = ActionSections;

	//对AllSection进行时间从小到大的排序，方便后续迭代
	Algo::Sort(ActionSections, [](UDialogueActionBase* A, UDialogueActionBase* B)
		{
			return A->StartTime < B->StartTime;
		});
	return AllSections;
}

void UDialogueActionTrack::DuplicateFromTrack(UDialogueTrackBase* Track)
{
	Super::DuplicateFromTrack(Track);
	if (UDialogueActionTrack* ActionTrack = Cast<UDialogueActionTrack>(Track))
	{
		SectionType = ActionTrack->SectionType;
	}
}

void UDialogueActionTrack::PostLoad()
{
	Super::PostLoad();
	ActionSections.Remove(nullptr);
}
#if WITH_EDITOR
void UDialogueActionTrack::OnEditorInitialized()
{
    for (auto* Section : ActionSections)
    {
        Section->OnEditorInitialized();
    }
}
#endif
