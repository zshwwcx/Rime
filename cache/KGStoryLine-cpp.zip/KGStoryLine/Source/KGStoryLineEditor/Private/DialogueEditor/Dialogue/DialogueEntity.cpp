#include "DialogueEditor/Dialogue/DialogueEntity.h"

#include "KGStoryLineDefine.h"
#include "Engine/World.h"
#include "GameFramework/Character.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/SkinnedMeshComponent.h"
#include "DialogueEditor/DialogueEditorUtilities.h"
#include "Engine/StaticMesh.h"

#pragma  region UDialogueEntity

UDialogueEntity::UDialogueEntity(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bDefaultObj = HasAnyFlags(RF_ClassDefaultObject);
}

void UDialogueEntity::BeginDestroy()
{
	if (Parent.IsValid())
	{
		Parent->OnEntityTransformChanged().RemoveAll(this);
	}

	Super::BeginDestroy();
}

void UDialogueEntity::PostLoad()
{
	Super::PostLoad();
	if (Parent.IsValid())
	{
		Parent->OnEntityTransformChanged().AddUObject(this, &UDialogueEntity::OnParentEntityTransformChanged);
	}
	bDefaultObj = HasAnyFlags(RF_ClassDefaultObject);
}

AActor* UDialogueEntity::GetEntity() const
{
	return Entity.Get();
}

void UDialogueEntity::SetEntity(AActor* InActor)
{
    if (Entity != InActor && InActor != nullptr )
    {
        Entity = InActor;
    }
}
FTransform UDialogueEntity::GetParentTransform() const
{
	FTransform Result = FTransform::Identity;
	TWeakObjectPtr<UDialogueEntity> ParentEntity = Parent;
	if (ParentEntity.IsValid() && ParentEntity->Entity.IsValid())
	{
		Result = Result * ParentEntity->Entity->GetActorTransform();
	}
	else
	{
		while (ParentEntity.IsValid())
		{
			if (ParentEntity->Entity.IsValid())
			{
				Result = Result * ParentEntity->Entity->GetActorTransform();
				break;
			}

			Result = Result * ParentEntity->SpawnTransform;
			ParentEntity = ParentEntity->Parent;
		}
	}
	return Result;
}

FTransform UDialogueEntity::GetWorldSpawnTransform() const
{
	return SpawnTransform * GetParentTransform();
}

TSubclassOf<AActor> UDialogueEntity::GetActorClass() const
{
	return ActorClass;
}

bool UDialogueEntity::GetDefaultVisible() const
{
	return bDefaultVisible;
}

void UDialogueEntity::OnParentEntityTransformChanged()
{
	if(Entity != nullptr)
		Entity->SetActorTransform(SpawnTransform * GetParentTransform());
	OnEntityTransformChangedEvent.Broadcast();
}

#if WITH_EDITOR
void UDialogueEntity::SetParent(TWeakObjectPtr<UDialogueEntity> InParent)
{
    if (Parent.IsValid())
    {
        Parent->OnEntityTransformChanged().RemoveAll(this);
    }
    Parent = InParent;
    if (Parent.IsValid())
    {
        Parent->OnEntityTransformChanged().AddUObject(this, &UDialogueEntity::OnParentEntityTransformChanged);
    }
}

void UDialogueEntity::UpdateSpawnTransform()
{
    FTransform ParentTransform = GetParentTransform();
    if (Entity.IsValid() && Parent.IsValid())
        SpawnTransform = Entity->GetActorTransform() * ParentTransform.Inverse();
}

void UDialogueEntity::OnEditorInitialized()
{
}

void UDialogueEntity::OnSpawnTransformChanged() const
{
    if(Entity.IsValid())
        Entity->SetActorTransform(SpawnTransform * GetParentTransform());
    OnEntityTransformChangedEvent.Broadcast();
}

void UDialogueEntity::OnEntityMoved()
{
    FTransform ParentTransform = GetParentTransform();
    if (Entity.IsValid() && Parent.IsValid())
    {
        // 保留缩放
        FVector SrcScale = SpawnTransform.GetScale3D();
        SpawnTransform = Entity->GetActorTransform() * ParentTransform.Inverse();
        SpawnTransform.SetScale3D(SrcScale);
        Entity->SetActorScale3D(SrcScale);
        Entity->MarkComponentsRenderStateDirty();
    }
	
    OnEntityTransformChangedEvent.Broadcast();
}

bool UDialogueEntity::CanEditChange(const FProperty* InProperty) const
{
    if (!HasAnyFlags(RF_ClassDefaultObject))
    {
        if (InProperty)
        {
            FString PropertyName = InProperty->GetName();
            if (PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UDialogueEntity, ActorClass))
            {
                return false;
            }
        }
    }
    return Super::CanEditChange(InProperty);
}

void UDialogueEntity::DuplicateFromEntityInfo_Implementation(UDialogueEntity* InEntity)
{
	SpawnTransform = InEntity->SpawnTransform;
	ActorClass = InEntity->ActorClass;
}

#pragma endregion

#pragma  region UDialogueCamera
/*
 * UDialogueCamera
 */
UDialogueCamera::UDialogueCamera(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
#if WITH_EDITORONLY_DATA
	static ConstructorHelpers::FObjectFinder<UStaticMesh> PlaneMesh(TEXT("/Engine/ArtTools/RenderToTexture/Meshes/S_1_Unit_Plane.S_1_Unit_Plane"));
	FocusPlaneVisualizationMesh = PlaneMesh.Object;

	static ConstructorHelpers::FObjectFinder<UMaterial> PlaneMat(TEXT("/Engine/EngineDebugMaterials/M_SimpleUnlitTranslucent.M_SimpleUnlitTranslucent"));
	FocusPlaneVisualizationMaterial = PlaneMat.Object;

	DebugFocusPlaneColor = FColor(70, 0, 255, 255);
#endif
}


void UDialogueCamera::DuplicateFromEntityInfo_Implementation(UDialogueEntity* InEntity)
{
	Super::DuplicateFromEntityInfo_Implementation(InEntity);
	if (UDialogueCamera* OtherCamera = Cast<UDialogueCamera>(InEntity))
	{
#define COPY_MEMBER(member)  member = OtherCamera->member
		COPY_MEMBER(FOV);
		COPY_MEMBER(bEnableLookAt);
		COPY_MEMBER(LookAtTarget);
		COPY_MEMBER(BoneName);
		COPY_MEMBER(OffsetZ);
		COPY_MEMBER(bOverride_DepthOfField);
		COPY_MEMBER(DepthOfFieldFocalDistance);
		COPY_MEMBER(DepthOfFieldSensorWidth);
		COPY_MEMBER(DepthOfFieldFocalRegion);
		COPY_MEMBER(DepthOfFieldNearTransitionRegion);
		COPY_MEMBER(DepthOfFieldFarTransitionRegion);
		COPY_MEMBER(DepthOfFieldFocusActor);
	}
}

void UDialogueCamera::PostLoad()
{
	Super::PostLoad();
}

void UDialogueCamera::SetEntity(AActor* InActor)
{
    bool bChanged = InActor != Entity && InActor != nullptr;
    Super::SetEntity(InActor);
    if (bChanged)
    {
        if (auto* CameraComp = Entity->FindComponentByClass<UCameraComponent>())
        {
            CameraComp->SetFieldOfView(FOV);
        }
    }
}

#if WITH_EDITORONLY_DATA
void UDialogueCamera::CreateDebugFocusPlane()
{
	if (AActor* TargetEntity = GetEntity())
	{
		if (ACameraActor* CameraActor = Cast<ACameraActor>(TargetEntity))
		{
			if(UCameraComponent* CameraComp = CameraActor->GetCameraComponent())
			{
				if (DebugFocusPlaneComponent == nullptr)
				{
					DebugFocusPlaneComponent = NewObject<UStaticMeshComponent>(CameraActor, NAME_None, RF_Transient | RF_Transactional | RF_TextExportTransient);
					DebugFocusPlaneComponent->SetupAttachment(CameraComp);
					DebugFocusPlaneComponent->SetIsVisualizationComponent(true);
					DebugFocusPlaneComponent->SetStaticMesh(FocusPlaneVisualizationMesh);
					DebugFocusPlaneComponent->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
					DebugFocusPlaneComponent->bHiddenInGame = false;
					DebugFocusPlaneComponent->CastShadow = false;
					DebugFocusPlaneComponent->CreationMethod = CameraComp->CreationMethod;
					DebugFocusPlaneComponent->bSelectable = false;
					DebugFocusPlaneComponent->SetIgnoreBoundsForEditorFocus(true);

					DebugFocusPlaneComponent->SetRelativeScale3D_Direct(FVector(10000.f, 10000.f, 1.f));
					DebugFocusPlaneComponent->SetRelativeRotation_Direct(FRotator(90.f, 0.f, 0.f));

					DebugFocusPlaneComponent->RegisterComponent();

					DebugFocusPlaneMID = DebugFocusPlaneComponent->CreateAndSetMaterialInstanceDynamicFromMaterial(0, FocusPlaneVisualizationMaterial);
					if (DebugFocusPlaneMID.IsValid())
					{
						DebugFocusPlaneMID->SetVectorParameterValue(FName(TEXT("Color")), DebugFocusPlaneColor.ReinterpretAsLinear());
					}
				}
			}
		}
	}
}

void UDialogueCamera::UpdateDebugFocusPlane()
{
	if (AActor* TargetEntity = GetEntity())
	{
		if (ACameraActor* CameraActor = Cast<ACameraActor>(TargetEntity))
		{
			if(UCameraComponent* CameraComp = CameraActor->GetCameraComponent())
			{
				if (FocusPlaneVisualizationMesh && DebugFocusPlaneComponent.IsValid())
				{
					FVector const CamLocation = CameraComp->GetComponentTransform().GetLocation();
					FVector const CamDir = CameraComp->GetComponentTransform().GetRotation().Vector();

					float const FocusDistance = GetDesiredFocusDistance(CamLocation);		// in editor, use desired focus distance directly, no interp
					FVector FocusPoint = CameraComp->GetComponentTransform().GetLocation() + CamDir * FocusDistance;

					DebugFocusPlaneComponent->SetWorldLocation(FocusPoint);
				}
			}
		}
	}

	if (DebugFocusPlaneMID.IsValid())
	{
		DebugFocusPlaneMID->SetVectorParameterValue(FName(TEXT("Color")), DebugFocusPlaneColor.ReinterpretAsLinear());
	}
}

float UDialogueCamera::GetDesiredFocusDistance(const FVector& InLocation) const
{
	float DesiredFocusDistance = 0.0f;
	
	FString TargetTrackName = LookAtTarget.PerformerName;
	if (UDialogueAsset* Asset = FDialogueEditorUtilities::GetDialogueAsset(this))
	{
		if (UDialogueTrackBase* Track = Asset->FindTrackByName(0, FName(TargetTrackName)))
		{
			if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(Track))
			{
				if (UDialogueEntity* DialogueEntity = SpawnableTrack->GetDialogueEntity())
				{
					if (AActor* DialogueActor = Cast<AActor>(DialogueEntity->GetEntity()))
					{
						if (UActorComponent* ActorComp = DialogueActor->GetComponentByClass(USkeletalMeshComponent::StaticClass()))
						{
							if (USkeletalMeshComponent* MainMesh = Cast<USkeletalMeshComponent>(ActorComp))
							{
								FVector FocusPoint;
								FVector HeadLocation = MainMesh->GetSocketLocation(TEXT("head"));
								FVector ActorLocation = DialogueActor->GetActorTransform().GetLocation();
								if (HeadLocation.Z < ActorLocation.Z)
								{
									HeadLocation = MainMesh->GetSocketLocation(TEXT("Bip001-Head"));
								}
								if (HeadLocation.Z < ActorLocation.Z)
								{
									FocusPoint = ActorLocation;
								}
								else
								{
									FocusPoint = HeadLocation;
								}
								DesiredFocusDistance = UKismetMathLibrary::Vector_Distance(InLocation, FocusPoint);
							}
						}
					}
				}
			}
		}
	}

	DesiredFocusDistance += DepthOfFieldFocalDistance;
	
	return DesiredFocusDistance;
}

void UDialogueCamera::DestroyDebugFocusPlane()
{
	if (DebugFocusPlaneComponent.IsValid())
	{
		DebugFocusPlaneComponent->SetVisibility(false);
		DebugFocusPlaneComponent->DestroyComponent();
		DebugFocusPlaneComponent.Reset();
		DebugFocusPlaneMID.Reset();
	}
}

#endif


void UDialogueCamera::OnEntityMoved()
{
    UDialogueEntity::OnEntityMoved();
}

void UDialogueCamera::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
    Super::PostEditChangeProperty(PropertyChangedEvent);
	
    if (bEnableCameraDOF_Debug)
    {
        CreateDebugFocusPlane();
        UpdateDebugFocusPlane();
    }
    else
    {
        DestroyDebugFocusPlane();
    }

}

#endif
class ACameraActor* UDialogueCamera::GetCamera() const
{
    return Cast<ACameraActor>(GetEntity());
}

float UDialogueCamera::GetFOV()
{
    return FOV;
}

#pragma endregion

#pragma region UDialogueActor

/*
 * UDialogueActor
 */
void UDialogueActor::DuplicateFromEntityInfo_Implementation(UDialogueEntity* InEntity)
{
	Super::DuplicateFromEntityInfo_Implementation(InEntity);
	AppearanceID = Cast<UDialogueActor>(InEntity)->AppearanceID;
}

#if WITH_EDITOR
void UDialogueActor::AdjustScaleByModelLibScale()
{
    FVector Scale = SpawnTransform.GetScale3D();
    // 反算scale，现在SpawnTransform上的缩放是剧编里面设置的缩放，而
    // Actor身上的缩放 = 剧编设置的缩放 * 模型库里面的缩放
    // 所以这里要将模型库配置缩放排除掉
    Scale = Scale / ScaleInModelLib;
    SpawnTransform.SetScale3D(Scale);
}

void UDialogueActor::PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);

	FDialogueActorInfo* TargetActorInfo = nullptr;
	UDialogueAsset* Asset = FDialogueEditorUtilities::GetDialogueAsset(this);
	if (!Asset)
	{
		return;
	}
	
	for (auto& ActorInfo : Asset->ActorInfos)
	{
		if (ActorInfo.PerformerName == TrackName)
		{
			TargetActorInfo = &ActorInfo;
			break;
		}
	}

	if (TargetActorInfo && Asset)
	{
		bool bPropertyChanged = false;
		FProperty* Property = nullptr;
		if (PropertyChangedEvent.GetPropertyName() == TEXT("IdleAnimLibAssetID"))
		{
			if (!(TargetActorInfo->IdleAnimation.operator==(IdleAnimLibAssetID)))
			{
				TargetActorInfo->IdleAnimation.StateName = IdleAnimLibAssetID.StateName;
				TargetActorInfo->IdleAnimation.SetAnimID(IdleAnimLibAssetID.AnimID);
				TargetActorInfo->IdleAnimation.SetAssetID(IdleAnimLibAssetID.AssetID);
				bPropertyChanged = true;

				Property = FDialogueActorInfo::StaticStruct()->FindPropertyByName(GET_MEMBER_NAME_STRING_CHECKED(FDialogueActorInfo, IdleAnimation));
			}
		}
		else if (PropertyChangedEvent.GetPropertyName() == TEXT("bIsPlayer"))
		{
			if (TargetActorInfo->bIsPlayer != bIsPlayer)
			{
				TargetActorInfo->bIsPlayer = bIsPlayer;
				bPropertyChanged = true;

				Property = FDialogueActorInfo::StaticStruct()->FindPropertyByName(GET_MEMBER_NAME_STRING_CHECKED(FDialogueActorInfo, bIsPlayer));
			}
		}
		else if (PropertyChangedEvent.GetPropertyName() == GET_MEMBER_NAME_STRING_CHECKED(UDialogueActor, UseSceneActor))
		{
			if (TargetActorInfo->UseSceneActor != UseSceneActor)
			{
				TargetActorInfo->UseSceneActor = UseSceneActor;
				bPropertyChanged = true;
				Property = FDialogueActorInfo::StaticStruct()->FindPropertyByName(GET_MEMBER_NAME_STRING_CHECKED(FDialogueActorInfo, UseSceneActor));
			}
		}
		else if (PropertyChangedEvent.GetPropertyName() == GET_MEMBER_NAME_STRING_CHECKED(UDialogueActor, InsID))
		{
			if (TargetActorInfo->InsID != InsID)
			{
				TargetActorInfo->InsID = InsID;
				bPropertyChanged = true;
				Property = FDialogueActorInfo::StaticStruct()->FindPropertyByName(GET_MEMBER_NAME_STRING_CHECKED(FDialogueActorInfo, InsID));
			}
		}


		if (bPropertyChanged && Property)
		{
			FProperty* PropertyActorInfos = UDialogueAsset::StaticClass()->FindPropertyByName(GET_MEMBER_NAME_STRING_CHECKED(UDialogueAsset, ActorInfos));
			FEditPropertyChain EditChain;
			EditChain.AddHead(PropertyActorInfos);

			EditChain.AddTail(Property);
			EditChain.SetActivePropertyNode(Property);
			EditChain.SetActiveMemberPropertyNode(PropertyActorInfos);

			FPropertyChangedEvent EditPropertyChangeEvent(Property, EPropertyChangeType::ValueSet);
			FPropertyChangedChainEvent ChainEvent(EditChain, EditPropertyChangeEvent);
			Asset->PostEditChangeChainProperty(ChainEvent);
		}
	}	
}

void UDialogueActor::UpdateSpawnTransform()
{
    FTransform ParentTransform = GetParentTransform();
    if (Entity.IsValid() && Parent.IsValid())
    {
        SpawnTransform = Entity->GetActorTransform() * ParentTransform.Inverse();
        AdjustScaleByModelLibScale();
    }
}

void UDialogueActor::OnEntityMoved()
{
    FTransform ParentTransform = GetParentTransform();
    if (Entity.IsValid() && Parent.IsValid())
    {
        SpawnTransform = Entity->GetActorTransform() * ParentTransform.Inverse();
        AdjustScaleByModelLibScale();	    
        Entity->MarkComponentsRenderStateDirty();
    }
	
    OnEntityTransformChangedEvent.Broadcast();
}

void UDialogueActor::OnSpawnTransformChanged() const
{
    if(Entity.IsValid())
    {
        FTransform Scale;
        Scale.SetScale3D(FVector(ScaleInModelLib));
        Entity->SetActorTransform(Scale * SpawnTransform * GetParentTransform());
    }
    OnEntityTransformChangedEvent.Broadcast();
}
#endif

void UDialogueActor::SetEntity(AActor* InActor)
{
    Super::SetEntity(InActor);
    
    if (Entity.IsValid())
    {
        FVector Scale = SpawnTransform.GetScale3D();
        Scale *= ScaleInModelLib;
        Entity->SetActorScale3D(Scale);
    }
}

void UDialogueActor::SetScaleInModelLibFromLua(float InScale)
{
    if (FMath::IsNearlyZero(InScale))
    {
        UE_LOG(LogKGSL, Warning, TEXT("[KGSL]SetModelScaleFromLua failed: scale can not be zero.Track:%s"), *TrackName);
        return;
    }
    
    ScaleInModelLib.X = InScale;
    ScaleInModelLib.Y = InScale;
    ScaleInModelLib.Z = InScale;
    UE_LOG(LogKGSL, Log, TEXT("[KGSL]SetModelScaleFromLua %s scale:%.4f"), *TrackName, InScale);
}

void UDialogueActor::CopyFromActorInfo(const struct FDialogueActorInfo* DialogueActorInfo)
{
	AppearanceID = DialogueActorInfo->AppearanceID.ApperanceID;
	IdleAnimLibAssetID = DialogueActorInfo->IdleAnimation;
	UseSceneActor = DialogueActorInfo->UseSceneActor;
	InsID = DialogueActorInfo->InsID;
	bIsPlayer = DialogueActorInfo->bIsPlayer;
}

void UDialogueActor::CopyToActorInfo(struct FDialogueActorInfo* DialogueActorInfo)
{
	DialogueActorInfo->AppearanceID.ApperanceID = AppearanceID;
	DialogueActorInfo->IdleAnimation = IdleAnimLibAssetID;
	DialogueActorInfo->UseSceneActor = UseSceneActor;
	DialogueActorInfo->InsID = InsID;
	DialogueActorInfo->bIsPlayer = bIsPlayer;
}

#pragma endregion