#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"

UDialogueDialogueTrack::UDialogueDialogueTrack() :UDialogueActionTrack()
{
	TrackName = "Dialogue";
}

EDialogueTrack::Type UDialogueDialogueTrack::GetType() const
{
	return EDialogueTrack::Type::Dialogue;
}

#if WITH_EDITOR
FText UDialogueDialogue::GetSectionName_Implementation()
{
	FString Content = SectionName.ToString();
	if (!Content.IsEmpty())
	{
		Content.ReplaceInline(TEXT("\\n"), TEXT("\n"));
		return FText::FromString(*Content);
	}

	return UDialogueActionBase::GetSectionName_Implementation();
}


#endif

void UDialogueDialogue::PostLoad()
{
	Super::PostLoad();
	if (EpisodeID == KGStoryLine::INVALID_EPISODE_ID && OwnedEpisodeID != KGStoryLine::INVALID_EPISODE_ID)
	{
		EpisodeID = OwnedEpisodeID;
	}

	if (ContentIndex == KGStoryLine::INVALID_LINE_INDEX && FromLineIndex != KGStoryLine::INVALID_LINE_INDEX)
	{
		ContentIndex = FromLineIndex + 1;
	}
}