// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/Dialogue/Actions/Dialogue3CAction.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "Editor.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Subsystems/AssetEditorSubsystem.h"

void UDialogue3CMoveAction::OnEntityTransformChanged()
{
    if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
    {
        if (IAssetEditorInstance* EditorInstance = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(DialogueAsset, true))
        {
            if (FDialogueEditor* DialogueEditor = StaticCast<FDialogueEditor*>(EditorInstance))
            {
                float Result = DialogueEditor->GetDialogueEditorManager()->Get3CMoveSectionDuration(this);
                Duration = Result > 0.f ? Result : 1.f;
            }
        }
    }
}

void UDialogue3CMoveAction::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
    Super::PostEditChangeProperty(PropertyChangedEvent);
    const FName PropertyName = (PropertyChangedEvent.Property != nullptr) ? PropertyChangedEvent.Property->GetFName() : NAME_None;
    if (PropertyName == "Target" || PropertyName == "Mode" || PropertyName == "MovePosture")
    {
        if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
        {
            if (PropertyName == "Target")
            {
                FBehaviorActorSelector OutValue;
                PropertyChangedEvent.Property->GetValue_InContainer(this, &OutValue);
                TArray<UDialogueEntity*> AllEntities = DialogueAsset->GetAllEntities();
                for (auto* Entity : AllEntities)
                {
                    if (Entity && Entity->TrackName == OutValue.TrackName.ToString()
                        && !Entity->OnEntityTransformChanged().IsBoundToObject(this))
                    {
                        if (LastTargetEntityBound != nullptr && LastTargetEntityBound != Entity)
                        {
                            LastTargetEntityBound->OnEntityTransformChanged().Remove(OnEntityTransformChangedDelegateHandle);
                        }

                        LastTargetEntityBound = Entity;
                       OnEntityTransformChangedDelegateHandle = Entity->OnEntityTransformChanged().AddUObject(this, &UDialogue3CMoveAction::OnEntityTransformChanged);
                        break;
                    }
                }
            }
            
            if (IAssetEditorInstance* EditorInstance = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(DialogueAsset, true))
            {
                if (FDialogueEditor* DialogueEditor = StaticCast<FDialogueEditor*>(EditorInstance))
                {
                    float Result = DialogueEditor->GetDialogueEditorManager()->Get3CMoveSectionDuration(this);
                    Duration = Result > 0.f ? Result : 1.f;
                }
            }
        }
    }
}
#if WITH_EDITOR
void UDialogue3CMoveAction::OnEditorInitialized()
{
    Super::OnEditorInitialized();

    UDialogueAsset* DialogueAsset = GetDialogueAsset();
    if (!DialogueAsset)
    {
        return;
    }

    FString TargetEntityName;
    for (TFieldIterator<FProperty> PropertyIt(GetClass()); PropertyIt; ++PropertyIt)
    {
        FProperty* Property = *PropertyIt;
        FString PropertyName = Property->GetName();

        if (PropertyName == TEXT("Target"))
        {
            FBehaviorActorSelector OutValue;
            Property->GetValue_InContainer(this, &OutValue);
            TargetEntityName = OutValue.TrackName.ToString();
        }
    }

    if (TargetEntityName.IsEmpty() || TargetEntityName.Equals(TEXT("None"), ESearchCase::IgnoreCase))
    {
        return;
    }

    TArray<UDialogueEntity*> AllEntities = DialogueAsset->GetAllEntities();
    for (auto* Entity : AllEntities)
    {
        if (Entity && Entity->TrackName == TargetEntityName
            && !Entity->OnEntityTransformChanged().IsBoundToObject(this))
        {
            if (LastTargetEntityBound != nullptr && LastTargetEntityBound != Entity)
            {
                LastTargetEntityBound->OnEntityTransformChanged().Remove(OnEntityTransformChangedDelegateHandle);
            }

            LastTargetEntityBound = Entity;
            OnEntityTransformChangedDelegateHandle = Entity->OnEntityTransformChanged().AddUObject(this, &UDialogue3CMoveAction::OnEntityTransformChanged);
            break;
        }
    }
}
#endif

void UDialogue3CTurnAction::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
    Super::PostEditChangeProperty(PropertyChangedEvent);
    const FName PropertyName = (PropertyChangedEvent.Property != nullptr) ? PropertyChangedEvent.Property->GetFName() : NAME_None;
    if (PropertyName == "Target")
    {
        if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
        {
            if (IAssetEditorInstance* EditorInstance = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(DialogueAsset, true))
            {
                if (FDialogueEditor* DialogueEditor = StaticCast<FDialogueEditor*>(EditorInstance))
                {
                    float Result = DialogueEditor->GetDialogueEditorManager()->Get3CTurnSectionDuration(this);
                    Duration = Result > 0.f ? Result : 1.f;
                }
            }
        }
    }
}
