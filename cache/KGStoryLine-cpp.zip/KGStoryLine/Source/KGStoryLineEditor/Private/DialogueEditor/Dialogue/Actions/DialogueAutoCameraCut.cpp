#include "DialogueEditor/Dialogue/Actions/DialogueAutoCameraCut.h"

UDialogueAutoCameraCutTrack::UDialogueAutoCameraCutTrack() :UDialogueActionTrack()
{
	TrackName = "AutoCameraCut";
}

EDialogueTrack::Type UDialogueAutoCameraCutTrack::GetType() const
{
	return EDialogueTrack::Type::AutoCameraCut;
}

#if WITH_EDITOR
void UDialogueAutoCameraCut::OnSetTableData(TMap<FString, FString> TableData)
{
	// SectionName = FText::FromString(TableData["AutoCameraCutDesc"]);
	if (AutoCameraType == EDialogueAutoCameraType::OneActor)
	{
		ActorFocusH =   FCString::Atof(*TableData["H"]);
		ActorFocusV =   FCString::Atof(*TableData["V"]);
		CameraFovX =   FCString::Atof(*TableData["HFov"]);
		ActorFocusDist =   FCString::Atof(*TableData["Dist"]);
		CameraYaw =   FCString::Atof(*TableData["theta"]);
		CameraPitch =   FCString::Atof(*TableData["Pitch"]);
	}
	else if(AutoCameraType == EDialogueAutoCameraType::TwoActorTypeOne)
	{
		ActorFocusH =   FCString::Atof(*TableData["H1"]);
		ActorFocusV =   FCString::Atof(*TableData["V1"]);
		ActorBackendH =   FCString::Atof(*TableData["H2"]);
		ActorBackendV =   FCString::Atof(*TableData["V2"]);
		CameraFovX =   FCString::Atof(*TableData["HFov"]);
		CameraYaw =   FCString::Atof(*TableData["theta"]);
	}
	else
	{
		ActorFocusH =   FCString::Atof(*TableData["H1"]);
		ActorFocusV =   FCString::Atof(*TableData["V1"]);
		ActorBackendH =   FCString::Atof(*TableData["H2"]);
		CameraFovX =   FCString::Atof(*TableData["HFov"]);
		CameraYaw =   FCString::Atof(*TableData["theta"]);
		CameraPitch =   FCString::Atof(*TableData["Pitch"]);
	}
}
#endif