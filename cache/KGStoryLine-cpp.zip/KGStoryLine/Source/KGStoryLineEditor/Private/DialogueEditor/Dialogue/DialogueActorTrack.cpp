#include "DialogueEditor/Dialogue/DialogueActorTrack.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"


UDialogueActorTrack::UDialogueActorTrack()
{
#if WITH_EDITOR
	NamePrefix = TEXT("Actor");
#endif
}

EDialogueTrack::Type UDialogueActorTrack::GetType() const
{
	return EDialogueTrack::Type::Actor;
}

UDialoguePerformerTrack::UDialoguePerformerTrack()
{
#if WITH_EDITOR
	NamePrefix = TEXT("Performer");
#endif
}


