#include "DialogueEditor/Dialogue/DialogueAnimInstance.h"

UDialogueAnimInstance::UDialogueAnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	/*LookAtLocation.Z = 180.f;
	LookAtLocation.Y = 50.f;*/
}