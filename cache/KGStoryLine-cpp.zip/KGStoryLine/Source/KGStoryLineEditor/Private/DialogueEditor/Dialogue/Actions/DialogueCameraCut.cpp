#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "DialogueEditor/Dialogue/DialogueActorTrack.h"

UDialogueCameraCutTrack::UDialogueCameraCutTrack() :UDialogueActionTrack()
{
	TrackName = "CameraCut";
}

EDialogueTrack::Type UDialogueCameraCutTrack::GetType() const
{
	return EDialogueTrack::Type::CameraCut;
}

UClass* UDialogueCameraCutTrack::GetSecondSectionType()
{
	FString BPSAutoCameraCutClassPath = TEXT("/Game/Blueprint/DialogueSystem/Section/BPS_DialogueAutoShot.BPS_DialogueAutoShot_C");
	UClass* BPSAutoCameraCutClass = StaticLoadClass(UObject::StaticClass(), nullptr, *BPSAutoCameraCutClassPath);
	return BPSAutoCameraCutClass;
}

#if WITH_EDITOR
FString UDialogueCameraCutTrack::GetEditorPreviewName()
{
	UDialogueTrackBase* ParentTrack = Parent;
	while(ParentTrack)
	{
		UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(ParentTrack);
		if(SpawnableTrack)
		{
			return SpawnableTrack->GetEditorPreviewName();
		}
		ParentTrack = ParentTrack->Parent;
	}
	
	return TEXT("");
}
#endif