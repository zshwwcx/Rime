#include "DialogueEditor/Dialogue/DialogueAsset.h"

#include "KGStoryLineDefine.h"
#include "Animation/AnimInstanceProxy.h"
#include "DialogueEditor/Dialogue/DialogueActorTrack.h"
#include "DialogueEditor/Dialogue/DialogueCameraTrack.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"
#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"
#include "DialogueEditor/Dialogue/DialogueEntitySpline.h"
#include "Misc/OutputDeviceNull.h"
#include "Containers/Queue.h"
#include "UObject/SavePackage.h"
#include "UObject/UObjectIterator.h"
#include "Engine/AssetManager.h"
#include "AssetRegistry/AssetIdentifier.h"
#include "EdGraph/EdGraph.h"
#include "UObject/MetaData.h"
#pragma optimize("", off)

bool GKGSLUseObject = true;
static FAutoConsoleVariableRef CVarKGSLUseObject(
	TEXT("KGSL.UseObject"),
	GKGSLUseObject,
	TEXT("If this is false, KGStoryLine dialogue use struct in internal data structure.\n"));

bool GKGSLUseLuaAsset = false;
static FAutoConsoleVariableRef CVarKGSLUseLuaAsset(
	TEXT("KGSL.UseLuaAsset"),
	GKGSLUseLuaAsset,
	TEXT("If this is true, dialogue will use lua asset\n")
);


static uint32 GenerateKGSLGUID(const FString& PackagePath, const FString& Content, const void* Address)
{
	static uint32 CallCounter = 0;
	++CallCounter;

	check(PackagePath.Len() > 0);
		
	FString GUID = FGuid::NewGuid().ToString();

	if(Address == nullptr)
	{
		Address = GetData(GUID);
	}
	
	FDateTime Now = FDateTime::Now();
	const int64 TimeStampInMillisecond = Now.GetTicks();

	FAnsiStringBuilderBase MagicStr;
	MagicStr.Appendf("%lld%s%s0x%p%u",
		TimeStampInMillisecond, TCHAR_TO_ANSI(*PackagePath), TCHAR_TO_ANSI(*GUID), Address, CallCounter);

	if (!Content.IsEmpty())
	{
		MagicStr.Appendf("%s", TCHAR_TO_ANSI(*Content));
	}

	static constexpr auto MIN_INT64 = std::numeric_limits<long long>().min() + 1;
	static constexpr auto MAX_INT64 = std::numeric_limits<long long>().max() - 1;
	const int64 RandomNumbers = FMath::RandRange(MIN_INT64, MAX_INT64);

	MagicStr.Appendf("%lld", RandomNumbers);

	return CityHash32(MagicStr.GetData(), MagicStr.Len());
}

#pragma region UKGSLDialogueLine

void UKGSLDialogueLine::Initialize(const FString& InContent, const FString& InGUID)
{
	if (InGUID.IsEmpty())
	{
		UE_LOG(LogKGSL, Warning, TEXT("dialogue line has no GUID in excel:%s"), *InContent);
	}
	else
	{
		FGuid::Parse(InGUID, UniqueID);
	}

	if(ContentString != InContent)
	{
		ContentString = InContent;
		ContentString.ReplaceInline(TEXT("\n"), TEXT("\\n"));
		Modify();
	}
}

void UKGSLDialogueLine::ExportText(FString& ValueStr, const void* Value, const void* Defaults,
	UObject* OwnerObject, int32 PortFlags, UObject* ExportRootScope)
{
	int32 Count = 0;

	for (TFieldIterator<FProperty> It(StaticClass()); It; ++It)
	{
		if (It->ShouldPort(PortFlags))
		{
			for (int32 Index = 0; Index < It->ArrayDim; Index++)
			{
				FString InnerValue;
				if (It->ExportText_InContainer(Index, InnerValue, Value, Defaults, OwnerObject, PPF_Delimited | PortFlags, ExportRootScope))
				{
					Count++;
					if (Count == 1)
					{
						ValueStr += TCHAR('(');
					}
					else if ((PortFlags & PPF_BlueprintDebugView) == 0)
					{
						ValueStr += TCHAR(',');
					}
					else
					{
						ValueStr += TEXT(",\n");
					}

					const FString PropertyName = (PortFlags & (PPF_ExternalEditor | PPF_BlueprintDebugView)) != 0 ? It->GetAuthoredName() : It->GetName();

					if (It->ArrayDim == 1)
					{
						ValueStr += FString::Printf(TEXT("%s="), *PropertyName);
					}
					else
					{
						ValueStr += FString::Printf(TEXT("%s[%i]="), *PropertyName, Index);
					}
					ValueStr += InnerValue;
				}
			}
		}
	}

	if (Count > 0)
	{
		ValueStr += TEXT(")");
	}
	else
	{
		ValueStr += TEXT("()");
	}
}

const TCHAR* UKGSLDialogueLine::ImportText(const TCHAR* InBuffer, void* Value, UObject* OwnerObject,
	int32 PortFlags, FOutputDevice* ErrorText, const FString& StructName)
{
	FOutputDeviceNull NullErrorText;
	if (!ErrorText)
	{
		ErrorText = &NullErrorText;
	}

	auto SkipWhitespace = [](const TCHAR*& Str)
	{
		while (FChar::IsWhitespace(*Str))
		{
			Str++;
		}
	};
	
	TArray<FDefinedProperty> DefinedProperties;
	// this keeps track of the number of errors we've logged, so that we can add new lines when logging more than one error
	int32 ErrorCount = 0;
	const TCHAR* Buffer = InBuffer;
	if (*Buffer++ == TCHAR('('))
	{
		// Parse all properties.
		while (*Buffer != TCHAR(')'))
		{
			// parse and import the value
			Buffer = FProperty::ImportSingleProperty(Buffer, Value, StaticClass(),
			                                         OwnerObject, PortFlags | PPF_Delimited, ErrorText,
			                                         DefinedProperties);

			// skip any remaining text before the next property value
			SkipWhitespace(Buffer);
			int32 SubCount = 0;
			while (*Buffer && *Buffer != TCHAR('\r') && *Buffer != TCHAR('\n') &&
				(SubCount > 0 || *Buffer != TCHAR(')')) && (SubCount > 0 || *Buffer != TCHAR(',')))
			{
				SkipWhitespace(Buffer);
				if (*Buffer == TCHAR('\"'))
				{
					do
					{
						Buffer++;
					} while (*Buffer && *Buffer != TCHAR('\"') && *Buffer != TCHAR('\n') && *Buffer != TCHAR('\r'));

					if (*Buffer != TCHAR('\"'))
					{
						ErrorText->Logf(TEXT("%sImportText (UKGSLDialogueLine): Bad quoted string at: %s"), ErrorCount++ > 0 ? LINE_TERMINATOR : TEXT(""), Buffer);
						return nullptr;
					}
				}
				else if (*Buffer == TCHAR('('))
				{
					SubCount++;
				}
				else if (*Buffer == TCHAR(')'))
				{
					SubCount--;
					if (SubCount < 0)
					{
						ErrorText->Logf(TEXT("%sImportText (UKGSLDialogueLine): Too many closing parenthesis in: %s"), ErrorCount++ > 0 ? LINE_TERMINATOR : TEXT(""), InBuffer);
						return nullptr;
					}
				}
				Buffer++;
			}
			if (SubCount > 0)
			{
				ErrorText->Logf(TEXT("%sImportText(UKGSLDialogueLine): Not enough closing parenthesis in: %s"), ErrorCount++ > 0 ? LINE_TERMINATOR : TEXT(""), InBuffer);
				return nullptr;
			}

			// Skip comma.
			if (*Buffer == TCHAR(','))
			{
				// Skip comma.
				Buffer++;
			}
			else if (*Buffer != TCHAR(')'))
			{
				ErrorText->Logf(TEXT("%sImportText (UKGSLDialogueLine): Missing closing parenthesis: %s"), ErrorCount++ > 0 ? LINE_TERMINATOR : TEXT(""), InBuffer);
				return nullptr;
			}

			SkipWhitespace(Buffer);
		}

		// Skip trailing ')'.
		Buffer++;
	}
	else
	{
		ErrorText->Logf(TEXT("%sImportText (UKGSLDialogueLine): Missing opening parenthesis: %s"), ErrorCount++ > 0 ? LINE_TERMINATOR : TEXT(""), InBuffer); //-V547
		return nullptr;
	}
	return Buffer;
}

UKGSLDialogueLine* UKGSLDialogueLine::Instance(UObject* Outer, const FString& InContent, FName Name, const FString& InGUID)
{
	UKGSLDialogueLine* Line = NewObject<UKGSLDialogueLine>(Outer, Name);
	check(IsValid(Line));
	Line->Initialize(InContent, InGUID);
	return Line;
}

void UKGSLDialogueOption::CopyTo(FDialogueOption& OutOption)
{
	for (TFieldIterator<FProperty> It(this->StaticClass()); It; ++It)
	{
		FProperty* Property = *It;
		if (FProperty* DstProperty = FindFProperty<FProperty>(FDialogueOption::StaticStruct(), Property->GetFName()))
		{
			ensureMsgf(DstProperty->GetCPPType() == Property->GetCPPType(),
			           TEXT("The property: %s in UKGSLDialogueOption is %s,but which in FDialogueOption is %s"),
			           *Property->GetName(), *Property->GetCPPType(), *DstProperty->GetCPPType());

			const void* SrcPtr = Property->ContainerPtrToValuePtr<void>(this);
			DstProperty->SetValue_InContainer(&OutOption, SrcPtr);
		}
	}
}

UKGSLDialogueOption* UKGSLDialogueOption::Instance(UObject* Outer, FName Name)
{
	UKGSLDialogueOption* Option = NewObject<UKGSLDialogueOption>(Outer, Name);
	check(Option);
	return Option;
}

#pragma endregion



#pragma region UKGSLDialogueEpisode

void UKGSLDialogueEpisode::SetEpisodeID(int32 InEpisodeID)
{
	EpisodeID = InEpisodeID;
}

UKGSLDialogueLine* UKGSLDialogueEpisode::InstanceLine(const FString& Content, const FString& InGUID)
{
	return UKGSLDialogueLine::Instance(this, Content, NAME_None,InGUID);
}

void UKGSLDialogueEpisode::AddLine(UKGSLDialogueLine* Line, int32 LineIndex)
{
	check(IsValid(Line));
	
	if(DialogueLines.IsValidIndex(LineIndex))
	{
		DialogueLines.Insert(Line, LineIndex);
	}
	else
	{
		DialogueLines.Add(Line);
	}
}

UKGSLDialogueLine* UKGSLDialogueEpisode::GetLine(int32 InLineIndex)
{
	if(DialogueLines.IsValidIndex(InLineIndex))
	{
		return DialogueLines[InLineIndex];
	}

	return nullptr;
}

UKGSLDialogueLine* UKGSLDialogueEpisode::GetLineByGUID(int32 InGUID)
{
	uint32 uGUID = static_cast<uint32>(InGUID);
	for(UKGSLDialogueLine* Line : DialogueLines)
	{
		if(Line->GUID == uGUID)
		{
			return Line;
		}
	}

	return nullptr;
}

void UKGSLDialogueEpisode::RemoveLine(int32 InLineIndex)
{
	if(DialogueLines.IsValidIndex(InLineIndex))
	{
		DialogueLines.RemoveAt(InLineIndex);
		Modify();
	}
}

void UKGSLDialogueEpisode::RemoveLineByGUID(int32 InGUID)
{
	uint32 uGUID = static_cast<uint32>(InGUID);
	for(UKGSLDialogueLine* Line : DialogueLines)
	{
		if(Line->GUID == uGUID)
		{
			DialogueLines.Remove(Line);
			Modify();
			break;
		}
	}
}

UKGSLDialogueOption* UKGSLDialogueEpisode::InstanceOption()
{
	return UKGSLDialogueOption::Instance(this);
}

void UKGSLDialogueEpisode::AddOption(UKGSLDialogueOption* Option, int32 InOptionIndex)
{
	check(IsValid(Option));
	
	if(Options.IsValidIndex(InOptionIndex))
	{
		Options.Insert(Option, InOptionIndex);
	}
	else
	{
		Options.Add(Option);
	}
}

void UKGSLDialogueEpisode::RemoveOption(int32 InOptionIndex)
{
	if(Options.IsValidIndex(InOptionIndex))
	{
		Options.RemoveAt(InOptionIndex);
	}
}

int32 UKGSLDialogueEpisode::CopyOptionsToEpisodeData(FDialogueEpisode& EpisodeData)
{
	EpisodeData.Options.Empty();
	for(UKGSLDialogueOption* Option : Options)
	{
		FDialogueOption& DstOption = EpisodeData.Options.AddDefaulted_GetRef();
		Option->CopyTo(DstOption);
	}

	return 0;
}

TArray<UDialogueTrackBase*> UKGSLDialogueEpisode::GetAllTracks(bool bIncludeSpawnableTackActions)
{
	TQueue<UDialogueTrackBase*> Queue;
	for (int32 i = 0; i < TrackList.Num(); ++i)
	{
		Queue.Enqueue(TrackList[i]);
	}
	
	TArray<UDialogueTrackBase*> OutTrackList;
	while (!Queue.IsEmpty())
	{
		UDialogueTrackBase* Track;
		Queue.Dequeue(Track);
		OutTrackList.Add(Track);
		for (int32 i = 0; i < Track->Childs.Num(); ++i)
		{
			Queue.Enqueue(Track->Childs[i]);
		}

		if(bIncludeSpawnableTackActions)
		{
			for(auto* Action : Track->Actions)
			{
				Queue.Enqueue(Action);
			}
		}
	}
	return OutTrackList;
}

TMap<FString, UDialogueCameraTrack*> UKGSLDialogueEpisode::GetTrackCameras()
{
	const TArray<UDialogueTrackBase*>& AllTrackList = GetAllTracks();
	TMap<FString, UDialogueCameraTrack*> Cameras;
	for (int32 i = 0; i < AllTrackList.Num(); ++i)
	{
		if (UDialogueCameraTrack* Camera = Cast<UDialogueCameraTrack>(AllTrackList[i]))
		{
			Cameras.Add(TTuple<FString, UDialogueCameraTrack*>(Camera->GetTrackName().ToString(), Camera));
		}
	}
	return Cameras;
}

TMap<FString, UDialogueActorTrack*> UKGSLDialogueEpisode::GetTrackActors()
{
	const TArray<UDialogueTrackBase*>& AllTrackList = GetAllTracks();
	TMap<FString, UDialogueActorTrack*> Actors;
	for (int32 i = 0; i < AllTrackList.Num(); ++i)
	{
		if (UDialogueActorTrack* Actor = Cast<UDialogueActorTrack>(AllTrackList[i]))
		{
			Actors.Add(TTuple<FString, UDialogueActorTrack*>(Actor->GetTrackName().ToString(), Actor));
		}
	}
	return Actors;
}


#pragma endregion



#pragma region UDialogueBaseAsset 

TArray<UDialogueTrackBase*> FDialogueEpisode::GetAllTracks(bool bIncludeSpawnableTackActions)
{
	TArray<UDialogueTrackBase*> OutTrackList;
	TQueue<UDialogueTrackBase*> Queue;
	for (int32 i = 0; i < TrackList.Num(); ++i)
	{
		Queue.Enqueue(TrackList[i]);
	}
	while (!Queue.IsEmpty())
	{
		UDialogueTrackBase* Track;
		Queue.Dequeue(Track);
		OutTrackList.Add(Track);
		for (int32 i = 0; i < Track->Childs.Num(); ++i)
		{
			Queue.Enqueue(Track->Childs[i]);
		}

		if(bIncludeSpawnableTackActions)
		{
			for(auto* Action : Track->Actions)
			{
				Queue.Enqueue(Action);
			}
		}
	}
	return OutTrackList;
}

TMap<FString, UDialogueCameraTrack*> FDialogueEpisode::GetTrackCameras()
{
	const TArray<UDialogueTrackBase*>& AllTrackList = GetAllTracks();
	TMap<FString, UDialogueCameraTrack*> Cameras;
	for (int32 i = 0; i < AllTrackList.Num(); ++i)
	{
		if (UDialogueCameraTrack* Camera = Cast<UDialogueCameraTrack>(AllTrackList[i]))
		{
			Cameras.Add(TTuple<FString, UDialogueCameraTrack*>(Camera->GetTrackName().ToString(), Camera));
		}
	}
	return Cameras;
}

TMap<FString, UDialogueActorTrack*> FDialogueEpisode::GetTrackActors()
{
	const TArray<UDialogueTrackBase*>& AllTrackList = GetAllTracks();
	TMap<FString, UDialogueActorTrack*> Actors;
	for (int32 i = 0; i < AllTrackList.Num(); ++i)
	{
		if (UDialogueActorTrack* Actor = Cast<UDialogueActorTrack>(AllTrackList[i]))
		{
			Actors.Add(TTuple<FString, UDialogueActorTrack*>(Actor->GetTrackName().ToString(), Actor));
		}
	}
	return Actors;
}

FName FDialogueEpisode::GetName()
{
#if WITH_EDITORONLY_DATA
	InitName();
	return Name;
#else
	return NAME_None;
#endif
	
}

void FDialogueEpisode::InitName()
{
#if WITH_EDITORONLY_DATA
	if(KGStoryLine::IsValidEpisodeID(EpisodeID) && Name.IsNone())
	{
		Name = FName(FString::Printf(TEXT("Episode:%d"), EpisodeID));
	}
#endif
}

UDialogueBaseAsset::UDialogueBaseAsset(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
#if WITH_EDITOR
	Episodes.AddDefaulted();
#endif
}

UDialogueEntity* UDialogueBaseAsset::FindAssetEntity(const FString& TrackName)
{
	TArray<UDialogueEntity*> AllEntities = GetAllEntities();
	for (UDialogueEntity* Entity : AllEntities)
	{
		if (Entity && Entity->TrackName == TrackName)
			return Entity;
	}
	return nullptr;
}


TArray<UDialogueEntity*> UDialogueBaseAsset::GetAllEntities()
{
	TArray<UDialogueEntity*> Ret;
	if (CameraList.Num() > 0)
	{
		// 优先将锚点加入数组
		Ret.Emplace(CameraList[0]);
	}

	Ret.Append(PerformerList);
	
	for (int32 i = 1; i < CameraList.Num(); ++i)
	{
		Ret.Emplace(CameraList[i]);
	}

	Ret.Append(RoutePointList);
	Ret.Append(NewEntityList);
	return Ret;
}

TArray<UDialogueEntity*> UDialogueBaseAsset::GetRootEntity()
{
	TArray<UDialogueEntity*> Ret;
	if(Episodes.Num() <= 0)
		return Ret;

	FDialogueEpisode DialogueEpisode = Episodes[0];
	const TArray<UDialogueEntity*> AllEntities = GetAllEntities();

	for (UDialogueTrackBase* DialogueTrackBase : DialogueEpisode.TrackList)
	{
		if (UDialogueSpawnableTrack* DialogueSpawnableTrack = Cast<UDialogueSpawnableTrack>(DialogueTrackBase))
		{
			if(DialogueSpawnableTrack->GetDialogueEntity())
				Ret.Add(DialogueSpawnableTrack->GetDialogueEntity());

		}
	}
	return Ret;
}

UDialogueTrackBase* UDialogueBaseAsset::FindTrackByName(int32 EpisodeIndex, FName TrackName)
{
	int32 Index = 0;
	for (FDialogueEpisode& Episode : Episodes)
	{
		if (Index++ == EpisodeIndex)
		{
			TArray<UDialogueTrackBase*> AllTracks = Episode.GetAllTracks();
			for (UDialogueTrackBase* Ret : AllTracks)
			{
				if (Ret->GetTrackName().ToString() == TrackName.ToString())
					return Ret;
			}
		}
	}
	return nullptr;
}

void UDialogueBaseAsset::SetEpisodeDuration(int32 EpisodeID, float Duration)
{
	for (FDialogueEpisode& Episode : Episodes)
	{
		if (Episode.EpisodeID == EpisodeID)
		{
			Episode.Duration = Duration;
			break;
		}
	}
}

UDialogueTrackBase* UDialogueBaseAsset::FindEpisodeTrackByName(int32 EpisodeID, FName TrackName)
{
	for (FDialogueEpisode& Episode : Episodes)
	{
		if (Episode.EpisodeID == EpisodeID)
		{
			TArray<UDialogueTrackBase*> AllTracks = Episode.GetAllTracks();
			for (UDialogueTrackBase* Ret : AllTracks)
			{
				if (Ret !=nullptr && Ret->GetTrackName().ToString() == TrackName.ToString())
					return Ret;
			}
			break;
		}
	}
	return nullptr;
}

UDialogueTrackBase* UDialogueBaseAsset::FindEpisodeTrackByTrackClass(int32 EpisodeID, UClass* TrackClass)
{
	if (TrackClass == nullptr)
		return nullptr;
	for (FDialogueEpisode& Episode : Episodes)
	{
		if (Episode.EpisodeID == EpisodeID)
		{
			TArray<UDialogueTrackBase*> AllTracks = Episode.GetAllTracks();
			for (UDialogueTrackBase* Ret : AllTracks)
			{
				if (Ret != nullptr && Ret->IsA(TrackClass))
					return Ret;
			}
			break;
		}
	}
	return nullptr;
}

bool UDialogueBaseAsset::AddEpisode(int32 EpisodeID)
{
	if(KGStoryLine::IsValidEpisodeID(EpisodeID))
	{
		if (Episodes.FindByPredicate([EpisodeID](const FDialogueEpisode& Episode) -> bool { return Episode.EpisodeID == EpisodeID; }) == nullptr)
		{
			FDialogueEpisode& NewEpisode = Episodes.AddDefaulted_GetRef();
			NewEpisode.EpisodeID = EpisodeID;
			OnEpisodeAdded(NewEpisode, EpisodeID);
		
			GetPackage()->MarkPackageDirty();
		}
		return true;
	}

	return false;
}

bool UDialogueBaseAsset::RemoveEpisode(int32 EpisodeID)
{
	Episodes.RemoveAll([EpisodeID](const FDialogueEpisode& Episode)
	{
		return Episode.EpisodeID == EpisodeID;
	});

	GetPackage()->MarkPackageDirty();

	return true;
}

bool UDialogueBaseAsset::AddTrack(int32 EpisodeIndex, UDialogueTrackBase* Track, int32 Pos/*=-1*/)
{
	if (!Episodes.IsValidIndex(EpisodeIndex))
	{
		Track->MarkAsGarbage();
		return false;
	}
	if(Pos == -1)
		Episodes[EpisodeIndex].TrackList.Add(Track);
	else
		Episodes[EpisodeIndex].TrackList.Insert(Track, Pos);
	GetPackage()->MarkPackageDirty();
	return true;
}

bool UDialogueBaseAsset::AddTrackByEpisodeID(int32 InEpisodeID, UDialogueTrackBase* Track, int32 Pos)
{
	if (FDialogueEpisode* Episode = Episodes.FindByPredicate([InEpisodeID](const FDialogueEpisode& Episode) { return Episode.EpisodeID == 
	InEpisodeID; }))
	{
		if (Pos == -1)
		{
			Episode->TrackList.Add(Track);
		}
		else
		{
			Episode->TrackList.Insert(Track, Pos);
		}
		return true;
	}

	if (Track)
	{
		Track->MarkAsGarbage();
	}
	return false;
}

int32 UDialogueBaseAsset::GetCameraCutIndex(int32 EpisodeID)
{
	if (!Episodes.IsValidIndex(EpisodeID))
	{
		return 0;
	}
	for(int i=0;i<Episodes[EpisodeID].TrackList.Num();i++)
	{
		if(UDialogueCameraCutTrack* CameraCut = Cast<UDialogueCameraCutTrack> (Episodes[EpisodeID].TrackList[i]))
		{
			return i;
		}
	}
	return 0;
}

bool UDialogueBaseAsset::AddTrackToAnchor(int32 EpisodeIndex, UDialogueTrackBase* InTrack, int32 Pos)
{
	if (!Episodes.IsValidIndex(EpisodeIndex))
	{
		InTrack->MarkAsGarbage();
		return false;
	}

	bool bAdded = false;
	auto& Episode = Episodes[EpisodeIndex];
	for (auto* Track : Episode.TrackList)
	{
		if (Track->IsA(UDialogueCameraTrack::StaticClass()))
		{
			InTrack->Parent = Track;
			Track->Childs.Add(InTrack);
			bAdded = true;
			break;
		}
	}

	if (!bAdded)
	{
		if (Pos == -1)
			Episodes[EpisodeIndex].TrackList.Add(InTrack);
		else
			Episodes[EpisodeIndex].TrackList.Insert(InTrack, Pos);
	}

	GetPackage()->MarkPackageDirty();
	
	return true;
}

bool UDialogueBaseAsset::RemoveTrack(int32 EpisodeID, UDialogueTrackBase& Track)
{
	if (!Episodes.IsValidIndex(EpisodeID))
	{
		Track.MarkAsGarbage();

		return false;
	}
	Episodes[EpisodeID].TrackList.Remove(&Track);
	GetPackage()->MarkPackageDirty();
	return true;
}

bool UDialogueBaseAsset::RemoveTrackByName(int32 EpisodeIndex, const FString& TrackName)
{
	if (!Episodes.IsValidIndex(EpisodeIndex))
		return false;
	Episodes[EpisodeIndex].TrackList.RemoveAll([TrackName](UDialogueTrackBase* Element)
	{
		return Element->GetTrackName().ToString() == TrackName;
	});
	GetPackage()->MarkPackageDirty();
	return true;
}

void UDialogueBaseAsset::RemoveAllEpisodesTrackByName(const FString& TrackName)
{
}

void UDialogueBaseAsset::AddPerformer(UDialogueActor* Performer)
{
	PerformerList.AddUnique(Performer);
}

void UDialogueBaseAsset::RemovePerformer(UDialogueActor* Performer)
{
	PerformerList.Remove(Performer);
}

void UDialogueBaseAsset::AddCamera(UDialogueCamera* Camera)
{
	if(Camera == nullptr)
		return;
    
	CameraList.AddUnique(Camera);
}

void UDialogueBaseAsset::AddRoutePoint(UDialogueEntity* RoutePoint)
{
	RoutePointList.AddUnique(RoutePoint);
}

void UDialogueBaseAsset::RemoveRoutePoint(UDialogueEntity* RoutePoint)
{
	RoutePointList.Remove(RoutePoint);
}

void UDialogueBaseAsset::AddDialogueEntity(UDialogueEntity* DialogueEntity)
{
	if(UDialogueActor* DialogueActor = Cast<UDialogueActor>(DialogueEntity))
	{
		AddPerformer(DialogueActor);
	}
	else if (UDialogueCamera* DialogueCamera = Cast<UDialogueCamera>(DialogueEntity))
	{
		AddCamera(DialogueCamera);
	}
	else
	{//新加的路径点不再添加到RouterPointList里面，一律添加到NewEntityList
		NewEntityList.AddUnique(DialogueEntity);
	}
}

void UDialogueBaseAsset::RemoveDialogueEntity(UDialogueEntity* DialogueEntity)
{
	if (UDialogueActor* DialogueActor = Cast<UDialogueActor>(DialogueEntity))
	{
		PerformerList.Remove(DialogueActor);
	}
	else if (UDialogueCamera* DialogueCamera = Cast<UDialogueCamera>(DialogueEntity))
	{
		CameraList.Remove(DialogueCamera);
	}
	else
	{
		//为了兼容考虑，目前还扫描一下路径点
		RoutePointList.Remove(DialogueEntity);
		NewEntityList.Remove(DialogueEntity);
	}
}

void UDialogueBaseAsset::RemoveCamera(UDialogueCamera* Camera)
{
	CameraList.Remove(Camera);
}

UDialogueActionBase* UDialogueBaseAsset::AddSection(int32 EpisodeID, UDialogueActionTrack* InAction)
{
	if (InAction == nullptr)
		return nullptr;
	UDialogueActionBase* NewActionSection = NewObject<UDialogueActionBase>(InAction, InAction->SectionType, NAME_None);
	ensureMsgf(NewActionSection, TEXT("AddSection faield:NewActionSection == nllptr "));
	NewActionSection->OwnedEpisodeID = EpisodeID;
	InAction->AddSection(NewActionSection);
	return NewActionSection;
}

UDialogueActionBase* UDialogueBaseAsset::AddSecondTypeSection(int32 EpisodeID, UDialogueActionTrack* InAction)
{
	if (InAction == nullptr)
		return nullptr;
	if (InAction->GetSecondSectionType())
	{
		UDialogueActionBase* NewActionSection = NewObject<UDialogueActionBase>(InAction, InAction->GetSecondSectionType(), NAME_None);
		ensureMsgf(NewActionSection, TEXT("AddSection failed:NewActionSection == nullptr "));
		NewActionSection->OwnedEpisodeID = EpisodeID;
		InAction->AddSection(NewActionSection);
		return NewActionSection;
	}
	return nullptr;
}

UDialogueActionBase* UDialogueBaseAsset::CopySection(int32 EpisodeID, UDialogueActionBase* InActionSection, UDialogueActionTrack* InAction)
{
	if (InAction == nullptr)
		return nullptr;
	UDialogueActionBase* CopiedObject = DuplicateObject<UDialogueActionBase>(InActionSection, this);
	InAction->AddSection(CopiedObject);
	return CopiedObject;
}

TArray<UDialogueTrackBase*> UDialogueBaseAsset::GetAllTracks(int32 EpisodeIndex)
{
	TArray<UDialogueTrackBase*> Ret;
	if(FDialogueEpisode* Episode = GetEpisodePointerByIndex(EpisodeIndex))
		Ret = Episode->GetAllTracks();
	return Ret;
}

TArray<UDialogueTrackBase*> UDialogueBaseAsset::GetAllTacksByEpisodeID(int32 EpisodeID, bool bIncludeSpawnableTackActions)
{
	TArray<UDialogueTrackBase*> Ret;
	if(FDialogueEpisode* Episode = GetEpisodePointerByID(EpisodeID))
	{
		Ret = Episode->GetAllTracks(bIncludeSpawnableTackActions);
	}
	return Ret;
}

TMap<FString, UDialogueCameraTrack*> UDialogueBaseAsset::GetTrackCameras(FDialogueEpisode& Episode)
{
	return Episode.GetTrackCameras();
}

TMap<FString, UDialogueActorTrack*> UDialogueBaseAsset::GetTrackActors(FDialogueEpisode& Episode)
{
	return Episode.GetTrackActors();
}

TArray<UDialogueActorTrack*> UDialogueBaseAsset::GetTrackActorsArray(FDialogueEpisode& Episode)
{
	TArray<UDialogueActorTrack*> Ret;
	TMap<FString, UDialogueActorTrack*> TrackActors = Episode.GetTrackActors();
	TrackActors.GenerateValueArray(Ret);
	return Ret;
}

TArray<UDialogueSpawnableTrack*> UDialogueBaseAsset::GetSpawnableTracks(FDialogueEpisode& Episode)
{
	TArray<UDialogueSpawnableTrack*> Ret;
	const TArray<UDialogueTrackBase*>& AllTrackList = Episode.GetAllTracks();
	for (int32 i = 0; i < AllTrackList.Num(); ++i)
	{
		if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(AllTrackList[i]))
		{
			Ret.Add(SpawnableTrack);
		}
	}
	return Ret;
}


#if WITH_EDITOR
void UDialogueBaseAsset::OnEditorInitialized()
{
    for (int32 i = 0; i < Episodes.Num(); ++i)
    {
        auto AllTrack = GetAllTracks(i);
        for (auto* Track : AllTrack)
        {
            if (Track)
            {
                Track->OnEditorInitialized();
            }
        }
    }

    auto AlleEntities = GetAllEntities();
    for (auto Entity : AlleEntities)
    {
        Entity->OnEditorInitialized();
    }
}

void UDialogueBaseAsset::RenameTrackName(const FString& OldTrackName, const FString& NewTrackName)
{
	for (FDialogueEpisode& Episode : Episodes)
	{
		TArray<UDialogueTrackBase*>  AllTracks = Episode.GetAllTracks();
		if (UDialogueTrackBase** SrcTrackPtr = AllTracks.FindByPredicate([OldTrackName](UDialogueTrackBase* Track) {return Track->GetTrackName().ToString() == OldTrackName; }))
		{
			(*SrcTrackPtr)->SetTrackName(FText::FromString(NewTrackName));
		}
	}

	TArray<UDialogueEntity*> AllEntities = GetAllEntities();
	for (UDialogueEntity* DialogueEntity : AllEntities)
	{
		if (DialogueEntity && DialogueEntity->TrackName == OldTrackName)
		{
			DialogueEntity->TrackName = NewTrackName;
			break;
		}
	}
}

bool UDialogueBaseAsset::IsNewTrackNameValid(const FString& NewTrackName)
{
	for (FDialogueEpisode& Episode : Episodes)
	{
		TArray<UDialogueTrackBase*>  AllTracks = Episode.GetAllTracks();
		if (bool Contains = AllTracks.ContainsByPredicate([NewTrackName](UDialogueTrackBase* Track) {return Track->GetTrackName().ToString() == NewTrackName; }))
		{
			return false;
		}
	}
	return true;
}
// 遍历模板轨道，递归每个子轨道
UDialogueTrackBase* UDialogueBaseAsset::RoamTrack(UDialogueTrackBase* InTrack)
{
	UDialogueTrackBase* NewTrack = NewObject<UDialogueTrackBase>(this, InTrack->GetClass(), NAME_None, RF_Transactional);
	NewTrack->DuplicateFromTrack(InTrack);
	if (UDialogueActorTrack* TrackActor = Cast<UDialogueActorTrack>(NewTrack))
	{
		UDialogueActor* DialogueActor = Cast<UDialogueActor>(TrackActor->GetDialogueEntity());
		AddPerformer(DialogueActor);
	}
	else if (UDialogueCameraTrack* TrackCamera = Cast<UDialogueCameraTrack>(NewTrack))
	{
		if(UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(this))
		{
			if(DialogueAsset->UseTemplateCamera)
			{
				AddCamera(Cast<UDialogueCamera>(TrackCamera->GetDialogueEntity()));
			}
#if WITH_EDITOR
			else if(TrackCamera->GetTrackName().ToString() == TEXT("锚点"))
			{
				AddCamera(Cast<UDialogueCamera>(TrackCamera->GetDialogueEntity()));
			}
#endif
			
		}
		else
		{
			AddCamera(Cast<UDialogueCamera>(TrackCamera->GetDialogueEntity()));
		}
	}
	else if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueCameraTrack>(NewTrack))
	{
		AddDialogueEntity(SpawnableTrack->GetDialogueEntity());
	}
	for (int32 i = 0; i < InTrack->Childs.Num(); ++i)
	{
		UDialogueTrackBase* ChildTrack = RoamTrack(InTrack->Childs[i]);
		if (UDialogueCameraTrack* TrackCamera = Cast<UDialogueCameraTrack>(ChildTrack))
		{
			if(UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(this))
			{
#if WITH_EDITOR
				if(!DialogueAsset->UseTemplateCamera && TrackCamera->GetTrackName().ToString() != TEXT("锚点"))
				{
					continue;
				}
#endif
			}
		}
		NewTrack->AddChild(ChildTrack);
		ChildTrack->Parent = NewTrack;
		UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(NewTrack);
		UDialogueSpawnableTrack* ChildSpawnableTrack = Cast<UDialogueSpawnableTrack>(ChildTrack);
		if (SpawnableTrack && ChildSpawnableTrack &&
			ChildSpawnableTrack->GetDialogueEntity() && SpawnableTrack->GetDialogueEntity())
		{
			ChildSpawnableTrack->GetDialogueEntity()->SetParent(SpawnableTrack->GetDialogueEntity());
		}
	}
	return NewTrack;
}
#endif
void UDialogueBaseAsset::PostLoad()
{
	Super::PostLoad();
	for (FDialogueEpisode& Episode : Episodes)
	{
		Episode.TrackList.Remove(nullptr);
	}
}

#pragma endregion UDialogueBaseAsset




#pragma region UDialogueAsset 

UDialogueAsset::UDialogueAsset(const FObjectInitializer& ObjectInitializer) 
	: Super(ObjectInitializer)
{
#if WITH_EDITOR
	if(!HasAnyFlags(EObjectFlags::RF_ClassDefaultObject | EObjectFlags::RF_ArchetypeObject))
	{
		if(UKGSLDialogueEpisode* Episode = CreateDefaultSubobject<UKGSLDialogueEpisode>(TEXT("KGSLDialogueEpisode")))
		{
			Episode->SetEpisodeID(1);
			EpisodesList.Add(Episode);
			
			if(Episodes.Num() <= 0)
			{
				Episodes.Add(FDialogueEpisode(Episode->GetEpisodeID()));
			}

			auto& E = Episodes[0];
			E.EpisodeID = Episode->GetEpisodeID();
		}
	}
#endif
}


void UDialogueAsset::Serialize(FArchive& Ar)
{
#if WITH_EDITOR
	if (Ar.IsSaving() && !Ar.IsCooking())
	{
		GenerateGUIDForLines();
		LinkSectionsAndLines();
	}
#endif

	Super::Serialize(Ar);
}

FString UDialogueAsset::GenerateLineGUIDForSection(const FString& ContentString /*= TEXT("")*/, const FString SuffixText /*= TEXT("")*/)
{
#if WITH_EDITOR
	return FGuid::NewGuid().ToString(EGuidFormats::Digits);
#else
	return "";
#endif
}

bool UDialogueAsset::IsValidEpisodeID(int32 InEpisodeID)
{
	bool bValid = true;
#if WITH_EDITORONLY_DATA
	bValid = EpisodesList.FindByPredicate([InEpisodeID](const UKGSLDialogueEpisode* Episode)
		{
			return Episode && Episode->GetEpisodeID() == InEpisodeID;
		}) != nullptr;
#endif
	
	return KGStoryLine::IsValidEpisodeID(InEpisodeID) && bValid;

}

bool UDialogueAsset::RemoveActorInfo(const FString& ActorName)
{
	ActorInfos.RemoveAll([&ActorName](FDialogueActorInfo& Info) { return Info.PerformerName == ActorName; });
	auto RemoveTrack = [this](FDialogueEpisode& Episode, UDialogueTrackBase* Track)
		{
			if (auto* ActionTrack = Cast<UDialogueActionTrack>(Track))
			{
				if (ActionTrack->Parent)
				{
					ActionTrack->Parent->SetFlags(EObjectFlags::RF_Transactional);
					ActionTrack->Parent->Modify();
					ActionTrack->Parent->RemoveAction(ActionTrack);
				}
				else
				{
					Episode.TrackList.Remove(Track);
				}
				return;
			}

			if (auto* SpawnableTrack = Cast<UDialogueSpawnableTrack>(Track))
			{
				TArray<UDialogueTrackBase*> AllChildTracks;
				Track->GetAllChildTracks(AllChildTracks);

				for (UDialogueTrackBase* ChildBaseTrack : AllChildTracks)
				{
					
					if (auto* ActionTrack = Cast<UDialogueActionTrack>(ChildBaseTrack))
					{
						if (ActionTrack->Parent)
						{
							ActionTrack->Parent->Modify();
							ActionTrack->Parent->RemoveAction(ActionTrack);
						}
					}
					else if (auto* ChildSpawnableTrack = Cast<UDialogueSpawnableTrack>(ChildBaseTrack))
					{
						RemoveDialogueEntity(ChildSpawnableTrack->GetDialogueEntity());
						if(ChildSpawnableTrack->Parent)
						{
							ChildSpawnableTrack->Parent->Modify();
							ChildSpawnableTrack->Parent->Childs.Remove(ChildSpawnableTrack);
						}
					}
				}

				RemoveDialogueEntity(SpawnableTrack->GetDialogueEntity());
				if (SpawnableTrack->Parent)
				{
					SpawnableTrack->Parent->Childs.Remove(SpawnableTrack);
				}
				else
				{
					Episode.TrackList.Remove(Track);
				}
			}
		};

	for (auto& Episode : Episodes)
	{
		TArray<UDialogueTrackBase*> AllTracks = Episode.GetAllTracks();
		for (auto* Track : AllTracks)
		{
			if (Track->GetTrackName().ToString() == ActorName)
			{
				RemoveTrack(Episode, Track);
			}
		}
	}


	return false;
}

FDialogueActorInfo& UDialogueAsset::FindOrAddActorInfo(const FString& ActorName)
{
	for (auto& Info : ActorInfos)
	{
		if (Info.PerformerName == ActorName)
		{
			return Info;
		}
	}

	auto& Info = ActorInfos.AddDefaulted_GetRef();
	Info.PerformerName = ActorName;
	return Info;
}

void UDialogueAsset::BeginDestroy()
{
#if WITH_EDITOR
	OnDialogueEpisodeChangedEvent.Clear();
#endif
	Super::BeginDestroy();
}
#if WITH_EDITOR

void UDialogueAsset::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	if (this == GetClass()->GetDefaultObject())
	{
		UE_LOG(LogTemp, Log, TEXT("Modify DialogueAsset Default Object"));
		return;
	}

	const FName PropertyName = (PropertyChangedEvent.Property ? PropertyChangedEvent.Property->GetFName() : NAME_None);

	if (PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UDialogueAsset, DialogueTemplate))
	{
		RefreshOnChangeTemplate();
	}
	
	RefreshSelectors();
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UDialogueAsset::RefreshOnChangeTemplate()
{
	OnDialogueAssetTemplateChangedEvent.Broadcast();
}

void UDialogueAsset::UpdateActorInfosData()
{
	//第一步，保存旧的信息（主要是AppereanceID Animation IsPlayer等信息）
	TMap<FString, FDialogueActorInfo> OldActorInfos;
	for (const FDialogueActorInfo& Element : ActorInfos)
		OldActorInfos.Add(Element.PerformerName, Element);

	//第二步，根据TrackActor信息，重构ActorInfos
	TMap < FString, UDialogueActorTrack* > TrackActors = Episodes[0].GetTrackActors();
	ActorInfos.Empty();
	for (auto [TrackName, TrackActor] : TrackActors)
	{
		if (UDialogueActor* pDialogueActor = Cast<UDialogueActor>(TrackActor->GetDialogueEntity()))
		{
			FDialogueActorInfo& Info = ActorInfos.AddDefaulted_GetRef();
			Info.PerformerName = TrackName;
			Info.AppearanceID.Owner = this;
			pDialogueActor->CopyToActorInfo(&Info);
			if (FDialogueActorInfo* pOldInfo = OldActorInfos.Find(TrackName))
			{
				Info.AppearanceID.ApperanceID = pOldInfo->AppearanceID.ApperanceID;
				Info.bIsPlayer = pOldInfo->bIsPlayer;
				Info.IdleAnimation = pOldInfo->IdleAnimation;
			}
		}
	}

	//第三步，先把ActorInfos信息同步到Track里面
	for (const FDialogueActorInfo& Element : ActorInfos)
	{
		for (FDialogueEpisode& Episode : Episodes)
		{
			TMap < FString, UDialogueActorTrack* > EpisodeTrackActors = Episode.GetTrackActors();
			if (UDialogueActorTrack** ppTrackActor = EpisodeTrackActors.Find(Element.PerformerName))
			{
				if (UDialogueActorTrack* pTrackActor = *ppTrackActor)
				{
					if (UDialogueActor* pDialogueActor = Cast<UDialogueActor>(pTrackActor->GetDialogueEntity()))
					{
						pDialogueActor->CopyFromActorInfo(&Element);
					}
				}

			}
		}
	}
}

void UDialogueAsset::PostLoad()
{
	Super::PostLoad();
	RefreshSelectors();
	
#if WITH_EDITOR
	if(!HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
	{
		// generate GUID for lines for old data and link sections and lines
		GenerateGUIDForLines();
		LinkSectionsAndLines();

	}
#endif
}

void UDialogueAsset::RefreshSelectors()
{
	for (int32 i = 0; i < ActorInfos.Num(); ++i)
	{
		ActorInfos[i].AppearanceID.Owner = this;
	}
}

bool UDialogueAsset::FindAppreanceName(int32 InAppreancceID, FName& OutName)
{
	for (TMap<FString, FAppreanceTableData>::TConstIterator ite = AppearanceTableData.CreateConstIterator(); ite; ++ite)
	{
		if (const FAppreanceDataItem* Item = ite->Value.FindID(InAppreancceID))
		{
			OutName = *Item->Name;
			return true;
		}
	}
	return false;
}

bool UDialogueAsset::IsUsingLuaAsset()
{
	return GKGSLUseLuaAsset;
}

void UDialogueAsset::SwitchUsingLuaAsset(bool bUsingLuaAsset)
{
	GKGSLUseLuaAsset = bUsingLuaAsset;
}

bool UDialogueAsset::IsUsingUObject() const
{
	return GKGSLUseObject;
}

void UDialogueAsset::ClearEpisodesList()
{
	EpisodesList.Empty();
}

UKGSLDialogueEpisode* UDialogueAsset::InstanceDialogueEpisode(int32 EpisodeID)
{
	UKGSLDialogueEpisode* Episode = NewObject<UKGSLDialogueEpisode>(this);
	checkf(Episode, TEXT("Failed to allocate UDialogueAsset::CreateDialogueEpisode"));

	if(!KGStoryLine::IsValidEpisodeID(EpisodeID))
	{
		EpisodeID = GenerateValidEpisodeID();
	}
	Episode->SetEpisodeID(EpisodeID);
	
	return Episode;
}

UKGSLDialogueLine* UDialogueAsset::InstanceDialogueLine(int32 EpisodeID, const FString& Content, const FString& InGUID)
{
	if(auto* Episode = GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		return Episode->InstanceLine(Content, InGUID);
	}

	return UKGSLDialogueLine::Instance(this, Content, NAME_None, InGUID);
}

UKGSLDialogueOption* UDialogueAsset::InstanceDialogueOption(int32 EpisodeID)
{
	if(auto* Episode = GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		return Episode->InstanceOption();
	}

	return UKGSLDialogueOption::Instance(this);
}

void UDialogueAsset::AddDialogueEpisode(UKGSLDialogueEpisode* Episode, int32 EpisodeIndex)
{
	check(Episode != nullptr);
	check(KGStoryLine::IsValidEpisodeID(Episode->GetEpisodeID()));
	
	if(EpisodesList.IsValidIndex(EpisodeIndex))
	{
		EpisodesList.Insert(Episode, EpisodeIndex);
	}
	else
	{
		EpisodesList.Add(Episode);
	}

	AddEpisode(Episode->GetEpisodeID());
}


bool UDialogueAsset::GenerateGUIDForLines()
{
	if(!IsValid(this))
	{
		return false;
	}
	
	bool bNeedMarkDirty = false;
	for(auto* Episode : EpisodesList)
	{
		if(IsValid(Episode))
		{
			for(auto* Line : Episode->DialogueLines)
			{
				if(IsValid(Line) && !Line->UniqueID.IsValid())
				{
					Line->Initialize(Line->ContentString, TEXT(""));
					bNeedMarkDirty = true;
				}
			}
		}
	}

	return bNeedMarkDirty;
}

bool UDialogueAsset::LinkSectionsAndLines()
{
	if (!IsValid(this))
	{
		return false;
	}

	bool bNeedMarkDirty = false;
	for (auto& Episode : Episodes)
	{
		auto AllTracks = GetAllTacksByEpisodeID(Episode.EpisodeID, true);
		for (auto& Track : AllTracks)
		{
			if (auto* ActionTrack = Cast<UDialogueActionTrack>(Track))
			{
				for (auto* Section : ActionTrack->ActionSections)
				{
					if (!Section)
					{
						continue;
					}

					if (Section->OwnedEpisodeID == KGStoryLine::INVALID_LINE_INDEX
						|| Section->OwnedEpisodeID != Episode.EpisodeID)
					{
						Section->OwnedEpisodeID = Episode.EpisodeID;
						bNeedMarkDirty = true;
					}

					if (Section->FromLineIndex != KGStoryLine::INVALID_LINE_INDEX
						&& !Section->LineUniqueIDLinked.IsValid())
					{
						if (auto* Line = GetDialogueLine(Episode.EpisodeID, Section->FromLineIndex))
						{
							if (Line->UniqueID.IsValid())
							{
								Section->LineUniqueIDLinked = Line->UniqueID;
								bNeedMarkDirty = true;
							}
						}
					}
				}
			}
		}
	}

	return bNeedMarkDirty;
}

void UDialogueAsset::AddDialogueEpisodeOption(int32 EpisodeID, FGuid PinID)
{
	if(UKGSLDialogueEpisode* Episode = GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		if(UKGSLDialogueOption* Option = Episode->InstanceOption())
		{
			Option->PinId = PinID;
			Episode->AddOption(Option);
		}
	}	
}

void UDialogueAsset::RemoveDialogueEpisodeOption(int32 EpisodeID, FGuid PinID)
{
	if(UKGSLDialogueEpisode* Episode = GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		for(auto* Option : Episode->Options)
		{
			if(Option->PinId == PinID)
			{
				Episode->Options.Remove(Option);
				break;
			}
		}
	}
	
	//Graph区域的操作，需要反馈到Detail面板里面的CurrentSelectEpisode
	SetCurrentSelectEpisodeID(EpisodeID);
}

void UDialogueAsset::RemoveAllUnReferencedObject()
{
	// 收集UPackage里面的所有UObject
	TArray<UObject*> OutObjects;
	UPackage* Package = GetPackage();
	GetObjectsWithPackage(Package, OutObjects);
	OutObjects.Add(Package);

	// 收集资产里面真正使用的UObject对象
	TArray<UObject*> AllObjectsReferenced;
	AllObjectsReferenced.Add(GetPackage());
	AllObjectsReferenced.Add(this);
	AllObjectsReferenced.Add(GetPackage()->GetMetaData());
	TArray<UObject*> Queue;
	Queue.Add(this);
	while (Queue.Num() > 0)
	{
		UObject* Obj = Queue.Pop();
		TArray<UObject*> RefObjs;
		FReferenceFinder RefCollector(RefObjs, Obj, true, false, true, false);
		RefCollector.FindReferences(Obj);
		Queue.Append(RefObjs);
		AllObjectsReferenced.Append(RefObjs);
	}

	TArray<UObject*> ObjsPendingRemoved;
	for (UObject* Obj : OutObjects)
	{
		if (!AllObjectsReferenced.Contains(Obj))
		{
			ObjsPendingRemoved.Add(Obj);
		}
	}

	// 移除所有无用的UObject对象
	for (auto* Obj : ObjsPendingRemoved)
	{
		Obj->Rename(nullptr, GetTransientPackage());
	}
}

void UDialogueAsset::MatchActorInfosAndPerformers()
{
    if (ActorInfos.Num() != PerformerList.Num())
    {
        UE_LOG(LogKGSL, Warning, TEXT("Actor infos count != Performers count"));
        return;
    }

    TArray<int32> NotFoundActorInfoIndies;
    TArray<UDialogueActor*> OldPerformers = PerformerList;
    for (int32 Index = 0; Index < ActorInfos.Num(); Index++)
    {
        const auto& ActorInfo = ActorInfos[Index];
        bool bFound = false;
        for (auto* Performer : PerformerList)
        {
            if (Performer->TrackName == ActorInfo.PerformerName)
            {
                OldPerformers.Remove(Performer);
                if (Performer->AppearanceID != ActorInfo.AppearanceID.ApperanceID)
                {
                    Performer->AppearanceID = ActorInfo.AppearanceID.ApperanceID;
                }

                if (Performer->IdleAnimLibAssetID != ActorInfo.IdleAnimation)
                {
                    Performer->IdleAnimLibAssetID = ActorInfo.IdleAnimation;
                }

                if (Performer->UseSceneActor != ActorInfo.UseSceneActor)
                {
                    Performer->UseSceneActor = ActorInfo.UseSceneActor;
                }

                if (Performer->InsID != ActorInfo.InsID)
                {
                    Performer->InsID = ActorInfo.InsID;
                }

                if (Performer->IsPlayer() != ActorInfo.bIsPlayer)
                {
                    Performer->SetIsPlayer(ActorInfo.bIsPlayer);
                }
                
                bFound = true;
                break;
            }
        }

        if (!bFound)
        {
            NotFoundActorInfoIndies.Add(Index);
        }
    }

    
    ensure(NotFoundActorInfoIndies.Num() == OldPerformers.Num());
    for (int32 Index = 0; Index < NotFoundActorInfoIndies.Num(); Index++)
    {
        const auto& ActorInfo = ActorInfos[NotFoundActorInfoIndies[Index]];
        if (OldPerformers.Num() > 0)
        {
            if (auto* Performer = OldPerformers.Pop())
            {
                UDialogueBaseAsset::RenameTrackName(Performer->TrackName, ActorInfo.PerformerName);
                Performer->TrackName = ActorInfo.PerformerName;
                Performer->AppearanceID = ActorInfo.AppearanceID.ApperanceID;;
                Performer->IdleAnimLibAssetID = ActorInfo.IdleAnimation;
                Performer->UseSceneActor = ActorInfo.UseSceneActor;
                Performer->InsID = ActorInfo.InsID;
                Performer->SetIsPlayer( ActorInfo.bIsPlayer);
            }
        }
        else
        {
            UE_LOG(LogKGSL, Warning, TEXT("[Dialogue]Actor info:%s can not be found in performer list."), *ActorInfo.PerformerName);
        }
    }
}

void UDialogueAsset::PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.PropertyChain.GetActiveMemberNode() 
		&& PropertyChangedEvent.PropertyChain.GetActiveMemberNode()->GetValue() 
		&& PropertyChangedEvent.PropertyChain.GetActiveMemberNode()->GetValue()->GetName() == TEXT("ActorInfos"))
	{
		for (auto* Performer : PerformerList)
		{
			for (const auto& ActorInfo : ActorInfos)
			{
				if (Performer->TrackName == ActorInfo.PerformerName)
				{
					if(PropertyChangedEvent.GetPropertyName() == GET_MEMBER_NAME_STRING_CHECKED(FDialogueActorInfo, IdleAnimation))
					{
						if (Performer->IdleAnimLibAssetID.AssetID != ActorInfo.IdleAnimation.AssetID
							|| Performer->IdleAnimLibAssetID.AnimID != ActorInfo.IdleAnimation.AnimID
							|| Performer->IdleAnimLibAssetID.StateName != ActorInfo.IdleAnimation.StateName)
						{
							Performer->IdleAnimLibAssetID.StateName = ActorInfo.IdleAnimation.StateName;
							Performer->IdleAnimLibAssetID.SetAnimID(ActorInfo.IdleAnimation.AnimID);
							Performer->IdleAnimLibAssetID.SetAssetID(ActorInfo.IdleAnimation.AssetID);

							FProperty* Property = UDialogueActor::StaticClass()->FindPropertyByName(GET_MEMBER_NAME_STRING_CHECKED(UDialogueActor, IdleAnimLibAssetID));
							FPropertyChangedEvent EditPropertyChangeEvent(Property, EPropertyChangeType::ValueSet);
							Performer->PostEditChangeProperty(EditPropertyChangeEvent);
						}
					}
					else if (PropertyChangedEvent.GetPropertyName() == GET_MEMBER_NAME_STRING_CHECKED(FDialogueActorInfo, UseSceneActor))
					{
						if (Performer->UseSceneActor != ActorInfo.UseSceneActor)
						{
							Performer->UseSceneActor = ActorInfo.UseSceneActor;

							FProperty* Property = UDialogueActor::StaticClass()->FindPropertyByName(GET_MEMBER_NAME_STRING_CHECKED(UDialogueActor, UseSceneActor));
							FPropertyChangedEvent EditPropertyChangeEvent(Property, EPropertyChangeType::ValueSet);
							Performer->PostEditChangeProperty(EditPropertyChangeEvent);
						}
					}
					else if (PropertyChangedEvent.GetPropertyName() == GET_MEMBER_NAME_STRING_CHECKED(FDialogueActorInfo, bIsPlayer))
					{
						if (Performer->IsPlayer() != ActorInfo.bIsPlayer)
						{
							Performer->SetIsPlayer(ActorInfo.bIsPlayer);

							FProperty* Property = UDialogueActor::StaticClass()->FindPropertyByName(TEXT("bIsPlayer"));
							FPropertyChangedEvent EditPropertyChangeEvent(Property, EPropertyChangeType::ValueSet);
							Performer->PostEditChangeProperty(EditPropertyChangeEvent);
						}
					}
					else if (PropertyChangedEvent.GetPropertyName() == GET_MEMBER_NAME_STRING_CHECKED(FDialogueActorInfo, InsID))
					{
						if (Performer->InsID != ActorInfo.InsID)
						{
							Performer->InsID = ActorInfo.InsID;

							FProperty* Property = UDialogueActor::StaticClass()->FindPropertyByName(GET_MEMBER_NAME_STRING_CHECKED(UDialogueActor, InsID));
							FPropertyChangedEvent EditPropertyChangeEvent(Property, EPropertyChangeType::ValueSet);
							Performer->PostEditChangeProperty(EditPropertyChangeEvent);
						}
					}
					break;
				}
			}
		}
	}
}

void UDialogueAsset::RenameTrackName(const FString& OldTrackName, const FString& NewTrackName)
{
	UDialogueBaseAsset::RenameTrackName(OldTrackName, NewTrackName);

	for (FDialogueActorInfo& DialogueActorInfo : ActorInfos)
	{
		if (DialogueActorInfo.PerformerName == OldTrackName)
		{
			DialogueActorInfo.PerformerName = NewTrackName;
		}
	}
}


UKGSLDialogueEpisode* UDialogueAsset::GetDialogueEpisode(int32 EpisodeIndex)
{
	if(EpisodesList.IsValidIndex(EpisodeIndex))
	{
		return EpisodesList[EpisodeIndex];
	}
	
	return nullptr;
}

UKGSLDialogueEpisode* UDialogueAsset::GetDialogueEpisodeByEpisodeID(int32 EpisodeID)
{
	for(auto* Episode : EpisodesList)
	{
		if(Episode->GetEpisodeID() == EpisodeID)
		{
			return Episode;
		}
	}
	
	return nullptr;
}

UKGSLDialogueLine* UDialogueAsset::GetDialogueLine(int32 EpisodeID, int32 LineIndex)
{
	if(UKGSLDialogueEpisode* Episode = GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		return Episode->GetLine(LineIndex);
	}

	return nullptr;
}

UKGSLDialogueLine* UDialogueAsset::GetDialogueLineByGUID(int32 EpisodeID, int32 GUID)
{
	if(UKGSLDialogueEpisode* Episode = GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		return Episode->GetLineByGUID(GUID);
	}

	return nullptr;
}

void UDialogueAsset::RemoveDialogueEpisode(int32 EpisodeIndex)
{
	if(EpisodesList.IsValidIndex(EpisodeIndex))
	{
		if (UKGSLDialogueEpisode* Episode = EpisodesList[EpisodeIndex])
		{
			RemoveEpisode(Episode->EpisodeID);
		}
		EpisodesList.RemoveAt(EpisodeIndex);

		OnEpisodeLinesCountChange.ExecuteIfBound();
	}
}

void UDialogueAsset::RemoveDialogueEpisodeByEpisodeID(int32 EpisodeID)
{
	RemoveEpisode(EpisodeID);
	
	 int32 CountLinesRemoved = EpisodesList.RemoveAll([EpisodeID](const UKGSLDialogueEpisode* Episode)
	{
		return Episode->GetEpisodeID() == EpisodeID;
	});

	if(CountLinesRemoved > 0)
	{
		OnEpisodeLinesCountChange.ExecuteIfBound();
	}
}

void UDialogueAsset::RemoveDialogueLine(int32 EpisodeID, int32 LineIndex)
{
	if(UKGSLDialogueEpisode* Episode = GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		Episode->RemoveLine(LineIndex);
	}
}

void UDialogueAsset::RemoveDialogueLineByGUID(int32 EpisodeID, int32 GUID)
{
	if(UKGSLDialogueEpisode* Episode = GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		Episode->RemoveLineByGUID(GUID);
	}
}

int32 UDialogueAsset::GetDialogueEpisodesCount() const
{
	return EpisodesList.Num();
}

int32 UDialogueAsset::GetFirstDialogueEpisodeID() const
{
	return EpisodesList.Num() > 0 ? EpisodesList[0]->GetEpisodeID() : KGStoryLine::INVALID_EPISODE_ID;
}

int32 UDialogueAsset::GenerateValidEpisodeID()
{
	// for(int32 i = 0; i < Episodes.Num(); i++)
	// {
	// 	auto& Episode = Episodes[i];
	// 	if(Episode.EpisodeID != i + 1)
	// 	{
	// 		Episode.EpisodeID = i + 1;
	// 	}
	// }
	
	int32 EpisodeID = 0;
	for(int32 i = 0; i < EpisodesList.Num(); ++i)
	{
		UKGSLDialogueEpisode* Episode = EpisodesList[i];
		// if(IsValid(Episode) && Episode->GetEpisodeID() != i + 1)
		// {
		// 	Episode->SetEpisodeID(i + 1);
		// }
			
		// EpisodeID = i + 1;
		if(IsValid(Episode) && Episode->GetEpisodeID() >= EpisodeID)
		{
			EpisodeID = Episode->GetEpisodeID();
		}
	}

	return EpisodeID + 1;
}

void UDialogueAsset::SetCurrentSelectEpisodeID(int32 EpisodeID)
{
	bool bNewEpisode = !CurrentEpisode || CurrentEpisode->GetEpisodeID() != EpisodeID;
	CurrentEpisode = nullptr;
	for(auto* Episode : EpisodesList)
	{
		if(IsValid(Episode) && Episode->GetEpisodeID() == EpisodeID)
		{
			CurrentEpisode = Episode;
			break;
		}
	}

	if (bNewEpisode)
	{
		OnDialogueEpisodeChangedEvent.Broadcast();
	}	
}

int32 UDialogueAsset::GetCurrentSelectEpisodeID() const
{
	return CurrentEpisode && IsValid(CurrentEpisode) ? CurrentEpisode->GetEpisodeID() : KGStoryLine::INVALID_EPISODE_ID;
}


void UDialogueAsset::OnCustomSelectorChanged(FString InTrackName)
{
	OnCustomSelectorChangedEvent.Broadcast(InTrackName);
}
#endif


#pragma endregion UDialogueAsset


#pragma optimize("", on)