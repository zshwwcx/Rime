#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"

#if WITH_EDITOR
void UDialogueTrackBase::OnEditorInitialized()
{
    for (auto* Action : Actions)
    {
        Action->OnEditorInitialized();
    }

    for (auto* Child : Childs)
    {
        Child->OnEditorInitialized();
    }
}
#endif

UDialogueBaseAsset* UDialogueTrackBase::GetOwningDialogueAsset()
{
	UObject* Obj = this;
	while (Obj)
	{
		if (Obj->IsA<UDialogueBaseAsset>())
		{
			return Cast<UDialogueBaseAsset>(Obj);
		}
		
		Obj = Obj->GetOuter();
	}

	return nullptr;
}

void UDialogueTrackBase::GetAllChildTracks(TArray<UDialogueTrackBase*>& ChildTracks)
{
	ChildTracks.Append(Childs);
	for(UDialogueTrackBase* BaseTrack: Childs)
		BaseTrack->GetAllChildTracks(ChildTracks);
}

UDialogueTrackBase* UDialogueTrackBase::FindChild(const FString& InTrackName)
{
	if (UDialogueTrackBase** Ret = Childs.FindByPredicate([InTrackName](UDialogueTrackBase* Element) { return Element->GetTrackName().ToString() == InTrackName; }))
		return *Ret;
	return nullptr;
}

UDialogueActionTrack* UDialogueTrackBase::FindAction(const FString& InTrackName)
{
	if (UDialogueActionTrack** Ret = Actions.FindByPredicate([InTrackName](UDialogueActionTrack* Element) { return Element->GetTrackName().ToString() == InTrackName; }))
		return *Ret;
	return nullptr;
}


void UDialogueTrackBase::AddAction(UDialogueActionTrack* Action)
{
	Actions.Add(Action);
	Action->Parent = this;
}

UDialogueEntity* UDialogueSpawnableTrack::GetDialogueEntity() 
{ 
	return DialogueEntity;
}

void UDialogueSpawnableTrack::SetDialogueEntity(UDialogueEntity* InDialogueEntity) 
{
	DialogueEntity = InDialogueEntity;
	if (DialogueEntity != nullptr)
		DialogueEntity->TrackName = TrackName;
}

UDialogueActionTrack* UDialogueSpawnableTrack::GetActionByClass(UClass* InClass)
{
	for (int32 i = 0; i < Actions.Num(); ++i)
	{
		if (Actions[i] && Actions[i]->IsA(InClass))
		{
			return Actions[i];
		}
	}
	return nullptr;
}

#if WITH_EDITOR
void UDialogueSpawnableTrack::DuplicateFromTrack(UDialogueTrackBase* Track)
{
	Super::DuplicateFromTrack(Track);
	if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(Track))
	{
		if (SpawnableTrack->GetDialogueEntity())
		{
			if (UDialogueBaseAsset* OuterDialogueAsset = Cast<UDialogueBaseAsset>(GetOuter()))
			{
				DialogueEntity = OuterDialogueAsset->FindAssetEntity(SpawnableTrack->GetTrackName().ToString());
				if (DialogueEntity == nullptr)
				{
					DialogueEntity = NewObject<UDialogueEntity>(GetOuter(), SpawnableTrack->GetDialogueEntity()->GetClass(), NAME_None);
					DialogueEntity->DuplicateFromEntityInfo(SpawnableTrack->GetDialogueEntity());
					SetDialogueEntity(DialogueEntity);
				}
			}
		}
	}
}

FString UDialogueSpawnableTrack::GetEditorPreviewName()
{
	if(DialogueEntity)
	{
		if (UDialogueActor* DialogueActor = Cast<UDialogueActor>(DialogueEntity))
		{
			if(DialogueActor->IsPlayer())
			{
				return TEXT("玩家");
			}
			if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(GetOwningDialogueAsset()))
			{
				FName RealName;
				if(DialogueAsset->FindAppreanceName(DialogueActor->AppearanceID, RealName))
				{
					return RealName.ToString();
				}
			}
			
			return TEXT("新角色");
		}
	}
	return TEXT("");
}

FString UDialogueSpawnableTrack::GetEditorPreviewFullName()
{
	if (GetEditorPreviewName().IsEmpty())
		return TrackName;
	return  FString::Printf(TEXT("%s(%s)"), *TrackName, *GetEditorPreviewName());
}

#endif
