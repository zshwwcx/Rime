#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"

#include "DialogueEditor/DialogueEditorUtilities.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"

float UDialogueActionBase::KeyFrameDefaultDuration = 0.0333f;

class UDialogueActionTrack* UDialogueActionBase::GetDialogueAction()
{
#if WITH_EDITOR
	if(DialogueAction)
		return DialogueAction;
	//DialogueAction为空，说明是旧的Section，此时需要去Outer的DialogueAsset里面搜寻

	if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
	{
		for (FDialogueEpisode& Episode : DialogueAsset->Episodes)
		{
			TArray<UDialogueTrackBase*> AllTracks = Episode.GetAllTracks();
			for (UDialogueTrackBase* DialogueTrackBase : AllTracks)
			{
				if (UDialogueActionTrack* DialogueActionTemp = Cast<UDialogueActionTrack>(DialogueTrackBase))
				{
					if (DialogueActionTemp->ActionSections.Contains(this))
					{
						DialogueAction = DialogueActionTemp;
						return DialogueAction;
					}
				}
			}
		}
	}
#endif
	return nullptr;
}

UDialogueActionBase::UDialogueActionBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bDefaultObj = HasAnyFlags(RF_ClassDefaultObject);
}

void UDialogueActionBase::SetLineUniqueIDLinked(const FGuid& InGUID)
{
	LineUniqueIDLinked = InGUID;
}

FString UDialogueActionBase::GetLineUniqueIDLinkedStr() const
{
	if (LineUniqueIDLinked.IsValid())
	{
		return LineUniqueIDLinked.ToString();
	}

	return FString();
}

void UDialogueActionBase::CopyFrom_Implementation(UDialogueActionBase* Other)
{
	if (Other == nullptr)
		return;
	StartTime = Other->StartTime;
	Duration = Other->Duration;
	SectionName = Other->SectionName;
}

#if WITH_EDITOR
bool UDialogueActionBase::CanEditChange(const FProperty* InProperty) const
{
	return Super::CanEditChange(InProperty);
}

void UDialogueActionBase::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	const FName PropertyName = (PropertyChangedEvent.Property ? PropertyChangedEvent.Property->GetFName() : NAME_None);

	OnSectionDataChange.ExecuteIfBound(this, PropertyName);
}

void UDialogueActionBase::PostLoad()
{
	UObject::PostLoad();
	if (!IsConstant())
	{
		Duration = KeyFrameDefaultDuration;
	}
	bDefaultObj = HasAnyFlags(RF_ClassDefaultObject);
}

class UDialogueActionBase* UDialogueActionBase::GetPreSection()
{
	UDialogueActionTrack* OwnerDialogueAction = GetDialogueAction();

	if (OwnerDialogueAction == nullptr)
		return nullptr;

	TArray<UDialogueActionBase*> OrderedActions = OwnerDialogueAction->GetOrderedSections();

	for (int i = OrderedActions.Num() - 1; i >= 0; --i)
	{
		UDialogueActionBase* DialogueActionSection = OrderedActions[i];
		if (DialogueActionSection != this)
		{
			if (DialogueActionSection->StartTime < StartTime)
			{
				return DialogueActionSection;
			}
		}
	}
	return nullptr;
}

class UDialogueActionBase* UDialogueActionBase::GetNextSection()
{
	UDialogueActionTrack* OwnerDialogueAction = GetDialogueAction();

	if (OwnerDialogueAction == nullptr)
		return nullptr;

	TArray<UDialogueActionBase*> OrderedActions = OwnerDialogueAction->GetOrderedSections();

	for (int i = 0; i < OrderedActions.Num(); ++i)
	{
		UDialogueActionBase* DialogueActionSection = OrderedActions[i];
		if (DialogueActionSection != this)
		{
			if (DialogueActionSection->StartTime > StartTime)
			{
				return DialogueActionSection;
			}
		}
	}
	return nullptr;
}

TArray<class UDialogueActionBase*> UDialogueActionBase::GetAllNextSections()
{
	TArray<class UDialogueActionBase*> Ret;

	UDialogueActionTrack* OwnerDialogueAction = GetDialogueAction();

	if (OwnerDialogueAction == nullptr)
		return Ret;

	TArray<UDialogueActionBase*> OrderedActions = OwnerDialogueAction->GetOrderedSections();

	for (int i = 0; i < OrderedActions.Num(); ++i)
	{
		UDialogueActionBase* DialogueActionSection = OrderedActions[i];
		if (DialogueActionSection != this)
		{
			if (DialogueActionSection->StartTime > StartTime)
			{
				Ret.Add(DialogueActionSection);
			}
		}
	}
	return Ret;
}

#if WITH_EDITOR
void UDialogueActionBase::OnEditorInitialized()
{
}
#endif

bool UDialogueActionBase::IsOverlapWithOtherSection()
{
	UDialogueActionTrack* OwnerDialogueAction = GetDialogueAction();

	if (OwnerDialogueAction == nullptr)
		return false;


	TArray<UDialogueActionBase*> OrderedActions = OwnerDialogueAction->GetOrderedSections();

	for (int i = 0; i < OrderedActions.Num(); ++i)
	{
		UDialogueActionBase* DialogueActionSection = OrderedActions[i];
		if (DialogueActionSection == this)
		{
			//等于自己，判断和前面、后面Section的区别
			if (i > 0)
			{
				UDialogueActionBase* PreSection = OrderedActions[i-1];
				if ((PreSection->GetEndTime() - StartTime) > 0.01)
					return true;
			}
			if (i < OrderedActions.Num() - 1)
			{
				UDialogueActionBase* NextSection = OrderedActions[i+1];
				if ((GetEndTime() - NextSection->StartTime) > 0.01)
					return true;
			}
			break;
		}
	}




	return false;
}

bool UDialogueActionBase::RemoveSelfFromAction(bool MarkModify)
{
	UDialogueActionTrack* OwnerDialogueAction = GetDialogueAction();

	if (OwnerDialogueAction == nullptr)
		return false;

	if (MarkModify)
		OwnerDialogueAction->Modify();

	OwnerDialogueAction->RemoveSection(this);
	return true;
}

float UDialogueActionBase::GetDelay()
{
	float PreEndTime = 0;
	if (UDialogueActionBase* PreSection = GetPreSection())
		PreEndTime = PreSection->GetEndTime();

	return StartTime - PreEndTime;
}

void UDialogueActionBase::SetEditorStartTime(float TempStart)
{
	EditorStartTime = TempStart;
}

void UDialogueActionBase::SetEditorDuration(float TempDuration)
{
	EditorDuration = TempDuration;
}

float UDialogueActionBase::GetEditorStartTime()
{
	if (FMath::IsNearlyEqual(EditorStartTime, SECTION_START_TIME_DEFAULT))
		return StartTime;
	return EditorStartTime;
}

float UDialogueActionBase::GetEditorDuration()
{
	if (FMath::IsNearlyEqual(EditorDuration, SECTION_DURATION_DEFAULT))
		return Duration;
	return EditorDuration;
}

bool UDialogueActionBase::IsAdjustingEdge()
{
	if (!FMath::IsNearlyEqual(EditorStartTime, SECTION_START_TIME_DEFAULT))
		return true;
	if (!FMath::IsNearlyEqual(EditorDuration, SECTION_DURATION_DEFAULT))
		return true;
	return false;
}

UDialogueAsset* UDialogueActionBase::GetDialogueAsset() const
{
	return FDialogueEditorUtilities::GetDialogueAsset(this);
}

#endif
