#include "DialogueEditor/Dialogue/DialogueCameraTrack.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"

#if WITH_EDITOR
FString UDialogueCameraTrack::GetEditorPreviewName()
{
	UDialogueTrackBase* ParentTrack = Parent;
	while (ParentTrack)
	{
		UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(ParentTrack);
		if (SpawnableTrack)
		{
			return SpawnableTrack->GetEditorPreviewName();
		}
		ParentTrack = ParentTrack->Parent;
	}

	return TEXT("");
}
#endif