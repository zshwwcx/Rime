
#include "DialogueEditor/Dialogue/DialogueEntitySpline.h"

void UDialogueEntitySpline::DuplicateFromEntityInfo_Implementation(UDialogueEntity* InEntity)
{
	Super::DuplicateFromEntityInfo(InEntity);
	SplineCurves = Cast<UDialogueEntitySpline>(InEntity)->SplineCurves;
}


