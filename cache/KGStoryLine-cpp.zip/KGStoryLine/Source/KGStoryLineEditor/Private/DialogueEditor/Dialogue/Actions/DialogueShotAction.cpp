#include "DialogueEditor/Dialogue/Actions/DialogueShotAction.h"

#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"

namespace
{
	FString DialogueShotPropertySwitchType = "SwitchType";
	FString DialogueShotPropertyBreathDuration = "BreathDuration";
	FString DialogueShotPropertyBreathType = "CameraBreathType";
}

void UDialogueShotAction::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	const FName PropertyName = (PropertyChangedEvent.Property != nullptr) ? PropertyChangedEvent.Property->GetFName() : NAME_None;
	if (PropertyName == DialogueShotPropertySwitchType)
	{
		OnDialogueShotSwitchTypeChangedEvent.ExecuteIfBound();
	}
	else if (PropertyName == DialogueShotPropertyBreathType)
	{
		if (!IsBreathShot())
		{
			Duration = KeyFrameDefaultDuration;
		}
		else
		{
			UpdateBreathTimeToDuration();
		}
	}
	else if (PropertyName == DialogueShotPropertyBreathDuration)
	{
		UpdateBreathTimeToDuration();
	}
}

void UDialogueShotAction::PostLoad()
{
	UObject::PostLoad();
}

bool UDialogueShotAction::IsSmooth()
{
	if (const FProperty* Property = GetClass()->FindPropertyByName(*DialogueShotPropertySwitchType))
	{
		if (const void* ValuePtr = Property->ContainerPtrToValuePtr<void>(this))
		{
			FString PropertyValue;
			Property->ExportTextItem_Direct(PropertyValue, ValuePtr, nullptr, nullptr, PPF_None);
			FString ValueStr = StaticEnum<EDialogueCameraSwitchType>()->GetNameStringByValue(static_cast<int>(EDialogueCameraSwitchType::Instant));
			if (PropertyValue != ValueStr)
			{
				return true;
			}
		}
	}
	return false;
}

bool UDialogueShotAction::IsBreathShot() const
{
	if (const FProperty* Property = GetClass()->FindPropertyByName(*DialogueShotPropertyBreathType))
	{
		if (const void* ValuePtr = Property->ContainerPtrToValuePtr<void>(this))
		{
			FString PropertyValue;
			Property->ExportTextItem_Direct(PropertyValue, ValuePtr, nullptr, nullptr, PPF_None);
			FString ValueStr = StaticEnum<EDialogueShotBreathType>()->GetNameStringByValue(static_cast<int>(EDialogueShotBreathType::None));
			if (PropertyValue != ValueStr)
			{
				return true;
			}
		}
	}
	return false;
}

void UDialogueShotAction::UpdateBreathTimeToDuration()
{
	FProperty* Property = GetClass()->FindPropertyByName(*DialogueShotPropertyBreathDuration);
	if (const void* ValuePtr = Property->ContainerPtrToValuePtr<void>(this))
	{
		FString PropertyValue;
		Property->ExportTextItem_Direct(PropertyValue, ValuePtr, nullptr, nullptr, PPF_None);
		Duration = FCString::Atof(*PropertyValue);
	}
}

void UDialogueShotAction::UpdateDurationToBreathTime()
{
	FProperty* Property = GetClass()->FindPropertyByName(*DialogueShotPropertyBreathDuration);
	if (void* ValuePtr = Property->ContainerPtrToValuePtr<void>(this))
	{
		Property->ImportText_Direct(*FString::SanitizeFloat(Duration), ValuePtr, this, PPF_None);
	}
}

UDialogueShotTrack::UDialogueShotTrack() :UDialogueActionTrack()
{
	TrackName = "Shot";
}

EDialogueTrack::Type UDialogueShotTrack::GetType() const
{
	return EDialogueTrack::Type::Shot;
}

UClass* UDialogueShotTrack::GetSecondSectionType()
{
	FString BPSAutoShotClassPath = TEXT("/Game/Blueprint/DialogueSystem/Section/BPS_DialogueAutoShot.BPS_DialogueAutoShot_C");
	UClass* BPSAutoShotClass = StaticLoadClass(UObject::StaticClass(), nullptr, *BPSAutoShotClassPath);
	return BPSAutoShotClass;
}

FString UDialogueShotTrack::GetEditorPreviewName()
{
	UDialogueTrackBase* ParentTrack = Parent;
	while(ParentTrack)
	{
		if(UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(ParentTrack))
		{
			return SpawnableTrack->GetEditorPreviewName();
		}
		ParentTrack = ParentTrack->Parent;
	}
	
	return TEXT("");
}