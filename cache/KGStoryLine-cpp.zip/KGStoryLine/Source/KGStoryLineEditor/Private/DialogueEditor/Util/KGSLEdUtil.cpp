#include "DialogueEditor/Util/KGSLEdUtil.h"

void KGStoryLineEditor::CopyProperty(UKGSLDialogueLine* DstObj, UKGSLDialogueLine* SrcObj)
{
	for(TFieldIterator<FProperty> It(UKGSLDialogueLine::StaticClass()); It; ++It)
	{
		FProperty* Property = *It;
		if(FProperty* DstProperty = FindFProperty<FProperty>(DstObj->StaticClass(), Property->GetFName()))
		{
			const void* SrcPtr = Property->ContainerPtrToValuePtr<void>(SrcObj);
			DstProperty->SetValue_InContainer(DstObj, SrcPtr);
		}
	}
}

void KGStoryLineEditor::CopyProperty(UKGSLDialogueOption* DstObj, const FDialogueOption& Option)
{
	for(TFieldIterator<FProperty> It(Option.StaticStruct()); It; ++It)
	{
		FProperty* Property = *It;
		if(FProperty* DstProperty = FindFProperty<FProperty>(DstObj->StaticClass(), Property->GetFName()))
		{
			ensureMsgf(DstProperty->GetCPPType() == Property->GetCPPType(),
				TEXT("The property: %s with type %s in FDialogueOption,but the property in UKGSLDialogueOption is %s with type %s"),
				*Property->GetName(), *Property->GetCPPType(), *DstProperty->GetName(), *DstProperty->GetCPPType());
			
			const void* SrcPtr = Property->ContainerPtrToValuePtr<void>(&Option);
			DstProperty->SetValue_InContainer(DstObj, SrcPtr);
		}
	}
}

FText KGStoryLineEditor::GetUObjectPropertyValueAsTextDirect(const FProperty* Property, UObject* Object, int32 Index)
{
	if (!Property || !IsValid(Object))
	{
		return FText::GetEmpty();
	}

	const uint8* ValuePtr = Property->ContainerPtrToValuePtr<uint8>(Object, Index);
	return DataTableUtils::GetPropertyValueAsTextDirect(Property, ValuePtr);
}

FText KGStoryLineEditor::GetUObjectPropertyValueAsText(const FProperty* Property, UObject* Object)
{
	FText Result;

	if (Property && DataTableUtils::IsSupportedTableProperty(Property))
	{
		FString ExportedString;
		if (Property->ArrayDim == 1)
		{
			FText Text = GetUObjectPropertyValueAsTextDirect(Property, Object, 0);
			ExportedString = Text.ToString();
		}
		else
		{
			ExportedString.AppendChar('(');

			for (int32 Index = 0; Index < Property->ArrayDim; ++Index)
			{
				FText Text = GetUObjectPropertyValueAsTextDirect(Property, Object, Index);
				ExportedString.Append(Text.ToString());

				if ((Index + 1) < Property->ArrayDim)
				{
					ExportedString.AppendChar(',');
					ExportedString.AppendChar(' ');
				}
			}

			ExportedString.AppendChar(')');
		}

		Result = FText::FromString(MoveTemp(ExportedString));
	}


	return Result;
}
