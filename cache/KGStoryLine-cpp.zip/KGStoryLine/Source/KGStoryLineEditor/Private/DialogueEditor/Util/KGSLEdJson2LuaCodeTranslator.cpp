// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/Util/KGSLEdJson2LuaCodeTranslator.h"
#include "Dom/JsonObject.h"
#include "Dom/JsonValue.h"

const FString FKGSLEdJson2LuaCodeTranslator::IndentIdentifier(TEXT("  "));

static FString ComposeKey(const FString& Key)
{
    return TEXT("[\"") + Key + TEXT("\"]");
}

static FString ComposeKey(int32 Key)
{
    return TEXT("[") + FString::FromInt(Key) + TEXT("]");
}

FKGSLEdJson2LuaCodeTranslator::FKGSLEdJson2LuaCodeTranslator(TSharedPtr<class FJsonObject> InJsonObject)
    : JsonObject(InJsonObject)
{
}

FKGSLEdJson2LuaCodeTranslator::~FKGSLEdJson2LuaCodeTranslator()
{
}

FString FKGSLEdJson2LuaCodeTranslator::Translate(bool bSortKey)
{
    if (!JsonObject.IsValid())
    {
        return TEXT("");
    }

    FStringBuilderBase StringBuilder;
    StringBuilder.Append(TEXT("{\n"));

     FString Indent = IndentIdentifier;

    TArray<FString> Keys;
    JsonObject->Values.GetKeys(Keys);
    if (bSortKey)
    {
        Keys.Sort([](const FString& A, const FString& B)
        {
            return FPlatformString::Strcmp(*A, *B) < 0; 
        });
    }
    
    for(const FString& Key : Keys)
    {
        TranslateJsonValue(JsonObject->TryGetField(Key), ComposeKey(Key), bSortKey, Indent, 
        StringBuilder);
    }

    StringBuilder.Append(TEXT("}"));
    return FString(StringBuilder.Len(), StringBuilder.GetData());
}

void FKGSLEdJson2LuaCodeTranslator::TranslateJsonValue(TSharedPtr<class FJsonValue> InJsonValue, const FString& Key,
    bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder)
{
    if(!InJsonValue.IsValid())
    {
        return;
    }

    if(TranslatorPtr Translator = GetTranslator(InJsonValue))
    {
        (this->*Translator)(InJsonValue, Key, bSortKey, InIndent, OutStringBuilder);
    }
}

void FKGSLEdJson2LuaCodeTranslator::TranslateJsonObject(TSharedPtr<FJsonValue> InJsonValue,
                                                        const FString& Key, bool bSortKey, const FString& InIndent,
                                                        FStringBuilderBase& OutStringBuilder)
{
    if(!InJsonValue.IsValid())
    {
        return;
    }
    
    TSharedPtr<FJsonObject> JsonValueObj = InJsonValue->AsObject();
    if(!JsonValueObj.IsValid())
    {
        return;
    }
    
    OutStringBuilder.Appendf(TEXT("%s%s = {\n"), *InIndent, *Key);

    const FString Indent = InIndent + IndentIdentifier;
    TArray<FString> Keys;
    JsonValueObj->Values.GetKeys(Keys);
    if (bSortKey)
    {
        Keys.Sort([](const FString& A, const FString& B)
        {
            return FPlatformString::Strcmp(*A, *B) < 0;
        });
    }

    for(const FString& k : Keys)
    {
        TranslateJsonValue(JsonValueObj->TryGetField(k), ComposeKey(k), bSortKey, Indent, OutStringBuilder);
    }

    OutStringBuilder.Appendf(TEXT("%s},\n"), *InIndent);
}

void FKGSLEdJson2LuaCodeTranslator::TranslateJsonArray(TSharedPtr<FJsonValue> InJsonValue,
                                                       const FString& Key, bool bSortKey, const FString& InIndent,
                                                       FStringBuilderBase& OutStringBuilder)
{
    if(!InJsonValue.IsValid())
    {
        return ;
    }

    OutStringBuilder.Appendf(TEXT("%s%s = {\n"), *InIndent, *Key);

    const FString Indent = InIndent + IndentIdentifier;
    
    const TArray< TSharedPtr<FJsonValue> >& JsonArry = InJsonValue->AsArray();
    for(int32 i = 0; i < JsonArry.Num(); ++i)
    {
        FString ArrayIndex = ComposeKey(i + 1);
        TranslateJsonValue(JsonArry[i], ArrayIndex, bSortKey, Indent, OutStringBuilder);
    }

    OutStringBuilder.Appendf(TEXT("%s},\n"), *InIndent);
}

void FKGSLEdJson2LuaCodeTranslator::TranslateJsonString(TSharedPtr<FJsonValue> InJsonValue,
                                                        const FString& Key, bool bSortKey, const FString& InIndent,
                                                        FStringBuilderBase& OutStringBuilder)
{
	FString strValue = InJsonValue->AsString();
	if (strValue.Contains(TEXT("\r\n")))
	{
		strValue.ReplaceInline(TEXT("\r\n"), TEXT("\\n"));
	}
	else if (strValue.Contains(TEXT("\n")))
	{
		strValue.ReplaceInline(TEXT("\n"), TEXT("\\n"));
	}
	if (strValue.Contains(TEXT("\"")))
	{
		strValue.ReplaceInline(TEXT("\""), TEXT("\\\""));
	}

	OutStringBuilder.Appendf(TEXT("%s%s = \"%s\",\n"), *InIndent, *Key, *strValue);
}

void FKGSLEdJson2LuaCodeTranslator::TranslateJsonNumber(TSharedPtr<FJsonValue> InJsonValue,
                                                        const FString& Key, bool bSortKey, const FString& InIndent,
                                                        FStringBuilderBase& OutStringBuilder)
{
    OutStringBuilder.Appendf(TEXT("%s%s = %s,\n"), *InIndent, *Key, *InJsonValue->AsString());
}

void FKGSLEdJson2LuaCodeTranslator::TranslateJsonNumberStr(TSharedPtr<FJsonValue> InJsonValue,
                                                           const FString& Key, bool bSortKey, const FString& InIndent,
                                                           FStringBuilderBase& OutStringBuilder)
{
    OutStringBuilder.Appendf(TEXT("%s%s = %s,\n"), *InIndent, *Key, *InJsonValue->AsString());
}

void FKGSLEdJson2LuaCodeTranslator::TranslateJsonBoolean(TSharedPtr<FJsonValue> InJsonValue,
                                                         const FString& Key, bool bSortKey, const FString& InIndent,
                                                         FStringBuilderBase& OutStringBuilder)
{
    OutStringBuilder.Appendf(TEXT("%s%s = %s,\n"), *InIndent, *Key, *InJsonValue->AsString());
}

void FKGSLEdJson2LuaCodeTranslator::TranslateJsonNull(TSharedPtr<FJsonValue> InJsonObj, const FString& Key,
    bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder)
{
}

FKGSLEdJson2LuaCodeTranslator::TranslatorPtr FKGSLEdJson2LuaCodeTranslator::GetTranslator(
    TSharedPtr<FJsonValue> InJsonValue) const
{
    static const TMap<EJson, TranslatorPtr> Translators = {
        {EJson::Object, &FKGSLEdJson2LuaCodeTranslator::TranslateJsonObject},
        {EJson::Array, &FKGSLEdJson2LuaCodeTranslator::TranslateJsonArray},
        {EJson::String, &FKGSLEdJson2LuaCodeTranslator::TranslateJsonString},
        {EJson::Number, &FKGSLEdJson2LuaCodeTranslator::TranslateJsonNumber},
        {EJson::Boolean, &FKGSLEdJson2LuaCodeTranslator::TranslateJsonBoolean},
        {EJson::Null, &FKGSLEdJson2LuaCodeTranslator::TranslateJsonNull}
    };

    if( Translators.Contains(InJsonValue->Type))
    {
        return Translators[InJsonValue->Type];
    }

    return nullptr;
}
