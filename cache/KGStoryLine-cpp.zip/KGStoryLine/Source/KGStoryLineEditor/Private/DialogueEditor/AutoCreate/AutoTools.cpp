#include "DialogueEditor/AutoCreate/AutoTools.h"

#include "DialogueEditor/DialogueEditorManager.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "ScopedTransaction.h"
#include "DialogueEditor/Dialogue/Actions/DialogueAutoCameraCut.h"
#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Misc/MessageDialog.h"

FString FDialogueAutoTools::OldLookAtTrackPath = TEXT("/Game/Blueprint/DialogueSystem/Track/BP_DialogueTrackLookAt.BP_DialogueTrackLookAt_C");
FString FDialogueAutoTools::LookAtTrackPath = TEXT("/Game/Blueprint/DialogueSystem/Track/BP_DialogueTrackActorLookAt.BP_DialogueTrackActorLookAt_C");
FString FDialogueAutoTools::CameraShotTrackPath = TEXT("/Game/Blueprint/DialogueSystem/Track/BP_DialogueCameraCut.BP_DialogueCameraCut_C");

FString FDialogueAutoTools::GenerateAvailableTrackName(class UDialogueBaseAsset* Asset, const FString& Prefix)
{
	if (Asset == nullptr) return TEXT("");
	TArray<UDialogueTrackBase*> AllTracks = Asset->GetAllEpisodeTracks(0);

	int AvailableIndex = 0;
	FString Ret;
	while (true)
	{
		//探测一个可用的TrackIndex
		AvailableIndex++;

		bool Continue = false;
		Ret = FString::Printf(TEXT("%s%d"), *Prefix, AvailableIndex);
		for (UDialogueTrackBase* TrackBase : AllTracks)
		{
			if (TrackBase->GetTrackName().ToString() == Ret)
			{
				Continue = true;
				break;
			}
		}
		if (!Continue) break;
	}
	return Ret;
}

UDialogueCamera* FDialogueAutoTools::AddNewCameraTrack(UDialogueAsset* Asset, FString TrackName)
{
	UDialogueCameraTrack* NewTrack = NewObject<UDialogueCameraTrack>(Asset, UDialogueCameraTrack::StaticClass(), NAME_None, RF_Transactional);
	NewTrack->FromTemplate = false;
	NewTrack->bAutoCameraTrack = true;
	UDialogueEditorSettings* DESettings = GetMutableDefault<UDialogueEditorSettings>();
	TSubclassOf<UDialogueEntity>* TrackEntityClass = DESettings->TrackEntityClass.Find(NewTrack->GetClass());
	FString AvailableTrackName;
	if (TrackName != "")
	{
		AvailableTrackName = TrackName;
	}
	else
	{
		AvailableTrackName = GenerateAvailableTrackName(Asset, NewTrack->NamePrefix);
	}
	NewTrack->SetTrackName(FText::FromString(AvailableTrackName));

	UDialogueCamera* DialogueEntity = NewObject<UDialogueCamera>(Asset, *TrackEntityClass, NAME_None, RF_Transactional);

	//绑定Track和Entity的对应关系
	NewTrack->SetDialogueEntity(DialogueEntity);
	//创建Entity后，加入到Asset的列表中
	Asset->AddDialogueEntity(DialogueEntity);

	FString AnchorTrackName;
	if (Asset->Episodes.Num() > 0)
	{
		//我们计算是否已经有一个锚点了，如果有，则要将USpawnable的Track加入到锚点下面
		for (int i = Asset->Episodes[0].TrackList.Num() - 1; i >= 0; --i)
		{
			UDialogueTrackBase* Track = Asset->Episodes[0].TrackList[i];
			if (Cast<UDialogueSpawnableTrack>(Track))
			{
				//已经有一个锚点了，说明有多个锚点同级别，需要将新建的Track挂到它下面
				AnchorTrackName = Track->GetTrackName().ToString();
				break;
			}
		}
	}

	TArray<UDialogueTrackBase*> AllTracks = Asset->Episodes[0].GetAllTracks();

	UDialogueTrackBase* DestTrack = nullptr;
	if (UDialogueTrackBase** DestTrackPtr = AllTracks.FindByPredicate([AnchorTrackName](UDialogueTrackBase* Track) { return Track->GetTrackName().ToString() == AnchorTrackName; })) DestTrack = *DestTrackPtr;

	//这些需要复制到其他Episode的，默认加入第0个Episode里面
	//然后其他Episode也分别添加
	DestTrack->Modify();
	DestTrack->AddChild(NewTrack);
	NewTrack->Parent = DestTrack;

	UDialogueSpawnableTrack* DestSpawnableTrack = Cast<UDialogueSpawnableTrack>(DestTrack);

	NewTrack->GetDialogueEntity()->SetParent(DestSpawnableTrack->GetDialogueEntity());
	NewTrack->GetDialogueEntity()->UpdateSpawnTransform();

	for (int i = 1; i < Asset->Episodes.Num(); ++i)
	{
		UDialogueCameraTrack* NewEpisodeTrack = NewObject<UDialogueCameraTrack>(Asset, NewTrack->GetClass(), NAME_None, RF_Transactional);
		NewEpisodeTrack->DuplicateFromTrack(NewTrack);
		NewEpisodeTrack->bAutoCameraTrack = true;
		AllTracks = Asset->Episodes[i].GetAllTracks();
		if (UDialogueTrackBase** DestTrackPtr = AllTracks.FindByPredicate([AnchorTrackName](UDialogueTrackBase* Track) { return Track->GetTrackName().ToString() == AnchorTrackName; })) DestTrack = *DestTrackPtr;

		DestTrack->Modify();
		DestTrack->AddChild(NewEpisodeTrack);
		NewEpisodeTrack->Parent = DestTrack;

		DestSpawnableTrack = Cast<UDialogueSpawnableTrack>(DestTrack);

		NewEpisodeTrack->GetDialogueEntity()->SetParent(DestSpawnableTrack->GetDialogueEntity());
		NewEpisodeTrack->GetDialogueEntity()->UpdateSpawnTransform();
	}
	return DialogueEntity;
}

TArray<UDialogueEntity*> FDialogueAutoTools::RemoveAllAutoTracks(UDialogueAsset* Asset)
{
	TArray<UDialogueEntity*> DialogueEntities;
	for (int i = 0; i < Asset->Episodes.Num(); ++i)
	{
		FDialogueEpisode& Episode = Asset->Episodes[i];
		TArray<UDialogueCameraTrack*> AllAutoCameraTracks;
		// 假设根节点中只有一个是spawnable track
		for (UDialogueTrackBase* Track : Episode.TrackList)
		{
			if (Cast<UDialogueSpawnableTrack>(Track))
			{
				TArray<UDialogueTrackBase*> Children = Track->Childs;
				for (UDialogueTrackBase* ChildTrack : Children)
				{
					if (UDialogueCameraTrack* CameraTrack = Cast<UDialogueCameraTrack>(ChildTrack))
					{
						if (CameraTrack->bAutoCameraTrack)
						{
							if (i == 0)
							{
								DialogueEntities.Add(CameraTrack->GetDialogueEntity());
							}
							Track->Childs.Remove(CameraTrack);
						}
					}
				}
				break;
			}
		}
	}
	return DialogueEntities;
}

UDialogueActionTrack* FDialogueAutoTools::FindLookAtTrack(UDialogueAsset* DialogueAsset, UDialogueActorTrack* ActorTrack)
{
	UClass* BPLookAtTrackClass = StaticLoadClass(UObject::StaticClass(), nullptr, *LookAtTrackPath);
	for (auto ActionTrack: ActorTrack->Actions)
	{
		if (ActionTrack->IsA(BPLookAtTrackClass))
		{
			return ActionTrack;
		}
	}
	return nullptr;
}

UDialogueActionTrack* FDialogueAutoTools::FindOrAddLookAtTrack(UDialogueAsset* DialogueAsset, UDialogueActorTrack* ActorTrack)
{
	UClass* BPLookAtTrackClass = StaticLoadClass(UObject::StaticClass(), nullptr, *LookAtTrackPath);
	for (auto ActionTrack: ActorTrack->Actions)
	{
		if (ActionTrack->IsA(BPLookAtTrackClass))
		{
			return ActionTrack;
		}
	}
	UDialogueActionTrack* NewTrack = NewObject<UDialogueActionTrack>(ActorTrack, BPLookAtTrackClass, NAME_None, RF_Transactional);
	ActorTrack->AddAction(NewTrack);
	return NewTrack;
}

UDialogueActionTrack* FDialogueAutoTools::RecreateCameraShotTrack(UDialogueAsset* DialogueAsset, FDialogueEpisode& Episode)
{
	UClass* BPCameraShotTrackClass = StaticLoadClass(UObject::StaticClass(), nullptr, *CameraShotTrackPath);
	Episode.TrackList.RemoveAll([](const UDialogueTrackBase* Track)
	{
		return Track->IsA(UDialogueCameraCutTrack::StaticClass()) || Track->IsA(UDialogueAutoCameraCutTrack::StaticClass());
	});
	UDialogueActionTrack* NewTrack = NewObject<UDialogueActionTrack>(DialogueAsset, BPCameraShotTrackClass, NAME_None, RF_Transactional);
	Episode.TrackList.Add(NewTrack);
	return NewTrack;
}

bool FDialogueAutoTools::IsLookAtEmpty(UDialogueAsset* DialogueAsset)
{
	UClass* OldBPLookAtTrackClass = StaticLoadClass(UObject::StaticClass(), nullptr, *OldLookAtTrackPath);
	for (FDialogueEpisode& Episode : DialogueAsset->Episodes)
	{
		TArray<UDialogueActorTrack*> ActorTracks;
		for (UDialogueTrackBase* Track : Episode.GetAllTracks())
		{
			if (Track->IsA(OldBPLookAtTrackClass))
			{
				UDialogueActionTrack* ActionTrack = Cast<UDialogueActionTrack>(Track);
				if (!ActionTrack->ActionSections.IsEmpty())
				{
					return false;
				}
			}
			if (UDialogueActorTrack* ActorTrack = Cast<UDialogueActorTrack>(Track))
			{
				if (UDialogueActionTrack* LookAtTrack = FindLookAtTrack(DialogueAsset, ActorTrack))
				{
					if (!LookAtTrack->ActionSections.IsEmpty())
					{
						return false;
					}
				}
			}
		}
	}
	return true;
}

void FDialogueAutoTools::CreateMultiAutoCameras(UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager)
{
	TArray<UDialogueEntity*> DialogueEntities = RemoveAllAutoTracks(DialogueAsset);
	for (UDialogueEntity* DialogueEntity : DialogueEntities)
	{
		DialogueAsset->RemoveDialogueEntity(DialogueEntity);
		if (DialogueEditor)
		{
			DialogueEditor->RemoveDialogueActor(DialogueEntity);
		}
	}
	
	UDialogueEditorManager* DialogueEditorManager;
	if (InDialogueEditorManager)
	{
		DialogueEditorManager = InDialogueEditorManager;
	}
	else
	{
		DialogueEditorManager = DialogueEditor->GetDialogueEditorManager();
	}

	// 先根据台本创建出对应的分镜，计算出分镜的机位信息
	TSet<FString> CameraNameSet;
	for (FDialogueEpisode& Episode : DialogueAsset->Episodes)
	{
		int CurrentEpisodeID = Episode.EpisodeID;
		if (UDialogueActionTrack* CameraCutTrack = RecreateCameraShotTrack(DialogueAsset, Episode))
		{
			UDialogueTrackBase* DialogueTrack = DialogueAsset->FindEpisodeTrackByTrackClass(CurrentEpisodeID, UDialogueDialogueTrack::StaticClass());
			if (DialogueTrack == nullptr)
			{
				UE_LOG(LogTemp, Warning, TEXT("Can not find Dialogue Action In Current Episode"));
				return;
			}
			UDialogueActionTrack* DialogueAction = Cast<UDialogueActionTrack>(DialogueTrack);
			if (DialogueAction == nullptr)
			{
				UE_LOG(LogTemp, Warning, TEXT("Can not find Dialogue Action In Current Episode"));
				return;
			}

			if (DialogueAction->ActionSections.Num() == 0)
			{
				UE_LOG(LogTemp, Warning, TEXT("Dialogue Action Sections:Num() == 0"));
				return;
			}

			FString ScopeText = FString::Printf(TEXT("Dialogue AddAllSectionsForLine, Track %s"), *(CameraCutTrack->GetTrackName().ToString()));
			CameraCutTrack->SetFlags(EObjectFlags::RF_Transactional);
			FScopedTransaction Transaction(FText::FromString(ScopeText));

			CameraCutTrack->ActionSections.Empty();
			TArray<UDialogueActionBase*> CameraCuts;
			TArray<UDialogueActionBase*> Dialogues;
			for (UDialogueActionBase* DialogueSection : DialogueAction->ActionSections)
			{
				if (DialogueSection)
				{
					CameraCutTrack->Modify();
					if (UDialogueActionBase* NewActionSection = DialogueAsset->AddSection(CurrentEpisodeID, CameraCutTrack))
					{
						NewActionSection->StartTime = DialogueSection->StartTime;
						NewActionSection->LineUniqueIDLinked = DialogueSection->LineUniqueIDLinked;
						CameraCuts.Add(NewActionSection);
						Dialogues.Add(DialogueSection);
					}
				}
			}
			TArray<FString> CameraNames;
			DialogueEditorManager->GetAndSetAllAutoCameraCutTargetCameraNames(CameraCuts, Dialogues, CameraNames);
			CameraNameSet.Append(CameraNames);
		}
	}

	// 根据自动计算出来的分镜，创建对应依赖的机位
	TArray<UDialogueCamera*> CameraEntities;
	TArray<FString> CameraNames;
	for (const FString& CameraName : CameraNameSet)
	{
		UDialogueCamera* CameraEntity = AddNewCameraTrack(DialogueAsset, CameraName);
		CameraEntities.Add(CameraEntity);
		CameraNames.Add(CameraName);
	}

	// 先保存lua数据
	DialogueEditorManager->OnAssetPostEdit(DialogueAsset);

	// 把机位对应的场景中的actor给刷出来
	if (DialogueEditor)
	{
		for (UDialogueCamera* CameraActorEntity : CameraEntities)
		{
			DialogueEditor->AddDialogueActor(CameraActorEntity);
		}
	}

	auto GetPerformerByName = [DialogueAsset](const FString& Name) -> UDialogueActor*
	{
		for (UDialogueActor* Performer : DialogueAsset->PerformerList)
		{
			if (Performer->TrackName == Name)
			{
				return Performer;
			}
		}
		return nullptr;
	};
	
	// 为每一个机位自动设置对应的位置和旋转信息
	TArray<FString> DialogueCameraNames = {TEXT("正面"), TEXT("近景"), TEXT("中景")};
	for (int32 Index = 0; Index < CameraEntities.Num(); Index++)
	{
		FString CameraName = CameraNames[Index];
		UDialogueCamera* CameraEntity = CameraEntities[Index];
		TArray<FString> Infos;
		CameraName.ParseIntoArray(Infos, TEXT("-"), true);
		if (Infos.Num() == 3)
		{
			FString SourceName = Infos[0];
			FString TargetName = Infos[1];
			int32 CutIndex = DialogueCameraNames.Find(Infos[2]);
			UDialogueActor* SourceActor = GetPerformerByName(SourceName);
			UDialogueActor* TargetActor = GetPerformerByName(TargetName);
			// 只有当TargetActor是玩家的时候，需要让TargetActor在画面左侧，其他情况都是SourceActor在画面左侧
			bool bIsPlayer = !(TargetActor && TargetActor->IsPlayer());
			if (CutIndex == 1)
			{
				DialogueEditorManager->SetActorNearCameraParams(SourceActor, TargetActor, CameraEntity, bIsPlayer);
			}
			else if (CutIndex == 2)
			{
				DialogueEditorManager->SetActorMediumCameraParams(SourceActor, TargetActor, CameraEntity, bIsPlayer);
			}
		}
		else if (Infos.Num() == 2)
		{
			FString SourceName = Infos[0];
			int32 CutIndex = DialogueCameraNames.Find(Infos[1]);
			UDialogueActor* SourceActor = GetPerformerByName(SourceName);
			bool bIsPlayer = SourceActor && SourceActor->IsPlayer();
			DialogueEditorManager->SetOneActorCameraParams(SourceActor, CameraEntity, bIsPlayer, CutIndex);
		}
	}
	
	if (DialogueEditor)
	{
		DialogueEditor->DialogueTimelineController.Pin()->RefreshTracks();
	}
}

void FDialogueAutoTools::CreateAutoCameras(UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager)
{
	TArray<UDialogueEntity*> DialogueEntities = RemoveAllAutoTracks(DialogueAsset);
	for (UDialogueEntity* DialogueEntity : DialogueEntities)
	{
		DialogueAsset->RemoveDialogueEntity(DialogueEntity);
		if (DialogueEditor)
		{
			DialogueEditor->RemoveDialogueActor(DialogueEntity);
		}
	}

	UDialogueActor* Performer1 = DialogueAsset->PerformerList[0];
	UDialogueActor* Performer2 = DialogueAsset->PerformerList[1];
	UDialogueActor* Player = nullptr;
	UDialogueActor* OtherPerformer = nullptr;
	if (Performer1->IsPlayer())
	{
		Player = Performer1;
		OtherPerformer = Performer2;
	}
	else
	{
		Player = Performer2;
		OtherPerformer = Performer1;
	}
	UDialogueEditorManager* DialogueEditorManager;
	if (InDialogueEditorManager)
	{
		DialogueEditorManager = InDialogueEditorManager;
	}
	else
	{
		DialogueEditorManager = DialogueEditor->GetDialogueEditorManager();
	}
	TArray<UDialogueCamera*> CameraEntities;
	CameraEntities.Add(AddNewCameraTrack(DialogueAsset, FString::Printf(TEXT("%s-正面"), *Player->TrackName)));
	CameraEntities.Add(AddNewCameraTrack(DialogueAsset, FString::Printf(TEXT("%s-近景"), *Player->TrackName)));
	CameraEntities.Add(AddNewCameraTrack(DialogueAsset, FString::Printf(TEXT("%s-中景"), *Player->TrackName)));
	CameraEntities.Add(AddNewCameraTrack(DialogueAsset, FString::Printf(TEXT("%s-正面"), *OtherPerformer->TrackName)));
	CameraEntities.Add(AddNewCameraTrack(DialogueAsset, FString::Printf(TEXT("%s-近景"), *OtherPerformer->TrackName)));
	CameraEntities.Add(AddNewCameraTrack(DialogueAsset, FString::Printf(TEXT("%s-中景"), *OtherPerformer->TrackName)));

	// 先保存lua数据
	DialogueEditorManager->OnAssetPostEdit(DialogueAsset);

	// 创建actor依赖最新的lua数据
	if (DialogueEditor)
	{
		for (UDialogueCamera* CameraActorEntity : CameraEntities)
		{
			DialogueEditor->AddDialogueActor(CameraActorEntity);
		}
	}

	// 设置镜头参数
	DialogueEditorManager->SetOneActorCameraParams(Player, CameraEntities[0], true, 0);
	DialogueEditorManager->SetActorNearCameraParams(Player, OtherPerformer, CameraEntities[1], true);
	DialogueEditorManager->SetActorMediumCameraParams(Player, OtherPerformer, CameraEntities[2], true);
	DialogueEditorManager->SetOneActorCameraParams(OtherPerformer, CameraEntities[3], false, 0);
	DialogueEditorManager->SetActorNearCameraParams(OtherPerformer, Player, CameraEntities[4], false);
	DialogueEditorManager->SetActorMediumCameraParams(OtherPerformer, Player, CameraEntities[5], false);

	// 直接创建对应的分镜
	for (FDialogueEpisode& Episode : DialogueAsset->Episodes)
	{
		const int CurrentEpisodeID = Episode.EpisodeID;
		if (UDialogueActionTrack* CameraCutTrack = RecreateCameraShotTrack(DialogueAsset, Episode))
		{
			UDialogueTrackBase* DialogueTrack = DialogueAsset->FindEpisodeTrackByTrackClass(CurrentEpisodeID, UDialogueDialogueTrack::StaticClass());
			if (DialogueTrack == nullptr)
			{
				UE_LOG(LogTemp, Warning, TEXT("Can not find Dialogue Action In Current Episode"));
				return;
			}
			UDialogueActionTrack* DialogueAction = Cast<UDialogueActionTrack>(DialogueTrack);
			if (DialogueAction == nullptr)
			{
				UE_LOG(LogTemp, Warning, TEXT("Can not find Dialogue Action In Current Episode"));
				return;
			}

			if (DialogueAction->ActionSections.Num() == 0)
			{
				UE_LOG(LogTemp, Warning, TEXT("Dialogue Action Sections:Num() == 0"));
				return;
			}

			FString ScopeText = FString::Printf(TEXT("Dialogue AddAllSectionsForLine, Track %s"), *(CameraCutTrack->GetTrackName().ToString()));
			CameraCutTrack->SetFlags(EObjectFlags::RF_Transactional);
			FScopedTransaction Transaction(FText::FromString(ScopeText));

			CameraCutTrack->ActionSections.Empty();
			TArray<UDialogueActionBase*> CameraCuts;
			TArray<UDialogueActionBase*> Dialogues;
			for (UDialogueActionBase* DialogueSection : DialogueAction->ActionSections)
			{
				if (DialogueSection)
				{
					CameraCutTrack->Modify();
					if (UDialogueActionBase* NewActionSection = DialogueAsset->AddSection(CurrentEpisodeID, CameraCutTrack))
					{
						NewActionSection->StartTime = DialogueSection->StartTime;
						NewActionSection->LineUniqueIDLinked = DialogueSection->LineUniqueIDLinked;
						CameraCuts.Add(NewActionSection);
						Dialogues.Add(DialogueSection);
					}
				}
			}
			DialogueEditorManager->SetAllAutoCameraCutTargetCamera(CameraCuts, Dialogues);
		}
		if (DialogueEditor)
		{
			DialogueEditor->DialogueTimelineController.Pin()->RefreshTracks();
		}
	}
}

void FDialogueAutoTools::CreateAutoLookAts(UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager, bool CoveragePrompt)
{
	if (DialogueEditor == nullptr && InDialogueEditorManager == nullptr)
	{
		return;
	}
	UDialogueEditorManager* DialogueEditorManager;
	if (InDialogueEditorManager)
	{
		DialogueEditorManager = InDialogueEditorManager;
	}
	else
	{
		DialogueEditorManager = DialogueEditor->GetDialogueEditorManager();
	}
	if (!IsLookAtEmpty(DialogueAsset))
	{
		const FText Message = FText::FromString(TEXT("已有lookat数据，是否覆盖？"));
		EAppReturnType::Type Ret = FMessageDialog::Open(EAppMsgType::YesNo, Message);
		if (Ret != EAppReturnType::Yes)
		{
			return;
		}
	}
	UClass* OldBPLookAtTrackClass = StaticLoadClass(UObject::StaticClass(), nullptr, *OldLookAtTrackPath);
	for (FDialogueEpisode& Episode : DialogueAsset->Episodes)
	{
		TArray<UDialogueActorTrack*> ActorTracks;
		for (UDialogueTrackBase* Track : Episode.GetAllTracks())
		{
			if (UDialogueActorTrack* ActorTrack = Cast<UDialogueActorTrack>(Track))
			{
				ActorTracks.Add(ActorTrack);
			}
			// 删除旧的lookat轨道
			if (Track->IsA(OldBPLookAtTrackClass))
			{
				UDialogueActionTrack* OldLookAtTrack = Cast<UDialogueActionTrack>(Track);
				for (UDialogueActionBase* ActionSection : OldLookAtTrack->ActionSections)
				{
					ActionSection->Rename(nullptr, GetTransientPackage());
				}
				Episode.TrackList.Remove(Track);
			}
		}
		int32 CurrentEpisodeID = Episode.EpisodeID;
		UDialogueActionTrack* DialogueTrack = Cast<UDialogueActionTrack>(DialogueAsset->FindEpisodeTrackByTrackClass(CurrentEpisodeID, UDialogueDialogueTrack::StaticClass()));
		if (!DialogueTrack)
		{
			continue;
		}
		// 单人的对话，不需要lookat
		if (ActorTracks.Num() > 1)
		{
			for (int32 i = 0; i < ActorTracks.Num(); i++)
			{
				TArray<UDialogueActionBase*> LookAts;
				TArray<UDialogueActionBase*> Dialogues;
				UDialogueActionTrack* LookAtTrack = FindOrAddLookAtTrack(DialogueAsset, ActorTracks[i]);
				LookAtTrack->ActionSections.Empty();
				for (UDialogueActionBase* DialogueSection : DialogueTrack->ActionSections)
				{
					if (DialogueSection)
					{
						if (UDialogueActionBase* NewActionSection = DialogueAsset->AddSection(CurrentEpisodeID, LookAtTrack))
						{
							NewActionSection->StartTime = DialogueSection->StartTime;
							NewActionSection->Duration = DialogueSection->Duration;
							NewActionSection->LineUniqueIDLinked = DialogueSection->LineUniqueIDLinked;
							LookAts.Add(NewActionSection);
							Dialogues.Add(DialogueSection);
						}
					}
				}
				// 双人的对话，都看对方
				if (ActorTracks.Num() == 2)
				{
					for (auto LookAtSection : LookAts)
					{
						DialogueEditorManager->SetLookAtSectionTarget(LookAtSection, ActorTracks[1 - i]->GetTrackName().ToString());
					}
				}
				// 多人的对话，按说话者规则选择目标
				else
				{
					TArray<int32> EmptyTargetSection;
					DialogueEditorManager->SetAllAutoLookAtSection(LookAts, Dialogues, ActorTracks[i]->GetTrackName().ToString(), EmptyTargetSection);
					for (const int32 EmptyIndex: EmptyTargetSection)
					{
						LookAtTrack->ActionSections.RemoveAt(EmptyIndex);
					}
				}
			}
		}
	}
	if (DialogueEditor)
	{
		DialogueEditor->DialogueTimelineController.Pin()->RefreshTracks();
	}
}

void FDialogueAutoTools::CreateLookAts(class UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager, bool CoveragePrompt)
{
	if (DialogueEditor == nullptr && InDialogueEditorManager == nullptr)
	{
		return;
	}
	UDialogueEditorManager* DialogueEditorManager;
	if (InDialogueEditorManager)
	{
		DialogueEditorManager = InDialogueEditorManager;
	}
	else
	{
		DialogueEditorManager = DialogueEditor->GetDialogueEditorManager();
	}
	if (!IsLookAtEmpty(DialogueAsset))
	{
		const FText Message = FText::FromString(TEXT("已有lookat数据，是否覆盖？"));
		EAppReturnType::Type Ret = FMessageDialog::Open(EAppMsgType::YesNo, Message);
		if (Ret != EAppReturnType::Yes)
		{
			return;
		}
	}
	UClass* OldBPLookAtTrackClass = StaticLoadClass(UObject::StaticClass(), nullptr, *OldLookAtTrackPath);
	TArray<UDialogueActionBase*> LookAtSections;
	for (FDialogueEpisode& Episode : DialogueAsset->Episodes)
	{
		// 删除旧的lookat轨道
		UDialogueActionTrack* OldLookAtTrack = nullptr;
		for (UDialogueTrackBase* Track : Episode.GetAllTracks())
		{
			if (Track->IsA(OldBPLookAtTrackClass))
			{
				OldLookAtTrack = Cast<UDialogueActionTrack>(Track);
				OldLookAtTrack->ActionSections.Empty();
			}
			if (UDialogueActorTrack* ActorTrack = Cast<UDialogueActorTrack>(Track))
			{
				if (UDialogueActionTrack* LookAtTrack = FindLookAtTrack(DialogueAsset, ActorTrack))
				{
					LookAtTrack->ActionSections.Empty();
					ActorTrack->Actions.Remove(LookAtTrack);
				}
			}
		}
		if (!OldLookAtTrack)
		{
			OldLookAtTrack =  NewObject<UDialogueActionTrack>(DialogueAsset, OldBPLookAtTrackClass, NAME_None, RF_Transactional);
			Episode.TrackList.Add(OldLookAtTrack);
		}
		int32 CurrentEpisodeID = Episode.EpisodeID;
		UDialogueActionTrack* DialogueTrack = Cast<UDialogueActionTrack>(DialogueAsset->FindEpisodeTrackByTrackClass(CurrentEpisodeID, UDialogueDialogueTrack::StaticClass()));
		if (!DialogueTrack)
		{
			continue;
		}
		if (UDialogueActionBase* NewActionSection = DialogueAsset->AddSection(CurrentEpisodeID, OldLookAtTrack))
		{
			NewActionSection->StartTime = 0;
			LookAtSections.Add(NewActionSection);
		}
	}
	DialogueEditorManager->SetAllLookAtSectionAuto(LookAtSections);
	if (DialogueEditor)
	{
		DialogueEditor->DialogueTimelineController.Pin()->RefreshTracks();
	}
}

void FDialogueAutoTools::CreateAutoLookAtAndCuts(UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager, const bool CoveragePrompt, const bool bManualTrigger)
{
	if (DialogueEditor == nullptr && InDialogueEditorManager == nullptr)
	{
		return;
	}
	
	// 处理分镜
	bool bCreate = true;
	// 需要覆盖提示
	if (CoveragePrompt)
	{
		bool HasCutsSection = false;
		for (FDialogueEpisode& Episode : DialogueAsset->Episodes)
		{
			for (UDialogueTrackBase* ActionTrack : Episode.GetAllTracks())
			{
				if (ActionTrack->IsA(UDialogueCameraCutTrack::StaticClass()))
				{
					UDialogueCameraCutTrack* CameraCutTrack = Cast<UDialogueCameraCutTrack>(ActionTrack);
					if (!CameraCutTrack->ActionSections.IsEmpty())
					{
						HasCutsSection = true;
						break;
					}
				}
			}
			if (HasCutsSection)
			{
				const FText Message = FText::FromString(TEXT("已有分镜数据，是否覆盖？"));
				EAppReturnType::Type Ret = FMessageDialog::Open(EAppMsgType::YesNo, Message);
				if (Ret != EAppReturnType::Yes)
				{
					bCreate = false;
				}
				break;
			}
		}
	}
	if (bCreate)
	{
		if (DialogueAsset->PerformerList.Num() == 2)
		{
			CreateAutoCameras(DialogueAsset, DialogueEditor, InDialogueEditorManager);
		}
		else if (bManualTrigger)
		{
			CreateMultiAutoCameras(DialogueAsset, DialogueEditor, InDialogueEditorManager);
		}
	}

	// 处理lookat
	if (bManualTrigger)
	{
		CreateLookAts(DialogueAsset, DialogueEditor, InDialogueEditorManager);
	}
}
