// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/Context/KGSLEdCtxSectionAutoLinkLine.h"

#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"

FKGSLEdCtxSectionAutoLinkLine::FKGSLEdCtxSectionAutoLinkLine(EKGSLEdContextIdentifier ContextID, uint32 InPriority, bool bInUnique)
	: FKGSLEdContext(ContextID, InPriority, bInUnique)
{
}

FKGSLEdCtxSectionAutoLinkLine::~FKGSLEdCtxSectionAutoLinkLine()
{
}

void FKGSLEdCtxSectionAutoLinkLine::OnInitialized()
{
	
	FKGSLEdContext::OnInitialized();
}

void FKGSLEdCtxSectionAutoLinkLine::OnUninitialized()
{
	
	FKGSLEdContext::OnUninitialized();
}

bool FKGSLEdCtxSectionAutoLinkLine::IsValid() const
{
	return KGStoryLine::IsValidEpisodeID(EpisodeID)
	&& LineUniqueID.IsValid()
	&& FKGSLEdContext::IsValid();
}

void FKGSLEdCtxSectionAutoLinkLine::OnActionSectionAdded(class UDialogueAsset* Asset, class UDialogueActionBase* SectionAdded)
{
	if (!IsValid() || !SectionAdded || !SectionAdded->IsValidLowLevel())
	{
		return;
	}

	if (UDialogueDialogue* NewDialogueSection = Cast<UDialogueDialogue>(SectionAdded))
	{
		return;
	}

	if (TargetAction->OwnedEpisodeID == SectionAdded->OwnedEpisodeID)
	{
		SectionAdded->LineUniqueIDLinked = TargetAction->LineUniqueIDLinked;
	}
}

void FKGSLEdCtxSectionAutoLinkLine::OnActionSectionRemoved(class UDialogueAsset* Asset, class UDialogueActionBase* SectionRemoved)
{
	if (TargetAction.IsValid() && TargetAction == SectionRemoved)
	{
		TargetAction.Reset();
		SetValidation(false);
	}
}

bool FKGSLEdCtxSectionAutoLinkLine::IsCurrentLinkTarget(UDialogueDialogue* Section) const
{
	if (!::IsValid(Section))
	{
		return false;
	}

	return Section->OwnedEpisodeID == EpisodeID && Section->LineUniqueIDLinked == LineUniqueID;
}

UDialogueDialogue* FKGSLEdCtxSectionAutoLinkLine::GetCurrentLinkSection() const
{
	if (TargetAction.IsValid())
	{
		return TargetAction.Get();
	}

	return nullptr;
}

bool FKGSLEdCtxSectionAutoLinkLine::SetCurrentLinkSection(UDialogueDialogue* Section)
{
	if (!bValidation)
	{
		return false;
	}
	
	UDialogueDialogue* Last = TargetAction.Get();
	uint32 NewEpisodeID = ::IsValid(Section) ? Section->OwnedEpisodeID : KGStoryLine::INVALID_EPISODE_ID;
	if (EpisodeID != NewEpisodeID || LineUniqueID != Section->LineUniqueIDLinked)
	{
		TargetAction = Section;
		EpisodeID = NewEpisodeID;
		if (Section)
		{
			LineUniqueID = Section->LineUniqueIDLinked;
		}
		else
		{
			LineUniqueID.Invalidate();
		}
		OnCurrentLinkSectionChanged.Broadcast(Last, Section);
		return true;
	}

	return false;
}
