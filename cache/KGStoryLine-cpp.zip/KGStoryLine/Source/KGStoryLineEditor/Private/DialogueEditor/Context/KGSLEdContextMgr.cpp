// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/Context/KGSLEdContextMgr.h"

FKGSLEdContextMgr::FKGSLEdContextMgr()
{
}

FKGSLEdContextMgr::~FKGSLEdContextMgr()
{
}

void FKGSLEdContextMgr::OnActionSectionAdded(UDialogueAsset* Asset, UDialogueActionBase* SectionAdded)
{
	TArray<TSharedPtr<FKGSLEdContext>> ContextsPendingRemove;
	for (auto& Context : ContextsResponseOnActionSectionAdded)
	{
		if (Context->IsValid())
		{
			Context->OnActionSectionAdded(Asset, SectionAdded);
		}
		else
		{
			ContextsPendingRemove.Add(Context);
		}
	}

	for (auto& Context : ContextsPendingRemove)
	{
		PopContext(Context, false);
	}

	Contexts.HeapSort();
}

void FKGSLEdContextMgr::OnActionSectionRemoved(class UDialogueAsset* Asset, class UDialogueActionBase* SectionRemoved)
{
	TArray<TSharedPtr<FKGSLEdContext>> ContextsPendingRemove;
	for (auto& Context : ContextsResponseOnActionSectionAdded)
	{
		if (Context->IsValid())
		{
			Context->OnActionSectionRemoved(Asset, SectionRemoved);
		}
		else
		{
			ContextsPendingRemove.Add(Context);
		}
	}

	for (auto& Context : ContextsPendingRemove)
	{
		PopContext(Context, false);
	}
	Contexts.HeapSort();
}
