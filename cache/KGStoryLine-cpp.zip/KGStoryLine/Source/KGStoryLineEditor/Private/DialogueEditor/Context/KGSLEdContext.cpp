// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/Context/KGSLEdContext.h"

FKGSLEdContext::FKGSLEdContext(EKGSLEdContextIdentifier InContextID,uint32 InPriority, bool bInUnique)
	: ContextID(InContextID)
	, Priority(InPriority)
	, bUnique(bInUnique)
{
}

FKGSLEdContext::~FKGSLEdContext()
{
}

bool FKGSLEdContext::operator<(const FKGSLEdContext& Other) const
{
	return Priority > Other.Priority;
}

void FKGSLEdContext::SetUnique(bool bInUnique)
{
	bUnique = bInUnique;
}

void FKGSLEdContext::SetPriority(uint32 InPriority)
{
	Priority = InPriority;
}

void FKGSLEdContext::Initialize()
{
	OnInitialized();
}

void FKGSLEdContext::Uninitialize()
{
	OnUninitialized();
}

bool operator<(const TSharedPtr<FKGSLEdContext>& A, const TSharedPtr<FKGSLEdContext>& B)
{
	if (A.IsValid() && B.IsValid())
	{
		return A.Get() < B.Get();
	}

	if (A.IsValid())
	{
		return true;
	}

	return false;
}
