
#include "DialogueEditor/DialogueEditorWorldExtension.h"
#include "InputCoreTypes.h"
#include "Editor/ActorPositioning.h"
#include "Kismet/KismetSystemLibrary.h"
#include "HAL/PlatformApplicationMisc.h"
#include "EditorViewportClient.h"
#include "DialogueEditor/DialogueEditor.h"
#include "SceneView.h"
#include "Engine/HitResult.h"

UDialogueEditorWorldExtension::UDialogueEditorWorldExtension()
{
	
}

bool UDialogueEditorWorldExtension::InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event)
{
	auto GetHitLocation = [ViewportClient, Viewport](FVector& Location)
	{
		int32 const HitX = Viewport->GetMouseX();
		int32 const HitY = Viewport->GetMouseY();

		FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
			Viewport,
			ViewportClient->GetScene(),
			ViewportClient->EngineShowFlags)
			.SetRealtimeUpdate(true));
		FSceneView* View = ViewportClient->CalcSceneView(&ViewFamily);
		FViewportCursorLocation Cursor(View, ViewportClient, HitX, HitY);


		FActorPositionTraceResult Results;

		const auto ViewportType = ViewportClient->GetViewportType();

		FVector RayStart = Cursor.GetOrigin();
		if (ViewportType == LVT_OrthoXY || ViewportType == LVT_OrthoXZ || ViewportType == LVT_OrthoYZ ||
			ViewportType == LVT_OrthoNegativeXY || ViewportType == LVT_OrthoNegativeXZ || ViewportType == LVT_OrthoNegativeYZ)
		{
			RayStart -= Cursor.GetDirection() * HALF_WORLD_MAX / 2;
		}

		const FVector RayEnd = RayStart + Cursor.GetDirection() * HALF_WORLD_MAX;

		TArray<AActor*> ActorsToIgnore;
		FHitResult OutHit;
		bool Result = UKismetSystemLibrary::LineTraceSingle(ViewportClient->GetWorld(), RayStart, RayEnd,
			UEngineTypes::ConvertToTraceType(ECC_Visibility), false, ActorsToIgnore, EDrawDebugTrace::ForDuration, OutHit, true,
			FLinearColor::Red, FLinearColor::Green, 1.0f);

		if (Result)
		{
			Location = OutHit.ImpactPoint;
		}

		return Result;
	};
	
	if (Event == EInputEvent::IE_Pressed && Key == EKeys::LeftMouseButton)
	{
		const bool bCtrlDown = Viewport->KeyState(EKeys::LeftControl) || Viewport->KeyState(EKeys::RightControl);
		const bool bWDown = Viewport->KeyState(EKeys::W);
		const bool bQDown = Viewport->KeyState(EKeys::Q);
		if (bCtrlDown && (bWDown || bQDown) )
		{
			FVector WorldPosition;
			bool bHit = GetHitLocation(WorldPosition);
			FString PosStrClip;
			if (bHit)
			{
				const FString PosStr = bWDown ? TEXT("{0},{1},{2}") : TEXT("(X={0},Y={1},Z={2})");
				PosStrClip = FString::Format(*PosStr, { (int32)WorldPosition.X,(int32)WorldPosition.Y, (int32)WorldPosition.Z });
			}
			
			FPlatformApplicationMisc::ClipboardCopy(*PosStrClip);
			//FPlatformMisc::ClipboardCopy(*PosStrClip);
		}
	}

	if (Event == EInputEvent::IE_Pressed && Key == EKeys::RightMouseButton)
	{
		const bool bShiftDown = Viewport->KeyState(EKeys::LeftShift) || Viewport->KeyState(EKeys::RightShift);
		if (bShiftDown)
		{
			FVector WorldPosition;
			bool bHit = GetHitLocation(WorldPosition);
			if (bHit)
			{
				CachedEditor.Pin()->SetSelectActorHere(WorldPosition);
			}
		}
	}

	return false;
}
