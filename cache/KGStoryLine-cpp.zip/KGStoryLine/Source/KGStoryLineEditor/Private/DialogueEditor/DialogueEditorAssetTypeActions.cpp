#include "DialogueEditor/DialogueEditorAssetTypeActions.h"

#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Misc/MessageDialog.h"
#include "EditorModeManager.h"
#include "KGStoryLineDefine.h"
#include "KGStoryLineEditorModule.h"
#include "3C/Movement/MovementPipeline/MovementCorrector/MovementCorrectorManager.h"
#include "DialogueEditor/Util/KGSLEdUtil.h"

#pragma optimize("", off)

#define LOCTEXT_NAMESPACE "AssetTypeActions_DialogueNewVersioAsset"

namespace
{
	bool IsGamePreview()
	{
		for (const FWorldContext& Context : GEngine->GetWorldContexts())
		{
			if (Context.WorldType == EWorldType::Game
				|| Context.WorldType == EWorldType::GamePreview
				|| Context.WorldType == EWorldType::PIE)
			{
				return true;
			}
		}

		return false;
	}
}

FAssetTypeActions_DialogueTemplateAsset::FAssetTypeActions_DialogueTemplateAsset(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{

}

FAssetTypeActions_DialogueTemplateAsset::~FAssetTypeActions_DialogueTemplateAsset()
{

}

FText FAssetTypeActions_DialogueTemplateAsset::GetName() const
{
	return LOCTEXT("AssetTypeActions_DialogueTemplateAsset", "DialogueTemplate");
}

FColor FAssetTypeActions_DialogueTemplateAsset::GetTypeColor() const
{
	return FColor::Cyan;
}

UClass* FAssetTypeActions_DialogueTemplateAsset::GetSupportedClass() const
{
	return UDialogueTemplateAsset::StaticClass();
}

void FAssetTypeActions_DialogueTemplateAsset::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{

}

void FAssetTypeActions_DialogueTemplateAsset::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	if (IsGamePreview())
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("游戏状态下不可以编辑对话")));
		return;
	}

	if (InObjects.Num() > 1)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("剧情对话编辑器暂时不允许多开.")));
		return;
	}

	for (UObject* Object : InObjects)
	{
		if (UDialogueTemplateAsset* DialogueAsset = Cast<UDialogueTemplateAsset>(Object))
		{
			IDialogueEditor::OpenEditor(DialogueAsset, EditWithinLevelEditor);
		}
	}
}

bool FAssetTypeActions_DialogueTemplateAsset::SupportsOpenedMethod(const EAssetTypeActivationOpenedMethod OpenedMethod) const
{
	if (!FKGStoryLineEditorModule::CanTypeOfAssetOpen(UDialogueAsset::StaticClass()))
		return false;
	
	return FAssetTypeActions_Base::SupportsOpenedMethod(OpenedMethod);
}

uint32 FAssetTypeActions_DialogueTemplateAsset::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}



FAssetTypeActions_DialogueAsset::FAssetTypeActions_DialogueAsset(EAssetTypeCategories::Type InAssetCategory) : MyAssetCategory(InAssetCategory)
{

}

FAssetTypeActions_DialogueAsset::~FAssetTypeActions_DialogueAsset()
{

}

FText FAssetTypeActions_DialogueAsset::GetName() const
{
	return LOCTEXT("AssetTypeActions_DialogueAsset", "Dialogue");
}

FColor FAssetTypeActions_DialogueAsset::GetTypeColor() const
{
	return FColor::Cyan;
}

UClass* FAssetTypeActions_DialogueAsset::GetSupportedClass() const
{
	return UDialogueAsset::StaticClass();
}

void FAssetTypeActions_DialogueAsset::ExecuteValidateEpisodeID(TArray<TWeakObjectPtr<class UDialogueAsset>> DialogueAssets)
{
	for(auto Asset : DialogueAssets)
	{
		if(Asset.IsValid() && IsValid(Asset.Get()))
		{
			ValidateEpisodeID(Asset.Get());
		}
	}
}

void FAssetTypeActions_DialogueAsset::ExecuteValidateEpisodeTracks(TArray<TWeakObjectPtr<class UDialogueAsset>> DialogueAssets)
{
	for(auto Asset : DialogueAssets)
	{
		if(Asset.IsValid() && IsValid(Asset.Get()))
		{
			ValidateEpisodeTracks(Asset.Get());
		}
	}
}

void FAssetTypeActions_DialogueAsset::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{
	auto DialogueAssets = GetTypedWeakObjectPtrs<UDialogueAsset>(InObjects);
	if (DialogueAssets.Num() <= 0)
	{
		return;
	}
	
	MenuBuilder.AddMenuEntry(
		LOCTEXT("KGSL_Editor_ValidateEpisodeID_Title", "Validate dialogue episode ID"),
		LOCTEXT("KGSL_Editor_ValidateEpisodeID_ToolTip", "Validate dialogue episode ID"),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(this, &FAssetTypeActions_DialogueAsset::ExecuteValidateEpisodeID, DialogueAssets)));

	MenuBuilder.AddMenuEntry(
		LOCTEXT("KGSL_Editor_ValidateEpisodeTracks_Title", "Validate dialogue episode tracks"),
		LOCTEXT("KGSL_Editor_ValidateEpisodeTracks_ToolTip", "Validate dialogue episode tracks"),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(this, &FAssetTypeActions_DialogueAsset::ExecuteValidateEpisodeTracks, DialogueAssets)));
}

void FAssetTypeActions_DialogueAsset::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("双击打开模式已禁止，请通过上方工具栏->C7_Editor->剧情编辑器入口打开")));
}

uint32 FAssetTypeActions_DialogueAsset::GetCategories()
{
	MyAssetCategory = EAssetTypeCategories::Type::Gameplay;

	return MyAssetCategory;
}

void FAssetTypeActions_DialogueAsset::ValidateEpisodeID(UDialogueAsset* Asset)
{
	bool bNeedReimport = false;
	TArray<int32, TInlineAllocator<16>> EpisodeIDs;
	for(auto* Episode : Asset->EpisodesList)
	{
		int32 Count = EpisodeIDs.Num();
		int32 Index = EpisodeIDs.AddUnique(Episode->GetEpisodeID());
		if(Index < Count)
		{
			bNeedReimport = true;
			break;
		}
	}

	if(bNeedReimport)
	{
		UE_LOG(LogKGSL, Log, TEXT("[KGSL]Episode ID is duplicated:%s"), *Asset->GetFullName());
	}
}

void FAssetTypeActions_DialogueAsset::ValidateEpisodeTracks(UDialogueAsset* Asset)
{
	if (Asset->Episodes.Num() == Asset->GetDialogueEpisodesCount())
	{
		return ;
	}

	TMap<int32, FDialogueEpisode*> EpisodeTracks;
	for (UKGSLDialogueEpisode* Episode : Asset->EpisodesList)
	{
		int32 EpisodeID = Episode->GetEpisodeID();
		FDialogueEpisode* Target = Asset->Episodes.FindByPredicate([EpisodeID](const FDialogueEpisode& Ep) -> bool
		{
			if(Ep.EpisodeID == EpisodeID)
			{
				return Ep.TrackList.Num() > 0;
			}
			return false;
		});

		if (Target != nullptr)
		{
			EpisodeTracks.Emplace(EpisodeID, Target);
		}
	}

	if (EpisodeTracks.Num() != Asset->GetDialogueEpisodesCount())
	{
		UE_LOG(LogKGSL, Log, TEXT("[KGSL]ValidateEpisodeTracks:data is lost,Episodes.Num() != EpisodesList.Num().Asset:%s"), *Asset->GetFullName());
		return;
	}

	int32 CountRemoved = Asset->Episodes.RemoveAll([&](const FDialogueEpisode& Episode) -> bool
	{
		return !EpisodeTracks.Contains(Episode.EpisodeID) || &Episode != EpisodeTracks[Episode.EpisodeID];
	});
	
	if (CountRemoved > 0)
	{
		UE_LOG(LogKGSL, Log, TEXT("[KGSL]ValidateEpisodeTracks:remove invalid tracks[%d]:%s"),
			CountRemoved, *Asset->GetFullName());
	}
}


#undef LOCTEXT_NAMESPACE

#pragma optimize("", on)

