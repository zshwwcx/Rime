// Fill out your copyright notice in the Description page of Project Settings.


#include "DialogueEditor/KGStoryLineEditorSubSystem.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "Editor.h"
#include "InterchangeTranslatorBase.h"
#include "DialogueEditor/Util/KGSLEdUtil.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "SourceControlHelpers.h"

class FLineGUIDRecover
{
public:
	explicit FLineGUIDRecover(UKGSLDialogueLine* Line) : Line(Line)
	{
		GUID = Line->GUID;
		UniqueID = Line->UniqueID;
	}
	~FLineGUIDRecover()
	{
		if(Line.IsValid())
		{
			Line->GUID = GUID;
			Line->UniqueID = UniqueID;
		}
	}
private:
	TWeakObjectPtr<UKGSLDialogueLine> Line;
	int32 GUID;
	FGuid UniqueID;
};

UKGStoryLineEditorSubSystem& UKGStoryLineEditorSubSystem::Get()
{
	UKGStoryLineEditorSubSystem* Instance = GetPtr();
	check(Instance != nullptr);
	return *Instance;
}

UKGStoryLineEditorSubSystem* UKGStoryLineEditorSubSystem::GetPtr()
{
	return GEditor->GetEditorSubsystem<UKGStoryLineEditorSubSystem>();
}

void UKGStoryLineEditorSubSystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	if (AssetRegistryModule.IsValid())
		AssetRegistryModule.Get().OnAssetRemoved().AddUObject(this, &UKGStoryLineEditorSubSystem::OnAssetRemoved);

}

void UKGStoryLineEditorSubSystem::Deinitialize()
{
	Super::Deinitialize();
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	if (AssetRegistryModule.IsValid())
		AssetRegistryModule.Get().OnAssetRemoved().RemoveAll(this);
}

UDialogueBaseAsset* UKGStoryLineEditorSubSystem::GetAsset(int32 EpisodeID)
{
	for(const auto& Asset : AssetsToEditors)
	{
		if(Asset.Key.IsValid() && IsValid(Asset.Key.Get()))
		{
			for(const auto& Episode : Asset.Key->Episodes)
			{
				if(Episode.EpisodeID == EpisodeID)
				{
					return Asset.Key.Get();
				}
			}
		}
	}
	
	return nullptr;
}

TSharedPtr<FDialogueEditor> UKGStoryLineEditorSubSystem::GetEditor(int32 EpisodeID) const
{
	for(const auto& Asset : AssetsToEditors)
	{
		if(Asset.Key.IsValid() && IsValid(Asset.Key.Get()))
		{
			for(const auto& Episode : Asset.Key->Episodes)
			{
				if(Episode.EpisodeID == EpisodeID)
				{
					return Asset.Value;
				}
			}
		}
	}
	
	return nullptr;
}

TSharedPtr<FDialogueEditor> UKGStoryLineEditorSubSystem::GetEditor(UDialogueBaseAsset* Asset) const
{
	if(!Asset || !IsValid(Asset))
	{
		return nullptr;
	}
	
	if(AssetsToEditors.Contains(Asset))
	{
		return AssetsToEditors[Asset];
	}

	return nullptr;
}

TSharedPtr<FDialogueEditor> UKGStoryLineEditorSubSystem::GetInUsingEditor()
{
	if (AssetsToEditors.IsEmpty())
	{
		return nullptr;
	}

	for (auto& Iter : AssetsToEditors)
	{
		return Iter.Value.IsValid() ? Iter.Value : nullptr;
	}

	return nullptr;
}

bool UKGStoryLineEditorSubSystem::RegisterAsset(UDialogueBaseAsset* Asset, TSharedPtr<FDialogueEditor> Editor)
{
	if (!Asset || !IsValid(Asset))
	{
		return false;
	}
	
	if(!AssetsToEditors.Contains(Asset))
	{
		AssetsToEditors.Add(Asset, Editor);
	}
	else if( AssetsToEditors[Asset] != Editor)
	{
		AssetsToEditors[Asset] = Editor;
	}
	
	return true;
}

bool UKGStoryLineEditorSubSystem::UnregisterAsset(const UDialogueBaseAsset* Asset)
{
	if (!Asset || !IsValid(Asset))
	{
		return false;
	}

	if(AssetsToEditors.Contains(Asset))
	{
		AssetsToEditors.Remove(Asset);
	}
	
	return true;
}

bool UKGStoryLineEditorSubSystem::IsDialogueEditorOpen() const
{
	return AssetsToEditors.Num() > 0;
}

void UKGStoryLineEditorSubSystem::RemoveListener(ListenerType* Listener)
{
	for(auto& Pair : Listeners)
	{
		Pair.Value.Remove(Listener);
	}
}

void UKGStoryLineEditorSubSystem::PreChange(const UDialogueAsset* Asset, EKGSLDataChangeInfo ChangeInfo)
{
	if(Listeners.Contains(ChangeInfo))
	{
		auto& SetListeners = Listeners[ChangeInfo];
		for(auto& Pair : SetListeners)
		{
			Pair->PreChange(Asset, ChangeInfo);
		}
	}
}

void UKGStoryLineEditorSubSystem::PostChange(const UDialogueAsset* Asset, EKGSLDataChangeInfo ChangeInfo)
{
	if(Listeners.Contains(ChangeInfo))
	{
		auto& SetListeners = Listeners[ChangeInfo];
		for(auto& Pair : SetListeners)
		{
			Pair->PostChange(Asset, ChangeInfo);
		}
	}
}

void UKGStoryLineEditorSubSystem::BroadcastPreChanged(const UDialogueAsset* Asset, EKGSLDataChangeInfo ChangeInfo)
{
	if(UKGStoryLineEditorSubSystem* This = GetPtr())
	{
		This->PreChange(Asset, ChangeInfo);
	}
}

void UKGStoryLineEditorSubSystem::BroadcastPostChanged(const UDialogueAsset* Asset, EKGSLDataChangeInfo ChangeInfo)
{
	if(UKGStoryLineEditorSubSystem* This = GetPtr())
	{
		This->PostChange(Asset, ChangeInfo);
	}
}

void UKGStoryLineEditorSubSystem::SelectLine(const UDialogueAsset* Asset, int32 EpisodeID, FName LineName)
{
	if(UKGStoryLineEditorSubSystem* This = GetPtr())
	{
		if(This->Listeners.Contains(EKGSLDataChangeInfo::LineSelected))
		{
			auto& SetListeners = This->Listeners[EKGSLDataChangeInfo::LineSelected];
			for(auto& Pair : SetListeners)
			{
				Pair->SelectionChange(Asset, EpisodeID, LineName);
			}
		}
	}
}

UKGSLDialogueLine* UKGStoryLineEditorSubSystem::AddLine(UDialogueAsset* Asset, int32 EpisodeID, const FString& Content)
{
	check(Asset != nullptr);
	if(UKGSLDialogueEpisode* Episode  = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		int32 Count = Episode->DialogueLines.Num();
		FName NewName(*FString::FromInt(Count + 1));

		BroadcastPreChanged(Asset, EKGSLDataChangeInfo::LineAdded);
		
		Asset->Modify();
			
		UKGSLDialogueLine* NewLine = Episode->InstanceLine(Content, TEXT(""));
		Episode->AddLine(NewLine);

		Asset->MarkPackageDirty();

		BroadcastPostChanged(Asset, EKGSLDataChangeInfo::LineAdded);
		SelectLine(Asset, EpisodeID, NewName);
		return NewLine;
	}

	return nullptr;
}

UKGSLDialogueLine* UKGStoryLineEditorSubSystem::InsertLine(UDialogueAsset* Asset, int32 EpisodeID, int32 InsertPos, const FString& Content)
{
	check(Asset != nullptr);
	if(UKGSLDialogueEpisode* Episode  = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		int32 Count = Episode->DialogueLines.Num();
		InsertPos = FMath::Clamp(InsertPos, 0, Count);
		FName NewName(*FString::FromInt(InsertPos + 1));

		BroadcastPreChanged(Asset, EKGSLDataChangeInfo::LineAdded);
		
		Asset->Modify();
			
		UKGSLDialogueLine* NewLine = Episode->InstanceLine(Content, TEXT(""));
		Episode->AddLine(NewLine, InsertPos);

		Asset->MarkPackageDirty();

		BroadcastPostChanged(Asset, EKGSLDataChangeInfo::LineAdded);
		SelectLine(Asset, EpisodeID, NewName);
		return NewLine;
	}

	return nullptr;
}

UKGSLDialogueLine* UKGStoryLineEditorSubSystem::DuplicateLine(UDialogueAsset* Asset, int32 EpisodeID, int32 SrcLineIndex)
{
	check(Asset != nullptr);
	
	if(UKGSLDialogueLine* Line = Asset->GetDialogueLine(EpisodeID, SrcLineIndex))
	{
		if(UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID))
		{
			BroadcastPreChanged(Asset, EKGSLDataChangeInfo::LineAdded);				

			UKGSLDialogueLine* NewLine = Episode->InstanceLine(Line->ContentString, TEXT(""));
			Asset->Modify();
				
			{
				FLineGUIDRecover Recover(NewLine);
				KGStoryLineEditor::CopyProperty(NewLine, Line);
			}
			Episode->AddLine(NewLine);
			
			BroadcastPostChanged(Asset, EKGSLDataChangeInfo::LineAdded);
			return NewLine;
		}			
	}	

	return nullptr;
}

bool UKGStoryLineEditorSubSystem::RemoveLine(UDialogueAsset* Asset, int32 EpisodeID, int32 LineIndex)
{
	check(Asset != nullptr);
	UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID);
	if(Episode && Episode->DialogueLines.IsValidIndex(LineIndex))
	{
		BroadcastPreChanged(Asset, EKGSLDataChangeInfo::LineRemoved);
		Asset->Modify();
		Episode->RemoveLine(LineIndex);
		BroadcastPostChanged(Asset, EKGSLDataChangeInfo::LineRemoved);
		return true;
	}

	return false;
}

bool UKGStoryLineEditorSubSystem::MoveRow(UDialogueAsset* Asset, int32 EpisodeID, int32 LineIndex,
	FDataTableEditorUtils::ERowMoveDirection Direction, int32 NumRowsToMoveBy)
{
	check(Asset != nullptr);
	if(UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		int32 NewLineIndex = INDEX_NONE;
		switch (Direction)
		{
		case FDataTableEditorUtils::ERowMoveDirection::Up:
			NewLineIndex = FMath::Clamp(LineIndex - NumRowsToMoveBy, 0, Episode->DialogueLines.Num() - 1);
			break;
		case FDataTableEditorUtils::ERowMoveDirection::Down:
			NewLineIndex = FMath::Clamp(LineIndex + NumRowsToMoveBy, 0, Episode->DialogueLines.Num() - 1);
			break;
		default:
			break;
		}

		if(NewLineIndex == INDEX_NONE || LineIndex == NewLineIndex)
		{
			return false;
		}			

		BroadcastPreChanged(Asset, EKGSLDataChangeInfo::LineSwapped);
		Asset->Modify();
		Episode->DialogueLines.Swap(LineIndex, NewLineIndex);
		BroadcastPostChanged(Asset, EKGSLDataChangeInfo::LineSwapped);
		return true;
	}

	return false;
}

bool UKGStoryLineEditorSubSystem::DiffersFromDefault(UDialogueAsset* Asset, int32 EpisodeID, int32 LineIndex)
{
	return false;
}

bool UKGStoryLineEditorSubSystem::ResetToDefault(UDialogueAsset* Asset, int32 EpisodeID, int32 LineIndex)
{
	return false;
}

UKGSLDialogueEpisode* UKGStoryLineEditorSubSystem::AddEpisode(UDialogueAsset* Asset, const TFunction<void(UKGSLDialogueEpisode*)>& Callback)
{
	check(Asset != nullptr);
	if (UKGSLDialogueEpisode* Episode = Asset->InstanceDialogueEpisode(Asset->GenerateValidEpisodeID()))
	{
		BroadcastPreChanged(Asset, EKGSLDataChangeInfo::EpisodeAdded);
;
		Asset->AddDialogueEpisode(Episode);

		if(Callback != nullptr)
		{
			Callback(Episode);
		}

		Asset->MarkPackageDirty();
		
		BroadcastPostChanged(Asset, EKGSLDataChangeInfo::EpisodeAdded);
		SelectEpisode(Asset, Episode->GetEpisodeID());
		return Episode;
	}
	
	return nullptr;
}

UKGSLDialogueEpisode* UKGStoryLineEditorSubSystem::DuplicateEpisode(UDialogueAsset* Asset, int32 SrcEpisodeID)
{
	check(Asset);
	if(UKGSLDialogueEpisode* SrcEpisode = Asset->GetDialogueEpisodeByEpisodeID(SrcEpisodeID))
	{
		if(UKGSLDialogueEpisode* NewEpisode = DuplicateObject<UKGSLDialogueEpisode>(SrcEpisode, Asset))
		{
			BroadcastPreChanged(Asset, EKGSLDataChangeInfo::EpisodeAdded);
			
			NewEpisode->SetEpisodeID(Asset->GenerateValidEpisodeID());
			Asset->AddDialogueEpisode(NewEpisode);
			Asset->MarkPackageDirty();
			
			BroadcastPostChanged(Asset, EKGSLDataChangeInfo::EpisodeAdded);

			SelectEpisode(Asset, NewEpisode->GetEpisodeID());
			return NewEpisode;
		}
	}
	
	return nullptr;
}

bool UKGStoryLineEditorSubSystem::RemoveEpisode(UDialogueAsset* Asset, int32 EpisodeID)
{
	check(Asset);
	if(UKGSLDialogueEpisode* Episode = Asset->GetDialogueEpisodeByEpisodeID(EpisodeID))
	{
		BroadcastPreChanged(Asset, EKGSLDataChangeInfo::EpisodeRemoved);
		Asset->RemoveDialogueEpisodeByEpisodeID(EpisodeID);
		Asset->MarkPackageDirty();
		BroadcastPostChanged(Asset, EKGSLDataChangeInfo::EpisodeRemoved);
	}
	return true;
}

void UKGStoryLineEditorSubSystem::SelectEpisode(UDialogueAsset* Asset, int32 EpisodeID)
{
	if(UKGStoryLineEditorSubSystem* This = GetPtr())
	{
		if(Asset && Asset->IsValidEpisodeID(EpisodeID))
		{
			Asset->SetCurrentSelectEpisodeID(EpisodeID);
			if(This->Listeners.Contains(EKGSLDataChangeInfo::EpisodeSelected))
			{
				auto& SetListeners = This->Listeners[EKGSLDataChangeInfo::EpisodeSelected];
				for(auto& Listener : SetListeners)
				{
					Listener->OnEpisodeSelectionChanged(Asset, EpisodeID);
				}
			}
		}		
	}
}

void UKGStoryLineEditorSubSystem::OnAssetRemoved(const FAssetData& InAssetData)
{
	if (!InAssetData.IsInstanceOf(UDialogueBaseAsset::StaticClass()))
	{
		return;
	}

	IFileManager& FileManager = IFileManager::Get();

	FString Path = FPaths::ProjectContentDir() + TEXT("Script/Data/Config/Dialogue/");
	Path = FPaths::ConvertRelativePathToFull(Path);

	FString AssetName = InAssetData.AssetName.ToString();
	FString FileName = Path + AssetName + TEXT(".lua");

	if (USourceControlHelpers::MarkFileForDelete(FileName, true))
	{
		UE_LOG(LogTemp, Log, TEXT("remove dialogue file %s, delete lua file success"), *AssetName);
	}
	else
	{
		UE_LOG(LogTemp, Log, TEXT("remove dialogue file %s, delete lua file failed"), *AssetName);
	}
}

