#include "DialogueEditor/DialogueEditorSettings.h"

namespace
{
	constexpr int32 DialogueHistoryMaxNum = 30;
}

FString UDialogueEditorSettings::GetWWiseEventsAbsPath() const
{
    FString AbsPath;
    FPackageName::TryConvertLongPackageNameToFilename(WWiseEvents.Path, AbsPath);
    AbsPath = FPaths::ConvertRelativePathToFull(AbsPath);
    return AbsPath;
}

#if WITH_EDITOR

void UDialogueEditorSettings::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
    if (PropertyChangedEvent.Property != nullptr)
    {
        const FName PropertyName = PropertyChangedEvent.GetMemberPropertyName();

        if (PropertyName == GET_MEMBER_NAME_CHECKED(UDialogueEditorSettings, WWiseEvents))
        {
           FString& Path = WWiseEvents.Path;
            if (Path.Len() > 0)
            {
                FPackageName::TryConvertFilenameToLongPackageName(Path, Path);
            }
        }
    }

    Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UDialogueEditorPerProjectUserSettings::AddHistoryAsset(const FString& AssetName)
{
	if (HistoryAssets.Contains(AssetName))
	{
		HistoryAssets.Remove(AssetName);
	}
	if (HistoryAssets.Num() >= DialogueHistoryMaxNum)
	{
		HistoryAssets.RemoveAt(0);
	}
	HistoryAssets.Add(AssetName);
	SaveConfig();
}

#endif
