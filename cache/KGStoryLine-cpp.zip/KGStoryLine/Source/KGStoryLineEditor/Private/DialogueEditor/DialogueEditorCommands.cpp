#include "DialogueEditor/DialogueEditorCommands.h"
#include "DialogueEditor/DialogueEditorSettings.h"



#define LOCTEXT_NAMESPACE "FDialogueEditorCommands"



void FDialogueEditorCommands::RegisterCommands()
{
	UDialogueEditorSettings* DialogueEditorSettings = GetMutableDefault<UDialogueEditorSettings>();
	if(DialogueEditorSettings->bShowPreviewViewport)
	{
		UI_COMMAND(Play, "Play", "Play Ability.", EUserInterfaceActionType::Button, FInputChord(EKeys::SpaceBar));
	}
	
	// UI_COMMAND(AddEpisode, "AddEpisode", "Add a new episode in this asset.", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(PlayBigworld, "PlayBigworld", "Play Ability.", EUserInterfaceActionType::Button, FInputChord(EKeys::SpaceBar));
	UI_COMMAND(Stop, "Stop", "Stop Ability.", EUserInterfaceActionType::Button, FInputChord());
	//UI_COMMAND(ForwardStep, "ForwardStep", "Forward Step.", EUserInterfaceActionType::Button, FInputChord(EKeys::D));
	//UI_COMMAND(BackwardStep, "BackwardStep", "Backward Step.", EUserInterfaceActionType::Button, FInputChord(EKeys::A));
	UI_COMMAND(Generate, "Generate", "Generate Dialogue.", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(Import, "Import", "Import Dialogue Data.", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(SyncTemplate, "SyncTemplate", "SyncTemplate Track Info From Template", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(SaveAsTemplate, "SaveAsTemplate", "Save This Asset Actors And Cameras As Template", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(CheckInValidAsset, "CheckInValidAsset", "Check Dialogue Asset That Does Not Exist In Excel Anymore", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(Copy, "Copy Track Or Section", "Copy Track Or Section", EUserInterfaceActionType::Button, FInputChord(EModifierKey::Control , EKeys::C));
	UI_COMMAND(Paste, "Paste Track Or Section", "Paste Track Or Section", EUserInterfaceActionType::Button, FInputChord(EModifierKey::Control , EKeys::V));
	UI_COMMAND(Delete, "Delete Track Or Section", "Delete Track Or Section", EUserInterfaceActionType::Button, FInputChord(EKeys::Delete));
	UI_COMMAND(Audio2FaceAutoMatch, "Audio2FaceAutoMatch", "Audio2FaceAutoMatch", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(CreateAutoCuts, "CreateAutoCuts", "CreateAutoCuts", EUserInterfaceActionType::Button, FInputChord());
}



#undef LOCTEXT_NAMESPACE