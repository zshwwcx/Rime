#include "DialogueEditor/DialogueAssetBrowser.h"

#include "DialogueEditor/DialogueEditorLuaGameInstance.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "Editor.h"
#include "KGStoryLineEditorModule.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "Engine/Blueprint.h"
#include "Engine/BlueprintGeneratedClass.h"
#include "DialogueEditor/Widgets/AssetBrowser/SDialogueAssetBrowser.h"
#include "Framework/Application/SlateApplication.h"
#include "HAL/PlatformFileManager.h"
#include "Misc/MessageDialog.h"
#include "Widgets/Input/SButton.h"

#define LOCTEXT_NAMESPACE "DialogueAssetBrowser"

FDialogueAssetBrowser::FDialogueAssetBrowser()
{
	LoadAllDialogueBPClasses();
}

FDialogueAssetBrowser::~FDialogueAssetBrowser()
{
	if (DialogueRootPackage.IsValid())
	{
		DialogueRootPackage->RemoveFromRoot();
		DialogueRootPackage.Reset();
	}
	for (int32 i = 0; i < DialogueBPClasses.Num(); i++)
	{
		if (DialogueBPClasses[i].IsValid())
		{
			DialogueBPClasses[i]->RemoveFromRoot();
		}
	}
	DialogueBPClasses.Empty();
}

void FDialogueAssetBrowser::LoadAllDialogueBPClasses()
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	TArray<FAssetData> BlueprintList;
	FARFilter Filter;
	Filter.PackagePaths.Add("/Game/Blueprint/DialogueSystem/Track");
	Filter.PackagePaths.Add("/Game/Blueprint/DialogueSystem/Section");
	Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
	Filter.ClassPaths.Add(UBlueprintGeneratedClass::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	AssetRegistryModule.Get().GetAssets(Filter, BlueprintList);
	for (int32 i = 0; i < BlueprintList.Num(); i++)
	{
		if (UBlueprint* Blueprint = Cast<UBlueprint>(BlueprintList[i].GetAsset()))
		{
			UClass* CurClass = Blueprint->GeneratedClass;
			if (CurClass->IsChildOf(UDialogueTrackBase::StaticClass()) || CurClass->IsChildOf(UDialogueActionBase::StaticClass()))
			{
				CurClass->AddToRoot();
				DialogueBPClasses.Add(CurClass);
			}
		}
	}
}

TWeakObjectPtr<UObject> FDialogueAssetBrowser::GetDialogueRootPackage()
{
	if (!DialogueRootPackage.IsValid())
	{
		FString PackageName = TEXT("/Temp/DialogueTransientPackage");
		DialogueRootPackage = CreatePackage(*PackageName);
		DialogueRootPackage->AddToRoot();
	}
	return DialogueRootPackage;
}

void FDialogueAssetBrowser::OpenDialogueAssetBrowser()
{
	if (!FKGStoryLineEditorModule::CanTypeOfAssetOpen(UDialogueAsset::StaticClass()))
		return;
	
	if (!DialogueRootPackage.IsValid())
	{
		FString PackageName = TEXT("/Temp/DialogueTransientPackage");
		DialogueRootPackage = CreatePackage(*PackageName);
		DialogueRootPackage->AddToRoot();
	}
	CloseDialogueAssetListWindow();
	DialogueAssetBrowserWindow = SNew(SWindow)
		.Title(LOCTEXT("DialogueAssetBrowserWindow", "对话资产浏览器"))
		.ClientSize(FVector2D(800, 1000));

	TSharedPtr<SVerticalBox> VerticalBox = SNew(SVerticalBox);

	VerticalBox->AddSlot()
		.FillHeight(0.95)
	[
		SAssignNew(DialogueAssetBrowse, SDialogueAssetBrowser)
		.OnOpenDialogueByDoubleClick(this, &FDialogueAssetBrowser::OnOpenDialogueByDoubleClick)
		.OnCreateDialogueByDoubleClick(this, &FDialogueAssetBrowser::OnOpenDialogueByDoubleClick)
	];

	DialogueAssetBrowserWindow->SetContent(VerticalBox.ToSharedRef());
	FSlateApplication::Get().AddWindow(DialogueAssetBrowserWindow.ToSharedRef());
}

void FDialogueAssetBrowser::CloseDialogueAssetListWindow()
{
	if (DialogueAssetBrowserWindow.IsValid())
	{
		DialogueAssetBrowserWindow->RequestDestroyWindow();
		DialogueAssetBrowserWindow.Reset();
	}
}

void FDialogueAssetBrowser::OnOpenDialogueByDoubleClick()
{
	// CloseDialogueAssetListWindow();
}

void FDialogueAssetBrowser::OnCreateDialogueByDoubleClick()
{
	CloseDialogueAssetListWindow();
}

void FDialogueAssetBrowser::GetDialogueAssetList(TArray<TSharedPtr<IDialogueAssetViewItem>>& OutAssetViewItems)
{
	
}

#undef LOCTEXT_NAMESPACE