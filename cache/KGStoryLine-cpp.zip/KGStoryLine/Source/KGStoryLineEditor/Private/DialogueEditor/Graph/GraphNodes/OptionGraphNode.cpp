#include "DialogueEditor/Graph/GraphNodes/OptionGraphNode.h"
#include "EdGraph/EdGraphNode.h"
#include "EdGraph/EdGraph.h"

UOptionGraphNode::UOptionGraphNode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UOptionGraphNode::AllocateDefaultPins()
{
	InputPin1 = CreatePin(EEdGraphPinDirection::EGPD_Input, TEXT("yaoyao"), TEXT("Condition1"));
	InputPin2 = CreatePin(EEdGraphPinDirection::EGPD_Input, TEXT("yaoyao"), TEXT("Condition2"));
	InputPins.Emplace(InputPin1);
	InputPins.Emplace(InputPin2);
	ResultPin = CreatePin(EEdGraphPinDirection::EGPD_Output, TEXT("yaoyao"), TEXT("Result"));
	OutputPin = CreatePin(EEdGraphPinDirection::EGPD_Output, TEXT("yaoyao"), TEXT("ExtraAction"));
	OutputPins.Emplace(OutputPin);
}

UEdGraphPin* UOptionGraphNode::GetInputPin1() const
{
	return InputPin1;
}

UEdGraphPin* UOptionGraphNode::GetInputPin2() const
{
	return InputPin2;
}

UEdGraphPin* UOptionGraphNode::GetResultPin() const
{
	return ResultPin;
}

UEdGraphPin* UOptionGraphNode::GetOutputPin() const
{
	return OutputPin;
}

FText UOptionGraphNode::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return FText::FromString(TEXT("AND"));
}

bool UOptionGraphNode::CanUserDeleteNode() const
{
	return true;
}

UEdGraphPin* UOptionGraphNode::AddConditionPin()
{
	//向Graph中添加一个Pin
	UEdGraphPin* NewPin = CreatePin(EEdGraphPinDirection::EGPD_Input, TEXT("yaoyao"), FName(*FString::Printf(TEXT("Condition"), InputPins.Num() + 1)));
	InputPins.Emplace(NewPin);
	GetGraph()->NotifyGraphChanged();
	return NewPin;
}

void UOptionGraphNode::RemoveConditionPin(const UEdGraphPin* Pin)
{
	UEdGraphPin* GraphPin = const_cast<UEdGraphPin*>(Pin);
	InputPins.Remove(GraphPin);
	RemovePin(GraphPin);
	GetGraph()->NotifyGraphChanged();
}

UEdGraphPin* UOptionGraphNode::AddActionPin()
{
	//向Graph中添加一个Pin
	UEdGraphPin* NewPin = CreatePin(EEdGraphPinDirection::EGPD_Output, TEXT("yaoyao"), FName(*FString::Printf(TEXT("ExtraAction"), OutputPins.Num())));
	OutputPins.Emplace(NewPin);
	GetGraph()->NotifyGraphChanged();
	return NewPin;;
}

void UOptionGraphNode::RemoveActionPin(const UEdGraphPin* Pin)
{
	UEdGraphPin* GraphPin = const_cast<UEdGraphPin*>(Pin);
	OutputPins.Remove(GraphPin);
	RemovePin(GraphPin);
	GetGraph()->NotifyGraphChanged();
}

UOptionGraphNoParamNode::UOptionGraphNoParamNode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UOptionGraphNoParamNode::AllocateDefaultPins()
{
	OutputPin = CreatePin(EEdGraphPinDirection::EGPD_Output, TEXT("yaoyao"), TEXT("result"));
}

UEdGraphPin* UOptionGraphNoParamNode::GetOutputPin() const
{
	return OutputPin;
}

FText UOptionGraphNoParamNode::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return FText::FromString(Title);
}

bool UOptionGraphNoParamNode::CanUserDeleteNode() const
{
	return true;
}

FString UOptionGraphNoParamNode::ToString()
{
	return ConditionName;
	
}

UOptionGraphOneParamNode::UOptionGraphOneParamNode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FString UOptionGraphOneParamNode::ToString()
{
	TStringBuilder<256> sb;
	sb.Reset();
	sb.Append(ConditionName);
	sb.Append(TEXT(":"));
	sb.Append(FString::FromInt(Param));
	return sb.ToString();
}

UOptionGraphActionNoParamNode::UOptionGraphActionNoParamNode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UOptionGraphActionNoParamNode::AllocateDefaultPins()
{
	InputPin = CreatePin(EEdGraphPinDirection::EGPD_Input, TEXT("yaoyao"), TEXT(""));
}

UEdGraphPin* UOptionGraphActionNoParamNode::GetInputPin() const
{
	return InputPin;
}

FText UOptionGraphActionNoParamNode::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return FText::FromString(Title);
}

bool UOptionGraphActionNoParamNode::CanUserDeleteNode() const
{
	return true;
}

FString UOptionGraphActionNoParamNode::ToString()
{
	return ConditionName;
}

UOptionGraphActionOneParamNode::UOptionGraphActionOneParamNode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FString UOptionGraphActionOneParamNode::ToString()
{
	TStringBuilder<256> sb;
	sb.Reset();
	sb.Append(ConditionName);
	sb.Append(TEXT("$"));
	sb.Append(FString::FromInt(Param));
	return sb.ToString();
}

UOptionGraphActionMultiParamNode::UOptionGraphActionMultiParamNode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FString UOptionGraphActionMultiParamNode::ToString()
{
	TStringBuilder<256> sb;
	sb.Reset();
	sb.Append(ConditionName);
	for(int Idx = 0; Idx < Params.Num(); Idx++)
	{
		sb.Append(TEXT("$"));
		sb.Append(Params[Idx]);
	}
	
	return sb.ToString();
}

UOptionGraphJumpNode::UOptionGraphJumpNode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UOptionGraphJumpNode::AllocateDefaultPins()
{
	InputPin = CreatePin(EEdGraphPinDirection::EGPD_Input, TEXT("yaoyao"), TEXT(""));
}

UEdGraphPin* UOptionGraphJumpNode::GetInputPin() const
{
	return InputPin;
}

FText UOptionGraphJumpNode::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return FText::FromString(TEXT("Jump"));
}

bool UOptionGraphJumpNode::CanUserDeleteNode() const
{
	return true;
}

FString UOptionGraphJumpNode::ToString()
{
	TStringBuilder<256> sb;
	sb.Reset();
	for (int Idx = 0; Idx < Params.Num(); Idx++)
	{
		sb.Append(TEXT("$"));
		sb.Append(FString::FromInt(Params[Idx]));
	}
		
	return sb.ToString();
}
