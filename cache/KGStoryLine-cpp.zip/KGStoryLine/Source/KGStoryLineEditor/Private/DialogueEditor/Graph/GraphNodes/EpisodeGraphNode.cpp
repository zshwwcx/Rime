// Copyright 2020 Kuai, Inc. All Rights Reserved.

#include "DialogueEditor/Graph/GraphNodes/EpisodeGraphNode.h"

#include "DialogueEditor/KGStoryLineEditorSubSystem.h"
#include "DialogueEditor/Graph/EpisodeGraph.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "EdGraph/EdGraphPin.h"

void UEpisodeGraphEntryNode::AllocateDefaultPins()
{
	OutputPin = CreatePin(EEdGraphPinDirection::EGPD_Output, NAME_None, NAME_None, NAME_None);
}

bool UEpisodeGraphEntryNode::CanUserDeleteNode() const
{
	return false;
}

FLinearColor UEpisodeGraphEntryNode::GetNodeTitleColor() const
{
	return FLinearColor::Red;
}

void UEpisodeGraphEntryNode::PinConnectionListChanged(UEdGraphPin* Pin)
{
	UDialogueAsset* DialogueAsset = GetDialogueAsset();

	if (Pin->LinkedTo.Num() > 0)
	{//连接
		if (UEpisodeGraphNode* EpisodeGraphNode = Cast<UEpisodeGraphNode>(Pin->LinkedTo[0]->GetOwningNode()))
		{
			for (int i = 0; i < DialogueAsset->EpisodesList.Num(); ++i)
			{
				if (DialogueAsset->EpisodesList[i]->GetEpisodeID() == EpisodeGraphNode->GetEpisodeID())
				{
					DialogueAsset->EpisodesList.Swap(0, i);
					break;
				}
			}
		}
	}
	else
	{//断开
	}
}

class UDialogueAsset* UEpisodeGraphEntryNode::GetDialogueAsset()
{
	UEpisodeGraph* EpisodeGraph = Cast<UEpisodeGraph>(GetOuter());
	return EpisodeGraph->GetDialogueAsset();
}

void UEpisodeGraphNode::AllocateDefaultPins()
{
	InputPin = CreatePin(EEdGraphPinDirection::EGPD_Input, NAME_None, NAME_None, NAME_None);

	/*下面代码不需要了，原因如下
	* 如果是手动在Graph里面添加的，则此时DialogueAsset里面还没有对应的EpisodeLines->Options数据，不需要处理
	* 如果是从外部导入的，则在导入的时候直接循环的时候就处理掉，这里不必再内部搞一个循环
	UDialogueAsset* DialogueAsset = GetDialogueAsset();
	for (int i = 0; i < DialogueAsset->EpisodeLinesContainer.EpisodeLines.Num(); ++i)
	{
		const FDialogueEpisodeLines& Element = DialogueAsset->EpisodeLinesContainer.EpisodeLines[i];
		if (Element.EpisodeID == EpisodeID)
		{
			for (const FDialogueOption& OptionInfo : Element.Options)
			{
				CreatePin(EEdGraphPinDirection::EGPD_Output, NAME_None, NAME_None, NAME_None);
			}
			break;
		}
	}
	*/
}

void UEpisodeGraphNode::DestroyNode()
{
	if(UDialogueAsset* DialogueAsset = GetDialogueAsset())
	{
		int32 EpisodeIDRemoved = EpisodeID;
		if(IsValid(OwnerDialogueEpisode))
		{
			EpisodeIDRemoved = OwnerDialogueEpisode->GetEpisodeID();
		}
		UKGStoryLineEditorSubSystem::RemoveEpisode(DialogueAsset, EpisodeIDRemoved);
	}
}

void UEpisodeGraphNode::PostLoad()
{
	UEdGraphNode::PostLoad();
}

class UDialogueAsset* UEpisodeGraphNode::GetDialogueAsset()
{
	UEpisodeGraph* EpisodeGraph =  Cast<UEpisodeGraph>(GetOuter());
	return EpisodeGraph->GetDialogueAsset();
}

UEdGraphPin* UEpisodeGraphNode::AddOptionPin()
{
	//向Graph中添加一个Pin
	UEdGraphPin* NewPin = CreatePin(EEdGraphPinDirection::EGPD_Output, "exec", NAME_None, NAME_None);
	GetGraph()->NotifyGraphChanged();

	return NewPin;
}

void UEpisodeGraphNode::RemoveOptionPin(const UEdGraphPin* Pin)
{
	if(UDialogueAsset* DialogueAsset = GetDialogueAsset())
	{
		DialogueAsset->RemoveDialogueEpisodeOption(EpisodeID, Pin->PinId);
		RemovePin(const_cast<UEdGraphPin*>(Pin));
		GetGraph()->NotifyGraphChanged();
	}
}

void UEpisodeGraphNode::SetOwnerDialogueEpisode(UKGSLDialogueEpisode* InOwner)
{
	if(IsValid(InOwner) && InOwner != OwnerDialogueEpisode)
	{
		OwnerDialogueEpisode = InOwner;
		EpisodeID = InOwner->GetEpisodeID();
	}
}

UKGSLDialogueEpisode* UEpisodeGraphNode::GetOwnerDialogueEpisode()
{
	return OwnerDialogueEpisode;
}

FLinearColor UEpisodeGraphNode::GetNodeTitleColor() const
{
	return FLinearColor::Green;
}

FText UEpisodeGraphNode::GetPinNameOverride(const UEdGraphPin& Pin) const
{
	if (Pin.Direction == EEdGraphPinDirection::EGPD_Input)
		return FText::GetEmpty();

	UEpisodeGraphNode* MutableThis = const_cast<UEpisodeGraphNode*>(this);

	if (UDialogueAsset* DialogueAsset = MutableThis->GetDialogueAsset())
	{
		if (UKGSLDialogueEpisode* EpisodeLines = DialogueAsset->GetDialogueEpisodeByEpisodeID(EpisodeID))
		{
			for (const UKGSLDialogueOption* Option : EpisodeLines->Options)
			{
				if (Option->PinId == Pin.PinId)
				{
					return FText::FromString(Option->DialogueText);
				}
			}
		}
	}
	return FText::FromString(TEXT("Next"));
}

FText UEpisodeGraphNode::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	UEpisodeGraphNode* MutableThis = const_cast<UEpisodeGraphNode*>(this);
	if(!IsValid(OwnerDialogueEpisode))
	{
		if(KGStoryLine::IsValidEpisodeID(EpisodeID))
		{
			if(UDialogueAsset* Asset = MutableThis->GetDialogueAsset())
			{
				MutableThis->SetOwnerDialogueEpisode(Asset->GetDialogueEpisodeByEpisodeID(EpisodeID));
			}
		}
	}
	
	if(IsValid(OwnerDialogueEpisode))
	{
		MutableThis->EpisodeID =  OwnerDialogueEpisode->GetEpisodeID();
	}
	
	return FText::FromString(FString::Printf(TEXT("%s(%d)"), *GetClass()->GetName(), EpisodeID));
}

void UEpisodeGraphNode::PinConnectionListChanged(UEdGraphPin* Pin)
{
	UDialogueAsset* DialogueAsset = GetDialogueAsset();

	UKGSLDialogueEpisode* EpisodeLine = DialogueAsset->GetDialogueEpisodeByEpisodeID(EpisodeID);
	if (Pin->Direction == EEdGraphPinDirection::EGPD_Input)
	{
	}
	else if (Pin->Direction == EEdGraphPinDirection::EGPD_Output)
	{
		if (Pin->LinkedTo.Num() > 0)
		{//连接
			UEpisodeGraphNode* EpisodeNode = Cast<UEpisodeGraphNode>(Pin->LinkedTo[0]->GetOwningNode());
			//Output只能连接1个，因此我们这里取第1个
			for (UKGSLDialogueOption* Option : EpisodeLine->Options)
			{
				if (Option->PinId == Pin->PinId)
				{//找到改变状态的这个Pin对应的Option
					Option->EpisodeID = EpisodeNode->EpisodeID;
					//通知CurrentSelectNode改变，否则CurrentSelectNode的数据不会变更，因此这里本质修改的是EpisodeLine数据
					//暂时注释掉，因为这里改的就是EpisodeLine数据，和CurrentSelectNode没有关系，且这个Option的Next EpisodeID变量也不可见
					//DialogueAsset->SetCurrentSelectEpisodeID(EpisodeID);
					break;
				}
			}
		}
		else
		{//断开
			for (UKGSLDialogueOption* Option : EpisodeLine->Options)
			{
				if (Option->PinId == Pin->PinId)
				{//找到改变状态的这个Pin对应的Option
					Option->EpisodeID = 0;
					//通知CurrentSelectNode改变，否则CurrentSelectNode的数据不会变更，因此这里本质修改的是EpisodeLine数据
					//暂时注释掉，因为这里改的就是EpisodeLine数据，和CurrentSelectNode没有关系，且这个Option的Next EpisodeID变量也不可见
					//DialogueAsset->SetCurrentSelectEpisodeID(EpisodeID);
					break;
				}
			}
		}
	}

}
