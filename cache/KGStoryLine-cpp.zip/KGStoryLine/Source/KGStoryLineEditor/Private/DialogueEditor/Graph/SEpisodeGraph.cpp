// Copyright 2020 Kuai, Inc. All Rights Reserved.

#include "DialogueEditor/Graph/SEpisodeGraph.h"
#include "DialogueEditor/Graph/EpisodeGraph.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Graph/EpisodeGraphSchema.h"
#include "ScopedTransaction.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Framework/Commands/GenericCommands.h"
#include "DialogueEditor/Graph/GraphNodes/EpisodeGraphNode.h"
#include "Misc/MessageDialog.h"
#include "DialogueEditor/DialogueEditorSettings.h"


#define LOCTEXT_NAMESPACE "LevelFlowEditor_Graph"


SEpisodeGraph::SEpisodeGraph()
: INotifyOnKGSLDataChanged(EKGSLDataChangeInfo::EpisodeAdded, EKGSLDataChangeInfo::EpisodeSelected,
                           EKGSLDataChangeInfo::EpisodeRemoved)
{
}

void SEpisodeGraph::Construct(const FArguments& InArgs, TSharedPtr<class FDialogueEditor> Editor)
{
    HostEditor = Editor;
    Editor->GetDialogueReConstructGraph().AddRaw(this, &SEpisodeGraph::OnDialogueConstructGraph);
    //Editor->GetDialogueConnectGraph().AddRaw(this, &SEpisodeGraph::OnDialogueConstructGraph);

    // Build graph
    UDialogueBaseAsset* BaseAsset = Editor->GetEditingAsset();
    if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(BaseAsset))
    {
        UEpisodeGraph* EpisodeGraph = Cast<UEpisodeGraph>(DialogueAsset->EpisodeGraph);
        if (EpisodeGraph == nullptr)
        {
            DialogueAsset->EpisodeGraph = FBlueprintEditorUtils::CreateNewGraph(
                DialogueAsset, TEXT("EpisodeGraph"), UEpisodeGraph::StaticClass(), UEpisodeGraphSchema::StaticClass());

            const UEdGraphSchema* Schema = DialogueAsset->EpisodeGraph->GetSchema();
            //Schema->CreateDefaultNodesForGraph(*LevelFlowGraph);

            EpisodeGraph = Cast<UEpisodeGraph>(DialogueAsset->EpisodeGraph);
            EpisodeGraph->OnCreated();
        }
        else
        {
            EpisodeGraph->OnLoaded();
        }
        GraphObject = Cast<UEpisodeGraph>(DialogueAsset->EpisodeGraph);
        //默认选中第1个
        DialogueAsset->SetCurrentSelectEpisodeID(DialogueAsset->Episodes[0].EpisodeID);
    }


    CreateCommandList();

    // Create the graph editor
    GraphEditor = CreateGraphEditor();

    ChildSlot
    [
        SAssignNew(GraphContainer, SVerticalBox)
        + SVerticalBox::Slot()
        .FillHeight(1.f)
        [
            GraphEditor.ToSharedRef()
        ]
    ];

	OnDialogueConstructGraph();
}

SEpisodeGraph::~SEpisodeGraph()
{
}

void SEpisodeGraph::PreChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType)
{
}

void SEpisodeGraph::PostChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType)
{
    if (GraphObject.IsValid() && IsValid(GraphObject.Get()) && GraphObject->GetOuter() == Changed)
    {
        switch (ChangedType)
        {
        case EKGSLDataChangeInfo::EpisodeAdded:
            GraphObject->OnEpisodeAdded();
            break;
        case EKGSLDataChangeInfo::EpisodeRemoved:
            GraphObject->OnEpisodeRemoved();
            break;
        default:
            break;
        }

        if (GraphEditor.IsValid())
        {
            for (auto Node : GraphObject->Nodes)
            {
                GraphEditor->RefreshNode(*Node.Get());
            }
        }
    }
}

TSharedPtr<SGraphEditor> SEpisodeGraph::CreateGraphEditor()
{
    FGraphAppearanceInfo AppearanceInfo;
    AppearanceInfo.CornerText = LOCTEXT("AppearanceCornerText_LevelFlow", "EpisodeGraph");

    SGraphEditor::FGraphEditorEvents GraphEvents;
    GraphEvents.OnSelectionChanged = SGraphEditor::FOnSelectionChanged::CreateSP(
        this, &SEpisodeGraph::HandleSelectionChanged);
    /*
    GraphEvents.OnNodeDoubleClicked = FSingleNodeEvent::CreateSP(this, &SLevelFlowGraph::HandleNodeDoubleClicked);
    GraphEvents.OnDropActor = SGraphEditor::FOnDropActor::CreateSP(this, &SLevelFlowGraph::DroppedActorsOnGraph);
    GraphEvents.OnTextCommitted = FOnNodeTextCommitted::CreateSP(this, &SLevelFlowGraph::OnNodeTitleCommitted);
    */

    // Create the graph editor
    return SNew(SGraphEditor)
        .GraphToEdit(GraphObject.Get())
        .GraphEvents(GraphEvents)
        .Appearance(AppearanceInfo)
        .AdditionalCommands(GraphEditorCommands)
        .ShowGraphStateOverlay(false);
}

void SEpisodeGraph::HandleSelectionChanged(const FGraphPanelSelectionSet& SelectionSet)
{
    UDialogueBaseAsset* BaseAsset = HostEditor.Pin()->GetEditingAsset();

    if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(BaseAsset))
    {
        for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectionSet); NodeIt; ++NodeIt)
        {
            if (UEpisodeGraphNode* EpisodeNode = Cast<UEpisodeGraphNode>(*NodeIt))
            {
                HostEditor.Pin()->SetCurrentSelectEpisode(EpisodeNode->GetEpisodeID());
                break;
            }
            if (UEpisodeGraphEntryNode* EpisodeNode = Cast<UEpisodeGraphEntryNode>(*NodeIt))
            {
                //选中EntryNode,不作处理
                break;
            }
        }
    }
}

void SEpisodeGraph::DeleteSelectedNodes()
{
    if (!GraphEditor.IsValid())
    {
        return;
    }

    const FScopedTransaction Transaction(FGenericCommands::Get().Delete->GetDescription());
    GraphEditor->GetCurrentGraph()->Modify();

    const FGraphPanelSelectionSet SelectedNodes = GraphEditor->GetSelectedNodes();
    GraphEditor->ClearSelectionSet();

    const UEpisodeGraphSchema* Schema = Cast<UEpisodeGraphSchema>(GraphObject->GetSchema());
    for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
    {
        if (UEdGraphNode* Node = Cast<UEdGraphNode>(*NodeIt))
        {
            Schema->SafeDeleteNodeFromGraph(GraphEditor->GetCurrentGraph(), Node);
        }
    }
}

bool SEpisodeGraph::CanDeleteNodes() const
{
	return false;
	/*
    const FGraphPanelSelectionSet SelectedNodes = GraphEditor->GetSelectedNodes();

    int EpisodeNodeCount = 0;
    for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
    {
        if (UEpisodeGraphEntryNode* Node = Cast<UEpisodeGraphEntryNode>(*NodeIt))
        {
            //不允许删除EntryNode
            return false;
        }
        if (UEpisodeGraphNode* Node = Cast<UEpisodeGraphNode>(*NodeIt))
        {
            ++EpisodeNodeCount;
        }
    }

    UEpisodeGraph* EpisodeGraph = Cast<UEpisodeGraph>(GraphEditor->GetCurrentGraph());

    //如果要删除的EpisodeNode恰好是全部的EpisodeNode，禁止，必须保留1个默认的EpisodeNode
    if (EpisodeGraph->GetEpisodeNodes().Num() == EpisodeNodeCount)
        return false;
    return true;
	*/
}

void SEpisodeGraph::OnDialogueConstructGraph()
{
	UDialogueAsset* DialogueAsset = HostEditor.Pin()->GetDialogueAsset();
	if (!DialogueAsset)
	{
		return;
	}
	
    UEpisodeGraph* EpisodeGraph = Cast<UEpisodeGraph>(GraphEditor->GetCurrentGraph());
	if (!EpisodeGraph)
	{
		return;
	}

    //从外部导入对话数据后，需要将原来的EpisodeNode清空掉
    TArray<UEdGraphNode*> WaitDeleteNodes;
    for (UEdGraphNode* EpisodeNode : EpisodeGraph->Nodes)
    {
        if (UEpisodeGraphNode* EpisodeGraphNode = Cast<UEpisodeGraphNode>(EpisodeNode))
        {
            //只删除Episode节点，不删除EntryNode
            WaitDeleteNodes.Add(EpisodeNode);
        }
    }
    for (UEdGraphNode* WaitDeleteNode : WaitDeleteNodes)
    {
        EpisodeGraph->RemoveNode(WaitDeleteNode);
    }
	
    TMap<int32, UEpisodeGraphNode*> EpisodeNodesMap; //记录一下EpisodeID->UEdGraphNode*，方便后续连接处理
    //根据DialogueAsset里面的EpisodeLines重建Nodes
    for (UKGSLDialogueEpisode* Episode : DialogueAsset->EpisodesList)
    {
        //先向Graph里面添加一个NewNode
        UEpisodeGraphNode* ResultNode = EpisodeGraph->CreateEpisodeNode(nullptr, false, FVector2D(0, 0));
        ResultNode->SetOwnerDialogueEpisode(Episode);
        EpisodeNodesMap.Add(ResultNode->GetEpisodeID(), ResultNode);
        for (UKGSLDialogueOption* Option : Episode->Options)
        {
            UEdGraphPin* OptionPin = ResultNode->AddOptionPin();
            Option->PinId = OptionPin->PinId;
        }
    }
    ConnectEpisodeNodes();
}

void SEpisodeGraph::CreateCommandList()
{
    if (GraphEditorCommands.IsValid())
    {
        return;
    }

    GraphEditorCommands = MakeShareable(new FUICommandList);

	/*
    GraphEditorCommands->MapAction(
        FGenericCommands::Get().Delete,
        FExecuteAction::CreateRaw(this, &SEpisodeGraph::DeleteSelectedNodes),
        FCanExecuteAction::CreateRaw(this, &SEpisodeGraph::CanDeleteNodes));
	
    GraphEditorCommands->MapAction(
        FGenericCommands::Get().Copy,
        FExecuteAction::CreateRaw(this, &SLevelFlowGraph::CopySelectedNodes),
        FCanExecuteAction::CreateRaw(this, &SLevelFlowGraph::CanCopyNodes));

    GraphEditorCommands->MapAction(
        FGenericCommands::Get().Paste,
        FExecuteAction::CreateRaw(this, &SLevelFlowGraph::PasteSelectedNodes),
        FCanExecuteAction::CreateRaw(this, &SLevelFlowGraph::CanPasteNodes));

    GraphEditorCommands->MapAction(
        FGraphEditorCommands::Get().CreateComment,
        FExecuteAction::CreateRaw(this, &SLevelFlowGraph::OnCreateComment),
        FCanExecuteAction::CreateRaw(this, &SLevelFlowGraph::CanCreateComment)
    );
    */
}

void SEpisodeGraph::ConnectEpisodeNodes()
{
    UEpisodeGraph* EpisodeGraph = Cast<UEpisodeGraph>(GraphEditor->GetCurrentGraph());
    UDialogueAsset* DialogueAsset = HostEditor.Pin()->GetDialogueAsset();

    //重建Nodes完成后，将Nodes进行连接
    int Index = 0;
    for (UEdGraphNode* EpisodeNode : EpisodeGraph->Nodes)
    {
        if (UEpisodeGraphNode* EpisodeGraphNode = Cast<UEpisodeGraphNode>(EpisodeNode))
        {
            if (Index++ == 0)
            {
                //第1个Episode，说明应该和EntryNode连接
                //EntryNode永远是Graph里面的第1个节点
                UEdGraphNode* EntryNode = EpisodeGraph->Nodes[0];
                EpisodeGraph->GetSchema()->TryCreateConnection(EntryNode->Pins[0], EpisodeGraphNode->InputPin);
                EpisodeGraphNode->NodePosX = EntryNode->NodePosX + 300;
                EpisodeGraphNode->NodePosY = EntryNode->NodePosY;
            }

            //处理它和后续节点的关系
            UKGSLDialogueEpisode* EpisodeLines = DialogueAsset->GetDialogueEpisodeByEpisodeID(
                EpisodeGraphNode->GetEpisodeID());

            int32 OptionIndex = 0;
            for (UKGSLDialogueOption* Option : EpisodeLines->Options)
            {
                bool FindNode = false;
                for (auto GraphNode : EpisodeGraph->Nodes)
                {
                    if (UEpisodeGraphNode* NodeValue = Cast<UEpisodeGraphNode>(GraphNode))
                    {
                        if (NodeValue->GetEpisodeID() == Option->EpisodeID)
                        {
                            UEpisodeGraphNode* PinNextNode = NodeValue;

                            //注意，也许多个Option连接同一个Node，这是合法的
                            UEdGraphPin* Pin = EpisodeGraphNode->FindPinById(Option->PinId);
                            EpisodeGraph->GetSchema()->TryCreateConnection(Pin, PinNextNode->InputPin);
                            PinNextNode->NodePosX = EpisodeGraphNode->NodePosX + 300;
                            PinNextNode->NodePosY = EpisodeGraphNode->NodePosY + 150 * OptionIndex++;
                            FindNode = true;
                            break;
                        }
                    }
                }
                if (!FindNode)
                {
                    // 没有找到这个Option连接的NextEpisode！说明什么？说明策划虽然添加了Option，但可能配置错了或者漏了NextEpisodeID！
                    // 但是0是特殊情况,可以忽略
                    if (0 != Option->EpisodeID)
                    {
                        FString Message = FString::Printf(TEXT("Episode %d的Option设置了NextEpisodeID:%d，但表格中未配置！"),
                                                          EpisodeGraphNode->GetEpisodeID(), Option->EpisodeID);
                        FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
                    }
                }
            }
        }
    }
}

#undef LOCTEXT_NAMESPACE
