// Copyright 2020 Kuai, Inc. All Rights Reserved.



#include "DialogueEditor/Graph/EpisodeGraphSchema.h"
#include "DialogueEditor/Graph/EpisodeGraph.h"
#include "DialogueEditor/Graph/GraphNodes/EpisodeGraphNode.h"
#include "Framework/Commands/GenericCommands.h"
#include "GraphEditorActions.h"
#include "DialogueEditor/KGStoryLineEditorSubSystem.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "ScopedTransaction.h"
#include "ToolMenuSection.h"
#include "ToolMenu.h"

#define LOCTEXT_NAMESPACE "EpisodeGraphSchema"


UEdGraphNode* FSchemaAction_EpisodeNewNode::PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode /*= true*/)
{
	const FScopedTransaction Transaction(FText::FromString(TEXT("DialogueTransaction Add Node")));

	UEpisodeGraph* EpisodeGraph = Cast<UEpisodeGraph>(ParentGraph);

	//先向Graph里面添加一个NewNode
	UEpisodeGraphNode* ResultNode = EpisodeGraph->CreateEpisodeNode(FromPin, bSelectNewNode, Location);
	
	//为这个NewNode赋1个EpisodeID，并加入到DialogueAsset的EpisodeLine数据中去
	if (UDialogueAsset* DialogueAsset = EpisodeGraph->GetDialogueAsset())
	{
		UKGStoryLineEditorSubSystem::AddEpisode(DialogueAsset, [ResultNode](UKGSLDialogueEpisode* InEpisode)
		{
			ResultNode->SetOwnerDialogueEpisode(InEpisode);
		});
	}

	return ResultNode;
}


void FSchemaAction_EpisodeNewNode::AddReferencedObjects(FReferenceCollector& Collector)
{
	FEdGraphSchemaAction::AddReferencedObjects(Collector);
}

void UEpisodeGraphSchema::GetGraphContextActions(FGraphContextMenuBuilder& ContextMenuBuilder) const
{
	/*
	FCategorizedGraphActionListBuilder NodesBuilder(TEXT("EpisodeGraphNodes"));

	TSharedPtr<FSchemaAction_EpisodeNewNode> NewAction(new FSchemaAction_EpisodeNewNode(FText::GetEmpty(), FText::FromString("AddEpisode"), FText::FromString("NewNodeTooltips"), 0));
	NodesBuilder.AddAction(NewAction);

	ContextMenuBuilder.Append(NodesBuilder);
	*/
}


void UEpisodeGraphSchema::GetContextMenuActions(class UToolMenu* Menu, class UGraphNodeContextMenuContext* Context) const
{
	Super::GetContextMenuActions(Menu, Context);
/*
	if (Context->Node->IsA<UEpisodeGraphNode>())
	{
		UEpisodeGraphSchema* MutableThis = const_cast<UEpisodeGraphSchema*>(this);
		if (Context->Pin && Context->Pin->Direction == EEdGraphPinDirection::EGPD_Output)
		{
			FToolMenuSection& RemomveOptionSection = Menu->AddSection("OptionSection", LOCTEXT("LOC_Option", "Option"));
			RemomveOptionSection.AddMenuEntry(TEXT("RemoveOption"),
				FText::FromString(TEXT("RemoveOption")),
				FText::FromString(TEXT("Remove This Option")),
				FSlateIcon(),
				FUIAction(FExecuteAction::CreateUObject(MutableThis, &UEpisodeGraphSchema::RemoveEpisodeOption, Context))
			);
		}
		else
		{
			FToolMenuSection& AddOptionSection = Menu->AddSection("OptionSection", LOCTEXT("LOC_Option", "Option"));
			AddOptionSection.AddMenuEntry(TEXT("AddOption"),
				FText::FromString(TEXT("AddOption")),
				FText::FromString(TEXT("Add a option for this episode")),
				FSlateIcon(),
				FUIAction(FExecuteAction::CreateUObject(MutableThis, &UEpisodeGraphSchema::AddEpisodeOption, Context))
			);

			FToolMenuSection& NodeSection = Menu->AddSection("GraphSchemaActions_Node", LOCTEXT("ClassActionsMenuHeader_Node", "Node Actions"));
			NodeSection.AddMenuEntry(FGenericCommands::Get().Delete);
			NodeSection.AddMenuEntry(FGenericCommands::Get().Cut);
			NodeSection.AddMenuEntry(FGenericCommands::Get().Copy);
			NodeSection.AddMenuEntry(FGenericCommands::Get().Duplicate);
			NodeSection.AddMenuEntry(FGraphEditorCommands::Get().BreakNodeLinks);
			NodeSection.AddMenuEntry(FGraphEditorCommands::Get().CreateComment);
		}
	}
*/
}

const FPinConnectionResponse UEpisodeGraphSchema::CanCreateConnection(const UEdGraphPin* A, const UEdGraphPin* B) const
{
	if (A == nullptr || B == nullptr)
		return FPinConnectionResponse(ECanCreateConnectionResponse::CONNECT_RESPONSE_DISALLOW, TEXT("Pin InValid!"));

	if (A->GetOwningNode() == B->GetOwningNode())
		return FPinConnectionResponse(ECanCreateConnectionResponse::CONNECT_RESPONSE_DISALLOW, TEXT("Same Node!"));

	if (A->Direction == B->Direction)
		return FPinConnectionResponse(ECanCreateConnectionResponse::CONNECT_RESPONSE_DISALLOW, TEXT("Direction InValid!"));

	const UEdGraphPin* InputPin = A->Direction == EEdGraphPinDirection::EGPD_Input ? A : B;
	const UEdGraphPin* OutputPin = InputPin == A ? B : A;

	if (A == OutputPin && A->LinkedTo.Num() != 0)
		return FPinConnectionResponse(ECanCreateConnectionResponse::CONNECT_RESPONSE_BREAK_OTHERS_A, TEXT("OutputPin Can Only Connect One Next Node"));
	if (B == OutputPin && B->LinkedTo.Num() != 0)
		return FPinConnectionResponse(ECanCreateConnectionResponse::CONNECT_RESPONSE_BREAK_OTHERS_B, TEXT("OutputPin Can Only Connect One Next Node"));

	return FPinConnectionResponse(ECanCreateConnectionResponse::CONNECT_RESPONSE_MAKE, TEXT("Other"));

}

bool UEpisodeGraphSchema::SafeDeleteNodeFromGraph(UEdGraph* Graph, UEdGraphNode* Node) const
{
	check(Node);

	if (Node->CanUserDeleteNode())
	{
		Node->Modify();
		Node->DestroyNode();
	}

	return true;
}


FText UEpisodeGraphSchema::GetPinDisplayName(const UEdGraphPin* Pin) const
{
	FText DisplayName = FText::GetEmpty();

	if (Pin)
	{
		UEdGraphNode* Node = Pin->GetOwningNode();
		if (Node->ShouldOverridePinNames())
		{
			DisplayName = Node->GetPinNameOverride(*Pin);
		}
		else
		{
			DisplayName = Super::GetPinDisplayName(Pin);
		}
	}
	return DisplayName;
}

void UEpisodeGraphSchema::AddEpisodeOption(class UGraphNodeContextMenuContext* Context) const
{
	if (UEpisodeGraphNode* EpisodeNode = const_cast<UEpisodeGraphNode*>(Cast<UEpisodeGraphNode>(Context->Node)))
	{
		//先在这个Node上创建一个GraphPin
		UEdGraphPin* NewPin = EpisodeNode->AddOptionPin();

		//通过EpisodeNode的EpisodeID，到DialogueAsset中查找对应的配置，并在这个配置中添加option		
		//注意此时只是表示EpisodeID多了个选项，至于这个选项连的是谁，现在还没有确定
		if(UDialogueAsset* DialogueAsset = Cast<UEpisodeGraph>(EpisodeNode->GetGraph())->GetDialogueAsset())
		{
			DialogueAsset->AddDialogueEpisodeOption(EpisodeNode->GetEpisodeID(), NewPin->PinId);
		}
	}
}

void UEpisodeGraphSchema::RemoveEpisodeOption(class UGraphNodeContextMenuContext* Context) const
{
	if (UEpisodeGraphNode* EpisodeNode = const_cast<UEpisodeGraphNode*>(Cast<UEpisodeGraphNode>(Context->Node)))
	{
		if (Context->Pin)
		{
			EpisodeNode->RemoveOptionPin(Context->Pin);
		}
	}
}

#undef LOCTEXT_NAMESPACE
