#include "DialogueEditor/Graph/OptionGraphSchemaAction_NewNode.h"
#include "Misc/MessageDialog.h"
#include "DialogueEditor/Graph/OptionGraph.h"
#include "DialogueEditor/Graph/GraphNodes/OptionGraphNode.h"

UEdGraphNode* FOptionGraphSchemaAction_HasItem::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionHasItemNode(0, Location);
	
	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_HasTaskFinished::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionHasTaskFinishedNode(0, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_CheckPreCondition::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionCheckPreConditionNode(0, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_IsQteSuccess::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionIsQteSuccessNode(0, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_IsQteFailed::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionIsQteFailedNode(0, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_CheckDiceResult::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionCheckDiceResultNode(0, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_IsModeOver::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionIsModeOverNode(0, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_HasFinalPrice::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionHasFinalPriceNode(0, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_And::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNode* NewNode = Graph->CreateOptionNode(Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(FromPin, NewNode->GetInputPin1());
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_AddMood::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	FString Param = TEXT("0");
	UOptionGraphActionNoParamNode* NewNode = Graph->CreateActionAddMoodNode(Param, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(FromPin, NewNode->GetInputPin());
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_OpenSeeMood::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	FString Param = TEXT("0");
	UOptionGraphActionNoParamNode* NewNode = Graph->CreateActionOpenSeeMoodNode(Param, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(FromPin, NewNode->GetInputPin());
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_CloseSeeMood::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	FString Param = TEXT("0");
	UOptionGraphActionNoParamNode* NewNode = Graph->CreateActioCloseSeeMoodNode(Param, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(FromPin, NewNode->GetInputPin());
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_OpenCutPrice::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	FString Param = TEXT("0");
	UOptionGraphActionNoParamNode* NewNode = Graph->CreateActioOpenCutPriceNode(Param, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(FromPin, NewNode->GetInputPin());
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_SubmitPrice::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	FString Param = TEXT("0");
	UOptionGraphActionNoParamNode* NewNode = Graph->CreateActioSubmitPriceNode(Param, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(FromPin, NewNode->GetInputPin());
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_OpenUI::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	FString Param = TEXT("uiname$param");
	UOptionGraphActionNoParamNode* NewNode = Graph->CreateActioOpenUINode(Param, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(FromPin, NewNode->GetInputPin());
	return nullptr;
}

UEdGraphNode* FOptionGraohSchemaAction_BargainResult::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	if (UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph))
	{
		FString Param(TEXT("true"));
		UOptionGraphActionNoParamNode* NewNode = Graph->CretaeActionBargainResult(Param, Location);
		if (FromPin)
		{
			Graph->GetSchema()->TryCreateConnection(FromPin, NewNode->GetInputPin());
		}

		return NewNode;
	}
	
    return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_CheckBargainStart::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionCheckBargainStart(true, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}

UEdGraphNode* FOptionGraphSchemaAction_CheckMoodLevel::PerformAction(UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//转换为UOptionGraph类型
	UOptionGraph* Graph = Cast<UOptionGraph>(ParentGraph);

	//创建新节点
	UOptionGraphNoParamNode* NewNode = Graph->CreateOptionCheckMoodLevel(0, Location);

	if (FromPin)//如果有引脚则连接
		Graph->GetSchema()->TryCreateConnection(NewNode->GetOutputPin(), FromPin);
	return nullptr;
}
