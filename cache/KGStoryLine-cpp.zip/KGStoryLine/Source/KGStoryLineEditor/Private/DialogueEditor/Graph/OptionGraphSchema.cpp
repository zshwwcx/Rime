//author yaoliwen@kuaishou.com 2024.9.18

#include "DialogueEditor/Graph/OptionGraphSchema.h"
#include "DialogueEditor/Graph/OptionGraphSchemaAction_NewNode.h"
#include "EdGraph/EdGraph.h"
#include "ToolMenuSection.h"
#include "DialogueEditor/Graph/GraphNodes/OptionGraphNode.h"
#include "ToolMenu.h"
#include "Framework/Commands/GenericCommands.h"

#define LOCTEXT_NAMESPACE "OptionGraphSchema"

UOptionGraphSchema::UOptionGraphSchema(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UOptionGraphSchema::GetGraphContextActions(FGraphContextMenuBuilder& ContextMenuBuilder) const
{
	// TSharedPtr<FOptionGraphSchemaAction_HasItem> HasItemAction(new FOptionGraphSchemaAction_HasItem());
	// ContextMenuBuilder.AddAction(HasItemAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_HasTaskFinished> HasTaskFinishedAction(new FOptionGraphSchemaAction_HasTaskFinished());
	// ContextMenuBuilder.AddAction(HasTaskFinishedAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_CheckPreCondition> CheckPreConditionAction(new FOptionGraphSchemaAction_CheckPreCondition());
	// ContextMenuBuilder.AddAction(CheckPreConditionAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_IsQteSuccess> IsQteSuccessAction(new FOptionGraphSchemaAction_IsQteSuccess());
	// ContextMenuBuilder.AddAction(IsQteSuccessAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_IsQteFailed> IsQteFailedAction(new FOptionGraphSchemaAction_IsQteFailed());
	// ContextMenuBuilder.AddAction(IsQteFailedAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_CheckDiceResult> CheckDiceResultAction(new FOptionGraphSchemaAction_CheckDiceResult());
	// ContextMenuBuilder.AddAction(CheckDiceResultAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_IsModeOver> IsModeOverAction(new FOptionGraphSchemaAction_IsModeOver());
	// ContextMenuBuilder.AddAction(IsModeOverAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_HasFinalPrice> HasFinalPriceAction(new FOptionGraphSchemaAction_HasFinalPrice());
	// ContextMenuBuilder.AddAction(HasFinalPriceAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_AddMood> AddMoodAction(new FOptionGraphSchemaAction_AddMood());
	// ContextMenuBuilder.AddAction(AddMoodAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_OpenSeeMood> OpenSeeMoodAction(new FOptionGraphSchemaAction_OpenSeeMood());
	// ContextMenuBuilder.AddAction(OpenSeeMoodAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_CloseSeeMood> CloseSeeMoodAction(new FOptionGraphSchemaAction_CloseSeeMood());
	// ContextMenuBuilder.AddAction(CloseSeeMoodAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_OpenCutPrice> OpenCutPriceAction(new FOptionGraphSchemaAction_OpenCutPrice());
	// ContextMenuBuilder.AddAction(OpenCutPriceAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_SubmitPrice> SubmitPriceAction(new FOptionGraphSchemaAction_SubmitPrice());
	// ContextMenuBuilder.AddAction(SubmitPriceAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_OpenUI> OpenUIAction(new FOptionGraphSchemaAction_OpenUI());
	// ContextMenuBuilder.AddAction(OpenUIAction);
	//
	// TSharedPtr<FOptionGraphSchemaAction_CheckBargainStart> CheckBargainStart(new FOptionGraphSchemaAction_CheckBargainStart());
	// ContextMenuBuilder.AddAction(CheckBargainStart);
	//
	// TSharedPtr<FOptionGraphSchemaAction_CheckMoodLevel> CheckMoodLevel(new FOptionGraphSchemaAction_CheckMoodLevel());
	// ContextMenuBuilder.AddAction(CheckMoodLevel);
	//
	// TSharedPtr<FOptionGraohSchemaAction_BargainResult> BargainResult(new FOptionGraohSchemaAction_BargainResult());
	// ContextMenuBuilder.AddAction(BargainResult);

}

void UOptionGraphSchema::GetContextMenuActions(UToolMenu* Menu, UGraphNodeContextMenuContext* Context) const
{
	Super::GetContextMenuActions(Menu, Context);

	if (const UOptionGraphNode* GraphNode = Cast<UOptionGraphNode>(Context->Node))
	{
		UOptionGraphSchema* MutableThis = const_cast<UOptionGraphSchema*>(this);
		if (Context->Pin && Context->Pin->Direction == EEdGraphPinDirection::EGPD_Input)
		{
			FToolMenuSection& AddConditionSection = Menu->AddSection("ConditionSection", LOCTEXT("LOC_Condition", "Condition"));
			AddConditionSection.AddMenuEntry(TEXT("AddCondition"),
				FText::FromString(TEXT("AddCondition")),
				FText::FromString(TEXT("Add a condition for this option")),
				FSlateIcon(),
				FUIAction(FExecuteAction::CreateUObject(MutableThis, &UOptionGraphSchema::AddCondition, Context))
			);

			FToolMenuSection& RemoveConditionSection = Menu->AddSection("ConditionSection", LOCTEXT("LOC_Condition", "Condition"));
			RemoveConditionSection.AddMenuEntry(TEXT("RemoveCondition"),
				FText::FromString(TEXT("RemoveCondition")),
				FText::FromString(TEXT("Remove this condition")),
				FSlateIcon(),
				FUIAction(FExecuteAction::CreateUObject(MutableThis, &UOptionGraphSchema::RemoveCondition, Context))
			);

			FToolMenuSection& NodeSection = Menu->AddSection("GraphSchemaActions_Node", LOCTEXT("ClassActionsMenuHeader_Node", "Node Actions"));
			NodeSection.AddMenuEntry(FGenericCommands::Get().Delete);
		}
		else if(Context->Pin && Context->Pin->Direction == EEdGraphPinDirection::EGPD_Output)
		{
			FToolMenuSection& AddConditionSection = Menu->AddSection("ActionSection", LOCTEXT("LOC_Action", "Action"));
			AddConditionSection.AddMenuEntry(TEXT("AddAction"),
				FText::FromString(TEXT("AddAction")),
				FText::FromString(TEXT("Add a action for this option")),
				FSlateIcon(),
				FUIAction(FExecuteAction::CreateUObject(MutableThis, &UOptionGraphSchema::AddAction, Context))
			);

			FToolMenuSection& RemoveConditionSection = Menu->AddSection("ActionSection", LOCTEXT("LOC_Action", "Action"));
			RemoveConditionSection.AddMenuEntry(TEXT("RemoveAction"),
				FText::FromString(TEXT("RemoveAction")),
				FText::FromString(TEXT("Remove this action")),
				FSlateIcon(),
				FUIAction(FExecuteAction::CreateUObject(MutableThis, &UOptionGraphSchema::RemoveAction, Context))
			);

			FToolMenuSection& NodeSection = Menu->AddSection("GraphSchemaActions_Node", LOCTEXT("ClassActionsMenuHeader_Node", "Node Actions"));
			NodeSection.AddMenuEntry(FGenericCommands::Get().Delete);
		}
	}
}

bool UOptionGraphSchema::SafeDeleteNodeFromGraph(UEdGraph* Graph, UEdGraphNode* Node) const
{
	check(Node);
	Graph->Modify();

	if (Node->CanUserDeleteNode())
	{
		Node->Modify();
		Node->DestroyNode();
	}

	return true;
}

void UOptionGraphSchema::AddCondition(UGraphNodeContextMenuContext* Context) const
{
	if (UOptionGraphNode* OptionNode = const_cast<UOptionGraphNode*>(Cast<UOptionGraphNode>(Context->Node)))
	{
		//先在这个Node上创建一个GraphPin
		UEdGraphPin* NewPin = OptionNode->AddConditionPin();

		//UDialogueAsset* DialogueAsset = (Cast<UEpisodeGraph>(OptionNode->GetGraph()))->GetDialogueAsset();

		////通过EpisodeNode的EpisodeID，到DialogueAsset中查找对应的配置，并在这个配置中添加option		
		////注意此时只是表示EpisodeID多了个选项，至于这个选项连的是谁，现在还没有确定
		//DialogueAsset->AddEpisodeOption(OptionNode->EpisodeID, NewPin->PinId);
	}
}

void UOptionGraphSchema::RemoveCondition(UGraphNodeContextMenuContext* Context) const
{
	if (UOptionGraphNode* OptionNode = const_cast<UOptionGraphNode*>(Cast<UOptionGraphNode>(Context->Node)))
	{
		if (Context->Pin)
		{
			OptionNode->RemoveConditionPin(Context->Pin);
		}
	}
}

void UOptionGraphSchema::AddAction(UGraphNodeContextMenuContext* Context) const
{
	if (UOptionGraphNode* OptionNode = const_cast<UOptionGraphNode*>(Cast<UOptionGraphNode>(Context->Node)))
	{
		UEdGraphPin* NewPin = OptionNode->AddActionPin();
	}
}

void UOptionGraphSchema::RemoveAction(UGraphNodeContextMenuContext* Context) const
{
	if (UOptionGraphNode* OptionNode = const_cast<UOptionGraphNode*>(Cast<UOptionGraphNode>(Context->Node)))
	{
		if (Context->Pin)
		{
			OptionNode->RemoveActionPin(Context->Pin);
		}
	}
}

#undef LOCTEXT_NAMESPACE
