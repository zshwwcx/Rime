//author yaoliwen@kuaishou.com 2024.9.18

#include "DialogueEditor/Graph/OptionGraph.h"
#include "Misc/MessageDialog.h"
#include "DialogueEditor/Graph/OptionGraphSchema.h"
#include "EdGraph/EdGraphPin.h"

TMap<FString, TDelegate<class UOptionGraphNoParamNode* (int Id, const FVector2D Location)>> UOptionGraph::Condition2NodeCreate = TMap<FString, TDelegate<class UOptionGraphNoParamNode* (int Id, const FVector2D Location)>>();

TMap<FString, TDelegate<class UOptionGraphActionNoParamNode* (FString& Param, const FVector2D Location)>> UOptionGraph::Action2NodeCreate = TMap<FString, TDelegate<class UOptionGraphActionNoParamNode* (FString& Param, const FVector2D Location)>>();

UOptionGraph::UOptionGraph(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	Condition2NodeCreate.Emplace(TEXT("Pre"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionCheckPreConditionNode));
	Condition2NodeCreate.Emplace(TEXT("CompleteTask"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionHasTaskFinishedNode));
	Condition2NodeCreate.Emplace(TEXT("Item"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionHasItemNode));
	Condition2NodeCreate.Emplace(TEXT("Qte"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionIsQteSuccessNode));
	Condition2NodeCreate.Emplace(TEXT("QteFailed"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionIsQteFailedNode));
	Condition2NodeCreate.Emplace(TEXT("Dice"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionCheckDiceResultNode));
	Condition2NodeCreate.Emplace(TEXT("Mood"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionIsModeOverNode));
	Condition2NodeCreate.Emplace(TEXT("Price"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionHasFinalPriceNode));
	Condition2NodeCreate.Emplace(TEXT("CheckBargainStart"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionCheckBargainStart));
	Condition2NodeCreate.Emplace(TEXT("CheckMoodLevel"), FCreateOptionNode::CreateUObject(this, &UOptionGraph::CreateOptionCheckMoodLevel));


	Action2NodeCreate.Emplace(TEXT("OpenSeeMood"), FCreateActionNode::CreateUObject(this, &UOptionGraph::CreateActionOpenSeeMoodNode));
	Action2NodeCreate.Emplace(TEXT("CloseSeeMood"), FCreateActionNode::CreateUObject(this, &UOptionGraph::CreateActioCloseSeeMoodNode));
	Action2NodeCreate.Emplace(TEXT("AddMood"), FCreateActionNode::CreateUObject(this, &UOptionGraph::CreateActionAddMoodNode));
	Action2NodeCreate.Emplace(TEXT("OpenCutPrice"), FCreateActionNode::CreateUObject(this, &UOptionGraph::CreateActioOpenCutPriceNode));
	Action2NodeCreate.Emplace(TEXT("SubmitPrice"), FCreateActionNode::CreateUObject(this, &UOptionGraph::CreateActioSubmitPriceNode));
	Action2NodeCreate.Emplace(TEXT("OpenUI"), FCreateActionNode::CreateUObject(this, &UOptionGraph::CreateActioOpenUINode));
	Action2NodeCreate.Emplace(TEXT("BargainResult"), FCreateActionNode::CreateUObject(this, &UOptionGraph::CretaeActionBargainResult));

}


void UOptionGraph::SetCondition(FString& InCondition, TArray<FString>& InExtraAction, int32 InEpisodeID, int32 InDialogueLineIndex, TWeakObjectPtr<UDialogueAsset> InDialogueAssetEditing)
{
	this->Condition = InCondition;
	this->ExtraAction = InExtraAction;
	this->EpisodeID = InEpisodeID;
	this->DialogueLineIndex = InDialogueLineIndex;
	this->DialogueAssetEditing = InDialogueAssetEditing;
	const UOptionGraphSchema* GraphSchema = Cast<UOptionGraphSchema>(GetSchema());
	for (auto& NodeIt : AllNodes)
	{
		GraphSchema->SafeDeleteNodeFromGraph(this, NodeIt);
	}
	AllNodes.Empty();
	for (auto& NodeIt : AllActionNodes)
	{
		GraphSchema->SafeDeleteNodeFromGraph(this, NodeIt);
	}
	AllActionNodes.Empty();

	if(AndNode)
	{
		GraphSchema->SafeDeleteNodeFromGraph(this, AndNode);
		AndNode = nullptr;
	}

	if (JumpNode)
	{
		GraphSchema->SafeDeleteNodeFromGraph(this, JumpNode);
		JumpNode = nullptr;
	}
}

void UOptionGraph::RebuildGraph()
{
	TArray<FString> ConditionArray;
	Condition.ParseIntoArray(ConditionArray, TEXT("&"));

	FVector2D Location(0, 0);
	for(int Idx = 0; Idx < ConditionArray.Num(); Idx++)
	{
		TArray<FString> DetailArray;
		ConditionArray[Idx].ParseIntoArray(DetailArray, TEXT(":"));
		if(DetailArray.Num() != 2)
		{
			UE_LOG(LogTemp, Warning, TEXT("dialogue option format is illegal ! %s "), *ConditionArray[Idx]);
		}
		else
		{
			FString& ConditionName = DetailArray[0];
			FString& ConditionValue = DetailArray[1];
			auto* It = Condition2NodeCreate.Find(ConditionName);
			if(It == nullptr)
			{
				UE_LOG(LogTemp, Warning, TEXT("Option ConditionName %s is illegal!"), *ConditionArray[Idx]);
			}
			else
			{
				auto CreateFunc = *It;
				if (ConditionName == TEXT("Qte"))
				{
					if (ConditionValue == TEXT("1"))
					{
						auto NewNode = CreateFunc.Execute(1, Location);
					}
					else if (ConditionValue == TEXT("0"))
					{
						auto* Failed = Condition2NodeCreate.Find(TEXT("QteFailed"));
						if(Failed)
						{
							auto NewNode = Failed->Execute(1, Location);
						}
					}
					Location.Y = Location.Y + 200;
					continue;
				}
				TArray<FString> ConditionIDs;
				ConditionValue.ParseIntoArray(ConditionIDs, TEXT(","));
				for (auto& ConditionID : ConditionIDs)
				{
					int ID = FCString::Atoi(*ConditionID);
					auto NewNode = CreateFunc.Execute(ID, Location);
					Location.Y = Location.Y + 200;
				}
			}
		}
	}

	Location.X = Location.X + 400;
	Location.Y = Location.Y / 2;
	//创建And节点
	UOptionGraphNode* result = CreateOptionNode(Location);

	//创建Jump节点
	Location.X = Location.X + 400;
	Location.Y = -200;
	UOptionGraphJumpNode* jump = CreateOptionJumpNode(Location);
	GetSchema()->TryCreateConnection(result->GetResultPin(), jump->GetInputPin());

	Location.X = Location.X + 400;
	Location.Y = 0;
	for (int Idx = 0; Idx < ExtraAction.Num(); Idx++)
	{
		TArray<FString> DetailArray;
		ExtraAction[Idx].ParseIntoArray(DetailArray, TEXT("$"));
		if (DetailArray.Num() < 1)
		{
			UE_LOG(LogTemp, Warning, TEXT("dialogue option extra action format is illegal ! %s "), *ExtraAction[Idx]);
		}
		else
		{
			FString& ActionName = DetailArray[0];
			FString ActionValue = TEXT("");
			for(int I = 1; I < DetailArray.Num(); I++)
			{
				if(I > 1)
				{
					ActionValue += TEXT("$");
				}
				ActionValue += DetailArray[I];
			}
			auto* It = Action2NodeCreate.Find(ActionName);
			if (It == nullptr)
			{
				UE_LOG(LogTemp, Warning, TEXT("Option extra action %s is illegal!"), *ExtraAction[Idx]);
			}
			else
			{
				auto CreateFunc = *It;
				auto NewNode = CreateFunc.Execute(ActionValue, Location);
				Location.Y = Location.Y + 200;
			}
		}
	}
	int num = AllNodes.Num();
	for (int i = 0; i < num; i++)
	{
		if (i < 2)
		{
			auto Pin = i == 0 ? result->GetInputPin1() : result->GetInputPin2();
			auto& Node = AllNodes[i];
			GetSchema()->TryCreateConnection(Node->GetOutputPin(), Pin);
		}
		else
		{
			auto Pin = result->AddConditionPin();
			auto& Node = AllNodes[i];
			GetSchema()->TryCreateConnection(Node->GetOutputPin(), Pin);
		}
	}
	num = AllActionNodes.Num();
	for (int i = 0; i < num; i++)
	{
		if (i < 1)
		{
			auto Pin = result->GetOutputPin();
			auto& Node = AllActionNodes[i];
			GetSchema()->TryCreateConnection(Pin, Node->GetInputPin());
		}
		else
		{
			auto Pin = result->AddActionPin();
			auto& Node = AllActionNodes[i];
			GetSchema()->TryCreateConnection(Pin, Node->GetInputPin());
		}
	}
}

UOptionGraphNode* UOptionGraph::CreateOptionNode(const FVector2D Location)
{
	if(AndNode)
	{
		UE_LOG(LogTemp, Warning, TEXT("逻辑AND运算节点已存在，只能存在一个"));
		return nullptr;
	}
	FGraphNodeCreator<UOptionGraphNode> NodeCreator(*this);
	UOptionGraphNode* result = NodeCreator.CreateNode();
	result->NodePosX = Location.X;
	result->NodePosY = Location.Y;
	result->AllocateDefaultPins();
	NodeCreator.Finalize();
	AndNode = result;
	return result;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionNoParamNode()
{
	FGraphNodeCreator<UOptionGraphNoParamNode> NodeCreator(*this);
	UOptionGraphNoParamNode* result = NodeCreator.CreateNode();
	NodeCreator.Finalize();
	return result;
}

UOptionGraphOneParamNode* UOptionGraph::CreateOptionOneParamNode()
{
	FGraphNodeCreator<UOptionGraphOneParamNode> NodeCreator(*this);
	UOptionGraphOneParamNode* result = NodeCreator.CreateNode();
	NodeCreator.Finalize();
	return result;
}

UOptionGraphActionNoParamNode* UOptionGraph::CreateOptionActionNoParamNode()
{
	FGraphNodeCreator<UOptionGraphActionNoParamNode> NodeCreator(*this);
	UOptionGraphActionNoParamNode* result = NodeCreator.CreateNode();
	NodeCreator.Finalize();
	return result;
}

UOptionGraphActionOneParamNode* UOptionGraph::CreateOptionActionOneParamNode()
{
	FGraphNodeCreator<UOptionGraphActionOneParamNode> NodeCreator(*this);
	UOptionGraphActionOneParamNode* result = NodeCreator.CreateNode();
	NodeCreator.Finalize();
	return result;
}

UOptionGraphActionMultiParamNode* UOptionGraph::CreateOptionActionMultiParamNode()
{
	FGraphNodeCreator<UOptionGraphActionMultiParamNode> NodeCreator(*this);
	UOptionGraphActionMultiParamNode* result = NodeCreator.CreateNode();
	NodeCreator.Finalize();
	return result;
}

UOptionGraphJumpNode* UOptionGraph::CreateOptionJumpNode(const FVector2D Location)
{
	if (JumpNode)
	{
		UE_LOG(LogTemp, Warning, TEXT("Jump跳转节点已存在，只能存在一个"));
		return nullptr;
	}
	FGraphNodeCreator<UOptionGraphJumpNode> NodeCreator(*this);
	UOptionGraphJumpNode* result = NodeCreator.CreateNode();
	result->NodePosX = Location.X;
	result->NodePosY = Location.Y;
	result->Params[0] = this->EpisodeID;
	result->Params[1] = this->DialogueLineIndex;
	result->DialogueAssetEditing = this->DialogueAssetEditing;
	result->AllocateDefaultPins();
	NodeCreator.Finalize();
	JumpNode = result;
	return result;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionHasItemNode(int Id, const FVector2D Location)
{
	//创建新节点
	UOptionGraphOneParamNode* NewNode = CreateOptionOneParamNode();
	//设置信息
	NewNode->Title = TEXT("Has Item");
	NewNode->ConditionName = TEXT("Item");
	NewNode->ParamName = TEXT("Item Id");
	NewNode->Param = Id;
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionHasTaskFinishedNode(int Id, const FVector2D Location)
{
	//创建新节点
	UOptionGraphOneParamNode* NewNode = CreateOptionOneParamNode();
	//设置信息
	NewNode->Title = TEXT("Has Task Finished");
	NewNode->ConditionName = TEXT("CompleteTask");
	NewNode->ParamName = TEXT("Task Id");
	NewNode->Param = Id;
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionCheckPreConditionNode(int Id, const FVector2D Location)
{
	//创建新节点
	UOptionGraphOneParamNode* NewNode = CreateOptionOneParamNode();
	//设置信息
	NewNode->Title = TEXT("Check Pre Condition");
	NewNode->ParamName = TEXT("Pre Con Id");
	NewNode->ConditionName = TEXT("Pre");
	NewNode->Param = Id;
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionIsQteSuccessNode(int Id, const FVector2D Location)
{
	//创建新节点
	UOptionGraphNoParamNode* NewNode = CreateOptionNoParamNode();
	//设置信息
	NewNode->Title = TEXT("Is Qte Success");
	NewNode->ConditionName = TEXT("Qte:1");
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionIsQteFailedNode(int Id, const FVector2D Location)
{
	//创建新节点
	UOptionGraphNoParamNode* NewNode = CreateOptionNoParamNode();
	//设置信息
	NewNode->Title = TEXT("Is Qte Failed");
	NewNode->ConditionName = TEXT("Qte:0");
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionCheckDiceResultNode(int Id, const FVector2D Location)
{
	//创建新节点
	UOptionGraphOneParamNode* NewNode = CreateOptionOneParamNode();
	//设置信息
	NewNode->Title = TEXT("Check Dice Result");
	NewNode->ConditionName = TEXT("Dice");
	NewNode->ParamName = TEXT("Dice Result");
	NewNode->Param = Id;
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionIsModeOverNode(int Id, const FVector2D Location)
{
	//创建新节点
	UOptionGraphOneParamNode* NewNode = CreateOptionOneParamNode();
	//设置信息
	NewNode->Title = TEXT("Is Mode Over");
	NewNode->ConditionName = TEXT("Mood");
	NewNode->ParamName = TEXT("Over");
	NewNode->Param = Id;
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionHasFinalPriceNode(int Id, const FVector2D Location)
{
	//创建新节点
	UOptionGraphNoParamNode* NewNode = CreateOptionNoParamNode();
	//设置信息
	NewNode->Title = TEXT("Has Final Price");
	NewNode->ConditionName = TEXT("Price:1");
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionCheckBargainStart(int32 bStart, const FVector2D Location)
{
	//创建新节点
	UOptionGraphOneParamNode* NewNode = CreateOptionOneParamNode();
	//设置信息
	NewNode->Title = TEXT("Check Bargain Start");
	NewNode->ConditionName = TEXT("CheckBargainStart");
	NewNode->ParamName = TEXT("Start");
	NewNode->Param = bStart ? 1 : 0;
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphNoParamNode* UOptionGraph::CreateOptionCheckMoodLevel(int32 MoodLevel, const FVector2D Location)
{
	//创建新节点
	UOptionGraphOneParamNode* NewNode = CreateOptionOneParamNode();
	//设置信息
	NewNode->Title = TEXT("Check Mood Level");
	NewNode->ConditionName = TEXT("CheckMoodLevel");
	NewNode->ParamName = TEXT("Level");
	NewNode->Param = MoodLevel;
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphActionNoParamNode* UOptionGraph::CreateActionAddMoodNode(FString& Param, const FVector2D Location)
{
	//创建新节点
	UOptionGraphActionOneParamNode* NewNode = CreateOptionActionOneParamNode();
	//设置信息
	NewNode->Title = TEXT("Add Mood");
	NewNode->ConditionName = TEXT("AddMood");
	NewNode->ParamName = TEXT("Mood Delta");
	NewNode->Param = FCString::Atoi(*Param);
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllActionNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphActionNoParamNode* UOptionGraph::CreateActionOpenSeeMoodNode(FString& Param, const FVector2D Location)
{
	//创建新节点
	UOptionGraphActionNoParamNode* NewNode = CreateOptionActionNoParamNode();
	//设置信息
	NewNode->Title = TEXT("Open See Mood");
	NewNode->ConditionName = TEXT("OpenSeeMood");
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllActionNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphActionNoParamNode* UOptionGraph::CreateActioCloseSeeMoodNode(FString& Param, const FVector2D Location)
{
	//创建新节点
	UOptionGraphActionNoParamNode* NewNode = CreateOptionActionNoParamNode();
	//设置信息
	NewNode->Title = TEXT("Close See Mood");
	NewNode->ConditionName = TEXT("CloseSeeMood");
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllActionNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphActionNoParamNode* UOptionGraph::CreateActioOpenCutPriceNode(FString& Param, const FVector2D Location)
{
	//创建新节点
	UOptionGraphActionNoParamNode* NewNode = CreateOptionActionNoParamNode();
	//设置信息
	NewNode->Title = TEXT("Open Cut Price");
	NewNode->ConditionName = TEXT("OpenCutPrice");
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllActionNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphActionNoParamNode* UOptionGraph::CreateActioSubmitPriceNode(FString& Param, const FVector2D Location)
{
	//创建新节点
	UOptionGraphActionNoParamNode* NewNode = CreateOptionActionNoParamNode();
	//设置信息
	NewNode->Title = TEXT("Submit Price");
	NewNode->ConditionName = TEXT("SubmitPrice");
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllActionNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphActionNoParamNode* UOptionGraph::CreateActioOpenUINode(FString& Param, const FVector2D Location)
{
	//创建新节点
	UOptionGraphActionMultiParamNode* NewNode = CreateOptionActionMultiParamNode();
	//设置信息
	NewNode->Title = TEXT("Open UI");
	NewNode->ConditionName = TEXT("OpenUI");
	NewNode->ParamNames.Add(TEXT("UI Name"));
	NewNode->ParamNames.Add(TEXT("Param"));
	Param.ParseIntoArray(NewNode->Params, TEXT("$"));
	int Num1 = NewNode->Params.Num();
	int Num2 = NewNode->ParamNames.Num();
	if(Num1 < Num2)
	{
		NewNode->Params.AddDefaulted(Num2 - Num1);
	}
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllActionNodes.Emplace(NewNode);
	return NewNode;
}

UOptionGraphActionNoParamNode* UOptionGraph::CretaeActionBargainResult(FString& StrSuccess, const FVector2D Location)
{
	//创建新节点
	UOptionGraphActionOneParamNode* NewNode = CreateOptionActionOneParamNode();
	//设置信息
	NewNode->Title = TEXT("Bargain Result");
	NewNode->ConditionName = TEXT("BargainResult");
	NewNode->ParamName = TEXT("Success");
	NewNode->Param = StrSuccess.Equals(TEXT("true"), ESearchCase::IgnoreCase) || StrSuccess == TEXT("1") ? 1 : 0;
	//设置节点的位置
	NewNode->NodePosX = Location.X;
	NewNode->NodePosY = Location.Y;
	AllActionNodes.Emplace(NewNode);
	return NewNode;
}

void UOptionGraph::DeleteNode(UEdGraphNode* Node)
{
	if (UOptionGraphNoParamNode* NoParamNode = Cast<UOptionGraphNoParamNode>(Node))
	{
		AllNodes.Remove(NoParamNode);
	}
	else if (UOptionGraphActionNoParamNode* ActionNode = Cast<UOptionGraphActionNoParamNode>(Node))
	{
		AllActionNodes.Remove(ActionNode);
	}
}

FString UOptionGraph::GetCondition()
{
	TStringBuilder<256> sb;
	sb.Reset();
	int num = AllNodes.Num();
	for(int Idx = 0; Idx < AllNodes.Num(); Idx++)
	{
		UOptionGraphNoParamNode* Node = AllNodes[Idx];
		sb.Append(Node->ToString());
		if(Idx < num - 1)
		{
			sb.Append(TEXT("&"));
		}
	}
	return sb.ToString();
}

TArray<FString> UOptionGraph::GetExtraAction()
{
	TArray<FString> Actions;
	int num = AllActionNodes.Num();
	for (int Idx = 0; Idx < AllActionNodes.Num(); Idx++)
	{
		UOptionGraphActionNoParamNode* Node = AllActionNodes[Idx];
		Actions.Add(Node->ToString());
	}
	return Actions;
}

int32 UOptionGraph::GetEpisodeID()
{
	return JumpNode->Params[0];
}

int32 UOptionGraph::GetDialogueLineIndex()
{
	return JumpNode->Params[1];
}

void UOptionGraph::TestFunc()
{
	//要显示的信息：
	FString Message = "UEdGraph_Yaksue::TestFunc():";

	for (auto p : AndNode->OutputPin->LinkedTo)//访问所有的引脚
	{
		//显示的信息中添加TestInfo
		//Message += ((UOptionGraphAndNode*)p->GetOwningNode())->Title;
	}

	//显示对话框
	FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
}
