// Copyright 2020 Kuai, Inc. All Rights Reserved.

#include "DialogueEditor/Graph/EpisodeGraph.h"
#include "DialogueEditor/Graph/EpisodeGraphSchema.h"
#include "DialogueEditor/Graph/GraphNodes/EpisodeGraphNode.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"


void UEpisodeGraph::OnCreated()
{
	UEpisodeGraphEntryNode* EntryNode = CreateEntryNode();
	UEpisodeGraphNode* DefaultNode = CreateEpisodeNode(nullptr, true, FVector2D(300,0));
	
	// Assigin
	if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
	{
		DefaultNode->SetOwnerDialogueEpisode(DialogueAsset->GetDialogueEpisode(0));
	}

	GetSchema()->TryCreateConnection(EntryNode->OutputPin, DefaultNode->InputPin);
}

void UEpisodeGraph::OnLoaded()
{

}

void UEpisodeGraph::Initialize()
{
}

class UEpisodeGraphNode* UEpisodeGraph::GetEpisodeNode(class UKGSLDialogueEpisode* Episode)
{
	if(!IsValid(Episode))
	{
		return nullptr;
	}
	
	for(auto& Node : Nodes)
	{
		if(UEpisodeGraphNode* NodePtr = Cast<UEpisodeGraphNode>(Node.Get()))
		{
			if(NodePtr->GetOwnerDialogueEpisode() == Episode)
			{
				return NodePtr;
			}
		}
	}
	
	if(UEpisodeGraphNode* Node = GetEpisodeNode(Episode->GetEpisodeID()))
	{
		Node->SetOwnerDialogueEpisode(Episode);
		return Node;
	}

	return nullptr;
}

class UEpisodeGraphNode* UEpisodeGraph::GetEpisodeNode(int32 EpisodeID)
{
	for(auto& Node : Nodes)
	{
		if(UEpisodeGraphNode* NodePtr = Cast<UEpisodeGraphNode>(Node.Get()))
		{
			if(NodePtr->GetEpisodeID() == EpisodeID)
			{
				return NodePtr;
			}
		}
	}
	
	return nullptr;
}

class UDialogueAsset* UEpisodeGraph::GetDialogueAsset()
{
	UDialogueAsset*  DialogueAsset = Cast<UDialogueAsset>(GetOuter());
	return DialogueAsset;
}

TArray<class UEpisodeGraphNode*> UEpisodeGraph::GetEpisodeNodes()
{
	TArray<class UEpisodeGraphNode*> Ret;
	for (UEdGraphNode* Node : Nodes)
	{
		if (UEpisodeGraphNode* EpisodeNode = Cast<UEpisodeGraphNode>(Node))
		{
			Ret.Add(EpisodeNode);
		}
	}
	return Ret;
}

UEpisodeGraphEntryNode* UEpisodeGraph::CreateEntryNode()
{
	UEpisodeGraphEntryNode* EntryNode = NewObject<UEpisodeGraphEntryNode>(this, UEpisodeGraphEntryNode::StaticClass());

	EntryNode->Rename(nullptr, this);
	AddNode(EntryNode, false, true);

	EntryNode->CreateNewGuid();
	EntryNode->PostPlacedNewNode();
	EntryNode->AllocateDefaultPins();

	EntryNode->NodePosX = 0;
	EntryNode->NodePosY = 0;

	EntryNode->SetFlags(RF_Transactional);
	return EntryNode;
}

UEpisodeGraphNode* UEpisodeGraph::CreateEpisodeNode(UEdGraphPin* FromPin, bool bSelectNewNode, const FVector2D& Location)
{
	Modify();
	if (FromPin)
	{
		FromPin->Modify();
	}
	UEpisodeGraphNode* NodeTemplate = NewObject<UEpisodeGraphNode>(this, UEpisodeGraphNode::StaticClass());

	NodeTemplate->Rename(nullptr, this);
	NodeTemplate->CreateNewGuid();
	AddNode(NodeTemplate, true, bSelectNewNode);

	NodeTemplate->PostPlacedNewNode();
	NodeTemplate->AllocateDefaultPins();
	NodeTemplate->AutowireNewNode(FromPin);

	NodeTemplate->NodePosX = Location.X;
	NodeTemplate->NodePosY = Location.Y;


	NodeTemplate->SetFlags(RF_Transactional);

	return NodeTemplate;
}

void UEpisodeGraph::OnEpisodeAdded()
{
	UDialogueAsset* Asset = GetDialogueAsset();
	if(!IsValid(Asset))
	{
		return;
	}

	TArray<UKGSLDialogueEpisode*> EpisodesAdded;
	for(auto* Episode : Asset->EpisodesList)
	{
		if(Episode)
		{
			if(UEpisodeGraphNode* Node= GetEpisodeNode(Episode))
			{
				if(Node->GetEpisodeID() != Episode->GetEpisodeID())
				{
					Node->SetOwnerDialogueEpisode(Episode);
				}
			}
			else 
			{
				EpisodesAdded.Add(Episode);
			}
		}
	}

	for(UKGSLDialogueEpisode* Episode : EpisodesAdded)
	{
		UEpisodeGraphNode* ResultNode = CreateEpisodeNode(nullptr, true, FVector2D::ZeroVector);
		ResultNode->SetOwnerDialogueEpisode(Episode);
	}
}

void UEpisodeGraph::OnEpisodeRemoved()
{
	UDialogueAsset* Asset = GetDialogueAsset();
	if(!IsValid(Asset))
	{
		return;
	}

	TArray<TObjectPtr<class UEdGraphNode>> EpisodeNodePendingRemoved;
	for(auto Node : Nodes)
	{
		if(UEpisodeGraphNode* NodePtr = Cast<UEpisodeGraphNode>(Node.Get()))
		{
			if(!Asset->GetDialogueEpisodeByEpisodeID(NodePtr->GetEpisodeID()))
			{
				EpisodeNodePendingRemoved.Add(Node);
			}
		}
	}

	for(auto Node : EpisodeNodePendingRemoved)
	{
		RemoveNode(Node.Get());
	}
}

void UEpisodeGraph::NotifyGraphChanged()
{
	UEdGraph::NotifyGraphChanged();
}

void UEpisodeGraph::NotifyGraphChanged(const FEdGraphEditAction& Action)
{
	UEdGraph::NotifyGraphChanged(Action);
}