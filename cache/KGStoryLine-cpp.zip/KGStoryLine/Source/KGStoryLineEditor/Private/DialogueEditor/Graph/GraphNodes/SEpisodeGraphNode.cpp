// Copyright 2020 Kuai, Inc. All Rights Reserved.

#include "DialogueEditor/Graph/GraphNodes/SEpisodeGraphNode.h"
#include "DialogueEditor/Graph/GraphNodes/EpisodeGraphNode.h"
#include "SGraphPanel.h"

//=============================================================================
/**
 * SLevelFlowGraphNode_CondBase
 */
void SEpisodeGraphEntryNode::Construct(const FArguments& InArgs, class UEpisodeGraphEntryNode* InNode)
{
	GraphNode = InNode;
	SetCursor(EMouseCursor::CardinalCross);

	if (GraphNode)
	{
		UpdateGraphNode();
	}

	SetEnabled(false);
}

void SEpisodeGraphEntryNode::UpdateGraphNode()
{
	SGraphNode::UpdateGraphNode();
	/*
	RightNodeBox.Reset();
	LeftNodeBox.Reset();

	this->ContentScale.Bind(this, &SGraphNode::GetContentScale);

	bool SupportsBubble = true;
	if (GraphNode != nullptr)
	{
		SupportsBubble = GraphNode->SupportsCommentBubble();
	}
	*/
}

TSharedRef<SWidget> SEpisodeGraphEntryNode::CreatTitleWidget()
{
	return SNullWidget::NullWidget;
}

TSharedRef<SWidget> SEpisodeGraphEntryNode::CreatBodyWidget()
{
	return SNullWidget::NullWidget;
}

void SEpisodeGraphEntryNode::OnDragEnter(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	TSharedPtr<FDragDropOperation> Operation = DragDropEvent.GetOperation();
	if (!Operation.IsValid())
	{
		return;
	}

	return SGraphNode::OnDragEnter(MyGeometry, DragDropEvent);
}

FReply SEpisodeGraphEntryNode::OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	bool bReadOnly = OwnerGraphPanelPtr.IsValid() ? !OwnerGraphPanelPtr.Pin()->IsGraphEditable() : false;
	TSharedPtr<FDragDropOperation> Operation = DragDropEvent.GetOperation();
	if (!Operation.IsValid() || bReadOnly)
	{
		return FReply::Unhandled();
	}

	return SGraphNode::OnDrop(MyGeometry, DragDropEvent);
}


FText SEpisodeGraphEntryNode::GetNodeTitle() const
{
	return FText::FromString(TEXT("EntryNode"));
}

FText SEpisodeGraphEntryNode::GetNodeBody() const
{
	return FText::FromString(TEXT("EntryNodeBody"));
}

FSlateColor SEpisodeGraphEntryNode::GetNodeBackgroundColor() const
{
	return FSlateColor(FLinearColor(0, 1, 0, 1));
}

FReply SEpisodeGraphEntryNode::OnMouseDown(const FGeometry& SenderGeometry, const FPointerEvent& MouseEvent)
{
	GetOwnerPanel()->SelectionManager.ClickedOnNode(GraphNode, MouseEvent);
	return FReply::Handled();
}

FSlateColor SEpisodeGraphEntryNode::GetBorderBackgroundColor() const
{
	return FLinearColor::Red;
}

void SEpisodeGraphNode::Construct(const FArguments& InArgs, class UEpisodeGraphNode* InNode)
{
	GraphNode = InNode;
	SetCursor(EMouseCursor::CardinalCross);

	if (GraphNode)
	{
		UpdateGraphNode();
	}

	SetEnabled(false);
}

#undef LOCTEXT_NAMESPACE
