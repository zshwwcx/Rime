//author yaoliwen@kuaishou.com 2024.9.18

#include "DialogueEditor/Graph/SOptionGraph.h"
#include "DialogueEditor/Graph/OptionGraph.h"
#include "DialogueEditor/Graph/OptionGraphSchema.h"
#include "Framework/Commands/GenericCommands.h"
#include "ScopedTransaction.h"

void SOptionGraph::Construct(const FArguments& InArgs)
{
	Condition = InArgs._Condition;
	ExtraAction = InArgs._ExtraAction;
	EpisodeID = InArgs._EpisodeID;
	DialogueLineIndex = InArgs._DialogueLineIndex;
	DialogueAssetEditing = InArgs._DialogueAssetEditing;
	//创建图表对象
	UOptionGraph* GraphObj = NewObject<UOptionGraph>();
	GraphObject = GraphObj;
	GraphObj->SetCondition(Condition, ExtraAction, EpisodeID, DialogueLineIndex, DialogueAssetEditing);
	GraphObj->Schema = UOptionGraphSchema::StaticClass();
	GraphObj->AddToRoot();
	GraphObj->RebuildGraph();

	CreateCommandList();
	//创建图表编辑器控件
	GraphEditor = SNew(SGraphEditor)
		.GraphToEdit(GraphObj)
		.AdditionalCommands(GraphEditorCommands);
	
	//指定本控件的UI：
	ChildSlot
		[
			GraphEditor.ToSharedRef()
		];
}

void SOptionGraph::CreateCommandList()
{
	if (GraphEditorCommands.IsValid())
	{
		return;
	}

	GraphEditorCommands = MakeShareable(new FUICommandList);

	GraphEditorCommands->MapAction(
		FGenericCommands::Get().Delete,
		FExecuteAction::CreateRaw(this, &SOptionGraph::DeleteSelectedNodes),
		FCanExecuteAction::CreateRaw(this, &SOptionGraph::CanDeleteNodes));
}

FVector2D SOptionGraph::ComputeDesiredSize(float) const
{
	return FVector2D(1152, 768);
}

void SOptionGraph::DeleteSelectedNodes()
{
	if (!GraphEditor.IsValid())
	{
		return;
	}

	const FScopedTransaction Transaction(FGenericCommands::Get().Delete->GetDescription());
	GraphEditor->GetCurrentGraph()->Modify();

	const FGraphPanelSelectionSet SelectedNodes = GraphEditor->GetSelectedNodes();
	GraphEditor->ClearSelectionSet();

	const UOptionGraphSchema* Schema = Cast<UOptionGraphSchema>(GraphObject->GetSchema());
	for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
	{
		if (UEdGraphNode* Node = Cast<UEdGraphNode>(*NodeIt))
		{
			if(Schema->SafeDeleteNodeFromGraph(GraphEditor->GetCurrentGraph(), Node))
			{
				GraphObject->DeleteNode(Node);
			}
		}
	}
}

bool SOptionGraph::CanDeleteNodes() const
{
	return false;
	// const FGraphPanelSelectionSet SelectedNodes = GraphEditor->GetSelectedNodes();
	//
	// for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
	// {
	// 	if (UOptionGraphNode* Node = Cast<UOptionGraphNode>(*NodeIt))
	// 	{
	// 		//不允许删除OptionGraphNode
	// 		return false;
	// 	}
	// }
	//
	// return true;
}

FString SOptionGraph::GetCondition()
{
	return GraphObject->GetCondition();
}

void SOptionGraph::SetCondition(FString& InCondition, TArray<FString>& InExtraAction, int32 InEpisodeID, int32 InDialogueLineIndex, TWeakObjectPtr<UDialogueAsset> InDialogueAssetEditing)
{
	Condition = InCondition;
	ExtraAction = InExtraAction;
	EpisodeID = InEpisodeID;
	DialogueLineIndex = InDialogueLineIndex;
	DialogueAssetEditing = InDialogueAssetEditing;
	GraphObject->Modify();
	GraphObject->SetCondition(InCondition, InExtraAction, InEpisodeID, InDialogueLineIndex, InDialogueAssetEditing);
	GraphObject->RebuildGraph();
}

TArray<FString> SOptionGraph::GetExtraAction()
{
	return GraphObject->GetExtraAction();
}

int32 SOptionGraph::GetEpisodeID()
{
	return GraphObject->GetEpisodeID();
}

int32 SOptionGraph::GetDialogueLineIndex()
{
	return GraphObject->GetDialogueLineIndex();
}
