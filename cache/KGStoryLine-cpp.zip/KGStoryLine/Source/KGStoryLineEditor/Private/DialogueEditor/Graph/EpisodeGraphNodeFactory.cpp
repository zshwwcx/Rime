// Copyright 2020 Kuai, Inc. All Rights Reserved.

#include "DialogueEditor/Graph/EpisodeGraphNodeFactory.h"
#include "DialogueEditor/Graph/GraphNodes/EpisodeGraphNode.h"
#include "DialogueEditor/Graph/GraphNodes/SEpisodeGraphNode.h"

TSharedPtr<class SGraphNode> FEpisodeGraphNodeFactory::CreateNode(UEdGraphNode* Node) const
{
	if (UEpisodeGraphEntryNode* EntryNode = Cast<UEpisodeGraphEntryNode>(Node))
	{
		TSharedRef<SGraphNode> GraphNode = SNew(SEpisodeGraphEntryNode, EntryNode);
		GraphNode->SlatePrepass();
		return GraphNode;
	}
	else if (UEpisodeGraphNode* EpisodeNode = Cast<UEpisodeGraphNode>(Node))
	{
		TSharedRef<SGraphNode> GraphNode = SNew(SEpisodeGraphNode, EpisodeNode);
		GraphNode->SlatePrepass();
		return GraphNode;
	}
	return nullptr;
}
