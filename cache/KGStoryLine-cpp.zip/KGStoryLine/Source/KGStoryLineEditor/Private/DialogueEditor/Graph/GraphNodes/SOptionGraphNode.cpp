//author yaoliwen@kuaishou.com 2024.9.18

#include "DialogueEditor/Graph/GraphNodes/SOptionGraphNode.h"
#include "DialogueEditor/Graph/GraphNodes/OptionGraphNode.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/SBoxPanel.h"
#include "EditorStyleSet.h"
#include "Widgets/Layout/SBox.h"
#include "GraphEditorSettings.h"
#include "Widgets/Input/SEditableTextBox.h"

#define LOCTEXT_NAMESPACE "SOptionGraphNode"

void SOptionGraphNode::Construct(const FArguments& InArgs, UOptionGraphNode* InNode)
{
	GraphNode = InNode;
	SetEnabled(false);
	UpdateGraphNode();
}

/*
void SOptionGraphNode::UpdateGraphNode()
{
	RightNodeBox.Reset();
	LeftNodeBox.Reset();
	//控件界面：
	GetOrAddSlot(ENodeZone::Center)
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SBorder)
						.BorderImage(FEditorStyle::GetBrush("Graph.Node.Body"))
						.Padding(0)
						[
							SNew(SVerticalBox)
								+ SVerticalBox::Slot()
								.AutoHeight()
								.HAlign(HAlign_Fill)
								.VAlign(VAlign_Top)
								[
									// NODE CONTENT AREA
									SNew(SBorder)
										.BorderImage(FEditorStyle::GetBrush("NoBorder"))
										.HAlign(HAlign_Fill)
										.VAlign(VAlign_Fill)
										.Padding(FMargin(0, 3))
										[
											SNew(SHorizontalBox)
												+ SHorizontalBox::Slot()
												.AutoWidth()
												.VAlign(VAlign_Center)
												[
													// LEFT
													SNew(SBox)
														.WidthOverride(40)
														[
															SAssignNew(LeftNodeBox, SVerticalBox)
														]
												]

												+ SHorizontalBox::Slot()
												.VAlign(VAlign_Center)
												.HAlign(HAlign_Center)
												.FillWidth(1.0f)
												[
													SNew(STextBlock).Text(FText::FromString(((UOptionGraphNode*)GraphNode)->TestInfo))
												]

												+ SHorizontalBox::Slot()
												.AutoWidth()
												.VAlign(VAlign_Center)
												[
													// RIGHT
													SNew(SBox)
														.WidthOverride(40)
														[
															SAssignNew(RightNodeBox, SVerticalBox)
														]
												]
										]
								]
						]
				]
		];
	CreatePinWidgets();
}
*/

void SOptionGraphNoParamNode::Construct(const FArguments& InArgs, UOptionGraphNoParamNode* InNode)
{
	GraphNode = InNode;
	SetEnabled(false);
	UpdateGraphNode();
}


void SOptionGraphOneParamNode::Construct(const FArguments& InArgs, UOptionGraphOneParamNode* InNode)
{
	GraphNode = InNode;
	SetEnabled(false);
	UpdateGraphNode();
}

TSharedRef<SWidget> SOptionGraphOneParamNode::CreateNodeContentArea()
{
	TSharedRef<SWidget> ContentAreaWidget = SGraphNode::CreateNodeContentArea();
	UOptionGraphOneParamNode* OptionNode = Cast<UOptionGraphOneParamNode>(GraphNode);
	TSharedPtr<SVerticalBox> VertContainer = SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		.VAlign(VAlign_Center)
		[
			SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Center)
				.AutoWidth()
				.Padding(Settings->GetInputPinPadding())
				[

					SNew(STextBlock)
						.Text(FText::FromString(OptionNode->ParamName))
				]
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Center)
				.AutoWidth()
				[
					SNew(SEditableTextBox)
						.OnTextCommitted_Lambda([this](const FText& NewText, ETextCommit::Type CommitType)
							{
								if (UOptionGraphOneParamNode* OptionNode = Cast<UOptionGraphOneParamNode>(GraphNode))
								{
									OptionNode->Param = FCString::Atoi(*NewText.ToString());
								}
							})
						.Text_Lambda([this]()
							{
								if (UOptionGraphOneParamNode* OptionNode = Cast<UOptionGraphOneParamNode>(GraphNode))
								{
									return FText::FromString(FString::FromInt(OptionNode->Param));
								}
								return FText();
							})
				]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			ContentAreaWidget
		];
	TSharedRef<SWidget> RetWidget = VertContainer.ToSharedRef();
	return RetWidget;
}


#undef LOCTEXT_NAMESPACE

void SOptionGraphActionNoParamNode::Construct(const FArguments& InArgs, UOptionGraphActionNoParamNode* InNode)
{
	GraphNode = InNode;
	SetEnabled(false);
	UpdateGraphNode();
}

void SOptionGraphActionOneParamNode::Construct(const FArguments& InArgs, UOptionGraphActionOneParamNode* InNode)
{
	GraphNode = InNode;
	SetEnabled(false);
	UpdateGraphNode();
}

TSharedRef<SWidget> SOptionGraphActionOneParamNode::CreateNodeContentArea()
{
	TSharedRef<SWidget> ContentAreaWidget = SGraphNode::CreateNodeContentArea();
	UOptionGraphActionOneParamNode* OptionNode = Cast<UOptionGraphActionOneParamNode>(GraphNode);
	TSharedPtr<SVerticalBox> VertContainer = SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		.VAlign(VAlign_Center)
		[
			SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Center)
				.AutoWidth()
				.Padding(Settings->GetInputPinPadding())
				[

					SNew(STextBlock)
						.Text(FText::FromString(OptionNode->ParamName))
				]
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Center)
				.AutoWidth()
				[
					SNew(SEditableTextBox)
						.OnTextCommitted_Lambda([this](const FText& NewText, ETextCommit::Type CommitType)
							{
								if (UOptionGraphActionOneParamNode* OptionNode = Cast<UOptionGraphActionOneParamNode>(GraphNode))
								{
									OptionNode->Param = FCString::Atoi(*NewText.ToString());
								}
							})
						.Text_Lambda([this]()
							{
								if (UOptionGraphActionOneParamNode* OptionNode = Cast<UOptionGraphActionOneParamNode>(GraphNode))
								{
									return FText::FromString(FString::FromInt(OptionNode->Param));
								}
								return FText();
							})
				]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			ContentAreaWidget
		];
	TSharedRef<SWidget> RetWidget = VertContainer.ToSharedRef();
	return RetWidget;
}

void SOptionGraphActionMultiParamNode::Construct(const FArguments& InArgs, UOptionGraphActionMultiParamNode* InNode)
{
	GraphNode = InNode;
	SetEnabled(false);
	UpdateGraphNode();
}

TSharedRef<SWidget> SOptionGraphActionMultiParamNode::CreateNodeContentArea()
{
	TSharedRef<SWidget> ContentAreaWidget = SGraphNode::CreateNodeContentArea();
	UOptionGraphActionMultiParamNode* OptionNode = Cast<UOptionGraphActionMultiParamNode>(GraphNode);
	TSharedPtr<SVerticalBox> VertContainer = SNew(SVerticalBox)
		.IsEnabled(false);
	for(int Idx = 0; Idx < OptionNode->ParamNames.Num(); Idx++)
	{
		VertContainer->AddSlot()
			.AutoHeight()
			.VAlign(VAlign_Center)
			[
				SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.HAlign(HAlign_Center)
					.AutoWidth()
					.Padding(Settings->GetInputPinPadding())
					[

						SNew(STextBlock)
							.Text(FText::FromString(OptionNode->ParamNames[Idx]))
					]
					+ SHorizontalBox::Slot()
					.HAlign(HAlign_Center)
					.AutoWidth()
					[
						SNew(SEditableTextBox)
							.OnTextCommitted_Lambda([this, Idx](const FText& NewText, ETextCommit::Type CommitType)
								{
									if (UOptionGraphActionMultiParamNode* OptionNode = Cast<UOptionGraphActionMultiParamNode>(GraphNode))
									{
										OptionNode->Params[Idx] = NewText.ToString();
									}
								})
							.Text_Lambda([this, Idx]()
								{
									if (UOptionGraphActionMultiParamNode* OptionNode = Cast<UOptionGraphActionMultiParamNode>(GraphNode))
									{
										return FText::FromString(OptionNode->Params[Idx]);
									}
									return FText();
								})
					]
			];
	}
	
	VertContainer->AddSlot()
		.AutoHeight()
		[
			ContentAreaWidget
		];
	TSharedRef<SWidget> RetWidget = VertContainer.ToSharedRef();
	return RetWidget;
}

void SOptionGraphJumpNode::Construct(const FArguments& InArgs, UOptionGraphJumpNode* InNode)
{
	GraphNode = InNode;
	SetEnabled(false);
	LineContent = SNew(SHorizontalBox).IsEnabled(false);
	UpdateGraphNode();
}

TSharedRef<SWidget> SOptionGraphJumpNode::CreateNodeContentArea()
{
	RebuildLinesBox();
	TSharedRef<SWidget> ContentAreaWidget = SGraphNode::CreateNodeContentArea();
	UOptionGraphJumpNode* OptionNode = Cast<UOptionGraphJumpNode>(GraphNode);
	TSharedPtr<SVerticalBox> VertContainer = SNew(SVerticalBox);
	for (int Idx = 0; Idx < OptionNode->ParamNames.Num(); Idx++)
	{
		VertContainer->AddSlot()
			.AutoHeight()
			.VAlign(VAlign_Center)
			[
				SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.HAlign(HAlign_Center)
					.AutoWidth()
					.Padding(Settings->GetInputPinPadding())
					[

						SNew(STextBlock)
							.Text(FText::FromString(OptionNode->ParamNames[Idx]))
					]
					+ SHorizontalBox::Slot()
					.HAlign(HAlign_Center)
					.AutoWidth()
					[
						SNew(SEditableTextBox)
							.OnTextCommitted_Lambda([this, Idx](const FText& NewText, ETextCommit::Type CommitType)
								{
									if (UOptionGraphJumpNode* OptionNode = Cast<UOptionGraphJumpNode>(GraphNode))
									{
										OptionNode->Params[Idx] = FCString::Atoi(*NewText.ToString());
										RebuildLinesBox();
									}
								})
							.Text_Lambda([this, Idx]()
								{
									if (UOptionGraphJumpNode* OptionNode = Cast<UOptionGraphJumpNode>(GraphNode))
									{
										return FText::FromString(FString::FromInt(OptionNode->Params[Idx]));
									}
									return FText();
								})
					]
			];
	}

	
	VertContainer->AddSlot()
	.AutoHeight()
		.VAlign(VAlign_Center)
		[
			LineContent.ToSharedRef()
		];
	VertContainer->AddSlot()
		.AutoHeight()
		[
			ContentAreaWidget
		];
	TSharedRef<SWidget> RetWidget = VertContainer.ToSharedRef();
	return RetWidget;
}

void SOptionGraphJumpNode::RebuildLinesBox() const
{
	LineContent->ClearChildren();
	UOptionGraphJumpNode* OptionNode = Cast<UOptionGraphJumpNode>(GraphNode);
	FString JumpContent;
	int32 EpisodeID = OptionNode->Params[0];
	int32 DialogueLineIndex = OptionNode->Params[1];
	UKGSLDialogueEpisode* Script = OptionNode->DialogueAssetEditing->GetDialogueEpisodeByEpisodeID(EpisodeID);
	if(Script)
	{
		if (DialogueLineIndex == 0)
		{
			JumpContent = TEXT("从第0帧开始");
		}
		else if (DialogueLineIndex > 0 && DialogueLineIndex <= Script->DialogueLines.Num())
		{
			JumpContent = Script->DialogueLines[DialogueLineIndex-1]->ContentString;
			if(JumpContent.IsEmpty())
			{
				JumpContent = TEXT("对话小段第几句 配置为空");
			}
		}
		else
		{
			JumpContent = FString::Printf(TEXT("error, 从对话小段第几句开始 非法,找不到 %d"), DialogueLineIndex);
		}
	}
	else
	{
		JumpContent = FString::Printf(TEXT("error, 本选项跳转的对话小段 非法,找不到 %d"), EpisodeID);
	}
	LineContent->AddSlot()
		.HAlign(HAlign_Center)
		.FillWidth(60)
		.Padding(Settings->GetInputPinPadding())
		[
			SNew(STextBlock)
				.Text(FText::FromString(JumpContent))
				.AutoWrapText(true)
		];
}
