#include "DialogueEditor/DialogueEditorManager.h"
//#include "UnLua/Public/UnLuaDelegates.h"
#include "AssetThumbnail.h"
#include "3C/Character/BaseCharacter.h"
#include "DialogueEditor/Dialogue/Actions/DialogueAutoCameraCut.h"
#include "Localization/LocalizationManager.h"
#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "JsonObjectConverter.h"
#include "Misc/FileHelper.h"
#include "Serialization/JsonSerializer.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorPreviewProxy.h"
#include "DialogueEditor/DialogueEditorSceneProxy.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "DialogueEditor/DialogueGossipBubbleManager.h"
#include "EditorAssetLibrary.h"
#include "SceneView.h"
#include "DialogueEditor/Dialogue/DialogueCommon.h"
#include "Misc/MessageDialog.h"
#include "Camera/CameraShakeBase.h"
#include "Camera/CameraShakeSourceComponent.h"
#include "Misc/ScopedSlowTask.h"
#include "DialogueEditor/DialogueEditorPreviewSettings.h"
#include "SourceControlHelpers.h"
#include "Subsystems/UnrealEditorSubsystem.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"
#include "Framework/Notifications/NotificationManager.h"
#include "DialogueEditor/LuaAsset/LuaAssetHelper.h"
#include "DialogueEditor/LuaAsset/PerforceTaskHelper.h"
#include "UObject/SavePackage.h"
#include "DialogueEditor/Util/KGSLEdJson2LuaCodeTranslator.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "EngineUtils.h"
#include "3C/Core/KGUEActorManager.h"
#include "Camera/CameraActor.h"
#include "Camera/PlayerCameraManager.h"
#include "Runtime/CinematicCamera/Public/CineCameraActor.h"
#include "GameFramework/PlayerController.h"
#include "LevelSequencePlayer.h"
#include "LevelSequence.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/WidgetComponent.h"
#include "DialogueEditor/LuaAsset/DialogueExporter.h"
#include "LuaSerialization/Serialization/LuaSerializer.h"
#include "LuaSerialization/Serialization/LuaWriter.h"
#include "Sections/MovieSceneCameraCutSection.h"
#include "Tracks/MovieSceneCameraCutTrack.h"
#include "Framework/Application/SlateApplication.h"


#define LOCTEXT_NAMESPACE "DialogueEditorManager"

bool GKGSLUseLuaSerializer = true;
static FAutoConsoleVariableRef CVarKGSLUseLuaSerializer(
	TEXT("KGSL.UseLuaSerializer"),
	GKGSLUseLuaSerializer,
	TEXT("If this is true, dialogue will use lua serializer\n")
);

bool GKGSLExportDefaultValue = false;
static FAutoConsoleVariableRef CVarGKGSLExportDefaultValue(
	TEXT("KGSL.ExportDefaultValue"),
	GKGSLExportDefaultValue,
	TEXT("If this is true, dialogue will export CDO value to lua asset.")
	);

TSharedPtr<FJsonObject> ExportDialogueTrackJson(UDialogueBaseAsset* Template, UDialogueSpawnableTrack* SpawnableTrack)
{
	TSharedPtr<FJsonObject> Ret = MakeShared<FJsonObject>();

	UDialogueEntity* DialogueEntity = SpawnableTrack->GetDialogueEntity();

	if (SpawnableTrack->IsA(UDialogueCameraTrack::StaticClass()))
		Ret->SetStringField(TEXT("TrackType"), TEXT("Camera"));
	else if (SpawnableTrack->IsA(UDialogueActorTrack::StaticClass()))
		Ret->SetStringField(TEXT("TrackType"), TEXT("Actor"));

	Ret->SetStringField(TEXT("TrackName"), *FTextInspector::GetSourceString(SpawnableTrack->GetTrackName()));

	FString TransformStr;

	FProperty* SpawnTransformProperty = UDialogueEntity::StaticClass()->FindPropertyByName(GET_MEMBER_NAME_CHECKED(UDialogueEntity, SpawnTransform));
	FTransform* ValuePtr = SpawnTransformProperty->ContainerPtrToValuePtr<FTransform>(DialogueEntity);
	SpawnTransformProperty->ExportTextItem_Direct(TransformStr, ValuePtr, nullptr, nullptr, 0);

	Ret->SetStringField(TEXT("Transform"), TransformStr);

	TArray<TSharedPtr<FJsonValue>> ChildJsonValue;
	for (UDialogueTrackBase* Child : SpawnableTrack->Childs)
	{
		if (UDialogueSpawnableTrack* ChildSpawnableTrack = Cast<UDialogueSpawnableTrack>(Child))
		{
			TSharedPtr<FJsonObject> ChildJsonObject = ExportDialogueTrackJson(Template, ChildSpawnableTrack);
			ChildJsonValue.Add(MakeShared<FJsonValueObject>(ChildJsonObject));
		}
	}

	Ret->SetArrayField("Childs", ChildJsonValue);
	return Ret;
}

void UDialogueEditorManager::SaveAsset(UDialogueAsset* DialogueAsset)
{
	if(!DialogueAsset || !IsValid(DialogueAsset))
	{
		return;
	}

	
	UPackage* Package = DialogueAsset->GetPackage();
	ensure(Package != nullptr);

	FString Path = Package->GetPathName();
	int32 Index = INDEX_NONE;
	if(Path.FindLastChar(TEXT('.'), Index))
	{
		Path = Path.Left(Index);
	}
	 Path.RemoveFromStart(TEXT("/Game/"));

	Path = FPaths::ProjectContentDir() + Path + TEXT(".uasset");
	Path = FPaths::ConvertRelativePathToFull(Path);
	if (FPaths::FileExists(Path))
	{
		bool CheckOutSuccess = USourceControlHelpers::CheckOutOrAddFile(Path, true);
		if (!CheckOutSuccess)
		{
			UE_LOG(LogTemp, Warning, TEXT("check out file %s failed, check your editor p4 connection!"), *Path);
		}
	}

	FString PackageName = Package->GetName();
	FString PackageFileName = FPackageName::LongPackageNameToFilename(PackageName, FPackageName::GetAssetPackageExtension());
	FSavePackageArgs SaveArgs;
	SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
	SaveArgs.SaveFlags = SAVE_NoError;
	UPackage::SavePackage(Package, DialogueAsset, *PackageFileName, SaveArgs);
}

void UDialogueEditorManager::ExportJson(UDialogueAsset* DialogueAsset, const FString& FileName)
{
	UDialogueBaseAsset* Template = DialogueAsset->DialogueTemplate;
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();

	FDialogueEpisode& FirstEpisode = Template->Episodes[0];

	TSharedPtr<FJsonObject> TrackListValue = MakeShared<FJsonObject>();

	TArray<TSharedPtr<FJsonValue>> ChildJsonValue;
	for (UDialogueTrackBase* TrackBase : FirstEpisode.TrackList)
	{
		if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(TrackBase))
		{
			TSharedPtr<FJsonObject> TrackListElementValue = ExportDialogueTrackJson(Template, SpawnableTrack);
			ChildJsonValue.Add(MakeShared<FJsonValueObject>(TrackListElementValue));
		}
	}
	Result->SetArrayField("TrackList", ChildJsonValue);

	FString OutString;
	TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR> > > JsonWriter = TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR> >::Create(&OutString, 0);
	bool bSuccess = FJsonSerializer::Serialize(Result.ToSharedRef(), JsonWriter);


	FFileHelper::SaveStringToFile(OutString, *FileName);
}

void UDialogueEditorManager::ExecuteGenerationCommand()
{
	if (DialogueEditor.IsValid())
	{
		auto Editor = DialogueEditor.Pin();
		if (auto MainEditor = StaticCastSharedPtr<FDialogueMainEditor>(Editor))
		{
			MainEditor->GenerateDialogue();
		}
	}
}

void UDialogueEditorManager::BeginBatch(int Count,FText Text)
{
	if (BatchAssistScopeTask.IsValid())
	{
		 BatchAssistScopeTask.Reset();
	}
	
	BatchAssistScopeTask = MakeShareable<FScopedSlowTask>( new FScopedSlowTask(Count, Text));
	BatchAssistScopeTask->MakeDialog();
}

void UDialogueEditorManager::AddTaskAmount(int32 TaskAmount) const
{
	if(BatchAssistScopeTask.IsValid())
	{
		BatchAssistScopeTask->TotalAmountOfWork += TaskAmount;
	}
}

void UDialogueEditorManager::IncreaseProgress()
{
	if (BatchAssistScopeTask.IsValid())
	{
		BatchAssistScopeTask->EnterProgressFrame(1.0f);
	}
}

void UDialogueEditorManager::EndBatch()
{
	if (BatchAssistScopeTask.IsValid())
	{
		BatchAssistScopeTask.Reset();
	}
}

bool UDialogueEditorManager::ExportAsLuaTable(UDialogueBaseAsset* DialogueAsset,bool bInUseCommandlet/* = false*/)
{
	SCOPED_NAMED_EVENT(ExportAsLuaTable, FColor::Magenta)
	if(DialogueAsset == nullptr)
	{
		return false;	
	}

	if (!USourceControlHelpers::IsAvailable() && !bInUseCommandlet)
	{
		//ShowMessageBoxForce(TEXT("请检查UE的P4连接！未连接会导致导出lua异常！本次导出失败!"));
		return false;
	}
	
	FString AssetName = DialogueAsset->GetName();
	TSharedPtr<FLuaTable> LuaTable = MakeShareable(new FLuaTable());
	TSharedPtr<FDialogueExporter> DialogueLuaExporter = MakeShared<FDialogueExporter>();
	DialogueLuaExporter->SetExportDefaultValue(GKGSLExportDefaultValue);
	DialogueLuaExporter->ExportObjectToLua(DialogueAsset, LuaTable);

	if (!GKGSLUseLuaSerializer)
	{
		FLuaAssetHelper::ExportEditorOnlyInfoToLuaTable(DialogueAsset, LuaTable);
	}
	else
	{
		UE_LOG(LogInit, Log, TEXT("[KGSL]new lua serialize!!!"));
		TSharedPtr<FLuaTable> EditorLuaTable = MakeShareable(new FLuaTable());
		// TSharedPtr<FLuaEditorInfoExporter> DialogueLuaEditorExporter = MakeShared<FLuaEditorInfoExporter>();
		// DialogueLuaEditorExporter->ExportObjectToLua(DialogueAsset, EditorLuaTable);
		auto DialogueEditorExporter = MakeShared<FDialogueEditorInfoExporter>();
		DialogueEditorExporter->JustExportEditorOnlyInfoToLua(DialogueAsset, EditorLuaTable);
		LuaTable->SetField("ZZZ_EditorOnly", MakeShared<FLuaValueTable>(EditorLuaTable));
	}

	FString LuaStr;
	const TSharedRef<TLuaWriter<>> LuaWriter = TLuaWriterFactory<>::Create(&LuaStr);
	FLuaSerializer::Serialize(LuaTable.ToSharedRef(), LuaWriter);
	
	// 导出Lua表
	FString TemporaryLuaFile = FPaths::ProjectDir() + TEXT("Content/Script/Data/Config/Dialogue/");
	TemporaryLuaFile = TemporaryLuaFile + AssetName + TEXT(".lua");
	FString FullPath = FPaths::ConvertRelativePathToFull(TemporaryLuaFile);
	
	if (!FFileHelper::SaveStringToFile(LuaStr, *TemporaryLuaFile, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
	{
		UE_LOG(LogTemp, Warning, TEXT("save file %s failed"), *TemporaryLuaFile);
		return false;
	}
	
	if (FPaths::FileExists(FullPath) && !bUseCommandlet)
	{
		if (!USourceControlHelpers::CheckOutOrAddFile(FullPath))
		{
			UE_LOG(LogTemp, Warning, TEXT("check out file %s failed, check your editor p4 connection!"), *TemporaryLuaFile);
			return false;
		}
		DialogueAsset->GetPackage()->ClearDirtyFlag();
	}
	
	//导完可能没改变，就revert掉
	if (!bUseCommandlet)
	{
		USourceControlHelpers::RevertUnchangedFile(FullPath, true);	
	}
	
	return true;
}

bool UDialogueEditorManager::ExportIfNeedWhenInitialize(UDialogueBaseAsset* DialogueAsset)
{
	FString AssetName = DialogueAsset->GetName();
	FString TemporaryLuaFile = FPaths::ProjectDir() + TEXT("Content/Script/Data/Config/Dialogue/");
	TemporaryLuaFile = TemporaryLuaFile + AssetName + TEXT(".lua");
	FString FullPath = FPaths::ConvertRelativePathToFull(TemporaryLuaFile);
	if (!FPaths::FileExists(FullPath))
	{
		return ExportAsLuaTable(DialogueAsset);
	}
	return true;
}

void UDialogueEditorManager::GenerateDialogueAndExportAsLuaTable(UDialogueAsset* DialogueAsset)
{
	GenerateDialogue(DialogueAsset);
	ForceExportLuaTable(DialogueAsset);
}

FString UDialogueEditorManager::ConvertJsonToLuaFile(TSharedPtr<FJsonObject> JsonObj, const FString& LuaFileName)
{
	SCOPED_NAMED_EVENT(ConvertJsonToLuaFile, FColor::Cyan);
	
	if (!JsonObj.IsValid())
	{
		return TEXT("");
	}

	FStringBuilderBase StringBuilder;
	StringBuilder.Append(TEXT("return "));
	FKGSLEdJson2LuaCodeTranslator Translator(JsonObj);
	FString StrTab = Translator.Translate(true);
	StringBuilder.Append(StrTab);
	StringBuilder.Append(TEXT("\n"));
	
	return FString(StringBuilder.Len(), StringBuilder.GetData());
}

void UDialogueEditorManager::SetCurrentEpisodeID(int EpisodeID, bool bForceRefreshUI)
{
	if (DialogueEditor.IsValid())
	{
		DialogueEditor.Pin()->SetCurrentSelectEpisode(EpisodeID, bForceRefreshUI);
	}
}

int UDialogueEditorManager::GetCurrentEpisodeID()
{
	if (DialogueEditor.IsValid())
	{
		return DialogueEditor.Pin()->GetCurrentEpisodeID();
	}

	return KGStoryLine::INVALID_EPISODE_ID;

}

void UDialogueEditorManager::SetSelectCameraComponent(class UCameraComponent* CameraComponent)
{
	if (DialogueEditor.IsValid())
	{
		DialogueEditor.Pin()->SetSelectCameraComponent(CameraComponent);
	}
}

UCameraComponent* UDialogueEditorManager::GetSelectCameraComponent()
{
	if (DialogueEditor.IsValid())
	{
		return DialogueEditor.Pin()->SelectCameraComponent.Get();
	}

	return nullptr;
}

UDialogueCamera* UDialogueEditorManager::GetCurrentLockCameraEntity()
{
	if (DialogueEditor.IsValid())
	{
		return DialogueEditor.Pin()->ClickCameraEntity.Get();
	}

	return nullptr;
}

FString UDialogueEditorManager::GetUClassPath(UClass* ClassPtr)
{
	if (ClassPtr)
		return ClassPtr->GetPathName();
	return TEXT("");
}

void UDialogueEditorManager::SetViewportLocationRotation(ACameraActor* CameraActor)
{
	if (DialogueEditor.IsValid())
	{
		DialogueEditor.Pin()->SetViewportParamByCameraActor(CameraActor);
	}
}

AActor* UDialogueEditorManager::GetSelectActor()
{
	if (DialogueEditor.IsValid())
	{
		return DialogueEditor.Pin()->GetSelectActor();
	}
	return nullptr;
}

UObject* UDialogueEditorManager::GetSoundAsset(UClass* AssetClass, const FString& SoundAssetName, bool ExactName)
{
	if(SoundAssetName.IsEmpty())
	{
		return nullptr;
	}

	FString SoundEventDir = GetDefault<UDialogueEditorSettings>()->GetWWiseEventsAbsPath();
	if(SoundEventDir.IsEmpty())
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("请在ProjectSeetins->DialogueEditorSettings中设置WWise Event所在目录")));
		return nullptr;
	}
	
	if(!FPaths::DirectoryExists(SoundEventDir))
	{
		FString Str = FString::Printf(TEXT("WWise Events的目录不存在：%s"), * SoundEventDir);
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Str));
		return nullptr;
	}

	TArray<FString> Files;	
	IFileManager::Get().FindFilesRecursive(Files, *SoundEventDir, *FString::Printf( TEXT("%s*.uasset"), *SoundAssetName),  true, false);
	if(Files.IsEmpty())
	{
		return nullptr;
	}
	
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName).Get();
	for(const auto& File : Files)
	{
		FString PackagePath;
		FPackageName::TryConvertFilenameToLongPackageName(File, PackagePath, nullptr);
		
		TArray<FAssetData> Assets;
		AssetRegistry.GetAssetsByPackageName(*PackagePath, Assets);
		for(const auto& Asset : Assets)
		{
			if(Asset.GetClass() == AssetClass)
			{
				if((ExactName && Asset.AssetName.IsEqual(*SoundAssetName))
					|| Asset.AssetName.ToString().Contains(SoundAssetName))
				{
						return Asset.GetAsset();
				}
			}
		}
	}

	return nullptr;
}

void UDialogueEditorManager::OnAddNewAutoCameraTrack()
{
	if (DialogueEditor.IsValid())
	{
		DialogueEditor.Pin()->DialogueTimelineController.Pin()->OnInternalAddAutoCameraTrack();
	}
}

class UObject* UDialogueEditorManager::GetAsset(UClass* AssetClass, const FString& AssetName, bool ExactName)
{
	if (AssetName.IsEmpty())
		return nullptr;
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName).Get();
	TArray<FAssetData> Assets;
	AssetRegistry.GetAssetsByClass(AssetClass->GetClassPathName(), Assets, /*bSearchSubClasses=*/true);

	//只在第一次显示进度弹窗，修复一个奇怪的弹窗崩溃问题
	bool ShowDialogue = false;
	if (!AlreadyScanedClass.Contains(AssetClass))
	{
		AlreadyScanedClass.Add(AssetClass);
		ShowDialogue = true;
	}
	if (ShowDialogue)
	{
		ShowMessageBox(FString::Printf(TEXT("为了自动匹配资源引用，需要扫描项目中所有的%s资源路径，Scaning..."), *AssetClass->GetName()));
	}

	for (const FAssetData& AssetData : Assets)
	{
		UObject* AssetObject = AssetData.GetAsset();
		if (AssetObject)
		{
			if (ExactName)
			{
				if (AssetObject->GetName() == AssetName)
				{
					return AssetObject;
				}
			}
			else
			{
				if (AssetObject->GetName().Contains(AssetName))
				{
					return AssetObject;
				}
			}
		}
	}
	return nullptr;
}

TArray<UObject*> UDialogueEditorManager::GetAllAsset(UClass* AssetClass)
{
	TArray<UObject*> Ret;

	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName).Get();
	TArray<FAssetData> Assets;
	AssetRegistry.GetAssetsByClass(AssetClass->GetClassPathName(), Assets, /*bSearchSubClasses=*/true);

	for (const FAssetData& AssetData : Assets)
	{
		Ret.Add(AssetData.GetAsset());
	}
	return Ret;
}

void UDialogueEditorManager::ShowMessageBox(const FString& msg)
{
	//有些情况，弹窗会造成崩溃？先注掉
	//FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(msg));
}

void UDialogueEditorManager::ShowMessageBoxForce(const FString& msg)
{
	FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(msg));
}

void UDialogueEditorManager::PushNotification(const FString& Msg, float Duration)
{
	const FText NotificationErrorText = FText::FromString(Msg);
	FNotificationInfo Info(NotificationErrorText);
	Info.ExpireDuration = Duration;
	FSlateNotificationManager::Get().AddNotification(Info);
}

bool Dialogue_Compare(const FVector& A, const FVector& B)
{
	bool XEqual = FMath::IsNearlyEqual(A.X, B.X, 0.001);
	bool YEqual = FMath::IsNearlyEqual(A.Y, B.Y, 0.001);
	bool ZEqual = FMath::IsNearlyEqual(A.Z, B.Z, 0.001);
	return XEqual && YEqual && ZEqual;
}

bool Dialogue_Compare(const FQuat& A, const FQuat& B)
{
	bool XEqual = FMath::IsNearlyEqual(A.X, B.X, 0.001);
	bool YEqual = FMath::IsNearlyEqual(A.Y, B.Y, 0.001);
	bool ZEqual = FMath::IsNearlyEqual(A.Z, B.Z, 0.001);
	bool WEqual = FMath::IsNearlyEqual(A.W, B.W, 0.001);
	return XEqual && YEqual && ZEqual && WEqual;
}
template<typename T>
bool Dialogue_CompareCurve(const T& A, const T& B)
{
	if (A.Points.Num() != B.Points.Num())
		return false;
	for (int i = 0; i < A.Points.Num(); ++i)
	{
		auto Point1 = A.Points[i];
		auto Point2 = B.Points[i];

		bool PointEqual = FMath::IsNearlyEqual(Point1.InVal, Point2.InVal, 0.001) &&
			//Point1.InterpMode == Point2.InterpMode &&
			Dialogue_Compare(Point1.OutVal, Point2.OutVal) &&
			Dialogue_Compare(Point1.ArriveTangent, Point2.ArriveTangent) &&
			Dialogue_Compare(Point1.LeaveTangent, Point2.LeaveTangent);
		if (!PointEqual)
			return false;
	}
	return true;
}
bool UDialogueEditorManager::CompareSplineCurves(const FSplineCurves& a, const FSplineCurves& b)
{
	bool PosEqual = Dialogue_CompareCurve(a.Position, b.Position);
	bool RotEqual = Dialogue_CompareCurve(a.Rotation, b.Rotation);
	bool SalEqual = Dialogue_CompareCurve(a.Scale, b.Scale);

	bool ret = a == b;
	bool overrideRet = PosEqual && RotEqual && SalEqual;
	return overrideRet;
}

bool UDialogueEditorManager::CompareVector(const FVector& a, const FVector& b)
{
	return Dialogue_Compare(a,b);
}

void UDialogueEditorManager::MarkModify(class UObject* Obj)
{
	if (Obj)
	{
		Obj->Modify(true);
	}
}

void UDialogueEditorManager::Initialize()
{
	UUnrealEditorSubsystem* UnrealEditorSubsystem = GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>();

	if (UnrealEditorSubsystem)
	{
		BigWorld = UnrealEditorSubsystem->GetEditorWorld();
	}
	FPerforceTaskHelper::SetP4WorkSpace();
	ReceiveInitialize();
}

void UDialogueEditorManager::UnInitialize()
{
	ReceiveUnInitialize();
}

FString UDialogueEditorManager::GetCurLevelPath()
{
	if (BigWorld.IsValid())
	{
		return BigWorld->GetOuter()->GetPathName();
	}
	return TEXT("");
}

void UDialogueEditorManager::OnEntityReady(const FString& TrackName, AActor* EntityActor)
{
	if(DialogueEditor.IsValid() && DialogueEditor.Pin()->GetPreviewScene())
	{
		DialogueEditor.Pin()->GetPreviewScene()->OnSpawnedEntity(TrackName, EntityActor);
	}
}

void UDialogueEditorManager::OnAllEntityReady()
{
	if(DialogueEditor.IsValid())
	{
		DialogueEditor.Pin()->OnAllEntityReady();
	}
}

UUserWidget* UDialogueEditorManager::CreateGossipBubbleWidget(int64 InEntityUid, const FString& InWidgetBPPath)
{
    if (DialogueEditor.IsValid())
    {
        auto SceneProxy = DialogueEditor.Pin()->GetPreviewScene();
        if (SceneProxy.IsValid() && SceneProxy->GossipBubbleManager.IsValid())
        {
            return SceneProxy->GossipBubbleManager.Pin()->CreateGossipBubble(InEntityUid, InWidgetBPPath);
        }
    }

    return nullptr;
}

void UDialogueEditorManager::RemoveGossipBubbleWidget(int64 InEntityUid)
{
    if (DialogueEditor.IsValid())
    {
        auto SceneProxy = DialogueEditor.Pin()->GetPreviewScene();
        if (SceneProxy.IsValid() && SceneProxy->GossipBubbleManager.IsValid())
        {
            return SceneProxy->GossipBubbleManager.Pin()->RemoveGossipBubble(InEntityUid);
        }
    }
}

void UDialogueEditorManager::SetUIRoot(UWidget* InUIRoot)
{
    if (DialogueEditor.IsValid())
    {
        auto SceneProxy = DialogueEditor.Pin()->GetPreviewScene();
        if (SceneProxy.IsValid() && SceneProxy->GossipBubbleManager.IsValid())
        {
            SceneProxy->GossipBubbleManager.Pin()->SetUIRoot(InUIRoot);
        }
    }
}

void UDialogueEditorManager::SetGameView(bool bGameView)
{
	if(DialogueEditor.IsValid() && DialogueEditor.Pin()->GetActiveViewportClient())
		DialogueEditor.Pin()->GetActiveViewportClient()->SetGameView(bGameView);
}

class UCameraShakeBase* UDialogueEditorManager::AddCameraShake(TSubclassOf<class UCameraShakeBase> ShakeClass, class UCameraShakeSourceComponent* ShakeSourceComponent)
{
	return DialogueEditor.Pin()->GetPreviewScene()->AddCameraShake(ShakeClass, ShakeSourceComponent);
}

void UDialogueEditorManager::AddCameraFrameRadio(bool InBVertical)
{
	if(DialogueEditor.IsValid())
	{
		DialogueEditor.Pin()->GetPreviewScene()->AddCameraFrameRadio(InBVertical);
	}
}

void UDialogueEditorManager::RemoveCameraFrameRadio()
{
	if(DialogueEditor.IsValid())
	{
		DialogueEditor.Pin()->GetPreviewScene()->RemoveCameraFrameRadio();
	}
}

void UDialogueEditorManager::SetPause(bool bPause)
{
	OnDialoguePlayerSetStateEvent.Broadcast(bPause);
}

FVector UDialogueEditorManager::GetViewLocation()
{
	FVector Ret;
	if (!DialogueEditor.IsValid())
	{
		return Ret;
	}
	
	if (DialogueEditor.Pin()->GetActiveViewportClient())
	{
		if(auto* ViewportClient = DialogueEditor.Pin()->GetActiveViewportClient())
		{
			Ret = ViewportClient->GetViewLocation();
		}
	}
	
	return Ret;
}

UDialogueBaseAsset* UDialogueEditorManager::GetCurrentAsset()
{
	return FBehaviorActorSelector::Owner.Get();
}

TArray<UDialogueTrackBase*> UDialogueEditorManager::GetShouldKeepTracks(FDialogueEpisode& Episode)
{
	const UDialogueEditorSettings* DialogueEditorSettings = GetDefault<UDialogueEditorSettings>();
	TArray<UDialogueTrackBase*> Ret;
	TArray<UDialogueTrackBase*> AllTracks = Episode.GetAllTracks();

	for (UDialogueTrackBase* TrackBase : AllTracks)
	{
		if (DialogueEditorSettings->GenerateNoneClearClass.Contains(TrackBase->GetClass()))
		{
			Ret.Add(TrackBase);
		}
	}
	return Ret;
}

bool UDialogueEditorManager::ContainsNoneGenerateClass(UObject* Obj)
{
	const UDialogueEditorSettings* DialogueEditorSettings = GetDefault<UDialogueEditorSettings>();
	return DialogueEditorSettings->GenerateNoneClearClass.Contains(Obj->GetClass());
}

void UDialogueEditorManager::SetMetaDataTag(UDialogueAsset* DialogueAsset)
{
	const FString KGSL_ID = UEditorAssetLibrary::GetMetadataTag(DialogueAsset, "KGSL.ID");
	const FString StoryLineID = FString::FromInt(DialogueAsset->StoryLineID);
	if (!KGSL_ID.Equals(StoryLineID))
	{
		UEditorAssetLibrary::SetMetadataTag(DialogueAsset, "KGSL.ID", StoryLineID);	
	}

	const FString KGSL_Ctt = UEditorAssetLibrary::GetMetadataTag(DialogueAsset, "KGSL.Ctt");
	FString Content;
	for(UKGSLDialogueEpisode* EpisodeLines : DialogueAsset->EpisodesList)
	{
		for (UKGSLDialogueLine* DialogueLine : EpisodeLines->DialogueLines)
		{
			if(IsValid(DialogueLine))
			{
				Content += DialogueLine->ContentString;
			}
		}
	}
	if (!KGSL_Ctt.Equals(Content))
	{
		UEditorAssetLibrary::SetMetadataTag(DialogueAsset, "KGSL.Ctt", Content);
	}
}

class UDialogueEditorSettings* UDialogueEditorManager::GetDialogueEditorSettings()
{
	UDialogueEditorSettings* DialogueEditorSettings = GetMutableDefault<UDialogueEditorSettings>();
	return DialogueEditorSettings;
}

void UDialogueEditorManager::EditorStop()
{
	if (DialogueEditor.IsValid())
	{
		DialogueEditor.Pin()->Stop();
	}
}

AActor* UDialogueEditorManager::SpawnTransientActorToWorld(UWorld* World, UClass* InClass, const FTransform& SpawnTransform)
{
	if(!World || !InClass)
	{
		return nullptr;
	}
	FActorSpawnParameters SpawnInfo;
	{
		SpawnInfo.ObjectFlags = RF_Transient | RF_Transactional;
		SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	}
	AActor* SpawnedActor = World->SpawnActorAbsolute(InClass, SpawnTransform, SpawnInfo);
	return SpawnedActor;
}

#pragma region Root
void UDialogueEditorManager::AddObjectToRoot(UObject* InObject)
{
	if (InObject)
	{
		InObject->AddToRoot();
	}
}

void UDialogueEditorManager::RemoveObjectFromRoot(UObject* InObject)
{
	if (InObject)
	{
		InObject->RemoveFromRoot();
		InObject->MarkAsGarbage();
	}
}

FString UDialogueEditorManager::GetLuaFilePath_Implementation() const
{
    return TEXT("Editor.DialogueEditor.DialogueEditorManager");   
}

void UDialogueEditorManager::ResetRespawnActorsCheck()
{
	RespawnActorsChecker = 0.1f;
}

void UDialogueEditorManager::ReSpawnActors()
{
	if (DialogueEditor.IsValid())
	{
		DialogueEditor.Pin()->GetPreviewScene()->DestroyPreviewActors();
		DialogueEditor.Pin()->GetPreviewScene()->SpawnPreviewActors();
	}
}

float UDialogueEditorManager::GetPlayRate()
{
	return GetDefault<UDialogueEditorPreviewSettings>()->PlayRate;
}

UWorld* UDialogueEditorManager::GetDialogueWorld()
{
	if (DialogueEditor.IsValid())
	{
		return DialogueEditor.Pin()->GetPreviewScene()->GetWorld();
	}

	return nullptr;
}

void UDialogueEditorManager::GetCachedPOVInfo(float& LocX, float& LocY, float& LocZ, float& Pitch, float& Yaw, float& Roll, float& FOV)
{
    if(DialogueEditor.IsValid() && DialogueEditor.Pin()->GetPreviewProxy().IsValid())
    {
        DialogueEditor.Pin()->GetCachedPOVInfo(LocX, LocY, LocZ, Pitch, Yaw, Roll, FOV);
    }
}

void UDialogueEditorManager::ShowCheckResultBox(FString ErrorMsg, FString WarningMsg)
{
	if (WarningWindow.IsValid())
	{
		WarningWindow->RequestDestroyWindow();
		WarningWindow.Reset();
	}
	WarningWindow = SNew(SWindow)
   .Title(LOCTEXT("CheckResultMessageBoxTitle", "Dialogue Editor Asset Rule Check"))
   .ClientSize(FVector2D(800, 600))
   .SupportsMinimize(true)
   .SupportsMaximize(true)
   [
	   SNew(SDialogueCheckWarningWidget)
	   .ErrorMessage(FText::FromString(ErrorMsg))
	   .WarnMessage(FText::FromString(WarningMsg))
   ];

	FSlateApplication::Get().AddWindow(WarningWindow.ToSharedRef());
}

// UWorld* UDialogueEditorManager::GetSmallWorld()
// {
// 	if(DialogueEditor.Pin() && DialogueEditor.Pin()->GetPreviewScene())
// 		return DialogueEditor.Pin()->GetPreviewScene()->FAdvancedPreviewScene::GetWorld();
// 	return nullptr;
// }

class UDialogueActionBase* UDialogueEditorManager::NewLookAtSection(class UDialogueAsset* DialogueAsset)
{
	FString LookAtSectionClassPath = TEXT("/Game/Blueprint/DialogueSystem/Section/BPS_LookAt.BPS_LookAt_C");
	if (UClass* LookAtSectionClass = StaticLoadClass(UObject::StaticClass(), nullptr, *LookAtSectionClassPath))
	{
		return NewObject<UDialogueActionBase>(DialogueAsset, LookAtSectionClass);
	}

	return nullptr;
}

UDialogueActionBase* UDialogueEditorManager::NewCameraCutSection(class UDialogueAsset* DialogueAsset)
{
	FString CameraCutSectionClassPath = TEXT("/Game/Blueprint/DialogueSystem/Section/BPS_DialogueShot.BPS_DialogueShot_C");
	if (UClass* CameraCutSectionClass = StaticLoadClass(UObject::StaticClass(), nullptr, *CameraCutSectionClassPath))
	{
		return NewObject<UDialogueActionBase>(DialogueAsset, CameraCutSectionClass);
	}

	return nullptr;
}

FString UDialogueEditorManager::SwitchToSequencerCamera(ULevelSequencePlayer* LevelSequencePlayer)
{
	UWorld* CurrentWorld = GetWorld();
	if (!CurrentWorld)
	{
		return "";
	}

	ACameraActor* CCA = nullptr;
	if (!LevelSequencePlayer)
	{
		return "";
	}

	// 获取 LevelSequence
	UMovieSceneSequence* LevelSequence = LevelSequencePlayer->GetSequence();
	if (!LevelSequence)
	{
		return "";
	}

	// 获取 MovieScene
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (!MovieScene)
	{
		return "";
	}
	
	// 获取第一个 CameraCut 片段
	UMovieSceneCameraCutTrack* CameraCutTrack = Cast<UMovieSceneCameraCutTrack>(MovieScene->GetCameraCutTrack());
	if (!CameraCutTrack || CameraCutTrack->GetAllSections().Num() == 0)
	{
		return "";
	}
	
	UMovieSceneCameraCutSection* Section = Cast<UMovieSceneCameraCutSection>(CameraCutTrack->GetAllSections()[0]);
	FMovieSceneObjectBindingID CameraBindingID = Section->GetCameraBindingID();
	
	if (!CameraBindingID.IsValid())
	{
		return "";
	}
	
	// 查找绑定的相机对象
	TArray<UObject*> BoundObjects = LevelSequencePlayer->GetBoundObjects(CameraBindingID);
	for (UObject* BoundObject : BoundObjects)
	{
		if (ACameraActor* CameraActor = Cast<ACameraActor>(BoundObject))
		{
			CCA = CameraActor;
			break;
		}
	}
	if(!CCA)
		return "";
	for (TActorIterator<APlayerController> It(CurrentWorld); It; ++It)
	{
		if (It->PlayerCameraManager)
		{
			It->PlayerCameraManager->SetViewTarget(CCA);
			break;
		}
	}
	return CCA->GetName();
}


#undef LOCTEXT_NAMESPACE

#pragma endregion Root
