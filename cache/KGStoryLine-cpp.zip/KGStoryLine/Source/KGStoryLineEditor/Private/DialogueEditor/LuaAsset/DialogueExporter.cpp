#include "DialogueEditor/LuaAsset/DialogueExporter.h"
#include "DialogueEditor/DialogueEditorUtilities.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Dialogue/DialogueCommon.h"
#include "LuaSerialization/Serialization/LuaSerializer.h"
#include "Misc/FileHelper.h"

#pragma optimize("", off)

FDialogueExporter::FDialogueExporter() 
	: FLuaExporter()
	, bExportObjectExtra(true)
{
	bExportDefaultValue = true;

	CustomStructExporters.Add(FString(TEXT("/Script/CoreUObject.Transform")), &FDialogueExporter::ExportFTransformPropertyToLua);
	CustomStructExporters.Add(FString(TEXT("/Script/Engine.SplineCurves")), &FDialogueExporter::ExportFSplineCurvesPropertyToLua);
}

void FDialogueExporter::ExportObjectExtraToLua(UObject* Object, TSharedPtr<FLuaTable> OutLua)
{
	if (!bExportObjectExtra)
	{
		return;
	}

	UClass* ObjectClass = Object->GetClass();
	if (Object->IsA<UDialogueAsset>())
	{
		OutLua->SetField(TEXT("ObjectName"), MakeShared<FLuaValueString>(Object->GetName()));
	}

	OutLua->SetField(TEXT("ObjectClass"), MakeShared<FLuaValueString>(ObjectClass->GetPathName()));
}

TSharedPtr<FLuaValue> FDialogueExporter::ExportStructPropertyToLua(UScriptStruct* ScriptStruct, void* DataAddress, UObject* ParentObject)
{
	if (ScriptStruct == FDialogueAppearanceSelector::StaticStruct())
	{
		FDialogueAppearanceSelector* Ptr = static_cast<FDialogueAppearanceSelector*>(DataAddress);
		return MakeShared<FLuaValueNumber>(Ptr->ApperanceID);
	}
	else if (ScriptStruct == FBehaviorActorSelector::StaticStruct())
	{
		FBehaviorActorSelector* Ptr = static_cast<FBehaviorActorSelector*>(DataAddress);
		return MakeShared<FLuaValueString>(Ptr->TrackName.ToString());
	}
	else if (ScriptStruct == FDialoguePerformerSelector::StaticStruct())
	{
		FDialoguePerformerSelector* Ptr = static_cast<FDialoguePerformerSelector*>(DataAddress);
		return MakeShared<FLuaValueString>(Ptr->PerformerName);
	}
	else if (ScriptStruct == FDialogueCameraSelector::StaticStruct())
	{
		FDialogueCameraSelector* Ptr = static_cast<FDialogueCameraSelector*>(DataAddress);
		return MakeShared<FLuaValueString>(Ptr->CameraName);
	}

	if (CustomStructExporters.Contains(ScriptStruct->GetStructPathName().ToString()))
	{
		auto Ptr = CustomStructExporters[ScriptStruct->GetStructPathName().ToString()];
		return (this->*Ptr)(ScriptStruct, DataAddress, ParentObject);
	}
	
	return FLuaExporter::ExportStructPropertyToLua(ScriptStruct, DataAddress, ParentObject);
}

void FDialogueExporter::SetCanExportDefault(bool bExportDefault)
{
	bExportDefaultValue = bExportDefault;
}

void FDialogueExporter::SetCanExportObjectExtra(bool bInExportObjectExtra)
{
	bExportObjectExtra = bInExportObjectExtra;
}

TSharedPtr<FLuaValue> FDialogueExporter::ExportFTransformPropertyToLua(UScriptStruct* ScriptStruct, void* DataAddress, UObject* ParentObject)
{
	if (bExportDefaultValue)
	{
		return FLuaExporter::ExportStructPropertyToLua(ScriptStruct, DataAddress, ParentObject);
	}
	
	FTransform* Ptr = static_cast<FTransform*>(DataAddress);

	if (FTransform::Identity.Identical(Ptr, 0))
	{
		return MakeShared<FLuaValueNull>();
	}

	TSharedPtr<FLuaTable> LuaTable = MakeShared<FLuaTable>();
	if (!Ptr->Rotator().Equals(FRotator::ZeroRotator, 0.f))
	{
		FQuat Quat = Ptr->GetRotation();
		TSharedPtr<FLuaTable> LuaQuat = MakeShared<FLuaTable>();
		LuaQuat->SetField(TEXT("W"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Quat.W, FloatDoubleDecimals)));
		LuaQuat->SetField(TEXT("X"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Quat.X, FloatDoubleDecimals)));
		LuaQuat->SetField(TEXT("Y"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Quat.Y, FloatDoubleDecimals)));
		LuaQuat->SetField(TEXT("Z"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Quat.Z, FloatDoubleDecimals)));
		LuaTable->SetField(TEXT("Rotation"), MakeShared<FLuaValueTable>(LuaQuat));
	}

	if (!Ptr->GetLocation().Equals(FVector::ZeroVector))
	{
		FVector Location = Ptr->GetLocation();
		TSharedPtr<FLuaTable> LuaScale = MakeShared<FLuaTable>();
		LuaScale->SetField(TEXT("X"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Location.X, FloatDoubleDecimals)));
		LuaScale->SetField(TEXT("Y"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Location.Y, FloatDoubleDecimals)));
		LuaScale->SetField(TEXT("Z"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Location.Z, FloatDoubleDecimals)));
		LuaTable->SetField(TEXT("Translation"), MakeShared<FLuaValueTable>(LuaScale));
	}

	if (!Ptr->GetScale3D().Equals(FVector::OneVector))
	{
		FVector Scale = Ptr->GetScale3D();
		TSharedPtr<FLuaTable> LuaScale = MakeShared<FLuaTable>();
		LuaScale->SetField(TEXT("X"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Scale.X, FloatDoubleDecimals)));
		LuaScale->SetField(TEXT("Y"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Scale.Y, FloatDoubleDecimals)));
		LuaScale->SetField(TEXT("Z"), MakeShared<FLuaValueNumber>(RoundToNDecimals(Scale.Z, FloatDoubleDecimals)));
		LuaTable->SetField(TEXT("Scale3D"), MakeShared<FLuaValueTable>(LuaScale));
	}
	LuaTable->SetField(TEXT("ObjectClass"), MakeShared<FLuaValueString>(TEXT("Transform")));

	return MakeShared<FLuaValueTable>(LuaTable);
}

TSharedPtr<FLuaValue> FDialogueExporter::ExportFSplineCurvesPropertyToLua(UScriptStruct* ScriptStruct, void* DataAddress, UObject* ParentObject)
{
	FSplineCurves* Ptr = static_cast<FSplineCurves*>(DataAddress);

	if (!bExportDefaultValue)
	{
		TSharedPtr<FLuaTable> LuaTable = MakeShared<FLuaTable>();
		bool bDefaultPosition = Ptr->Position.bIsLooped == false && Ptr->Position.LoopKeyOffset == 0 && (Ptr->Position.Points.Num() == 0 || (Ptr->Position.Points.Num() == 1 && Ptr->Position.Points[0].InterpMode == 3 && Ptr->Position.Points[0].InVal == 0 && Ptr->Position.Points[0].ArriveTangent == FVector(0, -130, 0) && Ptr->Position.Points[0].LeaveTangent == FVector(0, -130, 0) && Ptr->Position.Points[0].OutVal == FVector::Zero()));

		bool bDefaultReparamTable = Ptr->ReparamTable.bIsLooped == false && Ptr->ReparamTable.LoopKeyOffset == 0 && (Ptr->ReparamTable.Points.Num() == 0 || (Ptr->ReparamTable.Points.Num() == 1 && Ptr->ReparamTable.Points[0].InterpMode == 0 && Ptr->ReparamTable.Points[0].InVal == 0 && Ptr->ReparamTable.Points[0].ArriveTangent == 0 && Ptr->ReparamTable.Points[0].LeaveTangent == 0 && Ptr->ReparamTable.Points[0].OutVal == 0));

		bool bDefaultRotation = Ptr->Rotation.bIsLooped == false && Ptr->Rotation.LoopKeyOffset == 0 && (Ptr->Rotation.Points.Num() == 0 || (Ptr->Rotation.Points.Num() == 1 && Ptr->Rotation.Points[0].InterpMode == 1 && Ptr->Rotation.Points[0].InVal == 0 && Ptr->Rotation.Points[0].ArriveTangent == FQuat(0, 0, 0, 10000.0003) && Ptr->Rotation.Points[0].LeaveTangent == FQuat(0, 0, 0, 10000.0003) && Ptr->Rotation.Points[0].OutVal == FQuat::Identity));

		bool bDefaultScale = Ptr->Scale.bIsLooped == false && Ptr->Scale.LoopKeyOffset == 0 && (Ptr->Scale.Points.Num() == 0 || (Ptr->Scale.Points.Num() == 1 && Ptr->Scale.Points[0].InterpMode == 1 && Ptr->Scale.Points[0].InVal == 0 && Ptr->Scale.Points[0].ArriveTangent == FVector::Zero() && Ptr->Scale.Points[0].LeaveTangent == FVector::Zero() && Ptr->Scale.Points[0].OutVal == FVector::One()));

		if (bDefaultPosition && bDefaultReparamTable && bDefaultRotation && bDefaultScale)
		{
			return MakeShared<FLuaValueNull>();
		}
	}

	return FLuaExporter::ExportStructPropertyToLua(ScriptStruct, DataAddress, ParentObject);
}

void FDialogueEditorInfoExporter::JustExportEditorOnlyInfoToLua(UObject* Object, TSharedPtr<FLuaTable> OutLua)
{
	UClass* ObjectClass = Object->GetClass();
	for (TFieldIterator<FProperty> PropIt(ObjectClass); PropIt; ++PropIt)
	{
		// 不导出编辑器数据
		if (!(*PropIt)->IsEditorOnlyProperty() || (*PropIt)->HasMetaData(TEXT("IgnoreExport")))
		{
			continue;
		}
		
		// 不导出UObject的数据
		if (PropIt->GetOwnerClass() == UObject::StaticClass())
		{
			continue;
		}
		
		if ((*PropIt)->PropertyFlags & CPF_Transient)
		{
			//不导出运行时数据
			continue;
		}
		
		// 是否导出和默认值相等的属性
		if (!bExportDefaultValue)
		{
			if (UObject* DefaultObject = ObjectClass->GetDefaultObject())
			{
				if (ObjectClass->GetName().Contains(TEXT("BPS_Dialogue_C")))
				{
					void* CDOValuePtr = PropIt->ContainerPtrToValuePtr<void>(DefaultObject);
					void* ValuePtr = PropIt->ContainerPtrToValuePtr<void>(Object);
					if (PropIt->GetName() == TEXT("EpisodeID"))
					{
						FIntProperty* IntProp = CastField<FIntProperty>(*PropIt);
						UE_LOG(LogInit, Log, TEXT("[kgsl]Export: EpisodeID %d %d"), IntProp->GetPropertyValue(CDOValuePtr), IntProp->GetPropertyValue(ValuePtr));

					}
					else if (PropIt->GetName() == TEXT("CanSkip"))
					{
						auto* IntProp = CastField<FBoolProperty>(*PropIt);
						UE_LOG(LogInit, Log, TEXT("[kgsl]Export: EpisodeID %d %d"), IntProp->GetPropertyValue(CDOValuePtr), IntProp->GetPropertyValue(ValuePtr));
					}
					else if (PropIt->GetName() == TEXT("ContentIndex"))
					{
						FIntProperty* IntProp = CastField<FIntProperty>(*PropIt);
						UE_LOG(LogInit, Log, TEXT("[kgsl]Export: EpisodeID %d %d"), IntProp->GetPropertyValue(CDOValuePtr), IntProp->GetPropertyValue(ValuePtr));
					}
				}

				if (PropIt->Identical_InContainer(Object, DefaultObject))
				{
					continue;
				}
			}
		}
		
		void* CurAddress = (*PropIt)->ContainerPtrToValuePtr<void>(Object);
		FString FieldName = (*PropIt)->GetName();
		OutLua->SetField(FieldName, ExportPropertyToLua(*PropIt, CurAddress, Object));
	}

	ExportObjectExtraToLua(Object, OutLua);
	if (ObjectsLuaTable->Values.Num() > 0)
	{
		OutLua->SetField(TEXT("ObjectMap"), MakeShared<FLuaValueTable>(ObjectsLuaTable));
	}
}

#pragma optimize("", on)