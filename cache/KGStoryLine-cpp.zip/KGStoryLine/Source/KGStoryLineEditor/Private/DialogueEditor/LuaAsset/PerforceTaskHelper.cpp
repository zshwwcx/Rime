#include "DialogueEditor/LuaAsset/PerforceTaskHelper.h"

#include "ISourceControlModule.h"
#include "ISourceControlProvider.h"
#include "Misc/MessageDialog.h"
#include "Misc/Paths.h"
#include "HAL/PlatformApplicationMisc.h"

#define LOCTEXT_NAMESPACE "PerforceTaskHelper"

bool FPerforceTaskHelper::RunP4Command(const FString& Command, FString& OutResult)
{
	FString P4ExecCommand = FString::Printf(TEXT("p4"));
	FString DefaultWorkingDirectory = FPaths::ProjectDir();
	int32 ReturnCode;

	// 创建管道
	void* AutoP4ReadPipe = NULL;
	void* AutoP4WritePipe = NULL;
	FPlatformProcess::CreatePipe(AutoP4ReadPipe, AutoP4WritePipe);
	
	// FPlatformProcess::ExecProcess(*P4ExecCommand, *Command, &ReturnCode, &OutResult, nullptr);
	auto ProcHandle = FPlatformProcess::CreateProc(*P4ExecCommand, *Command, false, true, true, nullptr, 0, nullptr, AutoP4WritePipe, AutoP4ReadPipe);

	// 设置定时器
	bool bTimedOut = false;
	float TimeOutLimit = 3.f;
	float TimePassed = 0;
	FString StdOut;
	
	// 轮询进程状态
	while (FPlatformProcess::IsProcRunning(ProcHandle) && !bTimedOut)
	{
		FPlatformProcess::Sleep(0.1f); // 短暂休眠以减少CPU占用
		StdOut += FPlatformProcess::ReadPipe(AutoP4ReadPipe);
		TimePassed += 0.1f;
		if (TimePassed >= TimeOutLimit)
		{
			bTimedOut = true;
		}
	}

	// 检查是否超时
	if (bTimedOut)
	{
		// 终止进程
		FPlatformProcess::TerminateProc(ProcHandle, true);
		FText ConfirmText = LOCTEXT("QuestP4TimeOutWarning", "P4 action timeout, please check your P4 state or restart it");
		FMessageDialog::Open(EAppMsgType::OkCancel, ConfirmText);
		ReturnCode = -1; // 返回错误状态
		UE_LOG(LogTemp, Warning, TEXT("Command execution timed out and process terminated"));
	}
	else
	{
		// 获取返回值
		FPlatformProcess::GetProcReturnCode(ProcHandle, &ReturnCode);
		StdOut += FPlatformProcess::ReadPipe(AutoP4ReadPipe);
		OutResult = StdOut;
		UE_LOG(LogTemp, Log, TEXT("Command completed with return code: %d"), ReturnCode);
	}
	FPlatformProcess::CloseProc(ProcHandle);
	FPlatformProcess::ClosePipe(AutoP4ReadPipe, AutoP4WritePipe);
	return ReturnCode == 0;
}

bool FPerforceTaskHelper::SetP4WorkSpace()
{
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	FString ClientName;
	if (SourceControlProvider.IsEnabled())
	{
		ClientName = SourceControlProvider.GetCurrentWorkspaceName();
		if(ClientName.Len() == 0)
		{
			UE_LOG(LogTemp, Log, TEXT("Can't get current Client"));
		}
	}
	if(ClientName.Len()>0)
	{
		FString Result;
		FString WorkSpaceCommand = FString::Printf(TEXT("set P4CLIENT=%s"), *ClientName);
		RunP4Command(WorkSpaceCommand, Result);
	}
	return true;
}

bool FPerforceTaskHelper::GetDepotPath(const FString& LocalPath, FString& DepotPath)
{
	FString Command = FString::Printf(TEXT("where %s"), *LocalPath);
	FString Result;
	bool bSuccess = RunP4Command(Command, Result);

	if (bSuccess)
	{
		// Parse the result to extract the depot path
		TArray<FString> Lines;
		Result.ParseIntoArrayLines(Lines);

		if (Lines.Num() > 0)
		{
			TArray<FString> Tokens;
			Lines[0].ParseIntoArray(Tokens, TEXT(" "), true);

			if (Tokens.Num() >= 3)
			{
				DepotPath = Tokens[0]; // The depot path is typically the third token
				UE_LOG(LogTemp, Log, TEXT("Local path %s corresponds to depot path %s."), *LocalPath, *DepotPath);
				return true;
			}
		}
	}

	UE_LOG(LogTemp, Error, TEXT("Failed to get depot path for local path %s. Result: %s"), *LocalPath, *Result);
	return false;
}

bool FPerforceTaskHelper::GetLocalPath(const FString& DepotPath, FString& LocalPath)
{
	FString WhereResult;
	FString WhereCommand = FString::Printf(TEXT("where %s"), *DepotPath);
	if (RunP4Command(WhereCommand, WhereResult))
	{
		TArray<FString> WhereLines;
		WhereResult.ParseIntoArrayLines(WhereLines);

		if (WhereLines.Num() > 0)
		{
			TArray<FString> WhereTokens;
			WhereLines[0].ParseIntoArray(WhereTokens, TEXT(" "), true);

			if (WhereTokens.Num() > 2)
			{
				LocalPath = WhereTokens[2].TrimStartAndEnd();
				return true;
			}
		}
	}
	return false;
}

bool FPerforceTaskHelper::IsCheckedOutByOthers(const FString& FilePath, FString& CheckResult)
{
	FString Command = FString::Printf(TEXT("opened -a %s"), *FilePath);
	FString Result;
	bool bSuccess = RunP4Command(Command, Result);
	
	if (bSuccess)
	{
		ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
		FString ClientName;
		if (SourceControlProvider.IsEnabled())
		{
			ClientName = SourceControlProvider.GetCurrentWorkspaceName();
			if(ClientName.Len() == 0)
			{
				UE_LOG(LogTemp, Log, TEXT("Can't get current Client"));
			}
		}
		
		TArray<FString> Lines;
		Result.ParseIntoArrayLines(Lines);

		for (const FString& Line : Lines)
		{
			if (Line.Contains(ClientName))
			{
				continue;
			}
			if (Line.Contains(TEXT(" - add ")))
			{
				// Extract the user who marked the file for add
				int32 UserStart = Line.Find(TEXT(" by ")) + 4;
				int32 UserEnd = Line.Find(TEXT("@"), ESearchCase::IgnoreCase, ESearchDir::FromStart, UserStart);
				auto OutUser = Line.Mid(UserStart, UserEnd - UserStart);
				UE_LOG(LogTemp, Log, TEXT("Depot path %s is marked for add by user %s."), *FilePath, *OutUser);
				CheckResult = FText::Format(LOCTEXT("MarkedForAddOtherResult", "Depot path {0} is marked for add by user {1}."), FText::FromString(FilePath), FText::FromString(OutUser)).ToString();
				return true;
			}
			if (Line.Contains(TEXT(" - edit ")))
			{
				// Extract the user who marked the file for add
				int32 UserStart = Line.Find(TEXT(" by ")) + 4;
				int32 UserEnd = Line.Find(TEXT("@"), ESearchCase::IgnoreCase, ESearchDir::FromStart, UserStart);
				auto OutUser = Line.Mid(UserStart, UserEnd - UserStart);
				UE_LOG(LogTemp, Log, TEXT("Depot path %s is editing by user %s."), *FilePath, *OutUser);
				CheckResult = FText::Format(LOCTEXT("CheckOutByOthersResult", "Depot path {0} is editing by user {1}."), FText::FromString(FilePath), FText::FromString(OutUser)).ToString();
				return true;
			}
			if (Line.Contains(TEXT(" - delete ")))
			{
				// Extract the user who marked the file for add
				int32 UserStart = Line.Find(TEXT(" by ")) + 4;
				int32 UserEnd = Line.Find(TEXT("@"), ESearchCase::IgnoreCase, ESearchDir::FromStart, UserStart);
				auto OutUser = Line.Mid(UserStart, UserEnd - UserStart);
				UE_LOG(LogTemp, Log, TEXT("Depot path %s is marked for delete by user %s."), *FilePath, *OutUser);
				CheckResult = FText::Format(LOCTEXT("MarkedForDeleteOtherResult", "Depot path {0} is marked for delete by user {1}."), FText::FromString(FilePath), FText::FromString(OutUser)).ToString();
				return true;
			}
		}
	}
	return false;
}

bool FPerforceTaskHelper::LockFile(const FString& FilePath)
{
	FString Command = FString::Printf(TEXT("lock %s"), *FilePath);
	FString Result;
	bool bSuccess = RunP4Command(Command, Result);

	if (bSuccess)
	{
		UE_LOG(LogTemp, Log, TEXT("File %s has been locked."), *FilePath);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to lock file %s. Result: %s"), *FilePath, *Result);
	}

	return bSuccess;
}

bool FPerforceTaskHelper::IsUpToDate(const FString& FilePath)
{
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	FString ClientName;
	if (SourceControlProvider.IsEnabled())
	{
		ClientName = SourceControlProvider.GetCurrentWorkspaceName();
	}
	FString Command = FString::Printf(TEXT("-c %s fstat %s"), *ClientName, *FilePath);
	FString Result;
	bool bSuccess = RunP4Command(Command, Result);

	if (bSuccess)
	{
		// 查找文件的最新版本号
		int32 LatestRevision = -1;
		// 查找文件的工作区版本号
		int32 WorkspaceRevision = -1;
		TArray<FString> Lines;
		Result.ParseIntoArrayLines(Lines);
		for (const FString& Line : Lines)
		{
			if (Line.StartsWith(TEXT("... headRev")))
			{
				FString RevisionStr;
				Line.Split(TEXT("headRev "), nullptr, &RevisionStr);
				LatestRevision = FCString::Atoi(*RevisionStr);
			}
			if (Line.StartsWith(TEXT("... haveRev")))
			{
				FString RevisionStr;
				Line.Split(TEXT("haveRev "), nullptr, &RevisionStr);
				WorkspaceRevision = FCString::Atoi(*RevisionStr);
			}
		}
		return LatestRevision == WorkspaceRevision;
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to check file state of %s. Result: %s"), *FilePath, *Result);
		return false;
	}
}

#undef LOCTEXT_NAMESPACE
