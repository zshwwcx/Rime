#include "DialogueEditor/LuaAsset/LuaAssetHelper.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/DialogueEditorLuaGameInstance.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "EditorUtilityLibrary.h"
#include "Factories.h"
#include "KGStoryLineEditorModule.h"
#include "Exporters/Exporter.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "HAL/IConsoleManager.h"
#include "UnrealExporter.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "DialogueEditor/Dialogue/Actions/DialogueAutoCameraCut.h"
#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "HAL/PlatformFileManager.h"
#include "Misc/MessageDialog.h"
#include "UObject/SavePackage.h"
#include "DialogueEditor/Widgets/AssetBrowser/SDialogueAssetBrowser.h"
#include "KGStoryLineDefine.h"
#include "SourceControlHelpers.h"
#include "DialogueEditor/Dialogue/Actions/DialogueStateControl.h"
#include "ImportExport/LuaExporter.h"
#include "ImportExport/LuaImporter.h"
#include "DialogueEditor/LuaAsset/DialogueImporter.h"
#include "LuaSerialization/LuaTable.h"
#include "LuaSerialization/LuaValue.h"
#include "LuaSerialization/Serialization/LuaSerializer.h"
#include "LuaSerialization/Serialization/LuaReader.h"
#include "Engine/Blueprint.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/LuaAsset/DialogueExporter.h"

static FAutoConsoleVariable CVarKGDiscardOptions(
	TEXT("KGSL.DiscardOptions"),
	false,
	TEXT("discard dialogue options in lua asset")
	);
namespace
{
	TWeakObjectPtr<UObject> GetDialogueRootPackage()
	{
		if (FKGStoryLineEditorModule* StoryLineEditorModule = FModuleManager::GetModulePtr<FKGStoryLineEditorModule>("KGStoryLineEditor"))
		{
			return StoryLineEditorModule->GetDialogueRootPackage();
		}
		return nullptr;
	}

	void PostLoadDialogueAsset(UDialogueAsset* DialogueAsset)
	{
		if (DialogueAsset && DialogueAsset->Episodes.Num() > 0)
		{
			DialogueAsset->PostLoad();
			for (int32 i = 0; i < DialogueAsset->Episodes.Num(); i++)
			{
				for (UDialogueTrackBase* Track : DialogueAsset->Episodes[i].GetAllTracks())
				{
					Track->PostLoad();
					if (UDialogueActionTrack* ActionTrack = Cast<UDialogueActionTrack>(Track))
					{
						for (UDialogueActionBase* Action : ActionTrack->ActionSections)
						{
							Action->PostLoad();
						}
					}
					if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(Track))
					{
						for (auto DialogueActionTrack : SpawnableTrack->Actions)
						{
							DialogueActionTrack->PostLoad();
							for (UDialogueActionBase* Action : DialogueActionTrack->ActionSections)
							{
								Action->PostLoad();
							}
						}
						// 不同的Episode中的Entity是共同持有的，对第0个Episode的DialogueEntity执行post load就行
						if (i == 0)
						{
							if (UDialogueEntity* DialogueEntity = SpawnableTrack->GetDialogueEntity())
							{
								DialogueEntity->PostLoad();
							}
						}
					}
				}
			}
		}
	}
}

struct FDialogueObjectTextFactory : public FCustomizableTextObjectFactory
{
	UDialogueAsset* DialogueAsset=nullptr; // cppcheck:ignore
	
	FDialogueObjectTextFactory()
		: FCustomizableTextObjectFactory(GWarn)
	{
	}

protected:
	virtual bool CanCreateClass(UClass* ObjectClass, bool& bOmitSubObjs) const override
	{
		return true;
	}

	virtual void UpdateObjectName(UClass* ObjectClass, UObject* InParent, FName& InOutObjName) override
	{
	}

	virtual void ProcessConstructedObject(UObject* CreatedObject) override
	{
		if (UDialogueAsset* Asset = Cast<UDialogueAsset>(CreatedObject))
		{
			DialogueAsset = Asset;
		}
	}

	virtual void PostProcessConstructedObjects() override
	{
		PostLoadDialogueAsset(DialogueAsset);
	}
};

FString FLuaAssetHelper::DialoguePrePath = TEXT("/Game/Blueprint/DialogueSystem/DialogueAsset");

FString FLuaAssetHelper::DialogueNewPath = TEXT("/Game/Blueprint/DialogueSystem/DialogueAsset/NewTempAsset");

FString FLuaAssetHelper::LuaAssetPrePath = TEXT("Script/Data/Config/Dialogue");

FString FLuaAssetHelper::BPDialogueAssetClassPath = TEXT("/Game/Blueprint/DialogueSystem/BP_DialogueAsset.BP_DialogueAsset_C");
FString FLuaAssetHelper::Ignore_Return = TEXT("return");

bool FLuaAssetHelper::LoadLuaFileToAsset(const FString& FilePath, UObject* Asset)
{
	if (!FPaths::FileExists(FilePath))
	{
		UE_LOG(LogTemp, Error, TEXT("File does not exist: %s"), *FilePath);
		return false;
	}
	
	FString LuaStr;
	if (!FFileHelper::LoadFileToString(LuaStr, *FilePath))
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to read file: %s"), *FilePath);
		return false;
	}
	return true;
}

FString FLuaAssetHelper::GetEditorOnlyInfo(UObject* Asset)
{
	const FExportObjectInnerContext Context;
	FStringOutputDevice Archive;
	UObject* ThisOuter = Asset->GetOuter();
	UExporter::ExportToOutputDevice(&Context, Asset, NULL, Archive, TEXT("copy"), 0, PPF_ExportsNotFullyQualified|PPF_Copy|PPF_Delimited, false, ThisOuter);
	return LexToString(Archive);
}

void FLuaAssetHelper::ExportEditorOnlyInfoToLuaTable(UObject* Asset, const TSharedPtr<FLuaTable>& OutLua)
{
	SCOPED_NAMED_EVENT(ExportEditorOnlyInfoToJsonObject, FColor::Silver);
	TArray<TSharedPtr<FLuaValue>> LuaArray;
	const FExportObjectInnerContext Context;
	FStringOutputDevice Archive;
	UObject* ThisOuter = Asset->GetOuter();
	UExporter::ExportToOutputDevice(&Context, Asset, NULL, Archive, TEXT("copy"), 0, PPF_ExportsNotFullyQualified|PPF_Copy|PPF_Delimited, false, ThisOuter);
	FString OutString;
	OutString += Archive;
	FString LineStr;
	const TCHAR* Ptr = *OutString;
	FString StrLine;
	while( FParse::Line(&Ptr,StrLine) )
	{
		LuaArray.Add(MakeShared<FLuaValueString>(StrLine));
	}
	TSharedPtr<FLuaTable> LuaTable = MakeShareable(new FLuaTable());
	LuaTable->SetField(TEXT("AssetInfo"), MakeShared<FLuaValueArray>(LuaArray));

	// 加上ZZZ的前缀，保证序列化进lua table的时候在最后
	OutLua->SetField(TEXT("ZZZ_EditorOnlyInfo"), MakeShared<FLuaValueTable>(LuaTable));
}

bool FLuaAssetHelper::CreateAndOpenDialogueLuaAsset(const FString& AssetName)
{
	TWeakObjectPtr<UObject> DialoguePackage = GetDialogueRootPackage();
	if (!DialoguePackage.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("Dialogue root Object is not valid!!"))
		return false;
	}
	if (UClass* BPDialogue = StaticLoadClass(UObject::StaticClass(), nullptr, *BPDialogueAssetClassPath))
	{
		UDialogueAsset* NewDialogue = NewObject<UDialogueAsset>(DialoguePackage.Get(), BPDialogue, FName(AssetName),  RF_Transactional);
		NewDialogue->StoryLineID = FCString::Atoi(*AssetName);
		NewDialogue->AddToRoot();
		TSharedPtr<IDialogueEditor> Editor = IDialogueEditor::OpenEditor(NewDialogue, nullptr);
		if (Editor.IsValid())
		{
			FDialogueEditor* DialogueEditor = static_cast<FDialogueEditor*>(Editor.Get());
			DialogueEditor->bNeedCreateAutoCutsOnAllEntityReady = true;
		}
		NewDialogue->RemoveFromRoot();
		return true;
	}
	return false;
}

bool FLuaAssetHelper::OpenDialogueByEditorOnlyInfo(const FString& AssetName, const FString& EditorOnlyInfo)
{
	TWeakObjectPtr<UObject> DialoguePackage = GetDialogueRootPackage();
	if (!DialoguePackage.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("Dialogue root Object is not valid!!"))
		return false;
	}
	FDialogueObjectTextFactory Factory;
	Factory.ProcessBuffer(DialoguePackage.Get(), RF_Transactional, EditorOnlyInfo);
	if (UDialogueAsset* LoadAsset = Factory.DialogueAsset)
	{
		LoadAsset->StoryLineID = FCString::Atoi(*AssetName);
		LoadAsset->AddToRoot();
		if (TSharedPtr<IDialogueEditor> DialogueEditor = IDialogueEditor::OpenEditor(LoadAsset, nullptr))
		{
			DialoguePackage->GetPackage()->ClearDirtyFlag();
		}
		LoadAsset->RemoveFromRoot();
		return true;
	}
	return false;
}

bool FLuaAssetHelper::OpenDialogueByEditorOnly(const FString& AssetName, TSharedPtr<FLuaTable> LuaTable)
{
	TWeakObjectPtr<UObject> DialoguePackage = GetDialogueRootPackage();
	if (!DialoguePackage.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("Dialogue root Object is not valid!!"))
		return false;
	}
	UClass* BPDialogue = StaticLoadClass(UObject::StaticClass(), nullptr, *BPDialogueAssetClassPath);
	UDialogueAsset* DialogueAsset = NewObject<UDialogueAsset>(DialoguePackage.Get(), BPDialogue, FName(AssetName), RF_Transactional);
	auto EditorOnlyTable = LuaTable->GetTableField(TEXT("ZZZ_EditorOnly"));
	TSharedPtr<FDialogueImporter> LuaImporter = MakeShared<FDialogueImporter>();
	LuaImporter->ImportLuaToObj(LuaTable, DialogueAsset);
	PostLoadDialogueAsset(DialogueAsset);
	if (TSharedPtr<IDialogueEditor> DialogueEditor = IDialogueEditor::OpenEditor(DialogueAsset, nullptr))
	{
		DialoguePackage->GetPackage()->ClearDirtyFlag();
	}
	return true;
}

UDialogueAsset* FLuaAssetHelper::LoadDialogueAssetFromLua(const FString& AssetName, const FString& AssetPath)
{
	if (!FPaths::FileExists(AssetPath))
	{
		UE_LOG(LogTemp, Error, TEXT("File does not exist: %s"), *AssetPath);
		return nullptr;
	}

	SCOPED_NAMED_EVENT(FLuaAssetHelper_OpenDialogue, FColor::Green);
	FString LuaStr;
	if (!FFileHelper::LoadFileToString(LuaStr, *AssetPath))
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to read file: %s"), *AssetPath);
		return nullptr;
	}

	LuaStr.TrimStartInline();
    if (LuaStr.StartsWith(FLuaAssetHelper::Ignore_Return))
    {
	    LuaStr.RemoveFromStart(FLuaAssetHelper::Ignore_Return, ESearchCase::CaseSensitive);
    }

	TSharedPtr<FLuaValue> LuaValue = nullptr;
	const TSharedRef<TLuaReader<>> LuaReader = TLuaReaderFactory<>::Create(LuaStr);
	if(FLuaSerializer::Deserialize(LuaReader, LuaValue) && LuaValue.IsValid())
	{
		TSharedPtr<FLuaTable> LuaTable = LuaValue->AsTable();
		if (LuaTable.IsValid())
		{
			TWeakObjectPtr<UObject> DialoguePackage = GetDialogueRootPackage();
			if (!DialoguePackage.IsValid())
			{
				UE_LOG(LogTemp, Error, TEXT("Dialogue root Object is not valid!!"))
				return nullptr;
			}
			
			UClass* BPDialogue = StaticLoadClass(UObject::StaticClass(), nullptr, *BPDialogueAssetClassPath);
			UDialogueAsset* DialogueAsset = NewObject<UDialogueAsset>(DialoguePackage.Get(), BPDialogue, FName(AssetName), RF_Transactional);
			TSharedPtr<FDialogueImporter> LuaImporter = MakeShared<FDialogueImporter>();
			LuaImporter->ImportLuaToObj(LuaTable, DialogueAsset);
			
			PostLoadDialogueAsset(DialogueAsset);
			return DialogueAsset;
		}
	}
	return nullptr;
}

bool FLuaAssetHelper::OpenDialogue(const FString& AssetName, const FString& AssetPath)
{
	if (UDialogueAsset* DialogueAsset = LoadDialogueAssetFromLua(AssetName, AssetPath))
	{
		TWeakObjectPtr<UObject> DialoguePackage = GetDialogueRootPackage();
		if (TSharedPtr<IDialogueEditor> DialogueEditor = IDialogueEditor::OpenEditor(DialogueAsset, nullptr))
		{
			DialoguePackage->GetPackage()->ClearDirtyFlag();
		}
		return true;
	}
	return false;
}

void FLuaAssetHelper::CopyDialogue(const FString& SourceDialogueID, FString DestDialogueID)
{
	FString Directory = FPaths::Combine(FPaths::ProjectContentDir(), FLuaAssetHelper::LuaAssetPrePath);
	FString DialogueLuaPath = FPaths::Combine(Directory, SourceDialogueID + ".lua");
	if (UDialogueAsset* DialogueAsset = LoadDialogueAssetFromLua(SourceDialogueID, DialogueLuaPath))
	{
		const FString PackageName = FPaths::Combine(DialogueNewPath, DestDialogueID);
		UPackage* DestinationPackage = CreatePackage(*PackageName);
		UObject* DuplicatedAsset = DuplicateObject(DialogueAsset, DestinationPackage, *DestDialogueID);
		FAssetRegistryModule::AssetCreated(DuplicatedAsset);
		UDialogueAsset* NewDialogueAsset = Cast<UDialogueAsset>(DuplicatedAsset);
			
		UWorld* DummyWorld = NewObject<UWorld>();
		UEditorLuaEnv *LuaEnv = UEditorLuaEnv::CreateLuaEnv(DummyWorld, UDialogueEditorLuaGameInstance::StaticClass());
		UDialogueEditorManager* DialogueEditorManager = NewObject<UDialogueEditorManager>(DummyWorld);
		DialogueEditorManager->Initialize();
		FBehaviorActorSelector::Owner = DialogueAsset;
		DialogueEditorManager->ForceExportLuaTable(NewDialogueAsset);
        UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
	}
}

bool FLuaAssetHelper::OpenOrCreateDialogueByFileNameInternal(const FString& FileName, bool bSimpleDialogue,
						const TFunction<void()>& PreOpenCallBack, const TFunction<void()>& PreCreateCallBack)
{
	if (!FKGStoryLineEditorModule::CanTypeOfAssetOpen(UDialogueAsset::StaticClass()))
		return false;

	if (!IDialogueEditor::ProcessOtherOpen())
	{
		return false;
	}
	
	FString Directory = FPaths::Combine(FPaths::ProjectContentDir(), FLuaAssetHelper::LuaAssetPrePath);
	FString DialogueLuaPath = FPaths::Combine(Directory, FileName + ".lua");
	bool bFileExists = FPaths::FileExists(DialogueLuaPath);
	
	if (bSimpleDialogue && !bFileExists)
	{
		FString DialogText = FString::Printf(TEXT("是否为简单对话新建资产并打开，新建后请调整表内【简单对话】配置，让资产正常播放"));
		EAppReturnType::Type Ret = FMessageDialog::Open(EAppMsgType::YesNo, FText::FromString(DialogText));
		if (Ret == EAppReturnType::Yes)
		{
			if (PreCreateCallBack)
			{
				PreCreateCallBack();
			}
			if (!IDialogueEditor::ProcessOtherOpen())
			{
				return false;
			}
			if (FLuaAssetHelper::CreateAndOpenDialogueLuaAsset(FileName))
			{
				UDialogueEditorPerProjectUserSettings* EditorSettings = GetMutableDefault<UDialogueEditorPerProjectUserSettings>();
				EditorSettings->AddHistoryAsset(FileName);
				return true;
			}
		}
		return false;
	}
	
	if (bFileExists)
	{
		if (bSimpleDialogue)
		{
			FString DialogText = FString::Printf(TEXT("简单对话，不使用该资产内容；如需使用，请调整表内【简单对话】配置"));
			FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(DialogText));
			return false;
		}
			
		if (PreOpenCallBack)
		{
			PreOpenCallBack();
		}

		if (!IDialogueEditor::ProcessOtherOpen())
		{
			return false;
		}

		bool bSuccess = OpenDialogue(FileName, DialogueLuaPath);
		if(!bSuccess)
		{
			const FString DialogText = FString::Printf(TEXT("无法打开对话资产: %s.lua!!!请联系@wujianxiong进行排查 "), *FileName);
			FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(DialogText));
			return false;
		}
		else
		{
			UDialogueEditorPerProjectUserSettings* EditorSettings = GetMutableDefault<UDialogueEditorPerProjectUserSettings>();
			EditorSettings->AddHistoryAsset(FileName);
			return true;
		}
	}
	else
	{
		const FText Message = FText::FromString(TEXT("没有资产，是否要创建并打开？"));
		EAppReturnType::Type Ret = FMessageDialog::Open(EAppMsgType::YesNo, Message);
		if (Ret == EAppReturnType::Yes)
		{
			if (PreCreateCallBack)
			{
				PreCreateCallBack();
			}
			if (!IDialogueEditor::ProcessOtherOpen())
			{
				return false;
			}
			if (FLuaAssetHelper::CreateAndOpenDialogueLuaAsset(FileName))
			{
				UDialogueEditorPerProjectUserSettings* EditorSettings = GetMutableDefault<UDialogueEditorPerProjectUserSettings>();
				EditorSettings->AddHistoryAsset(FileName);
				return true;
			}
		}
	}
	return false;
}

void FLuaAssetHelper::OpenOrCreateDialogueByFileName(const FString& FileName)
{
	if (!FKGStoryLineEditorModule::CanTypeOfAssetOpen(UDialogueAsset::StaticClass()))
		return;
	
	UWorld* DummyWorld = NewObject<UWorld>();
	UEditorLuaEnv *LuaEnv = UEditorLuaEnv::CreateLuaEnv(DummyWorld, UDialogueEditorLuaGameInstance::StaticClass());
	UDialogueEditorManager* DialogueEditorManager = NewObject<UDialogueEditorManager>(DummyWorld);
	DialogueEditorManager->Initialize();
	TMap<FString, FDialogueAssetData> DialogueAssetData;
	DialogueEditorManager->GetDialogueAssetData(DialogueAssetData);
    UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
	
	if (!DialogueAssetData.Find(FileName))
	{
		FString DialogText = FString::Printf(TEXT("编号【%s】的对话不存在，请检查对话表是否正确配置了此ID，并检查是否成功导表"),*FileName);
		EAppReturnType::Type Ret = FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(DialogText));
		return;
	}

	bool bSimpleDialogue = DialogueAssetData[FileName].bSimpleDialogue;
	
	OpenOrCreateDialogueByFileNameInternal(FileName, bSimpleDialogue);
}

FAutoConsoleCommand KGExport(TEXT("KGStoryline.Export"), TEXT("KGStoryline.Export"), FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
{
	TArray<UObject*> SelectedAssets = UEditorUtilityLibrary::GetSelectedAssets();
	if (SelectedAssets.Num() > 0)
	{
		UObject* SelectedAsset = SelectedAssets[0];
		if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(SelectedAsset))
		{
			const FExportObjectInnerContext Context;
			FStringOutputDevice Archive;
			UObject* ThisOuter = DialogueAsset->GetOuter();
			UExporter::ExportToOutputDevice(&Context, DialogueAsset, NULL, Archive, TEXT("copy"), 0, PPF_ExportsNotFullyQualified|PPF_Copy|PPF_Delimited, false, ThisOuter);
			FString FileName = DialogueAsset->GetName() + TEXT(".lua");
			FString SaveDir = FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("Dialogue"));
			const FString FilePath = FPaths::Combine(SaveDir, FileName);
			FFileHelper::SaveStringToFile(Archive, *FilePath);
		}
	}
}));

FAutoConsoleCommand KGImport(TEXT("KGStoryline.Import"), TEXT("KGStoryline.Import"), FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
{
	FString Directory = FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("Dialogue"));
	TArray<FString> FileNames;
	FPlatformFileManager::Get().GetPlatformFile().FindFiles(FileNames, *Directory, TEXT("lua"));
	for (FString& FileName : FileNames)
	{
		UObject* Parent = NewObject<UDialogueAsset>(GetTransientPackage());
		FString LuaStr;
		if (FFileHelper::LoadFileToString(LuaStr, *FileName))
		{
			FDialogueObjectTextFactory Factory;
			Factory.ProcessBuffer(Parent, RF_Transactional, LuaStr);
			UDialogueAsset* LoadAsset = Factory.DialogueAsset;
			LoadAsset->AddToRoot();
			IDialogueEditor::OpenEditor(LoadAsset, nullptr);
		}
	}
}));

FAutoConsoleCommand KGExportAllDialogue(TEXT("KGStoryline.ExportAllDialogue"), TEXT("KGStoryline.ExportAllDialogue"), FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	AssetRegistryModule.Get().SearchAllAssets(true);
	const IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	FARFilter Filter;
	Filter.ClassPaths.Add(UDialogueAsset::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	Filter.PackagePaths.Add("/Game");
	TArray<FAssetData> OutAssetData;
	AssetRegistry.GetAssets(Filter, OutAssetData);
	UWorld* DummyWorld = NewObject<UWorld>();
    UEditorLuaEnv *LuaEnv = UEditorLuaEnv::CreateLuaEnv(DummyWorld, UDialogueEditorLuaGameInstance::StaticClass());
	UDialogueEditorManager* DialogueEditorManager = NewObject<UDialogueEditorManager>(DummyWorld);
	DialogueEditorManager->Initialize();
	for (int32 i = 0; i < OutAssetData.Num(); i++)
	{
		if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(OutAssetData[i].GetAsset()))
		{
			UE_LOG(LogTemp, Display, TEXT("Export Dialogue %d/%d"), i, OutAssetData.Num());
			DialogueEditorManager->ForceExportLuaTable(DialogueAsset);
		}
	}
    UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
}));

FAutoConsoleCommand KGCopyAllDialogue(TEXT("KGStoryline.CopyAllDialogue"), TEXT("KGStoryline.CopyAllDialogue"), FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	AssetRegistryModule.Get().SearchAllAssets(true);
	const IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	FARFilter Filter;
	Filter.ClassPaths.Add(UDialogueAsset::StaticClass()->GetClassPathName());
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	Filter.PackagePaths.Add(*FLuaAssetHelper::DialoguePrePath);
	TArray<FAssetData> OutAssetData;
	AssetRegistry.GetAssets(Filter, OutAssetData);
	UWorld* DummyWorld = NewObject<UWorld>();
    UEditorLuaEnv *LuaEnv = UEditorLuaEnv::CreateLuaEnv(DummyWorld, UDialogueEditorLuaGameInstance::StaticClass());
	UDialogueEditorManager* DialogueEditorManager = NewObject<UDialogueEditorManager>(DummyWorld);
	DialogueEditorManager->Initialize();
	TMap<FString, FDialogueAssetData> DialogueAssetData;
	DialogueEditorManager->GetDialogueAssetData(DialogueAssetData);
	
	TMap<FString, FAssetData*> AssetDataMap;
	for (int32 i = 0; i < OutAssetData.Num(); i++)
	{
		if (AssetDataMap.Contains(OutAssetData[i].AssetName.ToString()))
		{
			UE_LOG(LogTemp, Warning, TEXT("Asset Name Duplicated %s"), *OutAssetData[i].AssetName.ToString());
		}
		else
		{
			AssetDataMap.Add(OutAssetData[i].AssetName.ToString(), &OutAssetData[i]);
		}
	}
	UE_LOG(LogTemp, Warning, TEXT("Dialogue Count %d"), AssetDataMap.Num())

	TArray<FString> FailedNames;
	
	for (TTuple<FString, FDialogueAssetData>& Data: DialogueAssetData)
	{
		FString DialogueID = Data.Key;
		FString AssetPath = Data.Value.AssetPath;
		if (AssetPath.IsEmpty())
		{
			continue;
		}
		int32 LastSlashIndex;
		AssetPath.FindLastChar('/', LastSlashIndex);
		FString AssetName = AssetPath.Right(AssetPath.Len() - LastSlashIndex - 1);
		if (AssetDataMap.Contains(AssetName))
		{
			UObject* SourceAsset = AssetDataMap[AssetName]->GetAsset();
			FString NewAssetName = DialogueID;
			FString PackageName = FPaths::Combine(FLuaAssetHelper::DialogueNewPath, NewAssetName);
			UPackage* DestinationPackage = CreatePackage(*PackageName);
			UObject* DuplicatedAsset = DuplicateObject(SourceAsset, DestinationPackage, *NewAssetName);
			DestinationPackage->MarkPackageDirty();
			FAssetRegistryModule::AssetCreated(DuplicatedAsset);
			UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(DuplicatedAsset);
			DialogueEditorManager->ForceExportLuaTable(DialogueAsset);
		}
		else
		{
			FailedNames.Add(DialogueID);
		}
	}
	FString Messgae = FString::Join(FailedNames, TEXT(","));
	UE_LOG(LogTemp, Warning, TEXT("Failed Dialogeu IDs: %s"), *Messgae);
    UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
}));

FAutoConsoleCommand KGReplaceDialogueCameraAnim(TEXT("KGStoryline.ReplaceDialogueCameraAnim"), TEXT("KGStoryline.ReplaceDialogueCameraAnim"), FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
{
	UDialogueEditorSettings* DialogueEditorSettings = GetMutableDefault<UDialogueEditorSettings>();
	for (auto TrackClass : DialogueEditorSettings->BlueprintTracks)
	{
		StaticLoadClass(UObject::StaticClass(), nullptr, *TrackClass->GetClass()->GetName());
	}
	TArray<FAssetData> AssetDataList;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	TArray<FAssetData> OutAssetData;
	FARFilter Filter;
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	Filter.PackagePaths.Add("/Game/Blueprint/DialogueSystem/Track/");
	AssetRegistry.GetAssets(Filter, OutAssetData);
	for (auto AssetData : OutAssetData)
	{
		AssetData.GetAsset();
	}
	UWorld* DummyWorld = NewObject<UWorld>();
    UEditorLuaEnv *LuaEnv = UEditorLuaEnv::CreateLuaEnv(DummyWorld, UDialogueEditorLuaGameInstance::StaticClass());
	UDialogueEditorManager* DialogueEditorManager = NewObject<UDialogueEditorManager>(DummyWorld);
	DialogueEditorManager->Initialize();
	TMap<FString, FDialogueAssetData> CachedDialogueAssetData;
	CachedDialogueAssetData.Empty();
	DialogueEditorManager->GetDialogueAssetData(CachedDialogueAssetData);
	FString BPDialogueCameraAnimClassPath = TEXT("/Game/Blueprint/DialogueSystem/Track/BP_DialogueTrackCameraAnim.BP_DialogueTrackCameraAnim_C");
	UClass* BPDialogueCameraAnimClass = StaticLoadClass(UObject::StaticClass(), nullptr, *BPDialogueCameraAnimClassPath);
	FString BP_DialogueCameraCutClassPath = TEXT("/Game/Blueprint/DialogueSystem/Track/BP_DialogueCameraCut.BP_DialogueCameraCut_C");
	UClass* BP_DialogueCameraCutClass = StaticLoadClass(UObject::StaticClass(), nullptr, *BP_DialogueCameraCutClassPath);
	FString BP_DialogueTrackCameraMoveClassPath = TEXT("/Game/Blueprint/DialogueSystem/Track/BP_DialogueTrackCameraMove.BP_DialogueTrackCameraMove_C");
	UClass* BP_DialogueTrackCameraMoveClass = StaticLoadClass(UObject::StaticClass(), nullptr, *BP_DialogueTrackCameraMoveClassPath);
	FString PackageName = TEXT("/Temp/DialogueTransientPackage");
	TWeakObjectPtr<UObject> DialoguePackage = CreatePackage(*PackageName);
	DialoguePackage->AddToRoot();
	FString Directory = FPaths::Combine(FPaths::ProjectContentDir(), FLuaAssetHelper::LuaAssetPrePath);
	FDialogueObjectTextFactory Factory;
	
	for (const TTuple<FString, FDialogueAssetData>& AssetData : CachedDialogueAssetData)
	{
		FString AssetName = AssetData.Key;
		FString DialogueLuaPath = FPaths::Combine(Directory, AssetName + ".lua");
		if (!FPaths::FileExists(DialogueLuaPath))
		{
			continue;
		}
		TArray<FString> EditorOnlyInfo;
		FString EditorOnlyTag;
		DialogueEditorManager->GetDialogueEditorOnlyInfo(AssetName, EditorOnlyInfo, EditorOnlyTag);
		Factory.ProcessBuffer(DialoguePackage.Get(), RF_Transactional, EditorOnlyInfo[1]);
		if (UDialogueAsset* DialogueAsset = Factory.DialogueAsset)
		{
			bool bNeedSave = false;
			for (int32 EpisodeIndex=0; EpisodeIndex < DialogueAsset->Episodes.Num(); EpisodeIndex++)
			{
				FDialogueEpisode& Episode = DialogueAsset->Episodes[EpisodeIndex];
				UDialogueActionTrack* CameraCutTrack = nullptr;
				for (UDialogueTrackBase* ActionTrack : Episode.GetAllTracks())
				{
					if (ActionTrack->GetClass() == UDialogueCameraCutTrack::StaticClass() || ActionTrack->GetClass() == BP_DialogueCameraCutClass)
					{
						CameraCutTrack = Cast<UDialogueCameraCutTrack>(ActionTrack);
						break;
					}
				}
				TArray<UDialogueTrackBase*>& TrackList = Episode.TrackList;
				for (int32 TrackIndex = TrackList.Num() - 1; TrackIndex >= 0; TrackIndex--)
				{
					UDialogueTrackBase* Track = TrackList[TrackIndex];
					if (Track->IsA(BPDialogueCameraAnimClass) || Cast<UDialogueAutoCameraCutTrack>(Track))
					{
						if (UDialogueActionTrack* ActionTrack = Cast<UDialogueActionTrack>(Track))
						{
							if (ActionTrack->ActionSections.Num() > 0)
							{
								if (CameraCutTrack == nullptr)
								{
									UDialogueCameraCutTrack* NewTrack = NewObject<UDialogueCameraCutTrack>(DialogueAsset, BP_DialogueCameraCutClass, NAME_None, RF_Transactional);
									NewTrack->FromTemplate = false;
									TrackList.Add(NewTrack);
									CameraCutTrack = NewTrack;
									UE_LOG(LogTemp, Warning, TEXT("Has Camera Anim But Not have Camera cut track Dialogue Asset: %s"), *AssetName);
								}
								CameraCutTrack->ActionSections.Append(ActionTrack->ActionSections);
								for (UDialogueActionBase* ActionSection : ActionTrack->ActionSections)
								{
									ActionSection->Rename(nullptr, CameraCutTrack);
									ActionSection->DialogueAction = CameraCutTrack;
								}
								UE_LOG(LogTemp, Warning, TEXT("Has Camera Anim Dialogue Asset: %s"), *AssetName);
							}
							ActionTrack->Rename(nullptr, GetTransientPackage());
							TrackList.RemoveAt(TrackIndex);
							bNeedSave = true;
						}
					}
					if (Track->IsA(BP_DialogueTrackCameraMoveClass))
					{
						Track->Rename(nullptr, GetTransientPackage());
						TrackList.RemoveAt(TrackIndex);
						bNeedSave = true;
					}
				}
			}
			for (UKGSLDialogueEpisode* Episode: DialogueAsset->EpisodesList)
			{
				TArray<UDialogueTrackBase*>& TrackList = Episode->TrackList;
				for (int32 TrackIndex = TrackList.Num() - 1; TrackIndex >= 0; TrackIndex--)
				{
					UDialogueTrackBase* Track = TrackList[TrackIndex];
					if (Track->IsA(BPDialogueCameraAnimClass) || Cast<UDialogueAutoCameraCutTrack>(Track) || Track->IsA(BP_DialogueTrackCameraMoveClass))
					{
						TrackList.RemoveAt(TrackIndex);
						Track->Rename(nullptr, GetTransientPackage());
						bNeedSave = true;
					}
				}
			}
			if (bNeedSave)
			{
				DialogueEditorManager->ForceExportLuaTable(DialogueAsset);
			}
		}
	}
    UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
}));

FAutoConsoleCommand KGBatchProcessDialogueAssets(
	TEXT("KGStoryLine.BatchProcess"),
	TEXT("KGStoryLine.BatchProcess"),
	FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
	{
		if (Args.Num() < 1)
		{
			UE_LOG(LogKGSL, Error, TEXT("not enough arguments.It won't be sent.\n Command strcture is KGStoryLine.BatchProcess [ProcessFunctionName] [AssetName1] [AssetName2] ... [AssetNanmeN]\nAssetName:can be ignored,and this means do the process on all assets."));
			return;
		}

		FString ProcessFuncName = Args[0];

		TArray<FString> InputFileName;
		if (Args.Num() > 1)
		{
			InputFileName.Reserve(Args.Num() - 1);
			for (int32 i = 1; i < Args.Num(); ++i)
			{
				InputFileName.Emplace(Args[i]);
			}
		}

		// Load all classes and blueprints which are dialogue needed
		UDialogueEditorSettings* DialogueEditorSettings = GetMutableDefault<UDialogueEditorSettings>();
		for (auto TrackClass : DialogueEditorSettings->BlueprintTracks)
		{
			StaticLoadClass(UObject::StaticClass(), nullptr, *TrackClass->GetClass()->GetName());
		}

		TArray<FAssetData> AssetDataList;
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
		TArray<FAssetData> OutAssetData;
		FARFilter Filter;
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;
		Filter.PackagePaths.Add("/Game/Blueprint/DialogueSystem/Track/");
		AssetRegistry.GetAssets(Filter, OutAssetData);
		for (auto AssetData : OutAssetData)
		{
			AssetData.GetAsset();
		}

		// Init lua enviroment
		UWorld* DummyWorld = NewObject<UWorld>();
        UEditorLuaEnv *LuaEnv = UEditorLuaEnv::CreateLuaEnv(DummyWorld, UDialogueEditorLuaGameInstance::StaticClass());
		UDialogueEditorManager* DialogueEditorManager = NewObject<UDialogueEditorManager>(DummyWorld);
		DialogueEditorManager->Initialize();

		// Get lua assets name
		TArray<FString> LuaAssetNames;
		FString Directory = FPaths::Combine(FPaths::ProjectContentDir(), FLuaAssetHelper::LuaAssetPrePath);
		if (InputFileName.Num() > 0)
		{
			for (const auto& Name : InputFileName)
			{
				FString AssetPath = FPaths::Combine(Directory, Name + TEXT(".lua"));
				if (FPaths::FileExists(AssetPath))
				{
					LuaAssetNames.Emplace(Name);
				}
				else
				{
					UE_LOG(LogKGSL, Warning, TEXT("[KGSL]BatchProcess:input asset [%s] not exist."), *Name);
				}
			}
		}
		else
		{
			TMap<FString, FDialogueAssetData> CachedDialogueAssetData;
			DialogueEditorManager->GetDialogueAssetData(CachedDialogueAssetData);
			for (const TTuple<FString, FDialogueAssetData>& AssetData : CachedDialogueAssetData)
			{
				FString AssetName = AssetData.Key;
				FString AssetPath = FPaths::Combine(Directory, AssetName + ".lua");
				if (FPaths::FileExists(AssetPath))
				{
					LuaAssetNames.Emplace(AssetName);
				}
			}
		}

		// Batch process
		FString PackageName = TEXT("/Temp/DialogueTransientPackage");
		TWeakObjectPtr<UObject> DialoguePackage = CreatePackage(*PackageName);
		DialoguePackage->AddToRoot();
		FDialogueObjectTextFactory Factory;

		UClass* BPDialogue = StaticLoadClass(UObject::StaticClass(), nullptr, *FLuaAssetHelper::BPDialogueAssetClassPath);

		FScopedSlowTask BatchProcess(LuaAssetNames.Num(), FText::FromString(TEXT("Batch Process:") + ProcessFuncName));
		BatchProcess.MakeDialog();

		auto LastOwner = FBehaviorActorSelector::Owner;
		TArray<UDialogueAsset*> Assets;
		for (const auto& AssetName : LuaAssetNames)
		{
			BatchProcess.EnterProgressFrame(1.f, FText::FromString(AssetName));
			TArray<FString> EditorOnlyInfo;
			FString EditorOnlyTag;
			DialogueEditorManager->GetDialogueEditorOnlyInfo(AssetName, EditorOnlyInfo, EditorOnlyTag);

			UDialogueAsset* DialogueAsset = nullptr;
			if (EditorOnlyTag == TEXT("ZZZ_EditorOnlyInfo") || EditorOnlyTag == TEXT("EditorOnlyInfo"))
			{
				Factory.ProcessBuffer(DialoguePackage.Get(), RF_Transactional, EditorOnlyInfo[1]);
				DialogueAsset = Factory.DialogueAsset;
			}
			else
			{
				FString AssetPath = FPaths::Combine(Directory, AssetName + ".lua");
				FString LuaStr;
				if (FFileHelper::LoadFileToString(LuaStr, *AssetPath))
				{
				    if (LuaStr.StartsWith(FLuaAssetHelper::Ignore_Return))
				    {
                        LuaStr.RemoveFromStart(FLuaAssetHelper::Ignore_Return, ESearchCase::CaseSensitive);
                    }
					LuaStr.TrimStartInline();

					TSharedPtr<FLuaValue> LuaValue = nullptr;
					const TSharedRef<TLuaReader<>> LuaReader = TLuaReaderFactory<>::Create(LuaStr);
					if (FLuaSerializer::Deserialize(LuaReader, LuaValue) && LuaValue.IsValid())
					{
						TSharedPtr<FLuaTable> LuaTable = LuaValue->AsTable();
						if (LuaTable.IsValid())
						{
							DialogueAsset = NewObject<UDialogueAsset>(DialoguePackage.Get(), BPDialogue, FName(AssetName), RF_Transactional);
							TSharedPtr<FDialogueImporter> LuaImporter = MakeShared<FDialogueImporter>();
							LuaImporter->ImportLuaToObj(LuaTable, DialogueAsset);
						}
					}
				}
			}

			if (DialogueAsset)
			{
				Assets.Empty(1);
				int32 ID = FCString::Atoi(*AssetName);
				if (DialogueAsset->StoryLineID == 0 || DialogueAsset->StoryLineID != ID)
				{
					DialogueAsset->StoryLineID = ID;
				}
				Assets.Emplace(DialogueAsset);

				if (bool bNeedSave = DialogueEditorManager->CallEditorCommandWithDialogueAsset(ProcessFuncName, Assets))
				{
					FBehaviorActorSelector::Owner = DialogueAsset;
					DialogueEditorManager->ForceExportLuaTable(DialogueAsset);
				}
			}
		}

		FBehaviorActorSelector::Owner = LastOwner;

		UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
	}));


FAutoConsoleCommand KGExportDialogueCDOToLua(
	TEXT("KGStoryLine.ExportAllCDOToLua"),
	TEXT("KGStoryLine.ExportAllCDOToLua"),
	FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
		{
			UClass* BPDialogue = StaticLoadClass(UObject::StaticClass(), nullptr, *FLuaAssetHelper::BPDialogueAssetClassPath);
			if (!BPDialogue)
			{
				return;
			}

			TSet<const UObject*> CDOs;
			CDOs.Reserve(16);
			CDOs.Emplace(BPDialogue->GetDefaultObject());
			CDOs.Emplace(UDialogueTemplateAsset::StaticClass()->GetDefaultObject());
			const UDialogueEditorSettings* EditorSettings = GetDefault<UDialogueEditorSettings>();
			CDOs.Emplace(EditorSettings->PlayerType.Get()->GetDefaultObject());
			CDOs.Emplace(EditorSettings->CameraType.Get()->GetDefaultObject());
			CDOs.Emplace(EditorSettings->RoutePointEntityType.Get()->GetDefaultObject());

			for (auto Pairs : EditorSettings->TrackEntityClass)
			{
				CDOs.Emplace(Pairs.Key.Get()->GetDefaultObject());
				CDOs.Emplace(Pairs.Value.Get()->GetDefaultObject());
			}

			auto AddActionTrack = [&CDOs](const TSubclassOf<UDialogueActionTrack>& Track)
				{
					CDOs.Emplace(Track.GetDefaultObject());
					if (UDialogueActionTrack* ActionTrack = Cast<UDialogueActionTrack>(Track.Get()->GetDefaultObject()))
					{
						if (ActionTrack->SectionType.GetDefaultObject())
						{
							CDOs.Emplace(ActionTrack->SectionType.GetDefaultObject());
						}

						if (ActionTrack->GetSecondSectionType())
						{
							CDOs.Emplace(ActionTrack->GetSecondSectionType()->GetDefaultObject());
						}
					}
				};

			AddActionTrack(UDialogueStateControlTrack::StaticClass());

			for (const auto& ActorTrack : EditorSettings->ActorSubTracks)
			{
				CDOs.Emplace(ActorTrack.ActorTrackClass.Get()->GetDefaultObject());
				for (const auto& SubTrack : ActorTrack.SubTrackClasses)
				{
					AddActionTrack(SubTrack);
				}
			}

			for (const auto& RouterPointTrack : EditorSettings->RouterPointSubTracks)
			{
				AddActionTrack(RouterPointTrack);
			}

			for (const auto& CameraTrack : EditorSettings->CameraSubTracks)
			{
				AddActionTrack(CameraTrack);
			}

			auto AddTrack = [&CDOs](const TSubclassOf<UDialogueTrackBase>& Track)
				{
					CDOs.Emplace(Track.GetDefaultObject());
					if (auto* ActionTrack = Cast<UDialogueActionTrack>(Track.GetDefaultObject()))
					{
						if (ActionTrack->SectionType.GetDefaultObject())
						{
							CDOs.Emplace(ActionTrack->SectionType.GetDefaultObject());
						}

						if (ActionTrack->GetSecondSectionType())
						{
							CDOs.Emplace(ActionTrack->GetSecondSectionType()->GetDefaultObject());
						}
					}
				};

			// 获取AssetRegistry
			IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();

			// 设置过滤器
			FARFilter Filter;
			Filter.PackagePaths.Add(FName(TEXT("/Game/Blueprint/DialogueSystem/Track")));
			Filter.bRecursivePaths = true;
			Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());

			TArray<FAssetData> OutAssetData;
			AssetRegistry.GetAssets(Filter, OutAssetData);
			for (const auto& AssetData : OutAssetData)
			{
				if (UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset()))
				{
					if (Blueprint->GeneratedClass->IsChildOf(UDialogueTrackBase::StaticClass()))
					{
						AddTrack(Blueprint->GeneratedClass->GetDefaultObject()->GetClass());
					}
				}
			}

			for (const auto& BPTrack : EditorSettings->BlueprintTracks)
			{
				AddTrack(BPTrack);
			}

			for (const auto& SpecialTrack : EditorSettings->SpecialSubTracks)
			{
				AddTrack(SpecialTrack);
			}

			for (const auto& UniqueTrack : EditorSettings->UniqueTracks)
			{
				AddTrack(UniqueTrack);
			}

			for (const auto& Track : EditorSettings->DeprecatedTrackClass)
			{
				AddTrack(Track);
			}

			for (const auto& Track : EditorSettings->GenerateNoneClearClass)
			{
				AddTrack(Track);
			}

			FARFilter FilterSection;
			FilterSection.PackagePaths.Add(FName(TEXT("/Game/Blueprint/DialogueSystem/Section")));
			FilterSection.bRecursivePaths = true;
			FilterSection.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());

			OutAssetData.Empty();
			AssetRegistry.GetAssets(FilterSection, OutAssetData);
			for (const auto& AssetData : OutAssetData)
			{
				if (UBlueprint* Blueprint = Cast<UBlueprint>(AssetData.GetAsset()))
				{
					if (Blueprint->GeneratedClass->IsChildOf(UDialogueActionBase::StaticClass()))
					{
						CDOs.Emplace(Blueprint->GeneratedClass->GetDefaultObject());
					}
				}
			}

			TSharedPtr<FLuaTable> LuaTable = MakeShareable(new FLuaTable());
			TSharedPtr<FDialogueExporter> LuaExporter = MakeShared<FDialogueExporter>();
			LuaExporter->SetCanExportDefault(true);
			LuaExporter->SetCanExportObjectExtra(false);

			for (const auto* CDO : CDOs)
			{
				if (CDO)
				{
					TSharedPtr<FLuaTable> Table = MakeShareable(new FLuaTable());
					LuaExporter->ExportObjectToLua(const_cast<UObject*>(CDO), Table);
					LuaTable->SetField(CDO->GetClass()->GetName(), MakeShared<FLuaValueTable>(Table));
				}
			}

		// FSplineCurves
		FSplineCurves SplineCurves;
		int32 Index = SplineCurves.Position.AddPoint(0, FVector(0, 0, 0));
		SplineCurves.Position.Points[Index].ArriveTangent.Y = -130;
		SplineCurves.Position.Points[Index].LeaveTangent.Y = -130;
		SplineCurves.Position.Points[Index].InterpMode = EInterpCurveMode::CIM_CurveUser;
		
		SplineCurves.ReparamTable.AddPoint(0, 0);
		
		Index = SplineCurves.Rotation.AddPoint(0, FQuat::Identity);
		SplineCurves.Rotation.Points[Index].ArriveTangent.W = 1000.0003;
		SplineCurves.Rotation.Points[Index].LeaveTangent.W = 10000.0003;
		SplineCurves.Rotation.Points[Index].InterpMode = EInterpCurveMode::CIM_CurveAuto;
		
		Index = SplineCurves.Scale.AddPoint(0, FVector::One());
		SplineCurves.Scale.Points[Index].InterpMode = EInterpCurveMode::CIM_CurveAuto;
		
		TSharedPtr<FLuaTable> TableSplineCurves = MakeShareable(new FLuaTable());
		TSharedPtr<FLuaValue> LuaValSplineCurves = LuaExporter->ExportStructPropertyToLua(FSplineCurves::StaticStruct(), &SplineCurves, nullptr);
		LuaTable->SetField(TEXT("SplineCurves"), LuaValSplineCurves);

			// FTransform
			TSharedPtr<FLuaTable> LuaTransform = MakeShared<FLuaTable>();
			TSharedPtr<FLuaTable> LuaQuat = MakeShared<FLuaTable>();
			LuaQuat->SetField(TEXT("W"), MakeShared<FLuaValueNumber>(1));
			LuaQuat->SetField(TEXT("X"), MakeShared<FLuaValueNumber>(0));
			LuaQuat->SetField(TEXT("Y"), MakeShared<FLuaValueNumber>(0));
			LuaQuat->SetField(TEXT("Z"), MakeShared<FLuaValueNumber>(0));
			LuaTransform->SetField(TEXT("Rotation"), MakeShared<FLuaValueTable>(LuaQuat));

			TSharedPtr<FLuaTable> LuaTranslation = MakeShared<FLuaTable>();
			LuaTranslation->SetField(TEXT("X"), MakeShared<FLuaValueNumber>(0));
			LuaTranslation->SetField(TEXT("Y"), MakeShared<FLuaValueNumber>(0));
			LuaTranslation->SetField(TEXT("Z"), MakeShared<FLuaValueNumber>(0));
			LuaTransform->SetField(TEXT("Translation"), MakeShared<FLuaValueTable>(LuaTranslation));

			TSharedPtr<FLuaTable> LuaScale = MakeShared<FLuaTable>();
			LuaScale->SetField(TEXT("X"), MakeShared<FLuaValueNumber>(1));
			LuaScale->SetField(TEXT("Y"), MakeShared<FLuaValueNumber>(1));
			LuaScale->SetField(TEXT("Z"), MakeShared<FLuaValueNumber>(1));
			LuaTransform->SetField(TEXT("Scale3D"), MakeShared<FLuaValueTable>(LuaScale));

			LuaTable->SetField(TEXT("Transform"), MakeShared<FLuaValueTable>(LuaTransform));

			FString LuaStr;
			const TSharedRef<TLuaWriter<>> LuaWriter = TLuaWriterFactory<>::Create(&LuaStr);
			FLuaSerializer::Serialize(LuaTable.ToSharedRef(), LuaWriter);

			// 导出Lua表
			FString TemporaryLuaFile = FPaths::ProjectDir() + TEXT("Content/Script/Data/Config/Dialogue/DialogueClassCDO.lua");
			FString FullPath = FPaths::ConvertRelativePathToFull(TemporaryLuaFile);

			if (FPaths::FileExists(FullPath))
			{
				if (!USourceControlHelpers::CheckOutOrAddFile(FullPath))
				{
					UE_LOG(LogKGSL, Warning, TEXT("KGStoryLine.ExportAllCDOToLua: check out file %s failed, check your editor p4 connection!"), *TemporaryLuaFile);
					return;
				}
			}

			if (!FFileHelper::SaveStringToFile(LuaStr, *TemporaryLuaFile, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
			{
				UE_LOG(LogKGSL, Error, TEXT("KGStoryLine.ExportAllCDOToLua: save file %s failed"), *TemporaryLuaFile);
				return;
			}

			//导完可能没改变，就revert掉
			USourceControlHelpers::RevertUnchangedFile(FullPath, true);
		}));


