#include "DialogueEditor/LuaAsset/DialogueImporter.h"

#include "DialogueEditor/Graph/EpisodeGraph.h"
#include "DialogueEditor/Graph/EpisodeGraphSchema.h"
#include "KGStoryLineDefine.h"
#include "AI/NavigationSystemBase.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "EdGraph/EdGraph.h"
#include "EdGraph/EdGraphSchema.h"
#include "LuaSerialization/LuaTable.h"

void FDialogueImporter::FillUObject(const TSharedPtr<FLuaTable>& LuaTable, UObject* OutObject)
{
	TSharedPtr<FLuaTable> EditorOnly;
	if (LuaTable->HasField(TEXT("ZZZ_EditorOnly")))
	{
		EditorOnly = LuaTable->Values[TEXT("ZZZ_EditorOnly")]->AsTable();
		
		if (EditorOnly.IsValid() && EditorOnly->HasField(TEXT("ObjectMap")))
		{
			ObjectsLuaTable = EditorOnly->Values[TEXT("ObjectMap")]->AsTable();
		}
		else
		{
			ObjectsLuaTable = MakeShareable(new FLuaTable());
		}
	}
	else if (!ObjectsLuaTable.IsValid())
	{
		ObjectsLuaTable = MakeShareable(new FLuaTable());
	}
	
	for (FProperty* Property : TFieldRange<FProperty>(OutObject->GetClass(), EFieldIterationFlags::IncludeSuper))
	{
		void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(OutObject);
		const FString PropertyName = Property->GetName();
		if (LuaTable->Values.Contains(PropertyName))
		{
			FillFProperty(Property, PropertyAddress, LuaTable->Values[PropertyName], OutObject);
		}
		 else if (EditorOnly.IsValid() && EditorOnly->HasField(PropertyName))
		 {
			FillFProperty(Property, PropertyAddress, EditorOnly->Values[PropertyName], OutObject);
		 }
	}
}

bool FDialogueImporter::FillFDialogueAppearanceSelector(const FStructProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer)
{
	if (Address && LuaValue.IsValid())
	{
		if (LuaValue->Type == ELua::Number)
		{
			int32 AppearanceID = 0;
			LuaValue->TryGetNumber(AppearanceID);
			new (Address) FDialogueAppearanceSelector(AppearanceID);
			return true;
		}

		if (LuaValue->Type == ELua::Table)
		{
			return FLuaImporter::FillStructProperty(Property, Address, LuaValue, Outer);
		}
	}

	return false;
}

bool FDialogueImporter::FillFBehaviorActorSelector(const FStructProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer)
{
	if (Address && LuaValue.IsValid())
	{
		if (LuaValue->Type == ELua::String)
		{
			static_cast<FBehaviorActorSelector*>(Address)->TrackName = FName(LuaValue->AsString());
			return true;
		}

		if (LuaValue->Type == ELua::Table)
		{
			return FLuaImporter::FillStructProperty(Property, Address, LuaValue, Outer);
		}
	}

	return false;
}

bool FDialogueImporter::FillFDialoguePerformerSelector(const FStructProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer)
{
	if (Address && LuaValue.IsValid())
	{
		if (LuaValue->Type == ELua::String)
		{
			static_cast<FDialoguePerformerSelector*>(Address)->PerformerName = LuaValue->AsString();
			return true;
		}

		if (LuaValue->Type == ELua::Table)
		{
			return FLuaImporter::FillStructProperty(Property, Address, LuaValue, Outer);
		}
	}
	
	return false;
}

bool FDialogueImporter::FillFDialogueCameraSelector(const FStructProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer)
{
	if (Address && LuaValue.IsValid())
	{
		if (LuaValue->Type == ELua::String)
		{
			static_cast<FDialogueCameraSelector*>(Address)->CameraName = LuaValue->AsString();
			return true;
		}

		if (LuaValue->Type == ELua::Table)
		{
			return FLuaImporter::FillStructProperty(Property, Address, LuaValue, Outer);
		}
	}
	return false;
}

void FDialogueImporter::BuildLines(UDialogueAsset* DialogueAsset)
{
	ensure(DialogueAsset);
	DialogueAsset->EpisodesList.Empty();
	for (const auto& Episode : DialogueAsset->Episodes)
	{
	
		auto* DialogueEpisode = DialogueAsset->InstanceDialogueEpisode(Episode.EpisodeID);
		DialogueEpisode->OptionType = Episode.OptionType;
		DialogueEpisode->TimeLimit = Episode.TimeLimit;
		DialogueEpisode->TimeOutDefaultChoice = Episode.TimeOutDefaultChoice;
		DialogueAsset->AddDialogueEpisode(DialogueEpisode, Episode.EpisodeID);

		for (const auto& Option : Episode.Options)
		{
			UKGSLDialogueOption* Op = DialogueEpisode->InstanceOption();
			Op->DialogueID = Option.DialogueID;
			Op->DialogueText = Option.DialogueText;
			Op->EpisodeID = Option.EpisodeID;
			Op->DialogueLineIndex = Option.DialogueLineIndex;
			Op->Condition = Option.Condition;
			Op->CustomContent = Option.CustomContent;
			Op->Item = Option.Item;
			DialogueEpisode->AddOption(Op);
		}

		DialogueEpisode->DialogueLines.Empty();

		if (UDialogueTrackBase* Track = DialogueAsset->FindEpisodeTrackByName(Episode.EpisodeID, FName(TEXT("Dialogue"))))
		{
			for (auto* Section : Cast<UDialogueDialogueTrack>(Track)->ActionSections)
			{
				UDialogueDialogue* DialogueSection = Cast<UDialogueDialogue>(Section);
				auto* Line = DialogueEpisode->InstanceLine(Section->SectionName.ToString(), Section->LineUniqueIDLinked.ToString());
				DialogueEpisode->AddLine(Line);

				Line->Delay = DialogueSection->GetDelay();
				Line->Duration = DialogueSection->Duration;
				Line->EpisodeID = DialogueSection->EpisodeID;
				Line->ContentIndex = DialogueSection->ContentIndex;
				Line->ContentUI = StaticEnum<EDialogueContentUIType>()->GetDisplayNameTextByValue(static_cast<int64>(DialogueSection->ContentUI)).ToString();
				Line->Talker = DialogueSection->Talker;
				Line->TalkerName = DialogueSection->TalkerName;
				Line->CanSkip = DialogueSection->CanSkip;
				Line->bPause = DialogueSection->Pause;
				Line->Small = DialogueSection->Small;
				Line->SmallPos = DialogueSection->SmallPos;
				Line->SubTitle = DialogueSection->SubTitle;
				Line->SubTitleType = DialogueSection->SubTitleType;
			}
		}
	}
}

void FDialogueImporter::BuildEntityTree(UDialogueAsset* DialogueAsset)
{
	SCOPED_NAMED_EVENT(FDialogueImporter_BuildEntityTree, FColor::Cyan);
	TArray<UDialogueEntity*> AllEntities = DialogueAsset->GetAllEntities();
	for (auto Iter = PropertiesDeferredSettingValue.CreateIterator(); Iter; ++Iter)
	{
		if (Iter->Value.Property->IsA(FObjectProperty::StaticClass()))
		{
			const auto* ObjectProperty = CastField<FObjectProperty>(Iter->Value.Property);
			if (ObjectProperty->PropertyClass->IsChildOf<UDialogueEntity>())
			{
				FString ParentName = Iter->Value.LuaValue->AsString();
				if (UDialogueEntity** Parent = AllEntities.FindByPredicate([ParentName](const UDialogueEntity* Entity){ return Entity->TrackName == ParentName; }))
				{
					ObjectProperty->SetObjectPropertyValue(Iter->Value.Address, *Parent);
					Iter.RemoveCurrent();
				}
			}
		}
		else if (Iter->Value.Property->IsA(FWeakObjectProperty::StaticClass()))
		{
			const auto* ObjectProperty = CastField<FWeakObjectProperty>(Iter->Value.Property);
			if (ObjectProperty->PropertyClass->IsChildOf<UDialogueEntity>())
			{
				FString ParentName = Iter->Value.LuaValue->AsString();
				if (UDialogueEntity** Parent = AllEntities.FindByPredicate([ParentName](const UDialogueEntity* Entity){ return Entity->TrackName == ParentName; }))
				{
					ObjectProperty->SetObjectPropertyValue(Iter->Value.Address, *Parent);
					Iter.RemoveCurrent();
				}
			}
		}
	}
}

void FDialogueImporter::BuildTracksTree(UDialogueAsset* DialogueAsset)
{
	SCOPED_NAMED_EVENT(FDialogueImporter_BuildTracksTree, FColor::Turquoise);
	struct FTrackTreeBuilder
	{
		void operator()(FDialogueEpisode& Episode)
		{
			for (auto& Track : Episode.TrackList)
			{
				Build(Track, nullptr);
			}
		}

		static void Build(UDialogueTrackBase* Track, UDialogueTrackBase* Parent)
		{
			Track->Parent = Parent;
			for (auto* Child : Track->Childs)
			{
				Build(Child, Track);
			}

			for (auto* Action : Track->Actions)
			{
				BuildAction(Action, Track);
			}

			if (Track->IsA<UDialogueActionTrack>())
			{
				BuildAction(Cast<UDialogueActionTrack>(Track), Parent);
			}
		}

		static void BuildAction(UDialogueActionTrack* Action, UDialogueTrackBase* Parent)
		{
			Action->Parent = Parent;
			for (auto* Section : Action->ActionSections)
			{
				Section->DialogueAction = Action;
			}
		}
	} Builder;

	
	for (auto& Episode : DialogueAsset->Episodes)
	{
		Builder(Episode);
	}

	for (auto Iter = PropertiesDeferredSettingValue.CreateIterator(); Iter; ++Iter)
	{
		if (Iter->Value.Property->IsA(FObjectProperty::StaticClass()))
		{
			auto* ObjectProperty = CastField<FObjectProperty>(Iter->Value.Property);
			if (ObjectProperty->PropertyClass->IsChildOf<UDialogueTrackBase>() || ObjectProperty->PropertyClass->IsChildOf<UDialogueActionTrack>() )
			{
				Iter.RemoveCurrent();
			}
		}
		else if (Iter->Value.Property->IsA(FWeakObjectProperty::StaticClass()))
		{
			auto* ObjectProperty = CastField<FWeakObjectProperty>(Iter->Value.Property);
			if (ObjectProperty->PropertyClass->IsChildOf<UDialogueTrackBase>() || ObjectProperty->PropertyClass->IsChildOf<UDialogueActionTrack>() )
			{
				Iter.RemoveCurrent();
			}
		}
	}
}

void FDialogueImporter::BuildActorInfos(UDialogueAsset* DialogueAsset)
{
	SCOPED_NAMED_EVENT(FDialogueImporter_BuildActorInfos, FColor::Silver);
	DialogueAsset->ActorInfos.Empty();
	for (auto* Performer : DialogueAsset->PerformerList)
	{
		auto& ActorInfo = DialogueAsset->ActorInfos.AddDefaulted_GetRef();
		ActorInfo.PerformerName = Performer->TrackName;
		ActorInfo.AppearanceID.ApperanceID = Performer->AppearanceID;
		ActorInfo.IdleAnimation = Performer->IdleAnimLibAssetID;
		ActorInfo.InsID = Performer->InsID;
		ActorInfo.UseSceneActor = Performer->UseSceneActor;
		ActorInfo.bIsPlayer = Performer->IsPlayer();
	}
}

void FDialogueImporter::RegisterStructHandlers()
{
	if (bStructHandlersInited)
	{
		return;
	}
	
#define RegStructHandler(Struct, Callback) StructHandlers.Add(Struct::StaticStruct(), [SharedThis](const FStructProperty* Property, void* Address, const TSharedPtr<FLuaValue>& Value, UObject* Outer) -> bool\
	{\
		return SharedThis->Callback(Property, Address, Value, Outer);\
	})

	TSharedRef<FDialogueImporter> SharedThis = StaticCastSharedRef<FDialogueImporter>(AsShared());
	RegStructHandler(FDialogueAppearanceSelector, FillFDialogueAppearanceSelector);
	RegStructHandler(FBehaviorActorSelector, FillFBehaviorActorSelector);
	RegStructHandler(FDialoguePerformerSelector, FillFDialoguePerformerSelector);
	RegStructHandler(FDialogueCameraSelector, FillFDialogueCameraSelector);
	
	bStructHandlersInited = true;
}

void FDialogueImporter::CheckAndCopy(UDialogueTrackBase* TemplateTrack, UDialogueTrackBase* TargetTrack, UDialogueAsset* DialogueAsset)
{
	for (int32 IdxChild = 0; IdxChild < TemplateTrack->Childs.Num(); ++IdxChild)
	{
		UDialogueTrackBase*Child = nullptr;
		for (int32 Idx = 0; Idx < TargetTrack->Childs.Num(); ++Idx)
		{
			if (TargetTrack->Childs[Idx]->GetTrackName().ToString() == TemplateTrack->Childs[IdxChild]->GetTrackName().ToString())
			{
				Child = TargetTrack->Childs[Idx];
			}
		}

		if (!Child)
		{
			UDialogueTrackBase* NewTrack = DialogueAsset->RoamTrack(TemplateTrack->Childs[IdxChild]);
			TargetTrack->Childs.Insert(NewTrack, IdxChild);
		}
		else
		{
			CheckAndCopy(TemplateTrack->Childs[IdxChild], Child, DialogueAsset);
		}
	}

	for (int32 IdxAction = 0; IdxAction < TemplateTrack->Actions.Num(); ++IdxAction)
	{
		UDialogueTrackBase*Child = nullptr;
		for (int32 Idx = 0; Idx < TargetTrack->Actions.Num(); ++Idx)
		{
			if (TargetTrack->Actions[Idx]->GetTrackName().ToString() == TemplateTrack->Actions[IdxAction]->GetTrackName().ToString())
			{
				Child = TargetTrack->Actions[Idx];
			}
		}

		if (!Child)
		{
			UDialogueTrackBase* NewTrack = DialogueAsset->RoamTrack(TemplateTrack->Actions[IdxAction]);
			TargetTrack->Childs.Insert(NewTrack, IdxAction);
		}
		else
		{
			CheckAndCopy(TemplateTrack->Actions[IdxAction], Child, DialogueAsset);
		}
	}
}

void FDialogueImporter::AddDeferredSettingValue(const FProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer)
{
	FDeferredSettingValue& DeferredSettingProperty = PropertiesDeferredSettingValue.Emplace(Address);
	DeferredSettingProperty.Property = Property;
	DeferredSettingProperty.Address = Address;
	DeferredSettingProperty.Outer = Outer;
	DeferredSettingProperty.LuaValue = LuaValue;
}

void FDialogueImporter::ImportLuaToObj(TSharedPtr<class FLuaTable> LuaTable, UObject* OutObject)
{
	SCOPED_NAMED_EVENT(FDialogueImporter_ImportLuaToObj, FColor::Magenta);
	InitAssigners();
	RegisterStructHandlers();
	FillUObject(LuaTable, OutObject);

	if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(OutObject))
	{
		BuildEntityTree(DialogueAsset);
		BuildTracksTree(DialogueAsset);
		BuildLines(DialogueAsset);
		BuildActorInfos(DialogueAsset);
	}
}

bool FDialogueImporter::FillFObjectProperty(const FObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer)
{
	if (LuaValue->Type == ELua::Table)
	{
		const TSharedPtr<FLuaTable>& Table = LuaValue->AsTable();
		if (!Table.IsValid())
		{
			return false;
		}
		
		FString ObjName;
		
		UObject* Object = nullptr;
		//if (!ObjectMap.Contains(ObjectFullName))
		{
			UClass* Class = Property->PropertyClass;
			if (Table->HasField(TEXT("ObjectClass")))
			{
				FString ObjClassName = Table->Values[TEXT("ObjectClass")]->AsString();
				if (UClass* ObjClass = StaticLoadClass(UObject::StaticClass(), nullptr, *ObjClassName))
				{
					Class = ObjClass;
				}
			}
			
			Object = InstanceObject(Class, LuaValue, Outer);
		}

		ensure(Object);

		Property->SetObjectPropertyValue(Address, Object);
		return true;
	}

	if (LuaValue->Type == ELua::String && !LuaValue->AsString().IsEmpty())
	{
		FString ObjName = LuaValue->AsString();
		if (!ObjectMap.Contains(ObjName))
		{
			if (Property->HasMetaData(TEXT("ExportObjectByProperty")))
			{
				AddDeferredSettingValue(Property, Address, LuaValue, Outer);
				return true;
			}

			FLuaImporter::ConstructObject(Property->PropertyClass, ObjName, Outer);
		}
		
		if (ObjectMap.Contains(ObjName) && ObjectMap[ObjName].IsValid())
		{
			Property->SetObjectPropertyValue(Address, ObjectMap[ObjName].Get());
			return true;
		}
		
		UE_LOG(LogKGSL, Warning, TEXT("%s failed: %s is invalid."), ANSI_TO_TCHAR(__FUNCTION__), *ObjName);
	}
	
	return false;
}

bool FDialogueImporter::FillFWeakObjectProperty(const FWeakObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer)
{
	if (LuaValue->Type == ELua::String && !LuaValue->AsString().IsEmpty())
	{
		FString ObjName = LuaValue->AsString();

		if (!ObjectMap.Contains(ObjName))
		{
			if (Property->HasMetaData(TEXT("ExportObjectByProperty")))
			{
				AddDeferredSettingValue(Property, Address, LuaValue, Outer);
				return true;
			}

			FLuaImporter::ConstructObject(Property->PropertyClass, ObjName, Outer);
		}

		if (ObjectMap.Contains(ObjName))
		{
			Property->SetObjectPropertyValue(Address, ObjectMap[ObjName].Get());
			return true;
		}
	}
	
	return false;
}

bool FDialogueImporter::FillStructProperty(const FStructProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer)
{
	if (FStructHandler* StructHandler = StructHandlers.Find(Property->Struct))
	{
		return (*StructHandler)(Property, Address, LuaValue, Outer);
	}
	
	return FLuaImporter::FillStructProperty(Property, Address, LuaValue, Outer);
}

UObject* FDialogueImporter::InstanceObject(const UClass* PropertyClass, const TSharedPtr<FLuaValue>& LuaValue,  UObject* Outer)
{
	UObject* Obj = NewObject<UObject>(Outer, PropertyClass);
	ObjectMap.Add(Obj->GetPathName(), Obj);
	
	if (LuaValue.IsValid() && LuaValue->Type == ELua::Table)
	{
		const TSharedPtr<FLuaTable> LuaTable = LuaValue->AsTable();
		FillUObject(LuaTable, Obj);

		const FString Prefix = TEXT("CustomProperties");
		if (LuaTable->HasField(Prefix))
		{
			FString CustomProperties = LuaTable->Values[Prefix]->AsString();
			if (CustomProperties.StartsWith(Prefix))
			{
				CustomProperties = CustomProperties.Mid(Prefix.Len());
				CustomProperties.TrimStartInline();
				CustomProperties = CustomProperties.Replace(TEXT(": "), TEXT("="));
				const TCHAR* SourceText = *CustomProperties;
				Obj->ImportCustomProperties(SourceText, GWarn);
			}
		}
	}
	return Obj;
}

UDialogueAsset* FDialogueImporter::GetDialogueAsset(UObject* Object)
{
	UObject* Obj = Object;
	while (!Obj->IsA<UDialogueAsset>())
	{
		Obj = Obj->GetOuter(); 
	}

	if (Obj->IsA<UDialogueAsset>())
	{
		return Cast<UDialogueAsset>(Obj);
	}

	return nullptr;
}


