#include "DialogueEditor/CustomPropertyDialogueLineDetails.h"
#include "DetailWidgetRow.h"
#include "DetailCategoryBuilder.h"
#include "IDetailChildrenBuilder.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"


void FCustomPropertyDialogueLineDetails::CustomizeHeader(TSharedRef<IPropertyHandle> StructPropertyHandle,
                                                         FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
    HeaderRow.NameContent()
        [
            StructPropertyHandle->CreatePropertyNameWidget()
        ];

}

void FCustomPropertyDialogueLineDetails::CustomizeChildren(TSharedRef<IPropertyHandle> StructPropertyHandle,
    IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	TSharedPtr<IPropertyHandle> PerformerPropertyHandle = StructPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FDialogueAnimations, Performer));

	check(PerformerPropertyHandle.IsValid());

	StructBuilder.AddCustomRow(FText())
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.Padding(5.0f, 0.0f)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			[PerformerPropertyHandle->CreatePropertyNameWidget()]
			+ SHorizontalBox::Slot()
			[PerformerPropertyHandle->CreatePropertyValueWidget()]
		]
	];
}