#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Modes/DialogueEditorMode.h"
#include "DialogueEditor/DialogueEditorPreviewProxy.h"
#include "DialogueEditor/TabFactory/SDialogueEditorDetailTab.h"
#include "GameFramework/WorldSettings.h"
#include "DialogueEditor/DialogueEditorManager.h"
#include "DialogueEditor/Dialogue/DialogueActorTrack.h"
#include "DialogueEditor/Dialogue/DialogueCameraTrack.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "Engine/Selection.h"
#include "DialogueEditor/DialogueEditorCommands.h"
#include "DialogueEditor/DialogueEditorToolbar.h"
#include "DialogueEditor/DialogueEditorPreviewSettings.h"
#include "Camera/CameraActor.h"
#include "Kismet/GameplayStatics.h"
#include "AkGameplayStatics.h"
#include "AkAudioBank.h"
#include <AssetRegistry/IAssetRegistry.h>
#include "LevelLuaEditorProxyBase.h"
#include "Subsystems/UnrealEditorSubsystem.h"
#include "DialogueEditor/Dialogue/DialogueEntitySpline.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"
#include "Widgets/TimeLineBase/AnimTimelineTrack.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTrack.h"
#include "DialogueEditor/TabFactory/SDialogueEditorTimelineTab.h"
#include "EngineUtils.h"
#include "AssetToolsModule.h"
#include "ContentBrowserModule.h"
#include "UObject/SavePackage.h"
#include "../Private/ContentBrowserSingleton.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueActionTrackEditor.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "ScopedTransaction.h"
#include "Evaluation/MovieSceneCameraShakePreviewer.h"
#include "DialogueEditor/DialogueEditorAssetTypeActions.h"
#include "DialogueEditor/DialogueEditorDelegates.h"
#include "DialogueEditor/DialogueEditorSceneProxy.h"
#include "DialogueEditor/DialogueEditorUtilities.h"
#include "DialogueEditor/DialogueEditorLuaGameInstance.h"
#include "Widgets/Docking/SDockTab.h"
#include "DialogueEditor/DialogueEditorWorldExtension.h"
#include "GameMapsSettings.h"
#include "KGStoryLineDefine.h"
#include "DialogueEditor/KGStoryLineEditorSubSystem.h"
#include "LevelEditor.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackTimeline.h"
#include "DialogueEditor/AutoCreate/AutoTools.h"
#include "Components/CapsuleComponent.h"
#include "Misc/MessageDialog.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"
#include "Framework/Application/SlateApplication.h"
#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "3C/Camera/PostProcessNew/PostProcessManager.h"
#include "UObject/UObjectIterator.h"
#include "Styling/AppStyle.h"
#include "Widgets/Images/SImage.h"
#include "AssetRegistry/AssetRegistryModule.h"

#pragma optimize("",off)

const FName DialogueEditorAppIdentifier = TEXT("DialogueEditor");

const FName DialogueEditorModes::Main(TEXT("DialogueEditor_MainMode"));
const FName DialogueEditorModes::Template(TEXT("DialogueEditor_TemplateMode"));

const FName DialogueEditorEditorTabs::ViewportTab(TEXT("DialogueEditor_Viewport"));
const FName DialogueEditorEditorTabs::AssetEdit(TEXT("DialogueEditor_Asset"));
const FName DialogueEditorEditorTabs::AssetBrowser(TEXT("AssetBrowser"));
const FName DialogueEditorEditorTabs::AssetGraph(TEXT("Graph"));
const FName DialogueEditorEditorTabs::OptionGraph(TEXT("OptionGraph"));
const FName DialogueEditorEditorTabs::AssetDetails(TEXT("AssetDetails"));
const FName DialogueEditorEditorTabs::AssetOperationPanel(TEXT("OperationPanel"));
const FName DialogueEditorEditorTabs::Details(TEXT("DialogueEditor_Details"));
const FName DialogueEditorEditorTabs::PreviewSettings(TEXT("PreviewSettings"));

#define LOCTEXT_NAMESPACE "DialogueEditor"

// 处理多开的情况,返回是否处理成功允许开新资产了
bool IDialogueEditor::ProcessOtherOpen()
{
	if (UKGStoryLineEditorSubSystem::Get().IsDialogueEditorOpen())
	{
		EAppReturnType::Type Ret = FMessageDialog::Open(EAppMsgType::YesNo, FText::FromString(TEXT("剧情对话编辑器暂不允许多开,是否关闭旧的剧情对话资产并打开新的?")));
		if (Ret == EAppReturnType::Yes)
		{
			bool bCloseSuc = false;
			if (auto DialogueEditor = UKGStoryLineEditorSubSystem::Get().GetInUsingEditor())
			{
				bCloseSuc = DialogueEditor->CloseWindow(EAssetEditorCloseReason::AssetEditorHostClosed);
			}

			if (!bCloseSuc)
			{
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("剧情对话编辑器异常,请保留现场并联系程序解决.")));
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	return true;
}

TSharedPtr<IDialogueEditor> IDialogueEditor::OpenEditor(UObject* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost)
{
	check(InAsset);

	if (!ProcessOtherOpen())
	{
		return nullptr;
	}

	TSharedPtr<FDialogueEditor> EditorPtr;
	if (Cast<UDialogueTemplateAsset>(InAsset))
	{
		EditorPtr = MakeShareable(new FDialogueTemplateEditor());
	}
	else
	{
		EditorPtr = MakeShareable(new FDialogueMainEditor());
	}

	EditorPtr->InitializeEditor(Cast<UDialogueBaseAsset>(InAsset), InitToolkitHost);
	UE_LOG(LogKGSL, Log, TEXT("[KGSL]OpenEditor 0x%p Asset:%s"),
		EditorPtr.Get(), *InAsset->GetFullName());
	return EditorPtr;
}

FDialogueEditor::FDialogueEditor()
{
	EditorContextMgr = MakeUnique<FKGSLEdContextMgr>();
}

FDialogueEditor::~FDialogueEditor()
{
	if (EditorContextMgr)
	{
		EditorContextMgr = nullptr;
	}
	
	FDialogueEditorDelegates::OnTabActive.RemoveAll(this);
	if (FModuleManager::Get().IsModuleLoaded(TEXT("LevelEditor")))
	{
		FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
		LevelEditorModule.OnMapChanged().RemoveAll(this);
		GEditor->OnViewportClientListChanged().Remove(ViewportClientListChangedHandle);
	}
}

FKGSLEdContextMgr& FDialogueEditor::GetEditorContextMgr() const
{
	check(EditorContextMgr.IsValid());
	return *EditorContextMgr.Get();
}


void FDialogueEditor::InitLuaEnvironment()
{
	UWorld* World = GetWorld();
	check(World != nullptr);
    LuaEnv = UEditorLuaEnv::CreateLuaEnv(World, UDialogueEditorLuaGameInstance::StaticClass());
    UE_LOG(LogKGSL, Log, TEXT("[KGSL]InitLuaEnvironment FKGEditorLua:0x%p"), LuaEnv);
}

void FDialogueEditor::UnInitLuaEnvironment()
{
    UE_LOG(LogKGSL, Log, TEXT("[KGSL]UnInitLuaEnvironment FKGEditorLua:0x%p"), LuaEnv);
    if (LuaEnv)
	{
        UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
	}
}

bool FDialogueEditor::OnCanCloseLevelEditorTab()
{
	return false;
}

void FDialogueEditor::InitializeEditor(UDialogueBaseAsset* InAsset, const TSharedPtr<IToolkitHost>& InInitToolkitHost)
{
	UKGStoryLineEditorSubSystem::Get().RegisterAsset(InAsset, StaticCastSharedPtr<FDialogueEditor>(AsShared().ToSharedPtr()));
	
	FScopedSlowTask SlowTask(6.0f, FText::FromString(TEXT("Opening Dialogue Asset ....")));
	SlowTask.MakeDialog();
	SlowTask.EnterProgressFrame(1.0f);
	// 缓存编辑的资源指针
	check(InAsset);
	EditAsset = InAsset;
	FBehaviorActorSelector::Owner = InAsset;

	if(EditAsset->Episodes.Num() > 0)
	{
		CurrentSelectEpisodeID = EditAsset->Episodes[0].EpisodeID;
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("DialogueAsset Episode Num is 0 !!"));
	}

	SlowTask.EnterProgressFrame(1.0f);
	
	// 缓存配置资源指针
	PreviewSettings = GetMutableDefault<UDialogueEditorPreviewSettings>(UDialogueEditorPreviewSettings::StaticClass());
	PreviewSettings->ActiveEditor = this;
	PreviewSettings->OpendAssets.Add(EditAsset->GetName());
	// 初始化UE的资源编辑器
	const bool bCreateDefaultStandaloneMenu = true;
	const bool bCreateDefaultToolbar = true;
	FAssetEditorToolkit::InitAssetEditor(EToolkitMode::Standalone, InInitToolkitHost, DialogueEditorAppIdentifier, FTabManager::FLayout::NullLayout, bCreateDefaultStandaloneMenu, bCreateDefaultToolbar, InAsset);

	SlowTask.EnterProgressFrame(1.0f);

	// 绑定指令
	BindCommands();
	// 扩展工具栏
	ExtendToolbar();

	SlowTask.EnterProgressFrame(1.0f);

	// 创建预览场景
	CreatePreviewScene();
	InitBigWorldPreview();

	
	SlowTask.EnterProgressFrame(1.0f);

	// 初始化预览场景
	InitPreviewContext();

	//切换音频语言本地化版本
	FOnSetCurrentAudioCultureCallback Callback;
	UAkGameplayStatics::SetCurrentAudioCultureAsync(GetDefault<UDialogueEditorPreviewSettings>()->SoundBankLanguage, Callback);
	
	
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName).Get();
	TArray<FAssetData> Assets;
	AssetRegistry.GetAssetsByClass(UAkAudioBank::StaticClass()->GetClassPathName(), Assets, /*bSearchSubClasses=*/true);
	
	SlowTask.EnterProgressFrame(1.0f);
	// 添加编辑器模式
	AddApplicationMode(DialogueEditorModes::Main, MakeShareable(new FDialogueEditorMode_Main(SharedThis(this))));
	AddApplicationMode(DialogueEditorModes::Template, MakeShareable(new FDialogueEditorMode_Template(SharedThis(this))));

	SelectionChangedEventHandle = GEditor->GetSelectedActors()->SelectionChangedEvent.AddRaw(this,&FDialogueEditor::OnWorldSelectedChange);
	SelectionComponentModifiedEventHandle = GEditor->GetSelectedActors()->SelectionChangedEvent.AddRaw(this, &FDialogueEditor::OnWorldSelectComponentChange);

	FEditorDelegates::PostUndoRedo.AddRaw(this, &FDialogueEditor::OnUndoRedo);

	if (FModuleManager::Get().IsModuleLoaded(TEXT("LevelEditor")))
	{
		FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>("LevelEditor");
		LevelEditorModule.OnMapChanged().AddRaw(this, &FDialogueEditor::HandleMapChanged);
		AddOrRemoveLevelEditorCanTabCloseDelegate(true);
		ViewportClientListChangedHandle = GEditor->OnViewportClientListChanged().AddLambda([this]()
		{
			OnViewportClientListChanged();
		});
	}

	FDialogueEditorDelegates::OnTabActive.Broadcast(EditAsset->GetName(), false);

	CreateEditorWorldExtension();
#if WITH_EDITOR
    if (InAsset)
    {
        InAsset->OnEditorInitialized();
    }
#endif
} 


#pragma region Command
void FDialogueEditor::BindCommands()
{
	// 注册指令
	FDialogueEditorCommands::Register();

	const FDialogueEditorCommands& Commands = FDialogueEditorCommands::Get();
	const TSharedRef<FUICommandList>& UICommandsList = GetToolkitCommands();
	
	UICommandsList->MapAction(Commands.PlayBigworld, FExecuteAction::CreateSP(this, &FDialogueEditor::PlayBigWorld));
	UICommandsList->MapAction(Commands.Stop, FExecuteAction::CreateSP(this, &FDialogueEditor::Stop));
}

void FDialogueEditor::PlayBigWorld()
{
	PlayInternal();
}

void FDialogueEditor::PlayInternal()
{
	if (!PreviewScene.IsValid())
		return;
	
	OnLockCameraClicked(nullptr);
	if (PreviewProxy->IsPlaying())
	{
		if (PreviewProxy->IsPaused())
			PreviewProxy->Resume();
		else
			PreviewProxy->Pause();
	}
	else
	{
		Stop();
		float StartTime = PlayStartTime;
		if (PlayStartDialogueLineIndex != -1)
			StartTime = GetDialogueEditorManager()->GetDialogueLineStartTime(GetEditingAsset(), CurrentSelectEpisodeID, PlayStartDialogueLineIndex);
		PreviewProxy->Play(CurrentSelectEpisodeID, StartTime);
		if(ActiveViewportClient)
			ActiveViewportClient->SetGameView(true);
	}
}

bool FDialogueEditor::IsPlaying() const
{
	return PreviewProxy->IsPlaying();
}

bool FDialogueEditor::IsPaused() const
{
	return PreviewProxy->IsPaused();
}

bool FDialogueEditor::IsStopped() const
{
	return PreviewProxy->IsStopped();
}

void FDialogueEditor::Pause()
{
	if (PreviewProxy->IsPaused())
	{
		PreviewProxy->Resume();
	}
	else
	{
		PreviewProxy->Pause();
	}
}

void FDialogueEditor::Stop()
{
	GetDialogueEditorManager()->OnClickStop();
	if (!PreviewProxy->IsStopped())
		PreviewProxy->Stop();
	// 重新生成时，需要把当前选中的清除掉，不然会持有已销毁的Actor引用
	SetTrackSelected(nullptr);
	GEditor->SelectNone(false, true, false);

	if(ActiveViewportClient)
		ActiveViewportClient->SetGameView(false);

	//销毁Actor和Camerea并重新生成，因为播放期间已经破坏了Actor的数据
	PreviewScene->DestroyPreviewActors();

	PreviewScene->SpawnPreviewActors();
}

void FDialogueEditor::ForwardStep()
{
}

void FDialogueEditor::SetDialogueState(bool bPause)
{
	if (PreviewProxy->IsPlaying())
	{
		if (bPause)
			PreviewProxy->Pause();
		else
			PreviewProxy->Resume();
	}
}

void FDialogueEditor::BackwardStep()
{
}

bool FDialogueEditor::ShouldPauseWorld() const
{
	if (PreviewProxy->IsPaused())
	{
		return true;
	}

	return false;
}

FEditorViewportClient* FDialogueEditor::GetActiveViewportClient()
{
	if (ActiveViewportClient == nullptr)
	{
		ActiveViewportClient = GetUEMainViewportClient();
	}
	return ActiveViewportClient;
}

FEditorViewportClient* FDialogueEditor::GetUEMainViewportClient()
{
	FEditorViewportClient* Ret = nullptr;
	const TArray<class FLevelEditorViewportClient*>& LevelViewportClients = GEditor->GetLevelViewportClients();
	for (FLevelEditorViewportClient* LevelVC : LevelViewportClients)
	{
		if (LevelVC && LevelVC->IsPerspective())
		{
			Ret = LevelVC;
			break;
		}
	}
	if (Ret == nullptr && LevelViewportClients.Num() >= 2)
		Ret = LevelViewportClients[1];
	return Ret;
}

void FDialogueEditor::OnViewportClientListChanged()
{
	ActiveViewportClient = GetUEMainViewportClient();
}

UWorld* FDialogueEditor::GetWorld()
{
	return GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>()->GetEditorWorld();
}

bool FDialogueEditor::OnLockCameraClicked(class UDialogueCamera* DialogueEntity,bool IsLock)
{
	IsLockAutoCamera = IsLock;
	GetDialogueEditorManager()->OnLockCamera(DialogueEntity);

	if (GetDialogueAsset())
	{
		if (!BorderCameraEditing.IsValid())
		{
			SAssignNew(BorderCameraEditing, SImage)
			.ColorAndOpacity(FColor::Red)
			.Image(FAppStyle::GetBrush(TEXT("UMGEditor.DesignerMessageBorder")));
			FDialogueEditorUtilities::AddOverlayWidgetToViewport(BorderCameraEditing.ToSharedRef());
		}

		if (BorderCameraEditing.IsValid())
		{
			BorderCameraEditing->SetVisibility(DialogueEntity ? EVisibility::HitTestInvisible : EVisibility::Collapsed);
		}
	}

	if (ClickCameraEntity.IsValid() && ClickCameraEntity.Get() != DialogueEntity)
	{
		UE_LOG(LogKGSL, Log, TEXT("[KGSL]%s clear lock camera.last dialogue entity:%s transform = %s"), ANSI_TO_TCHAR(__FUNCTION__), *ClickCameraEntity->TrackName, *ClickCameraEntity->SpawnTransform.ToString());
	}

	ClickCameraEntity = DialogueEntity;
	if (DialogueEntity)
	{
		//Lock到一个相机的视角时，将其他相机隐藏，防止影响视线
		SetPreviewCameraVisible(nullptr, false);

		//Lock到一个相机时，更新位置到这个相机,只在选中的时候更新，后续就不用实时更新了
		SetViewportParamByCameraActor(DialogueEntity->GetCamera());

		GEditor->GetSelectedActors()->Modify();
		GEditor->SelectNone(true, true, false);
		GEditor->SelectActor(DialogueEntity->GetCamera(), true, true, true, true);
		UE_LOG(LogKGSL, Log, TEXT("[KGSL]%s lock camera.select dialogue entity:%s transform = %s"), ANSI_TO_TCHAR(__FUNCTION__), *DialogueEntity->TrackName, *DialogueEntity->SpawnTransform.ToString());
	}
	else
	{
		//Unlock相机时，显示相机模型
		SetPreviewCameraVisible(nullptr, true);
	}
	return true;
}

void FDialogueEditor::SetViewportParamByCameraActor(class ACameraActor* CameraActor)
{
	if (CameraActor)
	{
		if (FEditorViewportClient* ViewportClient = GetActiveViewportClient())
		{
			ViewportClient->SetViewLocation(CameraActor->GetCameraComponent()->GetComponentLocation());
			ViewportClient->SetViewRotation(CameraActor->GetCameraComponent()->GetComponentRotation());
			UE_LOG(LogKGSL, Log, TEXT("[KGSL]%s POV Location:%s Rotation:%s"), ANSI_TO_TCHAR(__FUNCTION__), *ViewportClient->GetViewLocation().ToString(), *ViewportClient->GetViewRotation().ToString());
		}
	}
}

void FDialogueEditor::OnWorldSelectedChange(UObject* SceneObject)
{
	TArray<AActor*> SelectedActors;
	GEditor->GetSelectedActors()->GetSelectedObjects<AActor>(SelectedActors);
	if (SelectedActors.Num() == 1)
	{
		if (SelectedActors[0] == SelectActor)
		//如果已经被选中返回
		{
			UE_LOG(LogTemp, Log, TEXT("已选中Actor %s 返回"), *(SelectedActors[0]->GetName()));
			return;
		}
		UE_LOG(LogTemp, Log, TEXT("选中Actor %s"), *(SelectedActors[0]->GetName()));
		SelectActor = SelectedActors[0];

		TArray<TSharedRef<class FAnimTimelineTrack>> AllTrackes = DialogueTimelineController.Pin()->GetRootTracks();
		//循环获取所有Tracks
		int index = 0;
		while (index < AllTrackes.Num())
		{
			if (AllTrackes[index]->GetChildren().Num() > 0)
				AllTrackes.Append(AllTrackes[index]->GetChildren());
			index++;
		}
		for (TSharedRef<class FAnimTimelineTrack> EditTrack : AllTrackes)
		{
			TSharedRef<FDialogueEditorTrack> DialogueEditTrack = StaticCastSharedRef<FDialogueEditorTrack>(EditTrack);
			if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(DialogueEditTrack->GetCachedTrack()))
			{
				if (SpawnableTrack->GetDialogueEntity())
				{
					AActor* EntityActor = GetDialogueEditorManager()->GetEntityActor(SpawnableTrack->GetDialogueEntity()->TrackName);
					if (EntityActor == SelectedActors[0])
					{
						//至此，转入TimelineTrack 逻辑进行驱动
						UE_LOG(LogTemp, Log, TEXT("从场景选中Actor，转入TimelineController驱动，以选中对应的Track"))
							DialogueTimelineController.Pin()->ClearTrackSelection();
						DialogueTimelineController.Pin()->SetTrackSelected(SpawnableTrack, false);
						break;
					}
				}
			}
		}
	}
}

void FDialogueEditor::OnWorldSelectComponentChange(UObject* Component)
{
	TArray<UActorComponent*> SelectedComponents;
	GEditor->GetSelectedComponents()->GetSelectedObjects<UActorComponent>(SelectedComponents);

	if (SelectedComponents.Num() == 0)
	{
		if (SelectCameraComponent.IsValid())
		{//这次没有选中的Component了，而且上次选择中的是子CameraComponent，则显示所有CameraActor
			SetSelectCameraComponent(nullptr);
		}
		else
		{//这次没有选中，上次选中的也不是子CameraComponent，不用处理

		}
	}
	else if (SelectedComponents.Num() == 1 && SelectedComponents[0] != SelectCameraComponent)
	{
		if (UCameraComponent* CameraComponent = Cast<UCameraComponent>(SelectedComponents[0]))
		{
			if (CameraComponent->ComponentHasTag("SubCamera"))
			{
				const UDialogueEditorPreviewSettings* DialogueEditorPreviewSettings = GetDefault<UDialogueEditorPreviewSettings>();
				if (DialogueEditorPreviewSettings->AutoAbsorb)
					SetSelectCameraComponent(CameraComponent);
			}
		}
	}
}

void FDialogueEditor::OnUndoRedo()
{
	GetDialogueEditorManager()->OnAssetPostEdit(GetDialogueAsset());
	TWeakObjectPtr<UObject> LastSelectObject = CurrentSelectObject.Num() > 0?CurrentSelectObject[CurrentSelectObject.Num()-1]:nullptr;
	GEditor->SelectNone(false, true, false);

	PreviewScene->DestroyPreviewActors();
	PreviewScene->SpawnPreviewActors();

	DialogueTimelineController.Pin()->RefreshTracks();

	if (SelectSectionLatest)
	{
		if(CurrentSelectSection.Num() > 0)
		{//RefreshTrack内部会SetTrackSelected，导致DetailsObject为空，这里重新设置一下
			SetSectionSelected(CurrentSelectSection[CurrentSelectSection.Num() - 1].Get());
		}
	}
	else if (LastSelectObject.IsValid())
	{//最新选中的是Track
		SetTrackSelected(LastSelectObject.Get());
	}
	DialogueEventConstructGraph.Broadcast();
}

void FDialogueEditor::HandleMapChanged(UWorld* NewWorld, EMapChangeType MapChangeType)
{
	if( ( MapChangeType == EMapChangeType::LoadMap || MapChangeType == EMapChangeType::NewMap || MapChangeType == EMapChangeType::TearDownWorld) )
	{
		UE_LOG(LogKGSL, Log, TEXT("[KGSL]FDialogueEditor::HandleMapChanged world:%s, EMapChangeType:%u"),
			NewWorld ? *NewWorld->GetFullName() : TEXT("Unknown"),
			static_cast<uint8>(MapChangeType));
		
		CloseWindow(EAssetEditorCloseReason::AssetUnloadingOrInvalid);
	}
}

void FDialogueEditor::OnMapBeginLoad(const FString& Filename, FCanLoadMap& CanLoad)
{
	if(PreviewScene)
	{
		PreviewScene->DestroyDialogueActors();

		//编辑器辅助震动模块被生成在了大世界World里面，需要解绑掉
		PreviewScene->DestroyShakePreviewer();
	}
	DestroyEditorWorldExtension();
}

void FDialogueEditor::OnMapOpened(const FString& Filename, bool bAsTemplate)
{
	CreateEditorWorldExtension();
}

void FDialogueEditor::SetSelectCameraComponent(UCameraComponent* CameraComponent)
{
	SelectCameraComponent = CameraComponent;

	if (SelectCameraComponent.IsValid())
	{
		SetPreviewCameraVisible(SelectCameraComponent->GetAttachParentActor(), false);

		UE_LOG(LogTemp, Log, TEXT("Select CameraComponent %s"), *SelectCameraComponent->GetName());

		if (FEditorViewportClient* ViewportClient = GetActiveViewportClient())
		{
			ViewportClient->SetViewLocation(SelectCameraComponent->GetComponentLocation());
			ViewportClient->SetViewRotation(SelectCameraComponent->GetComponentRotation());
		}
		GetDialogueEditorManager()->AddEditorPostProcess(true);
	}
	else
	{
		SetPreviewCameraVisible(nullptr, true);
		GetDialogueEditorManager()->AddEditorPostProcess(false);
	}
}

void FDialogueEditor::InitBigWorldPreview()
{
	PreviewScene->DestroyDialogueActors();

	UWorld* World = GetWorld();
	if (World && IsValid(World))
	{
		FURL URL;
		World->InitializeActorsForPlay(URL);
	}
	
	ActiveViewportClient = nullptr;
	if (GetActiveViewportClient())
	{
		GetActiveViewportClient()->ViewModifiers.AddSPLambda(this, [this](FEditorViewportViewModifierParams& Params)
		{
		    ModifyViewportClientView(Params);
		});
	}

	PreviewScene->ResetPreviewWorld();
	PreviewScene->AddDialogueWidget();
}

void FDialogueEditor::SetFocusCamera(AActor* CameraActor)
{
	FocusCamera = CameraActor;
	if (CameraActor)
	{//注视了这个Camera，处理这个Camera，其他都要隐藏
		SetPreviewCameraVisible(CameraActor, false);
	}
	else
	{//取消注视任何Camera,所有Camera都要显示
		SetPreviewCameraVisible(nullptr, true);
	}
}

AActor* FDialogueEditor::GetFocusCamera()
{
	return FocusCamera.Get();
}

void FDialogueEditor::SetCurrentSelectEpisode(int EpisodeID, bool bForceRefreshUI)
{
	UE_LOG(LogKGSL, Log, TEXT("[KGSL]FDialogueEditor::SetCurrentSelectEpisode EpisodeID:%d"), EpisodeID);
	if (CurrentSelectEpisodeID != EpisodeID)
	{
		CurrentSelectEpisodeID = EpisodeID;
		GetDialogueAsset()->SetCurrentSelectEpisodeID(EpisodeID);
		bForceRefreshUI = true;
	}
	if (bForceRefreshUI)
	{
		if (DialogueEditorTimelineTab.IsValid())
		{
			DialogueEditorTimelineTab.Pin()->Update();
		}
	}
}

int FDialogueEditor::GetCurrentEpisodeID()
{
	return CurrentSelectEpisodeID;
}

void FDialogueEditor::SetPlayStartTime(float InPlayStartTime)
{
	PlayStartTime = InPlayStartTime;
}

#pragma endregion Command

void FDialogueEditor::ExtendToolbar()
{
	// 创建工具栏
	if (!EditorToolbar.IsValid())
	{
		EditorToolbar = MakeShareable(new FDialogueEditorToolbar());
	}

	if (ToolbarExtender.IsValid())
	{
		RemoveToolbarExtender(ToolbarExtender);
		ToolbarExtender.Reset();
	}

	ToolbarExtender = MakeShareable(new FExtender);

	EditorToolbar->SetupToolbar(ToolbarExtender, SharedThis(this));

	EditorToolbar->AddTimelineToolbar(ToolbarExtender);

	AddToolbarExtender(ToolbarExtender);

}

void FDialogueEditor::OnAutoCameraToDialogueCamera()
{
	GetDialogueEditorManager()->OnActionNoticeToSectionInstance(1);
}


void FDialogueEditor::OnDialogueCameraToAutoCamera()
{
	GetDialogueEditorManager()->OnActionNoticeToSectionInstance(2);
}

void FDialogueEditor::RefreshAudio2FaceMatchAudioDialogue()
{
	if(!DialogueTimelineController.IsValid())
		return ;

	FDialogueEditorTimelineController* TimeLineCon = DialogueTimelineController.Pin().Get();
	if(!TimeLineCon)
		return ;

	TMap<FString, UDialogueActionBase*> DialogueAudioSectionMap;
	TMap<FString, UDialogueActionBase*> Audio2FaceSectionMap;

	for (auto TimelineTrack : TimeLineCon->GetAllTracks())
	{
		if (FDialogueEditorTrack* EditorTrack = StaticCast<FDialogueEditorTrack*>(&(TimelineTrack.Get())))
		{
			if (FDialogueTrackEditor* TrackEditor = StaticCast<FDialogueTrackEditor*>(EditorTrack->GetTrackEditor().Get()))
			{
				if(!TrackEditor->GetCacheTrack().IsValid())
					continue;

				UDialogueActionTrack* DiaAct = Cast<UDialogueActionTrack>(TrackEditor->GetCacheTrack());
				if(!DiaAct)
					continue;

				if (UDialogueDialogueTrack* DTrack = Cast<UDialogueDialogueTrack>(DiaAct))
				{
					for (UDialogueActionBase* _Section : DTrack->ActionSections)
					{
						for (FProperty* Property : TFieldRange<FProperty>(_Section->GetClass(), EFieldIteratorFlags::ExcludeSuper))
						{
							const FString StructCPPName = Property->GetCPPType();
							const FString PropName = Property->GetName();
							if (StructCPPName.Equals("UAkAudioEvent*") && PropName.Equals("Sound"))
							{
								if (FObjectProperty* ObjProperty = CastField<FObjectProperty>(Property))
								{
									UObject* _SoundObj = ObjProperty->GetObjectPropertyValue(ObjProperty->ContainerPtrToValuePtr<void>(_Section));
									if (IsValid(_SoundObj))
									{
										DialogueAudioSectionMap.Add(_SoundObj->GetName(), _Section);
									}
									
								}
							}
						}
					}
				}
				else if (DiaAct->GetTrackName().ToString() == "Audio2Face")
				{
					for (UDialogueActionBase* _Section : DiaAct->ActionSections)
					{
						for (FProperty* Property : TFieldRange<FProperty>(_Section->GetClass(), EFieldIteratorFlags::ExcludeSuper))
						{
							const FString StructCPPName = Property->GetCPPType();
							const FString PropName = Property->GetName();
							if (StructCPPName.Equals("FString") && PropName.Equals("FaceAnimID"))
							{
								if (FStrProperty* StrProperty = CastField<FStrProperty>(Property))
								{
									FString _FaceIDName = StrProperty->GetPropertyValue(StrProperty->ContainerPtrToValuePtr<void>(_Section));
									if (!_FaceIDName.IsEmpty())
									{
										Audio2FaceSectionMap.Add(_FaceIDName, _Section);
									}

								}
							}
						}
					}
				}

			}
		}
	}


	for (auto& Elem : DialogueAudioSectionMap)
	{
		UDialogueActionBase* * AudioSectionPtr = Audio2FaceSectionMap.Find(Elem.Key);
		if (AudioSectionPtr)
		{
			(*AudioSectionPtr)->SetStartTime(Elem.Value->GetStartTime());
		}
	}
}

void FDialogueEditor::OnAllEntityReady()
{
	if (bNeedCreateAutoCutsOnAllEntityReady)
	{
		bNeedCreateAutoCutsOnAllEntityReady = false;
		// 自动创建资产时，暂时只为1V1的生成自动镜头效果
		FDialogueAutoTools::CreateAutoLookAtAndCuts(GetDialogueAsset(), this, nullptr, false, false);
	}
}

// todo:先走通流程，验证可行性，后续优化代码
void FDialogueEditor::CreateAutoCuts()
{
	FDialogueAutoTools::CreateAutoLookAtAndCuts(GetDialogueAsset(), this, nullptr, true, true);
}

UDialogueBaseAsset* FDialogueEditor::GetEditingAsset()
{
	return Cast<UDialogueBaseAsset>(GetEditingObject());
}

class UDialogueAsset* FDialogueEditor::GetDialogueAsset()
{
	return Cast<UDialogueAsset>(GetEditingObject());
}

void FDialogueEditor::CreatePreviewScene()
{
	if (!PreviewScene.IsValid())
	{
		PreviewScene = MakeShareable(new FDialogueEditorSceneProxy(SharedThis(this)));

		PreviewScene->GetWorld()->GetWorldSettings()->SetIsTemporarilyHiddenInEditor(false);

		InitLuaEnvironment();
		PreviewScene->CreateDialogueEditorManager();
	    PreviewScene->SpawnGossipBubbleManager();
	}
}

void FDialogueEditor::AddOrRemoveLevelEditorCanTabCloseDelegate(bool bAdd)
{
	if (FModuleManager::Get().IsModuleLoaded(TEXT("LevelEditor")))
	{
		FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>("LevelEditor");
		auto LevelEditorTabMgr = LevelEditorModule.GetLevelEditorTabManager();

		static const FString LevelEditorTabNames[] = {
			TEXT("LevelEditorViewport"),
			TEXT("LevelEditorViewport_Clone1"),
			TEXT("LevelEditorViewport_Clone2"),
			TEXT("LevelEditorViewport_Clone3")
		};
		
		for (const auto& TabName : LevelEditorTabNames)
		{
			TSharedPtr<SDockTab> Tab = LevelEditorTabMgr->FindExistingLiveTab(FName(TabName));
			if (Tab.IsValid())
			{
				if (bAdd)
				{
					Tab->SetCanCloseTab(SDockTab::FCanCloseTab::CreateRaw(this, &FDialogueEditor::OnCanCloseLevelEditorTab));
				}
				else
				{
					Tab->SetCanCloseTab(SDockTab::FCanCloseTab());
				}
			}
		}
	}
}

void FDialogueEditor::SetSpecialActorVisible(class UWorld* World, bool Visible)
{
    if (!World || !IsValid(World))
    {
        return;
    }
    
	const UDialogueEditorSettings* DefaultSetting = GetDefault<UDialogueEditorSettings>();
	for (TActorIterator<AActor> ActorItr(World); ActorItr; ++ActorItr)
	{
		AActor* CurrentActor = *ActorItr;
		if (!IsValid(CurrentActor))
			continue;
		
		if(DefaultSetting->HideSceneActors.Contains(CurrentActor->GetClass()))
		{
			CurrentActor->GetRootComponent()->SetVisibility(Visible,true);
		}
	}
}

void FDialogueEditor::GetCachedPOVInfo(float& LocX, float& LocY, float& LocZ, float& Pitch, float& Yaw, float& Roll, float& OutFOV)
{
    if (PreviewProxy.IsValid() && PreviewProxy->IsPlaying())
    {
        LocX = CachedPOVLocation.X;
        LocY = CachedPOVLocation.Y;
        LocZ = CachedPOVLocation.Z;
        Pitch = CachedPOVRotation.Pitch;
        Yaw = CachedPOVRotation.Yaw;
        Roll = CachedPOVRotation.Roll;
        OutFOV = CachedPOVFOV;
    }
    else
    {
        LocX = 0;
        LocY = 0;
        LocZ = 0;
        Pitch = 0;
        Yaw = 0;
        Roll = 0;
        OutFOV = 0;
    }
}

TSharedPtr<FDialogueEditorSceneProxy> FDialogueEditor::GetPreviewScene() const
{
	return PreviewScene;
}

UDialogueEditorPreviewSettings* FDialogueEditor::GetPreviewSettings()
{
	return PreviewSettings.Get();
}

class UDialogueEditorManager* FDialogueEditor::GetDialogueEditorManager()
{
	return PreviewScene->GetDialogueEditorManager();
}

bool FDialogueEditor::OnRequestClose(EAssetEditorCloseReason InCloseReason)
{
	UE_LOG(LogKGSL, Log, TEXT("[KGSL]%s close reason:%d"), ANSI_TO_TCHAR(__FUNCTION__), static_cast<int32>(InCloseReason));
	if (EditAsset.IsValid() && EditAsset->GetPackage()->IsDirty())
	{
		const FText Message = FText::FromString(TEXT("对话资源修改后未保存，是否保存？"));
		EAppReturnType::Type Ret = FMessageDialog::Open(EAppMsgType::YesNo, Message);
		if (Ret == EAppReturnType::Yes)
		{
			SaveAsset_Execute();
			return true;
		}
		else if (Ret == EAppReturnType::No)
		{
			EditAsset->GetPackage()->ClearDirtyFlag();
			return true;
		}
	    else if (Ret == EAppReturnType::Cancel)
	    {
	        // 目前对话只会在开着编辑器切换场景的时候，强行关闭编辑器，这个时候不能单独保留对话编辑器，因为
	        // 对话编辑器需要持有的跟World强相关的对象都会无效，这个时候保存的数据都会错误的，只能直接关闭。
	        if (InCloseReason == EAssetEditorCloseReason::AssetUnloadingOrInvalid)
	        {
	            return true;
	        }

	        return false;
	    }
	}
	return true;
}

void FDialogueEditor::OnClose()
{
	UE_LOG(LogKGSL, Log, TEXT("[KSGL]FDialogueEditor::OnClose 0x%p"), this);
    GEditor->SelectNone(false, true, false);
	if (BorderCameraEditing.IsValid())
	{
		FDialogueEditorUtilities::RemoveOverlayWidgetToViewport(BorderCameraEditing.ToSharedRef());
		BorderCameraEditing.Reset();
	}
	PreviewSettings->OpendAssets.Remove(EditAsset->GetName());
	if(PreviewSettings->OpendAssets.Num() > 0)
	{
		GetPreviewScene()->SetPreviewActorsActive(true);
	}
	if(ActiveViewportClient)
	    ActiveViewportClient->SetGameView(false);
	PreviewScene->DestroyPreviewScene();
	if(GetActiveViewportClient())
		GetActiveViewportClient()->ViewModifiers.RemoveAll(this);
	PreviewSettings->ActiveEditor = nullptr;
	IDialogueEditor::OnClose();
	FBehaviorActorSelector::Owner = nullptr;

	GEditor->GetSelectedActors()->SelectionChangedEvent.Remove(SelectionChangedEventHandle);
	GEditor->GetSelectedComponents()->SelectionChangedEvent.Remove(SelectionComponentModifiedEventHandle);
	

	SetSpecialActorVisible(GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>()->GetEditorWorld(), true);
	FEditorDelegates::PostUndoRedo.RemoveAll(this);
	// FEditorDelegates::OnMapLoad.RemoveAll(this);
	// FEditorDelegates::OnMapOpened.RemoveAll(this);

	FDialogueEditorCommands::Unregister();

	UnInitLuaEnvironment();
	DestroyEditorWorldExtension();
	if(PreviewSettings->OpendAssets.Num() > 0)
	{
		FDialogueEditorDelegates::OnTabActive.Broadcast(PreviewSettings->OpendAssets[PreviewSettings->OpendAssets.Num() - 1], true);
	}

	AddOrRemoveLevelEditorCanTabCloseDelegate(false);
	UKGStoryLineEditorSubSystem::Get().UnregisterAsset(GetEditingAsset());
    
	CollectGarbage(GARBAGE_COLLECTION_KEEPFLAGS, true);
	for(FThreadSafeObjectIterator ObjIt(APlayerController::StaticClass()); ObjIt; ++ObjIt)
	{
		auto PC = Cast<APlayerController>(*ObjIt);
		if(PC && !PC->HasAnyFlags(RF_ClassDefaultObject))
		{				
			UE_LOG(LogTemp, Log, TEXT("DialogueEditor::OnClose, PlayerController=%s, Flags=0x%X"), *PC->GetFullName(), PC->GetFlags());
		}
	}
    for (FThreadSafeObjectIterator ObjIt(UCommonLuaGameInstanceBase::StaticClass()); ObjIt; ++ObjIt)
	{
        auto Obj = Cast<UCommonLuaGameInstanceBase>(*ObjIt);
		if(Obj && !Obj->HasAnyFlags(RF_ClassDefaultObject))
		{
			// auto LuaState = NS_SLUA::LuaState::get(Obj->LuaStateName);
            auto LuaState = Obj->GetLuaState();
            if (LuaState)
            {
                UE_LOG(LogTemp, Log, TEXT("DialogueEditor::OnClose, LuaGameInstance=%s, State=%p, Flags=0x%X"), *Obj->GetFullName(), LuaState, Obj->GetFlags());
            }
		}
	}
}

void FDialogueEditor::SetCurrentMode(FName NewMode)
{
	FWorkflowCentricApplication::SetCurrentMode(NewMode);
}


void FDialogueEditor::SaveAsset_Execute()
{
	FAssetEditorToolkit::SaveAsset_Execute();
}

void FDialogueEditor::RegisterTabSpawners(const TSharedRef<FTabManager>& InTabManager)
{
	WorkspaceMenuCategory = InTabManager->AddLocalWorkspaceMenuCategory(LOCTEXT("WorkspaceMenu_DialogueEditor", "DialogueEditor"));
	TSharedPtr<SDockTab> MajorTab = FGlobalTabmanager::Get()->GetMajorTabForTabManager(TabManager.ToSharedRef());
	MajorTab->SetOnTabActivated(SDockTab::FOnTabActivatedCallback::CreateSP(this, &FDialogueEditor::OnActiveTabChange));
	FAssetEditorToolkit::RegisterTabSpawners(InTabManager);
}

void FDialogueEditor::UnregisterTabSpawners(const TSharedRef<FTabManager>& InTabManager)
{
	FAssetEditorToolkit::UnregisterTabSpawners(InTabManager);
}

void FDialogueEditor::OnActiveTabChange(TSharedRef<SDockTab> ActiveTab, ETabActivationCause Cause)
{
	if(Cause != ETabActivationCause::UserClickedOnTab)
		return;
	FString CurrentTab = ActiveTab->GetTabLabel().ToString();
	FDialogueEditorDelegates::OnTabActive.Broadcast(CurrentTab, false);
}

FText FDialogueEditor::GetBaseToolkitName() const
{
	return LOCTEXT("AppLabel", "DialogueEditor");
}

void FDialogueEditor::CreateEditorWorldExtension()
{
	if(EditorWorldExtension.IsValid())
		return;
	UEditorWorldExtensionCollection* Collection = GEditor->GetEditorWorldExtensionsManager()->GetEditorWorldExtensions(GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>()->GetEditorWorld());
	if (Collection)
	{
		EditorWorldExtension = NewObject<UDialogueEditorWorldExtension>(Collection);
		EditorWorldExtension->AddToRoot();
		EditorWorldExtension->CachedEditor = SharedThis(this);
		Collection->AddExtension(EditorWorldExtension.Get());
	}
}

void FDialogueEditor::DestroyEditorWorldExtension()
{
	if (EditorWorldExtension.IsValid())
	{
		EditorWorldExtension->RemoveFromRoot();

		UEditorWorldExtensionCollection* Collection = GEditor->GetEditorWorldExtensionsManager()->GetEditorWorldExtensions(GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>()->GetEditorWorld());
		if (Collection && Collection->FindExtension(UDialogueEditorWorldExtension::StaticClass()))
		{
			Collection->RemoveExtension(EditorWorldExtension.Get());
		}
		EditorWorldExtension = nullptr;
	}
}

FName FDialogueEditor::GetToolkitFName() const
{
	return FName("DialogueEditor");
}

FString FDialogueEditor::GetWorldCentricTabPrefix() const
{
	return LOCTEXT("WorldCentricTabPrefix", "DialogueEditor").ToString();
}

FLinearColor FDialogueEditor::GetWorldCentricTabColorScale() const
{
	return FLinearColor(0.3f, 0.2f, 0.5f, 0.5f);
}

void FDialogueEditor::AddReferencedObjects(FReferenceCollector& Collector)
{
	Collector.AddReferencedObject(EditAsset);
}

void FDialogueEditor::SetSelectActorHere(const FVector& Location)
{
	FVector NewLocation = Location;
	if (CurrentSelectObject.Num() > 0)
	{
		if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(CurrentSelectObject[CurrentSelectObject.Num() -1]))
		{
			AActor* SelectEntityActor = GetDialogueEditorManager()->GetEntityActor(SpawnableTrack->GetDialogueEntity()->TrackName);
			if (SelectEntityActor)
			{
				if (UCapsuleComponent* CapsuleComponent = SelectEntityActor->FindComponentByClass<UCapsuleComponent>())
				{
					NewLocation.Z += CapsuleComponent->GetScaledCapsuleHalfHeight();
				}
				SelectEntityActor->SetActorLocation(NewLocation);
				PreviewScene->OnActorMoved(SelectEntityActor);

				GEditor->GetSelectedActors()->Modify();
				GEditor->SelectNone(true, true, false);
				GEditor->SelectActor(SelectEntityActor, true, true, true, true);
			}
		}
	}
}

void FDialogueEditor::InitPreviewContext()
{
	CreatePreviewProxy();
}

void FDialogueEditor::CreatePreviewProxy()
{
	PreviewProxy = MakeShareable(new FDialogueEditorPreviewProxy(EditAsset.Get(), SharedThis(this)));
}

TSharedPtr<FDialogueEditorPreviewProxy> FDialogueEditor::GetPreviewProxy() const
{
	return PreviewProxy;
}

TSharedPtr<SDialogueEditorViewport> FDialogueEditor::GetViewportWidget()
{
	return Viewport;
}

void FDialogueEditor::SetDetailWidget(TSharedPtr<SDialogueEditorDetailTab> InDetailWidget)
{
	DetailWidgetPtr = InDetailWidget;
}

void FDialogueEditor::ShowObjectDetail(UObject* InObject)
{
	if (DetailWidgetPtr.IsValid())
	{
		DetailWidgetPtr->SetDetailObject(InObject);
	}
}

bool FDialogueEditor::IsTrackPressingCtrl()
{
	return IsTrackPressCtrl;
}

void FDialogueEditor::SetTrackSelected(UObject* InObject, bool bSelectActor)
{
	UE_LOG(LogTemp, Log, TEXT("SetTrackSelected %s"), InObject ? *(InObject->GetName()) :TEXT("None"));

	CurrentSelectSection.Empty();
	ShowObjectDetail(InObject);

	if(InObject && !CurrentSelectObject.Contains(InObject))
	{
		if(IsTrackPressCtrl)
			CurrentSelectObject.Add(InObject);
		else
		{
			CurrentSelectObject.Empty();
			CurrentSelectObject.Add(InObject);
		}
	}

	if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(InObject))
	{
		SelectSectionLatest = false;
		if(UDialogueEditorManager* EditorMgr  = GetDialogueEditorManager())
		{
			if(SpawnableTrack->GetDialogueEntity())
			{
				if (AActor* EntityActor = EditorMgr->GetEntityActor(SpawnableTrack->GetDialogueEntity()->TrackName))
				{
					SelectActor = EntityActor;

					if (bSelectActor)
					{
						GEditor->GetSelectedActors()->Modify();
						GEditor->SelectNone(true, true, false);
						GEditor->SelectActor(SelectActor.Get(), true, true, true, true);
						GEditor->NoteSelectionChange();
					}

					PreviewScene->Tick(0);
					// Viewport->GetViewportClient()->Tick(0);
				}
			}
			else
			{
				UE_LOG(LogTemp, Log, TEXT("%s select actor failed:%s track name:%s"), ANSI_TO_TCHAR(__FUNCTION__), *InObject->GetFullName(), *SpawnableTrack->GetTrackName().ToString());
			}
		}
	}
	else if(UDialogueActionTrack* DialogueAction = Cast<UDialogueActionTrack>(InObject))
	{
		SelectSectionLatest = true;
		if (!DialogueAction->IsA(UDialogueCameraCutTrack::StaticClass()))
		{
			UDialogueTrackBase* ParentTrack = DialogueAction->Parent;
			while (ParentTrack)
			{
				UDialogueSpawnableTrack* ParentSpawnableTrack = Cast<UDialogueSpawnableTrack>(ParentTrack);
				if (ParentSpawnableTrack)
				{
					if (UDialogueEditorManager* EditorMgr = GetDialogueEditorManager())
					{
						if (AActor* EntityActor = EditorMgr->GetEntityActor(ParentSpawnableTrack->GetDialogueEntity()->TrackName))
						{
							SelectActor = EntityActor;

							if (bSelectActor)
							{
								GEditor->GetSelectedActors()->Modify();
								GEditor->SelectNone(true, true, false);
								GEditor->SelectActor(SelectActor.Get(), true, true, true, true);
								GEditor->NoteSelectionChange();
							}
							PreviewScene->Tick(0);
							// Viewport->GetViewportClient()->Tick(0);
						}
					}
					break;
				}
				ParentTrack = ParentTrack->Parent;
			}
		}
	}
}

void FDialogueEditor::DoubleClickTrack(UObject* InObject)
{
	UE_LOG(LogTemp, Log, TEXT("DoubleClickTrack %s"), InObject ? *(InObject->GetName()) : TEXT("None"));

	CurrentSelectSection.Empty();
	ShowObjectDetail(InObject);

	if (!CurrentSelectObject.Contains(InObject))
	{
		if (IsTrackPressCtrl)
			CurrentSelectObject.Add(InObject);
		else
		{
			CurrentSelectObject.Empty();
			CurrentSelectObject.Add(InObject);
		}
	}

	if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(InObject))
	{
		SelectSectionLatest = false;
		AActor* EntityActor = GetDialogueEditorManager()->GetEntityActor(SpawnableTrack->GetDialogueEntity()->TrackName);
		if (EntityActor)
		{
			SelectActor = EntityActor;

			GEditor->GetSelectedActors()->Modify();
			GEditor->SelectNone(true, true, false);
			GEditor->SelectActor(SelectActor.Get(), true, true, true, true);
			GEditor->NoteSelectionChange();

			UDialogueCamera* DialogueCamera = Cast<UDialogueCamera>(SpawnableTrack->GetDialogueEntity());
			if (DialogueCamera)
			{//双击相机
				OnLockCameraClicked(ClickCameraEntity == DialogueCamera ? nullptr : DialogueCamera);
			}
			else
			{//双击其他Actor
				if (GetDefault<UDialogueEditorSettings>()->EnableAutoLocateSceneActor)
					GEditor->MoveViewportCamerasToActor(*SelectActor, true);

				//这里必须把相机Lock去掉，否则相击位置会被同步到上一行自适应的位置去
				OnLockCameraClicked(nullptr);
			}
			PreviewScene->Tick(0);
			// Viewport->GetViewportClient()->Tick(0);
		}
	}
}

void FDialogueEditor::SetSectionSelected(class UDialogueActionBase* Section)
{
	IsTrackPressCtrl = false;
	CurrentSelectObject.Empty();
	SelectSectionLatest = true;

	if(Section != nullptr)
	{
		const FModifierKeysState ModifierKeys = FSlateApplication::Get().GetModifierKeys();
		bool IsCtrlDown = ModifierKeys.IsControlDown();
		bool IsShiftDown = ModifierKeys.IsShiftDown();

		if (!CurrentSelectSection.Contains(Section))
		{
			UE_LOG(LogTemp, Log, TEXT("Select Section %s"), *Section->GetSectionName().ToString());
			if (IsCtrlDown)
				CurrentSelectSection.Add(Section);
			else if (IsShiftDown)
			{
				if (CurrentSelectSection.Num() > 0)
				{
					// 理论上应该缓存选中的SDialogueEditorActionTrackNode 但是已经缓存了UDialogueActionSection 编辑器就不考虑遍历性能
					for (auto TimelineTrack : DialogueTimelineController.Pin()->GetAllTracks())
					{
						if (FDialogueEditorTrack* EditorTrack = StaticCast<FDialogueEditorTrack*>(&(TimelineTrack.Get())))
						{
							if (FDialogueTrackEditor* TrackEditor = StaticCast<FDialogueTrackEditor*>(EditorTrack->GetTrackEditor().Get()))
							{
								//  StaticCast 不能准确判断轨道是否为FDialogueActionTrackEditor 这里额外加上判断条件
								if (UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(TrackEditor->GetCacheTrack()))
									continue;
								EDialogueTrack::Type TrackType = TrackEditor->GetCacheTrack()->GetType();
								if (TrackType == EDialogueTrack::Type::Camera || TrackType == EDialogueTrack::Type::Actor ||
									TrackType == EDialogueTrack::Type::RoutePoint)
									continue;
								if (FDialogueActionTrackEditor* ActionTrackEditor = StaticCast<FDialogueActionTrackEditor*>(TrackEditor))
								{
									for (TSharedPtr<SDialogueEditorActionTrackNode> SectionAction : ActionTrackEditor->GetTrackWidget()->GetActionNodes())
									{
										if (SectionAction->GetActionNodeData().GetAction()->GetDialogueAction() != CurrentSelectSection[0]->GetDialogueAction())
											continue;
										if (SectionAction->GetActionNodeData().GetStartTime() > CurrentSelectSection[0]->GetStartTime() &&
											SectionAction->GetActionNodeData().GetStartTime() <= Section->GetStartTime())
										{
											CurrentSelectSection.Add(SectionAction->GetActionNodeData().GetAction());
										}

									}
								}
							}
						}
					}
				}
			}
			else
			{
				CurrentSelectSection.Empty();
				CurrentSelectSection.Add(Section);
			}
		}
		else
		{//已经包含了Section
			if (IsCtrlDown)
			{//Press Ctrl，去掉这个Section的选中
				CurrentSelectSection.Remove(Section);
				UE_LOG(LogTemp, Log, TEXT("UnSelect Section %s"), *Section->GetSectionName().ToString());
				return;
			}
			else
			{//没按Ctrl
				CurrentSelectSection.Empty();
				CurrentSelectSection.Add(Section);
			}
		}
	}
	
	ShowObjectDetail(Section);
	FDialogueEditorDelegates::OnSectionSelect.Broadcast(CurrentSelectSection);
}

void FDialogueEditor::SetPreviewCameraVisible(AActor* ExcludeActor, bool Visible)
{
	UDialogueBaseAsset* BaseAsset = GetEditingAsset();
	if(BaseAsset == nullptr)
		return;
	for (UDialogueEntity* DialogueEntity: BaseAsset->CameraList)
	{
		if (DialogueEntity)
		{
			AActor* Actor = DialogueEntity->GetEntity();
			if (Actor && Actor != ExcludeActor)
			{
				Actor->GetRootComponent()->SetVisibility(Visible, true);
			}
		}
	}
}

void FDialogueEditor::AddDialogueActor(class UDialogueEntity* DialogueEntity)
{
	if (class UDialogueActor* DialogueActor = Cast<UDialogueActor>(DialogueEntity))
	{
		PreviewScene->SpawnDialogueActor(DialogueActor);
	}
	else if (class UDialogueCamera* DialogueCamera = Cast<UDialogueCamera>(DialogueEntity))
	{
		PreviewScene->SpawnCamera(DialogueCamera);
	}
	else if (class UDialogueEntitySpline* DialogueEntitySpline = Cast<UDialogueEntitySpline>(DialogueEntity))
	{
		PreviewScene->SpawnDialogueSplineActor(DialogueEntity);
	}
	else
	//RouterPoint也包含在内
		PreviewScene->SpawnNewEntity(DialogueEntity);
}

void FDialogueEditor::RemoveDialogueActor(class UDialogueEntity* DialogueEntity)
{
	if (GEditor->GetSelectedActors()->IsSelected(GetEntityActor(DialogueEntity)))
	{
		GEditor->SelectNone(false, true, false);
	}
	if (class UDialogueActor* DialogueActor = Cast<UDialogueActor>(DialogueEntity))
	{
		PreviewScene->RemoveDialogueActor(DialogueActor);
	}
	else if (class UDialogueCamera* DialogueCamera = Cast<UDialogueCamera>(DialogueEntity))
	{
		PreviewScene->RemoveCamera(DialogueCamera);
	}
	else if (class UDialogueEntitySpline* DialogueEntitySpline = Cast<UDialogueEntitySpline>(DialogueEntity))
	{
		PreviewScene->RemoveDialogueSplineActor(DialogueEntity);
	}
	else
		//RouterPoint也包含在内
		PreviewScene->RemoveNewEntity(DialogueEntity);
}

AActor* FDialogueEditor::GetEntityActor(class UDialogueEntity* DialogueEntity)
{
	if(DialogueEntity == nullptr)
		return nullptr;
	if(GetDialogueEditorManager() == nullptr)
		return nullptr;
	return GetDialogueEditorManager()->GetEntityActor(DialogueEntity->TrackName);
}

void FDialogueEditor::SetViewportCameraCutEnabled(bool bEnabled)
{
	bViewportCameraCutEnabled = bEnabled;
	if (bEnabled)
	{
		if (GetActiveViewportClient())
			GetActiveViewportClient()->ViewModifiers.AddSPLambda(this, [this](FEditorViewportViewModifierParams& Params)
			{
			    ModifyViewportClientView(Params);
			});
	}
	else
	{
		if (GetActiveViewportClient())
			GetActiveViewportClient()->ViewModifiers.RemoveAll(this);
	}
}

void FDialogueEditor::ModifyViewportClientView(FEditorViewportViewModifierParams& Params)
{
	//使用锁定的Camera参数，只在选中的时候更新视口位置和旋转（一次性的，意味着玩家锁定Camera后还可以移动）
	//位置就不要实时刷新了，否则玩家就无法移动
	//其他FOV和DOF必须在这里更新，否则会被冲掉
	if (ClickCameraEntity.IsValid())
	{
		ACameraActor* CameraActor = ClickCameraEntity->GetCamera();
		if (CameraActor)
		{
			Params.ViewInfo.FOV = CameraActor->GetCameraComponent()->FieldOfView;
			Params.ViewInfo.PostProcessBlendWeight = 1.0f;
			Params.ViewInfo.PostProcessSettings = CameraActor->GetCameraComponent()->PostProcessSettings;
		}
		if (UDialogueCamera* DialogueCameraEntity = ClickCameraEntity.Get())
		{
			// 景深DOF可视化
			if (DialogueCameraEntity->bEnableCameraDOF_Debug)
			{
				// DialogueCameraEntity->CreateDebugFocusPlane();
				DialogueCameraEntity->UpdateDebugFocusPlane();
			}
			// else
			// {
			// 	DialogueCameraEntity->DestroyDebugFocusPlane();
			// }
		}
	}
	if (SelectCameraComponent.IsValid())
	{
		Params.ViewInfo.FOV = SelectCameraComponent->FieldOfView;
		Params.ViewInfo.PostProcessBlendWeight = 1.0f;
		Params.ViewInfo.PostProcessSettings = SelectCameraComponent->PostProcessSettings;
	}


	static int32 LastFrameNumber = 0;
	if (LastFrameNumber != GFrameNumber)
	{
		Params.ViewInfo.PostProcessSettings = PreviewScene->GetDialogueEditorManager()->SetPostProcessSettingMaterial(Params.ViewInfo.PostProcessSettings);
		LastFrameNumber = GFrameNumber;
	}

	if (PreviewScene && PreviewScene->PlayerController.IsValid() && PreviewScene->PlayerController->PlayerCameraManager)
	{
		if (IsPlaying())
		{
			FMinimalViewInfo ViewInfo = PreviewScene->PlayerController->PlayerCameraManager->GetCameraCacheView();
			Params.ViewInfo = ViewInfo;
		}
	}
	
	if (LuaEnv && IsValid(LuaEnv->GetLuaGameInstance()))
	{
		if (UPostProcessManager* PostProcessManager = Cast<UPostProcessManager>(LuaEnv->GetManagerByType(EManagerType::EMT_PostProcessManager)))
		{
			const TArray<float>* CameraAnimPPBlendWeightsPtr = nullptr;
			const TArray<FPostProcessSettings>* CameraAnimPPSettingsPtr = nullptr;
			PostProcessManager->GetCachedPostProcessBlends(CameraAnimPPSettingsPtr, CameraAnimPPBlendWeightsPtr);
			if (CameraAnimPPBlendWeightsPtr && CameraAnimPPSettingsPtr)
			{
				auto& CameraAnimPPSettings = *CameraAnimPPSettingsPtr;
				auto& CameraAnimPPBlendWeights = *CameraAnimPPBlendWeightsPtr;
				check(CameraAnimPPSettings.Num() == CameraAnimPPBlendWeights.Num());
				for (int32 PPIdx = 0; PPIdx < CameraAnimPPSettings.Num(); ++PPIdx)
				{
					Params.AddPostProcessBlend(CameraAnimPPSettings[PPIdx], CameraAnimPPBlendWeights[PPIdx]);
				}
			}
		}
	}
	
	if (const APlayerCameraManager* CameraManager = UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0))
	{
    	TArray<float> const* CameraAnimPPBlendWeights;
    	TArray<FPostProcessSettings> const* CameraAnimPPSettings;
    
    	CameraManager->GetCachedPostProcessBlends(CameraAnimPPSettings, CameraAnimPPBlendWeights);
    
    	for (int32 PPIdx = 0; PPIdx < CameraAnimPPBlendWeights->Num(); ++PPIdx)
    	{
    		Params.AddPostProcessBlend((*CameraAnimPPSettings)[PPIdx], (*CameraAnimPPBlendWeights)[PPIdx]);
    	}
    }

	if (PreviewScene && PreviewScene->IsInRadioPreviewer())
	{
		if (PreviewScene->IsFrameRadioVertical())
		{
			Params.ViewInfo.AspectRatioAxisConstraint = EAspectRatioAxisConstraint::AspectRatio_MaintainYFOV;
		}
		else
		{
			Params.ViewInfo.AspectRatioAxisConstraint = EAspectRatioAxisConstraint::AspectRatio_MaintainXFOV;
		}
	}

	if(PreviewScene && PreviewScene->CameraShakePreviewer)
	{
	    PreviewScene->CameraShakePreviewer->ModifyView(Params);
	}

    if (PreviewProxy.IsValid() && PreviewProxy->IsPlaying())
    {
        CachedPOVLocation = Params.ViewInfo.Location;
        CachedPOVRotation = Params.ViewInfo.Rotation;
        CachedPOVFOV = Params.ViewInfo.FOV;
        // UE_LOG(LogKGSL, Log, TEXT("[DialogueEditor]%s location:%s rotation:%s FOV:%f"), ANSI_TO_TCHAR(__FUNCTION__), *CachedPOVLocation.ToString(), *CachedPOVRotation.ToString(), CachedPOVFOV);
    }
}

#pragma region Template

void FDialogueTemplateEditor::InitializeEditor(class UDialogueBaseAsset* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost)
{
	FDialogueEditor::InitializeEditor(InAsset, InitToolkitHost);
	// 设置编辑器模式
	SetCurrentMode(DialogueEditorModes::Template);
}

void FDialogueTemplateEditor::BindCommands()
{

}

void FDialogueTemplateEditor::ExtendToolbar()
{

}

#pragma endregion Template


#pragma region Main
FDialogueMainEditor::~FDialogueMainEditor()
{
	PreviewScene->GetDialogueEditorManager()->OnDialoguePlayerSetState().RemoveAll(this);
	if (UDialogueAsset* Asset = Cast< UDialogueAsset>(EditAsset))
	{
		Asset->OnDialogueAssetTemplateChanged().RemoveAll(this);
		Asset->OnCustomSelectorChanged().RemoveAll(this);
		Asset->OnDialogueEpisodeChanged().Clear();
	}
}

void FDialogueMainEditor::InitializeEditor(class UDialogueBaseAsset* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost)
{
	FDialogueEditor::InitializeEditor(InAsset, InitToolkitHost);
	// 设置编辑器模式
	SetCurrentMode(DialogueEditorModes::Main);
	if(EditAsset->Episodes.Num() > 0) 
	{
		if(EditAsset->Episodes[0].GetAllTracks().Num() <=0)
		{
			OnDefaultInitExcelData();
		}

	}
	if (UDialogueAsset* Asset = Cast< UDialogueAsset>(EditAsset))
	{
		Asset->OnDialogueAssetTemplateChanged().AddRaw(this, &FDialogueMainEditor::OnDialogueAssetTemplateChanged);
		Asset->OnCustomSelectorChanged().AddRaw(this, &FDialogueMainEditor::OnCustomSelectorChanged);
		Asset->GetOnEpisodeLinesCountChange().BindRaw(this, &FDialogueMainEditor::OnAssetEpisodeLinesCountChange);
	}
	PreviewScene->GetDialogueEditorManager()->OnDialoguePlayerSetState().AddRaw(this, &FDialogueMainEditor::SetDialogueState);
}

void FDialogueMainEditor::GetSaveableObjects(TArray<UObject*>& OutObjects) const
{
	
}

void FDialogueMainEditor::SaveAsset_Execute()
{
	if (UDialogueAsset* DialogueAsset = GetDialogueAsset())
	{
	    if (PreviewProxy.IsValid() && PreviewProxy->IsPlaying())
	    {
	        PreviewProxy->Stop();
	    }
	    
		GetDialogueEditorManager()->SetMetaDataTag(DialogueAsset);
		
		DialogueAsset->RemoveAllUnReferencedObject();

        if (!GetDialogueEditorManager()->CanSaveAsset(DialogueAsset))
        {
            return;
        }

		if (!GetDialogueEditorManager()->ForceExportLuaTable(DialogueAsset))
		{
			return;
		}

		GenerateDialogue();
		
		// generate后会导致资产被modify,需要再save一次
		FDialogueEditor::SaveAsset_Execute();

		// 已经成功保存到lua文件里了，清理root object的标脏状态
		if (UObject* RootObj = DialogueAsset->GetOuter())
		{
			RootObj->GetPackage()->ClearDirtyFlag();
		}
			
		GetDialogueEditorManager()->OnClickSaveAsset(DialogueAsset, false);
	}
}

void FDialogueMainEditor::BindCommands()
{
	// 注册指令
	FDialogueEditorCommands::Register();

	const FDialogueEditorCommands& Commands = FDialogueEditorCommands::Get();
	const TSharedRef<FUICommandList>& UICommandsList = GetToolkitCommands();
	FDialogueEditor::BindCommands();
	
	UICommandsList->MapAction(Commands.Generate, FExecuteAction::CreateSP(this, &FDialogueMainEditor::OnClickGenerateDialogue));
	UICommandsList->MapAction(Commands.Import, FExecuteAction::CreateSP(this, &FDialogueMainEditor::ImportDialogue));
	UICommandsList->MapAction(Commands.SyncTemplate, FExecuteAction::CreateSP(this, &FDialogueMainEditor::SyncTemplate));
	UICommandsList->MapAction(Commands.SaveAsTemplate, FExecuteAction::CreateSP(this, &FDialogueMainEditor::SaveAsTemplate));
	UICommandsList->MapAction(Commands.CheckInValidAsset, FExecuteAction::CreateSP(this, &FDialogueMainEditor::CheckInValidAsset));
	UICommandsList->MapAction(Commands.Copy, FExecuteAction::CreateSP(this, &FDialogueMainEditor::CopySelectObject));
	UICommandsList->MapAction(Commands.Paste, FExecuteAction::CreateSP(this, &FDialogueMainEditor::PasteSelectObject));
	UICommandsList->MapAction(Commands.Delete, FExecuteAction::CreateSP(this, &FDialogueMainEditor::DeleteSelectObject));

	UICommandsList->MapAction(Commands.Audio2FaceAutoMatch, FExecuteAction::CreateSP(this, &FDialogueMainEditor::RefreshAudio2FaceMatchAudioDialogue));
	UICommandsList->MapAction(Commands.CreateAutoCuts, FExecuteAction::CreateSP(this, &FDialogueMainEditor::CreateAutoCuts));
}

void FDialogueMainEditor::OnClickGenerateDialogue()
{
	// 正在播放时不允许生成新的
	if (IsPlaying() || IsPaused())
	{
		return;
	}
	if (UDialogueAsset* Asset = Cast<UDialogueAsset>(EditAsset))
	{
		GenerateDialogue();
		GetDialogueEditorManager()->ForceExportLuaTable(Asset);
	}
}

void FDialogueMainEditor::GenerateDialogue()
{
	// 重新生成时，需要把当前选中的清除掉，不然会持有已销毁的Actor引用
	SetTrackSelected(nullptr);
	GEditor->SelectNone(false, true, false);

	SetSectionSelected(nullptr);
	if (UDialogueAsset* Asset = Cast< UDialogueAsset>(EditAsset))
	{
		//这里之所以销毁，是为了防止播放到一半的时候，各个Actors Camera信息都被Track改变的情况
		PreviewScene->DestroyPreviewActors();
		{
			FString ScopeText = TEXT("Dialogue GenerateDialogue");
			FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);

			Asset->Modify();
			for (FDialogueEpisode& DialogueEpisode : Asset->Episodes)
			{
				TArray<UDialogueTrackBase*> EpisodeAllTracks = DialogueEpisode.GetAllTracks();
				for (UDialogueTrackBase* DialogueTrackBase : EpisodeAllTracks)
				{
					if(DialogueTrackBase->IsA(UDialogueSpawnableTrack::StaticClass()))
					{
						DialogueTrackBase->Modify();
					}
				}
			}
			GetDialogueEditorManager()->GenerateDialogue(Asset);
		}
		
		PreviewScene->SpawnPreviewActors();

		GenarateDialogueEvent.Broadcast();
	}
}

void FDialogueMainEditor::ImportDialogue()
{
	// 正在播放时不允许生成新的
	if (IsPlaying() || IsPaused())
	{
		return;
	}
	if (UDialogueAsset* Asset = Cast< UDialogueAsset>(EditAsset))
	{
		bool ExecuteImport = true;
		if (GetDefault<UDialogueEditorSettings>()->ImportEnsureBox)
		{
			if (FMessageDialog::Open(EAppMsgType::YesNo, FText::FromString(TEXT("确定执行Import操作吗"))) != EAppReturnType::Yes)
			{
				ExecuteImport = false;
			}
		}

		if (ExecuteImport)
		{
			FString ScopeText = TEXT("Dialogue ImportDialogue");
			FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);
			Asset->Modify();

			PreviewScene->GetDialogueEditorManager()->ImportDialogue(Asset, false);
			PreviewScene->GetDialogueEditorManager()->GenerateDialogue(Asset);

			if (Asset->GetDialogueEpisodesCount() > 0)
			{
				//触发一次集数选中，以更新Details面板的CurrentSelectEpisode显示
				SetCurrentSelectEpisode(Asset->GetFirstDialogueEpisodeID());
			}
			//import dialogue后，更新Graph显示
			DialogueEventConstructGraph.Broadcast();
			UKGStoryLineEditorSubSystem::BroadcastPostChanged(Asset, EKGSLDataChangeInfo::ImportDialog);
		}
	}
}

void FDialogueMainEditor::ExportDialogue()
{
	if (UDialogueAsset* Asset = Cast< UDialogueAsset>(EditAsset))
	{
		PreviewScene->GetDialogueEditorManager()->ExportDialogue(Asset);
	}
}

void FDialogueMainEditor::ExportOptionText()
{
	if (UDialogueAsset* Asset = Cast< UDialogueAsset>(EditAsset))
	{
		PreviewScene->GetDialogueEditorManager()->ExportOptionText(Asset);
	}
}

void FDialogueMainEditor::SyncTemplate()
{
	// 正在播放时不允许生成新的
	if (IsPlaying() || IsPaused())
	{
		return;
	}
	// 重新生成时，需要把当前选中的清除掉，不然会持有已销毁的Actor引用
	SetTrackSelected(nullptr);
	SetSectionSelected(nullptr);

	GEditor->SelectNone(false, true, false);
	if (UDialogueAsset* Asset = Cast< UDialogueAsset>(EditAsset))
	{
		//这里之所以销毁，是为了防止播放到一半的时候，各个Actors Camera信息都被Track改变的情况
		PreviewScene->DestroyPreviewActors();

		PreviewScene->GetDialogueEditorManager()->SyncTemplate(Asset);

		PreviewScene->SpawnPreviewActors();

		GenarateDialogueEvent.Broadcast();
	}
}

void FDialogueMainEditor::SaveAsTemplate()
{
	// Load necessary modules
	FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");

	FSaveAssetDialogConfig SaveAssetDialogConfig;
	SaveAssetDialogConfig.DefaultAssetName = TEXT("NewTemplate");
	SaveAssetDialogConfig.ExistingAssetPolicy = ESaveAssetDialogExistingAssetPolicy::Disallow;
	FOnObjectPathChosenForSave OnObjectPathChosenForSave;
	FOnAssetDialogCancelled OnAssetDialogCancelled;

	OnObjectPathChosenForSave.BindRaw(this, &FDialogueMainEditor::SaveAsTemplate_Internal);
	ContentBrowserModule.Get().CreateSaveAssetDialog(SaveAssetDialogConfig, OnObjectPathChosenForSave, OnAssetDialogCancelled);

}

void FDialogueMainEditor::SaveAsTemplate_Internal(const FString& Path)
{
	FString Name, PackageName;
	Path.Split(TEXT("."), &PackageName, &Name);

	FAssetToolsModule& AssetToolsModule = FModuleManager::Get().LoadModuleChecked<FAssetToolsModule>("AssetTools");
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
	// Generate a unique asset name
	const FString PackagePath = FPackageName::GetLongPackagePath(PackageName);

	// Create object and package
	UPackage* package = CreatePackage(*PackageName);
	UObject* NewObject = AssetToolsModule.Get().CreateAsset(Name, PackagePath, UDialogueTemplateAsset::StaticClass(), nullptr);

	UDialogueAsset* DialogueAsset = GetDialogueAsset();
	GetDialogueEditorManager()->SaveAsTemplate(DialogueAsset, Cast<UDialogueTemplateAsset>(NewObject));

	FSavePackageArgs SavePackageArgs;
	UPackage::Save(package, NewObject, *FPackageName::LongPackageNameToFilename(PackageName, FPackageName::GetAssetPackageExtension()), SavePackageArgs);

	// Inform asset registry
	AssetRegistry.AssetCreated(NewObject);

	// Tell content browser to show the newly created asset
	TArray<UObject*> Objects;
	Objects.Add(NewObject);

	FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
	ContentBrowserModule.Get().SyncBrowserToAssets(Objects);
}

void FDialogueMainEditor::CopySelectObject()
{
	if(CurrentSelectObject.Num() > 0)
	{
		DialogueTimelineController.Pin()->CopySelectedTrack();
	}
	else if(CurrentSelectSection.Num() > 0)
	{
		// 理论上应该缓存选中的SDialogueEditorActionTrackNode 但是已经缓存了UDialogueActionSection 编辑器就不考虑遍历性能
		for (auto TimelineTrack:DialogueTimelineController.Pin()->GetAllTracks())
		{
			if(FDialogueEditorTrack* EditorTrack = StaticCast<FDialogueEditorTrack*>( &(TimelineTrack.Get())))
			{
				if(FDialogueTrackEditor* TrackEditor = StaticCast<FDialogueTrackEditor*>( EditorTrack->GetTrackEditor().Get()))
				{
					//  StaticCast 不能准确判断轨道是否为FDialogueActionTrackEditor 这里额外加上判断条件
					if(UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(TrackEditor->GetCacheTrack()))
						continue;
					EDialogueTrack::Type TrackType = TrackEditor->GetCacheTrack()->GetType();
					if(TrackType == EDialogueTrack::Type::Camera || TrackType == EDialogueTrack::Type::Actor ||
					TrackType ==  EDialogueTrack::Type::RoutePoint)
						continue;
					if(FDialogueActionTrackEditor* ActionTrackEditor =  StaticCast<FDialogueActionTrackEditor*>(TrackEditor))
					{
						for (TSharedPtr<SDialogueEditorActionTrackNode> SectionAction : ActionTrackEditor->GetTrackWidget()->GetActionNodes())
						{
							if(CurrentSelectSection.Contains(SectionAction->GetActionNodeData().GetAction()))
							{
								ActionTrackEditor->OnCopySection(SectionAction);
							}
						}
					}
				}
			}
		}
	}
}

void FDialogueMainEditor::PasteSelectObject()
{
	FString ScopeText = FString::Printf(TEXT("Dialogue AddSection, PasteSelectObject"));
	FScopedTransaction Transaction(FText::FromString(ScopeText));
	if(CurrentSelectObject.Num() > 0)
	{
		DialogueTimelineController.Pin()->PasteCopyTrack();
	}
	else if(CurrentSelectSection.Num() > 0)
	{
		// 理论上应该缓存选中的SDialogueEditorActionTrackNode 但是已经缓存了UDialogueActionSection 编辑器就不考虑遍历性能
		for (auto TimelineTrack:DialogueTimelineController.Pin()->GetAllTracks())
		{
			if(FDialogueEditorTrack* EditorTrack = StaticCast<FDialogueEditorTrack*>( &(TimelineTrack.Get())))
			{
				if(FDialogueTrackEditor* TrackEditor = StaticCast<FDialogueTrackEditor*>( EditorTrack->GetTrackEditor().Get()))
				{
					//  StaticCast 不能准确判断轨道是否为FDialogueActionTrackEditor 这里额外加上判断条件
					if(UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(TrackEditor->GetCacheTrack()))
						continue;
					EDialogueTrack::Type TrackType = TrackEditor->GetCacheTrack()->GetType();
					if(TrackType == EDialogueTrack::Type::Camera || TrackType == EDialogueTrack::Type::Actor ||
					TrackType ==  EDialogueTrack::Type::RoutePoint)
						continue;
					if(FDialogueActionTrackEditor* ActionTrackEditor =  StaticCast<FDialogueActionTrackEditor*>(TrackEditor))
					{
						bool NeedPaste = false;
						for (TSharedPtr<SDialogueEditorActionTrackNode> SectionAction : ActionTrackEditor->GetTrackWidget()->GetActionNodes())
						{
							NeedPaste = true;
							break;
						}
						if(NeedPaste)
							ActionTrackEditor->OnPasteSection();
					}	
				}
			}
		}
	}
}

void FDialogueMainEditor::DeleteSelectObject()
{
	FString ScopeText = FString::Printf(TEXT("Dialogue RemoveSection, CurrentSelectObjects"));
	FScopedTransaction Transaction(FText::FromString(ScopeText), GetDefault<UDialogueEditorSettings>()->EnableDialogueUndoRedo);
	if(CurrentSelectObject.Num() > 0)
	{
		TArray<TSharedRef<class FAnimTimelineTrack>> AllTracks = DialogueTimelineController.Pin()->GetAllTracks();
		for(int i=0;i<AllTracks.Num();i++)
		{
			if(CurrentSelectObject.Contains(AllTracks[i].Get().GetCachedTrack()))
			{
				DialogueTimelineController.Pin()->RemoveTrack(Cast<UDialogueTrackBase>(AllTracks[i]->GetCachedTrack()));
			}
		}
	}
	else if(CurrentSelectSection.Num() > 0)
	{
		// 理论上应该缓存选中的SDialogueEditorActionTrackNode 但是已经缓存了UDialogueActionSection 编辑器就不考虑遍历性能
		for (auto TimelineTrack:DialogueTimelineController.Pin()->GetAllTracks())
		{
			if(FDialogueEditorTrack* EditorTrack = StaticCast<FDialogueEditorTrack*>( &(TimelineTrack.Get())))
	            {
            		if(FDialogueTrackEditor* TrackEditor = StaticCast<FDialogueTrackEditor*>( EditorTrack->GetTrackEditor().Get()))
            		{
            			//  StaticCast 不能准确判断轨道是否为FDialogueActionTrackEditor 这里额外加上判断条件
            			if(UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(TrackEditor->GetCacheTrack()))
            				continue;
            			EDialogueTrack::Type TrackType = TrackEditor->GetCacheTrack()->GetType();
            			if(TrackType == EDialogueTrack::Type::Camera || TrackType == EDialogueTrack::Type::Actor ||
            			TrackType ==  EDialogueTrack::Type::RoutePoint)
            				continue;
            			if(FDialogueActionTrackEditor* ActionTrackEditor =  StaticCast<FDialogueActionTrackEditor*>(TrackEditor))
            			{
            				for (TSharedPtr<SDialogueEditorActionTrackNode> SectionAction : ActionTrackEditor->GetTrackWidget()->GetActionNodes())
            				{
            					if(CurrentSelectSection.Contains(SectionAction->GetActionNodeData().GetAction()))
            					{
            						ActionTrackEditor->RemoveSelectedSection(SectionAction.ToSharedRef(), false);
            					}
   
            				}
            			}
            		}
	            }
		}
		DialogueTimelineController.Pin()->RefreshTracks();
	}
}

void FDialogueMainEditor::MoveSelectSection(bool IsLeft)
{
	float DeltaTime = 0.1;
	for (auto TimelineTrack: DialogueTimelineController.Pin()->GetAllTracks())
	{
		// 理论上应该缓存选中的SDialogueEditorActionTrackNode 但是已经缓存了UDialogueActionSection 编辑器就不考虑遍历性能
		if(FDialogueEditorTrack* EditorTrack = StaticCast<FDialogueEditorTrack*>( &(TimelineTrack.Get())))
		{
			if(FDialogueTrackEditor* TrackEditor = StaticCast<FDialogueTrackEditor*>( EditorTrack->GetTrackEditor().Get()))
			{
				//  StaticCast 不能准确判断轨道是否为FDialogueActionTrackEditor 这里额外加上判断条件
				if(UDialogueSpawnableTrack* SpawnableTrack = Cast<UDialogueSpawnableTrack>(TrackEditor->GetCacheTrack()))
					continue;
				EDialogueTrack::Type TrackType = TrackEditor->GetCacheTrack()->GetType();
				if(TrackType == EDialogueTrack::Type::Camera || TrackType == EDialogueTrack::Type::Actor ||
				TrackType ==  EDialogueTrack::Type::RoutePoint)
					continue;
				if(FDialogueActionTrackEditor* ActionTrackEditor =  StaticCast<FDialogueActionTrackEditor*>(TrackEditor))
				{
					for (TSharedPtr<SDialogueEditorActionTrackNode> SectionAction : ActionTrackEditor->GetTrackWidget()->GetActionNodes())
					{
						if(CurrentSelectSection.Contains(SectionAction->GetActionNodeData().GetAction()))
						{
							UDialogueActionBase* ActionSection = SectionAction.Get()->GetActionNodeData().GetAction();
							float NewStartTime = IsLeft?ActionSection->GetStartTime() - DeltaTime:ActionSection->GetStartTime()+DeltaTime;
							ActionSection->SetStartTime(NewStartTime);
						}
   
					}
				}
			}
		}
	}
}


void FDialogueMainEditor::CheckInValidAsset()
{
	//暂借这个函数执行转换功能
	//1 获取所有的对话资产
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName).Get();
	TArray<FAssetData> Assets;
	AssetRegistry.GetAssetsByClass(UDialogueAsset::StaticClass()->GetClassPathName(), Assets, /*bSearchSubClasses=*/true);

	for (const FAssetData& AssetData : Assets)
	{
		if (AssetData.GetAsset())
		{
			if (UDialogueAsset* DialogueAsset = Cast<UDialogueAsset>(AssetData.GetAsset()))
			{
				PreviewScene->GetDialogueEditorManager()->CheckInValidAsset(DialogueAsset);
			}
		}
	}
}

void FDialogueMainEditor::OnDialogueAssetTemplateChanged()
{
	if (UDialogueAsset* Asset = Cast< UDialogueAsset>(EditAsset))
	{
		//改变模板后，重置选中的entity
		ClickCameraEntity = nullptr;

		PreviewScene->GetDialogueEditorManager()->RefreshOnChangeTemplate(Asset);
		GenarateDialogueEvent.Broadcast();
	}
}

void FDialogueMainEditor::OnCustomSelectorChanged(FString InTrackName)
{
	FDialogueEpisode* Episode = EditAsset->GetEpisodePointerByIndex(0);

	TMap<FString, UDialogueCameraTrack*> Cameras = Episode->GetTrackCameras();

	TMap<FString, UDialogueActorTrack*> Actors = Episode->GetTrackActors();

	if (Cameras.Find(InTrackName))
	{
		UDialogueCameraTrack* TrackCamera = *(Cameras.Find(InTrackName));
		SetTrackSelected(TrackCamera,false);
	}
	else if (Actors.Find(InTrackName))
	{
		UDialogueActorTrack* TrackActor = *(Actors.Find(InTrackName));
		SetTrackSelected(TrackActor,false);
	}
}

void FDialogueMainEditor::OnAssetEpisodeLinesCountChange()
{
	GenerateDialogue();
}

void FDialogueMainEditor::OnDefaultInitExcelData()
{
	UDialogueAsset* Asset = GetDialogueAsset();
	if (!Asset)
	{
		return;
	}
	
	if(Asset->DialogueTemplate == NULL)
	{
		FString TemplateName = GetPreviewProxy()->GetDialogueEditorManager()->GetDialogueInitialTemplateName(Asset->GetName());
		if(TemplateName == "")
			return;
		Asset->UseTemplateCamera = false;
		FString AssetPath = "/Game/Blueprint/DialogueSystem/Template/" + TemplateName;
		
		UDialogueTemplateAsset* DialogueTemplate = LoadObject<UDialogueTemplateAsset>(nullptr, *AssetPath);
		if (DialogueTemplate)
		{
			Asset->DialogueTemplate = DialogueTemplate;
		}
	}

	UKGSLDialogueEpisode* FirstEpisode = Asset->EpisodesList.IsValidIndex(0) ? Asset->EpisodesList[0] : nullptr;
	if (FirstEpisode && !FirstEpisode->DialogueLines.IsEmpty())
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("这个对话资产已经初始化过了,无法再次初始化.")));
		return;
	}
	
	SyncTemplate();
	GenerateDialogue();
}

void FDialogueMainEditor::AddEpisode()
{
	if(UDialogueAsset* Asset = Cast<UDialogueAsset>(GetEditingAsset()))
	{
		if(UKGSLDialogueEpisode* Episode = UKGStoryLineEditorSubSystem::AddEpisode(Asset))
		{
			SetCurrentSelectEpisode(Episode->GetEpisodeID());
		}
	}
}

#pragma optimize("",on)

#pragma endregion Main

#undef LOCTEXT_NAMESPACE

