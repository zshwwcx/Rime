#include "DialogueEditor/Modes/DialogueEditorMode.h"

#include "DialogueEditor/DialogueEditor.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/DialogueEditorSettings.h"



FDialogueEditorMode::FDialogueEditorMode(const FName& InModeName, TSharedRef<FDialogueEditor> InEditor): FApplicationMode(InModeName), CachedEditor(InEditor)
{
	
}

void FDialogueEditorMode::RegisterTabFactories(TSharedPtr<FTabManager> InTabManager)
{
	TSharedPtr<FWorkflowCentricApplication> HostingApp = CachedEditor.Pin();
	HostingApp->RegisterTabSpawners(InTabManager.ToSharedRef());
	HostingApp->PushTabFactories(TabFactories);

	FApplicationMode::RegisterTabFactories(InTabManager);
}

void FDialogueEditorMode::AddTabFactory(FCreateWorkflowTabFactory FactoryCreator)
{
	if (FactoryCreator.IsBound())
	{
		TabFactories.RegisterFactory(FactoryCreator.Execute(CachedEditor.Pin()));
	}
}

void FDialogueEditorMode::RemoveTabFactory(FName TabFactoryID)
{
	TabFactories.UnregisterFactory(TabFactoryID);
}


FDialogueEditorMode_Template::FDialogueEditorMode_Template(TSharedRef<FDialogueEditor> InEditor) : FDialogueEditorMode(DialogueEditorModes::Main, InEditor)
{
	UDialogueEditorSettings* DialogueEditorSettings = GetMutableDefault<UDialogueEditorSettings>();
	auto MiddleSplitter = FTabManager::NewSplitter()
		->SetSizeCoefficient(1.f)
		->SetOrientation(Orient_Vertical);

	auto RightSplitter = FTabManager::NewSplitter()
		->SetSizeCoefficient(0.2f)
		->SetOrientation(Orient_Vertical)
		->Split
		(
			FTabManager::NewStack()
			->SetSizeCoefficient(0.6f)
			->SetHideTabWell(false)
			->AddTab(DialogueEditorEditorTabs::Details, ETabState::OpenedTab)
		);

	
	MiddleSplitter
			->Split
			(
				FTabManager::NewStack()
				->SetSizeCoefficient(1.0f)
				->SetHideTabWell(true)
				->AddTab(DialogueEditorEditorTabs::AssetEdit, ETabState::OpenedTab)
			);

	// 创建Mode所需的Tabs
	CreateModeTabs(CachedEditor.Pin().ToSharedRef(), TabFactories);
	// 基础布局
	TabLayout = FTabManager::NewLayout("DialogueEditor_TemplateLayout_1.3")
		->AddArea
		(
			FTabManager::NewPrimaryArea()
			->SetOrientation(Orient_Vertical)
			->Split
			(
				FTabManager::NewSplitter()
				->SetSizeCoefficient(1.f)
				->SetOrientation(Orient_Horizontal)
				// 中
				->Split
				(
					MiddleSplitter
				)

				// 右
				->Split
				(
					RightSplitter
				)
			)
		);
}


FDialogueEditorMode_Main::FDialogueEditorMode_Main(TSharedRef<FDialogueEditor> InEditor) : FDialogueEditorMode(DialogueEditorModes::Main, InEditor)
{
	UDialogueEditorSettings* DialogueEditorSettings = GetMutableDefault<UDialogueEditorSettings>();
	auto MiddleSplitter = FTabManager::NewSplitter()
	->SetSizeCoefficient(1.f)
	->SetOrientation(Orient_Vertical);

	auto RightSplitter = FTabManager::NewSplitter()
		->SetSizeCoefficient(0.2f)
		->SetOrientation(Orient_Vertical)
		->Split
		(
			FTabManager::NewStack()
			->SetSizeCoefficient(0.6f)
			->SetHideTabWell(false)
			->AddTab(DialogueEditorEditorTabs::Details, ETabState::OpenedTab)
		)
		->Split
		(
			FTabManager::NewStack()
			->SetSizeCoefficient(0.4f)
			->SetHideTabWell(false)
			->AddTab(DialogueEditorEditorTabs::AssetGraph, ETabState::OpenedTab)
		);

	
	MiddleSplitter
			->Split
			(
				FTabManager::NewStack()
				->SetSizeCoefficient(1.0f)
				->SetHideTabWell(true)
				->AddTab(DialogueEditorEditorTabs::AssetEdit, ETabState::OpenedTab)
			);
	RightSplitter
		->Split
		(
			FTabManager::NewStack()
			->SetSizeCoefficient(0.01f)
			->SetHideTabWell(true)
			->AddTab(DialogueEditorEditorTabs::OptionGraph, ETabState::OpenedTab)
		);

	// 创建Mode所需的Tabs
	CreateModeTabs(CachedEditor.Pin().ToSharedRef(), TabFactories);

	// 基础布局
	TabLayout = FTabManager::NewLayout("DialogueEditor_MainLayout1.3")
		->AddArea
		(
			FTabManager::NewPrimaryArea()
			->SetOrientation(Orient_Vertical)
			->Split
			(
				FTabManager::NewSplitter()
				->SetSizeCoefficient(1.f)
				->SetOrientation(Orient_Horizontal)
				// 左
				->Split
				(
					FTabManager::NewStack()
					->SetSizeCoefficient(0.2f)
					->SetHideTabWell(false)
					->AddTab(DialogueEditorEditorTabs::AssetDetails, ETabState::OpenedTab)
					->AddTab(DialogueEditorEditorTabs::AssetOperationPanel, ETabState::OpenedTab)
				)

				// 中
				->Split
				(
					MiddleSplitter
				)

				// 右
				->Split
				(
					RightSplitter
				)
			)
		);
}
