#include "KGStoryLineEditorModule.h"
#include "CutScene/AnimMontageTrackEditor.h"
#include "AssetToolsModule.h"
#include "3C/Character/BaseCharacter.h"
#include "Core.h"
#include "CutScene/CutsceneCustomObjectBinding.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"
#include "DialogueEditor/DialogueEditorAssetTypeActions.h"
#include "Editor.h"
#include "ILevelSequenceEditorToolkit.h"
#include "ISequencerModule.h"
#include "DialogueEditor/CustomLayout/KGSLEdCustomLayoutDialogueEpisode.h"
#include "DialogueEditor/CustomLayout/KGSLEdCustomLayoutDialogueLine.h"
#include "DialogueEditor/CustomLayout/KGSLEdCustomLayoutDialogueSection.h"
#include "DialogueEditor/CustomLayout/KGSLEdDialogueAnimationLayout.h"
#include "LevelSequence.h"
#include "CutScene/LookAtPropertyTrackEditor.h"
#include "PropertyEditorModule.h"
#include "DialogueEditor/CustomLayout/KGSLIconPathLayout.h"
#include "CutScene/MovieSceneAudio2FaceTrackEditor.h"
#include "CutScene/ResizeBoundsTrackEditor.h"
#include "Framework/Application/SlateApplication.h"
#include "Modules/ModuleManager.h"

#include "EngineUtils.h"
#include "ISourceControlModule.h"
#include "SourceControlHelpers.h"
#include "SourceControlOperations.h"
#include "Engine/AssetManager.h"
#include "KGSLEditorStyle.h"
#include "DialogueEditor/DialogueAssetBrowser.h"
#include "DialogueEditor/CustomLayout/DialogueCustomLayoutApperanceSelector.h"
#include "DialogueEditor/CustomLayout/DialogueCustomLayoutBehaviorSelector.h"
#include "DialogueEditor/CustomLayout/DialogueCustomLayoutCameraSelector.h"
#include "DialogueEditor/CustomLayout/DialogueCustomLayoutDialogueShotAction.h"
#include "DialogueEditor/CustomLayout/DialogueCustomLayoutPerformerSelector.h"
#include "DialogueEditor/DialogueEditorSettings.h"
#include "CutScene/MovieSceneBatchMaterialTrackEditor.h"
#include "CutScene/MovieSceneCustomSection.h"
#include "CutScene/MovieSceneHeightOffsetTrackEditor.h"
#include "DialogueEditor/TabFactory/SDialogueEditorAssetBrowserTab.h"
#include "StoryLineAssetTypeActions.h"
#include "CutScene/Utils/AnimSeqRootFixTool.h"
#include "CutScene/FullScreenMediaTrackEditor.h"
#include "CutScene/MovieSceneGazeTrackEditor.h"
#include "DialogueEditor/Dialogue/Actions/DialogueShotAction.h"
#include "ToolMenus.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "CutScene/CustomSectionEditors/CustomSectionDataDetail.h"

#define LOCTEXT_NAMESPACE "FKGStoryLineEditorModule"

#define REG_KGSL_CUSTOM_OBJ_PROP_LAYOUT(ObjType, CustomLayout) \
PropertyModule.RegisterCustomPropertyTypeLayout(ObjType::StaticClass()->GetFName(), \
	FOnGetPropertyTypeCustomizationInstance::CreateStatic(&CustomLayout::MakeInstance));

#define REG_KGSL_CUSTOM_PROP_LAYOUT(StructType, CustomLayout) \
PropertyModule.RegisterCustomPropertyTypeLayout(StructType::StaticStruct()->GetFName(), \
	FOnGetPropertyTypeCustomizationInstance::CreateStatic(&CustomLayout::MakeInstance));

#define REG_KGSL_CUSTOM_CLASS_LAYOUT(ClassType, CustomLayout) \
PropertyModule.RegisterCustomClassLayout(ClassType::StaticClass()->GetFName(), \
	FOnGetDetailCustomizationInstance::CreateStatic(&CustomLayout::MakeInstance));

#define REG_KGSL_CUSTOM_STRUCT_LAYOUT(StructType, CustomLayout) \
PropertyModule.RegisterCustomClassLayout(StructType::StaticStruct()->GetFName(), \
	FOnGetDetailCustomizationInstance::CreateStatic(&CustomLayout::MakeInstance));

DEFINE_LOG_CATEGORY(LogKGStoryLineEditor);

void FKGStoryLineEditorModule::OnSequencerCreated(TSharedRef<ISequencer> Sequencer)
{
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(Sequencer->GetRootMovieSceneSequence());
	if (!LevelSequence)
		return;
	
	FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
	KGStoryLineEditorModule.CutSceneEditorPtr.Reset();
	KGStoryLineEditorModule.CutSceneEditorPtr = MakeShareable(new FCutSceneEditor());
	KGStoryLineEditorModule.CutSceneEditorPtr->InitLuaEnvironment();
	KGStoryLineEditorModule.CutSceneEditorPtr->InitPostProcessPreview();
	KGStoryLineEditorModule.IsAssetOpening = true;
	
	check(KGStoryLineEditorModule.CutSceneEditorPtr);
	KGStoryLineEditorModule.CutSceneEditorPtr->InitializeRoleComposite(Sequencer, LevelSequence);
	KGStoryLineEditorModule.CutSceneEditorPtr->OnModifiedIndirectly(nullptr);
	KGStoryLineEditorModule.IsAssetOpening = false;
}

void FKGStoryLineEditorModule::OnAssetOpened(UObject* Object) //, IAssetEditorInstance* Instance
{
	//UE_LOG(LogTemp, Warning, TEXT("FKGStoryLineEditorModule::OnAssetOpened Object:%s"), *(Object->GetName())); //*Instance->GetEditorName().ToString()
	if (ULevelSequence* LevelSequence = Cast<ULevelSequence>(Object))
	{
		//UE_LOG(LogTemp, Warning, TEXT("Level Sequence opened: %s"), *LevelSequence->GetName());
		FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
		IAssetEditorInstance* AssetEditor = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(LevelSequence, false);
		ILevelSequenceEditorToolkit* LevelSequenceEditor = static_cast<ILevelSequenceEditorToolkit*>(AssetEditor);
		TSharedPtr<ISequencer> Sequencer = LevelSequenceEditor ? LevelSequenceEditor->GetSequencer() : nullptr;
		
		static IConsoleVariable* const CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.Shadow.Virtual.DistantLightMode"));
		if(CVar)
		{
			KGStoryLineEditorModule.SavedDistantLightMode = CVar->GetInt();
			CVar->Set(0);
		}
		
		FSlateApplication& WindowManager = FSlateApplication::Get();
		TArray<TSharedRef<SWindow>> AllWindows;
		WindowManager.GetAllVisibleWindowsOrdered(AllWindows);
		bool found = false;
		for (TSharedRef<SWindow> Window : AllWindows)
		{
			//UE_LOG(LogTemp, Warning, TEXT("FKGStoryLineEditorModule OnAssetOpened: %s"), *Window->GetTitle().ToString());
			if (Window->IsVisible() && Window->GetTitle().ToString() == FString(TEXT("Sequencer")))
			{
				found = true;
				Window->GetOnWindowClosedEvent().AddRaw(&KGStoryLineEditorModule, &FKGStoryLineEditorModule::OnWindowClosedEvent);
				break;
			}
		}
		if (!found)
		{
			if (!Sequencer)
			{
				UE_LOG(LogTemp, Warning, TEXT("no Sequencer for asset %s"), *(Object->GetName()));
			}
			else
			{
				Sequencer->OnCloseEvent().AddLambda([](TSharedRef<ISequencer>)
				{
					FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
					if (!KGStoryLineEditorModule.IsAssetOpening)
					{
						KGStoryLineEditorModule.CutSceneEditorPtr.Reset();
					}
				});
			}
		}
	}
}

void FKGStoryLineEditorModule::OnWindowClosedEvent(const TSharedRef<SWindow>& Window)
{
	//UE_LOG(LogTemp, Warning, TEXT("FKGStoryLineEditorModule OnWindowClosedEvent: %s"), *Window->GetTitle().ToString());
	if (!IsAssetOpening)
	{
		CutSceneEditorPtr.Reset();		
	}

	IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.Shadow.Virtual.DistantLightMode"));
	if(CVar)
	{
		CVar->Set(SavedDistantLightMode);
	}
}

void FKGStoryLineEditorModule::OnMapBeginLoad(const FString& Filename, FCanLoadMap& CanLoad)
{
	UE_LOG(LogKGStoryLineEditor, Log, TEXT("OnMapBeginLoad: %s"), *Filename);
	FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
	KGStoryLineEditorModule.CutSceneEditorPtr.Reset();
}

void FKGStoryLineEditorModule::RegisterEditorToolMenu()
{
	if (IsRunningCommandlet())
	{
		return;	
	}

	// 注册Menu
	FToolMenuOwnerScoped OwnerScoped(this);
	{
		if (UToolMenu* ToolMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.C7_Editor"))
		{
			FToolMenuSection& Section = ToolMenu->FindOrAddSection("C7EditorWindowLayout");
			const FToolMenuEntry& DialogueAssetBrowserEntry = FToolMenuEntry::InitMenuEntry(
						FName("DialogueAssetBrowser"),
					LOCTEXT("DialogueAssetBrowser", "剧情编辑器"),
					FText::GetEmpty(),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateRaw(this, &FKGStoryLineEditorModule::OpenAssetBrowserTab))
					);
			Section.AddEntry(DialogueAssetBrowserEntry);
		}
	}

	FCutSceneEditor::ExtendMenu();
}

void FKGStoryLineEditorModule::OpenAssetBrowserTab()
{
	if (!DialogueAssetBrowser.IsValid())
	{
		DialogueAssetBrowser = MakeShareable(new FDialogueAssetBrowser()); 
	}

	DialogueAssetBrowser->OpenDialogueAssetBrowser();
}

TWeakObjectPtr<UObject> FKGStoryLineEditorModule::GetDialogueRootPackage()
{
	if (!DialogueAssetBrowser.IsValid())
	{
		DialogueAssetBrowser = MakeShareable(new FDialogueAssetBrowser()); 
	}
	if (DialogueAssetBrowser.IsValid())
	{
		return DialogueAssetBrowser->GetDialogueRootPackage();
	}
	return nullptr;
}

TSharedPtr<FCutSceneEditor> FKGStoryLineEditorModule::GetCutsceneEditor()
{
	return CutSceneEditorPtr;
}

void FKGStoryLineEditorModule::OnDeleteActorMessage(UObject* Object, FString& Message)
{
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(Object);
	if(LevelSequence == nullptr) return;
	//FString Path = Object->GetPathName();
	//Message += FString::Printf(TEXT("(Soft) Object %s\n"), *Path);

	const UPackage* Package = LevelSequence->GetPackage();

	if (Package == nullptr)
	{
		return;
	}

	const FString LocalFullPath(Package->GetLoadedPath().GetLocalFullPath());

	if (LocalFullPath.IsEmpty())
	{
		return;
	}

	TArray<FString> PackageFullpaths;
	PackageFullpaths.Add(FPaths::ConvertRelativePathToFull(LocalFullPath));
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	// Query for the file history for the provided packages
	TArray<FString> PackageFilenames = SourceControlHelpers::PackageFilenames(PackageFullpaths);
	TSharedRef<FUpdateStatus, ESPMode::ThreadSafe> UpdateStatusOperation = ISourceControlOperation::Create<FUpdateStatus>();
	UpdateStatusOperation->SetUpdateHistory(true);
	if (SourceControlProvider.Execute(UpdateStatusOperation, PackageFilenames))
	{
		TArray< FSourceControlStateRef > SourceControlStates;
		for (const FString& PackageFilename : PackageFilenames)
		{
			TArray<FString> RevisionName;
			RevisionName.Add(PackageFilename);

			while (RevisionName.Num() != 0)
			{
				int32 InitialNum = SourceControlStates.Num();
				SourceControlProvider.GetState(RevisionName, SourceControlStates, EStateCacheUsage::Use);
				int32 NewNum = SourceControlStates.Num();
				ensure(NewNum >= InitialNum);

				RevisionName.Empty();
				// check to see if origin of this file is a branch, append the history from the branch point:
				if (NewNum > InitialNum)
				{
					int32 HistorySize = SourceControlStates.Last()->GetHistorySize();
					if (HistorySize > 0)
					{
						TSharedPtr<class ISourceControlRevision, ESPMode::ThreadSafe> LastHistory = SourceControlStates.Last()->GetHistoryItem(0);
						TSharedPtr<ISourceControlRevision, ESPMode::ThreadSafe> BranchSource = LastHistory->GetBranchSource();
						if (BranchSource.IsValid())
						{
							const FString& BranchFileName = BranchSource->GetFilename();
							TArray<FString> BranchFullpaths;
							BranchFullpaths.Add(BranchFileName);
							TArray<FString> BranchPackageFilenames = SourceControlHelpers::PackageFilenames(BranchFullpaths);
							TSharedRef<FUpdateStatus, ESPMode::ThreadSafe> UpdateBranchStatusOperation = ISourceControlOperation::Create<FUpdateStatus>();
							UpdateBranchStatusOperation->SetUpdateHistory(true);
							if (SourceControlProvider.Execute(UpdateBranchStatusOperation, BranchPackageFilenames))
							{
								RevisionName.Add(BranchFileName);
							}
						}
					}
				}
			}
		}
		if (SourceControlStates.Num() > 0)
		{
			FSourceControlStateRef SourceControlState = SourceControlStates.Last();
			// Add each file revision
			if (SourceControlState->GetHistorySize() > 0)
			{
				TSharedPtr<ISourceControlRevision, ESPMode::ThreadSafe> Revision = SourceControlState->GetHistoryItem(0);
				check(Revision.IsValid());
				const FString& UserName = Revision->GetUserName();
				Message += FString::Printf(TEXT("请联系Sequence的最近一次修改人 %s\n"), *UserName);
			}
		}
	}
}

void FKGStoryLineEditorModule::StartupModule()
{
	RegisterEditorToolMenu();
	RegisterEditorObjectBindings();
	
	FCutSceneEditor::InitializeRenderPipeline();
	FKGSLEditorStyle::Initialize();
	ISequencerModule& SequencerModule = FModuleManager::LoadModuleChecked<ISequencerModule>(TEXT("Sequencer"));
	AnimMontageSequenceHandle = SequencerModule.RegisterTrackEditor(FOnCreateTrackEditor::CreateStatic(&FAnimMontageTrackEditor::CreateTrackEditor));
	LookAtPropertyTrackCreateEditorHandle = SequencerModule.RegisterPropertyTrackEditor<FLookAtPropertyTrackEditor>();
	ResizeBoundsTrackEditorHandle = SequencerModule.RegisterTrackEditor(FOnCreateTrackEditor::CreateStatic(&FResizeBoundsTrackEditor::CreateTrackEditor));
	Audio2FaceTrackEditorHandle = SequencerModule.RegisterTrackEditor(FOnCreateTrackEditor::CreateStatic(&FMovieSceneAudio2FaceTrackEditor::CreateTrackEditor));
	FMovieSceneBatchMaterialTrackEditorHandle = SequencerModule.RegisterTrackEditor(FOnCreateTrackEditor::CreateStatic(&FMovieSceneBatchMaterialTrackEditor::CreateTrackEditor));
	FullScreenMediaTrackEditorHandle = SequencerModule.RegisterPropertyTrackEditor<FFullScreenMediaTrackEditor>();
	GazeTrackEditorHandle = SequencerModule.RegisterTrackEditor(FOnCreateTrackEditor::CreateStatic(&FMovieSceneGazeTrackEditor::CreateTrackEditor));
	HeightOffsetTrackEditorHandle = SequencerModule.RegisterTrackEditor(FOnCreateTrackEditor::CreateStatic(&FMovieSceneHeightOffsetTrackEditor::CreateTrackEditor));
	SequenceCreatedHandle = SequencerModule.RegisterOnSequencerCreated(FOnSequencerCreated::FDelegate::CreateStatic(&FKGStoryLineEditorModule::OnSequencerCreated));

	ILevelSequenceModule& LevelSequenceModule = FModuleManager::LoadModuleChecked<ILevelSequenceModule>("LevelSequence");
	DefaultTrackHandle = LevelSequenceModule.OnNewActorTrackAdded().AddStatic(&FKGStoryLineEditorModule::AddDefaultSystemTracks);
	if (GEditor)
	{
		AssetOpenedHandle = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OnAssetEditorOpened().AddStatic(&FKGStoryLineEditorModule::OnAssetOpened);
		FEditorDelegates::OnMapLoad.AddRaw(this, &FKGStoryLineEditorModule::OnMapBeginLoad);
		FEditorDelegates::OnDeleteActorMessage.AddRaw(this, &FKGStoryLineEditorModule::OnDeleteActorMessage);
	}
	
	// Add custom property layout
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	REG_KGSL_CUSTOM_CLASS_LAYOUT(UDialogueDialogue, FKGSLEdCustomLayoutDialogueSection);
	REG_KGSL_CUSTOM_CLASS_LAYOUT(UKGSLDialogueLine, FKGSLEdCustomLayoutDialogueLine);
	REG_KGSL_CUSTOM_OBJ_PROP_LAYOUT(UKGSLDialogueLine, FKGSLEdDialogueLineLayout);
	REG_KGSL_CUSTOM_OBJ_PROP_LAYOUT(UKGSLDialogueEpisode, FKGSLEdDialogueEpisodeDetails);
	REG_KGSL_CUSTOM_PROP_LAYOUT(FDialoguePerformerSelector, FDialoguePerformerSelectorLayout);
	REG_KGSL_CUSTOM_PROP_LAYOUT(FDialogueCameraSelector, FDialogueCameraSelectorLayout);
	REG_KGSL_CUSTOM_PROP_LAYOUT(FDialogueAppearanceSelector, FDialogueAppearanceSelectorLayout);
	REG_KGSL_CUSTOM_PROP_LAYOUT(FBehaviorActorSelector, FDialogueBehaviorSelectorLayout);
	REG_KGSL_CUSTOM_PROP_LAYOUT(FDialogueAnimations, FKGSLEdDialogueAnimationLayout);
	REG_KGSL_CUSTOM_PROP_LAYOUT(FIconPath, FKGSLIconPathLayout);
	REG_KGSL_CUSTOM_CLASS_LAYOUT(UDialogueShotAction, FDialogueCustomLayoutDialogueShotAction);
	REG_KGSL_CUSTOM_CLASS_LAYOUT(UMovieSceneCustomData, FCustomSectionDataDetail);
	

	// Register asset type actions
	IAssetTools& AssetToolsModule = FAssetToolsModule::GetModule().Get();
	EAssetTypeCategories::Type CurrentAssetCategory = EAssetTypeCategories::Type::Gameplay;
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_DialogueTemplateAsset(CurrentAssetCategory)));
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FAssetTypeActions_DialogueAsset(CurrentAssetCategory)));
	AssetToolsModule.RegisterAssetTypeActions(MakeShareable(new FStoryLineAssetDefinitionWrapper(ULevelSequence::StaticClass())));

	FToolMenuOwnerScoped OwnerScoped(this);
	if (!IsRunningCommandlet())
	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.C7_Editor");

		{
			FToolMenuSection& Section = Menu->AddSection("Art", FText::FromString(TEXT("美术/TA 工具")));
			const FToolMenuEntry& Entry2 = FToolMenuEntry::InitMenuEntry(
				FName("AnimSeqRootFix"),
				LOCTEXT("AnimSeqRootFix", "Sequence位移调整"),
				FText::GetEmpty(),
				FSlateIcon(),
				FUIAction(FExecuteAction::CreateStatic(&UAnimSeqRootFixTool::OpenPanel))
			);
			Section.AddEntry(Entry2);
		}

		{
			FToolMenuSection& Section = Menu->FindOrAddSection("WindowLayout");
			const FToolMenuEntry& Entry3 = FToolMenuEntry::InitMenuEntry(
				FName("CheckSequenceData"),
				LOCTEXT("CheckSequenceData", "检查所有Sequence数据中引用的FacadeID"),
				FText::GetEmpty(),
				FSlateIcon(),
				FUIAction(FExecuteAction::CreateStatic(&FKGStoryLineEditorModule::CheckSequenceData))
			);
			Section.AddEntry(Entry3);
		}
	}
}

void FKGStoryLineEditorModule::ShutdownModule()
{
	UnregisterEditorObjectBindings();
	ISequencerModule* SequencerModule = FModuleManager::GetModulePtr<ISequencerModule>("Sequencer");
	if (SequencerModule != nullptr)
	{
		SequencerModule->UnregisterSequenceEditor(AnimMontageSequenceHandle);
		SequencerModule->UnRegisterTrackEditor(LookAtPropertyTrackCreateEditorHandle);
		SequencerModule->UnRegisterTrackEditor(ResizeBoundsTrackEditorHandle);

		SequencerModule->UnRegisterTrackEditor(Audio2FaceTrackEditorHandle);
		SequencerModule->UnRegisterTrackEditor(FullScreenMediaTrackEditorHandle);
		SequencerModule->UnRegisterTrackEditor(FMovieSceneBatchMaterialTrackEditorHandle);
		SequencerModule->UnRegisterTrackEditor(GazeTrackEditorHandle);
		SequencerModule->UnRegisterTrackEditor(HeightOffsetTrackEditorHandle);
	}

	if (FModuleManager::Get().IsModuleLoaded("LevelSequence"))
	{
		ILevelSequenceModule& LevelSequenceModule = FModuleManager::LoadModuleChecked<ILevelSequenceModule>("LevelSequence");
		LevelSequenceModule.OnNewActorTrackAdded().Remove(DefaultTrackHandle);
		LevelSequenceModule.OnNewActorTrackAdded().Remove(AssetOpenedHandle);
	}

	if (GEditor)
	{
		GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OnAssetEditorOpened().Remove(AssetOpenedHandle);
		FEditorDelegates::OnMapLoad.RemoveAll(this);
		FEditorDelegates::OnDeleteActorMessage.RemoveAll(this);
	}
	
	CutSceneEditorPtr.Reset();
}

bool FKGStoryLineEditorModule::IsSequencerEditorOpen()
{
	return CutSceneEditorPtr.IsValid();
}

bool FKGStoryLineEditorModule::CanTypeOfAssetOpen(const UClass* InClass)
{
	if (InClass == ULevelSequence::StaticClass())
	{
		if (UKGStoryLineEditorSubSystem::Get().IsDialogueEditorOpen())
		{
			FText Message = FText::FromString(TEXT("请先关闭剧情编辑器, 再重新打开Sequence"));
			FMessageDialog::Open(EAppMsgType::Ok, Message);
			return false;
		}
	}

	if (InClass == UDialogueAsset::StaticClass())
	{
		FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
		if (KGStoryLineEditorModule.IsSequencerEditorOpen())
		{
			FText Message = FText::FromString(TEXT("请先关闭Sequencer编辑器, 再打开剧情编辑器"));
			FMessageDialog::Open(EAppMsgType::Ok, Message);
			return false;
		}
		
		if (SDialogueAssetBrowser::OpenDialogueIsGamePreview())
		{
			FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("游戏状态下不可以打开剧情编辑器")));
			return false;
		}
	}

	return true;
}

void FKGStoryLineEditorModule::CheckSequenceData()
{
#if WITH_EDITOR
	UKGSequenceManager* KGSequenceManager = UKGSequenceManager::GetSequenceManagerInEditor();
	if (KGSequenceManager)
	{
		KGSequenceManager->CheckSequenceData();
	}
#endif
}

void FKGStoryLineEditorModule::AddDefaultSystemTracks(const AActor& SourceActor, const FGuid& Binding, TSharedPtr<ISequencer> Sequencer)
{
	const ABaseCharacter* Actor = Cast<ABaseCharacter>(&SourceActor);
	if (Actor == nullptr)
	{
		return;
	}
	// 删除默认添加LookAt功能 liuruilin@kuaishou.com 2026/6/12
	//美术还是要同款功能 修复一下问题，先打开 lizhang@kuaishou.com
#if 0 //LookAtComponent 先禁用了吧 hujianglong@kuaishou.com
	ULookAtComponent* LookAtComponent = Actor->GetComponentByClass<ULookAtComponent>();
	if (LookAtComponent == nullptr)
	{
		return;
	}
	UMovieSceneSequence* Sequence = Sequencer->GetFocusedMovieSceneSequence();
	UMovieScene* MovieScene = Sequence->GetMovieScene();

	UClass* TrackClass = UMovieSceneLookAtTrack::StaticClass();
	UMovieSceneTrack* NewTrack = MovieScene->FindTrack(TrackClass, Binding);
	if (!NewTrack)
	{
		NewTrack = MovieScene->AddTrack(TrackClass, Binding);
		//NewTrack->SetDisplayName(LOCTEXT("LookAtTrackName", "LookAt"));

#if WITH_EDITORONLY_DATA
		if (!NewTrack->SupportsDefaultSections())
		{
			return;
		}
#endif

		UMovieSceneSection* NewSection;
		if (NewTrack->GetAllSections().Num() > 0)
		{
			NewSection = NewTrack->GetAllSections()[0];
		}
		else
		{
			NewSection = NewTrack->CreateNewSection();
			NewTrack->AddSection(*NewSection);
		}

		UMovieSceneLookAtSection* MovieSceneLookAtSection = Cast<UMovieSceneLookAtSection>(NewSection);

		FRotator Eye = LookAtComponent->GetEye();
		FVector EyeScale = LookAtComponent->GetEyeScale();
		FRotator Head = LookAtComponent->GetHead();
		FRotator Body = LookAtComponent->GetBody();
		FRotator Spine_01 = LookAtComponent->GetSpine_01();
		FRotator Spine_02 = LookAtComponent->GetSpine_02();
		FRotator Spine_03 = LookAtComponent->GetSpine_03();

		TArrayView<FMovieSceneDoubleChannel*> DoubleChannels = MovieSceneLookAtSection->GetChannelProxy().GetChannels<FMovieSceneDoubleChannel>();
		DoubleChannels[0]->SetDefault(Eye.Euler().X);
		DoubleChannels[1]->SetDefault(Eye.Euler().Y);
		DoubleChannels[2]->SetDefault(EyeScale.Z);

		DoubleChannels[3]->SetDefault(Head.Euler().X);
		DoubleChannels[4]->SetDefault(Head.Euler().Y);
		DoubleChannels[5]->SetDefault(Head.Euler().Z);

		DoubleChannels[6]->SetDefault(Body.Euler().X);
		DoubleChannels[7]->SetDefault(Body.Euler().Y);
		DoubleChannels[8]->SetDefault(Body.Euler().Z);

		DoubleChannels[9]->SetDefault(Spine_01.Euler().X);
		DoubleChannels[10]->SetDefault(Spine_01.Euler().Y);
		DoubleChannels[11]->SetDefault(Spine_01.Euler().Z);

		DoubleChannels[12]->SetDefault(Spine_02.Euler().X);
		DoubleChannels[13]->SetDefault(Spine_02.Euler().Y);
		DoubleChannels[14]->SetDefault(Spine_02.Euler().Z);

		DoubleChannels[15]->SetDefault(Spine_03.Euler().X);
		DoubleChannels[16]->SetDefault(Spine_03.Euler().Y);
		DoubleChannels[17]->SetDefault(Spine_03.Euler().Z);

		/*if (Sequencer->GetInfiniteKeyAreas())
		{
			NewSection->SetRange(TRange<FFrameNumber>::All());
		}*/
		FFrameRate FrameResolution = MovieScene->GetTickResolution();
		FFrameTime SpawnSectionStartTime = Sequencer->GetLocalTime().ConvertTo(FrameResolution);
		FFrameTime SpawnSectionDuration = FrameResolution.AsFrameTime(5.0);

		MovieSceneLookAtSection->SetRange(TRange<FFrameNumber>(
			SpawnSectionStartTime.RoundToFrame(),
			(SpawnSectionStartTime + SpawnSectionDuration).RoundToFrame()));
	}
#endif
}


void FKGStoryLineEditorModule::UnregisterEditorObjectBindings()
{
	if (ISequencerModule* SequencerModule = FModuleManager::GetModulePtr<ISequencerModule>("Sequencer"))
	{
		SequencerModule->UnRegisterEditorObjectBinding(ActorBindingDelegateHandle);
	}
}	
	
void FKGStoryLineEditorModule::RegisterEditorObjectBindings()
{
	ISequencerModule& SequencerModule = FModuleManager::LoadModuleChecked<ISequencerModule>("Sequencer");
	ActorBindingDelegateHandle = SequencerModule.RegisterEditorObjectBinding(
		FOnCreateEditorObjectBinding::CreateLambda([](TSharedRef<ISequencer> InSequencer)
		{
			return MakeShareable(new FCutsceneCustomObjectBinding(InSequencer));
		})
	);
}

IMPLEMENT_MODULE(FKGStoryLineEditorModule, KGStoryLineEditor)

#undef LOCTEXT_NAMESPACE
