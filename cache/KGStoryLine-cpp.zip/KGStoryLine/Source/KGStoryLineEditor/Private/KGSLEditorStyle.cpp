// Fill out your copyright notice in the Description page of Project Settings.


#include "KGSLEditorStyle.h"

#include "Interfaces/IPluginManager.h"
#include "Styling/CoreStyle.h"
#include "Styling/SlateStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Styling/SlateTypes.h"
#include "Styling/StyleColors.h"

#define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush(Style->RootToContentDir(RelativePath, TEXT(".png")), __VA_ARGS__)
#define IMAGE_BRUSH_SVG(RelativePath, ...) FSlateVectorImageBrush(Style->RootToContentDir(RelativePath, TEXT(".svg")), __VA_ARGS__)

TSharedPtr<ISlateStyle> FKGSLEditorStyle::StyleInstance = nullptr;

void FKGSLEditorStyle::Initialize()
{
	if (StyleInstance == nullptr)
	{
		StyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FKGSLEditorStyle::Shutdown()
{
	if (StyleInstance != nullptr)
	{
		FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	}
	StyleInstance.Reset();
}

const ISlateStyle& FKGSLEditorStyle::Get()
{
	if (StyleInstance == nullptr)
	{
		Initialize();
	}
	return *StyleInstance;
}

FName FKGSLEditorStyle::GetStyleSetName()
{
	static const FName StyleSetName(TEXT("KGSLEditorStyle"));
	return StyleSetName;
}

TSharedRef<ISlateStyle> FKGSLEditorStyle::Create()
{
	check(StyleInstance == nullptr);
	TSharedRef<FSlateStyleSet> Style = MakeShareable(new FSlateStyleSet(GetStyleSetName()));
	static FString ContentDir = IPluginManager::Get().FindPlugin(TEXT("KGStoryLine"))->GetContentDir();
	Style->SetContentRoot( ContentDir / TEXT("Editor/Slate") );

	// style for button
	FSlateRoundedBoxBrush Brush = FSlateRoundedBoxBrush(FStyleColors::AccentWhite, 4.f,
		FLinearColor(0, 0, 0, .8), 0.0);
	Brush.SetImageSize(FVector2D(16, 16));
	Brush.TintColor = FLinearColor(0.f, 0.f, 0.f, 0.f);
	FSlateRoundedBoxBrush BrushDisable = FSlateRoundedBoxBrush(FStyleColors::SelectInactive, 4.f,
		FLinearColor(0, 0, 0, .8), 0.0);
	BrushDisable.SetImageSize(FVector2D(16, 16));
	BrushDisable.TintColor = FLinearColor(0.f, 0.f, 0.f, 0.f);
	
	FButtonStyle ButtonStyleMoveUp = FAppStyle::Get().GetWidgetStyle<FButtonStyle>("EditorViewportToolBar.Button");
	ButtonStyleMoveUp.SetNormal(Brush)
	.SetPressed(Brush)
	.SetHovered(Brush)
	.SetDisabled(BrushDisable)
	.SetNormalForeground(FSlateColor::UseForeground())
	.SetPressedForeground(FStyleColors::AccentGreen)
	.SetHoveredForeground(FSlateColor::UseForeground())
	.SetNormalPadding(FMargin(4, 4, 4, 4))
	.SetPressedPadding(FMargin(4.0f, 5.f, 4.f, 3.f));
	
	Style->Set("KGSL.ButtonStyle", ButtonStyleMoveUp);

	// style for image
	const FSlateBrush* BrushUp = FAppStyle::Get().GetBrush("Symbols.DoubleUpArrow");
	Style->Set("KGSL.DoubleUpArrow", new FSlateImageBrush(BrushUp->GetResourceName(), FVector2D(20, 20)));

	const FSlateBrush* BrushDown = FAppStyle::Get().GetBrush("Symbols.DoubleDownArrow");
	Style->Set("KGSL.DoubleDownArrow", new FSlateImageBrush(BrushDown->GetResourceName(), FVector2D(20, 20)));

	Style->Set("KGSL.Tracks.CameraActor", new IMAGE_BRUSH("Icons/CameraActor_16x", FVector2D(16)));
	Style->Set("KGSL.Tracks.CameraCut", new IMAGE_BRUSH("Icons/Icon_Camera_Cut_Track_16x", FVector2D(16)));
	Style->Set("KGSL.Tracks.Actor", new IMAGE_BRUSH_SVG("Icons/SkeletalMeshActor_16", FVector2D(16)));

	// font style
	FTextBlockStyle NormalText = FTextBlockStyle()
		.SetFont(FCoreStyle::GetDefaultFontStyle("Regular", 11))
		.SetColorAndOpacity(FSlateColor::UseForeground())
		.SetShadowOffset(FVector2D::ZeroVector)
		.SetShadowColorAndOpacity(FLinearColor::Black)
		.SetHighlightColor( FLinearColor( 0.02f, 0.3f, 0.0f));

	Style->Set("KGSL.NormalText", FTextBlockStyle(NormalText)
			.SetColorAndOpacity(FLinearColor( 1.0f, 1.0f, 1.0f)));
	
	return Style;
}

#undef IMAGE_BRUSH
#undef IMAGE_BRUSH_SVG