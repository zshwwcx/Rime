#pragma once

#include "MovieSceneTrack.h"
#include "CoreMinimal.h"
#include "MovieSceneTrackEditor.h"

class KGSTORYLINEEDITOR_API FResizeBoundsTrackEditor : public FMovieSceneTrackEditor
{
public:
	FResizeBoundsTrackEditor(TSharedRef<ISequencer> InSequencer);
	virtual ~FResizeBoundsTrackEditor();

	static TSharedRef<ISequencerTrackEditor> CreateTrackEditor(TSharedRef<ISequencer> OwningSequencer);

	virtual bool SupportsType(TSubclassOf<UMovieSceneTrack> Type) const override;
	virtual void OnInitialize() override;
	virtual void OnRelease() override;

private:
	void OnPreSave(ISequencer& InSequencer);
	void OnActorAddedToSequencer(AActor* Actor, const FGuid ObjectBinding);
	void AddDefaultResizeBoundsTrack(UMovieScene* MovieScene, const FGuid& ObjectBinding, TRange<FFrameNumber>& Range);
	bool GetSkeletalAnimationSectionTotalRange(UMovieScene* MovieScene, const FGuid& ObjectBinding, TRange<FFrameNumber>& OutRange);
};
