// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "PropertyTrackEditor.h"

class SSearchableComboBox;

class FMovieSceneGazeTrackEditor final : public FMovieSceneTrackEditor
{
public:
	explicit FMovieSceneGazeTrackEditor(const TSharedRef<ISequencer>& InSequencer)
		: FMovieSceneTrackEditor(InSequencer)
	{
	}
	
	static TSharedRef<ISequencerTrackEditor> CreateTrackEditor(TSharedRef<ISequencer> OwningSequencer)
	{
		return MakeShareable(new FMovieSceneGazeTrackEditor(OwningSequencer));
	}

	//~ FPropertyTrackEditor interface
	virtual bool SupportsType(TSubclassOf<UMovieSceneTrack> TrackClass) const override;
	virtual bool SupportsSequence(UMovieSceneSequence* InSequence) const override;
	virtual void BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass) override;
	virtual TSharedPtr<SWidget> BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params) override;
	virtual TSharedRef<ISequencerSection> MakeSectionInterface(UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding) override;
};

class FGazeSection final : public FSequencerSection, public TSharedFromThis<FGazeSection>
{
public:
	explicit FGazeSection(const TSharedPtr<ISequencer>& InSequencer, UMovieSceneSection& InSection);
	void UpdateCandidates();
	void OnGazeActorChanged(TSharedPtr<FString> String, ESelectInfo::Type Arg);
	void RefreshCandidateBones(const TWeakObjectPtr<AActor> InActor);
	static TSharedRef<SWidget> MakeWidgetFromString(TSharedPtr<FString> InString);
	FText GetCurrentBoneName() const;
	FText GetCurrentActorName() const;
	void OnBoneChanged(TSharedPtr<FString> String, ESelectInfo::Type Arg);
	TOptional<float> GetOffset(int I) const;
	void SetOffset(float X, int I) const;
	void BuildEditGazeSubMenu(FMenuBuilder& MenuBuilder);
	virtual void BuildSectionContextMenu(FMenuBuilder& MenuBuilder, const FGuid& ObjectBinding) override;
	FText GetSectionText() const;
	
	virtual TSharedRef<SWidget> GenerateSectionWidget() override;

private:
	TWeakPtr<ISequencer> WeakSequencer;
	TArray<TSharedPtr<FString>> CandidateObjectNames;
	TArray<FGuid> CandidateObjectBindings;
	TArray<TSharedPtr<FString>> CandidateBoneNames;
	int32 CurrentActorIndex;
	int32 CurrentBoneIndex;
	TWeakObjectPtr<AActor> TargetActor;
	TSharedPtr<SSearchableComboBox> BoneBox;
};
