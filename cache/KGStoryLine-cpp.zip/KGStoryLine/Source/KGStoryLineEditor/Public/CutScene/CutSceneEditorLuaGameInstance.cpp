#include "CutScene/CutSceneEditorLuaGameInstance.h"

#include "DialogueEditor/DialogueEditorUtilities.h"
#include "KGStoryLineEditorModule.h"
#include "LevelSequence.h"
#include "MovieScene.h"
#include "Slate/SceneViewport.h"
#include "Modules/ModuleManager.h"
#include "3C/Util/KGUtils.h"

void UCutSceneEditorLuaGameInstance::AddUI(UUserWidget* Widget)
{
	if (Widget == nullptr)
		return;
	TSharedRef<SWidget> SWidget = Widget->TakeWidget();

	//const FName NAME_LevelEditorName = "LevelEditor";
	//FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>(NAME_LevelEditorName);
	//TSharedPtr<class SLevelViewport> ActiveLevelViewport = LevelEditorModule.GetFirstActiveLevelViewport();
	//if (ActiveLevelViewport.IsValid())
	//	ActiveLevelViewport->AddOverlayWidget(SWidget);
	FDialogueEditorUtilities::AddOverlayWidgetToViewport(SWidget);
}

void UCutSceneEditorLuaGameInstance::RemoveUI(UUserWidget* Widget)
{
	if (Widget == nullptr)
		return;
	TSharedRef<SWidget> SWidget = Widget->TakeWidget();
	//const FName NAME_LevelEditorName = "LevelEditor";
	//FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>(NAME_LevelEditorName);
	// caution by fanggang@kuaishou.com: make sure remove properly when you use 'GetFirstActiveLevelViewport'  
	// TSharedPtr<class SLevelViewport> ActiveLevelViewport = LevelEditorModule.GetFirstActiveLevelViewport();
	// if (ActiveLevelViewport.IsValid())
	// 	ActiveLevelViewport->RemoveOverlayWidget(SWidget);
	//TSharedPtr<ILevelEditor> LevelEditor = LevelEditorModule.GetFirstLevelEditor();
	//if (LevelEditor.IsValid())
	//{
	//	TArray<TSharedPtr<SLevelViewport>> LevelViewports = LevelEditor->GetViewports();
	//	for (auto const& Viewport : LevelViewports)
	//	{
	//		if (Viewport.IsValid())
	//		{
	//			Viewport->RemoveOverlayWidget(SWidget);
	//		}
	//	}
	//}
	FDialogueEditorUtilities::RemoveOverlayWidgetToViewport(SWidget);
}

FVector2D UCutSceneEditorLuaGameInstance::GetViewportSize()
{
	const FName NAME_LevelEditorName = "LevelEditor";
	FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>(NAME_LevelEditorName);
	TSharedPtr<class SLevelViewport> ActiveLevelViewport = LevelEditorModule.GetFirstActiveLevelViewport();
	if (ActiveLevelViewport.IsValid())
	{
		TSharedPtr<FSceneViewport> SceneViewport = ActiveLevelViewport->GetSceneViewport();
		if(SceneViewport.IsValid())
		{
			return SceneViewport->GetSize();
		}
	}
	FVector2D ViewportSize(1, 1);
	return ViewportSize;
}
KGObjectID UCutSceneEditorLuaGameInstance::GetTemplateIDByTag(FString TagName)
{
	FKGStoryLineEditorModule& KGStoryLineEditorModule = FModuleManager::LoadModuleChecked<FKGStoryLineEditorModule>("KGStoryLineEditor");
	TSharedPtr<FCutSceneEditor>& CutSceneEditor = KGStoryLineEditorModule.GetCutSceneEditorPtr();
	if (!CutSceneEditor) return KG_INVALID_ID;
	
	TWeakPtr<ISequencer> Sequencer = CutSceneEditor->GetSequencer();
	TWeakObjectPtr<ULevelSequence> LevelSequence = CutSceneEditor->GetLevelSequence();
	if(!Sequencer.IsValid() || !LevelSequence.IsValid())
		return KG_INVALID_ID;

	if (UMovieScene* MovieScene = LevelSequence->GetMovieScene())
	{
		const TMap<FName, FMovieSceneObjectBindingIDs>& BindingGroups = MovieScene->AllTaggedBindings();
		for (auto[Tag, Bindings] : BindingGroups)
		{
			if(Tag.ToString() == TagName)
			{
				for (FMovieSceneObjectBindingID BindingID : Bindings.IDs)
				{
					FGuid ObjectGuid = BindingID.GetGuid();
					TArrayView<TWeakObjectPtr<UObject>> BoundObjects = Sequencer.Pin()->FindObjectsInCurrentSequence(ObjectGuid);

					for (TWeakObjectPtr<UObject> Obj : BoundObjects)
					{
						if (AActor* Actor = Cast<AActor>(Obj.Get()))
						{
							return KGUtils::GetIDByObject(Actor);
						}
					}
				}
			}
		}
	}
	return KG_INVALID_ID;
}