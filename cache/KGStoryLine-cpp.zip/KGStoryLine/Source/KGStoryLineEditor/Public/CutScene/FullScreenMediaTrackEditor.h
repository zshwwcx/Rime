// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "MovieSceneTrackEditor.h"
#include "Sequencer/MediaTrackEditor.h"

class UFullScreenMediaTrack;

class FFullScreenMediaTrackEditor final : public FMediaTrackEditor
{
public:
	static TSharedRef<ISequencerTrackEditor>  CreateTrackEditor(TSharedRef<ISequencer> OwningSequencer)
	{
		return MakeShared<FFullScreenMediaTrackEditor>(OwningSequencer);
	}

	FFullScreenMediaTrackEditor(TSharedRef<ISequencer> InSequencer);
	virtual bool SupportsType(TSubclassOf<UMovieSceneTrack> TrackClass) const override;
	virtual ~FFullScreenMediaTrackEditor() override;
	virtual void BuildAddTrackMenu(FMenuBuilder& MenuBuilder) override;
	virtual TSharedPtr<SWidget> BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params) override;
	virtual bool HandleAssetAdded(UObject* Asset, const FGuid& TargetObjectGuid) override;
	
	void OnAddTrackClicked() const;
};
