#pragma once

#include "CoreMinimal.h"
#include "EditorViewportClient.h"
#include "Lua/LuaEnv.h"
#include "TickableEditorObject.h"
#include "EventHandlers/ISignedObjectEventHandler.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "EventHandlers/MovieSceneDataEventContainer.h"
 
class APostProcessVolume;
class ISequencer;
class ULevelSequence;

class KGSTORYLINEEDITOR_API FCutSceneEditor final : FTickableEditorObject, UE::MovieScene::ISignedObjectEventHandler
{
public:
	FCutSceneEditor();
	virtual ~FCutSceneEditor() override; 

	void InitLuaEnvironment();
	void InitializeCharacterLighting() const;
	
	virtual void Tick(float DeltaTime) override;
	virtual TStatId GetStatId() const override;

	static void InitializeRenderPipeline();
	void OnCameraCut(UObject* Object, bool bArg) const;
	void InitializeRoleComposite(TWeakPtr<ISequencer> Sequencer, TWeakObjectPtr<ULevelSequence> LevelSequence);

	void InitPostProcessPreview();
	void ModifyViewportClientView(FEditorViewportViewModifierParams& Params);

	void UninitPostProcessPreview();
	
	bool GetFacadeControlIDs(TMap<int32, FString>& FacadeControlID) const;
	
	virtual void OnModifiedIndirectly(UMovieSceneSignedObject* Obj) override;
	
	static void BuildToolbar(FToolBarBuilder& ToolBarBuilder);
	static void ExtendMenu();
	
	TWeakPtr<ISequencer> GetSequencer();
	TWeakObjectPtr<ULevelSequence> GetLevelSequence();
private:
	void UnInitLuaEnvironment();
	void IterateTagsForRoleComposite();	
	void UninitializeRoleComposite();
	
	// 防止LevelInstance在Sequence里处于编辑状态下的时候被删掉
	static void OnActorAddedToSequencer(AActor* Actor, FGuid Guid, TWeakPtr<ISequencer> WeakSequencer);

private:
	void RequestRoleComposite(AActor* Actor, const FString& Tag, TArray<FName> Tags) const;
	void RequestObjectComposite(AActor* Actor, const FString& Tag, TArray<FName> Tags) const;
	
	TMap<int32, FString> FacadeControlIDs;
	TMap<TWeakObjectPtr<>, TSet<FName>> RoleTagMap; 
	class UEditorLuaEnv *LuaEnv = nullptr;
	FDelegateHandle RoleCompositeHandler;
	TWeakPtr<ISequencer> Sequencer;
	TWeakObjectPtr<ULevelSequence> LevelSequence;

	
	TWeakObjectPtr<APlayerController> PlayerController;

	FDelegateHandle PostProcessModifyHandle;
	FDelegateHandle CameraCutHandler;
	FDelegateHandle OnActorAddedHandle;
	
	UE::MovieScene::TNonIntrusiveEventHandler<UE::MovieScene::ISignedObjectEventHandler> MovieSceneModified;

	friend class UC7CutsceneGameInstance;
};
