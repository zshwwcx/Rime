#pragma once
#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "CutScene/MovieSceneCustomSection.h"
#include "Engine/DataAsset.h"
#include "Engine/DeveloperSettings.h"
#include "GameFramework/PlayerController.h"

#include "CutSceneEditorSettings.generated.h"

class UAnimBlueprint;
class UMoviePipelineQueue;
class UMoviePipelinePrimaryConfig;
class UDataTable;

UENUM()
enum class ECutsceneTagFitType
{
	Spawnable,
	PossessableSpawnable,
	Possessable,
};

USTRUCT()
struct FCutsceneTagDefine
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere)
	FName TagName;
	
	UPROPERTY(EditAnywhere)
	FText TipInfo;
	
	/** 标记是否可以给这种情况的对象使用, 分三种情况: 
	 * 1. Spawnable 
	 * 2. Possessable 
	 * 3. Possessable possesses Spawnable
	 */
	UPROPERTY(EditAnywhere)
	ECutsceneTagFitType FitType = ECutsceneTagFitType::Spawnable;
	
	FString GetAllFitTypeString() const
	{
		switch (FitType)
		{
		case ECutsceneTagFitType::Spawnable:
			return TEXT("Spawnable");
		case ECutsceneTagFitType::PossessableSpawnable:
			return TEXT("Spawnable 和 控制Spawnable的Possessable");
		case ECutsceneTagFitType::Possessable:
			return "Spawnable 和 控制Spawnable的Possessable 和 Possessable";
		default:
			return "";
		}
	}
	
	static FString GetFitTypeString(const ECutsceneTagFitType Type)
	{
		switch (Type)
		{
		case ECutsceneTagFitType::Spawnable:
			return TEXT("Spawnable");
		case ECutsceneTagFitType::PossessableSpawnable:
			return TEXT("控制Spawnable的Possessable");
		case ECutsceneTagFitType::Possessable:
			return "Possessable";
		default:
			return "";
		}
	}
};

/** 放资产的设置, 便于美术/TA修改 */
UCLASS()
class UCutsceneEditorAssetSettings: public UPrimaryDataAsset
{
	GENERATED_BODY()
public:
	
	/** 常用Tag定义 */
	UPROPERTY(EditAnywhere, Category = "Tag Manager")
	TArray<FCutsceneTagDefine> Tags;
	
	/** Wiki 的链接 */
	UPROPERTY(EditAnywhere, Category = "Base")
	FString DocumentUrl;
	
	UPROPERTY(EditAnywhere, Category = "Tag Manager")
	TArray<TSoftClassPtr<AActor>> IgnoredActorTypes;
	
	UPROPERTY(EditAnywhere, Category = "Render Video")
	TSoftObjectPtr<UMoviePipelineQueue> ArtVideoRenderQueue;
	
	UPROPERTY(EditAnywhere, Category = "Render Video")
	TSoftObjectPtr<UMoviePipelinePrimaryConfig> ArtVideoRenderConfig;
};


UCLASS(Blueprintable, Config = Editor, DefaultConfig, meta = (DisplayName = "CutScene Editor Settings"))
class UCutSceneEditorSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UCutSceneEditorSettings(const FObjectInitializer& ObjectInitializer): Super(ObjectInitializer){};

	UPROPERTY(EditAnywhere, Config)
	TSubclassOf<APlayerController> PlayerControllerClass;
	
	/** 捏脸的Actor类型 */
	UPROPERTY(Config, EditAnywhere)
	TArray<TSoftObjectPtr<UBlueprint>> CutsceneDynamicActors;

	/** 常用的Actor类型 */
	UPROPERTY(Config, EditAnywhere)
	TArray<TSoftClassPtr<UObject>> CommonCutsceneActors;

	UPROPERTY(Config, EditAnywhere)
	TSoftObjectPtr<UDataTable> FixLightDataTable;

	UPROPERTY(Config, EditAnywhere)
	FName LightTemplateDir;

	UPROPERTY(Config, EditAnywhere)
	TSubclassOf<UMovieSceneCustomData> LightControlClass;

	UPROPERTY(Config, EditAnywhere)
	TSoftObjectPtr<UCutsceneEditorAssetSettings> AssetSettings;
	
	UPROPERTY(Config, EditAnywhere)
	TSoftObjectPtr<UAnimBlueprint> MayaLiveLinkAnimBlueprint;

	UFUNCTION(BlueprintCallable)
	static UCutsceneEditorAssetSettings* GetAssetSettingsChecked();
};
