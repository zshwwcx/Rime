// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#pragma once

#include "ISequencerEditorObjectBinding.h"
#include "Templates/SharedPointer.h"

class UActorFactory;
class UBlueprint;
class FSequencer;
class ISequencer;
class AActor;

class FCutsceneCustomObjectBinding : public ISequencerEditorObjectBinding
{
public:

	FCutsceneCustomObjectBinding(const TSharedRef<ISequencer>& InSequencer);

	// ISequencerEditorObjectBinding interface
	virtual void BuildSequencerAddMenu(FMenuBuilder& MenuBuilder) override;
	virtual bool SupportsSequence(UMovieSceneSequence* InSequence) const override;

private:
	/** Menu extension callback for the add menu */
	void AddBlueprintsMenuExtensions(FMenuBuilder& MenuBuilder);
	
	/** Add More Light Template */
	void AddLightTemplateMenuExtensions(FMenuBuilder& MenuBuilder);
	
	/** Add Cutscene Dynamic Actor */
	void AddCutsceneDynamicActor(UBlueprint* Bp);
	
	void AddCommonActor(UObject* Obj) const;

	/** Add and Setup Light Template */
	void AddLightTemplate(UBlueprint* Blueprint);

	static FGuid AddSpawnable(ISequencer& Sequencer, UObject& Obj, UActorFactory* ActorFactory);
	
	/** Init Facade Control IDs */
	void InitFacadeControlIDs();

	/** 寻找 Light Template 一共有哪些 */
	void InitializeLightTemplates();
	
	static void CreateNotification(const FText& Message, bool bSuccess, float FadeOutDuration = 1.5f, float ExpireDuration = 1.5f, bool bWarning = false);

private:
	TWeakPtr<ISequencer> Sequencer;

	TMap<int32, FString> FacadeControlIDs;

	TArray<TWeakObjectPtr<UBlueprint>> LightTemplates; 
};
