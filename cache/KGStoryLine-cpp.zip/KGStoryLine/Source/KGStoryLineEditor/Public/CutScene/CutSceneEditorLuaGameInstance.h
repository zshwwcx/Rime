#pragma once

#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "KGCore/Public/Lua/LuaEnv.h"
#include "LevelEditor.h"
#include "SLevelViewport.h"
#include "Blueprint/UserWidget.h"
#include "CutSceneEditorLuaGameInstance.generated.h"


UCLASS(BlueprintType, Blueprintable)
class KGSTORYLINEEDITOR_API UCutSceneEditorLuaGameInstance : public UEditorLuaGameInstanceBase
{
	GENERATED_BODY()

#pragma region Important
public:
	FString GetLuaFilePath_Implementation() const override
	{
		return TEXT("Gameplay.CinematicSystem.CutScene.Editor.CutSceneEditorLuaGameInstance");
	}

	UFUNCTION(BlueprintCallable)
	void AddUI(UUserWidget* Widget);

	UFUNCTION(BlueprintCallable)
	void RemoveUI(UUserWidget* Widget);

	UFUNCTION()
	bool bIsRenderGameInstance() { return false; }

	UFUNCTION(BlueprintImplementableEvent)
	void InitializeCharacterLighting(const FString& LevelPath, const FString& SeqPath);
	
	UFUNCTION(BlueprintCallable)
	FVector2D GetViewportSize();
	
	UFUNCTION(BlueprintImplementableEvent)
	void SetCurrentCamera(UObject* Object, bool bArg);

	UFUNCTION(BlueprintCallable)
	int64 GetTemplateIDByTag(FString TagName);

#pragma endregion Important
};
