#pragma once
#include "MovieSceneTrack.h"
#include "CoreMinimal.h"
#include "CutScene/MovieSceneCustomTrack.h"
#include "MovieSceneTrackEditor.h"
#include "Misc/NotifyHook.h"

class UMovieSceneCustomSection;
class UMovieScenePlotPositionTemplateTrack;
class ISequencer;
class UCustomSectionEditor;

class KGSTORYLINEEDITOR_API FMovieSceneCustomTrackEditor : public FMovieSceneTrackEditor
{
public:
	FMovieSceneCustomTrackEditor(TSharedRef<ISequencer> InSequencer);
	virtual ~FMovieSceneCustomTrackEditor() override;

	static TSharedRef<ISequencerTrackEditor> CreateTrackEditor(TSharedRef<ISequencer> OwningSequencer);

public:
	virtual TSharedRef<ISequencerSection> MakeSectionInterface(UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding) override;
	virtual bool SupportsSequence(UMovieSceneSequence* InSequence) const override;
	virtual bool SupportsType(TSubclassOf<UMovieSceneTrack> Type) const override;
	virtual const FSlateBrush* GetIconBrush() const override;
	virtual void BuildAddTrackMenu(FMenuBuilder& MenuBuilder) override;
	virtual void BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass) override;
	virtual bool IsResizable(UMovieSceneTrack* InTrack) const override;
	virtual TSharedPtr<SWidget> BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params) override;
	
	virtual bool OnAllowDrop(const FDragDropEvent& DragDropEvent, FSequencerDragDropParams& DragDropParams) override;
	virtual FReply OnDrop(const FDragDropEvent& DragDropEvent, const FSequencerDragDropParams& DragDropParams) override;
	static void SetupSection(UMovieScene* FocusedMovieScene, UMovieSceneCustomTrack* NewTrack, UMovieSceneCustomSection* NewSection, const TWeakPtr<ISequencer>& WeakSeq);
	
	virtual void BuildObjectBindingContextMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass) override;
	static void OpenTagManager(TWeakPtr<ISequencer> WeakSequencer, TArray<FGuid> BindObjects);
	
private:
	void OnAddCustomTrackAndSection(FGuid ObjectBinding) const;
	static void PopulateMenu_CreateNewSection(FMenuBuilder& MenuBuilder, int32 RowIndex, UMovieSceneTrack* Track, TWeakPtr<ISequencer> InSequencer);
};

class FMovieSceneCustomSection : public ISequencerSection
	, public TSharedFromThis<FMovieSceneCustomSection>
	, public FGCObject
	, public FNotifyHook
{
public:
	FMovieSceneCustomSection(UMovieSceneSection& InSection, const TWeakPtr<ISequencer>& InSequencer);
	virtual ~FMovieSceneCustomSection() override;

public:
	virtual UMovieSceneSection* GetSectionObject() override;

	virtual FText GetSectionTitle() const override;
	virtual FText GetSectionToolTip() const override;
	virtual float GetSectionHeight(const UE::Sequencer::FViewDensityInfo& ViewDensity) const override;

	virtual int32 OnPaintSection(FSequencerSectionPainter& Painter) const override;
	virtual bool SectionIsResizable() const override { return true; }
	virtual void GenerateSectionLayout(class ISectionLayoutBuilder& LayoutBuilder) override;

	virtual void BeginResizeSection() override;
	virtual void ResizeSection(ESequencerSectionResizeMode ResizeMode, FFrameNumber ResizeTime) override;

	virtual void BeginSlipSection() override;
	virtual void SlipSection(FFrameNumber SlipTime) override;

	virtual TSharedRef<SWidget> GenerateSectionWidget() override;
	
	virtual void BuildSectionContextMenu(FMenuBuilder& MenuBuilder, const FGuid& ObjectBinding) override;
	
	void BuildCustomDataMenu(FMenuBuilder& MenuBuilder);

	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	virtual FString GetReferencerName() const override;
	
	void OnCustomSectionPostEditChangeProperty();
	void CreateCustomEditor();
	
	virtual void NotifyPostChange(const FPropertyChangedEvent& PropertyChangedEvent, FProperty* PropertyThatChanged) override;
	
	virtual void Tick(const FGeometry& AllottedGeometry, const FGeometry& ClippedGeometry, const double InCurrentTime, const float InDeltaTime) override;

private:
	TWeakObjectPtr<UMovieSceneCustomSection> Section;
	TWeakPtr<ISequencer> Sequencer;
	
	TWeakObjectPtr<UCustomSectionEditor> CustomEditor;
	FString PrevActionName;
};