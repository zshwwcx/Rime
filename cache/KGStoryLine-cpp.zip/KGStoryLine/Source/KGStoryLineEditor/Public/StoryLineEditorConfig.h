// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#pragma once

#include "CoreMinimal.h"
#include "EditorConfigBase.h"
#include "StoryLineEditorConfig.generated.h"

/**
 * 用户 Local 配置或缓存 
 */
UCLASS(EditorConfig="StoryLineEditorConfig")
class KGSTORYLINEEDITOR_API UStoryLineEditorConfig : public UEditorConfigBase
{
	GENERATED_BODY()
public:
	static void Initialize();
	static UStoryLineEditorConfig* Get() { return Instance; }

	/** 更新常用内容的使用频率 */
	void UpdateRecentlyUsedCustomSection(const FString& Content);
	
	/** 获取最近使用的5个内容，按使用频率排序 */
	TArray<FString> GetLatestRecentlyUsedCustomSection() const;

private:
	static constexpr int32 MaxCacheSize = 5;
	
	UPROPERTY(meta=(EditorConfig))
	TArray<FString> RecentlyUsedCustomSection;
	
	static TObjectPtr<UStoryLineEditorConfig> Instance; // cppcheck:ignore 固定搭配写法
};
