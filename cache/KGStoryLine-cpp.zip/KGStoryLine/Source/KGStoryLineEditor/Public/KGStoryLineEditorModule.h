// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"
#include "Subsystems/AssetEditorSubsystem.h"

#include "CutScene/CutSceneEditor.h"
#include "Editor.h"
#include "UnrealEdMisc.h"
#include "ILevelSequenceModule.h"
#include "ISequencerModule.h"
#include "Sequence/KGSequenceManager.h"

DECLARE_LOG_CATEGORY_EXTERN(LogKGStoryLineEditor, Log, All);

class KGSTORYLINEEDITOR_API FKGStoryLineEditorModule : public IModuleInterface
{
public:
	/** IModuleInterface implementation */
	static void OnAssetOpened(UObject* Object); //, IAssetEditorInstance* Instance
	static void OnSequencerCreated(TSharedRef<ISequencer> Sequencer);
	
	void OnWindowClosedEvent(const TSharedRef<SWindow>& Window);
	void OnMapBeginLoad(const FString& Filename, FCanLoadMap& CanLoad);
	void OnDeleteActorMessage(UObject* Object, FString& Message);

	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	bool IsSequencerEditorOpen();
	static bool CanTypeOfAssetOpen(const UClass* InClass);

	static void CheckSequenceData();
	TSharedPtr<FCutSceneEditor>& GetCutSceneEditorPtr() { return CutSceneEditorPtr; }

	TWeakObjectPtr<UObject> GetDialogueRootPackage();
	TSharedPtr<FCutSceneEditor> GetCutsceneEditor();

protected:
	static void AddDefaultSystemTracks(const AActor& SourceActor, const FGuid& Binding, TSharedPtr<ISequencer> Sequencer);

private:
	void RegisterEditorToolMenu();

	void OpenAssetBrowserTab();
	
	void UnregisterEditorObjectBindings();
	void RegisterEditorObjectBindings();

private:
	FDelegateHandle AnimMontageSequenceHandle;
	FDelegateHandle LookAtPropertyTrackCreateEditorHandle;
	FDelegateHandle AssetOpenedHandle;
	FDelegateHandle DefaultTrackHandle;
	FDelegateHandle Audio2FaceTrackEditorHandle;
	FDelegateHandle ResizeBoundsTrackEditorHandle;
	FDelegateHandle ActorBindingDelegateHandle;
	FDelegateHandle FullScreenMediaTrackEditorHandle;
	FDelegateHandle FMovieSceneBatchMaterialTrackEditorHandle;
	FDelegateHandle GazeTrackEditorHandle;
	FDelegateHandle SequenceCreatedHandle;
	FDelegateHandle HeightOffsetTrackEditorHandle;

	TSharedPtr<FCutSceneEditor> CutSceneEditorPtr;
	
	TSharedPtr<class FDialogueAssetBrowser> DialogueAssetBrowser;
	int32 SavedDistantLightMode = 0;
	bool IsAssetOpening = false;
};
