#pragma once

#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "LevelSequence.h"
#include "GameFramework/GameState.h"
#include "LuaOverriderInterface.h"
#include "Kismet2/ListenerManager.h"
#include "DialogueEditor/LuaAsset/LuaAssetHelper.h"
#include "DialogueEditor/Widgets/AssetBrowser/SDialogueCheckWarningWidget.h"
#include "DialogueEditorManager.generated.h"




class FJsonValue;
class UDialogueAsset;
USTRUCT(BlueprintType)
struct FDialogueEditorCommand
{
	GENERATED_BODY()
public:
	UPROPERTY()
	FString Name;
	UPROPERTY()
	FString HandlerFunction;
	UPROPERTY()
	FString CheckVisibleFunction;
};
UCLASS(Transient, BlueprintType, Blueprintable)
class KGSTORYLINEEDITOR_API UDialogueEditorManager : public UObject
		, public ILuaOverriderInterface
{
	GENERATED_BODY()

public:
	virtual void Initialize();
	virtual void UnInitialize();

    UPROPERTY(Transient)
    TMap<int64, class UWidgetComponent*> GossipBubbleMap;

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveInitialize();

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveUnInitialize();

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	TMap<FString, FAppreanceTableData> GetAppearanceTableData();

	UFUNCTION(BlueprintImplementableEvent)
	TMap<int32, FString> GetDialogueLineTableData();

	UFUNCTION(BlueprintImplementableEvent)
	FOptionTextTableData GetOptionTextTableData();
	
	UFUNCTION(BlueprintImplementableEvent)
	void SpawnAllDialogueActors(class UDialogueBaseAsset* BaseAsset);

	UFUNCTION(BlueprintImplementableEvent)
	void SpawnEditorDialogueActor(class UDialogueEntity* DialogueEntity);

	UFUNCTION(BlueprintImplementableEvent)
	void RemoveEditorDialogueActor(class UDialogueEntity* DialogueEntity);

	UFUNCTION(BlueprintImplementableEvent)
	void RemoveAllEditorDialogueActors();

	UFUNCTION(BlueprintCallable)
	FString GetCurLevelPath();

	//脚本异步创建完Actor之后，回调到C++层
	UFUNCTION(BlueprintCallable)
	void OnEntityReady(const FString& TrackName, AActor* EntityActor);
	
	UFUNCTION(BlueprintCallable)
	void OnAllEntityReady();

	UFUNCTION(BlueprintImplementableEvent)
	void OnEntityInfoChange(class UDialogueEntity* DialogueEntity, const FString& PropertyName);

	//Detail面板有属性变更时，通知到lua层
	UFUNCTION(BlueprintImplementableEvent)
	void OnObjectFinishChangeProperty(UObject* InObject, const FString& PropertyName, const UObject* ExternalObj = nullptr);
	
	//主要用来在Tick中实时保存Actor数据
	UFUNCTION(BlueprintImplementableEvent)
	void CheckSaveEntity(class UDialogueEntity* DialogueEntity);

	//主要用来在Tick中实时保存Actor数据
	UFUNCTION(BlueprintImplementableEvent)
	TArray<class UActorComponent*> GetTickableComponents(AActor* Actor);

	// UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	// class ACameraActor* GetCurrentCamera();
	
	//获取当前的相机后处理效果
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	FPostProcessSettings SetPostProcessSettingMaterial(FPostProcessSettings PostProcessSetting);

	//是否正在动态调整相机路线
	UFUNCTION(BlueprintImplementableEvent)
	bool IsDynamicAdjustCameraSpline();

	UFUNCTION(BlueprintImplementableEvent)
	void PreCreatePreviewSceneActors();

	UFUNCTION(BlueprintImplementableEvent)
	void PostCreatePreviewSceneActors();

	UFUNCTION(BlueprintImplementableEvent)
	void OnClickStop();

	UFUNCTION(BlueprintImplementableEvent)
	void OnClickSaveAsset(UDialogueAsset* DialogueAsset, bool NeedExport);

    UFUNCTION(BlueprintImplementableEvent)
    bool CanSaveAsset(UDialogueAsset* DialogueAsset);

    UFUNCTION(BlueprintImplementableEvent)
    FString GetGossipBubbleTextFromLua(int32 InGossipBubbleID);

    UFUNCTION(BlueprintCallable)
    UUserWidget* CreateGossipBubbleWidget(int64 InEntityUid, const FString& WidgetBPPath);

    UFUNCTION(BlueprintCallable)
    void RemoveGossipBubbleWidget(int64 InEntityUid);

    UFUNCTION(BlueprintCallable)
    void SetUIRoot(UWidget* InUIRoot);

	UFUNCTION()
	void SetGameView(bool bGameView);

	UFUNCTION()
	class UCameraShakeBase* AddCameraShake(TSubclassOf<class UCameraShakeBase> ShakeClass, class UCameraShakeSourceComponent* ShakeSourceComponent);

	UFUNCTION()
	void AddCameraFrameRadio(bool InBVertical);

	UFUNCTION()
	void RemoveCameraFrameRadio();
	
	UFUNCTION(BlueprintCallable)
	void SetPause(bool bPause);

	UFUNCTION(BlueprintCallable)
	FVector GetViewLocation();

	//获取当前正在编辑的资产
	UFUNCTION()
	UDialogueBaseAsset* GetCurrentAsset();

	//模板重导时，计算哪些轨道需要保持，这个主要计算的是SpawnableTrack
	UFUNCTION(BlueprintCallable)
	TArray<UDialogueTrackBase*> GetShouldKeepTracks(FDialogueEpisode& Episode);

	//判断该轨道类型是否应该保留，这个主要用来处理Action类型Track
	UFUNCTION(BlueprintCallable)
	bool ContainsNoneGenerateClass(UObject* Obj);

	// 设置对话资产的MetaDataTag,对应StoryLineID和台本,有变设置
	void SetMetaDataTag(class UDialogueAsset* DialogueAsset);

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveTick(float DeltaSeconds);

	UFUNCTION(BlueprintImplementableEvent)
	void SetNpcPanelVisible(bool Visible);

	UFUNCTION(BlueprintImplementableEvent)
	void OnBeginPlay(class UDialogueBaseAsset* DialogueAsset);

	UFUNCTION(BlueprintImplementableEvent)
	void OnStop(class UDialogueBaseAsset* DialogueAsset);

	UFUNCTION(BlueprintCallable)
	class UDialogueEditorSettings* GetDialogueEditorSettings();

	//提供接口给脚本用于触发编辑器的Stop命令
	UFUNCTION(BlueprintCallable)
	void EditorStop();

	UFUNCTION(BlueprintImplementableEvent)
	float GetDialogueLineStartTime(UDialogueBaseAsset* DialogueAsset, int EpisodeID, int DialogueLineIndex);

	DECLARE_EVENT_OneParam(UDialogueEditorManager, FOnDialoguePlayerSetStateEvent, bool);
	FOnDialoguePlayerSetStateEvent& OnDialoguePlayerSetState() { return OnDialoguePlayerSetStateEvent; }

	UFUNCTION(BlueprintImplementableEvent)
	void SetOneActorCameraParams(UDialogueEntity* PerformerEntity, UDialogueCamera* CameraEntity, bool IsPlayer, int32 CameraType);

	UFUNCTION(BlueprintImplementableEvent)
	void SetActorNearCameraParams(UDialogueEntity* PerformerEntity1, UDialogueEntity* PerformerEntity2, UDialogueCamera* CameraEntity, bool bIsPlayer);

	UFUNCTION(BlueprintImplementableEvent)
	void SetActorMediumCameraParams(UDialogueEntity* PerformerEntity1, UDialogueEntity* PerformerEntity2, UDialogueCamera* CameraEntity, bool bIsPlayer);

	UFUNCTION(BlueprintImplementableEvent)
	void SetViewPositionCameraParams(UDialogueEntity* CameraEntity, UDialogueActionBase* CameraSection, const FVector& Location, const FRotator& Rotation, const float& FOV);
    
#pragma region DialogueAssetAssist
	UFUNCTION(BlueprintImplementableEvent)
	AActor* GetEntityActor(const FString& EntityName);
#pragma endregion

#pragma region ExportToLua
	TSharedPtr<struct FScopedSlowTask> BatchAssistScopeTask;
	UFUNCTION(BlueprintCallable)
	void BeginBatch(int Count, FText Text);
	UFUNCTION(BlueprintCallable)
	void AddTaskAmount(int32 TaskAmount) const;
	UFUNCTION(BlueprintCallable)
	void IncreaseProgress();
	UFUNCTION(BlueprintCallable)
	void EndBatch();
	
	//DialogueAsset导为lua文件
	UFUNCTION(BlueprintCallable)
	bool ExportAsLuaTable(UDialogueBaseAsset* DialogueAsset, bool bInUseCommandlet = false);
	
	UFUNCTION(BlueprintCallable)
	bool ExportIfNeedWhenInitialize(UDialogueBaseAsset* DialogueAsset);

	UFUNCTION(BlueprintCallable)
	void GenerateDialogueAndExportAsLuaTable(UDialogueAsset* DialogueAsset);
	
	UFUNCTION(BlueprintImplementableEvent)
	FString ConvertJsonToLuaTable(const FString& JsonStr, const FString& AssetName);

	FString ConvertJsonToLuaFile(TSharedPtr<class FJsonObject> JsonObj, const FString& LuaFileName);

	UFUNCTION(BlueprintImplementableEvent)
	bool ForceExportLuaTable(UDialogueBaseAsset* DialogueAsset = nullptr);
	
	UFUNCTION(BlueprintCallable)
	void ExecuteGenerationCommand();

#pragma endregion

#pragma region DialogueAsset
	UFUNCTION(BlueprintImplementableEvent)
	bool ImportDialogue(UDialogueAsset* DialogueAsset, bool IsInitial=false);

	UFUNCTION(BlueprintImplementableEvent)
	bool ExportDialogue(UDialogueAsset* DialogueAsset, bool bHideExportConfirmWnd = false);

	UFUNCTION(BlueprintImplementableEvent)
	bool ExportOptionText(UDialogueAsset* DialogueAsset, bool bHideExportConfirmWnd = false);

	UFUNCTION(BlueprintImplementableEvent)
	bool GenerateDialogue(UDialogueAsset* DialogueAsset);

	UFUNCTION(BlueprintImplementableEvent)
	void RefreshOnChangeTemplate(UDialogueAsset* DialogueAsset);

	//从模板里面同步信息到对话资产中
	UFUNCTION(BlueprintImplementableEvent)
	void SyncTemplate(UDialogueAsset* DialogueAsset);

	//将对话资产的站位信息保存到模板中
	UFUNCTION(BlueprintImplementableEvent)
	void SaveAsTemplate(UDialogueAsset* DialogueAsset, UDialogueTemplateAsset* Template);

	UFUNCTION(BlueprintCallable)
	void SaveAsset(UDialogueAsset* DialogueAsset);

	UFUNCTION(BlueprintCallable)
	void ExportJson(UDialogueAsset* DialogueAsset, const FString& FileName);

	UFUNCTION(BlueprintImplementableEvent)
	void CheckInValidAsset(class UDialogueAsset* DialogueAsset);

	//锁定了一个相机
	UFUNCTION(BlueprintImplementableEvent)
	void OnLockCamera(class UDialogueCamera* DialogueEntity);

	UFUNCTION(BlueprintImplementableEvent)
	void AddEditorPostProcess(bool Add);


	//获取对话资产挂接的外界锚点Transform
	UFUNCTION(BlueprintImplementableEvent)
	FTransform GetAssetAnchorTransform(class UDialogueAsset* DialogueAsset);

	//当开始播放一个Episode的时候，需要更新Timeline区域，这要求从lua回调到编辑器
	UFUNCTION()
	void SetCurrentEpisodeID(int EpisodeID, bool bForceRefreshUI);

	UFUNCTION(BlueprintCallable)
	int GetCurrentEpisodeID();

	//操作曲线路径时，添加新点的同时，吸附上去，这里需要通知编辑器选中这个CameraComponent
	UFUNCTION()
	void SetSelectCameraComponent(class UCameraComponent* CameraComponent);

	//获取当前正在编辑的子相机，如果没有，返回nullptr
	UFUNCTION()
	UCameraComponent* GetSelectCameraComponent();

	//返回当前锁定的相机，可以返回nullptr
	UFUNCTION(BlueprintCallable)
	UDialogueCamera* GetCurrentLockCameraEntity();

	//转为导出的资源路径
	UFUNCTION(BlueprintCallable)
	FString GetUClassPath(UClass* ClassPtr);

	//把相机的位置、旋转同步给视口
	UFUNCTION(BlueprintCallable)
	void SetViewportLocationRotation(class ACameraActor* CameraActor);

	//获取编辑器中选中的Actor
	UFUNCTION()
	AActor*		GetSelectActor();

	//查找指定类型的资产，这是为了将策划配置的文件名转为资源引用
	//ExactName：是否精确匹配资源名，如果为true，要求资产名和AssetName完全相等
	//如果为false，则要求资源名Contains(AssetName)即可
	UFUNCTION(BlueprintCallable)
	class UObject* GetAsset(UClass* AssetClass, const FString& AssetName, bool ExactName=true);

	UFUNCTION(BlueprintCallable)
	UObject* GetSoundAsset(UClass* AssetClass, const FString& SoundAssetName, bool ExactName = true);

	UFUNCTION(BlueprintCallable)
	void OnAddNewAutoCameraTrack();
	
	//查找指定类型的所有资产，编辑器辅助函数
	UFUNCTION()
	TArray<UObject*> GetAllAsset(UClass* AssetClass);

	UFUNCTION()
	void ShowMessageBox(const FString& msg);

	UFUNCTION(BlueprintCallable)
	void ShowMessageBoxForce(const FString& msg);

	UFUNCTION(BlueprintCallable)
	void PushNotification(const FString& Msg, float Duration = 2.0f);
	
	//获取脚本扩展的定制命令
	UFUNCTION(BlueprintImplementableEvent)
	void GetEditorCommands(TArray<FDialogueEditorCommand>& Commands);

	UFUNCTION(BlueprintImplementableEvent)
	bool CallEditorCommand(const FString& CommandFunction);

	UFUNCTION(BlueprintImplementableEvent)
	bool CallEditorCommandWithDialogueAsset(const FString& CommandFunctionName, const TArray<class UDialogueAsset*>& Asset);

	//从近似资产里面拷贝数据
	UFUNCTION(BlueprintImplementableEvent)
	void CopyDataFromSymmetryAsset(class UDialogueBaseAsset* From, class UDialogueBaseAsset* To);

	//资产修改后，可能需要做些后处理
	UFUNCTION(BlueprintImplementableEvent)
	void OnAssetPostEdit(class UDialogueBaseAsset* DialogueAsset, const FString& PropertyName = TEXT(""));

	UFUNCTION(BlueprintImplementableEvent)
	void UpdateRootTransform();

	UFUNCTION(BlueprintCallable)
	void MarkModify(class UObject* Obj);

	//在Actor处上下Trace ,然后把Actor放置在地面Z坐标
	UFUNCTION(BlueprintImplementableEvent)
	void PutActorOnGround(AActor* InActor);

	UFUNCTION(BlueprintImplementableEvent)
	TMap<FString, FString> GetAutoCameraTableData(int32 CameraType, int32 Type);

	UFUNCTION(BlueprintImplementableEvent)
	FString GetDialogueSequenceTableData(int32 ID);
	
	UFUNCTION(BlueprintImplementableEvent)
	FString GetDialogueInitialTemplateName(const FString& AssetName);
	
	UFUNCTION()
	bool CompareSplineCurves(const FSplineCurves& a, const FSplineCurves& b);

	UFUNCTION()
	bool CompareVector(const FVector& a, const FVector& b);

	UFUNCTION(BlueprintImplementableEvent)
	float GetDialogueRunningTime();

	//后续增加Back Forward功能时，实现这两个接口
	UFUNCTION(BlueprintImplementableEvent)
	void ForwardStep(float DeltaTime);

	UFUNCTION(BlueprintImplementableEvent)
	void BackStep(float DeltaTime);

#pragma  endregion
protected:
	FOnDialoguePlayerSetStateEvent OnDialoguePlayerSetStateEvent;

public:
	TWeakPtr<class FDialogueEditor> DialogueEditor;

#pragma region Root
public:
	UFUNCTION(BlueprintCallable)
	void AddObjectToRoot(UObject* InObject);

	UFUNCTION(BlueprintCallable)
	void RemoveObjectFromRoot(UObject* InObject);

#pragma endregion Root

	virtual FString GetLuaFilePath_Implementation() const override;
	
	UFUNCTION()
	void ResetRespawnActorsCheck();

	UFUNCTION()
	void ReSpawnActors();

	UFUNCTION(BlueprintCallable)
	float GetPlayRate();

	UFUNCTION(BlueprintCallable)
	UWorld* GetDialogueWorld();

	UFUNCTION(BlueprintImplementableEvent)
	UUserWidget* ShowUIInEditor();

	UFUNCTION(BlueprintImplementableEvent)
	void ActivateDialogue(UDialogueBaseAsset* DialogueData, int StartEpisode, float StartTime);

	UFUNCTION(BlueprintImplementableEvent)
	void SetDialoguePause(bool Pause);

	UFUNCTION(BlueprintImplementableEvent)
	void GetDialogueEditorOnlyInfo(const FString& DialogueName, TArray<FString>& Data, FString& EditorOnlyTag);

	UFUNCTION(BlueprintImplementableEvent)
	void GetDialogueAssetData(TMap<FString, FDialogueAssetData>& Data);

    UFUNCTION(BlueprintCallable)
    void GetCachedPOVInfo(float& LocX, float& LocY, float& LocZ, float& Pitch, float& Yaw, float& Roll, float& FOV);

	UFUNCTION(BlueprintCallable)
	void ShowCheckResultBox(FString ErrorMsg, FString WarningMsg);

#pragma region Section
	//编辑器修改Section前边界检测，返回实际合法的StartTime
	UFUNCTION(BlueprintImplementableEvent)
	float OnSectionChange_DragStartCheck(class UDialogueAsset* DialogueAsset, class UDialogueActionBase* Section, float NewStartTime);

	//编辑器修改Section前边界结束，通知到lua层
	UFUNCTION(BlueprintImplementableEvent)
	void OnSectionChange_DragStart(class UDialogueAsset* DialogueAsset, class UDialogueActionBase* Section, float NewStartTime);

	//编辑器修改Section后边界检测，返回实际合法的EndTime
	UFUNCTION(BlueprintImplementableEvent)
	float OnSectionChange_DragEndCheck(class UDialogueAsset* DialogueAsset, class UDialogueActionBase* Section, float NewEndTime);

	//编辑器修改Section后边界结束，通知到lua层
	UFUNCTION(BlueprintImplementableEvent)
	void OnSectionChange_DragEnd(class UDialogueAsset* DialogueAsset, class UDialogueActionBase* Section, float NewEndTime);

	//编辑器拖拽修改Section的StartTime，返回实际合法的StartTime
	UFUNCTION(BlueprintImplementableEvent)
	float OnSectionChange_DragMoveCheck(class UDialogueAsset* DialogueAsset, class UDialogueActionBase* Section, float NewStartTime);

	//编辑器拖拽修改Section的StartTime，通知到lua层
	UFUNCTION(BlueprintImplementableEvent)
	float OnSectionChange_DragMove(class UDialogueAsset* DialogueAsset, class UDialogueActionBase* Section, float DeltaStartTime);

	//编辑器删除一个Section，通知到lua层
	UFUNCTION(BlueprintImplementableEvent)
	float OnSectionChange_DeleteSection(class UDialogueAsset* DialogueAsset, class UDialogueActionBase* Section);

	//编辑器Add一个Section，通知到lua层
	UFUNCTION(BlueprintImplementableEvent)
	float OnSectionChange_AddSection(class UDialogueAsset* DialogueAsset, class UDialogueActionBase* Section);

	//将Section数据同步回台本
	UFUNCTION(BlueprintImplementableEvent)
	void SyncSectionDataToLine(class UDialogueAsset* DialogueAsset);

	//获取DialogueAsset里面关联了Line GUID的所有Sections
	//LineGUID使用uint32类型会有报错error : Type 'uint32' is not supported by blueprint.
	UFUNCTION(BlueprintImplementableEvent)
	TArray<UDialogueActionBase*>	GetLinkedSections(class UDialogueAsset* DialogueAsset, double LineGUID);

	//分镜轨道使用Bind的方式添加机位Section，在lua代码中设置TargetCamera
	UFUNCTION(BlueprintImplementableEvent)
	void OnAddCameraCutSectionFromTrack(UDialogueActionBase* Section, const FString& CameraName);

	// 根据当前的台本自动为分镜选择对应的机位
	UFUNCTION(BlueprintImplementableEvent)
	void SetCameraCutTargetCameraByDialogue(UDialogueActionBase* CameraCutSection, UDialogueActionBase* DialogueSection);

	// 根据当前的台本自动为分镜选择对应的机位
	UFUNCTION(BlueprintImplementableEvent)
	void SetAllAutoCameraCutTargetCamera(const TArray<UDialogueActionBase*>& CameraCuts, const TArray<UDialogueActionBase*>& Dialogues);

	// 根据当前的台本自动为分镜选择对应的机位(单人及3人以上)
	UFUNCTION(BlueprintImplementableEvent)
	void GetAndSetAllAutoCameraCutTargetCameraNames(const TArray<UDialogueActionBase*>& CameraCuts, const TArray<UDialogueActionBase*>& Dialogues, TArray<FString>& CameraNames);

	// 根据当前的台本自动生成lookat
	UFUNCTION(BlueprintImplementableEvent)
	void SetAllLookAtSectionAuto(const TArray<UDialogueActionBase*>& LookAtSections);
	
	// 自动设置lookat
	UFUNCTION(BlueprintImplementableEvent)
	void SetLookAtSectionTarget(UDialogueActionBase* LookAtSection, const FString& TargetName);
	
	UFUNCTION(BlueprintImplementableEvent)
	void SetAllAutoLookAtSection(const TArray<UDialogueActionBase*>& LookAts, const TArray<UDialogueActionBase*>& Dialogues, const FString& ActorName, TArray<int32>& EmptyTargetSection);

	UFUNCTION(BlueprintImplementableEvent)
	float GetAnimationSectionAutoDuration(class UDialogueActionBase* Action);
    
    UFUNCTION(BlueprintImplementableEvent)
    void CheckSameWithAnimLibBlend(UDialogueActionBase* Action); 
    
    UFUNCTION(BlueprintImplementableEvent)
    bool TrySetAnimLibBlendParams(UDialogueActionBase* Action);

    UFUNCTION(BlueprintImplementableEvent)
    float Get3CMoveSectionDuration(class UDialogueActionBase* Action);

    UFUNCTION(BlueprintImplementableEvent)
    float Get3CTurnSectionDuration(class UDialogueActionBase* Action);

	UFUNCTION(BlueprintImplementableEvent)
	FString GetAnimIDByActionSection(class UDialogueActionBase* Action);

	UFUNCTION(BlueprintImplementableEvent)
	FString GetAnimIDByAppearanceID(int32 AppearanceID);
	
	UFUNCTION(BlueprintCallable)
	class UDialogueActionBase* NewLookAtSection(class UDialogueAsset* DialogueAsset);

	UFUNCTION(BlueprintCallable)
	class UDialogueActionBase* NewCameraCutSection(class UDialogueAsset* DialogueAsset);

#pragma endregion
    
	UFUNCTION(BlueprintImplementableEvent)
	void OnActionNoticeToSectionInstance(int32 EventID);
	
	UFUNCTION(BlueprintCallable)
	FString SwitchToSequencerCamera(ULevelSequencePlayer* LevelSequencePlayer);
	
#pragma region Scene
	UFUNCTION(BlueprintCallable)
	UWorld* GetBigWorld() { return BigWorld.Get();}

	//原来UI被生成在了大世界UWorld里面，需要改到小World里面
	// UFUNCTION(BlueprintCallable)
	// UWorld* GetSmallWorld();

	// 自定义创建actor到world的接口，不影响当前world资源
	UFUNCTION(BlueprintCallable)
	AActor* SpawnTransientActorToWorld(UWorld* World, UClass* InClass, const FTransform& SpawnTransform);

	//编辑器移动Actor后，回调到lua层
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
	void OnActorMoved(UDialogueBaseAsset* DialogueAsset, AActor* Actor);
#pragma endregion 
public:
	UPROPERTY(EditAnywhere)
	bool bUseCommandlet = false;

private:
	UPROPERTY()
	float RespawnActorsChecker= 0.0f;

	UPROPERTY()
	TArray<UClass*> AlreadyScanedClass;

	TWeakObjectPtr<class UWorld> BigWorld;

	TSharedPtr<SWindow> WarningWindow;
};
