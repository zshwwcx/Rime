// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "Misc/NotifyHook.h"
/**
 * 
 */
class  FKGSLEdDialogueAnimationLayout : public IPropertyTypeCustomization, public FNotifyHook
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance();
	virtual ~FKGSLEdDialogueAnimationLayout();
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> PropertyHandle, FDetailWidgetRow& HeaderRow,
	                             IPropertyTypeCustomizationUtils& CustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle, IDetailChildrenBuilder& ChildBuilder,
	                               IPropertyTypeCustomizationUtils& CustomizationUtils) override;

	// FNotifyHook
	virtual void NotifyPreChange( FProperty* PropertyAboutToChange ) override;
	virtual void NotifyPostChange( const FPropertyChangedEvent& PropertyChangedEvent, FProperty* PropertyThatChanged ) override;
private:
	void ConstructStructureDetailView(TSharedPtr<IPropertyHandle> AnimProperty);
private:
	TSharedPtr<class IStructureDetailsView> StructureDetailsView;
	TSharedPtr<class FStructOnScope> CurrentStructScope;
	TSharedPtr<IPropertyHandle> AnimProperty;
};

