// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "DialogueEditor/KGStoryLineEditorSubSystem.h"
#include "Templates/SharedPointer.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"

class SVerticalBox;
class SBox;
class STextBlock;

/**
 * 
 */
class FKGSLEdDialogueEpisodeDetails : public IPropertyTypeCustomization
                                      , public INotifyOnKGSLDataChanged
{
public:
	FKGSLEdDialogueEpisodeDetails();
    virtual ~FKGSLEdDialogueEpisodeDetails() override;
    static TSharedRef<IPropertyTypeCustomization> MakeInstance();

    // IPropertyTypeCustomization interface
    virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow,
                                 IPropertyTypeCustomizationUtils& CustomizationUtils);
    virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder,
                                   IPropertyTypeCustomizationUtils& CustomizationUtils);
    // End of IPropertyTypeCustomization interface


    //~BEGIN: INotifyOnKGSLDataChanged
    virtual void PreChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType) override;
    virtual void PostChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType) override;
    //~ END: of INotifyOnKGSLDataChanged
    
    UDialogueAsset* GetDialogueAsset() const;
	UKGSLDialogueEpisode* GetEpisode() const;

	//获取台本对应的FDialogueEpisode
	struct FDialogueEpisode* GetDialogueEpisode() const;

private:
    FReply OpenDialogueLinesEditor() const;
    void RebuildLinesBox() const;
    void RebuildOptionsBox() const;
    void Rebuild() const;
    void OnEpisodeChanged() const;
    static TSharedPtr<IPropertyHandle> FindRealEpisodeProperty(TSharedPtr<IPropertyHandle> InPropertyHandle);

	void OnSelectionChanged(TSharedPtr<FString> Selection, ESelectInfo::Type SelectInfo);
	TSharedRef<SWidget> OnGenerateWidget(TSharedPtr<FString> InItem);
	TSharedPtr<FString> GetSelectedItem() const;
	FText GetSelectedValue() const;

	double OnGetTimeLimit() const;
	void OnTimeLimitCommitted(double NewValue, ETextCommit::Type CommitInfo);

	void OnTimeOutDefaultChoicesChanged(TSharedPtr<FString> Selection, ESelectInfo::Type SelectInfo);
	TSharedRef<SWidget> OnGenerateTimeOutDefaultChoicesWidget(TSharedPtr<FString> InItem);
	TSharedPtr<FString> GetTimeOutDefaultChoicesSelectedItem() const;
	FText GetTimeOutDefaultChoicesSelectedValue() const;

private:
    TSharedPtr<IPropertyHandle> PropertyHandle;
    TSharedPtr<IPropertyHandle> PropertyOptionsHandle;

    TSharedPtr<SBox> PropertyLineContent;
    TSharedPtr<SVerticalBox> LineBoxes;

    TSharedPtr<SBox> PropertyOptionContent;
    TSharedPtr<SVerticalBox> OptionBoxes;
    TSharedPtr<STextBlock> TextBlockEpisode;

    FDelegateHandle EpisodeChangedHandle;

	const TArray<TSharedPtr<FString>> OptionTypes = { MakeShared<FString>(TEXT("普通选项")), MakeShared<FString>(TEXT("浮动选项")) };

	TArray<TSharedPtr<FString>> TimeOutDefaultChoices;
};
