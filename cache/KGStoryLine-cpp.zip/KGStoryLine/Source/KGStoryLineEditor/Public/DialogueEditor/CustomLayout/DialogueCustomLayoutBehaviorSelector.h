#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Input/SComboBox.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"



class FDetailWidgetRow;
class KGSTORYLINEEDITOR_API FDialogueBehaviorSelectorLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FDialogueBehaviorSelectorLayout());
	}

	// IPropertyTypeCustomization interface
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils);
	// End of IPropertyTypeCustomization interface

	FBehaviorActorSelector* GetRawStructData(TSharedRef<IPropertyHandle> InPropertyHandle);

	void SetName(FName InName);

	bool IsSelectorValid();

private:
	TSharedPtr<IPropertyHandle> PropertyHandle;
};