// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "IDetailCustomization.h"
#include "IPropertyTypeCustomization.h"
/**
 * 
 */
class FKGSLEdDialogueLineLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance();
 virtual void CustomizeHeader(TSharedRef<IPropertyHandle> PropertyHandle, FDetailWidgetRow& HeaderRow,
                              IPropertyTypeCustomizationUtils& CustomizationUtils) override;

 virtual void CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle, IDetailChildrenBuilder& ChildBuilder,
                                IPropertyTypeCustomizationUtils& CustomizationUtils) override;
private:
	void ExtractExtensionData(IDetailChildrenBuilder& ChildBuilder, TMap<FName, class IDetailGroup*>& MapGroups, 
	TSharedPtr<IPropertyHandle> HandleExtension);
	static TSharedPtr<IPropertyHandle> FindRealExtensionProperty(TSharedPtr<IPropertyHandle> HandleExtension);
};


class FKGSLEdCustomLayoutDialogueLine : public IDetailCustomization
{
public:
	static TSharedRef<IDetailCustomization> MakeInstance();
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;
};