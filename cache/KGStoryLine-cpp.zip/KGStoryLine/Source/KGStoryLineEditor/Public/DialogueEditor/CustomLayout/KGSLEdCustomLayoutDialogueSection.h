#pragma once

#include "CoreMinimal.h"
#include "IDetailCustomization.h"

class KGSTORYLINEEDITOR_API FKGSLEdCustomLayoutDialogueSection : public IDetailCustomization
{
public:
	static TSharedRef<IDetailCustomization> MakeInstance();
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;
private:
	static class UDialogueAsset* GetDialogueAsset(class UDialogueDialogue* Section);
};