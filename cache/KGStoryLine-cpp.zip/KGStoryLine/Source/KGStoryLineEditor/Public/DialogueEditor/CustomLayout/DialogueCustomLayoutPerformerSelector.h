#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Input/SComboBox.h"

#include "DialogueEditor/Dialogue/DialogueAsset.h"



class FDetailWidgetRow;
class KGSTORYLINEEDITOR_API FDialoguePerformerSelectorLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FDialoguePerformerSelectorLayout());
	}

	// IPropertyTypeCustomization interface
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils);
	// End of IPropertyTypeCustomization interface

	FDialoguePerformerSelector* GetRawStructData(TSharedRef<IPropertyHandle> InPropertyHandle);

	void SetPerformerName(FName InName);

	bool IsSelectorValid();

private:
	TSharedPtr<IPropertyHandle> PropertyHandle;

	TSharedPtr<IPropertyUtilities> PropertyUtilities;
};