#pragma once
#include "CoreMinimal.h"
#include "UObject/WeakObjectPtr.h"

// 资产创建指引窗口
class FKGSLAssetCreateGuide : public TSharedFromThis<FKGSLAssetCreateGuide>
{
public:
	FKGSLAssetCreateGuide() {}
	~FKGSLAssetCreateGuide() {}
	
	void OpenGuideWindow(bool bAsModal = false);
	void CloseGuideWindow();
	void SetStoryLineAsset(UObject* AssetObj);

	bool GetParameters(FString& OutAssetName, FString& OutStoryLineID, FString& OutTemplateName) const;
protected:
	class FReply OnCreateBtnClicked();
	void OnGuideWindowClosed(const TSharedRef<class SWindow>& Window);

private:
	// 每次打开,获取最新的模板信息
	void GetAllTemplates();

	// 套用数据修改资产
	void ApplyOnAsset(const FString& AssetName, const int32 InStoryLineID, const FString& InTemplateName);

protected:
	// 主窗口
	TSharedPtr<class SWindow> GuideWindow;

	// 用于填写资产名
	TSharedPtr<class SEditableTextBox> AssetNameText;

	// 用于填写表格ID
	TSharedPtr<class SEditableTextBox> StoryLineIDText;

	// 选育选择模板
	TSharedPtr<class STextComboBox> TemplateComboBox;

private:
	// 所有模板的名称和对应模板路径
	TMap<FString, FString> TemplateName2Path;
	
	// 选项列表
	TArray<TSharedPtr<FString>> TemplateNames;
	
	// 创建中的资产
	TWeakObjectPtr<UObject> InCreatingAssetObj;

	FString ValidAssetName;
	FString StoryLineID;
	FString TemplateName;
	
	// 是否成功创建
	bool bCreateSuccess = false;
};
