#pragma once

#include "CoreMinimal.h"
#include "UObject/WeakObjectPtr.h"

class FDialogueAssetBrowser : public TSharedFromThis<FDialogueAssetBrowser>
{
public:
	FDialogueAssetBrowser();
	~FDialogueAssetBrowser();

	void OpenDialogueAssetBrowser();

	void CloseDialogueAssetListWindow();

	void OnOpenDialogueByDoubleClick();

	void OnCreateDialogueByDoubleClick();

	void GetDialogueAssetList(TArray<TSharedPtr<class IDialogueAssetViewItem>>& OutAssetViewItems);

	void LoadAllDialogueBPClasses();

	TWeakObjectPtr<UObject> GetDialogueRootPackage();

	TSharedPtr<class SWindow> DialogueAssetBrowserWindow;

	TSharedPtr<class SDialogueAssetBrowser> DialogueAssetBrowse;

	TWeakObjectPtr<UObject> DialogueRootPackage = nullptr;

	TArray<TWeakObjectPtr<UClass>> DialogueBPClasses;
};
