#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "UObject/NoExportTypes.h"



class KGSTORYLINEEDITOR_API FDialogueEditorPreviewProxy
{
#pragma region Important
public:
	FDialogueEditorPreviewProxy(class UDialogueBaseAsset* InAsset, const TSharedPtr<class FDialogueEditor>& InEditor);

	virtual ~FDialogueEditorPreviewProxy();

	float GetCurrentTime(int32 EpisodeID);

	class UDialogueBaseAsset* GetPreviewAsset() const;
	TWeakPtr<class FDialogueEditor> GetCachedEditor() {
		return CachedEditor;}
private:
	void OnPreviewEnd();

private:
	// 资源文件
	TWeakObjectPtr<class UDialogueBaseAsset> CachedAsset;

	// 编辑器
	TWeakPtr<class FDialogueEditor> CachedEditor;

	void OnSectionInstanceNoticeLua(UDialogueActionBase* DialogueActionSection, int32 Param);

#pragma endregion Important



#pragma region Preview
public:
	class UDialogueEditorManager* GetDialogueEditorManager();

	void Play(int StartEpisode, float StartTime);

	bool IsPlaying() const;

	void Pause();

	bool IsPaused() const;

	void Resume();

	void Stop();

	bool IsStopped() const;

	void ResetWorld();

	void ForwardStep();
	
	void BackwardStep();


private:
	// 正在播放
	bool bPlaying = false;

	// 正在暂停
	bool bPause = false;

#pragma endregion Preview


};