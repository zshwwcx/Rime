#pragma once

#include "AdvancedPreviewScene.h"
#include "Engine/GameViewportClient.h"

class KGSTORYLINEEDITOR_API FDialogueEditorSceneProxy : public FTickableEditorObject, FGCObject, public TSharedFromThis<FDialogueEditorSceneProxy>
{
public:
	FDialogueEditorSceneProxy(TSharedPtr<class FDialogueEditor> InEditor);

	virtual ~FDialogueEditorSceneProxy() override;

	void CreateDialogueEditorManager();

	void SpawnDialogueActor(class UDialogueActor* DialogueActor) const;
	void RemoveDialogueActor(class UDialogueActor* DialogueActorInfo) const;

	void SpawnDialogueSplineActor(class UDialogueEntity* DialogueEntity) const;
	void RemoveDialogueSplineActor(class UDialogueEntity* DialogueEntity) const;

	void SpawnRoutePointActor(class UDialogueEntity* DialogueEntity) const;
	void RemoveRoutePoint(class UDialogueEntity* RoutePoint) const;

	void SpawnCamera(class UDialogueCamera* CameraInfo) const;
	void RemoveCamera(class UDialogueCamera* CameraInfo) const;

	void SpawnNewEntity(class UDialogueEntity* EntityInfo) const;
	void RemoveNewEntity(class UDialogueEntity* EntityInfo) const;

	//创建过程完全由异步的脚本创建，创建完成后回调本接口
	void OnSpawnedEntity(const FString& EntityName, AActor* EntityActor) const;

	// 初始化预览世界
	void SpawnPlayerController();
    void SpawnGossipBubbleManager();
	void InitializeCameraManager() const;
	void DestroyPlayerController();
    void DestroyGossipBubbleManager();

	// 重置预览世界
	void ResetPreviewWorld();

	// 创建预览对象
	void SpawnPreviewActors();

	// 销毁预览对象
	void DestroyPreviewActors(bool NeedDeleteFolder = false) const;

	void DestroyDialogueActors() const;

	class FCameraShakePreviewer* GetOrCreateShakePreviewer();
	void DestroyShakePreviewer();

	virtual void Tick(float DeltaTime) override;

	virtual bool IsTickable() const override;

	virtual TStatId GetStatId() const override;
	void TickWorld(float DeltaSeconds) const;

	void OnActorMoved(AActor* InActor) const;

	void RefreshAppearanceTable() const;

	void OnPreviewStateChanged(bool InPlaying, bool InPause) const;

	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	void AddDialogueWidget();
	void RemoveDialogueWidget();

	virtual FString GetReferencerName() const override
	{
		return TEXT("FDialogueEditorSceneProxy");
	}

	class UDialogueEditorManager* GetDialogueEditorManager() const;

	void DestroyPreviewScene();

	void SetPreviewActorsActive(bool IsActive);
	
	UWorld* GetWorld() const;

	class UCameraShakeBase* AddCameraShake(TSubclassOf<class UCameraShakeBase> ShakeClass, class UCameraShakeSourceComponent* ShakeSourceComponent);

	void AddCameraFrameRadio(bool InBVertical);
	void RemoveCameraFrameRadio();
	
	class FCameraShakePreviewer* CameraShakePreviewer = nullptr;
	
	bool IsInRadioPreviewer() const;
	bool IsFrameRadioVertical() const;

	TWeakObjectPtr<APlayerController> PlayerController;
    TWeakObjectPtr<class UDialogueGossipBubbleManager> GossipBubbleManager;
private:
	TWeakPtr<class FDialogueEditor> CachedEditor = nullptr;

	FFolder ActorFolder;
	FName ActorFolderName;
	TWeakObjectPtr<class UDialogueEditorManager> DialogueEditorManager;
	bool BFrameRadio = false;
	bool BVertical = false;
	TWeakObjectPtr<UUserWidget> DialogueWidget;
};
