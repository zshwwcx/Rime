#pragma once

#include "CoreMinimal.h"
#include "WorkflowOrientedApp/ApplicationMode.h"
#include "WorkflowOrientedApp/WorkflowTabManager.h"



class KGSTORYLINEEDITOR_API FDialogueEditorMode : public FApplicationMode
{
public:
	FDialogueEditorMode(const FName& InModeName, TSharedRef<class FDialogueEditor> InEditor);

	virtual ~FDialogueEditorMode() {}

	virtual void RegisterTabFactories(TSharedPtr<FTabManager> InTabManager) final override;

	virtual void AddTabFactory(FCreateWorkflowTabFactory FactoryCreator) final override;

	virtual void RemoveTabFactory(FName TabFactoryID) final override;

	virtual void CreateModeTabs(const TSharedRef<class FDialogueEditor> InEditor, FWorkflowAllowedTabSet& OutTabFactories) = 0;

protected:
	TWeakPtr<class FDialogueEditor> CachedEditor;

	FWorkflowAllowedTabSet TabFactories;

};


class KGSTORYLINEEDITOR_API FDialogueEditorMode_Template : public FDialogueEditorMode
{
public:
	FDialogueEditorMode_Template(TSharedRef<class FDialogueEditor> InEditor);

	virtual void CreateModeTabs(const TSharedRef<class FDialogueEditor> InEditor, FWorkflowAllowedTabSet& OutTabFactories) override;

};


class KGSTORYLINEEDITOR_API FDialogueEditorMode_Main : public FDialogueEditorMode
{
public:
	FDialogueEditorMode_Main(TSharedRef<class FDialogueEditor> InEditor);

	virtual void CreateModeTabs(const TSharedRef<class FDialogueEditor> InEditor, FWorkflowAllowedTabSet& OutTabFactories) override;

};