#pragma once

#include "Input/Reply.h"
#include "Styling/SlateBrush.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"



class KGSTORYLINEEDITOR_API FDialogueEditorToolbar : public TSharedFromThis<FDialogueEditorToolbar>
{
public:
	// 建立工具栏
	void SetupToolbar(TSharedPtr<FExtender> Extender, TSharedPtr<class FDialogueEditor> InEditor);

	// 添加时间轴工具栏
	void AddTimelineToolbar(TSharedPtr<FExtender> Extender);

private:
	// 填充时间轴工具栏
	void FillTimelineModeToolbar(FToolBarBuilder& ToolbarBuilder);

	// 数据导出菜单栏
	TSharedRef<SWidget> GenerateDataProcessMenu();

	FText GetPlayText() const;
	FText GetBigworldPlayText() const;

	FText GetPlayToolTip() const;

	FSlateIcon GetPlayIcon() const;

private:
	TWeakPtr<class FDialogueEditor> CachedEditor;

	FSlateIcon PlayIcon;
	FSlateIcon PauseIcon;
};
