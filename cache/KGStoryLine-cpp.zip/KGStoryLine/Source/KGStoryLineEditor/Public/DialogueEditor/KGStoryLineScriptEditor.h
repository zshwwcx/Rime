#pragma once
#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "EditorUndoClient.h"
#include "Toolkits/AssetEditorToolkit.h"
#include "DataTableEditorUtils.h"
#include "DialogueEditor/KGStoryLineEditorSubSystem.h"
#include "Kismet2/StructureEditorUtils.h"
#include "Widgets/Views/SListView.h"

class SKGSLScriptEdListViewSettings;
DECLARE_DELEGATE_OneParam(FOnKGSLScriptLineHighlighted, FName /*Row name*/);


class FKGStoryLineScriptEditor : public FAssetEditorToolkit
	, public FEditorUndoClient
	, public INotifyOnKGSLDataChanged
{
	friend class SKGStoryLineScriptListViewRow;
public:
	FKGStoryLineScriptEditor();
	KGSTORYLINEEDITOR_API virtual ~FKGStoryLineScriptEditor();
	KGSTORYLINEEDITOR_API virtual void RegisterTabSpawners(const TSharedRef<FTabManager>& TabManager) override;
	KGSTORYLINEEDITOR_API virtual void UnregisterTabSpawners(const TSharedRef<FTabManager>& TabManager) override;

	KGSTORYLINEEDITOR_API void InitScriptEditor(const EToolkitMode::Type Mode, const TSharedPtr<IToolkitHost>& 
	InitToolkitHost, UDialogueAsset* DialogueAsset, int32 EpisodeID, UStruct* StructClass);

	/** IToolkit interface */
	KGSTORYLINEEDITOR_API virtual FName GetToolkitFName() const override;
	KGSTORYLINEEDITOR_API virtual FText GetBaseToolkitName() const override;
	KGSTORYLINEEDITOR_API virtual FString GetWorldCentricTabPrefix() const override;
	KGSTORYLINEEDITOR_API virtual FLinearColor GetWorldCentricTabColorScale() const override;
	KGSTORYLINEEDITOR_API virtual void OnClose() override;
	KGSTORYLINEEDITOR_API virtual void SaveAsset_Execute() override;
	
	// FEditorUndoClient
	KGSTORYLINEEDITOR_API virtual void PostUndo(bool bSuccess) override;
	KGSTORYLINEEDITOR_API virtual void PostRedo(bool bSuccess) override;
	void HandleUndoRedo();

	// INotifyOnStructChanged
	virtual void PreChange(const class UUserDefinedStruct* Struct, FStructureEditorUtils::EStructureEditorChangeInfo Info);
	virtual void PostChange(const class UUserDefinedStruct* Struct, FStructureEditorUtils::EStructureEditorChangeInfo Info);

	//~ BEGIN: INotifyOnKGSLDataChanged
	virtual void PreChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo Info) override;
	void HandleFieldOrderChanged();
	virtual void PostChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo Info) override;
	virtual void SelectionChange(const UDialogueAsset* Changed, int32 EpisodeID, FName RowName);
	//~ END: INotifyOnKGSLDataChanged
	
	class UDialogueAsset* GetEditingAsset() const;
	void HandlePostChange();
	
	bool CanEditLines() const;
	bool CanEditScript() const;
	bool CanPaste() const;
	void CopySelectedLine() const;
	void Paste();
	void PasteOnSelectedLine();
	void PasteFromClipboard();
	void DuplicateSelectedLine();
	void DeleteSelectedLine();

	void SelectRow(FName RowID) const;
	void MoveRow(FName RowID, FDataTableEditorUtils::ERowMoveDirection Direction, int32 NumRowsToMoveBy) const;
	void AddRowAboveOrBelow(FName RowID, ERowInsertionPosition InsertPosition = ERowInsertionPosition::Bottom) const;

	static int32 RowId2LineIndex(const FName RowID);
	static FName LineIndex2RowId(int32 LineIndex);
protected:
	void RefreshCachedLine(const FName InCachedSelection = NAME_None, const bool bUpdateEvenIfValid = false);
	
	void CreateAndRegisterScriptTab(const TSharedRef<class FTabManager>& InTabManager);
	void CreateAndRegisterRowEditorTab(const TSharedRef<class FTabManager>& InTabManager);

	void OnInsertNewRow(ERowInsertionPosition RowInsertionPosition);
	void OnClearAllLiens();
	TSharedPtr<SWidget> MakeEmptyZoneActionMenu();
	void OnListViewSettingsOpenChanged(bool bOpened);
	TSharedRef<SVerticalBox> CreateScriptContentWidget();
	TSharedRef<SWidget> CreateRowEditorWidget();

	/** Make the widget for a row entry in the data table row list view */
	TSharedRef<ITableRow> MakeRowWidget(FDataTableEditorRowListViewDataPtr InRowDataPtr, const TSharedRef<STableViewBase>& OwnerTable);

	/** Make the widget for a cell entry in the data table row list view */
	TSharedRef<SWidget> MakeCellWidget(FDataTableEditorRowListViewDataPtr InRowDataPtr, const int32 InRowIndex, const FName& InColumnId);


	TSharedRef<SDockTab> SpawnTab_Script(const FSpawnTabArgs& Args);
	TSharedRef<SDockTab> SpawnTab_RowEditor(const FSpawnTabArgs& Args) const;


	void OnRowSelectionChanged(FDataTableEditorRowListViewDataPtr InNewSelection, ESelectInfo::Type InSelectInfo);
	void SetHighlightedRow(FName Name);
	void LoadLayoutData();
	void SaveLayoutData() const;
	void CacheScript(UDialogueAsset* Asset, int32 EpisodeID, TArray<FDataTableEditorColumnHeaderDataPtr>& OutAvailableColumns, TArray<FDataTableEditorRowListViewDataPtr>& OutAvailableRows);
	void UpdateVisibleRows(const FName InCachedSelection = NAME_None, const bool bUpdateEvenIfValid = false);

	// search
	FText GetFilterText() const;
	void OnFilterTextChanged(const FText& InFilterText);
	void OnFilterTextCommitted(const FText& NewText, ETextCommit::Type CommitInfo);

	FSlateColor GetRowTextColor(FName RowName) const;
	FText GetCellText(FDataTableEditorRowListViewDataPtr InRowDataPointer, int32 ColumnIndex) const;
	FText GetCellToolTipText(FDataTableEditorRowListViewDataPtr InRowDataPointer, int32 ColumnIndex) const;

	float GetRowNameColumnWidth() const;
	void RefreshRowNameColumnWidth();

	float GetRowNumberColumnWidth() const;
	void RefreshRowNumberColumnWidth();

	float GetColumnWidth(const int32 ColumnIndex) const;
	void OnColumnResized(const float NewWidth, const int32 ColumnIndex);
	void OnRowNameColumnResized(const float NewWidth);
	void OnRowNumberColumnResized(const float NewWidth);

	void SetDefaultSort();
	EColumnSortMode::Type GetColumnSortMode(const FName ColumnId) const;
	void OnColumnSortModeChanged(const EColumnSortPriority::Type SortPriority, const FName& ColumnId, const EColumnSortMode::Type InSortMode);
	void OnColumnNumberSortModeChanged(const EColumnSortPriority::Type SortPriority, const FName& ColumnId, const EColumnSortMode::Type InSortMode);
	void OnColumnNameSortModeChanged(const EColumnSortPriority::Type SortPriority, const FName& ColumnId, const EColumnSortMode::Type InSortMode);

	FReply OnMoveRowClicked(FDataTableEditorUtils::ERowMoveDirection MoveDirection);
	FReply OnMoveToExtentClicked(FDataTableEditorUtils::ERowMoveDirection MoveDirection);
	void OnAddClicked();
	void OnRemoveClicked();
	void OnCopyClicked();
	void OnPasteClicked();
	void OnDuplicateClicked();

	void RestoreCachedSelection(const FName InCachedSelection, const bool bUpdateEvenIfValid = false);
	void FillToolbar(FToolBarBuilder& ToolbarBuilder);
	
	void CacheKGSLDialogueLine(UDialogueAsset* Asset,
	                           TArray<FDataTableEditorColumnHeaderDataPtr>& OutAvailableColumns,
	                           TArray<FDataTableEditorRowListViewDataPtr>&
	                           OutAvailableRows, TArray<FDataTableEditorRowListViewDataPtr>& OldRows,
	                           const TArray<const FProperty*>& StructProps, TSharedRef<FSlateFontMeasure> FontMeasure,
	                           const FTextBlockStyle& CellTextStyle, const float& CellPadding) const;
protected:
	/** Struct holding information about the current column widths */
	struct FColumnWidth
	{
		FColumnWidth()
			: bIsAutoSized(true)
			, CurrentWidth(0.0f)
		{
		}

		/** True if this column is being auto-sized rather than sized by the user */
		bool bIsAutoSized;
		/** The width of the column, either sized by the user, or auto-sized */
		float CurrentWidth;
	};

	TWeakObjectPtr<UStruct> TemplateClass;
	FSimpleDelegate CallbackOnUndoRedo;

	/** UI for the "Script" tab */
	TSharedPtr<SWidget> ScriptTabWidget;

	/** Property viewing widget */
	TSharedPtr<class IDetailsView> PropertyView;

	/** UI for the "Row Editor" tab */
	TSharedPtr<SSearchBox> SearchBoxWidget;

	/** UI for the "Row Editor" tab */
	TSharedPtr<SWidget> RowEditorTabWidget;

	/** Array of the columns that are available for editing */
	TArray<FDataTableEditorColumnHeaderDataPtr> AvailableColumns;

	/** Array of the rows that are available for editing */
	TArray<FDataTableEditorRowListViewDataPtr> AvailableRows;

	/** Array of the rows that match the active filter(s) */
	TArray<FDataTableEditorRowListViewDataPtr> VisibleRows;

	/** Header row containing entries for each column in AvailableColumns */
	TSharedPtr<SHeaderRow> ColumnNamesHeaderRow;

	/** List view responsible for showing the rows in VisibleRows for each entry in AvailableColumns */
	TSharedPtr<SListView<FDataTableEditorRowListViewDataPtr>> CellsListView;

	/** Width of the row name column */
	float RowNameColumnWidth = 10.f;

	/** Width of the row number column */
	float RowNumberColumnWidth = 10.f;

	/** Widths of data table cell columns */
	TArray<FColumnWidth> ColumnWidths;

	/** The layout data for the currently loaded data table */
	TSharedPtr<FJsonObject> LayoutData;

	/** The name of the currently selected row */
	FName HighlightedRowName;

	/** The visible row index of the currently selected row */
	int32 HighlightedVisibleRowIndex = INDEX_NONE;

	FOnKGSLScriptLineHighlighted CallbackOnLineHighlighted;

	/** The current filter text applied to the data table */
	FText ActiveFilterText;

	/** Specify which column to sort with */
	FName SortByColumn;

	/** Currently selected sorting mode */
	EColumnSortMode::Type SortMode = EColumnSortMode::None;

	TWeakObjectPtr<UDialogueAsset> DialogueAssetEditing;
	int32 EditingEpisodeID = KGStoryLine::INVALID_EPISODE_ID;
	
	TSharedPtr<FExtensibilityManager> ToolBarExtensibilityManager;

	TSharedPtr<SWidget> ScrollBoxParentWidget;
	TSharedPtr<SKGSLScriptEdListViewSettings> ListViewSettings;
	TArray<FString> ColumnOrders;
private:
	static const FName ScriptEditorIdentifier;
	static const FName ScriptTabId;
	static const FName RowEditorTabId;
	
	/** The column id for the row name list view column */
	static const FName RowNameColumnId;

	/** The column id for the row number list view column */
	static const FName RowNumberColumnId;

	/** The column id for the drag drop column */
	static const FName RowDragDropColumnId;
};
