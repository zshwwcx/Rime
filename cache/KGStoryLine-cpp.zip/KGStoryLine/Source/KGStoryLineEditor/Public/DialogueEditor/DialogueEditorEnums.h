#pragma once
#include "UObject/ObjectMacros.h"

namespace EDialogueMode
{
	enum Type
	{
		Main,
		Template
	};
}

enum  AutoCameraEvent
{
	UpdateCameraParam = 1,
	UpdateViewParam = 2,
	UpdateCameraTemplate = 3,
};
