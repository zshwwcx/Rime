#pragma once

#include "Factories/Factory.h"

#include "DialogueEditorAssetFactory.generated.h"


UCLASS(HideCategories = Object, MinimalAPI)
class UDialogueTemplateAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UDialogueTemplateAssetFactory(const FObjectInitializer& ObjectInitializer);

	virtual ~UDialogueTemplateAssetFactory() {}

	virtual bool ConfigureProperties() override { return true; }

	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;

	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;
};


UCLASS(HideCategories = Object, MinimalAPI)
class UDialogueAssetFactory : public UFactory
{
	GENERATED_BODY()

public:
	UDialogueAssetFactory(const FObjectInitializer& ObjectInitializer);

	virtual ~UDialogueAssetFactory() {}

	virtual bool ConfigureProperties() override;
	virtual FString GetDefaultNewAssetName() const override;
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn, FName CallingContext) override;
	
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;

	const FString& GetAssetName() const;

protected:
	UPROPERTY()
	TSubclassOf<UObject>  ConcreteClass;
	FString AssetName;
	FString StoryLineID;
	FString TemplatePath;

};