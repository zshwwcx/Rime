#pragma once

#include "UObject/Object.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"

#include "Engine/DataAsset.h"
#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "DialogueEditor/Dialogue/DialogueCameraTrack.h"
#include "DialogueEditor/Dialogue/DialogueActorTrack.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"
#include "DialogueEditor/Dialogue/DialogueCommon.h"
#include "KGStoryLineConst.h"
#include "Animation/AnimationAsset.h"
#include "3C/Animation/AnimAssetDefine.h"

#include "DialogueAsset.generated.h"

UENUM()
enum class EDialogueContentUIType : uint8
{
	Default = 0 UMETA(DisplayName = "默认"),
	Aside = 1 UMETA(DisplayName = "旁白"),
	Printer = 2 UMETA(DisplayName = "印刷机"),
	Caption = 3 UMETA(DisplayName = "字幕"),
};

UENUM(BlueprintType)
enum class EDialoguePreloadResType : uint8
{
    Asset = 0 UMETA(DisplayName = "Asset"),
    Sequence = 1 UMETA(DisplayName = "Dialogue Sequence Cut"),
};

USTRUCT(BlueprintType)
struct FDialoguePreloadItem
{
    GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, meta = (DisplayName = "预加载资源"))
	FString PathName;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "预加载资源类型"))
	EDialoguePreloadResType Type = EDialoguePreloadResType::Asset;
    
    UPROPERTY(EditAnywhere, meta = (DisplayName = "预加载顺序"))
    int32 LoadOrder;
    
    UPROPERTY(EditAnywhere, meta = (DisplayName = "所属小段ID"))
    int32 EpisodeID;
    
    UPROPERTY(EditAnywhere, meta = (DisplayName = "Section开始时间"))
    float StartTime;
};

USTRUCT()
struct FDialogueTrackGroup
{
	GENERATED_USTRUCT_BODY()

public:
	FDialogueTrackGroup() : Name(NAME_None) {}
	FDialogueTrackGroup(FName GrroupName) : Name(GrroupName) {}

public:
	UPROPERTY()
	FName Name = NAME_None;

	/*UPROPERTY()
	TArray<TWeakObjectPtr<UDialogueTask>> TaskList;*/
};

USTRUCT(BlueprintType)
struct FIconPath
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, meta=(MetaClass="/Script/Paper2D.PaperSprite"))
	FSoftObjectPath Path;
};

//外观表格，ID对应各个配置表的ID，Name是经过编辑器处理的显示名字
USTRUCT(BlueprintType)
struct FOptionTextDataItem
{
	GENERATED_USTRUCT_BODY()
	UPROPERTY(meta = (DisplayName = "对话文本ID", HideFromDataTableEditorColumn = true))
	int32 ID = 0;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "对话文本", HideFromDataTableEditorColumn = true))
	FString Text;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "图标"))
	FIconPath Icon;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "选项锁定时是否显示"))
	bool LockVisible;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "选项锁定时文本"))
	FString LockText;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "是否关闭"))
	bool bClose = false;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "选择后是否隐藏"))
	bool SelectHide = false;

	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "额外行为"))
	TArray<FString> ExtraAction;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "通知服务器"))
	bool ReportServer = false;

	UPROPERTY(meta = (DisplayName = "资产名", HideFromDataTableEditorColumn = true))
	FString AssetName;
};

USTRUCT(BlueprintType)
struct FOptionTextTableData
{
	GENERATED_BODY()

	UPROPERTY()
	TMap<int32, FOptionTextDataItem> OptionTextID;

	const FOptionTextDataItem* FindID(int32 ID) const
	{
		return OptionTextID.Find(ID);
	}

	void SetItem(int32 ID, FOptionTextDataItem InItem)
	{
		FOptionTextDataItem* DataItem = OptionTextID.Find(ID);
		DataItem->ID = ID;
		DataItem->Text = InItem.Text;
		DataItem->LockVisible = InItem.LockVisible;
		DataItem->LockText = InItem.LockText;
		DataItem->bClose = InItem.bClose;
		DataItem->SelectHide = InItem.SelectHide;
		DataItem->ExtraAction = InItem.ExtraAction;
		DataItem->ReportServer = InItem.ReportServer;
		DataItem->AssetName = InItem.AssetName;
	}
};

//对话分支选项
UCLASS(Blueprintable)
class KGSTORYLINEEDITOR_API UDialogueOptionExtra: public UObject
{
	GENERATED_BODY()

public:
	UDialogueOptionExtra() {};

public:
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "对话文本ID"))
	int32 DialogueID = 0;

	UPROPERTY(meta = (DisplayName = "对话文本"))
	FString DialogueText;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "本选项跳转的对话小段"))
	int32 EpisodeID = 0;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "从对话小段第几句开始"))
	int32 DialogueLineIndex = 0;

	//只提供一个字符串，具体条件由lua配置并解析
	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "开启条件"))
	FString Condition;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "定制文本，比如打开商店Jump_xxxx"))
	FString CustomContent;

#if WITH_EDITORONLY_DATA
	UPROPERTY(meta = (HideFromDataTableEditorColumn = true))
	FGuid PinId;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "选项具体内容", HideFromDataTableEditorColumn = true))
	FOptionTextDataItem Item;

	FString ToString()
	{
		TStringBuilder<256> sb;
		sb.Reset();
		sb.Append(FString::FromInt(DialogueID));
		sb.Append(TEXT("|"));
		sb.Append(DialogueText);
		sb.Append(TEXT("|"));
		sb.Append(FString::FromInt(EpisodeID));
		sb.Append(TEXT("|"));
		sb.Append(FString::FromInt(DialogueLineIndex));
		sb.Append(TEXT("|"));
		sb.Append(Condition);
		sb.Append(TEXT("|"));
		sb.Append(CustomContent);
		sb.Append(TEXT("|"));
		sb.Append(FString::FromInt(Item.ID));
		sb.Append(TEXT("|"));
		sb.Append(Item.Text);
		sb.Append(TEXT("|"));
		sb.Append(Item.LockVisible ? TEXT("TRUE") : TEXT("FALSE"));
		sb.Append(TEXT("|"));
		sb.Append(Item.LockText);
		sb.Append(TEXT("|"));
		sb.Append(Item.bClose ? TEXT("TRUE") : TEXT("FALSE"));
		sb.Append(TEXT("|"));
		sb.Append(Item.SelectHide ? TEXT("TRUE") : TEXT("FALSE"));
		sb.Append(TEXT("|"));
		sb.Append(Item.ReportServer ? TEXT("TRUE") : TEXT("FALSE"));
		auto length = Item.ExtraAction.Num();
		if (length > 0)
		{
			sb.Append(TEXT("|"));
			sb.Append(FString::FromInt(length));
			for (int i = 0; i < length; i++)
			{
				sb.Append(TEXT("*"));
				sb.Append(Item.ExtraAction[i]);
			}
		}
		sb.Append(TEXT("|"));
		sb.Append(Item.AssetName);
		sb.Append(TEXT("|"));
		sb.Append(Item.Icon.Path.ToString());
		return sb.ToString();
	}

	static TObjectPtr<class UDialogueOptionExtra> ParseString(FString& line)
	{
		TArray<FString> arr;
		line.ParseIntoArray(arr, TEXT("|"), false);
		int k = 0;
#define KGSLGetOpNextToken() (arr.IsValidIndex(k) ? arr[k++] : FString(TEXT("")))
		auto DialogueID = FCString::Atoi(*KGSLGetOpNextToken());
		FString DialogueText = KGSLGetOpNextToken();
		auto EpisodeID = FCString::Atoi(*KGSLGetOpNextToken());
		auto DialogueLineIndex = FCString::Atoi(*KGSLGetOpNextToken());
		FString Condition = KGSLGetOpNextToken();
		FString CustomContent = KGSLGetOpNextToken();
		auto ID = FCString::Atoi(*KGSLGetOpNextToken());
		FString Text = KGSLGetOpNextToken();
		FString LockVisible = KGSLGetOpNextToken();
		FString LockText = KGSLGetOpNextToken();
		FString bClose = KGSLGetOpNextToken();
		FString SelectHide = KGSLGetOpNextToken();
		FString ReportServer = KGSLGetOpNextToken();
		TArray<FString> ExtraAction;
		if (k < arr.Num() && !arr[k].IsEmpty())
		{
			TArray<FString> files;
			FString StrActions = KGSLGetOpNextToken();
			StrActions.ParseIntoArray(files, TEXT("*"), false);
			auto length = FCString::Atoi(*files[0]);
			for (int m = 0; m < length; m++)
			{
				FString path = files[m + 1];
				ExtraAction.Add(path);
			}
		}
		FString AssetName = KGSLGetOpNextToken();
		FString IconPath = KGSLGetOpNextToken();
		FOptionTextDataItem Item = FOptionTextDataItem();
		Item.ID = ID;
		Item.Text = Text;
		Item.LockVisible = LockVisible == TEXT("TRUE");
		Item.LockText = LockText;
		Item.bClose = bClose == TEXT("TRUE");
		Item.SelectHide = SelectHide == TEXT("TRUE");
		Item.ReportServer = ReportServer == TEXT("TRUE");
		Item.ExtraAction = ExtraAction;
		Item.AssetName = AssetName;
		Item.Icon.Path.SetPath(IconPath);

		TObjectPtr<class UDialogueOptionExtra> OptionExtra = NewObject<UDialogueOptionExtra>();
		OptionExtra->DialogueID = DialogueID;
		OptionExtra->DialogueText = DialogueText;
		OptionExtra->EpisodeID = EpisodeID;
		OptionExtra->DialogueLineIndex = DialogueLineIndex;
		OptionExtra->Condition = Condition;
		OptionExtra->CustomContent = CustomContent;
		OptionExtra->Item = Item;
		return OptionExtra;
	}
#endif

};

//对话分支选项
USTRUCT(BlueprintType)
struct FDialogueOption
{
	GENERATED_BODY()
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "对话文本ID"))
	int32 DialogueID = 0;

	UPROPERTY(meta = (DisplayName = "对话文本"))
	FString DialogueText;

	UPROPERTY(meta = (DisplayName = "本选项对应的分支ID"))
	int32 EpisodeID = 0;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "从分支的第几句开始"))
	int32 DialogueLineIndex = 0;

	//只提供一个字符串，具体条件由lua配置并解析
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "开启条件"))
	FString Condition;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "定制文本，比如打开商店Jump_xxxx"))
	FString CustomContent;

	
#if WITH_EDITORONLY_DATA
	UPROPERTY(meta = (HideFromDataTableEditorColumn = true))
	FGuid PinId;
#endif

	UPROPERTY(meta = (HideFromDataTableEditorColumn = true))
	FOptionTextDataItem Item;
};


USTRUCT(BlueprintType)
struct KGSTORYLINEEDITOR_API FDialogueEpisode
{
	GENERATED_USTRUCT_BODY()

public:
	FDialogueEpisode()
	{
	}
	
	FDialogueEpisode(int32 InEpisodeID)
		: EpisodeID(InEpisodeID)
	{
		InitName();
	}
	
	UPROPERTY(EditDefaultsOnly)
	int32 EpisodeID = KGStoryLine::INVALID_EPISODE_ID;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Meta = (ClampMin = "0.52"))
	float Duration = 3.0f;

	// 循环次数，默认为0不循环。无限循环设置为-1。只在非独占对话中起效
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, meta = (DisplayName = "循环次数", ToolTip = "循环次数，默认为0不循环。无限循环设置为-1。只在非独占对话中起效"))
	int LoopTimes = 0;

	UPROPERTY(meta=(ExportObjectComplete))
	TArray<UDialogueTrackBase*> TrackList;

	//本集对话的选项数据
	UPROPERTY(EditDefaultsOnly)
	TArray<FDialogueOption> Options;

	UPROPERTY(EditDefaultsOnly)
	int OptionType = 0;

	UPROPERTY(EditDefaultsOnly, meta = (Tooltip = "时间限制"))
	float TimeLimit = 0;

	UPROPERTY(EditDefaultsOnly, meta = (Tooltip = "超时默认选项"))
	int TimeOutDefaultChoice = 0;

	TArray<UDialogueTrackBase*> GetAllTracks(bool bIncludeSpawnableTackActions = false);

	TMap<FString, UDialogueCameraTrack*> GetTrackCameras();

	TMap<FString, UDialogueActorTrack*> GetTrackActors();

	FName GetName();
private:
	void InitName();

#if WITH_EDITORONLY_DATA
	UPROPERTY(VisibleAnywhere)
	FName Name = NAME_None;
#endif
};


UCLASS(Blueprintable)
class KGSTORYLINEEDITOR_API UDialogueBaseAsset : public UPrimaryDataAsset
{
	GENERATED_UCLASS_BODY()

public:
	// 剧情时间线组
	UPROPERTY()
	TArray<FDialogueEpisode> Episodes;

	// 剧情演员列表
	UPROPERTY(meta=(ExportObjectComplete))
	TArray<UDialogueActor*> PerformerList;

	// 剧情镜头列表
	UPROPERTY(meta=(ExportObjectComplete))
	TArray<UDialogueCamera*> CameraList;

	// 寻路点列表
	UPROPERTY(meta=(ExportObjectComplete))
	TArray<UDialogueEntity*> RoutePointList;

	// 新扩展的对象列表，UDialogueEntity只是基类指针
	UPROPERTY(meta=(ExportObjectComplete))
	TArray<class UDialogueEntity*> NewEntityList;

	int32 GetEpisodeNum() const {return Episodes.Num();}

	FDialogueEpisode* GetEpisodePointerByIndex(int32 Index)
	{
		if (Episodes.IsValidIndex(Index))
		{
			return &(Episodes[Index]);
		}

		return nullptr;
	}
	FDialogueEpisode* GetEpisodePointerByID(int32 EpisodeID)
	{
		for (FDialogueEpisode& Data : Episodes)
			if (Data.EpisodeID == EpisodeID)
				return &Data;
		return nullptr;
	}

	//查找TrackName查找对应的Entity（Performer or Camera or RoutePoint），这个函数用于辅助多Episode情况，能够根据查找结果，避免重复创建相同的Entity
	UFUNCTION()
	UDialogueEntity* FindAssetEntity(const FString& TrackName);

	//获取用到的所有Entity
	UFUNCTION()
	TArray<UDialogueEntity*> GetAllEntities();

	//获取RootEntity，理论上来说一个资产应该只有1个RootEntity，不排除策划设置了多个Entity，因此返回一个Array
	UFUNCTION()
	TArray<UDialogueEntity*>  GetRootEntity();

	UFUNCTION(BlueprintCallable)
	TArray<UDialogueTrackBase*> GetAllEpisodeTracks(int32 EpisodeIndex)
	{
		if (Episodes.IsValidIndex(EpisodeIndex))
		{
			return Episodes[EpisodeIndex].GetAllTracks();
		}
		return TArray<UDialogueTrackBase*>();
	}
	UFUNCTION(BlueprintCallable)
	TArray<UDialogueTrackBase*> GetAllEpisodeTracksByRef(FDialogueEpisode& InEpisodeRef)
	{
		return InEpisodeRef.GetAllTracks();
	}

	//查找指定Track名称的轨道，默认从第1个Episode查起
	UFUNCTION(BlueprintCallable)
	UDialogueTrackBase* FindTrackByName(int32 EpisodeIndex, FName TrackName);

	UFUNCTION(BlueprintCallable)
	void SetEpisodeDuration(int32 EpisodeID, float Duration);

	/*查找指定Track名称的轨道
	** EpisodeID:要查找的EpisodeID
	*/
	UFUNCTION(BlueprintCallable)
	UDialogueTrackBase* FindEpisodeTrackByName(int32 EpisodeID, FName TrackName);

	/*查找指定Track类型的轨道
	** EpisodeID:要查找的EpisodeID
	*/
	UFUNCTION(BlueprintCallable)
	UDialogueTrackBase* FindEpisodeTrackByTrackClass(int32 EpisodeID, UClass* TrackClass);

	UFUNCTION(BlueprintCallable)
	float GetEpisodeDuration(int32 EpisodeIndex)
	{
		if (Episodes.IsValidIndex(EpisodeIndex))
		{
			return Episodes[EpisodeIndex].Duration;
		}
		return 0.f;
	}


	bool ChangeEpisodeDuration(int32 Index, float Duration)
	{
		if (Episodes.IsValidIndex(Index))
		{
			Episodes[Index].Duration = Duration;
			GetPackage()->MarkPackageDirty();
			return true;
		}
		return false;
	}

	UFUNCTION()
	bool AddEpisode(int32 EpisodeID);
	virtual void OnEpisodeAdded(FDialogueEpisode& InEvent, int32 InEpisodeID) {}

	UFUNCTION()
	TArray<FDialogueEpisode> GetEpisodesCopy() {return Episodes;}

	bool RemoveEpisode(int32 EpisodeID);

	//Pos:-1，添加到末尾;其他数据，插入到指定位置
	UFUNCTION()
	bool AddTrack(int32 EpisodeIndex, UDialogueTrackBase* Track, int32 Pos=-1);
	UFUNCTION()
	bool AddTrackByEpisodeID(int32 InEpisodeID, UDialogueTrackBase* Track, int32 Pos=-1);

	UFUNCTION(BlueprintCallable)
	bool AddTrackToAnchor(int32 EpisodeIndex, UDialogueTrackBase* Track, int32 Pos = -1);

	bool RemoveTrack(int32 EpisodeID, UDialogueTrackBase& Track);
	
	UFUNCTION()
	int32 GetCameraCutIndex(int32 EpisodeID);
	
	UFUNCTION()
	bool RemoveTrackByName(int32 EpisodeIndex, const FString& TrackName);

	//删除所有Episode里面的等于TrackName的Track
	void RemoveAllEpisodesTrackByName(const FString& TrackName);

	UFUNCTION()
	void AddPerformer(UDialogueActor* Performer);

	void RemovePerformer(UDialogueActor* Performer);

	UFUNCTION()
	void AddCamera(UDialogueCamera* Camera);

	void RemoveCamera(UDialogueCamera* Camera);

	UFUNCTION()
	void AddRoutePoint(UDialogueEntity* RoutePoint);
	UFUNCTION()
	void RemoveRoutePoint(UDialogueEntity* RoutePoint);

	UFUNCTION()
	void AddDialogueEntity(UDialogueEntity* DialogueEntity);
	UFUNCTION()
	void RemoveDialogueEntity(UDialogueEntity* DialogueEntity);

	UFUNCTION()
	class UDialogueActionBase* AddSection(int32 EpisodeID, class UDialogueActionTrack* InAction);

	UFUNCTION()
	class UDialogueActionBase* AddSecondTypeSection(int32 EpisodeID, class UDialogueActionTrack* InAction);

	UFUNCTION()
	UDialogueActionBase* CopySection(int32 EpisodeID, UDialogueActionBase* InActionSection, UDialogueActionTrack* InAction);
	
	UFUNCTION()
	TArray<UDialogueTrackBase*> GetAllTracks(int32 EpisodeIndex);

	UFUNCTION(BlueprintCallable)
	TArray<UDialogueTrackBase*> GetAllTacksByEpisodeID(int32 EpisodeID, bool bIncludeSpawnableTackActions = false);
	//UFUNCTION()
	//	TArray<UDialogueTrackBase*> GetAllTracks2(FDialogueEpisode* dd) {}

	UFUNCTION()
	TMap<FString, UDialogueCameraTrack*> GetTrackCameras(FDialogueEpisode& Episode);

	UFUNCTION()
	TMap<FString, UDialogueActorTrack*> GetTrackActors(FDialogueEpisode& Episode);

	UFUNCTION()
	TArray<UDialogueActorTrack*> GetTrackActorsArray(FDialogueEpisode& Episode);

	UFUNCTION()
	TArray<UDialogueSpawnableTrack*> GetSpawnableTracks(FDialogueEpisode& Episode);

#if WITH_EDITOR
    virtual void OnEditorInitialized();
	//修改TrackName
	virtual void RenameTrackName(const FString& OldTrackName, const FString& NewTrackName);

	//判断新的TrackName是否合法，主要是重名判断
	bool IsNewTrackNameValid(const FString& NewTrackName);
	UFUNCTION()
		UDialogueTrackBase* RoamTrack(UDialogueTrackBase* InTrack);
#endif

	 virtual void PostLoad() override;
};

UCLASS(Blueprintable)
class KGSTORYLINEEDITOR_API UDialogueTemplateAsset : public UDialogueBaseAsset
{
	GENERATED_BODY()
};


USTRUCT()
struct FDialogueAnimations
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "演员"))
	FDialoguePerformerSelector Performer;

	//播放动画的延迟时间
	UPROPERTY(EditDefaultsOnly)
	float DelayTime = 0.0f;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "一次性动画"))
	FAnimLibAssetID  SingleAnimation;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "旧的动作融合淡出时间"))
	float PreAnimationBlendOutTime= 0.2f;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "本动作融合淡出时间"))
	float BlendOutTime = 0.2f;

	//起手动画后接的循环动画，可以不用设置
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "循环动画"))
	FAnimLibAssetID  NewLoopAnimation;
};

USTRUCT(BlueprintType)
struct FDialogueActorInfo
{
	GENERATED_USTRUCT_BODY()

public:
	FDialogueActorInfo() {}
	FDialogueActorInfo(FString InName, int32 InAppearanceID)
		:PerformerName(InName), AppearanceID(InAppearanceID)
	{

	}
	UPROPERTY(VisibleAnywhere, meta = (DisplayName = "演员"))
	FString PerformerName;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "NPC ID"))
	FDialogueAppearanceSelector AppearanceID;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "初始动画"))
	FAnimLibAssetID  IdleAnimation;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "是否为玩家"))
	bool bIsPlayer = false;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "在无镜对话中使用真实NPC", ToolTip = "如果使用场景角色替换，需要填写InsID"))
	bool UseSceneActor = false;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "场景角色InsID", ToolTip = "如果使用场景角色替换，需要填写InsID", EditCondition = "UseSceneActor", EditConditionHides))
	FString InsID;
};

//扩展对话数据，应在蓝图子类添加
//轨道的生成应在lua实现
UCLASS(Blueprintable, EditInlineNew, Abstract)
class KGSTORYLINEEDITOR_API UDialogueLineExtension : public UObject
{
	GENERATED_BODY()
};

//对象行为，最终用这个来生成Track和Section，生成到宿主Track里面
USTRUCT(BlueprintType)
struct KGSTORYLINEEDITOR_API FPlotActorBehavior
{
	GENERATED_BODY()
public:
#if WITH_EDITORONLY_DATA
	UPROPERTY(EditDefaultsOnly, meta=(DisplayName = "行为说明"))
	FString ToolTips;
#endif
	UPROPERTY(EditDefaultsOnly)
	uint8 bEnable:1;

	//角色或者Camera的名字
	UPROPERTY(EditDefaultsOnly)
	FBehaviorActorSelector TrackName;

	//一个行为由N组Section构成
	UPROPERTY(EditDefaultsOnly, Instanced)
	TArray<class UDialogueActionBase*> Section;
};

USTRUCT(BlueprintType)
struct FDialogueCameraDebug
{
	GENERATED_BODY()

	//ID不让策划手动输入，自动生成，因为策划压根不用关系ID是多少，它只用于连接前后Episode
	UPROPERTY(BlueprintReadWrite, EditDefaultsOnly)
	bool OpenAutoCameraDebug = false;

	//本集对话对应的一些对白数据
	UPROPERTY(BlueprintReadWrite, EditDefaultsOnly)
	float DrawTime = 0.3;

	//本集对话的选项数据
	UPROPERTY(BlueprintReadWrite, EditDefaultsOnly)
	float Radius = 15;
};


//外观表格，ID对应各个配置表的ID，Name是经过编辑器处理的显示名字
USTRUCT(BlueprintType)
struct FAppreanceDataItem
{
	GENERATED_BODY()
	
	UPROPERTY()
	int32 ID = 0;
	UPROPERTY()
	FString Name;
};
USTRUCT(BlueprintType)
struct FAppreanceTableData
{
	GENERATED_BODY()
	
	UPROPERTY()
	TArray<FAppreanceDataItem> AppreanceID;

	const FAppreanceDataItem* FindID(int32 ID) const
	{
		return AppreanceID.FindByPredicate([ID](const FAppreanceDataItem& Item) {return Item.ID == ID; });
	}
};



// -----------------------------------------------------------------------------------------
// UObject实现
// -----------------------------------------------------------------------------------------

UCLASS(BlueprintType)
class KGSTORYLINEEDITOR_API UKGSLDialogueLine : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "小段ID", ImportFromExcel))
	int32 EpisodeID = 0;

	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "台本序号", ImportFromExcel))
	int32 ContentIndex = 0;
	/*
	 * 台词GUID
	 * 在生成时自动产生，算法：CityHash64(当前时间戳  + DialogueAssetName + 随机数)
	 */
	UPROPERTY(/*VisibleDefaultsOnly, meta = (DisplayName = "全局唯一标识符")*/)
	uint32 GUID = KGStoryLine::INVALID_LINE_GUID;
	
	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "全局唯一标识符", ImportFromExcel))
	FGuid UniqueID;

	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "台本类型", HideFromDataTableEditorColumn))
	int32 TalkType = 3;
	
	//在上一句台本后多久播放本台本
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "延后时间"))
	float Delay = 0.0f;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "时长"))
	float Duration = 5.0f;
	
	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "台本", ImportFromExcel))
	FString ContentString;
	
	//台本UI
	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "台本UI样式", Tooltip="请在台本Section上修改该样式"))
	FString ContentUI;

	//副字幕
	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "副字幕", ImportFromExcel))
	FString SubTitle;

	//副字幕
	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "副字幕样式", ImportFromExcel))
	int32 SubTitleType;

	//解释小字
	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "解释小字", ImportFromExcel))
	FString Small;

	//解释小字位置(在那个词语的上方)
	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "解释小字位置(在那个词语的上方)", ImportFromExcel))
	FString SmallPos;

	UPROPERTY(Transient)
	FDialogueCameraSelector Camera;

	UPROPERTY(Transient, meta = (DisplayName = "动画"))
	TArray<FDialogueAnimations> Animations;

	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "说话者", ImportFromExcel))
	FDialoguePerformerSelector Talker;

	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "说话者自定义名字", Tooltip = "设置了这个名字后，将取代说话者读表的名字", ImportFromExcel))
	FString TalkerName;

	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "是否停顿", Tooltip = "请在台本Section上修改该属性"))
	bool bPause = true; 

	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "可跳过", Tooltip = "请在台本Section上修改该属性"))
	bool CanSkip = true;
	
	UPROPERTY(EditDefaultsOnly, Category="自动相机",
		meta = (DisplayName = "自动镜头", EditCondition="false", EditConditionHides))
	int32 AutoCameraCut = -1;

	UPROPERTY(EditDefaultsOnly, Category="自动相机",
		meta = (DisplayName = "自动镜头Actor", EditCondition="false", EditConditionHides))
	TArray<FString> AutoCameraActor;

	UPROPERTY(EditDefaultsOnly, Category="自动相机", meta = (DisplayName = "自动镜头距离", EditCondition="false", EditConditionHides))
	FString AutoCameraDistance;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "说话者注视"))
	FString TalkerFocus;

	UPROPERTY(meta = (DisplayName = "LookAt"))
	TArray<FString> LookAt;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "是否开启景深"))
	bool bDOF = false;

	UPROPERTY(VisibleDefaultsOnly, meta = (DisplayName = "动态标识", ImportFromExcel))
	FString DynamicFlag;

public:
	UFUNCTION(BlueprintCallable)
	void Initialize(const FString& InContent, const FString& InGUID);

	static void ExportText(FString& ValueStr, const void* Value, const void* Defaults, UObject* OwnerObject, int32 
	                       PortFlags, UObject* ExportRootScope);
	static const TCHAR* ImportText(const TCHAR* Buffer, void* Value, UObject* OwnerObject, int32 PortFlags, FOutputDevice* ErrorText, const FString& StructName);

	static UKGSLDialogueLine* Instance(UObject* Outer, const FString& InContent, FName Name = NAME_None, const FString& InGUID = "");
};

//对话分支选项
UCLASS(BlueprintType)
class KGSTORYLINEEDITOR_API UKGSLDialogueOption : public UObject
{
	GENERATED_BODY()
public:
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "对话文本ID"))
	int32 DialogueID = 0;

	UPROPERTY(meta = (DisplayName = "对话文本"))
	FString DialogueText;

	UPROPERTY(meta = (DisplayName = "本选项对应的分支ID"))
	int32 EpisodeID = 0;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "从分支的第几句开始"))
	int32 DialogueLineIndex = 0;

	//只提供一个字符串，具体条件由lua配置并解析
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "开启条件"))
	FString Condition;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "定制文本，比如打开商店Jump_xxxx"))
	FString CustomContent;

#if WITH_EDITORONLY_DATA
	UPROPERTY(Transient)
	FGuid PinId;
#endif

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "选项具体内容"))
	FOptionTextDataItem Item;
public:
	UFUNCTION(BlueprintCallable)
	void CopyTo(FDialogueOption& OutOption);

	static UKGSLDialogueOption* Instance(UObject* Outer, FName Name = NAME_None);
};



UCLASS(BlueprintType)
class KGSTORYLINEEDITOR_API UKGSLDialogueEpisode : public UObject
{
	GENERATED_BODY()

public:
#if WITH_EDITORONLY_DATA
	UPROPERTY(VisibleAnywhere)
	FName Name = NAME_None;
#endif
	
	//ID不让策划手动输入，自动生成，因为策划压根不用关系ID是多少，它只用于连接前后Episode
	UPROPERTY(VisibleDefaultsOnly)
	int EpisodeID = -1;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Meta = (DisplayName = "时长", ClampMin = "0.52"))
	float Duration = 3.0f;
	
	//本集对话对应的一些对白数据
	UPROPERTY(Instanced)
	TArray<UKGSLDialogueLine*> DialogueLines;

	//本集对话的选项数据
	UPROPERTY(EditFixedSize)
	TArray<UKGSLDialogueOption*> Options;

	UPROPERTY(meta = (DisplayName = "选项类型"))
	int OptionType = 0;

	UPROPERTY(meta = (DisplayName = "时间限制（秒）"))
	double TimeLimit;

	UPROPERTY(meta = (DisplayName = "超时默认选项"))
	int TimeOutDefaultChoice;

	// 跳过当前小段时显示的概括文本
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "跳过文本"))
	FString SkipTips;

	UPROPERTY()
	TArray<UDialogueTrackBase*> TrackList;
public:
	UFUNCTION(BlueprintCallable)
	int32 GetEpisodeID() const { return EpisodeID; }

	UFUNCTION(BlueprintCallable)
	void SetEpisodeID(int32 InEpisodeID);
	
	UFUNCTION(BlueprintCallable)
	UKGSLDialogueLine* InstanceLine(const FString& Content, const FString& InGUID);
	
	UFUNCTION(BlueprintCallable)
	void AddLine(UKGSLDialogueLine* Line, int32 LineIndex = -1);

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueLine* GetLine(int32 InLineIndex);

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueLine* GetLineByGUID(int32 InGUID);

	UFUNCTION(BlueprintCallable)
	void RemoveLine(int32 InLineIndex);

	UFUNCTION(BlueprintCallable)
	void RemoveLineByGUID(int32 InGUID);

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueOption* InstanceOption();

	UFUNCTION(BlueprintCallable)
	void AddOption(UKGSLDialogueOption* Option, int32 InOptionIndex = -1);

	UFUNCTION(BlueprintCallable)
	void RemoveOption(int32 InOptionIndex);

	UFUNCTION(BlueprintCallable)
	int32 CopyOptionsToEpisodeData(FDialogueEpisode& EpisodeData);
public:
	TArray<UDialogueTrackBase*> GetAllTracks(bool bIncludeSpawnableTackActions = false);

	TMap<FString, UDialogueCameraTrack*> GetTrackCameras();

	TMap<FString, UDialogueActorTrack*> GetTrackActors(); 
};

// -----------------------------------------------------------------------------------------


UCLASS(Blueprintable, meta = (DisplayName = "对话资源"))
class KGSTORYLINEEDITOR_API UDialogueAsset : public UDialogueBaseAsset 
{
	GENERATED_UCLASS_BODY()

public:
	UPROPERTY(EditDefaultsOnly, Category = "模板", meta = (DisplayName = "是否使用Template镜头"))
	bool UseTemplateCamera = true;
	
	UPROPERTY(EditDefaultsOnly, EditFixedSize, Category = "对话资源", meta = (DisplayName = "角色基础属性", IgnoreExport))
	TArray<FDialogueActorInfo> ActorInfos;

	UPROPERTY(EditDefaultsOnly, Category = "模板", meta = (DisplayName = "站位镜头模板", EditorExportObjectOnlyPath))
	UDialogueTemplateAsset* DialogueTemplate = NULL;
	
    UPROPERTY(VisibleAnywhere, Category = "模板", meta = (DisplayName = "角色模板", EditorExportObjectOnlyPath))
    TArray<FDialoguePreloadItem> PreloadRes;
	/**
	 * 主要用于便捷搜索
	 */
	UPROPERTY(BlueprintReadWrite, VisibleAnywhere, Category = "对话资源", meta = (DisplayName = "和资产对应的ID", DisplayAfter = "None"))
	int32 StoryLineID = 0;
public:
	virtual void BeginDestroy() override;
	virtual void Serialize(FArchive& Ar) override;
	virtual void OnEpisodeAdded(FDialogueEpisode& NewEpisode, int32 InEpisodeID) override;
	
	//编辑器下新增一个台本Section时，用来为台本生成GUID, 蓝图返回值不支持uint32，因此使用int64代替
	UFUNCTION(BlueprintCallable)
	FString GenerateLineGUIDForSection(const FString& ContentString = TEXT(""), const FString SuffixText = TEXT(""));

	UFUNCTION(BlueprintCallable)
	bool IsValidEpisodeID(int32 InEpisodeID);

	UFUNCTION(BlueprintCallable)
	bool RemoveActorInfo(const FString& ActorName);

	UFUNCTION(BlueprintCallable)
	FDialogueActorInfo& FindOrAddActorInfo(const FString& ActorName);

#if WITH_EDITORONLY_DATA
	
	UPROPERTY()/*VisibleDefaultsOnly, Category = "对话资源", meta = (DisplayName = "当前Section对应的台本索引,-1说明Section没有对应台本")*/
	int32 EditDialogueLineProxyIndex = -1;

	// 这个变量不需要序列化的，也没必要暴露出去，要调试的话，通过工具栏增加开关调试
	UPROPERTY(Transient)
	FDialogueCameraDebug AutoCameraDebug;
	
	UPROPERTY(Instanced, meta=(IgnoreExport))
	TArray<UKGSLDialogueEpisode*> EpisodesList;

	// 当前选中的小段（Episode）
	UPROPERTY(EditDefaultsOnly, Transient, Category = "对话资源",  meta = (DisplayName = "当前编辑的小段", Tooltip = "当前选中的小段（Episode）"))
	UKGSLDialogueEpisode* CurrentEpisode;
	
	UPROPERTY(Transient)
	class UEdGraph* EpisodeGraph;

#endif
	
#if WITH_EDITOR
public:
	UFUNCTION(BlueprintCallable)
	static bool IsUsingLuaAsset();

	UFUNCTION(BlueprintCallable)
	static void SwitchUsingLuaAsset(bool bUsingLuaAsset);

	UFUNCTION(BlueprintCallable)
	bool IsUsingUObject() const;
	
	UFUNCTION(BlueprintCallable)
	void ClearEpisodesList();

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueEpisode* InstanceDialogueEpisode(int32 EpisodeId = -1);

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueLine* InstanceDialogueLine(int32 EpisodeID, const FString& Content, const FString& InGUID);

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueOption* InstanceDialogueOption(int32 EpisodeID);

	UFUNCTION(BlueprintCallable)
	void AddDialogueEpisode(UKGSLDialogueEpisode* Episode, int32 EpisodeIndex = -1);

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueEpisode* GetDialogueEpisode(int32 EpisodeIndex);

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueEpisode* GetDialogueEpisodeByEpisodeID(int32 EpisodeID);

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueLine* GetDialogueLine(int32 EpisodeID, int32 LineIndex);

	UFUNCTION(BlueprintCallable)
	UKGSLDialogueLine* GetDialogueLineByGUID(int32 EpisodeID, int32 GUID);

	UFUNCTION(BlueprintCallable)
	void RemoveDialogueEpisode(int32 EpisodeIndex);

	UFUNCTION(BlueprintCallable)
	void RemoveDialogueEpisodeByEpisodeID(int32 EpisodeID);

	UFUNCTION(BlueprintCallable)
	void RemoveDialogueLine(int32 EpisodeID, int32 LineIndex);

	UFUNCTION(BlueprintCallable)
	void RemoveDialogueLineByGUID(int32 EpisodeID, int32 GUID);

	UFUNCTION(BlueprintCallable)
	int32 GetDialogueEpisodesCount() const;

	UFUNCTION(BlueprintCallable)
	int32 GetFirstDialogueEpisodeID() const;

	UFUNCTION(BlueprintCallable)
	int32 GenerateValidEpisodeID();
	
	UFUNCTION(BlueprintCallable)
	bool GenerateGUIDForLines();
	bool LinkSectionsAndLines();

	void AddDialogueEpisodeOption(int32 EpisodeID, FGuid PinID);
	void RemoveDialogueEpisodeOption(int32 EpisodeID, FGuid PinID);

	UFUNCTION(BlueprintCallable)
	void RemoveAllUnReferencedObject();

    UFUNCTION(BlueprintCallable)
    void MatchActorInfosAndPerformers();

	virtual void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;
public:
	//修改TrackName
	virtual void RenameTrackName(const FString& OldTrackName, const FString& NewTrackName) override;
	
	UFUNCTION()
	void SetCurrentSelectEpisodeID(int32 EpisodeID);

	UFUNCTION()
	int32 GetCurrentSelectEpisodeID() const;

	/** Broadcasts when CurrentSelectEpisodeID changes */
	DECLARE_EVENT(UDialogueAsset, FOnDialogueEpisodeChangedEvent);
	FOnDialogueEpisodeChangedEvent& OnDialogueEpisodeChanged() { return OnDialogueEpisodeChangedEvent; }


	DECLARE_EVENT(UDialogueAsset, FOnDialogueAssetTemplateChangedEvent);
	FOnDialogueAssetTemplateChangedEvent& OnDialogueAssetTemplateChanged() { return OnDialogueAssetTemplateChangedEvent; }

	DECLARE_EVENT_OneParam(UDialogueAsset, FOnCustomSelectorChangedEvent, FString);
	FOnCustomSelectorChangedEvent& OnCustomSelectorChanged() {
		return OnCustomSelectorChangedEvent;
	}

	DECLARE_DELEGATE(FOnEpisodeLinesCountChange);
	FOnEpisodeLinesCountChange& GetOnEpisodeLinesCountChange() { return OnEpisodeLinesCountChange; }


	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	void SyncCurrentSelectEpisodeLine();

	void RefreshOnChangeTemplate();

	//Actor轨道数据改变后，更新ActorInfos信息
	UFUNCTION()
	void UpdateActorInfosData();

	virtual void PostLoad() override;

	UFUNCTION()
	void RefreshSelectors();

	bool FindAppreanceName(int32 InAppreancceID, FName& OutName);

	void OnCustomSelectorChanged(FString InTrackName);
	

	TMap<FString, FAppreanceTableData> AppearanceTableData;


private:
	FOnDialogueAssetTemplateChangedEvent OnDialogueAssetTemplateChangedEvent;
	FOnEpisodeLinesCountChange OnEpisodeLinesCountChange; //增删EpisodeNode

	FOnCustomSelectorChangedEvent OnCustomSelectorChangedEvent;

	FOnDialogueEpisodeChangedEvent OnDialogueEpisodeChangedEvent;

#endif
};

inline void UDialogueAsset::OnEpisodeAdded(FDialogueEpisode& NewEpisode, int32 InEpisodeID)
{
	Super::OnEpisodeAdded(NewEpisode, InEpisodeID);
#if WITH_EDITORONLY_DATA
	//增加集数的参考数据
	const FDialogueEpisode* CopyTemplateEpisode = nullptr;
	if(Episodes.Num() >= 1)
	{
		// 如果DialogueAsset已有数据，则使用第0个数据（因为所有Episode的数据相同，所以使用第0个即可）
		CopyTemplateEpisode = &Episodes[0];
	}
	else if (DialogueTemplate && DialogueTemplate->Episodes.Num() >= 1)
	{
		//如果当前没有数据，则使用模板的数据
		CopyTemplateEpisode = &DialogueTemplate->Episodes[0];
	}

	checkf(CopyTemplateEpisode != nullptr, TEXT("Dialogue asset has not template"));

	if (CopyTemplateEpisode)
	{
		UKGSLDialogueEpisode* Script = GetDialogueEpisodeByEpisodeID(InEpisodeID);
		if (Script != nullptr)
		{
			NewEpisode.OptionType = Script->OptionType;
			NewEpisode.EpisodeID = Script->EpisodeID;
			NewEpisode.TimeLimit = Script->TimeLimit;
			NewEpisode.TimeOutDefaultChoice = Script->TimeOutDefaultChoice;
		}
		                
		for (int32 j = 0; j < CopyTemplateEpisode->TrackList.Num(); ++j)
		{
			auto* Track = CopyTemplateEpisode->TrackList[j];
			auto* NewTrack = RoamTrack(Track);
			AddTrackByEpisodeID(InEpisodeID, NewTrack,-1);
		}
	}
#endif
}

#undef LOCTEXT_NAMESPACE
