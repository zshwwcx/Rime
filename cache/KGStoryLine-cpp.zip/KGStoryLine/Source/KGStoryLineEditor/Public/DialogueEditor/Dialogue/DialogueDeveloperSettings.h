// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "UObject/SoftObjectPtr.h"
#include "DialogueDeveloperSettings.generated.h"

/**
 * 
 */
UCLASS(config = Game, defaultconfig)
class KGSTORYLINEEDITOR_API UDialogueDeveloperSettings : public UDeveloperSettings
{
	GENERATED_BODY()
	
public:
	//黑屏section
	UPROPERTY(EditDefaultsOnly, Config)
	TSoftClassPtr<class UDialogueActionBase>   FadeInOutSectionClass;

	//白字旁白section
	UPROPERTY(EditDefaultsOnly, Config)
	TSoftClassPtr<class UDialogueActionBase>   AsideSectionClass;
};
