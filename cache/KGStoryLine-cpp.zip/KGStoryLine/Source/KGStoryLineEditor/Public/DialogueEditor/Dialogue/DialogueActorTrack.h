#pragma once

#include "DialogueEditor/Dialogue/DialogueTrackBase.h"

#include "DialogueActorTrack.generated.h"

UCLASS(Blueprintable, EditInlineNew, HideDropdown, meta=(DisplayName="Actor"))
class KGSTORYLINEEDITOR_API UDialogueActorTrack : public UDialogueSpawnableTrack
{
	GENERATED_BODY()
	
public:
	UDialogueActorTrack();
	virtual EDialogueTrack::Type GetType() const override;

    // UDialogueActorTrack是由Excel表中配置的演员信息生成，必须跟Excel数据匹配，不能随意复制轨道
    virtual bool CanCopy() const override { return false; }


	static int32 TrackCount;
};

UCLASS(Blueprintable, EditInlineNew, meta=(DisplayName="Actor"))
class KGSTORYLINEEDITOR_API UDialoguePerformerTrack : public UDialogueActorTrack
{
	GENERATED_BODY()
public:
	UDialoguePerformerTrack();

    // UDialoguePerformerTrack是由剧编菜单生成，可以随意复制
    virtual bool CanCopy() const override { return true; }
};