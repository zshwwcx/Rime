#pragma once
#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "DialogueCommon.generated.h"
#if WITH_EDITOR
DECLARE_DELEGATE(FOnStructChange);
#endif

class UDialogueAsset;
class UDialogueBaseAsset;
USTRUCT(BlueprintType)
struct KGSTORYLINEEDITOR_API FDialogueCameraSelector
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite)
	FString CameraName;

#if WITH_EDITORONLY_DATA
public:
	FOnStructChange OnStructChange;
#endif
};

USTRUCT(BlueprintType)
struct KGSTORYLINEEDITOR_API FDialoguePerformerSelector
{
	GENERATED_USTRUCT_BODY()

public:
	FDialoguePerformerSelector() {}
	FDialoguePerformerSelector(FString InName)
		:PerformerName(InName)
	{

	}
	UPROPERTY(EditDefaultsOnly)
	FString PerformerName;

#if WITH_EDITORONLY_DATA
public:
	FOnStructChange OnStructChange;
#endif
};


USTRUCT(BlueprintType)
struct KGSTORYLINEEDITOR_API FBehaviorActorSelector
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
		FName TrackName;
public:
	//为了方便快速选择，现在检测的目标Owner就是当前编辑器打开的资产
	static inline TWeakObjectPtr<UDialogueBaseAsset> Owner = nullptr;

	static bool IsDialogueEditorOpen() { return Owner.IsValid();}
};

USTRUCT()
struct KGSTORYLINEEDITOR_API FDialogueAppearanceSelector
{
	GENERATED_BODY()

public:
	FDialogueAppearanceSelector() {}
	FDialogueAppearanceSelector(int32 InApperanceID)
		:ApperanceID(InApperanceID)
	{

	}

	UPROPERTY(EditDefaultsOnly)
		int32 ApperanceID = 0;

#if WITH_EDITORONLY_DATA
public:
	UPROPERTY(Transient)
		UDialogueAsset* Owner;
#endif
};

