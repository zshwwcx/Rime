// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "Dialogue3CAction.generated.h"

/**
 * UDialogue3CMoveAction
 */
UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogue3CMoveAction : public UDialogueActionBase
{
    GENERATED_BODY()
public:
    UFUNCTION(BlueprintCallable)
    void OnEntityTransformChanged();
    
    virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#if WITH_EDITOR
    virtual void OnEditorInitialized() override;
#endif
private:
    UPROPERTY(Transient)
    class UDialogueEntity* LastTargetEntityBound = nullptr;

    FDelegateHandle OnEntityTransformChangedDelegateHandle;
};


/**
 * UDialogue3CTurnAction
 */
UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogue3CTurnAction : public UDialogueActionBase
{
    GENERATED_BODY()

    virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
};