#pragma once

#include "DialogueEditor/Dialogue/DialogueTrackBase.h"

#include "DialogueCameraTrack.generated.h"

UCLASS(Blueprintable, EditInlineNew, meta = (DisplayName = "相机"))
class KGSTORYLINEEDITOR_API UDialogueCameraTrack : public UDialogueSpawnableTrack
{
	GENERATED_BODY()
	UDialogueCameraTrack()
	{
#if WITH_EDITOR
		NamePrefix = TEXT("Camera");
#endif
	}

public:
#if WITH_EDITOR
	virtual FString GetEditorPreviewName() override;
#endif

public:
	virtual EDialogueTrack::Type GetType() const override
	{
		return EDialogueTrack::Type::Camera;
	}

	// 标记该Track是否为自动创建的机位
	UPROPERTY()
	bool bAutoCameraTrack = false;

	static int32 TrackCount;
};