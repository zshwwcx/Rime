#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"

#include "DialogueAnimInstance.generated.h"

/**
 * 剧情动画蓝图基类
 */
UCLASS(BlueprintType, Blueprintable)
class KGSTORYLINEEDITOR_API UDialogueAnimInstance : public UAnimInstance
{
	GENERATED_UCLASS_BODY()
	
//public:
	
	/*UFUNCTION(BlueprintCallable, Category = "DialogueAnim")
	UAnimSequenceBase* GetSingleAnimAsset() {
		return SingleAnimAsset;
	}

	void SetSingleAnimAsset(UAnimSequenceBase* InAnimAsset) {
		SingleAnimAsset = InAnimAsset;
	}

	UFUNCTION(BlueprintCallable, Category = "DialogueAnim")
	UAnimSequenceBase* GetIdleAnimAsset() {
		return IdleAnimAsset;
	}

	UFUNCTION(BlueprintCallable, Category = "DialogueAnim")
	void SetIdleAnimAsset(UAnimSequenceBase* InAnimAsset) {
		IdleAnimAsset = InAnimAsset;
	}

	UFUNCTION(BlueprintCallable, Category = "DialogueAnim")
	FVector GetLookAtLocation() {
		return LookAtLocation;
	}

	UFUNCTION(BlueprintCallable, Category = "DialogueAnim")
	void SetLookAtLocation(FVector InLocation) {
		LookAtLocation = InLocation;
	}

	UFUNCTION(BlueprintCallable, Category = "DialogueAnim")
	bool GetLookAtEnable() {
		return bLookAtEnable;
	}

	UFUNCTION(BlueprintCallable, Category = "DialogueAnim")
	void SetLookAtEnable(bool InEnable)
	{
		bLookAtEnable = InEnable;
	}

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = "DialogueAnim")
		float GetInterpolationTime();*/
	/*{
		return InterpolationTime;
	}*/

	/*UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = "DialogueAnim")
		void SetInterpolationTime(float InInterpolationTime);*/
	/*{
		InterpolationTime = InInterpolationTime;
	}*/

//private:
//	UAnimSequenceBase* SingleAnimAsset = nullptr;
//
//	UAnimSequenceBase* IdleAnimAsset = nullptr;
//
//	FVector LookAtLocation;
//
//	bool bLookAtEnable=true;

	/*float InterpolationTime = 0.f;*/
};