#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueCameraMove.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueCameraMove : public UDialogueActionBase
{
	GENERATED_BODY()

public:
	UDialogueCameraMove();
};