#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "Animation/AnimSequenceBase.h"
#include "DialogueIdleState.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueIdleState : public UDialogueActionBase
{
	GENERATED_BODY()

public:
	UFUNCTION()
	void SetAnimation(class UAnimationAsset* Src)
	{
		AnimAsset = Src;
	}
	// 动画资源
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> AnimAsset = NULL;
};