#pragma once

#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"

#include "DialogueActionTrack.generated.h"


namespace EDialogueAction
{
	enum Type
	{
		Animation,
		Transform
	};
}

// 行为类的轨道
UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueActionTrack : public UDialogueTrackBase
{
	GENERATED_BODY()

public:
	UPROPERTY(meta=(ExportObjectComplete))
	TArray<UDialogueActionBase*> ActionSections;

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class UDialogueActionBase> SectionType;

	UPROPERTY(EditDefaultsOnly)
	int32 Priority = 0;

	void SetSectionType(UClass* Type) { SectionType = Type; }

	virtual UClass* GetSecondSectionType() { return nullptr; }

	virtual EDialogueTrack::Type GetType() const override;

	UFUNCTION(BlueprintCallable)
	void AddSection(UDialogueActionBase* Section);

	UFUNCTION(BlueprintCallable)
	void RemoveSection(UDialogueActionBase* Section);
	//拖动或者调整一个Section的位置、起始时间时，可能会和其他Section重叠，调用这个接口对其他Section进行调整
	void AdjustOtherSectionData(class UDialogueActionBase* TargetSection);
	UFUNCTION(BlueprintCallable)
	TArray<UDialogueActionBase*> GetOrderedSections();

	virtual void DuplicateFromTrack(UDialogueTrackBase* Track) override;

	// 清理异常的section
	virtual void PostLoad() override;
#if WITH_EDITOR
    virtual void OnEditorInitialized() override;
#endif
};
