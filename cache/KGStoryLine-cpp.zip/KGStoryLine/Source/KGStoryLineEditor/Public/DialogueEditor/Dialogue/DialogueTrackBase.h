#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"

#include "DialogueTrackBase.generated.h"


namespace EDialogueTrack
{
	enum class Type
	{
		Base,
		Actor,
		Camera,
		CameraCut,
		Dialogue,
		Animation,
		StateControl,
		Blueprint,
		RoutePoint,
		SplineActor,
		AutoCameraCut,
		Shot,
	};
}


UCLASS(Abstract, Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueTrackBase : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(meta=(ExportObjectComplete))
	TArray<UDialogueTrackBase*> Childs;

	UPROPERTY(meta=(ExportObjectByProperty="TrackName"))
	UDialogueTrackBase* Parent=nullptr;

#if WITH_EDITORONLY_DATA
	//用来辅助编辑器预览，毕竟编辑器里面看什么Actor2 Actor3容易混淆
	UPROPERTY()
	FString EditorPreview;

	//该Track是否是从模板里面添加的，用于标识Actor的来源
	UPROPERTY()
	bool FromTemplate = true;
#endif
protected:
	UPROPERTY(EditDefaultsOnly)
	FString TrackName;

public:
	UPROPERTY(meta=(ExportObjectComplete))
	TArray<class UDialogueActionTrack*> Actions;

public:
#if WITH_EDITOR
	virtual FString GetEditorPreviewName() { return TEXT(""); };
	virtual FString GetEditorPreviewFullName() { return TEXT(""); };
    virtual void OnEditorInitialized();
#endif
	UFUNCTION(BlueprintCallable)
	FText GetTrackName() { return FText::FromString(TrackName); }
	void SetTrackName(FText Name) { TrackName = Name.ToString(); }

	class UDialogueBaseAsset* GetOwningDialogueAsset();
	
	virtual EDialogueTrack::Type GetType() const 
	{
		return EDialogueTrack::Type::Base;
	}

	void AddChild(UDialogueTrackBase* Track) { Childs.Add(Track); }

	//获取包括子层级的所有Track
	void GetAllChildTracks(TArray<UDialogueTrackBase*>& ChildTracks);

	
	//查找Childs里面名称为TrackName的Track
	UFUNCTION()
	UDialogueTrackBase* FindChild(const FString& InTrackName);

	//查找Actions里面名称为TrackName的Track
	UFUNCTION()
	UDialogueActionTrack* FindAction(const FString& InTrackName);

	
	void InsertChild(UDialogueTrackBase* Track, int32 Index)
	{
		Childs.Insert(Track, Index);
	}

	UFUNCTION()
	void AddAction(class UDialogueActionTrack* Action);

	UFUNCTION()
	void RemoveAction(class UDialogueActionTrack* Action)
	{
		Actions.Remove(Action);
	}

#if WITH_EDITOR
	virtual void DuplicateFromTrack(UDialogueTrackBase* Track) 
	{ 
		TrackName = Track->TrackName; 
		FromTemplate = Track->FromTemplate;
	}
#endif
};

UCLASS(Abstract, Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueSpawnableTrack : public UDialogueTrackBase
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	class UDialogueEntity* GetDialogueEntity();

	void SetDialogueEntity(class UDialogueEntity* InDialogueEntity);

	UFUNCTION()
		class UDialogueActionTrack* GetActionByClass(UClass* InClass);

#if WITH_EDITOR
	virtual void DuplicateFromTrack(UDialogueTrackBase* Track);
	UFUNCTION(BlueprintCallable)
	virtual FString GetEditorPreviewName();
	virtual FString GetEditorPreviewFullName();
    virtual bool CanCopy() const { return true; }
#endif

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditDefaultsOnly)
	FString NamePrefix = TEXT("RoutePoint");
	//是否应该在每个Episode生成一个副本Track（比如Actor这种）
	UPROPERTY(EditDefaultsOnly)
	bool    ExistInPerEpisode = true;
#endif
protected:
	UPROPERTY(VisibleAnywhere, meta=(ExportObjectByProperty="TrackName"))
	class UDialogueEntity* DialogueEntity = nullptr;
};