#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"
#include "Components/SplineComponent.h"
#include "DialogueEntitySpline.generated.h"

UCLASS(Blueprintable)
class KGSTORYLINEEDITOR_API UDialogueEntitySpline : public UDialogueEntity
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	FSplineCurves SplineCurves;

public:
	virtual void DuplicateFromEntityInfo_Implementation(UDialogueEntity* InEntity) override;
};

