#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/Dialogue/Actions/DialogueCameraCut.h"
#include "DialogueEditor/Dialogue/DialogueCommon.h"
#include "DialogueEditor/Dialogue/DialogueCameraTrack.h"
#include "DialogueAutoCameraCut.generated.h"


UENUM(BlueprintType)
enum class EDialogueAutoCameraType : uint8
{
	OneActor = 0 UMETA(DisplayName = "单人镜头"),
	TwoActorTypeOne UMETA(DisplayName = "双人镜头过肩"),
	TwoActorTypeTwo UMETA(DisplayName = "双人镜头侧视"),
};

UENUM(BlueprintType)
enum class EDialogueOneActorTemplate : uint8
{
	Type1 = 0 UMETA(DisplayName = "左侧-半身像-微俯视1"),
	Type2 UMETA(DisplayName = "左侧-半身像-微俯视2"),
	Type3 UMETA(DisplayName = "左侧-半身像-仰视"),
	Type4 UMETA(DisplayName = "左侧-胸像-微俯视"),
	Type5 UMETA(DisplayName = "左侧-胸像-平视"),
	Type6 UMETA(DisplayName = "左侧-面像-平视"),
	Type7 UMETA(DisplayName = "左侧-全身像-平视"),
	Type8 UMETA(DisplayName = "右侧-半身像-微俯视"),
	Type9 UMETA(DisplayName = "右侧-半身像-仰视"),
	Type10 UMETA(DisplayName = "右侧-胸像-微俯视"),
	Type11 UMETA(DisplayName = "右侧-胸像-平视"),
	Type12 UMETA(DisplayName = "右侧-面像-平视"),
	Type13 UMETA(DisplayName = "右侧-全身像-平视"),
	Type14 UMETA(DisplayName = "正中-半身像-微俯视"),
	Type15 UMETA(DisplayName = "正中-半身像-仰视"),
	Type16 UMETA(DisplayName = "正中-胸像-微俯视"),
	Type17 UMETA(DisplayName = "正中-面像-平视1"),
	Type18 UMETA(DisplayName = "正中-面像-平视2"),
	Type19 UMETA(DisplayName = "正中-全身像-平视"),
};

UENUM(BlueprintType)
enum class EDialogueTwoActorTypeOneTemplate : uint8
{
	Type1 = 0 UMETA(DisplayName = "越肩模式1（测试）"),
	Type2 UMETA(DisplayName = "左侧-越肩视角"),
	Type3 UMETA(DisplayName = "左侧-背视视角"),
	Type4 UMETA(DisplayName = "左侧-腰部视角"),
	Type5 UMETA(DisplayName = "左侧-同向视角1"),
	Type6 UMETA(DisplayName = "左侧-同向视角2"),
	Type7 UMETA(DisplayName = "左侧-平视1"),
	Type8 UMETA(DisplayName = "左侧-平视2"),
	Type9 UMETA(DisplayName = "右侧-越肩视角"),
	Type10 UMETA(DisplayName = "右侧-背视视角"),
	Type11 UMETA(DisplayName = "右侧-腰部视角"),
	Type12 UMETA(DisplayName = "右侧-同向视角1"),
	Type13 UMETA(DisplayName = "右侧-同向视角2"),
	Type14 UMETA(DisplayName = "右侧-平视1"),
	Type15 UMETA(DisplayName = "右侧-平视2"),
};

UENUM(BlueprintType)
enum class EDialogueTwoActorTypeTwoTemplate : uint8
{
	Type1 = 0 UMETA(DisplayName = "侧视模式1"),
};

UCLASS(Blueprintable, EditInlineNew, meta = (DisplayName = "自动镜头"))
class KGSTORYLINEEDITOR_API UDialogueAutoCameraCutTrack : public UDialogueActionTrack
{
	GENERATED_BODY()

public:
	UDialogueAutoCameraCutTrack();

public:
	EDialogueTrack::Type GetType() const override;
};

UCLASS(BlueprintType)
class UMyCustomString : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Custom Property")
	TArray<FString> CustomValues;
};


UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueAutoCameraCut : public UDialogueCameraCut
{
	GENERATED_BODY()

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "镜头类型", show))
	EDialogueAutoCameraType AutoCameraType;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "单人镜头模板", EditCondition = "AutoCameraType == EDialogueAutoCameraType::OneActor", EditConditionHides))
	EDialogueOneActorTemplate OnePersonTemplate;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera",
		meta = (DisplayName = "双人镜头过肩模板", EditCondition = "AutoCameraType == EDialogueAutoCameraType::TwoActorTypeOne", EditConditionHides))
	EDialogueTwoActorTypeOneTemplate TwoPersonTypeOneTemplate;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera",
		meta = (DisplayName = "双人镜头侧视模板", EditCondition = "AutoCameraType == EDialogueAutoCameraType::TwoActorTypeTwo", EditConditionHides))
	EDialogueTwoActorTypeTwoTemplate TwoPersonTypeTwoTemplate;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "Fov"))
	float CameraFovX;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "Yaw"))
	float CameraYaw;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera",
		meta = (DisplayName = "Pitch", EditCondition = "AutoCameraType != EDialogueAutoCameraType::TwoActorTypeOne", EditConditionHides))
	float CameraPitch;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "Actor1的H", UIMin = "-1", UIMax = "2"))
	float ActorFocusH;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "Actor1的V", UIMin = "-1", UIMax = "2"))
	float ActorFocusV;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera",
		meta = (DisplayName = "Actor2的H", EditCondition = "AutoCameraType != EDialogueAutoCameraType::OneActor", EditConditionHides, UIMin = "-1", UIMax = "2"))
	float ActorBackendH;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera",
		meta = (DisplayName = "Actor2的V", EditCondition = "AutoCameraType == EDialogueAutoCameraType::TwoActorTypeOne", EditConditionHides, UIMin = "-1", UIMax = "2"))
	float ActorBackendV;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "Actor的距离", EditCondition = "AutoCameraType == EDialogueAutoCameraType::OneActor", EditConditionHides))
	float ActorFocusDist;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "Actor1"))
	FDialoguePerformerSelector Actor1P;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "Actor2", EditCondition = "AutoCameraType != EDialogueAutoCameraType::OneActor", EditConditionHides))
	FDialoguePerformerSelector Actor2P;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera", meta = (DisplayName = "是否始终跟随头部"))
	bool AutoFocus;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "AutoCamera")
	UMyCustomString* CustomString;

	//DOF焦点
	UPROPERTY(EditDefaultsOnly, Category = DOF)
	bool bOpenDOF = false;

	//DOF焦点
	UPROPERTY(EditDefaultsOnly, Category = DOF)
	float DepthOfFieldFocalDistance = 0;

	//DOF焦点Actor
	UPROPERTY(EditDefaultsOnly, Category = DOF)
	FDialoguePerformerSelector DepthOfFieldFocusActor;

	//DOF大小
	UPROPERTY(EditDefaultsOnly, Category = DOF)
	float DepthOfFieldFStop = 4.0f;

	//DOF清晰度
	UPROPERTY(EditDefaultsOnly, Category = DOF, meta = (ClampMin = "0.1", UIMin = "0.1", UIMax = "200.0"))
	float DepthOfFieldSensorWidth = 30.0f;

public:
#if WITH_EDITOR
	UFUNCTION(BlueprintCallable)
	void OnSetTableData(TMap<FString, FString> TableData);
#endif
};
