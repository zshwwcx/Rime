#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Components/SplineComponent.h"
#include "DialogueEditor/Dialogue/DialogueCommon.h"
#include "3C/Animation/AnimAssetDefine.h"
#include "UObject/ConstructorHelpers.h"
#include "Camera/CameraComponent.h"
#include "Materials/Material.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Kismet/KismetMathLibrary.h"
#include "DialogueEntity.generated.h"



UCLASS(Abstract, Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueEntity : public UObject
{
	GENERATED_BODY()

public:
	UDialogueEntity(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
	
	virtual void BeginDestroy() override;

	DECLARE_EVENT(UDialogueEntity, FOnEntityTransformChangedEvent);

	FOnEntityTransformChangedEvent& OnEntityTransformChanged() { return OnEntityTransformChangedEvent; }

	virtual void PostLoad() override;

	UFUNCTION(BlueprintCallable)
	AActor* GetEntity() const;

	UFUNCTION(BlueprintCallable)
	virtual void SetEntity(AActor* InActor);

	UFUNCTION(BlueprintCallable)
	FTransform GetParentTransform() const;

	UFUNCTION(BlueprintCallable)
	FTransform GetWorldSpawnTransform() const;

	UFUNCTION(BlueprintCallable)
	TSubclassOf<AActor> GetActorClass() const;

	UFUNCTION(BlueprintCallable)
	bool GetDefaultVisible() const;

	UFUNCTION()
	UDialogueEntity* GetParentEntity()const { return Parent.Get();};

	void OnParentEntityTransformChanged();

public:
	UPROPERTY(EditDefaultsOnly, Category="基础", meta=(EditCondition = "bDefaultObj", EditConditionHides, HideEditConditionToggle))
	TSubclassOf<AActor> ActorClass;

	UPROPERTY(EditDefaultsOnly, Category="基础", meta = (DisplayName = "变换"))
	FTransform SpawnTransform = FTransform::Identity;

	UPROPERTY()
	FString TrackName;

	UPROPERTY(Transient)
	bool bDefaultObj = false;
	
	UPROPERTY(EditDefaultsOnly, Category="基础", meta = (DisplayName = "是否贴地", Tooltips = "如果自动贴地，则调整位置时会自动放置在Z下方的物体上"))
	bool StickGround = false;

protected:
	TWeakObjectPtr<AActor> Entity = nullptr;

	UPROPERTY(meta=(ExportObjectByProperty="TrackName"))
	TWeakObjectPtr<UDialogueEntity> Parent;

	UPROPERTY(EditDefaultsOnly, Category="基础", meta = (DisplayName = "默认是否可见"))
	bool bDefaultVisible = true;

	//跟随父节点的骨骼，为空表示不跟随，为root表示不跟骨骼只跟角色，具体字符串表示跟随骨骼
	UPROPERTY(EditDefaultsOnly, Category="基础", meta = (DisplayName = "跟随父节点骨骼"))
	FString FollowParentSocket;
	
	FOnEntityTransformChangedEvent OnEntityTransformChangedEvent;

#if WITH_EDITOR
public:
    virtual void OnEditorInitialized();
	UFUNCTION()
	virtual void OnSpawnTransformChanged() const;

	void SetParent(TWeakObjectPtr<UDialogueEntity> InParent);

	UFUNCTION()
	virtual void UpdateSpawnTransform();

	UFUNCTION()
	virtual void OnEntityMoved();

	virtual bool CanEditChange(const FProperty* InProperty) const override;
#endif

	//从另一个Entity里面拷贝数据，主要用在对话资产从对话模板里面拷贝数据的情况
	UFUNCTION(BlueprintNativeEvent)
		void DuplicateFromEntityInfo(UDialogueEntity* InEntity);
	virtual void DuplicateFromEntityInfo_Implementation(UDialogueEntity* InEntity);

};

UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueCamera : public UDialogueEntity
{
	GENERATED_UCLASS_BODY()

public:
	//UDialogueCamera(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	UFUNCTION(BlueprintCallable)
	class ACameraActor* GetCamera() const;
	UFUNCTION()
	float GetFOV();

	UFUNCTION(BlueprintCallable)
	void SetFOV(const float InFov) { FOV = InFov; }

	virtual void DuplicateFromEntityInfo_Implementation(UDialogueEntity* InEntity) override;
	virtual void PostLoad() override;
    virtual void SetEntity(AActor* InActor) override;
private:
	void AddDefaultPositionSplineCurvePoint();
	void AddDefaultReparamTableSplineCurvePoint();
	void AddDefaultRotationSplineCurvePoint();
	void AddDefaultScaleSplineCurvePoint();
#if WITH_EDITOR
public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void OnEntityMoved() override;
#endif
public:
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "广角FOV"))
	float FOV=90.0f;

	//开启后，自动适配不同身高的角色
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "锁头开关"))
	uint8	bEnableLookAt:1;
	//开启注视后的注释目标，需要是Actor
	UPROPERTY(EditDefaultsOnly, meta = (EditCondition = "bEnableLookAt", EditConditionHides, DisplayName = "指定对象"))
	FDialoguePerformerSelector LookAtTarget;
	//开启注视后注释目标的骨骼
	UPROPERTY(EditDefaultsOnly, meta = (EditCondition = "bEnableLookAt", EditConditionHides, DisplayName = "指定骨骼"))
	FName BoneName = TEXT("head");
	//偏移量自动计算，不需要调整
	UPROPERTY(BlueprintReadWrite, VisibleDefaultsOnly, meta = (EditCondition = "bEnableLookAt", EditConditionHides, DisplayName = "高度偏移"))
	float OffsetZ;

	//DOF的启用与否，只用这1个变量控制即可
	UPROPERTY(EditDefaultsOnly,BlueprintReadOnly, Category = DOF, meta = (DisplayName = "景深DOF开启"))
	uint8 bOverride_DepthOfField : 1;

	// 选择对焦角色后，自动调整距离
	UPROPERTY(EditDefaultsOnly, Category = DOF, meta = (Editcondition = "bOverride_DepthOfField", EditConditionHides, DisplayName = "对焦角色"))
	FDialoguePerformerSelector DepthOfFieldFocusActor;
	
	UFUNCTION()
	float GetOverride_DepthOfField() {return bOverride_DepthOfField;};

	//DOF焦点
	UPROPERTY(EditDefaultsOnly, Category = DOF, meta = (Editcondition = "bOverride_DepthOfField", EditConditionHides, DisplayName = "焦点距离"))
	float DepthOfFieldFocalDistance = 100.0f;
	
	// 光圈大小，数值越小，背景越虚化
	UPROPERTY(EditDefaultsOnly, Category = DOF, meta = (Editcondition = "bOverride_DepthOfField", EditConditionHides, DisplayName = "景深DOF大小"))
	float DepthOfFieldFStop = 30.0f;

	
	
	UFUNCTION()
	float GetDepthOfFieldFocalDistance() { return DepthOfFieldFocalDistance; };
	
	UFUNCTION()
	float GetDepthOfFieldFStop() { return DepthOfFieldFStop; };
	
	//DOF清晰度
	UPROPERTY(EditDefaultsOnly, Category = DOF, meta = (Editcondition = "bOverride_DepthOfField", EditConditionHides, DisplayName = "清晰度", ClampMin = "0.1", UIMin = "0.1", UIMax = "1000.0"))
	float DepthOfFieldSensorWidth = 100.0f;
	UFUNCTION()
	float GetDepthOfFieldSensorWidth() { return DepthOfFieldSensorWidth; };

	//Mobile设置这个参数，清晰区域，从DepthOfFieldFocalDistance开始计算
	UPROPERTY(EditDefaultsOnly, Category = "DOF|Mobile", meta = (Editcondition = "bOverride_DepthOfField", EditConditionHides))
	float DepthOfFieldFocalRegion;
	UFUNCTION()
	float GetDepthOfFieldFocalRegion() { return DepthOfFieldFocalRegion; };

	//Mobile设置这个参数,数值越大，清晰区域到近相机区域越清晰，越小越模糊
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DOF|Mobile", meta = (UIMin = "0.0", UIMax = "10000.0", Editcondition = "bOverride_DepthOfField", EditConditionHides))
	float DepthOfFieldNearTransitionRegion = 10000.0f;
	UFUNCTION()
	float GetDepthOfFieldNearTransitionRegion() { return DepthOfFieldNearTransitionRegion; };

	//Mobile设置这个参数,数值越大，清晰区域到远相机区域越清晰，越小越模糊
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "DOF|Mobile", meta = (UIMin = "0.0", UIMax = "10000.0", Editcondition = "bOverride_DepthOfField", EditConditionHides))
	float DepthOfFieldFarTransitionRegion = 10000.0f;
	UFUNCTION()
	float GetDepthOfFieldFarTransitionRegion() { return DepthOfFieldFarTransitionRegion; };
	
	/** Create Debug Focus Plane for DOF Visualization */
	UFUNCTION()
	void CreateDebugFocusPlane();
	/** Update the debug focus plane position and orientation. */
	UFUNCTION()
	void UpdateDebugFocusPlane();
	/** Destroy Debug Focus Plane for DOF Visualization */
	UFUNCTION()
	void DestroyDebugFocusPlane();
    
#if WITH_EDITORONLY_DATA
	//用于在编辑器中实现景深可视化功能
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = DOF, DisplayName = "景深可视化调试" , meta = (Editcondition = "bOverride_DepthOfField", EditConditionHides))
	bool bEnableCameraDOF_Debug = false;
	/** Mesh used for debug focus plane visualization */
	UPROPERTY(transient)
	TObjectPtr<UStaticMesh> FocusPlaneVisualizationMesh;

	/** Material used for debug focus plane visualization */
	UPROPERTY(transient)
	TObjectPtr<UMaterial> FocusPlaneVisualizationMaterial;
	
	/** Component for the debug focus plane visualization */
	UPROPERTY(transient)
	TWeakObjectPtr<UStaticMeshComponent> DebugFocusPlaneComponent;

	/** Dynamic material instance for the debug focus plane visualization */
	UPROPERTY(transient)
	TWeakObjectPtr<UMaterialInstanceDynamic> DebugFocusPlaneMID;

	/** For customizing the focus plane color, in case the default doesn't show up well in your scene. */
	UPROPERTY(EditAnywhere, Category = DOF, meta = (EditCondition = "bEnableCameraDOF_Debug", EditConditionHides))
	FColor DebugFocusPlaneColor;

	float GetDesiredFocusDistance(const FVector& InLocation) const;

#endif
};

UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueActor : public UDialogueEntity
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "NPC ID"))
	int32 AppearanceID = 1200001;

	//角色的默认Idle动画
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "初始动画"))
	FAnimLibAssetID  IdleAnimLibAssetID;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "在无镜对话中使用真实NPC", ToolTips = "如果使用场景角色替换，需要填写InsID"))
	bool UseSceneActor = false;

	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "场景角色InsID", ToolTips = "如果使用场景角色替换，需要填写InsID", EditCondition = "UseSceneActor", EditConditionHides))
	FString InsID;

    UPROPERTY(VisibleAnywhere, Transient,  Category="基础", meta = (DisplayName = "模型库缩放系数", EditCondition=false))
    FVector ScaleInModelLib = {1, 1, 1};

	void SetIsPlayer(bool InIsPlayer) { bIsPlayer = InIsPlayer; }
    virtual void SetEntity(AActor* InActor) override;
	UFUNCTION(BlueprintCallable)
	bool IsPlayer() const { return bIsPlayer; }
	UFUNCTION(BlueprintCallable)
	int32 GetAppearanceID() { return AppearanceID; }

    UFUNCTION()
    void SetScaleInModelLibFromLua(float InScale);

	void CopyFromActorInfo(const struct FDialogueActorInfo* DialogueActorInfo);
	void CopyToActorInfo(struct FDialogueActorInfo* DialogueActorInfo);
	virtual void DuplicateFromEntityInfo_Implementation(UDialogueEntity* InEntity) override;
private:
	UPROPERTY(EditDefaultsOnly, meta = (DisplayName = "是否为玩家"))
	bool bIsPlayer = false;

    void AdjustScaleByModelLibScale();
#if WITH_EDITOR
public:
	virtual void PostEditChangeChainProperty(struct FPropertyChangedChainEvent& PropertyChangedEvent) override;

    virtual void UpdateSpawnTransform() override;
    virtual void OnEntityMoved() override;
    virtual void OnSpawnTransformChanged() const override;
#endif
};
