#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"

#include "DialogueShotAction.generated.h"

UENUM(BlueprintType)
enum class EDialogueCameraSwitchType : uint8
{
	Instant UMETA(DisplayName="顺切"),
	Smooth UMETA(DisplayName="线性平滑过渡"),
	EaseIn UMETA(DisplayName="缓入"),
	EaseOut UMETA(DisplayName = "缓出"),
	EaseInOut UMETA(DisplayName = "缓入缓出"),
};

UENUM(BlueprintType)
enum class EDialogueShotBreathType : uint8
{
	None UMETA(DisplayName="无"),
	Left UMETA(DisplayName="左"),
	Right UMETA(DisplayName="右"),
	Top UMETA(DisplayName="上"),
	Bottom UMETA(DisplayName="下"),
	Front UMETA(DisplayName="前"),
	Back UMETA(DisplayName="后"),
	RotateLeft UMETA(DisplayName="旋转向左"),
	RotateRight UMETA(DisplayName="旋转向右"),
	RotateTop UMETA(DisplayName="旋转向上"),
	RotateBottom UMETA(DisplayName="旋转向下"),
};

UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueShotAction : public UDialogueActionBase
{
	GENERATED_BODY()

	DECLARE_DELEGATE(FOnDialogueShotSwitchTypeChanged);

public:
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

	virtual void PostLoad() override;
	
	bool IsSmooth();

	bool IsBreathShot() const;

	void UpdateBreathTimeToDuration();

	void UpdateDurationToBreathTime();

	FOnDialogueShotSwitchTypeChanged OnDialogueShotSwitchTypeChangedEvent;
};

UCLASS(Abstract, Blueprintable, EditInlineNew, meta = (DisplayName = "分镜(新)"))
class KGSTORYLINEEDITOR_API UDialogueShotTrack: public UDialogueActionTrack
{
	GENERATED_BODY()

public:
	UDialogueShotTrack();

public:
	EDialogueTrack::Type GetType() const override;

	virtual UClass* GetSecondSectionType() override;
	
#if WITH_EDITOR
	virtual FString GetEditorPreviewName() override;
#endif
};
