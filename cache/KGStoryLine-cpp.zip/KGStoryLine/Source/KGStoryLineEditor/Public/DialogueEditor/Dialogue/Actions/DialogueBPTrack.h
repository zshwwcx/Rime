// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueBPTrack.generated.h"

/**
 * 
 */
UCLASS()
class KGSTORYLINEEDITOR_API UDialogueBPTrack : public UDialogueActionTrack
{
	GENERATED_BODY()
};
