#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "Animation/AnimSequenceBase.h"
#include "DialogueAnimation.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueAnimation : public UDialogueActionBase
{
	GENERATED_BODY()

#if WITH_EDITOR
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif
    
    
    void OnBlendTypeChanged();
    void OnBlendParamsChanged(FName InPropertyName);
    void OnAnimLibItemChanged();
    void OnCustomBlendChanged(FProperty* InProperty, FName InPropertyName);
    int32 GetBlendType() const;
    bool IsAnimLibBlend() const;
    void SetShowCustomBlend(FName InPropertyName, FName InShowPropertyName, FName InDurationPropertyName, FName InBlendOpPropertyName);
public:
    void OnPreDetailShown();
};
