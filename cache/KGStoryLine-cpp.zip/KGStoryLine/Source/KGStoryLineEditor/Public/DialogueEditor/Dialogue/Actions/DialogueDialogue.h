#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "LuaOverriderInterface.h"
#include "DialogueEditor/Dialogue/DialogueActorTrack.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueDialogue.generated.h"

UCLASS(Blueprintable, EditInlineNew, meta = (DisplayName = "台本"))
class KGSTORYLINEEDITOR_API UDialogueDialogueTrack : public UDialogueActionTrack
{
	GENERATED_BODY()

public:
	UDialogueDialogueTrack();

public:
	EDialogueTrack::Type GetType() const override;
};


UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueDialogue : public UDialogueActionBase
{
	GENERATED_BODY()

public:
#if WITH_EDITOR
	virtual FText GetSectionName_Implementation() override;
#endif

	UPROPERTY(EditAnywhere, meta = (DisplayName = "可跳过"))
	bool CanSkip = true;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "是否停顿"))
	bool Pause = true;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "第几小段"))
	int32 EpisodeID = KGStoryLine::INVALID_EPISODE_ID;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "小段内第几句"))
	int32 ContentIndex = KGStoryLine::INVALID_LINE_INDEX;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "台本UI样式"))
	EDialogueContentUIType ContentUI;

	UPROPERTY(EditAnywhere, meta = (DisplayName = ""))
	bool SendOther;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "打字机速度", Tooltip = "打印机效果，每秒打印多少个字符（仅作开发调试用）"))
	int32 PrinterSpeed;

	UPROPERTY(VisibleAnywhere, meta = (DisplayName = "说话者", Tooltip = "\"说话者\"只能在Excel表中进行修改", EditCondition = "false"))
	FString Talker;

	UPROPERTY(VisibleAnywhere, meta = (DisplayName = "自定义说话人名", Tooltip = "\"自定义说话人名\"只能在Excel表中进行修改", EditCondition = "false"))
	FString TalkerName;

	UPROPERTY(VisibleAnywhere, meta = (DisplayName = "副字幕", Tooltip = "\"副字幕\"只能在Excel表中进行修改", EditCondition = "false"))
	FString SubTitle;

	UPROPERTY(VisibleAnywhere, meta = (DisplayName = "副字幕样式", Tooltip = "\"副字幕样式\"只能在Excel表中进行修改", EditCondition = "false"))
	int32 SubTitleType;

	UPROPERTY(VisibleAnywhere, meta = (DisplayName = "解释小字", Tooltip = "\"解释小字\"只能在Excel表中进行修改", EditCondition = "false"))
	FString Small;

	UPROPERTY(VisibleAnywhere, meta = (DisplayName = "解释小字位置", Tooltip = "\"解释小字位置\"只能在Excel表中进行修改", EditCondition = "false"))
	FString SmallPos;

	virtual void PostLoad() override;
};
