#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/Dialogue/DialogueCameraTrack.h"
#include "DialogueStateControl.generated.h"

UCLASS(Blueprintable, EditInlineNew, meta = (DisplayName = "流程控制"))
class KGSTORYLINEEDITOR_API UDialogueStateControlTrack : public UDialogueActionTrack
{
	GENERATED_BODY()

public:
	UDialogueStateControlTrack();

	UFUNCTION(BlueprintCallable)
	void RemoveAllSectionGeneratedByLine();
public:
	EDialogueTrack::Type GetType() const override;
};


UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueStateControl : public UDialogueActionBase
{
	GENERATED_BODY()

	virtual void PostLoad() override;

};