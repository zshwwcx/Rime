#pragma once

#include "CoreMinimal.h"
#include "KGStoryLineConst.h"
#include "UObject/Package.h"
#include "Templates/SubclassOf.h"
#include "Delegates/DelegateCombinations.h"

#include "DialogueActions.generated.h"

#ifdef WITH_EDITOR
DECLARE_DELEGATE_TwoParams(FOnSectionDataChange, UDialogueActionBase*, FName);
#endif

#define SECTION_START_TIME_DEFAULT -1.0f
#define SECTION_DURATION_DEFAULT -1.0f

// 行为轨道下的具体关键帧
UCLASS(Abstract, Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueActionBase : public UObject
{
	GENERATED_BODY()

public:
	UDialogueActionBase(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
#if WITH_EDITORONLY_DATA
	//Section所在的Action，这个变量加入较晚，需要需要获取，请使用GetDialogueAction()函数
	UPROPERTY()
	class UDialogueActionTrack* DialogueAction = nullptr;

	//本Sections和关联台本的Offset时间（用于拖拽台本Section时对应地移动本Section。拖拽本Section时，需要更新该参数）
	UPROPERTY(EditAnywhere, Category="基础", meta = (DisplayName = "与关联台本的相对偏移"))
	float LineLinkedOffset = 0.0f;
	
	//编辑器拖拽台词Section长度的时候，本Section如果关联了台词Section，则长度是否要跟着改变
	UPROPERTY(EditAnywhere, Category="基础", meta = (DisplayName = "与关联台本的长度绑定"))
	bool DurationInfluenceByDialogueSection = false;

	//本Section在编辑器下是否可以通过拖拽调整时长
	UPROPERTY(EditAnywhere, Category="基础", AdvancedDisplay, meta = (EditCondition="bDefaultObj", EditConditionHides, HideEditConditionToggle, DisplayName = "可以在编辑器中调整时长"))
	bool CanAdjustDurationInEditor = true;

	//编辑器下拖拽的时候，实时拖拽的StartTime，用于在结束的时候，进行吸附判断
	float EditorStartTime = SECTION_START_TIME_DEFAULT;
	//编辑器下拖拽的时候，实时拖拽的Duration，用于在结束的时候，进行吸附判断
	float EditorDuration = SECTION_DURATION_DEFAULT;
#endif

	UPROPERTY()
	FText SectionName = FText::FromString("Section");

	//section是否激活，方便快速激活、禁用该section效果
	UPROPERTY(EditAnywhere, Category="基础", meta = (DisplayName = "激活"))
	bool Enable = true;

	//由哪个台本生成的，对于Dialogue CameraCut来说，需要赋值，用于在编辑器里面临时存储目标DialogueLine，方便快速编辑
	UPROPERTY(VisibleDefaultsOnly, Category="基础", meta = (DisplayName = "来源台本序号"))
	int FromLineIndex = KGStoryLine::INVALID_LINE_INDEX;

	/* 关联的台词GUID */
	UPROPERTY(/*EditAnywhere, Category="基础", meta = (DisplayName = "关联台本GUID")*/)
	uint32 LineGUIDLinked = KGStoryLine::INVALID_LINE_GUID;
	
	UPROPERTY(EditAnywhere, Category="基础", meta = (DisplayName = "关联的台本"))
	FGuid LineUniqueIDLinked;
	
	/* 所属剧集的ID */
	UPROPERTY(VisibleDefaultsOnly, Category="基础", meta = (DisplayName = "关联台本所属小段"))
	int32 OwnedEpisodeID = KGStoryLine::INVALID_EPISODE_ID;

	UPROPERTY(EditAnywhere, Category="基础", meta = (DisplayName = "起始时间"))
	float StartTime = 0.0f;

	UPROPERTY(EditAnywhere, Category="基础", meta=(EditCondition="bConstant || bDefaultObj", EditConditionHides, DisplayName = "持续时间"))
	float Duration = 1.0f;

	// 是否是持续型section,单帧型的不允许设置Duration
	UPROPERTY(EditDefaultsOnly, Category="基础", meta = (EditCondition="bDefaultObj", EditConditionHides, HideEditConditionToggle, DisplayName = "持续型片段"))
	bool bConstant = true;

	UPROPERTY(Transient)
	bool bDefaultObj=false;

	//动态标识，用于外界填充对话数据
	UPROPERTY(EditAnywhere, Category="基础", meta = (DisplayName = "动态标识"))
	FString DynamicFlag;
	
	UFUNCTION(BlueprintNativeEvent)
	FLinearColor GetSectionColor();

	virtual FLinearColor GetSectionColor_Implementation() { return FLinearColor(FColor(0, 160, 160));}

	void SetStartTime(float Time) 
	{
		StartTime = Time; 
		GetPackage()->MarkPackageDirty();
	}

	void SetDuration(float Time) 
	{
		Duration = Time;
		GetPackage()->MarkPackageDirty();
	}
	void SetEnable(bool Value)
	{
		Enable = Value;
	}

	bool IsConstant() const
	{
		return bConstant;
	}

	UFUNCTION(BlueprintCallable)
	class UDialogueActionTrack* GetDialogueAction();

	UFUNCTION(BlueprintCallable)
	void SetLineUniqueIDLinked(const FGuid& InGUID);

	UFUNCTION(BlueprintCallable)
	FString GetLineUniqueIDLinkedStr() const;
	
	UFUNCTION(BlueprintCallable)
	float GetStartTime() { return StartTime; }
	UFUNCTION(BlueprintCallable)
	float GetDuration() { return Duration; }

	UFUNCTION(BlueprintCallable)
	float GetEndTime() { return StartTime + Duration; }

	virtual void SetSectionName(FText Name) { SectionName = Name; }

	//本section对应的轨道类型
	UFUNCTION(BlueprintImplementableEvent)
	TSubclassOf<class UDialogueTrackBase> GetTrackClass();

	UFUNCTION(BlueprintNativeEvent)
	void CopyFrom(UDialogueActionBase* Other);

	void CopyFrom_Implementation(UDialogueActionBase* Other);

	UFUNCTION(BlueprintNativeEvent)
	FText GetSectionName();

	virtual FText GetSectionName_Implementation() { return SectionName; }

	UFUNCTION(BlueprintNativeEvent)
	bool IsFixed();

	virtual bool IsFixed_Implementation() { return false; }

#if WITH_EDITOR
    virtual void OnEditorInitialized();
    //获取该Section的前置Section，即轨道上StartTime在This之前的Section，如果没有，则返回nullptr
	UFUNCTION(BlueprintCallable)
	class UDialogueActionBase* GetPreSection();
	//获取该Section的后置Section，即轨道上StartTime在This之后的Section，如果没有，则返回nullptr
	UFUNCTION(BlueprintCallable)
	class UDialogueActionBase* GetNextSection();
	//获取该Section的所有的后置Section，即轨道上StartTime在This之后的所有Sections，如果没有，则返回空
	UFUNCTION(BlueprintCallable)
	TArray<class UDialogueActionBase*> GetAllNextSections();
	//判断该Section是否和其他Section重叠
	UFUNCTION(BlueprintCallable)
	bool IsOverlapWithOtherSection();
	//将自己从所在的DialogueAction删除
	UFUNCTION(BlueprintCallable)
	bool RemoveSelfFromAction(bool MarkModify=true);
	//获取本Section Start相对于前Section End的Delay时间
	UFUNCTION(BlueprintCallable)
	float GetDelay();
	
	UFUNCTION(BlueprintCallable)
	void SetEditorStartTime(float TempStart);
	UFUNCTION(BlueprintCallable)
	void SetEditorDuration(float TempDuration);
	UFUNCTION(BlueprintCallable)
	float GetEditorStartTime();
	UFUNCTION(BlueprintCallable)
	float GetEditorDuration();
	UFUNCTION(BlueprintCallable)
	float GetEditorEndTime() { return GetEditorStartTime() + GetEditorDuration(); }

	//是否正在拖拽调整前后边界
	UFUNCTION(BlueprintCallable)
	bool IsAdjustingEdge();

	class UDialogueAsset* GetDialogueAsset() const;
	
	virtual bool CanEditChange(const FProperty* InProperty) const override;

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void PostLoad() override;
	FOnSectionDataChange OnSectionDataChange;
	static float KeyFrameDefaultDuration;
#endif //  WITH_EDITOR

};