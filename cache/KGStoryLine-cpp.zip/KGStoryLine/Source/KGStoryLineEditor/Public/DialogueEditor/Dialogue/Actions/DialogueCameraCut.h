#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActionTrack.h"
#include "DialogueEditor/Dialogue/DialogueCameraTrack.h"
#include "DialogueEditor/Dialogue/DialogueCommon.h"
#include "DialogueCameraCut.generated.h"

UCLASS(Blueprintable, EditInlineNew, meta = (DisplayName = "分镜"))
class KGSTORYLINEEDITOR_API UDialogueCameraCutTrack : public UDialogueActionTrack
{
	GENERATED_BODY()

public:
	UDialogueCameraCutTrack();

public:
	EDialogueTrack::Type GetType() const override;

	virtual UClass* GetSecondSectionType() override;
	
#if WITH_EDITOR
	virtual FString GetEditorPreviewName() override;
#endif
};


UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueCameraCut : public UDialogueActionBase
{
	GENERATED_BODY()

public:

	UPROPERTY(VisibleDefaultsOnly)
	UDialogueCameraTrack* CameraTrack = nullptr;

	UPROPERTY(BlueprintReadWrite, meta=(DisplayName = "已过时，请使用最新的TargetCamera"))
	FName CameraName;
};