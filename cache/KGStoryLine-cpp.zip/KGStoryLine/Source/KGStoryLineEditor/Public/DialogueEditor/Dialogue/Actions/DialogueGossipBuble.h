// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"
#include "DialogueGossipBuble.generated.h"

/**
 * UDialogueGossipBuble
 */
UCLASS(Blueprintable, EditInlineNew)
class KGSTORYLINEEDITOR_API UDialogueGossipBuble : public UDialogueActionBase
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, meta=(DisplayName="冒泡文本ID"))
    int32 GossipBubbleID;
};
