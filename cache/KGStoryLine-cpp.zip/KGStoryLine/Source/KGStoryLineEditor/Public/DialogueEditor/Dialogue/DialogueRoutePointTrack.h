#pragma once

#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "DialogueRoutePointTrack.generated.h"

UCLASS(Blueprintable, EditInlineNew, meta = (DisplayName = "路径点"))
class KGSTORYLINEEDITOR_API UDialogueRoutePointTrack : public UDialogueSpawnableTrack
{
	GENERATED_BODY()

	UDialogueRoutePointTrack():UDialogueSpawnableTrack()
	{
		NamePrefix=TEXT("路径点");
	}

public:
	virtual EDialogueTrack::Type GetType() const override
	{
		return EDialogueTrack::Type::RoutePoint;
	}
};