// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "3C/Animation/AnimAssetDefine.h"
#include "DialogueEditor/Dialogue/DialogueCommon.h"
#include "KGStoryLineConst.h"
// #include "KGSLDialogueLine.generated.h"
