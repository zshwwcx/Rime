#pragma once

#include "Styling/ISlateStyle.h"
#include "Runtime/Slate/Public/Framework/Commands/Commands.h"



class KGSTORYLINEEDITOR_API FDialogueEditorCommands : public TCommands<FDialogueEditorCommands>
{
public:
	FDialogueEditorCommands() : TCommands<FDialogueEditorCommands>(TEXT("DialogueEditor"), NSLOCTEXT("Contexts", "DialogueEditor", "DialogueEditor"), NAME_None, TEXT("Waiting"))
	{

	}

	virtual void RegisterCommands() override;

public:
	TSharedPtr<FUICommandInfo> Play;
	TSharedPtr<FUICommandInfo> PlayBigworld;
	TSharedPtr<FUICommandInfo> Stop;
	TSharedPtr<FUICommandInfo> ForwardStep;
	TSharedPtr<FUICommandInfo> BackwardStep;
	TSharedPtr<FUICommandInfo> Generate;
	TSharedPtr<FUICommandInfo> Import;
	TSharedPtr<FUICommandInfo> Export;
	TSharedPtr<FUICommandInfo> SyncTemplate;
	TSharedPtr<FUICommandInfo> SaveAsTemplate;
	TSharedPtr<FUICommandInfo> CheckInValidAsset;
	TSharedPtr<FUICommandInfo> Copy;
	TSharedPtr<FUICommandInfo> Paste;
	TSharedPtr<FUICommandInfo> Delete;
	TSharedPtr<FUICommandInfo> Audio2FaceAutoMatch;
	TSharedPtr<FUICommandInfo> AddEpisode;
	TSharedPtr<FUICommandInfo> CreateAutoCuts;
};
