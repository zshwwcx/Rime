#pragma once

#include "CoreMinimal.h"
#include "DialogueEditorMenuContext.generated.h"

UCLASS()
class UDialogueEditorTrackMenuContext : public UObject
{
	GENERATED_BODY()

public:
	TWeakPtr<class SDialogueEditorEpisode> EpisodeView;
};