#pragma once

#include "CoreMinimal.h"
#include "ClassViewerModule.h"
#include "Widgets/SCompoundWidget.h"
#include "Framework/SlateDelegates.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"

class UDialogueAsset;

class KGSTORYLINEEDITOR_API FDialogueEditorUtilities
{
public:
	// 创建轨道按钮
	static TSharedRef<SWidget> MakeTrackButton(FText HoverText, FOnGetContent MenuContent, const TAttribute<bool>& HoverState);

	static TWeakPtr<SWidget> MakeNewTrackPicker(FMenuBuilder& MenuBuilder, const FOnClassPicked& OnTrackClassPicked, bool IsTemplateMode=false, bool OnlySpawnableTrack=false);

	// 处理编辑器下视口管理UMG UI控件
	static void AddOverlayWidgetToViewport(TSharedRef<SWidget> OverlaidWidget);
	static void RemoveOverlayWidgetToViewport(TSharedRef<SWidget> OverlaidWidget);
	static UDialogueAsset* GetDialogueAsset(const UObject* InObject);
};
