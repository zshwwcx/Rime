#pragma once

#include "CoreMinimal.h"
#include "ClassViewerModule.h"
#include "Widgets/SCompoundWidget.h"
#include "IPropertyTypeCustomization.h"

class KGSTORYLINEEDITOR_API FCustomPropertyDialogueLineDetails: public IPropertyTypeCustomization
{
public:
    static TSharedRef<IPropertyTypeCustomization> MakeInstance()
    {
        return MakeShareable(new FCustomPropertyDialogueLineDetails);
    }

    virtual void CustomizeHeader(TSharedRef<class IPropertyHandle> StructPropertyHandle, class FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils) override;
    virtual void CustomizeChildren(TSharedRef<class IPropertyHandle> StructPropertyHandle, class IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils) override;

};