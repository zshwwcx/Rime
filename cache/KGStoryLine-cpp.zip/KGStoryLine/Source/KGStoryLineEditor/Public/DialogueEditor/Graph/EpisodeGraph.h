// Copyright 2020 Kuai, Inc. All Rights Reserved.

#pragma once

#include "DialogueEditor/KGStoryLineEditorSubSystem.h"
#include "EdGraph/EdGraph.h"
#include "EpisodeGraph.generated.h"

UCLASS()
class KGSTORYLINEEDITOR_API UEpisodeGraph : public UEdGraph
{
	GENERATED_BODY()

public:
	//~BEGIN: UEdGraph interface
	virtual void NotifyGraphChanged() override;
	virtual void NotifyGraphChanged( const FEdGraphEditAction& Action ) override;
	//~END: UEdGraph interface

	/** Graph被创建 */
	virtual void OnCreated();
	/** Graph被加载 */
	virtual void OnLoaded();

	/** 初始化调用 */
	virtual void Initialize();
	
	void SetRootNode(TWeakObjectPtr<> InRootNode) { RootNode = InRootNode; }

	class UEpisodeGraphNode* GetEpisodeNode(int32 EpisodeID);
	class UEpisodeGraphNode* GetEpisodeNode(class UKGSLDialogueEpisode* Episode);

	UDialogueAsset* GetDialogueAsset();

	TArray<UEpisodeGraphNode*> GetEpisodeNodes();
	UEpisodeGraphNode* CreateEpisodeNode(UEdGraphPin* FromPin, bool bSelectNewNode, const FVector2D& Location);
	void OnEpisodeAdded();
	void OnEpisodeRemoved();
private:
	class UEpisodeGraphEntryNode* CreateEntryNode();
	UPROPERTY()
	TWeakObjectPtr<UObject> RootNode;
};
