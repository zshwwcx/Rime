//author yaoliwen@kuaishou.com 2024.9.18

#pragma once
#include "DialogueEditor/Graph/GraphNodes/OptionGraphNode.h"
#include "DialogueEditor/Graph/GraphNodes/SOptionGraphNode.h"

//定义图表节点工厂
class FOptionGraphNodeFactory : public FGraphPanelNodeFactory
{
	virtual TSharedPtr<class SGraphNode> CreateNode(UEdGraphNode* Node) const override
	{
		if (UOptionGraphNode* OptionGraphNode = Cast<UOptionGraphNode>(Node))
		{
			return SNew(SOptionGraphNode, OptionGraphNode);
		}

		if (UOptionGraphOneParamNode* OptionGraphOneParamNode = Cast<UOptionGraphOneParamNode>(Node))
		{
			return SNew(SOptionGraphOneParamNode, OptionGraphOneParamNode);
		}

		if (UOptionGraphNoParamNode* OptionGraphNoParamNode = Cast<UOptionGraphNoParamNode>(Node))
		{
			return SNew(SOptionGraphNoParamNode, OptionGraphNoParamNode);
		}

		if (UOptionGraphActionMultiParamNode* OptionGraphActionMultiParamNode = Cast<UOptionGraphActionMultiParamNode>(Node))
		{
			return SNew(SOptionGraphActionMultiParamNode, OptionGraphActionMultiParamNode);
		}

		if (UOptionGraphActionOneParamNode* OptionGraphActionOneParamNode = Cast<UOptionGraphActionOneParamNode>(Node))
		{
			return SNew(SOptionGraphActionOneParamNode, OptionGraphActionOneParamNode);
		}

		if (UOptionGraphActionNoParamNode* OptionGraphActionNoParamNode = Cast<UOptionGraphActionNoParamNode>(Node))
		{
			return SNew(SOptionGraphActionNoParamNode, OptionGraphActionNoParamNode);
		}

		if (UOptionGraphJumpNode* OptionGraphActionNoParamNode = Cast<UOptionGraphJumpNode>(Node))
		{
			return SNew(SOptionGraphJumpNode, OptionGraphActionNoParamNode);
		}
		
		return nullptr;
	}
};
