//author yaoliwen@kuaishou.com 2024.9.18
#pragma once

#include "CoreMinimal.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"
#include "GraphEditor.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"


class SOptionGraph : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SOptionGraph) {}
		SLATE_ARGUMENT(FString, Condition)
		SLATE_ARGUMENT(TArray<FString>, ExtraAction)
		SLATE_ARGUMENT(int32, EpisodeID)
		SLATE_ARGUMENT(int32, DialogueLineIndex)
		SLATE_ARGUMENT(TWeakObjectPtr<UDialogueAsset>, DialogueAssetEditing)
	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs);

	void CreateCommandList();

	virtual FVector2D ComputeDesiredSize(float) const override;

	void DeleteSelectedNodes();
	bool CanDeleteNodes() const;
	FString GetCondition();
	void SetCondition(FString& InCondition, TArray<FString>& InExtraAction, int32 InEpisodeID, int32 InDialogueLineIndex, TWeakObjectPtr<UDialogueAsset> InDialogueAssetEditing);
	TArray<FString> GetExtraAction();
	int32 GetEpisodeID();
	int32 GetDialogueLineIndex();

public:
	//图表编辑器控件
	TSharedPtr<SGraphEditor> GraphEditor;

	//图表对象
	TWeakObjectPtr<class UOptionGraph> GraphObject;

	TSharedPtr<FUICommandList> GraphEditorCommands;

	FString Condition;
	TArray<FString> ExtraAction;
	int32 EpisodeID = 0;
	int32 DialogueLineIndex = 0;
	TWeakObjectPtr<UDialogueAsset> DialogueAssetEditing;
};
