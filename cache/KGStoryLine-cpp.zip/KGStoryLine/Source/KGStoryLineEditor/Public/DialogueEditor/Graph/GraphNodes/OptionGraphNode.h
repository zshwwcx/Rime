//author yaoliwen@kuaishou.com 2024.9.18

#pragma once
#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "EdGraph/EdGraphNode.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "OptionGraphNode.generated.h"

UCLASS()
class KGSTORYLINEEDITOR_API UOptionGraphNode : public UEdGraphNode
{
	GENERATED_UCLASS_BODY()

public:

	// UEdGraphNode implementation
	virtual void AllocateDefaultPins() override;
	// End UEdGraphNode implementation
	UEdGraphPin* GetInputPin1() const;
	UEdGraphPin* GetInputPin2() const;
	UEdGraphPin* GetResultPin() const;
	UEdGraphPin* GetOutputPin() const;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const;
	virtual bool CanUserDeleteNode() const;
	UEdGraphPin* AddConditionPin();
	void RemoveConditionPin(const UEdGraphPin* Pin);
	UEdGraphPin* AddActionPin();
	void RemoveActionPin(const UEdGraphPin* Pin);

public:
	//输入引脚
	UEdGraphPin* InputPin1;
	//输入引脚
	UEdGraphPin* InputPin2;
	//输入引脚
	TArray<UEdGraphPin*> InputPins;

	//输出引脚
	UEdGraphPin* ResultPin;

	//输出引脚
	UEdGraphPin* OutputPin;

	//输出引脚
	TArray<UEdGraphPin*> OutputPins;
};


UCLASS()
class KGSTORYLINEEDITOR_API UOptionGraphNoParamNode : public UEdGraphNode
{
	GENERATED_UCLASS_BODY()

public:

	// UEdGraphNode implementation
	virtual void AllocateDefaultPins() override;
	// End UEdGraphNode implementation
	UEdGraphPin* GetOutputPin() const;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const;
	virtual bool CanUserDeleteNode() const;
	virtual FString ToString();
	
public:
	FString Title;
	FString ConditionName;
	//输出引脚
	UEdGraphPin* OutputPin;
};

UCLASS()
class KGSTORYLINEEDITOR_API UOptionGraphOneParamNode : public UOptionGraphNoParamNode
{
	GENERATED_UCLASS_BODY()

public:
	virtual FString ToString() override;

public:
	FString ParamName;
	int Param;
};

UCLASS()
class KGSTORYLINEEDITOR_API UOptionGraphActionNoParamNode : public UEdGraphNode
{
	GENERATED_UCLASS_BODY()

public:

	// UEdGraphNode implementation
	virtual void AllocateDefaultPins() override;
	// End UEdGraphNode implementation
	UEdGraphPin* GetInputPin() const;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const;
	virtual bool CanUserDeleteNode() const;
	virtual FString ToString();

public:
	FString Title;
	FString ConditionName;
	//输入引脚
	UEdGraphPin* InputPin;
};


UCLASS()
class KGSTORYLINEEDITOR_API UOptionGraphActionOneParamNode : public UOptionGraphActionNoParamNode
{
	GENERATED_UCLASS_BODY()

public:
	virtual FString ToString() override;

public:
	FString ParamName;
	int Param;
};

UCLASS()
class KGSTORYLINEEDITOR_API UOptionGraphActionMultiParamNode : public UOptionGraphActionNoParamNode
{
	GENERATED_UCLASS_BODY()

public:
	virtual FString ToString() override;

public:
	TArray<FString> ParamNames;
	TArray<FString> Params;
};

UCLASS()
class KGSTORYLINEEDITOR_API UOptionGraphJumpNode : public UEdGraphNode
{
	GENERATED_UCLASS_BODY()

public:

	// UEdGraphNode implementation
	virtual void AllocateDefaultPins() override;
	// End UEdGraphNode implementation
	UEdGraphPin* GetInputPin() const;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const;
	virtual bool CanUserDeleteNode() const;
	virtual FString ToString();

public:
	FString Title;
	TArray<FString> ParamNames = { TEXT("本选项跳转的对话小段") , TEXT("从对话小段第几句开始") };
	TArray<int> Params = {0, 1};
	TWeakObjectPtr<UDialogueAsset> DialogueAssetEditing;
	//输入引脚
	UEdGraphPin* InputPin;
};