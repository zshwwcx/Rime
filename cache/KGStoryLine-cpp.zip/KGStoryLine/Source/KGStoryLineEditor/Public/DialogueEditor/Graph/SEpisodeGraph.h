// Copyright 2020 Kuai, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"
#include "GraphEditor.h"
#include "DialogueEditor/KGStoryLineEditorSubSystem.h"
#include "Components/VerticalBox.h"

class UEpisodeGraph;

class KGSTORYLINEEDITOR_API SEpisodeGraph : public SCompoundWidget, public INotifyOnKGSLDataChanged
{
public:
	SLATE_BEGIN_ARGS(SEpisodeGraph) {}
	SLATE_END_ARGS()

	SEpisodeGraph();
	void Construct(const FArguments& InArgs, TSharedPtr<class FDialogueEditor> Editor);
	~SEpisodeGraph();

	//~ BEGIN:  INotifyOnKGSLDataChanged
	virtual void PreChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType) override;
	virtual void PostChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType) override;
	//~ END: INotifyOnKGSLDataChanged

	
	void CreateCommandList();
	void ConnectEpisodeNodes();
	TSharedPtr<SGraphEditor> CreateGraphEditor();
	void HandleSelectionChanged(const FGraphPanelSelectionSet& SelectionSet);

	void DeleteSelectedNodes();
	bool CanDeleteNodes() const;

	void OnDialogueConstructGraph();
public:
	TSharedPtr<SWindow> HostWindow;
	TSharedPtr<SVerticalBox> GraphContainer;
	TSharedPtr<SGraphEditor> GraphEditor;
	TWeakObjectPtr<UEpisodeGraph> GraphObject;
	TWeakPtr<class FDialogueEditor> HostEditor;
	TSharedPtr<FUICommandList> GraphEditorCommands;

	SGraphEditor::FOnSelectionChanged OnSelectionChanged;
};
