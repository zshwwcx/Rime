// Copyright 2020 Kuai, Inc. All Rights Reserved.

#pragma once

#include "EdGraphUtilities.h"

class KGSTORYLINEEDITOR_API FEpisodeGraphNodeFactory : public FGraphPanelNodeFactory
{
	virtual TSharedPtr<class SGraphNode> CreateNode(class UEdGraphNode* Node) const override;
};

