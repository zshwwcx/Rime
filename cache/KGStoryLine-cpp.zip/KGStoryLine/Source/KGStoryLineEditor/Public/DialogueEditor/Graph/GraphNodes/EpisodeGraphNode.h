// Copyright 2020 Kuai, Inc. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "EdGraph/EdGraphNode.h"
#include "EpisodeGraphNode.generated.h"

class UKGSLDialogueEpisode;

UCLASS()
class KGSTORYLINEEDITOR_API UEpisodeGraphNode : public UEdGraphNode
{
	GENERATED_BODY()
public:
	virtual void AllocateDefaultPins() override;
	/** Destroy the specified node */
	virtual void DestroyNode() override;
	virtual void PostLoad() override;
	virtual FLinearColor GetNodeTitleColor() const override;
	/** Gets the name of this node, shown in title bar */
	virtual bool ShouldOverridePinNames() const override { return true; }
	virtual FText GetPinNameOverride(const UEdGraphPin& Pin) const override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const;
	virtual void PinConnectionListChanged(UEdGraphPin* Pin)override;

	class UDialogueAsset* GetDialogueAsset();

	UEdGraphPin* AddOptionPin();
	void RemoveOptionPin(const UEdGraphPin* Pin);
	UEdGraphPin* InputPin;// cppcheck:ignore

	void SetOwnerDialogueEpisode(UKGSLDialogueEpisode* InOwner);

	UFUNCTION(BlueprintCallable)
	int32 GetEpisodeID() const { return EpisodeID; }

	UKGSLDialogueEpisode* GetOwnerDialogueEpisode();
private:
	UPROPERTY()
	int32 EpisodeID = 0;

	UPROPERTY()
	UKGSLDialogueEpisode* OwnerDialogueEpisode;
};

UCLASS()
class UEpisodeGraphEntryNode : public UEdGraphNode
{
	GENERATED_BODY()
public:
	virtual void AllocateDefaultPins() override;
	virtual bool CanUserDeleteNode() const;
	virtual FLinearColor GetNodeTitleColor() const override;

	virtual void PinConnectionListChanged(UEdGraphPin* Pin)override;
	class UDialogueAsset* GetDialogueAsset();

	UEdGraphPin* OutputPin;// cppcheck:ignore
};