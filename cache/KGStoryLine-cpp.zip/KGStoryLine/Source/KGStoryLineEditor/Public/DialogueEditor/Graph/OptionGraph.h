//author yaoliwen@kuaishou.com 2024.9.18

#pragma once

#include "EdGraph/EdGraph.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Graph/GraphNodes/OptionGraphNode.h"
#include "UObject/ObjectMacros.h"
#include "Math/MathFwd.h"
#include "OptionGraph.generated.h"


DECLARE_DELEGATE_RetVal_TwoParams(class UOptionGraphNoParamNode*, FCreateOptionNode, int, const FVector2D)
DECLARE_DELEGATE_RetVal_TwoParams(class UOptionGraphActionNoParamNode*, FCreateActionNode, FString&, const FVector2D)

UCLASS()
class KGSTORYLINEEDITOR_API UOptionGraph : public UEdGraph
{
	GENERATED_UCLASS_BODY()

public:
	void SetCondition(FString& InCondition, TArray<FString>& InExtraAction, int32 InEpisodeID, int32 InDialogueLineIndex, TWeakObjectPtr<UDialogueAsset> InDialogueAssetEditing);
	//重新构建图表
	void RebuildGraph();
	//创建一个节点
	class UOptionGraphNode* CreateOptionNode(const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionNoParamNode();
	class UOptionGraphOneParamNode* CreateOptionOneParamNode();
	class UOptionGraphActionNoParamNode* CreateOptionActionNoParamNode();
	class UOptionGraphActionOneParamNode* CreateOptionActionOneParamNode();
	class UOptionGraphActionMultiParamNode* CreateOptionActionMultiParamNode();
	class UOptionGraphJumpNode* CreateOptionJumpNode(const FVector2D Location);

	class UOptionGraphNoParamNode* CreateOptionHasItemNode(int Id, const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionHasTaskFinishedNode(int Id, const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionCheckPreConditionNode(int Id, const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionIsQteSuccessNode(int Id, const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionIsQteFailedNode(int Id, const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionCheckDiceResultNode(int Id, const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionIsModeOverNode(int Id, const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionHasFinalPriceNode(int Id, const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionCheckBargainStart(int32 bStart, const FVector2D Location);
	class UOptionGraphNoParamNode* CreateOptionCheckMoodLevel(int32 MoodLevel, const FVector2D Location);

	class UOptionGraphActionNoParamNode* CreateActionAddMoodNode(FString& Param, const FVector2D Location);
	class UOptionGraphActionNoParamNode* CreateActionOpenSeeMoodNode(FString& Param, const FVector2D Location);
	class UOptionGraphActionNoParamNode* CreateActioCloseSeeMoodNode(FString& Param, const FVector2D Location);
	class UOptionGraphActionNoParamNode* CreateActioOpenCutPriceNode(FString& Param, const FVector2D Location);
	class UOptionGraphActionNoParamNode* CreateActioSubmitPriceNode(FString& Param, const FVector2D Location);
	class UOptionGraphActionNoParamNode* CreateActioOpenUINode(FString& Param, const FVector2D Location);
	class UOptionGraphActionNoParamNode* CretaeActionBargainResult(FString& StrSuccess, const FVector2D Location);

	void DeleteNode(UEdGraphNode* Node);
	FString GetCondition();
	TArray<FString> GetExtraAction();
	int32 GetEpisodeID();
	int32 GetDialogueLineIndex();
	void TestFunc();

private:
	UPROPERTY()
	class UOptionGraphNode* AndNode;
	UPROPERTY()
	class UOptionGraphJumpNode* JumpNode;
	FString Condition;
	TArray<FString> ExtraAction;
	int32 EpisodeID;
	int32 DialogueLineIndex;
	TWeakObjectPtr<UDialogueAsset> DialogueAssetEditing;
	UPROPERTY()
	TArray<class UOptionGraphNoParamNode*> AllNodes;
	UPROPERTY()
	TArray<class UOptionGraphActionNoParamNode*> AllActionNodes;

	static TMap<FString, TDelegate<class UOptionGraphNoParamNode* (int Id, const FVector2D Location)>> Condition2NodeCreate;
	static TMap<FString, TDelegate<class UOptionGraphActionNoParamNode* (FString& Param, const FVector2D Location)>> Action2NodeCreate;
};
