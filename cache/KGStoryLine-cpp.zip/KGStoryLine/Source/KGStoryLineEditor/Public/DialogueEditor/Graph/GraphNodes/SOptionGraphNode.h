//author yaoliwen@kuaishou.com 2024.9.18
#pragma once

#include "CoreMinimal.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SBoxPanel.h"
#include "SGraphNode.h"

class UOptionGraphNode;
class UOptionGraphNoParamNode;
class UOptionGraphOneParamNode;
class UOptionGraphActionNoParamNode;
class UOptionGraphActionOneParamNode;
class UOptionGraphActionMultiParamNode;
class UOptionGraphJumpNode;

class KGSTORYLINEEDITOR_API SOptionGraphNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SOptionGraphNode) {}

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, UOptionGraphNode* InNode);

	// SGraphNode implementation
	 //virtual TSharedRef<SWidget> CreateNodeContentArea() override;
	//virtual void UpdateGraphNode() override;
	// End SGraphNode implementation
};

class KGSTORYLINEEDITOR_API SOptionGraphNoParamNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SOptionGraphNoParamNode) {}

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, UOptionGraphNoParamNode* InNode);

	// SGraphNode implementation
	// 
	//virtual void UpdateGraphNode() override;
	// End SGraphNode implementation
};

class KGSTORYLINEEDITOR_API SOptionGraphOneParamNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SOptionGraphOneParamNode) {}

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, UOptionGraphOneParamNode* InNode);

	// SGraphNode implementation
	virtual TSharedRef<SWidget> CreateNodeContentArea() override;
	//virtual void UpdateGraphNode() override;
	// End SGraphNode implementation
};

class KGSTORYLINEEDITOR_API SOptionGraphActionNoParamNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SOptionGraphActionNoParamNode) {}

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, UOptionGraphActionNoParamNode* InNode);

	// SGraphNode implementation
	// 
	//virtual void UpdateGraphNode() override;
	// End SGraphNode implementation
};

class KGSTORYLINEEDITOR_API SOptionGraphActionOneParamNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SOptionGraphActionOneParamNode) {}

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, UOptionGraphActionOneParamNode* InNode);

	// SGraphNode implementation
	virtual TSharedRef<SWidget> CreateNodeContentArea() override;
	//virtual void UpdateGraphNode() override;
	// End SGraphNode implementation
};

class KGSTORYLINEEDITOR_API SOptionGraphActionMultiParamNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SOptionGraphActionMultiParamNode) {}

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, UOptionGraphActionMultiParamNode* InNode);

	// SGraphNode implementation
	virtual TSharedRef<SWidget> CreateNodeContentArea() override;
	//virtual void UpdateGraphNode() override;
	// End SGraphNode implementation
};

class KGSTORYLINEEDITOR_API SOptionGraphJumpNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SOptionGraphJumpNode) {}

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, UOptionGraphJumpNode* InNode);

	// SGraphNode implementation
	virtual TSharedRef<SWidget> CreateNodeContentArea() override;
	void RebuildLinesBox() const;
	//virtual void UpdateGraphNode() override;
	// End SGraphNode implementation
private:
	TSharedPtr<SHorizontalBox> LineContent;
};

