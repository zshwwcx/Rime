// Copyright 2020 Kuai, Inc. All Rights Reserved.
#pragma once

#include "EdGraph/EdGraphSchema.h"
#include "EpisodeGraphSchema.generated.h"



//=============================================================================
/**
 * FSchemaAction_EpisodeNewNode
 */
USTRUCT()
struct KGSTORYLINEEDITOR_API FSchemaAction_EpisodeNewNode : public FEdGraphSchemaAction
{
	GENERATED_BODY()
public:
	FSchemaAction_EpisodeNewNode()
		: FEdGraphSchemaAction()
	{}

	FSchemaAction_EpisodeNewNode(FText InNodeCategory, FText InMenuDesc, FText InToolTip, const int32 InGrouping)
		: FEdGraphSchemaAction(MoveTemp(InNodeCategory), MoveTemp(InMenuDesc), MoveTemp(InToolTip), InGrouping)
	{}

	//~BEGIN: FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	//~END: FEdGraphSchemaAction interface

};

//=============================================================================
/**
 * UEpisodeGraphSchema
 */
UCLASS()
class UEpisodeGraphSchema: public UEdGraphSchema
{
	GENERATED_BODY()

public:

	/** Graph右键菜单，创建Node*/
	virtual void GetGraphContextActions(FGraphContextMenuBuilder& ContextMenuBuilder) const override;

	/** Node 右键菜单 */
	virtual void GetContextMenuActions(class UToolMenu* Menu, class UGraphNodeContextMenuContext* Context) const override;
	/**
	 * Determine if a connection can be created between two pins.
	 *
	 * @param	A	The first pin.
	 * @param	B	The second pin.
	 *
	 * @return	An empty string if the connection is legal, otherwise a message describing why the connection would fail.
	 */
	virtual const FPinConnectionResponse CanCreateConnection(const UEdGraphPin* A, const UEdGraphPin* B) const override;

	/** 删除节点 */
	virtual bool SafeDeleteNodeFromGraph(UEdGraph* Graph, UEdGraphNode* Node) const override;

	virtual FLinearColor GetPinTypeColor(const FEdGraphPinType& PinType) const { return FLinearColor::White; }
	virtual FText GetPinDisplayName(const UEdGraphPin* Pin) const override;


private:
	/** 增加一个episode的选项 */
	void AddEpisodeOption(class UGraphNodeContextMenuContext* Context) const;
	/** 删除一个episode的选项 */
	void RemoveEpisodeOption(class UGraphNodeContextMenuContext* Context) const;
};
