//author yaoliwen@kuaishou.com 2024.9.18
#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "EdGraph/EdGraphSchema.h"

#include "OptionGraphSchemaAction_NewNode.generated.h"


USTRUCT()
struct FOptionGraphSchemaAction_HasItem : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_HasItem() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("HasItem")					//InMenuDesc
		, FText::FromString("HasItem_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};


USTRUCT()
struct FOptionGraphSchemaAction_HasTaskFinished : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_HasTaskFinished() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("HasTaskFinished")					//InMenuDesc
		, FText::FromString("HasTaskFinished_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};


USTRUCT()
struct FOptionGraphSchemaAction_CheckPreCondition : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_CheckPreCondition() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("CheckPreCondition")					//InMenuDesc
		, FText::FromString("CheckPreCondition_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};


USTRUCT()
struct FOptionGraphSchemaAction_IsQteSuccess : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_IsQteSuccess() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("IsQteSuccess")					//InMenuDesc
		, FText::FromString("IsQteSuccess_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_IsQteFailed : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_IsQteFailed() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("IsQteFailed")					//InMenuDesc
		, FText::FromString("IsQteFailed_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_CheckDiceResult : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_CheckDiceResult() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("CheckDiceResult")					//InMenuDesc
		, FText::FromString("CheckDiceResult_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};


USTRUCT()
struct FOptionGraphSchemaAction_IsModeOver : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_IsModeOver() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("IsModeOver")					//InMenuDesc
		, FText::FromString("IsModeOver_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_HasFinalPrice : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_HasFinalPrice() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("HasFinalPrice")					//InMenuDesc
		, FText::FromString("HasFinalPrice_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_CheckBargainStart : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_CheckBargainStart() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("BargainStart")					//InMenuDesc
		, FText::FromString("BargainStart_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {
	};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_CheckMoodLevel : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_CheckMoodLevel() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("CheckMoodLevel")					//InMenuDesc
		, FText::FromString("CheckMoodLevel_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {
	};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_And : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_And() :FEdGraphSchemaAction(
		FText::FromString("Condition")			//InNodeCategory
		, FText::FromString("And")					//InMenuDesc
		, FText::FromString("And")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_AddMood : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_AddMood() :FEdGraphSchemaAction(
		FText::FromString("ExtraAction")			//InNodeCategory
		, FText::FromString("AddMood")					//InMenuDesc
		, FText::FromString("AddMood_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_OpenSeeMood : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_OpenSeeMood() :FEdGraphSchemaAction(
		FText::FromString("ExtraAction")			//InNodeCategory
		, FText::FromString("OpenSeeMood")					//InMenuDesc
		, FText::FromString("OpenSeeMood_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_CloseSeeMood : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_CloseSeeMood() :FEdGraphSchemaAction(
		FText::FromString("ExtraAction")			//InNodeCategory
		, FText::FromString("CloseSeeMood")					//InMenuDesc
		, FText::FromString("CloseSeeMood_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_OpenCutPrice : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_OpenCutPrice() :FEdGraphSchemaAction(
		FText::FromString("ExtraAction")			//InNodeCategory
		, FText::FromString("OpenCutPrice")					//InMenuDesc
		, FText::FromString("OpenCutPrice_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_SubmitPrice : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_SubmitPrice() :FEdGraphSchemaAction(
		FText::FromString("ExtraAction")			//InNodeCategory
		, FText::FromString("SubmitPrice")					//InMenuDesc
		, FText::FromString("SubmitPrice_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraphSchemaAction_OpenUI : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:

	FOptionGraphSchemaAction_OpenUI() :FEdGraphSchemaAction(
		FText::FromString("ExtraAction")			//InNodeCategory
		, FText::FromString("OpenUI")					//InMenuDesc
		, FText::FromString("OpenUI_tooltip")			//InToolTip
		, 0	//InGrouping:/** This is a priority number for overriding alphabetical order in the action list (higher value  == higher in the list). */					
	) {};

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FOptionGraohSchemaAction_BargainResult : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()
public:
	FOptionGraohSchemaAction_BargainResult() : FEdGraphSchemaAction(
		FText::FromString("ExtraAction"),
		FText::FromString("BarginResult"),
		FText::FromString("BarginResult_tooltip"),
		0
	)
	{ }

	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
};