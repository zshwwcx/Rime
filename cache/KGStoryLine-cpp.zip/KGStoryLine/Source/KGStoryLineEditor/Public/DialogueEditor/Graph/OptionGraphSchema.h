//author yaoliwen@kuaishou.com 2024.9.18
#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "EdGraph/EdGraphSchema.h"

#include "OptionGraphSchema.generated.h"


UCLASS(MinimalAPI)
class UOptionGraphSchema : public UEdGraphSchema
{
	GENERATED_UCLASS_BODY()

	/**
	 * Determine if a connection can be created between two pins.
	 *
	 * @param	A	The first pin.
	 * @param	B	The second pin.
	 *
	 * @return	An empty string if the connection is legal, otherwise a message describing why the connection would fail.
	 */
	virtual const FPinConnectionResponse CanCreateConnection(const UEdGraphPin* A, const UEdGraphPin* B) const
	{
		return FPinConnectionResponse(CONNECT_RESPONSE_MAKE, TEXT("OK"));
	}

	/** Graph右键菜单，创建Node*/
	virtual void GetGraphContextActions(FGraphContextMenuBuilder& ContextMenuBuilder) const override;

	/** Node 右键菜单 */
	virtual void GetContextMenuActions(class UToolMenu* Menu, class UGraphNodeContextMenuContext* Context) const override;

	/** 删除节点 */
	virtual bool SafeDeleteNodeFromGraph(UEdGraph* Graph, UEdGraphNode* Node) const override;

	virtual FLinearColor GetPinTypeColor(const FEdGraphPinType& PinType) const { return FLinearColor::White; }

private:
	/** 增加一个episode的选项 */
	void AddCondition(class UGraphNodeContextMenuContext* Context) const;
	/** 删除一个episode的选项 */
	void RemoveCondition(class UGraphNodeContextMenuContext* Context) const;

	/** 增加一个episode的ExtraAction */
	void AddAction(class UGraphNodeContextMenuContext* Context) const;
	/** 删除一个episode的ExtraAction */
	void RemoveAction(class UGraphNodeContextMenuContext* Context) const;
};


