// Copyright 2020 Kuai, Inc. All Rights Reserved.

#pragma once

#include "SGraphNode.h"

class SHorizontalBox;

class KGSTORYLINEEDITOR_API SEpisodeGraphEntryNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SEpisodeGraphEntryNode) {}

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, class UEpisodeGraphEntryNode* InNode);

protected:
	//~BEGIN: SGraphNode interface
	virtual void UpdateGraphNode() override;
	virtual void OnDragEnter(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;
	virtual FReply OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;
	//~END: SGraphNode interface

	/** Handle for Selection */
	FReply OnMouseDown(const FGeometry& SenderGeometry, const FPointerEvent& MouseEvent);

	virtual FText GetNodeTitle() const;
	virtual FText GetNodeBody() const;
	virtual FSlateColor GetNodeBackgroundColor() const;
	virtual bool IsNameReadOnly() const { return true; }
	FSlateColor GetBorderBackgroundColor() const;

	virtual TSharedRef<SWidget> CreatTitleWidget();
	virtual TSharedRef<SWidget> CreatBodyWidget();
};

class KGSTORYLINEEDITOR_API SEpisodeGraphNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SEpisodeGraphNode) {}

	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, class UEpisodeGraphNode* InNode);
};
