#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/DialogueEditor.h"


class SDialogueEditorTimelineTab;
class KGSTORYLINEEDITOR_API SDialogueEditorEpisode : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SDialogueEditorEpisode) {};
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, const TSharedPtr<FDialogueEditor>& InAssetEditorToolkit, const TSharedPtr<SDialogueEditorTimelineTab>& AssetEditWidget, int32 InEpisodeIndex);

private:
	void ChangeEpisodeDuration(const FText& InText, ETextCommit::Type CommitInfo);

	TSharedRef<SWidget> BuildEpisodeSubMenu();

	void FillNewTrackMenu(class FMenuBuilder& MenuBuilder);

	void AddNewTrack(UClass* InTrackClass);

	void DeleteEpisode();

	FText GetEpisodeName() const;

	FText GetEpisodeDuration() const;

	void ToggleLayout(bool bNewLayout);

	bool IsUsedNewLayout() const;

	TSharedRef<SWidget> GetSettingsButtonContent();

	void RegisterGetSettingsButtonMenu();

	void PopulateSettingsButtonMenu(UToolMenu* Menu);

	void OnCameraListRefreshed();
	
	void OnNormalListRefreshed();
	 
public:
	TWeakPtr<FDialogueEditor> CachedEditor = nullptr;

	TWeakPtr<SDialogueEditorTimelineTab> CachedEditTab = nullptr;

	TSharedPtr<class SAnimTimeline> TimelineWidget = nullptr;

	TSharedPtr<class FDialogueEditorTimelineController> TimelineController = nullptr;

	TSharedPtr<class SAnimTimeline> CameraListWidget = nullptr;
	
	TSharedPtr<class FDialogueEditorTimelineController> CameraListController = nullptr;
};



class SDialogueEditorTimelineTab : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SDialogueEditorTimelineTab) {};
	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, const TSharedPtr<FDialogueEditor>& InAssetEditorToolkit);

	void Update();

	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	virtual FReply OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	TSharedPtr<class ITimeSliderController> GetAnimTimeSliderController();

private:
	TWeakPtr<FDialogueEditor> CachedEditor = nullptr;

	TSharedPtr<SDialogueEditorEpisode> EpisodeWidget;

	TSharedPtr<SBorder> BorderWidgetArea = nullptr;
};