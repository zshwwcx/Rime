#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "IDetailsView.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"



class KGSTORYLINEEDITOR_API SDialogueEditorDetailTab : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SDialogueEditorDetailTab) {}
	SLATE_ARGUMENT(TSharedPtr<class SWidget>, TopContent)
	SLATE_ARGUMENT(TSharedPtr<class SWidget>, BottomContent)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	void SetDetailObject(UObject* InObject);

	void OnFinishedChangingProperties(const FPropertyChangedEvent& PropertyChangedEvent);
	void OnChangeSectionData(class UDialogueActionBase* DialogueActionSection, FName PropertyName);

private:
	/**
	 * 将DialogueActor(轨道Actor)的属性同步到Asset的ActorInfo中
	 * @param PropName 
	 * @param DialogueActor 
	 */
	void CopyTrackActorInfo(const FString& PropName, const class UDialogueActor* DialogueActor);

public:
	TSharedPtr<class IDetailsView> DetailsView;
	TWeakPtr<class FDialogueEditor> DialogueEditor;

};
