#pragma once


#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "IDetailsView.h"
#include "Widgets/SCompoundWidget.h"

class KGSTORYLINEEDITOR_API SDialogueEditorOperationPanel : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SDialogueEditorOperationPanel) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, TSharedPtr<class FDialogueEditor> InEditor);


	void OnStartTimeCommited(const FText& InText, ETextCommit::Type InCommitType);
	void OnStartDialogueLineCommited(const FText& InText, ETextCommit::Type InCommitType);

	void OnSymmetryAssetChanged(const FAssetData& InAssetData);
	bool ShouldSymmetryAssetFilter(const FAssetData& InAssetData);
	FString GetSymmetryAssetPath() const;

	FReply OnClickCopySymmetryAssetData();
private:
	void ConstructCopySymmetryAsset(TSharedRef<class SVerticalBox> VertialBox);
	void ConstructEditorCommands(TSharedRef<class SVerticalBox> VertialBox);
public:
	TWeakPtr<class FDialogueEditor> DialogueEditor;
	TSharedPtr<class SAssetView> AssetViewPtr;
	TWeakObjectPtr<class UDialogueAsset> CopyAsset;
};
