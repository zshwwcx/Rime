#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "SSingleObjectDetailsPanel.h"



class KGSTORYLINEEDITOR_API SDialogueEditorAssetPropertyTabBody : public SSingleObjectDetailsPanel
{
public:
	SLATE_BEGIN_ARGS(SDialogueEditorAssetPropertyTabBody) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, TSharedPtr<class FDialogueEditor> InEditor);

	virtual UObject* GetObjectToObserve() const override;

	virtual TSharedRef<class SWidget> PopulateSlot(TSharedRef<class SWidget> PropertyEditorWidget) override;

	virtual FText GetAssetDisplayName() const;

	virtual EVisibility GetAssetDisplayNameVisibility() const;
	void OnFinishedChangingProperties(const FPropertyChangedEvent& PropertyChangedEvent);

	void OnEpisodeChanged() const;
private:
	TWeakPtr<class FDialogueEditor> CachedEditor = nullptr;
};



class SDialogueEditorSettingsTabBody : public SSingleObjectDetailsPanel
{
public:
	SLATE_BEGIN_ARGS(SDialogueEditorSettingsTabBody) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, TSharedPtr<class FDialogueEditor> InEditor);

	//virtual UObject* GetObjectToObserve() const override;

	virtual TSharedRef<class SWidget> PopulateSlot(TSharedRef<class SWidget> PropertyEditorWidget) override;

	virtual FText GetAssetDisplayName() const;

	virtual EVisibility GetAssetDisplayNameVisibility() const;

private:
	TWeakPtr<class FDialogueEditor> CachedEditor = nullptr;

};