#pragma once

#include "CoreMinimal.h"

#include "JsonObjectConverter.h"
#include "LuaAssetHelper.generated.h"

class KGSTORYLINEEDITOR_API FLuaAssetHelper
{
public:
    static FString Ignore_Return;
	static bool LoadLuaFileToAsset(const FString& FilePath, UObject* Asset);

	static FString GetEditorOnlyInfo(UObject* Asset);

	static void ExportEditorOnlyInfoToLuaTable(UObject* Asset, const TSharedPtr<class FLuaTable>& OutLua);

	static bool CreateAndOpenDialogueLuaAsset(const FString& AssetName);

	static bool OpenDialogueByEditorOnlyInfo(const FString& AssetName, const FString& EditorOnlyInfo);
	static bool OpenDialogueByEditorOnly(const FString& AssetName, TSharedPtr<FLuaTable> LuaTable);
	static class UDialogueAsset* LoadDialogueAssetFromLua(const FString& AssetName, const FString& AssetPath);
	static bool OpenDialogue(const FString& AssetName, const FString& AssetPath);

	static void CopyDialogue(const FString& SourceDialogueID, FString DestDialogueID);

	static void OpenOrCreateDialogueByFileName(const FString& FileName);

	static bool OpenOrCreateDialogueByFileNameInternal(const FString& FileName, bool bSimpleDialogue,
					const TFunction<void()>& PreOpenCallBack = nullptr, const TFunction<void()>& PreCreateCallBack = nullptr);
	
	static FString DialoguePrePath;
	
	static FString DialogueNewPath;

	static FString LuaAssetPrePath;

	static FString BPDialogueAssetClassPath;
};

UCLASS()
class ULuaParentAsset : public UObject
{
	GENERATED_BODY()
};

USTRUCT(BlueprintType)
struct FDialogueAssetData
{
	GENERATED_BODY()

	UPROPERTY()
	FString StoryLineID;

	UPROPERTY()
	FString DialogueType;

	UPROPERTY()
	FString SubFolder;

	UPROPERTY()
	FString Description;

	UPROPERTY()
	FString AuthorName;

	UPROPERTY()
	FString AssetPath;

	UPROPERTY()
	bool bSimpleDialogue=false;
};