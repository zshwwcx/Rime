#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "ImportExport/LuaExporter.h"

class FDialogueExporter : public FLuaExporter
{
public:
	using FCustomStructExporter = TSharedPtr<FLuaValue> (FDialogueExporter::*)(UScriptStruct* ScriptStruct, void* DataAddress, UObject* ParentObject);
	FDialogueExporter();
	
	virtual void ExportObjectExtraToLua(UObject* Object, TSharedPtr<class FLuaTable> OutLua) override;

	virtual TSharedPtr<FLuaValue> ExportStructPropertyToLua(UScriptStruct* ScriptStruct, void* DataAddress, UObject* ParentObject) override;
	void SetCanExportDefault(bool bExportDefault);
	void SetCanExportObjectExtra(bool bInExportObjectExtra);
protected:
	TSharedPtr<FLuaValue> ExportFTransformPropertyToLua(UScriptStruct* ScriptStruct, void* DataAddress, UObject* ParentObject);
	TSharedPtr<FLuaValue> ExportFSplineCurvesPropertyToLua(UScriptStruct* ScriptStruct, void* DataAddress, UObject* ParentObject);
protected:
	bool bExportObjectExtra;

	TMap<FString, FCustomStructExporter> CustomStructExporters;
};

class FDialogueEditorInfoExporter : public FLuaEditorInfoExporter
{
public:
	void JustExportEditorOnlyInfoToLua(UObject* Object, TSharedPtr<FLuaTable> OutLua);
};
