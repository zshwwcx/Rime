#pragma once
#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "ImportExport/LuaImporter.h"


class KGSTORYLINEEDITOR_API FDialogueImporter : public FLuaImporter
{
public:
	using FStructHandler = TFunction<bool(const FStructProperty*, void*, const TSharedPtr<FLuaValue>&, UObject*)>;
	
	virtual ~FDialogueImporter() override {}

	virtual void ImportLuaToObj(TSharedPtr<class FLuaTable> LuaTable, UObject* OutObject) override;
	virtual bool FillFObjectProperty(const FObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer) override;
	virtual bool FillFWeakObjectProperty(const FWeakObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer) override;
	virtual bool FillStructProperty(const FStructProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer) override;
	UObject* InstanceObject(const UClass* PropertyClass, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer);
	

protected:
	static class UDialogueAsset* GetDialogueAsset(UObject* Object);
	void FillUObject(const TSharedPtr<FLuaTable>& LuaTable, UObject* Outer);
	bool FillFDialogueAppearanceSelector(const FStructProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer);
	bool FillFBehaviorActorSelector(const FStructProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer);
	bool FillFDialoguePerformerSelector(const FStructProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer);
	bool FillFDialogueCameraSelector(const FStructProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer);

	void BuildLines(UDialogueAsset* DialogueAsset);
	void BuildEntityTree(UDialogueAsset* DialogueAsset);
	void BuildTracksTree(UDialogueAsset* DialogueAsset);
	void BuildActorInfos(UDialogueAsset* DialogueAsset);
	void RecoverCameraListFromTemplate(UDialogueAsset* DialogueAsset);

	void RegisterStructHandlers();
	void CheckAndCopy(UDialogueTrackBase* TemplateTrack, UDialogueTrackBase* TargetTrack, UDialogueAsset* DialgoueAsset);
	void AddDeferredSettingValue(const FProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer);
	struct FDeferredSettingValue
	{
		const FProperty* Property;
		void* Address;
		TSharedPtr<class FLuaValue> LuaValue;
		FWeakObjectPtr Outer;
	};

	TMap<void*, FDeferredSettingValue> PropertiesDeferredSettingValue;
	
	TMap<TWeakObjectPtr<UScriptStruct>, FStructHandler> StructHandlers;
	bool bStructHandlersInited = false;
};
