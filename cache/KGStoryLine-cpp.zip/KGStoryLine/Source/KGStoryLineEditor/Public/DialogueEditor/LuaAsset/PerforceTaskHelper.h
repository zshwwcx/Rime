#pragma once

#include "CoreMinimal.h"

class FPerforceTaskHelper
{
public:
	static bool RunP4Command(const FString& Command, FString& OutResult);
	static bool SetP4WorkSpace();
	static bool GetDepotPath(const FString& LocalPath, FString& DepotPath);
	static bool GetLocalPath(const FString& DepotPath, FString& LocalPath);
	static bool IsCheckedOutByOthers(const FString& FilePath, FString& CheckResult);
	static bool LockFile(const FString& FilePath);
	static bool IsUpToDate(const FString& FilePath);
};