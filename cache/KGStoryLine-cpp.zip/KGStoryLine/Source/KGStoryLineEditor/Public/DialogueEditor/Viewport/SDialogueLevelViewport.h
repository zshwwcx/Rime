// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Types/SlateStructs.h"
#include "Layout/Visibility.h"
#include "Input/Reply.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"
#include "LevelEditorViewport.h"
#include "SLevelViewport.h"
#include "Misc/FrameRate.h"


/** Overridden level viewport client for this viewport */
struct KGSTORYLINEEDITOR_API FCinematicViewportClient : FLevelEditorViewportClient
{
	FCinematicViewportClient();

	void SetViewportWidget(const TSharedPtr<SEditorViewport>& InViewportWidget) { EditorViewportWidget = InViewportWidget; }
};

class KGSTORYLINEEDITOR_API SDialogueLevelViewport : public SLevelViewport
{

};