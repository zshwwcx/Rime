#pragma once

#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Internationalization/StringTable.h"
#include "Engine/DeveloperSettings.h"

#include "DialogueEditorPreviewSettings.generated.h"



UENUM(BlueprintType)
enum class EAssistLineShowStrategy:uint8
{
	DragShowNearest = 3 UMETA(DisplayName = "拖拽显示最近"),
	DragShowAll = 0 UMETA(DisplayName = "拖拽显示所有"),
	AlwaysShow = 1 UMETA(DisplayName = "一直显示所有"),
	NeverShow = 2 UMETA(DisplayName = "从不显示"),
};

UCLASS(Config = Editor, DefaultConfig)
class KGSTORYLINEEDITOR_API UDialogueEditorPreviewSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UPROPERTY(Config, EditAnywhere)
	float PlayRate = 1.0f;

	UPROPERTY(Config, EditAnywhere, Category = "Viewport", meta = (DisplayName = "Field of View", ClampMin = 70.0f, ClampMax = 180.0f))
	float FOV;

	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "显示角色胶囊体"))
	bool ShowActorCollision = false;

	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "音频语言版本，默认为中文"))
	FString SoundBankLanguage = TEXT("Simplified Chinese");

	UPROPERTY(Transient, VisibleDefaultsOnly, Category = "Viewport", meta = (DisplayName = "当前视口绝对位置"))
	FTransform ViewportTransform;

	UPROPERTY(Config, EditAnywhere, Category = "Collision")
	float ShowHitBoxDuration = 2.0f;

	UPROPERTY(Config, EditAnywhere, Category = "Collision")
	bool BigWorldPreview;

	UPROPERTY(Config, EditAnywhere, Category = "Collision", meta = (DisplayName = "双击自动吸附子相机"))
	bool AutoAbsorb = true;

	UPROPERTY(Config, EditAnywhere, Category = "Collision", meta = (DisplayName = "辅助线显示策略"))
	EAssistLineShowStrategy AssistLineShowStrategy = EAssistLineShowStrategy::DragShowNearest;

	class FDialogueEditor* ActiveEditor;
	TArray<FString> OpendAssets;
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
};
