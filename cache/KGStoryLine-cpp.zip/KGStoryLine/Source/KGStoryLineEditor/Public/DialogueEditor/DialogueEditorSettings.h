#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"
#include "Engine/DeveloperSettings.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DialogueEditor/Widgets/AssetBrowser/SDialogueAssetBrowser.h"
#include "DialogueEditorSettings.generated.h"


USTRUCT(BlueprintType)
struct FActorTrackSubTracks
{
	GENERATED_BODY()
	UPROPERTY(EditDefaultsOnly,BlueprintReadOnly)
	TSubclassOf<class UDialogueSpawnableTrack> ActorTrackClass;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TArray<TSubclassOf<class UDialogueActionTrack>> SubTrackClasses;

};
UCLASS(Config = Editor, DefaultConfig, meta = (DisplayName = "Dialogue Editor Settings"))
class KGSTORYLINEEDITOR_API UDialogueEditorSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene")
	TSoftObjectPtr<UWorld> DefaultViewMap;

	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene", meta = (Tooltip = "Player type for ability preview"))
	TSubclassOf<class APlayerCameraManager> CameraManagerClass;

	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene", meta = (Tooltip = "Player type for ability preview"))
	TSubclassOf<UDialogueActor> PlayerType = UDialogueActor::StaticClass();

	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene", meta = (Tooltip = "Camera type for ability preview"))
	TSubclassOf<UDialogueCamera> CameraType = UDialogueCamera::StaticClass();
	
	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene", meta = (Tooltip = "routepoint entity type"))
	TSubclassOf<UDialogueEntity> RoutePointEntityType = UDialogueEntity::StaticClass();

	UPROPERTY(Config, EditAnywhere, Category = "Entity", meta = (Tooltip = "SpawnableTrack对应的EntityClass"))
	TMap<TSubclassOf<class UDialogueSpawnableTrack>, TSubclassOf<class UDialogueEntity> > TrackEntityClass;

	UPROPERTY(Config, EditAnywhere, Category = "PreviewScene", meta = (Tooltip = "Camera type for ability preview"))
	TSoftClassPtr<class UUserWidget> DialogueWidgetClass;

	UPROPERTY(Config, EditAnywhere,  meta = (Tooltip = "Extension class path"))
	TSubclassOf<UDialogueLineExtension> ExtensionClass;
	
	UPROPERTY(Config, EditAnywhere, meta = (Tooltip = "Actor类型子轨道，不同的ActorEntity可以配置不同的SubTrack"))
	TArray<FActorTrackSubTracks> ActorSubTracks;

	UPROPERTY(Config, EditAnywhere, meta = (Tooltip = "路径点类型子轨道"))
	TArray<TSubclassOf<class UDialogueActionTrack>> RouterPointSubTracks;

	UPROPERTY(Config, EditAnywhere, meta = (Tooltip = "Camera类型子轨道"))
	TArray<TSubclassOf<class UDialogueActionTrack>> CameraSubTracks;

	UPROPERTY(EditDefaultsOnly,Config)
	TSubclassOf<APlayerController> PlayerControllerClass;
	
	//蓝图扩展的子轨道
	UPROPERTY(EditDefaultsOnly, Config)
	TArray<TSubclassOf<class UDialogueTrackBase>>    BlueprintTracks;

	//SpecialSubTracks轨道，如塔罗牌，这些轨道需要放在二级菜单里面
	UPROPERTY(EditDefaultsOnly, Config)
	TArray<TSubclassOf<class UDialogueTrackBase>>    SpecialSubTracks;

	//资产里面只可以有一个轨道的类型,这种Track不能重复添加
	UPROPERTY(EditDefaultsOnly, Config)
	TArray<TSubclassOf<class UDialogueTrackBase>>    UniqueTracks;

	//已过时不再开放给策划配置的Track Class
	UPROPERTY(EditDefaultsOnly, Config)
	TArray<TSubclassOf<class UDialogueTrackBase>> DeprecatedTrackClass;

	//重新生成对话资产的时候，不要清空的轨道如黑屏、白字轨道
	UPROPERTY(EditDefaultsOnly, Config)
	TArray<TSubclassOf<class UDialogueTrackBase>>    GenerateNoneClearClass;

	//功能Track列表：可以在这个轨道右键->AddAllSectionsForLine，一键为这个轨道批量添加对应各个台本的Sections
	UPROPERTY(EditDefaultsOnly, Config)
	TArray<TSubclassOf<class UDialogueActionTrack>>    NeedAddAllSectionCommandTracks;

	//对话资产在蓝图级别的子类
	UPROPERTY(EditDefaultsOnly, Config)
	TSubclassOf<class UDialogueAsset>    DialogueAssetClass;

	//编辑器打开的时候，隐藏场景的一些特殊Actor
	UPROPERTY(EditDefaultsOnly, Config)
	TArray<TSubclassOf<class AActor>>    HideSceneActors;

	//编辑器打开的时候，是否显示小的预览场景
	UPROPERTY(EditDefaultsOnly, Config, meta=(DisplayName = "是否显示小预览窗口"))
	uint8    bShowPreviewViewport:1;

	UPROPERTY(Config, EditAnywhere, Category = "Viewport")
	float DepthOfFieldFocalDistance = 10000.0f;
	UPROPERTY(Config, EditAnywhere, Category = "Viewport")
	float DepthOfFieldSensorWidth = 100.0f;

	//SectionColor
	UPROPERTY(EditDefaultsOnly, Config, Category=Section)
	FLinearColor    SectionNormalColor = FLinearColor(FColor(0, 160, 160));
	UPROPERTY(EditDefaultsOnly, Config, Category = Section)
	FLinearColor    SectionDisableColor = FLinearColor(FColor(120, 0, 0));
	UPROPERTY(EditDefaultsOnly, Config, Category = Section)
	FLinearColor    SectionSelectColor = FLinearColor(FColor(0, 255, 0));
	UPROPERTY(EditDefaultsOnly, Config, Category = Section)
	FLinearColor    SectionInValidColor = FLinearColor(FColor(255, 0, 0));
	UPROPERTY(EditDefaultsOnly, Config, Category = Section)
	FLinearColor    SectionOverlapColor = FLinearColor(FColor(255, 0, 255));
	UPROPERTY(EditDefaultsOnly, Config, Category = Section)
	FLinearColor    SectionAdjustEdgeColor = FLinearColor(FColor(128, 255, 0, 128));
	UPROPERTY(EditDefaultsOnly, Config, Category = Section)
	FLinearColor    SectionSameLinkGUIDColor = FLinearColor(FColor(255, 255, 0, 128));
	FLinearColor    SectionAutoLinkColor = FLinearColor(FColor(0xff,0x4d, 0x6d, 0xff));

	UPROPERTY(Config, EditAnywhere, NonTransactional)
	bool EnableDialogueUndoRedo = true;

	//编辑器时是否允许Section重叠
	UPROPERTY(Config, EditAnywhere)
	bool EnableSectionOverlap = false;

	//选择Actor轨道时，3D场景是否自动定位对应的Actor
	UPROPERTY(Config, EditAnywhere)
	bool EnableAutoLocateSceneActor = true;

	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "显示LookAt点位信息"))
	bool EnableLookAtDrawDebug = false;

	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Import时是否弹确认框"))
	bool ImportEnsureBox = true;

	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "保存时是否弹框确认Export"))
	bool SaveExportEnsureBox= true;

	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "是否所有Section都显示辅助线，如果否，则手动填写:需要绘制辅助线的Section列表", Category = "辅助线"))
	bool AllSectionAssistLine = false;

	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "需要绘制辅助线的Section列表", Category = "辅助线"))
	TArray<TSubclassOf<UDialogueActionTrack>> NeedDrawAssistLineSections;

	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "辅助线颜色", Category = "辅助线"))
	FLinearColor AssistLineColor = FLinearColor::Yellow;

	UPROPERTY(Config, EditAnywhere, meta=(DisplayName = "WWise Events路径"), Category="Sound")
	FDirectoryPath WWiseEvents;

	UPROPERTY(Config, EditAnywhere, meta=(DisplayName = "台本列表默认显示字段"), Category="台本编辑器")
	TArray<FString> DefaultColumns;

public:
	UFUNCTION(BlueprintCallable)
	FString GetWWiseEventsAbsPath() const;
#if WITH_EDITOR
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif
};

UCLASS(config = EditorPerProjectUserSettings)
class UDialogueEditorPerProjectUserSettings : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(Config, EditAnywhere, meta=(DisplayName = "新界面布局", Category="测试功能"))
	bool bNewLayout=false;

	UPROPERTY(Config, EditAnywhere, meta=(DisplayName = "新布局下是否显示相机列表", Category="测试功能"))
	bool bShowCameraList=true;

	UPROPERTY(Config, EditAnywhere)
	EDialogueAssetViewType AssetViewType=EDialogueAssetViewType::Folder;

	UPROPERTY(Config, EditAnywhere)
	TArray<FString> FavoriteFolderPaths;

	UPROPERTY(Config, EditAnywhere)
	TArray<FString> HistoryAssets;

	void AddHistoryAsset(const FString& AssetName);
};