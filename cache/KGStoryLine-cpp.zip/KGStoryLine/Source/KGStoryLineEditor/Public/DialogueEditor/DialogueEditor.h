#pragma once

#include "CoreMinimal.h"
#include "EditorUndoClient.h"
#include "EditorViewportClient.h"
#include "AdvancedPreviewSceneModule.h"
#include "WorkflowOrientedApp/WorkflowTabManager.h"
#include "WorkflowOrientedApp/WorkflowCentricApplication.h"
#include "Evaluation/MovieSceneCameraShakePreviewer.h"

#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackNode.h"
#include "KGStoryLineConst.h"
#include "DialogueEditor/Context/KGSLEdContextMgr.h"

DECLARE_MULTICAST_DELEGATE(FOnGenarateDaialogue);
DECLARE_MULTICAST_DELEGATE(FDaialogueConstructGraph);

namespace DialogueEditorModes
{
	extern const FName Main;
	extern const FName Template;
};

namespace DialogueEditorEditorTabs
{
	extern const FName ViewportTab;
	extern const FName AssetEdit;
	extern const FName AssetBrowser;
	extern const FName AssetGraph;
	extern const FName OptionGraph;
	extern const FName AssetDetails;
	extern const FName AssetOperationPanel;
	extern const FName Details;
	extern const FName PreviewSettings;

};

class KGSTORYLINEEDITOR_API IDialogueEditor : public FWorkflowCentricApplication
{
public:
	static TSharedPtr<IDialogueEditor> OpenEditor(UObject* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost);

	static bool ProcessOtherOpen();

	virtual class UDialogueBaseAsset* GetEditingAsset() = 0;

protected:
	virtual void InitializeEditor(class UDialogueBaseAsset* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost) = 0;

	virtual TSharedPtr<class FDialogueEditorSceneProxy> GetPreviewScene() const = 0;

};


class KGSTORYLINEEDITOR_API FDialogueEditor : public IDialogueEditor, public FGCObject, public FEditorUndoClient
{
public:
	FDialogueEditor();
	virtual ~FDialogueEditor();

	FKGSLEdContextMgr& GetEditorContextMgr() const;
	virtual class UDialogueBaseAsset* GetEditingAsset() override;
	virtual class UDialogueAsset* GetDialogueAsset();
	bool OnCanCloseLevelEditorTab();
	virtual void InitializeEditor(class UDialogueBaseAsset* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost) override;
	virtual TSharedPtr<class FDialogueEditorSceneProxy> GetPreviewScene() const override;
	class UDialogueEditorPreviewSettings* GetPreviewSettings();
	class UDialogueEditorManager* GetDialogueEditorManager();
	TSharedPtr<class SDialogueEditorViewport> GetViewportWidget();

	virtual bool OnRequestClose(EAssetEditorCloseReason InCloseReason) override;
	
	// 关闭
	void OnClose() override;

	// 重载改变当前编辑模式
	void SetCurrentMode(FName NewMode) override;

	// 保存
	void SaveAsset_Execute() override;

	void RegisterTabSpawners(const TSharedRef<class FTabManager>& TabManager) override;

	void UnregisterTabSpawners(const TSharedRef<class FTabManager>& TabManager) override;

	void OnActiveTabChange(TSharedRef<SDockTab> ActiveTab, ETabActivationCause Cause);

	FText GetBaseToolkitName() const override;

	void CreateEditorWorldExtension();
	void DestroyEditorWorldExtension();

	FName GetToolkitFName() const override;

	FString GetWorldCentricTabPrefix() const override;

	FLinearColor GetWorldCentricTabColorScale() const override;

	void InitPreviewContext();

	virtual void CreatePreviewProxy();

	virtual TSharedPtr<class FDialogueEditorPreviewProxy> GetPreviewProxy() const;

	void SetDetailWidget(TSharedPtr<class SDialogueEditorDetailTab> InDetailWidget);

	void ShowObjectDetail(UObject* InObject);

	void SetTrackSelected(UObject* InObject, bool bSelectActor = true);
	void DoubleClickTrack(UObject* InObject);
	void SetSectionSelected(class UDialogueActionBase* Section);
	bool IsTrackPressingCtrl();
	
	//设置场景内的Actor可见性，ExcludeActor除外
	void SetPreviewCameraVisible(AActor* ExcludeActor, bool Visible);

	// 和引擎GC相关，添加引用的对象
	void AddReferencedObjects(class FReferenceCollector& Collector);

	void SetSelectActorHere(const FVector& Location);

	virtual FString GetReferencerName() const override
	{
		return TEXT("FDialogueEditor");
	}

	void AddDialogueActor(class UDialogueEntity* DialogueEntity);
	void RemoveDialogueActor(class UDialogueEntity* DialogueEntity);
	AActor* GetEntityActor(class UDialogueEntity* DialogueEntity);

	void SetViewportCameraCutEnabled(bool bEnabled);

	bool IsViewportCameraCutEnabled() { return bViewportCameraCutEnabled; }

	void ModifyViewportClientView(FEditorViewportViewModifierParams& Params);

	bool ShouldPauseWorld() const;

	//获取有效的窗口，用来实时更新相机信息，如果是大世界，则返回主编辑器的窗口，否则返回编辑器窗口
	FEditorViewportClient* GetActiveViewportClient();
	FEditorViewportClient* GetUEMainViewportClient();
	void OnViewportClientListChanged();
	AActor* GetSelectActor() { return SelectActor.Get(); }

	virtual bool IsTemplateMode() { return false; }

	UWorld* GetWorld();
	bool OnLockCameraClicked(class UDialogueCamera* DialogueEntity,  bool IsLockAutoCamera=false);
	void SetViewportParamByCameraActor(class ACameraActor* CameraActor);

	void OnWorldSelectedChange(UObject* SceneObject);
	void OnWorldSelectComponentChange(UObject* Component);
	void OnSelectorActorsModify(UObject* Object);
	void OnUndoRedo();
	void HandleMapChanged(UWorld* NewWorld, EMapChangeType MapChangeType);
	void OnMapBeginLoad(const FString& Filename, FCanLoadMap& CanLoad); 
	void OnMapOpened(const FString& Filename, bool bAsTemplate);
	void SetSelectCameraComponent(class UCameraComponent* CameraComponent);

	void InitBigWorldPreview();

	void SetFocusCamera(AActor* CameraActor);
	AActor* GetFocusCamera();

	void SetCurrentSelectEpisode(int EpisodeID, bool bForceRefreshUI=true);
	int  GetCurrentEpisodeID();
	void SetPlayStartTime(float InPlayStartTime);

	void OnAutoCameraToDialogueCamera();
	void OnDialogueCameraToAutoCamera();

	void RefreshAudio2FaceMatchAudioDialogue();

	void OnAllEntityReady();
	
	void CreateAutoCuts();

	bool bNeedCreateAutoCutsOnAllEntityReady = false;

	//从第几句对话开始预览，这个变量更加优先
	int				PlayStartDialogueLineIndex = -1;

	//当前预览的起始播放时间
	float			PlayStartTime = 0.0f;  

	//当前正在选中的相机组件，要求名字不能是CameraComponent，而是Spline上的相机组件
	TWeakObjectPtr<class UCameraComponent> SelectCameraComponent = nullptr;

	TArray<TWeakObjectPtr<UObject>> CurrentSelectObject;

	//当前选中的Section
	TArray<TWeakObjectPtr<UDialogueActionBase>> CurrentSelectSection;
	
	bool SelectSectionLatest = false; //可以先后选中Track和Section，这个变量用于标识最新选中的是否是Section

	bool IsSectionPressCtrl = false;
	bool IsSectionPressShift = false;
	bool IsTrackPressCtrl = false;

	//用于在Section之间拷贝LinkGUID数据
	FGuid CurrentCopySectionLinkUniqueID;

private:
	//当前正在注视的相机，注视这个相机时，其他相机隐藏
	TWeakObjectPtr<class AActor> FocusCamera = nullptr;

	TWeakObjectPtr<class UDialogueEditorWorldExtension> EditorWorldExtension;

	bool bViewportCameraCutEnabled = false;
	int CurrentSelectEpisodeID = 0;
	FDelegateHandle SelectionChangedEventHandle;
	FDelegateHandle SelectionComponentModifiedEventHandle;
	int64 SelectTrackTimeTicks = 0; //用于连续点击时，双击选中camera
protected:
	TWeakObjectPtr<class UDialogueBaseAsset> EditAsset = nullptr;
	TUniquePtr<FKGSLEdContextMgr> EditorContextMgr = nullptr;
	TWeakObjectPtr<AActor> SelectActor = nullptr;
	TSharedPtr<SImage> BorderCameraEditing;
	FEditorViewportClient* ActiveViewportClient = nullptr;
	
	FDelegateHandle ViewportClientListChangedHandle;

public:
	TWeakObjectPtr<class UDialogueCamera> ClickCameraEntity=nullptr;

	bool IsLockAutoCamera = false;
	
	//场景中选中Actor时，需要通知TimelineController将对应的Track执行选中操作
	TWeakPtr<class FDialogueEditorTimelineController> DialogueTimelineController;

	TWeakPtr<class SDialogueEditorTimelineTab> DialogueEditorTimelineTab;
	void SetSpecialActorVisible(class UWorld* World, bool Visible);

    void GetCachedPOVInfo(float& LocX, float& LocY, float& LocZ, float& Pitch, float& Yaw, float& Roll, float& FOV);

protected:
	// 创建预览场景
	void CreatePreviewScene();
	void AddOrRemoveLevelEditorCanTabCloseDelegate(bool bAdd);
protected:
	// 工具栏命令绑定
	virtual void BindCommands();

	// 扩展工具栏
	virtual void ExtendToolbar();

	// 编辑器预览窗口
	TSharedPtr<class SDialogueEditorViewport> Viewport;

	// 预览场景
	TSharedPtr<class FDialogueEditorSceneProxy> PreviewScene;

	// 预览配置
	TWeakObjectPtr<class UDialogueEditorPreviewSettings> PreviewSettings;

	// 预览代理
	TSharedPtr<class FDialogueEditorPreviewProxy> PreviewProxy;

	// 属性编辑窗口
	TSharedPtr<class SDialogueEditorDetailTab> DetailWidgetPtr;

    FVector CachedPOVLocation;
    FRotator CachedPOVRotation;
    float CachedPOVFOV = 0.f;
private:
	// 工具栏
	TSharedPtr<class FDialogueEditorToolbar> EditorToolbar;

	// 工具栏
	TSharedPtr<class FExtender> ToolbarExtender;
#pragma region Command
protected:
	void PlayBigWorld();
	void PlayInternal();

	void Pause();


	void ForwardStep();

	void BackwardStep();

	FOnGenarateDaialogue GenarateDialogueEvent; 
	FDaialogueConstructGraph   DialogueEventConstructGraph;
public:
	void Stop();
	bool IsPlaying() const;

	bool IsPaused() const;

	bool IsStopped() const;

	FOnGenarateDaialogue& GetGenarateDaialogueEvent() { return GenarateDialogueEvent; }
	FDaialogueConstructGraph& GetDialogueReConstructGraph() { return DialogueEventConstructGraph; }

	void SetDialogueState(bool bPause);
#pragma endregion Command
private:
	void InitLuaEnvironment();
	void UnInitLuaEnvironment();
    class UEditorLuaEnv *LuaEnv = nullptr;
};


#pragma region Template

class FDialogueTemplateEditor : public FDialogueEditor
{
	virtual void InitializeEditor(class UDialogueBaseAsset* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost) override;

	// 工具栏命令绑定
	virtual void BindCommands() override;
	virtual void ExtendToolbar() override;

public:
	virtual bool IsTemplateMode() { return true; }
};

#pragma endregion Template


#pragma region Main
class FDialogueMainEditor : public FDialogueEditor
{
	virtual void InitializeEditor(class UDialogueBaseAsset* InAsset, const TSharedPtr<IToolkitHost>& InitToolkitHost) override;

	/** Called when "Save" is clicked for this asset */
	virtual void SaveAsset_Execute();

	virtual void GetSaveableObjects(TArray<UObject*>& OutObjects) const override;
public:
	virtual ~FDialogueMainEditor();
	void CopySelectObject();
	void PasteSelectObject();
	void DeleteSelectObject();
	void MoveSelectSection(bool IsLeft);
	void GenerateDialogue();
protected:
	virtual void BindCommands() override;

	void OnClickGenerateDialogue();
	
	void ImportDialogue();
	void ExportDialogue();
	void ExportOptionText();
	void SyncTemplate();
	void SaveAsTemplate();
	void SaveAsTemplate_Internal(const FString& Path);
	void CheckInValidAsset();
	void OnDialogueAssetTemplateChanged();

	void OnCustomSelectorChanged(FString InTrackName);

	void OnAssetEpisodeLinesCountChange();
	void OnDefaultInitExcelData();
	void AddEpisode();
};
#pragma endregion Main