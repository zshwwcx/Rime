#pragma once


enum class EKGSLEdContextIdentifier
{
	None = 0,
	SectionAutoLinkLine = 1,
};