// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Context/KGSLEdContext.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"

DECLARE_MULTICAST_DELEGATE_TwoParams(FKGSLEdContextSwitchLinkTarget, UDialogueDialogue*, UDialogueDialogue*);

/**
 * FKGSLEdCtxSectionAutoLinkLine
 */
class  FKGSLEdCtxSectionAutoLinkLine : public FKGSLEdContext
{
public:
	FKGSLEdCtxSectionAutoLinkLine(EKGSLEdContextIdentifier ContextID, uint32 InPriority, bool bInUnique);
	virtual ~FKGSLEdCtxSectionAutoLinkLine();

	virtual void OnInitialized() override;
	virtual void OnUninitialized() override;
	virtual bool IsValid() const override;
	virtual void OnActionSectionAdded(class UDialogueAsset* Asset, class UDialogueActionBase* SectionAdded) override;
	virtual void OnActionSectionRemoved(class UDialogueAsset* Asset, class UDialogueActionBase* SectionRemoved) override;

	bool IsCurrentLinkTarget(UDialogueDialogue* Section) const;
	UDialogueDialogue* GetCurrentLinkSection() const;
	bool SetCurrentLinkSection(UDialogueDialogue* Section);

public:
	FKGSLEdContextSwitchLinkTarget OnCurrentLinkSectionChanged;
private:
	TWeakObjectPtr<UDialogueDialogue> TargetAction;
	uint32 EpisodeID = KGStoryLine::INVALID_EPISODE_ID;
	uint64 LineGUID = KGStoryLine::INVALID_LINE_GUID;
	FGuid LineUniqueID;
};

template<>
struct TKGSLEdContextTypeTraits<FKGSLEdCtxSectionAutoLinkLine> : public TkGSLEdContextTypeBaseTraits<FKGSLEdCtxSectionAutoLinkLine>
{
	enum
	{
		WithOnActionSectionAdded = true,
		WithOnActionSectionRemoved = true,
	};
	static constexpr bool bUnique = true;
	static constexpr uint16 Priority = 0;
	static constexpr EKGSLEdContextIdentifier ContextIdentifier = EKGSLEdContextIdentifier::SectionAutoLinkLine;
};