// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Context/KGSLEdContext.h"

enum class EKGSLEdContextType : uint8
{
	Unknown = 0,
	SectionAutoLinkLine = 1,
};

/**
 * FKGSLEdContextMgr
 */
class FKGSLEdContextMgr
{
public:
	FKGSLEdContextMgr();
	~FKGSLEdContextMgr();

	template<typename T>
	TSharedPtr<T> GetContext()
	{
		constexpr EKGSLEdContextIdentifier ContextIdentifier = TKGSLEdContextTypeTraits<T>::ContextIdentifier;
		
		for (auto& Context : Contexts)
		{
			if (Context.IsValid() && Context->GetContextID() == ContextIdentifier)
			{
				return StaticCastSharedPtr<T>(Context);
			}
		}

		return nullptr;
	}
	
	template<typename T>
	TArray<TSharedPtr<FKGSLEdContext>> GetContexts() const
	{
		constexpr EKGSLEdContextIdentifier ContextIdentifier = TKGSLEdContextTypeTraits<T>::ContextIdentifier;
		TArray<TSharedPtr<FKGSLEdContext>> Results;
		for (auto& Context : Contexts)
		{
			if (Context.IsValid() && Context->GetContextID() == ContextIdentifier)
			{
				Results.Add(Context);
			}
		}

		return Results;
	}
	
	template<typename T>
	bool HasContext() const
	{
		TSharedPtr<T> Result = GetContext<T>();
		return Result.IsValid();
	}
	
	template<typename T, typename... Args>
	TSharedPtr<T> PushContext(Args... InArgs)
	{
		constexpr bool bUnique = TKGSLEdContextTypeTraits<T>::bUnique; 
		if constexpr (bUnique)
		{
			TSharedPtr<T> FoundContext = GetContext<T>();
			if (FoundContext.IsValid())
			{
				return FoundContext;
			}
		}

		constexpr EKGSLEdContextIdentifier ContextIdentifier = TKGSLEdContextTypeTraits<T>::ContextIdentifier;
		uint32 DefaultPriority = TKGSLEdContextTypeTraits<T>::Priority;
		uint32 Priority = DefaultPriority << 16 | GetToken();
		TSharedPtr<T> Context(new T(ContextIdentifier, Priority, bUnique, Forward<Args>(InArgs)...));
		Contexts.HeapPush(Context);

		if constexpr (TKGSLEdContextTypeTraits<T>::WithOnActionSectionAdded)
		{
			ContextsResponseOnActionSectionAdded.Add(Context);
		}

		if constexpr (TKGSLEdContextTypeTraits<T>::WithOnActionSectionRemoved)
		{
			ContextsResponseOnActionSectionRemoved.Add(Context);
		}

		Context->Initialize();
		
		return Context;
	}

	TSharedPtr<FKGSLEdContext> PopContext(TSharedPtr<FKGSLEdContext> InContext, bool bNeedSort = true)
	{
		if (InContext.IsValid())
		{
			InContext->Uninitialize();
		}
		
		ContextsResponseOnActionSectionAdded.Remove(InContext);
		ContextsResponseOnActionSectionRemoved.Remove(InContext);
		
		Contexts.RemoveSingle(InContext);
		if (bNeedSort)
		{
			Contexts.HeapSort();
		}

		return InContext;
	}

	void OnActionSectionAdded(class UDialogueAsset* Asset, class UDialogueActionBase* SectionAdded);
	void OnActionSectionRemoved(class UDialogueAsset* Asset, class UDialogueActionBase* SectionRemoved);
private:
	static uint16 GetToken() noexcept
	{
		static uint16 Token = 0;
		++Token;
		Token = Token & 0xFFFF;
		return Token;
	}
	
private:
	TArray<TSharedPtr<FKGSLEdContext>> Contexts;
	TArray<TSharedPtr<FKGSLEdContext>> ContextsResponseOnActionSectionAdded;
	TArray<TSharedPtr<FKGSLEdContext>> ContextsResponseOnActionSectionRemoved;
};
