// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include  "DialogueEditor/Context/KGSLEdContextDefine.h"
class UDialogueAsset;
/**
 * FKGSLEdContext
 */
class FKGSLEdContext : public TSharedFromThis<FKGSLEdContext>
{
public:
	explicit FKGSLEdContext(EKGSLEdContextIdentifier InContextID,uint32 InPriority = 0, bool bInUnique = false);
	virtual ~FKGSLEdContext();

	bool operator<(const FKGSLEdContext& Other) const;
	
	EKGSLEdContextIdentifier GetContextID() const noexcept { return ContextID; }
	
	void SetUnique(bool bInUnique);
	bool IsUnique() const noexcept { return bUnique; }

	void SetPriority(uint32 InPriority);
	uint32 GetPriority() const noexcept { return Priority; }
	
	void Initialize();
	void Uninitialize();

	virtual bool IsValid() const { return bValidation; }
	void SetValidation(bool InValidation) { bValidation = InValidation; }
	virtual void OnInitialized() {}
	virtual void OnUninitialized() {}
	virtual void OnActionSectionAdded(class UDialogueAsset* Asset, class UDialogueActionBase* Section) {}
	virtual void OnActionSectionRemoved(class UDialogueAsset* Asset, class UDialogueActionBase* Section) {}
protected:
	// context identifer
	EKGSLEdContextIdentifier ContextID;

	/*
	 * The bigger value is heigher
	 */
	uint32 Priority = 0;

	/*
	 * will be unique in priority queue of KGSLEdContextMgr
	 */
	bool bUnique = false;

	bool bValidation = true;
	
};

bool operator<(const TSharedPtr<FKGSLEdContext>& A, const  TSharedPtr<FKGSLEdContext>& B);

template<typename T>
struct TkGSLEdContextTypeBaseTraits
{
	enum
	{
		WithOnActionSectionAdded = false,
		WithOnActionSectionRemoved = false,
	};
};

template <typename T>
struct TKGSLEdContextTypeTraits : public TkGSLEdContextTypeBaseTraits<T>
{
	static constexpr bool bUnique = false;
	static constexpr uint16 Priority = 0;
	static constexpr EKGSLEdContextIdentifier ContextIdentifier = EKGSLEdContextIdentifier::None;
};