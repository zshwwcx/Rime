#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/Dialogue/DialogueEntity.h"

class FDialogueAutoTools
{
public:
	static FString GenerateAvailableTrackName(class UDialogueBaseAsset* Asset, const FString& Prefix);

	static UDialogueCamera* AddNewCameraTrack(UDialogueAsset* Asset, FString TrackName);
	
	static TArray<UDialogueEntity*> RemoveAllAutoTracks(UDialogueAsset* Asset);
	
	static FString LookAtTrackPath;
	
	static FString CameraShotTrackPath;

	static FString OldLookAtTrackPath;

	static UDialogueActionTrack* FindLookAtTrack(UDialogueAsset* DialogueAsset, UDialogueActorTrack* ActorTrack);
	
	static UDialogueActionTrack* FindOrAddLookAtTrack(UDialogueAsset* DialogueAsset, UDialogueActorTrack* ActorTrack);
	
	static UDialogueActionTrack* RecreateCameraShotTrack(UDialogueAsset* DialogueAsset, struct FDialogueEpisode& Episode);

	static bool IsLookAtEmpty(UDialogueAsset* DialogueAsset);
	
	static void CreateMultiAutoCameras(class UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager);

	static void CreateAutoCameras(class UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager);

	static void CreateAutoLookAts(class UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager, bool CoveragePrompt=false);

	static void CreateLookAts(class UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager, bool CoveragePrompt=false);

	static void CreateAutoLookAtAndCuts(class UDialogueAsset* DialogueAsset, FDialogueEditor* DialogueEditor, UDialogueEditorManager* InDialogueEditorManager, bool CoveragePrompt, const bool bManualTrigger);
};
