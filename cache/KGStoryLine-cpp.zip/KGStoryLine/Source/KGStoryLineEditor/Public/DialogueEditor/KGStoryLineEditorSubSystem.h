// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DataTableEditorUtils.h"
#include "EditorSubsystem.h"
#include "DialogueEditor/DialogueEditor.h"
#include "Kismet2/ListenerManager.h"
#include "KGStoryLineEditorSubSystem.generated.h"

class UKGSLDialogueEpisode;
class UDialogueBaseAsset;
class UKGSLDialogueLine;

enum class EKGSLDataChangeInfo
{
	// 台本编辑
	LineData,
	LineAdded,
	LineRemoved,
	LineSwapped,
	LineSelected,
	EditorFieldOrderChanged,
	
	// 小段编辑
	EpisodeData,
	EpisodeAdded,
	EpisodeRemoved,
	EpisodeSwapped,
	EpisodeSelected,
	
	// 选项编辑
	OptionData,
	OptionAdded,
	OptionRemoved,
	OptionSwapped,
	OptionSelected,

	ImportDialog,
};


/**
 * 
 */
UCLASS()
class KGSTORYLINEEDITOR_API UKGStoryLineEditorSubSystem : public UEditorSubsystem
{
	GENERATED_BODY()
public:
	
	class ListenerType
	{
	public:
		template<typename...ListenEventType>
		ListenerType(ListenEventType&&...Args)
		{
			Get().AddListener(this, std::forward<ListenEventType>(Args)...);
		}
		
		virtual ~ListenerType()
		{
			Get().RemoveListener(this);
		}
		virtual void PreChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType) = 0;
		virtual void PostChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo ChangedType) = 0;
		virtual void SelectionChange(const UDialogueAsset* Asset, int32 EpisodeID, FName LineName){}
		virtual void OnEpisodeSelectionChanged(const UDialogueAsset* Asset, int32 EpisodeID){}
	};
public:
	static UKGStoryLineEditorSubSystem& Get();
	static UKGStoryLineEditorSubSystem* GetPtr();
	
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UDialogueBaseAsset* GetAsset(int32 EpisodeID);
	TSharedPtr<FDialogueEditor> GetEditor(int32 EpisodeID) const;
	TSharedPtr<FDialogueEditor> GetEditor(UDialogueBaseAsset* Asset) const;

	TSharedPtr<FDialogueEditor> GetInUsingEditor();
	
	bool RegisterAsset(UDialogueBaseAsset* Asset, TSharedPtr<FDialogueEditor> Editor);
	bool UnregisterAsset(const UDialogueBaseAsset* Asset);

	bool IsDialogueEditorOpen() const;

	template< typename... ArgsType>
	void AddListener(ListenerType* Listener, ArgsType&&... Args)
	{
		(AddOneListener(Listener, std::forward<ArgsType>(Args)), ...);
	}

	template<typename T, std::enable_if_t<std::is_same_v<T, EKGSLDataChangeInfo>, bool> = true>
	void AddOneListener(ListenerType* Listener, T&& DataChangeType)
	{
		if(!Listeners.Contains(DataChangeType))
		{
			Listeners.Add(DataChangeType, TSet<ListenerType*>());
		}

		Listeners[DataChangeType].Add(Listener);
	}

	void RemoveListener(ListenerType* Listener);
	void PreChange(const UDialogueAsset* Asset, EKGSLDataChangeInfo ChangeInfo);
	void PostChange(const UDialogueAsset* Asset, EKGSLDataChangeInfo ChangeInfo);
	
	static void BroadcastPreChanged(const UDialogueAsset* Asset, EKGSLDataChangeInfo ChangeInfo);
	static void BroadcastPostChanged(const UDialogueAsset* Asset, EKGSLDataChangeInfo ChangeInfo);
	static void SelectLine(const UDialogueAsset* Asset,int32 EpisodeID, FName LineName);
	static UKGSLDialogueLine* AddLine(UDialogueAsset* Asset, int32 EpisodeID, const FString& Content = TEXT(""));
	static UKGSLDialogueLine* InsertLine(UDialogueAsset* Asset, int32 EpisodeID, int32 InsertPos, const FString& Content = TEXT(""));
	static UKGSLDialogueLine* DuplicateLine(UDialogueAsset* Asset, int32 EpisodeID, int32 SrcLineIndex);
	static bool RemoveLine(UDialogueAsset* Asset, int32 EpisodeID, int32 LineIndex);
	static bool MoveRow(UDialogueAsset* Asset, int32 EpisodeID, int32 LineIndex, FDataTableEditorUtils::ERowMoveDirection Direction, int32 	NumRowsToMoveBy = 1);
	static bool DiffersFromDefault(UDialogueAsset* Asset, int32 EpisodeID, int32 LineIndex);
	static bool ResetToDefault(UDialogueAsset* Asset, int32 EpisodeID, int32 LineIndex);

	static UKGSLDialogueEpisode* AddEpisode(UDialogueAsset* Asset, const TFunction<void(UKGSLDialogueEpisode*)>& Callback = 
	nullptr);
	static UKGSLDialogueEpisode* DuplicateEpisode(UDialogueAsset* Asset, int32 SrcEpisodeID);
	static bool RemoveEpisode(UDialogueAsset* Asset, int32 EpisodeID);
	static void SelectEpisode(UDialogueAsset* Asset, int32 EpisodeID);
private:
	void OnAssetRemoved(const FAssetData& InAssetData);
private:
	TMap<TWeakObjectPtr<UDialogueBaseAsset>, TSharedPtr<FDialogueEditor>> AssetsToEditors;
	TMap<EKGSLDataChangeInfo, TSet<ListenerType*>> Listeners;
};

typedef UKGStoryLineEditorSubSystem::ListenerType INotifyOnKGSLDataChanged;

