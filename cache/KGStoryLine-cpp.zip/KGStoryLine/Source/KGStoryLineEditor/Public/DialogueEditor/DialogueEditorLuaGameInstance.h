#pragma once

#include "CoreMinimal.h"
#include "KGCore/Public/Lua/LuaEnv.h"
#include "LevelEditor.h"
#include "SLevelViewport.h"
#include "Blueprint/UserWidget.h"
#include "DialogueEditorLuaGameInstance.generated.h"


UCLASS(BlueprintType, Blueprintable)
class KGSTORYLINEEDITOR_API UDialogueEditorLuaGameInstance : public UEditorLuaGameInstanceBase
{
	GENERATED_BODY()

#pragma region Important
public:
	FString GetLuaFilePath_Implementation() const override;

	UFUNCTION(BlueprintCallable)
	void AddUI(UUserWidget* Widget);

	UFUNCTION(BlueprintCallable)
	void RemoveUI(UUserWidget* Widget);

	UFUNCTION(BlueprintCallable)
	FVector2D GetViewportSize();

#pragma endregion Important
};
