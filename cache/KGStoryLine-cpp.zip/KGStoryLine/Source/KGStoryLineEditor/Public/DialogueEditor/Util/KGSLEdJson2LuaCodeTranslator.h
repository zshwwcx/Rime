// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

/**
 * 
 */
class KGSTORYLINEEDITOR_API FKGSLEdJson2LuaCodeTranslator
{
public:

    using TranslatorPtr =  void (FKGSLEdJson2LuaCodeTranslator::*)(TSharedPtr<class FJsonValue>,
                                                           const FString&, bool, const FString&,
                                                           FStringBuilderBase&);
    
    explicit FKGSLEdJson2LuaCodeTranslator(TSharedPtr<class FJsonObject> InJsonObject);
    ~FKGSLEdJson2LuaCodeTranslator();
    FString Translate(bool bSortKey = true);

protected:
    void TranslateJsonValue(TSharedPtr<class FJsonValue> InJsonValue, const FString& Key,
                             bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder);
                             
    void TranslateJsonObject(TSharedPtr<class FJsonValue> InJsonValue, const FString& Key,
                             bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder);

    void TranslateJsonArray(TSharedPtr<class FJsonValue> InJsonValue, const FString& Key,
                            bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder);

    void TranslateJsonString(TSharedPtr<class FJsonValue> InJsonValue, const FString& Key,
                             bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder);


    void TranslateJsonNumber(TSharedPtr<class FJsonValue> InJsonValue, const FString& Key,
                             bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder);

    void TranslateJsonNumberStr(TSharedPtr<class FJsonValue> InJsonValue, const FString& Key,
                                bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder);

    void TranslateJsonBoolean(TSharedPtr<class FJsonValue> InJsonValue, const FString& Key,
                              bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder);

    void TranslateJsonNull(TSharedPtr<class FJsonValue> InJsonValue, const FString& Key,
                           bool bSortKey, const FString& InIndent, FStringBuilderBase& OutStringBuilder);

    TranslatorPtr GetTranslator(TSharedPtr<FJsonValue> InJsonValue) const;
    
private:
    TSharedPtr<class FJsonObject> JsonObject;
    static const FString IndentIdentifier; 
};
