#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "DataTableUtils.h"


namespace KGStoryLineEditor
{
	void CopyProperty(UKGSLDialogueLine* DstObj, UKGSLDialogueLine* SrcObj);
	void CopyProperty(UKGSLDialogueOption* DstObj, const FDialogueOption& Option);
	FText GetUObjectPropertyValueAsTextDirect(const class FProperty* Property, UObject* Object, int32 Index);
	FText GetUObjectPropertyValueAsText(const class FProperty* Property, UObject* Object);
}
