#pragma once

#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"
#include "Widgets/Layout/SConstraintCanvas.h"
#include "DialogueGossipBubbleManager.generated.h"

class UCanvasPanel;
class UCanvasPanelSlot;
class UUserWidget;
class FDialogueEditor;
class FDialogueEditorSceneProxy;
class SConstraintCanvas;

USTRUCT()
struct FDialogueGossipBubble
{
    GENERATED_BODY()

    UPROPERTY()
    int64 EntityID;
    
    UPROPERTY()
    TObjectPtr<UUserWidget> Widget;

    UPROPERTY()
    TObjectPtr<UCanvasPanelSlot> Slot;
};

/**
 * FDialogueGossipBubbleManager
 */
UCLASS()
class UDialogueGossipBubbleManager : public UObject
{
    GENERATED_BODY()
public:
    void Init(TWeakPtr<FDialogueEditor> InEditor);
    bool CalculateWidgetPositionInScreenSpace(const APlayerController* InPlayerController, int64 InEntityUID, UUserWidget* InUserWidget, FVector2D& OutScreenPos);
    void Tick(float DeltaTime);
    void SetUIRoot(class UWidget* InUIRoot);
    class UUserWidget* CreateGossipBubble(KGEntityID InEntityID, const FString& InWBPPath);
    void RemoveGossipBubble(KGEntityID InEntityID);
    void ClearAllGossipBubbles();
    void DestroyRootCanvas();
private:
    UPROPERTY()
    UWidget* UIRoot = nullptr;
    
    UPROPERTY(Transient)
    TMap<int64, FDialogueGossipBubble> GossipBubbleMap;

    TWeakPtr<FDialogueEditor> CachedEditor;

    UPROPERTY()
    UCanvasPanel* RootCanvas;
};





