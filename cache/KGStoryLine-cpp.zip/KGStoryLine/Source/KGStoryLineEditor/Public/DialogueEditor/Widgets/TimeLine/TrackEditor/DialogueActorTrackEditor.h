#pragma once

#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueTrackEditor.h"
#include "Widgets/SWidget.h"
#include "Widgets/Input/SCheckBox.h"

class KGSTORYLINEEDITOR_API FDialogueActorTrackEditor: public FDialogueTrackEditor
{
public:
	FDialogueActorTrackEditor(const TWeakPtr<class FTimelineController> InModel, const TWeakPtr<class FDialogueEditor>& InAssetEditor, UDialogueTrackBase* InTrack) :FDialogueTrackEditor(InModel, InAssetEditor, InTrack) {}

	virtual void BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder) override;

	virtual const FSlateBrush* GetIconBrush() const override;

	void AddActorSubTrack(TSubclassOf<class UDialogueActionTrack> TrackCls);
};