#pragma once

#include "CoreMinimal.h"

#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackNode.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackTimeline.h"

class SDialogueEditorShotSmoothActionNode : public SDialogueEditorActionTrackNode
{
public:
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	virtual void UpdateSizeAndPosition(const FGeometry& AllottedGeometry) override;
	
	virtual FMargin GetNotifyTrackPadding() override;

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	virtual FReply OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	// 鼠标移动回调
	virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	// 鼠标按键抬起回调
	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	virtual bool CanSelected() override {return false;}

	virtual FText GetNodeTooltip() const override;

	void OnDialogueCameraCutSwitchTypeChanged();

	UDialogueActionBase* GetPreCameraCutAction();

	TWeakObjectPtr<UDialogueActionBase> CachedPreAction;
};

class SDialogueEditorShotActionNode : public SDialogueEditorActionTrackKeyFrameNode
{
public:
	~SDialogueEditorShotActionNode();
	
	void Construct(const FArguments& InArgs, TSharedRef<SDialogueEditorActionTrackTimeline> InTimeline);

	void OnDialogueCameraCutSwitchTypeChanged();

	bool IsBreathNode() const;

	virtual FReply OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent) override;

	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	virtual void UpdateSizeAndPosition(const FGeometry& AllottedGeometry) override;

	virtual FReply OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	virtual ENotifyStateHandleHit::Type DurationHandleHitTest(const FVector2D& CursorScreenPosition) const override;
	
	virtual FCursorReply OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const override;

	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	
	TWeakPtr<SDialogueEditorActionTrackTimeline> CachedTimeline;

	static FString TargetCameraPropertyName;

	float BreathLocalSizeX = 0.f;
};