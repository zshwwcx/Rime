#pragma once

#include "Widgets/TimeLineBase/AnimTimelineTrack.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"

class KGSTORYLINEEDITOR_API FDialogueEditorTrackGroup : public FAnimTimelineTrack
{
	ANIMTIMELINE_DECLARE_TRACK(FDialogueEditorTrackGroup, FAnimTimelineTrack);

public:
	FDialogueEditorTrackGroup(const TSharedRef<class FDialogueEditorTimelineController>& InModel, FDialogueTrackGroup* InGroupData, const FText& InDisplayName, const FText& InToolTipText);


private:
	FDialogueTrackGroup* GroupData;
};