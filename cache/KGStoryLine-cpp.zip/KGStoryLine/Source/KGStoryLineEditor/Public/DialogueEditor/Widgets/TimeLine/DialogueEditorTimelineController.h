#pragma once

#include "Templates/SharedPointer.h"
#include "UObject/GCObject.h"
#include "Containers/ArrayView.h"
#include "DialogueEditor/DialogueEditor.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"
#include "Widgets/TimeLineBase/TimelineController.h"

enum class EItemDropZone;

class KGSTORYLINEEDITOR_API FDialogueEditorTimelineController : public FTimelineController
{

public:
	FDialogueEditorTimelineController();
	virtual ~FDialogueEditorTimelineController();

	DECLARE_EVENT(FDialogueEditorTimelineController, FOnTracksRefreshed)

	// 初始化
	void Initialize(const TSharedPtr<class FDialogueEditor>& InAssetEditorToolkit, TSharedPtr<class FDialogueEditorPreviewProxy> InPreviewProxy, int32 InEpisodeIndex, bool bAsCameraList = false);

	virtual float GetPlayLength() const override;

	virtual double GetFrameRate() const override;

	virtual FFrameNumber GetScrubPosition() const override;
	virtual void SetScrubPosition(FFrameTime NewScrubPostion) const override;

	//TimelineTrack辅助线列表
	virtual TArray<float> GetAssistLinePosX();
	//获取辅助线的颜色
	virtual FLinearColor GetAssistLineColor();

	int32 GetEpisodeID();

	void BuildTrackActionMenu(FMenuBuilder& InMenuBuilder, bool FromActorTrack);

	void FillNewTrackMenu(class FMenuBuilder& MenuBuilder, bool FromActorTrack);
	void FillSpecialTrackMenu(class FMenuBuilder& MenuBuilder, bool IsTemplateMode);
	void FillAllTracks(class FMenuBuilder& MenuBuilder);
	void FillActorOnlyTracks(class FMenuBuilder& MenuBuilder);

	UDialogueEntity* AddNewTrack(UClass* InTaskClass, FString DetermineTrackName="", const FVector& InSpawnLocation =
	 FVector::ZeroVector, const FRotator& InSpawnRotation = FRotator::ZeroRotator, const bool& UseParentTransform = true);

	void OnClassPicked(UClass* InTaskClass);

	void OnActorOnlyTrackClassPicked(UClass* InTrackClass);
	
	void RemoveAllSelectedTracks();

	void CopySelectedTrack();

	void PasteCopyTrack();

	void RemoveTrack(UDialogueTrackBase* Track);

	TSharedRef<class FDialogueEditorTrack> RoamTrack(UDialogueTrackBase* InTrack, bool bInCameraList = false);

	void GetAllTracks(const TSharedRef<class FAnimTimelineTrack>& Parent, TArray<TSharedRef<class FAnimTimelineTrack>>& Ret);
	TArray<TSharedRef<class FAnimTimelineTrack>> GetAllTracks();

	virtual void RefreshTracks() override;

	void RefreshTracksImplementation(bool NeedNotifyRefreshed=true);

	void OnTrackNameChanged();

	//DialogueEntityCamera:CameraActor对应的Entity
	void OnLockCameraClicked(class UDialogueCamera* DialogueEntityCamera, bool IsLockAutoCamera=false);
	
	//添加一个Track的时候，生成一个新的可用的TrackName
	//Prefix：类型前缀如Actor 或者Camera
	FString GenerateAvailableTrackName(class UDialogueBaseAsset* pAsset, const FString& Prefix);

	void OnInternalAddAutoCameraTrack();

	FOnTracksRefreshed TracksRefreshedEvent;

#pragma region TrackAddCheck

	// 总入口
	bool CanAddTrack(UClass* InTrackClass);

	// 通用检查
	bool MetCommonCondition(UClass* InTrackClass);

	// ActorOnly检查,要求必须选中了某个Actor轨道
	bool MetActorOnlyCondition(UClass* InTrackClass);

	// 该类型Track是否是ActorOnly的
	bool IsActorOnlyTrack(UClass* InTrackClass);

	// TODO:其他类型检查待扩展
	
#pragma endregion TrackAddCheck
	
public:
	virtual void BuildContextMenu(FMenuBuilder& InMenuBuilder);

	// 改变轨道位置
	void ChangeTrackPosition(class UDialogueTrackBase* SrcTrack, class UDialogueTrackBase* DestTrack, enum class EItemDropZone DropZone);

	void ChangeEpisodeTrackPosition(FDialogueEpisode* Episode, const FString& SrcTrackName, const FString& DestTrackName, enum class EItemDropZone DropZone);

	virtual void SetTrackSelected(const TSharedRef<class FAnimTimelineTrack>& InTrack, bool bIsSelected) override;

	virtual void DoubleClickTrack(const TSharedRef<class FAnimTimelineTrack>& InTrack) override;


	/** Clears the detail view of whatever we displayed last */
	virtual void ClearTrackSelection() override;

	void SetTrackSelected(UObject* InTrack, bool bSelectActor = true);
	void DoubleClickTrack(UObject* InTrack);

	class FDialogueEditor* GetCachedEditor();
	TWeakPtr<SWidget> TrackClassPickWidget;
private:
	TWeakPtr<class FDialogueEditor> CachedEditor = nullptr;

	TSharedPtr<class FDialogueEditorPreviewProxy> CachedPreviewProxy = nullptr;

	int32 EpisodeIndex = 0;

	//在Track上或者总体区域都可以召唤出菜单，如果是在Track上调出来，则打一个标识，用于后面将新的Track加到目标Track下面
	FString MenuFromTrack;

	//如果是从一个Track Duplicate复制出来的，则这个变量用于保存被复制的目标Track指针
	TWeakObjectPtr<class UDialogueSpawnableTrack> CopyTrackInfo = nullptr;

	// 是否开启了分离Camera模式
	bool bEnableCameraList = false;
	
	// 该Controller是否仅为摄像机使用
	bool bCameraList = false;
};
