#pragma once

#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueTrackEditor.h"
#include "Widgets/SWidget.h"
#include "Widgets/Input/SCheckBox.h"

class KGSTORYLINEEDITOR_API FDialogueRoutePointTrackEditor: public FDialogueTrackEditor
{
public:
	FDialogueRoutePointTrackEditor(const TWeakPtr<class FTimelineController> InModel, const TWeakPtr<class FDialogueEditor>& InAssetEditor, UDialogueTrackBase* InTrack) :FDialogueTrackEditor(InModel, InAssetEditor, InTrack) {}

	virtual void BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder) override;
	void AddSubTrack(TSubclassOf<class UDialogueActionTrack> TrackCls);
};