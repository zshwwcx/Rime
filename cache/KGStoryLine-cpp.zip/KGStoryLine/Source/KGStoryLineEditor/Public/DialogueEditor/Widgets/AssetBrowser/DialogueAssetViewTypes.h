#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/LuaAsset/LuaAssetHelper.h"
#include "Misc/TextFilter.h"
#include "Widgets/SNullWidget.h"
#include "Widgets/SWidget.h"
#include "Widgets/Views/STableRow.h"
#include "Styling/SlateBrush.h"


typedef TSharedPtr<class IDialogueAssetViewItem> FDialogueAssetTreeItemPtr;
typedef TSharedRef<IDialogueAssetViewItem> FDialogueAssetTreeItemRef;
typedef TTextFilter< const IDialogueAssetViewItem& > DialogueItemTextFilter;

enum class EDialogueAssetViewItemType : uint8
{
	Folder,
	File
};

class IDialogueAssetViewItem : public TSharedFromThis<IDialogueAssetViewItem>
{
public:
	IDialogueAssetViewItem() = default;

	virtual ~IDialogueAssetViewItem() {}

	virtual bool IsFolderItem() const = 0;

	virtual FString GetDisplayString() const = 0;

	virtual FString GetDialogueIDString() {return "";}
	
	virtual FString GetDialogueAuthorName() {return "";}

	virtual FString GetDescription() {return "";}

	virtual bool IsLabelReadOnly() const {return false;}

	virtual TSharedRef<SWidget> GenerateLabelWidget(class SDialogueAssetBrowser& Outliner, const STableRow<FDialogueAssetTreeItemPtr>& InRow) { return SNullWidget::NullWidget; }

	virtual TSharedPtr<SWidget> CreateContextMenu(TSharedPtr<class SDialogueAssetTreeView> DialogueAssetTreeView) { return SNullWidget::NullWidget; }
	
	/* Flags structure */
	struct FlagsType
	{
		/** Whether this item is expanded or not */
		bool bIsExpanded : 1;

		/* true if this item is filtered out */
		bool bIsFilteredOut : 1;

		/* true if this item can be interacted with as per the current outliner filters */
		bool bInteractive : 1;

		/** true if this item's children need to be sorted */
		bool bChildrenRequireSort : 1;

		/** Default constructor */		
		FlagsType() : bIsExpanded(0), bIsFilteredOut(0), bInteractive(1), bChildrenRequireSort(1) {}
	};

public:
		
	/** Flags for this item */
	FlagsType Flags;

	FString DialogueName;

	/** This item's parent, if any. */
	TWeakPtr<IDialogueAssetViewItem> Parent;

	/** Array of children contained underneath this item */
	mutable TSet<FDialogueAssetTreeItemPtr> Children;

	/** Get this item's parent. Can be nullptr. */
	FDialogueAssetTreeItemPtr GetParent() const
	{
		return Parent.Pin();
	}

	/** Add a child to this item */
	void AddChild(FDialogueAssetTreeItemRef Child)
	{
		check(!Children.Contains(Child));
		Child->Parent = AsShared();
		Children.Add(MoveTemp(Child));
	}

	/** Remove a child from this item */
	void RemoveChild(const FDialogueAssetTreeItemRef& Child)
	{
		if (Children.Remove(Child))
		{
			Child->Parent = nullptr;	
		}
	}

	/** Get this item's children, if any. */
	FORCEINLINE const TSet<FDialogueAssetTreeItemPtr>& GetChildren() const
	{
		return Children;
	}

	class FDialogueFolderViewItem* CastToFolderItem()
	{
		if (IsFolderItem())
		{
			return StaticCast<FDialogueFolderViewItem*>(this);
		}
		return nullptr;
	}

	class FDialogueLuaAssetViewItem* CastToLuaAssetViewItem()
	{
		if (!IsFolderItem())
		{
			return StaticCast<FDialogueLuaAssetViewItem*>(this);
		}
		return nullptr;
	}

	static bool Compare(const FDialogueAssetTreeItemPtr& A, const FDialogueAssetTreeItemPtr& B)
	{
		return A->GetDisplayString() < B->GetDisplayString();
	}

	static void CreateFolder(class FDialogueFolderViewItem* ParentItem, TSharedPtr<class SDialogueAssetTreeView> DialogueAssetTreeView);

	static void CreateDialogue(class FDialogueFolderViewItem* ParentItem, TSharedPtr<class SDialogueAssetTreeView> DialogueAssetTreeView);
};

class FDialogueFolderViewItem : public IDialogueAssetViewItem
{
public:
	virtual ~FDialogueFolderViewItem() override {}

	virtual bool IsFolderItem() const override { return true; } 
	
	virtual FString GetDisplayString() const override;

	FString GetLeafName() {return LeafName;}

	FString LeafName;

	FString Path;

	virtual TSharedRef<SWidget> GenerateLabelWidget(class SDialogueAssetBrowser& Outliner, const STableRow<FDialogueAssetTreeItemPtr>& InRow) override;

	virtual bool IsLabelReadOnly() const override;

	virtual TSharedPtr<SWidget> CreateContextMenu(TSharedPtr<class SDialogueAssetTreeView> DialogueAssetTreeView) override;

	void OnLabelCommitted(const FText& InLabel, ETextCommit::Type InCommitInfo);

	const FSlateBrush* GetIcon() const;
};

class FDialogueLuaAssetViewItem : public IDialogueAssetViewItem
{
public:

	FDialogueLuaAssetViewItem(const FDialogueAssetData& InDialogueAssetData) : DialogueAssetData(InDialogueAssetData) {}
	
	virtual ~FDialogueLuaAssetViewItem() override {}

	virtual bool IsFolderItem() const override { return false; } 
	
	virtual FString GetDisplayString() const override;

	virtual FString GetDialogueIDString() override {return DialogueAssetData.StoryLineID;}

	virtual FString GetDialogueAuthorName() override {return DialogueAssetData.AuthorName;}

	virtual FString GetDescription() {return DialogueAssetData.Description;}

	FDialogueAssetData DialogueAssetData;

	virtual TSharedRef<SWidget> GenerateLabelWidget(class SDialogueAssetBrowser& Outliner, const STableRow<FDialogueAssetTreeItemPtr>& InRow) override;

	virtual TSharedPtr<SWidget> CreateContextMenu(TSharedPtr<class SDialogueAssetTreeView> DialogueAssetTreeView) override;

	bool IsAssetValid() const;

	bool IsSimpleDialogue() const;

	FSlateColor GetColorAndOpacity() const;

	FString GetToolTipText() const;
	
	const FSlateBrush* GetDirtyImage() const;

	bool IsDirty() const {return false;}

	FString GetAssetPath() {return "";}
};
