#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Widgets/AssetBrowser/DialogueAssetViewTypes.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Views/STreeView.h"


namespace DialogueAssetBrowserColumnConstants
{
	const FName VersionState( TEXT("VersionState") );
	const FName DialogueID( TEXT("DialogueID") );
	const FName Description( TEXT("Description") );
	const FName AuthorName( TEXT("AuthorName") );
}

class SDialogueAssetTreeView : public STreeView< FDialogueAssetTreeItemPtr >
{
public:
		
	/** Construct this widget */
	void Construct(const FArguments& InArgs, TSharedRef<class SDialogueAssetBrowser> Owner);

	// void FlashHighlightOnItem( FDialogueAssetTreeItemPtr FlashHighlightOnItem );

	const TWeakPtr<SDialogueAssetBrowser>& GetBrowserPtr() { return DialogueAssetBrowserWeak; }
protected:

	/** Weak reference to the outliner widget that owns this list */
	TWeakPtr<SDialogueAssetBrowser> DialogueAssetBrowserWeak;
};

class SDialogueAssetTreeRow : public SMultiColumnTableRow<FDialogueAssetTreeItemPtr>
{
public:
	SLATE_BEGIN_ARGS(SDialogueAssetTreeRow)
		{
		}

		/** The list item for this row */
		SLATE_ARGUMENT(FDialogueAssetTreeItemPtr, Item)

	SLATE_END_ARGS()


	/** Construct function for this widget */
	void Construct(const FArguments& InArgs, const TSharedRef<SDialogueAssetTreeView>& DialogueAssetTreeView, TSharedRef<class SDialogueAssetBrowser> DialogueAssetBrowser);

	virtual TSharedRef<SWidget> GenerateWidgetForColumn( const FName& ColumnName ) override;

	TWeakPtr<IDialogueAssetViewItem> Item;
	
	TWeakPtr< SDialogueAssetBrowser > DialogueAssetBrowserWeak;
};
