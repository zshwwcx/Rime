#pragma once

#include "Containers/Array.h"
#include "Containers/BitArray.h"
#include "Containers/Set.h"
#include "Containers/SparseArray.h"
#include "Containers/UnrealString.h"
#include "DataTableEditorUtils.h"
#include "Delegates/Delegate.h"
#include "HAL/PlatformCrt.h"
#include "Input/Reply.h"
#include "Internationalization/Text.h"
#include "Kismet2/StructureEditorUtils.h"
#include "Layout/Visibility.h"
#include "Misc/NotifyHook.h"
#include "Misc/Optional.h"
#include "Serialization/Archive.h"
#include "Templates/SharedPointer.h"
#include "Templates/TypeHash.h"
#include "Templates/UnrealTemplate.h"
#include "Types/SlateEnums.h"
#include "UObject/NameTypes.h"
#include "UObject/SoftObjectPtr.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/Input/SComboBox.h"
#include "Widgets/SCompoundWidget.h"
#include "DialogueEditor/KGStoryLineEditorSubSystem.h"

class UDialogueAsset;
class FProperty;
class FStructOnScope;
class SWidget;
class UDialogueAsset;
class UScriptStruct;
struct FPropertyChangedEvent;

DECLARE_DELEGATE_OneParam(FOnKGSLScriptRowModified, FName /*Row name*/);
DECLARE_DELEGATE_OneParam(FOnKGSLScriptRowSelected, FName /*Row name*/);

class SKGStoryLineScriptLineEditor : public SCompoundWidget
	, public FNotifyHook
	, public INotifyOnKGSLDataChanged
{
public:
	SLATE_BEGIN_ARGS(SKGStoryLineScriptLineEditor) {}
	SLATE_END_ARGS()

	SKGStoryLineScriptLineEditor();
	virtual ~SKGStoryLineScriptLineEditor();

	// FNotifyHook
	virtual void NotifyPreChange( FProperty* PropertyAboutToChange ) override;
	virtual void NotifyPostChange( const FPropertyChangedEvent& PropertyChangedEvent, FProperty* PropertyThatChanged ) override;

	// INotifyOnDataTableChanged
	virtual void PreChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo Info) override;
	virtual void PostChange(const UDialogueAsset* Changed, EKGSLDataChangeInfo Info) override;

	FOnKGSLScriptRowSelected RowSelectedCallback;

protected:
	TArray<TSharedPtr<FName>> CachedRowNames;
	TSoftObjectPtr<UDialogueAsset> Asset; // weak obj ptr couldn't handle reimporting
	TSharedPtr<IDetailsView> PropertyView;
	TSharedPtr<FName> SelectedName;
	TSharedPtr<SComboBox<TSharedPtr<FName>>> RowComboBox;
	int32 EpisodeID;

	void RefreshNameList();
	void CleanBeforeChange();
	void Restore();

	/** Functions for enabling, disabling, and hiding portions of the row editor */
	virtual bool IsMoveRowUpEnabled() const;
	virtual bool IsMoveRowDownEnabled() const;
	virtual bool IsAddRowEnabled() const;
	virtual bool IsRemoveRowEnabled() const;
	virtual EVisibility GetRenameVisibility() const;

	FName GetCurrentName() const;
	FText GetCurrentNameAsText() const;
	TSharedRef<SWidget> OnGenerateWidget(TSharedPtr<FName> InItem);
	virtual void OnSelectionChanged(TSharedPtr<FName> InItem, ESelectInfo::Type InSeletionInfo);

	virtual FReply OnAddClicked();
	virtual FReply OnRemoveClicked();
	virtual FReply OnMoveRowClicked(FDataTableEditorUtils::ERowMoveDirection MoveDirection);
	FReply OnMoveToExtentClicked(FDataTableEditorUtils::ERowMoveDirection MoveDirection);
	void OnRowRenamed(const FText& Text, ETextCommit::Type CommitType);
	FReply OnResetToDefaultClicked();
	EVisibility GetResetToDefaultVisibility() const ;
	void ConstructInternal(UDialogueAsset* Changed, int32 InEpisodeID);

public:
	void Construct(const FArguments& InArgs, UDialogueAsset* Changed, int32 InEpisodeID);
	void SelectRow(FName Name);
	void HandleUndoRedo();

};
