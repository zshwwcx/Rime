#pragma once

#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueTrackEditor.h"
#include "Widgets/SWidget.h"
#include "Widgets/Input/SCheckBox.h"

class KGSTORYLINEEDITOR_API FDialogueCameraTrackEditor: public FDialogueTrackEditor
{
public:
	FDialogueCameraTrackEditor(const TWeakPtr<class FTimelineController> InModel, const TWeakPtr<class FDialogueEditor>& InAssetEditor, UDialogueTrackBase* InTrack) :FDialogueTrackEditor(InModel, InAssetEditor, InTrack) {}

	virtual TSharedPtr<SWidget> BuildOutlinerEditWidget() override;

	virtual void BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder) override;

	const FSlateBrush* GetIconBrush() const override;

	void OnLockCameraClicked(ECheckBoxState CheckBoxState);
	void OnFocusCameraClicked(ECheckBoxState CheckBoxState);

	ECheckBoxState IsCameraLocked() const;
	ECheckBoxState IsCameraFocus() const;

	FText GetLockCameraToolTip() const;
	FText GetFocusCameraToolTip() const;

	EVisibility GetCameraCurveVisible() const;

	void LockCameraBinding(bool bLock);

	void ClearLockedCameras(AActor* LockedActor);

	void AddTransformTrack();
	void AddCameraSubTrack(TSubclassOf<class UDialogueActionTrack> TrackCls);
};