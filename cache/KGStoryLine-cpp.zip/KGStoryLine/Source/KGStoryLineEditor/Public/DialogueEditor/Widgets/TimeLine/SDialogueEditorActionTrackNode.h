#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Dialogue/Actions/DialogueDialogue.h"
#include "Input/Reply.h"
#include "Misc/Attribute.h"

#include "SNodePanel.h"
#include "SCurveEditor.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"

#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineEvent.h"


namespace ENotifyStateHandleHit
{
	enum Type
	{
		Start,
		End,
		None
	};
}

class SOverlay;
class SBorder;
class SScrollBar;

struct FDialogueEditorActionNodeData
{
	FDialogueEditorActionNodeData();

	// 设置Node对应的Task对象
	void SetActionNodeData(class UDialogueActionBase* InSection);

	// 获取Task对象
	class UDialogueActionBase* GetAction() const;

	// 获取Task名称
	FName GetActionName() const;

	// 获取颜色
	TOptional<FLinearColor> GetColor() const;

	// 获取Tip
	FText GetNodeTooltip() const;

	// 获取开始时间
	float GetStartTime() const;
	float GetEditorStartTime();

	// 设置开始时间
	void SetStartTime(float Time);
	void SetEditorStartTime(float Time);

	// 获取持续时间
	float GetDuration() const;
	float GetEditorDuration() const;

	// 设置持续时间
	void SetDuration(float InDuration);
	void SetEditorDuration(float InDuration);

	TWeakPtr<class FDialogueEditor> CachedEditor = nullptr;
	// 缓存的Task对象
	TWeakObjectPtr<class UDialogueActionTrack> CachedTrack = nullptr;

	TWeakObjectPtr<class UDialogueActionBase> CachedSection = nullptr;

	TWeakObjectPtr<UClass> CameraCutBlueprintClass;

	bool bLinkTarget = false;
};


class KGSTORYLINEEDITOR_API SDialogueEditorActionTrackNode : public SLeafWidget
{
#pragma region Important

public:
	friend class SDialogueEditorActionTrackTimeline;

	SLATE_BEGIN_ARGS(SDialogueEditorActionTrackNode)
			: _ViewInputMin()
			, _ViewInputMax()
			,
			//_OnRefreshPanel(),
			_OnStartDragNode()
			, _NodeLeftMouseButtonUp()
		{
		}

		SLATE_ARGUMENT(TSharedPtr<class FDialogueEditor>, CachedEditor)
		SLATE_ARGUMENT(class UDialogueActionTrack*, Track)
		SLATE_ARGUMENT(class UDialogueActionBase*, Section)
		SLATE_ATTRIBUTE(float, ViewInputMin)
		SLATE_ATTRIBUTE(float, ViewInputMax)
		SLATE_ATTRIBUTE(float, TimelinePlayLength)
		//SLATE_EVENT(FRefreshPanel, OnRefreshPanel)
		SLATE_EVENT(FStartDragNode, OnStartDragNode)
		SLATE_EVENT(FDeleteSelectedSection, OnDeleteSelectedSection)
		SLATE_EVENT(FNodeLeftMouseButtonUp, NodeLeftMouseButtonUp)
		SLATE_EVENT(FNodeMouseButtonDoubleClick, NodeMouseButtonDoubleClickEvent)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	virtual ~SDialogueEditorActionTrackNode() override;

	FDialogueEditorActionNodeData* GetActionNodeDataPtr();
	TSharedPtr<class FDialogueEditor> GetDialogueEditor();

	const FDialogueEditorActionNodeData& GetActionNodeData() const;

protected:
	FDialogueEditorActionNodeData ActionNodeData;

#pragma endregion Important


#pragma region Render

public:
	// 绘制该控件
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	// 绘制移动时的偏移虚影
	void DrawHandleOffset(const float& Offset, const float& HandleCentre, FSlateWindowElementList& OutDrawElements, int32 MarkerLayer, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FLinearColor NodeColour) const;

	virtual FNavigationReply OnNavigation(const FGeometry& MyGeometry, const FNavigationEvent& InNavigationEvent) override;
#pragma endregion Render


#pragma region Parameter

public:
	bool IsSelected() const;

	FText GetNotifyText() const;

	virtual FText GetNodeTooltip() const;

	FVector2D GetSize() const;

	const FVector2D& GetScreenPosition() const;

	float GetDurationSize() const;

	FVector2D GetWidgetPosition() const;

	FVector2D GetNotifyPosition() const;

	FVector2D GetNotifyPositionOffset() const;

	virtual FVector2D GetWidgetAndStartTimeOffset() const;

	virtual FVector2D ComputeDesiredSize(float) const override;

	virtual void UpdateSizeAndPosition(const FGeometry& AllottedGeometry);

protected:
	bool bSelected;

	FSlateFontInfo Font;

	float NotifyTimePositionX;

	float NotifyDurationSizeX;

	float NotifyScrubHandleCentre;

	FVector2D ScreenPosition;

	bool bDrawTooltipToRight;

	FVector2D TextSize;

	float LabelWidth;

	FSlateBrush UnpinBrush;
#pragma endregion Parameter


#pragma region Widget

public:
	// 接收聚焦
	virtual FReply OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent) override;

	// 丢失聚焦
	virtual void OnFocusLost(const FFocusEvent& InFocusEvent) override;

	// 是否支持键盘聚焦
	virtual bool SupportsKeyboardFocus() const override;

	// 分析鼠标拖拽ActionNode的类型
	virtual ENotifyStateHandleHit::Type DurationHandleHitTest(const FVector2D& CursorScreenPosition) const;

	// 是否正在被拖动
	bool BeingDragged() const;

	void OnCurrentLinkSectionChanged(UDialogueDialogue* Last, UDialogueDialogue* Current);
	// mouse button bouble click
	virtual FReply OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent) override;
	// 鼠标按键按下回调
	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	// 拖动回调
	virtual FReply OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	// 拖动被取消
	void DragCancelled();

	// 设置鼠标按下时的位置
	void SetLastMouseDownPosition(const FVector2D& CursorPosition);

	// 鼠标移动回调
	virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	// 鼠标按键抬起回调
	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	// 鼠标悬停查询
	virtual FCursorReply OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const override;

	TSharedPtr<SWidget> SummonContextMenu(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

	void DeleteSelectedSection();
	void SetSelectedSectionEnable();
	void CopySectionLinkGUID();
	void PasteSectionLinkGUID();
	void ClearSectionLinkGUID();
	void QuickFocusSection();

	// 获取timeline需要的宽高
	virtual FMargin GetNotifyTrackPadding();

	void AddSlotToTimeline(TSharedPtr<SOverlay> NodeSlots);

	virtual bool CanSelected() {return true;}

protected:
	bool bBeingDragged;

	// Index for undo transactions for dragging, as a check to make sure it's active
	int32 DragMarkerTransactionIdx;

	/** The scrub handle currently being dragged, if any */
	ENotifyStateHandleHit::Type CurrentDragHandle;

	float WidgetX;

	FVector2D WidgetSize;

	TAttribute<float> ViewInputMin;

	TAttribute<float> ViewInputMax;

	float TimelinePlayLength;

	/** Last position the user clicked in the widget */
	FVector2D LastMouseDownPosition;

	/** Cached owning track geometry */
	FGeometry CachedTrackGeometry;

	FVector2D CachedAllotedGeometrySize;

#pragma endregion Widget


#pragma region Event

public:
	/** Delegate to redraw the notify panel */
	//FRefreshPanel RefreshPanelEvent;

	/** Delegate that is called when the user initiates dragging */
	FStartDragNode StartDragNodeEvent;

	FDeleteSelectedSection DeleteSelectedSectionEvent;

	FNodeLeftMouseButtonUp NodeLeftMouseButtonUpEvent;
	FNodeMouseButtonDoubleClick NodeMouseButtonDoubleClickEvent;

#pragma endregion Event
};

class KGSTORYLINEEDITOR_API SDialogueEditorActionTrackSectionNode : public SDialogueEditorActionTrackNode
{
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
};

class KGSTORYLINEEDITOR_API SDialogueEditorActionTrackKeyFrameNode : public SDialogueEditorActionTrackNode
{
public:
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	virtual void UpdateSizeAndPosition(const FGeometry& AllottedGeometry) override;
	
	virtual FMargin GetNotifyTrackPadding() override;

	virtual FVector2D GetWidgetAndStartTimeOffset() const override;

	virtual FReply OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	virtual FCursorReply OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const override;

	static const FVector2d KeySizePx;
	static const float HalfKeySize;
	static const float KeyBrushBorderWidth;
	static const float KeyPositionOffsetY;
};