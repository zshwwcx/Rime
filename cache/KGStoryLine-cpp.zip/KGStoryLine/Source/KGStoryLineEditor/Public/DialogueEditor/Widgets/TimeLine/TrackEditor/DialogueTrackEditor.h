#pragma once

#include "CoreMinimal.h"
#include "Widgets/SWidget.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueTrackEditor.h"
#include "DialogueEditor/Dialogue/DialogueTrackBase.h"
#include "Widgets/SNullWidget.h"


class FMenuBuilder;
class KGSTORYLINEEDITOR_API FDialogueTrackEditor : public TSharedFromThis<FDialogueTrackEditor>
{
public:
	FDialogueTrackEditor(const TWeakPtr<class FTimelineController> InModel, const TWeakPtr<class FDialogueEditor>& InAssetEditor, UDialogueTrackBase* InTrack);

	virtual ~FDialogueTrackEditor() {}

public:
	virtual TSharedPtr<SWidget> BuildOutlinerEditWidget() { return SNullWidget::NullWidget; }

	virtual void BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder) {}

	virtual TSharedRef<SWidget> GenerateContainerWidgetForTimeline() { return SNullWidget::NullWidget; }

	virtual bool IsTrackReadOnly() const { return false; }

	virtual const FSlateBrush* GetIconBrush() const {return nullptr;}

	TWeakObjectPtr<UDialogueTrackBase> GetCacheTrack();
protected:
	TWeakPtr<class FTimelineController> TimelineController;

	TWeakPtr<class FDialogueEditor> CachedEditor = nullptr;

	TWeakObjectPtr<UDialogueTrackBase> CachedTrack;

};
