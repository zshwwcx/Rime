// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DataTableEditorUtils.h"
#include "DragAndDrop/DecoratedDragDropOp.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Views/STableRow.h"

class SKGSLScriptEdListViewSettings;

struct FKGSLScriptEdListViewSettingsRowData
{
	FString DisplayName;
	FString ColumnName;
	FName RowId;
	uint32 RowNum;
};

using FKGSLScriptEdListViewSettingsRowDataPtr = TSharedPtr<FKGSLScriptEdListViewSettingsRowData>;

class SKGSLScriptEdListViewSettingsRow : public SMultiColumnTableRow<FKGSLScriptEdListViewSettingsRowDataPtr>
{
public:
	static const FName RowDragDropColumnId;
	static const FName RowNumberColumnId;
	static const FName NameColumnId;
	
	SLATE_BEGIN_ARGS(SKGSLScriptEdListViewSettingsRow)
		: _Order(0)
		{}
		SLATE_ARGUMENT(TSharedPtr<SKGSLScriptEdListViewSettings>, ViewSettings)
		SLATE_ARGUMENT(FString, ColumnName)
		SLATE_ARGUMENT(FKGSLScriptEdListViewSettingsRowDataPtr, RowDataPtr)
		SLATE_ARGUMENT(uint32, Order)
	SLATE_END_ARGS()

	FReply OnRowDrop(const FDragDropEvent& DragDropEvent);
	void OnRowDragEnter(const FDragDropEvent& DragDropEvent);
	void OnRowDragLeave(const FDragDropEvent& DragDropEvent);
	void Construct(const FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTable);
	const FSlateBrush* GetBorder() const;
	FSlateColor GetRowTextColor() const;
	FText GetColumnNameText() const;
	FReply OnMoveUpClicked();
	FReply OnMoveDownClicked();
	FText GetOrderText() const;
	virtual TSharedRef<SWidget> GenerateWidgetForColumn(const FName& InColumnName) override;

	void SetIsDragDrop(bool bInIsDragDrop);
	uint32 GetCurrentIndex() const;

private:
	FKGSLScriptEdListViewSettingsRowDataPtr RowData;
	TWeakPtr<SKGSLScriptEdListViewSettings> ViewSettings;
	FString ColumnName;
	uint32 Order = 0;
	bool bIsDragDropObject: 1 =  false;
	bool bSelected : 1 = false;
	bool bIsHoveredDragTarget : 1 = false;


};


class SKGSLScriptEdListViewSettingsRowDragDropOp : public FDecoratedDragDropOp
{
public:
	DRAG_DROP_OPERATOR_TYPE(FDataTableRowDragDropOp, FDecoratedDragDropOp)

	SKGSLScriptEdListViewSettingsRowDragDropOp(TSharedPtr<SKGSLScriptEdListViewSettingsRow> InRow);

	void OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent);

	virtual TSharedPtr<SWidget> GetDefaultDecorator() const override
	{
		return DecoratorWidget;
	}

	TSharedPtr<SWidget> DecoratorWidget;
	TWeakPtr<SKGSLScriptEdListViewSettingsRow> Row;

};


class SKGSLScriptEdListViewSettingsRowHandle: public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SKGSLScriptEdListViewSettingsRowHandle)
	{
	}

	SLATE_DEFAULT_SLOT(FArguments, Content)
	SLATE_ARGUMENT(TSharedPtr<SKGSLScriptEdListViewSettingsRow>, ParentRow)
SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override
	{
		return FReply::Handled().DetectDrag(SharedThis(this), EKeys::LeftMouseButton);
	};


	FReply OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	TSharedPtr<SKGSLScriptEdListViewSettingsRowDragDropOp> CreateDragDropOperation(TSharedPtr<SKGSLScriptEdListViewSettingsRow> InRow);

private:
	TWeakPtr<SKGSLScriptEdListViewSettingsRow> ParentRow;
};


/**
 * SKGSLScriptEdListViewSettings
 */
class SKGSLScriptEdListViewSettings : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SKGSLScriptEdListViewSettings)
		{}
		SLATE_ARGUMENT(TArray<FString>, ColumnNames)
		SLATE_ARGUMENT(TArray<FString>, DisplayNames)
	SLATE_END_ARGS()

	TSharedRef<ITableRow> MakeRowWidget(FKGSLScriptEdListViewSettingsRowDataPtr InRowDataPtr, const TSharedRef<STableViewBase>& OwnerTable);
	void OnColumnOrderSortModeChanged(EColumnSortPriority::Type InArg, const FName& Name, EColumnSortMode::Type InSortMode);
	EColumnSortMode::Type GetSortMode(FName Name) const;
	virtual void Construct(const FArguments& args);
	void SelectRow(int32 ColumnIndex);
	void MoveRow(int32 ColumnIndex, FDataTableEditorUtils::ERowMoveDirection InDirection, int32 InMoveCount = 1);
	void SetColumnDatas(const TArray<FString>& InColumnNames, const TArray<FString>& InDisplayNames);
	bool GetColumnDatas(TArray<FString>& OutColumnNames) const;
private:
	TArray<FKGSLScriptEdListViewSettingsRowDataPtr> ColumnNames;
	TMap<FString, TSharedPtr<SKGSLScriptEdListViewSettingsRow>> Rows;

	TSharedPtr<SHeaderRow> ColumnNamesHeaderRow;
	TSharedPtr<SListView<FKGSLScriptEdListViewSettingsRowDataPtr>> CellsListView;
	EColumnSortMode::Type SortMode = EColumnSortMode::None;
	FName SortByColumn;
};
