#pragma once

#include "CoreMinimal.h"
#include "Input/Reply.h"
#include "Misc/Attribute.h"

#include "SNodePanel.h"
#include "SCurveEditor.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"

#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineEvent.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackNode.h"


class KGSTORYLINEEDITOR_API SDialogueEditorActionTrackTimeline : public SCompoundWidget
{
#pragma region Important
public:
	SLATE_BEGIN_ARGS(SDialogueEditorActionTrackTimeline)
		: _ViewInputMin()
		, _ViewInputMax()
		, _TimelinePlayLength()
		, _TrackIndex()
		, _OnSetInputViewRange()
		, _OnAddNewSection()
		//, _OnRefreshPanel()
		/*, _OnDeselectAllNodes()
		, _OnDeleteTask()
		, _OnCopyTasks()*/
	{}
	SLATE_ARGUMENT(TSharedPtr<class FDialogueEditor>, CachedEditor)
		SLATE_ARGUMENT(class UDialogueActionTrack*, Task)
		SLATE_ATTRIBUTE(float, ViewInputMin)
		SLATE_ATTRIBUTE(float, ViewInputMax)
		SLATE_ATTRIBUTE(float, InputMin)
		SLATE_ATTRIBUTE(float, InputMax)
		SLATE_ATTRIBUTE(float, TimelinePlayLength)
		SLATE_ATTRIBUTE(double, FrameRate)
		SLATE_ARGUMENT(int32, TrackIndex)

		SLATE_EVENT(FOnSetInputViewRange, OnSetInputViewRange)

		SLATE_EVENT(FSelectActionSection, OnSelectActionSection)
		SLATE_EVENT(FDeleteSelectedSection, OnDeleteSection)
		SLATE_EVENT(FAddNewSection, OnAddNewSection)
		SLATE_EVENT(FAddNewSection, OnAddNewSecondTypeSection)
		SLATE_EVENT(FAddCameraSectionAtViewPosition, OnAddCameraSectionAtViewPosition)

		SLATE_END_ARGS()

		void Construct(const FArguments& InArgs);

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	int32 GetTrackIndex() const;
	
	TArray<TSharedPtr<SDialogueEditorActionTrackNode>> GetActionNodes() const;
private:
	float TimelinePlayLength=0.f;

	int32 TrackIndex=0;

	TWeakObjectPtr<class UDialogueActionTrack> CachedTrack = nullptr;

	TSharedPtr<SDialogueEditorActionTrackNode> TaskNode = nullptr;

	TArray<TSharedPtr<SDialogueEditorActionTrackNode>> ActionNodes;

#pragma endregion Important



#pragma region Render
public:
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;
	
	void UpdateLayout();

private:
	TAttribute<FLinearColor> TrackColor;

#pragma endregion Render


#pragma region Menu
private:
	TSharedPtr<SWidget> SummonContextMenu(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

	void AddNewSection();
	void AddAutoCameraSection();
	void AddCameraSectionAtViewPosition();
	void AddAllSectionsForLine();

public:
	bool bIsCtrlDown = false;
#pragma endregion Menu



#pragma region Widget
public:
	const FGeometry& GetCachedGeometry() const;

	void UpdateCachedGeometry(const FGeometry& InGeometry);

	FTrackScaleInfo GetCachedScaleInfo() const;

	virtual FVector2D ComputeDesiredSize(float) const override;

	virtual bool SupportsKeyboardFocus() const override;

	virtual FReply OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	virtual FCursorReply OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const override;

	void HandleNodeDrop(TSharedPtr<SDialogueEditorActionTrackNode> Node, float Offset = 0.0f);

private:
	void SelectActionNode(TSharedRef<SDialogueEditorActionTrackNode> NotifyNode);

	void DeleteSelectedSection();

	void OnDeleteKeyPressed();

	float CalculateTime(const FGeometry& MyGeometry, FVector2D NodePos, bool bInputIsAbsolute = true);

	FMargin GetNotifyTrackPadding(SDialogueEditorActionTrackNode* ActionNode) const;

	FReply OnNotifyNodeDragStarted(TSharedRef<SDialogueEditorActionTrackNode> NotifyNode, const FPointerEvent& MouseEvent, const FVector2D& ScreenNodePosition, const bool bDragOnMarker, const float TrackMinOffset);
	
	void OnNotifyDeleteSelectedNode(TSharedRef<SDialogueEditorActionTrackNode> NotifyNode, bool NeedRefresh = true);

	FReply OnNodeLeftMouseButtonUp(TSharedRef<SDialogueEditorActionTrackNode> NotifyNode);

	float CalculateDraggedNodePos() const { return CurrentDragXPosition; }

private:
	TAttribute<float> ViewInputMin;

	TAttribute<float> ViewInputMax;

	TAttribute<float> InputMin;

	TAttribute<float> InputMax;

	float LastClickedTime=0.f;

	float CurrentDragXPosition=0.f;

	FGeometry CachedGeometry;

	TSharedPtr<SBorder> TrackArea;

	TSharedPtr<SOverlay> NodeSlots;

	TSharedPtr<SScrollBar> NotifyTrackScrollBar;

	TSharedPtr<class FDialogueEditor> CachedEditor;
#pragma endregion Widget



#pragma region Event
private:
	FOnSetInputViewRange SetInputViewRangeEvent;

	FSelectNode SelectNodeEvent;

	FSelectActionSection SelectActionSectionEvent;

	FDeleteSelectedSection DeleteSectionEvent;

	FAddNewSection AddNewSectionEvent;

	FAddNewSection AddNewSecondTypeSectionEvent;
	
	FAddCameraSectionAtViewPosition AddCameraSectionAtViewPositionEvent;

#pragma endregion Event

};