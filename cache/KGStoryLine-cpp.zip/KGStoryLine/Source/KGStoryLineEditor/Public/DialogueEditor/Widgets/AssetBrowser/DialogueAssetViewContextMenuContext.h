#pragma once

#include "CoreMinimal.h"
#include "DialogueAssetViewContextMenuContext.generated.h"

UCLASS()
class UDialogueAssetViewContextMenuContext : public UObject
{
	GENERATED_BODY()

public:
	// TWeakPtr<class SContentBrowser> OwningContentBrowser;
	TWeakPtr<class SDialogueAssetBrowser> AssetView;
};