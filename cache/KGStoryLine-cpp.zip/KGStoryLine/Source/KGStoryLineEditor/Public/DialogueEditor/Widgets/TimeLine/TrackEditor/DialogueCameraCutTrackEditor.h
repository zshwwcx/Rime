#pragma once

#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueActionTrackEditor.h"
#include "Widgets/SWidget.h"
#include "Widgets/Input/SCheckBox.h"

class KGSTORYLINEEDITOR_API FDialogueCameraCutTrackEditor: public FDialogueActionTrackEditor
{
public:
	FDialogueCameraCutTrackEditor(const TWeakPtr<class FTimelineController> InModel, const TWeakPtr<class FDialogueEditor>& InAssetEditor, UDialogueTrackBase* InTrack) :FDialogueActionTrackEditor(InModel, InAssetEditor, InTrack) {}

	virtual void BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder) override;

	void OnAddCameraCutSection(UDialogueTrackBase* Track);

	virtual TSharedPtr<SWidget> BuildOutlinerEditWidget() override;

	virtual const FSlateBrush* GetIconBrush() const override;

	void OnLockCameraClicked(ECheckBoxState CheckBoxState);

	ECheckBoxState IsCameraLocked() const;

	FText GetLockCameraToolTip() const;
};