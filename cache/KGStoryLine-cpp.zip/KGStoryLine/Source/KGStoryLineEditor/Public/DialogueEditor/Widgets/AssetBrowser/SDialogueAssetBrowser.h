#pragma once

#include "CoreMinimal.h"
#include "DialogueEditor/Widgets/AssetBrowser/SDialogueAssetTreeView.h"
#include "ToolMenu.h"
#include "DialogueEditor/LuaAsset/LuaAssetHelper.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Views/SListView.h"
#include "SDialogueAssetBrowser.generated.h"


UENUM()
enum class EDialogueAssetViewType : uint8
{
	Folder,
	Asset,
	Favorite,
	History,
	Max
};

class SDialogueAssetBrowser : public SCompoundWidget
{
public:
	DECLARE_DELEGATE(FOnOpenDialogueByDoubleClick)
	DECLARE_DELEGATE(FOnCreateDialogueByDoubleClick)

	SLATE_BEGIN_ARGS(SDialogueAssetBrowser)
		{
		}

		SLATE_EVENT(FOnOpenDialogueByDoubleClick, OnOpenDialogueByDoubleClick)
		SLATE_EVENT(FOnCreateDialogueByDoubleClick, OnCreateDialogueByDoubleClick)

	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	void OnListMouseButtonDoubleClick(FDialogueAssetTreeItemPtr ViewItem);

	void OnGetChildrenForTree(FDialogueAssetTreeItemPtr InParent, TArray<FDialogueAssetTreeItemPtr>& OutChildren);

	void OnItemExpansionChanged(FDialogueAssetTreeItemPtr TreeItem, bool bIsExpanded) const;

	TSharedPtr<DialogueItemTextFilter> CreateTextFilter() const;

	void PopulateSearchStrings(const IDialogueAssetViewItem& Item, TArray< FString >& OutSearchStrings) const;

	void ExpandAllItems();

	void OnFilterTextChanged(const FText& InFilterText);

	void OnFilterTextCommitted(const FText& InFilterText, ETextCommit::Type CommitInfo);

	FText GetFilterText() const;

	void GetDialogueAssetData();

	void RefreshItemsByDialogueAssetData(TFunctionRef<bool(const FDialogueAssetData& DialogueAssetData)> FilterFunc);

	void RefreshTreeView();

	TSharedPtr<SWidget> OnOpenContextMenu();

	void SetCurrentViewTypeFromMenu(EDialogueAssetViewType NewType);

	bool IsCurrentViewType(EDialogueAssetViewType ViewType) const;

	EDialogueAssetViewType GetCurrentViewType() const;

	void SetCurrentViewType(EDialogueAssetViewType NewType);

	TSharedRef<ITableRow> OnGenerateRowForTree(FDialogueAssetTreeItemPtr InItem, const TSharedRef<STableViewBase>& OwnerTable);

	TMap<FString, FDialogueAssetData> CachedDialogueAssetData;

	TArray<FDialogueAssetTreeItemPtr> DialogueAssetItems;

	TSharedPtr<SDialogueAssetTreeView> TreeView;

	TSharedPtr<SHeaderRow> HeaderRowWidget;

	TSharedPtr<class SFilterSearchBox> FilterTextBoxWidget;

	FOnOpenDialogueByDoubleClick OnOpenDialogueByDoubleClick;
	
	FOnCreateDialogueByDoubleClick OnCreateDialogueByDoubleClick;

	TSharedPtr<DialogueItemTextFilter> SearchBoxFilter;

	EDialogueAssetViewType CurrentViewType = EDialogueAssetViewType::Folder;

private:
	// 搜索框使用到的搜索过滤函数
	static bool FilterCommon(const FString& FilterStr, const FDialogueAssetData& DialogueAssetData);

	static bool FilterByContent(const FDialogueAssetData& DialogueAssetData, const FString& Content);

public:
	static bool OpenDialogueIsGamePreview();
};
