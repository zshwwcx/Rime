#pragma once
#include "CoreMinimal.h"
#include "Widgets/SWindow.h"
#include "DetailColumnSizeData.h"
#include "DialogueEditor/Graph/SOptionGraph.h"

/**
 *
 */
class KGSTORYLINEEDITOR_API KGSLSOptionConditionWindow : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(KGSLSOptionConditionWindow){}
		SLATE_ARGUMENT(TWeakObjectPtr<class UDialogueAsset>, DialogueAssetEditing)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	void OnCurrentEditEpisodeChanged();
	
private:
	void GenerateComboOptionsOnCurrentEpisode();
	void OnSelectionChanged(TSharedPtr<FString> NewSelect, ESelectInfo::Type SelectInfo);

private:
	TWeakObjectPtr<class UDialogueAsset> DialogueAsset;
	int32 CurrentEditEpisodeID = 0;
	FString Condition;
	int32 DialogueLineIndex = 0;
	int32 OptionJumpEpisodeID = 0;
	TArray<FString> ExtraAction;

	TArray<TSharedPtr<FString>> ComboOptions;
	TMap<FString, TWeakObjectPtr<class UKGSLDialogueOption>> ComboOptions2Option;
	TSharedPtr<SVerticalBox> ContentBox;
	TSharedPtr<SOptionGraph> OptionGraph;
	TSharedPtr<SVerticalBox> GraphContainer;
	TSharedPtr<STextComboBox> ConditionComboBox;
};
