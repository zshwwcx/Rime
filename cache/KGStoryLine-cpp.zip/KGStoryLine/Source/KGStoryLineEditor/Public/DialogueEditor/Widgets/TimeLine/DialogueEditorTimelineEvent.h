#pragma once

#include "Delegates/DelegateCombinations.h"



DECLARE_DELEGATE(FRefreshPanel);
DECLARE_DELEGATE(FSelectNode);
DECLARE_DELEGATE(FDeselectAllNodes);
DECLARE_DELEGATE(FDeleteTask);
DECLARE_DELEGATE(FCopyTask);
DECLARE_DELEGATE(FPasteTask);
DECLARE_DELEGATE(FExportTask);
DECLARE_DELEGATE(FTaskTemplate);

DECLARE_DELEGATE_OneParam(FSelectActionSection, class UDialogueActionBase*);

DECLARE_DELEGATE_TwoParams(FDeleteSelectedSection, TSharedRef<class SDialogueEditorActionTrackNode>, bool);

DECLARE_DELEGATE_OneParam(FAddNewSection, float);
DECLARE_DELEGATE_OneParam(FAddCameraSectionAtViewPosition, float);

DECLARE_DELEGATE_RetVal_OneParam(FReply, FNodeLeftMouseButtonUp, TSharedRef<class SDialogueEditorActionTrackNode>)

DECLARE_DELEGATE_RetVal_TwoParams(FReply, FNodeMouseButtonDoubleClick, TSharedRef<class SDialogueEditorActionTrackNode>, const FPointerEvent&);

DECLARE_DELEGATE_RetVal_FiveParams(FReply, FStartDragNode, TSharedRef<class SDialogueEditorActionTrackNode>, const FPointerEvent&, const FVector2D&, const bool, const float)

DECLARE_DELEGATE_RetVal_FourParams(FReply, FStartExtraDragNode, TSharedRef<class SDialogueEditorActionTrackNode>, const FPointerEvent&, const FVector2D&, const bool)
