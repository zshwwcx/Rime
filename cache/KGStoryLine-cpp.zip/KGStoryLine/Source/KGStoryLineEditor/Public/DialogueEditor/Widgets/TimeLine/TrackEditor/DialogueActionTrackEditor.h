#pragma once

#include "DialogueEditor/DialogueEditorDelegates.h"
#include "DialogueEditor/Widgets/TimeLine/TrackEditor/DialogueTrackEditor.h"
#include "Widgets/SWidget.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackNode.h"
#include "Widgets/Input/SCheckBox.h"

class KGSTORYLINEEDITOR_API FDialogueActionTrackEditor: public FDialogueTrackEditor
{
public:
	FDialogueActionTrackEditor(const TWeakPtr<class FTimelineController> InModel, const TWeakPtr<class FDialogueEditor>& InAssetEditor, UDialogueTrackBase* InTrack) :FDialogueTrackEditor(InModel, InAssetEditor, InTrack)
	{
		FDialogueEditorDelegates::OnSectionSelect.AddRaw(this, &FDialogueActionTrackEditor::OnSelectSectionChange);
	}
	~FDialogueActionTrackEditor()
	{
		FDialogueEditorDelegates::OnSectionSelect.RemoveAll(this);
	}
	virtual void BuildOutlinerTrackActions(FMenuBuilder& InMenuBuilder) override;

	virtual TSharedRef<SWidget> GenerateContainerWidgetForTimeline() override;

	void AddSection(float StartTime);
	
	void AddNewSecondTypeSection(float StartTime);
	
	void AddCameraSectionAtViewPosition(float StartTime);

	class UDialogueActionBase* CreateSection(float StartTime, bool bSecondType=false);

	virtual bool IsTrackReadOnly() const override { return true; }

	TSharedPtr<class SDialogueEditorActionTrackTimeline> GetTrackWidget();

	void RemoveSelectedSection(TSharedRef<class SDialogueEditorActionTrackNode> NotifyNode, bool NeedRefreshTrack=true);

	void OnCopySection(TSharedPtr<class SDialogueEditorActionTrackNode> CopyNode);

	void OnPasteSection();

		
	TArray<TSharedPtr<class SDialogueEditorActionTrackNode>> CopyNode;
	

private:
	TSharedPtr<class SDialogueEditorActionTrackTimeline> TrackWidget = nullptr;
protected:
	float GetMinInput() const { return 0.0f; }
	float GetMaxInput() const;
	float GetViewMinInput() const;
	float GetViewMaxInput() const;

	void OnSetInputViewRange(float ViewMin, float ViewMax);

	void InputViewRangeChanged(float ViewMin, float ViewMax);

	void OnSelectActionSection(class UDialogueActionBase* Section);
	void OnSelectSectionChange(TArray<TWeakObjectPtr<UDialogueActionBase>> CurrentSelects);
};