#pragma once

#include "Widgets/TimeLineBase/AnimTimelineTrack.h"
#include "DialogueEditor/Dialogue/DialogueAsset.h"

class KGSTORYLINEEDITOR_API FDialogueEditorTrack : public FAnimTimelineTrack
{
	ANIMTIMELINE_DECLARE_TRACK(FDialogueEditorTrack, FAnimTimelineTrack);

public:
	FDialogueEditorTrack(const TSharedRef<class FDialogueEditorTimelineController>& InModel, const TWeakPtr<class FDialogueEditor>& InAssetEditor, UDialogueTrackBase* InTrack, const FText& InDisplayName, const FText& InToolTipText);

	void FillInnerHorizontalBox(TSharedPtr<SHorizontalBox> InnerHorizontalBox, TAttribute<FText> HighlightText);
	
	virtual TSharedRef<SWidget> GenerateContainerWidgetForOutliner(const TSharedRef<SAnimOutlinerItem>& InRow) override;

	TSharedRef<SWidget> GenerateOnDragContainerWidgetForOutliner();

	virtual TSharedRef<SWidget> GenerateContainerWidgetForTimeline() override;

	FText GetName() const;
	FText GetTrackPreivewName() const;
	virtual TArray<float> GetAssistLinePosX() override;
	virtual bool IsSectionBeDragged() override;



	void HandleNameCommitted(const FText& NewText, ETextCommit::Type CommitInfo);

	TSharedRef<SWidget> BuildTrackSubMenu();

	void AddTrackMenuEntry(FMenuBuilder& InMenuBuilder)const;

	void RemoveTrack() const;

	bool IsTrackReadOnly() const;

	void SetIsSelect(bool InSelect);

public:
	virtual bool SupportsSelection() const;

	virtual void AddToContextMenu(FMenuBuilder& InMenuBuilder, TSet<FName>& InOutExistingMenuTypes) const override;

	virtual UObject* GetCachedTrack();

	virtual TSharedPtr<class FDialogueTrackEditor> GetTrackEditor();

	virtual TOptional<EItemDropZone> OnCanAcceptDrop(const FDragDropEvent& DragDropEvent, EItemDropZone InItemDropZone, TSharedRef<FAnimTimelineTrack> InItem) override;

	virtual FReply OnAcceptDrop(const FDragDropEvent& DragDropEvent, EItemDropZone DropZone, TSharedRef<FAnimTimelineTrack> TargetItem) override;

	static const float NotificationTrackHeight;

	static const float SectionSnappingDeltaTime;

private:
	TWeakObjectPtr<UDialogueTrackBase> CachedTrack;

	TWeakPtr<class FDialogueEditor> CachedEditor = nullptr;
	TWeakPtr<SBorder> BackgroundBorder = nullptr;
	TSharedPtr<class FDialogueTrackEditor> TrackEditor;
	bool bSelect = false;
};