#pragma once

#include "CoreMinimal.h"
#include "Input/Reply.h"
#include "Misc/Attribute.h"
#include "ScopedTransaction.h"

#include "Widgets/SBoxPanel.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"


class SBorder;

class KGSTORYLINEEDITOR_API SDialogueEditorTrackOutliner : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SDialogueEditorTrackOutliner) {};
	SLATE_ARGUMENT(TSharedPtr<SBorder>, TrackPanelArea)
	SLATE_ARGUMENT(TSharedPtr<SWidget>, OutlineWidget)
	SLATE_ARGUMENT(TSharedPtr<SWidget>, InlineEditableTextBlock)
	SLATE_ARGUMENT(TSharedPtr<SWidget>, ExtraTextBlock)
	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs, const TSharedPtr<class FTimelineController>& InTimelineController, class UDialogueTrackBase* InTrack, TSharedPtr<class FDialogueEditorTrack> InDialogueEditorTrack);

	void UpdateLayout();

	virtual FReply OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;

	virtual void OnDragEnter(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;

	virtual void OnDragLeave(const FDragDropEvent& DragDropEvent) override;

	virtual FReply OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	virtual FReply OnMouseButtonDoubleClick(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	virtual FReply OnKeyUp(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

protected:
	TWeakPtr<class FDialogueEditorTimelineController> TimelineController = nullptr;

	TWeakObjectPtr<class UDialogueTrackBase> CachedTrack = nullptr;

	TSharedPtr<SBorder>	TrackPanelArea;

	TSharedPtr<SWidget>	OutlineWidget;

	TSharedPtr<SWidget>	InlineEditableTextBlock;

	TSharedPtr<SWidget>	ExtraTextBlock;

	TWeakPtr<FDialogueEditorTrack>	CachedDialogueEditorTrack;
};