#pragma once

#include "CoreMinimal.h"
#include "Input/Reply.h"
#include "Input/DragAndDrop.h"
#include "Misc/Attribute.h"

#include "SNodePanel.h"
#include "SCurveEditor.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackTimeline.h"
#include "DialogueEditor/Widgets/TimeLine/SDialogueEditorActionTrackNode.h"
#include "DialogueEditor/Widgets/TimeLine/DialogueEditorTimelineController.h"


class KGSTORYLINEEDITOR_API FDialogueEditorTrackDragDropOp : public FDragDropOperation
{
public:
	DRAG_DROP_OPERATOR_TYPE(FDialogueEditorTrackDragDropOp, FDragDropOperation)

	FDialogueEditorTrackDragDropOp();

	void Construct() override;

	static TSharedRef<FDialogueEditorTrackDragDropOp> New(const TSharedPtr<FDialogueEditorTimelineController>& InTimelineController, class UDialogueTrackBase* InTrack, TSharedPtr<SWidget> Decorator);

	void OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent) override;

	void OnDragged(const class FDragDropEvent& DragDropEvent) override;

	TSharedPtr<SWidget> GetDefaultDecorator() const override;

	void SetCanDropHere(bool bCanDropHere);

	void ChangeTrackPosition(class UDialogueTrackBase* TargetTask, EItemDropZone DropZone);

public:
	TSharedPtr<SWidget>	Decorator = nullptr;

	TWeakObjectPtr<class UDialogueTrackBase> CachedTrack = nullptr;

	TWeakPtr<FDialogueEditorTimelineController> TimelineController = nullptr;

};


class KGSTORYLINEEDITOR_API FDialogueEditorSectionDragDropOp : public FDragDropOperation
{
public:
	struct FTrackClampInfo
	{
		int32 TrackPos;
		int32 TrackSnapTestPos;
		TSharedPtr<SDialogueEditorActionTrackTimeline> NotifyTrack;
	};
	
	DRAG_DROP_OPERATOR_TYPE(FDialogueEditorSectionDragDropOp, FDragDropOperation)

	FDialogueEditorSectionDragDropOp(float& InCurrentDragXPosition);

	static TSharedRef<FDialogueEditorSectionDragDropOp> New
	(
		TSharedPtr<FDialogueEditorTimelineController> DialogueTimelineController,
		TArray<TSharedPtr<SDialogueEditorActionTrackNode>> NotifyNodes, TSharedPtr<SWidget> Decorator,
		const TArray<TSharedPtr<SDialogueEditorActionTrackTimeline>>& NotifyTracks, float InViewPlayLength,
		const FVector2D& CursorPosition, const FVector2D& SelectionScreenPosition,
		const FVector2D& SelectionSize, float& CurrentDragXPosition, FRefreshPanel& RefreshPanel, const float TrackMinOffset
	);

	virtual void OnDrop(bool bDropWasHandled, const FPointerEvent& MouseEvent) override;

	virtual void OnDragged(const class FDragDropEvent& DragDropEvent) override;

	virtual TSharedPtr<SWidget> GetDefaultDecorator() const override
	{
		return Decorator;
	}

	FText GetHoverText() const;

	FTrackClampInfo& GetTrackClampInfo(const FVector2D NodePos);

public:
	FVector2D DragOffset;
	TArray<FTrackClampInfo> ClampInfos;	

	TSharedPtr<SWidget> Decorator;
	TArray<TSharedPtr<SDialogueEditorActionTrackNode>> SelectedNodes;
	TSharedPtr<FDialogueEditorTimelineController> TimelineController;

	TArray<float> NodeTimes;
	TArray<float> NodeTimeOffsets;
	TArray<float> NodeXOffsets;
	FVector2D NodeGroupPosition;
	FVector2D NodeGroupSize;

	int32 TrackSpan;
	float ViewPlayLength;
	float SelectionTimeLength;
	float CurrentDragXPosition;
	float TrackMinOffset;

	FRefreshPanel RefreshPanelEvent;

};

