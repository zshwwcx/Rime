#pragma once

#include "Toolkits/IToolkitHost.h"
#include "AssetTypeActions_Base.h"

class UDialogueAsset;

class KGSTORYLINEEDITOR_API FAssetTypeActions_DialogueTemplateAsset : public FAssetTypeActions_Base
{
public:
	FAssetTypeActions_DialogueTemplateAsset(EAssetTypeCategories::Type InAssetCategory);

	~FAssetTypeActions_DialogueTemplateAsset();

	virtual FText GetName() const override;

	virtual FColor GetTypeColor() const override;

	virtual UClass* GetSupportedClass() const override;

	virtual bool HasActions(const TArray<UObject*>& InObjects) const override { return true; }

	virtual void GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder) override;

	virtual void OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor = TSharedPtr<IToolkitHost>()) override;

	virtual bool SupportsOpenedMethod(const EAssetTypeActivationOpenedMethod OpenedMethod) const override;

	virtual uint32 GetCategories() override;

private:
	EAssetTypeCategories::Type MyAssetCategory;

};

class KGSTORYLINEEDITOR_API FAssetTypeActions_DialogueAsset : public FAssetTypeActions_Base
{
public:
	FAssetTypeActions_DialogueAsset(EAssetTypeCategories::Type InAssetCategory);

	~FAssetTypeActions_DialogueAsset();

	virtual FText GetName() const override;

	virtual FColor GetTypeColor() const override;

	virtual UClass* GetSupportedClass() const override;

	virtual bool HasActions(const TArray<UObject*>& InObjects) const override { return true; }
	
	void ExecuteValidateEpisodeID(TArray<TWeakObjectPtr<UDialogueAsset>> DialogueAssets);
	void ExecuteValidateEpisodeTracks(TArray<TWeakObjectPtr<UDialogueAsset>> DialogueAssets);
	
	virtual void GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder) override;

	virtual void OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor = TSharedPtr<IToolkitHost>()) override;

	virtual uint32 GetCategories() override;
	
	static void ValidateEpisodeID(UDialogueAsset* Asset);
	static void ValidateEpisodeTracks(UDialogueAsset* Asset);
private:
	EAssetTypeCategories::Type MyAssetCategory;

};