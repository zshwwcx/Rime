#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"

#include "EditorWorldExtension.h"
#include "DialogueEditorWorldExtension.generated.h"


UCLASS(BlueprintType, Transient)
class UDialogueEditorWorldExtension : public UEditorWorldExtension
{
	GENERATED_BODY()

public:

	UDialogueEditorWorldExtension();

	virtual bool InputKey(FEditorViewportClient* InViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event);

public:
	TWeakPtr<class FDialogueEditor> CachedEditor;
};