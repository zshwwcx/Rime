#pragma once
#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Delegates/DelegateCombinations.h"
#include "DialogueEditor/Dialogue/Actions/DialogueActions.h"


class KGSTORYLINEEDITOR_API FDialogueEditorDelegates
{
public:
	DECLARE_MULTICAST_DELEGATE_TwoParams(FPreviewStateChanged, bool, bool);
	static FPreviewStateChanged PreviewStateChangedEvent;

	DECLARE_MULTICAST_DELEGATE_TwoParams(FSectionInstanceNoticeLua, UDialogueActionBase*, int32);
	static FSectionInstanceNoticeLua SectionInstanceNoticeLua;
	
	DECLARE_MULTICAST_DELEGATE_TwoParams(FOnTabActive, FString, bool);
	static FOnTabActive OnTabActive;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnSectionSelect, TArray<TWeakObjectPtr<UDialogueActionBase>>);
	static FOnSectionSelect OnSectionSelect;
};