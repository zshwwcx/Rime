// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "AssetDefinitionRegistry.h"
#include "AssetTypeActions_Base.h"
#include "LevelSequence.h"
#include "Settings/LevelEditorPlaySettings.h"

/**
 * 反向再用AssetTypeActions把引擎内的AssetDefinition包一层, 进行一些扩展
 */
class FStoryLineAssetDefinitionWrapper : public FAssetTypeActions_Base
{
public:
	explicit FStoryLineAssetDefinitionWrapper(UClass* InClass);
	virtual FText GetName() const override;
	virtual FColor GetTypeColor() const override;
	virtual bool ShouldForceWorldCentric() override;
	virtual uint32 GetCategories() override { return EAssetTypeCategories::Misc; }
	virtual UClass* GetSupportedClass() const override { return Class.IsValid() ? Class.Get() : nullptr; }
	virtual void OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor = TSharedPtr<IToolkitHost>()) override;
	virtual bool SupportsOpenedMethod(EAssetTypeActivationOpenedMethod OpenedMethod) const override;
private:
	TWeakObjectPtr<UClass> Class;
};