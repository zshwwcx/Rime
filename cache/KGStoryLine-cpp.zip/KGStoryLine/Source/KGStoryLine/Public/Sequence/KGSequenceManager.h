#pragma once
#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "MovieSceneObjectBindingID.h"
#include "Misc/CommonDefines.h"
#include "LevelSequencePlayer.h"
#include "Tracks/MovieSceneSubTrack.h"
#include "Sections/MovieSceneSubSection.h"
#include "CutScene/MovieSceneCustomSection.h"
#include "KGSequenceManager.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogSequenceManager, Log, All);

class USequenceLoadTask;
struct FMovieSceneFloatChannel;

USTRUCT(BlueprintType)
struct FMovieSceneBindingTagTemplateParams
{
	GENERATED_BODY()

	FMovieSceneBindingTagTemplateParams()
	{
	}

	FMovieSceneBindingTagTemplateParams(FName Tag, FGuid guid, int32 SequenceID)
		:BindingTag(Tag), Guid(guid), SequenceID(SequenceID)
	{
	}

	UPROPERTY()
	FName BindingTag;

	UPROPERTY()
	FGuid Guid;

	UPROPERTY()
	int32 SequenceID = 0;
};

USTRUCT(BlueprintType)
struct FMovieSceneBindingActorParams
{
	GENERATED_BODY()

	FMovieSceneBindingActorParams()
	{
	}

	FMovieSceneBindingActorParams(int loadHandleID, FGuid BindingGuid, int32 SequenceID)
		:loadHandleID(loadHandleID), BindingGuid(BindingGuid), SequenceID(SequenceID)
	{
	}

	UPROPERTY()
	int loadHandleID=0;

	UPROPERTY()
	FGuid BindingGuid;

	UPROPERTY()
	int32 SequenceID = 0;
};

/** 
 * 存每个LoadHandle的每个Sequence的运行时状态
 * Teardown时清空
 */
struct FCustomActionRuntimeStatus
{
	/** 是否需要停止Tick, CustomAction Execute 返回True之后, 即可停止Tick */
	bool bTickStopped = false;

	/** 是否已经执行过一次 */
	bool bHasExecuted = false;
};

UENUM(Flags)
enum class EActorCopyPropertyFlags : uint32
{
	Platform = 1 << 1,
	All = Platform,
};

UCLASS(Blueprintable, BlueprintType)
class KGSTORYLINE_API UKGSequenceManager : public UKGBasicManager
{
	GENERATED_BODY()

#pragma region Important
public:
	UKGSequenceManager();

	static UKGSequenceManager* GetInstance(UObject* InContext);
	static UKGSequenceManager* GetSequenceManagerInEditor();
	static UKGSequenceManager* GetSequenceManager(IMovieScenePlayer& Player);
	virtual void NativeInit() override;

	virtual void NativeUninit() override;
	
	virtual EManagerType GetManagerType() override { return EManagerType::EMT_SequenceManager; }
#pragma endregion Important


public:
#pragma region For Lua
	TArray<FMovieSceneBindingTagTemplateParams> KAPI_GetAllSpawnableObjectTemplate(int loadHandleID); 
	
	TArray<FString> KAPI_GetAllSubSequencePaths(int loadHandleID);

	void KAPI_DoTraversalAllTracks(int loadHandleID);
	
	KGObjectID KAPI_CreateEmptyActor(int loadHandleID);
	
	KGObjectID KAPI_CreateLevelSequence(KGObjectID LevelSequenceID, int loadHandleID, bool bPauseAtEnd=false, bool bAutoPlay = true, bool bDisableCameraCuts=false);
	
	void KAPI_DestroyLevelSequence(int loadHandleID);

	//lizhang@kuaishou.com, add new function can handle both spawnable and possessable bindings
	KGObjectID KAPI_GetBindingObjectIDByBindingID(int loadHandleID,  FGuid BindingGuid);
	
	KGObjectID KAPI_GetSpawnableObjectIDByBindingID(int loadHandleID,  FGuid BindingGuid);

	TArray<KGObjectID> KAPI_GetMultiAttachSectionIDs(int loadHandleID);
	
	TArray<KGObjectID> KAPI_GetCustomTrackSections(int loadHandleID, FString ActionName);

	KGObjectID KAPI_GetCustomDataBySectionID(KGObjectID SectionID);

	FGuid KAPI_GetBindingTemplateGuidBySectionID(int loadHandleID, KGObjectID SectionID);
	
	TArray<FGuid> KAPI_GetMultiAttachSectionInfo(int loadHandleID, KGObjectID SectionID);

	void KAPI_SetMultiAttachRealBindingID(int loadHandleID, int sequenceID, KGObjectID SectionID, FGuid TargetGuid);
	
	void KAPI_BindSequenceCallBack(int loadHandleID);
	
	void KAPI_SetPlayRate(int loadHandleID, float Rate);
	
	float KAPI_GetPlayRate(int loadHandleID);

	/**
	 * 设置DisplayRate, 不影响播放速率, 影响每秒的帧数, 用于实现抽帧效果.
	 * @param LoadHandleID 
	 * @param Frame 每秒帧数: 15, 30, ...
	 * @return bSuccess, true if success
	 */
	bool KAPI_SetDisplayRate(int LoadHandleID, int32 Frame);

	/**
	 * @param LoadHandleID 
	 * @return Frame -1 if failed
	 */
	int32 KAPI_GetDisplayRate(int LoadHandleID);
	
	void KAPI_SetSequencePlayerParams(int loadHandleID, float StartTime);
	
	float KAPI_GetSequencePlayerDuration(int loadHandleID);
	
	float KAPI_GetSequencePlayerPlayTime(int loadHandleID);

	float KAPI_GetSequencePlayerStartTime(int loadHandleID);
	
	void KAPI_SetBinding(int loadHandleID, KGObjectID ActorID, FGuid BindingGuid, int32 SequenceID);
	
	void KAPI_RemoveBinding(int loadHandleID, KGObjectID ActorID, FGuid BindingGuid, int32 SequenceID);
	
	void KAPI_SequencePlay(int loadHandleID, bool bLoop);

	void KAPI_SequenceStop(int loadHandleID);
	
	void KAPI_LevelSequenceJumpToStart(int loadHandleID);
	
	void KAPI_LevelSequenceJumpToFrame(int loadHandleID, int32 Frame);

	void KAPI_LevelSequenceJumpToMark(int loadHandleID, const FString& InMarkedFrame);
	
	void KAPI_LevelSequencePlayToFrame(int loadHandleID, int32 Frame);

	void KAPI_LevelSequencePlayToMark(int loadHandleID, const FString& InMarkedFrame);

	void KAPI_LevelSequencePlayToEnd(int loadHandleID);

	void KAPI_LevelSequenceSetFrameRange(int loadHandleID, int32 NewStartTime, int32 Duration);
	
	int32 KAPI_GetMovieSceneDisplayRate(int loadHandleID);

	void KAPI_ChangeSequenceTransformOriginActor(int loadHandleID, KGObjectID ActorID);

	FVector KAPI_GetTransformTrackPostionByBindingGuid(int loadHandleID, FGuid BindingGuid);

	void KAPI_CopyPropertyFromTemplate(KGObjectID NewActorID, KGObjectID TemplateActorID, EActorCopyPropertyFlags Flags);

	void KAPI_BindSequenceTriggerOnBeginOverlay(int loadHandleID, KGObjectID ActorID);
	
	void KAPI_ClearSequenceTriggerOnBeginOverlay(int loadHandleID);

	float  KAPI_GetSectionStartTime(KGObjectID SectionID);
	
	float KAPI_GetSectionEndTime(KGObjectID SectionID);
	
	void KAPI_SetSectionDuration(KGObjectID SectionID, float Duration);
	
	void KAPI_SetSectionDisplayName(KGObjectID SectionID, FString DisplayName);
	
	void KAPI_MuteTransformTrackByBindingGuid(KGObjectID SectionID, bool isMute);

	TMap<FString, int32> KAPI_GetSequenceMarkLabelToFrameNumber(int loadHandleID);
#pragma endregion For Lua

#pragma region For C++
	int GetSequenceLoadHandleIDByMoviePlayer(IMovieScenePlayer& Player);
	
	void OnCustomTrackSectionSetUp(const UMovieSceneCustomSection* MovieSceneCustomSection, int LoadHandleID=-1);

	void OnCustomTrackSectionExecute(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, float CurrentTime, int LoadHandleID=-1);
	
	void OnCustomTrackSectionTearDown(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, int LoadHandleID=-1);

	template<typename ...ARGS>
	void CallCustomProxyFunction(const FString& ProxyName, const FString& FunctionName, ARGS&& ...Args)
	{
		CallLuaFunction("CallCustomProxyFunction", ProxyName, FunctionName, std::forward<ARGS>(Args)...);
	};
	
#if WITH_EDITOR
	TSet<int32> FacadeIDs;

	void OnCustomTrackSectionSetUpInEditor(const UMovieSceneCustomSection* MovieSceneCustomSection, int LoadHandleID=-2);

	void OnCustomTrackSectionExecuteInEditor(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, float CurrentTime, int LoadHandleID=-2);
	
	void OnCustomTrackSectionTearDownInEditor(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, int LoadHandleID=-2);
	
	void OnCustomTrackSectionPropertyChange(const UMovieSceneCustomSection* MovieSceneCustomSection, bool isSectionData, FString PropertyName, int LoadHandleID);

	void CheckSequenceData();

	void KAPI_CheckSequenceByAssetPath(const FString& AssetPath);

	void KAPI_OnCheckSequenceFinish();
#endif
	static const int EditorLoadHandleID = -2;
#pragma endregion For C++

#pragma region Internal
protected:
	FMovieSceneObjectBindingID GetBindingIDByGuid(int loadHandle, FGuid Guid, int32 SequenceID);

	UFUNCTION()
	void OnSequenceTriggerBeginOverlap(AActor* OverlappedActor, AActor* OtherActor);
	
	UFUNCTION()
	void OnBoundActorDestroyed(AActor* DestroyedActor);
#pragma endregion Internal
	
private:
	UPROPERTY()
	TMap<int, TObjectPtr<USequenceLoadTask>> CacheSequenceHelpers;
	FVector InvalidPos = FVector(10000, 10000, 10000);

	TMap<int32, TMap<int32, FCustomActionRuntimeStatus>> CustomActionStatus;
};