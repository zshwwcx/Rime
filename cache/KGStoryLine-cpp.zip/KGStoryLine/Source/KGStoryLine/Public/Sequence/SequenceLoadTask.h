#pragma once
#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "Misc/CommonDefines.h"
#include "LevelSequenceActor.h"
#include "Sequence/KGSequenceManager.h"
#include "SequenceLoadTask.generated.h"

class UKGSequenceManager;


UCLASS()
class KGSTORYLINE_API USequenceLoadTask : public UObject
{
	GENERATED_BODY()


public:

	void Init(KGObjectID ID, int loadHandle)
	{
		LevelSequenceActorID = ID;
		loadHandleID = loadHandle;
	}
	
	void HelperBindSequenceCallBack();
	void HelperRemoveSequenceCallBack();
	
	ALevelSequenceActor* GetSequenceActor();
	ULevelSequencePlayer* GetSequencePlayer();

	TArray<KGActorID> SequenceTriggerCache;
	TArray<KGObjectID> CustomSectionObjectIDs;
	TArray<KGObjectID> MultiAttachSectionIDs;
	TMap<KGObjectID, TArray<FGuid>> AttachSectionInfo;
	TMap<KGActorID, FMovieSceneBindingActorParams> BindingActorIDToGuids;
private:
	UFUNCTION()
	void OnSequencePlay();
	UFUNCTION()
	void OnSequenceFinished();
	UFUNCTION()
	void OnSequencePause();
	UFUNCTION()
	void OnSequenceSubSequencePlay(int sequenceId);
	UFUNCTION()
	void OnSequenceCameraCut(UCameraComponent* CameraComponent);
	
	KGObjectID LevelSequenceActorID = 0;
	int loadHandleID = 0;
};