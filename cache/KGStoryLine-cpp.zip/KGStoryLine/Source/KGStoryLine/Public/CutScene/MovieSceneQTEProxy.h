#pragma once
#include "LuaOverriderInterface.h"
#include "CutScene/MovieSceneQTESection.h"


class KGSTORYLINE_API FMovieSceneQTEProxy
{
public:
	static void Execute(IMovieScenePlayer& Player, const UMovieSceneQTESection* MovieSceneCustomSection, float CurrentTime, int32 LoadHandle);
	static void SetUp(IMovieScenePlayer& Player, const UMovieSceneQTESection* MovieSceneCustomSection, int32 LoadHandle);
	static void TearDown(IMovieScenePlayer& Player, const UMovieSceneQTESection* MovieSceneCustomSection, int32 LoadHandle);
};
