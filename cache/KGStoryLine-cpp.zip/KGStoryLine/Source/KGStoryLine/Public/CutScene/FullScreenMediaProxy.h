// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "Sequence/KGSequenceManager.h"

class KGSTORYLINE_API FFullScreenMediaProxy
{
public:
	static void SetUp(IMovieScenePlayer& Player, const FString& Url, const bool bLooping, const bool bReference, const float SizePercent)
	{
		if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
		{
			Manager->CallCustomProxyFunction("FullScreenMediaProxy", "SetUp", Url, bLooping, bReference, SizePercent);
		}
	}

	static void TearDown(IMovieScenePlayer& Player)
	{
		if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
		{
			Manager->CallCustomProxyFunction("FullScreenMediaProxy", "TearDown");
		}
	}

	static void Seek(IMovieScenePlayer& Player, const double CurrentTime)
	{
		if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
		{
			Manager->CallCustomProxyFunction("FullScreenMediaProxy", "Seek", CurrentTime);
		}
	}

	static void SetRate(IMovieScenePlayer& Player, const float X)
	{
		if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
		{
			Manager->CallCustomProxyFunction("FullScreenMediaProxy", "SetRate", X);
		}
	}

	static void PreRoll(IMovieScenePlayer& Player)
	{
		if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
		{
			Manager->CallCustomProxyFunction("FullScreenMediaProxy", "PreRoll");
		}
	}
};
