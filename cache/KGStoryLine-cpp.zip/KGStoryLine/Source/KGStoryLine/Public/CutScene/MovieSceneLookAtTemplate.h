// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "Channels/MovieSceneFloatChannel.h"
#include "CutScene/MovieSceneLookAtSection.h"
#include "MovieSceneLookAtTemplate.generated.h"


class UMovieSceneFloatSection;
class UMovieScenePropertyTrack;

USTRUCT()
struct FMovieSceneLookAtSectionTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()
	
	FMovieSceneLookAtSectionTemplate() {}
	FMovieSceneLookAtSectionTemplate(const UMovieSceneLookAtSection& Section, const UMovieScenePropertyTrack& Track);

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;

	// cppcheck:push ignore
	UPROPERTY()
	FMovieSceneDoubleChannel Eye[3];

	UPROPERTY()
	FMovieSceneDoubleChannel Head[3];

	UPROPERTY()
	FMovieSceneDoubleChannel Body[3];
	
	UPROPERTY()
	FMovieSceneDoubleChannel Spine_01[3];
	
	UPROPERTY()
	FMovieSceneDoubleChannel Spine_02[3];

	UPROPERTY()
	FMovieSceneDoubleChannel Spine_03[3];
	// cppcheck:pop
};
