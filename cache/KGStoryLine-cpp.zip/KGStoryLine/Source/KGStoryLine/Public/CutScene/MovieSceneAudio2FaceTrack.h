#pragma once

#include "Tracks/MovieSceneSpawnTrack.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "MovieSceneNameableTrack.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "Evaluation/MovieSceneEvaluationOperand.h"
#include "MovieSceneAudio2FaceTrack.generated.h"

UCLASS()
class KGSTORYLINE_API UMovieSceneAudio2FaceTrack : public UMovieSceneNameableTrack, public IMovieSceneTrackTemplateProducer
{
	GENERATED_BODY()
public:
	UMovieSceneAudio2FaceTrack(const FObjectInitializer& ObjectInitializer);
	virtual ~UMovieSceneAudio2FaceTrack() override;

public:
	virtual void AddSection(UMovieSceneSection& Section) override;
	virtual UMovieSceneSection* CreateNewSection() override;
	virtual const TArray<UMovieSceneSection*>& GetAllSections() const override;
	virtual bool HasSection(const UMovieSceneSection& Section) const override;
	virtual bool IsEmpty() const override;
	virtual void RemoveSection(UMovieSceneSection& Section) override;
	virtual void RemoveSectionAt(int32 SectionIndex) override;
	virtual FName GetTrackName() const override;
#if WITH_EDITORONLY_DATA
	virtual FText GetDefaultDisplayName() const override;
#endif
	virtual bool SupportsMultipleRows() const override;
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;

	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;

	void Execute(const class UMovieSceneAudio2FaceSection* MovieSceneCustomSection, AActor* InActor, float CurrentTime);

	void SetUp(const class UMovieSceneAudio2FaceSection* MovieSceneCustomSection, AActor* InActor);

	void TearDown(const class UMovieSceneAudio2FaceSection* MovieSceneCustomSection, AActor* InActor);


private:
	UPROPERTY()
	TArray<TObjectPtr<UMovieSceneSection>> Sections;

public:
	FMovieSceneEvaluationOperand LastOperand;

	bool bSetUpFace = false;
};
