#pragma once

#include "CoreMinimal.h"
#include "MovieSceneSection.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "MovieSceneResizeBoundsSection.generated.h"


USTRUCT()
struct FMovieSceneResizeBoundsTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
	virtual void Initialize(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void SetupOverrides() override { EnableOverrides(RequiresInitializeFlag | RequiresTearDownFlag); }
};

/**
 * 
 */
UCLASS()
class KGSTORYLINE_API UMovieSceneResizeBoundsSection : public UMovieSceneSection
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FName BoneName = TEXT("pelvis");
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	float Threshold = 1.0f;
};
