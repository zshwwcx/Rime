// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#pragma once

#include "CoreMinimal.h" 
#include "LuaOverriderInterface.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "EValuation/MovieSceneEvalTemplate.h"
#include "Tracks/MovieScenePropertyTrack.h"
#include "MovieSceneGazeTrack.generated.h"


class KGSTORYLINE_API FMovieSceneGazeProxy
{
public:
	static void Setup(IMovieScenePlayer& Player);
	static void StartCutsceneGaze(IMovieScenePlayer& Player, int64 OwnerActorID, int64 TargetActorID, const FString& BoneName, FVector Offset);
	static void StopCutsceneGaze(IMovieScenePlayer& Player, int64 OwnerActorID, int64 TargetActorID, const FString& BoneName, FVector Offset);
};

UCLASS()
class KGSTORYLINE_API UMovieSceneGazeSection : public UMovieSceneSection
{
	GENERATED_BODY()

	public:
	/** Gaze对象 */
	UPROPERTY(EditAnywhere)
	FGuid ObjectBindingId;

	/** Gaze对象的骨骼名称 */
	UPROPERTY(EditAnywhere)
	FString BoneName = TEXT("head");

	UPROPERTY(EditAnywhere)
	FVector Offset;
};

UCLASS()
class KGSTORYLINE_API UMovieSceneGazeTrack
	: public UMovieSceneNameableTrack
	, public IMovieSceneTrackTemplateProducer
{
	GENERATED_BODY()

public:
	UMovieSceneGazeTrack(const FObjectInitializer& ObjectInitializer);
	
	// UMovieSceneTrack interface
	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;
	
	virtual UMovieSceneSection* CreateNewSection() override;
	virtual const TArray<UMovieSceneSection*>& GetAllSections() const override;
	virtual void AddSection(UMovieSceneSection& Section) override;
	virtual bool HasSection(const UMovieSceneSection& Section) const override;
	virtual bool IsEmpty() const override;
	virtual void RemoveSection(UMovieSceneSection& Section) override;
	virtual void RemoveSectionAt(int32 SectionIndex) override;

#if WITH_EDITORONLY_DATA
	virtual FText GetDisplayName() const override;
#endif
	
	UPROPERTY(Transient)
	bool bDataModified = false;
	
private:
	UPROPERTY()
	TArray<TObjectPtr<UMovieSceneSection>> Sections;
};

USTRUCT()
struct FMovieSceneGazeSectionTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()
	
	FMovieSceneGazeSectionTemplate() {}
	FMovieSceneGazeSectionTemplate(const UMovieSceneGazeSection& Section, const UMovieSceneGazeTrack& Track);
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	virtual void SetupOverrides() override;
	
	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
	virtual void Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
};
