#pragma once

#include "CoreMinimal.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "CutScene/MovieSceneCustomTrack.h"
#include "MovieSceneCustomTemplate.generated.h"

class UMovieSceneCustomTrack;
class UMovieSceneCustomSection;


USTRUCT()
struct FMovieSceneCustomTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()

	FMovieSceneCustomTemplate();
	FMovieSceneCustomTemplate(const UMovieSceneCustomSection& Section, const UMovieSceneCustomTrack& Track);

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
	virtual void Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void SetupOverrides() override { EnableOverrides(RequiresSetupFlag | RequiresTearDownFlag); }

#if WITH_EDITOR
	inline static bool bNeedUpdateAfterTransactionFinished = false;
#endif
};
