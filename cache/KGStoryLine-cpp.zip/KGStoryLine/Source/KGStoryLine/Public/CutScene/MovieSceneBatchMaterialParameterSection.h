// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "EntitySystem/IMovieSceneEntityProvider.h"
#include "Sections/MovieSceneComponentMaterialParameterSection.h"
#include "MovieSceneBatchMaterialParameterSection.generated.h"

UCLASS()
class KGSTORYLINE_API UMovieSceneBatchMaterialParameterSection
	: public UMovieSceneComponentMaterialParameterSection
{
	GENERATED_BODY()

	UMovieSceneBatchMaterialParameterSection();
public:
	virtual void ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity) override;

protected:
	//make sure the encode/decode method stay consistent with the super class, so just copy them from UMovieSceneComponentMaterialParameterSection
	/* Entity IDs are an encoded type and index, with the upper 8 bits being the type, and the lower 24 bits as the index */
	static uint32 EncodeMaterialParameterEntityID(int32 InIndex, uint8 InType)
	{
		check(InIndex >= 0 && InIndex < int32(0x00FFFFFF));
		return static_cast<uint32>(InIndex) | (uint32(InType) << 24);
	}
	static void DecodeMaterialParameterEntityID(uint32 InEntityID, int32& OutIndex, uint8& OutType)
	{
		// Mask out the type to get the index
		OutIndex = static_cast<int32>(InEntityID & 0x00FFFFFF);
		OutType = InEntityID >> 24;
	}
};
