#pragma once
#include "Tracks/MovieSceneSpawnTrack.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "Camera/CameraActor.h"
#include "MovieSceneNameableTrack.h"
#include "LuaOverriderInterface.h"
#include "CutScene/MovieSceneQTESection.h"
#include "CutScene/MovieSceneQTEProxy.h"
#include "MovieSceneQTETrack.generated.h"

UCLASS()
class KGSTORYLINE_API UMovieSceneQTETrack : public UMovieSceneNameableTrack, public IMovieSceneTrackTemplateProducer
{
	GENERATED_BODY()
public:
	UMovieSceneQTETrack(const FObjectInitializer& ObjectInitializer);
	virtual ~UMovieSceneQTETrack() override;

public:
	virtual void AddSection(UMovieSceneSection& Section) override;
	virtual class UMovieSceneSection* CreateNewSection() override;
	virtual const TArray<UMovieSceneSection*>& GetAllSections() const override;
	virtual bool HasSection(const UMovieSceneSection& Section) const override;
	virtual bool IsEmpty() const override;
	virtual void RemoveSectionAt(int32 SectionIndex) override;
	virtual void RemoveSection(UMovieSceneSection& Section) override;
	virtual FName GetTrackName() const override;
#if WITH_EDITORONLY_DATA
	virtual FText GetDefaultDisplayName() const override;
#endif
	virtual bool SupportsMultipleRows() const override;
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;

	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;

private:
	UPROPERTY()
	TArray<UMovieSceneSection*> Sections;
};
