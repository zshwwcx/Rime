// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "EntitySystem/MovieSceneEntityIDs.h"

struct FKGMovieSceneComponentType
{
	KGSTORYLINE_API ~FKGMovieSceneComponentType();
	
	static KGSTORYLINE_API void Destroy();

	static KGSTORYLINE_API FKGMovieSceneComponentType* Get();

	struct
	{
		UE::MovieScene::FComponentTypeID BatchMaterialOnActor;
	} Tags;

	struct
	{
		UE::MovieScene::TComponentTypeID<FText> BatchMaterialSlotName;
	} Components;
private:
	FKGMovieSceneComponentType();
};
