#pragma once

#include "CoreMinimal.h"
#include "MovieSceneSection.h"
#include "MovieSceneAudio2FaceSection.generated.h"


UCLASS()
class KGSTORYLINE_API UMovieSceneAudio2FaceSection :public UMovieSceneSection
{
	GENERATED_BODY()
public:
	UMovieSceneAudio2FaceSection(const FObjectInitializer& ObjectInitializer);

public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FString FaceAnimID;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	float FixTime = 0.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	float LipBlend = 1.0f;
};