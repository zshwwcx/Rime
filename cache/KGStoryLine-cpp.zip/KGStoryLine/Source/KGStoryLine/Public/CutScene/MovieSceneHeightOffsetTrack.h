// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#pragma once

#include "CoreMinimal.h"
#include "LuaOverriderInterface.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "EValuation/MovieSceneEvalTemplate.h"
#include "Tracks/MovieScenePropertyTrack.h"
#include "MovieSceneHeightOffsetTrack.generated.h"

class UMovieSceneHeightOffsetSection;

class KGSTORYLINE_API FMovieSceneHeightOffsetProxy
{
public:
	static void Execute(IMovieScenePlayer& Player, const UMovieSceneHeightOffsetSection* MovieSceneCustomSection, int64 ActorID, float CurrentTime, int32 LoadHandle);
	static void SetUp(IMovieScenePlayer& Player, const UMovieSceneHeightOffsetSection* MovieSceneCustomSection, int32 LoadHandle);
	static void TearDown(IMovieScenePlayer& Player, const UMovieSceneHeightOffsetSection* MovieSceneCustomSection, int32 LoadHandle);
};

UCLASS()
class KGSTORYLINE_API UMovieSceneHeightOffsetSection : public UMovieSceneSection
{
	GENERATED_BODY()

	public:
	/** HeightOffset对象 */
	UPROPERTY(EditAnywhere)
	FGuid ObjectBindingId;

	/** HeightOffset对象的骨骼名称 */
	UPROPERTY(EditAnywhere)
	FString UpperBone = TEXT("head");

	UPROPERTY(EditAnywhere)
	FString LowerBone = TEXT("ball_r");

	/** 初始骨骼高度 */
	UPROPERTY(EditAnywhere)
	float InitHeight = 0;

	UPROPERTY(EditAnywhere)
	TArray<float> SampleHeights;

	UPROPERTY(EditAnywhere)
	float SampleRate = 0.33;

	UPROPERTY(EditAnywhere)
	bool bUseContinuedHeights = false;

	UFUNCTION()
	float Sample(float Time) const;
};

UCLASS()
class KGSTORYLINE_API UMovieSceneHeightOffsetTrack
	: public UMovieSceneNameableTrack
	, public IMovieSceneTrackTemplateProducer
{
	GENERATED_BODY()

public:
	UMovieSceneHeightOffsetTrack(const FObjectInitializer& ObjectInitializer);
	
	// UMovieSceneTrack interface
	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;
	
	virtual UMovieSceneSection* CreateNewSection() override;
	virtual const TArray<UMovieSceneSection*>& GetAllSections() const override;
	virtual void AddSection(UMovieSceneSection& Section) override;
	virtual bool HasSection(const UMovieSceneSection& Section) const override;
	virtual void RemoveSection(UMovieSceneSection& Section) override;
	virtual void RemoveSectionAt(int32 SectionIndex) override;
	virtual bool IsEmpty() const override;

#if WITH_EDITORONLY_DATA
	virtual FText GetDisplayName() const override;
#endif
	
private:
	UPROPERTY()
	TArray<TObjectPtr<UMovieSceneSection>> Sections;
};

USTRUCT()
struct FMovieSceneHeightOffsetSectionTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()
	
	FMovieSceneHeightOffsetSectionTemplate() {}
	FMovieSceneHeightOffsetSectionTemplate(const UMovieSceneHeightOffsetSection& Section, const UMovieSceneHeightOffsetTrack& Track);
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	virtual void SetupOverrides() override;
	
	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
	virtual void Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
};
