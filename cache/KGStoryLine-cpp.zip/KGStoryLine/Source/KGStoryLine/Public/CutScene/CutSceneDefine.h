#pragma once

#include "CoreMinimal.h"

const static FName NAME_CutSceneActorSex_ManTag("Man");
const static FName NAME_CutSceneActorSex_WomanTag("Woman");