#pragma once
#include "CoreMinimal.h"
#include "MovieSceneSection.h"
#include "QTE/BSQTEObject.h"
#include "MovieSceneQTESection.generated.h"


UCLASS()
class KGSTORYLINE_API UMovieSceneQTESection :public UMovieSceneSection
{
    GENERATED_BODY()
public:
    UMovieSceneQTESection(const FObjectInitializer& ObjectInitializer);
    virtual ~UMovieSceneQTESection() override;

#if WITH_EDITORONLY_DATA
    // 要执行的QTE
    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Instanced)
    UBSQTEData* QTEData = nullptr;
#endif

    UPROPERTY(BlueprintReadWrite)
    FString QTEDataString;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	int32 SuccessJumpFrame;

    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
    int32 FailedJumpFrame;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float ConfigPlayRate;

    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
    FString ExtraUIPath;

    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
    TMap<FString, FString> ExtraData;

    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
    bool bJustStopWhenSectionEnd;

public:
#if WITH_EDITOR
    virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

    DECLARE_DELEGATE(FOnQTESectionPostEditChangePropertyDelegate);

    FOnQTESectionPostEditChangePropertyDelegate OnQTESectionPostEditChangePropertyDelegate;
#endif
};