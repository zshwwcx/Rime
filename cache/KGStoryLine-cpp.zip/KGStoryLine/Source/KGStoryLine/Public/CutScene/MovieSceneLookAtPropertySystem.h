// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Systems/MovieScenePropertySystem.h"
#include "MovieSceneLookAtPropertySystem.generated.h"

class UMovieSceneLookAtSection;

UCLASS(MinimalAPI)
class UMovieSceneLookAtPropertySystem : public UMovieScenePropertySystem //UMovieSceneEntitySystem
{
public:

	GENERATED_BODY()

	KGSTORYLINE_API UMovieSceneLookAtPropertySystem(const FObjectInitializer& ObjInit);

	//virtual void OnSchedulePersistentTasks(UE::MovieScene::IEntitySystemScheduler* TaskScheduler) override;

	KGSTORYLINE_API virtual void OnRun(FSystemTaskPrerequisites& InPrerequisites, FSystemSubsequentTasks& Subsequents) override;
};
