#pragma once
#include "CoreMinimal.h"
#include "MovieSceneSection.h"
#include "Camera/CameraComponent.h"
#include "Engine/World.h"
#include "LevelSequenceActor.h"
#include "Misc/CommonDefines.h"

#include "MovieSceneCustomSection.generated.h"

UCLASS(Abstract, Blueprintable, BlueprintType, EditInlineNew)
class KGSTORYLINE_API UMovieSceneCustomData : public UObject
{
    GENERATED_BODY()

public:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Important")
    FString ActionName;

	UFUNCTION(BlueprintCallable)
	void SetDisplayName(FString InDisplayName) {DisplayName = InDisplayName;}

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FString DisplayName;

	/** 扩展Section表现, 包括外观和菜单, fallback: ActionName */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FName SectionEditorName;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif
};


UCLASS()
class KGSTORYLINE_API UMovieSceneCustomSection :public UMovieSceneSection
{
    GENERATED_BODY()
public:
    UMovieSceneCustomSection(const FObjectInitializer& ObjectInitializer);
    virtual ~UMovieSceneCustomSection() override;

    UFUNCTION(BlueprintCallable)
    float GetStartTime() const;

    UFUNCTION(BlueprintCallable)
    float GetEndTime() const;

	UFUNCTION(BlueprintCallable)
	void SetDuration(float Duration);

    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Instanced)
    TObjectPtr<UMovieSceneCustomData> CustomData = nullptr;

public:
#if WITH_EDITOR
    virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

    DECLARE_DELEGATE(FOnCustomSectionPostEditChangePropertyDelegate);

    FOnCustomSectionPostEditChangePropertyDelegate OnCustomSectionPostEditChangePropertyDelegate;
#endif

    UFUNCTION(BlueprintCallable, Category = "Sequencer|Section")
    void ConstrainCurrentCamera(bool bVertical, UWorld* world, int64 ActorID);
};