#pragma once

#include "CoreMinimal.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "MovieSceneAudio2FaceTemplate.generated.h"


USTRUCT()
struct FMovieSceneAudio2FaceTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()

	FMovieSceneAudio2FaceTemplate();
	FMovieSceneAudio2FaceTemplate(const class UMovieSceneAudio2FaceSection& Section, const class UMovieSceneAudio2FaceTrack& Track);

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
	virtual void Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void SetupOverrides() override { EnableOverrides(RequiresSetupFlag | RequiresTearDownFlag); }
};
