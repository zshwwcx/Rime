// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once
#include "MovieSceneMediaTrack.h"
#include "FullScreenMediaTrack.generated.h"

class FFullScreenMediaProxy;
class IMovieScenePlayer;

UCLASS()
class KGSTORYLINE_API UFullScreenMediaTrack : public UMovieSceneMediaTrack
{
	GENERATED_BODY()
public:
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;
	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;
	void SetUp(IMovieScenePlayer& Player, const UMovieSceneMediaSection* CustomSection) const;
	static void Seek(IMovieScenePlayer& Player, double CurrentTime);
	void TearDown(IMovieScenePlayer& Player);
	void SetRate(IMovieScenePlayer& Player, float X);
	float GetRate(IMovieScenePlayer& Player) const;
	void PreRoll(IMovieScenePlayer& Player);

	/** 参考对照视频 */
	UPROPERTY(EditAnywhere, Category = "FullScreenMedia")
	bool bReferenceMovie = false;

	UPROPERTY(EditAnywhere, Category = "FullScreenMedia")
	float SizePercent = 0.2f;

private:
	float Rate = 0;
};
