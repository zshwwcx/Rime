// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Math/Vector2D.h"
#include "Math/Vector.h"
#include "Math/Vector4.h"
#include "Math/Rotator.h"
#include "Math/Color.h"
#include "EulerTransform.h"
#include "Styling/SlateColor.h"
#include "EntitySystem/MovieSceneEntityIDs.h"
#include "EntitySystem/MovieSceneComponentDebug.h"
#include "Misc/LargeWorldCoordinates.h"
#include "MovieSceneTracksLookAtTypes.generated.h"

class USceneComponent;

class UMovieSceneLookAtSection;

struct FLookAt;


namespace UE
{
	namespace MovieScene
	{


		/** Intermediate type used for applying partially animated LookAt. Saves us from repteatedly recomposing quaternions from euler angles */
		struct FIntermediateLookAt
		{
			// When LWC is enabled, translations are manipulated as doubles.
			double E_X, E_Y, E_Z, H_X, H_Y, H_Z, B_X, B_Y, B_Z, Sp01_X, Sp01_Y, Sp01_Z, Sp02_X, Sp02_Y, Sp02_Z, Sp03_X, Sp03_Y, Sp03_Z;

			FIntermediateLookAt()
				: E_X(0.), E_Y(0.), E_Z(0.), H_X(0.), H_Y(0.), H_Z(0.), B_X(0.), B_Y(0.), B_Z(0.), Sp01_X(0.), Sp01_Y(0.), Sp01_Z(0.), Sp02_X(0.), Sp02_Y(0.), Sp02_Z(0.), Sp03_X(0.), Sp03_Y(0.), Sp03_Z(0.)
			{}

			FIntermediateLookAt(
				double InE_X, double InE_Y, double InE_Z, double InH_X, double InH_Y, double InH_Z, double InB_X, double InB_Y, double InB_Z, double InSp01_X, double InSp01_Y, double InSp01_Z, double InSp02_X, double InSp02_Y, double InSp02_Z, double InSp03_X, double InSp03_Y, double InSp03_Z)
				: E_X(InE_X), E_Y(InE_Y), E_Z(InE_Z), H_X(InH_X), H_Y(InH_Y), H_Z(InH_Z), B_X(InB_X), B_Y(InB_Y), B_Z(InB_Z), Sp01_X(InSp01_X), Sp01_Y(InSp01_Y), Sp01_Z(InSp01_Z), Sp02_X(InSp02_X), Sp02_Y(InSp02_Y), Sp02_Z(InSp02_Z), Sp03_X(InSp03_X), Sp03_Y(InSp03_Y), Sp03_Z(InSp03_Z)
			{}

			FIntermediateLookAt(const FRotator& InEye, const FRotator& InHead, const FRotator& InBody, const FRotator& InSp01, const FRotator& InSp02, const FRotator& InSp03)
				: E_X(InEye.Roll), E_Y(InEye.Pitch), E_Z(InEye.Yaw)
				, H_X(InHead.Roll), H_Y(InHead.Pitch), H_Z(InHead.Yaw)
				, B_X(InBody.Roll), B_Y(InBody.Pitch), B_Z(InBody.Yaw)
				, Sp01_X(InSp01.Roll), Sp01_Y(InSp01.Pitch), Sp01_Z(InSp01.Yaw)
				, Sp02_X(InSp02.Roll), Sp02_Y(InSp02.Pitch), Sp02_Z(InSp02.Yaw)
				, Sp03_X(InSp03.Roll), Sp03_Y(InSp03.Pitch), Sp03_Z(InSp03.Yaw)
			{}

			double operator[](int32 Index) const // cppcheck:ignore
			{
				check(Index >= 0 && Index < 18);
				return (&E_X)[Index];
			}

			FRotator GetEye() const
			{
				return FRotator(E_X, E_Y, 0);
			}

			FVector GetEyeScale() const
			{
				return FVector(E_Z, E_Z, E_Z);
			}
			FRotator GetHead() const
			{
				return FRotator(H_Y, H_Z, H_X);
			}
			FRotator GetBody() const
			{
				return FRotator(B_X, B_Y, B_Z);
			}
			FRotator GetSp01() const
			{
				return FRotator(Sp01_X, Sp01_Y, Sp01_Z);
			}
			FRotator GetSp02() const
			{
				return FRotator(Sp02_X, Sp02_Y, Sp02_Z);
			}
			FRotator GetSp03() const
			{
				return FRotator(Sp03_X, Sp03_Y, Sp03_Z);
			}
			KGSTORYLINE_API void ApplyTo(USceneComponent* SceneComponent) const;
			KGSTORYLINE_API static void ApplyTransformTo(USceneComponent* SceneComponent, const FIntermediateLookAt& Transform);
			KGSTORYLINE_API static void ApplyTranslationAndRotationTo(USceneComponent* SceneComponent, const FIntermediateLookAt& Transform);
		};


		KGSTORYLINE_API void ConvertOperationalProperty(const FIntermediateLookAt& In, FLookAt& Out);
		KGSTORYLINE_API void ConvertOperationalProperty(const FLookAt& In, FIntermediateLookAt& Out);

	} // namespace MovieScene
} // namespace UE


struct FLookAt
{

	friend Z_Construct_UScriptStruct_FTransform3f_Statics;
	friend Z_Construct_UScriptStruct_FTransform3d_Statics;
	friend Z_Construct_UScriptStruct_FTransform_Statics;

	using TransformVectorRegister = TVectorRegisterType<double>;

protected:
	/** Rotation of this transformation, as a quaternion */
	TPersistentVectorRegisterType<double> Eye;
	TPersistentVectorRegisterType<double> Head;
	TPersistentVectorRegisterType<double> Body;
	TPersistentVectorRegisterType<double> Spine_01;
	TPersistentVectorRegisterType<double> Spine_02;
	TPersistentVectorRegisterType<double> Spine_03;
public:
	/**
	 * The identity transformation (Rotation = TQuat<T>::Identity, Translation = TVector<T>::ZeroVector, Scale3D = (1,1,1))
	 */
	KGSTORYLINE_API static const FLookAt Identity;


	/**
	 * Constructor with initialization to the identity transform.
	 */
	FORCEINLINE FLookAt()
	{
		Eye = GlobalVectorConstants::Float0001;
		Head = GlobalVectorConstants::Float0001;
		Body = GlobalVectorConstants::Float0001;
		Spine_01 = GlobalVectorConstants::Float0001;
		Spine_02 = GlobalVectorConstants::Float0001;
		Spine_03 = GlobalVectorConstants::Float0001;
	}

	/**
	 * Constructor with all components initialized as VectorRegisters
	 *
	 * @param InRotation The value to use for rotation component
	 * @param InTranslation The value to use for the translation component
	 * @param InScale3D The value to use for the scale component
	 */
	FORCEINLINE FLookAt(const TransformVectorRegister& InEye, const TransformVectorRegister& InHead, const TransformVectorRegister& InBody, const TransformVectorRegister& InSpine_01, const TransformVectorRegister& InSpine_02, const TransformVectorRegister& InSpine_03)
		:Eye(InEye),
		Head(InHead),
		Body(InBody),
		Spine_01(InSpine_01),
		Spine_02(InSpine_02),
		Spine_03(InSpine_03)
	{
	}

	/**
	 * Returns the rotation component
	 *
	 * @return The rotation component
	 */
	FORCEINLINE VectorRegister4Double GetEye() const
	{
		VectorRegister4Double OutRotation;
		VectorStoreAligned(Eye, &OutRotation);
		return OutRotation;
	}

	/**
	 * Returns the rotation component
	 *
	 * @return The rotation component
	 */
	FORCEINLINE VectorRegister4Double GetHead() const
	{
		VectorRegister4Double OutRotation;
		VectorStoreAligned(Head, &OutRotation);
		return OutRotation;
	}

	/**
	 * Returns the rotation component
	 *
	 * @return The rotation component
	 */
	FORCEINLINE VectorRegister4Double GetBody() const
	{
		VectorRegister4Double OutRotation;
		VectorStoreAligned(Body, &OutRotation);
		return OutRotation;
	}

	/**
	 * Returns the rotation component
	 *
	 * @return The rotation component
	 */
	FORCEINLINE VectorRegister4Double GetSpine_01() const
	{
		VectorRegister4Double OutRotation;
		VectorStoreAligned(Spine_01, &OutRotation);
		return OutRotation;
	}

	/**
	 * Returns the rotation component
	 *
	 * @return The rotation component
	 */
	FORCEINLINE VectorRegister4Double GetSpine_02() const
	{
		VectorRegister4Double OutRotation;
		VectorStoreAligned(Spine_02, &OutRotation);
		return OutRotation;
	}

	/**
	 * Returns the rotation component
	 *
	 * @return The rotation component
	 */
	FORCEINLINE VectorRegister4Double GetSpine_03() const
	{
		VectorRegister4Double OutRotation;
		VectorStoreAligned(Spine_03, &OutRotation);
		return OutRotation;
	}
};


using namespace UE::MovieScene;

//using FLookAtPropertyTraits = TIndirectPropertyTraits<FLookAt, FIntermediateLookAt>;

USTRUCT()
struct FMovieSceneLookAtData
{
	GENERATED_BODY()

	UPROPERTY()
	TObjectPtr<UMovieSceneLookAtSection> Section = nullptr;
};

namespace UE
{
	namespace MovieScene
	{
		struct FMovieSceneTracksLookAtTypes
		{
			KGSTORYLINE_API ~FMovieSceneTracksLookAtTypes();

			//TPropertyComponents<FLookAtPropertyTraits> LookAt;

			TComponentTypeID<FMovieSceneLookAtData> LookAt;

			static KGSTORYLINE_API void Destroy();

			static KGSTORYLINE_API FMovieSceneTracksLookAtTypes* Get();

		private:
			FMovieSceneTracksLookAtTypes();
		};

	}
}

