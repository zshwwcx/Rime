#pragma once

#include "CoreMinimal.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "CutScene/MovieSceneQTETrack.h"
#include "MovieSceneQTETemplate.generated.h"

class UMovieSceneQTETrack;
class UMovieSceneQTESection;


USTRUCT()
struct FMovieSceneQTETemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()

	FMovieSceneQTETemplate();
	FMovieSceneQTETemplate(const UMovieSceneQTESection& Section, const UMovieSceneQTETrack& Track);

private:
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
	virtual void Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void SetupOverrides() override { EnableOverrides(RequiresSetupFlag | RequiresTearDownFlag); }
};
