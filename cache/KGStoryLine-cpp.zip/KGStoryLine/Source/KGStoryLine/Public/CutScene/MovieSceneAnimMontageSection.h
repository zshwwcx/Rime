﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MovieSceneSection.h"
#include "Animation/AnimMontage.h"
#include "EntitySystem/IMovieSceneEntityProvider.h"
#include "MovieSceneAnimMontageSection.generated.h"


USTRUCT(BlueprintType)
struct FMovieSceneAnimMontageParams
{
	GENERATED_BODY()

	FMovieSceneAnimMontageParams();

	/** Gets the animation duration, modified by play rate */
	float GetDuration() const { return FMath::IsNearlyZero(PlayRate) || AnimMontage == nullptr ? 0.f : AnimMontage->GetPlayLength() / PlayRate; }

	/** Gets the animation sequence length, not modified by play rate */
	float GetSequenceLength() const { return AnimMontage != nullptr ? AnimMontage->GetPlayLength() : 0.f; }
	
	/**
    * Convert a sequence frame to a time in seconds inside the animation clip, taking into account start/end offsets,
    * looping, etc.
    */
	double MapTimeToAnimation(const UMovieSceneSection* InSection, FFrameTime InPosition, FFrameRate InFrameRate) const;

	/**
	* As above, but with already computed section bounds.
	*/
	double MapTimeToAnimation(FFrameNumber InSectionStartTime, FFrameNumber InSectionEndTime, FFrameTime InPosition, FFrameRate InFrameRate) const;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category="Animation", meta=(AllowedClasses = "/Script/Engine.AnimMontage"))
	TObjectPtr<UAnimMontage> AnimMontage;

	/** The offset into the beginning of the animation clip for the first loop of play. */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category="Animation")
	FFrameNumber FirstLoopStartFrameOffset;

	/** The offset into the beginning of the animation clip */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category="Animation")
	FFrameNumber StartFrameOffset;

	/** The offset into the end of the animation clip */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category="Animation")
	FFrameNumber EndFrameOffset;

	/** The playback rate of the animation clip */
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category="Animation")
	float PlayRate;
};
/**
 * 
 */
UCLASS()
class KGSTORYLINE_API UMovieSceneAnimMontageSection :
	public UMovieSceneSection, public IMovieSceneEntityProvider
{
	GENERATED_BODY()

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Animation", meta = (ShowOnlyInnerProperties))
	FMovieSceneAnimMontageParams Params;

	double MapTimeToAnimation(FFrameTime InPosition, FFrameRate InFrameRate) const;
	
	virtual void ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& InParams, FImportedEntity* OutImportedEntity) override;
};
