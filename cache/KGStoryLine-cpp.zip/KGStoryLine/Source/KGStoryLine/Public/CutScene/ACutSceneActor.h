// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/StreamableManager.h"
#include "3C/Character/BaseCharacter.h"
#include "ACutSceneActor.generated.h"

UCLASS()
class KGSTORYLINE_API ACutSceneActor : public ABaseCharacter
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ACutSceneActor();

	/**
	 * Gets the property name for Eye.
	 *
	 * This exists so subclasses don't need to have direct access to the Eye property so it
	 * can be made private later.
	 */
	static const FName GetRelativeEyePropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ACutSceneActor, Eye);
	}


	/**
	 * Gets the property name for EyeScale.
	 *
	 * This exists so subclasses don't need to have direct access to the EyeScale property so it
	 * can be made private later.
	 */
	static const FName GetRelativeEyeScalePropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ACutSceneActor, EyeScale);
	}


	/**
	 * Gets the property name for Head.
	 *
	 * This exists so subclasses don't need to have direct access to the Head property so it
	 * can be made private later.
	 */
	static const FName GetRelativeHeadPropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ACutSceneActor, Head);
	}

	/**
	 * Gets the property name for Body.
	 *
	 * This exists so subclasses don't need to have direct access to the Body property so it
	 * can be made private later.
	 */
	static const FName GetRelativeBodyPropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ACutSceneActor, Body);
	}

	/**
	 * Gets the property name for Spine_01.
	 *
	 * This exists so subclasses don't need to have direct access to the Spine_01 property so it
	 * can be made private later.
	 */
	static const FName GetRelativeSpine_01PropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ACutSceneActor, Spine_01);
	}

	/**
	 * Gets the property name for Spine_02.
	 *
	 * This exists so subclasses don't need to have direct access to the Spine_02 property so it
	 * can be made private later.
	 */
	static const FName GetRelativeSpine_02PropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ACutSceneActor, Spine_02);
	}

	/**
	 * Gets the property name for Spine_03.
	 *
	 * This exists so subclasses don't need to have direct access to the Spine_03 property so it
	 * can be made private later.
	 */
	static const FName GetRelativeSpine_03PropertyName()
	{
		return GET_MEMBER_NAME_CHECKED(ACutSceneActor, Spine_03);
	}
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason);

public:	
	// Called every frame
	//virtual void Tick(float DeltaTime) override;
	
	void UpdateProperty();
	
	FRotator GetEye() const
	{
		return Eye;
	};

	FVector GetEyeScale() const
	{
		//UE_LOG(LogTemp, Warning, TEXT("ACutSceneActor GetEyeScale => Eye:%f %f %f "), EyeScale.X, EyeScale.Y, EyeScale.Z);
		return EyeScale;
	};
	FRotator GetHead() const 
	{
		return Head;
	};
	FRotator GetBody() const 
	{	
		return Body;
	};

	FRotator GetSpine_01() const
	{
		return Spine_01;
	};

	FRotator GetSpine_02() const
	{
		return Spine_02;
	};

	FRotator GetSpine_03() const
	{
		return Spine_03;
	};

	void SetEye(FRotator InEye)
	{
		Eye = InEye;
	};

	void SetEyeScale(FVector InScale)
	{
		//UE_LOG(LogTemp, Warning, TEXT("ACutSceneActor SetEyeScale => Eye:%f %f %f "), InScale.X, InScale.Y, InScale.Z);
		EyeScale = InScale;
	};

	void SetHead(FRotator InHead)
	{
		Head = InHead;
	};
	void SetBody(FRotator InBody)
	{
		Body = InBody;
	};

	void SetSpine_01(FRotator InSpine_01)
	{
		Spine_01 = InSpine_01;
	};

	void SetSpine_02(FRotator InSpine_02)
	{
		Spine_02 = InSpine_02;
	};

	void SetSpine_03(FRotator InSpine_03)
	{
		Spine_03 = InSpine_03;
	};
private:
	/** Rotation of the Eye relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))
	FRotator Eye;

	/** Scale of the Eye relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))
	FVector EyeScale;

	/** Rotation of the Head relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))
	FRotator Head;

	/** Rotation of the Body relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))
	FRotator Body;

	/** Rotation of the spine_01 relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))
	FRotator Spine_01;

	/** Rotation of the spine_02 relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))
	FRotator Spine_02;

	/** Rotation of the spine_03 relative to its parent */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = LookAt, meta = (AllowPrivateAccess = "true", UIMin = "0.0", UIMax = "359.999"))
	FRotator Spine_03;
};
