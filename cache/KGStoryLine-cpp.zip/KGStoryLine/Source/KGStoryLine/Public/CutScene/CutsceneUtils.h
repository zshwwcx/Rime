// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "LevelSequence.h"
#include "MovieScene.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "CutsceneUtils.generated.h"

class UMaterialInterface;
class UPrimitiveComponent;
/**
 * 
 */
UCLASS()
class KGSTORYLINE_API UCutsceneUtils : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/**
	 * CGDev测试BP中使用的接口 (仅支持Editor调用)
	 * @param InSequence 
	 * @return 
	 */
	UFUNCTION(BlueprintCallable)
	static float GetLevelSequenceLengthInEditor(ULevelSequence* InSequence)
	{
		float Length = 0.f;
		
#if WITH_EDITOR
		UMovieScene* MovieScene = InSequence->GetMovieScene();
		if (!IsValid(InSequence) || !IsValid(MovieScene))
		{
			return Length;
		}

		const TRange<FFrameNumber> PlayRange = MovieScene->GetPlaybackRange();
		const FFrameRate TickResolution = MovieScene->GetTickResolution();

		Length = (PlayRange.GetUpperBoundValue() - PlayRange.GetLowerBoundValue()) / TickResolution;
#endif

		return Length;
	}

	static void ForEachMaterialOnComponentBySlotName(UPrimitiveComponent* PrimitiveComponent, FText SlotName, TFunctionRef<void(UMaterialInterface*)> ProcessFunction);
};
