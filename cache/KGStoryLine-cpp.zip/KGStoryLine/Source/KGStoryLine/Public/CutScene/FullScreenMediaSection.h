// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "Channels/MovieSceneFloatChannel.h"
#include "MovieSceneMediaSection.h"
#include "FullScreenMediaSection.generated.h"

class UMediaPlayer;
class UMovieSceneMediaSection;
class UMovieSceneMediaTrack;
class UMediaSoundComponent;
class UMediaSource;
class UMediaTexture;

USTRUCT()
struct KGSTORYLINE_API FFullScreenMediaSectionParams
{
	GENERATED_BODY()

	UPROPERTY()
	TObjectPtr<UMediaSoundComponent> MediaSoundComponent;

	UPROPERTY()
	TObjectPtr<UMediaSource> MediaSource;

	UPROPERTY()
	FMovieSceneObjectBindingID MediaSourceProxy;

	UPROPERTY()
	int32 MediaSourceProxyIndex;

	UPROPERTY()
	TObjectPtr<UMediaTexture> MediaTexture;

	UPROPERTY()
	TObjectPtr<UMediaPlayer> MediaPlayer;

	UPROPERTY()
	FFrameNumber SectionStartFrame;

	UPROPERTY()
	FFrameNumber SectionEndFrame;

	UPROPERTY()
	bool bLooping;

	UPROPERTY()
	FFrameNumber StartFrameOffset;

	UPROPERTY()
	FMovieSceneFloatChannel ProxyTextureBlend;

	FFullScreenMediaSectionParams()
		: MediaSoundComponent(nullptr)
		, MediaSource(nullptr)
		, MediaSourceProxyIndex(0)
		, MediaTexture(nullptr)
		, MediaPlayer(nullptr)
		, bLooping(false)
	{
	}
};

USTRUCT()
struct KGSTORYLINE_API FFullScreenMediaSectionTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()

	FFullScreenMediaSectionTemplate() = default;
	FFullScreenMediaSectionTemplate(const UMovieSceneMediaSection& InSection, const UMovieSceneMediaTrack& InTrack);

	//~ FMovieSceneEvalTemplate interface
	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	
	/** 确定这个Eval中需要那些流程: Setup/Initialize/TearDown */
	virtual void SetupOverrides() override;

	virtual void Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;

	/** 处理每一帧 */
	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;
	
private:
	UPROPERTY()
	FFullScreenMediaSectionParams Params;

	UPROPERTY()
	TObjectPtr<const UMovieSceneMediaSection> MediaSection;
};
