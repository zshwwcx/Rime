#pragma once
#include "Tracks/MovieSceneSpawnTrack.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "MovieSceneNameableTrack.h"
#include "LuaOverriderInterface.h"
#include "CutScene/MovieSceneCustomSection.h"
#include "MovieSceneCustomTrack.generated.h"

class UKGSequenceManager;

UCLASS()
class KGSTORYLINE_API UMovieSceneCustomTrack : public UMovieSceneNameableTrack, public IMovieSceneTrackTemplateProducer
{
	GENERATED_BODY()
public:
	UMovieSceneCustomTrack(const FObjectInitializer& ObjectInitializer);
	virtual ~UMovieSceneCustomTrack() override;

public:
	virtual void AddSection(UMovieSceneSection& Section) override;
	virtual UMovieSceneSection* CreateNewSection() override;
	virtual const TArray<UMovieSceneSection*>& GetAllSections() const override;
	virtual bool HasSection(const UMovieSceneSection& Section) const override;
	virtual bool IsEmpty() const override;
	virtual void RemoveSection(UMovieSceneSection& Section) override;
	virtual void RemoveSectionAt(int32 SectionIndex) override;
	virtual FName GetTrackName() const override;
#if WITH_EDITORONLY_DATA
	virtual FText GetDefaultDisplayName() const override;
#endif
	virtual bool SupportsMultipleRows() const override;
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;

	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;

	void Execute(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, float CurrentTime, IMovieScenePlayer& Player);

	void SetUp(const UMovieSceneCustomSection* MovieSceneCustomSection, IMovieScenePlayer& Player);

	void TearDown(const UMovieSceneCustomSection* MovieSceneCustomSection,  AActor* InActor, IMovieScenePlayer& Player);

	static UKGSequenceManager* GetSequenceManager(IMovieScenePlayer& Player);
	UPROPERTY(Transient)
	TWeakObjectPtr<AActor> Actor;

private:
	UPROPERTY()
	TArray<TObjectPtr<UMovieSceneSection>> Sections;
};
