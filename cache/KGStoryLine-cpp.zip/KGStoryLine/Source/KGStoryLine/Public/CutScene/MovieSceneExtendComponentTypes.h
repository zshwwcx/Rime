﻿#pragma once
#include "EntitySystem/MovieSceneEntityIDs.h"
#include "MovieSceneExtendComponentTypes.generated.h"

class UMovieSceneAnimMontageSection;

USTRUCT()
struct FMovieSceneAnimMontageComponentData
{
	GENERATED_BODY()

	UPROPERTY()
	TObjectPtr<UMovieSceneAnimMontageSection> Section = nullptr;
};

namespace UE
{
namespace MovieScene
{
	struct FMovieSceneExtendComponentTypes
	{
		KGSTORYLINE_API ~FMovieSceneExtendComponentTypes();

		TComponentTypeID<FMovieSceneAnimMontageComponentData> AnimMontage;

		static KGSTORYLINE_API void Destroy();

		static KGSTORYLINE_API FMovieSceneExtendComponentTypes* Get();
		
	private:
		FMovieSceneExtendComponentTypes();
	};
	
}
}

