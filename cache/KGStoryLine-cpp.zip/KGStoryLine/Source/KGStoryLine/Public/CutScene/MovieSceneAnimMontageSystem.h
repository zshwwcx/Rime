// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectKey.h"
#include "EntitySystem/MovieSceneEntitySystem.h"
#include "MovieSceneAnimMontageSystem.generated.h"

class UMovieSceneAnimMontageSection;
/**
 * 
 */
namespace UE::MovieScene
{
	/** Information for a single skeletal animation playing on a bound object */
	struct FActiveAnimMontages
	{
		TWeakObjectPtr<const UMovieSceneAnimMontageSection> AnimSection;
		FMovieSceneContext Context;
		FMovieSceneEntityID EntityID;
		FRootInstanceHandle RootInstanceHandle;
		float FromEvalTime;
		float ToEvalTime;
		EMovieScenePlayerStatus::Type PlayerStatus;
		uint8 bFireNotifies : 1;
		uint8 bPlaying : 1;
		uint8 bResetDynamics : 1;
		uint8 bWantsRestoreState : 1;
		uint8 bPreviewPlayback : 1;
	};
	
	struct FBoundObjectActiveAnimMontages
	{
		using FAnimationArray = TArray<FActiveAnimMontages, TInlineAllocator<2>>;

		FAnimationArray AnimMontages;
	};
	
	struct FMontagePlayerPerSectionData 
	{
		int32 MontageInstanceId;
	};
	
	struct FAnimMontageSystemData
	{
		void ResetAnimMontages()
		{
			SkeletalAnimations.Reset();
		}

		/** Map of active skeletal animations for each bound object */
		TMap<TWeakObjectPtr<USkeletalMeshComponent>, FBoundObjectActiveAnimMontages> SkeletalAnimations;

		/** Map of persistent montage data */
		TMap<FObjectKey, TMap<FObjectKey, FMontagePlayerPerSectionData>> MontageData;
	};
}

UCLASS()
class KGSTORYLINE_API UMovieSceneAnimMontageSystem : public UMovieSceneEntitySystem
{
	GENERATED_BODY()

public:

	UMovieSceneAnimMontageSystem(const FObjectInitializer& ObjectInitializer);

private:

	virtual void OnSchedulePersistentTasks(UE::MovieScene::IEntitySystemScheduler* TaskScheduler) override;
	
	virtual void OnRun(FSystemTaskPrerequisites& InPrerequisites, FSystemSubsequentTasks& Subsequents) override final;

	UE::MovieScene::FAnimMontageSystemData SystemData;
};
