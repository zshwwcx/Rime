// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#pragma once

#include "EntitySystem/MovieSceneEntitySystem.h"
#include "MovieSceneBatchMaterialParameterSystem.generated.h"

/**
 * System responsible for animating batch material parameter entities.
 *
 * Visits any material on actor's all primitive components with the supported parameter names 
 * and applies the resulting parameter to the materials.
 * don't support saving animating state for now.
 */
UCLASS(MinimalAPI)
class UMovieSceneBatchMaterialParameterEvaluationSystem : public UMovieSceneEntitySystem
{
public:
	GENERATED_BODY()
	
	UMovieSceneBatchMaterialParameterEvaluationSystem(const FObjectInitializer& ObjInit);

private:
	
	virtual void OnSchedulePersistentTasks(UE::MovieScene::IEntitySystemScheduler* TaskScheduler) override;
	virtual void OnRun(FSystemTaskPrerequisites& InPrerequisites, FSystemSubsequentTasks& Subsequents) override;
};
