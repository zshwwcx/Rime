#pragma once

#include "CoreMinimal.h"
#include "MovieSceneNameableTrack.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "MovieSceneResizeBoundsTrack.generated.h"

UCLASS()
class KGSTORYLINE_API UMovieSceneResizeBoundsTrack : public UMovieSceneNameableTrack, public IMovieSceneTrackTemplateProducer
{
	GENERATED_BODY()

public:
	UMovieSceneResizeBoundsTrack(const FObjectInitializer& ObjectInitializer);
	
	virtual void AddSection(UMovieSceneSection& Section) override;
	virtual UMovieSceneSection* CreateNewSection() override;
	virtual const TArray<UMovieSceneSection*>& GetAllSections() const override;
	virtual bool HasSection(const UMovieSceneSection& Section) const override;
	virtual bool IsEmpty() const override;
	virtual void RemoveSectionAt(int32 SectionIndex) override;
	virtual void RemoveSection(UMovieSceneSection& Section) override;
	virtual FName GetTrackName() const override;
	virtual bool SupportsMultipleRows() const override;
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;
#if WITH_EDITORONLY_DATA
	virtual FText GetDefaultDisplayName() const override;
#endif

	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;
	
private:
	UPROPERTY()
	TArray<UMovieSceneSection*> Sections;
};
