// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Channels/MovieSceneFloatChannel.h"
#include "Channels/MovieSceneDoubleChannel.h"
#include "CoreMinimal.h"
#include "MovieSceneSection.h"
#include "Sections/MovieSceneConstrainedSection.h"
#include "MovieSceneKeyStruct.h"
#include "Sections/MovieSceneFloatSection.h"
#include "Channels/IMovieSceneChannelOverrideProvider.h"
#include "EntitySystem/IMovieSceneEntityProvider.h"
#include "ConstraintsManager.h"
#include "ConstraintChannel.h"
#include "UObject/ObjectMacros.h"
#include "UObject/UObjectGlobals.h"
#include "UObject/ObjectSaveContext.h"
#include "MovieSceneLookAtSection.generated.h"

class UObject;

#if WITH_EDITORONLY_DATA
/** Visibility options for lookat trajectory. */
UENUM()
enum class EShowLookAtTrajectory : uint8
{
	EST_OnlyWhenSelected UMETA(DisplayName = "Only When Selected"),
	EST_Always UMETA(DisplayName = "Always"),
	EST_Never UMETA(DisplayName = "Never"),
};
#endif


/**
 * Proxy structure for translation keys in 3D transform sections.
 */
USTRUCT()
struct FMovieSceneEyeKeyStruct
	: public FMovieSceneKeyStruct
{
	GENERATED_BODY()

	/** The key's rotation value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Eye = FRotator::ZeroRotator;

	/** The key's time. */
	UPROPERTY(EditAnywhere, Category = Key)
	FFrameNumber Time;

	FMovieSceneKeyStructHelper KeyStructInterop;

	virtual void PropagateChanges(const FPropertyChangedEvent& ChangeEvent) override;
};
template<> struct TStructOpsTypeTraits<FMovieSceneEyeKeyStruct> : public TStructOpsTypeTraitsBase2<FMovieSceneEyeKeyStruct> { enum { WithCopy = false }; };


/**
 * Proxy structure for translation keys in 3D transform sections.
 */
USTRUCT()
struct FMovieSceneHeadKeyStruct
	: public FMovieSceneKeyStruct
{
	GENERATED_BODY()

	/** The key's rotation value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Head = FRotator::ZeroRotator;

	/** The key's time. */
	UPROPERTY(EditAnywhere, Category = Key)
	FFrameNumber Time;

	FMovieSceneKeyStructHelper KeyStructInterop;

	virtual void PropagateChanges(const FPropertyChangedEvent& ChangeEvent) override;
};
template<> struct TStructOpsTypeTraits<FMovieSceneHeadKeyStruct> : public TStructOpsTypeTraitsBase2<FMovieSceneHeadKeyStruct> { enum { WithCopy = false }; };

/**
 * Proxy structure for translation keys in 3D transform sections.
 */
USTRUCT()
struct FMovieSceneBodyKeyStruct
	: public FMovieSceneKeyStruct
{
	GENERATED_BODY()

	/** The key's rotation value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Body = FRotator::ZeroRotator;

	/** The key's time. */
	UPROPERTY(EditAnywhere, Category = Key)
	FFrameNumber Time;

	FMovieSceneKeyStructHelper KeyStructInterop;

	virtual void PropagateChanges(const FPropertyChangedEvent& ChangeEvent) override;
};
template<> struct TStructOpsTypeTraits<FMovieSceneBodyKeyStruct> : public TStructOpsTypeTraitsBase2<FMovieSceneBodyKeyStruct> { enum { WithCopy = false }; };


/**
 * Proxy structure for translation keys in 3D transform sections.
 */
USTRUCT()
struct FMovieSceneSpine_01KeyStruct
	: public FMovieSceneKeyStruct
{
	GENERATED_BODY()

	/** The key's rotation value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Spine_01 = FRotator::ZeroRotator;

	/** The key's time. */
	UPROPERTY(EditAnywhere, Category = Key)
	FFrameNumber Time;

	FMovieSceneKeyStructHelper KeyStructInterop;

	virtual void PropagateChanges(const FPropertyChangedEvent& ChangeEvent) override;
};
template<> struct TStructOpsTypeTraits<FMovieSceneSpine_01KeyStruct> : public TStructOpsTypeTraitsBase2<FMovieSceneSpine_01KeyStruct> { enum { WithCopy = false }; };

/**
 * Proxy structure for translation keys in 3D transform sections.
 */
USTRUCT()
struct FMovieSceneSpine_02KeyStruct
	: public FMovieSceneKeyStruct
{
	GENERATED_BODY()

	/** The key's rotation value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Spine_02 = FRotator::ZeroRotator;

	/** The key's time. */
	UPROPERTY(EditAnywhere, Category = Key)
	FFrameNumber Time;

	FMovieSceneKeyStructHelper KeyStructInterop;

	virtual void PropagateChanges(const FPropertyChangedEvent& ChangeEvent) override;
};
template<> struct TStructOpsTypeTraits<FMovieSceneSpine_02KeyStruct> : public TStructOpsTypeTraitsBase2<FMovieSceneSpine_02KeyStruct> { enum { WithCopy = false }; };

/**
 * Proxy structure for translation keys in 3D transform sections.
 */
USTRUCT()
struct FMovieSceneSpine_03KeyStruct
	: public FMovieSceneKeyStruct
{
	GENERATED_BODY()

	/** The key's rotation value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Spine_03 = FRotator::ZeroRotator;

	/** The key's time. */
	UPROPERTY(EditAnywhere, Category = Key)
	FFrameNumber Time;

	FMovieSceneKeyStructHelper KeyStructInterop;

	virtual void PropagateChanges(const FPropertyChangedEvent& ChangeEvent) override;
};
template<> struct TStructOpsTypeTraits<FMovieSceneSpine_03KeyStruct> : public TStructOpsTypeTraitsBase2<FMovieSceneSpine_03KeyStruct> { enum { WithCopy = false }; };

/**
 * Proxy structure for 3D transform section key data.
 */
USTRUCT()
struct FMovieSceneLookAtKeyStruct
	: public FMovieSceneKeyStruct
{
	GENERATED_BODY()

	/** The key's translation value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Eye = FRotator::ZeroRotator;

	/** The key's rotation value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Head = FRotator::ZeroRotator;

	/** The key's scale value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Body = FRotator::ZeroRotator;

	/** The key's scale value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Spine_01 = FRotator::ZeroRotator;

	/** The key's scale value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Spine_02 = FRotator::ZeroRotator;

	/** The key's scale value. */
	UPROPERTY(EditAnywhere, Category = Key)
	FRotator Spine_03 = FRotator::ZeroRotator;

	/** The key's time. */
	UPROPERTY(EditAnywhere, Category = Key)
	FFrameNumber Time;

	FMovieSceneKeyStructHelper KeyStructInterop;

	virtual void PropagateChanges(const FPropertyChangedEvent& ChangeEvent) override;
};
template<> struct TStructOpsTypeTraits<FMovieSceneLookAtKeyStruct> : public TStructOpsTypeTraitsBase2<FMovieSceneLookAtKeyStruct> { enum { WithCopy = false }; };


/**
* Defines for common transform 'type' sections. Moved here to avoid extra module dependencies
*/
enum class EMovieSceneLookAtChannel : uint32
{
	None = 0x000,

	EyeX = 0x001,
	EyeY = 0x002,
	EyeZ = 0x004,
	Eye = EyeX | EyeY | EyeZ,

	HeadX = 0x008,
	HeadY = 0x010,
	HeadZ = 0x020,
	Head = HeadX | HeadY | HeadZ,

	BodyX = 0x040,
	BodyY = 0x080,
	BodyZ = 0x100,
	Body = BodyX | BodyY | BodyZ,

	Spine_01X = 0x200,
	Spine_01Y = 0x400,
	Spine_01Z = 0x800,
	Spine_01 = Spine_01X | Spine_01Y | Spine_01Z,

	Spine_02X = 0x1000,
	Spine_02Y = 0x2000,
	Spine_02Z = 0x4000,
	Spine_02 = Spine_02X | Spine_02Y | Spine_02Z,

	Spine_03X = 0x8000,
	Spine_03Y = 0x10000,
	Spine_03Z = 0x20000,
	Spine_03 = Spine_03X | Spine_03Y | Spine_03Z,

	AllTransform = Eye | Head | Body | Spine_01 | Spine_02 | Spine_03,

	Weight = 0x40000,

	All = Eye | Head | Body | Spine_01 | Spine_02 | Spine_03 | Weight,
};
ENUM_CLASS_FLAGS(EMovieSceneLookAtChannel)

USTRUCT()
struct FMovieSceneLookAtMask
{
	GENERATED_BODY()

	FMovieSceneLookAtMask()
		: Mask(0)
	{}

	FMovieSceneLookAtMask(EMovieSceneLookAtChannel Channel)
		: Mask((__underlying_type(EMovieSceneLookAtChannel))Channel)
	{}

	EMovieSceneLookAtChannel GetChannels() const
	{
		return (EMovieSceneLookAtChannel)Mask;
	}

	FVector GetEyeFactor() const
	{
		EMovieSceneLookAtChannel Channels = GetChannels();
		return FVector(
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::EyeX) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::EyeY) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::EyeZ) ? 1.f : 0.f);
	}

	FVector GetHeadFactor() const
	{
		EMovieSceneLookAtChannel Channels = GetChannels();
		return FVector(
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::HeadX) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::HeadY) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::HeadZ) ? 1.f : 0.f);
	}

	FVector GetBodyFactor() const
	{
		EMovieSceneLookAtChannel Channels = GetChannels();
		return FVector(
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::BodyX) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::BodyY) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::BodyZ) ? 1.f : 0.f);
	}

	FVector GetSpine_01Factor() const
	{
		EMovieSceneLookAtChannel Channels = GetChannels();
		return FVector(
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::Spine_01X) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::Spine_01Y) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::Spine_01Z) ? 1.f : 0.f);
	}

	FVector GetSpine_02Factor() const
	{
		EMovieSceneLookAtChannel Channels = GetChannels();
		return FVector(
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::Spine_02X) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::Spine_02Y) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::Spine_02Z) ? 1.f : 0.f);
	}

	FVector GetSpine_03Factor() const
	{
		EMovieSceneLookAtChannel Channels = GetChannels();
		return FVector(
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::Spine_03X) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::Spine_03Y) ? 1.f : 0.f,
			EnumHasAllFlags(Channels, EMovieSceneLookAtChannel::Spine_03Z) ? 1.f : 0.f);
	}
private:

	UPROPERTY()
	uint32 Mask;
};

/**
* This object contains information needed for constraint channels on the transform section
*/
UCLASS(MinimalAPI)
class UMovieSceneLookAtSectionConstraints : public UObject
{
	GENERATED_BODY()

public:

	/** Constraint Channels*/
	UPROPERTY()
	TArray<FConstraintAndActiveChannel> ConstraintsChannels;

	/** When undo/redoing we need to recreate channel proxies after we are done*/
#if WITH_EDITOR
	KGSTORYLINE_API virtual void PostEditUndo() override;
#endif
};


/**
 * A single floating point section.
 */
UCLASS(MinimalAPI)
class UMovieSceneLookAtSection
	: public UMovieSceneSection
	, public IMovieSceneConstrainedSection
	, public IMovieSceneEntityProvider
	, public IMovieSceneChannelOverrideProvider
{
	GENERATED_UCLASS_BODY()

public:
#if WITH_EDITOR
		/* From UObject*/
		virtual bool Modify(bool bAlwaysMarkDirty = true) override;
		virtual void PostDuplicate(bool bDuplicateForPIE) override;
#endif
		/* From UMovieSection*/

		KGSTORYLINE_API virtual bool ShowCurveForChannel(const void* ChannelPtr) const override;
		KGSTORYLINE_API virtual void SetBlendType(EMovieSceneBlendType InBlendType) override;
		KGSTORYLINE_API virtual void OnBindingIDsUpdated(const TMap<UE::MovieScene::FFixedObjectBindingID, UE::MovieScene::FFixedObjectBindingID>& OldFixedToNewFixedMap, FMovieSceneSequenceID LocalSequenceID, TSharedRef<UE::MovieScene::FSharedPlaybackState> SharedPlaybackState) override;
		KGSTORYLINE_API virtual void GetReferencedBindings(TArray<FGuid>& OutBindings) override;
		KGSTORYLINE_API virtual void PreSave(FObjectPreSaveContext SaveContext) override;

#if WITH_EDITOR
		KGSTORYLINE_API virtual void PostPaste() override;
#endif
	
		/**
		 * Access the mask that defines which channels this track should animate
		 */
		KGSTORYLINE_API FMovieSceneLookAtMask GetMask() const;


		/**
		 * Set the mask that defines which channels this track should animate
		 */
		KGSTORYLINE_API void SetMask(FMovieSceneLookAtMask NewMask);

		/**
		 * Get the mask by name
		 */
		KGSTORYLINE_API FMovieSceneLookAtMask GetMaskByName(const FName& InName) const;

		/**
		* Get whether we should use quaternion interpolation for our rotations.
		*/
		KGSTORYLINE_API bool GetUseQuaternionInterpolation() const;

		/**
		* Set whether we should use quaternion interpolation for our rotations.
		*/
		KGSTORYLINE_API void SetUseQuaternionInterpolation(bool bInUseQuaternionInterpolation);

protected:

	KGSTORYLINE_API virtual TSharedPtr<FStructOnScope> GetKeyStruct(TArrayView<const FKeyHandle> KeyHandles) override;
	KGSTORYLINE_API virtual EMovieSceneChannelProxyType CacheChannelProxy() override;

private:

	KGSTORYLINE_API virtual bool PopulateEvaluationFieldImpl(const TRange<FFrameNumber>& EffectiveRange, const FMovieSceneEvaluationFieldEntityMetaData& InMetaData, FMovieSceneEntityComponentFieldBuilder* OutFieldBuilder) override;
	KGSTORYLINE_API virtual void ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity) override;
	KGSTORYLINE_API virtual void InterrogateEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity) override;

	template<typename BaseBuilderType>
	void BuildEntity(BaseBuilderType& InBaseBuilder, UMovieSceneEntitySystemLinker* Linker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity);
	void PopulateConstraintEntities(const TRange<FFrameNumber>& EffectiveRange, const FMovieSceneEvaluationFieldEntityMetaData& InMetaData, FMovieSceneEntityComponentFieldBuilder* OutFieldBuilder);
	void ImportConstraintEntity(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity);

	private:
		static UE::MovieScene::FChannelOverrideNames ChannelOverrideNames;

		UMovieSceneSectionChannelOverrideRegistry* GetChannelOverrideRegistry(bool bCreateIfMissing) override;
		UE::MovieScene::FChannelOverrideProviderTraitsHandle GetChannelOverrideProviderTraits() const override;
		void OnChannelOverridesChanged() override;

public:
	// cppcheck:push ignore
	UPROPERTY()
	FMovieSceneLookAtMask LookAtMask;
	/** Float data */
	UPROPERTY()
	FMovieSceneDoubleChannel Eye[3];

	UPROPERTY()
	FMovieSceneDoubleChannel Head[3];

	UPROPERTY()
	FMovieSceneDoubleChannel Body[3];

	UPROPERTY()
	FMovieSceneDoubleChannel Spine_01[3];

	UPROPERTY()
	FMovieSceneDoubleChannel Spine_02[3];

	UPROPERTY()
	FMovieSceneDoubleChannel Spine_03[3];

	/** Manual weight curve */
	UPROPERTY()
	FMovieSceneFloatChannel ManualWeight;

	/** Optional pointer to a "channels override" container object. This object would only be allocated if any channels are overridden with a non-standard channel 	*/
	UPROPERTY()
	TObjectPtr<UMovieSceneSectionChannelOverrideRegistry> OverrideRegistry;

	/** Optional pointer to constraint channels*/
	UPROPERTY()
	TObjectPtr<UMovieSceneLookAtSectionConstraints> Constraints;

	/** Whether to use a quaternion linear interpolation between keys. This finds the 'shortest' rotation between keyed orientations. */
	UPROPERTY(EditAnywhere, DisplayName = "Use Quaternion Interpolation", Category = "Rotation")
	bool bUseQuaternionInterpolation;
	// cppcheck:pop
	public:
		//IMovieSceneConstrainedSection overrides

		/*
		* If it has that constraint with that Name
		*/
		virtual  bool HasConstraintChannel(const FGuid& InGuid) const override;

		/*
		* Get constraint with that name
		*/
		virtual FConstraintAndActiveChannel* GetConstraintChannel(const FGuid& InGuid) override;

		/*
		*  Add Constraint channel
		*/
		virtual void AddConstraintChannel(UTickableConstraint* InConstraint) override;

		/*
		*  Remove Constraint channel
		*/
		virtual void RemoveConstraintChannel(const UTickableConstraint* InConstraint) override;

		/*
		*  Get The channels by value
		*/
		virtual TArray<FConstraintAndActiveChannel>& GetConstraintsChannels()  override;

		/*
		*  Replace the constraint with the specified name with the new one
		*/
		virtual void ReplaceConstraint(const FName InConstraintName, UTickableConstraint* InConstraint)  override;

		/*
		* Clear proxy if changed
		*/
		virtual void OnConstraintsChanged() override;

#if WITH_EDITORONLY_DATA

public:

	/**
	 * Return the trajectory visibility
	 */
	EShowLookAtTrajectory GetLookAtTrajectory() const { return Show3DTrajectory; }

	/**
	 * Return the trajectory visibility
	 */
	void SetLookAtTrajectory(EShowLookAtTrajectory InShow3DTrajectory) { Show3DTrajectory = InShow3DTrajectory; }

private:

	/** Whether to show the 3d trajectory */
	UPROPERTY(EditAnywhere, DisplayName = "Show 3D Trajectory", Category = "Transform")
	EShowLookAtTrajectory Show3DTrajectory;

#endif // WITH_EDITORONLY_DATA
};

