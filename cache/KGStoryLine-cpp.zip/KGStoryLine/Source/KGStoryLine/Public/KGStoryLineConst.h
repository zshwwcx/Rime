#pragma once
#include "CoreMinimal.h"

namespace KGStoryLine
{
	constexpr uint64 INVALID_LINE_GUID = 0;
	constexpr int32 INVALID_EPISODE_ID = -1;
	constexpr int32 INVALID_LINE_INDEX = -1;
	constexpr int32 FLOAT_NUMBER_DECIMALS = 4;
	FORCEINLINE bool IsValidLineGUID(uint64 LineGUID)
	{
		return LineGUID != INVALID_LINE_GUID;
	}

	FORCEINLINE bool IsValidLineIndex(int32 LineIndex)
	{
		return LineIndex != INVALID_LINE_INDEX;
	}

	FORCEINLINE bool IsValidEpisodeID(int32 EpisodeID)
	{
		return EpisodeID > INVALID_EPISODE_ID;
	}
	
}
