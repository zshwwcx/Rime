#include "CutScene/MovieSceneQTEProxy.h"

#include "Sequence/KGSequenceManager.h"
#include "3C/Util/KGUtils.h"

void FMovieSceneQTEProxy::Execute(IMovieScenePlayer& Player, const UMovieSceneQTESection* MovieSceneCustomSection, float CurrentTime, int32 LoadHandle)
{
	if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
	{
		int64 MovieSceneCustomSectionID = KGUtils::GetIDByObject(const_cast<UMovieSceneQTESection*>(MovieSceneCustomSection));
		Manager->CallCustomProxyFunction("MovieSceneQTEProxy", "Execute", MovieSceneCustomSectionID, CurrentTime, LoadHandle);
	}
}

void FMovieSceneQTEProxy::SetUp(IMovieScenePlayer& Player, const UMovieSceneQTESection* MovieSceneCustomSection, int32 LoadHandle)
{
	if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
	{
		int64 MovieSceneCustomSectionID = KGUtils::GetIDByObject(const_cast<UMovieSceneQTESection*>(MovieSceneCustomSection));
		Manager->CallCustomProxyFunction("MovieSceneQTEProxy", "SetUp", MovieSceneCustomSectionID, LoadHandle);
	}
}

void FMovieSceneQTEProxy::TearDown(IMovieScenePlayer& Player, const UMovieSceneQTESection* MovieSceneCustomSection, int32 LoadHandle)
{
	if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
	{
		int64 MovieSceneCustomSectionID = KGUtils::GetIDByObject(const_cast<UMovieSceneQTESection*>(MovieSceneCustomSection));
		Manager->CallCustomProxyFunction("MovieSceneQTEProxy", "TearDown", MovieSceneCustomSectionID, LoadHandle);
	}
}
