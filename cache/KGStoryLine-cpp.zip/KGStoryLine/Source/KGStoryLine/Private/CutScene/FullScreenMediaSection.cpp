// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com


#include "CutScene/FullScreenMediaSection.h"

#include "BinkMediaSource.h"
#include "CutScene/FullScreenMediaProxy.h"
#include "CutScene/FullScreenMediaTrack.h"
#include "IMediaAssetsModule.h"
#include "MediaPlayer.h"
#include "MediaSoundComponent.h"
#include "MovieSceneMediaData.h"

struct FFullScreenMediaExecutionToken : IMovieSceneExecutionToken
{
	FFullScreenMediaExecutionToken(const double InCurrentTime, UFullScreenMediaTrack* InTrack)
		: CurrentTime(InCurrentTime)
		, Track(InTrack)
	{
	}

	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
		if (!ensure(Track.IsValid()))
			return;
			
		if (Context.GetStatus() == EMovieScenePlayerStatus::Playing)
		{
			if (Context.HasJumped())
			{
				Track->Seek(Player, CurrentTime);
			}

			float CurrentPlayerRate = Track->GetRate(Player);
			if (Context.GetDirection() == EPlayDirection::Forwards && CurrentPlayerRate <= 0.0f)
			{
				Track->SetRate(Player, 1.0f);
				Track->Seek(Player, CurrentTime);
			}
			else if (Context.GetDirection() == EPlayDirection::Backwards && CurrentPlayerRate >= 0.0f)
			{
				Track->SetRate(Player, -1.0f);
				Track->Seek(Player, CurrentTime);
			}
		}
		else
		{
			Track->SetRate(Player, 0.0f);
			Track->Seek(Player, CurrentTime);
		}
	}

private:
	double CurrentTime;
	TWeakObjectPtr<UFullScreenMediaTrack> Track;
};

struct FFullScreenMediaPreRollExecutionToken : IMovieSceneExecutionToken
{
	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
		FFullScreenMediaProxy::PreRoll(Player);
	}
};

FFullScreenMediaSectionTemplate::FFullScreenMediaSectionTemplate(const UMovieSceneMediaSection& InSection, const UMovieSceneMediaTrack& InTrack)
	: MediaSection(&InSection)
{
	Params.MediaSource = InSection.GetMediaSource();
	Params.MediaSourceProxy = InSection.GetMediaSourceProxy();
	Params.MediaSourceProxyIndex = InSection.MediaSourceProxyIndex;
	Params.MediaSoundComponent = InSection.MediaSoundComponent;
	Params.bLooping = InSection.bLooping;
	Params.StartFrameOffset = InSection.StartFrameOffset;
#if false
	if (Params.MediaSource != nullptr)
	{
		Params.MediaSource->SetCacheSettings(InSection.CacheSettings);
	}
#endif

	if (InSection.HasStartFrame())
	{
		Params.SectionStartFrame = InSection.GetRange().GetLowerBoundValue();
	}
	if (InSection.HasEndFrame())
	{
		Params.SectionEndFrame = InSection.GetRange().GetUpperBoundValue();
	}
}

void FFullScreenMediaSectionTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	if (Context.IsPostRoll())
	{
		return;
	}
	
	const UMovieSceneMediaSection* CustomSection = Cast<UMovieSceneMediaSection>(GetSourceSection());
	if (ensure(CustomSection))
	{
		UFullScreenMediaTrack* CustomTrack = Cast<UFullScreenMediaTrack>(CustomSection->GetOuter());
		if (ensure(CustomTrack))
		{
			if (Context.IsPreRoll())
			{
				// Seek To 0, and Pause.
				ExecutionTokens.Add(FFullScreenMediaPreRollExecutionToken());
			}
			else if (!Context.IsPostRoll() && (Context.GetTime().FrameNumber < Params.SectionEndFrame))
			{
				const FFrameRate FrameRate = Context.GetFrameRate();
				const FFrameTime FrameTime(Context.GetTime().FrameNumber - Params.SectionStartFrame + Params.StartFrameOffset);

				const double FrameTimeInSeconds = FrameRate.AsSeconds(FrameTime);
				ExecutionTokens.Add(FFullScreenMediaExecutionToken(FrameTimeInSeconds, CustomTrack));
			}
		}	
	}
	
}

void FFullScreenMediaSectionTemplate::Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	const UMovieSceneMediaSection* CustomSection = Cast<UMovieSceneMediaSection>(GetSourceSection());
	if (ensure(CustomSection))
	{
		UFullScreenMediaTrack* CustomTrack = Cast<UFullScreenMediaTrack>(CustomSection->GetOuter());
		if (ensure(CustomTrack))
		{
			CustomTrack->SetUp(Player, CustomSection);
		}	
	}
}

void FFullScreenMediaSectionTemplate::SetupOverrides()
{
	EnableOverrides(RequiresSetupFlag | RequiresTearDownFlag);
}

void FFullScreenMediaSectionTemplate::TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	const UMovieSceneMediaSection* CustomSection = Cast<UMovieSceneMediaSection>(GetSourceSection());
	if (ensure(CustomSection))
	{
		UFullScreenMediaTrack* CustomTrack = Cast<UFullScreenMediaTrack>(CustomSection->GetOuter());
		if (ensure(CustomTrack))
		{
			CustomTrack->TearDown(Player);
		}	
	}
}
