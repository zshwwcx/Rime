
#include "CutScene/MovieSceneCustomTrack.h"

#include "CutScene/MovieSceneCustomSection.h"
#include "CutScene/MovieSceneCustomTemplate.h"
#include "Sequence/KGSequenceManager.h"


#define LOCTEXT_NAMESPACE "UMovieSceneCustomTrack"

UMovieSceneCustomTrack::UMovieSceneCustomTrack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer), Actor(nullptr)
{
	SupportedBlendTypes.Add(EMovieSceneBlendType::Absolute);
#if WITH_EDITORONLY_DATA
	TrackTint = FColor(249, 98, 31, 150);
#endif
}

UMovieSceneCustomTrack::~UMovieSceneCustomTrack()
{
}

FName UMovieSceneCustomTrack::GetTrackName() const
{
	static FName CustomTrackName = TEXT("CustomTrack");
	return CustomTrackName;
}

#if WITH_EDITORONLY_DATA
FText UMovieSceneCustomTrack::GetDefaultDisplayName() const
{
	return LOCTEXT("CustomTrackName", "CustomTrack");
}
#endif

bool UMovieSceneCustomTrack::IsEmpty() const
{
	return (Sections.Num() == 0);
}

bool UMovieSceneCustomTrack::SupportsMultipleRows() const
{
	return true;
}

bool UMovieSceneCustomTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneCustomSection::StaticClass();
}

FMovieSceneEvalTemplatePtr UMovieSceneCustomTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FMovieSceneCustomTemplate(*CastChecked<UMovieSceneCustomSection>(&InSection), *this);
}

void UMovieSceneCustomTrack::AddSection(UMovieSceneSection& Section)
{
	Sections.Add(&Section);
}

UMovieSceneSection* UMovieSceneCustomTrack::CreateNewSection() {
	UMovieSceneCustomSection* Section = NewObject<UMovieSceneCustomSection>(this, NAME_None, RF_Transactional);
	return Section;
}

const TArray<UMovieSceneSection*>& UMovieSceneCustomTrack::GetAllSections() const {
	return Sections;
}

bool UMovieSceneCustomTrack::HasSection(const UMovieSceneSection& Section) const {
	return Sections.Contains(&Section);
}

void UMovieSceneCustomTrack::RemoveSection(UMovieSceneSection& Section) {
	Sections.Remove(&Section);
}

void UMovieSceneCustomTrack::RemoveSectionAt(int32 SectionIndex)
{
	Sections.RemoveAt(SectionIndex);
}

#if WITH_EDITOR
#define CheckExecuteInEditor(func, ...) \
	{ \
		bool bInEditor = false; \
		UKGSequenceManager* EditorManager = GetSequenceManager(Player); \
		if (EditorManager) \
		{ \
			if (UWorld* CurrentWorld = EditorManager->GetWorld()) \
				if (UGameInstance* GameInstance = CurrentWorld->GetGameInstance()) \
					bInEditor = GameInstance->GetName().StartsWith(TEXT("C7CutsceneGameInstance")); \
		} \
		else \
		{ \
			EditorManager = UKGSequenceManager::GetSequenceManagerInEditor(); \
			bInEditor = true; \
		} \
		if (bInEditor) \
		{ \
			if (EditorManager) \
				EditorManager->func(__VA_ARGS__); \
			else \
				UE_LOG(LogTemp, Error, TEXT("##func## ExecuteInEditor: KGSequenceManager is nullptr")) \
			return; \
		} \
	}
#else
#define CheckExecuteInEditor(func, ...)
#endif

void UMovieSceneCustomTrack::Execute(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, float CurrentTime, IMovieScenePlayer& Player)
{
	CheckExecuteInEditor(OnCustomTrackSectionExecuteInEditor, MovieSceneCustomSection, InActor, CurrentTime, UKGSequenceManager::EditorLoadHandleID)
	
	if (UKGSequenceManager* KGSequenceManager = GetSequenceManager(Player))
	{
		int LoadHandleID = KGSequenceManager->GetSequenceLoadHandleIDByMoviePlayer(Player);
		KGSequenceManager->OnCustomTrackSectionExecute(MovieSceneCustomSection, InActor, CurrentTime, LoadHandleID);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("MovieSceneCustomTrack Execute: KGSequenceManager is nullptr"));
	}
}

void UMovieSceneCustomTrack::SetUp(const UMovieSceneCustomSection* MovieSceneCustomSection, IMovieScenePlayer& Player)
{
	CheckExecuteInEditor(OnCustomTrackSectionSetUpInEditor, MovieSceneCustomSection, UKGSequenceManager::EditorLoadHandleID)
	
	if (UKGSequenceManager* KGSequenceManager = GetSequenceManager(Player))
	{
		int LoadHandleID = KGSequenceManager->GetSequenceLoadHandleIDByMoviePlayer(Player);
		KGSequenceManager->OnCustomTrackSectionSetUp(MovieSceneCustomSection, LoadHandleID);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("MovieSceneCustomTrack SetUp: KGSequenceManager is nullptr"));
	}
}

void UMovieSceneCustomTrack::TearDown(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, IMovieScenePlayer& Player)
{
	CheckExecuteInEditor(OnCustomTrackSectionTearDownInEditor, MovieSceneCustomSection, InActor, UKGSequenceManager::EditorLoadHandleID)
	
	if (UKGSequenceManager* KGSequenceManager = GetSequenceManager(Player))
	{
		int LoadHandleID = KGSequenceManager->GetSequenceLoadHandleIDByMoviePlayer(Player);
		KGSequenceManager->OnCustomTrackSectionTearDown(MovieSceneCustomSection, InActor, LoadHandleID);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("MovieSceneCustomTrack TearDown: KGSequenceManager is nullptr"));
	}
}

UKGSequenceManager* UMovieSceneCustomTrack::GetSequenceManager(IMovieScenePlayer& Player)
{
	if (UObject* AsUObject = Player.AsUObject())
	{
		return UKGSequenceManager::GetInstance(AsUObject);
	}
	return nullptr;
}



#undef LOCTEXT_NAMESPACE
