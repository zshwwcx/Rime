// Copyright Epic Games, Inc. All Rights Reserved.

#include "CutScene/MovieSceneLookAtTemplate.h"

#include "3C/Animation/BaseAnimInstance.h"
#include "Tracks/MovieScenePropertyTrack.h"
#include "GameFramework/Actor.h"
#include "Engine/World.h"
#include "Evaluation/MovieSceneEvaluation.h"
#include "Components/SceneComponent.h"
#include "3C/Animation/LookAt/LookAtComponent.h"
#include "3C/Character/BaseCharacter.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(MovieSceneLookAtTemplate)


DECLARE_CYCLE_STAT(TEXT("LookAt Track Evaluate"), MovieSceneEval_LookAtTrack_Evaluate, STATGROUP_MovieSceneEval);
DECLARE_CYCLE_STAT(TEXT("LookAt Track Token Execute"), MovieSceneEval_LookAtTrack_TokenExecute, STATGROUP_MovieSceneEval);


/** A movie scene pre-animated token that stores a pre-animated actor's temporarily hidden in game */
struct FTemporarilyLookAtPreAnimatedToken : IMovieScenePreAnimatedToken
{
	FTemporarilyLookAtPreAnimatedToken(float rot, float temporarilyRot)
		: rot(rot)
		, temporarilyRot(temporarilyRot)
	{}

	virtual void RestoreState(UObject& InObject, const UE::MovieScene::FRestoreStateParams& Params) override
	{
		if (InObject.IsA(AActor::StaticClass()))
		{
			AActor* Actor = CastChecked<AActor>(&InObject);
			
			//Actor->SetActorHiddenInGame(bHidden);

#if WITH_EDITOR
			//Actor->SetIsTemporarilyHiddenInEditor(bTemporarilyHiddenInGame);
#endif // WITH_EDITOR
		}
		else if (InObject.IsA(USceneComponent::StaticClass()))
		{
			USceneComponent* SceneComponent = CastChecked<USceneComponent>(&InObject);
			
			//SceneComponent->SetHiddenInGame(bHidden);
		}
	}

	float rot;
	float temporarilyRot;
};

struct FTemporarilyLookAtTokenProducer : IMovieScenePreAnimatedTokenProducer
{
	/** Cache the existing state of an object before moving it */
	virtual IMovieScenePreAnimatedTokenPtr CacheExistingState(UObject& InObject) const override
	{
		if (InObject.IsA(AActor::StaticClass()))
		{
			AActor* Actor = CastChecked<AActor>(&InObject);
	
			bool bInTemporarilyHiddenInGame = 
#if WITH_EDITOR
				Actor->IsTemporarilyHiddenInEditor();
#else
				false;
#endif
			//return FTemporarilyLookAtPreAnimatedToken(Actor->IsHidden(), bInTemporarilyHiddenInGame);
			return FTemporarilyLookAtPreAnimatedToken(0, 0);
		}
		else if (InObject.IsA(USceneComponent::StaticClass()))
		{
			USceneComponent* SceneComponent = CastChecked<USceneComponent>(&InObject);

			const bool bUnused = false;
			//return FTemporarilyLookAtPreAnimatedToken(SceneComponent->bHiddenInGame, bUnused);
			return FTemporarilyLookAtPreAnimatedToken(0, 0);
		}

		//return FTemporarilyLookAtPreAnimatedToken(false, false);
		return FTemporarilyLookAtPreAnimatedToken(0, 0);
	}
};

/** A movie scene execution token that stores temporarily LookAt */
struct FTemporarilyLookAtExecutionToken
	: IMovieSceneExecutionToken
{
	double EyeX;
	double EyeY;
	double EyeZ;
	double HeadX;
	double HeadY;
	double HeadZ;
	double BodyX;
	double BodyY;
	double BodyZ;
	double Spine_01X;
	double Spine_01Y;
	double Spine_01Z;
	double Spine_02X;
	double Spine_02Y;
	double Spine_02Z;
	double Spine_03X;
	double Spine_03Y;
	double Spine_03Z;

	FTemporarilyLookAtExecutionToken(double EyeX, double EyeY, double EyeZ, double HeadX, double HeadY, double HeadZ, double BodyX, double BodyY, double BodyZ, double Spine_01X, double Spine_01Y, double Spine_01Z, double Spine_02X, double Spine_02Y, double Spine_02Z, double Spine_03X, double Spine_03Y, double Spine_03Z) : EyeX(EyeX), EyeY(EyeY), EyeZ(EyeZ), HeadX(HeadX), HeadY(HeadY), HeadZ(HeadZ), BodyX(BodyX), BodyY(BodyY), BodyZ(BodyZ), Spine_01X(Spine_01X), Spine_01Y(Spine_01Y), Spine_01Z(Spine_01Z), Spine_02X(Spine_02X), Spine_02Y(Spine_02Y), Spine_02Z(Spine_02Z), Spine_03X(Spine_03X), Spine_03Y(Spine_03Y), Spine_03Z(Spine_03Z) {}

	static FMovieSceneAnimTypeID GetAnimTypeID()
	{
		return TMovieSceneAnimTypeID<FTemporarilyLookAtExecutionToken>();
	}
	
	/** Execute this token, operating on all objects referenced by 'Operand' */
	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
		MOVIESCENE_DETAILED_SCOPE_CYCLE_COUNTER(MovieSceneEval_VisibilityTrack_TokenExecute);

		//美术还是要同款功能 修复一下问题，先打开 lizhang@kuaishou.com
#if 1  //LookAtComponent 先禁用了吧 hujianglong@kuaishou.com
		for (TWeakObjectPtr<> WeakObject : Player.FindBoundObjects(Operand))
		{
			if (UObject* ObjectPtr = WeakObject.Get())
			{
				if (ObjectPtr->IsA(ABaseCharacter::StaticClass()))
				{
					ABaseCharacter* Actor = Cast<ABaseCharacter>(ObjectPtr);

					Player.SavePreAnimatedState(*Actor, GetAnimTypeID(), FTemporarilyLookAtTokenProducer());

					if (USkeletalMeshComponent* MainMesh = Actor->GetMainMesh())
					{
						if (UBaseAnimInstance* AnimInstance = Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()))
						{
							AnimInstance->SequenceUpdateGazeBonesModify(FRotator(EyeX, EyeY, 0), FVector(EyeZ, EyeZ, EyeZ), FRotator(HeadX, HeadY, HeadZ), FRotator(BodyX, BodyY, BodyZ),
								FRotator(Spine_01X, Spine_01Y, Spine_01Z), FRotator(Spine_02X, Spine_02Y, Spine_02Z), FRotator(Spine_03X, Spine_03Y, Spine_03Z));
						}	
					}
					
					// ULookAtComponent* LookAtComponent = Actor->GetComponentByClass<ULookAtComponent>();
					// if(LookAtComponent == nullptr)
					// {
					// 	continue;
					// }
					// //UE_LOG(LogTemp, Warning, TEXT("FTemporarilyLookAtExecutionToken::Execute =>Eye:%f %f %f, Head:%f %f %f , body:%f %f %f "), EyeX, EyeY, EyeZ, HeadX, HeadY, HeadZ, BodyX, BodyY, BodyZ);
					// //Actor->SetActorHiddenInGame(bIsHidden);
					// LookAtComponent->SetEye(FRotator(EyeX, EyeY, 0));
					// LookAtComponent->SetEyeScale(FVector(EyeZ, EyeZ, EyeZ));
					// LookAtComponent->SetHead(FRotator(HeadX, HeadY, HeadZ));
					// LookAtComponent->SetBody(FRotator(BodyX, BodyY, BodyZ));
					// LookAtComponent->SetSpine_01(FRotator(Spine_01X, Spine_01Y, Spine_01Z));
					// LookAtComponent->SetSpine_02(FRotator(Spine_02X, Spine_02Y, Spine_02Z));
					// LookAtComponent->SetSpine_03(FRotator(Spine_03X, Spine_03Y, Spine_03Z));
					// LookAtComponent->UpdateProperty();
					
#if WITH_EDITOR
					if (GIsEditor && Actor->GetWorld() != nullptr && !Actor->GetWorld()->IsPlayInEditor())
					{
						//Actor->SetIsTemporarilyHiddenInEditor(bIsHidden);
					}
#endif // WITH_EDITOR
				}
				else if (ObjectPtr->IsA(USceneComponent::StaticClass()))
				{
					USceneComponent* SceneComponent = Cast<USceneComponent>(ObjectPtr);
					
					Player.SavePreAnimatedState(*SceneComponent, GetAnimTypeID(), FTemporarilyLookAtTokenProducer());
					//SceneComponent->SetHiddenInGame(bIsHidden);
				}
			}
		}
#endif
	}
};

//Eye{Section.Eye}, Head{Section.Head}, Body{Section.Body}, FloatCurve(Section.FloatCurve)
FMovieSceneLookAtSectionTemplate::FMovieSceneLookAtSectionTemplate(const UMovieSceneLookAtSection& Section, const UMovieScenePropertyTrack& Track)
{
	//美术还是要同款功能 修复一下问题，先打开 lizhang@kuaishou.com
#if 1  //LookAtComponent 先禁用了吧 hujianglong@kuaishou.com
	Eye[0] = Section.Eye[0];
	Eye[1] = Section.Eye[1];
	Eye[2] = Section.Eye[2];
	Head[0] = Section.Head[0];
	Head[1] = Section.Head[1];
	Head[2] = Section.Head[2];
	Body[0] = Section.Body[0];
	Body[1] = Section.Body[1];
	Body[2] = Section.Body[2];
	Spine_01[0] = Section.Spine_01[0];
	Spine_01[1] = Section.Spine_01[1];
	Spine_01[2] = Section.Spine_01[2];

	Spine_02[0] = Section.Spine_02[0];
	Spine_02[1] = Section.Spine_02[1];
	Spine_02[2] = Section.Spine_02[2];

	Spine_03[0] = Section.Spine_03[0];
	Spine_03[1] = Section.Spine_03[1];
	Spine_03[2] = Section.Spine_03[2];
#endif
}

void FMovieSceneLookAtSectionTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	MOVIESCENE_DETAILED_SCOPE_CYCLE_COUNTER(MovieSceneEval_LookAtTrack_Evaluate);

	//美术还是要同款功能 修复一下问题，先打开 lizhang@kuaishou.com
#if 1  //LookAtComponent 先禁用了吧 hujianglong@kuaishou.com
	double EyeX, EyeY, EyeZ = 0.0f;
	double HeadX, HeadY, HeadZ = 0.0f;
	double BodyX, BodyY, BodyZ = 0.0f;
	double Spine_01X, Spine_01Y, Spine_01Z = 0.0f;
	double Spine_02X, Spine_02Y, Spine_02Z = 0.0f; 
	double Spine_03X, Spine_03Y, Spine_03Z = 0.0f;
	FFrameTime InTime = Context.GetTime();
	if (Eye[0].Evaluate(InTime, EyeX))
	{
		
	}
	if (Eye[1].Evaluate(InTime, EyeY))
	{

	}
	if (Eye[2].Evaluate(InTime, EyeZ))
	{

	}
	if (Head[0].Evaluate(InTime, HeadX))
	{

	}
	if (Head[1].Evaluate(InTime, HeadY))
	{

	}
	if (Head[2].Evaluate(InTime, HeadZ))
	{

	}
	if (Body[0].Evaluate(InTime, BodyX))
	{

	}
	if (Body[1].Evaluate(InTime, BodyY))
	{

	}
	if (Body[2].Evaluate(InTime, BodyZ))
	{

	}

	if (Spine_01[0].Evaluate(InTime, Spine_01X))
	{

	}
	if (Spine_01[1].Evaluate(InTime, Spine_01Y))
	{

	}
	if (Spine_01[2].Evaluate(InTime, Spine_01Z))
	{

	}

	if (Spine_02[0].Evaluate(InTime, Spine_02X))
	{

	}
	if (Spine_02[1].Evaluate(InTime, Spine_02Y))
	{

	}
	if (Spine_02[2].Evaluate(InTime, Spine_02Z))
	{

	}

	if (Spine_03[0].Evaluate(InTime, Spine_03X))
	{

	}
	if (Spine_03[1].Evaluate(InTime, Spine_03Y))
	{

	}
	if (Spine_03[2].Evaluate(InTime, Spine_03Z))
	{

	}
	//UE_LOG(LogTemp, Warning, TEXT("FMovieSceneLookAtSectionTemplate::Execute => InTime %s Eye:%f %f %f, Head:%f %f %f , body:%f %f %f "), *LexToString(InTime), EyeX, EyeY, EyeZ, HeadX, HeadY, HeadZ, BodyX, BodyY, BodyZ);
	// Invert this evaluation since the property is "bHiddenInGame" and we want the visualization to be the inverse of that. Green means visible.
	ExecutionTokens.Add(FTemporarilyLookAtExecutionToken(EyeX, EyeY, EyeZ, HeadX, HeadY, HeadZ, BodyX, BodyY, BodyZ, Spine_01X, Spine_01Y, Spine_01Z, Spine_02X, Spine_02Y, Spine_02Z, Spine_03X, Spine_03Y, Spine_03Z));
#endif
}


