﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "CutScene/ACutSceneActor.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "Animation/AnimInstance.h"
#include "3C/Animation/LookAt/CutSceneAnimInstance.h"
#include "Components/SkeletalMeshComponent.h"

// Sets default values
ACutSceneActor::ACutSceneActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ACutSceneActor::BeginPlay()
{
	Super::BeginPlay();

}

void ACutSceneActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	
}

void ACutSceneActor::UpdateProperty()
{
	USceneComponent* Root = GetRootComponent();
	if (USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(Root))
	{
		UAnimInstance* AnimInstance = SkeletalMeshComponent->GetAnimInstance();
		if (UCutSceneAnimInstance* CutSceneAnimInstance = Cast<UCutSceneAnimInstance>(AnimInstance))
		{
			//UE_LOG(LogTemp, Warning, TEXT("UpdateProperty befor =>Eye:%f %f %f, Head:%f %f %f , body:%f %f %f "), CutSceneAnimInstance->Eye.Pitch, CutSceneAnimInstance->Eye.Yaw, CutSceneAnimInstance->Eye.Roll, CutSceneAnimInstance->Head.Pitch, CutSceneAnimInstance->Head.Yaw, CutSceneAnimInstance->Head.Roll, CutSceneAnimInstance->Body.Pitch, CutSceneAnimInstance->Body.Yaw, CutSceneAnimInstance->Body.Roll);
			CutSceneAnimInstance->Eye = Eye;
			CutSceneAnimInstance->EyeScale = EyeScale;
			CutSceneAnimInstance->Head = Head;
			CutSceneAnimInstance->Body = Body;
			CutSceneAnimInstance->Spine_01 = Spine_01;
			CutSceneAnimInstance->Spine_02 = Spine_02;
			CutSceneAnimInstance->Spine_03 = Spine_03;
			//UE_LOG(LogTemp, Warning, TEXT("UpdateProperty update =>Eye:%f %f %f, Head:%f %f %f , body:%f %f %f "), CutSceneAnimInstance->Eye.Pitch, CutSceneAnimInstance->Eye.Yaw, CutSceneAnimInstance->Eye.Roll, CutSceneAnimInstance->Head.Pitch, CutSceneAnimInstance->Head.Yaw, CutSceneAnimInstance->Head.Roll, CutSceneAnimInstance->Body.Pitch, CutSceneAnimInstance->Body.Yaw, CutSceneAnimInstance->Body.Roll);

			// Restore pose after unbinding to force the restored pose
			SkeletalMeshComponent->SetUpdateAnimationInEditor(true);
			SkeletalMeshComponent->SetUpdateClothInEditor(true);
			SkeletalMeshComponent->TickAnimation(0.f, false);

			SkeletalMeshComponent->RefreshBoneTransforms();
			SkeletalMeshComponent->RefreshFollowerComponents();
			SkeletalMeshComponent->UpdateComponentToWorld();
			SkeletalMeshComponent->FinalizeBoneTransform();
			SkeletalMeshComponent->MarkRenderTransformDirty();
			SkeletalMeshComponent->MarkRenderDynamicDataDirty();
		}
	}
}


