﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "CutScene/MovieSceneAnimMontageSection.h"
#include "CutScene/MovieSceneExtendComponentTypes.h"
#include "EntitySystem/BuiltInComponentTypes.h"

FMovieSceneAnimMontageParams::FMovieSceneAnimMontageParams()
{
	AnimMontage = nullptr;
}

double FMovieSceneAnimMontageParams::MapTimeToAnimation(const UMovieSceneSection* InSection, FFrameTime InPosition,
	FFrameRate InFrameRate) const
{
	const FFrameNumber SectionStartTime = InSection->GetInclusiveStartFrame();
	const FFrameNumber SectionEndTime = InSection->GetExclusiveEndFrame();
	return MapTimeToAnimation(SectionStartTime, SectionEndTime, InPosition, InFrameRate);
}

double FMovieSceneAnimMontageParams::MapTimeToAnimation(FFrameNumber InSectionStartTime, FFrameNumber InSectionEndTime,
	FFrameTime InPosition, FFrameRate InFrameRate) const
{
	// Get Animation Length and frame time
	if (AnimMontage)
	{
		const FFrameTime AnimationLength = GetSequenceLength() * InFrameRate;
		const int32 LengthInFrames = AnimationLength.FrameNumber.Value + (int)(AnimationLength.GetSubFrame() + 0.5f) + 1;

		// we only play end if we are not looping, and assuming we are looping if Length is greater than default length;
		const bool bLooping = (InSectionEndTime.Value - InSectionStartTime.Value + StartFrameOffset + EndFrameOffset) > LengthInFrames;

		// Make sure InPosition FrameTime doesn't underflow InSectionStartTime or overflow InSectionEndTime
		InPosition = FMath::Clamp(InPosition, FFrameTime(InSectionStartTime), FFrameTime(InSectionEndTime - 1));

		// Gather helper values
		const float SectionPlayRate = PlayRate * AnimMontage->RateScale;
		const float AnimPlayRate = FMath::IsNearlyZero(SectionPlayRate) ? 1.0f : SectionPlayRate;
		const double SeqLength = GetSequenceLength() - InFrameRate.AsSeconds(StartFrameOffset + EndFrameOffset);

		// The Time from the beginning of InSectionStartTime to InPosition in seconds
		double SecondsFromSectionStart = FFrameTime::FromDecimal((InPosition - InSectionStartTime).AsDecimal() * AnimPlayRate) / InFrameRate;

		// Logic for reversed animation
		// if (bReverse)
		// {
		// 	// Duration of this section 
		// 	double SectionDuration = (((InSectionEndTime - InSectionStartTime) * AnimPlayRate) / InFrameRate);
		// 	SecondsFromSectionStart = SectionDuration - SecondsFromSectionStart;
		// }

		SecondsFromSectionStart += InFrameRate.AsSeconds(FirstLoopStartFrameOffset);

		// Make sure Seconds is in range
		if (SeqLength > 0.0 && (bLooping || !FMath::IsNearlyEqual(SecondsFromSectionStart, SeqLength, 1e-4)))
		{
			SecondsFromSectionStart = FMath::Fmod(SecondsFromSectionStart, SeqLength);
		}

		// Add the StartFrameOffset to the current seconds in the section to get the right animation frame
		SecondsFromSectionStart += InFrameRate.AsSeconds(StartFrameOffset);
		return SecondsFromSectionStart;
	}
	return 0.0;
}


double UMovieSceneAnimMontageSection::MapTimeToAnimation(FFrameTime InPosition, FFrameRate InFrameRate) const
{
	return Params.MapTimeToAnimation(this, InPosition, InFrameRate);
}

void UMovieSceneAnimMontageSection::ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker,
                                                     const FEntityImportParams& InParams, FImportedEntity* OutImportedEntity)
{
	using namespace UE::MovieScene;

	const FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
	const FMovieSceneExtendComponentTypes* TrackComponents = FMovieSceneExtendComponentTypes::Get();

	const FGuid ObjectBindingID = InParams.GetObjectBindingID();
	FMovieSceneAnimMontageComponentData ComponentData { this };

	OutImportedEntity->AddBuilder(
		FEntityBuilder()
		.Add(TrackComponents->AnimMontage, ComponentData)
		.AddConditional(BuiltInComponents->GenericObjectBinding, ObjectBindingID, ObjectBindingID.IsValid())
	);
}
