// Copyright Epic Games, Inc. All Rights Reserved.

#include "CutScene/MovieSceneLookAtTrack.h"
#include "CutScene/MovieSceneLookAtSection.h"
#include "CutScene/MovieSceneLookAtTemplate.h"
#include "Systems/MovieScenePiecewiseDoubleBlenderSystem.h"
#include "Systems/MovieSceneQuaternionBlenderSystem.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(MovieSceneLookAtTrack)

#define LOCTEXT_NAMESPACE "MovieSceneLookAtTrack"

UMovieSceneLookAtTrack::UMovieSceneLookAtTrack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	static FName Transform("LookAt");
	SetPropertyNameAndPath(Transform, Transform.ToString());

	SupportedBlendTypes = FMovieSceneBlendTypeField::All();

#if WITH_EDITORONLY_DATA
	TrackTint = FColor(65, 173, 164, 65);
#endif

	EvalOptions.bEvaluateNearestSection_DEPRECATED = EvalOptions.bCanEvaluateNearestSection = true;
}

bool UMovieSceneLookAtTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneLookAtSection::StaticClass();
}

UMovieSceneSection* UMovieSceneLookAtTrack::CreateNewSection()
{
	return NewObject<UMovieSceneLookAtSection>(this, NAME_None, RF_Transactional);
}

FMovieSceneEvalTemplatePtr UMovieSceneLookAtTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FMovieSceneLookAtSectionTemplate(*CastChecked<const UMovieSceneLookAtSection>(&InSection), *this);
}

#if WITH_EDITORONLY_DATA
FText UMovieSceneLookAtTrack::GetDisplayName() const
{
	return LOCTEXT("LookAtDisplayName", "LookAt");
}

FSlateColor UMovieSceneLookAtTrack::GetLabelColor(const FMovieSceneLabelParams& LabelParams) const
{
	return FSlateColor::UseForeground();
}
#endif

#undef LOCTEXT_NAMESPACE

