#include "CutScene/MovieSceneAudio2FaceTemplate.h"

#include "MovieScene.h"
#include "Engine/Engine.h"
#include "CutScene/MovieSceneAudio2FaceSection.h"
#include "CutScene/MovieSceneAudio2FaceTrack.h"



struct FAudio2FaceSectionExecutionToken : IMovieSceneExecutionToken
{
	FAudio2FaceSectionExecutionToken(const UMovieSceneAudio2FaceSection* InSection)
		: Section(InSection)
	{}
	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
		if (UMovieSceneAudio2FaceTrack* Track = Cast<UMovieSceneAudio2FaceTrack>(Section->GetOuter()))
		{
			double CurrentTime = Context.GetFrameRate().AsSeconds(Context.GetTime());

			double StartTime = Section->GetInclusiveStartFrame() / Section->GetTypedOuter<UMovieScene>()->GetTickResolution();

			for (auto ObjectPtr : Player.FindBoundObjects(Operand))
			{
				if (const auto Object = ObjectPtr.Get())
				{
					if (AActor* Actor = CastChecked<AActor>(Object))
					{
						if (!Track->bSetUpFace)
						{
							Track->SetUp(Section, Actor);

							Track->bSetUpFace = true;
						}

						Track->Execute(Section, Actor, CurrentTime - StartTime);
					}
				}
			}

			Track->LastOperand = Operand;
		}
	}

	const UMovieSceneAudio2FaceSection* Section;
};

FMovieSceneAudio2FaceTemplate::FMovieSceneAudio2FaceTemplate()
{

}

FMovieSceneAudio2FaceTemplate::FMovieSceneAudio2FaceTemplate(const UMovieSceneAudio2FaceSection& Section, const UMovieSceneAudio2FaceTrack& Track)
{

}

void FMovieSceneAudio2FaceTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	if (Context.GetStatus() != EMovieScenePlayerStatus::Jumping)
	{
		if (const UMovieSceneAudio2FaceSection* Audio2FaceSection = Cast<UMovieSceneAudio2FaceSection>(GetSourceSection()))
		{
			ExecutionTokens.Add(FAudio2FaceSectionExecutionToken(Audio2FaceSection));
		}
	}
}

void FMovieSceneAudio2FaceTemplate::Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	if (const UMovieSceneAudio2FaceSection* Audio2FaceSection = Cast<UMovieSceneAudio2FaceSection>(GetSourceSection()))
	{
		if (UMovieSceneAudio2FaceTrack* Audio2FaceTrack = Cast<UMovieSceneAudio2FaceTrack>(Audio2FaceSection->GetOuter()))
		{
			Audio2FaceTrack->SetUp(Audio2FaceSection, nullptr);
		}
	}
}

void FMovieSceneAudio2FaceTemplate::TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	if (const UMovieSceneAudio2FaceSection* Audio2FaceSection = Cast<UMovieSceneAudio2FaceSection>(GetSourceSection()))
	{
		if (UMovieSceneAudio2FaceTrack* Audio2FaceTrack = Cast<UMovieSceneAudio2FaceTrack>(Audio2FaceSection->GetOuter()))
		{
			for (auto ObjectPtr : Player.FindBoundObjects(Audio2FaceTrack->LastOperand))
			{
				if (const auto Object = ObjectPtr.Get())
				{
					if (AActor* Actor = CastChecked<AActor>(Object))
					{
						Audio2FaceTrack->TearDown(Audio2FaceSection, Actor);
					}
				}
			}
		}
	}
}
