#include "CutScene/MovieSceneResizeBoundsSection.h"
#include "3C/Core/ResizeBoundsScaleComponent.h"
#include "Components/SkeletalMeshComponent.h"

struct FResizeBoundsEvaluationData : IPersistentEvaluationData
{
	TArrayView<TWeakObjectPtr<>> BoundObjects;
};

void FMovieSceneResizeBoundsTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
}

void FMovieSceneResizeBoundsTemplate::Initialize(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	FResizeBoundsEvaluationData& Data = PersistentData.GetOrAddSectionData<FResizeBoundsEvaluationData>();
	Data.BoundObjects = Player.FindBoundObjects(Operand);
	for (TWeakObjectPtr<> BoundObject : Data.BoundObjects)
	{
		if (UObject* Object = BoundObject.Get())
		{
			if (AActor* Actor = Cast<AActor>(Object))
			{
				TArray<USkeletalMeshComponent*> SkeletalMeshComponents;
				Actor->GetComponents<USkeletalMeshComponent>(SkeletalMeshComponents);
				for (auto& SkeletalMeshComponent : SkeletalMeshComponents)
				{
					SkeletalMeshComponent->SetUpdateBoundWithAllBones(true);
				}
			}
			else if (USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(Object))
			{
				SkeletalMeshComponent->SetUpdateBoundWithAllBones(true);
			}
		}
	}
}

void FMovieSceneResizeBoundsTemplate::TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	for (TWeakObjectPtr<> BoundObject : PersistentData.GetSectionData<FResizeBoundsEvaluationData>().BoundObjects)
	{
		if (UObject* Object = BoundObject.Get())
		{
			if (AActor* Actor = Cast<AActor>(Object))
			{
				TArray<USkeletalMeshComponent*> SkeletalMeshComponents;
				Actor->GetComponents<USkeletalMeshComponent>(SkeletalMeshComponents);
				for (auto& SkeletalMeshComponent : SkeletalMeshComponents)
				{
					SkeletalMeshComponent->SetUpdateBoundWithAllBones(false);
				}
			}
			else if (USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(Object))
			{
				SkeletalMeshComponent->SetUpdateBoundWithAllBones(false);
			}
		}
	}
}
