#include "CutScene/MovieSceneAudio2FaceTrack.h"
#include "CutScene/MovieSceneAudio2FaceSection.h"
#include "CutScene/MovieSceneAudio2FaceTemplate.h"
#include "3C/Animation/FaceAnim/FaceAnimComponent.h"
#include "CutScene/ACutSceneActor.h"
#include "Components/SkeletalMeshComponent.h"
#include "CutScene/CutSceneDefine.h"



#define LOCTEXT_NAMESPACE "MovieSceneAudio2FaceTrack"

UMovieSceneAudio2FaceTrack::UMovieSceneAudio2FaceTrack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	SupportedBlendTypes.Add(EMovieSceneBlendType::Absolute);
#if WITH_EDITORONLY_DATA
	TrackTint = FColor(0, 9, 185, 255);
#endif
}

UMovieSceneAudio2FaceTrack::~UMovieSceneAudio2FaceTrack()
{
}

FName UMovieSceneAudio2FaceTrack::GetTrackName() const
{
	static FName Audio2FaceName = TEXT("Audio2Face");
	return Audio2FaceName;
}

#if WITH_EDITORONLY_DATA
FText UMovieSceneAudio2FaceTrack::GetDefaultDisplayName() const
{
	return LOCTEXT("Audio2FaceName", "Audio2Face");
}
#endif

bool UMovieSceneAudio2FaceTrack::IsEmpty() const
{
	return (Sections.Num() == 0);
}

bool UMovieSceneAudio2FaceTrack::SupportsMultipleRows() const
{
	return true;
}

bool UMovieSceneAudio2FaceTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneAudio2FaceSection::StaticClass();
}

FMovieSceneEvalTemplatePtr UMovieSceneAudio2FaceTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FMovieSceneAudio2FaceTemplate(*CastChecked<UMovieSceneAudio2FaceSection>(&InSection), *this);
}

void UMovieSceneAudio2FaceTrack::AddSection(UMovieSceneSection& Section)
{
	Sections.Add(&Section);
}

UMovieSceneSection* UMovieSceneAudio2FaceTrack::CreateNewSection() {
	UMovieSceneAudio2FaceSection* Section = NewObject<UMovieSceneAudio2FaceSection>(this, NAME_None, RF_Transactional);
	return Section;
}

const TArray<UMovieSceneSection*>& UMovieSceneAudio2FaceTrack::GetAllSections() const {
	return Sections;
}

bool UMovieSceneAudio2FaceTrack::HasSection(const UMovieSceneSection& Section) const {
	return Sections.Contains(&Section);
}

void UMovieSceneAudio2FaceTrack::RemoveSection(UMovieSceneSection& Section) {
	Sections.Remove(&Section);
}

void UMovieSceneAudio2FaceTrack::RemoveSectionAt(int32 SectionIndex)
{
	if (Sections.IsValidIndex(SectionIndex))
	{
		Sections.RemoveAt(SectionIndex);
	}
}

void UMovieSceneAudio2FaceTrack::Execute(const UMovieSceneAudio2FaceSection* MovieSceneCustomSection, AActor* InActor, float CurrentTime)
{
	if (InActor)
	{
		if (UFaceAnimComponent* FaceAnimCom = InActor->FindComponentByClass<UFaceAnimComponent>())
		{
			FaceAnimCom->SetLipFaceAnimCurFrameTime(CurrentTime);
		}
	}
}

void UMovieSceneAudio2FaceTrack::SetUp(const UMovieSceneAudio2FaceSection* MovieSceneCustomSection, AActor* InActor)
{
	bSetUpFace = false;

	LastOperand = FMovieSceneEvaluationOperand();
	if(!InActor)
		return ;

	if (USkeletalMeshComponent* Mesh = InActor->FindComponentByClass<USkeletalMeshComponent>())
	{
		if (UFaceAnimComponent* FaceAnimCom = InActor->FindComponentByClass<UFaceAnimComponent>())
		{
			EFaceAnimSexType Sex = EFaceAnimSexType::None;
			if (InActor->ActorHasTag(NAME_CutSceneActorSex_ManTag))
			{
				Sex = EFaceAnimSexType::Male;
			}
			else if (InActor->ActorHasTag(NAME_CutSceneActorSex_WomanTag))
			{
				Sex = EFaceAnimSexType::Female;
			}

			FaceAnimCom->SetLipFaceAnimFrame(Mesh, MovieSceneCustomSection->FaceAnimID, MovieSceneCustomSection->FixTime,MovieSceneCustomSection->LipBlend, Sex);
		}
	}
}

void UMovieSceneAudio2FaceTrack::TearDown(const UMovieSceneAudio2FaceSection* MovieSceneCustomSection, AActor* InActor)
{
	LastOperand = FMovieSceneEvaluationOperand();
	bSetUpFace = false;

}

#undef LOCTEXT_NAMESPACE
