#include "CutScene/MovieSceneExtendComponentTypes.h"
#include "EntitySystem/MovieSceneComponentRegistry.h"
#include "EntitySystem/MovieSceneEntitySystemLinker.h"
#include "EntitySystem/MovieSceneEntityFactoryTemplates.h"

namespace UE
{
	namespace MovieScene
	{

		static bool GMovieSceneExtendComponentTypesDestroyed = false;
		static TUniquePtr<FMovieSceneExtendComponentTypes> GMovieSceneExtendComponentTypes;
		
		FMovieSceneExtendComponentTypes::FMovieSceneExtendComponentTypes()
		{
			FComponentRegistry* ComponentRegistry = UMovieSceneEntitySystemLinker::GetComponents();

			ComponentRegistry->NewComponentType(&AnimMontage, TEXT("Animation Montage"));
			
			ComponentRegistry->Factories.DuplicateChildComponent(AnimMontage);
		}

		FMovieSceneExtendComponentTypes::~FMovieSceneExtendComponentTypes()
		{
		}

		void FMovieSceneExtendComponentTypes::Destroy()
		{
			GMovieSceneExtendComponentTypes.Reset();
			GMovieSceneExtendComponentTypesDestroyed = true;
		}

		FMovieSceneExtendComponentTypes* FMovieSceneExtendComponentTypes::Get()
		{
			if (!GMovieSceneExtendComponentTypes.IsValid())
			{
				check(!GMovieSceneExtendComponentTypesDestroyed);
				GMovieSceneExtendComponentTypes.Reset(new FMovieSceneExtendComponentTypes);
			}
			return GMovieSceneExtendComponentTypes.Get();
		}

	}
}
