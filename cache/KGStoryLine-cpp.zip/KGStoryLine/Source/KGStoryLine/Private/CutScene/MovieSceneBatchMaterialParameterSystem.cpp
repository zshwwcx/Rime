// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "Systems/MovieSceneMaterialParameterSystem.h"
#include "Systems/FloatChannelEvaluatorSystem.h"
#include "Systems/DoubleChannelEvaluatorSystem.h"
#include "Systems/MovieScenePiecewiseDoubleBlenderSystem.h"
#include "Systems/MovieSceneHierarchicalBiasSystem.h"
#include "Systems/MovieSceneMaterialSystem.h"
#include "Systems/MovieSceneInitialValueSystem.h"
#include "Systems/MovieScenePreAnimatedMaterialParameters.h"
#include "Systems/WeightAndEasingEvaluatorSystem.h"
#include "Evaluation/PreAnimatedState/MovieScenePreAnimatedObjectStorage.h"
#include "Materials/MaterialParameterCollectionInstance.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "CutScene/MovieSceneBatchMaterialParameterSystem.h"

#include "CutScene/KGMovieSceneComponentType.h"
#include "Components/PrimitiveComponent.h"
#include "CutScene/CutsceneUtils.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(MovieSceneBatchMaterialParameterSystem)

namespace UE::MovieScene
{
/** Apply scalar material parameters */
struct FBatchApplyScalarParameters
{
	static void ForEachAllocation(FEntityAllocationIteratorItem Item,
		TRead<UObject*> BoundObjects,
		TRead<FMaterialParameterInfo> ScalarParameterInfos,
		TRead<double> ScalarValues,
		TRead<FText> SlotName)
	{
		const int32 Num = Item.GetAllocation()->Num();

		for (int32 Index = 0; Index < Num; ++Index)
		{
			TArray<UPrimitiveComponent*> PrimitiveComponents;
			AActor* Actor = Cast<AActor>(BoundObjects[Index]);
			if (!Actor)
			{
				UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(BoundObjects[Index]);
				if (!PrimitiveComponent)
				{
					return;
				}
				PrimitiveComponents.Add(PrimitiveComponent);
			}
			else
			{
				Actor->GetComponents(UPrimitiveComponent::StaticClass(), PrimitiveComponents);
			}
			
			if (SlotName->IsEmpty())
			{
				for (auto PrimitiveComponent : PrimitiveComponents)
				{
					TArray<UMaterialInterface*> UsedMaterials;
					PrimitiveComponent->GetUsedMaterials(UsedMaterials);
					for (auto MaterialInterface : UsedMaterials)
					{
						if (UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(MaterialInterface))
						{
							MID->SetScalarParameterValueByInfo(ScalarParameterInfos[Index], (float)ScalarValues[Index]);
						}
					}
				}
			}
			else
			{
				for (auto PrimitiveComponent : PrimitiveComponents)
				{
					UCutsceneUtils::ForEachMaterialOnComponentBySlotName(PrimitiveComponent, *SlotName, [&ScalarParameterInfos,&ScalarValues,&Index](UMaterialInterface* MaterialInterface) {
						if (UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(MaterialInterface))
						{
							MID->SetScalarParameterValueByInfo(ScalarParameterInfos[Index], (float)ScalarValues[Index]);
						}
					});
				}
			}
		}
	}
};

/** Apply vector material parameters */
struct FBatchApplyVectorParameters
{
	static void ForEachAllocation(FEntityAllocationIteratorItem Item,
		TRead<UObject*> BoundObjects,
		TRead<FMaterialParameterInfo> ColorParameterInfos,
		TRead<FText> SlotName,
		TReadOneOrMoreOf<double, double, double, double> VectorChannels)
	{
		const int32 Num = Item.GetAllocation()->Num();
		const double* RESTRICT R = VectorChannels.Get<0>();
		const double* RESTRICT G = VectorChannels.Get<1>();
		const double* RESTRICT B = VectorChannels.Get<2>();
		const double* RESTRICT A = VectorChannels.Get<3>();

		for (int32 Index = 0; Index < Num; ++Index)
		{
			TArray<UPrimitiveComponent*> PrimitiveComponents;
			AActor* Actor = Cast<AActor>(BoundObjects[Index]);
			if (!Actor)
			{
				UPrimitiveComponent* PrimitiveComponent = Cast<UPrimitiveComponent>(BoundObjects[Index]);
				if (!PrimitiveComponent)
				{
					return;
				}
				PrimitiveComponents.Add(PrimitiveComponent);
			}
			else
			{
				Actor->GetComponents(UPrimitiveComponent::StaticClass(), PrimitiveComponents);
			}
			
			FLinearColor Color(
				R ? (float)R[Index] : 1.f,
				G ? (float)G[Index] : 1.f,
				B ? (float)B[Index] : 1.f,
				A ? (float)A[Index] : 1.f
			);			

			if (SlotName->IsEmpty())
			{
				for (auto PrimitiveComponent : PrimitiveComponents)
				{
					TArray<UMaterialInterface*> UsedMaterials;
					PrimitiveComponent->GetUsedMaterials(UsedMaterials);
					for (auto MaterialInterface : UsedMaterials)
					{
						if (UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(MaterialInterface))
						{
							MID->SetVectorParameterValueByInfo(ColorParameterInfos[Index], Color);
						}
					}
				}
			}
			else
			{
				for (auto PrimitiveComponent : PrimitiveComponents)
				{
					UCutsceneUtils::ForEachMaterialOnComponentBySlotName(PrimitiveComponent, *SlotName, [&ColorParameterInfos, &Color, &Index](UMaterialInterface* MaterialInterface) {
						if (UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>(MaterialInterface))
						{
							MID->SetVectorParameterValueByInfo(ColorParameterInfos[Index], Color);
						}
					});
				}
			}
		}
	}
};
} // namespace UE::MovieScene

UMovieSceneBatchMaterialParameterEvaluationSystem::UMovieSceneBatchMaterialParameterEvaluationSystem(const FObjectInitializer& ObjInit)
	: Super(ObjInit)
{
	using namespace UE::MovieScene;

	FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
	FMovieSceneTracksComponentTypes* TracksComponents = FMovieSceneTracksComponentTypes::Get();
	FKGMovieSceneComponentType* KGComponents = FKGMovieSceneComponentType::Get();
	
	RelevantComponent = KGComponents->Tags.BatchMaterialOnActor;
	
	Phase = ESystemPhase::Scheduling;

	if (HasAnyFlags(RF_ClassDefaultObject))
	{
		DefineImplicitPrerequisite(UFloatChannelEvaluatorSystem::StaticClass(), GetClass());
		DefineImplicitPrerequisite(UMovieScenePiecewiseDoubleBlenderSystem::StaticClass(), GetClass());
		for (int32 Index = 0; Index < UE_ARRAY_COUNT(BuiltInComponents->DoubleResult); ++Index)
		{
			DefineComponentConsumer(GetClass(), BuiltInComponents->DoubleResult[Index]);
		}
		DefineComponentConsumer(GetClass(), BuiltInComponents->ObjectResult);
		DefineComponentConsumer(GetClass(), BuiltInComponents->BoundObject);
	}
}

void UMovieSceneBatchMaterialParameterEvaluationSystem::OnSchedulePersistentTasks(UE::MovieScene::IEntitySystemScheduler* TaskScheduler)
{
	using namespace UE::MovieScene;

	FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
	FMovieSceneTracksComponentTypes* TracksComponents = FMovieSceneTracksComponentTypes::Get(); 
	FKGMovieSceneComponentType* KGComponents = FKGMovieSceneComponentType::Get();
	
	FEntityTaskBuilder()
	.Read(BuiltInComponents->BoundObject)
	.Read(TracksComponents->ScalarMaterialParameterInfo)
	.Read(BuiltInComponents->DoubleResult[0])
	.Read(KGComponents->Components.BatchMaterialSlotName)
	.FilterAny({KGComponents->Tags.BatchMaterialOnActor})
	.SetDesiredThread(Linker->EntityManager.GetDispatchThread())
	.Schedule_PerAllocation<FBatchApplyScalarParameters>(&Linker->EntityManager, TaskScheduler);

	// Vectors and colors use the same API
	FEntityTaskBuilder()
	.Read(BuiltInComponents->BoundObject)
	.Read(TracksComponents->ColorMaterialParameterInfo)
	.Read(KGComponents->Components.BatchMaterialSlotName)
	.ReadOneOrMoreOf(BuiltInComponents->DoubleResult[0], BuiltInComponents->DoubleResult[1], BuiltInComponents->DoubleResult[2], BuiltInComponents->DoubleResult[3])
	.FilterAny({KGComponents->Tags.BatchMaterialOnActor})
	.SetDesiredThread(Linker->EntityManager.GetDispatchThread())
	.Schedule_PerAllocation<FBatchApplyVectorParameters>(&Linker->EntityManager, TaskScheduler);
}

void UMovieSceneBatchMaterialParameterEvaluationSystem::OnRun(FSystemTaskPrerequisites& InPrerequisites, FSystemSubsequentTasks& Subsequents)
{
	using namespace UE::MovieScene;

	FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
	FMovieSceneTracksComponentTypes* TracksComponents = FMovieSceneTracksComponentTypes::Get();
	FKGMovieSceneComponentType* KGComponents = FKGMovieSceneComponentType::Get();
	
	if (Linker->EntityManager.ContainsComponent(TracksComponents->ScalarMaterialParameterInfo))
	{
		FEntityTaskBuilder()
		.Read(BuiltInComponents->BoundObject)
		.Read(TracksComponents->ScalarMaterialParameterInfo)
		.Read(BuiltInComponents->DoubleResult[0])
		.Read(KGComponents->Components.BatchMaterialSlotName)
		.FilterAny({KGComponents->Tags.BatchMaterialOnActor})
		.SetDesiredThread(Linker->EntityManager.GetDispatchThread())
		.Dispatch_PerAllocation<FBatchApplyScalarParameters>(&Linker->EntityManager, InPrerequisites, &Subsequents);
	}

	// Vectors and colors use the same API
	if (Linker->EntityManager.ContainsComponent(TracksComponents->ColorMaterialParameterInfo))
	{
		FEntityTaskBuilder()
		.Read(BuiltInComponents->BoundObject)
		.Read(TracksComponents->ColorMaterialParameterInfo)
		.Read(KGComponents->Components.BatchMaterialSlotName)
		.ReadOneOrMoreOf(BuiltInComponents->DoubleResult[0], BuiltInComponents->DoubleResult[1], BuiltInComponents->DoubleResult[2], BuiltInComponents->DoubleResult[3])
		.FilterAny({KGComponents->Tags.BatchMaterialOnActor})
		.SetDesiredThread(Linker->EntityManager.GetDispatchThread())
		.Dispatch_PerAllocation<FBatchApplyVectorParameters>(&Linker->EntityManager, InPrerequisites, &Subsequents);
	}
}
