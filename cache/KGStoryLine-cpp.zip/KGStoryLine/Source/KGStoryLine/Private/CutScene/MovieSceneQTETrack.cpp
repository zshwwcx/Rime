#include "CutScene/MovieSceneQTETrack.h"
#include "CutScene/MovieSceneQTESection.h"
#include "CutScene/MovieSceneQTETemplate.h"

#define LOCTEXT_NAMESPACE "MovieSceneQTETrack"

UMovieSceneQTETrack::UMovieSceneQTETrack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	SupportedBlendTypes.Add(EMovieSceneBlendType::Absolute);
#if WITH_EDITORONLY_DATA
	TrackTint = FColor(249, 98, 31, 150);
#endif
}

UMovieSceneQTETrack::~UMovieSceneQTETrack()
{
}

FName UMovieSceneQTETrack::GetTrackName() const
{
	static FName QTETrackName = TEXT("QTETrack");
	return QTETrackName;
}

#if WITH_EDITORONLY_DATA
FText UMovieSceneQTETrack::GetDefaultDisplayName() const
{
	return LOCTEXT("QTETrackName", "QTETrack");
}
#endif

bool UMovieSceneQTETrack::IsEmpty() const
{
	return (Sections.Num() == 0);
}

bool UMovieSceneQTETrack::SupportsMultipleRows() const
{
	return true;
}

bool UMovieSceneQTETrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneQTESection::StaticClass();
}

FMovieSceneEvalTemplatePtr UMovieSceneQTETrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FMovieSceneQTETemplate(*CastChecked<UMovieSceneQTESection>(&InSection), *this);
}

void UMovieSceneQTETrack::AddSection(UMovieSceneSection& Section)
{
	Sections.Add(&Section);
}

UMovieSceneSection* UMovieSceneQTETrack::CreateNewSection() {
	UMovieSceneQTESection* Section = NewObject<UMovieSceneQTESection>(this, NAME_None, RF_Transactional);
	return Section;
}

const TArray<UMovieSceneSection*>& UMovieSceneQTETrack::GetAllSections() const {
	return Sections;
}

bool UMovieSceneQTETrack::HasSection(const UMovieSceneSection& Section) const {
	return Sections.Contains(&Section);
}

void UMovieSceneQTETrack::RemoveSectionAt(int32 SectionIndex) {
	if (Sections.IsValidIndex(SectionIndex))
	{
		Sections.RemoveAt(SectionIndex);
	}
}

void UMovieSceneQTETrack::RemoveSection(UMovieSceneSection& Section) {
	Sections.Remove(&Section);
}

#undef LOCTEXT_NAMESPACE
