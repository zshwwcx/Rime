// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "CoreTypes.h"
#include "Math/Quat.h"
#include "Math/Rotator.h"
#include "Math/Transform.h"
#include "Math/UnrealMathSSE.h"
#include "Math/Vector.h"
#include "UObject/ObjectMacros.h"

#include "LookAtTransform.generated.h"

class UScriptStruct;
template <class T> struct TBaseStructure;

UENUM()
enum class ELookAtRotationOrder : uint8
{
	XYZ,
	XZY,
	YXZ,
	YZX,
	ZXY,
	ZYX
};

USTRUCT(BlueprintType)
struct FLookAtTransform
{
	GENERATED_BODY()

	typedef FVector::FReal FReal;

	/**
	 * The identity transformation (Rotation = FRotator::ZeroRotator, Translation = FVector::ZeroVector, Body = (1,1,1)).
	 */
	static ANIMATIONCORE_API const FLookAtTransform Identity;

	FORCEINLINE FLookAtTransform()
		: Eye(ForceInitToZero)
		, Head(ForceInitToZero)
		, Body(ForceInitToZero)
		, Spine_01(ForceInitToZero)
		, Spine_02(ForceInitToZero)
		, Spine_03(ForceInitToZero)
	{
	}

	FORCEINLINE FLookAtTransform(const FRotator& InEye, const FRotator& InHead, const FRotator& InBody, const FRotator& InSpine_01, const FRotator& InSpine_02, const FRotator& InSpine_03)
		: Eye(InEye)
		, Head(InHead)
		, Body(InBody)
		, Spine_01(InSpine_01)
		, Spine_02(InSpine_02)
		, Spine_03(InSpine_03)
	{
	}

	/*FORCEINLINE explicit FLookAtTransform(const FTransform& InTransform)
		: Eye(InTransform.GetEye())
		, Head(InTransform.GetHead().Rotator())
		, Body(InTransform.GetBody3D())
	{

	}*/

	/** The translation of this transform */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Transform")
	FRotator Eye;

	/** The Head of this transform */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Transform")
	FRotator Head;

	/** The Body of this transform */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Transform")
	FRotator Body;

	/** The Body of this transform */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform")
	FRotator Spine_01;

	/** The Body of this transform */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform")
	FRotator Spine_02;

	/** The Body of this transform */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform")
	FRotator Spine_03;

	///** Convert to an FTransform */
	//FORCEINLINE FTransform ToFTransform() const
	//{
	//	return FTransform(Head.Quaternion(), Eye, Body);
	//}

	///** Convert from an FTransform */
	//FORCEINLINE void FromFTransform(const FTransform& InTransform)
	//{
	//	Eye = InTransform.GetEye().Rotator();
	//	Head = InTransform.GetHead().Rotator();
	//	Body = InTransform.GetBody().Rotator();
	//}

	// Test if all components of the transforms are equal, within a tolerance.
	FORCEINLINE bool Equals(const FLookAtTransform& Other, FReal Tolerance = KINDA_SMALL_NUMBER) const
	{
		return Eye.Equals(Other.Eye, Tolerance) &&
			Head.Equals(Other.Head, Tolerance) &&
			Body.Equals(Other.Body, Tolerance) &&
			Spine_01.Equals(Other.Spine_01, Tolerance)&&
			Spine_02.Equals(Other.Spine_02, Tolerance)&&
			Spine_03.Equals(Other.Spine_03, Tolerance);
	}

	FORCEINLINE const FQuat GetEye() const { return Eye.Quaternion(); }
	FORCEINLINE const FQuat GetHead() const { return Head.Quaternion(); }
	//FORCEINLINE const FRotator& Head() const { return Head; }
	FORCEINLINE const FQuat GetBody() const { return Body.Quaternion(); }
	FORCEINLINE const FQuat GetSpine_01() const { return Spine_01.Quaternion(); }
	FORCEINLINE const FQuat GetSpine_02() const { return Spine_02.Quaternion(); }
	FORCEINLINE const FQuat GetSpine_03() const { return Spine_03.Quaternion(); }
	FORCEINLINE void SetEye(const FQuat& InValue) { Eye = InValue.Rotator(); }
	FORCEINLINE void SetEye(const FRotator& InValue) { Eye = InValue; }
	FORCEINLINE void SetHead(const FQuat& InValue) { Head = InValue.Rotator(); }
	FORCEINLINE void SetHead(const FRotator& InValue) { Head = InValue; }
	FORCEINLINE void SetBody(const FQuat& InValue) { Body = InValue.Rotator(); }
	FORCEINLINE void SetBody(const FRotator& InValue) { Body = InValue; }
	FORCEINLINE void SetSpine_01(const FQuat& InValue) { Spine_01 = InValue.Rotator(); }
	FORCEINLINE void SetSpine_01(const FRotator& InValue) { Spine_01 = InValue; }
	FORCEINLINE void SetSpine_02(const FQuat& InValue) { Spine_02 = InValue.Rotator(); }
	FORCEINLINE void SetSpine_02(const FRotator& InValue) { Spine_02 = InValue; }
	FORCEINLINE void SetSpine_03(const FQuat& InValue) { Spine_03 = InValue.Rotator(); }
	FORCEINLINE void SetSpine_03(const FRotator& InValue) { Spine_03 = InValue; }
	FORCEINLINE void NormalizeHead() {}
};

template<> struct TBaseStructure<FLookAtTransform>
{
	static UScriptStruct* Get() { return FLookAtTransform::StaticStruct(); }
};
