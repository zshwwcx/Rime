// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#include "CutScene/MovieSceneGazeTrack.h"

#include "Sequence/KGSequenceManager.h"
#include "3C/Util/KGUtils.h"

#define LOCTEXT_NAMESPACE "MovieSceneGazeTrack"

void FMovieSceneGazeProxy::Setup(IMovieScenePlayer& Player)
{
	if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
	{
		Manager->CallCustomProxyFunction("MovieSceneGazeProxy", "Setup");
	}
}

void FMovieSceneGazeProxy::StartCutsceneGaze(IMovieScenePlayer& Player, int64 OwnerActorID, int64 TargetActorID, const FString& BoneName, FVector Offset)
{
	if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
	{
		Manager->CallCustomProxyFunction("MovieSceneGazeProxy", "StartCutsceneGaze", OwnerActorID, TargetActorID, BoneName, Offset);
	}
}

void FMovieSceneGazeProxy::StopCutsceneGaze(IMovieScenePlayer& Player, int64 OwnerActorID, int64 TargetActorID, const FString& BoneName, FVector Offset)
{
	if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
	{
		Manager->CallCustomProxyFunction("MovieSceneGazeProxy", "StopCutsceneGaze", OwnerActorID, TargetActorID, BoneName, Offset);
	}
}

UMovieSceneGazeTrack::UMovieSceneGazeTrack(const FObjectInitializer& ObjectInitializer)
{
	SupportedBlendTypes.Add(EMovieSceneBlendType::Absolute);
}

FMovieSceneEvalTemplatePtr UMovieSceneGazeTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FMovieSceneGazeSectionTemplate(*CastChecked<UMovieSceneGazeSection>(&InSection), *this);
}

bool UMovieSceneGazeTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneGazeSection::StaticClass();
}

UMovieSceneSection* UMovieSceneGazeTrack::CreateNewSection()
{
	return NewObject<UMovieSceneGazeSection>(this, NAME_None, RF_Transactional);
}

const TArray<UMovieSceneSection*>& UMovieSceneGazeTrack::GetAllSections() const
{
	return Sections;
}

void UMovieSceneGazeTrack::AddSection(UMovieSceneSection& Section)
{
	Sections.Emplace(&Section);
}

bool UMovieSceneGazeTrack::HasSection(const UMovieSceneSection& Section) const
{
	return Sections.Contains(&Section);
}

bool UMovieSceneGazeTrack::IsEmpty() const
{
	return Sections.Num() == 0;
}

void UMovieSceneGazeTrack::RemoveSection(UMovieSceneSection& Section)
{
	if (Sections.Contains(&Section))
		Sections.Remove(&Section);
}

void UMovieSceneGazeTrack::RemoveSectionAt(int32 SectionIndex)
{
	if (Sections.IsValidIndex(SectionIndex))
		Sections.RemoveAt(SectionIndex);
}

#if WITH_EDITORONLY_DATA
FText UMovieSceneGazeTrack::GetDisplayName() const
{
	return LOCTEXT("GazeDisplayName", "LookAtTarget");
}
#endif

struct FGazeEvaluationData final : IPersistentEvaluationData
{
	bool bStarted = false;
	KGObjectID OwnerID = KG_INVALID_ID;
	KGObjectID TargetID = KG_INVALID_ID;
	FMovieSceneEvaluationOperand Operand;
};

struct FGazeExecutionToken : IMovieSceneExecutionToken
{
	TWeakObjectPtr<const UMovieSceneGazeSection> WeakSection;

	explicit FGazeExecutionToken(const UMovieSceneGazeSection* InSection):WeakSection(InSection)
	{}
	
	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
		if (!ensure(PersistentData.FindSectionData<FGazeEvaluationData>()))
			return;

		if (!WeakSection.IsValid())
			return;
		
		FGazeEvaluationData& Data = PersistentData.GetSectionData<FGazeEvaluationData>();
		UMovieSceneGazeTrack* Track = Cast<UMovieSceneGazeTrack>(WeakSection->GetTypedOuter<UMovieSceneGazeTrack>());
		if (!(ensure(Track)))
			return;
		
		if (!Data.bStarted || Track->bDataModified)
		{
			Data.Operand = Operand;

			const TArrayView<TWeakObjectPtr<>> Owners = Player.FindBoundObjects(Data.Operand.ObjectBindingID, Data.Operand.SequenceID);
			const TArrayView<TWeakObjectPtr<>> Targets = Player.FindBoundObjects(WeakSection->ObjectBindingId, Data.Operand.SequenceID);
			if (Owners.Num() > 0 && Targets.Num() > 0)
			{
				const KGObjectID OwnerID = KGUtils::GetIDByObject(Owners[0].Get());
				const KGObjectID TargetID = KGUtils::GetIDByObject(Targets[0].Get());
				
				Data.OwnerID = OwnerID;
				Data.TargetID = TargetID;
				Data.bStarted = true;
				if (Track->bDataModified)
				{
					FMovieSceneGazeProxy::StopCutsceneGaze(Player, OwnerID, TargetID, WeakSection->BoneName, WeakSection->Offset);	
				}
				FMovieSceneGazeProxy::StartCutsceneGaze(Player, OwnerID, TargetID, WeakSection->BoneName, WeakSection->Offset);
				Track->bDataModified = false;
			}
		}
	}
};

FMovieSceneGazeSectionTemplate::FMovieSceneGazeSectionTemplate(const UMovieSceneGazeSection& Section, const UMovieSceneGazeTrack& Track)
{
}

void FMovieSceneGazeSectionTemplate::SetupOverrides()
{
	EnableOverrides(RequiresSetupFlag | RequiresTearDownFlag);
}

void FMovieSceneGazeSectionTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	if (Context.IsPreRoll() || Context.IsPostRoll())
		return;
	
	const UMovieSceneGazeSection* Section = Cast<UMovieSceneGazeSection>(GetSourceSection());
	if (!(ensure(Section)))
		return;

	ExecutionTokens.Add(FGazeExecutionToken(Section));
}

void FMovieSceneGazeSectionTemplate::Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	PersistentData.AddSectionData<FGazeEvaluationData>();
	
	const UMovieSceneGazeSection* Section = Cast<UMovieSceneGazeSection>(GetSourceSection());
	if (!(ensure(Section)))
		return;

	UMovieSceneGazeTrack* Track = Cast<UMovieSceneGazeTrack>(Section->GetTypedOuter<UMovieSceneGazeTrack>());
	if (!(ensure(Track)))
		return;
	
	FMovieSceneGazeProxy::Setup(Player);
}

void FMovieSceneGazeSectionTemplate::TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	const UMovieSceneGazeSection* Section = Cast<UMovieSceneGazeSection>(GetSourceSection());
	if (!(ensure(Section)))
		return;

	UMovieSceneGazeTrack* Track = Cast<UMovieSceneGazeTrack>(Section->GetTypedOuter<UMovieSceneGazeTrack>());
	if (!(ensure(Track)))
		return;
	
	if (!PersistentData.FindSectionData<FGazeEvaluationData>())
		return;
	const FGazeEvaluationData& Data = PersistentData.GetSectionData<FGazeEvaluationData>();
	FMovieSceneGazeProxy::StopCutsceneGaze(Player, Data.OwnerID, Data.TargetID, Section->BoneName, Section->Offset);
	PersistentData.ResetSectionData();
}

#undef LOCTEXT_NAMESPACE
