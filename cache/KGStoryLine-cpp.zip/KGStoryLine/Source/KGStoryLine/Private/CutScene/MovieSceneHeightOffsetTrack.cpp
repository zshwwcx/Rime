// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com
#include "CutScene/MovieSceneHeightOffsetTrack.h"

#include "Sequence/KGSequenceManager.h"
#include "3C/Util/KGUtils.h"
#include "CutScene/MovieSceneCustomTrack.h"

#define LOCTEXT_NAMESPACE "MovieSceneHeightOffsetTrack"

void FMovieSceneHeightOffsetProxy::Execute(IMovieScenePlayer& Player, const UMovieSceneHeightOffsetSection* MovieSceneCustomSection, int64 ActorID, float CurrentTime, int32 LoadHandle)
{
	if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
	{
		int64 MovieSceneCustomSectionID = KGUtils::GetIDByObject(const_cast<UMovieSceneHeightOffsetSection*>(MovieSceneCustomSection));
		Manager->CallCustomProxyFunction("MovieSceneHeightOffsetProxy", "Execute", MovieSceneCustomSectionID, ActorID, CurrentTime, LoadHandle);
	}
}

void FMovieSceneHeightOffsetProxy::SetUp(IMovieScenePlayer& Player, const UMovieSceneHeightOffsetSection* MovieSceneCustomSection, int32 LoadHandle)
{
	if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
	{
		int64 MovieSceneCustomSectionID = KGUtils::GetIDByObject(const_cast<UMovieSceneHeightOffsetSection*>(MovieSceneCustomSection));
		Manager->CallCustomProxyFunction("MovieSceneHeightOffsetProxy", "SetUp", MovieSceneCustomSectionID, LoadHandle);
	}
}

void FMovieSceneHeightOffsetProxy::TearDown(IMovieScenePlayer& Player, const UMovieSceneHeightOffsetSection* MovieSceneCustomSection, int32 LoadHandle)
{
	if (UKGSequenceManager* Manager = UKGSequenceManager::GetSequenceManager(Player))
	{
		int64 MovieSceneCustomSectionID = KGUtils::GetIDByObject(const_cast<UMovieSceneHeightOffsetSection*>(MovieSceneCustomSection));
		Manager->CallCustomProxyFunction("MovieSceneHeightOffsetProxy", "TearDown", MovieSceneCustomSectionID, LoadHandle);
	}
}

float UMovieSceneHeightOffsetSection::Sample(const float Time) const
{
	const int32 LowerIndex = FMath::Clamp(FMath::FloorToInt32(Time / SampleRate), 0, SampleHeights.Num() - 1);
	const int32 UpperIndex = FMath::Clamp(FMath::CeilToInt32(Time / SampleRate), 0, SampleHeights.Num() - 1);
	const float LowerHeight = SampleHeights[LowerIndex];
	const float UpperHeight = SampleHeights[UpperIndex];
	const float Height = FMath::Lerp(LowerHeight, UpperHeight, FMath::Fractional(Time / SampleRate));
	return Height;
}

UMovieSceneHeightOffsetTrack::UMovieSceneHeightOffsetTrack(const FObjectInitializer& ObjectInitializer)
{
	SupportedBlendTypes.Add(EMovieSceneBlendType::Absolute);
}

FMovieSceneEvalTemplatePtr UMovieSceneHeightOffsetTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FMovieSceneHeightOffsetSectionTemplate(*CastChecked<UMovieSceneHeightOffsetSection>(&InSection), *this);
}

bool UMovieSceneHeightOffsetTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneHeightOffsetSection::StaticClass();
}

UMovieSceneSection* UMovieSceneHeightOffsetTrack::CreateNewSection()
{
	return NewObject<UMovieSceneHeightOffsetSection>(this, NAME_None, RF_Transactional);
}

const TArray<UMovieSceneSection*>& UMovieSceneHeightOffsetTrack::GetAllSections() const
{
	return Sections;
}

void UMovieSceneHeightOffsetTrack::AddSection(UMovieSceneSection& Section)
{
	Sections.Emplace(&Section);
}

bool UMovieSceneHeightOffsetTrack::HasSection(const UMovieSceneSection& Section) const
{
	return Sections.Contains(&Section);
}

void UMovieSceneHeightOffsetTrack::RemoveSection(UMovieSceneSection& Section)
{
	if (Sections.Contains(&Section))
		Sections.Remove(&Section);
}

void UMovieSceneHeightOffsetTrack::RemoveSectionAt(int32 SectionIndex)
{
	if (Sections.IsValidIndex(SectionIndex))
		Sections.RemoveAt(SectionIndex);
}

bool UMovieSceneHeightOffsetTrack::IsEmpty() const
{
	return Sections.Num() == 0;
}

#if WITH_EDITORONLY_DATA
FText UMovieSceneHeightOffsetTrack::GetDisplayName() const
{
	return LOCTEXT("HeightOffsetDisplayName", "高度偏移");
}
#endif

struct FHeightOffsetExecutionToken : IMovieSceneExecutionToken
{
	TWeakObjectPtr<const UMovieSceneHeightOffsetSection> WeakSection;

	explicit FHeightOffsetExecutionToken(const UMovieSceneHeightOffsetSection* InSection):WeakSection(InSection)
	{}
	
	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
		if (!WeakSection.IsValid())
			return;
		
		UMovieSceneHeightOffsetTrack* Track = Cast<UMovieSceneHeightOffsetTrack>(WeakSection->GetTypedOuter<UMovieSceneHeightOffsetTrack>());
		if (!(ensure(Track)))
			return;

		const TArrayView<TWeakObjectPtr<>> Owners = Player.FindBoundObjects(Operand.ObjectBindingID, Operand.SequenceID);
		if (Owners.Num() > 0)
		{
			const KGObjectID OwnerID = KGUtils::GetIDByObject(Owners[0].Get());
			float CurrentTime = Context.GetFrameRate().AsSeconds(Context.GetTime());
			int LoadHandleID = -1;
			if (UKGSequenceManager* KGSequenceManager = UMovieSceneCustomTrack::GetSequenceManager(Player))
				LoadHandleID = KGSequenceManager->GetSequenceLoadHandleIDByMoviePlayer(Player);
			FMovieSceneHeightOffsetProxy::Execute(Player, WeakSection.Get(), OwnerID, CurrentTime, LoadHandleID);	
		}
	}
};

FMovieSceneHeightOffsetSectionTemplate::FMovieSceneHeightOffsetSectionTemplate(const UMovieSceneHeightOffsetSection& Section, const UMovieSceneHeightOffsetTrack& Track)
{
}

void FMovieSceneHeightOffsetSectionTemplate::SetupOverrides()
{
	EnableOverrides(RequiresSetupFlag | RequiresTearDownFlag);
}

void FMovieSceneHeightOffsetSectionTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	if (Context.IsPreRoll() || Context.IsPostRoll())
		return;
	
	const UMovieSceneHeightOffsetSection* Section = Cast<UMovieSceneHeightOffsetSection>(GetSourceSection());
	if (!(ensure(Section)))
		return;

	ExecutionTokens.Add(FHeightOffsetExecutionToken(Section));
}

void FMovieSceneHeightOffsetSectionTemplate::Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	const UMovieSceneHeightOffsetSection* Section = Cast<UMovieSceneHeightOffsetSection>(GetSourceSection());
	if (!(ensure(Section)))
		return;

	UMovieSceneHeightOffsetTrack* Track = Cast<UMovieSceneHeightOffsetTrack>(Section->GetTypedOuter<UMovieSceneHeightOffsetTrack>());
	if (!(ensure(Track)))
		return;
	
	int LoadHandleID = -1;
	if (UKGSequenceManager* KGSequenceManager = UMovieSceneCustomTrack::GetSequenceManager(Player))
		LoadHandleID = KGSequenceManager->GetSequenceLoadHandleIDByMoviePlayer(Player);
	FMovieSceneHeightOffsetProxy::SetUp(Player, Section, LoadHandleID);
}

void FMovieSceneHeightOffsetSectionTemplate::TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	const UMovieSceneHeightOffsetSection* Section = Cast<UMovieSceneHeightOffsetSection>(GetSourceSection());
	if (!(ensure(Section)))
		return;

	UMovieSceneHeightOffsetTrack* Track = Cast<UMovieSceneHeightOffsetTrack>(Section->GetTypedOuter<UMovieSceneHeightOffsetTrack>());
	if (!(ensure(Track)))
		return;
	
	int LoadHandleID = -1;
	if (UKGSequenceManager* KGSequenceManager = UMovieSceneCustomTrack::GetSequenceManager(Player))
		LoadHandleID = KGSequenceManager->GetSequenceLoadHandleIDByMoviePlayer(Player);
	FMovieSceneHeightOffsetProxy::TearDown(Player, Section, LoadHandleID);
}

#undef LOCTEXT_NAMESPACE
