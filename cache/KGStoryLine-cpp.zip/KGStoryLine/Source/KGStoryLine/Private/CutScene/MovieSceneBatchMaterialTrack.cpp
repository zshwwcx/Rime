// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "CutScene/MovieSceneBatchMaterialTrack.h"
#include "EntitySystem/BuiltInComponentTypes.h"
#include "CutScene/KGMovieSceneComponentType.h"
#include "CutScene/MovieSceneBatchMaterialParameterSection.h"

UMovieSceneBatchMaterialTrack::UMovieSceneBatchMaterialTrack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
#if WITH_EDITORONLY_DATA
	TrackTint = FColor(64,192,64,65);
#endif

	BuiltInTreePopulationMode = ETreePopulationMode::Blended;

	SupportedBlendTypes.Add(EMovieSceneBlendType::Absolute);
	SupportedBlendTypes.Add(EMovieSceneBlendType::Additive);
	SupportedBlendTypes.Add(EMovieSceneBlendType::AdditiveFromBase);
}

bool UMovieSceneBatchMaterialTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneBatchMaterialParameterSection::StaticClass();
}

UMovieSceneSection* UMovieSceneBatchMaterialTrack::CreateNewSection()
{
	UMovieSceneSection* NewSection = NewObject<UMovieSceneBatchMaterialParameterSection>(this, NAME_None, RF_Transactional);
	NewSection->SetBlendType(EMovieSceneBlendType::Absolute);
	return NewSection;
}

void UMovieSceneBatchMaterialTrack::ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity)
{
}

bool UMovieSceneBatchMaterialTrack::PopulateEvaluationFieldImpl(const TRange<FFrameNumber>& EffectiveRange, const FMovieSceneEvaluationFieldEntityMetaData& InMetaData, FMovieSceneEntityComponentFieldBuilder* OutFieldBuilder)
{
	const FMovieSceneTrackEvaluationField& LocalEvaluationField = GetEvaluationField();

	// Define entities for the old style parameter sections. BatchMaterialParameterSection define their own.
	for (const FMovieSceneTrackEvaluationFieldEntry& Entry : LocalEvaluationField.Entries)
	{
		UMovieSceneParameterSection* ParameterSection = Cast<UMovieSceneParameterSection>(Entry.Section);
		UMovieSceneBatchMaterialParameterSection* BatchMaterialParameterSection = Cast<UMovieSceneBatchMaterialParameterSection>(Entry.Section);
		if (ParameterSection || BatchMaterialParameterSection)
		{
			if (IsRowEvalDisabled(Entry.Section->GetRowIndex()))
			{
				continue;
			}

			TRange<FFrameNumber> SectionEffectiveRange = TRange<FFrameNumber>::Intersection(EffectiveRange, Entry.Range);
			if (!SectionEffectiveRange.IsEmpty())
			{
				FMovieSceneEvaluationFieldEntityMetaData SectionMetaData = InMetaData;
				SectionMetaData.Flags = Entry.Flags;
				if (ParameterSection)
				{
					ParameterSection->ExternalPopulateEvaluationField(SectionEffectiveRange, SectionMetaData, OutFieldBuilder);
				}
				else if (BatchMaterialParameterSection)
				{
					BatchMaterialParameterSection->ExternalPopulateEvaluationField(SectionEffectiveRange, SectionMetaData, OutFieldBuilder);
				}
			}
		}
	}

	return true;
}

void UMovieSceneBatchMaterialTrack::ExtendEntityImpl(UMovieSceneParameterSection* Section, UMovieSceneEntitySystemLinker* EntityLinker, const UE::MovieScene::FEntityImportParams& Params, UE::MovieScene::FImportedEntity* OutImportedEntity)
{
	using namespace UE::MovieScene;

	FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
	OutImportedEntity->AddBuilder(
	FEntityBuilder()
	.AddTag(FKGMovieSceneComponentType::Get()->Tags.BatchMaterialOnActor)
	// If the section has no valid blend type (legacy data), make it use absolute blending.
	// Otherwise, the base section class will add the appropriate blend type tag in BuildDefaultComponents.
	.AddTagConditional(BuiltInComponents->Tags.AbsoluteBlend, !Section->GetBlendType().IsValid())
);
}

#if WITH_EDITOR
FText UMovieSceneBatchMaterialTrack::GetDisplayNameToolTipText(const FMovieSceneLabelParams& LabelParams) const
{
	//@todo, set display text
	return Super::GetDisplayNameToolTipText(LabelParams);
}
#endif

#if WITH_EDITORONLY_DATA
FText UMovieSceneBatchMaterialTrack::GetDefaultDisplayName() const
{
	// Old track name before we started naming directly from editor
	return FText::FromString(TEXT("BatchMaterialTrack ") + SlotName.ToString());
}
#endif