// Fill out your copyright notice in the Description page of Project Settings.

#include "CutScene/CutsceneUtils.h"
#include "Components/PrimitiveComponent.h"
#include "Components/MeshComponent.h"

void UCutsceneUtils::ForEachMaterialOnComponentBySlotName(UPrimitiveComponent* PrimitiveComponent, FText SlotName, TFunctionRef<void(UMaterialInterface*)> ProcessFunction)
{
	const TArray<FName>& MaterialSlotNames = PrimitiveComponent->GetMaterialSlotNames();
	for (size_t i = 0; i < MaterialSlotNames.Num(); i++)
	{
		if (MaterialSlotNames[i] == SlotName.ToString()) {
			UMaterialInterface* MaterialInterface = PrimitiveComponent->GetMaterial(i);
			if (MaterialInterface)
			{
				ProcessFunction(MaterialInterface);
			}
		}
	}

	UMeshComponent* ToMeshComponent = Cast<UMeshComponent>(PrimitiveComponent);
	if (ToMeshComponent)
	{
		const TArray<FName>& SeperateOverlayMaterialSlotNames  = ToMeshComponent->GetSeperateOverlayMaterialSlotNames();
		for (size_t i = 0; i < SeperateOverlayMaterialSlotNames.Num(); i++)
		{
			if (SeperateOverlayMaterialSlotNames[i] == SlotName.ToString()) {
				UMaterialInterface* MaterialInterface = ToMeshComponent->GetSeperateOverlayMaterial(i);
				if (MaterialInterface)
				{
					ProcessFunction(MaterialInterface);
				}
			}
		}

		const TArray<FName>& RuntimeSeperateOverlayMaterialSlotNames = ToMeshComponent->GetRuntimeSeperateOverlayMaterialSlotNames();
		for (size_t i = 0; i < RuntimeSeperateOverlayMaterialSlotNames.Num(); i++)
		{
			if (RuntimeSeperateOverlayMaterialSlotNames[i] == SlotName.ToString()) {
				UMaterialInterface* MaterialInterface = ToMeshComponent->GetRuntimeSeperateOverlayMaterial(i);
				if (MaterialInterface)
				{
					ProcessFunction(MaterialInterface);
				}
			}
		}
	}
}