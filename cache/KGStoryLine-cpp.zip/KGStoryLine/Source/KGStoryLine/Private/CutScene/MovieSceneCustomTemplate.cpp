#include "CutScene/MovieSceneCustomTemplate.h"
#include "CutScene/MovieSceneCustomSection.h"
#include "Engine/Engine.h"

#if WITH_EDITOR
#include "Editor.h"
#include "LevelSequenceEditorBlueprintLibrary.h"
#endif

#if WITH_EDITOR
#define CHECK_TRANSACTION() \
	if (GEditor && GEditor->IsTransactionActive())\
	{\
		UE_LOG(LogTemp, Warning, TEXT("Transaction is active, skip execute custom track section")); \
		bNeedUpdateAfterTransactionFinished = true;\
		return; \
	}\
	else if (bNeedUpdateAfterTransactionFinished)\
	{\
		ULevelSequenceEditorBlueprintLibrary::RefreshCurrentLevelSequence();\
		bNeedUpdateAfterTransactionFinished = false; \
	}
#else
#define CHECK_TRANSACTION()
#endif

struct FCustomSectionExecutionToken : IMovieSceneExecutionToken
{
	FCustomSectionExecutionToken(const UMovieSceneCustomSection* InSection)
		: CustomSection(InSection)
	{}
	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
		UMovieSceneCustomTrack* CustomTrack = Cast<UMovieSceneCustomTrack>(CustomSection->GetOuter());
		for (auto ObjectPtr : Player.FindBoundObjects(Operand))
		{
			if (const auto Object = ObjectPtr.Get())
			{
				if (AActor* Actor = Cast<AActor>(Object))
				{
					CustomTrack->Actor = Actor;
					break;
				}
			}
		}
		float CurrentTime = Context.GetFrameRate().AsSeconds(Context.GetTime());
		CustomTrack->Execute(CustomSection.Get(), CustomTrack->Actor.Get(), CurrentTime, Player);
		
	}
	const TWeakObjectPtr<const UMovieSceneCustomSection> CustomSection;
	FObjectKey SectionKey;
};

FMovieSceneCustomTemplate::FMovieSceneCustomTemplate()
{
}

FMovieSceneCustomTemplate::FMovieSceneCustomTemplate(const UMovieSceneCustomSection& Section, const UMovieSceneCustomTrack& Track)
{
}


void FMovieSceneCustomTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	CHECK_TRANSACTION();
	if (Context.GetStatus() != EMovieScenePlayerStatus::Jumping)
	{
		const UMovieSceneCustomSection* CustomSection = Cast<UMovieSceneCustomSection>(GetSourceSection());
		ExecutionTokens.Add(FCustomSectionExecutionToken(CustomSection));
	}
}

void FMovieSceneCustomTemplate::Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	CHECK_TRANSACTION();
	const UMovieSceneCustomSection* CustomSection = Cast<UMovieSceneCustomSection>(GetSourceSection());
	UMovieSceneCustomTrack* CustomTrack = Cast<UMovieSceneCustomTrack>(CustomSection->GetOuter());
	CustomTrack->SetUp(CustomSection, Player);
}

void FMovieSceneCustomTemplate::TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	// CHECK_TRANSACTION();
	if (!SourceSectionPtr.IsValid())
	{
		return;
	}
	
	const UMovieSceneCustomSection* CustomSection = Cast<UMovieSceneCustomSection>(GetSourceSection());
	UMovieSceneCustomTrack* CustomTrack = Cast<UMovieSceneCustomTrack>(CustomSection->GetOuter());
	if(CustomTrack)
	{
		if (CustomTrack->Actor.IsValid())
		{
			CustomTrack->TearDown(CustomSection, CustomTrack->Actor.Get(), Player);
		}
		else
		{
			CustomTrack->TearDown(CustomSection, nullptr, Player);
		}
	}
}
