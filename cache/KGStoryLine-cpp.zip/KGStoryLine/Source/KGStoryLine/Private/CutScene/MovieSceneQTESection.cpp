#include "CutScene/MovieSceneQTESection.h"

UMovieSceneQTESection::UMovieSceneQTESection(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

UMovieSceneQTESection::~UMovieSceneQTESection()
{
}

#if WITH_EDITOR
void UMovieSceneQTESection::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) {

	Super::PostEditChangeProperty(PropertyChangedEvent);
	OnQTESectionPostEditChangePropertyDelegate.ExecuteIfBound();
}
#endif