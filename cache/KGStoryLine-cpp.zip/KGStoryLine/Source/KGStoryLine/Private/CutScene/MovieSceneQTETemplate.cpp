#include "CutScene/MovieSceneQTETemplate.h"

#include "Sequence/KGSequenceManager.h"
#include "CutScene/MovieSceneQTESection.h"
#include "Engine/Engine.h"
#include "3C/Util/KGUtils.h"
#include "CutScene/MovieSceneCustomTrack.h"



struct FQTESectionExecutionToken : IMovieSceneExecutionToken
{
	FQTESectionExecutionToken(const UMovieSceneQTESection* InSection)
		: QTESection(const_cast<UMovieSceneQTESection*>(InSection))
	{}
	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
		if (!QTESection.IsValid())
			return;
		
		UMovieSceneQTETrack* Track = Cast<UMovieSceneQTETrack>(QTESection->GetTypedOuter<UMovieSceneQTETrack>());
		if (!(ensure(Track)))
			return;

		float CurrentTime = Context.GetFrameRate().AsSeconds(Context.GetTime());
		int LoadHandleID = -1;
		if (UKGSequenceManager* KGSequenceManager = UMovieSceneCustomTrack::GetSequenceManager(Player))
			LoadHandleID = KGSequenceManager->GetSequenceLoadHandleIDByMoviePlayer(Player);
		FMovieSceneQTEProxy::Execute(Player, QTESection.Get(), CurrentTime, LoadHandleID);	
	}

	
	const TWeakObjectPtr<UMovieSceneQTESection> QTESection;
	FObjectKey SectionKey;
};

FMovieSceneQTETemplate::FMovieSceneQTETemplate()
{
}

FMovieSceneQTETemplate::FMovieSceneQTETemplate(const UMovieSceneQTESection& Section, const UMovieSceneQTETrack& Track)
{
}


void FMovieSceneQTETemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	if (Context.GetStatus() != EMovieScenePlayerStatus::Jumping)
	{
		const UMovieSceneQTESection* QTESection = Cast<UMovieSceneQTESection>(GetSourceSection());
		ExecutionTokens.Add(FQTESectionExecutionToken(QTESection));
	}
}

void FMovieSceneQTETemplate::Setup(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	const UMovieSceneQTESection* QTESection = Cast<UMovieSceneQTESection>(GetSourceSection());
	if (!QTESection)
	{
		return;	
	}
	int LoadHandleID = -1;
	if (UKGSequenceManager* KGSequenceManager = UMovieSceneCustomTrack::GetSequenceManager(Player))
		LoadHandleID = KGSequenceManager->GetSequenceLoadHandleIDByMoviePlayer(Player);
	FMovieSceneQTEProxy::SetUp(Player, QTESection, LoadHandleID);
}

void FMovieSceneQTETemplate::TearDown(FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	const UMovieSceneQTESection* QTESection = Cast<UMovieSceneQTESection>(GetSourceSection());
	if (!QTESection)
	{
		return;	
	}
	int LoadHandleID = -1;
	if (UKGSequenceManager* KGSequenceManager = UMovieSceneCustomTrack::GetSequenceManager(Player))
		LoadHandleID = KGSequenceManager->GetSequenceLoadHandleIDByMoviePlayer(Player);
	FMovieSceneQTEProxy::TearDown(Player, QTESection, LoadHandleID);
}
