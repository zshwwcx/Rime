#include "CutScene/MovieSceneResizeBoundsTrack.h"

#include "MovieScene.h"
#include "CutScene/MovieSceneResizeBoundsSection.h"

#define LOCTEXT_NAMESPACE "UMovieSceneResizeBoundsTrack"

UMovieSceneResizeBoundsTrack::UMovieSceneResizeBoundsTrack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UMovieSceneResizeBoundsTrack::AddSection(UMovieSceneSection& Section)
{
	Sections.Add(&Section);
}

UMovieSceneSection* UMovieSceneResizeBoundsTrack::CreateNewSection()
{
	return NewObject<UMovieSceneResizeBoundsSection>(this, NAME_None, RF_Transactional);
}

const TArray<UMovieSceneSection*>& UMovieSceneResizeBoundsTrack::GetAllSections() const
{
	return Sections;
}

bool UMovieSceneResizeBoundsTrack::HasSection(const UMovieSceneSection& Section) const
{
	return Sections.Contains(&Section);
}

bool UMovieSceneResizeBoundsTrack::IsEmpty() const
{
	return Sections.Num() == 0;
}

void UMovieSceneResizeBoundsTrack::RemoveSectionAt(int32 SectionIndex)
{
	if (Sections.IsValidIndex(SectionIndex))
	{
		Sections.RemoveAt(SectionIndex);
	}
}

void UMovieSceneResizeBoundsTrack::RemoveSection(UMovieSceneSection& Section)
{
	Sections.Remove(&Section);
}

FName UMovieSceneResizeBoundsTrack::GetTrackName() const
{
	return TEXT("ResizeBoundsTrack");
}

bool UMovieSceneResizeBoundsTrack::SupportsMultipleRows() const
{
	return false;
}

bool UMovieSceneResizeBoundsTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneResizeBoundsSection::StaticClass();
}

#if WITH_EDITORONLY_DATA
FText UMovieSceneResizeBoundsTrack::GetDefaultDisplayName() const
{
	return LOCTEXT("ResizeBoundsTrackName", "ResizeBoundsScale");
}
#endif

FMovieSceneEvalTemplatePtr UMovieSceneResizeBoundsTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FMovieSceneResizeBoundsTemplate();
}

#undef LOCTEXT_NAMESPACE



