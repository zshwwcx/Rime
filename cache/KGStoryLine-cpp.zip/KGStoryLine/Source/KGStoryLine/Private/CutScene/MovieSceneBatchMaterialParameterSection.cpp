// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "CutScene/MovieSceneBatchMaterialParameterSection.h"

#include "EntitySystem/BuiltInComponentTypes.h"
#include "CutScene/KGMovieSceneComponentType.h"
#include "MovieSceneTracksComponentTypes.h"
#include "CutScene/MovieSceneBatchMaterialTrack.h"

UMovieSceneBatchMaterialParameterSection::UMovieSceneBatchMaterialParameterSection()
{
	BlendType = EMovieSceneBlendType::Absolute;
}

//this function is basically as same as UMovieSceneComponentMaterialParameterSection, except we don't add ComponentMaterialInfo to the entity
void UMovieSceneBatchMaterialParameterSection::ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity)
{
	using namespace UE::MovieScene;

	uint8 ParameterType = 0;
	int32 EntityIndex = 0;
	DecodeMaterialParameterEntityID(Params.EntityID, EntityIndex, ParameterType);

	FBuiltInComponentTypes* BuiltInComponentTypes = FBuiltInComponentTypes::Get();
	FMovieSceneTracksComponentTypes* TracksComponentTypes = FMovieSceneTracksComponentTypes::Get();

	FGuid ObjectBindingID = Params.GetObjectBindingID();
	
	TEntityBuilder<TAddConditional<FGuid>> BaseBuilder = FEntityBuilder()
		.AddConditional(BuiltInComponentTypes->GenericObjectBinding, ObjectBindingID, ObjectBindingID.IsValid());

	FText SlotName;
	UMovieSceneBatchMaterialTrack* Track = GetTypedOuter<UMovieSceneBatchMaterialTrack>();
	if (ensure(Track)){
		SlotName = Track->SlotName;
	}

	switch (ParameterType)
	{
	case 0:
	{
		const FScalarMaterialParameterInfoAndCurve& Scalar = ScalarParameterInfosAndCurves[EntityIndex];

		if (Scalar.ParameterCurve.HasAnyData())
		{
			OutImportedEntity->AddBuilder(
				BaseBuilder
				.Add(TracksComponentTypes->ScalarMaterialParameterInfo, Scalar.ParameterInfo)
				.Add(BuiltInComponentTypes->FloatChannel[0], &Scalar.ParameterCurve)
				.Add(FKGMovieSceneComponentType::Get()->Components.BatchMaterialSlotName, SlotName)
				.AddTag(FKGMovieSceneComponentType::Get()->Tags.BatchMaterialOnActor)
				// If the section has no valid blend type (legacy data), make it use absolute blending.
				// Otherwise, the base section class will add the appropriate blend type tag in BuildDefaultComponents.
				.AddTagConditional(BuiltInComponentTypes->Tags.AbsoluteBlend, !GetBlendType().IsValid())
			);
		}
		break;
	}
	case 1:
	{
		const FColorMaterialParameterInfoAndCurves& Color = ColorParameterInfosAndCurves[EntityIndex];
		if (Color.RedCurve.HasAnyData() || Color.GreenCurve.HasAnyData() || Color.BlueCurve.HasAnyData() || Color.AlphaCurve.HasAnyData())
		{
			OutImportedEntity->AddBuilder(
				BaseBuilder
				.Add(TracksComponentTypes->ColorMaterialParameterInfo, Color.ParameterInfo)
				.Add(FKGMovieSceneComponentType::Get()->Components.BatchMaterialSlotName, SlotName)
				.AddConditional(BuiltInComponentTypes->FloatChannel[0], &Color.RedCurve, Color.RedCurve.HasAnyData())
				.AddConditional(BuiltInComponentTypes->FloatChannel[1], &Color.GreenCurve, Color.GreenCurve.HasAnyData())
				.AddConditional(BuiltInComponentTypes->FloatChannel[2], &Color.BlueCurve, Color.BlueCurve.HasAnyData())
				.AddConditional(BuiltInComponentTypes->FloatChannel[3], &Color.AlphaCurve, Color.AlphaCurve.HasAnyData())
				.AddTag(FKGMovieSceneComponentType::Get()->Tags.BatchMaterialOnActor)
				// If the section has no valid blend type (legacy data), make it use absolute blending.
				// Otherwise, the base section class will add the appropriate blend type tag in BuildDefaultComponents.
				.AddTagConditional(BuiltInComponentTypes->Tags.AbsoluteBlend, !GetBlendType().IsValid())
			);
		}
		break;
	}
	}
}