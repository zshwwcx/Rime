// Copyright KuaiShou Games, Inc. All Rights Reserved.
// Author: liuruilin@kuaishou.com

#include "CutScene/FullScreenMediaTrack.h"

#include "BinkMediaPlayer.h"
#include "BinkMediaSource.h"
#include "CutScene/FullScreenMediaProxy.h"
#include "CutScene/FullScreenMediaSection.h"
#include "MediaPlayer.h"
#include "Modules/ModuleManager.h"
#include "MovieScene.h"
#include "Evaluation/MovieSceneEvalTemplate.h"

bool UFullScreenMediaTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneMediaSection::StaticClass();
}

FMovieSceneEvalTemplatePtr UFullScreenMediaTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FFullScreenMediaSectionTemplate(*CastChecked<const UMovieSceneMediaSection>(&InSection), *this);
}

void UFullScreenMediaTrack::SetUp(IMovieScenePlayer& Player, const UMovieSceneMediaSection* CustomSection) const
{
	if (!ensure(CustomSection))
		return;

	UBinkMediaSource* BinkMediaSource = Cast<UBinkMediaSource>(CustomSection->MediaSource);
	if (!ensure(BinkMediaSource))
		return;
	
	FFullScreenMediaProxy::SetUp(Player, BinkMediaSource->FilePath, CustomSection->bLooping, bReferenceMovie, SizePercent);
}

void UFullScreenMediaTrack::Seek(IMovieScenePlayer& Player, const double CurrentTime)
{
	FFullScreenMediaProxy::Seek(Player, CurrentTime);
}

void UFullScreenMediaTrack::SetRate(IMovieScenePlayer& Player, const float X)
{
	Rate = X;
	FFullScreenMediaProxy::SetRate(Player, X);
}

float UFullScreenMediaTrack::GetRate(IMovieScenePlayer& Player) const
{
	return Rate;
}

void UFullScreenMediaTrack::PreRoll(IMovieScenePlayer& Player)
{
	Rate = 0;
	FFullScreenMediaProxy::PreRoll(Player);
}

void UFullScreenMediaTrack::TearDown(IMovieScenePlayer& Player)
{
	Rate = 0;
	FFullScreenMediaProxy::TearDown(Player);
}
