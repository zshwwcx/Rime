﻿// Fill out your copyright notice in the Description page of Project Settings.
#include "CutScene/MovieSceneAnimMontageTrack.h"

#if WITH_EDITORONLY_DATA
#include "AnimationBlueprintLibrary.h"
#include "Misc/QualifiedFrameTime.h"
#include "Misc/Timecode.h"
#endif
#include "MovieScene.h"
#include "CutScene/MovieSceneAnimMontageSection.h"

#define LOCTEXT_NAMESPACE "MovieSceneAnimMontageTrack"

UMovieSceneSection* UMovieSceneAnimMontageTrack::AddNewAnimationOnRow(FFrameNumber KeyTime,
	UAnimMontage* AnimSequence, int32 RowIndex)
{
	UMovieSceneAnimMontageSection* NewSection = Cast<UMovieSceneAnimMontageSection>(CreateNewSection());
	{
		FFrameTime AnimationLength = AnimSequence->GetPlayLength() * GetTypedOuter<UMovieScene>()->GetTickResolution();
		int32 IFrameNumber = AnimationLength.FrameNumber.Value + (int)(AnimationLength.GetSubFrame() + 0.5f) + 1;
		NewSection->InitialPlacementOnRow(AnimationSections, KeyTime, IFrameNumber, RowIndex);
		NewSection->Params.AnimMontage = AnimSequence;

#if WITH_EDITORONLY_DATA
		FQualifiedFrameTime SourceStartFrameTime;
		if (UAnimationBlueprintLibrary::EvaluateRootBoneTimecodeAttributesAtTime(NewSection->Params.AnimMontage, 0.0f, SourceStartFrameTime))
		{
			NewSection->TimecodeSource.Timecode = SourceStartFrameTime.ToTimecode();
		}
#endif
	}

	AddSection(*NewSection);

	return NewSection;
}

void UMovieSceneAnimMontageTrack::RemoveAllAnimationData()
{
	AnimationSections.Empty();
}

bool UMovieSceneAnimMontageTrack::HasSection(const UMovieSceneSection& Section) const
{
	return AnimationSections.Contains(&Section);
}

void UMovieSceneAnimMontageTrack::AddSection(UMovieSceneSection& Section)
{
	AnimationSections.Add(&Section);
}

void UMovieSceneAnimMontageTrack::RemoveSection(UMovieSceneSection& Section)
{
	AnimationSections.Remove(&Section);
}

void UMovieSceneAnimMontageTrack::RemoveSectionAt(int32 SectionIndex)
{
	AnimationSections.RemoveAt(SectionIndex);
}

bool UMovieSceneAnimMontageTrack::IsEmpty() const
{
	return AnimationSections.Num() == 0;
}

const TArray<UMovieSceneSection*>& UMovieSceneAnimMontageTrack::GetAllSections() const
{
	return AnimationSections;
}

bool UMovieSceneAnimMontageTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneAnimMontageSection::StaticClass();
}

UMovieSceneSection* UMovieSceneAnimMontageTrack::CreateNewSection()
{
	return NewObject<UMovieSceneAnimMontageSection>(this, NAME_None, RF_Transactional);
}

#if WITH_EDITORONLY_DATA
FText UMovieSceneAnimMontageTrack::GetDefaultDisplayName() const
{
	return LOCTEXT("TrackName", "AnimMontage");
}
#endif

#undef LOCTEXT_NAMESPACE






