// Copyright Epic Games, Inc. All Rights Reserved.

#include "CutScene/MovieSceneTracksLookAtTypes.h"
#include "Components/SkeletalMeshComponent.h"
#include "EntitySystem/BuiltInComponentTypes.h"
#include "EntitySystem/MovieSceneEntityManager.h"
#include "EntitySystem/MovieSceneEntitySystemLinker.h"
#include "EntitySystem/MovieSceneComponentRegistry.h"
#include "EntitySystem/MovieSceneBlenderSystem.h"
#include "Systems/MovieScenePiecewiseBoolBlenderSystem.h"
#include "Systems/MovieScenePiecewiseByteBlenderSystem.h"
#include "Systems/MovieScenePiecewiseEnumBlenderSystem.h"
#include "Systems/MovieScenePiecewiseIntegerBlenderSystem.h"
#include "Systems/MovieScenePiecewiseDoubleBlenderSystem.h"
#include "Systems/MovieScenePiecewiseDoubleBlenderSystem.h"
#include "EntitySystem/MovieScenePropertyComponentHandler.h"
#include "EntitySystem/MovieSceneEntityFactoryTemplates.h"
#include "EntitySystem/MovieScenePropertyMetaDataTraits.inl"
#include "Systems/MovieSceneColorPropertySystem.h"
#include "Systems/MovieSceneVectorPropertySystem.h"
#include "MovieSceneObjectBindingID.h"
#include "GameFramework/Actor.h"
#include "Materials/MaterialParameterCollection.h"
#include "Misc/App.h"
#include "PhysicsEngine/BodyInstance.h"
#include "CutScene/LookAtTransform.h"
#include "3C/Animation/LookAt/LookAtComponent.h"
#include "3C/Character/BaseCharacter.h"

//#include UE_INLINE_GENERATED_CPP_BY_NAME(MovieSceneTracksLookAtTypes)

namespace UE
{
	namespace MovieScene
	{

		static bool GMovieSceneLookAtTypesDestroyed = false;
		static TUniquePtr<FMovieSceneTracksLookAtTypes> GMovieSceneLookAtTypes;

		FMovieSceneTracksLookAtTypes::FMovieSceneTracksLookAtTypes()
		{
			FComponentRegistry* ComponentRegistry = UMovieSceneEntitySystemLinker::GetComponents();

			ComponentRegistry->NewComponentType(&LookAt, TEXT("LookAt"));

			ComponentRegistry->Factories.DuplicateChildComponent(LookAt);
		}

		FMovieSceneTracksLookAtTypes::~FMovieSceneTracksLookAtTypes()
		{
		}

		void FMovieSceneTracksLookAtTypes::Destroy()
		{
			GMovieSceneLookAtTypes.Reset();
			GMovieSceneLookAtTypesDestroyed = true;
		}

		FMovieSceneTracksLookAtTypes* FMovieSceneTracksLookAtTypes::Get()
		{
			if (!GMovieSceneLookAtTypes.IsValid())
			{
				check(!GMovieSceneLookAtTypesDestroyed);
				GMovieSceneLookAtTypes.Reset(new FMovieSceneTracksLookAtTypes);
			}
			return GMovieSceneLookAtTypes.Get();
		}

		void ConvertOperationalProperty(const FIntermediateLookAt& In, FLookAt& Out)
		{
			/*Out = FLookAt(In.GetEye().Quaternion(), In.GetHead().Quaternion(), In.GetBody().Quaternion(), In.GetSp01().Quaternion(), In.GetSp02().Quaternion(), In.GetSp03().Quaternion());*/
		}

		KGSTORYLINE_API void ConvertOperationalProperty(const FLookAt& In, FIntermediateLookAt& Out)
		{
			/*FRotator Eye = In.GetEye().Rotator();
			FRotator Head = In.GetHead().Rotator();
			FRotator Body = In.GetBody().Rotator();
			FRotator Spine_01 = In.GetSpine_01().Rotator();
			FRotator Spine_02 = In.GetSpine_02().Rotator();
			FRotator Spine_03 = In.GetSpine_03().Rotator();
			Out = FIntermediateLookAt(Eye, Head, Body, Spine_01, Spine_02, Spine_03);*/
		}

	}
}

namespace UE
{
namespace MovieScene
{

/* ---------------------------------------------------------------------------
 * Transform conversion functions
 * ---------------------------------------------------------------------------*/
void ConvertOperationalProperty(const FIntermediateLookAt& In, FLookAtTransform& Out)
{
	Out.Eye = In.GetEye();
	Out.Head = In.GetHead();
	Out.Body = In.GetBody();
	Out.Spine_01 = In.GetSp01();
	Out.Spine_02 = In.GetSp02();
	Out.Spine_03 = In.GetSp03();
}
void ConvertOperationalProperty(const FLookAtTransform& In, FIntermediateLookAt& Out)
{
	Out = FIntermediateLookAt(In.GetEye().Rotator(), In.GetHead().Rotator(), In.GetBody().Rotator(), In.GetSpine_01().Rotator(), In.GetSpine_02().Rotator(), In.GetSpine_03().Rotator());
}

void FIntermediateLookAt::ApplyTo(USceneComponent* SceneComponent) const
{
	ApplyTransformTo(SceneComponent, *this);
}

void FIntermediateLookAt::ApplyTransformTo(USceneComponent* SceneComponent, const FIntermediateLookAt& Transform)
{
	double DeltaTime = FApp::GetDeltaTime();
	//SetComponentTransform(SceneComponent, Transform);
	// If this is a simulating component, teleport since sequencer takes over. 
	// Teleport will not have no velocity, but it's computed later by sequencer so that it will be correct for physics.
	// @todo: We would really rather not 
	AActor* Actor = SceneComponent->GetOwner();
	if(ABaseCharacter* Character = Cast<ABaseCharacter>(Actor))
	{
		ULookAtComponent* LookAtComponent = Character ? Character->GetComponentByClass<ULookAtComponent>() : nullptr;
		if(LookAtComponent == nullptr)
		{
			return;
		}

		LookAtComponent->SetEye(Transform.GetEye());
		LookAtComponent->SetEyeScale(Transform.GetEyeScale());
		LookAtComponent->SetHead(Transform.GetHead());
		LookAtComponent->SetBody(Transform.GetBody());
		LookAtComponent->SetSpine_01(Transform.GetSp01());
		LookAtComponent->SetSpine_02(Transform.GetSp02());
		LookAtComponent->SetSpine_03(Transform.GetSp03());
		//FLookAtTransform NewTransform(Head, Eye, Body);
		//Character->SetRelativeTransform(NewTransform, false, nullptr, bIsSimulatingPhysics ? ETeleportType::ResetPhysics : ETeleportType::None);
	}
}

void FIntermediateLookAt::ApplyTranslationAndRotationTo(USceneComponent* SceneComponent, const FIntermediateLookAt& Transform)
{
	AActor* Actor = SceneComponent->GetOwner();
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(Actor))
	{
		ULookAtComponent* LookAtComponent = Character ? Character->GetComponentByClass<ULookAtComponent>() : nullptr;
		if(LookAtComponent == nullptr) 
		{
			return;
		}

		LookAtComponent->SetEye(Transform.GetEye());
		LookAtComponent->SetEyeScale(Transform.GetEyeScale());
		LookAtComponent->SetHead(Transform.GetHead());
		LookAtComponent->SetBody(Transform.GetBody());
		LookAtComponent->SetSpine_01(Transform.GetSp01());
		LookAtComponent->SetSpine_02(Transform.GetSp02());
		LookAtComponent->SetSpine_03(Transform.GetSp03());
		//FLookAtTransform NewTransform(Head, Eye, Body);
		//CutSceneActor->SetRelativeTransform(NewTransform, false, nullptr, bIsSimulatingPhysics ? ETeleportType::ResetPhysics : ETeleportType::None);
	}
}


//FMovieSceneTracksComponentTypes::FMovieSceneTracksComponentTypes()
//{
//	FComponentRegistry* ComponentRegistry = UMovieSceneEntitySystemLinker::GetComponents();
//
//	
//	ComponentRegistry->NewPropertyType(Transform, TEXT("FTransform"));
//	ComponentRegistry->NewComponentType(&TransformParameterName, TEXT("Transform Parameter Name"), EComponentTypeFlags::CopyToChildren | EComponentTypeFlags::CopyToOutput);
//
//	
//	FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
//
//	// Set up FTransform properties
//	BuiltInComponents->PropertyRegistry.DefineCompositeProperty(Transform, TEXT("Apply FTransform Properties"))
//	.AddComposite(BuiltInComponents->DoubleResult[0], &FIntermediate3DTransform::T_X)
//	.AddComposite(BuiltInComponents->DoubleResult[1], &FIntermediate3DTransform::T_Y)
//	.AddComposite(BuiltInComponents->DoubleResult[2], &FIntermediate3DTransform::T_Z)
//	.AddComposite(BuiltInComponents->DoubleResult[3], &FIntermediate3DTransform::R_X)
//	.AddComposite(BuiltInComponents->DoubleResult[4], &FIntermediate3DTransform::R_Y)
//	.AddComposite(BuiltInComponents->DoubleResult[5], &FIntermediate3DTransform::R_Z)
//	.AddComposite(BuiltInComponents->DoubleResult[6], &FIntermediate3DTransform::S_X)
//	.AddComposite(BuiltInComponents->DoubleResult[7], &FIntermediate3DTransform::S_Y)
//	.AddComposite(BuiltInComponents->DoubleResult[8], &FIntermediate3DTransform::S_Z)
//	.SetBlenderSystem<UMovieScenePiecewiseDoubleBlenderSystem>()
//	.Commit();
//}FMovieSceneTracksComponentTypes::FMovieSceneTracksComponentTypes()
//{
//	FComponentRegistry* ComponentRegistry = UMovieSceneEntitySystemLinker::GetComponents();
//
//	
//	ComponentRegistry->NewPropertyType(Transform, TEXT("FTransform"));
//	ComponentRegistry->NewComponentType(&TransformParameterName, TEXT("Transform Parameter Name"), EComponentTypeFlags::CopyToChildren | EComponentTypeFlags::CopyToOutput);
//
//	
//	FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
//
//	// Set up FTransform properties
//	BuiltInComponents->PropertyRegistry.DefineCompositeProperty(Transform, TEXT("Apply FTransform Properties"))
//	.AddComposite(BuiltInComponents->DoubleResult[0], &FIntermediate3DTransform::T_X)
//	.AddComposite(BuiltInComponents->DoubleResult[1], &FIntermediate3DTransform::T_Y)
//	.AddComposite(BuiltInComponents->DoubleResult[2], &FIntermediate3DTransform::T_Z)
//	.AddComposite(BuiltInComponents->DoubleResult[3], &FIntermediate3DTransform::R_X)
//	.AddComposite(BuiltInComponents->DoubleResult[4], &FIntermediate3DTransform::R_Y)
//	.AddComposite(BuiltInComponents->DoubleResult[5], &FIntermediate3DTransform::R_Z)
//	.AddComposite(BuiltInComponents->DoubleResult[6], &FIntermediate3DTransform::S_X)
//	.AddComposite(BuiltInComponents->DoubleResult[7], &FIntermediate3DTransform::S_Y)
//	.AddComposite(BuiltInComponents->DoubleResult[8], &FIntermediate3DTransform::S_Z)
//	.SetBlenderSystem<UMovieScenePiecewiseDoubleBlenderSystem>()
//	.Commit();
//}


} // namespace MovieScene
} // namespace UE
