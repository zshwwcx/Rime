#include "CutScene/MovieSceneAudio2FaceSection.h"
#include "MovieScene.h"

UMovieSceneAudio2FaceSection::UMovieSceneAudio2FaceSection(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

#if WITH_EDITORONLY_DATA
	SetColorTint(FColor(0, 9, 185, 255));
#endif
}