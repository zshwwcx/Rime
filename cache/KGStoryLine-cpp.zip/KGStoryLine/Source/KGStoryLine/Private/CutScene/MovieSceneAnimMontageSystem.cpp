﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "CutScene/MovieSceneAnimMontageSystem.h"
#include "AnimCustomInstanceHelper.h"
#include "AnimSequencerInstance.h"
#include "IMovieScenePlayer.h"
#include "CutScene/MovieSceneAnimMontageSection.h"
#include "CutScene/MovieSceneExtendComponentTypes.h"
#include "SequencerAnimationSupport.h"
#include "SkeletalMeshRestoreState.h"
#include "Engine/SkeletalMesh.h"
#include "EntitySystem/MovieSceneEntitySystemRunner.h"
#include "EntitySystem/Interrogation/MovieSceneInterrogationLinker.h"
#include "Evaluation/PreAnimatedState/MovieScenePreAnimatedObjectStorage.h"
#include "Evaluation/PreAnimatedState/MovieScenePreAnimatedStorageID.inl"
#include "Systems/MovieSceneComponentTransformSystem.h"
#include "Systems/MovieSceneQuaternionInterpolationRotationSystem.h"

namespace UE::MovieScene
{
	UAnimSequencerInstance* GetAnimSequencerInstance1(USkeletalMeshComponent* SkeletalMeshComponent)
	{
		ISequencerAnimationSupport* SeqInterface = Cast<ISequencerAnimationSupport>(SkeletalMeshComponent->GetAnimInstance());
		if (SeqInterface)
		{
			return Cast<UAnimSequencerInstance>(SeqInterface->GetSourceAnimInstance());
		}

		return nullptr;
	}
	
	struct FPreAnimatedSkeletalAnimationState
	{
		EAnimationMode::Type AnimationMode;
		TStrongObjectPtr<UAnimInstance> CachedAnimInstance;
		FSkeletalMeshRestoreState SkeletalMeshRestoreState;
	};
	
	/** Pre-animation traits for skeletal animations */
	struct FPreAnimatedSkeletalAnimationTraits : FBoundObjectPreAnimatedStateTraits
	{
		using KeyType     = FObjectKey;
		using StorageType = FPreAnimatedSkeletalAnimationState;

		FPreAnimatedSkeletalAnimationState CachePreAnimatedValue(const KeyType& Object)
		{
			FPreAnimatedSkeletalAnimationState OutCachedValue;
			USkeletalMeshComponent* Component = Cast<USkeletalMeshComponent>(Object.ResolveObjectPtr());
			if (ensure(Component))
			{
				OutCachedValue.AnimationMode = Component->GetAnimationMode();
				OutCachedValue.CachedAnimInstance.Reset(Component->AnimScriptInstance);
				OutCachedValue.SkeletalMeshRestoreState.SaveState(Component);
			}
			return OutCachedValue;
		}

		void RestorePreAnimatedValue(const KeyType& Object, StorageType& InOutCachedValue, const FRestoreStateParams& Params)
		{
			USkeletalMeshComponent* Component = Cast<USkeletalMeshComponent>(Object.ResolveObjectPtr());
			if (!Component)
			{
				return;
			}

			ISequencerAnimationSupport* SequencerInst = Cast<ISequencerAnimationSupport>(GetAnimSequencerInstance1(Component));
			if (SequencerInst)
			{
				SequencerInst->ResetPose();
				SequencerInst->ResetNodes();
			}

			FAnimCustomInstanceHelper::UnbindFromSkeletalMeshComponent<UAnimSequencerInstance>(Component);

			// Restore LOD before reinitializing anim instance
			InOutCachedValue.SkeletalMeshRestoreState.RestoreLOD(Component);

			if (Component->GetAnimationMode() != InOutCachedValue.AnimationMode)
			{
				// this SetAnimationMode reinitializes even if the mode is same
				// if we're using same anim blueprint, we don't want to keep reinitializing it. 
				Component->SetAnimationMode(InOutCachedValue.AnimationMode);
			}
			if (InOutCachedValue.CachedAnimInstance.Get())
			{
				Component->AnimScriptInstance = InOutCachedValue.CachedAnimInstance.Get();
				InOutCachedValue.CachedAnimInstance.Reset();
				if (Component->AnimScriptInstance && Component->GetSkeletalMeshAsset() && Component->AnimScriptInstance->CurrentSkeleton != Component->GetSkeletalMeshAsset()->GetSkeleton())
				{
					//the skeleton may have changed so need to recalc required bones as needed.
					Component->AnimScriptInstance->CurrentSkeleton = Component->GetSkeletalMeshAsset()->GetSkeleton();
					//Need at least RecalcRequiredbones and UpdateMorphTargetrs
					Component->InitializeAnimScriptInstance(true);
				}
			}

			// Restore pose after unbinding to force the restored pose
			Component->SetUpdateAnimationInEditor(true);
			Component->SetUpdateClothInEditor(true);
			Component->TickAnimation(0.f, false);

			Component->RefreshBoneTransforms();
			Component->RefreshFollowerComponents();
			Component->UpdateComponentToWorld();
			Component->FinalizeBoneTransform();
			Component->MarkRenderTransformDirty();
			Component->MarkRenderDynamicDataDirty();

			// Reset the mesh component update flag and animation mode to what they were before we animated the object
			InOutCachedValue.SkeletalMeshRestoreState.RestoreState(Component);

			// if not game world, don't clean this up
			if (Component->GetWorld() != nullptr && Component->GetWorld()->IsGameWorld() == false)
			{
				Component->ClearMotionVector();
			}
		}
	};

	/** Pre-animation storage for skeletal animations */
	struct FPreAnimatedSkeletalAnimationStorage1 : TPreAnimatedStateStorage_ObjectTraits<FPreAnimatedSkeletalAnimationTraits>
	{
		static TAutoRegisterPreAnimatedStorageID<FPreAnimatedSkeletalAnimationStorage1> StorageID;
	};

	TAutoRegisterPreAnimatedStorageID<FPreAnimatedSkeletalAnimationStorage1> FPreAnimatedSkeletalAnimationStorage1::StorageID;
	
	struct FGatherAnimMontages
	{
		const FInstanceRegistry* InstanceRegistry;
		FAnimMontageSystemData* SystemData;

		FGatherAnimMontages(const FInstanceRegistry* InInstanceRegistry, FAnimMontageSystemData* InSystemData)
		: InstanceRegistry(InInstanceRegistry)
		, SystemData(InSystemData)
		{
		}

		void PreTask() const
		{
			// Start fresh every frame, gathering all active skeletal animations.
			SystemData->ResetAnimMontages();
		}

		void ForEachAllocation(
			const FEntityAllocationProxy AllocationProxy, 
			TRead<FMovieSceneEntityID> EntityIDs,
			TRead<FRootInstanceHandle> RootInstanceHandles,
			TRead<FInstanceHandle> InstanceHandles,
			TRead<UObject*> BoundObjects,
			TRead<FMovieSceneAnimMontageComponentData> AnimMontages) const
		{
			const FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
			const FEntityAllocation* Allocation = AllocationProxy.GetAllocation();
			const int32 Num = Allocation->Num();
			for (int32 Index = 0; Index < Num; ++Index)
			{
				FMovieSceneEntityID EntityID(EntityIDs[Index]);
				//const FRootInstanceHandle& RootInstanceHandle(RootInstanceHandles[Index]);
				const FInstanceHandle& InstanceHandle(InstanceHandles[Index]);
				UObject* BoundObject(BoundObjects[Index]);
				const FMovieSceneAnimMontageComponentData& AnimMontage(AnimMontages[Index]);
				
				const FSequenceInstance& SequenceInstance = InstanceRegistry->GetInstance(InstanceHandle);
				const FMovieSceneContext& Context = SequenceInstance.GetContext();
				IMovieScenePlayer* Player = SequenceInstance.GetPlayer();
				
				const UMovieSceneAnimMontageSection* MontageSection = AnimMontage.Section;
				const FMovieSceneAnimMontageParams& MontageParams = MontageSection->Params;

				// Get the bound skeletal mesh component.
				USkeletalMeshComponent* SkeletalMeshComponent = SkeletalMeshComponentFromObject(BoundObject);
				if (!SkeletalMeshComponent || MontageParams.AnimMontage == nullptr)
				{
					continue;
				}
				const float EvalTime = MontageParams.MapTimeToAnimation(MontageSection, Context.GetTime(), Context.GetFrameRate());
				const float PreviousEvalTime = MontageParams.MapTimeToAnimation(MontageSection, Context.GetPreviousTime(), Context.GetFrameRate());

				const EMovieScenePlayerStatus::Type PlayerStatus = Player->GetPlaybackStatus();
				const bool bPlaying = PlayerStatus == EMovieScenePlayerStatus::Playing;
				
				FBoundObjectActiveAnimMontages& BoundObjectAnimations = SystemData->SkeletalAnimations.FindOrAdd(SkeletalMeshComponent);
				FActiveAnimMontages Montage;

				Montage.AnimSection = MontageSection;
				Montage.Context = Context;
				Montage.EntityID = EntityID;
				Montage.FromEvalTime = PreviousEvalTime;
				Montage.ToEvalTime = EvalTime;
				Montage.bPlaying = bPlaying;

				BoundObjectAnimations.AnimMontages.Add(Montage);
			}
		}
		
	private:
		static USkeletalMeshComponent* SkeletalMeshComponentFromObject(UObject* InObject)
		{
			// Check if we are bound directly to a skeletal mesh component.
			USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(InObject);
			if (SkeletalMeshComponent)
			{
				return SkeletalMeshComponent;
			}

			// Then check to see if we are controlling an actor. If so use its first skeletal mesh component.
			AActor* Actor = Cast<AActor>(InObject);
			if (!Actor)
			{
				if (UChildActorComponent* ChildActorComponent = Cast<UChildActorComponent>(InObject))
				{
					Actor = ChildActorComponent->GetChildActor();
				}
			}
			if (Actor)
			{
				return Actor->FindComponentByClass<USkeletalMeshComponent>();
			}
			return nullptr;
		}
	};
	
	struct FEvaluateAnimMontages
	{
		FAnimMontageSystemData* SystemData;

		TSharedPtr<FPreAnimatedSkeletalAnimationStorage1> PreAnimatedStorage;

		FEvaluateAnimMontages(UMovieSceneEntitySystemLinker* InLinker, FAnimMontageSystemData* InSystemData)
			: SystemData(InSystemData)
		{
			PreAnimatedStorage = InLinker->PreAnimatedState.GetOrCreateStorage<FPreAnimatedSkeletalAnimationStorage1>();
		}

		void Run(FEntityAllocationWriteContext WriteContext) const
		{
			Run();
		}

		void Run() const
		{
			for (TTuple<TWeakObjectPtr<USkeletalMeshComponent>, FBoundObjectActiveAnimMontages>& Pair : SystemData->SkeletalAnimations)
			{
				EvaluateSkeletalAnimations(Pair.Key.Get(), Pair.Value);
			}
		}
	private:
		void EvaluateSkeletalAnimations(USkeletalMeshComponent* SkeletalMeshComponent, FBoundObjectActiveAnimMontages& InAnimMontages) const
		{
			ensureMsgf(SkeletalMeshComponent, TEXT("Attempting to evaluate an Animation track with a null object."));

			if (!SkeletalMeshComponent || !SkeletalMeshComponent->GetSkeletalMeshAsset())
			{
				return;
			}

			// Cache pre-animated state for this bound object before doing anything.
			// We don't yet track what entities have already started animated vs. entities that just started this frame,
			// so we just process all the currently active ones. If they are already tracked and have already had their
			// pre-animated state saved, it these calls will just early return.
			for (const FActiveAnimMontages& SkeletalAnimation : InAnimMontages.AnimMontages)
			{
				PreAnimatedStorage->BeginTrackingEntity(SkeletalAnimation.EntityID, SkeletalAnimation.bWantsRestoreState, SkeletalAnimation.RootInstanceHandle, SkeletalMeshComponent);
			}
			FCachePreAnimatedValueParams CacheParams;
			PreAnimatedStorage->CachePreAnimatedValue(CacheParams, SkeletalMeshComponent);

			UAnimInstance* AnimInstance = SkeletalMeshComponent->GetAnimInstance();
			if (!AnimInstance)
			{
				return;
			}
			for (FActiveAnimMontages& SkeletalAnimation : InAnimMontages.AnimMontages)
			{
				if (!SkeletalAnimation.AnimSection.IsValid())
				{
					continue;
				}
				
				if (UAnimMontage* AnimMontage = Cast<UAnimMontage>(SkeletalAnimation.AnimSection->Params.AnimMontage))
				{
					FMontagePlayerPerSectionData* SectionData = SystemData->MontageData.FindOrAdd(SkeletalMeshComponent).Find(SkeletalAnimation.AnimSection.Get());
					const int32 InstanceId = (SectionData) ? SectionData->MontageInstanceId : INDEX_NONE;
					FAnimMontageInstance* MontageInstanceToUpdate = AnimInstance->GetMontageInstanceForID(InstanceId);
					if (!MontageInstanceToUpdate)
					{
						AnimInstance->Montage_Play(AnimMontage, 1.0f, EMontagePlayReturnType::MontageLength, 0.f, false);
						MontageInstanceToUpdate = AnimInstance->GetActiveInstanceForMontage(AnimMontage);
					}
					if (MontageInstanceToUpdate)
					{
						FMontagePlayerPerSectionData& DataContainer = SystemData->MontageData.FindOrAdd(SkeletalMeshComponent).FindOrAdd(SkeletalAnimation.AnimSection.Get());
						DataContainer.MontageInstanceId = MontageInstanceToUpdate->GetInstanceID();
			
						if (SkeletalAnimation.bPlaying)
						{
							MontageInstanceToUpdate->SetNextPositionWithEvents(SkeletalAnimation.FromEvalTime, SkeletalAnimation.ToEvalTime);
						}
						else
						{
							MontageInstanceToUpdate->SetPosition(SkeletalAnimation.ToEvalTime);
						}
						MontageInstanceToUpdate->bPlaying = SkeletalAnimation.bPlaying;
					}
				}
			}
		}
	};
}

UMovieSceneAnimMontageSystem::UMovieSceneAnimMontageSystem(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	using namespace UE::MovieScene;

	FMovieSceneExtendComponentTypes* TrackComponents = FMovieSceneExtendComponentTypes::Get();
	RelevantComponent = TrackComponents->AnimMontage;
	Phase = ESystemPhase::Instantiation | ESystemPhase::Scheduling;

	SystemCategories |= FSystemInterrogator::GetExcludedFromInterrogationCategory();

	if (HasAnyFlags(RF_ClassDefaultObject))
	{
		DefineImplicitPrerequisite(UMovieSceneComponentTransformSystem::StaticClass(), GetClass());
		DefineImplicitPrerequisite(UMovieSceneQuaternionInterpolationRotationSystem::StaticClass(), GetClass());
	}
}

void UMovieSceneAnimMontageSystem::OnSchedulePersistentTasks(UE::MovieScene::IEntitySystemScheduler* TaskScheduler)
{
	using namespace UE::MovieScene;

	FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
	FMovieSceneExtendComponentTypes* TrackComponents = FMovieSceneExtendComponentTypes::Get();

	FTaskID GatherTask = FEntityTaskBuilder()
	.ReadEntityIDs()
	.Read(BuiltInComponents->RootInstanceHandle)
	.Read(BuiltInComponents->InstanceHandle)
	.Read(BuiltInComponents->BoundObject)
	.Read(TrackComponents->AnimMontage)
	.FilterNone({ BuiltInComponents->Tags.Ignored })
	.Schedule_PerAllocation<FGatherAnimMontages>(&Linker->EntityManager, TaskScheduler, 
			Linker->GetInstanceRegistry(), &SystemData);

	// Now evaluate gathered animations. We need to do this on the game thread (when in multi-threaded mode)
	// because this task will call into a lot of animation system code that needs to be called there.
	FTaskParams Params(nullptr);
	Params.ForceGameThread();
	FTaskID EvaluateTask = TaskScheduler->AddTask<FEvaluateAnimMontages>(Params, Linker, &SystemData);

	TaskScheduler->AddPrerequisite(GatherTask, EvaluateTask);
}

void UMovieSceneAnimMontageSystem::OnRun(FSystemTaskPrerequisites& InPrerequisites, FSystemSubsequentTasks& Subsequents)
{
	using namespace UE::MovieScene;
	
	const FMovieSceneEntitySystemRunner* Runner = Linker->GetActiveRunner();
	if (Runner->GetCurrentPhase() == ESystemPhase::Instantiation)
	{
		SystemData.ResetAnimMontages();
		return;
	}
	
	FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
	FMovieSceneExtendComponentTypes* TrackComponents = FMovieSceneExtendComponentTypes::Get();

	FGraphEventRef GatherTask = FEntityTaskBuilder()
	.ReadEntityIDs()
	.Read(BuiltInComponents->RootInstanceHandle)
	.Read(BuiltInComponents->InstanceHandle)
	.Read(BuiltInComponents->BoundObject)
	.Read(TrackComponents->AnimMontage)
	.FilterNone({ BuiltInComponents->Tags.Ignored })
	.Dispatch_PerAllocation<FGatherAnimMontages>(&Linker->EntityManager, InPrerequisites, nullptr, 
			Linker->GetInstanceRegistry(), &SystemData);

	FSystemTaskPrerequisites EvalPrereqs;
	if (GatherTask)
	{
		EvalPrereqs.AddRootTask(GatherTask);
	}

	// Now evaluate gathered animations. We need to do this on the game thread (when in multi-threaded mode)
	// because this task will call into a lot of animation system code that needs to be called there.
	FEntityTaskBuilder()
	.SetDesiredThread(Linker->EntityManager.GetGatherThread())
	.Dispatch<FEvaluateAnimMontages>(&Linker->EntityManager, EvalPrereqs, &Subsequents, Linker, &SystemData);
}
