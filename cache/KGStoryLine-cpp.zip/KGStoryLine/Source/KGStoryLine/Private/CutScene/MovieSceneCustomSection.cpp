#include "CutScene/MovieSceneCustomSection.h"

#include "MovieScene.h"
#include "Tracks/MovieSceneCameraCutTrack.h"
#include "MovieSceneSequencePlayer.h"
#include "Sections/MovieSceneCameraCutSection.h"

#include "LevelSequencePlayer.h"
#include "Camera/CameraComponent.h"
#include "Tracks/MovieSceneSubTrack.h"
#include "EngineUtils.h"
#include "Sequence/KGSequenceManager.h"
#include "3C/Util/KGUtils.h"
#include "CutScene/MovieSceneCustomTrack.h"
#if WITH_EDITOR
#include "Editor.h"
#include "Subsystems/UnrealEditorSubsystem.h"
#endif

UMovieSceneCustomSection::UMovieSceneCustomSection(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

UMovieSceneCustomSection::~UMovieSceneCustomSection()
{
}

float UMovieSceneCustomSection::GetStartTime() const
{
	FFrameRate FrameRate = GetTypedOuter<UMovieScene>()->GetTickResolution();
	return (float)FrameRate.AsSeconds(GetRange().GetLowerBoundValue());
}

float UMovieSceneCustomSection::GetEndTime() const
{
	FFrameRate FrameRate = GetTypedOuter<UMovieScene>()->GetTickResolution();
	return (float)FrameRate.AsSeconds(GetRange().GetUpperBoundValue());
}

void UMovieSceneCustomSection::SetDuration(float Duration)
{
	FFrameNumber StartFrame = GetInclusiveStartFrame();

	UMovieScene* MovieScene = GetTypedOuter<UMovieScene>();
	if (MovieScene)
	{
		FFrameRate TickRes = MovieScene->GetTickResolution();
		FFrameNumber DurationFrames = TickRes.AsFrameNumber(Duration);
		FFrameNumber EndFrame = StartFrame + DurationFrames;
		SetRange(TRange<FFrameNumber>(StartFrame, EndFrame));
	}
}

#if WITH_EDITOR
void UMovieSceneCustomSection::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	OnCustomSectionPostEditChangePropertyDelegate.ExecuteIfBound();
	
	UKGSequenceManager* KGSequenceManager = UKGSequenceManager::GetSequenceManagerInEditor();
	if(KGSequenceManager)
		KGSequenceManager->OnCustomTrackSectionPropertyChange(this, false, PropertyChangedEvent.GetPropertyName().ToString(), UKGSequenceManager::EditorLoadHandleID);
}

void UMovieSceneCustomData::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	UKGSequenceManager* KGSequenceManager = UKGSequenceManager::GetSequenceManagerInEditor();
	UMovieSceneCustomSection* CustomSection = GetTypedOuter<UMovieSceneCustomSection>();
	if(KGSequenceManager)
		KGSequenceManager->OnCustomTrackSectionPropertyChange(CustomSection, true,PropertyChangedEvent.GetPropertyName().ToString(), UKGSequenceManager::EditorLoadHandleID);
}

#endif

void UMovieSceneCustomSection::ConstrainCurrentCamera(bool bVertical, UWorld* world, KGObjectID ActorID)
{
	AActor* TranActor = KGUtils::GetActorByID(ActorID);
	ALevelSequenceActor* Actor = Cast<ALevelSequenceActor>(TranActor);
	if(!Actor)
		return;
	UMovieScene* MovieScene = GetTypedOuter<UMovieScene>();
	if (!MovieScene)
	{
		return;
	}
    //UMovieSceneCameraCutTrack* CameraCutTrack = MovieScene->FindMasterTrack<UMovieSceneCameraCutTrack>();
    UMovieSceneTrack* MovieSceneTrack = MovieScene->GetCameraCutTrack();
    if (!MovieSceneTrack)
    {
        return;
    }
    UMovieSceneCameraCutTrack* CameraCutTrack = Cast<UMovieSceneCameraCutTrack>(MovieSceneTrack);

    /*UMovieSceneCameraCutTrack* CameraCutTrack = nullptr;
    for (UMovieSceneTrack* Track : MovieScene->GetTracks())
    {
        if (Track->GetClass()->IsChildOf(UMovieSceneCameraCutTrack::StaticClass()))
        {
            CameraCutTrack = Cast<UMovieSceneCameraCutTrack>(Track);
            break;
        }
        if (Track->GetClass()->IsChildOf(UMovieSceneSubTrack::StaticClass()))
        {
            UMovieSceneSubTrack* SubTrack = Cast<UMovieSceneSubTrack>(Track);
        }
    }*/

    if (!CameraCutTrack)
    {
        return;
    }

    if(Actor == nullptr)
    {
        for (TActorIterator<ALevelSequenceActor> ActorItr(world); ActorItr; ++ActorItr)
        {
            ALevelSequenceActor* MySeqActor = (*ActorItr);
            if (MySeqActor)
            {
                Actor = MySeqActor;
                break;
            }
        }
    }

    const TArray<UMovieSceneSection*>& CameraSections = CameraCutTrack->GetAllSections();

    if(Actor == nullptr)
    {
        return;
    }

    ULevelSequencePlayer* Player = Actor->GetSequencePlayer();
    if(Player == nullptr)
    {
        return;
    }
    ULevelSequence* LevelSequence = GetTypedOuter<ULevelSequence>();

    FMovieSceneSequenceID SequenceId = Player->State.FindSequenceId(LevelSequence);

    for (auto Section : CameraSections)
    {
        UMovieSceneCameraCutSection* CameraSection = Cast<UMovieSceneCameraCutSection>(Section);
        if (CameraSection)
        {
            UCameraComponent* CameraComponent = CameraSection->GetFirstCamera(*Player, SequenceId);
            if(CameraComponent)
            {
                CameraComponent->bOverrideAspectRatioAxisConstraint = 1;
                if(bVertical)
                {
                    CameraComponent->SetAspectRatioAxisConstraint(EAspectRatioAxisConstraint::AspectRatio_MaintainYFOV);
                }
                else
                {
                    CameraComponent->SetAspectRatioAxisConstraint(EAspectRatioAxisConstraint::AspectRatio_MaintainXFOV);
                }
            }
        }
    }
}
