// Copyright Epic Games, Inc. All Rights Reserved.

#include "CutScene/MovieSceneLookAtSection.h"
#include "Misc/EnumClassFlags.h"
#include "Channels/IMovieSceneChannelOverrideProvider.h"
#include "UObject/StructOnScope.h"
#include "UObject/SequencerObjectVersion.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "Channels/MovieSceneSectionChannelOverrideRegistry.h"
#include "GameFramework/Actor.h"
#include "EulerTransform.h"
#include "Systems/MovieScene3DTransformPropertySystem.h"
#include "Tracks/MovieScene3DTransformTrack.h"
#include "Tracks/MovieSceneEulerTransformTrack.h"
#include "EntitySystem/MovieSceneEntitySystemLinker.h"
#include "EntitySystem/MovieSceneEntityBuilder.h"
#include "MovieSceneTracksComponentTypes.h"
#include "Algo/AnyOf.h"
#include "TransformConstraint.h"
#include "TransformableHandle.h"
#include "UObject/ObjectSaveContext.h"
#include "CutScene/MovieSceneTracksLookAtTypes.h"
#include "CutScene/MovieSceneLookAtTrack.h"
#include "3C/Animation/LookAt/LookAtComponent.h"


#include UE_INLINE_GENERATED_CPP_BY_NAME(MovieSceneLookAtSection)


#if WITH_EDITOR

struct FLookAtChannelEditorData
{
	FLookAtChannelEditorData(EMovieSceneLookAtChannel Mask, int SortOrderStart)
	{
		static const TSet<FName> PropertyMetaDataKeys = { "UIMin", "UIMax", "SliderExponent", "LinearDeltaSensitivity", "Delta", "ClampMin", "ClampMax", "ForceUnits", "WheelStep" };

		const FProperty* RelativeEyeProperty = ULookAtComponent::StaticClass()->FindPropertyByName(ULookAtComponent::GetRelativeEyePropertyName());
		const FProperty* RelativeHeadProperty = ULookAtComponent::StaticClass()->FindPropertyByName(ULookAtComponent::GetRelativeHeadPropertyName());
		const FProperty* RelativeBodyProperty = ULookAtComponent::StaticClass()->FindPropertyByName(ULookAtComponent::GetRelativeBodyPropertyName());
		const FProperty* RelativeSpine_01Property = ULookAtComponent::StaticClass()->FindPropertyByName(ULookAtComponent::GetRelativeSpine_01PropertyName());
		const FProperty* RelativeSpine_02Property = ULookAtComponent::StaticClass()->FindPropertyByName(ULookAtComponent::GetRelativeSpine_02PropertyName());
		const FProperty* RelativeSpine_03Property = ULookAtComponent::StaticClass()->FindPropertyByName(ULookAtComponent::GetRelativeSpine_03PropertyName());
		FText EyeGroup = NSLOCTEXT("MovieSceneLookAtSection", "Eye", "Eye");
		FText HeadGroup = NSLOCTEXT("MovieSceneLookAtSection", "Head", "Head");
		FText BodyGroup = NSLOCTEXT("MovieSceneLookAtSection", "Body", "Body");
		FText Spine_01Group = NSLOCTEXT("MovieSceneLookAtSection", "Spine_01", "Spine_01");
		FText Spine_02Group = NSLOCTEXT("MovieSceneLookAtSection", "Spine_02", "Spine_02");
		FText Spine_03Group = NSLOCTEXT("MovieSceneLookAtSection", "Spine_03", "Spine_03");
		{
			MetaData[0].SetIdentifiers("Eye.X", NSLOCTEXT("MovieSceneLookAtSection", "EyeX", "Roll"), EyeGroup);
			MetaData[0].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::EyeX);
			MetaData[0].Color = FCommonChannelData::RedChannelColor;
			MetaData[0].SortOrder = SortOrderStart;
			MetaData[0].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[0].PropertyMetaData.Add(PropertyMetaDataKey, RelativeEyeProperty->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[1].SetIdentifiers("Eye.Y", NSLOCTEXT("MovieSceneLookAtSection", "EyeY", "Pitch"), EyeGroup);
			MetaData[1].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::EyeY);
			MetaData[1].Color = FCommonChannelData::GreenChannelColor;
			MetaData[1].SortOrder = SortOrderStart + 1;
			MetaData[1].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[1].PropertyMetaData.Add(PropertyMetaDataKey, RelativeEyeProperty->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[2].SetIdentifiers("Eye.Z", NSLOCTEXT("MovieSceneLookAtSection", "EyeZ", "Scale"), EyeGroup);
			MetaData[2].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::EyeZ);
			MetaData[2].Color = FCommonChannelData::BlueChannelColor;
			MetaData[2].SortOrder = SortOrderStart + 2;
			MetaData[2].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[2].PropertyMetaData.Add(PropertyMetaDataKey, RelativeEyeProperty->GetMetaData(PropertyMetaDataKey));
			}
		}
		{
			MetaData[3].SetIdentifiers("Head.X", NSLOCTEXT("MovieSceneLookAtSection", "HeadX", "Roll"), HeadGroup);
			MetaData[3].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::HeadX);
			MetaData[3].Color = FCommonChannelData::RedChannelColor;
			MetaData[3].SortOrder = SortOrderStart + 3;
			MetaData[3].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[3].PropertyMetaData.Add(PropertyMetaDataKey, RelativeHeadProperty->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[4].SetIdentifiers("Head.Y", NSLOCTEXT("MovieSceneLookAtSection", "HeadY", "Pitch"), HeadGroup);
			MetaData[4].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::HeadY);
			MetaData[4].Color = FCommonChannelData::GreenChannelColor;
			MetaData[4].SortOrder = SortOrderStart + 4;
			MetaData[4].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[4].PropertyMetaData.Add(PropertyMetaDataKey, RelativeHeadProperty->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[5].SetIdentifiers("Head.Z", NSLOCTEXT("MovieSceneLookAtSection", "HeadZ", "Yaw"), HeadGroup);
			MetaData[5].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::HeadZ);
			MetaData[5].Color = FCommonChannelData::BlueChannelColor;
			MetaData[5].SortOrder = SortOrderStart + 5;
			MetaData[5].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[5].PropertyMetaData.Add(PropertyMetaDataKey, RelativeHeadProperty->GetMetaData(PropertyMetaDataKey));
			}
		}
		{
			MetaData[6].SetIdentifiers("Body.X", NSLOCTEXT("MovieSceneLookAtSection", "BodyX", "Roll"), BodyGroup);
			MetaData[6].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::BodyX);
			MetaData[6].Color = FCommonChannelData::RedChannelColor;
			MetaData[6].SortOrder = SortOrderStart + 6;
			MetaData[6].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[6].PropertyMetaData.Add(PropertyMetaDataKey, RelativeBodyProperty->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[7].SetIdentifiers("Body.Y", NSLOCTEXT("MovieSceneLookAtSection", "BodyY", "Pitch"), BodyGroup);
			MetaData[7].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::BodyY);
			MetaData[7].Color = FCommonChannelData::GreenChannelColor;
			MetaData[7].SortOrder = SortOrderStart + 7;
			MetaData[7].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[7].PropertyMetaData.Add(PropertyMetaDataKey, RelativeBodyProperty->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[8].SetIdentifiers("Body.Z", NSLOCTEXT("MovieSceneLookAtSection", "BodyZ", "Yaw"), BodyGroup);
			MetaData[8].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::BodyZ);
			MetaData[8].Color = FCommonChannelData::BlueChannelColor;
			MetaData[8].SortOrder = SortOrderStart + 8;
			MetaData[8].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[8].PropertyMetaData.Add(PropertyMetaDataKey, RelativeBodyProperty->GetMetaData(PropertyMetaDataKey));
			}
		}
		{
			MetaData[9].SetIdentifiers("Spine_01.X", NSLOCTEXT("MovieSceneLookAtSection", "Spine_01X", "Roll"), Spine_01Group);
			MetaData[9].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Spine_01X);
			MetaData[9].Color = FCommonChannelData::RedChannelColor;
			MetaData[9].SortOrder = SortOrderStart + 9;
			MetaData[9].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[9].PropertyMetaData.Add(PropertyMetaDataKey, RelativeSpine_01Property->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[10].SetIdentifiers("Spine_01.Y", NSLOCTEXT("MovieSceneLookAtSection", "Spine_01Y", "Pitch"), Spine_01Group);
			MetaData[10].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Spine_01Y);
			MetaData[10].Color = FCommonChannelData::GreenChannelColor;
			MetaData[10].SortOrder = SortOrderStart + 10;
			MetaData[10].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[10].PropertyMetaData.Add(PropertyMetaDataKey, RelativeSpine_01Property->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[11].SetIdentifiers("Spine_01.Z", NSLOCTEXT("MovieSceneLookAtSection", "Spine_01Z", "Yaw"), Spine_01Group);
			MetaData[11].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Spine_01Z);
			MetaData[11].Color = FCommonChannelData::BlueChannelColor;
			MetaData[11].SortOrder = SortOrderStart + 11;
			MetaData[11].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[11].PropertyMetaData.Add(PropertyMetaDataKey, RelativeSpine_01Property->GetMetaData(PropertyMetaDataKey));
			}
		}

		{
			MetaData[12].SetIdentifiers("Spine_02.X", NSLOCTEXT("MovieSceneLookAtSection", "Spine_02X", "Roll"), Spine_02Group);
			MetaData[12].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Spine_02X);
			MetaData[12].Color = FCommonChannelData::RedChannelColor;
			MetaData[12].SortOrder = SortOrderStart + 12;
			MetaData[12].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[12].PropertyMetaData.Add(PropertyMetaDataKey, RelativeSpine_02Property->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[13].SetIdentifiers("Spine_02.Y", NSLOCTEXT("MovieSceneLookAtSection", "Spine_02Y", "Pitch"), Spine_02Group);
			MetaData[13].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Spine_02Y);
			MetaData[13].Color = FCommonChannelData::GreenChannelColor;
			MetaData[13].SortOrder = SortOrderStart + 13;
			MetaData[13].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[13].PropertyMetaData.Add(PropertyMetaDataKey, RelativeSpine_02Property->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[14].SetIdentifiers("Spine_02.Z", NSLOCTEXT("MovieSceneLookAtSection", "Spine_02Z", "Yaw"), Spine_02Group);
			MetaData[14].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Spine_02Z);
			MetaData[14].Color = FCommonChannelData::BlueChannelColor;
			MetaData[14].SortOrder = SortOrderStart + 14;
			MetaData[14].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[14].PropertyMetaData.Add(PropertyMetaDataKey, RelativeSpine_02Property->GetMetaData(PropertyMetaDataKey));
			}
		}

		{
			MetaData[15].SetIdentifiers("Spine_03.X", NSLOCTEXT("MovieSceneLookAtSection", "Spine_03X", "Roll"), Spine_03Group);
			MetaData[15].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Spine_03X);
			MetaData[15].Color = FCommonChannelData::RedChannelColor;
			MetaData[15].SortOrder = SortOrderStart + 15;
			MetaData[15].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[15].PropertyMetaData.Add(PropertyMetaDataKey, RelativeSpine_03Property->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[16].SetIdentifiers("Spine_03.Y", NSLOCTEXT("MovieSceneLookAtSection", "Spine_03Y", "Pitch"), Spine_03Group);
			MetaData[16].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Spine_03Y);
			MetaData[16].Color = FCommonChannelData::GreenChannelColor;
			MetaData[16].SortOrder = SortOrderStart + 16;
			MetaData[16].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[16].PropertyMetaData.Add(PropertyMetaDataKey, RelativeSpine_03Property->GetMetaData(PropertyMetaDataKey));
			}

			MetaData[17].SetIdentifiers("Spine_03.Z", NSLOCTEXT("MovieSceneLookAtSection", "Spine_03Z", "Yaw"), Spine_03Group);
			MetaData[17].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Spine_03Z);
			MetaData[17].Color = FCommonChannelData::BlueChannelColor;
			MetaData[17].SortOrder = SortOrderStart + 17;
			MetaData[17].bCanCollapseToTrack = false;
			for (const FName& PropertyMetaDataKey : PropertyMetaDataKeys)
			{
				MetaData[17].PropertyMetaData.Add(PropertyMetaDataKey, RelativeSpine_03Property->GetMetaData(PropertyMetaDataKey));
			}
		}
		{
			MetaData[18].SetIdentifiers("Weight", NSLOCTEXT("MovieSceneLookAtSection", "Weight", "Weight"));
			MetaData[18].bEnabled = EnumHasAllFlags(Mask, EMovieSceneLookAtChannel::Weight);
		}

		ExternalValues[0].OnGetExternalValue = ExtractEyeX;
		ExternalValues[1].OnGetExternalValue = ExtractEyeY;
		ExternalValues[2].OnGetExternalValue = ExtractEyeZ;
		ExternalValues[3].OnGetExternalValue = ExtractHeadX;
		ExternalValues[4].OnGetExternalValue = ExtractHeadY;
		ExternalValues[5].OnGetExternalValue = ExtractHeadZ;
		ExternalValues[6].OnGetExternalValue = ExtractBodyX;
		ExternalValues[7].OnGetExternalValue = ExtractBodyY;
		ExternalValues[8].OnGetExternalValue = ExtractBodyZ;

		ExternalValues[9].OnGetExternalValue = ExtractSpine_01X;
		ExternalValues[10].OnGetExternalValue = ExtractSpine_01Y;
		ExternalValues[11].OnGetExternalValue = ExtractSpine_01Z;

		ExternalValues[12].OnGetExternalValue = ExtractSpine_02X;
		ExternalValues[13].OnGetExternalValue = ExtractSpine_02Y;
		ExternalValues[14].OnGetExternalValue = ExtractSpine_02Z;

		ExternalValues[15].OnGetExternalValue = ExtractSpine_03X;
		ExternalValues[16].OnGetExternalValue = ExtractSpine_03Y;
		ExternalValues[17].OnGetExternalValue = ExtractSpine_03Z;
	}

	static TOptional<FRotator> GetEye(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		const FStructProperty* TransformProperty = Bindings ? CastField<FStructProperty>(Bindings->GetProperty(InObject)) : nullptr;

		if (TransformProperty)
		{
			if (TransformProperty->Struct == TBaseStructure<FTransform>::Get())
			{
				if (TOptional<FTransform> Transform = Bindings->GetOptionalValue<FTransform>(InObject))
				{
					return Transform->GetRotation().Rotator();
				}
			}
			else if (TransformProperty->Struct == TBaseStructure<FEulerTransform>::Get())
			{
				if (TOptional<FEulerTransform> EulerTransform = Bindings->GetOptionalValue<FEulerTransform>(InObject))
				{
					return EulerTransform->Rotation;
				}
			}
		}
		else if (AActor* Actor = Cast<AActor>(&InObject))
		{
			if (USceneComponent* RootComponent = Actor->GetRootComponent())
			{
				return RootComponent->GetRelativeRotation();
			}
		}

		return TOptional<FRotator>();
	}

	static TOptional<FRotator> GetHead(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		const FStructProperty* TransformProperty = Bindings ? CastField<FStructProperty>(Bindings->GetProperty(InObject)) : nullptr;

		if (TransformProperty)
		{
			if (TransformProperty->Struct == TBaseStructure<FTransform>::Get())
			{
				if (TOptional<FTransform> Transform = Bindings->GetOptionalValue<FTransform>(InObject))
				{
					return Transform->GetRotation().Rotator();
				}
			}
			else if (TransformProperty->Struct == TBaseStructure<FEulerTransform>::Get())
			{
				if (TOptional<FEulerTransform> EulerTransform = Bindings->GetOptionalValue<FEulerTransform>(InObject))
				{
					return EulerTransform->Rotation;
				}
			}
		}
		else if (AActor* Actor = Cast<AActor>(&InObject))
		{
			if (USceneComponent* RootComponent = Actor->GetRootComponent())
			{
				return RootComponent->GetRelativeRotation();
			}
		}

		return TOptional<FRotator>();
	}

	static TOptional<FRotator> GetBody(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		const FStructProperty* TransformProperty = Bindings ? CastField<FStructProperty>(Bindings->GetProperty(InObject)) : nullptr;

		if (TransformProperty)
		{
			if (TransformProperty->Struct == TBaseStructure<FTransform>::Get())
			{
				if (TOptional<FTransform> Transform = Bindings->GetOptionalValue<FTransform>(InObject))
				{
					return Transform->GetRotation().Rotator();
				}
			}
			else if (TransformProperty->Struct == TBaseStructure<FEulerTransform>::Get())
			{
				if (TOptional<FEulerTransform> EulerTransform = Bindings->GetOptionalValue<FEulerTransform>(InObject))
				{
					return EulerTransform->Rotation;
				}
			}
		}
		else if (AActor* Actor = Cast<AActor>(&InObject))
		{
			if (USceneComponent* RootComponent = Actor->GetRootComponent())
			{
				return RootComponent->GetRelativeRotation();
			}
		}

		return TOptional<FRotator>();
	}

	static TOptional<FRotator> GetSpine_01(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		const FStructProperty* TransformProperty = Bindings ? CastField<FStructProperty>(Bindings->GetProperty(InObject)) : nullptr;

		if (TransformProperty)
		{
			if (TransformProperty->Struct == TBaseStructure<FTransform>::Get())
			{
				if (TOptional<FTransform> Transform = Bindings->GetOptionalValue<FTransform>(InObject))
				{
					return Transform->GetRotation().Rotator();
				}
			}
			else if (TransformProperty->Struct == TBaseStructure<FEulerTransform>::Get())
			{
				if (TOptional<FEulerTransform> EulerTransform = Bindings->GetOptionalValue<FEulerTransform>(InObject))
				{
					return EulerTransform->Rotation;
				}
			}
		}
		else if (AActor* Actor = Cast<AActor>(&InObject))
		{
			if (USceneComponent* RootComponent = Actor->GetRootComponent())
			{
				return RootComponent->GetRelativeRotation();
			}
		}

		return TOptional<FRotator>();
	}

	static TOptional<FRotator> GetSpine_02(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		const FStructProperty* TransformProperty = Bindings ? CastField<FStructProperty>(Bindings->GetProperty(InObject)) : nullptr;

		if (TransformProperty)
		{
			if (TransformProperty->Struct == TBaseStructure<FTransform>::Get())
			{
				if (TOptional<FTransform> Transform = Bindings->GetOptionalValue<FTransform>(InObject))
				{
					return Transform->GetRotation().Rotator();
				}
			}
			else if (TransformProperty->Struct == TBaseStructure<FEulerTransform>::Get())
			{
				if (TOptional<FEulerTransform> EulerTransform = Bindings->GetOptionalValue<FEulerTransform>(InObject))
				{
					return EulerTransform->Rotation;
				}
			}
		}
		else if (AActor* Actor = Cast<AActor>(&InObject))
		{
			if (USceneComponent* RootComponent = Actor->GetRootComponent())
			{
				return RootComponent->GetRelativeRotation();
			}
		}

		return TOptional<FRotator>();
	}

	static TOptional<FRotator> GetSpine_03(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		const FStructProperty* TransformProperty = Bindings ? CastField<FStructProperty>(Bindings->GetProperty(InObject)) : nullptr;

		if (TransformProperty)
		{
			if (TransformProperty->Struct == TBaseStructure<FTransform>::Get())
			{
				if (TOptional<FTransform> Transform = Bindings->GetOptionalValue<FTransform>(InObject))
				{
					return Transform->GetRotation().Rotator();
				}
			}
			else if (TransformProperty->Struct == TBaseStructure<FEulerTransform>::Get())
			{
				if (TOptional<FEulerTransform> EulerTransform = Bindings->GetOptionalValue<FEulerTransform>(InObject))
				{
					return EulerTransform->Rotation;
				}
			}
		}
		else if (AActor* Actor = Cast<AActor>(&InObject))
		{
			if (USceneComponent* RootComponent = Actor->GetRootComponent())
			{
				return RootComponent->GetRelativeRotation();
			}
		}

		return TOptional<FRotator>();
	}
	static TOptional<double> ExtractEyeX(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Eye = GetEye(InObject, Bindings);
		return Eye.IsSet() ? Eye->Roll : TOptional<double>();
	}
	static TOptional<double> ExtractEyeY(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Eye = GetEye(InObject, Bindings);
		return Eye.IsSet() ? Eye->Pitch : TOptional<double>();
	}
	static TOptional<double> ExtractEyeZ(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Eye = GetEye(InObject, Bindings);
		return Eye.IsSet() ? Eye->Yaw : TOptional<double>();
	}

	static TOptional<double> ExtractHeadX(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Head = GetHead(InObject, Bindings);
		return Head.IsSet() ? Head->Roll : TOptional<double>();
	}
	static TOptional<double> ExtractHeadY(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Head = GetHead(InObject, Bindings);
		return Head.IsSet() ? Head->Pitch : TOptional<double>();
	}
	static TOptional<double> ExtractHeadZ(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Head = GetHead(InObject, Bindings);
		return Head.IsSet() ? Head->Yaw : TOptional<double>();
	}

	static TOptional<double> ExtractBodyX(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Body = GetBody(InObject, Bindings);
		return Body.IsSet() ? Body->Roll : TOptional<double>();
	}
	static TOptional<double> ExtractBodyY(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Body = GetBody(InObject, Bindings);
		return Body.IsSet() ? Body->Pitch : TOptional<double>();
	}
	static TOptional<double> ExtractBodyZ(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Body = GetBody(InObject, Bindings);
		return Body.IsSet() ? Body->Yaw : TOptional<double>();
	}

	static TOptional<double> ExtractSpine_01X(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Spine_01 = GetSpine_01(InObject, Bindings);
		return Spine_01.IsSet() ? Spine_01->Roll : TOptional<double>();
	}
	static TOptional<double> ExtractSpine_01Y(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Spine_01 = GetSpine_01(InObject, Bindings);
		return Spine_01.IsSet() ? Spine_01->Pitch : TOptional<double>();
	}
	static TOptional<double> ExtractSpine_01Z(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Spine_01 = GetSpine_01(InObject, Bindings);
		return Spine_01.IsSet() ? Spine_01->Yaw : TOptional<double>();
	}

	static TOptional<double> ExtractSpine_02X(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Spine_02 = GetSpine_02(InObject, Bindings);
		return Spine_02.IsSet() ? Spine_02->Roll : TOptional<double>();
	}
	static TOptional<double> ExtractSpine_02Y(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Spine_02 = GetSpine_02(InObject, Bindings);
		return Spine_02.IsSet() ? Spine_02->Pitch : TOptional<double>();
	}
	static TOptional<double> ExtractSpine_02Z(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Spine_02 = GetSpine_02(InObject, Bindings);
		return Spine_02.IsSet() ? Spine_02->Yaw : TOptional<double>();
	}

	static TOptional<double> ExtractSpine_03X(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Spine_03 = GetSpine_03(InObject, Bindings);
		return Spine_03.IsSet() ? Spine_03->Roll : TOptional<double>();
	}
	static TOptional<double> ExtractSpine_03Y(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Spine_03 = GetSpine_03(InObject, Bindings);
		return Spine_03.IsSet() ? Spine_03->Pitch : TOptional<double>();
	}
	static TOptional<double> ExtractSpine_03Z(UObject& InObject, FTrackInstancePropertyBindings* Bindings)
	{
		TOptional<FRotator> Spine_03 = GetSpine_03(InObject, Bindings);
		return Spine_03.IsSet() ? Spine_03->Yaw : TOptional<double>();
	}

	// cppcheck:push ignore
	FMovieSceneChannelMetaData      MetaData[19];
	TMovieSceneExternalValue<double> ExternalValues[18];
	TMovieSceneExternalValue<float> WeightExternalValue;
	// cppcheck:pop
};

#endif // WITH_EDITOR

/* FMovieSceneEyeKeyStruct interface
 *****************************************************************************/

void FMovieSceneEyeKeyStruct::PropagateChanges(const FPropertyChangedEvent& ChangeEvent)
{
	KeyStructInterop.Apply(Time);
}


/* FMovieSceneHeadKeyStruct interface
 *****************************************************************************/

void FMovieSceneHeadKeyStruct::PropagateChanges(const FPropertyChangedEvent& ChangeEvent)
{
	KeyStructInterop.Apply(Time);
}


/* FMovieSceneBodyKeyStruct interface
 *****************************************************************************/

void FMovieSceneBodyKeyStruct::PropagateChanges(const FPropertyChangedEvent& ChangeEvent)
{
	KeyStructInterop.Apply(Time);
}

/* FMovieSceneSpine_01KeyStruct interface
 *****************************************************************************/

void FMovieSceneSpine_01KeyStruct::PropagateChanges(const FPropertyChangedEvent& ChangeEvent)
{
	KeyStructInterop.Apply(Time);
}

/* FMovieSceneSpine_02KeyStruct interface
 *****************************************************************************/

void FMovieSceneSpine_02KeyStruct::PropagateChanges(const FPropertyChangedEvent& ChangeEvent)
{
	KeyStructInterop.Apply(Time);
}


/* FMovieSceneSpine_03KeyStruct interface
 *****************************************************************************/

void FMovieSceneSpine_03KeyStruct::PropagateChanges(const FPropertyChangedEvent& ChangeEvent)
{
	KeyStructInterop.Apply(Time);
}


/* FMovieSceneLookAtKeyStruct interface
 *****************************************************************************/

void FMovieSceneLookAtKeyStruct::PropagateChanges(const FPropertyChangedEvent& ChangeEvent)
{
	KeyStructInterop.Apply(Time);
}

namespace UE::MovieScene
{
	static constexpr uint32 ConstraintTypeMask = 1 << 31;
}


/* UMovieSceneLookAtSection interface
 *****************************************************************************/
UE::MovieScene::FChannelOverrideNames UMovieSceneLookAtSection::ChannelOverrideNames(10, {
		TEXT("Eye.X"), TEXT("Eye.Y"), TEXT("Eye.Z"),
		TEXT("Head.X"), TEXT("Head.Y"), TEXT("Head.Z"),
		TEXT("Body.X"), TEXT("Body.Y"), TEXT("Body.Z"),
		TEXT("Spine_01.X"), TEXT("Spine_01.Y"), TEXT("Spine_01.Z"),
		TEXT("Spine_02.X"), TEXT("Spine_02.Y"), TEXT("Spine_02.Z"),
		TEXT("Spine_03.X"), TEXT("Spine_03.Y"), TEXT("Spine_03.Z"),
		TEXT("Weight")
	});

UMovieSceneLookAtSection::UMovieSceneLookAtSection(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bUseQuaternionInterpolation(false)
#if WITH_EDITORONLY_DATA
	, Show3DTrajectory(EShowLookAtTrajectory::EST_OnlyWhenSelected)
#endif
{
#if WITH_EDITORONLY_DATA
	bIsInfinite_DEPRECATED = true;
#endif

	
	EvalOptions.EnableAndSetCompletionMode
	(GetLinkerCustomVersion(FSequencerObjectVersion::GUID) < FSequencerObjectVersion::WhenFinishedDefaultsToRestoreState ?
		EMovieSceneCompletionMode::KeepState :
		GetLinkerCustomVersion(FSequencerObjectVersion::GUID) < FSequencerObjectVersion::WhenFinishedDefaultsToProjectDefault ?
		EMovieSceneCompletionMode::RestoreState :
		EMovieSceneCompletionMode::ProjectDefault);

	LookAtMask = EMovieSceneLookAtChannel::AllTransform;
	BlendType = EMovieSceneBlendType::Absolute;
	bSupportsInfiniteRange = true;

	Eye[0].SetDefault(0.f);
	Eye[1].SetDefault(0.f);
	Eye[2].SetDefault(1.f);// this is eye scale ,need default set 1.0

	Head[0].SetDefault(0.f);
	Head[1].SetDefault(0.f);
	Head[2].SetDefault(0.f);

	Body[0].SetDefault(0.f);
	Body[1].SetDefault(0.f);
	Body[2].SetDefault(0.f);

	Spine_01[0].SetDefault(0.f);
	Spine_01[1].SetDefault(0.f);
	Spine_01[2].SetDefault(0.f);

	Spine_02[0].SetDefault(0.f);
	Spine_02[1].SetDefault(0.f);
	Spine_02[2].SetDefault(0.f);

	Spine_03[0].SetDefault(0.f);
	Spine_03[1].SetDefault(0.f);
	Spine_03[2].SetDefault(0.f);

//	bSupportsInfiniteRange = true;
//	SetRange(TRange<FFrameNumber>::All());
//	FloatCurve.SetDefault(1.f);
//	EvalOptions.EnableAndSetCompletionMode
//		(GetLinkerCustomVersion(FSequencerObjectVersion::GUID) < FSequencerObjectVersion::WhenFinishedDefaultsToProjectDefault ? 
//			EMovieSceneCompletionMode::RestoreState : 
//			EMovieSceneCompletionMode::ProjectDefault);
//
//#if WITH_EDITOR
//
//	ChannelProxy = MakeShared<FMovieSceneChannelProxy>(FloatCurve, FMovieSceneChannelMetaData(), TMovieSceneExternalValue<float>::Make());
//
//#else
//
//	ChannelProxy = MakeShared<FMovieSceneChannelProxy>(FloatCurve);
//
//#endif
}

void UMovieSceneLookAtSection::OnBindingIDsUpdated(const TMap<UE::MovieScene::FFixedObjectBindingID, UE::MovieScene::FFixedObjectBindingID>& OldFixedToNewFixedMap, FMovieSceneSequenceID LocalSequenceID, TSharedRef<UE::MovieScene::FSharedPlaybackState> SharedPlaybackState)
{
	if (Constraints)
	{
		for (FConstraintAndActiveChannel& ConstraintChannel : Constraints->ConstraintsChannels)
		{
			if (UTickableTransformConstraint* TransformConstraint = Cast< UTickableTransformConstraint>(ConstraintChannel.GetConstraint().Get()))
			{
				//Don't do child's we do that in the system, needed for duplication
				if (TransformConstraint->ParentTRSHandle)
				{
					TransformConstraint->ParentTRSHandle->OnBindingIDsUpdated(OldFixedToNewFixedMap, LocalSequenceID, SharedPlaybackState);
				}
			}
			if (UTickableTransformConstraint* SpawnCopy = Cast< UTickableTransformConstraint>(ConstraintChannel.GetConstraint()))
			{
				//Don't do child's we do that in the system, needed for duplication
				if (SpawnCopy->ParentTRSHandle)
				{
					SpawnCopy->ParentTRSHandle->OnBindingIDsUpdated(OldFixedToNewFixedMap, LocalSequenceID, SharedPlaybackState);
				}
			}
		}
	}
}

void UMovieSceneLookAtSection::GetReferencedBindings(TArray<FGuid>& OutBindings)
{
	if (Constraints)
	{
		for (FConstraintAndActiveChannel& ConstraintChannel : Constraints->ConstraintsChannels)
		{
			if (UTickableTransformConstraint* TransformConstraint = Cast< UTickableTransformConstraint>(ConstraintChannel.GetConstraint().Get()))
			{
				if (TransformConstraint->ChildTRSHandle && TransformConstraint->ChildTRSHandle->ConstraintBindingID.IsValid())
				{
					OutBindings.Add(TransformConstraint->ChildTRSHandle->ConstraintBindingID.GetGuid());
				}
				if (TransformConstraint->ParentTRSHandle && TransformConstraint->ParentTRSHandle->ConstraintBindingID.IsValid())
				{
					OutBindings.Add(TransformConstraint->ParentTRSHandle->ConstraintBindingID.GetGuid());
				}
			}
		}
	}
}

void UMovieSceneLookAtSection::PreSave(FObjectPreSaveContext SaveContext)
{
	Super::PreSave(SaveContext);
	if (Constraints)
	{
		for (FConstraintAndActiveChannel& ActiveChannel : Constraints->ConstraintsChannels)
		{
			if (ActiveChannel.GetConstraint().Get())
			{
				ActiveChannel.GetConstraint() = ActiveChannel.GetConstraint()->Duplicate(this);
			}
		}
	}
}

template<typename BaseBuilderType>
inline void UMovieSceneLookAtSection::BuildEntity(BaseBuilderType& InBaseBuilder, UMovieSceneEntitySystemLinker* Linker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity)
{
	using namespace UE::MovieScene;

	FBuiltInComponentTypes* BuiltInComponentTypes = FBuiltInComponentTypes::Get();
	FMovieSceneTracksComponentTypes* TrackComponents = FMovieSceneTracksComponentTypes::Get();
	UMovieScenePropertyTrack* Track = GetTypedOuter<UMovieScenePropertyTrack>();

	check(Track);

	const bool bIsComponentTransform = Track->IsA<UMovieSceneLookAtTrack>();
	const bool bIsEulerTransform = Track->IsA<UMovieSceneEulerTransformTrack>();

	FComponentTypeID PropertyTag = TrackComponents->Transform.PropertyTag;
	if (bIsComponentTransform)
	{
		PropertyTag = TrackComponents->ComponentTransform.PropertyTag;
	}
	else if (bIsEulerTransform)
	{
		PropertyTag = TrackComponents->EulerTransform.PropertyTag;
	}

	EMovieSceneLookAtChannel Channels = LookAtMask.GetChannels();

	const bool ActiveChannelsMask[] = {
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::EyeX) && Eye[0].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::EyeY) && Eye[1].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::EyeZ) && Eye[2].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::HeadX) && Head[0].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::HeadY) && Head[1].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::HeadZ) && Head[2].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::BodyX) && Body[0].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::BodyY) && Body[1].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::BodyZ) && Body[2].HasAnyData(),

		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Spine_01X) && Spine_01[0].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Spine_01Y) && Spine_01[1].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Spine_01Z) && Spine_01[2].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Spine_02X) && Spine_02[0].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Spine_02Y) && Spine_02[1].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Spine_02Z) && Spine_02[2].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Spine_03X) && Spine_03[0].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Spine_03Y) && Spine_03[1].HasAnyData(),
		EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Spine_03Z) && Spine_03[2].HasAnyData(),
	};

	if (!Algo::AnyOf(ActiveChannelsMask))
	{
		return;
	}

	TComponentTypeID<FSourceDoubleChannel> EyeChannel[3], HeadChannel[3], BodyChannel[3], Spine_01Channel[3], Spine_02Channel[3], Spine_03Channel[3];
	if (!bUseQuaternionInterpolation)
	{
		EyeChannel[0] = BuiltInComponentTypes->DoubleChannel[0];
		EyeChannel[1] = BuiltInComponentTypes->DoubleChannel[1];
		EyeChannel[2] = BuiltInComponentTypes->DoubleChannel[2];
		HeadChannel[0] = BuiltInComponentTypes->DoubleChannel[3];
		HeadChannel[1] = BuiltInComponentTypes->DoubleChannel[4];
		HeadChannel[2] = BuiltInComponentTypes->DoubleChannel[5];
		BodyChannel[0] = BuiltInComponentTypes->DoubleChannel[6];
		BodyChannel[1] = BuiltInComponentTypes->DoubleChannel[7];
		BodyChannel[2] = BuiltInComponentTypes->DoubleChannel[8];

		Spine_01Channel[0] = BuiltInComponentTypes->DoubleChannel[9];
		Spine_01Channel[1] = BuiltInComponentTypes->DoubleChannel[10];
		Spine_01Channel[2] = BuiltInComponentTypes->DoubleChannel[11];
		Spine_02Channel[0] = BuiltInComponentTypes->DoubleChannel[12];
		Spine_02Channel[1] = BuiltInComponentTypes->DoubleChannel[13];
		Spine_02Channel[2] = BuiltInComponentTypes->DoubleChannel[14];
		Spine_03Channel[0] = BuiltInComponentTypes->DoubleChannel[15];
		Spine_03Channel[1] = BuiltInComponentTypes->DoubleChannel[16];
		Spine_03Channel[2] = BuiltInComponentTypes->DoubleChannel[17];
	}
	else
	{
		EyeChannel[0] = TrackComponents->QuaternionRotationChannel[0];
		EyeChannel[1] = TrackComponents->QuaternionRotationChannel[1];
		EyeChannel[2] = TrackComponents->QuaternionRotationChannel[2];
		/*HeadChannel[0] = TrackComponents->QuaternionRotationChannel[3];
		HeadChannel[1] = TrackComponents->QuaternionRotationChannel[4];
		HeadChannel[2] = TrackComponents->QuaternionRotationChannel[5];
		BodyChannel[0] = TrackComponents->QuaternionRotationChannel[6];
		BodyChannel[1] = TrackComponents->QuaternionRotationChannel[7];
		BodyChannel[2] = TrackComponents->QuaternionRotationChannel[8];*/
	}

	// Let the override registry handle overriden channels
	const FName ChannelOverrideName = ChannelOverrideNames.GetChannelName(Params.EntityID);

	// If we are building the entity of an overriden channel, we pass the partial builder we have at this point 
	// (the one with the bindings) and add the tag to it.
	// Then call into the override repository so it can add a second builder with the override stuff.
	if (ChannelOverrideName != NAME_None)
	{
		if (!ensureMsgf(OverrideRegistry && OverrideRegistry->ContainsChannel(ChannelOverrideName),
			TEXT("We received an entity ID that corresponds to an override channel, but no such override channel exists in the registry.")))
		{
			return;
		}

		const int32 ChannelOverrideIndex = (Params.EntityID - ChannelOverrideNames.IndexOffset);
		if (ChannelOverrideIndex == 9)
		{
			if (EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Weight))
			{
				OutImportedEntity->AddBuilder(InBaseBuilder.AddTag(PropertyTag));

				FChannelOverrideEntityImportParams OverrideParams{ ChannelOverrideName, BuiltInComponentTypes->WeightResult };
				OverrideRegistry->ImportEntityImpl(OverrideParams, Params, OutImportedEntity);
			}
		}
		else
		{
			if (ActiveChannelsMask[ChannelOverrideIndex])
			{
				OutImportedEntity->AddBuilder(InBaseBuilder.AddTag(PropertyTag));

				FChannelOverrideEntityImportParams OverrideParams{ ChannelOverrideName, BuiltInComponentTypes->DoubleResult[ChannelOverrideIndex] };
				OverrideRegistry->ImportEntityImpl(OverrideParams, Params, OutImportedEntity);
			}
		}
		return;
	}

	// Here proceed with the all the normal channels
	OutImportedEntity->AddBuilder(
		InBaseBuilder
		.AddConditional(EyeChannel[0], &Eye[0], ActiveChannelsMask[0] && !IsChannelOverriden(OverrideRegistry, TEXT("Eye.X")))
		.AddConditional(EyeChannel[1], &Eye[1], ActiveChannelsMask[1] && !IsChannelOverriden(OverrideRegistry, TEXT("Eye.Y")))
		.AddConditional(EyeChannel[2], &Eye[2], ActiveChannelsMask[2] && !IsChannelOverriden(OverrideRegistry, TEXT("Eye.Z")))
		.AddConditional(HeadChannel[0], &Head[0], ActiveChannelsMask[3] && !IsChannelOverriden(OverrideRegistry, TEXT("Head.X")))
		.AddConditional(HeadChannel[1], &Head[1], ActiveChannelsMask[4] && !IsChannelOverriden(OverrideRegistry, TEXT("Head.Y")))
		.AddConditional(HeadChannel[2], &Head[2], ActiveChannelsMask[5] && !IsChannelOverriden(OverrideRegistry, TEXT("Head.Z")))
		.AddConditional(BodyChannel[0], &Body[0], ActiveChannelsMask[6] && !IsChannelOverriden(OverrideRegistry, TEXT("Body.X")))
		.AddConditional(BodyChannel[1], &Body[1], ActiveChannelsMask[7] && !IsChannelOverriden(OverrideRegistry, TEXT("Body.Y")))
		.AddConditional(BodyChannel[2], &Body[2], ActiveChannelsMask[8] && !IsChannelOverriden(OverrideRegistry, TEXT("Body.Z")))

		.AddConditional(Spine_01Channel[0], &Spine_01[0], ActiveChannelsMask[9] && !IsChannelOverriden(OverrideRegistry, TEXT("Spine_01.X")))
		.AddConditional(Spine_01Channel[1], &Spine_01[1], ActiveChannelsMask[10] && !IsChannelOverriden(OverrideRegistry, TEXT("Spine_01.Y")))
		.AddConditional(Spine_01Channel[2], &Spine_01[2], ActiveChannelsMask[11] && !IsChannelOverriden(OverrideRegistry, TEXT("Spine_01.Z")))
		.AddConditional(Spine_02Channel[0], &Spine_02[0], ActiveChannelsMask[12] && !IsChannelOverriden(OverrideRegistry, TEXT("Spine_02.X")))
		.AddConditional(Spine_02Channel[1], &Spine_02[1], ActiveChannelsMask[13] && !IsChannelOverriden(OverrideRegistry, TEXT("Spine_02.Y")))
		.AddConditional(Spine_02Channel[2], &Spine_02[2], ActiveChannelsMask[14] && !IsChannelOverriden(OverrideRegistry, TEXT("Spine_02.Z")))
		.AddConditional(Spine_03Channel[0], &Spine_03[0], ActiveChannelsMask[15] && !IsChannelOverriden(OverrideRegistry, TEXT("Spine_03.X")))
		.AddConditional(Spine_03Channel[1], &Spine_03[1], ActiveChannelsMask[16] && !IsChannelOverriden(OverrideRegistry, TEXT("Spine_03.Y")))
		.AddConditional(Spine_03Channel[2], &Spine_03[2], ActiveChannelsMask[17] && !IsChannelOverriden(OverrideRegistry, TEXT("Spine_03.Z")))
		.AddConditional(BuiltInComponentTypes->WeightChannel, &ManualWeight, EnumHasAnyFlags(Channels, EMovieSceneLookAtChannel::Weight) && ManualWeight.HasAnyData() && !IsChannelOverriden(OverrideRegistry, TEXT("Weight")))
		.AddTag(PropertyTag)
	);
}

void UMovieSceneLookAtSection::PopulateConstraintEntities(const TRange<FFrameNumber>& EffectiveRange, const FMovieSceneEvaluationFieldEntityMetaData& InMetaData, FMovieSceneEntityComponentFieldBuilder* OutFieldBuilder)
{
	check(Constraints);

	using namespace UE::MovieScene;

	const int32 MetaDataIndex = OutFieldBuilder->AddMetaData(InMetaData);

	// Add explicitly typed entities for each constraint
	// Encode the top bit of the entity ID to mean it is a constraint
	// We can check this in ImportEntityImpl to import the correct constraint
	for (int32 ConstraintIndex = 0; ConstraintIndex < Constraints->ConstraintsChannels.Num(); ++ConstraintIndex)
	{
		// Entity IDs for constraints are their index within the array, masked with the top bit set
		const uint32 EntityID = ConstraintIndex | ConstraintTypeMask;
		OutFieldBuilder->AddPersistentEntity(EffectiveRange, this, EntityID, MetaDataIndex);
	}
}


bool UMovieSceneLookAtSection::PopulateEvaluationFieldImpl(const TRange<FFrameNumber>& EffectiveRange, const FMovieSceneEvaluationFieldEntityMetaData& InMetaData, FMovieSceneEntityComponentFieldBuilder* OutFieldBuilder)
{
	if (Constraints)
	{
		PopulateConstraintEntities(EffectiveRange, InMetaData, OutFieldBuilder);
	}
	if (OverrideRegistry)
	{
		// Add evaluation field entries for each channel that runs with a different logic.
		OverrideRegistry->PopulateEvaluationFieldImpl(EffectiveRange, InMetaData, OutFieldBuilder, *this);
	}

	// Return false even if we have an override registry, so that we also add an evaluation field entry for the default
	// stuff.
	return false;
}

void UMovieSceneLookAtSection::ImportConstraintEntity(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity)
{
	using namespace UE::MovieScene;

	FBuiltInComponentTypes* BuiltInComponentTypes = FBuiltInComponentTypes::Get();
	FMovieSceneTracksComponentTypes* TrackComponents = FMovieSceneTracksComponentTypes::Get();

	// Constraints must always operate on a USceneComponent. Putting one on a generic FTransform property has no effect (or is not possible).
	FGuid ObjectBindingID = Params.GetObjectBindingID();
	if (ObjectBindingID.IsValid())
	{
		// Mask out the top bit to get the constraint index we encoded into the EntityID.
		const int32 ConstraintIndex = static_cast<int32>(Params.EntityID & ~ConstraintTypeMask);

		checkf(Constraints->ConstraintsChannels.IsValidIndex(ConstraintIndex), TEXT("Encoded constraint (%d) index is not valid within array size %d. Data must have been manipulated without re-compilaition."), ConstraintIndex, Constraints->ConstraintsChannels.Num());
		//add if constraint or spawn copy is valid
		if (Constraints->ConstraintsChannels[ConstraintIndex].GetConstraint().Get() ||
			Constraints->ConstraintsChannels[ConstraintIndex].GetConstraint())
		{
			FName ConstraintName = Constraints->ConstraintsChannels[ConstraintIndex].GetConstraint().Get() ? Constraints->ConstraintsChannels[ConstraintIndex].GetConstraint()->GetFName()
				: Constraints->ConstraintsChannels[ConstraintIndex].GetConstraint()->GetFName();

			/* todo yy
			FConstraintComponentData ComponentData;
			ComponentData.ConstraintName = ConstraintName;
			ComponentData.Section = this;
			OutImportedEntity->AddBuilder(
				FEntityBuilder()
				.Add(BuiltInComponentTypes->SceneComponentBinding, ObjectBindingID)
				.Add(TrackComponents->ConstraintChannel, ComponentData)
			);*/
		}
	}
}

void UMovieSceneLookAtSection::ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity)
{
	using namespace UE::MovieScene;

	/*const FBuiltInComponentTypes* BuiltInComponents = FBuiltInComponentTypes::Get();
	const FMovieSceneTracksLookAtTypes* TrackComponents = FMovieSceneTracksLookAtTypes::Get();

	const FGuid ObjectBindingID = Params.GetObjectBindingID();
	FMovieSceneLookAtData ComponentData{ this };

	OutImportedEntity->AddBuilder(
		FEntityBuilder()
		.Add(TrackComponents->LookAt, ComponentData)
		.AddConditional(BuiltInComponents->GenericObjectBinding, ObjectBindingID, ObjectBindingID.IsValid())
	);*/

	if ((Params.EntityID & ConstraintTypeMask) != 0 && Constraints)
	{
		ImportConstraintEntity(EntityLinker, Params, OutImportedEntity);
		return;
	}

	FBuiltInComponentTypes* BuiltInComponentTypes = FBuiltInComponentTypes::Get();
	UMovieScenePropertyTrack* Track = GetTypedOuter<UMovieScenePropertyTrack>();

	check(Track);

	// 3D Transform tracks use a scene component binding by default. Every other transform property track must be bound directly to the object.
	const TComponentTypeID<FGuid>& ObjectBinding = Track->IsA<UMovieSceneLookAtTrack>()
		? BuiltInComponentTypes->SceneComponentBinding
		: BuiltInComponentTypes->GenericObjectBinding;

	FGuid ObjectBindingID = Params.GetObjectBindingID();

	auto BaseBuilder = FEntityBuilder()
		.Add(BuiltInComponentTypes->PropertyBinding, Track->GetPropertyBinding())
		.AddConditional(ObjectBinding, ObjectBindingID, ObjectBindingID.IsValid());

	BuildEntity(BaseBuilder, EntityLinker, Params, OutImportedEntity);
}

void UMovieSceneLookAtSection::InterrogateEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity)
{
	using namespace UE::MovieScene;

	FBuiltInComponentTypes* BuiltInComponentTypes = FBuiltInComponentTypes::Get();

	auto BaseBuilder = FEntityBuilder().AddDefaulted(BuiltInComponentTypes->EvalTime);
	BuildEntity(BaseBuilder, EntityLinker, Params, OutImportedEntity);
}

FMovieSceneLookAtMask UMovieSceneLookAtSection::GetMask() const
{
	return LookAtMask;
}

void UMovieSceneLookAtSection::SetMask(FMovieSceneLookAtMask NewMask)
{
	LookAtMask = NewMask;
	ChannelProxy = nullptr;
}

FMovieSceneLookAtMask UMovieSceneLookAtSection::GetMaskByName(const FName& InName) const
{
	if (InName.ToString() == NSLOCTEXT("MovieSceneLookAtSection", "Eye", "Eye").ToString())
	{
		return EMovieSceneLookAtChannel::Eye;
	}
	else if (InName == TEXT("Eye.X"))
	{
		return EMovieSceneLookAtChannel::EyeX;
	}
	else if (InName == TEXT("Eye.Y"))
	{
		return EMovieSceneLookAtChannel::EyeY;
	}
	else if (InName == TEXT("Eye.Z"))
	{
		return EMovieSceneLookAtChannel::EyeZ;
	}
	else if (InName.ToString() == NSLOCTEXT("MovieSceneLookAtSection", "Head", "Head").ToString())
	{
		return EMovieSceneLookAtChannel::Head;
	}
	else if (InName == TEXT("Head.X"))
	{
		return EMovieSceneLookAtChannel::HeadX;
	}
	else if (InName == TEXT("Head.Y"))
	{
		return EMovieSceneLookAtChannel::HeadY;
	}
	else if (InName == TEXT("Head.Z"))
	{
		return EMovieSceneLookAtChannel::HeadZ;
	}
	else if (InName.ToString() == NSLOCTEXT("MovieSceneLookAtSection", "Body", "Body").ToString())
	{
		return EMovieSceneLookAtChannel::Body;
	}
	else if (InName == TEXT("Body.X"))
	{
		return EMovieSceneLookAtChannel::BodyX;
	}
	else if (InName == TEXT("Body.Y"))
	{
		return EMovieSceneLookAtChannel::BodyY;
	}
	else if (InName == TEXT("Body.Z"))
	{
		return EMovieSceneLookAtChannel::BodyZ;
	}

	else if (InName.ToString() == NSLOCTEXT("MovieSceneLookAtSection", "Spine_01", "Spine_01").ToString())
	{
		return EMovieSceneLookAtChannel::Spine_01;
	}
	else if (InName == TEXT("Spine_01.X"))
	{
		return EMovieSceneLookAtChannel::Spine_01X;
	}
	else if (InName == TEXT("Spine_01.Y"))
	{
		return EMovieSceneLookAtChannel::Spine_01Y;
	}
	else if (InName == TEXT("Spine_01.Z"))
	{
		return EMovieSceneLookAtChannel::Spine_01Z;
	}

	else if (InName.ToString() == NSLOCTEXT("MovieSceneLookAtSection", "Spine_02", "Spine_02").ToString())
	{
		return EMovieSceneLookAtChannel::Spine_02;
	}
	else if (InName == TEXT("Spine_02.X"))
	{
		return EMovieSceneLookAtChannel::Spine_02X;
	}
	else if (InName == TEXT("Spine_02.Y"))
	{
		return EMovieSceneLookAtChannel::Spine_02Y;
	}
	else if (InName == TEXT("Spine_02.Z"))
	{
		return EMovieSceneLookAtChannel::Spine_02Z;
	}

	else if (InName.ToString() == NSLOCTEXT("MovieSceneLookAtSection", "Spine_03", "Spine_03").ToString())
	{
		return EMovieSceneLookAtChannel::Spine_03;
	}
	else if (InName == TEXT("Spine_03.X"))
	{
		return EMovieSceneLookAtChannel::Spine_03X;
	}
	else if (InName == TEXT("Spine_03.Y"))
	{
		return EMovieSceneLookAtChannel::Spine_03Y;
	}
	else if (InName == TEXT("Spine_03.Z"))
	{
		return EMovieSceneLookAtChannel::Spine_03Z;
	}
	//Constraints aren't masked since they need to be deleted etc via their own API's
	FString ConstraintString = NSLOCTEXT("MovieSceneLookAtSection", "Constraint", "Constraint").ToString();
	if (InName.ToString().Contains(ConstraintString))
	{
		return EMovieSceneLookAtChannel::None;
	}
	return EMovieSceneLookAtChannel::All;
}


EMovieSceneChannelProxyType UMovieSceneLookAtSection::CacheChannelProxy()
{
	using namespace UE::MovieScene;

	FMovieSceneChannelProxyData Channels;

#if WITH_EDITOR

	auto GetValidConstraint = [](FConstraintAndActiveChannel& ConstraintChannel)
		{
			if (ConstraintChannel.GetConstraint().Get())
			{
				return ConstraintChannel.GetConstraint().Get();
			}
			return (ConstraintChannel.GetConstraint().Get());
		};
#endif

	//Constraints go on top
	int32 NumConstraints = 0;
	if (Constraints)
	{
		for (FConstraintAndActiveChannel& ConstraintChannel : Constraints->ConstraintsChannels)
		{
#if WITH_EDITOR
			TWeakObjectPtr<UTickableConstraint> WeakConstraint = GetValidConstraint(ConstraintChannel);
			if (WeakConstraint.IsValid())
			{
				FText ConstraintGroup = NSLOCTEXT("MovieSceneLookAtSection", "Constraints", "Constraints");
				const FName& ConstraintName = WeakConstraint->GetFName();
				ConstraintChannel.ActiveChannel.ExtraLabel = [WeakConstraint]
					{
						if (WeakConstraint.IsValid())
						{
							FString ParentStr; WeakConstraint->GetLabel().Split(TEXT("."), &ParentStr, nullptr);
							if (!ParentStr.IsEmpty())
							{
								return ParentStr;
							}
						}
						static const FString DummyStr;
						return DummyStr;
					};
				const FText DisplayText = FText::FromString(WeakConstraint->GetTypeLabel());
				FMovieSceneChannelMetaData MetaData(ConstraintName, DisplayText, ConstraintGroup, true /*bInEnabled*/);
				MetaData.SortOrder = NumConstraints++;
				MetaData.bCanCollapseToTrack = false;
				Channels.Add(ConstraintChannel.ActiveChannel, MetaData, TMovieSceneExternalValue<bool>());
			}
#else
			Channels.Add(ConstraintChannel.ActiveChannel);
#endif

		}
	}

#if WITH_EDITOR

	FLookAtChannelEditorData EditorData(LookAtMask.GetChannels(), NumConstraints);

	AddChannelProxy(Channels, OverrideRegistry, TEXT("Eye.X"), Eye[0], EditorData.MetaData[0], EditorData.ExternalValues[0]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Eye.Y"), Eye[1], EditorData.MetaData[1], EditorData.ExternalValues[1]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Eye.Z"), Eye[2], EditorData.MetaData[2], EditorData.ExternalValues[2]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Head.X"), Head[0], EditorData.MetaData[3], EditorData.ExternalValues[3]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Head.Y"), Head[1], EditorData.MetaData[4], EditorData.ExternalValues[4]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Head.Z"), Head[2], EditorData.MetaData[5], EditorData.ExternalValues[5]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Body.X"), Body[0], EditorData.MetaData[6], EditorData.ExternalValues[6]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Body.Y"), Body[1], EditorData.MetaData[7], EditorData.ExternalValues[7]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Body.Z"), Body[2], EditorData.MetaData[8], EditorData.ExternalValues[8]);

	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_01.X"), Spine_01[0], EditorData.MetaData[9], EditorData.ExternalValues[9]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_01.Y"), Spine_01[1], EditorData.MetaData[10], EditorData.ExternalValues[10]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_01.Z"), Spine_01[2], EditorData.MetaData[11], EditorData.ExternalValues[11]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_02.X"), Spine_02[0], EditorData.MetaData[12], EditorData.ExternalValues[12]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_02.Y"), Spine_02[1], EditorData.MetaData[13], EditorData.ExternalValues[13]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_02.Z"), Spine_02[2], EditorData.MetaData[14], EditorData.ExternalValues[14]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_03.X"), Spine_03[0], EditorData.MetaData[15], EditorData.ExternalValues[15]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_03.Y"), Spine_03[1], EditorData.MetaData[16], EditorData.ExternalValues[16]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_03.Z"), Spine_03[2], EditorData.MetaData[17], EditorData.ExternalValues[17]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Weight"), ManualWeight, EditorData.MetaData[18], EditorData.WeightExternalValue);

#else

	AddChannelProxy(Channels, OverrideRegistry, TEXT("Eye.X"), Eye[0]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Eye.Y"), Eye[1]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Eye.Z"), Eye[2]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Head.X"), Head[0]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Head.Y"), Head[1]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Head.Z"), Head[2]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Body.X"), Body[0]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Body.Y"), Body[1]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Body.Z"), Body[2]);

	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_01.X"), Spine_01[0]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_01.Y"), Spine_01[1]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_01.Z"), Spine_01[2]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_02.X"), Spine_02[0]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_02.Y"), Spine_02[1]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_02.Z"), Spine_02[2]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_03.X"), Spine_03[0]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_03.Y"), Spine_03[1]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Spine_03.Z"), Spine_03[2]);
	AddChannelProxy(Channels, OverrideRegistry, TEXT("Weight"), ManualWeight);

#endif

	ChannelProxy = MakeShared<FMovieSceneChannelProxy>(MoveTemp(Channels));
	return EMovieSceneChannelProxyType::Dynamic;
}


TSharedPtr<FStructOnScope> UMovieSceneLookAtSection::GetKeyStruct(TArrayView<const FKeyHandle> KeyHandles)
{
	TArrayView<FMovieSceneDoubleChannel* const> DoubleChannels = ChannelProxy->GetChannels<FMovieSceneDoubleChannel>();

	TOptional<TTuple<FKeyHandle, FFrameNumber>> EyeKeys[3] = {
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[0], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[1], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[2], KeyHandles)
	};

	TOptional<TTuple<FKeyHandle, FFrameNumber>> HeadKeys[3] = {
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[3], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[4], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[5], KeyHandles)
	};

	TOptional<TTuple<FKeyHandle, FFrameNumber>> BodyKeys[3] = {
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[6], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[7], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[8], KeyHandles)
	};

	TOptional<TTuple<FKeyHandle, FFrameNumber>> Spine_01Keys[3] = {
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[9], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[10], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[11], KeyHandles)
	};

	TOptional<TTuple<FKeyHandle, FFrameNumber>> Spine_02Keys[3] = {
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[12], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[13], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[14], KeyHandles)
	};

	TOptional<TTuple<FKeyHandle, FFrameNumber>> Spine_03Keys[3] = {
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[15], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[16], KeyHandles),
		FMovieSceneChannelValueHelper::FindFirstKey(DoubleChannels[17], KeyHandles)
	};
	const int32 AnyEyeKeys = Algo::AnyOf(EyeKeys);
	const int32 AnyHeadKeys = Algo::AnyOf(HeadKeys);
	const int32 AnyBodyKeys = Algo::AnyOf(BodyKeys);

	const int32 AnySpine_01Keys = Algo::AnyOf(Spine_01Keys);
	const int32 AnySpine_02Keys = Algo::AnyOf(Spine_02Keys);
	const int32 AnySpine_03Keys = Algo::AnyOf(Spine_03Keys);

	// do we have multiple keys on multiple parts of the transform?
	if (AnyEyeKeys + AnyHeadKeys + AnyBodyKeys + AnySpine_01Keys + AnySpine_02Keys + AnySpine_03Keys > 1)
	{
		TSharedRef<FStructOnScope> KeyStruct = MakeShareable(new FStructOnScope(FMovieSceneLookAtKeyStruct::StaticStruct()));
		auto Struct = (FMovieSceneLookAtKeyStruct*)KeyStruct->GetStructMemory();

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(0), &Struct->Eye.Roll, EyeKeys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(1), &Struct->Eye.Pitch, EyeKeys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(2), &Struct->Eye.Yaw, EyeKeys[2]));

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(3), &Struct->Head.Roll, HeadKeys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(4), &Struct->Head.Pitch, HeadKeys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(5), &Struct->Head.Yaw, HeadKeys[2]));

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(6), &Struct->Body.Roll, BodyKeys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(7), &Struct->Body.Pitch, BodyKeys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(8), &Struct->Body.Yaw, BodyKeys[2]));

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(9), &Struct->Spine_01.Roll, Spine_01Keys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(10), &Struct->Spine_01.Pitch, Spine_01Keys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(11), &Struct->Spine_01.Yaw, Spine_01Keys[2]));

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(12), &Struct->Spine_02.Roll, Spine_02Keys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(13), &Struct->Spine_02.Pitch, Spine_02Keys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(14), &Struct->Spine_02.Yaw, Spine_02Keys[2]));

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(15), &Struct->Spine_03.Roll, Spine_03Keys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(16), &Struct->Spine_03.Pitch, Spine_03Keys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(17), &Struct->Spine_03.Yaw, Spine_03Keys[2]));

		Struct->KeyStructInterop.SetStartingValues();
		Struct->Time = Struct->KeyStructInterop.GetUnifiedKeyTime().Get(0);
		return KeyStruct;
	}

	if (AnyEyeKeys)
	{
		TSharedRef<FStructOnScope> KeyStruct = MakeShareable(new FStructOnScope(FMovieSceneEyeKeyStruct::StaticStruct()));
		auto Struct = (FMovieSceneEyeKeyStruct*)KeyStruct->GetStructMemory();

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(0), &Struct->Eye.Roll, EyeKeys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(1), &Struct->Eye.Pitch, EyeKeys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(2), &Struct->Eye.Yaw, EyeKeys[2]));

		Struct->KeyStructInterop.SetStartingValues();
		Struct->Time = Struct->KeyStructInterop.GetUnifiedKeyTime().Get(0);
		return KeyStruct;
	}

	if (AnyHeadKeys)
	{
		TSharedRef<FStructOnScope> KeyStruct = MakeShareable(new FStructOnScope(FMovieSceneHeadKeyStruct::StaticStruct()));
		auto Struct = (FMovieSceneHeadKeyStruct*)KeyStruct->GetStructMemory();

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(3), &Struct->Head.Roll, HeadKeys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(4), &Struct->Head.Pitch, HeadKeys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(5), &Struct->Head.Yaw, HeadKeys[2]));

		Struct->KeyStructInterop.SetStartingValues();
		Struct->Time = Struct->KeyStructInterop.GetUnifiedKeyTime().Get(0);
		return KeyStruct;
	}

	if (AnyBodyKeys)
	{
		TSharedRef<FStructOnScope> KeyStruct = MakeShareable(new FStructOnScope(FMovieSceneBodyKeyStruct::StaticStruct()));
		auto Struct = (FMovieSceneBodyKeyStruct*)KeyStruct->GetStructMemory();

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(6), &Struct->Body.Roll, BodyKeys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(7), &Struct->Body.Pitch, BodyKeys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(8), &Struct->Body.Yaw, BodyKeys[2]));

		Struct->KeyStructInterop.SetStartingValues();
		Struct->Time = Struct->KeyStructInterop.GetUnifiedKeyTime().Get(0);
		return KeyStruct;
	}


	if (AnySpine_01Keys)
	{
		TSharedRef<FStructOnScope> KeyStruct = MakeShareable(new FStructOnScope(FMovieSceneSpine_01KeyStruct::StaticStruct()));
		auto Struct = (FMovieSceneSpine_01KeyStruct*)KeyStruct->GetStructMemory();

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(9), &Struct->Spine_01.Roll, Spine_01Keys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(10), &Struct->Spine_01.Pitch, Spine_01Keys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(11), &Struct->Spine_01.Yaw, Spine_01Keys[2]));

		Struct->KeyStructInterop.SetStartingValues();
		Struct->Time = Struct->KeyStructInterop.GetUnifiedKeyTime().Get(0);
		return KeyStruct;
	}

	if (AnySpine_02Keys)
	{
		TSharedRef<FStructOnScope> KeyStruct = MakeShareable(new FStructOnScope(FMovieSceneSpine_02KeyStruct::StaticStruct()));
		auto Struct = (FMovieSceneSpine_02KeyStruct*)KeyStruct->GetStructMemory();

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(12), &Struct->Spine_02.Roll, Spine_02Keys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(13), &Struct->Spine_02.Pitch, Spine_02Keys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(14), &Struct->Spine_02.Yaw, Spine_02Keys[2]));

		Struct->KeyStructInterop.SetStartingValues();
		Struct->Time = Struct->KeyStructInterop.GetUnifiedKeyTime().Get(0);
		return KeyStruct;
	}

	if (AnySpine_03Keys)
	{
		TSharedRef<FStructOnScope> KeyStruct = MakeShareable(new FStructOnScope(FMovieSceneSpine_03KeyStruct::StaticStruct()));
		auto Struct = (FMovieSceneSpine_03KeyStruct*)KeyStruct->GetStructMemory();

		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(15), &Struct->Spine_03.Roll, Spine_03Keys[0]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(16), &Struct->Spine_03.Pitch, Spine_03Keys[1]));
		Struct->KeyStructInterop.Add(FMovieSceneChannelValueHelper(ChannelProxy->MakeHandle<FMovieSceneDoubleChannel>(17), &Struct->Spine_03.Yaw, Spine_03Keys[2]));

		Struct->KeyStructInterop.SetStartingValues();
		Struct->Time = Struct->KeyStructInterop.GetUnifiedKeyTime().Get(0);
		return KeyStruct;
	}
	return nullptr;
}


bool UMovieSceneLookAtSection::GetUseQuaternionInterpolation() const
{
	return bUseQuaternionInterpolation;
}


void UMovieSceneLookAtSection::SetUseQuaternionInterpolation(bool bInUseQuaternionInterpolation)
{
	bUseQuaternionInterpolation = bInUseQuaternionInterpolation;
}

bool UMovieSceneLookAtSection::ShowCurveForChannel(const void* ChannelPtr) const
{
	if (GetUseQuaternionInterpolation())
	{
		return ChannelPtr != &Head[0] && ChannelPtr != &Head[1] && ChannelPtr != &Head[2];
	}
	return true;
}

void UMovieSceneLookAtSection::SetBlendType(EMovieSceneBlendType InBlendType)
{
	Super::SetBlendType(InBlendType);
	if (GetSupportedBlendTypes().Contains(InBlendType))
	{
		if (InBlendType == EMovieSceneBlendType::Absolute)
		{
			Body[0].SetDefault(1.f);
			Body[1].SetDefault(1.f);
			Body[2].SetDefault(1.f);
		}
		else if (InBlendType == EMovieSceneBlendType::Additive || InBlendType == EMovieSceneBlendType::Relative)
		{
			Body[0].SetDefault(0.f);
			Body[1].SetDefault(0.f);
			Body[2].SetDefault(0.f);
		}
	}
}

bool UMovieSceneLookAtSection::HasConstraintChannel(const FGuid& InGuid) const
{
	if (Constraints)
	{
		return Constraints->ConstraintsChannels.ContainsByPredicate([InGuid](const FConstraintAndActiveChannel& InChannel)
			{
				return InChannel.GetConstraint().Get() ? InChannel.GetConstraint()->ConstraintID == InGuid : false;
			});
	}
	return false;
}

FConstraintAndActiveChannel* UMovieSceneLookAtSection::GetConstraintChannel(const FGuid& InGuid)
{
	if (Constraints)
	{
		const int32 Index = Constraints->ConstraintsChannels.IndexOfByPredicate([InGuid](const FConstraintAndActiveChannel& InChannel)
			{
				return InChannel.GetConstraint().Get() ? InChannel.GetConstraint()->ConstraintID == InGuid : (InChannel.GetConstraint() ?
					InChannel.GetConstraint()->ConstraintID == InGuid : false);
			});
		return (Index != INDEX_NONE) ? &(Constraints->ConstraintsChannels[Index]) : nullptr;
	}
	return nullptr;
}

TArray<FConstraintAndActiveChannel>& UMovieSceneLookAtSection::GetConstraintsChannels()
{
	static TArray< FConstraintAndActiveChannel> EmptyChannels;
	if (Constraints)
	{
		return Constraints->ConstraintsChannels;
	}
	return EmptyChannels;
}

#if WITH_EDITOR
bool UMovieSceneLookAtSection::Modify(bool bAlwaysMarkDirty)
{
	using namespace UE::MovieScene;
	if (Constraints)
	{
		Constraints->SetFlags(RF_Transactional);
		Constraints->Modify(bAlwaysMarkDirty);
	}
	bool bModified = Super::Modify(bAlwaysMarkDirty);

	return bModified;
}

void UMovieSceneLookAtSection::PostDuplicate(bool bDuplicateForPIE)
{
	Super::PostDuplicate(bDuplicateForPIE);
	//if not duplicating for PIE clear out the soft object ptrs to the constraints we dont' want to hold pointers to the old constraints.
	//also make the copy to spawn so we can duplicate it if it doesn't exist in the level
	//to the old ones but make new duplicates
	if (bDuplicateForPIE == false && Constraints)
	{
		for (FConstraintAndActiveChannel& ConstraintChannel : Constraints->ConstraintsChannels)
		{
			if (ConstraintChannel.GetConstraint().Get() && !ConstraintChannel.GetConstraint())
			{
				ConstraintChannel.SetConstraint(ConstraintChannel.GetConstraint()->Duplicate(this));
			}
			ConstraintChannel.SetConstraint(nullptr);
		}
	}
}

#endif


void UMovieSceneLookAtSection::AddConstraintChannel(UTickableConstraint* InConstraint)
{
	Modify();
	if (!Constraints)
	{
		Constraints = NewObject<UMovieSceneLookAtSectionConstraints>(this, NAME_None, RF_Public | RF_Transactional);
	}
	if (InConstraint && !HasConstraintChannel(InConstraint->ConstraintID))
	{
		Constraints->SetFlags(RF_Transactional);
		Constraints->Modify();
		const int32 NewIndex = Constraints->ConstraintsChannels.Add(FConstraintAndActiveChannel(InConstraint));

		FMovieSceneConstraintChannel* ExistingChannel = &Constraints->ConstraintsChannels[NewIndex].ActiveChannel;
		ExistingChannel->SetDefault(false);

		//make copy that we can spawn if it doesn't exist
		Constraints->ConstraintsChannels[NewIndex].SetConstraint(InConstraint->Duplicate(this));

		CacheChannelProxy();

		if (OnConstraintChannelAdded.IsBound())
		{
			OnConstraintChannelAdded.Broadcast(this, ExistingChannel);
		}
	}
}

void UMovieSceneLookAtSection::ReplaceConstraint(const FName InConstraintName, UTickableConstraint* InConstraint)
{
	if (Constraints)
	{
		const int32 Index = Constraints->ConstraintsChannels.IndexOfByPredicate([InConstraintName](const FConstraintAndActiveChannel& InChannel)
			{
				return InChannel.GetConstraint() ? InChannel.GetConstraint()->GetFName() == InConstraintName : false;
			});
		if (Index != INDEX_NONE)
		{
			Modify();
			Constraints->ConstraintsChannels[Index].SetConstraint(InConstraint);
			CacheChannelProxy();
		}
	}
}

void UMovieSceneLookAtSection::RemoveConstraintChannel(const UTickableConstraint* InConstraint)
{
	if (bDoNotRemoveChannel == true)
	{
		return;
	}
	if (Constraints)
	{
		const int32 Index = Constraints->ConstraintsChannels.IndexOfByPredicate([InConstraint](const FConstraintAndActiveChannel& InChannel)
			{
				return InChannel.GetConstraint().Get() ? InChannel.GetConstraint() == InConstraint : false;
			});

		if (Constraints->ConstraintsChannels.IsValidIndex(Index))
		{
			Modify();
			Constraints->ConstraintsChannels.RemoveAt(Index);
			CacheChannelProxy();
		}
	}
}

UMovieSceneSectionChannelOverrideRegistry* UMovieSceneLookAtSection::GetChannelOverrideRegistry(bool bCreateIfMissing)
{
	if (bCreateIfMissing && OverrideRegistry == nullptr)
	{
		OverrideRegistry = NewObject<UMovieSceneSectionChannelOverrideRegistry>(this, NAME_None, RF_Transactional);
	}
	return OverrideRegistry;
}

UE::MovieScene::FChannelOverrideProviderTraitsHandle UMovieSceneLookAtSection::GetChannelOverrideProviderTraits() const
{
	struct FLookAtChannelOverrideProviderTraits : UE::MovieScene::FChannelOverrideProviderTraits
	{
		FName GetDefaultChannelTypeName(FName ChannelName) const override
		{
			if (ChannelName == TEXT("Weight"))
			{
				return FMovieSceneFloatChannel::StaticStruct()->GetFName();
			}
			else
			{
				return FMovieSceneDoubleChannel::StaticStruct()->GetFName();
			}
		}

		int32 GetChannelOverrideEntityID(FName ChannelName) const override
		{
			return UMovieSceneLookAtSection::ChannelOverrideNames.GetIndex(ChannelName);
		}

		FName GetChannelOverrideName(int32 EntityID) const override
		{
			return UMovieSceneLookAtSection::ChannelOverrideNames.GetChannelName(EntityID);
		}
	};

	FLookAtChannelOverrideProviderTraits Traits;
	return UE::MovieScene::FChannelOverrideProviderTraitsHandle(Traits);
}


void UMovieSceneLookAtSection::OnConstraintsChanged()
{
	ChannelProxy = nullptr;
}


void UMovieSceneLookAtSection::OnChannelOverridesChanged()
{
	ChannelProxy = nullptr;
}


#if WITH_EDITOR
void UMovieSceneLookAtSection::PostPaste()
{
	Super::PostPaste();
	if (OverrideRegistry)
	{
		OverrideRegistry->OnPostPaste();
	}
	if (Constraints)
	{
		Constraints->ClearFlags(RF_Transient);
	}
}

void UMovieSceneLookAtSectionConstraints::PostEditUndo()
{
	Super::PostEditUndo();
	if (UMovieSceneLookAtSection* Section = GetTypedOuter<UMovieSceneLookAtSection>())
	{
		if (IMovieSceneConstrainedSection* ConstrainedSection = Cast<IMovieSceneConstrainedSection>(Section))
		{
			ConstrainedSection->OnConstraintsChanged();
		}
	}
}
#endif