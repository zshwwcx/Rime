// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: lizhang@kuaishou.com

#include "CutScene/KGMovieSceneComponentType.h"
#include "EntitySystem/MovieSceneEntitySystemLinker.h"
#include "EntitySystem/MovieSceneEntityFactoryTemplates.h"

static bool GKGMovieSceneComponentTypesDestroyed = false;
static TUniquePtr<FKGMovieSceneComponentType> GKGMovieSceneComponentTypes;

FKGMovieSceneComponentType::FKGMovieSceneComponentType()
{
	UE::MovieScene::FComponentRegistry* ComponentRegistry = UMovieSceneEntitySystemLinker::GetComponents();

	Tags.BatchMaterialOnActor = ComponentRegistry->NewTag(TEXT("Batch Material On Actor"));
	ComponentRegistry->Factories.DefineChildComponent(Tags.BatchMaterialOnActor, Tags.BatchMaterialOnActor);

	ComponentRegistry->NewComponentType(&Components.BatchMaterialSlotName, TEXT("BatchMaterialSlotName"));
	ComponentRegistry->Factories.DuplicateChildComponent(Components.BatchMaterialSlotName);
}

FKGMovieSceneComponentType::~FKGMovieSceneComponentType()
{
}

void FKGMovieSceneComponentType::Destroy()
{
	GKGMovieSceneComponentTypes.Reset();
	GKGMovieSceneComponentTypesDestroyed = true;
}

FKGMovieSceneComponentType* FKGMovieSceneComponentType::Get()
{
	if (!GKGMovieSceneComponentTypes.IsValid())
	{
		check(!GKGMovieSceneComponentTypesDestroyed);
		GKGMovieSceneComponentTypes.Reset(new FKGMovieSceneComponentType);
	}
	return GKGMovieSceneComponentTypes.Get();
}