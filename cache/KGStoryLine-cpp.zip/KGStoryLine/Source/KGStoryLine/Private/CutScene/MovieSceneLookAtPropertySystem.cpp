// Copyright Epic Games, Inc. All Rights Reserved.FPreAnimatedLookAtTraits

#include "CutScene/MovieSceneLookAtPropertySystem.h"
#include "CutScene/MovieSceneTracksLookAtTypes.h"
#include "Systems/MovieScenePropertyInstantiator.h"
#include "Systems/DoubleChannelEvaluatorSystem.h"
#include "Systems/MovieScenePiecewiseDoubleBlenderSystem.h"
#include "AnimSequencerInstance.h"
#include "SkeletalMeshRestoreState.h"
#include "3C/Animation/LookAt/CutSceneAnimInstance.h"
#include "AnimCustomInstanceHelper.h"
#include "EntitySystem/MovieSceneEntitySystemRunner.h"
#include "3C/Animation/LookAt/LookAtComponent.h"
#include "3C/Character/BaseCharacter.h"
#include "IMovieScenePlayer.h"
#include "Engine/SkeletalMesh.h"


#include UE_INLINE_GENERATED_CPP_BY_NAME(MovieSceneLookAtPropertySystem)

UMovieSceneLookAtPropertySystem::UMovieSceneLookAtPropertySystem(const FObjectInitializer& ObjInit)
	: Super(ObjInit)
{
	BindToProperty(UE::MovieScene::FMovieSceneTracksComponentTypes::Get()->Transform);
	if (HasAnyFlags(RF_ClassDefaultObject))
	{
		DefineImplicitPrerequisite(UMovieScenePiecewiseDoubleBlenderSystem::StaticClass(), GetClass());
		DefineImplicitPrerequisite(UDoubleChannelEvaluatorSystem::StaticClass(), GetClass());
	}
}

void UMovieSceneLookAtPropertySystem::OnRun(FSystemTaskPrerequisites& InPrerequisites, FSystemSubsequentTasks& Subsequents)
{
	Super::OnRun(InPrerequisites, Subsequents);
}

