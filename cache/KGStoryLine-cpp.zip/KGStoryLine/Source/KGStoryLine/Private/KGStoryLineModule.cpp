#include "KGStoryLineModule.h"
//#include "Core.h"
#include "Modules/ModuleManager.h"
#define LOCTEXT_NAMESPACE "FKGStoryLineModule"

#if __has_include("CxxReflectionKGStoryLine.h")
#include "CxxReflectionKGStoryLine.h"
#endif

DEFINE_LOG_CATEGORY(LogKGStoryLine);

void FKGStoryLineModule::StartupModule()
{
#if __has_include("CxxReflectionKGStoryLine.h") && !defined(KG_CXX_REFLECTING)
	REGISTER_LAZY_REGISTER(KGStoryLine);
#endif
}

void FKGStoryLineModule::ShutdownModule()
{
}

IMPLEMENT_MODULE(FKGStoryLineModule, KGStoryLine)

#undef LOCTEXT_NAMESPACE