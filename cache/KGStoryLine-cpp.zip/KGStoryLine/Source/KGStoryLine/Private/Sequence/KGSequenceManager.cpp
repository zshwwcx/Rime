#include "Sequence/KGSequenceManager.h"

#include "DefaultLevelSequenceInstanceData.h"
#include "EngineUtils.h"
#include "LevelSequencePlayer.h"
#include "MovieScene.h"
#include "Tracks/MovieSceneSubTrack.h"
#include "Sections/MovieSceneSubSection.h"
#include "MovieSceneSequencePlayer.h"
#include "3C/Util/KGUtils.h"
#include "LevelSequenceActor.h"
#include "Sequence/SequenceLoadTask.h"
#include "LuaObject.h"
#include "Sections/MovieScene3DAttachSection.h"
#include "Tracks/MovieScene3DAttachTrack.h"
#include "Tracks/MovieScene3DTransformTrack.h"
#include "CutScene/MovieSceneCustomTrack.h"
#include "Bindings/MovieSceneSpawnableActorBinding.h"
#include "TimeManagementBlueprintLibrary.h"
#include "Engine/TriggerBox.h"
#include "GameFramework/ActorPlatformSetUtilities.h"

#if WITH_EDITOR
#include "Editor.h"
#include "Subsystems/UnrealEditorSubsystem.h"
#endif

DEFINE_LOG_CATEGORY(LogSequenceManager);

#pragma region CVar
static TAutoConsoleVariable<int> CVarSequenceAssetsPlatform(TEXT("CutScene.SequenceAssetsPlatform"), 0, TEXT("0-Editor, 1-PC Cooked, 2-Mobile Cooked"));
#pragma endregion CVar

#pragma region Important
UKGSequenceManager::UKGSequenceManager()
{

}

UKGSequenceManager* UKGSequenceManager::GetInstance(UObject* InContext)
{
	return Cast<UKGSequenceManager>(GetManagerByType(InContext, EManagerType::EMT_SequenceManager));
}


UKGSequenceManager* UKGSequenceManager::GetSequenceManagerInEditor()
{
#if WITH_EDITOR
	UUnrealEditorSubsystem* UnrealEditorSubsystem = GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>();
	if (UnrealEditorSubsystem)
	{
		UWorld* SceneWorld = UnrealEditorSubsystem->GetEditorWorld();
		if (SceneWorld)
		{
			UKGSequenceManager* KGSequenceManager = UKGSequenceManager::GetInstance(SceneWorld);
			return KGSequenceManager;
		}
	}
#endif
	return nullptr;
}

UKGSequenceManager* UKGSequenceManager::GetSequenceManager(IMovieScenePlayer& Player)
{
	if (UObject* AsUObject = Player.AsUObject()) return GetInstance(AsUObject);
	return GetSequenceManagerInEditor();
}

void UKGSequenceManager::NativeInit()
{
	Super::NativeInit();
	
	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetAllSpawnableObjectTemplate", &UKGSequenceManager::KAPI_GetAllSpawnableObjectTemplate);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_DoTraversalAllTracks", &UKGSequenceManager::KAPI_DoTraversalAllTracks);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetAllSubSequencePaths", &UKGSequenceManager::KAPI_GetAllSubSequencePaths);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_CreateEmptyActor", &UKGSequenceManager::KAPI_CreateEmptyActor);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_CreateLevelSequence", &UKGSequenceManager::KAPI_CreateLevelSequence);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_DestroyLevelSequence", &UKGSequenceManager::KAPI_DestroyLevelSequence);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetBindingObjectIDByBindingID", &UKGSequenceManager::KAPI_GetBindingObjectIDByBindingID);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetSpawnableObjectIDByBindingID", &UKGSequenceManager::KAPI_GetSpawnableObjectIDByBindingID);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_BindSequenceCallBack", &UKGSequenceManager::KAPI_BindSequenceCallBack);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_SetPlayRate", &UKGSequenceManager::KAPI_SetPlayRate);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetPlayRate", &UKGSequenceManager::KAPI_GetPlayRate);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_SetDisplayRate", &UKGSequenceManager::KAPI_SetDisplayRate);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetDisplayRate", &UKGSequenceManager::KAPI_GetDisplayRate);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_SetSequencePlayerParams", &UKGSequenceManager::KAPI_SetSequencePlayerParams);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetSequencePlayerDuration", &UKGSequenceManager::KAPI_GetSequencePlayerDuration);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetSequencePlayerPlayTime", &UKGSequenceManager::KAPI_GetSequencePlayerPlayTime);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetSequencePlayerStartTime", &UKGSequenceManager::KAPI_GetSequencePlayerStartTime)
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_SetBinding", &UKGSequenceManager::KAPI_SetBinding);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_RemoveBinding", &UKGSequenceManager::KAPI_RemoveBinding);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_SequencePlay", &UKGSequenceManager::KAPI_SequencePlay);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_BSequenceStop", &UKGSequenceManager::KAPI_SequenceStop);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_LevelSequenceJumpToStart", &UKGSequenceManager::KAPI_LevelSequenceJumpToStart);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_LevelSequenceJumpToFrame", &UKGSequenceManager::KAPI_LevelSequenceJumpToFrame);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_LevelSequenceJumpToMark", &UKGSequenceManager::KAPI_LevelSequenceJumpToMark);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_LevelSequencePlayToFrame", &UKGSequenceManager::KAPI_LevelSequencePlayToFrame);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_LevelSequencePlayToMark", &UKGSequenceManager::KAPI_LevelSequencePlayToMark);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_LevelSequencePlayToEnd", &UKGSequenceManager::KAPI_LevelSequencePlayToEnd);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_LevelSequenceSetFrameRange", &UKGSequenceManager::KAPI_LevelSequenceSetFrameRange);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetMovieSceneDisplayRate", &UKGSequenceManager::KAPI_GetMovieSceneDisplayRate);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_ChangeSequenceTransformOriginActor", &UKGSequenceManager::KAPI_ChangeSequenceTransformOriginActor);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetTransformTrackPostionByBindingGuid", &UKGSequenceManager::KAPI_GetTransformTrackPostionByBindingGuid);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_MuteTransformTrackByBindingGuid", &UKGSequenceManager::KAPI_MuteTransformTrackByBindingGuid);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_CopyPropertyFromTemplate", &UKGSequenceManager::KAPI_CopyPropertyFromTemplate);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_BindSequenceTriggerOnBeginOverlay", &UKGSequenceManager::KAPI_BindSequenceTriggerOnBeginOverlay);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_ClearSequenceTriggerOnBeginOverlay", &UKGSequenceManager::KAPI_ClearSequenceTriggerOnBeginOverlay);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetSectionStartTime", &UKGSequenceManager::KAPI_GetSectionStartTime);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetSectionEndTime", &UKGSequenceManager::KAPI_GetSectionEndTime);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_SetSectionDuration", &UKGSequenceManager::KAPI_SetSectionDuration);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_SetSectionDisplayName", &UKGSequenceManager::KAPI_SetSectionDisplayName);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetSequenceMarkLabelToFrameNumber", &UKGSequenceManager::KAPI_GetSequenceMarkLabelToFrameNumber);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetMultiAttachSectionIDs", &UKGSequenceManager::KAPI_GetMultiAttachSectionIDs);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetMultiAttachSectionInfo", &UKGSequenceManager::KAPI_GetMultiAttachSectionInfo);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_SetMultiAttachRealBindingID", &UKGSequenceManager::KAPI_SetMultiAttachRealBindingID);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetCustomTrackSections", &UKGSequenceManager::KAPI_GetCustomTrackSections);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetCustomDataBySectionID", &UKGSequenceManager::KAPI_GetCustomDataBySectionID);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_GetBindingTemplateGuidBySectionID", &UKGSequenceManager::KAPI_GetBindingTemplateGuidBySectionID);
#if WITH_EDITOR
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_CheckSequenceByAssetPath", &UKGSequenceManager::KAPI_CheckSequenceByAssetPath);
	REG_MANAGER_FUNC(UKGSequenceManager, "KAPI_OnCheckSequenceFinish", &UKGSequenceManager::KAPI_OnCheckSequenceFinish);
#endif
}

void UKGSequenceManager::NativeUninit()
{
	Super::NativeUninit();
	for (auto Item : CacheSequenceHelpers)
	{
		USequenceLoadTask* LoadTask = Item.Value.Get();
		if(LoadTask)
			LoadTask->HelperRemoveSequenceCallBack();
	}
	CacheSequenceHelpers.Empty();
}
#pragma endregion Important

#pragma region  For Lua

KGObjectID UKGSequenceManager::KAPI_CreateEmptyActor(int loadHandleID)
{
	UWorld* CurrentWorld = GetWorld();
	const FTransform Transform = FTransform(FQuat(0,0,0,1),FVector(0,0,-100000),FVector(1,1,1));
	AActor* EmptyActor = CurrentWorld->SpawnActor<AActor>(AActor::StaticClass(), Transform);
#if WITH_EDITOR
	EmptyActor->SetActorLabel(FString::Printf(TEXT("CutSceneEmptyActor_%d"),loadHandleID));
#endif
	return KGUtils::GetIDByObject(EmptyActor);
}

KGObjectID UKGSequenceManager::KAPI_CreateLevelSequence(KGObjectID LevelSequenceID, int loadHandleID, bool PauseAtEnd,  bool AutoPlay, bool bDisableCameraCuts)
{
	UObject* SequencObject = KGUtils::GetObjectByID(LevelSequenceID);
	ULevelSequence* LevelSequence = Cast<ULevelSequence>(SequencObject);
	if(CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_CreateLevelSequence] CacheSequenceHelpers Already Have Create The Same LevelSequenceActor LevelSequenceID: %lld loadHandleID: %d"), LevelSequenceID, loadHandleID);
		return KG_INVALID_ID;
	}
	if(!LevelSequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_CreateLevelSequence] LevelSequence Is InValid LevelSequenceID: %lld loadHandleID: %d"), LevelSequenceID, loadHandleID);
		return KG_INVALID_ID;
	}
	UWorld* CurrentWorld = GetWorld();
	FMovieSceneSequencePlaybackSettings Settings;
	Settings.bPauseAtEnd = PauseAtEnd;
	Settings.bAutoPlay = AutoPlay;
	Settings.bDisableCameraCuts = bDisableCameraCuts;
	ALevelSequenceActor* LevelSequenceActor = nullptr;
	ULevelSequencePlayer* Player = ULevelSequencePlayer::CreateLevelSequencePlayer(CurrentWorld, LevelSequence, Settings, LevelSequenceActor);
	
	if(!LevelSequenceActor)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_CreateLevelSequence] LevelSequenceActor Create InValid LevelSequenceName: %s loadHandleID: %d"), *LevelSequence->GetName(), loadHandleID);
		return KG_INVALID_ID;
	}
	ULevelSequencePlayer* SequencePlayer = LevelSequenceActor->GetSequencePlayer();
	if(!SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_CreateLevelSequence] SequencePlayer Is Invalid LevelSequenceName: %s loadHandleID: %d"), *LevelSequence->GetName(), loadHandleID);
		return KG_INVALID_ID;
	}
	KGObjectID SequenceActorID = KGUtils::GetIDByObject(LevelSequenceActor);
	USequenceLoadTask* NewSequenceHelper = NewObject<USequenceLoadTask>(this);
	NewSequenceHelper->Init(SequenceActorID, loadHandleID);
	CacheSequenceHelpers.Add(loadHandleID, NewSequenceHelper);
	
	UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_CreateLevelSequence] Create LevelSequenceActor Success loadHandleID: %d "), loadHandleID);
	return SequenceActorID;
}

void UKGSequenceManager::KAPI_DestroyLevelSequence(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_DestroyLevelSequence] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_DestroyLevelSequence] SequenceLoadTask In CacheSequenceHelpers Is Invalid  loadHandleID: %d"), loadHandleID);
		CacheSequenceHelpers.Remove(loadHandleID);
		return;
	}
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if(SequencePlayer)
	{
		SequencePlayer->Stop();
		Task->HelperRemoveSequenceCallBack();
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	if(SequenceActor)
		SequenceActor->K2_DestroyActor();
	CacheSequenceHelpers.Remove(loadHandleID);
	CustomActionStatus.Remove(loadHandleID);
	UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_DestroyLevelSequence] Destroy SequenceActor Success loadHandleID: %d "), loadHandleID);
}

void UKGSequenceManager::KAPI_BindSequenceCallBack(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_BindSequenceCallBack] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
		Task->HelperBindSequenceCallBack();
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_BindSequenceCallBack]  SequenceLoadTask In CacheSequenceHelpers Is Invalid loadHandleID: %d"), loadHandleID);
}


void UKGSequenceManager::KAPI_SetPlayRate(int loadHandleID, float Rate)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetPlayRate] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
		if(SequencePlayer)
			SequencePlayer->SetPlayRate(Rate);
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetPlayRate] SequenceLoadTask In CacheSequenceHelpers Is Invalid  loadHandleID: %d"), loadHandleID);
}


float UKGSequenceManager::KAPI_GetPlayRate(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetPlayRate] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), loadHandleID);
		return -1;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
		if(!SequencePlayer)
		{
			UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetPlayRate] SequencePlayer Is Invalid  loadHandleID: %d"), loadHandleID);
			return -1;
		}
		return SequencePlayer->GetPlayRate();
	}
	UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetPlayRate] SequenceLoadTask In CacheSequenceHelpers Is Invalid  loadHandleID: %d"), loadHandleID);
	return -1;
}

bool UKGSequenceManager::KAPI_SetDisplayRate(const int LoadHandleID, const int Frame)
{
	if (!CacheSequenceHelpers.Contains(LoadHandleID) || !CacheSequenceHelpers[LoadHandleID]->IsValidLowLevel())
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetDisplayRate] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), LoadHandleID);
		return false;
	}

	const TObjectPtr<USequenceLoadTask> Task = CacheSequenceHelpers[LoadHandleID];
	if (ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer())
	{
		SequencePlayer->SetFrameRate(FFrameRate(Frame, 1));
	}
	
	return false;
}

int32 UKGSequenceManager::KAPI_GetDisplayRate(const int LoadHandleID)
{
	if (!CacheSequenceHelpers.Contains(LoadHandleID) || !CacheSequenceHelpers[LoadHandleID]->IsValidLowLevel())
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetDisplayRate] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), LoadHandleID);
		return -1;
	}

	const TObjectPtr<USequenceLoadTask> Task = CacheSequenceHelpers[LoadHandleID];
	if (const ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer())
	{
		return SequencePlayer->GetFrameRate().Numerator;
	}

	return -1;
}

void UKGSequenceManager::KAPI_SetSequencePlayerParams(int loadHandleID, float StartTime)
{
	FMovieSceneSequencePlaybackParams Params;
	Params.Time = StartTime;
	Params.UpdateMethod = EUpdatePositionMethod::Jump;
	Params.PositionType = EMovieScenePositionType::Time;
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetSequencePlayerParams] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
		if(SequencePlayer)
			SequencePlayer->SetPlaybackPosition(Params);
		else
			UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetSequencePlayerParams] SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetSequencePlayerParams] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), loadHandleID);
}

float UKGSequenceManager::KAPI_GetSequencePlayerDuration(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequencePlayerDuration] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), loadHandleID);
		return -1;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
		if(SequencePlayer)
			return UTimeManagementBlueprintLibrary::Conv_QualifiedFrameTimeToSeconds(SequencePlayer->GetDuration());
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequencePlayerDuration] SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequencePlayerDuration] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
	return -1;
}

float UKGSequenceManager::KAPI_GetSequencePlayerPlayTime(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequencePlayerPlayTime] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), loadHandleID);
		return -1;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
		if(SequencePlayer)
			return UTimeManagementBlueprintLibrary::Conv_QualifiedFrameTimeToSeconds(SequencePlayer->GetCurrentTime());
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequencePlayerPlayTime] SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequencePlayerPlayTime] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
	return -1;
}


float UKGSequenceManager::KAPI_GetSequencePlayerStartTime(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequencePlayerStartTime] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), loadHandleID);
		return -1;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
		if(SequencePlayer)
			return UTimeManagementBlueprintLibrary::Conv_QualifiedFrameTimeToSeconds(SequencePlayer->GetStartTime());
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequencePlayerStartTime] SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequencePlayerStartTime] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
	return -1;
}

void UKGSequenceManager::KAPI_SetBinding(int loadHandleID, KGObjectID ActorID, FGuid BindingGuid, int32 SequenceID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetBinding] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
		if(SequenceActor && SequenceActor->GetSequencePlayer() && SequenceActor->GetSequencePlayer()->IsValid())
		{
			AActor* BindingActor = KGUtils::GetActorByID(ActorID);
			if(!BindingActor)
			{
				UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetBinding] BindingActor Is Invalid loadHandleID: %d ActorID: %lld"), loadHandleID, ActorID);
				return;
			}
			TArray<AActor*> Actors;
			Actors.Add(BindingActor);
			FMovieSceneObjectBindingID BindingID = GetBindingIDByGuid(loadHandleID, BindingGuid, SequenceID);
			UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_SetBinding] BindingActor Success loadHandleID: %d ActorID: %lld BindingID.Guid.A: %d"), loadHandleID, ActorID, BindingID.GetGuid().A);
			SequenceActor->SetBinding(BindingID, Actors, false);
			FMovieSceneBindingActorParams BindingParams(loadHandleID, BindingGuid, SequenceID);
			Task->BindingActorIDToGuids.Add(ActorID, BindingParams);
			if(!BindingActor->OnDestroyed.IsAlreadyBound(this,  &UKGSequenceManager::OnBoundActorDestroyed))
				BindingActor->OnDestroyed.AddDynamic(this, &UKGSequenceManager::OnBoundActorDestroyed);
		}
		else
			UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetBinding] SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetBinding] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
}


void UKGSequenceManager::KAPI_RemoveBinding(int loadHandleID, KGObjectID ActorID, FGuid BindingGuid, int32 SequenceID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_RemoveBinding] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
		if(SequenceActor && SequenceActor->GetSequencePlayer() && SequenceActor->GetSequencePlayer()->IsValid())
		{
			AActor* BindingActor = KGUtils::GetActorByID(ActorID);
			if(!BindingActor)
			{
				UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_RemoveBinding] BindingActor Is Invalid loadHandleID: %d ActorID: %lld"), loadHandleID, ActorID);
				return;
			}
			FMovieSceneObjectBindingID BindingID = GetBindingIDByGuid(loadHandleID, BindingGuid, SequenceID);
			SequenceActor->RemoveBinding(BindingID, BindingActor);
			SequenceActor->OnDestroyed.RemoveDynamic(this, &UKGSequenceManager::OnBoundActorDestroyed);
			Task->BindingActorIDToGuids.Remove(ActorID);
			UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_RemoveBinding] RemoveBinding Success: %d ActorID: %lld BindingID.Guid.A: %d"), loadHandleID, ActorID, BindingID.GetGuid().A);
		}
		else
			UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_RemoveBinding] SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_RemoveBinding] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
}

void UKGSequenceManager::KAPI_SequencePlay(int loadHandleID, bool bLoop)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SequencePlay] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
		if(SequencePlayer)
		{
			if(bLoop)
				SequencePlayer->PlayLooping(-1);
			else
				SequencePlayer->Play();
		}
		else
			UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SequencePlay] SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SequencePlay] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
}

void UKGSequenceManager::KAPI_SequenceStop(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SequenceStop] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
		if(SequencePlayer)
		{
			SequencePlayer->Stop();
		}
		else
			UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SequenceStop] SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SequenceStop] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
}

FMovieSceneObjectBindingID UKGSequenceManager::GetBindingIDByGuid(int loadHandleID, FGuid Guid, int32 SequenceID)
{
	FMovieSceneObjectBindingID OutBindingID;
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[GetBindingIDByGuid] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return OutBindingID;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(Task)
	{
		ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
		if(SequenceActor)
		{
			ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
			if(!SequencePlayer)
			{
				UE_LOG(LogSequenceManager, Warning, TEXT("[GetBindingIDByGuid] SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
				return OutBindingID;
			}
			if (UMovieScene* MovieScene = SequenceActor->GetSequence()->GetMovieScene())
			{
				const TMap<FName, FMovieSceneObjectBindingIDs>& BindingGroups = MovieScene->AllTaggedBindings();
				for (auto[Tag, Bindings] : BindingGroups)
				{
					for (FMovieSceneObjectBindingID Binding : Bindings.IDs)
					{
						if (Binding.IsValid())
						{
							if (SequencePlayer)
							{
								if(Binding.GetGuid() == Guid && SequenceID == Binding.GetRelativeSequenceID().GetInternalValue())
									return Binding;
							}
						}
					}
				}
			}
		}
	}
	else
		UE_LOG(LogSequenceManager, Warning, TEXT("[GetBindingIDByGuid] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
	return OutBindingID;
}


TArray<FMovieSceneBindingTagTemplateParams> UKGSequenceManager::KAPI_GetAllSpawnableObjectTemplate(int loadHandleID)
{
	TArray<FMovieSceneBindingTagTemplateParams> OutSpawnableObjectTemplates;
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllSpawnableObjectTemplate] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return OutSpawnableObjectTemplates;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllSpawnableObjectTemplate] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return OutSpawnableObjectTemplates;
	}
	
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllSpawnableObjectTemplate] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return OutSpawnableObjectTemplates;
	}
	
	ULevelSequence* Sequence = SequenceActor->GetSequence();
	if (!Sequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllSpawnableObjectTemplate] Sequence Resource Is Invalid loadHandleID: %d"), loadHandleID);
		return OutSpawnableObjectTemplates;
	}
	
	if (UMovieScene* MovieScene = Sequence->GetMovieScene())
	{
		const TMap<FName, FMovieSceneObjectBindingIDs>& BindingGroups = MovieScene->AllTaggedBindings();
		UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_GetAllSpawnableObjectTemplate] BindingGroups Num: %d loadHandleID: %d"), BindingGroups.Num(), loadHandleID);
		for (auto[Tag, Bindings] : BindingGroups)
		{
			UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_GetAllSpawnableObjectTemplate] Index BindingGroups Tag: %s Bindings.Num: %d"), *Tag.ToString(), Bindings.IDs.Num());
			for (FMovieSceneObjectBindingID Binding : Bindings.IDs)
			{
				if (Binding.IsValid())
				{
					// 判断Binding所在主轨道是否Mute了
					bool IsTrackMute = false;
					UMovieSceneSequence* TargetSequence = nullptr;
					if (Binding.GetRelativeSequenceID() == MovieSceneSequenceID::Root)
					{
						TargetSequence = Cast<UMovieSceneSequence>(SequencePlayer->GetSequence());
					}
					else
					{
						const FMovieSceneSequenceHierarchy* Hierarchy = SequencePlayer->GetEvaluationTemplate().GetHierarchy();
						const FMovieSceneSubSequenceData* SubData = Hierarchy ? Hierarchy->FindSubData(Binding.GetRelativeSequenceID()) : nullptr;
						if (SubData)
						{
							TargetSequence = SubData->GetSequence();
						}
					}
					if (!TargetSequence)
					{
						UE_LOG(LogTemp, Warning, TEXT("[KAPI_GetAllSpawnableObjectTemplate]  Cannot resolve sequence for binding in tag %s"), *Tag.ToString());
						continue;
					}
					UMovieScene* SubMovieScene = TargetSequence->GetMovieScene();
					if(!SubMovieScene)
					{
						UE_LOG(LogTemp, Warning, TEXT("[KAPI_GetAllSpawnableObjectTemplate] SubMovieScene Is InValid tag %s"), *Tag.ToString());
						continue;
					}
					const FMovieSceneBinding* MovieSceneBinding = SubMovieScene->FindBinding(Binding.GetGuid());
					if(!MovieSceneBinding)
					{
						UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_GetAllSpawnableObjectTemplate] Can not Find MovieSceneBinding By FMovieSceneObjectBindingID Tag: %s Guid.A: %d"), *Tag.ToString(), Binding.GetGuid().A);
						continue;
					}
					const TArray<UMovieSceneTrack*>& Tracks = MovieSceneBinding->GetTracks();
					if(Tracks.Num() <= 0)
					{
						UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_GetAllSpawnableObjectTemplate] Tracks Num is 0 Tag: %s Guid.A: %d"), *Tag.ToString(), Binding.GetGuid().A);
						continue;
					}
					for(int i=0;i<Tracks.Num();i++)
					{
						UMovieSceneTrack* CurTrack = Tracks[i];
						if(!(CurTrack && CurTrack->IsEvalDisabled()))
						{
							IsTrackMute = false;
							break;
						}
						IsTrackMute = true;
					}
					if(IsTrackMute)
					{
						UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_GetAllSpawnableObjectTemplate] Track Is Mute loadHandleID: %d Guid.A: %d"), loadHandleID, Binding.GetGuid().A);
						continue;
					}
					FMovieSceneBindingTagTemplateParams BindingTemplate(Tag, Binding.GetGuid(), Binding.GetRelativeSequenceID().GetInternalValue());
					UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_GetAllSpawnableObjectTemplate] Add OutSpawnableObjectTemplates: %d Tag: %s"), loadHandleID, *Tag.ToString());
					OutSpawnableObjectTemplates.Add(BindingTemplate);
				}
			}
		}
	}
	return OutSpawnableObjectTemplates;
}

TArray<FString> UKGSequenceManager::KAPI_GetAllSubSequencePaths(int loadHandleID)
{
	TArray<FString> SubSequencePaths;

	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllSubSequencePaths] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return SubSequencePaths;
	}
		
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllSubSequencePaths] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return SubSequencePaths;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllSubSequencePaths] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return SubSequencePaths;
	}
	
	ULevelSequence* Sequence = SequenceActor->GetSequence();
	if (!Sequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllSubSequencePaths] Sequence Resource Is Invalid loadHandleID: %d"), loadHandleID);
		return SubSequencePaths;
	}
	UMovieScene* MovieScene = Sequence->GetMovieScene();
	if (!MovieScene) return SubSequencePaths;

	for (UMovieSceneTrack* Track : MovieScene->GetTracks())
	{
		if (UMovieSceneSubTrack* SubTrack = Cast<UMovieSceneSubTrack>(Track))
		{
			for (UMovieSceneSection* Section : SubTrack->GetAllSections())
			{
				if (UMovieSceneSubSection* SubSection = Cast<UMovieSceneSubSection>(Section))
				{
					UMovieSceneSequence* SubSequence = SubSection->GetSequence();
					if (SubSequence)
					{
						FString Path = SubSequence->GetPathName(); // 或使用 SubSequence->GetOutermost()->GetName()
						UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_GetAllSubSequencePaths] Add SubSequencePaths: %d Tag: %s"), loadHandleID, *Path);
						SubSequencePaths.Add(Path);
					}
				}
			}
		}
	}

	return SubSequencePaths;
}

void UKGSequenceManager::KAPI_DoTraversalAllTracks(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_DoTravelAllTracks] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_DoTravelAllTracks] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_DoTravelAllTracks] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ULevelSequence* Sequence = SequenceActor->GetSequence();
	if (!Sequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_DoTravelAllTracks] Sequence Resource Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	UMovieScene* MovieScene = Sequence->GetMovieScene();
	if (!MovieScene) return;

	for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
	{
		for (UMovieSceneTrack* Track : Binding.GetTracks())
		{
			// 处理3DAttachTrack类型
			if (UMovieScene3DAttachTrack* AttachTrack = Cast<UMovieScene3DAttachTrack>(Track))
			{
				const TArray<UMovieSceneSection*>& AttachSections = AttachTrack->GetAllSections();
				for(int j=0;j<AttachSections.Num();j++)
				{
					if(UMovieScene3DAttachSection* AttachSection = Cast<UMovieScene3DAttachSection>(AttachSections[j]))
					{
						if(AttachSection->UseMultiAttach)
						{
							KGObjectID CurrentSectionID = KGUtils::GetIDByObject(AttachSection);
							Task->MultiAttachSectionIDs.Emplace(CurrentSectionID);
							TArray<FGuid> CurrentSectionGuids;
							for (int k=0;k<AttachSection->AttachBindingIDLst.Num();k++)
							{
								CurrentSectionGuids.Emplace(AttachSection->AttachBindingIDLst[k].GetGuid());
							}
							Task->AttachSectionInfo.Add(CurrentSectionID, CurrentSectionGuids);
						}
					}
				}
			}
		}
	}
}

KGObjectID UKGSequenceManager::KAPI_GetBindingObjectIDByBindingID(int loadHandleID,  FGuid BindingGuid)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetBindingObjectIDByBindingID] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return KG_INVALID_ID;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetBindingObjectIDByBindingID] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return KG_INVALID_ID;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetBindingObjectIDByBindingID] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return KG_INVALID_ID;
	}
	ULevelSequence* Sequence = SequenceActor->GetSequence();
	if (!Sequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetBindingObjectIDByBindingID] Sequence Resource Is Invalid loadHandleID: %d"), loadHandleID);
		return KG_INVALID_ID;
	}
	if (UMovieScene* MovieScene = Sequence->GetMovieScene())
	{
		const TMap<FName, FMovieSceneObjectBindingIDs>& BindingGroups = MovieScene->AllTaggedBindings();
		for (auto[Tag, Bindings] : BindingGroups)
		{
			for (FMovieSceneObjectBindingID Binding : Bindings.IDs)
			{
				if (Binding.IsValid())
				{
					if(Binding.GetGuid() != BindingGuid)
						continue;
					
					FMovieSceneSequenceID SequenceID = Binding.ResolveSequenceID(MovieSceneSequenceID::Root, *SequencePlayer);
					const TArrayView<TWeakObjectPtr<>>& BindingObjects = SequencePlayer->FindBoundObjects(BindingGuid, SequenceID);
					//lizhang@kuaishou.com 目前，只处理绑定单Object的情况
					if (BindingObjects.Num() > 0 && BindingObjects[0].IsValid())
					{
						UObject* BindingObject = BindingObjects[0].Get();
						return KGUtils::GetIDByObject(BindingObject);
					}else
					{
						return KG_INVALID_ID;
					}
				}
			}
		}
	}
	return KG_INVALID_ID;
}

KGObjectID UKGSequenceManager::KAPI_GetSpawnableObjectIDByBindingID(int loadHandleID,  FGuid BindingGuid)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSpawnableObjectIDByBindingID] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return KG_INVALID_ID;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSpawnableObjectIDByBindingID] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return KG_INVALID_ID;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSpawnableObjectIDByBindingID] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return KG_INVALID_ID;
	}
	ULevelSequence* Sequence = SequenceActor->GetSequence();
	if (!Sequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSpawnableObjectIDByBindingID] Sequence Resource Is Invalid loadHandleID: %d"), loadHandleID);
		return KG_INVALID_ID;
	}
	
	if (UMovieScene* MovieScene = Sequence->GetMovieScene())
	{
		const TMap<FName, FMovieSceneObjectBindingIDs>& BindingGroups = MovieScene->AllTaggedBindings();
		for (auto[Tag, Bindings] : BindingGroups)
		{
			for (FMovieSceneObjectBindingID Binding : Bindings.IDs)
			{
				if(Binding.GetGuid() != BindingGuid)
					continue;
				if (SequencePlayer)
				{
					FMovieSceneSequenceID SequenceID = Binding.ResolveSequenceID(MovieSceneSequenceID::Root, *SequencePlayer);
					if (UMovieSceneSequence* SubSequence = SequencePlayer->State.FindSequence(SequenceID))
					{
						if (const FMovieSceneBindingReferences* References = SubSequence->GetBindingReferences())
						{
							if (const UMovieSceneCustomBinding* CustomBinding = References->GetCustomBinding(BindingGuid, 0))
							{
								if (const UMovieSceneSpawnableActorBinding* ActorBinding = Cast<UMovieSceneSpawnableActorBinding>(CustomBinding))
								{
									UObject* Template = const_cast<UMovieSceneSpawnableActorBinding*>(ActorBinding)->GetObjectTemplate();
									return KGUtils::GetIDByObject(Template);
								}
							}
						}
						if (UMovieScene* SubMovieScene = SubSequence->GetMovieScene())
						{
							if (FMovieSceneSpawnable* Spawnable = SubMovieScene->FindSpawnable(Binding.GetGuid()))
							{
								UObject* Template = Spawnable->GetObjectTemplate();
								return KGUtils::GetIDByObject(Template);
							}
						}
					}
				}
			}
		}
	}
	return KG_INVALID_ID;
}

TArray<KGObjectID> UKGSequenceManager::KAPI_GetMultiAttachSectionIDs(int loadHandleID)
{
	TArray<KGObjectID> AttachInfo;
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetMultiAttachSectionIDs] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return AttachInfo;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetMultiAttachSectionIDs] Invalid SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return AttachInfo;
	}
	return Task->MultiAttachSectionIDs;
}

TArray<KGObjectID> UKGSequenceManager::KAPI_GetCustomTrackSections(int loadHandleID, FString ActionName)
{
	TArray<KGObjectID> CutstomTrackSections;
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetCustomTrackSections] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return CutstomTrackSections;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetCustomTrackSections] Invalid SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return CutstomTrackSections;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	if (!SequenceActor)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetCustomTrackSections] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return CutstomTrackSections;
	}
	
	ULevelSequence* Sequence = SequenceActor->GetSequence();
	if (!Sequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetCustomTrackSections] Sequence Resource Is Invalid loadHandleID: %d"), loadHandleID);
		return CutstomTrackSections;
	}
	UMovieScene* MovieScene = Sequence->GetMovieScene();
	if (!MovieScene) return CutstomTrackSections;

	for (UMovieSceneTrack* Track : MovieScene->GetTracks())
	{
		if (UMovieSceneCustomTrack* SubTrack = Cast<UMovieSceneCustomTrack>(Track))
			for (UMovieSceneSection* Section : SubTrack->GetAllSections())
			{
				if (UMovieSceneCustomSection* SubSection = Cast<UMovieSceneCustomSection>(Section))
				{
					if(SubSection->CustomData)
					{
						if(SubSection->CustomData->ActionName == ActionName)
						{
							KGObjectID SectionID = KGUtils::GetIDByObject(SubSection);
		{
							CutstomTrackSections.Emplace(SectionID);
						}
					}
				}
			}
		}
	}
	return CutstomTrackSections;
}

KGObjectID UKGSequenceManager::KAPI_GetCustomDataBySectionID(KGObjectID SectionID)
{
	if(UMovieSceneCustomSection* Section = Cast<UMovieSceneCustomSection>(KGUtils::GetObjectByID(SectionID)))
	{
		if(Section->CustomData)
		{
			return KGUtils::GetIDByObject(Section->CustomData);
		}
	}
	return KG_INVALID_ID;
}

FGuid UKGSequenceManager::KAPI_GetBindingTemplateGuidBySectionID(int loadHandleID, KGObjectID SectionID)
{
	FGuid TargetGuid = FGuid(0, 0, 0, 0);
    if(!CacheSequenceHelpers.Contains(loadHandleID))
    {
    	UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetBindingTemplateGuidBySectionID] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
    	return TargetGuid;
    }
    
    USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
    if(!Task)
    {
    	UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetBindingTemplateGuidBySectionID] Invalid SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
    	return TargetGuid;
    }
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if(UMovieSceneCustomSection* Section = Cast<UMovieSceneCustomSection>(KGUtils::GetObjectByID(SectionID)))
	{
		UMovieSceneTrack* TargetTrack = Section->GetTypedOuter<UMovieSceneTrack>();
		if(!TargetTrack)
			return TargetGuid;
		UMovieScene* MovieScene = TargetTrack->GetTypedOuter<UMovieScene>();
		if(!MovieScene)
			return TargetGuid;
		
		const TMap<FName, FMovieSceneObjectBindingIDs>& BindingGroups = MovieScene->AllTaggedBindings();
		for (auto[Tag, Bindings] : BindingGroups)
		{
			for (FMovieSceneObjectBindingID Binding : Bindings.IDs)
			{
				if (Binding.IsValid())
				{
					UMovieSceneSequence* TargetSequence = nullptr;
					if (Binding.GetRelativeSequenceID() == MovieSceneSequenceID::Root)
					{
						TargetSequence = Cast<UMovieSceneSequence>(SequencePlayer->GetSequence());
					}
					else
					{
						const FMovieSceneSequenceHierarchy* Hierarchy = SequencePlayer->GetEvaluationTemplate().GetHierarchy();
						const FMovieSceneSubSequenceData* SubData = Hierarchy ? Hierarchy->FindSubData(Binding.GetRelativeSequenceID()) : nullptr;
						if (SubData)
						{
							TargetSequence = SubData->GetSequence();
						}
					}
					if (!TargetSequence)
					{
						UE_LOG(LogTemp, Warning, TEXT("[KAPI_GetBindingTemplateGuidBySectionID]  Cannot resolve sequence for binding in tag %s"), *Tag.ToString());
						continue;
					}
					UMovieScene* SubMovieScene = TargetSequence->GetMovieScene();
					if(!SubMovieScene)
					{
						UE_LOG(LogTemp, Warning, TEXT("[KAPI_GetBindingTemplateGuidBySectionID] SubMovieScene Is InValid tag %s"), *Tag.ToString());
						continue;
					}
					const FMovieSceneBinding* MovieSceneBinding = SubMovieScene->FindBinding(Binding.GetGuid());
					if(!MovieSceneBinding)
					{
						UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_GetBindingTemplateGuidBySectionID] Can not Find MovieSceneBinding By FMovieSceneObjectBindingID Tag: %s Guid.A: %d"), *Tag.ToString(), Binding.GetGuid().A);
						continue;
					}
					const TArray<UMovieSceneTrack*>& Tracks = MovieSceneBinding->GetTracks();
					for(int i=0;i<Tracks.Num();i++)
					{
						UMovieSceneTrack* CurTrack = Tracks[i];
						if(CurTrack == TargetTrack)
							return Binding.GetGuid();
					}
				}
			}
		}
	}
	return TargetGuid;
}

TArray<FGuid> UKGSequenceManager::KAPI_GetMultiAttachSectionInfo(int loadHandleID, KGObjectID SectionID)
{
	TArray<FGuid> AttachInfo;
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllMultiAttachSection] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return AttachInfo;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetAllMultiAttachSection] Invalid SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return AttachInfo;
	}
	if(Task->AttachSectionInfo.Contains(SectionID))
		return Task->AttachSectionInfo[SectionID];
	return AttachInfo;
}

void UKGSequenceManager::KAPI_SetMultiAttachRealBindingID(int loadHandleID, int sequenceID, KGObjectID SectionID, FGuid TargetGuid)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetMultiAttachRealBindingID] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_SetMultiAttachRealBindingID] Invalid SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	if(UMovieScene3DAttachSection* AttachSection = Cast<UMovieScene3DAttachSection>(KGUtils::GetObjectByID(SectionID)))
	{
		FMovieSceneObjectBindingID TargetBindingID = GetBindingIDByGuid(loadHandleID, TargetGuid, sequenceID);
		AttachSection->SetAttachTargetID(TargetBindingID);
		UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_SetMultiAttachRealBindingID] Set New Attach GUID.A: %d"), TargetGuid.A);
	}
}

void UKGSequenceManager::KAPI_LevelSequenceJumpToFrame(int loadHandleID, int32 Frame)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceJumpToFrame] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceJumpToFrame] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceJumpToFrame] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	SequencePlayer->SetPlaybackPosition(FMovieSceneSequencePlaybackParams(FFrameTime(Frame), EUpdatePositionMethod::Jump));
}

void UKGSequenceManager::KAPI_LevelSequenceJumpToStart(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceJumpToStart] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceJumpToStart] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceJumpToStart] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	const FFrameTime StatTime = SequencePlayer->GetStartTime().Time;
	SequencePlayer->SetPlaybackPosition(FMovieSceneSequencePlaybackParams(StatTime, EUpdatePositionMethod::Jump));
}

void UKGSequenceManager::KAPI_LevelSequenceJumpToMark(int loadHandleID, const FString& InMarkedFrame)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceJumpToMark] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceJumpToMark] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceJumpToMark] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	SequencePlayer->SetPlaybackPosition(FMovieSceneSequencePlaybackParams(InMarkedFrame, EUpdatePositionMethod::Jump));
	SequencePlayer->Play();
}

void UKGSequenceManager::KAPI_LevelSequencePlayToFrame(int loadHandleID, int32 Frame)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToFrame] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToFrame] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToFrame] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	SequencePlayer->PlayTo(FMovieSceneSequencePlaybackParams(FFrameTime(Frame), EUpdatePositionMethod::Play), FMovieSceneSequencePlayToParams());
}

void UKGSequenceManager::KAPI_LevelSequencePlayToMark(int loadHandleID, const FString& InMarkedFrame)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToMark] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToMark] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToMark] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	SequencePlayer->PlayTo(FMovieSceneSequencePlaybackParams(InMarkedFrame, EUpdatePositionMethod::Play), FMovieSceneSequencePlayToParams());
}

void UKGSequenceManager::KAPI_LevelSequencePlayToEnd(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToEnd] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToEnd] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequenceActor || !SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToEnd] SequenceActor Or SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	const FFrameTime EndTime = SequencePlayer->GetEndTime().Time;
	SequencePlayer->PlayTo(FMovieSceneSequencePlaybackParams(EndTime, EUpdatePositionMethod::Play), FMovieSceneSequencePlayToParams());
}

void UKGSequenceManager::KAPI_LevelSequenceSetFrameRange(int loadHandleID, int32 NewStartTime, int32 Duration)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceSetFrameRange] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequenceSetFrameRange] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ULevelSequencePlayer* SequencePlayer = Task->GetSequencePlayer();
	if (!SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_LevelSequencePlayToEnd]   SequencePlayer Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	SequencePlayer->SetFrameRange(NewStartTime, Duration);
}

int32 UKGSequenceManager::KAPI_GetMovieSceneDisplayRate(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetMovieSceneDisplayRate] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return -1;
	}
	
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetMovieSceneDisplayRate] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return -1;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	if (!SequenceActor)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetMovieSceneDisplayRate]   SequenceActor Is Invalid loadHandleID: %d"), loadHandleID);
		return -1;
	}
	ULevelSequence* Sequence = SequenceActor->GetSequence();
	if (!Sequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetMovieSceneDisplayRate]   Sequence Resource Is Invalid loadHandleID: %d"), loadHandleID);
		return -1;
	}
	if (UMovieScene* MovieScene = Sequence->GetMovieScene())
	{
		return MovieScene->GetDisplayRate().Numerator;
	}
	UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetMovieSceneDisplayRate]   MovieScene Resource Is Invalid loadHandleID: %d"), loadHandleID);
	return -1;
}

void UKGSequenceManager::KAPI_ChangeSequenceTransformOriginActor(int loadHandleID, KGObjectID ActorID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_ChangeSequenceTransformOriginActor] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_ChangeSequenceTransformOriginActor] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	if (!SequenceActor)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_ChangeSequenceTransformOriginActor]   SequenceActor Is Invalid loadHandleID: %d"), loadHandleID);
		return;
	}
	AActor* Target = KGUtils::GetActorByID(ActorID);
	if(!Target)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetMovieSceneDisplayRate]  Target Acotr Is Invalid loadHandleID: %d ActorID: %lld"), loadHandleID, ActorID);
		return;
	}
	SequenceActor->bOverrideInstanceData = true;
	if(UDefaultLevelSequenceInstanceData* InstanceData = Cast<UDefaultLevelSequenceInstanceData>(SequenceActor->DefaultInstanceData))
	{
		InstanceData->TransformOriginActor = Target;
	}
}

FVector UKGSequenceManager::KAPI_GetTransformTrackPostionByBindingGuid(int loadHandleID, FGuid BindingGuid)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetTransformTrackPostionByBindingGuid] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return InvalidPos;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetTransformTrackPostionByBindingGuid] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return InvalidPos;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	if (!SequenceActor)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetTransformTrackPostionByBindingGuid]   SequenceActor Is Invalid loadHandleID: %d"), loadHandleID);
		return InvalidPos;
	}
	ULevelSequence* LevelSequence = SequenceActor->GetSequence();
	if(!LevelSequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetTransformTrackPostionByBindingGuid]   LevelSequence Is Invalid loadHandleID: %d"), loadHandleID);
		return InvalidPos;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if(!MovieScene)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetTransformTrackPostionByBindingGuid]   MovieScene Is Invalid loadHandleID: %d"), loadHandleID);
		return InvalidPos;
	}
	const FMovieSceneBinding* Binding = MovieScene->FindBinding(BindingGuid);
	if(!Binding)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetTransformTrackPostionByBindingGuid]   Binding Is Invalid loadHandleID: %d"), loadHandleID);
		return InvalidPos;
	}
	for(int i=0;i<Binding->GetTracks().Num();i++)
	{
		UMovieSceneTrack* Track = Binding->GetTracks()[i];
		if (Track && Track->IsA<UMovieScene3DTransformTrack>())
		{
			UMovieScene3DTransformTrack* TransformTrack = Cast<UMovieScene3DTransformTrack>(Track);
			if(TransformTrack)
			{
				const TArray<UMovieSceneSection*>& Sections = TransformTrack->GetAllSections();
				if (Sections.Num() > 0)
				{
					UMovieScene3DTransformSection* TransformSection = Cast<UMovieScene3DTransformSection>(Sections[0]);
					if (TransformSection)
					{
						const FMovieSceneDoubleChannel* Translation = TransformSection->GetTranslation();
						if(!Translation)
							return InvalidPos;
						double PositionX = 0;
						double PositionY = 0;
						double PositionZ = 0;
						for (int32 j = 0; j < 3; j++)
						{
							// 优先获取第零帧数据
							if (Translation[j].Evaluate(0, j == 0? PositionX : ( j==1 ? PositionY : PositionZ)))
							{
								continue;
							}
							// 没有第零帧则用默认值
							TOptional<double> DefaultValue = Translation[j].GetDefault();
							if (!DefaultValue.IsSet())
							{
								return InvalidPos;
							}
							j == 0? PositionX = Translation[j].GetDefault().GetValue():(j == 1? PositionY = Translation[j].GetDefault().GetValue():PositionZ = Translation[j].GetDefault().GetValue());
						}
						return FVector(PositionX, PositionY, PositionZ);
					}
				}
			}
		}
	}
	return InvalidPos;
}

void UKGSequenceManager::KAPI_MuteTransformTrackByBindingGuid(KGObjectID SectionID, bool isMute)
{
	UObject* SectionObject = KGUtils::GetObjectByID(SectionID);
	if(UMovieSceneCustomSection* CustomSection = Cast<UMovieSceneCustomSection>(SectionObject))
	{
		if (UMovieSceneTrack* ParentTrack = CustomSection->GetTypedOuter<UMovieSceneTrack>())
		{
			if (UMovieScene* MovieScene = ParentTrack->GetTypedOuter<UMovieScene>())
			{
				// 遍历所有 Binding，找到 ParentTrack 所属 Binding
				for (const FMovieSceneBinding& Binding : MovieScene->GetBindings())
				{
					if (Binding.GetTracks().Contains(ParentTrack))
					{
						// 找同一个 Binding 下的 Transform 轨道
						for (UMovieSceneTrack* Track : Binding.GetTracks())
						{
							if (UMovieScene3DTransformTrack* TransformTrack = Cast<UMovieScene3DTransformTrack>(Track))
							{
								const TArray<UMovieSceneSection*>& Sections = TransformTrack->GetAllSections();
								for(int j=0;j<Sections.Num();j++)
								{
									UMovieScene3DTransformSection* TransformSection = Cast<UMovieScene3DTransformSection>(Sections[j]);
									TransformSection->SetIsActive(isMute);
									UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_MuteTransformTrackByBindingGuid] Transform Section is Mute: %d"), j);
								}
							}
						}
					}
				}
			}
		}
	}
}


TMap<FString, int32> UKGSequenceManager::KAPI_GetSequenceMarkLabelToFrameNumber(int loadHandleID)
{
	TMap<FString, int32> MarkToFrame;
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequenceMarkLabelToFrameNumber] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return MarkToFrame;
	}
	USequenceLoadTask* Task = CacheSequenceHelpers[loadHandleID].Get();
	if(!Task)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequenceMarkLabelToFrameNumber] SequenceLoadTask Is Invalid loadHandleID: %d"), loadHandleID);
		return MarkToFrame;
	}
	ALevelSequenceActor* SequenceActor = Task->GetSequenceActor();
	if (!SequenceActor)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequenceMarkLabelToFrameNumber]   SequenceActor Is Invalid loadHandleID: %d"), loadHandleID);
		return MarkToFrame;
	}
	ULevelSequence* LevelSequence = SequenceActor->GetSequence();
	if(!LevelSequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequenceMarkLabelToFrameNumber]   LevelSequence Is Invalid loadHandleID: %d"), loadHandleID);
		return MarkToFrame;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if(!MovieScene)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_GetSequenceMarkLabelToFrameNumber]   MovieScene Is Invalid loadHandleID: %d"), loadHandleID);
		return MarkToFrame;
	}
	const auto& Marks = MovieScene->GetMarkedFrames();
	for (const auto& Mark : Marks)
	{
		FFrameRate TickRate = MovieScene->GetTickResolution();
		FFrameTime FrameInTargetRate = ConvertFrameTime(Mark.FrameNumber, TickRate, MovieScene->GetDisplayRate());
		MarkToFrame.Add(Mark.Label, FrameInTargetRate.GetFrame().Value);
	}
	return MarkToFrame;
}

void UKGSequenceManager::KAPI_CopyPropertyFromTemplate(const KGObjectID NewActorID, const KGObjectID TemplateActorID, EActorCopyPropertyFlags Flags)
{
	AActor* NewActor = KGUtils::GetActorByID(NewActorID);
	const AActor* TemplateActor = KGUtils::GetActorByID(TemplateActorID);
	if (!NewActor || !TemplateActor)
	{
		UE_LOG(LogSequenceManager, Error, TEXT("[CopyPropertyFromTemplate] Actor Is Invalid NewActorID: %lld or TemplateActorID: %lld"), NewActorID, TemplateActorID);
		return;
	}

	if (static_cast<uint32>(Flags) & static_cast<uint32>(EActorCopyPropertyFlags::Platform))
	{
		NewActor->Platforms = TemplateActor->Platforms;
#if WITH_EDITOR
		NewActor->PlatformsDisabledActor = TemplateActor->PlatformsDisabledActor;
#endif
		if(FActorPlatformSetUtilities::IsValidPlatformProperty(&NewActor->Platforms))
		{
			FActorPlatformSetUtilities::OnActorRegistered(NewActor);
		}
	}
}


void UKGSequenceManager::KAPI_BindSequenceTriggerOnBeginOverlay(int loadHandleID, KGObjectID ActorID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_BindSequenceTriggerOnBeginOverlay] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	TObjectPtr<USequenceLoadTask> TargetLoadTask = CacheSequenceHelpers[loadHandleID];
	if(!TargetLoadTask)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_BindSequenceTriggerOnBeginOverlay] Invalid TargetLoadTask loadHandleID: %d"), loadHandleID);
		return;
	}
	
	if(TargetLoadTask->SequenceTriggerCache.Contains(ActorID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_BindSequenceTriggerOnBeginOverlay] Already Bind Trigger OnActorBeginOverlap loadHandleID: %d, TriggerActorID: %lld"), loadHandleID, ActorID);
		return;
	}
	
	TargetLoadTask->SequenceTriggerCache.Add(ActorID);
	UObject* TargetObject = KGUtils::GetObjectByID(ActorID);
	if(ATriggerBox* TriggerBox = Cast<ATriggerBox>(TargetObject))
	{
		TriggerBox->OnActorBeginOverlap.AddDynamic(this, &UKGSequenceManager::OnSequenceTriggerBeginOverlap);
		UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_BindSequenceTriggerOnBeginOverlay] AddDynamic Trigger success loadHandleID: %d, TriggerActorID: %lld"), loadHandleID, ActorID);
	}
}

void UKGSequenceManager::KAPI_ClearSequenceTriggerOnBeginOverlay(int loadHandleID)
{
	if(!CacheSequenceHelpers.Contains(loadHandleID))
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_ClearSequenceTriggerOnBeginOverlay] Can Not Find SequenceLoadTask In CacheSequenceHelpers loadHandleID: %d"), loadHandleID);
		return;
	}
	TObjectPtr<USequenceLoadTask> TargetLoadTask = CacheSequenceHelpers[loadHandleID];
	if(!TargetLoadTask)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_ClearSequenceTriggerOnBeginOverlay] Invalid TargetLoadTask loadHandleID: %d"), loadHandleID);
		return;
	}
	
	for(int i=TargetLoadTask->SequenceTriggerCache.Num() - 1;i>=0;i--)
	{
		KGActorID TargetID = TargetLoadTask->SequenceTriggerCache[i];
		UObject* TargetObject = KGUtils::GetObjectByID(TargetID);
		if(ATriggerBox* TriggerBox = Cast<ATriggerBox>(TargetObject))
		{
			TriggerBox->OnActorBeginOverlap.Clear();
		}
		TargetLoadTask->SequenceTriggerCache.Remove(TargetID);
	}
}

float UKGSequenceManager::KAPI_GetSectionStartTime(KGObjectID SectionID)
{
	UObject* SectionObject = KGUtils::GetObjectByID(SectionID);
	if(UMovieSceneSection* CustomSection = Cast<UMovieSceneSection>(SectionObject))
	{
		UMovieScene* MovieScene = CustomSection->GetTypedOuter<UMovieScene>();
		if(MovieScene)
		{
			FFrameRate FrameRate = MovieScene->GetTickResolution();
			return (float)FrameRate.AsSeconds(CustomSection->GetRange().GetLowerBoundValue());
		}
	}
	return -1;
}
	
float UKGSequenceManager::KAPI_GetSectionEndTime(KGObjectID SectionID)
{
	UObject* SectionObject = KGUtils::GetObjectByID(SectionID);
	if(UMovieSceneSection* CustomSection = Cast<UMovieSceneSection>(SectionObject))
	{
		UMovieScene* MovieScene = CustomSection->GetTypedOuter<UMovieScene>();
		if(MovieScene)
		{
			FFrameRate FrameRate = MovieScene->GetTickResolution();
			return (float)FrameRate.AsSeconds(CustomSection->GetRange().GetUpperBoundValue());
		}
	}
	return -1;
}
	
void UKGSequenceManager::KAPI_SetSectionDuration(KGObjectID SectionID, float Duration)
{
	UObject* SectionObject = KGUtils::GetObjectByID(SectionID);
	if(UMovieSceneCustomSection* CustomSection = Cast<UMovieSceneCustomSection>(SectionObject))
	{
		CustomSection->SetDuration(Duration);
	}
}

void UKGSequenceManager::KAPI_SetSectionDisplayName(KGObjectID SectionID, FString DisplayName)
{
	UObject* SectionObject = KGUtils::GetObjectByID(SectionID);
	if(UMovieSceneCustomData* CustomSectionData = Cast<UMovieSceneCustomData>(SectionObject))
	{
		CustomSectionData->SetDisplayName(DisplayName);
	}
}

#pragma endregion For Lua

#pragma region  For C++
int UKGSequenceManager::GetSequenceLoadHandleIDByMoviePlayer(IMovieScenePlayer& Player)
{
	if (ALevelSequenceActor* Actor = Cast<ALevelSequenceActor>(Player.GetPlaybackContext()))
	{
		for (auto Item : CacheSequenceHelpers)
		{
			if(Item.Value && Item.Value->GetSequenceActor() == Actor)
				return Item.Key;
		}
	}
	return -1;
}


void UKGSequenceManager::OnCustomTrackSectionSetUp(const UMovieSceneCustomSection* MovieSceneCustomSection, int LoadHandleID)
{
	UMovieSceneCustomSection* CustomSection = const_cast<UMovieSceneCustomSection*>(MovieSceneCustomSection);
	if(UObject* CustomSectionObject = Cast<UObject>(CustomSection))
	{
		KGObjectID CustomSectionID = KGUtils::GetIDByObject(CustomSectionObject);
		KGObjectID CustomDataID = KGUtils::GetIDByObject(CustomSection->CustomData);
		if(!CacheSequenceHelpers.Contains(LoadHandleID))
		{
			UE_LOG(LogSequenceManager, Warning, TEXT("[OnCustomTrackSectionSetUp] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), LoadHandleID);
			return;
		}
		USequenceLoadTask* Task = CacheSequenceHelpers[LoadHandleID].Get();
		if(!Task)
		{
			UE_LOG(LogSequenceManager, Warning, TEXT("[OnCustomTrackSectionSetUp] SequenceLoadTask In CacheSequenceHelpers Is Invalid  loadHandleID: %d"), LoadHandleID);
			return;
		}
		Task->CustomSectionObjectIDs.Emplace(CustomSectionID);
		CustomActionStatus.FindOrAdd(LoadHandleID).Add(CustomSectionID, FCustomActionRuntimeStatus());
    	CallLuaFunction("OnCustomTrackSectionSetUp", CustomSectionID, CustomDataID, LoadHandleID);
	}
}

void UKGSequenceManager::OnCustomTrackSectionExecute(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, float CurrentTime, int LoadHandleID)
{
	TRACE_CPUPROFILER_EVENT_SCOPE(UKGSequenceManager::OnCustomTrackSectionExecute);
	UMovieSceneCustomSection* CustomSection = const_cast<UMovieSceneCustomSection*>(MovieSceneCustomSection);
	if(UObject* CustomSectionObject = Cast<UObject>(CustomSection))
	{
		KGObjectID CustomSectionID = KGUtils::GetIDByObject(CustomSectionObject);
		KGObjectID CustomDataID = KGUtils::GetIDByObject(CustomSection->CustomData);
		KGObjectID ActorID = KGUtils::GetIDByObject(InActor);
		FCustomActionRuntimeStatus& Status = CustomActionStatus.FindOrAdd(LoadHandleID).FindOrAdd(CustomSectionID);
		if (Status.bTickStopped)
			return;
		const bool& bStopTick = CallLuaFunction<bool>("OnCustomTrackSectionExecute", CustomSectionID, CustomDataID, ActorID, Status.bHasExecuted, CurrentTime, LoadHandleID);
		Status.bTickStopped = bStopTick;
		Status.bHasExecuted = true;
	}
}
	
void UKGSequenceManager::OnCustomTrackSectionTearDown(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, int LoadHandleID)
{
	UMovieSceneCustomSection* CustomSection = const_cast<UMovieSceneCustomSection*>(MovieSceneCustomSection);
	if(UObject* CustomSectionObject = Cast<UObject>(CustomSection))
	{
		KGObjectID CustomSectionID = KGUtils::GetIDByObject(CustomSectionObject);
		KGObjectID CustomDataID = KGUtils::GetIDByObject(CustomSection->CustomData);
		KGObjectID ActorID = KGUtils::GetIDByObject(InActor);
		if(!CacheSequenceHelpers.Contains(LoadHandleID))
		{
			UE_LOG(LogSequenceManager, Warning, TEXT("[OnCustomTrackSectionSetUp] Can Not Find SequenceLoadTask In CacheSequenceHelpers  loadHandleID: %d"), LoadHandleID);
			return;
		}
		USequenceLoadTask* Task = CacheSequenceHelpers[LoadHandleID].Get();
		if(!Task)
		{
			UE_LOG(LogSequenceManager, Warning, TEXT("[OnCustomTrackSectionSetUp] SequenceLoadTask In CacheSequenceHelpers Is Invalid  loadHandleID: %d"), LoadHandleID);
			return;
		}
		CallLuaFunction("OnCustomTrackSectionTearDown", CustomSectionID, CustomDataID, ActorID, LoadHandleID);
		Task->CustomSectionObjectIDs.Remove(CustomSectionID);
		CustomActionStatus.FindOrAdd(LoadHandleID).Remove(CustomSectionID);
	}
}

#if WITH_EDITOR
void UKGSequenceManager::OnCustomTrackSectionSetUpInEditor(const UMovieSceneCustomSection* MovieSceneCustomSection, int LoadHandleID)
{
	UMovieSceneCustomSection* CustomSection = const_cast<UMovieSceneCustomSection*>(MovieSceneCustomSection);
	if(UObject* CustomSectionObject = Cast<UObject>(CustomSection))
	{
		KGObjectID CustomSectionID = KGUtils::GetIDByObject(CustomSectionObject);
		KGObjectID CustomDataID = KGUtils::GetIDByObject(CustomSection->CustomData);
		CustomActionStatus.FindOrAdd(LoadHandleID).Add(CustomSectionID, FCustomActionRuntimeStatus());
		CallLuaFunction("OnCustomTrackSectionSetUpInEditor", CustomSectionID, CustomDataID, LoadHandleID);
	}
}

void UKGSequenceManager::OnCustomTrackSectionExecuteInEditor(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, float CurrentTime, int LoadHandleID)
{
	UMovieSceneCustomSection* CustomSection = const_cast<UMovieSceneCustomSection*>(MovieSceneCustomSection);
	if(UObject* CustomSectionObject = Cast<UObject>(CustomSection))
	{
		KGObjectID CustomSectionID = KGUtils::GetIDByObject(CustomSectionObject);
		KGObjectID CustomDataID = KGUtils::GetIDByObject(CustomSection->CustomData);
		KGObjectID ActorID = KGUtils::GetIDByObject(InActor);
		FCustomActionRuntimeStatus& Status = CustomActionStatus.FindOrAdd(LoadHandleID).FindOrAdd(CustomSectionID);
		if (Status.bTickStopped)
			return;
		const bool& bStopTick = CallLuaFunction<bool>("OnCustomTrackSectionExecuteInEditor", CustomSectionID, CustomDataID, ActorID, Status.bHasExecuted, CurrentTime, LoadHandleID);
		Status.bTickStopped = bStopTick;
		Status.bHasExecuted = true;
	}
}
	
void UKGSequenceManager::OnCustomTrackSectionTearDownInEditor(const UMovieSceneCustomSection* MovieSceneCustomSection, AActor* InActor, int LoadHandleID)
{
	UMovieSceneCustomSection* CustomSection = const_cast<UMovieSceneCustomSection*>(MovieSceneCustomSection);
	if(UObject* CustomSectionObject = Cast<UObject>(CustomSection))
	{
		KGObjectID CustomSectionID = KGUtils::GetIDByObject(CustomSectionObject);
		KGObjectID CustomDataID = KGUtils::GetIDByObject(CustomSection->CustomData);
		KGObjectID ActorID = KGUtils::GetIDByObject(InActor);
		CallLuaFunction("OnCustomTrackSectionTearDownInEditor", CustomSectionID, CustomDataID, ActorID, LoadHandleID);
		CustomActionStatus.FindOrAdd(LoadHandleID).Remove(CustomSectionID);
	}
}

void UKGSequenceManager::OnCustomTrackSectionPropertyChange(const UMovieSceneCustomSection* MovieSceneCustomSection, bool isSectionData, FString PropertyName, int LoadHandleID)
{
	UMovieSceneCustomSection* CustomSection = const_cast<UMovieSceneCustomSection*>(MovieSceneCustomSection);
	if(UObject* CustomSectionObject = Cast<UObject>(CustomSection))
	{
		KGObjectID CustomSectionID = KGUtils::GetIDByObject(CustomSectionObject);
		KGObjectID CustomDataID = KGUtils::GetIDByObject(CustomSection->CustomData);
		CallLuaFunction("OnCustomTrackSectionPropertyChange", CustomSectionID, CustomDataID, isSectionData, PropertyName, LoadHandleID);
	}
}

void UKGSequenceManager::CheckSequenceData()
{
	FacadeIDs.Empty();
	CallLuaFunction("CheckSequenceData");
}

void UKGSequenceManager::KAPI_CheckSequenceByAssetPath(const FString& AssetPath)
{
	UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_CheckSequenceByAssetPath] AssetPath: %s"), *AssetPath);
	ULevelSequence* LevelSequence = LoadObject<ULevelSequence>(
		nullptr,
		*AssetPath
	);
	if (!LevelSequence)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_CheckSequenceByAssetPath] Load LevelSequence Failed AssetPath: %s"), *AssetPath);
		return;
	}
	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (!MovieScene)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[KAPI_CheckSequenceByAssetPath] LevelSequence MovieScene Is Invalid AssetPath: %s"), *AssetPath);
		return;
	}
	for (const auto& Tuple : MovieScene->AllTaggedBindings())
	{
		FString NameStr = Tuple.Key.ToString();

		// 1. 检查是否是纯数字
		if (NameStr.IsNumeric())
		{
			FacadeIDs.Add(FCString::Atoi(*NameStr));
		}

		// 2. 检查是否以"model_"开头
		if (NameStr.StartsWith(TEXT("model_")))
		{
			FString AfterModel = NameStr.RightChop(6);

			if (AfterModel.IsNumeric())
			{
				FacadeIDs.Add(FCString::Atoi(*AfterModel));
			}
		}
	}
}

void UKGSequenceManager::KAPI_OnCheckSequenceFinish()
{
	TArray<FString> StringArray;

	for (const int32& ID : FacadeIDs)
	{
		StringArray.Add(FString::FromInt(ID));
	}

	UE_LOG(LogSequenceManager, Log, TEXT("[KAPI_CheckSequenceByAssetPath] LevelSequence AllFacadeIDs: %s"), *FString::Join(StringArray, TEXT(",")));
}
#endif

#pragma endregion  For C++

#pragma region Internal
void UKGSequenceManager::OnSequenceTriggerBeginOverlap(AActor* OverlappedActor, AActor* OtherActor)
{
	KGActorID OverlappedActorID = KGUtils::GetIDByObject(OverlappedActor);
	KGActorID OtherActorID = KGUtils::GetIDByObject(OtherActor);
	for (auto CacheData : CacheSequenceHelpers)
	{
		if(CacheData.Value && CacheData.Value->SequenceTriggerCache.Contains(OverlappedActorID))
		{
			CallLuaFunction("OnSequenceTriggerBeginOverlap", CacheData.Key, OverlappedActorID, OtherActorID);
			break;
		}
	}
}

void UKGSequenceManager::OnBoundActorDestroyed(AActor* DestroyedActor)
{
	KGActorID ActorID = KGUtils::GetIDByObject(DestroyedActor);
	for (auto CacheData : CacheSequenceHelpers)
	{
		TObjectPtr<USequenceLoadTask> LoadTask = CacheData.Value;
		if(LoadTask)
		{
			ALevelSequenceActor* SequenceActor = LoadTask->GetSequenceActor();
			if(SequenceActor && 
				SequenceActor->GetSequencePlayer() && 
				SequenceActor->GetSequencePlayer()->IsValid() && 
				LoadTask->BindingActorIDToGuids.Contains(ActorID))
			{
				TArray<AActor*> Actors;
				FMovieSceneBindingActorParams BindingActorParams = LoadTask->BindingActorIDToGuids[ActorID];
				FMovieSceneObjectBindingID BindingID = GetBindingIDByGuid(BindingActorParams.loadHandleID, BindingActorParams.BindingGuid, BindingActorParams.SequenceID);
				SequenceActor->SetBinding(BindingID, Actors, false);
				break;
			}
		}
	}
	if(DestroyedActor)
		DestroyedActor->OnDestroyed.RemoveDynamic(this, &UKGSequenceManager::OnBoundActorDestroyed);
}
#pragma endregion Internal