#include "Sequence/KGSequenceManager.h"
#include "EngineUtils.h"
#include "LevelSequencePlayer.h"
#include "MovieScene.h"
#include "Tracks/MovieSceneSubTrack.h"
#include "Sections/MovieSceneSubSection.h"
#include "MovieSceneSequencePlayer.h"
#include "Engine/Engine.h"
#include "3C/Util/KGUtils.h"
#include "LevelSequenceActor.h"
#include "Sequence/SequenceLoadTask.h"

#include "Camera/CameraComponent.h"


void USequenceLoadTask::OnSequencePlay()
{
	UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] OnSequencePlay loadHandleID: %d GetWorld: %s"), loadHandleID, GetWorld()? *GetWorld()->GetName(): TEXT("Null"));
	if (UKGSequenceManager* KGSequenceManager = UKGSequenceManager::GetInstance(GetWorld()))
	{
		UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] Call Lua OnSequencePlay"));
		KGSequenceManager->CallLuaFunction("OnSequencePlay", loadHandleID);
	}
};

void USequenceLoadTask::OnSequenceFinished()
{
	UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] OnSequenceFinished loadHandleID: %d GetWorld: %s"), loadHandleID, GetWorld()? *GetWorld()->GetName(): TEXT("Null"));
	if (UKGSequenceManager* KGSequenceManager = UKGSequenceManager::GetInstance(GetWorld()))
	{
		UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] Call Lua OnSequenceFinished"));
		KGSequenceManager->CallLuaFunction("OnSequenceFinished", loadHandleID);
	}
};

void USequenceLoadTask:: OnSequencePause()
{
	UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] OnSequencePause loadHandleID: %d GetWorld: %s"), loadHandleID, GetWorld()? *GetWorld()->GetName(): TEXT("Null"));
	if (UKGSequenceManager* KGSequenceManager = UKGSequenceManager::GetInstance(GetWorld()))
	{
		UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] Call Lua OnSequencePause"));
		KGSequenceManager->CallLuaFunction("OnSequencePause", loadHandleID);
	}
};

void USequenceLoadTask::OnSequenceSubSequencePlay(int sequenceId)
{
	UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] OnSequenceSubSequencePlay loadHandleID: %d GetWorld: %s"), loadHandleID, GetWorld()? *GetWorld()->GetName():TEXT("Null"));
	if (UKGSequenceManager* KGSequenceManager = UKGSequenceManager::GetInstance(GetWorld()))
	{
		UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] Call Lua OnSequenceSubSequencePlay"));
		KGSequenceManager->CallLuaFunction("OnSequenceSubSequencePlay", loadHandleID, sequenceId);
	}
};
void USequenceLoadTask::OnSequenceCameraCut(UCameraComponent* CameraComponent)
{
	UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] OnSequenceCameraCut loadHandleID: %d GetWorld: %s"), loadHandleID, GetWorld()? *GetWorld()->GetName():TEXT("Null"));
	if (UKGSequenceManager* KGSequenceManager = UKGSequenceManager::GetInstance(GetWorld()))
	{
		if(CameraComponent)
		{
			KGObjectID CameraID = KGUtils::GetIDByObject(CameraComponent);
			UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] Call Lua OnSequenceCameraCut"));
			KGSequenceManager->CallLuaFunction("OnSequenceCameraCut", loadHandleID, CameraID);
		}
	}
}

void USequenceLoadTask::HelperBindSequenceCallBack()
{
	ALevelSequenceActor* LevelSequenceActor = Cast<ALevelSequenceActor>(KGUtils::GetObjectByID(LevelSequenceActorID));
	if(!LevelSequenceActor)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[USequenceLoadTask] HelperBindSequenceCallBack LevelSequenceActor Is Valid loadHandleID: %d LevelSequenceActorID: %lld"), loadHandleID, LevelSequenceActorID);
		return;
	}
	ULevelSequencePlayer* SequencePlayer = LevelSequenceActor->GetSequencePlayer();
	if(!SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[USequenceLoadTask] HelperBindSequenceCallBack SequencePlayer Is Valid loadHandleID: %d LevelSequenceActorID: %lld"), loadHandleID, LevelSequenceActorID);
		return;
	}
	UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] HelperBindSequenceCallBack loadHandleID: %d "), loadHandleID);
	SequencePlayer->OnPlay.AddDynamic(this, &USequenceLoadTask::OnSequencePlay);
	SequencePlayer->OnFinished.AddDynamic(this, &USequenceLoadTask::OnSequenceFinished);
	SequencePlayer->OnPause.AddDynamic(this, &USequenceLoadTask::OnSequencePause);
	SequencePlayer->OnSubSequencePlay.AddDynamic(this, &USequenceLoadTask::OnSequenceSubSequencePlay);
	SequencePlayer->OnCameraCut.AddDynamic(this, &USequenceLoadTask::OnSequenceCameraCut);
}

void USequenceLoadTask::HelperRemoveSequenceCallBack()
{
	ALevelSequenceActor* LevelSequenceActor = Cast<ALevelSequenceActor>(KGUtils::GetObjectByID(LevelSequenceActorID));
	if(!LevelSequenceActor)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[USequenceLoadTask] HelperRemoveSequenceCallBack LevelSequenceActor Is Valid loadHandleID: %d LevelSequenceActorID: %lld"), loadHandleID, LevelSequenceActorID);
		return;
	}
	ULevelSequencePlayer* SequencePlayer = LevelSequenceActor->GetSequencePlayer();
	if(!SequencePlayer)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[USequenceLoadTask] HelperRemoveSequenceCallBack SequencePlayer Is Valid loadHandleID: %d LevelSequenceActorID: %lld"), loadHandleID, LevelSequenceActorID);
		return;
	}
	UE_LOG(LogSequenceManager, Log, TEXT("[USequenceLoadTask] HelperBindSequenceCallBack loadHandleID: %d "), loadHandleID);
	SequencePlayer->OnPlay.RemoveAll(this);
	SequencePlayer->OnFinished.RemoveAll(this);
	SequencePlayer->OnPause.RemoveAll(this);
	SequencePlayer->OnSubSequencePlay.RemoveAll(this);
	SequencePlayer->OnCameraCut.RemoveAll(this);
}

ALevelSequenceActor* USequenceLoadTask::GetSequenceActor()
{
	UObject* Actor = KGUtils::GetObjectByID(LevelSequenceActorID);
	ALevelSequenceActor* LevelSequenceActor = Cast<ALevelSequenceActor>(Actor);
	return LevelSequenceActor;
}

ULevelSequencePlayer* USequenceLoadTask::GetSequencePlayer()
{
	UObject* Actor = KGUtils::GetObjectByID(LevelSequenceActorID);
	ALevelSequenceActor* LevelSequenceActor = Cast<ALevelSequenceActor>(Actor);
	if(!LevelSequenceActor)
	{
		UE_LOG(LogSequenceManager, Warning, TEXT("[USequenceLoadTask] GetSequencePlayer LevelSequenceActor Is Valid loadHandleID: %d LevelSequenceActorID: %lld"), loadHandleID, LevelSequenceActorID);
		return nullptr;
	}
	ULevelSequencePlayer* SequencePlayer = LevelSequenceActor->GetSequencePlayer();
	return SequencePlayer;
}