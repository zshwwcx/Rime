#include "CoreUObject.h"
#include "Core.h"
#include "UObject/NameTypes.h"
#include "Containers/UnrealString.h"
#include "Features/IModularFeatures.h"
#include "Programs/UnrealHeaderTool/Public/IScriptGeneratorPluginInterface.h"

#define LOCTEXT_NAMESPACE "FKGTypeRedirectorModule"

DEFINE_LOG_CATEGORY_STATIC(LogKGTypeRedirector, Log, All);

class FKGTypeRedirectorModule : public IScriptGeneratorPluginInterface
{
public:
    virtual void StartupModule() override
    {
        IModularFeatures::Get().RegisterModularFeature(TEXT("ScriptGenerator"), this);
    }

    virtual void ShutdownModule() override
    {
        IModularFeatures::Get().UnregisterModularFeature(TEXT("ScriptGenerator"), this);
    }

    virtual FString GetGeneratedCodeModuleName() const override { return TEXT("KGCore"); }

    virtual bool SupportsTarget(const FString& TargetName) const override { return true; }

    virtual void Initialize(const FString& RootLocalPath, const FString& RootBuildPath, const FString& OutputDirectory, const FString& IncludeBase) override
    {
        RootDirectory = RootLocalPath;
        RootDirectory.Append(TEXT("/KGRedirectINI"));
    }

    virtual bool ShouldExportClassesForModule(const FString& ModuleName, EBuildModuleType::Type ModuleType, const FString& ModuleGeneratedIncludeDirectory) const override
    {
        FKGTypeRedirectorModule* NonConstPtr = const_cast<FKGTypeRedirectorModule*>(this);
        bool Ret = NonConstPtr->CheckModuleName(ModuleName, ModuleType);
        if (Ret)
        {
            UE_LOG(LogKGTypeRedirector, Display, TEXT("KuaishouGame UHT[ShouldExportClassesForModule] - %s"), *ModuleName);
        }
        return Ret;
    }
    virtual bool ShouldExportStructForModule(const FString& ModuleName, EBuildModuleType::Type ModuleType, const FString& ModuleGeneratedIncludeDirectory) const override
    {
        FKGTypeRedirectorModule* NonConstPtr = const_cast<FKGTypeRedirectorModule*>(this);
        bool Ret = NonConstPtr->CheckModuleName(ModuleName, ModuleType);
        if (Ret)
        {
            UE_LOG(LogKGTypeRedirector, Display, TEXT("KuaishouGame UHT[ShouldExportStructForModule] - %s"), *ModuleName);
        }
        return Ret;
    }
    virtual bool ShouldExportEnumForModule(const FString& ModuleName, EBuildModuleType::Type ModuleType, const FString& ModuleGeneratedIncludeDirectory) const override
    {
        FKGTypeRedirectorModule* NonConstPtr = const_cast<FKGTypeRedirectorModule*>(this);
        bool Ret = NonConstPtr->CheckModuleName(ModuleName, ModuleType);
        if (Ret)
        {
            UE_LOG(LogKGTypeRedirector, Display, TEXT("KuaishouGame UHT[ShouldExportEnumForModule] - %s"), *ModuleName);
        }
        return Ret;
    }
    virtual void ExportClass(UClass* Class, const FString& SourceHeaderFilename, const FString& GeneratedHeaderFilename, bool bHasChanged) override
    {
        UPackage* Package = Class->GetPackage();
        if (Package != nullptr && Package->GetName() == CurrentModuleFullName)
        {
            FString ClassName = Class->GetName();
            if (EditorModule)
            {
                GeneratedFileContent += FString::Printf(TEXT("+ClassRedirects=(OldName=\"/Script/C7Editor.%s\",NewName=\"%s.%s\")\r\n"), *CheckOldName(ClassName), *CurrentModuleFullName, *ClassName);
            }
            else
            {
                GeneratedFileContent += FString::Printf(TEXT("+ClassRedirects=(OldName=\"/Script/C7.%s\",NewName=\"%s.%s\")\r\n"), *CheckOldName(ClassName), *CurrentModuleFullName, *ClassName);   
            }
        }
    }
    virtual void ExportStruct(class UStruct* Struct, const FString& SourceHeaderFilename, const FString& GeneratedHeaderFilename, bool bHasChanged) override
    {
        UPackage* Package = Struct->GetPackage();
        if (Package != nullptr && Package->GetName() == CurrentModuleFullName)
        {
            FString ClassName = Struct->GetName();
            if (EditorModule)
            {
                GeneratedFileContent += FString::Printf(TEXT("+StructRedirects=(OldName=\"/Script/C7Editor.%s\",NewName=\"%s.%s\")\r\n"), *CheckOldName(ClassName), *CurrentModuleFullName, *ClassName);   
            }
            else
            {
                GeneratedFileContent += FString::Printf(TEXT("+StructRedirects=(OldName=\"/Script/C7.%s\",NewName=\"%s.%s\")\r\n"), *CheckOldName(ClassName), *CurrentModuleFullName, *ClassName);
            }
        }
    }
    virtual void ExportEnum(class UEnum* Enum, const FString& SourceHeaderFilename, const FString& GeneratedHeaderFilename, bool bHasChanged) override
    {
        UPackage* Package = Enum->GetPackage();
        if (Package != nullptr && Package->GetName() == CurrentModuleFullName)
        {
            FString ClassName = Enum->GetName();
            if (EditorModule)
            {
                GeneratedFileContent += FString::Printf(TEXT("+EnumRedirects=(OldName=\"/Script/C7Editor.%s\",NewName=\"%s.%s\")\r\n"), *CheckOldName(ClassName), *CurrentModuleFullName, *ClassName);
            }
            else
            {
                GeneratedFileContent += FString::Printf(TEXT("+EnumRedirects=(OldName=\"/Script/C7.%s\",NewName=\"%s.%s\")\r\n"), *CheckOldName(ClassName), *CurrentModuleFullName, *ClassName);
            }
        }
    }

    virtual void FinishExport() override
    {
        if (CurrentModule.Len() > 0)
        {
            const FString FilePath = FString::Printf(TEXT("%s/Default%s.ini"), *RootDirectory, *CurrentModule);
            FString FileContent;
            FFileHelper::LoadFileToString(FileContent, *FilePath);

            if (GeneratedFileContent != FileContent && GeneratedFileContent.Len() > 0)
            {
                FFileHelper::SaveStringToFile(GeneratedFileContent, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
            }
        }
        GeneratedFileContent = TEXT("[CoreRedirects]\r\n");
    }

    virtual FString GetGeneratorName() const override
    {
        return TEXT("Kuaishou-Game type-redirector exporter");
    }

private:
    bool CheckModuleName(const FString& ModuleName, EBuildModuleType::Type ModuleType)
    {
        bool Ret = RedirectTargetModules.Contains(ModuleName);
        if (Ret && CurrentModule != ModuleName)
        {
            // 保存前一个模块！
            FinishExport();
            CurrentModule = ModuleName;
            EditorModule = ModuleType == EBuildModuleType::Type::EngineEditor || ModuleType == EBuildModuleType::Type::GameEditor;
            CurrentModuleFullName = FString::Printf(TEXT("/Script/%s"), *ModuleName);
        }
        return Ret;
    }
    FString CheckOldName(const FString& OldName)
    {
        if (RenamedTypes.Contains(OldName))
        {
            return RenamedTypes[OldName];
        }
        return OldName;
    }
    // 代码写死的部分插件需要进行一下重定向操作
    TSet<FString> RedirectTargetModules = {
        TEXT("KGAI"),
        TEXT("KGAIEditor"),
        TEXT("KGBattleSystem"),
        TEXT("KGBattleSystemEditor"),
        TEXT("KGCharacter"),
        TEXT("KGCharacterEditor"),
        TEXT("KGCore"),
        TEXT("KGCoreEditor"),
        TEXT("KGLevelFlow"),
        TEXT("KGLevelFlowEditor"),
        TEXT("KGStoryLine"),
        TEXT("KGStoryLineEditor")
    };
    // 代码梳理的过程中，重命名的部分（原先包含C7）
    TMap<class FString, class FString> RenamedTypes = {
        {TEXT("KGBasicManager"), TEXT("C7BasicManager")},
        {TEXT("KGResourceManager"), TEXT("C7ResourceManager")},
        {TEXT("KGUObjectManager"), TEXT("C7UObjectManager")},
        {TEXT("KGObjectCreateListener"), TEXT("C7ObjectCreateListener")},
        {TEXT("KGObjectDeleteListener"), TEXT("C7ObjectDeleteListener")},
        {TEXT("KGCoreFunctionLibrary"), TEXT("C7CoreFunctionLibrary")},
        {TEXT("KGGameInstanceBase"), TEXT("C7GameInstanceBase")},
        {TEXT("KGUIPlatformCustomSetting"), TEXT("C7UIPlatformCustomSetting")},
        {TEXT("KGUserWidget"), TEXT("C7UserWidget")},
        {TEXT("KGWidgetAnimationEvent"), TEXT("C7WidgetAnimationEvent")},
        {TEXT("KGAnimationEventBinding"), TEXT("C7AnimationEventBinding")},
        {TEXT("KGUMGAnimationNotifyEventBinding"), TEXT("C7UMGAnimationNotifyEventBinding")},
        {TEXT("KGUMGAnimationNotifyEvents"), TEXT("C7UMGAnimationNotifyEvents")},
        {TEXT("OnKGTouch"), TEXT("OnC7Touch")},
        {TEXT("KGUserWidgetAnimComponent"), TEXT("C7UserWidgetAnimComponent")},
        {TEXT("KGUserWidgetComponent"), TEXT("C7UserWidgetComponent")},
        {TEXT("KGUserWidgetComponentSetting"), TEXT("C7UserWidgetComponentSetting")},
        {TEXT("KGResourceList"), TEXT("C7ResourceList")},
        {TEXT("KGAsyncLoadCompleted"), TEXT("C7AsyncLoadCompleted")},
        {TEXT("KGLoadDump"), TEXT("C7LoadDump")},
        {TEXT("KGLoadDumpList"), TEXT("C7LoadDumpList")},
        {TEXT("KGODLForResourceManager"), TEXT("C7ODLForResourceManager")},
        {TEXT("KGInt64s"), TEXT("C7Int64s")},
        {TEXT("KGStrings"), TEXT("C7Strings")},
        {TEXT("KGObjects"), TEXT("C7Objects")},
        {TEXT("KGActors"), TEXT("C7Actors")},
        {TEXT("KGTMapOfStringString"), TEXT("C7TMapOfStringString")},
        {TEXT("KGEditorStyle"), TEXT("C7EditorStyle")},
        {TEXT("KGJsonExporter"), TEXT("C7JsonExporter")},
        {TEXT("KGCoreEditorFunctionLibrary"), TEXT("C7CoreEditorFunctionLibrary")},
        {TEXT("EKGWidgetAnimationEvent"), TEXT("EC7WidgetAnimationEvent")},
        {TEXT("ELLMTagKG"), TEXT("ELLMTagC7")},
    };
    
    FString RootDirectory;
    FString CurrentModule;
    FString CurrentModuleFullName;
    bool EditorModule;
    FString GeneratedFileContent = TEXT("[CoreRedirects]\r\n");
};

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FKGTypeRedirectorModule, KGTypeRedirector)
