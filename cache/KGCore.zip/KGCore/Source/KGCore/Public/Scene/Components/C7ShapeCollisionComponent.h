// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ShapeComponent.h"
#include "C7ShapeCollisionComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FC7DetectEnterTrigger, AActor*, Player, const FVector&, Pos);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FC7DetectLeaveTrigger, AActor*, Player, const FVector&, Pos);

UENUM()
enum class EC7ShapeCollisionType : uint8
{
	Sphere,
	Box
};

USTRUCT(BlueprintType)
struct FC7InteractableCustomScopeParams
{
	GENERATED_BODY()

	// 内圆半径
	UPROPERTY(BlueprintReadWrite, Transient)
	float InnerRadius = 0.f;
	
	// 外圆半径
	UPROPERTY(BlueprintReadWrite, Transient)
	float MaxRadius = 0.f;
	
	// 用于Mesh视觉正方向和交互物实际正方向存在偏差的Case
	UPROPERTY(BlueprintReadWrite, Transient)
	float LimitAngleYawOffset = 0.f;
	
	// 可交互角度限制
	UPROPERTY(BlueprintReadWrite, Transient)
	float HalfMaxAngle = 180.f;
	
	// 可交互最小角度限制
	UPROPERTY(BlueprintReadWrite, Transient)
	float HalfMinAngle = 0.f;

	// 可交互对象胶囊体高度
	UPROPERTY(BlueprintReadWrite, Transient)
	float OwnerCapsuleHalfHeight = 0.f;
	
	// 可交互对象胶囊体半径
	UPROPERTY(BlueprintReadWrite, Transient)
	float OwnerCapsuleRadius = 0.f;

	// 检测到玩家的连线阻挡
	UPROPERTY(BlueprintReadWrite, Transient)
	bool bCheckLineTracePlayer = false;

	// 检测到相机的连线阻挡
	UPROPERTY(BlueprintReadWrite, Transient)
	bool bCheckLineTraceCamera = false;

	// 连线检测最小的距离，若小于此距离，则不再连线检测同时也认为脱离交互范围
	UPROPERTY(BlueprintReadWrite, Transient)
	float LineTracePlayerMinDistance = -1.0f;
	
	// 连线检测最小的距离，若小于此距离，则不再连线检测同时也认为脱离交互范围
	UPROPERTY(BlueprintReadWrite, Transient)
	float LineTraceCameraMinDistance = -1.0f;
};

class FPrimitiveSceneProxy;

/**
 * 
 */
UCLASS(ClassGroup="Collision", editinlinenew, hidecategories=(Object,LOD,Lighting,TextureStreaming), meta=(DisplayName="C7ShapeCollision Collision", BlueprintSpawnableComponent))
class KGCORE_API UC7ShapeCollisionComponent : public UShapeComponent
{
	GENERATED_BODY()
	
protected:
	/** The extents (radii dimensions) of the box **/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, export, Category=Shape)
	FVector BoxExtent;

	///** Used to control the line thickness when rendering */
	//UPROPERTY(EditAnywhere, BlueprintReadWrite, export, Category=Shape)
	//float LineThickness;

	/** The radius of the sphere **/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, export, Category=Shape)
	float SphereRadius;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, export, Category=Tags)
	FName CollisionTag;

public:
	UC7ShapeCollisionComponent(const FObjectInitializer& ObjectInitializer);
	
	virtual void BeginPlay() override;
	
	/**
	 * Change the sphere radius. This is the unscaled radius, before component scale is applied.
	 * @param	InSphereRadius: the new sphere radius
	 * @param	bUpdateOverlaps: if true and this shape is registered and collides, updates touching array for owner actor.
	 */
	UFUNCTION(BlueprintCallable, Category="Components|Sphere")
	void SetSphereRadius(float InSphereRadius, bool bUpdateOverlaps=true);

	// @return the radius of the sphere, with component scale applied.
	UFUNCTION(BlueprintCallable, Category="Components|Sphere")
	float GetScaledSphereRadius() const;

	// @return the radius of the sphere, ignoring component scale.
	UFUNCTION(BlueprintCallable, Category="Components|Sphere")
	float GetUnscaledSphereRadius() const;

	//~ Begin UPrimitiveComponent Interface.
	virtual FPrimitiveSceneProxy* CreateSceneProxy() override;
	virtual bool IsZeroExtent() const override;
	virtual struct FCollisionShape GetCollisionShape(float Inflation = 0.0f) const override;
	virtual bool AreSymmetricRotations(const FQuat& A, const FQuat& B, const FVector& Scale3D) const override;
	//~ End UPrimitiveComponent Interface.

	//~ Begin USceneComponent Interface
	virtual FBoxSphereBounds CalcBounds(const FTransform& LocalToWorld) const override;
	virtual void CalcBoundingCylinder(float& CylinderRadius, float& CylinderHalfHeight) const override;
	//~ End USceneComponent Interface

	//~ Begin UShapeComponent Interface
	virtual void UpdateBodySetup() override;
	//~ End UShapeComponent Interface

	// Get the scale used by this shape. This is a uniform scale that is the minimum of any non-uniform scaling.
	// @return the scale used by this shape.
	UFUNCTION(BlueprintCallable, Category="Components|Sphere")
	float GetShapeScale() const;

	// Sets the sphere radius without triggering a render or physics update.
	FORCEINLINE void InitSphereRadius(float InSphereRadius) { SphereRadius = InSphereRadius; }


	/** 
	 * Change the box extent size. This is the unscaled size, before component scale is applied.
	 * @param	InBoxExtent: new extent (radius) for the box.
	 * @param	bUpdateOverlaps: if true and this shape is registered and collides, updates touching array for owner actor.
	 */
	UFUNCTION(BlueprintCallable, Category="Components|Box")
	void SetBoxExtent(FVector InBoxExtent, bool bUpdateOverlaps=true);

	// Set the LineThickness
	//UFUNCTION(BlueprintCallable, Category="Components|Box")
	//void SetLineThickness(float Thickness);

	// @return the box extent, scaled by the component scale.
	UFUNCTION(BlueprintCallable, Category="Components|Box")
	FVector GetScaledBoxExtent() const;

	// @return the box extent, ignoring component scale.
	UFUNCTION(BlueprintCallable, Category="Components|Box")
	FVector GetUnscaledBoxExtent() const;

	// Sets the box extents without triggering a render or physics update.
	FORCEINLINE void InitBoxExtent(const FVector& InBoxExtent) { BoxExtent = InBoxExtent; }

	UFUNCTION(BlueprintCallable, Category="Components|Tags")
	FORCEINLINE FName GetCollisionTag() const { return CollisionTag; }

	UFUNCTION(BlueprintCallable, Category="Components|Tags")
	virtual float GetCollisionParam() const { return 0; }

public:
	FPrimitiveSceneProxy* CreateBoxSceneProxy() ;
	
	FPrimitiveSceneProxy* CreateSphereSceneProxy() ;

	UFUNCTION(BlueprintCallable)
	void InitCollisionAsBox(const FVector& InBoxExtent);
	
	UFUNCTION(BlueprintCallable)
	void InitCollisionAsSphere(const float& InRadius);
	
	UFUNCTION(BlueprintCallable)
	void SetShapeType(EC7ShapeCollisionType InShapeType);

	UFUNCTION(BlueprintCallable)
	void SetEntityOwner(const FString& EID);

	bool DealMoveDeltaByCollision(FVector& MoveDelta, const FVector& StartLocation, const FVector& EndLocation, const float UpdateComponentXYRadius, const bool bNeedSlide);

	bool ConstraintLocationXYInRange(const FVector& TargetLocation, FVector& FinalLocation);

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ShapeThickness = 10;

	UPROPERTY(BlueprintReadWrite, EditDefaultsOnly)
	bool bForceConstraintInArea = false;
	
	FString OwnerEntityID;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EC7ShapeCollisionType ShapeType = EC7ShapeCollisionType::Sphere;

public:
	//设置Owner的Int UID
	UFUNCTION(BlueprintCallable)
	void SetOwnerIntUID(int64 InOwnerUID);
	
	// 设置为被探测者
	// InOwnerUID: 脚本层Entity的UID，若为0则不分发到脚本层
	// bInUseNativeDetectEvent: 触发自身的检测事件
	UFUNCTION(BlueprintCallable)
	void InitAsInteractable(int64 InOwnerUID, bool bInUseNativeDetectEvent);

	// 设置使用触发自身的检测事件
	UFUNCTION(BlueprintCallable)
	void SetUseNativeDetectEvent(bool bInUseNativeDetectEvent);

	// 是否可被探测到
	UFUNCTION(BlueprintCallable)
	bool IsActivateForDetect();

	// 开启、激活探测
	UFUNCTION(BlueprintCallable)
	void EnableInterActiveForDetect(bool bEnable);

	// 设置交互的所有自定义参数
	UFUNCTION(BlueprintCallable)
	void SetCustomScopeParams(bool InCustomScopeEnable, const FC7InteractableCustomScopeParams& InCustomScope);
	
	// 获取交互的自定义参数
	UFUNCTION(BlueprintCallable)
	void GetCustomScopeParams(FC7InteractableCustomScopeParams& OutCustomScope);
	FC7InteractableCustomScopeParams GetCustomScopeParams() { return CustomScopeParams; }
	
	// 设置自定义参数的内外圆
	UFUNCTION(BlueprintCallable)
	void ResetLimitCustomScope(float InnerRadius, float MaxRadius);
	
	// 设置自定义交互角度限制
	UFUNCTION(BlueprintCallable)
	void ResetLimitCustomAngle(float HalfMinAngle, float HalfMaxAngle, float YawOffset);

	// 设置自定义参数的胶囊体大小
	UFUNCTION(BlueprintCallable)
	void SetOwnerCapsuleSize(float InHalfHeight, float InRadius);
	
	// 设置自定义玩家碰撞检测
	UFUNCTION(BlueprintCallable)
	void SetCheckLineTracePlayer(bool bEnable, float MinCheckDistance);
	
	// 设置自定义相机碰撞检测
	UFUNCTION(BlueprintCallable)
	void SetCheckLineTraceCamera(bool bEnable, float MinCheckDistance);
	
	virtual void EnterInteractiveTrigger(AActor* Other, const FVector& Pos);
	
	virtual void LeaveInteractiveTrigger(AActor* Other, const FVector& Pos);

public:
	UPROPERTY(BlueprintReadOnly)
	int64 OwnerIntUID = 0;
	
	UPROPERTY(BlueprintReadWrite)
	FC7InteractableCustomScopeParams CustomScopeParams;
	
	// C++层使用的进入触发的InnerEvent，脚本应走统一封装
	// UPROPERTY(BlueprintAssignable)
	FC7DetectEnterTrigger OnEnterTrigger_MD;

	// C++层使用的离开触发的InnerEvent，脚本应走统一封装
	// UPROPERTY(BlueprintAssignable)
	FC7DetectLeaveTrigger OnLeaveTrigger_MD;
	
private:
	bool bUseNativeDetectEvent = false;
	
	bool bActivateForDetect = false;

public:
	
	
// 用这个组件来显示Cylinder的wire，因为只是编辑器下的预览，实际没有圆柱的碰撞
#if WITH_EDITOR
	FPrimitiveSceneProxy* CreateCylinderSceneProxy() ;
	
	void SetShow3DInEditor(bool bShow3D)
	{
#if WITH_EDITORONLY_DATA
		bShow3DInEditor = bShow3D;
		MarkRenderStateDirty();
#endif
	}
	
#endif

	
#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bShowSphereWireAsCylinderInEditor = false;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bShow3DInEditor = true;
	
#endif
	
};

// ----------------- INLINES ---------------

FORCEINLINE float UC7ShapeCollisionComponent::GetScaledSphereRadius() const
{
	return SphereRadius * GetShapeScale();
}

FORCEINLINE float UC7ShapeCollisionComponent::GetUnscaledSphereRadius() const
{
	return SphereRadius;
}

FORCEINLINE float UC7ShapeCollisionComponent::GetShapeScale() const
{
	return GetComponentTransform().GetMinimumAxisScale();
}

FORCEINLINE FVector UC7ShapeCollisionComponent::GetScaledBoxExtent() const
{
	return BoxExtent * GetComponentTransform().GetScale3D();
}

FORCEINLINE FVector UC7ShapeCollisionComponent::GetUnscaledBoxExtent() const
{
	return BoxExtent;
}
