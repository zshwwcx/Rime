#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "Engine/AssetUserData.h"

#include "CommonDefines.generated.h"



USTRUCT(BlueprintType)
struct FKGInt64s
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<int64> List;
};



USTRUCT(BlueprintType)
struct FKGStrings
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FString> List;
};



USTRUCT(BlueprintType)
struct FKGNames
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FName> List;
};



USTRUCT(BlueprintType)
struct FKGObjects
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<UObject*> List;
};



USTRUCT(BlueprintType)
struct FKGActors
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<AActor*> List;
};



USTRUCT(BlueprintType)
struct FKGComponents
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<USceneComponent*> List;
};



USTRUCT(BlueprintType)
struct FKGTMapOfStringString
{
	GENERATED_BODY()
public:
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite)
	TMap<FString,FString> Map;
};

// 自定义AssetView处理类型
UENUM(BlueprintType)
enum class EEditorCommonAssetState : uint8
{
	Normal = 0,            
	UnFinish,
	Finish
};

UCLASS(Blueprintable)
class KGCORE_API UArtAssetUserData : public UAssetUserData
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Asset Tags")
	EEditorCommonAssetState AssetTag;  // 用于存储标签的
};

UENUM(BlueprintType)
enum class EManagerType : uint8
{
	EMT_Null,
	EMT_BSManager,
	EMT_PPManager, // todo deprecated
	EMT_PostProcessManager,
	EMT_RoleCompositeManager,
	EMT_CurveManager,
	EMT_LocalizationManager,
	EMT_AkAudioManager,
	EMT_EffectManager,
	EMT_MaterialManager,
	EMT_ObjectActorManager,
	EMT_UEActorManager,
	EMT_WorkProxyManager,
	EMT_SceneDisplayManager,
	EMT_TickableWidgetComponentManager,
	EMT_KGInputProcessorManager,
	EMT_WorldManager,
	EMT_ManorBuildingManager,
	EMT_Time,
	EMT_WorldWidgetManager2,
	EMT_MediaManager,
	EMT_CppAssetManager,
	EMT_SequenceManager,
	EMT_CharacterLightManager,
	EMT_SceneRuntimeEditorManager,
	EMT_TimerManager,
	EMT_HUDManager,
	EMT_DataCacheManager,
	EMT_DamageProcessManager,
	EMT_PlatformScalabilitySettings,
	EMT_GMEManager,
	EMT_CombatUnitManager,
    EMT_TabClose,
	EMT_WebAnimationManager,
	EMT_GeographyClimateManager,
	EMT_CombatSettingsManager,
	EMT_AllInSdkManager,
	EMT_ActorDebugManager,
	EMT_EasyFileManager,
	EMT_Max,
};


#ifndef KG_INVALID_ID
#define KG_INVALID_ID 0
#endif

using KGObjectID = int64;
using KGActorID = int64;
#ifndef KG_INVALID_ACTOR_ID
#define KG_INVALID_ACTOR_ID (0)
#endif
#define IS_VALID_ACTOR_ID(UID) (UID != KG_INVALID_ACTOR_ID)

using KGEntityID = int64;
#ifndef KG_INVALID_ENTITY_ID
#define KG_INVALID_ENTITY_ID (0)
#endif
#define IS_VALID_ENTITY_ID(UID) (UID != KG_INVALID_ENTITY_ID)

using KGActorClassType = int32;
