﻿#pragma once

#include "Kismet/BlueprintPlatformLibrary.h"

#include "C7EditorPreviewGameInstance.generated.h"

UCLASS(BlueprintType, Blueprintable)
class KGCORE_API UKGEditorPreviewGameInstance : public UPlatformGameInstance
{
	GENERATED_BODY()

public:
	UKGEditorPreviewGameInstance(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer) {}
};