// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "KGTime.generated.h"

/**
 * UKGTime
 */
UCLASS(BlueprintType, Blueprintable)
class KGCORE_API UKGTime : public UKGBasicManager
{
	GENERATED_UCLASS_BODY()

public:
	static UKGTime* GetInstance(UObject* InContext)
	{
		return Cast<UKGTime>(GetManagerByType(InContext, EManagerType::EMT_Time));	
	}
	
	virtual EManagerType GetManagerType() override { return EManagerType::EMT_Time; }
	virtual void NativeInit() override;
	virtual void NativeUninit() override;


	// 每帧开始时调用
	void OnFrameBegin();

	void SetServerTimeZone(int32 InServerTimeZone) { ServerTimeZone = InServerTimeZone; }
	void AdjustClientTimeWithServer(int64 InServerTime, int32 InServerTimeZone = 0);

	//返回服务器UTC时间戳（from epoch）
	int64 GetUTCTimeOfServer();
	int64 GetUTCTimeOfClient();
	//返回引擎表现层的时间，这个仅能用于表现同步，与绝对时间偏差会很大， MS
	int64 GetTimeOfEngineWorldMS();

	FString GetUTCTimeStringOfServer();
	FString GetLocalTimeStringOfServer();
	FString GetUTTimeStringOfClient();
	FString GetLocalTimeStringOfClient();


	
	void Dump();
private:

	int64 GetUTCTimeFromEpoch();
	int GetLocalTimeZone();
	int GetServerTimeZone() { return ServerTimeZone; }
	bool IsSyncWithServer() const { return UTCTimeOfServer != INVALID_TIME && UTCTimeOfServerSync != INVALID_TIME; }
private:
	static constexpr int64 INVALID_TIME = 0;
	static constexpr int64 MillisecondsPerHour = 3600 * 1000;
	static FDateTime Epoch;

	//服务器同步来下的 服务器时区 
	int8 ServerTimeZone = 0; // server time zone
	//服务器同步下来的服务器UTC时间戳（MS）
	int64 UTCTimeOfServer = INVALID_TIME;
	// 服务器同步消息收到时， 客户端上UTC时间戳（MS），用于客户端后续获取服务器UTC时间的基础
	int64 UTCTimeOfServerSync = INVALID_TIME;
	// 这个管理器启动UTC时间戳（MS）
	int64 UTCTimeOfClientManagerStart = INVALID_TIME;
};
