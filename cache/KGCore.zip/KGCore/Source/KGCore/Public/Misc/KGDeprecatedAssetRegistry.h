#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "KGDeprecatedAssetRegistry.generated.h"

UCLASS()
class KGCORE_API UKGDeprecatedAssetRegistry : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Deprecated")
	TSet<FName> DeprecatedPaths;

	static const FName DeprecatedAssetRegistryPath;
};
