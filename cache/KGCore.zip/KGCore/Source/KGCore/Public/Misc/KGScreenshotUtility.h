// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "RenderingThread.h"
#include "RendererInterface.h"
#include "Engine/Canvas.h"
#include "Components/Widget.h"
#include "ImageCore.h"
#include "KGScreenshotUtility.generated.h"

/**
 * 
 */
DECLARE_LOG_CATEGORY_EXTERN(LogKGScreenshotUtility, Log, All);
DECLARE_DYNAMIC_DELEGATE_ThreeParams(FKGOnScreenShotCaptured,UTextureRenderTarget2D*,Tex,int32,SizeX,int32,SizeY);
DECLARE_DYNAMIC_DELEGATE_OneParam(FKGOnScreenShotFailed, const FString&, ErrorMessage);
DECLARE_DYNAMIC_DELEGATE_TwoParams(FKGOnAsyncExportRenderTarget, bool, Result, FString, TotalFileName);

UCLASS()
class KGCORE_API UKGScreenshotUtility : public UObject
{
	GENERATED_BODY()
	
	UFUNCTION()
	void Init();

	UFUNCTION()
	void UnInit();
	
	UFUNCTION()
	bool TakeScreenShot(bool bShowUI,FString& FileName);

	UFUNCTION()
	bool TakeScreenShotWithHeadInfoAndMarquee(FString& FileName);


	UFUNCTION()
	bool TakeScreenShotWithClipRect(bool bShowUI, FString& FileName, FVector2D ScreenPosition, FVector2D ScreenSize);

	void OnScreenShotCaptured(int32 InSizeX, int32 InSizeY, const TArray<FColor>& InImageData);
	
	UFUNCTION()
	void AddWaterMark(UTextureRenderTarget2D* MainRT,UTexture* WaterMark,FVector2D& Position,FVector2D& WaterMarkSize, float Rotation);

	UFUNCTION()
	UTextureRenderTarget2D* DuplicationRenderTexture(UTextureRenderTarget2D* SourceTexture);
	
	UFUNCTION()
	UTextureRenderTarget2D* DuplicationRenderTextureWithRect(UTextureRenderTarget2D* SourceTexture, FVector4 Rect);

	UFUNCTION()
	UTextureRenderTarget2D* CreateRenderTargetFromTexture2D(UTexture2D* SourceTexture);
	
	UFUNCTION()
	FString GetImageBase64FromMaterial(UMaterialInstanceDynamic* MaterialInstanceDynamic, int SizeX, int SizeY);
	
	UPROPERTY()
	FKGOnScreenShotCaptured OnScreenShotCapturedDelegate;

	UPROPERTY()
	FKGOnScreenShotFailed OnScreenShotFailedDelegate;

	UPROPERTY()
	FKGOnAsyncExportRenderTarget OnAsyncExportRenderTargetDelegate;

	UPROPERTY()
	UCanvas* CanvasForDrawRT;
	
	UFUNCTION()
	void AsyncExportRenderTarget(UTextureRenderTarget2D* TextureRenderTarget, const FString& FilePath, const FString& FileName);

	// 设置 Widget 的 RenderChannel，用于截图/录像时过滤显示
	UFUNCTION()
	void SetWidgetRenderChannel(UWidget* Widget, int32 RenderChannel);
	
	// 从文件加载图片到FImage
	static bool LoadImageFromFile(const FString& Filename, FImage& OutImage);
	
	// 从文件导入图片并创建缩略图纹理
	// @param Filename 图片文件路径
	// @param MaxThumbnailSize 缩略图的最大尺寸
	UFUNCTION()
	static UTexture2D* ImportFileAsThumbnailTexture2D(const FString& Filename, int32 MaxThumbnailSize = 256);

	static FVector2D ClipScreenPosition;
	static FVector2D ClipScreenSize;
	static bool IsClipRect;
};
