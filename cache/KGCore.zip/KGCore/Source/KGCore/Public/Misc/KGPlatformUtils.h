﻿#pragma once
#include "CoreMinimal.h"

class KGCORE_API KGPlatformUtils
{
public:
	static int32 GetGameplayScability();
	static bool Is_ES3_1_FeatureLevel(UObject* WorldContextObject);
	static bool IsInLevelPreviewWorld(UObject* WorldContextObject);
};
