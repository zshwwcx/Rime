// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "HAL/Platform.h"
#include "Kismet/BlueprintPlatformLibrary.h"
#include "Manager/KGBasicManager.h"
#include "Lua/LuaEnv.h"
#include "KGGameInstanceBase.generated.h"

UCLASS(Abstract, BlueprintType, Blueprintable)
class KGCORE_API UKGGameInstanceBase : public UPlatformGameInstance
{
	GENERATED_BODY()

public:
	UKGGameInstanceBase();
	/** virtual function to allow custom GameInstances an opportunity to do cleanup when shutting down */
	virtual void Shutdown();

	virtual void OnStart();

	virtual void StartGameInstance() override;

	virtual void Init() override;

	virtual void OnObjectCountNearlyExceed(int32 CurrentObjectCount);

public:

	UPROPERTY()
	class UKGObjectCountWatcher* ObjectCountWatcher = nullptr;

protected:
    UPROPERTY(Transient)
    ULuaEnv *LuaEnv = nullptr;

	void InitLuaEnv();
    void UninitLuaEnv();

public:
    ULuaEnv *GetLuaEnv() const { return LuaEnv; }
    class ULuaGameInstance *GetLuaGameInstance();
};
