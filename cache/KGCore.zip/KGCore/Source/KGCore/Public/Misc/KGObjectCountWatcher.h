#pragma once

#include "Tickable.h"
#include "KGObjectCountWatcher.generated.h"

// 监听UObject数量超出阈值时的回调，触发各种缓存的处理
UCLASS(BlueprintType, Blueprintable)
class KGCORE_API UKGObjectCountWatcher : public UObject, public FTickableGameObject, public FUObjectArray::FUObjectCountExceedListener
{
	GENERATED_BODY()
public:
	UKGObjectCountWatcher()	{	}
	void Init(class UKGGameInstanceBase* InGameInstance);
	void UnInit();

	virtual void Tick(float DeltaTime) override;
	bool IsTickable() const
	{
		return (HasAnyFlags(RF_ClassDefaultObject) == false);
	}
	virtual TStatId GetStatId() const override
	{
		return GetStatID();
	}

	virtual void NotifyObjectCountNearlyExceed(int32 Count) override;
	virtual void NotifyUObjectCountExceed(int32 Count) override;
	virtual void OnUObjectArrayShutdown() override;

protected:
	UPROPERTY()
	class UKGGameInstanceBase* GameInstance = nullptr;

	UPROPERTY()
	bool IsObjectCountNearlyExceed = false;

	UPROPERTY()
	int CurrentObjectCount = 0;

	// control the callback to lua frequency
	UPROPERTY()
	double MinElapseBetweenCallback = 0.1;

	double PrevCallbackTime = -1;
};
