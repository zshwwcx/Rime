#pragma once
#include "CoreMinimal.h"

class KGCORE_API MathFormula {

public:
	// 半衰插值方式, 保障目标值频繁变化时, 插值变化时一阶连续的
	static float DecayValue(float srcValue, float dstValue, float halfLife, float timeDelta);
	static void DecayValue(FVector& output, const FVector& srcValue, const FVector& dstValue, float halfLife, float timeDelta);
	static void DecayValue(FVector2D& output, const FVector2D& srcValue, const FVector2D& dstValue, float halfLife, float timeDelta);
	static void DecayValue(FRotator& output, const FRotator& srcValue, const FRotator& dstValue, float halfLife, float timeDelta);

	// 弹簧插值
	static float SmoothDamp(float srcValue, float dstValue, float& curVelocity, float smoothTime, float timeDelta, float maxSpeed = FLT_MAX);
	static double SmoothDamp(double srcValue, double dstValue, double& curVelocity, float smoothTime, float timeDelta, double maxSpeed = DBL_MAX);
	static void SmoothDamp(FVector& output, const FVector& srcValue, const FVector& dstValue, FVector& curVelocity, float smoothTime, float timeDelta, float maxSpeed = FLT_MAX);


	// 线性速度方式向目标值靠近
	static float LinearCloseToDst(float src, float dst, float linearSpeed, float timeDelta);


	/*这里的角度计算都与坐标系无关
    // 角度是按照象限分布:
    //                      0
    //                      \
    //            0到-pi/2  \   0到pi/2
	//           --------------------------       
	//             到-pi    \    到pi
	//                      \
	*/
	static float SameSignAngle(float SrcAngle, float DstAngle);

	// 已yaw1为参考方向, 返回yaw1和yaw2间小于pi的夹角, 大于0时yaw1通过顺时针转向yaw2(即yaw2在yaw1的右边), 小于0是yaw1通过逆时针转向yaw(即yaw2在yaw1的左边)
	static float ClosetYawSignedDiff(float yawAngle1, float yawAngle2);
	static float ClosetYawAbsDiff(float yawAngle1, float yawAngle2);

	// 以yaw1为基础, 然后旋转到yaw2需要进行的角度差, 取值范围360到-360; 数值大于0是顺时针, 数值小于0是逆时针
	static float YawSignedNormalizedDiff(float yawAngle1, float yawAngle2);


	static float YawDecayWithNormalized(float srcYaw, float dstYaw, float halfLife, float timeDelta);

	static bool AlmostSameRotation(const FQuat& q1, const FQuat& q2, float tolerance);

	
	const static float RotateTolerateDegree;

private:
	MathFormula() {};


};


