#pragma once

#include "CoreMinimal.h"

KGCORE_API DECLARE_LOG_CATEGORY_EXTERN(LogC7, Log, All);
DECLARE_MULTICAST_DELEGATE_TwoParams(FOnWriteLog, int, const FString&);
