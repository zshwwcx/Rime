#pragma once
#include "HAL/LowLevelMemTracker.h"



#if ENABLE_LOW_LEVEL_MEM_TRACKER

#define LLM_SCOPE_KG(Tag) LLM_SCOPE((ELLMTag)Tag)

enum class ELLMTagKG : LLM_TAG_TYPE
{
	BSStart = (LLM_TAG_TYPE)ELLMTag::ProjectTagStart,
	BSTaskIns,
	BSAblIns,
	BSBuffIns,
	BSObject,
	BSNiagara,
	BSCascade,
	BSDecal,
	BSGhost,
	BSChaosCache,
	BSOSData,

};

namespace KGLLM
{
	void Initialize();
}

#else

#define LLM_SCOPE_KG(...)

#endif

