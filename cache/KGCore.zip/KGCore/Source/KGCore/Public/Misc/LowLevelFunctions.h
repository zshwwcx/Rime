#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "GameFramework/Actor.h"
#include "LowLevelFunctions.generated.h"


UCLASS()
class KGCORE_API ULowLevelFunctions : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

#pragma region Important

public:
	// 52位的全局ID
	UFUNCTION(BlueprintPure, Category = "Important")
	static int64 GetGlobalUniqueID();

	static bool IsValid(const UObject* InObject);

	static UClass* GetClassByPath(const FString& InPath);

	//UFUNCTION(BlueprintCallable)
	//static class UBasicLuaGameInstance* GetLuaGI(UObject* InWorldContext);

protected:
	static int32 GlobalIDCreater;
	static int32 ShortGlobalIDCreater;

	static TMap<FString, TWeakObjectPtr<UClass>> PathToClass;

#pragma endregion Important


#pragma region Time

public:
	// 获取当前时间戳（毫秒）
	UFUNCTION(BlueprintCallable, Category = "Time")
	static int64 GetUtcMillisecond();

	// 获取游戏运行时间（微秒）
	UFUNCTION(BlueprintCallable, Category = "Time")
	static int64 GetGameMicrosecond();

	// 设置客户端到服务器的时间差
	UFUNCTION(BlueprintCallable, Category = "Time")
	static void SetDeltaTimeToServer(int64 InDeltaTime);

public:
	static int64 DeltaTimeToServer;

#pragma endregion Time


#pragma region Math

public:
	// 斐波那契格点构造法([0,1]范围内)
	UFUNCTION(BlueprintPure, Category = "Math")
	static void FibonacciLattice(int32 N, TArray<float>& OutX, TArray<float>& OutY);
	static TArray<FVector2D> FibonacciLattice(int32 N);

	// 生成均匀球面随机点
	UFUNCTION(BlueprintPure, Category = "Math")
	static void SphericalUniformRandomPoint(int32 N, float Radius, TArray<float>& OutX, TArray<float>& OutY, TArray<float>& OutZ);
	static TArray<FVector> SphericalUniformRandomPoint(int32 N, float Radius);

	// 点到线段的距离
	UFUNCTION(BlueprintCallable, Category = "Math")
	static float PointToLineSegment(float PX, float PY, float PZ, float LPX1, float LPY1, float LPZ1, float LPX2, float LPY2, float LPZ2, bool In2D = false);
	static float PointToLineSegment(const FVector& InPoint, const FVector& LinePoint1, const FVector& LinePoint2, bool In2D = false);

	// 判断点在线段上
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckPointInsideLineSegment(float PX, float PY, float PZ, float LPX1, float LPY1, float LPZ1, float LPX2, float LPY2, float LPZ2, bool In2D = false, float DistanceError = 10.0f);
	static bool CheckPointInsideLineSegment(const FVector& InPoint, const FVector& LinePoint1, const FVector& LinePoint2, bool In2D = false, float DistanceError = 10.0f);

	// 判断点在圆形内
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckPointInsideCircle(float PX, float PY, float PZ, float CCX, float CCY, float CCZ, float Radius, float HeightDifference = 600.0f);
	static bool CheckPointInsideCircle(const FVector& InPoint, const FVector& CircleCenter, float Radius, float HeightDifference = 600.0f);

	// 判断点在矩形内
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckPointInsideRectangle(float PX, float PY, float PZ, float RCX, float RCY, float RCZ, float RDYaw, float RSX, float RSY, float HeightDifference = 600.0f);
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckPointInsideRectangleQ(float PX, float PY, float PZ, float RCX, float RCY, float RCZ, float RDX, float RDY, float RDZ, float RDW, float RSX, float RSY, float HeightDifference = 600.0f);
	static bool CheckPointInsideRectangle(const FVector& InPoint, const FVector& InRectCenter, const FRotator& InRectDir, const FVector2D& RectSize, float HeightDifference = 600.0f);

	// 判断点在扇形内
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckPointInsideFan2D(float PX, float PY, float PZ, float FCX, float FCY, float FCZ, float FDYaw, float FSX, float FSY, float FSZ, float HeightDifference = 600.0f);
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckPointInsideFan2DQ(float PX, float PY, float PZ, float FCX, float FCY, float FCZ, float FDX, float FDY, float FDZ, float FDW, float FSX, float FSY, float FSZ, float HeightDifference = 600.0f);
	static bool CheckPointInsideFan2D(const FVector& InPoint, const FVector& InFanCenter, const FRotator& InFanDir, const FVector& FanSize, float HeightDifference = 600.0f);

	// 判断圆与圆相交
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckCircleIntersectCircle(float CCX1, float CCY1, float CCZ1, float CircleRadius1, float CCX2, float CCY2, float CCZ2, float CircleRadius2, float HeightDifference = 600.0f);
	static bool CheckCircleIntersectCircle(const FVector& CircleCenter1, float CircleRadius1, const FVector& CircleCenter2, float CircleRadius2, float HeightDifference = 600.0f);

	// 判断圆与矩形相交
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckCircleIntersectRectangle(float CCX, float CCY, float CCZ, float CircleRadius, float RCX, float RCY, float RCZ, float FDYaw, float FSX, float FSY, float HeightDifference = 600.0f);
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckCircleIntersectRectangleQ(float CCX, float CCY, float CCZ, float CircleRadius, float RCX, float RCY, float RCZ, float FDX, float FDY, float FDZ, float FDW, float FSX, float FSY, float HeightDifference = 600.0f);
	static bool CheckCircleIntersectRectangle(const FVector& CircleCenter, float CircleRadius, const FVector& InRectCenter, const FRotator& InRectDir, const FVector2D& RectSize, float HeightDifference = 600.0f);

	// 判断圆与扇形相交
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckCircleIntersectFan2D(float CCX, float CCY, float CCZ, float CircleRadius, float FCX, float FCY, float FCZ, float FDYaw, float FSX, float FSY, float FSZ, float HeightDifference = 600.0f);
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckCircleIntersectFan2DQ(float CCX, float CCY, float CCZ, float CircleRadius, float FCX, float FCY, float FCZ, float FDX, float FDY, float FDZ, float FDW, float FSX, float FSY, float FSZ, float HeightDifference = 600.0f);
	static bool CheckCircleIntersectFan2D(const FVector& CircleCenter, float CircleRadius, const FVector& InFanCenter, const FRotator& InFanDir, const FVector& FanSize, float HeightDifference = 600.0f);

	// 判断球体与长方体相交
	UFUNCTION(BlueprintCallable, Category = "Math")
	static bool CheckSphereIntersectBox(const FVector& SphereCenter, float SphereRadius, const FVector& InBoxCenter, const FRotator& InBoxDirection, const FVector& BoxSize);

	// 组合两个欧拉角
	UFUNCTION(BlueprintCallable, Category = "Math")
	static void ComposeRotators(float R1, float P1, float Y1, float R2, float P2, float Y2, float& R, float& P, float& Y);

	// 组合两个欧拉角返回四元数
	UFUNCTION(BlueprintCallable, Category = "Math")
	static void ComposeRotatorsQ(float R1, float P1, float Y1, float R2, float P2, float Y2, float& X, float& Y, float& Z, float& W);

	// 点到长方体的距离
	UFUNCTION(BlueprintCallable, Category = "Math")
	static float PointToBoxDistance(const FVector& InPoint, const FTransform& InBoxTransform, const FVector& InBoxHalfSize);

	// 生成二分查找序列
	UFUNCTION(BlueprintCallable, Category = "Math")
	static void BuildBSTSequence(int32 Start, int32 End, bool bLeftPriority, TArray<int32>& Result);

#pragma endregion Math


#pragma region Actor

public:
	// 获取角色位置
	UFUNCTION(BlueprintCallable, Category = "Actor")
	static void GetActorLocation_P(AActor* InActor, bool bRelation, float& X, float& Y, float& Z);

	// 设置角色位置
	UFUNCTION(BlueprintCallable, Category = "Actor")
	static void SetActorLocation_P(AActor* InActor, bool bRelation, float X, float Y, float Z);

	// 获取角色朝向
	UFUNCTION(BlueprintCallable, Category = "Actor")
	static void GetActorRotation_P(AActor* InActor, bool bRelation, float& Roll, float& Pitch, float& Yaw);

	// 设置角色朝向
	UFUNCTION(BlueprintCallable, Category = "Actor")
	static void SetActorRotation_P(AActor* InActor, bool bRelation, float Roll, float Pitch, float Yaw);

	// 获取角色的坐标变换
	UFUNCTION(BlueprintCallable, Category = "Actor")
	static void GetActorTransform_P(AActor* InActor, bool bRelation, float& LX, float& LY, float& LZ, float& RX, float& RY, float& RZ, float& RW, float& SX, float& SY, float& SZ);

	// 设置角色的坐标变换
	UFUNCTION(BlueprintCallable, Category = "Actor")
	static void SetActorTransform_P(AActor* InActor, bool bRelation, float LX, float LY, float LZ, float RX, float RY, float RZ, float RW, float SX, float SY, float SZ);

	// 获取角色前向量
	UFUNCTION(BlueprintCallable, Category = "Actor")
	static void GetActorForward_P(AActor* InActor, float& X, float& Y, float& Z);

	// 将角色挂载到某个组件
	UFUNCTION(BlueprintCallable, Category = "Actor")
	static void ActorAttachToComponent_P(AActor* InActor, USceneComponent* InComponent, const FString& InSocketName);

#pragma endregion Actor


#pragma region Component

public:
	// 获取组件位置
	UFUNCTION(BlueprintCallable, Category = "Component")
	static void GetComponentLocation_P(USceneComponent* InComponent, bool bRelation, float& X, float& Y, float& Z);

	// 设置组件朝向
	UFUNCTION(BlueprintCallable, Category = "Component")
	static void SetComponentRotation_P(USceneComponent* InComponent, bool bRelation, float Roll, float Pitch, float Yaw);

	// 获取组件的坐标变换
	UFUNCTION(BlueprintCallable, Category = "Component")
	static void GetComponentTransform_P(USceneComponent* InComponent, bool bRelation, float& LX, float& LY, float& LZ, float& RX, float& RY, float& RZ, float& RW, float& SX, float& SY, float& SZ);

	// 获取组件上向量
	UFUNCTION(BlueprintCallable, Category = "Component")
	static void GetComponentUp_P(USceneComponent* InComponent, float& X, float& Y, float& Z);

#pragma endregion Component


#pragma region Material

public:
	UFUNCTION(BlueprintCallable, Category = "Material")
	static void SetMIDScalarParameter_P(class UMaterialInstanceDynamic* InMID, const FName& InName, float InValue);

	UFUNCTION(BlueprintCallable, Category = "Material")
	static void SetMIDVectorParameter_P(class UMaterialInstanceDynamic* InMID, const FName& InName, float InX, float InY, float InZ, float InW);

	UFUNCTION(BlueprintCallable, Category = "Material")
	static void SetMIDTextureParameter_P(class UMaterialInstanceDynamic* InMID, const FName& InName, class UTexture* InTexture);

#pragma endregion Material


#pragma region GameplayOptimization
	// C++直接创建的附属Actor, 武器、占卜家卡牌
	UFUNCTION(BlueprintCallable, Category = "GameplayOptimization")
	static void EnableActorOptimizationForWithoutComposite(AActor * Actor, const bool& bEnable);
	
	// C++直接创建的附属Component, 例如占卜家前面的单独卡牌
	UFUNCTION(BlueprintCallable, Category = "GameplayOptimization")
	static void EnablePrimitiveComponentOptimization(UPrimitiveComponent * Prim, const bool& bEnable, const bool& bControlUseParentBound=true);
	
	UFUNCTION(BlueprintCallable, Category = "GameplayOptimization")
	static void EnableSKMeshOptimization(class USkeletalMeshComponent* InSkCom, const bool& bEnable);
	
	UFUNCTION(BlueprintCallable, Category = "GameplayOptimization")
	static void EnableAnimTickOptimization(class USkeletalMeshComponent* InSkCom, const bool& bEnable);

	UFUNCTION(BlueprintCallable, Category = "GameplayOptimization")
	static void EnableOverlapOptimization(class USceneComponent *SceneComponent, const bool& bEnable);
	
	UFUNCTION(BlueprintCallable, Category = "GameplayOptimization")
	static void EnableOverlapOptimizationWithActor(class AActor *Actor, const bool& bEnable);
	
#pragma endregion GameplayOptimization 
	

#pragma region File

public:
	UFUNCTION(BlueprintCallable, Category = "File")
	static void FetchAllFiles(const FString& InFoldPath, TArray<FString>& OutFiles);

#pragma endregion File

};
