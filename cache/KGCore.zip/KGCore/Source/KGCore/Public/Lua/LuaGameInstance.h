#pragma once

#include "CoreMinimal.h"

#include "slua.h"
#include "LuaOverriderInterface.h"

#include "LuaGameInstance.generated.h"

class ULuaEnvBase;

UCLASS(BlueprintType, Blueprintable)
class KGCORE_API UCommonLuaGameInstanceBase : public UObject, public ILuaOverriderInterface
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable)
    void CacheManager(class UKGBasicManager* InManager);

    void SetLuaEnv(ULuaEnvBase *Env) { LuaEnv = Env; }
    lua_State *GetLuaState() const;

protected:
    bool bIsActive = false;

private:
    TWeakObjectPtr<ULuaEnvBase> LuaEnv = nullptr;
};

UCLASS(BlueprintType, Blueprintable)
class KGCORE_API ULuaGameInstance : public UCommonLuaGameInstanceBase
{
    GENERATED_BODY()

public:
    void Init(class UGameInstance *InUEGameInstance);
    void Uninit();

    /// lua events begin
    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaPatchBegin(class UGameInstance *InGI);

    void BeginPlay(class UGameInstance *InGI);
    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaBegin(class UGameInstance *InGI);

    void EndPlay();
    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaEnd();

    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaMapLoaded(const FString &InMapName);

    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaMapReady(UWorld *World, const FString &InMapName);

    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaLoadMapError(const FString &InErrorMsg);

	UFUNCTION(BlueprintImplementableEvent)
    void OnWorldBeginTearDown(UWorld* InWorld);

    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaHotPatchFlowEnd(int32 InMapId);

    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaMemoryLowWarning();

    UFUNCTION(BlueprintImplementableEvent)
    void OnObjectCountNearlyExceed(int32 CurrentObjectCount);

    // Lv=0的时候表示普通的Cell（即64米的Cell），大于0的表示的是比较大的Cell
    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaWpCellLoaded(UWorld *World, bool Added, int X, int Y, int Lv, FBox &Bounds);

    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaExecGM(const FString &Cmd);

    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaShowGM();

    UFUNCTION(BlueprintImplementableEvent)
    void ApplicationWillEnterBackground();

    UFUNCTION(BlueprintImplementableEvent)
    void ApplicationHasEnteredForeground();

    UFUNCTION(BlueprintImplementableEvent)
    void OnWindowForceChanged(bool bDeactivate, bool bWindowMinimized);

    UFUNCTION(BlueprintImplementableEvent)
    bool OnWindowCloseRequested();
    // lua evnets end

private:
    UPROPERTY(Transient)
    class UKGGameInstanceBase *EngineGameInstance = nullptr;
};


UCLASS(BlueprintType, Blueprintable)
class KGCORE_API ULaunchLuaGameInstance : public ULuaGameInstance
{
    GENERATED_BODY()

public:
    virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Launch.LaunchInstance"); }
};

UCLASS(BlueprintType, Blueprintable)
class KGCORE_API UGamePlayLuaGameInstance : public ULuaGameInstance
{
    GENERATED_BODY()

public:
    virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Gameplay.GameEntrance.GameInstance"); }
};

UCLASS(BlueprintType, Blueprintable)
class KGCORE_API UEditorLuaGameInstanceBase : public UCommonLuaGameInstanceBase, public FTickableGameObject
{
    GENERATED_BODY()

public:
    virtual void BeginPlay(UWorld *InWorld);
    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaBegin(UWorld *InWorld);

    virtual void EndPlay();
    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaEnd();
//
public:
    virtual UWorld *GetTickableGameObjectWorld() const override;

    virtual ETickableTickType GetTickableTickType() const override;

    virtual bool IsAllowedToTick() const override;

    virtual TStatId GetStatId() const override;

    virtual void Tick(float DeltaTime) override;

    UFUNCTION(BlueprintImplementableEvent)
    void OnLuaTick(float DeltaTime);
};