#pragma once

#include "slua.h"

KGCORE_API DECLARE_LOG_CATEGORY_EXTERN(LuaLog, Log, All);

namespace LUA_LOG {

enum class LuaLogLevel : uint8_t
{
	DebugLog = 1,
	DebugWarning = 2,
	DebugError = 3,
	Log = 4,
	Warning = 5,
	Error = 6,
	Fatal = 7,
};

void RegisterLuaLogLib(lua_State* L);

}