// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "slua.h"
#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "Misc/CommonDefines.h"
#include "Curves/CurveBase.h"

template<typename T>
struct FullDecay {
	using type = std::remove_pointer_t<std::decay_t<T>>;
};

template<typename T>
using FullDecay_t = typename FullDecay<T>::type;

template<typename T>
struct IsUObjectLike {
	static constexpr bool value = std::is_base_of_v<UObject, FullDecay_t<T>> && !std::is_base_of_v<UCurveBase, FullDecay_t<T>> && !std::is_base_of_v<UClass, FullDecay_t<T>>;
};

template<>
struct IsUObjectLike<lua_State> {
	static constexpr bool value = false;
};

template<typename T>
struct IsUObjectLike<TArray<T>> {
	static constexpr bool value = IsUObjectLike<T>::value;
};

template<typename T>
struct IsUObjectLike<TSet<T>> {
	static constexpr bool value = IsUObjectLike<T>::value;
};

template<typename T, typename K>
struct IsUObjectLike<TMap<K, T>> {
	static constexpr bool value = IsUObjectLike<T>::value;
};

template<typename T>
struct HasUObjectArg : std::false_type {};

template<typename T, typename Ret, typename... Args>
struct HasUObjectArg< Ret(T::*)(Args...)> {
	static constexpr bool value = (IsUObjectLike<FullDecay_t<Ret>>::value) || (IsUObjectLike<FullDecay_t<Args>>::value || ...);
};

template<typename T, typename Ret, typename... Args>
struct HasUObjectArg< Ret(T::*)(Args...) const> {
	static constexpr bool value = (IsUObjectLike<FullDecay_t<Ret>>::value) || (IsUObjectLike<FullDecay_t<Args>>::value || ...);
};

template<typename Ret, typename... Args>
struct HasUObjectArg<Ret(*)(Args...)> {
	static constexpr bool value = (IsUObjectLike<FullDecay_t<Ret>>::value) || (IsUObjectLike<FullDecay_t<Args>>::value || ...);
};


#define REG_MANAGER_FUNC(U,N,M) { \
    using BindType = LuaCppBinding<decltype(M),M>; \
	static_assert(!HasUObjectArg<decltype(M)>::value);     \
    LuaObject::addExtensionMethod(U::StaticClass(),N,BindType::LuaCFunction, BindType::IsStatic);  \
}

class KGCORE_API KGLuaObjectBase {
public:
	KGLuaObjectBase() = default;
	virtual ~KGLuaObjectBase() {}

	int BindLuaObject(lua_State* L, int idx);
	void UnbindLuaObject();
	void RefSelf(lua_State* L, int idx);
	void UnrefSelf(lua_State* L);

	NS_SLUA::LuaVar& GetSelfTable() { return SelfTable; }

	template<class ...ARGS>
	void CallLuaFunction(const FString& FunctionName, ARGS&& ...Args) {
		const auto Buff = StringCast<ANSICHAR>(*FunctionName);
		CallLuaFunction<void>(Buff.Get(), std::forward<ARGS>(Args)...);
	}

	template<class ...ARGS>
	void CallLuaFunction(const char *FunctionName, ARGS&& ...Args) {
		CallLuaFunction<void>(FunctionName, std::forward<ARGS>(Args)...);
	}

	template<class RET, class ...ARGS>
	RET CallLuaFunction(const FString& FunctionName, ARGS&& ...Args) {
		const auto Buff = StringCast<ANSICHAR>(*FunctionName);
		return CallLuaFunction(Buff.Get(), std::forward<ARGS>(Args)...);
	}

	template<class RET, class ...ARGS>
	RET CallLuaFunction(const char *FunctionName, ARGS&& ...Args) {
		static constexpr bool HasUObject = (IsUObjectLike<RET>::value) || (IsUObjectLike<ARGS>::value || ...);
		static_assert(!HasUObject);

		if (!SelfTable.isValid()) {
			NS_SLUA::Log::Error("Lua Object not assign to KGLuaObject");
			return RET();
		}

		
		NS_SLUA::LuaState *State = NS_SLUA::LuaState::get(SelfTable.getStateIndex());
		lua_State *L = State->getLuaState();
		NS_SLUA::AutoStack as(L);

		auto ArgsTuple = std::make_tuple(std::forward<ARGS>(Args)...);
		using Argslist = decltype(ArgsTuple);
		using UdType = std::tuple<KGLuaObjectBase*, const char*, Argslist>;
		UdType ud(this, FunctionName, ArgsTuple);
		auto f = [](lua_State* L)
			{
				UdType* ud = static_cast<UdType*>(lua_touserdata(L, 1));

				const char *FunctionName = std::get<1>(*ud);
				NS_SLUA::FLuaObjectContext LuaContext(L, FunctionName);
				int n = std::get<0>(*ud)->Dispatch(FunctionName, std::get<2>(*ud), std::make_index_sequence<std::tuple_size_v<Argslist>>{});
				return n;
			};

		int OldTop = lua_gettop(L);
		State->pushCFuncWrpper(L);
		lua_pushlightuserdata(L, &ud);
		lua_pushlightuserdata(L, reinterpret_cast<void *>(static_cast<lua_CFunction>(f)));
		int Result = lua_pcall(L, 2, LUA_MULTRET, 0);
		if (Result != LUA_OK)
		{
			if (lua_isstring(L, -1))
			{
				const char* error_msg = lua_tostring(L, -1);
				UE_LOG(LogTemp, Error, TEXT("CallLuaFunction failed. function=%s, error=%hs"), ANSI_TO_TCHAR(FunctionName), error_msg);
			}
			return RET();
		}

		int Nret = lua_gettop(L) - OldTop;
		auto Ret = WrapReturn(L, Nret);
		if (Ret.isValid()) {
			return Ret.template castTo<RET>();
		}
		else {
			return RET();
		}

		return RET();
	}

	NS_SLUA::LuaVar WrapReturn(lua_State* L, int n) {
		ensure(n >= 0);
		if (n == 0)
			return NS_SLUA::LuaVar();
		else if (n == 1)
			return NS_SLUA::LuaVar(L, -1);
		else
			return NS_SLUA::LuaVar(L, n);
	}


	template <typename ArgsList, std::size_t... Inx>
	int Dispatch(const char* FunctionName, ArgsList&& args, std::index_sequence<Inx...>)
	{
		return DoCallLuaFunction(FunctionName, std::get<Inx>(args)...);
	}

	template<class ...ARGS>
	int DoCallLuaFunction(const char* FunctionName, ARGS&& ...Args) {
		auto L = SelfTable.getState();
		SelfTable.push(L);
		lua_pushstring(L, FunctionName);
		lua_gettable(L, -2);
		if (!lua_isfunction(L, -1)) {
			return 0;
		}

		auto funcVal = NS_SLUA::LuaVar(L, lua_gettop(L));
		return funcVal.call_ex(SelfTable, std::forward<ARGS>(Args)...);
	}

private:
	NS_SLUA::LuaVar SelfTable;
	int SelfRef = LUA_NOREF;
};

#define REG_LUA_OBJECT_BIND_FUNC(NAME)									\
	using namespace NS_SLUA;											\
	REG_EXTENSION_METHOD_IMP(NAME, "BindLuaObject", {					\
	CheckUD(NAME, L, 1);												\
	if (!UD) { return luaL_error(L, "Arg 1 expect %s", #NAME); }		\
	return UD->BindLuaObject(L, 2);										\
	});

class KGLuaObjectUtils
{
public:
	template<class T>
	static int push(lua_State* L, const char* fn, const T* v)
	{
		NS_SLUA::LuaObject::push(L, fn, v);
		return 1;
	}

	template<class T>
	static int pushWithAutoGC(lua_State* L, const char* fn, const T* v)
	{
		NS_SLUA::LuaObject::push(L, fn, v, UD_AUTOGC);
		return 1;
	}

	/**
	 * 将 TArray<T> 填充到 Lua table 中（清空旧数据 + 填充新数据）
	 * @param L Lua 状态
	 * @param tableIdx table 在栈上的位置
	 * @param Array 要填充的 C++ 数组
	 * @return 填充的元素数量
	 */
	template<typename T>
	static int FillLuaTableFromArray(lua_State* L, int tableIdx, const TArray<T>& Array)
	{
		// 获取旧长度用于清理
		int oldLen = (int)lua_objlen(L, tableIdx);
		int newLen = Array.Num();

		// 填入新数据
		for (int32 i = 0; i < newLen; ++i)
		{
			lua_pushinteger(L, i + 1);  // key (Lua 数组从 1 开始)
			NS_SLUA::LuaObject::push(L, Array[i]);  // value (自动根据类型 push)
			lua_rawset(L, tableIdx);
		}

		// 清理多余的旧元素
		for (int i = newLen + 1; i <= oldLen; ++i)
		{
			lua_pushinteger(L, i);
			lua_pushnil(L);
			lua_rawset(L, tableIdx);
		}

		return newLen;
	}
};

class KGCORE_API LuaEntityBase : public KGLuaObjectBase
{
public:
	LuaEntityBase() = default;
	LuaEntityBase(KGEntityID EntID) : EntID(EntID) {}
	virtual ~LuaEntityBase() {}

	virtual bool InitLua(lua_State* L);
	virtual void FiniLua(lua_State* L);

	// Created By User, Destroy By User
	virtual void BindActorByOwnSpawned(AActor* InActor);

	// Create By Level Load, Destry By Level Unload
	// Do not Destroy The Actor Mannully
	virtual void BindActorByLevelSpawned(AActor* InActor);
	virtual void UnbindActor();
	void BindActor(KGObjectID ActorID);

	KGEntityID GetEntityID() { return EntID; }
	AActor* GetActor();

	KGActorID GetActorID() { return ActorID; }
protected:
	KGEntityID EntID = KG_INVALID_ENTITY_ID;
	KGObjectID ActorID = KG_INVALID_ACTOR_ID;
	TWeakObjectPtr<AActor> Actor;
};

