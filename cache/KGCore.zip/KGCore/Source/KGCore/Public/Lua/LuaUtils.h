#pragma once

#include "CoreMinimal.h"
#include "slua.h"


class KGCORE_API LuaTools
{
public:
	static void DumpLuaStack(lua_State* L);
	// 为了避免FName膨胀，这里用FString，同时如果参数是FString的话，FName->FString也有内存消耗
	// 由于FName内部有优化，因此参数是FName，多次传递相同的字符串，也不存在内存分配问题
	static TMap<FString, int64> RuntimeStr2IdMap;
	static TMap<int64, FString> RuntimeId2StrMap;
	static int64 CurRuntimeStrId;
	static int64 GetRuntimeStrId(const FString& str);
	static const FString& GetStrById(int64 strId);
};