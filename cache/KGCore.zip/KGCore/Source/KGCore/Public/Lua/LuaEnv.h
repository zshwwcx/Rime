#pragma once

#include "CoreMinimal.h"

#include "slua.h"
#include "Misc/CommonDefines.h"
#include "Lua/LuaGameInstance.h"

#include "LuaEnv.generated.h"

class UKGBasicManager;
class UEditorLuaGameInstanceBase;

UCLASS()
class KGCORE_API ULuaEnvBase : public UObject
{
    GENERATED_BODY()

public:
    virtual void Start() {}

    lua_State *GetLuaState();

    void RegManager(UKGBasicManager *InManager);

    UKGBasicManager *GetManagerByType(EManagerType InType);

	static TArray<uint8> LoadLuaFileDelegate(const char *fn, FString &filepath);

protected:
    void CreateLuaState(const char* name, class UGameInstance *InGI = nullptr);
    void CloseLuaState();

protected:
    bool bIsActive = false;
    NS_SLUA::LuaState *LuaState = nullptr;	
    FString LuaStateName = "";

    UPROPERTY(Transient)
    TArray<UKGBasicManager *> Managers;
};

UCLASS()
class KGCORE_API ULuaEnv : public ULuaEnvBase
{
    GENERATED_BODY()

public:
    void Init(class UGameInstance *InGI);
    void Uninit();


	void ChangeInstanceToGamePlay();

	void Start() override;

	class ULuaGameInstance *GetLuaGameInstance() { return LuaGI; }

	static ULuaEnv *CreateLuaEnv(class UGameInstance *InGI);
    static void DestroyLuaEnv(ULuaEnv* Env);

private:
    TWeakObjectPtr<UGameInstance> GI = nullptr;

	UPROPERTY(Transient)
    class ULuaGameInstance *LuaGI = nullptr;
};


UCLASS()
class KGCORE_API UEditorLuaEnv : public ULuaEnvBase
{
    GENERATED_BODY()

public:
    void Init(UWorld *InWorld, UClass *InLuaGIClass, UGameInstance *InGameInstance = nullptr);
    void Uninit();

    UEditorLuaGameInstanceBase *GetLuaGameInstance() { return LuaGI; }

	static UEditorLuaEnv *CreateLuaEnv(UWorld *InWorld, UClass *InLuaGIClass, UGameInstance *InGameInstance = nullptr);
    static UEditorLuaEnv *CreateLuaEnv(UClass *InLuaGIClass = nullptr);
    static void DestroyLuaEnv(UEditorLuaEnv *Env);
	static UEditorLuaEnv *GetLuaEnv(UObject *InWorldContext);
    static UEditorLuaGameInstanceBase *GetLuaGameInstance(UObject *InWorldContext);

private:
    void InitLua(UClass *InLuaGIClass = nullptr, UGameInstance *InGameInstance = nullptr);

private:
    bool bCreateWorld = false;

    TWeakObjectPtr<UWorld> World = nullptr;

	UPROPERTY(Transient)
    class UEditorLuaGameInstanceBase *LuaGI = nullptr;

private:
    static inline int32 SLuaStateIndex = 1;
    static TArray<TWeakObjectPtr<class UEditorLuaEnv>> LuaEnvs;
};