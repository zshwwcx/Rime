#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "LuaOverriderInterface.h"

#include "Manager/KGBasicManager.h"

#include "LocalizationManager.generated.h"



UCLASS(Blueprintable, BlueprintType)
class KGCORE_API ULocalizationManager : public UKGBasicManager
{
	GENERATED_BODY()

#pragma region Important
public:
	static ULocalizationManager* GetInstance(UObject* InContext);

	void NativeInit() override;

	virtual EManagerType GetManagerType() { return EManagerType::EMT_LocalizationManager; }

#pragma endregion Important



#pragma region Wwise
public:
	UFUNCTION(BlueprintCallable)
	void ChangeCurrentWwiseCulture(const FString& NewCultureName);

	UFUNCTION()
	void OnChangedWwiseCulture(bool Result);

#pragma endregion Wwise

};