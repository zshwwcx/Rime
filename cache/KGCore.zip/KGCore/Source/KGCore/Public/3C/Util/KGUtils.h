#pragma once
#include "CoreMinimal.h"
#include "Misc/CommonDefines.h"


class KGCORE_API KGUtils
{
public:
	static KGObjectID GetIDByObject(UObject* InObj);
	static UObject* GetObjectByID(KGObjectID InID);
	static AActor* GetActorByID(KGObjectID InID);

	static KGObjectID GetIDByClass(UClass* InClass);
	static UClass* GetClassByID(KGObjectID InID);

	template <typename T>
	static T* GetObjectByID(KGObjectID InID) 
	{
		UObject* obj = GetObjectByID(InID);
		return Cast<T>(obj);
	}
};
