#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "UObject/SoftObjectPath.h"
#include "3CSettingsBase.generated.h"


UCLASS(Config = Game, meta = (DisplayName = "3CSettingsBase"), DefaultConfig, Abstract)
class KGCORE_API U3CSettingsBase : public UDeveloperSettings
{
	GENERATED_BODY()
public:

	//开启Npc调试
	UPROPERTY(EditAnywhere, Config, Category = "Debug")
	bool bEnableNpcDebug = true;

	//最大跳跃限制高度
	UPROPERTY(EditAnywhere, Config, Category = "Vox")
	float MaxLimitJumpHeight = 260;
};

