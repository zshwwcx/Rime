﻿#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "KGActorUtil.generated.h"

class ACharacter;
class UActorComponent;

// 由于当前引擎的Actor/Component本身有一些属性并没有暴露出来给脚本层直接使用，这里仅能添加Actor/Component对应的属性Get或者Set接口

UCLASS(Blueprintable)
class KGCORE_API UKGActorUtil : public UObject
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	static bool IsActorHidden(AActor* Actor);

	UFUNCTION(BlueprintCallable)
	static USkeletalMeshComponent* GetCharacterMesh(ACharacter* Character);
	
	UFUNCTION(BlueprintCallable)
	static USceneComponent* GetComponentByNameAndClass(AActor* InActor, const FName& InName, UClass* InClass = nullptr, bool bNoChild = false);

	UFUNCTION(BlueprintCallable)
	static USceneComponent* GetComponentBySocket(AActor* InActor, const FName& InSocket, bool bNoChild = false);

	UFUNCTION(BlueprintCallable)
	static TArray<UActorComponent*> GetComponentsByClasses(AActor* InActor, const TArray<UClass*>& InValidClasses, bool bIncludeChildActors = false);

	// 避免直接操作FTransform
	UFUNCTION(BlueprintCallable)
	static void SetActorTransform(
		AActor* InActor,
		float LocX, float LocY, float LocZ,
		float RotX, float RotY, float RotZ, float RotW,
		float ScaleX, float ScaleY, float ScaleZ);

	UFUNCTION(BlueprintCallable)
	static void AddInstanceComponent(AActor* Actor, UActorComponent* Component);

	UFUNCTION(BlueprintCallable)
	void AddActorTag(AActor* Actor, FName InTag, bool bAddIfNotExist);
	
	static FVector V2GetActorBottomLocation(AActor* InActor, bool bRelation = false);
};
