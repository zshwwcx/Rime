#pragma once
#include "CoreMinimal.h"

#include "KGCurveUtil.generated.h"

class UCurveTable;

UCLASS(Blueprintable)
class KGCORE_API UKGCurveUtil : public UObject
{
	GENERATED_BODY()

	UFUNCTION(BlueprintCallable)
	static bool GetRichCurveTableValues(UCurveTable* CurveTable, float InTime, TMap<FName, float>& OutValues);

	UFUNCTION(BlueprintCallable)
	static bool GetSimpleCurveTableValues(UCurveTable* CurveTable, float InTime, TMap<FName, float>& OutValues);

	UFUNCTION(BlueprintCallable)
	static bool GetRichCurveTableValue(UCurveTable* CurveTable, float InTime, FName ParamName, float& OutValue);

	UFUNCTION(BlueprintCallable)
	static bool GetSimpleCurveTableValue(UCurveTable* CurveTable, float InTime, FName ParamName, float& OutValue);
};

