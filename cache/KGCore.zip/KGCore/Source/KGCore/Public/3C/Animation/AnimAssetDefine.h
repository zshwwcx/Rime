#pragma once

#include "CoreMinimal.h"
#if WITH_EDITOR
#include "IPropertyUtilities.h"
#endif
#include "Engine/GameInstance.h"
#include "reflection/CppReflectionMarco.h"
#include "AnimAssetDefine.generated.h"

UENUM()
enum class EAnimLibViewMode : uint8
{
	None,
	NPCLib,
	PlayerLib,
	MonsterLib,
	AnimalLib,
	BeHitLib,
	AttachItemLib
};


USTRUCT(BlueprintType)
struct KGCORE_API FAnimLibAssetID
{
	GENERATED_BODY()
	FAnimLibAssetID() {};

	FAnimLibAssetID(FString InID)
		:AssetID(InID), StateName(TEXT(""))
	{};
	
	FAnimLibAssetID(FString InID, FString InStateName)
	:AssetID(InID), StateName(InStateName)
	{};

	FORCEINLINE bool operator==(const FAnimLibAssetID& Other)
	{
		return Other.GetID() == AssetID && Other.GetState() == StateName;
	}

	friend inline bool operator==(const FAnimLibAssetID& A, const FAnimLibAssetID& B)
	{
		return A.AssetID == B.AssetID && A.StateName == B.StateName;
	}

	friend inline uint32 GetTypeHash(const FAnimLibAssetID& Key)
	{
		uint32 Hash = 0;
		Hash = HashCombine(Hash, GetTypeHash(Key.AssetID));
		Hash = HashCombine(Hash, GetTypeHash(Key.StateName));
		return Hash;
	}

	inline void SetAnimID(const FString& InAnimID)
	{
		if(!AnimID.Equals(InAnimID))
		{
			AnimID = InAnimID;
#if WITH_EDITOR
			if(PropertyUtilities.IsValid())
			{
				PropertyUtilities.Pin()->RequestForceRefresh();
			}
#endif
		}
	}

	inline void SetAssetID(const FString& InAssetID)
	{
		if (!AssetID.Equals(InAssetID))
		{
			AssetID = InAssetID;
#if WITH_EDITOR
			if(PropertyUtilities.IsValid())
			{
				PropertyUtilities.Pin()->RequestForceRefresh();
			}
#endif
		}
	}

	inline FString GetAnimID() const
	{
		return AnimID;
	}

#if WITH_EDITOR
	inline void SetPropertyUtilities(const TSharedPtr<IPropertyUtilities>& InIPropertyUtilities)
	{
		PropertyUtilities = InIPropertyUtilities;
	}
#endif

public:
	KG_ATTR(nohotfix) FString GetID()const { return AssetID; }
	KG_ATTR(nohotfix) FString GetState()const { return StateName; }

	KG_ATTR(nohotfix) FName GetNameID() const { return FName(AssetID); }
	KG_ATTR(nohotfix) FName GetNameState() const { return FName(StateName); }

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FString AssetID;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FString StateName = TEXT("");

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FString AnimID = TEXT("");

private:
#if WITH_EDITOR
	TWeakPtr<IPropertyUtilities> PropertyUtilities;
#endif
};