#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "GameFramework/Actor.h"
#include "C7ActorInterface.generated.h"

UINTERFACE(MinimalAPI, Blueprintable)
class UC7ActorInterface : public UInterface
{
	GENERATED_BODY()
};

// 注意: 不要给数据, 否则有可能会增加对象布局的内存(特别是菱形继承)
class KGCORE_API IC7ActorInterface
{
	GENERATED_BODY()

public:
	/**
	 * @return 不重写此函数的派生类则直接返回nullptr
	 */
	virtual class USkeletalMeshComponent* GetMainMesh();

	/**
	 * @return 不重写此函数的派生类则直接返回nullptr
	 */
	virtual class UCapsuleComponent* GetCapsule();

	/**
	 * 设置Actor的唯一ID,业务层使用的Actor必须重载此接口
	 * @param InEntityUID 
	 */
	virtual void SetEntityUID(int64 InEntityUID) {}

	/**
	 * 获取Actor的唯一ID,业务层使用的Actor必须重载此接口
	 * @return 
	 */
	virtual int64 GetEntityUID() { return 0; }


	virtual bool GetVirtualSocketLocation(const int64& SocketID, FVector& OutLocation) { return false; }

	bool DoSetCollisionPresetForRootAndMeshComponents(AActor* actor, bool updatedateOverlaps, const FName& SceneRoorPresetName, const FName& ChildPresetName);

	void DoSetMinLOD(AActor* actor, int32 InNewMinLOD);
	
	void DoSetTagFromRootAndMeshComps(AActor* InActor, const FString& InTag);
	
	virtual bool AddAttachToLogicParent(IC7ActorInterface* ParentActor);
	virtual bool AddAttachToLogicParent(int64 parentLogicId);
	virtual bool RemoveAttachFromLogicParent();
	
	virtual void RemoveAllLogicChild();

	virtual bool EnableLogicFeatureSynchronizeToChilds(int64 logicChildID, int32 stateMask);
	virtual bool DisableLogicFeatureSynchronizeToChilds(int64 logicChildID, int32 stateMask);
	virtual bool IsLogicFeatureSynchronizeToChilds(int64 logicChildID, int32 stateMask);
	virtual bool IsLogicFeatureSynchronizeToChilds(AActor * actor, int32 stateMask);

	void ForEachLogicChildDoLogicSynchronize(int32 logicStateMask, TFunctionRef<void(IC7ActorInterface*)> Operation);

	virtual bool HasLogicChild(IC7ActorInterface * childActor);
	virtual bool HasLogicChild(int64);
	virtual int64 GetLoigcParent() { return 0; }
	virtual TMap<int64, int32>* GetLogicChildMaskMap() { return nullptr; }
	
	virtual bool IsBriefActor() { return false;};
	virtual const FTransform* GetBriefActorTransform() const { return nullptr;}
	
	virtual void SyncVisibilityFromParent(bool bVisible) {}
	
protected:

	virtual int64* GetLoigcParentInnerForModify() { return nullptr; }
};
