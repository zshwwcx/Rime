#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"

#include "RoleLogicComponent.generated.h"

//角色逻辑组件基类
UCLASS(Blueprintable, BlueprintType, ClassGroup = (RoleLogic), meta = (BlueprintSpawnableComponent))
class KGCORE_API URoleLogicComponent : public UActorComponent
{
	GENERATED_UCLASS_BODY()

};
