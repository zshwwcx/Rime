#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "3C/Core/C7ActorInterface.h"
#include "BaseCharacterInternal.generated.h"



UCLASS(BlueprintType, Blueprintable, Abstract)
class KGCORE_API ABaseCharacterInternal : public ACharacter, public IC7ActorInterface
{
	GENERATED_BODY()
	
public:

	virtual void BeginPlay() override;

	virtual UActorComponent* RegisterComponentByClassInternal(const TSubclassOf<UActorComponent> ComponentClass, FName Tag = NAME_None)
	{ 
		return nullptr;
	}

	UFUNCTION(BlueprintCallable)
	bool SetCollisionPresetForRootAndMeshComponents(bool updatedateOverlaps, const FName& SceneRoorPresetName, const FName& ChildPresetName);

	UFUNCTION(BlueprintCallable)
    void SetMinLOD(int32 InNewMinLOD);

	UFUNCTION(BlueprintCallable)
	class USkeletalMeshComponent* GetMainMesh() override;

	UFUNCTION(BlueprintCallable)
	class UCapsuleComponent* GetCapsule() override;

	UFUNCTION(BlueprintCallable)
	class UCharacterMovementComponent* GetCharacterMoveComp();

	UFUNCTION(Blueprintable)
	bool EnableLogicFeatureSynchronizeToChildsExposed(int64 logicChildID, int32 stateMask) { return EnableLogicFeatureSynchronizeToChilds(logicChildID, stateMask); }

	UFUNCTION(Blueprintable)
	bool DisableLogicFeatureSynchronizeToChildsExposed(int64 logicChildID, int32 stateMask) { return DisableLogicFeatureSynchronizeToChilds(logicChildID, stateMask); }

	UFUNCTION(Blueprintable)
	bool IsLogicFeatureSynchronizeToChildsExposed(int64 logicChildID, int32 stateMask) { return IsLogicFeatureSynchronizeToChilds(logicChildID, stateMask); }

	UFUNCTION(Blueprintable)
	bool HasLogicChildExposed(int64 logicChildId) { return HasLogicChild(logicChildId); }

	UFUNCTION(Blueprintable)
	bool AddAttachToLogicParentExposed(int64 parentLogicId) { return AddAttachToLogicParent(parentLogicId); }

	UFUNCTION(Blueprintable)
	bool RemoveAttachFromLogicParentExposed() { return RemoveAttachFromLogicParent(); }

	UFUNCTION(Blueprintable)
	void RemoveAllLogicChildExposed() { RemoveAllLogicChild(); }
	
	UFUNCTION(Blueprintable)
	bool IsHideOutScreen() {return bHideOutScreen;}

	UFUNCTION(Blueprintable)
	void SetHideOutScreen(bool HideOutScreen) { bHideOutScreen = HideOutScreen; }

	virtual int64 GetLoigcParent() { return LogicParentActorId; }
	virtual TMap<int64, int32>* GetLogicChildMaskMap() { return &LogicChildObjectIdMapping; }
	virtual bool IsInScreen() {return true;}
	
	// MassNPC专用,避免模块循环依赖,先封在这里
	virtual void FinishInteract() {}
	virtual void DoReactingToPlayer() {}
	virtual void FinishReactingToPlayer() {}
	virtual void SetActorHiddenInGame_L(bool bNewHidden) {}
	virtual void StopStateTreeTasks() {}
	virtual void SetCrowdNpcVelocity(bool bSet, float VelocityX, float VelocityY, float VelocityZ) {}
	virtual bool IsCrowdNpc() { return false; }

protected:

	virtual int64* GetLoigcParentInnerForModify() { return &LogicParentActorId; }

	int64 LogicParentActorId = 0;
	// ObjectId: SyncFeatureControlMask
	TMap<int64, int32> LogicChildObjectIdMapping;

	UPROPERTY(EditAnywhere, Category="Base Character")
	bool bHideOutScreen = false;

};
