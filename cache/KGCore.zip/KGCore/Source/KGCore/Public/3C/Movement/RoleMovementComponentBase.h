#pragma once

#include "CoreMinimal.h"
#include "GameFramework/CharacterMovementComponent.h"

#include "RoleMovementComponentBase.generated.h"



UCLASS(Abstract)
class KGCORE_API URoleMovementComponentBase : public UCharacterMovementComponent
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	virtual bool AllowMovement() const;

	UFUNCTION(BlueprintCallable)
	virtual bool AllowRotation() const;



	UFUNCTION(BlueprintCallable)
	virtual bool AllowProactiveMovement() const;

	UFUNCTION(BlueprintCallable)
	virtual bool IsProactiveMoving(bool InCheckRM = true);

	UFUNCTION(BlueprintCallable)
	virtual bool IsValidProactiveMoving(bool InCheckRM = true);



	UFUNCTION(BlueprintCallable)
	virtual bool AllowProactiveRotation() const;




	UFUNCTION(BlueprintCallable)
	virtual bool AllowProactiveJump() const;



	UFUNCTION(BlueprintCallable)
	virtual void ChangeDisableMeshPredict(int64 InSign, bool bDisable);

	UFUNCTION(BlueprintCallable)
	virtual bool AllowMeshPredict() const;



	UFUNCTION(BlueprintCallable)
	virtual void ChangeDisableRootMotionByType(int32 InTypeMask, int64 InSign, bool bDisable);

	UFUNCTION(BlueprintCallable)
	virtual bool AllowRootMotionByTypeMask(int32 InTypeMask) const;



	UFUNCTION(BlueprintCallable, Category = "RootMotion")
	virtual bool IsRunningRootMotion();

	UFUNCTION(BlueprintCallable, Category = "RootMotion")
	virtual bool IsRunningAnimRootMotion();

	UFUNCTION(BlueprintCallable, Category = "RootMotion")
	virtual bool IsRunningRootMotionSource();

};
