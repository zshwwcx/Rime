﻿#pragma once

#include "CoreMinimal.h"
#include "Containers/Union.h"
#include "UObject/StrongObjectPtr.h"
#include "Curves/CurveFloat.h"
#include "Curves/CurveLinearColor.h"
#include "Curves/CurveVector.h"

#include "KGEffectCommon.generated.h"

USTRUCT()
struct KGCORE_API FKGCurveParams
{
	GENERATED_BODY()
	
	FString CurvePath;
	bool bNeedRemap = false;
	float RemapTime = 1.0f;
	bool bLoop = false;
	bool bActivateImmediately = false;
};

USTRUCT(Blueprintable)
struct KGCORE_API FKGScalarRuntimeCurveParams
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FRuntimeFloatCurve RuntimeFloatCurve;

	bool bNeedRemap = true;
	float RemapTime = 1.0f;
	bool bLoop = true;
	bool bActivateImmediately = false;
};

template<typename T>
struct FKGLinearSampleParams
{
	T StartVal;
	T EndVal;
	// todo 下面这两个参数要移出去
	TOptional<T> CurTargetVal;
	TOptional<float> NewDuration;
	float Duration = 1.0f;
	bool bActivateImmediately = false;
};

template struct KGCORE_API FKGLinearSampleParams<float>;
template struct KGCORE_API FKGLinearSampleParams<FLinearColor>;

// 0~BlendInTime, 线性插值从StartVal到EndVal, BlendInTime到 Duration-BlendOutTime, 保持EndVal不变, BlendOutTime到Duration, 线性插值从EndVal到StartVal
// 一方面为了兼容旧数据, 避免生成大量曲线, 另一方面简化配置
template<typename T>
struct FKGLinearBlendInAndBlendOutParams
{
	T StartVal;
	T EndVal;
	float BlendInTime = 0.0f;
	float BlendOutTime = 0.0f;
	float Duration = 0.0f;
	bool bActivateImmediately = false;
};

template struct KGCORE_API FKGLinearBlendInAndBlendOutParams<float>;

template<typename CurveType, typename ValueType>
struct TKGCurveEvalHelper
{
	TKGCurveEvalHelper() = default;
	
	template<typename... Args>
    void InitEvalParams(Args... InArgs)
    {
    	CurveImpl.InitEvalParams(std::forward<Args>(InArgs)...);
    }
	
	template<typename... Args>
	void InitEvalParams(bool bInNeedRemap, float InRemapTime, bool bInEnableLoop, Args... InArgs)
	{
		CurveImpl.InitEvalParams(std::forward<Args>(InArgs)...);
		bEnableLoop = bInEnableLoop;
		
		if (bInNeedRemap)
		{
			if (bCachedTimeRangeDirty)
			{
				if (CurveImpl.GetTimeRange(CachedMinTime, CachedMaxTime))
				{
					bCachedTimeRangeDirty = false;
				}
				else
				{
					UE_LOG(LogTemp, Error, TEXT("GetRemapScale, cannot get float curve time range"));
				}
			}
			
			const float DeltaTime = CachedMaxTime - CachedMinTime;
			if (FMath::IsNearlyZero(DeltaTime))
			{
				UE_LOG(LogTemp, Error, TEXT("GetRemapScale, invalid float curve time range"));
				return;
			}

			if (FMath::IsNearlyZero(InRemapTime))
			{
				UE_LOG(LogTemp, Error, TEXT("GetRemapScale, invalid float curve remap time"));
				return;
			}

			bNeedRemap = true;
			RemapScale = DeltaTime / InRemapTime;
		}
	}
	
	bool IsValid() const
	{
		return CurveImpl.IsValid();
	}
	
	bool GetValue(float InTime, ValueType& OutVal)
	{
		if (!CurveImpl.IsValid())
		{
			return false;
		}

		UpdateEvalInfo(InTime);

		return CurveImpl.GetValue(InTime, OutVal);
	}
	
	bool DoesTimeReachEnd(float InTime)
	{
		if (!CurveImpl.IsValid())
		{
			return false;
		}
		
		if (bEnableLoop)
		{
			return false;
		}

		if (bCachedTimeRangeDirty)
		{
			if (!CurveImpl.GetTimeRange(CachedMinTime, CachedMaxTime))
			{
				return false;
			}
			bCachedTimeRangeDirty = false;
		}

		if (bNeedRemap)
		{
			InTime = InTime * RemapScale;
		}

		return InTime > CachedMaxTime;
	}
	
	void UpdateEvalInfo(float& InOutTime)
	{
		if (!CurveImpl.IsValid())
		{
			return;
		}
		
		if (bCachedTimeRangeDirty)
		{
			if (!CurveImpl.GetTimeRange(CachedMinTime, CachedMaxTime))
			{
				return;
			}
			bCachedTimeRangeDirty = false;
		}
	
		if (bNeedRemap)
		{
			InOutTime = InOutTime * RemapScale;
		}

		if (bEnableLoop)
		{
			const float TimeRange = CachedMaxTime - CachedMinTime;
			if (!FMath::IsNearlyZero(TimeRange, KINDA_SMALL_NUMBER))
			{
				InOutTime = FMath::Fmod(InOutTime, TimeRange) + CachedMinTime;
			}
		}
	
		InOutTime = FMath::Clamp(InOutTime, CachedMinTime, CachedMaxTime);
	}
	
private:
	bool bNeedRemap = false;
	// 这里存放remap scale 避免tick采样多次计算
	float RemapScale = 1.0f;
	bool bEnableLoop = false;
	
	CurveType CurveImpl;
	
	bool bCachedTimeRangeDirty = true;
	float CachedMinTime = 0.0f;
	float CachedMaxTime = 0.0f;
};

struct KGCORE_API FKGCurveImplCurveFloat
{
	FKGCurveImplCurveFloat() = default;
	void InitEvalParams(UCurveFloat* InCurveFloat)
	{
		CurveFloat = TStrongObjectPtr(InCurveFloat);
	}
	bool GetValue(float InTime, float& OutVal) const;
	bool GetTimeRange(float& OutMin, float& OutMax) const;
	bool IsValid() const { return CurveFloat.IsValid(); }
	
	TStrongObjectPtr<UCurveFloat> CurveFloat;
};

struct KGCORE_API FKGCurveImplCurveVector
{
	FKGCurveImplCurveVector() = default;
	void InitEvalParams(UCurveVector* InCurveVector)
	{
		CurveVector = TStrongObjectPtr(InCurveVector);
	}
	bool GetValue(float InTime, FVector& OutVal) const;
	bool GetTimeRange(float& OutMin, float& OutMax) const;
	bool IsValid() const { return CurveVector.IsValid(); }
	
	TStrongObjectPtr<UCurveVector> CurveVector;
};

struct KGCORE_API FKGCurveImplCurveLinearColor
{
	FKGCurveImplCurveLinearColor() = default;
	void InitEvalParams(UCurveLinearColor* InCurveLinearColor)
	{
		CurveLinearColor = TStrongObjectPtr(InCurveLinearColor);
	}
	bool GetValue(float InTime, FLinearColor& OutVal) const;
	bool GetTimeRange(float& OutMin, float& OutMax) const;
	bool IsValid() const { return CurveLinearColor.IsValid(); }
	
	TStrongObjectPtr<UCurveLinearColor> CurveLinearColor;
};

struct KGCORE_API FKGCurveImplRuntimeFloatCurve
{
	FKGCurveImplRuntimeFloatCurve() = default;
	
	void InitEvalParams(const FRuntimeFloatCurve& InRuntimeFloatCurve)
	{
		bHasInit = true;
		ExternalCurve = TStrongObjectPtr(InRuntimeFloatCurve.ExternalCurve.Get());
		RichCurve = InRuntimeFloatCurve.EditorCurveData;
	}
	bool GetValue(float InTime, float& OutVal) const;
	bool GetTimeRange(float& OutMin, float& OutMax) const;
	bool IsValid() const { return bHasInit; }
	
	const FRichCurve* GetRichCurve() const;
	
	// 为了能够不用UPROPERTY标记, 这里单独存储ExternalCurve以及RichCurve数据
	bool bHasInit = false;
	TStrongObjectPtr<UCurveFloat> ExternalCurve;
	FRichCurve RichCurve;
};

template struct KGCORE_API TKGCurveEvalHelper<FKGCurveImplCurveFloat, float>;
typedef TKGCurveEvalHelper<FKGCurveImplCurveFloat, float> FKGCurveFloatEvalHelper;
template struct KGCORE_API TKGCurveEvalHelper<FKGCurveImplCurveVector, FVector>;
typedef TKGCurveEvalHelper<FKGCurveImplCurveVector, FVector> FKGCurveVectorEvalHelper;
template struct KGCORE_API TKGCurveEvalHelper<FKGCurveImplCurveLinearColor, FLinearColor>;
typedef TKGCurveEvalHelper<FKGCurveImplCurveLinearColor, FLinearColor> FKGCurveLinearColorEvalHelper;
template struct KGCORE_API TKGCurveEvalHelper<FKGCurveImplRuntimeFloatCurve, float>;
typedef TKGCurveEvalHelper<FKGCurveImplRuntimeFloatCurve, float> FKGRuntimeCurveFloatEvalHelper;

/**
 * 这里提供remap机制的原因
 * 对于所有技能内配置的task，如果这些task内部引用了curve类型的资产，在配置上希望这些curve资产的时长都是归一化的（横轴坐标都是0到1）
 * 而curve的真实时间总是由技能task的持续时间来定，这样方便策划每次调整task时长后不用频繁去调整curve时长
 *
 * 正常来说，希望是在技能数据导出时自动根据task时长去调整导出的curve资产数据，确保运行时拿到的curve数据本身就是remap过后的，避免运行时
 * 执行额外的remap计算。
 *
 * 但是对于curve来说，纵轴的数据值会受到横轴数据影响，因为对于具体的数据点来说，策划配置的总是数据点的斜率，在斜率不变的情况下，技能curve数据
 * 导出时调整了横轴的数据间隔，相应的纵轴数据值也会变化。
 *
 * 还有一些可能的解决方案包括
 * 1，离线导出时先将curve采样改为折线段再缩放，对于时长较长的curve，可能curve数据失真的问题会比较严重，也会增加curve的
 * 数据量
 *
 * 目前看下来remap的机制运行时的开销并不高（多一次乘法&除法），目前先维持在运行时处理的方案
 */
struct KGCORE_API FKGCurveEvalParams
{
	FKGCurveEvalParams() = default;
	
	void InitEvalParams(UCurveBase* InCurve, bool bInNeedRemap, float InRemapTime, bool bInEnableLoop);
	bool DoesTimeReachEnd(float InTime);
	bool IsValid() const;
	
	bool GetFloatValue(float InTime, float& OutVal);
	bool GetVectorValue(float InTime, FVector& OutVal);
	bool GetLinearColorValue(float InTime, FLinearColor& OutVal);
	
	bool IsFloatCurve() const { return CurveEvalHelper.HasSubtype<FKGCurveFloatEvalHelper>(); }
	
	TUnion<FKGCurveFloatEvalHelper, FKGCurveVectorEvalHelper, FKGCurveLinearColorEvalHelper> CurveEvalHelper;
};
