#pragma once

#include "CoreMinimal.h"
#include "NiagaraEffectType.h"

#include "KGNiagaraSignificanceHandler.generated.h"

/**
 * 这两个handler目前还在用，且引用资源数量比较多，目前先从EffectManager中把原始逻辑挪过来 后续特效优化专项中再看这两个handler是否要做处理
 *
 */

UCLASS(EditInlineNew, meta = (DisplayName = "DistanceToPlayer"))
class KGCORE_API UNSHDistanceToPlayer : public UNiagaraSignificanceHandler
{
	GENERATED_BODY()

public:
	virtual void CalculateSignificance(
		TConstArrayView<class UNiagaraComponent*> Components,
		TArrayView<FNiagaraScalabilityState> OutState,
		TConstArrayView<FNiagaraScalabilitySystemData> SystemData,
		TArray<int32>& OutIndices) override;

};


UCLASS(EditInlineNew, meta = (DisplayName = "DistanceToPlayerWithBound"))
class KGCORE_API UNSHDistanceToPlayerWithBound : public UNiagaraSignificanceHandler
{
	GENERATED_BODY()

public:
	virtual void CalculateSignificance(
		TConstArrayView<class UNiagaraComponent*> Components,
		TArrayView<FNiagaraScalabilityState> OutState,
		TConstArrayView<FNiagaraScalabilitySystemData> SystemData,
		TArray<int32>& OutIndices) override;

};