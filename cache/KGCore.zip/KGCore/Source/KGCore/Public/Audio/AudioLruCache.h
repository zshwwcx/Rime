#pragma once

#include "CoreMinimal.h"
#include "Containers/List.h"
#include "Containers/Map.h"

/**
 * 音频侧定制Lru
 */
class FAudioLruCache
{
public:
	void SetCapacity(int NewCapacity) { Capacity = NewCapacity; }
	bool Update(const FString& Key);
	FString Add(const FString& Key, double Value);
	bool Contains(const FString& Key) const;
	bool Remove(const FString& Key);
	double Size() const;
	void Clear();
	void GetAllKeys(TArray<FString>& OutKeys) const;

private:
	struct CacheNode
	{
		FString Key;
		double Value;
        
		CacheNode(const FString& InKey, double InValue)
			: Key(InKey), Value(InValue) {}
	};
    
	using NodePtr = TSharedPtr<CacheNode>;
	using ListType = TDoubleLinkedList<NodePtr>;
	using ListItr = typename ListType::TDoubleLinkedListNode;
	using MapType = TMap<FString, ListItr*>;
    
	void MoveToFront(ListItr* Node);
	FString RemoveLru();

	// 注意这里的Capacity不是传统意义上的节点数量,而是Bank占用内存的总大小
	double Capacity = 0.f;
	double CurrentSize = 0.f;
	ListType List;
	MapType Map;
};
