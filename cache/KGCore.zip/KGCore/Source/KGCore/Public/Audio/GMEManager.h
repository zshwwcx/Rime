#pragma once
#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"

#ifdef DISABLE_GME
#else
#include "tmg_sdk.h"
#endif

#include "GMEManager.generated.h"

UCLASS(Blueprintable, BlueprintType)
class KGCORE_API UGMEManager : public UKGBasicManager
{
	GENERATED_BODY()

public:

	virtual void NativeInit();
	virtual void NativeUninit();
	virtual EManagerType GetManagerType() { return EManagerType::EMT_GMEManager; }

	static UGMEManager* GetInstance(UObject* InContext)
	{
		return Cast<UGMEManager>(GetManagerByType(InContext, EManagerType::EMT_GMEManager));
	}

	virtual void Tick(float DeltaTime) override;
	virtual void OnPostLoadMapWithWorld(UWorld* World) override;
private:

	
public:
#ifdef DISABLE_GME
#else
	virtual void OnEvent(ITMG_MAIN_EVENT_TYPE eventType, const char* data, int32 channelType);
#endif

	int32 KAPI_InitGME(const FString& SdkAppId,const FString& SdkAppKey,const FString& InUserId,const FString& InUserSig);
	void KAPI_UninitGME();
	void KAPI_EnterRoom(const FString& RoomID, int32 RoomType, int32 ChannelType,const FString&  InUserSig);
	int32 KAPI_ExitRoom(int32 ChannelType = 1);
	int32 KAPI_SetVoiceType(int32 VoiceType, int32 ChannelType);
	int32 KAPI_EnableMic(bool Enable, int32 ChannelType);
	int32 KAPI_EnableAudioCaptureDevice(bool Enable, int32 ChannelType);
	bool KAPI_IsAudioCaptureDeviceEnabled(int32 ChannelType);
	int32 KAPI_EnableAudioSend(bool Enable, int32 ChannelType);
	bool KAPI_IsAudioSendEnabled(int32 ChannelType);
	int32 KAPI_SetScene(int32 scene, int32 ChannelType);
	int32 KAPI_SetAudioRole(int32 role, int32 ChannelType);
	int32 KAPI_SetAdvanceParams(FString key, FString value, int32 ChannelType);
	int32 KAPI_GetMicState(int32 ChannelType);
	int32 KAPI_EnableSpeaker(bool Enable, int32 ChannelType);
	int32 KAPI_StartRecording(FString filePath);
	int32 KAPI_StartRecordingWithStreamingRecognition(FString filePath);
	int32 KAPI_StopRecording();
	int32 KAPI_CancelRecording();
	int32 KAPI_UploadRecordedFile(FString filePath);
	int32 KAPI_DownloadRecordedFile(FString fileId, FString filePath);
	int32 KAPI_PlayRecordedFile(FString filePath);
	int32 KAPI_StopPlayFile();
	int32 KAPI_GetVoiceFileDuration(FString filePath);
	int32 KAPI_SetMaxMessageLength(int32 msTime);
	int32 KAPI_GetMicLevel(int32 ChannelType);
	int32 KAPI_GetMicVolume(int32 ChannelType);
	int32 KAPI_GetSpeakerLevel(int32 ChannelType);
	int32 KAPI_GetSpeakerVolume(int32 ChannelType);
	int32 KAPI_SetMicVolume(int32 volumn, int32 ChannelType);
	int32 KAPI_SetSpeakerVolume(int32 volumn, int32 ChannelType);
	int32 KAPI_AddAudioBlackList(FString OpenID, int32 ChannelType);
	int32 KAPI_RemoveAudioBlackList(FString OpenID, int32 ChannelType);
	int32 KAPI_CreateChannelContext(int32 ChannelType,const FString& InUserSig);
	void KAPI_DestroyChannelContext(int32 ChannelType);
	void KAPI_PauseContext(int32 ChannelType);
	void KAPI_ResumeContext(int32 ChannelType);

	//回调函数
	void OnEnterRoomCompleted(int32 result, const FString& errInfo, int32 channelType);
	void OnExitRoomCompleted(int32 result, const FString& errInfo, int32 channelType);
	void OnEndpointsUpdateInfo(int32 eventID, const FString& identifier, int32 channelType);
	void OnPttRecordFileCompleted(int32 result, const FString& filePath, int32 duration, int32 filesize);
	void OnPttPlayFileCompleted(int32 result, const FString& filePath);
	void OnPttUploadFileCompleted(int32 result, const FString& filePath, const FString& fileID);
	void OnPttDownloadFileCompleted(int32 result, const FString& filePath, const FString& fileID);
	void OnPttSpeech2TextCompleted(int32 result, const FString& fileID, const FString& text);
	void OnPttStreamRecognitionCompleted(int32 result, const FString& filePath, const FString& fileID, const FString& text);
	void OnPttStreamRecognitionisRunning(int32 result, const FString& filePath, const FString& fileID, const FString& text);

private:
	UPROPERTY()
	FString AppId;

	UPROPERTY()
	FString AppKey;

	UPROPERTY()
	FString UserId;

	bool bEnabled = false;

#ifdef DISABLE_GME
#else
	ITMGContext* GetChannelContext(int32 ChannelType);
	ITMGContext* GetOrCreatChannelContext(int32 ChannelType, const FString& InUserSig);
	int32 CreateChannelContext(int32 ChannelType, const FString& InUserSig);
	
	// 公共鉴权方法
	int32 GenerateAuthBuffer(const FString& InUserSig, FString InRoomID, unsigned char* OutBuffer, int32& OutBufferLen);
	uint32 ApplyAuthBuffer(ITMGContext* Context, const FString& InUserSig, const FString& InRoomID, const FString& LogPrefix = TEXT(""));
	
	TMap<int32, ITMGContext*> ITMGContextMap;
	TMap<int32, TSharedPtr<ITMGDelegate>> ITMGDelegateMap;
#endif

};
