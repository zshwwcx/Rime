﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "C7AkAudioVolume.generated.h"

UENUM()
enum EC7AkAudioVolumeShape
{
	Sphere,
	Box,
};

UENUM()
enum EC7AkAudioVolumeRtpcOwnerType
{
	Global,
	Player,
	Volume,
};

UCLASS()
class KGCORE_API AC7AkAudioVolume : public AActor
{
	GENERATED_BODY()

public:
	AC7AkAudioVolume();

protected:
	virtual void BeginPlay() override;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	virtual void Tick(float DeltaSeconds) override;

	UFUNCTION(BlueprintCallable)
	void SetEnableDebugDraw(bool bEnable) { bEnableDebugDraw = bEnable; }

	UFUNCTION()
	void OnPlayerEnter(AActor* Player, const FVector& Loc);

	UFUNCTION()
	void OnPlayerLeave(AActor* Player, const FVector& Loc);

private:
	void PlayerInsideOfVolume(const FVector& PlayerLoc);

	void PlayerOutsideOfVolume(const FVector& PlayerLoc);

#if WITH_EDITOR

protected:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

#endif

public:
	/**
	 * 形状
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None"))
	TEnumAsByte<EC7AkAudioVolumeShape> Shape = EC7AkAudioVolumeShape::Box;

	/**
	 * 圆形的半径
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta=(DisplayAfter = "None", EditCondition = "Shape == EC7AkAudioVolumeShape::Sphere", EditConditionHides = "Radius"))
	float Radius = 500.f;

	/**
	 * 方形的长宽高
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta=(DisplayAfter = "None", EditCondition = "Shape == EC7AkAudioVolumeShape::Box", EditConditionHides = "BoxExtent"))
	FVector BoxExtent = FVector(500.f, 500.f, 500.f);

	/**
	 * 方形样条线粗细
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta=(DisplayAfter = "None", EditCondition = "Shape == EC7AkAudioVolumeShape::Box", EditConditionHides = "BoxLineThickness"))
	float BoxLineThickness = 10.f;

	/**
	 * 要播放的音频事件
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None"))
	class UAkAudioEvent* AkAudioEvent;

	/**
	 * 是否允许声音被阻挡
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None"))
	bool bUseOcclusion = false;

	/**
	 * 声障Tick频率
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None", EditCondition = "bUseOcclusion", EditConditionHides, ClampMin = 0.1))
	float OcclusionRefreshInterval = 0.1f;

	/**
	 * 进入Volume时要切的GroupState
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None"))
	TArray<struct FKGGroupState> GroupState;

	/**
	 * 优先级, -1代表没有优先级, 即不参与优先级计算, 直接设置
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None", ClampMin = -1))
	int32 Priority = -1;

	/**
	 * Volume到声音源的距离Rtpc名称, 设置为""代表不设置该Rtpc
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None"))
	FString RtpcNameOfDistanceToVolume;

	/**
	 * Rtpc归属类型
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None"))
	TEnumAsByte<EC7AkAudioVolumeRtpcOwnerType> RtpcOwnerType = EC7AkAudioVolumeRtpcOwnerType::Global;

private:
	UPROPERTY()
	class UAkComponent* AkComponent;

	UPROPERTY()
	class UC7ShapeCollisionComponent* ShapeCollision = nullptr;

	UPROPERTY(Transient)
	TArray<struct FAkExternalSourceInfo> ExternalSources;

	bool bEnableDebugDraw = false;

	bool bPlayerInVolume = false;
};
