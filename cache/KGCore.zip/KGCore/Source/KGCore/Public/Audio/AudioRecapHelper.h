#pragma once
#include "CoreMinimal.h"
#include "AkAudioType.h"

class FAudioRecapHelper
{
public:
	void SetAudioManager(class UKGAkAudioManager* InAudioManager);

	void RebindDelegate();
	
	void OnRecordStart();
	void OnRecordStop();
	void OnRecordTick();
	
	void RecordInitialParams(
		const TMap<FString, FString>& InGroupState,
		const TMap<FString, float>& InRtpcs,
		const TMap<AkGameObjectID, TMap<FString, float>>& InGameObjectRtpcs,
		const TMap<AkGameObjectID, TMap<FString, FString>>& InGameObjectSwitches);

	
	void RecordEventPost(const FString& EventName, int32 PlayingID, const class UAkGameObject* GameObject, const FVector& ObjectLocation = FVector::ZeroVector);
	void RecordGroupState(const FString& GroupName, const FString& StateName);
	void RecordRtpc(const FString& RtpcName, float RtpcValue, const class UAkGameObject* GameObject = nullptr);
	void RecordSwitch(const FString& SwitchGroupName, const FString& SwitchStateName, const class UAkGameObject* GameObject);
	void RecordEventStopped(int32 PlayingID);
	void OnActorDestroyed(AActor* Actor);

private:
	struct FAudioGameObjectRecord
	{
		FString GameObjectName;
		TArray<int32> EventIDs;
		TArray<FString> EventNames;
		FVector ObjectLocation;
	};
	
	struct FAudioRecord
	{
		TArray<struct FKGGroupState> GroupStateRecords;
		TArray<struct FKGGroupState> SwitchRecords;
		TArray<struct FKGRtpc> RtpcRecords;
		FVector ListenerLocation;
		FRotator ListenerRotator;
		TArray<int32> StoppedEventIDs;
		TArray<AkGameObjectID> UnregisteredGameObjects;
		TMap<AkGameObjectID, FAudioGameObjectRecord> GameObjectRecords;
	};

	TWeakObjectPtr<class UKGAkAudioManager> AudioManager;

	// 初始信息
	TMap<FString, FString> InitialGroupStates;
	TMap<FString, float> InitialRtpcs;
	TArray<FKGGroupState> InitialSwitchesOnAkComp;
	TArray<FKGRtpc> InitialRtpcsOnAkComp;

	// 过程信息
	TMap<int64, FAudioRecord> AudioRecords;
	
	// 开始时间
	int64 RecordStartTime = 0;

	// 当前帧
	int64 CurrentMillisecond = 0;

	// 频率控制
	double LastRecordTime = 0.f;

	// 有过记录的GameObject,不在这里面的,会在统计数据内移除,主要是为了剔除无用数据
	TMap<AkGameObjectID, bool> UsefulGameObject;

	FDelegateHandle ActorDestroyDelegateHandle;
};
