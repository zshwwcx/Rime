﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AkComponent.h"
#include "Components/SplineComponent.h"
#include "GameFramework/Actor.h"
#include "AkAreaSoundEmitter.generated.h"

UCLASS()
class KGCORE_API AAkAreaSoundEmitter : public AActor
{
	GENERATED_BODY()

public:
	AAkAreaSoundEmitter();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

#if WITH_EDITOR

	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

#endif

public:
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable)
	void PostAreaEvent();

	UFUNCTION(BlueprintCallable)
	void StopAreaEvent();

public:
	/**
	 * 要播放的Event
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None"))
	class UAkAudioEvent* AkAudioEvent = nullptr;

	/**
	 * 是否允许声音被阻挡
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None"))
	bool bUseOcclusion = false;

	/**
	 * 声障Tick频率
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio", meta = (DisplayAfter = "None", EditCondition = "bUseOcclusion", EditConditionHides, ClampMin = 0.1))
	float OcclusionRefreshInterval = 0.1f;

	/**
	 * 最大衰减距离
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "C7Audio", meta = (DisplayAfter = "None"))
	float MaxAttenuationRadius = 0.f;

	/**
	 * 外径
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "C7Audio", meta = (DisplayAfter = "None", ClampMin = 0.0f) )
	float outerRadius = .0f;

	/**
	 * 内径
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "C7Audio", meta = (DisplayAfter = "None", ClampMin = 0.0f))
	float innerRadius = .0f;

private:
	UPROPERTY()
	UAkComponent* AkComponent;

	UPROPERTY()
	USplineComponent* SplineComponent;

	uint32 PlayingID = 0;

	TArray<FTransform> PointList;

	UPROPERTY(Transient)
	TArray<FAkExternalSourceInfo> AkExternalSourceInfos;
};
