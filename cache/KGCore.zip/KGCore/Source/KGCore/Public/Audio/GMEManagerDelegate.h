#pragma once

#include "CoreMinimal.h"
#ifdef DISABLE_GME
#else
#include "tmg_sdk.h"
#endif
#include "Audio/GMEManager.h"

class GMEDelegate
#ifdef DISABLE_GME
#else
	: public ITMGDelegate
#endif
{
public:
#ifdef DISABLE_GME
	GMEDelegate() {}
	~GMEDelegate() {} // 禁用 GME 时的析构函数
#else
	GMEDelegate(int32 InChannelType, UGMEManager* InManager)
		: ChannelType(InChannelType), Manager(InManager) {}
	~GMEDelegate() override { Manager.Reset(); }
    
	// 重写 OnEvent 方法
	virtual void OnEvent(ITMG_MAIN_EVENT_TYPE eventType, const char* data) override;
private:
	int32 ChannelType;
	TWeakObjectPtr<UGMEManager> Manager;
#endif
};
