#pragma once

#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "GeographyAndDateTimeController.h"
#include "ClimateController.h"
#include "KGGeographyClimateManager.generated.h"

const int32 MAX_DRAG_SPEED = 999999;

UDELEGATE()
DECLARE_DYNAMIC_DELEGATE_TwoParams(FGeographyClimateManager_OnMinChanged, int32, Hour, int32, Min);

UCLASS()
class KGCORE_API UKGGeographyClimateManager : public UKGBasicManager, public FTickableGameObject
{
	GENERATED_BODY()
	
public:
	void UpdateTime(float DeltaTime);

	void CalCurrentGameTime();

	void SetDateTime(float DeltaTime);

	void SetBloodMoon(float curveTime);
	
	void SetPhaseAngle(float curveTime);

	int64 GetUTCTime();

	template<typename T>
	void FindActorsOfType(TArray<TWeakObjectPtr<T>>& OutArray);

#pragma region Override
	virtual void NativeInit() override;
	virtual void NativeUninit() override;

	virtual EManagerType GetManagerType() override
	{
		return EManagerType::EMT_GeographyClimateManager;
	}

	static UKGGeographyClimateManager* GetInstance(UObject* InContext)
	{
		return Cast<UKGGeographyClimateManager>(GetManagerByType(InContext, EManagerType::EMT_GeographyClimateManager));
	}

	virtual void Tick(float DeltaTime) override;
	bool IsTickable() const override
	{
		return (HasAnyFlags(RF_ClassDefaultObject) == false);
	}
	virtual TStatId GetStatId() const override
	{
		return GetStatID();
	}
	
#pragma endregion Override
	
#pragma region Delegate
	UPROPERTY(Transient)
	FGeographyClimateManager_OnMinChanged OnMinChanged;
#pragma endregion Delegate

#pragma region LUA_API
	void LoadCurves(const FName& BloodMoonCurveName, const FName& PhaseAngleCurveName);

	void LuaUpdateWeather(float Cloud, float Fog, float Wind, float Rain, float Snow, float Thunderstorm, float Rainbow, bool BShowFakeCloud);
	
	void OverrideClimateShiftSpeed(float Value);

	void RestoreClimateShiftSpeed();

	void SetGameTime(double InJumpTime, int64 InStopTime);
	
	int32 GetGameTime();
	
	void ResetControllers();
	
	void ClearControllers();

	void CleanInvalidControllers();
#pragma endregion LUA_API

public:
	UPROPERTY(EditAnywhere)
	int64 RealSecondsPerDay = 3600;

	UPROPERTY(EditAnywhere)
	int32 InitServerTime = 0;

	UPROPERTY(EditAnywhere)
	bool bUseDefaultTime = false;

	UPROPERTY(EditAnywhere)
	float TimeDragSpeed = MAX_DRAG_SPEED;

	UPROPERTY(EditAnywhere)
	int32 CycleTime = 3600;
	
	UPROPERTY(EditAnywhere)
	int64 LastCurveTime = 0;

	UPROPERTY(EditAnywhere)
	float TimeFlowSpeed = 1.0f;

	UPROPERTY(EditAnywhere)
	float BloodMoonFactor = -1.0f;

	UPROPERTY(EditAnywhere)
	float PhaseAngleFactor = -1.0f;
private:
	UPROPERTY(Transient)
	TArray<TWeakObjectPtr<AGeographyAndDateTimeController>> GeographyAndDateTimeControllers;

	UPROPERTY(Transient)
	TArray<TWeakObjectPtr<AClimateController>> ClimateControllers;

	UPROPERTY(Transient)
	TObjectPtr<UCurveFloat> BloodMoonCurve;

	UPROPERTY(Transient)
	TObjectPtr<UCurveFloat> PhaseAngleCurve;

	double JumpTime = 0.0f;

	int64 StopTime = -1;
	
	int32 Hours = 0;

	int32 Minutes = 0;
	
	int32 Seconds = 0;
};
