// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "Input/Events.h"
#include "UKGInputProcessManager.generated.h"

DECLARE_DYNAMIC_DELEGATE_RetVal_TwoParams(bool, FKeyEventNotify, FName, KeyName, EInputEvent, KeyEvent);
DECLARE_DYNAMIC_DELEGATE_RetVal_OneParam(bool, FMouseEventNotify, FPointerEvent, MouseEvent);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FMouseEventNoReplyNotify, const FPointerEvent&, MouseEvent);
class KGInputProcessor;
/**
 * 
 */
UCLASS(BlueprintType, Blueprintable)
class KGCORE_API UUKGInputProcessManager : public UKGBasicManager
{
	GENERATED_BODY()

public:
	virtual void NativeInit() override;

	virtual void NativeUninit() override;

	virtual EManagerType GetManagerType() override { return EManagerType::EMT_KGInputProcessorManager; }

	UUKGInputProcessManager(const FObjectInitializer& ObjectInitializer);
	virtual ~UUKGInputProcessManager() override;
	
	UFUNCTION(Blueprintable)
	void BindKeyDownEvent(FName KeyName);

	UFUNCTION(Blueprintable)
	void UnBindKeyDownEvent(FName KeyName);

	UFUNCTION(Blueprintable)
	void BindKeyUpEvent(FName KeyName);

	UFUNCTION(Blueprintable)
	void UnBindKeyUpEvent(FName KeyName);

	UFUNCTION(Blueprintable)
	void UnBindAllKeyEvents();

	UFUNCTION(Blueprintable)
	void BindMouseButtonDownEvent();

	UFUNCTION(Blueprintable)
	void UnBindMouseButtonDownEvent();

	UFUNCTION(Blueprintable)
	void BindMouseButtonUpEvent();

	UFUNCTION(Blueprintable)
	void UnBindMouseButtonUpEvent();
    
    UFUNCTION(Blueprintable)
    void BindPointerMoveEvent();

    UFUNCTION(Blueprintable)
	void UnBindPointerMoveEvent();
    
	UFUNCTION(Blueprintable)
	void UnBindAllMouseEvents();
	
	// 回调代理 
	UPROPERTY()
	FKeyEventNotify OnGetKeyEventDelegate;

	UPROPERTY()
	FMouseEventNotify OnGetMouseButtonDownDelegate;

	UPROPERTY()
	FMouseEventNotify OnGetMouseButtonUpDelegate;
    
    UPROPERTY()
    FMouseEventNotify OnGetPointerMoveDelegate;

    UPROPERTY()
    FMouseEventNoReplyNotify OnGetMouseButtonUpNoReplyDelegate;

    UPROPERTY()
    FMouseEventNoReplyNotify OnGetMouseButtonDownNoReplyDelegate;
    
    UPROPERTY()
    FMouseEventNoReplyNotify OnGetPointerMoveNoReplyDelegate;

private:
	TSharedPtr<KGInputProcessor> InputPreprocessor = nullptr;
	
	TSet<FName> ReleasedKeyMaps;
	TSet<FName> PressedKeyMaps;
	bool bListenMouseDown = false;
	bool bListenMouseUp = false;
    bool bListenPointerMove = false;

	bool InputKeyNotify(FName KeyName, EInputEvent Event) const;
	bool InputMouseNotify(const FPointerEvent& MouseEvent, bool bIsDown) const;
    bool InputPointerMoveNotify(const FPointerEvent& InPointerEvent) const;
};
