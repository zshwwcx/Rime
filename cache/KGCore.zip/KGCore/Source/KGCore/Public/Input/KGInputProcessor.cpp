#include "Input/KGInputProcessor.h"
#include "Engine/EngineBaseTypes.h"


void KGInputProcessor::Tick(const float DeltaTime, FSlateApplication& SlateApp, TSharedRef<ICursor> Cursor)
{
}

bool KGInputProcessor::HandleKeyDownEvent(FSlateApplication& SlateApp, const FKeyEvent& InKeyEvent)
{
	if(InputKeyDelegate.IsBound())
	{
		return InputKeyDelegate.Execute(InKeyEvent.GetKey().GetFName(), IE_Pressed);
	}
	return IInputProcessor::HandleKeyDownEvent(SlateApp, InKeyEvent);
}

bool KGInputProcessor::HandleKeyUpEvent(FSlateApplication& SlateApp, const FKeyEvent& InKeyEvent)
{
	if(InputKeyDelegate.IsBound())
	{
		return InputKeyDelegate.Execute(InKeyEvent.GetKey().GetFName(), IE_Released);
	}
	return IInputProcessor::HandleKeyUpEvent(SlateApp, InKeyEvent);
}

bool KGInputProcessor::HandleMouseMoveEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent)
{
    if (InputPointerMoveDelegate.IsBound())
    {
        return InputPointerMoveDelegate.Execute(MouseEvent);
    }
    
    return IInputProcessor::HandleMouseMoveEvent(SlateApp, MouseEvent);
}

bool KGInputProcessor::HandleMouseButtonDownEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent)
{
	if(InputMouseDelegate.IsBound())
	{
		return InputMouseDelegate.Execute(MouseEvent, true);
	}
	return IInputProcessor::HandleMouseButtonDownEvent(SlateApp, MouseEvent);
}

bool KGInputProcessor::HandleMouseButtonUpEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent)
{
	if(InputMouseDelegate.IsBound())
	{
		return InputMouseDelegate.Execute(MouseEvent, false);
	}
	return IInputProcessor::HandleMouseButtonUpEvent(SlateApp, MouseEvent);
}