#pragma once

#include "CoreMinimal.h"
#include "TypeDefines/LuaEnums.h"
#include "Misc/CommonDefines.h"



struct FCppEntityData
{
	
	KGEntityID FinalOwnerID = KG_INVALID_ENTITY_ID; // 最终拥有者ID
	bool bIsMainPlayerTeammate = false;
	bool bIsMainPlayerGroupMember = false;
	
	bool bVisible = true; // 是否可见

	ECampType CampType = ECampType::Friendly; //相对于本机玩家的敌对关系
	EKGObserverType ObserverType = EKGObserverType::NONE; // 观察者类型
	FName BattleZoneID = NAME_None; // 战斗区域ID
	uint32 LockLimitCamp = 0;
	bool bIsLockLimit = false;
	EBossType BossType = EBossType::NoMonster; // BOSS类型
	ENpcType NpcType = ENpcType::Monster; // NPC类型
	uint32 PlayerClassTypeMask = 0; // 玩家职业类型

	double NextValidWhiteFlashTimestampSeconds = 0.0f;

	void Reset()
	{
		FinalOwnerID = KG_INVALID_ENTITY_ID;
		bIsMainPlayerTeammate = false;
		bIsMainPlayerGroupMember = false;
		bVisible = true;
		CampType = ECampType::Friendly;
		ObserverType = EKGObserverType::NONE;
		LockLimitCamp = 0;
		bIsLockLimit = false;
		BattleZoneID = NAME_None;
		BossType = EBossType::NoMonster;
		NpcType = ENpcType::Monster;
		NextValidWhiteFlashTimestampSeconds = 0.0;
	}
};