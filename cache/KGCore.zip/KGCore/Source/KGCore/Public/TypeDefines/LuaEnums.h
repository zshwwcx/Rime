#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"


// keep the same as Enum.EDamageFlagType in lua
enum class EDamageFlagType : uint8
{
	bHeal = 1,
	bSteal = 2,
	bActionHit = 4,
	bActionBlocked = 8,
	bActionCrit = 16,
	bDead = 32,
	bShallowGrave = 64,
	bImmune = 128,
};

enum class EDamageType1 : uint8
{
	Heal, // can be with bActionCrit
	Steal,// can be with bActionCrit
	bActionHit,// can be with bActionCrit | 
	bActionBlocked,
	ShallowGrave,
	Immune,
};

enum class EDamageType2 : uint8
{
	NoneDamage,
	PhysicalDamage,
	SpellDamage,
};

// keep the same in lua
// 伤害形式
UENUM(BlueprintType)
enum class EDamageMethod : uint8
{
	NormalHit = 0,              // 正常命中
	Blocked = 1,                // 格挡
	Critical = 2,               // 暴击
};

// keep the same in lua
// 伤害类型
UENUM(BlueprintType)
enum class EDamageType : uint8
{
	None = 0,
	Physics = 1,    // 物理伤害
	Magic = 2,      // 魔法伤害
};

enum class EDamageSourceType : uint8
{
	Skill = 0, // 技能
	Buff = 1, // Buff
};


// keep the same as Enum.EBuffStateType in lua
enum class EBuffStateType : uint8
{
	Empty = 0, //空占位符
	Attach = 1, //挂载（未实现）
	Sleep = 2, //催眠
	Stealth = 3, //隐身
	Taunt = 5, //嘲讽
	Endure = 6, //霸体
	Stuck = 7, //禁锢
	Dizzy = 10, //眩晕
	Silent = 11, //沉默
	SpeedDown = 15, //减速
	NormalBossMechanism = 16, //通用boss机制空状态
	DodgeLimit = 17, //滞涩
	Terror = 18, //恐惧
	CharacterStealth = 19, //隐身, 该隐身与Stealth唯一的差别在于，该隐身只具有ImunneLock效果，不具有Hitlimit效果
	StoneState = 100, //石化状态
	MaxValue = 101, //占坑用
};


enum class ERelationType : uint8
{
	Self = 0, //自己
	TeamMate = 1, //小队队友
	GroupMate = 2, //团队队友
	Allies = 3, //友好角色
	Neutral = 4, //中立角色
	Enemy = 5,	//敌对角色
	BackUp01 = 6,
	BackUp02 = 7,
	BackUp03 = 8,
	BackUp04 = 9,
	BackUp05 = 10,
	BackUp06 = 11,
	BackUp07 = 12,
	BackUp08 = 13,
	BackUp09 = 14,
	Max = 15, //无效选项
};

enum class ECampType : uint8
{
	Friendly = 0,
	Enemy = 1,
	Neutral = 2,

};

enum class EKGObserverType : uint8
{
	NONE = 0,
	PVP = 1,
	PVE = 2,
};

//阵营检查类型
enum class EDynamicCampType : uint8
{
	RedNameRule = 1,    //红名阵营判断规则
	SpaceDynamicCampRule = 2,     //动态阵营规则
};

//触发伤害结算的来源
enum class EDoFightActionSourceType : uint8
{
	Skill = 0,
	Buff = 1,
	SpellField = 2,
	Bullet = 3,
	Max, //无效选项
};


enum class EHitEffectPlayLocationMode : uint8
{
	HitLocation = 1, // 在受击点播放
	AttachLocation = 2, // 在挂接点播放
};

/*
Enum.EBossType = {
	NoMonster = -1,--非怪物
	CREEP = 0,   -- 小兵
	Create = 1,  -- 创生怪物
	Elite = 2,   -- 精英怪物
	BOSS = 3,    -- Boss
	Building = 4, -- 建筑物（防御塔之类的)
}
*/
enum class EBossType : int8
{
	NoMonster = -1, // 非怪物
	CREEP = 0, // 小兵
	Create = 1, // 创生怪物
	Elite = 2, // 精英怪物
	BOSS = 3, // Boss
	Building = 4, // 建筑物（防御塔之类的)
	Vehicle = 5, // 载具
};

enum class ENpcType : uint8
{
	Monster = 0, // 怪物
	Task = 1,   // 任务NPC
	Passerby = 2,
	Vehicle = 3,
	CombatVehicle = 4,
	Max,
};

enum class EPlayerClassType : uint8
{
	Melee = 1,
	Ranged = 2,
	Healer = 3,
	DPS = 4,
	Tank = 5,
	SefirahCastle = 6,
	ChaosSea = 7
};

/*
AkAudioManager.EPlayerSlotSuffix = {
	P1 = "_1P",
	P2 = "_2P",
	P3 = "", -- 占位用
}
*/

enum class EPlayerSlotSuffix : uint8
{
	P1 = 0,
	P2 = 1,
	P3 = 2,
	MAX = 3,
};

enum class EKGBulletTrailType : uint8
{
	Direction = 1,      // 子弹平行直线往前，参数为最多飞n米
	Line = 2,           // 直线打向目标点，可往高处或者低处打
	Missile = 3,        // 追踪子弹，往目标追踪
	MissileNoMiss = 4,  // 必中追踪子弹
	Curve = 7,          // 特殊复杂曲线轨迹，参数为UE内编辑的曲线文件（这个待开发，需要先开发UE内曲线编辑器
	Parabola = 8,       // 抛物线(新)
	ParabolaWithTrack = 9, // 抛物线追踪
	Round = 10,         // 环绕子弹
	Max,
};

enum class EKGBulletNiagaraFollowType : uint8
{
	NotFollow = 0,           // 不跟随
	FollowPosAndRot = 1, // 跟随位置和朝向
	OnlyFollowPos = 2,    // 仅跟随位置
	Max,
};

enum class EKGBulletOffsetMode : uint8
{
	Spawner = 0,
	Target = 1,
};

enum class EKGBulletDirectionMode : uint8
{
	Root1ToRoot2 = 0,               // 默认第一偏移点到到第二偏移点为起始方向
	UseDirectionByConfig = 1,       // 使用配置计算出来的偏移(表格内+task的两次偏移和转向）
	Direction2Target = 2,           // 指向目标
	UseDirectionByTask = 3,         // 子弹朝向仅取决于 Task 设置
};

enum class EKGBulletDestroyReason : int8
{
	UNDEFINED = -1,				// actor被其他原因销毁
	END_OF_LIFE = 0,            // 生命周期到了
	HIT_TARGET = 1,             // 命中目标
	REACH_MAX_HIT_TIMES = 2,    // 到达命中次数上线
	REACH_TARGET_POS = 3,       // 到达了目标位置
	INSTIGATOR_DEAD = 4,        // 始作俑者死亡
	INSTIGATOR_LEAVE_SPACE = 5, // 始作俑者离开场景
	INSTIGATOR_DESTROY = 6,     // 始作俑者销毁(死亡)
	TARGET_DESTROY = 7,         // 目标销毁了
	INTERRUPT = 8,              // 中断(外部主动销毁)
	TARGET_INVALID = 9,         // 目标非法(不可攻击之类的)
};

// keep the same in lua
// 控制结果
UENUM(BlueprintType)
enum class EControlAddResultType : uint8
{
	Succ = 0,		// 成功
	Immune = 1,    // 免疫
	Fail = 2,      // 失败
};


UENUM()
enum class EKGDecalHiddenReason : uint8
{
	ForewarnEntityHidden = 0,
	Cutscene = 1,
	// 从200开始cpp内部使用
	LoadingMaterial = 200, // 材质加载好之前不能显示, 否则会使用默认材质有表现问题
	// 最大255
	Max = 255
};
