#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Misc/CommonDefines.h"


struct FTeamMemberList
{
	TArray<KGEntityID> TeamMemberIDs; // 组队成员ID列表
};

/**
 * 老爷车拖尾表现相关(特效&音效)
 */
struct FTriggerDriftParams
{
	FString TriggerDriftDecalPath_L; // 左转特效路径
	FString TriggerDriftDecalPath_R; // 右转特效路径
	FString TriggerDriftStartAudio; // 开始音效
	FString TriggerDriftStopAudio; // 结束音效
	FString TriggerDriftStartAudio_1P; // 开始音效1P
	FString TriggerDriftStopAudio_1P; // 结束音效1P
	bool bInitialized = false;
};

struct FGlideLoopParams
{
	uint8 LocoState = 0;
	FString HandNiagaraPath;
	FString ArmNiagaraPath_L;
	FString ArmNiagaraPath_R;
	FName NiagaraAttachPoint_HL;
	FName NiagaraAttachPoint_HR;
	FName NiagaraAttachPoint_AL;
	FName NiagaraAttachPoint_AR;
	bool bInitialized = false;
};

// 脚印配置
struct FTerrainFootprintData
{
	bool bTriggerOnLeave = false;
	float RemainTime = 0.f; // 脚印检测时间
	float LifeTime = 0.f; // 脚印滞留时间
	float FadeOutTime = 0.f; // 脚印淡出时间
	FVector DecalSize; // 大小
	FString DecalMaterialPath;
	TArray<FString> SameEffectTerrainList;
};

// 武器信息配置
struct FWeaponInfoData
{
	int WeaponID;
	int WeaponType;
	int WeaponSlot;
	TArray<int> SubWeapons;

	FString ModelID;
	FString WeaponFightToIdleAnimPath;

	int DisappearEffect;
	float DisappearStartTime;
	int AppearEffect;
	float AppearStartTime;
};

// 武器类型配置
struct FWeaponTypeData
{
	int WeaponType;
	int DisappearEffect;
	float DisappearStartTime;
	int AppearEffect;
	float AppearStartTime;
};

// 涉及到 虚拟挂接的跟随模式参数太多、暂时只支持配置实际使用到的参数
struct FVirtualAttachInfo
{
public:
	int64 AttachID = -1;
	int64 AttachVirtualSocketID = -1;
	
	FName AttachSocket = NAME_None;
	FVector RelLocation = FVector::ZeroVector;
	FRotator RelRotation = FRotator::ZeroRotator;
	FVector RelLocationAdd = FVector::ZeroVector;
	FVector SocketLocation = FVector::ZeroVector;
	FRotator SocketRotation = FRotator::ZeroRotator;

	// 位置更新模式
	uint8 LocationUpdateMode = 0;

	// 贝塞尔位置更新参数
	float BezierStep = 0.f;
	float BezierStepMaxDist = 0.f;
	float BezierSpeedAlpha = 0.f;
	float BezierLagSpeed = 0.f;
	float BezierDirectionMultiplier = 0.f;

	bool bWithInCircle = false;
	float InCircleLagSpeed = 0.f;
	float InCircleLagTolerance = 0.f;

	// 旋转更新模式
	uint8 RotationUpdateMode = 0;
	float AttachRotationLagSpeed = 0.f;
	float FaceToMoveDirectionTolerance = 0.f;
	bool bClampPitch = false;
	float PitchClampAngleMin = 0.f;
	float PitchClampAngleMax = 0.f;
	float RotateRoundTime = 10.f;
	bool bEnableAttachRotationLag = true;
	bool bAbsoluteRotate = false;
	
	// 碰撞探测相关配置
	bool bDoCollisionTest = false;
	float CollisionProbeSize = 10.f;
	TArray<int> CollisionChannels;
};