#pragma once

#include "CoreMinimal.h"
#include "TypeDefines/LuaEnums.h"
#include "UObject/NoExportTypes.h"
#include "Misc/CommonDefines.h"

#include "LuaTypes.generated.h"


// keep the same as DamageContextNew in alias.xml
struct DamageContextNew
{
	int AssetIDWithType = 0; // 资产ID和类型
	int ActionUniqueID = 0; // 动作唯一ID -- deprecated
	KGEntityID InstigatorID = 0; // 发起者ID -- deprecated, 与 AttackerID 一致
	KGEntityID AttackerID = 0; // 攻击者ID
	KGEntityID DefenderID = 0; // 防御者ID
	int BitFlags = 0; // 位标志 -- deprecated
	float HpDelta = 0.0f; // 实际血量变化值 -- deprecated, 如果是伤害与 RealDamage - ShieldCost 一致，如果是治愈与 RealHeal 一致
	float ShieldCost = 0.0f; // 护盾扣除值
	int EleEffectId = 0; // 元素效果ID -- deprecated
	int DamageType = 0; // 伤害类型
	int DamageValue = 0; // 当次伤害值 -- deprecated, 与 TotalDamage 一致
	int DamageMethod = 0; // 伤害形式
	int TotalDamage = 0; // 总伤害
	int RealDamage = 0; // 有效伤害量
	int TotalHeal = 0; // 总治疗量
	int RealHeal = 0; // 有效治疗量
	// EDamageType DamageType = EDamageType::None; // 伤害类型
	// EDamageMethod DamageMethod = EDamageMethod::NormalHit; // 伤害形式
	bool IsDead = false; // 是否致命伤害
};


struct BeatenContext
{
	uint64 HitSrcInsIdWithType = 0; // 击中源实例ID和类型
	int ActionUniqueID = 0; // 动作唯一ID
	KGEntityID InstigatorID = 0; // 发起者ID
	KGEntityID AttackerID = 0; // 攻击者ID
	KGEntityID DefenderID = 0; // 防御者ID
	bool bNeedSpecifyTrans = false; // 是否需要指定变换
	FTransform SpecifyTrans = FTransform::Identity;

};

UENUM(BlueprintType)
enum class EDamageProcessType : uint8
{
	None = 0,
	Damage = 1,
	Heal = 2,
	Control = 3,
	BurnBody = 4,
	HealLimit = 5,
};

struct FVFXData
{
	FString HitEffectPath;    // 击中特效路径
	FString HitSoundPath;     // 击中音效路径
	FRotator HitEffectRotation; // 击中特效旋转
	FVector HitEffectScale = FVector::OneVector; // 击中特效缩放
	FVector HitEffectOffset = FVector::ZeroVector; // 击中特效偏移
	float HitFxPlayRate = 1.0; // 击中特效播放速率
	FName HitFxPosUsedSocket = NAME_None; // 击中特效使用的骨骼位置
	EHitEffectPlayLocationMode LocationMode; // 击中特效播放位置模式
	bool bFlashWhite = false;              // 是否闪白
	FString OnHitShake;       // 击中震屏效果
};

struct FBuffData
{
	int32 ID = 0;
	FString BuffName;
};

UENUM()
enum class EKGTargetActorType : uint32
{
	None = 0,          // 全体（不筛选)
	Player = 1,        // 玩家
	CreateMonster = 2, // 创生怪物
	NormalMonster = 4, // 普通怪物
	EliteMonster = 8,  // 精英怪物
	Boss = 16,         // boss
	TaskNpc = 32,      // 任务npc
	Interactor = 64,   // 交互物
	SpellField = 128,  // 法术场(entity实现的法术场)
	Aura = 256,        // 光环(entity实现的光环)
	Trap = 512,        // 陷阱(entity实现的陷阱)
	Vehicle = 1024,    // 载具
	Summon = 2048,     // 召唤物
	Building = 4096,   // 建筑
	
	Monsters = CreateMonster | NormalMonster | EliteMonster | Boss,
	Npcs = TaskNpc,
	All = Player | Monsters | Npcs | Vehicle | Summon,
};

UENUM()
enum class EKGTargetSortStrategy : uint8
{
	None = 0,            // 不排序
	ByProp = 1,            // 通过属性排序
	ByDistance = 2,        // 通过到调用者的距离排序
	Random = 3,            // 随机
	EnterOrder = 4,        // 进出顺序(用于光环)
	CreateTime = 5,     // 创建时间(用于光环、陷阱、法术场等unit单位)
	ByHpRate = 6,       // 血量百分比
	ByDistanceDivide = 7, // 距离划分
	ByCameraDir = 8,		// 镜头方向(用于索敌)
	
	// 内部使用， 不开放给策划(ByHpRate会转换成BySortMethod)
	BySortMethod = 100,
};

#define KG_MAX_SHAPE_PARAMS_NUM (6)

UENUM()
enum class EKGTargetSelectShapeType : uint8
{
	Cuboid = 1,        // 长方体(原点为底面中心）
	Cylinder = 2,    // 圆柱（原点为底面圆心）
	Fan3d = 3,      // 扇柱（原点为底面圆心）
	Sphere = 4,        // 球形（原点为球心）
	Annular3d  = 5, // 环形体（原点为底面圆心)
};

UENUM()
enum class EKGTargetSelectCoordinateType : uint8
{
	Self = 0,           // self: 自身位置点
	SelfOffset = 1,     // selfoffset,dist,x: 自身位置往前dist距离、再往右x（x缺省为0）的点
	Target = 2,         // tar: 目标位置点
	TargetOffset = 3,   // taroffset,dist,x: 目标位置往前dist距离、再往右x（x缺省为0）的点
	TargetToSelf = 4,   // tartoself,dist,x: 目标往自身连线方向往前dist距离、再往右x（x缺省为0）的点
	SelfToTarget = 5,   // selftotar,dist,x: 自身往目标连线方向往前dist距离、再往右x（x缺省为0）的点
	WorldPos = 6,       // worldpos,x,y,z：世界坐标系下x,y,z坐标点
	PosList = 7,        // poslist：黑板值里的位置，无参数
	TargetList = 8,     // tarlist：黑板值里的目标，无参数
	Location = 9,       // location：外部传入的位置（对怪物是FlowChart传入的位置，对玩家是鼠标拖拽的位置），无参数
	SelfInput = 10,     // selfinput: 自身位置点, 朝向为 inputDir
};

struct FKGSingleRangeData
{
	bool GetShapeParamsAsCuboid(float& OutLength, float& OutWidth, float& OutHeight, float& OutZRangeMin, float& OutZRangeMax) const
	{
		if (ShapeType != EKGTargetSelectShapeType::Cuboid)
		{
			return false;
		}
		OutLength = ShapeParams[0];
		OutWidth = ShapeParams[1];
		OutHeight = ShapeParams[2];
		OutZRangeMin = ShapeParams[3];
		OutZRangeMax = ShapeParams[4];
		return true;
	}
	
	bool GetShapeParamsAsCylinder(float& OutRadius, float& OutHeight, float& OutZRangeMin, float& OutZRangeMax) const
	{
		if (ShapeType != EKGTargetSelectShapeType::Cylinder)
		{
			return false;
		}
		OutRadius = ShapeParams[0];
		OutHeight = ShapeParams[1];
		OutZRangeMin = ShapeParams[2];
		OutZRangeMax = ShapeParams[3];
		return true;
	}
	
	bool GetShapeParamsAsFan3d(float& OutInnerRadius, float& OutOuterRadius, float& OutHeight, float& OutAngleDegree, float& OutZRangeMin, float& OutZRangeMax) const
	{
		if (ShapeType != EKGTargetSelectShapeType::Fan3d)
		{
			return false;
		}
		OutInnerRadius = ShapeParams[0];
		OutOuterRadius = ShapeParams[1];
		OutHeight = ShapeParams[2];
		OutAngleDegree = ShapeParams[3];
		OutZRangeMin = ShapeParams[4];
		OutZRangeMax = ShapeParams[5];
		return true;
	}
	
	bool GetShapeParamsAsSphere(float& OutRadius, float& OutZRangeMin, float& OutZRangeMax) const
	{
		if (ShapeType != EKGTargetSelectShapeType::Sphere)
		{
			return false;
		}
		OutRadius = ShapeParams[0];
		OutZRangeMin = ShapeParams[1];
		OutZRangeMax = ShapeParams[2];
		return true;
	}
	
	bool GetShapeParamsAsAnnular3d(float& OutInnerRadius, float& OutOuterRadius, float& OutHeight, float& OutZRangeMin, float& OutZRangeMax) const
	{
		if (ShapeType != EKGTargetSelectShapeType::Annular3d)
		{
			return false;
		}
		OutInnerRadius = ShapeParams[0];
		OutOuterRadius = ShapeParams[1];
		OutHeight = ShapeParams[2];
		OutZRangeMin = ShapeParams[3];
		OutZRangeMax = ShapeParams[4];
		return true;
	}
	
	void SetShapeParams(float Param0, float Param1, float Param2, float Param3, float Param4, float Param5)
	{
		ShapeParams[0] = Param0;
		ShapeParams[1] = Param1;
		ShapeParams[2] = Param2;
		ShapeParams[3] = Param3;
		ShapeParams[4] = Param4;
		ShapeParams[5] = Param5;
	}
	
	bool IsShapeParamsValid() const
	{
		if (ShapeType == EKGTargetSelectShapeType::Cuboid)
		{
			float Length, Width, Height, ZRangeMin, ZRangeMax;
			if (!GetShapeParamsAsCuboid(Length, Width, Height, ZRangeMin, ZRangeMax))
			{
				return false;
			}
			
			return Width > UE_KINDA_SMALL_NUMBER && Length > UE_KINDA_SMALL_NUMBER && Height > UE_KINDA_SMALL_NUMBER &&
				ZRangeMin <= 0.0f && ZRangeMax >= 0.0f;
		}
		
		if (ShapeType == EKGTargetSelectShapeType::Cylinder)
		{
			float Radius, Height, ZRangeMin, ZRangeMax;
			if (!GetShapeParamsAsCylinder(Radius, Height, ZRangeMin, ZRangeMax))
			{
				return false;
			}
			
			return Radius > UE_KINDA_SMALL_NUMBER && Height > UE_KINDA_SMALL_NUMBER && 
				ZRangeMin <= 0.0f && ZRangeMax >= 0.0f;
		}
		
		if (ShapeType == EKGTargetSelectShapeType::Fan3d)
		{
			float InnerRadius, OuterRadius, Height, AngleDegree, ZRangeMin, ZRangeMax;
			if (!GetShapeParamsAsFan3d(InnerRadius, OuterRadius, Height, AngleDegree, ZRangeMin, ZRangeMax))
			{
				return false;
			}
			
			return OuterRadius > UE_KINDA_SMALL_NUMBER && 
						Height > UE_KINDA_SMALL_NUMBER && 
						AngleDegree > UE_KINDA_SMALL_NUMBER &&
						AngleDegree <= 360.0f &&
						InnerRadius >= 0.0f && 
						OuterRadius > InnerRadius &&
						ZRangeMin <= 0.0f && ZRangeMax >= 0.0f;
		}
		
		if (ShapeType == EKGTargetSelectShapeType::Sphere)
		{
			float Radius, ZRangeMin, ZRangeMax;
			if (!GetShapeParamsAsSphere(Radius, ZRangeMin, ZRangeMax))
			{
				return false;
			}
			
			return Radius > UE_KINDA_SMALL_NUMBER && ZRangeMin <= 0.0f && ZRangeMax >= 0.0f;;
		}
		
		if (ShapeType == EKGTargetSelectShapeType::Annular3d)
		{
			float InnerRadius, OuterRadius, Height, ZRangeMin, ZRangeMax;
			if (!GetShapeParamsAsAnnular3d(InnerRadius, OuterRadius, Height, ZRangeMin, ZRangeMax))
			{
				return false;
			}
			
			return OuterRadius > UE_KINDA_SMALL_NUMBER && 
					Height > UE_KINDA_SMALL_NUMBER &&
					InnerRadius >= 0.0f && 
					OuterRadius > InnerRadius &&
					ZRangeMin <= 0.0f && ZRangeMax >= 0.0f;
		}
		
		return false;
	}
	
	FString GetShapeParamsInfo() const
	{
		if (ShapeType == EKGTargetSelectShapeType::Cuboid)
		{
			float Length, Width, Height, ZRangeMin, ZRangeMax;
			GetShapeParamsAsCuboid(Length, Width, Height, ZRangeMin, ZRangeMax);
			return FString::Printf(TEXT("Cuboid(L: %.2f, W: %.2f, H: %.2f, ZMin: %.2f, ZMax: %.2f)"), Length, Width, Height, ZRangeMin, ZRangeMax);
		}
		
		if (ShapeType == EKGTargetSelectShapeType::Cylinder)
		{
			float Radius, Height, ZRangeMin, ZRangeMax;
			GetShapeParamsAsCylinder(Radius, Height, ZRangeMin, ZRangeMax);
			return FString::Printf(TEXT("Cylinder(R: %.2f, H: %.2f, ZMin: %.2f, ZMax: %.2f)"), Radius, Height, ZRangeMin, ZRangeMax);
		}
		
		if (ShapeType == EKGTargetSelectShapeType::Fan3d)
		{
			float InnerRadius, OuterRadius, Height, AngleDegree, ZRangeMin, ZRangeMax;
			GetShapeParamsAsFan3d(InnerRadius, OuterRadius, Height, AngleDegree, ZRangeMin, ZRangeMax);
			return FString::Printf(TEXT("Fan3d(IR: %.2f, OR: %.2f, H: %.2f, A: %.2f, ZMin: %.2f, ZMax: %.2f)"),
				InnerRadius, OuterRadius, Height, AngleDegree, ZRangeMin, ZRangeMax);
		}
		
		if (ShapeType == EKGTargetSelectShapeType::Sphere)
		{
			float Radius, ZRangeMin, ZRangeMax;
			GetShapeParamsAsSphere(Radius, ZRangeMin, ZRangeMax);
			return FString::Printf(TEXT("Sphere(R: %.2f, ZMin: %.2f, ZMax: %.2f)"), Radius, ZRangeMin, ZRangeMax);
		}
		
		if (ShapeType == EKGTargetSelectShapeType::Annular3d)
		{
			float InnerRadius, OuterRadius, Height, ZRangeMin, ZRangeMax;
			GetShapeParamsAsAnnular3d(InnerRadius, OuterRadius, Height, ZRangeMin, ZRangeMax);
			return FString::Printf(TEXT("Annular3d(IR: %.2f, OR: %.2f, H: %.2f, ZMin: %.2f, ZMax: %.2f)"),
				InnerRadius, OuterRadius, Height, ZRangeMin, ZRangeMax);
		}
		
		return FString::Printf(TEXT("Unknown ShapeType %d"), static_cast<uint8>(ShapeType));
	}
	
	EKGTargetSelectCoordinateType CoordinateType = EKGTargetSelectCoordinateType::Self;
	float ClockwiseRotation = 0.0f;
	FVector CoordinateOffset = FVector::ZeroVector;
	
	EKGTargetSelectShapeType ShapeType = EKGTargetSelectShapeType::Cuboid;
	
private:
	// 用float数组表示各类形式的图形的参数
	float ShapeParams[KG_MAX_SHAPE_PARAMS_NUM] = { 0.0f };
};

struct FKGSearchRangeParams
{
	// 暂时先只支持单个range data
	FKGSingleRangeData RangeData;
};

UENUM()
enum class EKGEntityAliveType : uint8
{
	Alive = 0,       // 活人(排除尸体)(缺省)
	Dead = 1,        // 要求目标是死亡的
	IncludeDead = 2, // 不考虑存活状态(死亡或者活着都行)
};

UENUM()
enum class EKGHitLimitType : uint8
{
	NonLimit = 0,     // 常规(排除不可筛选对象)
	Limit = 1,        // 仅不可筛选对象
	IncludeLimit = 2, // 包含不可筛选对象
};

enum class EKGQuerySelfType : uint8
{
	Default = 0,
	OnlySelf = 1,
	ExcludeSelf = 2,
	OnlyOwner = 3,
	ExcludeAll = 4, // 结果排除所有人
};

struct FKGSearchTargetParams
{
	uint64 GlobalTargetTypeMask = 0;
	// faction filter
	uint32 FactionMask = 0;
	EKGQuerySelfType QuerySelfType = EKGQuerySelfType::Default;
	// type filter
	uint64 TargetTypeMask = static_cast<uint64>(EKGTargetActorType::All);
	uint32 ClassTypeMask = 0;
	// revise filter
	EKGEntityAliveType EntityAliveType = EKGEntityAliveType::Alive;
	EKGHitLimitType HitLimitType = EKGHitLimitType::NonLimit;
};

UENUM()
enum class EKGTargetSelectBackupMode : uint8
{
	UseNewSelectRule = 0,   // 完全使用新的目标筛选规则
	UseNewShape = 1,        // 仅使用新的范围
	UseNewFilter = 2,       // 仅使用新的过滤规则
};

struct FSkillData
{
	int32 ID = 0;
	FString Name;
	FVFXData VFXData; // 通用效果数据
	float Dist = 0.0f;
	
	uint32 TargetNum = 0;
	bool bHasRangeParams = false;
	FKGSearchRangeParams RangeParams;
	bool bHasBackupRangeParams = false;
	FKGSearchRangeParams BackupRangeParams;
	FKGSearchTargetParams SearchTargetParams;
};

struct FSpellFieldData
{
	int32 ID = 0;
	FVFXData VFXData; // 通用效果数据
	
	uint32 TargetNum = 0;
	bool bHasRangeParams = false;
	FKGSearchRangeParams RangeParams;
	bool bHasSearchTargetParams = false;
	FKGSearchTargetParams SearchTargetParams;
	TArray<FVector2D> CheckTimeList;
};

struct FKGTargetSelectRuleData
{
	uint32 MaxNum = 0;
	uint32 BackupRuleID = 0;
	EKGTargetSelectBackupMode BackupMode = EKGTargetSelectBackupMode::UseNewSelectRule;
	EKGTargetSortStrategy SortType = EKGTargetSortStrategy::None;
	bool bDistanceSortUseIncOrder = false;
	FKGSearchRangeParams RangeParams;
	FKGSearchTargetParams SearchTargetParams;
};

struct FBulletEffectData
{
	FString EffectPath; // 子弹特效路径
	bool bFollowScale = false; // 子弹特效是否跟随缩放
	FRotator EffectRotation = FRotator::ZeroRotator; // 子弹特效旋转
	FVector EffectScale = FVector::OneVector; // 子弹特效缩放
	FVector EffectOffset = FVector::ZeroVector; // 子弹特效偏移
};

struct FBulletData
{
	int32 ID = 0;
	FVFXData VFXData; // 通用效果数据
	
	float MaxLifeTime = 0.0f; // 最大飞行时长(秒)
	float MoveDist = -1.0f; // 最大飞行距离(cm)
	float DelayDestroyTime = 0.0f; // 延迟销毁时间(秒)
	EKGBulletTrailType TrailType = EKGBulletTrailType::Direction; // 子弹轨迹类型
	FString StartPosAnchorBone; // 子弹出生点骨骼
	FVector StartPosAnchorOffset = FVector::ZeroVector; // 子弹出生点偏移(cm)
	FString TargetPosAnchorBone; // 子弹目标点骨骼
	float DelayLaunchTime = 0.0f; // 开始飞行延迟时间(秒)
	float Velocity = 0.0f; // 子弹速度(cm/s)
	float Acceleration = 0.0f; // 子弹加速度(cm/s²)
	float AngularVelocity = 0.0f; // 子弹角速度(度/s)
	float MaxHomingAngle = 360.0f; // 最大追踪角度(度)
	
	float TargetPointMoveSpeed = 0.0f; // 抛物线追踪目标点移动速度(cm/s)
	float TrackDuration = 0.0f; //  抛物线追踪持续时间(秒)

	FVector RoundStartCoordinates = FVector::ZeroVector; // 环绕子弹起始坐标
	FVector RoundCenterCoordinates = FVector::ZeroVector; // 环绕子弹中心坐标

	FBulletEffectData BulletSpawnEffectData; // 子弹出生特效数据
	EKGBulletNiagaraFollowType SpawnEffectFollowType = EKGBulletNiagaraFollowType::NotFollow; // 子弹出生特效跟随类型
	
	FBulletEffectData BulletTrailEffectData; // 子弹拖尾特效数据
	EKGBulletNiagaraFollowType TrailEffectFollowType = EKGBulletNiagaraFollowType::NotFollow; // 子弹拖尾特效跟随类型
	float TrailEffectDelayDestroyTime = 0.0f; // 子弹拖尾特效延迟销毁时间(秒)
	
	FBulletEffectData BulletDestroyEffectData; // 子弹销毁特效数据

	FString FireAudioName; // 发射音效
	FString FadeAudioName; // 飞行音效

	bool bEnableWaterWave = false;
	float WaterWaveRadius = 0.0f; // 水波半径
	float DepthThreshold = 0.0f;
	float DistanceThreshold = 0.0f;
	int32 WaveMotorTextureID = 0;
	float ScaleX = 1.0f;
	float ScaleY = 1.0f;
	float MaxHeight = 0.0f;
	float FoamScale = 1.0f;

	bool bCheckPrefectDodge = false;
	float CollisionRadius = 0.0f;
	uint32 PerfectDodgeSkillID = 0;

	uint8 EffectPriority = 0;
};

struct FReminderData
{
	FString Text1;
};


struct FElementEffectsData
{
	int32 ID = 0;
	int32 ElementTypeID = 0;
	int32 NoCriticalEffectId = 0;
	int32 CriticalEffectId = 0;
	FString icon;
};


struct FElementSingleEffectData
{
	int32 ID = 0;
	int32 CastSkill = 0;
	int32 HealCastSkill = 0;
	FString EleDamage;
	float DamageDiffusionCoeff = 0.0f;
	TArray<int32> AddBuffs;
	bool IsRandomBuff = false;
	TArray<int32> TargetAddBuffs;
	bool IsTargetRandomBuff = false;
	int32 ExtraAtkRandomTimes = 0;
	TArray<FString> AddProfessionProp; // Assuming this is a string array, adjust as needed
	FString SelfElementNiagara;
	FString TargetElementNiagara;
};


struct FSkillAkEventKey
{
	FString OriginName;
	EPlayerSlotSuffix Type;

	// 必须的 == 运算符
	bool operator==(const FSkillAkEventKey& Other) const
	{
		return OriginName == Other.OriginName && Type == Other.Type;
	}

	// 推荐的 != 运算符
	bool operator!=(const FSkillAkEventKey& Other) const
	{
		return !(*this == Other);
	}

	// 必须的哈希函数
	friend uint32 GetTypeHash(const FSkillAkEventKey& Key)
	{
		return HashCombine(GetTypeHash(Key.OriginName), GetTypeHash(Key.Type));
	}
};

template<typename T>
struct FKGLinearSampleMaterialParam
{
	T StartVal;
	T EndVal;
	float Duration = 0.0f;
};

struct FKGCurveMaterialParam
{
	FString CurvePath;
	bool bNeedRemap = false;
	float RemapTime = 1.0f;
};

struct FKGMaterialParamsData
{
	TMap<FName, float> ScalarParams;
	TMap<FName, FLinearColor> VectorParams;
	TMap<FName, FString> TextureParams;
	TMap<FName, FKGLinearSampleMaterialParam<float>> LinearSampleScalarParams;
	TMap<FName, FKGLinearSampleMaterialParam<FLinearColor>> LinearSampleVectorParams;
	TMap<FName, FKGCurveMaterialParam> CurveParams;
};

struct FKGNiagaraParamData
{
	TMap<FName, float> ScalarParams;
	TMap<FName, FKGLinearSampleMaterialParam<float>> LinearSampleScalarParams;
	TMap<FName, FKGCurveMaterialParam> CurveParams;
};

struct FKGDissolveEffectData
{
	bool bOverrideDissolveColor = false;
	FLinearColor OverrideDissolveColor = FLinearColor::Black;
	float Duration = 1.0f;
	int32 DissolveType = 0;
	TArray<int32> EffectIDs;
	TArray<FName> MaterialSlotNames;
	FString WeaponDissolveSMEffectPath;
	FString WeaponDissolveSKEffectPath;
	float WeaponDissolveEffectPlayRate = 1.0f;
	
	FName DissolveSwitchParamName;
	bool bLinearSampleDissolve = true;
};

struct FKGAttachedNiagaraEffectData
{
	FString NiagaraEffectPath;
	FName AttachPointName = NAME_None;
	FString AttachComponentName;
	FTransform RelativeTransform = FTransform::Identity;
	bool bAttachToCamera = false;
};

struct FVehicleWayPathPointData
{
	// SplinePoint
	float InputKey = 0.f;	// 曲线点的Key
	FVector Position = FVector::ZeroVector;	// 曲线点位置
	FVector ArriveTangent = FVector::ZeroVector; // 曲线点进入切线
	FVector LeaveTangent = FVector::ZeroVector; // 曲线点离开切线
	FRotator Rotation = FRotator::ZeroRotator;	// 曲线点旋转
	FVector Scale = FVector::OneVector;	// 曲线点缩放
	int32 PointType = 0;	// 曲线点类型

	// PointAttr
	bool IsStop = false;	// 是否站点
	float InStopDistance = 0.f;	// 站点前停车距离
	float OutStopDistance = 0.f;	// 站点后启动距离
	float StopTime = 0.f;	// 站点停车时间
};

struct FVehicleWayPathData
{
	bool ClosedLoop = false;
	
	TArray<FVehicleWayPathPointData> PathPoints;
};


// 目前仅在技能编辑器中开放使用
UENUM(BlueprintType)
enum class EDecalRotationMode : uint8
{
	Follow = 0 UMETA(DisplayName = "实时跟随释放者朝向（跟随）", ToolTip = "创建者实时朝向+Transform.Rot（偏移）, 期间实时跟随"),
	Init = 1 UMETA(DisplayName = "释放者此刻朝向（不跟随）", ToolTip = "创建者创建贴花时朝向+Transform.Rot（偏移）, 不实时更新"),
	World = 2 UMETA(DisplayName = "固定世界朝向", ToolTip = "固定的世界朝向=Transform.Rot（偏移）"),
	PointAtInstigator = 3 UMETA(DisplayName = "指向始作俑者", ToolTip = "朝向一直指向始作俑者"),
};

UENUM(BlueprintType)
enum class EDecalPositionMode : uint8
{
	Follow = 0 UMETA(DisplayName = "实时跟随释放者位置（跟随）", ToolTip = "世界位置为创建者实时位置+在指定朝向上的Transform.Pos（偏移），期间实时跟随"),
	Init = 1 UMETA(DisplayName = "释放者此刻位置（不跟随）", ToolTip = "世界位置为创建者创建贴花时位置+在指定朝向上Transform.Pos（偏移），不实时跟随"),
	World = 2 UMETA(DisplayName = "固定世界位置", ToolTip = "固定的世界位置=Transform.Pos"),
};

UENUM(BlueprintType)
enum class EDecalShapeType : uint8
{
	Rectangle UMETA(DisplayName = "矩形"),
	Circle UMETA(DisplayName = "圆形"),
	Sector UMETA(DisplayName = "扇形"),
	Ring UMETA(DisplayName = "环形"),
};

UENUM(BlueprintType)
enum class EDecalRecFillMode : uint8
{
	FillingByX UMETA(DisplayName = "沿着宽轴填充"),
	FillingByY UMETA(DisplayName = "沿着长轴填充"),
	FillingByXFromCenter UMETA(DisplayName = "由宽轴向两边填充"),
	FillingByYFromCenter UMETA(DisplayName = "由长轴向两边填充"),
};


UENUM(BlueprintType)
enum class EDecalCircleLikeFillMode : uint8
{
	FillingFromCenter UMETA(DisplayName = "从圆心向圆周填充"),
	FillingFromAround UMETA(DisplayName = "从圆周向圆心填充"),
	FillingByCounterclockwise UMETA(DisplayName = "逆时针扫描填充"),
	FillingByClockwise UMETA(DisplayName = "顺时针扫描填充"),
};

UENUM(BlueprintType)
enum class EDecalRecDissolveMode : uint8
{
	DissolveByX UMETA(DisplayName = "沿着宽轴溶解"),
	DissolveByY UMETA(DisplayName = "沿着长轴溶解"),
	DissolveByXFromCenter UMETA(DisplayName = "由宽轴向两边溶解"),
	DissolveByYFromCenter UMETA(DisplayName = "由长轴向两边溶解"),
};


UENUM(BlueprintType)
enum class EDecalCircleLikeDissolveMode : uint8
{
	DissolveFromCenter UMETA(DisplayName = "从圆心向圆周溶解"),
	DissolveFromAround UMETA(DisplayName = "从圆周向圆心溶解"),
	DissolveByCounterclockwise UMETA(DisplayName = "逆时针扫描溶解"),
	DissolveByClockwise UMETA(DisplayName = "顺时针扫描溶解"),
};

UENUM(BlueprintType)
enum class EDecalScaleMode : uint8
{
	DecalScaleMode_0 UMETA(Hidden),
	DecalScaleMode_1 UMETA(Hidden),
	DecalScaleMode_2 UMETA(Hidden),
	DecalScaleMode_3 UMETA(Hidden),
	DecalScaleMode_4 UMETA(Hidden),
	DecalScaleMode_5 UMETA(Hidden),
	DecalScaleMode_6 UMETA(Hidden),
	DecalScaleMode_7 UMETA(Hidden),
	DecalScaleMode_8 UMETA(Hidden),
	DecalScaleMode_9 UMETA(Hidden),
	DecalScaleMode_10 UMETA(Hidden),
};

UENUM(BlueprintType)
enum class EDecalPointAtTargetType : uint8
{
	None = 0 UMETA(DisplayName = "不指向"),
	Instigator = 1 UMETA(DisplayName = "指向释放者"),
};

UENUM(BlueprintType)
enum class EDecalParamModifyType : uint8
{
	ConstantValue = 0 UMETA(DisplayName = "常量值"),
	LinearSample = 1 UMETA(DisplayName = "线性采样"),
	Curve = 2 UMETA(DisplayName = "曲线"),
};

struct FKGDecalConfigKey
{
	uint32 TemplateType = 0;
	EDecalShapeType ShapeType = EDecalShapeType::Rectangle;
	uint32 ScaleMode = 0;

	bool operator==(const FKGDecalConfigKey& Other) const
	{
		return TemplateType == Other.TemplateType
			&& ShapeType == Other.ShapeType
			&& ScaleMode == Other.ScaleMode;
	}
};

inline uint32 GetTypeHash(const FKGDecalConfigKey& Key)
{
	return HashCombine(HashCombine(Key.TemplateType, static_cast<uint32>(Key.ShapeType)), Key.ScaleMode);
}

struct FKGDecalConfigData
{
	// 先仅保留一个属性, 后续可能会加
	FString MatPath;
};

UENUM(BlueprintType, Blueprintable)
enum class EGamePlaySplinePathType : uint8
{
	// 原生Spline类型，不包含任何路点相关属性
	Native = 0,
	
	// 带站点信息的路径类型，例如轨道车站点
	Station = 1
};

struct FGameplaySplinePoint
{
	float InputKey = 0.f;	// 曲线点的Key
	FVector Position = FVector::ZeroVector;	// 曲线点位置
	FVector ArriveTangent = FVector::ZeroVector; // 曲线点进入切线
	FVector LeaveTangent = FVector::ZeroVector; // 曲线点离开切线
	FRotator Rotation = FRotator::ZeroRotator;	// 曲线点旋转
	FVector Scale = FVector::OneVector;	// 曲线点缩放
	int32 PointType = 0;	// 曲线点类型
};

struct FGameplaySplineData
{
	bool ClosedLoop = false;
	
	FTransform SplineTransform = FTransform::Identity;
	
	TArray<FGameplaySplinePoint> PathPoints;
};

UENUM(BlueprintType, Blueprintable)
enum class EGamePlaySplineStationMoveType : uint8
{
	BackTrace = 0,
	TurnBack = 1,
	Single = 2,
};

struct FGameplaySplineStation
{
	bool IsStop = false;	// 是否站点
	float InStopDistance = 0.f;	// 站点前停车距离
	float OutStopDistance = 0.f;	// 站点后启动距离
	float StopTime = 0.f;	// 站点停车时间
};

struct FGameplaySplineStationData
{
	EGamePlaySplineStationMoveType MoveType = EGamePlaySplineStationMoveType::BackTrace;
	
	TArray<FGameplaySplineStation> Stations;
};