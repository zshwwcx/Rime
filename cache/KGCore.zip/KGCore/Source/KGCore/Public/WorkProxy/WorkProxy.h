/*
	使用须知：
	1、结构体中的成员变量，对于UObject不能为硬指针，请使用弱指针或者软指针！
		否则会因为野指针问题引发崩溃，因为该结构体不一定会加入到UE4的反射系统中！
*/

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "WorkProxy.generated.h"

UENUM()
enum class ETimeState : uint8
{
	// 渐入
	FadeIn,
	// 持续
	Duration,
	// 渐出
	FadeOut,
};

USTRUCT(BlueprintType)
struct KGCORE_API FWorkProxyData
{
	GENERATED_USTRUCT_BODY()

public:
	// 总生命时长(值小于0代表无限生命)
	UPROPERTY(Transient, BlueprintReadWrite)
	float TotalLife = 0.0f;

};



USTRUCT(BlueprintType)
struct KGCORE_API FWorkProxy
{
	GENERATED_USTRUCT_BODY()

public:
	FWorkProxy();
	virtual ~FWorkProxy();

	virtual void Init(int64 InDataID);

	virtual void Update(float InDeltaTime);

	virtual void DoWork(float InDeltaTime);

	virtual void FinishWork();

	//用于切换渐入渐出的状态（因为减少使用static_cast而写在了此处）
	virtual void SetState(ETimeState InState){ State = InState;};

public:
	// 唯一ID
	UPROPERTY(Transient, BlueprintReadWrite)
	int64 WorkID = 0;

	// 静态数据ID
	UPROPERTY(Transient, BlueprintReadWrite)
	int64 StaticDataID = 0;

	// 更新间隔
	UPROPERTY(Transient, BlueprintReadWrite)
	float UpdateInterval = 0.0f;

	// 上一次发生更新的运行时间
	UPROPERTY(Transient, BlueprintReadWrite)
	float LastRunningTime = 0.0f;

	// 总生命时长(值小于0代表无限生命)
	UPROPERTY(Transient, BlueprintReadWrite)
	float TotalRunTime = 0.0f;

	// 当前运行时间
	UPROPERTY(Transient, BlueprintReadWrite)
	float RunningTime = 0.0f;

	// 当前运行速率
	UPROPERTY(Transient, BlueprintReadWrite)
	float RunningRate = 1.0f;

	// 是否有效
	UPROPERTY(Transient, BlueprintReadWrite)
	bool bIsValid = false;

	// 是否完成工作
	UPROPERTY(Transient, BlueprintReadWrite)
	bool bFinishedWork = false;

	// 缓存工作代理管理器
	UPROPERTY(Transient, BlueprintReadWrite)
	TWeakObjectPtr<class UWorkProxyManager> WPMgr = nullptr;

	ETimeState State = ETimeState::FadeIn;

private:
	bool bHasFinishedWork = false;
	
};
