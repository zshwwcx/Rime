#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Tickable.h"

#include "Misc/CommonDefines.h"
#include "Manager/KGBasicManager.h"
#include "WorkProxy/WorkProxy.h"
#include "WorkProxy/OperateStack.h"

#include "LuaOverriderInterface.h"

#include "WorkProxyManager.generated.h"



DECLARE_LOG_CATEGORY_EXTERN(LogWPMgr, Log, All);



USTRUCT(BlueprintType)
struct FOSSearchKey
{
	GENERATED_USTRUCT_BODY()

public:
	FOSSearchKey() {}
	FOSSearchKey(UObject* InTarget, int32 InSign)
	{
		Target = InTarget;
		Sign = InSign;
	}

public:
	UPROPERTY(Transient)
	TWeakObjectPtr<UObject> Target;

	UPROPERTY(Transient)
	int32 Sign = 0;

	friend bool operator==(const FOSSearchKey& Val1, const FOSSearchKey& Val2)
	{
		return Val1.Target == Val2.Target && Val1.Sign == Val2.Sign;
	}

	friend uint32 GetTypeHash(const FOSSearchKey& s)
	{
		int64 PointerHash = GetTypeHash(s.Target);
		PointerHash <<= 8;
		PointerHash |= (int64)s.Sign;

		return GetTypeHash(s.Sign);
	}
};






UCLASS(Blueprintable, BlueprintType)
class KGCORE_API UWorkProxyManager : public UKGBasicManager, public ILuaOverriderInterface
{
	GENERATED_BODY()

#pragma region Important
public:
	virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Gameplay.WorkProxy.WorkProxyManager"); }

	static UWorkProxyManager* GetInstance(UObject* InContext);

	void NativeInit() override;

	void NativeUninit() override;

	virtual EManagerType GetManagerType() { return EManagerType::EMT_WorkProxyManager; }

	void CleanupManager();

protected:
	UFUNCTION(BlueprintCallable)
	void OnWorldCleanupEnd(UWorld* World, bool bSessionEnded, bool bCleanupResources);

#pragma endregion Important



#pragma region Tick
public:
	virtual void Tick(float DeltaTime) override;
	virtual void OnPostLoadMapWithWorld(UWorld* World) override;

private:
	float GCTimer = 0.0f;

#pragma endregion Tick



#pragma region OperateStack
public:
	// 请求碰撞操作栈
	UFUNCTION(BlueprintCallable)
	int64 RequestCollisionOS_P(UPrimitiveComponent* InTarget);

	// 往碰撞操作栈中添加新操作记录
	UFUNCTION(BlueprintCallable)
	int64 AddNewDataToCollisionOS(int64 InID, const FChangeCollisionMessage& InMessage, int32 InPriority = 5);

	// 替换碰撞操作栈中的记录
	UFUNCTION(BlueprintCallable)
	void ReplaceDataToCollisionOS(int64 InID, int64 InEntryID, const FChangeCollisionMessage& InMessage);
	
	// 请求组件相对信息操作栈
	UFUNCTION(BlueprintCallable)
	int64 RequestComponentRelationOS_P(USceneComponent* InTarget);

	// 往组件相对信息操作栈中添加新操作记录
	UFUNCTION(BlueprintCallable)
	int64 AddNewDataToComponentRelationOS(int64 InID, const FComponentRelativeMessage& InMessage, int32 InPriority = 5);

	// 替换组件相对信息操作栈中的记录
	UFUNCTION(BlueprintCallable)
	void ReplaceDataToComponentRelationOS(int64 InID, int64 InEntryID, const FComponentRelativeMessage& InMessage);
	
	// 请求模型相对信息操作栈
	UFUNCTION(BlueprintCallable)
	int64 RequestModelRelationOS_A(AActor* InTarget);

	// 往模型相对信息操作栈中添加新操作记录
	UFUNCTION(BlueprintCallable)
	int64 AddNewDataToModelRelationOS(int64 InID, const FModelMessage& InMessage, int32 InPriority = 5);

	// 替换模型相对信息操作栈中的记录
	UFUNCTION(BlueprintCallable)
	void ReplaceDataToModelRelationOS(int64 InID, int64 InEntryID, const FModelMessage& InMessage);
	
	// 获取操作栈ID
	UFUNCTION(BlueprintCallable)
	int64 GetOperateStackID_P(UObject* InTarget, int32 InSign);

	// 获取操作栈
	UFUNCTION(BlueprintCallable)
	UOperateStack* GetOperateStack_P(UObject* InTarget, int32 InSign);

	// 根据ID获取操作栈
	UFUNCTION(BlueprintCallable)
	UOperateStack* GetOperateStackByID(int64 InID);

	// 移除操作栈中的某条信息
	UFUNCTION(BlueprintCallable)
	void RemoveDataFromOS_P(UObject* InTarget, int32 InSign, int64 InEntryID, bool bUpdateData = true);

	// 根据ID移除操作栈中的某条信息
	UFUNCTION(BlueprintCallable)
	void RemoveDataFromOSByID(int64 InID, int64 InEntryID, bool bUpdateData = true);

	// 销毁操作栈
	UFUNCTION(BlueprintCallable)
	void DestroyOperateStack_P(UObject* InTarget, const TArray<int32>& InSigns, bool InPopToBottom = true);

	// 根据ID销毁操作栈
	UFUNCTION(BlueprintCallable)
	void DestroyOperateStackByID(const TArray<int64>& InIDs, bool InPopToBottom = true);

	// 清理操作栈
	UFUNCTION(BlueprintCallable)
	void CleanOperateStack();

	// 根据ID获取操作栈
	template<typename T>
	T* GetOperateStack(int64 InID)
	{
		for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
		{
			if (!UsingOperateStacks[i])
			{
				continue;
			}

			if (UsingOperateStacks[i]->GetID() == InID)
			{
				return (T*)UsingOperateStacks[i];
			}
		}

		return nullptr;
	}

protected:
	template<typename T>
	T* RequestOperateStack(UObject* InTarget, int32 InSign)
	{
		T* TheStack = nullptr;

		// 尝试从对象池获取
		if (FKGObjects* List = OperateStackPool.Find(T::StaticClass()))
		{
			if (List->List.Num() > 0)
			{
				TheStack = Cast<T>(List->List.Pop());
			}
		}
		// 获取失败，创建新栈
		if (!IsValid(TheStack))
		{
			TheStack = NewObject<T>(this, T::StaticClass());
		}

		if (IsValid(TheStack))
		{
			OSIDSearchMap.Add(FOSSearchKey(InTarget, InSign), TheStack->GetID());
			UsingOperateStacks.Add(TheStack);
		}

		return TheStack;
	}

	void UpdateOperateStacks(float InDeltaTime);

	void CleanOperateStackTrash();

protected:
	// 操作栈对象缓存池大小
	UPROPERTY(Transient, BlueprintReadWrite)
	int32 OSPoolSize = 50;

	// 操作栈对象缓存池
	UPROPERTY(Transient, BlueprintReadWrite)
	TMap<UClass*, FKGObjects> OperateStackPool;

	// 正在使用的操作栈列表
	UPROPERTY(Transient, BlueprintReadWrite)
	TArray<UOperateStack*> UsingOperateStacks;

	// 根据目标和标记找到正在使用的操作栈ID
	UPROPERTY(Transient, BlueprintReadWrite)
	TMap<FOSSearchKey, int64> OSIDSearchMap;

#pragma endregion OperateStack



#pragma region WorkProxy
public:
	// 强制执行某个工作代理
	UFUNCTION(BlueprintCallable)
	void WorkProxyDoWork(int64 InWPID, float InDeltaTime);

	// 强制执行某些工作代理
	UFUNCTION(BlueprintCallable)
	void WorkProxiesDoWork(const TArray<int64>& InWPIDs, float InDeltaTime);

	// 撤销工作代理
	UFUNCTION(BlueprintCallable)
	void CancelWorkProxy(int64 InWPID);

	// 撤销多个工作代理
	UFUNCTION(BlueprintCallable)
	void CancelWorkProxies(const TArray<int64>& InWPIDs);

	// 修改工作代理的总生命时长
	UFUNCTION(BlueprintCallable)
	void ChangeWorkProxyTotalLife(int64 InWPID, float InTotalLife);

	// 修改多个工作代理的总生命时长
	UFUNCTION(BlueprintCallable)
	void ChangeWorkProxiesTotalLife(const TArray<int64>& InWPIDs, float TotalLife);

	// 修改工作代理的当前生命时长
	UFUNCTION(BlueprintCallable)
	void ChangeWorkProxyCurrentLife(int64 InWPID, float InLife);

	// 修改多个工作代理的当前生命时长
	UFUNCTION(BlueprintCallable)
	void ChangeWorkProxiesCurrentLife(const TArray<int64>& InWPIDs, float InLife);

	// 修改工作代理的更新间隔
	UFUNCTION(BlueprintCallable)
	void ChangeWorkProxyUpdateInterval(int64 InWPID, float InUpdateInterval);

	// 修改多个工作代理的更新间隔
	UFUNCTION(BlueprintCallable)
	void ChangeWorkProxiesUpdateInterval(const TArray<int64>& InWPIDs, float InUpdateInterval);

	// 修改工作代理的更新系数
	UFUNCTION(BlueprintCallable)
	void ChangeWorkProxyUpdateRate(int64 InWPID, float InUpdateRate);

	// 修改多个工作代理的更新系数
	UFUNCTION(BlueprintCallable)
	void ChangeWorkProxiesUpdateRate(const TArray<int64>& InWPIDs, float InUpdateRate);

	// 修改工作代理静态数据的引用计数
	UFUNCTION(BlueprintCallable)
	void ChangeWorkProxyDataReference(int64 InDataID, int32 InDelta);

	// 脚本获取所有正在运行的工作代理ID
	UFUNCTION(BlueprintCallable)
	void ScriptGetAllRunningWorkProxyID();

	//申请缩放模型工作代理
	UFUNCTION(BlueprintCallable)
	int64 RequestWPModelScale_P(FVector InScaleRate, AActor* InTarget, float FadeInTime, UCurveFloat* InFadeInCurve, float InDuration, float InFadeOutTime, UCurveFloat* InFadeOutCurve, uint8 InPriority = 3 );

	//申请缩放结束工作代理，用于打断后渐出
	UFUNCTION(BlueprintCallable)
	void RequestWPModelScaleEnd(int64 InWPID);
	
	// 脚本推送标量到原生层
	UFUNCTION(BlueprintCallable)
	void WorkProxyScriptPushScalar(int64 InID, int32 InIndex, float InValue = 0.0f);

	// 脚本推送向量到原生层
	UFUNCTION(BlueprintCallable)
	void WorkProxyScriptPushVector(int64 InID, int32 InIndex, float X = 0.0f, float Y = 0.0f, float Z = 0.0f, float W = 0.0f);

	// 撤销脚本推送的数据
	UFUNCTION(BlueprintCallable)
	void CancelWorkProxyScriptData(int64 InID);
	
	// 缓存工作代理的静态数据
	template<typename T>
	int64 CacheWorkProxyData(const T* InData)
	{
		if (!InData)
		{
			return -1;
		}

		UScriptStruct* StructType = InData->StaticStruct();
		if (!IsValid(StructType))
		{
			return -1;
		}

		int64 NewID = ULowLevelFunctions::GetGlobalUniqueID();

		FStructOnScope& NewWPD = WorkProxyDataMap.Add(NewID, FStructOnScope(StructType));
		StructType->CopyScriptStruct(NewWPD.GetStructMemory(), (uint8*)InData);

		return NewID;
	}

	// 根据ID获取工作代理的静态数据
	template<typename T>
	const T* GetWorkProxyDataByID(int64 InID)
	{
		FStructOnScope* FindResult = WorkProxyDataMap.Find(InID);
		if (!FindResult)
		{
			return nullptr;
		}

		if (UScriptStruct* StructType = T::StaticStruct())
		{
			return (FindResult->IsValid() && FindResult->GetStruct()->IsChildOf(StructType)) ? (T*)(FindResult->GetStructMemory()) : nullptr;

		}

		return nullptr;
	}
	
	// 注册新的工作代理
	template<typename T>
	T* RegisterWorkProxy()
	{
		UScriptStruct* InStructType = T::StaticStruct();

		if (!InStructType || !InStructType->IsChildOf(FWorkProxy::StaticStruct()))
		{
			return nullptr;
		}

		FStructOnScope& NewWP = RunningProxys.Add_GetRef(FStructOnScope(InStructType));
		if (!NewWP.IsValid())
		{
			return nullptr;
		}

		if (FWorkProxy* WP = (FWorkProxy*)NewWP.GetStructMemory())
		{
			WP->WPMgr = this;

			return (T*)WP;
		}

		return nullptr;
	}

	// 根据ID获取工作代理
	template<typename T>
	T* GetWorkProxy(int64 InID)
	{
		for (int32 i = 0; i < RunningProxys.Num(); ++i)
		{
			if (!RunningProxys[i].IsValid())
			{
				continue;
			}

			if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
			{
				if (WP->WorkID == InID)
				{
					return (T*)WP;
				}
			}
		}

		return nullptr;
	}

	// 更新工作代理
	void UpdateWorkProxys(float InDeltaTime);

	// 清理工作代理
	void ClearWorkProxy();

	// 清理工作代理的垃圾数据
	void CleanWorkProxyTrash();
	
	// 获取管理器缓存的脚本推送标量数据
	bool GetScriptScalar(int64 InPushID, int32 InIndex, float& OutValue);

	// 获取管理器缓存的脚本推送向量数据
	bool GetScriptVector(int64 InPushID, int32 InIndex, FVector4& OutValue);	

protected:
	// 脚本推送的工作代理标量数据
	TMap<int64, TMap<int32, float>> WorkProxyScriptScalars;

	// 脚本推送的工作代理向量数据
	TMap<int64, TMap<int32, FVector4>> WorkProxyScriptVectors;

	// 正在运行的工作代理
	TArray<FStructOnScope> RunningProxys;

	// 缓存的工作代理静态数据
	TMap<int64, FStructOnScope> WorkProxyDataMap;

	// 工作代理静态数据的引用次数
	UPROPERTY(Transient, BlueprintReadWrite)
	TMap<int64, int32> WorkProxyDataReferenceMap;

#pragma endregion WorkProxy

};

