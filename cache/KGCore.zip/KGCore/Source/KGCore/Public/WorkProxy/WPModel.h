﻿#pragma once

#include "CoreMinimal.h"

#include "WorkProxy/WorkProxy.h"
#include "WorkProxy/OperateStackStructs.h"
#include "Components/CapsuleComponent.h"

#include "WPModel.generated.h"

//归一化参数
USTRUCT(BlueprintType)
struct FCurveNormalParams
{
	GENERATED_USTRUCT_BODY()

public:	
	float MinTime = 0;
	float MaxTime = 0;
	float MinValue = 0;
	float MaxValue = 0;
};

USTRUCT(BlueprintType)
struct FWPModelScale : public FWorkProxy
{
	GENERATED_USTRUCT_BODY()

public:
	void Init(int64 InDataID) override;

	void DoWork(float InDeltaTime) override;

	void FinishWork() override;

	static void SetCurveNormal(UCurveFloat* Curve, FCurveNormalParams& OutCurveNormal);

	static float GetCurveNormalValue(const UCurveFloat* Curve, const FCurveNormalParams CurveNormalParams, float Pct);

	void SetState(ETimeState InState) override;
public:
	// 缩放倍率
	UPROPERTY(Transient, BlueprintReadWrite)
	FVector ScaleRate = FVector::OneVector;
	
	//渐入时间
	UPROPERTY(Transient, BlueprintReadWrite)
	float FadeInTime = 0.0f;

	//持续时间
	UPROPERTY(Transient, BlueprintReadWrite)
	float Duration = 0.0f;

	//渐出时间
	UPROPERTY(Transient, BlueprintReadWrite)
	float FadeOutTime = 0.0f;

	//渐入曲线
	UPROPERTY(Transient, BlueprintReadWrite)
	TWeakObjectPtr<UCurveFloat> FadeInCurve;

	//渐出曲线
	UPROPERTY(Transient, BlueprintReadWrite)
	TWeakObjectPtr<UCurveFloat> FadeOutCurve;

	//要缩放的actor
	UPROPERTY(Transient, BlueprintReadWrite)
	TWeakObjectPtr<AActor> Actor;

private:
	// 操作堆栈ID
	int64 ROSID = 0;

	// 操作记录ID
	int64 ROSEntryID = 0;

	// 操作栈信息
	FModelMessage CRM;

	// 原始相对尺寸
	FVector OriginScale = FVector::OneVector;
	
	float StateDuration = 0.0f;

	FCurveNormalParams FadeInCurveNormal;
	FCurveNormalParams FadeOutCurveNormal;
	
	TWeakObjectPtr<UCapsuleComponent> Capsule;
};