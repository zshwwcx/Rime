#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "Materials/MaterialInstance.h"
#include "WorkProxy/OperateStackStructs.h"

#include "OperateStack.generated.h"



DECLARE_STATS_GROUP(TEXT("OperateStack"), STATGROUP_OperateStack, STATCAT_Advanced);
DECLARE_DWORD_ACCUMULATOR_STAT(TEXT("OperateStack"), STAT_OSNum, STATGROUP_OperateStack);
DECLARE_DWORD_ACCUMULATOR_STAT(TEXT("OperateStackData"), STAT_OSDataNum, STATGROUP_OperateStack);



struct OSData
{
public:
	OSData() {}

	OSData(int64 InID, int64 InSmallData, uint32 InPriority) : UniqueID(InID), SmallData(InSmallData), Priority(InPriority) {}

	OSData(int64 InID, void* InDataAdress, uint32 InPriority) : UniqueID(InID), DataAddress(InDataAdress), Priority(InPriority) {}

public:
	int64 UniqueID = 0;

	int64 SmallData = 0;

	void* DataAddress = nullptr;

	uint8 Priority = 0;

};

UCLASS(Transient, BlueprintType, Blueprintable)
class KGCORE_API UOperateStack : public UObject
{
	GENERATED_BODY()

	friend class UOperateStackFunctionLibrary;

#pragma region Important
public:
	UOperateStack(const FObjectInitializer& ObjectInitializer);
	virtual ~UOperateStack();

	// 销毁操作栈
	UFUNCTION(BlueprintCallable)
	virtual void DestroyOS(bool InPopToBottom = true);

	// 初始化操作栈
	template<typename T>
	void InitOS(const T& OriginData, UScriptStruct* InStructType, UObject* InModifyTarget, UObject* InFunctionOwner, FName InFunctionName)
	{
		InternalInitOS(&OriginData, InStructType, InModifyTarget, InFunctionOwner, InFunctionName);
	}

	// 添加新操作记录
	template<typename T>
	int64 AddNewData(const T& NewData, UScriptStruct* InStructType, int32 Priority = 0)
	{
		return InternalAddNewData(&NewData, InStructType, Priority);
	}

	// 替换操作记录
	template<typename T>
	void ReplaceEntryData(const T& NewData, UScriptStruct* InStructType, int64 InID)
	{
		InternalReplaceEntryData(&NewData, InStructType, InID);
	}

	// 移除操作记录
	UFUNCTION(BlueprintCallable)
	virtual void RemoveOldData(int64 InID, bool bUpdateData = true);

	// 弹出至栈底
	UFUNCTION(BlueprintCallable)
	virtual void PopToBottom();

	// 清除所有操作记录
	UFUNCTION(BlueprintCallable)
	virtual void ClearAllData(bool InPopToBottom = true);

	// 获取操作栈ID
	UFUNCTION(BlueprintPure)
	int64 GetID();

	// 该操作栈是否合法
	UFUNCTION(BlueprintPure)
	bool CheckOSIsLegal();

	// 设置该操作栈的操作记录目标
	UFUNCTION(BlueprintCallable)
	void SetModifyTarget(UObject* InTarget) { ModifyTarget = InTarget; }

	// 获取该操作栈的操作记录目标
	UFUNCTION(BlueprintPure)
	UObject* GetModifyTarget() { return ModifyTarget.Get(); }

	// 获取该操作栈的数据类型
	UFUNCTION(BlueprintPure)
	UScriptStruct* GetStructType() { return StructType; }

	// 获取该操作栈的记录数量
	UFUNCTION(BlueprintPure)
	virtual int32 GetEntriesNum() { return DataAddresses.Num(); }

	// 获取该操作栈的记录数据
	template<typename T>
	T* GetEntry(int64 InID)
	{
		for (int32 i = 0; i < DataAddresses.Num(); ++i)
		{
			if (DataAddresses[i].UniqueID == InID)
			{
				if (DataAddresses[i].DataAddress == nullptr)
				{
					return (T*)(&DataAddresses[i].SmallData);
				}
				else
				{
					return (T*)(DataAddresses[i].DataAddress);
				}
			}
		}

		return nullptr;
	}

	template<typename T>
	T* GetEntryByIndex(int32 InIndex)
	{
		if (DataAddresses.IsValidIndex(InIndex))
		{
			if (DataAddresses[InIndex].DataAddress == nullptr)
			{
				return (T*)(&DataAddresses[InIndex].SmallData);
			}
			else
			{
				return (T*)(DataAddresses[InIndex].DataAddress);
			}
		}

		return nullptr;
	}

protected:
	virtual void InternalInitOS(const void* InOriginDataAddress, UScriptStruct* InStructType, UObject* InModifyTarget, UObject* InFunctionOwner, FName InFunctionName);

	virtual int64 InternalAddNewData(const void* InDataAddress, UScriptStruct* InStructType, int32 Priority = 0);

	virtual void InternalReplaceEntryData(const void* InDataAddress, UScriptStruct* InStructType, int64 InID);

	virtual void UpdateTargetByLatestData();

	void* GetDataAddressFromPool();

	void SetDataAddressToPool(void* TheAddress);

protected: 
	// 操作栈数据集
	TArray<OSData> DataAddresses;

	// 操作栈ID
	UPROPERTY(Transient)
	int64 ID = 0;

	// 操作栈目标
	UPROPERTY(Transient)
	TWeakObjectPtr<UObject> ModifyTarget = nullptr;

	// 该操作栈条目的结构类型
	UPROPERTY(Transient)
	UScriptStruct* StructType = nullptr;

	// 更新函数
	UPROPERTY(Transient)
	UFunction* TheFunction = nullptr;

	// 更新函数的拥有者
	UPROPERTY(Transient)
	UObject* FunctionOwner = nullptr;

	// 更新函数的参数内存
	uint64* UpdateFuncParm = nullptr;

	// 当前所有申请并且未释放的内存地址
	TArray<void*> AllMallocAddress;

#pragma endregion Important



#pragma region BPAPI
	UFUNCTION(BlueprintCallable, CustomThunk, meta = (DefaultToSelf = "Object", CustomStructureParam = "OriginData"))
	void InitOS(const FOSData_Material& OriginData, UObject* InModifyTarget, UObject* InFunctionOwner, FName InFunctionName);
	DECLARE_FUNCTION(execInitOS)
	{
		Stack.MostRecentProperty = nullptr;

		// 更新蓝图虚拟机栈顶指针
		Stack.StepCompiledIn<FProperty>(nullptr);

		// 获取备忘数据的地址
		void* DataAddress = Stack.MostRecentPropertyAddress;

		// 获取第一个参数的反射信息
		FProperty* DataProperty = CastField<FProperty>(Stack.MostRecentProperty);
		if (!DataProperty)
			return;

		// 获取修改目标
		P_GET_OBJECT(UObject, ModifyTarget);
		
		// 获取函数拥有者
		P_GET_OBJECT(UObject, FunctionOwner);

		// 获取函数名称
		P_GET_PROPERTY(FNameProperty, FunctionName);

		// 停止对蓝图栈的使用
		P_FINISH;

		P_NATIVE_BEGIN;
		if (FStructProperty* StrPro = CastField<FStructProperty>(DataProperty))
			P_THIS_CAST(UOperateStack)->InternalInitOS(DataAddress, StrPro->Struct, ModifyTarget, FunctionOwner, FunctionName);
		else
			P_THIS_CAST(UOperateStack)->InternalInitOS(DataAddress, nullptr, ModifyTarget, FunctionOwner, FunctionName);
		P_NATIVE_END;
	}

	UFUNCTION(BlueprintCallable, CustomThunk, meta = (DefaultToSelf = "Object", CustomStructureParam = "TheData"))
	void AddNewData(const FOSData_Material& TheData, int32 Priority = 0);
	DECLARE_FUNCTION(execAddNewData)
	{
		Stack.MostRecentProperty = nullptr;

		// 更新蓝图虚拟机栈顶指针
		Stack.StepCompiledIn<FProperty>(nullptr);

		// 获取备忘数据的地址
		void* DataAddress = Stack.MostRecentPropertyAddress;

		// 获取第一个参数的反射信息
		FProperty* DataProperty = CastField<FProperty>(Stack.MostRecentProperty);
		if (!DataProperty)
			return;

		// 获取优先级
		P_GET_UBOOL32(Priority);

		// 停止对蓝图栈的使用
		P_FINISH;

		P_NATIVE_BEGIN;
		if (FStructProperty* StrPro = CastField<FStructProperty>(DataProperty))
			P_THIS_CAST(UOperateStack)->InternalAddNewData(DataAddress, StrPro->Struct, Priority);
		else
			P_THIS_CAST(UOperateStack)->InternalAddNewData(DataAddress, nullptr, Priority);
		P_NATIVE_END;
	}

	UFUNCTION(BlueprintCallable, CustomThunk, meta = (DefaultToSelf = "Object", CustomStructureParam = "TheData"))
	void ReplaceEntryData(const FOSData_Material& TheData, int64 InID);
	DECLARE_FUNCTION(execReplaceEntryData)
	{
		Stack.MostRecentProperty = nullptr;

		// 更新蓝图虚拟机栈顶指针
		Stack.StepCompiledIn<FProperty>(nullptr);

		// 获取备忘数据的地址
		void* DataAddress = Stack.MostRecentPropertyAddress;

		// 获取第一个参数的反射信息
		FProperty* DataProperty = CastField<FProperty>(Stack.MostRecentProperty);
		if (!DataProperty)
			return;

		// 获取修改ID
		P_GET_PROPERTY(FInt64Property, CurID);

		// 停止对蓝图栈的使用
		P_FINISH;

		P_NATIVE_BEGIN;
		if (FStructProperty* StrPro = CastField<FStructProperty>(DataProperty))
			P_THIS_CAST(UOperateStack)->InternalReplaceEntryData(DataAddress, StrPro->Struct, CurID);
		else
			P_THIS_CAST(UOperateStack)->InternalReplaceEntryData(DataAddress, nullptr, CurID);
		P_NATIVE_END;
	}

#pragma endregion BPAPI



#pragma region Help
public:
	USceneComponent* GetComponentByNameAndClass(AActor* InActor, const FString& InName, UClass* InClass = nullptr);

#pragma endregion Help

};


#pragma region Collision
UCLASS(Transient, BlueprintType, Blueprintable)
class KGCORE_API UCollisionOS : public UOperateStack
{
	GENERATED_BODY()

protected:
	void UpdateTargetByLatestData() override;

};

#pragma endregion Collision






#pragma region Relation
UCLASS(Transient, BlueprintType, Blueprintable)
class KGCORE_API URelationOS : public UOperateStack
{
	GENERATED_BODY()

protected:
	void UpdateTargetByLatestData() override;

};

#pragma endregion Relation


#pragma region Model
UCLASS(Transient, BlueprintType, Blueprintable)
class KGCORE_API UModelOS : public UOperateStack
{
	GENERATED_BODY()
protected:
	void UpdateTargetByLatestData() override;
};

#pragma endregion Model