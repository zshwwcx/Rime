#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "WorkProxy/OperateStackEnums.h"
#include "Materials/MaterialInterface.h"

#include "OperateStackStructs.generated.h"



#pragma region Material
USTRUCT(BlueprintType)
struct FOSData_Material
{
	GENERATED_USTRUCT_BODY()

public:
	// 全局ID
	int64 UniqueID = 0;

	// 优先级
	uint8 Priority = 0;

	// 材质修改规则: 0、使用上一层材质；1、使用新材质；
	uint8 ModifyRule = 0;

	// 材质模板
	UPROPERTY(Transient)
	UMaterialInterface* Material = nullptr;


	// 标量参数
	// UPROPERTY(Transient)
	// TArray<FRMaterialScalar> Scalars;

	// 新的覆盖标量参数值
	UPROPERTY(Transient)
	TMap<FName, float> NewScalarValues;

	// 继承下来的覆盖标量参数值
	UPROPERTY(Transient)
	TMap<FName, float> InheritedScalarValues;


	// 向量参数
	// UPROPERTY(Transient)
	// TArray<FRMaterialVector> Vectors;

	// 新的覆盖向量参数值
	UPROPERTY(Transient)
	TMap<FName, FLinearColor> NewVectorValues;

	// 继承下来的覆盖向量参数值
	UPROPERTY(Transient)
	TMap<FName, FLinearColor> InheritedVectorValues;


	// 纹理参数
	// UPROPERTY(Transient)
	// TArray<FRMaterialTexture> Textures;

	// 新的覆盖纹理参数值
	UPROPERTY(Transient)
	TMap<FName, UTexture*> NewTextureValues;

	// 继承下来的覆盖纹理参数值
	UPROPERTY(Transient)
	TMap<FName, UTexture*> InheritedTextureValues;

public:
	void operator=(const FOSData_Material& Other)
	{
		UniqueID = Other.UniqueID;
		Priority = Other.Priority;
		ModifyRule = Other.ModifyRule;
		Material = Other.Material;

		// Scalars.Empty();
		// Scalars.Append(Other.Scalars);
		NewScalarValues.Empty();
		NewScalarValues.Append(Other.NewScalarValues);
		InheritedScalarValues.Empty();
		InheritedScalarValues.Append(Other.InheritedScalarValues);

		// Vectors.Empty();
		// Vectors.Append(Other.Vectors);
		NewVectorValues.Empty();
		NewVectorValues.Append(Other.NewVectorValues);
		InheritedVectorValues.Empty();
		InheritedVectorValues.Append(Other.InheritedVectorValues);

		// Textures.Empty();
		// Textures.Append(Other.Textures);
		NewTextureValues.Empty();
		NewTextureValues.Append(Other.NewTextureValues);
		InheritedTextureValues.Empty();
		InheritedTextureValues.Append(Other.InheritedTextureValues);
	}
};

USTRUCT(BlueprintType)
struct FOSData_MaterialList
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(Transient)
	TArray<FOSData_Material> List;
};

#pragma endregion Material






#pragma region Component
USTRUCT(BlueprintType, Blueprintable)
struct FComponentRelativeMessage
{
	GENERATED_USTRUCT_BODY()

public:
	// 组件的变量名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	FName ComponentVarName = TEXT("Mesh");


	// 是否修改组件的挂载者
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeParent = false;
	// 组件的新挂载者名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (EditCondition = "bNeedChangeParent"))
	FName NewAttachParentName = NAME_None;

	// 是否修改组件的挂载点
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeSocket = false;
	// 组件的新挂载点
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (EditCondition = "bNeedChangeSocket"))
	FName NewAttachSocketName = NAME_None;

	// 是否修改组件的绝对性
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeAbsolute = false;
	// 组件的新绝对性设置(小于等于0为false, 大于0为true)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (EditCondition = "bNeedChangeAbsolute"))
	FVector NewAbsolute = FVector(-1.0f, -1.0f, -1.0f);

	// 是否修改组件的相对位置
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeRelativeLocation = false;
	// 组件的新相对位置
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (EditCondition = "bNeedChangeRelativeLocation"))
	FVector NewRelativeLocation = FVector::ZeroVector;

	// 是否修改组件的相对朝向
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeRelativeRotation = false;
	// 组件的新相对朝向
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (EditCondition = "bNeedChangeRelativeRotation"))
	FRotator NewRelativeRotation = FRotator::ZeroRotator;

	// 是否修改组件的相对缩放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeRelativeScale = false;
	// 组件的新相对缩放
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Transform", meta = (EditCondition = "bNeedChangeRelativeScale"))
	FVector NewRelativeScale = FVector::OneVector;

public:
	void Reset()
	{
		ComponentVarName = TEXT("Mesh");
		bNeedChangeParent = false;
		NewAttachParentName = NAME_None;
		bNeedChangeSocket = false;
		NewAttachSocketName = NAME_None;
		bNeedChangeAbsolute = false;
		NewAbsolute.X = -1.0f;
		NewAbsolute.Y = -1.0f;
		NewAbsolute.Z = -1.0f;
		bNeedChangeRelativeLocation = false;
		NewRelativeLocation = FVector::ZeroVector;
		bNeedChangeRelativeRotation = false;
		NewRelativeRotation = FRotator::ZeroRotator;
		bNeedChangeRelativeScale = false;
		NewRelativeScale = FVector::OneVector;
	}

	void operator=(const FComponentRelativeMessage& Other)
	{
		ComponentVarName = Other.ComponentVarName;
		bNeedChangeParent = Other.bNeedChangeParent;
		NewAttachParentName = Other.NewAttachParentName;
		bNeedChangeSocket = Other.bNeedChangeSocket;
		NewAttachSocketName = Other.NewAttachSocketName;
		bNeedChangeAbsolute = Other.bNeedChangeAbsolute;
		NewAbsolute = Other.NewAbsolute;
		bNeedChangeRelativeLocation = Other.bNeedChangeRelativeLocation;
		NewRelativeLocation = Other.NewRelativeLocation;
		bNeedChangeRelativeRotation = Other.bNeedChangeRelativeRotation;
		NewRelativeRotation = Other.NewRelativeRotation;
		bNeedChangeRelativeScale = Other.bNeedChangeRelativeScale;
		NewRelativeScale = Other.NewRelativeScale;
	}
};

#pragma endregion Component






#pragma region Collision
USTRUCT(BlueprintType, Blueprintable)
struct FCollisionChannelInfo
{
	GENERATED_USTRUCT_BODY()

public:
	FCollisionChannelInfo() {}
	FCollisionChannelInfo(ECollisionChannel Channel, ECollisionResponse Response) : NewCollisionChannel(Channel), NewCollisionResponse(Response) {}

public:
	// 碰撞通道
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<ECollisionChannel> NewCollisionChannel = ECollisionChannel::ECC_WorldStatic;

	// 碰撞通道对应的策略
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<ECollisionResponse> NewCollisionResponse = ECollisionResponse::ECR_Ignore;

};

USTRUCT(BlueprintType, Blueprintable)
struct FChangeCollisionMessage
{
	GENERATED_USTRUCT_BODY()

public:
	// 组件的变量名称
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	FName ComponentVarName = TEXT("CapsuleComponent");


	// 覆盖碰撞盒尺寸
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	bool bOverrideCollisionBoxSize = false;
	// 修改碰撞盒的尺寸(bOverrideCollisionBoxSize为true时覆盖值，为false是缩放值)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	FVector CollisionBoxSize = FVector(1.0f, 1.0f, 1.0f);

	// 碰撞通道覆盖信息
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base")
	TArray<FCollisionChannelInfo> NewCollisionChannelInfos;

	// 是否修改ObjectType
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base", meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeObjectType = false;
	// 新的ObjectType
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base", meta = (EditCondition = "bNeedChangeObjectType"))
	TEnumAsByte<EObjectTypeQuery> NewObjectType = EObjectTypeQuery::ObjectTypeQuery1;

	// 是否修改碰撞状态
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base", meta = (PinHiddenByDefault, InlineEditConditionToggle))
	bool bNeedChangeCollisionState = false;
	// 新的碰撞状态
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Base", meta = (EditCondition = "bNeedChangeCollisionState"))
	TEnumAsByte<ECollisionEnabled::Type> NewCollisionState = ECollisionEnabled::Type::NoCollision;

public:
	void Reset()
	{
		ComponentVarName = TEXT("CapsuleComponent");
		bOverrideCollisionBoxSize = false;
		CollisionBoxSize.X = 1.0f;
		CollisionBoxSize.Y = 1.0f;
		CollisionBoxSize.Z = 1.0f;
		NewCollisionChannelInfos.Empty();
		bNeedChangeObjectType = false;
		NewObjectType = EObjectTypeQuery::ObjectTypeQuery1;
		bNeedChangeCollisionState = false;
		NewCollisionState = ECollisionEnabled::Type::NoCollision;
	}

	void operator=(const FChangeCollisionMessage& Other)
	{
		ComponentVarName = Other.ComponentVarName;
		bOverrideCollisionBoxSize = Other.bOverrideCollisionBoxSize;
		CollisionBoxSize = Other.CollisionBoxSize;
		NewCollisionChannelInfos.Empty();
		NewCollisionChannelInfos.Append(Other.NewCollisionChannelInfos);
		bNeedChangeObjectType = Other.bNeedChangeObjectType;
		NewObjectType = Other.NewObjectType;
		bNeedChangeCollisionState = Other.bNeedChangeCollisionState;
		NewCollisionState = Other.NewCollisionState;
	}
};

#pragma endregion Collision





#pragma region Model
USTRUCT(BlueprintType, Blueprintable)
struct FModelMessage
{
	GENERATED_USTRUCT_BODY()
public:
	// 组件的新相对缩放
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector NewRelativeScale = FVector::OneVector;

	// 组件的新相对缩放后的位置
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float NewRelativeLocationZ = 0.f;

public:
	void Reset()
	{
		NewRelativeScale = FVector::OneVector;
		NewRelativeLocationZ = 0.f;
	}

	void operator=(const FModelMessage& Other)
	{
		NewRelativeScale = Other.NewRelativeScale;
		NewRelativeLocationZ = Other.NewRelativeLocationZ;
	}
};

#pragma endregion Model