#pragma once

#include "CoreMinimal.h"

#include "GameplayTagContainer.h"
#include "Components/MeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"

#include "Curve/KGCurve.h"
#include "Misc/LowLevelFunctions.h"

#include "OSMaterialInstance.generated.h"



#pragma region Enums
UENUM(BlueprintType)
enum class EMaterialParameterUsingType : uint8
{
	MPT_UseRangeValue         = 0			UMETA(DisplayName = "对上下限参数进行线性插值"),
	MPT_UseCurveValue						UMETA(DisplayName = "采样曲线"),
	MPT_ReserveOldValue                     UMETA(DisplayName = "保留旧数值"),
	MPT_UseManagerValue				        UMETA(DisplayName = "使用管理器的缓存数据(适用于非常特殊的逻辑)"),
	MPT_UseSpecialValue						UMETA(DisplayName = "使用特定的逻辑"),

	MPT_TMax
};
#pragma endregion Enums



#pragma region ConfigStructs
USTRUCT(BlueprintType)
struct KGCORE_API FMaterialParameterBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "BaseParameter")
	FName ParameterName;

};

USTRUCT(BlueprintType)
struct KGCORE_API FMaterialTextureParameter : public FMaterialParameterBase
{
	GENERATED_BODY()

public:
	// 想要替换的纹理贴图，不填代表保留旧的贴图
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Parameter")
	TSoftObjectPtr<class UTexture> NewTexture = nullptr;

public:
	void operator=(const FMaterialTextureParameter& Other)
	{
		ParameterName = Other.ParameterName;

		NewTexture = Other.NewTexture;
	}
};

USTRUCT(BlueprintType)
struct KGCORE_API FMaterialScalarParameter : public FMaterialParameterBase
{
	GENERATED_BODY()

public:
	// 默认数值
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float DefaultValue = 0.0f;

	// 数据使用类型
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EMaterialParameterUsingType ParameterType = EMaterialParameterUsingType::MPT_UseRangeValue;


	// 下限值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseRangeValue", EditConditionHides))
	float MinValue = 0.0;

	// 上限值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseRangeValue", EditConditionHides))
	float MaxValue = 0.0;


	// 待采样曲线
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseCurveValue", EditConditionHides))
	FKGRemapFloatCurve FloatCurve;

	// 是否需要循环采样曲线
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseCurveValue", EditConditionHides))
	bool bNeedLoop = false;


	// 数据索引
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseManagerValue", EditConditionHides))
	int32 DataIndex = 0;

public:
	void operator=(const FMaterialScalarParameter& Other)
	{
		DefaultValue = Other.DefaultValue;

		ParameterName = Other.ParameterName;
		ParameterType = Other.ParameterType;

		MinValue = Other.MinValue;
		MaxValue = Other.MaxValue;

		FloatCurve = Other.FloatCurve;
		bNeedLoop = Other.bNeedLoop;

		DataIndex = Other.DataIndex;
	}

};

USTRUCT(BlueprintType)
struct KGCORE_API FMaterialVectorParameter : public FMaterialParameterBase
{
	GENERATED_BODY()

public:
	// 默认数值
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor DefaultValue = FLinearColor::Black;

	// 数据使用类型
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EMaterialParameterUsingType ParameterType = EMaterialParameterUsingType::MPT_UseRangeValue;


	// 下限值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseRangeValue", EditConditionHides))
	FLinearColor MinValue = FLinearColor::Black;

	// 上限值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseRangeValue", EditConditionHides))
	FLinearColor MaxValue = FLinearColor::Black;


	// 待采样曲线
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseCurveValue", EditConditionHides))
	FKGRemapColorCurve ColorCurve;

	// 是否需要循环采样曲线
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseCurveValue", EditConditionHides))
	bool bNeedLoop = false;


	// 数据索引
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseManagerValue", EditConditionHides))
	int32 DataIndex = 0;


	// 特定逻辑
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Meta = (EditCondition = "ParameterType == EMaterialParameterUsingType::MPT_UseSpecialValue", EditConditionHides))
	FGameplayTag SpecialLogicTag;

public:
	void operator=(const FMaterialVectorParameter& Other)
	{
		DefaultValue = Other.DefaultValue;

		ParameterName = Other.ParameterName;
		ParameterType = Other.ParameterType;

		MinValue = Other.MinValue;
		MaxValue = Other.MaxValue;

		ColorCurve = Other.ColorCurve;
		bNeedLoop = Other.bNeedLoop;

		DefaultValue = Other.DefaultValue;
		DataIndex = Other.DataIndex;

		SpecialLogicTag = Other.SpecialLogicTag;
	}

};

USTRUCT(BlueprintType)
struct KGCORE_API FOverrideMaterialParameter
{
	GENERATED_USTRUCT_BODY()

public:
	// 替换优先级
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MaterialIndex")
	uint8 Priority = 5;

	// 是否替换全部材质
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MaterialIndex")
	bool bReplaceAllMaterial = false;

	/*
	*  当ReplaceAllMaterial为false的时候：代表想要替换的材质ID
	*  当ReplaceAllMaterial为true的时候：代表不想要替换的材质ID
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MaterialIndex")
	TArray<int32> MaterialIDs;

	/*
	*  当ReplaceAllMaterial为false的时候：代表想要替换的材质Slot名称
	*  当ReplaceAllMaterial为true的时候：代表不想要替换的材质Slot名称
	*  名称为"SPECIAL_OVERLAY"代表的是 OverlayMaterial 这个变量
	*  名称为"SPECIAL_CUSTOM"代表的是 CustomPrimitiveData 功能
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MaterialIndex")
	TArray<FName> MaterialSlotNames;



	// 想要替换的新材质（如果为NULL，代表只修改参数）
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MaterialParameter")
	TSoftObjectPtr<UMaterialInstance> ReplaceMaterial = nullptr;

	// 纹理参数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MaterialParameter")
	TArray<FMaterialTextureParameter> MaterialTextureParamValues;

	// 标量参数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MaterialParameter")
	TArray<FMaterialScalarParameter> MaterialScalarParamValues;

	// 向量参数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MaterialParameter")
	TArray<FMaterialVectorParameter> MaterialVectorParamValues;


public:
	void operator=(const FOverrideMaterialParameter& Other)
	{
		Priority = Other.Priority;
		bReplaceAllMaterial = Other.bReplaceAllMaterial;

		MaterialIDs.Empty();
		MaterialIDs.Append(Other.MaterialIDs);

		MaterialSlotNames.Empty();
		MaterialSlotNames.Append(Other.MaterialSlotNames);

		ReplaceMaterial = Other.ReplaceMaterial;

		MaterialTextureParamValues.Empty();
		MaterialTextureParamValues.Append(Other.MaterialTextureParamValues);

		MaterialScalarParamValues.Empty();
		MaterialScalarParamValues.Append(Other.MaterialScalarParamValues);

		MaterialVectorParamValues.Empty();
		MaterialVectorParamValues.Append(Other.MaterialVectorParamValues);
	}
};
#pragma endregion ConfigStructs



#pragma region RuntimeStructs
USTRUCT(BlueprintType)
struct KGCORE_API FRMaterialBasicParameter
{
	GENERATED_BODY()

public:
	UPROPERTY(Transient, BlueprintReadWrite)
	FName Name;
};

USTRUCT(BlueprintType)
struct KGCORE_API FRMaterialTexture : public FRMaterialBasicParameter
{
	GENERATED_BODY()

public:
	// 想要替换的纹理贴图，不填代表保留旧的贴图
	UPROPERTY(Transient, BlueprintReadWrite)
	TSoftObjectPtr<class UTexture> Texture = nullptr;

public:
	// class UTexture* GetValue() const;

	void operator=(const FRMaterialTexture& Other)
	{
		Name = Other.Name;

		Texture = Other.Texture;
	}
};

USTRUCT(BlueprintType)
struct KGCORE_API FRMaterialScalar : public FRMaterialBasicParameter
{
	GENERATED_BODY()

public:
	// 数据使用类型
	UPROPERTY(Transient, BlueprintReadWrite)
	EMaterialParameterUsingType ParameterType = EMaterialParameterUsingType::MPT_UseRangeValue;

	// 数值1
	UPROPERTY(Transient, BlueprintReadWrite)
	float Value1 = 0.0;

	// 数值2
	UPROPERTY(Transient, BlueprintReadWrite)
	float Value2 = 0.0;

	// 逻辑数值
	UPROPERTY(Transient, BlueprintReadWrite)
	int64 LogicValue = 0;

	// 逻辑掩码
	UPROPERTY(Transient, BlueprintReadWrite)
	int32 LogicMask = 0;

public:
	// float GetValue(float Alpha, float AlphaDenominator = 0.0f, UObject* WContext = nullptr, int64 PushID = 0) const;

	void operator=(const FRMaterialScalar& Other)
	{
		Name = Other.Name;
		ParameterType = Other.ParameterType;

		Value1 = Other.Value1;
		Value2 = Other.Value2;

		LogicValue = Other.LogicValue;
		LogicMask = Other.LogicMask;
	}
};

USTRUCT(BlueprintType)
struct KGCORE_API FRMaterialVector : public FRMaterialBasicParameter
{
	GENERATED_BODY()

public:
	// 数据使用类型
	UPROPERTY(Transient, BlueprintReadWrite)
	EMaterialParameterUsingType ParameterType = EMaterialParameterUsingType::MPT_UseRangeValue;

	// 数值1
	UPROPERTY(Transient, BlueprintReadWrite)
	FLinearColor Value1 = FLinearColor::Black;

	// 数值2
	UPROPERTY(Transient, BlueprintReadWrite)
	FLinearColor Value2 = FLinearColor::Black;

	// 逻辑数值
	UPROPERTY(Transient, BlueprintReadWrite)
	int64 LogicValue = 0;

	// 逻辑掩码
	UPROPERTY(Transient, BlueprintReadWrite)
	int32 LogicMask = 0;

	// 特定逻辑
	UPROPERTY(Transient, BlueprintReadWrite)
	FName SpecialLogicTag;

protected:
	static FName SV_LocalPawnLocation;
	static FName SV_LocalPawnRotation;
	static FName SV_MeshWLocation;
	static FName SV_MeshWRotation;
	static FName SV_MeshRLocation;
	static FName SV_MeshRRotation;
	static FName SV_MeshOwnerLocation;
	static FName SV_MeshOwnerRotation;

public:
	// FLinearColor GetValue(float Alpha, float AlphaDenominator = 0.0f, UObject* WContext = nullptr, int64 PushID = 0) const;

	void operator=(const FRMaterialVector& Other)
	{
		Name = Other.Name;
		ParameterType = Other.ParameterType;

		Value1 = Other.Value1;
		Value2 = Other.Value2;

		LogicValue = Other.LogicValue;
		LogicMask = Other.LogicMask;

		SpecialLogicTag = Other.SpecialLogicTag;
	}
};

USTRUCT(BlueprintType)
struct KGCORE_API FROverrideMaterial
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(Transient, BlueprintReadWrite)
	uint8 Priority = 5;

	UPROPERTY(Transient, BlueprintReadWrite)
	bool bReplaceAllMaterial = false;

	UPROPERTY(Transient, BlueprintReadWrite)
	TArray<int32> MaterialIDs;

	UPROPERTY(Transient, BlueprintReadWrite)
	TArray<FName> MaterialSlotNames;

	// 想要替换的新材质（如果为NULL，代表只修改参数）
	UPROPERTY(Transient, BlueprintReadWrite)
	TSoftObjectPtr<UMaterialInstance> ReplaceMaterial = nullptr;

	// 纹理参数
	UPROPERTY(Transient, BlueprintReadWrite)
	TArray<FRMaterialTexture> TextureValues;

	// 标量参数
	UPROPERTY(Transient, BlueprintReadWrite)
	TArray<FRMaterialScalar> ScalarValues;

	// 向量参数
	UPROPERTY(Transient, BlueprintReadWrite)
	TArray<FRMaterialVector> VectorValues;

public:
	void Reset()
	{
		Priority = 5;
		bReplaceAllMaterial = false;
		MaterialIDs.Empty();
		MaterialSlotNames.Empty();
		ReplaceMaterial = nullptr;
		TextureValues.Empty();
		ScalarValues.Empty();
		VectorValues.Empty();
	}

	void operator=(const FROverrideMaterial& Other)
	{
		Priority = Other.Priority;
		bReplaceAllMaterial = Other.bReplaceAllMaterial;

		MaterialIDs.Empty();
		MaterialIDs.Append(Other.MaterialIDs);

		MaterialSlotNames.Empty();
		MaterialSlotNames.Append(Other.MaterialSlotNames);

		ReplaceMaterial = Other.ReplaceMaterial;

		TextureValues.Empty();
		TextureValues.Append(Other.TextureValues);

		ScalarValues.Empty();
		ScalarValues.Append(Other.ScalarValues);

		VectorValues.Empty();
		VectorValues.Append(Other.VectorValues);
	}
};
#pragma endregion RuntimeStructs


