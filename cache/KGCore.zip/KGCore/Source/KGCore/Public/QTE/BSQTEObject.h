#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "BSQTEObject.generated.h"
UCLASS(Abstract, Blueprintable, BlueprintType, EditInlineNew)
class KGCORE_API UBSQTEData : public UObject
{
	GENERATED_BODY()

public:
	// P_开头的UI名称(必填！，请与程序咨询)
	/*UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Important")
	FString UIName;*/

	// QTE时长
	//UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Important")
	//float Duration = 1.0f;

	//// QTE循环次数
	//UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Important")
	//int32 LoopTimes = 1;
	
};

USTRUCT(BlueprintType)
struct FQTEBlackBoardValue
{
	GENERATED_USTRUCT_BODY()

public:
	// 变量名
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Common")
	FString ValueName = TEXT("DefaultValue");

	// 变量初始值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Common")
	float InitValue = 0.0f;

	// 变量下限
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Common")
	float MinValue = 0.0f;

	// 变量上限
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Common")
	float MaxValue = 1.0f;

	// 变量自动更新的间隔，单位：s（小于等于0则无自动更新逻辑）
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Delta")
	float AutoChangeInterval = -1.0f;

	// 变量自动更新时的变化值
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Delta", Meta = (EditCondition = "AutoChangeInterval > 0.0"))
	float AutoChangeDeltaValue = -1.0f;

	// QTE触发成功时变化值（绝对值小于0.001表示，QTE触发成功时值不改变）
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Event")
	float SuccessDeltaValue = 0.0f;

	// QTE触发失败时变化值（绝对值小于0.001表示，QTE触发失败时值不改变）
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Event")
	float FailedDeltaValue = 0.0f;
};