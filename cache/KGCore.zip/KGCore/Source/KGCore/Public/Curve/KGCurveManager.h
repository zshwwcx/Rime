#pragma once

#include "CoreMinimal.h"

#include "LuaOverriderInterface.h"

#include "Curve/KGCurve.h"
#include "Manager/KGBasicManager.h"

#include "KGCurveManager.generated.h"



UCLASS(Blueprintable, BlueprintType)
class KGCORE_API UKGCurveManager : public UKGBasicManager
{
	GENERATED_BODY()

#pragma region Important
public:
	static UKGCurveManager* GetInstance(UObject* InContext);

	void NativeInit() override;

	void NativeUninit() override;

	virtual EManagerType GetManagerType() { return EManagerType::EMT_CurveManager; }

protected:
	UFUNCTION(BlueprintCallable)
	void OnWorldCleanupEnd(UWorld* World, bool bSessionEnded, bool bCleanupResources);

private:
	const FString GIDName = TEXT("GID");

	const FString XKeysName = TEXT("XKeys");
	const FString YKeysName = TEXT("YKeys");
	const FString ZKeysName = TEXT("ZKeys");
	const FString WKeysName = TEXT("WKeys");

	const FString ATName = TEXT("ArriveTangent");
	const FString ATWName = TEXT("ArriveTangentWeight");
	const FString IMName = TEXT("InterpMode");
	const FString LTName = TEXT("LeaveTangent");
	const FString LTWName = TEXT("LeaveTangentWeight");
	const FString TMName = TEXT("TangentMode");
	const FString TWMName = TEXT("TangentWeightMode");
	const FString TName = TEXT("Time");
	const FString VName = TEXT("Value");

	FRichCurve XTemporaryCurve;
	FRichCurve YTemporaryCurve;
	FRichCurve ZTemporaryCurve;
	FRichCurve WTemporaryCurve;

#pragma endregion Important



#pragma region Curve
public:
	// Float曲线
	UFUNCTION(BlueprintCallable)
	bool HasFloatCurve(int64 InID);
	UFUNCTION(BlueprintCallable)
	void GetFloatCurve(FKGRemapFloatCurve& OutCurve, int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& Keys);
	UFUNCTION(BlueprintCallable)
	UCurveFloat* GetFloatCurveObject(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& Keys);
	UFUNCTION(BlueprintCallable)
	UCurveFloat* GetFloatCurveObjectByID(int64 InID);

	// Vector曲线
	UFUNCTION(BlueprintCallable)
	bool HasVectorCurve(int64 InID);
	UFUNCTION(BlueprintCallable)
	void GetVectorCurve(FKGRemapVectorCurve& OutCurve, int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys);
	UFUNCTION(BlueprintCallable)
	UCurveVector* GetVectorCurveObject(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys);
	UFUNCTION(BlueprintCallable)
	UCurveVector* GetVectorCurveObjectByID(int64 InID);

	// Color曲线
	UFUNCTION(BlueprintCallable)
	void GetColorCurve(FKGRemapColorCurve& OutCurve, int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys, TArray<FRichCurveKey>& WKeys);
	UFUNCTION(BlueprintCallable)
	UCurveLinearColor* GetColorCurveObject(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys, TArray<FRichCurveKey>& WKeys);
	UFUNCTION(BlueprintCallable)
	UCurveLinearColor* GetColorCurveObjectByID(int64 InID);

	// 曲线组
	UFUNCTION(BlueprintCallable)
	UCurveTable* GetCurveTableObjectByID(int64 InID);

	// 根据ID获取曲线对象
	UFUNCTION(BlueprintCallable)
	UObject* GetCurveObjectByID(int64 InID);

	UFUNCTION(BlueprintCallable)
	void GetCurveTimeRange(int64 InID, float& OutMinTime, float& OutMaxTime);

	UFUNCTION(BlueprintCallable)
	bool CheckCurveIDByPath(const FString& InPath, int64& OutID);

	UFUNCTION(BlueprintCallable)
	void AddCurveObject(UObject* InCurve, int64 InCurveID);

	UFUNCTION(BlueprintCallable)
	void CleanCurves();

	// Float曲线获取值
	UFUNCTION(BlueprintCallable)
	float GetFloatCurveValue(int64 InID, float InTime, float InTotalTime);

	// Vector曲线获取值
	UFUNCTION(BlueprintCallable)
	void GetVectorCurveValue(int64 InID, float InTime, float InTotalTime, float& OX, float& OY, float& OZ);
	FVector GetVectorCurveValue(int64 InID, float InTime, float InTotalTime);
	
	// Color曲线获取值
	UFUNCTION(BlueprintCallable)
	void GetColorCurveValue(int64 InID, float InTime, float InTotalTime, float& OR, float& OG, float& OB, float& OA);
	FLinearColor GetColorCurveValue(int64 InID, float InTime, float InTotalTime);

	// 曲线表获取值
	UFUNCTION(BlueprintCallable)
	TMap<FName, float>& GetCurveTableRowValueList(int64 InID, float InTime);

protected:
	int64 AddNewFloatCurve(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, bool InNeedObject = false);
	
	int64 AddNewVectorCurve(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys, bool InNeedObject = false);

	int64 AddNewColorCurve(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys, TArray<FRichCurveKey>& WKeys, bool InNeedObject = false);

	void AddNewCurveObject(int64 InID);

	void GenerateRichCurve(FRichCurve& RichCurve,  TArray<FRichCurveKey>& Keys);

public:
	// 运行时浮点曲线数据查找表
	UPROPERTY(Transient)
	TMap<int64, FKGRemapFloatCurve> FloatSearchMap;
	UPROPERTY(Transient)
	TMap<int64, UCurveFloat*> FloatObjectSearchMap;

	// 运行时向量曲线数据查找表
	UPROPERTY(Transient)
	TMap<int64, FKGRemapVectorCurve> VectorSearchMap;
	UPROPERTY(Transient)
	TMap<int64, UCurveVector*> VectorObjectSearchMap;

	// 运行时颜色曲线数据查找表
	UPROPERTY(Transient)
	TMap<int64, FKGRemapColorCurve> ColorSearchMap;
	UPROPERTY(Transient)
	TMap<int64, UCurveLinearColor*> ColorObjectSearchMap;

	// 运行时曲线组数据查找表
	UPROPERTY(Transient)
	TMap<int64, FKGRemapCurveTable> CurveTableSearchMap;

	UPROPERTY(Transient)
	TArray<int64> InvalidCurveGIDs;

	UPROPERTY(Transient)
	TMap<FString, int64> PathToCurveID;

private:
	UPROPERTY(Transient)
	TMap<FName, float> EmptyCurveTableData;	

#pragma endregion Curve

};
