#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"

#include "Curves/CurveFloat.h"
#include "Curves/CurveVector.h"
#include "Curves/CurveLinearColor.h"
#include "Engine/CurveTable.h"

#include "KGCurve.generated.h"



USTRUCT(BlueprintType)
struct KGCORE_API FKGRemapFloatCurve
{
	GENERATED_USTRUCT_BODY()

public:
	FKGRemapFloatCurve() {}
	FKGRemapFloatCurve(bool InRemap) : bNeedRemap(InRemap) {}

public:
	UPROPERTY(EditAnywhere)
	bool bNeedRemap = true;

	UPROPERTY(EditAnywhere)
	FRuntimeFloatCurve Curve;

public:
	void operator=(const FKGRemapFloatCurve& Other)
	{
		bNeedRemap = Other.bNeedRemap;

		Curve.ExternalCurve = Other.Curve.ExternalCurve;

		Curve.EditorCurveData.SetKeys(Other.Curve.EditorCurveData.Keys);
	}

	float GetFloatValue(float InTime, float TotalTime) const
	{
		if (bNeedRemap)
		{
			return Curve.GetRichCurveConst()->Eval(FMath::Min(InTime / FMath::Max(TotalTime, 1e-8), 1.0f));
		}

		return  Curve.GetRichCurveConst()->Eval(InTime);
	}
};



USTRUCT(BlueprintType)
struct KGCORE_API FKGRemapVectorCurve
{
	GENERATED_USTRUCT_BODY()

public:
	FKGRemapVectorCurve() {}
	FKGRemapVectorCurve(bool InRemap) : bNeedRemap(InRemap) {}

public:
	UPROPERTY(EditAnywhere)
	bool bNeedRemap = true;

	UPROPERTY(EditAnywhere)
	FRuntimeVectorCurve Curve;

public:
	void operator=(const FKGRemapVectorCurve& Other)
	{
		bNeedRemap = Other.bNeedRemap;

		Curve.ExternalCurve = Other.Curve.ExternalCurve;

		Curve.VectorCurves[0].SetKeys(Other.Curve.VectorCurves[0].Keys);
		Curve.VectorCurves[1].SetKeys(Other.Curve.VectorCurves[1].Keys);
		Curve.VectorCurves[2].SetKeys(Other.Curve.VectorCurves[2].Keys);
	}

	FVector GetVectorValue(float InTime, float TotalTime) const
	{
		if (bNeedRemap)
		{
			return Curve.GetValue(FMath::Min(InTime / FMath::Max(TotalTime, 1e-8), 1.0f));
		}

		return  Curve.GetValue(InTime);
	}
};



USTRUCT(BlueprintType)
struct KGCORE_API FKGRemapColorCurve
{
	GENERATED_USTRUCT_BODY()

public:
	FKGRemapColorCurve() {}
	FKGRemapColorCurve(bool InRemap) : bNeedRemap(InRemap) {}

public:
	UPROPERTY(EditAnywhere)
	bool bNeedRemap = true;

	UPROPERTY(EditAnywhere)
	FRuntimeCurveLinearColor Curve;

public:
	void operator=(const FKGRemapColorCurve& Other)
	{
		bNeedRemap = Other.bNeedRemap;

		Curve.ExternalCurve = Other.Curve.ExternalCurve;

		Curve.ColorCurves[0].SetKeys(Other.Curve.ColorCurves[0].Keys);
		Curve.ColorCurves[1].SetKeys(Other.Curve.ColorCurves[1].Keys);
		Curve.ColorCurves[2].SetKeys(Other.Curve.ColorCurves[2].Keys);
		Curve.ColorCurves[3].SetKeys(Other.Curve.ColorCurves[3].Keys);
	}

	FLinearColor GetLinearColorValue(float InTime, float TotalTime) const
	{
		if (bNeedRemap)
		{
			return Curve.GetLinearColorValue(FMath::Min(InTime / FMath::Max(TotalTime, 1e-8), 1.0f));
		}

		return  Curve.GetLinearColorValue(InTime);
	}
};



USTRUCT(BlueprintType)
struct KGCORE_API FKGRemapCurveTable
{
	GENERATED_USTRUCT_BODY()

public:
	FKGRemapCurveTable(){}

	TMap<FName, float>& GetCurveTableRowValueList(float InTime)
	{
		CurveTableTimeValueMap.Empty();
		for (auto RichCurveRow : Curve->GetRichCurveRowMap())
		{
			CurveTableTimeValueMap.Add(RichCurveRow.Key, RichCurveRow.Value->Eval(InTime));
		}

		return CurveTableTimeValueMap;
	}

public:
	UPROPERTY(EditAnywhere)
	TMap<FName, float> CurveTableTimeValueMap;

	UPROPERTY(EditAnywhere)
	UCurveTable* Curve;
};
