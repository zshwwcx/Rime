// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "Curves/CurveFloat.h"
#include "KGUIPlatformCustomSetting.generated.h"

UENUM()
enum class EDPIScalePreviewPlatforms : uint8
{
	PC,
	Android,
	IOS
};

enum class EUIScalingRule : uint8;

/**
 * 
 */
UCLASS(Config = Game, defaultconfig)
class KGCORE_API UKGUIPlatformCustomSetting : public UDeveloperSettings
{
	GENERATED_BODY()
public:
	UPROPERTY(config, EditAnywhere, Category="DPI Scaling")
	EDPIScalePreviewPlatforms EditorPreviewPlatform;

	UPROPERTY(config, EditAnywhere, Category="PC DPI Scaling", meta=( DisplayName="PC DPI Scale Rule" ))
	EUIScalingRule PCScaleRule;
	UPROPERTY(config, EditAnywhere, Category="PC DPI Scaling", meta=(
	DisplayName="DPI Curve",
	XAxisName="Resolution",
	YAxisName="Scale"))
	FRuntimeFloatCurve PCScalingCurve;
	
	UPROPERTY(config, EditAnywhere, Category="Android DPI Scaling", meta=( DisplayName="Android DPI Scale Rule" ))
	EUIScalingRule AndroidScaleRule;
	UPROPERTY(config, EditAnywhere, Category="Android DPI Scaling", meta=(
		DisplayName="DPI Curve",
		XAxisName="Resolution",
		YAxisName="Scale"))
	FRuntimeFloatCurve AndroidScalingCurve;
	
	UPROPERTY(config, EditAnywhere, Category="IOS DPI Scaling", meta=( DisplayName="IOS DPI Scale Rule" ))
	EUIScalingRule IOSScaleRule;
	UPROPERTY(config, EditAnywhere, Category="IOS DPI Scaling", meta=(
		DisplayName="DPI Curve",
		XAxisName="Resolution",
		YAxisName="Scale"))
	FRuntimeFloatCurve IOSScalingCurve;


};
