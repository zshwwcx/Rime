// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Blueprint/UserWidget.h"
#include "KGUserWidgetComponent.generated.h"


/**
 * 
 */
USTRUCT(BlueprintType, Blueprintable, meta = (DisplayName = "LiteWidgetComponent Setting"))
struct FKGUserWidgetComponentSetting
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	UClass* ClassIdentify;

	// #if WITH_EDITORONLY DATA
	UPROPERTY(BlueprintReadOnly, EditAnywhere, Transient, meta = (DisplayName = "Component "))
	FString ComponentName;
	// #endif

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "Params"))
	TMap<FString, FString> Params;
};

UCLASS(Abstract, Blueprintable, EditInlineNew, DefaultToInstanced)
class KGCORE_API UKGUserWidgetComponent : public UObject
{
	GENERATED_BODY()

protected:
	UFUNCTION(BlueprintImplementableEvent, meta = (Keywords = "PreConstruct"))
	void PreConstruct(bool IsDesignTime);

	UFUNCTION(BlueprintImplementableEvent, meta = (Keywords = "Begin Play"))
	void Construct();

	UFUNCTION(BlueprintImplementableEvent, meta = (Keywords = "End Play, Destory"))
	void Destruct(bool IsDesignTime);

	UFUNCTION(BlueprintImplementableEvent, meta = (Keywords = "Tick"))
	void Tick(FGeometry MyGeometry, float InDeltaTime);


public:
	virtual bool Initialize();
	virtual void NativePreConstruct();
	virtual void NativeConstruct();
	virtual void NativeDestruct();
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime);
	
};
