// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/KGUserWidgetComponent.h"
#include "Animation/WidgetAnimation.h"
#include "Blueprint/UserWidget.h"
#include "KGUserWidgetAnimComponent.generated.h"

/**
 * 
 */
USTRUCT(BlueprintType, Blueprintable, meta = (DisplayName = "Binding Setting"))
struct FBindingSetting
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "Animation"))
	FString AnimationName; //对应的动画名

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "Redirect Widgets"))
	TMap<FName, FName> Redirects; //动画原来K帧的节点:重定向的节点
};

UCLASS()
class KGCORE_API UKGUserWidgetAnimComponent : public UKGUserWidgetComponent
{
	GENERATED_BODY()
public:
	//对白板WBP的引用
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "Animation WBP"))
	TArray<TSubclassOf<UUserWidget>> AnimWBPs;

	//方便美术同学添加新的动画.
	UPROPERTY(BlueprintReadOnly, VisibleAnywhere, meta = (DisplayName = "Animations Valiable"))
	TSet<FString> AnimsAvaliable;

	//动画名对应的动画资源
	UPROPERTY(BlueprintReadWrite, VisibleAnywhere, meta = (DisplayName = "AnimationsMap"))
	TMap<FString, UWidgetAnimation*> AnimationsMap;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (DisplayName = "Animation Settings"))
	TArray<FBindingSetting> AnimBindingSettings; //由于一个WBP会引用多个白板WBP的动画资源,所以这是一个FBindingSetting数组,

	void RefreshAnimationsAvaliable();

	/*void PlayAnimationsAtStart();*/
	virtual bool Initialize() override;
	virtual void NativeConstruct() override;
	
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif
	void CleanUnavaliableAnimationSettings();
	void RefreshAnimationSettings();
	// UFUNCTION()
	// UWidgetAnimation* CreateAnim(FName ToControllerName, FString AnimationName);
};
