﻿#pragma once


#include "Kismet/BlueprintFunctionLibrary.h"
#include "Rendering/SuperResolutionBPLibrary.h"


#include "SuperResolutionHelper.generated.h"


UENUM(Blueprintable)
enum class ESuperResolutionMethod : uint8
{
	None = static_cast<uint8>(EFrameGenerationMode::FG_None),
	DLSS = static_cast<uint8>(EFrameGenerationMode::FG_DLSS),
	FSR = static_cast<uint8>(EFrameGenerationMode::FG_FSR),
	XeSS = static_cast<uint8>(EFrameGenerationMode::FG_XeSS),
	TSR
};

UENUM(Blueprintable)
enum class ESuperResolutionQualityMode : uint8
{
	Off = 0 UMETA(DisplayName = "Off"),
	AA = 1 UMETA(DisplayName = "AA"),
	UltraQualityPlus = 2 UMETA(DisplayName = "Ultra Quality Plus", ToolTip = "Only For XeSS"),
	UltraQuality = 3 UMETA(DisplayName = "Ultra Quality"),
	Quality = 4 UMETA(DisplayName = "Quality"),
	Balanced = 5 UMETA(DisplayName = "Balanced"),
	Performance = 6 UMETA(DisplayName = "Performance"),
	UltraPerformance = 7 UMETA(DisplayName = "Ultra Performance")
};


UENUM(BlueprintType)
enum class EFrameGenerationQualityMode : uint8
{
	Off = 0 UMETA(DisplayName = "Off"),
	Auto = 251 UMETA(DisplayName = "Auto"),
	On2X = 17 UMETA(DisplayName = "2X"),
	On3X = 23 UMETA(DisplayName = "3X"),
	On4X = 31 UMETA(DisplayName = "4X"),
};

UCLASS()
class KGCORE_API USuperResolutionHelper : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "SuperResolutionHelper")
	static void Init();

	/**
	 * return all supported modes by the input Method, include off 
	 */
	UFUNCTION(BlueprintCallable, meta = (WorldContext="WorldContextObject"), Category="SuperResolutionHelper")
	static TArray<ESuperResolutionQualityMode> GetSuperResolutionSupport(UObject* WorldContextObject, ESuperResolutionMethod Method);

	/**
	 * for fsr and xess, only has off and On2X, two state 
	 */
	UFUNCTION(BlueprintCallable, meta = (WorldContext="WorldContextObject"), Category="SuperResolutionHelper")
	static TArray<EFrameGenerationQualityMode> GetFrameGenerationSupport(UObject* WorldContextObject, ESuperResolutionMethod Method);

	UFUNCTION(BlueprintCallable, meta = (WorldContext="WorldContextObject"), Category="SuperResolutionHelper")
	static void SetSuperResolution(UObject* WorldContextObject, ESuperResolutionMethod Method,
	                               ESuperResolutionQualityMode Quality, bool bDisablePre = true);

	/**
	 * 
	 * @return true : restart to take effect
	 */
	UFUNCTION(BlueprintCallable, meta = (WorldContext="WorldContextObject"), Category="SuperResolutionHelper")
	static bool SetFrameGeneration(UObject* WorldContextObject, ESuperResolutionMethod Method,
	                               EFrameGenerationQualityMode FrameGenerationQuality, bool bDisablePre = true);

	UFUNCTION(BlueprintCallable, Category="SuperResolutionHelper")
	static ESuperResolutionQualityMode GetSuperResolutionQuality(ESuperResolutionMethod Method);

	UFUNCTION(BlueprintCallable, Category="SuperResolutionHelper")
	static EFrameGenerationQualityMode GetFrameGenerationQuality(ESuperResolutionMethod Method);

	/**
	 * 
	 * @return [0,1] percentage, < 0 for invalid
	 */
	UFUNCTION(BlueprintCallable, Category="SuperResolutionHelper")
	static float GetSRModeScreenPercentage(ESuperResolutionMethod Method, ESuperResolutionQualityMode Quality);

	UFUNCTION(BlueprintCallable, meta = (WorldContext="WorldContextObject"), Category="SuperResolutionHelper")
	static bool SetSuperResolutionAndFrameGeneration(UObject* WorldContextObject,
	                                                 ESuperResolutionMethod Method,
	                                                 ESuperResolutionQualityMode Quality,
	                                                 EFrameGenerationQualityMode FrameGenerationQuality);


	UFUNCTION(BlueprintCallable, Category="SuperResolutionHelper")
	static void GetCurSuperResolutionCfg(ESuperResolutionMethod& Method, ESuperResolutionQualityMode& SRQuality,
	                                     EFrameGenerationQualityMode& FGQuality);

	UFUNCTION(BlueprintCallable, Category="SuperResolutionHelper")
	static float GetFPS();

	static bool DisableCurFrameGeneration(UObject* WorldContextObject);
	static void DisableCurSuperResolution(UObject* WorldContextObject);

	static bool SetFrameGenerationMode(EFrameGenerationMode Mode);

	static bool ShouldRestart(EFrameGenerationMode Mode);

	static void PushVSync();

	static void PopVSync();

private:
	static ESuperResolutionMethod CurMethod;
	static bool bHasXeSS;
	static bool bInit;

	static bool bInitVSync;
	static int32 PreviousVSync;
	static uint32 PreviousForceDisableFrameRateSmoothing;
};
