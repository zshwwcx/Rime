﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Containers/LruCache.h"
#include "AkGameplayTypes.h"
#include "Audio/AudioRecapHelper.h"
#include "Manager/KGBasicManager.h"
#include "KGAkAudioManager.generated.h"

#define ASYNC_TASK_MAX_NUM 64

DECLARE_LOG_CATEGORY_EXTERN(LogAudioMgr, Log, All);

class UKGAkAudioManager;
class USkeletalMeshComponent;
class UAkComponent;
class UAkAudioEvent;

UENUM()
enum EAkEventCategory
{
	OTHER = 0, // 未分类
	MUSIC = 1, // 音乐
	AMBIENT = 2, // 环境
};

USTRUCT()
struct FAsyncEventPostTask
{
	GENERATED_USTRUCT_BODY()
	
	FAsyncEventPostTask()
	{
		Reset();
	}

	void Reset()
	{
		LoadID = 0;
		Location = FVector::ZeroVector;
		AkComp.Reset();
		bOnComp = false;
		bNeedPost = true;
		bStopWhenAttachedObjectDestroyed = true;
	}

	// 异步加载标识ID,由CppAssetMgr返回
	int32 LoadID;
	// 定点播放还是挂接播放
	bool bOnComp;
	// 播放定点音频时的位置 
	FVector Location;
	// 播放挂接音频时的组件
	TWeakObjectPtr<UAkComponent> AkComp;
	// 是否还需要播放(用于处理异步期间被Stop了的情况)
	bool bNeedPost;
	// 音频是否跟随挂接者一起销毁
	bool bStopWhenAttachedObjectDestroyed;
};

USTRUCT(BlueprintType)
struct FKGGroupState
{
	GENERATED_USTRUCT_BODY()

	FKGGroupState()
	{
		GameObjectID = 0;
	}

	FKGGroupState(const FString& InGroup, const FString& InState)
	{
		Group = InGroup;
		State = InState;
		GameObjectID = 0;
	}

	FKGGroupState(const FString& InGroup, const FString& InState, AkGameObjectID InGameObjectID)
	{
		Group = InGroup;
		State = InState;
		GameObjectID = InGameObjectID;
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio")
	FString Group;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "C7Audio")
	FString State;

	AkGameObjectID GameObjectID;
};

struct FKGRtpc
{
	FKGRtpc(const FString& InRtpcName, float InRtpcValue)
	{
		RtpcName = InRtpcName;
		RtpcValue = InRtpcValue;
		GameObjectID = 0;
	}

	FKGRtpc(const FString& InRtpcName, float InRtpcValue, AkGameObjectID InGameObjectID)
	{
		RtpcName = InRtpcName;
		RtpcValue = InRtpcValue;
		GameObjectID = InGameObjectID;
	}

	FString RtpcName;
	float RtpcValue;
	AkGameObjectID GameObjectID;
};

UENUM()
enum class EAudioListenerMode : uint8
{
	Camera, // 挂在相机上,和相机保持一致的Transform
	Player, // 挂在玩家上,和玩家头部保持一致的Location,但Rotation仍然和相机保持一致
};



/**
 * 音频管理器
 */
UCLASS(Blueprintable, BlueprintType)
class KGCORE_API UKGAkAudioManager : public UKGBasicManager
{
	GENERATED_BODY()

#pragma region Important

public:
	void NativeInit() override;

	void NativeUninit() override;

	virtual EManagerType GetManagerType() { return EManagerType::EMT_AkAudioManager; }

	static UKGAkAudioManager* GetInstance(UObject* InContext)
	{
		return Cast<UKGAkAudioManager>(GetManagerByType(InContext, EManagerType::EMT_AkAudioManager));
	}

	virtual void Tick(float DeltaTime) override;

	virtual void OnPostLoadMapWithWorld(UWorld* World) override;

private:
	double LastUpdateTime = 0.f;

#pragma endregion Important

#pragma region Notify

public:
	/**
	 * 静态导出,设置Notify最大数量限制,Avatar和Npc分池
	 * @param InAvatarNotifyEventLimit
	 * @param InNpcNotifyEventLimit 
	 */
	void SetNotifyEventLimit(int32 InAvatarNotifyEventLimit, int32 InNpcNotifyEventLimit);
	bool CanPostNotifyEvent(bool bIsAvatar) const;
	void AddNotifyEventRecord(int32 PlayingID, double PlayingTime, bool bIsAvatar);

	/**
	 * 静态导出,设置当前主角锁定的目标
	 */
	void SetLockTargetUID(int64 InLockTargetUID) { LockTargetUID = InLockTargetUID; }
	int32 GetLockTargetUID() const { return LockTargetUID; }

	/**
	 * 静态导出,获取当前播放中的BattleEvent数量
	 * @return 
	 */
	int32 GetBattleEventNum() const { return BattleEventPlayingMap.Num(); }

	int32 GetBattleEventLimit() const { return BattleEventLimit; }

	/**
	 * 静态导出,记录BattleEvent播放时长
	 * @param PlayingID 
	 * @param PlayingTime 
	 */
	void AddBattleEventRecord(int32 PlayingID, double PlayingTime);

	/**
	 * 静态导出,移除一条战斗侧Event播放时长
	 * @param PlayingID 
	 */
	void DelBattleEventRecord(int32 PlayingID);

	/**
	 * 静态导出,设置战斗用数值
	 * @param InBattleEventLimitRtpcName 
	 * @param InBattleEventLimit 
	 */
	void SetBattleEventLimitInfo(FString InBattleEventLimitRtpcName, float InBattleEventLimit);

	/**
	 * 静态导出,控制地面材质打印开关
	 * @param bEnable 
	 */
	void SetEnablePrintTerrainName(bool bEnable) { bEnablePrintTerrainName = bEnable; }
	bool IsEnablePrintTerrainName() const { return bEnablePrintTerrainName; }

private:
	FString BattleEventLimitRtpcName;
	float BattleEventLimit = 0.f;
	float CurrentBattleEventRtpcValue = -1.f;
	int64 LockTargetUID = 0;

	int32 AvatarNotifyEventLimit = 0;
	int32 NpcNotifyEventLimit = 0;
	TMap<int32, double> AvatarNotifyEventPlayingMap;
	TMap<int32, double> NpcNotifyEventPlayingMap;
	TMap<int32, double> BattleEventPlayingMap;

	bool bEnablePrintTerrainName = false;

#pragma endregion Notify

#pragma region Track

public:
	static void PostTrackEvent(UObject* WorldContextObject, UAkAudioEvent* AkAudioEvent, bool bEnableSync);

#pragma endregion Track

#pragma region Event

public:
	/**
	 * 静态导出
	 * @param EventName 
	 * @param X
	 * @param Y
	 * @param Z
	 * @return PlayingID
	 */
	int32 InnerPostEvent3D(const FString& EventName, double X = 0, double Y = 0, double Z = 0);

	// CppEntity调用
	int32 InnerPostEventOnAkComp(const FString& EventName, UAkComponent* AkComponent, bool bStopWhenAttachedObjectDestroyed = true);

	/**
	 * 静态导出,在一个纯Actor上播放挂接音频,如果没有AkComponent,会动态创建一个
	 * @param EventName 
	 * @param ActorID 
	 * @return 
	 */
	int32 InnerPostEventOnPureActor(const FString& EventName, KGActorID ActorID);
	
	/**
	 * 静态导出
	 * @param PlayingID 
	 * @param BlendTime 
	 * @param BlendType 
	 */
	void InnerStopEventByPlayingID(int32 PlayingID, int32 BlendTime = 0, EAkCurveInterpolation BlendType = EAkCurveInterpolation::Linear);

	/**
	 * 静态导出
	 * @param PlayingID 
	 * @param BlendTime 
	 * @param BlendType 
	 */
	void InnerPauseEventByPlayingID(int32 PlayingID, int32 BlendTime = 0, EAkCurveInterpolation BlendType = EAkCurveInterpolation::Linear);

	/**
	 * 静态导出
	 * @param PlayingID 
	 * @param BlendTime 
	 * @param BlendType 
	 */
	void InnerResumeEventByPlayingID(int32 PlayingID, int32 BlendTime = 0, EAkCurveInterpolation BlendType = EAkCurveInterpolation::Linear);

	/**
	 * 静态导出
	 * @param PlayingIDs 
	 */
	void StopAllByPlayingIDs(const TArray<int32>& PlayingIDs);
	
	UFUNCTION()
	void OnAkAudioEventLoaded(int InLoadID, UObject* LoadedObject, int32 EventPostTaskID);

	// CppEntity调用
	void CacheEventAsset(UAkAudioEvent* AkAudioEvent);

	/**
	 * 静态导出,在游戏启动阶段,动态加载一些全局功能性事件
	 * @param EventName 
	 */
	void SyncLoadAndCacheEvent(const FString& EventName);

	bool DoesBattleEventOverLimit();
	
	// CppEntity调用
	FString GetEventPath(const FString& EventName) const;

private:
	static int32 GenerateEventPostTaskID();
	
	// 异步播放音频
	int32 InnerAsyncPostEvent(const FString& EventPath, const FVector& Location = FVector::ZeroVector, UAkComponent* AkComp = nullptr, bool bStopWhenAttachedObjectDestroyed = true);

	// 统一取
	const TWeakObjectPtr<UAkAudioEvent>* GetEventFromPool(const FString& EventName);

	// 统一清理
	void ClearEventFromPool(const FString& EventName);
	
private:
	// 异步加载任务
	TMap<int32, FAsyncEventPostTask> AsyncEventPostTasks;

	// 异步加载ID对应PlayingID
	TMap<int32, int32> AsyncPostTaskID2PlayingID;

	// LruEvent池,逻辑池,不对UObject有效性负责
	TLruCache<FString, TWeakObjectPtr<UAkAudioEvent>> LruEventPool;

	// 常驻Event池,主要是音乐相关
	TMap<FString, TWeakObjectPtr<UAkAudioEvent>> StaticEventPool;

	// 主要是Amb相关的,这些会和地图绑定
	TMap<FString, TWeakObjectPtr<UAkAudioEvent>> AmbientEventPool;

	// EventUObject持有,不会直接从这里取数据
	UPROPERTY(Transient)
	TMap<FString, UAkAudioEvent*> EventCachePool;

#pragma endregion Event

#pragma region AUDIO_PARAM

public:
	/**
	 * 静态导出,切换前后台时控制音频输出
	 * @param bLostFocus 
	 */
	void OnWindowFocusChanged(bool bLostFocus);
	
	/**
	 * 静态导出
	 * @param Group 
	 * @param State 
	 */
	void InnerSetGroupState(const FString& Group, const FString& State);

	/**
	 * 静态导出
	 * @param Group 
	 */
	void InnerResetGroupState(const FString& Group);

	/**
	 * 静态导出
	 * @param RtpcName 
	 * @param RtpcValue 
	 */
	void InnerSetRtpcValue(const FString& RtpcName, float RtpcValue);

	/**
	 * 静态导出
	 * @param RtpcName 
	 */
	void InnerResetRtpcValue(const FString& RtpcName);

	void SetRtpcValueOnAkGameObject(class UAkGameObject* AkGameObject, const FString& RtpcName, float RtpcValue);
	void ResetRtpcValueOnAkGameObject(class UAkGameObject* AkGameObject, const FString& RtpcName);
	void SetSwitchGroupOnAkGameObject(class UAkGameObject* AkGameObject, const FString& SwitchGroup, const FString& SwitchState);

	static void OnEnterPriorityGroupStateAudioVolume(class AC7AkAudioVolume* AudioVolume);
	static void OnLeavePriorityGroupStateAudioVolume(class AC7AkAudioVolume* AudioVolume);

private:
	void SetPriorityGroupState(class AC7AkAudioVolume* AudioVolume);
	void UnsetPriorityGroupState(class AC7AkAudioVolume* AudioVolume);

private:
	// 使用场景不复杂,所以简单实现,最多3个Volume叠在一起
	struct FPriorityGroupStateItem
	{
		FPriorityGroupStateItem(uint32 InUniqueID, const TArray<FKGGroupState>& InGroupState, int32 InPriority)
		{
			UniqueID = InUniqueID;
			GroupState.Append(InGroupState);
			Priority = InPriority;
		}

		inline bool operator==(const FPriorityGroupStateItem& Other) const
		{
			return UniqueID == Other.UniqueID;
		}

		uint32 UniqueID = 0;
		TArray<FKGGroupState> GroupState;
		int32 Priority = 0;
	};

	TArray<FPriorityGroupStateItem> PriorityGroupStateList;
	uint32 CurrentVolumeUniqueID = 0;
	TArray<FKGGroupState> CurrentPriorityGroupState;

	TMap<FString, FString> GroupStates;
	TMap<FString, float> Rtpcs;
	TMap<AkGameObjectID, TMap<FString, float>> GameObjectRtpcs;
	TMap<AkGameObjectID, TMap<FString, FString>> GameObjectSwitches;

#pragma endregion AUDIO_PARAM

#pragma region DataInit

public:
	/**
	 * 静态导出,设置Lru大小
	 * @param LruSize 
	 */
	void SetLruSize(int32 LruSize);
	
	/**
	 * 静态导出,设置语言
	 * @param Culture 
	 */
	void SetAudioCulture(const FString& Culture);
	
	/**
	 * 静态导出
	 * @param InEvent2Path 
	 * @param InEvent2Duration
	 * @param InEvent2Category
	 */
	void InnerInitEventData(const TMap<FString, FString>& InEvent2Path, const TMap<FString, double>& InEvent2Duration, const TMap<FString, int32>& InEvent2Category);
	double GetEventDuration(const FString& EventName);
	bool IsMusicEvent(const FString& EventName);
	bool IsAmbientEvent(const FString& EventName);
	bool IsValidEvent(const FString& EventName) const;

	/**
	 * 静态导出
	 * @param InEventName 
	 * @param InRequiredBank 
	 * @param InDuration
	 * @param InCategory
	 */
	void InnerUpdateEventData(const FString& InEventName, const FString& InRequiredBank, double InDuration, int32 InCategory);

	/**
	 * 
	 * @param InGenderSwitch 性别Switch
	 * @param InMainPlayerGenderGroup 主角性别
	 * @param InMaleState 
	 * @param InFemaleState 
	 * @param InStaminaRtpc 体力条Rtpc
	 * @param AudioInputEventPath
	 */
	void SetCommonGameParameterName(const FString& InGenderSwitch, const FString& InMainPlayerGenderGroup, const FString& InMaleState, const FString& InFemaleState,const FString& InStaminaRtpc,
		const FString& AudioInputEventPath);
	void InitCommonGameParameters(UAkComponent* AkComponent, bool bMainPlayer, int32 Gender, float StaminaValue);
	UAkAudioEvent* GetAudioInputEvent() const { return AudioInputEvent; }

private:
	TMap<FString, FString> Event2Path;
	TMap<FString, double> Event2Duration;
	TMap<FString, int32> Event2Category;

	FString GenderSwitch;
	FString MainPlayerGenderGroup;
	FString MaleState;
	FString FemaleState;
	FString StaminaRtpc;

	UPROPERTY(Transient)
	TObjectPtr<UAkAudioEvent> AudioInputEvent;

#pragma endregion DataInit

#pragma region AudioRecap

public:
	/**
	 * 静态导出,开始音频回放记录
	 */
	void StartRecordAudioRecap();

	/**
	 * 静态导出,结束音频回访记录并输出json文件
	 */
	void StopRecordAudioRecap();

public:
	FAudioRecapHelper AudioRecapHelper;
	static float ResetRtpcValue;

private:
	// 开关
	bool bIsRecording = false;

#pragma endregion AudioRecap

#pragma region Battle
public:
	FString GetBattleFinalEventName(const FString& InEventName, bool bFromLocal, bool bHitLocal, bool bHasHit);

	/**
	 * 静态导出,战斗系统播放音频
	 * @param InEventName
	 * @param TargetActorID 要播放音频的单位
	 * @param bFromLocal 是否来自P1
	 * @param bHitLocal 是否击中P1
	 * @param bHasHit 是否有命中
	 * @param bNeedAttach 是否挂接
	 * @param OffsetX 
	 * @param OffsetY 
	 * @param OffsetZ 
	 * @param bSetWorldLocation 是否使用世界坐标
	 * @param bUseOriginPath 是否使用原始路径
	 * @param bStopWhenAttachedObjectDestroyed
	 * @param bNeedDrawDebug 3D情况下画点
	 * @return 
	 */
	int32 InnerPostEventForSkill(const FString& InEventName, KGActorID TargetActorID, bool bFromLocal, bool bHitLocal, bool bHasHit, 
		bool bNeedAttach, float OffsetX, float OffsetY, float OffsetZ, bool bSetWorldLocation,
		bool bUseOriginPath, bool bStopWhenAttachedObjectDestroyed, bool bNeedDrawDebug);

	/**
	 * 静态导出,战斗系统停止音频
	 * @param PlayingID 
	 * @param FadeTime 
	 * @param FadeCurve 
	 */
	void InnerStopEventForSkill(int32 PlayingID, int32 FadeTime, EAkCurveInterpolation FadeCurve);

private:
	// 事件拼接缓存
	TMap<FString, TMap<FString, FString>> BattleEventNameCache;
	
#pragma endregion Battle

#pragma region Dialogue
public:
	/**
	 * 静态导出
	 * @param DialogueID 
	 * @param EpisodeID 
	 * @param ContentIdx 
	 */
	FString GetDialogueVoiceEventName(int32 DialogueID, int32 EpisodeID, int32 ContentIdx) const;
	
#pragma endregion Dialogue

#pragma region GlobalParams
public:
	static FString WaterDepthRtpcName;
	static FString VisibilityRtpcName;
	static float VisibleRtpcValue;
	static float InvisibleRtpcValue;

public:
	void KAPI_AudioMgr_SetGlobalParams(const FString& InWaterDepthRtpcName, const FString& InVisibilityRtpcName, float InVisibleRtpcValue, float InInvisibleRtpcValue);
#pragma endregion GlobalParams
	
#pragma region Debug
	
public:
	FString GetDebugInfo() const;
	
#pragma endregion Debug
};
