#pragma once
#include "CoreMinimal.h"
#include "Tickable.h"
#include "Delegates/Delegate.h"
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"
#include "Manager/KGBasicManager.h"
#include "Containers/LruCache.h"
#include "Animation/AnimSequenceBase.h"
#include "KGCppAssetManager.generated.h"

#define KG_CPP_INVALID_ASSET_LOAD_ID (0)
DEFINE_LOG_CATEGORY_STATIC(KGCppAssetManager, Log, All);

DECLARE_DELEGATE_TwoParams(FAsyncLoadCompleteDelegate, int, UObject*);
DECLARE_DELEGATE_TwoParams(FAsyncLoadListCompleteDelegate, int, const TArray<UObject*>&);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FAsyncLoadCppAssetNotify, int, RequestID, UObject*, LoadedObject);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FAsyncLoadCppAssetListNotify, int, RequestID, TArray<UObject*>, LoadedObjectList);

#define CPP_ASSET_MANAGER_LOG(Format, ...) \
if (bEnableLog) \
{ \
FString FinalLog = FString::Printf(Format, ##__VA_ARGS__); \
UE_LOG(KGCppAssetManager, Log, TEXT("%s"), *FinalLog); \
}

USTRUCT()
struct FKGCppObjectArray
{
	GENERATED_BODY()
	UPROPERTY(Transient)
	TArray<UObject*> ObjList;
};

USTRUCT()
struct FKGCppWeakObjectArray
{
	GENERATED_BODY()
	UPROPERTY(Transient)
	TArray<TWeakObjectPtr<UObject>> ObjList;
};

struct KGCppAsyncLoadTask
{
	int LoadID = 0;
	TSharedPtr<FStreamableHandle> Handle = nullptr;
	TArray<FString> AssetPathList;
	FAsyncLoadCompleteDelegate CallBack;
	FAsyncLoadListCompleteDelegate CallBackList;
	bool CallLua;
	bool IsList;
	bool KeepRef;

	void Init(int InLoadID, TSharedPtr<FStreamableHandle> InHandle, TArray<FString> InAssetPathList, const
		FAsyncLoadCompleteDelegate& InCallBack, const FAsyncLoadListCompleteDelegate& InCallBackList, bool InCallLua = false, bool InIsList = false, bool InKeepRef = false)
	{
		LoadID = InLoadID;
		Handle = InHandle;
		AssetPathList = MoveTemp(InAssetPathList);
		CallBack = InCallBack;
		CallBackList = InCallBackList;
		CallLua = InCallLua;
		IsList = InIsList;
		KeepRef = InKeepRef;
	}
};

enum class EAssetLoadPriority
{
	PreLoad = 9999,
	Default = 10000,
	CombatEffect = 10001,
	AnimLib = 10002,
	UI = 10003,
	MoveCurve = 10004,
};


USTRUCT()
struct FAnimSequenceRefMap
{
	GENERATED_BODY()
public:
	
	UPROPERTY(Transient)
	TMap<FName, UAnimSequenceBase*> AnimSequenceAssetMap;
};

enum EAnimSequenceCacheType
{
	Game = 0,
	Level = 1,
};

USTRUCT()
struct FAnimSequenceCache
{
	GENERATED_BODY()

public:
	// 速查表
	TMap<FName, TWeakObjectPtr<UAnimSequenceBase>> PreLoadAnimsForLookUp;

	// 额外添加动画
	UPROPERTY(Transient)
	TMap<FName, TObjectPtr<UAnimSequenceBase>> PreLoadAnims;
	TLruCache<FName, bool> PreloadAnimLruCache;
	int PreloadAnimLruCacheAddCount = 0;

	// For AnimID LRU
	UPROPERTY(Transient)
	TMap<FName, FAnimSequenceRefMap> AnimLibAssetRefMap;

	UPROPERTY(Transient)
	TMap<FName, FAnimSequenceRefMap> AnimLibAssetRefMapForABP;
	
	// For AnimID LRU
	TLruCache<FName, bool> AnimIDToPreLoadAnimsLruCache;

	//异步使用的情况下需要锁一下资源
	TMap<FName, int> AnimIDForLock;

	bool EnableLru = false;

	int PreloadAnimLruCapacity=0;
	int Capacity = 0;

	void Reset();

	void Reset(int InCapacity, int PreloadAnimLRUCapacity);

	void Add(const FName& AnimID, const TArray<FName>& AnimPaths, const TArray<UAnimSequenceBase*>& PreLoadAnimAssets, const TArray<FName>& AnimFeatureNames, const TArray<FName>& FilterLocoNames);

	void Add(const FName& AnimPath, UAnimSequenceBase* AnimAsset);
	void Add(const TArray<FName>& AnimPath, const TArray<UAnimSequenceBase*>& AnimAsset);

	bool ContainsID(const FName& AnimID) const;

	int LockID(const FName& AnimID);

	void UnLockID(const FName& AnimID);

	bool Contains(const FName& AnimPath) const;

	UAnimSequenceBase* GetFromPath(const FName& AnimPath);
	const TMap<FName, UAnimSequenceBase*>* GetABPAnimationsFromID(const FName& AnimID);
};

UCLASS(Blueprintable, BlueprintType)
class KGCORE_API UKGCppAssetManager : public UKGBasicManager
{
	GENERATED_BODY()
	
public:
	virtual void NativeInit() override;
	virtual void NativeUninit() override;
	virtual EManagerType GetManagerType() { return EManagerType::EMT_CppAssetManager; }

	static UKGCppAssetManager* GetInstance(UObject* InContext)
	{
		return Cast<UKGCppAssetManager>(GetManagerByType(InContext, EManagerType::EMT_CppAssetManager));
	}
	
	virtual void Tick(float DeltaTime) override;
	virtual void OnPostLoadMapWithWorld(UWorld* World) override;

#if WITH_EDITOR
	void EditorTick(float DeltaTime)
	{
		Tick(DeltaTime);
	}
#endif

	/**
	* C++侧弱引用加载
	*/
	int AsyncLoadAsset(const FString& InPath, const FAsyncLoadCompleteDelegate& CallBack, int32 InPriority = static_cast<int32>(EAssetLoadPriority::Default));
	int AsyncLoadAsset(const TArray<FString>& InPaths, const FAsyncLoadListCompleteDelegate& CallBack, int32 InPriority = static_cast<int32>(EAssetLoadPriority::Default));

	/**
	* C++侧弱引用加载，资源存在立即返回资源
	*/
	int AsyncLoadAsset(const FString& InPath, UObject*& OutAsset, const FAsyncLoadCompleteDelegate& CallBack, int32 InPriority = static_cast<int32>(EAssetLoadPriority::Default));
	int AsyncLoadAsset(const TArray<FString>& InPaths, TArray<UObject*>& OutAssets, const FAsyncLoadListCompleteDelegate& CallBack, int32 InPriority = static_cast<int32>(EAssetLoadPriority::Default));
	
	void CancelAsyncLoadByLoadID(int InLoadID);
	void EnableLog(bool value){ bEnableLog = value;}
	void EnableLoadSync(bool value){ bEnableLoadSync = value;}
	void EnableLoadCancel(bool value){ bEnableLoadCancel = value;}
	UFUNCTION(BlueprintCallable)
	void EnableDeprecatedPath(bool value);
	void DoFlushAsyncLoading(){ FlushAsyncLoading();}

public:
	UPROPERTY(Transient)
	TMap<int, FKGCppObjectArray> RefObjectMapForCallback; //回调前的强引用保证

	UPROPERTY(Transient)
	TMap<int, FKGCppObjectArray> RefObjectMapForKeep; //强引用保证

	UPROPERTY(Transient)
	TMap<FString, TWeakObjectPtr<UObject>> WeakRefObjectMap; //弱引用检查，过图的时候可以检查资源的释放情况
	
protected:
	int InnerAsyncLoadAsset(const TArray<FString>& InPaths, const FAsyncLoadCompleteDelegate& CallBack, const FAsyncLoadListCompleteDelegate& CallBackList, int32 InPriority = 0, bool CallLua = false, bool IsList = false, bool KeepRef = false);
	int InnerAsyncLoadAssetWithFindAssetInMemory(const TArray<FString>& InPaths, TArray<UObject*>& OutAssets, const FAsyncLoadCompleteDelegate& CallBack, const FAsyncLoadListCompleteDelegate& CallBackList, int32 InPriority = 0, bool CallLua = false, bool IsList = false, bool KeepRef = false);
	
	void OnCompleteAsyncLoadAsset(int InLoadTaskID);
	int GenerateRequestID();
	KGCppAsyncLoadTask& AddLoadTask(int InID);
	void PrintStringList(const TArray<FString>& StringList, int Type);
	void HandleWorldCleanup(UWorld* World, bool bSessionEnded, bool bCleanupResources);
	
	void RefObjectForCallback(int InLoadID, TArray<UObject*>& InObjs);
	void ClearRefObjectForCallback(int InLoadID);
	void RefObjectForKeep(int InLoadID, TArray<UObject*>& InObjs);
	void ClearRefObjectForKeep(int InLoadID);
	void RefObjectForWeak(TArray<UObject*>& InObjs);
	
	void NotifyLoadTaskDone(KGCppAsyncLoadTask* InLoadedTask);
	bool FindAssetInMemory(const TArray<FString>& InPaths, TArray<UObject*>& OutAssets);
	
private:
	FDelegateHandle WorldCleanupHandle;
	TMap<int, KGCppAsyncLoadTask> LoadingTasks;
	TArray<int> PendingTaskIDs;
	FAsyncLoadCompleteDelegate EmptyAsyncLoadCompleteDelegate;
	FAsyncLoadListCompleteDelegate EmptyAsyncLoadListCompleteDelegate;
	TSet<FName> DeprecatedPaths;
	
	bool bEnableLog = false;
	bool bEnableLoadSync = false;
	bool bEnableLoadCancel = true;
	bool bEnableDeprecatedPath = false;
	
public:
	/**
	* Lua侧弱引用加载
	*/
	int AsyncLoadAssetID(const FString& InPath, int InPriority);
	
	UFUNCTION(BlueprintCallable)
	int AsyncLoadAssetListID(const TArray<FString>& InPaths, int32 InPriority);

	/**
	* Lua侧强引用加载
	*/
	int AsyncLoadAssetKeepReferenceID(const FString& InPath, int InPriority);
	
	UFUNCTION(BlueprintCallable)
	int AsyncLoadAssetListKeepReferenceID(const TArray<FString>& InPaths, int32 InPriority);

	/**
	* Lua侧除了初始化阶段/loading阶段允许使用同步加载以外，其他情况原则上不允许使用
	*/
	UFUNCTION(BlueprintCallable)
	int SyncLoadAssetKeepReferenceID(const FString& InPath, int64& OutLoadedAssetID);
	UFUNCTION(BlueprintCallable)
	int SyncLoadAssetListKeepReferenceID(const TArray<FString>& InPaths, TArray<int64>& OutLoadedAssetIDs);

	/**
	* Lua侧强引用加载,通过DELEGATE返回UObject
	*/
	UPROPERTY(BlueprintAssignable)
	FAsyncLoadCppAssetNotify OnAssetLoadedDelegate;
	UPROPERTY(BlueprintAssignable)
	FAsyncLoadCppAssetListNotify OnAssetListLoadedDelegate;
	
	int AsyncLoadAssetKeepReference(const FString& InPath, int InPriority);
	
	UFUNCTION(BlueprintCallable)
	int AsyncLoadAssetListKeepReference(const TArray<FString>& InPaths, int32 InPriority);
	
	void OnAsyncLoadAssetKeepReferenceLoaded(int InLoadID, UObject* Asset);
	void OnAsyncLoadAssetListKeepReferenceLoaded(int InLoadID, const TArray<UObject*>& AssetList);

	/*
	同步加载资源
	注意：
		1 加载的如果是一个列表，但是里面有目标无法加载，返回的对象是一个Null
		2 不默认进行引用持有
	*/
	UFUNCTION(BlueprintCallable)
	UObject* SyncLoadAsset(const FString& InPath);
	
	UFUNCTION(BlueprintCallable)
	TArray<UObject*> SyncLoadAssetList(const TArray<FString>& InPaths);

	void RemoveAssetReferenceByLoadID(int InLoadID);

#pragma region AssetCache

public:
	void EnableAnimCache(bool Value) { bEnableAnimCache = Value;}
	
	void ResetAnimCache();

	void ResetLevelAnimCache(int InCapacity, int PreloadAnimLruCapacity);

	bool AddAnimsToCache(EAnimSequenceCacheType CacheType, const FName& AnimLibName, const TArray<FName>& AnimPaths, const TArray<UAnimSequenceBase*>& PreLoadAnimAssets, const TArray<FName>& AnimFeatureNames, const TArray<FName>& FilterLocoNames);
	bool AddAnimsToCache(EAnimSequenceCacheType CacheType, const FName& AnimPath, UAnimSequenceBase* AnimAsset);
	bool AddAnimsToCache(EAnimSequenceCacheType CacheType, const TArray<FName>& AnimPath, const TArray<UAnimSequenceBase*>& AnimAsset);
	bool HasAnimCache(EAnimSequenceCacheType CacheType, const FName& AnimPath) const;

	bool HasAnimCacheForLocomotionABP(const FName& AnimLibName);
	bool LockLocomotionABPCache(const FName& AnimLibName);
	void UnLockLocomotionABPCache(const FName& AnimLibName);

	const TMap<FName, UAnimSequenceBase*>* GetAnimCacheForLocomotionABP(const FName& AnimLibName);
	UAnimSequenceBase* GetAnimSequenceAssetCache(const FName& AnimPath);
	
	UClass* GetAnimABPClassCache(const FName& ABPClassPath);
	void SetAnimABPClassCache(const FName& ABPClassPath, UClass* Class);
	void CleanUpABPClassCache() { ABPClassCache.Empty(); }

	FString GetAssetCacheDebugInfo() const;

	FString GetAssetManagerDebugInfo() const;

public:
	
	UPROPERTY(Transient)
	TMap<FName, TObjectPtr<UClass>> ABPClassCache;

	UPROPERTY(Transient)
	FAnimSequenceCache CacheAnimsInGame;

	UPROPERTY(Transient)
	FAnimSequenceCache CacheAnimsInLevel;
	
	bool bEnableAnimCache = true;
	int AnimLibAssetHitTimes = 0;
	int AnimLibAssetMissTimes = 0;

#pragma endregion AssetCache
	
};
