#pragma once
#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "KGTimerManager.generated.h"

UCLASS(Blueprintable, BlueprintType)
class KGCORE_API UKGTimerManager : public UKGBasicManager
{
	GENERATED_BODY()

public:

	virtual void NativeInit();
	virtual void NativeUninit();
	virtual EManagerType GetManagerType() { return EManagerType::EMT_TimerManager; }

	static UKGTimerManager* GetInstance(UObject* InContext)
	{
		return Cast<UKGTimerManager>(GetManagerByType(InContext, EManagerType::EMT_TimerManager));
	}

	virtual void Tick(float DeltaTime) override;
	virtual void OnPostLoadMapWithWorld(UWorld* World) override;

private:
	double timeSeconds = 0;
	double realTimeSeconds = 0;
};
