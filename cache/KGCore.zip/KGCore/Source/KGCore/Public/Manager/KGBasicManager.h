#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Engine/GameInstance.h"
#include "Kismet/GameplayStatics.h"
#include "Misc/CommonDefines.h"

#include "Misc/LowLevelFunctions.h"
#include "Lua/KGLuaEntityBase.h"
#include "slua.h"
#include "KGBasicManager.generated.h"

class UKGBasicManager;

USTRUCT()
struct FTickUKGManagerFunction : public FTickFunction
{
	GENERATED_USTRUCT_BODY()

	FTickUKGManagerFunction() : Manager(nullptr) {}

	// Begin FTickFunction overrides
	virtual void ExecuteTick(float DeltaTime, enum ELevelTick TickType, ENamedThreads::Type CurrentThread, const FGraphEventRef& MyCompletionGraphEvent) override;
	virtual FString DiagnosticMessage() override;
	virtual FName DiagnosticContext(bool bDetailed) override;
	// End FTickFunction overrides
	
	class UKGBasicManager* Manager;
};

template<>
struct TStructOpsTypeTraits<FTickUKGManagerFunction> : public TStructOpsTypeTraitsBase2<FTickUKGManagerFunction>
{
	enum
	{
		WithCopy = false
	};
};

UCLASS(Abstract, Blueprintable, BlueprintType)
class KGCORE_API UKGBasicManager : public UObject, public KGLuaObjectBase
{
	GENERATED_BODY()
	
public:
	UFUNCTION(BlueprintCallable)
	virtual void NativeInit();

	UFUNCTION(BlueprintCallable)
	virtual void NativeUninit();

	bool GetIsActive() const;
	
	virtual void Tick(float DeltaTime) {};

	virtual void OnPostLoadMapWithWorld(UWorld* World) {};

	FTickUKGManagerFunction& GetTickFunction();
	
	UPROPERTY()
	FTickUKGManagerFunction TickFunction;

public:
	virtual EManagerType GetManagerType() { return EManagerType::EMT_Null; }
	void SetLuaGameInstance(class UBasicLuaGameInstance* InLuaGameInstance);

	class UKGBasicManager* GetManagerByType(EManagerType InType);
	static UKGBasicManager* GetManagerByType(UObject* InContext, EManagerType InType);

	lua_State* GetLuaState();

	void SetLuaEnv(class ULuaEnvBase *InLuaEnv) { LuaEnv = InLuaEnv; }

public:
	FString LuaStateName = "";
	 
private:
	bool bActive = false;

	UPROPERTY(Transient)
    class ULuaEnvBase *LuaEnv= nullptr;
};
