#pragma once

#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "Engine/World.h"
#include "KGObjectActorManager.generated.h"



DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FWorldCleanNotify, UWorld*, InWorld);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnActorDestroyedNotify, AActor*, InActor, int64, InActorID);


UCLASS(Blueprintable, BlueprintType)
class KGCORE_API UKGObjectActorManager : public UKGBasicManager, public FUObjectArray::FUObjectCreateListener, public FUObjectArray::FUObjectDeleteListener
{
	GENERATED_BODY()

public:

	virtual void NativeInit();
	virtual void NativeUninit();
	virtual EManagerType GetManagerType() { return EManagerType::EMT_ObjectActorManager; }
	static UKGObjectActorManager* GetInstance(UObject* InContext)
	{
		return Cast<UKGObjectActorManager>(GetManagerByType(InContext, EManagerType::EMT_ObjectActorManager));
	}

	virtual void NotifyUObjectCreated(const UObjectBase* InObject, int32 Index) override;
	virtual void NotifyUObjectDeleted(const UObjectBase* InObject, int32 Index) override;

	virtual void OnUObjectArrayShutdown();


	void OnWorldCleanupEnd(UWorld* World, bool bSessionEnded, bool bCleanupResources);

	UFUNCTION()
	void OnActorDestroyed(AActor* InActor);


	// 静态导出
	int64 GetIDByObejct(UObject* InObj);
	UObject* GetObjectByID(int64 InID);

	// 因为slua不支持把函数参数从UClass*自动转为UObject*, 所以额外开放一组接口做兼容处理
	int64 GetIDByClass(UClass* InClass);
	UClass* GetClassByID(int64 InID);
	
	// 反射接口 - actor
	UFUNCTION(BlueprintCallable)
		AActor* SpawnActor(UClass* InClass, bool bKeepReference, float InLocationX, float InLocationY, float InLocationZ, float InPitch, float InYaw, float InRoll);
	UFUNCTION(BlueprintCallable)
		void DestroyActor(AActor* InActor);
	UFUNCTION(BlueprintCallable)
		void DestroyActorByID(int64 InID);
	UFUNCTION(BlueprintCallable)
		void DestroyActorList(const TArray<AActor*>& InActors);
	UFUNCTION(BlueprintCallable)
		void DestroyActorListByID(const TArray<int64>& InActorIDs);



	//反射接口 - object
	//动态创建的uobject，需要业务方进行手动释放；游戏退出时，会将未释放对象信息警告式输出，日常需要保障这个异常为0
	UFUNCTION(BlueprintCallable)
	UObject* KGNewObject(UClass* InClass, UObject* InOuter, bool bKeepReference);
	
	UFUNCTION(BlueprintCallable)
	void ReferenceObject(UObject* InObject);
	
	// 不会强制删除对象，但是把这个管理器与这个对象的引用关系释放掉
	UFUNCTION(BlueprintCallable)
	void RemoveObjectReference(const UObject* InObject);
	UFUNCTION(BlueprintCallable)
	void RemoveObjectReferenceByID(int64 InID);
	UFUNCTION(BlueprintCallable)
	void RemoveObjectListReference(const TArray<UObject*>& InObjects);
	UFUNCTION(BlueprintCallable)
	void RemoveObjectListReferenceByID(const TArray<int64> InIDs);


	/*
		回调代理
	*/
	UPROPERTY(Transient)
	TMap<int64, UObject*> DynamicObjectMap;

	UPROPERTY(Transient)
	TMap<int64, AActor*> DynamicActorMap;


	UPROPERTY(BlueprintAssignable)
	FWorldCleanNotify OnWorldCleanUpDelegate;

	UPROPERTY(BlueprintAssignable)
	FOnActorDestroyedNotify OnActorDestoryedDelegate;

	FActorSpawnParameters SpawnActorParameters;

private:
	void InnerReferenceObject(UObject* InObject);
	void UnreferenceObject(UObject* InObject);

	void ReferenceActor(AActor* InActor);
	void UnRefernceActor(AActor* InActor);

	void UnreferenceAllActors();
	

	// @C7 Code Begin.  ADD by kanzhengjie
protected:
	class UWorld* GetSpawnActorWorld();
#if WITH_EDITOR
	UFUNCTION(BlueprintCallable)
	void SetSpawnActorWorld(UWorld* InWorld) { OverrideWorld = InWorld; };
	//对话编辑器Lua State在小编辑器窗口中，但角色要生成到大世界World中，这里可以重新指定一下
	TWeakObjectPtr<class UWorld> OverrideWorld;
	// @C7 Code End.  ADD by kanzhengjie
#endif
};
