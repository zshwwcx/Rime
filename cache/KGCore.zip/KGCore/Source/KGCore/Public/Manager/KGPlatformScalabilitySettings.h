#pragma once
#include "CoreMinimal.h"
#include "Manager/KGBasicManager.h"
#include "KGPlatformScalabilitySettings.generated.h"

DEFINE_LOG_CATEGORY_STATIC(KGPlatformScalabilitySettings, Log, All);

#define CPP_MANAGER_LOG(Format, ...) \
if (bEnableLog) \
{ \
FString FinalLog = FString::Printf(Format, ##__VA_ARGS__); \
UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("%s"), *FinalLog); \
}

UCLASS(Blueprintable, BlueprintType)
class KGCORE_API UKGPlatformScalabilitySettings : public UKGBasicManager
{
	GENERATED_BODY()

public:

	virtual void NativeInit();
	virtual void NativeUninit();
	virtual EManagerType GetManagerType() { return EManagerType::EMT_PlatformScalabilitySettings; }

	static UKGPlatformScalabilitySettings* GetInstance(UObject* InContext)
	{
		return Cast<UKGPlatformScalabilitySettings>(GetManagerByType(InContext, EManagerType::EMT_PlatformScalabilitySettings));
	}

	void EnableLog(bool value){ bEnableLog = value;}
	void DumpDebugInfo();

#pragma region Lod Budget
	UFUNCTION(BlueprintCallable)
	void SetScalabilityLodValueBool(const FString& Category, const FString& Key, const TArray<bool>& LodValues);
	UFUNCTION(BlueprintCallable)
	void SetScalabilityLodValueFloat(const FString& Category, const FString& Key, const TArray<float>& LodValues);
	UFUNCTION(BlueprintCallable)
	void SetScalabilityLodValueString(const FString& Category, const FString& Key, const TArray<FString>& LodValues);

	template<typename T>
	const TArray<T>& GetScalabilityLodValueArray(const FString& Category, const FString& Key);

	// 声明特化
	template<>
	const TArray<bool>& GetScalabilityLodValueArray<bool>(const FString& Category, const FString& Key);
	template<>
	const TArray<float>& GetScalabilityLodValueArray<float>(const FString& Category, const FString& Key);
	template<>
	const TArray<FString>& GetScalabilityLodValueArray<FString>(const FString& Category, const FString& Key);

	template<typename T>
	T GetScalabilityLodValue(int LOD, const FString& Category, const FString& Key);

	// 声明特化
	template<>
	bool GetScalabilityLodValue<bool>(int LOD, const FString& Category, const FString& Key);
	template<>
	float GetScalabilityLodValue<float>(int LOD, const FString& Category, const FString& Key);
	template<>
	FString GetScalabilityLodValue<FString>(int LOD, const FString& Category, const FString& Key);
	
#pragma endregion Lod Budget

	bool CheckLodBoolPermit(int Lod, const FString& CategoryLod, const FString& Key);
	void SetScalabilityValueBool(const FString& Category, const FString& Key, bool Value);
	void SetScalabilityValueFloat(const FString& Category, const FString& Key, float Value);
	void SetScalabilityValueString(const FString& Category, const FString& Key, const FString& Value);

	template<typename T>
	T GetScalabilityValue(const FString& Category, const FString& Key);

	// 声明特化
	template<>
	bool GetScalabilityValue<bool>(const FString& Category, const FString& Key);
	template<>
	float GetScalabilityValue<float>(const FString& Category, const FString& Key);
	template<>
	FString GetScalabilityValue<FString>(const FString& Category, const FString& Key);

#pragma region LimitBudget
	bool ConsumeActorLimitBudgetWithLod(int64 ActorID, int Lod, const FString& CategoryLimit, const FString& CategoryLod, const FString& Key);
	bool ReleaseActorLimitBudget(int64 ActorID, const FString& CategoryLimit, const FString& Key);
	void ReleaseActorAllLimitBudget(int64 ActorID);
	void EnableBudget(bool value){ bEnableBudget = value;}

protected:
	void SetActorUsedLimitBudgetValue(const FString& Category, const FString& Key, float Value);
	float GetActorUsedLimitBudgetValue(const FString& Category, const FString& Key);
	bool ConsumeBudgetScalabilityLimit(const FString& Category, const FString& Key);
	bool ReleaseBudgetScalabilityLimit(const FString& Category, const FString& Key);
	
#pragma endregion LimitBudget

protected:

	bool bEnableLog = false;
	TMap<FString,TMap<FString,TArray<bool>>> ScalabilityLodValueBoolData;
	TMap<FString,TMap<FString,TArray<float>>> ScalabilityLodValueFloatData;
	TMap<FString,TMap<FString,TArray<FString>>> ScalabilityLodValueStringData;
	
	TMap<FString,TMap<FString,bool>> ScalabilityValueBoolData;
	TMap<FString,TMap<FString,float>> ScalabilityValueFloatData;
	TMap<FString,TMap<FString,FString>> ScalabilityValueStringData;

	bool bEnableBudget = true;
	TMap<int64,TMap<FString,TMap<FString,bool>>> ScalabilityBudgetRecord;
	TMap<FString,TMap<FString,float>> UsedScalabilityBudgetRecord;
};
