// Fill out your copyright notice in the Description page of Project Settings.


#include "Input/UKGInputProcessManager.h"

#include "Input/KGInputProcessor.h"
#include "Framework/Application/SlateApplication.h"
#include "UObject/UObjectThreadContext.h"


UUKGInputProcessManager::UUKGInputProcessManager(const FObjectInitializer& ObjectInitializer):
	bListenMouseDown(false), bListenMouseUp(false)
{
}

UUKGInputProcessManager::~UUKGInputProcessManager()
{
}

void UUKGInputProcessManager::NativeUninit()
{
	Super::NativeUninit();
	UnBindAllKeyEvents();
	UnBindAllMouseEvents();
}

void UUKGInputProcessManager::NativeInit()
{
	Super::NativeInit();

	if (ensure(FSlateApplication::IsInitialized()))
	{
		InputPreprocessor = MakeShared<KGInputProcessor>();
		FSlateApplication::Get().RegisterInputPreProcessor(InputPreprocessor);

		InputPreprocessor->InputKeyDelegate.BindUObject(this, &UUKGInputProcessManager::InputKeyNotify);
		InputPreprocessor->InputMouseDelegate.BindUObject(this, &UUKGInputProcessManager::InputMouseNotify);
	    InputPreprocessor->InputPointerMoveDelegate.BindUObject(this, &UUKGInputProcessManager::InputPointerMoveNotify);
	}
}

void UUKGInputProcessManager::BindKeyDownEvent(FName KeyName)
{
	PressedKeyMaps.Emplace(KeyName);
}

void UUKGInputProcessManager::BindKeyUpEvent(FName KeyName)
{
	ReleasedKeyMaps.Emplace(KeyName);
}

void UUKGInputProcessManager::UnBindKeyDownEvent(FName KeyName)
{
	PressedKeyMaps.Remove(KeyName);
}

void UUKGInputProcessManager::UnBindKeyUpEvent(FName KeyName)
{
	ReleasedKeyMaps.Remove(KeyName);
}

void UUKGInputProcessManager::UnBindAllKeyEvents()
{
	PressedKeyMaps.Empty();
	ReleasedKeyMaps.Empty();
}

void UUKGInputProcessManager::BindMouseButtonDownEvent()
{
	bListenMouseDown = true;
}

void UUKGInputProcessManager::UnBindMouseButtonDownEvent()
{
	bListenMouseDown = false;
}

void UUKGInputProcessManager::BindMouseButtonUpEvent()
{
	bListenMouseUp = true;
}

void UUKGInputProcessManager::UnBindMouseButtonUpEvent()
{
	bListenMouseUp = false;
}

void UUKGInputProcessManager::BindPointerMoveEvent()
{
    bListenPointerMove = true;
}

void UUKGInputProcessManager::UnBindPointerMoveEvent()
{
    bListenPointerMove = false;
}

void UUKGInputProcessManager::UnBindAllMouseEvents()
{
	bListenMouseDown = false;
	bListenMouseUp = false;
    bListenPointerMove = false;
}

bool UUKGInputProcessManager::InputKeyNotify(FName KeyName, EInputEvent Event) const
{
	// Don't call key notify delegate if inside of a PostLoad
	if (FUObjectThreadContext::Get().IsRoutingPostLoad)
	{
		UE_LOG(LogTemp, Error, TEXT("[UUKGInputProcessManager::InputMouseNotify] Lost Key notify due to FUObjectThreadContext IsRoutingPostLoad"));
		return false;
	}
	
	if (Event == IE_Pressed && PressedKeyMaps.Contains(KeyName) && OnGetKeyEventDelegate.IsBound())
	{
		return OnGetKeyEventDelegate.Execute(KeyName, Event);
	} 
	if(Event == IE_Released && ReleasedKeyMaps.Contains(KeyName) && OnGetKeyEventDelegate.IsBound())
	{ 
		return OnGetKeyEventDelegate.Execute(KeyName, Event);
	}
	return false;
}

bool UUKGInputProcessManager::InputMouseNotify(const FPointerEvent& MouseEvent, bool bIsDown) const
{
	// Don't call mouse notify delegate if inside of a PostLoad
	if (FUObjectThreadContext::Get().IsRoutingPostLoad)
	{
		UE_LOG(LogTemp, Error, TEXT("[UUKGInputProcessManager::InputMouseNotify] Lost Mouse notify due to FUObjectThreadContext IsRoutingPostLoad"));
		return false;
	}
	
	if(bIsDown && OnGetMouseButtonDownDelegate.IsBound())
	{
	    OnGetMouseButtonDownNoReplyDelegate.Broadcast(MouseEvent);
		return OnGetMouseButtonDownDelegate.Execute(MouseEvent);
	}
	if(!bIsDown && OnGetMouseButtonUpDelegate.IsBound())
	{
	    OnGetMouseButtonUpNoReplyDelegate.Broadcast(MouseEvent);
		return OnGetMouseButtonUpDelegate.Execute(MouseEvent);
	}
	return false;
}

bool UUKGInputProcessManager::InputPointerMoveNotify(const FPointerEvent& InPointerEvent) const
{
    // Don't call mouse notify delegate if inside of a PostLoad
    if (FUObjectThreadContext::Get().IsRoutingPostLoad)
    {
        UE_LOG(LogTemp, Error, TEXT("[UUKGInputProcessManager::InputMouseNotify] Lost Mouse notify due to FUObjectThreadContext IsRoutingPostLoad"));
        return false;
    }
    
    if (bListenPointerMove)
    {
        OnGetPointerMoveNoReplyDelegate.Broadcast(InPointerEvent);
        if (OnGetPointerMoveDelegate.IsBound())
        {
            return OnGetPointerMoveDelegate.Execute(InPointerEvent);
        }
    }
    
    return false;
}
