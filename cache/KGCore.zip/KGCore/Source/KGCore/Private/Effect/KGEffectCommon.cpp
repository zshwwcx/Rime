#include "Effect/KGEffectCommon.h"

#include "Curves/CurveFloat.h"
#include "Curves/CurveLinearColor.h"
#include "Curves/CurveVector.h"

bool FKGCurveImplCurveFloat::GetValue(float InTime, float& OutVal) const
{
	if (!CurveFloat.IsValid())
	{
		return false;
	}
	
	OutVal = CurveFloat->GetFloatValue(InTime);
	return true;
}

bool FKGCurveImplCurveFloat::GetTimeRange(float& OutMin, float& OutMax) const
{
	if (!CurveFloat.IsValid())
	{
		return false;
	}
	
	CurveFloat->GetTimeRange(OutMin, OutMax);
	return true;
}

bool FKGCurveImplCurveVector::GetValue(float InTime, FVector& OutVal) const
{
	if (!CurveVector.IsValid())
	{
		return false;
	}
	
	OutVal = CurveVector->GetVectorValue(InTime);
	return true;
}

bool FKGCurveImplCurveVector::GetTimeRange(float& OutMin, float& OutMax) const
{
	if (!CurveVector.IsValid())
	{
		return false;
	}
	
	CurveVector->GetTimeRange(OutMin, OutMax);
	return true;
}

bool FKGCurveImplCurveLinearColor::GetValue(float InTime, FLinearColor& OutVal) const
{
	if (!CurveLinearColor.IsValid())
	{
		return false;
	}
	
	OutVal = CurveLinearColor->GetLinearColorValue(InTime);
	return true;
}

bool FKGCurveImplCurveLinearColor::GetTimeRange(float& OutMin, float& OutMax) const
{
	if (!CurveLinearColor.IsValid())
	{
		return false;
	}
	
	CurveLinearColor->GetTimeRange(OutMin, OutMax);
	return true;
}

bool FKGCurveImplRuntimeFloatCurve::GetValue(float InTime, float& OutVal) const
{
	auto* RichCurvePtr = GetRichCurve();
	if (!RichCurvePtr)
	{
		return false;
	}
	
	OutVal = RichCurvePtr->Eval(InTime);
	return true;
}

bool FKGCurveImplRuntimeFloatCurve::GetTimeRange(float& OutMin, float& OutMax) const
{
	auto* RichCurvePtr = GetRichCurve();
	if (RichCurvePtr == nullptr)
	{
		return false;
	}
	
	RichCurvePtr->GetTimeRange(OutMin, OutMax);
	return true;
}

const FRichCurve* FKGCurveImplRuntimeFloatCurve::GetRichCurve() const
{
	if (ExternalCurve.IsValid())
	{
		return &(ExternalCurve->FloatCurve);
	}
	
	return &RichCurve;
}

void FKGCurveEvalParams::InitEvalParams(UCurveBase* InCurve, bool bInNeedRemap, float InRemapTime, bool bInEnableLoop)
{
	if (UCurveFloat* FloatCurve = Cast<UCurveFloat>(InCurve))
	{
		FKGCurveFloatEvalHelper CurveFloatEvalHelper;
		CurveFloatEvalHelper.InitEvalParams(bInNeedRemap, InRemapTime, bInEnableLoop, FloatCurve);
		CurveEvalHelper.SetSubtype<FKGCurveFloatEvalHelper>(CurveFloatEvalHelper);
	}
	else if (UCurveVector* CurveVector = Cast<UCurveVector>(InCurve))
	{
		FKGCurveVectorEvalHelper CurveVectorEvalHelper;
		CurveVectorEvalHelper.InitEvalParams(bInNeedRemap, InRemapTime, bInEnableLoop, CurveVector);
		CurveEvalHelper.SetSubtype<FKGCurveVectorEvalHelper>(CurveVectorEvalHelper);
	}
	else if (UCurveLinearColor* CurveLinearColor = Cast<UCurveLinearColor>(InCurve))
	{
		FKGCurveLinearColorEvalHelper CurveLinearColorEvalHelper;
		CurveLinearColorEvalHelper.InitEvalParams(bInNeedRemap, InRemapTime, bInEnableLoop, CurveLinearColor);
		CurveEvalHelper.SetSubtype<FKGCurveLinearColorEvalHelper>(CurveLinearColorEvalHelper);
	}
	else
	{
		CurveEvalHelper.Reset();
	}
}

bool FKGCurveEvalParams::DoesTimeReachEnd(float InTime)
{
	if (CurveEvalHelper.HasSubtype<FKGCurveFloatEvalHelper>())
	{
		auto& CurveFloatEvalHelper = CurveEvalHelper.GetSubtype<FKGCurveFloatEvalHelper>();
		return CurveFloatEvalHelper.DoesTimeReachEnd(InTime);
	}
	if (CurveEvalHelper.HasSubtype<FKGCurveVectorEvalHelper>())
	{
		auto& CurveVectorEvalHelper = CurveEvalHelper.GetSubtype<FKGCurveVectorEvalHelper>();
		return CurveVectorEvalHelper.DoesTimeReachEnd(InTime);
	}
	if (CurveEvalHelper.HasSubtype<FKGCurveLinearColorEvalHelper>())
	{
		auto& CurveLinearColorEvalHelper = CurveEvalHelper.GetSubtype<FKGCurveLinearColorEvalHelper>();
		return CurveLinearColorEvalHelper.DoesTimeReachEnd(InTime);
	}
	return true;
}

bool FKGCurveEvalParams::IsValid() const
{
	if (CurveEvalHelper.HasSubtype<FKGCurveFloatEvalHelper>())
	{
		auto& CurveFloatEvalHelper = CurveEvalHelper.GetSubtype<FKGCurveFloatEvalHelper>();
		return CurveFloatEvalHelper.IsValid();
	}
	if (CurveEvalHelper.HasSubtype<FKGCurveVectorEvalHelper>())
	{
		auto& CurveVectorEvalHelper = CurveEvalHelper.GetSubtype<FKGCurveVectorEvalHelper>();
		return CurveVectorEvalHelper.IsValid();
	}
	if (CurveEvalHelper.HasSubtype<FKGCurveLinearColorEvalHelper>())
	{
		auto& CurveLinearColorEvalHelper = CurveEvalHelper.GetSubtype<FKGCurveLinearColorEvalHelper>();
		return CurveLinearColorEvalHelper.IsValid();
	}
	return false;
}

bool FKGCurveEvalParams::GetFloatValue(float InTime, float& OutVal)
{
	if (CurveEvalHelper.HasSubtype<FKGCurveFloatEvalHelper>())
	{
		auto& CurveFloatEvalHelper = CurveEvalHelper.GetSubtype<FKGCurveFloatEvalHelper>();
		return CurveFloatEvalHelper.GetValue(InTime, OutVal);
	}
	return false;
}

bool FKGCurveEvalParams::GetVectorValue(float InTime, FVector& OutVal)
{
	if (CurveEvalHelper.HasSubtype<FKGCurveVectorEvalHelper>())
	{
		auto& CurveVectorEvalHelper = CurveEvalHelper.GetSubtype<FKGCurveVectorEvalHelper>();
		return CurveVectorEvalHelper.GetValue(InTime, OutVal);
	}
	return false;
}

bool FKGCurveEvalParams::GetLinearColorValue(float InTime, FLinearColor& OutVal)
{
	if (CurveEvalHelper.HasSubtype<FKGCurveLinearColorEvalHelper>())
	{
		auto& CurveLinearColorEvalHelper = CurveEvalHelper.GetSubtype<FKGCurveLinearColorEvalHelper>();
		return CurveLinearColorEvalHelper.GetValue(InTime, OutVal);
	}
	return false;
}
