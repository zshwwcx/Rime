#include "Effect/KGNiagaraSignificanceHandler.h"

#include "NiagaraComponent.h"
#include "NiagaraScalabilityManager.h"
#include "NiagaraSystemInstanceController.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"

void UNSHDistanceToPlayer::CalculateSignificance(TConstArrayView<UNiagaraComponent*> Components, TArrayView<FNiagaraScalabilityState> OutState, TConstArrayView<FNiagaraScalabilitySystemData> SystemData, TArray<int32>& OutIndices)
{
	const int32 ComponentCount = Components.Num();
	check(ComponentCount == OutState.Num());

	ACharacter* LocalPlayer = UGameplayStatics::GetPlayerCharacter(Components[0], 0);
	FVector LPLoc = FVector(1.0f, 2.0f, 3.0f);
	if (LocalPlayer)
	{
		LPLoc = LocalPlayer->GetActorLocation();
	}

	for (int32 CompIdx = 0; CompIdx < ComponentCount; ++CompIdx)
	{
		FNiagaraScalabilityState& State = OutState[CompIdx];
		const FNiagaraScalabilitySystemData& SysData = SystemData[State.SystemDataIndex];

		const bool AddIndex = (SysData.bNeedsSignificanceForActiveOrDirty && (!State.bCulled || State.IsDirty())) || SysData.bNeedsSignificanceForCulled;

		if (State.bCulled && !SysData.bNeedsSignificanceForCulled)
		{
			State.Significance = 0.0f;
		}
		else
		{
			float LODDistance = 0.0f;
			UNiagaraComponent* Component = Components[CompIdx];

			if (LocalPlayer)
			{
				LODDistance = (LPLoc - Component->GetComponentLocation()).Size();
			}
			else
			{
				if (Component->bEnablePreviewLODDistance)
				{
					LODDistance = Component->PreviewLODDistance;
				}
				else if (FNiagaraSystemInstanceControllerConstPtr Controller = Component->GetSystemInstanceController())
				{
					LODDistance = Controller->GetLODDistance();
				}
			}

			State.Significance = 1.0f / FMath::Max(LODDistance, 0.1f);
		}

		if (AddIndex)
		{
			OutIndices.Add(CompIdx);
		}
	}
}


void UNSHDistanceToPlayerWithBound::CalculateSignificance(TConstArrayView<UNiagaraComponent*> Components, TArrayView<FNiagaraScalabilityState> OutState, TConstArrayView<FNiagaraScalabilitySystemData> SystemData, TArray<int32>& OutIndices)
{
	const int32 ComponentCount = Components.Num();
	check(ComponentCount == OutState.Num());

	ACharacter* LocalPlayer = UGameplayStatics::GetPlayerCharacter(Components[0], 0);
	FVector LPLoc = FVector(1.0f, 2.0f, 3.0f);
	if (LocalPlayer)
	{
		LPLoc = LocalPlayer->GetActorLocation();
	}

	for (int32 CompIdx = 0; CompIdx < ComponentCount; ++CompIdx)
	{
		FNiagaraScalabilityState& State = OutState[CompIdx];
		const FNiagaraScalabilitySystemData& SysData = SystemData[State.SystemDataIndex];

		const bool AddIndex = (SysData.bNeedsSignificanceForActiveOrDirty && (!State.bCulled || State.IsDirty())) || SysData.bNeedsSignificanceForCulled;

		if (State.bCulled && !SysData.bNeedsSignificanceForCulled)
		{
			State.Significance = 0.0f;
		}
		else
		{
			float LODDistance = 0.0f;
			UNiagaraComponent* Component = Components[CompIdx];

			if (LocalPlayer)
			{
				float BoundRadius = 0.0f;

				if (UNiagaraSystem* CurrentAsset = Component->GetAsset())
				{
					if (CurrentAsset->bFixedBounds == false && CurrentAsset->GetEffectType())
					{
						BoundRadius = CurrentAsset->GetEffectType()->DefaultBoundRadius;
					}
				}

				if (BoundRadius < 1e-4)
				{
					BoundRadius = Component->Bounds.SphereRadius;
				}
				
				LODDistance = FMath::Max((LPLoc - Component->GetComponentLocation()).Size() - BoundRadius, 0.0f);
			}
			else
			{
				if (Component->bEnablePreviewLODDistance)
				{
					LODDistance = Component->PreviewLODDistance;
				}
				else if (FNiagaraSystemInstanceControllerConstPtr Controller = Component->GetSystemInstanceController())
				{
					LODDistance = Controller->GetLODDistance();
				}
			}

			State.Significance = 1.0f / FMath::Max(LODDistance, 0.1f);
		}

		if (AddIndex)
		{
			OutIndices.Add(CompIdx);
		}
	}
}
