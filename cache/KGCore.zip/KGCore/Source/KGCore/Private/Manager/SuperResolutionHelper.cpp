#include "Manager/SuperResolutionHelper.h"

#include "DataDrivenShaderPlatformInfo.h"
#include "Engine/Engine.h"

#if PLATFORM_WINDOWS
#include "DLSSLibrary.h"
#include "FFXFSR3Library.h"
#include "FFXFSR4Settings.h"
#include "XeSSBlueprintLibrary.h"
#include "XeFGBlueprintLibrary.h"
#include "KGEngineCoreBPLibrary.h"
#include "StreamlineLibraryDLSSG.h"


#define HelperFunctionDeclare \
	static TArray<ESuperResolutionQualityMode> GetSuperResolutionSupport(); \
	static TArray<EFrameGenerationQualityMode> GetFrameGenerationSupport(); \
	static void SwitchSuperResolution(UObject* WorldContextObject,ESuperResolutionQualityMode Quality); \
	static ESuperResolutionQualityMode GetSuperResolutionQuality(); \
	static bool SwitchFrameGeneration(UObject* WorldContextObject, EFrameGenerationQualityMode FrameGenerationQuality); \
	static EFrameGenerationQualityMode GetFrameGenerationQuality(); \
	static float GetFPS(); \
	static float GetSRModeScreenPercentage(UObject*, ESuperResolutionQualityMode Quality);

namespace SuperResolutionHelperImpl
{
	struct FDLSSHelper
	{
		static UDLSSMode QualityToDetail(ESuperResolutionQualityMode Quality);
		static ESuperResolutionQualityMode DetailToQuality(UDLSSMode Quality);
		HelperFunctionDeclare
	};

	struct FFSRHelper
	{
		static UFSR3Mode QualityToDetail(ESuperResolutionQualityMode Quality);
		static ESuperResolutionQualityMode DetailToQuality(UFSR3Mode Quality);
		HelperFunctionDeclare
	};

	struct FXeSSHelper
	{
		static EXeSSQualityMode QualityToDetail(ESuperResolutionQualityMode Quality);
		static ESuperResolutionQualityMode DetailToQuality(EXeSSQualityMode Quality);
		HelperFunctionDeclare
	};

	struct TSRHelper
	{
		static UTSRMode QualityToDetail(ESuperResolutionQualityMode Quality);
		static ESuperResolutionQualityMode DetailToQuality(UTSRMode Quality);
		HelperFunctionDeclare
	};
}


#define SRDispatch0(Method, Function) \
switch (Method) \
{ \
	case ESuperResolutionMethod::DLSS: \
	return SuperResolutionHelperImpl::FDLSSHelper::Function(); \
	case ESuperResolutionMethod::FSR: \
	return SuperResolutionHelperImpl::FFSRHelper::Function(); \
	case ESuperResolutionMethod::XeSS: \
	return SuperResolutionHelperImpl::FXeSSHelper::Function(); \
	case ESuperResolutionMethod::TSR : \
	return SuperResolutionHelperImpl::TSRHelper::Function(); \
	default: \
	return {}; \
}

#endif


bool USuperResolutionHelper::bInit = false;

void USuperResolutionHelper::Init()
{
	if (bInit)
	{
		return;
	}
	CurMethod = static_cast<ESuperResolutionMethod>(USuperResolutionBPLibrary::GetFGMode());
	bInit = true;
}

bool IsMobilePreview(UObject* WorldContextObject)
{
#if WITH_EDITOR
	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull);
	return World && World->GetFeatureLevel() == ERHIFeatureLevel::ES3_1;
#else
	return false;
#endif
	
}

TArray<ESuperResolutionQualityMode> USuperResolutionHelper::GetSuperResolutionSupport(UObject* WorldContextObject,
	ESuperResolutionMethod Method)
{
#if PLATFORM_WINDOWS
	auto Impl = [](ESuperResolutionMethod MethodLocal) -> TArray<ESuperResolutionQualityMode>
	{
		SRDispatch0(MethodLocal, GetSuperResolutionSupport);
	};
#if WITH_EDITOR
	if (IsMobilePreview(WorldContextObject))
	{
		return {};
	}
#endif
	auto Res = Impl(Method);
	Res.AddUnique(ESuperResolutionQualityMode::Off);
	Res.Sort();
	return Res;
#else
	return {};
#endif
}


TArray<EFrameGenerationQualityMode> USuperResolutionHelper::GetFrameGenerationSupport(UObject* WorldContextObject,
	ESuperResolutionMethod Method)
{
#if PLATFORM_WINDOWS
	auto Impl = [](ESuperResolutionMethod MethodLocal) -> TArray<EFrameGenerationQualityMode>
	{
		SRDispatch0(MethodLocal, GetFrameGenerationSupport);
	};

	auto Support = USuperResolutionBPLibrary::GetFGMode();
	if (static_cast<int32>(Support) != static_cast<int32>(Method))
	{
		return {};
	}
#if WITH_EDITOR
	if (IsMobilePreview(WorldContextObject))
	{
		return {};
	}
#endif
	auto Res = Impl(Method);
	Res.Sort();
	return Res;
#else
	return {};
#endif
}


#if PLATFORM_WINDOWS

#define SRDispatch2(Method, Function, Arg1, Arg2) \
switch (Method) \
{ \
case ESuperResolutionMethod::DLSS: \
SuperResolutionHelperImpl::FDLSSHelper::Function(Arg1,Arg2); break;\
case ESuperResolutionMethod::FSR: \
SuperResolutionHelperImpl::FFSRHelper::Function(Arg1,Arg2); break;\
case ESuperResolutionMethod::XeSS: \
SuperResolutionHelperImpl::FXeSSHelper::Function(Arg1,Arg2); break;;\
case ESuperResolutionMethod::TSR : \
SuperResolutionHelperImpl::TSRHelper::Function(Arg1,Arg2); break;\
default: \
break; \
}

#define SRDispatch2_Return(Method, Function, Arg1,Arg2) \
switch (Method) \
{ \
case ESuperResolutionMethod::DLSS: \
return SuperResolutionHelperImpl::FDLSSHelper::Function(Arg1,Arg2); \
case ESuperResolutionMethod::FSR: \
return SuperResolutionHelperImpl::FFSRHelper::Function(Arg1,Arg2); \
case ESuperResolutionMethod::XeSS: \
return SuperResolutionHelperImpl::FXeSSHelper::Function(Arg1,Arg2);\
case ESuperResolutionMethod::TSR : \
return SuperResolutionHelperImpl::TSRHelper::Function(Arg1,Arg2);\
default: \
break; \
}

#endif


ESuperResolutionMethod USuperResolutionHelper::CurMethod = ESuperResolutionMethod::None;
bool USuperResolutionHelper::bHasXeSS = false;

void USuperResolutionHelper::SetSuperResolution(UObject* WorldContextObject, ESuperResolutionMethod Method,
                                                ESuperResolutionQualityMode Quality, bool bDisablePre)
{
#if PLATFORM_WINDOWS
	Init();
	if (bDisablePre && Method != CurMethod)
	{
		DisableCurSuperResolution(WorldContextObject);
		DisableCurFrameGeneration(WorldContextObject);
	}
	SRDispatch2(Method, SwitchSuperResolution, WorldContextObject, Quality);

	CurMethod = Method;
#endif
}

bool USuperResolutionHelper::bInitVSync = false;
int32 USuperResolutionHelper::PreviousVSync = 1;
uint32 USuperResolutionHelper::PreviousForceDisableFrameRateSmoothing = 0;

bool USuperResolutionHelper::SetFrameGeneration(UObject* WorldContextObject,
                                                ESuperResolutionMethod Method,
                                                EFrameGenerationQualityMode FrameGenerationQuality, bool bDisablePre)
{
#if PLATFORM_WINDOWS
	Init();
	if (Method != CurMethod)
	{
		UE_LOG(LogTemp, Warning, TEXT("Cur Method %d vs Input Method %d"), CurMethod, Method);
		return false;
	}
	if (bDisablePre && Method != CurMethod)
	{
		DisableCurFrameGeneration(WorldContextObject);
	}

	if (Method == ESuperResolutionMethod::None)
	{
		SetFrameGenerationMode(EFrameGenerationMode::FG_None);
		return false;
	}

	SRDispatch2_Return(Method, SwitchFrameGeneration, WorldContextObject,
	                   FrameGenerationQuality);
	return false;
#else
	return false;
#endif
}

ESuperResolutionQualityMode USuperResolutionHelper::GetSuperResolutionQuality(ESuperResolutionMethod Method)
{
#if PLATFORM_WINDOWS
	SRDispatch0(Method, GetSuperResolutionQuality);
#else
	return ESuperResolutionQualityMode::Off;
#endif
}

EFrameGenerationQualityMode USuperResolutionHelper::GetFrameGenerationQuality(ESuperResolutionMethod Method)
{
#if PLATFORM_WINDOWS
	SRDispatch0(Method, GetFrameGenerationQuality);
#else
	return EFrameGenerationQualityMode::Off;
#endif
}

float USuperResolutionHelper::GetSRModeScreenPercentage(ESuperResolutionMethod Method,
                                                        ESuperResolutionQualityMode Quality)
{
#if PLATFORM_WINDOWS
	SRDispatch2_Return(Method, GetSRModeScreenPercentage, nullptr, Quality);
	return 0;
#else
	return 0;
#endif
}

bool USuperResolutionHelper::SetSuperResolutionAndFrameGeneration(UObject* WorldContextObject,
                                                                  ESuperResolutionMethod Method,
                                                                  ESuperResolutionQualityMode Quality,
                                                                  EFrameGenerationQualityMode FrameGenerationQuality)
{
#if PLATFORM_WINDOWS
	Init();
	if (Method != CurMethod)
	{
		DisableCurSuperResolution(WorldContextObject);
		DisableCurFrameGeneration(WorldContextObject);
	}
	SetSuperResolution(WorldContextObject, Method, Quality, false);
	return SetFrameGeneration(WorldContextObject, Method, FrameGenerationQuality, false);
#else
	return false;
#endif
}

void USuperResolutionHelper::GetCurSuperResolutionCfg(ESuperResolutionMethod& Method,
                                                      ESuperResolutionQualityMode& SRQuality,
                                                      EFrameGenerationQualityMode& FGQuality)
{
#if PLATFORM_WINDOWS
	Method = CurMethod;
	SRQuality = GetSuperResolutionQuality(Method);
	FGQuality = GetFrameGenerationQuality(Method);
#endif
}

float USuperResolutionHelper::GetFPS()
{
#if PLATFORM_WINDOWS
	int32 Val = USuperResolutionBPLibrary::GetFGMode();
	if (CurMethod == ESuperResolutionMethod::None || (Val == 0))
	{
		return SuperResolutionHelperImpl::TSRHelper::GetFPS();
	}
	SRDispatch0(CurMethod, GetFPS);
#else
	return 0;
#endif
}

bool USuperResolutionHelper::DisableCurFrameGeneration(UObject* WorldContextObject)
{
#if PLATFORM_WINDOWS
	int32 Val = USuperResolutionBPLibrary::GetFGMode();

	EFrameGenerationMode Method = static_cast<EFrameGenerationMode>(Val);
	if (Method == EFrameGenerationMode::FG_None)
	{
		return false;
	}
	SRDispatch2_Return(static_cast<ESuperResolutionMethod>(Method), SwitchFrameGeneration, WorldContextObject,
	                   EFrameGenerationQualityMode::Off);
	return false;
#else
	return false;
#endif
}

void USuperResolutionHelper::DisableCurSuperResolution(UObject* WorldContextObject)
{
#if PLATFORM_WINDOWS
	SRDispatch2(CurMethod, SwitchSuperResolution, WorldContextObject, ESuperResolutionQualityMode::Off);
#endif
}

bool USuperResolutionHelper::SetFrameGenerationMode(EFrameGenerationMode Mode)
{
#if PLATFORM_WINDOWS
	int32 Cur = USuperResolutionBPLibrary::GetFGMode();
	bHasXeSS |= (Cur == static_cast<int32>(EFrameGenerationMode::FG_XeSS));
	bool bRestart = false;
	if (Cur != static_cast<int32>(Mode))
	{
		bRestart = USuperResolutionBPLibrary::SetFrameGenerationMode(Mode);
	}

	bRestart = bRestart || ShouldRestart(Mode);
	UE_LOG(LogTemp, Log, TEXT("restart to take effect %d"), bRestart);
	return bRestart;
#else
	return false;
#endif
}

bool USuperResolutionHelper::ShouldRestart(EFrameGenerationMode Mode)
{
	return (Mode == EFrameGenerationMode::FG_DLSS) && bHasXeSS;
}

void USuperResolutionHelper::PushVSync()
{
	static auto CVarVSync = IConsoleManager::Get().FindConsoleVariable(TEXT("r.VSync"));
	if (CVarVSync)
	{
		PreviousVSync = CVarVSync->GetInt();
		CVarVSync->Set(0, ECVF_SetByGameSetting);

		PreviousForceDisableFrameRateSmoothing = GEngine->bForceDisableFrameRateSmoothing;
		GEngine->bForceDisableFrameRateSmoothing = true;

		bInitVSync = true;
	}
}

void USuperResolutionHelper::PopVSync()
{
	static auto CVarVSync = IConsoleManager::Get().FindConsoleVariable(TEXT("r.VSync"));

	if (CVarVSync && bInitVSync)
	{
		GEngine->bForceDisableFrameRateSmoothing = PreviousForceDisableFrameRateSmoothing;

		CVarVSync->Set(PreviousVSync, ECVF_SetByGameSetting);
		bInitVSync = false;
	}
}

#if PLATFORM_WINDOWS

#undef SRDispatch2
#undef SRDispatch0
#undef HelperFunctionDeclare

namespace SuperResolutionHelperImpl
{
	template <typename T>
	FORCEINLINE T MapQualityToDetail(ESuperResolutionQualityMode InQuality,
	                                 T AA, T UltraQuality, T Quality, T Balanced, T Performance, T UltraPerformance,
	                                 T Off)
	{
		switch (InQuality)
		{
		case ESuperResolutionQualityMode::AA:
			return AA;
		case ESuperResolutionQualityMode::UltraQuality:
			return UltraQuality;
		case ESuperResolutionQualityMode::Quality:
			return Quality;
		case ESuperResolutionQualityMode::Balanced:
			return Balanced;
		case ESuperResolutionQualityMode::Performance:
			return Performance;
		case ESuperResolutionQualityMode::UltraPerformance:
			return UltraPerformance;
		default:
			return Off;
		}
	}

	template <typename T, typename TDetailQuality>
	void MapDetailToQualityArray(const TArray<TDetailQuality>& Src, TArray<ESuperResolutionQualityMode>& Dst)
	{
		Dst.Empty(Src.Num());
		for (auto Quality : Src)
		{
			Dst.AddUnique(T::DetailToQuality(Quality));
		}
	}

#define MapDetailToQuality(InQuality, AALabel, UltraQualityLabel, QualityLabel, BalancedLabel, PerformanceLabel, UltraPerformanceLabel) \
	{ \
		switch (InQuality) \
		{ \
		case AALabel: \
			return ESuperResolutionQualityMode::AA; \
		case UltraQualityLabel: \
			return ESuperResolutionQualityMode::UltraQuality; \
		case QualityLabel: \
			return ESuperResolutionQualityMode::Quality; \
		case BalancedLabel: \
			return ESuperResolutionQualityMode::Balanced; \
		case PerformanceLabel: \
			return ESuperResolutionQualityMode::Performance; \
		case UltraPerformanceLabel: \
			return ESuperResolutionQualityMode::UltraPerformance; \
		default: \
			return ESuperResolutionQualityMode::Off; \
		} \
	}

#pragma region DLSS
	UDLSSMode FDLSSHelper::QualityToDetail(ESuperResolutionQualityMode Quality)
	{
		return MapQualityToDetail(Quality,
		                          UDLSSMode::DLAA,
		                          UDLSSMode::UltraQuality, UDLSSMode::Quality,
		                          UDLSSMode::Balanced,
		                          UDLSSMode::Performance, UDLSSMode::UltraPerformance,
		                          UDLSSMode::Off);
	}

	ESuperResolutionQualityMode FDLSSHelper::DetailToQuality(UDLSSMode Quality)
	{
		MapDetailToQuality(Quality,
		                   UDLSSMode::DLAA,
		                   UDLSSMode::UltraQuality, UDLSSMode::Quality,
		                   UDLSSMode::Balanced,
		                   UDLSSMode::Performance, UDLSSMode::UltraPerformance);
	}

	TArray<ESuperResolutionQualityMode> FDLSSHelper::GetSuperResolutionSupport()
	{
		TArray<ESuperResolutionQualityMode> Support;
		if (!UDLSSLibrary::IsDLSSSupported())
		{
			return Support;
		}
		auto DetailMode = UDLSSLibrary::GetSupportedDLSSModes();
		DetailMode.RemoveSingle(UDLSSMode::Auto);
		MapDetailToQualityArray<FDLSSHelper, UDLSSMode>(DetailMode, Support);
		return Support;
	}

	TArray<EFrameGenerationQualityMode> FDLSSHelper::GetFrameGenerationSupport()
	{
		if (!UStreamlineLibraryDLSSG::IsDLSSGSupported())
		{
			return {};
		}
		auto SupportMode = UStreamlineLibraryDLSSG::GetSupportedDLSSGModes();
		TArray<EFrameGenerationQualityMode> Res;
		Res.Empty(SupportMode.Num());
		for (auto Detail : SupportMode)
		{
			Res.Add(static_cast<EFrameGenerationQualityMode>(Detail));
		}
		return Res;
	}

	void FDLSSHelper::SwitchSuperResolution(UObject* WorldContextObject, ESuperResolutionQualityMode Quality)
	{
		if (!UDLSSLibrary::IsDLSSSupported())
		{
			UE_LOG(LogTemp, Warning, TEXT("DLSS Not Support"));
			return;
		}
		if (Quality == ESuperResolutionQualityMode::Off)
		{
			UDLSSLibrary::EnableDLSS(false);
			return;
		}
		return UDLSSLibrary::SetDLSSMode(WorldContextObject, QualityToDetail(Quality));
	}

	ESuperResolutionQualityMode FDLSSHelper::GetSuperResolutionQuality()
	{
		return DetailToQuality(UDLSSLibrary::GetDLSSMode());
	}

	EFrameGenerationQualityMode FDLSSHelper::GetFrameGenerationQuality()
	{
		return static_cast<EFrameGenerationQualityMode>(UStreamlineLibraryDLSSG::GetDLSSGMode());
	}

	bool FDLSSHelper::SwitchFrameGeneration(UObject* WorldContextObject,
	                                        EFrameGenerationQualityMode FrameGenerationQuality)
	{
		bool bNeedRestart = USuperResolutionHelper::SetFrameGenerationMode(EFrameGenerationMode::FG_DLSS);
		EStreamlineDLSSGMode Detail = static_cast<EStreamlineDLSSGMode>(FrameGenerationQuality);
		if (Detail == EStreamlineDLSSGMode::Off)
		{
			USuperResolutionHelper::PopVSync();
			UStreamlineLibraryDLSSG::SetDLSSGMode(Detail);
			return false;
		}

		if (!bNeedRestart)
		{
			USuperResolutionHelper::PushVSync();
			UStreamlineLibraryDLSSG::SetDLSSGMode(Detail);
		}

		return bNeedRestart;
	}

	float FDLSSHelper::GetFPS()
	{
		float FPS = 0.0f;
		int Unused = 0;
		UStreamlineLibraryDLSSG::GetDLSSGFrameTiming(FPS, Unused);
		return FPS;
	}

	float FDLSSHelper::GetSRModeScreenPercentage(UObject*, ESuperResolutionQualityMode Quality)
	{
		return UDLSSLibrary::GetDLSSModeScreenPercentage(QualityToDetail(Quality));
	}

#pragma endregion


#pragma region FSR
	UFSR3Mode FFSRHelper::QualityToDetail(ESuperResolutionQualityMode Quality)
	{
		return MapQualityToDetail(Quality, UFSR3Mode::NativeAA,
		                          UFSR3Mode::UltraQuality, UFSR3Mode::Quality,
		                          UFSR3Mode::Balanced,
		                          UFSR3Mode::Performance, UFSR3Mode::UltraPerformance,
		                          static_cast<UFSR3Mode>(static_cast<int>(UFSR3Mode::UltraPerformance) + 1));
	}

	ESuperResolutionQualityMode FFSRHelper::DetailToQuality(UFSR3Mode Quality)
	{
		MapDetailToQuality(Quality, UFSR3Mode::NativeAA,
		                   UFSR3Mode::UltraQuality, UFSR3Mode::Quality,
		                   UFSR3Mode::Balanced,
		                   UFSR3Mode::Performance, UFSR3Mode::UltraPerformance);
	}

	TArray<ESuperResolutionQualityMode> FFSRHelper::GetSuperResolutionSupport()
	{
#if WITH_EDITOR
		return {};
#else
		TArray<ESuperResolutionQualityMode> Support;
		auto DetailMode = UFSR3Library::GetSupportedFSR3Modes();

		MapDetailToQualityArray<FFSRHelper, UFSR3Mode>(DetailMode, Support);
		return Support;
#endif
	}

	TArray<EFrameGenerationQualityMode> FFSRHelper::GetFrameGenerationSupport()
	{
#if WITH_EDITOR
		return {};
#else
		TArray<EFrameGenerationQualityMode> Support;
		// UFSR3Library::IsFSR3FGSupported return true if swapchain is ready
		// if (!UFSR3Library::IsFSR3FGSupported())
		// {
		// 	return Support;
		// }
		Support.Add(EFrameGenerationQualityMode::Off);
		Support.Add(EFrameGenerationQualityMode::On2X);
		return Support;
#endif
	}

	void FFSRHelper::SwitchSuperResolution(UObject* WorldContextObject, ESuperResolutionQualityMode Quality)
	{
		if (Quality == ESuperResolutionQualityMode::Off)
		{
			UFSR3Library::EnableFSR3(false);
			return;
		}
		UFSR3Mode Detail = QualityToDetail(Quality);
		if (!UFSR3Library::IsFSR3ModeSupported(Detail))
		{
			UE_LOG(LogTemp, Warning, TEXT("FSR Not %d Support"), Detail);
			return;
		}
		UFSR3Library::EnableFSR3(true);
		UFSR3Library::SetFSR3Mode(WorldContextObject, Detail);
	}

	ESuperResolutionQualityMode FFSRHelper::GetSuperResolutionQuality()
	{
		int32 FSR4Enable = CVarEnableFSR4.GetValueOnAnyThread();
		if (FSR4Enable == 0)
		{
			return ESuperResolutionQualityMode::Off;
		}
		int32 QualityVal = CVarFSR4QualityMode.GetValueOnAnyThread();
		UFSR3Mode DetailMode;
		switch (QualityVal)
		{
		case 0:
			DetailMode = UFSR3Mode::NativeAA;
			break;
		case 1:
			DetailMode = UFSR3Mode::Quality;
			break;
		case 2:
			DetailMode = UFSR3Mode::Balanced;
			break;
		case 3:
			DetailMode = UFSR3Mode::Performance;
			break;
		case 4:
			DetailMode = UFSR3Mode::UltraPerformance;
			break;
		default:
			return ESuperResolutionQualityMode::Off;
		}
		return DetailToQuality(DetailMode);
	}

	EFrameGenerationQualityMode FFSRHelper::GetFrameGenerationQuality()
	{
		return UFSR3Library::IsFSR3FGEnabled() ? EFrameGenerationQualityMode::On2X : EFrameGenerationQualityMode::Off;
	}


	bool FFSRHelper::SwitchFrameGeneration(UObject* WorldContextObject,
	                                       EFrameGenerationQualityMode FrameGenerationQuality)
	{
		bool bNeedRestart = USuperResolutionHelper::SetFrameGenerationMode(EFrameGenerationMode::FG_FSR);
		if (FrameGenerationQuality == EFrameGenerationQualityMode::Off)
		{
			USuperResolutionHelper::PopVSync();
			UFSR3Library::EnableFSR3FG(false);
			return false;
		}
		if (!bNeedRestart)
		{
			USuperResolutionHelper::PushVSync();
			UFSR3Library::EnableFSR3FG(true);
		}
		return false;
	}

	float FFSRHelper::GetFPS()
	{
		extern ENGINE_API float GAverageFPS;

		return GAverageFPS;
	}


	float FFSRHelper::GetSRModeScreenPercentage(UObject*, ESuperResolutionQualityMode Quality)
	{
		return UFSR3Library::GetFSR3ModeScreenPercentage(QualityToDetail(Quality));
	}


#pragma endregion


#pragma region XeSS

	EXeSSQualityMode FXeSSHelper::QualityToDetail(ESuperResolutionQualityMode Quality)
	{
		if (Quality == ESuperResolutionQualityMode::UltraQualityPlus)
		{
			return EXeSSQualityMode::UltraQualityPlus;
		}
		return MapQualityToDetail(Quality,
		                          EXeSSQualityMode::AntiAliasing,
		                          EXeSSQualityMode::UltraQuality, EXeSSQualityMode::Quality,
		                          EXeSSQualityMode::Balanced,
		                          EXeSSQualityMode::Performance, EXeSSQualityMode::UltraPerformance,
		                          EXeSSQualityMode::Off);
	}

	ESuperResolutionQualityMode FXeSSHelper::DetailToQuality(EXeSSQualityMode Quality)
	{
		if (Quality == EXeSSQualityMode::UltraQualityPlus)
		{
			return ESuperResolutionQualityMode::UltraQualityPlus;
		}
		MapDetailToQuality(Quality,
		                   EXeSSQualityMode::AntiAliasing,
		                   EXeSSQualityMode::UltraQuality, EXeSSQualityMode::Quality,
		                   EXeSSQualityMode::Balanced,
		                   EXeSSQualityMode::Performance, EXeSSQualityMode::UltraPerformance);
	}

	TArray<ESuperResolutionQualityMode> FXeSSHelper::GetSuperResolutionSupport()
	{
#if WITH_EDITOR
		return {};
#else
		TArray<ESuperResolutionQualityMode> Support;
		if (!UXeSSBlueprintLibrary::IsXeSSSupported())
		{
			return {};
		}
		auto QualityMode = UXeSSBlueprintLibrary::GetSupportedXeSSQualityModes();

		MapDetailToQualityArray<FXeSSHelper, EXeSSQualityMode>(QualityMode, Support);
		return Support;
#endif
	}

	TArray<EFrameGenerationQualityMode> FXeSSHelper::GetFrameGenerationSupport()
	{
#if WITH_EDITOR
		return {};
#else
		TArray<EFrameGenerationQualityMode> Support;
		if (!UXeFGBlueprintLibrary::IsXeFGSupported())
		{
			return Support;
		}
		Support.Add(EFrameGenerationQualityMode::Off);
		Support.Add(EFrameGenerationQualityMode::On2X);
		return Support;
#endif
	}

	void FXeSSHelper::SwitchSuperResolution(UObject* WorldContextObject, ESuperResolutionQualityMode Quality)
	{
		if (!UXeSSBlueprintLibrary::IsXeSSSupported())
		{
			UE_LOG(LogTemp, Warning, TEXT("XeSS Not Support"));
			return;
		}
		auto Detail = QualityToDetail(Quality);
		UXeSSBlueprintLibrary::SetXeSSQualityMode(Detail);
	}

	ESuperResolutionQualityMode FXeSSHelper::GetSuperResolutionQuality()
	{
		return DetailToQuality(UXeSSBlueprintLibrary::GetXeSSQualityMode());
	}

	bool FXeSSHelper::SwitchFrameGeneration(UObject* WorldContextObject,
	                                        EFrameGenerationQualityMode FrameGenerationQuality)
	{
		bool bNeedRestart = USuperResolutionHelper::SetFrameGenerationMode(EFrameGenerationMode::FG_XeSS);
		if (FrameGenerationQuality == EFrameGenerationQualityMode::Off)
		{
			USuperResolutionHelper::PopVSync();
			UXeFGBlueprintLibrary::SetXeFGMode(EXeFGMode::Off);
			return false;
		}
		if (!bNeedRestart)
		{
			USuperResolutionHelper::PushVSync();
			UXeFGBlueprintLibrary::SetXeFGMode(EXeFGMode::On);
		}
		return bNeedRestart;
	}

	EFrameGenerationQualityMode FXeSSHelper::GetFrameGenerationQuality()
	{
		auto Mode = UXeFGBlueprintLibrary::GetXeFGMode();
		EFrameGenerationQualityMode Res = Mode == EXeFGMode::Off
			                                  ? EFrameGenerationQualityMode::Off
			                                  : EFrameGenerationQualityMode::On2X;
		return Res;
	}

	float FXeSSHelper::GetFPS()
	{
		extern XEFGRHI_API float GXeFGAverageFPS;
		return GXeFGAverageFPS;
	}

	float FXeSSHelper::GetSRModeScreenPercentage(UObject*, ESuperResolutionQualityMode Quality)
	{
		float Percentage = 0;
		if (UXeSSBlueprintLibrary::GetXeSSQualityModeInformation(QualityToDetail(Quality), Percentage))
		{
			Percentage = Percentage / 100;
		}
		else
		{
			Percentage = -1;
		}
		return Percentage;
	}


#pragma endregion


#pragma region TSR
	UTSRMode TSRHelper::QualityToDetail(ESuperResolutionQualityMode Quality)
	{
		return MapQualityToDetail(Quality,
		                          UTSRMode::NativeAA,
		                          UTSRMode::UltraQuality, UTSRMode::Quality,
		                          UTSRMode::Balanced,
		                          UTSRMode::Performance, UTSRMode::UltraPerformance,
		                          static_cast<UTSRMode>(static_cast<int>(UTSRMode::UltraPerformance) + 1));
	}

	ESuperResolutionQualityMode TSRHelper::DetailToQuality(UTSRMode Quality)
	{
		MapDetailToQuality(Quality,
		                   UTSRMode::NativeAA,
		                   UTSRMode::UltraQuality, UTSRMode::Quality,
		                   UTSRMode::Balanced,
		                   UTSRMode::Performance, UTSRMode::UltraPerformance);
	}

	TArray<ESuperResolutionQualityMode> TSRHelper::GetSuperResolutionSupport()
	{
		TArray<ESuperResolutionQualityMode> Support;
		auto QualityMode = UKGEngineCoreBPLibrary::GetSupportedTSRModes();

		MapDetailToQualityArray<TSRHelper, UTSRMode>(QualityMode, Support);
		return Support;
	}

	TArray<EFrameGenerationQualityMode> TSRHelper::GetFrameGenerationSupport()
	{
		return {};
	}

	void TSRHelper::SwitchSuperResolution(UObject* WorldContextObject, ESuperResolutionQualityMode Quality)
	{
		UKGEngineCoreBPLibrary::SetTSRMode(WorldContextObject, QualityToDetail(Quality));
	}

	ESuperResolutionQualityMode TSRHelper::GetSuperResolutionQuality()
	{
		static IConsoleVariable* CVarScreenPercentage = IConsoleManager::Get().FindConsoleVariable(
			TEXT("r.ScreenPercentage"));

		int ScreenPercentage = CVarScreenPercentage->GetInt();
		TArray<UTSRMode> ModeList = {
			UTSRMode::NativeAA,
			UTSRMode::UltraQuality, UTSRMode::Quality,
			UTSRMode::Balanced,
			UTSRMode::Performance, UTSRMode::UltraPerformance
		};

		ESuperResolutionQualityMode Res = ESuperResolutionQualityMode::Off;
		for (auto Mode : ModeList)
		{
			int Target = static_cast<int>(UKGEngineCoreBPLibrary::GetTSRModeScreenPercentage(Mode) * 100);
			if (Target == ScreenPercentage)
			{
				Res = DetailToQuality(Mode);
				break;
			}
		}
		return Res;
	}

	bool TSRHelper::SwitchFrameGeneration(UObject* WorldContextObject,
	                                      EFrameGenerationQualityMode FrameGenerationQuality)
	{
		USuperResolutionHelper::SetFrameGenerationMode(EFrameGenerationMode::FG_None);
		return false;
	}

	EFrameGenerationQualityMode TSRHelper::GetFrameGenerationQuality()
	{
		return EFrameGenerationQualityMode::Off;
	}

	float TSRHelper::GetFPS()
	{
		extern ENGINE_API float GAverageFPS;
		return GAverageFPS;
	}


	float TSRHelper::GetSRModeScreenPercentage(UObject*, ESuperResolutionQualityMode Quality)
	{
		return UKGEngineCoreBPLibrary::GetTSRModeScreenPercentage(QualityToDetail(Quality));
	}


#pragma endregion
}

#endif
