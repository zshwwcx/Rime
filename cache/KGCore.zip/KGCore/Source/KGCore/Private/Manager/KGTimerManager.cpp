#include "Manager/KGTimerManager.h"

DECLARE_CYCLE_STAT(TEXT("TimerManager Tick"), STAT_TimerManagerTick, STATGROUP_Game);

void UKGTimerManager::NativeInit()
{
	Super::NativeInit();
}

void UKGTimerManager::NativeUninit()
{
	Super::NativeUninit();
}

void UKGTimerManager::OnPostLoadMapWithWorld(UWorld* World)
{
#if UE_EDITOR
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_PrePhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);
	TickFunction.SetPriorityIncludingPrerequisites(true);
#endif
}

void UKGTimerManager::Tick(float DeltaTime)
{
#if UE_EDITOR
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGTimerManager_Tick");
	SCOPE_CYCLE_COUNTER(STAT_TimerManagerTick);
	
	if (UWorld* World = GetWorld())
	{
		timeSeconds = World->GetTimeSeconds();
		realTimeSeconds = World->GetRealTimeSeconds();
	}
	
	CallLuaFunction(TEXT("UpdateTick"), DeltaTime, timeSeconds, realTimeSeconds);
#endif
}