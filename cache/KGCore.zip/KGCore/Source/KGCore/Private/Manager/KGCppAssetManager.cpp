/**
 * 类功能概述: @hujianglong
 * ============================================================================
 * UKGCppAssetManager主要负责以下核心功能:
 *
 * 1. **异步资源加载**:
 *    - 提供单资源(AsyncLoadAsset)和批量资源(AsyncLoadAsset)的异步加载接口
 *    - 支持优先级设置(InPriority)控制加载队列顺序
 *    - 内部使用FStreamableManager进行底层资源加载管理
 *
 * 2. **资源加载生命周期管理**:
 *    - 通过LoadTaskID唯一标识每个加载任务
 *    - 使用LoadingTasks映射表跟踪所有进行中的加载任务
 *    - 自动处理世界清理时的资源释放(HandleWorldCleanup)
 *
 * 3. **回调机制**:
 *    - 支持单资源回调(FAsyncLoadCompleteDelegate)和列表回调(FAsyncLoadListCompleteDelegate)
 *    - 自动处理引擎资源去重后的结果对齐
 */


#include "Manager/KGCppAssetManager.h"
#include "GameMapsSettings.h"
#include "Engine/StreamableManager.h"
#include "Internationalization/Regex.h"
#include "Engine/Level.h"
#include "UnrealEngine.h"
#include "Misc/KGDeprecatedAssetRegistry.h"

#if !UE_BUILD_SHIPPING
// 由于编辑器模式下资源默认不卸载, 为了方便编辑下面测试, 这里新增一个full gc的GM指令，执行该指令standalone的资产也会GC
static void ForceFullGC(const TArray<FString>& Strings)
{
	TryCollectGarbage(RF_NoFlags);
}

static FAutoConsoleCommand CmdForceFullGC(
	TEXT("ForceFullGC"),
	TEXT("ForceFullGC"),
	FConsoleCommandWithArgsDelegate::CreateStatic(&ForceFullGC)
);
#endif

//PRAGMA_DISABLE_OPTIMIZATION

const int DEFAULT_ANIMID_LRU_CACHE_SIZE = 30;
const int DEFAULT_PRELOAD_LRU_CACHE_SIZE = 200;
const int PRELOAD_LRU_REFRESH_COUNT = 10;

void FAnimSequenceCache::Reset()
{
	PreLoadAnimsForLookUp.Reset();
	PreLoadAnims.Reset();
	PreloadAnimLruCapacity = DEFAULT_PRELOAD_LRU_CACHE_SIZE;
	PreloadAnimLruCache.Empty(PreloadAnimLruCapacity);
	PreloadAnimLruCacheAddCount = 0;
	AnimLibAssetRefMap.Reset();
	AnimLibAssetRefMapForABP.Reset();
	AnimIDForLock.Reset();
	Capacity = 0;
	AnimIDToPreLoadAnimsLruCache.Empty(Capacity);
	EnableLru = false;
}

void FAnimSequenceCache::Reset(int InCapacity, int PreloadAnimLRUCapacity)
{
	PreLoadAnimsForLookUp.Reset();
	PreLoadAnims.Reset();
	PreloadAnimLruCapacity = PreloadAnimLRUCapacity;
	PreloadAnimLruCache.Empty(PreloadAnimLruCapacity);
	PreloadAnimLruCacheAddCount = 0;
	AnimLibAssetRefMap.Reset();
	AnimLibAssetRefMapForABP.Reset();
	AnimIDForLock.Reset();
	Capacity = InCapacity;
	AnimIDToPreLoadAnimsLruCache.Empty(InCapacity);
}

void FAnimSequenceCache::Add(const FName& AnimID, const TArray<FName>& AnimPaths,
                                   const TArray<UAnimSequenceBase*>& PreLoadAnimAssets,
                                   const TArray<FName>& AnimFeatureNames,
                                   const TArray<FName>& FilterLocoNames)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FAnimSequenceCache_Add");
	if(AnimPaths.Num() != PreLoadAnimAssets.Num() || AnimPaths.Num() != AnimFeatureNames.Num())
	{
		UE_LOG(KGCppAssetManager, Warning, TEXT("FAnimSequenceCache Add Failed! AnimPaths:%d  PreLoadAnimAssets:%d  AnimFeatureNames:%d FilterLocoNames:%d" ), AnimPaths.Num(), PreLoadAnimAssets.Num(), AnimFeatureNames.Num(), FilterLocoNames.Num());
		return;
	}

	if(EnableLru && !AnimIDToPreLoadAnimsLruCache.Contains(AnimID))
	{
		AnimIDToPreLoadAnimsLruCache.Add(AnimID, true);
	}

	AnimLibAssetRefMap.FindOrAdd(AnimID).AnimSequenceAssetMap.Reset();
	AnimLibAssetRefMapForABP.FindOrAdd(AnimID).AnimSequenceAssetMap.Reset();

	auto& AnimIDPreLoadAnims = AnimLibAssetRefMap[AnimID].AnimSequenceAssetMap;
	for(int Index = AnimPaths.Num() - 1; Index > -1; --Index)
	{
		AnimIDPreLoadAnims.Add(FName(AnimFeatureNames[Index]), PreLoadAnimAssets[Index]);
		PreLoadAnimsForLookUp.Add(FName(AnimPaths[Index]), PreLoadAnimAssets[Index]);
	}
	auto& AnimIDPreLoadAnimsForABP = AnimLibAssetRefMapForABP[AnimID].AnimSequenceAssetMap;
	for(auto& FilterLocoName : FilterLocoNames)
	{
		FName LocoName= FName(FilterLocoName);
		if(AnimIDPreLoadAnims.Contains(LocoName))
		{
			AnimIDPreLoadAnimsForABP.Add(LocoName, AnimIDPreLoadAnims[LocoName]);
		}
	}

	if(EnableLru)
	{
		for (auto It = AnimLibAssetRefMap.CreateIterator(); It; ++It)
		{
			auto& Key = It.Key();
			const int* count = AnimIDForLock.Find(Key);
			if(count && *count>0)
			{
				continue;
			}
			if (!AnimIDToPreLoadAnimsLruCache.Contains(Key))
			{
				AnimLibAssetRefMapForABP.FindAndRemoveChecked(Key);
				It.RemoveCurrent();
			}
		}
	}
}

void FAnimSequenceCache::Add(const FName& AnimPath, UAnimSequenceBase* AnimAsset)
{
	PreLoadAnims.Add(AnimPath, AnimAsset);
	if(EnableLru)
	{
		PreloadAnimLruCache.Add(AnimPath, true);
		PreloadAnimLruCacheAddCount += 1;
		if(PreloadAnimLruCacheAddCount >= PRELOAD_LRU_REFRESH_COUNT)
		{
			PreloadAnimLruCacheAddCount = 0;
			if(PreLoadAnims.Num() > PreloadAnimLruCapacity)
			{
				for (auto It = PreLoadAnims.CreateIterator(); It; ++It)
				{
					auto& Key = It.Key();	
					if(PreloadAnimLruCache.Contains(Key))
					{
						continue;
					}

					It.RemoveCurrent();
				}
			}
		}
	}
	PreLoadAnimsForLookUp.Add(AnimPath, AnimAsset);
}

void FAnimSequenceCache::Add(const TArray<FName>& AnimPath, const TArray<UAnimSequenceBase*>& AnimAsset)
{
	if (AnimPath.Num() == AnimAsset.Num())
	{
		for (int Index = 0; Index > AnimPath.Num(); ++Index)
		{
			PreLoadAnims.Add(AnimPath[Index], AnimAsset[Index]);
			if(EnableLru)
			{
				PreloadAnimLruCache.Add(AnimPath[Index], true);
				PreloadAnimLruCacheAddCount += 1;
			}
			PreLoadAnimsForLookUp.Add(AnimPath[Index], AnimAsset[Index]);
		}

		if(EnableLru && PreloadAnimLruCacheAddCount >= PRELOAD_LRU_REFRESH_COUNT)
		{
			PreloadAnimLruCacheAddCount = 0;
			if(PreLoadAnims.Num() > PreloadAnimLruCapacity)
			{
				for (auto It = PreLoadAnims.CreateIterator(); It; ++It)
				{
					auto& Key = It.Key();	
					if(PreloadAnimLruCache.Contains(Key))
					{
						continue;
					}

					It.RemoveCurrent();
				}
			}
		}
	}
}

bool FAnimSequenceCache::ContainsID(const FName& AnimID) const
{
	return AnimLibAssetRefMap.Contains(AnimID);
}

int FAnimSequenceCache::LockID(const FName& AnimID)
{
	int& count = AnimIDForLock.FindOrAdd(AnimID, 0);
	count++;
	return count;
}

void FAnimSequenceCache::UnLockID(const FName& AnimID)
{
	int* count = AnimIDForLock.Find(AnimID);
	if(count && *count>0)
	{
		(*count)--;
	}
}

bool FAnimSequenceCache::Contains(const FName& AnimPath) const
{
	return PreLoadAnimsForLookUp.Contains(AnimPath) && PreLoadAnimsForLookUp[AnimPath].IsValid();
}

UAnimSequenceBase* FAnimSequenceCache::GetFromPath(const FName& AnimPath)
{
	if(!PreLoadAnimsForLookUp.Contains(AnimPath))
	{
		return nullptr;
	}
	
	if(!PreLoadAnimsForLookUp[AnimPath].IsValid())
	{
		PreLoadAnimsForLookUp.Remove(AnimPath);
		return nullptr;
	}
	
	if(EnableLru)
	{
		PreloadAnimLruCache.FindAndTouchRef(AnimPath);
	}

	return PreLoadAnimsForLookUp[AnimPath].Get();
}

const TMap<FName, UAnimSequenceBase*>* FAnimSequenceCache::GetABPAnimationsFromID(const FName& AnimID)
{
	if(AnimLibAssetRefMapForABP.Contains(AnimID))
	{
		if(EnableLru)
		{
			AnimIDToPreLoadAnimsLruCache.FindAndTouch(AnimID);
		}
		return &AnimLibAssetRefMapForABP[AnimID].AnimSequenceAssetMap;
	}

	return nullptr;
}

void UKGCppAssetManager::NativeInit()
{
	Super::NativeInit();
	
	WorldCleanupHandle = FWorldDelegates::OnPostWorldCleanup.AddUObject(
		this,
		&UKGCppAssetManager::HandleWorldCleanup
	);
	
	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGCppAssetManager, "EnableLog", &UKGCppAssetManager::EnableLog);
	REG_MANAGER_FUNC(UKGCppAssetManager, "EnableLoadSync", &UKGCppAssetManager::EnableLoadSync);
	REG_MANAGER_FUNC(UKGCppAssetManager, "EnableLoadCancel", &UKGCppAssetManager::EnableLoadCancel);
	REG_MANAGER_FUNC(UKGCppAssetManager, "DoFlushAsyncLoading", &UKGCppAssetManager::DoFlushAsyncLoading);
	
	REG_MANAGER_FUNC(UKGCppAssetManager, "AsyncLoadAssetID", &UKGCppAssetManager::AsyncLoadAssetID);
	REG_MANAGER_FUNC(UKGCppAssetManager, "AsyncLoadAssetKeepReference", &UKGCppAssetManager::AsyncLoadAssetKeepReference);
	REG_MANAGER_FUNC(UKGCppAssetManager, "AsyncLoadAssetKeepReferenceID", &UKGCppAssetManager::AsyncLoadAssetKeepReferenceID);

	REG_MANAGER_FUNC(UKGCppAssetManager, "AsyncLoadAssetListID", &UKGCppAssetManager::AsyncLoadAssetListID);
    REG_MANAGER_FUNC(UKGCppAssetManager, "AsyncLoadAssetListKeepReference", &UKGCppAssetManager::AsyncLoadAssetListKeepReference);
    REG_MANAGER_FUNC(UKGCppAssetManager, "AsyncLoadAssetListKeepReferenceID", &UKGCppAssetManager::AsyncLoadAssetListKeepReferenceID);
	
	REG_MANAGER_FUNC(UKGCppAssetManager, "CancelAsyncLoadByLoadID", &UKGCppAssetManager::CancelAsyncLoadByLoadID);
	REG_MANAGER_FUNC(UKGCppAssetManager, "RemoveAssetReferenceByLoadID", &UKGCppAssetManager::RemoveAssetReferenceByLoadID);
	
	REG_MANAGER_FUNC(UKGCppAssetManager, "GetAssetCacheDebugInfo", &UKGCppAssetManager::GetAssetCacheDebugInfo);

	REG_MANAGER_FUNC(UKGCppAssetManager, "EnableAnimCache", &UKGCppAssetManager::EnableAnimCache);
	REG_MANAGER_FUNC(UKGCppAssetManager, "ResetAnimCache", &UKGCppAssetManager::ResetAnimCache);
	REG_MANAGER_FUNC(UKGCppAssetManager, "ResetLevelAnimCache", &UKGCppAssetManager::ResetLevelAnimCache);
	REG_MANAGER_FUNC(UKGCppAssetManager, "HasAnimCacheForLocomotionABP", &UKGCppAssetManager::HasAnimCacheForLocomotionABP);
	REG_MANAGER_FUNC(UKGCppAssetManager, "LockLocomotionABPCache", &UKGCppAssetManager::LockLocomotionABPCache);
	REG_MANAGER_FUNC(UKGCppAssetManager, "UnLockLocomotionABPCache", &UKGCppAssetManager::UnLockLocomotionABPCache);
	REG_MANAGER_FUNC(UKGCppAssetManager, "CleanUpABPClassCache", &UKGCppAssetManager::CleanUpABPClassCache);
	
#if WITH_EDITOR
	REG_MANAGER_FUNC(UKGCppAssetManager, "EditorTick", &UKGCppAssetManager::EditorTick);
#endif
}

void UKGCppAssetManager::NativeUninit()
{
	CleanUpABPClassCache();
	ResetAnimCache();
	Super::NativeUninit();
	FWorldDelegates::OnPostWorldCleanup.Remove(WorldCleanupHandle);

	if(RefObjectMapForKeep.Num()>0)
	{
		FString CombinedString;
		for (TMap<int, FKGCppObjectArray>::TIterator It(RefObjectMapForKeep); It; ++It)
		{
			const FKGCppObjectArray& OA = It.Value();
			for (size_t i = 0; i < OA.ObjList.Num(); i++)
			{
				UObject* obj = OA.ObjList[i];
				if (obj)
				{
					UE_LOG(KGCppAssetManager, Warning, TEXT("[UKGCppAssetManager 2025-07-30] object reference is not removed ID[%d] Asset[%s]"), It.Key(), *(obj->GetPathName()));
					CombinedString += FString::Printf(TEXT("\t\t : %s\n"), *(obj->GetName()));
				}
			}
		}
		UE_LOG(KGCppAssetManager, Error, TEXT("[UKGCppAssetManager 2025-07-30] object reference is not removed! Num: [%d] Name[%s]"), RefObjectMapForKeep.Num(), *CombinedString);
	}
}

void UKGCppAssetManager::HandleWorldCleanup(UWorld* World, bool bSessionEnded, bool bCleanupResources)
{
	ULevel* CurrentLevel = World->GetCurrentLevel();
	if (!CurrentLevel || !CurrentLevel->IsPersistentLevel())
	{
		return;
	}
	
	if (GIsEditor && !GIsPlayInEditorWorld)
	{
		return;
	}

	//只在TransitionMap的时候去检查,一些UI系统的异步性会导致加载是在过图的时候执行的
	FString TransitionMapName = GetDefault<UGameMapsSettings>()->TransitionMap.GetAssetName();
	if (World->GetName() != TransitionMapName)
	{
		return;
	}

	UE_LOG(KGCppAssetManager, Log, TEXT("HandleWorldCleanup %s"), *World->GetName());
	
	if (World && World->IsGameWorld())
	{
		if(LoadingTasks.Num()>0)
		{
			for (auto It = LoadingTasks.CreateIterator(); It; ++It)
			{
				const KGCppAsyncLoadTask& Task = It.Value();
				UE_LOG(KGCppAssetManager, Error, TEXT("[2025-08-23] LoadID:%d loaded Object by path not clean by user : "), It.Key());
				PrintStringList(Task.AssetPathList, 1);
			}
			UE_LOG(KGCppAssetManager, Error, TEXT("[UKGCppAssetManager 2025-07-30] loaded Object by path not clean by user!  Num: [%d]"), LoadingTasks.Num());
		}
		
		if(RefObjectMapForCallback.Num()>0)
		{
			UE_LOG(KGCppAssetManager, Error, TEXT("[2025-06-03] RefObjectMapForCallback reference is not removed!"));
			for (TMap<int, FKGCppObjectArray>::TIterator It(RefObjectMapForCallback); It; ++It)
			{
				const FKGCppObjectArray& ObjectArray = It.Value();
				for (size_t i = 0; i < ObjectArray.ObjList.Num(); i++)
				{
					UObject* obj = ObjectArray.ObjList[i];
					if (obj)
					{
						UE_LOG(KGCppAssetManager, Warning, TEXT("RefObjectMapForCallback reference is not removed ID[%d] Asset[%s]"), It.Key(), *(obj->GetPathName()));
					}
				}
			}
		}

		bool hasAssetLeak = false;
		int LeakCount = 0;
		for (TMap<FString, TWeakObjectPtr<UObject>>::TIterator MapIt(WeakRefObjectMap); MapIt; ++MapIt)
		{
			TWeakObjectPtr<UObject> obj = MapIt.Value();
			if (obj.IsValid() && obj.Get()->IsValidLowLevel() && !obj.Get()->GetMaskedFlags(RF_Standalone))
			{
				hasAssetLeak = true;
				LeakCount++;
				UE_LOG(LogTemp, Warning, TEXT("[UKGCppAssetManager 2025-08-22] Object weak reference [%s] is valid!"), *MapIt.Key());
			}
			else
			{
				MapIt.RemoveCurrent();
			}
		}

		if(hasAssetLeak)
		{
			UE_LOG(LogTemp, Error, TEXT("[UKGCppAssetManager 2025-08-22] Object weak reference has leak: [%s] LeakCount:[%d]"), TEXT("true"), LeakCount);
		}
		else
		{
			UE_LOG(LogTemp, Log, TEXT("[UKGCppAssetManager 2025-08-22] Object weak reference has leak: [%s]"), TEXT("false"));
		}
	}
}

void UKGCppAssetManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_PrePhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);
	TickFunction.SetPriorityIncludingPrerequisites(true);
}

void UKGCppAssetManager::Tick(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGCppAssetManager_Tick");
	QUICK_SCOPE_CYCLE_COUNTER(UKGCppAssetManager_Tick);
	
	if (PendingTaskIDs.Num() > 0)
	{
		TArray<int> TempPendingTaskIDs = PendingTaskIDs;
		PendingTaskIDs.Reset();
		
		for (size_t i = 0; i < TempPendingTaskIDs.Num(); i++)
		{
			KGCppAsyncLoadTask* LoadedTask = LoadingTasks.Find(TempPendingTaskIDs[i]);
			if (LoadedTask == nullptr)
			{
				UE_LOG(KGCppAssetManager, Error, TEXT("UKGCppAssetManager::Tick can not find pending task by id:%d"), TempPendingTaskIDs[i]);
				continue;
			}
			
			NotifyLoadTaskDone(LoadedTask);
		}
	}
}

void UKGCppAssetManager::NotifyLoadTaskDone(KGCppAsyncLoadTask* InLoadedTask)
{
	CPP_ASSET_MANAGER_LOG(TEXT("NotifyLoadTaskDone %d"), InLoadedTask->LoadID);
	check(InLoadedTask);
	int LoadTaskID = InLoadedTask->LoadID;

	const FAsyncLoadCompleteDelegate LocalCallback = InLoadedTask->CallBack;
	const FAsyncLoadListCompleteDelegate LocalListCallback = InLoadedTask->CallBackList;
	if(InLoadedTask->Handle)
	{
		InLoadedTask->Handle.Reset();
	}
	LoadingTasks.Remove(InLoadedTask->LoadID);//这里先释放InLoadedTask，后面就用LoadTask

	if(!RefObjectMapForCallback.Contains(LoadTaskID))
	{
		UE_LOG(KGCppAssetManager, Error, TEXT("UKGCppAssetManager::NotifyLoadTaskDone can not find RefObject task id:%d"), LoadTaskID);
		return;
	}
	check(InLoadedTask->AssetPathList.Num() == RefObjectMapForCallback[LoadTaskID].ObjList.Num());

    auto LoadedAssets = RefObjectMapForCallback[LoadTaskID];
	if(InLoadedTask->CallLua)
	{
		if(!InLoadedTask->IsList)
		{
			UObject* ObjPtr = LoadedAssets.ObjList[0];
			int64 ObjID = KG_INVALID_ID;
			if (ObjPtr)
			{
				TWeakObjectPtr ptr = ObjPtr;
				ObjID = ptr.KGGetObjectID();
			}
			
			CallLuaFunction("OnAsyncLoadAssetIDComplete",InLoadedTask->LoadID, ObjID);
		}
		else
		{
			TArray<int64> LoadedObjIDs;
			for (size_t i = 0; i < LoadedAssets.ObjList.Num(); i++)
			{
				UObject* obj =LoadedAssets.ObjList[i];
				int64 ObjID = KG_INVALID_ID;
				if (obj)
				{
					TWeakObjectPtr ptr = obj;
					ObjID = ptr.KGGetObjectID();
				}

				LoadedObjIDs.Add(ObjID);
			}
			CallLuaFunction("OnAsyncLoadAssetIDListComplete", InLoadedTask->LoadID, LoadedObjIDs);
		}
	}
	else
	{
		if (LocalListCallback.IsBound())
		{
			LocalListCallback.Execute(LoadTaskID, LoadedAssets.ObjList);
		}
		else if (LocalCallback.IsBound())
		{
			UObject* ObjPtr = LoadedAssets.ObjList[0];
			LocalCallback.Execute(LoadTaskID, ObjPtr);
		}
	}
	
	ClearRefObjectForCallback(LoadTaskID);
}

int UKGCppAssetManager::AsyncLoadAsset(const TArray<FString>& InPaths, const FAsyncLoadListCompleteDelegate& CallBack, int32 InPriority)
{
	return InnerAsyncLoadAsset(InPaths,EmptyAsyncLoadCompleteDelegate,CallBack,InPriority);
}

int UKGCppAssetManager::AsyncLoadAsset(const FString& InPath, const FAsyncLoadCompleteDelegate& CallBack, int32 InPriority)
{
	TArray<FString> Paths;
	Paths.Add(InPath);
	return InnerAsyncLoadAsset(Paths,CallBack,EmptyAsyncLoadListCompleteDelegate,InPriority);
}

int UKGCppAssetManager::AsyncLoadAsset(const TArray<FString>& InPaths, TArray<UObject*>& OutAssets, const FAsyncLoadListCompleteDelegate& CallBack, int32 InPriority)
{
	return InnerAsyncLoadAssetWithFindAssetInMemory(InPaths,OutAssets, EmptyAsyncLoadCompleteDelegate,CallBack,InPriority,false,true,false);
}

int UKGCppAssetManager::AsyncLoadAsset(const FString& InPath, UObject*& OutAsset, const FAsyncLoadCompleteDelegate& CallBack, int32 InPriority)
{
	TArray<FString> Paths;
	Paths.Add(InPath);
	TArray<UObject*> LocalOutAssets;
	int LoadID = InnerAsyncLoadAssetWithFindAssetInMemory(Paths,LocalOutAssets,CallBack,EmptyAsyncLoadListCompleteDelegate,InPriority,false,false,false);
	if(LocalOutAssets.Num()==1)
	{
		OutAsset = LocalOutAssets[0];
	}
	return LoadID;
}

int UKGCppAssetManager::AsyncLoadAssetID(const FString& InPath, int InPriority)
{
	TArray<FString> Paths;
	Paths.Add(InPath);
	int ret = InnerAsyncLoadAsset(Paths, nullptr, nullptr, InPriority, true, false);
	return ret;
}

int UKGCppAssetManager::AsyncLoadAssetListID(const TArray<FString>& InPaths, int32 InPriority)
{
	int ret = InnerAsyncLoadAsset(InPaths, nullptr, nullptr, InPriority, true, true);
	return ret;
}

int UKGCppAssetManager::AsyncLoadAssetKeepReferenceID(const FString& InPath, int InPriority)
{
	TArray<FString> Paths;
	Paths.Add(InPath);
	int ret = InnerAsyncLoadAsset(Paths, nullptr, nullptr, InPriority, true, false, true);
	return ret;
}

int UKGCppAssetManager::AsyncLoadAssetListKeepReferenceID(const TArray<FString>& InPaths, int32 InPriority)
{
	int ret = InnerAsyncLoadAsset(InPaths, nullptr, nullptr, InPriority, true, true, true);
	return ret;
}

int UKGCppAssetManager::SyncLoadAssetKeepReferenceID(const FString& InPath, int64& OutLoadedAssetID)
{
	UObject* loadedObject =  FSoftObjectPath(InPath).TryLoad();
	if(loadedObject == nullptr)
	{
		UE_LOG(KGCppAssetManager, Warning, TEXT("SyncLoadAssetKeepReferenceID load asset failed by path:%s"), *InPath);
	}
	TWeakObjectPtr ptr = loadedObject;
	OutLoadedAssetID = ptr.KGGetObjectID();
	int LoadID = GenerateRequestID();
	TArray<UObject*> loadedObjectList;
	loadedObjectList.Add(loadedObject);
	RefObjectForKeep(LoadID,loadedObjectList);
	return LoadID;
}

int UKGCppAssetManager::SyncLoadAssetListKeepReferenceID(const TArray<FString>& InPaths, TArray<int64>& OutLoadedAssets)
{
	TArray<UObject*> loadedObjectList;
	for (auto InPath : InPaths)
	{
		UObject* loadedObject =  FSoftObjectPath(InPath).TryLoad();
		if(loadedObject == nullptr)
		{
			UE_LOG(KGCppAssetManager, Warning, TEXT("SyncLoadAssetListKeepReferenceID load asset failed by path:%s"), *InPath);
		}
		loadedObjectList.Add(loadedObject);
		TWeakObjectPtr ptr = loadedObject;
		OutLoadedAssets.Add(ptr.KGGetObjectID());
	}

	int LoadID = GenerateRequestID();
	RefObjectForKeep(LoadID,loadedObjectList);
	return LoadID;
}

int UKGCppAssetManager::AsyncLoadAssetKeepReference(const FString& InPath, int InPriority)
{
	TArray<FString> Paths;
	Paths.Add(InPath);
	int ret = InnerAsyncLoadAsset(Paths, FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGCppAssetManager::OnAsyncLoadAssetKeepReferenceLoaded), nullptr, InPriority, false, false, true);
	return ret;
}

int UKGCppAssetManager::AsyncLoadAssetListKeepReference(const TArray<FString>& InPaths, int32 InPriority)
{
	int ret = InnerAsyncLoadAsset(InPaths, nullptr, FAsyncLoadListCompleteDelegate::CreateUObject(this, &UKGCppAssetManager::OnAsyncLoadAssetListKeepReferenceLoaded), InPriority, false, true, true);
	return ret;
}

void UKGCppAssetManager::OnAsyncLoadAssetKeepReferenceLoaded(int InLoadID, UObject* Asset)
{
	CPP_ASSET_MANAGER_LOG(TEXT("OnAsyncLoadAssetKeepReferenceLoaded %d"), InLoadID);
	OnAssetLoadedDelegate.Broadcast(InLoadID, Asset);
}

void UKGCppAssetManager::OnAsyncLoadAssetListKeepReferenceLoaded(int InLoadID, const TArray<UObject*>& AssetList)
{
	CPP_ASSET_MANAGER_LOG(TEXT("OnAsyncLoadAssetListKeepReferenceLoaded %d"), InLoadID);
	OnAssetListLoadedDelegate.Broadcast(InLoadID, AssetList);
}

UObject* UKGCppAssetManager::SyncLoadAsset(const FString& InPath)
{
	UObject* Asset =  FSoftObjectPath(InPath).TryLoad();
	if(Asset == nullptr)
	{
		UE_LOG(KGCppAssetManager, Warning, TEXT("SyncLoadAsset load asset failed by path:%s"), *InPath);
	}
	return Asset;
}

TArray<UObject*> UKGCppAssetManager::SyncLoadAssetList(const TArray<FString>& InPaths)
{
	TArray<UObject*> Out;
	Out.AddZeroed(InPaths.Num());
	for (size_t i = 0; i < InPaths.Num(); i++)
	{
		Out[i] = FSoftObjectPath(InPaths[i]).TryLoad();
		if(Out[i] == nullptr)
		{
			UE_LOG(KGCppAssetManager, Warning, TEXT("SyncLoadAssetList load asset failed by path:%s"), *InPaths[i]);
		}
	}
	return Out;
}

void UKGCppAssetManager::RemoveAssetReferenceByLoadID(int InLoadID)
{
	CPP_ASSET_MANAGER_LOG(TEXT("RemoveAssetReferenceByLoadID %d"), InLoadID);
	CancelAsyncLoadByLoadID(InLoadID);
}

void UKGCppAssetManager::CancelAsyncLoadByLoadID(int InLoadID)
{
	CPP_ASSET_MANAGER_LOG(TEXT("CancelAsyncLoadByLoadID %d"), InLoadID);
	KGCppAsyncLoadTask* LoadTask = LoadingTasks.Find(InLoadID);
	if (LoadTask)
	{
		if (LoadTask->Handle && LoadTask->Handle.IsValid() && bEnableLoadCancel)
		{
			LoadTask->Handle->CancelHandle();
		}
		LoadingTasks.Remove(InLoadID);
		PendingTaskIDs.Remove(InLoadID);
		CPP_ASSET_MANAGER_LOG(TEXT("CancelAsyncLoadByLoadID  Succeeded %d"), InLoadID);
	}

	ClearRefObjectForCallback(InLoadID);
	ClearRefObjectForKeep(InLoadID);
}

void UKGCppAssetManager::EnableDeprecatedPath(bool value)
{
	bEnableDeprecatedPath = value;
	DeprecatedPaths.Empty();
	if (value)
	{
		const FString RegistryPath = UKGDeprecatedAssetRegistry::DeprecatedAssetRegistryPath.ToString();
		if (auto Registry = LoadObject<UKGDeprecatedAssetRegistry>(nullptr, *RegistryPath))
		{
			for (auto Path : Registry->DeprecatedPaths)
			{
				DeprecatedPaths.Add(Path);
			}
		}
	}
}

int UKGCppAssetManager::InnerAsyncLoadAsset(const TArray<FString>& InPaths, const FAsyncLoadCompleteDelegate& CallBack, const FAsyncLoadListCompleteDelegate& CallBackList, int32 InPriority, bool CallLua, bool IsList, bool KeepRef)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGCppAssetManager::InnerAsyncLoadAsset");
	
	if(InPaths.Num() <= 0)
	{
		UE_LOG(KGCppAssetManager, Error, TEXT("AsyncLoadAsset InPaths is empty!"));
		return KG_CPP_INVALID_ASSET_LOAD_ID;
	}
	
	TArray<FSoftObjectPath> ToLoadPathList;
	ToLoadPathList.Reserve(InPaths.Num());
	for (size_t i = 0; i < InPaths.Num(); i++)
	{
		auto Path = InPaths[i];
		if (bEnableDeprecatedPath && DeprecatedPaths.Contains(FName(*Path)))
		{
			Path.InsertAt(5, TEXT("/Deprecated"));
		}

		ToLoadPathList.Add(Path);
	}

	int LoadTaskID = GenerateRequestID();
	CPP_ASSET_MANAGER_LOG(TEXT("InnerAsyncLoadAsset LoadID: %d CallLua: %s IsList: %s KeepRef: %s"), LoadTaskID,
		CallLua ? TEXT("True") : TEXT("False"), IsList ? TEXT("True") : TEXT("False"), KeepRef ? TEXT("True") : TEXT("False"));
	
	FStreamableManager& StreamableManager = UAssetManager::GetStreamableManager();
	if(!bEnableLoadSync)
	{
		const TSharedPtr<FStreamableHandle> HandleHolder = StreamableManager.RequestAsyncLoad(
					ToLoadPathList,
					FStreamableDelegate::CreateUObject(this, & UKGCppAssetManager::OnCompleteAsyncLoadAsset, LoadTaskID),
					InPriority
				);

		if(HandleHolder.IsValid())
		{
			KGCppAsyncLoadTask& LoadTask = AddLoadTask(LoadTaskID);
			LoadTask.Init(LoadTaskID,HandleHolder,InPaths,CallBack,CallBackList,CallLua,IsList,KeepRef);
			HandleHolder->BindCancelDelegate(FStreamableDelegate::CreateUObject(this, &UKGCppAssetManager::CancelAsyncLoadByLoadID, LoadTaskID));
		}
		else
		{
			UE_LOG(KGCppAssetManager, Warning, TEXT("AsyncLoadAsset files not find : %s"), InPaths[0].IsEmpty() ? TEXT("Empty Path") : *InPaths[0]);
			PrintStringList(InPaths, 1);
		}
	}
	else
	{
		const TSharedPtr<FStreamableHandle> HandleHolder = StreamableManager.RequestSyncLoad(ToLoadPathList);
		if(HandleHolder.IsValid())
		{
			KGCppAsyncLoadTask& LoadTask = AddLoadTask(LoadTaskID);
			LoadTask.Init(LoadTaskID,HandleHolder,InPaths,CallBack,CallBackList,CallLua,IsList,KeepRef);
			OnCompleteAsyncLoadAsset(LoadTaskID);
		}
		else
		{
			UE_LOG(KGCppAssetManager, Warning, TEXT("AsyncLoadAsset files not find : %s"), InPaths[0].IsEmpty() ? TEXT("Empty Path") : *InPaths[0]);
			PrintStringList(InPaths, 1);
		}
	}
	
	return LoadTaskID;
}

int UKGCppAssetManager::InnerAsyncLoadAssetWithFindAssetInMemory(const TArray<FString>& InPaths, TArray<UObject*>& OutAssets, const FAsyncLoadCompleteDelegate& CallBack, const FAsyncLoadListCompleteDelegate& CallBackList, int32 InPriority, bool CallLua, bool IsList, bool KeepRef)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGCppAssetManager::InnerAsyncLoadAsset");
	
	if(InPaths.Num() <= 0)
	{
		UE_LOG(KGCppAssetManager, Error, TEXT("AsyncLoadAsset InPaths is empty!"));
		return KG_CPP_INVALID_ASSET_LOAD_ID;
	}
	
	TArray<FSoftObjectPath> ToLoadPathList;
	ToLoadPathList.Reserve(InPaths.Num());
	for (size_t i = 0; i < InPaths.Num(); i++)
	{
		auto Path = InPaths[i];
		if (bEnableDeprecatedPath && DeprecatedPaths.Contains(FName(*Path)))
		{
			Path.InsertAt(5, TEXT("/Deprecated"));
		}

		ToLoadPathList.Add(Path);
	}

	int LoadTaskID = GenerateRequestID();
	
	bool bFound = FindAssetInMemory(InPaths, OutAssets);
	if (bFound)
	{
		RefObjectForCallback(LoadTaskID, OutAssets);
		PendingTaskIDs.Add(LoadTaskID);
		KGCppAsyncLoadTask& LoadTask = AddLoadTask(LoadTaskID);
		LoadTask.Init(LoadTaskID,nullptr,InPaths,CallBack,CallBackList,false);
		return LoadTaskID;
	}

	FStreamableManager& StreamableManager = UAssetManager::GetStreamableManager();
	TSharedPtr<FStreamableHandle> HandleHolder = StreamableManager.RequestAsyncLoad(
				ToLoadPathList,
				FStreamableDelegate::CreateUObject(this, & UKGCppAssetManager::OnCompleteAsyncLoadAsset, LoadTaskID),
				InPriority
			);

	if(HandleHolder.IsValid())
	{
		KGCppAsyncLoadTask& LoadTask = AddLoadTask(LoadTaskID);
		LoadTask.Init(LoadTaskID,HandleHolder,InPaths,CallBack,CallBackList,false);
	}
	else
	{
		UE_LOG(KGCppAssetManager, Warning, TEXT("AsyncLoadAsset files not find : %s"), InPaths[0].IsEmpty() ? TEXT("Empty Path") : *InPaths[0]);
		PrintStringList(InPaths, 1);
	}
	
	return LoadTaskID;
}

void UKGCppAssetManager::OnCompleteAsyncLoadAsset(int InLoadTaskID)
{
	CPP_ASSET_MANAGER_LOG(TEXT("OnCompleteAsyncLoadAsset %d"), InLoadTaskID);
	KGCppAsyncLoadTask* LoadedTask = LoadingTasks.Find(InLoadTaskID);
	if(LoadedTask == nullptr)
	{
		UE_LOG(KGCppAssetManager, Error, TEXT("OnCompleteAsyncLoadAsset can not find load key: %d"), InLoadTaskID);
		return;
	}
	
	check(LoadedTask->Handle.IsValid());
	check(LoadedTask->Handle->HasLoadCompleted());

	TArray<UObject*> LoadedAssets;
	LoadedTask->Handle->GetLoadedAssets(LoadedAssets);
	
	if (LoadedAssets.Num() != LoadedTask->AssetPathList.Num())
	{
		// 由于引擎在做异步加载时会对加载资源列表进行去重, 因此返回的加载任务结果可能跟Request中的资源列表数量对不上
		// 为了避免业务处理起来比较繁琐, 在加载资源存在重复的情况下, 这里还是会将资源加载结果的数量补齐到Request的数量,
		// 同时输出Error, 正常来说一个列表中不应该出现重复的资源加载请求
		// 引擎内部是基于Set进行去重的, 一旦发生去重, 可能顺序就无法保证了, 此外一些非法的资源路径也会被剔除
#if !UE_BUILD_SHIPPING
		//UE_LOG(KGCppAssetManager, Warning, TEXT("OnCompleteAsyncLoadAsset, LoadedAssets.Num() != LoadedTask->AssetPathList.Num() %d"), InLoadTaskID);
		//PrintStringList(LoadedTask->AssetPathList, 1);
#endif

		TArray<FSoftObjectPath> RequestedAssets;
		LoadedTask->Handle->GetRequestedAssets(RequestedAssets);

		check(RequestedAssets.Num() == LoadedAssets.Num());
		
		TMap<FString, UObject*> LoadedAssetMap;
		LoadedAssetMap.Reserve(LoadedAssets.Num());
		for (int32 i = 0; i < LoadedAssets.Num(); i++)
		{
			LoadedAssetMap.Add(RequestedAssets[i].ToString(), LoadedAssets[i]);
		}

		LoadedAssets.Empty(LoadedTask->AssetPathList.Num());
		for (int32 i = 0; i < LoadedTask->AssetPathList.Num(); i++)
		{
			UObject* Result = nullptr;
			if (LoadedAssetMap.Contains(LoadedTask->AssetPathList[i]))
			{
				Result = LoadedAssetMap[LoadedTask->AssetPathList[i]];
			}
			LoadedAssets.Add(Result);
		}
	}

	RefObjectForCallback(InLoadTaskID, LoadedAssets);
	if(LoadedTask->KeepRef)
	{
		RefObjectForKeep(InLoadTaskID, LoadedAssets);
	}
	else
	{
		RefObjectForWeak(LoadedAssets);
	}
	
	PendingTaskIDs.Add(InLoadTaskID);

	//不是所有加载失败，引擎都会报错，补充一下加载失败的日志
	for (size_t i = 0; i < LoadedAssets.Num(); i++)
	{
		if (LoadedAssets[i] == nullptr)
		{
			UE_LOG(KGCppAssetManager, Warning, TEXT("OnCompleteAsyncLoadAsset LoadID[%d], load asset failed by path:%s"), InLoadTaskID, *(LoadedTask->AssetPathList[i]));
		}
	}
}

void UKGCppAssetManager::RefObjectForCallback(int InLoadID, TArray<UObject*>& InObjs)
{
	FKGCppObjectArray& StrongObjs = RefObjectMapForCallback.FindOrAdd(InLoadID);
	check(StrongObjs.ObjList.Num() == 0);
	StrongObjs.ObjList = InObjs; 
}

void UKGCppAssetManager::ClearRefObjectForCallback(int InLoadID)
{
	if(RefObjectMapForCallback.Contains(InLoadID))
	{
		RefObjectMapForCallback.Remove(InLoadID);
	}
}

void UKGCppAssetManager::RefObjectForKeep(int InLoadID, TArray<UObject*>& InObjs)
{
	FKGCppObjectArray& StrongObjs = RefObjectMapForKeep.FindOrAdd(InLoadID);
	check(StrongObjs.ObjList.Num() == 0);
	StrongObjs.ObjList = InObjs; 
}

void UKGCppAssetManager::ClearRefObjectForKeep(int InLoadID)
{
	if(RefObjectMapForKeep.Contains(InLoadID))
	{
		RefObjectMapForKeep.Remove(InLoadID);
	}
}

void UKGCppAssetManager::RefObjectForWeak(TArray<UObject*>& InObjs)
{
	if(InObjs.Num()>0)
	{
		for (UObject* Obj : InObjs)
		{
			WeakRefObjectMap.FindOrAdd(Obj->GetPathName(), TWeakObjectPtr<UObject>(Obj));
		}
	}
}

bool UKGCppAssetManager::FindAssetInMemory(const TArray<FString>& InPaths, TArray<UObject*>& OutAssets)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGCppAssetManager_FindAssetInMemory");
	const int num = InPaths.Num();
	if (num == 0)
	{
		OutAssets.Empty();
		return true;
	}

	TArray<UObject*> Out;
	Out.Reserve(num);
	for (size_t i = 0; i < num; i++)
	{
		UObject* at = StaticFindObject(UObject::StaticClass(), nullptr, *InPaths[i]);
		if (at == nullptr)
		{
			return false;
		}
		Out.Add(at);
	}
	OutAssets = Out;
	return true;
}

int UKGCppAssetManager::GenerateRequestID()
{
	static int RequestID = 1;
	RequestID++;
	if (RequestID >= 0x7fffffff)
	{
		RequestID = 1;
	}
	return RequestID;
}

KGCppAsyncLoadTask& UKGCppAssetManager::AddLoadTask(int InID)
{
	KGCppAsyncLoadTask* Task = LoadingTasks.Find(InID);
	if (Task != nullptr)
	{
		UE_LOG(KGCppAssetManager, Error, TEXT("AddLoadTask found dumplicate key : %d"), InID);
		PrintStringList(Task->AssetPathList, 2);
		check(false);
		return *Task;
	}

	KGCppAsyncLoadTask& NewTask = LoadingTasks.Add(InID);
	return NewTask;
}

void UKGCppAssetManager::PrintStringList(const TArray<FString>& StringList, int Type)
{
	if (StringList.Num() == 0)
	{
		return;
	}

	FString CombinedString;
	for (int32 i = 0; i < StringList.Num(); ++i)
	{
		CombinedString += FString::Printf(TEXT("\t\t : %s\n"), *StringList[i]);
	}
	
	if (Type == 1)
	{
		UE_LOG(KGCppAssetManager, Warning, TEXT("%s"), *CombinedString);
	}
	if (Type == 2)
	{
		UE_LOG(KGCppAssetManager, Error, TEXT("%s"), *CombinedString);
	}
	else
	{
		UE_LOG(KGCppAssetManager, Log, TEXT("%s"), *CombinedString);
	}
}

#pragma region AssetCache

void UKGCppAssetManager::ResetAnimCache()
{
	CacheAnimsInGame.Reset();
	ResetLevelAnimCache(DEFAULT_ANIMID_LRU_CACHE_SIZE, DEFAULT_PRELOAD_LRU_CACHE_SIZE);
}

void UKGCppAssetManager::ResetLevelAnimCache(int InCapacity, int PreloadAnimLruCapacity)
{
	CacheAnimsInLevel.EnableLru = true;
	CacheAnimsInLevel.Reset(InCapacity, PreloadAnimLruCapacity);
	AnimLibAssetHitTimes = 0;
	AnimLibAssetMissTimes = 0;
}

bool UKGCppAssetManager::HasAnimCacheForLocomotionABP(const FName& AnimLibName)
{
	if(!bEnableAnimCache)
	{
		return false;
	}

	if(CacheAnimsInGame.ContainsID(AnimLibName))
	{
		return true;
	}
	
	if(CacheAnimsInLevel.ContainsID(AnimLibName))
	{
		return true;
	}

	return false;
}

bool UKGCppAssetManager::LockLocomotionABPCache(const FName& AnimLibName)
{
	if(CacheAnimsInLevel.ContainsID(AnimLibName))
	{
		CacheAnimsInLevel.LockID(AnimLibName);
		return true;
	}
	return false;
}

void UKGCppAssetManager::UnLockLocomotionABPCache(const FName& AnimLibName)
{
	if(CacheAnimsInLevel.ContainsID(AnimLibName))
	{
		CacheAnimsInLevel.UnLockID(AnimLibName);
	}
}

const TMap<FName, UAnimSequenceBase*>* UKGCppAssetManager::GetAnimCacheForLocomotionABP(const FName& AnimLibName)
{
	if(!bEnableAnimCache)
	{
		return nullptr;
	}

	if(CacheAnimsInGame.ContainsID(AnimLibName))
	{
		AnimLibAssetHitTimes += 1;
		return CacheAnimsInGame.GetABPAnimationsFromID(AnimLibName);
	}
	
	if(CacheAnimsInLevel.ContainsID(AnimLibName))
    {
    	AnimLibAssetHitTimes += 1;
    	return CacheAnimsInLevel.GetABPAnimationsFromID(AnimLibName);
    }

	AnimLibAssetMissTimes += 1;
	return nullptr;
}


bool UKGCppAssetManager::AddAnimsToCache(EAnimSequenceCacheType CacheType, const FName& AnimLibName, const TArray<FName>& AnimPaths,
                                                    const TArray<UAnimSequenceBase*>& PreLoadAnimAssets,
                                                    const TArray<FName>& AnimFeatureNames,
                                                    const TArray<FName>& FilterLocoNames)
{
	if(!bEnableAnimCache)
	{
		return false;
	}

	CPP_ASSET_MANAGER_LOG(TEXT("AddAnimsToCache AnimLibName:%s AnimPaths:%d  PreLoadAnimAssets:%d  AnimFeatureNames:%d FilterLocoNames:%d" ), *AnimLibName.ToString(), AnimPaths.Num(), PreLoadAnimAssets.Num(), AnimFeatureNames.Num(), FilterLocoNames.Num());

	if(CacheType == EAnimSequenceCacheType::Game)
	{
		CacheAnimsInGame.Add(AnimLibName, AnimPaths, PreLoadAnimAssets, AnimFeatureNames, FilterLocoNames);
	}
	else if(CacheType == EAnimSequenceCacheType::Level)
	{
		if(!CacheAnimsInGame.Contains(AnimLibName))
		{
			CacheAnimsInLevel.Add(AnimLibName, AnimPaths, PreLoadAnimAssets, AnimFeatureNames, FilterLocoNames);
		}
	}

	return true;
}

bool UKGCppAssetManager::AddAnimsToCache(EAnimSequenceCacheType CacheType,const FName& AnimPath, UAnimSequenceBase* AnimAsset)
{
	if(!bEnableAnimCache)
	{
		return false;
	}

	if(CacheType == EAnimSequenceCacheType::Game)
	{
		CacheAnimsInGame.Add(AnimPath, AnimAsset);
	}
	else if(CacheType == EAnimSequenceCacheType::Level)
	{
		if(!CacheAnimsInGame.Contains(AnimPath))
		{
			CacheAnimsInLevel.Add(AnimPath, AnimAsset);
		}
	}

	return true;
}

bool UKGCppAssetManager::AddAnimsToCache(EAnimSequenceCacheType CacheType, const TArray<FName>& AnimPath,
	const TArray<UAnimSequenceBase*>& AnimAsset)
{
	if(!bEnableAnimCache)
	{
		return false;
	}

	if(CacheType == EAnimSequenceCacheType::Game)
	{
		CacheAnimsInGame.Add(AnimPath, AnimAsset);
	}
	else if(CacheType == EAnimSequenceCacheType::Level)
	{
		CacheAnimsInLevel.Add(AnimPath, AnimAsset);
	}

	return true;
}

bool UKGCppAssetManager::HasAnimCache(EAnimSequenceCacheType CacheType, const FName& AnimPath) const
{
	if(!bEnableAnimCache)
	{
		return false;
	}

	if(CacheType == EAnimSequenceCacheType::Game)
	{
		return CacheAnimsInGame.Contains(AnimPath);
	}

	if(CacheType == EAnimSequenceCacheType::Level)
	{
		return CacheAnimsInLevel.Contains(AnimPath);
	}

	return false;
}

UAnimSequenceBase* UKGCppAssetManager::GetAnimSequenceAssetCache(const FName& AnimPath)
{
	if(!bEnableAnimCache)
	{
		return nullptr;
	}
	UAnimSequenceBase* AnimSequence = CacheAnimsInGame.GetFromPath(AnimPath);
	if(AnimSequence)
	{
		return AnimSequence;
	}

	return CacheAnimsInLevel.GetFromPath(AnimPath);
}

UClass* UKGCppAssetManager::GetAnimABPClassCache(const FName& ABPClassPath) {
	if (!ABPClassCache.Contains(ABPClassPath)) {
		return nullptr;
	}

	return ABPClassCache[ABPClassPath].Get();
}

void UKGCppAssetManager::SetAnimABPClassCache(const FName& ABPClassPath, UClass* ABPClass) {
	CPP_ASSET_MANAGER_LOG(TEXT("[UKGCppAssetManager::SetAnimABPClass]: ABPClassPath:%s  HasAbpClass:%d"), *ABPClassPath.ToString(), ABPClass != nullptr);
	if (ABPClassCache.Contains(ABPClassPath)) {
		if (ABPClass == nullptr) {
			ABPClassCache.Remove(ABPClassPath);
			return;
		}

		if (ABPClassCache[ABPClassPath].Get() != ABPClass) {
			UE_LOG(KGCppAssetManager, Error, TEXT("SetAnimABPClass found dumplicate key : %s"), *ABPClassPath.ToString());
		}
		return;
	}

	ABPClassCache.Add(ABPClassPath, ABPClass);
}

FString UKGCppAssetManager::GetAssetCacheDebugInfo() const
{
	FString CombinedString = "AssetCache hit rate: \n";
	
	if (AnimLibAssetMissTimes > 0 || AnimLibAssetHitTimes > 0)
	{ 
		float HitPercentage = (static_cast<float>(AnimLibAssetHitTimes) / (AnimLibAssetMissTimes + AnimLibAssetHitTimes)) * 100.0f;
		CombinedString += FString::Printf(TEXT("\t\t : AnimLocomotionABPCache %.2f%%\n"), HitPercentage);
	}
	
	return CombinedString;
}

FString UKGCppAssetManager::GetAssetManagerDebugInfo() const
{
	FString Output;
	Output.Append(TEXT("----Asset Load Info-----\n"));
	Output.Appendf(TEXT("LoadingTasks Num:%d\n"), LoadingTasks.Num());
	Output.Appendf(TEXT("PendingTaskIDs Num:%d\n"), PendingTaskIDs.Num());
	Output.Appendf(TEXT("StrongRef Load Num:%d\n"), RefObjectMapForKeep.Num());
	Output.Appendf(TEXT("WeakRef Load Num:%d\n"), WeakRefObjectMap.Num());
	Output.Appendf(TEXT("CallbackRef Load Num:%d\n"), RefObjectMapForCallback.Num());
	
	Output.Append(TEXT("-----Game Anim Cache-----\n"));
	Output.Appendf(TEXT("Cached Anim Num:%d\n"), CacheAnimsInGame.PreLoadAnims.Num());
	Output.Appendf(TEXT("Cached AnimID Num:%d\n"), CacheAnimsInGame.AnimLibAssetRefMap.Num());
	for(auto It = CacheAnimsInGame.AnimLibAssetRefMap.CreateConstIterator(); It; ++It)
	{
		Output.Appendf(TEXT("--AnimID:%s\n"), *It.Key().ToString());
	}

	Output.Append(TEXT("-----Level Anim Cache-----\n"));
	Output.Append(GetAssetCacheDebugInfo());
	int ValidAnimNum = 0;
	for(auto It = CacheAnimsInLevel.PreLoadAnimsForLookUp.CreateConstIterator(); It; ++It)
	{
		if(It.Value().IsValid())
		{
			++ValidAnimNum;
		}
	}
	Output.Appendf(TEXT("Cached Anim Num:%d ValidNum:%d\n"), CacheAnimsInLevel.PreLoadAnimsForLookUp.Num(), ValidAnimNum);
	Output.Appendf(TEXT("Cached Additional Anim Num:%d\n"), CacheAnimsInLevel.PreLoadAnims.Num());
	Output.Appendf(TEXT("Cached AnimID Num:%d\n"), CacheAnimsInLevel.AnimIDToPreLoadAnimsLruCache.Num());
	for(auto It = CacheAnimsInLevel.AnimLibAssetRefMap.CreateConstIterator(); It; ++It)
	{
		Output.Appendf(TEXT("--AnimID:%s\n"), *It.Key().ToString());
	}

	return Output;
}

#pragma endregion AssetCache