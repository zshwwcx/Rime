#include "Manager/KGPlatformScalabilitySettings.h"

// 静态默认值定义
const TArray<bool>& GetDefaultBoolLodArray()
{
	static const TArray<bool> DefaultArray = { false, false, false, false };
	return DefaultArray;
}

const TArray<float>& GetDefaultFloatLodArray()
{
	static const TArray<float> DefaultArray = { 0.0f, 0.0f, 0.0f, 0.0f };
	return DefaultArray;
}

const TArray<FString>& GetDefaultStringLodArray()
{
	static const TArray<FString> DefaultArray =  { TEXT(""), TEXT(""), TEXT(""), TEXT("") };
	return DefaultArray;
}

const FString& GetDefaultEmptyString()
{
	static FString DefaultEmptyString = TEXT("");
	return DefaultEmptyString;
}

void UKGPlatformScalabilitySettings::NativeInit()
{
	Super::NativeInit();
	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGPlatformScalabilitySettings, "EnableLog", &UKGPlatformScalabilitySettings::EnableLog);
	REG_MANAGER_FUNC(UKGPlatformScalabilitySettings, "EnableBudget", &UKGPlatformScalabilitySettings::EnableBudget);
	REG_MANAGER_FUNC(UKGPlatformScalabilitySettings, "SetScalabilityValueBool", &UKGPlatformScalabilitySettings::SetScalabilityValueBool);
	REG_MANAGER_FUNC(UKGPlatformScalabilitySettings, "SetScalabilityValueFloat", &UKGPlatformScalabilitySettings::SetScalabilityValueFloat);
	REG_MANAGER_FUNC(UKGPlatformScalabilitySettings, "SetScalabilityValueString", &UKGPlatformScalabilitySettings::SetScalabilityValueString);
	REG_MANAGER_FUNC(UKGPlatformScalabilitySettings, "DumpDebugInfo", &UKGPlatformScalabilitySettings::DumpDebugInfo);
}

void UKGPlatformScalabilitySettings::NativeUninit()
{
	Super::NativeUninit();
}

void UKGPlatformScalabilitySettings::SetScalabilityLodValueBool(const FString& Category, const FString& Key, const TArray<bool>& LodValues)
{
	check(LodValues.Num() == 4);
	ScalabilityLodValueBoolData.FindOrAdd(Category).Add(Key, LodValues);
}

void UKGPlatformScalabilitySettings::SetScalabilityLodValueFloat(const FString& Category, const FString& Key, const TArray<float>& LodValues)
{
	check(LodValues.Num() == 4);
	ScalabilityLodValueFloatData.FindOrAdd(Category).Add(Key, LodValues);
}

void UKGPlatformScalabilitySettings::SetScalabilityLodValueString(const FString& Category, const FString& Key, const TArray<FString>& LodValues)
{
	check(LodValues.Num() == 4);
	ScalabilityLodValueStringData.FindOrAdd(Category).Add(Key, LodValues);
}

void UKGPlatformScalabilitySettings::SetScalabilityValueBool(const FString& Category, const FString& Key, bool Value)
{
	ScalabilityValueBoolData.FindOrAdd(Category).Add(Key, Value);
}

void UKGPlatformScalabilitySettings::SetScalabilityValueFloat(const FString& Category, const FString& Key, float Value)
{
	ScalabilityValueFloatData.FindOrAdd(Category).Add(Key, Value);
}

void UKGPlatformScalabilitySettings::SetScalabilityValueString(const FString& Category, const FString& Key, const FString& Value)
{
	ScalabilityValueStringData.FindOrAdd(Category).Add(Key, Value);
}

template<>
const TArray<bool>& UKGPlatformScalabilitySettings::GetScalabilityLodValueArray<bool>(const FString& Category, const FString& Key)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGPlatformScalabilitySettings::GetScalabilityLodValueArray");
	if (ScalabilityLodValueBoolData.Contains(Category) && ScalabilityLodValueBoolData[Category].Contains(Key))
	{
		return ScalabilityLodValueBoolData[Category][Key];
	}
	return GetDefaultBoolLodArray();
}

template<>
const TArray<float>& UKGPlatformScalabilitySettings::GetScalabilityLodValueArray<float>(const FString& Category, const FString& Key)
{
	if (ScalabilityLodValueFloatData.Contains(Category) && ScalabilityLodValueFloatData[Category].Contains(Key))
	{
		return ScalabilityLodValueFloatData[Category][Key];
	}
	return GetDefaultFloatLodArray();
}

template<>
const TArray<FString>& UKGPlatformScalabilitySettings::GetScalabilityLodValueArray<FString>(const FString& Category, const FString& Key)
{
	if (ScalabilityLodValueStringData.Contains(Category) && ScalabilityLodValueStringData[Category].Contains(Key))
	{
		return ScalabilityLodValueStringData[Category][Key];
	}
	return GetDefaultStringLodArray();
}

template<>
bool UKGPlatformScalabilitySettings::GetScalabilityLodValue<bool>(int LOD, const FString& Category, const FString& Key)
{
	const TArray<bool>& Values = GetScalabilityLodValueArray<bool>(Category, Key);
	checkf(LOD < Values.Num(), TEXT(" Lod index %d larger ScalabilityLodValue: %s : %s"), LOD, *Category, *Key);
	return Values[LOD];
}

template<>
float UKGPlatformScalabilitySettings::GetScalabilityLodValue<float>(int LOD, const FString& Category, const FString& Key)
{
	const TArray<float>& Values =  GetScalabilityLodValueArray<float>(Category, Key);
	checkf(LOD < Values.Num(), TEXT(" Lod index %d larger ScalabilityLodValue: %s : %s"), LOD, *Category, *Key);
	return Values[LOD];
}

template<>
FString UKGPlatformScalabilitySettings::GetScalabilityLodValue<FString>(int LOD, const FString& Category, const FString& Key)
{
	const TArray<FString>& Values =  GetScalabilityLodValueArray<FString>(Category, Key);
	checkf(LOD < Values.Num(), TEXT(" Lod index %d larger ScalabilityLodValue: %s : %s"), LOD, *Category, *Key);
	return Values[LOD];
}

template<>
bool UKGPlatformScalabilitySettings::GetScalabilityValue<bool>(const FString& Category, const FString& Key)
{
	if (ScalabilityValueBoolData.Contains(Category) && ScalabilityValueBoolData[Category].Contains(Key))
	{
		return ScalabilityValueBoolData[Category][Key];
	}
	return false;
}

template<>
float UKGPlatformScalabilitySettings::GetScalabilityValue<float>(const FString& Category, const FString& Key)
{
	if (ScalabilityValueFloatData.Contains(Category) && ScalabilityValueFloatData[Category].Contains(Key))
	{
		return ScalabilityValueFloatData[Category][Key];
	}
	return 0.0f;
}

template<>
FString UKGPlatformScalabilitySettings::GetScalabilityValue<FString>(const FString& Category, const FString& Key)
{
	if (ScalabilityValueStringData.Contains(Category) && ScalabilityValueStringData[Category].Contains(Key))
	{
		return ScalabilityValueStringData[Category][Key];
	}
	return GetDefaultEmptyString();
}

#pragma region LimitBudget

void UKGPlatformScalabilitySettings::SetActorUsedLimitBudgetValue(const FString& Category, const FString& Key, float Value)
{
	UsedScalabilityBudgetRecord.FindOrAdd(Category).Add(Key, Value);
}

float UKGPlatformScalabilitySettings::GetActorUsedLimitBudgetValue(const FString& Category, const FString& Key)
{
	if (const TMap<FString,float>* CategoryMap = UsedScalabilityBudgetRecord.Find(Category))
	{
		if (const float* FoundValue = CategoryMap->Find(Key))
		{
			return *FoundValue;
		}
	}
	return 0.0f;
}

bool UKGPlatformScalabilitySettings::CheckLodBoolPermit(int Lod, const FString& CategoryLod, const FString& Key)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGPlatformScalabilitySettings::CheckLodPermit");
	if(!bEnableBudget)
	{
		return true;
	}
	const TArray<bool>& ScalabilityLodValue = GetScalabilityLodValueArray<bool>(CategoryLod, Key);
	checkf(Lod < ScalabilityLodValue.Num(), TEXT(" Lod index %d larger ScalabilityLodValue: %s : %s"), Lod, *CategoryLod, *Key);
	const bool BudgetPermit = ScalabilityLodValue[Lod];
	if(!BudgetPermit)
	{
#if !UE_BUILD_SHIPPING
		CPP_MANAGER_LOG(TEXT("[KGPlatformScalabilitySettings] CheckLodPermit Lod Check Failed %s:%s:%d"), *CategoryLod, *Key, Lod);
#endif
	}
	return BudgetPermit;
}

bool UKGPlatformScalabilitySettings::ConsumeActorLimitBudgetWithLod(int64 ActorID, int Lod, const FString& CategoryLimit, const FString& CategoryLod, const FString& Key)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGPlatformScalabilitySettings::ConsumeActorLimitBudgetWithLod");
	if(!bEnableBudget)
	{
		return true;
	}
	const TArray<bool>& ScalabilityLodValue = GetScalabilityLodValueArray<bool>(CategoryLod, Key);
	checkf(Lod < ScalabilityLodValue.Num(), TEXT(" Lod index %d larger ScalabilityLodValue: %s : %s"), Lod, *CategoryLod, *Key);
	bool BudgetPermit = ScalabilityLodValue[Lod];
	if(BudgetPermit)
	{
		TMap<FString,bool>& BudgetRecord = ScalabilityBudgetRecord.FindOrAdd(ActorID).FindOrAdd(CategoryLimit);
		BudgetPermit = BudgetRecord.Contains(Key) or ConsumeBudgetScalabilityLimit(CategoryLimit, Key);
		if(BudgetPermit) BudgetRecord.FindOrAdd(Key,true);
	}
	else
	{
#if !UE_BUILD_SHIPPING
		CPP_MANAGER_LOG(TEXT("[KGPlatformScalabilitySettings] ConsumeActorLimitBudgetWithLod Lod Check Failed %s:%s:%d  ActorID:%lld"), *CategoryLod, *Key, Lod, ActorID);
#endif
	}
	return BudgetPermit;
}

bool UKGPlatformScalabilitySettings::ReleaseActorLimitBudget(int64 ActorID, const FString& CategoryLimit, const FString& Key)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGPlatformScalabilitySettings::ReleaseActorLimitBudget");
	auto BudgetRecord = ScalabilityBudgetRecord.FindOrAdd(ActorID).FindOrAdd(CategoryLimit);
	if(BudgetRecord.Contains(Key))
	{
		ReleaseBudgetScalabilityLimit(CategoryLimit, Key);
		BudgetRecord.Remove(Key);
		return true;
	}
	return false;
}

void UKGPlatformScalabilitySettings::ReleaseActorAllLimitBudget(int64 ActorID)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGPlatformScalabilitySettings::ReleaseActorAllLimitBudget");
	const TMap<FString,TMap<FString,bool>>& BudgetRecord = ScalabilityBudgetRecord.FindOrAdd(ActorID);
	for (const auto& Records : BudgetRecord)
	{
		for(const auto& Record : Records.Value)
		{
			ReleaseBudgetScalabilityLimit(Records.Key, Record.Key);
		}
	}
	ScalabilityBudgetRecord.Remove(ActorID);
}

bool UKGPlatformScalabilitySettings::ConsumeBudgetScalabilityLimit(const FString& Category, const FString& Key)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGPlatformScalabilitySettings::ConsumeBudgetScalabilityLimit");
	auto BudgetValue = GetScalabilityValue<float>(Category,Key);
	auto UsedBudgetValue = GetActorUsedLimitBudgetValue(Category,Key);
	if(BudgetValue-UsedBudgetValue>=1.0F)
	{
		SetActorUsedLimitBudgetValue(Category,Key, UsedBudgetValue+1.0F);
#if !UE_BUILD_SHIPPING
		CPP_MANAGER_LOG(TEXT("[KGPlatformScalabilitySettings] ConsumeBudgetScalabilityLimit Sucessed %s:%s:%f"), *Category, *Key, UsedBudgetValue+1.0F);
#endif
		return true;
	}
#if !UE_BUILD_SHIPPING
	CPP_MANAGER_LOG(TEXT("[KGPlatformScalabilitySettings] ConsumeBudgetScalabilityLimit Failed %s:%s:%f:%f"), *Category, *Key, BudgetValue, UsedBudgetValue);
#endif
	return false;
}

bool UKGPlatformScalabilitySettings::ReleaseBudgetScalabilityLimit(const FString& Category, const FString& Key)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGPlatformScalabilitySettings::ReleaseBudgetScalabilityLimit");
	auto UsedBudgetValue = GetActorUsedLimitBudgetValue(Category,Key);
	if(UsedBudgetValue>=1.0F)
	{
		SetActorUsedLimitBudgetValue(Category,Key, UsedBudgetValue-1.0F);
#if !UE_BUILD_SHIPPING
		CPP_MANAGER_LOG(TEXT("[KGPlatformScalabilitySettings] ReleaseBudgetScalabilityLimit Sucessed %s:%s:%f"), *Category, *Key, UsedBudgetValue-1.0F);
#endif
		return true;
	}
	return false;
}

#pragma endregion LimitBudget

void UKGPlatformScalabilitySettings::DumpDebugInfo()
{
    UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("============ [KGPlatformScalabilitySettings] Scalability Data Dump ============"));

    // 辅助 Lambda：将 bool 数组转为字符串
    auto BoolArrayToString = [](const TArray<bool>& Arr) -> FString {
        FString Result;
        for (bool b : Arr) {
            Result += b ? TEXT("true, ") : TEXT("false, ");
        }
        if (!Result.IsEmpty()) Result.LeftChopInline(2); // 移除末尾逗号
        return FString::Printf(TEXT("[%s]"), *Result);
    };

    // 辅助 Lambda：将 float 数组转为字符串
    auto FloatArrayToString = [](const TArray<float>& Arr) -> FString {
        FString Result;
        for (float f : Arr) {
            Result += FString::Printf(TEXT("%.2f, "), f);
        }
        if (!Result.IsEmpty()) Result.LeftChopInline(2);
        return FString::Printf(TEXT("[%s]"), *Result);
    };

    // 辅助 Lambda：将 string 数组转为字符串
    auto StringArrayToString = [](const TArray<FString>& Arr) -> FString {
        return FString::Printf(TEXT("[%s]"), *FString::Join(Arr, TEXT(", ")));
    };

    // 1. 输出 ScalabilityLodValueBoolData
	if(ScalabilityLodValueBoolData.Num()>0)
	{
		UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("--- ScalabilityLodValueBoolData ---"));
		for (auto& OuterPair : ScalabilityLodValueBoolData) {
			UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("  Category: %s"), *OuterPair.Key);
			for (auto& InnerPair : OuterPair.Value) {
				UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("    Key: %s => %s"), 
					*InnerPair.Key,
					*BoolArrayToString(InnerPair.Value));
			}
		}
	}

    // 2. 输出 ScalabilityLodValueFloatData
	if(ScalabilityLodValueFloatData.Num()>0)
	{
		UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("--- ScalabilityLodValueFloatData ---"));
		for (auto& OuterPair : ScalabilityLodValueFloatData) {
			UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("  Category: %s"), *OuterPair.Key);
			for (auto& InnerPair : OuterPair.Value) {
				UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("    Key: %s => %s"),
					*InnerPair.Key,
					*FloatArrayToString(InnerPair.Value));
			}
		}
	}

    // 3. 输出 ScalabilityLodValueStringData
	if(ScalabilityLodValueStringData.Num()>0)
	{
		UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("--- ScalabilityLodValueStringData ---"));
		for (auto& OuterPair : ScalabilityLodValueStringData) {
			UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("  Category: %s"), *OuterPair.Key);
			for (auto& InnerPair : OuterPair.Value) {
				UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("    Key: %s => %s"),
					*InnerPair.Key,
					*StringArrayToString(InnerPair.Value));
			}
		}
	}

    // 4. 输出 ScalabilityValueBoolData
	if(ScalabilityValueBoolData.Num()>0)
	{
		UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("--- ScalabilityValueBoolData ---"));
		for (auto& OuterPair : ScalabilityValueBoolData) {
			UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("  Category: %s"), *OuterPair.Key);
			for (auto& InnerPair : OuterPair.Value) {
				UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("    Key: %s => %s"),
					*InnerPair.Key,
					InnerPair.Value ? TEXT("true") : TEXT("false"));
			}
		}
	}
	
    // 5. 输出 ScalabilityValueFloatData
	if(ScalabilityValueFloatData.Num()>0)
	{
		UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("--- ScalabilityValueFloatData ---"));
		for (auto& OuterPair : ScalabilityValueFloatData) {
			UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("  Category: %s"), *OuterPair.Key);
			for (auto& InnerPair : OuterPair.Value) {
				UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("    Key: %s => %.4f"),
					*InnerPair.Key,
					InnerPair.Value);
			}
		}
	}

    // 6. 输出 ScalabilityValueStringData
	if(ScalabilityValueStringData.Num()>0)
	{
		UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("--- ScalabilityValueStringData ---"));
		for (auto& OuterPair : ScalabilityValueStringData) {
			UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("  Category: %s"), *OuterPair.Key);
			for (auto& InnerPair : OuterPair.Value) {
				UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("    Key: %s => %s"),
					*InnerPair.Key,
					*InnerPair.Value);
			}
		}
	}

    // 7. 输出 ScalabilityBudgetRecord (三层嵌套)
	if(ScalabilityBudgetRecord.Num()>0)
	{
		UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("--- ScalabilityBudgetRecord ---"));
		for (auto& TimePair : ScalabilityBudgetRecord) {
			UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("  ActorID: %lld"), TimePair.Key);
			for (auto& CategoryPair : TimePair.Value) {
				UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("    Category: %s"), *CategoryPair.Key);
				for (auto& ValuePair : CategoryPair.Value) {
					UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("      Key: %s => %s"),
						*ValuePair.Key,
						ValuePair.Value ? TEXT("true") : TEXT("false"));
				}
			}
		}
	}

    // 8. 输出 UsedScalabilityBudgetRecord
	if(UsedScalabilityBudgetRecord.Num()>0)
	{
		UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("--- UsedScalabilityBudgetRecord ---"));
		for (auto& OuterPair : UsedScalabilityBudgetRecord) {
			UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("  Category: %s"), *OuterPair.Key);
			for (auto& InnerPair : OuterPair.Value) {
				UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("    Key: %s => %.4f"),
					*InnerPair.Key,
					InnerPair.Value);
			}
		}
	}

    UE_LOG(KGPlatformScalabilitySettings, Log, TEXT("============ End Dump ============"));
}