#include "Manager/KGObjectActorManager.h"
#include "UObject/ObjectMacros.h"
#include "Engine/World.h"
#include "LuaCppBinding.h"
#include "Misc/ObjCrashCollector.h"
#include "3C/Util/KGUtils.h"
#define KG_ENGINE_OBJECT_DEBUG_LOG 1

void UKGObjectActorManager::NativeInit()
{
	using namespace NS_SLUA;
	REG_EXTENSION_METHOD(UKGObjectActorManager, "GetIDByObject", &UKGObjectActorManager::GetIDByObejct);
	REG_EXTENSION_METHOD(UKGObjectActorManager, "GetObjectByID", &UKGObjectActorManager::GetObjectByID);
	REG_EXTENSION_METHOD(UKGObjectActorManager, "GetClassByID", &UKGObjectActorManager::GetClassByID);
	REG_EXTENSION_METHOD(UKGObjectActorManager, "GetIDByClass", &UKGObjectActorManager::GetIDByClass);


	FWorldDelegates::OnWorldCleanup.AddUObject(this, &UKGObjectActorManager::OnWorldCleanupEnd);

	SpawnActorParameters.bNoFail = true;
	SpawnActorParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnActorParameters.ObjectFlags |= RF_Transient;
}


void UKGObjectActorManager::NativeUninit()
{
	FWorldDelegates::OnWorldCleanup.RemoveAll(this);

	for (TMap<int64, AActor*>::TIterator It(DynamicActorMap); It; ++It)
	{
		AActor* actor = It.Value();
		if (actor != nullptr)
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGObjectActorManager - AActor reference is not removed path:%s "), *(actor->GetFullName()));
		}
	}

	for (TMap<int64, UObject*>::TIterator It(DynamicObjectMap); It; ++It)
	{
		UObject* obj = It.Value();
		if (obj != nullptr)
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGObjectActorManager - Object reference is not removed path:%s "), *(obj->GetFullName()));
		}
	}

}

void UKGObjectActorManager::NotifyUObjectCreated(const UObjectBase* InObject, int32 Index)
{

}
void UKGObjectActorManager::NotifyUObjectDeleted(const UObjectBase* InObject, int32 Index)
{

}


void UKGObjectActorManager::OnUObjectArrayShutdown()
{
	GUObjectArray.RemoveUObjectCreateListener(this);
	GUObjectArray.RemoveUObjectDeleteListener(this);
}


int64 UKGObjectActorManager::GetIDByObejct(UObject* InObj)
{
	return KGUtils::GetIDByObject(InObj);
}

UObject* UKGObjectActorManager::GetObjectByID(int64 InID)
{
	return KGUtils::GetObjectByID(InID);
}

int64 UKGObjectActorManager::GetIDByClass(UClass* InClass)
{
	return KGUtils::GetIDByClass(InClass);
}

UClass* UKGObjectActorManager::GetClassByID(int64 InID)
{
	return KGUtils::GetClassByID(InID);
}

//void KGEngineObejctManager::PrintStringList(const TArray<FString>& StringList, bool bWarning)
//{
//	for (size_t i = 0; i < StringList.Num(); i++)
//	{
//		if (bWarning)
//		{
//			UE_LOG(LogTemp, Warning, TEXT("\t\t : %s"), *StringList[i]);
//		}
//		else
//		{
//			UE_LOG(LogTemp, Log, TEXT("\t\t : %s"), *StringList[i]);
//		}
//		
//	}
//}

AActor* UKGObjectActorManager::SpawnActor(UClass* InClass, bool bKeepReference, float InLocationX, float InLocationY, float InLocationZ, float InPitch, float InYaw, float InRoll)
{
	UWorld* InWorld = GetSpawnActorWorld();
	if (InWorld == nullptr || IsValid(InWorld) == false)
	{
		UE_LOG(LogTemp, Warning, TEXT("KGSpawnActor InWorld is valid"));
		return nullptr;
	}

	if (InClass == nullptr || IsValid(InClass) == false)
	{
		UE_LOG(LogTemp, Warning, TEXT("KGSpawnActor InClass is valid"));
		return nullptr;
	}

	FRotator Rot(InPitch, InYaw, InRoll);
	FVector Loc(InLocationX, InLocationY, InLocationZ);
	FVector S(1, 1, 1);

	AActor* NewActor = InWorld->SpawnActor(InClass, &Loc, &Rot, SpawnActorParameters);
	if (NewActor == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("KGSpawnActor Spawn Actor Failed InClass[%s], InWorld[%s], XYZ[%f %f %f], PYR[%f %f %f]"),
			*(InClass->GetPathName()), *(InWorld->GetPathName()), 
			InLocationX, InLocationY, InLocationZ, 
			InPitch, InYaw, InRoll);
	}
	else
	{
		if (bKeepReference)
		{
			ReferenceActor(NewActor);
		}

		NewActor->OnDestroyed.AddDynamic(this, &UKGObjectActorManager::OnActorDestroyed);
	}

	return NewActor;
}


void UKGObjectActorManager::DestroyActor(AActor* InActor)
{
	if (IsValid(InActor) == false)
	{
		UE_LOG(LogTemp, Warning, TEXT("KGDestroyActor Destroy a invalid actor:%lld"), (uint64)InActor);
		return;
	}

	//UnRefernceActor(InActor);

	UWorld* CW = InActor->GetWorld();
	if (CW)
	{
		CW->DestroyActor(InActor);
	}
}

void UKGObjectActorManager::DestroyActorByID(int64 InID)
{
	AActor* A = Cast<AActor>(GetObjectByID(InID));
	if (A)
	{
		DestroyActor(A);
	}
}

void UKGObjectActorManager::DestroyActorListByID(const TArray<int64>& InActorIDs)
{

}

void UKGObjectActorManager::DestroyActorList(const TArray<AActor*>& InActors)
{
	for (size_t i = 0; i < InActors.Num(); i++)
	{
		DestroyActor(InActors[i]);
	}
}


UObject* UKGObjectActorManager::KGNewObject(UClass* InClass, UObject* InOuter, bool bKeepReference)
{
	if (IsValid(InClass) == false)
	{
		UE_LOG(LogTemp, Error, TEXT("NewObject failed with invalid InClass"));
		return nullptr;
	}

	UObject* Obj = NewObject<UObject>(InOuter, InClass);
	if (Obj && bKeepReference)
	{
		InnerReferenceObject(Obj);
	}

	return Obj;
}

void UKGObjectActorManager::ReferenceObject(UObject* InObject)
{
	c7_obj_check(InObject);
	InnerReferenceObject(InObject);
}

void UKGObjectActorManager::RemoveObjectReference(const UObject* InObject)
{
	UnreferenceObject(const_cast<UObject*>(InObject));
}

void UKGObjectActorManager::RemoveObjectListReference(const TArray<UObject*>& InObjects)
{
	for (size_t i = 0; i < InObjects.Num(); i++)
	{
		UnreferenceObject(InObjects[i]);
	}
}

void UKGObjectActorManager::RemoveObjectReferenceByID(int64 InID)
{
	UObject* obj = GetObjectByID(InID);
	if (obj)
	{
		UnreferenceObject(obj);
	}

}

void UKGObjectActorManager::RemoveObjectListReferenceByID(const TArray<int64> InIDs)
{
	for (size_t i = 0; i < InIDs.Num(); i++)
	{
		RemoveObjectReferenceByID(InIDs[i]);
	}

}

class UWorld* UKGObjectActorManager::GetSpawnActorWorld()
{
#if WITH_EDITOR
	if (OverrideWorld.IsValid())
		return OverrideWorld.Get();
#endif
	return Super::GetWorld();
}

void UKGObjectActorManager::InnerReferenceObject(UObject* InObject)
{
	if (IsValid(InObject) == false)
	{
		UE_LOG(LogTemp, Error, TEXT("ReferenceObject failed with invalid InObject"));
		return;
	}

	TWeakObjectPtr Ptr = InObject;
	int64 id = Ptr.KGGetObjectID();

	UObject** obj = DynamicObjectMap.Find(id);

	if (obj == nullptr)
	{
		DynamicObjectMap.Add(id, InObject);
	}
	else
	{
		if (*obj)
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGEngineObejctManager::ReferenceObject object[%lld, %s] is referenced again!"), id, *(InObject->GetFullName()));
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGEngineObejctManager::ReferenceObject object[%lld] is referenced again!"), id);
		}

		*obj = InObject;
	}
}

void UKGObjectActorManager::UnreferenceObject(UObject* InObject)
{
	if (IsValid(InObject) == false)
	{
		UE_LOG(LogTemp, Error, TEXT("UnreferenceObject failed with invalid InObject"));
		return;
	}

	TWeakObjectPtr Ptr = InObject;
	int64 id = Ptr.KGGetObjectID();

	UObject** obj = DynamicObjectMap.Find(id);
	if (obj == nullptr)
	{
		//UE_LOG(LogTemp, Warning, TEXT("UKGEngineObejctManager::UnreferenceObject invalid object[%lld %s] to unreference"), id, *(InObject->GetFullName()));
	}
	else
	{
		if (*obj == nullptr)
		{
			UE_LOG(LogTemp, Error, TEXT("UKGEngineObejctManager::UnreferenceObject key[%lld] value is null"), id);
		}

		DynamicObjectMap.Remove(id);
	}
}

void UKGObjectActorManager::ReferenceActor(AActor* InActor)
{
	if (IsValid(InActor) == false)
	{
		UE_LOG(LogTemp, Error, TEXT("ReferenceActor failed with invalid InActor"));
		return;
	}

	TWeakObjectPtr Ptr = InActor;
	int64 id = Ptr.KGGetObjectID();
	AActor** actor = DynamicActorMap.Find(id);
	if (actor == nullptr)
	{
		DynamicActorMap.Add(id, InActor);
	}
	else
	{
		if (*actor)
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGEngineObejctManager::ReferenceActor actor[%lld, %s] is referenced again!"), id, *(InActor->GetFullName()));
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGEngineObejctManager::ReferenceActor actor[%lld] is referenced again!"), id);
		}

		*actor = InActor;
	}
}

void UKGObjectActorManager::UnRefernceActor(AActor* InActor)
{
	if (IsValid(InActor) == false)
	{
		UE_LOG(LogTemp, Error, TEXT("UnRefernceActor failed with invalid InObject"));
		return;
	}

	TWeakObjectPtr Ptr = InActor;
	int64 id = Ptr.KGGetObjectID();

	AActor** actor = DynamicActorMap.Find(id);
	if (actor == nullptr)
	{
		//UE_LOG(LogTemp, Warning, TEXT("UKGEngineObejctManager::UnRefernceActor invalid object[%lld %s] to unreference"), id, *(InActor->GetFullName()));
	}
	else
	{
		if (*actor == nullptr)
		{
			UE_LOG(LogTemp, Error, TEXT("UKGEngineObejctManager::UnRefernceActor key[%lld] value is null"), id);
		}

		DynamicActorMap.Remove(id);
	}


}

void UKGObjectActorManager::UnreferenceAllActors()
{
	DynamicActorMap.Reset();
}

void UKGObjectActorManager::OnWorldCleanupEnd(UWorld* World, bool bSessionEnded, bool bCleanupResources)
{
	if (OnWorldCleanUpDelegate.IsBound())
	{
		OnWorldCleanUpDelegate.Broadcast(World);
	}

	UnreferenceAllActors();
}

void UKGObjectActorManager::OnActorDestroyed(AActor* InActor)
{
	if (InActor == nullptr)
	{
		return;
	}

	UnRefernceActor(InActor);

	check(InActor->OnDestroyed.IsBound());
	InActor->OnDestroyed.RemoveDynamic(this, &UKGObjectActorManager::OnActorDestroyed);

	if (OnActorDestoryedDelegate.IsBound())
	{
		OnActorDestoryedDelegate.Broadcast(InActor, GetIDByObejct(InActor));
	}
}