#include "Manager/KGBasicManager.h"

#include "Misc/CrashCollector.h"
#include "Misc/KGGameInstanceBase.h"
#include "Lua/LuaEnv.h"
#include "Misc/Log.h"


void FTickUKGManagerFunction::ExecuteTick(float DeltaTime, enum ELevelTick TickType, ENamedThreads::Type CurrentThread, const FGraphEventRef& MyCompletionGraphEvent)
{
	QUICK_SCOPE_CYCLE_COUNTER(FTickUKGManagerFunction_ExecuteTick);
	if (ensure(Manager) && Manager->GetIsActive())
	{
		Manager->Tick(DeltaTime);
	}
}

FString FTickUKGManagerFunction::DiagnosticMessage()
{
	return TEXT("FTickUKGManagerFunction");
}

FName FTickUKGManagerFunction::DiagnosticContext(bool bDetailed)
{
	return FName(TEXT("TickUKGManager"));
}

FTickUKGManagerFunction& UKGBasicManager::GetTickFunction()
{
	return TickFunction;
}

void UKGBasicManager::NativeInit()
{
	bActive = true;

	AddToRoot();

	FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &UKGBasicManager::OnPostLoadMapWithWorld);

	
	REG_LUA_OBJECT_BIND_FUNC(UKGBasicManager);

	UE_LOG(LogTemp, Log, TEXT("[Manager] %s Init !"), *GetName());
}

void UKGBasicManager::NativeUninit()
{
	UE_LOG(LogTemp, Log, TEXT("[Manager] %s Uninit !"), *GetName());

	FCoreUObjectDelegates::PostLoadMapWithWorld.RemoveAll(this);
	
	RemoveFromRoot();

	UnbindLuaObject();

	TickFunction.UnRegisterTickFunction();

	bActive = false;
}

bool UKGBasicManager::GetIsActive() const
{
	return bActive;
}

lua_State* UKGBasicManager::GetLuaState()
{
	if (LuaEnv) {
        return LuaEnv->GetLuaState();
	}

	return nullptr;
}

UKGBasicManager* UKGBasicManager::GetManagerByType(EManagerType InType)
{
    check(LuaEnv);
    return LuaEnv->GetManagerByType(InType);
}

UKGBasicManager* UKGBasicManager::GetManagerByType(UObject* InContext, EManagerType InType)
{
	if (InContext == nullptr)
	{
		UEnum* ManagerType = StaticEnum<EManagerType>();
		if (ManagerType)
		{
			FString EnumString = ManagerType->GetNameStringByValue(static_cast<int64>(InType));
#if WITH_EDITOR
			TArray<FProgramCounterSymbolInfo> StackBackTrace;
			FCrashCollector::GetStack(StackBackTrace, 1, 96, true, true);
			TAnsiStringBuilder<1024> Builder;
			if (StackBackTrace.Num())
			{
				for (auto& StackInfo : StackBackTrace)
				{
					Builder.Append("\t");
					if (StackInfo.ProgramCounter)
					{
						Builder.Appendf("%s\tabsPc 0x%llx\t%s (%s:%d)\n", TCHAR_TO_UTF8(*FPaths::GetCleanFilename(StackInfo.ModuleName)),
							StackInfo.ProgramCounter, StackInfo.FunctionName, StackInfo.Filename, StackInfo.LineNumber);
					}
					else
					{
						Builder.Appendf("%s\t%s (%s:%d)\n", StackInfo.ModuleName, StackInfo.FunctionName, StackInfo.Filename, StackInfo.LineNumber);
					}
				}
			}
			UE_LOG(LogC7, Error, TEXT("UKGBasicManager::GetManagerByType : InContext is null  ManagerType : %s Trace: %hs"), *EnumString, Builder.GetData());
#else
			UE_LOG(LogC7, Error, TEXT("UKGBasicManager::GetManagerByType : InContext is null  ManagerType : %s"), *EnumString);
#endif
		}

		return nullptr;
		
	}

	UGameInstance* GI = UGameplayStatics::GetGameInstance(InContext);

	//editor 虚拟机是没有game instance，仅仅游戏或PIE里的游戏才有game instance
	if (GI) 
	{
		UKGGameInstanceBase* KGGI = Cast<UKGGameInstanceBase>(GI);
		if (KGGI == nullptr)
		{
			UE_LOG(LogC7, Error, TEXT("GameInstance is not a UKGGameInstanceBase !!!!"));
			return nullptr;
		}

		auto LuaEnv = KGGI->GetLuaEnv();
		if (LuaEnv == nullptr)
		{
			UE_LOG(LogC7, Error, TEXT("LuaEnv is null, need to check"));
			return nullptr;
		}

		return LuaEnv->GetManagerByType(InType);
	}
	else //编辑器情况
	{

		UEditorLuaEnv *LuaEnv = UEditorLuaEnv::GetLuaEnv(InContext);
        if (LuaEnv)
		{
            return LuaEnv->GetManagerByType(InType);
		}
		else
		{
			//20241104 在editor环境下确实可能存在对应的editor LuaGI不存在的情况, 相应的错误日志转移到GetLuaGI内部中, 仅针对不合理的case才输出错误日志
			//UE_LOG(LogC7, Warning, TEXT("UKGBasicManager::GetManagerByType : InContext[%s] InType[%d]"), *InContext->GetPathName(), InType);
			return nullptr;
		}
	}
}

