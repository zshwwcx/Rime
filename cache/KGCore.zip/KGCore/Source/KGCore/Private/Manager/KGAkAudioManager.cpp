#include "Manager/KGAkAudioManager.h"
#include "Wwise/API/WwiseSoundEngineAPI.h"
#include "AkComponent.h"
#include "AkAudioEvent.h"
#include "Audio/C7AkAudioVolume.h"
#include "AkGameplayStatics.h"
#include "Async/Async.h"
#include "Manager/KGCppAssetManager.h"
#include "Manager/KGObjectActorManager.h"
#include "3C/Util/KGUtils.h"

DEFINE_LOG_CATEGORY(LogAudioMgr)

static AK::SoundEngine::AkActionOnEventType AkAction_Stop = AK::SoundEngine::AkActionOnEventType::AkActionOnEventType_Stop;
static AK::SoundEngine::AkActionOnEventType AkAction_Pause = AK::SoundEngine::AkActionOnEventType::AkActionOnEventType_Pause;
static AK::SoundEngine::AkActionOnEventType AkAction_Resume = AK::SoundEngine::AkActionOnEventType::AkActionOnEventType_Resume;
static AkCallbackType NoneAkCallbackType = (AkCallbackType)0;


#pragma region Important


void UKGAkAudioManager::NativeInit()
{
	Super::NativeInit();

	AudioRecapHelper.SetAudioManager(this);

	// 静态导出
	using namespace NS_SLUA;

	// COMMON
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerPostEvent3D", &UKGAkAudioManager::InnerPostEvent3D);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerPostEventOnPureActor", &UKGAkAudioManager::InnerPostEventOnPureActor);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerStopEventByPlayingID", &UKGAkAudioManager::InnerStopEventByPlayingID);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerPauseEventByPlayingID", &UKGAkAudioManager::InnerPauseEventByPlayingID);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerResumeEventByPlayingID", &UKGAkAudioManager::InnerResumeEventByPlayingID);
	REG_MANAGER_FUNC(UKGAkAudioManager, "StopAllByPlayingIDs", &UKGAkAudioManager::StopAllByPlayingIDs);

	// NOTIFY&BATTLE
	REG_MANAGER_FUNC(UKGAkAudioManager, "SetNotifyEventLimit", &UKGAkAudioManager::SetNotifyEventLimit);
	REG_MANAGER_FUNC(UKGAkAudioManager, "SetLockTargetUID", &UKGAkAudioManager::SetLockTargetUID);
	REG_MANAGER_FUNC(UKGAkAudioManager, "GetBattleEventNum", &UKGAkAudioManager::GetBattleEventNum);
	REG_MANAGER_FUNC(UKGAkAudioManager, "AddBattleEventRecord", &UKGAkAudioManager::AddBattleEventRecord);
	REG_MANAGER_FUNC(UKGAkAudioManager, "DelBattleEventRecord", &UKGAkAudioManager::DelBattleEventRecord);
	REG_MANAGER_FUNC(UKGAkAudioManager, "SetBattleEventLimitInfo", &UKGAkAudioManager::SetBattleEventLimitInfo);
	REG_MANAGER_FUNC(UKGAkAudioManager, "SetEnablePrintTerrainName", &UKGAkAudioManager::SetEnablePrintTerrainName);

	// AUDIO PARAM
	REG_MANAGER_FUNC(UKGAkAudioManager, "OnWindowFocusChanged", &UKGAkAudioManager::OnWindowFocusChanged);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerSetGroupState", &UKGAkAudioManager::InnerSetGroupState);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerResetGroupState", &UKGAkAudioManager::InnerResetGroupState);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerSetRtpcValue", &UKGAkAudioManager::InnerSetRtpcValue);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerResetRtpcValue", &UKGAkAudioManager::InnerResetRtpcValue);

	// InitData
	REG_MANAGER_FUNC(UKGAkAudioManager, "SetLruSize", &UKGAkAudioManager::SetLruSize);
	REG_MANAGER_FUNC(UKGAkAudioManager, "SetAudioCulture", &UKGAkAudioManager::SetAudioCulture);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerInitEventData", &UKGAkAudioManager::InnerInitEventData);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerUpdateEventData", &UKGAkAudioManager::InnerUpdateEventData);
	REG_MANAGER_FUNC(UKGAkAudioManager, "SetCommonGameParameterName", &UKGAkAudioManager::SetCommonGameParameterName);
	REG_MANAGER_FUNC(UKGAkAudioManager, "SyncLoadAndCacheEvent", &UKGAkAudioManager::SyncLoadAndCacheEvent);

	// AudioRecap
	REG_MANAGER_FUNC(UKGAkAudioManager, "StartRecordAudioRecap", &UKGAkAudioManager::StartRecordAudioRecap);
	REG_MANAGER_FUNC(UKGAkAudioManager, "StopRecordAudioRecap", &UKGAkAudioManager::StopRecordAudioRecap);

	// Battle
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerPostEventForSkill", &UKGAkAudioManager::InnerPostEventForSkill);
	REG_MANAGER_FUNC(UKGAkAudioManager, "InnerStopEventForSkill", &UKGAkAudioManager::InnerStopEventForSkill);

	// Dialogue
	REG_MANAGER_FUNC(UKGAkAudioManager, "GetDialogueVoiceEventName", &UKGAkAudioManager::GetDialogueVoiceEventName);

	// GlobalParams
	REG_MANAGER_FUNC(UKGAkAudioManager, "KAPI_AudioMgr_SetGlobalParams", &UKGAkAudioManager::KAPI_AudioMgr_SetGlobalParams);
}

void UKGAkAudioManager::NativeUninit()
{
	if (auto* CppAssetMgr = UKGCppAssetManager::GetInstance(this))
	{
		for (auto& It : AsyncEventPostTasks)
		{
			FAsyncEventPostTask& Task = It.Value;
			CppAssetMgr->CancelAsyncLoadByLoadID(Task.LoadID);
		}
	}
	AsyncEventPostTasks.Empty();

	StaticEventPool.Empty();
	AmbientEventPool.Empty();
	LruEventPool.Empty();
	EventCachePool.Empty();

	Super::NativeUninit();
}

void UKGAkAudioManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if (World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}

	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_DuringPhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);

	if (bIsRecording)
	{
		AudioRecapHelper.RebindDelegate();
	}

	// 切图Ambient资产清理
	for (auto& It : AmbientEventPool)
	{
		EventCachePool.Remove(It.Key);
	}
	AmbientEventPool.Empty();
}

void UKGAkAudioManager::Tick(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGAkAudioManager::Tick");
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	double CurrentTime = World->GetTimeSeconds();

	if (bIsRecording)
	{
		AudioRecapHelper.OnRecordTick();
	}

	// 数量限制逻辑要控制频率
	if (CurrentTime - LastUpdateTime < 0.5f)
	{
		return;
	}

	LastUpdateTime = CurrentTime;

	TArray<int32> RecordToRemove;
	for (auto Iter : AvatarNotifyEventPlayingMap)
	{
		const double& ExpireTime = Iter.Value;
		if (CurrentTime >= ExpireTime)
		{
			RecordToRemove.Add(Iter.Key);
		}
	}

	for (auto PlayingID : RecordToRemove)
	{
		AvatarNotifyEventPlayingMap.Remove(PlayingID);
	}

	RecordToRemove.Reset();
	for (auto Iter : NpcNotifyEventPlayingMap)
	{
		const double& ExpireTime = Iter.Value;
		if (CurrentTime >= ExpireTime)
		{
			RecordToRemove.Add(Iter.Key);
		}
	}

	for (auto PlayingID : RecordToRemove)
	{
		NpcNotifyEventPlayingMap.Remove(PlayingID);
	}

	RecordToRemove.Reset();
	for (auto Iter : BattleEventPlayingMap)
	{
		const double& ExpireTime = Iter.Value;
		if (CurrentTime >= ExpireTime)
		{
			RecordToRemove.Add(Iter.Key);
		}
	}

	for (auto PlayingID : RecordToRemove)
	{
		BattleEventPlayingMap.Remove(PlayingID);
	}

	// 有变同步
	float BattleEventNum = BattleEventPlayingMap.Num();
	float NextBattleEventRtpcValue = BattleEventNum < BattleEventLimit ? BattleEventNum : BattleEventLimit;
	if (!FMath::IsNearlyEqual(NextBattleEventRtpcValue, CurrentBattleEventRtpcValue, 0.1f))
	{
		CurrentBattleEventRtpcValue = NextBattleEventRtpcValue;
		InnerSetRtpcValue(BattleEventLimitRtpcName, CurrentBattleEventRtpcValue);
	}

	// UE_LOG(LogAudioMgr, Log, TEXT("Current in playing event num, Notify:%d, Battle:%d"), NotifyEventPlayingMap.Num(), BattleEventPlayingMap.Num());
}

#pragma endregion Important


#pragma region Track


void UKGAkAudioManager::PostTrackEvent(UObject* WorldContextObject, UAkAudioEvent* AkAudioEvent, bool bEnableSync)
{
	if (!AkAudioEvent)
	{
		return;
	}

	if (IsValid(WorldContextObject))
	{
		if (UKGAkAudioManager* AudioManager = GetInstance(WorldContextObject))
		{
			AudioManager->InnerPostEvent3D(AkAudioEvent->GetName());
		}
	}
	else
	{
#if WITH_EDITOR
		AkAudioEvent->PostOnActor(nullptr, nullptr, nullptr, nullptr, NoneAkCallbackType, nullptr, true);
#else
		UE_LOG(LogAudioMgr, Error, TEXT("UKGAkAudioManager::PostTrackEvent Context is null"));
#endif
	}
}


#pragma endregion Track


#pragma region Event


int32 UKGAkAudioManager::InnerPostEvent3D(const FString& EventName, double X, double Y, double Z)
{
	const FVector Location(X, Y, Z);
	if (const TWeakObjectPtr<UAkAudioEvent>* AkAudioEventPtr = GetEventFromPool(EventName))
	{
		const TWeakObjectPtr<UAkAudioEvent> AkAudioEvent = *AkAudioEventPtr;
		if (AkAudioEvent.IsValid())
		{
			if (IsMusicEvent(EventName))
			{
				return AkAudioEvent->PostOnGameObjectID(DUMMY_GAMEOBJ, nullptr, nullptr, nullptr, NoneAkCallbackType, nullptr);
			}
			else
			{
				return AkAudioEvent->PostAtLocation(Location, FRotator::ZeroRotator, GetWorld(), nullptr, nullptr, nullptr, NoneAkCallbackType, nullptr);	
			}
		}

		UE_LOG(LogAudioMgr, Warning, TEXT("[InnerPostEvent3D] %s event asset invalid, reload"), *EventName);
		ClearEventFromPool(EventName);
	}

	FString* EventPath = Event2Path.Find(EventName);
	if (!EventPath)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[InnerPostEvent3D] %s get event path failed"), *EventName)
		return AK_INVALID_PLAYING_ID;
	}

	return InnerAsyncPostEvent(*EventPath, Location);
}

int32 UKGAkAudioManager::InnerPostEventOnAkComp(const FString& EventName, UAkComponent* AkComponent, bool bStopWhenAttachedObjectDestroyed/* = false */)
{
	if (!IsValid(AkComponent))
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[InnerPostEventOnAkComp] ak component invalid, cannot post %s"), *EventName);
		return AK_INVALID_PLAYING_ID;
	}

	if (const TWeakObjectPtr<UAkAudioEvent>* AkAudioEventPtr = GetEventFromPool(EventName))
	{
		const TWeakObjectPtr<UAkAudioEvent> AkAudioEvent = *AkAudioEventPtr;
		if (AkAudioEvent.IsValid())
		{
			return AkAudioEvent->PostOnComponent(AkComponent, nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, bStopWhenAttachedObjectDestroyed);
		}
		else
		{
			UE_LOG(LogAudioMgr, Warning, TEXT("[InnerPostEventOnAkComp] %s event asset invalid, reload"), *EventName);
			ClearEventFromPool(EventName);
		}
	}

	FString* EventPath = Event2Path.Find(EventName);
	if (!EventPath)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[InnerPostEventOnAkComp] %s get event path failed"), *EventName)
		return AK_INVALID_PLAYING_ID;
	}

	return InnerAsyncPostEvent(*EventPath, FVector::ZeroVector, AkComponent, bStopWhenAttachedObjectDestroyed);
}

int32 UKGAkAudioManager::InnerPostEventOnPureActor(const FString& EventName, KGActorID ActorID)
{
	auto* ObjectActorMgr = UKGObjectActorManager::GetInstance(this);
	if (!ObjectActorMgr)
	{
		return AK_INVALID_PLAYING_ID;
	}

	AActor* Actor = Cast<AActor>(ObjectActorMgr->GetObjectByID(ActorID));
	if (!Actor)
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[InnerPostEventOnPureActor] Actor:%lld not found, %s post failed"), ActorID, *EventName);
		return AK_INVALID_PLAYING_ID;
	}

	UAkComponent* AkComponent = Actor->GetComponentByClass<UAkComponent>();
	if (!AkComponent)
	{
		// 没有的话动态新增一个
		UE_LOG(LogAkAudio, Log, TEXT("[InnerPostEventOnPureActor] Actor:%lld dynamic add AkComponent on post %s"), ActorID, *EventName);
		if (UActorComponent* ActorComponent = Actor->AddComponentByClass(UAkComponent::StaticClass(), false, FTransform::Identity, false))
		{
			AkComponent = Cast<UAkComponent>(ActorComponent);
		}
	}

	return InnerPostEventOnAkComp(EventName, AkComponent);
}

void UKGAkAudioManager::InnerStopEventByPlayingID(int32 PlayingID, int32 BlendTime, EAkCurveInterpolation BlendType)
{
	if (PlayingID == AK_INVALID_PLAYING_ID)
	{
		return;
	}

	// 异步播放的Event有标记
	if (AsyncEventPostTasks.Contains(PlayingID))
	{
		if (FAsyncEventPostTask* Task = AsyncEventPostTasks.Find(PlayingID))
		{
			UE_LOG(LogAudioMgr, Log, TEXT("[InnerStopEventByPlayingID] %d stopped in async loading"), PlayingID);
			Task->bNeedPost = false;
			return;
		}
	}

	// 获取真正的PlayingID
	if (AsyncPostTaskID2PlayingID.Contains(PlayingID * -1))
	{
		PlayingID = AsyncPostTaskID2PlayingID[PlayingID * -1];
	}

	if (bIsRecording)
	{
		AudioRecapHelper.RecordEventStopped(PlayingID);
	}

	if (auto* SoundEngine = IWwiseSoundEngineAPI::Get())
	{
		SoundEngine->ExecuteActionOnPlayingID(AkAction_Stop, PlayingID, BlendTime);
	}
}

void UKGAkAudioManager::InnerPauseEventByPlayingID(int32 PlayingID, int32 BlendTime, EAkCurveInterpolation BlendType)
{
	// 获取真正的PlayingID
	if (AsyncPostTaskID2PlayingID.Contains(PlayingID * -1))
	{
		PlayingID = AsyncPostTaskID2PlayingID[PlayingID * -1];
	}

	if (auto* SoundEngine = IWwiseSoundEngineAPI::Get())
	{
		SoundEngine->ExecuteActionOnPlayingID(AkAction_Pause, PlayingID, BlendTime);
	}
}

void UKGAkAudioManager::InnerResumeEventByPlayingID(int32 PlayingID, int32 BlendTime, EAkCurveInterpolation BlendType)
{
	// 获取真正的PlayingID
	if (AsyncPostTaskID2PlayingID.Contains(PlayingID * -1))
	{
		PlayingID = AsyncPostTaskID2PlayingID[PlayingID * -1];
	}

	if (auto* SoundEngine = IWwiseSoundEngineAPI::Get())
	{
		SoundEngine->ExecuteActionOnPlayingID(AkAction_Resume, PlayingID, BlendTime);
	}
}

void UKGAkAudioManager::StopAllByPlayingIDs(const TArray<int32>& PlayingIDs)
{
	for (auto& PlayingID : PlayingIDs)
	{
		InnerStopEventByPlayingID(PlayingID);
	}
}

void UKGAkAudioManager::OnAkAudioEventLoaded(int InLoadID, UObject* LoadedObject, int32 EventPostTaskID)
{
	UAkAudioEvent* AkAudioEvent = Cast<UAkAudioEvent>(LoadedObject);
	if (!AkAudioEvent)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[OnAkAudioEventLoaded] event asset invalid in %d"), EventPostTaskID);
		AsyncEventPostTasks.Remove(EventPostTaskID);
		return;
	}

	if (!AsyncEventPostTasks.Contains(EventPostTaskID))
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[OnAkAudioEventLoaded] event post task %d not exist"), EventPostTaskID);
		return;
	}

	// 分类存放
	const FString& EventName = AkAudioEvent->GetName();
	if (IsMusicEvent(EventName))
	{
		StaticEventPool.Add(EventName, AkAudioEvent);
	}
	else if (IsAmbientEvent(EventName))
	{
		AmbientEventPool.Add(EventName, AkAudioEvent);
	}
	else
	{
		LruEventPool.Add(EventName, AkAudioEvent);
	}

	// 持有资产
	EventCachePool.Emplace(EventName, AkAudioEvent);

	if (FAsyncEventPostTask* Task = AsyncEventPostTasks.Find(EventPostTaskID))
	{
		if (Task->bNeedPost)
		{
			int32 PlayingID;
			if (Task->bOnComp)
			{
				PlayingID = AkAudioEvent->PostOnComponent(Task->AkComp.Get(), nullptr, nullptr, nullptr, NoneAkCallbackType, nullptr, Task->bStopWhenAttachedObjectDestroyed);
			}
			else
			{
				if (IsMusicEvent(EventName))
				{
					PlayingID = AkAudioEvent->PostOnGameObjectID(DUMMY_GAMEOBJ, nullptr, nullptr, nullptr, NoneAkCallbackType, nullptr);
				}
				else
				{
					PlayingID = AkAudioEvent->PostAtLocation(Task->Location, FRotator::ZeroRotator, GetWorld(), nullptr, nullptr, nullptr, NoneAkCallbackType, nullptr);	
				}
			}

			// @shijingzhe:这里*-1的原因是和正常的PlayingID区分开,因为有可能普通PlayingID==TaskID的情况
			AsyncPostTaskID2PlayingID.Add(EventPostTaskID * -1, PlayingID);	
		}
	}

	// 清理异步Task
	AsyncEventPostTasks.Remove(EventPostTaskID);
}

void UKGAkAudioManager::CacheEventAsset(UAkAudioEvent* AkAudioEvent)
{
	if (!AkAudioEvent)
	{
		return;
	}

	// 分类存放
	const FString& EventName = AkAudioEvent->GetName();
	if (IsMusicEvent(EventName))
	{
		StaticEventPool.Emplace(EventName, AkAudioEvent);
	}
	else if (IsAmbientEvent(EventName))
	{
		AmbientEventPool.Emplace(EventName, AkAudioEvent);
	}
	else
	{
		LruEventPool.Add(EventName, AkAudioEvent);
	}

	// 持有资产
	EventCachePool.Emplace(EventName, AkAudioEvent);
}

void UKGAkAudioManager::SyncLoadAndCacheEvent(const FString& EventName)
{
	auto* AssetMgr = UKGCppAssetManager::GetInstance(this);
	if (!AssetMgr)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[SyncLoadAndCacheEvent] get UKGCppAssetManager failed in loading %s"), *EventName);
		return;
	}

	const FString& EventPath = GetEventPath(EventName);
	if (EventPath.IsEmpty())
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[SyncLoadAndCacheEvent] no event asset path for %s"), *EventName);
		return;
	}

	UObject* AssetObj = AssetMgr->SyncLoadAsset(EventPath);
	if (!AssetObj)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[SyncLoadAndCacheEvent] EventName:%s EventPath:%s load failed"), *EventName, *EventPath);
		return;
	}

	UAkAudioEvent* AkAudioEvent = Cast<UAkAudioEvent>(AssetObj);
	if (!AkAudioEvent)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[SyncLoadAndCacheEvent] EventName:%s EventPath:%s not an UAkAudioEvent"), *EventName, *EventPath);
		return;
	}

	UE_LOG(LogAudioMgr, Log, TEXT("[SyncLoadAndCacheEvent] EventName:%s EventPath:%s success"), *EventName, *EventPath);
	CacheEventAsset(AkAudioEvent);
}

FString UKGAkAudioManager::GetEventPath(const FString& EventName) const
{
	return Event2Path.Contains(EventName) ? Event2Path[EventName] : FString();
}

int32 UKGAkAudioManager::GenerateEventPostTaskID()
{
	static int32 PlayTaskID = 1;
	PlayTaskID++;
	if (PlayTaskID >= 0x7fffffff)
	{
		PlayTaskID = 1;
	}
	return PlayTaskID;
}

int32 UKGAkAudioManager::InnerAsyncPostEvent(const FString& EventPath, const FVector& Location, UAkComponent* AkComp, bool bStopWhenAttachedObjectDestroyed)
{
	auto* CppAssetMgr = UKGCppAssetManager::GetInstance(this);
	if (!CppAssetMgr)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[InnerAsyncLoadEventAsset] get asset manager failed"));
		return AK_INVALID_PLAYING_ID;
	}

	int32 EventPostTaskID = GenerateEventPostTaskID();
	FAsyncEventPostTask AsyncLoadTask;
	AsyncLoadTask.bOnComp = IsValid(AkComp);
	AsyncLoadTask.Location = Location;
	AsyncLoadTask.AkComp = AkComp;
	AsyncLoadTask.bStopWhenAttachedObjectDestroyed = bStopWhenAttachedObjectDestroyed;
	AsyncLoadTask.LoadID = CppAssetMgr->AsyncLoadAsset(EventPath, FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGAkAudioManager::OnAkAudioEventLoaded, EventPostTaskID));

	AsyncEventPostTasks.Add(EventPostTaskID, AsyncLoadTask);
	return EventPostTaskID;
}

const TWeakObjectPtr<UAkAudioEvent>* UKGAkAudioManager::GetEventFromPool(const FString& EventName)
{
	const TWeakObjectPtr<UAkAudioEvent>* AkAudioEventPtr = StaticEventPool.Find(EventName);
	if (!AkAudioEventPtr)
	{
		AkAudioEventPtr = AmbientEventPool.Find(EventName);
	}
	if (!AkAudioEventPtr)
	{
		AkAudioEventPtr = LruEventPool.FindAndTouch(EventName);
	}
	return AkAudioEventPtr;
}

void UKGAkAudioManager::ClearEventFromPool(const FString& EventName)
{
	StaticEventPool.Remove(EventName);
	AmbientEventPool.Remove(EventName);
	LruEventPool.Remove(EventName);
	EventCachePool.Remove(EventName);
}

bool UKGAkAudioManager::DoesBattleEventOverLimit()
{
	return BattleEventPlayingMap.Num() >= BattleEventLimit;
}

#pragma endregion Event


#pragma region Notify&BATTLE


void UKGAkAudioManager::SetNotifyEventLimit(int32 InAvatarNotifyEventLimit, int32 InNpcNotifyEventLimit)
{
	AvatarNotifyEventLimit = InAvatarNotifyEventLimit;
	NpcNotifyEventLimit = InNpcNotifyEventLimit;
}

bool UKGAkAudioManager::CanPostNotifyEvent(bool bIsAvatar) const
{
	if (bIsAvatar)
	{
		return AvatarNotifyEventPlayingMap.Num() < AvatarNotifyEventLimit;
	}
	else
	{
		return NpcNotifyEventPlayingMap.Num() < NpcNotifyEventLimit;
	}
}

void UKGAkAudioManager::AddNotifyEventRecord(int32 PlayingID, double PlayingTime, bool bIsAvatar)
{
	if (PlayingID == AK_INVALID_PLAYING_ID)
	{
		return;
	}

	if (UWorld* World = GetWorld())
	{
		if (bIsAvatar)
		{
			AvatarNotifyEventPlayingMap.Add(PlayingID, PlayingTime + World->GetTimeSeconds());
		}
		else
		{
			NpcNotifyEventPlayingMap.Add(PlayingID, PlayingTime + World->GetTimeSeconds());
		}
	}
}

void UKGAkAudioManager::AddBattleEventRecord(int32 PlayingID, double PlayingTime)
{
	if (UWorld* World = GetWorld())
	{
		BattleEventPlayingMap.Add(PlayingID, PlayingTime + World->GetTimeSeconds());
	}
}

void UKGAkAudioManager::DelBattleEventRecord(int32 PlayingID)
{
	BattleEventPlayingMap.Remove(PlayingID);
}

void UKGAkAudioManager::SetBattleEventLimitInfo(FString InBattleEventLimitRtpcName, float InBattleEventLimit)
{
	BattleEventLimitRtpcName = InBattleEventLimitRtpcName;
	BattleEventLimit = InBattleEventLimit;
}


#pragma endregion Notify&BATTLE


#pragma region AUDIO_PARAM


void UKGAkAudioManager::OnWindowFocusChanged(bool bLostFocus)
{
	IWwiseSoundEngineAPI* WwiseSoundEngineAPI = IWwiseSoundEngineAPI::Get();
	if (!WwiseSoundEngineAPI)
	{
		return;
	}

	if (bLostFocus)
	{
		WwiseSoundEngineAPI->Suspend(true);
	}
	else
	{
		WwiseSoundEngineAPI->WakeupFromSuspend();
	}
}

void UKGAkAudioManager::InnerSetGroupState(const FString& Group, const FString& State)
{
	IWwiseSoundEngineAPI* WwiseSoundEngineAPI = IWwiseSoundEngineAPI::Get();
	if (!WwiseSoundEngineAPI)
	{
		return;
	}

	WwiseSoundEngineAPI->SetState(TCHAR_TO_AK(*Group), TCHAR_TO_AK(*State));
	GroupStates.Emplace(Group, State);

	if (bIsRecording)
	{
		AudioRecapHelper.RecordGroupState(Group, State);
	}
}

static FString NoneState = TEXT("None"); 

void UKGAkAudioManager::InnerResetGroupState(const FString& Group)
{
	IWwiseSoundEngineAPI* WwiseSoundEngineAPI = IWwiseSoundEngineAPI::Get();
	if (!WwiseSoundEngineAPI)
	{
		return;
	}

	WwiseSoundEngineAPI->SetState(TCHAR_TO_AK(*Group), TCHAR_TO_AK(*NoneState));
	GroupStates.Remove(Group);

	if (bIsRecording)
	{
		AudioRecapHelper.RecordGroupState(Group, NoneState);
	}
}

void UKGAkAudioManager::InnerSetRtpcValue(const FString& RtpcName, float RtpcValue)
{
	IWwiseSoundEngineAPI* WwiseSoundEngineAPI = IWwiseSoundEngineAPI::Get();
	if (!WwiseSoundEngineAPI)
	{
		return;
	}

	WwiseSoundEngineAPI->SetRTPCValue(TCHAR_TO_AK(*RtpcName), RtpcValue);
	Rtpcs.Emplace(RtpcName, RtpcValue);

	if (bIsRecording)
	{
		AudioRecapHelper.RecordRtpc(RtpcName, RtpcValue);
	}
}

float UKGAkAudioManager::ResetRtpcValue = -999;

void UKGAkAudioManager::InnerResetRtpcValue(const FString& RtpcName)
{
	IWwiseSoundEngineAPI* WwiseSoundEngineAPI = IWwiseSoundEngineAPI::Get();
	if (!WwiseSoundEngineAPI)
	{
		return;
	}

	WwiseSoundEngineAPI->ResetRTPCValue(TCHAR_TO_AK(*RtpcName));
	Rtpcs.Remove(RtpcName);

	if (bIsRecording)
	{
		AudioRecapHelper.RecordRtpc(RtpcName, ResetRtpcValue);
	}
}

void UKGAkAudioManager::SetRtpcValueOnAkGameObject(UAkGameObject* AkGameObject, const FString& RtpcName, float RtpcValue)
{
	if (!AkGameObject)
	{
		return;
	}

	IWwiseSoundEngineAPI* WwiseSoundEngineAPI = IWwiseSoundEngineAPI::Get();
	if (!WwiseSoundEngineAPI)
	{
		return;
	}

	AkGameObjectID GameObjectID = AkGameObject->GetAkGameObjectID();
	TMap<FString, float>* RtpcsOnGameObject = GameObjectRtpcs.Find(GameObjectID);
	if (!RtpcsOnGameObject)
	{
		RtpcsOnGameObject = &GameObjectRtpcs.Add(GameObjectID);
	}
	RtpcsOnGameObject->Emplace(RtpcName, RtpcValue);

	WwiseSoundEngineAPI->SetRTPCValue(TCHAR_TO_AK(*RtpcName), RtpcValue, GameObjectID);

	if (bIsRecording)
	{
		AudioRecapHelper.RecordRtpc(RtpcName, RtpcValue, AkGameObject);
	}
}

void UKGAkAudioManager::ResetRtpcValueOnAkGameObject(UAkGameObject* AkGameObject, const FString& RtpcName)
{
	if (!AkGameObject)
	{
		return;
	}

	IWwiseSoundEngineAPI* WwiseSoundEngineAPI = IWwiseSoundEngineAPI::Get();
	if (!WwiseSoundEngineAPI)
	{
		return;
	}

	AkGameObjectID GameObjectID = AkGameObject->GetAkGameObjectID();
	TMap<FString, float>* RtpcsOnGameObject = GameObjectRtpcs.Find(GameObjectID);
	if (!RtpcsOnGameObject)
	{
		RtpcsOnGameObject = &GameObjectRtpcs.Add(GameObjectID);
	}
	RtpcsOnGameObject->Remove(RtpcName);

	WwiseSoundEngineAPI->ResetRTPCValue(TCHAR_TO_AK(*RtpcName), GameObjectID);

	if (bIsRecording)
	{
		AudioRecapHelper.RecordRtpc(RtpcName, ResetRtpcValue, AkGameObject);
	}
}

void UKGAkAudioManager::SetSwitchGroupOnAkGameObject(UAkGameObject* AkGameObject, const FString& SwitchGroup, const FString& SwitchState)
{
	if (!AkGameObject)
	{
		return;
	}

	IWwiseSoundEngineAPI* WwiseSoundEngineAPI = IWwiseSoundEngineAPI::Get();
	if (!WwiseSoundEngineAPI)
	{
		return;
	}

	AkGameObjectID GameObjectID = AkGameObject->GetAkGameObjectID();
	TMap<FString, FString>* SwitchesOnGameObject = GameObjectSwitches.Find(GameObjectID);
	if (!SwitchesOnGameObject)
	{
		SwitchesOnGameObject = &GameObjectSwitches.Add(GameObjectID);
	}
	SwitchesOnGameObject->Emplace(SwitchGroup, SwitchState);

	WwiseSoundEngineAPI->SetSwitch(TCHAR_TO_AK(*SwitchGroup), TCHAR_TO_AK(*SwitchState), GameObjectID);

	if (bIsRecording)
	{
		AudioRecapHelper.RecordSwitch(SwitchGroup, SwitchState, AkGameObject);
	}
}

void UKGAkAudioManager::OnEnterPriorityGroupStateAudioVolume(AC7AkAudioVolume* AudioVolume)
{
	if (!AudioVolume)
	{
		return;
	}

	UKGAkAudioManager* AudioManager = GetInstance(AudioVolume);
	if (!AudioManager)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("OnEnterPriorityGroupStateAudioVolume %s get audio manager failed"), *AudioVolume->GetName());
		return;
	}

	AudioManager->SetPriorityGroupState(AudioVolume);
}

void UKGAkAudioManager::SetPriorityGroupState(class AC7AkAudioVolume* AudioVolume)
{
	if (!AudioVolume)
	{
		return;
	}

	// 没有优先级,直接设
	if (AudioVolume->Priority < 0)
	{
		for (auto& GS : AudioVolume->GroupState)
		{
			InnerSetGroupState(GS.Group, GS.State);
		}

		return;
	}

	const uint32 VolumeUniqueID = AudioVolume->GetUniqueID();

	if (PriorityGroupStateList.Num() > 0)
	{
		FPriorityGroupStateItem& TopItem = PriorityGroupStateList.Last();

		// 如果优先级更高,则reset当前top, 并设置新的
		if (AudioVolume->Priority >= TopItem.Priority)
		{
			for (auto& GS : TopItem.GroupState)
			{
				InnerResetGroupState(GS.Group);
			}

			for (auto& GS : AudioVolume->GroupState)
			{
				InnerSetGroupState(GS.Group, GS.State);
			}

			CurrentVolumeUniqueID = VolumeUniqueID;
			CurrentPriorityGroupState = AudioVolume->GroupState;
		}
	}
	else
	{
		for (auto& GS : AudioVolume->GroupState)
		{
			InnerSetGroupState(GS.Group, GS.State);
		}

		CurrentVolumeUniqueID = VolumeUniqueID;
		CurrentPriorityGroupState = AudioVolume->GroupState;
	}

	// 无论如何都入队并排序,升序,保证优先级最高的在队尾
	PriorityGroupStateList.Add(FPriorityGroupStateItem(VolumeUniqueID, AudioVolume->GroupState, AudioVolume->Priority));
	PriorityGroupStateList.Sort([](const FPriorityGroupStateItem& A, const FPriorityGroupStateItem& B)
	{
		return A.Priority < B.Priority;
	});

	UE_LOG(LogAudioMgr, Log, TEXT("[SetPriorityGroupState] current top priority group state volume is %u"), CurrentVolumeUniqueID);
}

void UKGAkAudioManager::OnLeavePriorityGroupStateAudioVolume(AC7AkAudioVolume* AudioVolume)
{
	if (!AudioVolume)
	{
		return;
	}

	UKGAkAudioManager* AudioManager = GetInstance(AudioVolume);
	if (!AudioManager)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("OnLeavePriorityGroupStateAudioVolume %s get audio manager failed"), *AudioVolume->GetName());
		return;
	}

	AudioManager->UnsetPriorityGroupState(AudioVolume);
}

void UKGAkAudioManager::UnsetPriorityGroupState(class AC7AkAudioVolume* AudioVolume)
{
	if (!AudioVolume)
	{
		return;
	}

	// 没有优先级,直接设
	if (AudioVolume->Priority < 0)
	{
		for (auto& GS : AudioVolume->GroupState)
		{
			InnerResetGroupState(GS.Group);
		}

		return;
	}

	const uint32 VolumeUniqueID = AudioVolume->GetUniqueID();

	// 无论如何都出队
	for (int32 Idx = 0; Idx < PriorityGroupStateList.Num(); ++Idx)
	{
		if (PriorityGroupStateList[Idx].UniqueID == VolumeUniqueID)
		{
			PriorityGroupStateList.RemoveAt(Idx);
			break;
		}
	}

	// 如果被reset的是当前值,则将当前值重置后,再把Top设置上去
	if (VolumeUniqueID == CurrentVolumeUniqueID)
	{
		for (auto& GS : CurrentPriorityGroupState)
		{
			InnerResetGroupState(GS.Group);
		}

		CurrentVolumeUniqueID = 0;
		CurrentPriorityGroupState.Empty();

		if (PriorityGroupStateList.Num() > 0)
		{
			FPriorityGroupStateItem& TopItem = PriorityGroupStateList.Last();
			for (auto& GS : TopItem.GroupState)
			{
				InnerSetGroupState(GS.Group, GS.State);
			}

			CurrentVolumeUniqueID = TopItem.UniqueID;
			CurrentPriorityGroupState = TopItem.GroupState;
		}
	}

	UE_LOG(LogAudioMgr, Log, TEXT("[UnsetPriorityGroupState] current top priority group state volume is %u"), CurrentVolumeUniqueID);
}


#pragma endregion AUDIO_PARAM


#pragma region DataInit

void UKGAkAudioManager::SetLruSize(int32 LruSize)
{
	LruEventPool.Empty(LruSize);
}

void UKGAkAudioManager::SetAudioCulture(const FString& Culture)
{
	if (FAkAudioDevice* AkAudioDevice = FAkAudioDevice::Get())
	{
		UE_LOG(LogAkAudio, Log, TEXT("[SetAudioCulture] new culture is %s"), *Culture);
		AkAudioDevice->SetCurrentAudioCulture(Culture);
	}
}

void UKGAkAudioManager::InnerInitEventData(const TMap<FString, FString>& InEvent2Path, const TMap<FString, double>& InEvent2Duration, const TMap<FString, int32>& InEvent2Category)
{
	Event2Path = InEvent2Path;
	Event2Duration = InEvent2Duration;
	Event2Category = InEvent2Category;
}

double UKGAkAudioManager::GetEventDuration(const FString& EventName)
{
	if (Event2Duration.Contains(EventName))
	{
		return Event2Duration[EventName];
	}
	return 0.f;
}

bool UKGAkAudioManager::IsMusicEvent(const FString& EventName)
{
	if (Event2Category.Contains(EventName))
	{
		return Event2Category[EventName] == EAkEventCategory::MUSIC;
	}
	return false;
}

bool UKGAkAudioManager::IsAmbientEvent(const FString& EventName)
{
	if (Event2Category.Contains(EventName))
	{
		return Event2Category[EventName] == EAkEventCategory::AMBIENT;
	}
	return false;
}

bool UKGAkAudioManager::IsValidEvent(const FString& EventName) const
{
	return Event2Duration.Contains(EventName);
}

void UKGAkAudioManager::InnerUpdateEventData(const FString& InEventName, const FString& InRequiredBank, double InDuration, int32 InCategory)
{
	Event2Path.Emplace(InEventName, InRequiredBank);
	Event2Duration.Emplace(InEventName, InDuration);
	Event2Category.Emplace(InEventName, InCategory);
}

void UKGAkAudioManager::SetCommonGameParameterName(
	const FString& InGenderSwitch, const FString& InMainPlayerGenderGroup, const FString& InMaleState, const FString& InFemaleState, const FString& InStaminaRtpc,
	const FString& AudioInputEventPath)
{
	GenderSwitch = InGenderSwitch;
	MainPlayerGenderGroup = InMainPlayerGenderGroup;
	MaleState = InMaleState;
	FemaleState = InFemaleState;
	StaminaRtpc = InStaminaRtpc;
	AudioInputEvent = LoadObject<UAkAudioEvent>(this, *AudioInputEventPath);
	if (!AudioInputEvent)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[SetCommonGameParameterName] %s load failed"), *AudioInputEventPath);
	}
}

void UKGAkAudioManager::InitCommonGameParameters(UAkComponent* AkComponent, bool bMainPlayer, int32 Gender, float StaminaValue)
{
	if (!AkComponent)
	{
		return;
	}

	if (Gender == 0)
	{
		SetSwitchGroupOnAkGameObject(AkComponent, GenderSwitch, MaleState);
		if (bMainPlayer)
		{
			InnerSetGroupState(MainPlayerGenderGroup, MaleState);
		}
	}
	else if (Gender == 1)
	{
		SetSwitchGroupOnAkGameObject(AkComponent, GenderSwitch, FemaleState);
		if (bMainPlayer)
		{
			InnerSetGroupState(MainPlayerGenderGroup, FemaleState);
		}
	}

	SetRtpcValueOnAkGameObject(AkComponent, StaminaRtpc, StaminaValue);
}


#pragma endregion DataInit


#pragma region AudioRecap


void UKGAkAudioManager::StartRecordAudioRecap()
{
	if (bIsRecording)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[StartRecordAudioRecap] in recording, cannot reentry"));
		return;
	}

	bIsRecording = true;
	AudioRecapHelper.OnRecordStart();
	AudioRecapHelper.RecordInitialParams(GroupStates, Rtpcs, GameObjectRtpcs, GameObjectSwitches);
}

void UKGAkAudioManager::StopRecordAudioRecap()
{
	if (!bIsRecording)
	{
		UE_LOG(LogAudioMgr, Warning, TEXT("[StartRecordAudioRecap] not in recording"));
		return;
	}

	bIsRecording = false;
	AudioRecapHelper.OnRecordStop();
}


#pragma endregion AudioRecap


#pragma region


const FString PlayerSlotSuffix_P1 = FString(TEXT("_1P"));
const FString PlayerSlotSuffix_P2 = FString(TEXT("_2P"));
const FString PlayerSlotSuffix_P3 = FString(TEXT(""));

FString UKGAkAudioManager::GetBattleFinalEventName(const FString& InEventName, bool bFromLocal, bool bHitLocal, bool bHasHit)
{
	FString FinalEventName = InEventName;
	FString PlayerSlotSuffix;

	// 首先区分有无命中
	if (!bHasHit)
	{
		if (bFromLocal)
		{
			// 我产生的是1P
			PlayerSlotSuffix = PlayerSlotSuffix_P1;
		}
		else
		{
			// 别人产生的是3P
			PlayerSlotSuffix = PlayerSlotSuffix_P3;
		}
	}
	else
	{
		if (bFromLocal)
		{
			// 我命中别人是1P
			PlayerSlotSuffix = PlayerSlotSuffix_P1;
		}
		else if (!bFromLocal && bHitLocal)
		{
			// 别人命中我是3P
			PlayerSlotSuffix = PlayerSlotSuffix_P3;
		}
		else if (!bFromLocal && !bHitLocal)
		{
			// 别人命中别人是2P
			PlayerSlotSuffix = PlayerSlotSuffix_P2;
		}
	}

	if (!BattleEventNameCache.Contains(InEventName))
	{
		BattleEventNameCache.Add(InEventName);
	}

	auto& SuffixCache = BattleEventNameCache[InEventName];
	if (!SuffixCache.Contains(PlayerSlotSuffix))
	{
		SuffixCache.Add(PlayerSlotSuffix, FinalEventName.Append(FString::Format(TEXT("{0}"), {PlayerSlotSuffix})));
	}

	FinalEventName = SuffixCache[PlayerSlotSuffix];
	return FinalEventName;
}

int32 UKGAkAudioManager::InnerPostEventForSkill(const FString& InEventName, KGActorID TargetActorID, bool bFromLocal, bool bHitLocal, bool bHasHit,
	bool bNeedAttach, float OffsetX, float OffsetY, float OffsetZ, bool bSetWorldLocation,
	bool bUseOriginPath, bool bStopWhenAttachedObjectDestroyed, bool bNeedDrawDebug)
{
	if (InEventName.IsEmpty())
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[InnerPostEventForSkill] event name empty, TargetActorID=%lld"), TargetActorID);
		return AK_INVALID_PLAYING_ID;
	}

	FString FinalEventName = bUseOriginPath ? InEventName : GetBattleFinalEventName(InEventName, bFromLocal, bHitLocal, bHasHit);
	if (FinalEventName.IsEmpty())
	{
		UE_LOG(LogAkAudio, Warning, TEXT("[InnerPostEventForSkill] event name empty after calculate, TargetActorID=%lld"), TargetActorID);
		return AK_INVALID_PLAYING_ID;
	}

	int32 PlayingID;

	if (bNeedAttach)
	{
		AActor* TargetActor = KGUtils::GetActorByID(TargetActorID);
		if (!TargetActor)
		{
			UE_LOG(LogAkAudio, Warning, TEXT("[InnerPostEventForSkill] target actor get failed, TargetActorID=%lld, EventName=%s"), TargetActorID, *FinalEventName);
			return AK_INVALID_PLAYING_ID;
		}

		UAkComponent* AkComponent = TargetActor->GetComponentByClass<UAkComponent>();
		if (!AkComponent)
		{
			UE_LOG(LogAkAudio, Log, TEXT("[InnerPostEventForSkill] dynamic add ak component, TargetID=%lld, EventName=%s"), TargetActorID, *FinalEventName);
			AkComponent = Cast<UAkComponent>(TargetActor->AddComponentByClass(UAkComponent::StaticClass(), false, FTransform::Identity, false));
		}

		if (!AkComponent)
		{
			UE_LOG(LogAkAudio, Warning, TEXT("[InnerPostEventForSkill] target ak component get failed, TargetID=%lld, EventName=%s"), TargetActorID, *FinalEventName);
			return AK_INVALID_PLAYING_ID;
		}

		PlayingID = InnerPostEventOnAkComp(FinalEventName, AkComponent, bStopWhenAttachedObjectDestroyed);
	}
	else
	{
		FVector EventPostLocation;
		if (bSetWorldLocation)
		{
			EventPostLocation.X = OffsetX;
			EventPostLocation.Y = OffsetY;
			EventPostLocation.Z = OffsetZ;
		}
		else
		{
			AActor* TargetActor = KGUtils::GetActorByID(TargetActorID);
			if (!TargetActor)
			{
				UE_LOG(LogAkAudio, Warning, TEXT("[InnerPostEventForSkill] target actor get failed, TargetActorID=%lld, EventName=%s"), TargetActorID, *FinalEventName);
				return AK_INVALID_PLAYING_ID;
			}

			float ForwardYaw = TargetActor->GetActorRotation().Yaw;
			FRotator ForwardRotator = FRotator(0, ForwardYaw, 0);
			EventPostLocation = TargetActor->GetActorLocation();
			EventPostLocation += ForwardRotator.RotateVector(FVector(OffsetX, OffsetY, OffsetZ));
		}

		if (bNeedDrawDebug)
		{
			UKismetSystemLibrary::DrawDebugPoint(this, EventPostLocation, 10, FLinearColor::Yellow, 3);
		}

		PlayingID = InnerPostEvent3D(FinalEventName, EventPostLocation.X, EventPostLocation.Y, EventPostLocation.Z);
	}

	if (PlayingID != AK_INVALID_PLAYING_ID)
	{
		float EventDuration = GetEventDuration(FinalEventName);
		AddBattleEventRecord(PlayingID, EventDuration);
	}

	return PlayingID;
}

void UKGAkAudioManager::InnerStopEventForSkill(int32 PlayingID, int32 FadeTime, EAkCurveInterpolation FadeCurve)
{
	if (PlayingID == AK_INVALID_PLAYING_ID)
	{
		return;
	}

	InnerStopEventByPlayingID(PlayingID, FadeTime, FadeCurve);
	DelBattleEventRecord(PlayingID);
}

#pragma endregion Battle

#pragma region Dialogue

FString UKGAkAudioManager::GetDialogueVoiceEventName(int32 DialogueID, int32 EpisodeID, int32 ContentIdx) const
{
	return FString::Printf(TEXT("Play_Vo_Dialogue_%d_%d_%d"), DialogueID, EpisodeID, ContentIdx);
}

#pragma endregion Dialogue

#pragma region GlobalParams

FString UKGAkAudioManager::WaterDepthRtpcName = TEXT("");
FString UKGAkAudioManager::VisibilityRtpcName = TEXT("");
float UKGAkAudioManager::VisibleRtpcValue = 0.f;
float UKGAkAudioManager::InvisibleRtpcValue = 0.f;

void UKGAkAudioManager::KAPI_AudioMgr_SetGlobalParams(const FString& InWaterDepthRtpcName, const FString& InVisibilityRtpcName, float InVisibleRtpcValue, float InInvisibleRtpcValue)
{
	WaterDepthRtpcName = InWaterDepthRtpcName;
	VisibilityRtpcName = InVisibilityRtpcName;
	VisibleRtpcValue = InVisibleRtpcValue;
	InvisibleRtpcValue = InInvisibleRtpcValue;
}

#pragma endregion GlobalParams

#pragma region Debug

FString UKGAkAudioManager::GetDebugInfo() const
{
	FString OutDebugInfo;
	
	OutDebugInfo.Appendf(TEXT("LruEventPool Size %d\n"), LruEventPool.Num());
	OutDebugInfo.Appendf(TEXT("StaticEventPool Size %d\n"), StaticEventPool.Num());
	OutDebugInfo.Appendf(TEXT("AmbientEventPool Size %d\n"), AmbientEventPool.Num());
	
	return OutDebugInfo;
}

#pragma endregion Debug
