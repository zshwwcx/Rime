#include "WorkProxy/WorkProxyManager.h"
#include "Components/BoxComponent.h"
#include "Components/SphereComponent.h"
#include "Components/CapsuleComponent.h"

#include "WorkProxy/WPModel.h"
#include "Curves/CurveFloat.h"
#include "lua.hpp"
#include "LuaState.h"
#include "Engine/World.h"
#include "Engine/Texture.h"


DEFINE_LOG_CATEGORY(LogWPMgr);



#pragma region Important
UWorkProxyManager* UWorkProxyManager::GetInstance(UObject* InContext)
{
	//return UKGBasicManager::GetManager<UWorkProxyManager>(InContext);
	return Cast<UWorkProxyManager>(GetManagerByType(InContext, EManagerType::EMT_WorkProxyManager));
}

void UWorkProxyManager::NativeInit()
{
	FWorldDelegates::OnWorldCleanup.AddUObject(this, &UWorkProxyManager::OnWorldCleanupEnd);

	Super::NativeInit();
}

void UWorkProxyManager::NativeUninit()
{
	CleanupManager();

	FWorldDelegates::OnWorldCleanup.RemoveAll(this);

	Super::NativeUninit();
}

void UWorkProxyManager::CleanupManager()
{
	ClearWorkProxy();

	CleanOperateStack();
}

void UWorkProxyManager::OnWorldCleanupEnd(UWorld* World, bool bSessionEnded, bool bCleanupResources)
{
	CleanupManager();
}

#pragma endregion Important



#pragma region Tick

void UWorkProxyManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_DuringPhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);
}

void UWorkProxyManager::Tick(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorkProxyManager_Tick");
	// 更新操作栈的有效性
	UpdateOperateStacks(DeltaTime);

	// 更新工作代理
	UpdateWorkProxys(DeltaTime);

	// 垃圾清理
	{
		GCTimer -= DeltaTime;
		if (GCTimer <= 0.0f)
		{
			CleanOperateStackTrash();
			CleanWorkProxyTrash();
			GCTimer = 10.0f;
		}
	}
}

#pragma endregion Tick



#pragma region OperateStack


int64 UWorkProxyManager::RequestCollisionOS_P(UPrimitiveComponent* InTarget)
{
	if (!IsValid(InTarget))
	{
		return 0;
	}

	if (int64* IDResult = OSIDSearchMap.Find(FOSSearchKey(InTarget, 100000)))
	{
		for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
		{
			if (UsingOperateStacks[i] && (UsingOperateStacks[i]->GetID() == (*IDResult)))
			{
				return *IDResult;
			}
		}
	}

	UCollisionOS* COS = RequestOperateStack<UCollisionOS>(InTarget, 100000);
	if (IsValid(COS))
	{
		FChangeCollisionMessage NewData;

		// 缓存初始碰撞盒大小
		NewData.bOverrideCollisionBoxSize = true;
		if (USphereComponent* TmpSphere = Cast<USphereComponent>(InTarget))
		{
			NewData.CollisionBoxSize.X = TmpSphere->GetUnscaledSphereRadius();
		}
		else if (UCapsuleComponent* TmpCapsule = Cast<UCapsuleComponent>(InTarget))
		{
			float X = NewData.CollisionBoxSize.X;
			float Y = NewData.CollisionBoxSize.Y;

			TmpCapsule->GetUnscaledCapsuleSize(X, Y);

			NewData.CollisionBoxSize.X = X;
			NewData.CollisionBoxSize.Y = Y;
		}
		else if (UBoxComponent* TmpBox = Cast<UBoxComponent>(InTarget))
		{
			NewData.CollisionBoxSize = TmpBox->GetUnscaledBoxExtent();
		}

		// 缓存各个碰撞通道的信息
		for (int32 j = 0; j < (uint8)ECollisionChannel::ECC_MAX; ++j)
		{
			ECollisionChannel TmpChannel = (ECollisionChannel)j;
			NewData.NewCollisionChannelInfos.Add(FCollisionChannelInfo(TmpChannel, InTarget->GetCollisionResponseToChannel(TmpChannel)));
		}

		// 缓存碰撞类型
		NewData.bNeedChangeObjectType = true;
		NewData.NewObjectType = UEngineTypes::ConvertToObjectType(InTarget->GetCollisionObjectType());

		// 缓存碰撞状态
		NewData.bNeedChangeCollisionState = true;
		NewData.NewCollisionState = InTarget->GetCollisionEnabled();

		// 初始化备忘录
		COS->InitOS<FChangeCollisionMessage>(NewData, NewData.StaticStruct(), InTarget, nullptr, NAME_None);

		return COS->GetID();
	}

	return 0;
}

int64 UWorkProxyManager::AddNewDataToCollisionOS(int64 InID, const FChangeCollisionMessage& InMessage, int32 InPriority)
{
	UCollisionOS* COS = nullptr;
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i] && (UsingOperateStacks[i]->GetID() == InID))
		{
			COS = Cast<UCollisionOS>(UsingOperateStacks[i]);
			break;
		}
	}

	if (!IsValid(COS) || !COS->CheckOSIsLegal())
	{
		return 0;
	}

	// 将数据塞入备忘录
	return COS->AddNewData<FChangeCollisionMessage>(InMessage, InMessage.StaticStruct(), InPriority);
}

void UWorkProxyManager::ReplaceDataToCollisionOS(int64 InID, int64 InEntryID, const FChangeCollisionMessage& InMessage)
{
	UCollisionOS* COS = nullptr;
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i] && (UsingOperateStacks[i]->GetID() == InID))
		{
			COS = Cast<UCollisionOS>(UsingOperateStacks[i]);
			break;
		}
	}

	if (!IsValid(COS) || !COS->CheckOSIsLegal())
	{
		return;
	}

	COS->ReplaceEntryData<FChangeCollisionMessage>(InMessage, InMessage.StaticStruct(), InEntryID);
}

int64 UWorkProxyManager::RequestComponentRelationOS_P(USceneComponent* InTarget)
{
	if (!IsValid(InTarget))
	{
		return 0;
	}

	if (int64* IDResult = OSIDSearchMap.Find(FOSSearchKey(InTarget, 100010)))
	{
		for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
		{
			if (UsingOperateStacks[i] && (UsingOperateStacks[i]->GetID() == (*IDResult)))
			{
				return *IDResult;
			}
		}
	}

	URelationOS* ROS = RequestOperateStack<URelationOS>(InTarget, 100010);
	if (IsValid(ROS))
	{
		FComponentRelativeMessage OriginData;

		// 缓存挂载者的名称
		OriginData.bNeedChangeParent = true;
		if (USceneComponent* ParentComp = InTarget->GetAttachParent())
		{
			OriginData.NewAttachParentName = FName(ParentComp->GetName());
		}
		else
		{
			OriginData.NewAttachParentName = NAME_None;
		}

		// 缓存挂载点名称
		OriginData.bNeedChangeSocket = true;
		OriginData.NewAttachSocketName = InTarget->GetAttachSocketName();

		// 缓存绝对性
		OriginData.bNeedChangeAbsolute = true;
		OriginData.NewAbsolute.X = InTarget->IsUsingAbsoluteLocation() ? 1.0f : -1.0f;
		OriginData.NewAbsolute.Y = InTarget->IsUsingAbsoluteRotation() ? 1.0f : -1.0f;
		OriginData.NewAbsolute.Z = InTarget->IsUsingAbsoluteScale() ? 1.0f : -1.0f;

		// 缓存相对位置
		OriginData.bNeedChangeRelativeLocation = true;
		OriginData.NewRelativeLocation = InTarget->GetRelativeLocation();

		// 缓存相对方向
		OriginData.bNeedChangeRelativeRotation = true;
		OriginData.NewRelativeRotation = InTarget->GetRelativeRotation();

		// 缓存相对大小
		OriginData.bNeedChangeRelativeScale = true;
		OriginData.NewRelativeScale = InTarget->GetRelativeScale3D();

		// 初始化备忘录
		ROS->InitOS<FComponentRelativeMessage>(OriginData, FComponentRelativeMessage::StaticStruct(), InTarget, nullptr, NAME_None);

		return ROS->GetID();
	}

	return 0;
}

int64 UWorkProxyManager::AddNewDataToComponentRelationOS(int64 InID, const FComponentRelativeMessage& InMessage, int32 InPriority)
{
	URelationOS* ROS = nullptr;
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i] && (UsingOperateStacks[i]->GetID() == InID))
		{
			ROS = Cast<URelationOS>(UsingOperateStacks[i]);
			break;
		}
	}

	if (!IsValid(ROS) || !ROS->CheckOSIsLegal())
	{
		return 0;
	}

	// 将数据塞入备忘录
	return ROS->AddNewData<FComponentRelativeMessage>(InMessage, InMessage.StaticStruct(), InPriority);
}

void UWorkProxyManager::ReplaceDataToComponentRelationOS(int64 InID, int64 InEntryID, const FComponentRelativeMessage& InMessage)
{
	URelationOS* ROS = nullptr;
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i] && (UsingOperateStacks[i]->GetID() == InID))
		{
			ROS = Cast<URelationOS>(UsingOperateStacks[i]);
			break;
		}
	}

	if (!IsValid(ROS) || !ROS->CheckOSIsLegal())
	{
		return;
	}

	ROS->ReplaceEntryData<FComponentRelativeMessage>(InMessage, InMessage.StaticStruct(), InEntryID);
}


int64 UWorkProxyManager::RequestModelRelationOS_A(AActor* InTarget)
{
	if (!IsValid(InTarget))
	{
		return 0;
	}

	if (int64* IDResult = OSIDSearchMap.Find(FOSSearchKey(InTarget, 100030)))
	{
		for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
		{
			if (UsingOperateStacks[i] && (UsingOperateStacks[i]->GetID() == (*IDResult)))
			{
				return *IDResult;
			}
		}
	}

	UModelOS* ROS = RequestOperateStack<UModelOS>(InTarget, 100030);
	if (IsValid(ROS))
	{
		FModelMessage OriginData;
		OriginData.NewRelativeScale = InTarget->GetActorScale3D();
		OriginData.NewRelativeLocationZ = InTarget->GetActorLocation().Z;
		// 初始化备忘录
		ROS->InitOS<FModelMessage>(OriginData, FModelMessage::StaticStruct(), InTarget, nullptr, NAME_None);

		return ROS->GetID();
	}
	return 0;
}


int64 UWorkProxyManager::AddNewDataToModelRelationOS(int64 InID, const FModelMessage& InMessage, int32 InPriority)
{
	UModelOS* ROS = nullptr;
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i] && (UsingOperateStacks[i]->GetID() == InID))
		{
			ROS = Cast<UModelOS>(UsingOperateStacks[i]);
			break;
		}
	}

	if (!IsValid(ROS) || !ROS->CheckOSIsLegal())
	{
		return 0;
	}

	// 将数据塞入备忘录
	return ROS->AddNewData<FModelMessage>(InMessage, InMessage.StaticStruct(), InPriority);
}

void UWorkProxyManager::ReplaceDataToModelRelationOS(int64 InID, int64 InEntryID, const FModelMessage& InMessage)
{
	UModelOS* ROS = nullptr;
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i] && (UsingOperateStacks[i]->GetID() == InID))
		{
			ROS = Cast<UModelOS>(UsingOperateStacks[i]);
			break;
		}
	}

	if (!IsValid(ROS) || !ROS->CheckOSIsLegal())
	{
		return;
	}

	ROS->ReplaceEntryData<FModelMessage>(InMessage, InMessage.StaticStruct(), InEntryID);
}

int64 UWorkProxyManager::GetOperateStackID_P(UObject* InTarget, int32 InSign)
{
	if (int64* IDResult = OSIDSearchMap.Find(FOSSearchKey(InTarget, InSign)))
	{
		return *IDResult;
	}

	return 0;
}

UOperateStack* UWorkProxyManager::GetOperateStack_P(UObject* InTarget, int32 InSign)
{
	if (int64* IDResult = OSIDSearchMap.Find(FOSSearchKey(InTarget, InSign)))
	{
		return GetOperateStackByID(*IDResult);
	}

	return nullptr;
}

UOperateStack* UWorkProxyManager::GetOperateStackByID(int64 InID)
{
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i] && UsingOperateStacks[i]->CheckOSIsLegal() && UsingOperateStacks[i]->GetID() == InID)
		{
			return UsingOperateStacks[i];
		}
	}

	return nullptr;
}

void UWorkProxyManager::RemoveDataFromOS_P(UObject* InTarget, int32 InSign, int64 InEntryID, bool bUpdateData)
{
	if (int64* IDResult = OSIDSearchMap.Find(FOSSearchKey(InTarget, InSign)))
	{
		RemoveDataFromOSByID(*IDResult, InEntryID, bUpdateData);
	}
}

void UWorkProxyManager::RemoveDataFromOSByID(int64 InID, int64 InEntryID, bool bUpdateData)
{
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i] && UsingOperateStacks[i]->GetID() == InID)
		{
			UsingOperateStacks[i]->RemoveOldData(InEntryID, bUpdateData);
		}
	}
}

void UWorkProxyManager::DestroyOperateStack_P(UObject* InTarget, const TArray<int32>& InSigns, bool InPopToBottom)
{
	TArray<int64> IDs;
	for (int32 i = 0; i < InSigns.Num(); ++i)
	{
		if (int64* IDResult = OSIDSearchMap.Find(FOSSearchKey(InTarget, InSigns[i])))
		{
			IDs.Add(*IDResult);
		}
	}

	DestroyOperateStackByID(IDs, InPopToBottom);
}

void UWorkProxyManager::DestroyOperateStackByID(const TArray<int64>& InIDs, bool InPopToBottom)
{
	for (int32 Loop = 0; Loop < InIDs.Num(); ++Loop)
	{
		int64 InID = InIDs[Loop];

		UOperateStack* CurOS = nullptr;

		for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
		{
			if (UsingOperateStacks[i] && UsingOperateStacks[i]->GetID() == InID)
			{
				CurOS = UsingOperateStacks[i];
				UsingOperateStacks.RemoveAtSwap(i);
				break;
			}
		}

		if (IsValid(CurOS))
		{
			UClass* OSType = CurOS->GetClass();
			if (IsValid(OSType))
			{
				if (FKGObjects* Pool = OperateStackPool.Find(OSType))
				{
					// 尝试塞入缓存池
					if (Pool->List.Num() < OSPoolSize)
					{
						CurOS->ClearAllData(InPopToBottom);
						CurOS->SetModifyTarget(nullptr);

						Pool->List.Add(CurOS);
					}
					else
					{
						CurOS->DestroyOS(InPopToBottom);
					}
				}
				else
				{
					CurOS->ClearAllData(InPopToBottom);
					CurOS->SetModifyTarget(nullptr);

					FKGObjects NewPool;
					NewPool.List.Add(CurOS);

					OperateStackPool.Add(CurOS->GetClass(), NewPool);
				}
			}
			else
			{
				CurOS->DestroyOS(InPopToBottom);
			}
		}

		for (TMap<FOSSearchKey, int64>::TIterator It(OSIDSearchMap); It; ++It)
		{
			if (It->Value == InID)
			{
				It.RemoveCurrent();
				break;
			}
		}
	}
}

void UWorkProxyManager::CleanOperateStack()
{
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i])
		{
			UsingOperateStacks[i]->DestroyOS();
		}
	}
	UsingOperateStacks.Empty();
	OSIDSearchMap.Empty();

	for (TMap<UClass*, FKGObjects>::TIterator It(OperateStackPool); It; ++It)
	{
		for (int32 i = 0; i < It->Value.List.Num(); ++i)
		{
			UOperateStack* CurOS = Cast<UOperateStack>(It->Value.List[i]);
			if (IsValid(CurOS))
			{
				CurOS->DestroyOS();
			}
		}
	}
	OperateStackPool.Empty();
}

void UWorkProxyManager::CleanOperateStackTrash()
{
	TArray<int64> IDs;

	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (!UsingOperateStacks[i]->CheckOSIsLegal())
		{
			IDs.Add(UsingOperateStacks[i]->GetID());
		}
	}

	DestroyOperateStackByID(IDs);
}

void UWorkProxyManager::UpdateOperateStacks(float InDeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorkProxyManager_UpdateOperateStacks");
	TArray<int64> WillDestroyOSIDs;
	for (int32 i = 0; i < UsingOperateStacks.Num(); ++i)
	{
		if (UsingOperateStacks[i])
		{
			// 非法操作栈 或 操作记录只剩下一条（即最原始的数据）
			if (!UsingOperateStacks[i]->CheckOSIsLegal() || UsingOperateStacks[i]->GetEntriesNum() <= 1)
			{
				WillDestroyOSIDs.Add(UsingOperateStacks[i]->GetID());
			}
		}
	}

	DestroyOperateStackByID(WillDestroyOSIDs);
}

#pragma endregion OperateStack



#pragma region WorkProxy
void UWorkProxyManager::WorkProxyDoWork(int64 InWPID, float InDeltaTime)
{
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			if (WP->WorkID == InWPID)
			{
				WP->DoWork(InDeltaTime);
				break;
			}
		}
	}
}

void UWorkProxyManager::WorkProxiesDoWork(const TArray<int64>& InWPIDs, float InDeltaTime)
{
	for (int32 i = 0; i < InWPIDs.Num(); ++i)
	{
		WorkProxyDoWork(InWPIDs[i], InDeltaTime);
	}
}

void UWorkProxyManager::CancelWorkProxy(int64 InWPID)
{
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			if (WP->WorkID == InWPID)
			{
				WP->bFinishedWork = true;
				break;
			}
		}
	}
}

void UWorkProxyManager::CancelWorkProxies(const TArray<int64>& InWPIDs)
{
	for (int32 i = 0; i < InWPIDs.Num(); ++i)
	{
		CancelWorkProxy(InWPIDs[i]);
	}
}

void UWorkProxyManager::ChangeWorkProxyTotalLife(int64 InWPID, float InTotalLife)
{
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			if (WP->WorkID == InWPID)
			{
				WP->TotalRunTime = InTotalLife;
				break;
			}
		}
	}
}

void UWorkProxyManager::ChangeWorkProxiesTotalLife(const TArray<int64>& InWPIDs, float TotalLife)
{
	for (int32 i = 0; i < InWPIDs.Num(); ++i)
	{
		ChangeWorkProxyTotalLife(InWPIDs[i], TotalLife);
	}
}

void UWorkProxyManager::ChangeWorkProxyCurrentLife(int64 InWPID, float InLife)
{
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			if (WP->WorkID == InWPID)
			{
				WP->RunningTime = InLife;
				break;
			}
		}
	}
}

void UWorkProxyManager::ChangeWorkProxiesCurrentLife(const TArray<int64>& InWPIDs, float InLife)
{
	for (int32 i = 0; i < InWPIDs.Num(); ++i)
	{
		ChangeWorkProxyCurrentLife(InWPIDs[i], InLife);
	}
}

void UWorkProxyManager::ChangeWorkProxyUpdateInterval(int64 InWPID, float InUpdateInterval)
{
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			if (WP->WorkID == InWPID)
			{
				WP->UpdateInterval = InUpdateInterval;

				break;
			}
		}
	}
}

void UWorkProxyManager::ChangeWorkProxiesUpdateInterval(const TArray<int64>& InWPIDs, float InUpdateInterval)
{
	for (int32 i = 0; i < InWPIDs.Num(); ++i)
	{
		ChangeWorkProxyUpdateInterval(InWPIDs[i], InUpdateInterval);
	}
}

void UWorkProxyManager::ChangeWorkProxyUpdateRate(int64 InWPID, float InUpdateRate)
{
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			if (WP->WorkID == InWPID)
			{
				WP->RunningRate = InUpdateRate;
				break;
			}
		}
	}
}

void UWorkProxyManager::ChangeWorkProxiesUpdateRate(const TArray<int64>& InWPIDs, float InUpdateRate)
{
	for (int32 i = 0; i < InWPIDs.Num(); ++i)
	{
		ChangeWorkProxyUpdateRate(InWPIDs[i], InUpdateRate);
	}
}

void UWorkProxyManager::ChangeWorkProxyDataReference(int64 InDataID, int32 InDelta)
{
	if (int32* Value = WorkProxyDataReferenceMap.Find(InDataID))
	{
		(*Value) = FMath::Max(0, (*Value) + InDelta);
	}
	else if (InDelta > 0)
	{
		WorkProxyDataReferenceMap.Add(InDataID, InDelta);
	}
}

void UWorkProxyManager::ScriptGetAllRunningWorkProxyID()
{
	using namespace NS_SLUA;
	lua_State* L = NS_SLUA::LuaState::get(LuaStateName)->getLuaState();
	if (!L)
	{
		return;
	}

	int32 NumParams = lua_gettop(L);
	if (NumParams != 2 || !(lua_istable(L, 2)))
	{
		return;
	}

	lua_pushvalue(L, 2);
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();
	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			lua_pushinteger(L, WP->WorkID);
			lua_pushboolean(L, true);
			lua_settable(L, -3);
		}
	}
	lua_pop(L, 1);

	int32 FinalNum = lua_gettop(L);
	if (NumParams != FinalNum)
	{
		UE_LOG(LogTemp, Warning, TEXT("[BSLOG] Lua Stack Unbalanced In ScriptGetAllRunningWorkProxyID !!!"));
	}
}

int64 UWorkProxyManager::RequestWPModelScale_P(FVector InScaleRate, AActor* InTarget, float InFadeInTime, UCurveFloat* InFadeInCurve, float InDuration, float InFadeOutTime, UCurveFloat* InFadeOutCurve, uint8 InPriority)
{
	if (FWPModelScale* WP = RegisterWorkProxy<FWPModelScale>())
	{
		WP->ScaleRate = InScaleRate;
		WP->FadeInTime = InFadeInTime;
		WP->Duration = InDuration;
		WP->FadeOutTime = InFadeOutTime;
		WP->FadeInCurve = InFadeInCurve;
		WP->FadeOutCurve = InFadeOutCurve;
		WP->Actor = InTarget;
		
		WP->Init(InPriority);
		WP->DoWork(0.0f);

		return WP->WorkID;
	}

	return 0;
}

void UWorkProxyManager::RequestWPModelScaleEnd(int64 InWPID)
{
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			if (WP->WorkID == InWPID)
			{
				WP->SetState(ETimeState::FadeOut);
				break;
			}
		}
	}
}

void UWorkProxyManager::WorkProxyScriptPushScalar(int64 InID, int32 InIndex, float InValue)
{
	if (TMap<int32, float>* FindResult = WorkProxyScriptScalars.Find(InID))
	{
		if (float* ValueResult = FindResult->Find(InIndex))
		{
			(*ValueResult) = InValue;
		}
		else
		{
			FindResult->Add(InIndex, InValue);
		}
	}
	else
	{
		WorkProxyScriptScalars.Add(InID);
		if (TMap<int32, float>* NewResult = WorkProxyScriptScalars.Find(InID))
		{
			NewResult->Add(InIndex, InValue);
		}
	}
}

void UWorkProxyManager::WorkProxyScriptPushVector(int64 InID, int32 InIndex, float X, float Y, float Z, float W)
{
	if (TMap<int32, FVector4>* FindResult = WorkProxyScriptVectors.Find(InID))
	{
		if (FVector4* ValueResult = FindResult->Find(InIndex))
		{
			ValueResult->X = X;
			ValueResult->Y = Y;
			ValueResult->Z = Z;
			ValueResult->W = W;
		}
		else
		{
			FindResult->Add(InIndex, FVector4(X, Y, Z, W));
		}
	}
	else
	{
		WorkProxyScriptVectors.Add(InID);
		if (TMap<int32, FVector4>* NewResult = WorkProxyScriptVectors.Find(InID))
		{
			NewResult->Add(InIndex, FVector4(X, Y, Z, W));
		}
	}
}

void UWorkProxyManager::CancelWorkProxyScriptData(int64 InID)
{
	WorkProxyScriptScalars.Remove(InID);
	WorkProxyScriptVectors.Remove(InID);
}


void UWorkProxyManager::UpdateWorkProxys(float InDeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UWorkProxyManager_UpdateWorkProxys");
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	// 更新所有的工作代理
	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			if (!WP->bFinishedWork)
			{
				WP->Update(InDeltaTime);
			}

			if (WP->bFinishedWork)
			{
				WP->FinishWork();
				WP = nullptr;
				RunningProxys[i].Reset();
			}
		}
	}
}

void UWorkProxyManager::ClearWorkProxy()
{
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	for (int32 i = 0; i < RunningProxys.Num(); ++i)
	{
		if (!RunningProxys[i].IsValid() || !RunningProxys[i].GetStruct()->IsChildOf(WPSS))
		{
			continue;
		}

		if (FWorkProxy* WP = (FWorkProxy*)RunningProxys[i].GetStructMemory())
		{
			WP->FinishWork();
		}
	}

	RunningProxys.Empty();

	CleanWorkProxyTrash();
}

void UWorkProxyManager::CleanWorkProxyTrash()
{
	UScriptStruct* WPSS = FWorkProxy::StaticStruct();

	// 删除所有的无效工作代理
	RunningProxys.RemoveAll
	(
		[&](const FStructOnScope& InVal)
		{
			if (!InVal.IsValid() || !InVal.GetStruct()->IsChildOf(WPSS))
			{
				return true;
			}

			if (FWorkProxy* WP = (FWorkProxy*)InVal.GetStructMemory())
			{
				return !WP->bIsValid;
			}

			return false;
		}
	);

	// 移除没有继续引用的缓存数据
	for (TMap<int64, int32>::TIterator It(WorkProxyDataReferenceMap); It; ++It)
	{
		if (It->Value <= 0)
		{
			WorkProxyDataMap.Remove(It->Key);
			It.RemoveCurrent();
		}
	}
}


bool UWorkProxyManager::GetScriptScalar(int64 InPushID, int32 InIndex, float& OutValue)
{
	if (TMap<int32, float>* Result = WorkProxyScriptScalars.Find(InPushID))
	{
		if (float* Value = Result->Find(InIndex))
		{
			OutValue = *Value;

			return true;
		}
	}

	return false;
}

bool UWorkProxyManager::GetScriptVector(int64 InPushID, int32 InIndex, FVector4& OutValue)
{
	if (TMap<int32, FVector4>* Result = WorkProxyScriptVectors.Find(InPushID))
	{
		if (FVector4* Value = Result->Find(InIndex))
		{
			OutValue.X = Value->X;
			OutValue.Y = Value->Y;
			OutValue.Z = Value->Z;
			OutValue.W = Value->W;

			return true;
		}
	}

	return false;
}

#pragma endregion WorkProxy
