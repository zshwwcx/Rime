#include "WorkProxy/WPModel.h"

#include "Curves/CurveFloat.h"
#include "WorkProxy/WorkProxyManager.h"

void FWPModelScale::Init(int64 InPriority)
{
	if (!WPMgr.IsValid() || !Actor.IsValid())
	{
		bFinishedWork = true;
		return;
	}
	FWorkProxy::Init(InPriority);
	// 运行数据初始化
	bIsValid = true;
	bFinishedWork = false;
	LastRunningTime = 0.0f;
	RunningTime = 0.0f;
	
	TotalRunTime = FadeInTime + Duration + FadeOutTime;
	ROSID = WPMgr->RequestModelRelationOS_A(Actor.Get());
	if (URelationOS* ROS = WPMgr->GetOperateStack<URelationOS>(ROSID))
	{
		if (FModelMessage* OriginEntry = ROS->GetEntryByIndex<FModelMessage>(0))
		{
			OriginScale = OriginEntry->NewRelativeScale;
		}
	}
	CRM.NewRelativeScale = Actor->GetActorScale3D();
	CRM.NewRelativeLocationZ = Actor->GetActorLocation().Z;
	ROSEntryID = WPMgr->AddNewDataToModelRelationOS(ROSID, CRM, InPriority);
	
	Capsule = Actor->GetComponentByClass<UCapsuleComponent>();
	State = ETimeState::FadeIn;
	StateDuration = 0.0f;
	if (FadeInCurve.IsValid())
	{
		SetCurveNormal(FadeInCurve.Get(), FadeInCurveNormal);
	}
	if (FadeOutCurve.IsValid())
	{
		SetCurveNormal(FadeOutCurve.Get(), FadeOutCurveNormal);
	}
}

void FWPModelScale::DoWork(float InDeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("FWPModelScale_DoWork");
	FWorkProxy::DoWork(InDeltaTime);

	if (!WPMgr.IsValid() || !Actor.IsValid())
	{
		bFinishedWork = true;
		return;
	}
	FVector TargetRelativeScale = OriginScale;
	float Alpha = 1.0f;
	if (State == ETimeState::FadeIn)
	{
		Alpha = FMath::Min(FadeInTime > 0 ? StateDuration / FadeInTime : 1,1);
		Alpha = FadeInCurve.IsValid() && FadeInTime > 0? GetCurveNormalValue(FadeInCurve.Get(), FadeInCurveNormal, Alpha) : Alpha;
		TargetRelativeScale = FMath::Lerp(OriginScale, ScaleRate, Alpha);
	}
	else if (State == ETimeState::Duration)
	{
		TargetRelativeScale = ScaleRate;
	}
	else if (State == ETimeState::FadeOut)
	{
		Alpha = FMath::Max(FadeOutTime > 0 ? 1 - StateDuration / FadeOutTime : 0,0);
		Alpha = FadeOutCurve.IsValid() && FadeOutTime > 0? GetCurveNormalValue(FadeOutCurve.Get(), FadeOutCurveNormal, 1 - Alpha) : Alpha;
		TargetRelativeScale = FMath::Lerp(OriginScale, ScaleRate, Alpha);
	}
	CRM.NewRelativeScale = TargetRelativeScale;
	if (Capsule.IsValid())
	{
		FVector CurLocation = Actor->GetActorLocation();
		FVector CurScale3D = Actor->GetActorScale3D();
		float deltaZ = TargetRelativeScale.Z - CurScale3D.Z;
		float halfHeight = Capsule->GetUnscaledCapsuleHalfHeight();
		CRM.NewRelativeLocationZ = CurLocation.Z + halfHeight * deltaZ;
	}

	WPMgr->ReplaceDataToModelRelationOS(ROSID, ROSEntryID, CRM);

	StateDuration += InDeltaTime;
	if (State == ETimeState::FadeIn)
	{
		if (StateDuration > FadeInTime)
		{
			State = ETimeState::Duration;
			StateDuration = 0.0f;
		}
	}
	else if (State == ETimeState::Duration)
	{
		if (StateDuration > Duration)
		{
			State = ETimeState::FadeOut;
			StateDuration = 0.0f;
		}
	}
	else
	{
		if (StateDuration > FadeOutTime)
		{
			bFinishedWork = true;
		}
	}
}

void FWPModelScale::FinishWork()
{
	if (WPMgr.IsValid())
	{
		WPMgr->RemoveDataFromOSByID(ROSID, ROSEntryID);
	}
	ScaleRate = FVector::OneVector;
	FadeInTime = 0.0f;
	Duration = 0.0f;
	FadeOutTime = 0.0f;
	FadeInCurve.Reset();
	FadeOutCurve.Reset();
	ROSID = 0;
	ROSEntryID = 0;
	Actor.Reset();
	Capsule.Reset();
	FWorkProxy::FinishWork();
}

void FWPModelScale::SetCurveNormal(UCurveFloat* Curve, FCurveNormalParams& OutCurveNormal)
{
	Curve->GetTimeRange(OutCurveNormal.MinTime,OutCurveNormal.MaxTime);
	Curve->GetValueRange(OutCurveNormal.MinValue,OutCurveNormal.MaxValue);
}

float FWPModelScale::GetCurveNormalValue(const UCurveFloat* Curve, const FCurveNormalParams CurveNormalParams, float Pct)
{
	float MinTime = CurveNormalParams.MinTime, MaxTime = CurveNormalParams.MaxTime;
	float MinValue = CurveNormalParams.MinValue, MaxValue = CurveNormalParams.MaxValue;
	if(MaxValue - MinValue == 0 || MaxTime - MinTime == 0)
	{
		return 1;
	}
	const float CurveValue = Curve->GetFloatValue(Pct * (MaxTime - MinTime) + MinTime);
	return (CurveValue - MinValue) / (MaxValue - MinValue);
}

void FWPModelScale::SetState(ETimeState InState)
{
	if (State == InState)
	{
		return;
	}
	State = InState;
	// 保存当前打断时的缩放尺度,防止没渐入结束就打断产生的缩放不正确
	if (State == ETimeState::FadeOut && Actor.IsValid())
	{
		StateDuration = 0.0f;
		ScaleRate = Actor->GetActorScale3D();
	}
}
