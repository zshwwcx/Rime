#include "WorkProxy/WorkProxy.h"

#include "Misc/LowLevelFunctions.h"

#include "WorkProxy/WorkProxyManager.h"



FWorkProxy::FWorkProxy()
{

}

FWorkProxy::~FWorkProxy()
{

}

void FWorkProxy::Init(int64 InDataID)
{
	if (WorkID <= 0)
	{
		WorkID = ULowLevelFunctions::GetGlobalUniqueID();
	}

	StaticDataID = InDataID;
	if (WPMgr.IsValid())
	{
		WPMgr->ChangeWorkProxyDataReference(StaticDataID, 1);

		if (const FWorkProxyData* SData = WPMgr->GetWorkProxyDataByID<FWorkProxyData>(StaticDataID))
		{
			TotalRunTime = SData->TotalLife;
		}
	}

	// 运行数据初始化
	bIsValid = true;
	bFinishedWork = false;
	LastRunningTime = 0.0f;
	RunningTime = 0.0f;
}

void FWorkProxy::Update(float InDeltaTime)
{
	if (bFinishedWork)
	{
		return;
	}

	RunningTime += InDeltaTime * RunningRate;

	float TotalDelta = RunningTime - LastRunningTime;
	if (TotalDelta > UpdateInterval)
	{
		DoWork(TotalDelta);
	}

	// 超过运行时长，设置为非激活状态
	if (TotalRunTime > 0.0f && RunningTime > TotalRunTime)
	{
		bFinishedWork = true;
	}
}

void FWorkProxy::DoWork(float InDeltaTime)
{
	LastRunningTime = RunningTime;
}

void FWorkProxy::FinishWork()
{
	if (WPMgr.IsValid())
	{
		WPMgr->ChangeWorkProxyDataReference(StaticDataID, -1);
	}
	StaticDataID = 0;

	bIsValid = false;
	LastRunningTime = 0.0f;
	RunningTime = 0.0f;
}
