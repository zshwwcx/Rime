#include "WorkProxy/OperateStack.h"
#include "HAL/LowLevelMemStats.h"

#include "Components/ShapeComponent.h"
#include "Components/BoxComponent.h"
#include "Components/SphereComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/PrimitiveComponent.h"

#include "Misc/KGLLM.h"
#include "Misc/LowLevelFunctions.h"



#pragma region Base
UOperateStack::UOperateStack(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	LLM_SCOPE_KG(ELLMTagKG::BSOSData);

	if (!HasAnyFlags(RF_ClassDefaultObject))
	{
		INC_DWORD_STAT(STAT_OSNum);

		UpdateFuncParm = (uint64*)FMemory::Malloc(16);

		ID = ULowLevelFunctions::GetGlobalUniqueID();
	}
}

UOperateStack::~UOperateStack()
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{
		DEC_DWORD_STAT(STAT_OSNum);
	}

	DataAddresses.Empty();

	// 清理所有申请并未释放的内存
	for (int32 i = 0; i < AllMallocAddress.Num(); ++i)
	{
		DEC_DWORD_STAT(STAT_OSDataNum);
		FMemory::Free(AllMallocAddress[i]);

		AllMallocAddress[i] = nullptr;
	}
	AllMallocAddress.Empty();

	FMemory::Free(UpdateFuncParm);
	UpdateFuncParm = nullptr;
}

void UOperateStack::DestroyOS(bool InPopToBottom)
{
	ClearAllData(InPopToBottom);
	ModifyTarget = nullptr;

	if (IsRooted())
	{
		RemoveFromRoot();
	}

	MarkAsGarbage();
}

void UOperateStack::PopToBottom()
{
	if (DataAddresses.Num() > 0)
	{
		for (int32 i = 1; i < DataAddresses.Num(); ++i)
		{
			DataAddresses[i].UniqueID = 0;
		}
		// 清除无效数据
		DataAddresses.RemoveAll
		(
			[&](OSData& Val)
			{
				if (Val.UniqueID <= 0)
				{
					SetDataAddressToPool(Val.DataAddress);

					Val.DataAddress = nullptr;
					return true;
				}
				return false;
			}
		);

		UpdateTargetByLatestData();
	}
}

void UOperateStack::ClearAllData(bool InPopToBottom)
{
	if (InPopToBottom)
	{
		PopToBottom();
	}

	if (DataAddresses.Num() > 0)
	{
		SetDataAddressToPool(DataAddresses[0].DataAddress);
	}
	DataAddresses.Empty();
}

void UOperateStack::RemoveOldData(int64 InID, bool bUpdateData)
{
	if (!CheckOSIsLegal())
		return;

	// 根据修改者清除记录，栈底不会被删除！！
	for (int32 i = 1; i < DataAddresses.Num(); ++i)
	{
		if (DataAddresses[i].UniqueID == InID)
		{
			DataAddresses[i].UniqueID = 0;
		}
	}
	// 清除无效数据
	DataAddresses.RemoveAll
	(
		[&](OSData& Val)
		{
			if (Val.UniqueID <= 0)
			{
				SetDataAddressToPool(Val.DataAddress);

				Val.DataAddress = nullptr;
				return true;
			}
			return false;
		}
	);

	if (bUpdateData)
	{
		UpdateTargetByLatestData();
	}
}

int64 UOperateStack::GetID()
{
	return ID;
}

bool UOperateStack::CheckOSIsLegal()
{
	return ModifyTarget.IsValid();
}

void UOperateStack::InternalInitOS(const void* InOriginDataAddress, UScriptStruct* InStructType, UObject* InModifyTarget, UObject* InFunctionOwner, FName InFunctionName)
{
	if (!InOriginDataAddress || !InModifyTarget)
		return;

	StructType = InStructType;

	if (InFunctionOwner)
	{
		FunctionOwner = InFunctionOwner;
		TheFunction = FunctionOwner->FindFunction(InFunctionName);
	}
	
	ModifyTarget = InModifyTarget;

	ClearAllData();

	// 将初始数据塞入栈底
	InternalAddNewData(InOriginDataAddress, StructType, 0);
}

int64 UOperateStack::InternalAddNewData(const void* InDataAddress, UScriptStruct* InStructType, int32 Priority)
{
	if (!InDataAddress || !CheckOSIsLegal() || StructType != InStructType)
		return 0;

	// 数组保持单调递减，记录起始下标
	int32 StartRefreshIndex = 0;
	for (int32 i = DataAddresses.Num() - 1; i >= 0; --i)
	{
		if (DataAddresses[i].Priority <= (uint32)Priority)
		{
			StartRefreshIndex = i + 1;
			break;
		}
	}

	int64 NewUniqueID = ULowLevelFunctions::GetGlobalUniqueID();

	// 拷贝数据，并将其塞入栈中
	if (StructType)
	{
		void* NewData = GetDataAddressFromPool();
		StructType->InitializeStruct(NewData);
		StructType->CopyScriptStruct(NewData, InDataAddress);
		DataAddresses.EmplaceAt(StartRefreshIndex, OSData(NewUniqueID, NewData, Priority));
	}
	else
	{
		OSData NewData;
		NewData.UniqueID = NewUniqueID;
		NewData.DataAddress = nullptr;
		NewData.Priority = Priority;
		FMemory::Memcpy(&NewData.SmallData, InDataAddress, 8);
		DataAddresses.EmplaceAt(StartRefreshIndex, NewData);
	}

	UpdateTargetByLatestData();

	return NewUniqueID;
}

void UOperateStack::InternalReplaceEntryData(const void* InDataAddress, UScriptStruct* InStructType, int64 InID)
{
	if (!InDataAddress || !CheckOSIsLegal() || StructType != InStructType)
		return;

	bool Flag = false;
	// 找到对应修改者的修改条目
	for (int32 i = DataAddresses.Num() - 1; i >= 0; --i)
	{
		if (DataAddresses[i].UniqueID == InID)
		{
			if (StructType)
			{
				StructType->InitializeStruct(DataAddresses[i].DataAddress);
				StructType->CopyScriptStruct(DataAddresses[i].DataAddress, InDataAddress);
			}
			else
			{
				FMemory::Memcpy(&DataAddresses[i].SmallData, InDataAddress, 8);
			}

			Flag = true;
			break;
		}
	}

	if (Flag)
	{
		UpdateTargetByLatestData();
	}
}

void UOperateStack::UpdateTargetByLatestData()
{
	if (DataAddresses.Num() > 0 && TheFunction && CheckOSIsLegal())
	{
		if (DataAddresses.Last().DataAddress == nullptr)
		{
			*UpdateFuncParm = (uint64)(&DataAddresses.Last().SmallData);
		}
		else
		{
			*UpdateFuncParm = (uint64)(DataAddresses.Last().DataAddress);
		}
		*(UpdateFuncParm + 1) = (uint64)(ModifyTarget.Get());

		FunctionOwner->ProcessEvent(TheFunction, UpdateFuncParm);
	}

	return;
}

void* UOperateStack::GetDataAddressFromPool()
{
	LLM_SCOPE_KG(ELLMTagKG::BSOSData);

	INC_DWORD_STAT(STAT_OSDataNum);
	void* NewAddress = FMemory::Malloc(StructType ? StructType->GetStructureSize() : 8);
	AllMallocAddress.Add(NewAddress);

	return NewAddress;
}

void UOperateStack::SetDataAddressToPool(void* TheAddress)
{
	LLM_SCOPE(TEXT("BSOSData"));

	if (TheAddress == nullptr)
	{
		return;
	}
	
	DEC_DWORD_STAT(STAT_OSDataNum);
	AllMallocAddress.Remove(TheAddress);
	FMemory::Free(TheAddress);
}

USceneComponent* UOperateStack::GetComponentByNameAndClass(AActor* InActor, const FString& InName, UClass* InClass)
{
	if (!InActor)
	{
		return nullptr;
	}

	FName Name(InName);

	if (FProperty* Prop = InActor->GetClass()->FindPropertyByName(Name))
	{
		if (UObject* ObjectValue = CastField<FObjectProperty>(Prop)->GetObjectPropertyValue_InContainer(InActor))
		{
			USceneComponent* Component = Cast<USceneComponent>(ObjectValue);
			if (Component && (!InClass || Component->GetClass()->IsChildOf(InClass)))
			{
				return Component;
			}
		}
	}

	TArray<USceneComponent*> AllSceneComps;
	InActor->GetComponents<USceneComponent>(AllSceneComps);
	for (int32 i = 0; i < AllSceneComps.Num(); ++i)
	{
		USceneComponent* Component = AllSceneComps[i];
		if (Component && (Component->GetFName().IsEqual(Name) || Component->ComponentHasTag(Name)) && (!InClass || Component->GetClass()->IsChildOf(InClass)))
		{
			return Component;
		}
	}

	return nullptr;
}

#pragma endregion Base


#pragma region Collision
void UCollisionOS::UpdateTargetByLatestData()
{
	UPrimitiveComponent* TargetComp = Cast<UPrimitiveComponent>(ModifyTarget);
	if (DataAddresses.Num() <= 0 || !CheckOSIsLegal() || !TargetComp)
	{
		return;
	}


	// 更新各个碰撞通道
	TEnumAsByte<EObjectTypeQuery> FinalObjectType;
	ECollisionEnabled::Type FinalCollisionState = ECollisionEnabled::Type::QueryOnly;
	TMap<ECollisionChannel, ECollisionResponse> FinalResponse;
	for (int32 i = 0; i < DataAddresses.Num(); ++i)
	{
		FChangeCollisionMessage* CurData = (FChangeCollisionMessage*)DataAddresses[i].DataAddress;

		if (CurData->bNeedChangeObjectType)
		{
			FinalObjectType = CurData->NewObjectType;
		}

		if (CurData->bNeedChangeCollisionState)
		{
			FinalCollisionState = CurData->NewCollisionState;
		}

		for (int32 j = 0; j < CurData->NewCollisionChannelInfos.Num(); ++j)
		{
			if (ECollisionResponse* FindResult = FinalResponse.Find(CurData->NewCollisionChannelInfos[j].NewCollisionChannel))
			{
				(*FindResult) = CurData->NewCollisionChannelInfos[j].NewCollisionResponse;
			}
			else
			{
				FinalResponse.Add(CurData->NewCollisionChannelInfos[j].NewCollisionChannel, CurData->NewCollisionChannelInfos[j].NewCollisionResponse);
			}
		}
	}
	for (TMap<ECollisionChannel, ECollisionResponse>::TIterator It(FinalResponse); It; ++It)
	{
		if (TargetComp->GetCollisionResponseToChannel(It->Key) != It->Value)
		{
			TargetComp->SetCollisionResponseToChannel(It->Key, It->Value);
		}
	}

	FChangeCollisionMessage* FirstData = (FChangeCollisionMessage*)DataAddresses[0].DataAddress;
	FChangeCollisionMessage* LatestData = (FChangeCollisionMessage*)DataAddresses.Last().DataAddress;


	// 更新碰撞盒的大小
	FVector NewSize = FirstData->CollisionBoxSize;
	if (LatestData->bOverrideCollisionBoxSize)
	{
		NewSize = LatestData->CollisionBoxSize;
	}
	else
	{
		NewSize *= LatestData->CollisionBoxSize;
	}


	if (USphereComponent* TmpSphere = Cast<USphereComponent>(TargetComp))
	{
		TmpSphere->SetSphereRadius(NewSize.X);
	}
	else if (UCapsuleComponent* TmpCapsule = Cast<UCapsuleComponent>(TargetComp))
	{
		TmpCapsule->SetCapsuleSize(NewSize.X, NewSize.Y);
	}
	else if (UBoxComponent* TmpBox = Cast<UBoxComponent>(TargetComp))
	{
		TmpBox->SetBoxExtent(NewSize);
	}


	// 更新碰撞类型
	TargetComp->SetCollisionObjectType(UEngineTypes::ConvertToCollisionChannel(FinalObjectType));


	// 更新碰撞状态
	TargetComp->SetCollisionEnabled(FinalCollisionState);
}

#pragma endregion Collision






#pragma region Relation
void URelationOS::UpdateTargetByLatestData()
{
	USceneComponent* TargetComp = Cast<USceneComponent>(ModifyTarget);
	if (DataAddresses.Num() <= 0 || !CheckOSIsLegal() || !TargetComp)
	{
		return;
	}

	FComponentRelativeMessage* OldestMsg = (FComponentRelativeMessage*)DataAddresses[0].DataAddress;
	FComponentRelativeMessage* NewestMsg = (FComponentRelativeMessage*)DataAddresses.Last().DataAddress;

	// 找到挂载的组件
	USceneComponent* CurParentComp = GetComponentByNameAndClass(TargetComp->GetOwner(), NewestMsg->bNeedChangeParent ? NewestMsg->NewAttachParentName.ToString() : OldestMsg->NewAttachParentName.ToString());
	if (!CurParentComp)
	{
		CurParentComp = TargetComp->GetOwner()->GetRootComponent();
	}

	// 进行挂载
	TargetComp->AttachToComponent(CurParentComp, FAttachmentTransformRules::KeepWorldTransform, NewestMsg->bNeedChangeSocket ? NewestMsg->NewAttachSocketName : OldestMsg->NewAttachSocketName);

	// 调整绝对性设置
	if (NewestMsg->bNeedChangeAbsolute)
	{
		TargetComp->SetAbsolute(NewestMsg->NewAbsolute.X > 0.0f, NewestMsg->NewAbsolute.Y > 0.0f, NewestMsg->NewAbsolute.Z > 0.0f);
	}
	else
	{
		TargetComp->SetAbsolute(OldestMsg->NewAbsolute.X > 0.0f, OldestMsg->NewAbsolute.Y > 0.0f, OldestMsg->NewAbsolute.Z > 0.0f);
	}

	// 调整相对位置
	TargetComp->SetRelativeLocation(NewestMsg->bNeedChangeRelativeLocation ? NewestMsg->NewRelativeLocation : OldestMsg->NewRelativeLocation);

	// 调整相对方向
	TargetComp->SetRelativeRotation(NewestMsg->bNeedChangeRelativeRotation ? NewestMsg->NewRelativeRotation : OldestMsg->NewRelativeRotation);

	// 调整相对大小
	TargetComp->SetRelativeScale3D(NewestMsg->bNeedChangeRelativeScale ? NewestMsg->NewRelativeScale : OldestMsg->NewRelativeScale);
}

#pragma endregion Relation



#pragma region Model
void UModelOS::UpdateTargetByLatestData()
{
	AActor* Target = Cast<AActor>(ModifyTarget);
	if (DataAddresses.Num() <= 0 || !CheckOSIsLegal() || !IsValid(Target))
	{
		return;
	}

	//FModelMessage* OldestMsg = (FModelMessage*)DataAddresses[0].DataAddress;
	FModelMessage* NewestMsg = (FModelMessage*)DataAddresses.Last().DataAddress;
	FVector CurLocation = Target->GetActorLocation();
	CurLocation.Z = NewestMsg->NewRelativeLocationZ;
	Target->SetActorLocation(CurLocation);
	Target->SetActorScale3D(NewestMsg->NewRelativeScale);
}

#pragma endregion Model