// Fill out your copyright notice in the Description page of Project Settings.


#include "Scene/Components/C7ShapeCollisionComponent.h"
#include "CollisionShape.h"
#include "PhysicsEngine/BodySetup.h"
#include "PrimitiveViewRelevance.h"
#include "PrimitiveSceneProxy.h"
#include "PhysicsEngine/SphereElem.h"
#include "SceneManagement.h"
#include "Misc/KGGameInstanceBase.h"
#include "Engine.h"

UC7ShapeCollisionComponent::UC7ShapeCollisionComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

	SphereRadius = 32.0f;
	ShapeColor = FColor(255, 0, 0, 255);

	LineThickness = 5.0f;
	BoxExtent = FVector(32.0f, 32.0f, 32.0f);
	
	bUseEditorCompositing = true;

	bCanEverAffectNavigation = false;
}

FBoxSphereBounds UC7ShapeCollisionComponent::CalcBounds(const FTransform& LocalToWorld) const
{
	return ShapeType == EC7ShapeCollisionType::Box ?
		FBoxSphereBounds( FBox( -BoxExtent, BoxExtent ) ).TransformBy(LocalToWorld) :
	FBoxSphereBounds( FVector::ZeroVector, FVector(SphereRadius), SphereRadius ).TransformBy(LocalToWorld);
}

void UC7ShapeCollisionComponent::CalcBoundingCylinder(float& CylinderRadius, float& CylinderHalfHeight) const
{
	CylinderRadius = SphereRadius * GetComponentTransform().GetMaximumAxisScale();
	CylinderHalfHeight = CylinderRadius;
}

template <EShapeBodySetupHelper UpdateBodySetupAction, typename BodySetupType>
bool InvalidateOrUpdateBoxBodySetup(BodySetupType& ShapeBodySetup, bool bUseArchetypeBodySetup, FVector BoxExtent)
{
	check((bUseArchetypeBodySetup && UpdateBodySetupAction == EShapeBodySetupHelper::InvalidateSharingIfStale) || (!bUseArchetypeBodySetup && UpdateBodySetupAction == EShapeBodySetupHelper::UpdateBodySetup));
	check(ShapeBodySetup->AggGeom.BoxElems.Num() == 1);
	FKBoxElem* se = ShapeBodySetup->AggGeom.BoxElems.GetData();

	// @todo do we allow this now?
	// check for malformed values
	if (BoxExtent.X < UE_KINDA_SMALL_NUMBER)
	{
		BoxExtent.X = 1.0f;
	}

	if (BoxExtent.Y < UE_KINDA_SMALL_NUMBER)
	{
		BoxExtent.Y = 1.0f;
	}

	if (BoxExtent.Z < UE_KINDA_SMALL_NUMBER)
	{
		BoxExtent.Z = 1.0f;
	}

	float XExtent = BoxExtent.X * 2.f;
	float YExtent = BoxExtent.Y * 2.f;
	float ZExtent = BoxExtent.Z * 2.f;

	if (UpdateBodySetupAction == EShapeBodySetupHelper::UpdateBodySetup)
	{
		// now set the PhysX data values
		se->SetTransform(FTransform::Identity);
		se->X = XExtent;
		se->Y = YExtent;
		se->Z = ZExtent;
	}
	else if(se->X != XExtent || se->Y != YExtent || se->Z != ZExtent)
	{
		ShapeBodySetup = nullptr;
		bUseArchetypeBodySetup = false;
	}

	return bUseArchetypeBodySetup;
}

template <EShapeBodySetupHelper UpdateBodySetupAction, typename BodySetupType>
bool InvalidateOrUpdateSphereBodySetup(BodySetupType& ShapeBodySetup, bool bUseArchetypeBodySetup, float SphereRadius)
{
	check((bUseArchetypeBodySetup && UpdateBodySetupAction == EShapeBodySetupHelper::InvalidateSharingIfStale) || (!bUseArchetypeBodySetup && UpdateBodySetupAction == EShapeBodySetupHelper::UpdateBodySetup) );
	check(ShapeBodySetup->AggGeom.SphereElems.Num() == 1);
	FKSphereElem* SphereElem = ShapeBodySetup->AggGeom.SphereElems.GetData();

	// check for mal formed values
	float Radius = SphereRadius;
	if (Radius < UE_KINDA_SMALL_NUMBER)
	{
		Radius = 0.1f;
	}

	if(UpdateBodySetupAction == EShapeBodySetupHelper::UpdateBodySetup)
	{
		// now set the PhysX data values
		SphereElem->Center = FVector::ZeroVector;
		SphereElem->Radius = Radius;
	}
	else
	{
		if(SphereElem->Radius != Radius)
		{
			ShapeBodySetup = nullptr;
			bUseArchetypeBodySetup = false;
		}
	}
	
	return bUseArchetypeBodySetup;
}

void UC7ShapeCollisionComponent::UpdateBodySetup()
{

	if (ShapeType == EC7ShapeCollisionType::Box)
	{
		if (!ShapeBodySetup || ShapeBodySetup->AggGeom.BoxElems.IsEmpty())
		{
			ShapeBodySetup = nullptr;
			CreateShapeBodySetupIfNeeded<FKBoxElem>();
		}
		bUseArchetypeBodySetup = false; //InvalidateOrUpdateBoxBodySetup<EShapeBodySetupHelper::InvalidateSharingIfStale>(ShapeBodySetup, bUseArchetypeBodySetup, BoxExtent);

		if (!bUseArchetypeBodySetup)
		{
			InvalidateOrUpdateBoxBodySetup<EShapeBodySetupHelper::UpdateBodySetup>(ShapeBodySetup, bUseArchetypeBodySetup, BoxExtent);
		}
	}
	else
	{
		if (!ShapeBodySetup || ShapeBodySetup->AggGeom.SphereElems.IsEmpty())
		{
			ShapeBodySetup = nullptr;
			CreateShapeBodySetupIfNeeded<FKSphereElem>();
		}

		bUseArchetypeBodySetup = false; //InvalidateOrUpdateSphereBodySetup<EShapeBodySetupHelper::InvalidateSharingIfStale>(ShapeBodySetup, bUseArchetypeBodySetup, SphereRadius);

		if(!bUseArchetypeBodySetup)
		{
			InvalidateOrUpdateSphereBodySetup<EShapeBodySetupHelper::UpdateBodySetup>(ShapeBodySetup, bUseArchetypeBodySetup, SphereRadius);
		}
	}

}

void UC7ShapeCollisionComponent::BeginPlay()
{

	Super::BeginPlay();
	ULowLevelFunctions::EnableOverlapOptimization(this, true);
}

void UC7ShapeCollisionComponent::SetSphereRadius( float InSphereRadius, bool bUpdateOverlaps )
{
	SphereRadius = InSphereRadius;
	UpdateBounds();
	UpdateBodySetup();
	MarkRenderStateDirty();

	if (bPhysicsStateCreated)
	{
		// Update physics engine collision shapes
		BodyInstance.UpdateBodyScale(GetComponentTransform().GetScale3D(), true);

		if ( bUpdateOverlaps && IsCollisionEnabled() && GetOwner() )
		{
			UpdateOverlaps();
		}
	}
}

bool UC7ShapeCollisionComponent::IsZeroExtent() const
{
	return ShapeType == EC7ShapeCollisionType::Box ?
		BoxExtent.IsZero() :
		SphereRadius == 0.f;
}


FPrimitiveSceneProxy* UC7ShapeCollisionComponent::CreateSphereSceneProxy()
{
	/** Represents a DrawLightRadiusComponent to the scene manager. */
	class FSphereSceneProxy final : public FPrimitiveSceneProxy
	{
	public:
		SIZE_T GetTypeHash() const override
		{
			static size_t UniquePointer;
			return reinterpret_cast<size_t>(&UniquePointer);
		}

		/** Initialization constructor. */
		FSphereSceneProxy(const UC7ShapeCollisionComponent* InComponent)
			:	FPrimitiveSceneProxy(InComponent)
			,	bDrawOnlyIfSelected( InComponent->bDrawOnlyIfSelected )
			,	SphereColor(InComponent->ShapeColor)
			,	SphereRadius(InComponent->SphereRadius)
		{
			bWillEverBeLit = false;
		}

		  // FPrimitiveSceneProxy interface.
		
		virtual void GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const override
		{
			QUICK_SCOPE_CYCLE_COUNTER( STAT_SphereSceneProxy_GetDynamicMeshElements );

			for (int32 ViewIndex = 0; ViewIndex < Views.Num(); ViewIndex++)
			{
				if (VisibilityMap & (1 << ViewIndex))
				{
					const FSceneView* View = Views[ViewIndex];
					FPrimitiveDrawInterface* PDI = Collector.GetPDI(ViewIndex);

					const FMatrix& LocalToWorld = GetLocalToWorld();
					const FLinearColor DrawSphereColor = GetViewSelectionColor(SphereColor, *View, IsSelected(), IsHovered(), false, IsIndividuallySelected() );

					// Taking into account the min and maximum drawing distance
					const float DistanceSqr = (View->ViewMatrices.GetViewOrigin() - LocalToWorld.GetOrigin()).SizeSquared();
					if (DistanceSqr < FMath::Square(GetMinDrawDistance()) || DistanceSqr > FMath::Square(GetMaxDrawDistance()) )
					{
						continue;
					}
					
					float AbsScaleX = LocalToWorld.GetScaledAxis(EAxis::X).Size();
					float AbsScaleY = LocalToWorld.GetScaledAxis(EAxis::Y).Size();
					float AbsScaleZ = LocalToWorld.GetScaledAxis(EAxis::Z).Size();
					float MinAbsScale = FMath::Min3(AbsScaleX, AbsScaleY, AbsScaleZ);

					FVector ScaledX = LocalToWorld.GetUnitAxis(EAxis::X) * MinAbsScale;
					FVector ScaledY = LocalToWorld.GetUnitAxis(EAxis::Y) * MinAbsScale;
					FVector ScaledZ = LocalToWorld.GetUnitAxis(EAxis::Z) * MinAbsScale;

					const int32 SphereSides = FMath::Clamp<int32>(SphereRadius / 4.f, 16, 64);
					DrawCircle(PDI, LocalToWorld.GetOrigin(), ScaledX, ScaledY, DrawSphereColor, SphereRadius, SphereSides, SDPG_World);
					DrawCircle(PDI, LocalToWorld.GetOrigin(), ScaledX, ScaledZ, DrawSphereColor, SphereRadius, SphereSides, SDPG_World);
					DrawCircle(PDI, LocalToWorld.GetOrigin(), ScaledY, ScaledZ, DrawSphereColor, SphereRadius, SphereSides, SDPG_World);
				}
			}
		}

		virtual FPrimitiveViewRelevance GetViewRelevance(const FSceneView* View) const override
		{
			const bool bVisibleForSelection = !bDrawOnlyIfSelected || IsSelected();
			const bool bVisibleForShowFlags = true; // @TODO

			// Should we draw this because collision drawing is enabled, and we have collision
			const bool bShowForCollision = View->Family->EngineShowFlags.Collision && IsCollisionEnabled();

			FPrimitiveViewRelevance Result;
			Result.bDrawRelevance = (IsShown(View) && bVisibleForSelection && bVisibleForShowFlags) || bShowForCollision;
			Result.bDynamicRelevance = true;
			Result.bShadowRelevance = IsShadowCast(View);
			Result.bEditorPrimitiveRelevance = UseEditorCompositing(View);
			return Result;
		}

		virtual uint32 GetMemoryFootprint( void ) const override { return( sizeof( *this ) + GetAllocatedSize() ); }
		uint32 GetAllocatedSize( void ) const { return( FPrimitiveSceneProxy::GetAllocatedSize() ); }

	private:
		const uint32				bDrawOnlyIfSelected:1;
		const FColor				SphereColor;
		const float					SphereRadius;
	};

	return new FSphereSceneProxy( this );
}

void UC7ShapeCollisionComponent::InitCollisionAsBox(const FVector& InBoxExtent)
{
	SetBoxExtent(InBoxExtent, false);
	SetShapeType(EC7ShapeCollisionType::Box);
}

void UC7ShapeCollisionComponent::InitCollisionAsSphere(const float& InRadius)
{
	SetSphereRadius(InRadius, false);
	SetShapeType(EC7ShapeCollisionType::Sphere);
}

FPrimitiveSceneProxy* UC7ShapeCollisionComponent::CreateBoxSceneProxy()
{
	/** Represents a UC7ShapeCollisionComponent to the scene manager. */
	class FBoxSceneProxy final : public FPrimitiveSceneProxy
	{
	public:
		SIZE_T GetTypeHash() const override
		{
			static size_t UniquePointer;
			return reinterpret_cast<size_t>(&UniquePointer);
		}

		FBoxSceneProxy(const UC7ShapeCollisionComponent* InComponent)
			:	FPrimitiveSceneProxy(InComponent)
			,	bDrawOnlyIfSelected( InComponent->bDrawOnlyIfSelected )
			,   BoxExtents( InComponent->BoxExtent )
			,	BoxColor( InComponent->ShapeColor )
			,	LineThickness( InComponent->LineThickness )
#if WITH_EDITORONLY_DATA
			,	bShow3D(InComponent->bShow3DInEditor)
#endif
		{
			bWillEverBeLit = false;
		}

		virtual void GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const override
		{
			QUICK_SCOPE_CYCLE_COUNTER( STAT_BoxSceneProxy_GetDynamicMeshElements );

			const FMatrix& LocalToWorld = GetLocalToWorld();
			const FQuat WorldQuat = LocalToWorld.Rotator().Quaternion();
			const FVector WorldLocation = LocalToWorld.GetOrigin();
			for (int32 ViewIndex = 0; ViewIndex < Views.Num(); ViewIndex++)
			{
				if (VisibilityMap & (1 << ViewIndex))
				{
					const FSceneView* View = Views[ViewIndex];

					const FLinearColor DrawColor = GetViewSelectionColor(BoxColor, *View, IsSelected(), IsHovered(), false, IsIndividuallySelected() );

					FPrimitiveDrawInterface* PDI = Collector.GetPDI(ViewIndex);
					if (bShow3D)
					{
						DrawOrientedWireBox(PDI, LocalToWorld.GetOrigin(), LocalToWorld.GetScaledAxis( EAxis::X ), LocalToWorld.GetScaledAxis( EAxis::Y ), LocalToWorld.GetScaledAxis( EAxis::Z ), BoxExtents, DrawColor, SDPG_World, LineThickness);
					}
					else
					{
						FVector LocalVerts[8] = {
							FVector(-BoxExtents.X, -BoxExtents.Y, -BoxExtents.Z),
							FVector(BoxExtents.X, -BoxExtents.Y, -BoxExtents.Z),
							FVector(BoxExtents.X, BoxExtents.Y, -BoxExtents.Z),
							FVector(-BoxExtents.X, BoxExtents.Y, -BoxExtents.Z),
							FVector(-BoxExtents.X, -BoxExtents.Y, BoxExtents.Z),
							FVector(BoxExtents.X, -BoxExtents.Y, BoxExtents.Z),
							FVector(BoxExtents.X, BoxExtents.Y, BoxExtents.Z),
							FVector(-BoxExtents.X, BoxExtents.Y, BoxExtents.Z)
						};
						for (int i = 0; i < 8; ++i)
						{
							LocalVerts[i] = WorldLocation + WorldQuat.RotateVector(LocalVerts[i]);
						}

						PDI->DrawTranslucentLine(LocalVerts[0], LocalVerts[4], DrawColor, SDPG_World, LineThickness);
						PDI->DrawTranslucentLine(LocalVerts[1], LocalVerts[5], DrawColor, SDPG_World, LineThickness);
						PDI->DrawTranslucentLine(LocalVerts[2], LocalVerts[6], DrawColor, SDPG_World, LineThickness);
						PDI->DrawTranslucentLine(LocalVerts[3], LocalVerts[7], DrawColor, SDPG_World, LineThickness);
					}
				}
			}
		}

		virtual FPrimitiveViewRelevance GetViewRelevance(const FSceneView* View) const override
		{
			const bool bProxyVisible = !bDrawOnlyIfSelected || IsSelected();

			// Should we draw this because collision drawing is enabled, and we have collision
			const bool bShowForCollision = View->Family->EngineShowFlags.Collision && IsCollisionEnabled();

			FPrimitiveViewRelevance Result;
			Result.bDrawRelevance = (IsShown(View) && bProxyVisible) || bShowForCollision;
			Result.bDynamicRelevance = true;
			Result.bShadowRelevance = IsShadowCast(View);
			Result.bEditorPrimitiveRelevance = UseEditorCompositing(View);
			return Result;
		}
		virtual uint32 GetMemoryFootprint( void ) const override { return( sizeof( *this ) + GetAllocatedSize() ); }
		uint32 GetAllocatedSize( void ) const { return( FPrimitiveSceneProxy::GetAllocatedSize() ); }

	private:
		const uint32	bDrawOnlyIfSelected:1;
		const FVector	BoxExtents;
		const FColor	BoxColor;
		const float LineThickness;
		bool			bShow3D = true;
	};

	return new FBoxSceneProxy( this );
}

FPrimitiveSceneProxy* UC7ShapeCollisionComponent::CreateSceneProxy()
{
	auto CreateDefaultProxy = [this]()
	{
		return ShapeType == EC7ShapeCollisionType::Box ?
			CreateBoxSceneProxy() :
			CreateSphereSceneProxy();
	};

#if WITH_EDITOR
	
	#if WITH_EDITORONLY_DATA
		return ShapeType == EC7ShapeCollisionType::Box ?
			CreateBoxSceneProxy() :
			( bShowSphereWireAsCylinderInEditor ? CreateCylinderSceneProxy() : CreateSphereSceneProxy() );
	#else
		return CreateDefaultProxy();
	#endif

#else
	return CreateDefaultProxy();
#endif
}


FCollisionShape UC7ShapeCollisionComponent::GetCollisionShape(float Inflation) const
{
	if (ShapeType == EC7ShapeCollisionType::Box)
	{
		FVector Extent = GetScaledBoxExtent() + Inflation;
		if (Inflation < 0.f)
		{
			// Don't shrink below zero size.
			Extent = Extent.ComponentMax(FVector::ZeroVector);
		}
		return FCollisionShape::MakeBox(Extent);
	}
	else
	{
		const float Radius = FMath::Max(0.f, GetScaledSphereRadius() + Inflation);
		return FCollisionShape::MakeSphere(Radius);
	}
}

bool UC7ShapeCollisionComponent::AreSymmetricRotations(const FQuat& A, const FQuat& B, const FVector& Scale3D) const
{
	// All rotations are equal when scale is uniform.
	// Not detecting rotations around non-uniform scale.
	return Scale3D.GetAbs().AllComponentsEqual() || A.Equals(B);
}

void UC7ShapeCollisionComponent::SetBoxExtent(FVector NewBoxExtent, bool bUpdateOverlaps)
{
	BoxExtent = NewBoxExtent;
	UpdateBounds();
	MarkRenderStateDirty();
	UpdateBodySetup();

	// do this if already created
	// otherwise, it hasn't been really created yet
	if (bPhysicsStateCreated)
	{
		// Update physics engine collision shapes
		BodyInstance.UpdateBodyScale(GetComponentTransform().GetScale3D(), true);

		if ( bUpdateOverlaps && IsCollisionEnabled() && GetOwner() )
		{
			UpdateOverlaps();
		}
	}
}

//void UC7ShapeCollisionComponent::SetLineThickness(float Thickness)
//{
//	LineThickness = Thickness;
//	MarkRenderStateDirty();
//}


void UC7ShapeCollisionComponent::SetShapeType(EC7ShapeCollisionType InShapeType)
{
	ShapeType = InShapeType;
	UpdateBounds();
	UpdateBodySetup();
	RecreatePhysicsState();
	MarkRenderStateDirty();
}

void UC7ShapeCollisionComponent::SetEntityOwner(const FString& EID)
{
	OwnerEntityID = EID;
}

bool UC7ShapeCollisionComponent::DealMoveDeltaByCollision(FVector& MoveDelta, const FVector& StartLocation,const FVector& EndLocation, const float UpdateComponentXYRadius, const bool bNeedSlide)
{
	bool bHitBounds = false;
	if (ShapeType == EC7ShapeCollisionType::Sphere)
	{

		FVector Center = GetComponentLocation();
		float Radius = GetScaledSphereRadius();

		// 战斗区域中心到移动起始点的向量
		FVector CenterToStart = StartLocation - Center;
		CenterToStart.Z = 0.0f;
		// 如果是零向量，给一个默认值
		if (CenterToStart.IsNearlyZero())
		{
			CenterToStart = FVector(1.0f, 0.0f, 0.0f);
		}
		float CenterToStartSize = CenterToStart.Size2D();
		FVector CenterToStartNormal = CenterToStart / CenterToStartSize;


		bool StartRes = CenterToStartSize < Radius;
		bool EndRes = (EndLocation - Center).SizeSquared() < Radius * Radius;

		if (!StartRes || EndRes)
		{
			return bHitBounds;
		}
		
		bHitBounds = true;
		
		if (!bNeedSlide)
		{
			MoveDelta = FVector::ZeroVector;
			return bHitBounds;
		}


		// 位移向量投影大小
		float ProjectToCenterToStartNormal = FVector::DotProduct(MoveDelta, CenterToStartNormal);
		if (ProjectToCenterToStartNormal > 0.0f)
		{
			MoveDelta = MoveDelta - ProjectToCenterToStartNormal * CenterToStartNormal;
			MoveDelta.Z = 0.0f;
		}

		if (MoveDelta.IsNearlyZero())
		{
			return bHitBounds;
		}

		// 最终调整位移大小
		float MoveDeltaSize = MoveDelta.Size2D();
		MoveDelta = MoveDelta / MoveDeltaSize * FMath::Min(MoveDeltaSize, FMath::Sqrt(Radius * Radius - CenterToStartSize * CenterToStartSize));

	}

	else if (ShapeType == EC7ShapeCollisionType::Box)
	{
		// 方形, 判断目的点是否在方形区域内
		FVector Center = GetComponentLocation();
		FRotator Rotation = GetComponentRotation();
		Rotation.Roll = 0.0f;
		Rotation.Pitch = 0.0f;
		FVector2D Size = FVector2D(GetScaledBoxExtent());


		FTransform RectangleT = FTransform(Rotation, Center);
		FVector LocalStart = RectangleT.InverseTransformPosition(StartLocation);
		FVector LocalEnd = RectangleT.InverseTransformPosition(EndLocation);


		bool StartRes = (LocalStart.X >= -Size.X) && (LocalStart.X <= Size.X) && (LocalStart.Y >= -Size.Y) && (LocalStart.Y <= Size.Y);
		bool EndRes = (LocalEnd.X >= -Size.X) && (LocalEnd.X <= Size.X) && (LocalEnd.Y >= -Size.Y) && (LocalEnd.Y <= Size.Y);

		if (!StartRes || EndRes)
		{
			return bHitBounds;
		}
		
		bHitBounds = true;
		
		if (!bNeedSlide)
		{
			MoveDelta = FVector::ZeroVector;
			return bHitBounds;
		}


		float MaxLength = 0.0f;
		FVector NormalDirection = FVector::ZeroVector;
		if (LocalEnd.X <= -Size.X || LocalEnd.X > Size.X)
		{
			if (LocalEnd.X <= -Size.X)
				NormalDirection = FVector(-1.0f, 0.0f, 0.0f);
			else
				NormalDirection = FVector(1.0f, 0.0f, 0.0f);

			if (LocalEnd.Y > LocalStart.Y)
				MaxLength = Size.Y - LocalStart.Y;
			else
				MaxLength = LocalStart.Y + Size.Y;
		}
		else
		{
			if (LocalEnd.Y <= -Size.Y)
				NormalDirection = FVector(0.0f, -1.0f, 0.0f);
			else
				NormalDirection = FVector(0.0f, 1.0f, 0.0f);

			if (LocalEnd.X > LocalStart.X)
				MaxLength = Size.X - LocalStart.X;
			else
				MaxLength = LocalStart.X + Size.X;
		}


		NormalDirection = RectangleT.TransformVector(NormalDirection);

		// 位移向量投影大小
		float ProjectToNormal = FVector::DotProduct(MoveDelta, NormalDirection);
		if (ProjectToNormal > 0.0f)
		{
			MoveDelta = MoveDelta - ProjectToNormal * NormalDirection;
			MoveDelta.Z = 0.0f;
		}

		if (MoveDelta.IsNearlyZero())
		{
			return bHitBounds;
		}

		// 最终调整位移大小
		float MoveDeltaSize = MoveDelta.Size2D();
		MoveDelta = MoveDelta / MoveDeltaSize * FMath::Min(MoveDeltaSize, MaxLength);

		FVector FinalEndLocation = StartLocation + MoveDelta + MoveDelta.GetSafeNormal2D() * (UpdateComponentXYRadius + 5.0f);
		FinalEndLocation = RectangleT.InverseTransformPosition(FinalEndLocation);
		// 解决在角落处, 有概率穿透过去的问题
		if (FinalEndLocation.X < -Size.X || FinalEndLocation.X > Size.X) {
			MoveDelta.X = 0;
		}

		if (FinalEndLocation.Y < -Size.Y || FinalEndLocation.Y > Size.Y) {
			MoveDelta.Y = 0;
		}
	}
	return bHitBounds;
}

bool UC7ShapeCollisionComponent::ConstraintLocationXYInRange(const FVector& TargetLocation, FVector& FinalLocation)
{
	if (ShapeType == EC7ShapeCollisionType::Sphere)
	{
		FVector Center = GetComponentLocation();
		float Radius = GetScaledSphereRadius();
		
		FVector CenterToTarget = TargetLocation - Center;
		CenterToTarget.Z = 0.0f;
		if (CenterToTarget.IsNearlyZero())
		{
			CenterToTarget = FVector(1.0f, 0.0f, 0.0f);
		}
		
		float CenterToTargetSize = CenterToTarget.Size2D();
		if (CenterToTargetSize < Radius)
		{
			FinalLocation = TargetLocation;
			return true;
		}
		CenterToTarget.Normalize();
 		FinalLocation = Center + (Radius - ShapeThickness) * CenterToTarget;
		FinalLocation.Z = TargetLocation.Z;
		return false;
	}
	else
	{
		// 方形, 判断目的点是否在方形区域内
		FVector Center = GetComponentLocation();
		FRotator Rotation = GetComponentRotation();
		Rotation.Roll = 0.0f;
		Rotation.Pitch = 0.0f;
		FVector2D Size = FVector2D(GetScaledBoxExtent());

		FTransform RectangleT = FTransform(Rotation, Center);
		FVector LocalTarget = RectangleT.InverseTransformPosition(TargetLocation);

		bool StartRes = (LocalTarget.X >= -Size.X) && (LocalTarget.X <= Size.X) && (LocalTarget.Y >= -Size.Y) && (LocalTarget.Y <= Size.Y);
		if (StartRes)
		{
			FinalLocation = TargetLocation;
			return true;
		}
		
		if (LocalTarget.X < -Size.X)
		{
			LocalTarget.X = -Size.X + ShapeThickness;
		}
		else if (LocalTarget.X > Size.X)
		{
			LocalTarget.X = Size.X - ShapeThickness;
		}

		if (LocalTarget.Y < -Size.Y)
		{
			LocalTarget.Y = -Size.Y + ShapeThickness;
		}
		else if (LocalTarget.Y > Size.Y)
		{
			LocalTarget.Y = Size.Y - ShapeThickness;
		}

		FinalLocation = RectangleT.TransformPosition(LocalTarget);
		FinalLocation.Z = TargetLocation.Z;
		return false;
	}
}

void UC7ShapeCollisionComponent::SetOwnerIntUID(int64 InOwnerUID)
{
	OwnerIntUID = InOwnerUID;
}

void UC7ShapeCollisionComponent::InitAsInteractable(int64 InOwnerUID, bool bInUseNativeDetectEvent)
{
	if (InOwnerUID == 0)
	{
		if (AActor* Owner = GetOwner())
		{
			InOwnerUID = Owner->GetUniqueID();
		}
	}
	SetOwnerIntUID(InOwnerUID);
	SetUseNativeDetectEvent(bInUseNativeDetectEvent);
	EnableInterActiveForDetect(true);
}

void UC7ShapeCollisionComponent::SetUseNativeDetectEvent(bool bInUseNativeDetectEvent)
{
	bUseNativeDetectEvent = bInUseNativeDetectEvent;	
}

bool UC7ShapeCollisionComponent::IsActivateForDetect()
{
	return bActivateForDetect;
}

void UC7ShapeCollisionComponent::EnableInterActiveForDetect(bool bEnable)
{
	bActivateForDetect = bEnable;
}

void UC7ShapeCollisionComponent::SetCustomScopeParams(bool InCustomScopeEnable, const FC7InteractableCustomScopeParams& InCustomScope)
{
	CustomScopeParams = InCustomScope;
}

void UC7ShapeCollisionComponent::ResetLimitCustomScope(float InnerRadius, float MaxRadius)
{
	CustomScopeParams.InnerRadius = InnerRadius;
	CustomScopeParams.MaxRadius = MaxRadius;
}

void UC7ShapeCollisionComponent::ResetLimitCustomAngle(float HalfMinAngle, float HalfMaxAngle, float YawOffset)
{
	CustomScopeParams.HalfMinAngle = HalfMinAngle; 
	CustomScopeParams.HalfMaxAngle = HalfMaxAngle;
	CustomScopeParams.LimitAngleYawOffset = YawOffset;
}

void UC7ShapeCollisionComponent::SetOwnerCapsuleSize(float InHalfHeight, float InRadius)
{
	CustomScopeParams.OwnerCapsuleRadius = InRadius;
	CustomScopeParams.OwnerCapsuleHalfHeight = InHalfHeight;
}

void UC7ShapeCollisionComponent::SetCheckLineTracePlayer(bool bEnable, float MinCheckDistance)
{
	CustomScopeParams.bCheckLineTracePlayer = bEnable;
	CustomScopeParams.LineTracePlayerMinDistance = MinCheckDistance;
}

void UC7ShapeCollisionComponent::SetCheckLineTraceCamera(bool bEnable, float MinCheckDistance)
{
	CustomScopeParams.bCheckLineTraceCamera = bEnable;
	CustomScopeParams.LineTraceCameraMinDistance = MinCheckDistance;
}

void UC7ShapeCollisionComponent::GetCustomScopeParams(FC7InteractableCustomScopeParams& OutCustomScope)
{
	OutCustomScope = CustomScopeParams;
}

void UC7ShapeCollisionComponent::EnterInteractiveTrigger(AActor* Other, const FVector& Pos)
{
	if (bUseNativeDetectEvent)
	{
		OnEnterTrigger_MD.Broadcast(Other, Pos);
	}
}

void UC7ShapeCollisionComponent::LeaveInteractiveTrigger(AActor* Other, const FVector& Pos)
{
	if (bUseNativeDetectEvent)
	{
		OnLeaveTrigger_MD.Broadcast(Other, Pos);
	}
}

#if WITH_EDITOR

FPrimitiveSceneProxy* UC7ShapeCollisionComponent::CreateCylinderSceneProxy()
{
		/** Represents a DrawLightRadiusComponent to the scene manager. */
	class FCylinderSceneProxy final : public FPrimitiveSceneProxy
	{
	public:
		SIZE_T GetTypeHash() const override
		{
			static size_t UniquePointer;
			return reinterpret_cast<size_t>(&UniquePointer);
		}

		/** Initialization constructor. */
		FCylinderSceneProxy(const UC7ShapeCollisionComponent* InComponent)
			:	FPrimitiveSceneProxy(InComponent)
			,	bDrawOnlyIfSelected( InComponent->bDrawOnlyIfSelected )
			,	SphereColor(InComponent->ShapeColor)
			,	SphereRadius(InComponent->SphereRadius)
			,	BoxExtent(InComponent->BoxExtent)
#if WITH_EDITORONLY_DATA
			,	bShow3D(InComponent->bShow3DInEditor)
#endif
		
		{
			bWillEverBeLit = false;
		}

		  // FPrimitiveSceneProxy interface.
		
		virtual void GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const override
		{
			QUICK_SCOPE_CYCLE_COUNTER( STAT_SphereSceneProxy_GetDynamicMeshElements );

			for (int32 ViewIndex = 0; ViewIndex < Views.Num(); ViewIndex++)
			{
				if (VisibilityMap & (1 << ViewIndex))
				{
					const FSceneView* View = Views[ViewIndex];
					FPrimitiveDrawInterface* PDI = Collector.GetPDI(ViewIndex);

					const FMatrix& LocalToWorld = GetLocalToWorld();
					const FLinearColor DrawSphereColor = GetViewSelectionColor(SphereColor, *View, IsSelected(), IsHovered(), false, IsIndividuallySelected() );

					// Taking into account the min and maximum drawing distance
					const float DistanceSqr = (View->ViewMatrices.GetViewOrigin() - LocalToWorld.GetOrigin()).SizeSquared();
					if (DistanceSqr < FMath::Square(GetMinDrawDistance()) || DistanceSqr > FMath::Square(GetMaxDrawDistance()) )
					{
						continue;
					}
					
					float AbsScaleX = LocalToWorld.GetScaledAxis(EAxis::X).Size();
					float AbsScaleY = LocalToWorld.GetScaledAxis(EAxis::Y).Size();
					float AbsScaleZ = LocalToWorld.GetScaledAxis(EAxis::Z).Size();
					float MinAbsScale = FMath::Min3(AbsScaleX, AbsScaleY, AbsScaleZ);

					FVector ScaledX = LocalToWorld.GetUnitAxis(EAxis::X) * MinAbsScale;
					FVector ScaledY = LocalToWorld.GetUnitAxis(EAxis::Y) * MinAbsScale;
					FVector ScaledZ = LocalToWorld.GetUnitAxis(EAxis::Z) * MinAbsScale;

					const int32 SphereSides = FMath::Clamp<int32>(SphereRadius / 4.f, 16, 64);

					// DrawCircle(PDI, LocalToWorld.GetOrigin(), ScaledX, ScaledZ, DrawSphereColor, SphereRadius, SphereSides, SDPG_World);
					// DrawCircle(PDI, LocalToWorld.GetOrigin(), ScaledY, ScaledZ, DrawSphereColor, SphereRadius, SphereSides, SDPG_World);
					
					FTransform WorldTransform(LocalToWorld);
					float HalfHeight = BoxExtent.Z;
					FVector BottonLineStart1 = WorldTransform.TransformPosition(FVector(-SphereRadius,0,-HalfHeight));
					FVector BottonLineEnd1 = WorldTransform.TransformPosition(FVector(SphereRadius,0,-HalfHeight));
					FVector BottonLineStart2 = WorldTransform.TransformPosition(FVector(0, -SphereRadius, -HalfHeight));
					FVector BottonLineEnd2 = WorldTransform.TransformPosition(FVector(0, SphereRadius, -HalfHeight));
					if (bShow3D)
					{
						DrawCircle(PDI, LocalToWorld.GetOrigin() - FVector(0,0,HalfHeight), ScaledX, ScaledY, DrawSphereColor, SphereRadius, SphereSides, SDPG_World);
						PDI->DrawLine(BottonLineStart1, BottonLineEnd1, DrawSphereColor, SDPG_World);
						PDI->DrawLine(BottonLineStart2, BottonLineEnd2, DrawSphereColor, SDPG_World);
					}
					
					FVector TopLineStart1 = WorldTransform.TransformPosition(FVector(-SphereRadius, 0, HalfHeight));
					FVector TopLineEnd1 = WorldTransform.TransformPosition(FVector(SphereRadius, 0, HalfHeight));
					FVector TopLineStart2 = WorldTransform.TransformPosition(FVector(0, -SphereRadius,HalfHeight));
					FVector TopLineEnd2 = WorldTransform.TransformPosition(FVector(0, SphereRadius,HalfHeight));
					if (bShow3D)
					{
						DrawCircle(PDI, LocalToWorld.GetOrigin() + FVector(0,0,HalfHeight), ScaledX, ScaledY, DrawSphereColor, SphereRadius, SphereSides, SDPG_World);
						PDI->DrawLine(TopLineStart1, TopLineEnd1, DrawSphereColor, SDPG_World);
						PDI->DrawLine(TopLineStart2, TopLineEnd2, DrawSphereColor, SDPG_World);
					}
					
					PDI->DrawLine(BottonLineStart1, TopLineStart1, DrawSphereColor, SDPG_World);
					PDI->DrawLine(BottonLineEnd1, TopLineEnd1, DrawSphereColor, SDPG_World);
					PDI->DrawLine(BottonLineStart2, TopLineStart2, DrawSphereColor, SDPG_World);
					PDI->DrawLine(BottonLineEnd2, TopLineEnd2, DrawSphereColor, SDPG_World);
				}
			}
		}

		virtual FPrimitiveViewRelevance GetViewRelevance(const FSceneView* View) const override
		{
			const bool bVisibleForSelection = !bDrawOnlyIfSelected || IsSelected();
			const bool bVisibleForShowFlags = true; // @TODO

			// Should we draw this because collision drawing is enabled, and we have collision
			const bool bShowForCollision = View->Family->EngineShowFlags.Collision && IsCollisionEnabled();

			FPrimitiveViewRelevance Result;
			Result.bDrawRelevance = (IsShown(View) && bVisibleForSelection && bVisibleForShowFlags) || bShowForCollision;
			Result.bDynamicRelevance = true;
			Result.bShadowRelevance = IsShadowCast(View);
			Result.bEditorPrimitiveRelevance = UseEditorCompositing(View);
			return Result;
		}

		virtual uint32 GetMemoryFootprint( void ) const override { return( sizeof( *this ) + GetAllocatedSize() ); }
		uint32 GetAllocatedSize( void ) const { return( FPrimitiveSceneProxy::GetAllocatedSize() ); }

	private:
		const uint32				bDrawOnlyIfSelected:1;
		const FColor				SphereColor;
		const float					SphereRadius;
		const FVector				BoxExtent;
		bool						bShow3D = true;
	};

	return new FCylinderSceneProxy( this );
}
#endif