#include "Lua/LuaLog.h"

#include "LuaCppBinding.h"
#include "CoreMinimal.h"
#include "Engine/Engine.h"
#include "Kismet/BlueprintFunctionLibrary.h"

#include <cinttypes>

using namespace NS_SLUA;
//UE_DISABLE_OPTIMIZATION
DEFINE_LOG_CATEGORY(LuaLog);

namespace LUA_LOG {

#ifndef LUA_QL
#define LUA_QL(x) "'" x "'"
#define LUA_QS LUA_QL("%s")
#endif // !LUA_QL

#define __LUA_FILENAME__(path) (strrchr(path, '/') ? strrchr(path, '/') + 1 : path)
#define LOG_LINE_MAX (1024 * 4)
#define FORMAT_MAX_ITEM_LEN 64

static char output[LOG_LINE_MAX + 16];
static LuaLogLevel GameLogLevel = LuaLogLevel::DebugLog;
static LuaLogLevel LogOnScreenLevel = LuaLogLevel::Error;
static bool LogErrorTraceback = true;

static void WriteLog(LuaLogLevel level, const char* msg, size_t len)
{
	auto buff = KgUTF8ToTCHAR((const UTF8CHAR*)msg);
	switch (level) {
	case LuaLogLevel::Fatal:
		UE_LOG(LuaLog, Fatal, TEXT("%s"), buff.Get());
		break;
	case LuaLogLevel::Error:
		UE_LOG(LuaLog, Error, TEXT("%s"), buff.Get());
		break;
	case LuaLogLevel::Warning:
		UE_LOG(LuaLog, Warning, TEXT("%s"), buff.Get());
		break;
	case LuaLogLevel::Log:
		UE_LOG(LuaLog, ReleaseLog, TEXT("%s"), buff.Get());
		break;
#if !UE_BUILD_SHIPPING
	case LuaLogLevel::DebugError:
		UE_LOG(LuaLog, Error, TEXT("%s"), buff.Get());
		break;
	case LuaLogLevel::DebugWarning:
		UE_LOG(LuaLog, Warning, TEXT("%s"), buff.Get());
#endif
	default:
		UE_LOG(LuaLog, Log, TEXT("%s"), buff.Get());
		break;
	}

	//log on screen
	if (level >= LogOnScreenLevel && GAreScreenMessagesEnabled)
	{
		FColor ScreenLogColor = FColor::Red;
		switch (level)
		{
		case LuaLogLevel::Fatal:
		case LuaLogLevel::Error:
			break;
		case LuaLogLevel::Warning:
			ScreenLogColor = FColor::Yellow;
			break;
		default:
			ScreenLogColor = FColor::White;
			break;
		}

		check(GEngine);
		GEngine->AddOnScreenDebugMessage(-10, 10.0f, ScreenLogColor, buff.Get());
	}
}

static void AppendLogBuffer(char* out, int& cur, const char* s, size_t len)
{
	int output_len = fmin(static_cast<int>(len), LOG_LINE_MAX - 1 - cur);
	FMemory::Memcpy(out + cur, s, output_len);
	cur += output_len;
}

static void AppendLogBuffer(char* out, int& cur, char c, size_t len)
{
	int output_len = fmin(LOG_LINE_MAX - 1 - cur, static_cast<int>(len));
	FMemory::Memset(out + cur, c, output_len);
	cur += output_len;
}

static void FormatLuaType(lua_State* L, int narg, char* out, int& cur)
{
	switch (lua_type(L, narg)) {
	case LUA_TNIL:
		return AppendLogBuffer(out, cur, "nil", 3);
	case LUA_TBOOLEAN:
		if (lua_toboolean(L, narg)) {
			return AppendLogBuffer(out, cur, "true", 4);
		}
		else {
			return AppendLogBuffer(out, cur, "false", 5);
		}
	case LUA_TTABLE:
		return AppendLogBuffer(out, cur, "TABLE", 5);
	case LUA_TLIGHTUSERDATA:
		return AppendLogBuffer(out, cur, "LIGHTUSERDATA", 13);
	case LUA_TFUNCTION:
		return AppendLogBuffer(out, cur, "USERDATA", 8);
	case LUA_TTHREAD:
		return AppendLogBuffer(out, cur, "THREAD", 6);
	default:
		return AppendLogBuffer(out, cur, "ERRORTYPE", 9);
	}
}

static void ProcessOneArg(lua_State* L, int i, char* out, int& cur)
{
	int type = lua_type(L, i);
	switch (type) {
	case LUA_TNUMBER: {
		char buff[FORMAT_MAX_ITEM_LEN];
		int len;
		if (lua_isinteger(L, i))
		{
			int64 v = lua_tointeger(L, i);
			len = FCStringAnsi::Snprintf(buff, FORMAT_MAX_ITEM_LEN, "%" PRId64, v);
		}
		else
		{
			double v = lua_tonumber(L, i);
			len = FCStringAnsi::Snprintf(buff, FORMAT_MAX_ITEM_LEN, "%.2f", v);
		}
		AppendLogBuffer(out, cur, buff, len);
	} break;
	case LUA_TSTRING: {
		size_t len;
		const char* s = lua_tolstring(L, i, &len);
		AppendLogBuffer(out, cur, s, len);
	} break;
	case LUA_TUSERDATA: {
		const char* s;
		size_t len;
		lua_getglobal(L, "tostring");
		lua_pushvalue(L, i);
		lua_call(L, 1, 1);
		s = lua_tolstring(L, -1, &len);
		if (s == nullptr) {
			s = "nil";
			len = 3;
		}

		AppendLogBuffer(out, cur, s, len);
		lua_pop(L, 1);
	} break;
	case LUA_TTABLE:
	case LUA_TBOOLEAN:
	case LUA_TLIGHTUSERDATA:
	case LUA_TFUNCTION:
	case LUA_TTHREAD:
	case LUA_TNIL: {
		FormatLuaType(L, i, out, cur);
	} break;
	default:
		break;
	}
}

template <LuaLogLevel LogLevel, int StackLv=1>
int LogPrint(lua_State* L)
{
	if (LogLevel < GameLogLevel) {
		return 0;
	}

	const char* filename = "Lua";
	int lineno = 0;
	lua_Debug ar;
	if (lua_getstack(L, StackLv, &ar)) {
		lua_getinfo(L, "Sln", &ar);
		if (ar.currentline > 0) {
			filename = __LUA_FILENAME__(ar.short_src);
			lineno = ar.currentline;
		}
	}

	int cur = 0;
	cur = FCStringAnsi::Snprintf(output, LOG_LINE_MAX, "%s:%d ", filename, lineno);
	if (cur < 0 || cur >= LOG_LINE_MAX) {
		cur = LOG_LINE_MAX - 1;
	}

	int n = lua_gettop(L); /* number of arguments */
	for (int i = 1; i <= n; i++) {
		if (cur >= LOG_LINE_MAX - 2) {
			break;
		}

		if (i != 1) {
			output[cur++] = '\t';
		}
		ProcessOneArg(L, i, output, cur);
	}

	// removed by fanggang@ks, auto append at crashsight logic.
	// if (LogLevel >= LuaLogLevel::Error && LogErrorTraceback) {
	// 	AddTracebackInfo(L, output, cur);
	// }

	output[cur] = '\0';

	lua_settop(L, n);

	WriteLog(LogLevel, output, (size_t)cur);
	return 0;
}

template <LuaLogLevel LogLevel, bool HasPrefix, int base>
int FormatAndWrite(lua_State* L, const char* filename, int lineno)
{
	int n = lua_gettop(L);
	if (n <= 0) {
		return 0;
	}

	int fmt_idx = base + 1;
	int prefix_info_idx = base;
	if constexpr (HasPrefix)
	{
		++prefix_info_idx;
		++fmt_idx;
	}
	if (lua_type(L, fmt_idx) != LUA_TSTRING) {
		lua_getglobal(L, "tostring");
		const char* s;
		size_t len;
		lua_pushvalue(L, -1);
		lua_pushvalue(L, 1);
		lua_call(L, 1, 1);
		s = lua_tolstring(L, -1, &len);
		if (s == nullptr) {
			s = "nil";
			len = 3;
		}
		lua_pop(L, 1);

		UE_LOG(LuaLog, Error, TEXT("format log does not has string format in first parameter slot"));
		return 0;
	}

	if constexpr (HasPrefix)
	{
		if (lua_type(L, prefix_info_idx) != LUA_TSTRING)
		{
			UE_LOG(LuaLog, Error, TEXT("prefix log does not has string format in second parameter slot"));
			return 0;
		}
	}

	int cur = 0;
	cur = FCStringAnsi::Snprintf(output, LOG_LINE_MAX, "%s:%d ", filename, lineno);
	if (cur < 0 || cur >= LOG_LINE_MAX) {
		cur = LOG_LINE_MAX - 1;
	}

	size_t len;
	const char* strfrmt = lua_tolstring(L, fmt_idx, &len);
	const char* strfrmt_end = strfrmt + len;

	int arg_idx = base + 2;
	if constexpr (HasPrefix)
	{
		ProcessOneArg(L, prefix_info_idx, output, cur);
		if (cur < LOG_LINE_MAX - 2)
		{
			output[cur++] = ' ';
		}
		++arg_idx;
	}
	while (strfrmt < strfrmt_end) {
		if (cur >= LOG_LINE_MAX - 2)
			break;

		if (*strfrmt == '%' && ((strfrmt + 1) < strfrmt_end)) {
			char tag = *(strfrmt + 1);
			if (tag == 's' || tag == 'd') { // format %s and %d
				if (n >= arg_idx) {
					ProcessOneArg(L, arg_idx, output, cur);
				}
				else {
					static size_t slen = strlen("NO_ARG");
					AppendLogBuffer(output, cur, "NO_ARG", slen);
				}

				strfrmt++; // skip '%'
				strfrmt++; // skip 's'/'v'
				arg_idx++;
			}
			else {
				output[cur++] = *strfrmt++;
			}
		}
		else {
			output[cur++] = *strfrmt++;
		}
	}

	// removed by fanggang@ks, auto append at crashsight logic.
	// if (LogLevel >= LuaLogLevel::Error && LogErrorTraceback) {
	// 	AddTracebackInfo(L, output, cur);
	// }

	output[cur] = '\0';

	lua_settop(L, n);

	WriteLog(LogLevel, output, (size_t)cur);
	return 0;
}

template <LuaLogLevel LogLevel, int StackLv=1, bool HasPrefix = false>
int LogFormatPrint(lua_State* L)
{
	if (LogLevel < GameLogLevel) {
		return 0;
	}

	const char* filename = "Lua";
	int lineno = 0;
	lua_Debug ar;
	if (lua_getstack(L, StackLv, &ar)) {
		lua_getinfo(L, "Sl", &ar);
		if (ar.currentline > 0) {
			filename = __LUA_FILENAME__(ar.short_src);
			lineno = ar.currentline;
		}
	}

	FormatAndWrite<LogLevel, HasPrefix, 0>(L, filename, lineno);
	return 0;
}

static int SetGameLogLevel(lua_State* L)
{
	int lv = luaL_checkinteger(L, 1);
	GameLogLevel = static_cast<LuaLogLevel>(lv);
	return 0;
}

static int GetGameLogLevel(lua_State* L)
{
	lua_pushinteger(L, static_cast<int>(GameLogLevel));
	return 1;
}

static int SetLogOnScreenLevel(lua_State* L)
{
	int lv = luaL_checkinteger(L, 1);
	LogOnScreenLevel = static_cast<LuaLogLevel>(lv);
	return 0;
}

static int GetLogOnScreenLevel(lua_State* L)
{
	lua_pushinteger(L, static_cast<int>(LogOnScreenLevel));
	return 1;
}

static int SetLogErrorTraceback(lua_State* L)
{
	if (!lua_isboolean(L, 1)) {
		return luaL_error(L, "arg type must be bool");
	}
	LogErrorTraceback = (bool)lua_toboolean(L, 1);
	return 0;
}


void RegisterLuaLogLib(lua_State* L)
{
	int top = lua_gettop(L);

	lua_getglobal(L, "LuaCLogger");
	if (lua_isnil(L, -1)) {
		lua_pop(L, 1);
		lua_newtable(L);
		lua_pushvalue(L, -1);
		lua_setglobal(L, "LuaCLogger");
	}

	lua_pushcclosure(L, LogPrint<LuaLogLevel::DebugLog>, 0);
	lua_setfield(L, -2, "DebugLog");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::DebugWarning>, 0);
	lua_setfield(L, -2, "DebugWarning");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::DebugError>, 0);
	lua_setfield(L, -2, "DebugError");

	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::DebugLog>, 0);
	lua_setfield(L, -2, "DebugLogFmt");

	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::DebugWarning>, 0);
	lua_setfield(L, -2, "DebugWarningFmt");

	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::DebugError>, 0);
	lua_setfield(L, -2, "DebugErrorFmt");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::Log>, 0);
	lua_setfield(L, -2, "Log");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::Warning>, 0);
	lua_setfield(L, -2, "Warning");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::Error>, 0);
	lua_setfield(L, -2, "Error");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::Fatal>, 0);
	lua_setfield(L, -2, "Fatal");

	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::Log>, 0);
	lua_setfield(L, -2, "LogFmt");

	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::Warning>, 0);
	lua_setfield(L, -2, "WarningFmt");

	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::Error>, 0);
	lua_setfield(L, -2, "ErrorFmt");

	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::Fatal>, 0);
	lua_setfield(L, -2, "FatalFmt");

	////////////////////////////////////////////////////////////////////////////
	lua_pushcclosure(L, LogPrint<LuaLogLevel::DebugLog, 2>, 0);
	lua_setfield(L, -2, "DebugPrefixLog");
	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::DebugLog, 2, true>, 0);
	lua_setfield(L, -2, "DebugPrefixLogFmt");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::DebugWarning, 2>, 0);
	lua_setfield(L, -2, "DebugPrefixWarning");
	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::DebugWarning, 2, true>, 0);
	lua_setfield(L, -2, "DebugPrefixWarningFmt");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::DebugError, 2>, 0);
	lua_setfield(L, -2, "DebugPrefixError");
	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::DebugError, 2, true>, 0);
	lua_setfield(L, -2, "DebugPrefixErrorFmt");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::Log, 2>, 0);
	lua_setfield(L, -2, "PrefixLog");
	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::Log, 2, true>, 0);
	lua_setfield(L, -2, "PrefixLogFmt");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::Warning, 2>, 0);
	lua_setfield(L, -2, "PrefixWarning");
	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::Warning, 2, true>, 0);
	lua_setfield(L, -2, "PrefixWarningFmt");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::Error, 2>, 0);
	lua_setfield(L, -2, "PrefixError");
	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::Error, 2, true>, 0);
	lua_setfield(L, -2, "PrefixErrorFmt");

	lua_pushcclosure(L, LogPrint<LuaLogLevel::Fatal, 2>, 0);
	lua_setfield(L, -2, "PrefixFatal");
	lua_pushcclosure(L, LogFormatPrint<LuaLogLevel::Fatal, 2, true>, 0);
	lua_setfield(L, -2, "PrefixFatalFmt");

	lua_pushcfunction(L, SetGameLogLevel);
	lua_setfield(L, -2, "SetGameLogLevel");
	lua_pushcfunction(L, GetGameLogLevel);
	lua_setfield(L, -2, "GetGameLogLevel");

	lua_pushcfunction(L, SetLogOnScreenLevel);
	lua_setfield(L, -2, "SetLogOnScreenLevel");
	lua_pushcfunction(L, GetLogOnScreenLevel);
	lua_setfield(L, -2, "GetLogOnScreenLevel");

	lua_pushcfunction(L, SetLogErrorTraceback);
	lua_setfield(L, -2, "SetLogErrorTraceback");

	lua_settop(L, top);
}

}