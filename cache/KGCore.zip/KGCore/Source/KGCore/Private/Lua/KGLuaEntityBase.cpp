#include "Lua/KGLuaEntityBase.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Util/KGUtils.h"
using namespace NS_SLUA;

int KGLuaObjectBase::BindLuaObject(lua_State* L, int idx) {
	if (lua_type(L, idx) != LUA_TTABLE) {
		return luaL_error(L, "Arg 2 expect lua table");
	}

	SelfTable = NS_SLUA::LuaVar(L, idx);
	return 0;
}

void KGLuaObjectBase::UnbindLuaObject()
{
	if (SelfTable.isValid()) {
		SelfTable.free();
	}
}

void KGLuaObjectBase::RefSelf(lua_State* L, int idx)
{
	lua_pushvalue(L, idx);
	SelfRef = luaL_ref(L, LUA_REGISTRYINDEX);
}

void KGLuaObjectBase::UnrefSelf(lua_State* L) {
	AutoStack as(L);

	if (SelfRef == LUA_NOREF) {
		return;
	}

	lua_rawgeti(L, LUA_REGISTRYINDEX, SelfRef);
	auto udptr = reinterpret_cast<GenericUserData*>(lua_touserdata(L, -1));
	udptr->flag |= UD_HADFREE;
	lua_pop(L, 1);

	luaL_unref(L, LUA_REGISTRYINDEX, SelfRef);
	SelfRef = LUA_NOREF;
}


bool LuaEntityBase::InitLua(lua_State* L)
{
	return true;
}

void LuaEntityBase::FiniLua(lua_State* L)
{
	UnrefSelf(L);
	UnbindLuaObject();
	Actor.Reset();
	EntID = KG_INVALID_ENTITY_ID;
	ActorID = KG_INVALID_ACTOR_ID;
}

void LuaEntityBase::BindActorByOwnSpawned(AActor* InActor)
{
	Actor = InActor;
	ActorID = KGUtils::GetIDByObject(InActor);
	if (IC7ActorInterface* Interface = Cast<IC7ActorInterface>(Actor)) {
		Interface->SetEntityUID(EntID);
	}

	CallLuaFunction("KG_OnCreateActor");
}

void LuaEntityBase::BindActorByLevelSpawned(AActor* InActor)
{
	Actor = InActor;
	ActorID = KGUtils::GetIDByObject(InActor);
	if (IC7ActorInterface* Interface = Cast<IC7ActorInterface>(InActor)) {
		Interface->SetEntityUID(EntID);
	}
}

void LuaEntityBase::UnbindActor()
{
	Actor.Reset();
	ActorID = KG_INVALID_ACTOR_ID;
}

AActor* LuaEntityBase::GetActor() 
{
	if (!Actor.IsValid())
	{
		return nullptr;
	}
	return Actor.Get();
}

void LuaEntityBase::BindActor(KGObjectID InActorID)
{
	ActorID = InActorID;
	Actor = KGUtils::GetActorByID(InActorID);
	if (IC7ActorInterface* Interface = Cast<IC7ActorInterface>(Actor)) {
		Interface->SetEntityUID(EntID);
	}
}
