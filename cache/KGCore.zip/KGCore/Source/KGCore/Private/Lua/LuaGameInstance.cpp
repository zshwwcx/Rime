#include "Lua/LuaGameInstance.h"

#include "Misc/KGGameInstanceBase.h"
#include "Misc/Log.h"
#include "Lua/LuaEnv.h"

using namespace NS_SLUA;

lua_State *UCommonLuaGameInstanceBase::GetLuaState() const
{ 
	if (LuaEnv.Get())
	{
        return LuaEnv->GetLuaState();
	}
    return nullptr;
}

void UCommonLuaGameInstanceBase::CacheManager(UKGBasicManager *InManager)
{ 
	LuaEnv->RegManager(InManager);
}

void ULuaGameInstance::Init(class UGameInstance *InUEGameInstance)
{
    check(InUEGameInstance);
    EngineGameInstance = Cast<UKGGameInstanceBase>(InUEGameInstance);
}


void ULuaGameInstance::Uninit() {
    EngineGameInstance = nullptr;
}


 void ULuaGameInstance::BeginPlay(UGameInstance* InGI)
{
	bIsActive = true;
	OnLuaBegin(InGI);
 }

 void ULuaGameInstance::EndPlay()
{
	if (!bIsActive)
	{
		return;
	}

	bIsActive = false;
	OnLuaEnd();
 }


void UEditorLuaGameInstanceBase::BeginPlay(UWorld *InWorld)
{
    UE_LOG(LogC7, Display, TEXT("UEditorLuaGameInstanceBase::BeginPlay: %s"), *GetPathName());
    OnLuaBegin(InWorld);
}

void UEditorLuaGameInstanceBase::EndPlay()
{
    UE_LOG(LogC7, Display, TEXT("UEditorLuaGameInstanceBase::EndPlay: %s"), *GetPathName());
    OnLuaEnd();
    SetTickableTickType(ETickableTickType::Never);
}

#pragma endregion Important

#pragma region Tick
UWorld *UEditorLuaGameInstanceBase::GetTickableGameObjectWorld() const
{
    if (GetOuter())
    {
        return GetOuter()->GetWorld();
    }

    return nullptr;
}

ETickableTickType UEditorLuaGameInstanceBase::GetTickableTickType() const
{
    return IsTemplate() ? ETickableTickType::Never : ETickableTickType::Always;
}

bool UEditorLuaGameInstanceBase::IsAllowedToTick() const { return IsValid(this) && !IsUnreachable(); }

TStatId UEditorLuaGameInstanceBase::GetStatId() const
{
    RETURN_QUICK_DECLARE_CYCLE_STAT(UEditorLuaGameInstanceBase, STATGROUP_Tickables);
}

void UEditorLuaGameInstanceBase::Tick(float DeltaTime) { OnLuaTick(DeltaTime); }

#pragma endregion Tick