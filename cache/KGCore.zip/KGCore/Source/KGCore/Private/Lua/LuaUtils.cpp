
#include "Lua/LuaUtils.h"

// 前向声明
void DumpLuaValue(lua_State* L, int index, int depth = 0);


// 递归打印Lua table内容
void DumpLuaTable(lua_State* L, int index, int depth = 0)
{
	//table 不进行多层打印
	if (depth >= 2)
	{
		return;
	}
	FString Indent;
	Indent.Append(TEXT(" "), depth * 2);

	// 检查是否是有效的table
	if (!lua_istable(L, index))
	{
		UE_LOG(LogTemp, Display, TEXT("%sNot a table"), *Indent);
		return;
	}

	// 打印table开始
	UE_LOG(LogTemp, Display, TEXT("%s{"), *Indent);

	// 首先遍历数组部分
	lua_pushnil(L);
	while (lua_next(L, index))
	{
		if (lua_type(L, -2) == LUA_TNUMBER)
		{
			int isNum;
			lua_Integer key = lua_tointegerx(L, -2, &isNum);
			if (isNum)
			{
				FString Output = FString::Printf(TEXT("%s  [%d] = "), *Indent, key);
				DumpLuaValue(L, -1, depth + 1);
				UE_LOG(LogTemp, Display, TEXT("%s,"), *Output);
			}
		}
		lua_pop(L, 1); // 移除value，保留key用于下一次迭代
	}

	// 然后遍历非数组部分
	lua_pushnil(L);
	while (lua_next(L, index))
	{
		if (lua_type(L, -2) != LUA_TNUMBER)
		{
			FString KeyStr;
			switch (lua_type(L, -2))
			{
			case LUA_TSTRING:
				KeyStr = FString(lua_tostring(L, -2));
				break;
			case LUA_TBOOLEAN:
				KeyStr = lua_toboolean(L, -2) ? TEXT("true") : TEXT("false");
				break;
			case LUA_TNIL:
				KeyStr = TEXT("nil");
				break;
			default:
				KeyStr = FString::Printf(TEXT("%s@%p"), ANSI_TO_TCHAR(lua_typename(L, lua_type(L, -2))), lua_topointer(L, -2));
				break;
			}

			FString Output = FString::Printf(TEXT("%s  [%s] = "), *Indent, *KeyStr);
			DumpLuaValue(L, -1, depth + 1);
			UE_LOG(LogTemp, Display, TEXT("%s,"), *Output);
		}
		lua_pop(L, 1); // 移除value，保留key用于下一次迭代
	}

	// 打印table结束
	UE_LOG(LogTemp, Display, TEXT("%s}"), *Indent);
}

// 打印单个Lua值
void DumpLuaValue(lua_State* L, int index, int depth)
{
	FString Indent;
	Indent.Append(TEXT(" "), depth * 2);

	switch (lua_type(L, index))
	{
	case LUA_TNIL:
		UE_LOG(LogTemp, Display, TEXT("%snil"), *Indent);
		break;
	case LUA_TBOOLEAN:
		UE_LOG(LogTemp, Display, TEXT("%s%s"), *Indent, lua_toboolean(L, index) ? TEXT("true") : TEXT("false"));
		break;
	case LUA_TLIGHTUSERDATA:
		UE_LOG(LogTemp, Display, TEXT("%slightuserdata@%p"), *Indent, lua_touserdata(L, index));
		break;
	case LUA_TNUMBER:
		UE_LOG(LogTemp, Display, TEXT("%s%f"), *Indent, lua_tonumber(L, index));
		break;
	case LUA_TSTRING:
		UE_LOG(LogTemp, Display, TEXT("%s\"%s\""), *Indent, ANSI_TO_TCHAR(lua_tostring(L, index)));
		break;
	case LUA_TTABLE:
		DumpLuaTable(L, index, depth);
		break;
	case LUA_TFUNCTION:
		UE_LOG(LogTemp, Display, TEXT("%sfunction@%p"), *Indent, lua_topointer(L, index));
		break;
	case LUA_TUSERDATA:
		UE_LOG(LogTemp, Display, TEXT("%suserdata@%p"), *Indent, lua_touserdata(L, index));
		break;
	case LUA_TTHREAD:
		UE_LOG(LogTemp, Display, TEXT("%sthread@%p"), *Indent, lua_tothread(L, index));
		break;
	default:
		UE_LOG(LogTemp, Display, TEXT("%sunknown type"), *Indent);
		break;
	}
}


void LuaTools::DumpLuaStack(lua_State* L)
{
	int top = lua_gettop(L);
	UE_LOG(LogTemp, Display, TEXT("==== Lua Stack Dump (%d elements) ===="), top);

	for (int i = 1; i <= top; i++)
	{
		FString TypeStr = ANSI_TO_TCHAR(lua_typename(L, lua_type(L, i)));
		UE_LOG(LogTemp, Display, TEXT("[%d] %s:"), i, *TypeStr);
		DumpLuaValue(L, i);
	}

	UE_LOG(LogTemp, Display, TEXT("==== End of Stack Dump ===="));

}

int64 LuaTools::CurRuntimeStrId = 0;
TMap<FString, int64> LuaTools::RuntimeStr2IdMap;
TMap<int64, FString> LuaTools::RuntimeId2StrMap;

int64 LuaTools::GetRuntimeStrId(const FString& str)
{
	if (str.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("GetRuntimeStrId: empty string key!"));
		return -1;
	}

	if (int64* Found = RuntimeStr2IdMap.Find(str))
	{
		return *Found;
	}

	const int64 NewId = ++CurRuntimeStrId;
	RuntimeStr2IdMap.Add(str, NewId);
	RuntimeId2StrMap.Add(NewId, str);
	return NewId;
}

const FString& LuaTools::GetStrById(int64 strId)
{
	if (FString* Found = RuntimeId2StrMap.Find(strId))
	{
		return *Found;
	}
	UE_LOG(LogTemp, Warning, TEXT("GetStrById: empty string key!"));
	static const FString EmptyStr(TEXT(""));
	return EmptyStr;
}