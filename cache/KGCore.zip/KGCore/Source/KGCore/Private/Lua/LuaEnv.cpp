#include "Lua/LuaEnv.h"

#include "Engine.h"
#include "CoreMinimal.h"
#include "Misc/FileHelper.h"
#include "HAL/Platform.h"
#include "HAL/PlatformFilemanager.h"
#include "Misc/FileHelper.h"
#include "Manager/KGBasicManager.h"
#include "Misc/Log.h"

#include "Lua/LuaLog.h"
#include "Lua/LuaGameInstance.h"


TArray<uint8> ULuaEnvBase::LoadLuaFileDelegate(const char *fn, FString &filepath)
{
    FString path = FPaths::ProjectContentDir();
    FString filename = UTF8_TO_TCHAR(fn);
    filename = filename.Replace(TEXT("."), TEXT("/"));
    TArray<uint8> Content;

#if WITH_EDITOR
    if (filename == "emmy_core") // emmy_core直接return,不然会加载不到dll
    {
        return MoveTemp(Content);
    }
    const FString sourceCodeScriptPath =
        FPaths::Combine(path, "Script", filename + TEXT(".lua")); // 编辑器下优先判断下有没有Script源码目录
    if (IFileManager::Get().FileExists(*sourceCodeScriptPath))
    {
        FFileHelper::LoadFileToArray(Content, *sourceCodeScriptPath);
        filepath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*sourceCodeScriptPath);
        return MoveTemp(Content);
    }

    const FString onlyDevHasPath = FPaths::Combine(path, "Script/Gameplay/GameInit/Main.lua");
    if (IFileManager::Get().FileExists(*onlyDevHasPath))
    {
        return MoveTemp(Content);
    }

    const FString sourceCodeScriptOPCodePath =
        FPaths::Combine(path, "ScriptOPCode", filename + TEXT(".lua")); // 编辑器下ScriptOPCode下的Data不编译成luac
    if (IFileManager::Get().FileExists(*sourceCodeScriptOPCodePath))
    {
        FFileHelper::LoadFileToArray(Content, *sourceCodeScriptOPCodePath);
        filepath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*sourceCodeScriptOPCodePath);
        return MoveTemp(Content);
    }
#else
#if PLATFORM_WINDOWS && !UE_BUILD_SHIPPING
    static FString LuaPath = FPlatformMisc::GetEnvironmentVariable(TEXT("KG_LUA_PATH"));
    filepath = FPaths::Combine(LuaPath, filename + TEXT(".lua"));
    if (IFileManager::Get().FileExists(*filepath))
    {
        FFileHelper::LoadFileToArray(Content, *filepath);
        return MoveTemp(Content);
    }
#endif
#if !UE_BUILD_SHIPPING
    // Cooking模式下优先从PersistentDownloadDir读取脚本,方便Cooking版本调试代码
    filepath = FPaths::Combine("Script", filename + TEXT(".lua"));
    const FString externalFullPath = FPaths::Combine(FPaths::ProjectPersistentDownloadDir(), filepath);
    if (IFileManager::Get().FileExists(*externalFullPath))
    {
        FFileHelper::LoadFileToArray(Content, *externalFullPath);
        return MoveTemp(Content);
    }
#endif
#endif
    // Script opcode dir for luac
    path /= "ScriptOPCode";
    path /= filename;
    auto fullPath = path + TEXT(".luac");
    if (IFileManager::Get().FileExists(*fullPath))
    {
        FFileHelper::LoadFileToArray(Content, *fullPath);
        filepath = fullPath;
        return MoveTemp(Content);
    }
    // Script opcode dir for lua
    fullPath = path + TEXT(".lua");
    if (IFileManager::Get().FileExists(*fullPath))
    {
        FFileHelper::LoadFileToArray(Content, *fullPath);
        filepath = fullPath;
        return MoveTemp(Content);
    }

    return MoveTemp(Content);
}


void ULuaEnvBase::CreateLuaState(const char *name, UGameInstance *InGI)
{
    LuaState = new NS_SLUA::LuaState(name, InGI);
    LuaState->setLoadFileDelegate(&ULuaEnvBase::LoadLuaFileDelegate);
    LuaState->init();
    LUA_LOG::RegisterLuaLogLib(LuaState->getLuaState());
}

void ULuaEnvBase::CloseLuaState()
{
    if (LuaState)
    {
        LuaState->close();
        delete LuaState;
        LuaState = nullptr;
    }
}

lua_State *ULuaEnvBase::GetLuaState()
{
    if (LuaState)
    {
        return LuaState->getLuaState();
    }
    return nullptr;
}

void ULuaEnvBase::RegManager(UKGBasicManager *InManager)
{
    check(InManager);

    if (Managers.Num() == 0)
    {
        Managers.AddZeroed(int(EManagerType::EMT_Max));
    }
    int idx = int(InManager->GetManagerType());
    check(idx > int(EManagerType::EMT_Null) && idx < int(EManagerType::EMT_Max));

    check(Managers[idx] == nullptr);

    Managers[idx] = InManager;

    InManager->SetLuaEnv(this);

    // TODO: 后续清理
    InManager->LuaStateName = LuaStateName;
}

UKGBasicManager *ULuaEnvBase::GetManagerByType(EManagerType InType)
{
    int idx = int(InType);
    if (!Managers.IsValidIndex(idx))
    {
        return nullptr;
    }

    return Managers[idx];
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

ULuaEnv* ULuaEnv::CreateLuaEnv(class UGameInstance* InGI)
{ 
	ULuaEnv *Env = NewObject<ULuaEnv>(); 
    Env->Init(InGI);
    return Env;
}

void ULuaEnv::DestroyLuaEnv(ULuaEnv *Env)
{
    if (!Env)
    {
        return;
    }

	Env->Uninit();
}

void ULuaEnv::Init(UGameInstance *InGI)
{
    check(InGI);
    if (LuaState)
    {
        UE_LOG(LogC7, Error, TEXT("CreateLuaState, bug LuaState is not null"));
        Uninit();
    }

    GI = InGI;
    CreateLuaState("GameLuaState", InGI);

#if WITH_EDITOR
    NS_SLUA::LuaState::SetMainLuaState(LuaState); // 创建PIE运行时虚拟机时，强制指定mainState
#endif

    // main state只能指游戏的LuaState，否则这个指向是混乱的.
    LuaState->SetMainLuaState(LuaState);

    check(LuaGI == nullptr);
    LuaGI = NewObject<ULaunchLuaGameInstance>(GI.Get());
    LuaGI->SetLuaEnv(this);
    LuaGI->Init(InGI);
}

void ULuaEnv::Uninit()
{
    if (LuaGI)
    {
        LuaGI->Uninit();
        LuaGI = nullptr;
    }

	for (TArray<UKGBasicManager*>::TIterator It(Managers); It; ++It)
    {
    	UKGBasicManager* Manager = *It;
    	if (!IsValid(Manager))
    	{
    		continue;
    	}
    
    	//暂时兼容，管理器的逆初始化都需要在lua层进行调用
    	if (Manager->GetIsActive())
    	{
    		UE_LOG(LogC7, Error, TEXT("manager:%s is not destroyed by lua, need to fix this"), *(Manager->GetFullName()));
    		Manager->NativeUninit();
    	}
    }
    Managers.Empty();

    CloseLuaState();
}

void ULuaEnv::Start()
{
    check(LuaState);
    LuaState->doFile("Launch.Launch");
}

void ULuaEnv::ChangeInstanceToGamePlay()
{
	
	check(LuaGI != nullptr);
	LuaGI->Uninit();
	LuaGI = nullptr;

	//reinit
	check(LuaGI == nullptr);
	LuaGI = NewObject<UGamePlayLuaGameInstance>(GI.Get());
	LuaGI->SetLuaEnv(this);
	LuaGI->Init(GI.Get());


}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

TArray<TWeakObjectPtr<class UEditorLuaEnv>> UEditorLuaEnv::LuaEnvs;
void UEditorLuaEnv::Init(UWorld *InWorld, UClass *InLuaGIClass, UGameInstance *InGameInstance)
{
    if (!IsValid(InWorld))
    {
        return;
    }

    Uninit();

    World = InWorld;
    InitLua(InLuaGIClass, InGameInstance);
    AddToRoot();
}

void UEditorLuaEnv::InitLua(UClass *InLuaGIClass, UGameInstance *InGameInstance)
{
    check(World.Get() != nullptr);

    CreateLuaState(TCHAR_TO_ANSI(*World->GetName()), InGameInstance);

    if (!IsValid(InLuaGIClass))
    {
        InLuaGIClass = UEditorLuaGameInstanceBase::StaticClass();
    }

	UEditorLuaEnv::LuaEnvs.Add(this);

    LuaGI = NewObject<UEditorLuaGameInstanceBase>(World.Get(), InLuaGIClass);
    LuaGI->SetLuaEnv(this);
    LuaGI->BeginPlay(World.Get());
}

void UEditorLuaEnv::Uninit()
{
    NS_SLUA::LuaState::onInitEvent.RemoveAll(this);
	
	if (LuaGI)
	{
		LuaGI->EndPlay();
		LuaGI = nullptr;
	}
	
	for (TArray<UKGBasicManager*>::TIterator It(Managers); It; ++It)
	{
		UKGBasicManager* Manager = *It;
		if (!IsValid(Manager))
		{
			continue;
		}
    
		//暂时兼容，管理器的逆初始化都需要在lua层进行调用
		if (Manager->GetIsActive())
		{
			UE_LOG(LogC7, Error, TEXT("manager:%s is not destroyed by lua, need to fix this"), *(Manager->GetFullName()));
			Manager->NativeUninit();
		}
	}
	Managers.Empty();
	
    if (bCreateWorld && World.Get())
    {
        GEngine->DestroyWorldContext(World.Get());
        World->DestroyWorld(true);
        World->MarkAsGarbage();
        World = nullptr;
    }
    bCreateWorld = false;

    CloseLuaState();

    GEngine->ForceGarbageCollection();
    UEditorLuaEnv::LuaEnvs.Remove(this);
    RemoveFromRoot();
}


UEditorLuaEnv *UEditorLuaEnv::CreateLuaEnv(UWorld *InWorld, UClass *InLuaGIClass, UGameInstance *InGameInstance)
{
    UEditorLuaEnv *Env = NewObject<UEditorLuaEnv>(InWorld);
    Env->Init(InWorld, InLuaGIClass, InGameInstance);
    Env->AddToRoot();
    return Env;
}

UEditorLuaEnv* UEditorLuaEnv::CreateLuaEnv(UClass* InLuaGIClass)
{
    UEditorLuaEnv::SLuaStateIndex += 1;
    FString WorldName = InLuaGIClass == nullptr ?
                            FString::Printf(TEXT("UEditorLuaGameInstance_%d_World"), SLuaStateIndex) :
                            FString::Printf(TEXT("%s_%d_World"), *InLuaGIClass->GetName(), SLuaStateIndex);

    // 换用引擎提供的创建接口，新版本引擎需要对世界进行初始化，否则报错
    auto World = UWorld::CreateWorld(EWorldType::EditorPreview, false, *WorldName, nullptr, true);
    if (World == nullptr)
    {
        UE_LOG(LogC7, Error,
               TEXT("UEditorLuaGameInstance::CreateLuaStateWithoutWorld : failed in creating world by name %s"),
               *WorldName);
        return nullptr;
    }
    UEditorLuaEnv *Env = NewObject<UEditorLuaEnv>(World);
    Env->Init(World, InLuaGIClass);
    Env->bCreateWorld = true;
    Env->AddToRoot();
    return Env;
}

void UEditorLuaEnv::DestroyLuaEnv(UEditorLuaEnv *Env)
{
    if (!Env)
    {
        return;
    }
    Env->Uninit();
    Env->RemoveFromRoot();
}

UEditorLuaEnv* UEditorLuaEnv::GetLuaEnv(UObject* InWorldContext)
{
    if (!IsValid(InWorldContext))
    {
    	UE_LOG(LogC7, Error, TEXT("UEditorLuaEnv::GetLuaEnv : invalid world context"));
    	return nullptr;
    }
    
    UWorld* EditorWorld = InWorldContext->GetWorld();
    if (!IsValid(EditorWorld))
    {
    	UE_LOG(LogC7, Error, TEXT("UEditorLuaEnv::GetLuaEnv : invalid world %s"), *GetNameSafe(InWorldContext));
		return nullptr;
    }
    
    for (TArray<TWeakObjectPtr<UEditorLuaEnv>>::TIterator It(UEditorLuaEnv::LuaEnvs); It; ++It)
    {
        UEditorLuaEnv *LuaEnv = It->Get();
        if (!IsValid(LuaEnv))
    	{
    		continue;
    	}
    
    	if (LuaEnv->GetOuter() == EditorWorld)
    	{
            return LuaEnv;
    	}
    }
    
    return nullptr;
}

UEditorLuaGameInstanceBase *UEditorLuaEnv::GetLuaGameInstance(UObject *InWorldContext)
{
    auto LuaEnv = GetLuaEnv(InWorldContext);
	if (LuaEnv) {
        return LuaEnv->GetLuaGameInstance();
	}
    return nullptr;
}