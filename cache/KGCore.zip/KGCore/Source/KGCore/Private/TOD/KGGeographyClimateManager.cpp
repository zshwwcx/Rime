#include "TOD/KGGeographyClimateManager.h"
#include "GeographyClimateSubsystem.h"

using namespace NS_SLUA;

const float FLOAT_SECONDS_PER_MINUTE = 60.0f;
const float FLOAT_SECONDS_PER_HOUR = FLOAT_SECONDS_PER_MINUTE * 60.0f;
const float FLOAT_SECONDS_PER_DAY = 24.0f * FLOAT_SECONDS_PER_HOUR;

int64 UKGGeographyClimateManager::GetUTCTime()
{
	FDateTime Current = FDateTime::UtcNow();
	int64 DeltaTicks = Current.GetTicks() - FDateTime(1970, 1, 1).GetTicks();
	return DeltaTicks / ETimespan::TicksPerMillisecond;
}

void UKGGeographyClimateManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	UpdateTime(DeltaTime);
}

void UKGGeographyClimateManager::UpdateTime(float DeltaTime)
{
	CleanInvalidControllers();
	CalCurrentGameTime();
	SetDateTime(DeltaTime);
	if (GeographyAndDateTimeControllers.Num() > 0)
	{
		float CurveTime = FMath::Fmod((GetUTCTime() / 1000.0 - InitServerTime) / FLOAT_SECONDS_PER_HOUR * TimeFlowSpeed + LastCurveTime, CycleTime);
		SetBloodMoon(CurveTime);
		SetPhaseAngle(CurveTime);
	}
}

void UKGGeographyClimateManager::CalCurrentGameTime()
{
	int64 _StopTime = StopTime > 0.0 ? StopTime : GetUTCTime();
	double ElapsedRealTime = FMath::Fmod(_StopTime / 1000.0 + JumpTime - InitServerTime + RealSecondsPerDay, RealSecondsPerDay);
	double GameTime = FMath::Fmod(ElapsedRealTime * FLOAT_SECONDS_PER_DAY / RealSecondsPerDay, FLOAT_SECONDS_PER_DAY);

	int32 NewHours = FMath::FloorToInt(GameTime / FLOAT_SECONDS_PER_HOUR);
	float Remainder = FMath::Fmod(GameTime, FLOAT_SECONDS_PER_HOUR);
	int32 NewMinutes = FMath::FloorToInt(Remainder / FLOAT_SECONDS_PER_MINUTE);
	if (NewHours != Hours || NewMinutes != Minutes)
	{
		OnMinChanged.ExecuteIfBound(NewHours, NewMinutes);
	}
	Hours = NewHours;
	Minutes = NewMinutes;
	Seconds = FMath::FloorToInt(FMath::Fmod(Remainder, FLOAT_SECONDS_PER_MINUTE));
}

void UKGGeographyClimateManager::SetDateTime(float DeltaTime)
{
	int64 TargetTimeInSeconds = Hours * 3600 + Minutes * 60 + Seconds;
	int64 currentTimeInSeconds = TargetTimeInSeconds;
	
	if (GeographyAndDateTimeControllers.Num() > 0 && !bUseDefaultTime)
	{
		auto defaultController = GeographyAndDateTimeControllers[0].Get();
		if (TimeDragSpeed < MAX_DRAG_SPEED)
		{
			currentTimeInSeconds = defaultController->Hours * FLOAT_SECONDS_PER_HOUR + defaultController->Minutes * FLOAT_SECONDS_PER_MINUTE + defaultController->Seconds;
			if (TargetTimeInSeconds < currentTimeInSeconds)
			{
				TargetTimeInSeconds = TargetTimeInSeconds + FLOAT_SECONDS_PER_DAY;
			}
			currentTimeInSeconds = currentTimeInSeconds + TimeDragSpeed * DeltaTime;
			if (currentTimeInSeconds >= TargetTimeInSeconds)
			{
				TimeDragSpeed = MAX_DRAG_SPEED;
				currentTimeInSeconds = TargetTimeInSeconds;
			}
		}

		auto NewHour = FMath::FloorToInt(currentTimeInSeconds / FLOAT_SECONDS_PER_HOUR);
		float Remainder = FMath::Fmod(currentTimeInSeconds, FLOAT_SECONDS_PER_HOUR);
		auto NewMin = FMath::FloorToInt(Remainder / FLOAT_SECONDS_PER_MINUTE);
		auto NewSec = FMath::FloorToInt(FMath::Fmod(Remainder, FLOAT_SECONDS_PER_MINUTE));

		for (auto& WeakController : GeographyAndDateTimeControllers)
		{
			if (auto Controller = WeakController.Get())
			{
				Controller->Hours = NewHour;
				Controller->Minutes = NewMin;
				Controller->Seconds = NewSec;
			}
		}
	}
}

void UKGGeographyClimateManager::SetBloodMoon(float curveTime)
{
	if (GeographyAndDateTimeControllers.Num() > 0)
	{
		float factor = 0.0;
		if (BloodMoonFactor > 0.0f)
		{
			factor = BloodMoonFactor;
		}
		else if (BloodMoonCurve != nullptr)
		{
			factor = BloodMoonCurve->GetFloatValue(curveTime);
		}
		for (auto& WeakController : GeographyAndDateTimeControllers)
		{
			if (auto Controller = WeakController.Get())
			{
				Controller->BloodMoonFactor = factor;
			}
		}
	}
}

void UKGGeographyClimateManager::SetPhaseAngle(float curveTime)
{
	if (GeographyAndDateTimeControllers.Num() > 0)
	{
		float factor = 180.0;
		if (PhaseAngleFactor > 0.0f)
		{
			factor = PhaseAngleFactor;
		}
		else if (PhaseAngleCurve)
		{
			factor = PhaseAngleCurve->GetFloatValue(curveTime);
		}
		for (auto& WeakController : GeographyAndDateTimeControllers)
		{
			if (auto Controller = WeakController.Get())
			{
				Controller->PhaseAngle = factor;
			}
		}
	}
}

void UKGGeographyClimateManager::NativeInit()
{
	REG_EXTENSION_METHOD(UKGGeographyClimateManager, "KAPI_GeographyClimateManager_LoadCurves", &UKGGeographyClimateManager::LoadCurves);
	REG_EXTENSION_METHOD(UKGGeographyClimateManager, "KAPI_GeographyClimateManager_LuaUpdateWeather", &UKGGeographyClimateManager::LuaUpdateWeather);
	REG_EXTENSION_METHOD(UKGGeographyClimateManager, "KAPI_GeographyClimateManager_OverrideClimateShiftSpeed", &UKGGeographyClimateManager::OverrideClimateShiftSpeed);
	REG_EXTENSION_METHOD(UKGGeographyClimateManager, "KAPI_GeographyClimateManager_RestoreClimateShiftSpeed", &UKGGeographyClimateManager::RestoreClimateShiftSpeed);
	REG_EXTENSION_METHOD(UKGGeographyClimateManager, "KAPI_GeographyClimateManager_SetGameTime", &UKGGeographyClimateManager::SetGameTime);
	REG_EXTENSION_METHOD(UKGGeographyClimateManager, "KAPI_GeographyClimateManager_GetGameTime", &UKGGeographyClimateManager::GetGameTime);
	REG_EXTENSION_METHOD(UKGGeographyClimateManager, "KAPI_GeographyClimateManager_ResetControllers", &UKGGeographyClimateManager::ResetControllers);
	REG_EXTENSION_METHOD(UKGGeographyClimateManager, "KAPI_GeographyClimateManager_ClearControllers", &UKGGeographyClimateManager::ClearControllers);
}

void UKGGeographyClimateManager::NativeUninit()
{
	OnMinChanged.Clear();
}

template<typename T>
void UKGGeographyClimateManager::FindActorsOfType(TArray<TWeakObjectPtr<T>>& OutArray)
{
	OutArray.Empty();
    
	UWorld* World = GetWorld();
	if (!World) return;
    
	TArray<AActor*> FoundActors;
	UGameplayStatics::GetAllActorsOfClass(World, T::StaticClass(), FoundActors);
    
	for (AActor* Actor : FoundActors)
	{
		if (T* TypedActor = Cast<T>(Actor))
		{
			OutArray.Add(TypedActor);
		}
	}
}

void UKGGeographyClimateManager::CleanInvalidControllers()
{
	GeographyAndDateTimeControllers.RemoveAll([](const TWeakObjectPtr<AGeographyAndDateTimeController>& Ptr)
	{
		return !Ptr.IsValid();
	});
    
	ClimateControllers.RemoveAll([](const TWeakObjectPtr<AClimateController>& Ptr)
	{
		return !Ptr.IsValid();
	});
}

#pragma region LUA_API
void UKGGeographyClimateManager::LoadCurves(const FName& BloodMoonCurveName, const FName& PhaseAngleCurveName)
{
	BloodMoonCurve = LoadObject<UCurveFloat>(nullptr, *BloodMoonCurveName.ToString());
	PhaseAngleCurve = LoadObject<UCurveFloat>(nullptr, *PhaseAngleCurveName.ToString());
}

void UKGGeographyClimateManager::LuaUpdateWeather(float Cloud, float Fog, float Wind, float Rain, float Snow,
	float Thunderstorm, float Rainbow, bool BShowFakeCloud)
{
	if (ClimateControllers.Num() > 0)
	{
		for (auto& WeakController : ClimateControllers)
		{
			if (auto Controller = WeakController.Get())
			{
				Controller->Cloud = Cloud;
				Controller->Fog = Fog;
				Controller->Wind = Wind;
				Controller->Rain = Rain;
				Controller->Snow = Snow;
				Controller->Thunderstorm = Thunderstorm;
				Controller->Rainbow = Rainbow;
			}
		}
	}

	if (GetWorld())
	{
		if (UGeographyClimateSubsystem* GeographyClimateSystem = GetWorld()->GetSubsystem<UGeographyClimateSubsystem>())
		{	
			GeographyClimateSystem->SetFakeCloudShadowSupport(BShowFakeCloud);
		}
	}
}

void UKGGeographyClimateManager::OverrideClimateShiftSpeed(float Value)
{
	if (GetWorld())
	{
		if (UGeographyClimateSubsystem* GeographyClimateSystem = GetWorld()->GetSubsystem<UGeographyClimateSubsystem>())
		{
			FClimateSpeedInfo SpeedSetting;
			SpeedSetting.BaseSunnySpeed = Value;
			SpeedSetting.CloudSpeed = Value;
			SpeedSetting.FogSpeed = Value;
			SpeedSetting.WindSpeed = Value;
			SpeedSetting.RainSpeed = Value;
			SpeedSetting.SnowSpeed = Value;
			SpeedSetting.ThunderstormSpeed = Value;
			SpeedSetting.RainbowSpeed = Value;
			GeographyClimateSystem->SetPhotoClimateSpeedInfo(SpeedSetting);
			GeographyClimateSystem->SetUsePhotoClimateSpeedInfo(true);
		}
	}
}

void UKGGeographyClimateManager::RestoreClimateShiftSpeed()
{
	if (GetWorld())
	{
		if (UGeographyClimateSubsystem* GeographyClimateSystem = GetWorld()->GetSubsystem<UGeographyClimateSubsystem>())
		{
			GeographyClimateSystem->SetUsePhotoClimateSpeedInfo(false);
		}
	}
}

void UKGGeographyClimateManager::SetGameTime(double InJumpTime, int64 InStopTime)
{
	JumpTime = InJumpTime;
	StopTime = InStopTime;
}

int32 UKGGeographyClimateManager::GetGameTime()
{
	return Hours * FLOAT_SECONDS_PER_HOUR + Minutes * FLOAT_SECONDS_PER_MINUTE + Seconds;
}

void UKGGeographyClimateManager::ResetControllers()
{
	ClearControllers();
	FindActorsOfType(GeographyAndDateTimeControllers);
	FindActorsOfType(ClimateControllers);
}

void UKGGeographyClimateManager::ClearControllers()
{
	GeographyAndDateTimeControllers.Empty();
	ClimateControllers.Empty();
}
#pragma endregion LUA_API	

