#include "KGCoreModule.h"
#include "Core.h"
#include "Modules/ModuleManager.h"
#define LOCTEXT_NAMESPACE "FKGCoreModule"
#include "UObject/CoreRedirects.h"

#if __has_include("CxxReflectionKGCore.h")
#include "CxxReflectionKGCore.h"
#endif

DEFINE_LOG_CATEGORY(LogKGCore);

void FKGCoreModule::StartupModule()
{
	UE_LOG(LogInit, Log, TEXT("KGCoreModule StartupModule!"));
#if __has_include("CxxReflectionKGCore.h") && !defined(KG_CXX_REFLECTING)
	REGISTER_LAZY_REGISTER(KGCore);
#endif
}

void FKGCoreModule::ShutdownModule()
{
}

IMPLEMENT_MODULE(FKGCoreModule, KGCore)

#undef LOCTEXT_NAMESPACE