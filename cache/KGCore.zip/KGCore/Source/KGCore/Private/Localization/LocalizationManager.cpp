#include "Localization/LocalizationManager.h"

#include "AkAudio/Public/AkAudioDevice.h"
#include "AkAudio/Classes/AkGameplayStatics.h"



#pragma region Important
ULocalizationManager* ULocalizationManager::GetInstance(UObject* InContext)
{
	//return UKGBasicManager::GetManager<ULocalizationManager>(InContext);
	return Cast<ULocalizationManager>(GetManagerByType(InContext, EManagerType::EMT_LocalizationManager));
}

void ULocalizationManager::NativeInit()
{
	Super::NativeInit();

	// 目前默认转换为中文语音
	ChangeCurrentWwiseCulture(TEXT("Simplified Chinese"));
}

#pragma endregion Important



#pragma region Wwise
void ULocalizationManager::ChangeCurrentWwiseCulture(const FString& NewCultureName)
{
	if (UAkGameplayStatics::GetCurrentAudioCulture().Equals(NewCultureName))
		return;

	// 目前只有Dialog需要转换语言，后续迭代！
	// Bruce 2023.5.10，对话语音分布到每个具体对话的Bank中了，这里不再统一加卸载
	//UAkGameplayStatics::UnloadBankByName(TEXT("Dialog"));

	FOnSetCurrentAudioCultureCallback Callback;
	Callback.BindUFunction(this, FName(TEXT("OnChangedWwiseCulture")));

	UAkGameplayStatics::SetCurrentAudioCultureAsync(NewCultureName, Callback);
}

void ULocalizationManager::OnChangedWwiseCulture(bool Result)
{
	//UAkGameplayStatics::LoadBankByName(TEXT("Dialog"));
}

#pragma endregion Wwise
