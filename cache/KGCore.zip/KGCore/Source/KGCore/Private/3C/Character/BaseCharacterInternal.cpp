#include "3C/Character/BaseCharacterInternal.h"

void ABaseCharacterInternal::BeginPlay() {
	Super::BeginPlay();
	LogicParentActorId = 0;
	LogicChildObjectIdMapping.Reset();

}

bool ABaseCharacterInternal::SetCollisionPresetForRootAndMeshComponents(bool updatedateOverlaps, const FName& SceneRoorPresetName, const FName& ChildPresetName)
{
	return IC7ActorInterface::DoSetCollisionPresetForRootAndMeshComponents(this, updatedateOverlaps, SceneRoorPresetName, ChildPresetName);
}

void ABaseCharacterInternal::SetMinLOD(int32 InNewMinLOD) {
  return IC7ActorInterface::DoSetMinLOD(this, InNewMinLOD);
}

USkeletalMeshComponent* ABaseCharacterInternal::GetMainMesh()
{
	return GetMesh();
}

UCapsuleComponent* ABaseCharacterInternal::GetCapsule()
{
	return GetCapsuleComponent();
}

UCharacterMovementComponent* ABaseCharacterInternal::GetCharacterMoveComp()
{
	return GetCharacterMovement();
}
