#include "3C/Movement/RoleMovementComponentBase.h"



bool URoleMovementComponentBase::AllowProactiveRotation() const
{
	return false;
}

bool URoleMovementComponentBase::AllowProactiveMovement() const
{
	return false;
}

bool URoleMovementComponentBase::AllowProactiveJump() const
{
	return false;
}

bool URoleMovementComponentBase::AllowMovement() const
{
	return false;
}

bool URoleMovementComponentBase::AllowRotation() const
{
	return false;
}

void URoleMovementComponentBase::ChangeDisableMeshPredict(int64 InSign, bool bDisable)
{

}

bool URoleMovementComponentBase::AllowMeshPredict() const
{
	return false;
}

void URoleMovementComponentBase::ChangeDisableRootMotionByType(int32 InTypeMask, int64 InSign, bool bDisable)
{

}

bool URoleMovementComponentBase::AllowRootMotionByTypeMask(int32 InTypeMask) const
{
	return false;
}

bool URoleMovementComponentBase::IsProactiveMoving(bool InCheckRM)
{
	return false;
}

bool URoleMovementComponentBase::IsValidProactiveMoving(bool InCheckRM)
{
	return false;
}

bool URoleMovementComponentBase::IsRunningRootMotion()
{
	return false;
}

bool URoleMovementComponentBase::IsRunningAnimRootMotion()
{
	return false;
}

bool URoleMovementComponentBase::IsRunningRootMotionSource()
{
	return false;
}
