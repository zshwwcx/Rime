#include "3C/Util/KGActorUtil.h"

#include "Components/BoxComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SphereComponent.h"
#include "Misc/ObjCrashCollector.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"

bool UKGActorUtil::IsActorHidden(AActor* Actor)
{
	if (!IsValid(Actor))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::IsActorHidden, invalid actor"));
		return false;
	}

	return Actor->IsHidden();
}

USkeletalMeshComponent* UKGActorUtil::GetCharacterMesh(ACharacter* Character)
{
	if (!IsValid(Character))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::GetCharacterMesh, invalid Character"));
		return nullptr;
	}

	return Character->GetMesh();
}

USceneComponent* UKGActorUtil::GetComponentByNameAndClass(
	AActor* InActor, const FName& InName, UClass* InClass, bool bNoChild)
{
	if (!IsValid(InActor))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::GetComponentByNameAndClass, invalid Actor"));
		return nullptr;
	}

	// todo 目前很多数据都在用这种方式去获取组件, 这块后续要改掉
	if (FProperty* Prop = InActor->GetClass()->FindPropertyByName(InName))
	{
		if (UObject* ObjectValue = CastField<FObjectProperty>(Prop)->GetObjectPropertyValue_InContainer(InActor))
		{
			if (USceneComponent* Component = Cast<USceneComponent>(ObjectValue))
			{
				return Component;
			}
		}
	}
	
	TArray<USceneComponent*> AllSceneComps;
	InActor->GetComponents<USceneComponent>(AllSceneComps);
	for (int32 i = 0; i < AllSceneComps.Num(); ++i)
	{
		USceneComponent* Component = AllSceneComps[i];
		if (Component && (Component->GetFName().IsEqual(InName) || Component->ComponentHasTag(InName)) && (!InClass || Component->GetClass()->IsChildOf(InClass)))
		{
			return Component;
		}
	}
	
	if (!bNoChild)
	{
		TArray<AActor*> AttachedActors;
		InActor->GetAttachedActors(AttachedActors, true, false);

		for (int32 i = 0; i < AttachedActors.Num(); ++i)
		{
			AActor* SubActor = AttachedActors[i];
			if (!SubActor)
			{
				continue;
			}

			SubActor->GetComponents<USceneComponent>(AllSceneComps);
			for (int32 j = 0; j < AllSceneComps.Num(); ++j)
			{
				USceneComponent* Component = AllSceneComps[j];
				if (!Component)
				{
					continue;
				}

				if (!Component->IsAttachedTo(InActor->GetRootComponent()))
				{
					continue;
				}

				if ((Component->GetFName().IsEqual(InName) || Component->ComponentHasTag(InName)) && (!InClass || Component->GetClass()->IsChildOf(InClass)))
				{
					return Component;
				}
			}
		}
	}

	return nullptr;
}

USceneComponent* UKGActorUtil::GetComponentBySocket(AActor* InActor, const FName& InSocket, bool bNoChild)
{
	if (!IsValid(InActor))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::GetComponentBySocket, invalid Actor"));
		return nullptr;
	}

	if (InSocket.IsNone())
	{
		return InActor->GetRootComponent();
	}

	TArray<USceneComponent*> Components;
	InActor->GetComponents<USceneComponent>(Components);
	for (int32 i = 0; i < Components.Num(); ++i)
	{
		USceneComponent* Component = Components[i];
		if (Component && Component->GetAllSocketNames().Contains(InSocket))
		{
			return Component;
		}
	}

	// 只找一层子Actor，不进行深层递归
	if (!bNoChild)
	{
		TArray<AActor*> AttachedActors;
		InActor->GetAttachedActors(AttachedActors, true, false);

		for (int32 i = 0; i < AttachedActors.Num(); ++i)
		{
			AActor* SubActor = AttachedActors[i];
			if (!SubActor)
			{
				continue;
			}

			SubActor->GetComponents<USceneComponent>(Components);
			for (int32 j = 0; j < Components.Num(); ++j)
			{
				USceneComponent* Component = Components[j];
				if (!Component)
				{
					continue;
				}

				if (!Component->IsAttachedTo(InActor->GetRootComponent()))
				{
					continue;
				}

				if (Component->DoesSocketExist(InSocket))
				{
					return Component;
				}
			}
		}
	}

	return InActor->GetRootComponent();
}

TArray<UActorComponent*> UKGActorUtil::GetComponentsByClasses(AActor* InActor, const TArray<UClass*>& InValidClasses, bool bIncludeChildActors)
{
	c7_obj_check(InActor);
	
	TArray<UActorComponent*> Components;
	if (!IsValid(InActor))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::GetComponentsByClasses, invalid actor"));
		return Components;
	}

	if (InValidClasses.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::GetComponentsByClasses, invalid component classes"));
		return Components;
	}
	
	InActor->ForEachComponent(bIncludeChildActors, [&Components, &InValidClasses](UActorComponent* Comp)
		{
			if (Comp)
			{
				for (const auto& InValidClass : InValidClasses)
				{
					if (InValidClass && Comp->IsA(InValidClass))
					{
						Components.Add(Comp);
						break;
					}
				}
			}
		});

	return Components;
}

void UKGActorUtil::SetActorTransform(
	AActor* InActor,
	float LocX, float LocY, float LocZ,
	float RotX, float RotY, float RotZ, float RotW,
	float ScaleX, float ScaleY, float ScaleZ)
{
	c7_obj_check(InActor);
	if (!IsValid(InActor))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::SetActorTransform, invalid Actor"));
		return;
	}

	FTransform Transform;
	
	const auto& Loc = FVector(LocX, LocY, LocZ);
	check(!Loc.ContainsNaN());
	Transform.SetLocation(Loc);
	
	const auto& Quat = FQuat(RotX, RotY, RotZ, RotW);
	check(!Quat.ContainsNaN());
	Transform.SetRotation(Quat);

	const auto& Scale = FVector(ScaleX, ScaleY, ScaleZ);
	check(!Scale.ContainsNaN());
	Transform.SetScale3D(Scale);

	InActor->SetActorTransform(Transform);
}

void UKGActorUtil::AddInstanceComponent(AActor* Actor, UActorComponent* Component)
{
	if (!IsValid(Actor) || !IsValid(Component))
	{
		return;
	}

	Actor->AddInstanceComponent(Component);
}

void UKGActorUtil::AddActorTag(AActor* Actor, FName InTag, bool bAddIfNotExist)
{
	if (!IsValid(Actor))
	{
		UE_LOG(LogTemp, Error, TEXT("UKGActorUtil::AddActorTag, invalid Actor"));
		return;
	}

	if (bAddIfNotExist)
	{
		Actor->Tags.AddUnique(InTag);
	}
	else
	{
		Actor->Tags.Add(InTag);
	}
}

FVector UKGActorUtil::V2GetActorBottomLocation(AActor* InActor, bool bRelation)
{
	if (!InActor || !InActor->GetRootComponent())
	{
		return FVector::ZeroVector;
	}

	FVector UpVec = bRelation ? FVector::UpVector : InActor->GetActorUpVector();
	if (USphereComponent* Sphere = Cast<USphereComponent>(InActor->GetRootComponent()))
	{
		return bRelation ? -UpVec * Sphere->GetScaledSphereRadius() : Sphere->GetComponentLocation() - UpVec * Sphere->GetScaledSphereRadius();
	}
	else if (UCapsuleComponent* Capsule = Cast<UCapsuleComponent>(InActor->GetRootComponent()))
	{
		return bRelation ? -UpVec * Capsule->GetScaledCapsuleHalfHeight() : Capsule->GetComponentLocation() - UpVec * Capsule->GetScaledCapsuleHalfHeight();
	}
	else if (UBoxComponent* Box = Cast<UBoxComponent>(InActor->GetRootComponent()))
	{
		float UpDot = FMath::Abs(UpVec.Dot(Box->GetUpVector()));
		float RightDot = FMath::Abs(UpVec.Dot(Box->GetRightVector()));
		float ForwardDot = FMath::Abs(UpVec.Dot(Box->GetForwardVector()));

		float Length = 0.0f;
		if (UpDot > RightDot && UpDot > ForwardDot)
		{
			Length = Box->GetScaledBoxExtent().Z;
		}
		else if (RightDot > UpDot && RightDot > ForwardDot)
		{
			Length = Box->GetScaledBoxExtent().Y;
		}
		else
		{
			Length = Box->GetScaledBoxExtent().X;
		}

		return bRelation ? -UpVec * Length : Box->GetComponentLocation() - UpVec * Length;
	}

	return bRelation ? FVector::ZeroVector : InActor->GetRootComponent()->GetComponentLocation();
}
