#include "3C/Util/KGUtils.h"
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Misc/CommonDefines.h"

KGObjectID KGUtils::GetIDByObject(UObject* InObj)
{
	if (InObj == nullptr)
	{
		return KG_INVALID_ID;
	}

	if (IsValid(InObj) == false)
	{
		return KG_INVALID_ID;
	}

	TWeakObjectPtr ptr = InObj;
	if (ptr.IsValid() == false)
	{
		return KG_INVALID_ID;
	}

	return ptr.KGGetObjectID();
}

UObject* KGUtils::GetObjectByID(KGObjectID InID)
{
	TWeakObjectPtr ptr;
	ptr.KGSetObjectID(InID);
	return ptr.Get();
}

AActor* KGUtils::GetActorByID(KGObjectID InID)
{
	UObject* obj = GetObjectByID(InID);
	return Cast<AActor>(obj);
}

KGObjectID KGUtils::GetIDByClass(UClass* InClass)
{
	return GetIDByObject(InClass);
}

UClass* KGUtils::GetClassByID(KGObjectID InID)
{
	return Cast<UClass>(GetObjectByID(InID));
}