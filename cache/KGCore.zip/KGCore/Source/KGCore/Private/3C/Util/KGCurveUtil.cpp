#include "3C/Util/KGCurveUtil.h"

#include "Misc/ObjCrashCollector.h"
#include "Engine/CurveTable.h"

bool UKGCurveUtil::GetRichCurveTableValues(UCurveTable* CurveTable, float InTime, TMap<FName, float>& OutValues)
{
	c7_obj_check(CurveTable);
	if (!IsValid(CurveTable))
	{
		UE_LOG(LogTemp, Error, TEXT("Curve table is invalid"));
		return false;
	}

	OutValues.Empty();
	for (const auto& RichCurveRow : CurveTable->GetRichCurveRowMap())
	{
		OutValues.Add(RichCurveRow.Key, RichCurveRow.Value->Eval(InTime));
	}
	
	return true;
}

bool UKGCurveUtil::GetSimpleCurveTableValues(UCurveTable* CurveTable, float InTime, TMap<FName, float>& OutValues)
{
	c7_obj_check(CurveTable);
	if (!IsValid(CurveTable))
	{
		UE_LOG(LogTemp, Error, TEXT("Curve table is invalid"));
		return false;
	}

	OutValues.Empty();
	for (const auto& SimpleCurveRow : CurveTable->GetSimpleCurveRowMap())
	{
		OutValues.Add(SimpleCurveRow.Key, SimpleCurveRow.Value->Eval(InTime));
	}
	
	return true;
}

bool UKGCurveUtil::GetRichCurveTableValue(UCurveTable* CurveTable, float InTime, FName ParamName, float& OutValue)
{
	c7_obj_check(CurveTable);
	if (!IsValid(CurveTable))
	{
		UE_LOG(LogTemp, Error, TEXT("Curve table is invalid"));
		return false;
	}

	const auto& RichCurveRowMap = CurveTable->GetRichCurveRowMap();
	if (!RichCurveRowMap.Contains(ParamName))
	{
		UE_LOG(LogTemp, Error, TEXT("Curve table param invalid %s"), *ParamName.ToString());
		return false;
	}

	FRichCurve* RichCurve = RichCurveRowMap[ParamName];
	c7_obj_check(RichCurve);
	if (!RichCurve)
	{
		UE_LOG(LogTemp, Error, TEXT("Curve table curve invalid %s"), *ParamName.ToString());
		return false;
	}

	OutValue = RichCurve->Eval(InTime);
	return true;
}

bool UKGCurveUtil::GetSimpleCurveTableValue(UCurveTable* CurveTable, float InTime, FName ParamName, float& OutValue)
{
	c7_obj_check(CurveTable);
	if (!IsValid(CurveTable))
	{
		UE_LOG(LogTemp, Error, TEXT("Curve table is invalid"));
		return false;
	}

	const auto& SimpleCurveRowMap = CurveTable->GetSimpleCurveRowMap();
	if (!SimpleCurveRowMap.Contains(ParamName))
	{
		UE_LOG(LogTemp, Error, TEXT("Curve table param invalid %s"), *ParamName.ToString());
		return false;
	}

	FSimpleCurve* SimpleCurve = SimpleCurveRowMap[ParamName];
	c7_obj_check(SimpleCurve);
	if (!SimpleCurve)
	{
		UE_LOG(LogTemp, Error, TEXT("Curve table curve invalid %s"), *ParamName.ToString());
		return false;
	}

	OutValue = SimpleCurve->Eval(InTime);
	return true;
}

