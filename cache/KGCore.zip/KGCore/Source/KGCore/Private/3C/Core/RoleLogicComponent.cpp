#include "3C/Core/RoleLogicComponent.h"

URoleLogicComponent::URoleLogicComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = true;
}
