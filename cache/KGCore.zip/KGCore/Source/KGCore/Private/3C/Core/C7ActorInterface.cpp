#include "3C/Core/C7ActorInterface.h"

#include "Components/BoxComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/MeshComponent.h"
#include "Components/SkinnedMeshComponent.h"
#include "Manager/KGObjectActorManager.h"


DEFINE_LOG_CATEGORY_STATIC(IC7ActorInterfaceLog, Log, All);

USkeletalMeshComponent* IC7ActorInterface::GetMainMesh()
{
	return nullptr;
}

class UCapsuleComponent* IC7ActorInterface::GetCapsule()
{
	return nullptr;
}

bool IC7ActorInterface::DoSetCollisionPresetForRootAndMeshComponents(AActor* actor, bool updatedateOverlaps, const FName& SceneRoorPresetName, const FName& ChildPresetName) {
	if (!actor) {
		ensureAlwaysMsgf(false, TEXT("[C7ActorInterface::SetCollisionPresetForRootAndMeshComponents]  Invalid Actor"));
		return false;
	}

	USceneComponent* rootCom = actor->GetRootComponent();
	if (!rootCom) {
		ensureAlwaysMsgf(false, TEXT("[ABaseCharacter::SetCollisionPresetForPrimitiveComponents]  Has No Scene Root, PresetName:%s"), *SceneRoorPresetName.ToString());
		return false;
	}

	// @shijingzhe: 如果有BoxComp,则跟随Root保持一样的碰撞预设,目前只有一个
	UBoxComponent* BoxComp = actor->GetComponentByClass<UBoxComponent>();

	UPrimitiveComponent* rootPrimCom = Cast<UPrimitiveComponent>(rootCom);

	if (rootPrimCom) {
		rootPrimCom->SetCollisionProfileName(SceneRoorPresetName, updatedateOverlaps);
		if (BoxComp)
		{
			BoxComp->SetCollisionProfileName(SceneRoorPresetName, updatedateOverlaps);
		}
	}

	TArray<UMeshComponent*> AllPrimComponents;
	actor->GetComponents(AllPrimComponents);

	for (auto curPrimComPtr : AllPrimComponents) {
		if (curPrimComPtr == rootCom) {
			continue;
		}
		curPrimComPtr->SetCollisionProfileName(ChildPresetName, updatedateOverlaps);

	}
	return true;
}

void IC7ActorInterface::DoSetMinLOD(AActor* actor, int32 InNewMinLOD) {
  TArray<USkinnedMeshComponent*> SkinnedMeshComponents;
  actor->GetComponents(SkinnedMeshComponents);
  for (USkinnedMeshComponent* meshComponent : SkinnedMeshComponents) {
    meshComponent->OverrideMinLOD(InNewMinLOD);
  }
}

void IC7ActorInterface::DoSetTagFromRootAndMeshComps(AActor* InActor, const FString& InTag)
{
	if (!IsValid(InActor))
	{
		return;
	}

	if (InTag.IsEmpty())
	{
		return;
	}

	FName NewTag(InTag);

	if (USceneComponent* RootComp = InActor->GetRootComponent())
	{
		RootComp->ComponentTags.AddUnique(NewTag);
	}

	TArray<UMeshComponent*> Components;
	InActor->GetComponents<UMeshComponent>(Components);
	for (auto& Comp : Components)
	{
		Comp->ComponentTags.AddUnique(NewTag);
	}
}


bool IC7ActorInterface::AddAttachToLogicParent(IC7ActorInterface * ParentActor)
{

	if (!ParentActor) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::AddAttachToParent  Logic Parent Need To Be IC7ActorInterface"));
#endif
		return false;
	}

	UObject* ownObjectPtr = Cast<UObject>(this);
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(ownObjectPtr);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("IC7ActorInterface::AddAttachToParent: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return false;
	}

	int64 parentObjId = UOAM->GetIDByObejct(Cast<UObject>(ParentActor));

	if (parentObjId == KG_INVALID_ID)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("IC7ActorInterface::AddAttachToParent: Unexpected Lifetime For Object ."));
#endif
		return false;
	}


	int64 currentLogicParent = GetLoigcParent();
	if (parentObjId == currentLogicParent) {
		return true;
	}

	if (currentLogicParent != KG_INVALID_ID)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("ABaseCharacter::AddAttachToParent  LogicParent is not nullptr ,call RemoveAttachFromParent firstly"));
#endif
		return false;
	}

	
	int64* parentToModiferPtr = GetLoigcParentInnerForModify();
	if (!parentToModiferPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::AddAttachToParent  Unpexcted Implementation"));
#endif
	}
	

	TMap<int64, int32>* childMapOfParentPtr = ParentActor->GetLogicChildMaskMap();
	if (!childMapOfParentPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::AddAttachToParent  Unpexcted Implementation"));
#endif
		return false;
	}

	int64 objectId = UOAM->GetIDByObejct(ownObjectPtr);

	if (objectId == KG_INVALID_ID)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("IC7ActorInterface::AddAttachToParent: Unexpected Lifetime For Object ."));
#endif
		return false;
	}

	*parentToModiferPtr = parentObjId;
	childMapOfParentPtr->Emplace(objectId, 0);

	return true;

}

bool IC7ActorInterface::AddAttachToLogicParent(int64 parentObjId) {
	UObject* ownObjectPtr = Cast<UObject>(this);
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(ownObjectPtr);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::AddAttachToLogicParent: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return false;
	}
	
	IC7ActorInterface* ParentActor = Cast<IC7ActorInterface>(UOAM->GetObjectByID(parentObjId));

	if (!ParentActor) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::AddAttachToLogicParent  Logic Parent Need To Be IC7ActorInterface"));
#endif
		return false;
	}
	
	return AddAttachToLogicParent(ParentActor);

}


bool IC7ActorInterface::RemoveAttachFromLogicParent()
{

	int64 logicParent = GetLoigcParent();
	if (logicParent == KG_INVALID_ID) {
		return true;
	}

	UObject* ownObjectPtr = Cast<UObject>(this);
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(ownObjectPtr);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::RemoveAttachFromLogicParent: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return false;
	}
	
	int64 * parentToModiferPtr = GetLoigcParentInnerForModify();
	if (!parentToModiferPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::RemoveAttachFromLogicParent  Unpexcted Implementation"));
#endif
	}
	

	IC7ActorInterface * parent = Cast<IC7ActorInterface>(UOAM->GetObjectByID(*parentToModiferPtr));
	if (!parent) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("IC7ActorInterface::RemoveAttachFromLogicParent  Parent Unpexcted Implementation"));
#endif
		return false;
	}

	auto * childMapOfParentPtr = parent->GetLogicChildMaskMap();
	if (!childMapOfParentPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::RemoveAttachFromLogicParent  Unpexcted Implementation"));
#endif
		return false;
	}

	*parentToModiferPtr = KG_INVALID_ID;
	childMapOfParentPtr->Remove(UOAM->GetIDByObejct(ownObjectPtr));
	return true;


}

void IC7ActorInterface::RemoveAllLogicChild() {
	auto* childMapPtr = GetLogicChildMaskMap();
	if (!childMapPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::RemoveAllLogicChild  Unpexcted Implementation"));
#endif
		return ;
	}
	
	UObject* ownObjectPtr = Cast<UObject>(this);
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(ownObjectPtr);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::RemoveAllLogicChild: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return;
	}

	TArray<int64> keyActors;
	childMapPtr->GetKeys(keyActors);
	for (int64 childObjID : keyActors) {
		IC7ActorInterface* childActor = Cast<IC7ActorInterface>(UOAM->GetObjectByID(childObjID));
		if (!childActor) {
			continue;
		}

		childActor->RemoveAttachFromLogicParent();
	}

	childMapPtr->Reset();
	return;
}


bool IC7ActorInterface::HasLogicChild(IC7ActorInterface* childActor) {
	auto* childMapPtr = GetLogicChildMaskMap();
	if (!childMapPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::HasLogicChild  Unpexcted Implementation"));
#endif
		return false;
	}


	UObject* ownObjectPtr = Cast<UObject>(this);
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(ownObjectPtr);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::HasLogicChild: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return false;
	}

	return childMapPtr->Contains(UOAM->GetIDByObejct(Cast<UObject>(childActor)));
}

bool IC7ActorInterface::HasLogicChild(int64 logicObjectId) {
	auto* childMapPtr = GetLogicChildMaskMap();
	if (!childMapPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::HasLogicChild  Unpexcted Implementation"));
#endif
		return false;
	}


	return childMapPtr->Contains(logicObjectId);
}


bool IC7ActorInterface::EnableLogicFeatureSynchronizeToChilds(int64 CharacterID, int32 stateMask)
{

	auto* childMapPtr = GetLogicChildMaskMap();
	if (!childMapPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::EnableLogicFeatureSynchronizeToChilds  Unpexcted Implementation"));
#endif
		return false;
	}
	if (!childMapPtr->Contains(CharacterID)) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("IC7ActorInterface::EnableLogicFeatureSynchronizeToChilds  No Parent-Child Attach"));
#endif
		return false;
	}
	
	(*childMapPtr)[CharacterID] = (*childMapPtr)[CharacterID] | stateMask;
	return true;
}

bool IC7ActorInterface::DisableLogicFeatureSynchronizeToChilds( int64 CharacterID, int32 stateMask)
{
	auto* childMapPtr = GetLogicChildMaskMap();
	if (!childMapPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::DisableLogicFeatureSynchronizeToChilds  Unpexcted Implementation"));
#endif
		return false;
	}
	if (!childMapPtr->Contains(CharacterID)) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("IC7ActorInterface::DisableLogicFeatureSynchronizeToChilds  No Parent-Child Attach"));
#endif
		return false;
	}

	(*childMapPtr)[CharacterID] = (*childMapPtr)[CharacterID] &(~stateMask);
	return true;
}


bool IC7ActorInterface::IsLogicFeatureSynchronizeToChilds(int64 childID, int32 stateMask)
{
	auto* childMapPtr = GetLogicChildMaskMap();
	if (!childMapPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::IsLogicFeatureSynchronizeToChilds  Unpexcted Implementation"));
#endif
		return false;
	}
	if (!childMapPtr->Contains(childID)) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("IC7ActorInterface::IsLogicFeatureSynchronizeToChilds  No Parent-Child Attach"));
#endif
		return false;
	}

	return ((*childMapPtr)[childID] & (stateMask)) > 0;

}

bool IC7ActorInterface::IsLogicFeatureSynchronizeToChilds(AActor* actor, int32 stateMask)
{
	UObject* ownObjectPtr = Cast<UObject>(this);
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(ownObjectPtr);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Log, TEXT("IC7ActorInterface::IsLogicFeatureSynchronizeToChilds: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return false;
	}


	return IsLogicFeatureSynchronizeToChilds(UOAM->GetIDByObejct(actor), stateMask);
}

void IC7ActorInterface::ForEachLogicChildDoLogicSynchronize(int32 logicStateMask, TFunctionRef<void(IC7ActorInterface*)> Operation) {
	auto* childMapPtr = GetLogicChildMaskMap();
	if (!childMapPtr) {
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::ForEachLogicChildDoLogicSynchronize  Unpexcted Implementation"));
#endif
		return ;
	}

	UObject* ownObjectPtr = Cast<UObject>(this);
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(ownObjectPtr);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(IC7ActorInterfaceLog, Error, TEXT("IC7ActorInterface::ForEachLogicChildDoLogicSynchronize: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return ;
	}

	for (auto pair : *childMapPtr) {
		if (0 == (pair.Value & logicStateMask)) {
			continue;
		}
		
		UObject* child = UOAM->GetObjectByID(pair.Key);
		if (!child) {
#if !UE_BUILD_SHIPPING
			UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("IC7ActorInterface::ForEachLogicChildDoLogicSynchronize: Unexpected Lifetime For Child:%d ."), pair.Key);
#endif
			continue;
		}

		IC7ActorInterface* logicChild = Cast<IC7ActorInterface>(child);
		if (!logicChild) {
#if !UE_BUILD_SHIPPING
			UE_LOG(IC7ActorInterfaceLog, Warning, TEXT("IC7ActorInterface::ForEachLogicChildDoLogicSynchronize: Not A IC7ActorInterfer:%d ."), pair.Key);
#endif
			continue;
		}

		Operation(logicChild);

	}
	return;

}
