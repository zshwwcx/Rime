// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/KGUserWidgetAnimComponent.h"
#include "Compilation/MovieSceneCompiledDataManager.h"
#include "Components/PanelSlot.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"

//收集动画资源.//
void UKGUserWidgetAnimComponent::RefreshAnimationsAvaliable()
{
	AnimationsMap.Empty();
	AnimsAvaliable.Empty();

	for (TArray<TSubclassOf<UUserWidget>>::TIterator Iter = AnimWBPs.CreateIterator(); Iter; ++Iter)
	{
		UWidgetBlueprintGeneratedClass* WidgetClass = Cast<UWidgetBlueprintGeneratedClass>((*Iter).Get());
		if (WidgetClass != nullptr)
		{
			for (TArray<TObjectPtr<UWidgetAnimation>>::TIterator Iter2 = WidgetClass->Animations.CreateIterator(); Iter2
			     ; ++Iter2)
			{
				if (*Iter2)
				{
					UWidgetAnimation* Anim = *Iter2;
					if (Anim)
					{
						if (!AnimsAvaliable.Contains(Anim->GetName()))
						{
							Anim->SetFlags(RF_Public);
							AnimationsMap.Add(Anim->GetName(), Anim);
							AnimsAvaliable.Add(Anim->GetName());
						}
					}
					
				}
				
			}
		}
	}
}

//因为UWidgetAnimation实例中会Cache动画过程的状态,
//所以播放动画之前需要复制一份动画,避免播放冲突
//而且在复制创建的过程中也需要对动画中绑定的WidgetName进行替换
// UWidgetAnimation* UKGUserWidgetAnimComponent::CreateAnim(FName ToControllerName, FString AnimationName)
// {
// 	UWidgetAnimation** CloneFrom = nullptr;
// 	UWidgetAnimation* NewAnim = NewObject<UWidgetAnimation>(this);
// 	for (TArray<FBindingSetting>::TIterator Iter = AnimBindingSettings.CreateIterator(); Iter; ++Iter)
// 	{
// 		FBindingSetting& BindingSetting = *Iter;
// 		const TMap<FName, FName>& Redirects = BindingSetting.Redirects;
// 		if (BindingSetting.AnimationName == AnimationName)
// 		{
// 			CloneFrom = AnimationsMap.Find(BindingSetting.AnimationName);
// 			if (CloneFrom != nullptr)
// 			{
// 				NewAnim->DefaultCompletionMode = (*CloneFrom)->DefaultCompletionMode;
// #if WITH_EDITOR
// 				NewAnim->SetDisplayLabel((*CloneFrom)->GetDisplayLabel());
// #endif
// 				UMovieSceneCompiledDataManager* PrecompiledData = UMovieSceneCompiledDataManager::GetPrecompiledData();
//				PrecompiledData->CopyCompiledData(*CloneFrom);
// 				PrecompiledData->LoadCompiledData(NewAnim);
// 				NewAnim->MovieScene = (*CloneFrom)->MovieScene;
//
// 				NewAnim->AnimationBindings.Empty();
// 				for (TArray<FWidgetAnimationBinding>::TConstIterator It = (*CloneFrom)->AnimationBindings.
// 					     CreateConstIterator(); It; ++It)
// 				{
// 					if (ToControllerName == *Redirects.Find((*It).WidgetName))
// 					{
// 						FWidgetAnimationBinding NewBinding;
// 						NewBinding.AnimationGuid = (*It).AnimationGuid;
// 						NewBinding.bIsRootWidget = (*It).bIsRootWidget;
// 						NewBinding.WidgetName = ToControllerName;
// 						if (!(*It).SlotWidgetName.IsNone())
// 						{
// 							
// 							UWidget* Widget = Cast<UUserWidget>(GetOuter())->GetWidgetFromName(NewBinding.WidgetName);
// 							if (Widget != nullptr)
// 								NewBinding.SlotWidgetName = FName(*Widget->Slot->GetName()); //对绑定的Slot进行重定向.
// 						}
// 						NewAnim->AnimationBindings.Add(NewBinding);
// 						return NewAnim;
// 					}
// 					else
// 					{
// 						break;
// 					}
// 				}
// 			}
// 			else
// 			{
// 				break;
// 			}
// 		}
// 	}
// 	return NewAnim;
// }

/*void UKGUserWidgetAnimComponent::PlayAnimationsAtStart()
{
	//UWidgetAnimation* Anim = CreateAnim("Btn_Test_lua", "BGColorAnimation_INST");
	UWidgetAnimation* Anim = CreateAnim("Btn_Test_lua", "FontColorAnimation_INST");
	PlayAnimation(Anim);
}*/

bool UKGUserWidgetAnimComponent::Initialize()
{
	bool rt = Super::Initialize();
	RefreshAnimationsAvaliable(); //根据引用的白板WBP收集可用动画资源
	CleanUnavaliableAnimationSettings(); //编辑器里美术可能会移除引用的白板WBP,所以做一下配置清理
	RefreshAnimationSettings(); //刷新一下新增引用的白板WBP的默认配置,方便美术在Detail里进行配置修改.
	return rt;
}

void UKGUserWidgetAnimComponent::NativeConstruct()
{
	Super::NativeConstruct();
}

#if WITH_EDITOR
void UKGUserWidgetAnimComponent::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.MemberProperty != nullptr)
	{
		FString PropertyName = PropertyChangedEvent.MemberProperty->GetName();
		if (PropertyName == TEXT("AnimWBPs"))
		{
			RefreshAnimationsAvaliable(); //刷新一下可用的动画资源
			CleanUnavaliableAnimationSettings(); //清理移除用的动画资源的配置
		}
		else if (PropertyName == TEXT("AnimBindingSettings"))
		{
			RefreshAnimationSettings(); //动画绑定设置修改后,有可能是数组新增了一项.
		}
	}
	Super::PostEditChangeProperty( PropertyChangedEvent);
}
#endif

void UKGUserWidgetAnimComponent::CleanUnavaliableAnimationSettings()
{
	for (int Index = AnimBindingSettings.Num() - 1; Index >= 0; --Index)
	{
		if (!AnimationsMap.Contains(AnimBindingSettings[Index].AnimationName))
			AnimBindingSettings.RemoveAt(Index);
	}
}

void UKGUserWidgetAnimComponent::RefreshAnimationSettings()
{
	for (TArray<FBindingSetting>::TIterator Iter = AnimBindingSettings.CreateIterator(); Iter; ++Iter)
	{
		FBindingSetting& BindingSetting = *Iter;
		if (!BindingSetting.AnimationName.IsEmpty())
		{
			UWidgetAnimation** WidgetAnim = AnimationsMap.Find(BindingSetting.AnimationName);
			if (WidgetAnim != nullptr && (*WidgetAnim)->AnimationBindings.Num() > 0)
			{
				for (TArray<FWidgetAnimationBinding>::TIterator Iter2 = (*WidgetAnim)->AnimationBindings.
					     CreateIterator(); Iter2; ++Iter2)
				{
					FWidgetAnimationBinding& BindingInfo = *Iter2;

					if (!BindingSetting.Redirects.Contains(BindingInfo.WidgetName))
					{
						UWidget* Widget = Cast<UUserWidget>(GetOuter())->GetWidgetFromName(BindingInfo.WidgetName);
						if (Widget != nullptr)
							BindingSetting.Redirects.Add(BindingInfo.WidgetName, BindingInfo.WidgetName);
						else
							BindingSetting.Redirects.Add(BindingInfo.WidgetName, TEXT(""));
					}
				}
			}
		}
	}

	TArray<FName> RedirectsToRemove;
	for (int Index = AnimBindingSettings.Num() - 1; Index >= 0; --Index)
	{
		FBindingSetting& BindingSetting = AnimBindingSettings[Index];
		UWidgetAnimation** Anim = AnimationsMap.Find(BindingSetting.AnimationName);
		if (Anim != nullptr)
		{
			RedirectsToRemove.Empty();
			for (TMap<FName, FName>::TIterator Iter = BindingSetting.Redirects.CreateIterator(); Iter; ++Iter)
			{
				bool IsExsited = false;
				for (TArray<FWidgetAnimationBinding>::TIterator Iter2 = (*Anim)->AnimationBindings.CreateIterator();
				     Iter2; ++Iter2)
				{
					if ((*Iter2).WidgetName == Iter.Key())
					{
						IsExsited = true;
						break;
					}
				}
				if (!IsExsited)
					RedirectsToRemove.Add(Iter.Key());
			}

			for (TArray<FName>::TIterator Iter = RedirectsToRemove.CreateIterator(); Iter; ++Iter)
			{
				BindingSetting.Redirects.Remove(*Iter);
			}
		}
	}
}
