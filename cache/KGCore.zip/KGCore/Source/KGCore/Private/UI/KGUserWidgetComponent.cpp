// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/KGUserWidgetComponent.h"


bool UKGUserWidgetComponent::Initialize()
{
	return true;
}

void UKGUserWidgetComponent::NativePreConstruct()
{
}

void UKGUserWidgetComponent::NativeConstruct()
{
}

void UKGUserWidgetComponent::NativeDestruct()
{
}

void UKGUserWidgetComponent::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	
}

