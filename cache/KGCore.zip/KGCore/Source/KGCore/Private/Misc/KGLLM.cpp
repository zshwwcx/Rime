#include "Misc/KGLLM.h"
#include "HAL/LowLevelMemStats.h"



#if ENABLE_LOW_LEVEL_MEM_TRACKER
DECLARE_LLM_MEMORY_STAT(TEXT("BattleSystem"), STAT_BSLLM, STATGROUP_LLM);
DECLARE_LLM_MEMORY_STAT(TEXT("BSTaskIns"), STAT_BSTILLM, STATGROUP_LLMFULL);
DECLARE_LLM_MEMORY_STAT(TEXT("BSAblIns"), STAT_BSAILLM, STATGROUP_LLMFULL);
DECLARE_LLM_MEMORY_STAT(TEXT("BSBuffIns"), STAT_BSBILLM, STATGROUP_LLMFULL);
DECLARE_LLM_MEMORY_STAT(TEXT("BSBattleObj"), STAT_BSBOLLM, STATGROUP_LLMFULL);
DECLARE_LLM_MEMORY_STAT(TEXT("BSNiagara"), STAT_BSNLLM, STATGROUP_LLMFULL);
DECLARE_LLM_MEMORY_STAT(TEXT("BSCascade"), STAT_BSCLLM, STATGROUP_LLMFULL);
DECLARE_LLM_MEMORY_STAT(TEXT("BSDecal"), STAT_BSDLLM, STATGROUP_LLMFULL);
DECLARE_LLM_MEMORY_STAT(TEXT("BSGhost"), STAT_BSGLLM, STATGROUP_LLMFULL);
DECLARE_LLM_MEMORY_STAT(TEXT("BSChaosCache"), STAT_BSCCLLM, STATGROUP_LLMFULL);
DECLARE_LLM_MEMORY_STAT(TEXT("BSOSData"), STAT_BSOSDLLM, STATGROUP_LLMFULL);

struct KGLLMInfo
{
	const TCHAR* Name;
	FName StatName;
	FName SummaryStatName;
};

static const KGLLMInfo KGLLMNames[] =
{
	{ TEXT("BattleSystem"),          GET_STATFNAME(STAT_BSLLM),               GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSTaskIns"),             GET_STATFNAME(STAT_BSTILLM),             GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSAblIns"),              GET_STATFNAME(STAT_BSAILLM),             GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSBuffIns"),             GET_STATFNAME(STAT_BSBILLM),             GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSBattleObj"),           GET_STATFNAME(STAT_BSBOLLM),             GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSNiagara"),             GET_STATFNAME(STAT_BSNLLM),              GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSCascade"),             GET_STATFNAME(STAT_BSCLLM),              GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSDecal"),               GET_STATFNAME(STAT_BSDLLM),              GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSGhost"),               GET_STATFNAME(STAT_BSGLLM),              GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSChaosCache"),          GET_STATFNAME(STAT_BSCCLLM),             GET_STATFNAME(STAT_BSLLM) },
	{ TEXT("BSOSData"),              GET_STATFNAME(STAT_BSOSDLLM),            GET_STATFNAME(STAT_BSLLM) },
};

namespace KGLLM
{
	void Initialize()
	{
		int32 TagCount = sizeof(KGLLMNames) / sizeof(KGLLMInfo);

		for (int32 Index = 0; Index < TagCount; ++Index)
		{
			int32 Tag = (int32)ELLMTag::ProjectTagStart + Index;
			const KGLLMInfo& TagInfo = KGLLMNames[Index];

			FLowLevelMemTracker::Get().RegisterProjectTag(Tag, TagInfo.Name, TagInfo.StatName, TagInfo.SummaryStatName);
		}
	}
}

#endif
