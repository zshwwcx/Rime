﻿#include "Misc/KGPlatformUtils.h"

#include "Misc/C7EditorPreviewGameInstance.h"
#include "Engine/Engine.h"
#include "Engine/GameInstance.h"
#include "Kismet/GameplayStatics.h"

static TAutoConsoleVariable<int32> CVarGameplayScability(TEXT("C7.GameplayScability"), 2, TEXT("Set CPU Performance Level\n") TEXT(" 0:low, 1:med, 2:high, 3:epic, 4:cinematic, default: 2"), ECVF_RenderThreadSafe | ECVF_Preview);

bool KGPlatformUtils::Is_ES3_1_FeatureLevel(UObject* WorldContextObject)
{
	if (WorldContextObject)
	{
		if (UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull))
		{
			return World->GetFeatureLevel() == ERHIFeatureLevel::Type::ES3_1;
		}
	}
	return false;
}

bool KGPlatformUtils::IsInLevelPreviewWorld(UObject* WorldContextObject)
{
#if WITH_EDITOR
	if (!IsValid(WorldContextObject))
	{
		UE_LOG(LogTemp, Warning, TEXT("KGPlatformUtils::IsInLevelPreviewWorld, invalid world context object"));
		return false;
	}

	if (UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(WorldContextObject))
	{
		return GameInstance->IsA(UKGEditorPreviewGameInstance::StaticClass());
	}
#endif

	// 编辑器预览时这里没有game instance, 是合理的
	// UE_LOG(LogTemp, Warning, TEXT("KGPlatformUtils::IsInLevelPreviewWorld, could not get game instance from context object, %s"),
	// 	*WorldContextObject->GetName());
	return false;
}

int32 KGPlatformUtils::GetGameplayScability()
{
	return FMath::Clamp(CVarGameplayScability->GetInt(), 0, 4);
}
