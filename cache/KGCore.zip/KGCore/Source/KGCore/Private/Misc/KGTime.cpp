#include "Misc/KGTime.h"
#include "Misc/DateTime.h"
#include "Misc/CoreDelegates.h"
#include <chrono>

DECLARE_LOG_CATEGORY_CLASS(LogKGTime, Log, All);

FDateTime UKGTime::Epoch(1970, 1, 1);

UKGTime::UKGTime(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

	UTCTimeOfServer = INVALID_TIME;
	ServerTimeZone = 0;
	UTCTimeOfServerSync = INVALID_TIME;

	UTCTimeOfClientManagerStart = GetUTCTimeFromEpoch();
}

void UKGTime::NativeInit()
{
	Super::NativeInit();

	FCoreDelegates::OnBeginFrame.AddUObject(this, &UKGTime::OnFrameBegin);

	using namespace NS_SLUA;
	REG_EXTENSION_METHOD(UKGTime, "AdjustClientTimeWithServer", &UKGTime::AdjustClientTimeWithServer);
	REG_EXTENSION_METHOD(UKGTime, "GetUTCTimeOfServer", &UKGTime::GetUTCTimeOfServer);
	REG_EXTENSION_METHOD(UKGTime, "GetUTCTimeOfClient", &UKGTime::GetUTCTimeOfClient);
	REG_EXTENSION_METHOD(UKGTime, "SetServerTimeZone", &UKGTime::SetServerTimeZone);

	REG_EXTENSION_METHOD(UKGTime, "GetTimeOfEngineWorldMS", &UKGTime::GetTimeOfEngineWorldMS);

	REG_EXTENSION_METHOD(UKGTime, "GetUTCTimeStringOfServer", &UKGTime::GetUTCTimeStringOfServer);
	REG_EXTENSION_METHOD(UKGTime, "GetLocalTimeStringOfServer", &UKGTime::GetLocalTimeStringOfServer);
	REG_EXTENSION_METHOD(UKGTime, "GetUTTimeStringOfClient", &UKGTime::GetUTTimeStringOfClient);
	REG_EXTENSION_METHOD(UKGTime, "GetLocalTimeStringOfClient", &UKGTime::GetLocalTimeStringOfClient);

	REG_EXTENSION_METHOD(UKGTime, "Dump", &UKGTime::Dump);
}

void UKGTime::NativeUninit()
{
	Super::NativeUninit();

	FCoreDelegates::OnBeginFrame.RemoveAll(this);
}

// 每帧开始时调用
void UKGTime::OnFrameBegin()
{
	int64 utcTime = GetUTCTimeOfServer();
	int64 WorldTimeMS = GetTimeOfEngineWorldMS();

	CallLuaFunction("KCB_UpdateTimeCache", utcTime, WorldTimeMS);
}

int UKGTime::GetLocalTimeZone()
{
	return (FDateTime::Now() - FDateTime::UtcNow()).GetHours();
}

int64 UKGTime::GetUTCTimeFromEpoch()
{
	return (FDateTime::UtcNow().GetTicks() - Epoch.GetTicks()) / ETimespan::TicksPerMillisecond;
}

void UKGTime::AdjustClientTimeWithServer(int64 InServerUTCTime, int32 InServerTimeZone)
{
	ServerTimeZone = InServerTimeZone;
	if (InServerUTCTime > UTCTimeOfServer)
	{
		UTCTimeOfServer = InServerUTCTime;
	}

	UTCTimeOfServerSync = GetUTCTimeFromEpoch();
}

int64 UKGTime::GetUTCTimeOfServer()
{
	if (IsSyncWithServer())
	{
		int64 T = UTCTimeOfServer + GetUTCTimeFromEpoch() - UTCTimeOfServerSync;
		return T;
	}

	//如果还没有与服务器同步过，使用本地机器UTC时间戳
	return GetUTCTimeOfClient();
}

int64 UKGTime::GetUTCTimeOfClient()
{
	return GetUTCTimeFromEpoch();
}

FString UKGTime::GetUTCTimeStringOfServer()
{
	int64 ServerUTC = GetUTCTimeOfServer();
	ServerUTC = ServerUTC * ETimespan::TicksPerMillisecond + Epoch.GetTicks();
	FDateTime DT(ServerUTC);
	return DT.ToString(TEXT("%Y.%m.%d %H:%M:%S.%s"));
}

FString UKGTime::GetLocalTimeStringOfServer()
{
	int64 ServerUTC = GetUTCTimeOfServer();
	int64 ServerT = ServerUTC * ETimespan::TicksPerMillisecond + Epoch.GetTicks() + GetServerTimeZone() * MillisecondsPerHour * ETimespan::TicksPerMillisecond;
	FDateTime DT(ServerT);
	return DT.ToString(TEXT("%Y.%m.%d %H:%M:%S.%s"));

}

FString UKGTime::GetUTTimeStringOfClient()
{
	return FDateTime::UtcNow().ToString(TEXT("%Y.%m.%d %H:%M:%S.%s"));
}

FString UKGTime::GetLocalTimeStringOfClient()
{
	return FDateTime::Now().ToString(TEXT("%Y.%m.%d %H:%M:%S.%s"));
}


int64 UKGTime::GetTimeOfEngineWorldMS()
{
	UWorld* w = GetWorld();
	if (w)
	{
		return w->GetTimeSeconds() * 1000;
	}

	return 0;
}

void UKGTime::Dump()
{
	UE_LOG(LogKGTime, Log, TEXT("===================================\nDump time:"));

	//打印所有重要内容：
	UE_LOG(LogKGTime, Log, TEXT("ServerTimeZone: %d"), ServerTimeZone);
	UE_LOG(LogKGTime, Log, TEXT("UTCTimeOfServer: %lld"), UTCTimeOfServer);
	UE_LOG(LogKGTime, Log, TEXT("UTCTimeOfServerSync: %lld"), UTCTimeOfServerSync);
	UE_LOG(LogKGTime, Log, TEXT("UTCTimeOfClientManagerStart: %lld"), UTCTimeOfClientManagerStart);
	UE_LOG(LogKGTime, Log, TEXT("GetUTCTimeOfServer: %lld"), GetUTCTimeOfServer());
	UE_LOG(LogKGTime, Log, TEXT("GetUTCTimeOfClient: %lld"), GetUTCTimeOfClient());
	UE_LOG(LogKGTime, Log, TEXT("GetLocalTimeZone: %d"), GetLocalTimeZone());
	UE_LOG(LogKGTime, Log, TEXT("GetUTCTimeStringOfServer: %s"), *GetUTCTimeStringOfServer());
	UE_LOG(LogKGTime, Log, TEXT("GetLocalTimeStringOfServer: %s"), *GetLocalTimeStringOfServer());
	UE_LOG(LogKGTime, Log, TEXT("GetUTTimeStringOfClient: %s"), *GetUTTimeStringOfClient());
	UE_LOG(LogKGTime, Log, TEXT("GetLocalTimeStringOfClient: %s"), *GetLocalTimeStringOfClient());

	UE_LOG(LogKGTime, Log, TEXT("==================================="));
}

