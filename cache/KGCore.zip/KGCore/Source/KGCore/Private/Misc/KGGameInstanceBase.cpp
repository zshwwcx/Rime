// Fill out your copyright notice in the Description page of Project Settings.


#include "Misc/KGGameInstanceBase.h"
#include "Misc/KGObjectCountWatcher.h"

UKGGameInstanceBase::UKGGameInstanceBase()
{
}

void UKGGameInstanceBase::Init()
{
	Super::Init();

	ObjectCountWatcher = NewObject<UKGObjectCountWatcher>();
	ObjectCountWatcher->Init(this);
}

void UKGGameInstanceBase::Shutdown()
{
	if (ObjectCountWatcher != nullptr)
	{
		ObjectCountWatcher->UnInit();
		ObjectCountWatcher = nullptr;
	}
	
	Super::Shutdown();
}

void UKGGameInstanceBase::OnStart()
{
	Super::OnStart();
}

void UKGGameInstanceBase::StartGameInstance()
{
	Super::StartGameInstance();
}

void UKGGameInstanceBase::OnObjectCountNearlyExceed(int32 CurrentObjectCount)
{
	
}

void UKGGameInstanceBase::InitLuaEnv()
{
	check(LuaEnv == nullptr);
    LuaEnv = ULuaEnv::CreateLuaEnv(this);
}

void UKGGameInstanceBase::UninitLuaEnv()
{
	check(LuaEnv);
    ULuaEnv::DestroyLuaEnv(LuaEnv);
    LuaEnv = nullptr;
}

ULuaGameInstance *UKGGameInstanceBase::GetLuaGameInstance()
{
	if (LuaEnv) {
        return LuaEnv->GetLuaGameInstance();
	}
    return nullptr;
}