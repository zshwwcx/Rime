#include "Misc/MathFormula.h"
#include "CoreMinimal.h"


 const  float MathFormula::RotateTolerateDegree = 0.2f;

float MathFormula::DecayValue(float srcValue, float dstValue, float halfLife, float timeDelta) {
	if (halfLife <= 0.0f) {
		return dstValue;
	}
	
	return dstValue + (srcValue - dstValue) * FMath::Pow(0.5f, timeDelta / halfLife);
}

void  MathFormula::DecayValue(FVector& output, const FVector& srcValue, const FVector& dstValue, float halfLife, float timeDelta) {
	if (halfLife <= 0.0f) {
		output = dstValue;
		return;
	}

	float expr = FMath::Pow(0.5f, timeDelta / halfLife);

	output.X = dstValue.X + (srcValue.X - dstValue.X) * expr;
	output.Y = dstValue.Y + (srcValue.Y - dstValue.Y) * expr;
	output.Z = dstValue.Z + (srcValue.Z - dstValue.Z) * expr;
	return;
}

void MathFormula::DecayValue(FVector2D& output, const FVector2D& srcValue, const FVector2D& dstValue, float halfLife,
                             float timeDelta)
{
	if (halfLife <= 0.0f) {
		output = dstValue;
		return;
	}

	float expr = FMath::Pow(0.5f, timeDelta / halfLife);

	output.X = dstValue.X + (srcValue.X - dstValue.X) * expr;
	output.Y = dstValue.Y + (srcValue.Y - dstValue.Y) * expr;
	return;
}

void  MathFormula::DecayValue(FRotator& output, const FRotator& srcValue, const FRotator& dstValue, float halfLife, float timeDelta) {
	float expr = FMath::Pow(0.5f, timeDelta / halfLife);

	output.Pitch = YawDecayWithNormalized(srcValue.Pitch, dstValue.Pitch, halfLife, timeDelta); 
	output.Yaw = YawDecayWithNormalized(srcValue.Yaw, dstValue.Yaw, halfLife, timeDelta);
	output.Roll = YawDecayWithNormalized(srcValue.Roll, dstValue.Roll, halfLife, timeDelta);
}

float MathFormula::SmoothDamp(float srcValue, float dstValue, float& curVelocity, float smoothTime, float timeDelta,
                              float maxSpeed)
{
	smoothTime = FMath::Max(0.0001F, smoothTime);
	float omega = 2.f / smoothTime;

	float x = omega * timeDelta;
	float exp = 1.f / (1.f + x + 0.48F * x * x + 0.235F * x * x * x);
	float change = srcValue - dstValue;
	float originalTo = dstValue;

	// Clamp maximum speed
	float maxChange = maxSpeed * smoothTime;
	change = FMath::Clamp(change, -maxChange, maxChange);
	dstValue = srcValue - change;

	float temp = (curVelocity + omega * change) * timeDelta;
	curVelocity = (curVelocity - omega * temp) * exp;
	float output = dstValue + (change + temp) * exp;

	// Prevent overshooting
	if (originalTo - srcValue > 0.f == output > originalTo)
	{
		output = originalTo;
		curVelocity = (output - originalTo) / timeDelta;
	}

	return output;
}

double MathFormula::SmoothDamp(double srcValue, double dstValue, double& curVelocity, float smoothTime,
                              float timeDelta, double maxSpeed)
{
	smoothTime = FMath::Max(0.0001F, smoothTime);
	float omega = 2.f / smoothTime;

	float x = omega * timeDelta;
	float exp = 1.f / (1.f + x + 0.48F * x * x + 0.235F * x * x * x);
	double change = srcValue - dstValue;
	double originalTo = dstValue;

	// Clamp maximum speed
	double maxChange = maxSpeed * smoothTime;
	change = FMath::Clamp(change, -maxChange, maxChange);
	dstValue = srcValue - change;

	double temp = (curVelocity + omega * change) * timeDelta;
	curVelocity = (curVelocity - omega * temp) * exp;
	double output = dstValue + (change + temp) * exp;

	// Prevent overshooting
	if (originalTo - srcValue > 0.f == output > originalTo)
	{
		output = originalTo;
		curVelocity = (output - originalTo) / timeDelta;
	}

	return output;
}

void MathFormula::SmoothDamp(FVector& output, const FVector& srcValue, const FVector& dstValue, FVector& curVelocity,
                             float smoothTime, float timeDelta, float maxSpeed)
{
	float output_x = 0.f;
    float output_y = 0.f;
    float output_z = 0.f;

    // Based on Game Programming Gems 4 Chapter 1.10
    smoothTime = FMath::Max(0.0001F, smoothTime);
    float omega = 2.f / smoothTime;

    float x = omega * timeDelta;
    float exp = 1.f / (1.f + x + 0.48F * x * x + 0.235F * x * x * x);

    float change_x = srcValue.X - dstValue.X;
    float change_y = srcValue.Y - dstValue.Y;
    float change_z = srcValue.Z - dstValue.Z;
    FVector originalTo = dstValue;

    // Clamp maximum speed
    float maxChange = maxSpeed * smoothTime;

    float maxChangeSq = maxChange * maxChange;
    float sqrmag = change_x * change_x + change_y * change_y + change_z * change_z;
    if (sqrmag > maxChangeSq)
    {
        float mag = FMath::Sqrt(sqrmag);
        change_x = change_x / mag * maxChange;
        change_y = change_y / mag * maxChange;
        change_z = change_z / mag * maxChange;
    }

	FVector newDstValue = {srcValue.X - change_x, srcValue.Y - change_y, srcValue.Z - change_z};

    float temp_x = (curVelocity.X + omega * change_x) * timeDelta;
    float temp_y = (curVelocity.Y + omega * change_y) * timeDelta;
    float temp_z = (curVelocity.Z + omega * change_z) * timeDelta;

    curVelocity.X = (curVelocity.X - omega * temp_x) * exp;
    curVelocity.Y = (curVelocity.Y - omega * temp_y) * exp;
    curVelocity.Z = (curVelocity.Z - omega * temp_z) * exp;

    output_x = newDstValue.X + (change_x + temp_x) * exp;
    output_y = newDstValue.Y + (change_y + temp_y) * exp;
    output_z = newDstValue.Z + (change_z + temp_z) * exp;

    // Prevent overshooting
    float origMinusCurrent_x = originalTo.X - srcValue.X;
    float origMinusCurrent_y = originalTo.Y - srcValue.Y;
    float origMinusCurrent_z = originalTo.Z - srcValue.Z;
    float outMinusOrig_x = output_x - originalTo.X;
    float outMinusOrig_y = output_y - originalTo.Y;
    float outMinusOrig_z = output_z - originalTo.Z;

    if (origMinusCurrent_x * outMinusOrig_x + origMinusCurrent_y * outMinusOrig_y + origMinusCurrent_z * outMinusOrig_z > 0)
    {
        output_x = originalTo.X;
        output_y = originalTo.Y;
        output_z = originalTo.Z;

        curVelocity.X = (output_x - originalTo.X) / timeDelta;
        curVelocity.Y = (output_y - originalTo.Y) / timeDelta;
        curVelocity.Z = (output_z - originalTo.Z) / timeDelta;
    }

    output.X = output_x;
    output.Y = output_y;
	output.Z = output_z;
}


float MathFormula::LinearCloseToDst(float src, float dst, float linearSpeed, float timeDelta){

	if (linearSpeed <= 0.0f) {
		return dst;
	}

	float diff = dst - src;
	int sign = diff >= 0 ? 1 : -1;

	float absDiff = FMath::Abs(diff);
	linearSpeed = linearSpeed * timeDelta;
	if (absDiff < linearSpeed) {
		linearSpeed = absDiff;
	}
	
	return src + linearSpeed * sign;
	

}

float MathFormula::SameSignAngle(float SrcAngle, float DstAngle)
{
	SrcAngle = FRotator::NormalizeAxis(SrcAngle);
	DstAngle = FRotator::NormalizeAxis(DstAngle);

	if (DstAngle > SrcAngle + 180.f)
	{
		return DstAngle - 360.f;
	}
	else if (DstAngle < SrcAngle - 180.f)
	{
		return DstAngle + 360.f;
	}
	else
	{
		return DstAngle;
	}

}

 float MathFormula::ClosetYawSignedDiff(float yawAngle1, float yawAngle2)
{
	return MathFormula::SameSignAngle(yawAngle1, yawAngle2) - FRotator::NormalizeAxis(yawAngle1);

}

 float MathFormula::ClosetYawAbsDiff(float yawAngle1, float yawAngle2)
{
	return FMath::Abs(MathFormula::SameSignAngle(yawAngle1, yawAngle2) - FRotator::NormalizeAxis(yawAngle1));

}



 float MathFormula::YawSignedNormalizedDiff(float yawAngle1, float yawAngle2)
 {
	 return FRotator::ClampAxis(yawAngle2) - FRotator::ClampAxis(yawAngle1);

 }

 float MathFormula::YawDecayWithNormalized(float srcYaw, float dstYaw, float halfLife, float timeDelta)
{
	dstYaw = MathFormula::SameSignAngle(srcYaw, dstYaw);
	srcYaw = FRotator::NormalizeAxis(srcYaw);
	return   MathFormula::DecayValue(srcYaw, dstYaw, halfLife, timeDelta);
}


 /*
 * 判断两个四元数代表的旋转是否几乎相等
 * @param q1: 四元数1
 * @param q2: 四元数2
 * @param tolerance: 阈值, 角度
 * @return: 如果两个四元数的差的长度小于阈值，则返回 true，否则返回 false
 */
 bool MathFormula::AlmostSameRotation(const FQuat& q1, const FQuat& q2, float tolerance)
 {
	 // 计算两个四元数的差
	 const FQuat delta = q1.Inverse() * q2;

	 // 计算差的长度
	 FRotator rot = delta.Rotator();

	 return abs(rot.Pitch) <= tolerance && abs(rot.Yaw) <= tolerance && abs(rot.Roll) <= tolerance;
 }

