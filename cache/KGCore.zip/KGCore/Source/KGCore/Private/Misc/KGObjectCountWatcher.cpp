#include "Misc/KGObjectCountWatcher.h"
#include "Misc/KGGameInstanceBase.h"
#include "luaref/LuaReferenceDump.h"

DEFINE_LOG_CATEGORY_STATIC(LogKGObjectCountWatcher, Log, Log);

void UKGObjectCountWatcher::Init(UKGGameInstanceBase* InGameInstance)
{
	GameInstance = InGameInstance;

	GUObjectArray.AddUObjectCountExceedListener(this);
}
void UKGObjectCountWatcher::UnInit()
{
	GameInstance = nullptr;
	GUObjectArray.RemoveUObjectCountExceedListener(this);
}

void UKGObjectCountWatcher::NotifyUObjectCountExceed(int32 Count) 
{
	if (!IsInGameThread())
	{
		UE_LOG(LogKGObjectCountWatcher, Warning, TEXT("UObject Count Exceeded! %d, but not in main thread, what a pity."), Count);
		return; 	//不在主线程触发的话直接跳过吧，可能会崩溃（虽然因为UObject数量超已经要崩溃了）
	}
	NS_SLUA::LuaState* LuaState = NS_SLUA::LuaState::get(GameInstance);
	if (LuaState)
	{
		NS_SLUA::LuaReferenceDump::DumpLuaBeforeCrash(LuaState);
		UE_LOG(LogKGObjectCountWatcher, Warning, TEXT("UObject Count Exceeded! %d, saved at LuaReferenceDump.txt"), Count);
	}
	else
	{
		UE_LOG(LogKGObjectCountWatcher, Warning, TEXT("UObject Count Exceeded! %d, without dump lua-vm."), Count);
	}
}
void UKGObjectCountWatcher::NotifyObjectCountNearlyExceed(int32 Count) 
{
	// 注意：回调可能在多线程当中！这里通过标记位处理并在Tick中进入Lua层
	IsObjectCountNearlyExceed = true;
	CurrentObjectCount = Count;
	// UE_LOG(LogKGObjectCountWatcher, Warning, TEXT("Object count nearly exceed! Current count: %d"), Count)
}
void UKGObjectCountWatcher::OnUObjectArrayShutdown() 
{
	GUObjectArray.RemoveUObjectCountExceedListener(this);
}
void UKGObjectCountWatcher::Tick(float DeltaTime)
{
	if (GameInstance && IsObjectCountNearlyExceed)
	{
		IsObjectCountNearlyExceed = false;
		const auto CurrentTime = FPlatformTime::Seconds();
		// UE_LOG(LogKGObjectCountWatcher, Warning, TEXT("Object count exceeded! callback to lua, %f|%f|%f"), CurrentTime, PrevCallbackTime, MinElapseBetweenCallback);
		if (CurrentTime - PrevCallbackTime >= MinElapseBetweenCallback)
		{
			UE_LOG(LogKGObjectCountWatcher, Warning, TEXT("Object count exceeded! callback to lua"))
			PrevCallbackTime = CurrentTime;
			GameInstance->OnObjectCountNearlyExceed(CurrentObjectCount);	
		}
	}
}