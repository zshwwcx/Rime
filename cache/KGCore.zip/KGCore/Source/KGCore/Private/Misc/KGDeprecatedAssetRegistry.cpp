#include "Misc/KGDeprecatedAssetRegistry.h"

const FName UKGDeprecatedAssetRegistry::DeprecatedAssetRegistryPath = TEXT("/Game/Blueprint/Misc/DeprecatedAssets.DeprecatedAssets");
