#include "Misc/LowLevelFunctions.h"
#include "Components/BoxComponent.h"
#include "Components/SphereComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Engine/World.h"
#include "HAL/FileManager.h"


#pragma region Important
int32 ULowLevelFunctions::GlobalIDCreater = 1;

TMap<FString, TWeakObjectPtr<UClass>> ULowLevelFunctions::PathToClass;

int64 ULowLevelFunctions::GetGlobalUniqueID()
{
	uint64 Result = FDateTime::UtcNow().GetTicks();

	// 除以8192，相当于精确到毫秒（毫秒要除以10000）
	Result >>= 13;
	// 将高位的无效位移除，保留大概80年的份额
	Result <<= 22;
	// 留出符号位，最后加上循环自增计数器
	Result = (Result >> 12) + GlobalIDCreater;
	GlobalIDCreater = (GlobalIDCreater % 1000) + 1;

	return Result;
}

bool ULowLevelFunctions::IsValid(const UObject* InObject)
{
	return InObject && FInternalUObjectBaseUtilityIsValidFlagsChecker::CheckObjectValidBasedOnItsFlags(InObject) && InObject->IsValidLowLevelFast();
}

UClass* ULowLevelFunctions::GetClassByPath(const FString& InPath)
{
	if (TWeakObjectPtr<UClass>* Result = PathToClass.Find(InPath))
	{
		if (Result->IsValid())
		{
			return Result->Get();
		}
	}

	UClass* Class = FindObject<UClass>(nullptr, *InPath);
	if (ULowLevelFunctions::IsValid(Class))
	{
		PathToClass.Add(InPath, Class);
	}

	return Class;
}

//UBasicLuaGameInstance* ULowLevelFunctions::GetLuaGI(UObject* InWorldContext)
//{
//	UBasicLuaGameInstance* LuaGI = Cast<UBasicLuaGameInstance>(InWorldContext);
//
//	if (IsValid(LuaGI))
//	{
//		return LuaGI;
//	}
//
//#if WITH_EDITOR
//	LuaGI = UEditorLuaGameInstance::GetLuaGameInstance(InWorldContext);
//	if (!IsValid(LuaGI))
//	{
//		LuaGI = ULuaGameInstance::GetLuaGameInstance(InWorldContext);
//	}
//#else
//	LuaGI = ULuaGameInstance::GetLuaGameInstance(InWorldContext);
//#endif
//
//	return LuaGI;
//}

#pragma endregion Impoortant


#pragma region Time
int64 ULowLevelFunctions::DeltaTimeToServer = 0;

int64 ULowLevelFunctions::GetUtcMillisecond()
{
	FDateTime Current = FDateTime::UtcNow();
	int64 DeltaTicks = Current.GetTicks() - FDateTime(1970, 1, 1).GetTicks();

	return DeltaTicks / ETimespan::TicksPerMillisecond;
}

int64 ULowLevelFunctions::GetGameMicrosecond()
{
	double DeltaTicks = FPlatformTime::ToMilliseconds64(FPlatformTime::Cycles64());

	return DeltaTicks * 1000.0;
}

void ULowLevelFunctions::SetDeltaTimeToServer(int64 InDeltaTime)
{
	ULowLevelFunctions::DeltaTimeToServer = InDeltaTime;
}

#pragma endregion Time


#pragma region Math
void ULowLevelFunctions::FibonacciLattice(int32 N, TArray<float>& OutX, TArray<float>& OutY)
{
	OutX.Empty();
	OutY.Empty();

	TArray<FVector2D> Result = ULowLevelFunctions::FibonacciLattice(N);

	for (int32 i = 0; i < Result.Num(); ++i)
	{
		const FVector2D& It = Result[i];

		OutX.Add(It.X);
		OutY.Add(It.Y);
	}
}

TArray<FVector2D> ULowLevelFunctions::FibonacciLattice(int32 N)
{
	TArray<FVector2D> Results;

	float Phi = (1.0f + FMath::Sqrt(5.0f)) / 2.0f;
	for (int32 i = 1; i <= N; ++i)
	{
		float X = FMath::Fmod(i / Phi, 1.0f);
		float Y = i / (N * 1.0f);

		Results.Add(FVector2D(X, Y));
	}

	return Results;
}

void ULowLevelFunctions::SphericalUniformRandomPoint(int32 N, float Radius, TArray<float>& OutX, TArray<float>& OutY, TArray<float>& OutZ)
{
	OutX.Empty();
	OutY.Empty();
	OutZ.Empty();

	TArray<FVector> Result = ULowLevelFunctions::SphericalUniformRandomPoint(N, Radius);

	for (int32 i = 0; i < Result.Num(); ++i)
	{
		const FVector& It = Result[i];

		OutX.Add(It.X);
		OutY.Add(It.Y);
		OutZ.Add(It.Z);
	}
}

TArray<FVector> ULowLevelFunctions::SphericalUniformRandomPoint(int32 N, float Radius)
{
	TArray<FVector> Results;

	TArray<FVector2D> FibonacciLattice = ULowLevelFunctions::FibonacciLattice(N);
	for (int32 i = 0; i < FibonacciLattice.Num(); ++i)
	{
		float Theta = 2.0f * 3.1416 * FibonacciLattice[i].X;
		float R = FMath::Sqrt(FibonacciLattice[i].Y);

		float Phi = 2.0f * FMath::Asin(R);
		float X = FMath::Cos(Theta) * FMath::Sin(Phi);
		float Y = FMath::Sin(Theta) * FMath::Sin(Phi);
		float Z = FMath::Cos(Phi);

		Results.Add(FVector(X, Y, Z) * Radius);
	}

	return Results;
}

float ULowLevelFunctions::PointToLineSegment(float PX, float PY, float PZ, float LPX1, float LPY1, float LPZ1, float LPX2, float LPY2, float LPZ2, bool In2D)
{
	return ULowLevelFunctions::PointToLineSegment(FVector(PX, PY, PZ), FVector(LPX1, LPY1, LPZ1), FVector(LPX2, LPY2, LPZ2), In2D);
}

float ULowLevelFunctions::PointToLineSegment(const FVector& InPoint, const FVector& LinePoint1, const FVector& LinePoint2, bool In2D)
{
	FVector VLine = LinePoint2 - LinePoint1;
	FVector WLine1 = InPoint - LinePoint1;
	FVector WLine2 = InPoint - LinePoint2;
	if (In2D)
	{
		VLine.Z = 0.0f;
		WLine1.Z = 0.0f;
		WLine2.Z = 0.0f;
	}

	if (VLine.IsNearlyZero())
	{
		return WLine1.Size();
	}

	float C1 = WLine1.Dot(VLine);
	float C2 = VLine.Dot(VLine);
	float Ratio = C1 / C2;

	if (Ratio < 0.0)
	{
		return WLine1.Size();
	}

	if (Ratio > 1.0)
	{
		return WLine2.Size();
	}

	FVector P = LinePoint1 + Ratio * VLine;

	if (In2D)
	{
		return (InPoint - P).Size2D();
	}

	return (InPoint - P).Size();
}

bool ULowLevelFunctions::CheckPointInsideLineSegment(float PX, float PY, float PZ, float LPX1, float LPY1, float LPZ1, float LPX2, float LPY2, float LPZ2, bool In2D, float DistanceError)
{
	float Dis = ULowLevelFunctions::PointToLineSegment(FVector(PX, PY, PZ), FVector(LPX1, LPY1, LPZ1), FVector(LPX2, LPY2, LPZ2), In2D);

	if (Dis <= DistanceError)
	{
		return true;
	}

	return false;
}

bool ULowLevelFunctions::CheckPointInsideLineSegment(const FVector& InPoint, const FVector& LinePoint1, const FVector& LinePoint2, bool In2D, float DistanceError)
{
	float Dis = ULowLevelFunctions::PointToLineSegment(InPoint, LinePoint1, LinePoint2, In2D);

	if (Dis <= DistanceError)
	{
		return true;
	}

	return false;
}

bool ULowLevelFunctions::CheckPointInsideCircle(float PX, float PY, float PZ, float CCX, float CCY, float CCZ, float Radius, float HeightDifference)
{
	float DeltaX = PX - CCX;
	float DeltaY = PY - CCY;
	float DeltaZ = PZ - CCZ;

	if (FMath::Abs(DeltaZ) > HeightDifference)
	{
		return false;
	}

	float Dis2 = DeltaX * DeltaX + DeltaY * DeltaY;

	return Dis2 <= Radius * Radius;
}

bool ULowLevelFunctions::CheckPointInsideCircle(const FVector& InPoint, const FVector& CircleCenter, float Radius, float HeightDifference)
{
	FVector Delta = InPoint - CircleCenter;

	if (FMath::Abs(Delta.Z) > HeightDifference)
	{
		return false;
	}

	float Dis2 = (Delta).SizeSquared2D();

	return Dis2 <= Radius * Radius;
}

bool ULowLevelFunctions::CheckPointInsideRectangle(float PX, float PY, float PZ, float RCX, float RCY, float RCZ, float RDYaw, float RSX, float RSY, float HeightDifference)
{
	return ULowLevelFunctions::CheckPointInsideRectangle(FVector(PX, PY, PZ), FVector(RCX, RCY, RCZ), FRotator(0.0f, RDYaw, 0.0f), FVector2D(RSX, RSY), HeightDifference);
}

bool ULowLevelFunctions::CheckPointInsideRectangleQ(float PX, float PY, float PZ, float RCX, float RCY, float RCZ, float RDX, float RDY, float RDZ, float RDW, float RSX, float RSY, float HeightDifference)
{
	FRotator RectRot = FQuat(RDX, RDY, RDZ, RDW).Rotator();
	RectRot.Roll = 0.0f;
	RectRot.Pitch = 0.0f;

	return ULowLevelFunctions::CheckPointInsideRectangle(FVector(PX, PY, PZ), FVector(RCX, RCY, RCZ), RectRot, FVector2D(RSX, RSY), HeightDifference);
}

bool ULowLevelFunctions::CheckPointInsideRectangle(const FVector& InPoint, const FVector& InRectCenter, const FRotator& InRectDir, const FVector2D& RectSize, float HeightDifference)
{
	FVector LocalP = InPoint - InRectCenter;
	LocalP = InRectDir.UnrotateVector(LocalP);

	if (FMath::Abs(LocalP.X) <= RectSize.X && FMath::Abs(LocalP.Y) <= RectSize.Y && FMath::Abs(LocalP.Z) <= HeightDifference)
	{
		return true;
	}

	return false;
}

bool ULowLevelFunctions::CheckPointInsideFan2D(float PX, float PY, float PZ, float FCX, float FCY, float FCZ, float FDYaw, float FSX, float FSY, float FSZ, float HeightDifference)
{
	return ULowLevelFunctions::CheckPointInsideFan2D(FVector(PX, PY, PZ), FVector(FCX, FCY, FCZ), FRotator(0.0f, FDYaw, 0.0f), FVector(FSX, FSY, FSZ), HeightDifference);
}

bool ULowLevelFunctions::CheckPointInsideFan2DQ(float PX, float PY, float PZ, float FCX, float FCY, float FCZ, float FDX, float FDY, float FDZ, float FDW, float FSX, float FSY, float FSZ, float HeightDifference)
{
	FRotator RectRot = FQuat(FDX, FDY, FDZ, FDW).Rotator();
	RectRot.Roll = 0.0f;
	RectRot.Pitch = 0.0f;

	return ULowLevelFunctions::CheckPointInsideFan2D(FVector(PX, PY, PZ), FVector(FCX, FCY, FCZ), RectRot, FVector(FSX, FSY, FSZ), HeightDifference);
}

bool ULowLevelFunctions::CheckPointInsideFan2D(const FVector& InPoint, const FVector& InFanCenter, const FRotator& InFanDir, const FVector& FanSize, float HeightDifference)
{
	FVector LocalP = InPoint - InFanCenter;
	LocalP = InFanDir.UnrotateVector(LocalP);

	if (FMath::Abs(LocalP.Z) > HeightDifference)
	{
		return false;
	}
	LocalP.Z = 0.0f;

	float FanCos = FMath::Cos(FMath::DegreesToRadians(FanSize.Z));

	// 点在圆内 并且 点在角内
	float Length = LocalP.Size();
	if (Length >= FanSize.X && Length <= FanSize.Y && (LocalP.GetSafeNormal() | FVector(1.0f, 0.0f, 0.0f)) >= FanCos)
	{
		return true;
	}

	return false;
}

bool ULowLevelFunctions::CheckCircleIntersectCircle(float CCX1, float CCY1, float CCZ1, float CircleRadius1, float CCX2, float CCY2, float CCZ2, float CircleRadius2, float HeightDifference)
{
	if (FMath::Abs(CCZ1 - CCZ2) > HeightDifference)
	{
		return false;
	}

	float DeltaX = CCX1 - CCX2;
	float DeltaY = CCY1 - CCY2;

	float Dis2 = DeltaX * DeltaX + DeltaY * DeltaY;

	if (Dis2 <= FMath::Square(CircleRadius1 + CircleRadius2))
	{
		return true;
	}

	return false;
}

bool ULowLevelFunctions::CheckCircleIntersectCircle(const FVector& CircleCenter1, float CircleRadius1, const FVector& CircleCenter2, float CircleRadius2, float HeightDifference)
{
	FVector Delta = CircleCenter1 - CircleCenter2;

	if (FMath::Abs(Delta.Z) > HeightDifference)
	{
		return false;
	}

	float Dis2 = Delta.SizeSquared2D();

	if (Dis2 <= FMath::Square(CircleRadius1 + CircleRadius2))
	{
		return true;
	}

	return false;
}

bool ULowLevelFunctions::CheckCircleIntersectRectangle(float CCX, float CCY, float CCZ, float CircleRadius, float RCX, float RCY, float RCZ, float FDYaw, float FSX, float FSY, float HeightDifference)
{
	return ULowLevelFunctions::CheckCircleIntersectRectangle(FVector(CCX, CCY, CCZ), CircleRadius, FVector(RCX, RCY, RCZ), FRotator(0.0f, FDYaw, 0.0f), FVector2D(FSX, FSY), HeightDifference);
}

bool ULowLevelFunctions::CheckCircleIntersectRectangleQ(float CCX, float CCY, float CCZ, float CircleRadius, float RCX, float RCY, float RCZ, float FDX, float FDY, float FDZ, float FDW, float FSX, float FSY, float HeightDifference)
{
	FRotator RectRot = FQuat(FDX, FDY, FDZ, FDW).Rotator();
	RectRot.Roll = 0.0f;
	RectRot.Pitch = 0.0f;

	return ULowLevelFunctions::CheckCircleIntersectRectangle(FVector(CCX, CCY, CCZ), CircleRadius, FVector(RCX, RCY, RCZ), RectRot, FVector2D(FSX, FSY), HeightDifference);
}

bool ULowLevelFunctions::CheckCircleIntersectRectangle(const FVector& CircleCenter, float CircleRadius, const FVector& InRectCenter, const FRotator& InRectDir, const FVector2D& RectSize, float HeightDifference)
{
	FVector LocalP = CircleCenter - InRectCenter;
	LocalP = InRectDir.UnrotateVector(LocalP);
	if (FMath::Abs(LocalP.Z) > HeightDifference)
	{
		return false;
	}
	LocalP.Z = 0.0f;

	// 1、判断圆心是否在矩形内
	if (FMath::Abs(LocalP.X) <= RectSize.X && FMath::Abs(LocalP.Y) <= RectSize.Y)
	{
		return true;
	}

	// 左下顶点
	FVector A = FVector(-RectSize.X, -RectSize.Y, 0.0f);
	// 左上顶点
	FVector B = FVector(-RectSize.X, RectSize.Y, 0.0f);
	// 右上顶点
	FVector C = FVector(RectSize.X, RectSize.Y, 0.0f);
	// 右下顶点
	FVector D = FVector(RectSize.X, -RectSize.Y, 0.0f);

	// 2、判断圆心到线段的距离
	float DisAB = ULowLevelFunctions::PointToLineSegment(LocalP, A, B);
	float DisBC = ULowLevelFunctions::PointToLineSegment(LocalP, B, C);
	float DisCD = ULowLevelFunctions::PointToLineSegment(LocalP, C, D);
	float DisDA = ULowLevelFunctions::PointToLineSegment(LocalP, D, A);
	if (DisAB <= CircleRadius || DisBC <= CircleRadius || DisCD <= CircleRadius || DisDA <= CircleRadius)
	{
		return true;
	}

	return false;
}

bool ULowLevelFunctions::CheckCircleIntersectFan2D(float CCX, float CCY, float CCZ, float CircleRadius, float FCX, float FCY, float FCZ, float FDYaw, float FSX, float FSY, float FSZ, float HeightDifference)
{
	return ULowLevelFunctions::CheckCircleIntersectFan2D(FVector(CCX, CCY, CCZ), CircleRadius, FVector(FCX, FCY, FCZ), FRotator(0.0f, FDYaw, 0.0f), FVector(FSX, FSY, FSZ), HeightDifference);
}

bool ULowLevelFunctions::CheckCircleIntersectFan2DQ(float CCX, float CCY, float CCZ, float CircleRadius, float FCX, float FCY, float FCZ, float FDX, float FDY, float FDZ, float FDW, float FSX, float FSY, float FSZ, float HeightDifference)
{
	FRotator RectRot = FQuat(FDX, FDY, FDZ, FDW).Rotator();
	RectRot.Roll = 0.0f;
	RectRot.Pitch = 0.0f;

	return ULowLevelFunctions::CheckCircleIntersectFan2D(FVector(CCX, CCY, CCZ), CircleRadius, FVector(FCX, FCY, FCZ), RectRot, FVector(FSX, FSY, FSZ), HeightDifference);
}

bool ULowLevelFunctions::CheckCircleIntersectFan2D(const FVector& CircleCenter, float CircleRadius, const FVector& InFanCenter, const FRotator& InFanDir, const FVector& FanSize, float HeightDifference)
{
	FVector LocalP = CircleCenter - InFanCenter;
	LocalP = InFanDir.UnrotateVector(LocalP);
	if (FMath::Abs(LocalP.Z) > HeightDifference)
	{
		return false;
	}
	LocalP.Z = 0.0f;

	// 点在圆内 并且 点在角内
	float Length = LocalP.Size();
	float FanCos = FMath::Cos(FMath::DegreesToRadians(FanSize.Z));
	if (Length >= FanSize.X && Length <= FanSize.Y && (LocalP.GetSafeNormal() | FVector(1.0f, 0.0f, 0.0f)) >= FanCos)
	{
		return true;
	}

	float FanSin = FMath::Sin(FMath::DegreesToRadians(FanSize.Z));
	FVector FanP11 = FVector(FanCos * FanSize.X, FanSin * FanSize.X, 0.0f);
	FVector FanP12 = FVector(FanCos * FanSize.Y, FanSin * FanSize.Y, 0.0f);
	FVector FanP21 = FVector(FanCos * FanSize.X, FanSin * FanSize.X * -1.0f, 0.0f);
	FVector FanP22 = FVector(FanCos * FanSize.Y, FanSin * FanSize.Y * -1.0f, 0.0f);

	// 2、判断圆与圆环相交
	if (Length >= FanSize.X - CircleRadius && Length <= FanSize.Y + CircleRadius)
	{
		// 3、判断圆心在角内
		if ((LocalP.GetSafeNormal() | FVector(1.0f, 0.0f, 0.0f)) >= FanCos)
		{
			return true;
		}

		// 4、判断圆心到线段的距离
		float DisPP1 = ULowLevelFunctions::PointToLineSegment(LocalP, FanP11, FanP12);
		float DisPP2 = ULowLevelFunctions::PointToLineSegment(LocalP, FanP21, FanP22);
		if (DisPP1 <= CircleRadius || DisPP2 <= CircleRadius)
		{
			return true;
		}
	}

	return false;
}

/*
* 解法：https://www.zhihu.com/question/24251545/answer/27184960
*/
bool ULowLevelFunctions::CheckSphereIntersectBox(const FVector& SphereCenter, float SphereRadius, const FVector& InBoxCenter, const FRotator& InBoxDirection, const FVector& BoxSize)
{
	// 1、将球体坐标转换到以长方体坐标为原点的坐标系的第一象限
	FVector DeltaCenter = FTransform(InBoxDirection, InBoxCenter).InverseTransformPosition(SphereCenter);
	DeltaCenter.X = FMath::Abs(DeltaCenter.X);
	DeltaCenter.Y = FMath::Abs(DeltaCenter.Y);
	DeltaCenter.Z = FMath::Abs(DeltaCenter.Z);

	// 2、求圆心到矩形的最短距离向量
	FVector Shortest = DeltaCenter - BoxSize;
	Shortest.X = FMath::Max(Shortest.X, 0.0f);
	Shortest.Y = FMath::Max(Shortest.Y, 0.0f);
	Shortest.Z = FMath::Max(Shortest.Z, 0.0f);

	// 3、判断距离
	return Shortest.SizeSquared() <= SphereRadius * SphereRadius;
}

void ULowLevelFunctions::ComposeRotators(float R1, float P1, float Y1, float R2, float P2, float Y2, float& R, float& P, float& Y)
{
	FRotator Rot1(P1, Y1, R1);
	FRotator Rot2(P2, Y2, R2);

	FRotator Rot = (Rot2.Quaternion() * Rot1.Quaternion()).Rotator();

	R = Rot.Roll;
	P = Rot.Pitch;
	Y = Rot.Yaw;
}

void ULowLevelFunctions::ComposeRotatorsQ(float R1, float P1, float Y1, float R2, float P2, float Y2, float& X, float& Y, float& Z, float& W)
{
	FRotator Rot1(P1, Y1, R1);
	FRotator Rot2(P2, Y2, R2);

	FQuat Q = Rot2.Quaternion() * Rot1.Quaternion();

	X = Q.X;
	Y = Q.Y;
	Z = Q.Z;
	W = Q.W;
}

float ULowLevelFunctions::PointToBoxDistance(const FVector& InPoint, const FTransform& InBoxTransform, const FVector& InBoxHalfSize)
{
	FVector LocalPoint = InBoxTransform.InverseTransformPositionNoScale(InPoint);

	float DX = FMath::Max(FMath::Abs(LocalPoint.X) - InBoxHalfSize.X, 0.0f);
	float DY = FMath::Max(FMath::Abs(LocalPoint.Y) - InBoxHalfSize.Y, 0.0f);
	float DZ = FMath::Max(FMath::Abs(LocalPoint.Z) - InBoxHalfSize.Z, 0.0f);

	return FMath::Sqrt(DX * DX + DY * DY + DZ * DZ);
}

void ULowLevelFunctions::BuildBSTSequence(int32 Start, int32 End, bool bLeftPriority, TArray<int32>& Result)
{
	if (Start > End)
	{
		return;
	}

	// 找到中间元素
	int32 Mid = Start + (End - Start) / 2;

	// 中间元素作为根节点
	Result.Add(Mid);

	// 递归构建右子树和左子树
	if (bLeftPriority)
	{
		ULowLevelFunctions::BuildBSTSequence(Start, Mid - 1, bLeftPriority, Result);
		ULowLevelFunctions::BuildBSTSequence(Mid + 1, End, bLeftPriority, Result);
	}
	else
	{
		ULowLevelFunctions::BuildBSTSequence(Mid + 1, End, bLeftPriority, Result);
		ULowLevelFunctions::BuildBSTSequence(Start, Mid - 1, bLeftPriority, Result);
	}
}
#pragma endregion Math


#pragma region Actor


void ULowLevelFunctions::GetActorLocation_P(AActor* InActor, bool bRelation, float& X, float& Y, float& Z)
{
	X = 0.0f;
	Y = 0.0f;
	Z = 0.0f;

	if (!InActor || !InActor->GetRootComponent())
	{
		return;
	}

	FVector Location;
	if (bRelation)
	{
		Location = InActor->GetRootComponent()->GetRelativeLocation();
	}
	else
	{
		Location = InActor->GetActorLocation();
	}

	X = Location.X;
	Y = Location.Y;
	Z = Location.Z;
}

void ULowLevelFunctions::SetActorLocation_P(AActor* InActor, bool bRelation, float X, float Y, float Z)
{
	if (!InActor || !InActor->GetRootComponent())
	{
		return;
	}

	if (bRelation)
	{
		InActor->SetActorRelativeLocation(FVector(X, Y, Z));
	}
	else
	{
		InActor->SetActorLocation(FVector(X, Y, Z));
	}
}

void ULowLevelFunctions::GetActorRotation_P(AActor* InActor, bool bRelation, float& Roll, float& Pitch, float& Yaw)
{
	Roll = 0.0f;
	Pitch = 0.0f;
	Yaw = 0.0f;

	if (!InActor || !InActor->GetRootComponent())
	{
		return;
	}

	FRotator Rotation;
	if (bRelation)
	{
		Rotation = InActor->GetRootComponent()->GetRelativeRotation();
	}
	else
	{
		Rotation = InActor->GetActorRotation();
	}

	Roll = Rotation.Roll;
	Pitch = Rotation.Pitch;
	Yaw = Rotation.Yaw;
}

void ULowLevelFunctions::SetActorRotation_P(AActor* InActor, bool bRelation, float Roll, float Pitch, float Yaw)
{
	if (!InActor || !InActor->GetRootComponent())
	{
		return;
	}

	if (bRelation)
	{
		InActor->SetActorRelativeRotation(FRotator(Pitch, Yaw, Roll));
	}
	else
	{
		InActor->SetActorRotation(FRotator(Pitch, Yaw, Roll));
	}
}

void ULowLevelFunctions::GetActorTransform_P(AActor* InActor, bool bRelation, float& LX, float& LY, float& LZ, float& RX, float& RY, float& RZ, float& RW, float& SX, float& SY, float& SZ)
{
	LX = 0.0f;
	LY = 0.0f;
	LZ = 0.0f;

	RX = 0.0f;
	RY = 0.0f;
	RZ = 0.0f;
	RW = 1.0f;

	SX = 1.0f;
	SY = 1.0f;
	SZ = 1.0f;

	if (!InActor || !InActor->GetRootComponent())
	{
		return;
	}

	FTransform Transform;
	if (bRelation)
	{
		Transform = InActor->GetRootComponent()->GetRelativeTransform();
	}
	else
	{
		Transform = InActor->GetActorTransform();
	}

	FVector Location = Transform.GetTranslation();
	LX = Location.X;
	LY = Location.Y;
	LZ = Location.Z;

	FQuat Quat = Transform.GetRotation();
	RX = Quat.X;
	RY = Quat.Y;
	RZ = Quat.Z;
	RW = Quat.W;

	FVector Scale3D = Transform.GetScale3D();
	SX = Scale3D.X;
	SY = Scale3D.Y;
	SZ = Scale3D.Z;
}

void ULowLevelFunctions::SetActorTransform_P(AActor* InActor, bool bRelation, float LX, float LY, float LZ, float RX, float RY, float RZ, float RW, float SX, float SY, float SZ)
{
	if (!InActor || !InActor->GetRootComponent())
	{
		return;
	}

	if (bRelation)
	{
		InActor->SetActorRelativeTransform(FTransform(FQuat(RX, RY, RZ, RW), FVector(LX, LY, LZ), FVector(SX, SY, SZ)));
	}
	else
	{
		InActor->SetActorTransform(FTransform(FQuat(RX, RY, RZ, RW), FVector(LX, LY, LZ), FVector(SX, SY, SZ)));
	}
}

void ULowLevelFunctions::GetActorForward_P(AActor* InActor, float& X, float& Y, float& Z)
{
	X = 0.0f;
	Y = 0.0f;
	Z = 0.0f;

	if (!InActor || !InActor->GetRootComponent())
	{
		return;
	}

	FVector Direction = InActor->GetActorForwardVector();
	X = Direction.X;
	Y = Direction.Y;
	Z = Direction.Z;
}

void ULowLevelFunctions::ActorAttachToComponent_P(AActor* InActor, USceneComponent* InComponent, const FString& InSocketName)
{
	if (!InActor || !InComponent)
	{
		return;
	}

	InActor->AttachToComponent(InComponent, FAttachmentTransformRules::KeepWorldTransform, FName(InSocketName));
}


#pragma endregion Actor


#pragma region Component


void ULowLevelFunctions::GetComponentLocation_P(USceneComponent* InComponent, bool bRelation, float& X, float& Y, float& Z)
{
	X = 0.0f;
	Y = 0.0f;
	Z = 0.0f;

	if (!InComponent)
	{
		return;
	}

	FVector Location;
	if (bRelation)
	{
		Location = InComponent->GetRelativeLocation();
	}
	else
	{
		Location = InComponent->GetComponentLocation();
	}

	X = Location.X;
	Y = Location.Y;
	Z = Location.Z;
}

void ULowLevelFunctions::SetComponentRotation_P(USceneComponent* InComponent, bool bRelation, float Roll, float Pitch, float Yaw)
{
	if (!InComponent)
	{
		return;
	}

	if (bRelation)
	{
		InComponent->SetRelativeRotation(FRotator(Pitch, Yaw, Roll));
	}
	else
	{
		InComponent->SetWorldRotation(FRotator(Pitch, Yaw, Roll));
	}
}

void ULowLevelFunctions::GetComponentTransform_P(USceneComponent* InComponent, bool bRelation, float& LX, float& LY, float& LZ, float& RX, float& RY, float& RZ, float& RW, float& SX, float& SY, float& SZ)
{
	LX = 0.0f;
	LY = 0.0f;
	LZ = 0.0f;

	RX = 0.0f;
	RY = 0.0f;
	RZ = 0.0f;
	RW = 1.0f;

	SX = 1.0f;
	SY = 1.0f;
	SZ = 1.0f;

	if (!InComponent)
	{
		return;
	}

	FTransform Transform;
	if (bRelation)
	{
		Transform = InComponent->GetRelativeTransform();
	}
	else
	{
		Transform = InComponent->GetComponentTransform();
	}

	FVector Location = Transform.GetTranslation();
	LX = Location.X;
	LY = Location.Y;
	LZ = Location.Z;

	FQuat Quat = Transform.GetRotation();
	RX = Quat.X;
	RY = Quat.Y;
	RZ = Quat.Z;
	RW = Quat.W;

	FVector Scale3D = Transform.GetScale3D();
	SX = Scale3D.X;
	SY = Scale3D.Y;
	SZ = Scale3D.Z;
}

void ULowLevelFunctions::GetComponentUp_P(USceneComponent* InComponent, float& X, float& Y, float& Z)
{
	X = 0.0f;
	Y = 0.0f;
	Z = 0.0f;

	if (!InComponent)
	{
		return;
	}

	FVector Direction = InComponent->GetUpVector();
	X = Direction.X;
	Y = Direction.Y;
	Z = Direction.Z;
}


#pragma endregion Component

#pragma region GameplayOptimization
void ULowLevelFunctions::EnableActorOptimizationForWithoutComposite(AActor * Actor, const bool& bEnable)
{
	if(!IsValid(Actor))
		return ;

	TArray<USceneComponent *> AllSceneComps;
	Actor->GetComponents<USceneComponent>( AllSceneComps);

	for(auto & CompPtr:AllSceneComps)
	{
		CompPtr->bUseAttachParentBound = bEnable;

		if(UPrimitiveComponent *PrimComPtr = Cast<UPrimitiveComponent>(CompPtr))
		{
			PrimComPtr->SetGenerateOverlapEvents(!bEnable);
			PrimComPtr->SetShouldUpdatePhysicsVolume(!bEnable);
			if(USkeletalMeshComponent * SkelComPtr = Cast<USkeletalMeshComponent>(PrimComPtr))
			{
				SkelComPtr->bUpdateOverlapsOnAnimationFinalize = !bEnable;
				EnableAnimTickOptimization(SkelComPtr, bEnable);
				EnableSKMeshOptimization(SkelComPtr, bEnable);
			}
		}
	}
}

void ULowLevelFunctions::EnablePrimitiveComponentOptimization(UPrimitiveComponent * Prim, const bool& bEnable, const bool& bControlUseParentBound)
{
	if(!IsValid(Prim))
		return ;

	if(bControlUseParentBound)
	{
		Prim->bUseAttachParentBound = bEnable;
	}
	Prim->SetGenerateOverlapEvents(!bEnable);
	Prim->SetShouldUpdatePhysicsVolume(!bEnable);
	if(USkeletalMeshComponent * SkelComPtr = Cast<USkeletalMeshComponent>(Prim))
	{
		SkelComPtr->bUpdateOverlapsOnAnimationFinalize = !bEnable;
		EnableAnimTickOptimization(SkelComPtr, bEnable);
		EnableSKMeshOptimization(SkelComPtr, bEnable);
	}
}


void ULowLevelFunctions::EnableSKMeshOptimization(class USkeletalMeshComponent* InSkCom, const bool& bEnable)
{
	if(!IsValid(InSkCom))
		return ;

	InSkCom->bSkipKinematicUpdateWhenInterpolating = bEnable;
	InSkCom->KinematicBonesUpdateType = EKinematicBonesUpdateToPhysics::SkipAllBones;
	InSkCom->bSkipBoundsUpdateWhenInterpolating = bEnable;
	InSkCom->bComponentUseFixedSkelBounds = bEnable;
	InSkCom->bUseScreenRenderStateForUpdate = bEnable;
	InSkCom->bComponentUseExtraPhysicsAssetBounds = true; //优化版的PhysicsAsset Bounds计算方式
	InSkCom->bComputeFastLocalBounds = bEnable; //LocalBounds直接取Bounds换算，这样bUseAttachParentBound渲染Culling和Parent才能对应上！
}



void ULowLevelFunctions::EnableAnimTickOptimization(class USkeletalMeshComponent* InSkCom, const bool& bEnable)
{
	if(!IsValid(InSkCom))
		return ;

	if (bEnable)
	{
		InSkCom->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::OnlyTickPoseWhenRendered;
	}
	else
	{
		InSkCom->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones;
	}
}

void ULowLevelFunctions::EnableOverlapOptimization(class USceneComponent *SceneComponent, const bool& bEnable)
{
	if(!IsValid(SceneComponent))
	{
		return;
	}
	
	SceneComponent->SetShouldUpdatePhysicsVolume(!bEnable);

	if(UPrimitiveComponent* PrimComPtr=Cast<UPrimitiveComponent>(SceneComponent))
	{
		PrimComPtr->SetGenerateOverlapEvents(!bEnable);
	}

	return;
}

void ULowLevelFunctions::EnableOverlapOptimizationWithActor(class AActor *Actor, const bool& bEnable)
{
	if(!IsValid(Actor))
	{
		return;
	}

	TArray<USceneComponent *> AllSceneComps;
	Actor->GetComponents<USceneComponent>( AllSceneComps);

	for(auto & CompPtr:AllSceneComps)
	{
		CompPtr->SetShouldUpdatePhysicsVolume(!bEnable);

		if(UPrimitiveComponent* PrimComPtr=Cast<UPrimitiveComponent>(CompPtr))
		{
			PrimComPtr->SetGenerateOverlapEvents(!bEnable);
		}
	}

	return;
}

#pragma endregion GameplayOptimization

#pragma region Material
void ULowLevelFunctions::SetMIDScalarParameter_P(UMaterialInstanceDynamic* InMID, const FName& InName, float InValue)
{
	if (!InMID)
	{
		return;
	}

	InMID->SetScalarParameterValue(InName, InValue);
}

void ULowLevelFunctions::SetMIDVectorParameter_P(UMaterialInstanceDynamic* InMID, const FName& InName, float InX, float InY, float InZ, float InW)
{
	if (!InMID)
	{
		return;
	}

	InMID->SetVectorParameterValue(InName, FLinearColor(InX, InY, InZ, InW));
}

void ULowLevelFunctions::SetMIDTextureParameter_P(UMaterialInstanceDynamic* InMID, const FName& InName, UTexture* InTexture)
{
	if (!InMID)
	{
		return;
	}

	InMID->SetTextureParameterValue(InName, InTexture);
}

#pragma endregion Material


#pragma region File


void ULowLevelFunctions::FetchAllFiles(const FString& InFoldPath, TArray<FString>& OutFiles)
{
	if (InFoldPath.IsEmpty())
	{
		return;
	}

	IFileManager::Get().FindFilesRecursive(OutFiles, *InFoldPath, TEXT("*.lua"), true, false, true);
}

#pragma endregion File


