// Fill out your copyright notice in the Description page of Project Settings.


#include "Misc/KGScreenshotUtility.h"

#include "Serialization/BufferArchive.h"
#include "DataDrivenShaderPlatformInfo.h"
#include "HighResScreenshot.h"
#include "ImageUtils.h"
#include "Slate/SceneViewport.h"
#include "RendererInterface.h"
#include "EngineGlobals.h"
#include "Misc/AutomationTest.h"
#include "RenderingThread.h"
#include "TextureResource.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "Engine/GameViewportClient.h"
#include "Engine/Texture2D.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Kismet/KismetRenderingLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Logging/LogMacros.h"
#include "UObject/Package.h"
#include "Misc/Base64.h"
#include "Misc/FileHelper.h"
#include "Materials/MaterialInstanceDynamic.h"
DECLARE_STATS_GROUP(TEXT("UKGScreenshotUtility"), STATGROUPKGSCREENSHOT, STATCAT_Advanced);
DECLARE_CYCLE_STAT(TEXT("UKGScreenshotUtility_AddWaterMark"), UKGScreenshotUtility_AddWaterMark, STATGROUPKGSCREENSHOT);
DECLARE_CYCLE_STAT(TEXT("UKGScreenshotUtility_OnScreenShotCaptured"), UKGScreenshotUtility_OnScreenShotCaptured, STATGROUPKGSCREENSHOT);

DEFINE_LOG_CATEGORY(LogKGScreenshotUtility);

FVector2D UKGScreenshotUtility::ClipScreenPosition = FVector2D(0, 0);
FVector2D UKGScreenshotUtility::ClipScreenSize = FVector2D(0, 0);
bool UKGScreenshotUtility::IsClipRect = false;

void UKGScreenshotUtility::Init()
{
}

void UKGScreenshotUtility::UnInit()
{
}

bool UKGScreenshotUtility::TakeScreenShot(bool bShowUI,FString& FileName)
{
	check(IsInGameThread());
	check(GEngine->GameViewport);

	// Make sure any screenshot request has been processed
	FlushRenderingCommands();

	UGameViewportClient* GameViewportClient = GEngine->GameViewport;
	GameViewportClient->OnScreenshotCaptured().AddUObject(this, &UKGScreenshotUtility::OnScreenShotCaptured);

	// bool bSucc = false;

	// if (IsMobilePlatform(GShaderPlatformForFeatureLevel[GMaxRHIFeatureLevel]))
	// {
	// 	// For mobile, use the high res screenshot API to ensure a fixed resolution screenshot is produced.
	// 	// This means screenshot comparisons can compare with the output from any device.
	// 	FHighResScreenshotConfig& Config = GetHighResScreenshotConfig();
	// 	// TWeakPtr<FSceneViewport>VP = *GEngine->GameViewport->GetGameViewport());
	// 	// Config.ChangeViewport(VP);
	// 	FVector2D Size = GEngine->GameViewport->GetGameViewport()->GetSize();
	// 	if (Config.SetResolution(Size.X, Size.Y, 1.0f))
	// 	{
	// 		
	// 		bSucc = GEngine->GameViewport->GetGameViewport()->TakeHighResScreenShot();
	// 	}
	// }
	// else
	// {
		// Screenshots in Unreal Engine work in this way:
		// 1. Call FScreenshotRequest::RequestScreenshot to ask the system to take a screenshot. The screenshot
		//    will have the same resolution as the current viewport;
		// 2. Register a callback to UGameViewportClient::OnScreenshotCaptured() delegate. The call back will be
		//    called with screenshot pixel data when the shot is taken;
		// 3. Wait till the next frame or call FSceneViewport::Invalidate to force a redraw. Screenshot is not
		//    taken until next draw where UGameViewportClient::ProcessScreenshots or
		//    FEditorViewportClient::ProcessScreenshots is called to read pixels back from the viewport. It also
		//    trigger the callback function registered in step 2.
		FScreenshotRequest::RequestScreenshot(FileName,bShowUI,false);
		// bSucc = true;
	// }
	return true;
}

bool UKGScreenshotUtility::TakeScreenShotWithHeadInfoAndMarquee(FString& FileName)
{
	check(IsInGameThread());
	check(GEngine->GameViewport);

	// Make sure any screenshot request has been processed
	FlushRenderingCommands();

	UGameViewportClient* GameViewportClient = GEngine->GameViewport;
	GameViewportClient->OnScreenshotCaptured().AddUObject(this, &UKGScreenshotUtility::OnScreenShotCaptured);
	const uint32 UIFilterChannel = 0x02 | 0x04;// UIFilterChannel: 0x02 for HeadInfo, 0x04 for Marquee
	FScreenshotRequest::RequestScreenshot(FileName, true, false, false, UIFilterChannel);
	return true;
}

bool UKGScreenshotUtility::TakeScreenShotWithClipRect(bool bShowUI, FString& FileName, FVector2D ScreenPosition, FVector2D ScreenSize)
{
	check(IsInGameThread());
	check(GEngine->GameViewport);

	// Make sure any screenshot request has been processed
	FlushRenderingCommands();

	// 验证裁剪区域参数
	if (ScreenSize.X <= 0 || ScreenSize.Y <= 0)
	{
		UE_LOG(LogKGScreenshotUtility, Error, TEXT("TakeScreenShotWithClipRect failed: Invalid ScreenSize (%.2f, %.2f)"), ScreenSize.X, ScreenSize.Y);
		return false;
	}

	if (ScreenPosition.X < 0 || ScreenPosition.Y < 0)
	{
		UE_LOG(LogKGScreenshotUtility, Warning, TEXT("TakeScreenShotWithClipRect: Negative ScreenPosition (%.2f, %.2f), clamping to zero"), ScreenPosition.X, ScreenPosition.Y);
		ScreenPosition.X = FMath::Max(0.f, ScreenPosition.X);
		ScreenPosition.Y = FMath::Max(0.f, ScreenPosition.Y);
	}

	UE_LOG(LogKGScreenshotUtility, Log, TEXT("TakeScreenShotWithClipRect: Position=(%.2f, %.2f), Size=(%.2f, %.2f), File=%s"),
		ScreenPosition.X, ScreenPosition.Y, ScreenSize.X, ScreenSize.Y, *FileName);

	UKGScreenshotUtility::IsClipRect = true;
	UKGScreenshotUtility::ClipScreenPosition = ScreenPosition;
	UKGScreenshotUtility::ClipScreenSize = ScreenSize;
	UGameViewportClient* GameViewportClient = GEngine->GameViewport;
	GameViewportClient->OnScreenshotCaptured().AddUObject(this, &UKGScreenshotUtility::OnScreenShotCaptured);

	FScreenshotRequest::RequestScreenshot(FileName, bShowUI, false);

	return true;
}


void UKGScreenshotUtility::OnScreenShotCaptured(int32 InSizeX, int32 InSizeY, const TArray<FColor>& InImageData)
{
	SCOPE_CYCLE_COUNTER(UKGScreenshotUtility_OnScreenShotCaptured)
	check(GEngine->GameViewport);

	GEngine->GameViewport->OnScreenshotCaptured().RemoveAll(this);

	UE_LOG(LogKGScreenshotUtility, Log, TEXT("OnScreenShotCaptured: CapturedSize=(%d, %d), PixelCount=%d"), InSizeX, InSizeY, InImageData.Num());

	// 检查截图数据是否有效
	if (InImageData.Num() == 0 || InSizeX <= 0 || InSizeY <= 0)
	{
		UE_LOG(LogKGScreenshotUtility, Error, TEXT("OnScreenShotCaptured failed: Invalid captured data. Size=(%d, %d), PixelCount=%d"), InSizeX, InSizeY, InImageData.Num());
		if (OnScreenShotFailedDelegate.IsBound())
		{
			OnScreenShotFailedDelegate.Execute(TEXT("Invalid screenshot data"));
		}
		return;
	}

	LLM_SCOPE_BYNAME(TEXT("UKGScreenshotUtility/ScreenShotCaptured"));

	int32 RTSizeX = InSizeX;
	int32 RTSizeY = InSizeY;
	int32 RTScreenPosX = 0;
	int32 RTScreenPosY = 0;

	if (UKGScreenshotUtility::IsClipRect)
	{
		UE_LOG(LogKGScreenshotUtility, Log, TEXT("ClipRect enabled: Position=(%.2f, %.2f), Size=(%.2f, %.2f)"),
			UKGScreenshotUtility::ClipScreenPosition.X, UKGScreenshotUtility::ClipScreenPosition.Y,
			UKGScreenshotUtility::ClipScreenSize.X, UKGScreenshotUtility::ClipScreenSize.Y);

		FVector2D ClipScreenEndPosition = UKGScreenshotUtility::ClipScreenPosition + UKGScreenshotUtility::ClipScreenSize;
		if (!(UKGScreenshotUtility::ClipScreenPosition.X >= 0 && UKGScreenshotUtility::ClipScreenPosition.X < InSizeX && UKGScreenshotUtility::ClipScreenPosition.Y >= 0 && UKGScreenshotUtility::ClipScreenPosition.Y < InSizeY
			&& ClipScreenEndPosition.X >= 0 && ClipScreenEndPosition.X <= InSizeX && ClipScreenEndPosition.Y >= 0 && ClipScreenEndPosition.Y <= InSizeY))
		{
			UE_LOG(LogKGScreenshotUtility, Warning, TEXT("OnScreenShotCaptured: ClipRect out of bounds, using original image. Position=(%.2f, %.2f), Size=(%.2f, %.2f), CapturedSize=(%d, %d)"),
				UKGScreenshotUtility::ClipScreenPosition.X, UKGScreenshotUtility::ClipScreenPosition.Y,
				UKGScreenshotUtility::ClipScreenSize.X, UKGScreenshotUtility::ClipScreenSize.Y,
				InSizeX, InSizeY);
			// 裁剪失败，使用原图
			UKGScreenshotUtility::IsClipRect = false;
		}
		else
		{
			RTScreenPosX = UKGScreenshotUtility::ClipScreenPosition.X;
			RTScreenPosY = UKGScreenshotUtility::ClipScreenPosition.Y;
			RTSizeX = UKGScreenshotUtility::ClipScreenSize.X;
			RTSizeY = UKGScreenshotUtility::ClipScreenSize.Y;
			UKGScreenshotUtility::IsClipRect = false;
			UE_LOG(LogKGScreenshotUtility, Log, TEXT("ClipRect applied: FinalPos=(%d, %d), FinalSize=(%d, %d)"), RTScreenPosX, RTScreenPosY, RTSizeX, RTSizeY);
		}
	}

	FColor* RawData = new FColor[RTSizeX * RTSizeY];
	UE_LOG(LogKGScreenshotUtility, Log, TEXT("Copying pixel data: RTPos=(%d, %d), RTSize=(%d, %d)"), RTScreenPosX, RTScreenPosY, RTSizeX, RTSizeY);
	for (int i = 0; i < RTSizeY; i++)
	{
		for (int j = 0; j < RTSizeX; j++)
		{
			int DstID = i * RTSizeX + j;
			int SrcID = (RTScreenPosY + i) * InSizeX + (RTScreenPosX + j);
			RawData[DstID] = InImageData[SrcID];
		}
	}
	
	FImageView NewImg(RawData, RTSizeX, RTSizeY);
	UTexture2D* Tex = FImageUtils::CreateTexture2DFromImage(NewImg);
	
	// 检查纹理创建是否成功
	if (Tex == nullptr)
	{
		UE_LOG(LogKGScreenshotUtility, Error, TEXT("OnScreenShotCaptured failed: CreateTexture2DFromImage returned nullptr"));
		delete[] RawData;
		if (OnScreenShotFailedDelegate.IsBound())
		{
			OnScreenShotFailedDelegate.Execute(TEXT("Failed to create texture from image data"));
		}
		return;
	}
	
	UWorld* World = GEngine->GetWorldFromContextObject(GetWorld(), EGetWorldErrorMode::LogAndReturnNull);
	UTextureRenderTarget2D* NewRenderTarget2D = NewObject<UTextureRenderTarget2D>(this);

	if (RTSizeX > 0 && RTSizeY > 0 && World)
	{
		check(NewRenderTarget2D);
		// NewRenderTarget2D->RenderTargetFormat = Format;
		// NewRenderTarget2D->ClearColor = ClearColor;
		NewRenderTarget2D->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA8_SRGB;
		NewRenderTarget2D->bAutoGenerateMips = false;
		NewRenderTarget2D->InitAutoFormat(RTSizeX, RTSizeY);
		NewRenderTarget2D->UpdateResourceImmediate(true);


		if (!FApp::CanEverRender())
		{
			// Returning early to avoid warnings about missing resources that are expected when CanEverRender is false.
			UE_LOG(LogKGScreenshotUtility, Error, TEXT("OnScreenShotCaptured failed: Application cannot render"));
			delete[] RawData;
			if (OnScreenShotFailedDelegate.IsBound())
			{
				OnScreenShotFailedDelegate.Execute(TEXT("Application cannot render"));
			}
			return;
		}
		
		World->FlushDeferredParameterCollectionInstanceUpdates();

		FTextureRenderTargetResource* RenderTargetResource = NewRenderTarget2D->GameThread_GetRenderTargetResource();

		if (CanvasForDrawRT == nullptr)
		{
			CanvasForDrawRT = NewObject<UCanvas>(GetTransientPackage(), NAME_None);
		}

		if (CanvasForDrawRT)
		{
			FCanvas RenderCanvas(
				RenderTargetResource,
				nullptr,
				World,
				World->GetFeatureLevel());

			CanvasForDrawRT->Init(NewRenderTarget2D->SizeX, NewRenderTarget2D->SizeY, nullptr, &RenderCanvas);

			{
				RHI_BREADCRUMB_EVENT_GAMETHREAD("DrawMaterialToRenderTarget:%s", NewRenderTarget2D->GetFName());

				ENQUEUE_RENDER_COMMAND(FlushDeferredResourceUpdateCommand)(
					[RenderTargetResource](FRHICommandListImmediate& RHICmdList)
					{
						RenderTargetResource->FlushDeferredResourceUpdate(RHICmdList);
					});

				
				if(IsOpenGLPlatform(GMaxRHIShaderPlatform))
				{
					//修复截图在安卓端颠倒问题
					CanvasForDrawRT->K2_DrawTexture(Tex, FVector2D(0, 0), FVector2D(RTSizeX, RTSizeY), FVector2D(0, 1),FVector2D(1, -1));
				}else
				{
					CanvasForDrawRT->K2_DrawTexture(Tex, FVector2D(0, 0), FVector2D(RTSizeX, RTSizeY), FVector2D(0, 0));
				}

				
	
				RenderCanvas.Flush_GameThread();
				CanvasForDrawRT->Canvas = nullptr;

				//UpdateResourceImmediate must be called here to ensure mips are generated.
				NewRenderTarget2D->UpdateResourceImmediate(false);
			}
		}
	}
	else
	{
		// RTSizeX/RTSizeY 无效或 World 为空
		UE_LOG(LogKGScreenshotUtility, Error, TEXT("OnScreenShotCaptured failed: Invalid render parameters. RTSize=(%d, %d), World=%s"), 
			RTSizeX, RTSizeY, World ? TEXT("Valid") : TEXT("Null"));
		delete[] RawData;
		if (OnScreenShotFailedDelegate.IsBound())
		{
			OnScreenShotFailedDelegate.Execute(TEXT("Invalid render parameters or world is null"));
		}
		return;
	}

	delete[] RawData;

	if (OnScreenShotCapturedDelegate.IsBound() && Tex != nullptr)
	{
		OnScreenShotCapturedDelegate.Execute(NewRenderTarget2D, RTSizeX, RTSizeY);
	}
	else
	{
		// 成功截图但没有回调监听或纹理无效
		UE_LOG(LogKGScreenshotUtility, Warning, TEXT("OnScreenShotCaptured completed but no delegate bound or Tex is null. IsBound=%d, Tex=%s"), 
			OnScreenShotCapturedDelegate.IsBound(), Tex ? TEXT("Valid") : TEXT("Null"));
		if (Tex == nullptr && OnScreenShotFailedDelegate.IsBound())
		{
			OnScreenShotFailedDelegate.Execute(TEXT("Screenshot succeeded but texture is null"));
		}
	}
}

void UKGScreenshotUtility::AddWaterMark(UTextureRenderTarget2D* MainRT,UTexture* WaterMark,FVector2D& Position,FVector2D& WaterMarkSize, float Rotation)
{
	SCOPE_CYCLE_COUNTER(UKGScreenshotUtility_AddWaterMark)
	if (MainRT == nullptr)
	{
		return;
	}

	if (WaterMark == nullptr)
	{
		return;
	}
	
	if (CanvasForDrawRT == nullptr)
	{
		CanvasForDrawRT = NewObject<UCanvas>(GetTransientPackage(), NAME_None);
	}
	
	UWorld* World = GEngine->GetWorldFromContextObject(GetWorld(), EGetWorldErrorMode::LogAndReturnNull);
	FTextureRenderTargetResource* RenderTargetResource = MainRT->GameThread_GetRenderTargetResource();

	if(World == nullptr || RenderTargetResource ==nullptr)
	{
		return;
	}
	
	if (CanvasForDrawRT)
	{
		FCanvas RenderCanvas(
					RenderTargetResource,
					nullptr,
					World,
					World->GetFeatureLevel() );
		


		CanvasForDrawRT->Init(MainRT->SizeX, MainRT->SizeY, nullptr, &RenderCanvas);

		{
			RHI_BREADCRUMB_EVENT_GAMETHREAD("UKGScreenshotUtilityAddWaterMark:%s", MainRT->GetFName());

			ENQUEUE_RENDER_COMMAND(FlushDeferredResourceUpdateCommand)(
				[RenderTargetResource](FRHICommandListImmediate& RHICmdList)
				{
					RenderTargetResource->FlushDeferredResourceUpdate(RHICmdList);
				});

			CanvasForDrawRT->K2_DrawTexture(
				WaterMark, Position, WaterMarkSize, FVector2D(0, 0),FVector2D(1, 1), FLinearColor::White, BLEND_Translucent, Rotation);

			RenderCanvas.Flush_GameThread();
			CanvasForDrawRT->Canvas = nullptr;

			//UpdateResourceImmediate must be called here to ensure mips are generated.
			MainRT->UpdateResourceImmediate(false);
		}
	}
}

UTextureRenderTarget2D* UKGScreenshotUtility::DuplicationRenderTexture(UTextureRenderTarget2D* SourceTexture)
{
	if (!SourceTexture)
	{
		UE_LOG(LogTemp, Warning, TEXT("Source texture is null."));
		return nullptr;
	}
	
	// 创建一个新的UTextureRenderTarget2D实例
	UTextureRenderTarget2D* DestinationTexture = NewObject<UTextureRenderTarget2D>(this);
	DestinationTexture->RenderTargetFormat = SourceTexture->RenderTargetFormat;
	DestinationTexture->InitAutoFormat(SourceTexture->SizeX, SourceTexture->SizeY);
	DestinationTexture->bAutoGenerateMips = false;
	DestinationTexture->UpdateResourceImmediate(true);
	
	FTextureRenderTargetResource* SourceResource = SourceTexture->GameThread_GetRenderTargetResource();
	FTextureRenderTargetResource* DestResource = DestinationTexture->GameThread_GetRenderTargetResource();
	
	if (!SourceResource || !DestResource)
	{
		UE_LOG(LogTemp, Warning, TEXT("Source or Destination render target resource is null."));
		return DestinationTexture;
	}
	FRHICopyTextureInfo CopyInfo;
    CopyInfo.SourcePosition = FIntVector(0, 0, 0);
    CopyInfo.DestPosition = FIntVector(0, 0, 0);
    CopyInfo.Size = FIntVector(SourceTexture->SizeX, SourceTexture->SizeY, 1);
    CopyInfo.SourceMipIndex = 0;
    CopyInfo.DestMipIndex = 0;
    CopyInfo.NumMips = 1;

    ENQUEUE_RENDER_COMMAND(CopyTextureCommand)(
        [SourceResource, DestResource, CopyInfo](FRHICommandListImmediate& RHICmdList)
        {
            RHICmdList.CopyTexture(SourceResource->TextureRHI, DestResource->TextureRHI, CopyInfo);
        }
    );
	return DestinationTexture;
}

UTextureRenderTarget2D* UKGScreenshotUtility::DuplicationRenderTextureWithRect(UTextureRenderTarget2D* SourceTexture, FVector4 Rect)
{
	if (!SourceTexture)
	{
		UE_LOG(LogTemp, Warning, TEXT("Source texture is null."));
		return nullptr;
	}

	int32 X1 = FMath::RoundToInt(Rect.X);
	int32 Y1 = FMath::RoundToInt(Rect.Y);
	int32 X2 = FMath::RoundToInt(Rect.Z);
	int32 Y2 = FMath::RoundToInt(Rect.W);

	// 验证矩形区域
	if (X1 < 0 || Y1 < 0 || X2 > SourceTexture->SizeX || Y2 > SourceTexture->SizeY || X1 >= X2 || Y1 >= Y2)
	{
		UE_LOG(LogTemp, Warning, TEXT("Invalid rect dimensions."));
		return nullptr;
	}

	int32 DestWidth = X2 - X1;
	int32 DestHeight = Y2 - Y1;

	// 创建一个新的UTextureRenderTarget2D实例
	UTextureRenderTarget2D* DestinationTexture = NewObject<UTextureRenderTarget2D>(this);
	DestinationTexture->RenderTargetFormat = SourceTexture->RenderTargetFormat;
	DestinationTexture->InitAutoFormat(DestWidth, DestHeight);
	DestinationTexture->bAutoGenerateMips = false;
	DestinationTexture->UpdateResourceImmediate(true);

	FTextureRenderTargetResource* SourceResource = SourceTexture->GameThread_GetRenderTargetResource();
	FTextureRenderTargetResource* DestResource = DestinationTexture->GameThread_GetRenderTargetResource();

	if (!SourceResource || !DestResource)
	{
		UE_LOG(LogTemp, Warning, TEXT("Source or Destination render target resource is null."));
		return DestinationTexture;
	}

	FRHICopyTextureInfo CopyInfo;
	CopyInfo.SourcePosition = FIntVector(X1, Y1, 0);
	CopyInfo.DestPosition = FIntVector(0, 0, 0);
	CopyInfo.Size = FIntVector(DestWidth, DestHeight, 1);
	CopyInfo.SourceMipIndex = 0;
	CopyInfo.DestMipIndex = 0;
	CopyInfo.NumMips = 1;

	ENQUEUE_RENDER_COMMAND(CopyTextureCommand)(
		[SourceResource, DestResource, CopyInfo](FRHICommandListImmediate& RHICmdList)
		{
			RHICmdList.CopyTexture(SourceResource->TextureRHI, DestResource->TextureRHI, CopyInfo);
		}
	);

	FlushRenderingCommands();
	return DestinationTexture;
}

UTextureRenderTarget2D* UKGScreenshotUtility::CreateRenderTargetFromTexture2D(UTexture2D* SourceTexture)
{
    if (!SourceTexture)
    {
        UE_LOG(LogKGScreenshotUtility, Warning, TEXT("Source texture is null."));
        return nullptr;
    }

    // 创建一个新的UTextureRenderTarget2D实例
    UTextureRenderTarget2D* DestinationTexture = NewObject<UTextureRenderTarget2D>(this);
    DestinationTexture->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA8_SRGB;
    DestinationTexture->InitAutoFormat(SourceTexture->GetSizeX(), SourceTexture->GetSizeY());
    DestinationTexture->bAutoGenerateMips = false;
    DestinationTexture->UpdateResourceImmediate(true);
	
    UWorld* World = GEngine->GetWorldFromContextObject(GetWorld(), EGetWorldErrorMode::LogAndReturnNull);

    if (CanvasForDrawRT == nullptr)
    {
        CanvasForDrawRT = NewObject<UCanvas>(GetTransientPackage(), NAME_None);
    }

    FTextureRenderTargetResource* DestResource = DestinationTexture->GameThread_GetRenderTargetResource();
    if (!DestResource)
    {
        UE_LOG(LogKGScreenshotUtility, Error, TEXT("Failed to get destination render target resource."));
        return DestinationTexture;
    }

    if (CanvasForDrawRT)
    {
        FCanvas RenderCanvas(
            DestResource,
            nullptr,
            World,
            World->GetFeatureLevel());

        CanvasForDrawRT->Init(DestinationTexture->SizeX, DestinationTexture->SizeY, nullptr, &RenderCanvas);

        RHI_BREADCRUMB_EVENT_GAMETHREAD("CreateRenderTargetFromTexture2D:%s", DestinationTexture->GetFName());

        ENQUEUE_RENDER_COMMAND(FlushDeferredResourceUpdateCommand)(
            [DestResource](FRHICommandListImmediate& RHICmdList)
            {
                DestResource->FlushDeferredResourceUpdate(RHICmdList);
            });

        // 绘制纹理到渲染目标
        CanvasForDrawRT->K2_DrawTexture(
            SourceTexture, 
            FVector2D(0, 0), 
            FVector2D(DestinationTexture->SizeX, DestinationTexture->SizeY), 
            FVector2D(0, 0), 
            FVector2D(1, 1));

        RenderCanvas.Flush_GameThread();
        CanvasForDrawRT->Canvas = nullptr;

        // 更新资源以确保mipmaps生成
        DestinationTexture->UpdateResourceImmediate(false);
    }

    FlushRenderingCommands();

    return DestinationTexture;
}

void UKGScreenshotUtility::AsyncExportRenderTarget(UTextureRenderTarget2D* TextureRenderTarget, const FString& FilePath, const FString& FileName)
{
	FString TotalFileName = FPaths::Combine(*FilePath, *FileName);
	FText PathError;
	FPaths::ValidatePath(TotalFileName, &PathError);
	if (!TextureRenderTarget)
	{
		UE_LOG(LogTemp, Error, TEXT("UKGScreenshotUtility::ExportRenderTarget_InvalidTextureRenderTarget: TextureRenderTarget must be non-null."));
		OnAsyncExportRenderTargetDelegate.ExecuteIfBound(false, TotalFileName);
	}
	else if (!TextureRenderTarget->GetResource())
	{
		UE_LOG(LogTemp, Error, TEXT("UKGScreenshotUtility::ExportRenderTarget_ReleasedTextureRenderTarget: render target has been released."));
		OnAsyncExportRenderTargetDelegate.ExecuteIfBound(false, TotalFileName);
	}
	else if (!PathError.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("UKGScreenshotUtility::ExportRenderTarget_InvalidFilePath : Invalid file path provided: '%s'"), *PathError.ToString());
		OnAsyncExportRenderTargetDelegate.ExecuteIfBound(false, TotalFileName);
	}
	else if (FileName.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("UKGScreenshotUtility::ExportRenderTarget_InvalidFileName: FileName must be non-empty."));
		OnAsyncExportRenderTargetDelegate.ExecuteIfBound(false, TotalFileName);
	}
	else
	{
		FImage Image;
		if (!FImageUtils::GetRenderTargetImage(TextureRenderTarget, Image))
		{
			UE_LOG(LogTemp, Error, TEXT("UKGScreenshotUtility::ExportRenderTarget_FailedRenderTargetImage, FilePath:%s"), *TotalFileName);
			OnAsyncExportRenderTargetDelegate.ExecuteIfBound(false, TotalFileName);
			return;
		}
		FString FormatExtension = TEXT("PNG");
		if (TextureRenderTarget->RenderTargetFormat == RTF_RGBA16f)
		{
			FormatExtension = FPaths::GetExtension(TotalFileName) == TEXT("HDR") ? TEXT("HDR") : TEXT("EXR");
		}
		TWeakObjectPtr<UKGScreenshotUtility> WeakThis(this);
		AsyncTask(ENamedThreads::AnyBackgroundThreadNormalTask, [WeakThis, TotalFileName = MoveTemp(TotalFileName), Image = MoveTemp(Image), FormatExtension = MoveTemp(FormatExtension)]()
		{
			bool Result = false;
			if (FArchive* Ar = IFileManager::Get().CreateFileWriter(*TotalFileName))
			{
				TArray64<uint8> CompressedData;
				if (FImageUtils::CompressImage(CompressedData, *FormatExtension, Image))
				{
					FBufferArchive Buffer;
					Buffer.Serialize((void*)CompressedData.GetData(), CompressedData.GetAllocatedSize());
					Ar->Serialize(const_cast<uint8*>(Buffer.GetData()), Buffer.Num());
					Result = true;
				}
				else
				{
					UE_LOG(LogTemp, Error, TEXT("UKGScreenshotUtility::ExportRenderTarget_FailedCompressImage, FilePath:%s"), *TotalFileName);
				}
				delete Ar;
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("UKGScreenshotUtility::ExportRenderTarget_FailedCreateFileWriter, FilePath:%s"), *TotalFileName);
			}
			FFunctionGraphTask::CreateAndDispatchWhenReady([WeakThis, TotalFileName, Result]
			{
				if (WeakThis.IsValid())
				{
					WeakThis->OnAsyncExportRenderTargetDelegate.ExecuteIfBound(Result, TotalFileName);
				}
			}, {}, nullptr, ENamedThreads::GameThread);
		});
	}
}

FString UKGScreenshotUtility::GetImageBase64FromMaterial(UMaterialInstanceDynamic* MaterialInstanceDynamic, int SizeX, int SizeY)
{
	QUICK_SCOPE_CYCLE_COUNTER(GetImageBase64FromMaterial);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("GetImageBase64FromMaterial");
	
	if (!MaterialInstanceDynamic || SizeX <= 0 || SizeY <= 0)
	{
		return FString();
	}

	UTextureRenderTarget2D* RenderTarget2D = NewObject<UTextureRenderTarget2D>(this);
	RenderTarget2D->InitAutoFormat(SizeX, SizeY);
	RenderTarget2D->bAutoGenerateMips = false;
	RenderTarget2D->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA8_SRGB;
	RenderTarget2D->UpdateResourceImmediate(true);
	UKismetRenderingLibrary::DrawMaterialToRenderTarget(this, RenderTarget2D, MaterialInstanceDynamic);
	FTextureRenderTargetResource* RenderTargetResource = RenderTarget2D->GameThread_GetRenderTargetResource();
	if (TArray<FColor> PixelData; RenderTargetResource->ReadPixels(PixelData))
	{
		TArray64<uint8> PNGData;
		FImageUtils::PNGCompressImageArray(SizeX, SizeY, PixelData, PNGData);
		return FBase64::Encode(PNGData.GetData(), PNGData.Num());
	}
	return FString();
}

void UKGScreenshotUtility::SetWidgetRenderChannel(UWidget* Widget, int32 RenderChannel)
{
	if (!IsValid(Widget))
	{
		UE_LOG(LogTemp, Warning, TEXT("SetWidgetRenderChannel: Invalid Widget"));
		return;
	}

	TSharedPtr<SWidget> SlateWidget = Widget->GetCachedWidget();
	if (SlateWidget.IsValid())
	{
		const uint32 FinalRenderChannel = static_cast<uint32>(RenderChannel) | SLATE_RENDERCHANNLE_DEFAULT_VALUE;
		SlateWidget->SetRenderChannel(FinalRenderChannel);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("SetWidgetRenderChannel: Widget has no cached SWidget"));
	}
}

bool UKGScreenshotUtility::LoadImageFromFile(const FString& Filename, FImage& OutImage)
{
	TArray64<uint8> Buffer;
	if (!FFileHelper::LoadFileToArray(Buffer, *Filename))
	{
		return false;
	}

	return FImageUtils::DecompressImage(Buffer.GetData(), Buffer.Num(), OutImage);
}

UTexture2D* UKGScreenshotUtility::ImportFileAsThumbnailTexture2D(const FString& Filename, int32 MaxThumbnailSize)
{
	if (MaxThumbnailSize <= 0)
	{
		UE_LOG(LogKGScreenshotUtility, Warning, TEXT("ImportFileAsThumbnailTexture2D: Invalid MaxThumbnailSize (%d), using default 256"), MaxThumbnailSize);
		MaxThumbnailSize = 256;
	}

	if (!FPaths::FileExists(Filename))
	{
		UE_LOG(LogKGScreenshotUtility, Error, TEXT("ImportFileAsThumbnailTexture2D: File does not exist: %s"), *Filename);
		return nullptr;
	}

	FImage OriginalImage;
	if (!LoadImageFromFile(Filename, OriginalImage))
	{
		UE_LOG(LogKGScreenshotUtility, Error, TEXT("ImportFileAsThumbnailTexture2D: Failed to load image file: %s"), *Filename);
		return nullptr;
	}

	int32 OriginalWidth = OriginalImage.GetWidth();
	int32 OriginalHeight = OriginalImage.GetHeight();

	if (OriginalWidth <= 0 || OriginalHeight <= 0)
	{
		UE_LOG(LogKGScreenshotUtility, Error, TEXT("ImportFileAsThumbnailTexture2D: Invalid image dimensions (%d x %d)"), OriginalWidth, OriginalHeight);
		return nullptr;
	}

	// 计算缩略图尺寸（保持宽高比）
	int32 ThumbnailWidth = OriginalWidth;
	int32 ThumbnailHeight = OriginalHeight;

	if (OriginalWidth > MaxThumbnailSize || OriginalHeight > MaxThumbnailSize)
	{
		float AspectRatio = static_cast<float>(OriginalWidth) / static_cast<float>(OriginalHeight);

		if (OriginalWidth >= OriginalHeight)
		{
			ThumbnailWidth = MaxThumbnailSize;
			ThumbnailHeight = FMath::Max(1, FMath::RoundToInt(MaxThumbnailSize / AspectRatio));
		}
		else
		{
			ThumbnailHeight = MaxThumbnailSize;
			ThumbnailWidth = FMath::Max(1, FMath::RoundToInt(MaxThumbnailSize * AspectRatio));
		}
	}

	// 如果需要缩放，进行图像缩放
	UTexture2D* ThumbnailTexture = nullptr;
	if (ThumbnailWidth != OriginalWidth || ThumbnailHeight != OriginalHeight)
	{
		// 获取原始图像的 BGRA8 数据并转换为 TArray<FColor>
		TArrayView64<FColor> OriginalView = OriginalImage.AsBGRA8();
		TArray<FColor> SrcColors;
		SrcColors.SetNumUninitialized(OriginalWidth * OriginalHeight);
		FMemory::Memcpy(SrcColors.GetData(), OriginalView.GetData(), OriginalView.Num() * sizeof(FColor));

		// 使用 FImageUtils::ImageResize 进行缩放
		TArray<FColor> ResizedColors;
		ResizedColors.SetNumUninitialized(ThumbnailWidth * ThumbnailHeight);
		FImageUtils::ImageResize(OriginalWidth, OriginalHeight, SrcColors, ThumbnailWidth, ThumbnailHeight, ResizedColors, false, false);

		// 从缩放后的数据创建纹理
		ThumbnailTexture = UTexture2D::CreateTransient(ThumbnailWidth, ThumbnailHeight, PF_B8G8R8A8);
		if (ThumbnailTexture)
		{
			void* TextureData = ThumbnailTexture->GetPlatformData()->Mips[0].BulkData.Lock(LOCK_READ_WRITE);
			FMemory::Memcpy(TextureData, ResizedColors.GetData(), ResizedColors.Num() * sizeof(FColor));
			ThumbnailTexture->GetPlatformData()->Mips[0].BulkData.Unlock();
			ThumbnailTexture->UpdateResource();
		}
	}
	else
	{
		ThumbnailTexture = FImageUtils::CreateTexture2DFromImage(OriginalImage);
	}

	return ThumbnailTexture;
}