﻿// Fill out your copyright notice in the Description page of Project Settings.
#include "Audio/C7AkAmbientSound.h"
#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "Misc/LowLevelFunctions.h"
#include "Scene/Components/C7ShapeCollisionComponent.h"

AC7AkAmbientSound::AC7AkAmbientSound()
{
	AkComponent = CreateDefaultSubobject<UAkComponent>(TEXT("AkComponent0"));
	AkComponent->SetMobility(EComponentMobility::Static);
	RootComponent = AkComponent;

	ShapeCollision = CreateDefaultSubobject<UC7ShapeCollisionComponent>(TEXT("ShapeCollisionComponent0"));
	ShapeCollision->SetupAttachment(RootComponent);
	ULowLevelFunctions::EnableOverlapOptimization(ShapeCollision, true);
	
	static FName CollisionProfileName(TEXT("InteractablePreset"));
	ShapeCollision->SetCollisionProfileName(CollisionProfileName);
	ShapeCollision->SetMobility(EComponentMobility::Static);

	AkExternalSourceInfos.Empty();
}

void AC7AkAmbientSound::BeginPlay()
{
	Super::BeginPlay();

	if (!AkAudioEvent)
	{
		return;
	}

	if (FMath::IsNearlyZero(MaxAttenuationRadius, 0.01f))
	{
		UE_LOG(LogTemp, Warning, TEXT("%s ZERO MaxAttenuationRadius for %s"), *FString(__FUNCTION__), *GetName());
		return;
	}

	ShapeCollision->InitCollisionAsSphere(MaxAttenuationRadius);
	ShapeCollision->OnEnterTrigger_MD.AddDynamic(this, &AC7AkAmbientSound::OnPlayerEnter);
	ShapeCollision->OnLeaveTrigger_MD.AddDynamic(this, &AC7AkAmbientSound::OnPlayerLeave);
	ShapeCollision->InitAsInteractable(0, true);
}

void AC7AkAmbientSound::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	ShapeCollision->EnableInterActiveForDetect(false);
	ShapeCollision->OnEnterTrigger_MD.Clear();
	ShapeCollision->OnLeaveTrigger_MD.Clear();
	Super::EndPlay(EndPlayReason);
}

void AC7AkAmbientSound::OnPlayerEnter(AActor* Player, const FVector& Pos)
{
	if (bOnceOnly && bPlayed)
	{
		return;
	}

	const uint32 PlayingID = AkAudioEvent->PostOnComponent(AkComponent, nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
	bPlayed = true;

	if (PlayingID == AK_INVALID_PLAYING_ID)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s Invalid PlayingID from %s"), *FString(__FUNCTION__), *GetName());
	}
	else
	{
		// UE_LOG(LogTemp, Log, TEXT("%s %s post event %s with playingID:%u"), *FString(__FUNCTION__), *GetName(), *AkAudioEvent->GetName(), PlayingID);
	}
}

void AC7AkAmbientSound::OnPlayerLeave(AActor* Player, const FVector& Pos)
{
	// UE_LOG(LogTemp, Log, TEXT("%s %s stop event %s"), *FString(__FUNCTION__), *GetName(), *AkAudioEvent->GetName());
	AkComponent->Stop();
}

#if WITH_EDITOR

void AC7AkAmbientSound::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	const FString& PropertyName = PropertyChangedEvent.Property->GetName();
	if (PropertyName.Equals("AkAudioEvent"))
	{
		AkComponent->AkAudioEvent = AkAudioEvent;
		if (AkAudioEvent)
		{
			MaxAttenuationRadius = AkAudioEvent->MaxAttenuationRadius;
		}
		else
		{
			MaxAttenuationRadius = 0.f;
		}
	}

	if (PropertyName.Equals("bUseOcclusion"))
	{
		AkComponent->OcclusionRefreshInterval = bUseOcclusion ? OcclusionRefreshInterval : 0.f;
	}
}

#endif
