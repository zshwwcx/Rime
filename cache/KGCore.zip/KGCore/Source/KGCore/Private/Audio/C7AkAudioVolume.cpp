﻿#include "Audio/C7AkAudioVolume.h"

#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "Scene/Components/C7ShapeCollisionComponent.h"
#include "DrawDebugHelpers.h"
#include "Manager/KGAkAudioManager.h"
#include "Misc/LowLevelFunctions.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"


AC7AkAudioVolume::AC7AkAudioVolume()
{
	USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Scene"));
	RootComponent = SceneComponent;
	RootComponent->SetMobility(EComponentMobility::Static);

	// Ak
	AkComponent = CreateDefaultSubobject<UAkComponent>(TEXT("Ak"));
	AkComponent->SetupAttachment(RootComponent);
	AkComponent->SetMobility(EComponentMobility::Movable);

	ShapeCollision = CreateDefaultSubobject<UC7ShapeCollisionComponent>(TEXT("ShapeCollisionComponent0"));
	ShapeCollision->SetupAttachment(RootComponent);
	ULowLevelFunctions::EnableOverlapOptimization(ShapeCollision, true);
	static FName CollisionProfileName(TEXT("InteractablePreset"));
	ShapeCollision->SetCollisionProfileName(CollisionProfileName);
	ShapeCollision->SetMobility(EComponentMobility::Static);

	ExternalSources.Empty();

	PrimaryActorTick.bCanEverTick = true;
	SetActorTickInterval(1.0f);
}

void AC7AkAudioVolume::BeginPlay()
{
	Super::BeginPlay();

	ShapeCollision->OnEnterTrigger_MD.AddDynamic(this, &AC7AkAudioVolume::OnPlayerEnter);
	ShapeCollision->OnLeaveTrigger_MD.AddDynamic(this, &AC7AkAudioVolume::OnPlayerLeave);
	ShapeCollision->InitAsInteractable(0, true);
	
	if (!AkAudioEvent && RtpcNameOfDistanceToVolume.IsEmpty())
	{
		// 不需要Tick逻辑
		SetActorTickEnabled(false);	
	}

	if (AkAudioEvent)
	{
		const int32 PlayingID = AkAudioEvent->PostOnComponent(AkComponent, nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);;
		if (0 == PlayingID)
		{
			UE_LOG(LogTemp, Error, TEXT("%s event %s post failed"), *FString(__FUNCTION__), *AkAudioEvent->GetName());
		}
	}
}

void AC7AkAudioVolume::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	ShapeCollision->EnableInterActiveForDetect(false);
	ShapeCollision->OnEnterTrigger_MD.Clear();
	ShapeCollision->OnLeaveTrigger_MD.Clear();
	
	if (!GroupState.IsEmpty())
	{
		UKGAkAudioManager::OnLeavePriorityGroupStateAudioVolume(this);
	}
	
	if (!RtpcNameOfDistanceToVolume.IsEmpty())
	{
		if (auto* AudioMgr = UKGAkAudioManager::GetInstance(this))
		{
			if (RtpcOwnerType == EC7AkAudioVolumeRtpcOwnerType::Global)
			{
				AudioMgr->InnerResetRtpcValue(RtpcNameOfDistanceToVolume);
			}
			else if (RtpcOwnerType == EC7AkAudioVolumeRtpcOwnerType::Player)
			{
				if (ACharacter* PlayerCharacter = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0))
				{
					if (auto* PlayerAkComp = PlayerCharacter->GetComponentByClass<UAkComponent>())
					{
						AudioMgr->ResetRtpcValueOnAkGameObject(PlayerAkComp, RtpcNameOfDistanceToVolume);
					}
				}
			}
		}
	}

	AkComponent->Stop();
	Super::EndPlay(EndPlayReason);
}

void AC7AkAudioVolume::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (ACharacter* PlayerCharacter = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0))
	{
		const FVector& PlayerLoc = PlayerCharacter->GetActorLocation();
		if (bPlayerInVolume)
		{
			PlayerInsideOfVolume(PlayerLoc);
		}
		else
		{
			PlayerOutsideOfVolume(PlayerLoc);
		}
		
		if (!RtpcNameOfDistanceToVolume.IsEmpty())
		{
			if (auto* AudioMgr = UKGAkAudioManager::GetInstance(this))
			{
				const float Distance = FVector::Dist(PlayerLoc, GetActorLocation());
				if (RtpcOwnerType == EC7AkAudioVolumeRtpcOwnerType::Global)
				{
					AudioMgr->InnerSetRtpcValue(RtpcNameOfDistanceToVolume, Distance);
				}
				else if (RtpcOwnerType == EC7AkAudioVolumeRtpcOwnerType::Player)
				{
					if (auto* PlayerAkComp = PlayerCharacter->GetComponentByClass<UAkComponent>())
					{
						AudioMgr->SetRtpcValueOnAkGameObject(PlayerAkComp, RtpcNameOfDistanceToVolume, Distance);
					}
				}
				else if (RtpcOwnerType == EC7AkAudioVolumeRtpcOwnerType::Volume)
				{
					AudioMgr->SetRtpcValueOnAkGameObject(AkComponent, RtpcNameOfDistanceToVolume, Distance);
				}	
			}
		}
	}

#if WITH_EDITOR
	if (bEnableDebugDraw)
	{
		DrawDebugPoint(GetWorld(), AkComponent->GetComponentLocation(), 10, FColor::Red, false, 1);
	}
#endif
}

void AC7AkAudioVolume::PlayerInsideOfVolume(const FVector& PlayerLoc)
{
	// 和玩家位置重叠
	AkComponent->SetWorldLocation(PlayerLoc);
}

void AC7AkAudioVolume::PlayerOutsideOfVolume(const FVector& PlayerLoc)
{
	// 设置为最近的交点
	const FVector& VolumeLoc = GetActorLocation();
	FVector CrossPoint;

	if (Shape == EC7AkAudioVolumeShape::Sphere)
	{
		const FVector& Vector2SPlayer = PlayerLoc - VolumeLoc;
		const FVector& Vector2Player_N = Vector2SPlayer.GetSafeNormal();
		CrossPoint = VolumeLoc + Radius * Vector2Player_N;
	}
	else
	{
		const float Point2BoxDistance = ULowLevelFunctions::PointToBoxDistance(PlayerLoc, GetTransform(), BoxExtent);
		const FVector& Vector2Box = VolumeLoc - PlayerLoc;
		const FVector& Vector2Box_N = Vector2Box.GetSafeNormal();
		CrossPoint = PlayerLoc + Point2BoxDistance * Vector2Box_N;
	}

	AkComponent->SetWorldLocation(CrossPoint);
}

void AC7AkAudioVolume::OnPlayerEnter(AActor* Player, const FVector& Loc)
{
	if (AkAudioEvent)
	{
		SetActorTickInterval(0.1f);
	}

	bPlayerInVolume = true;
	if (!GroupState.IsEmpty())
	{
		UKGAkAudioManager::OnEnterPriorityGroupStateAudioVolume(this);
	}
}

void AC7AkAudioVolume::OnPlayerLeave(AActor* Player, const FVector& Loc)
{
	if (AkAudioEvent)
	{
		SetActorTickInterval(1.0f);
	}

	bPlayerInVolume = false;
	if (!GroupState.IsEmpty())
	{
		UKGAkAudioManager::OnLeavePriorityGroupStateAudioVolume(this);
	}
}

#if WITH_EDITOR

void AC7AkAudioVolume::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	const FString& PropName = PropertyChangedEvent.MemberProperty->GetName();
	if (PropName.Equals("Radius"))
	{
		ShapeCollision->InitCollisionAsSphere(Radius);
	}
	else if (PropName.Equals("BoxExtent"))
	{
		ShapeCollision->InitCollisionAsBox(BoxExtent);
	}
	else if (PropName.Equals("BoxLineThickness"))
	{
		ShapeCollision->SetLineThickness(BoxLineThickness);
	}
	else if (PropName.Equals("Shape"))
	{
		if (Shape == EC7AkAudioVolumeShape::Box)
		{
			ShapeCollision->InitCollisionAsBox(BoxExtent);
		}
		else if (Shape == EC7AkAudioVolumeShape::Sphere)
		{
			ShapeCollision->InitCollisionAsSphere(Radius);
		}
	}
	else if (PropName.Equals("AkAudioEvent"))
	{
		AkComponent->AkAudioEvent = AkAudioEvent;
	}
	else if (PropName.Equals("bUseOcclusion"))
	{
		AkComponent->OcclusionRefreshInterval = bUseOcclusion ? OcclusionRefreshInterval : 0.f;
	}
}

#endif
