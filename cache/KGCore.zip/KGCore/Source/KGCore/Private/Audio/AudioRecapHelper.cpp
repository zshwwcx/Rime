#include "Audio/AudioRecapHelper.h"
#include "AkComponent.h"
#include "Misc/FileHelper.h"
#include "Serialization/JsonSerializer.h"
#include "UObject/UObjectIterator.h"
#include "Kismet/GameplayStatics.h"
#include "Manager/KGAkAudioManager.h"
#include "Misc/Paths.h"

void FAudioRecapHelper::SetAudioManager(UKGAkAudioManager* InAudioManager)
{
	if (InAudioManager)
	{
		AudioManager = InAudioManager;
	}
}

void FAudioRecapHelper::RebindDelegate()
{
	if (!AudioManager.IsValid())
	{
		return;
	}

	UWorld* World = AudioManager->GetWorld();
	if (!World)
	{
		return;
	}

	World->RemoveOnActorDestroyededHandler(ActorDestroyDelegateHandle);
	ActorDestroyDelegateHandle.Reset();
	FOnActorDestroyed::FDelegate ActorDestroyedDelegate = FOnActorDestroyed::FDelegate::CreateRaw(this, &FAudioRecapHelper::OnActorDestroyed);
	ActorDestroyDelegateHandle = World->AddOnActorDestroyedHandler(ActorDestroyedDelegate);
}

void FAudioRecapHelper::OnRecordStart()
{
	if (!AudioManager.IsValid())
	{
		return;
	}

	UWorld* World = AudioManager->GetWorld();
	if (!World)
	{
		return;
	}

	double CurrentTime = World->GetTimeSeconds();
	CurrentMillisecond = FMath::FloorToInt(CurrentTime * 1000);
	RecordStartTime = CurrentMillisecond;
	UE_LOG(LogAudioMgr, Log, TEXT("[OnRecordStart] at %lld"), RecordStartTime);

	AudioRecords.Empty();
	InitialGroupStates.Empty();
	InitialRtpcs.Empty();
	InitialSwitchesOnAkComp.Empty();
	InitialRtpcsOnAkComp.Empty();
	UsefulGameObject.Empty();
	
	RebindDelegate();
}

void FAudioRecapHelper::OnRecordStop()
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGAkAudioManager::StopRecordAudioRecap");
	UE_LOG(LogAudioMgr, Log, TEXT("[OnRecordStop] at %lld"), CurrentMillisecond);

	AudioRecords.KeySort([](const int64& A, const int64& B)
	{
		return A < B;
	});

	// 所有数据导出Json
	TSharedPtr<FJsonObject> RootObject = MakeShareable(new FJsonObject());

	// 全局参数
	TSharedPtr<FJsonObject> GlobalObject = MakeShareable(new FJsonObject());
	GlobalObject->SetNumberField(TEXT("TimeStampStep"), 66);
	GlobalObject->SetNumberField(TEXT("StartTime"), RecordStartTime);
	RootObject->SetObjectField(TEXT("Global"), GlobalObject);

	// 初始参数
	TSharedPtr<FJsonObject> InitialParamsObject = MakeShareable(new FJsonObject());
	TArray<TSharedPtr<FJsonValue>> InitialGroupStateArray;
	for (const auto& Elem : InitialGroupStates)
	{
		TSharedPtr<FJsonObject> GroupStateRecord = MakeShareable(new FJsonObject);
		GroupStateRecord->SetStringField(TEXT("StateGroupName"), Elem.Key);
		GroupStateRecord->SetStringField(TEXT("StateName"), Elem.Value);
		InitialGroupStateArray.Add(MakeShareable(new FJsonValueObject(GroupStateRecord)));
	}
	InitialParamsObject->SetArrayField(TEXT("State"), InitialGroupStateArray);

	TArray<TSharedPtr<FJsonValue>> InitialSwitchArray;
	for (const auto& Elem : InitialSwitchesOnAkComp)
	{
		TSharedPtr<FJsonObject> SwitchRecord = MakeShareable(new FJsonObject);
		SwitchRecord->SetStringField(TEXT("SwitchGroupName"), Elem.Group);
		SwitchRecord->SetStringField(TEXT("SwitchName"), Elem.State);
		SwitchRecord->SetNumberField(TEXT("GameObject"), Elem.GameObjectID);
		InitialSwitchArray.Add(MakeShareable(new FJsonValueObject(SwitchRecord)));
	}
	InitialParamsObject->SetArrayField(TEXT("Switch"), InitialSwitchArray);

	TArray<TSharedPtr<FJsonValue>> InitialRtpcArray;
	for (const auto& Elem : InitialRtpcs)
	{
		TSharedPtr<FJsonObject> RtpcRecord = MakeShareable(new FJsonObject);
		RtpcRecord->SetStringField(TEXT("RTPCName"), Elem.Key);
		RtpcRecord->SetNumberField(TEXT("RTPCValue"), Elem.Value);
		RtpcRecord->SetNumberField(TEXT("GameObject"), 0);
		InitialRtpcArray.Add(MakeShareable(new FJsonValueObject(RtpcRecord)));
	}
	for (const auto& Elem : InitialRtpcsOnAkComp)
	{
		TSharedPtr<FJsonObject> RtpcRecord = MakeShareable(new FJsonObject);
		RtpcRecord->SetStringField(TEXT("RTPCName"), Elem.RtpcName);
		RtpcRecord->SetNumberField(TEXT("RTPCValue"), Elem.RtpcValue);
		RtpcRecord->SetNumberField(TEXT("GameObject"), Elem.GameObjectID);
		InitialRtpcArray.Add(MakeShareable(new FJsonValueObject(RtpcRecord)));
	}
	InitialParamsObject->SetArrayField(TEXT("RTPC"), InitialRtpcArray);
	RootObject->SetObjectField(TEXT("InitialParams"), InitialParamsObject);

	// 遍历时间戳记录
	TArray<TSharedPtr<FJsonValue>> TimeStampsArray;
	for (const auto& Elem : AudioRecords)
	{
		TSharedPtr<FJsonObject> RecordObject = MakeShareable(new FJsonObject());

		RecordObject->SetNumberField(TEXT("Time"), Elem.Key);
		RecordObject->SetStringField(TEXT("ListenerLocation"), Elem.Value.ListenerLocation.ToString());
		RecordObject->SetStringField(TEXT("ListenerRotator"), Elem.Value.ListenerRotator.ToString());

		// ============================== GameObjectRecords ==============================
		TArray<TSharedPtr<FJsonValue>> GameObjectArray;
		for (const auto& GameObjPair : Elem.Value.GameObjectRecords)
		{
			// 剔除
			if (!UsefulGameObject.Contains(GameObjPair.Key))
			{
				continue;
			}

			TSharedPtr<FJsonObject> ObjRecord = MakeShareable(new FJsonObject);
			ObjRecord->SetNumberField(TEXT("GameObjectID"), GameObjPair.Key);
			ObjRecord->SetStringField(TEXT("GameObjectName"), GameObjPair.Value.GameObjectName);
			ObjRecord->SetStringField(TEXT("Location"), GameObjPair.Value.ObjectLocation.ToString());

			TArray<TSharedPtr<FJsonValue>> EventNameArray;
			for (const auto& EventName : GameObjPair.Value.EventNames)
			{
				EventNameArray.Add(MakeShareable(new FJsonValueString(EventName)));
			}
			ObjRecord->SetArrayField(TEXT("WwiseEventNames"), EventNameArray);

			TArray<TSharedPtr<FJsonValue>> EventIDArray;
			for (const auto& EventID : GameObjPair.Value.EventIDs)
			{
				EventIDArray.Add(MakeShareable(new FJsonValueNumber(EventID)));
			}
			ObjRecord->SetArrayField(TEXT("WwiseEventID"), EventIDArray);

			GameObjectArray.Add(MakeShareable(new FJsonValueObject(ObjRecord)));
		}
		RecordObject->SetArrayField(TEXT("GameObjects"), GameObjectArray);
		// ============================== GameObjectRecords ==============================

		// ============================== Params ==============================
		TSharedPtr<FJsonObject> ParamObject = MakeShareable(new FJsonObject());
		TArray<TSharedPtr<FJsonValue>> GroupStateArray;
		for (const auto& GroupStatePair : Elem.Value.GroupStateRecords)
		{
			TSharedPtr<FJsonObject> GroupStateRecord = MakeShareable(new FJsonObject);
			GroupStateRecord->SetStringField(TEXT("StateGroupName"), GroupStatePair.Group);
			GroupStateRecord->SetStringField(TEXT("StateName"), GroupStatePair.State);
			GroupStateArray.Add(MakeShareable(new FJsonValueObject(GroupStateRecord)));
		}
		ParamObject->SetArrayField(TEXT("State"), GroupStateArray);

		TArray<TSharedPtr<FJsonValue>> SwitchArray;
		for (const auto& SwitchPair : Elem.Value.SwitchRecords)
		{
			TSharedPtr<FJsonObject> SwitchRecord = MakeShareable(new FJsonObject);
			SwitchRecord->SetStringField(TEXT("SwitchGroupName"), SwitchPair.Group);
			SwitchRecord->SetStringField(TEXT("SwitchName"), SwitchPair.State);
			SwitchRecord->SetNumberField(TEXT("GameObject"), SwitchPair.GameObjectID);
			SwitchArray.Add(MakeShareable(new FJsonValueObject(SwitchRecord)));
		}
		ParamObject->SetArrayField(TEXT("Switch"), SwitchArray);

		TArray<TSharedPtr<FJsonValue>> RtpcArray;
		for (const auto& RtpcPair : Elem.Value.RtpcRecords)
		{
			TSharedPtr<FJsonObject> RptcRecord = MakeShareable(new FJsonObject);
			RptcRecord->SetStringField(TEXT("RTPCName"), RtpcPair.RtpcName);
			RptcRecord->SetNumberField(TEXT("RTPCValue"), RtpcPair.RtpcValue);
			RptcRecord->SetNumberField(TEXT("GameObject"), RtpcPair.GameObjectID);
			RtpcArray.Add(MakeShareable(new FJsonValueObject(RptcRecord)));
		}
		ParamObject->SetArrayField(TEXT("RTPC"), RtpcArray);

		RecordObject->SetObjectField(TEXT("ParamsChange"), ParamObject);
		// ============================== Params ==============================

		// ============================== Others ==============================
		TArray<TSharedPtr<FJsonValue>> StoppedPlayingIDArray;
		for (const auto& PlayingID : Elem.Value.StoppedEventIDs)
		{
			StoppedPlayingIDArray.Add(MakeShareable(new FJsonValueNumber(PlayingID)));
		}
		RecordObject->SetArrayField(TEXT("StoppedEventIDs"), StoppedPlayingIDArray);

		TArray<TSharedPtr<FJsonValue>> UnregisteredGameObjectArray;
		for (const auto& GameObjectID : Elem.Value.UnregisteredGameObjects)
		{
			UnregisteredGameObjectArray.Add(MakeShareable(new FJsonValueNumber(GameObjectID)));
		}
		RecordObject->SetArrayField(TEXT("UnregisteredGameObject"), UnregisteredGameObjectArray);
		// ============================== Others ==============================

		TimeStampsArray.Add(MakeShareable(new FJsonValueObject(RecordObject)));
	}

	RootObject->SetArrayField(TEXT("TimeStamps"), TimeStampsArray);

	// 序列化为字符串
	FString OutputString;
	const TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputString);
	FJsonSerializer::Serialize(RootObject.ToSharedRef(), Writer);

	// 写文件
	FString FilePath = FPaths::ProjectSavedDir() / FString::Printf(TEXT("AudioRecap_%lld.json"), RecordStartTime);
	FFileHelper::SaveStringToFile(OutputString, *FilePath);

	// 清理数据
	AudioRecords.Empty();
	InitialGroupStates.Empty();
	InitialRtpcs.Empty();
	InitialSwitchesOnAkComp.Empty();
	InitialRtpcsOnAkComp.Empty();

	CurrentMillisecond = 0;
	RecordStartTime = 0;

	if (AudioManager.IsValid())
	{
		if (UWorld* World = AudioManager->GetWorld())
		{
			World->RemoveOnActorDestroyededHandler(ActorDestroyDelegateHandle);
			ActorDestroyDelegateHandle.Reset();
		}
	}
}

void FAudioRecapHelper::RecordInitialParams(
	const TMap<FString, FString>& InGroupState,
	const TMap<FString, float>& InRtpcs,
	const TMap<AkGameObjectID, TMap<FString, float>>& InGameObjectRtpcs,
	const TMap<AkGameObjectID, TMap<FString, FString>>& InGameObjectSwitches)
{
	if (!AudioManager.IsValid())
	{
		return;
	}

	UWorld* World = AudioManager->GetWorld();
	if (!World)
	{
		return;
	}

	InitialGroupStates = InGroupState;
	InitialRtpcs = InRtpcs;

	for (auto& It : InGameObjectRtpcs)
	{
		AkGameObjectID GameObjectID = It.Key;
		const TMap<FString, float>& Rtpcs = It.Value;
		
		UsefulGameObject.Emplace(GameObjectID, true);
		for (const auto& Rtpc : Rtpcs)
		{
			InitialRtpcsOnAkComp.Emplace(FKGRtpc(Rtpc.Key, Rtpc.Value, GameObjectID));
		}
	}

	for (auto& It : InGameObjectSwitches)
	{
		AkGameObjectID GameObjectID = It.Key;
		const TMap<FString, FString>& Switches = It.Value;

		UsefulGameObject.Emplace(GameObjectID, true);
		for (auto SwitchGroup : Switches)
		{
			InitialSwitchesOnAkComp.Emplace(FKGGroupState(SwitchGroup.Key, SwitchGroup.Value, GameObjectID));
		}
	}
}

void FAudioRecapHelper::OnRecordTick()
{
	if (!AudioManager.IsValid())
	{
		return;
	}

	UWorld* World = AudioManager->GetWorld();
	if (!World)
	{
		return;
	}

	double CurrentTime = World->GetTimeSeconds();
	double Millisecond = FMath::FloorToInt(CurrentTime * 1000);
	if (Millisecond - CurrentMillisecond < 67)
	{
		return;
	}

	CurrentMillisecond = Millisecond;

	FAudioRecord& AudioRecord = AudioRecords.Add(CurrentMillisecond);

	// 获取所有GameObject
	TArray<UAkGameObject*> AkGameObjects;
	for (TObjectIterator<UAkGameObject> It; It; ++It)
	{
		if (It->GetWorld() == World)
		{
			AkGameObjects.Add(*It);
		}
	}

	for (auto& AkGameObject : AkGameObjects)
	{
		AkGameObjectID GameObjectID = AkGameObject->GetAkGameObjectID();
		FAudioGameObjectRecord& NewRecord = AudioRecord.GameObjectRecords.Add(GameObjectID);
		NewRecord.ObjectLocation = AkGameObject->K2_GetComponentLocation();
	}

	// 记录ListenerLocation
	if (APlayerController* PlayerController = UGameplayStatics::GetPlayerController(World, 0))
	{
		if (IsValid(PlayerController->PlayerCameraManager))
		{
			AudioRecord.ListenerLocation = PlayerController->PlayerCameraManager->GetCameraLocation();
			AudioRecord.ListenerRotator = PlayerController->PlayerCameraManager->GetCameraRotation();
		}
	}
}

void FAudioRecapHelper::RecordEventPost(const FString& EventName, int32 PlayingID, const UAkGameObject* GameObject, const FVector& ObjectLocation)
{
	if (PlayingID == AK_INVALID_PLAYING_ID)
	{
		return;
	}

	FAudioRecord* AudioRecord = AudioRecords.Find(CurrentMillisecond);
	if (!AudioRecord)
	{
		return;
	}

	AkGameObjectID GameObjectID = 0;
	FString ObjectName;
	if (!GameObject)
	{
		GameObjectID = (AkGameObjectID)&EventName;
	}
	else
	{
		GameObjectID = GameObject->GetAkGameObjectID();
		if (AActor* Owner = GameObject->GetOwner())
		{
			ObjectName = Owner->GetName();
		}
	}

	UsefulGameObject.Emplace(GameObjectID, true);

	if (FAudioGameObjectRecord* GameObjectRecord = AudioRecord->GameObjectRecords.Find(GameObjectID))
	{
		GameObjectRecord->EventNames.Add(EventName);
		GameObjectRecord->EventIDs.Add(PlayingID);
	}
	else
	{
		FAudioGameObjectRecord& NewGameObjectRecord = AudioRecord->GameObjectRecords.Add(GameObjectID);
		NewGameObjectRecord.EventNames.Add(EventName);
		NewGameObjectRecord.EventIDs.Add(PlayingID);
		NewGameObjectRecord.ObjectLocation = ObjectLocation;
		NewGameObjectRecord.GameObjectName = ObjectName;
	}
}

void FAudioRecapHelper::RecordGroupState(const FString& GroupName, const FString& StateName)
{
	FAudioRecord* AudioRecord = AudioRecords.Find(CurrentMillisecond);
	if (!AudioRecord)
	{
		return;
	}

	AudioRecord->GroupStateRecords.Add(FKGGroupState(GroupName, StateName));
}

void FAudioRecapHelper::RecordRtpc(const FString& RtpcName, float RtpcValue, const UAkGameObject* GameObject)
{
	FAudioRecord* AudioRecord = AudioRecords.Find(CurrentMillisecond);
	if (!AudioRecord)
	{
		return;
	}

	if (!GameObject)
	{
		AudioRecord->RtpcRecords.Add(FKGRtpc(RtpcName, RtpcValue));
	}
	else
	{
		AkGameObjectID GameObjectID = GameObject->GetAkGameObjectID();
		AudioRecord->RtpcRecords.Add(FKGRtpc(RtpcName, RtpcValue, GameObjectID));
		UsefulGameObject.Emplace(GameObjectID, true);
	}
}

void FAudioRecapHelper::RecordSwitch(const FString& SwitchGroupName, const FString& SwitchStateName, const UAkGameObject* GameObject)
{
	FAudioRecord* AudioRecord = AudioRecords.Find(CurrentMillisecond);
	if (!AudioRecord)
	{
		return;
	}

	if (!GameObject)
	{
		return;
	}

	AkGameObjectID GameObjectID = GameObject->GetAkGameObjectID();
	AudioRecord->SwitchRecords.Add(FKGGroupState(SwitchGroupName, SwitchStateName, GameObjectID));
	UsefulGameObject.Emplace(GameObjectID, true);
}

void FAudioRecapHelper::RecordEventStopped(int32 PlayingID)
{
	FAudioRecord* AudioRecord = AudioRecords.Find(CurrentMillisecond);
	if (!AudioRecord)
	{
		return;
	}

	if (PlayingID == AK_INVALID_PLAYING_ID)
	{
		return;
	}

	AudioRecord->StoppedEventIDs.Add(PlayingID);
}

void FAudioRecapHelper::OnActorDestroyed(AActor* Actor)
{
	if (!Actor)
    {
    	return;
    }

	if (UAkGameObject* AkGameObject = Actor->FindComponentByClass<UAkGameObject>())
	{
		if (FAudioRecord* AudioRecord = AudioRecords.Find(CurrentMillisecond))
		{
			AudioRecord->UnregisteredGameObjects.Add(AkGameObject->GetAkGameObjectID());
		}
	}
}
