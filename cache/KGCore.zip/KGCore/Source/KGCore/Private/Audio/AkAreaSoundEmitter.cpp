﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Audio/AkAreaSoundEmitter.h"

#include "AkAudioBank.h"
#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"


AAkAreaSoundEmitter::AAkAreaSoundEmitter()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 1.f;

	PointList.Empty();
	AkExternalSourceInfos.Empty();

	if (USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("DefaultSceneRoot")))
	{
		SetRootComponent(SceneComponent);
		SceneComponent->SetMobility(EComponentMobility::Static);
		
		SplineComponent = CreateDefaultSubobject<USplineComponent>(TEXT("Spline"));
		if (SplineComponent)
		{
			SplineComponent->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
			SplineComponent->SetDrawDebug(false);
			SplineComponent->SetMobility(EComponentMobility::Static);
		}
		
		AkComponent = CreateDefaultSubobject<UAkComponent>(TEXT("Ak"));
		if (AkComponent)
		{
			AkComponent->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
			AkComponent->SetMobility(EComponentMobility::Static);
		}
	}
}

void AAkAreaSoundEmitter::BeginPlay()
{
	Super::BeginPlay();

	// Event没有配置,不生效
	if (!AkComponent->AkAudioEvent)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s %s have no AkAudioEvent"), *FString(__FUNCTION__), *GetName());
		SetActorTickEnabled(false);
		return;
	}

	// 判断最大衰减距离
	if (FMath::IsNearlyZero(MaxAttenuationRadius, 0.01f))
	{
		UE_LOG(LogTemp, Warning, TEXT("%s %s AkAudioEvent:%s got zero MaxAttenuationRadius"), *FString(__FUNCTION__), *GetName(), *AkComponent->AkAudioEvent->GetName());
		SetActorTickEnabled(false);
		return;
	}

	// 计算所有点
	const int32 SplinePointNum = SplineComponent->GetNumberOfSplinePoints();
	for (int32 Idx = 0; Idx < SplinePointNum; ++Idx)
	{
		FVector Location = SplineComponent->GetLocationAtSplinePoint(Idx, ESplineCoordinateSpace::World);
		FVector Tangent = SplineComponent->GetTangentAtSplinePoint(Idx, ESplineCoordinateSpace::World);
		FRotator Rotator = Tangent.Rotation();
		PointList.Add(FTransform(Rotator, Location));
	}

	// 设置Component声源点
	UAkGameplayStatics::SetMultiplePositions(AkComponent, PointList, AkMultiPositionType::MultiDirections);
}

void AAkAreaSoundEmitter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	StopAreaEvent();
	Super::EndPlay(EndPlayReason);
}

void AAkAreaSoundEmitter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	const ACharacter* MainPlayer = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (!MainPlayer)
	{
		return;
	}

	const FVector& MainPlayLoc = MainPlayer->GetActorLocation();

	if (0 == PlayingID)
	{
		// 没有音频播放,计算距离,只要有一个点小于最大衰减就播放
		for (auto& Point : PointList)
		{
			const float Distance = FVector::Distance(Point.GetLocation(), MainPlayLoc);
			if (Distance < MaxAttenuationRadius)
			{
				PostAreaEvent();
				return;
			}
		}
	}
	else
	{
		// 有音频播放,计算所有点的距离,如果都大于最大衰减就停止播放
		for (auto& Point : PointList)
		{
			const float Distance = FVector::Distance(Point.GetLocation(), MainPlayLoc);
			if (Distance < MaxAttenuationRadius)
			{
				return;
			}
		}

		StopAreaEvent();
	}
}

void AAkAreaSoundEmitter::PostAreaEvent()
{
	PlayingID = AkComponent->AkAudioEvent->PostOnComponent(AkComponent, nullptr, nullptr, nullptr, (AkCallbackType)0, nullptr, true);
	// UE_LOG(LogTemp, Log, TEXT("%s %s post %s with playingID:%u"), *FString(__FUNCTION__), *GetName(), *AkComponent->AkAudioEvent->GetName(), PlayingID);
}

void AAkAreaSoundEmitter::StopAreaEvent()
{
	// UE_LOG(LogTemp, Log, TEXT("%s %s stop playingID:%u"), *FString(__FUNCTION__), *GetName(), PlayingID);
	AkComponent->Stop();
	PlayingID = 0;
}

#if WITH_EDITOR

void AAkAreaSoundEmitter::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	const FString& PropertyName = PropertyChangedEvent.Property->GetName();
	if (PropertyName.Equals("AkAudioEvent"))
	{
		AkComponent->AkAudioEvent = AkAudioEvent;
		if (AkAudioEvent)
		{
			MaxAttenuationRadius = AkAudioEvent->MaxAttenuationRadius;
		}
		else
		{
			MaxAttenuationRadius = 0.f;
		}
	}
	
	if (PropertyName.Equals("bUseOcclusion"))
	{
		AkComponent->OcclusionRefreshInterval = bUseOcclusion ? OcclusionRefreshInterval : 0.f;
	}

	if (PropertyName.Equals("outerRadius"))
	{
		AkComponent->outerRadius = outerRadius;
	}

	if (PropertyName.Equals("innerRadius"))
	{
		AkComponent->innerRadius = innerRadius;
	}
}

#endif
