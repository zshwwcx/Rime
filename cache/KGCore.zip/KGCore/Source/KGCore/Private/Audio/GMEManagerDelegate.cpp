#include "Audio/GMEManagerDelegate.h"
#include "Audio/GMEManager.h"

#ifdef DISABLE_GME
#else
void GMEDelegate::OnEvent(ITMG_MAIN_EVENT_TYPE eventType, const char* data)
{
	if (UGMEManager* Ptr = Manager.Get()) {
		Ptr->OnEvent(eventType, data, ChannelType);
	}
}
#endif