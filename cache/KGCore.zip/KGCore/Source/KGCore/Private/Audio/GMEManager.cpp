#include "Audio/GMEManager.h"
#include "Audio/GMEManagerDelegate.h"
#include "HAL/FileManager.h"

#include "Serialization/JsonTypes.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Misc/Base64.h"
#ifdef DISABLE_GME
#else
// #include "../../../Plugins/GMESDK/Source/GMESDK/Public/GMESDK/av_type.h"
// #include "../../../Plugins/GMESDK/Source/GMESDK/Public/GMESDK/tmg_sdk.h"

#include "GMESDK/av_type.h"
#include "GMESDK/tmg_sdk.h"
#endif

#include "Misc/Log.h"

DECLARE_CYCLE_STAT(TEXT("GMEManager Tick"), STAT_GMEManagerTick, STATGROUP_Game);

void UGMEManager::NativeInit()
{
	Super::NativeInit();

	// 静态导出
	using namespace NS_SLUA;

	REG_MANAGER_FUNC(UGMEManager, "KAPI_InitGME", &UGMEManager::KAPI_InitGME);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_UninitGME", &UGMEManager::KAPI_UninitGME);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_EnterRoom", &UGMEManager::KAPI_EnterRoom);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_ExitRoom", &UGMEManager::KAPI_ExitRoom);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_SetVoiceType", &UGMEManager::KAPI_SetVoiceType);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_EnableMic", &UGMEManager::KAPI_EnableMic);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_EnableAudioCaptureDevice", &UGMEManager::KAPI_EnableAudioCaptureDevice);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_IsAudioCaptureDeviceEnabled", &UGMEManager::KAPI_IsAudioCaptureDeviceEnabled);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_EnableAudioSend", &UGMEManager::KAPI_EnableAudioSend);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_IsAudioSendEnabled", &UGMEManager::KAPI_IsAudioSendEnabled);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_SetScene", &UGMEManager::KAPI_SetScene);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_SetAudioRole", &UGMEManager::KAPI_SetAudioRole);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_SetAdvanceParams", &UGMEManager::KAPI_SetAdvanceParams);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_GetMicState", &UGMEManager::KAPI_GetMicState);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_EnableSpeaker", &UGMEManager::KAPI_EnableSpeaker);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_StartRecording", &UGMEManager::KAPI_StartRecording);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_StartRecordingWithStreamingRecognition", &UGMEManager::KAPI_StartRecordingWithStreamingRecognition);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_StopRecording", &UGMEManager::KAPI_StopRecording);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_CancelRecording", &UGMEManager::KAPI_CancelRecording);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_UploadRecordedFile", &UGMEManager::KAPI_UploadRecordedFile);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_DownloadRecordedFile", &UGMEManager::KAPI_DownloadRecordedFile);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_PlayRecordedFile", &UGMEManager::KAPI_PlayRecordedFile);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_StopPlayFile", &UGMEManager::KAPI_StopPlayFile);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_GetVoiceFileDuration", &UGMEManager::KAPI_GetVoiceFileDuration);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_SetMaxMessageLength", &UGMEManager::KAPI_SetMaxMessageLength);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_GetMicLevel", &UGMEManager::KAPI_GetMicLevel);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_GetMicVolume", &UGMEManager::KAPI_GetMicVolume);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_GetSpeakerLevel", &UGMEManager::KAPI_GetSpeakerLevel);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_GetSpeakerVolume", &UGMEManager::KAPI_GetSpeakerVolume);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_SetMicVolume", &UGMEManager::KAPI_SetMicVolume);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_SetSpeakerVolume", &UGMEManager::KAPI_SetSpeakerVolume);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_AddAudioBlackList", &UGMEManager::KAPI_AddAudioBlackList);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_RemoveAudioBlackList", &UGMEManager::KAPI_RemoveAudioBlackList);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_CreateChannelContext", &UGMEManager::KAPI_CreateChannelContext);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_DestroyChannelContext", &UGMEManager::KAPI_DestroyChannelContext);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_PauseContext", &UGMEManager::KAPI_PauseContext);
	REG_MANAGER_FUNC(UGMEManager, "KAPI_ResumeContext", &UGMEManager::KAPI_ResumeContext);
}

void UGMEManager::NativeUninit()
{
	Super::NativeUninit();
}

void UGMEManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_DuringPhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);
	TickFunction.SetPriorityIncludingPrerequisites(true);
}

void UGMEManager::Tick(float DeltaTime)
{
	//TRACE_CPUPROFILER_EVENT_SCOPE_STR("GMEManager_Tick");
	SCOPE_CYCLE_COUNTER(STAT_GMEManagerTick);


	#ifdef DISABLE_GME
#else
	if (bEnabled)
	{
		ITMGContextGetInstance()->Poll();
		for (auto It = ITMGContextMap.CreateIterator(); It; ++It)
		{
			ITMGContext* Context = It.Value();
			Context->Poll();
		}
	}

#endif
}



void UGMEManager::KAPI_UninitGME()
{
#ifdef DISABLE_GME
#else

	bEnabled = false;

	for (auto It = ITMGContextMap.CreateIterator(); It; ++It)
	{
		ITMGContext* Context = It.Value();
		Context->Uninit();
		ITMGContextGetInstance()->DestroySubInstance(Context);
	}
	ITMGContextMap.Empty();
	ITMGDelegateMap.Empty();
	ITMGContextGetInstance()->Uninit();
#endif
}

// 初始化GME
int32 UGMEManager::KAPI_InitGME(const FString& SdkAppId,const FString& SdkAppKey,const FString& InUserId,const FString& InUserSig) {

#ifdef DISABLE_GME
	return 0;
#else
	ITMGContextGetInstance()->SetAdvanceParams("StringOpenID", "1");
	int32 nAppid = FCString::Atoi(*SdkAppId);
	int32 ret = ITMGContextGetInstance()->Init(TCHAR_TO_UTF8(*SdkAppId), TCHAR_TO_UTF8(*InUserId));
	UE_LOG(LogC7, Display, TEXT("InitGME retcode = %d"), ret);

	TSharedPtr<ITMGDelegate> newTMGDelegate = MakeShareable(new GMEDelegate(0, this));
	ITMGDelegateMap.Add(0, newTMGDelegate);
	ITMGContextGetInstance()->SetTMGDelegate(newTMGDelegate.Get());

	int32 RetCode = (int32)ITMGContextGetInstance()->CheckMicPermission();
	UE_LOG(LogC7, Display, TEXT("Check Mic Permission retcode = %d"), RetCode);

	AppId = SdkAppId;
	AppKey = SdkAppKey;
	UserId = InUserId;

	bEnabled = true;
	ApplyAuthBuffer(ITMGContextGetInstance(), InUserSig, TEXT(""), TEXT(""));
	return ret;
#endif
}

void UGMEManager::KAPI_EnterRoom(const FString& RoomID, int32 RoomType, int32 ChannelType, const FString& InUserSig) {
#ifdef DISABLE_GME
#else
	unsigned char strSig[1024] = { 0 };
	int32 nLength = 1024;
	GenerateAuthBuffer(InUserSig, RoomID, strSig, nLength);
	
	if (InUserSig.IsEmpty() || InUserSig.Len() == 0)
	{
		UE_LOG(LogC7, Display, TEXT("OnEnterRoom with generated sig userSigLen = %d"), nLength);
	}
	else
	{
		UE_LOG(LogC7, Display, TEXT("OnEnterRoom with InUserSig userSigLen = %d"), nLength);
	}
	
	ITMGContext* channelTMGContext = GetOrCreatChannelContext(ChannelType, InUserSig);
	channelTMGContext->EnterRoom(TCHAR_TO_UTF8(*RoomID), (ITMG_ROOM_TYPE)RoomType, (const char*)strSig, nLength);
#endif
}

// 退出房间
int32 UGMEManager::KAPI_ExitRoom(int32 ChannelType)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* channelTMGContext = GetChannelContext(ChannelType);
	if (channelTMGContext != nullptr)
		return channelTMGContext->ExitRoom();
	else
		return 0;
#endif
}

#ifdef DISABLE_GME
#else
void UGMEManager::OnEvent(ITMG_MAIN_EVENT_TYPE eventType, const char* data, int32 channelType)
{
#ifdef DISABLE_GME
#else
	FString jsonData = FString(UTF8_TO_TCHAR(data));
	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(FString(UTF8_TO_TCHAR(data)));
	FJsonSerializer::Deserialize(Reader, JsonObject);

	switch (eventType)
	{
	case ITMG_MAIN_EVENT_TYPE_ENTER_ROOM:
	{
		int32 result = JsonObject->GetIntegerField(TEXT("result"));
		FString error_info = JsonObject->GetStringField(TEXT("error_info"));
		if (result == 0) {
			UE_LOG(LogC7, Display, TEXT("Enter room success"))
		}
		else {
			UE_LOG(LogC7, Display, TEXT("Enter room failed. result= %d, info = %ls"), result, *error_info)
		}
		OnEnterRoomCompleted(result, error_info, channelType);
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_CHANGE_ROOM_TYPE:
	{
		int32 nResult = JsonObject->GetIntegerField(TEXT("result"));
		FString error_info = JsonObject->GetStringField(TEXT("error_info"));
		int32 nSubEventType = JsonObject->GetIntegerField(TEXT("sub_event_type"));
		int32 nNewType = JsonObject->GetIntegerField(TEXT("new_room_type"));

		FString msg("CHANGE_ROOM_TYPE");
		// switch (nSubEventType) {
		// case ITMG_ROOM_CHANGE_EVENT_ENTERROOM:
		// 	msg = FString::Printf(TEXT("onRoomTypeChanged ITMG_ROOM_CHANGE_EVENT_ENTERROOM nNewType=%d"), nNewType);
		// 	break;
		// case ITMG_ROOM_CHANGE_EVENT_COMPLETE:
		// 	msg = FString::Printf(TEXT("onRoomTypeChanged ITMG_ROOM_CHANGE_EVENT_COMPLETE nNewType=%d"), nNewType);
		// 	break;
		// }
		UE_LOG(LogC7, Display, TEXT("%s"), *msg)
			break;
	}
	case ITMG_MAIN_EVENT_TYPE_EXIT_ROOM:
	{
		FString error_info = JsonObject->GetStringField(TEXT("error_info"));
		UE_LOG(LogC7, Display, TEXT("Exit room success"));
		OnExitRoomCompleted(0, error_info, channelType);
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_ROOM_DISCONNECT:
	{
		int32 result = JsonObject->GetIntegerField(TEXT("result"));
		FString error_info = JsonObject->GetStringField(TEXT("error_info"));
		OnExitRoomCompleted(result, error_info, channelType);
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_USER_UPDATE:
	{
		int32 eventId = JsonObject->GetIntegerField(TEXT("event_id"));
		TArray<TSharedPtr<FJsonValue>> UserList = JsonObject->GetArrayField(TEXT("user_list"));
		for (int32 i = 0; i < UserList.Num(); i++) {
			FString identifier = UserList.operator[](i)->AsString();
			OnEndpointsUpdateInfo(eventId, identifier, channelType);
		}
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_PTT_RECORD_COMPLETE:
	{
		int32 result = JsonObject->GetIntegerField(TEXT("result"));
		FString filepath = JsonObject->GetStringField(TEXT("file_path"));

		auto path = StringCast<UTF8CHAR>(*filepath);

		int32 duration = 0;
		int32 filesize = 0;
		if (result == 0) {
			duration = ITMGContextGetInstance()->GetPTT()->GetVoiceFileDuration((ANSICHAR*)path.Get());
			filesize = ITMGContextGetInstance()->GetPTT()->GetFileSize((ANSICHAR*)path.Get());
		}

		OnPttRecordFileCompleted(result, filepath, duration, filesize);
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_PTT_UPLOAD_COMPLETE:
	{
		int32 result = JsonObject->GetIntegerField(TEXT("result"));
		FString filepath = JsonObject->GetStringField(TEXT("file_path"));
		FString fileid = JsonObject->GetStringField(TEXT("file_id"));
		OnPttUploadFileCompleted(result, filepath, fileid);
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_PTT_DOWNLOAD_COMPLETE:
	{
		int32 result = JsonObject->GetIntegerField(TEXT("result"));
		FString filepath = JsonObject->GetStringField(TEXT("file_path"));
		FString fileid = JsonObject->GetStringField(TEXT("file_id"));
		OnPttDownloadFileCompleted(result, filepath, fileid);
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_PTT_PLAY_COMPLETE:
	{
		int32 result = JsonObject->GetIntegerField(TEXT("result"));
		FString filepath = JsonObject->GetStringField(TEXT("file_path"));
		OnPttPlayFileCompleted(result, filepath);
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_PTT_SPEECH2TEXT_COMPLETE:
	{
		int32 result = JsonObject->GetIntegerField(TEXT("result"));
		FString text = JsonObject->GetStringField(TEXT("text"));
		FString fileid = JsonObject->GetStringField(TEXT("file_id"));
		OnPttSpeech2TextCompleted(result, fileid, text);
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_PTT_STREAMINGRECOGNITION_COMPLETE:
	{
		int32 nResult = JsonObject->GetIntegerField(TEXT("result"));
		FString text = JsonObject->GetStringField(TEXT("text"));
		FString fileid = JsonObject->GetStringField(TEXT("file_id"));
		FString file_path = JsonObject->GetStringField(TEXT("file_path"));
		OnPttStreamRecognitionCompleted(nResult, file_path, fileid, text);
		break;
	}
	case ITMG_MAIN_EVENT_TYPE_PTT_STREAMINGRECOGNITION_IS_RUNNING:
	{
		int32 nResult = JsonObject->GetIntegerField(TEXT("result"));
		FString text = JsonObject->GetStringField(TEXT("text"));
		FString fileid = TEXT("STREAMINGRECOGNITION_IS_RUNNING");
		FString file_path = JsonObject->GetStringField(TEXT("file_path"));
		OnPttStreamRecognitionisRunning(nResult, file_path, fileid, text);
		break;
	}
	}
#endif
}
#endif

// 设置应用场景
int32 UGMEManager::KAPI_SetScene(int32 scene, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->SetScene((ITMG_APP_SCENE)scene);
	else
		UE_LOG(LogC7, Display, TEXT("SetScene Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

//切换场景
int32 UGMEManager::KAPI_SetAudioRole(int32 role, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->SetAudioRole((ITMG_AUDIO_MEMBER_ROLE)role);
	else
		UE_LOG(LogC7, Display, TEXT("SetAudioRole Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}


//切换场景
int32 UGMEManager::KAPI_SetAdvanceParams(FString key, FString value, int ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->SetAdvanceParams(TCHAR_TO_UTF8(*key), TCHAR_TO_UTF8(*value));
	else
		UE_LOG(LogC7, Display, TEXT("SetAdvanceParams Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}


// 打开或关闭麦克风
int32 UGMEManager::KAPI_EnableMic(bool Enable, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->EnableMic(Enable);
	else
		UE_LOG(LogC7, Display, TEXT("EnableMic Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}


// 打开或关闭音频采集设备
int32 UGMEManager::KAPI_EnableAudioCaptureDevice(bool Enable, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
    return 0;
#else
    ITMGContext* tmgContext = GetChannelContext(ChannelType);
    if (tmgContext != nullptr)
        return tmgContext->GetAudioCtrl()->EnableAudioCaptureDevice(Enable);
    else
        UE_LOG(LogC7, Display, TEXT("EnableAudioCaptureDevice Failed ChannelType = %d"), ChannelType);
    return 0;
#endif
}

// 获取麦克风是否打开
bool UGMEManager::KAPI_IsAudioCaptureDeviceEnabled(int32 ChannelType = 0)
{
#ifdef DISABLE_GME
    return false;
#else
    ITMGContext* tmgContext = GetChannelContext(ChannelType);
    if (tmgContext != nullptr)
        return tmgContext->GetAudioCtrl()->IsAudioCaptureDeviceEnabled();
    else
        UE_LOG(LogC7, Display, TEXT("IsAudioCaptureDeviceEnabled Failed ChannelType = %d"), ChannelType);
    return false;
#endif
}


// 启用或禁用音频发送
int32 UGMEManager::KAPI_EnableAudioSend(bool Enable, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
    return 0;
#else
    ITMGContext* tmgContext = GetChannelContext(ChannelType);
    if (tmgContext != nullptr)
        return tmgContext->GetAudioCtrl()->EnableAudioSend(Enable);
    else
        UE_LOG(LogC7, Display, TEXT("EnableAudioSend Failed ChannelType = %d"), ChannelType);
    return 0;
#endif
}

// 获取启用或禁用音频发送状态
bool UGMEManager::KAPI_IsAudioSendEnabled(int32 ChannelType = 0)
{
#ifdef DISABLE_GME
    return false;
#else
    ITMGContext* tmgContext = GetChannelContext(ChannelType);
    if (tmgContext != nullptr)
        return tmgContext->GetAudioCtrl()->IsAudioSendEnabled();
    else
        UE_LOG(LogC7, Display, TEXT("IsAudioSendEnabled Failed ChannelType = %d"), ChannelType);
    return false;
#endif
}


// 获取麦克风状态
int32 UGMEManager::KAPI_GetMicState(int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->GetMicState();
	else
		UE_LOG(LogC7, Display, TEXT("GetMicState Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

// 打开或关闭扬声器
int32 UGMEManager::KAPI_EnableSpeaker(bool Enable, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->EnableSpeaker(Enable);
	else
		UE_LOG(LogC7, Display, TEXT("EnableSpeaker Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

// 设置声音类型
int32 UGMEManager::KAPI_SetVoiceType(int32 VoiceType, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioEffectCtrl()->SetVoiceType((ITMG_VOICE_TYPE)VoiceType);
	else
		UE_LOG(LogC7, Display, TEXT("SetVoiceType Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

// 开始录音
int32 UGMEManager::KAPI_StartRecording(FString filePath)
{
#ifdef DISABLE_GME
	return 0;
#else
	const FString FullPath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForWrite(*filePath);
	return ITMGContextGetInstance()->GetPTT()->StartRecording(TCHAR_TO_UTF8(*FullPath));
#endif
}

// 开始录音转文字
int32 UGMEManager::KAPI_StartRecordingWithStreamingRecognition(FString filePath)
{
#ifdef DISABLE_GME
	return 0;
#else
	const FString FullPath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForWrite(*filePath);
	return ITMGContextGetInstance()->GetPTT()->StartRecordingWithStreamingRecognition(TCHAR_TO_UTF8(*FullPath));
#endif
}

//停止录音
int32 UGMEManager::KAPI_StopRecording()
{
#ifdef DISABLE_GME
	return 0;
#else
	return ITMGContextGetInstance()->GetPTT()->StopRecording();
#endif
}

//取消录音
int32 UGMEManager::KAPI_CancelRecording()
{
#ifdef DISABLE_GME
	return 0;
#else
	return ITMGContextGetInstance()->GetPTT()->CancelRecording();
#endif
}

//上传录音文件
int32 UGMEManager::KAPI_UploadRecordedFile(FString filePath)
{
#ifdef DISABLE_GME
	return 0;
#else
	const FString FullPath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForWrite(*filePath);
	return ITMGContextGetInstance()->GetPTT()->UploadRecordedFile(TCHAR_TO_UTF8(*FullPath));
#endif
}

//下载录音文件
int32 UGMEManager::KAPI_DownloadRecordedFile(FString fileId, FString filePath)
{
#ifdef DISABLE_GME
	return 0;
#else
	const FString FullPath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForWrite(*filePath);
	return ITMGContextGetInstance()->GetPTT()->DownloadRecordedFile(TCHAR_TO_UTF8(*fileId), TCHAR_TO_UTF8(*FullPath));
#endif
}

//播放录音文件
int32 UGMEManager::KAPI_PlayRecordedFile(FString filePath)
{
#ifdef DISABLE_GME
	return 0;
#else
	const FString FullPath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForWrite(*filePath);
	return ITMGContextGetInstance()->GetPTT()->PlayRecordedFile(TCHAR_TO_UTF8(*FullPath));
#endif
}

//停止播放录音文件
int32 UGMEManager::KAPI_StopPlayFile()
{
#ifdef DISABLE_GME
	return 0;
#else
	return ITMGContextGetInstance()->GetPTT()->StopPlayFile();
#endif
}

//获取录音文件长度
int32 UGMEManager::KAPI_GetVoiceFileDuration(FString filePath)
{
#ifdef DISABLE_GME
	return 0;
#else
	const FString FullPath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForWrite(*filePath);
	return ITMGContextGetInstance()->GetPTT()->GetVoiceFileDuration(TCHAR_TO_UTF8(*FullPath));
#endif
}

//设置录音长度
int32 UGMEManager::KAPI_SetMaxMessageLength(int32 msTime)
{
#ifdef DISABLE_GME
	return 0;
#else
	return ITMGContextGetInstance()->GetPTT()->SetMaxMessageLength(msTime);
#endif
}

//获取speaker level 大小
int32 UGMEManager::KAPI_GetSpeakerLevel(int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->GetSpeakerLevel();
	else
		UE_LOG(LogC7, Display, TEXT("GetSpeakerLevel Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

//设置speaker volume 大小
int32 UGMEManager::KAPI_SetSpeakerVolume(int32 SpeakerVolumne, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->SetSpeakerVolume(SpeakerVolumne);
	else
		UE_LOG(LogC7, Display, TEXT("SetSpeakerVolume Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

//获取speaker volume 大小
int32 UGMEManager::KAPI_GetSpeakerVolume(int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->GetSpeakerVolume();
	else
		UE_LOG(LogC7, Display, TEXT("GetSpeakerVolume Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

//获取mic level 大小
int32 UGMEManager::KAPI_GetMicLevel(int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->GetMicLevel();
	else
		UE_LOG(LogC7, Display, TEXT("GetMicLevel Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

//获取mic volume 大小
int32 UGMEManager::KAPI_GetMicVolume(int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->GetMicVolume();
	else
		UE_LOG(LogC7, Display, TEXT("GetMicVolume Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

//设置speaker volume 大小
int32 UGMEManager::KAPI_SetMicVolume(int32 micVolumne, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->SetMicVolume(micVolumne);
	else
		UE_LOG(LogC7, Display, TEXT("SetMicVolume Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

//设置speaker volume 大小
int32 UGMEManager::KAPI_AddAudioBlackList(FString OpenID, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->AddAudioBlackList(TCHAR_TO_UTF8(*OpenID));
	else
		UE_LOG(LogC7, Display, TEXT("AddAudioBlackList Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

int32 UGMEManager::KAPI_RemoveAudioBlackList(FString OpenID, int32 ChannelType = 0)
{
#ifdef DISABLE_GME
	return 0;
#else
	ITMGContext* tmgContext = GetChannelContext(ChannelType);
	if (tmgContext != nullptr)
		return tmgContext->GetAudioCtrl()->RemoveAudioBlackList(TCHAR_TO_UTF8(*OpenID));
	else
		UE_LOG(LogC7, Display, TEXT("RemoveAudioBlackList Failed ChannelType = %d"), ChannelType);
	return 0;
#endif
}

#ifdef DISABLE_GME
	
#else
ITMGContext* UGMEManager::GetChannelContext(int32 ChannelType)
{
	if (ChannelType == 0)
		return ITMGContextGetInstance();

	if (ITMGContextMap.Contains(ChannelType))
		return ITMGContextMap[ChannelType];
	else
		return nullptr;
}

ITMGContext* UGMEManager::GetOrCreatChannelContext(int32 ChannelType,const FString& InUserSig)
{
	if (ChannelType == 0)
		return ITMGContextGetInstance();
	else
		CreateChannelContext(ChannelType, InUserSig);
	if (ITMGContextMap.Contains(ChannelType))
		return ITMGContextMap[ChannelType];
	else
		return nullptr;
}


// 生成鉴权buffer
int32 UGMEManager::GenerateAuthBuffer(const FString& InUserSig, FString InRoomID, unsigned char* OutBuffer, int32& OutBufferLen)
{
	if (InUserSig.IsEmpty() || InUserSig.Len() == 0)
	{
		// 使用本地生成
		int32 nAppid = FCString::Atoi(*AppId);
		if (InRoomID.IsEmpty())
		{
			OutBufferLen = QAVSDK_AuthBuffer_GenAuthBuffer(nAppid, NULL, TCHAR_TO_UTF8(*UserId), TCHAR_TO_UTF8(*AppKey), OutBuffer, OutBufferLen);
		}
		else
		{
			OutBufferLen = QAVSDK_AuthBuffer_GenAuthBuffer(nAppid,  TCHAR_TO_UTF8(*InRoomID), TCHAR_TO_UTF8(*UserId), TCHAR_TO_UTF8(*AppKey), OutBuffer, OutBufferLen);
		}
		return OutBufferLen;
	}
	else
	{
		// 使用外部输入
		OutBufferLen = InUserSig.Len();
		FMemory::Memcpy(OutBuffer, TCHAR_TO_UTF8(*InUserSig), OutBufferLen);
		return OutBufferLen;
	}
}

// 应用鉴权buffer到PTT
uint32 UGMEManager::ApplyAuthBuffer(ITMGContext* Context, const FString& InUserSig, const FString& InRoomID, const FString& LogPrefix)
{
	if (Context == nullptr)
	{
		UE_LOG(LogC7, Warning, TEXT("%s ApplyAuthBuffer failed: Context is null"), *LogPrefix);
		return 0;
	}

	unsigned char authBuffer[1024] = { 0 };
	int32 bufferLen = 1024;
	GenerateAuthBuffer(InUserSig, InRoomID, authBuffer, bufferLen);
	
	uint32 authRet = Context->GetPTT()->ApplyPTTAuthbuffer((const char*)authBuffer, bufferLen);
	
	if (InUserSig.IsEmpty() || InUserSig.Len() == 0)
	{
		UE_LOG(LogC7, Display, TEXT("%s ApplyPTTAuthbuffer with generated sig retcode = %d userSigLen = %d"), *LogPrefix, authRet, bufferLen);
	}
	else
	{
		UE_LOG(LogC7, Display, TEXT("%s ApplyPTTAuthbuffer with InUserSig retcode = %d userSigLen = %d"), *LogPrefix, authRet, bufferLen);
	}
	
	return authRet;
}
#endif	



int32 UGMEManager::CreateChannelContext(int32 ChannelType, const FString& InUserSig)
{
#ifdef DISABLE_GME
	return 0;
#else
	if (ITMGContextMap.Contains(ChannelType))
		return 0;
	ITMGContext* newTMGContext = nullptr;
	if (ChannelType != 0)
		newTMGContext = ITMGContextGetInstance()->CreateSubInstance();

	newTMGContext->SetAdvanceParams("StringOpenID", "1");
	int32 ret = newTMGContext->Init(TCHAR_TO_UTF8(*AppId), TCHAR_TO_UTF8(*UserId));
	UE_LOG(LogC7, Display, TEXT("Channel %d InitGME retcode = %d"), ChannelType, ret);

	TSharedPtr<ITMGDelegate> newTMGDelegate = MakeShareable(new GMEDelegate(ChannelType, this));
	newTMGContext->SetTMGDelegate(newTMGDelegate.Get());
	ITMGDelegateMap.Add(ChannelType, newTMGDelegate);
	
	int32 RetCode = (int32)newTMGContext->CheckMicPermission();
	UE_LOG(LogC7, Display, TEXT("Check Mic Permission retcode = %d"), RetCode);

	FString logPrefix = FString::Printf(TEXT("Channel %d"), ChannelType);
	ApplyAuthBuffer(newTMGContext, InUserSig, TEXT(""), logPrefix);
	ITMGContextMap.Add(ChannelType, newTMGContext);
	return 1;
#endif	
}



int32 UGMEManager::KAPI_CreateChannelContext(int32 ChannelType,const FString& InUserSig)
{
#ifdef DISABLE_GME
	return 0;
#else
	if (ITMGContextMap.Contains(ChannelType))
		return 0;
	ITMGContext* newTMGContext = nullptr;
	if (ChannelType != 0)
		newTMGContext = ITMGContextGetInstance()->CreateSubInstance();

	newTMGContext->SetAdvanceParams("StringOpenID", "1");
	int32 ret = newTMGContext->Init(TCHAR_TO_UTF8(*AppId), TCHAR_TO_UTF8(*UserId));
	UE_LOG(LogC7, Display, TEXT("InitGME retcode = %d"), ret);

	TSharedPtr<ITMGDelegate> newTMGDelegate = MakeShareable(new GMEDelegate(ChannelType, this));
	newTMGContext->SetTMGDelegate(newTMGDelegate.Get());
	ITMGDelegateMap.Add(ChannelType, newTMGDelegate);

	int32 RetCode = (int32)newTMGContext->CheckMicPermission();
	UE_LOG(LogC7, Display, TEXT("Check Mic Permission retcode = %d"), RetCode);

	ApplyAuthBuffer(newTMGContext, InUserSig, TEXT(""), TEXT(""));
	ITMGContextMap.Add(ChannelType, newTMGContext);
	return 1;
#endif	
}
 

void UGMEManager::KAPI_DestroyChannelContext(int32 ChannelType)
{
#ifdef DISABLE_GME
	return;
#else
	if (!ITMGContextMap.Contains(ChannelType))
		return;
	if (ChannelType != 0) {
		ITMGContextMap[ChannelType]->Uninit();
		ITMGContextGetInstance()->DestroySubInstance(ITMGContextMap[ChannelType]);
		ITMGContextMap.Remove(ChannelType);
		ITMGDelegateMap.Remove(ChannelType);
		UE_LOG(LogC7, Display, TEXT("DestroyChannelContext ChannelType = %d"), ChannelType);
	}
#endif	
}

void UGMEManager::KAPI_PauseContext(int32 ChannelType)
{
#ifdef DISABLE_GME
	return;
#else
	if (!ITMGContextMap.Contains(ChannelType))
		return;
	if (ChannelType != 0) {
		ITMGContextMap[ChannelType]->Pause();
	}
#endif	
}

void UGMEManager::KAPI_ResumeContext(int32 ChannelType)
{
#ifdef DISABLE_GME
	return;
#else
	if (!ITMGContextMap.Contains(ChannelType))
		return;
	if (ChannelType != 0) {
		ITMGContextMap[ChannelType]->Resume();
	}
#endif	
}



//回调
void UGMEManager::OnEnterRoomCompleted(int32 result, const FString& errInfo, int32 channelType)
{
	CallLuaFunction(TEXT("KCB_OnEnterRoomCompleted"), result, errInfo, channelType);
}

void UGMEManager::OnExitRoomCompleted(int32 result, const FString& errInfo, int32 channelType)
{
	CallLuaFunction(TEXT("KCB_OnExitRoomCompleted"), result, errInfo, channelType);
}

void UGMEManager::OnEndpointsUpdateInfo(int32 eventID, const FString& identifier, int32 channelType)
{
	CallLuaFunction(TEXT("KCB_OnEndpointsUpdateInfo"), eventID, identifier, channelType);
}

void UGMEManager::OnPttRecordFileCompleted(int32 result, const FString& filePath, int32 duration, int32 filesize)
{
	CallLuaFunction(TEXT("KCB_OnPttRecordFileCompleted"), result, filePath, duration, filesize);
}

void UGMEManager::OnPttPlayFileCompleted(int32 result, const FString& filePath)
{
	CallLuaFunction(TEXT("KCB_OnPttPlayFileCompleted"), result, filePath);
}

void UGMEManager::OnPttUploadFileCompleted(int32 result, const FString& filePath, const FString& fileID)
{
	CallLuaFunction(TEXT("KCB_OnPttUploadFileCompleted"), result, filePath, fileID);
}

void UGMEManager::OnPttDownloadFileCompleted(int32 result, const FString& filePath, const FString& fileID)
{
	CallLuaFunction(TEXT("KCB_OnPttDownloadFileCompleted"), result, filePath, fileID);
}

void UGMEManager::OnPttSpeech2TextCompleted(int32 result, const FString& fileID, const FString& text)
{
	CallLuaFunction(TEXT("KCB_OnPttSpeech2TextCompleted"), result, fileID, text);
}

void UGMEManager::OnPttStreamRecognitionCompleted(int32 result, const FString& filePath, const FString& fileID, const FString& text)
{
	CallLuaFunction(TEXT("KCB_OnPttStreamRecognitionCompleted"), result, filePath, fileID, text);
}

void UGMEManager::OnPttStreamRecognitionisRunning(int32 result, const FString& filePath, const FString& fileID, const FString& text)
{
	CallLuaFunction(TEXT("KCB_OnPttStreamRecognitionisRunning"), result, filePath, fileID, text);
}
