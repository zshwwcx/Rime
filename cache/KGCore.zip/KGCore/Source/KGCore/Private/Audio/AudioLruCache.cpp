#include "Audio/AudioLruCache.h"


bool FAudioLruCache::Update(const FString& Key)
{
	if (ListItr** NodePtr = Map.Find(Key))
	{
		ListItr* Node = *NodePtr;
		MoveToFront(Node);
		return true;
	}
	return false;
}

FString FAudioLruCache::Add(const FString& Key, double Value)
{
	// Update existing key
	FString LruKey;
	if (ListItr** NodePtr = Map.Find(Key))
	{
		ListItr* Node = *NodePtr;
		MoveToFront(Node);
		return LruKey;
	}
    
	// Remove LRU if cache is full
	CurrentSize += Value;
	if (CurrentSize >= Capacity)
	{
		LruKey = RemoveLru();
	}
    
	// Add new item
	NodePtr NewNode = MakeShared<CacheNode>(Key, Value);
	List.AddHead(NewNode);
	ListItr* NewListItr = List.GetHead();
	Map.Add(Key, NewListItr);

	return LruKey;
}

bool FAudioLruCache::Contains(const FString& Key) const
{
	return Map.Contains(Key);
}

bool FAudioLruCache::Remove(const FString& Key)
{
	if (ListItr** NodePtr = Map.Find(Key))
	{
		ListItr* Node = *NodePtr;
		List.RemoveNode(Node, false);
		Map.Remove(Key);
		return true;
	}
	return false;
}

double FAudioLruCache::Size() const
{
	return CurrentSize;
}

void FAudioLruCache::Clear()
{
	CurrentSize = 0.f;
	List.Empty();
	Map.Reset();
}

void FAudioLruCache::GetAllKeys(TArray<FString>& OutKeys) const
{
	for (auto& It : Map)
	{
		OutKeys.Add(It.Key);
	}
}

void FAudioLruCache::MoveToFront(ListItr* Node)
{
	List.RemoveNode(Node, false);
	List.AddHead(Node);
}

FString FAudioLruCache::RemoveLru()
{
	FString LruKey;
	if (List.GetTail())
	{
		LruKey = List.GetTail()->GetValue()->Key;
		double LruValue = List.GetTail()->GetValue()->Value;
		CurrentSize -= LruValue;
		List.RemoveNode(List.GetTail(), false);
		Map.Remove(LruKey);
	}
	return LruKey;
}
