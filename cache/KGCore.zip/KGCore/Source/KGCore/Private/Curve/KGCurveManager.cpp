#include "Curve/KGCurveManager.h"

#include "lua.hpp"
#include "LuaState.h"
#include "Engine/CurveTable.h"
#include "Engine/World.h"


#pragma region Important
UKGCurveManager* UKGCurveManager::GetInstance(UObject* InContext)
{
	//return UKGBasicManager::GetManager<UKGCurveManager>(InContext);
	return Cast<UKGCurveManager>(GetManagerByType(InContext, EManagerType::EMT_CurveManager));
}

void UKGCurveManager::NativeInit()
{
	FWorldDelegates::OnWorldCleanup.AddUObject(this, &UKGCurveManager::OnWorldCleanupEnd);

	Super::NativeInit();
}

void UKGCurveManager::NativeUninit()
{
	CleanCurves();

	FWorldDelegates::OnWorldCleanup.RemoveAll(this);

	Super::NativeUninit();
}

void UKGCurveManager::OnWorldCleanupEnd(UWorld* World, bool bSessionEnded, bool bCleanupResources)
{
	CleanCurves();
}

#pragma endregion Important



#pragma region Curve
bool UKGCurveManager::HasFloatCurve(int64 InID)
{
	return FloatSearchMap.Contains(InID);
}

void UKGCurveManager::GetFloatCurve(FKGRemapFloatCurve& OutCurve, int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& Keys)
{
	OutCurve.bNeedRemap = false;
	OutCurve.Curve.ExternalCurve = nullptr;
	OutCurve.Curve.EditorCurveData.Reset();
	
	int64 GID = AddNewFloatCurve(InID, NeedRemap, ForceRefresh, Keys);

	if (FKGRemapFloatCurve* Result = FloatSearchMap.Find(GID))
	{
		OutCurve = *Result;
	}
}

void UKGCurveManager::GetVectorCurve(FKGRemapVectorCurve& OutCurve, int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys)
{
	OutCurve.bNeedRemap = false;
	OutCurve.Curve.ExternalCurve = nullptr;
	OutCurve.Curve.VectorCurves[0].Reset();
	OutCurve.Curve.VectorCurves[1].Reset();
	OutCurve.Curve.VectorCurves[2].Reset();
	
	int64 GID = AddNewVectorCurve(InID, NeedRemap, ForceRefresh, XKeys, YKeys, ZKeys);

	if (FKGRemapVectorCurve* Result = VectorSearchMap.Find(GID))
	{
		OutCurve = *Result;
	}
}

void UKGCurveManager::GetColorCurve(FKGRemapColorCurve& OutCurve, int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys, TArray<FRichCurveKey>& WKeys)
{
	OutCurve.bNeedRemap = false;
	OutCurve.Curve.ExternalCurve = nullptr;
	OutCurve.Curve.ColorCurves[0].Reset();
	OutCurve.Curve.ColorCurves[1].Reset();
	OutCurve.Curve.ColorCurves[2].Reset();
	OutCurve.Curve.ColorCurves[3].Reset();

	int64 GID = AddNewColorCurve(InID, NeedRemap, ForceRefresh, XKeys, YKeys, ZKeys, WKeys);

	if (FKGRemapColorCurve* Result = ColorSearchMap.Find(GID))
	{
		OutCurve = *Result;
	}
}

UCurveFloat* UKGCurveManager::GetFloatCurveObject(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& Keys)
{
	int64 GID = AddNewFloatCurve(InID, NeedRemap, ForceRefresh, Keys, true);

	if (UCurveFloat** Result = FloatObjectSearchMap.Find(GID))
	{
		return *Result;
	}

	return nullptr;
}

UCurveVector* UKGCurveManager::GetVectorCurveObject(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys)
{
	int64 GID = AddNewVectorCurve(InID, NeedRemap, ForceRefresh, XKeys, YKeys, ZKeys, true);

	if (UCurveVector** Result = VectorObjectSearchMap.Find(GID))
	{
		return *Result;
	}

	return nullptr;
}

UCurveLinearColor* UKGCurveManager::GetColorCurveObject(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys, TArray<FRichCurveKey>& WKeys)
{
	int64 GID = AddNewColorCurve(InID, NeedRemap, ForceRefresh, XKeys, YKeys, ZKeys, WKeys, true);

	if (UCurveLinearColor** Result = ColorObjectSearchMap.Find(GID))
	{
		return *Result;
	}

	return nullptr;
}

void UKGCurveManager::GenerateRichCurve(FRichCurve& RichCurve,  TArray<FRichCurveKey>& Keys)
{
	RichCurve.Reset();
	FRichCurve* TemporaryCurve = &RichCurve;

	for(int Index = 0; Index < Keys.Num(); ++Index)
	{
		if (!TemporaryCurve->Keys.IsValidIndex(Index))
		{
			TemporaryCurve->Keys.SetNum(Index + 1);
		}

		FRichCurveKey& CurveKey = TemporaryCurve->Keys[Index];
		
		CurveKey.ArriveTangent = Keys[Index].ArriveTangent;
		CurveKey.ArriveTangentWeight = Keys[Index].ArriveTangentWeight;
		CurveKey.InterpMode = Keys[Index].InterpMode;
		CurveKey.LeaveTangent = Keys[Index].LeaveTangent;
		CurveKey.LeaveTangentWeight = Keys[Index].LeaveTangentWeight;
		CurveKey.TangentMode = Keys[Index].TangentMode;
		CurveKey.TangentWeightMode = Keys[Index].TangentWeightMode;
		CurveKey.Time = Keys[Index].Time;
		CurveKey.Value = Keys[Index].Value;
	}
}

int64 UKGCurveManager::AddNewColorCurve(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys, TArray<FRichCurveKey>& WKeys, bool InNeedObject)
{
	if (!ForceRefresh)
	{
		if (InvalidCurveGIDs.Contains(InID))
		{
			UE_LOG(LogTemp, Warning, TEXT("[CurveLOG] AddNewColorCurve Error !!!"));

			return 0;
		}
		
		if (ColorSearchMap.Contains(InID))
		{
			if (InNeedObject && !ColorObjectSearchMap.Contains(InID))
			{
				AddNewCurveObject(InID);
			}
			return InID;
		}
	}

	GenerateRichCurve(XTemporaryCurve, XKeys);
	GenerateRichCurve(YTemporaryCurve, YKeys);
	GenerateRichCurve(ZTemporaryCurve, ZKeys);
	GenerateRichCurve(WTemporaryCurve, WKeys);
	
	if (XTemporaryCurve.GetNumKeys() <= 0 && YTemporaryCurve.GetNumKeys() <= 0 && ZTemporaryCurve.GetNumKeys() <= 0 && WTemporaryCurve.GetNumKeys() <= 0)
	{
		InvalidCurveGIDs.Add(InID);
		return 0;
	}

	FKGRemapColorCurve NewCurve;
	NewCurve.Curve.ColorCurves[0].SetKeys(XTemporaryCurve.Keys);
	NewCurve.Curve.ColorCurves[1].SetKeys(YTemporaryCurve.Keys);
	NewCurve.Curve.ColorCurves[2].SetKeys(ZTemporaryCurve.Keys);
	NewCurve.Curve.ColorCurves[3].SetKeys(WTemporaryCurve.Keys);
	NewCurve.bNeedRemap = NeedRemap;

	ColorSearchMap.Add(InID, NewCurve);


	if (InNeedObject)
	{
		AddNewCurveObject(InID);
	}
	
	return InID;
}

int64 UKGCurveManager::AddNewVectorCurve(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, TArray<FRichCurveKey>& YKeys, TArray<FRichCurveKey>& ZKeys, bool InNeedObject)
{
	if (!ForceRefresh)
	{
		if (InvalidCurveGIDs.Contains(InID))
		{
			UE_LOG(LogTemp, Warning, TEXT("[CurveLOG] AddNewColorCurve Error !!!"));

			return 0;
		}
		
		if (VectorSearchMap.Contains(InID))
		{
			if (InNeedObject && !VectorObjectSearchMap.Contains(InID))
			{
				AddNewCurveObject(InID);
			}
			return InID;
		}
	}

	GenerateRichCurve(XTemporaryCurve, XKeys);
	GenerateRichCurve(YTemporaryCurve, YKeys);
	GenerateRichCurve(ZTemporaryCurve, ZKeys);
	
	if (XTemporaryCurve.GetNumKeys() <= 0 && YTemporaryCurve.GetNumKeys() <= 0 && ZTemporaryCurve.GetNumKeys() <= 0 && WTemporaryCurve.GetNumKeys() <= 0)
	{
		InvalidCurveGIDs.Add(InID);
		return 0;
	}

	FKGRemapVectorCurve NewCurve;
	NewCurve.Curve.GetRichCurve(0)->SetKeys(XTemporaryCurve.Keys);
	NewCurve.Curve.GetRichCurve(1)->SetKeys(YTemporaryCurve.Keys);
	NewCurve.Curve.GetRichCurve(2)->SetKeys(ZTemporaryCurve.Keys);
	NewCurve.bNeedRemap = NeedRemap;

	VectorSearchMap.Add(InID, NewCurve);


	if (InNeedObject)
	{
		AddNewCurveObject(InID);
	}
	
	return InID;
}

int64 UKGCurveManager::AddNewFloatCurve(int64 InID, bool NeedRemap, bool ForceRefresh, TArray<FRichCurveKey>& XKeys, bool InNeedObject)
{
	if (!ForceRefresh)
	{
		if (InvalidCurveGIDs.Contains(InID))
		{
			UE_LOG(LogTemp, Warning, TEXT("[CurveLOG] AddNewColorCurve Error !!!"));

			return 0;
		}
		
		if (FloatSearchMap.Contains(InID))
		{
			if (InNeedObject && !FloatObjectSearchMap.Contains(InID))
			{
				AddNewCurveObject(InID);
			}
			return InID;
		}
	}

	GenerateRichCurve(XTemporaryCurve, XKeys);
	
	if (XTemporaryCurve.GetNumKeys() <= 0 && YTemporaryCurve.GetNumKeys() <= 0 && ZTemporaryCurve.GetNumKeys() <= 0 && WTemporaryCurve.GetNumKeys() <= 0)
	{
		InvalidCurveGIDs.Add(InID);
		return 0;
	}

	FKGRemapFloatCurve NewCurve;
	NewCurve.Curve.GetRichCurve()->SetKeys(XTemporaryCurve.Keys);
	NewCurve.bNeedRemap = NeedRemap;

	FloatSearchMap.Add(InID, NewCurve);


	if (InNeedObject)
	{
		AddNewCurveObject(InID);
	}
	
	return InID;
}

void UKGCurveManager::AddNewCurveObject(int64 InID)
{
	if (FKGRemapFloatCurve* FCurve = FloatSearchMap.Find(InID))
	{
		if (UCurveFloat* CurveObj = NewObject<UCurveFloat>(this))
		{
			CurveObj->FloatCurve.SetKeys(FCurve->Curve.EditorCurveData.Keys);
			FloatObjectSearchMap.Add(InID, CurveObj);
		}
	}
	else if (FKGRemapVectorCurve* VCurve = VectorSearchMap.Find(InID))
	{
		if (UCurveVector* CurveObj = NewObject<UCurveVector>(this))
		{
			CurveObj->FloatCurves[0].SetKeys(VCurve->Curve.VectorCurves[0].Keys);
			CurveObj->FloatCurves[1].SetKeys(VCurve->Curve.VectorCurves[1].Keys);
			CurveObj->FloatCurves[2].SetKeys(VCurve->Curve.VectorCurves[2].Keys);
			VectorObjectSearchMap.Add(InID, CurveObj);
		}
	}
	else if (FKGRemapColorCurve* LCurve = ColorSearchMap.Find(InID))
	{
		if (UCurveLinearColor* CurveObj = NewObject<UCurveLinearColor>(this))
		{
			CurveObj->FloatCurves[0].SetKeys(LCurve->Curve.ColorCurves[0].Keys);
			CurveObj->FloatCurves[1].SetKeys(LCurve->Curve.ColorCurves[1].Keys);
			CurveObj->FloatCurves[2].SetKeys(LCurve->Curve.ColorCurves[2].Keys);
			CurveObj->FloatCurves[3].SetKeys(LCurve->Curve.ColorCurves[3].Keys);
			ColorObjectSearchMap.Add(InID, CurveObj);
		}
	}
}

void UKGCurveManager::CleanCurves()
{
	FloatSearchMap.Empty();
	for (TMap<int64, UCurveFloat*>::TIterator It(FloatObjectSearchMap); It; ++It)
	{
		if (IsValid(It->Value) && It->Value->GetOuter() == this)
		{
			It->Value->MarkAsGarbage();
		}
	}
	FloatObjectSearchMap.Empty();

	VectorSearchMap.Empty();
	for (TMap<int64, UCurveVector*>::TIterator It(VectorObjectSearchMap); It; ++It)
	{
		if (IsValid(It->Value) && It->Value->GetOuter() == this)
		{
			It->Value->MarkAsGarbage();
		}
	}
	VectorObjectSearchMap.Empty();

	ColorSearchMap.Empty();
	for (TMap<int64, UCurveLinearColor*>::TIterator It(ColorObjectSearchMap); It; ++It)
	{
		if (IsValid(It->Value) && It->Value->GetOuter() == this)
		{
			It->Value->MarkAsGarbage();
		}
	}
	ColorObjectSearchMap.Empty();

	CurveTableSearchMap.Empty();

	InvalidCurveGIDs.Empty();
}

void UKGCurveManager::GetCurveTimeRange(int64 InID, float& OutMinTime, float& OutMaxTime)
{
	if (FKGRemapFloatCurve* FCurvePtr = FloatSearchMap.Find(InID))
	{
		FCurvePtr->Curve.GetRichCurveConst()->GetTimeRange(OutMinTime, OutMaxTime);
	}
	else if (FKGRemapVectorCurve* VCurvePtr = VectorSearchMap.Find(InID))
	{
		float Min, Max;
		VCurvePtr->Curve.VectorCurves[0].GetTimeRange(OutMinTime, OutMaxTime);
		VCurvePtr->Curve.VectorCurves[1].GetTimeRange(Min, Max);
		OutMinTime = FMath::Min(OutMinTime, Min);
		OutMaxTime = FMath::Max(OutMaxTime, Max);
		VCurvePtr->Curve.VectorCurves[2].GetTimeRange(Min, Max);
		OutMinTime = FMath::Min(OutMinTime, Min);
		OutMaxTime = FMath::Max(OutMaxTime, Max);
	}
	else if (FKGRemapColorCurve* LCurvePtr = ColorSearchMap.Find(InID))
	{
		float Min, Max;
		LCurvePtr->Curve.ColorCurves[0].GetTimeRange(OutMinTime, OutMaxTime);
		LCurvePtr->Curve.ColorCurves[1].GetTimeRange(Min, Max);
		OutMinTime = FMath::Min(OutMinTime, Min);
		OutMaxTime = FMath::Max(OutMaxTime, Max);
		LCurvePtr->Curve.ColorCurves[2].GetTimeRange(Min, Max);
		OutMinTime = FMath::Min(OutMinTime, Min);
		OutMaxTime = FMath::Max(OutMaxTime, Max);
		LCurvePtr->Curve.ColorCurves[3].GetTimeRange(Min, Max);
		OutMinTime = FMath::Min(OutMinTime, Min);
		OutMaxTime = FMath::Max(OutMaxTime, Max);
	}
	else
	{
		OutMinTime = 0.0f;
		OutMaxTime = 0.0f;
	}
}

bool UKGCurveManager::CheckCurveIDByPath(const FString& InPath, int64& OutID)
{
	if (InPath.IsEmpty())
	{
		OutID = 0;
		return false;
	}

	if (int64* Result = PathToCurveID.Find(InPath))
	{
		OutID = *Result;

		if (!FloatObjectSearchMap.Contains(OutID) && !VectorObjectSearchMap.Contains(OutID) && !ColorObjectSearchMap.Contains(OutID))
		{
			return false;
		}

		return true;
	}

	OutID = ULowLevelFunctions::GetGlobalUniqueID();
	PathToCurveID.Add(InPath, OutID);

	return false;
}

void UKGCurveManager::AddCurveObject(UObject* InCurve, int64 InCurveID)
{
	if (UCurveFloat* CFloat = Cast<UCurveFloat>(InCurve))
	{
		FloatObjectSearchMap.Add(InCurveID, CFloat);
	}
	else if (UCurveVector* CVector = Cast<UCurveVector>(InCurve))
	{
		VectorObjectSearchMap.Add(InCurveID, CVector);
	}
	else if (UCurveLinearColor* CColor = Cast<UCurveLinearColor>(InCurve))
	{
		ColorObjectSearchMap.Add(InCurveID, CColor);
	}
	else if (UCurveTable* CTable = Cast<UCurveTable>(InCurve))
	{
		FKGRemapCurveTable NewCurve;
		NewCurve.Curve = CTable;
		CurveTableSearchMap.Add(InCurveID, NewCurve);
	}
}

UCurveFloat* UKGCurveManager::GetFloatCurveObjectByID(int64 InID)
{
	if (UCurveFloat** Curve = FloatObjectSearchMap.Find(InID))
	{
		return *Curve;
	}

	return nullptr;
}

bool UKGCurveManager::HasVectorCurve(int64 InID)
{
	return VectorSearchMap.Contains(InID);
}

float UKGCurveManager::GetFloatCurveValue(int64 InID, float InTime, float InTotalTime)
{
	if (FKGRemapFloatCurve* CurvePtr = FloatSearchMap.Find(InID))
	{
		return CurvePtr->GetFloatValue(InTime, InTotalTime);
	}
	else if (UCurveFloat** CurveObj = FloatObjectSearchMap.Find(InID))
	{
		return (*CurveObj)->GetFloatValue(InTime);
	}

	return 0.0f;
}

UCurveVector* UKGCurveManager::GetVectorCurveObjectByID(int64 InID)
{
	if (UCurveVector** Curve = VectorObjectSearchMap.Find(InID))
	{
		return *Curve;
	}

	return nullptr;
}

void UKGCurveManager::GetVectorCurveValue(int64 InID, float InTime, float InTotalTime, float& OX, float& OY, float& OZ)
{
	FVector Result = GetVectorCurveValue(InID, InTime, InTotalTime);

	OX = Result.X;
	OY = Result.Y;
	OZ = Result.Z;
}

FVector UKGCurveManager::GetVectorCurveValue(int64 InID, float InTime, float InTotalTime)
{
	if (FKGRemapVectorCurve* CurvePtr = VectorSearchMap.Find(InID))
	{
		return CurvePtr->GetVectorValue(InTime, InTotalTime);
	}
	else if (UCurveVector** CurveObj = VectorObjectSearchMap.Find(InID))
	{
		return (*CurveObj)->GetVectorValue(InTime);
	}

	return FVector::ZeroVector;
}

UCurveLinearColor* UKGCurveManager::GetColorCurveObjectByID(int64 InID)
{
	if (UCurveLinearColor** Curve = ColorObjectSearchMap.Find(InID))
	{
		return *Curve;
	}

	return nullptr;
}

UCurveTable* UKGCurveManager::GetCurveTableObjectByID(int64 InID)
{
	if (FKGRemapCurveTable* Curve = CurveTableSearchMap.Find(InID))
	{
		return Curve->Curve;
	}

	return nullptr;
}

UObject* UKGCurveManager::GetCurveObjectByID(int64 InID)
{
	if (UObject* FCurve = GetFloatCurveObjectByID(InID))
	{
		return FCurve;
	}

	if (UObject* VCurve = GetVectorCurveObjectByID(InID))
	{
		return VCurve;
	}

	if (UObject* CCurve = GetColorCurveObjectByID(InID))
	{
		return CCurve;
	}

	if (UObject* TCurve = GetCurveTableObjectByID(InID))
	{
		return TCurve;
	}

	return nullptr;
}

void UKGCurveManager::GetColorCurveValue(int64 InID, float InTime, float InTotalTime, float& OR, float& OG, float& OB, float& OA)
{
	FLinearColor Result = GetColorCurveValue(InID, InTime, InTotalTime);

	OR = Result.R;
	OG = Result.G;
	OB = Result.B;
	OA = Result.A;
}

FLinearColor UKGCurveManager::GetColorCurveValue(int64 InID, float InTime, float InTotalTime)
{
	if (FKGRemapColorCurve* CurvePtr = ColorSearchMap.Find(InID))
	{
		return CurvePtr->GetLinearColorValue(InTime, InTotalTime);
	}
	else if (UCurveLinearColor** CurveObj = ColorObjectSearchMap.Find(InID))
	{
		return (*CurveObj)->GetLinearColorValue(InTime);
	}

	return FLinearColor::Black;
}

TMap<FName, float>& UKGCurveManager::GetCurveTableRowValueList(int64 InID, float InTime)
{
	if (FKGRemapCurveTable* CurvePtr = CurveTableSearchMap.Find(InID))
	{
		return CurvePtr->GetCurveTableRowValueList(InTime);
	}

	return EmptyCurveTableData;
}

#pragma endregion Curve
