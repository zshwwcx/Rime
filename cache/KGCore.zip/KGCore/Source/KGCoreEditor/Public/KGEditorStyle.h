#pragma once

#include "CoreMinimal.h"
#include "Styling/SlateStyle.h"

/**  */
class KGCOREEDITOR_API FKGEditorStyle
{
public:

	static void Initialize();

	static void Shutdown();

	/** reloads textures used by slate renderer */
	static void ReloadTextures();

	/** @return The Slate style set for the Shooter game */
	static const ISlateStyle* Get();

	static FName GetStyleSetName();

	/* Returns the given Brush according to the passed in BrushName. Returns nullptr if not found. */
	static const FSlateBrush* GetBrush(FName BrushName);

private:

	static TSharedRef< class FSlateStyleSet > Create();

private:

	static TSharedPtr< class FSlateStyleSet > StyleInstance;
};