// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"

DECLARE_LOG_CATEGORY_EXTERN(LogKGCoreEditor, Log, All);

class FKGCoreEditorModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	// Actor前置处理
	TSharedPtr<class FActorsPlacedHook> ActorsPlacedHook;

private:
    class UEditorLuaEnv *LuaEnv; 
};
