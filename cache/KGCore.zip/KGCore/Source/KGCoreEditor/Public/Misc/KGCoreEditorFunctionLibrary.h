#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Serialization/JsonSerializer.h"
#include "GameplayTagContainer.h"

#include "KGCoreEditorFunctionLibrary.generated.h"



UCLASS(Blueprintable)
class KGCOREEDITOR_API UKGCoreEditorFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

#pragma region Json
public:
	static void ExportStructToJson(void* DataAddress, UScriptStruct* TheStruct, TSharedPtr<FJsonObject> OutJson);
	
	static void ExportObjectToJson(UObject* TheObject, TSharedPtr<FJsonObject> OutJson);
	
	static TSharedPtr<FJsonValue> ExportPropertyToJson(void* DataAddress, FProperty* Prop);

#pragma endregion Json

#pragma region Reflection

	template<typename T>
	static bool GetPropertyValue(const FName& PropertyName, UObject* TargetObject, T& OutValue);

	template<typename T>
	static bool SetPropertyValue(const FName& PropertyName, UObject* TargetObject, const T& NewValue);
	
	template<typename T, typename Predicate>
	static bool GetPropertyValueByPredicate(Predicate Pred, UObject* TargetObject, T& OutValue);
	
	template<typename T, typename Predicate>
	static bool SetPropertyValueByPredicate(Predicate Pred, UObject* TargetObject, const T& NewValue);

private:
	template<typename T, typename Predicate>
	static bool GetNestedStructValue(void* StructContainer, UStruct* StructType, Predicate Pred, T& OutValue);

	template<typename T, typename Predicate>
	static bool SetNestedStructValue(void* StructContainer, UStruct* StructType, Predicate Pred, const T& NewValue);
	
#pragma endregion Reflection
};

template<typename T>
bool UKGCoreEditorFunctionLibrary::GetPropertyValue(const FName& PropertyName, UObject* TargetObject, T& OutValue)
{
	return GetPropertyValueByPredicate<T>(
		[&PropertyName](const FString& PropName) { return PropName == PropertyName.ToString(); },
		TargetObject, OutValue);
}

template <typename T>
bool UKGCoreEditorFunctionLibrary::SetPropertyValue(const FName& PropertyName, UObject* TargetObject, const T& NewValue)
{
	return SetPropertyValueByPredicate<T>(
		[&PropertyName](const FString& PropName) { return PropName == PropertyName.ToString(); },
		TargetObject, NewValue);
}

template <typename T, typename Predicate>
bool UKGCoreEditorFunctionLibrary::GetPropertyValueByPredicate(Predicate Pred, UObject* TargetObject, T& OutValue)
{
	if (!TargetObject) return false;

	bool bFoundProperty = false;
	// 遍历对象的所有属性
	for (TFieldIterator<FProperty> It(TargetObject->GetClass()); It; ++It)
	{
		FProperty* Property = *It;
        
		// 直接匹配属性名称
		if (Pred(Property->GetAuthoredName()))
		{
			void* PropertyPtr = Property->ContainerPtrToValuePtr<void>(TargetObject);
			Property->CopyCompleteValue(static_cast<void*>(&OutValue), PropertyPtr);
			bFoundProperty = true;
		}

		// 处理嵌套对象
		if (FObjectProperty* ObjectProperty = CastField<FObjectProperty>(Property))
		{
			if (UObject* SubObject = ObjectProperty->GetObjectPropertyValue(Property->ContainerPtrToValuePtr<void>(TargetObject)))
			{
				if (GetPropertyValueByPredicate(Pred, SubObject, OutValue))
				{
					bFoundProperty = true;
				}
			}
		}
		// 处理结构体
		else if (FStructProperty* StructProperty = CastField<FStructProperty>(Property))
		{
			void* StructPtr = StructProperty->ContainerPtrToValuePtr<void>(TargetObject);
			if (GetNestedStructValue(StructPtr, StructProperty->Struct, Pred, OutValue))
			{
				bFoundProperty = true;
			}
		}
		// todo 处理容器
	}

	return bFoundProperty;
}

template <typename T, typename Predicate>
bool UKGCoreEditorFunctionLibrary::SetPropertyValueByPredicate(Predicate Pred, UObject* TargetObject, const T& NewValue)
{
	if (!TargetObject) return false;

	// 遍历对象的所有属性
	for (TFieldIterator<FProperty> It(TargetObject->GetClass()); It; ++It)
	{
		FProperty* Property = *It;
        
		// 直接匹配属性名称
		if (Pred(Property->GetAuthoredName()))
		{
			void* PropertyPtr = Property->ContainerPtrToValuePtr<void>(TargetObject);
			Property->CopyCompleteValue(PropertyPtr, static_cast<const void*>(&NewValue));
			return true;
		}

		// 处理嵌套对象
		if (FObjectProperty* ObjectProperty = CastField<FObjectProperty>(Property))
		{
			if (UObject* SubObject = ObjectProperty->GetObjectPropertyValue(Property->ContainerPtrToValuePtr<void>(TargetObject)))
			{
				if (SetPropertyValueByPredicate(Pred, SubObject, NewValue))
				{
					return true;
				}
			}
		}
		// 处理结构体
		else if (FStructProperty* StructProperty = CastField<FStructProperty>(Property))
		{
			void* StructPtr = StructProperty->ContainerPtrToValuePtr<void>(TargetObject);
			if (SetNestedStructValue(StructPtr, StructProperty->Struct, Pred, NewValue))
			{
				return true;
			}
		}
		// todo 处理容器
	}

	return false;
}

template <typename T, typename Predicate>
bool UKGCoreEditorFunctionLibrary::GetNestedStructValue(void* StructContainer, UStruct* StructType, Predicate Pred, T& OutValue)
{
	bool bFoundProperty = false;
	for (TFieldIterator<FProperty> It(StructType); It; ++It)
	{
		FProperty* Property = *It;
        
		if (Pred(Property->GetAuthoredName()))
		{
			void* PropertyPtr = Property->ContainerPtrToValuePtr<void>(StructContainer);
			Property->CopyCompleteValue(static_cast<void*>(&OutValue), PropertyPtr);
			bFoundProperty = true;
		}

		// 递归处理嵌套结构体
		if (FStructProperty* StructProperty = CastField<FStructProperty>(Property))
		{
			if (GetNestedStructValue(
				StructProperty->ContainerPtrToValuePtr<void>(StructContainer),
				StructProperty->Struct,
				Pred,
				OutValue))
			{
				bFoundProperty = true;
			}
		}
		else if (FObjectProperty* ObjectProperty = CastField<FObjectProperty>(Property))
		{
			if (UObject* SubObject = ObjectProperty->GetObjectPropertyValue(Property->ContainerPtrToValuePtr<void>(StructContainer)))
			{
				if (GetPropertyValueByPredicate(Pred, SubObject, OutValue))
				{
					bFoundProperty = true;
				}
			}
		}
	}
	
	return bFoundProperty;
}

template <typename T, typename Predicate>
bool UKGCoreEditorFunctionLibrary::SetNestedStructValue(void* StructContainer, UStruct* StructType, Predicate Pred, const T& NewValue)
{
	bool bFoundProperty = false;
	for (TFieldIterator<FProperty> It(StructType); It; ++It)
	{
		FProperty* Property = *It;
        
		if (Pred(Property->GetAuthoredName()))
		{
			void* PropertyPtr = Property->ContainerPtrToValuePtr<void>(StructContainer);
			Property->CopyCompleteValue(PropertyPtr, static_cast<const void*>(&NewValue));
			bFoundProperty = true;
		}

		// 递归处理嵌套结构体
		if (FStructProperty* StructProperty = CastField<FStructProperty>(Property))
		{
			if (SetNestedStructValue(
				StructProperty->ContainerPtrToValuePtr<void>(StructContainer),
				StructProperty->Struct,
				Pred,
				NewValue))
			{
				bFoundProperty = true;
			}
		}
		else if (FObjectProperty* ObjectProperty = CastField<FObjectProperty>(Property))
		{
			if (UObject* SubObject = ObjectProperty->GetObjectPropertyValue(Property->ContainerPtrToValuePtr<void>(StructContainer)))
			{
				if (SetPropertyValueByPredicate(Pred, SubObject, NewValue))
				{
					bFoundProperty = true;
				}
			}
		}
	}
	
	return bFoundProperty;
}

