#pragma once

#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "DumpTypesCommandlet.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogDumpTypesCommandlet, All, All);

UCLASS()
class KGCOREEDITOR_API UDumpTypesCommandlet : public UCommandlet
{
	GENERATED_BODY()
public:
	virtual int32 Main(const FString& Params) override;

private:
	void ExportAllReflectionTypes(const FString& OutputPath);
	FString ExportClassType(UClass* Class);
	FString ExportStructType(UScriptStruct* Struct);
	FString ExportEnumType(UEnum* Enum);
	FString GetFunctionSignature(UFunction* Function);
	FString GetFunctionReturnType(UFunction* Function);
	FString GetPropertyTypeName(FProperty* Property);
	FString GetEnumValueList(UEnum* Enum);
};
