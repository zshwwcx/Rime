// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Input/Reply.h"
#include "ITransportControl.h"

class InPreviewProxy;
class UAnimSingleNodeInstance;
class FTimelineController;

class KGCOREEDITOR_API SAnimTimelineTransportControls : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SAnimTimelineTransportControls) {}

	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, const TSharedRef<FTimelineController>& InEditorTimelineController);

private:
	FReply OnClick_Forward_Step();

	FReply OnClick_Forward();

	EPlaybackMode::Type GetPlaybackMode() const;

private:
	TWeakPtr<FTimelineController> EditorTimelineController;

};