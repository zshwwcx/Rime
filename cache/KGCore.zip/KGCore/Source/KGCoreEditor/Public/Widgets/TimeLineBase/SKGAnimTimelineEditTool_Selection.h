#pragma once

#include "CoreMinimal.h"
#include "Layout/Geometry.h"
#include "Input/Events.h"
#include "Input/Reply.h"
#include "Types/PaintArgs.h"
#include "Styling/WidgetStyle.h"

class SAnimTrackArea;

class SKGAnimTimelineEditTool_Selection
{
public:
	SKGAnimTimelineEditTool_Selection(TSharedRef<SAnimTrackArea const> TrackArea);

	FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);
	int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const;
	void RaiseOnMarqueeFinished();
	void RaiseOnMarqueeSelecting();
	void MoveVirtualArea(FVector2D Delta);

private:
	FVector2D StartPosition;
	FVector2D CurrentPosition;

	TWeakPtr<SAnimTrackArea const> TrackArea;
};