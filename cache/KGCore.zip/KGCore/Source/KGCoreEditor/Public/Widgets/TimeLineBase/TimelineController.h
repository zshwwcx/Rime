#pragma once

#include "CoreMinimal.h"
#include "AnimatedRange.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Misc/FrameNumber.h"
#include "ITimeSlider.h"



class KGCOREEDITOR_API FTimelineController : public TSharedFromThis<FTimelineController>
{
#pragma region Important
public:
	FTimelineController() {}
	virtual ~FTimelineController() {}

	/** Refresh the tracks we have using our underlying asset */
	virtual void RefreshTracks();

	/** Build a context menu for selected items */
	virtual void BuildContextMenu(FMenuBuilder& InMenuBuilder);

#pragma endregion Important



#pragma region Parameter
public:
	/** Get the root tracks representing the tree */
	virtual TArray<TSharedRef<class FAnimTimelineTrack>>& GetRootTracks();
	virtual const TArray<TSharedRef<class FAnimTimelineTrack>>& GetRootTracks() const;

	/** Get the current view range */
	virtual FAnimatedRange GetViewRange() const;
	/** Set the current view range */
	virtual void SetViewRange(TRange<double> InRange);

	/** Snap ViewRange to PlayRange */
	virtual void SnapViewToPlayRange();

	/** Get the working range of the model's data */
	virtual FAnimatedRange GetWorkingRange() const;
	/** Get the playback range of the model's data */
	virtual TRange<FFrameNumber> GetPlaybackRange() const;

	/** Get the current scrub position */
	virtual FFrameNumber GetScrubPosition() const;
	/** Set the current scrub position */
	virtual void SetScrubPosition(FFrameTime NewScrubPostion) const;

	/** Get the sequence length of the object */
	virtual float GetPlayLength() const;
	/** Get the framerate specified by the anim sequence */
	virtual double GetFrameRate() const;
	/** Get the tick resolution we are displaying at */
	virtual int32 GetTickResolution() const;

	/** Handle the view range being changed */
	virtual void HandleViewRangeChanged(TRange<double> InRange, EViewRangeInterpolation InInterpolation);

	/** Handle the working range being changed */
	virtual void HandleWorkingRangeChanged(TRange<double> InRange);

	/** Get whether a track is selected */
	virtual bool IsTrackSelected(const TSharedRef<class FAnimTimelineTrack>& InTrack) const;

	/** Clear all track selection */
	virtual void ClearTrackSelection();

//辅助线相关接口Start Add By Kanzhengjie
	//TimelineTrack辅助线列表
	virtual TArray<float> GetAssistLinePosX() { TArray<float> ret; return ret; };
	//获取辅助线的颜色
	virtual FLinearColor GetAssistLineColor() { return FLinearColor::Yellow; };
	//设置当前正在拖拽的Section 实时PosX
	void SetDragSectionPosX(float PosX);
	float GetDragSectionPosX() { return DragSectionPosX; };
//辅助线相关接口End Add By Kanzhengjie


	/** Set whether a track is selected */
	virtual void SetTrackSelected(const TSharedRef<class FAnimTimelineTrack>& InTrack, bool bIsSelected);

	/** Set When a Track is DoubleClicked Add By Kanzhengjie*/
	virtual void DoubleClickTrack(const TSharedRef<class FAnimTimelineTrack>& InTrack);

	/** 'Selects' objects and shows them in the details view */
	virtual void SelectObjects(const TArray<UObject*>& Objects);

	/** Clears the detail view of whatever we displayed last */
	virtual void PostClearTrackSelection();

protected:
	/** Tracks used to generate a tree */
	TArray<TSharedRef<class FAnimTimelineTrack>> RootTracks;

	/** Tracks that are selected */
	TSet<TSharedRef<class FAnimTimelineTrack>> SelectedTracks;

	/** The range we are currently viewing */
	FAnimatedRange ViewRange;

	/** The working range of this model, encompassing the view range */
	FAnimatedRange WorkingRange;

	/** Recursion guard for selection */
	bool bIsSelecting;

#pragma endregion Parameter



#pragma region Event
public:
	DECLARE_EVENT(FTimelineController, FOnTracksChanged)

protected:
	FOnTracksChanged TracksChangedEvent;
	//正在拖拽的Section PostionX, 0表示没有
	int DragSectionPosX = 0;
public:
	FOnTracksChanged& OnTracksChanged() { return TracksChangedEvent; }

#pragma endregion Event

};

