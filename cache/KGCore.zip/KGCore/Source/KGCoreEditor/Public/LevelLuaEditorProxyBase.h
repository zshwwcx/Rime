#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Engine/Engine.h"
#include "Containers/Map.h"
#include "TickableEditorObject.h"
#include "LevelLuaEditorProxyBase.generated.h"

USTRUCT(BlueprintType)
struct KGCOREEDITOR_API FRoleConfigData
{
	GENERATED_BODY()

public:
	FRoleConfigData()
		: ConfigID(""), Des("")
	{
	}

public:
	UPROPERTY(BlueprintReadWrite, Transient)
	FString ConfigID;

	UPROPERTY(BlueprintReadWrite, Transient)
	FString Des;
};

USTRUCT(BlueprintType)
struct FRoleConfigDataList
{
	GENERATED_BODY()

public:
	FRoleConfigDataList()
	{
	}

public:
	UPROPERTY(BlueprintReadWrite, Transient)
	TArray<FRoleConfigData> RoleConfigDatas;
};

// 角色配置相关
typedef TMap<FString, FRoleConfigDataList> FGetRoleConfigDataDelegateParam1;
DECLARE_DELEGATE_OneParam(FGetRoleConfigDataDelegate, FGetRoleConfigDataDelegateParam1&);
// JSON字符串和lua字符串得转换
DECLARE_DELEGATE_RetVal_OneParam(FString, FJsonStrToLuaStr, FString&);
// 编辑器下得Lua虚拟机操作
DECLARE_DELEGATE(FStartUnluaDelegate);
DECLARE_DELEGATE(FStopUnluaDelegate);
DECLARE_DELEGATE_RetVal(int32, FGetUnluaRefCountDelegate);
DECLARE_DELEGATE(FCloseLuaEnvConflictedEditorsDelegate);
DECLARE_DELEGATE_TwoParams(FGetLuaEnvConflictedEditorNumDelegate, int& EditingNum, int& UnSavedNum);
// Lua虚拟机触发PIE
DECLARE_DELEGATE_OneParam(FLuaOnBeginPIE, bool);
DECLARE_DELEGATE_OneParam(FLuaOnEndPIE, bool);
// LevelFlow数据转化
DECLARE_DELEGATE_RetVal_SixParams(FString, FGetLevelFlowStringPropValueNew, FString, FString, FString, int32, FString, FString);
DECLARE_DELEGATE_RetVal_SixParams(TArray<FString>, FGetLevelFlowArrayPropValueNew, FString, FString, FString, int32, FString, FString);
using MyType = TMap<FString, int32>;
DECLARE_DELEGATE_RetVal_SixParams(MyType, FGetLevelFlowMapPropValueNew, FString, FString, FString, int32, FString, FString);


DECLARE_DELEGATE_RetVal_OneParam(const UDataLayerInstance*, FGetCurrentDataLayer, const UWorld*);
// LevelFlow数据导出
DECLARE_DELEGATE(FExportLevelFlowData);
DECLARE_DELEGATE_FourParams(FSerializeLevelFlow, class ULevelFlow*, const FString, const FString, const FString);
DECLARE_DELEGATE_FourParams(FDeserializeLevelFlow, class ULevelFlow*, const FString, const FString, const FString);

class KGCOREEDITOR_API FLevelLuaEditorProxyBase
{
	// 通用得API封装，其他Plugin来具体实现
public:
	static FGetRoleConfigDataDelegate GetRoleConfigData;
	static FStartUnluaDelegate StartUnlua;
	static FStopUnluaDelegate StopUnlua;
	static FCloseLuaEnvConflictedEditorsDelegate CloseUnluaConflictedEditor;
	static FGetLuaEnvConflictedEditorNumDelegate GetLuaEnvConflictedEditorNum;
	static FJsonStrToLuaStr JsonStrToLuaStr;
	static FLuaOnBeginPIE LuaOnBeginPIE;
	static FLuaOnEndPIE LuaOnEndPIE;
	static FGetLevelFlowStringPropValueNew GetLevelFlowStringPropValueNew;
	static FGetLevelFlowArrayPropValueNew GetLevelFlowArrayPropValueNew;
	static FGetLevelFlowMapPropValueNew GetLevelFlowMapPropValueNew;
	
	static FSerializeLevelFlow SerializeLevelFlow;
	static FDeserializeLevelFlow DeserializeLevelFlow;
};
