#pragma once

#include "CoreMinimal.h"
#include "Containers/Map.h"
#include "Templates/SharedPointer.h"
#include "Misc/StringBuilder.h"

namespace SeqLua
{
	// 定义值的类型，可以是字符串、整数、浮点数、布尔值或嵌套表
	using FLuaValue = TSharedPtr<struct FLuaValueType>;

	struct FLuaValueType
	{
		virtual ~FLuaValueType() = default;
		virtual FString ToString(int32 IndentLevel = 0) const = 0;
	};

	// 具体类型：字符串
	struct FLuaStringValue : public FLuaValueType
	{
		FString Value;

		FLuaStringValue(const FString& InValue) : Value(InValue) {}

		virtual FString ToString(int32 IndentLevel) const override
		{
			return FString::Printf(TEXT("\"%s\""), *Value);
		}
	};

	// 具体类型：整数
	struct FLuaIntValue : public FLuaValueType
	{
		int32 Value;

		FLuaIntValue(int32 InValue) : Value(InValue) {}

		virtual FString ToString(int32 IndentLevel) const override
		{
			return FString::Printf(TEXT("%d"), Value);
		}
	};

	// 具体类型：浮点数
	struct FLuaDoubleValue : public FLuaValueType
	{
		double Value;

		FLuaDoubleValue(double InValue) : Value(InValue) {}

		virtual FString ToString(int32 IndentLevel) const override
		{
			return FString::Printf(TEXT("%f"), Value);
		}
	};

	// 具体类型：布尔值
	struct FLuaBoolValue : public FLuaValueType
	{
		bool Value;

		FLuaBoolValue(bool InValue) : Value(InValue) {}

		virtual FString ToString(int32 IndentLevel) const override
		{
			return Value ? TEXT("true") : TEXT("false");
		}
	};

	// 具体类型：嵌套表
	struct FLuaArrayValue : public FLuaValueType
	{
		TArray<FLuaValue> Values;

		virtual FString ToString(int32 IndentLevel) const override
		{
			FStringBuilderBase LuaTable;
			FString Indent = FString::ChrN(IndentLevel * 4, ' '); // 根据缩进级别生成缩进

			LuaTable /*<< Indent*/ << TEXT("{");
			for (size_t i = 0; i < Values.Num(); i++)
			{
				auto v = Values[i];
				if (i != 0)
				{
					LuaTable<< TEXT(",");
				}
				LuaTable << v->ToString(IndentLevel);
			}
			LuaTable << TEXT("}");
			return LuaTable.ToString();
		}
	};

	// 具体类型：嵌套表
	struct FLuaTableValue : public FLuaValueType
	{
		TMap<FString, FLuaValue> Table;

		virtual FString ToString(int32 IndentLevel) const override
		{
			FStringBuilderBase LuaTable;
			FString Indent = FString::ChrN(IndentLevel * 4, ' '); // 根据缩进级别生成缩进

			LuaTable /*<< Indent*/ << TEXT("{\n");
			for (const auto& Pair : Table)
			{
				LuaTable << Indent << TEXT("    ") << Pair.Key << TEXT(" = ") << Pair.Value->ToString(IndentLevel + 1) << TEXT(",\n");
			}
			LuaTable << Indent << TEXT("}");
			return LuaTable.ToString();
		}
	};

	class FLuaTableGenerator
	{
	public:
		// 添加键值对
		void AddValue(const FString& Key, const FLuaValue& Value)
		{
			Table.Add(Key, Value);
		}

		// 生成 LUA 表字符串
		FString GenerateLuaTable(int32 IndentLevel = 0) const
		{
			FStringBuilderBase LuaTable;

			FLuaTableValue TableValue;
			TableValue.Table = Table;
			FString content = TableValue.ToString(IndentLevel);
			//return TableValue.ToString(IndentLevel);
			LuaTable << TEXT("local LevelSequenceData =\n") << content;
			return LuaTable.ToString();
		}

	private:
		TMap<FString, FLuaValue> Table; // 使用 TMap 存储键值对
	};
}

/*

使用参考
void GenerateLuaTableExample()
{
	// 创建根表
	FLuaTableGenerator RootTable;

	// 添加简单键值对
	RootTable.AddValue(TEXT("name"), MakeShared<FLuaStringValue>(TEXT("John Doe")));
	RootTable.AddValue(TEXT("age"), MakeShared<FLuaIntValue>(30));
	RootTable.AddValue(TEXT("height"), MakeShared<FLuaDoubleValue>(5.9));
	RootTable.AddValue(TEXT("isStudent"), MakeShared<FLuaBoolValue>(false));

	// 创建嵌套表
	TSharedPtr<FLuaTableValue> AddressTable = MakeShared<FLuaTableValue>();
	AddressTable->Table.Add(TEXT("street"), MakeShared<FLuaStringValue>(TEXT("123 Main St")));
	AddressTable->Table.Add(TEXT("city"), MakeShared<FLuaStringValue>(TEXT("Anytown")));
	AddressTable->Table.Add(TEXT("zip"), MakeShared<FLuaIntValue>(12345));

	// 将嵌套表添加到根表
	RootTable.AddValue(TEXT("address"), AddressTable);

	// 创建另一个嵌套表
	TSharedPtr<FLuaTableValue> PreferencesTable = MakeShared<FLuaTableValue>();
	PreferencesTable->Table.Add(TEXT("theme"), MakeShared<FLuaStringValue>(TEXT("dark")));
	PreferencesTable->Table.Add(TEXT("notifications"), MakeShared<FLuaBoolValue>(true));

	// 将嵌套表添加到根表
	RootTable.AddValue(TEXT("preferences"), PreferencesTable);

	// 生成 LUA 表字符串
	FString LuaTableString = RootTable.GenerateLuaTable();

	// 输出生成的 LUA 表
	UE_LOG(LogTemp, Log, TEXT("Generated LUA Table:\n%s"), *LuaTableString);
}

*/