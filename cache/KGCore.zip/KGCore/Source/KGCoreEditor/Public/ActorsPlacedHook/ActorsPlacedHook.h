#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"


DECLARE_LOG_CATEGORY_EXTERN(LogActorsPlacedHook, All, All);

class FActorsPlacedHook : public TSharedFromThis<FActorsPlacedHook>
{
public:
	void OnStartupModule();
	void OnShutdownModule();

	void OnNewActorsPlaced(UObject* ObjToUse, const TArray<AActor*>& PlacedActors);

	void InitProcessors();

	TSharedPtr<class FStaticMeshPlacedPostProcessor> StaticMeshProcessor;
};
