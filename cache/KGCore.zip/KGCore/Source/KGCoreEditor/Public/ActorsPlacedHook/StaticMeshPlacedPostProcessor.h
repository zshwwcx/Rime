#pragma once

#include "CoreMinimal.h"
#include "ActorsPlacedHook/ActorPlacedPostProcessor.h"
#include "Engine/DataTable.h"
#include "Engine/DeveloperSettings.h"

#include "StaticMeshPlacedPostProcessor.generated.h"

USTRUCT(BlueprintType)
struct FSMPlacedData : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TObjectPtr<class UMaterialInterface> Material = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<FString, FString> Properties;
};

class FStaticMeshPlacedPostProcessor : public FActorPlacedPostProcessor
{
public:
	virtual void Process(UObject* ObjToUse, AActor* PlacedActor) override;

	static void ProcessByMaterial(UObject* ObjToUse, AActor* PlacedActor);
};

UCLASS(Config = Editor, meta = (DisplayName = "KGActorsPlacedSettings"), DefaultConfig)
class UKGActorsPlacedSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Config)
	FString DataTablePath;
};
