#pragma once

#include "CoreMinimal.h"

class FActorPlacedPostProcessor : public TSharedFromThis<FActorPlacedPostProcessor>
{
public:
	virtual ~FActorPlacedPostProcessor() = default;

	virtual void Process(UObject* ObjToUse, class AActor* PlacedActor)
	{
	}

	static void SetPropertyValueByName(UObject* InObject, const FString& PropertyName, const FString& PropertyValue, FString& ErrorLog);
};
