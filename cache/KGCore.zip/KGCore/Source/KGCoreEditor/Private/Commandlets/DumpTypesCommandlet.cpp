#include "Commandlets/DumpTypesCommandlet.h"
#include "UObject/Class.h"
#include "UObject/UObjectIterator.h"
#include "Misc/FileHelper.h"
#include "UObject/UnrealType.h"
#include "UObject/Field.h"
#include "Misc/Paths.h"
#include "GameFramework/Actor.h"

int32 UDumpTypesCommandlet::Main(const FString& Params)
{
	// 解析命令行参数
	TArray<FString> Tokens;
	TArray<FString> Switches;
	TMap<FString, FString> ParamVals;
	ParseCommandLine(*Params, Tokens, Switches, ParamVals);

	// 获取输出文件路径
	FString OutputPath = FPaths::ProjectSavedDir() / TEXT("ReflectionTypes.txt");
	if (const FString* OutputPathParam = ParamVals.Find("output"))
	{
		OutputPath = *OutputPathParam;
	}

	ExportAllReflectionTypes(OutputPath);

	return 0;
}

void UDumpTypesCommandlet::ExportAllReflectionTypes(const FString& OutputPath)
{
	FString OutputString;

	// 导出所有UCLASS类型
	for (TObjectIterator<UClass> It; It; ++It)
	{
		UClass* Class = *It;
		if (Class && Class->HasAnyClassFlags(CLASS_Native))
		{
			OutputString += ExportClassType(Class);
		}
	}

	// 导出所有USTRUCT类型
	for (TObjectIterator<UScriptStruct> It; It; ++It)
	{
		UScriptStruct* Struct = *It;
		if (Struct /*&& Struct->GetOuter() != GetTransientPackage()*/)
		{
			OutputString += ExportStructType(Struct);
		}
	}

	// 导出所有UENUM类型
	for (TObjectIterator<UEnum> It; It; ++It)
	{
		UEnum* Enum = *It;
		if (Enum /*&& Enum->GetOuter() != GetTransientPackage()*/)
		{
			OutputString += ExportEnumType(Enum);
		}
	}

	if (FFileHelper::SaveStringToFile(OutputString, *OutputPath))
	{
		UE_LOG(LogTemp, Display, TEXT("Successfully exported reflection types to: %s"), *OutputPath);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to export reflection types to: %s"), *OutputPath);
	}
}

FString UDumpTypesCommandlet::ExportClassType(UClass* Class)
{
	FString Result;

	int32 FuncCount = 0;
	int32 PropCount = 0;

	// 统计数量
	for (TFieldIterator<UFunction> FuncIt(Class, EFieldIterationFlags::IncludeDeprecated); FuncIt; ++FuncIt)
	{
		//if ((*FuncIt)->HasAnyFunctionFlags(FUNC_BlueprintCallable | FUNC_BlueprintEvent))
		{
			FuncCount++;
		}
	}

	for (TFieldIterator<FProperty> PropIt(Class, EFieldIterationFlags::IncludeDeprecated); PropIt; ++PropIt)
	{
		//if ((*PropIt)->HasAnyPropertyFlags(CPF_BlueprintVisible))
		{
			PropCount++;
		}
	}

	FString ClassName = Class->GetName();
	if (Class->GetDefaultObject() && Class->GetDefaultObject()->IsA(AActor::StaticClass()))
	{
		ClassName = FString(TEXT("A")) + ClassName;
	}
	else
	{
		ClassName = FString(TEXT("U")) + ClassName;
	}

	Result += FString::Printf(TEXT("ClassName[%s] FuncCount[%d] PropertyCount[%d]\n"),
		*ClassName, FuncCount, PropCount);

	// 导出函数
	for (TFieldIterator<UFunction> FuncIt(Class, EFieldIterationFlags::IncludeDeprecated); FuncIt; ++FuncIt)
	{
		UFunction* Function = *FuncIt;
		//if (Function->HasAnyFunctionFlags(FUNC_BlueprintCallable | FUNC_BlueprintEvent))
		{
			Result += FString::Printf(TEXT("\t[UFUNCTION] [%s]\n"), *GetFunctionSignature(Function));
		}
	}

	// 导出属性
	for (TFieldIterator<FProperty> PropIt(Class, EFieldIterationFlags::IncludeDeprecated); PropIt; ++PropIt)
	{
		FProperty* Property = *PropIt;
		//if (Property->HasAnyPropertyFlags(CPF_BlueprintVisible))
		{
			Result += FString::Printf(TEXT("\t[UPROPERTY] [%s] [%s]\n"),
				*GetPropertyTypeName(Property),
				*Property->GetName());
		}
	}

	return Result;
}

FString UDumpTypesCommandlet::ExportStructType(UScriptStruct* Struct)
{
	FString Result;

	int32 PropCount = 0;
	for (TFieldIterator<FProperty> PropIt(Struct, EFieldIterationFlags::IncludeDeprecated); PropIt; ++PropIt)
	{
		//if ((*PropIt)->HasAnyPropertyFlags(CPF_BlueprintVisible))
		{
			PropCount++;
		}
	}

	Result += FString::Printf(TEXT("StructName[F%s] PropertyCount[%d]\n"),
		*Struct->GetName(), PropCount);

	// 导出属性
	for (TFieldIterator<FProperty> PropIt(Struct, EFieldIterationFlags::IncludeDeprecated); PropIt; ++PropIt)
	{
		FProperty* Property = *PropIt;
		//if (Property->HasAnyPropertyFlags(CPF_BlueprintVisible))
		{
			Result += FString::Printf(TEXT("\t[UPROPERTY] [%s] [%s]\n"),
				*GetPropertyTypeName(Property),
				*Property->GetName());
		}
	}

	return Result;
}

FString UDumpTypesCommandlet::ExportEnumType(UEnum* Enum)
{
	FString Result;

	int32 ValueCount = Enum->NumEnums() - 1; // 减去最后的_MAX项

	Result += FString::Printf(TEXT("EnumName[%s]\n"),
		*Enum->GetName());

	//// 导出枚举值
	//for (int32 i = 0; i < ValueCount; ++i)
	//{
	//	Result += FString::Printf(TEXT("\t[ENUMVALUE] [%s = %d]\n"),
	//		*Enum->GetNameStringByIndex(i),
	//		Enum->GetValueByIndex(i));
	//}

	return Result;
}

FString UDumpTypesCommandlet::GetFunctionSignature(UFunction* Function)
{
	FString Signature = GetFunctionReturnType(Function);
	Signature += " ";
	Signature += Function->GetName();
	Signature += "(";

	bool bFirstParam = true;
	for (TFieldIterator<FProperty> ParamIt(Function); ParamIt; ++ParamIt)
	{
		FProperty* Param = *ParamIt;
		if (Param->GetPropertyFlags() & CPF_Parm && !(Param->GetPropertyFlags() & CPF_ReturnParm))
		{
			if (!bFirstParam) Signature += ", ";

			if (Param->HasAnyPropertyFlags(CPF_ConstParm))
			{
				Signature += "const ";
			}

			Signature += GetPropertyTypeName(Param);
			//Signature += " ";
			//Signature += Param->GetName();

			bFirstParam = false;
		}
	}

	Signature += ")";
	return Signature;
}

FString UDumpTypesCommandlet::GetFunctionReturnType(UFunction* Function)
{
	FProperty* ReturnProp = Function->GetReturnProperty();
	return ReturnProp ? GetPropertyTypeName(ReturnProp) : TEXT("void");
}

FString UDumpTypesCommandlet::GetPropertyTypeName(FProperty* Property)
{
	if (FClassProperty* ClassProperty = CastField<FClassProperty>(Property))
	{
		return FString::Printf(TEXT("TSubclassOf<U%s>"), *ClassProperty->MetaClass->GetName());
	}
	else if (FObjectProperty* ObjectProperty = CastField<FObjectProperty>(Property))
	{
		return FString::Printf(TEXT("U%s*"), *ObjectProperty->PropertyClass->GetName());
	}
	else if (FEnumProperty* EnumProperty = CastField<FEnumProperty>(Property))
	{
		return EnumProperty->GetEnum()->GetName();
	}
	else if (FByteProperty* ByteProperty = CastField<FByteProperty>(Property))
	{
		if (ByteProperty->Enum)
		{
			return FString::Printf(TEXT("TEnumAsByte<%s>"), *ByteProperty->Enum->GetName());
		}
	}
	else if (FArrayProperty* ArrayProperty = CastField<FArrayProperty>(Property))
	{
		return FString::Printf(TEXT("TArray<%s>"), *GetPropertyTypeName(ArrayProperty->Inner));
	}
	else if (FSetProperty* SetProperty = CastField<FSetProperty>(Property))
	{
		return FString::Printf(TEXT("TSet<%s>"), *GetPropertyTypeName(SetProperty->ElementProp));
	}
	else if (FMapProperty* MapProperty = CastField<FMapProperty>(Property))
	{
		return FString::Printf(TEXT("TMap<%s, %s>"),
			*GetPropertyTypeName(MapProperty->KeyProp),
			*GetPropertyTypeName(MapProperty->ValueProp));
	}

	return Property->GetCPPType();
}
