#include "ActorsPlacedHook/ActorPlacedPostProcessor.h"

#include "UObject/Class.h"
#include "UObject/EnumProperty.h"
#include "UObject/Field.h"
#include "UObject/Object.h"
#include "UObject/UnrealType.h"

void FActorPlacedPostProcessor::SetPropertyValueByName(UObject* InObject, const FString& PropertyName, const FString& PropertyValue, FString& ErrorLog)
{
	FProperty* Property = InObject->GetClass()->FindPropertyByName(*PropertyName);

	if (!Property)
	{
		ErrorLog = FString::Format(TEXT("The Property: {0} is not in {1}"), {PropertyName, InObject->GetClass()->GetName()});
		return;
	}

	if (const FByteProperty* ByteProp = CastField<FByteProperty>(Property))
	{
		const uint8 Value = static_cast<uint8>(FCString::Atoi(*PropertyValue));
		ByteProp->SetPropertyValue_InContainer(InObject, Value);
	}
	else if (const FEnumProperty* EnumProp = CastField<FEnumProperty>(Property))
	{
		const int64 Value = FCString::Atoi64(*PropertyValue);
		EnumProp->GetUnderlyingProperty()->SetIntPropertyValue(InObject, Value);
	}
	else if (const FBoolProperty* BoolProp = CastField<FBoolProperty>(Property))
	{
		const FString Lower = PropertyValue.ToLower();
		if (Lower != "true" || Lower != "false" || Lower != "1" || Lower != "0")
		{
			ErrorLog = FString::Format(TEXT("The Property value: {0} is not valid bool of Property: {1}"), {Lower, PropertyName});
			return;
		}
		const bool Value = PropertyValue.ToLower() == "true" || PropertyValue == "1";
		BoolProp->SetPropertyValue_InContainer(InObject, Value);
	}
	else if (const FInt8Property* Int8Prop = CastField<FInt8Property>(Property))
	{
		const int8 Value = static_cast<int8>(FCString::Atoi(*PropertyValue));
		Int8Prop->SetPropertyValue_InContainer(InObject, Value);
	}
	else if (const FInt16Property* Int16Prop = CastField<FInt16Property>(Property))
	{
		const int16 Value = static_cast<int16>(FCString::Atoi(*PropertyValue));
		Int16Prop->SetPropertyValue_InContainer(InObject, Value);
	}
	else if (const FIntProperty* Int32Prop = CastField<FIntProperty>(Property))
	{
		const int32 Value = FCString::Atoi(*PropertyValue);
		Int32Prop->SetPropertyValue_InContainer(InObject, Value);
	}
	else if (const FInt64Property* Int64Prop = CastField<FInt64Property>(Property))
	{
		const int64 Value = FCString::Atoi64(*PropertyValue);
		Int64Prop->SetPropertyValue_InContainer(InObject, Value);
	}
	else if (const FFloatProperty* FloatProp = CastField<FFloatProperty>(Property))
	{
		const float Value = FCString::Atof(*PropertyValue);
		FloatProp->SetPropertyValue_InContainer(InObject, Value);
	}
	else if (const FDoubleProperty* DoubleProp = CastField<FDoubleProperty>(Property))
	{
		const double Value = FCString::Atod(*PropertyValue);
		DoubleProp->SetPropertyValue_InContainer(InObject, Value);
	}
	else
	{
		ErrorLog = FString::Format(TEXT("The Property: {0} is not an valid type"), {PropertyName});
	}
}
