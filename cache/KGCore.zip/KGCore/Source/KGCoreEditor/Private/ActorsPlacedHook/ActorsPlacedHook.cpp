#include "ActorsPlacedHook/ActorsPlacedHook.h"
#include "Editor.h"
#include "ActorsPlacedHook/StaticMeshPlacedPostProcessor.h"
#include "Engine/StaticMeshActor.h"

DEFINE_LOG_CATEGORY(LogActorsPlacedHook)

static TAutoConsoleVariable<bool> CVarActorsPlacedHookEnable(
	TEXT("c7.Editor.ActorsPlacedHookEnable"),
	true,
	TEXT("Post Process when place actors."),
	ECVF_Default | ECVF_RenderThreadSafe);

void FActorsPlacedHook::OnStartupModule()
{
	FEditorDelegates::OnNewActorsPlaced.AddRaw(this, &FActorsPlacedHook::OnNewActorsPlaced);
}

void FActorsPlacedHook::OnShutdownModule()
{
	FEditorDelegates::OnNewActorsPlaced.RemoveAll(this);
}

void FActorsPlacedHook::InitProcessors()
{
	if (!StaticMeshProcessor.IsValid())
	{
		StaticMeshProcessor = MakeShared<FStaticMeshPlacedPostProcessor>();
	}
}

void FActorsPlacedHook::OnNewActorsPlaced(UObject* ObjToUse, const TArray<AActor*>& PlacedActors)
{
	if (!CVarActorsPlacedHookEnable.GetValueOnAnyThread())
	{
		return;
	}
	InitProcessors();
	for (AActor* Actor: PlacedActors)
	{
		// 暂时只有StaticMesh有相关的需求，后续有其他需求可考虑扩展成注册的形式
		if (Cast<AStaticMeshActor>(Actor))
		{
			StaticMeshProcessor->Process(ObjToUse, Actor);
		}
	}
}
