#include "ActorsPlacedHook/StaticMeshPlacedPostProcessor.h"

#include "ActorsPlacedHook/ActorsPlacedHook.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/DataTable.h"
#include "Engine/StaticMesh.h"
#include "Engine/StaticMeshActor.h"
#include "Materials/MaterialInterface.h"


void FStaticMeshPlacedPostProcessor::Process(UObject* ObjToUse, AActor* PlacedActor)
{
	ProcessByMaterial(ObjToUse, PlacedActor);
}

void FStaticMeshPlacedPostProcessor::ProcessByMaterial(UObject* ObjToUse, AActor* PlacedActor)
{
	const AStaticMeshActor* StaticMeshActor = Cast<AStaticMeshActor>(PlacedActor);
	UStaticMeshComponent* StaticMeshComponent = StaticMeshActor->GetStaticMeshComponent();
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(ObjToUse);
	if (!StaticMesh)
	{
		UE_LOG(LogActorsPlacedHook, Warning, TEXT("StaticMesh is null"))
		return;
	}
	const UKGActorsPlacedSettings* Settings = GetDefault<UKGActorsPlacedSettings>();
	if (Settings->DataTablePath.IsEmpty())
	{
		UE_LOG(LogActorsPlacedHook, Warning, TEXT("Data Table Path is empty!"))
		return;
	}
	const UDataTable* DataTable = Cast<UDataTable>(StaticLoadObject(UDataTable::StaticClass(), nullptr, *Settings->DataTablePath));
	if (!DataTable)
	{
		UE_LOG(LogActorsPlacedHook, Warning, TEXT("Data table not found: %s"), *Settings->DataTablePath)
		return;
	}
	TArray<FName> RowNames = DataTable->GetRowNames();
	if (RowNames.IsEmpty())
	{
		UE_LOG(LogActorsPlacedHook, Warning, TEXT("Data table is empty"))
		return;
	}
	bool Processed = false;
	for (const FStaticMaterial& Material : StaticMesh->GetStaticMaterials())
	{
		const UMaterialInterface* MaterialInterface = Material.MaterialInterface;
		if (!MaterialInterface)
		{
			continue;
		}
		FString MaterialName = MaterialInterface->GetName();
		for (const FName& RowName : RowNames)
		{
			if (const FSMPlacedData* Result = DataTable->FindRow<FSMPlacedData>(RowName, "GetRow", false))
			{
				if (Result->Material == MaterialInterface)
				{
					for (auto Property: Result->Properties)
					{
						FString ErrorLog;
						SetPropertyValueByName(StaticMeshComponent, Property.Key, Property.Value, ErrorLog);
						if (!ErrorLog.IsEmpty())
						{
							UE_LOG(LogActorsPlacedHook, Warning, TEXT("%s"), *ErrorLog)
						}
					}
					Processed = true;
					break;
				}
			}
		}
		if (Processed)
		{
			break;
		}
	}
}
