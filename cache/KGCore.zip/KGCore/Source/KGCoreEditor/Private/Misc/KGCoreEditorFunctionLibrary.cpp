#include "Misc/KGCoreEditorFunctionLibrary.h"
#include "GameplayTagContainer.h"



#pragma region Json
void UKGCoreEditorFunctionLibrary::ExportStructToJson(void* DataAddress, UScriptStruct* TheStruct, TSharedPtr<FJsonObject> OutJson)
{
	if (!TheStruct)
		return;
		
	// 先把结构体路径存下来
	OutJson->SetStringField(TEXT("StructName"), TheStruct->GetName());
	OutJson->SetStringField(TEXT("StructPath"), TheStruct->GetPathName());

	for (TFieldIterator<FProperty> PropIt(TheStruct); PropIt; ++PropIt)
	{
		if ((*PropIt)->IsEditorOnlyProperty())
		{
			continue;
		}

		void* CurAddress = (*PropIt)->ContainerPtrToValuePtr<void>(DataAddress);
		if (FObjectProperty* CurObjProp = CastField<FObjectProperty>((*PropIt)))
		{
			UObject* CurObject = CurObjProp->GetObjectPropertyValue(CurAddress);
			OutJson->SetField((*PropIt)->GetName(), UKGCoreEditorFunctionLibrary::ExportPropertyToJson(CurObject, *PropIt));
		}
		else
		{
			OutJson->SetField((*PropIt)->GetName(), UKGCoreEditorFunctionLibrary::ExportPropertyToJson(CurAddress, *PropIt));
		}
	}
}

void UKGCoreEditorFunctionLibrary::ExportObjectToJson(UObject* TheObject, TSharedPtr<FJsonObject> OutJson)
{
	if (!TheObject)
		return;

	UClass* ObjectClass = TheObject->GetClass();

	// 先把类路径存下来
	OutJson->SetStringField(TEXT("ClassName"), ObjectClass->GetName());
	OutJson->SetStringField(TEXT("ClassPath"), ObjectClass->GetPathName());
	OutJson->SetStringField(TEXT("ObjectPath"), TheObject->GetPathName());

	for (TFieldIterator<FProperty> PropIt(ObjectClass); PropIt; ++PropIt)
	{
		// 不导出编辑器数据
		if ((*PropIt)->IsEditorOnlyProperty())
		{
			continue;
		}

		// 不导出UObject的数据
		UClass* CurrentClass = PropIt->GetOwnerClass();
		if (CurrentClass == UObject::StaticClass())
		{
			continue;
		}
		else
		{
			void* CurAddress = (*PropIt)->ContainerPtrToValuePtr<void>(TheObject);
			if (FObjectProperty* CurObjProp = CastField<FObjectProperty>((*PropIt)))
			{
				UObject* CurObject = CurObjProp->GetObjectPropertyValue(CurAddress);
				OutJson->SetField((*PropIt)->GetName(), UKGCoreEditorFunctionLibrary::ExportPropertyToJson(CurObject, *PropIt));
			}
			else
			{
				OutJson->SetField((*PropIt)->GetName(), UKGCoreEditorFunctionLibrary::ExportPropertyToJson(CurAddress, *PropIt));
			}
		}
	}
}

TSharedPtr<FJsonValue> UKGCoreEditorFunctionLibrary::ExportPropertyToJson(void* DataAddress, FProperty* Prop)
{
	if (FByteProperty* ByteProp = CastField<FByteProperty>(Prop))
	{
		int8* ValuePtr = (int8*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FEnumProperty* EnumProp = CastField<FEnumProperty>(Prop))
	{
		int8* ValuePtr = (int8*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FBoolProperty* BoolProp = CastField<FBoolProperty>(Prop))
	{
		bool Value = BoolProp->GetPropertyValue(DataAddress);
		return MakeShared<FJsonValueBoolean>(Value);
	}
	else if (FInt8Property* Int8Prop = CastField<FInt8Property>(Prop))
	{
		int8* ValuePtr = (int8*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FInt16Property* Int16Prop = CastField<FInt16Property>(Prop))
	{
		int16* ValuePtr = (int16*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FIntProperty* Int32Prop = CastField<FIntProperty>(Prop))
	{
		int32* ValuePtr = (int32*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FInt64Property* Int64Prop = CastField<FInt64Property>(Prop))
	{
		int64* ValuePtr = (int64*)DataAddress;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FFloatProperty* FloatProp = CastField<FFloatProperty>(Prop))
	{
		float* ValuePtr = (float*)DataAddress;
		double Value = FMath::RoundToDouble((*ValuePtr) * 1000.0f) / 1000.0f;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FDoubleProperty* DoubleProp = CastField<FDoubleProperty>(Prop))
	{
		double* ValuePtr = (double*)DataAddress;
		double Value = FMath::RoundToDouble((*ValuePtr) * 1000.0f) / 1000.0f;
		return MakeShared<FJsonValueNumber>(*ValuePtr);
	}
	else if (FClassProperty* ClassProp = CastField<FClassProperty>(Prop))
	{
		UClass* TheClass = (UClass*)(DataAddress);
		return MakeShared<FJsonValueString>(TheClass->GetPathName());
	}
	else if (FSoftClassProperty* SoftClassProp = CastField<FSoftClassProperty>(Prop))
	{
		FSoftObjectPtr* TheClass = (FSoftObjectPtr*)(DataAddress);
		return MakeShared<FJsonValueString>(TheClass->ToString());
	}
	else if (FObjectProperty* ObjectProp = CastField<FObjectProperty>(Prop))
	{
		if (ObjectProp->HasMetaData(TEXT("EditInline")))
		{
			UObject* ObjectPtr = (UObject*)DataAddress;
			TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

			UKGCoreEditorFunctionLibrary::ExportObjectToJson(ObjectPtr, JsonObject);

			return MakeShared<FJsonValueObject>(JsonObject);
		}
		else
		{
			UObject* ObjectPtr = (UObject*)DataAddress;
			return MakeShared<FJsonValueString>(ObjectPtr->GetPathName());
		}
	}
	else if (FSoftObjectProperty* SoftObjectProp = CastField<FSoftObjectProperty>(Prop))
	{
		FSoftObjectPtr* ValuePtr = (FSoftObjectPtr*)DataAddress;

		FString ObjectType;
		SoftObjectProp->GetCPPMacroType(ObjectType);

		if (ObjectType.Contains(TEXT("UBSASkillAsset")) || ObjectType.Contains(TEXT("UBSABuffAsset")) || ObjectType.Contains(TEXT("UBSAAsset")))
		{
			if (ValuePtr->IsNull())
			{
				return MakeShared<FJsonValueNumber>(0);
			}
			else
			{
				int32 ID = FCString::Atoi(*ValuePtr->GetAssetName());
				return MakeShared<FJsonValueNumber>(ID);
			}
		}

		return MakeShared<FJsonValueString>(ValuePtr->ToString());
	}
	else if (FNameProperty* NameProp = CastField<FNameProperty>(Prop))
	{
		FName* ValuePtr = (FName*)DataAddress;
		return MakeShared<FJsonValueString>(ValuePtr->ToString());
	}
	else if (FStrProperty* StringProp = CastField<FStrProperty>(Prop))
	{
		FString* ValuePtr = (FString*)DataAddress;
		return MakeShared<FJsonValueString>(*ValuePtr);
	}
	else if (FArrayProperty* ArrayProp = CastField<FArrayProperty>(Prop))
	{
		TArray<TSharedPtr<FJsonValue>> JsonArray;
		FScriptArrayHelper ArrayHelper(ArrayProp, DataAddress);

		FProperty* ElementType = ArrayProp->Inner;
		int32 ArrayNum = ArrayHelper.Num();
		for (int32 i = 0; i < ArrayNum; ++i)
		{
			void* ElementPtr = ArrayHelper.GetRawPtr(i);
			if (FObjectProperty* CurObjectProp = CastField<FObjectProperty>(ElementType))
			{
				ElementPtr = CurObjectProp->GetObjectPropertyValue(ElementPtr);
			}

			JsonArray.Add(UKGCoreEditorFunctionLibrary::ExportPropertyToJson(ElementPtr, ElementType));
		}

		return MakeShared<FJsonValueArray>(JsonArray);
	}
	else if (FMapProperty* MapProp = CastField<FMapProperty>(Prop))
	{
		TArray<TSharedPtr<FJsonValue>> JsonArray;
		FScriptMapHelper MapHelper(MapProp, DataAddress);

		FProperty* KeyType = MapHelper.GetKeyProperty();
		FProperty* ValueType = MapHelper.GetValueProperty();
		int32 MapNum = MapHelper.Num();
		for (int32 i = 0; i < MapNum; ++i)
		{
			TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

			JsonObject->SetStringField(TEXT("StructPath"), TEXT("MapKeyValue"));

			void* KeyPtr = MapHelper.GetKeyPtr(i);
			if (FObjectProperty* TmpProp = CastField<FObjectProperty>(KeyType))
			{
				KeyPtr = TmpProp->GetObjectPropertyValue(KeyPtr);
			}
			JsonObject->SetField(TEXT("Key"), UKGCoreEditorFunctionLibrary::ExportPropertyToJson(KeyPtr, KeyType));

			void* ValuePtr = MapHelper.GetValuePtr(i);
			if (FObjectProperty* TmpProp = CastField<FObjectProperty>(ValueType))
			{
				ValuePtr = TmpProp->GetObjectPropertyValue(ValuePtr);
			}
			JsonObject->SetField(TEXT("Value"), UKGCoreEditorFunctionLibrary::ExportPropertyToJson(ValuePtr, ValueType));

			JsonArray.Add(MakeShared<FJsonValueObject>(JsonObject));
		}

		return MakeShared<FJsonValueArray>(JsonArray);
	}
	else if (FStructProperty* StructProp = CastField<FStructProperty>(Prop))
	{
		TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

		UKGCoreEditorFunctionLibrary::ExportStructToJson(DataAddress, StructProp->Struct, JsonObject);

		return MakeShared<FJsonValueObject>(JsonObject);
	}

	return MakeShared<FJsonValueNull>();
}
#pragma endregion Json
