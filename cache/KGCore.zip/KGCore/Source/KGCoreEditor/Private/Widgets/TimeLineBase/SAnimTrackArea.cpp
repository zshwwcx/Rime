// Copyright Epic Games, Inc. All Rights Reserved.

#include "Widgets/TimeLineBase/SAnimTrackArea.h"
#include "Types/PaintArgs.h"
#include "Layout/ArrangedChildren.h"
#include "Rendering/DrawElements.h"
#include "Layout/LayoutUtils.h"
#include "Widgets/SWeakWidget.h"
#include "EditorStyleSet.h"
#include "Widgets/TimeLineBase/SAnimTrack.h"
#include "Widgets/TimeLineBase/SAnimOutliner.h"
#include "Widgets/TimeLineBase/AnimTimelineTrack.h"
#include "Widgets/TimeLineBase/TimelineController.h"
#include "Widgets/TimeLineBase/AnimTimeSliderController.h"

FAnimTrackAreaSlot::FAnimTrackAreaSlot(const TSharedPtr<SAnimTrack>& InSlotContent)
{
	TrackWidget = InSlotContent;

	HAlignment = HAlign_Fill;
	VAlignment = VAlign_Top;

	AttachWidget(
		SNew(SWeakWidget)
		.Clipping(EWidgetClipping::ClipToBounds)
		.PossiblyNullContent(InSlotContent)
	);
}

float FAnimTrackAreaSlot::GetVerticalOffset() const
{
	TSharedPtr<SAnimTrack> PinnedTrackWidget = TrackWidget.Pin();
	return PinnedTrackWidget.IsValid() ? PinnedTrackWidget->GetPhysicalPosition() : 0.f;
}

void SAnimTrackArea::Construct(const FArguments& InArgs, const TSharedRef<FTimelineController>& InTimelineController, const TSharedRef<FAnimTimeSliderController>& InTimeSliderController)
{
	WeakEditorTimelineController = InTimelineController;
	WeakTimeSliderController = InTimeSliderController;
	bSelectionEditToolEnabled = InArgs._bSelectionEditToolEnabled;
	OnMarqueeFinished = InArgs._OnMarqueeFinished;
	OnMarqueeSelecting = InArgs._OnMarqueeSelecting;
}

void SAnimTrackArea::SetOutliner(const TSharedPtr<SAnimOutliner>& InOutliner)
{
	WeakOutliner = InOutliner;
}

void SAnimTrackArea::Empty()
{
	TrackSlots.Empty();
	Children.Empty();
}

void SAnimTrackArea::AddTrackSlot(const TSharedRef<FAnimTimelineTrack>& InTrack, const TSharedPtr<SAnimTrack>& InSlot)
{
	TrackSlots.Add(InTrack, InSlot);
	Children.AddSlot(FAnimTrackAreaSlot::FSlotArguments(MakeUnique<FAnimTrackAreaSlot>(InSlot)));
}

TSharedPtr<SAnimTrack> SAnimTrackArea::FindTrackSlot(const TSharedRef<FAnimTimelineTrack>& InTrack)
{
	// Remove stale entries
	TrackSlots.Remove(TWeakPtr<FAnimTimelineTrack>());

	return TrackSlots.FindRef(InTrack).Pin();
}

void SAnimTrackArea::OnArrangeChildren(const FGeometry& AllottedGeometry, FArrangedChildren& ArrangedChildren) const
{
	struct Temp
	{
		Temp(int32 InID, EVisibility InVis, const AlignmentArrangeResult& InX, const AlignmentArrangeResult& InY) : Index(InID), Vis(InVis), XResult(InX), YResult(InY) {}

		int32 Index;
		EVisibility Vis;
		AlignmentArrangeResult XResult;
		AlignmentArrangeResult YResult;
	};

	TArray<Temp> TempMsgs;

	for (int32 ChildIndex = 0; ChildIndex < Children.Num(); ++ChildIndex)
	{
		const FAnimTrackAreaSlot& CurChild = Children[ChildIndex];

		const EVisibility ChildVisibility = CurChild.GetWidget()->GetVisibility();
		if (!ArrangedChildren.Accepts(ChildVisibility))
		{
			continue;
		}

		const FMargin Padding(0, CurChild.GetVerticalOffset(), 0, 0);

		Temp TT(ChildIndex, ChildVisibility, AlignChild<Orient_Horizontal>(AllottedGeometry.GetLocalSize().X, CurChild, Padding, 1.0f, false), AlignChild<Orient_Vertical>(AllottedGeometry.GetLocalSize().Y, CurChild, Padding, 1.0f, false));

		TempMsgs.Add(TT);
	}

	TempMsgs.Sort
	(
		[&](const Temp& A, const Temp& B)
		{
			return A.YResult.Offset < B.YResult.Offset;
		}
	);

	for (int32 i = 0; i < TempMsgs.Num(); ++i)
	{
		Temp& TT = TempMsgs[i];
		ArrangedChildren.AddWidget(TT.Vis, AllottedGeometry.MakeChild(Children[TT.Index].GetWidget(), FVector2D(TT.XResult.Offset, TT.YResult.Offset), FVector2D(TT.XResult.Size, TT.YResult.Size)));
	}
}

FVector2D SAnimTrackArea::ComputeDesiredSize( float ) const
{
	FVector2D MaxSize(0.0f, 0.0f);
	for (int32 ChildIndex = 0; ChildIndex < Children.Num(); ++ChildIndex)
	{
		const FAnimTrackAreaSlot& CurChild = Children[ChildIndex];

		const EVisibility ChildVisibilty = CurChild.GetWidget()->GetVisibility();
		if (ChildVisibilty != EVisibility::Collapsed)
		{
			FVector2D ChildDesiredSize = CurChild.GetWidget()->GetDesiredSize();
			MaxSize.X = FMath::Max(MaxSize.X, ChildDesiredSize.X);
			MaxSize.Y = FMath::Max(MaxSize.Y, ChildDesiredSize.Y);
		}
	}

	return MaxSize;
}

FChildren* SAnimTrackArea::GetChildren()
{
	return &Children;
}

void SAnimTrackArea::OnFocusLost(const FFocusEvent& InFocusEvent)
{
	SPanel::OnFocusLost(InFocusEvent);
	if (bIsSelectionEditToolWorking)
	{
		this->GetOrCreataSelectionEditTool()->RaiseOnMarqueeFinished();
		bIsSelectionEditToolWorking = false;
	}
}

int32 SAnimTrackArea::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled ) const
{
	// paint the child widgets
	FArrangedChildren ArrangedChildren(EVisibility::Visible);
	ArrangeChildren(AllottedGeometry, ArrangedChildren);

	const FPaintArgs NewArgs = Args.WithNewParent(this);

	for (int32 ChildIndex = 0; ChildIndex < ArrangedChildren.Num(); ++ChildIndex)
	{
		FArrangedWidget& CurWidget = ArrangedChildren[ChildIndex];
		FSlateRect ChildClipRect = MyCullingRect.IntersectionWith(CurWidget.Geometry.GetLayoutBoundingRect());
		const int32 ThisWidgetLayerId = CurWidget.Widget->Paint(NewArgs, CurWidget.Geometry, ChildClipRect, OutDrawElements, LayerId + 2, InWidgetStyle, bParentEnabled);

		LayerId = FMath::Max(LayerId, ThisWidgetLayerId);
	}

	if (bIsSelectionEditToolWorking)
	{
		LayerId = FMath::Max(LayerId, GetOrCreataSelectionEditTool()->OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled));
	}


	TArray<float> AllAssistLinePosXArray;
	if (WeakEditorTimelineController.IsValid())
	{
		AllAssistLinePosXArray = WeakEditorTimelineController.Pin()->GetAssistLinePosX();

		//辅助线多少个线段
		constexpr int LineCount = 30;
		//每个线段长度
		constexpr int LineLength = 15;
		//每个线段之间距离
		constexpr int LineInterval = 15;

		for (float PosX : AllAssistLinePosXArray)
		{
			for (int LineIndex = 0; LineIndex < LineCount; ++LineIndex)
			{
				TArray<FVector2f> Points;
				Points.Add(FVector2f(PosX, LineIndex * (LineLength + LineInterval)));
				Points.Add(FVector2f(PosX, LineIndex * (LineLength + LineInterval) + LineLength));

				FSlateDrawElement::MakeLines
				(
					OutDrawElements, LayerId,
					AllottedGeometry.ToPaintGeometry(), Points, ESlateDrawEffect::None, WeakEditorTimelineController.Pin()->GetAssistLineColor(), true, 1
				);
			}
		}
	}



	return LayerId;
}

void SAnimTrackArea::UpdateHoverStates( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent )
{

}

TSharedPtr<SKGAnimTimelineEditTool_Selection> SAnimTrackArea::GetOrCreataSelectionEditTool() const
{
	if (SelectionEditTool == nullptr)
	{
		SelectionEditTool = MakeShared<SKGAnimTimelineEditTool_Selection>(SharedThis(this));
	}
	return SelectionEditTool;
}

void SAnimTrackArea::UpdateAutoScrollingSpeed(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	auto GlobalPosition = MyGeometry.GetAbsolutePosition();
	auto GlobalSize = MyGeometry.GetAbsoluteSize();
	auto MouseGlobalPosition = MouseEvent.GetScreenSpacePosition();
	if (MouseGlobalPosition.X - GlobalPosition.X < 50)
	{
		AutoScrollingSpeed.X = -1;
	}
	else if (GlobalPosition.X + GlobalSize.X - MouseGlobalPosition.X < 50)
	{
		AutoScrollingSpeed.X = 1;
	}
	else
	{
		AutoScrollingSpeed.X = 0;
	}
	if (MouseGlobalPosition.Y - GlobalPosition.Y < 50)
	{
		AutoScrollingSpeed.Y = -1;
	}
	else if (GlobalPosition.Y + GlobalSize.Y - MouseGlobalPosition.Y < 50)
	{
		AutoScrollingSpeed.Y = 1;
	}
	else
	{
		AutoScrollingSpeed.Y = 0;
	}
}

FReply SAnimTrackArea::OnMouseButtonDown( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent )
{
	FReply Reply = FReply::Unhandled();
	TSharedPtr<FAnimTimeSliderController> TimeSliderController = WeakTimeSliderController.Pin();
	if(!Reply.IsEventHandled() && TimeSliderController.IsValid())
	{
		if (!MouseEvent.IsControlDown())
		{
			WeakOutliner.Pin()->ClearSelection();
			WeakEditorTimelineController.Pin()->ClearTrackSelection();
		}

		Reply = TimeSliderController->OnMouseButtonDown(*this, MyGeometry, MouseEvent);
	}

	if (!Reply.IsEventHandled() && MouseEvent.GetEffectingButton() == EKeys::LeftMouseButton)
	{
		bIsSelectionEditToolWorking = bSelectionEditToolEnabled.Get();
		if (bIsSelectionEditToolWorking)
		{
			Reply = GetOrCreataSelectionEditTool()->OnMouseButtonDown(MyGeometry, MouseEvent);
			if (!Reply.IsEventHandled())
			{
				bIsSelectionEditToolWorking = false;
			}
			else
			{
				UpdateAutoScrollingSpeed(MyGeometry, MouseEvent);
				return FReply::Handled().CaptureMouse(this->AsShared());
			}
		}
	}

	return Reply;
}

FReply SAnimTrackArea::OnMouseButtonUp( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent )
{
	FReply Reply = FReply::Unhandled();

	if (bIsSelectionEditToolWorking)
	{
		GetOrCreataSelectionEditTool()->OnMouseButtonUp(MyGeometry, MouseEvent);
		bIsSelectionEditToolWorking = false;
		return Reply.ReleaseMouseCapture();
	}

	TSharedPtr<FAnimTimeSliderController> TimeSliderController = WeakTimeSliderController.Pin();
	if(TimeSliderController.IsValid())
	{
		Reply = WeakTimeSliderController.Pin()->OnMouseButtonUp(*this, MyGeometry, MouseEvent);
	}
	
	return Reply;
}

FReply SAnimTrackArea::OnMouseMove( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent )
{
	FReply Reply = FReply::Unhandled();
	UpdateHoverStates(MyGeometry, MouseEvent);

	if (bIsSelectionEditToolWorking)
	{
		Reply = GetOrCreataSelectionEditTool()->OnMouseMove(MyGeometry, MouseEvent);
		UpdateAutoScrollingSpeed(MyGeometry, MouseEvent);
		return Reply;
	}

	TSharedPtr<FAnimTimeSliderController> TimeSliderController = WeakTimeSliderController.Pin();
	if(!Reply.IsEventHandled() && TimeSliderController.IsValid())
	{
		Reply = WeakTimeSliderController.Pin()->OnMouseMove(*this, MyGeometry, MouseEvent);

		// Handle right click scrolling on the track area
		if (Reply.IsEventHandled())
		{
			if (MouseEvent.IsMouseButtonDown(EKeys::RightMouseButton) && HasMouseCapture())
			{
				WeakOutliner.Pin()->ScrollByDelta(-MouseEvent.GetCursorDelta().Y);
			}
		}
	}

	return Reply;
}

FReply SAnimTrackArea::OnMouseWheel( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent )
{
	TSharedPtr<FAnimTimeSliderController> TimeSliderController = WeakTimeSliderController.Pin();
	if(TimeSliderController.IsValid())
	{
		FReply Reply = WeakTimeSliderController.Pin()->OnMouseWheel(*this, MyGeometry, MouseEvent);
		if (Reply.IsEventHandled())
		{
			return Reply;
		}

		const float ScrollAmount = -MouseEvent.GetWheelDelta() * GetGlobalScrollAmount();
		WeakOutliner.Pin()->ScrollByDelta(ScrollAmount);

		return FReply::Handled();
	}

	return FReply::Unhandled();
}

void SAnimTrackArea::OnMouseLeave(const FPointerEvent& MouseEvent)
{
}

FCursorReply SAnimTrackArea::OnCursorQuery( const FGeometry& MyGeometry, const FPointerEvent& CursorEvent ) const
{
	if (CursorEvent.IsMouseButtonDown(EKeys::RightMouseButton) && HasMouseCapture())
	{
		return FCursorReply::Cursor(EMouseCursor::GrabHandClosed);
	}
	else
	{
		TSharedPtr<FAnimTimeSliderController> TimeSliderController = WeakTimeSliderController.Pin();
		if(TimeSliderController.IsValid())
		{
			return TimeSliderController->OnCursorQuery(SharedThis(this), MyGeometry, CursorEvent);
		}
	}

	return FCursorReply::Unhandled();
}

void SAnimTrackArea::Tick( const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime )
{
	CachedGeometry = AllottedGeometry;

	for (int32 Index = 0; Index < Children.Num();)
	{
		if (!StaticCastSharedRef<SWeakWidget>(Children[Index].GetWidget())->ChildWidgetIsValid())
		{
			Children.RemoveAt(Index);
		}
		else
		{
			++Index;
		}
	}

	if (bIsSelectionEditToolWorking && !AutoScrollingSpeed.IsZero())
	{
		auto LocalViewRange = WeakTimeSliderController.Pin()->GetViewRange();
		double LocalViewRangeMin = LocalViewRange.GetLowerBoundValue();
		double LocalViewRangeMax = LocalViewRange.GetUpperBoundValue();
		
		float RequestX = AutoScrollingSpeed.X * InDeltaTime * (LocalViewRangeMax - LocalViewRangeMin) * 0.3;

		double NewViewOutputMin = LocalViewRangeMin + RequestX;
		double NewViewOutputMax = LocalViewRangeMax + RequestX;

		WeakTimeSliderController.Pin()->ClampViewRange(NewViewOutputMin, NewViewOutputMax);
		WeakTimeSliderController.Pin()->SetViewRange(NewViewOutputMin, NewViewOutputMax, EViewRangeInterpolation::Immediate);
		auto ActualX = WeakTimeSliderController.Pin()->ConvertInputDeltaToScreen(AllottedGeometry, RequestX);
		float RequestY = AutoScrollingSpeed.Y * InDeltaTime * 300;
		auto ActualY = WeakOutliner.Pin()->ScrollByDelta(RequestY);
		ActualX = (
			AllottedGeometry.LocalToAbsolute(FVector2D(ActualX, 0))
			-
			AllottedGeometry.LocalToAbsolute(FVector2D(0, 0))
			).X;
		// TODO: 这个Y方向的实际滚动长度，应该取决于ActualY，但是它的单位不是Slate的长度单位，是列表的滚动单位，很难算出来实际滚动长度…
		RequestY = (
			AllottedGeometry.LocalToAbsolute(FVector2D(RequestY, 0))
			-
			AllottedGeometry.LocalToAbsolute(FVector2D(0, 0))
			).X;
		GetOrCreataSelectionEditTool()->MoveVirtualArea(
			FVector2D(-ActualX, ActualY  == 0 ? 0 : -RequestY)
		);
	}
}
