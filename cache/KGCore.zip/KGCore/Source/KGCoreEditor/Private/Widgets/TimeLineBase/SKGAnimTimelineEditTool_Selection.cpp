#include "Widgets/TimeLineBase/SKGAnimTimelineEditTool_Selection.h"

#include "Widgets/TimeLineBase/SAnimTrack.h"
#include "Widgets/TimeLineBase/SAnimTrackArea.h"
#include "Rendering/DrawElementTypes.h"
#include "Styling/AppStyle.h"

SKGAnimTimelineEditTool_Selection::SKGAnimTimelineEditTool_Selection(TSharedRef<SAnimTrackArea const> InTrackArea)
	: TrackArea(InTrackArea)
{
}

FReply SKGAnimTimelineEditTool_Selection::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	StartPosition = CurrentPosition = MouseEvent.GetScreenSpacePosition();
	return FReply::Handled();
}

FReply SKGAnimTimelineEditTool_Selection::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	CurrentPosition = MouseEvent.GetScreenSpacePosition();
	RaiseOnMarqueeFinished();
	return FReply::Handled();
}

FReply SKGAnimTimelineEditTool_Selection::OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	CurrentPosition = MouseEvent.GetScreenSpacePosition();
	RaiseOnMarqueeSelecting();
	return FReply::Unhandled();
}

int32 SKGAnimTimelineEditTool_Selection::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	auto TopLeftPosition = FVector2D(FMath::Min(StartPosition.X, CurrentPosition.X), FMath::Min(StartPosition.Y, CurrentPosition.Y));
	auto BottomRightPosition = FVector2D(FMath::Max(StartPosition.X, CurrentPosition.X), FMath::Max(StartPosition.Y, CurrentPosition.Y));

	auto TopLeftLocalPosition = this->TrackArea.Pin()->GetCachedGeometry().AbsoluteToLocal(TopLeftPosition);
	auto BottomRightLocalPosition = this->TrackArea.Pin()->GetCachedGeometry().AbsoluteToLocal(BottomRightPosition);

	FSlateDrawElement::MakeBox(
		OutDrawElements,
		LayerId,
		AllottedGeometry.ToPaintGeometry(BottomRightLocalPosition - TopLeftLocalPosition, FSlateLayoutTransform(TopLeftLocalPosition)),
		FAppStyle::GetBrush(TEXT("MarqueeSelection"))
	);
	return LayerId + 1;
}

void SKGAnimTimelineEditTool_Selection::RaiseOnMarqueeFinished()
{
	auto TopLeftPosition = FVector2D(FMath::Min(StartPosition.X, CurrentPosition.X), FMath::Min(StartPosition.Y, CurrentPosition.Y));
	auto BottomRightPosition = FVector2D(FMath::Max(StartPosition.X, CurrentPosition.X), FMath::Max(StartPosition.Y, CurrentPosition.Y));

	this->TrackArea.Pin()->OnMarqueeFinished.ExecuteIfBound(TopLeftPosition, BottomRightPosition);
}

void SKGAnimTimelineEditTool_Selection::RaiseOnMarqueeSelecting()
{
	auto TopLeftPosition = FVector2D(FMath::Min(StartPosition.X, CurrentPosition.X), FMath::Min(StartPosition.Y, CurrentPosition.Y));
	auto BottomRightPosition = FVector2D(FMath::Max(StartPosition.X, CurrentPosition.X), FMath::Max(StartPosition.Y, CurrentPosition.Y));

	this->TrackArea.Pin()->OnMarqueeSelecting.ExecuteIfBound(TopLeftPosition, BottomRightPosition);
}

void SKGAnimTimelineEditTool_Selection::MoveVirtualArea(FVector2D Delta)
{
	StartPosition += Delta;
}
