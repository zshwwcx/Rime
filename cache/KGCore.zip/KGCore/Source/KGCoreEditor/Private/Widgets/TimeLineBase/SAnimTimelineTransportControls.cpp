// Copyright Epic Games, Inc. All Rights Reserved.

#include "Widgets/TimeLineBase/SAnimTimelineTransportControls.h"
#include "EditorWidgetsModule.h"
#include "Animation/DebugSkelMeshComponent.h"
#include "Animation/AnimSingleNodeInstance.h"
#include "Animation/AnimSequenceBase.h"
#include "Animation/AnimSequence.h"
#include "Modules/ModuleManager.h"
#include "Widgets/TimeLineBase/TimelineController.h"

void SAnimTimelineTransportControls::Construct(const FArguments& InArgs, const TSharedRef<FTimelineController>& InEditorTimelineController)
{
	EditorTimelineController = InEditorTimelineController;

	FEditorWidgetsModule& EditorWidgetsModule = FModuleManager::LoadModuleChecked<FEditorWidgetsModule>("EditorWidgets");

	FTransportControlArgs TransportControlArgs;
	TransportControlArgs.OnForwardPlay = FOnClicked::CreateSP(this, &SAnimTimelineTransportControls::OnClick_Forward);
	TransportControlArgs.OnForwardStep = FOnClicked::CreateSP(this, &SAnimTimelineTransportControls::OnClick_Forward_Step);
	TransportControlArgs.OnGetPlaybackMode = FOnGetPlaybackMode::CreateSP(this, &SAnimTimelineTransportControls::GetPlaybackMode);

	ChildSlot
	[
		EditorWidgetsModule.CreateTransportControl(TransportControlArgs)
	];
}

FReply SAnimTimelineTransportControls::OnClick_Forward_Step()
{
	return FReply::Handled();
}

FReply SAnimTimelineTransportControls::OnClick_Forward()
{
	return FReply::Handled();
}

EPlaybackMode::Type SAnimTimelineTransportControls::GetPlaybackMode() const
{
	return EPlaybackMode::Stopped;
}
