// Copyright 2020 T, Inc. All Rights Reserved.
#include "Widgets/SSimpleEdViewport.h"
#include "Framework/Application/SlateApplication.h"
#include "AdvancedPreviewScene.h"
#include "SViewportToolBar.h"
#include "LevelViewportActions.h"
#include "Viewports.h"

/*********************************************************/
// SSimpleEdViewport
// Viewport Widget
/*********************************************************/
void SSimpleEdViewport::Construct(const FArguments& InArgs, const FEdViewportArgs& InRequiredArgs)
{
	PreviewScenePtr = InRequiredArgs.PreviewScene;
	AssetEditorToolkitPtr = InRequiredArgs.AssetEditorToolkit;
	ViewportIndex = InRequiredArgs.ViewportIndex;

	SEditorViewport::Construct(
		SEditorViewport::FArguments()
		.IsEnabled(FSlateApplication::Get().GetNormalExecutionAttribute())
		.AddMetaData<FTagMetaData>(TEXT("ProjectC.Viewport"))
	);

	if (Client)
	{
		Client->VisibilityDelegate.BindSP(this, &SSimpleEdViewport::IsVisible);
	}

	// restore last used feature level
	auto ScenePtr = PreviewScenePtr.Pin();
	if (ScenePtr.IsValid())
	{
		UWorld* World = ScenePtr->GetWorld();
		if (World != nullptr)
		{
			World->SetFeatureLevel(GWorld->GetFeatureLevel());
		}
	}

	UEditorEngine* Editor = (UEditorEngine*)GEngine;
	PreviewFeatureLevelChangedHandle = Editor->OnPreviewFeatureLevelChanged().AddLambda([this](ERHIFeatureLevel::Type NewFeatureLevel)
		{
			auto ScenePtr = PreviewScenePtr.Pin();
			if (ScenePtr.IsValid())
			{
				UWorld* World = ScenePtr->GetWorld();
				if (World != nullptr)
				{
					World->ChangeFeatureLevel(NewFeatureLevel);
				}
			}
		});
}

TSharedRef<FEditorViewportClient> SSimpleEdViewport::MakeEditorViewportClient()
{
	// Create viewport client
	ViewportClient = MakeShareable(new FSimpleEdViewportClient(nullptr, PreviewScenePtr.Pin().Get(), SharedThis(this)));
	ViewportClient->ViewportType = LVT_Perspective;
	ViewportClient->bSetListenerPosition = false;
	ViewportClient->SetViewLocation(EditorViewportDefs::DefaultPerspectiveViewLocation);
	ViewportClient->SetViewRotation(EditorViewportDefs::DefaultPerspectiveViewRotation);

	return ViewportClient.ToSharedRef();
}

TSharedPtr<SWidget> SSimpleEdViewport::MakeViewportToolbar()
{
	return SAssignNew(ViewportToolbar, SViewportToolBar);
}

void SSimpleEdViewport::PostUndo(bool bSuccess)
{
	ViewportClient->Invalidate();
}

void SSimpleEdViewport::PostRedo(bool bSuccess)
{
	ViewportClient->Invalidate();
}

void SSimpleEdViewport::OnFocusViewportToSelection()
{
}

void SSimpleEdViewport::BindCommands()
{
	SEditorViewport::BindCommands();

	FUICommandList& CommandListRef = *CommandList;
	const FLevelViewportCommands& LevelViewportActions = FLevelViewportCommands::Get();
	CommandListRef.MapAction( 
		LevelViewportActions.ToggleGameView,
		FExecuteAction::CreateSP( this, &SSimpleEdViewport::ToggleGameView),
		FCanExecuteAction::CreateSP(this, &SSimpleEdViewport::CanToggleGameView),
		FIsActionChecked::CreateSP(this, &SSimpleEdViewport::IsInGameView));
	CommandListRef.MapAction(
		LevelViewportActions.EjectActorPilot,
		FExecuteAction::CreateSP( this, &SSimpleEdViewport::OnActorUnlock ),
		FCanExecuteAction::CreateSP( this, &SSimpleEdViewport::CanExecuteActorUnlock ));
}

UWorld* SSimpleEdViewport::GetWorld() const
{
	if (PreviewScenePtr.Pin())
	{
		return PreviewScenePtr.Pin()->GetWorld();
	}

	return nullptr;
}

TSharedPtr<SOverlay> SSimpleEdViewport::GetViewportOverlay()
{
	return ViewportOverlay;
}

void SSimpleEdViewport::ToggleGameView()
{
	if( ViewportClient->IsPerspective() )
	{
		bool bGameViewEnable = !ViewportClient->IsInGameView();

		ViewportClient->SetGameView(bGameViewEnable);
	}
}

bool SSimpleEdViewport::CanToggleGameView() const
{
	return ViewportClient->IsPerspective();
}

bool SSimpleEdViewport::IsInGameView() const
{
	return ViewportClient->IsInGameView();
}

TSharedPtr<FSimpleEdViewportClient> SSimpleEdViewport::GetSimpleViewportClient() const
{
	return StaticCastSharedPtr<FSimpleEdViewportClient>(ViewportClient);
}

void SSimpleEdViewport::OnActorUnlock()
{
	if (ViewportClient->GetLockedActor() != nullptr)
	{
		ViewportClient->SetLockedActor(nullptr);
		ViewportClient->ViewFOV = ViewportClient->FOVAngle;
	}
}

bool SSimpleEdViewport::CanExecuteActorUnlock() const
{
	return ViewportClient->GetLockedActor() != nullptr;
}

EVisibility SSimpleEdViewport::GetLockedIconVisibility() const
{
	return ViewportClient->GetLockedActor() != nullptr ? EVisibility::Visible : EVisibility::Collapsed;
}

