#include "KGCoreEditorModule.h"
#include "Core.h"
#include "Lua/LuaEnv.h"
#include "Modules/ModuleManager.h"
#include "ActorsPlacedHook/ActorsPlacedHook.h"
#include "KGLuaUtils.h"

#define LOCTEXT_NAMESPACE "FKGCoreEditorModule"

DEFINE_LOG_CATEGORY(LogKGCoreEditor);

void FKGCoreEditorModule::StartupModule()
{
	ActorsPlacedHook = MakeShared<FActorsPlacedHook>();
	ActorsPlacedHook->OnStartupModule();

	FKGLuaUtils::CreateKGLuaHandler = FKGLuaUtils::FKGLuaHandler::CreateLambda([this](lua_State*& State)
	{
        if (LuaEnv == nullptr)
		{
            LuaEnv = UEditorLuaEnv::CreateLuaEnv(nullptr);	
		}
        State = LuaEnv->GetLuaState();
	});
	
	FKGLuaUtils::DestroyKGLuaHandler = FKGLuaUtils::FKGLuaHandler::CreateLambda([this](lua_State*& State)
	{
        if (ensure(LuaEnv != nullptr && State != nullptr && LuaEnv->GetLuaState() == State))
		{
            UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
            LuaEnv = nullptr;
			State = nullptr;
		}
	});
}

void FKGCoreEditorModule::ShutdownModule()
{
	if (ActorsPlacedHook)
	{
		ActorsPlacedHook->OnShutdownModule();
		ActorsPlacedHook.Reset();
	}

	FKGLuaUtils::CreateKGLuaHandler.Unbind();
	FKGLuaUtils::DestroyKGLuaHandler.Unbind();
}

IMPLEMENT_MODULE(FKGCoreEditorModule, KGCoreEditor)

#undef LOCTEXT_NAMESPACE