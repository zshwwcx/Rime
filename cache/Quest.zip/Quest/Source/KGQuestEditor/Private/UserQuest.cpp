// Fill out your copyright notice in the Description page of Project Settings.


#include "UserQuest.h"
#include "UserQuestCondition.h"
#include "UserGroupQuest.h"
//#include "Manager/QuestManager.h"

//void UUserQuest::InitQuest(UQuest* QuestTemp, UUserQuest* Parent, UQuestManager* missionMgr)
//{
//	QuestTemplate = QuestTemp;
//	QuestManager = missionMgr;
//	ParentQuest = Parent;
//	//初始化任务状态
//	QuestStatus = EQuestStatus::EMS_None;
//	if (QuestTemplate != nullptr)
//	{
//		int Num = QuestTemplate->AcceptConditions.Num();
//		if (Num > 0)
//		{
//			for (int i = 0; i < Num; i++)
//			{
//				UQuestCondition* Condition = QuestTemplate->AcceptConditions[i];
//				if (Condition != nullptr)
//				{
//					UUserQuestCondition* UserCondition = NewObject<UUserQuestCondition>(this, Condition->InstanceClass);
//					if (UserCondition)
//					{
//						UserCondition->Init(Condition,this);
//						UserAcceptConditions.Add(UserCondition);
//					}
//				}
//			}
//		}
//
//		Num = QuestTemplate->CompleteConditions.Num();
//		if (Num > 0)
//		{
//			for (int i = 0; i < Num; i++)
//			{
//				UQuestCondition* Condition = QuestTemplate->CompleteConditions[i];
//				if (Condition != nullptr)
//				{
//					UUserQuestCondition* UserCondition = NewObject<UUserQuestCondition>(this, Condition->InstanceClass);
//					if (UserCondition)
//					{
//						UserCondition->Init(Condition,this);
//						UserCompleteConditions.Add(UserCondition);
//					}
//				}
//			}
//		}
//	}
//}
//
//UWorld* UUserQuest::GetWorld() const
//{
//	UWorld* World = NULL;
//	if (QuestManager)
//	{
//		World = QuestManager->GetWorld();
//	}
//	return World;
//}
//
//void UUserQuest::DestroyAll()
//{
//	UserAcceptConditions.Empty();
//	UserCompleteConditions.Empty();
//}
//
//UUserGroupQuest* UUserQuest::GetParentUserGroupQuest()
//{ 
//	return Cast<UUserGroupQuest>(ParentQuest); 
//}
//
//const FName UUserQuest::GetQuestId()
//{
//	if (QuestTemplate)
//	{
//		return QuestTemplate->Id;
//	}
//	return NAME_None;
//}
//
//// 获取前置个任务的ID
//const TArray<FName> UUserQuest::GetPreQuestId()
//{
//	if (QuestTemplate)
//	{
//		return QuestTemplate->PreQuestId;
//	}
//	return TArray<FName>();
//}
//
//const TArray<FName> UUserQuest::GetPostQuestId()
//{
//	if (QuestTemplate)
//	{
//		return QuestTemplate->PostQuestId;
//	}
//	return TArray<FName>();
//}
//
//void UUserQuest::StartAcceptedQuest()
//{
//	//开始监听完成条件是否满足
//	int Num = UserCompleteConditions.Num();
//	if (Num > 0)
//	{
//		for (int i = 0; i < Num; i++)
//		{
//			UserCompleteConditions[i]->StartMsgRegister();
//		}
//	}
//}
//
////主动接受任务
//bool UUserQuest::AcceptQuest()
//{
//	bool IsAccepted = false;
//
//	//开始监听接受条件是否满足
//	int Num = UserAcceptConditions.Num();
//	if (Num > 0)
//	{
//		for (int i = 0; i < Num; i++)
//		{
//			UserAcceptConditions[i]->StartMsgRegister();
//		}
//	}
//
//	if (QuestStatus >= EQuestStatus::EMS_Accepted)
//	{
//		IsAccepted = true;
//	}
//	else if (CheckAcceptCondition())
//	{
//		QuestStatus = EQuestStatus::EMS_Accepted;
//		StartAcceptedQuest();
//
//		IsAccepted = true;
//	}
//	else
//	{
//		//说明不满足条件
//		QuestStatus = EQuestStatus::EMS_Locked;
//	}
//
//	UpdateQuestStatus();
//
//	if (IsAccepted)
//	{
//		//此处可向服务器，发送接受任务协议
//		// to do...
//	}
//
//	return IsAccepted;
//}
//
////主动领取任务奖励
//bool UUserQuest::GetQuestRewards()
//{
//	if (QuestStatus >= EQuestStatus::EMS_EarnReward)
//	{
//		return true;
//	}
//
//	if (CheckCompleteCondition())
//	{
//		QuestStatus = EQuestStatus::EMS_EarnReward;
//		//此处可向服务器，发送领取任务奖励协议
//		// to do...
//		return true;
//	}
//
//	return false;
//}
//
////检查接受条件是否满足
//bool UUserQuest::CheckAcceptCondition()
//{
//	bool CanAccept = true;
//
//	int Num = UserAcceptConditions.Num();
//	if (Num > 0)
//	{
//		int ConditionCount = 0;
//		for (int i = 0; i < Num; i++)
//		{
//			if (!UserAcceptConditions[i]->IsMeetCondition())
//			{
//				CanAccept = false;
//			}
//		}
//	}
//
//
//	return CanAccept;
//}
//
////检查完成条件是否满足
//bool UUserQuest::CheckCompleteCondition()
//{
//	int Num = UserCompleteConditions.Num();
//	bool IsComplete = true;
//	if (Num > 0)
//	{
//		for (int i = 0; i < Num; i++)
//		{
//			if (!UserCompleteConditions[i]->IsMeetCondition())
//			{
//				IsComplete = false;
//			}
//		}
//
//	}
//	
//	return IsComplete;
//}

