// Fill out your copyright notice in the Description page of Project Settings.


#include "UserGroupQuest.h"
#include "UserSingleQuest.h"
//#include "Templates/QuestTemplate.h"
//#include "Manager/QuestManager.h"

//void UUserGroupQuest::InitQuest(UQuest* QuestTemp, UUserQuest* Parent, UQuestManager* missionMgr)
//{
//	Super::InitQuest(QuestTemp,Parent, missionMgr);
//	UGroupQuestTemplate* GroupQuest = Cast<UGroupQuestTemplate>(QuestTemp);
//	if (GroupQuest != nullptr)
//	{
//		int Num = GroupQuest->QuestArray.Num();
//		for (int i =0 ; i < Num; i++)
//		{
//			UQuest* Quest =  GroupQuest->QuestArray[i];
//			if (Quest != nullptr)
//			{
//				if (Quest->IsA<USingleQuest>())
//				{
//					UUserSingleQuest* UserSingleQuest = NewObject<UUserSingleQuest>(this);
//					if (UserSingleQuest == nullptr)
//					{
//						UE_LOG(LogTemp, Error, TEXT("InitQuestTemplate ,IsA<USingleQuest> Failed "));
//						continue;
//					}
//					UserSingleQuest->InitQuest(Quest,this, missionMgr);
//					UserSingleQuestArray.Add(UserSingleQuest);
//				}
//				else if (Quest->IsA<UGroupQuestTemplate>())
//				{
//
//					UUserGroupQuest* UserGroupQuest = NewObject<UUserGroupQuest>(this);
//					if (UserGroupQuest == nullptr)
//					{
//						UE_LOG(LogTemp, Error, TEXT("InitQuestTemplate, IsA<UGroupQuestTemplate> Failed "));
//						continue;
//					}
//					UserGroupQuest->InitQuest(Quest,this, missionMgr);
//
//					ChildUserGroupQuestArray.Add(UserGroupQuest);
//				}
//				else
//				{
//					UE_LOG(LogTemp,Error,TEXT("Cant found class: %s"), *Quest->GetClass()->GetName());
//				}
//			}
//		}
//
//
//	}
//}
//
//const FName UUserGroupQuest::GetGroupQuestId()
//{
//	UGroupQuestTemplate* Template = GetGroupQuestTemplate();
//	if (Template)
//	{
//		return Template->GroupQuestId;
//	}
//
//	return NAME_None;
//}
//UGroupQuestTemplate* UUserGroupQuest::GetGroupQuestTemplate()
//{
//	return Cast<UGroupQuestTemplate>(QuestTemplate);
//}
//
//UUserSingleQuest* UUserGroupQuest::GetUserSingleQuestInGroup(const FName& SingleQuestId)
//{
//	int Num = UserSingleQuestArray.Num();
//	if (Num > 0)
//	{
//		for (int i = 0; i < Num; i++)
//		{
//			//行为节点是否完成
//			if (UserSingleQuestArray[i]->GetSingleQuestId() == SingleQuestId)
//			{
//				return UserSingleQuestArray[i];
//			}
//		}
//	}
//	return nullptr;
//}
//
//UUserGroupQuest* UUserGroupQuest::GetChildUserGroupQuestInGroup(const FName& ChildGroupId)
//{
//	int Num = ChildUserGroupQuestArray.Num();
//	if (Num > 0)
//	{
//		for (int i = 0; i < Num; i++)
//		{
//			//行为节点是否完成
//			if (ChildUserGroupQuestArray[i]->GetGroupQuestId() == ChildGroupId)
//			{
//				return ChildUserGroupQuestArray[i];
//			}
//			//递归子任务组如果有
//			UUserGroupQuest* UserGroupQuest = ChildUserGroupQuestArray[i]->GetChildUserGroupQuestInGroup(ChildGroupId);
//			if (UserGroupQuest != nullptr)
//			{
//				return UserGroupQuest;
//			}
//		}
//	}
//	return nullptr;
//}
//
//bool UUserGroupQuest::CheckInChildUserGroupQuest(UGroupQuestTemplate* Template)
//{
//	int Num = ChildUserGroupQuestArray.Num();
//	for (int i = 0; i < Num; i++)
//	{
//		UUserGroupQuest* UserGroupQuest = ChildUserGroupQuestArray[i];
//		if (UserGroupQuest)
//		{
//			UGroupQuestTemplate* GroupTemp = UserGroupQuest->GetGroupQuestTemplate();
//			if (GroupTemp != nullptr 
//				&& (GroupTemp->GroupQuestId == Template->GroupQuestId || UserGroupQuest->CheckInChildUserGroupQuest(Template))
//				)
//			{
//				return true;
//			}
//		}
//	}
//	return false;
//}
//
//
//void UUserGroupQuest::DestroyAll()
//{
//	UserSingleQuestArray.Empty();
//	ChildUserGroupQuestArray.Empty();
//}
//
//
////检查任务组能否接受
//bool UUserGroupQuest::CheckAcceptCondition()
//{
//	bool ret = UUserQuest::CheckAcceptCondition();
//	
//	return ret;
//}
//
////检查完成接受条件，并更新任务组状态
//bool UUserGroupQuest::CheckCompleteCondition()
//{
//	bool ret = UUserQuest::CheckCompleteCondition();
//
//	if (ret)
//	{
//		//1. 检查当前任务组里的所有单个任务条件是否满足 ,之后考虑优化只记录最新进度的单个任务信息
//		int Num = UserSingleQuestArray.Num();
//		if (Num > 0)
//		{
//			for (int i = 0; i < Num; i++)
//			{
//				//行为节点是否完成
//				if (!UserSingleQuestArray[i]->CheckCompleteCondition())
//				{
//					ret = false;
//					return ret;
//				}
//			}
//		}
//
//		//2.检查当前任务组里的所有子任务组条件是否满足 ,之后考虑优化只记录最新进度的子任务组信息
//		Num = ChildUserGroupQuestArray.Num();
//		if (Num > 0)
//		{
//			for (int i = 0; i < Num; i++)
//			{
//				//行为节点是否完成
//				if (!ChildUserGroupQuestArray[i]->CheckCompleteCondition())
//				{
//					ret = false;
//					return ret;
//				}
//			}
//		}
//	}
//
//	return ret;
//}
//
//void UUserGroupQuest::UpdateQuestStatus()
//{
//	EQuestStatus OldQuestStatus = QuestStatus;
//	if (QuestStatus < EQuestStatus::EMS_Accepted)
//	{
//		//任务组尚未接受
//		if (CheckAcceptCondition())
//		{
//			QuestStatus = EQuestStatus::EMS_Accepted;
//		}
//	}
//	else if (QuestStatus < EQuestStatus::EMS_Complete)
//	{
//		//任务组尚未完成
//		if (CheckCompleteCondition())
//		{
//			QuestStatus = EQuestStatus::EMS_Complete;
//		}
//	}
//
//	//奖励领取状态 ，在基本类中设置
//
//	//更新当前任务列表
//	if (QuestManager && OldQuestStatus != QuestStatus)
//	{
//		QuestManager->UpdateCurQuests(this);
//	}
//}


