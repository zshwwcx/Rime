#include "KGQuestEditorModule.h"
#include "FQuestObjectivesEditor.h"
#include "Core.h"
#include "QuestEditorCommands.h"
#include "Modules/ModuleManager.h"
#include "Interfaces/IPluginManager.h"
#include "EDGraph/Util/EDClassCollect.h"
#include "EDGraph/Graph/EDGraphFactory.h"
#include "QuestTemplate.h"
#include "SourceControlHelpers.h"
#include "CustomLayout/QuestDocHelper_CustomLayout.h"
#include "CustomLayout/QuestAutoCreate_CustomLayout.h"
#include "CustomLayout/QuestDialogueID_CustomLayout.h"
#include "CustomLayout/QuestFlowChartPath_CustomLayout.h"
#include "CustomLayout/QuestItemID_CustomLayout.h"
#include "CustomLayout/QuestMonsterID_CustomLayout.h"
#include "CustomLayout/QuestNPCID_CustomLayout.h"
#include "CustomLayout/QuestSubmitID_CustomLayout.h"
#include "CustomLayout/QuestTaskCollectID_CustomLayout.h"
#include "CustomLayout/QuestOptionTextID_CustomLayout.h"
#define LOCTEXT_NAMESPACE "FKGQuestEditorModule"


DEFINE_LOG_CATEGORY(LogKGQuestEditor);

void FKGQuestEditorModule::StartupModule()
{
	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomPropertyTypeLayout("QuestDocHelper", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FQuestDocHelper_CustomLayout::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout("QuestAutoCreate", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FQuestAutoCreate_CustomLayout::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout("DialogueID", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FQuestDialogueID_CustomLayout::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout("NPCID", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FQuestNPCID_CustomLayout::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout("ItemID", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FQuestItemID_CustomLayout::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout("TaskCollectID", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FQuestTaskCollectID_CustomLayout::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout("MonsterID", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FQuestMonsterID_CustomLayout::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout("ItemSubmitID", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FQuestSubmitID_CustomLayout::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout("FlowChartPath", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FFlowChartPath_CustomLayout::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout("OptionTextID", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FQuestOptionTextID_CustomLayout::MakeInstance));
	
	FCoreDelegates::OnPostEngineInit.AddRaw(this, &FKGQuestEditorModule::OnPostEngineInit);

	EDGraphPanelNodeFactory = MakeShareable(new FEDGraphPanelNodeFactory());
	FEdGraphUtilities::RegisterVisualNodeFactory(EDGraphPanelNodeFactory);

	EDGraphPinNodeFactory = MakeShareable(new FEDGraphPinFactory());
	FEdGraphUtilities::RegisterVisualPinFactory(EDGraphPinNodeFactory);
	
	FQuestEditorCommands::Register();
}

void FKGQuestEditorModule::ShutdownModule()
{
	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.UnregisterCustomPropertyTypeLayout("QuestDocHelper");

	FCoreDelegates::OnPostEngineInit.RemoveAll(this);

	if (EDClassCollect.IsValid())
	{
		EDClassCollect->Release();
		EDClassCollect.Reset();
	}
}

void FKGQuestEditorModule::OnPostEngineInit()
{
#if 0
	UToolMenu* Menu = UToolMenus::Get()->RegisterMenu("MainFrame.MainMenu.Window");
	{
		FToolMenuSection& Section = Menu->AddSection("WindowGlobalTabSpawners");
		Section.AddMenuEntry(
			"Quest",
			LOCTEXT("QuestLabel", "Quest"),
			LOCTEXT("QuestToolTip", ""),
			FSlateIcon(FAppStyle::GetAppStyleSetName(), "Launcher.TabIcon"),
			FUIAction(FExecuteAction::CreateLambda([] {

				if (!USourceControlHelpers::IsAvailable())
				{
					FString DialogStr = "SourceControl Error! Check P4";
					FText DialogText = FText::FromString(DialogStr);
					FMessageDialog::Open(EAppMsgType::Ok, DialogText);

					return;
				}

				FString CurOwner = USourceControlHelpers::CurrentProvider();

				if (CurOwner != "Perforce")
				{
					FString DialogStr = "CurOwner Error! Check P4";
					FText DialogText = FText::FromString(DialogStr);
					FMessageDialog::Open(EAppMsgType::Ok, DialogText);
					return;
				}

			TSharedRef<FQuestObjectivesEditor> NewMissionObjectivesEditor(new FQuestObjectivesEditor());
		NewMissionObjectivesEditor->InitQuestObjectivesEditor(EToolkitMode::Standalone, nullptr);
		}), FCanExecuteAction::CreateLambda([] { return true; }))
		);
	}
#endif
	// 为了避免影响现在使用同学的入口习惯 上面旧的先不移除 下面新增汇总在C7_EDITOR
	UToolMenu* EditorMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.C7_Editor");
	{
		FToolMenuSection& Section = EditorMenu->FindOrAddSection("C7EditorWindowLayout");
		Section.AddMenuEntry(
			"Quest",
			LOCTEXT("QuestLabel", "Quest"),
			LOCTEXT("QuestToolTip", ""),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateLambda([] {

				if (!USourceControlHelpers::IsAvailable())
				{
					FString DialogStr = "SourceControl Error! Check P4";
					FText DialogText = FText::FromString(DialogStr);
					FMessageDialog::Open(EAppMsgType::Ok, DialogText);

					return;
				}

				FString CurOwner = USourceControlHelpers::CurrentProvider();

				if (CurOwner != "Perforce")
				{
					FString DialogStr = "CurOwner Error! Check P4";
					FText DialogText = FText::FromString(DialogStr);
					FMessageDialog::Open(EAppMsgType::Ok, DialogText);
					return;
				}

			TSharedRef<FQuestObjectivesEditor> NewMissionObjectivesEditor(new FQuestObjectivesEditor());
		NewMissionObjectivesEditor->InitQuestObjectivesEditor(EToolkitMode::Standalone, nullptr);
		}), FCanExecuteAction::CreateLambda([] { return true; }))
		);
	}
}

FEDClassCollect* FKGQuestEditorModule::GetEDClassCollect()
{
	if (!EDClassCollect.IsValid())
	{
		EDClassCollect = MakeShareable(new FEDClassCollect(UQuestDataBase::StaticClass()));
		EDClassCollect->AddObservedBlueprintClasses(UQuestTargetBase::StaticClass());
		EDClassCollect->AddObservedBlueprintClasses(UQuestActionBase::StaticClass());
		EDClassCollect->UpdateAvailableBlueprintClasses();
	}

	return EDClassCollect.Get();
}

IMPLEMENT_MODULE(FKGQuestEditorModule, KGQuestEditor)

#undef LOCTEXT_NAMESPACE