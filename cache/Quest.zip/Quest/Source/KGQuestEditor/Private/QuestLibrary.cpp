// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestLibrary.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "QuestTemplate.h"
#include "Engine/AssetManager.h"
//#include "Manager/ResourceManager.h"
#include "Misc/FileHelper.h"
#include "Serialization/JsonSerializer.h"
#include "JsonObjectConverter.h"
//#include "Utilities/CommonUtils.h"

static void DataReproduct(FProperty* Prop, TSharedPtr<FJsonValue>& Value);
static int StringToEQuestActionNodeType(FString TypeName, UEnum* EnumPtr);
static int StringToEQuestType(FString TypeName);
static TSharedPtr<FJsonObject> SerializeSingleQuestProperty(FPrimaryAssetId AssetID);
static TSharedPtr<FJsonObject> SerializeQuestActionNodeProperty(UQuestActionNode* ActionNode);
static TSharedPtr<FJsonObject> SerializeSingleQuestPropertyWithObject(UObject* TempObject);


static const FString FolderPath = "../../../Backend/server/bin/game/design/mission/";

void FQuestLibrary::ExportAllQuestData() {
	FPlatformFileManager::Get().Get().GetPlatformFile().DeleteDirectoryRecursively(*FolderPath);

	UAssetManager::Get().ReinitializeFromConfig();
	ExportQuestDataByType("GroupQuestTemplate", "QuestGroup");

	ExportSingleQuestNode();

	//ActionNode中需要对一些属性导出的字符串进行处理
	ExportQuestActionNode();
}

void FQuestLibrary::ExportQuestDataByType(FString QuestType, FString FileName)
{
	const FPrimaryAssetType QuestTemplateType = { FName(QuestType) };

	const FString SavePath = FolderPath + FileName + ".json";

	TArray<FPrimaryAssetId> IDList;
	bool Ret = UAssetManager::Get().GetPrimaryAssetIdList(QuestTemplateType, IDList);

	TSharedPtr<FJsonObject> AllQuestsJsonObj = MakeShared<FJsonObject>();
	if (Ret)
	{
		for (int32 i = 0; i < IDList.Num(); ++i)
		{
			FName AssetName = IDList[i].PrimaryAssetName;

			TSharedPtr<FJsonObject> SingleJsonObj = SerializeSingleQuestProperty(IDList[i]);

			AllQuestsJsonObj->SetObjectField(AssetName.ToString(), SingleJsonObj);
		}
	}
	FString OutJsonString;
	TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>> > JsonWriter = TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>::Create(
		&OutJsonString, 0);
	bool bSuccess = FJsonSerializer::Serialize(AllQuestsJsonObj.ToSharedRef(), JsonWriter);
	FFileHelper::SaveStringToFile(OutJsonString, *SavePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
}

void FQuestLibrary::ExportSingleQuestNode()
{
	////先获取所有的MisiionTemplate
	//const FPrimaryAssetType QuestTemplateType = { FName("GroupQuestTemplate") };
	//const FString SavePath = FolderPath + "QuestSingle" + ".json";
	//TArray<FPrimaryAssetId> IDList;
	//bool Ret = UAssetManager::Get().GetPrimaryAssetIdList(QuestTemplateType, IDList);
	//TSharedPtr<FJsonObject> DataEntity->AllQuestsJsonObj = MakeShared<FJsonObject>();
	//if (Ret)
	//{
	//	for (int32 i = 0; i < IDList.Num(); ++i)
	//	{
	//		FName SingleQuestId = IDList[i].PrimaryAssetName;
	//		FAssetData OutData;
	//		UAssetManager::Get().GetPrimaryAssetData(IDList[i], OutData);
	//		TArray<UQuest*> SingleQuestArray = Cast<UGroupQuestTemplate>(OutData.GetAsset())->QuestArray;
	//		for (int32 n = 0; n < SingleQuestArray.Num(); n++)
	//		{
	//			USingleQuest* TempSingleQuest = Cast<USingleQuest>(SingleQuestArray[n]);
	//			if (TempSingleQuest)
	//			{
	//				FString ActionIdStr = FString::FromInt(SingleQuestArray[n]->Id);
	//				TSharedPtr<FJsonObject> SingleJsonObj = SerializeSingleQuestPropertyWithObject(SingleQuestArray[n]);
	//				DataEntity->AllQuestsJsonObj->SetObjectField(ActionIdStr, SingleJsonObj);
	//			}
	//		}
	//	}

	//}
	//FString OutJsonString;
	//TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>> > JsonWriter = TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>::Create(
	//	&OutJsonString, 0);
	//bool bSuccess = FJsonSerializer::Serialize(DataEntity->AllQuestsJsonObj.ToSharedRef(), JsonWriter);
	//FFileHelper::SaveStringToFile(OutJsonString, *SavePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);

}

void FQuestLibrary::ExportQuestActionNode()
{
	//TArray<FString> AssetPaths;
	//AssetPaths.Add("/Game/Template/Quest");
	//// Begin loading assets
	//FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));

	//AssetRegistryModule.Get().SearchAllAssets(/*bSynchronousSearch =*/true);
	//TArray<FAssetData> AssetList;
	//FARFilter ARFilter;
	//ARFilter.ClassNames.Add("BP_SingleQuestProperty_C");
	//ARFilter.bRecursivePaths = true;

	//for (const FString& AssetPath : AssetPaths)
	//{
	//	ARFilter.PackagePaths.Push(FName(*AssetPath));
	//}

	//AssetRegistryModule.Get().GetAssets(ARFilter, AssetList);

	//TSharedPtr<FJsonObject> DataEntity->AllQuestsJsonObj = MakeShared<FJsonObject>();
	//for (FAssetData const& Asset : AssetList)
	//{
	//	TArray<UQuestActionNode*> ActionArray = Cast<USingleQuest>(Asset.GetAsset())->QuestActionNodeArray;
	//	for (int32 n = 0; n < ActionArray.Num(); n++)
	//	{
	//		FString ActionIdStr = FString::FromInt(ActionArray[n]->Id);
	//		TSharedPtr<FJsonObject> SingleJsonObj = SerializeQuestActionNodeProperty(ActionArray[n]);
	//		DataEntity->AllQuestsJsonObj->SetObjectField(ActionIdStr, SingleJsonObj);
	//	}
	//}


	///*const FPrimaryAssetType QuestTemplateType = { FName("SingleQuest") };


	//TArray<FPrimaryAssetId> IDList;
	//bool Ret = UAssetManager::Get().GetPrimaryAssetIdList(QuestTemplateType, IDList,EAssetManagerFilter::Default);

	//TSharedPtr<FJsonObject> DataEntity->AllQuestsJsonObj = MakeShared<FJsonObject>();
	//if (Ret)
	//{
	//	for (int32 i = 0; i < IDList.Num(); ++i)
	//	{
	//		FName SingleQuestId = IDList[i].PrimaryAssetName;
	//		FAssetData OutData;
	//		UAssetManager::Get().GetPrimaryAssetData(IDList[i], OutData);
	//		TArray<UQuestActionNode*> ActionArray = Cast<USingleQuest>(OutData.GetAsset())->QuestActionNodeArray;
	//		for (int32 n = 0; n < ActionArray.Num(); n++)
	//		{
	//			FString ActionIdStr = FString::FromInt(ActionArray[n]->Id);
	//			TSharedPtr<FJsonObject> SingleJsonObj = SerializeQuestActionNodeProperty(ActionArray[n]);
	//			DataEntity->AllQuestsJsonObj->SetObjectField(ActionIdStr, SingleJsonObj);
	//		}
	//	}
	//}*/

	//FString SavePath = FolderPath + "QuestActionNode.json";
	//FString OutJsonString;
	//TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>> > JsonWriter = TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>::Create(
	//	&OutJsonString, 0);
	//bool bSuccess = FJsonSerializer::Serialize(DataEntity->AllQuestsJsonObj.ToSharedRef(), JsonWriter);
	//FFileHelper::SaveStringToFile(OutJsonString, *SavePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
}

static TSharedPtr<FJsonObject> SerializeSingleQuestProperty(FPrimaryAssetId AssetID)
{
	TSharedPtr<FJsonObject> SingleJsonObj = MakeShared<FJsonObject>();

	//FAssetData OutData;
	//UAssetManager::Get().GetPrimaryAssetData(AssetID, OutData);

	//for (TFieldIterator<FProperty> PropIter(OutData.GetAsset()->GetClass()); PropIter; ++PropIter)
	//{
	//	FProperty* Prop = *PropIter;

	//	FProperty* Property = OutData.GetAsset()->GetClass()->FindPropertyByName(Prop->GetFName());
	//	if (Property)
	//	{
	//		TSharedPtr<FJsonValue> Value;
	//		if (Property->GetFName().ToString() == "QuestActionNodeArray") {
	//			TArray<UQuestActionNode*> ActionArray = Cast<USingleQuest>(OutData.GetAsset())->QuestActionNodeArray;
	//			TArray<TSharedPtr<FJsonValue>> resStr;
	//			for (int32 i = 0; i < ActionArray.Num(); ++i)
	//			{
	//				resStr.Add(MakeShareable(new FJsonValueNumber(ActionArray[i]->Id)));
	//			}
	//			Value = MakeShared<FJsonValueArray>(resStr);
	//		}
	//		if (Prop->GetFName().ToString() == "NativeClass")
	//		{
	//			FString TempString = OutData.GetAsset()->GetClass()->GetName();
	//			Value = MakeShared<FJsonValueString>(TempString);
	//		}
	//		else {
	//			void* ValuePtr = Property->ContainerPtrToValuePtr<void>(OutData.GetAsset());
	//			Value = FJsonObjectConverter::UPropertyToJsonValue(Property, ValuePtr, 0, 0);
	//			DataReproduct(Prop, Value);
	//		}
	//		SingleJsonObj.Get()->SetField(Prop->GetFName().ToString(), Value);
	//	}
	//}
	return SingleJsonObj;
}

static TSharedPtr<FJsonObject> SerializeSingleQuestPropertyWithObject(UObject* TempObject)
{
	TSharedPtr<FJsonObject> SingleJsonObj = MakeShared<FJsonObject>();

	//FAssetData OutData(TempObject);

	//for (TFieldIterator<FProperty> PropIter(OutData.GetAsset()->GetClass()); PropIter; ++PropIter)
	//{
	//	FProperty* Prop = *PropIter;

	//	FProperty* Property = OutData.GetAsset()->GetClass()->FindPropertyByName(Prop->GetFName());
	//	if (Property)
	//	{
	//		TSharedPtr<FJsonValue> Value;
	//		if (Property->GetFName().ToString() == "QuestActionNodeArray") {
	//			TArray<UQuestActionNode*> ActionArray = Cast<USingleQuest>(OutData.GetAsset())->QuestActionNodeArray;
	//			TArray<TSharedPtr<FJsonValue>> resStr;
	//			for (int32 i = 0; i < ActionArray.Num(); ++i)
	//			{
	//				resStr.Add(MakeShareable(new FJsonValueNumber(ActionArray[i]->Id)));
	//			}
	//			Value = MakeShared<FJsonValueArray>(resStr);
	//		}
	//		else {
	//			void* ValuePtr = Property->ContainerPtrToValuePtr<void>(OutData.GetAsset());
	//			Value = FJsonObjectConverter::UPropertyToJsonValue(Property, ValuePtr, 0, 0);
	//			DataReproduct(Prop, Value);
	//		}
	//		if (Prop->GetFName().ToString() == "NativeClass")
	//		{
	//			FString TempString = TempObject->GetClass()->GetName();
	//			Value = MakeShared<FJsonValueString>(TempString);
	//		}
	//		SingleJsonObj.Get()->SetField(Prop->GetFName().ToString(), Value);
	//	}
	//}
	return SingleJsonObj;
}

static TSharedPtr<FJsonObject> SerializeQuestActionNodeProperty(UQuestActionNode* ActionNode)
{
	TSharedPtr<FJsonObject> SingleJsonObj = MakeShared<FJsonObject>();
	for (TFieldIterator<FProperty> PropIter(ActionNode->GetClass()); PropIter; ++PropIter)
	{
		FProperty* Prop = *PropIter;

		FProperty* Property = ActionNode->GetClass()->FindPropertyByName(Prop->GetFName());
		if (Property)
		{
			void* ValuePtr = Property->ContainerPtrToValuePtr<void>(ActionNode);
			TSharedPtr<FJsonValue> Value = FJsonObjectConverter::UPropertyToJsonValue(Property, ValuePtr, 0, 0);
			DataReproduct(Prop, Value);
			if (Prop->GetFName().ToString() == "NativeClass")
			{
				FString TempString = ActionNode->GetClass()->GetName();
				Value = MakeShared<FJsonValueString>(TempString);
			}
			SingleJsonObj.Get()->SetField(Prop->GetFName().ToString(), Value);
		}
	}
	return SingleJsonObj;
}

//对一些属性导出的字符串进行处理
static void DataReproduct(FProperty* Prop, TSharedPtr<FJsonValue>& Value) {
	const FString PropName = Prop->GetFName().ToString();


	if (PropName == "QuestArray") {
		//QuestArray属性，只序列化各Quest的Id字段
		TArray<TSharedPtr<FJsonValue> > ValueArray = Value.Get()->AsArray();
		TArray<TSharedPtr<FJsonValue>> ResultString;
		for (int32 i = 0; i < ValueArray.Num(); ++i)
		{
			TSharedPtr<FJsonValue> QuestId = MakeShareable(new FJsonValueNumber(ValueArray[i].Get()->AsObject()->GetNumberField(StringCast<TCHAR>("id"))));
			ResultString.Add(QuestId);
		}
		Value = MakeShared<FJsonValueArray>(ResultString);
	}
	else if (PropName == "WidgetRowName") {
		//源字符串格式为 "WidgetBlueprintGeneratedClass'/Game/Blueprint/UMG/UMG_TestPanel.UMG_TestPanel_C'"
		//转换为 "/Game/Blueprint/UMG/UMG_TestPanel.UMG_TestPanel_C"
		FString ValueString = Value.Get()->AsString();
		if (ValueString == "") {
			return;
		}
		FString TempRightString;
		ValueString.Split("'", nullptr, &TempRightString);
		FString ResultString;
		TempRightString.Split("'", &ResultString, nullptr);
		Value = MakeShared<FJsonValueString>(ResultString);
	}
	else if (PropName == "ActionNodeType") {
		//将导出的EQuestActionNodeType字符串转为int值
		UEnum* EnumPtr = FindObject<UEnum>(nullptr, TEXT("EQuestActionNodeType"), true);
		int EnumIdx = StringToEQuestActionNodeType(Value.Get()->AsString(), EnumPtr);
		Value = MakeShared<FJsonValueNumber>(EnumIdx);
	}
	else if (PropName == "EventName") {
		UEnum* EnumPtr = FindObject<UEnum>(nullptr, TEXT("EQuestActionLevelEvent"), true);
		int EnumIdx = StringToEQuestActionNodeType(Value.Get()->AsString(), EnumPtr);
		Value = MakeShared<FJsonValueNumber>(EnumIdx);
	}
	else if (PropName == "AchieveQuestType") {
		UEnum* EnumPtr = FindObject<UEnum>(nullptr, TEXT("EAchieveQuestType"), true);
		int EnumIdx = StringToEQuestActionNodeType(Value.Get()->AsString(), EnumPtr);
		Value = MakeShared<FJsonValueNumber>(EnumIdx);
	}
	else if (PropName == "QuestType") {
		//将导出的EQuestType字符串转为int值
		int EnumIdx = StringToEQuestType(Value.Get()->AsString());
		Value = MakeShared<FJsonValueNumber>(EnumIdx);
	}
	//else if (PropName == "CompleteConditions") {
	//	TArray< TSharedPtr<FJsonValue> > valueArray = Value.Get()->AsArray();
	//	TArray<TSharedPtr<FJsonValue>> resStr;
	//	for (int32 i = 0; i < valueArray.Num(); ++i)
	//	{
	//		TSharedPtr<FJsonValue> QuestId = MakeShareable(new FJsonValueNumber(valueArray[i].Get()->AsObject()->GetIntegerField("dialogId")));
	//		resStr.Add(QuestId);
	//	}
	//}
}

//将导出的EQuestActionNodeType字符串转为int值
static int StringToEQuestActionNodeType(FString TypeName, UEnum* EnumPtr) {
	if (EnumPtr != nullptr)
	{
		for (int i = 0; i < EnumPtr->NumEnums(); i++)
		{
			FString EnumName = EnumPtr->GetNameStringByIndex(i);
			if (EnumName == TypeName) {
				return i;
			}
		}
	}
	return 0;
}

//将导出的EQuestType字符串转为int值
static int StringToEQuestType(FString TypeName) {
	const UEnum* EnumPtr = FindObject<UEnum>(nullptr, TEXT("EQuestType"), true);
	if (EnumPtr != nullptr)
	{
		for (int i = 0; i < EnumPtr->NumEnums(); i++)
		{
			EQuestType enumValue = (EQuestType)(EnumPtr->GetValueByIndex(i));
			FString EnumName = EnumPtr->GetNameStringByIndex(i);
			if (EnumName == TypeName) {
				return i;
			}
		}
	}
	return 0;
}


bool FQuestLibrary::QuestSaveAsset(const FString& AssetsToSave, bool bOnlyIfIsDirty)
{
	UEditorAssetSubsystem* EditorAssetSubsystem = GEditor->GetEditorSubsystem<UEditorAssetSubsystem>();
	return EditorAssetSubsystem->SaveAsset(AssetsToSave, bOnlyIfIsDirty);
}

