#include "QuestImportLua.h"

#include "EdGraphNode_Comment.h"
#include "EDGraph/Graph/EventDrivenGraphSchema.h"
#include "EDGraph/Nodes/EDGraphNode_StateNode.h"
#include "EDGraph/Nodes/EDGraphNode_Transition.h"
#include "FQuestObjectivesEditor.h"
#include "QuestObjectDataEntity.h"
#include "QuestSettings.h"
#include "AssetRegistry/AssetRegistryModule.h"

/*------------------------------------------------------------------------------------
	Statics and Globals
------------------------------------------------------------------------------------*/
TArray<TWeakObjectPtr<UClass>> FQuestImportLua::RecordedUClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImportLua::ActionClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImportLua::TargetClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImportLua::FailConditionClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImportLua::ApplyClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImportLua::RewardClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImportLua::SubmitClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImportLua::FailedFallbackClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImportLua::LeavePlaneClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImportLua::TraceParamClass;

template<typename T>
T* FQuestImportLua::CheckCastAddress(void* Address)
{
	if (T* Dest = StaticCast<T*>(Address))
	{
		return Dest;
	}
	return nullptr;
}

FString FQuestImportLua::GetPropertyDisPlayName(const FProperty* Property, bool bByStruct)
{
	FString RetVal;
	if (!bByStruct)
	{
		return Property->GetName();
	}
	else
	{
		RetVal = Property->GetName();
		int32 UnderscoreIndex = RetVal.Find(TEXT("_"));
		if (UnderscoreIndex != INDEX_NONE)
		{
			RetVal = RetVal.Left(UnderscoreIndex);
		}
	}
	return RetVal;
}

template <typename Func>
void FQuestImportLua::TraverseArray(const TSharedPtr<FJsonValue>& JsonValue, Func TraverseAction)
{
	auto Array = JsonValue->AsArray();
	const int ArrayLen = Array.Num();
	for (int Index = 0; Index < ArrayLen; ++Index)
	{
		Invoke(TraverseAction, Index, -1);
	}
}

template <typename Func>
void FQuestImportLua::TraverseTable(const TSharedPtr<FJsonValue>& JsonValue, Func TraverseAction)
{
	auto Table = JsonValue->AsObject();
	for(auto Pair : Table->Values)
	{
		Invoke(TraverseAction, Pair.Key);
	}
}
	
template<typename T>
bool FQuestImportLua::DoFill(const TSharedPtr<FJsonValue>& JsonValue, T* Address, int ParamIndex)
{
	return false;
}
	
template<>
bool FQuestImportLua::DoFill(const TSharedPtr<FJsonValue>& JsonValue, FSoftObjectPath* Address, int ParamIndex)
{
	FString Path = JsonValue->AsString();
	if (JsonValue->Type == EJson::String)
	{
		FSoftObjectPath SoftPath(*Path);
		*Address = SoftPath;
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FString>(const TSharedPtr<FJsonValue>& JsonValue, FString* Address, int ParamIndex)
{
	if (JsonValue->Type == EJson::String)
	{
		FString Result = JsonValue->AsString();
		*Address = Result;
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FName>(const TSharedPtr<FJsonValue>& JsonValue, FName* Address, int ParamIndex)
{
	if (JsonValue->Type == EJson::String)
	{
		FString Result = JsonValue->AsString();
		*Address = FName(*Result);
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FText>(const TSharedPtr<FJsonValue>& JsonValue, FText* Address, int ParamIndex)
{
	if (JsonValue->Type == EJson::String)
	{
		FString Result = JsonValue->AsString();
		*Address = FText::FromString(Result);
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<bool>(const TSharedPtr<FJsonValue>& JsonValue, bool* Address, int ParamIndex)
{
	if (JsonValue->Type == EJson::Boolean)
	{
		*Address = JsonValue->AsBool();
		return true;
	}
	return false;
}

template <typename T>
bool FQuestImportLua::FillNumber(const TSharedPtr<FJsonValue>& JsonValue, T* Address, int ParamIndex)
{
	if (JsonValue->Type == EJson::Number)
	{
		*Address = static_cast<T>(JsonValue->AsNumber());
		return true;
	}
	return false;
}


template<>
bool FQuestImportLua::DoFill<double>(const TSharedPtr<FJsonValue>& JsonValue, double* Address, int ParamIndex)
{
	return FillNumber<double>(JsonValue, Address, ParamIndex);
}

template<>
bool FQuestImportLua::DoFill<float>(const TSharedPtr<FJsonValue>& JsonValue, float* Address, int ParamIndex)
{
	return FillNumber<float>(JsonValue, Address, ParamIndex);
}

template<>
bool FQuestImportLua::DoFill<int>(const TSharedPtr<FJsonValue>& JsonValue, int* Address, int ParamIndex)
{
	return FillNumber<int>(JsonValue, Address, ParamIndex);
}

template<>
bool FQuestImportLua::DoFill<int8>(const TSharedPtr<FJsonValue>& JsonValue, int8* Address, int ParamIndex)
{
	return FillNumber<int8>(JsonValue, Address, ParamIndex);
}

template<>
bool FQuestImportLua::DoFill<int64>(const TSharedPtr<FJsonValue>& JsonValue, int64* Address, int ParamIndex)
{
	return FillNumber<int64>(JsonValue, Address, ParamIndex);
}

template<>
bool FQuestImportLua::DoFill<uint8_t>(const TSharedPtr<FJsonValue>& JsonValue, uint8_t* Address, int ParamIndex)
{
	return FillNumber<uint8_t>(JsonValue, Address, ParamIndex);
}

template<>
bool FQuestImportLua::DoFill<FVector2d>(const TSharedPtr<FJsonValue>& JsonValue, FVector2d* Address, int ParamIndex)
{
	auto JArray = JsonValue->AsArray();
	if(JArray.Num() == 2)
	{
		Address->X = JArray[0]->AsNumber();
		Address->Y = JArray[1]->AsNumber();
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FVector>(const TSharedPtr<FJsonValue>& JsonValue, FVector* Address, int ParamIndex)
{
	auto JArray = JsonValue->AsArray();
	if(JArray.Num() == 3)
	{
		Address->X = JArray[0]->AsNumber();
		Address->Y = JArray[1]->AsNumber();
		Address->Z = JArray[2]->AsNumber();
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FRotator>(const TSharedPtr<FJsonValue>& JsonValue, FRotator* Address, int ParamIndex)
{
	auto JArray = JsonValue->AsArray();
	if(JArray.Num() == 3)
	{
		Address->Pitch = JArray[0]->AsNumber();
		Address->Yaw = JArray[1]->AsNumber();
		Address->Roll = JArray[2]->AsNumber();
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FQuat>(const TSharedPtr<FJsonValue>& JsonValue, FQuat* Address, int ParamIndex)
{
	auto JArray = JsonValue->AsArray();
	if(JArray.Num() == 4)
	{
		Address->X = JArray[0]->AsNumber();
		Address->Y = JArray[1]->AsNumber();
		Address->Z = JArray[2]->AsNumber();
		Address->W = JArray[3]->AsNumber();
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FColor>(const TSharedPtr<FJsonValue>& JsonValue, FColor* Address, int ParamIndex)
{
	auto JArray = JsonValue->AsArray();
	if(JArray.Num() == 4)
	{
		Address->R = JArray[0]->AsNumber();
		Address->G = JArray[1]->AsNumber();
		Address->B = JArray[2]->AsNumber();
		Address->A = JArray[3]->AsNumber();
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FTransform>(const TSharedPtr<FJsonValue>& JsonValue, FTransform* Address, int ParamIndex)
{
	auto JArray = JsonValue->AsArray();
	if(JArray.Num() == 3)
	{
		FQuat* Rotation = nullptr;
		FVector* Translation = nullptr;
		FVector* Scale = nullptr;
		DoFill<FQuat>(JArray[0], Rotation, ParamIndex);
		DoFill<FVector>(JArray[1], Translation, ParamIndex);
		DoFill<FVector>(JArray[2], Scale, ParamIndex);
		if(!Rotation || !Translation || !Scale)
		{
			return false;
		}
		Address->SetRotation(*Rotation);
		Address->SetTranslation(*Translation);
		Address->SetScale3D(*Scale);
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FGameplayID>(const TSharedPtr<FJsonValue>& JsonValue, FGameplayID* Address, int ParamIndex)
{
	auto JNum = JsonValue->AsNumber();
	if(JNum != 0)
	{
		Address->ID = JNum;
		return true;
	}
	return false;
}

template<>
bool FQuestImportLua::DoFill<FFlowChartPath>(const TSharedPtr<FJsonValue>& JsonValue, FFlowChartPath* Address, int ParamIndex)
{
	auto JString = JsonValue->AsString();
	if(JString != "")
	{
		Address->Path = JString;
		return true;
	}
	return false;
}

template<typename T>
bool FQuestImportLua::Fill(const TSharedPtr<FJsonValue>& JsonValue, void* Address, int ParamIndex)
{
	if (T* Dest = CheckCastAddress<T>(Address))
	{
		return DoFill<T>(JsonValue, Dest, ParamIndex);
	}
	return false;
}

template<typename PropertyType>
bool FQuestImportLua::Fill(PropertyType* Property, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer)
{
	return false;
}

template <typename ClassName>
bool FQuestImportLua::InitializeClassList(const FString& BPFilePath, TMap<int32, TWeakObjectPtr<UClass>>& ClassList)
{
	if (ClassList.Num() == 0)
	{
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();
		
		FARFilter Filter;
		Filter.PackagePaths.Add(*BPFilePath);
		Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;
		
		// Get the assets
		TArray<FAssetData> AssetDataList;
		AssetRegistry.GetAssets(Filter, AssetDataList);

		for (auto Asset : AssetDataList)
		{
			UObject* Obj = Asset.GetAsset();
			UClass* Class = Obj->GetClass();
			if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
			{
				Class = BPObj->GeneratedClass;
			}
			if (!Class->IsChildOf(ClassName::StaticClass()))
			{
				continue;
			}
			ClassName* InitiateTarget = NewObject<ClassName>(GetTransientPackage(), Class);
			Class->AddToRoot();
			RecordedUClass.Add(Class);
			ClassList.Add(InitiateTarget->Type, Class);
		}
	}
	return true;
}

template<>
bool FQuestImportLua::Fill<FEnumProperty>(FEnumProperty* Property, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer)
{
	//兼容老数据
	if (JsonValue->Type == EJson::Number)
	{
		return Fill<uint8_t>(JsonValue, Address, ParamIndex);
	}

	if (JsonValue->Type == EJson::Object)
	{
		auto JObj = JsonValue->AsObject();
		if(JObj->Values.Contains("EnumName"))
		{
			FString EnumName = JObj->Values["EnumName"]->AsString();
			const UEnum* Enum = Property->GetEnum();
			int64 IntValue = Enum->GetValueByName(FName(*EnumName), EGetByNameFlags::CheckAuthoredName);
			if (IntValue != INDEX_NONE)
			{
				Property->GetUnderlyingProperty()->SetIntPropertyValue(Address, IntValue);
				return true;
			}
		}
		if(JObj->Values.Contains("EnumValue"))
		{
			bool bSuccess = Fill<uint8_t>(JObj->Values["EnumValue"], Address, ParamIndex);
			return bSuccess;
		}
	}
	return false;
}

template<>
bool FQuestImportLua::Fill<FByteProperty>(FByteProperty* Property, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer)
{
	//兼容老数据
	if (JsonValue->Type == EJson::Number)
	{
		return Fill<uint8_t>(JsonValue, Address, ParamIndex);
	}

	if (JsonValue->Type == EJson::Object)
	{
		auto JObj = JsonValue->AsObject();
		if(JObj->Values.Contains("EnumName"))
		{
			FString EnumName = JObj->Values["EnumName"]->AsString();
			const UEnum* Enum = Property->Enum;
			int64 IntValue = Enum->GetValueByName(FName(*EnumName), EGetByNameFlags::CheckAuthoredName);
			if (IntValue != INDEX_NONE)
			{
				Property->SetIntPropertyValue(Address, IntValue);
				return true;
			}
		}
		if(JObj->Values.Contains("EnumValue"))
		{
			bool bSuccess = Fill<uint8_t>(JObj->Values["EnumValue"], Address, ParamIndex);
			return bSuccess;
		}
	}
	return false;
}

template<>
bool FQuestImportLua::Fill<FStructProperty>(FStructProperty* StructProperty, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer)
{
	const FString CPPType = StructProperty->GetCPPType(nullptr, 0);
	
	if (CPPType == "FVector")
	{
		return Fill<FVector>(JsonValue, Address, ParamIndex);
	}
	if (CPPType == "FRotator")
	{
		return Fill<FRotator>(JsonValue, Address, ParamIndex);
	}
	if (CPPType == "FTransform")
	{
		return Fill<FTransform>(JsonValue, Address, ParamIndex);
	}
	if (CPPType == "FColor")
	{
		return Fill<FColor>(JsonValue, Address, ParamIndex);
	}
	// // if (StructProperty->GetCPPType() == "FBodyInstance")
	// // {
	// // 	FBodyInstance* BodyIns = StaticCast<FBodyInstance*>Address;
	// // 	return ExBodyInstance(*BodyIns);
	// // }
	if (CPPType == "FSoftObjectPath")
	{
		return Fill<FSoftObjectPath>(JsonValue, Address, ParamIndex);
	}
	
	if (const UScriptStruct* Struct = StructProperty->Struct)
	{
		UScriptStruct* FGameplayIDStruct = FindObject<UScriptStruct>(nullptr, TEXT("/Script/KGQuestEditor.GameplayID"));
		if (Struct->IsChildOf(FGameplayIDStruct))
		{
			return Fill<FGameplayID>(JsonValue, Address, ParamIndex);
		}
		UScriptStruct* FFlowChartPathStruct = FindObject<UScriptStruct>(nullptr, TEXT("/Script/KGQuestEditor.FlowChartPath"));
		if (Struct->IsChildOf(FFlowChartPathStruct))
		{
			return Fill<FFlowChartPath>(JsonValue, Address, ParamIndex);
		}
		if(JsonValue->Type != EJson::Object)
		{
			return false;
		}
		auto Jobj = JsonValue->AsObject();
		for (FProperty* Property: TFieldRange<FProperty>(Struct))
		{
			void* ValueAddress = Property->ContainerPtrToValuePtr<void>(Address);
			const FString PropertyName = GetPropertyDisPlayName(Property, true);
			if(Jobj->Values.Contains(PropertyName))
			{
				FillFProperty(Property, ValueAddress, Jobj->Values[PropertyName], -1, Outer);
			}
		}
	}
	return true;	
}

template<>
bool FQuestImportLua::Fill<FObjectProperty>(FObjectProperty* ObjProperty, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer)
{
	UObject* Object = ObjProperty->GetObjectPropertyValue(Address);
	const FString ObjPropertyName = ObjProperty->GetName();
	void* ObjectRaw = Object;
	if(JsonValue->Type != EJson::Object)
	{
		return false;
	}
	auto JObj = JsonValue->AsObject();
	if (ObjProperty->PropertyClass->IsChildOf(UPreRingInfo::StaticClass()))
	{
		const FString PropertyName = "Type";
		if(JObj->Values.Contains(PropertyName))
		{
			double TypeResult = JObj->Values[PropertyName]->AsNumber();
			switch (int Type = TypeResult)
			{
			case 0: Object = NewObject<UPreRingInfo>(Outer);
				break;
			case 1: Object = NewObject<UPreRingID>(Outer);
				break;
			case 2: Object = NewObject<UAndRelation>(Outer);
				break;
			case 3: Object = NewObject<UOrRelation>(Outer);
				break;
			default:
				break;
			}
			ObjectRaw = Object;
		}
	}
	if (!Object)
	{
		// 此处应该要走NewObject
		return false;
	}
	for (FProperty* Property: TFieldRange<FProperty>(Object->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		void* PropAddress = Property->ContainerPtrToValuePtr<void>(ObjectRaw);
		const FString PropertyName = GetPropertyDisPlayName(Property);
		if(JObj->Values.Contains(PropertyName))
		{
			FillFProperty(Property, PropAddress, JObj->Values[PropertyName], -1, Object);
		}
	}
	if (ObjProperty->PropertyClass->IsChildOf(UPreRingInfo::StaticClass()))
	{
		ObjProperty->SetObjectPropertyValue(Address, Object);
	}
	return true;
}

template<>
bool FQuestImportLua::Fill<FArrayProperty>(FArrayProperty* ArrayProperty, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer)
{
	FProperty* ElemProperty = ArrayProperty->Inner;
	if(JsonValue->Type != EJson::Array)
	{
		return false;
	}
	auto JArray = JsonValue->AsArray();
	FScriptArrayHelper Helper(ArrayProperty, Address);
	Helper.Resize(JArray.Num());

	TraverseArray(
		JsonValue,
		[&](const int Index, const int ElemIndex)
		{
			FillFProperty(ElemProperty, Helper.GetRawPtr(Index), JArray[Index], ElemIndex, Outer);
		}
	);
	return true;
}

template<>
bool FQuestImportLua::Fill<FMapProperty>(FMapProperty* MapProperty, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer)
{
	if(JsonValue->Type != EJson::Object)
	{
		return false;
	}
	auto JObj = JsonValue->AsObject();
	auto MapSize = JObj->Values.Num();
	FScriptMapHelper Helper(MapProperty, Address);
	Helper.EmptyValues(MapSize);

	TraverseTable(
		JsonValue,
		[&](const FString& Key)
		{
			const int32 MapIndex = Helper.AddDefaultValue_Invalid_NeedsRehash();
			void* KeyAddress = Helper.GetKeyPtr(MapIndex);
			void* ValueAddress = Helper.GetValuePtr(MapIndex);
			TSharedPtr<FJsonValue> TempJsonValue = MakeShareable(new FJsonValueString(Key));
			FillFProperty(MapProperty->KeyProp, KeyAddress, TempJsonValue, -1, Outer);
			FillFProperty(MapProperty->ValueProp, ValueAddress, JObj->Values[Key], -1, Outer);
		}
	);

	Helper.Rehash();
	return true;
}

template<>
bool FQuestImportLua::Fill<FSoftObjectProperty>(FSoftObjectProperty* SoftObjectProperty, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer)
{
	if (JsonValue->Type == EJson::String)
	{
		FString Path = JsonValue->AsString();
		if (FSoftObjectProperty::TCppType* SoftPtr = CheckCastAddress<FSoftObjectProperty::TCppType>(Address))
		{
			FSoftObjectPath SoftPath(*Path);
			*SoftPtr = SoftPath;
			return true;
		}
	}
	return false;
}

bool FQuestImportLua::FillFProperty(FProperty* Property, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer)
{
	if (!JsonValue.IsValid())
	{
		return false;
	}
	if (FStrProperty* StrProperty = CastField<FStrProperty>(Property))
	{
		return Fill<FString>(JsonValue, Address, ParamIndex);
	}
	if (FNameProperty* NameProperty = CastField<FNameProperty>(Property))
	{
		return Fill<FName>(JsonValue, Address, ParamIndex);
	}
	if (FTextProperty* TextProperty = CastField<FTextProperty>(Property))
	{
		return Fill<FText>(JsonValue, Address, ParamIndex);
	}
	if (FBoolProperty* BoolProperty = CastField<FBoolProperty>(Property))
	{
		return Fill<bool>(JsonValue, Address, ParamIndex);
	}
	if (FFloatProperty* FloatProperty = CastField<FFloatProperty>(Property))
	{
		return Fill<float>(JsonValue, Address, ParamIndex);
	}
	if (FDoubleProperty* DoubleProperty = CastField<FDoubleProperty>(Property))
	{
		return Fill<double>(JsonValue, Address, ParamIndex);
	}
	if (FIntProperty* IntProperty = CastField<FIntProperty>(Property))
	{
		return Fill<int>(JsonValue, Address, ParamIndex);
	}
	if (FInt64Property* IntProperty = CastField<FInt64Property>(Property))
	{
		return Fill<int64>(JsonValue, Address, ParamIndex);
	}
	if (FUInt32Property* IntProperty = CastField<FUInt32Property>(Property))
	{
		return Fill<uint32>(JsonValue, Address, ParamIndex);
	}
	if (FEnumProperty* EnumProperty = CastField<FEnumProperty>(Property))
	{
		// return Fill<uint8_t>(L, Address, ParamIndex);
		return Fill<FEnumProperty>(EnumProperty, Address, JsonValue, ParamIndex, Outer);
	}
	if (Property->IsA<FByteProperty>())
	{
		if (FByteProperty* ByteP = CastField<FByteProperty>(Property))
		{
			// if (ByteP->Enum)
			// {
			// 	return Fill<int8>(L, Address, ParamIndex);
			// }
			return Fill<FByteProperty>(ByteP, Address, JsonValue, ParamIndex, Outer);
		}
	}
	else if (FObjectProperty* ObjProperty = CastField<FObjectProperty>(Property))
	{
		return Fill<FObjectProperty>(ObjProperty, Address, JsonValue, ParamIndex, Outer);
	}
	else if (FStructProperty* StructProperty = CastField<FStructProperty>(Property))
	{
		return Fill<FStructProperty>(StructProperty, Address, JsonValue, ParamIndex, Outer);
	}
	else if (FSoftObjectProperty* SoftObjProperty = CastField<FSoftObjectProperty>(Property))
	{
		return Fill<FSoftObjectProperty>(SoftObjProperty, Address, JsonValue, ParamIndex, Outer);
	}
	else if (FArrayProperty* ArrayProperty = CastField<FArrayProperty>(Property))
	{
		return Fill<FArrayProperty>(ArrayProperty, Address, JsonValue, ParamIndex, Outer);
	}
	else if (FMapProperty* MapProperty = CastField<FMapProperty>(Property))
	{
		return Fill<FMapProperty>(MapProperty, Address, JsonValue, ParamIndex, Outer);
	}

	return false;
}

UObject* FQuestImportLua::GetActionInstanceFromEvent(int32 Event, UObject* Outer)
{
	if (ActionClass.Num() == 0)
	{
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

		FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestAction");
		FString NewBPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestActions");
		
		FARFilter Filter;
		Filter.PackagePaths.Add(*BPFilePath);
		Filter.PackagePaths.Add(*NewBPFilePath);
		Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;
		
		// Get the assets
		TArray<FAssetData> AssetDataList;
		AssetRegistry.GetAssets(Filter, AssetDataList);

		for (auto Asset : AssetDataList)
		{
			UObject* Obj = Asset.GetAsset();
			UClass* Class = Obj->GetClass();
			if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
			{
				Class = BPObj->GeneratedClass;
			}
			if (!Class->IsChildOf(UQuestActionBase::StaticClass()))
			{
				continue;
			}
			UQuestActionBase* QuestAction = NewObject<UQuestActionBase>(Outer, Class);
			Class->AddToRoot();
			RecordedUClass.Add(Class);
			ActionClass.Add(QuestAction->Event, Class);
		}
	}

	if (ActionClass.Contains(Event))
	{
		UClass* Class = ActionClass[Event].Get();
		return NewObject<UQuestActionBase>(Outer, Class);
	}
	return nullptr;
}

int32 FQuestImportLua::ProcessTargetType(UQuestTargetBase* InQuestTarget)
{
	// 5和15有两种Target资产, 这里做成-5和-15
	if (InQuestTarget->Type == 5)
	{
		FProperty* MapID = InQuestTarget->GetClass()->FindPropertyByName("MapID");
		if (MapID)
			return -InQuestTarget->Type;
	}
	if (InQuestTarget->Type == 15)
	{
		FProperty* MapID = InQuestTarget->GetClass()->FindPropertyByName("MapID");
		if (MapID)
			return -InQuestTarget->Type;
	}
	return InQuestTarget->Type;
}

void FQuestImportLua::ClearRecordedUClass()
{
	for(auto RecordedTarget : RecordedUClass)
	{
		if(RecordedTarget.IsValid())
		{
			RecordedTarget->RemoveFromRoot();
		}
	}
	RecordedUClass.Empty();
	ActionClass.Empty();
	TargetClass.Empty();
	FailConditionClass.Empty();
	ApplyClass.Empty();
	SubmitClass.Empty();
	FailedFallbackClass.Empty();
	LeavePlaneClass.Empty();
}

TArray<TSharedPtr<FJsonValue>> FQuestImportLua::GetQuestDataArrayInRingJObj(const TSharedPtr<FJsonObject>& RingJObj)
{
	if (RingJObj.IsValid())
	{
		if (RingJObj->HasField(TEXT("QuestData")))
		{
			const TArray<TSharedPtr<FJsonValue>>* QuestDataArray = nullptr;
			if (RingJObj->TryGetArrayField(TEXT("QuestData"), QuestDataArray))
			{
				return *QuestDataArray;
			}
		}
	}
	return {};
}

TSharedPtr<FJsonObject> FQuestImportLua::GetQuestDataObjectInRingJObj(const TSharedPtr<FJsonObject>& RingJObj)
{
	if (RingJObj.IsValid())
	{
		if (RingJObj->HasField(TEXT("QuestData")))
		{
			const TSharedPtr<FJsonObject>* QuestDataObject;
			if (RingJObj->TryGetObjectField(TEXT("QuestData"), QuestDataObject))
			{
				return *QuestDataObject;
			}
		}
	}
	return nullptr;
}

UObject* FQuestImportLua::GetTargetInstanceFromEvent(int32 Type, UObject* Outer)
{
	if (TargetClass.Num() == 0)
	{
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

		FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestTarget");
		FString NewBPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestTargets");
		
		FARFilter Filter;
		Filter.PackagePaths.Add(*BPFilePath);
		Filter.PackagePaths.Add(*NewBPFilePath);
		Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;

		// Get the assets
		TArray<FAssetData> AssetDataList;
		AssetRegistry.GetAssets(Filter, AssetDataList);

		for (auto Asset : AssetDataList)
		{
			UObject* Obj = Asset.GetAsset();
			UClass* Class = Obj->GetClass();
			if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
			{
				Class = BPObj->GeneratedClass;
			}
			if (!Class->IsChildOf(UQuestTargetBase::StaticClass()))
			{
				continue;
			}
			UQuestTargetBase* QuestTarget = NewObject<UQuestTargetBase>(Outer, Class);
			int32 ProcessedType = ProcessTargetType(QuestTarget);
			Class->AddToRoot();
			RecordedUClass.Add(Class);
			TargetClass.Add(ProcessedType, Class);
		}
	}

	if (TargetClass.Contains(Type))
	{
		UClass* Class = TargetClass[Type].Get();
		return NewObject<UQuestTargetBase>(Outer, Class);
	}
	return nullptr;
}

UObject* FQuestImportLua::GetApplyInstanceFromType(int32 Type, UObject* Outer)
{
	FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/ReceiveType");
	InitializeClassList<UApplyBase>(BPFilePath, ApplyClass);
	if (ApplyClass.Contains(Type))
	{
		UClass* Class = ApplyClass[Type].Get();
		return NewObject<UApplyBase>(Outer, Class);
	}
	return nullptr;
}

UObject* FQuestImportLua::GetRewardInstanceFromType(int32 Type, UObject* Outer)
{
	FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/RewardType");
	InitializeClassList<URewardBase>(BPFilePath, RewardClass);
	if (RewardClass.Contains(Type))
	{
		UClass* Class = RewardClass[Type].Get();
		return NewObject<URewardBase>(Outer, Class);
	}
	return nullptr;
}

UObject* FQuestImportLua::GetSubmitInstanceFromType(int32 Type, UObject* Outer)
{
	FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/SubmitType");
	InitializeClassList<USubmitBase>(BPFilePath, SubmitClass);
	if (SubmitClass.Contains(Type))
	{
		UClass* Class = SubmitClass[Type].Get();
		return NewObject<USubmitBase>(Outer, Class);
	}
	return nullptr;
}

UObject* FQuestImportLua::GetFailedFallbackInstanceFromType(int32 Type, UObject* Outer)
{
	FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/FailedFallback");
	InitializeClassList<UFailedFallbackBase>(BPFilePath, FailedFallbackClass);
	if (FailedFallbackClass.Contains(Type))
	{
		UClass* Class = FailedFallbackClass[Type].Get();
		return NewObject<UFailedFallbackBase>(Outer, Class);
	}
	return nullptr;
}

UObject* FQuestImportLua::GetLeavePlaneInstanceFromType(int32 Type, UObject* Outer)
{
	FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/LeavePlaneType");
	InitializeClassList<ULeavePlaneBase>(BPFilePath, LeavePlaneClass);
	if (LeavePlaneClass.Contains(Type))
	{
		UClass* Class = LeavePlaneClass[Type].Get();
		return NewObject<ULeavePlaneBase>(Outer, Class);
	}
	return nullptr;
}

UObject* FQuestImportLua::GetTraceParamInstanceFromType(int32 Type, UObject* Outer)
{
	FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestTrace");
	InitializeClassList<UTaskTargetTrace>(BPFilePath, TraceParamClass);
	if (TraceParamClass.Contains(Type))
	{
		UClass* Class = TraceParamClass[Type].Get();
		return NewObject<UTaskTargetTrace>(Outer, Class);
	}
	return nullptr;
}

UObject* FQuestImportLua::GetFailConditionInstanceFromEvent(int32 Event, UObject* Outer)
{
	if (FailConditionClass.Num() == 0)
	{
		FString BPFilePath = FPaths::ConvertRelativePathToFull(FPaths::EngineDir() / TEXT("../Client/Content/Editor/QuestEditor/TemplatePart/FailCondition"));
		TArray<FString> Files;
		IFileManager::Get().FindFiles(Files, *BPFilePath, TEXT("*.uasset"));

		for (const FString& File : Files)
		{
			FString FileName = FPaths::GetBaseFilename(File, true);
			FString AssetPath = FPaths::Combine(TEXT("/Game/Editor/QuestEditor/TemplatePart/FailCondition"), FileName);
			AssetPath = AssetPath + TEXT(".") + FileName;
			FSoftObjectPath AssetRef(AssetPath);
			UObject* Obj = AssetRef.ResolveObject();
			if (Obj == nullptr)
			{
				Obj = AssetRef.TryLoad();
			}
			UClass* Class = Obj->GetClass();
			if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
			{
				Class = BPObj->GeneratedClass;
			}
		
			UQuestEndConditionBase* FailCondition = NewObject<UQuestEndConditionBase>(Outer, Class);
			Class->AddToRoot();
			RecordedUClass.Add(Class);
			FailConditionClass.Add(FailCondition->Type, Class);
		}	
	}

	if (FailConditionClass.Contains(Event))
	{
		UClass* Class = FailConditionClass[Event].Get();
		return NewObject<UQuestEndConditionBase>(Outer, Class);
	}
	return nullptr;
}

bool FQuestImportLua::FillObjWithLuaStr(UObject* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
 	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}
	
	for (FProperty* Property : TFieldRange<FProperty>(InObj->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(InObj);
		const FString PropertyName = GetPropertyDisPlayName(Property, false);
		if(JsonObject->Values.Contains(PropertyName))
		{
			FillFProperty(Property, PropertyAddress, JsonObject->Values[PropertyName], -1, InObj);
		}
	}
	return true;
}

bool FQuestImportLua::FillTypedObjPropertyWithLuaStr(UObject* &InObj, const TSharedPtr<FJsonValue>& JsonValue, FString Field, FTypeGetter TypeGetter, UObject* Outer)
{
	if(JsonValue.IsValid() && JsonValue->Type != EJson::Object)
	{
		return false;
	}
	auto JObj = JsonValue->AsObject();
	if(!JObj->Values.Contains("Type"))
	{
		return false;
	}
	double TypeResult = JObj->Values["Type"]->AsNumber();
	
	// 真正创建Object
	UObject* Obj = TypeGetter(TypeResult, Outer);
	if(!Obj)
	{
		return false;
	}
	for (FProperty* Property : TFieldRange<FProperty>(Obj->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(Obj);
		const FString PropertyName = GetPropertyDisPlayName(Property, false);
		if(JObj->Values.Contains(PropertyName))
		{
			FillFProperty(Property, PropertyAddress, JObj->Values[PropertyName], -1, Obj);
		}
	}
	InObj = Obj;
	return true;
}

bool FQuestImportLua::FillTypedObjArrayWithLuaStr(TArray<UObject*> &InObj, const TSharedPtr<FJsonValue>& JsonValue, FString Field, FTypeGetter TypeGetter, UObject* Outer)
{
	TArray<UObject*> ObjArray;
	if(JsonValue->Type != EJson::Array)
	{
		return false;
	}
	auto JArray = JsonValue->AsArray();
	const int ArrayLen = JArray.Num();
	for (int Index = 0; Index < ArrayLen; ++Index)
	{
		auto JValue = JArray[Index];
		if(JValue->Type != EJson::Object)
		{
			continue;
		}
		auto ArrayObj = JValue->AsObject();
		if(!ArrayObj->Values.Contains("Event"))
		{
			continue;
		}
		double TypeResult = ArrayObj->Values["Event"]->AsNumber();

		// 真正创建Obj并写入数据
		UObject* Obj = TypeGetter(TypeResult, Outer);
		if(!Obj)
		{
			continue;
		}
		for (FProperty* Property : TFieldRange<FProperty>(Obj->GetClass(), EFieldIteratorFlags::IncludeSuper))
		{
			void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(Obj);
			const FString PropertyName = GetPropertyDisPlayName(Property, false);
			if(ArrayObj->Values.Contains(PropertyName))
			{
				FillFProperty(Property, PropertyAddress, ArrayObj->Values[PropertyName], -1, Obj);
			}
		}
		ObjArray.Add(Obj);
	}
	InObj = ObjArray;
	return true;
}

bool FQuestImportLua::FillObjWithLuaStr(UQuestChapter* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}
	
	for (FProperty* Property : TFieldRange<FProperty>(InObj->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		if(Property->GetName() == "NativeClass")
		{
			continue;
		}
		void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(InObj);
		const FString PropertyName = GetPropertyDisPlayName(Property, false);
		if(JsonObject->Values.Contains(PropertyName))
		{
			FillFProperty(Property, PropertyAddress, JsonObject->Values[PropertyName], -1, InObj);
		}
	}
	return true;
}

bool FQuestImportLua::FillObjWithLuaStr(UQuestRing* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}

	// 数据以EditorOnly为准
	auto EditorOnlyObject = JsonObject->GetObjectField(TEXT("EditorOnly"));
	
	for (FProperty* Property : TFieldRange<FProperty>(InObj->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		if(Property->GetName() == "NativeClass")
		{
			continue;
		}
		void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(InObj);
		const FString PropertyName = GetPropertyDisPlayName(Property, false);
		if(EditorOnlyObject->Values.Contains(PropertyName))
		{
			FillFProperty(Property, PropertyAddress, EditorOnlyObject->Values[PropertyName], -1, InObj);
		}
	}
	return true;
}

bool FQuestImportLua::FillObjWithLuaStr(UQuest* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}
	
	// 数据以EditorOnly为准
	auto EditorOnlyObject = JsonObject->GetObjectField(TEXT("EditorOnly"));

	// 普通属性的反序列化
	for (FProperty* Property : TFieldRange<FProperty>(InObj->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		if(Property->GetName() == "NativeClass")
		{
			continue;
		}
		void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(InObj);
		const FString PropertyName = GetPropertyDisPlayName(Property, false);
		if(EditorOnlyObject->Values.Contains(PropertyName))
		{
			FillFProperty(Property, PropertyAddress, EditorOnlyObject->Values[PropertyName], -1, InObj);
		}
	}
	return true;
}

void FQuestImportLua::FillGraphCommentNode(UEDGraphBase* GraphBase, const TSharedPtr<FJsonObject>& JsonObject)
{
	const TArray<TSharedPtr<FJsonValue>>* CommentNodeArray = nullptr;
	if (JsonObject->TryGetArrayField(TEXT("CommentNode"), CommentNodeArray))
	{
		for (const auto& CommentNodeJValue : *CommentNodeArray)
		{
			auto CommentNodeObj = CommentNodeJValue->AsObject();
			if (CommentNodeObj.IsValid())
			{
				// 创建ChapterComment节点
				if (GraphBase)
				{
					int32 NodePosX = CommentNodeObj->GetIntegerField(TEXT("NodePosX"));
					int32 NodePosY = CommentNodeObj->GetIntegerField(TEXT("NodePosY"));
					int32 NodeWidth = CommentNodeObj->GetIntegerField(TEXT("NodeWidth"));
					int32 NodeHeight = CommentNodeObj->GetIntegerField(TEXT("NodeHeight"));
					FString NodeComment = CommentNodeObj->GetStringField(TEXT("NodeComment"));

					UEdGraphNode_Comment* GraphNode_Comment = NewObject<UEdGraphNode_Comment>(GraphBase);
					GraphNode_Comment->NodePosX = NodePosX;
					GraphNode_Comment->NodePosY = NodePosY;
					GraphNode_Comment->NodeWidth = NodeWidth;
					GraphNode_Comment->NodeHeight = NodeHeight;
					GraphNode_Comment->NodeComment = NodeComment;
					GraphBase->AddNode(GraphNode_Comment);
					GraphNode_Comment->bCanRenameNode = true;
				}
			}
		}
	}
}

bool FQuestImportLua::FillChapterGraphWithLuaStr(UQuestChapter* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj || !InObj->ChapterGraph)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}
	
	// 数据以EditorOnly为准
	auto EditorOnlyObject = JsonObject->GetObjectField(TEXT("EditorOnly"));

	// ChapterGraph的反序列化
	// 1. 处理Ring节点
	const TArray<TSharedPtr<FJsonValue>>* RingNodeArray = nullptr;
	if (EditorOnlyObject->TryGetArrayField(TEXT("RingNode"), RingNodeArray))
	{
		for (const auto& RingNodeJValue : *RingNodeArray)
		{
			auto RingNode = RingNodeJValue->AsObject();
			if (RingNode.IsValid())
			{
				double RingIDResult;
				RingIDResult = RingNode->GetNumberField(TEXT("RingID"));
				double PosXResult;
				PosXResult = RingNode->GetNumberField(TEXT("PosX"));
				double PosYResult;
				PosYResult = RingNode->GetNumberField(TEXT("PosY"));
				// 创建Ring节点
				if (UEDGraphBase* ChapterGraphBase = Cast<UEDGraphBase>(InObj->ChapterGraph))
				{
					auto CurEditor = ChapterGraphBase->QuestObjectivesEditor;
					if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
					{
						if (UQuestRing* TargetRing = QuestEditor->GetRingObjByRingID(RingIDResult))
						{
							const UEdGraphSchema* Schema = InObj->ChapterGraph->GetSchema();
							if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
							{
								FVector2D NewPlacePos = FVector2D(PosXResult, PosYResult);
								ThisSchema->CreateRingNode(ChapterGraphBase, TargetRing, NewPlacePos, true);
							}
						}
					}
				}
			}
		}
	}

	// 2. 处理End节点
	const TArray<TSharedPtr<FJsonValue>>* EndNodeArray = nullptr;
	if (EditorOnlyObject->TryGetArrayField(TEXT("EndNode"), EndNodeArray))
	{
		for (const auto& EndNodeJValue : *EndNodeArray)
		{
			auto EndNodeObj = EndNodeJValue->AsObject();
			if (EndNodeObj.IsValid())
			{
				double RingIDResult;
				RingIDResult = EndNodeObj->GetNumberField(TEXT("NextRingID"));
				FString DescResult;
				DescResult = EndNodeObj->GetStringField(TEXT("Desc"));
				double PosXResult;
				PosXResult = EndNodeObj->GetNumberField(TEXT("PoxX"));
				double PosYResult;
				PosYResult = EndNodeObj->GetNumberField(TEXT("PosY"));
			
				// 创建ChapterEnd节点
				if (UEDGraphBase* ChapterGraphBase = Cast<UEDGraphBase>(InObj->ChapterGraph))
				{
					auto CurEditor = ChapterGraphBase->QuestObjectivesEditor;
					if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
					{
						UChapterEnd* EndTarget = NewObject<UChapterEnd>(InObj);
						EndTarget->NextRingID = RingIDResult;
						EndTarget->Desc = DescResult;
						QuestEditor->GetDataEntity()->ChapterEnds.Add(EndTarget);
						if (EndTarget)
						{
							const UEdGraphSchema* Schema = InObj->ChapterGraph->GetSchema();
							if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
							{
								FVector2D NewPlacePos = FVector2D(PosXResult, PosYResult);
								ThisSchema->CreateChapterEndNode(ChapterGraphBase, EndTarget, NewPlacePos, true);
							}
						}
					}
				}
			}
		}
	}

	// 3. 处理Comment节点
	if (UEDGraphBase* ChapterGraphBase = Cast<UEDGraphBase>(InObj->ChapterGraph))
	{
		FillGraphCommentNode(ChapterGraphBase, EditorOnlyObject);
	}

	// 4. 处理Ring节点的连线
	if (UEDGraphBase* ChapterGraphBase = Cast<UEDGraphBase>(InObj->ChapterGraph))
	{
		auto CurEditor = ChapterGraphBase->QuestObjectivesEditor;
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
		{
			for(auto Child : InObj->Children)
			{
				if(auto RingChild = Cast<UQuestRing>(Child))
				{
					auto TempTaskInfoList = RingChild->NextTaskInfoList;
					for(auto NextTaskInfo : TempTaskInfoList)
					{
						if (!NextTaskInfo)
						{
							UE_LOG(LogTemp, Warning, TEXT("NextTaskInfo is null. RingID: %d"), RingChild->RingID);
							continue;
						}
						int NextTaskID = NextTaskInfo->NextTaskID;
						UQuestObject* NextTask = QuestEditor->GetRingObjByRingID(NextTaskID);
						if(!NextTask)
						{
							continue;
						}
						if(NextTask->Father.Get())
						{
							UObject* ToQuest = nullptr;
							bool bNextIsEnd = false;
							if(NextTask->Father == InObj)
							{
								ToQuest = NextTask;
							}
							else
							{
								bNextIsEnd = true;
							}
							UEDGraphNode_StateNodeBase* FromNode = nullptr;
							UEDGraphNode_StateNodeBase* ToNode = nullptr;
							int FromRingIDResult = RingChild->RingID;
							UQuestRing* FromQuest = QuestEditor->GetRingObjByRingID(FromRingIDResult);
							if (FromQuest)
							{
								for (TObjectPtr<class UEdGraphNode>& GraphNode : InObj->ChapterGraph->Nodes)
								{
									if (!GraphNode)
										continue;
									if (UEDGraphNode_StateNodeBase* QuestStateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
									{
										if(bNextIsEnd)
										{
											if(auto ChapterEnd = Cast<UChapterEnd>(QuestStateNode->NodeInstance))
											{
												if(ChapterEnd->NextRingID == NextTask->QuestObjectID)
												{
													ToNode = QuestStateNode;
												}
											}
										}
										if(QuestStateNode->NodeInstance == FromQuest)
										{
											FromNode = QuestStateNode;
										}
										else if(QuestStateNode->NodeInstance == ToQuest)
										{
											ToNode = QuestStateNode;
										}
										if (FromNode != nullptr && ToNode != nullptr)
											break;
									}
								}	
								const UEdGraphSchema* Schema = InObj->ChapterGraph->GetSchema();
								if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
								{
									if(!FromNode || !ToNode)
									{
										continue;
									}
									// 连线
									ThisSchema->TryCreateConnection(FromNode->GetOutputPin(), ToNode->GetInputPin());
								}
							}
						}
					}
				}
			}
		}
	}
	return true;
}

bool FQuestImportLua::FillRingGraphWithLuaStr(UQuestRing* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj || !InObj->RingGraph)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}
	// 数据以EditorOnly为准
	auto EditorOnlyObject = JsonObject->GetObjectField(TEXT("EditorOnly"));
	
	// RingGraph的反序列化
	// 1. 处理Quest节点'
	const TArray<TSharedPtr<FJsonValue>>* QuestNodeArray = nullptr;
	if (EditorOnlyObject->TryGetArrayField(TEXT("QuestNode"), QuestNodeArray))
	{
		for (const auto& QuestNodeJValue : *QuestNodeArray)
		{
			auto QuestNodeObj = QuestNodeJValue->AsObject();
			if (QuestNodeObj.IsValid())
			{
				int32 QuestIDResult = QuestNodeObj->GetIntegerField(TEXT("QuestID"));
				double PosXResult = QuestNodeObj->GetNumberField(TEXT("PosX"));
				double PosYResult = QuestNodeObj->GetNumberField(TEXT("PosY"));
			
				// 创建Quest节点
				if (UEDGraphBase* RingGraphBase = Cast<UEDGraphBase>(InObj->RingGraph))
				{
					auto CurEditor = RingGraphBase->QuestObjectivesEditor;
					if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
					{
						UQuest* TargetQuest = QuestEditor->GetQuestObjByQuestID(QuestIDResult);
						if (TargetQuest)
						{
							QuestEditor->LoadQuestGraph(TargetQuest);
							const UEdGraphSchema* Schema = InObj->RingGraph->GetSchema();
							if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
							{
								FVector2D NewPlacePos = FVector2D(PosXResult, PosYResult);
								ThisSchema->CreateQuestNode(RingGraphBase, TargetQuest, NewPlacePos, true);
							}	
						}
					}
				}
			}
		}
	}

	// 2. 处理Quest节点的连线
	const TArray<TSharedPtr<FJsonValue>>* QuestConnectionArray = nullptr;
	if (EditorOnlyObject->TryGetArrayField(TEXT("QuestConnection"), QuestConnectionArray))
	{
		for (const auto& QuestConnectionJValue : *QuestConnectionArray)
		{
			auto QuestConnectionObj = QuestConnectionJValue->AsObject();
			if (QuestConnectionObj.IsValid())
			{
				double FromQuestIDResult = QuestConnectionObj->GetNumberField(TEXT("FromQuestID"));
				double ToQuestIDResult = QuestConnectionObj->GetNumberField(TEXT("ToQuestID"));
			
				// 根据连线信息连接Quest节点
				if (UEDGraphBase* RingGraphBase = Cast<UEDGraphBase>(InObj->RingGraph))
				{
					UEDGraphNode_StateNodeBase* FromNode = nullptr;
					UEDGraphNode_StateNodeBase* ToNode = nullptr;
					auto CurEditor = RingGraphBase->QuestObjectivesEditor;
					if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
					{
						UQuest* FromQuest = QuestEditor->GetQuestObjByQuestID(FromQuestIDResult);
						UQuest* ToQuest = QuestEditor->GetQuestObjByQuestID(ToQuestIDResult);
						if (FromQuest && ToQuest)
						{
							for (TObjectPtr<class UEdGraphNode>& GraphNode : InObj->RingGraph->Nodes)
							{
								if (!GraphNode)
									continue;
								if (UEDGraphNode_StateNodeBase* QuestStateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
								{
									if(QuestStateNode->NodeInstance == FromQuest)
									{
										FromNode = QuestStateNode;
									}
									else if(QuestStateNode->NodeInstance == ToQuest)
									{
										ToNode = QuestStateNode;
									}
									if (FromNode != nullptr && ToNode != nullptr)
										break;
								}
							}
							const UEdGraphSchema* Schema = InObj->RingGraph->GetSchema();
							if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
							{
								if(!FromNode || !ToNode)
								{
									continue;
								}
								// 连线
								ThisSchema->TryCreateConnection(FromNode->GetOutputPin(), ToNode->GetInputPin());
							}	
						}
					}
				}
			}
		}
	}

	// 3. 处理Comment节点
	if (UEDGraphBase* GraphBase = Cast<UEDGraphBase>(InObj->RingGraph))
	{
		FillGraphCommentNode(GraphBase, EditorOnlyObject);
	}
	return true;
}

bool FQuestImportLua::FillQuestGraphWithLuaStr(UQuest* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj || !InObj->QuestGraph)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}
	
	// 数据以EditorOnly为准
	auto EditorOnlyObject = JsonObject->GetObjectField(TEXT("EditorOnly"));
	
	// QuestGraph的反序列化
	// 1. 处理Target节点
	TArray<UQuestTargetBase*> TargetNodeList;
	const TArray<TSharedPtr<FJsonValue>>* QuestTargets = nullptr;
	if (EditorOnlyObject->TryGetArrayField(TEXT("Condition"), QuestTargets))
	{
		for (const auto& ConditionJValue : *QuestTargets)
		{
			auto Condition = ConditionJValue->AsObject();
			if (Condition.IsValid())
			{
				double TypeResult = Condition->GetNumberField(TEXT("Type"));
				double PosXResult = Condition->GetNumberField(TEXT("PosX"));
				double PosYResult = Condition->GetNumberField(TEXT("PosY"));
				const TArray<TSharedPtr<FJsonValue>>* Args = nullptr;
				if (Condition->TryGetArrayField(TEXT("args"), Args))
				{
					if (Args->Num())
					{
						// 真正创建Target并写入数据
						auto ConditionArg = (*Args)[0]->AsObject();
						// 特殊处理5和15
						if (TypeResult == 5 || TypeResult == 15)
						{
							if(ConditionArg->HasField(TEXT("MapID")))
							{
								TypeResult = -TypeResult;
							}
						}
				
						UQuestTargetBase* LoadedTarget = Cast<UQuestTargetBase>(GetTargetInstanceFromEvent(TypeResult, InObj));
						if(!LoadedTarget)
						{
							continue;
						}
						for (FProperty* Property : TFieldRange<FProperty>(LoadedTarget->GetClass(), EFieldIteratorFlags::IncludeSuper))
						{
							void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(LoadedTarget);
							const FString PropertyName = GetPropertyDisPlayName(Property, false);
							if(ConditionArg->Values.Contains(PropertyName))
							{
								FillFProperty(Property, PropertyAddress, ConditionArg->Values[PropertyName], -1, LoadedTarget);
							}
						}

						//处理UniqueID
						double UniqueIDResult = ConditionArg->GetNumberField(TEXT("UniqueID"));
						LoadedTarget->UniqueID = UniqueIDResult;

						if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(InObj->QuestGraph))
						{
							UEDGraphNode_StateNodeBase* ProgressNode = nullptr;
							for (TObjectPtr<class UEdGraphNode>& GraphNode : InObj->QuestGraph->Nodes)
							{
								if (!GraphNode)
									continue;
								if (UEDGraphNode_StateNodeBase* ActionStateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
								{
									if (ActionStateNode->NodeType == EDNodeType::QuestProgress)
									{
										ProgressNode = ActionStateNode;
										break;
									}
								}
							}

							if (ProgressNode != nullptr)
							{
								const UEdGraphSchema* Schema = InObj->QuestGraph->GetSchema();
								if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
								{
									FVector2D NewPlacePos = FVector2D(PosXResult, PosYResult);
									ThisSchema->CreateQuestTargetNode(QuestGraphBase, LoadedTarget, ProgressNode->GetOutputPin(), NewPlacePos);
								}	
							}
						}

						TargetNodeList.Add(LoadedTarget);
					}
				}
			}
		}
	}
	InObj->QuestTargets = TargetNodeList;
	
	// 2. 处理FailCondition
	UObject* FailCondition = nullptr;
	auto FailConditionObj = EditorOnlyObject->Values["FailConditions"];
	FillTypedObjPropertyWithLuaStr(FailCondition, FailConditionObj, "FailConditions", GetFailConditionInstanceFromEvent, InObj);
	if(auto FailedconditionBase = Cast<UQuestEndConditionBase>(FailCondition))
	{
		InObj->FailConditions = FailedconditionBase;
	}
	
	// 2-2. 处理bIsAnd（任务目标与或关系）
	bool bIsAnd = false;
	if (EditorOnlyObject->HasField(TEXT("bIsAnd")))
	{
		bIsAnd = EditorOnlyObject->GetBoolField(TEXT("bIsAnd"));
	}
	if (InObj->Progress)
		InObj->Progress->bIsAnd = bIsAnd;

	TArray<UQuestActionBase*> BeginAction;
	TArray<UQuestActionBase*> EndAction;
	// 3. 处理Action节点
	TMap<FString, UQuestActionBase*> ActionMap;
	/* 待处理旧QuestGraph相关代码
	lua_getfield(L, -1, "TriggerOn");
	RestoreLuaStackGuard PopTriggerOnGuard(L);
	if (!lua_istable(L, -1))
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: LuaStr Field EditorOnly-TriggerOn is not a table"), ANSI_TO_TCHAR(__FUNCTION__));
		PopTriggerOnGuard.Finish();
		PopQuestGuard.Finish();
		PopObjGuard.Finish();
		return false;
	}
	const int TriggerOnArrayLen = GetLuaTableArrayPartLen(L, -1);
	if (TriggerOnArrayLen <= 0)
	{
		// 没有Action节点, 这种情况是存在的, 不再需要往下处理
		PopTriggerOnGuard.Finish();
		PopQuestGuard.Finish();
		PopObjGuard.Finish();
		return true;
	}
	for (int Index = 1; Index <= TriggerOnArrayLen; ++Index)
	{
		lua_pushnumber(L, Index);
		lua_gettable(L, -2);  
		RestoreLuaStackGuard PopElemGuard(L);
		if (!lua_isnil(L, -1))
		{
			lua_getfield(L, -1, "Type");
			RestoreLuaStackGuard PopTypeElemGuard(L);
			double TypeResult;
			if (!GetValueOnLuaStack(TypeResult, L, -1))
			{
				PopTypeElemGuard.Finish();
				PopElemGuard.Finish();
				continue;
			}
			PopTypeElemGuard.Finish();

			lua_getfield(L, -1, "Event");
			RestoreLuaStackGuard PopEventElemGuard(L);
			double EventResult;
			if (!GetValueOnLuaStack(EventResult, L, -1))
			{
				PopEventElemGuard.Finish();
				PopElemGuard.Finish();
				continue;
			}
			PopEventElemGuard.Finish();
			
			lua_getfield(L, -1, "PosX");
			RestoreLuaStackGuard PopPosXElemGuard(L);
			double PosXResult;
			if (!GetValueOnLuaStack(PosXResult, L, -1))
			{
				PopPosXElemGuard.Finish();
				PopElemGuard.Finish();
				continue;
			}
			PopPosXElemGuard.Finish();

			lua_getfield(L, -1, "PosY");
			RestoreLuaStackGuard PopPosYElemGuard(L);
			double PosYResult;
			if (!GetValueOnLuaStack(PosYResult, L, -1))
			{
				PopPosYElemGuard.Finish();
				PopElemGuard.Finish();
				continue;
			}
			PopPosYElemGuard.Finish();

			lua_getfield(L, -1, "bAutoStart");
			RestoreLuaStackGuard PopAutoStartElemGuard(L);
			double bAutoStart;
			if (!GetValueOnLuaStack(bAutoStart, L, -1))
			{
				PopAutoStartElemGuard.Finish();
				PopElemGuard.Finish();
				continue;
			}
			PopAutoStartElemGuard.Finish();

			// 这个稍微特殊点, ParentIdx只有Target下的Action有
			lua_getfield(L, -1, "ParentIdx");
			RestoreLuaStackGuard PopParentIdxElemGuard(L);
			double ParentIdx = 0;
			GetValueOnLuaStack(ParentIdx, L, -1);
			if (ParentIdx > TargetNodeList.Num() || (TypeResult == 6 && ParentIdx <= 0))
			{
				PopParentIdxElemGuard.Finish();
				PopElemGuard.Finish();
				continue;
			}
			PopParentIdxElemGuard.Finish();

			lua_getfield(L, -1, "UniqueID");
			RestoreLuaStackGuard PopUniqueIDElemGuard(L);
			FString UniqueIDResult;
			if (!GetValueOnLuaStack(UniqueIDResult, L, -1))
			{
				PopUniqueIDElemGuard.Finish();
				PopElemGuard.Finish();
				continue;
			}
			PopUniqueIDElemGuard.Finish();

			bool bBegin = true;
			// 真正创建Action并写入数据
			UQuestActionBase* LoadedAction = Cast<UQuestActionBase>(GetActionInstanceFromEvent(EventResult));
			if(!LoadedAction)
			{
				PopElemGuard.Finish();
				continue;
			}
			for (FProperty* Property : TFieldRange<FProperty>(LoadedAction->GetClass(), EFieldIteratorFlags::IncludeSuper))
			{
				void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(LoadedAction);
				const FString PropertyName = GetPropertyDisPlayName(Property, false);
				lua_getfield(L, -1, TCHAR_TO_UTF8(*PropertyName));
				RestoreLuaStackGuard PopPropertyGuard(L);
				FillFProperty(Property, PropertyAddress, L, -1, LoadedAction);
				PopPropertyGuard.Finish();
			}

			if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(InObj->QuestGraph))
			{
				UEdGraphPin* FromPin = nullptr;
				if (bAutoStart > 0)
				{
					for (TObjectPtr<class UEdGraphNode>& GraphNode : InObj->QuestGraph->Nodes)
					{
						if (!GraphNode)
							continue;
						if (UEDGraphNode_EntryNode* ActionStateNode = Cast<UEDGraphNode_EntryNode>(GraphNode))
						{
							if (TypeResult == 1 && ActionStateNode->NodeType == EDNodeType::QuestBegin)
							{
								FromPin = ActionStateNode->GetOutputPin();
								break;
							}
						}
						if (UEDGraphNode_StateNodeBase* ActionStateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
						{
							if(TypeResult == 6 && ActionStateNode->NodeInstance == TargetNodeList[ParentIdx - 1])
							{
								FromPin = ActionStateNode->GetOutputPin();
								break;
							}
							if(TypeResult == 3 && ActionStateNode->NodeType == EDNodeType::QuestEnd)
							{
								FromPin = ActionStateNode->FindPin(TEXT("Out"));
								bBegin = false;
								break;
							}
							if(TypeResult == 5 && ActionStateNode->NodeType == EDNodeType::QuestEnd)
							{
								FromPin = ActionStateNode->FindPin(TEXT("Out2"));
								bBegin = false;
								break;
							}
						}
					}	
				}
				const UEdGraphSchema* Schema = InObj->QuestGraph->GetSchema();
				if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
				{
					FVector2D NewPlacePos = FVector2D(PosXResult, PosYResult);
					if (FromPin)
						ThisSchema->CreateActionNode(QuestGraphBase, LoadedAction, FromPin, NewPlacePos);
					else
						ThisSchema->CreateActionNode(QuestGraphBase, LoadedAction, nullptr, NewPlacePos);
				}	
			}
			if(bBegin)
			{
				BeginAction.Add(LoadedAction);
			}else
			{
				EndAction.Add(LoadedAction);
			}
			ActionMap.Add(UniqueIDResult, LoadedAction);
		}
		PopElemGuard.Finish();
	}
	PopTriggerOnGuard.Finish();
	InObj->BeginActions = BeginAction;
	InObj->EndActions = EndAction;
	// 4. 处理子Action节点的连线
	lua_getfield(L, -1, "ActionConnection");
	RestoreLuaStackGuard PopActionConnectionGuard(L);
	if (!lua_istable(L, -1))
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: LuaStr Field EditorOnly-ActionConnection is not a table"), ANSI_TO_TCHAR(__FUNCTION__));
		PopActionConnectionGuard.Finish();
		PopQuestGuard.Finish();
		PopObjGuard.Finish();
		return false;
	}
	const int ActionConnectionArrayLen = GetLuaTableArrayPartLen(L, -1);
	if (ActionConnectionArrayLen <= 0)
	{
		// 没有子Action节点连线信息, 这种情况是存在的, 不再需要往下处理
		PopActionConnectionGuard.Finish();
		PopQuestGuard.Finish();
		PopObjGuard.Finish();
		return true;
	}
	for (int Index = 1; Index <= ActionConnectionArrayLen; ++Index)
	{
		lua_pushnumber(L, Index);
		lua_gettable(L, -2);  
		RestoreLuaStackGuard PopElemGuard(L);
		if (!lua_isnil(L, -1))
		{
			lua_getfield(L, -1, "FromUniqueID");
			RestoreLuaStackGuard PopFromUniqueIDElemGuard(L);
			FString FromUniqueIDResult;
			if (!GetValueOnLuaStack(FromUniqueIDResult, L, -1))
			{
				PopFromUniqueIDElemGuard.Finish();
				PopElemGuard.Finish();
				continue;
			}
			PopFromUniqueIDElemGuard.Finish();

			lua_getfield(L, -1, "ToUniqueID");
			RestoreLuaStackGuard PopToUniqueIDElemGuard(L);
			FString ToUniqueIDResult;
			if (!GetValueOnLuaStack(ToUniqueIDResult, L, -1))
			{
				PopToUniqueIDElemGuard.Finish();
				PopElemGuard.Finish();
				continue;
			}
			PopToUniqueIDElemGuard.Finish();
			
			// 根据连线信息连接Action节点
			if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(InObj->QuestGraph))
			{
				UEDGraphNode_StateNodeBase* FromNode = nullptr;
				UEDGraphNode_StateNodeBase* ToNode = nullptr;
				for (TObjectPtr<class UEdGraphNode>& GraphNode : InObj->QuestGraph->Nodes)
				{
					if (!GraphNode)
						continue;
					if (UEDGraphNode_StateNodeBase* ActionStateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
					{
						if(ActionStateNode->NodeInstance == ActionMap[FromUniqueIDResult])
						{
							FromNode = ActionStateNode;
						}
						else if(ActionStateNode->NodeInstance == ActionMap[ToUniqueIDResult])
						{
							ToNode = ActionStateNode;
						}
						if (FromNode != nullptr && ToNode != nullptr)
							break;
					}
				}	
				const UEdGraphSchema* Schema = InObj->QuestGraph->GetSchema();
				if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
				{
					// 连线
					ThisSchema->TryCreateConnection(FromNode->GetOutputPin(), ToNode->GetInputPin());
					// 连线上的条件
					lua_getfield(L, -1, "OrConditions");
					RestoreLuaStackGuard PopOrConditionsElemGuard(L);
					TArray<UEDGraphNode_Base*> LinkToNodes;
					TArray<UEDGraphNode_Base*> LinkFromNodes;
					FromNode->GetOutputTransitionNodes(LinkFromNodes, UEDGraphNode_Transition::StaticClass());
					ToNode->GetInputTransitionNodes(LinkToNodes, UEDGraphNode_Transition::StaticClass());
					TArray<UEDGraphNode_Base*> CommonNodes;
					for (auto& LinkToNode : LinkToNodes)
					{
						if (LinkFromNodes.Contains(LinkToNode))
						{
							CommonNodes.AddUnique(LinkToNode);
						}
					}
					if (CommonNodes.Num() > 0)
					{
						if (UEDGraphNode_Transition* EdgeNode = Cast<UEDGraphNode_Transition>(CommonNodes[0]))
						{
							UQuestActionConditionBase* TransitionCondition = EdgeNode->TransitionCondition;
							for (FProperty* Property : TFieldRange<FProperty>(TransitionCondition->GetClass(), EFieldIteratorFlags::IncludeSuper))
							{
								void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(TransitionCondition);
								const FString PropertyName = GetPropertyDisPlayName(Property, false);
								lua_getfield(L, -1, TCHAR_TO_UTF8(*PropertyName));
								RestoreLuaStackGuard PopPropertyGuard(L);
								FillFProperty(Property, PropertyAddress, L, -1, TransitionCondition);
								PopPropertyGuard.Finish();
							}	
						}	
					}
					PopOrConditionsElemGuard.Finish();
				}	
			}
		}
		PopElemGuard.Finish();
	}
	PopActionConnectionGuard.Finish();
	
	PopQuestGuard.Finish();

	PopObjGuard.Finish();
	
	const int32 FinalNum = lua_gettop(L);
	if (NumParams != FinalNum)
	{
		UE_LOG(LogTemp, Warning, TEXT("[QuestLOG] Lua Stack Unbalanced In FillQuestGraphWithLuaStr!!!"));
	}
	*/
	return true;
}

bool FQuestImportLua::FillRingDataArrayWithLuaStr(UQuestRing* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}

	// 数据以EditorOnly为准
	auto EditorOnlyObject = JsonObject->GetObjectField(TEXT("EditorOnly"));
	
	// RingData的反序列化
	// 1. 处理Apply Type
	UObject* OutData = nullptr;
	auto ApplyTypeObj = EditorOnlyObject->TryGetField(TEXT("ApplyType"));
	FillTypedObjPropertyWithLuaStr(OutData, ApplyTypeObj, "ApplyType", GetApplyInstanceFromType, InObj);
	if(auto ApplyType = Cast<UApplyBase>(OutData))
	{
		InObj->ApplyType = ApplyType;
	}

	// 2. 处理Submit Type
	auto SubmitTypeObj = EditorOnlyObject->TryGetField(TEXT("SubmitType"));
	FillTypedObjPropertyWithLuaStr(OutData, SubmitTypeObj, "SubmitType", GetSubmitInstanceFromType, InObj);
	if(auto SubmitType = Cast<USubmitBase>(OutData))
	{
		InObj->SubmitType = SubmitType;
	}

	TArray<UObject*> OutDataArray;

	return true;
}

bool FQuestImportLua::FillQuestDataArrayWithLuaStr(UQuest* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}

	// 数据以EditorOnly为准
	auto EditorOnlyObject = JsonObject->GetObjectField(TEXT("EditorOnly"));
	
	// QuestData的反序列化
	// 1. 处理Target节点
	TArray<UQuestTargetBase*> TargetNodeList;
	const TArray<TSharedPtr<FJsonValue>>* QuestTargets = nullptr;
	if (EditorOnlyObject->TryGetArrayField(TEXT("QuestTargets"), QuestTargets))
	{
		for (const auto& TargetJValue : *QuestTargets)
		{
			auto TargetObj = TargetJValue->AsObject();
			if (TargetObj.IsValid())
			{
				double TypeResult = TargetObj->GetNumberField(TEXT("Type"));

				// 真正创建Target并写入数据
				// 特殊处理5和15
				if (TypeResult == 5 || TypeResult == 15)
				{
					if (TargetObj->HasField(TEXT("MapID")))
					{
						TypeResult = -TypeResult;
					}
				}

				double TraceType = 0;
				auto TraceParam = TargetObj->GetObjectField(TEXT("TraceParam"));
				if (TraceParam.IsValid())
				{
					if (TraceParam->HasField(TEXT("Type")))
					{
						TraceType = TraceParam->GetNumberField(TEXT("Type"));
					}
				}
			
				UQuestTargetBase* LoadedTarget = Cast<UQuestTargetBase>(GetTargetInstanceFromEvent(TypeResult, InObj));
				if(!LoadedTarget)
				{
					continue;
				}
				LoadedTarget->TraceParam = Cast<UTaskTargetTrace>(GetTraceParamInstanceFromType(TraceType, LoadedTarget));
				for (FProperty* Property : TFieldRange<FProperty>(LoadedTarget->GetClass(), EFieldIteratorFlags::IncludeSuper))
				{
					void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(LoadedTarget);
					const FString PropertyName = GetPropertyDisPlayName(Property, false);
					if(TargetObj->Values.Contains(PropertyName))
					{
						FillFProperty(Property, PropertyAddress, TargetObj->Values[PropertyName], -1, LoadedTarget);
					}
				}
				TargetNodeList.Add(LoadedTarget);
			}
		}
	}
	InObj->QuestTargets = TargetNodeList;

	// 6. 处理Failed Fallback Type
	UObject* OutData = nullptr;
	auto FailedFallbackType = EditorOnlyObject->TryGetField(TEXT("FailedFallbackType"));
	FillTypedObjPropertyWithLuaStr(OutData, FailedFallbackType, "FailedFallbackType", GetFailedFallbackInstanceFromType, InObj);
	if(auto FailedFallback = Cast<UFailedFallbackBase>(OutData))
	{
		InObj->FailedFallbackType = FailedFallback;
	}
	
	// 7. 处理Leave plane Type
	auto LeavePlaneAction = EditorOnlyObject->TryGetField(TEXT("LeavePlaneAction"));
	FillTypedObjPropertyWithLuaStr(OutData, LeavePlaneAction, "LeavePlaneAction", GetLeavePlaneInstanceFromType, InObj);
	if(auto LeavePlaneType = Cast<ULeavePlaneBase>(OutData))
	{
		InObj->LeavePlaneAction = LeavePlaneType;
	}
	
	// 8. 处理Trace param
	TArray<FQuestTraceItem> TraceItems;
	const TArray<TSharedPtr<FJsonValue>>* MainTargetTraceComboArray = nullptr;
	if (EditorOnlyObject->TryGetArrayField(TEXT("MainTargetTraceCombo"), MainTargetTraceComboArray))
	{
		for (int Index = 0; Index < MainTargetTraceComboArray->Num(); ++Index)
		{
			auto MainTargetTrace = (*MainTargetTraceComboArray)[Index]->AsObject();
			if (MainTargetTrace.IsValid() && MainTargetTrace->Values.Contains("TraceParam"))
			{
				FillTypedObjPropertyWithLuaStr(OutData, MainTargetTrace->Values["TraceParam"], "TraceParam", GetTraceParamInstanceFromType, InObj);
				if(auto TraceParam = Cast<UTaskTargetTrace>(OutData))
				{
					InObj->MainTargetTraceCombo[Index].TraceParam = TraceParam;
				}
			}
		}
	}
	return true;
}

bool FQuestImportLua::FillQuestNextTaskWithLuaStr(UQuest* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}
	
	// 数据以EditorOnly为准
	auto EditorOnlyObject = JsonObject->GetObjectField(TEXT("EditorOnly"));

	// 这里只考虑NextTaskInfoList
	InObj->NextTaskInfoList.Empty();
	if (class UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
	{
		FSoftObjectPath SoftPath = QuestSettings->RingConditionClass;
		if (SoftPath.IsValid())
		{
			UObject* Obj = SoftPath.ResolveObject();
			if (Obj == nullptr)
			{
				Obj = SoftPath.TryLoad();
			}
			if (Obj)
			{
				UClass* Class = Obj->GetClass();
				if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
				{
					Class = BPObj->GeneratedClass;
				}

				const TArray<TSharedPtr<FJsonValue>>* NextTaskInfoList = nullptr;
				if (EditorOnlyObject->TryGetArrayField(TEXT("NextTaskInfoList"), NextTaskInfoList))
				{
					for (const auto& NextTaskInfoJValue : *NextTaskInfoList)
					{
						URingTaskConditionBase* _RingTaskConditionObj = NewObject<URingTaskConditionBase>(InObj, Class);
						auto NextTaskInfo = NextTaskInfoJValue->AsObject();
						if (NextTaskInfo.IsValid())
						{
							double NextTaskIDResult = NextTaskInfo->GetNumberField(TEXT("NextTaskID"));
							_RingTaskConditionObj->NextTaskID = NextTaskIDResult;

							const TArray<TSharedPtr<FJsonValue>>* OrConditions = nullptr;
							if (NextTaskInfo->TryGetArrayField(TEXT("OrConditions"), OrConditions))
							{
								if (OrConditions->Num() <= 0)
								{
									// 没有OrConditions信息, 这种情况是存在的, 不再需要往下处理
									InObj->NextTaskInfoList.AddUnique(_RingTaskConditionObj);
									continue;
								}
								for (const auto& OrConditionObjsValue : *OrConditions)
								{
									auto OrConditionObjs = OrConditionObjsValue->AsObject();
									if (OrConditionObjs.IsValid())
									{
										const TArray<TSharedPtr<FJsonValue>>* AndConditions = nullptr;
										FRingTaskAndConditions OrCondition;
										if (OrConditionObjs->TryGetArrayField(TEXT("AndConditions"), AndConditions))
										{
											for (const auto& AndConditionJValue : *AndConditions)
											{
												auto AndConditionObj = AndConditionJValue->AsObject();
												if (AndConditionObj.IsValid())
												{
													double VariableResult = AndConditionObj->GetNumberField(TEXT("Variable"));
													double CompareTypeResult = AndConditionObj->GetNumberField(TEXT("CompareType"));
													double ValueResult = AndConditionObj->GetNumberField(TEXT("Value"));
													FString KeyResult = AndConditionObj->GetStringField(TEXT("Key"));
													URingTaskConditionClass* AndCondition = NewObject<URingTaskConditionClass>(InObj);
													AndCondition->Variable = static_cast<ERingTaskConditionType>(VariableResult);
													AndCondition->CompareType = static_cast<ERingTaskCompareType>(CompareTypeResult);
													AndCondition->Value = ValueResult;
													AndCondition->Key = KeyResult;
													AndCondition->FlowChartPath.Path = KeyResult;
													OrCondition.AndConditions.Add(AndCondition);
												}
											}
										}
										_RingTaskConditionObj->OrConditions.Add(OrCondition);
										if (OrCondition.AndConditions.Num() > 0)
										{
											_RingTaskConditionObj->TaskCondition = OrCondition.AndConditions[0];
										}
									}
								}
							}

							const TSharedPtr<FJsonObject>* TaskConditionObject;
							if (NextTaskInfo->TryGetObjectField(TEXT("TaskCondition"), TaskConditionObject))
							{
								auto TaskConditionObj = *TaskConditionObject;
								if (TaskConditionObj.IsValid() && !TaskConditionObj->Values.IsEmpty())
								{
									double VariableResult = TaskConditionObj->GetNumberField(TEXT("Variable"));
									double CompareTypeResult = TaskConditionObj->GetNumberField(TEXT("CompareType"));
									double ValueResult = TaskConditionObj->GetNumberField(TEXT("Value"));
									FString KeyResult = TaskConditionObj->GetStringField(TEXT("Key"));
									URingTaskConditionClass* TaskCondition = NewObject<URingTaskConditionClass>(InObj);
									TaskCondition->Variable = static_cast<ERingTaskConditionType>(VariableResult);
									TaskCondition->CompareType = static_cast<ERingTaskCompareType>(CompareTypeResult);
									TaskCondition->Value = ValueResult;
									TaskCondition->Key = KeyResult;
									TaskCondition->FlowChartPath.Path = KeyResult;
									_RingTaskConditionObj->TaskCondition = TaskCondition;
								}
							}
						}
						InObj->NextTaskInfoList.AddUnique(_RingTaskConditionObj);
					}
				}
			}
		}
	}
	return true;
}

bool FQuestImportLua::FillRingNextTaskWithLuaStr(UQuestRing* InObj, const TSharedPtr<FJsonObject>& JsonObject)
{
	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return false;
	}
	
	// 数据以EditorOnly为准
	auto EditorOnlyObject = JsonObject->GetObjectField(TEXT("EditorOnly"));
	
	// 这里只考虑NextTaskInfoList
	InObj->NextTaskInfoList.Empty();
	if (class UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
	{
		FSoftObjectPath SoftPath = QuestSettings->RingConditionClass;
		if (SoftPath.IsValid())
		{
			UObject* Obj = SoftPath.ResolveObject();
			if (Obj == nullptr)
			{
				Obj = SoftPath.TryLoad();
			}
			if (Obj)
			{
				UClass* Class = Obj->GetClass();
				if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
				{
					Class = BPObj->GeneratedClass;
				}

				const TArray<TSharedPtr<FJsonValue>>* NextTaskInfoList = nullptr;
				if (EditorOnlyObject->TryGetArrayField(TEXT("NextTaskInfoList"), NextTaskInfoList))
				{
					for (const auto& NextTaskInfoJValue : *NextTaskInfoList)
					{
						URingTaskConditionBase* _RingTaskConditionObj = NewObject<URingTaskConditionBase>(InObj, Class);
						auto NextTaskInfo = NextTaskInfoJValue->AsObject();
						if (NextTaskInfo.IsValid())
						{
							double NextTaskIDResult = NextTaskInfo->GetNumberField(TEXT("NextTaskID"));
							_RingTaskConditionObj->NextTaskID = NextTaskIDResult;

							const TArray<TSharedPtr<FJsonValue>>* OrConditions = nullptr;
							if (NextTaskInfo->TryGetArrayField(TEXT("OrConditions"), OrConditions))
							{
								if (OrConditions->Num() <= 0)
								{
									// 没有OrConditions信息, 这种情况是存在的, 不再需要往下处理
									InObj->NextTaskInfoList.AddUnique(_RingTaskConditionObj);
									continue;
								}
								for (const auto& OrConditionObjsValue : *OrConditions)
								{
									auto OrConditionObjs = OrConditionObjsValue->AsObject();
									if (OrConditionObjs.IsValid())
									{
										const TArray<TSharedPtr<FJsonValue>>* AndConditions = nullptr;
										FRingTaskAndConditions OrCondition;
										if (OrConditionObjs->TryGetArrayField(TEXT("AndConditions"), AndConditions))
										{
											for (const auto& AndConditionJValue : *AndConditions)
											{
												auto AndConditionObj = AndConditionJValue->AsObject();
												if (AndConditionObj.IsValid())
												{
													double VariableResult = AndConditionObj->GetNumberField(TEXT("Variable"));
													double CompareTypeResult = AndConditionObj->GetNumberField(TEXT("CompareType"));
													double ValueResult = AndConditionObj->GetNumberField(TEXT("Value"));
													FString KeyResult = AndConditionObj->GetStringField(TEXT("Key"));
													URingTaskConditionClass* AndCondition = NewObject<URingTaskConditionClass>(InObj);
													AndCondition->Variable = static_cast<ERingTaskConditionType>(VariableResult);
													AndCondition->CompareType = static_cast<ERingTaskCompareType>(CompareTypeResult);
													AndCondition->Value = ValueResult;
													AndCondition->Key = KeyResult;
													OrCondition.AndConditions.Add(AndCondition);
												}
											}
										}
										_RingTaskConditionObj->OrConditions.Add(OrCondition);
										if (OrCondition.AndConditions.Num() > 0)
										{
											_RingTaskConditionObj->TaskCondition = OrCondition.AndConditions[0];
										}
									}
								}
							}

							const TSharedPtr<FJsonObject>* TaskConditionObject;
							if (NextTaskInfo->TryGetObjectField(TEXT("TaskCondition"), TaskConditionObject))
							{
								auto TaskConditionObj = *TaskConditionObject;
								if (TaskConditionObj.IsValid() && !TaskConditionObj->Values.IsEmpty())
								{
									double VariableResult = TaskConditionObj->GetNumberField(TEXT("Variable"));
									double CompareTypeResult = TaskConditionObj->GetNumberField(TEXT("CompareType"));
									double ValueResult = TaskConditionObj->GetNumberField(TEXT("Value"));
									FString KeyResult = TaskConditionObj->GetStringField(TEXT("Key"));
									URingTaskConditionClass* TaskCondition = NewObject<URingTaskConditionClass>(InObj);
									TaskCondition->Variable = static_cast<ERingTaskConditionType>(VariableResult);
									TaskCondition->CompareType = static_cast<ERingTaskCompareType>(CompareTypeResult);
									TaskCondition->Value = ValueResult;
									TaskCondition->Key = KeyResult;
									_RingTaskConditionObj->TaskCondition = TaskCondition;
								}
							}
						}
						InObj->NextTaskInfoList.AddUnique(_RingTaskConditionObj);
					}
				}
			}
		}
	}
	return true;
}