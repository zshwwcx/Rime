#pragma once

#include "ImportExport/LuaImporter.h"


class FQuestImporter : public FLuaImporter
{
public:
	FQuestImporter();

	FQuestImporter(bool InLoadSpecialObject);
	
	virtual void ImportLuaToObj(TSharedPtr<class FLuaTable> LuaTable, UObject* OutObject) override;

	void ImportLazyPropertiesFromLuaToObj(TSharedPtr<class FLuaTable> LuaTable, UObject* OutObject);

	void FillObjectPropertyByName(const FString& PropertyName, const TSharedPtr<class FLuaTable>& LuaTable, UObject* OutObject);

	static void InitializeSystemActionClassList(const TMap<FString, UClass*>& ClassList);

private:
	void ImportLuaToObjInner(const TSharedPtr<class FLuaTable>& LuaTable, UObject* OutObject);
	
	bool ProcessQuestSpecialObjectType(const FObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer);

	bool ProcessQuestCommonSubObjectType(const FObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer);
	
	virtual bool FillFObjectProperty(const FObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer) override;

	virtual bool FillStructProperty(const FStructProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer) override;

	void InitAssignersAndAllClassList();

	template <typename ClassName>
	static bool InitializeClassList(const TArray<FString>& BPFilePaths, TMap<int32, TWeakObjectPtr<UClass>>& ClassList);
	static void InitializeAllClassList();
	
	static UClass* GetRingConditionClass();
	
	template <typename ClassName, typename KeyType>
	bool FillTypedObjPropertyWithLuaTable(const FObjectProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer, TMap<KeyType, TWeakObjectPtr<UClass>>& ClassList);
	
	template <typename ClassName, typename KeyType>
	static ClassName* GetInstanceFromType(TSharedPtr<FLuaTable> LuaTable, UObject* Outer, TMap<KeyType, TWeakObjectPtr<UClass>>& ClassList);

	template <typename ClassName>
	static FString GetClassTypeKeyString();

	template <typename ClassName>
	static int32 GetClassType(ClassName* Instance);

private:
	static TArray<TWeakObjectPtr<UClass>> RecordedUClass;
	static TMap<int32, TWeakObjectPtr<UClass>> PreInfoClass;
	static TMap<int32, TWeakObjectPtr<UClass>> ActionClass;
	static TMap<FString, TWeakObjectPtr<UClass>> SystemActionClass;
	static TMap<int32, TWeakObjectPtr<UClass>> TargetClass;
	static TMap<int32, TWeakObjectPtr<UClass>> FailConditionClass;
	static TMap<int32, TWeakObjectPtr<UClass>> ApplyClass;
	static TMap<int32, TWeakObjectPtr<UClass>> RewardClass;
	static TMap<int32, TWeakObjectPtr<UClass>> SubmitClass;
	static TMap<int32, TWeakObjectPtr<UClass>> FailedFallbackClass;
	static TMap<int32, TWeakObjectPtr<UClass>> LeavePlaneClass;
	static TMap<int32, TWeakObjectPtr<UClass>> TraceParamClass;
	static TMap<int32, TWeakObjectPtr<UClass>> RingTaskConditionBaseClass;
	static TMap<int32, TWeakObjectPtr<UClass>> BSQTEDataClass;
	static bool bClassListInited; 
	
	bool bLoadSpecialObject = false;
};

// 给任务编辑器封装好的直接使用的接口
class FQuestLuaImporter
{
public:
	static TSharedPtr<FLuaTable> ConvertLuaFileToLuaTable(const FString &LuaPath);

	static class UEDGraphNode_StateNodeBase* FindNodeByInstance(UEdGraph* Graph, UObject* Instance);
	static class UEDGraphNode_StateNodeBase* FindChapterEndByQuestObjectID(UEdGraph* Graph, const class UQuestRing* Ring);
	
	static bool FillChapterGraphWithLuaTable(class UQuestChapter* InObj, const TSharedPtr<FLuaTable>& LuaTable);

	static void FillGraphCommentNode(class UEDGraphBase* GraphBase, const TSharedPtr<FLuaTable>& LuaTable);

	static bool FillRingGraphAndObjDataWithLuaTable(class UQuestRing* InObj, const TSharedPtr<FLuaTable>& LuaTable);
	
	static bool FillQuestObjDataWithLuaTable(class UQuest* InObj, const TSharedPtr<FLuaTable>& LuaTable);

	static bool FillNextTaskWithLuaTable(class UQuestObject* InObj, const TSharedPtr<FLuaTable>& LuaTable);
};
