#include "QuestTablePreview.h"
#include "QuestTemplate.h"
#include "Kismet/KismetSystemLibrary.h"
#include "UObject/UObjectGlobals.h"
#include "Engine/DataTable.h"
#include "UObject/Class.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "StructUtils/UserDefinedStruct.h"
#include "QuestExportLua.h"


void FQuestTablePreview::CopyStructTableDataFromQuest(UDataTable* DataTable, UQuest* InQuestData, TMap<FName, const uint8*>& TableData)
{
	if(!UKismetSystemLibrary::IsValid(DataTable) || !UKismetSystemLibrary::IsValid(InQuestData))
		return ;
	//

	const FString StructPath = "/Script/Engine.UserDefinedStruct'/Game/Editor/QuestEditor/EditorExcelPreview/FQuestTablePreview.FQuestTablePreview'";

	UScriptStruct* Struct = LoadObject<UScriptStruct>(nullptr, *StructPath);
	if(!Struct)
		return ;

	UUserDefinedStruct* UDStruct = Cast<UUserDefinedStruct>(Struct);
	if(!UDStruct)
		return ;

	DataTable->RowStruct = Struct;

	FString TargetDesList;
	if (InQuestData->QuestGraph && IsValid(InQuestData->QuestGraph))
	{
		TArray<UQuestDataBase*> Progress_Targets;

		for (TObjectPtr<class UEdGraphNode>& QuestNode : InQuestData->QuestGraph->Nodes)
		{
			if (!QuestNode)
				continue;
			if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
			{
				TArray<UQuestDataBase*> OutChildNodeDatas;

				switch (QNode->NodeType)
				{
				case EDNodeType::QuestProgress:
					FQuestExportLua::GetChildNodesData(QNode, EDNodeType::QuestTarget, OutChildNodeDatas);
					Progress_Targets.Append(OutChildNodeDatas);
					break;
				}
			}
		}


		for (auto Elem : Progress_Targets)
		{
			TargetDesList.Append(Elem->GetClass()->GetDisplayNameText().ToString());
			TargetDesList.Append(";");
		}

	}

	for (TFieldIterator<FProperty> It_As(InQuestData->GetClass(), EFieldIteratorFlags::ExcludeSuper); It_As; ++It_As)
	{
		if (FProperty* StructProperty = CastField<FProperty>(*It_As))
		{

			for (TFieldIterator<FProperty> SProperty(Struct); SProperty; ++SProperty)
			{
				if (StructProperty->GetFName() == SProperty->GetMetaData(TEXT("DisplayName")))
				{
					void* TargetPtr = (void*)UDStruct->GetDefaultInstance();

					uint8* rig_Original = StructProperty->ContainerPtrToValuePtr<uint8>(InQuestData);
					uint8* rig_Target = SProperty->ContainerPtrToValuePtr<uint8>(TargetPtr);

					if (rig_Original && rig_Target)
					{
						SProperty->CopyCompleteValue(rig_Target, rig_Original);
					}
				}
				else if ("TargetDesList" == SProperty->GetMetaData(TEXT("DisplayName")))
				{
					if (FStrProperty* StrProperty = CastField<FStrProperty>(*SProperty))
					{
						void* TargetPtr = (void*)UDStruct->GetDefaultInstance();
						uint8* rig_Target = SProperty->ContainerPtrToValuePtr<uint8>(TargetPtr);

						StrProperty->SetValue_InContainer(TargetPtr, TargetDesList);
					}
				}
				else if ("QuestName" == SProperty->GetMetaData(TEXT("DisplayName")))
				{
					if (FStrProperty* StrProperty = CastField<FStrProperty>(*SProperty))
					{
						void* TargetPtr = (void*)UDStruct->GetDefaultInstance();
						uint8* rig_Target = SProperty->ContainerPtrToValuePtr<uint8>(TargetPtr);

						StrProperty->SetValue_InContainer(TargetPtr, InQuestData->QuestName);
					}
				}
			}

			//for (TFieldIterator<FProperty> TIt_As(Struct->GetClass(), EFieldIteratorFlags::ExcludeSuper); TIt_As; ++TIt_As)
			//{
			//	if (FProperty* SProperty = CastField<FProperty>(*TIt_As))
			//	{
			//		if (StructProperty->GetFName() == SProperty->GetFName())
			//		{
			//			uint8* rig_Original = StructProperty->ContainerPtrToValuePtr<uint8>(InQuestData);
			//			uint8* rig_Target = SProperty->ContainerPtrToValuePtr<uint8>(Struct);

			//			if (rig_Original && rig_Target)
			//			{
			//				SProperty->CopyCompleteValue(rig_Target, rig_Original);
			//			}
			//		}
			//	}
			//}
		}
	}

	//uint8* RowData = (uint8*)FMemory::Malloc(DataTable->RowStruct->GetStructureSize());
	//DataTable->RowStruct->InitializeStruct(RowData);

	//TMap<FName, const uint8*> TableData;

	//for (auto& Elem : DataTable->GetRowMap())
	//{
	//	TableData.Add(Elem.Key, Elem.Value);
	//}

	TableData.Add(FName(FString::FromInt(InQuestData->QuestID)), UDStruct->GetDefaultInstance());

	//DataTable->CreateTableFromRawData(TableData, DataTable->RowStruct);


	//DataTable->MarkPackageDirty();

	//FAssetRegistryModule::AssetCreated(DataTable);
}
