
#include "QuestExportLua.h"

#include "EdGraphNode_Comment.h"
#include "FQuestObjectivesEditor.h"
#include "QuestSettings.h"
#include "QuestTemplate.h"
#include "../EDGraph/Nodes/EDGraphNode_StateNode.h"
#include "../EDGraph/Nodes/EDGraphNode_Transition.h"
#include "../EDGraph/Graph/EventDrivenGraphSchema.h"

UE_DISABLE_OPTIMIZATION_SHIP

FString FQuestExportLua::GetPropertyDisPlayName(const FProperty* Property, bool bByStruct)
{
	FString RetVal;
	if (!bByStruct)
	{
		return Property->GetName();
	}
	//static const FName NAME_DisplayName(TEXT("DisplayName"));
	//FString NativeDisplayName;
	//if (const FString* FoundMetaData = Property->FindMetaData(NAME_DisplayName))
	//{
	//	NativeDisplayName = *FoundMetaData;
	//}
	else
	{
		RetVal = Property->GetName();
		int32 UnderscoreIndex = RetVal.Find(TEXT("_"));
		if (UnderscoreIndex != INDEX_NONE)
		{
			RetVal = RetVal.Left(UnderscoreIndex);
		}
	}
	return RetVal;
}


template<typename T>
T* FQuestExportLua::CheckCastAddress(void* Address)
{
	if (T* Dest = StaticCast<T*>(Address))
	{
		return Dest;
	}
	return nullptr;
}

FString FQuestExportLua::JsonValueToLuaStr(TSharedPtr<FJsonValue> RootJsonValue, const FString Field)
{
		
	TSharedPtr<FJsonObject> JsonObject = MakeShared<FJsonObject>();
	JsonObject->SetField(Field, RootJsonValue);
	return JsonValueToLua_Implementation(JsonObject);
}

FString FQuestExportLua::JsonValueToLua_Implementation(TSharedPtr<FJsonObject> JsonObject)
{
	
	FString LuaStr;
	FString LuaRet;
	auto JsonValues = JsonObject->Values;
	for (auto& Pair : JsonValues)
	{
		LuaRet += DumpLua(Pair.Key, Pair.Value, 0, false);
	}
	
	LuaStr = LuaStr.IsEmpty() ? LuaRet : LuaStr;
	LuaStr = LuaStr.IsEmpty() ? "{}" : LuaStr;
	return LuaStr;
}

FString FQuestExportLua::DumpLua(FString InKey, TSharedPtr<FJsonValue> InValue, int Indent, bool bFromArray)
{
	static const FString BaseIndent = "  ";

	auto GetIndentString = [](int Num)
	{
		FString RetString = "";
		for (int i=0; i<Num; i++)
		{
			RetString += BaseIndent;
		}
		return RetString;
	};
	
	// FString KeyStr =
	// 	InKey.IsNumeric() ?
	// 	FString::Format(TEXT("[{0}]"), {FCString::Atoi(*InKey) }) : 
	// 	FString::Format(TEXT("[\"{0}\"]"), {InKey });

	FString KeyStr =
		InKey.IsNumeric() && bFromArray ?
		FString::Format(TEXT("[{0}] = "), {FCString::Atoi(*InKey) }) : 
		FString::Format(TEXT("[\"{0}\"] = "), {InKey });

	if(InKey.Len() == 0)
	{
		KeyStr = InKey;
	}
	
	FString ValueStr;
	if (InValue->Type == EJson::String)
	{
		FString Value = InValue->AsString();
		if (Value.Find("FVector2D") != INDEX_NONE ||
			Value.Find("FVector") != INDEX_NONE ||
			Value.Find("FRotator") != INDEX_NONE ||
			Value.Find("FQuat") != INDEX_NONE ||
			Value.Find("FColor") != INDEX_NONE ||
			Value.Find("FTransform") != INDEX_NONE)
		{
			ValueStr += FString::Format(TEXT("{0},"), { Value });
		}
		else if (Value.Find("\n") != INDEX_NONE || Value.Find("\r\n") != INDEX_NONE)
		{
			Value = Value.Replace(TEXT("\r\n"), TEXT("\\n"));
			Value = Value.Replace(TEXT("\n"), TEXT("\\n"));
			ValueStr += FString::Format(TEXT("\"{0}\","), { Value });
		}
		else if (Value.Find("\"") != INDEX_NONE)
		{
			Value = Value.Replace(TEXT("\""), TEXT("\\\""));
			ValueStr += FString::Format(TEXT("\"{0}\","), { Value });
		}
		else
		{
			ValueStr += FString::Format(TEXT("\"{0}\","), { Value });
		}
	}
	else if(InValue->Type == EJson::Boolean)
	{
		bool Value = InValue->AsBool();
		ValueStr += Value ? "true," : "false,";
	}
	else if (InValue->Type == EJson::Number)
	{
		double ValueDouble = InValue->AsNumber();
		int64 ValueInt = (int64)ValueDouble;
		ValueStr += ValueDouble == (double)ValueInt ?
			FString::Format(TEXT("{0},"), {ValueInt }) :
			FString::Format(TEXT("{0},"), {ValueDouble });
	}
	else if (InValue->Type == EJson::Array)
	{
		if (!InValue->IsNull())
		{
			ValueStr += "{\n";
			TArray< TSharedPtr<FJsonValue> > ArrayValue = InValue->AsArray();
			for (int i=0; i<ArrayValue.Num(); i++)
			{
				const TSharedPtr<FJsonValue>& ArrayValueItem = ArrayValue[i];
				if (ArrayValueItem.IsValid() && !ArrayValueItem->IsNull())
				{
					ValueStr += DumpLua(FString::FromInt(i+1), ArrayValueItem, Indent + 1, true);
				}
			}
			ValueStr += GetIndentString(Indent) + "},";
		}
		else
		{
			ValueStr += "{},";
		}
	}
	else if (InValue->Type == EJson::Object)
	{
		ValueStr += "{\n";
		TSharedPtr<FJsonObject> ObjectValue = InValue->AsObject();
		for (const auto& Entry : ObjectValue->Values)
		{
			if (Entry.Value.IsValid() && !Entry.Value->IsNull())
			{
				ValueStr += DumpLua(Entry.Key, Entry.Value, Indent + 1, false);
			}
		}
		ValueStr += GetIndentString(Indent) + "},";
	}

	if(InKey.Len() == 0)
	{
		ValueStr = ValueStr.Replace(TEXT(","), TEXT("\t"));
		ValueStr.RemoveFromEnd("\t");
		ValueStr += ",";
	}

	ProcessKey(KeyStr);
	return FString::Format(TEXT("{0}{1}{2}\n"), {GetIndentString(Indent), KeyStr, ValueStr});
}


template<typename T>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport(T* Address)
{
	if (FString* Dest = CheckCastAddress<FString>(Address))
	{
		return MakeShared<FJsonValueString>(*Dest);
	}
	return MakeShared<FJsonValueString>(FString());
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FName>(FName* Address)
{
	if (Address)
	{
		return MakeShared<FJsonValueString>(Address->ToString());
	}
	return MakeShared<FJsonValueString>(FString());
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FText>(FText* Address)
{
	if (Address)
	{
		return MakeShared<FJsonValueString>(Address->ToString());
	}
	return MakeShared<FJsonValueString>(FString());
}
	
template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FSoftObjectPath>(FSoftObjectPath* Address)
{
	if (Address)
	{
		return MakeShared<FJsonValueString>(*Address->ToString());
	}
	return MakeShared<FJsonValueString>(FString());
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FGameplayID>(FGameplayID* Address)
{
	if (Address)
	{
		return MakeShared<FJsonValueNumber>(Address->ID);
	}
	return MakeShared<FJsonValueString>(FString());
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FFlowChartPath>(FFlowChartPath* Address)
{
	if (Address)
	{
		return MakeShared<FJsonValueString>(Address->Path);
	}
	return MakeShared<FJsonValueString>(FString());
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FVector2D>(FVector2D* Address)
{
	return MakeShared<FJsonValueString>(FString::Format(TEXT("FVector2D({0},{1})"), { Address->X, Address->Y}));
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FVector>(FVector* Address)
{
	return MakeShared<FJsonValueString>(FString::Format(TEXT("FVector({0},{1},{2})"), { Address->X, Address->Y, Address->Z }));
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FRotator>(FRotator* Address)
{
	return MakeShared<FJsonValueString>(FString::Format(TEXT("FRotator({0},{1},{2})"), { Address->Pitch, Address->Yaw, Address->Roll }));
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FQuat>(FQuat* Address)
{
	return MakeShared<FJsonValueString>(FString::Format(TEXT("FQuat({0},{1},{2},{3})"), { Address->X, Address->Y, Address->Z, Address->W }));
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FColor>(FColor* Address)
{
	return MakeShared<FJsonValueString>(FString::Format(TEXT("FColor({0},{1},{2},{3})"), { Address->R, Address->G, Address->B, Address->A }));
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<FTransform>(FTransform* Address)
{
	FQuat Quat = Address->GetRotation();
	auto QuatJson = DoExport<FQuat>(&Quat);
	
	FVector Vector = Address->GetTranslation();
	auto VectorJson = DoExport<FVector>(&Vector);
	
	FVector Scale = Address->GetScale3D();
	auto ScaleJson = DoExport<FVector>(&Scale);
	FString Value = FString::Format(TEXT("FTransform({0},{1},{2})"),
		{
			QuatJson->AsString(),
			VectorJson->AsString(),
			ScaleJson->AsString()
		});
	return MakeShared<FJsonValueString>(Value);
}

template<typename T>
TSharedPtr<FJsonValue> FQuestExportLua::Export(void *Address)
{
	if (T* Dest = CheckCastAddress<T>(Address))
	{
		return DoExport<T>(Dest);
	}
	return MakeShared<FJsonValueString>(FString());
}

template<typename T, typename JsonValueType>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport(T* Address)
{
	if (Address)
	{
		return MakeShared<JsonValueType>(*Address);
	}
	return MakeShared<FJsonValueString>(FString());
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::DoExport<bool, FJsonValueBoolean>(bool* Address)
{
	if (Address)
	{
		return MakeShared<FJsonValueBoolean>(*Address);
	}
	return MakeShared<FJsonValueBoolean>(false);
}

template<typename T, typename JsonValueType>
TSharedPtr<FJsonValue> FQuestExportLua::Export(void *Address)
{
	if (T* Dest = CheckCastAddress<T>(Address))
	{
		return DoExport<T, JsonValueType>(Dest);
	}
	return MakeShared<FJsonValueString>(FString());
}

template<typename PropertyType>
TSharedPtr<FJsonValue> FQuestExportLua::Export(PropertyType* Property, void* Address)
{
	return MakeShared<FJsonValueString>(FString());
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::Export<FEnumProperty>(FEnumProperty* Property, void* Address)
{
	const uint8_t EnumVale = Property->GetUnderlyingProperty()->GetUnsignedIntPropertyValue(Address);
	return MakeShareable(new FJsonValueNumber(EnumVale));
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::Export<FByteProperty>(FByteProperty* Property, void* Address)
{
	int8 Value(0);
	const TSharedPtr<FJsonObject> UObjectJObj = MakeShared<FJsonObject>();
	if (const FNumericProperty* NumericProperty = CastField<FNumericProperty>(Property))
	{
		if (const UEnum* EnumDef = Property->Enum)
		{
			Value = NumericProperty->GetSignedIntPropertyValue(Address);
		}
	}

	return MakeShareable(new FJsonValueNumber(Value));
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::Export<FStructProperty>(FStructProperty* StructProperty, void* Address)
{
	const TSharedPtr<FJsonObject> StructJObj = MakeShareable(new FJsonObject());
	const FString CPPType = StructProperty->GetCPPType(nullptr, 0);
	if (CPPType == "FVector2D")
	{
		return Export<FVector2D>(Address);
	}
	if (CPPType == "FVector")
	{
		return Export<FVector>(Address);
	}
	if (CPPType == "FRotator")
	{
		return Export<FRotator>(Address);
	}
	if (CPPType == "FTransform")
	{
		return Export<FTransform>(Address);
	}
	if (CPPType == "FColor")
	{
		return Export<FColor>(Address);
	}
	if (CPPType == "FSoftObjectPath")
	{
		return Export<FSoftObjectPath>(Address);
	}
	
	if (const UScriptStruct* Struct = StructProperty->Struct)
	{
		UScriptStruct* FGameplayIDStruct = FindObject<UScriptStruct>(nullptr, TEXT("/Script/KGQuestEditor.GameplayID"));
		if (Struct->IsChildOf(FGameplayIDStruct))
		{
			return Export<FGameplayID>(Address);
		}
		UScriptStruct* FFlowChartPathStruct = FindObject<UScriptStruct>(nullptr, TEXT("/Script/KGQuestEditor.FlowChartPath"));
		if (Struct->IsChildOf(FFlowChartPathStruct))
		{
			return Export<FFlowChartPath>(Address);
		}
		for (FProperty* Property: TFieldRange<FProperty>(Struct))
		{
			void* ValueAddress = Property->ContainerPtrToValuePtr<void>(Address);
			StructJObj->SetField(GetPropertyDisPlayName(Property, true), ExportFProperty(Property, ValueAddress));
		}
	}
	return MakeShareable(new FJsonValueObject(StructJObj));
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::Export<FObjectProperty>(FObjectProperty* ObjectProperty, void* Address)
{
	const TSharedPtr<FJsonObject> UObjectJObj = MakeShared<FJsonObject>();
	if(ObjectProperty->GetName() == "NativeClass")
	{
		return MakeShareable(new FJsonValueObject(UObjectJObj));
	}
	Address = ObjectProperty->GetObjectPropertyValue(Address);
	const UObject* Object = StaticCast<UObject*>(Address);
	if (!IsValid(Object))
	{
		return MakeShareable(new FJsonValueObject(UObjectJObj));
	}

	const UClass* Class = Object->GetClass();

	UObject* DefaultObj(nullptr);
	if (Class && Object->IsA<URingTaskConditionBase>())
	{
		DefaultObj = Class->GetDefaultObject();
	}
	const FName CategoryKey = TEXT("Category");
	for (FProperty *Property : TFieldRange<FProperty>(Class, EFieldIteratorFlags::IncludeSuper))
	{
		FString CategoryName;
		const FString* CategoryNamePtr = Property->GetMetaDataMap()->Find(CategoryKey);
		if(CategoryNamePtr)
		{
			CategoryName = *CategoryNamePtr;
		}
		if (CategoryName == "Edit")
		{
			continue;
		}
		
		void* PropAddress = Property->ContainerPtrToValuePtr<void>(Address);

		if (DefaultObj)
		{
			if (FIntProperty* IntProperty = CastField<FIntProperty>(Property))
			{
				void* DefaultIntAddress = Property->ContainerPtrToValuePtr<void>(DefaultObj);
				int32* DefValue = StaticCast<int32*>(DefaultIntAddress);
				int32* CurValue = StaticCast<int32*>(PropAddress);
				if ((*DefValue) == (*CurValue))
				{
					continue;
				}
			}
			else if (FStrProperty* StrProperty = CastField<FStrProperty>(Property))
			{
				void* DefaultIntAddress = Property->ContainerPtrToValuePtr<void>(DefaultObj);
				FString* DefValue = StaticCast<FString*>(DefaultIntAddress);
				FString* CurValue = StaticCast<FString*>(PropAddress);
				if ((*DefValue) == (*CurValue))
				{
					continue;
				}
			}
		}
		//if(const FObjectProperty* ObjProperty = CastField<FObjectProperty>(Property))
		//{
		//	PropAddress = ObjProperty->GetObjectPropertyValue(PropAddress);
		//}
		UObjectJObj->SetField(Property->GetName(), ExportFProperty(Property, PropAddress));
	}

	return MakeShareable(new FJsonValueObject(UObjectJObj));
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::Export<FSoftObjectProperty>(FSoftObjectProperty* Property, void* Address)
{
	const FString CPPType = Property->GetCPPType(nullptr, 0);
	if (const FSoftObjectProperty::TCppType* ObjectAddress = CheckCastAddress<FSoftObjectProperty::TCppType>(Address))
	{
		auto Object = *ObjectAddress;
		auto Asset = Object.LoadSynchronous();
		if (Asset)
		{
			return MakeShared<FJsonValueString>(Asset->GetPathName());
		}

	}
	return MakeShared<FJsonValueString>(FString());
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::Export<FMapProperty>(FMapProperty* MapProperty, void* Address)
{
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

	FScriptMapHelper MapHelper(MapProperty, Address);

	FProperty* KeyProperty = MapHelper.GetKeyProperty();
	FProperty* ValueProperty = MapHelper.GetValueProperty();
	const FObjectProperty* ObjectProperty = CastField<FObjectProperty>(ValueProperty);
	const int32 MapNum = MapHelper.Num();
	for (int32 i = 0; i < MapNum; ++i)
	{
		if (!MapHelper.IsValidIndex(i))
		{
			continue;
		}

		void* KeyAddress = MapHelper.GetKeyPtr(i);
		FString Key;
		if (FStrProperty* KeyFStr = CastField<FStrProperty>(KeyProperty))
		{
			Key = *StaticCast<FString*>(KeyAddress);
		}
		if (FNameProperty* KeyFName = CastField<FNameProperty>(KeyProperty))
		{
			Key = StaticCast<FName*>(KeyAddress)->ToString();
		}
		if (FIntProperty* KeyInt32 = CastField<FIntProperty>(KeyProperty))
		{
			const int32* IntKey = StaticCast<int32*>(KeyAddress);
			Key = FString::FromInt(*IntKey);
		}

		void* ValueAddress = MapHelper.GetValuePtr(i);
			
		if (ObjectProperty)
		{
			ValueAddress = ObjectProperty->GetObjectPropertyValue(ValueAddress);
		}

		if (!Key.IsEmpty())
		{
			JsonObject->SetField(Key, ExportFProperty(ValueProperty, ValueAddress));
		}
	}

	return MakeShared<FJsonValueObject>(JsonObject);
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::Export<FSetProperty>(FSetProperty* SetProperty, void* Address)
{
	TArray<TSharedPtr<FJsonValue>> JObjArray;
	FScriptSetHelper SetHelper(SetProperty, Address);
	
	FProperty* ElementProperty = SetHelper.GetElementProperty();
	
	const FObjectProperty* ObjectProperty = CastField<FObjectProperty>(ElementProperty);
	const int32 SetNum = SetHelper.Num();
	for (int32 i = 0; i < SetNum; ++i)
	{
		if (!SetHelper.IsValidIndex(i))
		{
			continue;
		}

		void* ElementAddress = SetHelper.GetElementPtr(i);
		
		if (ObjectProperty)
		{
			ElementAddress = ObjectProperty->GetObjectPropertyValue(ElementAddress);
		}

		JObjArray.Add(ExportFProperty(ElementProperty, ElementAddress));
	}

	return MakeShared<FJsonValueArray>(JObjArray);
}

template<>
TSharedPtr<FJsonValue> FQuestExportLua::Export<FArrayProperty>(FArrayProperty* ArrayProperty, void* Address)
{
	TArray<TSharedPtr<FJsonValue>> JObjArray;
	FScriptArrayHelper ArrayHelper(ArrayProperty, Address);

	FProperty* ElemProperty = ArrayProperty->Inner;
	const FObjectProperty* ObjectProperty = CastField<FObjectProperty>(ElemProperty);

	const int32 ArrayNum = ArrayHelper.Num();
	for (int32 i = 0; i < ArrayNum; ++i)
	{
		void* PropAddress = ArrayHelper.GetRawPtr(i);
		if (ObjectProperty)
		{
			UObject* ObjAddress = ObjectProperty->GetObjectPropertyValue(PropAddress);
			if(!ObjAddress)
			{
				continue;
			}
		}
		JObjArray.Add(ExportFProperty(ElemProperty, PropAddress));
	}
	return MakeShared<FJsonValueArray>(JObjArray);
}

TSharedPtr<FJsonValue> FQuestExportLua::ExportFProperty(FProperty* Property, void* Address)
{
	if (!Address)
	{
		return MakeShared<FJsonValueString>(FString());
	}
	if (FStrProperty* StrProperty = CastField<FStrProperty>(Property))
	{
		return Export<FString>(Address);
	}
	if (FTextProperty* TextProperty = CastField<FTextProperty>(Property))
	{
		return Export<FText>(Address);
	}
	if (FNameProperty* NameProperty = CastField<FNameProperty>(Property))
	{
		return Export<FName>(Address);
	}
	if (FBoolProperty* BoolProperty = CastField<FBoolProperty>(Property))
	{
		return Export<bool, FJsonValueBoolean>(Address);
	}
	if (FFloatProperty* FloatProperty = CastField<FFloatProperty>(Property))
	{
		return Export<float, FJsonValueNumber>(Address);
	}
	if (FDoubleProperty* DoubleProperty = CastField<FDoubleProperty>(Property))
	{
		return Export<double, FJsonValueNumber>(Address);
	}
	if (FIntProperty* IntProperty = CastField<FIntProperty>(Property))
    {
    	return Export<int, FJsonValueNumber>(Address);
    }
	if (FInt64Property* IntProperty = CastField<FInt64Property>(Property))
	{
		return Export<int64, FJsonValueNumber>(Address);
	}
	if (FEnumProperty* EnumProperty = CastField<FEnumProperty>(Property))
	{
		// return Export<uint8_t, FJsonValueNumber>(Address);
		return Export<FEnumProperty>(EnumProperty, Address);
	}
	if (Property->IsA<FByteProperty>())
	{
		if (FByteProperty* ByteP = CastField<FByteProperty>(Property))
		{
			// if (ByteP->Enum)
			// {
			// 	return Export<int8, FJsonValueNumber>(Address);
			// }
			return Export<FByteProperty>(ByteP, Address);
		}
	}
	else if (FSoftObjectProperty* SoftObjProperty = CastField<FSoftObjectProperty>(Property))
	{
		return Export<FSoftObjectProperty>(SoftObjProperty, Address);
	}
	else if (FArrayProperty* ArrayProperty = CastField<FArrayProperty>(Property))
	{
		return Export<FArrayProperty>(ArrayProperty, Address);
	}
	else if (FMapProperty* MapProperty = CastField<FMapProperty>(Property))
	{
		return Export<FMapProperty>(MapProperty, Address);
	}
	else if (FSetProperty* SetProperty = CastField<FSetProperty>(Property))
	{
		return Export<FSetProperty>(SetProperty, Address);
	}
	else if (FObjectProperty* ObjProperty = CastField<FObjectProperty>(Property))
	{
		return Export<FObjectProperty>(ObjProperty, Address);
	}
	else if (FStructProperty* StructProperty = CastField<FStructProperty>(Property))
	{
		return Export<FStructProperty>(StructProperty, Address);
	}
	else if (FUInt32Property* UInt32Property = CastField<FUInt32Property>(Property))
	{
		return Export<uint32, FJsonValueNumber>(Address);
	}

	return MakeShared<FJsonValueString>(FString());
}

void FQuestExportLua::InnerExportObjectData(UObject* Obj, TSharedPtr<FJsonObject> JsonObject, const TMap<FString, FString>* ExPropertys, const TMap<FString, int32>* ExIntPropertys)
{
	if(!Obj || !IsValid(Obj))
		return ;

	
	const FName CategoryKey = TEXT("Category");
	for (FProperty* Property : TFieldRange<FProperty>(Obj->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		if(!Property->GetMetaDataMap())
			continue;

		if (Property->HasMetaData(TEXT("LuaNoExport")))
			continue;

		FString CategoryName;
		const FString* CategoryNamePtr = Property->GetMetaDataMap()->Find(CategoryKey);
		if(CategoryNamePtr)
		{
			CategoryName = *CategoryNamePtr;
		}
		if (CategoryName == "Edit")
		{
			continue;
		}
		if(Property->GetName() == "NativeClass")
		{
			continue;
		}
		//if (!(Property->HasAnyPropertyFlags(CPF_BlueprintVisible) || CategoryName == "Quest"))
		//{
		//	continue;
		//}

		void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(Obj);

		JsonObject->SetField(Property->GetName(), ExportFProperty(Property, PropertyAddress));
	}
	
	if (ExPropertys)
	{
		for (auto& Elem : *ExPropertys)
		{
			JsonObject->SetField(Elem.Key, MakeShared<FJsonValueString>(*Elem.Value));
		}
	}
	if (ExIntPropertys)
	{
		for (auto& Elem : *ExIntPropertys)
		{
			JsonObject->SetField(Elem.Key, MakeShared<FJsonValueNumber>(Elem.Value));
		}
	}
}

void FQuestExportLua::InnerExportObjectDataAll(UObject* Obj, TSharedPtr<FJsonObject> JsonObject, const TMap<FString, FString>* ExPropertys, const TMap<FString, int32>* ExIntPropertys)
{
	if(!Obj || !IsValid(Obj))
		return ;
	
	for (FProperty* Property : TFieldRange<FProperty>(Obj->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		if(!Property->GetMetaDataMap())
			continue;

		if (Property->HasMetaData(TEXT("LuaNoExport")))
			continue;

		bool bCommonExport = true;

		if(Property->GetName().Equals("Father"))
		{
			bCommonExport = false;
		}
		if(Property->GetName().Equals("Children"))
		{
			bCommonExport = false;
		}
		
		if (UQuestRing* QR = Cast<UQuestRing>(Obj))
		{
			// UQuestRing下的RingGraph需要特殊处理
			if (Property->GetName().Equals("RingGraph"))
			{
				bCommonExport = false;
			}
		}
		else if (UQuest* Q = Cast<UQuest>(Obj))
		{
			// UQuest下的QuestGraph需要特殊处理
			if (Property->GetName().Equals("QuestGraph"))
			{
				bCommonExport = false;
			}
			// UQuest下的Begin需要特殊处理
			else if (Property->GetName().Equals("Begin"))
			{
				bCommonExport = false;
			}
			// UQuest下的Progress需要特殊处理
			else if (Property->GetName().Equals("Progress"))
			{
				bCommonExport = false;
			}
			// UQuest下的End需要特殊处理
			else if (Property->GetName().Equals("End"))
			{
				bCommonExport = false;
			}
		}
		else if(UQuestChapter* QC = Cast<UQuestChapter>(Obj))
		{
			if(Property->GetName().Equals("ChapterGraph"))
			{
				bCommonExport = false;
			}
		}
		
		if (bCommonExport)
		{
			void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(Obj);

			JsonObject->SetField(Property->GetName(), ExportFProperty(Property, PropertyAddress));
		}
	}

	if (ExPropertys)
	{
		for (auto& Elem : *ExPropertys)
		{
			JsonObject->SetField(Elem.Key, MakeShared<FJsonValueString>(*Elem.Value));
		}
	}
	if (ExIntPropertys)
	{
		for (auto& Elem : *ExIntPropertys)
		{
			JsonObject->SetField(Elem.Key, MakeShared<FJsonValueNumber>(Elem.Value));
		}
	}
}

void FQuestExportLua::InnerExportActionConditionData(FActionConditionExportLua* Obj, TSharedPtr<FJsonObject> JsonObject)
{
	if (!Obj)
		return;

	if (!Obj->TransitionCondition.IsValid())
		return;

	JsonObject->SetField("FromUniqueID", MakeShared<FJsonValueString>(Obj->FromUniqueID));
	JsonObject->SetField("ToUniqueID", MakeShared<FJsonValueString>(Obj->ToUniqueID));

	const FName CategoryKey = TEXT("Category");
	for (FProperty* Property : TFieldRange<FProperty>(Obj->TransitionCondition.Get()->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		if (!Property->GetMetaDataMap())
			continue;

		const FString* CategoryName = Property->GetMetaDataMap()->Find(CategoryKey);
		if (CategoryName && CategoryName->Equals("Edit"))
		{
			continue;
		}

		void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(Obj->TransitionCondition.Get());

		JsonObject->SetField(Property->GetName(), ExportFProperty(Property, PropertyAddress));
	}
}

void FQuestExportLua::ExportQuestExtraInfo(UQuest* QuestData, TSharedPtr<FJsonObject> JsonObject)
{
	FString ExtraInfo;
	auto AddObjectInfo = [&ExtraInfo](UObject* InObject)
	{
		ExtraInfo += InObject->GetClass()->GetDisplayNameText().ToString();
		ExtraInfo += TEXT("  ");
	};

	// 任务目标设置
	for (UQuestTargetBase* QuestTarget : QuestData->QuestTargets)
	{
		if (QuestTarget && QuestTarget->bIsMain)
		{
			AddObjectInfo(QuestTarget);

			// 任务步骤追踪设置的下拉框内的中文文本
			if (QuestTarget->TraceParam)
			{
				AddObjectInfo(QuestTarget->TraceParam);
			}
		}
	}
	// 任务步骤失败条件
	if (QuestData->FailConditions)
	{
		AddObjectInfo(QuestData->FailConditions);
	}
	// 任务步骤失败模式
	if (QuestData->FailedFallbackType)
	{
		AddObjectInfo(QuestData->FailedFallbackType);
	}
	// 任务步骤完成时离开位面设置
	if (QuestData->LeavePlaneAction)
	{
		AddObjectInfo(QuestData->LeavePlaneAction);
	}

	JsonObject->SetStringField(TEXT("ExtraInfo"), ExtraInfo);
}

void FQuestExportLua::ExportRingExtraInfo(UQuestRing* RingData, TSharedPtr<FJsonObject> JsonObject)
{
	FString ExtraInfo;
	auto AddObjectInfo = [&ExtraInfo](UObject* InObject)
	{
		ExtraInfo += InObject->GetClass()->GetDisplayNameText().ToString();
		ExtraInfo += TEXT("  ");
	};

	JsonObject->SetStringField(TEXT("ExtraInfo"), ExtraInfo);
}

void FQuestExportLua::GetChildNodes(UEDGraphNode_Base* ParentNode, EDNodeType TargetType, TArray<UEDGraphNode_Base*>& OutChildNodes)
{
	if (!ParentNode || !IsValid(ParentNode))
		return;

	for (UEdGraphPin* Pin : ParentNode->GetAllPins())
	{
		if (Pin->Direction == EGPD_Output)
		{
			TArray<UEdGraphPin*> ToPins = Pin->LinkedTo;
			for (UEdGraphPin* ToPin : ToPins)
			{
				if (UEdGraphNode* ChildNode = ToPin->GetOwningNodeUnchecked())
				{
					if (UEDGraphNode_Transition* TNode = Cast<UEDGraphNode_Transition>(ChildNode))
					{
						UEdGraphPin* NextTToPin = TNode->GetOutputPin();
						if (NextTToPin)
						{
							TArray<UEdGraphPin*> NextTToPin_LinkTos = NextTToPin->LinkedTo;
							for (UEdGraphPin* NextTToPin_ToPin : NextTToPin_LinkTos)
							{
								if (NextTToPin_ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
								{
									UEdGraphNode* ToNode = NextTToPin_ToPin->GetOwningNodeUnchecked();
									if (UEDGraphNode_StateNode* ToQuest = Cast<UEDGraphNode_StateNode>(ToNode))
									{
										ChildNode = ToQuest;
									}
								}
							}
						}
					}

					if (UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(ChildNode))
					{
						if (EDNode->NodeType != TargetType)
							continue;

						if (EDNode->NodeInstance && IsValid(EDNode->NodeInstance))
						{
							OutChildNodes.Push(EDNode);
						}
					}
				}
			}
		}
	}
}

void FQuestExportLua::GetChildNodes(UEDGraphNode_Base* ParentNode, const TCHAR* PinName, EDNodeType TargetType, TArray<UEDGraphNode_Base*>& OutChildNodes)
{
	if (!ParentNode || !IsValid(ParentNode))
		return;

	if (UEdGraphPin* Pin = ParentNode->FindPin(PinName))
	{
		if (Pin->Direction == EGPD_Output)
		{
			TArray<UEdGraphPin*> ToPins = Pin->LinkedTo;
			for (UEdGraphPin* ToPin : ToPins)
			{
				if (UEdGraphNode* ChildNode = ToPin->GetOwningNodeUnchecked())
				{
					if (UEDGraphNode_Transition* TNode = Cast<UEDGraphNode_Transition>(ChildNode))
					{
						UEdGraphPin* NextTToPin = TNode->GetOutputPin();
						if (NextTToPin)
						{
							TArray<UEdGraphPin*> NextTToPin_LinkTos = NextTToPin->LinkedTo;
							for (UEdGraphPin* NextTToPin_ToPin : NextTToPin_LinkTos)
							{
								if (NextTToPin_ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
								{
									UEdGraphNode* ToNode = NextTToPin_ToPin->GetOwningNodeUnchecked();
									if (UEDGraphNode_StateNode* ToQuest = Cast<UEDGraphNode_StateNode>(ToNode))
									{
										ChildNode = ToQuest;
									}
								}
							}
						}
					}

					if (UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(ChildNode))
					{
						if (EDNode->NodeType != TargetType)
							continue;

						if (EDNode->NodeInstance && IsValid(EDNode->NodeInstance))
						{
							OutChildNodes.Push(EDNode);
						}
					}
				}
			}
		}
	}
}

void FQuestExportLua::GetChildNodesData(UEDGraphNode_Base* ParentNode, EDNodeType TargetType, TArray<UQuestDataBase*>& OutChildNodeDatas, bool bReCursive)
{
	TArray<UEDGraphNode_Base*> OutChildNodes;
	FQuestExportLua::GetChildNodes(ParentNode, TargetType, OutChildNodes);
	for (UEDGraphNode_Base* ChildNode : OutChildNodes)
	{
		if (ChildNode->NodeType != TargetType)
			continue;

		if (ChildNode->NodeInstance && IsValid(ChildNode->NodeInstance))
		{
			if (UQuestDataBase* QD = Cast<UQuestDataBase>(ChildNode->NodeInstance))
			{
				OutChildNodeDatas.Push(QD);
			}
		}

		// 如果是Action节点的话，还需要考虑串联的情况
		if (TargetType == EDNodeType::QuestAction && bReCursive)
		{
			FQuestExportLua::GetChildNodesData(ChildNode, TargetType, OutChildNodeDatas, bReCursive);
		}
	}
}

void FQuestExportLua::GetChildNodesData(UEDGraphNode_Base* ParentNode, const TCHAR* PinName, EDNodeType TargetType, TArray<UQuestDataBase*>& OutChildNodeDatas, bool bReCursive)
{
	TArray<UEDGraphNode_Base*> OutChildNodes;
	FQuestExportLua::GetChildNodes(ParentNode, PinName, TargetType, OutChildNodes);
	for (UEDGraphNode_Base* ChildNode : OutChildNodes)
	{
		if (ChildNode->NodeType != TargetType)
			continue;

		if (ChildNode->NodeInstance && IsValid(ChildNode->NodeInstance))
		{
			if (UQuestDataBase* QD = Cast<UQuestDataBase>(ChildNode->NodeInstance))
			{
				OutChildNodeDatas.Push(QD);
			}
		}

		// 如果是Action节点的话，还需要考虑串联的情况
		if (TargetType == EDNodeType::QuestAction && bReCursive)
		{
			FQuestExportLua::GetChildNodesData(ChildNode, TargetType, OutChildNodeDatas, bReCursive);
		}
	}
}

void FQuestExportLua::GetChildNodesData(UEDGraphNode_Base* ParentNode, EDNodeType TargetType1, EDNodeType TargetType2, TArray<UQuestDataBase*>& OutChildNodeDatas, bool bReCursive)
{
	TArray<UEDGraphNode_Base*> OutChildNodes;
	FQuestExportLua::GetChildNodes(ParentNode, TargetType1, OutChildNodes);
	for (UEDGraphNode_Base* ChildNode : OutChildNodes)
	{
		GetChildNodesData(ChildNode, TargetType2, OutChildNodeDatas, bReCursive);
	}
}

bool FQuestExportLua::PreCheckQuestData(class UQuest* QuestData)
{
	if (!QuestData || !IsValid(QuestData))
		return false;

	if (QuestData->QuestGraph && IsValid(QuestData->QuestGraph))
	{
		if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(QuestData->QuestGraph))
		{
			UEDGraphNode_StateNodeBase* ProgressNode = nullptr;
			for (TObjectPtr<class UEdGraphNode>& GraphNode : QuestData->QuestGraph->Nodes)
			{
				if (!GraphNode)
					continue;
				if (UEDGraphNode_StateNodeBase* ActionStateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
				{
					if (ActionStateNode->NodeType == EDNodeType::QuestProgress)
					{
						ProgressNode = ActionStateNode;
						break;
					}
				}
			}

			if (ProgressNode == nullptr)
				return false;

			TArray<UEDGraphNode_Base*> OutChildNodes;
			FQuestExportLua::GetChildNodes(ProgressNode, EDNodeType::QuestTarget, OutChildNodes);
			if (QuestData->MainTarget)
				return true;
			else
				return false;
		}
	}

	return false;
}

FString FQuestExportLua::ExportChapterData(class UQuestChapter* ChapterData, const TMap<FString, FString>* ExPropertys)
{
	FString LuaStr = "{ }";
	if (!ChapterData || !IsValid(ChapterData))
	{
		return LuaStr;
	}
	
	const TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());
	const TSharedPtr<FJsonObject> JsonObjectEditor = MakeShareable(new FJsonObject());
	InnerExportObjectDataAll(ChapterData, JsonObject, ExPropertys);
	
	TArray<TSharedPtr<FJsonValue>> JObjArray;
	TArray<TSharedPtr<FJsonValue>> JEndArray;
	TArray<TSharedPtr<FJsonValue>> JCommentArray;
	if (ChapterData->ChapterGraph)
	{
		for (TObjectPtr<class UEdGraphNode>& RingNode : ChapterData->ChapterGraph->Nodes)
		{
			if (!RingNode)
				continue;
			if (UEDGraphNode_Base* RNode = Cast<UEDGraphNode_Base>(RingNode))
			{
				if (auto RingData = Cast<UQuestRing>(RNode->NodeInstance))
				{
					TSharedPtr<FJsonObject> JObject = MakeShared<FJsonObject>();
					JObject->SetField("RingID", MakeShared<FJsonValueNumber>(RingData->RingID));
					JObject->SetField("PosX", MakeShared<FJsonValueNumber>(RNode->NodePosX));
					JObject->SetField("PosY", MakeShared<FJsonValueNumber>(RNode->NodePosY));
					JObjArray.Add(MakeShareable(new FJsonValueObject(JObject)));
				}
			}
			if (UEDGraphNode_Base* RNode = Cast<UEDGraphNode_Base>(RingNode))
			{
				if (auto EndData = Cast<UChapterEnd>(RNode->NodeInstance))
				{
					TSharedPtr<FJsonObject> JObject = MakeShared<FJsonObject>();
					JObject->SetField("NextRingID", MakeShared<FJsonValueNumber>(EndData->NextRingID));
					JObject->SetField("Desc", MakeShared<FJsonValueString>(EndData->Desc));
					JObject->SetField("PosX", MakeShared<FJsonValueNumber>(RNode->NodePosX));
					JObject->SetField("PosY", MakeShared<FJsonValueNumber>(RNode->NodePosY));
					JEndArray.Add(MakeShareable(new FJsonValueObject(JObject)));
				}
			}
			if (UEdGraphNode_Comment* CommentNode = Cast<UEdGraphNode_Comment>(RingNode))
			{
				ExportCommentNode(CommentNode, JCommentArray);
			}
		}
	}
	
	JsonObjectEditor->SetField("RingNode", MakeShared<FJsonValueArray>(JObjArray));
	JsonObjectEditor->SetField("EndNode", MakeShared<FJsonValueArray>(JEndArray));
	JsonObjectEditor->SetField("CommentNode", MakeShared<FJsonValueArray>(JCommentArray));
	
	const TSharedPtr<FJsonValue> JsonObjectEditorValue = MakeShareable(new FJsonValueObject(JsonObjectEditor));
	JsonObject->SetField("EditorOnly", JsonObjectEditorValue);
	
	return "return {\n" + JsonValueToLua_Implementation(JsonObject) + "}";
}

TSharedPtr<FJsonObject> FQuestExportLua::ExportQuestJsonValue(UQuest* QuestData, const TMap<FString, FString>* ExPropertys)
{
	const TSharedPtr<FJsonObject> JsonObject = DoExportQuest(QuestData, false, ExPropertys);
	const TSharedPtr<FJsonObject> JsonObjectEditor = DoExportQuest(QuestData, true, ExPropertys);
	const TSharedPtr<FJsonValue> JsonObjectEditorValue = MakeShareable(new FJsonValueObject(JsonObjectEditor));
	JsonObject->SetField("EditorOnly", JsonObjectEditorValue);

	return JsonObject;
}

TSharedPtr<FJsonObject> FQuestExportLua::ExportQuestJsonValueProcessed(UQuest* QuestData, const TMap<FString, FString>* ExPropertys)
{
	if (!QuestData)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: Invalid InObj!"), ANSI_TO_TCHAR(__FUNCTION__));
		return nullptr;
	}
	if (UQuestRing* QuestRing = Cast<UQuestRing>(QuestData->Father))
	{
		if (UEDGraphBase* RingGraphBase = Cast<UEDGraphBase>(QuestRing->RingGraph))
		{
			auto CurEditor = RingGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				UQuest* QuestDataDelegate = Cast<UQuest>(QuestEditor->DeepCopyQuestObject(QuestData));
				if (QuestDataDelegate)
				{
					// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
					if (QuestDataDelegate->QuestGraph == nullptr)
						QuestEditor->PreRefreshQuestGraph(QuestDataDelegate);
				
					// 处理主副目标，需要将主目标也放入数组中，并确保不存在副目标也标记了bIsMain
					for(auto QuestTarget : QuestDataDelegate->QuestTargets)
					{
						if(QuestTarget)
						{
							QuestTarget->bIsMain = false;
						}
					}
					QuestDataDelegate->QuestTargets.Add(QuestDataDelegate->MainTarget);
					QuestDataDelegate->MainTarget = nullptr;

					return ExportQuestJsonValue(QuestDataDelegate);
				}
			}
		}
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("%s: QuestData %d has no father!"), ANSI_TO_TCHAR(__FUNCTION__), QuestData->QuestID);
	}

	return ExportQuestJsonValue(QuestData);
}

FString FQuestExportLua::ExportQuestCSV(UQuest* QuestData, const TArray<FString> &Titles)
{
	const TSharedPtr<FJsonObject> JsonObject = ExportQuestJsonValue(QuestData);
	FString RetVal = "";
	for(int Index = 0; Index < Titles.Num(); Index++)
	{
		FString PropertyContent = ",";
		if(JsonObject->HasField(Titles[Index]))
		{
			PropertyContent = DumpLua("", JsonObject->Values[Titles[Index]], 0, false);
		}
		RetVal += PropertyContent;
	}
	RetVal = RetVal.Replace(TEXT("\n"), TEXT(""));
	if(RetVal.Len()>0)
	{
		RetVal.RemoveFromEnd(",");
	}
	return RetVal;
}

FString FQuestExportLua::ExportQuestData(class UQuest* QuestData, const TMap<FString, FString>* ExPropertys)
{
	const TSharedPtr<FJsonObject> JsonObject = ExportQuestJsonValue(QuestData, ExPropertys);
	
	return "return {\n" + JsonValueToLua_Implementation(JsonObject) + "}";
}

FString FQuestExportLua::ExportQuestDataProcessed(UQuest* QuestData, const TMap<FString, FString>* ExPropertys)
{
	const TSharedPtr<FJsonObject> JsonObject = ExportQuestJsonValueProcessed(QuestData, ExPropertys);
	
	return "return {\n" + JsonValueToLua_Implementation(JsonObject) + "}";
}

UEDGraphNode_Base* TryGetNodeByInstance(class UQuest* QuestData, UQuestDataBase* InInstance)
{
	if (QuestData->QuestGraph && IsValid(QuestData->QuestGraph))
	{
		for (TObjectPtr<class UEdGraphNode>& QuestNode : QuestData->QuestGraph->Nodes)
		{
			if (!QuestNode)
				continue;
			if (UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(QuestNode))
			{
				if (EDNode->NodeInstance && IsValid(EDNode->NodeInstance))
				{
					if (EDNode->NodeInstance == InInstance)
						return EDNode;
				}
			}
		}
	}
	return nullptr;
}

TSharedPtr<FJsonObject> FQuestExportLua::DoExportQuest(class UQuest* QuestData, bool bAsset, const TMap<FString, FString>* ExPropertys)
{
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());
	
	if (!QuestData || !IsValid(QuestData))
		return JsonObject;
	
	if (!QuestData)
	{
		return JsonObject;
	}

	if (bAsset)
	{
		InnerExportObjectDataAll(QuestData, JsonObject, ExPropertys);
		InnerExportObjectDataAll(QuestData->End, JsonObject);
		InnerExportObjectDataAll(QuestData->Progress, JsonObject);
		ExportQuestExtraInfo(QuestData, JsonObject);
	}
	else
	{
		InnerExportObjectData(QuestData, JsonObject, ExPropertys);
		InnerExportObjectData(QuestData->End, JsonObject);
		InnerExportObjectData(QuestData->Progress, JsonObject);
	}
	
	return JsonObject;
}

TSharedPtr<FJsonObject> FQuestExportLua::ExportRingJsonValue(UQuestRing* RingData, const TMap<FString, FString>* ExPropertys)
{
	if (!RingData || !IsValid(RingData))
	{
		return nullptr;
	}

	bool bSaveAndLoadQuestInRing = false;
	if (UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
	{
		bSaveAndLoadQuestInRing = QuestSettings->bSaveAndLoadQuestInRing;
	}
	
	const TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());
	const TSharedPtr<FJsonObject> JsonObjectEditor = MakeShareable(new FJsonObject());
	
	InnerExportObjectData(RingData, JsonObject, ExPropertys);
	InnerExportObjectDataAll(RingData, JsonObjectEditor, ExPropertys);

	TArray<TSharedPtr<FJsonValue>> JObjArray;
	TArray<TSharedPtr<FJsonValue>> JCommentArray;
	TSharedPtr<FJsonObject> JObjQuests = MakeShareable(new FJsonObject());
	if (RingData->RingGraph)
	{
		for (TObjectPtr<class UEdGraphNode>& QuestNode : RingData->RingGraph->Nodes)
		{
			if (!QuestNode)
				continue;
			if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
			{
				if (UQuest* QuestData = Cast<UQuest>(QNode->NodeInstance))
				{
					TSharedPtr<FJsonObject> JObject = MakeShared<FJsonObject>();
					JObject->SetField("QuestID", MakeShared<FJsonValueNumber>(QuestData->QuestID));
					JObject->SetField("PosX", MakeShared<FJsonValueNumber>(QNode->NodePosX));
					JObject->SetField("PosY", MakeShared<FJsonValueNumber>(QNode->NodePosY));
					JObjArray.Add(MakeShareable(new FJsonValueObject(JObject)));

					if (bSaveAndLoadQuestInRing)
					{
						const TSharedPtr<FJsonObject> JObjectQuest = ExportQuestJsonValueProcessed(QuestData);
						JObjQuests->SetField(FString::FromInt(QuestData->QuestID) + TEXT("__ToInt"), MakeShareable(new FJsonValueObject(JObjectQuest)));
					}
				}
			}
			if (UEdGraphNode_Comment* CommentNode = Cast<UEdGraphNode_Comment>(QuestNode))
			{
				ExportCommentNode(CommentNode, JCommentArray);
			}
		}
	}
	JsonObjectEditor->SetField("QuestNode", MakeShared<FJsonValueArray>(JObjArray));
	JsonObjectEditor->SetField("CommentNode", MakeShared<FJsonValueArray>(JCommentArray));
	if (bSaveAndLoadQuestInRing)
	{
		// JsonObjectEditor->SetField("QuestData", MakeShared<FJsonValueObject>(JObjQuests));
		JsonObject->SetField("QuestData", MakeShared<FJsonValueObject>(JObjQuests));
	}

	TArray<TSharedPtr<FJsonValue>> JTransArray;
	if (RingData->RingGraph)
	{
		for (TObjectPtr<class UEdGraphNode>& QuestNode : RingData->RingGraph->Nodes)
		{
			if (!QuestNode)
				continue;
			if (UEDGraphNode_Transition* ActionTransitionNode = Cast<UEDGraphNode_Transition>(QuestNode))
			{
				UEDGraphNode_Base* FromState = ActionTransitionNode->GetFromState();
				UEDGraphNode_Base* ToState = ActionTransitionNode->GetToState();
				if (FromState && FromState->NodeInstance && IsValid(FromState->NodeInstance) && ToState && ToState->NodeInstance && IsValid(ToState->NodeInstance))
				{
					if (UQuest* FromQuestData = Cast<UQuest>(FromState->NodeInstance))
					{
						if (UQuest* ToQuestData = Cast<UQuest>(ToState->NodeInstance))
						{
							TSharedPtr<FJsonObject> JObject = MakeShared<FJsonObject>();
							JObject->SetField("FromQuestID", MakeShared<FJsonValueNumber>(FromQuestData->QuestID));
							JObject->SetField("ToQuestID", MakeShared<FJsonValueNumber>(ToQuestData->QuestID));
							JTransArray.Add(MakeShareable(new FJsonValueObject(JObject)));		
						}
					}
				}
			}
		}
	}
	JsonObjectEditor->SetField("QuestConnection", MakeShared<FJsonValueArray>(JTransArray));
	ExportRingExtraInfo(RingData, JsonObjectEditor);
	
	const TSharedPtr<FJsonValue> JsonObjectEditorValue = MakeShareable(new FJsonValueObject(JsonObjectEditor));
	JsonObject->SetField("EditorOnly", JsonObjectEditorValue);

	return JsonObject;
}

FString FQuestExportLua::ExportRingCSV(UQuestRing* RingData, const TArray<FString>& Titles)
{
	const TSharedPtr<FJsonObject> JsonObject = ExportRingJsonValue(RingData);
	FString RetVal = "";
	for(int Index = 0; Index < Titles.Num(); Index++)
	{
		FString PropertyContent = ",";
		if(JsonObject->HasField(Titles[Index]))
		{
			PropertyContent = DumpLua("", JsonObject->Values[Titles[Index]], 0, false);
		}
		RetVal += PropertyContent;
	}
	RetVal = RetVal.Replace(TEXT("\n"), TEXT(""));
	if(RetVal.Len()>0)
	{
		RetVal.RemoveFromEnd(",");
	}
	
	return RetVal;
}

FString FQuestExportLua::ExportRingData(UQuestRing* RingData, const TMap<FString, FString>* ExPropertys)
{
	const auto JsonObject = ExportRingJsonValue(RingData, ExPropertys);
	return "return {\n" + JsonValueToLua_Implementation(JsonObject) + "}";
}

void FQuestExportLua::ExportCommentNode(UEdGraphNode_Comment* CommentNode, TArray<TSharedPtr<FJsonValue>>& JCommentArray)
{
	if (CommentNode)
	{
		const TSharedPtr<FJsonObject> JObject = MakeShared<FJsonObject>();
		JObject->SetField("NodePosX", MakeShareable(new FJsonValueNumber(CommentNode->NodePosX)));
		JObject->SetField("NodePosY", MakeShareable(new FJsonValueNumber(CommentNode->NodePosY)));
		JObject->SetField("NodeWidth", MakeShareable(new FJsonValueNumber(CommentNode->NodeWidth)));
		JObject->SetField("NodeHeight", MakeShareable(new FJsonValueNumber(CommentNode->NodeHeight)));
		JObject->SetField("NodeComment", MakeShareable(new FJsonValueString(CommentNode->NodeComment)));
		JCommentArray.Add(MakeShareable(new FJsonValueObject(JObject)));
	}
}

void FQuestExportLua::ProcessKey(FString& InKey)
{
	// 从 ["98001605__ToInt"] =  变到 [98001605] =
	if (InKey.Contains(TEXT("__ToInt")) && InKey.Contains(TEXT("\"")) && InKey.Contains(TEXT("[")) && InKey.Contains(TEXT("]")))
	{
		InKey = InKey.Replace(TEXT("\""), TEXT(""));
		InKey = InKey.Replace(TEXT("__ToInt"), TEXT(""));
	}
}


UE_ENABLE_OPTIMIZATION_SHIP