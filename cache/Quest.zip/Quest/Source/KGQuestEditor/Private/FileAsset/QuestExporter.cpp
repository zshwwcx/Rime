#include "QuestExporter.h"

#include "EdGraphNode_Comment.h"
#include "FQuestObjectivesEditor.h"
#include "QuestImporter.h"
#include "QuestSettings.h"
#include "QuestTemplate.h"
#include "Action/QuestAction.h"
#include "EDGraph/Graph/EventDrivenGraphSchema.h"
#include "EDGraph/Nodes/EDGraphNode_Base.h"
#include "EDGraph/Nodes/EDGraphNode_Transition.h"
#include "LuaSerialization/Serialization/LuaSerializer.h"

FQuestExporter::FQuestExporter()
{
	MathDataExportMethod = EMathDataImportExportMethod::Constructor;
}

TSharedPtr<FLuaValue> FQuestExporter::ExportObjectPropertyToLua(FObjectProperty* Prop, void* DataAddress, UObject* ParentObject)
{
	UObject* ObjectPtr = Prop->GetObjectPropertyValue(DataAddress);
	TSharedPtr<FLuaTable> LuaTable = MakeShareable(new FLuaTable());
	if (ObjectPtr == nullptr)
	{
		return MakeShared<FLuaValueTable>(LuaTable);
	}
	ExportObjectToLuaInner(ObjectPtr, LuaTable);
	
	return MakeShared<FLuaValueTable>(LuaTable);
}

TSharedPtr<FLuaValue> FQuestExporter::ExportClassPropertyToLua(FClassProperty* Prop, void* DataAddress)
{
	TSharedPtr<FLuaTable> LuaTable = MakeShareable(new FLuaTable());
	if(Prop->GetName() == "NativeClass")
	{
		return MakeShared<FLuaValueTable>(LuaTable);
	}
	return FLuaExporter::ExportClassPropertyToLua(Prop, DataAddress);
}

TSharedPtr<FLuaValue> FQuestExporter::ExportStructPropertyToLua(UScriptStruct* ScriptStruct, void* DataAddress, UObject* ParentObject)
{
	const FString StructCPPName = ScriptStruct->GetStructCPPName();
	if (StructCPPName == "FSoftObjectPath")
	{
		if (const FSoftObjectPath* Address = static_cast<FSoftObjectPath*>(DataAddress))
		{
			return MakeShared<FLuaValueString>(*Address->ToString());
		}
		return MakeShared<FLuaValueString>(FString());
	}
	if (ScriptStruct->IsChildOf(FGameplayID::StaticStruct()))
	{
		if (FGameplayID* Address = static_cast<FGameplayID*>(DataAddress))
		{
			return MakeShared<FLuaValueNumber>(Address->ID);
		}
		return MakeShared<FLuaValueString>(FString());
	}
	if (ScriptStruct->IsChildOf(FFlowChartPath::StaticStruct()))
	{
		if (FFlowChartPath* Address = static_cast<FFlowChartPath*>(DataAddress))
		{
			return MakeShared<FLuaValueString>(Address->Path);
		}
		return MakeShared<FLuaValueString>(FString());
	}
	
	return FLuaExporter::ExportStructPropertyToLua(ScriptStruct, DataAddress, ParentObject);
}

TSharedPtr<FLuaValue> FQuestExporter::ExportInt64PropertyToLua(FInt64Property* Prop, void* DataAddress)
{
	int64* ValuePtr = static_cast<int64*>(DataAddress);
	return MakeShared<FLuaValueNumber>(*ValuePtr);
}

bool FQuestExporter::IsInnerObjectPropertyNeedExport(FProperty* Prop, UObject* Object, UClass* ObjectClass)
{
	if (Prop->HasMetaData(TEXT("QuestIgnoreExport")))
	{
		return false;
	}
	if (Prop->GetName() == "NativeClass")
	{
		return false;
	}
	if (Prop->GetName() == "AssetBundleData")
	{
		return false;
	}
	if (Prop->GetName() == "Bundles")
	{
		return false;
	}
	if (UObject* DefaultObject = ObjectClass->GetDefaultObject())
	{
		if (GetMutableDefault<UQuestSettings>()->bUseCDO && !bForceExportDefaultValue)
		{
			if (!Prop->HasMetaData(TEXT("QuestExportIdenticalToDefault")) && Prop->Identical_InContainer(Object, DefaultObject))
			{
				return false;
			}
		}
	}
	return FLuaExporter::IsInnerObjectPropertyNeedExport(Prop, Object, ObjectClass);
}

FQuestEditorExporter::FQuestEditorExporter() : FQuestExporter()
{
	bExportEditorOnly = true;
}

bool FQuestEditorExporter::IsInnerObjectPropertyNeedExport(FProperty* Prop, UObject* Object, UClass* ObjectClass)
{
	if (Prop->HasMetaData(TEXT("QuestIgnoreExportEditor")))
	{
		return false;
	}
	if (Prop->GetName() == "AssetBundleData")
	{
		return false;
	}
	if (Prop->GetName() == "Bundles")
	{
		return false;
	}
	return FLuaExporter::IsInnerObjectPropertyNeedExport(Prop, Object, ObjectClass);
}

FQuestCDOExporter::FQuestCDOExporter() : FQuestExporter()
{
	bForceExportDefaultValue = true;
}

TArray<TPair<FString, TSharedPtr<FLuaValueIntTable>>> FQuestLuaExporter::SystemActionLuaTables;

FString FQuestLuaExporter::ExportChapterData(UQuestChapter* ChapterData)
{
	TSharedPtr<FLuaTable> LuaTable = MakeShareable(new FLuaTable());
	ExportChapterDataToLuaTable(ChapterData, LuaTable);
	FString LuaStr;
	const TSharedRef<TLuaWriter<>> LuaWriter = TLuaWriterFactory<>::Create(&LuaStr);
	FLuaSerializer::Serialize(LuaTable.ToSharedRef(), LuaWriter, true, false);
	return LuaStr;
}

void FQuestLuaExporter::ExportChapterDataToLuaTable(class UQuestChapter* ChapterData, const TSharedPtr<FLuaTable>& LuaTable)
{
	TSharedPtr<FQuestChapterExporter> QuestChapterExporter = MakeShared<FQuestChapterExporter>();
	QuestChapterExporter->ExportObjectToLua(ChapterData, LuaTable);
	TSharedPtr<FLuaTable> EditorOnlyTable = MakeShareable(new FLuaTable());
	TArray<TSharedPtr<FLuaValue>> LTableArray;
	TArray<TSharedPtr<FLuaValue>> LEndArray;
	TArray<TSharedPtr<FLuaValue>> LCommentArray;
	if (ChapterData->ChapterGraph)
	{
		for (TObjectPtr<class UEdGraphNode>& RingNode : ChapterData->ChapterGraph->Nodes)
		{
			if (!RingNode)
				continue;
			if (UEDGraphNode_Base* RNode = Cast<UEDGraphNode_Base>(RingNode))
			{
				if (auto RingData = Cast<UQuestRing>(RNode->NodeInstance))
				{
					TSharedPtr<FLuaTable> LTable = MakeShared<FLuaTable>();
					LTable->SetField("RingID", MakeShared<FLuaValueNumber>(RingData->RingID));
					LTable->SetField("PosX", MakeShared<FLuaValueNumber>(RNode->NodePosX));
					LTable->SetField("PosY", MakeShared<FLuaValueNumber>(RNode->NodePosY));
					LTableArray.Add(MakeShareable(new FLuaValueTable(LTable)));
				}

				if (auto EndData = Cast<UChapterEnd>(RNode->NodeInstance))
				{
					TSharedPtr<FLuaTable> LTable = MakeShared<FLuaTable>();
					LTable->SetField("NextRingID", MakeShared<FLuaValueNumber>(EndData->NextRingID));
					LTable->SetField("Desc", MakeShared<FLuaValueString>(EndData->Desc));
					LTable->SetField("PosX", MakeShared<FLuaValueNumber>(RNode->NodePosX));
					LTable->SetField("PosY", MakeShared<FLuaValueNumber>(RNode->NodePosY));
					LEndArray.Add(MakeShareable(new FLuaValueTable(LTable)));
				}
			}

			if (UEdGraphNode_Comment* CommentNode = Cast<UEdGraphNode_Comment>(RingNode))
			{
				const TSharedPtr<FLuaTable> LTable = MakeShared<FLuaTable>();
				LTable->SetField("NodePosX", MakeShareable(new FLuaValueNumber(CommentNode->NodePosX)));
				LTable->SetField("NodePosY", MakeShareable(new FLuaValueNumber(CommentNode->NodePosY)));
				LTable->SetField("NodeWidth", MakeShareable(new FLuaValueNumber(CommentNode->NodeWidth)));
				LTable->SetField("NodeHeight", MakeShareable(new FLuaValueNumber(CommentNode->NodeHeight)));
				LTable->SetField("NodeComment", MakeShareable(new FLuaValueString(CommentNode->NodeComment)));
				LCommentArray.Add(MakeShareable(new FLuaValueTable(LTable)));
			}
		}
	}
	
	EditorOnlyTable->SetField("RingNode", MakeShared<FLuaValueArray>(LTableArray));
	if (!LEndArray.IsEmpty())
	{
		EditorOnlyTable->SetField("EndNode", MakeShared<FLuaValueArray>(LEndArray));
	}
	if (!LCommentArray.IsEmpty())
	{
		EditorOnlyTable->SetField("CommentNode", MakeShared<FLuaValueArray>(LCommentArray));
	}
	LuaTable->SetField(TEXT("EditorOnly"), MakeShared<FLuaValueTable>(EditorOnlyTable));
}

FString FQuestLuaExporter::ExportRingData(UQuestRing* RingData, const TMap<FString, FString>* ExProperties, bool bParseSystemActions)
{
	SystemActionLuaTables.Empty();
	TSharedPtr<FLuaTable> LuaTable = MakeShareable(new FLuaTable());
	ExportRingDataToLuaTable(RingData, LuaTable, ExProperties);
	if (bParseSystemActions)
	{
		FQuestActionHelper::ParseSystemActions(SystemActionLuaTables);
	}
	FString LuaStr;
	const TSharedRef<TLuaWriter<>> LuaWriter = TLuaWriterFactory<>::Create(&LuaStr);
	FLuaSerializer::Serialize(LuaTable.ToSharedRef(), LuaWriter, true, false, true);
	return LuaStr;
}

void FQuestLuaExporter::ExportRingDataToLuaTable(UQuestRing* RingData, const TSharedPtr<FLuaTable>& LuaTable, const TMap<FString, FString>* ExProperties)
{
	TSharedPtr<FQuestRingExporter> QuestRingExporter = MakeShared<FQuestRingExporter>();
	QuestRingExporter->ExportObjectToLua(RingData, LuaTable);
	// 处理system action 逻辑
	ProcessSystemActions(RingData->ApplySystemActions, "ApplySystemActions", LuaTable);
	ProcessSystemActions(RingData->SubmitSystemActions, "SubmitSystemActions", LuaTable);
	ProcessSystemActions(RingData->AbandonSystemActions, "AbandonSystemActions", LuaTable);

	TMap<int32, UQuest*> QuestID2Quest;
	for (TObjectPtr<UEdGraphNode>& QuestNode : RingData->RingGraph->Nodes)
	{
		if (!QuestNode)
		{
			continue;
		}
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
		{
			if (UQuest* QuestData = Cast<UQuest>(QNode->NodeInstance))
			{
				// 提前清空预加载参数，在后续重新计算填充
				QuestData->PreloadMap.Empty();

				QuestID2Quest.Add(QuestData->QuestID, QuestData);
			}
		}
	}

	TMap<UQuest*, TArray<UQuest*>> QuestTrans;
	TMap<UQuest*, TArray<UQuest*>> QuestTransReverse;
	if (RingData->RingGraph)
	{
		for (TObjectPtr<class UEdGraphNode>& QuestNode : RingData->RingGraph->Nodes)
		{
			if (!QuestNode)
				continue;
			if (UEDGraphNode_Transition* ActionTransitionNode = Cast<UEDGraphNode_Transition>(QuestNode))
			{
				UEDGraphNode_Base* FromState = ActionTransitionNode->GetFromState();
				UEDGraphNode_Base* ToState = ActionTransitionNode->GetToState();
				if (FromState && FromState->NodeInstance && IsValid(FromState->NodeInstance) && ToState && ToState->NodeInstance && IsValid(ToState->NodeInstance))
				{
					if (UQuest* FromQuestData = Cast<UQuest>(FromState->NodeInstance))
					{
						if (UQuest* ToQuestData = Cast<UQuest>(ToState->NodeInstance))
						{
							TArray<UQuest*>& Trans = QuestTrans.FindOrAdd(FromQuestData);
							Trans.Add(ToQuestData);

							TArray<UQuest*>& TransReverse = QuestTransReverse.FindOrAdd(ToQuestData);
							TransReverse.Add(FromQuestData);
						}
					}
				}
			}
		}
	}

	auto FillPreloadMap = [&QuestTransReverse, &QuestID2Quest](UQuest* QuestData, const FPreloadArgs& PreloadArgs, const TArray<int32>& DialogueIDs, const TArray<int32>& CutsceneIDs)
	{
		if (PreloadArgs.PreloadQuestID == "-1")
		{
			if (QuestTransReverse.Contains(QuestData))
			{
				TArray<UQuest*> QuestFathers = QuestTransReverse[QuestData];
				for (UQuest* QuestFather : QuestFathers)
				{
					if (QuestTransReverse.Contains(QuestFather))
					{
						TArray<UQuest*> QuestGrandpas = QuestTransReverse[QuestFather];
						for (UQuest* QuestGrandpa : QuestGrandpas)
						{
							if (QuestGrandpa->PreloadMap.Contains(QuestData->QuestID))
							{
								for (int32 DialogID : DialogueIDs)
								{
									QuestGrandpa->PreloadMap[QuestData->QuestID].PreloadDialogIDs.AddUnique(DialogID);
								}
								for (int32 CutsceneID : CutsceneIDs)
								{
									QuestGrandpa->PreloadMap[QuestData->QuestID].PreLoadCutSceneIDs.AddUnique(CutsceneID);
								}
							}
							else
							{
								FPreloadIDs PreloadDialogIDs;
								PreloadDialogIDs.PreloadDialogIDs.Append(DialogueIDs);
								PreloadDialogIDs.PreLoadCutSceneIDs.Append(CutsceneIDs);
								QuestGrandpa->PreloadMap.Add(QuestData->QuestID, PreloadDialogIDs);
							}
						}
					}
				}
			}
		}
		else if (QuestID2Quest.Contains(FCString::Atoi(*PreloadArgs.PreloadQuestID)))
		{
			UQuest* QuestToAddPreloadInfo = QuestID2Quest[FCString::Atoi(*PreloadArgs.PreloadQuestID)];
			if (QuestToAddPreloadInfo->PreloadMap.Contains(QuestData->QuestID))
			{
				for (int32 DialogID : DialogueIDs)
				{
					QuestToAddPreloadInfo->PreloadMap[QuestData->QuestID].PreloadDialogIDs.AddUnique(DialogID);
				}
				for (int32 CutsceneID : CutsceneIDs)
				{
					QuestToAddPreloadInfo->PreloadMap[QuestData->QuestID].PreLoadCutSceneIDs.AddUnique(CutsceneID);
				}
			}
			else
			{
				FPreloadIDs PreloadDialogIDs;
				PreloadDialogIDs.PreloadDialogIDs.Append(DialogueIDs);
				PreloadDialogIDs.PreLoadCutSceneIDs.Append(CutsceneIDs);
				QuestToAddPreloadInfo->PreloadMap.Add(QuestData->QuestID, PreloadDialogIDs);
			}
		}
	};

	for (TObjectPtr<UEdGraphNode>& QuestNode : RingData->RingGraph->Nodes)
	{
		if (!QuestNode)
		{
			continue;
		}
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
		{
			if (UQuest* QuestData = Cast<UQuest>(QNode->NodeInstance))
			{
				// 预加载判断
				TArray<UQuestTargetBase*> QuestTargetsToProcess = QuestData->QuestTargets;
				QuestTargetsToProcess.Add(QuestData->MainTarget);
				for (UQuestTargetBase* QuestTarget : QuestTargetsToProcess)
				{
					// 播放Dialogue 与Npc进行对话
					if (QuestTarget && (QuestTarget->Type == 102 || QuestTarget->Type == 144))
					{
						if (FProperty* PreLoadArgsProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("PreLoadArgs")))
						{
							FPreloadArgs PreloadArgs;
							PreLoadArgsProperty->GetValue_InContainer(QuestTarget, &PreloadArgs);

							// 如果该任务有需要预加载的对话，则提前在相应任务填充预加载字段
							if (PreloadArgs.bNeedPreload)
							{
								if (FProperty* DialogIDProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("DialogID")))
								{
									if (FStructProperty* StructProperty = CastField<FStructProperty>(DialogIDProperty))
									{
										FDialogueID DialogID;
										StructProperty->GetValue_InContainer(QuestTarget, &DialogID);

										FillPreloadMap(QuestData, PreloadArgs, {DialogID.ID}, {});
									}
								}
							}
						}
					}

					// 播放Cutscene
					if (QuestTarget && QuestTarget->Type == 101)
					{
						if (FProperty* PreLoadArgsProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("PreLoadArgs")))
						{
							FPreloadArgs PreloadArgs;
							PreLoadArgsProperty->GetValue_InContainer(QuestTarget, &PreloadArgs);

							// 如果该任务有需要预加载的对话，则提前在相应任务填充预加载字段
							if (PreloadArgs.bNeedPreload)
							{
								if (FProperty* DialogIDProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("CutSceneID")))
								{
									if (FIntProperty* StructProperty = CastField<FIntProperty>(DialogIDProperty))
									{
										int32 CutSceneID;
										StructProperty->GetValue_InContainer(QuestTarget, &CutSceneID);

										FillPreloadMap(QuestData, PreloadArgs, {}, {CutSceneID});
									}
								}
							}
						}
					}

					// 与Npc进行连续对话
					if (QuestTarget && QuestTarget->Type == 169)
					{
						if (FProperty* PreLoadArgsProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("PreLoadArgs")))
						{
							FPreloadArgs PreloadArgs;
							PreLoadArgsProperty->GetValue_InContainer(QuestTarget, &PreloadArgs);

							// 如果该任务有需要预加载的对话，则提前在相应任务填充预加载字段
							if (PreloadArgs.bNeedPreload)
							{
								if (FProperty* DialogIDProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("DialogIDList")))
								{
									if (FArrayProperty* ArrayProperty = CastField<FArrayProperty>(DialogIDProperty))
									{
										TArray<int32> DialogIDs;
										
										FScriptArrayHelper ArrayHelper(ArrayProperty, ArrayProperty->ContainerPtrToValuePtr<void>(QuestTarget));
										int32 ArrayNum = ArrayHelper.Num();

										for (int32 Index = 0; Index < ArrayNum; ++Index)
										{
											if (void* ElementAddress = ArrayHelper.GetElementPtr(Index))
											{
												if (FDialogueID* DialogIDPtr = static_cast<FDialogueID*>(ElementAddress))
												{
													DialogIDs.Add(DialogIDPtr->ID);
												}
											}
										}

										FillPreloadMap(QuestData, PreloadArgs, DialogIDs, {});
									}
								}
							}
						}
					}

					// 提交道具（设置提交ID） 分支提交道具 提交道具（设置提交参数）
					if (QuestTarget && (QuestTarget->Type == 124 || QuestTarget->Type == 168 || QuestTarget->Type == 167))
					{
						if (FProperty* PreLoadArgsProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("PreLoadArgs")))
						{
							FPreloadArgs PreloadArgs;
							PreLoadArgsProperty->GetValue_InContainer(QuestTarget, &PreloadArgs);

							// 如果该任务有需要预加载的对话，则提前在相应任务填充预加载字段
							if (PreloadArgs.bNeedPreload)
							{
								
								if (FProperty* PlayDialogueKindIDProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("PlayDialogueKindID")))
								{
									int32 PlayDialogueKindID;
									PlayDialogueKindIDProperty->GetValue_InContainer(QuestTarget, &PlayDialogueKindID);

									// 提交模式选择不为 “只提交道具不播放Dialogue”
									if (PlayDialogueKindID != 0)
									{
										if (FProperty* DialogIDProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("DialogueID")))
										{
											if (FStructProperty* StructProperty = CastField<FStructProperty>(DialogIDProperty))
											{
												FDialogueID DialogID;
												StructProperty->GetValue_InContainer(QuestTarget, &DialogID);

												FillPreloadMap(QuestData, PreloadArgs, {DialogID.ID}, {});
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	TSharedPtr<FLuaTable> QuestDatasTable = MakeShareable(new FLuaTable());
	for (TObjectPtr<UEdGraphNode>& QuestNode : RingData->RingGraph->Nodes)
	{
		if (!QuestNode)
		{
			continue;
		}
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
		{
			if (UQuest* QuestData = Cast<UQuest>(QNode->NodeInstance))
			{
				if (UQuest* FinalQuest = GetFinalQuestDataToExport(QuestData))
				{
					TSharedPtr<FLuaTable> QuestTable = MakeShareable(new FLuaTable());
					ExportQuestDataToLuaTable(FinalQuest, QuestTable, ExProperties);
					QuestDatasTable->SetField(FString::FromInt(QuestData->QuestID), MakeShared<FLuaValueTable>(QuestTable));
				}
			}
		}
	}
	LuaTable->SetField(TEXT("QuestData"), MakeShared<FLuaValueIntTable>(QuestDatasTable));

	TSharedPtr<FLuaTable> EditorOnlyTable = MakeShareable(new FLuaTable());
	TSharedPtr<FQuestRingEditorExporter> QuestRingEditorExporter = MakeShared<FQuestRingEditorExporter>();
	TArray<TSharedPtr<FLuaValue>> LCommentArray;
	TMap<UQuest*, FString> QuestNodeStrs;
	if (RingData->RingGraph)
	{
		for (TObjectPtr<class UEdGraphNode>& QuestNode : RingData->RingGraph->Nodes)
		{
			if (!QuestNode)
				continue;
			if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
			{
				if (UQuest* QuestData = Cast<UQuest>(QNode->NodeInstance))
				{
					QuestNodeStrs.Add(QuestData, FString::Format(TEXT("{0},{1}"), {QNode->NodePosX, QNode->NodePosY}));
				}
			}
			if (UEdGraphNode_Comment* CommentNode = Cast<UEdGraphNode_Comment>(QuestNode))
			{
				const TSharedPtr<FLuaTable> LTable = MakeShared<FLuaTable>();
				LTable->SetField("NodePosX", MakeShareable(new FLuaValueNumber(CommentNode->NodePosX)));
				LTable->SetField("NodePosY", MakeShareable(new FLuaValueNumber(CommentNode->NodePosY)));
				LTable->SetField("NodeWidth", MakeShareable(new FLuaValueNumber(CommentNode->NodeWidth)));
				LTable->SetField("NodeHeight", MakeShareable(new FLuaValueNumber(CommentNode->NodeHeight)));
				LTable->SetField("NodeComment", MakeShareable(new FLuaValueString(CommentNode->NodeComment)));
				LCommentArray.Add(MakeShareable(new FLuaValueTable(LTable)));
			}
		}
	}
	TSharedPtr<FLuaTable> QuestNodeAndTransTable = MakeShared<FLuaTable>();
	bool IsFirstIndex = true;
	int32 FirstQuestID = INDEX_NONE;
	for (auto Pair : QuestNodeStrs)
	{
		UQuest* Quest = Pair.Key;
		FString TransStr = Pair.Value;
		if (QuestTrans.Contains(Quest))
		{
			for (int32 Index = 0; Index < QuestTrans[Quest].Num(); Index++)
			{
				TransStr += FString::Format(TEXT(",{0}"), {QuestTrans[Quest][Index]->QuestID});
			}
		}
		QuestNodeAndTransTable->SetField(FString::FromInt(Quest->QuestID), MakeShared<FLuaValueString>(TransStr));
		if (IsFirstIndex && !QuestTransReverse.Contains(Quest))
		{
			FirstQuestID = Quest->QuestID;
			IsFirstIndex = false;
		}
	}
	EditorOnlyTable->SetField("QuestNodeAndConnection", MakeShared<FLuaValueIntTable>(QuestNodeAndTransTable));
	if (!LCommentArray.IsEmpty())
	{
		EditorOnlyTable->SetField("CommentNode", MakeShared<FLuaValueArray>(LCommentArray));
	}
	if (!IsFirstIndex)
	{
		LuaTable->SetField(TEXT("FirstQuestID"), MakeShared<FLuaValueNumber>(FirstQuestID));
	}
	LuaTable->SetField(TEXT("EditorOnly"), MakeShared<FLuaValueTable>(EditorOnlyTable));

	ExportRingExtraInfo(RingData, LuaTable);
}

void FQuestLuaExporter::ProcessSystemActions(const TArray<UQuestSystemActionBase*>& Actions, const FString& PropertyName, const TSharedPtr<FLuaTable>& LuaTable)
{
	if (!Actions.IsEmpty())
	{
		const FString ActionParseKey = FQuestActionHelper::GetSystemActionsParams(Actions);
		TSharedPtr<FLuaTable> SystemActionLuaTable = MakeShareable(new FLuaTable());
		TSharedPtr<FLuaValueIntTable> LuaValueIntTable = MakeShared<FLuaValueIntTable>(SystemActionLuaTable);
		FQuestLuaExporter::SystemActionLuaTables.Add(TPair<FString, TSharedPtr<FLuaValueIntTable>>(ActionParseKey, LuaValueIntTable));
		LuaTable->SetField(FString::Printf(TEXT("%sData"), *PropertyName), LuaValueIntTable);
	}
}

void FQuestLuaExporter::ExportQuestDataToLuaTable(UQuest* QuestData, const TSharedPtr<FLuaTable>& LuaTable, const TMap<FString, FString>* ExProperties)
{
	TSharedPtr<FQuestDataExporter> QuestDataExporter = MakeShared<FQuestDataExporter>();
	QuestDataExporter->ExportObjectToLua(QuestData, LuaTable);
	// 处理system action 逻辑
	ProcessSystemActions(QuestData->BeginSystemActions, "BeginSystemActions", LuaTable);
	ProcessSystemActions(QuestData->EndSystemActions, "EndSystemActions", LuaTable);
	ProcessSystemActions(QuestData->FailSystemActions, "FailSystemActions", LuaTable);
	ProcessSystemActions(QuestData->ClickSystemActions, "ClickSystemActions", LuaTable);

	ExportQuestExtraInfo(QuestData, LuaTable);
}

UQuest* FQuestLuaExporter::GetFinalQuestDataToExport(UQuest* QuestData)
{
	UQuest* FinalQuest = nullptr;
	if (UQuestRing* QuestRing = Cast<UQuestRing>(QuestData->Father))
	{
		if (UEDGraphBase* RingGraphBase = Cast<UEDGraphBase>(QuestRing->RingGraph))
		{
			auto CurEditor = RingGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				// 如果是 前往指定坐标交互并进入位面 则在保存时多写一个 instanceid 给服务端用
				// 这里我们要修改到原来的 QuestData，而不是深拷贝后的 FinalQuest
				TArray<UQuestTargetBase*> QuestTargetsToProcess = QuestData->QuestTargets;
				QuestTargetsToProcess.Add(QuestData->MainTarget);
				for (UQuestTargetBase* QuestTarget : QuestTargetsToProcess)
				{
					if (QuestTarget && QuestTarget->Type == 143)
					{
						FProperty* InstanceIDProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("InstanceID"));

						if (InstanceIDProperty)
						{
							if (FStrProperty* StrProperty = CastField<FStrProperty>(InstanceIDProperty))
							{
								// 处理整数ID
								FString CurrentID = StrProperty->GetPropertyValue_InContainer(QuestTarget);

								// 如果为0或无效，生成新ID
								if (CurrentID.IsEmpty())
								{
									// refer to ASceneActorBase::ASceneActorBase()
									int64 NewID = GetTypeHash(FGuid::NewGuid());
									StrProperty->SetPropertyValue_InContainer(QuestTarget, FString::Printf(TEXT("%lld"), NewID));
								}
							}
						}
					}
				}
				
				FinalQuest = Cast<UQuest>(QuestEditor->DeepCopyQuestObject(QuestData));
				if (FinalQuest)
				{
					// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
					if (FinalQuest->QuestGraph == nullptr)
					{
						QuestEditor->PreRefreshQuestGraph(FinalQuest);
					}
				
					// 处理主副目标，需要将主目标也放入数组中，并确保不存在副目标也标记了bIsMain
					for (auto QuestTarget : FinalQuest->QuestTargets)
					{
						if(QuestTarget)
						{
							QuestTarget->bIsMain = false;
						}
					}
					if (FinalQuest->MainTarget && FinalQuest->MainTarget->bIsMain == true)
					{
						// 主目标的这部分数据从 MainTargetTraceCombo 里获取，避免冗余
						FinalQuest->MainTarget->TraceParam = nullptr;
					}
					FinalQuest->QuestTargets.Add(FinalQuest->MainTarget);
					FinalQuest->MainTarget = nullptr;
				}
			}
		}
	}
	return FinalQuest;
}

FString FQuestLuaExporter::ExportCDO()
{
	return "";
}

void FQuestLuaExporter::ExportRingExtraInfo(UQuestRing* RingData, TSharedPtr<FLuaTable> LuaTable)
{
	FString ExtraInfo;
	auto AddObjectInfo = [&ExtraInfo](UObject* InObject)
	{
		ExtraInfo += InObject->GetClass()->GetDisplayNameText().ToString();
		ExtraInfo += TEXT("  ");
	};

	// Action设置
	for (UQuestSystemActionBase* Action : RingData->ApplySystemActions)
	{
		if (Action)
		{
			AddObjectInfo(Action);
		}
	}
	for (UQuestSystemActionBase* Action : RingData->SubmitSystemActions)
	{
		if (Action)
		{
			AddObjectInfo(Action);
		}
	}
	for (UQuestSystemActionBase* Action : RingData->AbandonSystemActions)
	{
		if (Action)
		{
			AddObjectInfo(Action);
		}
	}

	LuaTable->SetField(TEXT("ExtraInfo"), MakeShared<FLuaValueString>(ExtraInfo));
}

void FQuestLuaExporter::ExportQuestExtraInfo(UQuest* QuestData, TSharedPtr<FLuaTable> LuaTable)
{
	FString ExtraInfo;
	auto AddObjectInfo = [&ExtraInfo](UObject* InObject)
	{
		ExtraInfo += InObject->GetClass()->GetDisplayNameText().ToString();
		ExtraInfo += TEXT("  ");
	};

	// 任务目标设置
	for (UQuestTargetBase* QuestTarget : QuestData->QuestTargets)
	{
		if (QuestTarget && QuestTarget->bIsMain)
		{
			AddObjectInfo(QuestTarget);

			// 任务步骤追踪设置的下拉框内的中文文本
			if (QuestTarget->TraceParam)
			{
				AddObjectInfo(QuestTarget->TraceParam);
			}
		}
	}
	// Action设置
	for (UQuestSystemActionBase* Action : QuestData->ClickSystemActions)
	{
		if (Action)
		{
			AddObjectInfo(Action);
		}
	}
	for (UQuestSystemActionBase* Action : QuestData->BeginSystemActions)
	{
		if (Action)
		{
			AddObjectInfo(Action);
		}
	}
	for (UQuestSystemActionBase* Action : QuestData->FailSystemActions)
	{
		if (Action)
		{
			AddObjectInfo(Action);
		}
	}
	for (UQuestSystemActionBase* Action : QuestData->EndSystemActions)
	{
		if (Action)
		{
			AddObjectInfo(Action);
		}
	}
	// 任务步骤失败条件
	if (QuestData->FailConditions)
	{
		AddObjectInfo(QuestData->FailConditions);
	}
	// 任务步骤失败模式
	if (QuestData->FailedFallbackType)
	{
		AddObjectInfo(QuestData->FailedFallbackType);
	}
	// 任务步骤完成时离开位面设置
	if (QuestData->LeavePlaneAction)
	{
		AddObjectInfo(QuestData->LeavePlaneAction);
	}

	LuaTable->SetField(TEXT("ExtraInfo"), MakeShared<FLuaValueString>(ExtraInfo));
}
