#pragma once


#include "CoreMinimal.h"
#include "Templates/SharedPointer.h"
#include "Engine/DataTable.h"

class FQuestTablePreview : public TSharedFromThis<FQuestTablePreview>
{
public:
	virtual ~FQuestTablePreview(){};

public:
	static void CopyStructTableDataFromQuest(UDataTable* Table, class UQuest* InQuestData, TMap<FName, const uint8*>& TableData);
};