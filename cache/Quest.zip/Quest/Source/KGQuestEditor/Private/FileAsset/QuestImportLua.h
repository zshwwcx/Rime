#pragma once

#include "CoreMinimal.h"
#include "QuestTemplate.h"
#include "lua.hpp"
#include "LuaState.h"


typedef UObject* (*FTypeGetter)(int32, UObject* Outer);

class MakeLuaIndexTopGuard
{
public:
	MakeLuaIndexTopGuard() = delete;

	MakeLuaIndexTopGuard(lua_State* L, int ParamIndex);

	void Finish();

	// ~MakeLuaIndexTopGuard();

private:
	void* operator new(size_t t) = delete;  
	void  operator delete(void * ptr) = delete;

private:
	bool bOnTop = false;
	lua_State* L = nullptr;
};

class RestoreLuaStackGuard
{
public:
	RestoreLuaStackGuard() = delete;

	RestoreLuaStackGuard(lua_State* L, int PopNumber=1);

	void Finish();
	
	// ~RestoreLuaStackGuard();

private:
	void* operator new(size_t t) = delete;  
	void  operator delete(void * ptr) = delete;

private:
	int PopNumber = 0;
	lua_State* L = nullptr;
};

class FQuestImportLua
{
	
public:
	static FString GetPropertyDisPlayName(const FProperty* Property, bool bByStruct=false);
	
	template<typename T>
	static T* CheckCastAddress(void* Address);
	
	template<typename Func>
	static void TraverseArray(const TSharedPtr<FJsonValue>& JsonValue, Func TraverseAction);

	template<typename Func>
	static void TraverseTable(const TSharedPtr<FJsonValue>& JsonValue, Func TraverseAction);

	template<typename T>
	static bool DoFill(const TSharedPtr<FJsonValue>& JsonValue, T* Address, int ParamIndex);

	template<typename T>
	static bool FillNumber(const TSharedPtr<FJsonValue>& JsonValue, T* Address, int ParamIndex);
	
	template<typename T>
	static bool Fill(const TSharedPtr<FJsonValue>& JsonValue, void* Address, int ParamIndex);

	template<typename PropertyType>
	static bool Fill(PropertyType* Property, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer);
	
	static bool FillFProperty(FProperty* Property, void* Address, const TSharedPtr<FJsonValue>& JsonValue, int ParamIndex, UObject* Outer);

	// 通用的反序列化
	static bool FillObjWithLuaStr(UObject* InObj, const TSharedPtr<FJsonObject>& JsonObject);

	// 针对多种基类仅管理Type的对象使用的反序列化方法
	static bool FillTypedObjPropertyWithLuaStr(UObject* &InObj, const TSharedPtr<FJsonValue>& JsonValue, FString Field, FTypeGetter TypeGetter, UObject* Outer);
	// 针对多种基类仅管理Type的Object数组的反序列化方法
	static bool FillTypedObjArrayWithLuaStr(TArray<UObject*> &InObj, const TSharedPtr<FJsonValue>& JsonValue, FString Field, FTypeGetter TypeGetter, UObject* Outer);
	
	// Ring和Quest需要特殊处理Graph
	static bool FillObjWithLuaStr(UQuestChapter* InObj, const TSharedPtr<FJsonObject>& JsonObject);
	static bool FillObjWithLuaStr(UQuestRing* InObj, const TSharedPtr<FJsonObject>& JsonObject);
	static bool FillObjWithLuaStr(UQuest* InObj, const TSharedPtr<FJsonObject>& JsonObject);

	static void FillGraphCommentNode(class UEDGraphBase* GraphBase, const TSharedPtr<FJsonObject>& JsonObject);
	static bool FillChapterGraphWithLuaStr(UQuestChapter* InObj, const TSharedPtr<FJsonObject>& JsonObject);
	static bool FillRingGraphWithLuaStr(UQuestRing* InObj, const TSharedPtr<FJsonObject>& JsonObject);
	static bool FillQuestGraphWithLuaStr(UQuest* InObj, const TSharedPtr<FJsonObject>& JsonObject);

	static bool FillRingDataArrayWithLuaStr(UQuestRing* InObj, const TSharedPtr<FJsonObject>& JsonObject);
	static bool FillQuestDataArrayWithLuaStr(UQuest* InObj, const TSharedPtr<FJsonObject>& JsonObject);

	static bool FillQuestNextTaskWithLuaStr(UQuest* InObj, const TSharedPtr<FJsonObject>& JsonObject);
	static bool FillRingNextTaskWithLuaStr(UQuestRing* InObj, const TSharedPtr<FJsonObject>& JsonObject);

	template <typename ClassName>
	static bool InitializeClassList(const FString &BPFilePath, TMap<int32, TWeakObjectPtr<UClass>>& ClassList);
	static UObject* GetActionInstanceFromEvent(int32 Event, UObject* Outer);
	static UObject* GetTargetInstanceFromEvent(int32 Type, UObject* Outer);
	static UObject* GetApplyInstanceFromType(int32 Type, UObject* Outer);
	static UObject* GetRewardInstanceFromType(int32 Type, UObject* Outer);
	static UObject* GetSubmitInstanceFromType(int32 Type, UObject* Outer);
	static UObject* GetFailedFallbackInstanceFromType(int32 Type, UObject* Outer);
	static UObject* GetLeavePlaneInstanceFromType(int32 Type, UObject* Outer);
	static UObject* GetTraceParamInstanceFromType(int32 Type, UObject* Outer);
	static UObject* GetFailConditionInstanceFromEvent(int32 Type, UObject* Outer);
	static int32 ProcessTargetType(UQuestTargetBase* InQuestTarget);

	static void ClearRecordedUClass();
public:
	static TArray<TSharedPtr<FJsonValue>> GetQuestDataArrayInRingJObj(const TSharedPtr<FJsonObject>& RingJObj);
	static TSharedPtr<FJsonObject> GetQuestDataObjectInRingJObj(const TSharedPtr<FJsonObject>& RingJObj);
private:
	static TArray<TWeakObjectPtr<UClass>> RecordedUClass;
	static TMap<int32, TWeakObjectPtr<UClass>> ActionClass;
	static TMap<int32, TWeakObjectPtr<UClass>> TargetClass;
	static TMap<int32, TWeakObjectPtr<UClass>> FailConditionClass;
	static TMap<int32, TWeakObjectPtr<UClass>> ApplyClass;
	static TMap<int32, TWeakObjectPtr<UClass>> RewardClass;
	static TMap<int32, TWeakObjectPtr<UClass>> SubmitClass;
	static TMap<int32, TWeakObjectPtr<UClass>> FailedFallbackClass;
	static TMap<int32, TWeakObjectPtr<UClass>> LeavePlaneClass;
	static TMap<int32, TWeakObjectPtr<UClass>> TraceParamClass;
};
