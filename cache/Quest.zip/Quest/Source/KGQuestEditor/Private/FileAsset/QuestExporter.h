#pragma once

#include "ImportExport/LuaExporter.h"

// 导出运行时数据使用的基类
class FQuestExporter : public FLuaExporter
{
public:
	FQuestExporter();
	
	virtual TSharedPtr<FLuaValue> ExportObjectPropertyToLua(FObjectProperty* Prop, void* DataAddress, UObject* ParentObject) override;

	virtual TSharedPtr<FLuaValue> ExportClassPropertyToLua(FClassProperty* Prop, void* DataAddress) override;
	
	virtual TSharedPtr<FLuaValue> ExportStructPropertyToLua(UScriptStruct* ScriptStruct, void* DataAddress, UObject* ParentObject) override;

	virtual TSharedPtr<FLuaValue> ExportInt64PropertyToLua(FInt64Property* Prop, void* DataAddress) override;

	virtual bool IsInnerObjectPropertyNeedExport(FProperty* Prop, UObject* Object, UClass* ObjectClass) override;

	virtual bool IsNeedExportArrayInnerNullObject() override {return false;}

	bool bForceExportDefaultValue = false;
};

// 导出编辑器态数据使用的基类
class FQuestEditorExporter : public FQuestExporter
{
public:
	FQuestEditorExporter();

	virtual bool IsInnerObjectPropertyNeedExport(FProperty* Prop, UObject* Object, UClass* ObjectClass) override;
};

// 导出章节的运行时数据
class FQuestChapterExporter : public FQuestExporter
{
	
};

// 导出环的运行时数据
class FQuestRingExporter : public FQuestExporter
{
	
};

// 导出单个任务的运行时数据
class FQuestDataExporter : public FQuestExporter
{
	
};

// 导出环的编辑器态数据
class FQuestRingEditorExporter : public FQuestEditorExporter
{
	
};

// 导出CDO数据
class FQuestCDOExporter : public FQuestExporter
{
public:
	FQuestCDOExporter();
};

// 给任务编辑器封装好的直接使用的接口
class FQuestLuaExporter
{
public:
	static FString ExportChapterData(class UQuestChapter* ChapterData);

	static void ExportChapterDataToLuaTable(class UQuestChapter* ChapterData, const TSharedPtr<FLuaTable>& LuaTable);
	
	static FString ExportRingData(class UQuestRing* RingData, const TMap<FString, FString>* ExProperties = nullptr, bool bParseSystemActions = true);
	
	static void ExportRingDataToLuaTable(class UQuestRing* RingData, const TSharedPtr<FLuaTable>& LuaTable, const TMap<FString, FString>* ExProperties = nullptr);

	static void ProcessSystemActions(const TArray<class UQuestSystemActionBase*>& Actions, const FString& PropertyName, const TSharedPtr<FLuaTable>& LuaTable);

	static void ExportQuestDataToLuaTable(class UQuest* QuestData, const TSharedPtr<FLuaTable>& LuaTable, const TMap<FString, FString>* ExProperties = nullptr);

	static UQuest* GetFinalQuestDataToExport(UQuest* QuestData);

	static FString ExportCDO();

	static TArray<TPair<FString, TSharedPtr<FLuaValueIntTable>>> SystemActionLuaTables;
private:
	static void ExportRingExtraInfo(class UQuestRing* RingData, TSharedPtr<FLuaTable> LuaTable);

	static void ExportQuestExtraInfo(class UQuest* QuestData, TSharedPtr<FLuaTable> LuaTable);
};