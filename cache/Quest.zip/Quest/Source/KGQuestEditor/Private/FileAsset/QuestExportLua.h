#pragma once

#include "CoreMinimal.h"
#include "JsonObjectConverter.h"
#include "../EDGraph/Nodes/EDGraphNode_StateNode.h"
#include "QuestTemplate.h"

class FActionConditionExportLua
{
public:
	TWeakObjectPtr<UQuestActionConditionBase> TransitionCondition;

	FString FromUniqueID;

	FString ToUniqueID;
};

class FQuestExportLua
{
public:
	static FString GetPropertyDisPlayName(const FProperty* Property, bool bByStruct=false);

	template<typename T>
	static T* CheckCastAddress(void* Address);

	static FString JsonValueToLuaStr(TSharedPtr<FJsonValue> RootJsonValue, const FString Field);

	static FString JsonValueToLua_Implementation(TSharedPtr<FJsonObject> JsonObject);

	static FString DumpLua(FString InKey, TSharedPtr<FJsonValue> InValue, int Indent, bool bFromArray);

	static void GetChildNodes(UEDGraphNode_Base* ParentNode, EDNodeType TargetType, TArray<UEDGraphNode_Base*>& OutChildNodes);
	static void GetChildNodes(UEDGraphNode_Base* ParentNode, const TCHAR* PinName, EDNodeType TargetType, TArray<UEDGraphNode_Base*>& OutChildNodes);
	static void GetChildNodesData(UEDGraphNode_Base* ParentNode, EDNodeType TargetType, TArray<class UQuestDataBase*>& OutChildNodeDatas, bool bReCursive=false);
	static void GetChildNodesData(UEDGraphNode_Base* ParentNode, const TCHAR* PinName, EDNodeType TargetType, TArray<class UQuestDataBase*>& OutChildNodeDatas, bool bReCursive=false);
	static void GetChildNodesData(UEDGraphNode_Base* ParentNode, EDNodeType TargetType1, EDNodeType TargetType2, TArray<class UQuestDataBase*>& OutChildNodeDatas, bool bReCursive=false);
	
public:
	template<typename T>
	static TSharedPtr<FJsonValue> DoExport(T* Address);
	
	template<typename T>
	static TSharedPtr<FJsonValue> Export(void *Address);

	template<typename T, typename JsonValueType>
	static TSharedPtr<FJsonValue> DoExport(T* Address);
	
	template<typename T, typename JsonValueType>
	static TSharedPtr<FJsonValue> Export(void *Address);

	template<typename PropertyType>
	static TSharedPtr<FJsonValue> Export(PropertyType* Property, void* Address);

	static TSharedPtr<FJsonValue> ExportFProperty(FProperty* Property, void* Address);

	static void InnerExportObjectData(UObject* Obj, TSharedPtr<FJsonObject> JsonObject, const TMap<FString, FString>* ExPropertys = nullptr, const TMap<FString, int32>* ExIntPropertys = nullptr);

	static void InnerExportObjectDataAll(UObject* Obj, TSharedPtr<FJsonObject> JsonObject, const TMap<FString, FString>* ExPropertys = nullptr, const TMap<FString, int32>* ExIntPropertys = nullptr);
	
	static void InnerExportActionConditionData(FActionConditionExportLua* Obj, TSharedPtr<FJsonObject> JsonObject);

	static void ExportQuestExtraInfo(class UQuest* QuestData, TSharedPtr<FJsonObject> JsonObject);
	static void ExportRingExtraInfo(class UQuestRing* RingData, TSharedPtr<FJsonObject> JsonObject);

	static bool PreCheckQuestData(class UQuest* QuestData);
	
	static FString ExportChapterData(class UQuestChapter* ChapterData, const TMap<FString, FString>* ExPropertys = nullptr);

	static TSharedPtr<FJsonObject> ExportQuestJsonValue(class UQuest* QuestData, const TMap<FString, FString>* ExPropertys = nullptr);
	static TSharedPtr<FJsonObject> ExportQuestJsonValueProcessed(class UQuest* QuestData, const TMap<FString, FString>* ExPropertys = nullptr);

	static  FString ExportQuestCSV(class UQuest* QuestData, const TArray<FString> &Titles);
	
	static FString ExportQuestData(class UQuest* QuestData, const TMap<FString, FString>* ExPropertys = nullptr);
	static FString ExportQuestDataProcessed(class UQuest* QuestData, const TMap<FString, FString>* ExPropertys = nullptr);

	static TSharedPtr<FJsonObject> DoExportQuest(class UQuest* QuestData, bool bAsset, const TMap<FString, FString>* ExPropertys = nullptr);

	static TSharedPtr<FJsonObject> ExportRingJsonValue(class UQuestRing* RingData, const TMap<FString, FString>* ExPropertys = nullptr);

	static FString ExportRingCSV(class UQuestRing* RingData, const TArray<FString> &Titles);
	
	static FString ExportRingData(class UQuestRing* RingData, const TMap<FString, FString>* ExPropertys = nullptr);

	static void ExportCommentNode(class UEdGraphNode_Comment* CommentNode, TArray<TSharedPtr<FJsonValue>>& JCommentArray);
private:
	static void ProcessKey(FString& InKey);
};
