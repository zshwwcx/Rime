#include "QuestImporter.h"

#include "EdGraphNode_Comment.h"
#include "FQuestObjectivesEditor.h"
#include "QuestObjectDataEntity.h"
#include "QuestTemplate.h"
#include "LuaSerialization/Serialization/LuaReader.h"
#include "QuestSettings.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "EDGraph/Graph/EventDrivenGraphSchema.h"
#include "EDGraph/Nodes/EDGraphNode_StateNode.h"
#include "LuaSerialization/Serialization/LuaSerializer.h"
#include "QTE/BSQTEObject.h"

TArray<TWeakObjectPtr<UClass>> FQuestImporter::RecordedUClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::PreInfoClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::ActionClass;
TMap<FString, TWeakObjectPtr<UClass>> FQuestImporter::SystemActionClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::TargetClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::FailConditionClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::ApplyClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::RewardClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::SubmitClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::FailedFallbackClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::LeavePlaneClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::TraceParamClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::RingTaskConditionBaseClass;
TMap<int32, TWeakObjectPtr<UClass>> FQuestImporter::BSQTEDataClass;
bool FQuestImporter::bClassListInited = false;

#define PROCESS_CLASS_TYPE(ClassType, ClassMap) \
if (PropertyClass->IsChildOf(ClassType::StaticClass())) { \
FillTypedObjPropertyWithLuaTable<ClassType>(Property, Address, LuaValue, Outer, ClassMap); \
return true; \
}

FQuestImporter::FQuestImporter()
	: FLuaImporter()
{
	MathDataImportMethod = EMathDataImportExportMethod::Constructor;
}

FQuestImporter::FQuestImporter(const bool InLoadSpecialObject)
	: FLuaImporter()
	, bLoadSpecialObject(InLoadSpecialObject)
{
	MathDataImportMethod = EMathDataImportExportMethod::Constructor;
}

void FQuestImporter::ImportLuaToObj(const TSharedPtr<class FLuaTable> LuaTable, UObject* OutObject)
{
	InitAssignersAndAllClassList();
	ImportLuaToObjInner(LuaTable, OutObject);
}

void FQuestImporter::ImportLazyPropertiesFromLuaToObj(TSharedPtr<class FLuaTable> LuaTable, UObject* OutObject)
{
	InitAssignersAndAllClassList();
	for (FProperty* Property : TFieldRange<FProperty>(OutObject->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		const FString PropertyName = Property->GetName();
		if (!Property->HasMetaData("QuestLazyImport"))
		{
			continue;
		}
		if (LuaTable->Values.Contains(PropertyName))
		{
			void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(OutObject);
			FillFProperty(Property, PropertyAddress, LuaTable->Values[PropertyName], OutObject);
		}
	}
}

void FQuestImporter::FillObjectPropertyByName(const FString& PropertyName, const TSharedPtr<class FLuaTable>& LuaTable, UObject* OutObject)
{
	InitAssignersAndAllClassList();
	FProperty* Property = OutObject->GetClass()->FindPropertyByName(*PropertyName);
	void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(OutObject);
	if (LuaTable->Values.Contains(PropertyName))
	{
		FillFProperty(Property, PropertyAddress, LuaTable->Values[PropertyName], OutObject);
	}
}

void FQuestImporter::ImportLuaToObjInner(const TSharedPtr<class FLuaTable>& LuaTable, UObject* OutObject)
{
	for (FProperty* Property : TFieldRange<FProperty>(OutObject->GetClass(), EFieldIteratorFlags::IncludeSuper))
	{
		const FString PropertyName = Property->GetName();
		if (LuaTable->Values.Contains(PropertyName))
		{
			void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(OutObject);
			FillFProperty(Property, PropertyAddress, LuaTable->Values[PropertyName], OutObject);
		}
	}
}

bool FQuestImporter::ProcessQuestSpecialObjectType(const FObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer)
{
	UClass* PropertyClass = Property->PropertyClass;
	PROCESS_CLASS_TYPE(UQuestActionBase, ActionClass)
	PROCESS_CLASS_TYPE(UQuestSystemActionBase, SystemActionClass)
	PROCESS_CLASS_TYPE(UQuestTargetBase, TargetClass)
	PROCESS_CLASS_TYPE(UQuestEndConditionBase, FailConditionClass)
	PROCESS_CLASS_TYPE(UApplyBase, ApplyClass)
	PROCESS_CLASS_TYPE(URewardBase, RewardClass)
	PROCESS_CLASS_TYPE(USubmitBase, SubmitClass)
	PROCESS_CLASS_TYPE(UFailedFallbackBase, FailedFallbackClass)
	PROCESS_CLASS_TYPE(ULeavePlaneBase, LeavePlaneClass)
	PROCESS_CLASS_TYPE(UTaskTargetTrace, TraceParamClass)
	PROCESS_CLASS_TYPE(UPreRingInfo, PreInfoClass)
	PROCESS_CLASS_TYPE(URingTaskConditionBase, RingTaskConditionBaseClass)
	PROCESS_CLASS_TYPE(UBSQTEData, BSQTEDataClass)
	return ProcessQuestCommonSubObjectType(Property, Address, LuaValue, Outer);
}

bool FQuestImporter::ProcessQuestCommonSubObjectType(const FObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer)
{
	UClass* PropertyClass = Property->PropertyClass;
	if (LuaValue.IsValid() && LuaValue->Type != ELua::Table)
	{
		return false;
	}
	TSharedPtr<FLuaTable> LuaTable = LuaValue->AsTable();
	if (LuaTable->Values.IsEmpty())
	{
		return false;
	}
	UObject* Obj = NewObject<UObject>(Outer, PropertyClass);
	if (!Obj)
	{
		return false;
	}
	ImportLuaToObjInner(LuaTable, Obj);
	Property->SetObjectPropertyValue(Address, Obj);
	if (PropertyClass == URingTaskConditionClass::StaticClass())
	{
		if (URingTaskConditionClass* RingTaskCondition = Cast<URingTaskConditionClass>(Obj))
		{
			RingTaskCondition->FlowChartPath.Path = RingTaskCondition->Key;
		}
	}
	return true;
}

bool FQuestImporter::FillFObjectProperty(const FObjectProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer)
{
	if (bLoadSpecialObject && ProcessQuestSpecialObjectType(Property, Address, LuaValue, Outer))
	{
		return true;
	}
	return true;
}

bool FQuestImporter::FillStructProperty(const FStructProperty* Property, void* Address, const TSharedPtr<class FLuaValue>& LuaValue, UObject* Outer)
{
	UScriptStruct* Struct = Property->Struct;
	if (Struct->IsChildOf(FGameplayID::StaticStruct()))
	{
		if (FGameplayID* GameplayID = static_cast<FGameplayID*>(Address))
		{
			auto Number = LuaValue->AsNumber();
			if (Number != 0)
			{
				GameplayID->ID = Number;
				return true;
			}
		}
		return false;
	}
	else if (Struct->IsChildOf(FFlowChartPath::StaticStruct()))
	{
		if (FFlowChartPath* FlowChartPath = static_cast<FFlowChartPath*>(Address))
		{
			auto Path = LuaValue->AsString();
			FlowChartPath->Path = Path;
			return true;
		}
		return false;
	}
	return FLuaImporter::FillStructProperty(Property, Address, LuaValue, Outer);
}

void FQuestImporter::InitAssignersAndAllClassList()
{
	InitAssigners();
	InitializeAllClassList();
}

void FQuestImporter::InitializeAllClassList()
{
	if (bClassListInited)
	{
		return;
	}
	TArray<FString> BPFilePaths = {TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestAction"), TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestActions")};
	InitializeClassList<UQuestActionBase>(BPFilePaths, ActionClass);

	BPFilePaths = {TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestTarget"), TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestTargets")};
	InitializeClassList<UQuestTargetBase>(BPFilePaths, TargetClass);

	BPFilePaths = {TEXT("/Game/Editor/QuestEditor/TemplatePart/FailCondition")};
	InitializeClassList<UQuestEndConditionBase>(BPFilePaths, FailConditionClass);

	BPFilePaths = {TEXT("/Game/Editor/QuestEditor/TemplatePart/ReceiveType")};
	InitializeClassList<UApplyBase>(BPFilePaths, ApplyClass);

	BPFilePaths = {TEXT("/Game/Editor/QuestEditor/TemplatePart/RewardType")};
	InitializeClassList<URewardBase>(BPFilePaths, RewardClass);

	BPFilePaths = {TEXT("/Game/Editor/QuestEditor/TemplatePart/SubmitType")};
	InitializeClassList<USubmitBase>(BPFilePaths, SubmitClass);

	BPFilePaths = {TEXT("/Game/Editor/QuestEditor/TemplatePart/FailedFallback")};
	InitializeClassList<UFailedFallbackBase>(BPFilePaths, FailedFallbackClass);

	BPFilePaths = {TEXT("/Game/Editor/QuestEditor/TemplatePart/LeavePlaneType")};
	InitializeClassList<ULeavePlaneBase>(BPFilePaths, LeavePlaneClass);

	BPFilePaths = {TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestTrace")};
	InitializeClassList<UTaskTargetTrace>(BPFilePaths, TraceParamClass);

	BPFilePaths = {TEXT("/Game/Editor/QTEData")};
	InitializeClassList<UBSQTEData>(BPFilePaths, BSQTEDataClass);

	PreInfoClass.Add(0, UPreRingInfo::StaticClass());
	PreInfoClass.Add(1, UPreRingID::StaticClass());
	PreInfoClass.Add(2, UAndRelation::StaticClass());
	PreInfoClass.Add(3, UOrRelation::StaticClass());

	if (UClass* RingConditionClass = GetRingConditionClass())
	{
		RingTaskConditionBaseClass.Add(0, RingConditionClass);
	}

	bClassListInited = true;
}

void FQuestImporter::InitializeSystemActionClassList(const TMap<FString, UClass*>& ClassList)
{
	SystemActionClass.Empty();
	for (auto Pair : ClassList)
	{
		SystemActionClass.Add(Pair);
	}
}

template <typename ClassName>
bool FQuestImporter::InitializeClassList(const TArray<FString>& BPFilePaths, TMap<int32, TWeakObjectPtr<UClass>>& ClassList)
{
	if (ClassList.Num() == 0)
	{
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

		FARFilter Filter;
		for (auto BPFilePath : BPFilePaths)
		{
			Filter.PackagePaths.Add(*BPFilePath);
		}
		Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;

		// Get the assets
		TArray<FAssetData> AssetDataList;
		AssetRegistry.GetAssets(Filter, AssetDataList);

		for (auto Asset : AssetDataList)
		{
			UObject* Obj = Asset.GetAsset();
			UClass* Class = Obj->GetClass();
			if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
			{
				Class = BPObj->GeneratedClass;
			}
			if (!Class->IsChildOf(ClassName::StaticClass()))
			{
				continue;
			}
			ClassName* InitiateTarget = NewObject<ClassName>(GetTransientPackage(), Class);
			Class->AddToRoot();
			RecordedUClass.Add(Class);
			ClassList.Add(GetClassType<ClassName>(InitiateTarget), Class);
		}
	}
	return true;
}

UClass* FQuestImporter::GetRingConditionClass()
{
	UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass());
	if (!QuestSettings)
	{
		return nullptr;
	}
	FSoftObjectPath SoftPath = QuestSettings->RingConditionClass;
	if (!SoftPath.IsValid())
	{
		return nullptr;
	}
	UObject* Obj = SoftPath.ResolveObject();
	if (Obj == nullptr)
	{
		Obj = SoftPath.TryLoad();
	}
	if (Obj == nullptr)
	{
		return nullptr;
	}
	UClass* Class = Obj->GetClass();
	if (const UBlueprint* BPObj = Cast<UBlueprint>(Obj))
	{
		Class = BPObj->GeneratedClass;
	}
	Class->AddToRoot();
	return Class;
}

template <typename ClassName, typename KeyType>
bool FQuestImporter::FillTypedObjPropertyWithLuaTable(const FObjectProperty* Property, void* Address, const TSharedPtr<FLuaValue>& LuaValue, UObject* Outer, TMap<KeyType, TWeakObjectPtr<UClass>>& ClassList)
{
	if (LuaValue.IsValid() && LuaValue->Type != ELua::Table)
	{
		return false;
	}
	TSharedPtr<FLuaTable> LuaTable = LuaValue->AsTable();
	
	// 真正创建Object
	ClassName* Obj = GetInstanceFromType<ClassName>(LuaTable, Outer, ClassList);
	if (!Obj)
	{
		return false;
	}
	ImportLuaToObjInner(LuaTable, Obj);
	Property->SetObjectPropertyValue(Address, Obj);
	return true;
}

template<typename KeyType>
struct FLuaValueConverter;

// 特化int32
template<>
struct FLuaValueConverter<int32>
{
	static int32 Convert(const TSharedPtr<FLuaValue>& Value)
	{
		return static_cast<int32>(Value->AsNumber());
	}
};

// 特化FString
template<>
struct FLuaValueConverter<FString>
{
	static FString Convert(const TSharedPtr<FLuaValue>& Value)
	{
		return Value->AsString();
	}
};

template <typename ClassName, typename KeyType>
ClassName* FQuestImporter::GetInstanceFromType(TSharedPtr<FLuaTable> LuaTable, UObject* Outer, TMap<KeyType, TWeakObjectPtr<UClass>>& ClassList)
{
	FString TypeKey = GetClassTypeKeyString<ClassName>();
	if (!LuaTable->Values.Contains(TypeKey))
	{
		return nullptr;
	}
	KeyType InstanceType = FLuaValueConverter<KeyType>::Convert(LuaTable->Values[TypeKey]);
	if (ClassList.Contains(InstanceType))
	{
		const UClass* Class = ClassList[InstanceType].Get();
		return NewObject<ClassName>(Outer, Class);
	}
	return nullptr;
}

template <>
URingTaskConditionBase* FQuestImporter::GetInstanceFromType<URingTaskConditionBase>(TSharedPtr<FLuaTable> LuaTable, UObject* Outer, TMap<int32, TWeakObjectPtr<UClass>>& ClassList)
{
	if (!ClassList.IsEmpty())
	{
		UClass* Class = ClassList[0].Get();
		return NewObject<URingTaskConditionBase>(Outer, Class);
	}
	return nullptr;
}

template <typename ClassName>
FString FQuestImporter::GetClassTypeKeyString()
{
	return TEXT("Type");
}

template <>
FString FQuestImporter::GetClassTypeKeyString<UQuestActionBase>()
{
	return TEXT("Event");
}

template <>
FString FQuestImporter::GetClassTypeKeyString<UQuestSystemActionBase>()
{
	return TEXT("ActionTypeName");
}

template <>
FString FQuestImporter::GetClassTypeKeyString<UBSQTEData>()
{
	return TEXT("QTEType");
}

template <typename ClassName>
int32 FQuestImporter::GetClassType(ClassName* Instance)
{
	return Instance->Type;
}

template <>
int32 FQuestImporter::GetClassType<UQuestActionBase>(UQuestActionBase* Instance)
{
	return Instance->Event;
}

template <>
int32 FQuestImporter::GetClassType<UQuestTargetBase>(UQuestTargetBase* Instance)
{
	// 5和15有两种Target资产, 这里做成-5和-15
	if (Instance->Type == 5)
	{
		FProperty* MapID = Instance->GetClass()->FindPropertyByName("MapID");
		if (MapID) return -Instance->Type;
	}
	if (Instance->Type == 15)
	{
		FProperty* MapID = Instance->GetClass()->FindPropertyByName("MapID");
		if (MapID) return -Instance->Type;
	}
	return Instance->Type;
}

template <>
int32 FQuestImporter::GetClassType<UBSQTEData>(UBSQTEData* Instance)
{
	if (Instance && Instance->GetClass())
	{
		FProperty* QTETypeProperty = Instance->GetClass()->FindPropertyByName(TEXT("QTEType"));
		if (QTETypeProperty && QTETypeProperty->IsA<FByteProperty>())
		{
			if (FByteProperty* ByteProp = CastField<FByteProperty>(QTETypeProperty))
			{
				uint8 QTETypeData = 0;
				ByteProp->GetValue_InContainer(Instance, &QTETypeData);
				return QTETypeData;
			}
		}
	}
	return -1;
}

TSharedPtr<FLuaTable> FQuestLuaImporter::ConvertLuaFileToLuaTable(const FString& LuaPath)
{
	FString LuaStr;
	if (!FFileHelper::LoadFileToString(LuaStr, *LuaPath))
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to read file: %s"), *LuaPath);
		return nullptr;
	}
	const FString StartStr = TEXT("return");
	LuaStr.TrimStartInline();
	LuaStr = LuaStr.Right(LuaStr.Len() - StartStr.Len());
	LuaStr.TrimStartInline();

	TSharedPtr<FLuaValue> LuaValue = nullptr;
	const TSharedRef<TLuaReader<>> LuaReader = TLuaReaderFactory<>::Create(LuaStr);
	if (FLuaSerializer::Deserialize(LuaReader, LuaValue) && LuaValue.IsValid())
	{
		return LuaValue->AsTable();
	}
	return nullptr;
}

UEDGraphNode_StateNodeBase* FQuestLuaImporter::FindNodeByInstance(UEdGraph* Graph, UObject* Instance)
{
	for (UEdGraphNode* GraphNode : Graph->Nodes)
	{
		if (auto StateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
		{
			if (StateNode->NodeInstance == Instance)
			{
				return StateNode;
			}
		}
	}
	return nullptr;
}

UEDGraphNode_StateNodeBase* FQuestLuaImporter::FindChapterEndByQuestObjectID(UEdGraph* Graph, const UQuestRing* Ring)
{
	for (UEdGraphNode* GraphNode : Graph->Nodes)
	{
		if (auto StateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
		{
			if (UChapterEnd* ChapterEnd = Cast<UChapterEnd>(StateNode->NodeInstance))
			{
				if (ChapterEnd->NextRingID == Ring->QuestObjectID)
				{
					return StateNode;
				}
			}
		}
	}
	return nullptr;
}

bool FQuestLuaImporter::FillChapterGraphWithLuaTable(UQuestChapter* InObj, const TSharedPtr<FLuaTable>& LuaTable)
{
	if (!InObj || !InObj->ChapterGraph)
	{
		UE_LOG(LogTemp, Warning, TEXT("FillChapterGraphWithLuaTable: Invalid InObj!"));
		return false;
	}

	// 数据以EditorOnly为准
	TSharedPtr<FLuaTable> EditorOnlyObject = LuaTable->GetTableField(TEXT("EditorOnly"));

	const UEventDrivenGraphSchema* Schema = Cast<const UEventDrivenGraphSchema>(InObj->ChapterGraph->GetSchema());
	UEDGraphBase* ChapterGraphBase = Cast<UEDGraphBase>(InObj->ChapterGraph);

	if (Schema == nullptr || ChapterGraphBase == nullptr)
	{
		return false;
	}

	if (!ChapterGraphBase->QuestObjectivesEditor.IsValid())
	{
		return false;
	}
	FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(ChapterGraphBase->QuestObjectivesEditor.Pin().Get());

	if (QuestEditor == nullptr)
	{
		return false;
	}

	// ChapterGraph的反序列化
	// 1. 处理Ring节点
	const TSharedPtr<FLuaTable>* RingNodeTable = nullptr;
	if (EditorOnlyObject->TryGetTableField(TEXT("RingNode"), RingNodeTable))
	{
		for (const auto& RingNodePair : (*RingNodeTable)->Values)
		{
			auto RingNode = RingNodePair.Value->AsTable();
			if (RingNode.IsValid())
			{
				double RingIDResult = RingNode->GetNumberField(TEXT("RingID"));
				// 创建Ring节点
				if (UQuestRing* TargetRing = QuestEditor->GetRingObjByRingID(RingIDResult))
				{
					double PosXResult = RingNode->GetNumberField(TEXT("PosX"));
					double PosYResult = RingNode->GetNumberField(TEXT("PosY"));
					Schema->CreateRingNode(ChapterGraphBase, TargetRing, FVector2D(PosXResult, PosYResult), true);
				}
			}
		}
	}

	// 2. 处理End节点
	const TSharedPtr<FLuaTable>* EndNodeTable = nullptr;
	if (EditorOnlyObject->TryGetTableField(TEXT("EndNode"), EndNodeTable))
	{
		for (const auto& EndNodePair : (*EndNodeTable)->Values)
		{
			if (TSharedPtr<FLuaTable> EndNodeObj = EndNodePair.Value->AsTable())
			{
				// 创建ChapterEnd节点
				if (UChapterEnd* EndTarget = NewObject<UChapterEnd>(InObj))
				{
					double RingIDResult = EndNodeObj->GetNumberField(TEXT("NextRingID"));
					FString DescResult = EndNodeObj->GetStringField(TEXT("Desc"));
					double PosXResult = EndNodeObj->GetNumberField(TEXT("PoxX"));
					double PosYResult = EndNodeObj->GetNumberField(TEXT("PosY"));
					EndTarget->NextRingID = RingIDResult;
					EndTarget->Desc = DescResult;
					QuestEditor->GetDataEntity()->ChapterEnds.Add(EndTarget);
					FVector2D NewPlacePos = FVector2D(PosXResult, PosYResult);
					Schema->CreateChapterEndNode(ChapterGraphBase, EndTarget, NewPlacePos, true);
				}
			}
		}
	}

	// 3. 处理Comment节点
	FillGraphCommentNode(ChapterGraphBase, EditorOnlyObject);

	// 4. 处理Ring节点的连线
	for (auto Child : InObj->Children)
	{
		if (UQuestRing* FromRing = Cast<UQuestRing>(Child))
		{
			UEDGraphNode_StateNodeBase* FromNode = FindNodeByInstance(ChapterGraphBase, FromRing);
			auto TempTaskInfoList = FromRing->NextTaskInfoList;
			for (auto NextTaskInfo : TempTaskInfoList)
			{
				int NextTaskID = NextTaskInfo->NextTaskID;
				UQuestRing* NextRing = QuestEditor->GetRingObjByRingID(NextTaskID);
				if (!NextRing || !NextRing->Father)
				{
					continue;
				}
				UEDGraphNode_StateNodeBase* ToNode = NextRing->Father == InObj ? FindNodeByInstance(ChapterGraphBase, NextRing) : FindChapterEndByQuestObjectID(ChapterGraphBase, NextRing);

				if (FromNode && ToNode)
				{
					// 连线
					Schema->TryCreateConnection(FromNode->GetOutputPin(), ToNode->GetInputPin());
				}
			}
		}
	}
	return true;
}

void FQuestLuaImporter::FillGraphCommentNode(UEDGraphBase* GraphBase, const TSharedPtr<FLuaTable>& LuaTable)
{
	const TSharedPtr<FLuaTable>* CommentNodeTable = nullptr;
	if (LuaTable->TryGetTableField(TEXT("CommentNode"), CommentNodeTable))
	{
		TSharedPtr<FQuestImporter> QuestImporter = MakeShared<FQuestImporter>();
		for (const auto& CommentNodePair : (*CommentNodeTable)->Values)
		{
			if (TSharedPtr<FLuaTable> CommentNodeObj = CommentNodePair.Value->AsTable())
			{
				// 创建ChapterComment节点
				if (GraphBase)
				{
					UEdGraphNode_Comment* GraphNode_Comment = NewObject<UEdGraphNode_Comment>(GraphBase);
					QuestImporter->ImportLuaToObj(CommentNodeObj, GraphNode_Comment);
					GraphBase->AddNode(GraphNode_Comment);
					GraphNode_Comment->bCanRenameNode = true;
				}
			}
		}
	}
}

bool FQuestLuaImporter::FillRingGraphAndObjDataWithLuaTable(UQuestRing* InObj, const TSharedPtr<FLuaTable>& LuaTable)
{
	if (!InObj || !InObj->RingGraph)
	{
		UE_LOG(LogTemp, Warning, TEXT("FillRingGraphAndObjDataWithLuaTable: Invalid InObj!"));
		return false;
	}
	UEDGraphBase* RingGraphBase = Cast<UEDGraphBase>(InObj->RingGraph);
	if (RingGraphBase == nullptr)
	{
		return false;
	}
	if (!RingGraphBase->QuestObjectivesEditor.IsValid())
	{
		return false;
	}

	FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(RingGraphBase->QuestObjectivesEditor.Pin().Get());
	if (QuestEditor == nullptr)
	{
		return false;
	}
	const UEventDrivenGraphSchema* EventDrivenSchema = Cast<const UEventDrivenGraphSchema>(RingGraphBase->GetSchema());
	// 数据以EditorOnly为准
	TSharedPtr<FLuaTable> EditorOnlyObject = LuaTable->GetTableField(TEXT("EditorOnly"));

	// RingGraph的反序列化
	const TSharedPtr<FLuaTable>* QuestNodeAndConnection = nullptr;
	const TSharedPtr<FLuaTable>* QuestNodeTable = nullptr;
	if (EditorOnlyObject->TryGetTableField(TEXT("QuestNodeAndConnection"), QuestNodeAndConnection))
	{
		TMap<UEDGraphNode_StateNodeBase*, TArray<int32>> QuestConnections;
		for (const auto& QuestNodePair : (*QuestNodeAndConnection)->Values)
		{
			const int32 QuestIDResult = FCString::Atoi(*QuestNodePair.Key);
			UQuest* FromQuest = QuestEditor->GetQuestObjByQuestID(QuestIDResult);
			if (FromQuest == nullptr)
			{
				continue;
			}
			FString QuestNodeAndConnectionStr = QuestNodePair.Value->AsString();
			TArray<FString> QuestNodeAndConnections;
			QuestNodeAndConnectionStr.ParseIntoArray(QuestNodeAndConnections, TEXT(","));
			if (QuestNodeAndConnections.Num() >= 2)
			{
				const double PosXResult = FCString::Atoi(*QuestNodeAndConnections[0]);
				const double PosYResult = FCString::Atoi(*QuestNodeAndConnections[1]);
				QuestEditor->LoadQuestGraphNew(FromQuest, LuaTable);
				if (EventDrivenSchema == nullptr)
				{
					continue;
				}
				EventDrivenSchema->CreateQuestNode(RingGraphBase, FromQuest, FVector2D(PosXResult, PosYResult), true);
				UEDGraphNode_StateNodeBase* FromNode = FindNodeByInstance(RingGraphBase, FromQuest);
				if (FromNode == nullptr)
				{
					continue;
				}
				for (int32 Index = 2; Index < QuestNodeAndConnections.Num(); ++Index)
				{
					const int32 ToQuestID = FCString::Atoi(*QuestNodeAndConnections[Index]);
					TArray<int32>& EndNodeIDs = QuestConnections.FindOrAdd(FromNode);
					EndNodeIDs.Add(ToQuestID);
				}
			}
		}
		for (auto Pair : QuestConnections)
		{
			for (int32 QuestID : Pair.Value)
			{
				UQuest* ToQuest = QuestEditor->GetQuestObjByQuestID(QuestID);
				if (ToQuest == nullptr)
				{
					continue;
				}
				const UEDGraphNode_StateNodeBase* ToNode = FindNodeByInstance(RingGraphBase, ToQuest);
				if (ToNode == nullptr)
				{
					continue;
				}
				EventDrivenSchema->TryCreateConnection(Pair.Key->GetOutputPin(), ToNode->GetInputPin());
			}
			
		}
	}
	else
	{
		if (EditorOnlyObject->TryGetTableField(TEXT("QuestNode"), QuestNodeTable))
		{
			for (const auto& QuestNodePair : (*QuestNodeTable)->Values)
			{
				if (QuestNodePair.Value->Type == ELua::Table)
				{
					auto QuestNodeObj = QuestNodePair.Value->AsTable();
					int32 QuestIDResult = QuestNodeObj->GetIntegerField(TEXT("QuestID"));
					double PosXResult = QuestNodeObj->GetNumberField(TEXT("PosX"));
					double PosYResult = QuestNodeObj->GetNumberField(TEXT("PosY"));
					// 创建Quest节点
					if (UQuest* TargetQuest = QuestEditor->GetQuestObjByQuestID(QuestIDResult))
					{
						QuestEditor->LoadQuestGraphNew(TargetQuest, LuaTable);
						if (EventDrivenSchema)
						{
							FVector2D NewPlacePos = FVector2D(PosXResult, PosYResult);
							EventDrivenSchema->CreateQuestNode(RingGraphBase, TargetQuest, NewPlacePos, true);
						}
					}
				}
			}
		}

		// 2. 处理Quest节点的连线
		const TSharedPtr<FLuaTable>* QuestConnectionTable = nullptr;
		if (EditorOnlyObject->TryGetTableField(TEXT("QuestConnection"), QuestConnectionTable))
		{
			for (const auto& QuestConnectionPair : (*QuestConnectionTable)->Values)
			{
				TArray<double> ToQuestIDResults;
				if (QuestConnectionPair.Value->Type == ELua::Table)
				{
					auto QuestConnectionObj = QuestConnectionPair.Value->AsTable();
					double FromQuestIDResult = QuestConnectionObj->GetNumberField(TEXT("FromQuestID"));
					double ToQuestID = QuestConnectionObj->GetNumberField(TEXT("ToQuestID"));
					// 根据连线信息连接Quest节点
					UQuest* FromQuest = QuestEditor->GetQuestObjByQuestID(FromQuestIDResult);
					if (FromQuest == nullptr)
					{
						continue;
					}
					UEDGraphNode_StateNodeBase* FromNode = FindNodeByInstance(RingGraphBase, FromQuest);
					if (FromNode == nullptr)
					{
						continue;
					}
					UQuest* ToQuest = QuestEditor->GetQuestObjByQuestID(ToQuestID);
					if (ToQuest == nullptr)
					{
						continue;
					}
					const UEDGraphNode_StateNodeBase* ToNode = FindNodeByInstance(RingGraphBase, ToQuest);
					if (ToNode == nullptr)
					{
						continue;
					}
					if (EventDrivenSchema)
					{
						// 连线
						EventDrivenSchema->TryCreateConnection(FromNode->GetOutputPin(), ToNode->GetInputPin());
					}
				}
			}
		}
	}

	// 3. 处理Comment节点
	FillGraphCommentNode(RingGraphBase, EditorOnlyObject);

	TSharedPtr<FQuestImporter> QuestImporter = MakeShared<FQuestImporter>(true);
	// 在加载ring graph的时候，把ring数据中需要懒加载的数据给加载进来
	QuestImporter->ImportLazyPropertiesFromLuaToObj(LuaTable, InObj);
	return true;
}

bool FQuestLuaImporter::FillQuestObjDataWithLuaTable(UQuest* InObj, const TSharedPtr<FLuaTable>& LuaTable)
{
	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("FillQuestObjDataWithLuaTable: Invalid InObj!"));
		return false;
	}
	TSharedPtr<FQuestImporter> QuestImporter = MakeShared<FQuestImporter>(true);
	// 在加载quest graph的时候，把quest数据中需要懒加载的数据给加载进来
	QuestImporter->ImportLazyPropertiesFromLuaToObj(LuaTable, InObj);
	return true;
}

bool FQuestLuaImporter::FillNextTaskWithLuaTable(class UQuestObject* InObj, const TSharedPtr<FLuaTable>& LuaTable)
{
	if (!InObj)
	{
		UE_LOG(LogTemp, Warning, TEXT("FillQuestNextTaskWithLuaTable: Invalid InObj!"));
		return false;
	}
	const TSharedPtr<FQuestImporter> QuestImporter = MakeShared<FQuestImporter>(true);
	QuestImporter->FillObjectPropertyByName(TEXT("NextTaskInfoList"), LuaTable, InObj);
	return true;
}
