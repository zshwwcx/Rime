// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Lua/LuaEnv.h"
#include "Action/QuestAction.h"
#include "QuestEditorLuaObj.generated.h"

/**
 * 
 */

UCLASS()
class KGQUESTEDITOR_API UQuestEditorLuaObj : public UEditorLuaGameInstanceBase
{
	GENERATED_BODY()

public:
	virtual FString GetLuaFilePath_Implementation() const override { return TEXT("Gameplay.Quest.Editor.QuestEditorLuaObj"); }

	static void GetDialogueDatalist(TMap<int32, FString>& OutDataList);

	UFUNCTION(BlueprintImplementableEvent)
	void Inner_OnStart();
	
	UFUNCTION(BlueprintImplementableEvent)
	void GetDialogueData(TMap<int32, FString>& OutData);
	
	UFUNCTION(BlueprintImplementableEvent)
	void GetNPCData(TMap<int32, FString>& OutData);

	UFUNCTION(BlueprintImplementableEvent)
	void GetItemData(TMap<int32, FString>& OutData);
	
	UFUNCTION(BlueprintImplementableEvent)
	void GetTaskCollectIDData(TMap<int32, FString>& OutData);

	UFUNCTION(BlueprintImplementableEvent)
	void GetMonsterIDData(TMap<int32, FString>& OutData);
	
	UFUNCTION(BlueprintImplementableEvent)
	void GetItemSubmitIDData(TMap<int32, FString>& OutData);

	UFUNCTION(BlueprintImplementableEvent)
	void GetOptionTextIDData(TMap<int32, FString>& OutData);

	UFUNCTION(BlueprintImplementableEvent)
	FString GetAnimAssetID(const FString& InstanceID);

	UFUNCTION(BlueprintImplementableEvent)
	TArray<FString> DoDataCheck(const TArray<UQuestChapter*>& CheckChapters, const TArray<UQuestRing*>& CheckRings, const TArray<UQuest*>& CheckQuests);

	UFUNCTION(BlueprintImplementableEvent)
	int32 GetQuestSubTargetMaxNumber();

	UFUNCTION(BlueprintImplementableEvent)
	void GetSystemActionDefine(TArray<FSystemActionDefine>& OutActionDefine);
};
