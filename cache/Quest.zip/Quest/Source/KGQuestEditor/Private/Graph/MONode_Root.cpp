// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "MONode_Root.h"
#include "EdGraph_QuestObjectivesProp.h"
#include "../MOEditorStyle.h"
#include "../Widget/SCCStandardNode.h"

UMONode_Root::UMONode_Root(const FObjectInitializer& ObjectInitializer)
	//: Super(ObjectInitializer.SetDefaultSubobjectClass<UMOObjectiveNode>("MORootNode"))
{
	bUserDefined = false;
	bShowIndexOrder = false;

}


