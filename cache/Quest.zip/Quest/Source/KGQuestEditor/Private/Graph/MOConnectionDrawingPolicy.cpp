// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "MOConnectionDrawingPolicy.h"
#include "GraphEditor.h"
#include "MONode_Base.h"

#define LOCTEXT_NAMESPACE "MOConnectionDrawingPolicy"

FMOConnectionDrawingPolicy::FMOConnectionDrawingPolicy(int32 InBackLayerID, int32 InFrontLayerID, float ZoomFactor, const FSlateRect& InClippingRect, FSlateWindowElementList& InDrawElements, UEdGraph* InGraphObj)
: FConnectionDrawingPolicy(InBackLayerID, InFrontLayerID, ZoomFactor, InClippingRect, InDrawElements)
, GraphObj(InGraphObj)
{
}

static const FLinearColor DefaultColor(1.0f, 1.0f, 1.0f);
static const FLinearColor PositiveColor(0.237f, 0.713f, 0.218f);
static const FLinearColor NegativeColor(1.0f, 0.289f, 0.245f);

void FMOConnectionDrawingPolicy::DetermineWiringStyle(UEdGraphPin* OutputPin, UEdGraphPin* InputPin, /*inout*/ FConnectionParams& Params)
{
	Params.AssociatedPin1 = OutputPin;
	Params.AssociatedPin2 = InputPin;
	Params.WireThickness = 1.5f;

	const bool bDeemphasizeUnhoveredPins = HoveredPins.Num() > 0;
	if (bDeemphasizeUnhoveredPins)
	{
		ApplyHoverDeemphasis(OutputPin, InputPin, Params.WireThickness, Params.WireColor);
	}

	if (InputPin)
	{
		/*if (UMONode_Base* Node_Base = Cast<UMONode_Base>(InputPin->GetOwningNode()))
		{
			switch (Node_Base->AssociatedObject->NodeCharacter)
			{
			case ENodeCharacter::Neutral:
				Params.WireColor = DefaultColor;
				break;
			case ENodeCharacter::Positive:
				Params.WireColor = PositiveColor;
				break;
			case ENodeCharacter::Negative:
				Params.WireColor = NegativeColor;
				break;
			}
		}*/
	}
}

void FMOConnectionDrawingPolicy::Draw(TMap<TSharedRef<SWidget>, FArrangedWidget>& PinGeometriesIn, FArrangedChildren& ArrangedNodes)
{
	// Build an acceleration structure to quickly find geometry for the nodes
	NodeWidgetMap.Empty();
	for (int32 NodeIndex = 0; NodeIndex < ArrangedNodes.Num(); ++NodeIndex)
	{
		FArrangedWidget& CurWidget = ArrangedNodes[NodeIndex];
		TSharedRef<SGraphNode> ChildNode = StaticCastSharedRef<SGraphNode>(CurWidget.Widget);
		NodeWidgetMap.Add(ChildNode->GetNodeObj(), NodeIndex);
	}

	// Now draw
	FConnectionDrawingPolicy::Draw(PinGeometriesIn, ArrangedNodes);
}

void FMOConnectionDrawingPolicy::DrawPreviewConnector(const FGeometry& PinGeometry, const FVector2D& StartPoint, const FVector2D& EndPoint, UEdGraphPin* Pin)
{
	bool bBiDirectional = false;
	FConnectionParams Params;
	Params.WireThickness = 1.0f;
	Params.WireColor = FLinearColor::White;
	Params.bDrawBubbles = false;
	Params.bUserFlag1 = bBiDirectional;
	DetermineWiringStyle(Pin, NULL, /*inout*/ Params);

	if (Pin->Direction == EEdGraphPinDirection::EGPD_Output)
	{
		DrawSplineWithArrow(FGeometryHelper::FindClosestPointOnGeom(PinGeometry, EndPoint), EndPoint, Params);
	}
	else
	{
		DrawSplineWithArrow(FGeometryHelper::FindClosestPointOnGeom(PinGeometry, StartPoint), StartPoint, Params);
	}

}

void FMOConnectionDrawingPolicy::DrawSplineWithArrow(const FVector2D& StartAnchorPoint, const FVector2D& EndAnchorPoint, const FConnectionParams& Params)
{
	// hacky: use bBidirectional flag to reverse direction of connection (used by debugger)
	bool Bidirectional = Params.bUserFlag1;
	const FVector2D& P0 = Bidirectional ? EndAnchorPoint : StartAnchorPoint;
	const FVector2D& P1 = Bidirectional ? StartAnchorPoint : EndAnchorPoint;

	Internal_DrawLineWithArrow(P0, P1, Params);
}

void FMOConnectionDrawingPolicy::Internal_DrawLineWithArrow(const FVector2D& StartAnchorPoint, const FVector2D& EndAnchorPoint, const FConnectionParams& Params)
{
	const float LineSeparationAmount = 4.5f;

	const FVector2D DeltaPos = EndAnchorPoint - StartAnchorPoint;
	const FVector2D UnitDelta = DeltaPos.GetSafeNormal();
	const FVector2D Normal = FVector2D(DeltaPos.Y, -DeltaPos.X).GetSafeNormal();

	// Come up with the final start/end points
	const FVector2D DirectionBias = Normal * LineSeparationAmount;
	const FVector2D LengthBias = ArrowRadius.X * UnitDelta;
	const FVector2D StartPoint = StartAnchorPoint + DirectionBias + LengthBias;
	const FVector2D EndPoint = EndAnchorPoint + DirectionBias - LengthBias;

	// Draw a line/spline
	DrawConnection(WireLayerID, StartPoint, EndPoint, Params);

	// Draw the arrow
	const FVector2D ArrowDrawPos = EndPoint - ArrowRadius;
	const float AngleInRadians = FMath::Atan2(DeltaPos.Y, DeltaPos.X);

	FSlateDrawElement::MakeRotatedBox(
		DrawElementsList,
		ArrowLayerID,
		FPaintGeometry(ArrowDrawPos, ArrowImage->ImageSize * ZoomFactor, ZoomFactor),
		ArrowImage,
		ESlateDrawEffect::None,
		AngleInRadians,
		TOptional<FVector2D>(),
		FSlateDrawElement::RelativeToElement,
		Params.WireColor
		);
}

void FMOConnectionDrawingPolicy::DrawSplineWithArrow(const FGeometry& StartGeom, const FGeometry& EndGeom, const FConnectionParams& Params)
{
	// Get a reasonable seed point (halfway between the boxes)
	const FVector2D StartCenter = FGeometryHelper::CenterOf(StartGeom);
	const FVector2D EndCenter = FGeometryHelper::CenterOf(EndGeom);
	const FVector2D SeedPoint = (StartCenter + EndCenter) * 0.5f;

	// Find the (approximate) closest points between the two boxes
	const FVector2D StartAnchorPoint = FGeometryHelper::FindClosestPointOnGeom(StartGeom, SeedPoint);
	const FVector2D EndAnchorPoint = FGeometryHelper::FindClosestPointOnGeom(EndGeom, SeedPoint);

	DrawSplineWithArrow(StartAnchorPoint, EndAnchorPoint, Params);
}



void FMOConnectionDrawingPolicy::DrawConnection(int32 LayerId, const FVector2D& Start, const FVector2D& End, const FConnectionParams& Params)
{
	const FVector2D& P0 = Start;
	const FVector2D& P1 = End;

	const FVector2D Delta = End - Start;
	const FVector2D NormDelta = Delta.GetSafeNormal();

	const FVector2D P0Tangent = NormDelta;
	const FVector2D P1Tangent = NormDelta;

	// Draw the spline itself
	FSlateDrawElement::MakeDrawSpaceSpline(
		DrawElementsList,
		LayerId,
		P0, P0Tangent,
		P1, P1Tangent,
		Params.WireThickness,
		ESlateDrawEffect::None,
		Params.WireColor
		);

	if (Params.bDrawBubbles)
	{
		// This table maps distance along curve to alpha
		FInterpCurve<float> SplineReparamTable;
		float SplineLength = MakeSplineReparamTable(P0, P0Tangent, P1, P1Tangent, SplineReparamTable);

		// Draw bubbles on the spline
		const float BubbleSpacing = 64.f * ZoomFactor;
		const float BubbleSpeed = 192.f * ZoomFactor;
		const FVector2D BubbleSize = BubbleImage->ImageSize * ZoomFactor * 0.1f * Params.WireThickness;

		float Time = (FPlatformTime::Seconds() - GStartTime);
		const float BubbleOffset = FMath::Fmod(Time * BubbleSpeed, BubbleSpacing);
		const int32 NumBubbles = FMath::CeilToInt(SplineLength / BubbleSpacing);
		for (int32 i = 0; i < NumBubbles; ++i)
		{
			const float Distance = ((float)i * BubbleSpacing) + BubbleOffset;
			if (Distance < SplineLength)
			{
				const float Alpha = SplineReparamTable.Eval(Distance, 0.f);
				FVector2D BubblePos = FMath::CubicInterp(P0, P0Tangent, P1, P1Tangent, Alpha);
				BubblePos -= (BubbleSize * 0.5f);

				FSlateDrawElement::MakeBox(
					DrawElementsList,
					LayerId,
					FPaintGeometry(BubblePos, BubbleSize, ZoomFactor),
					BubbleImage,
					ESlateDrawEffect::None,
					Params.WireColor
					);
			}
		}
	}
	const float QueryDistanceTriggerThresholdSquared = FMath::Square(Settings->SplineHoverTolerance + Params.WireThickness * 0.5f);
	const float QueryDistanceToBoundingBoxSquared = QueryDistanceTriggerThresholdSquared;
	bool bCloseToSpline = false;
	{
		// The curve will include the endpoints but can extend out of a tight bounds because of the tangents
		// P0Tangent coefficient maximizes to 4/27 at a=1/3, and P1Tangent minimizes to -4/27 at a=2/3.
		const float MaximumTangentContribution = 4.0f / 27.0f;
		FBox2D Bounds(ForceInit);

		Bounds += FVector2D(P0);
		Bounds += FVector2D(P0 + MaximumTangentContribution * P0Tangent);
		Bounds += FVector2D(P1);
		Bounds += FVector2D(P1 - MaximumTangentContribution * P1Tangent);

		bCloseToSpline = Bounds.ComputeSquaredDistanceToPoint(LocalMousePosition) < QueryDistanceToBoundingBoxSquared;

		// Draw the bounding box for debugging
	}
	if (bCloseToSpline)
	{
		// Find the closest approach to the spline
		FVector2D ClosestPoint(ForceInit);
		float ClosestDistanceSquared = FLT_MAX;

		const int32 NumStepsToTest = 16;
		const float StepInterval = 1.0f / (float)NumStepsToTest;
		FVector2D Point1 = FMath::CubicInterp(P0, P0Tangent, P1, P1Tangent, 0.0f);
		for (float TestAlpha = 0.0f; TestAlpha < 1.0f; TestAlpha += StepInterval)
		{
			const FVector2D Point2 = FMath::CubicInterp(P0, P0Tangent, P1, P1Tangent, TestAlpha + StepInterval);

			const FVector2D ClosestPointToSegment = FMath::ClosestPointOnSegment2D(LocalMousePosition, Point1, Point2);
			const float DistanceSquared = (LocalMousePosition - ClosestPointToSegment).SizeSquared();

			if (DistanceSquared < ClosestDistanceSquared)
			{
				ClosestDistanceSquared = DistanceSquared;
				ClosestPoint = ClosestPointToSegment;
			}

			Point1 = Point2;
		}

		// Record the overlap
		if (ClosestDistanceSquared < QueryDistanceTriggerThresholdSquared)
		{
			if (ClosestDistanceSquared < SplineOverlapResult.GetDistanceSquared())
			{
				const float SquaredDistToPin1 = (Params.AssociatedPin1 != nullptr) ? (P0 - ClosestPoint).SizeSquared() : FLT_MAX;
				const float SquaredDistToPin2 = (Params.AssociatedPin2 != nullptr) ? (P1 - ClosestPoint).SizeSquared() : FLT_MAX;

				SplineOverlapResult = FGraphSplineOverlapResult(Params.AssociatedPin1, Params.AssociatedPin2, ClosestDistanceSquared, SquaredDistToPin1, SquaredDistToPin2, true);
			}
		}
	}
}

#undef LOCTEXT_NAMESPACE
