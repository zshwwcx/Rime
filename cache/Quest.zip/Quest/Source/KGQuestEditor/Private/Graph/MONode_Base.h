// Copyright 15.07.2018 Tefel. All Rights Reserved.

#pragma once
#include "EdGraph/EdGraphNode.h"
#include "Styling/SlateBrush.h"
#include "MONode_Base.generated.h"

class UMONode_Root;

class  FNodePropertyObserver {
public:
	virtual void OnPropertyChanged(class UMONode_Base* Sender, const FName& PropertyName) = 0;
};

UENUM(BlueprintType)
enum class EQuestNode_Color : uint8
{
	Green,
	Blue
};

UENUM(BlueprintType)
enum class EQuestNode_Icon : uint8
{
	objective,
	entry,
	success,
	fail
};

UENUM(BlueprintType)
enum class EQuestNode_BackgroundImage : uint8
{
	green,
	blue,
	red
};

//任务节点默认引脚
UENUM(BlueprintType)
enum class EQuestNode_DefaultPin : uint8
{
	both,
	in,
	out
};

UCLASS(Blueprintable)
class  UMONode_Base : public UEdGraphNode {
	GENERATED_BODY()

public:
	virtual void AllocateDefaultPins() override;

	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& e);
	virtual const FSlateBrush* GetNodeIcon() const;
	virtual FSlateColor GetNodeBackgroundColor() const;
	virtual const FSlateBrush* GetNodeBackgroundImage() const;
	virtual FLinearColor GetNodeTitleColor() const override;
	virtual UEdGraphPin* GetInputPin() const;
	virtual UEdGraphPin* GetOutputPin() const;
	virtual void NodeConnectionListChanged() override;
	virtual void AutowireNewNode(UEdGraphPin* FromPin) override;
	virtual void DestroyNode() override;
	virtual void PinConnectionListChanged(UEdGraphPin* Pin) override;
	// Clearing pasted node and prepare structure for registering new nodes
	virtual void PostPasteNode() override;
	// Adding and registering missing child nodes in the model
	virtual void PostPasteNodeFinal();
	virtual void PrepareForCopying() override;

	//void UpdateNodeCharacterRecursive(ENodeCharacter Character);
	//void UpdateNodeCharacter(ENodeCharacter Character);
	void SetTitle(FName NewTitle);
	void PostCopying();

	TArray<UMONode_Base*> GetNodeChildren();
	UMONode_Root* FindRootNode();
	void DestroyAllChildNodes();
	UMONode_Base* GetParentNode();
	TArray<UMONode_Base*> GetParentNodes();

	virtual void InitRootNode();


	// Associated object used for nodes which are represented in model (runtime)
//	UPROPERTY(VisibleAnywhere, Instanced, BlueprintReadWrite, Category = "RootInfo")
	//class UMOTextNode* AssociatedObject;

	// Only user defined nodes can be deleted
	bool bUserDefined = true;

	// If node should show index orde
	bool bShowIndexOrder = true;

	// nodes which can cross-reference
	bool bIsNodeSelected;

	//初始化方法
	virtual void NodeInit() {}

	FText GetHeadTitle() const;

	FText GetHeadTitleID() const;

	FText GetHeadTitleType() const;

	void SetTitleText(FText Title) { TitleName = Title; }

	void SetTitleTextID(FText ID) { TitleID = ID; }

	void SetTitleTextType(FText Text) { TitleType = Text; }

	virtual void UpdateTitle();

	virtual void OnMouseButtonDown(); 

	virtual void OnMouseButtonDoubleClick();

	virtual void DeleteNode();

	virtual void CreateAsset(UObject* TemplateObject = nullptr);

	//当取消选中该node的时候触发，此时需要保存编辑该节点时的相关数据，显示编辑好的数据到节点上
	virtual void OnSelectedNodeChanged();


public:
	//任务编辑器中节点描述
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString QuestEditor_Desc;

	//任务编辑器中节点类型描述
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString QuestEditor_TypeDesc;

	//任务编辑器中节点标题
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString NodeTitle;

	//任务编辑器中节点背景颜色
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		EQuestNode_Color QuestNode_Color = EQuestNode_Color::Green;

	//任务编辑器中节点图标
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		EQuestNode_Icon QuestNode_Icon = EQuestNode_Icon::objective;

	//任务编辑器中节点图标
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		EQuestNode_BackgroundImage QuestNode_BackgroundImage = EQuestNode_BackgroundImage::blue;

	//任务编辑器中节点默认引脚
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		EQuestNode_DefaultPin QuestNode_DefaultPin = EQuestNode_DefaultPin::both;

	
	
protected:

	FText TitleName;

	FText TitleID;

	FText TitleType;


private:
	bool HasAnyParentNodes();
	bool HasAnyChildNodes();

};