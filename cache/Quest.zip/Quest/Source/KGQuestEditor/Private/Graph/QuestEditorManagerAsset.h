#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Engine/DataAsset.h"
#include "MONode_Base.h"
#include "EdGraphSchema_QuestObjectivesProp.h"
#include "QuestEditorManagerAsset.generated.h"

USTRUCT(Blueprintable)
struct FMONode_BaseStruct
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<TSubclassOf<UMONode_Base>> MONode_BaseArray;
};

/**
 *
 */
UCLASS(Blueprintable) 
class  UQuestEditorManagerAsset : public UObject
{
	GENERATED_BODY()

public:
	//对于章节还是Quest页面下显示的不同任务类型节点
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PathWithNodeType")
		TMap<EActionType, FMONode_BaseStruct> ChaperAndQuestNodeTypeMap;

	//Quest页面根节点类型
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Level")
		TSubclassOf<UMONode_Root> QuestActionRoot;

	//关卡页面星级奖励根节点类型
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Level")
		TSubclassOf<UMONode_Root> StarRewardRoot;

	//关卡页面完成关卡奖励根节点类型
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Level")
		TSubclassOf<UMONode_Root> CompleteLevelRoot;

	//Action页面开始节点根节点类型
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "action")
		TSubclassOf<class UMONode_QuestAction> ActionStartRoot;

	//Action页面结束节点根节点类型
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "action")
		TSubclassOf<class UMONode_QuestAction> ActionEndRoot;

	static UQuestEditorManagerAsset* GetQuestEditorManagerAsset();
};
 