// Copyright 15.07.2018 Tefel. All Rights Reserved.

#pragma once
#include "MONode_Base.h"
#include "MONode_Quest.generated.h"

UCLASS(Blueprintable)
class  UMONode_Quest : public UMONode_Base {
	GENERATED_UCLASS_BODY()

public:
	// Begin UEdGraphNode interface.
	// End UEdGraphNode interface.

	//virtual class USingleQuest* GetSingleQuest() { return SingleQuest; }

	virtual void UpdateTitle() override;

	virtual void OnMouseButtonDown() override;

	virtual void CreateAsset(UObject* TemplateObject = nullptr) override;

	virtual void CreateQuestPackage(UPackage* Package, FString AssetName, UObject* TemplateObject = nullptr);

	virtual void DeleteNode() override;

	virtual void OnMouseButtonDoubleClick() override;

	virtual void OnSelectedNodeChanged();


public:

	//UPROPERTY(BlueprintReadWrite, EditAnywhere)
	//	TSubclassOf<USingleQuest> QuestClass;

	//UPROPERTY(BlueprintReadWrite, EditAnywhere)
	//	class USingleQuest* SingleQuest;



};