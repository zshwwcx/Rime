// Copyright 15.07.2018 Tefel. All Rights Reserved.

#pragma once
#include "EdGraph/EdGraphSchema.h"
#include "EdGraphSchema_QuestObjectivesProp.generated.h"

class UMONode_Root;

// Action types
UENUM(BlueprintType)
enum class EActionType : uint8
{
	None,
	All,
	Chapter,
	Quest
};

/** Action to add a node to the graph */
USTRUCT()
struct  FQuestObjectivesSchemaAction_NewNode : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY();

	/** Template of node we want to create */
	UPROPERTY()
	TObjectPtr<UEdGraphNode> NodeTemplate = nullptr;


	FQuestObjectivesSchemaAction_NewNode()
		: FEdGraphSchemaAction()
		, NodeTemplate(NULL)
	{}

	FQuestObjectivesSchemaAction_NewNode(const FText& InNodeCategory, const FText& InMenuDesc, const FText& InToolTip, const int32 InGrouping)
		: FEdGraphSchemaAction(InNodeCategory, InMenuDesc, InToolTip, InGrouping)
		, NodeTemplate(NULL)
	{}

	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, TArray<UEdGraphPin*>& FromPins, const FVector2D Location, bool bSelectNewNode = true) override;
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	// End of FEdGraphSchemaAction interface

};

UCLASS()
class UEdGraphSchema_QuestObjectivesProp : public UEdGraphSchema {
	GENERATED_BODY()

	// Begin EdGraphSchema interface
	virtual void GetGraphContextActions(FGraphContextMenuBuilder& ContextMenuBuilder) const override;
	virtual const FPinConnectionResponse CanCreateConnection(const UEdGraphPin* A, const UEdGraphPin* B) const override;
	virtual class FConnectionDrawingPolicy* CreateConnectionDrawingPolicy(int32 InBackLayerID, int32 InFrontLayerID, float InZoomFactor, const FSlateRect& InClippingRect, class FSlateWindowElementList& InDrawElements, class UEdGraph* InGraphObj) const override;
	virtual FLinearColor GetPinTypeColor(const FEdGraphPinType& PinType) const override;
	virtual bool ShouldHidePinDefaultValue(UEdGraphPin* Pin) const override;
	virtual bool TryCreateConnection(UEdGraphPin* A, UEdGraphPin* B) const override;
	// End EdGraphSchema interface




public:
	void GetActionList(TArray<TSharedPtr<FEdGraphSchemaAction> >& OutActions, const UEdGraph* Graph, EActionType ActionType) const;

	void SetGraphPalette(TSharedPtr<class SCCGraphPalette> TempCCGraphPalette);

	//获取当前页面节点的所有类型
	EActionType GetAllActionType() const;

private:
	TSharedPtr<class SCCGraphPalette> CCGraphPalette;

	// Finding root and setting Outer to the Asset
	UMONode_Root* GetRootNode(const UEdGraph* Graph) const;

	UPROPERTY()
	TArray<FEdGraphSchemaAction> ActionsCached;
};

class  QuestObjectivesSchemaUtils {
public:
	template<typename T>
	static void AddAction(FString Title, FString Tooltip, TArray<TSharedPtr<FEdGraphSchemaAction> >& OutActions, UObject* Owner, FText Category) {
		const FText MenuDesc = FText::FromString(Title);
		TSharedPtr<FQuestObjectivesSchemaAction_NewNode> NewActorNodeAction = AddNewNodeAction(OutActions, Category, MenuDesc, Tooltip);
		if (Owner)
		{
			T* ActorNode = NewObject<T>(Owner);
			NewActorNodeAction->NodeTemplate = ActorNode; // todo bug?
		}
		else
		{
			T* ActorNode = NewObject<T>();
			NewActorNodeAction->NodeTemplate = ActorNode; // todo bug?
		}
	}

	static TSharedPtr<FQuestObjectivesSchemaAction_NewNode> AddNewNodeAction(TArray<TSharedPtr<FEdGraphSchemaAction> >& OutActions, const FText& Category, const FText& MenuDesc, const FString& Tooltip)
	{
		TSharedPtr<FQuestObjectivesSchemaAction_NewNode> NewAction = TSharedPtr<FQuestObjectivesSchemaAction_NewNode>(new FQuestObjectivesSchemaAction_NewNode(Category, MenuDesc, FText::FromString(Tooltip), 0));

		OutActions.Add(NewAction);
		return NewAction;
	}

	static void AddAction(FString Title, FString Tooltip, TArray<TSharedPtr<FEdGraphSchemaAction> >& OutActions, UObject* Owner, FText Category , EObjectFlags ObjectFlags, UClass* NodeTypeClass) 
	{
		const FText MenuDesc = FText::FromString(Title);
		TSharedPtr<FQuestObjectivesSchemaAction_NewNode> NewActorNodeAction = AddNewNodeAction(OutActions, Category, MenuDesc, Tooltip);

		if (Owner)
		{
			NewActorNodeAction->NodeTemplate = NewObject<UEdGraphNode>(Owner, NodeTypeClass);
		}
		else
		{
			NewActorNodeAction->NodeTemplate = NewObject<UEdGraphNode>(NodeTypeClass);
		}
	}
};