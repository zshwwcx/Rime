// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "EdGraphSchema_QuestObjectivesProp.h"
#include "EdGraph_QuestObjectivesProp.h"
#include "EdGraph/EdGraphPin.h"
#include "MONode_Quest.h"
#include "MONode_QuestAction.h"
#include "MOConnectionDrawingPolicy.h"
#include "MONode_Root.h"
#include "../Widget/SCCGraphPalette.h"
#include "FQuestObjectivesEditor.h"
#include "../UI/QuestScrollWidget.h"
#include "../UI/QuestListViewWidget.h"
#include "../UI/QuestTreeView.h"
#include "MONode_Quest_Reward.h"
#include "QuestEditorManagerAsset.h"

#define SNAP_GRID (16)

namespace
{
	// Maximum distance a drag can be off a node edge to require 'push off' from node
	const int32 NodeDistance = 60;
}

UEdGraphNode* FQuestObjectivesSchemaAction_NewNode::PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode/* = true*/)
{
	UEdGraphNode* ResultNode = NULL;

	// If there is a template, we actually use it
	if (NodeTemplate != NULL)
	{
		NodeTemplate->SetFlags(RF_Transactional);

		// set outer to be the graph so it doesn't go away
		NodeTemplate->Rename(NULL, ParentGraph, REN_NonTransactional);
		ParentGraph->AddNode(NodeTemplate, true, bSelectNewNode);

		NodeTemplate->CreateNewGuid();
		NodeTemplate->PostPlacedNewNode();
		NodeTemplate->AllocateDefaultPins();
		NodeTemplate->AutowireNewNode(FromPin);

		// For input pins, new node will generally overlap node being dragged off
		// Work out if we want to visually push away from connected node
		int32 XLocation = Location.X;
		if (FromPin && FromPin->Direction == EGPD_Input)
		{
			UEdGraphNode* PinNode = FromPin->GetOwningNode();
			const float XDelta = FMath::Abs(PinNode->NodePosX - Location.X);

			if (XDelta < NodeDistance)
			{
				// Set location to edge of current node minus the max move distance
				// to force node to push off from connect node enough to give selection handle
				XLocation = PinNode->NodePosX - NodeDistance;
			}
		}

		NodeTemplate->NodePosX = XLocation;
		NodeTemplate->NodePosY = Location.Y;
		NodeTemplate->SnapToGrid(SNAP_GRID);

		ResultNode = NodeTemplate;
	}

	return ResultNode;
}

UEdGraphNode* FQuestObjectivesSchemaAction_NewNode::PerformAction(class UEdGraph* ParentGraph, TArray<UEdGraphPin*>& FromPins, const FVector2D Location, bool bSelectNewNode/* = true*/)
{
	UEdGraphNode* ResultNode = NULL;

	if (FromPins.Num() > 0)
	{
		ResultNode = PerformAction(ParentGraph, FromPins[0], Location, bSelectNewNode);

		// Try autowiring the rest of the pins
		for (int32 Index = 1; Index < FromPins.Num(); ++Index)
		{
			ResultNode->AutowireNewNode(FromPins[Index]);
		}
	}
	else
	{
		ResultNode = PerformAction(ParentGraph, NULL, Location, bSelectNewNode);
	}

	return ResultNode;
}

void FQuestObjectivesSchemaAction_NewNode::AddReferencedObjects(FReferenceCollector& Collector)
{
	FEdGraphSchemaAction::AddReferencedObjects(Collector);

	// These don't get saved to disk, but we want to make sure the objects don't get GC'd while the action array is around
	Collector.AddReferencedObject(NodeTemplate);
}

void UEdGraphSchema_QuestObjectivesProp::GetActionList(TArray<TSharedPtr<FEdGraphSchemaAction> >& OutActions, const UEdGraph* Graph, EActionType ActionType) const
{
#if WITH_EDITOR


	UEdGraph_QuestObjectivesProp* QuestObjectivesProp = CCGraphPalette->GetQuestObjectivesEditor().Pin()->GetQuestObjectivesGraph();
	UObject* FoundObject = QuestObjectivesProp;
	if (FoundObject == nullptr)
	{
		return;
	}

	//获取当前任务页签所有任务节点类型（章节页签中的所有节点，还是任务页签中的所有节点）
	UQuestEditorManagerAsset* QuestEditorManagerAsset = UQuestEditorManagerAsset::GetQuestEditorManagerAsset();
	if (QuestEditorManagerAsset && QuestEditorManagerAsset->ChaperAndQuestNodeTypeMap.Num() > 0)
	{
		TArray<TSubclassOf<UMONode_Base>> MONode_BaseArray = QuestEditorManagerAsset->ChaperAndQuestNodeTypeMap.Find(ActionType)->MONode_BaseArray;
		for (TSubclassOf<UMONode_Base> MONode_Base : MONode_BaseArray)
		{
			if (UMONode_Quest* TempQuest = (UMONode_Quest*)MONode_Base->ClassDefaultObject)
			{
				QuestObjectivesSchemaUtils::AddAction(TempQuest->QuestEditor_Desc, TempQuest->QuestEditor_Desc, OutActions, FoundObject,
					FText::FromString(TempQuest->QuestEditor_TypeDesc), EObjectFlags::RF_Public, TempQuest->GetClass());
			}
		}
	}

	//switch (ActionType)
	//{
	//case EActionType::None:
	//	break;

	//case EActionType::All:
	//	if (UMONode_Root* MONode_Root = GetRootNode(Graph))
	//	{


	//		QuestObjectivesSchemaUtils::AddAction<UMONode_Quest>(TEXT("任务节点"), TEXT("任务节点"), OutActions, FoundObject, QuestCategory);
	//		QuestObjectivesSchemaUtils::AddAction<UMONode_QuestAction>(TEXT("行为基础节点"), TEXT("行为基础节点"), OutActions, FoundObject, ActionCategory);
	//		QuestObjectivesSchemaUtils::AddAction<UMONode_QuestSuccess>(TEXT("任务成功节点"), TEXT("任务成功节点"), OutActions, FoundObject, ActionCategory);
	//		QuestObjectivesSchemaUtils::AddAction<UMONode_QuestFailure>(TEXT("任务失败节点"), TEXT("任务失败节点"), OutActions, FoundObject, ActionCategory);
	//	}
	//	break;

	//case EActionType::Chapter:
	//	QuestObjectivesSchemaUtils::AddAction<UMONode_Quest>(TEXT("任务节点"), TEXT("任务节点"), OutActions, FoundObject, QuestCategory);
	//	QuestObjectivesSchemaUtils::AddAction<UMONode_Quest_Reward>(TEXT("任务关卡奖励节点"), TEXT("任务关卡奖励节点"), OutActions, FoundObject, QuestLevelRewardCategory);

	//	break;

	//case EActionType::Quest:
	//	QuestObjectivesSchemaUtils::AddAction<UMONode_QuestAction>(TEXT("任务行为节点"), TEXT("任务行为节点"), OutActions, FoundObject, ActionCategory);
	//	QuestObjectivesSchemaUtils::AddAction<UMONode_QuestAction_NPCVisibility>(TEXT("行为_NPC可见性节点"), TEXT("NPC可见性"), OutActions, FoundObject, VisibilityCategory);
	//	QuestObjectivesSchemaUtils::AddAction<UMONode_QuestAction_Play>(TEXT("行为_播放节点"), TEXT("播放"), OutActions, FoundObject, PlayCategory);
	//	QuestObjectivesSchemaUtils::AddAction<UMONode_QuestAction_Reward>(TEXT("行为_奖励节点"), TEXT("奖励"), OutActions, FoundObject, RewardCategory);


	//	break;
	//default:
	//	break;
	//}

#endif

}

void UEdGraphSchema_QuestObjectivesProp::GetGraphContextActions(FGraphContextMenuBuilder& ContextMenuBuilder) const
{
	const UEdGraph* Graph = ContextMenuBuilder.CurrentGraph;
	TArray<TSharedPtr<FEdGraphSchemaAction> > Actions;
	GetActionList(Actions, Graph, GetAllActionType());
	for (TSharedPtr<FEdGraphSchemaAction> Action : Actions) {
		ContextMenuBuilder.AddAction(Action);
	}
}



FString Combine(const TArray<FString> Array, FString Separator) {
	FString Result;
	for (const FString& Item : Array) {
		if (Result.Len() > 0) {
			Result += Separator;
		}
		Result += Item;
	}
	return Result;
}

const FPinConnectionResponse UEdGraphSchema_QuestObjectivesProp::CanCreateConnection(const UEdGraphPin* A, const UEdGraphPin* B) const
{
	// Make sure the input is connecting to an output
	if (A->Direction == B->Direction) {
		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, TEXT("Not allowed"));
	}

	return FPinConnectionResponse(CONNECT_RESPONSE_MAKE, TEXT(""));
}

class FConnectionDrawingPolicy* UEdGraphSchema_QuestObjectivesProp::CreateConnectionDrawingPolicy(int32 InBackLayerID, int32 InFrontLayerID, float InZoomFactor, const FSlateRect& InClippingRect, class FSlateWindowElementList& InDrawElements, class UEdGraph* InGraphObj) const
{
	return new FMOConnectionDrawingPolicy(InBackLayerID, InFrontLayerID, InZoomFactor, InClippingRect, InDrawElements, InGraphObj);
}

FLinearColor UEdGraphSchema_QuestObjectivesProp::GetPinTypeColor(const FEdGraphPinType& PinType) const
{
	return FColor::Yellow;
}

bool UEdGraphSchema_QuestObjectivesProp::ShouldHidePinDefaultValue(UEdGraphPin* Pin) const
{
	return false;
}

bool UEdGraphSchema_QuestObjectivesProp::TryCreateConnection(UEdGraphPin* A, UEdGraphPin* B) const
{
	bool ConnectionMade = UEdGraphSchema::TryCreateConnection(A, B);
	if (ConnectionMade) {
		UEdGraphPin* OutputPin = (A->Direction == EEdGraphPinDirection::EGPD_Output) ? A : B;
		UMONode_Base* OutputNode = Cast<UMONode_Base>(OutputPin->GetOwningNode());
		if (OutputNode) {
			OutputNode->GetGraph()->NotifyGraphChanged();
		}
	}

	return ConnectionMade;
}

EActionType UEdGraphSchema_QuestObjectivesProp::GetAllActionType() const
{
	EActionType TempActionType = EActionType::All;

	//if (CCGraphPalette.IsValid() && CCGraphPalette->GetQuestObjectivesEditor().IsValid() && CCGraphPalette->GetQuestObjectivesEditor().Pin()->GetQuestScrollWidget())
	//{
	//	if (CCGraphPalette->GetQuestObjectivesEditor().Pin()->GetQuestScrollWidget()->GetListViewWidget()->IsDeleteAsset())
	//	{
	//		return EActionType::None;
	//	}

	//	int CurrentPage = CCGraphPalette->GetQuestObjectivesEditor().Pin()->GetQuestScrollWidget()->GetListViewWidget()->GetCurrentPage();
	//	//看如果是章节页面，那么只显示章节相关节点
	//	if (CurrentPage == 2)
	//	{
	//		TempActionType = EActionType::Chapter;
	//	}
	//	//看如果是任务页面，那么只显示任务相关节点
	//	if (CurrentPage == 3)
	//	{
	//		TempActionType = EActionType::Quest;
	//	}
	//}

	if (CCGraphPalette.IsValid() && CCGraphPalette->GetQuestObjectivesEditor().IsValid())
	{
		if (CCGraphPalette->GetQuestObjectivesEditor().Pin()->GetQuestTreeView()->IsDeleteAsset())
		{
			return EActionType::None;
		}

		EQuestCategory Category = CCGraphPalette->GetQuestObjectivesEditor().Pin()->GetQuestTreeView()->GetCurClickItemCategory();
		//看如果是章节页面，那么只显示章节相关节点
		if (Category == EQuestCategory::Chapter)
		{
			TempActionType = EActionType::Chapter;
		}
		//看如果是任务页面，那么只显示任务相关节点
		if (Category == EQuestCategory::SingleQuest)
		{
			TempActionType = EActionType::Quest;
		}
	}
	return TempActionType;
}

void UEdGraphSchema_QuestObjectivesProp::SetGraphPalette(TSharedPtr<class SCCGraphPalette> TempCCGraphPalette)
{
	CCGraphPalette = TempCCGraphPalette;
}

UMONode_Root* UEdGraphSchema_QuestObjectivesProp::GetRootNode(const UEdGraph* Graph) const
{
	TArray<UMONode_Root*> RootNodes;
	Graph->GetNodesOfClass(RootNodes);
	if (RootNodes.Num() > 0)
	{
		return RootNodes[0];
	}

	return nullptr;
}
