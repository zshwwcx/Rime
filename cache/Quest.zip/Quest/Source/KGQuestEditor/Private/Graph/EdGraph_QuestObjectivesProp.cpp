// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "EdGraph_QuestObjectivesProp.h"
#include "EdGraphSchema_QuestObjectivesProp.h"
#include "GraphEditAction.h"
#include "EdGraph/EdGraphNode.h"
#include "MONode_Root.h"
#include "FQuestObjectivesEditor.h"
#include "../UI/QuestScrollWidget.h"
#include "../UI/QuestListViewWidget.h"
#include "../UI/QuestTreeView.h"
#include "QuestEditorManagerAsset.h"

#define SNAP_GRID (16)

#define LOCTEXT_NAMESPACE "QuestObjectivesPropGraph"

const FName FQuestObjectivesDataTypes::PinType_Entry = "Entry";
const FName FQuestObjectivesDataTypes::PinType_Input = "Input";
const FName FQuestObjectivesDataTypes::PinType_Objective = "Objective";
const FName FQuestObjectivesDataTypes::PinType_Quest = "Quest";


UEdGraph_QuestObjectivesProp::UEdGraph_QuestObjectivesProp(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	Schema = UEdGraphSchema_QuestObjectivesProp::StaticClass();
}

template<typename T>
void GetChildNodes(UMONode_Base* ParentNode, TArray<T*>& OutChildren)
{
	for (UEdGraphPin* ChildPin : ParentNode->GetOutputPin()->LinkedTo) {
		if (ChildPin) {
			if (T* DesiredNode = Cast<T>(ChildPin->GetOwningNode())) {
				OutChildren.Add(DesiredNode);
			}
		}
	}
}

void UEdGraph_QuestObjectivesProp::InitializeGraph()
{
	//if (QuestObjectivesEditor && QuestObjectivesEditor->GetQuestScrollWidget()->GetListViewWidget()->GetCurrentPage() == 3)
	if (QuestObjectivesEditor.IsValid() && QuestObjectivesEditor.Pin()->GetQuestTreeView()->GetCurClickItemCategory() == EQuestCategory::SingleQuest)
	{
		if (UQuestEditorManagerAsset* QuestEditorManagerAsset = UQuestEditorManagerAsset::GetQuestEditorManagerAsset())
		{
			bool bFind = false;
			for (UEdGraphNode* node : Nodes)
			{
				UMONode_Root* TempRootNode = Cast<UMONode_Root>(node);
				if (TempRootNode)
				{
					bFind = true;
				}
			}
			// ROOT NODE CREATION
			if (!bFind)
			{
				UMONode_Root* RootStartNode = NewObject<UMONode_Root>(this, *QuestEditorManagerAsset->QuestActionRoot);
				RootStartNode->InitRootNode();
				this->AddNode(RootStartNode, true, false);

				UMONode_QuestAction* RootEndNode = NewObject<UMONode_QuestAction>(this, *QuestEditorManagerAsset->ActionEndRoot);
				RootEndNode->InitRootNode();
				this->AddNode(RootEndNode, true, false);
				RootEndNode->NodePosY = 100;
			}
		}
		
	}
	if (QuestObjectivesEditor.IsValid() && QuestObjectivesEditor.Pin()->GetQuestTreeView()->GetCurClickItemCategory() == EQuestCategory::Chapter &&
		QuestObjectivesEditor.Pin()->GetQuestTreeView()->GetCurClickItemQuestType() == EQuestFolderType::Quest_Level)
	{
		bool bFind = false;
		if (UQuestEditorManagerAsset* QuestEditorManagerAsset = UQuestEditorManagerAsset::GetQuestEditorManagerAsset())
		{
			for (UEdGraphNode* node : Nodes)
			{
				UMONode_Root* TempRootNode = Cast<UMONode_Root>(node);
				if (TempRootNode)
				{
					bFind = true;
				}
			}
			// ROOT NODE CREATION
			if (!bFind)
			{
				UMONode_Root* StarRewardRoot = NewObject<UMONode_Root>(this , *QuestEditorManagerAsset->StarRewardRoot);
				StarRewardRoot->InitRootNode();
				this->AddNode(StarRewardRoot, true, false);

				UMONode_Root* CompleteLevelNode = NewObject<UMONode_Root>(this, *QuestEditorManagerAsset->CompleteLevelRoot);
				CompleteLevelNode->InitRootNode();
				CompleteLevelNode->NodePosY = 500;
				this->AddNode(CompleteLevelNode, true, false);
			}
		}


	}

}

void UEdGraph_QuestObjectivesProp::RefreshNodeSelection(UEdGraphNode* Node)
{
	TSet<const UEdGraphNode*> NodesToFocus;
	//NodesToFocus.Add(Node);

	FEdGraphEditAction SelectionAction;
	SelectionAction.Action = GRAPHACTION_SelectNode;
	SelectionAction.Graph = this;
	NotifyGraphChanged(SelectionAction);
	SelectionAction.Nodes = NodesToFocus;
	NotifyGraphChanged(SelectionAction);
}


void UEdGraph_QuestObjectivesProp::ReGenerateAllNodes(UEdGraph* TempGraph)
{
	for (int i = 0; i < TempGraph->Nodes.Num(); i++)
	{
		UEdGraphNode* Node = TempGraph->Nodes[i];
		Node->Rename(/*NewName=*/ NULL, /*NewOuter=*/ this, REN_DontCreateRedirectors | (true ? REN_ForceNoResetLoaders : 0) | (false ? REN_NonTransactional : 0));
		Nodes.Add(Node);
	};

	NotifyGraphChanged();

}

#undef LOCTEXT_NAMESPACE
