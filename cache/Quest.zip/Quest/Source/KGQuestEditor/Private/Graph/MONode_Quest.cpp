// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "MONode_Quest.h"
#include "../MOEditorStyle.h"
#include "EdGraph_QuestObjectivesProp.h"
#include "../Widget/SCCStandardNode.h"
#include "QuestTemplate.h"
#include "FQuestObjectivesEditor.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "../UI/QuestScrollWidget.h"
#include "../UI/QuestListViewWidget.h"
#include "ObjectTools.h"
#include "EditorUtilityLibrary.h"
#include "FileHelpers.h"
#include "../UI/QuestTreeView.h"


#define LOCTEXT_NAMESPACE "UMONode_Objective"

UMONode_Quest::UMONode_Quest(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	NodeInit();
}


void UMONode_Quest::UpdateTitle()
{
	//设置标题
	Super::UpdateTitle();
	//if (SingleQuest)
	//{
	//	SetTitleText(FText::FromString((SingleQuest->Name)));
	//}

}

void UMONode_Quest::OnMouseButtonDown()
{
	//UEdGraph_QuestObjectivesProp* Graph = Cast<UEdGraph_QuestObjectivesProp>(GetOuter());
	//if (Graph && Graph->QuestObjectivesEditor)
	//{
	//	TArray<UObject*> TempObjects;
	//	TempObjects.Add(SingleQuest);
	//	Graph->QuestObjectivesEditor->PropertyEditorSetObjects(TempObjects);
	//}
}

void UMONode_Quest::CreateAsset(UObject* TemplateObject)
{
	//if (nullptr == SingleQuest || TemplateObject != nullptr)
	//{
	//	UEdGraph_QuestObjectivesProp* Graph = Cast<UEdGraph_QuestObjectivesProp>(GetOuter());
	//	if (Graph && Graph->QuestObjectivesEditor)
	//	{
	//		UObject* EditAsset = Graph->QuestObjectivesEditor->GetQuestTreeView()->GetCurClickItemAsset();
	//		//当前选中的章节
	//		FString Path = FAssetData(EditAsset).PackageName.ToString();
	//		FString CreateAssetFullPath = "";
	//		FString AssetName = "";
	//		//找到一个可以使用的名字
	//		FString TempNum = "";
	//		
	//		for (int i = 101; i < 999; i++)
	//		{
	//			TempNum = FString::Printf(TEXT("%03d"), i);
	//			if (UGroupQuestTemplate* GroupQuest = Cast<UGroupQuestTemplate>(EditAsset))
	//			{
	//				AssetName = FString::FromInt(GroupQuest->Id) + TempNum;
	//			}
	//			CreateAssetFullPath = Path / AssetName;

	//			UObject* TempObject = Cast<UObject>(StaticLoadObject(UObject::StaticClass(), NULL, *CreateAssetFullPath));
	//			if (TempObject == nullptr)
	//			{
	//				break;
	//			}
	//		}

	//		UPackage* Package = CreatePackage(*(CreateAssetFullPath));

	//		CreateQuestPackage(Package, AssetName ,TemplateObject);
	//		//创建资源
	//		FAssetRegistryModule::AssetCreated(SingleQuest);

	//		TArray<UPackage*> OutermostPackagesToSave;
	//		OutermostPackagesToSave.Add(Package);
	//		FEditorFileUtils::PromptForCheckoutAndSave(OutermostPackagesToSave, true, true);
	//		//这里看上去是命名，其实是让文件自动迁出
	//		//UEditorUtilityLibrary::RenameAsset(SingleQuest, SingleQuest->GetName());

	//		//设置SingleQuest的ID
	//		if (UGroupQuestTemplate* GroupQuest = Cast<UGroupQuestTemplate>(EditAsset))
	//		{
	//			SingleQuest->Id = FCString::Atoi(*(FString::FromInt(GroupQuest->Id) + TempNum));
	//			SingleQuest->Name = FString::FromInt(SingleQuest->Id);
	//		}

	//		//对于QuestGroup的处理
	//		UGroupQuestTemplate* GroupQuest = Cast<UGroupQuestTemplate>(EditAsset);

	//		Graph->QuestObjectivesEditor->GetQuestTreeView()->NewQuestAsset(SingleQuest);

	//		//生成完资源后，显示该资源的属性
	//		TArray<UObject*> TempObjects;
	//		TempObjects.Add(SingleQuest);
	//		Graph->QuestObjectivesEditor->PropertyEditorSetObjects(TempObjects);

	//		//自动点击一次保存按钮
	//		Graph->QuestObjectivesEditor->GetQuestTreeView()->OnSaveButtonClick();

	//	}
	//}
}

void UMONode_Quest::CreateQuestPackage(UPackage* Package, FString AssetName, UObject* TemplateObject)
{
	//if (QuestClass)
	//{
	//	SingleQuest = NewObject<USingleQuest>(Package, *QuestClass, FName(AssetName), EObjectFlags::RF_Public | RF_Standalone, TemplateObject);
	//}
}

void UMONode_Quest::DeleteNode()
{
	//if (SingleQuest)
	//{
	//	UEdGraph_QuestObjectivesProp* Graph = Cast<UEdGraph_QuestObjectivesProp>(GetOuter());
	//	if (Graph && Graph->QuestObjectivesEditor)
	//	{
	//		Graph->QuestObjectivesEditor->GetQuestTreeView()->DeleteQuestAsset(SingleQuest);
	//	}

	//	TArray<UObject*> AssetsToDelete;
	//	AssetsToDelete.Add(SingleQuest);
	//	//ObjectTools::DeleteSingleObject(CurDeleteItem->ChapterAsset, true);
	//	ObjectTools::ForceDeleteObjects(AssetsToDelete, false);

	//}
}

void UMONode_Quest::OnMouseButtonDoubleClick()
{
	////双击时打开任务的Item
	//UEdGraph_QuestObjectivesProp* Graph = Cast<UEdGraph_QuestObjectivesProp>(GetOuter());
	//if (Graph && Graph->QuestObjectivesEditor)
	//{
	//	Graph->QuestObjectivesEditor->GetQuestTreeView()->DoubleClickQuestNode(SingleQuest);
	//}
}

void UMONode_Quest::OnSelectedNodeChanged()
{
	//UEdGraph_QuestObjectivesProp* Graph = Cast<UEdGraph_QuestObjectivesProp>(GetOuter());
	//if (Graph && Graph->QuestObjectivesEditor)
	//{
	//	Graph->QuestObjectivesEditor->GetQuestTreeView()->UpdateNodeQuestText(this);
	//}
	//if (SingleQuest)
	//{
	//	//SetTitleTextID(FText::FromString(FString::FromInt(SingleQuest->Id)));
	//}
}



#undef LOCTEXT_NAMESPACE
