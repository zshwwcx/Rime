#include "QuestEditorManagerAsset.h"
#include "Logging/LogMacros.h"
#include "Engine/Engine.h"
//#include "GameSettings.h"


UQuestEditorManagerAsset* UQuestEditorManagerAsset::GetQuestEditorManagerAsset() 
{
	//UGameSettings* GameSetting = GetMutableDefault<UGameSettings>(UGameSettings::StaticClass());
	//return GameSetting->QuestEditorManagerAsset.LoadSynchronous();
	FString TempPath = TEXT("Blueprint'/Game/Editor/Quest/QuestManagerData.QuestManagerData_C'");
	
	UBlueprintGeneratedClass* TempLoadStructObjectGeneratedClass = (UBlueprintGeneratedClass*)StaticLoadObject(UBlueprintGeneratedClass::StaticClass(), NULL, *TempPath);
	UBlueprint* TempLoadStructObject = Cast<UBlueprint>(TempLoadStructObjectGeneratedClass->ClassGeneratedBy);
	if (TempLoadStructObject)
	{
		UQuestEditorManagerAsset* QuestEditorManagerAsset = Cast<UQuestEditorManagerAsset>(TempLoadStructObject->GeneratedClass->GetDefaultObject());
		return QuestEditorManagerAsset;
	}

	return nullptr;
}


