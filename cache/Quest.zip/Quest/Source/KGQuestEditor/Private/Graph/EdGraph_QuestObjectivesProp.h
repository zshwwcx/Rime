// Copyright 15.07.2018 Tefel. All Rights Reserved.

#pragma once
#include "EdGraph/EdGraph.h"
#include "EdGraph_QuestObjectivesProp.generated.h"

struct FQuestObjectivesDataTypes {
	static const FName PinType_Entry;
	static const FName PinType_Objective;
	static const FName PinType_Input;
	static const FName PinType_Quest;
};


struct FQuestObjectivesGraphBuildError {
	TWeakObjectPtr<class UMONode_Base> NodeWithError;
	FString ErrorMessage;
	FString ErrorTooltip;
};

UCLASS()
class UEdGraph_QuestObjectivesProp : public UEdGraph {
	GENERATED_UCLASS_BODY()

public:
	void InitializeGraph();
	void RefreshNodeSelection(UEdGraphNode* Node);

	void ReGenerateAllNodes(UEdGraph* TempGraph);

	TWeakPtr<class FQuestObjectivesEditor> QuestObjectivesEditor;

private:

};
