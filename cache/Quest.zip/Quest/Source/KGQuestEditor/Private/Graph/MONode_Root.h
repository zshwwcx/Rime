// Copyright 15.07.2018 Tefel. All Rights Reserved.

#pragma once
#include "MONode_QuestAction.h"
#include "MONode_Root.generated.h"

UCLASS()
class  UMONode_Root : public UMONode_Base {
	GENERATED_UCLASS_BODY()

public:

};