// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "MONode_Base.h"
#include "MONode_Root.h"
#include "EdGraph_QuestObjectivesProp.h"
#include "../MOEditorStyle.h"
#include "QuestTemplate.h"
#include "FQuestObjectivesEditor.h"

#define LOCTEXT_NAMESPACE "MONode_Base"

void UMONode_Base::PostEditChangeProperty(struct FPropertyChangedEvent& e)
{
	Super::PostEditChangeProperty(e);

	TArray<FName> RefreshNames = {"NodeName", "AssociatedObject"};
	if (e.Property &&  RefreshNames.Contains(e.Property->GetFName())) {
		GetGraph()->NotifyGraphChanged();
	}
}

void UMONode_Base::InitRootNode()
{
	bUserDefined = false;
	Rename(NULL, GetOuter(), REN_NonTransactional);
	CreateNewGuid();
	PostPlacedNewNode();
	AllocateDefaultPins();
	NodePosX = 0;
	NodePosY = 0;
	SnapToGrid(16);
}


//FText UMONode_Base::GetNodeTitle(ENodeTitleType::Type TitleType) const
//{
//	return FText::FromName(AssociatedObject->Title);
//}

void UMONode_Base::AllocateDefaultPins()
{
	if (QuestNode_DefaultPin == EQuestNode_DefaultPin::both)
	{
		UEdGraphPin* Inputs = CreatePin(EGPD_Input, FQuestObjectivesDataTypes::PinType_Objective, TEXT("In"));
		UEdGraphPin* Outputs = CreatePin(EGPD_Output, FQuestObjectivesDataTypes::PinType_Objective, TEXT("Out"));
	}
	if (QuestNode_DefaultPin == EQuestNode_DefaultPin::in)
	{
		UEdGraphPin* Inputs = CreatePin(EGPD_Input, FQuestObjectivesDataTypes::PinType_Objective, TEXT("In"));
	}
	if (QuestNode_DefaultPin == EQuestNode_DefaultPin::out)
	{
		UEdGraphPin* Outputs = CreatePin(EGPD_Output, FQuestObjectivesDataTypes::PinType_Objective, TEXT("Out"));
	}
}


const FSlateBrush* UMONode_Base::GetNodeIcon() const
{
	if (QuestNode_Icon == EQuestNode_Icon::entry)
	{
		return FMOEditorStyle::GetBrush(TEXT("MOEditor.nodeicon.entry"));
	}
	if (QuestNode_Icon == EQuestNode_Icon::objective)
	{
		return FMOEditorStyle::GetBrush(TEXT("MOEditor.nodeicon.objective"));
	}
	if (QuestNode_Icon == EQuestNode_Icon::success)
	{
		return FMOEditorStyle::GetBrush(TEXT("MOEditor.nodeicon.success"));
	}
	if (QuestNode_Icon == EQuestNode_Icon::fail)
	{
		return FMOEditorStyle::GetBrush(TEXT("MOEditor.nodeicon.failure"));
	}
	return FAppStyle::Get().GetBrush(TEXT("Graph.StateNode.Icon"));
}

FSlateColor UMONode_Base::GetNodeBackgroundColor() const
{
	return FLinearColor(0.08f, 0.08f, 0.08f);

}

FLinearColor UMONode_Base::GetNodeTitleColor() const
{
	return FLinearColor(0.7f, 0.7f, 0.7f);
}

UEdGraphPin* UMONode_Base::GetInputPin() const
{
	if (QuestNode_DefaultPin == EQuestNode_DefaultPin::both || QuestNode_DefaultPin == EQuestNode_DefaultPin::in)
	{
		return Pins[0];
	}
	
	return nullptr;
}

UEdGraphPin* UMONode_Base::GetOutputPin() const
{
	if (QuestNode_DefaultPin == EQuestNode_DefaultPin::both)
	{
		return Pins[1];
	}
	if (QuestNode_DefaultPin == EQuestNode_DefaultPin::out)
	{
		return Pins[0];
	}

	return nullptr;
}

void UMONode_Base::NodeConnectionListChanged()
{
	UEdGraphNode::NodeConnectionListChanged();
	GetGraph()->NotifyGraphChanged();
}

void UMONode_Base::DestroyAllChildNodes()
{
	TArray<UMONode_Base*> NodesToRemove;
	for (auto Link : GetOutputPin()->LinkedTo)
	{
		UMONode_Base* OwningNode = Cast<UMONode_Base>(Link->GetOwningNode());
		NodesToRemove.Add(OwningNode);
	}

	for (int32 Index = 0; Index < NodesToRemove.Num(); Index++)
	{
		NodesToRemove[Index]->DestroyNode();
	}
}

UMONode_Base* UMONode_Base::GetParentNode()
{
	UEdGraphPin* MyInputPin = GetInputPin();
	UEdGraphPin* MyParentOutputPin = nullptr;
	if (MyInputPin != nullptr && MyInputPin->LinkedTo.Num() > 0)
	{
		MyParentOutputPin = MyInputPin->LinkedTo[0];
		if (MyParentOutputPin != nullptr)
		{
			if (MyParentOutputPin->GetOwningNode() != nullptr)
			{
				return CastChecked<UMONode_Base>(MyParentOutputPin->GetOwningNode());
			}
		}
	}

	return nullptr;
}

TArray<UMONode_Base*> UMONode_Base::GetParentNodes()
{
	UEdGraphPin* MyInputPin = GetInputPin();
	TArray<UMONode_Base*> ParentNodes = TArray<UMONode_Base*>();

	if (MyInputPin != nullptr && MyInputPin->LinkedTo.Num() > 0)
	{
		for (UEdGraphPin* MyParentOutputPin : MyInputPin->LinkedTo)
		{
			if (MyParentOutputPin->GetOwningNode() != nullptr)
			{
				ParentNodes.AddUnique(CastChecked<UMONode_Base>(MyParentOutputPin->GetOwningNode()));
			}
		}
	}

	return ParentNodes;
}

FText UMONode_Base::GetHeadTitle() const
{
	return TitleName;
}

FText UMONode_Base::GetHeadTitleID() const
{
	return TitleID;
}

FText UMONode_Base::GetHeadTitleType() const
{
	return TitleType;
}

void UMONode_Base::UpdateTitle()
{
	SetTitleTextType(FText::FromString(NodeTitle));
}

void UMONode_Base::OnMouseButtonDown()
{

}

void UMONode_Base::OnMouseButtonDoubleClick()
{

}

void UMONode_Base::DeleteNode()
{

}

void UMONode_Base::CreateAsset(UObject* TemplateObject)
{

}

void UMONode_Base::OnSelectedNodeChanged()
{

}

void UMONode_Base::PrepareForCopying()
{
	//AssociatedObject->Rename(NULL, this, REN_NonTransactional);

	Super::PrepareForCopying();
}

void UMONode_Base::SetTitle(FName NewTitle)
{
	/*if (IsValid(AssociatedObject))
	{
		AssociatedObject->Title = NewTitle;
	}*/
}

void UMONode_Base::PostCopying()
{
	//AssociatedObject->Rename(NULL, FindRootNode()->Quest, REN_NonTransactional);
}

void UMONode_Base::PinConnectionListChanged(UEdGraphPin* Pin)
{
	//if (GetInputPin() == Pin)
	//{
	//	AssociatedObject->RemoveFromParentNodes();
	//	for (UMONode_Base* ParentNode : GetParentNodes())
	//	{
	//		ParentNode->AssociatedObject->AddChildNode(AssociatedObject);
	//	}		

	//	if (UEdGraph_QuestObjectivesProp* QuestGraph = Cast<UEdGraph_QuestObjectivesProp>(GetGraph()))
	//	{
	//		QuestGraph->UpdateNegativePositiveRoutes();
	//	}
	//}
}



const FSlateBrush* UMONode_Base::GetNodeBackgroundImage() const
{
	if (QuestNode_BackgroundImage == EQuestNode_BackgroundImage::blue)
	{
		return FMOEditorStyle::GetBrush("MOEditor.background_blue");
	}
	if (QuestNode_BackgroundImage == EQuestNode_BackgroundImage::green)
	{
		return FMOEditorStyle::GetBrush("MOEditor.background_green");
	}
	if (QuestNode_BackgroundImage == EQuestNode_BackgroundImage::red)
	{
		return FMOEditorStyle::GetBrush("MOEditor.background_red");
	}
	return FMOEditorStyle::GetBrush("MOEditor.background_red");
}

TArray<UMONode_Base*> UMONode_Base::GetNodeChildren()
{
	TArray<UMONode_Base*> Children;
	if (UEdGraphPin* Pin = GetOutputPin())
	{
		for (UEdGraphPin* ChildPin : Pin->LinkedTo)
		{
			if (UMONode_Base* ChildNode = Cast<UMONode_Base>(ChildPin->GetOwningNode()))
			{
				Children.Add(ChildNode);
			}
		}
	}

	return Children;
}

bool UMONode_Base::HasAnyParentNodes()
{
	if (UEdGraphPin* Pin = GetInputPin())
	{
		return (Pin->LinkedTo.Num() > 0);
	}
	return false;
}

bool UMONode_Base::HasAnyChildNodes()
{
	if (UEdGraphPin* Pin = GetOutputPin())
	{
		return (Pin->LinkedTo.Num() > 0);
	}

	return false;
}

void UMONode_Base::AutowireNewNode(UEdGraphPin* FromPin)
{
	if (!FromPin) {
		return;
	}

	UEdGraphPin* InputPin = GetInputPin();

	// Make sure we have no loops with this connection
	const UEdGraphSchema* Schema = GetGraph()->GetSchema();
	const FPinConnectionResponse ConnectionValid = Schema->CanCreateConnection(FromPin, InputPin);
	if (ConnectionValid.Response == CONNECT_RESPONSE_MAKE)
	{
		FromPin->MakeLinkTo(InputPin);

		FromPin->GetOwningNode()->PinConnectionListChanged(FromPin);
		PinConnectionListChanged(InputPin);
	}
}

void UMONode_Base::DestroyNode()
{
	BreakAllNodeLinks();
	//AssociatedObject->RemoveFromParentNodes();
	Super::DestroyNode();
}

void UMONode_Base::PostPasteNode()
{
	// Set parent node to nullptr and removing children because created objects are new (invalid)
	//AssociatedObject->RemoveFromParentNodes();
	//AssociatedObject->ClearChildNodes();
}

void UMONode_Base::PostPasteNodeFinal()
{
	// Get new unique name from appending new unique id
	FString Left = "";
	//AssociatedObject->GetName().Split("_", &Left, nullptr, ESearchCase::IgnoreCase, ESearchDir::FromEnd);
	FString NewName = Left + "_" + FString::FromInt(GetUniqueID());
	//AssociatedObject->Rename(*NewName, FindRootNode()->Quest, REN_NonTransactional);

	if (HasAnyChildNodes())
	{
		//CreateModelChilds();
	}
}

class UMONode_Root* UMONode_Base::FindRootNode()
{
	if (GetOuter()->IsA(UEdGraph::StaticClass()))
	{
		TArray<UMONode_Root*> RootNodes;
		GetGraph()->GetNodesOfClass(RootNodes);
		if (RootNodes.Num() > 0)
		{
			return RootNodes[0];
		}
	}
	return nullptr;
}

#undef LOCTEXT_NAMESPACE
