// Copyright 15.07.2018 Tefel. All Rights Reserved.

#pragma once
#include "MONode_Base.h"
#include "Styling/SlateBrush.h"
#include "EdGraph/EdGraphPin.h"
#include "MONode_QuestAction.generated.h"

UCLASS(Blueprintable)
class  UMONode_QuestAction : public UMONode_Base {
	GENERATED_UCLASS_BODY()

public:
	virtual void PostLoad() override;

	// Begin UEdGraphNode interface.
	// End UEdGraphNode interface.

	virtual void UpdateTitle() override;

	virtual void OnMouseButtonDown() override;

	virtual void CreateAsset(UObject* TemplateObject = nullptr) override;

	void SetID();

	virtual UObject* GetParentSingleQuest(class UEdGraph_QuestObjectivesProp* Graph);

	virtual void OnSelectedNodeChanged();

	virtual void NodeInit() override;

public:
	UPROPERTY()
	class UQuestActionNode* QuestActionNode = nullptr;

	//QuestAction节点属性类型
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	TSubclassOf<UQuestActionNode> QuestActionNodeClassType;

	//UPROPERTY()
	//TWeakObjectPtr<class UQuestActionNode> QuestActionNodePtr;
};
