// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "MONode_QuestAction.h"
#include "EdGraph_QuestObjectivesProp.h"
#include "MONode_Root.h"
#include "../MOEditorStyle.h"
#include "QuestTemplate.h"
#include "../Widget/SCCStandardNode.h"
#include "FQuestObjectivesEditor.h"
//#include "EditorAssetLibrary.h"
#include "../UI/QuestScrollWidget.h"
#include "../UI/QuestListViewWidget.h"
#include "../UI/QuestTreeView.h"



UMONode_QuestAction::UMONode_QuestAction(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	NodeInit();
}

void UMONode_QuestAction::PostLoad()
{
	Super::PostLoad();

}

void UMONode_QuestAction::UpdateTitle()
{
	//设置标题
	Super::UpdateTitle();

	//if (QuestActionNode)
	//{
	//	SetTitleText(FText::FromString((QuestActionNode->Name)));
	//}
}

void UMONode_QuestAction::OnMouseButtonDown()
{
	UEdGraph_QuestObjectivesProp* Graph = Cast<UEdGraph_QuestObjectivesProp>(GetOuter());
	if (Graph && Graph->QuestObjectivesEditor.IsValid())
	{
		TArray<UObject*> TempObjects;
		TempObjects.Add(QuestActionNode);
		Graph->QuestObjectivesEditor.Pin()->PropertyEditorSetObjects(TempObjects);
	}
}

void UMONode_QuestAction::CreateAsset(UObject* TemplateObject)
{
	if (nullptr == QuestActionNode || TemplateObject != nullptr)
	{
		//生成Object
		UEdGraph_QuestObjectivesProp* Graph = Cast<UEdGraph_QuestObjectivesProp>(GetOuter());
		if (Graph && Graph->QuestObjectivesEditor.IsValid())
		{
			//当前选中的章节
			QuestActionNode = NewObject<UQuestActionNode>(GetParentSingleQuest(Graph), *QuestActionNodeClassType, NAME_None, RF_NoFlags, TemplateObject);

			//生成完资源后，显示该资源的属性
			TArray<UObject*> TempObjects;
			TempObjects.Add(QuestActionNode);
			Graph->QuestObjectivesEditor.Pin()->PropertyEditorSetObjects(TempObjects);

			SetID();
		}
	}
}

void UMONode_QuestAction::SetID()
{
	////生成id
	////先获取SingleQuest的ID
	//UEdGraph_QuestObjectivesProp* Graph = Cast<UEdGraph_QuestObjectivesProp>(GetOuter());
	//USingleQuest* ParentSingleQuest = Cast<USingleQuest>(Graph->QuestObjectivesEditor->GetQuestTreeView()->GetCurClickItemAsset());

	//FString TempNum = "";
	//int64 ActionQuestID = 0;
	//for (int i = 101; i < 999; i++)
	//{
	//	TempNum = FString::Printf(TEXT("%03d"), i);
	//	FString TempActionQuestIDString = FString::FromInt(ParentSingleQuest->Id) + TempNum;
	//	ActionQuestID = FCString::Atoi(*TempActionQuestIDString);
	//	bool bFoundHaveID = false;
	//	for (UQuestActionNode* ActionNode : ParentSingleQuest->QuestActionNodeArray)
	//	{
	//		if (ActionNode->Id == ActionQuestID)
	//		{
	//			bFoundHaveID = true;
	//		}
	//	}
	//	if (!bFoundHaveID)
	//	{
	//		break;
	//	}
	//}
	//QuestActionNode->Id = ActionQuestID;

	////
	//Graph->QuestObjectivesEditor->GetQuestTreeView()->OnSaveButtonClick();

}

UObject* UMONode_QuestAction::GetParentSingleQuest(UEdGraph_QuestObjectivesProp* Graph)
{
	USingleQuest* ParentSingleQuest = Cast<USingleQuest>(Graph->QuestObjectivesEditor.Pin()->GetQuestTreeView()->GetCurClickItemAsset());
	check(ParentSingleQuest != nullptr);
	return ParentSingleQuest;
}

void UMONode_QuestAction::OnSelectedNodeChanged()
{
	UpdateTitle();
}

void UMONode_QuestAction::NodeInit()
{
	SetTitle("Entry Node");
	bUserDefined = true;
	bShowIndexOrder = true;
	UpdateTitle();
}

