//// Copyright 15.07.2018 Tefel. All Rights Reserved.
//
//#include "MONode_Quest_Reward.h"
//#include "../MOEditorStyle.h"
//#include "EdGraph_QuestObjectivesProp.h"
//#include "../Widget/SCCStandardNode.h"
//#include "QuestTemplate.h"
//#include "../FQuestObjectivesEditor.h"
//#include "AssetRegistry/AssetRegistryModule.h"
//#include "../UI/QuestScrollWidget.h"
//#include "../UI/QuestListViewWidget.h"
//#include "ObjectTools.h"
//#include "EditorUtilityLibrary.h"
//#include "FileHelpers.h"
//#include "../UI/QuestTreeView.h"
//
//
//#define LOCTEXT_NAMESPACE "UMONode_Objective"
//
//UMONode_Quest_Reward::UMONode_Quest_Reward(const FObjectInitializer& ObjectInitializer)
//	: Super(ObjectInitializer)
//{
//	//AssociatedObject = ObjectInitializer.CreateDefaultSubobject<UMOObjectiveNode>(GetOuter(), *(GetName() + "_" + FString::FromInt(GetUniqueID())));
//	SetTitle("GroupQuest Node");
//
//
//}
//
//void UMONode_Quest_Reward::CreateQuestPackage(UPackage* Package, FString AssetName, UObject* TemplateObject)
//{
//	//SingleQuest = NewObject<USingleQuest>(Package, *QuestClass, FName(AssetName), EObjectFlags::RF_Public | RF_Standalone, TemplateObject);
//
//}
//
//void UMONode_Quest_Reward::UpdateTitle()
//{
//	//设置标题
//	SetTitleTextType(FText::FromString(TEXT("任务_关卡奖励: ")));
//	if (SingleQuest)
//	{
//		if (USingleQuest_LevelReward* SingleQuest_Reward = Cast<USingleQuest_LevelReward>(SingleQuest))
//		{
//			FText RewardName;
//			UEnum::GetDisplayValueAsText(SingleQuest_Reward->StarReward, RewardName);
//			SetTitleTextType(FText::FromString(TEXT("任务_关卡奖励: ") + RewardName.ToString()));
//
//			if (SingleQuest_Reward->bFirstReward)
//			{
//				SetTitleTextType(FText::FromString(TEXT("任务_关卡奖励(首次): ") + RewardName.ToString()));
//			}
//		}
//		SetTitleText(FText::FromString((SingleQuest->Name)));
//	}
//}
//
//
//
//#undef LOCTEXT_NAMESPACE
