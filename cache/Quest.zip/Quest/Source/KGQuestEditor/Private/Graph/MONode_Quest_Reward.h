//// Copyright 15.07.2018 Tefel. All Rights Reserved.
//
//#pragma once
//#include "MONode_Base.h"
//#include "MONode_Quest.h"
//#include "MONode_Quest_Reward.generated.h"
//
//UCLASS(Blueprintable)
//class  UMONode_Quest_Reward : public UMONode_Quest {
//	GENERATED_UCLASS_BODY()
//
//public:
//	// Begin UEdGraphNode interface.
//	// End UEdGraphNode interface.
//
//	virtual void CreateQuestPackage(UPackage* Package, FString AssetName, UObject* TemplateObject = nullptr) override;
//
//	virtual void UpdateTitle() override;
//
//
//public:
//
//
//
//};