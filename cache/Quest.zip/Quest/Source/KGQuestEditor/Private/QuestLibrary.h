// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

#include "Subsystems/EditorAssetSubsystem.h"



class FQuestLibrary
{

public:

	static void ExportAllQuestData();

	static void ExportQuestDataByType(FString QuestType, FString FileName);

	static void ExportSingleQuestNode();

	static void ExportQuestActionNode();

	static bool QuestSaveAsset(const FString& AssetsToSave, bool bOnlyIfIsDirty = true);
};
