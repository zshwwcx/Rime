// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "MOEditorStyle.h"
#include "Framework/Application/SlateApplication.h"
#include "Styling/SlateStyleRegistry.h"
#include "Slate/SlateGameResources.h"
#include "Interfaces/IPluginManager.h"

TSharedPtr< FSlateStyleSet > FMOEditorStyle::StyleInstance = NULL;

void FMOEditorStyle::Initialize()
{
	if (!StyleInstance.IsValid())
	{
		StyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FMOEditorStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	ensure(StyleInstance.IsUnique());
	StyleInstance.Reset();
}

FName FMOEditorStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("MOEditorStyle"));
	return StyleSetName;
}


#define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define BOX_BRUSH( RelativePath, ... ) FSlateBoxBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define BORDER_BRUSH( RelativePath, ... ) FSlateBorderBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define DEFAULT_FONT(...) FCoreStyle::GetDefaultFontStyle(__VA_ARGS__)

const FVector2D TempIcon16x16(16.0f, 16.0f);
const FVector2D TempIcon20x20(20.0f, 20.0f);
const FVector2D TempIcon32x32(32.0f, 32.0f);
const FVector2D TempIcon40x40(40.0f, 40.0f);
const FVector2D TempIcon64x64(64.0f, 64.0f);


TSharedRef< FSlateStyleSet > FMOEditorStyle::Create()
{
	TSharedRef< FSlateStyleSet > Style = MakeShareable(new FSlateStyleSet("MOEditorStyle"));
	//修改目录
	//Style->SetContentRoot(IPluginManager::Get().FindPlugin("QuestObjectives")->GetBaseDir() / TEXT("Resources"));
	FString ProjectDir = FPaths::ProjectDir();
	Style->SetContentRoot(ProjectDir / TEXT("Content/Template/Quest/Resources"));

	// Asset icon
	Style->Set("ClassThumbnail.Quest", new IMAGE_BRUSH(TEXT("QuestClassThumnail"), TempIcon64x64));
	Style->Set("ClassIcon.Quest", new IMAGE_BRUSH(TEXT("QuestClassIcon"), TempIcon16x16));

	Style->Set("ClassThumbnail.ScriptedAction", new IMAGE_BRUSH(TEXT("ScriptedActionClassThumnail"), TempIcon64x64));
	Style->Set("ClassIcon.ScriptedAction", new IMAGE_BRUSH(TEXT("ScriptedActionClassIcon"), TempIcon16x16));

	Style->Set("ClassThumbnail.ReferencedQuestObject", new IMAGE_BRUSH(TEXT("ReferencedQuestObjectClassThumnail"), TempIcon64x64));
	Style->Set("ClassIcon.ReferencedQuestObject", new IMAGE_BRUSH(TEXT("ReferencedQuestObjectClassIcon"), TempIcon16x16));

	static const FName PROPERTY_DialogueClassIcon;
	static const FName PROPERTY_DialogueClassThumbnail;

	Style->Set("MOEditor.background_blue", new BOX_BRUSH(TEXT("bg_blue"), FMargin(4.f / 16.f)));
	Style->Set("MOEditor.background_purple", new BOX_BRUSH(TEXT("bg_purple"), FMargin(4.f / 16.f)));
	Style->Set("MOEditor.background_red", new BOX_BRUSH(TEXT("bg_red"), FMargin(4.f / 16.f)));
	Style->Set("MOEditor.background_green", new BOX_BRUSH(TEXT("bg_green"), FMargin(4.f / 16.f)));
	Style->Set("MOEditor.background_yellow", new BOX_BRUSH(TEXT("bg_yellow"), FMargin(4.f / 16.f)));

	Style->Set("MOEditor.arrow_down", new IMAGE_BRUSH(TEXT("arrow_down"), FVector2D(64.0f, 12.0f)));
	Style->Set("MOEditor.arrow_up", new IMAGE_BRUSH(TEXT("arrow_up"), FVector2D(64.0f, 12.0f)));

	Style->Set("MOEditor.nodeicon.root", new IMAGE_BRUSH(TEXT("nodeicon_root"), TempIcon20x20));
	Style->Set("MOEditor.nodeicon.entry", new IMAGE_BRUSH(TEXT("nodeicon_entry"), TempIcon20x20));
	Style->Set("MOEditor.nodeicon.success", new IMAGE_BRUSH(TEXT("nodeicon_success"), TempIcon20x20));
	Style->Set("MOEditor.nodeicon.failure", new IMAGE_BRUSH(TEXT("nodeicon_failure"), TempIcon20x20));
	Style->Set("MOEditor.nodeicon.objective", new IMAGE_BRUSH(TEXT("nodeicon_objective"), TempIcon20x20));

	Style->Set("MOEditor.nodecirclebackground", new  IMAGE_BRUSH(TEXT("nodecirclebackground"), TempIcon64x64));

	// TextStyle
	{
		Style->Set("MO.NodeTitle", FTextBlockStyle()
			.SetFont(DEFAULT_FONT("Bold", 11))
			.SetColorAndOpacity(FLinearColor(230.0f / 255.0f, 230.0f / 255.0f, 230.0f / 255.0f))
			.SetShadowOffset(FVector2D(1, 1))
			.SetShadowColorAndOpacity(FLinearColor(0.f, 0.f, 0.f, 0.7f)));

		Style->Set("MO.ObjectiveCount", FTextBlockStyle()
			.SetFont(DEFAULT_FONT("Bold", 10))
			.SetColorAndOpacity(FLinearColor(230.0f / 255.0f, 230.0f / 255.0f, 230.0f / 255.0f))
			.SetShadowOffset(FVector2D(1, 1))
			.SetShadowColorAndOpacity(FLinearColor(0.f, 0.f, 0.f, 0.7f)));

		Style->Set("MO.NodeText", FTextBlockStyle()
			.SetFont(DEFAULT_FONT("Normal", 8))
			.SetColorAndOpacity(FLinearColor(218.0f / 255.0f, 218.0f / 255.0f, 218.0f / 255.0f)));

		Style->Set("PivotTool.NormalText.Blue", FTextBlockStyle()
			.SetFont(DEFAULT_FONT("Fonts/DroidSansMono", 8))
			.SetColorAndOpacity(FLinearColor(.0f, .0f, 1.0f))
			.SetHighlightColor(FLinearColor(.0f, .0f, 1.0f)));

		Style->Set("PivotTool.ButtonText.Roboto", FTextBlockStyle()
			.SetColorAndOpacity(FLinearColor(1.0f, 1.0f, 1.0f))
			.SetHighlightColor(FLinearColor(1.0f, 1.0f, 1.0f)));

		Style->Set("PivotTool.ButtonText", FTextBlockStyle()
			.SetColorAndOpacity(FLinearColor(1.0f, 1.0f, 1.0f))
			.SetHighlightColor(FLinearColor(1.0f, 1.0f, 1.0f)));

		Style->Set("PivotTool.ButtonText.Black", FTextBlockStyle()
			.SetColorAndOpacity(FLinearColor(0.f, 0.f, 0.f))
			.SetHighlightColor(FLinearColor(0.f, 0.f, 0.f))
		);
	}



	FTextBlockStyle NormalText;
	FTextBlockStyle GraphNodeTitle = FTextBlockStyle(NormalText)
		.SetFont(DEFAULT_FONT("Bold", 11))
		.SetColorAndOpacity(FLinearColor(230.0f / 255.0f, 230.0f / 255.0f, 230.0f / 255.0f))
		.SetShadowOffset(FVector2D(2, 2))
		.SetShadowColorAndOpacity(FLinearColor(0.f, 0.f, 0.f, 0.7f));
	Style->Set("Graph.Node.NodeTitle", GraphNodeTitle);


	FTextBlockStyle TextStyle = FTextBlockStyle(NormalText)
		.SetFont(DEFAULT_FONT("Bold", 10))
		.SetColorAndOpacity(FLinearColor(218.0f / 255.0f, 218.0f / 255.0f, 218.0f / 255.0f))
		.SetShadowOffset(FVector2D::ZeroVector)
		.SetShadowColorAndOpacity(FLinearColor(0.f, 0.f, 0.f, 0.7f));
	Style->Set("Graph.Node.Text", TextStyle);

	FEditableTextBoxStyle GraphNodeTitleEditableText = FEditableTextBoxStyle()
		.SetFont(NormalText.Font);

	Style->Set("Graph.Node.NodeTitleEditableText", GraphNodeTitleEditableText);

	Style->Set("Graph.Node.NodeTitleInlineEditableText", FInlineEditableTextBlockStyle()
		.SetTextStyle(GraphNodeTitle)
		.SetEditableTextBoxStyle(GraphNodeTitleEditableText)
	);

	if(FSlateApplication::IsInitialized())
	{
		Style->Set("DefaultAppIconEditor", new FSlateBrush(*FSlateApplication::Get().GetAppIcon()));
	}

	return Style;
}


#undef IMAGE_BRUSH
#undef BOX_BRUSH
#undef BORDER_BRUSH
#undef DEFAULT_FONT

void FMOEditorStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

const ISlateStyle& FMOEditorStyle::Get()
{
	return *StyleInstance;
}

const FSlateBrush* FMOEditorStyle::GetBrush(FName PropertyName, const ANSICHAR* Specifier /*= NULL*/)
{
	return StyleInstance->GetBrush(PropertyName, Specifier);
}