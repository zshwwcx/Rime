#include "EDGraphNode_EntryNode.h"

#define LOCTEXT_NAMESPACE "EDGraphNode_EntryNode"


UEDGraphNode_EntryNode::UEDGraphNode_EntryNode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bCanRenameNode = false;
}

void UEDGraphNode_EntryNode::AllocateDefaultPins()
{

	if (NodeType == EDNodeType::QuestBegin)
	{
		CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_Exec, "Quest Begin");

		CreatePin(EGPD_Output, TEXT("Transition"), TEXT("Action"));
	}
}

FText UEDGraphNode_EntryNode::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	UEdGraph* Graph = GetGraph();
	return FText::FromString(Graph->GetName());
}

FText UEDGraphNode_EntryNode::GetTooltipText() const
{
	return LOCTEXT("EDEntryNodeTooltip", "Entry Event");
}

void UEDGraphNode_EntryNode::PostPasteNode()
{
	Super::PostPasteNode();
}

void UEDGraphNode_EntryNode::PostPlacedNewNode()
{
	//UClass* NodeClass = UEDEventTrigger::StaticClass();
	//if (NodeClass && (NodeInstance == nullptr))
	//{
	//	UEdGraph* MyGraph = GetGraph();
	//	UObject* GraphOwner = MyGraph ? MyGraph->GetOuter() : nullptr;
	//	if (GraphOwner)
	//	{
	//		NodeInstance = NewObject<UObject>(GraphOwner, NodeClass);
	//		NodeInstance->SetFlags(RF_Transactional);
	//	}
	//}
}

void UEDGraphNode_EntryNode::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

UEdGraphPin* UEDGraphNode_EntryNode::GetNextQuestOutPin()
{
	for (UEdGraphPin* Pin : Pins)
	{
		if (Pin->Direction == EGPD_Output && Pin->PinName == "Quest Begin")
		{
			return Pin;
		}
	}

	return nullptr;
}


#undef LOCTEXT_NAMESPACE