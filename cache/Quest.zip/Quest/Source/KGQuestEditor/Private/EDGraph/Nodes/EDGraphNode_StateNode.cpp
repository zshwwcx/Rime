#include "EDGraphNode_StateNode.h"

#include "Kismet2/Kismet2NameValidators.h"
#include "UObject/UObjectThreadContext.h"
#include "../Graph/EventDrivenGraphSchema.h"
#include "QuestTemplate.h"
#include "QuestSettings.h"
#include "../../FileAsset/QuestExportLua.h"

#define LOCTEXT_NAMESPACE "EDGraphStateNode"

UE_DISABLE_OPTIMIZATION_SHIP

class FEDStateNodeNameValidator : public FStringSetNameValidator
{
public:
	FEDStateNodeNameValidator(const UEDGraphNode_StateNodeBase* InStateNode)
		: FStringSetNameValidator(FString())
	{
		//TArray<UEDGraphNode_StateNodeBase*> Nodes;
		//USMGraph* StateMachine = CastChecked<USMGraph>(InStateNode->GetOuter());

		//StateMachine->GetNodesOfClass<UEDGraphNode_StateNodeBase>(Nodes);
		//for (auto NodeIt = Nodes.CreateIterator(); NodeIt; ++NodeIt)
		//{
		//	UEDGraphNode_StateNodeBase* Node = *NodeIt;
		//	if (Node != InStateNode)
		//	{
		//		Names.Add(Node->GetStateName());
		//	}
		//}
	}

	// Begin FEDStateNodeNameValidator
	virtual EValidatorResult IsValid(const FString& Name, bool bOriginal) override
	{
		EValidatorResult Result = FStringSetNameValidator::IsValid(Name, bOriginal);

		//if (Result == EValidatorResult::Ok)
		//{
		//	if (Name.Len() > 100)
		//	{
		//		Result = EValidatorResult::TooLong;
		//	}
		//	else if (FSMBlueprintEditorUtils::GetProjectEditorSettings()->bRestrictInvalidCharacters)
		//	{
		//		FText Reason;
		//		if (!FName(Name).IsValidXName(Reason, LD_INVALID_STATENAME_CHARACTERS))
		//		{
		//			Result = EValidatorResult::ContainsInvalidCharacters;
		//		}
		//		else if (Name.Compare(TEXT("Sequencer"), ESearchCase::IgnoreCase) == 0)
		//		{
		//			// Can cause problems during copy & paste.
		//			Result = EValidatorResult::LocallyInUse;
		//		}
		//	}
		//}

		return Result;
	}
	// End FEDStateNodeNameValidator
};

UEDGraphNode_StateNodeBase::UEDGraphNode_StateNodeBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer), bAlwaysUpdate_DEPRECATED(false), bDisableTickTransitionEvaluation_DEPRECATED(false),
	bEvalTransitionsOnStart_DEPRECATED(false), bExcludeFromAnyState_DEPRECATED(false),
	bCanTransitionToSelf(false)
{
	bCanRenameNode = false;
}

void UEDGraphNode_StateNodeBase::AllocateDefaultPins()
{

	//if (NodeType == EDNodeType::QuestEnd)
	//{
	//	CreatePin(EGPD_Input, TEXT("Transition"), TEXT("In"));

	//	CreatePin(EGPD_Output, TEXT("Transition"), TEXT("Success"));
	//	CreatePin(EGPD_Output, TEXT("Transition"), TEXT("Failed"));
	//}
	//else
	{
		CreatePin(EGPD_Input, TEXT("Transition"), TEXT("In"));
		CreatePin(EGPD_Output, TEXT("Transition"), TEXT("Out"));

		if (NodeType == EDNodeType::QuestProgress || NodeType == EDNodeType::QuestEnd)
		{
			CreatePin(EGPD_Output, TEXT("Transition"), TEXT("Out2"));
		}
	}

}

FText UEDGraphNode_StateNodeBase::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	FString StateName = GetStateName();
	return FText::FromString(StateName);
}

void UEDGraphNode_StateNodeBase::AutowireNewNode(UEdGraphPin* FromPin)
{
	Super::AutowireNewNode(FromPin);

	//if (FromPin != nullptr)
	//{
	//	UEdGraphPin* InputPin = GetInputPin();

	//	if (InputPin && GetSchema()->TryCreateConnection(FromPin, InputPin))
	//	{
	//		FromPin->GetOwningNode()->NodeConnectionListChanged();
	//	}
	//}
}

void UEDGraphNode_StateNodeBase::BindNodeData()
{
	if (NodeInstance != nullptr)
	{
		if (UQuestActionBase* TNode = Cast<UQuestActionBase>(NodeInstance))
		{
			TNode->OnRefreshImportantData.RemoveAll(this);
			TNode->OnRefreshImportantData.AddUObject(this, &UEDGraphNode_StateNodeBase::ExternalUpdateNodeName);
		}

		if (UQuestTargetBase* TNode = Cast<UQuestTargetBase>(NodeInstance))
		{
			TNode->OnRefreshImportantData.RemoveAll(this);
			TNode->OnRefreshImportantData.AddUObject(this, &UEDGraphNode_StateNodeBase::ExternalUpdateNodeName);
		}

		if(UQuestChapter* TNode = Cast<UQuestChapter>(NodeInstance))
		{
			TNode->OnRefreshChapter.RemoveAll(this);
			TNode->OnRefreshChapter.AddUObject(this, &UEDGraphNode_StateNodeBase::ExternalUpdateNodeName);
		}
		
		if(UChapterEnd* TNode = Cast<UChapterEnd>(NodeInstance))
		{
			TNode->OnChapterEndChanged.RemoveAll(this);
			TNode->OnChapterEndChanged.AddUObject(this, &UEDGraphNode_StateNodeBase::ExternalUpdateNodeName);
		}

		if(UQuestRing* TNode = Cast<UQuestRing>(NodeInstance))
		{
			TNode->OnRefreshRingname.RemoveAll(this);
			TNode->OnRefreshRingname.AddUObject(this, &UEDGraphNode_StateNodeBase::ExternalUpdateNodeName);
		}
		
		if (UQuest* TNode = Cast<UQuest>(NodeInstance))
		{
			TNode->OnRefreshQuestName.RemoveAll(this);
			TNode->OnRefreshQuestName.AddUObject(this, &UEDGraphNode_StateNodeBase::ExternalUpdateNodeName);
		}
	}
}

void UEDGraphNode_StateNodeBase::UnBindNodeData()
{
	if (NodeInstance != nullptr)
	{
		if (UQuestActionBase* TNode = Cast<UQuestActionBase>(NodeInstance))
		{
			TNode->OnRefreshImportantData.RemoveAll(this);
		}

		if (UQuestTargetBase* TNode = Cast<UQuestTargetBase>(NodeInstance))
		{
			TNode->OnRefreshImportantData.RemoveAll(this);
		}

		if (UQuestChapter* TNode = Cast<UQuestChapter>(NodeInstance))
		{
			TNode->OnRefreshChapter.RemoveAll(this);
		}

		if (UQuestRing* TNode = Cast<UQuestRing>(NodeInstance))
		{
			TNode->OnRefreshRingname.RemoveAll(this);
		}

		if(UChapterEnd* TNode = Cast<UChapterEnd>(NodeInstance))
		{
			TNode->OnChapterEndChanged.RemoveAll(this);
		}
		
		if (UQuest* TNode = Cast<UQuest>(NodeInstance))
		{
			TNode->OnRefreshQuestName.RemoveAll(this);
		}
	}
}

void UEDGraphNode_StateNodeBase::PostLoad()
{
	Super::PostLoad();

	BindNodeData();
}

void UEDGraphNode_StateNodeBase::PostPlacedNewNode()
{
	UClass* NodeClass = ClassData.GetClass(true);
	if (NodeClass && (NodeInstance == nullptr))
	{
		NodeInstance = NewObject<UObject>(this, NodeClass);
		NodeInstance->SetFlags(RF_Transactional);
		if (UQuestActionBase* QuestActionData = Cast<UQuestActionBase>(NodeInstance))
		{
			QuestActionData->UniqueID = FString::Printf(TEXT("%u"), GetTypeHash(FGuid::NewGuid()));
		}
		else if (UQuestTargetBase* QuestTargetData = Cast<UQuestTargetBase>(NodeInstance))
		{
			QuestTargetData->UniqueID = GetTypeHash(FGuid::NewGuid());
		}
	}
	else if (NodeInstance)
	{
		if (UQuestActionBase* QuestActionData = Cast<UQuestActionBase>(NodeInstance))
		{
			NodeInstance->RemoveFromRoot();
			NodeInstance->Rename(nullptr, this, REN_None);
			if (QuestActionData->UniqueID.IsEmpty())
				QuestActionData->UniqueID = FString::Printf(TEXT("%u"), GetTypeHash(FGuid::NewGuid()));
		}
		else if (UQuestTargetBase* QuestTargetData = Cast<UQuestTargetBase>(NodeInstance))
		{
			NodeInstance->RemoveFromRoot();
			NodeInstance->Rename(nullptr, this, REN_None);
			if (QuestTargetData->UniqueID == 0)
				QuestTargetData->UniqueID = GetTypeHash(FGuid::NewGuid());
		}	
	}

	BindNodeData();

	UpdateNodeName();
}

void UEDGraphNode_StateNodeBase::PostPasteNode()
{

	Super::PostPasteNode();

	bRequestInitialAnimation = true;

	{
		if (NodeInstance == nullptr || !NodeInstance->IsA<UQuestDataBase>())
		{
			if (UEDGraphBase* EDGraph = Cast<UEDGraphBase>(this->GetGraph()))
			{
				if (EDGraph->UserDataObj.IsValid())
				{
					if (UQuest* Quest = Cast<UQuest>(EDGraph->UserDataObj.Get()))
					{
						UObject* RefNodeIns = nullptr;

						switch (NodeType)
						{
						case EDNodeType::QuestBegin:
							if (!Quest->Begin)
							{
								Quest->Begin = NewObject<UQuestBeginBase>(Quest, TEXT("Begin"));
							}
							RefNodeIns = Quest->Begin;
							break;

						case EDNodeType::QuestProgress:
							if (!Quest->Progress)
							{
								Quest->Progress = NewObject<UQuestProgressBase>(Quest, TEXT("Progress"));

								if (UQuestProgressBase* QuestProgress = Cast<UQuestProgressBase>(Quest->Progress))
								{
									if (class UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
									{
										FSoftObjectPath SoftPath = QuestSettings->QuestSuccessConditionClass;
										if (SoftPath.IsValid())
										{
											UObject* Obj = SoftPath.ResolveObject();
											if (Obj == nullptr)
											{
												Obj = SoftPath.TryLoad();
											}
											if (Obj)
											{
												UClass* Class = Obj->GetClass();
												if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
												{
													Class = BPObj->GeneratedClass;
												}
											}
										}
									}

								}
							}
							RefNodeIns = Quest->Progress;
							break;
						case EDNodeType::QuestEnd:
							if (!Quest->End)
							{
								Quest->End = NewObject<UQuestEndBase>(Quest, TEXT("End"));
							}
							RefNodeIns = Quest->End;
							break;
						}

						if (RefNodeIns)
						{
							NodeInstance = RefNodeIns;
						}
					}
				}
			}
		}
		else if (UQuestActionBase* QuestActionData = Cast<UQuestActionBase>(NodeInstance))
		{
			QuestActionData->UniqueID = FString::Printf(TEXT("%u"), GetTypeHash(FGuid::NewGuid()));
		}
		else if (UQuestTargetBase* QuestTargetData = Cast<UQuestTargetBase>(NodeInstance))
		{
			QuestTargetData->UniqueID = GetTypeHash(FGuid::NewGuid());
		}
	}

	BindNodeData();

	UpdateNodeName();
}

void UEDGraphNode_StateNodeBase::DestroyNode()
{
	Modify();

	UnBindNodeData();

	Super::DestroyNode();
}

TSharedPtr<INameValidatorInterface> UEDGraphNode_StateNodeBase::MakeNameValidator() const
{
	return MakeShareable(new FEDStateNodeNameValidator(this));
}

void UEDGraphNode_StateNodeBase::PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

void UEDGraphNode_StateNodeBase::PinConnectionListChanged(UEdGraphPin* Pin)
{
	Super::PinConnectionListChanged(Pin);
}

//void UEDGraphNode_StateNodeBase::PreCompile(FSMKismetCompilerContext& CompilerContext)
//{
//	Super::PreCompile(CompilerContext);
//}

bool UEDGraphNode_StateNodeBase::IsEndState(bool bCheckAnyState) const
{
	// Must have entry.
	if (!HasInputConnections())
	{
		return false;
	}

	return true;
}

bool UEDGraphNode_StateNodeBase::HasInputConnections() const
{
	return false;
}

bool UEDGraphNode_StateNodeBase::HasOutputConnections() const
{

	return false;
}

bool UEDGraphNode_StateNodeBase::ShouldExcludeFromAnyState() const
{
	return false;
}

bool UEDGraphNode_StateNodeBase::HasTransitionToNode(UEdGraphNode* Node) const
{

	return false;
}

bool UEDGraphNode_StateNodeBase::HasTransitionFromNode(UEdGraphNode* Node) const
{
	return false;
}

UEDGraphNode_StateNodeBase* UEDGraphNode_StateNodeBase::GetPreviousNode(int32 Index /*= 0*/) const
{
	return nullptr;
}

UEDGraphNode_StateNodeBase* UEDGraphNode_StateNodeBase::GetNextNode(int32 Index /*= 0*/) const
{
	return nullptr;
}

//USMGraphNode_TransitionEdge* UEDGraphNode_StateNodeBase::GetPreviousTransition(int32 Index) const
//{
//	if (UEdGraphPin* InputPin = GetInputPin())
//	{
//		if (InputPin->LinkedTo.Num() <= Index || InputPin->LinkedTo[Index] == nullptr)
//		{
//			return nullptr;
//		}
//
//		if (USMGraphNode_TransitionEdge* Transition = Cast<USMGraphNode_TransitionEdge>(InputPin->LinkedTo[Index]->GetOwningNode()))
//		{
//			return Transition;
//		}
//	}
//	return nullptr;
//}
//
//USMGraphNode_TransitionEdge* UEDGraphNode_StateNodeBase::GetNextTransition(int32 Index) const
//{
//	if (UEdGraphPin* OutputPin = GetOutputPin())
//	{
//		if (OutputPin->LinkedTo.Num() <= Index || OutputPin->LinkedTo[Index] == nullptr)
//		{
//			return nullptr;
//		}
//
//		if (USMGraphNode_TransitionEdge* Transition = Cast<USMGraphNode_TransitionEdge>(OutputPin->LinkedTo[Index]->GetOwningNode()))
//		{
//			return Transition;
//		}
//	}
//
//	return nullptr;
//}

//void UEDGraphNode_StateNodeBase::GetInputTransitions(TArray<USMGraphNode_TransitionEdge*>& OutTransitions) const
//{
//	if (UEdGraphPin* InputPin = GetInputPin())
//	{
//		for (int32 Idx = 0; Idx < InputPin->LinkedTo.Num(); ++Idx)
//		{
//			if (InputPin->LinkedTo[Idx] == nullptr)
//			{
//				// Could be null during a paste.
//				continue;
//			}
//			if (USMGraphNode_TransitionEdge* Transition = Cast<USMGraphNode_TransitionEdge>(InputPin->LinkedTo[Idx]->GetOwningNode()))
//			{
//				OutTransitions.AddUnique(Transition);
//			}
//		}
//	}
//}
//
//void UEDGraphNode_StateNodeBase::GetOutputTransitions(TArray<USMGraphNode_TransitionEdge*>& OutTransitions) const
//{
//	if (UEdGraphPin* OutputPin = GetOutputPin())
//	{
//		for (int32 Idx = 0; Idx < OutputPin->LinkedTo.Num(); ++Idx)
//		{
//			if (OutputPin->LinkedTo[Idx] == nullptr)
//			{
//				// Could be null during a paste.
//				continue;
//			}
//			if (USMGraphNode_TransitionEdge* Transition = Cast<USMGraphNode_TransitionEdge>(OutputPin->LinkedTo[Idx]->GetOwningNode()))
//			{
//				OutTransitions.AddUnique(Transition);
//			}
//		}
//	}
//}

UEdGraphPin* UEDGraphNode_StateNodeBase::GetConnectedEntryPin() const
{
	//if (UEdGraphPin* InputPin = GetInputPin())
	//{
	//	for (int32 Idx = 0; Idx < InputPin->LinkedTo.Num(); ++Idx)
	//	{
	//		if (InputPin->LinkedTo[Idx]->GetOwningNode()->IsA<USMGraphNode_StateMachineEntryNode>())
	//		{
	//			return InputPin->LinkedTo[Idx];
	//		}
	//	}
	//}

	return nullptr;
}

//FLinearColor UEDGraphNode_StateNodeBase::GetBackgroundColorForNodeInstance(const USMNodeInstance* NodeInstance) const
//{
//	const USMEditorSettings* Settings = FSMBlueprintEditorUtils::GetEditorSettings();
//	const FLinearColor* CustomColor = GetCustomBackgroundColor(NodeInstance);
//	const FLinearColor ColorModifier = !CustomColor ? FLinearColor(0.6f, 0.6f, 0.6f, 0.5f) : *CustomColor;
//	const FLinearColor EndStateColor = !CustomColor ? Settings->EndStateColor * ColorModifier : CastChecked<USMStateInstance_Base>(NodeInstance)->GetEndStateColor();
//
//	if (IsEndState())
//	{
//		return EndStateColor;
//	}
//
//	const FLinearColor DefaultColor = Settings->StateDefaultColor;
//
//	// No input -- node unreachable.
//	if (!HasInputConnections())
//	{
//		return DefaultColor * ColorModifier;
//	}
//
//	// State is active
//	if (FSMBlueprintEditorUtils::GraphHasAnyLogicConnections(BoundGraph))
//	{
//		return CustomColor ? *CustomColor * FLinearColor(1.f, 1.f, 1.f, 1.2f) : Settings->StateWithLogicColor * ColorModifier;
//	}
//
//	return DefaultColor * ColorModifier;
//}

FLinearColor UEDGraphNode_StateNodeBase::Internal_GetBackgroundColor() const
{
	return FLinearColor::Black;
}

FString ConvertFJsonValueToFString(TSharedPtr<FJsonValue> JsonValue)
{
	FString FinalString;
	if (JsonValue->Type == EJson::Array)
	{
		// 处理一下数组的表现形式
		TArray<TSharedPtr<FJsonValue>> ArrayValues = JsonValue->AsArray();
		FinalString = TEXT("[");
		for (int32 i = 0; i < ArrayValues.Num(); i++)
		{
			TSharedPtr<FJsonValue> ArrayValue = ArrayValues[i];
			FString ArrayValueString = ConvertFJsonValueToFString(ArrayValue);
			FinalString += ArrayValueString;
			if (i < ArrayValues.Num() - 1)
			{
				FinalString += TEXT(", ");
			}
		}
		FinalString += TEXT("]");
	}
	else if(JsonValue->Type == EJson::Object)
	{
		// 处理一下对象的表现形式
		TSharedPtr ObjectValue = JsonValue->AsObject();
		FinalString = TEXT("{");
		TArray<FString> ValueKeys;
		ObjectValue->Values.GetKeys(ValueKeys);
		for (int32 i = 0; i < ValueKeys.Num(); i++)
		{
			FString KeyName = ValueKeys[i];
			TSharedPtr ObjectKeyValue = ObjectValue->Values[KeyName];
			FString ObjectValueString = ConvertFJsonValueToFString(ObjectKeyValue);
			FinalString += FString::Printf(TEXT("%s: %s"), *KeyName, *ObjectValueString);
			if (i < ValueKeys.Num() - 1)
			{
				FinalString += TEXT(", ");
			}
		}
		FinalString += TEXT("}");
	}
	else
	{
		// object我们这里暂不支持,其他类型目前AsString即可
		FinalString = JsonValue->AsString();
	}
	return FinalString;
}

void UEDGraphNode_StateNodeBase::UpdateNodeName()
{
	if (NodeInstance)
	{
		const FName CategoryKey = TEXT("Category");
		switch (NodeType)
		{
		case EDNodeType::QuestTarget:
			NodeName = NodeInstance->GetClass()->GetMetaData(TEXT("DisplayName"));
			if (NodeName.IsEmpty())
			{
				NodeName = NodeInstance->GetClass()->GetName();
			}
			for (FProperty* Property : TFieldRange<FProperty>(NodeInstance->GetClass(), EFieldIteratorFlags::IncludeSuper))
			{
				if (!Property->GetMetaDataMap())
					continue;

				const FString* CategoryName = Property->GetMetaDataMap()->Find(CategoryKey);
				if (CategoryName && (CategoryName->Equals(TEXT("Important")) || CategoryName->Equals(TEXT("important"))))
				{
					void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(NodeInstance);
					TSharedPtr<FJsonValue> JsonValue = FQuestExportLua::ExportFProperty(Property, PropertyAddress);
					FString FinalString = ConvertFJsonValueToFString(JsonValue);
					FinalString = Property->GetName() + FString(": ") + FinalString;
					NodeName.Append("\n");
					NodeName.Append(FinalString);
				}
			}
			break;

		case EDNodeType::RingQuest:
			if (UQuest* Quest = Cast<UQuest>(NodeInstance))
			{
				NodeName = FString::FromInt(Quest->QuestID);
				NodeName.Append(FString("-"));
				if(Quest->MainTargetTraceCombo.Num() > 0)
				{
					NodeName.Append(Quest->MainTargetTraceCombo[0].Desc);
				}
			}
			break;

		case EDNodeType::ChapterRing:
			if (UQuestRing* Ring = Cast<UQuestRing>(NodeInstance))
			{
				NodeName = FString::FromInt(Ring->RingID);
				NodeName.Append(FString("-"));
				NodeName.Append(Ring->RingName);
			}
			break;

		case EDNodeType::ChapterEnd:
			if( UChapterEnd* ChapterEnd = Cast<UChapterEnd>(NodeInstance))
			{
				NodeName = FString::FromInt(ChapterEnd->NextRingID);
				NodeName.Append(FString("-"));
				NodeName.Append(ChapterEnd->Desc);
			}
			break;
			
		case EDNodeType::QuestAction:
			NodeName = NodeInstance->GetClass()->GetMetaData(TEXT("DisplayName"));
			if (NodeName.IsEmpty())
			{
				NodeName = NodeInstance->GetClass()->GetName();
			}
			for (FProperty* Property : TFieldRange<FProperty>(NodeInstance->GetClass(), EFieldIteratorFlags::IncludeSuper))
			{
				if (!Property->GetMetaDataMap())
					continue;

				const FString* CategoryName = Property->GetMetaDataMap()->Find(CategoryKey);
				if (CategoryName && (CategoryName->Equals(TEXT("Important")) || CategoryName->Equals(TEXT("important"))))
				{
					void* PropertyAddress = Property->ContainerPtrToValuePtr<void>(NodeInstance);
					TSharedPtr<FJsonValue> JsonValue = FQuestExportLua::ExportFProperty(Property, PropertyAddress);
					FString FinalString = ConvertFJsonValueToFString(JsonValue);
					FinalString = Property->GetName() + FString(": ") + FinalString;
					NodeName.Append("\n");
					NodeName.Append(FinalString);
				}
			}
			break;
		}
	}
	
}

void UEDGraphNode_StateNodeBase::ExternalUpdateNodeName()
{
	if (NodeInstance)
	{
		FString OldNodeName = NodeName;
		UpdateNodeName();
		if (NodeName != OldNodeName)
		{
			Modify();
		}
		NodeContentChanged.Broadcast();
	}
}

UEDGraphNode_StateNode::UEDGraphNode_StateNode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UEDGraphNode_StateNode::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	// Enable templates
	bool bStateChange = false;
	//if (PropertyChangedEvent.GetPropertyName() == GET_MEMBER_NAME_CHECKED(UEDGraphNode_StateNode, StateClass))
	//{
	//	InitTemplate();
	//	bStateChange = true;
	//}

	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (bStateChange && PropertyChangedEvent.ChangeType != EPropertyChangeType::Redirected)
	{
	}
}

UObject* UEDGraphNode_StateNode::GetJumpTargetForDoubleClick() const
{
	return Super::GetJumpTargetForDoubleClick();
}

//void UEDGraphNode_StateNode::PlaceDefaultInstanceNodes()
//{
//	Super::PlaceDefaultInstanceNodes();
//}

void UEDGraphNode_StateNode::SetNodeClass(UClass* Class)
{
}

const FSlateBrush* UEDGraphNode_StateNode::GetNodeIcon() const
{
	//if (const FSlateBrush* Icon = Super::GetNodeIcon())
	//{
	//	return Icon;
	//}

	return FAppStyle::Get().GetBrush(TEXT("Graph.StateNode.Icon"));
}

void UEDGraphNode_StateNode::InitTemplate()
{

}

void UEDGraphNode_StateNode::AutowireNewNode(UEdGraphPin* FromPin)
{
	if (!FromPin) {
		return;
	}

	UEdGraphPin* InputPin = GetInputPin();

	const UEdGraphSchema* Schema = GetGraph()->GetSchema();

	//FromPin->MakeLinkTo(InputPin);
	if (Schema->TryCreateConnection(FromPin, InputPin))
	{
		FromPin->GetOwningNode()->PinConnectionListChanged(FromPin);
		PinConnectionListChanged(InputPin);
	}
}

FString UEDGraphNode_StateNode::GetStateName() const
{
	if (NodeInstance)
	{
		switch (NodeType)
		{
		case EDNodeType::RingQuest:
			if (UQuest* Quest = Cast<UQuest>(NodeInstance))
			{
				FString EditName;
				if(Quest->MainTargetTraceCombo.Num() > 0)
				{
					EditName = Quest->MainTargetTraceCombo[0].Desc;
				}
				return FString::Format(TEXT("{0}-{1}"), {Quest->QuestID, EditName});
			}
			break;
		}
	}

	return FString();
}

void UEDGraphNode_StateNode::SetStateIdx(FString InIdx)
{
	if (NodeInstance)
	{
		if (CustomStateIdx != InIdx)
		{
			CustomStateIdx = InIdx;
			NodeContentChanged.Broadcast();
		}
	}
}

UEdGraphPin* UEDGraphNode_StateNode::GetNextQuestOutPin()
{
	for (UEdGraphPin* Pin : Pins)
	{
		if (Pin->Direction == EGPD_Output && Pin->PinName == "Out")
		{
			return Pin;
		}
	}

	return nullptr;
}

#undef LOCTEXT_NAMESPACE

UE_ENABLE_OPTIMIZATION_SHIP