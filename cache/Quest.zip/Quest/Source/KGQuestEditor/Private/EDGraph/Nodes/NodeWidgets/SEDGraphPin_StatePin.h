#pragma once

#include "CoreMinimal.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "SGraphPin.h"

class SEDGraphPin_StatePin : public SGraphPin
{
public:
	SLATE_BEGIN_ARGS(SEDGraphPin_StatePin) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, UEdGraphPin* InPin)
	{
		this->SetCursor(EMouseCursor::Default);
		bShowLabel = true;

		GraphPinObj = InPin;
		check(GraphPinObj);

		const UEdGraphSchema* Schema = GraphPinObj->GetSchema();
		check(Schema);

		SBorder::Construct(SBorder::FArguments()
			.BorderImage(this, &SEDGraphPin_StatePin::GetPinBorder)
			.BorderBackgroundColor(this, &SEDGraphPin_StatePin::GetPinColor)
			.OnMouseButtonDown(this, &SEDGraphPin_StatePin::OnPinMouseDown)
			.Cursor(this, &SEDGraphPin_StatePin::GetPinCursor)
		);
	}

	virtual FReply OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;

protected:
	virtual TSharedRef<SWidget>	GetDefaultValueWidget() override
	{
		return SNew(STextBlock);
	}

	const FSlateBrush* GetPinBorder() const
	{
		return IsHovered()
			? FAppStyle::Get().GetBrush(TEXT("Graph.StateNode.Pin.BackgroundHovered"))
			: FAppStyle::Get().GetBrush(TEXT("Graph.StateNode.Pin.Background"));
	}
};

