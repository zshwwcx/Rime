#include "SEDGraphNode_Transition.h"

#include "Widgets/SBoxPanel.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/SToolTip.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "SGraphPanel.h"
#include "SGraphPreviewer.h"
#include "../EDGraphNode_Base.h"
#include "../EDGraphNode_Transition.h"
#include "../EDGraphNode_StateNode.h"
#include "ConnectionDrawingPolicy.h"

#define LOCTEXT_NAMESPACE "SEDGraphNode_Transition"



void SEDGraphNode_Transition::Construct(const FArguments& InArgs, UEDGraphNode_Transition* InNode)
{
	SEDGraphNode_BaseNode::Construct(SEDGraphNode_BaseNode::FArguments(), Cast<UEDGraphNode_Base>(InNode));
	//CastChecked<UEDGraphNode_Base>(GraphNode)->OnWidgetConstruct();

	bool bShow(true);
	if (UEDGraphNode_Base* EDNode = InNode->GetFromState())
	{
		if (EDNode->NodeType == EDNodeType::QuestBegin
			|| EDNode->NodeType == EDNodeType::QuestProgress
			|| EDNode->NodeType == EDNodeType::QuestEnd
			|| EDNode->NodeType == EDNodeType::QuestTarget
			)
		{
			bShow = false;
		}
	}
	
	if (bShow)
	{
		UpdateGraphNode();
	}
}

void SEDGraphNode_Transition::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime,
	const float InDeltaTime)
{
	SGraphNode::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);

	UEDGraphNode_Transition* Node = CastChecked<UEDGraphNode_Transition>(GraphNode);
	Node->UpdateTime(InDeltaTime);
}

void SEDGraphNode_Transition::MoveTo(const FVector2D& NewPosition, FNodeSet& NodeFilter, bool bMarkDirty)
{
	// Position set by states.
}

bool SEDGraphNode_Transition::RequiresSecondPassLayout() const
{
	return true;
}

void SEDGraphNode_Transition::PerformSecondPassLayout(const TMap< UObject*, TSharedRef<SNode> >& NodeToWidgetLookup) const
{
	const UEDGraphNode_Transition* EdgeNode = CastChecked<UEDGraphNode_Transition>(GraphNode);

	FGeometry StartGeom;
	FGeometry EndGeom;

	int32 ThisIndex = 0;
	int32 TransitionCount = 1;

	const UEDGraphNode_Base* FromState = EdgeNode->GetFromState();
	const UEDGraphNode_Base* ToState = EdgeNode->GetToState();
	if (FromState && ToState)
	{
		const TSharedRef<SNode>* pFromWidget = NodeToWidgetLookup.Find(FromState);
		const TSharedRef<SNode>* pToWidget = NodeToWidgetLookup.Find(ToState);
		if (pFromWidget && pToWidget)
		{
			const TSharedRef<SNode>& FromWidget = *pFromWidget;
			const TSharedRef<SNode>& ToWidget = *pToWidget;

			StartGeom = FGeometry(FVector2D(FromState->NodePosX, FromState->NodePosY), FVector2D::ZeroVector, FromWidget->GetDesiredSize(), 1.0f);
			EndGeom = FGeometry(FVector2D(ToState->NodePosX, ToState->NodePosY), FVector2D::ZeroVector, ToWidget->GetDesiredSize(), 1.0f);

		//	TArray<UEDGraphNode_Transition*> Transitions;
		//	FromState->GetOutputTransitions(Transitions);

		//	Transitions = Transitions.FilterByPredicate([ToState](const UEDGraphNode_Transition* InTransition) -> bool
		//		{
		//			return InTransition->GetToState() == ToState;
		//		});

		//	ThisIndex = Transitions.IndexOfByKey(EdgeNode);
		//	TransitionCount = Transitions.Num();
		}
	}

	PositionBetweenTwoNodesWithOffset(StartGeom, EndGeom, ThisIndex, TransitionCount);
}

void SEDGraphNode_Transition::UpdateGraphNode()
{
	InputPins.Empty();
	OutputPins.Empty();

	RightNodeBox.Reset();
	LeftNodeBox.Reset();

	this->ContentScale.Bind(this, &SGraphNode::GetContentScale);

	TSharedPtr<SVerticalBox> IconVerticalBox;

	this->GetOrAddSlot(ENodeZone::Center)
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
		.AutoHeight()
		.HAlign(HAlign_Center)
		.Padding(2.5)
		[
			SNew(STextBlock)
			//.Visibility(this, &SEDGraphNode_Transition::GetPriorityVisibility)
		.Font(FCoreStyle::Get().GetFontStyle("ExpandableArea.TitleFont"))
		.Text(this, &SEDGraphNode_Transition::GetDisplayName)
		//.ToolTipText(LOCTEXT("TransitionPriorityTooltip", "Priority Order - lower numbers evaluate first."))
		]
	+ SVerticalBox::Slot()
		.AutoHeight()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Center)
		[
			SAssignNew(IconVerticalBox, SVerticalBox)
		]
		];

	IconVerticalBox->AddSlot()
		.AutoHeight()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Center)
		[
			SNew(SOverlay)
			+ SOverlay::Slot()
		.HAlign(HAlign_Fill)
		.VAlign(VAlign_Fill)
		[
			SNew(SImage)
			.Image(FAppStyle::Get().GetBrush("Graph.TransitionNode.ColorSpill"))
			.ColorAndOpacity(this, &SEDGraphNode_Transition::GetEdgeColor, -1)
		]
	+ SOverlay::Slot()
		[
			SNew(SImage)
			.Image(this, &SEDGraphNode_Transition::GetIcon, -1)
		]
		];
}

TSharedPtr<SToolTip> SEDGraphNode_Transition::GetComplexTooltip()
{
	/* Display a pop-up on mouse hover with useful information. */

	UEDGraphNode_Transition* TransitionNode = CastChecked<UEDGraphNode_Transition>(GraphNode);

	bool bHasOnEnteredLogic = false;
	bool bHasInitLogic = false;
	bool bHasShutdownLogic = false;
	bool bHasPreEvalLogic = false;
	bool bHasPostEvalLogic = false;
	const bool bIsDefaultClass = true;

	UEDGraphNode_Base* FromStateNode = TransitionNode->GetFromState();
	
	const TSharedRef<SVerticalBox> Widget = SNew(SVerticalBox);
	Widget->AddSlot()
		.AutoHeight()
		.Padding(FMargin(0.f, 0.f, 0.f, 4.f))
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(STextBlock)
		.Text(FText::Format(LOCTEXT("TransitionPopupTitle", "{0} (Transition)"), FText::FromString(TransitionNode->GetTransitionName())))
		]
	+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(0.f, -4.f, 0.f, 0.f)
		];

	//// Selected transition
	//{
	//	Widget->AddSlot()
	//		.AutoHeight()
	//		.Padding(2.0f)
	//		[
	//			// Take the expression connected to the eval pin and turn it into text.
	//			SNew(SSMTransitionShorthandView, TransitionNode)
	//		];
	//}

	if (bHasOnEnteredLogic)
	{
		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(2.f, 4.f, 2.f, 4.f))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "SMGraph.Tooltip.Info")
			.Text(LOCTEXT("TransitionEnteredTooltip", "Transition Entered: Logic will execute when entering this transition"))
			];
	}

	if (bHasInitLogic)
	{
		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(2.f, 4.f, 2.f, 4.f))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "SMGraph.Tooltip.Info")
			.Text(FText::Format(LOCTEXT("TransitionInitTooltip", "Transition Initialization: Logic will execute when state '{0}' has started"), FText::FromString(FromStateNode->NodeName)))
			];
	}

	if (bHasShutdownLogic)
	{
		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(2.f, 4.f, 2.f, 4.f))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "SMGraph.Tooltip.Info")
			.Text(FText::Format(LOCTEXT("TransitionShutdownTooltip", "Transition Shutdown: Logic will execute when state '{0}' has exited"), FText::FromString(FromStateNode->NodeName)))
			];
	}

	if (bHasPreEvalLogic)
	{
		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(2.f, 4.f, 2.f, 4.f))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "SMGraph.Tooltip.Warning")
			.Text(LOCTEXT("TransitionPreEvalTooltip", "Transition Pre-Eval: Logic will execute before each evaluation"))
			];
	}

	if (bHasPostEvalLogic)
	{
		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(2.f, 4.f, 2.f, 4.f))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "SMGraph.Tooltip.Warning")
			.Text(LOCTEXT("TransitionPostEvalTooltip", "Transition Post-Eval: Logic will execute after each evaluation"))
			];
	}

	//if (bHasOnEnteredLogic || bHasInitLogic || bHasShutdownLogic || bHasPreEvalLogic || bHasPostEvalLogic)
	//{
	//	Widget->AddSlot()
	//		.AutoHeight()
	//		[
	//			SNew(SGraphPreviewer, TransitionNode->GetBoundGraph())
	//			.ShowGraphStateOverlay(false)
	//		];
	//}

	return SNew(SToolTip)
		[
			Widget
		];
}

const FSlateBrush* SEDGraphNode_Transition::GetShadowBrush(bool bSelected) const
{
	return !bSelected ? FStyleDefaults::GetNoBrush() : SEDGraphNode_BaseNode::GetShadowBrush(bSelected);
}

void SEDGraphNode_Transition::OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	UEDGraphNode_Transition* TransNode = CastChecked<UEDGraphNode_Transition>(GraphNode);
	if (UEdGraphPin* Pin = TransNode->GetInputPin())
	{
		GetOwnerPanel()->AddPinToHoverSet(Pin);
	}

	SGraphNode::OnMouseEnter(MyGeometry, MouseEvent);
}

void SEDGraphNode_Transition::OnMouseLeave(const FPointerEvent& MouseEvent)
{
	UEDGraphNode_Transition* TransNode = CastChecked<UEDGraphNode_Transition>(GraphNode);
	if (UEdGraphPin* Pin = TransNode->GetInputPin())
	{
		GetOwnerPanel()->RemovePinFromHoverSet(Pin);
	}

	SGraphNode::OnMouseLeave(MouseEvent);
}

void SEDGraphNode_Transition::PositionBetweenTwoNodesWithOffset(const FGeometry& StartGeom, const FGeometry& EndGeom, int32 NodeIndex, int32 MaxNodes) const
{
	// Get a reasonable seed point (halfway between the boxes)
	const FVector2D StartCenter = FGeometryHelper::CenterOf(StartGeom);
	const FVector2D EndCenter = FGeometryHelper::CenterOf(EndGeom);

	if (StartCenter == EndCenter)
	{
		FVector2D Corner = StartCenter;
		Corner.X += StartGeom.Size.X / 2.f + 10.f;
		Corner.Y += StartGeom.Size.Y / 2.f + 15.f;

		GraphNode->NodePosX = Corner.X;
		GraphNode->NodePosY = Corner.Y;

		return;
	}

	const FVector2D SeedPoint = (StartCenter + EndCenter) * 0.5f;

	// Find the (approximate) closest points between the two boxes
	const FVector2D StartAnchorPoint = FGeometryHelper::FindClosestPointOnGeom(StartGeom, SeedPoint);
	const FVector2D EndAnchorPoint = FGeometryHelper::FindClosestPointOnGeom(EndGeom, SeedPoint);

	// Position ourselves halfway along the connecting line between the nodes, elevated away perpendicular to the direction of the line
	const float Height = 30.0f;

	FVector2D DesiredNodeSize = GetDesiredSize();
	DesiredNodeSize.Y += GetDesiredYOffset();

	FVector2D DeltaPos(EndAnchorPoint - StartAnchorPoint);

	if (DeltaPos.IsNearlyZero())
	{
		DeltaPos = FVector2D(10.0f, 0.0f);
	}

	const FVector2D Normal = FVector2D(DeltaPos.Y, -DeltaPos.X).GetSafeNormal();

	const FVector2D NewCenter = StartAnchorPoint + (0.5f * DeltaPos) + (Height * Normal);

	FVector2D DeltaNormal = DeltaPos.GetSafeNormal();

	// Calculate node offset in the case of multiple transitions between the same two nodes
	// MultiNodeOffset: the offset where 0 is the center of the transition, -1 is 1 <size of node>
	// towards the PrevStateNode and +1 is 1 <size of node> towards the NextStateNode.

	const float MutliNodeSpace = 0.2f; // Space between multiple transition nodes (in units of <size of node> )
	const float MultiNodeStep = (1.f + MutliNodeSpace); //Step between node centres (Size of node + size of node spacer)

	const float MultiNodeStart = -((MaxNodes - 1) * MultiNodeStep) / 2.f;
	const float MultiNodeOffset = MultiNodeStart + (NodeIndex * MultiNodeStep);

	// Now we need to adjust the new center by the node size, zoom factor and multi node offset
	FVector2D NewCorner = NewCenter - (0.5f * DesiredNodeSize) + (DeltaNormal * MultiNodeOffset * DesiredNodeSize.Size());
	NewCorner.Y += GetDesiredYOffset();

	GraphNode->NodePosX = NewCorner.X;
	GraphNode->NodePosY = NewCorner.Y;
}

FSlateColor SEDGraphNode_Transition::GetEdgeColor(int32 InIndex) const
{
	// 如果设置了跳转条件，则特殊颜色标记
	if (UEDGraphNode_Transition* EdgeNode = CastChecked<UEDGraphNode_Transition>(GraphNode))
	{
		if (URingTaskConditionBase* RingTaskConditionBase = Cast<URingTaskConditionBase>(EdgeNode->NodeInstance))
		{
			if (RingTaskConditionBase->TaskCondition)
			{
				return FLinearColor(0.9f, 0.9f, 0.0f, 1.0f);
			}
		}
	}

	return FLinearColor(0.9f, 0.9f, 0.9f, 1.0f);
}

const FSlateBrush* SEDGraphNode_Transition::GetIcon(int32 InIndex) const
{
	if (UEDGraphNode_Transition* EdgeNode = CastChecked<UEDGraphNode_Transition>(GraphNode))
	{
		if (const FSlateBrush* Brush = EdgeNode->GetTransitionIcon(InIndex))
		{
			if (Brush->ImageSize.GetMax() > 0)
			{
				return Brush;
			}
		}	
	}

	return FAppStyle::Get().GetBrush(TEXT("Graph.TransitionNode.Icon"));
}


FText SEDGraphNode_Transition::GetPriorityAsText() const
{
	int32 PriorityOrder = 0;

	return FText::FromString(FString::FromInt(PriorityOrder));
}

EVisibility SEDGraphNode_Transition::GetPriorityVisibility() const
{
	return EVisibility::Visible;
}

FText SEDGraphNode_Transition::GetDisplayName() const
{
	FString DisplayName;
	if (GraphNode)
	{
		if (UEDGraphNode_Transition* Node = Cast<UEDGraphNode_Transition>(GraphNode))
		{
			DisplayName = Node->GetDisplayName();
		}
	}

	return FText::FromString(DisplayName);
}

int32 SEDGraphNode_Transition::GetDesiredYOffset() const
{
	const int32 DesiredSizeYOffset = GetPriorityVisibility() == EVisibility::Visible ? -16.f /* Rough height of priority */ : 0.f;
	return DesiredSizeYOffset;
}

#undef LOCTEXT_NAMESPACE



