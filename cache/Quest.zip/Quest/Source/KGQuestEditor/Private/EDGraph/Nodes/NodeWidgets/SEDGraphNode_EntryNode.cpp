#include "SEDGraphNode_EntryNode.h"
#include "../EDGraphNode_EntryNode.h"
#include "SGraphPin.h"
#include "SEDGraphPin_QuestTargetPin.h"

void SEDGraphNode_EntryNode::Construct(const FArguments& InArgs, UEDGraphNode_EntryNode* InNode)
{
	this->GraphNode = InNode;

	//TitleName = InNode->NodeName;

	this->SetCursor(EMouseCursor::CardinalCross);

	this->UpdateGraphNode();
}

void SEDGraphNode_EntryNode::GetNodeInfoPopups(FNodeInfoContext* Context, TArray<FGraphInformationPopupInfo>& Popups) const
{

}

void SEDGraphNode_EntryNode::CreatePinWidgets()
{
	EDNodeType NodeType(EDNodeType::Max);
	if (UEDGraphNode_EntryNode* EntryNode = Cast<UEDGraphNode_EntryNode>(GraphNode))
	{
		NodeType = EntryNode->NodeType;
	}

	for (int32 PinIndex = 0; PinIndex < GraphNode->Pins.Num(); ++PinIndex)
	{
		UEdGraphPin* CurPin = GraphNode->Pins[PinIndex];

		if (NodeType == EDNodeType::QuestBegin && CurPin->PinName == "Action")
		{
			const TSharedPtr<SGraphPin> NewPin = SNew(SEDGraphPin_QuestTargetPin, CurPin);

			NewPin->SetOwner(SharedThis(this));

			OutputPinTargetBox->AddSlot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				[
					NewPin.ToSharedRef()
				];
			OutputPins.Add(NewPin.ToSharedRef());
		}
		else
		{
			if (!ensureMsgf(CurPin->GetOuter() == GraphNode
				, TEXT("Graph node ('%s' - %s) has an invalid %s pin: '%s'; (with a bad %s outer: '%s'); skiping creation of a widget for this pin.")
				, *GraphNode->GetNodeTitle(ENodeTitleType::ListView).ToString()
				, *GraphNode->GetPathName()
				, (CurPin->Direction == EEdGraphPinDirection::EGPD_Input) ? TEXT("input") : TEXT("output")
				, CurPin->PinFriendlyName.IsEmpty() ? *CurPin->PinName.ToString() : *CurPin->PinFriendlyName.ToString()
				, CurPin->GetOuter() ? *CurPin->GetOuter()->GetClass()->GetName() : TEXT("UNKNOWN")
				, CurPin->GetOuter() ? *CurPin->GetOuter()->GetPathName() : TEXT("NULL")))
			{
				continue;
			}

			CreateStandardPinWidget(CurPin);
		}
	}
}

FSlateColor SEDGraphNode_EntryNode::GetBorderBackgroundColor() const
{
	const FLinearColor InactiveStateColor(0.08f, 0.08f, 0.08f);

	return InactiveStateColor;
}

void SEDGraphNode_EntryNode::UpdateGraphNode()
{
	InputPins.Empty();
	OutputPins.Empty();

	RightNodeBox.Reset();
	LeftNodeBox.Reset();

	this->ContentScale.Bind(this, &SGraphNode::GetContentScale);
	this->GetOrAddSlot(ENodeZone::Center)
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
			[
				SNew(SBorder)
				.BorderImage(FAppStyle::GetBrush("Graph.StateNode.Body"))
				.Padding(0,0)
				.BorderBackgroundColor(this, &SEDGraphNode_EntryNode::GetBorderBackgroundColor)
				[
					SNew(SOverlay)
					+ SOverlay::Slot()
					.HAlign(HAlign_Right)
					.VAlign(VAlign_Fill)
					.Padding(10.0f, 0)
					[
						SAssignNew(RightNodeBox, SVerticalBox)
					]
				]
			]

			+SVerticalBox::Slot()
			[
				SNew(SBox)
					[
					SNew(SVerticalBox)
						+ SVerticalBox::Slot()
						.HAlign(HAlign_Fill)
						.VAlign(VAlign_Bottom)
						.Padding(20.0f, 0.0f)
						.FillHeight(1.0f)
						.MaxHeight(20)
						[
							SAssignNew(OutputPinTargetBox, SHorizontalBox)
						]
					]
			]
		];

	CreatePinWidgets();
}

void SEDGraphNode_EntryNode::AddPin(const TSharedRef<SGraphPin>& PinToAdd)
{
	PinToAdd->SetOwner(SharedThis(this));
	RightNodeBox->AddSlot()
		.HAlign(HAlign_Fill)
		.VAlign(VAlign_Fill)
		.FillHeight(1.0f)
		[
			PinToAdd
		];
	OutputPins.Add(PinToAdd);
}

FText SEDGraphNode_EntryNode::GetPreviewCornerText() const
{
	return NSLOCTEXT("SEDGraphNodeEntry", "TextDescription", "Entry Event");
}
