#pragma once

#include "CoreMinimal.h"
#include "EDGraphNode_Base.h"

#include "GameplayTagContainer.h"
#include "Templates/SubclassOf.h"
#include "EdGraph/EdGraphNode.h"

#include "EDGraphNode_StateNode.generated.h"

DECLARE_MULTICAST_DELEGATE(FNodeContentChanged);

UCLASS()
class UEDGraphNode_StateNodeBase : public UEDGraphNode_Base
{
	GENERATED_UCLASS_BODY()

		/**
		 * Add tags to this state that Any State nodes will recognize.
		 * This can allow control over which specific Any State nodes should impact this state.
		 *
		 * On the Any State you can define an AnyStateTagQuery to control which tags an Any State should recognize.
		 * Only valid in the editor.
		 */
	UPROPERTY(EditAnywhere, Category = "Any State")
	FGameplayTagContainer AnyStateTags;

	/**
	 * @deprecated Set on the node template instead.
	 */
	UPROPERTY()
		uint8 bAlwaysUpdate_DEPRECATED : 1;

	/**
	 * @deprecated Set on the node template instead.
	 */
	UPROPERTY()
		uint8 bDisableTickTransitionEvaluation_DEPRECATED : 1;

	/**
	 * @deprecated Set on the node template instead.
	 */
	UPROPERTY()
		uint8 bEvalTransitionsOnStart_DEPRECATED : 1;

	/**
	 * @deprecated Set on the node template instead.
	 */
	UPROPERTY()
		uint8 bExcludeFromAnyState_DEPRECATED : 1;

	/**
	 * Set by the editor and read by the schema to allow self transitions.
	 * We don't want to drag / drop self transitions because a single pin click will
	 * trigger them. There doesn't seem to be an ideal way for the schema to detect
	 * mouse movement to prevent single clicks when in CanCreateConnection,
	 * so we're relying on a context menu.
	 */
	uint8 bCanTransitionToSelf : 1;

	FNodeContentChanged NodeContentChanged;
	
public:
	// UEdGraphNode
	virtual void AllocateDefaultPins() override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	virtual void AutowireNewNode(UEdGraphPin* FromPin) override;
	/** Called after playing a new node -- will create new blue print graph. */
	virtual void PostPlacedNewNode() override;
	virtual void PostPasteNode() override;
	virtual void DestroyNode() override;
	virtual TSharedPtr<INameValidatorInterface> MakeNameValidator() const override;
	virtual void PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent) override;
	virtual void PinConnectionListChanged(UEdGraphPin* Pin) override;
	// ~UEdGraphNode

	//virtual void PreCompile(FSMKismetCompilerContext& CompilerContext) override;

	/** Copy configuration settings to the runtime node. */
	virtual FString GetStateName() const { return ""; }

	virtual FString GetStateIdx() const { return "-1"; }

	/**
	 * Checks if there are no outbound transitions.
	 * @param bCheckAnyState Checks if an Any State will prevent this from being an end state.
	 */
	virtual bool IsEndState(bool bCheckAnyState = true) const;

	/** Checks if there are any connections to this node. Does not count self. */
	virtual bool HasInputConnections() const;

	/** Checks if there are any connections from this node. */
	virtual bool HasOutputConnections() const;

	/** If this is a state that gets compiled into the runtime blueprint.  */
	virtual bool CanExistAtRuntime() const { return true; };

	/** If this node shouldn't receive transitions from an Any State. */
	bool ShouldExcludeFromAnyState() const;

	/** Checks if there is a node connected via outgoing transition. */
	bool HasTransitionToNode(UEdGraphNode* Node) const;

	/** Checks if there is a node connected via incoming transition. */
	bool HasTransitionFromNode(UEdGraphNode* Node) const;

	/** Returns the previous node at the given input linked to index. */
	UEDGraphNode_StateNodeBase* GetPreviousNode(int32 Index = 0) const;

	/** Returns the next node at the given output linked to index. */
	UEDGraphNode_StateNodeBase* GetNextNode(int32 Index = 0) const;

	///** Returns a transition going to the input pin. */
	//USMGraphNode_TransitionEdge* GetPreviousTransition(int32 Index = 0) const;

	///** Returns a transitions from the output pin. */
	//USMGraphNode_TransitionEdge* GetNextTransition(int32 Index = 0) const;

	///** Return all transitions to the input pin. */
	//void GetInputTransitions(TArray<USMGraphNode_TransitionEdge*>& OutTransitions) const;

	///** Return all transitions from the output pin. */
	//void GetOutputTransitions(TArray<USMGraphNode_TransitionEdge*>& OutTransitions) const;

	/** Return the entry pin if this states is connected to an entry node, nullptr otherwise. */
	UEdGraphPin* GetConnectedEntryPin() const;

	//FLinearColor GetBackgroundColorForNodeInstance(const USMNodeInstance* NodeInstance) const;

	///** Return any linked states pointing to this node. */
	//const TSet<USMGraphNode_LinkStateNode*>& GetLinkedStates() const { return LinkedStates; }

	void ExternalUpdateNodeName();

	void PostLoad();

	void BindNodeData();

	void UnBindNodeData();

protected:
	virtual FLinearColor Internal_GetBackgroundColor() const;

	void UpdateNodeName();

private:
	//friend class SGraphNode_StateNode;
	bool bRequestInitialAnimation;

	//friend class USMGraphNode_LinkStateNode;

	///** States linked to this state. */
	//UPROPERTY()
	//	TSet<USMGraphNode_LinkStateNode*> LinkedStates;
};


UCLASS()
class UEDGraphNode_StateNode : public UEDGraphNode_StateNodeBase
{
public:
	GENERATED_UCLASS_BODY()

	
	// UEdGraphNode
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual UObject* GetJumpTargetForDoubleClick() const override;
	
	//~ UEdGraphNode

	//virtual void PlaceDefaultInstanceNodes() override;
	virtual void SetNodeClass(UClass* Class);
	virtual FName GetFriendlyNodeName() const { return "State"; }
	virtual const FSlateBrush* GetNodeIcon() const;
	virtual void InitTemplate();
	virtual void AutowireNewNode(UEdGraphPin* FromPin) override;
	//virtual void OnCompile(FSMKismetCompilerContext& CompilerContext) override;


	virtual FString GetStateName() const override;
	virtual void SetStateIdx(FString InIdx);
	virtual FString GetStateIdx() const override { return CustomStateIdx; }

public:
	UEdGraphPin* GetNextQuestOutPin();

	FString CustomStateIdx = TEXT("-1");
};