#pragma once

#include "CoreMinimal.h"
#include "EdGraph/EdGraphNode.h"
#include "Styling/SlateBrush.h"
#include "EDGraph/Util/EDClassCollect.h"
#include "EDNodeDefine.h"
#include "EDGraphNode_Base.generated.h"

UCLASS(abstract)
class UEDGraphNode_Base : public UEdGraphNode
{
	GENERATED_UCLASS_BODY()

public:
	UPROPERTY()
	struct FEDClassData ClassData;

	UPROPERTY()
	TObjectPtr<UObject> NodeInstance;

	UPROPERTY()
	FString NodeName;

	UPROPERTY()
	EDNodeType NodeType;

	UPROPERTY()
	FString NodePath;


public:
	//~ Begin UEdGraphNode Interface
	virtual void DestroyNode() override;
	virtual void PostPasteNode() override;
	virtual void PostEditUndo() override;
	virtual void PostPlacedNewNode() override;
	virtual void OnRenameNode(const FString& NewName) override;
	virtual UObject* GetJumpTargetForDoubleClick() const override;
	virtual bool CanJumpToDefinition() const override;
	virtual void JumpToDefinition() const override;
	virtual bool CanCreateUnderSpecifiedSchema(const UEdGraphSchema* Schema) const override;
	virtual void ReconstructNode() override;
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void PinConnectionListChanged(UEdGraphPin* Pin) override;
	virtual void ValidateNodeDuringCompilation(FCompilerResultsLog& MessageLog) const override;

	virtual FLinearColor GetBackgroundColor() const;

	virtual const FSlateBrush* GetNodeIcon() const;

	virtual UEdGraphPin* GetInputPin() const;
	virtual UEdGraphPin* GetOutputPin() const;

	void GetInputTransitionNodes(TArray<UEDGraphNode_Base*>& OutInputTransNodes, UClass* FilterClass);

	void GetOutputTransitionNodes(TArray<UEDGraphNode_Base*>& OutInputTransNodes, UClass* FilterClass);

	void GetOutputTransitionNodesWithPin(TArray<UEDGraphNode_Base*>& OutInputTransNodes, UClass* FilterClass, UEdGraphPin* Pin);
};