#pragma once


#include "SEDGraphNode_BaseNode.h"

#include "SGraphPreviewer.h"
#include "Widgets/Images/SImage.h"

class UEDGraphNode_StateNodeBase;

class SEDGraphNode_StateNode : public SEDGraphNode_BaseNode
{
public:
	SLATE_BEGIN_ARGS(SEDGraphNode_StateNode) : _ContentPadding(FMargin(2.f, 2.f, 2.f, 2.f)) {}
		SLATE_ARGUMENT(FMargin, ContentPadding)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, UEDGraphNode_StateNodeBase* InNode);

	// SGraphNode
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
	virtual void UpdateGraphNode() override;
	virtual void CreatePinWidgets() override;
	virtual void AddPin(const TSharedRef<SGraphPin>& PinToAdd) override;
	virtual TSharedPtr<SToolTip> GetComplexTooltip() override;
	virtual TArray<FOverlayWidgetInfo> GetOverlayWidgets(bool bSelected, const FVector2D& WidgetSize) const override;
	virtual FReply OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent) override;
	virtual void RequestRenameOnSpawn() override;
	virtual FReply OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;
	virtual FReply OnDragOver(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;
	virtual ~SEDGraphNode_StateNode() override;
	// ~SGraphNode

	// SNodePanel::SNode
	virtual void GetNodeInfoPopups(FNodeInfoContext* Context, TArray<FGraphInformationPopupInfo>& Popups) const override;
	// ~SNodePanel::SNode

	// SGraphNode_BaseNode
	virtual void OnRefreshRequested(UEDGraphNode_Base* InNode, bool bFullRefresh) override;
	// ~SGraphNode_BaseNode

	virtual TSharedPtr<SWidget> CreateContentBox();
	virtual FSlateColor GetBorderBackgroundColor() const;
	virtual const FSlateBrush* GetNameIcon() const;
	virtual TSharedPtr<SVerticalBox> BuildComplexTooltip();
	virtual UEdGraph* GetGraphToUseForTooltip() const;

	void CalculateAnyStateImpact();
	void CalculateLinkStateImpact();

	void OnRefreshNodeName();

protected:
	TArray<TSharedPtr<SWidget>> AnyStateImpactWidgets;
	TSharedPtr<SWidget> LinkStateImpactWidget;
	TSharedPtr<SWidget> FastPathWidget;
	TSharedPtr<SImage> NodeIcon;
	TSharedPtr<STextBlock> EditNameBlock;
	TSharedPtr<STextBlock> TargetDescBlock;
	FMargin ContentPadding;
	const int32 OverlayWidgetPadding = 20;

	TWeakObjectPtr<UEDGraphNode_StateNodeBase> CachedStateNode;
};