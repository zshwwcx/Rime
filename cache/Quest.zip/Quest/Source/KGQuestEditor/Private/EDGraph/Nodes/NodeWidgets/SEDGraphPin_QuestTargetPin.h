#pragma once

#include "CoreMinimal.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "SGraphPin.h"

class SEDGraphPin_QuestTargetPin : public SGraphPin
{
public:
	SLATE_BEGIN_ARGS(SEDGraphPin_QuestTargetPin): _Padding(FMargin(40.0f, 10)) {}
		SLATE_ATTRIBUTE(FMargin, Padding)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, UEdGraphPin* InPin)
	{
		this->SetCursor(EMouseCursor::Default);
		bShowLabel = true;

		GraphPinObj = InPin;
		check(GraphPinObj);

		const UEdGraphSchema* Schema = GraphPinObj->GetSchema();
		check(Schema);

		Padding = InArgs._Padding.Get();

		//SBorder::Construct(SBorder::FArguments()
		//	.BorderImage(this, &SEDGraphPin_QuestTargetPin::GetPinBorder)
		//	.BorderBackgroundColor(this, &SEDGraphPin_QuestTargetPin::GetPinColor)
		//	.OnMouseButtonDown(this, &SEDGraphPin_QuestTargetPin::OnPinMouseDown)
		//	.Cursor(this, &SEDGraphPin_QuestTargetPin::GetPinCursor)
		//);


		SBorder::Construct(SBorder::FArguments()
			.BorderImage(this, &SEDGraphPin_QuestTargetPin::GetPinBorder)
			.BorderBackgroundColor(this, &SEDGraphPin_QuestTargetPin::GetPinColor)
			.OnMouseButtonDown(this, &SEDGraphPin_QuestTargetPin::OnPinMouseDown)
			.Cursor(this, &SEDGraphPin_QuestTargetPin::GetPinCursor)
			.Padding(Padding)
		);
	}

	virtual FReply OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;

public:
	FMargin Padding;

protected:
	virtual TSharedRef<SWidget>	GetDefaultValueWidget() override
	{
		return SNew(STextBlock);
	}

	const FSlateBrush* GetPinBorder() const
	{
		return FAppStyle::GetBrush(TEXT("Graph.StateNode.Body"));
	}

	virtual FSlateColor GetPinColor() const override;
};

