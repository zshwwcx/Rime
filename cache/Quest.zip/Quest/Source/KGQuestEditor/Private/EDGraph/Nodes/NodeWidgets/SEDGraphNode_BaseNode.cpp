#include "SEDGraphNode_BaseNode.h"
#include "../EDGraphNode_Base.h"
#include "QuestTemplate.h"
#include "../../Graph/EventDrivenGraphSchema.h"
#include "FQuestObjectivesEditor.h"

#define LOCTEXT_NAMESPACE "SEDGraphNode_BaseNode"

SEDGraphNode_BaseNode::~SEDGraphNode_BaseNode()
{

}

void SEDGraphNode_BaseNode::Construct(const FArguments& InArgs, UEDGraphNode_Base* InNode)
{
	check(InNode);
	GraphNode = InNode;

	//NodeRefreshHandle = InNode->OnGraphNodeRefreshRequestedEvent.AddSP(this, &SEDGraphNode_BaseNode::OnRefreshRequested);
}

void SEDGraphNode_BaseNode::UpdateGraphNode()
{
	SGraphNode::UpdateGraphNode();

#if WITH_EDITOR
#endif
}

void SEDGraphNode_BaseNode::OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	SGraphNode::OnMouseEnter(MyGeometry, MouseEvent);
	bIsMouseOver = true;
}

void SEDGraphNode_BaseNode::OnMouseLeave(const FPointerEvent& MouseEvent)
{
	SGraphNode::OnMouseLeave(MouseEvent);
	bIsMouseOver = false;
}

void SEDGraphNode_BaseNode::MoveTo( const FVector2D& NewPosition, FNodeSet& NodeFilter, bool bMarkDirty )
{
	SGraphNode::MoveTo(NewPosition, NodeFilter, bMarkDirty);

#if WITH_EDITOR
	if (GraphNode && !RequiresSecondPassLayout())
	{
		if (UEDGraphNode_Base* NodeBase = Cast<UEDGraphNode_Base>(GraphNode))
		{
			if (NodeBase->NodeInstance)
			{
				if (UQuestActionBase* ActionData = Cast<UQuestActionBase>(NodeBase->NodeInstance))
				{
					ActionData->NotifyQuestEditor();
				}

				if (UQuestTargetBase* TargetData = Cast<UQuestTargetBase>(NodeBase->NodeInstance))
				{
					TargetData->NotifyQuestEditor();
				}

				if (UQuest* QuestData = Cast<UQuest>(NodeBase->NodeInstance))
				{
					QuestData->NotifyQuestEditor();
				}

				if (UQuestRing* RingData = Cast<UQuestRing>(NodeBase->NodeInstance))
				{
					RingData->NotifyQuestEditor();
				}
			}	
		}
	}
#endif
}

void SEDGraphNode_BaseNode::OnRefreshRequested(UEDGraphNode_Base* InNode, bool bFullRefresh)
{
	UpdateGraphNode();
}

#undef LOCTEXT_NAMESPACE
