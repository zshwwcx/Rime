#include "SEDGraphNode_StateNode.h"


#include "SLevelOfDetailBranchNode.h"
#include "SCommentBubble.h"
#include "SlateOptMacros.h"
#include "SGraphPin.h"
#include "Components/VerticalBox.h"
#include "SGraphPreviewer.h"
#include "GraphEditorSettings.h"
#include "Templates/SharedPointer.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/SToolTip.h"
#include "Widgets/SWidget.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Kismet2/KismetEditorUtilities.h"


#include "../EDGraphNode_StateNode.h"
#include "SEDGraphPin_StatePin.h"
#include "../EDGraphNode_Transition.h"
#include "Kismet/KismetSystemLibrary.h"

#define LOCTEXT_NAMESPACE "SEDGraphNode_StateNode"

void SEDGraphNode_StateNode::Construct(const FArguments& InArgs, UEDGraphNode_StateNodeBase* InNode)
{
	SEDGraphNode_BaseNode::Construct(SEDGraphNode_BaseNode::FArguments(), InNode);
	CachedStateNode = InNode;
	ContentPadding = InArgs._ContentPadding;
	TitleName = InNode->NodeName;
	//CastChecked<UEDGraphNode_Base>(GraphNode)->OnWidgetConstruct();

	if(UEDGraphNode_StateNodeBase* BaseStateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode))
	{
		BaseStateNode->NodeContentChanged.AddRaw(this, &SEDGraphNode_StateNode::OnRefreshNodeName);
	}
	if (InNode && InNode->NodeType == EDNodeType::RingQuest)
	{
		if(auto QuestData = Cast<UQuest>(InNode->NodeInstance))
		{
			QuestData->OnRefreshQuestName.AddRaw(this, &SEDGraphNode_StateNode::OnRefreshNodeName);
			if(QuestData->MainTarget)
			{
				if(auto BpClass = Cast<UBlueprintGeneratedClass>(QuestData->MainTarget->GetClass()))
				{
					TargetDesc = BpClass->GetDisplayNameText();
				}
			}
			EditName = QuestData->QuestName;
		}
		FString _Name = InNode->GetStateName();
		if (!_Name.IsEmpty())
		{
			TitleName = InNode->GetStateName();
		}
	}
	
	if (InNode && InNode->NodeType == EDNodeType::QuestAction)
	{
		NodeIdx = InNode->GetStateIdx();
	}

	if (InNode && InNode->NodeType == EDNodeType::QuestTarget)
	{
		NodeIdx = InNode->GetStateIdx();
	}

	UpdateGraphNode();
	SetCursor(EMouseCursor::CardinalCross);

	//const USMEditorSettings* EditorSettings = FSMBlueprintEditorUtils::GetEditorSettings();
	//{
	//	const FSlateBrush* FastPathImageBrush = FAppStyle::Get()->GetBrush(TEXT("SMGraph.FastPath"));

	//	FastPathWidget =
	//		SNew(SImage)
	//		.Image(FastPathImageBrush)
	//		.ToolTipText(NSLOCTEXT("StateNode", "StateNodeFastPathTooltip", "Fast path enabled: All execution points avoid going through the blueprint graph."))
	//		.Visibility(EVisibility::Visible);
	//}
}

void SEDGraphNode_StateNode::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SGraphNode::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);

	//OnRefreshNodeName();

	//UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	//StateNode->UpdateTime(InDeltaTime);
}

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void SEDGraphNode_StateNode::UpdateGraphNode()
{
	InputPins.Empty();
	OutputPins.Empty();

	// Reset variables that are going to be exposed, in case we are refreshing an already setup node.
	RightNodeBox.Reset();
	LeftNodeBox.Reset();

	const FLinearColor TitleShadowColor(0.6f, 0.6f, 0.6f);

	SetupErrorReporting();
	TSharedPtr<SErrorText> ErrorText;
	const TSharedPtr<SWidget> ContentBox = CreateContentBox();

	this->ContentScale.Bind(this, &SGraphNode::GetContentScale);
	this->GetOrAddSlot(ENodeZone::Center)
	.HAlign(HAlign_Center)
	.VAlign(VAlign_Center)
	[
		SNew(SBorder)
		.BorderImage(FAppStyle::Get().GetBrush("Graph.StateNode.Body"))
		.Padding(0)
		.BorderBackgroundColor(this, &SEDGraphNode_StateNode::GetBorderBackgroundColor)
		[
			SNew(SOverlay)

			// PIN AREA
			+ SOverlay::Slot()
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Fill)
			[
				SAssignNew(RightNodeBox, SVerticalBox)
			]
	
			// STATE NAME AREA
			+ SOverlay::Slot()
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			.Padding(FMargin(6.f, 6.f, 6.f, 6.f))
			[
				SNew(SBorder)
				.BorderImage(FAppStyle::Get().GetBrush("Graph.StateNode.ColorSpill"))
				.BorderBackgroundColor(TitleShadowColor)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Visibility(EVisibility::SelfHitTestInvisible)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.AutoWidth()
					[
						// POPUP ERROR MESSAGE
						SAssignNew(ErrorText, SErrorText)
						.BackgroundColor(this, &SEDGraphNode_StateNode::GetErrorColor)
						.ToolTipText(this, &SEDGraphNode_StateNode::GetErrorMsgToolTip)
					]
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					+ SHorizontalBox::Slot()
					.Padding(ContentPadding)
					[
						ContentBox.ToSharedRef()
					]
				]
			]
		]
	];

	// Create comment bubble
	TSharedPtr<SCommentBubble> CommentBubble;
	const FSlateColor CommentColor = FLinearColor(1,1,1,1);

	SAssignNew(CommentBubble, SCommentBubble)
		.GraphNode(GraphNode)
		.Text(this, &SGraphNode::GetNodeComment)
		.OnTextCommitted(this, &SGraphNode::OnCommentTextCommitted)
		.ColorAndOpacity(CommentColor)
		.AllowPinning(true)
		.EnableTitleBarBubble(true)
		.EnableBubbleCtrls(true)
		.GraphLOD(this, &SGraphNode::GetCurrentLOD)
		.IsGraphNodeHovered(this, &SGraphNode::IsHovered);

	GetOrAddSlot(ENodeZone::TopCenter)
		.SlotOffset(TAttribute<FVector2D>(CommentBubble.Get(), &SCommentBubble::GetOffset))
		.SlotSize(TAttribute<FVector2D>(CommentBubble.Get(), &SCommentBubble::GetSize))
		.AllowScaling(TAttribute<bool>(CommentBubble.Get(), &SCommentBubble::IsScalingAllowed))
		.VAlign(VAlign_Top)
		[
			CommentBubble.ToSharedRef()
		];

	ErrorReporting = ErrorText;
	ErrorReporting->SetError(ErrorMsg);
	CreatePinWidgets();

	CalculateAnyStateImpact();
	CalculateLinkStateImpact();
}
END_SLATE_FUNCTION_BUILD_OPTIMIZATION

void SEDGraphNode_StateNode::CreatePinWidgets()
{
	const UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);

	UEdGraphPin* PinToUse = StateNode->GetOutputPin();
	if (!PinToUse)
	{
		// For cases where there is no output pin.
		PinToUse = StateNode->GetInputPin();
	}

	if (PinToUse && UKismetSystemLibrary::IsValid(PinToUse->GetOwningNode()) && !PinToUse->bHidden)
	{
		const TSharedPtr<SGraphPin> NewPin = SNew(SEDGraphPin_StatePin, PinToUse);
		this->AddPin(NewPin.ToSharedRef());
	}
}

void SEDGraphNode_StateNode::AddPin(const TSharedRef<SGraphPin>& PinToAdd)
{
	PinToAdd->SetOwner(SharedThis(this));
	RightNodeBox->AddSlot()
		.HAlign(HAlign_Fill)
		.VAlign(VAlign_Fill)
		.FillHeight(1.0f)
		[
			PinToAdd
		];
	OutputPins.Add(PinToAdd);
}


void SEDGraphNode_StateNode::OnRefreshNodeName()
{
	UEDGraphNode_StateNodeBase* BaseStateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	if (BaseStateNode && InlineEditableText.IsValid())
	{
		TitleName = BaseStateNode->NodeName;
		if (BaseStateNode->NodeType == EDNodeType::RingQuest)
		{
			FString _Name = BaseStateNode->GetStateName();
			if (!_Name.IsEmpty())
			{
				TitleName = BaseStateNode->GetStateName();
			}
		}
		InlineEditableText->SetText(FText::FromString(TitleName));

		if (BaseStateNode->NodeType == EDNodeType::QuestAction && NodeIdxText.IsValid())
		{
			NodeIdx = BaseStateNode->GetStateIdx();
			NodeIdxText->SetText(FText::FromString(NodeIdx));
		}

		if (BaseStateNode->NodeType == EDNodeType::QuestTarget && NodeIdxText.IsValid())
		{
			NodeIdx = BaseStateNode->GetStateIdx();
			NodeIdxText->SetText(FText::FromString(NodeIdx));
		}
		
		if (BaseStateNode->NodeType == EDNodeType::RingQuest)
		{
			if(auto QuestData = Cast<UQuest>(BaseStateNode->NodeInstance))
			{
				if(QuestData->MainTarget)
				{
					if(auto BpClass = Cast<UBlueprintGeneratedClass>(QuestData->MainTarget->GetClass()))
					{
						TargetDesc = BpClass->GetDisplayNameText();
					}
				}
				EditName = QuestData->QuestName;
			}
			EditNameBlock->SetText(FText::FromString(EditName));
			TargetDescBlock->SetText(TargetDesc);
		}
	}
	Invalidate(EInvalidateWidget::LayoutAndVolatility);
}

TSharedPtr<SToolTip> SEDGraphNode_StateNode::GetComplexTooltip()
{
	/* Display a pop-up on mouse hover with useful information. */
	const TSharedPtr<SVerticalBox> Widget = BuildComplexTooltip();

	return SNew(SToolTip)
		[
			Widget.ToSharedRef()
		];
}

TArray<FOverlayWidgetInfo> SEDGraphNode_StateNode::GetOverlayWidgets(bool bSelected, const FVector2D& WidgetSize) const
{
	TArray<FOverlayWidgetInfo> Widgets;

	//const USMEditorSettings* EditorSettings = FSMBlueprintEditorUtils::GetEditorSettings();
	//if (!EditorSettings->bDisableVisualCues)
	//{
	//	if (const UEDGraphNode_StateNodeBase* StateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
	//	{
	//		const FSlateBrush* LinkStateImageBrush = FAppStyle::Get()->GetBrush(TEXT("SMGraph.LinkState"));
	//		if (LinkStateImpactWidget.IsValid())
	//		{
	//			FOverlayWidgetInfo Info;
	//			Info.OverlayOffset = FVector2D(WidgetSize.X - (LinkStateImageBrush->ImageSize.X * 0.5f), -(LinkStateImageBrush->ImageSize.Y * 0.5f));
	//			Info.Widget = LinkStateImpactWidget;

	//			Widgets.Add(MoveTemp(Info));
	//		}

	//		const FSlateBrush* AnyStateImageBrush = FAppStyle::Get()->GetBrush(TEXT("SMGraph.AnyState"));
	//		for (const TSharedPtr<SWidget>& AnyStateWidget : AnyStateImpactWidgets)
	//		{
	//			FOverlayWidgetInfo Info;
	//			Info.OverlayOffset = FVector2D(WidgetSize.X - (AnyStateImageBrush->ImageSize.X * 0.5f) - (Widgets.Num() * OverlayWidgetPadding),
	//				-(AnyStateImageBrush->ImageSize.Y * 0.5f));
	//			Info.Widget = AnyStateWidget;

	//			Widgets.Add(MoveTemp(Info));
	//		}
	//		if (EditorSettings->bDisplayFastPath && StateNode->IsNodeFastPathEnabled())
	//		{
	//			const FSlateBrush* FastPathImageBrush = FAppStyle::Get()->GetBrush(TEXT("SMGraph.FastPath"));

	//			FOverlayWidgetInfo Info;
	//			Info.OverlayOffset = FVector2D(WidgetSize.X - (FastPathImageBrush->ImageSize.X * 0.5f) - (Widgets.Num() * OverlayWidgetPadding),
	//				-(FastPathImageBrush->ImageSize.Y * 0.5f));
	//			Info.Widget = FastPathWidget;

	//			Widgets.Add(MoveTemp(Info));
	//		}
	//	}
	//}

	return Widgets;
}

FReply SEDGraphNode_StateNode::OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	return SGraphNode::OnMouseButtonDoubleClick(InMyGeometry, InMouseEvent);
}

void SEDGraphNode_StateNode::RequestRenameOnSpawn()
{
	SGraphNode::RequestRenameOnSpawn();
}

FReply SEDGraphNode_StateNode::OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	return SEDGraphNode_BaseNode::OnDrop(MyGeometry, DragDropEvent);
}

FReply SEDGraphNode_StateNode::OnDragOver(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	return SEDGraphNode_BaseNode::OnDragOver(MyGeometry, DragDropEvent);
}

SEDGraphNode_StateNode::~SEDGraphNode_StateNode()
{
	if (!CachedStateNode.IsValid())
	{
		return;
	}
	if(auto StateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
	{
		if (StateNode->NodeType == EDNodeType::RingQuest)
		{
			if(auto QuestData = Cast<UQuest>(StateNode->NodeInstance))
			{
				QuestData->OnRefreshQuestName.RemoveAll(this);
			}
		}

		if (StateNode->NodeType == EDNodeType::ChapterRing)
		{
			if(auto QuestData = Cast<UQuestRing>(StateNode->NodeInstance))
			{
				QuestData->OnRefreshRingname.RemoveAll(this);
			}
		}

		if (StateNode->NodeType == EDNodeType::ChapterEnd)
		{
			if(auto QuestData = Cast<UChapterEnd>(StateNode->NodeInstance))
			{
				QuestData->OnChapterEndChanged.RemoveAll(this);
			}
		}
		StateNode->NodeContentChanged.RemoveAll(this);
	}
}

TSharedPtr<SVerticalBox> SEDGraphNode_StateNode::BuildComplexTooltip()
{
	UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);

	const bool bCanExecute = StateNode->HasInputConnections();
	const bool bIsEndState = StateNode->IsEndState(false);
	bool bIsAnyState = false;

	TSharedPtr<SVerticalBox> Widget = SNew(SVerticalBox);
	Widget->AddSlot()
		.AutoHeight()
		.Padding(FMargin(0.f, 0.f, 0.f, 4.f))
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(STextBlock)
		.Text(FText::Format(LOCTEXT("StatePopupTitle", "{0} ({1})"), FText::FromString(StateNode->GetStateName()), FText::FromString(FString(""))))
		]
		];

	if (UEdGraph* Graph = GetGraphToUseForTooltip())
	{
		Widget->AddSlot()
			.AutoHeight()
			[
				SNew(SGraphPreviewer, Graph)
				.ShowGraphStateOverlay(false)
			];
	}
	if (!bCanExecute && !bIsAnyState)
	{
		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(2.f, 4.f, 2.f, 2.f))
			[
				SNew(STextBlock)
			.Text(LOCTEXT("StateCantExecuteTooltip", "No Valid Input: State will never execute"))
			];
	}

	if (bIsEndState)
	{
		const FText EndStateTooltip = StateNode->IsEndState(true) ? LOCTEXT("EndStateTooltip", "End State: State will never exit") :
			LOCTEXT("NotEndStateTooltip", "Not an End State: An Any State node is adding transitions to this node");

		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(2.f, 4.f, 2.f, 2.f))
			[
				SNew(STextBlock)
			.Text(EndStateTooltip)
			];
	}
	else if (true)
	{
		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(10.f, 4.f, 2.f, 2.f))
			[
				SNew(STextBlock)
			.Text(LOCTEXT("AnyStateImpactTooltip", "An Any State node is adding transitions to this node"))
			];
	}

	return Widget;
}

UEdGraph* SEDGraphNode_StateNode::GetGraphToUseForTooltip() const
{
	//const UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	//return StateNode->GetBoundGraph();

	return nullptr;
}

void SEDGraphNode_StateNode::CalculateAnyStateImpact()
{
	//AnyStateImpactWidgets.Reset();

	//const UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	//TArray<USMGraphNode_AnyStateNode*> AnyStates;

	//const USMEditorSettings* EditorSettings = FSMBlueprintEditorUtils::GetEditorSettings();
	//if (EditorSettings->MaxAnyStateIcons > 0 && FSMBlueprintEditorUtils::IsNodeImpactedFromAnyStateNode(StateNode, &AnyStates))
	//{
	//	// Sort first so similar colors are grouped. Luminance seems to provide quickest and best results.
	//	AnyStates.Sort([](const USMGraphNode_AnyStateNode& AnyStateA, const USMGraphNode_AnyStateNode& AnyStateB)
	//		{
	//			return AnyStateA.GetAnyStateColor().GetLuminance() >= AnyStateB.GetAnyStateColor().GetLuminance();
	//		});

	//	int32 ColorsOverLimit = 1;
	//	for (int32 AnyStateIdx = 0; AnyStateIdx < AnyStates.Num(); ++AnyStateIdx)
	//	{
	//		const USMGraphNode_AnyStateNode* AnyState = AnyStates[AnyStateIdx];
	//		const bool bIsGrouped = AnyStateIdx >= EditorSettings->MaxAnyStateIcons;
	//		const bool bIsLastIteration = AnyStateIdx == AnyStates.Num() - 1;

	//		FLinearColor AnyStateColor = AnyState->GetAnyStateColor();

	//		if (bIsGrouped)
	//		{
	//			ColorsOverLimit++;
	//			if (!bIsLastIteration)
	//			{
	//				// Skip until end.
	//				continue;
	//			}
	//		}

	//		FText TooltipText;

	//		if (bIsGrouped)
	//		{
	//			// Replace the last one with the grouped widget.
	//			AnyStateImpactWidgets.RemoveAt(0);

	//			TooltipText = FText::FromString(FString::Printf(TEXT("An additional %s Any State nodes are adding transitions to this node."),
	//				*FString::FromInt(ColorsOverLimit)));

	//			AnyStateColor = FLinearColor::White;
	//		}
	//		else
	//		{
	//			// Display individual any state.
	//			TooltipText = FText::FromString(FString::Printf(TEXT("The Any State node '%s' is adding one or more transitions to this state."),
	//				*AnyState->GetStateName()));
	//		}

	//		AnyStateColor.A = 0.72f;

	//		const FSlateBrush* ImageBrush = FAppStyle::Get()->GetBrush(TEXT("SMGraph.AnyState"));
	//		TSharedPtr<SWidget> Widget =
	//			SNew(SBorder)
	//			.BorderImage(FAppStyle::Get().GetBrush("NoBorder"))
	//			.Cursor(bIsGrouped ? EMouseCursor::Default : EMouseCursor::Hand)
	//			.Padding(0.f)
	//			.VAlign(VAlign_Center)
	//			.OnMouseDoubleClick_Lambda([AnyState, bIsGrouped](const FGeometry&, const FPointerEvent&)
	//				{
	//					if (!bIsGrouped && AnyState)
	//					{
	//						FKismetEditorUtilities::BringKismetToFocusAttentionOnObject(AnyState);
	//					}
	//					return FReply::Handled();
	//				})
	//			[
	//				SNew(SOverlay)
	//				+ SOverlay::Slot()
	//					.VAlign(VAlign_Center)
	//					[
	//						SNew(SImage)
	//						.Image(ImageBrush)
	//					.ToolTipText(TooltipText)
	//					.ColorAndOpacity(AnyStateColor)
	//					.Visibility(EVisibility::Visible)
	//					]
	//				+ SOverlay::Slot()
	//					.VAlign(VAlign_Center)
	//					.HAlign(HAlign_Center)
	//					[
	//						SNew(STextBlock)
	//						.Visibility(bIsGrouped ? EVisibility::HitTestInvisible : EVisibility::Collapsed)
	//					.Text(FText::FromString(FString::FromInt(ColorsOverLimit)))
	//					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 8))
	//					.ColorAndOpacity(FLinearColor::Black)
	//					]
	//			];

	//				AnyStateImpactWidgets.Insert(Widget, 0);
	//	}
	//}
}

void SEDGraphNode_StateNode::CalculateLinkStateImpact()
{
	//LinkStateImpactWidget.Reset();

	//const UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);

	//const bool bIsLinkState = StateNode->IsA<USMGraphNode_LinkStateNode>();
	//const bool bHasLinkedStates = StateNode->GetLinkedStates().Num() > 0;

	//if (bIsLinkState || bHasLinkedStates)
	//{
	//	FText TooltipText;

	//	if (bIsLinkState)
	//	{
	//		TooltipText = LOCTEXT("LinkState_Tooltip", "This node is a proxy for another state in the graph.");
	//	}
	//	else if (bHasLinkedStates)
	//	{
	//		TooltipText = LOCTEXT("LinkByStates_Tooltip", "This node is linked to from one or more proxy states in the graph.");
	//	}

	//	const FSlateBrush* ImageBrush = FAppStyle::Get()->GetBrush(TEXT("SMGraph.LinkState"));
	//	SAssignNew(LinkStateImpactWidget, SBorder)
	//		.BorderImage(FAppStyle::Get().GetBrush("NoBorder"))
	//		.Cursor(EMouseCursor::Hand)
	//		.Padding(0.f)
	//		.VAlign(VAlign_Center)
	//		.OnMouseDoubleClick_Lambda([bIsLinkState, bHasLinkedStates, StateNode](const FGeometry&, const FPointerEvent&)
	//			{
	//				if (bIsLinkState)
	//				{
	//					FKismetEditorUtilities::BringKismetToFocusAttentionOnObject(CastChecked<USMGraphNode_LinkStateNode>(StateNode)->GetLinkedState());
	//				}
	//				else if (bHasLinkedStates)
	//				{
	//					const TSet<USMGraphNode_LinkStateNode*>& LinkedStates = StateNode->GetLinkedStates();
	//					if (LinkedStates.Num() == 1)
	//					{
	//						FKismetEditorUtilities::BringKismetToFocusAttentionOnObject(*LinkedStates.CreateConstIterator());
	//					}
	//					else
	//					{
	//						if (FSMBlueprintEditor* Editor = FSMBlueprintEditorUtils::GetStateMachineEditor(StateNode))
	//						{
	//							Editor->SelectNodes(reinterpret_cast<const TSet<UEdGraphNode*>&>(LinkedStates), true);
	//						}
	//					}
	//				}
	//				return FReply::Handled();
	//			})
	//		[
	//			SNew(SOverlay)
	//			+ SOverlay::Slot()
	//				.VAlign(VAlign_Center)
	//				[
	//					SNew(SImage)
	//					.Image(ImageBrush)
	//				.ToolTipText(TooltipText)
	//				.Visibility(EVisibility::Visible)
	//				]
	//		];
	//}
}

void SEDGraphNode_StateNode::GetNodeInfoPopups(FNodeInfoContext* Context,
	TArray<FGraphInformationPopupInfo>& Popups) const
{
	//const UEDGraphNode_StateNodeBase* Node = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	//if (const FSMNode_Base* DebugNode = Node->GetDebugNode())
	//{
	//	// Show active time or last active time over the node.

	//	if (Node->IsDebugNodeActive())
	//	{
	//		const FString StateText = FString::Printf(TEXT("Active for %.2f secs"), DebugNode->TimeInState);
	//		new (Popups) FGraphInformationPopupInfo(nullptr, Node->GetBackgroundColor(), StateText);
	//	}
	//	else if (Node->WasDebugNodeActive())
	//	{

	//		const USMEditorSettings* EditorSettings = FSMBlueprintEditorUtils::GetEditorSettings();

	//		const float StartFade = EditorSettings->TimeToDisplayLastActiveState;
	//		const float TimeToFade = EditorSettings->TimeToFadeLastActiveState;
	//		const float DebugTime = Node->GetDebugTime();

	//		if (DebugTime < StartFade + TimeToFade)
	//		{
	//			const FString StateText = FString::Printf(TEXT("Was Active for %.2f secs"), DebugNode->TimeInState);

	//			if (DebugTime > StartFade)
	//			{
	//				FLinearColor Color = Node->GetBackgroundColor();

	//				const float PercentComplete = TimeToFade <= 0.f ? 0.f : FMath::Clamp(Color.A * (1.f - (DebugTime - StartFade) / TimeToFade), 0.f, Color.A);
	//				Color.A *= PercentComplete;

	//				const FLinearColor ResultColor = Color;
	//				new (Popups) FGraphInformationPopupInfo(nullptr, ResultColor, StateText);
	//			}
	//			else
	//			{
	//				new (Popups) FGraphInformationPopupInfo(nullptr, Node->GetBackgroundColor(), StateText);
	//			}
	//		}
	//	}
	//}
}

void SEDGraphNode_StateNode::OnRefreshRequested(UEDGraphNode_Base* InNode, bool bFullRefresh)
{
	CalculateAnyStateImpact();
	CalculateLinkStateImpact();

	SEDGraphNode_BaseNode::OnRefreshRequested(InNode, bFullRefresh);
}

TSharedPtr<SWidget> SEDGraphNode_StateNode::CreateContentBox()
{
	TSharedPtr<SVerticalBox> Content;
	TSharedPtr<SNodeTitle> NodeTitle = SNew(SNodeTitle, GraphNode);
	SAssignNew(Content, SVerticalBox);

	// 在状态描述区域的顶部显示节点编号, 仅QuestAction有效
	UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	if (StateNode && (StateNode->NodeType == EDNodeType::QuestAction || StateNode->NodeType == EDNodeType::QuestTarget))
	{
		Content->AddSlot()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Top)
		.AutoHeight()
		[
			SAssignNew(NodeIdxText, STextBlock)
			.Text(FText::FromString(NodeIdx))
			.ColorAndOpacity(FLinearColor::White)
			.Font(FCoreStyle::GetDefaultFontStyle("Regular", 12))
		];	
	}

	if(StateNode->NodeType == EDNodeType::RingQuest)
	{
		TArray<UEDGraphNode_Base*> LinkToNodes;
		TArray<UEDGraphNode_Base*> LinkFromNodes;
		StateNode->GetOutputTransitionNodes(LinkToNodes, UEDGraphNode_Transition::StaticClass());
		StateNode->GetInputTransitionNodes(LinkFromNodes, UEDGraphNode_Transition::StaticClass());
		if (LinkFromNodes.Num() == 0)
		{
			Content->AddSlot()
			.AutoHeight()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("StartNodeHintText", "Start Node"))
				.Font(FAppStyle::Get().GetFontStyle("NormalFontBold"))
			];
		}else if (LinkToNodes.Num() == 0)
		{
			Content->AddSlot()
			.AutoHeight()
			[
				SNew(STextBlock)
				.Text(LOCTEXT("EndNodeHintText","End Node"))
				.Font(FAppStyle::Get().GetFontStyle("NormalFontBold"))
			];
		}
	}
	
	if(StateNode->NodeType == EDNodeType::RingQuest)
	{
		Content->AddSlot()
		.AutoHeight()
		[
			SAssignNew(EditNameBlock, STextBlock)
			.Text(FText::FromString(EditName))
			.Visibility(EVisibility::Visible)
		];
	}
	
	Content->AddSlot()
		.AutoHeight()
		[
			SAssignNew(InlineEditableText, SInlineEditableTextBlock)
			.Style(FAppStyle::Get(), "Graph.StateNode.NodeTitleInlineEditableText")
			.Text(FText::FromString(TitleName))
			.OnVerifyTextChanged(this, &SEDGraphNode_StateNode::OnVerifyNameTextChanged)
			.OnTextCommitted(this, &SEDGraphNode_StateNode::OnNameTextCommited)
			.IsReadOnly(this, &SEDGraphNode_StateNode::IsNameReadOnly)
			.IsSelected(this, &SEDGraphNode_StateNode::IsSelectedExclusively)
			.Visibility(EVisibility::Visible)
		];

	if(StateNode->NodeType == EDNodeType::RingQuest)
	{
		Content->AddSlot()
		.AutoHeight()
		[
			SAssignNew(TargetDescBlock, STextBlock)
			.Text(TargetDesc)
			.Visibility(EVisibility::Visible)
		];
	}
	
	Content->AddSlot()
		.AutoHeight()
		[
			NodeTitle.ToSharedRef()
		];

	//// Add custom property widgets sorted by user specification.
	//UEDGraphNode_StateNodeBase* StateNodeBase = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);

	//// Populate all used state classes, in order.
	//TArray<USMNodeInstance*> NodeTemplates;

	//auto IsValidClass = [](UEDGraphNode_Base* Node, UClass* NodeClass) {return NodeClass && NodeClass != Node->GetDefaultNodeClass(); };

	//if (IsValidClass(StateNodeBase, StateNodeBase->GetNodeClass()))
	//{
	//	NodeTemplates.Add(StateNodeBase->GetNodeTemplate());
	//}

	return Content;
}

FSlateColor SEDGraphNode_StateNode::GetBorderBackgroundColor() const
{
	if (!CachedStateNode.IsValid())
	{
		return FColor::White;
	}
	UEDGraphNode_StateNodeBase* StateNode = CachedStateNode.Pin().Get();

	TArray<UEDGraphNode_Base*> LinkToNodes;
	TArray<UEDGraphNode_Base*> LinkFromNodes;
	FLinearColor RetVal = StateNode->GetBackgroundColor();
	switch (StateNode->NodeType)
	{
	case EDNodeType::QuestTarget:
		if (const UQuestTargetBase* QuestTargetBase = Cast<UQuestTargetBase>(StateNode->NodeInstance))
			return QuestTargetBase->NodeColor;
		else
			return FLinearColor::Yellow;
		break;
	case EDNodeType::QuestAction:
		StateNode->GetInputTransitionNodes(LinkFromNodes, UEDGraphNode_Transition::StaticClass());
		if(LinkFromNodes.Num() == 1)
		{
			UEDGraphNode_Base* TransNodeBase = LinkFromNodes[0];
			if (UEDGraphNode_Transition* TransNode = Cast<UEDGraphNode_Transition>(TransNodeBase))
			{
				UEDGraphNode_Base* ParentNode = TransNode->GetFromState();
				while(ParentNode && ParentNode->NodeType == EDNodeType::QuestAction)
				{
					LinkFromNodes.Empty();
					ParentNode->GetInputTransitionNodes(LinkFromNodes, UEDGraphNode_Transition::StaticClass());
					if(LinkFromNodes.Num() == 1)
					{
						if (UEDGraphNode_Transition* ChildTransNode = Cast<UEDGraphNode_Transition>(LinkFromNodes[0]))
						{
							TransNode = ChildTransNode;
							ParentNode = ChildTransNode->GetFromState();
						}
						else
							ParentNode = nullptr;
					}
					else
						ParentNode = nullptr;
				}
				
				if (ParentNode && ParentNode->NodeType == EDNodeType::QuestEnd)
				{
					TArray<UEDGraphNode_Base*> LinkSuccessTrans;
					UEdGraphPin* SuccessPin = ParentNode->FindPin(TEXT("Out"));
					ParentNode->GetOutputTransitionNodesWithPin(LinkSuccessTrans, UEDGraphNode_Base::StaticClass(), SuccessPin);
					TArray<UEDGraphNode_Base*> LinkFailTrans;
					UEdGraphPin* FailPin = ParentNode->FindPin(TEXT("Out2"));
					ParentNode->GetOutputTransitionNodesWithPin(LinkFailTrans, UEDGraphNode_Base::StaticClass(), FailPin);
					if (LinkSuccessTrans.Contains(TransNode))
						return FLinearColor::Green;
					if (LinkFailTrans.Contains(TransNode))
						return FLinearColor::Red;
				}
			}
		}
		
		if (const UQuestActionBase* QuestActionBase = Cast<UQuestActionBase>(StateNode->NodeInstance))
			return QuestActionBase->NodeColor;
		else
			return FLinearColor::Blue;
		break;

	case EDNodeType::RingQuest:
		StateNode->GetOutputTransitionNodes(LinkToNodes, UEDGraphNode_Transition::StaticClass());
		StateNode->GetInputTransitionNodes(LinkFromNodes, UEDGraphNode_Transition::StaticClass());
		if(auto NodeIns = Cast<UQuest>(StateNode->NodeInstance))
		{
			if(NodeIns->FallbackSetting == EFallbackSetting::Checkpoint)
			{
				RetVal = FLinearColor::Yellow;
			}
			else if(NodeIns->FallbackSetting == EFallbackSetting::FallbackPoint)
			{
				RetVal = FLinearColor::Blue;
			}

			if (NodeIns->bQuestReward)
			{
				RetVal = FLinearColor::Green;
			}
		}

		if(LinkFromNodes.Num() == 0 && LinkToNodes.Num() == 0)
		{
			if (GraphNode->GetGraph()->Nodes.Num() > 1)
			{
				return FLinearColor::Red;
			}
		}
		
		return RetVal;

	case EDNodeType::ChapterEnd:
		return  FLinearColor::Green;
	}

	return StateNode->GetBackgroundColor();
}

const FSlateBrush* SEDGraphNode_StateNode::GetNameIcon() const
{
	UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	if (const FSlateBrush* Brush = StateNode->GetNodeIcon())
	{
		return Brush;
	}

	return FAppStyle::Get().GetBrush(TEXT("Graph.StateNode.Icon"));
}


#undef LOCTEXT_NAMESPACE