#include "EDGraphNode_Base.h"
#include "../Graph/EventDrivenGraphSchema.h"

UEDGraphNode_Base::UEDGraphNode_Base(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bCanRenameNode = true;
}

void UEDGraphNode_Base::DestroyNode()
{
	Super::DestroyNode();
}

void UEDGraphNode_Base::PostPasteNode()
{
	Super::PostPasteNode();
}

void UEDGraphNode_Base::PostEditUndo()
{
	Super::PostEditUndo();
}

void UEDGraphNode_Base::PostPlacedNewNode()
{
	UClass* NodeClass = ClassData.GetClass(true);
	if (NodeClass && (NodeInstance == nullptr))
	{
		UEdGraph* MyGraph = GetGraph();
		UObject* GraphOwner = MyGraph ? MyGraph->GetOuter() : nullptr;
		if (GraphOwner)
		{
			NodeInstance = NewObject<UObject>(this, NodeClass);
			NodeInstance->SetFlags(RF_Transactional);

			//if (UEDNodeBase* NewNodeBase = Cast<UEDNodeBase>(NodeInstance))
			//{
			//	NodeName = NewNodeBase->TitleName;
			//}
		}
	}
}

void UEDGraphNode_Base::OnRenameNode(const FString& NewName)
{
}

UObject* UEDGraphNode_Base::GetJumpTargetForDoubleClick() const
{
	return nullptr;
}

bool UEDGraphNode_Base::CanJumpToDefinition() const
{
	return GetJumpTargetForDoubleClick() != nullptr;
}

void UEDGraphNode_Base::JumpToDefinition() const
{

}

bool UEDGraphNode_Base::CanCreateUnderSpecifiedSchema(const UEdGraphSchema* Schema) const
{
	return Schema->IsA(UEventDrivenGraphSchema::StaticClass());
}

void UEDGraphNode_Base::ReconstructNode()
{
	Super::ReconstructNode();
}

void UEDGraphNode_Base::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UEDGraphNode_Base::PinConnectionListChanged(UEdGraphPin* Pin)
{
	Super::PinConnectionListChanged(Pin);
}

void UEDGraphNode_Base::ValidateNodeDuringCompilation(FCompilerResultsLog& MessageLog) const
{
	Super::ValidateNodeDuringCompilation(MessageLog);
}


FLinearColor UEDGraphNode_Base::GetBackgroundColor() const
{
	//const FLinearColor* CustomColor = GetCustomBackgroundColor();
	//const FLinearColor BaseColor = Internal_GetBackgroundColor() * (CustomColor ? *CustomColor : FLinearColor(1.f, 1.f, 1.f, 1.f));
	//const FLinearColor ActiveColor = GetActiveBackgroundColor();

	//if (GetDebugNode() == nullptr)
	//{
	//	return BaseColor;
	//}

	//if (IsDebugNodeActive())
	//{
	//	return ActiveColor;
	//}

	//const float TimeToFade = 0.7f;
	//const float DebugTime = GetDebugTime();

	//if (bWasDebugActive && DebugTime < TimeToFade)
	//{
	//	return FLinearColor::LerpUsingHSV(ActiveColor, BaseColor, DebugTime / TimeToFade);
	//}

	return FLinearColor(1.f, 1.f, 1.f, 1.f);
}

const FSlateBrush* UEDGraphNode_Base::GetNodeIcon() const
{
	return nullptr;
}

UEdGraphPin* UEDGraphNode_Base::GetInputPin() const
{
	if (Pins.Num() == 0 || Pins[0]->Direction == EGPD_Output)
	{
		return nullptr;
	}

	return Pins[0];
}

UEdGraphPin* UEDGraphNode_Base::GetOutputPin() const
{
	for (UEdGraphPin* Pin : Pins)
	{
		if (Pin->Direction == EGPD_Output)
		{
			return Pin;
		}
	}

	return nullptr;
}

void UEDGraphNode_Base::GetInputTransitionNodes(TArray<UEDGraphNode_Base*>& OutInputTransNodes, UClass* FilterClass)
{
	for (UEdGraphPin* FromPin : Pins)
	{
		if (FromPin->Direction == EGPD_Input)
		{
			TArray<UEdGraphPin*> LinkTos = FromPin->LinkedTo;
			for (UEdGraphPin* ToPin : LinkTos)
			{
				if (ToPin->Direction == EEdGraphPinDirection::EGPD_Output)
				{
					UEdGraphNode* ToNode = ToPin->GetOwningNodeUnchecked();
					if (ToNode && ToNode->IsA(FilterClass))
					{
						if (UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(ToNode))
						{
							OutInputTransNodes.AddUnique(EDNode);
						}
					}
				}
			}
		}
	}
}

void UEDGraphNode_Base::GetOutputTransitionNodes(TArray<UEDGraphNode_Base*>& OutInputTransNodes, UClass * FilterClass)
{
	for (UEdGraphPin* FromPin : Pins)
	{
		if (FromPin->Direction == EGPD_Output)
		{
			TArray<UEdGraphPin*> LinkTos = FromPin->LinkedTo;
			for (UEdGraphPin* ToPin : LinkTos)
			{
				if (ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
				{
					UEdGraphNode* ToNode = ToPin->GetOwningNodeUnchecked();
					if (ToNode && ToNode->IsA(FilterClass))
					{
						if (UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(ToNode))
						{
							OutInputTransNodes.AddUnique(EDNode);
						}
					}
				}
			}
		}
	}
}

void UEDGraphNode_Base::GetOutputTransitionNodesWithPin(TArray<UEDGraphNode_Base*>& OutInputTransNodes, UClass * FilterClass, UEdGraphPin* Pin)
{
	if (Pin)
	{
		if (Pin->Direction == EGPD_Output)
		{
			TArray<UEdGraphPin*> LinkTos = Pin->LinkedTo;
			for (UEdGraphPin* ToPin : LinkTos)
			{
				if (ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
				{
					UEdGraphNode* ToNode = ToPin->GetOwningNodeUnchecked();
					if (ToNode && ToNode->IsA(FilterClass))
					{
						if (UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(ToNode))
						{
							OutInputTransNodes.AddUnique(EDNode);
						}
					}
				}
			}
		}
	}
}
