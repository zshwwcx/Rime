#pragma once


#include "EDGraphNode_Base.h"
#include "QuestTemplate.h"
#include "EDGraphNode_Transition.generated.h"


UCLASS()
class UEDGraphNode_Transition : public UEDGraphNode_Base
{
	GENERATED_UCLASS_BODY()

	
	/**
	 * The class of the instance containing the delegate.
	 */
	UPROPERTY(EditAnywhere, Category = "Event Trigger")
	TSubclassOf<UObject> DelegateOwnerClass;
	
	/**
	 * The guid assigned to this property if one exists.
	 */
	UPROPERTY()
	FGuid DelegatePropertyGuid;
	
	/**
	 * Available delegates.
	 */
	UPROPERTY(EditAnywhere, Category = "Event Trigger")
	FName DelegatePropertyName;

	/**
	 * If the event should trigger a targeted update of the state machine limited to this
	 * transition and destination state.
	 * 
	 * This can efficiently allow state machines with tick disabled to update. This
	 * won't evaluate parallel or super state transitions.
	 *
	 * This setting can also be changed on each Event Trigger Result Node.
	 */
	UPROPERTY(EditAnywhere, Category = "Event Trigger", meta = (DisplayName = "Targeted Update"))
	uint8 bEventTriggersTargetedUpdate: 1;

	/**
	 * If the event should trigger a full update of the state machine. Setting this will be applied
	 * after 'Targeted Update'. A full update consists of evaluating transitions top down from the
	 * root state machine, as well as running OnStateUpdate if necessary.
	 *
	 * This is a legacy setting. To maintain old legacy behavior enable this setting and
	 * disable 'Targeted Update'.
	 *
	 * This setting can also be changed on each Event Trigger Result Node.
	 */
	UPROPERTY(EditAnywhere, AdvancedDisplay, Category = "Event Trigger", meta = (DisplayName = "Full Update"))
	uint8 bEventTriggersFullUpdate: 1;

	/**
	 * @deprecated Set on the node template instead.
	 */
	UPROPERTY()
	uint8 bCanEvaluate_DEPRECATED: 1;

	/**
	 * @deprecated Set on the node template instead.
	 */
	UPROPERTY()
	uint8 bCanEvaluateFromEvent_DEPRECATED: 1;
	
	/**
	 * @deprecated Set on the node template instead.
	 */
	UPROPERTY()
	uint8 bCanEvalWithStartState_DEPRECATED: 1;
	
	/**
	 * @deprecated Set on the node template instead.
	 */
	UPROPERTY()
	int32 PriorityOrder_DEPRECATED;

	/** Copy configurable settings from another transition node. */
	void CopyFrom(const UEDGraphNode_Transition& Transition);
	
	// UEdGraphNode
	virtual void AllocateDefaultPins() override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	virtual void PinConnectionListChanged(UEdGraphPin* Pin) override;
	virtual void PostPlacedNewNode() override;
	virtual void PrepareForCopying() override;
	virtual void PostPasteNode() override;
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent) override;
	virtual void DestroyNode() override;
	virtual bool CanDuplicateNode() const override { return true; }
	virtual void ReconstructNode() override;
	virtual UObject* GetJumpTargetForDoubleClick() const override;
	// ~UEdGraphNode

	virtual void ResetDebugState();
	virtual void UpdateTime(float DeltaTime);
	virtual void ImportDeprecatedProperties();
	virtual void PlaceDefaultInstanceNodes();
	virtual FName GetFriendlyNodeName() const { return "Transition"; }
	virtual FLinearColor GetBackgroundColor() const override;
	virtual FLinearColor GetActiveBackgroundColor() const;
	virtual UClass* GetNodeClass() const { return nullptr; }
	virtual void SetNodeClass(UClass* Class);
	virtual bool SupportsPropertyGraphs() const { return false; }
	virtual float GetMaxDebugTime() const;
	//virtual void PreCompile(FSMKismetCompilerContext& CompilerContext) override;
	//virtual void OnCompile(FSMKismetCompilerContext& CompilerContext) override;
	virtual const FSlateBrush* GetNodeIcon() const override;

protected:
	void CreateBoundGraph();
	void SetBoundGraph(UEdGraph* Graph);

public:
	/** Return the color to use for the transition. */
	FLinearColor GetTransitionColor(bool bIsHovered) const;

	/**
	 * Return the correct icon for the transition or transition stack.
	 * @param InIndex The icon to retrieve. < 0 for base transition, 0+ for the transition stack.
	 */
	const FSlateBrush* GetTransitionIcon(int32 InIndex);
	
	UClass* GetSelectedDelegateOwnerClass() const;
	
	void GoToTransitionEventNode();

	void InitTransitionDelegate();


	FString GetDisplayName();
	
protected:
	void SetupDelegateDefaults();
	void RefreshTransitionDelegate();
	
	/** Record the guid. */
	void UpdateTransitionDelegateGuid();

	/** Update all applicable transition result nodes with the event settings of this node. */
	void UpdateResultNodeEventSettings();
	
public:
	FString GetTransitionName() const;
	void CreateConnections(class UEDGraphNode_Base* Start, class UEDGraphNode_Base* End);
	void CreateConnections(UEdGraphPin* Start, UEdGraphPin* End);

	/** Checks if there is any possibility of transitioning. */
	bool PossibleToTransition() const;
	
	class UEDGraphNode_Base* GetFromState() const;
	class UEDGraphNode_Base* GetToState() const;

	bool ShouldRunParallel() const;
	bool WasEvaluating() const { return bWasEvaluating; }

	bool IsHovered() const { return bIsHoveredByUser; }
	bool IsFromAnyState() const;
	bool IsFromLinkState() const;

	/** Return the best pin to use for linear expression display. */
	UEdGraphPin* GetLinearExpressionPin() const;

	// 跳转条件 add by lyl, design for QuestAction Node
	UPROPERTY(VisibleAnywhere)
	UQuestActionConditionBase* TransitionCondition;

protected:
	virtual FLinearColor Internal_GetBackgroundColor() const;
	void SetDefaultsWhenPlaced();

protected:
	bool bWasEvaluating;
	
private:

	// UTC time stamp user last hovered this node.
	FDateTime LastHoverTimeStamp;
	
	// Time in seconds since last hover.
	double TimeSinceHover;
	
	// If the user is considered hovering this node.
	uint8 bIsHoveredByUser: 1;

	// Determined by kismet compiler. 
	uint8 bFromAnyState: 1;

	// Determined by kismet compiler.
	uint8 bFromLinkState: 1;
};
