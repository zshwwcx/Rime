#pragma once

#include "CoreMinimal.h"
#include "SGraphNode.h"



class SEDGraphNode_EntryNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SEDGraphNode_EntryNode) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, class UEDGraphNode_EntryNode* InNode);

	// SNodePanel::SNode interface
	virtual void GetNodeInfoPopups(FNodeInfoContext* Context, TArray<FGraphInformationPopupInfo>& Popups) const override;
	virtual void CreatePinWidgets() override;
	// End of SNodePanel::SNode interface

	// SGraphNode interface
	virtual void UpdateGraphNode() override;
	virtual void AddPin(const TSharedRef<class SGraphPin>& PinToAdd) override;

	// End of SGraphNode interface


protected:
	FSlateColor GetBorderBackgroundColor() const;

	FText GetPreviewCornerText() const;


	TSharedPtr<SHorizontalBox> OutputPinTargetBox;
};
