#pragma once
#include "CoreMinimal.h"
#include "EDGraphNode_Base.h"
#include "EDGraphNode_EntryNode.generated.h"


UCLASS()
class UEDGraphNode_EntryNode : public UEDGraphNode_Base
{
	GENERATED_UCLASS_BODY()

	//~ Begin UEdGraphNode Interface
	virtual void AllocateDefaultPins() override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	virtual FText GetTooltipText() const override;
	virtual void PostPasteNode() override;
	virtual void PostPlacedNewNode() override;
	virtual bool CanUserDeleteNode() const override { return true; }
	virtual bool CanDuplicateNode() const override { return true; }
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	//~ End UEdGraphNode Interface

public:
	UEdGraphPin* GetNextQuestOutPin();
};