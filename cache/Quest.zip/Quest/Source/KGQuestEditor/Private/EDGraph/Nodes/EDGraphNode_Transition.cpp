#include "EDGraphNode_Transition.h"

#include "EdGraphUtilities.h"
#include "K2Node_CommutativeAssociativeBinaryOperator.h"
#include "EdGraph/EdGraphPin.h"
#include "EdGraph/EdGraph.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Widgets/Images/SImage.h"
#include "UObject/UObjectThreadContext.h"
#include "EDGraphNode_StateNode.h"

#define LOCTEXT_NAMESPACE "EDGraphNode_Transition"

UEDGraphNode_Transition::UEDGraphNode_Transition(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer), DelegateOwnerClass(nullptr),
	bEventTriggersTargetedUpdate(true),
	bEventTriggersFullUpdate(false),
	bCanEvaluate_DEPRECATED(true),
	bCanEvaluateFromEvent_DEPRECATED(true), bCanEvalWithStartState_DEPRECATED(true),
	PriorityOrder_DEPRECATED(0),
	bWasEvaluating(false), TimeSinceHover(0), bIsHoveredByUser(false), bFromAnyState(false), bFromLinkState(false)
{
	bCanRenameNode = false;
}

void UEDGraphNode_Transition::CopyFrom(const UEDGraphNode_Transition& Transition)
{
	DelegateOwnerClass = Transition.DelegateOwnerClass;
	DelegatePropertyName = Transition.DelegatePropertyName;
}

void UEDGraphNode_Transition::AllocateDefaultPins()
{
	UEdGraphPin* Inputs = CreatePin(EGPD_Input, TEXT("Transition"), TEXT("In"));
	Inputs->bHidden = true;
	UEdGraphPin* Outputs = CreatePin(EGPD_Output, TEXT("Transition"), TEXT("Out"));
	Outputs->bHidden = true;
}

FText UEDGraphNode_Transition::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return FText::FromString(GetTransitionName());
}

void UEDGraphNode_Transition::PinConnectionListChanged(UEdGraphPin* Pin)
{
	Super::PinConnectionListChanged(Pin);
	if (Pin->LinkedTo.Num() == 0)
	{
		// Commit suicide; transitions must always have an input and output connection
		Modify();

		// Our parent graph will have our graph in SubGraphs so needs to be modified to record that.
		if (UEdGraph* ParentGraph = GetGraph())
		{
			ParentGraph->Modify();
		}

		DestroyNode();
	}
}

void UEDGraphNode_Transition::PostPlacedNewNode()
{
	//UClass* NodeClass = UEDConditionNode::StaticClass();
	//if (NodeClass && (NodeInstance == nullptr))
	//{
	//	UEdGraph* MyGraph = GetGraph();
	//	UObject* GraphOwner = MyGraph ? MyGraph->GetOuter() : nullptr;
	//	if (GraphOwner)
	//	{
	//		NodeInstance = NewObject<UObject>(GraphOwner, NodeClass);
	//		NodeInstance->SetFlags(RF_Transactional);
	//	}
	//}

	CreateBoundGraph();
	SetupDelegateDefaults();

	//if (bGenerateTemplateOnNodePlacement)
	{
		//InitTemplate();
	}
}

void UEDGraphNode_Transition::PrepareForCopying()
{
	Super::PrepareForCopying();
}

void UEDGraphNode_Transition::PostPasteNode()
{
	//if (!BoundGraph)
	//{
	//	CreateBoundGraph();
	//}

	//TArray<UEdGraphNode*> ContainedNodes;
	//FSMBlueprintEditorUtils::GetAllNodesOfClassNested<UEdGraphNode>(BoundGraph, ContainedNodes);

	//for (UEdGraphNode* GraphNode : ContainedNodes)
	//{
	//	GraphNode->CreateNewGuid();
	//	GraphNode->PostPasteNode();
	//	// Required to correct context display issues.
	//	GraphNode->ReconstructNode();
	//}

	Super::PostPasteNode();

	UEdGraphPin* InputPin = GetInputPin();
	UEdGraphPin* OutputPin = GetOutputPin();
	check(InputPin);
	check(OutputPin);

	if (InputPin->LinkedTo.Num() == 0 && OutputPin->LinkedTo.Num() == 0)
	{
		// If this transition is being copied & pasted by itself, look for nodes the user may want to link.

		TArray<UEDGraphNode_Base*> StateNodes;
		StateNodes.Reserve(2);
		//if (FSMBlueprintEditor* BlueprintEditor = FSMBlueprintEditorUtils::GetStateMachineEditor(this))
		//{
		//	const TSet<TWeakObjectPtr<USMGraphNode_Base>>& Selection = BlueprintEditor->GetSelectedGraphNodesDuringPaste();
		//	if (Selection.Num() == 1)
		//	{
		//		if (UEDGraphNode_Transition* Transition = Cast<UEDGraphNode_Transition>(Selection.CreateConstIterator()->Get()))
		//		{
		//			// For a single selected transition add the pasted transition to the stack.
		//			if (UEDGraphNode_Base* FromState = Transition->GetFromState())
		//			{
		//				StateNodes.Add(FromState);
		//			}
		//			if (UEDGraphNode_Base* ToState = Transition->GetToState())
		//			{
		//				StateNodes.Add(ToState);
		//			}
		//		}
		//		else if (UEDGraphNode_Base* State = Cast<UEDGraphNode_Base>(Selection.CreateConstIterator()->Get()))
		//		{
		//			// Single selected state - treat this as a self transition.
		//			StateNodes.Add(State);
		//			StateNodes.Add(State);
		//		}
		//	}
		//	else
		//	{
		//		// Check for multiple selected states.
		//		for (TWeakObjectPtr<USMGraphNode_Base> Object : Selection)
		//		{
		//			if (UEDGraphNode_Base* StateNode = Cast<UEDGraphNode_Base>(Object.Get()))
		//			{
		//				if (StateNodes.Num() == 2)
		//				{
		//					// Only allow two selected state nodes.
		//					StateNodes.Empty();
		//					break;
		//				}

		//				StateNodes.Add(StateNode);
		//			}
		//		}
		//	}
		//}

		if (StateNodes.Num() == 2)
		{
			check(StateNodes[0]);
			check(StateNodes[1]);
			InputPin->MakeLinkTo(StateNodes[0]->GetOutputPin());
			OutputPin->MakeLinkTo(StateNodes[1]->GetInputPin());
		}
	}

	// Destroy this node if there are no valid connections to any states.
	for (UEdGraphPin* Pin : Pins)
	{
		if (Pin->LinkedTo.Num() == 0)
		{
			DestroyNode();
			break;
		}
	}
}

void UEDGraphNode_Transition::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	//const FName PropertyName = PropertyChangedEvent.GetPropertyName();

	//// Enable templates
	//if (PropertyName == GET_MEMBER_NAME_CHECKED(UEDGraphNode_Transition, TransitionClass))
	//{
	//	InitTemplate();
	//}

	//Super::PostEditChangeProperty(PropertyChangedEvent);

	//if (PropertyName == GET_MEMBER_NAME_CHECKED(UEDGraphNode_Transition, DelegatePropertyName))
	//{
	//	InitTransitionDelegate();
	//}
	//else if (PropertyName == GET_MEMBER_NAME_CHECKED(UEDGraphNode_Transition, DelegateOwnerInstance))
	//{
	//	DelegatePropertyName = NAME_None;
	//	DelegateOwnerClass = nullptr;
	//	InitTransitionDelegate();
	//}
	//else if (PropertyName == GET_MEMBER_NAME_CHECKED(UEDGraphNode_Transition, DelegateOwnerClass))
	//{
	//	DelegatePropertyName = NAME_None;
	//	InitTransitionDelegate();
	//}
	//else if (PropertyName == GET_MEMBER_NAME_CHECKED(UEDGraphNode_Transition, bEventTriggersTargetedUpdate) ||
	//	PropertyName == GET_MEMBER_NAME_CHECKED(UEDGraphNode_Transition, bEventTriggersFullUpdate))
	//{
	//	UpdateResultNodeEventSettings();
	//}
}

void UEDGraphNode_Transition::PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}

void UEDGraphNode_Transition::DestroyNode()
{
	Modify();

	UEDGraphNode_Base* State1 = GetFromState();
	UEDGraphNode_Base* State2 = GetToState();
	if (State1 && State1->NodeInstance && IsValid(State1->NodeInstance))
	{
		if (UQuest* Quest1 = Cast<UQuest>(State1->NodeInstance))
		{
			if (State2 && !State2->NodeName.IsEmpty())
			{
				// ToState指向的节点可能已经被销毁, 不一定有NodeInstance, 这里用NodeName来查询
				URingTaskConditionBase* SelectNode = nullptr;
				for (URingTaskConditionBase* NextTaskCon : Quest1->NextTaskInfoList)
				{
					if (IsValid(NextTaskCon) && State2->NodeName.StartsWith(FString::FromInt(NextTaskCon->NextTaskID)))
					{
						SelectNode = NextTaskCon;
						break;
					}
				}
				if (SelectNode)
				{
					Quest1->Modify();
					Quest1->NextTaskInfoList.Remove(SelectNode);
					// todo LuaVersion
					UPackage* QuestDataPackage = Quest1->GetPackage();
					if (QuestDataPackage) QuestDataPackage->SetDirtyFlag(true);
					Quest1->NextTaskInfoNotifyQuestEditor();
				}
			}
		}
		else if (UQuestRing* Ring = Cast<UQuestRing>(State1->NodeInstance))
		{
			if (State2 && !State2->NodeName.IsEmpty())
			{
				// ToState指向的节点可能已经被销毁, 不一定有NodeInstance, 这里用NodeName来查询
				URingTaskConditionBase* SelectNode = nullptr;
				for (URingTaskConditionBase* NextTaskCon : Ring->NextTaskInfoList)
				{
					if (IsValid(NextTaskCon) && State2->NodeName.StartsWith(FString::FromInt(NextTaskCon->NextTaskID)))
					{
						SelectNode = NextTaskCon;
						break;
					}
				}
				if (SelectNode)
				{
					Ring->Modify();
					Ring->NextTaskInfoList.Remove(SelectNode);
					// todo LuaVersion
					UPackage* QuestDataPackage = Ring->GetPackage();
					if (QuestDataPackage) QuestDataPackage->SetDirtyFlag(true);
					Ring->NextTaskInfoNotifyQuestEditor();
				}
			}
		}
	}

	/*UEDGraphNode_Base* State1 = GetFromState();
	if (State1 && State1->NodeInstance && IsValid(State1->NodeInstance))
	{
		if (UQuest* Quest = Cast<UQuest>(State1->NodeInstance))
		{
			if (!NodeInstance)
			{
				Quest->NextTaskInfoList.Remove(Cast<URingTaskConditionBase>(NodeInstance.Get()));
			}
		}
	}*/

	Super::DestroyNode();
}

void UEDGraphNode_Transition::ReconstructNode()
{
	Super::ReconstructNode();
	RefreshTransitionDelegate();
}

UObject* UEDGraphNode_Transition::GetJumpTargetForDoubleClick() const
{
	return Super::GetJumpTargetForDoubleClick();
}

void UEDGraphNode_Transition::ResetDebugState()
{
	
}

void UEDGraphNode_Transition::UpdateTime(float DeltaTime)
{
	
}

void UEDGraphNode_Transition::ImportDeprecatedProperties()
{
	//Super::ImportDeprecatedProperties();
}

void UEDGraphNode_Transition::PlaceDefaultInstanceNodes()
{
	//Super::PlaceDefaultInstanceNodes();
}

FLinearColor UEDGraphNode_Transition::GetBackgroundColor() const
{
	return Super::GetBackgroundColor();
}

FLinearColor UEDGraphNode_Transition::GetActiveBackgroundColor() const
{
	return FLinearColor::Blue;
}

void UEDGraphNode_Transition::SetNodeClass(UClass* Class)
{
	//Super::SetNodeClass(Class);
}

float UEDGraphNode_Transition::GetMaxDebugTime() const
{
	return 0.0f;
}

//void UEDGraphNode_Transition::PreCompile(FSMKismetCompilerContext& CompilerContext)
//{
//	Super::PreCompile(CompilerContext);
//
//	//if (!DelegatePropertyName.IsNone())
//	//{
//	//	if (UClass* DelegateClass = GetSelectedDelegateOwnerClass())
//	//	{
//	//		if (DelegateClass->FindPropertyByName(DelegatePropertyName) == nullptr)
//	//		{
//	//			// The delegate cannot be found, check to see if it was renamed.
//
//	//			if (USMGraphK2Node_FunctionNode_TransitionEvent* TransitionEvent = FSMBlueprintEditorUtils::GetFirstNodeOfClassNested<USMGraphK2Node_FunctionNode_TransitionEvent>(BoundGraph))
//	//			{
//	//				UBlueprint* Blueprint = FSMBlueprintEditorUtils::FindBlueprintForNodeChecked(this);
//	//				bool bRequiresDelegateRefresh = false;
//
//	//				FString NewDelegateName;
//	//				if (FProperty* RemappedProperty = FSMBlueprintEditorUtils::GetPropertyForVariable(Blueprint, DelegatePropertyName))
//	//				{
//	//					NewDelegateName = RemappedProperty->GetName();
//	//				}
//	//				else if (UFunction* Function = TransitionEvent->GetDelegateFunction())
//	//				{
//	//					NewDelegateName = Function->GetName();
//	//					NewDelegateName.RemoveFromEnd(TEXT("__DelegateSignature"));
//	//				}
//	//				else if (DelegatePropertyGuid.IsValid())
//	//				{
//	//					// Attempt a guid lookup if there is one saved. This can happen if the variable was renamed once,
//	//					// but this owning blueprint wasn't saved, and the variable was renamed again.
//
//	//					FBPVariableDescription VariableDescription;
//	//					if (FSMBlueprintEditorUtils::TryGetVariableByGuid(Blueprint, DelegatePropertyGuid, VariableDescription))
//	//					{
//	//						NewDelegateName = VariableDescription.VarName.ToString();
//	//						bRequiresDelegateRefresh = true;
//	//					}
//	//				}
//
//	//				if (!NewDelegateName.IsEmpty())
//	//				{
//	//					const FString OldDelegateName = DelegatePropertyName.ToString();
//
//	//					DelegatePropertyName = *NewDelegateName;
//	//					TransitionEvent->DelegatePropertyName = *NewDelegateName;
//
//	//					if (OldDelegateName != NewDelegateName)
//	//					{
//	//						// NewDelegateName cannot be refreshed on first compile in some situations, only display the message when it's been updated.
//
//	//						FText const InfoFormat = LOCTEXT("EventDelegateRename", "Event delegate '{0}' has been renamed to '{1}' on transition @@.");
//	//						CompilerContext.MessageLog.Note(*FText::Format(InfoFormat, FText::FromString(OldDelegateName), FText::FromString(NewDelegateName)).ToString(), this);
//	//					}
//
//	//					if (bRequiresDelegateRefresh)
//	//					{
//	//						RefreshTransitionDelegate();
//	//					}
//
//	//					return;
//	//				}
//	//			}
//
//	//			CompilerContext.MessageLog.Error(TEXT("Delegate property not found for transition @@."), this);
//	//		}
//	//		else
//	//		{
//	//			RefreshTransitionDelegate();
//	//		}
//	//	}
//	//}
//}
//
//void UEDGraphNode_Transition::OnCompile(FSMKismetCompilerContext& CompilerContext)
//{
//	Super::OnCompile(CompilerContext);
//}

const FSlateBrush* UEDGraphNode_Transition::GetNodeIcon() const
{
	if (const FSlateBrush* Icon = Super::GetNodeIcon())
	{
		return Icon;
	}

	return FAppStyle::Get().GetBrush(TEXT("Graph.TransitionNode.Icon"));
}

void UEDGraphNode_Transition::CreateBoundGraph()
{
	//// Create a new state machine graph
	//check(BoundGraph == NULL);
	//BoundGraph = FBlueprintEditorUtils::CreateNewGraph(
	//	this,
	//	NAME_None,
	//	USMTransitionGraph::StaticClass(),
	//	USMTransitionGraphSchema::StaticClass());
	//check(BoundGraph);

	//// Find an interesting name
	//FEdGraphUtilities::RenameGraphToNameOrCloseToName(BoundGraph, GetTransitionName());

	//// Initialize the state machine graph
	//const UEdGraphSchema* Schema = BoundGraph->GetSchema();
	//Schema->CreateDefaultNodesForGraph(*BoundGraph);

	//// Add the new graph as a child of our parent graph
	//UEdGraph* ParentGraph = GetGraph();

	//if (ParentGraph->SubGraphs.Find(BoundGraph) == INDEX_NONE)
	//{
	//	ParentGraph->Modify();
	//	ParentGraph->SubGraphs.Add(BoundGraph);
	//}
}

void UEDGraphNode_Transition::SetBoundGraph(UEdGraph* Graph)
{
}

FLinearColor UEDGraphNode_Transition::GetTransitionColor(bool bIsHovered) const
{
	return GetBackgroundColor();
}

const FSlateBrush* UEDGraphNode_Transition::GetTransitionIcon(int32 InIndex)
{
	if (InIndex < 0)
	{
		return GetNodeIcon();
	}

	return nullptr;
}

UClass* UEDGraphNode_Transition::GetSelectedDelegateOwnerClass() const
{
	return DelegateOwnerClass;
}

void UEDGraphNode_Transition::GoToTransitionEventNode()
{

}

void UEDGraphNode_Transition::InitTransitionDelegate()
{

}

FString UEDGraphNode_Transition::GetDisplayName()
{
	FString DisplayName;

	if (NodeType == EDNodeType::RingQuestCondition)
	{
		if (URingTaskConditionBase* Cond = Cast<URingTaskConditionBase>(NodeInstance))
		{
			return Cond->DisplayName;
		}
	}

	return DisplayName;
}

void UEDGraphNode_Transition::SetupDelegateDefaults()
{

}

void UEDGraphNode_Transition::RefreshTransitionDelegate()
{
	DelegatePropertyGuid.Invalidate();

	if (DelegatePropertyName.IsNone())
	{
		return;
	}
}

void UEDGraphNode_Transition::UpdateTransitionDelegateGuid()
{
	DelegatePropertyGuid.Invalidate();
}

void UEDGraphNode_Transition::UpdateResultNodeEventSettings()
{
}

FString UEDGraphNode_Transition::GetTransitionName() const
{
	UEDGraphNode_Base* State1 = GetFromState();
	UEDGraphNode_Base* State2 = GetToState();

	const FString State1Name =  "StartState";
	const FString State2Name =  "EndState";

	return FString::Printf(TEXT("%s to %s"), *State1Name, *State2Name);
}

void UEDGraphNode_Transition::CreateConnections(UEDGraphNode_Base* Start, UEDGraphNode_Base* End)
{
	Pins[0]->Modify();
	Pins[0]->LinkedTo.Empty();

	Start->GetOutputPin()->Modify();
	Pins[0]->MakeLinkTo(Start->GetOutputPin());

	// This to next
	Pins[1]->Modify();
	Pins[1]->LinkedTo.Empty();

	End->GetInputPin()->Modify();
	Pins[1]->MakeLinkTo(End->GetInputPin());

	SetDefaultsWhenPlaced();
}

void UEDGraphNode_Transition::CreateConnections(UEdGraphPin* Start, UEdGraphPin* End)
{
	Pins[0]->Modify();
	Pins[0]->LinkedTo.Empty();

	Start->Modify();
	Pins[0]->MakeLinkTo(Start);

	// This to next
	Pins[1]->Modify();
	Pins[1]->LinkedTo.Empty();

	End->Modify();
	Pins[1]->MakeLinkTo(End);

	SetDefaultsWhenPlaced();
}

bool UEDGraphNode_Transition::PossibleToTransition() const
{
	return false;
}

UEDGraphNode_Base* UEDGraphNode_Transition::GetFromState() const
{
	if (Pins.Num() && Pins[0]->LinkedTo.Num() > 0)
	{
		return Cast<UEDGraphNode_Base>(Pins[0]->LinkedTo[0]->GetOwningNode());
	}

	return nullptr;
}

UEDGraphNode_Base* UEDGraphNode_Transition::GetToState() const
{
	if (Pins.Num() > 1 && Pins[1]->LinkedTo.Num() > 0)
	{
		return Cast<UEDGraphNode_Base>(Pins[1]->LinkedTo[0]->GetOwningNode());
	}

	return nullptr;
}

bool UEDGraphNode_Transition::ShouldRunParallel() const
{
	return false;
}

bool UEDGraphNode_Transition::IsFromAnyState() const
{
	return bFromAnyState;
}

bool UEDGraphNode_Transition::IsFromLinkState() const
{
	return bFromLinkState;
}

UEdGraphPin* UEDGraphNode_Transition::GetLinearExpressionPin() const
{
	return nullptr;
}

FLinearColor UEDGraphNode_Transition::Internal_GetBackgroundColor() const
{
	return FLinearColor::Blue;
}

void UEDGraphNode_Transition::SetDefaultsWhenPlaced()
{
}

#undef LOCTEXT_NAMESPACE

