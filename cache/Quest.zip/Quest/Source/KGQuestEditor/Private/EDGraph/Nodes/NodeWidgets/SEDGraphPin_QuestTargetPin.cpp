#include "SEDGraphPin_QuestTargetPin.h"

#include "Editor/Kismet/Private/BPFunctionDragDropAction.h"

const FLinearColor SEDGraphPin_QuestTargetPin_Hover(1.0f, 0.7f, 0.0f);
const FLinearColor SEDGraphPin_QuestTargetPin_Default(1.0f, 1.0f, 1.0f);

FReply SEDGraphPin_QuestTargetPin::OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	// Function drag drops will attempt to wire through a k2 schema which will crash since this isn't for a k2 schema.
	TSharedPtr<FKismetFunctionDragDropAction> FunctionDragDrop = DragDropEvent.GetOperationAs<FKismetFunctionDragDropAction>();
	if (FunctionDragDrop.IsValid())
	{
		return FReply::Handled();
	}

	return SGraphPin::OnDrop(MyGeometry, DragDropEvent);
}

FSlateColor SEDGraphPin_QuestTargetPin::GetPinColor() const
{
	return FSlateColor(IsHovered() ? FLinearColor::Yellow : FLinearColor::Black);
}