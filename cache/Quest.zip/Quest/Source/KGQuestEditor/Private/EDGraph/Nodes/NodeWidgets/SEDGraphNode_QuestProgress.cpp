#include "SEDGraphNode_QuestProgress.h"


#include "SLevelOfDetailBranchNode.h"
#include "SCommentBubble.h"
#include "SlateOptMacros.h"
#include "SGraphPin.h"
#include "Components/VerticalBox.h"
#include "SGraphPreviewer.h"
#include "GraphEditorSettings.h"
#include "Templates/SharedPointer.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/SToolTip.h"
#include "Widgets/SWidget.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Kismet2/KismetEditorUtilities.h"


#include "../EDGraphNode_StateNode.h"
#include "SEDGraphPin_StatePin.h"
#include "SEDGraphPin_QuestTargetPin.h"
#include "Widgets/Layout/SBox.h"

#define LOCTEXT_NAMESPACE "SEDGraphNode_QuestProgress"

void SEDGraphNode_QuestProgress::Construct(const FArguments& InArgs, UEDGraphNode_StateNodeBase* InNode)
{
	SEDGraphNode_BaseNode::Construct(SEDGraphNode_BaseNode::FArguments(), InNode);
	ContentPadding = InArgs._ContentPadding;
	TitleName = InNode->NodeName;
	//CastChecked<UEDGraphNode_Base>(GraphNode)->OnWidgetConstruct();
	SetCursor(EMouseCursor::CardinalCross);
	UpdateGraphNode();
	
}

void SEDGraphNode_QuestProgress::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SGraphNode::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
}

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void SEDGraphNode_QuestProgress::UpdateGraphNode()
{
	InputPins.Empty();
	OutputPins.Empty();

	// Reset variables that are going to be exposed, in case we are refreshing an already setup node.
	RightNodeBox.Reset();
	LeftNodeBox.Reset();
	OutputPinBox.Reset();

	const FLinearColor TitleShadowColor(0.6f, 0.6f, 0.6f);

	const FLinearColor TargetPinColor(1.0f, 0.0f, 0.0f);

	SetupErrorReporting();
	TSharedPtr<SErrorText> ErrorText;
	const TSharedPtr<SWidget> ContentBox = CreateContentBox();
	const TAttribute<const FSlateBrush*> SelectedBrush = TAttribute<const FSlateBrush*>::Create(TAttribute<const FSlateBrush*>::FGetter::CreateSP(this, &SEDGraphNode_QuestProgress::GetNameIcon));

	const FMargin NodePadding = FMargin(20.0f);

	this->ContentScale.Bind(this, &SGraphNode::GetContentScale);

	UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(GraphNode);

	if (EDNode && EDNode->NodeType == EDNodeType::QuestProgress)
	{
		this->GetOrAddSlot(ENodeZone::Center)
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Center)
			[
				SNew(SBorder)
					.BorderImage(FAppStyle::GetBrush("Graph.StateNode.Body"))
					.Padding(0.0f)
					.BorderBackgroundColor(this, &SEDGraphNode_QuestProgress::GetBorderBackgroundColor)
					.OnMouseButtonDown(this, &SEDGraphNode_QuestProgress::OnMouseDown)
					[
						SNew(SVerticalBox)

							+ SVerticalBox::Slot()
							.HAlign(HAlign_Fill)
							.VAlign(VAlign_Fill)
							[
								SNew(SHorizontalBox)
									+ SHorizontalBox::Slot()
									.MaxWidth(20)
									.Padding(FMargin(0, 10.0f, 0, 0.0f))
									[
										SAssignNew(LeftNodeBox, SVerticalBox)
									]

									+ SHorizontalBox::Slot()
									.Padding(FMargin(0, 10.0f, 60, 0.0f))
									[
										

										SNew(SVerticalBox)

											+ SVerticalBox::Slot()
											.AutoHeight()
											[
												SNew(SBorder)
													.BorderImage(FAppStyle::Get().GetBrush("Graph.StateNode.ColorSpill"))
													.BorderBackgroundColor(TitleShadowColor)
													.HAlign(HAlign_Left)
													.VAlign(VAlign_Center)
													[
														SNew(SHorizontalBox)
															+ SHorizontalBox::Slot()
															.AutoWidth()
															.VAlign(VAlign_Center)
															[
																SNew(SImage)
																	.Image(SelectedBrush)
															]
															+ SHorizontalBox::Slot()
															//.Padding(ContentPadding)
															[
																ContentBox.ToSharedRef()
															]

															//+ SHorizontalBox::Slot()
															//[
															//	SNew(STextBlock)
															//		.ColorAndOpacity(FLinearColor(1, 1, 1, 1))
															//		.Text(FText::FromString("InProgress"))
															//]
													]
											]
									]

									+ SHorizontalBox::Slot()
									.MaxWidth(20)
									.Padding(0.0f, 10.0f)
									[
										SAssignNew(OutputPinBox, SHorizontalBox)
									]
							]

							+ SVerticalBox::Slot()
							.AutoHeight()
							[
								SNew(SBox)
									.MinDesiredHeight(NodePadding.Bottom)
									[
										SAssignNew(RightNodeBox, SVerticalBox)
											+ SVerticalBox::Slot()
											.HAlign(HAlign_Fill)
											.VAlign(VAlign_Fill)
											.Padding(20.0f, 0.0f)
											.FillHeight(1.0f)
											[
												SAssignNew(OutputPinTargetBox, SHorizontalBox)
											]
									]
							]
					]
			];
	}
	else if(EDNode && EDNode->NodeType == EDNodeType::QuestEnd)
	{
		this->GetOrAddSlot(ENodeZone::Center)
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Center)
			[
				SNew(SBorder)
					.BorderImage(FAppStyle::GetBrush("Graph.StateNode.Body"))
					.Padding(0.0f)
					.BorderBackgroundColor(this, &SEDGraphNode_QuestProgress::GetBorderBackgroundColor)
					.OnMouseButtonDown(this, &SEDGraphNode_QuestProgress::OnMouseDown)
					[
						SNew(SHorizontalBox)

							+ SHorizontalBox::Slot()
							.HAlign(HAlign_Fill)
							.VAlign(VAlign_Fill)
							[
								SNew(SHorizontalBox)
									+ SHorizontalBox::Slot()
									.Padding(FMargin(0, 10.0f, 20, 10.0f))
									[
										SNew(SHorizontalBox)

											+ SHorizontalBox::Slot()
											.MaxWidth(20)
											[
												SAssignNew(LeftNodeBox, SVerticalBox)
											]

											+ SHorizontalBox::Slot()
											[
												SNew(SBorder)
													.BorderImage(FAppStyle::Get().GetBrush("Graph.StateNode.ColorSpill"))
													.BorderBackgroundColor(TitleShadowColor)
													.HAlign(HAlign_Fill)
													.VAlign(VAlign_Center)
													.Padding(FMargin(0, 0.0f, 0, 0.0f))
													[
														SNew(SHorizontalBox)
															//+ SHorizontalBox::Slot()
															//.AutoWidth()
															//.VAlign(VAlign_Center)
															//[
															//	SNew(SImage)
															//		.Image(SelectedBrush)

															//]
															//+ SHorizontalBox::Slot()
															////.Padding(ContentPadding)
															//[
															//	ContentBox.ToSharedRef()
															//]
															+ SHorizontalBox::Slot()
															[
																SNew(STextBlock)
																	.ColorAndOpacity(FLinearColor(1, 1, 1, 1))
																	.Text(FText::FromString("End"))
															]
													]
											]
									]
							]

							+ SHorizontalBox::Slot()
							.AutoWidth()
							[
								SNew(SVerticalBox)
									+ SVerticalBox::Slot()
									[
										SNew(SVerticalBox)
										+ SVerticalBox::Slot()
										[
											SNew(STextBlock)
												.ColorAndOpacity(FLinearColor::Green)
												.Text(FText::FromString("Success"))
										]

										+ SVerticalBox::Slot()
										[
											SAssignNew(OutputPinBox, SHorizontalBox)
										]
									]

									+ SVerticalBox::Slot()
									[
										SAssignNew(RightNodeBox, SVerticalBox)
											+SVerticalBox::Slot()
											[
												SNew(STextBlock)
													.ColorAndOpacity(FLinearColor::Red)
													.Text(FText::FromString("Failed"))
											]

											+ SVerticalBox::Slot()
											//.HAlign(HAlign_Fill)
											//.VAlign(VAlign_Fill)
											//.Padding(0.0f, 0.0f)
											//.FillHeight(1.0f)
											[
												SAssignNew(OutputPinTargetBox, SHorizontalBox)
											]
									]
							]
					]
			];
	}


	// Create comment bubble
	TSharedPtr<SCommentBubble> CommentBubble;
	const FSlateColor CommentColor = FLinearColor(1,1,1,1);

	SAssignNew(CommentBubble, SCommentBubble)
		.GraphNode(GraphNode)
		.Text(this, &SGraphNode::GetNodeComment)
		.OnTextCommitted(this, &SGraphNode::OnCommentTextCommitted)
		.ColorAndOpacity(CommentColor)
		.AllowPinning(true)
		.EnableTitleBarBubble(true)
		.EnableBubbleCtrls(true)
		.GraphLOD(this, &SGraphNode::GetCurrentLOD)
		.IsGraphNodeHovered(this, &SGraphNode::IsHovered);

	GetOrAddSlot(ENodeZone::TopCenter)
		.SlotOffset(TAttribute<FVector2D>(CommentBubble.Get(), &SCommentBubble::GetOffset))
		.SlotSize(TAttribute<FVector2D>(CommentBubble.Get(), &SCommentBubble::GetSize))
		.AllowScaling(TAttribute<bool>(CommentBubble.Get(), &SCommentBubble::IsScalingAllowed))
		.VAlign(VAlign_Top)
		[
			CommentBubble.ToSharedRef()
		];

	//ErrorReporting = ErrorText;
	//ErrorReporting->SetError(ErrorMsg);
	CreatePinWidgets();

	CalculateAnyStateImpact();
	CalculateLinkStateImpact();
}
END_SLATE_FUNCTION_BUILD_OPTIMIZATION

void SEDGraphNode_QuestProgress::CreatePinWidgets()
{
	const UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);



	UEdGraphPin* PinToUse = StateNode->GetOutputPin();

	PinToUse = StateNode->GetInputPin();

	if (PinToUse && !PinToUse->bHidden)
	{
		const TSharedPtr<SGraphPin> NewPin = SNew(SEDGraphPin_QuestTargetPin, PinToUse);
		this->AddPin(NewPin.ToSharedRef());
	}

	for (UEdGraphPin* Pin : StateNode->Pins)
	{
		if (Pin->Direction == EEdGraphPinDirection::EGPD_Output)
		{
			switch (StateNode->NodeType)
			{
			case EDNodeType::QuestProgress:
				if (Pin->PinName == "Out2")
				{
					const TSharedPtr<SGraphPin> NewPin = SNew(SEDGraphPin_QuestTargetPin, Pin).Padding(FMargin(40.0f, 10));
					this->AddPin(NewPin.ToSharedRef());
				}
				else
				{
					const TSharedPtr<SGraphPin> NewPin = SNew(SEDGraphPin_QuestTargetPin, Pin).Padding(FMargin(40.0f, 20));
					this->AddPin(NewPin.ToSharedRef());
				}
				break;
			case EDNodeType::QuestEnd:
				if (Pin->PinName == "Out2")
				{
					const TSharedPtr<SGraphPin> NewPin = SNew(SEDGraphPin_QuestTargetPin, Pin).Padding(FMargin(40.0f, 5, 0, 20));
					this->AddPin(NewPin.ToSharedRef());
				}
				else
				{
					const TSharedPtr<SGraphPin> NewPin = SNew(SEDGraphPin_QuestTargetPin, Pin).Padding(FMargin(40.0f, 5, 0, 20));
					this->AddPin(NewPin.ToSharedRef());
				}
				break;
			}
			


		}
	}

}

void SEDGraphNode_QuestProgress::AddPin(const TSharedRef<SGraphPin>& PinToAdd)
{
	PinToAdd->SetOwner(SharedThis(this));

	if (PinToAdd->GetDirection() == EEdGraphPinDirection::EGPD_Input)
	{
		LeftNodeBox->AddSlot()
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Fill)
			.FillHeight(1.0f)
			//.Padding(0.0f, 10.0f, 0, 0)
			[
				PinToAdd
			];
		InputPins.Add(PinToAdd);
	}
	else // Direction == EEdGraphPinDirection::EGPD_Output
	{
		if (PinToAdd->GetPinObj() && PinToAdd->GetPinObj()->PinName == "Out2")
		{
			OutputPinTargetBox->AddSlot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				.FillWidth(1.0f)
				[
					PinToAdd
				];
		}
		else
		{
			OutputPinBox->AddSlot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				.FillWidth(1.0f)
				[
					PinToAdd
				];
		}
		OutputPins.Add(PinToAdd);
	}
}

TSharedPtr<SToolTip> SEDGraphNode_QuestProgress::GetComplexTooltip()
{
	/* Display a pop-up on mouse hover with useful information. */
	const TSharedPtr<SVerticalBox> Widget = BuildComplexTooltip();

	return SNew(SToolTip)
		[
			Widget.ToSharedRef()
		];
}

TArray<FOverlayWidgetInfo> SEDGraphNode_QuestProgress::GetOverlayWidgets(bool bSelected, const FVector2D& WidgetSize) const
{
	TArray<FOverlayWidgetInfo> Widgets;

	return Widgets;
}

FReply SEDGraphNode_QuestProgress::OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	return SGraphNode::OnMouseButtonDoubleClick(InMyGeometry, InMouseEvent);
}

void SEDGraphNode_QuestProgress::RequestRenameOnSpawn()
{
	SGraphNode::RequestRenameOnSpawn();
}

FReply SEDGraphNode_QuestProgress::OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	return FReply::Handled();
}

FReply SEDGraphNode_QuestProgress::OnMouseDown(const FGeometry& SenderGeometry, const FPointerEvent& MouseEvent)
{
	UEDGraphNode_StateNodeBase* TestNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode);

	return FReply::Unhandled();
}

TSharedPtr<SVerticalBox> SEDGraphNode_QuestProgress::BuildComplexTooltip()
{
	UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);

	const bool bCanExecute = StateNode->HasInputConnections();
	const bool bIsEndState = StateNode->IsEndState(false);
	bool bIsAnyState = false;

	const FSlateBrush* FastPathImageBrush = FAppStyle::Get().GetBrush(TEXT("Graph.StateNode.Icon"));

	TSharedPtr<SVerticalBox> Widget = SNew(SVerticalBox);
	Widget->AddSlot()
		.AutoHeight()
		.Padding(FMargin(0.f, 0.f, 0.f, 4.f))
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(STextBlock)
			.TextStyle(FAppStyle::Get(), "Graph.StateNode.Icon")
		.Text(FText::Format(LOCTEXT("StatePopupTitle", "{0} ({1})"), FText::FromString(StateNode->GetStateName()), FText::FromString(FString(""))))
		]
	+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(0.f, -4.f, 0.f, 0.f)
		[
			SNew(SImage)
			.Image(FastPathImageBrush)
		.Visibility_Lambda([StateNode]()
			{
				return StateNode ? EVisibility::Visible : EVisibility::Collapsed;
			})
		]
		];

	if (UEdGraph* Graph = GetGraphToUseForTooltip())
	{
		Widget->AddSlot()
			.AutoHeight()
			[
				SNew(SGraphPreviewer, Graph)
				.ShowGraphStateOverlay(false)
			];
	}
	if (!bCanExecute && !bIsAnyState)
	{
		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(2.f, 4.f, 2.f, 2.f))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "Graph.StateNode.Icon")
			.Text(LOCTEXT("StateCantExecuteTooltip", "No Valid Input: State will never execute"))
			];
	}

	if (bIsEndState)
	{
		const FText EndStateTooltip = StateNode->IsEndState(true) ? LOCTEXT("EndStateTooltip", "End State: State will never exit") :
			LOCTEXT("NotEndStateTooltip", "Not an End State: An Any State node is adding transitions to this node");

		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(2.f, 4.f, 2.f, 2.f))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "Graph.StateNode.Icon")
			.Text(EndStateTooltip)
			];
	}
	else if (true)
	{
		Widget->AddSlot()
			.AutoHeight()
			.Padding(FMargin(10.f, 4.f, 2.f, 2.f))
			[
				SNew(STextBlock)
				.TextStyle(FAppStyle::Get(), "Graph.StateNode.Icon")
			.Text(LOCTEXT("AnyStateImpactTooltip", "An Any State node is adding transitions to this node"))
			];
	}

	return Widget;
}

UEdGraph* SEDGraphNode_QuestProgress::GetGraphToUseForTooltip() const
{
	//const UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	//return StateNode->GetBoundGraph();

	return nullptr;
}

void SEDGraphNode_QuestProgress::CalculateAnyStateImpact()
{
	//AnyStateImpactWidgets.Reset();

	//const UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	//TArray<USMGraphNode_AnyStateNode*> AnyStates;

	//const USMEditorSettings* EditorSettings = FSMBlueprintEditorUtils::GetEditorSettings();
	//if (EditorSettings->MaxAnyStateIcons > 0 && FSMBlueprintEditorUtils::IsNodeImpactedFromAnyStateNode(StateNode, &AnyStates))
	//{
	//	// Sort first so similar colors are grouped. Luminance seems to provide quickest and best results.
	//	AnyStates.Sort([](const USMGraphNode_AnyStateNode& AnyStateA, const USMGraphNode_AnyStateNode& AnyStateB)
	//		{
	//			return AnyStateA.GetAnyStateColor().GetLuminance() >= AnyStateB.GetAnyStateColor().GetLuminance();
	//		});

	//	int32 ColorsOverLimit = 1;
	//	for (int32 AnyStateIdx = 0; AnyStateIdx < AnyStates.Num(); ++AnyStateIdx)
	//	{
	//		const USMGraphNode_AnyStateNode* AnyState = AnyStates[AnyStateIdx];
	//		const bool bIsGrouped = AnyStateIdx >= EditorSettings->MaxAnyStateIcons;
	//		const bool bIsLastIteration = AnyStateIdx == AnyStates.Num() - 1;

	//		FLinearColor AnyStateColor = AnyState->GetAnyStateColor();

	//		if (bIsGrouped)
	//		{
	//			ColorsOverLimit++;
	//			if (!bIsLastIteration)
	//			{
	//				// Skip until end.
	//				continue;
	//			}
	//		}

	//		FText TooltipText;

	//		if (bIsGrouped)
	//		{
	//			// Replace the last one with the grouped widget.
	//			AnyStateImpactWidgets.RemoveAt(0);

	//			TooltipText = FText::FromString(FString::Printf(TEXT("An additional %s Any State nodes are adding transitions to this node."),
	//				*FString::FromInt(ColorsOverLimit)));

	//			AnyStateColor = FLinearColor::White;
	//		}
	//		else
	//		{
	//			// Display individual any state.
	//			TooltipText = FText::FromString(FString::Printf(TEXT("The Any State node '%s' is adding one or more transitions to this state."),
	//				*AnyState->GetStateName()));
	//		}

	//		AnyStateColor.A = 0.72f;

	//		const FSlateBrush* ImageBrush = FAppStyle::Get()->GetBrush(TEXT("SMGraph.AnyState"));
	//		TSharedPtr<SWidget> Widget =
	//			SNew(SBorder)
	//			.BorderImage(FAppStyle::Get().GetBrush("NoBorder"))
	//			.Cursor(bIsGrouped ? EMouseCursor::Default : EMouseCursor::Hand)
	//			.Padding(0.f)
	//			.VAlign(VAlign_Center)
	//			.OnMouseDoubleClick_Lambda([AnyState, bIsGrouped](const FGeometry&, const FPointerEvent&)
	//				{
	//					if (!bIsGrouped && AnyState)
	//					{
	//						FKismetEditorUtilities::BringKismetToFocusAttentionOnObject(AnyState);
	//					}
	//					return FReply::Handled();
	//				})
	//			[
	//				SNew(SOverlay)
	//				+ SOverlay::Slot()
	//					.VAlign(VAlign_Center)
	//					[
	//						SNew(SImage)
	//						.Image(ImageBrush)
	//					.ToolTipText(TooltipText)
	//					.ColorAndOpacity(AnyStateColor)
	//					.Visibility(EVisibility::Visible)
	//					]
	//				+ SOverlay::Slot()
	//					.VAlign(VAlign_Center)
	//					.HAlign(HAlign_Center)
	//					[
	//						SNew(STextBlock)
	//						.Visibility(bIsGrouped ? EVisibility::HitTestInvisible : EVisibility::Collapsed)
	//					.Text(FText::FromString(FString::FromInt(ColorsOverLimit)))
	//					.Font(FCoreStyle::GetDefaultFontStyle("Regular", 8))
	//					.ColorAndOpacity(FLinearColor::Black)
	//					]
	//			];

	//				AnyStateImpactWidgets.Insert(Widget, 0);
	//	}
	//}
}

void SEDGraphNode_QuestProgress::CalculateLinkStateImpact()
{
	//LinkStateImpactWidget.Reset();

	//const UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);

	//const bool bIsLinkState = StateNode->IsA<USMGraphNode_LinkStateNode>();
	//const bool bHasLinkedStates = StateNode->GetLinkedStates().Num() > 0;

	//if (bIsLinkState || bHasLinkedStates)
	//{
	//	FText TooltipText;

	//	if (bIsLinkState)
	//	{
	//		TooltipText = LOCTEXT("LinkState_Tooltip", "This node is a proxy for another state in the graph.");
	//	}
	//	else if (bHasLinkedStates)
	//	{
	//		TooltipText = LOCTEXT("LinkByStates_Tooltip", "This node is linked to from one or more proxy states in the graph.");
	//	}

	//	const FSlateBrush* ImageBrush = FAppStyle::Get()->GetBrush(TEXT("SMGraph.LinkState"));
	//	SAssignNew(LinkStateImpactWidget, SBorder)
	//		.BorderImage(FAppStyle::Get().GetBrush("NoBorder"))
	//		.Cursor(EMouseCursor::Hand)
	//		.Padding(0.f)
	//		.VAlign(VAlign_Center)
	//		.OnMouseDoubleClick_Lambda([bIsLinkState, bHasLinkedStates, StateNode](const FGeometry&, const FPointerEvent&)
	//			{
	//				if (bIsLinkState)
	//				{
	//					FKismetEditorUtilities::BringKismetToFocusAttentionOnObject(CastChecked<USMGraphNode_LinkStateNode>(StateNode)->GetLinkedState());
	//				}
	//				else if (bHasLinkedStates)
	//				{
	//					const TSet<USMGraphNode_LinkStateNode*>& LinkedStates = StateNode->GetLinkedStates();
	//					if (LinkedStates.Num() == 1)
	//					{
	//						FKismetEditorUtilities::BringKismetToFocusAttentionOnObject(*LinkedStates.CreateConstIterator());
	//					}
	//					else
	//					{
	//						if (FSMBlueprintEditor* Editor = FSMBlueprintEditorUtils::GetStateMachineEditor(StateNode))
	//						{
	//							Editor->SelectNodes(reinterpret_cast<const TSet<UEdGraphNode*>&>(LinkedStates), true);
	//						}
	//					}
	//				}
	//				return FReply::Handled();
	//			})
	//		[
	//			SNew(SOverlay)
	//			+ SOverlay::Slot()
	//				.VAlign(VAlign_Center)
	//				[
	//					SNew(SImage)
	//					.Image(ImageBrush)
	//				.ToolTipText(TooltipText)
	//				.Visibility(EVisibility::Visible)
	//				]
	//		];
	//}
}

void SEDGraphNode_QuestProgress::GetNodeInfoPopups(FNodeInfoContext* Context,
	TArray<FGraphInformationPopupInfo>& Popups) const
{
}

void SEDGraphNode_QuestProgress::OnRefreshRequested(UEDGraphNode_Base* InNode, bool bFullRefresh)
{
	CalculateAnyStateImpact();
	CalculateLinkStateImpact();

	SEDGraphNode_BaseNode::OnRefreshRequested(InNode, bFullRefresh);
}

TSharedPtr<SWidget> SEDGraphNode_QuestProgress::CreateContentBox()
{
	TSharedPtr<SVerticalBox> Content;
	TSharedPtr<SNodeTitle> NodeTitle = SNew(SNodeTitle, GraphNode);
	SAssignNew(Content, SVerticalBox);

	bool bDisplayTitle = true;

	Content->AddSlot()
		.AutoHeight()
		[
			SAssignNew(InlineEditableText, SInlineEditableTextBlock)
			.Style(FAppStyle::Get(), "Graph.StateNode.NodeTitleInlineEditableText")
		//.Text(NodeTitle.Get(), &SNodeTitle::GetHeadTitle)
		.Text(FText::FromString(TitleName))
		.OnVerifyTextChanged(this, &SEDGraphNode_QuestProgress::OnVerifyNameTextChanged)
		.OnTextCommitted(this, &SEDGraphNode_QuestProgress::OnNameTextCommited)
		.IsReadOnly(this, &SEDGraphNode_QuestProgress::IsNameReadOnly)
		.IsSelected(this, &SEDGraphNode_QuestProgress::IsSelectedExclusively)
		.Visibility(bDisplayTitle ? EVisibility::Visible : EVisibility::Collapsed)
		];
	Content->AddSlot()
		.AutoHeight()
		[
			NodeTitle.ToSharedRef()
		];

	//// Add custom property widgets sorted by user specification.
	//UEDGraphNode_StateNodeBase* StateNodeBase = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);

	//// Populate all used state classes, in order.
	//TArray<USMNodeInstance*> NodeTemplates;

	//auto IsValidClass = [](UEDGraphNode_Base* Node, UClass* NodeClass) {return NodeClass && NodeClass != Node->GetDefaultNodeClass(); };

	//if (IsValidClass(StateNodeBase, StateNodeBase->GetNodeClass()))
	//{
	//	NodeTemplates.Add(StateNodeBase->GetNodeTemplate());
	//}

	return Content;
}

FSlateColor SEDGraphNode_QuestProgress::GetBorderBackgroundColor() const
{
	UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	return FLinearColor::Gray;
}

const FSlateBrush* SEDGraphNode_QuestProgress::GetNameIcon() const
{
	UEDGraphNode_StateNodeBase* StateNode = CastChecked<UEDGraphNode_StateNodeBase>(GraphNode);
	if (const FSlateBrush* Brush = StateNode->GetNodeIcon())
	{
		return Brush;
	}

	return FAppStyle::Get().GetBrush(TEXT("Graph.StateNode.Icon"));
}


#undef LOCTEXT_NAMESPACE