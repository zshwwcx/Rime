#pragma once

#include "CoreMinimal.h"
#include "EDNodeDefine.generated.h"

UENUM(BlueprintType, Blueprintable)
enum class EDNodeType : uint8
{
	RingQuest,
	RingQuestCondition,

	QuestBegin,
	QuestProgress,
	QuestTarget,
	QuestAction,
	QuestCondition,
	QuestEnd,

	ChapterRing,
	ChapterRingCondition,
	ChapterEnd,
	
	Max,
};