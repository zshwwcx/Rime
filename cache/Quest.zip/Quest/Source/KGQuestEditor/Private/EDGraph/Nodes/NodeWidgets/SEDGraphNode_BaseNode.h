#pragma once

#include "CoreMinimal.h"
#include "SGraphNode.h"

class UEDGraphNode_Base;

class SEDGraphNode_BaseNode : public SGraphNode
{
public:
	SLATE_BEGIN_ARGS(SEDGraphNode_BaseNode) {}
	SLATE_ARGUMENT(FMargin, ContentPadding)
		SLATE_END_ARGS()

		~SEDGraphNode_BaseNode();

	void Construct(const FArguments& InArgs, class UEDGraphNode_Base* InNode);

	// SGraphNode
	virtual void UpdateGraphNode() override;
	virtual void OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual void OnMouseLeave(const FPointerEvent& MouseEvent) override;
	virtual void MoveTo( const FVector2D& NewPosition, FNodeSet& NodeFilter, bool bMarkDirty = true ) override;
	// ~SGraphNode

	bool IsMouseOverNode() const { return bIsMouseOver; }
	virtual void OnRefreshRequested(UEDGraphNode_Base* InNode, bool bFullRefresh);

protected:
	bool bIsMouseOver = false;
	TSharedPtr<STextBlock> NodeIdxText;

private:
	FDelegateHandle NodeRefreshHandle;

public:
	FString EditName;
	FText TargetDesc;
	FString TitleName;
	FString NodeIdx;
};
