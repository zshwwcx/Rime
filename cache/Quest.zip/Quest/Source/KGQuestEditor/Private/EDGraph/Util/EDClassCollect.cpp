#include "EDClassCollect.h"

#include "UObject/Object.h"
#include "UObject/Class.h"
#include "Misc/FeedbackContext.h"
#include "Modules/ModuleManager.h"
#include "UObject/UObjectHash.h"
#include "UObject/UObjectIterator.h"
#include "Misc/PackageName.h"
#include "UObject/ConstructorHelpers.h"
#include "Engine/Blueprint.h"
#include "AssetRegistry/AssetData.h"
#include "Editor.h"
#include "ObjectEditorUtils.h"
#include "Logging/MessageLog.h"
#include "AssetRegistry/ARFilter.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "StructUtils/UserDefinedStruct.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "HAL/PlatformApplicationMisc.h"

#define LOCTEXT_NAMESPACE "EDGraph"

FEDClassData::FEDClassData(UClass* InClass, const FString& InDeprecatedMessage) :
	bIsHidden(0),
	bHideParent(0),
	Class(InClass),
	DeprecatedMessage(InDeprecatedMessage)
{
	Category = GetCategory();

	if (InClass)
	{
		ClassName = InClass->GetName();
	}
}

FEDClassData::FEDClassData(const FString& InAssetName, const FString& InGeneratedClassPackage, const FString& InClassName, UClass* InClass) :
	bIsHidden(0),
	bHideParent(0),
	Class(InClass),
	AssetName(InAssetName),
	GeneratedClassPackage(InGeneratedClassPackage),
	ClassName(InClassName)
{
	Category = GetCategory();
}

FString FEDClassData::ToString() const
{
	FString ShortName = GetDisplayName();
	if (!ShortName.IsEmpty())
	{
		return ShortName;
	}

	UClass* MyClass = Class.Get();
	if (MyClass)
	{
		FString ClassDesc = MyClass->GetName();

		if (MyClass->HasAnyClassFlags(CLASS_CompiledFromBlueprint))
		{
			return ClassDesc.LeftChop(2);
		}

		const int32 ShortNameIdx = ClassDesc.Find(TEXT("_"), ESearchCase::CaseSensitive);
		if (ShortNameIdx != INDEX_NONE)
		{
			ClassDesc.MidInline(ShortNameIdx + 1, MAX_int32, false);
		}

		return ClassDesc;
	}

	return AssetName;
}

FString FEDClassData::GetClassName() const
{
	return Class.IsValid() ? Class->GetName() : ClassName;
}

FString FEDClassData::GetDisplayName() const
{
	return Class.IsValid() ? Class->GetMetaData(TEXT("DisplayName")) : FString();
}

FText FEDClassData::GetCategory() const
{
	return Class.IsValid() ? FObjectEditorUtils::GetCategoryText(Class.Get()) : Category;
}

bool FEDClassData::IsAbstract() const
{
	return Class.IsValid() ? Class.Get()->HasAnyClassFlags(CLASS_Abstract) : false;
}

UClass* FEDClassData::GetClass(bool bSilent)
{
	UClass* RetClass = Class.Get();
	if (RetClass == NULL && GeneratedClassPackage.Len())
	{
		GWarn->BeginSlowTask(LOCTEXT("LoadPackage", "Loading Package..."), true);

		UPackage* Package = LoadPackage(NULL, *GeneratedClassPackage, LOAD_NoRedirects);
		if (Package)
		{
			Package->FullyLoad();

			UObject* Object = FindObject<UObject>(Package, *AssetName);

			GWarn->EndSlowTask();

			UBlueprint* BlueprintOb = Cast<UBlueprint>(Object);
			RetClass = BlueprintOb ? *BlueprintOb->GeneratedClass :
				Object ? Object->GetClass() :
				NULL;

			Class = RetClass;
		}
		else
		{
			GWarn->EndSlowTask();

			if (!bSilent)
			{
				FMessageLog EditorErrors("EditorErrors");
				EditorErrors.Error(LOCTEXT("PackageLoadFail", "Package Load Failed"));
				EditorErrors.Info(FText::FromString(GeneratedClassPackage));
				EditorErrors.Notify(LOCTEXT("PackageLoadFail", "Package Load Failed"));
			}
		}
	}

	return RetClass;
}

//////////////////////////////////////////////////////////////////////////

FEDClassCollect::FEDClassCollect(UClass* InRootClass)
{
	RootNodeClass = InRootClass;

	// Register with the Asset Registry to be informed when it is done loading up files.
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	AssetRegistryModule.Get().OnFilesLoaded().AddRaw(this, &FEDClassCollect::InvalidateCache);
	AssetRegistryModule.Get().OnAssetAdded().AddRaw(this, &FEDClassCollect::OnAssetAdded);
	AssetRegistryModule.Get().OnAssetRemoved().AddRaw(this, &FEDClassCollect::OnAssetRemoved);

	// Register to have Populate called when doing a Reload.
	FCoreUObjectDelegates::ReloadCompleteDelegate.AddRaw(this, &FEDClassCollect::OnReloadComplete);

	// Register to have Populate called when a Blueprint is compiled.
	GEditor->OnBlueprintCompiled().AddRaw(this, &FEDClassCollect::InvalidateCache);
	GEditor->OnClassPackageLoadedOrUnloaded().AddRaw(this, &FEDClassCollect::InvalidateCache);

	UpdateAvailableBlueprintClasses();
}

void FEDClassCollect::Release()
{
	// Unregister with the Asset Registry to be informed when it is done loading up files.
	if (FModuleManager::Get().IsModuleLoaded(TEXT("AssetRegistry")))
	{
		IAssetRegistry* AssetRegistry = FModuleManager::GetModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).TryGet();
		if (AssetRegistry)
		{
			AssetRegistry->OnFilesLoaded().RemoveAll(this);
			AssetRegistry->OnAssetAdded().RemoveAll(this);
			AssetRegistry->OnAssetRemoved().RemoveAll(this);
		}

		// Unregister to have Populate called when doing a Reload.
		FCoreUObjectDelegates::ReloadCompleteDelegate.RemoveAll(this);

		// Unregister to have Populate called when a Blueprint is compiled.
		if (UObjectInitialized())
		{
			// GEditor can't have been destructed before we call this or we'll crash.
			GEditor->OnBlueprintCompiled().RemoveAll(this);
			GEditor->OnClassPackageLoadedOrUnloaded().RemoveAll(this);
		}
	}
}

void FEDNodeClassNode::AddUniqueSubNode(TSharedPtr<FEDNodeClassNode> SubNode)
{
	for (int32 Idx = 0; Idx < SubNodes.Num(); Idx++)
	{
		if (SubNode->Data.GetClassName() == SubNodes[Idx]->Data.GetClassName())
		{
			return;
		}
	}

	SubNodes.Add(SubNode);
}

void FEDClassCollect::GatherClasses(const UClass* BaseClass, TArray<FEDClassData>& AvailableClasses)
{
	const FString BaseClassName = BaseClass->GetName();
	if (!RootNode.IsValid())
	{
		BuildClassGraph();
	}

	TSharedPtr<FEDNodeClassNode> BaseNode = FindBaseClassNode(RootNode, BaseClassName);
	FindAllSubClasses(BaseNode, AvailableClasses);
}

FString FEDClassCollect::GetDeprecationMessage(const UClass* Class)
{
	static FName MetaDeprecated = TEXT("DeprecatedNode");
	static FName MetaDeprecatedMessage = TEXT("DeprecationMessage");
	FString DefDeprecatedMessage("Please remove it!");
	FString DeprecatedPrefix("DEPRECATED");
	FString DeprecatedMessage;

	if (Class && Class->HasAnyClassFlags(CLASS_Native) && Class->HasMetaData(MetaDeprecated))
	{
		DeprecatedMessage = DeprecatedPrefix + TEXT(": ");
		DeprecatedMessage += Class->HasMetaData(MetaDeprecatedMessage) ? Class->GetMetaData(MetaDeprecatedMessage) : DefDeprecatedMessage;
	}

	return DeprecatedMessage;
}

bool FEDClassCollect::IsClassKnown(const FEDClassData& ClassData)
{
	return !ClassData.IsBlueprint() || !UnknownPackages.Contains(*ClassData.GetPackageName());
}

void FEDClassCollect::AddUnknownClass(const FEDClassData& ClassData)
{
	if (ClassData.IsBlueprint())
	{
		UnknownPackages.AddUnique(*ClassData.GetPackageName());
	}
}

bool FEDClassCollect::IsHidingParentClass(UClass* Class)
{
	static FName MetaHideParent = TEXT("HideParentNode");
	return Class && Class->HasAnyClassFlags(CLASS_Native) && Class->HasMetaData(MetaHideParent);
}

bool FEDClassCollect::IsHidingClass(UClass* Class)
{
	static FName MetaHideInEditor = TEXT("HiddenNode");
	return Class && Class->HasAnyClassFlags(CLASS_Native) && Class->HasMetaData(MetaHideInEditor);
}

bool FEDClassCollect::IsPackageSaved(FName PackageName)
{
	const bool bFound = FPackageName::SearchForPackageOnDisk(PackageName.ToString());
	return bFound;
}

void FEDClassCollect::OnAssetAdded(const struct FAssetData& AssetData)
{
	TSharedPtr<FEDNodeClassNode> Node = CreateClassDataNode(AssetData);

	TSharedPtr<FEDNodeClassNode> ParentNode;
	if (Node.IsValid())
	{
		ParentNode = FindBaseClassNode(RootNode, Node->ParentClassName);

		if (!IsPackageSaved(AssetData.PackageName))
		{
			UnknownPackages.AddUnique(AssetData.PackageName);
		}
		else
		{
			const int32 PrevListCount = UnknownPackages.Num();
			UnknownPackages.RemoveSingleSwap(AssetData.PackageName);

			if (UnknownPackages.Num() != PrevListCount)
			{
				OnPackageListUpdated.Broadcast();
			}
		}
	}

	if (ParentNode.IsValid())
	{
		ParentNode->AddUniqueSubNode(Node);
		Node->ParentNode = ParentNode;
	}

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	if (!AssetRegistryModule.Get().IsLoadingAssets())
	{
		UpdateAvailableBlueprintClasses();
	}
}

void FEDClassCollect::OnAssetRemoved(const struct FAssetData& AssetData)
{
	FString AssetClassName;
	if (AssetData.GetTagValue(FBlueprintTags::GeneratedClassPath, AssetClassName))
	{
		ConstructorHelpers::StripObjectClass(AssetClassName);
		AssetClassName = FPackageName::ObjectPathToObjectName(AssetClassName);

		TSharedPtr<FEDNodeClassNode> Node = FindBaseClassNode(RootNode, AssetClassName);
		if (Node.IsValid() && Node->ParentNode.IsValid())
		{
			Node->ParentNode->SubNodes.RemoveSingleSwap(Node);
		}
	}

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	if (!AssetRegistryModule.Get().IsLoadingAssets())
	{
		UpdateAvailableBlueprintClasses();
	}
}

void FEDClassCollect::InvalidateCache()
{
	RootNode.Reset();

	UpdateAvailableBlueprintClasses();
}

void FEDClassCollect::OnReloadComplete(EReloadCompleteReason Reason)
{
	InvalidateCache();
}

TSharedPtr<FEDNodeClassNode> FEDClassCollect::CreateClassDataNode(const struct FAssetData& AssetData)
{
	TSharedPtr<FEDNodeClassNode> Node;

	FString AssetClassName;
	FString AssetParentClassName;
	if (AssetData.GetTagValue(FBlueprintTags::GeneratedClassPath, AssetClassName) && AssetData.GetTagValue(FBlueprintTags::ParentClassPath, AssetParentClassName))
	{
		UObject* Outer1(NULL);
		ResolveName(Outer1, AssetClassName, false, false);

		UObject* Outer2(NULL);
		ResolveName(Outer2, AssetParentClassName, false, false);

		Node = MakeShareable(new FEDNodeClassNode);
		Node->ParentClassName = AssetParentClassName;

		UObject* AssetOb = AssetData.IsAssetLoaded() ? AssetData.GetAsset() : NULL;
		UBlueprint* AssetBP = Cast<UBlueprint>(AssetOb);
		UClass* AssetClass = AssetBP ? *AssetBP->GeneratedClass : AssetOb ? AssetOb->GetClass() : NULL;
		

		FEDClassData NewData(AssetData.AssetName.ToString(), AssetData.PackageName.ToString(), AssetClassName, AssetClass);
		Node->Data = NewData;
	}

	return Node;
}

TSharedPtr<FEDNodeClassNode> FEDClassCollect::FindBaseClassNode(TSharedPtr<FEDNodeClassNode> Node, const FString& ClassName)
{
	TSharedPtr<FEDNodeClassNode> RetNode;
	if (Node.IsValid())
	{
		if (Node->Data.GetClassName() == ClassName)
		{
			return Node;
		}

		for (int32 i = 0; i < Node->SubNodes.Num(); i++)
		{
			RetNode = FindBaseClassNode(Node->SubNodes[i], ClassName);
			if (RetNode.IsValid())
			{
				break;
			}
		}
	}

	return RetNode;
}

void FEDClassCollect::FindAllSubClasses(TSharedPtr<FEDNodeClassNode> Node, TArray<FEDClassData>& AvailableClasses)
{
	if (Node.IsValid())
	{
		if (!Node->Data.IsAbstract() && !Node->Data.IsDeprecated() && !Node->Data.bIsHidden)
		{
			Node->Data.GetClass();

			AvailableClasses.Add(Node->Data);
		}

		for (int32 i = 0; i < Node->SubNodes.Num(); i++)
		{
			FindAllSubClasses(Node->SubNodes[i], AvailableClasses);
		}
	}
}

UClass* FEDClassCollect::FindAssetClass(const FString& GeneratedClassPackage, const FString& AssetName)
{
	UPackage* Package = FindPackage(NULL, *GeneratedClassPackage);
	if (Package)
	{
		UObject* Object = FindObject<UObject>(Package, *AssetName);
		if (Object)
		{
			UBlueprint* BlueprintOb = Cast<UBlueprint>(Object);
			return BlueprintOb ? *BlueprintOb->GeneratedClass : Object->GetClass();
		}
	}

	return NULL;
}

void FEDClassCollect::BuildClassGraph()
{
	TArray<TSharedPtr<FEDNodeClassNode> > NodeList;
	TArray<UClass*> HideParentList;
	RootNode.Reset();

	// gather all native classes
	for (TObjectIterator<UClass> It; It; ++It)
	{
		UClass* TestClass = *It;
		if (TestClass->HasAnyClassFlags(CLASS_Native) && TestClass->IsChildOf(RootNodeClass))
		{
			TSharedPtr<FEDNodeClassNode> NewNode = MakeShareable(new FEDNodeClassNode);
			NewNode->ParentClassName = TestClass->GetSuperClass()->GetName();

			FString DeprecatedMessage = GetDeprecationMessage(TestClass);
			FEDClassData NewData(TestClass, DeprecatedMessage);

			NewData.bHideParent = IsHidingParentClass(TestClass);
			if (NewData.bHideParent)
			{
				HideParentList.Add(TestClass->GetSuperClass());
			}

			NewData.bIsHidden = IsHidingClass(TestClass);

			NewNode->Data = NewData;

			if (TestClass == RootNodeClass)
			{
				RootNode = NewNode;
			}

			NodeList.Add(NewNode);
		}
	}

	// find all hidden parent classes
	for (int32 i = 0; i < NodeList.Num(); i++)
	{
		TSharedPtr<FEDNodeClassNode> TestNode = NodeList[i];
		if (HideParentList.Contains(TestNode->Data.GetClass()))
		{
			TestNode->Data.bIsHidden = true;
		}
	}

	// gather all blueprints
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	TArray<FAssetData> BlueprintList;

	FARFilter Filter;
	Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
	
	AssetRegistryModule.Get().GetAssets(Filter, BlueprintList);

	for (int32 i = 0; i < BlueprintList.Num(); i++)
	{
		TSharedPtr<FEDNodeClassNode> NewNode = CreateClassDataNode(BlueprintList[i]);
		NodeList.Add(NewNode);
	}

	// build class tree
	AddClassGraphChildren(RootNode, NodeList);
}

void FEDClassCollect::AddClassGraphChildren(TSharedPtr<FEDNodeClassNode> Node, TArray<TSharedPtr<FEDNodeClassNode> >& NodeList)
{
	if (!Node.IsValid())
	{
		return;
	}

	const FString NodeClassName = Node->Data.GetClassName();
	for (int32 i = NodeList.Num() - 1; i >= 0; i--)
	{
		if (NodeList[i]->ParentClassName == NodeClassName)
		{
			TSharedPtr<FEDNodeClassNode> MatchingNode = NodeList[i];
			NodeList.RemoveAt(i);

			MatchingNode->ParentNode = Node;
			Node->SubNodes.Add(MatchingNode);

			AddClassGraphChildren(MatchingNode, NodeList);
		}
	}
}

int32 FEDClassCollect::GetObservedBlueprintClassCount(UClass* BaseNativeClass)
{
	return BlueprintClassCount.FindRef(BaseNativeClass);
}

void FEDClassCollect::AddObservedBlueprintClasses(UClass* BaseNativeClass)
{
	BlueprintClassCount.Add(BaseNativeClass, 0);
}

void FEDClassCollect::UpdateAvailableBlueprintClasses()
{
	if (FModuleManager::Get().IsModuleLoaded(TEXT("AssetRegistry")))
	{
		IAssetRegistry& AssetRegistry = FModuleManager::GetModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();
		const bool bSearchSubClasses = true;

		TArray<FTopLevelAssetPath> ClassNames;
		TSet<FTopLevelAssetPath> DerivedClassNames;

		for (TMap<UClass*, int32>::TIterator It(BlueprintClassCount); It; ++It)
		{
			ClassNames.Reset();
			ClassNames.Add(It.Key()->GetClassPathName());

			DerivedClassNames.Empty(DerivedClassNames.Num());
			AssetRegistry.GetDerivedClassNames(ClassNames, TSet<FTopLevelAssetPath>(), DerivedClassNames);

			int32& Count = It.Value();
			Count = DerivedClassNames.Num();
		}
	}
}

static const TCHAR* VAR_PREFIX = TEXT("BPVar");
static const TCHAR* GRAPH_PREFIX = TEXT("BPGraph");

void FEDClassCollect::ConvertStructToObjClass(UClass* ObjClass, FString SourceStructPath, FString OutObjPath)
{
	
	FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());

	FString FilePath = CurrentPath + "/Editor/QuestEditor/TemplatePart/BoolVarTemplate.txt";


	FBPVariableDescription BoolDescription;
	FString BoolDescriptionStr;
	if (FFileHelper::LoadFileToString(BoolDescriptionStr, *FilePath))
	{

		FString ClipboardText = BoolDescriptionStr;

		if (!ClipboardText.StartsWith(VAR_PREFIX, ESearchCase::CaseSensitive))
		{
			return;
		}

		FBPVariableDescription Description;
		FStringOutputDevice Errors;
		const TCHAR* Import = ClipboardText.GetCharArray().GetData() + FCString::Strlen(VAR_PREFIX);
		FBPVariableDescription::StaticStruct()->ImportText(Import, &Description, nullptr, PPF_None, &Errors, FBPVariableDescription::StaticStruct()->GetName());

		if (!Errors.IsEmpty())
		{
			return ;
		}

		BoolDescription = Description;
	}

	FString FilesPath = SourceStructPath;
	FilesPath.RemoveAt(0, 6);

	FilesPath = CurrentPath + FilesPath;

	TArray<FString> TempFilePath;
	IFileManager::Get().FindFiles(TempFilePath, *FilesPath);

	for (auto& FileP : TempFilePath)
	{
		FString _FileName = FPaths::GetBaseFilename(FileP);

		FString NodPath = SourceStructPath + _FileName + "." + _FileName;

		FString StructPath = NodPath;

		FSoftObjectPath AssetRef(StructPath);

		UUserDefinedStruct* SourceStruct = Cast<UUserDefinedStruct>(AssetRef.TryLoad());
		if (SourceStruct)
		{
			{
				FString StructName = FPaths::GetBaseFilename(StructPath);

				FString NewClassName = "QT_" + StructName;
				
				const FString PackageName = "/Game/Structs/" + NewClassName;
				const FName BPName = FName(NewClassName);

				UPackage* BlueprintPackage = CreatePackage(*PackageName);
				if (BlueprintPackage)
				{
					UBlueprint* BlueprintObject = FKismetEditorUtilities::CreateBlueprint(ObjClass, BlueprintPackage, BPName, EBlueprintType::BPTYPE_Normal, UBlueprint::StaticClass(), UBlueprintGeneratedClass::StaticClass());

					if (BlueprintObject)
					{
						BlueprintPackage->SetDirtyFlag(true);
						BlueprintObject->BlueprintDisplayName = SourceStruct->GetToolTipText().ToString();

						for (TFieldIterator<FProperty> It(SourceStruct); It; ++It)
						{
							FProperty* Property = *It;
							if (Property)
							{
								FBPVariableDescription NewVar = FBlueprintEditorUtils::DuplicateVariableDescription(BlueprintObject, BoolDescription);
								if (NewVar.VarGuid.IsValid())
								{
									NewVar.VarName = FName(Property->GetDisplayNameText().ToString());
									NewVar.FriendlyName = FName::NameToDisplayString(NewVar.VarName.ToString(), false);

									FString PinCategory = "";
									FString PinSubCategory = "";
									FString PinSubCategoryObject = "";
									FString DefaultValue = "";

									if (FStrProperty* StrProperty = CastField<FStrProperty>(Property))
									{
										PinCategory = "string";
										DefaultValue = "0.000000";
									}
									if (FNameProperty* NameProperty = CastField<FNameProperty>(Property))
									{
										PinCategory = "name";
										DefaultValue = "0.000000";
									}
									if (FBoolProperty* BoolProperty = CastField<FBoolProperty>(Property))
									{
										PinCategory = "bool";
									}
									if (FFloatProperty* FloatProperty = CastField<FFloatProperty>(Property))
									{
										PinCategory = "real";
										PinSubCategory = "double";
										DefaultValue = "0.000000";
									}
									if (FDoubleProperty* DoubleProperty = CastField<FDoubleProperty>(Property))
									{
										PinCategory = "real";
										PinSubCategory = "double";
										DefaultValue = "0.000000";
									}
									if (FIntProperty* IntProperty = CastField<FIntProperty>(Property))
									{
										PinCategory = "int";
										DefaultValue = "0";
									}
									
									 
									const FString CPPType = Property->GetCPPType(nullptr, 0);
									if (CPPType == "FVector")
									{
										PinCategory = "struct";
										PinSubCategory = "";
										PinSubCategoryObject = "/Script/CoreUObject.ScriptStruct'/Script/CoreUObject.Vector'";
										DefaultValue = "0.000000";
									}
									if (CPPType == "FRotator")
									{
										PinCategory = "struct";
										PinSubCategory = "";
										PinSubCategoryObject = "/Script/CoreUObject.ScriptStruct'/Script/CoreUObject.Rotator'";
										DefaultValue = "0.000000";
									}
									if (CPPType == "FTransform")
									{
										PinCategory = "struct";
										PinSubCategory = "";
										PinSubCategoryObject = "/Script/CoreUObject.ScriptStruct'/Script/CoreUObject.Transform'";
										DefaultValue = "0.000000";
									}
									if (CPPType == "FColor")
									{
										PinCategory = "struct";
										PinSubCategory = "";
										PinSubCategoryObject = "/Script/CoreUObject.ScriptStruct'/Script/CoreUObject.Color'";
										DefaultValue = "0.000000";
									}

									if (PinCategory.IsEmpty() && PinSubCategory.IsEmpty() && PinSubCategoryObject.IsEmpty() && DefaultValue.IsEmpty())
									{
										UE_LOG(LogTemp, Error, TEXT("%s %s"), *StructName, *(NewVar.VarName.ToString()));

										PinCategory = "string";
										DefaultValue = "(\"\")";

										NewVar.VarType.ContainerType = EPinContainerType::Array;
									}

									FScopedTransaction Transaction(FText::Format(LOCTEXT("PasteVariable", "Paste Variable: {0}"), FText::FromName(NewVar.VarName)));
									BlueprintObject->Modify();

									NewVar.VarType.PinCategory = FName(PinCategory);
									NewVar.VarType.PinSubCategory = FName(PinSubCategory);
									NewVar.DefaultValue = DefaultValue;

									if (!PinSubCategoryObject.IsEmpty())
									{
										FSoftObjectPath PinSubCategoryObjectAssetRef(PinSubCategoryObject);

										UScriptStruct* PinSubCategoryObjectSourceStruct = Cast<UScriptStruct>(PinSubCategoryObjectAssetRef.TryLoad());
										if (PinSubCategoryObjectSourceStruct)
										{
											NewVar.VarType.PinSubCategoryObject = PinSubCategoryObjectSourceStruct;
										}
										else
										{
											UE_LOG(LogTemp, Error, TEXT("%s %s"), *StructName, *(NewVar.VarName.ToString()));
										}
									}


									BlueprintObject->NewVariables.Add(NewVar);

									FBlueprintEditorUtils::ValidateBlueprintChildVariables(BlueprintObject, NewVar.VarName);
									FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(BlueprintObject);
								}
							}
						}

						FKismetEditorUtilities::CompileBlueprint(BlueprintObject);
						FAssetRegistryModule::AssetCreated(BlueprintObject);

						FAssetData AssetData(BlueprintObject);
						TArray<FAssetData> Assets;
						Assets.Add(MoveTemp(AssetData));

						FAssetRegistryModule::AssetsSaved(MoveTemp(Assets));
					}
				}


			}
		}
	}
}

#undef LOCTEXT_NAMESPACE
