#include "EventDrivenGraphSchema.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "../Nodes/EDGraphNode_EntryNode.h"
#include "../Nodes/EDGraphNode_StateNode.h"
#include "EDGraphLineDrawingPolicy.h"
#include "../Nodes/EDGraphNode_Transition.h"
#include "../Util/EDClassCollect.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "FQuestObjectivesEditor.h"
#include "QuestSettings.h"
#include "KGQuestEditorModule.h"
#include "Framework/Commands/GenericCommands.h"

#define LOCTEXT_NAMESPACE "EventDrivenGraphSchema"

DEFINE_LOG_CATEGORY_STATIC(LogQuestObjectivesEditor, Log, All);

UE_DISABLE_OPTIMIZATION_SHIP

UEdGraphNode* FEDGraphSchemaAction_PlaceNode::PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode /*= true*/)
{
	// 有一些情况下我们不允许放置节点
	{
		if (NodeType == EDNodeType::QuestAction || NodeType == EDNodeType::QuestTarget)
		{
			if (FromPin != nullptr)
			{
				if (FromPin->Direction == EEdGraphPinDirection::EGPD_Input)
				{
					FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Cannot Place Node From Display-Only Pin!"))));
					// 是Input就说明是连错了位置
					return nullptr;
				}
				if (const UEDGraphNode_Base* TargetNode = Cast<UEDGraphNode_Base>(FromPin->GetOwningNodeUnchecked()))
				{
					// 有一些Action节点不允许连接在End上
					if (TargetNode->NodeType == EDNodeType::QuestEnd)
					{
						if (UEDGraphNode_Base* NodeTemplateBase = Cast<UEDGraphNode_Base>(NodeTemplate))
						{
							if (const UClass* NodeTemplateNodeClass = NodeTemplateBase->ClassData.GetClass(true))
							{
								if (NodeTemplateNodeClass->GetSuperClass() == UQuestActionBase::StaticClass())
								{
									if (const UQuestActionBase* QuestActionBase = Cast<UQuestActionBase>(NodeTemplateNodeClass->GetDefaultObject()))
									{
										// 目前他们就在文档中标注了一下,只能先写死
										const TArray<int32> TmpBanList({1,2,3,4,5,7,24,30,31,50});
										if (TmpBanList.Contains(QuestActionBase->Event))
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("This Node Cannot Put At End!"))));
											return nullptr;
										}
									}
								}
							}
						}
					}
					// 首个Target继承QuestName
					if (TargetNode->NodeType == EDNodeType::QuestProgress)
					{
						int targetCount = 0;
						for (UEdGraphPin* Pin : TargetNode->GetAllPins())
						{
							if (Pin->Direction == EGPD_Output)
							{
								TArray<UEdGraphPin*> ToPins = Pin->LinkedTo;
								for (UEdGraphPin* ToPin : ToPins)
								{
									if (UEdGraphNode* ChildNode = ToPin->GetOwningNodeUnchecked())
									{
										if (UEDGraphNode_Transition* TNode = Cast<UEDGraphNode_Transition>(ChildNode))
										{
											UEdGraphPin* NextTToPin = TNode->GetOutputPin();
											if (NextTToPin)
											{
												TArray<UEdGraphPin*> NextTToPin_LinkTos = NextTToPin->LinkedTo;
												for (UEdGraphPin* NextTToPin_ToPin : NextTToPin_LinkTos)
												{
													if (NextTToPin_ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
													{
														UEdGraphNode* ToNode = NextTToPin_ToPin->GetOwningNodeUnchecked();
														if (UEDGraphNode_StateNode* ToQuest = Cast<UEDGraphNode_StateNode>(ToNode))
														{
															ChildNode = ToQuest;
														}
													}
												}
											}
										}

										if (UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(ChildNode))
										{
											if (EDNode->NodeType == EDNodeType::QuestTarget)
												targetCount++;
										}
									}
								}
							}
						}
						if (targetCount <= 0)
						{
							if (const UQuest* ParentQuest = Cast<UQuest>(ParentGraph->GetOuter()))
							{
								if (FProperty* Property = ParentQuest->GetClass()->FindPropertyByName(TEXT("QuestName")))
								{
									if (UEDGraphNode_Base* NodeTemplateBase = Cast<UEDGraphNode_Base>(NodeTemplate))
									{
										if (const UClass* NodeTemplateNodeClass = NodeTemplateBase->ClassData.GetClass(true))
										{
											if (NodeTemplateNodeClass->GetSuperClass()->GetSuperClass() == UQuestTargetBase::StaticClass())
											{
												if (UQuestTargetBase* QuestActionBase = Cast<UQuestTargetBase>(NodeTemplateNodeClass->GetDefaultObject()))
												{
													if (FProperty* targetProperty = QuestActionBase->GetClass()->FindPropertyByName(TEXT("Desc")))
													{
														targetProperty->CopyCompleteValue(targetProperty->ContainerPtrToValuePtr<void>(QuestActionBase), Property->ContainerPtrToValuePtr<const void>(ParentQuest));
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}	
	}
	
	UEdGraphNode* ResultNode = nullptr;

	UObject* NodeUserData(nullptr);

	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			bInitialization = QuestEditor->bLoadingChapterGraph | QuestEditor->bLoadingRingGraph | QuestEditor->bLoadingQuestGraph;
		}
	}

	FScopedTransaction Transaction(LOCTEXT("PlaceNodeTransaction", "Place Node Transaction"));
	if(bInitialization)
	{
		//Transaction.Cancel();
	}
	if(!bInitialization)
	{
		ParentGraph->Modify();
		if(FromPin)
		{
			FromPin->Modify();
		}
	}
	
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			if(!bInitialization)
			{
				QuestEditor->ModifyData();
			}
			if (NodeType == EDNodeType::RingQuest)
			{
				if (NodeTemplate != nullptr)
				{
					if (UEDGraphNode_Base* NodeTemplateBase = Cast<UEDGraphNode_Base>(NodeTemplate))
					{
						if (NodeTemplateBase->NodeInstance == nullptr)
						{
							QuestEditor->PlacePos = Location;
							UQuest* NewQuest = QuestEditor->CreateQuest(FromPin);
							if (!NewQuest)
							{
								return nullptr;
							}
							NodeUserData = NewQuest;
						}
						else
							NodeUserData = NodeTemplateBase->NodeInstance;
					}
				}
			}
			if (NodeType == EDNodeType::ChapterRing)
			{
				if (UEDGraphNode_Base* NodeTemplateBase = Cast<UEDGraphNode_Base>(NodeTemplate))
				{
					if (NodeTemplateBase->NodeInstance == nullptr)
					{
						QuestEditor->PlacePos = Location;
						UQuestRing* NewRing = QuestEditor->CreateRing(FromPin);
						if (!NewRing)
						{
							return nullptr;
						}
						NodeUserData = NewRing;
					}
					else
						NodeUserData = NodeTemplateBase->NodeInstance;
				}
			}
			if (NodeType == EDNodeType::ChapterEnd)
			{
				if (UEDGraphNode_Base* NodeTemplateBase = Cast<UEDGraphNode_Base>(NodeTemplate))
				{
					if (NodeTemplateBase->NodeInstance == nullptr)
					{
						QuestEditor->PlacePos = Location;
						UChapterEnd* End = QuestEditor->CreateChapterEnd(FromPin);
						if (!End)
						{
							return nullptr;
						}
						NodeUserData = End;
					}
					else
						NodeUserData = NodeTemplateBase->NodeInstance;
				}
			}
		}
	}


	if (NodeTemplate != nullptr)
	{
		if(!bInitialization)
		{
			NodeTemplate->Modify();
		}
		if (UEDGraphNode_Base* _NewNode = Cast<UEDGraphNode_Base>(NodeTemplate))
		{
			_NewNode->NodeType = NodeType;
			switch (_NewNode->NodeType)
			{
			case EDNodeType::ChapterRing:
				_NewNode->NodeInstance = NodeUserData;
				if (UQuestRing* Ring = Cast<UQuestRing>(NodeUserData))
				{
					_NewNode->NodeName = FString::FromInt(Ring->RingID);
					_NewNode->NodeName.Append(FString("-"));
					_NewNode->NodeName.Append(Ring->RingName);
					_NewNode->NodePath = Ring->GetPathName();
				}
				break;
			case EDNodeType::ChapterEnd:
				_NewNode->NodeInstance = NodeUserData;
				if (UChapterEnd* End = Cast<UChapterEnd>(NodeUserData))
				{
					_NewNode->NodeName = FString::FromInt(End->NextRingID);
					_NewNode->NodeName.Append(FString("-"));
					_NewNode->NodeName.Append(End->Desc);
					_NewNode->NodePath = End->GetPathName();
				}
				break;
			case EDNodeType::RingQuest:
				_NewNode->NodeInstance = NodeUserData;
				if (UQuest* Quest = Cast<UQuest>(NodeUserData))
				{
					_NewNode->NodeName = FString::FromInt(Quest->QuestID);
					_NewNode->NodeName.Append(FString("-"));
					if(Quest->MainTargetTraceCombo.Num() > 0)
					{
						_NewNode->NodeName.Append(Quest->MainTargetTraceCombo[0].Desc);
					}
					_NewNode->NodePath = Quest->GetPathName();
				}
				break;
				
			case EDNodeType::QuestBegin:
			case EDNodeType::QuestProgress:
			case EDNodeType::QuestEnd:
				_NewNode->NodeInstance = NodeUserData;
				if (UEDGraphBase* EDGraph = Cast<UEDGraphBase>(ParentGraph))
				{
					if (EDGraph->UserDataObj.IsValid())
					{
						if (UQuest* Quest = Cast<UQuest>(EDGraph->UserDataObj.Get()))
						{
							UObject* RefNodeIns = nullptr;

							switch (_NewNode->NodeType)
							{
							case EDNodeType::QuestBegin:
								if (!Quest->Begin)
								{
									Quest->Begin = NewObject<UQuestBeginBase>(Quest, TEXT("Begin"));
								}
								RefNodeIns = Quest->Begin;
								break;

							case EDNodeType::QuestProgress:
								if (!Quest->Progress)
								{
									Quest->Progress = NewObject<UQuestProgressBase>(Quest, TEXT("Progress"));
								}
								RefNodeIns = Quest->Progress;
								break;
							case EDNodeType::QuestEnd:
								if (!Quest->End)
								{
									Quest->End = NewObject<UQuestEndBase>(Quest, TEXT("End"));
								}
								RefNodeIns = Quest->End;
								break;
							}


							_NewNode->NodeInstance = RefNodeIns;
						}
					}
				}
				break;
			}
		}

		NodeTemplate->Rename(nullptr, ParentGraph);
		NodeTemplate->CreateNewGuid();

		// Optimization to not double generate a template.
		//if (USMGraphNode_Base* GraphNode = Cast<USMGraphNode_Base>(NodeTemplate))
		//{
		//	GraphNode->bGenerateTemplateOnNodePlacement = NodeClass == nullptr;
		//}

		NodeTemplate->PostPlacedNewNode();
		NodeTemplate->AllocateDefaultPins();

		NodeTemplate->NodePosX = Location.X;
		NodeTemplate->NodePosY = Location.Y;

		NodeTemplate->SetFlags(RF_Transactional);

		ParentGraph->AddNode(NodeTemplate, !bInitialization, bSelectNewNode);

		ResultNode = NodeTemplate;
		
		// Set the actual node class if one is set.
		if (NodeClass)
		{
			//if (USMGraphNode_Base* GraphNode = Cast<USMGraphNode_Base>(NodeTemplate))
			//{
			//	GraphNode->SetNodeClass(NodeClass);
			//}
		}

		NodeTemplate->AutowireNewNode(FromPin);
		ParentGraph->NotifyGraphChanged();

		//UBlueprint* Blueprint = FBlueprintEditorUtils::FindBlueprintForGraphChecked(ParentGraph);
		//FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);
	}
	
	if (NodeType == EDNodeType::QuestAction)
	{
		if (UEDGraphBase* EDGraph = Cast<UEDGraphBase>(ParentGraph))
		{
			if (EDGraph->QuestObjectivesEditor.IsValid())
			{
				auto EDGraphEditor = EDGraph->QuestObjectivesEditor.Pin().Get();
				if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(EDGraphEditor))
				{
					QuestEditor->OnRefreshActionStateIdx(EDGraph);
				}
			}
		}
	}

	if (NodeType == EDNodeType::QuestTarget)
	{
		if (UEDGraphBase* EDGraph = Cast<UEDGraphBase>(ParentGraph))
		{
			if (EDGraph->QuestObjectivesEditor.IsValid())
			{
				auto EDGraphEditor = EDGraph->QuestObjectivesEditor.Pin().Get();
				if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(EDGraphEditor))
				{
					QuestEditor->OnRefreshTargetStateIdx(EDGraph);
				}
			}
		}
	}

	if (UEDGraphNode_Base* NodeTemplateBase = Cast<UEDGraphNode_Base>(NodeTemplate))
	{
		if (UQuestDataBase* QuestDataBase = Cast<UQuestDataBase>(NodeTemplateBase->NodeInstance))
		{
			QuestDataBase->QuestGraph = ParentGraph;
		}
	}

	return ResultNode;
}

void FEDGraphSchemaAction_PlaceNode::AddReferencedObjects(FReferenceCollector& Collector)
{
	FEdGraphSchemaAction::AddReferencedObjects(Collector);
	Collector.AddReferencedObject(NodeTemplate);
}

UEdGraphNode* FEDGraphSchemaAction_NewComment::PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode /*= true*/)
{
	// Add menu item for creating comment boxes
	UEdGraphNode_Comment* CommentTemplate = NewObject<UEdGraphNode_Comment>();

	UBlueprint* Blueprint = FBlueprintEditorUtils::FindBlueprintForGraph(ParentGraph);

	FVector2D SpawnLocation = Location;

	FSlateRect Bounds;
	if (Blueprint != nullptr && FKismetEditorUtilities::GetBoundsForSelectedNodes(Blueprint, Bounds, 50.0f))
	{
		CommentTemplate->SetBounds(Bounds);
		SpawnLocation.X = CommentTemplate->NodePosX;
		SpawnLocation.Y = CommentTemplate->NodePosY;
	}

	return FEdGraphSchemaAction_NewNode::SpawnNodeFromTemplate<UEdGraphNode_Comment>(ParentGraph, CommentTemplate, SpawnLocation);
}


template<typename T>
TSharedPtr<T> AddNewNodeAction(FGraphContextMenuBuilder& ContextMenuBuilder, const FText& Category, const FText& MenuDesc, const FText& Tooltip, const int32 Grouping = 0)
{
	TSharedPtr<T> NewStateNode(new T(Category, MenuDesc, Tooltip, Grouping));
	ContextMenuBuilder.AddAction(NewStateNode);
	return NewStateNode;
}

UEventDrivenGraphSchema::UEventDrivenGraphSchema(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UEventDrivenGraphSchema::CreateDefaultNodesForGraph(UEdGraph& Graph) const
{
	// Create the result node
	//FGraphNodeCreator<USMGraphNode_StateMachineEntryNode> NodeCreator(Graph);
	//USMGraphNode_StateMachineEntryNode* EntryNode = NodeCreator.CreateNode();
	//NodeCreator.Finalize();
	//SetNodeMetaData(EntryNode, FNodeMetadata::DefaultGraphNode);

	//if (USMGraph* StateMachineGraph = CastChecked<USMGraph>(&Graph))
	//{
	//	StateMachineGraph->EntryNode = EntryNode;
	//}
}

EGraphType UEventDrivenGraphSchema::GetGraphType(const UEdGraph* TestEdGraph) const
{
	return GT_StateMachine;
}

void UEventDrivenGraphSchema::GetGraphContextActions(FGraphContextMenuBuilder& ContextMenuBuilder) const
{
	Super::GetGraphContextActions(ContextMenuBuilder);

	const int32 BaseGrouping = 1;
	const int32 UserGrouping = 0;

	if (ContextMenuBuilder.CurrentGraph && ContextMenuBuilder.CurrentGraph->GetName() == "RingGraph")
	{
		//TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, FText::GetEmpty(), LOCTEXT("AddConduit1", "Add Conduit..."), LOCTEXT("AddConduit1Tooltip", "A new conduit for branching to different states."), BaseGrouping);
		//NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_EntryNode>(ContextMenuBuilder.OwnerOfTemporaries);

		const UEDGraphBase* EDGraph = Cast<UEDGraphBase>(ContextMenuBuilder.CurrentGraph);
		if (EDGraph)
		{
			if (!ContextMenuBuilder.FromPin)
			{
				{
					const FText MenuDescription = false ? LOCTEXT("CreateCommentSelection", "Create Comment from Selection") : LOCTEXT("AddComment", "Add Comment...");
					const FText ToolTip = LOCTEXT("CreateCommentSelectionTooltip", "Create a resizeable comment box around selected nodes.");

					TSharedPtr<FEDGraphSchemaAction_NewComment> NewComment(new FEDGraphSchemaAction_NewComment(FText::GetEmpty(), MenuDescription, ToolTip, BaseGrouping));
					ContextMenuBuilder.AddAction(NewComment);
				}
			}

			{
				TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, FText::GetEmpty(), LOCTEXT("AddQuest", "AddQuest"), LOCTEXT("AddQuestTooltip", "AddQuest"), BaseGrouping);
				NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(ContextMenuBuilder.OwnerOfTemporaries);
				NewNodeAction->NodeType = EDNodeType::RingQuest;
				NewNodeAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;
			}
		}
	}


	if (ContextMenuBuilder.CurrentGraph && ContextMenuBuilder.CurrentGraph->GetName() == "QuestGraph")
	{

		if (!ContextMenuBuilder.FromPin)
		{
			// Add comment
			{
				//UBlueprint* OwnerBlueprint = FBlueprintEditorUtils::FindBlueprintForGraphChecked(ContextMenuBuilder.CurrentGraph);
				//const bool bIsManyNodesSelected = (FKismetEditorUtilities::GetNumberOfSelectedNodes(OwnerBlueprint) > 0);
				const FText MenuDescription = false ? LOCTEXT("CreateCommentSelection", "Create Comment from Selection") : LOCTEXT("AddComment", "Add Comment...");
				const FText ToolTip = LOCTEXT("CreateCommentSelectionTooltip", "Create a resizeable comment box around selected nodes.");

				TSharedPtr<FEDGraphSchemaAction_NewComment> NewComment(new FEDGraphSchemaAction_NewComment(FText::GetEmpty(), MenuDescription, ToolTip, BaseGrouping));
				ContextMenuBuilder.AddAction(NewComment);
			}

			{
				TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, FText::GetEmpty(), LOCTEXT("AddQuestBegin", "AddQuestBegin..."), LOCTEXT("AddQuestBeginTooltip", "A QuestBegin."), BaseGrouping);
				NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_EntryNode>(ContextMenuBuilder.OwnerOfTemporaries);
				NewNodeAction->NodeType = EDNodeType::QuestBegin;
			}

			{
				TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, FText::GetEmpty(), LOCTEXT("AddQuestInProgress", "AddQuestInProgress.."), LOCTEXT("AddQuestInProgressTooltip", "A QuestInProgress"), BaseGrouping);
				NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(ContextMenuBuilder.OwnerOfTemporaries);
				NewNodeAction->NodeType = EDNodeType::QuestProgress;
			}

			{
				TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, FText::GetEmpty(), LOCTEXT("AddQuestEnd", "Add QuestEnd..."), LOCTEXT("AddQuestEndTooltip", "A QuestEnd"), BaseGrouping);
				NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(ContextMenuBuilder.OwnerOfTemporaries);
				NewNodeAction->NodeType = EDNodeType::QuestEnd;
			}
		}

		EDNodeType FromType = EDNodeType::Max;
		if (ContextMenuBuilder.FromPin && ContextMenuBuilder.FromPin->GetOwningNodeUnchecked())
		{
			if (UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(ContextMenuBuilder.FromPin->GetOwningNodeUnchecked()))
			{
				FromType = EDNode->NodeType;
			}
		}

		{
			FKGQuestEditorModule& EditorModule = FModuleManager::GetModuleChecked<FKGQuestEditorModule>("KGQuestEditor");


			{
				//FCategorizedGraphActionListBuilder TasksBuilder(TEXT("Quest"));

				if(FromType == EDNodeType::QuestProgress)
				{
					TArray<FEDClassData> NodeClasses;

					EditorModule.GetEDClassCollect()->GatherClasses(UQuestTargetBase::StaticClass(), NodeClasses);
					const FText Category = FText::FromString("QuestTarget");
					for (const auto& NodeClass : NodeClasses)
					{
						FString NodeName = NodeClass.GetDisplayName().IsEmpty() ? NodeClass.ToString() : NodeClass.GetDisplayName();
						const FText NodeTypeName = FText::FromString(NodeName);
						if (NodeClass.GetCategory().EqualTo(FText::FromString("QuestTargetBase")) || NodeClass.GetClassName() == "QuestTargetBase")
						{
							continue;
						}

						TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, FText::GetEmpty(), NodeTypeName, FText::GetEmpty());

						UEDGraphNode_StateNode* NewNode = NewObject<UEDGraphNode_StateNode>(ContextMenuBuilder.OwnerOfTemporaries);
						NewNode->ClassData = NodeClass;
						NewNodeAction->NodeTemplate = NewNode;
						NewNodeAction->NodeType = EDNodeType::QuestTarget;
					}
				}

				if(FromType != EDNodeType::Max && FromType != EDNodeType::QuestProgress)
				{
					TArray<FEDClassData> NodeClasses;

					EditorModule.GetEDClassCollect()->GatherClasses(UQuestActionBase::StaticClass(), NodeClasses);
					const FText Category = FText::FromString("QuestAction");
					for (const auto& NodeClass : NodeClasses)
					{
						FString NodeName = NodeClass.GetDisplayName().IsEmpty() ? NodeClass.ToString() : NodeClass.GetDisplayName();
						const FText NodeTypeName = FText::FromString(NodeName);
						if (NodeClass.GetCategory().EqualTo(FText::FromString("QuestActionBase")) || NodeClass.GetClassName() == "QuestActionBase")
						{
							continue;
						}

						TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, FText::GetEmpty(), NodeTypeName, FText::GetEmpty());

						UEDGraphNode_StateNode* NewNode = NewObject<UEDGraphNode_StateNode>(ContextMenuBuilder.OwnerOfTemporaries);
						NewNode->ClassData = NodeClass;
						NewNodeAction->NodeTemplate = NewNode;
						NewNodeAction->NodeType = EDNodeType::QuestAction;
					}
				}

				//ContextMenuBuilder.Append(TasksBuilder);
			}
		}
	}

	if (ContextMenuBuilder.CurrentGraph && ContextMenuBuilder.CurrentGraph->GetName() == "ChapterGraph")
	{
		const UEDGraphBase* EDGraph = Cast<UEDGraphBase>(ContextMenuBuilder.CurrentGraph);
		if (EDGraph)
		{
			if (!ContextMenuBuilder.FromPin)
			{
				{
					const FText MenuDescription = false ? LOCTEXT("CreateCommentSelection", "Create Comment from Selection") : LOCTEXT("AddComment", "Add Comment...");
					const FText ToolTip = LOCTEXT("CreateCommentSelectionTooltip", "Create a resizeable comment box around selected nodes.");

					TSharedPtr<FEDGraphSchemaAction_NewComment> NewComment(new FEDGraphSchemaAction_NewComment(FText::GetEmpty(), MenuDescription, ToolTip, BaseGrouping));
					ContextMenuBuilder.AddAction(NewComment);
				}
			}

			{
				TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, FText::GetEmpty(), LOCTEXT("AddRing", "AddRing"), LOCTEXT("AddRingTooltip", "AddRing"), BaseGrouping);
				NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(ContextMenuBuilder.OwnerOfTemporaries);
				NewNodeAction->NodeType = EDNodeType::ChapterRing;
				NewNodeAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;
			}

			{
				TSharedPtr<FEDGraphSchemaAction_PlaceNode> ChapterEndAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, FText::GetEmpty(), LOCTEXT("AddChapterEndNode", "AddChapterEndNode"), LOCTEXT("AddChapterEndNodeTip", "AddChapterEndNode"), BaseGrouping);
				ChapterEndAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(ContextMenuBuilder.OwnerOfTemporaries);
				ChapterEndAction->NodeType = EDNodeType::ChapterEnd;
				ChapterEndAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;
			}
		}
	}
	//GameFrameEditorModule& EditorModule = FModuleManager::GetModuleChecked<GameFrameEditorModule>("GameFrameEditor");


	//{
	//	FCategorizedGraphActionListBuilder TasksBuilder(TEXT("Tasks"));

	//	TArray<FEDClassData> NodeClasses;
	//			
	//	if (EditorModule.EDEditor.IsValid() && EditorModule.EDEditor->EDClassCollect.IsValid())
	//	{
	//		EditorModule.EDEditor->EDClassCollect->GatherClasses(UEDTask::StaticClass(), NodeClasses);
	//	}
	//	const FText Category = FText::FromString("Tasks");
	//	for (const auto& NodeClass : NodeClasses)
	//	{
	//		const FText NodeTypeName = FText::FromString(FName::NameToDisplayString(NodeClass.ToString(), false));
	//		if (NodeClass.GetCategory().EqualTo(FText::FromString("EDTaskBase")))
	//		{
	//			continue;
	//		}

	//		TSharedPtr<FEDGraphSchemaAction_PlaceNode> AddOpAction = AddNewNodeAction<FEDGraphSchemaAction_PlaceNode>(ContextMenuBuilder, Category, NodeTypeName, FText::GetEmpty());

	//		UEDGraphNode_StateNode* NewNode = NewObject<UEDGraphNode_StateNode>(ContextMenuBuilder.OwnerOfTemporaries);
	//		NewNode->ClassData = NodeClass;
	//		AddOpAction->NodeTemplate = NewNode;
	//	}

	//	ContextMenuBuilder.Append(TasksBuilder);
	//}
}

void UEventDrivenGraphSchema::GetContextMenuActions(class UToolMenu* Menu, class UGraphNodeContextMenuContext* Context) const
{
	const UEdGraph* CurrentGraph = Context->Graph;
	const UEdGraphNode* InGraphNode = Context->Node;
	const UEdGraphPin* InGraphPin = Context->Pin;
	const bool bIsDebugging = Context->bIsDebugging;

	if (InGraphNode)
	{
		FToolMenuSection& Section = Menu->AddSection("QuestObjectiveNodeActions", LOCTEXT("NodeActionsMenuHeader", "Node Actions"));
		{
			Section.AddMenuEntry(FGenericCommands::Get().Delete);
			Section.AddMenuEntry(FGenericCommands::Get().Cut);
			Section.AddMenuEntry(FGenericCommands::Get().Copy);
			Section.AddMenuEntry(FGenericCommands::Get().Paste);
		}

	//		if (bool bCanRename = InGraphNode->bCanRenameNode)
	//		{
	//			if (bCanRename)
	//			{
	//				Section.AddMenuEntry(FGenericCommands::Get().Rename);
	//			}
	//		}

	//		if (!bIsDebugging)
	//		{
	//			FToolMenuSection& StateSection = Menu->AddSection("SMGraphSchemaStateActions", LOCTEXT("StateActionsMenuHeader", "State Actions"));

	//			if (const USMGraphNode_StateNode* StateNode = Cast<USMGraphNode_StateNode>(InGraphNode))
	//			{
	//				//StateSection.AddMenuEntry(FSMEditorCommands::Get().CutAndMergeStates);
	//				//StateSection.AddMenuEntry(FSMEditorCommands::Get().CopyAndMergeStates);
	//			}

	//			StateSection.AddMenuEntry(FSMEditorCommands::Get().CollapseToStateMachine);

	//			if (CanReplaceNode(InGraphNode))
	//			{
	//				StateSection.AddSubMenu(
	//					NAME_None,
	//					LOCTEXT("NodeActionsReplaceWith", "Replace With..."),
	//					LOCTEXT("NodeActionsReplaceWithToolTip", "Perform a destructive replacement of the selected node"),
	//					FNewMenuDelegate::CreateUObject((UEventDrivenGraphSchema* const)this, &UEventDrivenGraphSchema::GetReplaceWithMenuActions, InGraphNode));
	//			}

	//			if (const USMGraphNode_StateMachineStateNode* StateMachineNode = Cast<USMGraphNode_StateMachineStateNode>(InGraphNode))
	//			{
	//				//MenuBuilder->EndSection();
	//				FToolMenuSection& StateMachineSection = Menu->AddSection("SMGraphSchemaReferenceActions", LOCTEXT("ReferenceActionsMenuHeader", "Reference Actions"));
	//				{
	//					if (StateMachineNode->IsStateMachineReference())
	//					{
	//						StateMachineSection.AddMenuEntry(FSMEditorCommands::Get().JumpToStateMachineReference);
	//						StateMachineSection.AddMenuEntry(FSMEditorCommands::Get().ChangeStateMachineReference);

	//						if (StateMachineNode->ShouldUseIntermediateGraph())
	//						{
	//							StateMachineSection.AddMenuEntry(FSMEditorCommands::Get().DisableIntermediateGraph);
	//						}
	//						else
	//						{
	//							StateMachineSection.AddMenuEntry(FSMEditorCommands::Get().EnableIntermediateGraph);
	//						}
	//					}
	//					else
	//					{
	//						StateMachineSection.AddMenuEntry(FSMEditorCommands::Get().ConvertToStateMachineReference);
	//					}
	//				}
	//			}
	//		}
	//		else
	//		{
	//			// Allow some state machine actions while debugging
	//			if (const USMGraphNode_StateMachineStateNode* StateMachineNode = Cast<USMGraphNode_StateMachineStateNode>(InGraphNode))
	//			{
	//				//MenuBuilder->EndSection();
	//				FToolMenuSection& ReferenceSection = Menu->AddSection("SMGraphSchemaReferenceActions", LOCTEXT("ReferenceActionsMenuHeader", "Reference Actions"));
	//				{
	//					if (StateMachineNode->IsStateMachineReference())
	//					{
	//						ReferenceSection.AddMenuEntry(FSMEditorCommands::Get().JumpToStateMachineReference);
	//					}
	//				}
	//			}
	//		}
	//	}

	//	FToolMenuSection& GraphSection = Menu->AddSection("SMGraphSchemaGraphActions", LOCTEXT("GraphActionsMenuHeader", "Graph Actions"));
	//	{
	//		GraphSection.AddMenuEntry(FSMEditorCommands::Get().GoToGraph);
	//		GraphSection.AddMenuEntry(FSMEditorCommands::Get().GoToNodeBlueprint);
	//	}

	//	FToolMenuSection& LinkSection = Menu->AddSection("SMGraphSchemaLinkActions", LOCTEXT("LinkActionsMenuHeader", "Link Actions"));
	//	{
	//		LinkSection.AddMenuEntry(FGraphEditorCommands::Get().BreakNodeLinks);
	//		if (!bIsDebugging && InGraphNode->IsA<USMGraphNode_StateNodeBase>())
	//		{
	//			LinkSection.AddMenuEntry(FSMEditorCommands::Get().CreateSelfTransition);
	//		}
	//	}
	}

	Super::GetContextMenuActions(Menu, Context);
}

const FPinConnectionResponse UEventDrivenGraphSchema::CanCreateConnection(const UEdGraphPin* PinA, const UEdGraphPin* PinB) const
{
	if (PinA->GetOwningNode() == PinB->GetOwningNode())
	{
		UEDGraphNode_StateNodeBase* State = Cast<UEDGraphNode_StateNodeBase>(PinA->GetOwningNode());

		if (!State || !State->bCanTransitionToSelf)
		{
			return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("PinErrorSameNode", "self-transitions."));
		}
	}

	//if (PinB->GetOwningNode()->IsA<USMGraphNode_AnyStateNode>())
	//{
	//	return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("PinErrorAnyStateNode", "Cannot connect to an AnyState Node."));
	//}

	//const bool bPinAIsEntry = PinA->GetOwningNode()->IsA(UEDGraphNode_EntryNode::StaticClass());
	//const bool bPinBIsEntry = PinB->GetOwningNode()->IsA(UEDGraphNode_EntryNode::StaticClass());
	//UEDGraphNode_StateNodeBase* StateNodeA = Cast<UEDGraphNode_StateNodeBase>(PinA->GetOwningNode());
	//UEDGraphNode_StateNodeBase* StateNodeB = Cast<UEDGraphNode_StateNodeBase>(PinB->GetOwningNode());

	//if (StateNodeA && StateNodeB && StateNodeA->NodeType == EDNodeType::RingQuest)
	//{
	//	int32 AQuestID(-1);
	//	int32 BQuestID(-1);

	//	if (UEDGraphNode_StateNode* StateA = Cast<UEDGraphNode_StateNode>(StateNodeA))
	//	{
	//		if (StateA->NodeType == EDNodeType::RingQuest && StateA->NodeInstance)
	//		{
	//			if (UQuest* QuestData = Cast<UQuest>(StateA->NodeInstance))
	//			{
	//				AQuestID = QuestData->QuestID;
	//			}
	//		}
	//	}
	//	if(AQuestID == -1)
	//		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("PinErrorNotStateNode", "AQuestID Error"));


	//	if (UEDGraphNode_StateNode* StateB = Cast<UEDGraphNode_StateNode>(StateNodeB))
	//	{
	//		if (StateB->NodeType == EDNodeType::RingQuest && StateB->NodeInstance)
	//		{
	//			if (UQuest* QuestData = Cast<UQuest>(StateB->NodeInstance))
	//			{
	//				BQuestID = QuestData->QuestID;
	//			}
	//		}
	//	}

	//	if (BQuestID == -1)
	//		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("PinErrorNotStateNode", "BQuestID Error"));

	//	if (AQuestID <= BQuestID)
	//	{
	//		return FPinConnectionResponse(CONNECT_RESPONSE_MAKE_WITH_CONVERSION_NODE, TEXT(""));
	//	}

	//	return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("PinErrorNotStateNode", "Reverse RingQuest Translation"));
	//}


	//if (bPinAIsEntry || bPinBIsEntry)
	//{
	//	if (bPinAIsEntry && StateNodeB)
	//	{
	//		// Check for user defined rules.
	//		FPinConnectionResponse UserResponse;
	//		if (!DoesUserAllowPlacement(PinA->GetOwningNode(), PinB->GetOwningNode(), UserResponse))
	//		{
	//			return UserResponse;
	//		}

	//		return FPinConnectionResponse(CONNECT_RESPONSE_BREAK_OTHERS_A, TEXT(""));
	//	}

	//	if (bPinBIsEntry && StateNodeA)
	//	{
	//		return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("PinErrorEntryNode", "Cannot connect a state to an entry node."));
	//	}

	//	return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("PinErrorNotStateNode", "Entry must connect to a state node."));
	//}

	//const bool bPinAIsTransition = PinA->GetOwningNode()->IsA(USMGraphNode_TransitionEdge::StaticClass());
	//const bool bPinBIsTransition = PinB->GetOwningNode()->IsA(USMGraphNode_TransitionEdge::StaticClass());

	//if (bPinAIsTransition && bPinBIsTransition)
	//{
	//	return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW, LOCTEXT("PinErrorTransition", "Cannot wire a transition to a transition."));
	//}
	//if (bPinAIsTransition)
	//{
	//	return FPinConnectionResponse(CONNECT_RESPONSE_BREAK_OTHERS_A, TEXT(""));
	//}
	//if (bPinBIsTransition)
	//{
	//	return FPinConnectionResponse(CONNECT_RESPONSE_BREAK_OTHERS_B, TEXT(""));
	//}

	//// Check for user defined rules.
	//FPinConnectionResponse UserResponse;
	//if (!DoesUserAllowPlacement(PinA->GetOwningNode(), PinB->GetOwningNode(), UserResponse))
	//{
	//	return UserResponse;
	//}

	//if (!bPinAIsTransition && !bPinBIsTransition)
	//{
	//	return FPinConnectionResponse(CONNECT_RESPONSE_MAKE_WITH_CONVERSION_NODE, TEXT("Create a transition."));
	//}

	

	return FPinConnectionResponse(CONNECT_RESPONSE_MAKE_WITH_CONVERSION_NODE, TEXT(""));

	// return FPinConnectionResponse(CONNECT_RESPONSE_MAKE, TEXT(""));
}

bool UEventDrivenGraphSchema::TryCreateConnection(UEdGraphPin* PinA, UEdGraphPin* PinB) const
{
	
	if (CanCreateConnection(PinA, PinB).Response == CONNECT_RESPONSE_DISALLOW)
	{
		return false;
	}

	if (PinB->Direction == PinA->Direction)
	{
		if (UEDGraphNode_StateNodeBase* Node = Cast<UEDGraphNode_StateNodeBase>(PinB->GetOwningNode()))
		{
			if (PinA->Direction == EGPD_Input)
			{
				PinB = Node->GetOutputPin();
			}
			else
			{
				PinB = Node->GetInputPin();
			}
		}
	}

	const bool bModified = (PinA && PinB) ? UEdGraphSchema::TryCreateConnection(PinA, PinB) : false;

	// 添加日志
	if (Cast<UEDGraphNode_Base>(PinA->GetOwningNode()) && Cast<UEDGraphNode_Base>(PinB->GetOwningNode())
		&& (!Cast<UEDGraphNode_Base>(PinA->GetOwningNode())->NodeName.IsEmpty() || !Cast<UEDGraphNode_Base>(PinB->GetOwningNode())->NodeName.IsEmpty()))
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("TryCreateConnection: %s, %s"),
			*(Cast<UEDGraphNode_Base>(PinA->GetOwningNode())->NodeName), *(Cast<UEDGraphNode_Base>(PinB->GetOwningNode())->NodeName));
	}
	
	if (bModified)
	{
		auto FromNode = Cast<UEDGraphNode_StateNodeBase>(PinA->GetOwningNode());
		auto ToNode = Cast<UEDGraphNode_StateNodeBase>(PinB->GetOwningNode());
		if(FromNode && ToNode)
		{
			if(FromNode == ToNode)
			{
				return bModified;
			}
			auto FromRingObj = Cast<UQuestRing>(FromNode->NodeInstance);
			auto ToRingObj = Cast<UQuestRing>(ToNode->NodeInstance);
			if(FromRingObj && ToRingObj)
			{
				if(ToRingObj->QuestObjectivesEditor.IsValid())
				{
					auto EDGraphEditor = ToRingObj->QuestObjectivesEditor.Pin().Get();
					FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(EDGraphEditor);
					if (QuestEditor)
					{
						if(QuestEditor->bLoadingChapterGraph || QuestEditor->bLoadingQuestGraph || QuestEditor->bLoadingRingGraph)
						{
							return bModified;
						}
						QuestEditor->MarkAssetForDirty(ToRingObj);
					}
					if(!IsValid(ToRingObj->PreRingRelations))
					{
						auto FromRingInfo = NewObject<UPreRingID>();
						FromRingInfo->PreRingID = FromRingObj->RingID;
						ToRingObj->PreRingRelations = FromRingInfo;
						ToRingObj->PostEditChange();
					}
					if(IsValid(ToRingObj->ApplyType) && ToRingObj->ApplyType->GetClass()->GetName() == "RT_AUTO_C")
					{
						if(auto TransitionApplyType = QuestEditor->GetTransitionApplyType())
						{
							ToRingObj->ApplyType = TransitionApplyType;
						}
					}
				}
			}
		}
	}

	return bModified;
}

bool UEventDrivenGraphSchema::CreateAutomaticConversionNodeAndConnections(UEdGraphPin* A, UEdGraphPin* B) const
{
	UEDGraphNode_Base* NodeA = Cast<UEDGraphNode_Base>(A->GetOwningNode());
	UEDGraphNode_Base* NodeB = Cast<UEDGraphNode_Base>(B->GetOwningNode());

	if (NodeA == nullptr || NodeB == nullptr)
		return false;

	if (NodeA->GetOutputPin() == nullptr || NodeB->GetInputPin() == nullptr)
		return false;

	//if (NodeA->NodeType == EDNodeType::QuestBegin
	//|| NodeA->NodeType == EDNodeType::QuestProgress)
	//{
	//	return false;
	//}

	FVector2D InitPos((NodeA->NodePosX + NodeB->NodePosX) / 2, (NodeA->NodePosY + NodeB->NodePosY) / 2);

	FEDGraphSchemaAction_PlaceNode Action;
	Action.NodeTemplate = NewObject<UEDGraphNode_Transition>(NodeA->GetGraph());

	UEDGraphNode_Transition* EdgeNode = CastChecked<UEDGraphNode_Transition>(Action.PerformAction(NodeA->GetGraph(), nullptr, InitPos, false));

	
	if (A->Direction == EGPD_Output)
	{
		if (NodeA->NodeType == EDNodeType::QuestEnd)
			// 这里由于连接的是Node和Node, 走的是默认的Pin, 和Pin A B可能不是同一个, End需要区分Success和Fail
			EdgeNode->CreateConnections(A, B);
		else
			EdgeNode->CreateConnections(NodeA, NodeB);
	}
	else
	{
		EdgeNode->CreateConnections(NodeB, NodeA);
	}

	if (NodeA->NodeType == EDNodeType::RingQuest)
	{
		EdgeNode->NodeType = EDNodeType::RingQuestCondition;

		if (class UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
		{
			FSoftObjectPath SoftPath = QuestSettings->RingConditionClass;
			if (SoftPath.IsValid())
			{
				UObject* Obj = SoftPath.ResolveObject();
				if (Obj == nullptr)
				{
					Obj = SoftPath.TryLoad();
				}
				if (Obj)
				{
					UClass* Class = Obj->GetClass();
					if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
					{
						Class = BPObj->GeneratedClass;
					}

					int32 B_QuestID(-1);
					if (UEDGraphNode_StateNode* StateB = Cast<UEDGraphNode_StateNode>(NodeB))
					{
						if (StateB->NodeType == EDNodeType::RingQuest && StateB->NodeInstance)
						{
							if (UQuest* QuestData = Cast<UQuest>(StateB->NodeInstance))
							{
								B_QuestID = QuestData->QuestID;
							}
						}
					}

					URingTaskConditionBase* CurRingTaskConditionObj(nullptr);

					if (UEDGraphNode_StateNode* StateA = Cast<UEDGraphNode_StateNode>(NodeA))
					{
						if (StateA->NodeType == EDNodeType::RingQuest && StateA->NodeInstance)
						{
							if (UQuest* QuestData = Cast<UQuest>(StateA->NodeInstance))
							{
								TArray<URingTaskConditionBase*> CondList;
								CondList.Append(QuestData->NextTaskInfoList);
								// QuestData->NextTaskInfoList.Reset(CondList.Num());

								const TArray<UEdGraphPin*> StateAPins = StateA->GetAllPins();
								for (const UEdGraphPin* FromPin : StateAPins)
								{
									if (FromPin && FromPin->Direction == EEdGraphPinDirection::EGPD_Output)
									{
										TArray<UEdGraphPin*> LinkTos = FromPin->LinkedTo;
										for (UEdGraphPin* ToPin : LinkTos)
										{
											if (ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
											{
												UEdGraphNode* ToNode = ToPin->GetOwningNodeUnchecked();
												if (UEDGraphNode_Transition* NextT = Cast<UEDGraphNode_Transition>(ToNode))
												{
													UEdGraphPin* NextTToPin = NextT->GetOutputPin();
													if (NextTToPin)
													{
														TArray<UEdGraphPin*> NextTToPin_LinkTos = NextTToPin->LinkedTo;
														for (UEdGraphPin* NextTToPin_ToPin : NextTToPin_LinkTos)
														{
															if (NextTToPin_ToPin&& NextTToPin_ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
															{
																ToNode = NextTToPin_ToPin->GetOwningNodeUnchecked();
															}
														}
													}
												}

												if (UEDGraphNode_StateNode* NextQuest = Cast<UEDGraphNode_StateNode>(ToNode))
												{
													if (NextQuest->NodeType == EDNodeType::RingQuest && NextQuest->NodeInstance)
													{
														if (UQuest* NextQuestData = Cast<UQuest>(NextQuest->NodeInstance))
														{
															URingTaskConditionBase* _RingTaskConditionObj(nullptr);

															for (URingTaskConditionBase* Elem : CondList)
															{
																if (IsValid(Elem) && Elem->NextTaskID == NextQuestData->QuestID)
																{
																	_RingTaskConditionObj = Elem;
																	break;
																}
															}

															if (!_RingTaskConditionObj)
															{
																_RingTaskConditionObj = NewObject<URingTaskConditionBase>(QuestData, Class);
																_RingTaskConditionObj->NextTaskID = NextQuestData->QuestObjectID;
															}

															QuestData->NextTaskInfoList.AddUnique(_RingTaskConditionObj);
															// todo LuaVersion
															UPackage* QuestDataPackage = QuestData->GetPackage();
															if (QuestDataPackage) QuestDataPackage->SetDirtyFlag(true);
															QuestData->NextTaskInfoNotifyQuestEditor();

															if (_RingTaskConditionObj && _RingTaskConditionObj->NextTaskID == B_QuestID)
															{
																CurRingTaskConditionObj = _RingTaskConditionObj;
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}

					EdgeNode->NodeInstance = CurRingTaskConditionObj;
				}
			}
		}
	}
	else if(NodeA->NodeType == EDNodeType::ChapterRing)
	{
		EdgeNode->NodeType = EDNodeType::ChapterRingCondition;

		if (class UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
		{
			FSoftObjectPath SoftPath = QuestSettings->RingConditionClass;
			if (SoftPath.IsValid())
			{
				UObject* Obj = SoftPath.ResolveObject();
				if (Obj == nullptr)
				{
					Obj = SoftPath.TryLoad();
				}
				if (Obj)
				{
					UClass* Class = Obj->GetClass();
					if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
					{
						Class = BPObj->GeneratedClass;
					}

					int32 B_RingID(-1);
					if (UEDGraphNode_StateNode* StateB = Cast<UEDGraphNode_StateNode>(NodeB))
					{
						if (StateB->NodeType == EDNodeType::ChapterRing && StateB->NodeInstance)
						{
							if (UQuestRing* QuestData = Cast<UQuestRing>(StateB->NodeInstance))
							{
								B_RingID = QuestData->RingID;
							}
						}
						if (StateB->NodeType == EDNodeType::ChapterEnd && StateB->NodeInstance)
						{
							if (UChapterEnd* QuestData = Cast<UChapterEnd>(StateB->NodeInstance))
							{
								B_RingID = QuestData->NextRingID;
							}
						}
					}

					URingTaskConditionBase* CurRingTaskConditionObj(nullptr);

					if (UEDGraphNode_StateNode* StateA = Cast<UEDGraphNode_StateNode>(NodeA))
					{
						if (StateA->NodeType == EDNodeType::ChapterRing && StateA->NodeInstance)
						{
							if (UQuestRing* QuestData = Cast<UQuestRing>(StateA->NodeInstance))
							{
								TArray<URingTaskConditionBase*> CondList;
								CondList.Append(QuestData->NextTaskInfoList);

								// NextTaskInfoList 在加载时 FQuestImportLua::FillRingNextTaskWithLuaStr 先初始化，没必要重新创建一遍
								// 并且若清空 NextTaskInfoList，重新构造的 URingTaskConditionBase* _RingTaskConditionObj 不会读原有的 Conditions 数据
								// QuestData->NextTaskInfoList.Reset(CondList.Num());

								const TArray<UEdGraphPin*> StateAPins = StateA->GetAllPins();
								for (const UEdGraphPin* FromPin : StateAPins)
								{
									// 连接源GraphNode接出点为FromPin
									if(!FromPin || FromPin->Direction != EEdGraphPinDirection::EGPD_Output)
									{
										continue;
									}
									// 接出点接出的箭头落点在LinkTos里
									TArray<UEdGraphPin*> LinkTos = FromPin->LinkedTo;
									for (UEdGraphPin* ToPin : LinkTos)
									{
										if(!ToPin || ToPin->Direction != EEdGraphPinDirection::EGPD_Input)
										{
											continue;
										}
										// 接出点箭头所属节点
										UEdGraphNode* ToNode = ToPin->GetOwningNodeUnchecked();
										if (UEDGraphNode_Transition* NextT = Cast<UEDGraphNode_Transition>(ToNode))
										{
											UEdGraphPin* NextTToPin = NextT->GetOutputPin();
											// 箭头指向的节点
											if (NextTToPin)
											{
												TArray<UEdGraphPin*> NextTToPin_LinkTos = NextTToPin->LinkedTo;
												for (UEdGraphPin* NextTToPin_ToPin : NextTToPin_LinkTos)
												{
													if (NextTToPin_ToPin&& NextTToPin_ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
													{
														ToNode = NextTToPin_ToPin->GetOwningNodeUnchecked();
													}
												}
											}
										}

										if (UEDGraphNode_StateNode* NextQuest = Cast<UEDGraphNode_StateNode>(ToNode))
										{
											if ((NextQuest->NodeType == EDNodeType::ChapterRing || NextQuest->NodeType == EDNodeType::ChapterEnd)
												&& NextQuest->NodeInstance)
											{
												// 新创建的 RingID 可以为负数
												bool bInitNextRingID = false;
												int NextRingID = -1;
												if (UQuestRing* NextRingData = Cast<UQuestRing>(NextQuest->NodeInstance))
												{
													bInitNextRingID = true;
													// 由于可能改id，RingID后续可能会变化，所以使用 QuestObjectID，如果改 id 了则在最终保存时去处理
													NextRingID = NextRingData->QuestObjectID;
												}
												else if(UChapterEnd* EndData = Cast<UChapterEnd>(NextQuest->NodeInstance))
												{
													bInitNextRingID = true;
													NextRingID = EndData->NextRingID;
												}
												
												if (bInitNextRingID)
												{
													URingTaskConditionBase* _RingTaskConditionObj(nullptr);
													for (URingTaskConditionBase* Elem : CondList)
													{
														if (IsValid(Elem) && Elem->NextTaskID == NextRingID)
														{
															_RingTaskConditionObj = Elem;
															break;
														}
													}
													if (!_RingTaskConditionObj)
													{
														_RingTaskConditionObj = NewObject<URingTaskConditionBase>(QuestData, Class);
														_RingTaskConditionObj->NextTaskID = NextRingID;
													}
													bool bDuplicated = false;
													for(auto NextTaskInfoIns : QuestData->NextTaskInfoList)
													{
														if (NextTaskInfoIns && NextTaskInfoIns->NextTaskID == NextRingID)
														{
															bDuplicated = true;
															CurRingTaskConditionObj = NextTaskInfoIns;
															break;
														}
													}
													if(bDuplicated)
													{
														continue;
													}
													QuestData->NextTaskInfoList.AddUnique(_RingTaskConditionObj);
													// todo LuaVersion
													UPackage* QuestDataPackage = QuestData->GetPackage();
													if (QuestDataPackage) QuestDataPackage->SetDirtyFlag(true);
													QuestData->NextTaskInfoNotifyQuestEditor();
													if (_RingTaskConditionObj && _RingTaskConditionObj->NextTaskID == B_RingID)
													{
														CurRingTaskConditionObj = _RingTaskConditionObj;
													}
												}
											}
										}
									}
								}
							}
						}
					}

					EdgeNode->NodeInstance = CurRingTaskConditionObj;
				}
			}
		}
	}
	else if (NodeA->NodeType == EDNodeType::QuestAction)
	{
		EdgeNode->NodeType = EDNodeType::QuestCondition;

		if (class UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
		{
			FSoftObjectPath SoftPath = QuestSettings->ActionConditionBaseClass;
			if (SoftPath.IsValid())
			{
				UObject* Obj = SoftPath.ResolveObject();
				if (Obj == nullptr)
				{
					Obj = SoftPath.TryLoad();
				}
				if (Obj)
				{
					UClass* Class = Obj->GetClass();
					if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
					{
						Class = BPObj->GeneratedClass;
					}

					if (UEDGraphNode_StateNode* StateA = Cast<UEDGraphNode_StateNode>(NodeA))
					{
						if (StateA->NodeType == EDNodeType::QuestAction && StateA->NodeInstance)
						{
							if (UEDGraphNode_StateNode* StateB = Cast<UEDGraphNode_StateNode>(NodeB))
							{
								if (StateB->NodeType == EDNodeType::QuestAction && StateB->NodeInstance)
								{
									if (UQuestActionBase* QuestActionData = Cast<UQuestActionBase>(StateA->NodeInstance))
									{
										EdgeNode->TransitionCondition = NewObject<UQuestActionConditionBase>(EdgeNode, Class);
									}		
								}
							}
						}
					}
				}
			}
		}

		// 有新连接, 通知StateIdx更新
		if (UEDGraphBase* EDGraph = Cast<UEDGraphBase>(NodeA->GetGraph()))
		{
			if (EDGraph->QuestObjectivesEditor.IsValid())
			{
				auto EDGraphEditor = EDGraph->QuestObjectivesEditor.Pin().Get();
				if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(EDGraphEditor))
				{
					QuestEditor->OnRefreshActionStateIdx(EDGraph);
				}
			}
		}
	}
	else if (NodeA->NodeType == EDNodeType::QuestTarget)
	{
		if (UEDGraphBase* EDGraph = Cast<UEDGraphBase>(NodeA->GetGraph()))
		{
			if (EDGraph->QuestObjectivesEditor.IsValid())
			{
				auto EDGraphEditor = EDGraph->QuestObjectivesEditor.Pin().Get();
				if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(EDGraphEditor))
				{
					QuestEditor->OnRefreshTargetStateIdx(EDGraph);
				}
			}
		}
	}

	// If this is a transition being placed as part of a new state node then the state node will handle this.
	// This only matters if this transition is being connected after a state has been placed.
	//TArray<UClass*> TransitionClasses;
	//FSMBlueprintEditorUtils::GetAllNodeSubClasses(USMTransitionInstance::StaticClass(), TransitionClasses);

	// Self transition.
	//if (NodeA == NodeB)
	//{
	//	if (USMTransitionInstance* TransitionInstance = EdgeNode->GetNodeTemplateAs<USMTransitionInstance>())
	//	{
	//		TransitionInstance->SetCanEvalWithStartState(false);
	//	}
	//}

	//UBlueprint* Blueprint = FBlueprintEditorUtils::FindBlueprintForGraphChecked(EdgeNode->GetBoundGraph());
	//FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);

	return true;
}

FConnectionDrawingPolicy* UEventDrivenGraphSchema::CreateConnectionDrawingPolicy(int32 InBackLayerID, int32 InFrontLayerID,
	float InZoomFactor, const FSlateRect& InClippingRect, FSlateWindowElementList& InDrawElements,
	UEdGraph* InGraphObj) const
{
	return new EDGraphLineDrawingPolicy(InBackLayerID, InFrontLayerID, InZoomFactor, InClippingRect, InDrawElements, InGraphObj);
}

FLinearColor UEventDrivenGraphSchema::GetPinTypeColor(const FEdGraphPinType& PinType) const
{
	return FLinearColor::Gray;
}

void UEventDrivenGraphSchema::GetGraphDisplayInformation(const UEdGraph& Graph, FGraphDisplayInfo& DisplayInfo) const
{
	Super::GetGraphDisplayInformation(Graph, DisplayInfo);

	//if (const USMGraphNode_StateMachineStateNode* StateNode = Cast<const USMGraphNode_StateMachineStateNode>(Graph.GetOuter()))
	//{
	//	FString NodeType = "state machine";
	//	if (StateNode->IsA<USMGraphNode_StateMachineParentNode>())
	//	{
	//		NodeType = "parent";
	//	}
	//	else if (StateNode->IsStateMachineReference())
	//	{
	//		NodeType = "reference";
	//	}

	//	DisplayInfo.PlainName = FText::Format(LOCTEXT("StateNameGraphTitle", "{0} ({1})"), FText::FromString(StateNode->GetStateName()), FText::FromString(NodeType));
	//}
	//DisplayInfo.DisplayName = DisplayInfo.PlainName;
	//DisplayInfo.DocExcerptName = nullptr;
	//DisplayInfo.Tooltip = FText::FromName(Graph.GetFName());
}

void UEventDrivenGraphSchema::BreakNodeLinks(UEdGraphNode& TargetNode) const
{
	//const FScopedTransaction Transaction(NSLOCTEXT("UnrealEd", "GraphEd_BreakNodeLinks", "Break Node Links"));

	//// Most nodes work fine without this. StateMachineEntry node does not.
	//UBlueprint* Blueprint = FBlueprintEditorUtils::FindBlueprintForNodeChecked(&TargetNode);
	Super::BreakNodeLinks(TargetNode);
	//FBlueprintEditorUtils::MarkBlueprintAsModified(Blueprint);
}

void UEventDrivenGraphSchema::BreakPinLinks(UEdGraphPin& TargetPin, bool bSendsNodeNotification) const
{
	const FScopedTransaction Transaction(NSLOCTEXT("UnrealEd", "GraphEd_BreakPinLinks", "Break Pin Links"));

	if (TargetPin.GetOwningNode())
	{
		if (UEDGraphBase* EDGraph = Cast<UEDGraphBase>(TargetPin.GetOwningNode()->GetGraph()))
		{
			if (EDGraph->QuestObjectivesEditor.IsValid())
			{
				auto EDGraphEditor = EDGraph->QuestObjectivesEditor.Pin().Get();
				if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(EDGraphEditor))
				{
					for (auto LinkedTo : TargetPin.LinkedTo)
					{
						if (!LinkedTo) continue;
						
						if (auto TransitionNode = Cast<UEDGraphNode_Transition>(LinkedTo->GetOwningNode()))
						{
							QuestEditor->OnDeleteTransitionNode(TransitionNode);
						}
					}
				}
			}
		}
	}

	// Most nodes work fine without this. StateMachineEntry node does not.
	//UBlueprint* Blueprint = FBlueprintEditorUtils::FindBlueprintForNodeChecked(TargetPin.GetOwningNode());
	Super::BreakPinLinks(TargetPin, bSendsNodeNotification);
	//FBlueprintEditorUtils::MarkBlueprintAsModified(Blueprint);
}

void UEventDrivenGraphSchema::BreakSinglePinLink(UEdGraphPin* SourcePin, UEdGraphPin* TargetPin) const
{
	const FScopedTransaction Transaction(NSLOCTEXT("UnrealEd", "GraphEd_BreakSinglePinLink", "Break Pin Link"));

	// Most nodes work fine without this. StateMachineEntry node does not.
	//UBlueprint* Blueprint = FBlueprintEditorUtils::FindBlueprintForNodeChecked(TargetPin->GetOwningNode());
	Super::BreakSinglePinLink(SourcePin, TargetPin);
	//FBlueprintEditorUtils::MarkBlueprintAsModified(Blueprint);
}

void UEventDrivenGraphSchema::SetPinBeingDroppedOnNode(UEdGraphPin* InSourcePin) const
{
	Super::SetPinBeingDroppedOnNode(InSourcePin);
}

UEdGraphPin* UEventDrivenGraphSchema::DropPinOnNode(UEdGraphNode* InTargetNode, const FName& InSourcePinName, const FEdGraphPinType& InSourcePinType, EEdGraphPinDirection InSourcePinDirection) const
{
	UEdGraphPin* Result = nullptr;
	for (auto Pin : InTargetNode->GetAllPins())
	{
		if (Pin->GetName() == "In")
		{
			Result = Pin;
			break;
		}
	}
	return Result;
}

bool UEventDrivenGraphSchema::SupportsDropPinOnNode(UEdGraphNode* InTargetNode, const FEdGraphPinType& InSourcePinType, EEdGraphPinDirection InSourcePinDirection, FText& OutErrorMessage) const
{
	return true;
	//return Cast<USMGraphNode_StateNode>(InTargetNode) != nullptr;
}

void UEventDrivenGraphSchema::HandleGraphBeingDeleted(UEdGraph& GraphBeingRemoved) const
{
	//if (UBlueprint* Blueprint = FBlueprintEditorUtils::FindBlueprintForGraph(&GraphBeingRemoved))
	//{
	//	if (USMGraph* StateMachineGraph = Cast<USMGraph>(&GraphBeingRemoved))
	//	{
	//		bool bHasBoundGraph = false;

	//		UEdGraphNode* StateMachineNode = nullptr;
	//		if (USMGraphK2Node_StateMachineNode* StateMachineK2Node = StateMachineGraph->GetOwningStateMachineK2Node())
	//		{
	//			StateMachineNode = StateMachineK2Node;
	//			bHasBoundGraph = StateMachineK2Node->GetStateMachineGraph() != nullptr;
	//		}
	//		else if (USMGraphNode_StateMachineStateNode* StateMachineStateNode = StateMachineGraph->GetOwningStateMachineNodeWhenNested())
	//		{
	//			StateMachineNode = StateMachineStateNode;
	//			bHasBoundGraph = !StateMachineStateNode->IsSwitchingGraphTypes() && StateMachineStateNode->GetBoundGraph() != nullptr;
	//		}
	//		else
	//		{
	//			// No entry node.
	//			check(false);
	//		}

	//		// Let the node delete first-- it will trigger graph removal. Helps with undo buffer transaction.
	//		if (bHasBoundGraph)
	//		{
	//			FBlueprintEditorUtils::RemoveNode(Blueprint, StateMachineNode, true);
	//			return;
	//		}

	//		// Remove this graph from the parent graph.
	//		UEdGraph* ParentGraph = StateMachineNode->GetGraph();
	//		ParentGraph->SubGraphs.Remove(StateMachineGraph);

	//		// Remove all contained states and transitions.
	//		TArray<UEdGraphNode*> AllNodes;
	//		StateMachineGraph->GetNodesOfClass<UEdGraphNode>(AllNodes);

	//		// Remove all sub nodes.
	//		for (UEdGraphNode* Node : AllNodes)
	//		{
	//			FBlueprintEditorUtils::RemoveNode(Blueprint, Node, true);
	//		}
	//	}

	//	FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);
	//}

	Super::HandleGraphBeingDeleted(GraphBeingRemoved);
}

bool UEventDrivenGraphSchema::DoesUserAllowPlacement(const UEdGraphNode* A, const UEdGraphNode* B, FPinConnectionResponse& ResponseOut)
{
	return true;
}

bool UEventDrivenGraphSchema::CanReplaceNode(const UEdGraphNode* InGraphNode)
{
	bool bCanAddStateMachine, bCanAddStateMachineRef, bCanAddState, bCanAddConduit, bCanAddParent;
	return CanReplaceNodeWith(InGraphNode, bCanAddStateMachine, bCanAddStateMachineRef, bCanAddState, bCanAddConduit, bCanAddParent);
}

bool UEventDrivenGraphSchema::CanReplaceNodeWith(const UEdGraphNode* InGraphNode, bool& bStateMachine, bool& bStateMachineRef,
	bool& bState, bool& bConduit, bool& bStateMachineParent)
{
	return false;
	//if (!InGraphNode->IsA<USMGraphNode_StateNodeBase>())
	//{
	//	return false;
	//}

	//bool bCanAddStateMachine = !InGraphNode->IsA<USMGraphNode_StateMachineStateNode>() || InGraphNode->IsA<USMGraphNode_StateMachineParentNode>();
	//bool bCanAddStateMachineRef = bCanAddStateMachine;
	//bool bCanAddStateMachineParent = !InGraphNode->IsA<USMGraphNode_StateMachineParentNode>();
	//bCanAddStateMachineParent = false;
	//bool bCanAddState = !InGraphNode->IsA<USMGraphNode_StateNode>();
	//bool bCanAddConduit = !InGraphNode->IsA<USMGraphNode_ConduitNode>();

	//if (USMGraphNode_StateMachineStateNode const* StateMachineNode = Cast<USMGraphNode_StateMachineStateNode>(InGraphNode))
	//{
	//	if (!StateMachineNode->IsA<USMGraphNode_StateMachineParentNode>())
	//	{
	//		if (StateMachineNode->IsStateMachineReference())
	//		{
	//			bCanAddStateMachine = true;
	//			bCanAddStateMachineRef = false;
	//		}
	//		else
	//		{
	//			bCanAddStateMachine = false;
	//			bCanAddStateMachineRef = true;
	//		}
	//	}
	//}

	//// Only allow parent to be set if the blueprint is a child.
	//if (bCanAddStateMachineParent)
	//{
	//	TArray<USMBlueprintGeneratedClass*> ParentClasses;
	//	UBlueprint* OwnerBlueprint = FBlueprintEditorUtils::FindBlueprintForNodeChecked(InGraphNode);
	//	bCanAddStateMachineParent = FSMBlueprintEditorUtils::TryGetParentClasses(OwnerBlueprint, ParentClasses);
	//}

	//bStateMachine = bCanAddStateMachine;
	//bStateMachineRef = bCanAddStateMachineRef;
	//bState = bCanAddState;
	//bConduit = bCanAddConduit;
	//bStateMachineParent = bCanAddStateMachineParent;

	//return bStateMachine || bStateMachineRef || bState || bConduit || bStateMachineParent;
}

void UEventDrivenGraphSchema::CreateQuestNode(UEDGraphBase* EDGraph, FVector2D Location)
{
	TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction(new FEDGraphSchemaAction_PlaceNode(FText::GetEmpty(), LOCTEXT("AddQuest", "AddQuest"), LOCTEXT("AddQuestTooltip", "AddQuest"), 0));
	NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(EDGraph);
	NewNodeAction->NodeType = EDNodeType::RingQuest;
	NewNodeAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;

	NewNodeAction->PerformAction(EDGraph, nullptr, Location, false);
}

void UEventDrivenGraphSchema::CreateQuestNode(UEDGraphBase* EDGraph, UEdGraphPin* FromPin, FVector2D Location)
{
	TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction(new FEDGraphSchemaAction_PlaceNode(FText::GetEmpty(), LOCTEXT("AddQuest", "AddQuest"), LOCTEXT("AddQuestTooltip", "AddQuest"), 0));
	NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(EDGraph);
	NewNodeAction->NodeType = EDNodeType::RingQuest;
	NewNodeAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;

	NewNodeAction->PerformAction(EDGraph, FromPin, Location, false);
}

void UEventDrivenGraphSchema::CreateQuestNode(class UEDGraphBase* EDGraph, UQuest* NodeInstance, FVector2D Location, bool bInitilization)
{
	TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction(new FEDGraphSchemaAction_PlaceNode(FText::GetEmpty(), LOCTEXT("AddQuest", "AddQuest"), LOCTEXT("AddQuestTooltip", "AddQuest"), 0));
	NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(EDGraph);
	if (UEDGraphNode_Base* _NewNode = Cast<UEDGraphNode_Base>(NewNodeAction->NodeTemplate))
		_NewNode->NodeInstance = NodeInstance;
	NewNodeAction->bInitialization = bInitilization;
	NewNodeAction->NodeType = EDNodeType::RingQuest;
	NewNodeAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;

	NewNodeAction->PerformAction(EDGraph, nullptr, Location, false);
}

void UEventDrivenGraphSchema::CreateRingNode(UEDGraphBase* EDGraph, UQuestRing* NodeInstance, FVector2D Location, bool bInitilization)
{
	TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction(new FEDGraphSchemaAction_PlaceNode(FText::GetEmpty(), LOCTEXT("AddRing", "AddRing"), LOCTEXT("AddRingTooltip", "AddRing"), 0));
	NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(EDGraph);
	if (UEDGraphNode_Base* _NewNode = Cast<UEDGraphNode_Base>(NewNodeAction->NodeTemplate))
		_NewNode->NodeInstance = NodeInstance;
	NewNodeAction->bInitialization = bInitilization;
	NewNodeAction->NodeType = EDNodeType::ChapterRing;
	NewNodeAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;

	NewNodeAction->PerformAction(EDGraph, nullptr, Location, false);
}

void UEventDrivenGraphSchema::CreateChapterEndNode(UEDGraphBase* EDGraph, UChapterEnd* NodeInstance, FVector2D Location, bool bInitilization)
{
	TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction(new FEDGraphSchemaAction_PlaceNode(FText::GetEmpty(), LOCTEXT("AddChapterEnd", "AddChapterEnd"), LOCTEXT("AddChapterEndTooltip", "AddChapterEnd"), 0));
	NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(EDGraph);
	if (UEDGraphNode_Base* _NewNode = Cast<UEDGraphNode_Base>(NewNodeAction->NodeTemplate))
		_NewNode->NodeInstance = NodeInstance;
	NewNodeAction->bInitialization = bInitilization;
	NewNodeAction->NodeType = EDNodeType::ChapterEnd;
	NewNodeAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;

	NewNodeAction->PerformAction(EDGraph, nullptr, Location, false);
}

void UEventDrivenGraphSchema::CreateQuestTargetNode(class UEDGraphBase* EDGraph, UQuestTargetBase* TargetInstance, UEdGraphPin* FromPin, FVector2D Location)
{
	TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction(new FEDGraphSchemaAction_PlaceNode(FText::GetEmpty(), LOCTEXT("AddTarget", "AddTarget"), LOCTEXT("AddTargetTooltip", "AddTarget"), 0));
	NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(EDGraph);
	NewNodeAction->NodeType = EDNodeType::QuestTarget;
	NewNodeAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;
	if (UEDGraphNode_Base* NewNode = Cast<UEDGraphNode_Base>(NewNodeAction->NodeTemplate))
		NewNode->NodeInstance = TargetInstance;
	NewNodeAction->PerformAction(EDGraph, FromPin, Location, false);
}

void UEventDrivenGraphSchema::CreateActionNode(class UEDGraphBase* EDGraph, UQuestActionBase* ActionInstance, UEdGraphPin* FromPin, FVector2D Location)
{
	TSharedPtr<FEDGraphSchemaAction_PlaceNode> NewNodeAction(new FEDGraphSchemaAction_PlaceNode(FText::GetEmpty(), LOCTEXT("AddTarget", "AddTarget"), LOCTEXT("AddTargetTooltip", "AddTarget"), 0));
	NewNodeAction->NodeTemplate = NewObject<UEDGraphNode_StateNode>(EDGraph);
	NewNodeAction->NodeType = EDNodeType::QuestAction;
	NewNodeAction->QuestObjectivesEditor = EDGraph->QuestObjectivesEditor;
	if (UEDGraphNode_Base* NewNode = Cast<UEDGraphNode_Base>(NewNodeAction->NodeTemplate))
		NewNode->NodeInstance = ActionInstance;
	NewNodeAction->PerformAction(EDGraph, FromPin, Location, false);
}

void UEventDrivenGraphSchema::GetReplaceWithMenuActions(FMenuBuilder& MenuBuilder, const UEdGraphNode* InGraphNode) const
{
	bool bCanAddStateMachine, bCanAddStateMachineRef, bCanAddState, bCanAddConduit, bCanAddParent;

	if (!CanReplaceNodeWith(InGraphNode, bCanAddStateMachine, bCanAddStateMachineRef, bCanAddState, bCanAddConduit, bCanAddParent))
	{
		return;
	}

	MenuBuilder.BeginSection("SMGraphSchemaNodeReplacementActions", LOCTEXT("NodeActionsReplacementMenuHeader", "Replacement"));

	//if (bCanAddStateMachine)
	//{
	//	MenuBuilder.AddMenuEntry(FSMEditorCommands::Get().ReplaceWithStateMachine);
	//}

	//if (bCanAddStateMachineRef)
	//{
	//	MenuBuilder.AddMenuEntry(FSMEditorCommands::Get().ReplaceWithStateMachineReference);
	//}

	//if (bCanAddParent)
	//{
	//	MenuBuilder.AddMenuEntry(FSMEditorCommands::Get().ReplaceWithStateMachineParent);
	//}

	//if (bCanAddState)
	//{
	//	MenuBuilder.AddMenuEntry(FSMEditorCommands::Get().ReplaceWithState);
	//}

	//if (bCanAddConduit)
	//{
	//	MenuBuilder.AddMenuEntry(FSMEditorCommands::Get().ReplaceWithConduit);
	//}

	MenuBuilder.EndSection();
}

#undef LOCTEXT_NAMESPACE


UE_ENABLE_OPTIMIZATION_SHIP