#pragma once

#include "CoreMinimal.h"
#include "EdGraph/EdGraphSchema.h"
#include "EdGraphSchema_K2.h"
#include "EdGraph/EdGraphSchema.h"
#include "../Nodes/EDNodeDefine.h"
#include "QuestTemplate.h"

#include "EventDrivenGraphSchema.generated.h"


UCLASS()
class UEDGraphBase : public UEdGraph
{
	GENERATED_BODY()

public:

	TWeakPtr<class FAssetEditorToolkit> QuestObjectivesEditor;

	TWeakPtr<SGraphEditor> GraphEditor;
	
	TWeakObjectPtr<UObject> UserDataObj;

};


USTRUCT()
struct FEDGraphSchemaAction_PlaceNode : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

public:
	FEDGraphSchemaAction_PlaceNode() : NodeTemplate(nullptr), NodeClass(nullptr) {}

	FEDGraphSchemaAction_PlaceNode(const FText& InNodeCategory, const FText& InMenuDesc, const FText& InToolTip, const int32 InGrouping)
		: FEdGraphSchemaAction(InNodeCategory, InMenuDesc, InToolTip, InGrouping), NodeTemplate(nullptr), NodeClass(nullptr) {}

	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;

	bool bInitialization = true;
	
	TObjectPtr<UEdGraphNode> NodeTemplate;

	TObjectPtr<UClass> NodeClass;

	EDNodeType NodeType;

	TWeakPtr<class FAssetEditorToolkit> QuestObjectivesEditor;
};


USTRUCT()
struct FEDGraphSchemaAction_NewComment : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY();

	FEDGraphSchemaAction_NewComment()
		: FEdGraphSchemaAction()
	{}

	FEDGraphSchemaAction_NewComment(FText InNodeCategory, FText InMenuDesc, FText InToolTip, const int32 InGrouping)
		: FEdGraphSchemaAction(MoveTemp(InNodeCategory), MoveTemp(InMenuDesc), MoveTemp(InToolTip), InGrouping)
	{}

	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
};

UCLASS()
class UEventDrivenGraphSchema : public UEdGraphSchema
{
	GENERATED_UCLASS_BODY()

public:
	// UEdGraphSchema
	virtual void CreateDefaultNodesForGraph(UEdGraph& Graph) const override;
	virtual EGraphType GetGraphType(const UEdGraph* TestEdGraph) const override;
	virtual void GetGraphContextActions(FGraphContextMenuBuilder& ContextMenuBuilder) const override;
	virtual void GetContextMenuActions(class UToolMenu* Menu, class UGraphNodeContextMenuContext* Context) const override;
	virtual const FPinConnectionResponse CanCreateConnection(const UEdGraphPin* PinA, const UEdGraphPin* PinB) const override;
	
	virtual bool TryCreateConnection(UEdGraphPin* PinA, UEdGraphPin* PinB) const override;
	virtual bool CreateAutomaticConversionNodeAndConnections(UEdGraphPin* A, UEdGraphPin* B) const override;
	virtual FConnectionDrawingPolicy* CreateConnectionDrawingPolicy(int32 InBackLayerID, int32 InFrontLayerID, float InZoomFactor, const FSlateRect& InClippingRect, class FSlateWindowElementList& InDrawElements, class UEdGraph* InGraphObj) const override;
	virtual FLinearColor GetPinTypeColor(const FEdGraphPinType& PinType) const override;
	virtual void GetGraphDisplayInformation(const UEdGraph& Graph, /*out*/ FGraphDisplayInfo& DisplayInfo) const override;

	virtual void BreakNodeLinks(UEdGraphNode& TargetNode) const override;
	virtual void BreakPinLinks(UEdGraphPin& TargetPin, bool bSendsNodeNotification) const override;
	virtual void BreakSinglePinLink(UEdGraphPin* SourcePin, UEdGraphPin* TargetPin) const override;
	
	virtual void SetPinBeingDroppedOnNode(UEdGraphPin* InSourcePin) const override;
	virtual UEdGraphPin* DropPinOnNode(UEdGraphNode* InTargetNode, const FName& InSourcePinName, const FEdGraphPinType& InSourcePinType, EEdGraphPinDirection InSourcePinDirection) const override;
	virtual bool SupportsDropPinOnNode(UEdGraphNode* InTargetNode, const FEdGraphPinType& InSourcePinType, EEdGraphPinDirection InSourcePinDirection, FText& OutErrorMessage) const override;
	virtual bool CanDuplicateGraph(UEdGraph* InSourceGraph) const override { return false; }
	virtual void HandleGraphBeingDeleted(UEdGraph& GraphBeingRemoved) const override;
	// ~UEdGraphSchema

	static bool DoesUserAllowPlacement(const UEdGraphNode* A, const UEdGraphNode* B, FPinConnectionResponse& ResponseOut);

	static bool CanReplaceNode(const UEdGraphNode* InGraphNode);
	static bool CanReplaceNodeWith(const UEdGraphNode* InGraphNode, bool& bStateMachine, bool& bStateMachineRef, bool& bState, bool& bConduit, bool& bStateMachineParent);

	static void CreateQuestNode(class UEDGraphBase* EDGraph, FVector2D Location);
	static void CreateQuestNode(class UEDGraphBase* EDGraph, UEdGraphPin* FromPin, FVector2D Location);
	static void CreateQuestNode(class UEDGraphBase* EDGraph, UQuest* NodeInstance, FVector2D Location, bool bInitilization = false);
	static void CreateRingNode(class UEDGraphBase* EDGraph, UQuestRing* NodeInstance, FVector2D Location, bool bInitilization = false);
	static void CreateChapterEndNode(class UEDGraphBase* EDGraph, UChapterEnd* NodeInstance, FVector2D Location, bool bInitilization = false);
	static void CreateQuestTargetNode(class UEDGraphBase* EDGraph, UQuestTargetBase* TargetInstance, UEdGraphPin* FromPin, FVector2D Location);
	static void CreateActionNode(class UEDGraphBase* EDGraph, UQuestActionBase* ActionInstance, UEdGraphPin* FromPin, FVector2D Location);

protected:
	void GetReplaceWithMenuActions(class FMenuBuilder& MenuBuilder, const UEdGraphNode* InGraphNode) const;

};
