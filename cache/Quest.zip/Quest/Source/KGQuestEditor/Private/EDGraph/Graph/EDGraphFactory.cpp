#include "EDGraphFactory.h"
#include "KismetPins/SGraphPinExec.h"

#include "../Nodes/NodeWidgets/SEDGraphNode_EntryNode.h"
#include "../Nodes/EDGraphNode_EntryNode.h"

#include "../Nodes/NodeWidgets/SEDGraphNode_StateNode.h"
#include "../Nodes/EDGraphNode_StateNode.h"

#include "../Nodes/EDGraphNode_Transition.h"
#include "../Nodes/NodeWidgets/SEDGraphNode_Transition.h"
#include "../Nodes/NodeWidgets/SEDGraphNode_QuestProgress.h"

#define LOCTEXT_NAMESPACE "EDGraphFactory"


TSharedPtr<class SGraphNode> FEDGraphPanelNodeFactory::CreateNode(class UEdGraphNode* Node) const
{
	if (UEDGraphNode_Base* NodeBase = Cast<UEDGraphNode_Base>(Node))
	{
		if (NodeBase->NodeInstance)
		{
			//if (UEDNodeBase* NewNodeBase = Cast<UEDNodeBase>(NodeBase->NodeInstance))
			//{
			//	NodeBase->NodeName = NewNodeBase->TitleName;
			//}

			//if (UEDEventTrigger* Trigger = Cast<UEDEventTrigger>(NodeBase->NodeInstance))
			//{
			//	NodeBase->NodeName = Trigger->TitleName;
			//}
		}
	}

	if (UEDGraphNode_EntryNode* EntryNode = Cast<UEDGraphNode_EntryNode>(Node))
	{
		return SNew(SEDGraphNode_EntryNode, EntryNode);
	}
	else if (UEDGraphNode_StateNode* StateNode = Cast<UEDGraphNode_StateNode>(Node))
	{
		switch (StateNode->NodeType)
		{
		case EDNodeType::QuestProgress:
		case EDNodeType::QuestEnd:
			return SNew(SEDGraphNode_QuestProgress, StateNode);
			break;
		case EDNodeType::QuestAction:
		case EDNodeType::QuestTarget:
			return SNew(SEDGraphNode_StateNode, StateNode);
			break;
		}
		return SNew(SEDGraphNode_StateNode, StateNode);
	}
	else if (UEDGraphNode_Transition* TransNode = Cast<UEDGraphNode_Transition>(Node))
	{
		return SNew(SEDGraphNode_Transition, TransNode);
	}

	return FGraphPanelNodeFactory::CreateNode(Node);
}

TSharedPtr<class SGraphPin> FEDGraphPinFactory::CreatePin(class UEdGraphPin* InPin) const
{
	if (InPin->PinType.PinCategory == UEdGraphSchema_K2::PC_Exec)
	{
		return SNew(SGraphPinExec, InPin);
	}
	//if (InPin->PinType.PinCategory == USMGraphK2Schema::PC_StateMachine)
	//{
	//	return SNew(SSMGraphPin_StateMachinePin, InPin);
	//}

	return FGraphPanelPinFactory::CreatePin(InPin);
}

#undef LOCTEXT_NAMESPACE