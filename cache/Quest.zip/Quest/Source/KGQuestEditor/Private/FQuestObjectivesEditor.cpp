#include "FQuestObjectivesEditor.h"
#include "Toolkits/IToolkitHost.h"
#include "Toolkits/AssetEditorToolkit.h"
#include "GraphEditor.h"
#include "EdGraphUtilities.h"
#include "SNodePanel.h"
#include "Widgets/Docking/SDockTab.h"
#include "Framework/Commands/GenericCommands.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "PropertyEditorModule.h"
#include "IDetailsView.h"
#include "EdGraph/EdGraph.h"
#include "Graph/EdGraph_QuestObjectivesProp.h"
#include "FileHelpers.h"
#include "HAL/PlatformApplicationMisc.h"
#include "UI/QuestScrollWidget.h"
#include "Widget/SCCGraphPalette.h"
#include "Graph/MONode_Base.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "QuestTemplate.h"
#include "Widget/CCNodeFactory.h"
#include "UI/QuestTreeView.h"
#include "Widgets/Input/SSearchBox.h"
#include "Styling/SlateColor.h"

#include "Misc/MessageDialog.h"

#include "PackageSourceControlHelper.h"
#include "EDGraph/Graph/EventDrivenGraphSchema.h"
#include "EDGraph/Nodes/EDGraphNode_Base.h"
#include "BlueprintUtilities.h"
#include "FEditorLuaSerializeHelper.h"
#include "GraphEditAction.h"
#include "ISourceControlModule.h"
#include "KGQuestEditorModule.h"
#include "KGQuestEditorSubSystem.h"
#include "QuestEditorCommands.h"
#include "EDGraph/Nodes/EDGraphNode_EntryNode.h"
#include "EDGraph/Nodes/EDGraphNode_StateNode.h"
#include "QuestSettings.h"
#include "FileAsset/QuestExportLua.h"
#include "FileAsset/QuestImportLua.h"
#include "EDGraph/Nodes/EDGraphNode_Transition.h"
#include "FileAsset/QuestTablePreview.h"
#include "Misc/DefaultValueHelper.h"
#include "QuestObjectDataEntity.h"
#include "SGraphPanel.h"
#include "FileAsset/QuestExporter.h"
#include "FileAsset/QuestImporter.h"
#include "Framework/Notifications/NotificationManager.h"
#include "LuaSerialization/LuaTable.h"
#include "LuaSerialization/Serialization/LuaSerializer.h"
#include "LuaSerialization/Serialization/LuaWriter.h"
#include "UI/FindInQuests.h"
#include "Widget/SIDExchangePanel.h"
#include "Widget/SQuestCheckWarningWidget.h"
#include "Widgets/Notifications/SNotificationList.h"

UE_DISABLE_OPTIMIZATION_SHIP

#define LOCTEXT_NAMESPACE "FQuestObjectivesEditor" 

DEFINE_LOG_CATEGORY_STATIC(LogQuestObjectivesEditor, Log, All);

const FName QuestObjectivesEditorAppName = FName(TEXT("QuestObjectivesEditorApp"));
TSharedPtr<FQuestObjectivesEditorThumbnailPool> FQuestObjectivesEditorThumbnailPool::Instance;


bool GVarKGQuestUseCheck = true;
FAutoConsoleVariableRef CVarQuestCheckSwitch(
	TEXT("KGQuest.UseQuestCheck"),
	GVarKGQuestUseCheck,
	TEXT("Use Data Check For Quest Editor.")
);


struct FQuestObjectivesEditorTabs
{
	static const FName NavigationTab;

	static const FName DetailsID;
	static const FName ActionsID;
	static const FName ViewportID;
	static const FName ChapterGraphID;
	static const FName RingGraphID;
	static const FName QuestGraphID;
	static const FName QuestChoiseDetailID;
	static const FName QuestToolBarID;
	static const FName QuestFindResultsID;
};	

const FName FQuestObjectivesEditorTabs::NavigationTab(TEXT("NavigatorTab"));
const FName FQuestObjectivesEditorTabs::DetailsID(TEXT("Details"));
const FName FQuestObjectivesEditorTabs::ViewportID(TEXT("Viewport"));
const FName FQuestObjectivesEditorTabs::ChapterGraphID(TEXT("ChapterGraph"));
const FName FQuestObjectivesEditorTabs::RingGraphID(TEXT("RingGraph"));
const FName FQuestObjectivesEditorTabs::QuestGraphID(TEXT("QuestGraph"));
const FName FQuestObjectivesEditorTabs::ActionsID(TEXT("Actions"));
const FName FQuestObjectivesEditorTabs::QuestChoiseDetailID(TEXT("QuestChoiseDetailID"));
const FName FQuestObjectivesEditorTabs::QuestToolBarID(TEXT("QuestToolBarID"));
const FName FQuestObjectivesEditorTabs::QuestFindResultsID(TEXT("FindResults"));


static TMap<EQuestType, FColor> QuestTypeColorMap = { 
	{EQuestType::MAIN, FColor::Yellow},
	{EQuestType::SUBTASK, FColor(255,153,204)},
	{EQuestType::CITYCOLLECT, FColor::White},
	{EQuestType::WANDER, FColor::Cyan},
	{EQuestType::REPEAT, FColor::Orange},
	{EQuestType::WANTED, FColor::Purple},
	{EQuestType::SEQUENCE, FColor::Emerald}
	};

template <typename FilterType>
void FQuestFilter<FilterType>::ActiveStateChanged(bool bActive)
{
	if (this->QuestEditor)
	{
		this->QuestEditor->OnQuestTypeFilterChanged(QuestType, bActive);
	}
}

void FQuestObjectivesEditor::OnNodeTitleCommitted(const FText& NewText, ETextCommit::Type CommitInfo, UEdGraphNode* NodeBeingChanged)
{
	if (NodeBeingChanged)
	{
		const FScopedTransaction Transaction( NSLOCTEXT( "K2_RenameNode", "RenameNode", "Rename Node" ) );
		NodeBeingChanged->Modify();
		NodeBeingChanged->OnRenameNode(NewText.ToString());

		// mark dirty
		UObject* CurrentObject = NodeBeingChanged;
		while (CurrentObject)
		{
			// 检查当前对象是否是UQuest类型
			if (UQuest* QuestObject = Cast<UQuest>(CurrentObject))
			{
				MarkAssetForDirty(QuestObject);
			}
			else if (UQuestRing* QuestRingObject = Cast<UQuestRing>(CurrentObject))
			{
				MarkAssetForDirty(QuestRingObject);
			}
			else if (UQuestChapter* QuestChapterObject = Cast<UQuestChapter>(CurrentObject))
			{
				MarkAssetForDirty(QuestChapterObject);
			}

			// 获取当前对象的Outer
			CurrentObject = CurrentObject->GetOuter();
		}
	}
}

void FQuestObjectivesEditor::RefreshChapterGraphData()
{
}

///////////////
void FQuestObjectivesEditor::OnQuestTypeFilterChanged(EQuestType InType, bool bInActive)
{
	if (Actives[int(InType)] != bInActive)
	{
		Actives[int(InType)] = bInActive;

		RebuildChapterList(true);
	}
}

///////////////
UClass* GetBPClass(FSoftObjectPath SoftPath)
{
	if (SoftPath.IsValid())
	{
		UObject* Obj = SoftPath.ResolveObject();
		if (Obj == nullptr)
		{
			Obj = SoftPath.TryLoad();
		}
		if (Obj)
		{
			UClass* Class = Obj->GetClass();
			if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
			{
				Class = BPObj->GeneratedClass;
			}

			return Class;
		}
	}

	return nullptr;
}


////////////


TArray<UObject*> FQuestObjectivesEditor::GetAllObjectFromPathAndObjectClass(FString SearthPath, UClass* ObjectClass)
{
	TArray<UObject*> GetObjects;

	TArray<FString> AssetPaths;
	AssetPaths.Add(SearthPath);

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	AssetRegistryModule.Get().SearchAllAssets(/*bSynchronousSearch =*/true);
	TArray<FAssetData> AssetList;
	FARFilter ARFilter;
	ARFilter.bRecursivePaths = true;

	for (const FString& AssetPath : AssetPaths)
	{
		ARFilter.PackagePaths.Push(FName(*AssetPath));
	}

	AssetRegistryModule.Get().GetAssets(ARFilter, AssetList);

	for (FAssetData const& Asset : AssetList)
	{
		if (UObject* Object = Asset.FastGetAsset(true))
		{
			if (Object->GetClass()->IsChildOf(ObjectClass))
			{
				GetObjects.Add(Object);
			}
		}
	}

	return GetObjects;
}

void FQuestObjectivesEditor::PropertyEditorSetObjects(TArray<UObject*> SelectedObjects) const
{
	PropertyEditor->SetObjects(SelectedObjects);
}

class UEdGraph_QuestObjectivesProp* FQuestObjectivesEditor::GetQuestObjectivesGraph()
{
	if (CurEditorDataAsset.IsValid())
	{
		if (UGroupQuestTemplate* GroupQuestTemplate = Cast<UGroupQuestTemplate>(CurEditorDataAsset) )
		{
			if (GroupQuestTemplate->NodeGraph)
			{
				return Cast<UEdGraph_QuestObjectivesProp>(GroupQuestTemplate->NodeGraph);
			}
			else
			{
				GroupQuestTemplate->NodeGraph = NewObject<UEdGraph_QuestObjectivesProp>(GroupQuestTemplate);
				return Cast<UEdGraph_QuestObjectivesProp>(GroupQuestTemplate->NodeGraph);
			}
		}

		//if (USingleQuest* SingleQuest = Cast<USingleQuest>(CurEditorDataAsset))
		//{
		//	if (SingleQuest->NodeGraph)
		//	{
		//		return Cast<UEdGraph_QuestObjectivesProp>(SingleQuest->NodeGraph);
		//	}
		//	else
		//	{
		//		SingleQuest->NodeGraph = NewObject<UEdGraph_QuestObjectivesProp>(SingleQuest);
		//		return Cast<UEdGraph_QuestObjectivesProp>(SingleQuest->NodeGraph);
		//	}
		//}
	}

	return nullptr;
}

void FQuestObjectivesEditor::InitQuestObjectivesProp()
{
	RemoveGraphEditor();

	GetQuestObjectivesGraph()->QuestObjectivesEditor = SharedThis(this);
	GetQuestObjectivesGraph()->InitializeGraph();

	//刷新下
	GetQuestObjectivesGraph()->NotifyGraphChanged();

	GraphEditor = CreateGraphEditorWidget(GetQuestObjectivesGraph());
	//Listen for graph changed event
	OnGraphChangedDelegateHandle = GraphEditor->GetCurrentGraph()->AddOnGraphChangedHandler(FOnGraphChanged::FDelegate::CreateRaw(this, &FQuestObjectivesEditor::OnGraphChanged));
	bGraphStateChanged = true;

	AddGraphEditor();
}

void FQuestObjectivesEditor::RemoveGraphEditor()
{
	if (GraphEditor)
	{
		GraphHorizontalBox.Get()->RemoveSlot(GraphEditor.ToSharedRef());
		GraphEditor = nullptr;
	}
}

void FQuestObjectivesEditor::AddGraphEditor()
{
	GraphHorizontalBox.Get()->AddSlot()
		.HAlign(HAlign_Fill)
		.VAlign(VAlign_Fill)
		[
			GraphEditor.ToSharedRef()
		];
}

UQuestObjectDataEntity* FQuestObjectivesEditor::GetDataEntity()
{
	return DataEntity.Get();
}

void FQuestObjectivesEditor::ModifyData()
{
	DataEntity->Modify();
	DataEntity->MarkPackageDirty();
}

const FString FQuestObjectivesEditor::PlotQuestName(TEXT("PlotQuest"));
const FString FQuestObjectivesEditor::AchievementQuestName(TEXT("AchievementQuest"));
const FString FQuestObjectivesEditor::LevelQuestName(TEXT("LevelQuest"));
const FString FQuestObjectivesEditor::GoodImpressionName(TEXT("GoodImpression"));
const FString FQuestObjectivesEditor::QuestAssetPath(TEXT("/Game/Template/Quest"));

FName FQuestObjectivesEditor::GetToolkitFName() const
{
	return FName("QuestObjectivesEditor");
}

FText FQuestObjectivesEditor::GetBaseToolkitName() const
{
	return LOCTEXT("QuestObjectivesEditorAppLabel", "QuestObjectives Editor");
}

FText FQuestObjectivesEditor::GetToolkitName() const
{
	FFormatNamedArguments Args;
	return LOCTEXT("QuestObjectivesEditorAppLabel", "QuestObjectives Editor");
}

FString FQuestObjectivesEditor::GetWorldCentricTabPrefix() const
{
	return TEXT("QuestObjectivesEditor");
}

FLinearColor FQuestObjectivesEditor::GetWorldCentricTabColorScale() const
{
	return FLinearColor::White;
}

TSharedRef<SDockTab> FQuestObjectivesEditor::SpawnTab_Details(const FSpawnTabArgs& Args)
{
	// FQuestObjectivesEditorEdMode* EdMode = FAssetEditorToolkit::GetEditorMode();
	FPropertyEditorModule& PropertyEditorModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	//const FDetailsViewArgs DetailsViewArgs(false, false, true, FDetailsViewArgs::HideNameArea, true, this);
	FDetailsViewArgs DetailsViewArgs;
	DetailsViewArgs.bUpdatesFromSelection = false;
	DetailsViewArgs.bLockable = false;
	DetailsViewArgs.bAllowSearch = true;
	DetailsViewArgs.NameAreaSettings = FDetailsViewArgs::ENameAreaSettings::HideNameArea;
	DetailsViewArgs.bHideSelectionTip = true;
	DetailsViewArgs.NotifyHook = this;

	TSharedPtr<IDetailsView> PropertyEditorRef = PropertyEditorModule.CreateDetailView(DetailsViewArgs);

	PropertyEditor = PropertyEditorRef;

	// Spawn the tab
	return SNew(SDockTab)
		.Label(LOCTEXT("DetailsTab_Title", "Details"))
		[
			PropertyEditorRef.ToSharedRef()
		];
}

TSharedRef<SDockTab> FQuestObjectivesEditor::SpawnTab_NavigationTab(const FSpawnTabArgs& Args)
{
	FilterType.Reset();

	EVisibility Visibility = EVisibility::Visible;
	UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass());
	if(QuestSettings && !QuestSettings->bShowDeprecatedWindow)
	{
		Visibility = EVisibility::Collapsed;
	}
	TSharedPtr<FFilterCategory> FC = MakeShared<FFilterCategory>(NSLOCTEXT("Quest.Filter1", "Quest.Filter1Label", "Default"), FText::GetEmpty());

	for (int32 i(0); i < (int32)EQuestType::EQT_Max; ++i)
	{
		UEnum* Enum = StaticEnum<EQuestType>();
		bool bIsDeprecated = Enum->HasMetaData(TEXT("Deprecated"), i);
		if (bIsDeprecated)
		{
			continue;
		}

		TSharedRef<FQuestFilter<FString>> Switcher = MakeShareable(new FQuestFilter<FString>(FC, GetQuestTypeDisplayName(EQuestType(i)), FText::FromString(GetQuestTypeDisplayName(EQuestType(i))), OnQuestItemFilteredDelegate));
		
		FColor Color(FColor::Green);
		if (FColor* _Color = QuestTypeColorMap.Find(EQuestType(i)))
		{
			Color = *_Color;
		}
		
		Switcher->Init(this, Color, EQuestType(i));
		FilterType.Add(Switcher);
	}

	const TSharedRef<SDockTab> DockTab = 
		SNew(SDockTab)
		.TabRole(NomadTab)
		[
			SNew(SSplitter)
			+ SSplitter::Slot()
			.Resizable(true)
			[
				SNew(SVerticalBox)
				+SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SHorizontalBox)
					+SHorizontalBox::Slot()
					.AutoWidth()
					[
						SNew(SComboButton)
						.OnGetMenuContent(FOnGetContent::CreateRaw(this, &FQuestObjectivesEditor::GenerateFilterBtnMenuContent))
						.ButtonContent()
						[
							SNew(SHorizontalBox)
							+SHorizontalBox::Slot()
							.AutoWidth()
							[
								SNew(SImage)
								.Image(FAppStyle::Get().GetBrush("Icons.Filter"))
								.ColorAndOpacity(FSlateColor::UseForeground())
							]
						]
					]
					+ SHorizontalBox::Slot()
					.AutoWidth()
					[
						SNew(SBox)
						.HAlign(HAlign_Center)
						.VAlign(VAlign_Center)
						.Content()
						[
							SNew(SSearchBox)
							.HintText(LOCTEXT("QuestToolBarSearchID", "Search Chapter Name"))
							.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarSearchChapterNameToolTip",
								"Search Chapter By Chapter Name")))
							.OnTextChanged(this, &FQuestObjectivesEditor::OnChapterSearchTextChanged)
						]
					]
				]
				+SVerticalBox::Slot()
				.FillHeight(1.0f)
				[
					SAssignNew(QuestObjectTreeView, STreeView<TObjectPtr<UQuestObject>>)
					.TreeItemsSource(&QuestObjectFilteredItems)
					.SelectionMode(ESelectionMode::Multi)
					.OnGenerateRow(this, &FQuestObjectivesEditor::GenerateQuestObjectItemRow)
					.OnGetChildren(this, &FQuestObjectivesEditor::OnGetQuestObjectTreeChildren)
					.ItemHeight(18)
					.OnSelectionChanged(this, &FQuestObjectivesEditor::OnQuestObjectListSelectionChanged)
					.OnKeyDownHandler(this, &FQuestObjectivesEditor::OnQuestObjectListKeyDownHandler)
					.OnMouseButtonClick(this, &FQuestObjectivesEditor::OnQuestObjectListMouseButtonClick)
					.ClearSelectionOnClick(false)
					.OnContextMenuOpening(this, &FQuestObjectivesEditor::OnGetQuestObjectListContextMenu)
				]
			]
			+ SSplitter::Slot()
			[
				SNew(SSplitter)
				.Visibility(Visibility)
				.Orientation(Orient_Vertical)
				+ SSplitter::Slot()
				.SizeRule(SSplitter::SizeToContent)
				[
					SNew(SVerticalBox)
					+ SVerticalBox::Slot()
					.AutoHeight()
					[
						SAssignNew(FilterBar, SQuestFilterBar<FString>)
						.CustomFilters(FilterType)
						.FilterBarLayout(EFilterBarLayout::Vertical)
					]
				]
				+ SSplitter::Slot()
				[
					SAssignNew(ChapterListView, SListView<TObjectPtr<UQuestChapter>>)
					.ListItemsSource(&DataEntity->ChapterListItems)
					.SelectionMode(ESelectionMode::Single)
					.OnGenerateRow(this, &FQuestObjectivesEditor::GenerateChapterItemRow)
					.ItemHeight(18)
					.OnSelectionChanged(this, &FQuestObjectivesEditor::OnChapterListSelectionChanged)
					.OnMouseButtonDoubleClick(this, &FQuestObjectivesEditor::OnChapterListItemDoubleClick)
					.ClearSelectionOnClick(false)
				]
			]
			+ SSplitter::Slot()
			.Resizable(true)
			[
				SNew(SSplitter)
				.Visibility(Visibility)
				.Orientation(Orient_Vertical)
				+ SSplitter::Slot()
				//.SizeRule(SSplitter::SizeToContent)
				[
					SAssignNew(RingListView, SListView<TObjectPtr<UQuestRing>>)
					.ListItemsSource(&DataEntity->RingListItems)
					.SelectionMode(ESelectionMode::Single)
					.OnGenerateRow(this, &FQuestObjectivesEditor::GenerateRingItemRow)
					.ItemHeight(18)
					//.OnSelectionChanged(this, &FQuestObjectivesEditor::OnRingListSelectionChanged)
					.OnMouseButtonClick(this, &FQuestObjectivesEditor::OnRingListItemClicked)
					.OnMouseButtonDoubleClick(this, &FQuestObjectivesEditor::OnRingListItemDoubleClick)
					.ClearSelectionOnClick(false)
				]
				+SSplitter::Slot()
				.Resizable(true)
				[
					SAssignNew(QuestListView, SListView<TObjectPtr<UQuest>>)
					.ListItemsSource(&DataEntity->QuestListItems)
					.SelectionMode(ESelectionMode::Single)
					.OnGenerateRow(this, &FQuestObjectivesEditor::GenerateQuestItemRow)
					.ItemHeight(18)
					//.OnSelectionChanged(this, &FQuestObjectivesEditor::OnQuestListSelectionChanged)
					.OnMouseButtonClick(this, &FQuestObjectivesEditor::OnQuestListItemClicked)
					.OnMouseButtonDoubleClick(this, &FQuestObjectivesEditor::OnQuestListItemDoubleClick)
					.ClearSelectionOnClick(false)
				]
			]

				

			//+SVerticalBox::Slot()
			//	.AutoHeight()
			//	[

			//	]

			//SNew(SVerticalBox)
			//+SVerticalBox::Slot()
			//.AutoHeight()
			//[
			//	SNew(STextBlock)
			//	.Text(FText::FromString(TEXT("this is a test")))
			//]
			//+SVerticalBox::Slot()
			//.AutoHeight()
			//[
			//	SAssignNew(FilterBar, SQuestFilterBar<FString>)
			//	.CustomFilters(FilterType)
			//	.FilterBarLayout(EFilterBarLayout::Vertical)
			//]

		];


	FilterBar->EnalbeAllCustomFilters();

	//FilterBar->SetFilterCheckState(MainSwitcher, ECheckBoxState::Checked);

	FilterBar->SetCheckBox(0, true);

	// FilterBar->SetCheckBox((int32)EQuestType::WANDER, true);

	return DockTab;


	////QuestScrollWidget = SNew(SQuestScrollWidget, SharedThis(this) );
	//QuestTreeView = SNew(SQuestTreeView, SharedThis(this));

	//return
	//	SNew(SDockTab)
	//	.Label(NSLOCTEXT("ChoiseQuest", "Choise Quest", "ChoiseQuestDetail"))
	//	[
	//		SNew(SVerticalBox)

	//		// FILTER BOX
	//	+ SVerticalBox::Slot()
	//	.AutoHeight()
	//	[
	//		SAssignNew(FilterTextBox, SSearchBox)
	//		// If there is an external filter delegate, do not display this filter box
	//		//.Visibility(InArgs._OnGetFilterText.IsBound() ? EVisibility::Collapsed : EVisibility::Visible)
	//	.OnTextChanged(this, &FQuestObjectivesEditor::OnFilterTextChanged)
	//	.OnTextCommitted(this, &FQuestObjectivesEditor::OnFilterTextCommitted)
	//	]

	//// ACTION LIST
	//+ SVerticalBox::Slot()
	//	.Padding(FMargin(0.0f, 2.0f, 0.0f, 0.0f))
	//	.FillHeight(1.f)
	//	[
	//		//SNew(SScrollBorder, QuestTreeView.ToSharedRef())
	//		//[
	//		QuestTreeView.ToSharedRef()
	//		//]
	//	]
	//	];
}

TSharedRef<SDockTab> FQuestObjectivesEditor::SpawnTab_QuestToolBar(const FSpawnTabArgs& Args)
{
	TSharedRef<SHorizontalBox> HorizontalBox = SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("QuestToolBarOpenIDDocument", "Open ID Document"))
				.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarOpenIDDocumentToolTip", "Open ID Document Url")))
				.OnClicked(this, &FQuestObjectivesEditor::OnOpenIDDocumentClicked)
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(SButton)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			.Text(LOCTEXT("QuestToolBarSave", "Save"))
			.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarSaveTooltip", "Save modified quest data to lua files")))
			.OnClicked(this, &FQuestObjectivesEditor::OnSaveAsset)
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(SButton)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			.Text(LOCTEXT("QuestToolBarReload", "HotPatch"))
			.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarHotPatchTooltip", "Save and Hot Patching modified quest data")))
			.OnClicked(this, &FQuestObjectivesEditor::OnHotPatchAsset)
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(SButton)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			.Text(LOCTEXT("QuestToolBarIDExchange", "IDExchange"))
			.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarIDExchangeTooltip", "ID Exchange")))
			.OnClicked(this, &FQuestObjectivesEditor::OnIDExchangeBtnClick)
		]
				
		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("QuestToolBarRefresh", "Refresh"))
				.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarRefreshTooltip", "Refresh quest data")))
				.OnClicked(this, &FQuestObjectivesEditor::OnRefresh)
			]

		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("QuestToolBarUndo", "Undo"))
				.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarUndoTooltip",
					"Undo last modification (most graph actions can NOT be undo after graphview changed)")))
				.OnClicked(this, &FQuestObjectivesEditor::OnUndoButtonClicked)
			]

		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("QuestToolBarRedo", "Redo"))
				.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarRedoTooltip", "Redo")))
				.OnClicked(this, &FQuestObjectivesEditor::OnRedoButtonClicked)
			]
				
		+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(SButton)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			.Text(LOCTEXT("QuestToolBarRefreshLuaState", "Refresh lua state"))
			.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarRefreshLuaListToolTip",
				"Refresh env lua state, use this after lua list refreshed.")))
			.OnClicked(this, &FQuestObjectivesEditor::OnRefreshLuaState)
		]

		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.Text(LOCTEXT("QuestToolBarFlowChart", "Flow Chart"))
					.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarFlowChartToolTip", "Open project flowchart tool")))
					.OnClicked(this, &FQuestObjectivesEditor::OpenFlowChart)
			]

		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("QuestToolBarSourceControlShow", "Show Source Control State"))
				.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarSourceControlShowToolTip",
					"Show Chapter Source Control State")))
				.Visibility_Lambda([this]()
				{
					if (!this->bShowSourceControlState)
						return EVisibility::Visible;
					return EVisibility::Collapsed;
				})
				.OnClicked(this, &FQuestObjectivesEditor::OnShowSourceControlState)
			]

		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("QuestToolBarSourceControlHide", "Hide Source Control State"))
				.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarSourceControlHideToolTip",
					"Hide Chapter Source Control State")))
				.Visibility_Lambda([this]()
				{
					if (this->bShowSourceControlState)
						return EVisibility::Visible;
					return EVisibility::Collapsed;
				})
				.OnClicked(this, &FQuestObjectivesEditor::OnShowSourceControlState)
			]

		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.Text(LOCTEXT("QuestToolBarExportAll", "ExportAll"))
					.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarExportAllToolTip", "Export quest data to csv file")))
					.OnClicked(this, &FQuestObjectivesEditor::OnExportAll)
			]

		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.Text(LOCTEXT("QuestToolBarImportAll", "ImportAll"))
					.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarImportAllToolTip", "Import quest data from csv file")))
					.OnClicked(this, &FQuestObjectivesEditor::OnImportAll)
			]

		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("QuestToolBarOpenDisasterRecoveryFolder", "OpenDisasterRecoveryFolder"))
				.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarOpenDisasterRecoveryFolderTooltip", "Open Disaster Recovery Folder")))
				.OnClicked(this, &FQuestObjectivesEditor::OnOpenDisasterRecoveryFolderBtnClick)
			]
				
		+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SBox)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Content()
				[
					SNew(SSearchBox)
					.HintText(LOCTEXT("QuestToolBarSearchQuestID", "Search quest ID"))
					.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarSearchIDToolTip",
						"Search ID from chapter ring or quest")))
					.OnTextCommitted(this, &FQuestObjectivesEditor::OnSearchTextCommitted)
				]
			];
	if (GetMutableDefault<UQuestSettings>()->bShowSaveAllButton)
	{
		HorizontalBox->AddSlot()
		.AutoWidth()
		[
			SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("QuestToolBarSaveAll", "SaveAll"))
				.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarSaveAllToolTip", "Save All Quest")))
				.OnClicked(this, &FQuestObjectivesEditor::OnSaveAll)
		];

		HorizontalBox->AddSlot()
		.AutoWidth()
		[
			SNew(SButton)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				.Text(LOCTEXT("QuestToolBarExportCDO", "ExportCDO"))
				.ToolTip(FSlateApplicationBase::Get().MakeToolTip(LOCTEXT("QuestToolBarExportCDOToolTip", "Export CDO")))
				.OnClicked(this, &FQuestObjectivesEditor::OnExportCDO)
		];
	}
	
	TSharedRef<SDockTab> SpawnedTab_ToolBar = SNew(SDockTab)
	.Label(LOCTEXT("QuestToolBar", "QuestToolBar"))
	[
		SNew(SBox)
		[
			HorizontalBox
		]
	];
	return SpawnedTab_ToolBar;
}

EVisibility FQuestObjectivesEditor::GetDeleteDeleteVisibility() const
{
	return GetSelectedQuest() == nullptr ? EVisibility::Collapsed : EVisibility::Visible;
}

FReply FQuestObjectivesEditor::OnRefresh(bool bReload)
{
	if (bReload)
	{
		LoadAllQuestAssets();
	}

	RebuildLists(!bReload);

	return FReply::Handled();
}

void FQuestObjectivesEditor::GetAllFilenamesInDirectory(const FString& Directory, TArray<FString>& FileNames)
{
	FPlatformFileManager::Get().GetPlatformFile().FindFiles(FileNames, *Directory, TEXT("lua"));
}

void FQuestObjectivesEditor::DeleteTempSaveFiles()
{
	IFileManager& FileMgr = IFileManager::Get();
	for (FString& File : TempSaveFiles)
	{
		FileMgr.Delete(*File, false, true, true);
	}
	TempSaveFiles.Empty();
}

FReply FQuestObjectivesEditor::OnRefreshQuest(bool bReload)
{
	if (bReload)
	{
		// do nothing
	}

	RebuildQuestList(true);

	return FReply::Handled();


}

FReply FQuestObjectivesEditor::OnRefreshLuaState()
{
	RefreshLuaState();
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnExportAll()
{
	FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());

	FString AssetFilePath = CurrentPath + "Script/Data/Config/Quest/";
	
	for (auto Chapter : DataEntity->AllChapters)
	{
		UQuestChapter* ChapterData = Chapter.Get();
		if (!ChapterData)
			continue;

		// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
		if (ChapterData->ChapterGraph == nullptr)
			PreRefreshChapterGraph(ChapterData);
	}
	
	//Export Ring
	{
		TArray<FString> RingResult;
		ExportRingArray(DataEntity->AllQuestRings, RingResult);
		FString ExportRingFilePath = AssetFilePath + "RingCSV.csv";

		const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ExportRingFilePath);

		if (!FFileHelper::SaveStringArrayToFile(RingResult, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
		{
			UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportRing csv Error"));
			FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("Save asset error", "Export Ring csv Error! Please Contact Programmer!"));
		}
	}


	//Export Quest
	{
		TArray<FString> QuestResult;
		ExportQuestArray(DataEntity->AllQuests, QuestResult);
		FString QuestFilePath = AssetFilePath + "QuestCSV.csv";

		const FString AbsolutePath = FPaths::ConvertRelativePathToFull(QuestFilePath);

		if (!FFileHelper::SaveStringArrayToFile(QuestResult, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
		{
			UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportTask SaveLua Error"));
			FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("Save lua error", "Export Task SaveLua Error! Please Contact Programmer!"));
		}
	}
	FText ConfirmText = LOCTEXT("Export excel report", "Export Finish!");
	EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::Ok, ConfirmText);
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnImportAll()
{
	FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());
	FString AssetFilePath = CurrentPath + "Script/Data/Config/Quest/";
	FString RingFilePath = AssetFilePath + "RingCSV.csv";
	FString QuestFilePath = AssetFilePath + "QuestCSV.csv";
	FString DirtyAssets;
	for (auto Chapter : DataEntity->AllChapters)
	{
		UQuestChapter* ChapterData = Chapter.Get();
		if (!ChapterData)
			continue;

		// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
		if (ChapterData->ChapterGraph == nullptr)
			PreRefreshChapterGraph(ChapterData);
	}
	
	// Ring
	{
		TArray<FString> LoadedRingArray;
		FFileHelper::LoadFileToStringArray(LoadedRingArray, *RingFilePath);
		TArray<FString> CurrentRingArray;
		TArray<FString> Titles;
		ExportRingArray(DataEntity->AllQuestRings, CurrentRingArray);
		CurrentRingArray[0].ParseIntoArray(Titles, TEXT(","));
		TMap<int32, FString> LoadedRingMap;
		for(auto lr : LoadedRingArray)
		{
			TArray<FString> TrimPropertyArray;
			lr.ParseIntoArray(TrimPropertyArray, TEXT(","));
			if(TrimPropertyArray[2].IsNumeric())
			{
				LoadedRingMap.Add(FCString::Atoi(*TrimPropertyArray[2]), lr);
			}
		}
		TMap<int32, FString> DirtyRings;
		for(auto cr : CurrentRingArray)
		{
			TArray<FString> TrimPropertyArray;
			cr.ParseIntoArray(TrimPropertyArray, TEXT(","));
			if(TrimPropertyArray[2].IsNumeric())
			{
				int32 Key = FCString::Atoi(*TrimPropertyArray[2]);
				FString CurrentString = cr.Replace(TEXT("\""), TEXT(""));
				if(LoadedRingMap.Contains(Key))
				{
					FString LoadedString = LoadedRingMap[Key].Replace(TEXT("\""), TEXT(""));
					if(CurrentString != LoadedString)
					{
						DirtyRings.Add(Key, LoadedRingMap[Key]);
					}
				}
			}
		}
		for(auto Pair : DirtyRings)
		{
			TArray<FString> RingProperties;
			FString LuaStr = "return { [\"EditorOnly\"] = {";
			Pair.Value.ParseIntoArray(RingProperties, TEXT(","));
			for(int i = 0; i < RingProperties.Num(); i++)
			{
				if(Titles[i] == "RingName" || Titles[i] == "RingDescription")
				{
					RingProperties[i] = "\"" + RingProperties[i] + "\"";
				}
				FString SolvedString = RingProperties[i].Replace(TEXT("\"\""), TEXT("\""));
				SolvedString = SolvedString.Replace(TEXT("\"{"), TEXT("{"));
				SolvedString = SolvedString.Replace(TEXT("}\""), TEXT("}"));
				SolvedString = SolvedString.Replace(TEXT("\t"), TEXT(","));
				LuaStr += FString::Printf(TEXT("[\"%s\"] = %s,"), *Titles[i], *RingProperties[i]);
			}
			LuaStr += "}}";
			if (DataEntity->RingMap.Contains(Pair.Key))
			{
				auto Target = DataEntity->RingMap[Pair.Key];
				MarkAssetForDirty(Target);
				auto JObj = FEditorLuaSerializeHelper::ConvertLuaStrToJsonObject(LuaStr);
				FQuestImportLua::FillObjWithLuaStr(Target, JObj);
				FQuestImportLua::FillRingDataArrayWithLuaStr(Target, JObj);
				DirtyAssets += FString::FromInt(Pair.Key) + ",";
			}
		}
	}

	// Quest
	{
		TArray<FString> LoadedQuestArray;
		FFileHelper::LoadFileToStringArray(LoadedQuestArray, *QuestFilePath);
		TArray<FString> CurrentQuestArray;
		TArray<FString> Titles;
		ExportQuestArray(DataEntity->AllQuests, CurrentQuestArray);
		CurrentQuestArray[0].ParseIntoArray(Titles, TEXT(","));
		TMap<int32, FString> LoadedQuestMap;
		for(auto lq : LoadedQuestArray)
		{
			TArray<FString> TrimPropertyArray;
			lq.ParseIntoArray(TrimPropertyArray, TEXT(","));
			if(TrimPropertyArray[2].IsNumeric())
			{
				LoadedQuestMap.Add(FCString::Atoi(*TrimPropertyArray[2]), lq);
			}
		}
		TMap<int32, FString> DirtyQuests;
		for(auto cq : CurrentQuestArray)
		{
			TArray<FString> TrimPropertyArray;
			cq.ParseIntoArray(TrimPropertyArray, TEXT(","));
			if(TrimPropertyArray[2].IsNumeric())
			{
				int32 Key = FCString::Atoi(*TrimPropertyArray[2]);
				FString CurrentString = cq.Replace(TEXT("\""), TEXT(""));
				if(LoadedQuestMap.Contains(Key))
				{
					FString LoadedString = LoadedQuestMap[Key].Replace(TEXT("\""), TEXT(""));
					if(CurrentString != LoadedString)
					{
						DirtyQuests.Add(Key, LoadedQuestMap[Key]);
					}
				}
			}
		}
		for(auto Pair : DirtyQuests)
		{
			TArray<FString> QuestProperties;
			FString LuaStr = "return { [\"EditorOnly\"] = {";
			Pair.Value.ParseIntoArray(QuestProperties, TEXT(","));
			for(int i = 0; i < QuestProperties.Num(); i++)
			{
				FString SolvedString = QuestProperties[i];
				SolvedString = SolvedString.Replace(TEXT("\"{"), TEXT("{"));
				SolvedString = SolvedString.Replace(TEXT("}\""), TEXT("}"));
				SolvedString = SolvedString.Replace(TEXT("\t"), TEXT(","));
				LuaStr += FString::Printf(TEXT("[\"%s\"] = %s,"), *Titles[i], *SolvedString);
			}
			LuaStr += "}}";
			if (DataEntity->QuestMap.Contains(Pair.Key))
			{
				auto Target = DataEntity->QuestMap[Pair.Key];
				MarkAssetForDirty(Target);
				TSharedPtr<FJsonObject> JObj = FEditorLuaSerializeHelper::ConvertLuaStrToJsonObject(LuaStr);
				if (JObj.IsValid())
				{
					FQuestImportLua::FillObjWithLuaStr(Target, JObj);
					FQuestImportLua::FillQuestDataArrayWithLuaStr(Target, JObj);
					DirtyAssets += FString::FromInt(Pair.Key) + ",";
				}
			}
		}
	}

	FText ConfirmText = FText::Format(LOCTEXT("Import excel report", "Import Finish! Modified assets: {0}"), FText::FromString(DirtyAssets));
	EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::Ok, ConfirmText);
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnSaveAll()
{
	FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());

	FString AssetFilePath = CurrentPath + "Script/Data/Config/Quest/";
	for (auto Chapter : DataEntity->AllChapters)
	{
		UQuestChapter* ChapterData = Chapter.Get();
		if (!ChapterData)
			continue;

		// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
		if (ChapterData->ChapterGraph == nullptr)
			PreRefreshChapterGraph(ChapterData);
		FString LuaString;
		LuaString = FQuestLuaExporter::ExportChapterData(ChapterData);
		if (LuaString.IsEmpty())
		{
			UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportChapter Error ChapterID %d"), ChapterData->ChapterID);
			FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Save chapter error", "Export Chapter Error! Please Contact Programmer! ChapterID {0}"), ChapterData->ChapterID));
			continue;
		}

		FString ChapterFilePath = AssetFilePath + "Chapter/" + FString::FromInt(ChapterData->ChapterID) + ".lua";

		const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ChapterFilePath);

		if (!FFileHelper::SaveStringToFile(LuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
		{
			UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportChapter SaveLua Error ChapterID %d"), ChapterData->ChapterID);
			FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Save chapter error2", "Export Chapter SaveLua Error! Please Contact Programmer! ChapterID {0}"), ChapterData->ChapterID));
			continue;
		}

		FText ErrorMessage;
		if (!SourceControlHelpers::CheckoutOrMarkForAdd(AbsolutePath, FText::FromString(AbsolutePath), nullptr, ErrorMessage))
		{
				
			if (!AddFile(AbsolutePath))
			{
				if (!SourceControlHelpers::QueryFileState(AbsolutePath).bIsCheckedOut)
					FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Checkout chapter error", "Export Chapter CheckOut Error! Please Check P4! ChapterID {0} {1}"), ChapterData->ChapterID, ErrorMessage));
			}
		}
	}

	for (auto Ring : DataEntity->AllQuestRings)
    {
    	UQuestRing* RingData = Ring.Get();
    	if (!RingData)
    		continue;
    
    	// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
    	if (RingData->RingGraph == nullptr)
    		PreRefreshRingGraph(RingData);
    
    	TMap<FString, FString> ExPropertys;
    	for (size_t i = 0; i < DataEntity->AllChapters.Num(); i++)
    	{
    		UQuestChapter* Chapter = DataEntity->AllChapters[i].Get();
    		if (Chapter && RingData->ChapterID == Chapter->ChapterID)
    		{
    			ExPropertys.Add("ChapterName", Chapter->ChapterName);
    			ExPropertys.Add("ChapterIndex", Chapter->ChapterIndex);
    			break;
    		}
    	}
    
    	FText ErrInfo;
    	FString ExportLuaString;
		ExportLuaString = FQuestLuaExporter::ExportRingData(RingData, &ExPropertys);
    	if (ExportLuaString.IsEmpty())
    	{
    		UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportRing Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
    		FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Save ring error", "Export Ring Error! Please Contact Programmer! RingID {0} ChapterID {1}"), RingData->RingID, RingData->ChapterID));
    		continue;
    	}
		
		FString ExportRingFilePath = AssetFilePath + "Ring/" + FString::FromInt(RingData->RingID) + ".lua";
		const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ExportRingFilePath);
    
    	if (!FFileHelper::SaveStringToFile(ExportLuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
    	{
    		UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportRing SaveLua Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
    		FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Ring Save Lua error", "Export Ring SaveLua Error! Please Contact Programmer! RingID {0} ChapterID {1}"), RingData->RingID, RingData->ChapterID));
    		continue;
    	}
    
    	FText ExportErrorMessage;
    	if (!SourceControlHelpers::CheckoutOrMarkForAdd(AbsolutePath, FText::FromString(AbsolutePath), nullptr, ExportErrorMessage))
    	{
    		if (!AddFile(AbsolutePath))
    		{
    			if (!SourceControlHelpers::QueryFileState(AbsolutePath).bIsCheckedOut)
    				FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Ring Save Lua error2", "Export Ring CheckOut Error! Please Check P4! RingID {0} ChapterID {1} {2}"), RingData->RingID, RingData->ChapterID, ExportErrorMessage));
    		}
    		
    	}
    }
	
	return FReply::Handled();
}

void FQuestObjectivesEditor::SaveRings(TArray<UQuestRing*> InRings)
{
	FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());

	FString AssetFilePath = CurrentPath + "Script/Data/Config/Quest/";
	FScopedSlowTask SlowTask(InRings.Num(), LOCTEXT("QuestEditor.SavingRings", "Saving Rings"));
	SlowTask.MakeDialog();
	for (auto RingData : InRings)
    {
    	if (RingData == nullptr)
    		continue;

		SlowTask.EnterProgressFrame(1.0f, FText::Format(LOCTEXT("QuestEditor.SavingRingsProgressFrame", "Saving {0}"), FText::FromString(FString::FromInt(RingData->RingID))));

    	TMap<FString, FString> ExPropertys;
    	for (size_t i = 0; i < DataEntity->AllChapters.Num(); i++)
    	{
    		UQuestChapter* Chapter = DataEntity->AllChapters[i].Get();
    		if (Chapter && RingData->ChapterID == Chapter->ChapterID)
    		{
    			ExPropertys.Add("ChapterName", Chapter->ChapterName);
    			ExPropertys.Add("ChapterIndex", Chapter->ChapterIndex);
    			break;
    		}
    	}
    
    	FText ErrInfo;
    	FString ExportLuaString;
		ExportLuaString = FQuestLuaExporter::ExportRingData(RingData, &ExPropertys);
    	if (ExportLuaString.IsEmpty())
    	{
    		UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportRing Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
    		FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Save ring error", "Export Ring Error! Please Contact Programmer! RingID {0} ChapterID {1}"), RingData->RingID, RingData->ChapterID));
    		continue;
    	}
		
		FString ExportRingFilePath = AssetFilePath + "Ring/" + FString::FromInt(RingData->RingID) + ".lua";
		const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ExportRingFilePath);

    	if (!FFileHelper::SaveStringToFile(ExportLuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
    	{
    		UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportRing SaveLua Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
    		FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Ring Save Lua error", "Export Ring SaveLua Error! Please Contact Programmer! RingID {0} ChapterID {1}"), RingData->RingID, RingData->ChapterID));
    		continue;
    	}

    	FText ExportErrorMessage;
    	if (!SourceControlHelpers::CheckoutOrMarkForAdd(AbsolutePath, FText::FromString(AbsolutePath), nullptr, ExportErrorMessage))
    	{
    		if (!AddFile(AbsolutePath))
    		{
    			if (!SourceControlHelpers::QueryFileState(AbsolutePath).bIsCheckedOut)
    				FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Ring Save Lua error2", "Export Ring CheckOut Error! Please Check P4! RingID {0} ChapterID {1} {2}"), RingData->RingID, RingData->ChapterID, ExportErrorMessage));
    		}
    	}
    }
}

FReply FQuestObjectivesEditor::OnExportCDO()
{
	FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());

	FString CDOFilePath = CurrentPath + "Script/Data/Config/Quest/QuestCDO.lua";

	const FString AbsolutePath = FPaths::ConvertRelativePathToFull(CDOFilePath);

	FString ExportLuaString = FQuestLuaExporter::ExportCDO();
    
	if (!FFileHelper::SaveStringToFile(ExportLuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
	{
		FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("Export CDO Failed", "Export CDO Failed"));
	}
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnSaveAssetInternal(bool bHotReload)
{
	TArray<FString> WarningMsgs;
	TArray<FString> ErrorMsgs;
	TArray<UQuestChapter*> CheckChapters;
	TArray<UQuestRing*> CheckRings;
	TArray<UQuest*> CheckQuests;
	if (GVarKGQuestUseCheck)
	{
		// STEP1: Check Assets
		CheckChapters.Reserve(DataEntity->DirtyCheckChapters.Num());
		for (auto Chapter : DataEntity->DirtyCheckChapters)
			{
			UQuestChapter* CheckChapter = Chapter.Get();
			if (CheckChapter && DataEntity->ChapterMap.Contains(CheckChapter->ChapterID)) 
			{
				CheckChapters.Add(CheckChapter);
			}
			}

		CheckRings.Reserve(DataEntity->DirtyCheckRings.Num());
		for (auto Ring: DataEntity->DirtyCheckRings)
		{
			if (!Ring.IsValid()) continue;

			UQuestRing* CheckRing = Ring.Get();
			if (CheckRing && DataEntity->RingMap.Contains(CheckRing->RingID))
			{
				CheckRings.Add(CheckRing);
			}

			// 检查 Ring 时需要一并检查相关联的 Quest
			for (auto Child : Ring->Children)
			{
				if (UQuest* Quest = Cast<UQuest>(Child))
				{
					if (Quest && DataEntity->QuestMap.Contains(Quest->QuestID))
					{
						CheckQuests.Add(Quest);
					}
				}
			}
		}

		for (auto Quest: DataEntity->DirtyCheckQuests)
		{
			UQuest* CheckQuest = Quest.Get();
			if (CheckQuest && DataEntity->QuestMap.Contains(CheckQuest->QuestID))
			{
				CheckQuests.AddUnique(CheckQuest);
			}
		}
	}
	
	// STEP2: Save Assets
	FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());

	FString AssetFilePath = CurrentPath + "Script/Data/Config/Quest/";

	TArray<TWeakObjectPtr<UQuestChapter>> ReservedDirtyChapters;
	TArray<TWeakObjectPtr<UQuestRing>> ReservedDirtyRings;
	TArray<TWeakObjectPtr<UQuest>> ReservedDirtyQuests;

	bool bSaveAndLoadQuestInRing = false;
	bool bForbidExportQuestFile = false;
	if (UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
	{
		bSaveAndLoadQuestInRing = QuestSettings->bSaveAndLoadQuestInRing;
		bForbidExportQuestFile = QuestSettings->bForbidExportQuestFile;
	}

	// 对于新创建的节点有不合法 id 的情况，需要阻止相关 Chapter 的保存，防止里面存有错误数据
	{
		const FString ErrorMsgPrefix = LOCTEXT("ErrorMsgPrefix", "新增").ToString();
		TSet<int32> ReservedDirtyChapterID;

		// Chapter ID
		{
			for (auto Chapter : DataEntity->DirtyChapters)
			{
				UQuestChapter* ChapterData = Chapter.Get();
				if (!ChapterData)
					continue;

				// Chapter 为负数，说明是新创建的节点但没有改 ID
				// 对改了 Chapter ID 的 Chapter，检查一下 Chapter ID 是否合法
				if (ChapterData->ChapterID < 0 || ChapterData->QuestObjectID != ChapterData->ChapterID)
				{
					FText CheckDialog;
					// 最终保存时检查不再去检查 id 是否在 map 中，因为改 id 的时候已经做过了，且改完 id 会把新 id 刷到 map 中
					if (!ChapterData->CheckChapterID(CheckDialog, false))
					{
						// Chapter ID 检查不通过
						ErrorMsgs.Add(ErrorMsgPrefix + CheckDialog.ToString());
						// 相关联章节下所有任务的改动都不保存
						ReservedDirtyChapterID.Add(ChapterData->ChapterID);
						continue;
					}
				}
				else if (Chapter->AuthorName.IsEmpty())
				{
					// 负责人检查
					// 需要检查这个Chapter是否填写了负责人名称，如果填了才能正常保存，没填则直接卡保存。
					const FString ErrorMsgAuthorName = LOCTEXT("ErrorMsgAuthorName", "章节[{0}]未设置负责人名称，此次改动将无法正常保存，请补全后再做尝试。").ToString();
					ErrorMsgs.Add(FString::Format(*ErrorMsgAuthorName, {Chapter->ChapterID}));
					// 相关联章节下所有任务的改动都不保存
					ReservedDirtyChapterID.Add(ChapterData->ChapterID);
					continue;
				}
			}
		}
		
		// Ring ID
		{
			for (auto Ring : DataEntity->DirtyRings)
			{
				UQuestRing* RingData = Ring.Get();
				if (!RingData)
					continue;

				// RingID 为负数，说明是新创建的节点但没有改 ID
				// 对改了 Ring ID 的 Ring，检查一下 Ring ID 是否合法
				if (RingData->RingID < 0 || RingData->QuestObjectID != RingData->RingID)
				{
					FText CheckDialog;
					// 最终保存时检查不再去检查 id 是否在 map 中，因为改 id 的时候已经做过了，且改完 id 会把新 id 刷到 map 中
					if (!RingData->CheckRingID(CheckDialog, false))
					{
						// Ring ID 检查不通过
						ErrorMsgs.Add(ErrorMsgPrefix + CheckDialog.ToString());
						// 相关联章节下所有任务的改动都不保存
						ReservedDirtyChapterID.Add(RingData->ChapterID);
						continue;
					}
				}
				else if (RingData->Father && Cast<UQuestChapter>(RingData->Father))
				{
					auto QuestChapter = Cast<UQuestChapter>(RingData->Father);
					if (!ReservedDirtyChapterID.Contains(QuestChapter->ChapterID) && QuestChapter->AuthorName.IsEmpty())
					{
						// 负责人检查
						const FString ErrorMsgAuthorName = LOCTEXT("ErrorMsgAuthorName", "章节[{0}]未设置负责人名称，此次改动将无法正常保存，请补全后再做尝试。").ToString();
						ErrorMsgs.Add(FString::Format(*ErrorMsgAuthorName, {QuestChapter->ChapterID}));
						// 相关联章节下所有任务的改动都不保存
						ReservedDirtyChapterID.Add(QuestChapter->ChapterID);
						continue;
					}
				}
			}
		}

		TArray<TWeakObjectPtr<UQuestChapter>> ChaptersToReservedDirty;
		TArray<TWeakObjectPtr<UQuestRing>> RingsToReservedDirty;
		TArray<TWeakObjectPtr<UQuest>> QuestsToReservedDirty;
		for (auto Chapter : DataEntity->DirtyChapters)
		{
			if (Chapter.IsValid())
			{
				if (ReservedDirtyChapterID.Contains(Chapter->ChapterID))
				{
					ChaptersToReservedDirty.Add(Chapter);
				}
			}
		}
		for (auto Ring : DataEntity->DirtyRings)
		{
			if (Ring.IsValid())
			{
				if (ReservedDirtyChapterID.Contains(Ring->ChapterID))
				{
					RingsToReservedDirty.Add(Ring);
				}
			}
		}
		for (auto Quest : DataEntity->DirtyQuests)
		{
			if (Quest.IsValid())
			{
				if (ReservedDirtyChapterID.Contains(Quest->ChapterID))
				{
					QuestsToReservedDirty.Add(Quest);
				}
			}
		}

		for (TWeakObjectPtr<UQuestChapter> ChapterToReservedDirty : ChaptersToReservedDirty)
		{
			// 不参与导出
			DataEntity->DirtyChapters.Remove(ChapterToReservedDirty);
			// 保存结束后仍然保留在 Dirty 里
			ReservedDirtyChapters.Add(ChapterToReservedDirty);
		}
		for (TWeakObjectPtr<UQuestRing> RingToReservedDirty : RingsToReservedDirty)
		{
			// 不参与导出
			DataEntity->DirtyRings.Remove(RingToReservedDirty);
			// 保存结束后仍然保留在 Dirty 里
			ReservedDirtyRings.Add(RingToReservedDirty);
		}
		for (TWeakObjectPtr<UQuest> QuestToReservedDirty : QuestsToReservedDirty)
		{
			// 不参与导出
			DataEntity->DirtyQuests.Remove(QuestToReservedDirty);
			// 保存结束后仍然保留在 Dirty 里
			ReservedDirtyQuests.Add(QuestToReservedDirty);
		}

		if (!ErrorMsgs.IsEmpty())
		{
			ErrorMsgs.Add(LOCTEXT("SaveCheckErrorDialog", "\n注意：以上错误请及时修改，否则关联章节下所有任务的改动将不会正常保存。").ToString());
		}
	}


	// 改 ID 的情况（ChapterID、RingID、QuestID）需要提前处理一下
	TArray<UQuestChapter*> ChaptersToReinitGraph;
	TArray<UQuestChapter*> ChaptersToDeleteArray;
	TArray<UQuestChapter*> ChaptersToAddArray;
	TArray<UQuestRing*> RingsToReinitGraph;
	TArray<UQuestRing*> RingToDeleteArray;
	TArray<UQuestRing*> RingToAddArray;
	TArray<UQuest*> QuestsToDeleteArray;
	TArray<UQuest*> QuestsToAddArray;
	{
		// ChapterID
		// 对更改了 ChapterID 的那些章节，修改对应的 Ring 和 Quest
		{
			for (auto Chapter : DataEntity->DirtyChapters)
			{
				UQuestChapter* ChapterData = Chapter.Get();
				if (!ChapterData)
					continue;

				// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
				if (ChapterData->ChapterGraph == nullptr)
					PreRefreshChapterGraph(ChapterData);

				// 更改了 ChapterID
				if (ChapterData->ChapterID != ChapterData->QuestObjectID)
				{
					const int32 NewChapterID = ChapterData->ChapterID;
					const int32 OldChapterID = ChapterData->QuestObjectID;
				
					// Trick: 复原旧的 ChapterID，以删除旧文件
					// 考虑到 id 交换，当 ChapterMap 没有 OldChapterID 时才删除旧文件
					if (!DataEntity->ChapterMap.Contains(OldChapterID))
					{
						UQuestChapter* OldChapterDelegate = Cast<UQuestChapter>(DeepCopyQuestObject(ChapterData));
						OldChapterDelegate->ChapterID = OldChapterID;
						ChaptersToDeleteArray.Add(OldChapterDelegate);
					}
				
					ChapterData->QuestObjectID = ChapterData->ChapterID;
					ChaptersToAddArray.Add(ChapterData);
					
					for (auto RingChild : ChapterData->Children)
					{
						if (auto QuestRing = Cast<UQuestRing>(RingChild))
						{
							QuestRing->ChapterID = ChapterData->ChapterID;

							DataEntity->DirtyRings.Add(QuestRing);

							for (auto QuestChild : QuestRing->Children)
							{
								if (auto Quest = Cast<UQuest>(QuestChild))
								{
									Quest->ChapterID = ChapterData->ChapterID;

									DataEntity->DirtyQuests.Add(Quest);
								}
							}
						}
					}
				}
			}
		}

		// RingID
		{
			TSet<TWeakObjectPtr<UQuestRing>> RingsToMarkDirty;
			for (auto Ring : DataEntity->DirtyRings)
			{
				UQuestRing* RingData = Ring.Get();
				if (!RingData)
					continue;

				// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
				if (RingData->RingGraph == nullptr)
					PreRefreshRingGraph(RingData);

				if (RingData->QuestObjectID != RingData->RingID)
				{
					const int32 NewRingID = RingData->RingID;
					const int32 OldRingID = RingData->QuestObjectID;

					// 保持 Ring 节点间的连线不变
					if (auto QuestChapter = Cast<UQuestChapter>(RingData->Father))
					{
						// 当前 Ring A 的 ID 从 RingData->QuestObjectID 变到 RingData->RingID
						// 需要修改指向 Ring A 的 Ring B 节点的 NextTaskInfo 记录的 RingID 值
						for (auto Child : QuestChapter->Children)
						{
							if (auto QuestRing = Cast<UQuestRing>(Child))
							{
								for (URingTaskConditionBase* NextTaskInfo : QuestRing->NextTaskInfoList)
								{
									if (NextTaskInfo->NextTaskID == OldRingID)
									{
										NextTaskInfo->NextTaskID = NewRingID;
										RingsToMarkDirty.Add(QuestRing);
									}
								}
							}
						}
					}

					// Trick: 复原旧的 RingID，以删除旧文件
					// 考虑到 id 交换，当 RingMap 没有 OldRingID 时才删除旧文件
					if (!DataEntity->RingMap.Contains(OldRingID))
					{
						UQuestRing* OldRingDelegate = Cast<UQuestRing>(DeepCopyQuestObject(RingData));
						OldRingDelegate->RingID = OldRingID;
						RingToDeleteArray.Add(OldRingDelegate);
					}

					RingData->QuestObjectID = NewRingID;
					RingToAddArray.Add(RingData);

					// 需要重新导出 Chapter，更改里面的 RingNode 数据
					if (DataEntity->ChapterMap.Contains(RingData->ChapterID))
					{
						if (MarkAssetForDirty(DataEntity->ChapterMap[RingData->ChapterID]))
						{
							ChaptersToReinitGraph.Add(DataEntity->ChapterMap[RingData->ChapterID]);
						}
					}

					// 需要再刷一下 Quest 的 ID 和 Quest 记录的 RingID
					FlushQuestsAfterRingIDChange(RingData);
				}
			}
			DataEntity->DirtyRings.Append(RingsToMarkDirty);
		}

		// QuestID
		{
			for (auto Quest : DataEntity->DirtyQuests)
			{
				UQuest* QuestData = Quest.Get();
				if (!QuestData)
					continue;

				// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
				if (QuestData->QuestGraph == nullptr)
					PreRefreshQuestGraph(QuestData);

				if (QuestData->QuestObjectID != QuestData->QuestID)
				{
					const int32 NewQuestID = QuestData->QuestID;
					const int32 OldQuestID = QuestData->QuestObjectID;

					// 保持 Quest 节点间的连线不变
					if (auto QuestRing = Cast<UQuestRing>(QuestData->Father))
					{
						// 当前 Ring A 的 ID 从 RingData->QuestObjectID 变到 RingData->RingID
						// 需要修改指向 Ring A 的 Ring B 节点的 NextTaskInfo 记录的 RingID 值
						for (auto Child : QuestRing->Children)
						{
							if (auto OtherQuest = Cast<UQuest>(Child))
							{
								for (URingTaskConditionBase* NextTaskInfo : OtherQuest->NextTaskInfoList)
								{
									if (NextTaskInfo->NextTaskID == OldQuestID)
									{
										NextTaskInfo->NextTaskID = NewQuestID;
									}
								}
							}
						}

						// 需要重新导出父 Ring
						DataEntity->DirtyRings.Add(QuestRing);
					}

					// Trick: 复原旧的 QuestID，以删除旧文件
					UQuest* OldQuestDelegate = Cast<UQuest>(DeepCopyQuestObject(QuestData));
					OldQuestDelegate->QuestID = OldQuestID;
					QuestsToDeleteArray.Add(OldQuestDelegate);

					QuestData->QuestObjectID = NewQuestID;
					QuestsToAddArray.Add(QuestData);

					// 需要刷新 Ring Graph
					if (DataEntity->RingMap.Contains(QuestData->RingID))
					{
						if (MarkAssetForDirty(DataEntity->RingMap[QuestData->RingID]))
						{
							RingsToReinitGraph.Add(DataEntity->RingMap[QuestData->RingID]);
						}
					}
				}
			}
		}
	}

	// 按文件热更
	TArray<FString> RingPathsToReload;
	TArray<FString> RingIds;

	//Export Ring
	{
		if (bSaveAndLoadQuestInRing)
		{
			// Quest 数据在 Ring 中，随 Ring 导出
			for (auto Quest : DataEntity->DirtyQuests)
			{
				auto Target = Quest.Get();
				if (DataEntity->RingMap.Contains(Target->RingID))
				{
					DataEntity->DirtyRings.Add(DataEntity->RingMap[Target->RingID]);
				}
			}
		}

		for (auto Ring : DataEntity->DirtyRings)
		{
			UQuestRing* RingData = Ring.Get();
			if (!RingData)
				continue;

			// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
			if (RingData->RingGraph == nullptr)
				PreRefreshRingGraph(RingData);

			TMap<FString, FString> ExPropertys;
			for (size_t i = 0; i < DataEntity->AllChapters.Num(); i++)
			{
				UQuestChapter* Chapter = DataEntity->AllChapters[i].Get();
				if (Chapter && RingData->ChapterID == Chapter->ChapterID)
				{
					ExPropertys.Add("ChapterName", Chapter->ChapterName);
					ExPropertys.Add("ChapterIndex", Chapter->ChapterIndex);
					break;
				}
			}

			FString ExportLuaString;
			ExportLuaString = FQuestLuaExporter::ExportRingData(RingData, &ExPropertys);
			if (ExportLuaString.IsEmpty())
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportRing Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
				FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Save ring error", "Export Ring Error! Please Contact Programmer! RingID {0} ChapterID {1}"), RingData->RingID, RingData->ChapterID));
				continue;
			}

			FString ExportRingFilePath = AssetFilePath + "Ring/" + FString::FromInt(RingData->RingID) + ".lua";

			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ExportRingFilePath);

			// 记录以 Data 的相对路径到 RingPathsToReload 数组中，在保存完成后按文件热更时使用
			RingPathsToReload.Add("Data/Quest/Ring/" + FString::FromInt(RingData->RingID));
			RingIds.Add(FString::FromInt(RingData->RingID));

			if (!FFileHelper::SaveStringToFile(ExportLuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportRing SaveLua Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
				FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Ring Save Lua error", "Export Ring SaveLua Error! Please Contact Programmer! RingID {0} ChapterID {1}"), RingData->RingID, RingData->ChapterID));
				continue;
			}

			FText ExportErrorMessage;
			if (!SourceControlHelpers::CheckoutOrMarkForAdd(AbsolutePath, FText::FromString(AbsolutePath), nullptr, ExportErrorMessage))
			{
				if (!AddFile(AbsolutePath))
				{
					if (!SourceControlHelpers::QueryFileState(AbsolutePath).bIsCheckedOut)
						FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Ring Save Lua error2", "Export Ring CheckOut Error! Please Check P4! RingID {0} ChapterID {1} {2}"), RingData->RingID, RingData->ChapterID, ExportErrorMessage));
				}
				
			}
		}

		for (auto RingToDelete : RingToDeleteArray)
		{
			// 会删除 Ring 以及相关的 Quest
			DeleteRing(RingToDelete);
		}
		for (auto RingToAdd : RingToAddArray)
		{
			AddRingObjToDataEntity(RingToAdd);
		}
	}

	//Export Chapter
	{
		for (auto Chapter : DataEntity->DirtyChapters)
		{
			UQuestChapter* ChapterData = Chapter.Get();
			if (!ChapterData)
				continue;

			// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
			if (ChapterData->ChapterGraph == nullptr)
				PreRefreshChapterGraph(ChapterData);
			FString LuaString;
			LuaString = FQuestLuaExporter::ExportChapterData(ChapterData);
			if (LuaString.IsEmpty())
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportChapter Error ChapterID %d"), ChapterData->ChapterID);
				FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Save chapter error", "Export Chapter Error! Please Contact Programmer! ChapterID {0}"), ChapterData->ChapterID));
				continue;
			}

			FString ChapterFilePath = AssetFilePath + "Chapter/" + FString::FromInt(ChapterData->ChapterID) + ".lua";

			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ChapterFilePath);

			if (!FFileHelper::SaveStringToFile(LuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportChapter SaveLua Error ChapterID %d"), ChapterData->ChapterID);
				FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Save chapter error2", "Export Chapter SaveLua Error! Please Contact Programmer! ChapterID {0}"), ChapterData->ChapterID));
				continue;
			}

			FText ErrorMessage;
			if (!SourceControlHelpers::CheckoutOrMarkForAdd(AbsolutePath, FText::FromString(AbsolutePath), nullptr, ErrorMessage))
			{
				
				if (!AddFile(AbsolutePath))
				{
					if (!SourceControlHelpers::QueryFileState(AbsolutePath).bIsCheckedOut)
						FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("Checkout chapter error", "Export Chapter CheckOut Error! Please Check P4! ChapterID {0} {1}"), ChapterData->ChapterID, ErrorMessage));
				}
			}
		}

		// 对于调整 RingID 的那些 Chapter，得重新生成 Graph
		for (auto ChapterToReinitGraph : ChaptersToReinitGraph)
		{
			ChapterToReinitGraph->ChapterGraph->MarkAsGarbage();
			ChapterToReinitGraph->ChapterGraph = nullptr;
			RefreshChapterGraph(ChapterToReinitGraph);
		}

		// 删除旧 ChapterID 的 Chapter
		for (auto ChapterToDelete : ChaptersToDeleteArray)
		{
			// 仅删除 Chapter，会放到 PendingDeleteObjects 中
			DeleteChapterObj(ChapterToDelete);
		}
		for (auto ChapterToAdd : ChaptersToAddArray)
		{
			AddChapterObjToDataEntity(ChapterToAdd);
		}
	}

	//Export Quest
	for (auto QuestToDelete : QuestsToDeleteArray)
	{
		DeleteQuestObj(QuestToDelete);
	}
	for (auto QuestToAdd : QuestsToAddArray)
	{
		AddQuestObjToDataEntity(QuestToAdd);
	}
	// 对于调整 QuestID 的那些 Ring，得重新生成 Graph
	for (auto RingToReinitGraph : RingsToReinitGraph)
	{
		RefreshRingGraph(RingToReinitGraph);
	}

	// 因为涉及到改 id 等操作，所以放到保存完毕后再检查新的任务
	if (!CheckChapters.IsEmpty() || !CheckRings.IsEmpty() || !CheckQuests.IsEmpty())
	{
		WarningMsgs = UKGQuestEditorSubSystem::Get().DataCheck(CheckChapters, CheckRings, CheckQuests);
	}
	// 检查错误面板
	if (!WarningMsgs.IsEmpty() || !ErrorMsgs.IsEmpty())
	{
		ShowCheckResultMessageBox(WarningMsgs, ErrorMsgs);
		// return FReply::Handled(); // 有检查问题也保留改动，不卡策划的保存
	}

	// Deal with pending delete assets
	{
		FString ProjPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());
		auto SourceControlDeleteFile = [](const FString& FilePath)
		{
			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(FilePath);
			if (FPaths::FileExists(AbsolutePath))
			{
				if (!IFileManager::Get().IsReadOnly(*AbsolutePath))
				{
					// 如果文件是可写的，此时如果直接p4删除，会弹出警告：Can't clobber writable file
					// 因此我们先取巧恢复到只读，再标记删除
					UE_LOG(LogQuestObjectivesEditor, Log, TEXT("File %s is not read only. Try to check out and revert to remove Writable."), *AbsolutePath);
					USourceControlHelpers::CheckOutFile(AbsolutePath);
					USourceControlHelpers::RevertFile(AbsolutePath);
				}
				USourceControlHelpers::MarkFileForDelete(AbsolutePath, true);
			}
		};
		for(auto Asset : DataEntity->PendingDeleteObjects)
		{
			if(auto QuestObj = Cast<UQuest>(Asset))
			{
				// 对应的lua文件标记删除
				{
					FString FilePath = ProjPath + "Script/Data/Config/Quest/Quest/";
					FString QuestFilePath = FilePath + FString::FromInt(QuestObj->QuestID) + ".lua";
					SourceControlDeleteFile(QuestFilePath);
				}
			}else if(auto RingObj = Cast<UQuestRing>(Asset))
			{
				// 对应的lua文件标记删除
				{
					// 删除的 Ring 对象也要加到 RingIds 中
					RingIds.Add(FString::FromInt(RingObj->RingID));
					
					FString FilePath = ProjPath + "Script/Data/Config/Quest/Ring/";
					FString QuestFilePath = FilePath + FString::FromInt(RingObj->RingID) + ".lua";
					SourceControlDeleteFile(QuestFilePath);
				}
			}else if(auto ChapterObj = Cast<UQuestChapter>(Asset))
			{
				// 对应的lua文件标记删除
				{
					FString FilePath = ProjPath + "Script/Data/Config/Quest/Chapter/";
					FString QuestFilePath = FilePath + FString::FromInt(ChapterObj->ChapterID) + ".lua";
					SourceControlDeleteFile(QuestFilePath);
				}
			}
		}
	}
	DeleteEmptyFilesInChangelist();
	FText ConfirmText = LOCTEXT("ExportFinishReport", "Export Finish! ");
	FMessageDialog::Open(EAppMsgType::Ok, ConfirmText);
	
	DataEntity->DirtyChapters.Reset();
	DataEntity->DirtyRings.Reset();
	DataEntity->DirtyQuests.Reset();
	DataEntity->PendingDeleteObjects.Reset();
	DataEntity->DirtyChapters.Append(ReservedDirtyChapters);
	DataEntity->DirtyRings.Append(ReservedDirtyRings);
	DataEntity->DirtyQuests.Append(ReservedDirtyQuests);

	// 运行导出 bat
	if (bHotReload)
	{
		// 生成数据并热更
		if (GetMutableDefault<UQuestSettings>()->bUseNewReloadBat)
		{
			FString ProjectDir = FPaths::ProjectDir();
			FString RelativePathToBatch = FPaths::Combine(TEXT(".."), TEXT("Design"), TEXT("按文件热更任务数据.bat"));
			FString BatchFilePath = FPaths::Combine(ProjectDir, RelativePathToBatch);
			FPaths::NormalizeFilename(BatchFilePath);
			FString Param = "\"reload_by_path;" + FString::Join(RingPathsToReload, TEXT(";"));
			Param += TEXT("\"");
			RunBatFile(BatchFilePath, Param);
		}
		else
		{
			FString ProjectDir = FPaths::ProjectDir();
			FString RelativePathToBatch = FPaths::Combine(TEXT(".."), TEXT("Design"), TEXT("热更任务数据.bat"));
			FString BatchFilePath = FPaths::Combine(ProjectDir, RelativePathToBatch);
			FPaths::NormalizeFilename(BatchFilePath);
			RunBatFile(BatchFilePath);
		}
	}
	else
	{
		// 只生成数据不执行热更
		FString ProjectDir = FPaths::ProjectDir();
		FString RelativePathToBatch = FPaths::Combine(TEXT(".."), TEXT("Design/Tool"), TEXT("MakeQuestMergeData.bat"));
		FString BatchFilePath = FPaths::Combine(ProjectDir, RelativePathToBatch);
		FPaths::NormalizeFilename(BatchFilePath);
		RunBatFile(BatchFilePath);
	}

	if (RingIds.Num() > 0)
	{
		FString ProjectDir = FPaths::ProjectDir();
		FString RelativePathToBatch = FPaths::Combine(TEXT(".."), TEXT("Design/Tool"), TEXT("TaskRewardTableMergeTool.exe"));
		FString BatchFilePath = FPaths::Combine(ProjectDir, RelativePathToBatch);
		FPaths::NormalizeFilename(BatchFilePath);
		FString Param = "--refresh_type some_refresh --ring_list";
		for (const FString& RingId : RingIds)
		{
			Param += " ";
			Param += RingId;
		}
		RunBatFile(BatchFilePath, Param);
	}

	// 策划点击保存之后，策划就不能撤销或者恢复保存前的改动了
	GEditor->ResetTransaction(LOCTEXT("ClearTransBuffer", "Clear Undo/Redo Buffers after Save"));

	// 保存成功后，把容灾机制所存的临时文件都清理掉
	DeleteTempSaveFiles();
	
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnSaveAsset()
{
	FReply ReplyResult = OnSaveAssetInternal();

	return ReplyResult;
}

FReply FQuestObjectivesEditor::OnHotPatchAsset()
{
	FReply ReplyResult = OnSaveAssetInternal(true);

	return ReplyResult;
}

FReply FQuestObjectivesEditor::OnIDExchangeBtnClick()
{
	if (IDExchangeWindow.IsValid())
	{
		IDExchangeWindow->RequestDestroyWindow();
		IDExchangeWindow.Reset();
	}
	IDExchangeWindow = SNew(SWindow)
	.Title(LOCTEXT("IDExchangeWindowTitle", "FQuestObjectivesEditor ID Exchange Window"))
	.ClientSize(FVector2D(800, 600))
	.SupportsMinimize(true)
	.SupportsMaximize(true)
	[
		SNew(SIDExchangePanel)
		.CurQuestObjectivesEditor(this)
	];

	FSlateApplication::Get().AddWindow(IDExchangeWindow.ToSharedRef());

	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnRefresh()
{
	OnRefresh(false);
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnUndoButtonClicked()
{
	GEditor->UndoTransaction();
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnRedoButtonClicked()
{
	GEditor->RedoTransaction();
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::DoExportAsset(TArray<UPackage*>& DirtyPkgs, TMap<UPackage*, UQuest*>& ModifyQuestMap, TMap<UPackage*, UQuestRing*>& ModifyRingMap)
{
	TArray<UPackage*> FailedList;
	FEditorFileUtils::PromptForCheckoutAndSave(DirtyPkgs, false, true, &FailedList, false, true);

	FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());

	FString FilePath = CurrentPath + "Script/Data/Config/Task/";

	//Export Ring
	{
		for (auto& Elem : ModifyRingMap)
		{
			if (FailedList.Find(Elem.Key) != INDEX_NONE)
				continue;

			UQuestRing* RingData = Elem.Value;

			TMap<FString, FString> ExPropertys;
			for (size_t i = 0; i < DataEntity->AllChapters.Num(); i++)
			{
				UQuestChapter* Chapter = DataEntity->AllChapters[i].Get();
				if (Chapter && RingData->ChapterID == Chapter->ChapterID)
				{
					ExPropertys.Add("ChapterName", Chapter->ChapterName);
					ExPropertys.Add("ChapterIndex", Chapter->ChapterIndex);
					break;
				}
			}

			FString LuaString = FQuestExportLua::ExportRingData(Elem.Value, &ExPropertys);
			if (LuaString.IsEmpty())
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportRing Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
				continue;
			}

			FString RingFilePath = FilePath + "Ring/" + FString::FromInt(RingData->RingID) + ".lua";

			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(RingFilePath);

			if (!FFileHelper::SaveStringToFile(LuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportRing SaveLua Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
				continue;
			}

			FText ErrorMessage;
			if (!SourceControlHelpers::CheckoutOrMarkForAdd(AbsolutePath, FText::FromString(AbsolutePath), nullptr, ErrorMessage))
			{
				continue;
			}
		}
	}


	//Export Quest
	{
		for (auto& Elem : ModifyQuestMap)
		{
			if (FailedList.Find(Elem.Key) != INDEX_NONE)
				continue;

			UQuest* QuestData = Elem.Value;
			//bool bPassCheck = FQuestExportLua::PreCheckQuestData(Elem.Value);
			//if (!bPassCheck)
			//{
			//	FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Export Task Error! No Condition in Quest! QuestID %d RingID %d ChapterID %d"), QuestData->QuestID, QuestData->RingID, QuestData->ChapterID)));
			//	continue;
			//}

			FString LuaString = FQuestExportLua::ExportQuestData(Elem.Value);
			if (LuaString.IsEmpty())
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportTask Error QuestID %d RingID %d ChapterID %d"), QuestData->QuestID, QuestData->RingID, QuestData->ChapterID);
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Export Task Error! Please Contact Programmer! QuestID %d RingID %d ChapterID %d"), QuestData->QuestID, QuestData->RingID, QuestData->ChapterID)));
				continue;
			}

			FString QuestFilePath = FilePath + FString::FromInt(QuestData->QuestID) + ".lua";

			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(QuestFilePath);

			if (!FFileHelper::SaveStringToFile(LuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::OnSaveAsset ExportTask SaveLua Error QuestID %d RingID %d ChapterID %d"), QuestData->QuestID, QuestData->RingID, QuestData->ChapterID);
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Export Task SaveLua Error! Please Contact Programmer! QuestID %d RingID %d ChapterID %d"), QuestData->QuestID, QuestData->RingID, QuestData->ChapterID)));
				continue;
			}

			FText ErrorMessage;
			if (!SourceControlHelpers::CheckoutOrMarkForAdd(AbsolutePath, FText::FromString(AbsolutePath), nullptr, ErrorMessage))
			{
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Export Task CheckOut Error! Please Check P4!  QuestID %d RingID %d ChapterID %d %s"), QuestData->QuestID, QuestData->RingID, QuestData->ChapterID, *ErrorMessage.ToString())));
				continue;
			}
		}
	}

	FText ConfirmText = FText::FromString(FString::Printf(TEXT("Export Finish! Run Auto Check?")));
	EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, ConfirmText);
	if (ReturnType == EAppReturnType::Type::Yes)
	{
		FString ExePath = FPaths::ConvertRelativePathToFull(FPaths::EngineDir() / TEXT("../Design/Tool/CheckQuest.exe"));
		FString WorkingDirectory = FPaths::ConvertRelativePathToFull(FPaths::EngineDir() / TEXT("../Design/Tool"));
		if (FPaths::FileExists(ExePath) && FPaths::DirectoryExists(WorkingDirectory))
		{
			FPlatformProcess::CreateProc(*ExePath, nullptr, true, false, false, nullptr, 0, *WorkingDirectory, nullptr);
		}
	}

	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnOpenDisasterRecoveryFolderBtnClick()
{
	if (FPaths::DirectoryExists(DisasterRecoveryBaseFolderPath))
	{
		FPlatformProcess::ExploreFolder(*FPaths::ConvertRelativePathToFull(DisasterRecoveryBaseFolderPath));
	}
	else
	{
		FText Message = LOCTEXT("DisasterRecoveryFolderNotExists", "容灾机制的文件夹不存在，可能是没有修改文件，没有触发容灾机制。");
		FNotificationInfo NotifyInfo(Message);
		NotifyInfo.FadeOutDuration = 5.f;
		FSlateNotificationManager::Get().AddNotification(NotifyInfo);
	}

	return FReply::Handled();
}

void FQuestObjectivesEditor::RefreshLuaState()
{
	UKGQuestEditorSubSystem::Get().ShutDownLuaState();
}


/** Dialog widget used to display an object its properties */
class SObjParamDialog : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SObjParamDialog) {}
	SLATE_END_ARGS()

		void Construct(const FArguments& InArgs, TWeakPtr<SWindow> InParentWindow, const TArray<UObject*>& Objects, bool bCreateAgain = false)
	{
		bOKPressed = false;

		// Initialize details view
		FDetailsViewArgs DetailsViewArgs;
		{
			DetailsViewArgs.bLockable = false;
			DetailsViewArgs.bUpdatesFromSelection = false;
			DetailsViewArgs.bAllowSearch = false;
			//DetailsViewArgs.ColumnWidth = Options.ValueColumnWidthRatio;
			DetailsViewArgs.NameAreaSettings = FDetailsViewArgs::ENameAreaSettings::HideNameArea;
			DetailsViewArgs.bAllowMultipleTopLevelObjects = true;
			DetailsViewArgs.bShowPropertyMatrixButton = false;
		}

		FPropertyEditorModule& PropertyEditorModule = FModuleManager::Get().LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
		TSharedRef<IDetailsView> DetailsView = PropertyEditorModule.CreateDetailView(DetailsViewArgs);

		DetailsView->SetObjects(Objects, true);

		FVector2D DefaultWindowSize = FAppStyle::Get().GetVector("WindowSize.Medium");

		ChildSlot
			[
				SNew(SBox)
				.MinDesiredWidth(400)
				.MinDesiredHeight(300)
				[
					SNew(SVerticalBox)
					+ SVerticalBox::Slot()
					.FillHeight(1.0f)
					[
						SNew(SScrollBox)
						+ SScrollBox::Slot()
					[
						DetailsView->AsShared()
					]
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SBorder)
					.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
					.VAlign(VAlign_Center)
					.HAlign(HAlign_Right)
					[
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
						.Padding(2.0f)
						.AutoWidth()
						[
							SNew(SButton)
							.ContentPadding(FCoreStyle::Get().GetMargin("StandardDialog.ContentPadding"))
							.Text(LOCTEXT("PreCheckID", "PreCheckID"))
							.HAlign(HAlign_Center)
							.OnClicked_Lambda([this, InParentWindow, Objects]()
							{
								UObject* PreObj = Objects[0];
								UPreQuestChapter* ChapterPreObj = dynamic_cast<UPreQuestChapter*>(PreObj);
								UPreQuestRing* RingPreObj = dynamic_cast<UPreQuestRing*>(PreObj);
								UPreQuest* QuestPreObj = dynamic_cast<UPreQuest*>(PreObj);
								bool bLuaVersion = false;
								if (class UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
									bLuaVersion = QuestSettings->bLuaVersion;
								if (ChapterPreObj != nullptr) {
									if (bLuaVersion)
									{
										FString FilePath = FPaths::ProjectContentDir();
										FilePath = FilePath + FString("Script/Data/Config/Quest/Chapter");
										FString FileName = FString::Printf(TEXT("%d"), ChapterPreObj->ChapterID);
										FilePath += FString::Printf(TEXT("/%s.lua"), *FileName);
										const FString AbsolutePath = FPaths::ConvertRelativePathToFull(FilePath);
													
										if (FPaths::FileExists(AbsolutePath))
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("ID[%d] already exist, use new ID"), ChapterPreObj->ChapterID)));
											return FReply::Handled();
										}

										FSourceControlState State = SourceControlHelpers::QueryFileState(AbsolutePath);
										if (State.bIsSourceControlled)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Chapter Already in SourceControll! Please Check P4! ChapterID %d"), ChapterPreObj->ChapterID)));
											return FReply::Handled();
										}
									}
									else
									{
										FString CreateAssetFullPath(TEXT("/Game/Template/Quest/Chapter"));
										FString FileName = FString::Printf(TEXT("%d"), ChapterPreObj->ChapterID);
										CreateAssetFullPath += FString::Printf(TEXT("/%s"), *FileName);

										UPackage* FoundPkg = LoadPackage(NULL, *CreateAssetFullPath, 0);
										if (FoundPkg)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("ID[%d] already exist, use new ID"), ChapterPreObj->ChapterID)));
											return FReply::Handled();
										}

										const FString AbsolutePath = FPaths::ConvertRelativePathToFull(CreateAssetFullPath);

										FSourceControlState State = SourceControlHelpers::QueryFileState(AbsolutePath);
										if (State.bIsSourceControlled)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Chapter Already in SourceControll! Please Check P4! ChapterID %d"), ChapterPreObj->ChapterID)));
											return FReply::Handled();
										}
									}
								}
								else if (RingPreObj != nullptr)
								{
									if (bLuaVersion)
									{
										FString FilePath = FPaths::ProjectContentDir();
										FilePath = FilePath + FString("Script/Data/Config/Quest/Ring");
										FString FileName = FString::Printf(TEXT("%d"), RingPreObj->RingID);
										FilePath += FString::Printf(TEXT("/%s.lua"), *FileName);
										const FString AbsolutePath = FPaths::ConvertRelativePathToFull(FilePath);

										if (FPaths::FileExists(AbsolutePath))
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("ID[%d] already exist, use new ID"), RingPreObj->RingID)));
											return FReply::Handled();
										}

										if (SourceControlHelpers::QueryFileState(AbsolutePath).bIsSourceControlled)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Create Ring Error! Already In SourceControl! Please Check P4! RingID %d"), RingPreObj->RingID)));
											return FReply::Handled();
										}
									}
									else
									{
										FString CreateAssetFullPath(TEXT("/Game/Template/Quest/Ring"));
										if (RingPreObj->RingID / 1000 == 63)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Create Ring Error! ID[%d] 63 Error, use new ID"), RingPreObj->RingID)));
											return FReply::Handled();
										}

										FString FileName = FString::Printf(TEXT("%d"), RingPreObj->RingID);
										CreateAssetFullPath += FString::Printf(TEXT("/%s"), *FileName);

										UPackage* FoundPkg = LoadPackage(NULL, *CreateAssetFullPath, 0);
										if (FoundPkg)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("ID[%d] already exist, use new ID"), RingPreObj->ChapterID)));
											return FReply::Handled();
										}

										const FString AbsolutePath = FPaths::ConvertRelativePathToFull(CreateAssetFullPath);

										if (SourceControlHelpers::QueryFileState(AbsolutePath).bIsSourceControlled)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Ring Already in SourceControll! Please Check P4! RingID %d"), RingPreObj->RingID)));
											return FReply::Handled();
										}
									}
								}
								else if (QuestPreObj != nullptr)
								{
									if (bLuaVersion)
									{
										FString FilePath = FPaths::ProjectContentDir();
										FilePath = FilePath + FString("Script/Data/Config/Quest/Quest");
										FString FileName = FString::Printf(TEXT("%d"), QuestPreObj->QuestID);
										FilePath += FString::Printf(TEXT("/%s.lua"), *FileName);
										const FString AbsolutePath = FPaths::ConvertRelativePathToFull(FilePath);

										if (SourceControlHelpers::QueryFileState(AbsolutePath).bIsCheckedOutOther)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Create Quest Error! ID[%d] already checkout by others, use new ID or check P4"), QuestPreObj->QuestID)));
											return FReply::Handled();
										}
									}
									else
									{
										FString CreateAssetFullPath(TEXT("/Game/Template/Quest/Quest"));
										if (QuestPreObj->QuestID / 100000 == 63)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Create Quest Error! ID[%d] 63 Error, use new ID"), QuestPreObj->QuestID)));
											return FReply::Handled();
										}


										FString FileName = FString::Printf(TEXT("%d"), QuestPreObj->QuestID);
										CreateAssetFullPath += FString::Printf(TEXT("/%s"), *FileName);

										UPackage* FoundPkg = LoadPackage(NULL, *CreateAssetFullPath, 0);
										if (FoundPkg)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Create Quest Error! ID[%d] already exist, use new ID"), QuestPreObj->QuestID)));
											return FReply::Handled();
										}

										const FString AbsolutePath = FPaths::ConvertRelativePathToFull(CreateAssetFullPath);

										if (SourceControlHelpers::QueryFileState(AbsolutePath).bIsSourceControlled)
										{
											FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Quest Already in SourceControll! Please Check P4! QuestID %d"), QuestPreObj->QuestID)));
											return FReply::Handled();
										}
									}
								}
								FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("PreCheck Success!"))));
								return FReply::Handled();
							})
						]
						+ SHorizontalBox::Slot()
						.Padding(2.0f)
						.AutoWidth()
						[
							SNew(SButton)
								.ContentPadding(FCoreStyle::Get().GetMargin("StandardDialog.ContentPadding"))
								.Text(LOCTEXT("NextCreate", "Create Again"))
								.HAlign(HAlign_Center)
								.Visibility(bCreateAgain ? EVisibility::Visible : EVisibility::Hidden)
								.OnClicked_Lambda([this, InParentWindow, InArgs]()
								{
									if (InParentWindow.IsValid())
									{
										InParentWindow.Pin()->RequestDestroyWindow();
									}
									bNextCreate = true;
									return FReply::Handled();
								})
						]
						+ SHorizontalBox::Slot()
						.Padding(2.0f)
						.AutoWidth()
						[
							SNew(SButton)
							.ContentPadding(FCoreStyle::Get().GetMargin("StandardDialog.ContentPadding"))
							.Text(LOCTEXT("CancelButton", "Cancel"))
							.HAlign(HAlign_Center)
							.OnClicked_Lambda([InParentWindow]()
							{
								if (InParentWindow.IsValid())
								{
									InParentWindow.Pin()->RequestDestroyWindow();
								}
								return FReply::Handled();
							})
						]
						+ SHorizontalBox::Slot()
						.Padding(2.0f)
						.AutoWidth()
						[
							SNew(SButton)
								.ContentPadding(FCoreStyle::Get().GetMargin("StandardDialog.ContentPadding"))
								.Text(LOCTEXT("OKButton", "OK"))
								.HAlign(HAlign_Center)
								.OnClicked_Lambda([this, InParentWindow, InArgs]()
									{
										if (InParentWindow.IsValid())
										{
											InParentWindow.Pin()->RequestDestroyWindow();
										}
										bOKPressed = true;
										return FReply::Handled();
									})
						]
					]
				]
			]
		];
	}

	bool WasOkPressed() const { return bOKPressed; }

	bool WasNextCreate() const { return bNextCreate; }
protected:
	bool bOKPressed = false;

	bool bNextCreate = false;
};

void FQuestObjectivesEditor::OnQuestObjectListSelectionChanged(TObjectPtr< UQuestObject > InChangedItem, ESelectInfo::Type SelectInfo)
{
	if (IsValid(InChangedItem))
	{
		PropertyEditor->SetObject(InChangedItem.Get());

		if(auto ChapterObj = Cast<UQuestChapter>(InChangedItem.Get()))
		{
			RefreshChapterGraph(ChapterObj);
		}
	}
	else
	{
		PropertyEditor->SetObject(nullptr);
	}

	if(!InChangedItem || InChangedItem->QuestObjectType == Root)
	{
		return;
	}

	bFocusingTreeView = true;
	
	RebuildRingList(false);

	RebuildQuestList(false);
}

FReply FQuestObjectivesEditor::OnQuestObjectListKeyDownHandler(const FGeometry&, const FKeyEvent& InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::Delete)
	{
		OnDeleteChapter();
		return FReply::Handled();
	}

	return FReply::Unhandled();
}

void FQuestObjectivesEditor::OnQuestObjectListMouseButtonClick(TObjectPtr<UQuestObject> InItem)
{
	if (IsValid(InItem))
	{
		PropertyEditor->SetObject(InItem.Get());
	}
}

TSharedPtr<SWidget> FQuestObjectivesEditor::OnGetQuestObjectListContextMenu()
{
	const FQuestEditorCommands& Commands = FQuestEditorCommands::Get();
	
	// Build up the menu
	FMenuBuilder MenuBuilder(true, ToolkitCommands);
	{
		MenuBuilder.BeginSection("QuestEditor", LOCTEXT("QuestEditor", "QuestEditor"));
		{
			MenuBuilder.AddMenuEntry(Commands.CreateChapter);
			MenuBuilder.AddMenuEntry(Commands.ChapterCopy);
			MenuBuilder.AddMenuEntry(Commands.ChapterCut);
			MenuBuilder.AddMenuEntry(Commands.ChapterPaste);
			MenuBuilder.AddMenuEntry(Commands.ChapterDelete);
		}
		MenuBuilder.EndSection();
	}
	return MenuBuilder.MakeWidget();
}

void FQuestObjectivesEditor::OnChapterListSelectionChanged(TObjectPtr< UQuestChapter > InChangedItem, ESelectInfo::Type SelectInfo)
{
	if (IsValid(InChangedItem))
	{
		PropertyEditor->SetObject(InChangedItem.Get());
	}
	else
	{
		PropertyEditor->SetObject(nullptr);
	}

	bFocusingTreeView = false;
	
	RebuildRingList(false);

	RebuildQuestList(false);
}

void FQuestObjectivesEditor::OnRingListSelectionChanged(TObjectPtr<UQuestRing> InChangedItem, ESelectInfo::Type SelectInfo)
{
	if (IsValid(InChangedItem))
	{
		PropertyEditor->SetObject(InChangedItem.Get());
		RefreshRingGraph(InChangedItem.Get());
	}
	else
	{
		PropertyEditor->SetObject(nullptr);
	}

	RebuildQuestList(false);
}
void FQuestObjectivesEditor::OnRingListItemClicked(TObjectPtr<UQuestRing> InItem)
{
	OnRingListSelectionChanged(InItem, ESelectInfo::Type::Direct);
}

void FQuestObjectivesEditor::OnQuestListSelectionChanged(TObjectPtr<UQuest> InChangedItem, ESelectInfo::Type SelectInfo)
{
	if (IsValid(InChangedItem))
	{
		RefreshQuestGraph(InChangedItem.Get());
		PropertyEditor->SetObject(InChangedItem.Get());
	}
	else
	{
		PropertyEditor->SetObject(nullptr);
	}
}

void FQuestObjectivesEditor::OnQuestListItemClicked(TObjectPtr<UQuest> InItem)
{
	OnQuestListSelectionChanged(InItem, ESelectInfo::Type::Direct);
}

void FQuestObjectivesEditor::OnChapterListItemDoubleClick(TObjectPtr< UQuestChapter > InItem)
{
	OnChapterListSelectionChanged(InItem, ESelectInfo::Direct);
}

void FQuestObjectivesEditor::OnRingListItemDoubleClick(TObjectPtr<UQuestRing> InItem)
{
}

void FQuestObjectivesEditor::OnQuestListItemDoubleClick(TObjectPtr<UQuest> InItem)
{

}

void FQuestObjectivesEditor::OnChapterTypeChanged(UQuestChapter* ChangedChapter)
{
	TObjectPtr<UQuestObject> NewRoot = ChangedChapter;
	for(auto Root : QuestObjectTreeView->GetRootItems())
	{
		if(Root->QuestType == ChangedChapter->QuestType)
		{
			NewRoot = Root;
			break;
		}
	}

	bool bNeedChangeID = true;
	FText CheckDialog;
	RefreshChapterGraph(ChangedChapter);
	// 如果 id 本来就合法，则无需操作（无需重新分配id等），只改 ChapterID 就行
	// 例如 主线任务 切换成 原著任务，他们共享一个 id 段
	if (ChangedChapter->CheckChapterID(CheckDialog, false))
	{
		bNeedChangeID = false;
	}
	// 如果需要改 id，则要删除 chapter 本身
	if (!CutSelectedChapter(bNeedChangeID))
	{
		if (IsValid(ChangedChapter->Father))
		{
			ChangedChapter->QuestType = ChangedChapter->Father->QuestType;
		}
		return;
	}
	QuestObjectTreeView->SetSelection(NewRoot);
	PasteCopiedChapter(bNeedChangeID);
	RebuildQuestObjectList(false);
}


TSharedRef<ITableRow> FQuestObjectivesEditor::GenerateRingItemRow(TObjectPtr<UQuestRing> Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	FText DisplayText = FText::FromString(FString::Printf(TEXT("%d - %s"), Item->QuestObjectID, *Item->QuestObjectName));
	return SNew(STableRow<TObjectPtr<UQuestRing>>, OwnerTable)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		.AutoWidth()
			//TODO: SourceControl mark implant
		//[
		//	SNew(SImage)
		//	.Image(FAppStyle::GetBrush(TEXT("SourceControl.Add")))
		//	.ColorAndOpacity(FLinearColor::Red)
		//]
	+ SHorizontalBox::Slot()
		[
			SNew(STextBlock)
			.Text(DisplayText)
		]

		];
}

TSharedRef<ITableRow> FQuestObjectivesEditor::GenerateQuestItemRow(TObjectPtr<UQuest> Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	FText DisplayText = FText::FromString(FString::Printf(TEXT("%d - %s"), Item->QuestObjectID, *Item->QuestObjectName));
	return SNew(STableRow<TObjectPtr<UQuest>>, OwnerTable)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		//.AutoWidth()
		//[
		//	SNew(SImage)
		//	.Image(FAppStyle::GetBrush(TEXT("SourceControl.Add")))
		//.ColorAndOpacity(FLinearColor::Red)
		//]
	+ SHorizontalBox::Slot()
		[
			SNew(STextBlock)
			.Text(DisplayText)
		]

		];

}

void FQuestObjectivesEditor::LoadAllQuestAssets()
{
	DataEntity->AllChapters.Reset();
	DataEntity->AllQuestRings.Reset();
	DataEntity->AllQuests.Reset();
	
	TArray<FString> ChapterNames, RingNames, QuestNames;
	FString ChapterFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Chapter");
	FString RingFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Ring");
	FString QuestFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Quest");
	ChapterFilePath = FPaths::ConvertRelativePathToFull(ChapterFilePath);
	RingFilePath = FPaths::ConvertRelativePathToFull(RingFilePath);
	QuestFilePath = FPaths::ConvertRelativePathToFull(QuestFilePath);
	GetAllFilenamesInDirectory(ChapterFilePath, ChapterNames);
	GetAllFilenamesInDirectory(RingFilePath, RingNames);
	GetAllFilenamesInDirectory(QuestFilePath, QuestNames);

	DataEntity->QuestTypes.SetNum(static_cast<int>(EQuestType::EQT_Max));
	
	RebuildRootItems();

	TSharedPtr<FQuestImporter> QuestImporter = MakeShared<FQuestImporter>();
	// Chapter
	for (FString ChapterPath : ChapterNames)
	{
		if(TSharedPtr<FLuaTable> ChapterLuaTable = FQuestLuaImporter::ConvertLuaFileToLuaTable(ChapterPath))
		{
			UClass* QuestChapterClass(UQuestChapter::StaticClass());
			if (UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
			{
				if (UClass* Class = GetBPClass(QuestSettings->ChapterDataBP))
				{
					QuestChapterClass = Class;
				}
			}
			UQuestChapter* QC = NewObject<UQuestChapter>(DataEntity, QuestChapterClass);
			QuestImporter->ImportLuaToObj(ChapterLuaTable, QC);
			QC->QuestObjectName = QC->ChapterName;
			AddChapterObj(QC, true);
		}
	}

	// Ring
	for (FString RingPath : RingNames)
	{
		if(TSharedPtr<FLuaTable> RingLuaTable = FQuestLuaImporter::ConvertLuaFileToLuaTable(RingPath))
		{
			UClass* QuestRingClass(UQuestRing::StaticClass());
			if (class UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
			{
				if (UClass* Class = GetBPClass(QuestSettings->RingDataBP))
				{
					QuestRingClass = Class;
				}
			}
			UQuestRing* QR = NewObject<UQuestRing>(DataEntity, QuestRingClass);
			QuestImporter->ImportLuaToObj(RingLuaTable, QR);
			QR->QuestObjectName = QR->RingName;
			AddRingObj(QR, true);
			const TSharedPtr<FLuaTable>* QuestDataTable;
			if (RingLuaTable->TryGetTableField(TEXT("QuestData"), QuestDataTable))
			{
				for (const auto& Pair : (*QuestDataTable)->Values)
				{
					if (TSharedPtr<FLuaTable> QuestTable = Pair.Value->AsTable())
					{
						UClass* QuestClass(UQuest::StaticClass());
						if (UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
						{
							if (UClass* Class = GetBPClass(QuestSettings->QuestDataBP))
							{
								QuestClass = Class;
							}
						}
						UQuest* Q = NewObject<UQuest>(DataEntity, QuestClass);
						QuestImporter->ImportLuaToObj(QuestTable, Q);
						Q->ChapterID = QR->ChapterID;
						Q->RingID = QR->RingID;
						Q->QuestObjectName = Q->QuestName;
						AddQuestObj(Q, true);
					}
				}
			}
		}
	}
	
	for (auto QuestObj : DataEntity->QuestObjectMap)
	{
		RebuildQuestObjectRelations(QuestObj.Value.Get());
	}

	RecoverQuestObjectFilteredItems();
}

void FQuestObjectivesEditor::AddChapterObjToDataEntity(UQuestChapter* InObj)
{
	if (InObj == nullptr)
	{
		return;
	}
	
	DataEntity->AllChapters.Add(InObj);
	InObj->QuestObjectID = InObj->ChapterID;
	InObj->QuestObjectName = InObj->ChapterName;
	InObj->QuestObjectType = Chapter;
	DataEntity->AllQuestObject.Add(InObj);
	if(DataEntity->QuestObjectMap.Contains(InObj->QuestObjectID))
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("Conflict questobject ID %i"), InObj->QuestObjectID);
	}
	DataEntity->QuestObjectMap.Add(InObj->QuestObjectID, InObj);
	DataEntity->ChapterMap.Add(InObj->QuestObjectID, InObj);
}

void FQuestObjectivesEditor::AddRingObjToDataEntity(UQuestRing* InObj)
{
	if (InObj == nullptr)
	{
		return;
	}
	
	DataEntity->AllQuestRings.Add(InObj);
	InObj->QuestObjectID = InObj->RingID;
	if(DataEntity->QuestObjectMap.Contains(InObj->QuestObjectID))
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("Conflict questobject unique ID %i"), InObj->QuestObjectID);
	}
	DataEntity->QuestObjectMap.Add(InObj->QuestObjectID, InObj);
	DataEntity->RingMap.Add(InObj->QuestObjectID, InObj);
}

void FQuestObjectivesEditor::LoadChapterGraph(UQuestChapter* InChapter)
{
	FString ChapterFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Chapter");
	ChapterFilePath = FPaths::ConvertRelativePathToFull(ChapterFilePath);
	const FString FileName = FString::Printf(TEXT("%d"), InChapter->ChapterID);
	ChapterFilePath += FString::Printf(TEXT("/%s.lua"), *FileName);

	if(TSharedPtr<FLuaTable> ChapterLuaTable = FQuestLuaImporter::ConvertLuaFileToLuaTable(ChapterFilePath))
	{
		// 需要把NextTaskInfoList的数据也加载进来
		// 普通反序列化难以加载未创建的NextTaskInfoList
		// 初始化Graph时会尝试修改NextTaskInfoList, 所以在这个时序处理
		// TArray<FString> RingNames;
		FString RingFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Ring");
		RingFilePath = FPaths::ConvertRelativePathToFull(RingFilePath);
		for (auto Child : InChapter->Children)
		{
			TObjectPtr<UQuestRing> TempRing = Cast<UQuestRing>(Child);
			if(IsValid(TempRing))
			{
				FString RingFileName = FString::Printf(TEXT("%d.lua"), TempRing->RingID);
				FString RingPath = FPaths::Combine(RingFilePath, RingFileName);
				if(TSharedPtr<FLuaTable> RingLuaTable = FQuestLuaImporter::ConvertLuaFileToLuaTable(RingPath))
				{
					UQuestRing* R = GetRingObjByRingID(TempRing->RingID);
					FQuestLuaImporter::FillNextTaskWithLuaTable(R, RingLuaTable);

					TSharedPtr<FQuestImporter> QuestImporter = MakeShared<FQuestImporter>(true);
					QuestImporter->ImportLuaToObj(RingLuaTable, R);
				}
			}
		}
		
		// 加载ChapterGraph
		FQuestLuaImporter::FillChapterGraphWithLuaTable(InChapter, ChapterLuaTable);
	}
}

void FQuestObjectivesEditor::RemapPreRingRelations(UPreRingInfo* InPreRingInfo)
{
	if(auto PreRingID = Cast<UPreRingID>(InPreRingInfo))
	{
		if(DataEntity->RevCopiedMapping.Contains(PreRingID->PreRingID))
		{
			PreRingID->PreRingID = DataEntity->RevCopiedMapping[PreRingID->PreRingID];
		}
	}else if(auto AndRelation = Cast<UAndRelation>(InPreRingInfo))
	{
		for(auto Child : AndRelation->ChildInfo)
		{
			RemapPreRingRelations(Child);
		}
	}else if(auto OrRelation = Cast<UOrRelation>(InPreRingInfo))
	{
		for(auto Child : OrRelation->ChildInfo)
		{
			RemapPreRingRelations(Child);
		}
	}
}

void FQuestObjectivesEditor::LoadRingGraph(UQuestRing* InRing)
{
	FString RingFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Ring");
	RingFilePath = FPaths::ConvertRelativePathToFull(RingFilePath);
	const FString FileName = FString::Printf(TEXT("%d"), InRing->RingID);
	RingFilePath += FString::Printf(TEXT("/%s.lua"), *FileName);
	if (!FPaths::FileExists(RingFilePath))
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("File does not exist: %s. Maybe new ring."), *RingFilePath);
		return;
	}
	if (TSharedPtr<FLuaTable> RingLuaTable = FQuestLuaImporter::ConvertLuaFileToLuaTable(RingFilePath))
	{
		bLoadingRingGraph = true;
		const TSharedPtr<FLuaTable>* QuestDataTable;
		if (RingLuaTable->TryGetTableField(TEXT("QuestData"), QuestDataTable))
		{
			for (const auto& Pair : (*QuestDataTable)->Values)
			{
				if (TSharedPtr<FLuaTable> QuestLTable = Pair.Value->AsTable())
				{
					const int32 QuestID = QuestLTable->GetIntegerField(TEXT("QuestID"));
					UQuest* Q = GetQuestObjByQuestID(QuestID);
					FQuestLuaImporter::FillNextTaskWithLuaTable(Q, QuestLTable);
				}
			}
		}
		// 加载RingGraph和懒加载的UObj数据
		FQuestLuaImporter::FillRingGraphAndObjDataWithLuaTable(InRing, RingLuaTable);
		bLoadingRingGraph = false;
	}
}

void FQuestObjectivesEditor::LoadQuestGraph(UQuest* InQuest)
{
	bool bSaveAndLoadQuestInRing = false;
	if (UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
	{
		bSaveAndLoadQuestInRing = QuestSettings->bSaveAndLoadQuestInRing;
	}

	bool bFillQuest = false;

	// 优先从 Ring 的数据内拿 Quest
	if (bSaveAndLoadQuestInRing)
	{
		FString RingFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Ring");
		RingFilePath = FPaths::ConvertRelativePathToFull(RingFilePath);
		const FString FileName = FString::Printf(TEXT("%d"), InQuest->RingID);
		RingFilePath += FString::Printf(TEXT("/%s.lua"), *FileName);

		bLoadingQuestGraph = true;
		auto RingJObj = FEditorLuaSerializeHelper::ConvertLuaFileToJsonObject(RingFilePath);
		if (RingJObj.IsValid())
		{
			// QuestData 为 map，key 为 QuestID
			if (TSharedPtr<FJsonObject> QuestDataObject = FQuestImportLua::GetQuestDataObjectInRingJObj(RingJObj))
			{
				for (const auto& Pair : QuestDataObject->Values)
				{
					TSharedPtr<FJsonValue> QuestData = Pair.Value;
					if (QuestData.IsValid())
					{
						const TSharedPtr<FJsonObject>& QuestJObj = QuestData->AsObject();
						const int32 QuestID = QuestJObj->GetIntegerField(TEXT("QuestID"));
						if (QuestID == InQuest->QuestID)
						{
							FQuestImportLua::FillQuestGraphWithLuaStr(InQuest, QuestJObj);
							FQuestImportLua::FillQuestDataArrayWithLuaStr(InQuest, QuestJObj);
							bFillQuest = true;
						}
					}
				}
			}

			// 旧数据兼容：QuestData 为数组形式
			const TArray<TSharedPtr<FJsonValue>>& QuestDataArray = FQuestImportLua::GetQuestDataArrayInRingJObj(RingJObj);
			for (TSharedPtr<FJsonValue> QuestData : QuestDataArray)
			{
				if (QuestData.IsValid())
				{
					const TSharedPtr<FJsonObject>& QuestJObj = QuestData->AsObject();
					const int32 QuestID = QuestJObj->GetIntegerField(TEXT("QuestID"));
					if (QuestID == InQuest->QuestID)
					{
						FQuestImportLua::FillQuestGraphWithLuaStr(InQuest, QuestJObj);
						FQuestImportLua::FillQuestDataArrayWithLuaStr(InQuest, QuestJObj);
						bFillQuest = true;
					}
				}
			}
		}
	}

	// 兼容旧的 Quest 文件的形式
	if (!bFillQuest)
	{
		FString QuestFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Quest");
		QuestFilePath = FPaths::ConvertRelativePathToFull(QuestFilePath);
		int32 TargetID = InQuest->QuestID;
		const FString FileName = FString::Printf(TEXT("%d"), TargetID);
		QuestFilePath += FString::Printf(TEXT("/%s.lua"), *FileName);

		bLoadingQuestGraph = true;
		auto QuestJObj = FEditorLuaSerializeHelper::ConvertLuaFileToJsonObject(QuestFilePath);
		if (QuestJObj.IsValid())
		{
			FQuestImportLua::FillQuestGraphWithLuaStr(InQuest, QuestJObj);
			FQuestImportLua::FillQuestDataArrayWithLuaStr(InQuest, QuestJObj);
		}
	}

	// 主目标单独提出
	int MainIndex = 0;
	for (int Index = 0; Index < InQuest->QuestTargets.Num(); Index++)
	{
		if(InQuest->QuestTargets[Index]->bIsMain)
		{
			MainIndex = Index;
			break;
		}
	}
	bLoadingQuestGraph = false;
	if(InQuest->QuestTargets.Num() == 0)
	{
		return;
	}
	InQuest->MainTarget = InQuest->QuestTargets[MainIndex];
	InQuest->MainTarget->bIsMain = true;
	InQuest->QuestTargets.RemoveAt(MainIndex);
}

void FQuestObjectivesEditor::LoadQuestGraphNew(UQuest* InQuest)
{
	FString RingFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Ring");
	RingFilePath = FPaths::ConvertRelativePathToFull(RingFilePath);
	const FString FileName = FString::Printf(TEXT("%d"), InQuest->RingID);
	RingFilePath += FString::Printf(TEXT("/%s.lua"), *FileName);

	if (TSharedPtr<FLuaTable> RingLuaTable = FQuestLuaImporter::ConvertLuaFileToLuaTable(RingFilePath))
	{
		LoadQuestGraphNew(InQuest, RingLuaTable);
	}
}

void FQuestObjectivesEditor::LoadQuestGraphNew(UQuest* InQuest, const TSharedPtr<FLuaTable>& LuaTable)
{
	const TSharedPtr<FLuaTable>* QuestDataTable = nullptr;
	if (LuaTable->TryGetTableField(TEXT("QuestData"), QuestDataTable))
	{
		FString QuestIDStr = FString::FromInt(InQuest->QuestID);
		if ((*QuestDataTable)->Values.Contains(QuestIDStr))
		{
			const TSharedPtr<FLuaTable>& QuestTable = (*QuestDataTable)->Values[QuestIDStr]->AsTable();
			FQuestLuaImporter::FillQuestObjDataWithLuaTable(InQuest, QuestTable);
		}
	}
	
	// 主目标单独提出
	int MainIndex = 0;
	for (int Index = 0; Index < InQuest->QuestTargets.Num(); Index++)
	{
		if(InQuest->QuestTargets[Index]->bIsMain)
		{
			MainIndex = Index;
			break;
		}
	}
	bLoadingQuestGraph = false;
	if(InQuest->QuestTargets.Num() == 0)
	{
		return;
	}
	InQuest->MainTarget = InQuest->QuestTargets[MainIndex];
	InQuest->MainTarget->bIsMain = true;
	InQuest->QuestTargets.RemoveAt(MainIndex);
}

void FQuestObjectivesEditor::CreateChapter()
{
	const FScopedTransaction Transaction(LOCTEXT("CreateChapterTransaction", "Create Chapter"));
	DataEntity->Modify();
	UPreQuestChapter* PreObj = NewObject<UPreQuestChapter>();

	auto SelectedItems = QuestObjectTreeView->GetSelectedItems();
	if(SelectedItems.Num() > 0)
	{
		PreObj->QuestType = SelectedItems[0]->QuestType;
	}
	UClass* QuestChapterClass(UQuestChapter::StaticClass());
	UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass());
	if (QuestSettings)
	{
		if (UClass* Class = GetBPClass(QuestSettings->ChapterDataBP))
		{
			QuestChapterClass = Class;
		}
	}

	UQuestChapter* Obj = NewObject<UQuestChapter>(DataEntity, QuestChapterClass);
	
	PreObj->ChapterID = GetAvailableID(Obj);

	TArray<UObject*> ViewObjects = { PreObj };

	bool bShowDialogue = true;
	if(QuestSettings)
	{
		bShowDialogue = QuestSettings->bCreateChapterDialogue;
	}
	TSharedRef<SWindow> Window = SNew(SWindow)
		.Title(FText::FromString(TEXT("Create Chapter")))
		.SizingRule(ESizingRule::Autosized)
		.AutoCenter(EAutoCenter::PrimaryWorkArea)
		.SupportsMinimize(false)
		.SupportsMaximize(false);
	
	TSharedPtr<SObjParamDialog> Dialog;
	if(bShowDialogue)
	{
		Window->SetContent(SAssignNew(Dialog, SObjParamDialog, Window, ViewObjects));
		GEditor->EditorAddModalWindow(Window);
	}

	if (!bShowDialogue || Dialog->WasOkPressed())
	{
		FString FilePath = FPaths::ProjectContentDir();
		FilePath = FilePath + FString("Script/Data/Config/Quest/Chapter");
		FString FileName = FString::Printf(TEXT("%d"), PreObj->ChapterID);
		FString FinalName = FilePath + FString::Printf(TEXT("/%s.lua"), *FileName);
		const FString AbsolutePath = FPaths::ConvertRelativePathToFull(FinalName);

		auto SCState = SourceControlHelpers::QueryFileState(AbsolutePath);
		
		if (FPaths::FileExists(AbsolutePath) || SCState.bIsCheckedOutOther)
		{
			FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("CreateChapterDuplicateID", "ID[{0}] already exist, use new ID"), PreObj->ChapterID));
			return;
		}

		FString DepotPath;
		GetDepotPath(AbsolutePath, DepotPath);
		if(IsCheckedOutByOthers(DepotPath))
		{
			FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("CreateChapterAlreadyInSC", "Chapter Already in SourceControll! Please Check P4! ChapterID {0}"), PreObj->ChapterID));
			return;
		}
		
		Obj->ChapterID = PreObj->ChapterID;
		Obj->QuestType = PreObj->QuestType;
		Obj->ChapterName = PreObj->ChapterName;
		Obj->ChapterIndex = PreObj->ChapterIndex;
		
		MarkAssetForDirty(Obj);

		AddChapterObj(Obj);

		RebuildChapterList(true);

		if(bFocusingTreeView && Obj->Father)
		{
			QuestObjectTreeView->SetItemExpansion(Obj->Father, true);
			QuestObjectTreeView->SetSelection(Obj);
		}
		
		//if (UEDGraphBase* ChapterGraphBase = Cast<UEDGraphBase>(Obj->ChapterGraph))
		//{
		//	const UEdGraphSchema* Schema = ChapterGraphBase->GetSchema();
		//	if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
		//	{
		//		FVector2D NewPlacePos = FVector2D(0, 0);
		//		ThisSchema->CreateRingNode(ChapterGraphBase, CreateRing(), NewPlacePos, true);
		//	}
		//}
	}
}

void FQuestObjectivesEditor::AddQuestObjToDataEntity(UQuest* InObj)
{
	if (InObj == nullptr)
	{
		return;
	}

	DataEntity->AllQuests.Add(InObj);
	InObj->QuestObjectivesEditor = this->AsWeak();
	InObj->QuestObjectID = InObj->QuestID;
	if(DataEntity->QuestObjectMap.Contains(InObj->QuestObjectID))
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("Conflict questobject unique ID %i"), InObj->QuestObjectID);
	}
	DataEntity->QuestObjectMap.Add(InObj->QuestObjectID, InObj);
	DataEntity->QuestMap.Add(InObj->QuestObjectID, InObj);
}

bool FQuestObjectivesEditor::RemoveChapterInDataEntity(UQuestChapter* InObj)
{
	if (InObj == nullptr)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("func FQuestObjectivesEditor::RemoveChapterInDataEntity InObj is nullptr."));
		return false;
	}
	
	int32 RemoveIdx = -1;
	for (size_t i = 0; i < DataEntity->AllChapters.Num(); i++)
	{
		auto i2 = DataEntity->AllChapters[i];
		if (IsValid(i2) && i2.Get() == InObj)
		{
			RemoveIdx = i;
			break;
		}
	}
	if (RemoveIdx >= 0)
	{
		DataEntity->AllChapters.RemoveAt(RemoveIdx);
	}
	
	RemoveIdx = -100;
	for (size_t i = 0; i < DataEntity->AllQuestObject.Num(); i++)
	{
		auto i2 = DataEntity->AllQuestObject[i];
		if (IsValid(i2) && i2.Get() == InObj)
		{
			RemoveIdx = i;
			break;
		}
	}
	if (RemoveIdx >= 0)
	{
		DataEntity->AllQuestObject.RemoveAt(RemoveIdx);
	}
	if(DataEntity->ChapterMap.Contains(InObj->ChapterID))
	{
		DataEntity->ChapterMap.Remove(InObj->ChapterID);
	}
	if(DataEntity->QuestObjectMap.Contains(InObj->QuestObjectID))
	{
		DataEntity->QuestObjectMap.Remove(InObj->QuestObjectID);
	}

	return true;
}

bool FQuestObjectivesEditor::RemoveRingInDataEntity(UQuestRing* InObj)
{
	if (InObj == nullptr)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("func FQuestObjectivesEditor::RemoveRingInDataEntity InObj is nullptr."));
		return false;
	}
	
	int32 RemoveIdx = -1;
	for (size_t i = 0; i < DataEntity->AllQuestRings.Num(); i++)
	{
		auto i2 = DataEntity->AllQuestRings[i];
		if (IsValid(i2) && i2.Get() == InObj)
		{
			RemoveIdx = i;
			break;
		}
	}
	if (RemoveIdx >= 0)
	{
		DataEntity->AllQuestRings.RemoveAt(RemoveIdx);
	}
	if(DataEntity->RingMap.Contains(InObj->RingID))
	{
		DataEntity->RingMap.Remove(InObj->RingID);
	}
	if(DataEntity->QuestObjectMap.Contains(InObj->QuestObjectID))
	{
		DataEntity->QuestObjectMap.Remove(InObj->QuestObjectID);
	}

	return true;
}

bool FQuestObjectivesEditor::RemoveQuestInDataEntity(UQuest* InObj)
{
	if (InObj == nullptr)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("func FQuestObjectivesEditor::RemoveQuestInDataEntity InObj is nullptr."));
		return false;
	}
	
	int32 RemoveIdx = -1;
	for (int32 i = 0; i < DataEntity->AllQuests.Num(); i++)
	{
		auto i2 = DataEntity->AllQuests[i];
		if (IsValid(i2) && i2.Get() == InObj)
		{
			RemoveIdx = i;
			break;
		}
	}
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Remove Quest In Data Entity: %d."), InObj->QuestID);
	if (RemoveIdx >= 0)
	{
		DataEntity->AllQuests.RemoveAt(RemoveIdx);
	}
	if(DataEntity->QuestMap.Contains(InObj->QuestID))
	{
		DataEntity->QuestMap.Remove(InObj->QuestID);
	}
	if(DataEntity->QuestObjectMap.Contains(InObj->QuestObjectID))
	{
		DataEntity->QuestObjectMap.Remove(InObj->QuestObjectID);
	}

	return true;
}

void FQuestObjectivesEditor::RemoveInDataEntityMap(int32 InQuestObjectID)
{
	if(DataEntity->QuestMap.Contains(InQuestObjectID))
	{
		DataEntity->QuestMap.Remove(InQuestObjectID);
	}
	if(DataEntity->RingMap.Contains(InQuestObjectID))
	{
		DataEntity->RingMap.Remove(InQuestObjectID);
	}
	if(DataEntity->ChapterMap.Contains(InQuestObjectID))
	{
		DataEntity->ChapterMap.Remove(InQuestObjectID);
	}
	if(DataEntity->QuestObjectMap.Contains(InQuestObjectID))
	{
		DataEntity->QuestObjectMap.Remove(InQuestObjectID);
	}
}

void FQuestObjectivesEditor::AddInDataEntityMap(UQuestObject* InObj)
{
	if (!InObj) return;

	if (UQuest* Quest = Cast<UQuest>(InObj))
	{
		DataEntity->QuestMap.Add(Quest->QuestID, Quest);
		DataEntity->QuestObjectMap.Add(Quest->QuestObjectID, Quest);
	}
	else if (UQuestRing* Ring = Cast<UQuestRing>(InObj))
	{
		DataEntity->RingMap.Add(Ring->RingID, Ring);
		DataEntity->QuestObjectMap.Add(Ring->QuestObjectID, Ring);
	}
	else if (UQuestChapter* Chapter = Cast<UQuestChapter>(InObj))
	{
		DataEntity->ChapterMap.Add(Chapter->ChapterID, Chapter);
		DataEntity->QuestObjectMap.Add(Chapter->QuestObjectID, Chapter);
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("InObj %s is not quest or ring or chapter."), *InObj->GetName());
		return;
	}
}

void FQuestObjectivesEditor::AddChapterObj(UQuestChapter* InObj, bool bInit)
{
	if (InObj == nullptr)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("AddChapterObj failed: InObj nullptr."));
		return;
	}
	
	if (!bInit)
	{
		// 初始化加载的时候不刷log，否则太多了
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("AddChapterObj: %d."), InObj->ChapterID);
	}

#if WITH_EDITOR
	InObj->OnRefreshChapter.RemoveAll(this);
	InObj->OnRefreshChapter.AddRaw(this, &FQuestObjectivesEditor::OnRefreshChapter);
	InObj->OnPropertyChangedToBp();
#endif
	AddChapterObjToDataEntity(InObj);
	if(!bInit)
	{
		RebuildQuestObjectRelations(InObj);
	}
}

void FQuestObjectivesEditor::AddRingObj(UQuestRing* InObj, bool bInit)
{
	if (InObj == nullptr)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("AddRingObj failed: InObj nullptr."));
		return;
	}
	
	if (!bInit)
	{
		// 初始化加载的时候不刷log，否则太多了
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("AddRingObj: %d."), InObj->RingID);
	}

#if WITH_EDITOR
	InObj->OnPropertyChangedToBp();
	InObj->QuestObjectivesEditor = this->AsWeak();
#endif
	AddRingObjToDataEntity(InObj);
	if(!bInit)
	{
		RebuildQuestObjectRelations(InObj);
	}
}

void FQuestObjectivesEditor::AddQuestObj(UQuest* InObj, bool bInit)
{
	if (InObj == nullptr)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("AddQuestObj failed: InObj nullptr."));
		return;
	}

	if (!bInit)
	{
		// 初始化加载的时候不刷log，否则太多了
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("AddQuestObj: %d."), InObj->QuestID);
	}

#if WITH_EDITOR
	InObj->OnPropertyChangedToBp();
#endif
	
	AddQuestObjToDataEntity(InObj);
	if(!bInit)
	{
		RebuildQuestObjectRelations(InObj);
	}
}

void FQuestObjectivesEditor::DeleteChapterObj(UQuestChapter* InObj)
{
	if (InObj == nullptr)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("DeleteChapterObj failed: InObj nullptr."));
		return;
	}
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("DeleteChapterObj: %d."), InObj->ChapterID);
	
	int RemoveIdx = -1;
	TObjectPtr<UQuestChapter> DirtyAssetPtr(InObj);
	RebuildQuestObjectRelations(InObj, true);
	DataEntity->DirtyChapters.Remove(InObj);
	DataEntity->DirtyCheckChapters.Remove(InObj);
	
	RemoveChapterInDataEntity(InObj);
	
	DataEntity->PendingDeleteObjects.Add(InObj);
}

void FQuestObjectivesEditor::DeleteRingObj(UQuestRing* InObj)
{
	if (InObj == nullptr)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("DeleteRingObj failed: InObj nullptr."));
		return;
	}
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("DeleteRingObj: %d."), InObj->RingID);
	
	TObjectPtr<UQuestRing> DirtyAssetPtr(InObj);
	RebuildQuestObjectRelations(InObj, true);
	DataEntity->DirtyRings.Remove(InObj);
	DataEntity->DirtyCheckRings.Remove(InObj);
	
	RemoveRingInDataEntity(InObj);
	
	DataEntity->PendingDeleteObjects.Add(InObj);
}

void FQuestObjectivesEditor::DeleteQuestObj(UQuest* InObj)
{
	if (InObj == nullptr)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("DeleteQuestObj failed: InObj nullptr."));
		return;
	}
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("DeleteQuestObj: %d."), InObj->QuestID);
	
	TObjectPtr<UQuest> DirtyAssetPtr(InObj);
	RebuildQuestObjectRelations(InObj, true);
	DataEntity->DirtyQuests.Remove(InObj);
	DataEntity->DirtyCheckQuests.Remove(InObj);

	RemoveQuestInDataEntity(InObj);
	
	DataEntity->PendingDeleteObjects.Add(InObj);
}

void FQuestObjectivesEditor::RebuildQuestObjectRelations(UQuestObject* InObj, bool bDelete)
{
	UQuestChapter* Chapter = Cast<UQuestChapter>(InObj);
	UQuestRing* Ring = Cast<UQuestRing>(InObj);
	UQuest* Quest = Cast<UQuest>(InObj);
	DataEntity->Modify();
	InObj->Modify();
	if(bDelete)
	{
		if(InObj->Father.Get())
		{
			int IndexForDelete = -1;
			InObj->Father->Modify();
			for(int i = 0; i < InObj->Father->Children.Num() ; ++i)
			{
				auto Child = InObj->Father->Children[i];
				if(Child.Get() && Child == InObj)
				{
					Child = nullptr;
					IndexForDelete = i;
					break;
				}
			}
			if(IndexForDelete != -1)
			{
				InObj->Father->Children.RemoveAt(IndexForDelete, 1, false);
			}
			InObj->Father = nullptr;
		}
		return;
	}
	
	if(InObj->Father.Get())
	{
		InObj->Father->Modify();
		InObj->Father->Children.RemoveSingle(InObj);
		InObj->Father = nullptr;
	}
	if(Chapter)
	{
		int QuestTypeNum = static_cast<int>(InObj->QuestType);
		Chapter->Father = DataEntity->QuestTypes[QuestTypeNum];
		DataEntity->QuestTypes[QuestTypeNum]->Modify();
		DataEntity->QuestTypes[QuestTypeNum]->Children.Add(Chapter);
	}else if(Ring)
	{
		auto ChapterID = Ring->ChapterID;
		if(DataEntity->ChapterMap.Contains(ChapterID))
		{
			Ring->Father = DataEntity->ChapterMap[ChapterID];
			DataEntity->ChapterMap[ChapterID]->Modify();
			DataEntity->ChapterMap[ChapterID]->Children.Add(Ring);
			Ring->QuestType = Ring->Father->QuestType;
		}
	}
	else if(Quest)
	{
		auto RingID = Quest->RingID;
		if(DataEntity->RingMap.Contains(RingID))
		{
			Quest->Father = DataEntity->RingMap[RingID];
			DataEntity->RingMap[RingID]->Modify();
			DataEntity->RingMap[RingID]->Children.Add(Quest);
			Quest->QuestType = Quest->Father->QuestType;
		}
	}
}

void FQuestObjectivesEditor::QuestObjectTreeRefresh(bool bKeepSelection)
{
	TArray<TObjectPtr<UQuestObject>> ExpandedItems;
	if(bKeepSelection)
	{
		for (auto Item : QuestObjectTreeView->GetRootItems())
		{
			if (QuestObjectTreeView->IsItemExpanded(Item))
			{
				ExpandedItems.Add(Item);
			}
		}
	}
	QuestObjectTreeView->RequestTreeRefresh();
	if(bKeepSelection)
	{
		for (auto Item : ExpandedItems)
		{
			QuestObjectTreeView->SetItemExpansion(Item, true);
		}
	}
}

void FQuestObjectivesEditor::ClearRingGraph()
{
	RefreshRingGraph(nullptr);
}

void FQuestObjectivesEditor::ClearChapterGraph()
{
	RefreshChapterGraph(nullptr);
}

void FQuestObjectivesEditor::OnAssetRemoved(const FAssetData& InAssetData)
{
	FString AssetPath = InAssetData.PackagePath.ToString();
	if (AssetPath.Contains(QuestAssetPath))
	{
		if (bRemovingQuest && AssetPath.Contains(TEXT("/Game/Template/Quest/Quest")))
		{
			// Delete Quest In QuestEditor, it's ok, do nothing
		}
		else if(!bRemoveQuestClosing)
		{
			FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(TEXT("Do Not Delete Quest Asset Outside While QuestEditor Open! AssetName: " + InAssetData.AssetName.ToString())));
			FText ConfirmText = LOCTEXT("Outside Delete Warning", "Closing Quest Editor...");
			FMessageDialog::Open(EAppMsgType::YesNo, ConfirmText);
			CloseWindow(EAssetEditorCloseReason::AssetForceDeleted);
			/**if (GEditor != nullptr)
			{
				GEditor->GetTimerManager()->SetTimerForNextTick([this]()
					{
						CloseWindow();
					});
			}*/
			bRemoveQuestClosing = true;
		}
	}
}

void FQuestObjectivesEditor::OnRefreshChapter()
{
	MarkCurChapterForDirty();
	// 有可能会出现修改属性显隐的情况, 这里刷新下面板
	if(bFocusingTreeView)
	{
		TArray<TObjectPtr<UQuestObject>> Selections = QuestObjectTreeView->GetSelectedItems();
		OnRefresh(false);
		if (Selections.Num() > 0)
		{
			auto SelectedItem = Selections[0];
			if (IsValid(SelectedItem))
			{
				OnRefreshPropertyEditor(SelectedItem.Get());
			}
			if(IsValid(SelectedItem->Father))
			{
				QuestObjectTreeView->SetItemExpansion(SelectedItem->Father, true);
				QuestObjectTreeView->SetSelection(SelectedItem);
			}
		}
	}else
	{
		TArray<TObjectPtr<UQuestChapter>> Selections = ChapterListView->GetSelectedItems();
		if (Selections.Num() > 0)
		{
			TObjectPtr<UQuestChapter> SelectedItem = Selections[0];
			if (IsValid(SelectedItem))
			{
				OnRefreshPropertyEditor(SelectedItem.Get());
			}
			if (IsValid(SelectedItem->Father))
			{
				ChapterListView->SetSelection(SelectedItem);
			}
		}
	}
}

void FQuestObjectivesEditor::OnRefreshRingName()
{
	// OnRefresh(false);
}

void FQuestObjectivesEditor::OnRefreshQuestName()
{
	OnRefreshQuest(false);
}

void FQuestObjectivesEditor::OnRefreshPropertyEditor(UObject* InObj)
{
	TArray< TWeakObjectPtr<UObject> > SelectedObjs = PropertyEditor->GetSelectedObjects();
	for (TWeakObjectPtr SelectedObj : SelectedObjs)
	{
		if (InObj == SelectedObj.Get())
		{
			PropertyEditor->ForceRefresh();
			break;
		}
	}
}

void FQuestObjectivesEditor::OnRefreshTargetStateIdx(UEdGraph* EDGraph)
{
	if (EDGraph == nullptr)
		return;

	for (TObjectPtr<class UEdGraphNode>& QuestNode : EDGraph->Nodes)
	{
		if (!QuestNode)
			continue;
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
		{
			if (QNode->NodeType == EDNodeType::QuestProgress)
			{
				TArray<UEDGraphNode_Base*> OutChildNodes;
				FQuestExportLua::GetChildNodes(QNode, EDNodeType::QuestTarget, OutChildNodes);
				for (UEDGraphNode_Base* ChildNode : OutChildNodes)
				{
					if (UEDGraphNode_StateNode* ChildTargetStateNode = Cast<UEDGraphNode_StateNode>(ChildNode))
					{
						if (UQuestTargetBase* QuestTargetData = Cast<UQuestTargetBase>(ChildNode->NodeInstance))
						{
							ChildTargetStateNode->SetStateIdx(FString::Printf(TEXT("%lld"), QuestTargetData->UniqueID));
						}
					}
				}
				break;
			}
		}
	}
}

void FQuestObjectivesEditor::OnRefreshActionStateIdx(UEdGraph* EDGraph)
{
	if (EDGraph == nullptr)
		return;
	
	int StartIdx = 0;
	// 先给Begin排序
	for (TObjectPtr<class UEdGraphNode>& QuestNode : EDGraph->Nodes)
	{
		if (!QuestNode)
			continue;
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
		{
			if (QNode->NodeType == EDNodeType::QuestBegin)
			{
				TArray<UEDGraphNode_Base*> OutChildNodes;
				FQuestExportLua::GetChildNodes(QNode, EDNodeType::QuestAction, OutChildNodes);
				int idx = StartIdx;
				for (UEDGraphNode_Base* ChildNode : OutChildNodes)
				{
					idx++;
					if (UEDGraphNode_StateNode* ChildStateNode = Cast<UEDGraphNode_StateNode>(ChildNode))
					{
						ChildStateNode->SetStateIdx(FString::FromInt(idx));
					}
				}
				StartIdx = idx;
				break;
			}
		}
	}
	// 再给Target排序
	for (TObjectPtr<class UEdGraphNode>& QuestNode : EDGraph->Nodes)
	{
		if (!QuestNode)
			continue;
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
		{
			if (QNode->NodeType == EDNodeType::QuestProgress)
			{
				TArray<UEDGraphNode_Base*> OutChildNodes;
				FQuestExportLua::GetChildNodes(QNode, EDNodeType::QuestTarget, OutChildNodes);
				int idx = StartIdx;
				for (UEDGraphNode_Base* ChildNode : OutChildNodes)
				{
					TArray<UEDGraphNode_Base*> OutChildNodesReal;
					FQuestExportLua::GetChildNodes(ChildNode, EDNodeType::QuestAction, OutChildNodesReal);
					for (UEDGraphNode_Base* ChildNodeReal : OutChildNodesReal)
					{
						idx++;
						if (UEDGraphNode_StateNode* ChildStateNode = Cast<UEDGraphNode_StateNode>(ChildNodeReal))
						{
							ChildStateNode->SetStateIdx(FString::FromInt(idx));
						}	
					}
				}
				StartIdx = idx;
				break;
			}
		}
	}
	// 再给End排序
	for (TObjectPtr<class UEdGraphNode>& QuestNode : EDGraph->Nodes)
	{
		if (!QuestNode)
			continue;
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
		{
			if (QNode->NodeType == EDNodeType::QuestEnd)
			{
				TArray<UEDGraphNode_Base*> OutChildNodes;
				FQuestExportLua::GetChildNodes(QNode, TEXT("Out"), EDNodeType::QuestAction, OutChildNodes);
				int idx = StartIdx;
				for (UEDGraphNode_Base* ChildNode : OutChildNodes)
				{
					idx++;
					if (UEDGraphNode_StateNode* ChildStateNode = Cast<UEDGraphNode_StateNode>(ChildNode))
					{
						ChildStateNode->SetStateIdx(FString::FromInt(idx));
					}
				}

				OutChildNodes.Empty();
				FQuestExportLua::GetChildNodes(QNode, TEXT("Out2"), EDNodeType::QuestAction, OutChildNodes);
				for (UEDGraphNode_Base* ChildNode : OutChildNodes)
				{
					idx++;
					if (UEDGraphNode_StateNode* ChildStateNode = Cast<UEDGraphNode_StateNode>(ChildNode))
					{
						ChildStateNode->SetStateIdx(FString::FromInt(idx));
					}
				}
				break;
			}
		}
	}
	// 最后遍历普通的Action
	for (TObjectPtr<class UEdGraphNode>& QuestNode : EDGraph->Nodes)
	{
		if (!QuestNode)
			continue;
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
		{
			if (QNode->NodeType == EDNodeType::QuestAction)
			{
				TArray<UEDGraphNode_Base*> OutChildNodes;
				FQuestExportLua::GetChildNodes(QNode, EDNodeType::QuestAction, OutChildNodes);
				int idx = 0;
				for (UEDGraphNode_Base* ChildNode : OutChildNodes)
				{
					idx++;
					if (UEDGraphNode_StateNode* ChildStateNode = Cast<UEDGraphNode_StateNode>(ChildNode))
					{
						if (UEDGraphNode_StateNode* ParentStateNode = Cast<UEDGraphNode_StateNode>(QNode))
						{
							FString ParentIdx = ParentStateNode->GetStateIdx();
							if (ParentIdx != TEXT("-1"))
								ChildStateNode->SetStateIdx(ParentIdx + TEXT("-") + FString::FromInt(idx));
							else
								ChildStateNode->SetStateIdx(FString::FromInt(idx));
						}
						else
						{
							ChildStateNode->SetStateIdx(FString::FromInt(idx));
						}
					}
				}
			}
		}
	}
}

void FQuestObjectivesEditor::RebuildLists(bool bKeepSelection)
{
	RebuildQuestObjectList(bKeepSelection);
	
	RebuildChapterList(bKeepSelection);

	RebuildRingList(bKeepSelection);

	RebuildQuestList(bKeepSelection);
}

void FQuestObjectivesEditor::RebuildRootItems()
{
	DataEntity->QuestObjectRootItems.Reset();
	for(int i = 0; i < DataEntity->QuestTypes.Num(); i++)
	{
		UEnum* E = StaticEnum<EQuestType>();
		bool bIsDeprecated = E->HasMetaData(TEXT("Deprecated"), i);
		if (bIsDeprecated)
		{
			continue;
		}
		UQuestObject* QO = NewObject<UQuestObject>(DataEntity);
		QO->QuestType = static_cast<EQuestType>(i);
		QO->QuestObjectName = E->GetDisplayNameTextByValue(i).ToString();
		QO->QuestObjectID = -i - 1;
		QO->QuestObjectType = Root;
		DataEntity->AllQuestObject.Add(QO);
		DataEntity->QuestTypes[i] = QO;
		DataEntity->QuestObjectRootItems.Add(QO);
	}

	// 原著任务要放在第二个位置
	int32 TargetIndex = DataEntity->QuestObjectRootItems.IndexOfByPredicate([](TObjectPtr<UQuestObject> Item) {
		return Item && Item->QuestObjectName == TEXT("原著任务");
	});
	if (TargetIndex != INDEX_NONE && TargetIndex != 1)
	{
		// 保存要移动的对象
		TObjectPtr<UQuestObject> ItemToMove = DataEntity->QuestObjectRootItems[TargetIndex];

		// 从原位置移除
		DataEntity->QuestObjectRootItems.RemoveAt(TargetIndex);

		// 插入到第二位（索引1）
		if (DataEntity->QuestObjectRootItems.Num() > 0)
		{
			DataEntity->QuestObjectRootItems.Insert(ItemToMove, 1);
		}
		else
		{
			DataEntity->QuestObjectRootItems.Add(ItemToMove);
		}
	}
}

FString FQuestObjectivesEditor::GetQuestTypeDisplayName(EQuestType InType)
{
	UEnum* E = StaticEnum<EQuestType>();
	check(E);
	FString DisplayString = E->GetDisplayNameTextByValue((int)InType).ToString();
	return DisplayString;
}

UQuestChapter* FQuestObjectivesEditor::GetSelectedChapter()
{
	if(bFocusingTreeView)
	{
		TArray<TObjectPtr<UQuestObject>> Selections = QuestObjectTreeView->GetSelectedItems();
		if (Selections.Num() == 0)
		{
			return nullptr;
		}

		if (!IsValid(Selections[0]))
		{
			return nullptr;
		}
		auto RetVal = Cast<UQuestChapter>(Selections[0].Get());
		return RetVal;
	}else
	{
		TArray<TObjectPtr<UQuestChapter>> Selections = ChapterListView->GetSelectedItems();
		if (Selections.Num() == 0)
		{
			return nullptr;
		}

		if (!IsValid(Selections[0]))
		{
			return nullptr;
		}

		return Selections[0].Get();
	}
}

UQuestRing* FQuestObjectivesEditor::GetSelectedRing()
{
	TArray<TObjectPtr<UQuestRing>> Selections = RingListView->GetSelectedItems();
	if (Selections.Num() == 0)
	{
		return nullptr;
	}
	
	if (!IsValid(Selections[0]))
	{
		return nullptr;
	}

	return Selections[0].Get();

}

UQuest* FQuestObjectivesEditor::GetSelectedQuest() const
{
	TArray<TObjectPtr<UQuest>> Selections = QuestListView->GetSelectedItems();
	if (Selections.Num() == 0)
	{
		return nullptr;
	}

	if (!IsValid(Selections[0]))
	{
		return nullptr;
	}
	
	return Selections[0].Get();
}

void FQuestObjectivesEditor::RebuildQuestObjectList(bool bKeepSelection)
{
	if(bKeepSelection)
	{
		TArray<TObjectPtr<UQuestObject>> Selections = QuestObjectTreeView->GetSelectedItems();
		QuestObjectTreeRefresh(bKeepSelection);
		if(Selections.Num() > 0)
		{
			QuestObjectTreeView->SetSelection(Selections[0]);
		}
		return;
	}
	
	RebuildRootItems();
	
	for(auto Chapter : DataEntity->AllChapters)
	{
		RebuildQuestObjectRelations(Chapter);
	}
	RecoverQuestObjectFilteredItems();
	QuestObjectTreeView->RebuildList();
}

void FQuestObjectivesEditor::RebuildChapterList(bool bKeepSelection, bool bFilter/* = true*/)
{
	TArray<TObjectPtr<UQuestChapter>> Selections = ChapterListView->GetSelectedItems();

	DataEntity->ChapterListItems.Reset();

	for (size_t i = 0; i < DataEntity->AllChapters.Num(); i++)
	{
		TObjectPtr<UQuestChapter> ci = DataEntity->AllChapters[i];
		if (IsValid(ci) && (!bFilter || (bFilter && Actives[(int)ci->QuestType])))
		{
			DataEntity->ChapterListItems.Add(ci);
		}

	}

	DataEntity->ChapterListItems.Sort([](const TObjectPtr<UQuestChapter>& A, const TObjectPtr<UQuestChapter>& B) { return A->ChapterID < B->ChapterID; });

	ChapterListView->RebuildList();
	QuestObjectTreeView->RebuildList();
}

void FQuestObjectivesEditor::RebuildRingList(bool bKeepSelection)
{
	DataEntity->RingListItems.Reset();

	TArray<TObjectPtr<UQuestChapter>> Selections = ChapterListView->GetSelectedItems();
	TArray<TObjectPtr<UQuestObject>> QOSelections = QuestObjectTreeView->GetSelectedItems();
	
	if (Selections.Num() == 0 && QOSelections.Num() == 0)
	{

	}
	else
	{
		TWeakObjectPtr<UQuestObject> Selection;
		if (bFocusingTreeView)
		{
			if(QOSelections.Num() == 0)
			{
				return;
			}
			TObjectPtr<UQuestObject> QOSelectedItem = QOSelections[0];
			Selection = QOSelectedItem;
		}else
		{
			if(Selections.Num() == 0)
			{
				return;
			}
			TObjectPtr<UQuestChapter> SelectedItem = Selections[0];
			Selection = SelectedItem;
		}
		
		if (Selection.IsValid())
		{
			for(auto Child : Selection->Children)
			{
				if(!Child.Get())
				{
					continue;
				}
				if (DataEntity->RingMap.Contains(Child->QuestObjectID))
				{
					auto Item = DataEntity->RingMap[Child->QuestObjectID];
					if(IsValid(Item))
					{
						DataEntity->RingListItems.Add(Item);
					}
				}
			}
		}
	}

	DataEntity->RingListItems.Sort([](const TObjectPtr<UQuestRing>& A, const TObjectPtr<UQuestRing>& B) { return A->RingID < B->RingID;});

	RingListView->RebuildList();

}
void FQuestObjectivesEditor::RebuildQuestList(bool bKeepSelection)
{
	DataEntity->QuestListItems.Reset();

	TArray<TObjectPtr<UQuestRing>> Selections = RingListView->GetSelectedItems();

	if (Selections.Num() == 0)
	{

	}
	else
	{
		TObjectPtr<UQuestRing> SelectedItem = Selections[0];

		if (IsValid(SelectedItem))
		{
			for(auto Child : SelectedItem->Children)
			{
				if(!Child.Get())
				{
					continue;
				}
				if (DataEntity->QuestMap.Contains(Child->QuestObjectID))
				{
					auto Item = DataEntity->QuestMap[Child->QuestObjectID];
					if(IsValid(Item))
					{
						DataEntity->QuestListItems.Add(Item);
					}
				}
			}
		}
	}

	DataEntity->QuestListItems.Sort([](const TObjectPtr<UQuest>& A, const TObjectPtr<UQuest>& B) { return A->QuestID < B->QuestID; });

	QuestListView->RebuildList();

}

FReply FQuestObjectivesEditor::OnCreateRing()
{
	const FScopedTransaction Transaction(LOCTEXT("CreateRingTransaction", "Create Ring"));
	DataEntity->Modify();
	CreateRing();
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnOpenIDDocumentClicked()
{
	FPlatformProcess::LaunchURL(*FString("https://docs.corp.kuaishou.com/s/home/fcAAHGPtdBuizoT8nS2RUcCrh"), nullptr, nullptr);
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OnDeleteSelectQuest()
{
	if (FMessageDialog::Open(EAppMsgType::OkCancel, FText::FromString(FString::Printf(TEXT("确认是否删除任务!"))), FText::FromString(FString::Printf(TEXT("删除任务二次确认")))) == EAppReturnType::Ok)
	{
		if (DeleteQuest(GetSelectedQuest()))
		{
			OnRefreshQuest(false);
		}
	}
	
	return FReply::Handled();
}

void FQuestObjectivesEditor::OnChapterSearchTextChanged(const FText& InSearchText)
{
	QuestObjectSearchText = InSearchText.ToString();
	FilterQuestObject();
}

void FQuestObjectivesEditor::OnSearchTextCommitted(const FText& InSearchText, ETextCommit::Type InCommitType)
{
	if(InCommitType != ETextCommit::Type::OnEnter)
	{
		return;
	}
	int32 SearchID = 0;
	FDefaultValueHelper::ParseInt(InSearchText.ToString(), SearchID);
	if(!DataEntity->QuestObjectMap.Contains(SearchID))
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("There is no QuestObject whose ID is %i"), SearchID);
	}else
	{
		auto QuestObject = DataEntity->QuestObjectMap[SearchID];
		auto ChapterObject = Cast<UQuestChapter>(QuestObject);
		auto RingObject = Cast<UQuestRing>(QuestObject);
		auto Quest = Cast<UQuest>(QuestObject);
		if(Quest)
		{
			auto FatherRing = Quest->Father;
			if (!FatherRing)
			{
				return;
			}
			auto FatherChapter = FatherRing->Father;
			if (!FatherChapter)
			{
				return;
			}
			if (!DataEntity->QuestMap.Contains(SearchID))
			{
				UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("There is no Quest whose ID is %i"), SearchID);
				return;
			}
			auto QuestItem = DataEntity->QuestMap[SearchID];
			if (!DataEntity->RingMap.Contains(FatherRing->QuestObjectID))
			{
				UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("There is no Ring whose ID is %i"), FatherRing->QuestObjectID);
				return;
			}
			auto RingItem = DataEntity->RingMap[FatherRing->QuestObjectID];
			if (!DataEntity->ChapterMap.Contains(FatherChapter->QuestObjectID))
			{
				UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("There is no Chapter whose ID is %i"), FatherChapter->QuestObjectID);
				return;;
			}
			auto ChapterItem = DataEntity->ChapterMap[FatherChapter->QuestObjectID];
			for(auto Root : QuestObjectTreeView->GetRootItems())
			{
				if(Root->Children.Contains(ChapterItem))
				{
					QuestObjectTreeView->SetItemExpansion(Root, true);
					break;
				}
			}
			QuestObjectTreeView->SetSelection(ChapterItem);
			OnQuestTypeFilterChanged(ChapterItem->QuestType, true);
			ChapterListView->SetSelection(ChapterItem);

			if (ChapterGraph.IsValid())
			{
				for(auto Node : ChapterGraph->Nodes)
				{
					if(auto NodeBase = Cast<UEDGraphNode_Base>(Node.Get()))
					{
						if(NodeBase->NodeInstance == RingItem)
						{
							ChapterGraph->GraphEditor.Pin()->GetGraphPanel()->SelectionManager.SelectSingleNode(Node);
							ChapterGraph->GraphEditor.Pin()->ZoomToFit(true);
							break;
						}
					}
				}
			}
			else
			{
				UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("ChapterGraph is empty!"))
			}

			if (RingGraph.IsValid())
			{
				for(auto Node : RingGraph->Nodes)
				{
					if(auto NodeBase = Cast<UEDGraphNode_Base>(Node.Get()))
					{
						if(NodeBase->NodeInstance == QuestItem)
						{
							RingGraph->GraphEditor.Pin()->GetGraphPanel()->SelectionManager.SelectSingleNode(Node);
							RingGraph->GraphEditor.Pin()->ZoomToFit(true);
							break;
						}
					}
				}
			}
			else
			{
				UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("RingGraph is empty!"))
			}
			
			
		}else if(RingObject)
		{
			auto FatherChapter = RingObject->Father;
			if (!FatherChapter)
			{
				return;
			}
			if (!DataEntity->RingMap.Contains(SearchID))
			{
				UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("There is no Ring whose ID is %i"), SearchID);
				return;
			}
			auto RingItem = DataEntity->RingMap[SearchID];
			if (!DataEntity->ChapterMap.Contains(FatherChapter->QuestObjectID))
			{
				UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("There is no Chapter whose ID is %i"), FatherChapter->QuestObjectID);
				return;
			}
			auto ChapterItem = DataEntity->ChapterMap[FatherChapter->QuestObjectID];
			for(auto Root : QuestObjectTreeView->GetRootItems())
			{
				if(Root->Children.Contains(ChapterItem))
				{
					QuestObjectTreeView->SetItemExpansion(Root, true);
					break;
				}
			}
			QuestObjectTreeView->SetSelection(ChapterItem);
			OnQuestTypeFilterChanged(ChapterItem->QuestType, true);
			ChapterListView->SetSelection(ChapterItem);
			for(auto Node : ChapterGraph->Nodes)
			{
				if(auto NodeBase = Cast<UEDGraphNode_Base>(Node.Get()))
				{
					if(NodeBase->NodeInstance == RingItem)
					{
						ChapterGraph->GraphEditor.Pin()->GetGraphPanel()->SelectionManager.SelectSingleNode(Node);
						ChapterGraph->GraphEditor.Pin()->ZoomToFit(true);
						break;
					}
				}
			}
			
		}else if(ChapterObject)
		{
			if (!DataEntity->ChapterMap.Contains(SearchID))
			{
				UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("There is no Chapter whose ID is %i"), SearchID);
				return;
			}
			auto ChapterItem = DataEntity->ChapterMap[SearchID];
			for(auto Root : QuestObjectTreeView->GetRootItems())
			{
				if(Root->Children.Contains(ChapterObject))
				{
					QuestObjectTreeView->SetItemExpansion(Root, true);
					break;
				}
			}
			QuestObjectTreeView->SetSelection(ChapterItem);
			OnQuestTypeFilterChanged(ChapterItem->QuestType, true);
			ChapterListView->SetSelection(ChapterItem);
		}
	}
}

void FQuestObjectivesEditor::ExportRingArray(const TArray<TObjectPtr<UQuestRing>>& Input, TArray<FString>& OutPut)
{
	TArray<FString> RingTitles;
	FString DisplayRingTitle;
	for (FProperty* Property : TFieldRange<FProperty>(UQuestRing::StaticClass(), EFieldIteratorFlags::ExcludeSuper))
	{
		FString CategoryName;
		const FString* CategoryNamePtr = Property->GetMetaDataMap()->Find("Category");
		if(CategoryNamePtr)
		{
			CategoryName = *CategoryNamePtr;
		}
		if (CategoryName == "Edit")
		{
			continue;
		}
		FString EnumDetail;
		if(auto EnumProperty = CastField<FEnumProperty>(Property))
		{
			UEnum* EnumPtr = EnumProperty->GetEnum();
			for(int i = 0; i<EnumPtr->NumEnums() - 1; i++)
			{
				FString DisplayName = EnumPtr->GetDisplayNameTextByIndex(i).ToString();
				EnumDetail += FString::Printf(TEXT("%d:%s;"),i , *DisplayName);
			}
		}
		DisplayRingTitle += Property->GetDisplayNameText().ToString() + " " + EnumDetail + ",";
		RingTitles.Add(Property->GetName());
	}
	FString RingCSVTitle = "";
	for(auto RingTitle : RingTitles)
	{
		RingCSVTitle += RingTitle + ",";
	}
	RingCSVTitle.RemoveFromEnd(",");
	OutPut.Add(RingCSVTitle);
	OutPut.Add(DisplayRingTitle);
	for (auto Ring : Input)
	{
		UQuestRing* RingData = Ring.Get();
		if (!RingData)
			continue;

		// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
		if (RingData->RingGraph == nullptr)
			PreRefreshRingGraph(RingData);
			
		FString ExportCSVString = FQuestExportLua::ExportRingCSV(RingData, RingTitles);
		OutPut.Add(ExportCSVString);
	}
}

void FQuestObjectivesEditor::ExportQuestArray(const TArray<TObjectPtr<UQuest>>& Input, TArray<FString>& OutPut)
{
	TArray<FString> QuestTitles;
	FString DisplayQuestTitle;
	for (FProperty* Property : TFieldRange<FProperty>(UQuest::StaticClass(), EFieldIteratorFlags::ExcludeSuper))
	{
		FString CategoryName;
		const FString* CategoryNamePtr = Property->GetMetaDataMap()->Find("Category");
		if(CategoryNamePtr)
		{
			CategoryName = *CategoryNamePtr;
		}
		if (CategoryName == "Edit")
		{
			continue;
		}
		FString EnumDetail;
		if(auto EnumProperty = CastField<FEnumProperty>(Property))
		{
			UEnum* EnumPtr = EnumProperty->GetEnum();
			for(int i = 0; i<EnumPtr->NumEnums() - 1; i++)
			{
				FString DisplayName = EnumPtr->GetDisplayNameTextByIndex(i).ToString();
				EnumDetail += FString::Printf(TEXT("%d:%s;"),i , *DisplayName);
			}
		}
		DisplayQuestTitle += Property->GetDisplayNameText().ToString() + " " + EnumDetail + ",";
		QuestTitles.Add(Property->GetName());
	}
	FString QuestCSVTitle = "";
	for(auto RingTitle : QuestTitles)
	{
		QuestCSVTitle += RingTitle + ",";
	}
	QuestCSVTitle.RemoveFromEnd(",");
	OutPut.Add(QuestCSVTitle);
	OutPut.Add(DisplayQuestTitle);
	for (auto Quest : Input)
	{
		// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
		if (Quest->QuestGraph == nullptr)
			PreRefreshQuestGraph(Quest);
			
		FString ExportLuaString = FQuestExportLua::ExportQuestCSV(Quest, QuestTitles);
		OutPut.Add(ExportLuaString);
	}
}

// Copy from EditorUtilities
void CopySinglePropertyRecursive(const void* const InSourcePtr, void* const InTargetPtr, UObject* const InTargetObject, FProperty* const InProperty)
{
	// Properties that are *object* properties are tricky
	// Sometimes the object will be a reference to a PIE-world object, and copying that reference back to an actor CDO asset is not a good idea
	// If the property is referencing an actor or actor component in the PIE world, then we can try and fix that reference up to the equivalent
	// from the editor world; otherwise we have to skip it
	bool bNeedsGenericCopy = true;
	if (FObjectPropertyBase* const ObjectProperty = CastField<FObjectPropertyBase>(InProperty))
	{
		bNeedsGenericCopy = false;
	}
	else if (FStructProperty* const StructProperty = CastField<FStructProperty>(InProperty))
	{
		// Ensure that the target struct is initialized before copying fields from the source.
		StructProperty->InitializeValue_InContainer(InTargetPtr);

		const int32 PropertyArrayDim = InProperty->ArrayDim;
		for (int32 ArrayIndex = 0; ArrayIndex < PropertyArrayDim; ArrayIndex++)
		{
			const void* const SourcePtr = StructProperty->ContainerPtrToValuePtr<void>(InSourcePtr, ArrayIndex);
			void* const TargetPtr = StructProperty->ContainerPtrToValuePtr<void>(InTargetPtr, ArrayIndex);

			for (TFieldIterator<FProperty> It(StructProperty->Struct); It; ++It)
			{
				FProperty* const InnerProperty = *It;
				CopySinglePropertyRecursive(SourcePtr, TargetPtr, InTargetObject, InnerProperty);
			}
		}

		bNeedsGenericCopy = false;
	}
	else if (FArrayProperty* const ArrayProperty = CastField<FArrayProperty>(InProperty))
	{
		check(InProperty->ArrayDim == 1);
		FScriptArrayHelper SourceArrayHelper(ArrayProperty, ArrayProperty->ContainerPtrToValuePtr<void>(InSourcePtr));
		FScriptArrayHelper TargetArrayHelper(ArrayProperty, ArrayProperty->ContainerPtrToValuePtr<void>(InTargetPtr));

		FProperty* InnerProperty = ArrayProperty->Inner;
		int32 Num = SourceArrayHelper.Num();

		// here we emulate UArrayProperty::CopyValuesInternal()
		if (!(InnerProperty->PropertyFlags & CPF_IsPlainOldData))
		{
			TargetArrayHelper.EmptyAndAddValues(Num);
		}
		else
		{
			TargetArrayHelper.EmptyAndAddUninitializedValues(Num);
		}

		for (int32 Index = 0; Index < Num; Index++)
		{
			CopySinglePropertyRecursive(SourceArrayHelper.GetRawPtr(Index), TargetArrayHelper.GetRawPtr(Index), InTargetObject, InnerProperty);
		}

		bNeedsGenericCopy = false;
	}

	// Handle copying properties that either aren't an object, or aren't part of the PIE world
	if (bNeedsGenericCopy)
	{
		InProperty->CopyCompleteValue_InContainer(InTargetPtr, InSourcePtr);
	}
}

void CopySingleProperty(const UObject* const InSourceObject, UObject* const InTargetObject, FProperty* const InProperty)
{
	CopySinglePropertyRecursive(InSourceObject, InTargetObject, InTargetObject, InProperty);
}

UQuestRing* FQuestObjectivesEditor::CreateRing(UEdGraphPin* FromPin)
{
	UQuestChapter* ParentObj = GetSelectedChapter();
	if (ParentObj == nullptr)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("must select a Chapter first"))));
		return nullptr;
	}
	UPreQuestRing* PreObj = NewObject<UPreQuestRing>();
	UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass());
	UClass* QuestRingClass(UQuestRing::StaticClass());
	if (QuestSettings)
	{
		if (UClass* Class = GetBPClass(QuestSettings->RingDataBP))
		{
			QuestRingClass = Class;
		}
	}
		
	UQuestRing* Obj = NewObject<UQuestRing>(DataEntity, QuestRingClass);
	
	PreObj->ChapterID = ParentObj->ChapterID;
	PreObj->QuestType = ParentObj->QuestType;

	Obj->QuestType = PreObj->QuestType;
	PreObj->RingID = GetAvailableID(Obj);

	TArray<UObject*> ViewObjects = { PreObj };

	TSharedRef<SWindow> Window = SNew(SWindow)
		.Title(FText::FromString(TEXT("Create Ring")))
		.SizingRule(ESizingRule::Autosized)
		.AutoCenter(EAutoCenter::PrimaryWorkArea)
		.SupportsMinimize(false)
		.SupportsMaximize(false);

	TSharedPtr<SObjParamDialog> Dialog;
	bool bShowDialogue = true;
	if(QuestSettings)
	{
		bShowDialogue = QuestSettings->bCreateRingDialogue;
	}
	if(bShowDialogue)
	{
		Window->SetContent(SAssignNew(Dialog, SObjParamDialog, Window, ViewObjects));
		GEditor->EditorAddModalWindow(Window);
	}

	if (!bShowDialogue || Dialog->WasOkPressed())
	{

		Obj->ChapterID = PreObj->ChapterID;
		Obj->RingID = PreObj->RingID;
		Obj->QuestType = PreObj->QuestType;
        Obj->Type = PreObj->Type;
        Obj->RingName = PreObj->RingName;
        Obj->RingDescription = PreObj->RingDescription;
        Obj->RingExplain = PreObj->RingExplain;
        Obj->RelatedPlanes = PreObj->RelatedPlanes;
        Obj->Version = PreObj->Version;
		Obj->SetMiniType(ParentObj->QuestType);

		MarkAssetForDirty(Obj);
		
		AddRingObj(Obj);

		RebuildRingList(true);

		RingListView->SetSelection(Obj);

		OnRingListSelectionChanged(Obj, ESelectInfo::Type::Direct);
		
		//if (UEDGraphBase* RingGraphBase = Cast<UEDGraphBase>(Obj->RingGraph))
		//{
		//	RingGraphBase->Modify();
		//	const UEdGraphSchema* Schema = RingGraphBase->GetSchema();
		//	if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
		//	{
		//		FVector2D NewPlacePos = FVector2D(0, 0);
		//		ThisSchema->CreateQuestNode(RingGraphBase, CreateQuest(), NewPlacePos, true);
		//	}
		//}
		
		RingListView->SetSelection(Obj);
		
		return Obj;
	}
	return nullptr;
}

UChapterEnd* FQuestObjectivesEditor::CreateChapterEnd(UEdGraphPin* FromPin)
{
	UQuestChapter* ParentObj = GetSelectedChapter();
	UPreChapterEnd* PreVal = NewObject<UPreChapterEnd>();

	TSharedRef<SWindow> Window = SNew(SWindow)
	.Title(FText::FromString(TEXT("Create Chapter End")))
	.SizingRule(ESizingRule::Autosized)
	.AutoCenter(EAutoCenter::PrimaryWorkArea)
	.SupportsMinimize(false)
	.SupportsMaximize(false);

	TArray<UObject*> ViewObjects = { PreVal };
	
	TSharedPtr<SObjParamDialog> Dialog;
	Window->SetContent(SAssignNew(Dialog, SObjParamDialog, Window, ViewObjects));
	GEditor->EditorAddModalWindow(Window);

	if (Dialog->WasOkPressed())
	{
		if(!ParentObj)
		{
			FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Create End Error! Select one chapter before creating"))));
			return nullptr;
		}
		if(!DataEntity->RingMap.Contains(PreVal->NextRingID))
		{
			FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Create End Error! ID[%d] doesn't exist, use another ID"), PreVal->NextRingID)));
			return nullptr;
		}
		UChapterEnd* RetVal = NewObject<UChapterEnd>(DataEntity);
		RetVal->QuestObjectivesEditor = this->AsWeak();
		RetVal->NextRingID = PreVal->NextRingID;
		RetVal->Desc = PreVal->Desc;
		DataEntity->ChapterEnds.Add(RetVal);
		ParentObj->ChapterEnds.Add(RetVal);
		RetVal->Father = ParentObj;
		return RetVal;
	}
	return nullptr;
}

UQuest* FQuestObjectivesEditor::CreateQuest(UEdGraphPin* FromPin)
{
	UQuestRing* ParentObj = GetSelectedRing();
	if (ParentObj == nullptr)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("must select a Ring first"))));
		return nullptr;
	}
	
	UQuestChapter* ParentChapterObj(nullptr);

	for (size_t i = 0; i < DataEntity->AllChapters.Num(); i++)
	{
		UQuestChapter* Chapter = DataEntity->AllChapters[i].Get();
		if (Chapter && ParentObj->ChapterID == Chapter->ChapterID)
		{
			ParentChapterObj = Chapter;
			break;
		}
	}

	if (!ParentChapterObj)
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("must select a Chapter first"))));
		return nullptr;
	}
	UClass* QuestClass(UQuest::StaticClass());
	UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass());
	if (QuestSettings)
	{
		if (UClass* Class = GetBPClass(QuestSettings->QuestDataBP))
		{
			QuestClass = Class;
		}
	}
	UQuest* Obj = NewObject<UQuest>(DataEntity, QuestClass);
	UPreQuest* PreObj = NewObject<UPreQuest>();
	PreObj->ChapterID = ParentObj->ChapterID;
	PreObj->RingID = ParentObj->RingID;
	Obj->ChapterID = PreObj->ChapterID;
	Obj->RingID = PreObj->RingID;
	PreObj->QuestID = GetAvailableID(Obj);

	UCreateQuestEdit* QuestEditSetting = NewObject<UCreateQuestEdit>();
	QuestEditSetting->PreQuest = TWeakObjectPtr<class UPreQuest>(PreObj);

	TArray<UObject*> ViewObjects = { PreObj, QuestEditSetting };
	
	bool bShowDialogue = true;
	bool bForbidExportQuestFile = true;
	if(QuestSettings)
	{
		bShowDialogue = QuestSettings->bCreateQuestDialogue;
		bForbidExportQuestFile = QuestSettings->bForbidExportQuestFile;
	}
	
	TSharedRef<SWindow> Window = SNew(SWindow)
		.Title(FText::FromString(TEXT("Create Quest")))
		.SizingRule(ESizingRule::Autosized)
		.AutoCenter(EAutoCenter::PrimaryWorkArea)
		.SupportsMinimize(false)
		.SupportsMaximize(false);

	TSharedPtr<SObjParamDialog> Dialog;
	if(bShowDialogue)
	{
		Window->SetContent(SAssignNew(Dialog, SObjParamDialog, Window, ViewObjects, true));
		GEditor->EditorAddModalWindow(Window);
	}

	if (!bShowDialogue || (Dialog->WasOkPressed() || Dialog->WasNextCreate()))
	{
		if (!bForbidExportQuestFile)
		{
			FString FilePath = FPaths::ProjectContentDir();
			FilePath = FilePath + FString("Script/Data/Config/Quest/Quest");
			FString FileName = FString::Printf(TEXT("%d"), PreObj->QuestID);
			FilePath += FString::Printf(TEXT("/%s.lua"), *FileName);
			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(FilePath);

			if (SourceControlHelpers::QueryFileState(AbsolutePath).bIsCheckedOutOther)
			{
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Printf(TEXT("Create Quest Error! ID[%d] already checkout by others, use new ID or check P4"), PreObj->QuestID)));
				return nullptr;
			}
		}
		
		Obj->ChapterID = PreObj->ChapterID;
		Obj->RingID = PreObj->RingID;
		Obj->QuestID = PreObj->QuestID;
		Obj->QuestName = PreObj->QuestName;

		MarkAssetForDirty(Obj);
		
		AddQuestObj(Obj);

		RebuildQuestList(true);

		// 处理额外的QuestEditSetting
		if (QuestEditSetting->PreSelectTargets.Num() > 0)
		{
			CreateQuestGraph(Obj); // 预创建Targets, 提前写入QuestGraph

			// 新建Target并提前创建, 这里不能直接传入PreSelectTargets, 因为Outer是QuestEditSetting, 会析构掉
			TArray<UQuestTargetBase*> NewTargetList;
			for (UQuestTargetBase* PreCreateTarget : QuestEditSetting->PreSelectTargets)
			{
				int32 ProcessedType = FQuestImportLua::ProcessTargetType(PreCreateTarget);
				UQuestTargetBase* LoadedTarget = Cast<UQuestTargetBase>(FQuestImportLua::GetTargetInstanceFromEvent(ProcessedType, Obj));
				NewTargetList.Add(LoadedTarget);
			}
			
			Obj->CreateTargetsManually(NewTargetList);
		}

		if (QuestEditSetting->bCopyLastQuestData && FromPin != nullptr)
		{
			// 找到上一个Node
			if (UEDGraphNode_Base* TargetNode = Cast<UEDGraphNode_Base>(FromPin->GetOwningNodeUnchecked()))
			{
				if (UQuest* TargetQuestData = Cast<UQuest>(TargetNode->NodeInstance))
				{
					const FName CategoryKey = TEXT("Category");
					for (FProperty* Property : TFieldRange<FProperty>(Obj->GetClass(), EFieldIteratorFlags::ExcludeSuper))
					{
						if (!Property->GetMetaDataMap())
							continue;
						const FString* CategoryName = Property->GetMetaDataMap()->Find(CategoryKey);
						if (CategoryName && CategoryName->Equals(TEXT("位面")))
						{
							CopySingleProperty(TargetQuestData, Obj, Property);
						}
					}
				}
			}
		}

		if (Dialog && Dialog->WasNextCreate() && GEditor != nullptr)
		{
			GEditor->GetTimerManager()->SetTimerForNextTick([this, PreObj]()
				{
					if (RingGraph.IsValid())
					{
						// 找到最新的那个Node
						UEDGraphNode_Base* TargetNode = nullptr;
						for (TObjectPtr<class UEdGraphNode>& QuestNode : RingGraph->Nodes)
						{
							if (!QuestNode)
								continue;
							if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
							{
								if (UQuest* QuestData = Cast<UQuest>(QNode->NodeInstance))
								{
									if (QuestData->QuestID == PreObj->QuestID)
									{
										TargetNode = QNode;
									}
								}
							}
						}
						if (TargetNode != nullptr)
						{
							FVector2D NewPlacePos = FVector2D(PlacePos.X, PlacePos.Y + 100);
							UEventDrivenGraphSchema::CreateQuestNode(RingGraph.Get(), TargetNode->GetOutputPin(), NewPlacePos);
						}
					}
				});
		}
		return Obj;
	}
	return nullptr;
}

bool FQuestObjectivesEditor::DeleteQuest(UQuest* InQuestData)
{
	if(!IsValid(InQuestData))
		return false;

	int32 QuestID = InQuestData->QuestID;

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Delete Quest: %d."), QuestID);

	UQuestRing* QuestRing = Cast<UQuestRing>(InQuestData->Father);

	if (!MarkAssetForDirty(QuestRing))
	{
		return false;
	}
	
	if(!QuestRing || !IsValid(QuestRing->RingGraph))
		return false;

	TArray<UEDGraphNode_Base*> DeleteNodes;
	
	for (TObjectPtr<class UEdGraphNode>& QuestNode : QuestRing->RingGraph->Nodes)
	{
		if (!QuestNode)
			continue;
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
		{
			if (QNode->NodeInstance == InQuestData)
			{
				QNode->GetOutputTransitionNodes(DeleteNodes, UEDGraphNode_Transition::StaticClass());
				QNode->GetInputTransitionNodes(DeleteNodes, UEDGraphNode_Transition::StaticClass());
				DeleteNodes.AddUnique(QNode);
				break;
			}
		}
	}

	if (QuestGraphBox)
	{
		QuestGraphBox.Get()->ClearChildren();
	}

	for (auto& Node : DeleteNodes)
	{
		Node->Modify();
		Node->DestroyNode();
	}

	DeleteQuestObj(InQuestData);

	return true;
}

bool FQuestObjectivesEditor::DeleteRing(UQuestRing* InRingData)
{
	if(!IsValid(InRingData))
		return false;

	PreRefreshRingGraph(InRingData);

	if (!MarkAssetForDirty(InRingData))
	{
		return false;
	}
	
	int RetryTime = 3;
	while(int N = InRingData->Children.Num())
	{
		if(auto Q = Cast<UQuest>(InRingData->Children[0]))
		{
			Q->Modify();
			DeleteQuest(Q);
		}
		if(N == InRingData->Children.Num())
		{
			RetryTime -= 1;
			if(RetryTime == 0)
			{
				return false;
			}
		}
	}
	
	int32 RingID = InRingData->RingID;

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Delete Ring: %d."), RingID);

	UQuestChapter* QuestChapter = Cast<UQuestChapter>(InRingData->Father);

	if(!QuestChapter || !IsValid(QuestChapter->ChapterGraph))
		return false;

	TArray<UEDGraphNode_Base*> DeleteNodes;
		
	for (TObjectPtr<class UEdGraphNode>& RingNode : QuestChapter->ChapterGraph->Nodes)
	{
		if (!RingNode)
			continue;
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(RingNode))
		{
			if (QNode->NodeInstance == InRingData)
			{
				QNode->GetOutputTransitionNodes(DeleteNodes, UEDGraphNode_Transition::StaticClass());
				QNode->GetInputTransitionNodes(DeleteNodes, UEDGraphNode_Transition::StaticClass());
				DeleteNodes.AddUnique(QNode);
				break;
			}
		}
	}

	if (RingGraphBox)
	{
		RingGraphBox.Get()->ClearChildren();
	}

	for (auto& Node : DeleteNodes)
	{
		Node->Modify();
		Node->DestroyNode();
	}

	DeleteRingObj(InRingData);

	return true;
}

bool FQuestObjectivesEditor::DeleteChapter(UQuestChapter* InChapterData)
{
	if(!IsValid(InChapterData))
		return false;

	PreRefreshChapterGraph(InChapterData);

	if (!MarkAssetForDirty(InChapterData))
	{
		return false;
	}

	for (auto Child : InChapterData->Children)
	{
		if(auto QR = Cast<UQuestRing>(Child))
		{
			if (!MarkAssetForDirty(QR))
			{
				return false;
			}
		}
	}
	
	int RetryTime = 3;
	while(int N = InChapterData->Children.Num())
	{
		if(auto QR = Cast<UQuestRing>(InChapterData->Children[0]))
		{
			QR->Modify();
			DeleteRing(QR);
		}
		if(N == InChapterData->Children.Num())
		{
			RetryTime -= 1;
			if(RetryTime == 0)
			{
				return false;
			}
		}
	}

	int ChapterID = InChapterData->ChapterID;

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Delete Chapter: %d."), ChapterID);
	
	if (ChapterGraphBox)
	{
		ChapterGraphBox.Get()->ClearChildren();
	}

	DeleteChapterObj(InChapterData);
	RebuildQuestObjectList(true);
	return true;
}

bool FQuestObjectivesEditor::DeleteChapterEnd(UChapterEnd* ChapterEnd)
{
	if(!IsValid(ChapterEnd))
		return false;

	auto QuestChapter = Cast<UQuestChapter>(ChapterEnd->Father);

	if (!MarkAssetForDirty(QuestChapter))
	{
		return false;
	}
	
	TArray<UEDGraphNode_Base*> DeleteNodes;
		
	for (TObjectPtr<class UEdGraphNode>& Node : QuestChapter->ChapterGraph->Nodes)
	{
		if (!Node)
			continue;
		if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(Node))
		{
			if (QNode->NodeInstance == ChapterEnd)
			{
				QNode->GetOutputTransitionNodes(DeleteNodes, UEDGraphNode_Transition::StaticClass());
				QNode->GetInputTransitionNodes(DeleteNodes, UEDGraphNode_Transition::StaticClass());
				DeleteNodes.AddUnique(QNode);
				break;
			}
		}
	}
	for (auto& Node : DeleteNodes)
	{
		Node->Modify();
		Node->DestroyNode();
	}

	QuestChapter->ChapterEnds.Remove(ChapterEnd);
	DataEntity->ChapterEnds.Remove(ChapterEnd);
	return true;
}

bool FQuestObjectivesEditor::ChangeQuestID(UQuest* InQuestData, int32 NewQuestID)
{
	if (RemoveQuestInDataEntity(InQuestData))
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Change Quest ID from %d to %d."), InQuestData->QuestID, NewQuestID);

		// Change ID
		InQuestData->QuestID = NewQuestID;
		InQuestData->QuestObjectID = NewQuestID;

		AddQuestObjToDataEntity(InQuestData);
		return true;
	}
	return false;
}

void FQuestObjectivesEditor::FlushQuestsAfterRingIDChange(UQuestRing* InRingData)
{
	// 需要刷一下 Quest 的 ID 和 Quest 记录的 RingID
	for (auto QuestObj : InRingData->Children)
	{
		UQuest* Quest = Cast<UQuest>(QuestObj);
		// 因为 lazy 机制, 在这里把 quest 的属性加载全，否则可能因为交换id，在保存时重新加载属性回读覆盖
		if (Quest->QuestGraph == nullptr)
			PreRefreshQuestGraph(Quest);
		if (!Quest)
		{
			UE_LOG(LogQuestObjectivesEditor, Error, TEXT("Ring %d has Child which is not quest. please check."), InRingData->RingID);
			continue;
		}
		FString QuestIDStr = FString::FromInt(Quest->QuestID);
		const FString NewRingIDStr = FString::FromInt(InRingData->RingID);
		if (!QuestIDStr.StartsWith(NewRingIDStr))
		{
			// 改 Quest 的 QuestID
			QuestIDStr = NewRingIDStr + QuestIDStr.Right(2);
			const int32 OldQuestID = Quest->QuestID;
			const int32 NewQuestID = FCString::Atoi(*QuestIDStr);
			ChangeQuestID(Quest, NewQuestID);

			// 改其他 Quest 的 NextTaskInfo
			for (auto OtherQuestObj : InRingData->Children)
			{
				UQuest* OtherQuest = Cast<UQuest>(OtherQuestObj);
				if (!OtherQuest)
				{
					UE_LOG(LogQuestObjectivesEditor, Error, TEXT("Ring %d has Child which is not quest. please check."), InRingData->RingID);
					continue;
				}
				for (URingTaskConditionBase* NextTaskInfo : OtherQuest->NextTaskInfoList)
				{
					if (NextTaskInfo && NextTaskInfo->NextTaskID == OldQuestID)
					{
						NextTaskInfo->NextTaskID = NewQuestID;
					}
				}
			}

			// 改 Quest 记录的 RingID
			Quest->RingID = InRingData->RingID;
		}
		else
		{
			UE_LOG(LogQuestObjectivesEditor, Log, TEXT("QuestIDStr already startswith OldRingIDStr. Do not need Flush. QuestID: %d, QuestObjectID: %d, RingID in Quest: %d"),
				Quest->QuestID, QuestObj->QuestObjectID, Quest->RingID);
		}
	}

	// 刷新一下 Ring Graph
	RefreshRingGraph(InRingData);
}

void FQuestObjectivesEditor::IDExchange(int32 FirstID, int32 SecondID)
{
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("IDExchange: %d, %d."), FirstID, SecondID);
	if (!DataEntity->QuestObjectMap.Contains(FirstID))
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("QuestFirstIDDontExist", "任务ID {0} 不存在."),
			FirstID));
		return;
	}
	if (!DataEntity->QuestObjectMap.Contains(SecondID))
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("QuestFirstIDDontExist", "任务ID {0} 不存在."),
			SecondID));
		return;
	}
	UQuestObject* FirstObj = DataEntity->QuestObjectMap[FirstID];
	UQuestObject* SecondObj = DataEntity->QuestObjectMap[SecondID];
	auto FirstQuest = Cast<UQuest>(FirstObj);
	auto SecondQuest = Cast<UQuest>(SecondObj);
	auto FirstRing = Cast<UQuestRing>(FirstObj);
	auto SecondRing = Cast<UQuestRing>(SecondObj);
	auto FirstChapter = Cast<UQuestChapter>(FirstObj);
	auto SecondChapter = Cast<UQuestChapter>(SecondObj);

	// QuestObjectID 不更改，这样在保存时可以做检查
	if (FirstQuest && SecondQuest)
	{
		if (FirstQuest->RingID != SecondQuest->RingID)
		{
			FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("QuestFatherNotEqual", "任务 {0} 的环 {1} 与任务 {2} 的环 {3} 不一致."),
				FirstID, FirstQuest->RingID, SecondID, SecondQuest->RingID));
			return;
		}
		FirstQuest->QuestID = SecondID;
		SecondQuest->QuestID = FirstID;
	}
	else if (FirstRing && SecondRing)
	{
		RefreshChapterGraph(Cast<UQuestChapter>(FirstRing->Father));
		RefreshChapterGraph(Cast<UQuestChapter>(SecondRing->Father));
		RefreshRingGraph(FirstRing);
		RefreshRingGraph(SecondRing);

		if (FirstRing->QuestType != SecondRing->QuestType)
		{
			FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("QuestTypeNotEqual", "环 {0} 与环 {1} 的 任务类型 不一致."),
				FirstID, SecondID));
			return;
		}

		FirstRing->RingID = SecondID;
		FText CheckDialog;
		if (!FirstRing->CheckRingID(CheckDialog, false))
		{
			FirstRing->RingID = FirstID;
			FMessageDialog::Open(EAppMsgType::Ok, CheckDialog);
			return;
		}

		SecondRing->RingID = FirstID;
		if (!SecondRing->CheckRingID(CheckDialog, false))
		{
			FirstRing->RingID = FirstID;
			SecondRing->RingID = SecondID;
			FMessageDialog::Open(EAppMsgType::Ok, CheckDialog);
			return;
		}
	}
	else if (FirstChapter && SecondChapter)
	{
		if (FirstChapter->QuestType != SecondChapter->QuestType)
		{
			FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("ChapterTypeNotEqual", "章节 {0} 与章节 {1} 的类型不一致."),
				FirstID, SecondID));
			return;
		}
		RefreshChapterGraph(FirstChapter);
		RefreshChapterGraph(SecondChapter);
		FirstChapter->ChapterID = SecondID;
		SecondChapter->ChapterID = FirstID;
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("First and Second dont have same type. Please check."));
		return;
	}

	RemoveInDataEntityMap(FirstID);
	RemoveInDataEntityMap(SecondID);
	AddInDataEntityMap(FirstObj);
	AddInDataEntityMap(SecondObj);
	MarkAssetForDirty(FirstObj);
	MarkAssetForDirty(SecondObj);

	if (FirstQuest && SecondQuest)
	{
		FirstQuest->OnRefreshQuestName.Broadcast();
		SecondQuest->OnRefreshQuestName.Broadcast();
		RefreshRingGraph(Cast<UQuestRing>(FirstQuest->Father));
	}
	else if (FirstRing && SecondRing)
	{
		FirstRing->OnRefreshRingname.Broadcast();
		SecondRing->OnRefreshRingname.Broadcast();
		FlushQuestsAfterRingIDChange(FirstRing);
		FlushQuestsAfterRingIDChange(SecondRing);
		RefreshChapterGraph(Cast<UQuestChapter>(FirstRing->Father));
		MarkAssetForDirty(FirstRing->Father);
		MarkAssetForDirty(SecondRing->Father);
	}
}

FReply FQuestObjectivesEditor::TablePreview()
{
	TMap<FName, const uint8*> AllTableData;

	FString CreateAssetFullPath(TEXT("/Game/Editor/QuestEditor/EditorPreviewTable"));
	FString FileName("QuestPreviewDataTable");
	CreateAssetFullPath += FString::Printf(TEXT("/%s"), *FileName);

	UPackage* Package = CreatePackage(*CreateAssetFullPath);
	Package->SetDirtyFlag(true);

	UDataTable* ALDataTable = NewObject<UDataTable>(Package, UDataTable::StaticClass(), FName(*FileName), EObjectFlags::RF_Public | RF_Standalone);
	FAssetRegistryModule::AssetCreated(ALDataTable);

	for (size_t i = 0; i < DataEntity->AllQuests.Num(); i++)
	{
		UQuest* QuestData = DataEntity->AllQuests[i].Get();
		if (QuestData)
		{
			UDataTable* DataTable = NewObject<UDataTable>();

			TMap<FName, const uint8*> TableData;
			FQuestTablePreview::CopyStructTableDataFromQuest(DataTable, QuestData, TableData);

				DataTable->CreateTableFromRawData(TableData, DataTable->RowStruct);

			if (i == 0)
			{
				ALDataTable->RowStruct = DataTable->RowStruct;
				for (auto& Elem : DataTable->GetRowMap())
				{
					AllTableData.Add(Elem.Key, Elem.Value);
				}

				ALDataTable->CreateTableFromRawData(AllTableData, ALDataTable->RowStruct);
			}
			else
			{
				for (auto& Elem : DataTable->GetRowMap())
				{
					ALDataTable->AddRow(Elem.Key, *reinterpret_cast<FTableRowBase*>(Elem.Value));
				}
			}
		}
	}

	ALDataTable->MarkPackageDirty();

	FAssetRegistryModule::AssetCreated(ALDataTable);

	ALDataTable->OnDataTableEditorDelegate.AddRaw(this, &FQuestObjectivesEditor::OnDataTableEditor);

	TArray<UObject*> InObjects;
	InObjects.Add(ALDataTable);
	GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAssets(InObjects);
	

	return FReply::Handled();
}

void FQuestObjectivesEditor::OnDataTableEditor(const UDataTable* InDataTable, const FName& Name)
{
	FString ID(Name.ToString());
	if(ID.IsEmpty())
		return ;

	int32 QuestID = FCString::Atoi(*ID);

	UQuest* SelectQuestData(nullptr);
	for (size_t i = 0; i < DataEntity->AllQuests.Num(); i++)
	{
		UQuest* QuestData = DataEntity->AllQuests[i].Get();
		if (QuestData && QuestData->QuestID == QuestID)
		{
			SelectQuestData = QuestData;
			break;
		}
	}
	if(!SelectQuestData)
		return ;

	ChapterListView->ClearSelection();

	RebuildChapterList(true, false);

	for (auto& ChapterItem : DataEntity->ChapterListItems)
	{
		if (IsValid(ChapterItem) && IsValid(ChapterItem.Get()) && ChapterItem->ChapterID == SelectQuestData->ChapterID)
		{
			ChapterListView->SetItemSelection(ChapterItem, true, ESelectInfo::Direct);
			break;
		}
	}


	RingListView->ClearSelection();
	RebuildRingList(true);

	
	 
	for (auto& RingItem : DataEntity->RingListItems)
	{
		if (IsValid(RingItem) && IsValid(RingItem.Get()) && RingItem->RingID == SelectQuestData->RingID)
		{
			RingListView->SetItemSelection(RingItem, true, ESelectInfo::Direct);
			break;
		}
	}

	QuestListView->ClearSelection();

	RebuildQuestList(true);

	for (auto& QuestItem : DataEntity->QuestListItems)
	{
		if (IsValid(QuestItem) && IsValid(QuestItem) && QuestItem->QuestID == SelectQuestData->QuestID)
		{
			QuestListView->SetItemSelection(QuestItem, true, ESelectInfo::Direct);

			OnQuestListItemClicked(QuestItem);
			break;
		}
	}
}

FReply FQuestObjectivesEditor::OnShowSourceControlState()
{
	bShowSourceControlState = !bShowSourceControlState;
	RebuildQuestObjectList(false);
	return FReply::Handled();
}

FReply FQuestObjectivesEditor::OpenFlowChart()
{
	FString StringFlowToolPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());
	FString ProjectXMLPath = StringFlowToolPath;
	ProjectXMLPath += "../../Tools/FlowChartTool/c7.xml";
	StringFlowToolPath += "../../Tools/FlowChartTool/FlowChartTool.exe";
	FString Params;

	uint32* ID = 0;

	FPlatformProcess::CreateProc(*StringFlowToolPath, *Params, true, false, false, ID, 0, nullptr, nullptr);

	return FReply::Handled();
}

void FQuestObjectivesEditor::GetChapterIDRange(EQuestType QuestType, int32& OutMinChapterID, int32& OutMaxChapterIDLimit)
{
	int32 MinChapterID(1);
	int32 MaxChapterIDLimit(99999);
	switch (QuestType)
	{
	case EQuestType::MAIN:
		MinChapterID = 10000;
		MaxChapterIDLimit = 19999;
		break;
	case EQuestType::SUBTASK:
		MinChapterID = 20000;
		MaxChapterIDLimit = 39999;
		break;
	case EQuestType::CITYCOLLECT:
		MinChapterID = 20000;
		MaxChapterIDLimit = 39999;
		break;
	case EQuestType::WANDER:
		MinChapterID = 20000;
		MaxChapterIDLimit = 39999;
		break;
	case EQuestType::REPEAT:
		MinChapterID = 40000;
		MaxChapterIDLimit = 49999;
		break;
	case EQuestType::WANTED:
		MinChapterID = 50000;
		MaxChapterIDLimit = 59999;
		break;
	case EQuestType::SEQUENCE:
		MinChapterID = 10000;
		MaxChapterIDLimit = 19999;
		break;
	case EQuestType::ROLEPLAY:
		MinChapterID = 70000;
		MaxChapterIDLimit = 79999;
		break;
	case EQuestType::EQT_Max:
		MinChapterID = 1;
		MaxChapterIDLimit = 99999;
	}
	OutMinChapterID = MinChapterID;
	OutMaxChapterIDLimit = MaxChapterIDLimit;
}

void FQuestObjectivesEditor::GetRingIDRange(EQuestType QuestType, int32& OutMinRingID, int32& OutMaxRingIDLimit)
{
	int32 MinRingID(0);
	int32 MaxRingIDLimit(999999);
	switch (QuestType)
	{
	case EQuestType::MAIN:
		MinRingID = 600000;
		MaxRingIDLimit = 609999;
		break;
	case EQuestType::SUBTASK:
		MinRingID = 980000;
		MaxRingIDLimit = 999999;
		break;
	case EQuestType::CITYCOLLECT:
		MinRingID = 980000;
		MaxRingIDLimit = 999999;
		break;
	case EQuestType::WANDER:
		MinRingID = 980000;
		MaxRingIDLimit = 999999;
		break;
	case EQuestType::REPEAT:
		MinRingID = 970000;
		MaxRingIDLimit = 979999;
		break;
	case EQuestType::WANTED:
		MinRingID = 930000;
		MaxRingIDLimit = 939999;
		break;
	case EQuestType::SEQUENCE:
		MinRingID = 600000;
		MaxRingIDLimit = 609999;
		break;
	case EQuestType::ROLEPLAY:
		MinRingID = 940000;
		MaxRingIDLimit = 949999;
		break;
	case EQuestType::EQT_Max:
		MinRingID = 0;
		MaxRingIDLimit = 999999;
	}
	OutMinRingID = MinRingID;
	OutMaxRingIDLimit = MaxRingIDLimit;
}

FLinearColor FQuestObjectivesEditor::GetChapterTypeColor(TObjectPtr<UQuestObject> Item)
{
	FColor Color(FColor::Green);
	if (IsValid(Item))
	{
		if (FColor* _Color = QuestTypeColorMap.Find(Item->QuestType))
		{
			Color = *_Color;
		}
	}

	return Color;
}

FString FQuestObjectivesEditor::GetItemSourceControlState(TObjectPtr<UQuestObject> Item)
{
	FString RetVal;
	if(auto ChapterItem = Cast<UQuestChapter>(Item))
	{
		FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());
		FString AssetFilePath = CurrentPath + "Script/Data/Config/Quest/";
		FString ChapterFilePath = AssetFilePath + "Chapter/" + FString::FromInt(ChapterItem->ChapterID) + ".lua";
		const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ChapterFilePath);
		auto FileState = SourceControlHelpers::QueryFileState(AbsolutePath);
		if(FileState.bIsCheckedOut)
		{
			RetVal = "Perforce.CheckedOut";
		}
		if(FileState.bIsAdded)
		{
			RetVal = "Perforce.OpenForAdd";
		}
		if(FileState.bIsCheckedOutOther)
		{
			RetVal = "Perforce.CheckedOutByOtherUser";
		}
	}
	return RetVal;
}

TSharedRef<ITableRow> FQuestObjectivesEditor::GenerateQuestObjectItemRow(TObjectPtr<UQuestObject> Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	FLinearColor TextColor = {1,1,1,1};
	if (Item->QuestObjectType == Chapter || Item->QuestObjectType == Root)
	{
		TextColor = GetChapterTypeColor(Item);
	}
	FString Display = FString::Printf(TEXT("%s"), *Item->QuestObjectName);
	if (Item->QuestObjectType == Chapter)
	{
		if (auto Chapter = Cast<UQuestChapter>(Item))
		{
			// 显示章节序号
			Display = FString::Printf(TEXT("%s %s"), *Item->QuestObjectName, *Chapter->ChapterIndex);
		}
	}
		
	FText DisplayText = FText::FromString(Display);
	FString SourceControlState;
	if(bShowSourceControlState)
	{
		SourceControlState = GetItemSourceControlState(Item);
	}
	return SNew(STableRow<TObjectPtr<UQuestChapter>>, OwnerTable)
		[
			SNew(SHorizontalBox)
			//TODO: SourceControl mark implant
			+SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SImage)
				.Image(FAppStyle::GetBrush(*SourceControlState))
				.ColorAndOpacity(FLinearColor::Red)
			]
			+ SHorizontalBox::Slot()
			[
				SNew(STextBlock)
				.Text(DisplayText)
				.ColorAndOpacity(TextColor)
			]

		];
}

void FQuestObjectivesEditor::OnGetQuestObjectTreeChildren(TObjectPtr<UQuestObject> InItem,
                                                          TArray<TObjectPtr<UQuestObject>>& OutChildren)
{
	if(InItem->IsA(UQuestChapter::StaticClass()))
	{
		return;
	}
	if(InItem->IsA(UQuestRing::StaticClass()))
	{
		return;
	}
	if(InItem->IsA(UQuest::StaticClass()))
	{
		return;
	}
	TArray<TObjectPtr<UQuestObject>> ChildItems;
	for(auto ChildObj : InItem->Children)
	{
		ChildItems.Add(ChildObj);
	}
	ChildItems.Sort([](const TObjectPtr<UQuestObject>& A, const TObjectPtr<UQuestObject>& B)
	{
		if(TObjectPtr<UQuestChapter> ChapterA = Cast<UQuestChapter>(A))
		{
			if (TObjectPtr<UQuestChapter> ChapterB = Cast<UQuestChapter>(B))
			{
				return *ChapterA < *ChapterB;
			}
		}
		return *A < *B;
	});
	OutChildren.Append(ChildItems);
}

FReply FQuestObjectivesEditor::FindBrowserOnClicked()
{
	if (QuestTreeView)
	{
		return QuestTreeView->OnFindBrowserOnClicked();
	}
	return FReply::Handled();
}

TArray<TObjectPtr<UQuestChapter>>& FQuestObjectivesEditor::GetAllQuestChapters()
{
	return DataEntity->AllChapters;
}

TArray<TObjectPtr<UQuestRing>>& FQuestObjectivesEditor::GetAllQuestRings()
{
	return DataEntity->AllQuestRings;
}

TArray<TObjectPtr<UQuest>>& FQuestObjectivesEditor::GetAllQuests()
{
	return DataEntity->AllQuests;
}

bool FQuestObjectivesEditor::IsTickableInEditor() const
{
	return true;
}

void FQuestObjectivesEditor::Tick(float DeltaTime)
{
	// tick可能会被UI进程阻塞掉导致TickableGameObj无法tick, 改用timer
	/*if (bNextCreateQuest)
	{
		bNextCreateQuest = false;

		if (RingGraph.IsValid())
		{
			UEventDrivenGraphSchema::CreateQuestNode(RingGraph.Get(), PlacePos);
		}
	}*/

	if (bGraphStateChanged) {
		bGraphStateChanged = false;
		HandleGraphChanged();
	}
}

bool FQuestObjectivesEditor::IsTickable() const
{
	return true;
}

TStatId FQuestObjectivesEditor::GetStatId() const
{
	return TStatId();
}

void FQuestObjectivesEditor::BindCommands()
{
	const FQuestEditorCommands& Commands = FQuestEditorCommands::Get();

	ToolkitCommands->MapAction(
		Commands.CreateChapter,
		FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CreateChapter));
	
	ToolkitCommands->MapAction(
		Commands.ChapterCopy,
		FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CopySelectedChapter));
	
	ToolkitCommands->MapAction(
		Commands.ChapterCut,
		FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::OnCutSelectedChapter));

	ToolkitCommands->MapAction(
		Commands.ChapterPaste,
		FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::PasteCopiedChapter, true));

	ToolkitCommands->MapAction(
		Commands.ChapterDelete,
		FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::OnDeleteChapter));
}

TSharedRef<SDockTab> FQuestObjectivesEditor::SpawnTab_GraphEditor(const FSpawnTabArgs& Args)
{
		SAssignNew(GraphDockTab, SDockTab)
		.Label(LOCTEXT("QuestGraph", "Quest Graph"))
		.TabColorScale(GetTabColorScale())
		[
			SAssignNew(GraphHorizontalBox, SHorizontalBox)
			
		];

		/*GraphHorizontalBox.Get()->AddSlot()
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Fill)
			[
				GraphEditor.ToSharedRef()
			];*/

	return GraphDockTab.ToSharedRef();
	
}

TSharedRef<SDockTab> FQuestObjectivesEditor::SpawnTab_ChapterGraph(const FSpawnTabArgs& Args)
{
	SAssignNew(ChapterGraphDockTab, SDockTab)
		.Label(LOCTEXT("ChapterGraph", "Chapter Graph"))
		.TabColorScale(GetTabColorScale())
		[
			SAssignNew(ChapterGraphBox, SVerticalBox)
		];

	return ChapterGraphDockTab.ToSharedRef();
}

TSharedRef<SDockTab> FQuestObjectivesEditor::SpawnTab_RingGraph(const FSpawnTabArgs& Args)
{
	SAssignNew(RingGraphDockTab, SDockTab)
		.Label(LOCTEXT("RingGraph", "Ring Graph"))
		.TabColorScale(GetTabColorScale())
		[
			SAssignNew(RingGraphBox, SVerticalBox)
		];

	return RingGraphDockTab.ToSharedRef();

}

TSharedRef<SDockTab> FQuestObjectivesEditor::SpawnTab_FindInQuest(const FSpawnTabArgs& Args)
{
	return SNew(SDockTab)
		.Label(LOCTEXT("FindInQuests", "Find in quests"))
		.TabColorScale(GetTabColorScale())
		[
			SAssignNew(FindResults, SFindInQuests, SharedThis(this))
		];
}

bool FQuestObjectivesEditor::RunP4Command(const FString& Command, FString& OutResult)
{
	FString P4ExecCommand = FString::Printf(TEXT("p4"));
	FString DefaultWorkingDirectory = FPaths::ProjectDir();
	int32 ReturnCode;

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("RunP4Command: %s."), *P4ExecCommand);

	// 创建管道
	void* AutoP4ReadPipe = NULL;
	void* AutoP4WritePipe = NULL;
	FPlatformProcess::CreatePipe(AutoP4ReadPipe, AutoP4WritePipe);
	
	// FPlatformProcess::ExecProcess(*P4ExecCommand, *Command, &ReturnCode, &OutResult, nullptr);
	auto ProcHandle = FPlatformProcess::CreateProc(*P4ExecCommand, *Command, false, true, true, nullptr, 0, nullptr, AutoP4WritePipe, AutoP4ReadPipe);

	// 设置定时器
	bool bTimedOut = false;
	float TimeOutLimit = 3.f;
	float TimePassed = 0;
	FString StdOut;
	
	// 轮询进程状态
	while (FPlatformProcess::IsProcRunning(ProcHandle) && !bTimedOut)
	{
		FPlatformProcess::Sleep(0.1f); // 短暂休眠以减少CPU占用
		StdOut += FPlatformProcess::ReadPipe(AutoP4ReadPipe);
		TimePassed += 0.1f;
		if (TimePassed >= TimeOutLimit)
		{
			bTimedOut = true;
		}
	}

	// 检查是否超时
	if (bTimedOut)
	{
		// 终止进程
		FPlatformProcess::TerminateProc(ProcHandle, true);
		FText ConfirmText =LOCTEXT("QuestP4TimeOutWarning", "P4 action timeout, please check your P4 state or restart it");
		FMessageDialog::Open(EAppMsgType::OkCancel, ConfirmText);
		ReturnCode = -1; // 返回错误状态
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("Command execution timed out and process terminated"));
	}
	else
	{
		// 获取返回值
		FPlatformProcess::GetProcReturnCode(ProcHandle, &ReturnCode);
		StdOut += FPlatformProcess::ReadPipe(AutoP4ReadPipe);
		OutResult = StdOut;
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Command completed with return code: %d"), ReturnCode);
	}
	FPlatformProcess::CloseProc(ProcHandle);
	FPlatformProcess::ClosePipe(AutoP4ReadPipe, AutoP4WritePipe);
	return ReturnCode == 0;
}

bool FQuestObjectivesEditor::SetP4WorkSpace()
{
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	FString ClientName;
	if (SourceControlProvider.IsEnabled())
	{
		ClientName = SourceControlProvider.GetCurrentWorkspaceName();
		if(ClientName.Len() == 0)
		{
			UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Can't get current Client"));
		}
	}
	if(ClientName.Len()>0)
	{
		FString Result;
		FString WorkSpaceCommand = FString::Printf(TEXT("set P4CLIENT=%s"), *ClientName);
		RunP4Command(WorkSpaceCommand, Result);
	}
	return true;
}

bool FQuestObjectivesEditor::GetDepotPath(const FString& LocalPath, FString& DepotPath)
{
	FString Command = FString::Printf(TEXT("where %s"), *LocalPath);
	FString Result;
	bool bSuccess = RunP4Command(Command, Result);

	if (bSuccess)
	{
		// Parse the result to extract the depot path
		TArray<FString> Lines;
		Result.ParseIntoArrayLines(Lines);

		if (Lines.Num() > 0)
		{
			TArray<FString> Tokens;
			Lines[0].ParseIntoArray(Tokens, TEXT(" "), true);

			if (Tokens.Num() >= 3)
			{
				DepotPath = Tokens[0]; // The depot path is typically the third token
				UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Local path %s corresponds to depot path %s."), *LocalPath, *DepotPath);
				return true;
			}
		}
	}

	UE_LOG(LogQuestObjectivesEditor, Error, TEXT("Failed to get depot path for local path %s. Result: %s"), *LocalPath, *Result);
	return false;
}

bool FQuestObjectivesEditor::GetLocalPath(const FString& DepotPath, FString& LocalPath)
{
	FString WhereResult;
	FString WhereCommand = FString::Printf(TEXT("where %s"), *DepotPath);
	if (RunP4Command(WhereCommand, WhereResult))
	{
		TArray<FString> WhereLines;
		WhereResult.ParseIntoArrayLines(WhereLines);

		if (WhereLines.Num() > 0)
		{
			TArray<FString> WhereTokens;
			WhereLines[0].ParseIntoArray(WhereTokens, TEXT(" "), true);

			if (WhereTokens.Num() > 2)
			{
				LocalPath = WhereTokens[2].TrimStartAndEnd();
				return true;
			}
		}
	}
	return false;
}

bool FQuestObjectivesEditor::IsCheckedOutByOthers(const FString& FilePath)
{
	FString Command = FString::Printf(TEXT("opened -a %s"), *FilePath);
	FString Result;
	bool bSuccess = RunP4Command(Command, Result);

	
	if (bSuccess)
	{
		TArray<FString> Lines;
		Result.ParseIntoArrayLines(Lines);

		for (const FString& Line : Lines)
		{
			if (Line.Contains(TEXT(" - add ")))
			{
				// Extract the user who marked the file for add
				int32 UserStart = Line.Find(TEXT(" by ")) + 4;
				int32 UserEnd = Line.Find(TEXT("@"), ESearchCase::IgnoreCase, ESearchDir::FromStart, UserStart);
				auto OutUser = Line.Mid(UserStart, UserEnd - UserStart);
				UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Depot path %s is marked for add by user %s."), *FilePath, *OutUser);
				return true;
			}
			if (Line.Contains(TEXT(" - edit ")))
			{
				// Extract the user who marked the file for add
				int32 UserStart = Line.Find(TEXT(" by ")) + 4;
				int32 UserEnd = Line.Find(TEXT("@"), ESearchCase::IgnoreCase, ESearchDir::FromStart, UserStart);
				auto OutUser = Line.Mid(UserStart, UserEnd - UserStart);
				UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Depot path %s is editing by user %s."), *FilePath, *OutUser);
				return true;
			}
			if (Line.Contains(TEXT(" - delete ")))
			{
				// Extract the user who marked the file for add
				int32 UserStart = Line.Find(TEXT(" by ")) + 4;
				int32 UserEnd = Line.Find(TEXT("@"), ESearchCase::IgnoreCase, ESearchDir::FromStart, UserStart);
				auto OutUser = Line.Mid(UserStart, UserEnd - UserStart);
				UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Depot path %s is marked for delete by user %s."), *FilePath, *OutUser);
				return true;
			}
		}
	}
	return false;
}

bool FQuestObjectivesEditor::LockFile(const FString& FilePath)
{
	FString Command = FString::Printf(TEXT("lock %s"), *FilePath);
	FString Result;
	bool bSuccess = RunP4Command(Command, Result);

	if (bSuccess)
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("File %s has been locked."), *FilePath);
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Error, TEXT("Failed to lock file %s. Result: %s"), *FilePath, *Result);
	}

	return bSuccess;
}

bool FQuestObjectivesEditor::AddFile(const FString& FilePath)
{
	FString Command = FString::Printf(TEXT("add -d -c default %s"), *FilePath);
	FString Result;
	bool bSuccess = RunP4Command(Command, Result);

	if (bSuccess)
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("File %s has been added."), *FilePath);
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Error, TEXT("Failed to add file %s. Result: %s"), *FilePath, *Result);
	}

	return bSuccess;
}

bool FQuestObjectivesEditor::DeleteEmptyFilesInChangelist()
{
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("DeleteEmptyFilesInChangelist Begin."));
	
	FString Result;
	if (RunP4Command(TEXT("opened -c default"), Result))
	{
		TArray<FString> Lines;
		Result.ParseIntoArrayLines(Lines);

		for (const FString& Line : Lines)
		{
			TArray<FString> Tokens;
			Line.ParseIntoArray(Tokens, TEXT("#"), true);

			if (Tokens.Num() > 0)
			{
				FString DepotPath = Tokens[0].TrimStartAndEnd();
				FString FilePath;
				GetLocalPath(DepotPath, FilePath);
				// Check if the file is empty and delete it if so
				if (FPaths::FileExists(FilePath))
				{
					int64 FileSize = IFileManager::Get().FileSize(*FilePath);
					if (FileSize == 0)
					{
						RunP4Command(FString::Printf(TEXT("revert %s"), *FilePath), Result);
						IFileManager::Get().Delete(*FilePath);
						UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Deleted empty file: %s"), *FilePath);
					}
				}
			}
		}
		return true;
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("Failed to retrieve files from the default changelist."));
		return false;
	}
}

bool FQuestObjectivesEditor::MarkAssetForDirty(UQuestChapter* DirtyAsset)
{
	if(bLoadingChapterGraph || bLoadingRingGraph)
	{
		return true;
	}
	if(DataEntity->DirtyChapters.Contains(DirtyAsset))
	{
		return true;
	}

	DataEntity->Modify();
	TObjectPtr<UQuestChapter> DirtyAssetPtr(DirtyAsset);
	if (!DataEntity->DirtyChapters.Contains(DirtyAssetPtr))
	{
		DataEntity->DirtyChapters.Add(DirtyAssetPtr);
	}
	return true;
}

bool FQuestObjectivesEditor::MarkAssetForDirty(UQuestRing* DirtyAsset)
{
	if(bLoadingChapterGraph || bLoadingRingGraph)
	{
		return true;
	}
	if(DataEntity->DirtyRings.Contains(DirtyAsset))
	{
		return true;
	}

	DataEntity->Modify();
	TObjectPtr<UQuestRing> DirtyAssetPtr(DirtyAsset);
	if (!DataEntity->DirtyRings.Contains(DirtyAssetPtr))
	{
		DataEntity->DirtyRings.Add(DirtyAssetPtr);
	}
	return true;
}

bool FQuestObjectivesEditor::MarkAssetForDirty(UQuest* DirtyAsset)
{
	DataEntity->Modify();
	TObjectPtr<UQuest> DirtyAssetPtr(DirtyAsset);
	if (!DataEntity->DirtyQuests.Contains(DirtyAssetPtr))
	{
		DataEntity->DirtyQuests.Add(DirtyAssetPtr);
	}
	return true;
}

bool FQuestObjectivesEditor::MarkAssetForDirty(UQuestObject* DirtyAsset)
{
	if (DirtyAsset)
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForDirty: %d."), DirtyAsset->QuestObjectID);
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForDirty Invalid DirtyAsset."));
		return false;
	}

	if (auto Quest = Cast<UQuest>(DirtyAsset))
	{
		return MarkAssetForDirty(Quest);
	}
	else if (auto Ring = Cast<UQuestRing>(DirtyAsset))
	{
		return MarkAssetForDirty(Ring);
	}
	else if (auto Chapter = Cast<UQuestChapter>(DirtyAsset))
	{
		return MarkAssetForDirty(Chapter);
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Error, TEXT("Unknown type : %d"), DirtyAsset->QuestObjectID);
		return false;
	}
}

void FQuestObjectivesEditor::MarkCurChapterForDirty()
{
	if(bMarkingCurChapterDirty)
	{
		return;
	}
	bMarkingCurChapterDirty = true;
	if(bFocusingTreeView)
	{
		TArray<TObjectPtr<UQuestObject>> Selections = QuestObjectTreeView->GetSelectedItems();
		if (Selections.Num() > 0)
		{
			auto SelectedItem = Selections[0];
			if (IsValid(SelectedItem))
			{
				MarkAssetForDirty(Cast<UQuestChapter>(SelectedItem.Get()));
			}
		}
	}else
	{
		auto Selections = ChapterListView->GetSelectedItems();
		if (Selections.Num() > 0)
		{
			auto SelectedItem = Selections[0];
			if (IsValid(SelectedItem))
			{
				MarkAssetForDirty(SelectedItem.Get());	
			}
		}
		else
		{
			UE_LOG(LogQuestObjectivesEditor, Log, TEXT("%s"), *LOCTEXT("No seleceted chapter warning", "Please Select Chapter to Modify").ToString());
		}
	}
	bMarkingCurChapterDirty = false;
}

void FQuestObjectivesEditor::MarkCurRingForDirty()
{
	if(bLoadingChapterGraph || bMarkingCurRingDirty)
	{
		return;
	}
	bMarkingCurRingDirty = true;
	auto Selections = RingListView->GetSelectedItems();
	if (Selections.Num() > 0)
	{
		auto SelectedItem = Selections[0];
		if (IsValid(SelectedItem))
		{
			MarkAssetForDirty(SelectedItem.Get());	
		}
	}
	else
		FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("No seleceted ring warning", "Please Select Ring to Modify"));
	
	bMarkingCurRingDirty = false;
}

void FQuestObjectivesEditor::MarkCurQuestForDirty()
{
	if(bMarkingCurQuestDirty)
	{
		return;
	}
	bMarkingCurQuestDirty = true;
	auto Selections = QuestListView->GetSelectedItems();
	if (Selections.Num() > 0)
	{
		auto SelectedItem = Selections[0];
		if (IsValid(SelectedItem))
		{
			MarkAssetForDirty(SelectedItem.Get());	
		}
	}
	else
		FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("No selected quest warning", "Please Select Quest to Modify"));

	bMarkingCurQuestDirty = false;
}

bool FQuestObjectivesEditor::MarkAssetForCheck(UQuestChapter* DirtyAsset)
{
	if (DirtyAsset)
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForCheck ChapterID: %d."), DirtyAsset->ChapterID);
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForCheck QuestObjectID: %d."), DirtyAsset->QuestObjectID);
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForCheck Invalid DirtyAsset."));
		return false;
	}
	
	DataEntity->Modify();
	TObjectPtr<UQuestChapter> DirtyAssetPtr(DirtyAsset);
	if (!DataEntity->DirtyCheckChapters.Contains(DirtyAssetPtr))
	{
		DataEntity->DirtyCheckChapters.Add(DirtyAssetPtr);
	}
	return true;
}

bool FQuestObjectivesEditor::MarkAssetForCheck(UQuestRing* DirtyAsset)
{
	if (DirtyAsset)
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForCheck RingID: %d."), DirtyAsset->RingID);
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForCheck QuestObjectID: %d."), DirtyAsset->QuestObjectID);
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForCheck Invalid DirtyAsset."));
		return false;
	}
	
	DataEntity->Modify();
	TObjectPtr<UQuestRing> DirtyAssetPtr(DirtyAsset);
	if (!DataEntity->DirtyCheckRings.Contains(DirtyAssetPtr))
	{
		DataEntity->DirtyCheckRings.Add(DirtyAssetPtr);
	}
	return true;
}

bool FQuestObjectivesEditor::MarkAssetForCheck(UQuest* DirtyAsset)
{
	if (DirtyAsset)
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForCheck QuestID: %d."), DirtyAsset->QuestID);
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForCheck QuestObjectID: %d."), DirtyAsset->QuestObjectID);
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("MarkAssetForCheck Invalid DirtyAsset."));
		return false;
	}
	
	DataEntity->Modify();
	TObjectPtr<UQuest> DirtyAssetPtr(DirtyAsset);
	if (!DataEntity->DirtyCheckQuests.Contains(DirtyAssetPtr))
	{
		DataEntity->DirtyCheckQuests.Add(DirtyAssetPtr);
	}
	return true;
}


UQuest* FQuestObjectivesEditor::GetQuestObjByQuestID(int32 QuestID, bool bReMapping)
{
	if(bReMapping && DataEntity->RevCopiedMapping.Contains(QuestID))
	{
		QuestID = DataEntity->RevCopiedMapping[QuestID];
	}
	if(DataEntity->QuestMap.Contains(QuestID))
	{
		return DataEntity->QuestMap[QuestID].Get();
	}
	for (size_t i = 0; i < DataEntity->AllQuests.Num(); i++)
	{
		auto i2 = DataEntity->AllQuests[i];
		if (IsValid(i2) && i2->QuestID == QuestID)
		{
			return i2.Get();
		}
	}
	return nullptr;
}

UQuestRing* FQuestObjectivesEditor::GetRingObjByRingID(int32 RingID, bool bReMapping)
{
	if(bReMapping && DataEntity->RevCopiedMapping.Contains(RingID))
	{
		RingID = DataEntity->RevCopiedMapping[RingID];
	}
	if(DataEntity->RingMap.Contains(RingID))
	{
		return DataEntity->RingMap[RingID].Get();
	}else
	{
		for (size_t i = 0; i < DataEntity->AllQuestRings.Num(); i++)
		{
			auto i2 = DataEntity->AllQuestRings[i];
			if (IsValid(i2) && i2->RingID == RingID)
			{
				return i2.Get();
			}
		}
	}
	return nullptr;
}

UApplyBase* FQuestObjectivesEditor::GetTransitionApplyType()
{
	UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass());
	UApplyBase* RetVal = nullptr;
	if (UClass* Class = GetBPClass(QuestSettings->TransitionApplyType))
	{
		RetVal = NewObject<UApplyBase>(GetTransientPackage(), Class);
	}
	return RetVal;
}

int32 FQuestObjectivesEditor::GetAvailableID(const UQuestObject* InObj, bool bCreate)
{
	ISourceControlProvider& SourceControlProvider = ISourceControlModule::Get().GetProvider();
	FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());
	FString AssetFilePath = CurrentPath + "Script/Data/Config/Quest/";
	
	auto ChapterObj = Cast<UQuestChapter>(InObj);
	auto RingObj = Cast<UQuestRing>(InObj);
	auto QuestObj = Cast<UQuest>(InObj);
	FString EmptyString;
	FText ExportErrorMessage;
	if(ChapterObj)
	{
		int32 MinChapterID(1);
		int32 MaxChapterID(99999);
		if (!bCreate)
		{
			GetChapterIDRange(ChapterObj->QuestType, MinChapterID, MaxChapterID);
		}
		for(int Index = MinChapterID; Index<MaxChapterID; Index++)
		{
			int NewChapterID = Index;

			// 如果是第一次创建，则初始化 id 为不合法的负数
			if (bCreate)
			{
				NewChapterID = -Index;
			}
			
			if(DataEntity->QuestObjectMap.Contains(NewChapterID) || DataEntity->ChapterMap.Contains(NewChapterID))
			{
				continue;
			}
			FString ChapterFilePath = AssetFilePath + "Chapter/" + FString::FromInt(NewChapterID) + ".lua";
			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ChapterFilePath);
			if(FPaths::FileExists(AbsolutePath))
			{
				continue;
			}
			if (!bCreate)
			{
				FString DepotPath;
				auto SCState = SourceControlHelpers::QueryFileState(AbsolutePath);
				GetDepotPath(AbsolutePath, DepotPath);
				if(IsCheckedOutByOthers(DepotPath) || SCState.bIsSourceControlled)
				{
					continue;
				}
			}
			return NewChapterID;
		}
	}
	
	if(RingObj)
	{
		int32 MinRingID(1);
		int32 MaxRingIDLimit(999999);
		if (!bCreate)
		{
			GetRingIDRange(RingObj->QuestType, MinRingID, MaxRingIDLimit);
		}
		for(int Index = MinRingID; Index < MaxRingIDLimit; Index++)
		{
			int NewRingID = Index;

			// 如果是第一次创建，则初始化 id 为不合法的负数
			if (bCreate)
			{
				NewRingID = -Index;
			}

			if(DataEntity->QuestObjectMap.Contains(NewRingID) || DataEntity->RingMap.Contains(NewRingID))
			{
				continue;
			}
			bool bPendingDeleteConflict = false;
			for(auto PendingDeleteObj : DataEntity->PendingDeleteObjects)
			{
				if (PendingDeleteObj.IsValid() && PendingDeleteObj->QuestObjectID == NewRingID)
				{
					bPendingDeleteConflict = true;
					break;
				}
			}
			if(bPendingDeleteConflict)
			{
				continue;
			}
			FString RingFilePath = AssetFilePath + "Ring/" + FString::FromInt(NewRingID) + ".lua";
			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(RingFilePath);
			if(FPaths::FileExists(AbsolutePath))
			{
				continue;
			}
			if (!bCreate)
			{
				FString DepotPath;
				GetDepotPath(AbsolutePath, DepotPath);
				if(IsCheckedOutByOthers(DepotPath))
				{
					continue;
				}
			}
			return NewRingID;
		}
	}

	if(QuestObj)
	{
		int32 MinQuestID(QuestObj->RingID * 100);
		int32 MaxQuestIDLimit(MinQuestID + 99);
		
		for (size_t Index = MinQuestID; Index < MaxQuestIDLimit; Index++)
		{
			if(!DataEntity->QuestMap.Contains(Index))
			{
				bool bPendingDeleteConflict = false;
				for(auto PendingDeleteObj : DataEntity->PendingDeleteObjects)
				{
					if (PendingDeleteObj.IsValid() && PendingDeleteObj->QuestObjectID == Index)
					{
						bPendingDeleteConflict = true;
						break;
					}
				}
				if(bPendingDeleteConflict)
				{
					continue;
				}
				return Index;
			}
		}
	}
	
	return -100;
}

void FQuestObjectivesEditor::RunBatFile(const FString& BatchFilePath, FString Param)
{
	Async(EAsyncExecution::Thread, [BatchFilePath, Param]()
	{
		// 检查文件是否存在
		if (FPaths::FileExists(BatchFilePath))
		{
			int32 ReturnCode;
			FString Result;
			FString ResultErr;
			bool bProcessSuccess = FPlatformProcess::ExecProcess(*BatchFilePath, *Param, &ReturnCode, &Result, &ResultErr);
			if (bProcessSuccess)
			{
				UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Batch file completed: %s %s"), *BatchFilePath, *Param);
			}
			else
			{
				UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("Failed to start batch file: %s %s"), *BatchFilePath, *Param);
			}
		}
		else
		{
			UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("Batch file not found: %s"), *BatchFilePath);
		}
	});
}

// 由于lazy的机制, 批量保存等逻辑时需要手动加载
void FQuestObjectivesEditor::PreRefreshQuestGraph(UQuest* QuestData)
{
	if(!QuestData || !IsValid(QuestData))
		return ;
	
	if (QuestData->QuestGraph == nullptr)
	{
		CreateQuestGraph(QuestData);

		TSharedPtr<SGraphEditor> _GraphEditor;
		_GraphEditor = SNew(SGraphEditor)
			.GraphToEdit(QuestData->QuestGraph);

		if (UEDGraphBase* EDG = Cast<UEDGraphBase>(QuestData->QuestGraph))
		{
			EDG->QuestObjectivesEditor = this->AsWeak();
			EDG->UserDataObj = QuestData;
			EDG->GraphEditor = _GraphEditor;
		}
		
		LoadQuestGraphNew(QuestData);
		
		
		for (TObjectPtr<class UEdGraphNode>& QuestNode : QuestData->QuestGraph->Nodes)
		{
			if (!QuestNode)
				continue;
			if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
			{
				if (QNode->NodeInstance)
				{
					if (UQuestDataBase* QuestDataBase = Cast<UQuestDataBase>(QNode->NodeInstance))
					{
						QuestDataBase->QuestGraph = QuestData->QuestGraph;
					}
				}
			}
		}
		
		OnRefreshActionStateIdx(QuestData->QuestGraph);
		OnRefreshTargetStateIdx(QuestData->QuestGraph);
	}
}

void FQuestObjectivesEditor::RefreshQuestGraph(UQuest* QuestData)
{
	if(!QuestData || !IsValid(QuestData))
	{
		if (QuestGraphBox)
		{
			QuestGraphBox.Get()->ClearChildren();
		}
		return;
	}
	if (GVarKGQuestUseCheck)
	{
		MarkAssetForCheck(QuestData);
	}

	UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass());
	bool bShowQuestGraph = true;
	if(QuestSettings)
	{
		bShowQuestGraph = QuestSettings->bShowDeprecatedWindow;
	}

	TSharedPtr<SGraphEditor> _GraphEditor;
	if (QuestData)
	{
		bool bInitQuestGraph = false;
		if (QuestData->QuestGraph == nullptr)
		{
			CreateQuestGraph(QuestData);
			bInitQuestGraph = true;
		}

		if (QuestGraph.IsValid())
			QuestGraph->RemoveOnGraphChangedHandler(OnQuestGraphChangedDelegateHandle);
		
		UEdGraph* MyGraph = QuestData->QuestGraph;

		QuestGraph = Cast<UEDGraphBase>(MyGraph);

		if (MyGraph != nullptr)
		{
			QuestGraphEditorCommands = MakeShareable(new FUICommandList);

			QuestGraphEditorCommands->MapAction(FGenericCommands::Get().Delete,
				FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::OnDeleteQuestNode, MyGraph),
				FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CanDeleteQuestNodes)
			);

			QuestGraphEditorCommands->MapAction(FGenericCommands::Get().Copy,
				FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CopySelectedQuestNodes, MyGraph),
				FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CanCopyQuestNodes)
			);

			QuestGraphEditorCommands->MapAction(FGenericCommands::Get().Paste,
				FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::PasteSelectedQuestNodes, MyGraph),
				FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CanPasteQuestNodes)
			);

			SGraphEditor::FGraphEditorEvents InEvents;
			InEvents.OnSelectionChanged = SGraphEditor::FOnSelectionChanged::CreateSP(this, &FQuestObjectivesEditor::OnSelectedQuestNodesChanged);
			InEvents.OnNodeDoubleClicked= FSingleNodeEvent::CreateSP(this, &FQuestObjectivesEditor::OnQuestNodeDoubleClicked);
			InEvents.OnTextCommitted = FOnNodeTextCommitted::CreateSP(this, &FQuestObjectivesEditor::OnNodeTitleCommitted);

			_GraphEditor = SNew(SGraphEditor)
				.GraphToEdit(MyGraph)
				.AdditionalCommands(QuestGraphEditorCommands)
				.GraphEvents(InEvents);

			if (UEDGraphBase* EDG = Cast<UEDGraphBase>(MyGraph))
			{
				EDG->QuestObjectivesEditor = this->AsWeak();
				EDG->UserDataObj = QuestData;
				EDG->GraphEditor = _GraphEditor;
			}
		}
		// Lazy加载Lua层储存的QuestGraph
		if (bInitQuestGraph)
		{
			LoadQuestGraphNew(QuestData);
		}

		if (MyGraph != nullptr)
		{
			for (TObjectPtr<class UEdGraphNode>& QuestNode : MyGraph->Nodes)
			{
				if (!QuestNode)
					continue;
				if (UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode))
				{
					if (QNode->NodeInstance)
					{
						if (UQuestDataBase* QuestDataBase = Cast<UQuestDataBase>(QNode->NodeInstance))
						{
							QuestDataBase->QuestGraph = MyGraph;
						}
					}
				}
			}
		}

		if (QuestGraph.IsValid())
		{
			OnQuestGraphChangedDelegateHandle = QuestGraph->AddOnGraphChangedHandler(
				FOnGraphChanged::FDelegate::CreateRaw(this, &FQuestObjectivesEditor::OnQuestGraphChanged));
		}
	}

	if (QuestGraphBox)
	{
		QuestGraphBox.Get()->ClearChildren();

		if (_GraphEditor)
		{
			QuestGraphBox.Get()->AddSlot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				[
					_GraphEditor.ToSharedRef()
				];
		}

		FString TabName = FString::FromInt(QuestData->QuestID);
		TabName.Append("-");
		TabName.Append(QuestData->QuestName);

		QuestGraphDockTab->SetLabel(FText::FromString(TabName));

		QuestGraphDockTab->ActivateInParent(ETabActivationCause::UserClickedOnTab);
	}

	OnRefreshActionStateIdx(QuestData->QuestGraph);
	OnRefreshTargetStateIdx(QuestData->QuestGraph);
}

void FQuestObjectivesEditor::CreateQuestGraph(UQuest* QuestData)
{
	if (!QuestData || !IsValid(QuestData))
		return;

	if (QuestData)
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("CreateQuestGraph: %d."), QuestData->QuestObjectID);
		
		UEdGraph* MyGraph = QuestData->QuestGraph;

		if (MyGraph == nullptr)
		{
			MyGraph = FBlueprintEditorUtils::CreateNewGraph(QuestData, TEXT("QuestGraph"), UEDGraphBase::StaticClass(), UEventDrivenGraphSchema::StaticClass());

			if (UQuest* GroupQuestTemplate = Cast<UQuest>(QuestData))
			{
				GroupQuestTemplate->QuestGraph = MyGraph;

				FString CurrentPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());

				FString FilePath = CurrentPath + "/Editor/QuestEditor/TemplatePart/QuestDataTemplate.txt";

				if (UEDGraphBase* EDG = Cast<UEDGraphBase>(MyGraph))
				{
					EDG->QuestObjectivesEditor = this->AsWeak();
					EDG->UserDataObj = QuestData;
				}

				FString NodeLuaStr;
				if (FFileHelper::LoadFileToString(NodeLuaStr, *FilePath))
				{
					TSet<UEdGraphNode*> ImportedNodeSet;
					FEdGraphUtilities::ImportNodesFromText(MyGraph, NodeLuaStr, ImportedNodeSet);

					UEDGraphNode_EntryNode* Begin(nullptr);
					UEDGraphNode_StateNode* Progress(nullptr);
					UEDGraphNode_StateNode* End(nullptr);
					for (auto& Elem : ImportedNodeSet)
					{
						if (UEDGraphNode_EntryNode* _Begin = Cast<UEDGraphNode_EntryNode>(Elem))
						{
							Begin = _Begin;
						}
						else if (UEDGraphNode_StateNode* _QuestNode = Cast<UEDGraphNode_StateNode>(Elem))
						{
							if (_QuestNode->NodeType == EDNodeType::QuestProgress)
							{
								Progress = _QuestNode;
							}
							else if (_QuestNode->NodeType == EDNodeType::QuestEnd)
							{
								End = _QuestNode;
							}
						}
					}

					if (Progress && Begin)
					{
						UEdGraphPin* _NextOutPin = Begin->GetNextQuestOutPin();
						if (_NextOutPin)
						{
							Progress->AutowireNewNode(_NextOutPin);
						}

						if (!GroupQuestTemplate->Progress)
						{
							// text加载上来时Progress天然有一个NodeInstance, 这会导致所有Quest公有这一个NodeInstance
							auto ProgressData = NewObject<UQuestProgressBase>(GroupQuestTemplate, TEXT("Progress"));
							Progress->NodeInstance = ProgressData;
							GroupQuestTemplate->Progress = ProgressData;
						}
					}

					if (End && Progress)
					{
						UEdGraphPin* _NextOutPin = Progress->GetNextQuestOutPin();
						if (_NextOutPin)
						{
							End->AutowireNewNode(_NextOutPin);
						}
					}
				}
			}
		}
	}
}

void FQuestObjectivesEditor::RefreshQuestObjectTree()
{
	QuestObjectTreeView->RequestTreeRefresh();
}

void FQuestObjectivesEditor::OnSelectedQuestNodesChanged(const TSet<class UObject*>& NewSelection)
{
	if (NewSelection.Num() == 1)
	{
		for (auto& Elem : NewSelection)
		{
			if (UEDGraphNode_Base* Node = Cast<UEDGraphNode_Base>(Elem))
			{
				UObject* SelectObj = Node->NodeInstance;
				switch (Node->NodeType)
				{
					case EDNodeType::QuestProgress:
						break;
					case EDNodeType::QuestCondition:
						if (UEDGraphNode_Transition* TNode = Cast<UEDGraphNode_Transition>(Node))
						{
							SelectObj = TNode->TransitionCondition;
						}
						break;
					case EDNodeType::QuestAction:
						break;
					case EDNodeType::QuestTarget:
						break;
				}

				PropertyEditor->SetObject(SelectObj);
			}
		}
	}
	else
	{
		PropertyEditor->SetObject(nullptr);
	}
}

bool FQuestObjectivesEditor::CanDeleteQuestNodes() const
{
	return true;
}

void FQuestObjectivesEditor::OnDeleteQuestNode(UEdGraph* InGraph)
{
	if (!IsValid(InGraph))
		return;
		
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnDeleteQuestNode Begin."));

	SGraphEditor* CurrentGraphEditor(nullptr);
	if (UEDGraphBase* EDG = Cast<UEDGraphBase>(InGraph))
	{
		CurrentGraphEditor = EDG->GraphEditor.Pin().Get();
	}
	if (!CurrentGraphEditor)
		return;

	const FScopedTransaction Transaction(FGenericCommands::Get().Delete->GetDescription());
	DataEntity->Modify();
	CurrentGraphEditor->GetCurrentGraph()->Modify();

	const FGraphPanelSelectionSet SelectedNodes = CurrentGraphEditor->GetSelectedNodes();
	CurrentGraphEditor->ClearSelectionSet();
	
	FGraphPanelSelectionSet FilterSelectedNodes;
	
	// 当选中数量大于1时,剔除连线
	for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
	{
		UObject* NodeObj = *NodeIt;
		if (!IsValid(NodeObj) || NodeObj->GetName() == "None")
			continue;
		if (UEDGraphNode_Transition* Node = Cast<UEDGraphNode_Transition>(NodeObj))
		{
			if (SelectedNodes.Num() > 1)
				continue;
		}
		FilterSelectedNodes.Add(NodeObj);
	}

	while (FilterSelectedNodes.Num() > 0)
	{
		UObject* NodeObj = *FilterSelectedNodes.begin();
		if (UEdGraphNode* Node = Cast<UEdGraphNode>(NodeObj))
		{
			if (Node->CanUserDeleteNode())
			{
				FilterSelectedNodes.Remove(NodeObj);
				
				TArray<UEDGraphNode_Base*> DeleteNodes;
				if (UEDGraphNode_Base* ActionNode = Cast<UEDGraphNode_Base>(Node))
				{
					ActionNode->GetOutputTransitionNodes(DeleteNodes, UEDGraphNode_Transition::StaticClass());
					ActionNode->GetInputTransitionNodes(DeleteNodes, UEDGraphNode_Transition::StaticClass());
				}
				for (auto& DeleteNode : DeleteNodes)
				{
					DeleteNode->Modify();
					DeleteNode->DestroyNode();
				}

				Node->Modify();
				Node->DestroyNode();
			}
		}
	}

	OnRefreshActionStateIdx(InGraph);
	OnRefreshTargetStateIdx(InGraph);
	
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnDeleteQuestNode Finish."));
}

void FQuestObjectivesEditor::CopySelectedQuestNodes(class UEdGraph* InGraph)
{
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("CopySelectedQuestNodes Begin."));
	
	if (!IsValid(InGraph))
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("CopySelectedQuestNodes Failed: Invalid graph."));
		return;
	}

	SGraphEditor* CurrentGraphEditor(nullptr);
	if (UEDGraphBase* EDG = Cast<UEDGraphBase>(InGraph))
	{
		CurrentGraphEditor = EDG->GraphEditor.Pin().Get();
	}
	if (!CurrentGraphEditor)
		return;

	FGraphPanelSelectionSet SelectedNodes = CurrentGraphEditor->GetSelectedNodes();

	FString ExportedText;

	FEdGraphUtilities::ExportNodesToText(SelectedNodes, ExportedText);
	FPlatformApplicationMisc::ClipboardCopy(*ExportedText);

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("CopySelectedQuestNodes Finish."));
}

bool FQuestObjectivesEditor::CanCopyQuestNodes() const
{
	return true;
}

void FQuestObjectivesEditor::PasteSelectedQuestNodes(class UEdGraph* InGraph)
{
	if (!IsValid(InGraph))
		return;

	SGraphEditor* CurrentGraphEditor(nullptr);
	if (UEDGraphBase* EDG = Cast<UEDGraphBase>(InGraph))
	{
		CurrentGraphEditor = EDG->GraphEditor.Pin().Get();
	}
	if (!CurrentGraphEditor)
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("PasteSelectedQuestNodes failed: Invilid CurrentGraphEditor."));
		return;
	}

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("PasteSelectedQuestNodes Begin."));

	FString ImportedText;
	FPlatformApplicationMisc::ClipboardPaste(ImportedText);
	
	TSet<UEdGraphNode*> ImportedNodeSet;
	FEdGraphUtilities::ImportNodesFromText(InGraph, ImportedText, ImportedNodeSet);	
	
	//Average position of nodes so we can move them while still maintaining relative distances to each other
	FVector2D AvgNodePosition(0.0f, 0.0f);
	for (TSet<UEdGraphNode*>::TIterator It(ImportedNodeSet); It; ++It)
	{
		const UEdGraphNode* Node = *It;
		AvgNodePosition.X += Node->NodePosX;
		AvgNodePosition.Y += Node->NodePosY;
	}

	if (ImportedNodeSet.Num() > 0)
	{
		const float InvNumNodes = 1.0f / float(ImportedNodeSet.Num());
		AvgNodePosition.X *= InvNumNodes;
		AvgNodePosition.Y *= InvNumNodes;
	}
	
	for (TSet<UEdGraphNode*>::TIterator It(ImportedNodeSet); It; ++It)
	{
		UEdGraphNode* Node = *It;

		// Select the newly pasted stuff
		CurrentGraphEditor->SetNodeSelection(Node, true);
		Node->NodePosX = (Node->NodePosX - AvgNodePosition.X) + CurrentGraphEditor->GetPasteLocation().X;
		Node->NodePosY = (Node->NodePosY - AvgNodePosition.Y) + CurrentGraphEditor->GetPasteLocation().Y;
		Node->SnapToGrid(SNodePanel::GetSnapGridSize());

		// Give new node a different Guid from the old one
		Node->CreateNewGuid();
	}

	// Update UI
	CurrentGraphEditor->NotifyGraphChanged();

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("PasteSelectedQuestNodes End."));
}

bool FQuestObjectivesEditor::CanPasteQuestNodes() const
{
	return true;
}

// 由于lazy的机制, 批量保存等逻辑时需要手动加载
void FQuestObjectivesEditor::PreRefreshRingGraph(UQuestRing* RingData)
{
	
	if (!RingData || !IsValid(RingData))
		return;

	bLoadingRingGraph = true;
	if (RingData->RingGraph == nullptr)
	{
		RingData->RingGraph = FBlueprintEditorUtils::CreateNewGraph(RingData, TEXT("RingGraph"), UEDGraphBase::StaticClass(), UEventDrivenGraphSchema::StaticClass());
		
		TSharedPtr<SGraphEditor> _GraphEditor = SNew(SGraphEditor)
				.GraphToEdit(RingData->RingGraph);

		if (UEDGraphBase* EDG = Cast<UEDGraphBase>(RingData->RingGraph))
		{
			EDG->QuestObjectivesEditor = this->AsWeak();
			EDG->GraphEditor = _GraphEditor;
		}
		
		// Lazy加载Lua层储存的RingGraph
		LoadRingGraph(RingData);

		if (UEDGraphBase* EDG = Cast<UEDGraphBase>(RingData->RingGraph))
		{
			EDG->QuestObjectivesEditor = this->AsWeak();
		}
	}
	bLoadingRingGraph = false;
}

void FQuestObjectivesEditor::RefreshRingGraph(UQuestRing* RingData, bool bMarkCheck)
{
	if (!RingData || !IsValid(RingData))
	{
		if (RingGraphBox)
		{
			RingGraphBox.Get()->ClearChildren();
		}
		return;
	}

	if (GVarKGQuestUseCheck && bMarkCheck)
	{
		MarkAssetForCheck(RingData);
	}

	//if (TabManager.IsValid() && (!RingGraphDockTab.IsValid() || !RingGraphDockTab->IsActive()))
	//{
	//	TabManager->TryInvokeTab(FQuestObjectivesEditorTabs::RingGraphID, true);
	//}
	
	if (!TabManager->FindExistingLiveTab(FQuestObjectivesEditorTabs::RingGraphID))
	{
		SpawnTab_RingGraph(FSpawnTabArgs(nullptr, FQuestObjectivesEditorTabs::RingGraphID));

		RingGraphDockTab = TabManager->TryInvokeTab(FQuestObjectivesEditorTabs::RingGraphID);
	}
	
	bLoadingRingGraph = true;
	TSharedPtr<SGraphEditor> _GraphEditor;
	if (RingData)
	{
		bool bInitRingGraph = false;
		UEdGraph* MyGraph = RingData->RingGraph;
		if (MyGraph == nullptr || !IsValid(MyGraph->Schema))
		{
			MyGraph = FBlueprintEditorUtils::CreateNewGraph(RingData, TEXT("RingGraph"), UEDGraphBase::StaticClass(), UEventDrivenGraphSchema::StaticClass());
			RingData->RingGraph = MyGraph;
			bInitRingGraph = true;
		}
		
		{
			RingGraphEditorCommands = MakeShareable(new FUICommandList);

			RingGraphEditorCommands->MapAction(FGenericCommands::Get().Delete,
				FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::OnDeleteNode, MyGraph),
				FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CanDeleteNodes)
			);
			
			RingGraphEditorCommands->MapAction(FGenericCommands::Get().Copy,
				FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::OnCopyNode, MyGraph),
				FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CanCopyNodes)
			);

			RingGraphEditorCommands->MapAction(FGenericCommands::Get().Paste,
				FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::OnPasteNode, MyGraph),
				FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CanPasteQuestNode)
			);
		}

		SGraphEditor::FGraphEditorEvents InEvents;
		InEvents.OnSelectionChanged = SGraphEditor::FOnSelectionChanged::CreateSP(this, &FQuestObjectivesEditor::OnSelectedRingNodesChanged);
		InEvents.OnNodeDoubleClicked = FSingleNodeEvent::CreateSP(this, &FQuestObjectivesEditor::OnRingNodeDoubleClicked);
		InEvents.OnTextCommitted = FOnNodeTextCommitted::CreateSP(this, &FQuestObjectivesEditor::OnNodeTitleCommitted);

		_GraphEditor = SNew(SGraphEditor)
						.GraphToEdit(MyGraph)
						.AdditionalCommands(RingGraphEditorCommands)
						.GraphEvents(InEvents);

		if (UEDGraphBase* EDG = Cast<UEDGraphBase>(MyGraph))
		{
			EDG->QuestObjectivesEditor = this->AsWeak();
			EDG->GraphEditor = _GraphEditor;
		}

		if (RingGraph.IsValid())
			RingGraph->RemoveOnGraphChangedHandler(OnRingGraphChangedDelegateHandle);
		
		RingGraph = Cast<UEDGraphBase>(MyGraph);

		// Lazy加载Lua层储存的RingGraph
		if (bInitRingGraph)
		{
			LoadRingGraph(RingData);
		}

		if (RingGraph.IsValid())
		{
			OnRingGraphChangedDelegateHandle = RingGraph->AddOnGraphChangedHandler(
				FOnGraphChanged::FDelegate::CreateRaw(this, &FQuestObjectivesEditor::OnRingGraphChanged));
		}
	}

	if (RingGraphBox)
	{
		RingGraphBox.Get()->ClearChildren();

		if (_GraphEditor)
		{
			RingGraphBox.Get()->AddSlot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				[
					_GraphEditor.ToSharedRef()
				];
		}

		FString TabName = FString::FromInt(RingData->RingID);
		TabName.Append("-");
		TabName.Append(RingData->RingName);

		RingGraphDockTab->SetLabel(FText::FromString(TabName));

		RingGraphDockTab->ActivateInParent(ETabActivationCause::UserClickedOnTab);
	}

	bLoadingRingGraph = false;
}

void FQuestObjectivesEditor::OnSelectedRingNodesChanged(const TSet<class UObject*>& NewSelection)
{
	if (NewSelection.Num() == 1)
	{
		for (auto& Elem : NewSelection)
		{
			if (UEDGraphNode_Base* Node = Cast<UEDGraphNode_Base>(Elem))
			{
				UObject* SelectNode = Node->NodeInstance;
				switch (Node->NodeType)
				{
				case EDNodeType::RingQuest:
					if (!Node->NodeInstance && !Node->NodePath.IsEmpty())
					{
						FSoftObjectPath ObjectRef(Node->NodePath);
						UObject* LoadedObj = ObjectRef.TryLoad();
						if (LoadedObj)
						{
							Node->NodeInstance = LoadedObj;
						}
					}
					OnRingNodeDoubleClicked(Node);
					SelectNode = Node->NodeInstance;
					break;
				case EDNodeType::RingQuestCondition:
					if (UEDGraphNode_Transition* TNode = Cast<UEDGraphNode_Transition>(Node))
					{
						int32 NextTaskID(-1);

						UEdGraphPin* NextTToPin = TNode->GetOutputPin();
						if (NextTToPin)
						{
							TArray<UEdGraphPin*> NextTToPin_LinkTos = NextTToPin->LinkedTo;
							for (UEdGraphPin* NextTToPin_ToPin : NextTToPin_LinkTos)
							{
								if (NextTToPin_ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
								{
									UEdGraphNode* ToNode = NextTToPin_ToPin->GetOwningNodeUnchecked();
									if (UEDGraphNode_StateNode* ToQuest = Cast<UEDGraphNode_StateNode>(ToNode))
									{
										if (UQuest* NextQuestData = Cast<UQuest>(ToQuest->NodeInstance))
										{
											NextTaskID = NextQuestData->QuestID;
										}
									}
								}
							}
						}

						if (UEdGraphPin* InPin = TNode->GetInputPin())
						{
							TArray<UEdGraphPin*> InPins = InPin->LinkedTo;
							for (UEdGraphPin* FromPin : InPins)
							{
								if (FromPin->Direction == EEdGraphPinDirection::EGPD_Output)
								{
									UEdGraphNode* F_Node = FromPin->GetOwningNodeUnchecked();

									if (UEDGraphNode_StateNode* FromQuest = Cast<UEDGraphNode_StateNode>(F_Node))
									{
										if (UQuest* FromQuestData = Cast<UQuest>(FromQuest->NodeInstance))
										{
											for (URingTaskConditionBase* NextTaskCon : FromQuestData->NextTaskInfoList)
											{
												if (IsValid(NextTaskCon) && NextTaskCon->NextTaskID == NextTaskID)
												{
													SelectNode = NextTaskCon;
												}
											}
										}
									}
								}
							}
						}

					}
					break;
				}

				PropertyEditor->SetObject(SelectNode);
			}
		}
	}
	else
	{
		PropertyEditor->SetObject(nullptr);
	}
}

void FQuestObjectivesEditor::OnRingNodeDoubleClicked(UEdGraphNode* InNode)
{
	if(!InNode)
		return ;

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnRingNodeDoubleClicked Begin."));

	if (UEDGraphNode_Base* Node = Cast<UEDGraphNode_Base>(InNode))
	{
		for (auto& QuestItem : DataEntity->QuestListItems)
		{
			if (IsValid(QuestItem) && IsValid(QuestItem.Get()) && QuestItem.Get() == Node->NodeInstance)
			{
				QuestListView->ClearSelection();
				QuestListView->SetItemSelection(QuestItem, true, ESelectInfo::Direct);
				OnQuestListItemClicked(QuestItem);
				break;
			}
		}
	}
}

bool FQuestObjectivesEditor::CanDeleteNodes() const
{
	return true;
}

void FQuestObjectivesEditor::OnDeleteNode(UEdGraph* InGraph)
{
	if(!IsValid(InGraph))
		return ;

	SGraphEditor* CurrentGraphEditor(nullptr);
	if (UEDGraphBase* EDG = Cast<UEDGraphBase>(InGraph))
	{
		CurrentGraphEditor = EDG->GraphEditor.Pin().Get();
	}
	if(!CurrentGraphEditor)
		return ;

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnDeleteNode Begin."));

	const FScopedTransaction Transaction(FGenericCommands::Get().Delete->GetDescription());
	CurrentGraphEditor->GetCurrentGraph()->Modify();
	DataEntity->Modify();

	const FGraphPanelSelectionSet SelectedNodes = CurrentGraphEditor->GetSelectedNodes();
	CurrentGraphEditor->ClearSelectionSet();

	FGraphPanelSelectionSet FilterSelectedNodes;

	// 当选中数量大于1时,剔除连线
	for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
	{
		UObject* NodeObj = *NodeIt;
		if (!IsValid(NodeObj) || NodeObj->GetName() == "None")
			continue;
		if (UEDGraphNode_Transition* Node = Cast<UEDGraphNode_Transition>(NodeObj))
		{
			if (SelectedNodes.Num() > 1)
				continue;
		}
		FilterSelectedNodes.Add(NodeObj);
	}

	bool bRefresh(false);
	while (FilterSelectedNodes.Num() > 0)
	{
		UObject* NodeObj = *FilterSelectedNodes.begin();
		if (UEdGraphNode* Node = Cast<UEdGraphNode>(NodeObj))
		{
			if (Node->CanUserDeleteNode())
			{
				FilterSelectedNodes.Remove(NodeObj);

				if (UEDGraphNode_Base* EDNode = Cast<UEDGraphNode_Base>(Node))
				{
					// 是连线,那么直接删除自身
					if (UEDGraphNode_Transition* TransitionNode = Cast<UEDGraphNode_Transition>(EDNode))
					{
						UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnDeleteTransitionNode."));
						
						Node->Modify();

						OnDeleteTransitionNode(TransitionNode);

						Node->DestroyNode();
					}
					// 是节点,会删除自己和两边的连线,这也是为什么当选中数量大于1时,需要剔除连线
					else if (EDNode->NodeInstance)
					{
						UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnDeleteNodeInstance."));
						
						if (UQuest* Quest = Cast<UQuest>(EDNode->NodeInstance))
						{
							Quest->Modify();
							if (DeleteQuest(Quest))
							{
								bRefresh = true;
							}
						}else if(UQuestRing* Ring = Cast<UQuestRing>(EDNode->NodeInstance))
						{
							Ring->Modify();
							if(DeleteRing(Ring))
							{
								bRefresh = true;
							}
						}
						else if(UChapterEnd* End = Cast<UChapterEnd>(EDNode->NodeInstance))
						{
							End->Modify();
							if(DeleteChapterEnd(End))
							{
								bRefresh = true;
							}
						}
					}
				}
				// 是评论,那么直接删除自身
				else
				{
					UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnDeleteNodeSelf. Maybe Comment Node."));
					
					Node->Modify();
					Node->DestroyNode();
				}
			}
		}
	}
	if (bRefresh)
	{
		OnRefresh(false);
	}

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnDeleteNode End."));
}

void FQuestObjectivesEditor::OnCopyNode(UEdGraph* InGraph)
{
	// Export the selected nodes and place the text on the clipboard

	if(!IsValid(InGraph))
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("OnCopyNode failed: Invalid Graph."));
		return ;
	}

	SGraphEditor* CurrentGraphEditor(nullptr);
	if (UEDGraphBase* EDG = Cast<UEDGraphBase>(InGraph))
	{
		CurrentGraphEditor = EDG->GraphEditor.Pin().Get();
	}
	if(!CurrentGraphEditor)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("OnCopyNode failed: Invalid CurrentGraphEditor."));
		return ;
	}

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnCopyNode Begin."));

	const FScopedTransaction Transaction(FGenericCommands::Get().Delete->GetDescription());
	CurrentGraphEditor->GetCurrentGraph()->Modify();
	DataEntity->Modify();
	DataEntity->PasteBuffer.Empty();
	
	const FGraphPanelSelectionSet SelectedNodes = CurrentGraphEditor->GetSelectedNodes();

	FString ExportedText;
	for (FGraphPanelSelectionSet::TConstIterator SelectedIter(SelectedNodes); SelectedIter; ++SelectedIter)
	{
		if (UEDGraphNode_Base* Node = Cast<UEDGraphNode_Base>(*SelectedIter))
		{
			Node->PrepareForCopying();
			if(auto QuestNodeContent = Cast<UQuestObject>(Node->NodeInstance))
			{
				UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnCopyNode QuestObjectID: %d."), QuestNodeContent->QuestObjectID);
				DataEntity->PasteBuffer.Add(DeepCopyQuestObject(QuestNodeContent));
			}
		}
	}
	FEdGraphUtilities::ExportNodesToText(SelectedNodes, /*out*/ ExportedText);
	FPlatformApplicationMisc::ClipboardCopy(*ExportedText);

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnCopyNode End."));
}

void FQuestObjectivesEditor::OnPasteNode(UEdGraph* InGraph)
{
	if (!IsValid(InGraph))
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("OnPasteNode failed: Invalid Graph."));
		return;
	}
	
	SGraphEditor* CurrentGraphEditor(nullptr);
	if (UEDGraphBase* EDG = Cast<UEDGraphBase>(InGraph))
	{
		CurrentGraphEditor = EDG->GraphEditor.Pin().Get();
	}
	if (!CurrentGraphEditor)
	{
		UE_LOG(LogQuestObjectivesEditor, Warning, TEXT("OnPasteNode failed: Invalid CurrentGraphEditor."));
		return;
	}

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnPasteNode Begin."));

	const FScopedTransaction Transaction(FGenericCommands::Get().Paste->GetDescription());
	DataEntity->Modify();
	CurrentGraphEditor->GetCurrentGraph()->Modify();
	
	FString ImportedText;
	FPlatformApplicationMisc::ClipboardPaste(ImportedText);
	
	TSet<UEdGraphNode*> ImportedNodeSet;
	FEdGraphUtilities::ImportNodesFromText(InGraph, ImportedText, ImportedNodeSet);	
	
	//Average position of nodes so we can move them while still maintaining relative distances to each other
	FVector2D AvgNodePosition(0.0f, 0.0f);
	for (TSet<UEdGraphNode*>::TIterator It(ImportedNodeSet); It; ++It)
	{
		const UEdGraphNode* Node = *It;
		AvgNodePosition.X += Node->NodePosX;
		AvgNodePosition.Y += Node->NodePosY;
	}

	if (ImportedNodeSet.Num() > 0)
	{
		const float InvNumNodes = 1.0f / float(ImportedNodeSet.Num());
		AvgNodePosition.X *= InvNumNodes;
		AvgNodePosition.Y *= InvNumNodes;
	}
	
	UQuestObject* SelectedObj = nullptr;
	auto SelectedChapters = QuestObjectTreeView->GetSelectedItems();
	if(SelectedChapters.Num()>0)
	{
		SelectedObj = SelectedChapters[0];
	}
	DataEntity->Modify();
	DataEntity->CopiedMapping.Empty();
	DataEntity->RevCopiedMapping.Empty();

	FText ConfirmText = FText(LOCTEXT("Paste Keep ID", "Do you want to keep suffix of Quest node copied?"));
	EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, ConfirmText);
	bool bKeepID = false;
	if(ReturnType == EAppReturnType::Yes)
	{
		bKeepID = true;
	}
	TArray<TObjectPtr<UQuestObject>> PasteObjs;
	for(int i = 0; i < DataEntity->PasteBuffer.Num(); i++)
	{
		UQuestObject* QuestObj = nullptr;
		QuestObj = DeepCopyQuestObject(DataEntity->PasteBuffer[i], true);
		if(auto SelectedChapter = Cast<UQuestChapter>(SelectedObj))
		{
			QuestObj->QuestType = SelectedChapter->QuestType;
		}
		if(auto RingObj = Cast<UQuestRing>(QuestObj))
		{
			RingObj->Father = SelectedObj;
			SelectedObj->Children.AddUnique(RingObj);
		}
		if(auto Quest = Cast<UQuest>(QuestObj))
		{
			Quest->Father = GetSelectedRing();
			Quest->Father->Children.AddUnique(Quest);
		}
		ReAllocateQuestObjectID(QuestObj, bKeepID);
		PasteObjs.Add(QuestObj);
	}

	// Deal with nextinfo
	for(int i = 0; i < PasteObjs.Num(); i++)
	{
		UQuestObject* Obj = nullptr;
		Obj = PasteObjs[i];
		if(auto RingObj = Cast<UQuestRing>(Obj))
		{
			for(auto NextInfo : RingObj->NextTaskInfoList)
			{
				if(NextInfo && DataEntity->RevCopiedMapping.Contains(NextInfo->NextTaskID))
				{
					NextInfo->NextTaskID = DataEntity->RevCopiedMapping[NextInfo->NextTaskID];
				}
			}
			PreRefreshRingGraph(RingObj);
		}
		if(auto QuestObj = Cast<UQuest>(Obj))
		{
			for (int32 NextInfoIndex = QuestObj->NextTaskInfoList.Num() - 1; NextInfoIndex >= 0; NextInfoIndex--)
			{
				URingTaskConditionBase* NextInfo = QuestObj->NextTaskInfoList[NextInfoIndex];
				if(NextInfo && DataEntity->RevCopiedMapping.Contains(NextInfo->NextTaskID))
				{
					NextInfo->NextTaskID = DataEntity->RevCopiedMapping[NextInfo->NextTaskID];
				}
				else
				{
					// 原来指向的下一个的节点没有一同被复制，需要清理掉对应的 NextInfo
					QuestObj->NextTaskInfoList.RemoveAt(NextInfoIndex);
				}
			}
			PreRefreshQuestGraph(QuestObj);
		}
	}
	
	for (TSet<UEdGraphNode*>::TIterator It(ImportedNodeSet); It; ++It)
	{
		UEdGraphNode* Node = *It;

		// Select the newly pasted stuff
		CurrentGraphEditor->SetNodeSelection(Node, true);
		Node->NodePosX = (Node->NodePosX - AvgNodePosition.X) + CurrentGraphEditor->GetPasteLocation().X;
		Node->NodePosY = (Node->NodePosY - AvgNodePosition.Y) + CurrentGraphEditor->GetPasteLocation().Y;
		Node->SnapToGrid(SNodePanel::GetSnapGridSize());

		// Give new node a different Guid from the old one
		Node->CreateNewGuid();
		
		if(auto BaseNode = Cast<UEDGraphNode_Base>(Node))
		{
			if(auto NodeQuestObject = Cast<UQuestObject>(BaseNode->NodeInstance))
			{
				if(DataEntity->RevCopiedMapping.Contains(NodeQuestObject->QuestObjectID))
				{
					auto NewID = DataEntity->RevCopiedMapping[NodeQuestObject->QuestObjectID];
					for(auto CopiedIns : PasteObjs)
					{
						if (CopiedIns->QuestObjectID == NewID)
						{
							BaseNode->NodeInstance = CopiedIns;
						}
					}
				}
			}
		}

		Node->PostPasteNode();
	}
	
	QuestObjectTreeRefresh(true);
	// Update UI
	CurrentGraphEditor->NotifyGraphChanged();

	PropertyEditor->SetObject(nullptr);

	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnPasteNode End."));
}

void FQuestObjectivesEditor::OnDeleteTransitionNode(UEDGraphNode_Transition* TransitionNode)
{
	// 还需要改 PreRingID
	if (UEdGraphPin* OutputPin = TransitionNode->GetOutputPin())
	{
		for (UEdGraphPin* GraphStateNodePin : OutputPin->LinkedTo)
		{
			if (auto GraphStateNode = Cast<UEDGraphNode_Base>(GraphStateNodePin->GetOwningNode()))
			{
				if (auto QuestRingToChangePreID = Cast<UQuestRing>(GraphStateNode->NodeInstance))
				{
					if (auto PreRingID = Cast<UPreRingID>(QuestRingToChangePreID->PreRingRelations))
					{
						// 连线被删，清掉指向节点的 PreRingID
						QuestRingToChangePreID->Modify();
						QuestRingToChangePreID->PreRingRelations = nullptr;
					}
				}
			}
		}
	}

	// 改 NextTaskInfoList
	TransitionNode->Modify();

	UEDGraphNode_Base* State1 = TransitionNode->GetFromState();
	UEDGraphNode_Base* State2 = TransitionNode->GetToState();
	if (State1 && State1->NodeInstance && IsValid(State1->NodeInstance))
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnDeleteTransitionNode: %s %s"), *State1->NodeName, *State2->NodeName);
		
		if (UQuest* Quest1 = Cast<UQuest>(State1->NodeInstance))
		{
			if (State2 && !State2->NodeName.IsEmpty())
			{
				// ToState指向的节点可能已经被销毁, 不一定有NodeInstance, 这里用NodeName来查询
				URingTaskConditionBase* SelectNode = nullptr;
				for (URingTaskConditionBase* NextTaskCon : Quest1->NextTaskInfoList)
				{
					if (IsValid(NextTaskCon) && State2->NodeName.StartsWith(FString::FromInt(NextTaskCon->NextTaskID)))
					{
						SelectNode = NextTaskCon;
						break;
					}
				}
				if (SelectNode)
				{
					Quest1->Modify();
					Quest1->NextTaskInfoList.Remove(SelectNode);
					// todo LuaVersion
					UPackage* QuestDataPackage = Quest1->GetPackage();
					if (QuestDataPackage) QuestDataPackage->SetDirtyFlag(true);
					Quest1->NextTaskInfoNotifyQuestEditor();
				}
			}
		}
		else if (UQuestRing* Ring = Cast<UQuestRing>(State1->NodeInstance))
		{
			if (State2 && !State2->NodeName.IsEmpty())
			{
				// ToState指向的节点可能已经被销毁, 不一定有NodeInstance, 这里用NodeName来查询
				URingTaskConditionBase* SelectNode = nullptr;
				for (URingTaskConditionBase* NextTaskCon : Ring->NextTaskInfoList)
				{
					if (IsValid(NextTaskCon) && State2->NodeName.StartsWith(FString::FromInt(NextTaskCon->NextTaskID)))
					{
						SelectNode = NextTaskCon;
						break;
					}
				}
				if (SelectNode)
				{
					Ring->Modify();
					Ring->NextTaskInfoList.Remove(SelectNode);
					// todo LuaVersion
					UPackage* QuestDataPackage = Ring->GetPackage();
					if (QuestDataPackage) QuestDataPackage->SetDirtyFlag(true);
					Ring->NextTaskInfoNotifyQuestEditor();
				}
			}
		}
	}
}

void FQuestObjectivesEditor::PreRefreshChapterGraph(UQuestChapter* ChapterData)
{
	if (!ChapterData || !IsValid(ChapterData))
		return;

	bLoadingChapterGraph = true;
	if (ChapterData->ChapterGraph == nullptr)
	{
		ChapterData->ChapterGraph = FBlueprintEditorUtils::CreateNewGraph(ChapterData, TEXT("ChapterGraph"), UEDGraphBase::StaticClass(), UEventDrivenGraphSchema::StaticClass());
		
		TSharedPtr<SGraphEditor> _GraphEditor = SNew(SGraphEditor)
				.GraphToEdit(ChapterData->ChapterGraph);

		if (UEDGraphBase* EDG = Cast<UEDGraphBase>(ChapterData->ChapterGraph))
		{
			EDG->QuestObjectivesEditor = this->AsWeak();
			EDG->GraphEditor = _GraphEditor;
		}
		
		// Lazy加载Lua层储存的ChapterGraph
		LoadChapterGraph(ChapterData);

		if (UEDGraphBase* EDG = Cast<UEDGraphBase>(ChapterData->ChapterGraph))
		{
			EDG->QuestObjectivesEditor = this->AsWeak();
		}
	}
	bLoadingChapterGraph = false;
}

void FQuestObjectivesEditor::RefreshChapterGraph(UQuestChapter* ChapterData)
{
	if (!ChapterData || !IsValid(ChapterData))
	{
		if (ChapterGraphBox)
		{
			ChapterGraphBox.Get()->ClearChildren();
		}
		return;
	}

	if (GVarKGQuestUseCheck)
	{
		MarkAssetForCheck(ChapterData);
	}

	//if (TabManager.IsValid() && (!RingGraphDockTab.IsValid() || !RingGraphDockTab->IsActive()))
	//{
	//	TabManager->TryInvokeTab(FQuestObjectivesEditorTabs::RingGraphID, true);
	//}

	bLoadingChapterGraph = true;
	if (!TabManager->FindExistingLiveTab(FQuestObjectivesEditorTabs::ChapterGraphID))
	{
		SpawnTab_ChapterGraph(FSpawnTabArgs(nullptr, FQuestObjectivesEditorTabs::ChapterGraphID));

		ChapterGraphDockTab = TabManager->TryInvokeTab(FQuestObjectivesEditorTabs::ChapterGraphID);
	}

	TSharedPtr<SGraphEditor> _GraphEditor;
	if (ChapterData)
	{
		bool bInitGraph = false;
		UEdGraph* MyGraph = ChapterData->ChapterGraph;
		if (MyGraph == nullptr)
		{
			MyGraph = FBlueprintEditorUtils::CreateNewGraph(ChapterData, TEXT("ChapterGraph"), UEDGraphBase::StaticClass(), UEventDrivenGraphSchema::StaticClass());
			ChapterData->ChapterGraph = MyGraph;
			bInitGraph = true;
		}
		
		{
			ChapterGraphEditorCommands = MakeShareable(new FUICommandList);

			ChapterGraphEditorCommands->MapAction(FGenericCommands::Get().Delete,
				FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::OnDeleteNode, MyGraph),
				FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CanDeleteNodes)
			);

			ChapterGraphEditorCommands->MapAction(FGenericCommands::Get().Copy,
				FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::OnCopyNode, MyGraph),
				FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CanCopyNodes)
			);

			ChapterGraphEditorCommands->MapAction(FGenericCommands::Get().Paste,
				FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::OnPasteNode, MyGraph),
				FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::CanPasteRingNode)
			);
		}

		SGraphEditor::FGraphEditorEvents InEvents;
		InEvents.OnSelectionChanged = SGraphEditor::FOnSelectionChanged::CreateSP(this, &FQuestObjectivesEditor::OnSelectedChapterNodesChanged);
		InEvents.OnNodeDoubleClicked = FSingleNodeEvent::CreateSP(this, &FQuestObjectivesEditor::OnChapterNodeDoubleClicked);
		InEvents.OnTextCommitted = FOnNodeTextCommitted::CreateSP(this, &FQuestObjectivesEditor::OnNodeTitleCommitted);

		_GraphEditor = SNew(SGraphEditor)
						.GraphToEdit(MyGraph)
						.AdditionalCommands(ChapterGraphEditorCommands)
						.GraphEvents(InEvents);

		if (UEDGraphBase* EDG = Cast<UEDGraphBase>(MyGraph))
		{
			EDG->QuestObjectivesEditor = this->AsWeak();
			EDG->GraphEditor = _GraphEditor;
		}
		
		if (ChapterGraph.IsValid())
			ChapterGraph->RemoveOnGraphChangedHandler(OnRingGraphChangedDelegateHandle);
		
		ChapterGraph = Cast<UEDGraphBase>(MyGraph);

		// Lazy加载Lua层储存的ChapterGraph
		if (bInitGraph)
		{
			LoadChapterGraph(ChapterData);
		}
		
		if (ChapterGraph.IsValid())
		{
			OnChapterGraphChangedDelegateHandle = ChapterGraph->AddOnGraphChangedHandler(
				FOnGraphChanged::FDelegate::CreateRaw(this, &FQuestObjectivesEditor::OnChapterGraphChanged));
		}
	}

	if (ChapterGraphBox)
	{
		ChapterGraphBox.Get()->ClearChildren();

		if (_GraphEditor)
		{
			ChapterGraphBox.Get()->AddSlot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				[
					_GraphEditor.ToSharedRef()
				];
		}

		FString TabName = FString::FromInt(ChapterData->ChapterID);
		TabName.Append("-");
		TabName.Append(ChapterData->ChapterName);

		ChapterGraphDockTab->SetLabel(FText::FromString(TabName));

		ChapterGraphDockTab->ActivateInParent(ETabActivationCause::UserClickedOnTab);
	}
	bLoadingChapterGraph = false;
}

void FQuestObjectivesEditor::OnSelectedChapterNodesChanged(const TSet<UObject*>& NewSelection)
{
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnSelectedChapterNodesChanged Begin."));
	if (NewSelection.Num() == 1)
	{
		for (auto& Elem : NewSelection)
		{
			if (UEDGraphNode_Base* Node = Cast<UEDGraphNode_Base>(Elem))
			{
				UObject* SelectNode = Node->NodeInstance;
				switch (Node->NodeType)
				{
				case EDNodeType::ChapterRing:
					if (!Node->NodeInstance && !Node->NodePath.IsEmpty())
					{
						FSoftObjectPath ObjectRef(Node->NodePath);
						UObject* LoadedObj = ObjectRef.TryLoad();
						if (LoadedObj)
						{
							Node->NodeInstance = LoadedObj;
						}
					}
					if(auto RingItem = Cast<UQuestRing>(Node->NodeInstance))
					{
						RingListView->ClearSelection();
						RingListView->SetItemSelection(RingItem, true, ESelectInfo::Direct);
						UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnSelectedChapterNodesChanged: Select %d."), RingItem->RingID);
						OnRingListItemClicked(RingItem);
					}
					SelectNode = Node->NodeInstance;
					break;
				case EDNodeType::ChapterRingCondition:
					if (UEDGraphNode_Transition* TNode = Cast<UEDGraphNode_Transition>(Node))
					{
						int32 NextTaskID(-1);

						UEdGraphPin* NextTToPin = TNode->GetOutputPin();
						if (NextTToPin)
						{
							TArray<UEdGraphPin*> NextTToPin_LinkTos = NextTToPin->LinkedTo;
							for (UEdGraphPin* NextTToPin_ToPin : NextTToPin_LinkTos)
							{
								if (NextTToPin_ToPin->Direction == EEdGraphPinDirection::EGPD_Input)
								{
									UEdGraphNode* ToNode = NextTToPin_ToPin->GetOwningNodeUnchecked();
									if (UEDGraphNode_StateNode* ToQuest = Cast<UEDGraphNode_StateNode>(ToNode))
									{
										if (UQuestRing* NextQuestData = Cast<UQuestRing>(ToQuest->NodeInstance))
										{
											NextTaskID = NextQuestData->RingID;
										}
										if(UChapterEnd* ChapterEndData = Cast<UChapterEnd>(ToQuest->NodeInstance))
										{
											NextTaskID = ChapterEndData->NextRingID;
										}
									}
								}
							}
						}

						UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnSelectedChapterNodesChanged: Select ChapterRingCondition. NextTaskID: %d."), NextTaskID);


						if (UEdGraphPin* InPin = TNode->GetInputPin())
						{
							TArray<UEdGraphPin*> InPins = InPin->LinkedTo;
							for (UEdGraphPin* FromPin : InPins)
							{
								if (FromPin->Direction == EEdGraphPinDirection::EGPD_Output)
								{
									UEdGraphNode* F_Node = FromPin->GetOwningNodeUnchecked();

									if (UEDGraphNode_StateNode* FromQuest = Cast<UEDGraphNode_StateNode>(F_Node))
									{
										if (UQuestRing* FromQuestData = Cast<UQuestRing>(FromQuest->NodeInstance))
										{
											for (URingTaskConditionBase* NextTaskCon : FromQuestData->NextTaskInfoList)
											{
												if (IsValid(NextTaskCon) && NextTaskCon->NextTaskID == NextTaskID)
												{
													SelectNode = NextTaskCon;
												}
											}
										}
									}
								}
							}
						}
					}
					break;
				}

				PropertyEditor->SetObject(SelectNode);
			}
		}
	}
	else
	{
		UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnSelectedChapterNodesChanged Sellect nullptr."));
		PropertyEditor->SetObject(nullptr);
	}
}

void FQuestObjectivesEditor::OnChapterNodeDoubleClicked(UEdGraphNode* InNode)
{
	if(!InNode)
		return ;

	if (UEDGraphNode_Base* Node = Cast<UEDGraphNode_Base>(InNode))
	{
		if(auto EndNode = Cast<UChapterEnd>(Node->NodeInstance))
		{
			FString SearchText = FString::FromInt(EndNode->NextRingID);
			OnSearchTextCommitted(FText::FromString(SearchText) , ETextCommit::Type::OnEnter);
		}
		for (auto& RingItem : DataEntity->RingListItems)
		{
			if (IsValid(RingItem) && IsValid(RingItem.Get()) && RingItem.Get() == Node->NodeInstance)
			{
				RingListView->ClearSelection();
				RingListView->SetItemSelection(RingItem, true, ESelectInfo::Direct);
				OnRingListItemClicked(RingItem);
				break;
			}
		}
	}
}

void FQuestObjectivesEditor::OnDeleteChapter()
{
	TArray<TObjectPtr<UQuestObject>> Selections = QuestObjectTreeView->GetSelectedItems();
	
	const FScopedTransaction Transaction(FGenericCommands::Get().Delete->GetDescription());
	DataEntity->Modify();
	for(auto QuestObject:Selections)
	{
		if(auto Chapter = Cast<UQuestChapter>(QuestObject))
		{
			DeleteChapter(Chapter);
		}
	}
}

TSharedRef<class SGraphEditor> FQuestObjectivesEditor::CreateEDGraphEditorWidget(UEdGraph* InGraph)
{
	check(InGraph != NULL);

	if (!QuestGraphEditorCommands.IsValid())
	{
		QuestGraphEditorCommands = MakeShareable(new FUICommandList);

		QuestGraphEditorCommands->MapAction(FGenericCommands::Get().Delete,
			FExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::EDDeleteSelectedNodes),
			FCanExecuteAction::CreateRaw(this, &FQuestObjectivesEditor::EDCanDeleteNodes)
		);
	}

	SGraphEditor::FGraphEditorEvents InEvents;
	//InEvents.OnSelectionChanged = SGraphEditor::FOnSelectionChanged::CreateSP(this, &FQuestObjectivesEditor::OnSelectedEDNodesChanged);
	//InEvents.OnNodeDoubleClicked = FSingleNodeEvent::CreateSP(this, &FBehaviorTreeEditor::OnNodeDoubleClicked);
	//InEvents.OnTextCommitted = FOnNodeTextCommitted::CreateSP(this, &FBehaviorTreeEditor::OnNodeTitleCommitted);

	// Make title bar
	TSharedRef<SWidget> TitleBarWidget =
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush(TEXT("Graph.TitleBackground")))
		.HAlign(HAlign_Fill)
		[
			SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Center)
				.FillWidth(1.f)
				[
					SNew(STextBlock)
						.Text(LOCTEXT("EDGraphLabel", "EventDriven"))
						.TextStyle(FAppStyle::Get(), TEXT("GraphBreadcrumbButtonText"))
				]
		];

	// Make full graph editor
	const bool bGraphIsEditable = InGraph->bEditable;

	TSharedRef<SGraphEditor> GraphRef = SNew(SGraphEditor)
		.AdditionalCommands(QuestGraphEditorCommands)
		//.IsEditable(this, &FBehaviorTreeEditor::InEditingMode, bGraphIsEditable)
		//.Appearance(this, &FBehaviorTreeEditor::GetGraphAppearance)
		.TitleBar(TitleBarWidget)
		.GraphToEdit(InGraph)
		.GraphEvents(InEvents);
	InGraph->Schema = UEventDrivenGraphSchema::StaticClass();



	return GraphRef;
}

void FQuestObjectivesEditor::EDDeleteSelectedNodes()
{
	//TSharedPtr<SGraphEditor> CurrentGraphEditor = CurGraphEdPtr.Pin();
	//if (!CurrentGraphEditor.IsValid())
	//{
	//	return;
	//}

	//const FScopedTransaction Transaction(FGenericCommands::Get().Delete->GetDescription());
	//CurrentGraphEditor->GetCurrentGraph()->Modify();

	//const FGraphPanelSelectionSet SelectedNodes = CurrentGraphEditor->GetSelectedNodes();
	//CurrentGraphEditor->ClearSelectionSet();

	//for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
	//{
	//	if (UEdGraphNode* Node = Cast<UEdGraphNode>(*NodeIt))
	//	{
	//		if (Node->CanUserDeleteNode())
	//		{
	//			Node->Modify();
	//			Node->DestroyNode();
	//		}
	//	}
	//}
}

bool FQuestObjectivesEditor::EDCanDeleteNodes() const
{
	//// If any of the nodes can be deleted then we should allow deleting
	//const FGraphPanelSelectionSet SelectedNodes = GetSelectedNodes();
	//for (FGraphPanelSelectionSet::TConstIterator SelectedIter(SelectedNodes); SelectedIter; ++SelectedIter)
	//{
	//	UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter);
	//	if (Node && Node->CanUserDeleteNode())
	//	{
	//		return true;
	//	}
	//}

	return true;
}

TSharedRef<SGraphEditor> FQuestObjectivesEditor::CreateGraphEditorWidget(UEdGraph* InGraph) {
	// Create the appearance info
	FGraphAppearanceInfo AppearanceInfo;
	AppearanceInfo.CornerText = LOCTEXT("AppearanceCornerText", "Quest & objectives");

	QuestGraphEditorCommands = MakeShareable(new FUICommandList);
	{
		QuestGraphEditorCommands->MapAction(FGenericCommands::Get().SelectAll,
			FExecuteAction::CreateSP(this, &FQuestObjectivesEditor::SelectAllNodes),
			FCanExecuteAction::CreateSP(this, &FQuestObjectivesEditor::CanSelectAllNodes)
		);

		QuestGraphEditorCommands->MapAction(FGenericCommands::Get().Delete,
			FExecuteAction::CreateSP(this, &FQuestObjectivesEditor::DeleteSelectedNodes),
			FCanExecuteAction::CreateSP(this, &FQuestObjectivesEditor::CanDeleteNodes)
		);

		QuestGraphEditorCommands->MapAction(FGenericCommands::Get().Copy,
			FExecuteAction::CreateSP(this, &FQuestObjectivesEditor::CopySelectedNodes),
			FCanExecuteAction::CreateSP(this, &FQuestObjectivesEditor::CanCopyNodes)
		);

		QuestGraphEditorCommands->MapAction(FGenericCommands::Get().Paste,
			FExecuteAction::CreateSP(this, &FQuestObjectivesEditor::PasteNodes),
			FCanExecuteAction::CreateSP(this, &FQuestObjectivesEditor::CanPasteNodes)
		);

		QuestGraphEditorCommands->MapAction(FGenericCommands::Get().Cut,
			FExecuteAction::CreateSP(this, &FQuestObjectivesEditor::CutSelectedNodes),
			FCanExecuteAction::CreateSP(this, &FQuestObjectivesEditor::CanCutNodes)
		);

		QuestGraphEditorCommands->MapAction(FGenericCommands::Get().Duplicate,
			FExecuteAction::CreateSP(this, &FQuestObjectivesEditor::DuplicateNodes),
			FCanExecuteAction::CreateSP(this, &FQuestObjectivesEditor::CanDuplicateNodes)
		);
	}

	SGraphEditor::FGraphEditorEvents InEvents;
	InEvents.OnSelectionChanged = SGraphEditor::FOnSelectionChanged::CreateSP(this, &FQuestObjectivesEditor::OnSelectedNodesChanged);
	InEvents.OnTextCommitted = FOnNodeTextCommitted::CreateSP(this, &FQuestObjectivesEditor::OnNodeTitleCommitted);
	
	// Make title bar
	TSharedRef<SWidget> TitleBarWidget =
		SNew(SBorder)
		.BorderImage(FAppStyle::Get().GetBrush(TEXT("Graph.TitleBackground")))
		.HAlign(HAlign_Fill)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.HAlign(HAlign_Center)
			.FillWidth(1.f)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("UpdateGraphLabel", "QuestObjectives Graph"))
			.TextStyle(FAppStyle::Get(), TEXT("GraphBreadcrumbButtonText"))
			]
		];

	TSharedRef<SGraphEditor> _GraphEditor = SNew(SGraphEditor_QuestObjectives)
		.AdditionalCommands(QuestGraphEditorCommands)
		.Appearance(AppearanceInfo)
		//.TitleBar(TitleBarWidget)
		.GraphToEdit(InGraph)
		.GraphEvents(InEvents)
		;

	return _GraphEditor;
}

void FQuestObjectivesEditor::SelectAllNodes()
{
	GraphEditor->SelectAllNodes();
}

bool FQuestObjectivesEditor::CanSelectAllNodes() const
{
	return GraphEditor.IsValid();
}

void FQuestObjectivesEditor::DeleteSelectedNodes()
{
	TArray<UEdGraphNode*> NodesToDelete;
	const FGraphPanelSelectionSet SelectedNodes = GraphEditor->GetSelectedNodes();

	for (FGraphPanelSelectionSet::TConstIterator NodeIt(SelectedNodes); NodeIt; ++NodeIt)
	{
		NodesToDelete.Add(CastChecked<UEdGraphNode>(*NodeIt));
	}

	for (int i = 0; i < NodesToDelete.Num(); i++)
	{
		if (Cast<UMONode_Base>(NodesToDelete[i]))
		{
			Cast<UMONode_Base>(NodesToDelete[i])->DeleteNode();
		}
	}

	DeleteNodes(NodesToDelete);
}

bool FQuestObjectivesEditor::CanDeleteNode(class UEdGraphNode* Node)
{
	bool CanDelete = true;

	if (UMONode_Base* GroupNode = Cast<UMONode_Base>(Node)) {
		CanDelete = GroupNode->bUserDefined;
	}

	return CanDelete;
}

void FQuestObjectivesEditor::DeleteNodes(const TArray<class UEdGraphNode*>& NodesToDelete)
{
	if (NodesToDelete.Num() > 0)
	{

		for (int32 Index = 0; Index < NodesToDelete.Num(); ++Index)
		{
			if (!CanDeleteNode(NodesToDelete[Index])) {
				continue;
			}

			NodesToDelete[Index]->DestroyNode();
		}
	}
}

void FQuestObjectivesEditor::DeleteSelectedDuplicatableNodes()
{
	// Cache off the old selection
	const FGraphPanelSelectionSet OldSelectedNodes = GraphEditor->GetSelectedNodes();

	// Clear the selection and only select the nodes that can be duplicated
	FGraphPanelSelectionSet RemainingNodes;
	GraphEditor->ClearSelectionSet();

	for (FGraphPanelSelectionSet::TConstIterator SelectedIter(OldSelectedNodes); SelectedIter; ++SelectedIter)
	{
		UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter);
		if ((Node != NULL) && Node->CanDuplicateNode())
		{
			GraphEditor->SetNodeSelection(Node, true);
		}
		else
		{
			RemainingNodes.Add(Node);
		}
	}

	// Delete the duplicatable nodes
	DeleteSelectedNodes();

	// Reselect whatever is left from the original selection after the deletion
	GraphEditor->ClearSelectionSet();

	for (FGraphPanelSelectionSet::TConstIterator SelectedIter(RemainingNodes); SelectedIter; ++SelectedIter)
	{
		if (UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter))
		{
			GraphEditor->SetNodeSelection(Node, true);
		}
	}
}

UQuestObject* FQuestObjectivesEditor::DeepCopyQuestObject(UQuestObject* From, bool bForceNewInstanceID)
{
	UQuestObject* RetVal = nullptr;
	if(auto FromChapter = Cast<UQuestChapter>(From))
	{
		PreRefreshChapterGraph(FromChapter);
		RetVal = DuplicateObject(FromChapter, GetTransientPackage());
		auto ToChapter = Cast<UQuestChapter>(RetVal);
		bLoadingChapterGraph = true;
		ToChapter->ChapterGraph = DuplicateObject(FromChapter->ChapterGraph, ToChapter);
		bLoadingChapterGraph = false;
	}
	if(auto FromRing = Cast<UQuestRing>(From))
	{
		PreRefreshRingGraph(FromRing);
		RetVal = DuplicateObject(FromRing, GetTransientPackage());
		auto ToRIng = Cast<UQuestRing>(RetVal);
		bLoadingRingGraph = true;
		ToRIng->RingGraph = DuplicateObject(FromRing->RingGraph, ToRIng);
		bLoadingRingGraph = false;
	}
	if(auto FromQuest = Cast<UQuest>(From))
	{
		PreRefreshQuestGraph(FromQuest);
		RetVal = DuplicateObject(FromQuest, GetTransientPackage());
		auto ToQuest = Cast<UQuest>(RetVal);
		bLoadingQuestGraph = true;
		ToQuest->QuestGraph = DuplicateObject(FromQuest->QuestGraph, ToQuest);
		bLoadingQuestGraph = false;

		// 如果是 前往指定坐标交互并进入位面 则在保存时多写一个 instanceid 给服务端用
		// 深拷贝时进行处理，且复制粘贴出来的节点 instanceid 不能相同
		TArray<UQuestTargetBase*> QuestTargetsToProcess = ToQuest->QuestTargets;
		QuestTargetsToProcess.Add(ToQuest->MainTarget);
		for (UQuestTargetBase* QuestTarget : QuestTargetsToProcess)
		{
			if (QuestTarget && QuestTarget->Type == 143)
			{
				FProperty* InstanceIDProperty = QuestTarget->GetClass()->FindPropertyByName(TEXT("InstanceID"));

				if (InstanceIDProperty)
				{
					if (FStrProperty* StrProperty = CastField<FStrProperty>(InstanceIDProperty))
					{
						// 处理整数ID
						FString CurrentID = StrProperty->GetPropertyValue_InContainer(QuestTarget);

						// 如果为0或无效，生成新ID
						if (CurrentID.IsEmpty() || bForceNewInstanceID)
						{
							// refer to ASceneActorBase::ASceneActorBase()
							int64 NewID = GetTypeHash(FGuid::NewGuid());
							StrProperty->SetPropertyValue_InContainer(QuestTarget, FString::Printf(TEXT("%lld"), NewID));
						}
					}
				}
			}
		}
	}
	RetVal->Children.Empty();
	for(int i = 0; i < From->Children.Num(); i++)
	{
		if(auto NewChild = DeepCopyQuestObject(From->Children[i]))
		{
			NewChild->Father = RetVal;
			RetVal->Children.Add(NewChild);
		}
	}
	return RetVal;
}

void FQuestObjectivesEditor::CopySelectedChapter()
{
	auto SelectedChapter = GetSelectedChapter();
	if(!SelectedChapter)
	{
		return;
	}
	else
	{
		DataEntity->PasteBuffer.Empty();
		DataEntity->PasteBuffer.Add(DeepCopyQuestObject(SelectedChapter));
	}
}

void FQuestObjectivesEditor::OnCutSelectedChapter()
{
	CutSelectedChapter();
}

bool FQuestObjectivesEditor::CutSelectedChapter(bool bDeleteSelf)
{
	const FScopedTransaction Transaction(FGenericCommands::Get().Cut->GetDescription());
	DataEntity->Modify();
	auto SelectedChapter = GetSelectedChapter();
	CopySelectedChapter();
	if (bDeleteSelf)
	{
		// 删除自身
		return DeleteChapter(SelectedChapter);
	}
	return true;
}

void FQuestObjectivesEditor::PasteCopiedChapter(bool bNeedChangeID)
{
	const FScopedTransaction Transaction(FGenericCommands::Get().Paste->GetDescription());
	DataEntity->Modify();
	DataEntity->CopiedMapping.Empty();
	DataEntity->RevCopiedMapping.Empty();
	UQuestObject* SelectedObj = nullptr;
	auto SelectedChapters = QuestObjectTreeView->GetSelectedItems();
	if(SelectedChapters.Num()>0)
	{
		SelectedObj = SelectedChapters[0];
	}
	if(DataEntity->PasteBuffer.Num()>0)
	{
		UQuestChapter* ChapterObj = nullptr;
		auto DuplicatedObj = DeepCopyQuestObject(DataEntity->PasteBuffer[0]);
		ChapterObj = Cast<UQuestChapter>(DuplicatedObj);
		if (ChapterObj == nullptr)
		{
			return;
		}
		if(auto SelectedChapter = Cast<UQuestChapter>(SelectedObj))
		{
			ChapterObj->Father = SelectedChapter->Father;
		}else
		{
			ChapterObj->Father = SelectedObj;
		}
		ChapterObj->QuestType = SelectedObj->QuestType;
		if (bNeedChangeID)
		{
			ReAllocateQuestObjectID(ChapterObj);
		}
		for(auto GraphNode : ChapterObj->ChapterGraph->Nodes)
		{
			GraphNode->PostPasteNode();
		}
		RebuildQuestObjectRelations(ChapterObj);
		QuestObjectTreeRefresh(true);
	}
}

void FQuestObjectivesEditor::ReAllocateQuestObjectID(UQuestObject* Target, bool bKeepID)
{
	if(!Target)
	{
		return;
	}
	Target->Modify();
	int32 Prev = Target->QuestObjectID;
	UQuestChapter* ChapterObj = Cast<UQuestChapter>(Target);
	UQuestRing* RingObj = Cast<UQuestRing>(Target);
	UQuest* QuestObj = Cast<UQuest>(Target);
	if(ChapterObj)
	{
		ChapterObj->ChapterID = GetAvailableID(ChapterObj);
		ChapterObj->QuestObjectID = ChapterObj->ChapterID;
		MarkAssetForDirty(ChapterObj);
		AddChapterObj(ChapterObj, true);
	}
	else if(RingObj)
	{
		RingObj->ChapterID = RingObj->Father->QuestObjectID;
		RingObj->RingID = GetAvailableID(RingObj);;
		RingObj->QuestObjectID = RingObj->RingID;
		MarkAssetForDirty(RingObj);
		AddRingObj(RingObj, true);
	}
	else if(QuestObj)
	{
		QuestObj->RingID = QuestObj->Father->QuestObjectID;
		if (UQuestRing* FatherRing = Cast<UQuestRing>(QuestObj->Father))
		{
			// 可能相关联的 Ring 的 RingID 被改变但没保存，
			// 此时 QuestObjectID 存的是原先的 RingID，所以这里把 Quest 的 RingID 改为 Ring 的 RingID 而不是 QuestObjectID
			QuestObj->RingID = FatherRing->RingID;
		}
		if (QuestObj->Father->Father == nullptr)
		{
			UE_LOG(LogQuestObjectivesEditor, Error, TEXT("ReAllocateQuestObjectID: Father Chapter Is Empty!!! Ring ID: %d"), QuestObj->RingID)
			return;
		}
		QuestObj->ChapterID = QuestObj->Father->Father->QuestObjectID;
		int32 CurrentSuffix = QuestObj->QuestID % 100;
		// 注意新创建的 RingID 可能为负数
		int32 KeepID = QuestObj->RingID > 0 ? QuestObj->RingID * 100 + CurrentSuffix : QuestObj->RingID * 100 - CurrentSuffix;
		if(bKeepID && !DataEntity->QuestMap.Contains(KeepID))
		{
			QuestObj->QuestID = KeepID;
		}else
		{
			QuestObj->QuestID = GetAvailableID(QuestObj);;
		}
		QuestObj->QuestObjectID = QuestObj->QuestID;
		MarkAssetForDirty(QuestObj);
		AddQuestObj(QuestObj, true);
	}
	if(Prev != Target->QuestObjectID)
	{
		DataEntity->CopiedMapping.Add(Target->QuestObjectID, Prev);
		DataEntity->RevCopiedMapping.Add(Prev, Target->QuestObjectID);
	}
	for(auto Child : Target->Children)
	{
		if(IsValid(Child))
		{
			Child->Father = Target;
			Child->QuestType = Target->QuestType;	
			ReAllocateQuestObjectID(Child, bKeepID);
		}
	}
	if(ChapterObj)
	{
		for(auto Child : ChapterObj->Children)
		{
			if(auto R = Cast<UQuestRing>(Child))
			{
				for (auto NextTaskObj : R->NextTaskInfoList)
				{
					if(NextTaskObj && DataEntity->RevCopiedMapping.Contains(NextTaskObj->NextTaskID))
					{
						NextTaskObj->NextTaskID = DataEntity->RevCopiedMapping[NextTaskObj->NextTaskID];
					}
				}
				RemapPreRingRelations(R->PreRingRelations);
			}
		}
		for (auto Node : ChapterObj->ChapterGraph->Nodes)
		{
			if(auto RingNode = Cast<UEDGraphNode_Base>(Node))
			{
				auto PrevIns = Cast<UQuestRing>(RingNode->NodeInstance);
				if(PrevIns && DataEntity->RevCopiedMapping.Contains(PrevIns->RingID))
				{
					RingNode->NodeInstance = DataEntity->RingMap[DataEntity->RevCopiedMapping[PrevIns->RingID]];
				}
			}
		}
	}
	
	if(RingObj)
	{
		for(auto Child : RingObj->Children)
		{
			if(auto Q = Cast<UQuest>(Child))
			{
				for (auto NextTaskObj : Q->NextTaskInfoList)
				{
					if(NextTaskObj && DataEntity->RevCopiedMapping.Contains(NextTaskObj->NextTaskID))
					{
						NextTaskObj->NextTaskID = DataEntity->RevCopiedMapping[NextTaskObj->NextTaskID];
					}
				}
			}
		}
		for (auto Node : RingObj->RingGraph->Nodes)
		{
			if(auto QuestNode = Cast<UEDGraphNode_Base>(Node))
			{
				auto PrevIns = Cast<UQuest>(QuestNode->NodeInstance);
				if(PrevIns && DataEntity->RevCopiedMapping.Contains(PrevIns->QuestID))
				{
					QuestNode->NodeInstance = DataEntity->QuestMap[DataEntity->RevCopiedMapping[PrevIns->QuestID]];
				}
			}
		}
	}
}

void FQuestObjectivesEditor::CopySelectedNodes()
{
	// Export the selected nodes and place the text on the clipboard

	FGraphPanelSelectionSet SelectedNodes = FGraphPanelSelectionSet();
	for (FGraphPanelSelectionSet::TConstIterator SelectedIter(GraphEditor->GetSelectedNodes()); SelectedIter; ++SelectedIter)
	{
		if (UMONode_Base* NodeBase = Cast<UMONode_Base>(*SelectedIter))
		{
			// Only user defined nodes can be copied
			if (NodeBase->bUserDefined)
			{
				SelectedNodes.Add(*SelectedIter);
			}
		}
	}

	FString ExportedText;
	for (FGraphPanelSelectionSet::TConstIterator SelectedIter(SelectedNodes); SelectedIter; ++SelectedIter)
	{
		if (UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter))
		{
			Node->PrepareForCopying();
		}
	}


	FEdGraphUtilities::ExportNodesToText(SelectedNodes, /*out*/ ExportedText);
	FPlatformApplicationMisc::ClipboardCopy(*ExportedText);

	//UE_LOG(LogQuestObjectivesEditor, Log, TEXT("ExportedText is %s"), *ExportedText);
	
	//CopyNodesTemplateObjectArray.Empty();
	//for (FGraphPanelSelectionSet::TConstIterator SelectedIter(SelectedNodes); SelectedIter; ++SelectedIter)
	//{
	//	if (UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter))
	//	{
	//		if (UMONode_Base* NodeBase = Cast<UMONode_Base>(Node))
	//		{
	//			NodeBase->PostCopying();
	//			if (UMONode_QuestAction* QuestAction = Cast<UMONode_QuestAction>(Node))
	//			{
	//				CopyNodesTemplateObjectArray.Add(QuestAction->QuestActionNode);
	//			}
	//			else if (UMONode_Quest* SingleQuest = Cast<UMONode_Quest>(Node))
	//			{
	//				CopyNodesTemplateObjectArray.Add(SingleQuest->SingleQuest);
	//			}
	//			else
	//			{
	//				CopyNodesTemplateObjectArray.Add(nullptr);
	//			}
	//		}
	//	}
	//}
}

bool FQuestObjectivesEditor::CanCopyNodes() const
{
	return true;
	//// If any of the nodes can be duplicated then we should allow copying
	//const FGraphPanelSelectionSet SelectedNodes = GraphEditor->GetSelectedNodes();
	//for (FGraphPanelSelectionSet::TConstIterator SelectedIter(SelectedNodes); SelectedIter; ++SelectedIter)
	//{
	//	UEdGraphNode* Node = Cast<UEdGraphNode>(*SelectedIter);
	//	if ((Node != NULL) && Node->CanDuplicateNode())
	//	{
	//		return true;
	//	}
	//}
	//return false;
}

void FQuestObjectivesEditor::PasteNodes()
{
	PasteNodesHere(GraphEditor->GetPasteLocation());
}

void FQuestObjectivesEditor::PasteNodesHere(const FVector2D& Location)
{
	// Clear the selection set (newly pasted stuff will be selected)
	GraphEditor->ClearSelectionSet();

	// Grab the text to paste from the clipboard.
	FString TextToImport;
	FPlatformApplicationMisc::ClipboardPaste(TextToImport);

	// Import the nodes
	TSet<UEdGraphNode*> PastedNodes;

	FEdGraphUtilities::ImportNodesFromText(GetQuestObjectivesGraph(), TextToImport, /*out*/ PastedNodes);

	//Average position of nodes so we can move them while still maintaining relative distances to each other
	FVector2D AvgNodePosition(0.0f, 0.0f);

	for (TSet<UEdGraphNode*>::TIterator It(PastedNodes); It; ++It)
	{
		UEdGraphNode* Node = *It;
		AvgNodePosition.X += Node->NodePosX;
		AvgNodePosition.Y += Node->NodePosY;
	}

	if (PastedNodes.Num() > 0)
	{
		float InvNumNodes = 1.0f / float(PastedNodes.Num());
		AvgNodePosition.X *= InvNumNodes;
		AvgNodePosition.Y *= InvNumNodes;
	}

	int TempNum = 0;
	for (TSet<UEdGraphNode*>::TIterator It(PastedNodes); It; ++It)
	{
		UEdGraphNode* Node = *It;

		// Select the newly pasted stuff
		GraphEditor->SetNodeSelection(Node, true);
		Node->NodePosX = (Node->NodePosX - AvgNodePosition.X) + Location.X;
		Node->NodePosY = (Node->NodePosY - AvgNodePosition.Y) + Location.Y;
		Node->SnapToGrid(SNodePanel::GetSnapGridSize());

		// Give new node a different Guid from the old one
		Node->CreateNewGuid();

		if (UMONode_Base* NodeBase = Cast<UMONode_Base>(Node))
		{
			NodeBase->PostPasteNodeFinal();
			NodeBase->CreateAsset(CopyNodesTemplateObjectArray[TempNum]);
		}
		TempNum ++;
	}

	// Update UI
	GraphEditor->NotifyGraphChanged();
}

bool FQuestObjectivesEditor::CanPasteNodes() const
{
	return true;
	//FString ClipboardContent;
	//FPlatformApplicationMisc::ClipboardPaste(ClipboardContent);
//
	//if (UGroupQuestTemplate* GroupQuestTemplate = Cast<UGroupQuestTemplate>(CurEditorDataAsset))
	//{
	//	return FEdGraphUtilities::CanImportNodesFromText(GroupQuestTemplate->NodeGraph, ClipboardContent);
	//}
	//else if (USingleQuest* SingleQuest = Cast<USingleQuest>(CurEditorDataAsset))
	//{
	//	return FEdGraphUtilities::CanImportNodesFromText(SingleQuest->NodeGraph, ClipboardContent);
	//}
	//else
	//{
	//	return FEdGraphUtilities::CanImportNodesFromText(nullptr, ClipboardContent);
	//}
}

bool FQuestObjectivesEditor::CanPasteQuestNode() const
{
	if(DataEntity->PasteBuffer.Num()>0)
	{
		if(DataEntity->PasteBuffer[0].IsA(UQuest::StaticClass()))
		{
			return true;
		}
	}
	return false;
}

bool FQuestObjectivesEditor::CanPasteRingNode() const
{
	if(DataEntity->PasteBuffer.Num()>0)
	{
		if(DataEntity->PasteBuffer[0].IsA(UQuestRing::StaticClass()))
		{
			return true;
		}
	}
	return false;
}

void FQuestObjectivesEditor::CutSelectedNodes()
{
	CopySelectedNodes();
	// Cut should only delete nodes that can be duplicated
	DeleteSelectedDuplicatableNodes();
}

bool FQuestObjectivesEditor::CanCutNodes() const
{
	return CanCopyNodes() && CanDeleteNodes();
}

void FQuestObjectivesEditor::DuplicateNodes()
{
	// Copy and paste current selection
	CopySelectedNodes();
	PasteNodes();
}

bool FQuestObjectivesEditor::CanDuplicateNodes() const
{
	return CanCopyNodes();
}

void FQuestObjectivesEditor::OnGraphChanged(const FEdGraphEditAction& Action)
{
	bGraphStateChanged = true;
}

void FQuestObjectivesEditor::OnChapterGraphChanged(const FEdGraphEditAction& Action)
{
	if(bUndoing || Action.Action == GRAPHACTION_SelectNode)
	{
		return;
	}
	MarkCurChapterForDirty();
}

void FQuestObjectivesEditor::OnRingGraphChanged(const FEdGraphEditAction& Action)
{
	if(bUndoing || Action.Action == GRAPHACTION_SelectNode)
	{
		return;
	}
	MarkCurRingForDirty();
}

void FQuestObjectivesEditor::OnQuestGraphChanged(const FEdGraphEditAction& Action)
{
	if(bUndoing || Action.Action == GRAPHACTION_SelectNode)
	{
		return;
	}
	MarkCurQuestForDirty();
}

void FQuestObjectivesEditor::HandleGraphChanged()
{
}

void FQuestObjectivesEditor::SaveAsset_Execute()
{
	/*UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Saving QuestObjectives prop asset %s"), *GetEditingObjects()[0]->GetName());

	UPackage* Package = PropBeingEdited->GetOutermost();
	if (Package)
	{
		TArray<UPackage*> PackagesToSave;
		PackagesToSave.Add(Package);
		FEditorFileUtils::PromptForCheckoutAndSave(PackagesToSave, false, false);
	}*/
}

void FQuestObjectivesEditor::OnSelectedNodesChanged(const TSet<class UObject*>& NewSelection)
{
	for (TWeakObjectPtr<UMONode_Base> SelectedNode : LastSelectedNodes)
	{
		if (SelectedNode.IsValid())
		{
			SelectedNode->bIsNodeSelected = false;
			SelectedNode->OnSelectedNodeChanged();
		}
	}

	TArray<UObject*> SelectedObjects;
	for (UObject* Object : NewSelection) {
		SelectedObjects.Add(Object);

		UMONode_Base* Node = Cast<UMONode_Base>(Object);
		if (Node)
		{
			LastSelectedNodes.Add(Node);
			Node->bIsNodeSelected = true;
		}
	}

	///*if (SelectedObjects.Num() == 0)
	//{
	//	PropertyEditor->SetObject(GetPropBeingEdited());
	//	return;
	//}*/

	//PropertyEditor->SetObjects(SelectedObjects);
}

void FQuestObjectivesEditor::OnQuestNodeDoubleClicked(UEdGraphNode* InNode)
{
	if (InNode)
	{
		if (UEDGraphNode_Base* Node = Cast<UEDGraphNode_Base>(InNode))
		{
			UObject* SelectObj = Node->NodeInstance;
			if (SelectObj && Node->NodeType == EDNodeType::QuestAction)
			{
				if (UQuestActionBase* Action = Cast<UQuestActionBase>(SelectObj))
				{
					if (Action->Event == 44)
					{
						FString FlowChartName;
						for (FProperty* Property : TFieldRange<FProperty>(Action->GetClass(), EFieldIteratorFlags::ExcludeSuper))
						{
							if (Property->GetName() == "FlowChart")
							{
								if (FStrProperty* StrProp = CastField<FStrProperty>(Property))
								{
									void* PropAddress = Property->ContainerPtrToValuePtr<void>(Action);
									FlowChartName = *StaticCast<FString*>(PropAddress);
								}
							}
						}


						FString StringFlowToolPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());
						FString ProjectXMLPath = StringFlowToolPath;
						ProjectXMLPath += "../../Tools/FlowChartTool/c7.xml";
						StringFlowToolPath += "../../Tools/FlowChartTool/FlowChartTool.exe";
						FString Params(ProjectXMLPath);
						Params += " ";
						Params += FlowChartName;

						uint32* ID = 0;

						FPlatformProcess::CreateProc(*StringFlowToolPath, *Params, true, false, false, ID, 0, nullptr, nullptr);
					}
				}
			}

			PropertyEditor->SetObject(SelectObj);
		}
	}
	else
	{
		PropertyEditor->SetObject(nullptr);
	}
}

bool FQuestObjectivesEditor::OnRequestClose(EAssetEditorCloseReason InCloseReason)
{
	if (DataEntity->DirtyChapters.Num() > 0 || DataEntity->DirtyRings.Num() > 0 || DataEntity->DirtyQuests.Num() > 0 || DataEntity->PendingDeleteObjects.Num() > 0)
	{
		FString DirtyChapterList;
		for (auto Chapter : DataEntity->DirtyChapters)
		{
			UQuestChapter* ChapterData = Chapter.Get();
			if (!ChapterData)
				continue;
			DirtyChapterList += FString::FromInt(ChapterData->ChapterID) + " ";
		}
		
		FString DirtyRingList;
		for (auto Ring : DataEntity->DirtyRings)
		{
			UQuestRing* RingData = Ring.Get();
			if (!RingData)
				continue;
			DirtyRingList += FString::FromInt(RingData->RingID) + " ";
		}

		FString DirtyQuestList;
		for (auto Quest : DataEntity->DirtyQuests)
		{
			UQuest* QuestData = Quest.Get();
			if (!QuestData)
				continue;
			DirtyQuestList += FString::FromInt(QuestData->QuestID) + " ";
		}

		FString PendingDeleteList;
		for (auto Obj : DataEntity->PendingDeleteObjects)
		{
			UQuestObject* QuestData = Obj.Get();
			if (!QuestData)
				continue;
			PendingDeleteList += FString::FromInt(QuestData->QuestObjectID) + " ";
		}
		
		FString FinalRes;
		if (!DirtyChapterList.IsEmpty())
			FinalRes += "Chapter: " + DirtyChapterList;
		if (!DirtyRingList.IsEmpty())
			FinalRes += "Ring: " + DirtyRingList;
		if (!DirtyQuestList.IsEmpty())
			FinalRes += "Quest: " + DirtyQuestList;
		if (!PendingDeleteList.IsEmpty())
			FinalRes += "PendingDeleteObj: " + PendingDeleteList;

		FText ConfirmText = FText::Format(LOCTEXT("Close Warning", "Still Have UnSave Files, {0}, Sure to Close?"), FText::FromString(FinalRes));
		EAppReturnType::Type ReturnType = FMessageDialog::Open(EAppMsgType::YesNo, ConfirmText);
		if (ReturnType == EAppReturnType::Type::Yes)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	return true;
}

void FQuestObjectivesEditor::ShowCheckResultMessageBox(const TArray<FString>& WarningMsgs, const TArray<FString>& ErrorMsgs)
{
	FString WarningInfo = FString::Join(WarningMsgs, TEXT("\n"));
	FString ErrorInfo = FString::Join(ErrorMsgs, TEXT("\n"));
	if (WarningWindow.IsValid())
	{
		WarningWindow->RequestDestroyWindow();
		WarningWindow.Reset();
	}
	WarningWindow = SNew(SWindow)
   .Title(LOCTEXT("CheckResultMessageBoxTitle", "FQuestObjectivesEditor Data Check Warnings"))
   .ClientSize(FVector2D(800, 600))
   .SupportsMinimize(true)
   .SupportsMaximize(true)
   [
	   SNew(SQuestCheckWarningWidget)
	   .ErrorMessage(FText::FromString(ErrorInfo))
	   .WarnMessage(FText::FromString(WarningInfo))
   ];

	FSlateApplication::Get().AddWindow(WarningWindow.ToSharedRef());
}

void FQuestObjectivesEditor::RecoverQuestObjectFilteredItems()
{
	QuestObjectFilteredItems.Empty();
	QuestObjectFilteredItems.Append(DataEntity->QuestObjectRootItems);
}

void FQuestObjectivesEditor::InitializeQuestTypeSelection()
{
	for (int32 Index = 0; Index < static_cast<int32>(EQuestType::EQT_Max); ++Index)
	{
		SelectedQuestTypes.Add(static_cast<EQuestType>(Index), true); // 初始状态都为选中
	}
}

TSharedRef<SWidget> FQuestObjectivesEditor::GenerateFilterBtnMenuContent()
{
	TSharedRef<SVerticalBox> MenuContent = SNew(SVerticalBox);

	for (int32 Index = 0; Index < static_cast<int32>(EQuestType::EQT_Max); ++Index)
	{
		UEnum* Enum = StaticEnum<EQuestType>();
		bool bIsDeprecated = Enum->HasMetaData(TEXT("Deprecated"), Index);
		if (bIsDeprecated)
		{
			continue;
		}

		EQuestType QuestType = static_cast<EQuestType>(Index);

		MenuContent->AddSlot()
		.AutoHeight()
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([this, QuestType]()
			{
				return SelectedQuestTypes[QuestType] ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
			})
			.OnCheckStateChanged_Lambda([this, QuestType](ECheckBoxState NewState)
			{
				SelectedQuestTypes[QuestType] = (NewState == ECheckBoxState::Checked);
				FilterQuestObject();
			})
			[
				SNew(STextBlock).Text(FText::FromString(GetQuestTypeDisplayName(QuestType)))
			]
		];
	}

	return MenuContent;
}

void FQuestObjectivesEditor::FilterQuestObject()
{
	RecoverQuestObjectFilteredItems();
	FilterQuestObjectBySearchText();
	FilterQuestObjectTypes();
}

void FQuestObjectivesEditor::FilterQuestObjectBySearchText()
{
	if (QuestObjectSearchText.IsEmpty())
	{
		RecoverQuestObjectFilteredItems();
	}
	else
	{
		// 清空筛选后的列表
		QuestObjectFilteredItems.Empty();

		// 遍历原始数据源，进行筛选
		for (const TObjectPtr<UQuestObject>& Item : DataEntity->QuestObjectRootItems)
		{
			bool bInitNewItem = false;
			TObjectPtr<UQuestObject> DelegateItem = nullptr;

			for (TObjectPtr<UQuestObject> Child : Item->Children)
			{
				if (Child->QuestObjectName.Contains(QuestObjectSearchText))
				{
					if (!bInitNewItem)
					{
						DelegateItem = NewObject<UQuestObject>();
						DelegateItem->QuestType = Item->QuestType;
						DelegateItem->QuestObjectName = Item->QuestObjectName;
						DelegateItem->QuestObjectType = Root;

						DelegateItem->Children.Empty();
						bInitNewItem = true;
					}

					if (DelegateItem)
					{
						DelegateItem->Children.Add(Child);
					}
				}
			}

			if (DelegateItem)
			{
				QuestObjectFilteredItems.Add(DelegateItem);
				QuestObjectTreeView->SetItemExpansion(DelegateItem, true);
			}
		}
	}

	// 刷新树视图
	QuestObjectTreeView->RequestTreeRefresh();
}

void FQuestObjectivesEditor::FilterQuestObjectTypes()
{
	for (int32 Index = QuestObjectFilteredItems.Num() - 1; Index >= 0; Index--)
	{
		TObjectPtr<UQuestObject> CurItem = QuestObjectFilteredItems[Index];
		if (SelectedQuestTypes.Contains(CurItem->QuestType) && !SelectedQuestTypes[CurItem->QuestType])
		{
			QuestObjectFilteredItems.RemoveAt(Index);
		}
	}

	// 刷新树视图
	QuestObjectTreeView->RequestTreeRefresh();
}

void FQuestObjectivesEditor::OnClose()
{
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnClose Begin."));
	DeleteEmptyFilesInChangelist();
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	if (AssetRegistryModule.IsValid())
		AssetRegistryModule.Get().OnAssetRemoved().RemoveAll(this);

	OnRefreshLuaState();
	
	if (GraphUndoRedoHandler)
	{
		delete GraphUndoRedoHandler;
		GraphUndoRedoHandler = nullptr;
	}
	
	for (size_t i = 0; i < DataEntity->AllChapters.Num(); i++)
	{
		if (IsValid(DataEntity->AllChapters[i]))
		{
			UQuestChapter* ChapterData = DataEntity->AllChapters[i].Get();
			if (ChapterData)
			{
				ChapterData->OnRefreshChapter.RemoveAll(this);
			}
		}
	}

	DataEntity->RemoveFromRoot();

	if (ChapterGraph.IsValid())
	{
		ChapterGraph->RemoveOnGraphChangedHandler(OnChapterGraphChangedDelegateHandle);
		ChapterGraph->GraphEditor.Reset();
		ChapterGraph->Nodes.Reset();
		ChapterGraph.Reset();
	}
	
	if (RingGraph.IsValid())
	{
		RingGraph->RemoveOnGraphChangedHandler(OnRingGraphChangedDelegateHandle);
		RingGraph->GraphEditor.Reset();
		RingGraph->Nodes.Reset();
		RingGraph.Reset();
	}
		
	
	if (QuestGraph.IsValid())
	{
		QuestGraph->RemoveOnGraphChangedHandler(OnQuestGraphChangedDelegateHandle);
		QuestGraph->GraphEditor.Reset();
		QuestGraph->Nodes.Reset();
		QuestGraph.Reset();
	}

	if (GraphEditor)
	{
		if (GraphEditor->GetCurrentGraph()) 
		{
			GraphEditor->GetCurrentGraph()->RemoveOnGraphChangedHandler(OnGraphChangedDelegateHandle);
		}
	}
	
	//TSharedPtr<SDockTab> FindResultsTab = TabManager->FindExistingLiveTab(FQuestObjectivesEditorTabs::QuestFindResultsID);
	//if (FindResultsTab.IsValid())
	//{
	//	FindResultsTab->RequestCloseTab();
	//}
	
	FQuestImportLua::ClearRecordedUClass();
	TabManager->UnregisterAllTabSpawners();
	
	FAssetEditorToolkit::OnClose();
	
	FoundObject->RemoveFromRoot();

	if (DisasterRecoveryTimerHandle.IsValid())
	{
		GEditor->GetTimerManager()->ClearTimer(DisasterRecoveryTimerHandle);
	}
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("OnClose Finish."));
}

void FGraphUndoRedoHandler::OnUndoRedo()
{
	auto ChapterGraph = ActiveEditor->GetChapterGraph();
	auto RingGraph = ActiveEditor->GetRingGraph();
	auto QuestGraph = ActiveEditor->GetQuestGraph();
	ActiveEditor->bUndoing = true;
	
	ActiveEditor->QuestObjectTreeRefresh(true);
	if(ChapterGraph.IsValid())
	{
		ChapterGraph->NotifyGraphChanged();
	}else
	{
		ActiveEditor->ClearChapterGraph();
	}
	if(RingGraph.IsValid())
	{
		RingGraph->NotifyGraphChanged();
	}else
	{
		ActiveEditor->ClearRingGraph();
	}
	if(QuestGraph.IsValid())
	{
		QuestGraph->NotifyGraphChanged();
	}
	ActiveEditor->bUndoing = false;
}

void FQuestObjectivesEditor::RegisterTabSpawners(const TSharedRef<class FTabManager>& TabManagerReg)
{
	WorkspaceMenuCategory = TabManagerReg->AddLocalWorkspaceMenuCategory(LOCTEXT("WorkspaceMenu_QuestObjectivesEditor", "QuestObjectives Editor"));
	auto WorkspaceMenuCategoryRef = WorkspaceMenuCategory.ToSharedRef();


	//DocumentManager->SetTabManager(TabManagerReg);

	FAssetEditorToolkit::RegisterTabSpawners(TabManagerReg);

	TabManagerReg->RegisterTabSpawner(FQuestObjectivesEditorTabs::DetailsID, FOnSpawnTab::CreateSP(this, &FQuestObjectivesEditor::SpawnTab_Details))
		.SetDisplayName(LOCTEXT("DetailsTabLabel", "Details"))
		.SetGroup(WorkspaceMenuCategoryRef)
		.SetIcon(FSlateIcon(FAppStyle::Get().GetStyleSetName(), "LevelEditor.Tabs.Details"));

	TabManagerReg->RegisterTabSpawner(FQuestObjectivesEditorTabs::ChapterGraphID, FOnSpawnTab::CreateSP(this, &FQuestObjectivesEditor::SpawnTab_ChapterGraph))
		.SetDisplayName(LOCTEXT("ChapterGraphTab", "ChapterGraph"))
		.SetGroup(WorkspaceMenuCategoryRef)
		.SetIcon(FSlateIcon(FAppStyle::Get().GetStyleSetName(), "LevelEditor.Tabs.ChapterGraph"));
	
	TabManagerReg->RegisterTabSpawner(FQuestObjectivesEditorTabs::RingGraphID, FOnSpawnTab::CreateSP(this, &FQuestObjectivesEditor::SpawnTab_RingGraph))
		.SetDisplayName(LOCTEXT("RingGraphTab", "RingGraph"))
		.SetGroup(WorkspaceMenuCategoryRef)
		.SetIcon(FSlateIcon(FAppStyle::Get().GetStyleSetName(), "LevelEditor.Tabs.RingGraph"));

	TabManagerReg->RegisterTabSpawner(FQuestObjectivesEditorTabs::NavigationTab, FOnSpawnTab::CreateSP(this, &FQuestObjectivesEditor::SpawnTab_NavigationTab))
		.SetDisplayName(LOCTEXT("NavigationTabLabel", "NavigationTab"))
		.SetGroup(WorkspaceMenuCategoryRef)
		.SetIcon(FSlateIcon(FAppStyle::Get().GetStyleSetName(), "LevelEditor.Tabs.Details"));

	TabManagerReg->RegisterTabSpawner(FQuestObjectivesEditorTabs::QuestToolBarID, FOnSpawnTab::CreateSP(this, &FQuestObjectivesEditor::SpawnTab_QuestToolBar))
		.SetDisplayName(LOCTEXT("QuestToolBar", "QuestToolBar"))
		.SetGroup(WorkspaceMenuCategoryRef)
		.SetIcon(FSlateIcon(FAppStyle::Get().GetStyleSetName(), "LevelEditor.Tabs.Details"));
		
	TabManagerReg->RegisterTabSpawner(FQuestObjectivesEditorTabs::QuestFindResultsID, FOnSpawnTab::CreateSP(this, &FQuestObjectivesEditor::SpawnTab_FindInQuest))
		.SetDisplayName(LOCTEXT("FindInQuestTable", "Find in quest"))
		.SetGroup(WorkspaceMenuCategoryRef)
		.SetIcon(FSlateIcon(FAppStyle::Get().GetStyleSetName(), "LevelEditor.Tabs.Details"));
	
}

void FQuestObjectivesEditor::UnregisterTabSpawners(const TSharedRef<class FTabManager>& TabManagerReg)
{
	FAssetEditorToolkit::UnregisterTabSpawners(TabManagerReg);

	TabManagerReg->UnregisterTabSpawner(FQuestObjectivesEditorTabs::ViewportID);
	TabManagerReg->UnregisterTabSpawner(FQuestObjectivesEditorTabs::ChapterGraphID);
	TabManagerReg->UnregisterTabSpawner(FQuestObjectivesEditorTabs::RingGraphID);
	TabManagerReg->UnregisterTabSpawner(FQuestObjectivesEditorTabs::QuestGraphID);
	TabManagerReg->UnregisterTabSpawner(FQuestObjectivesEditorTabs::ActionsID);
	TabManagerReg->UnregisterTabSpawner(FQuestObjectivesEditorTabs::DetailsID);
	TabManagerReg->UnregisterTabSpawner(FQuestObjectivesEditorTabs::QuestChoiseDetailID);
	TabManagerReg->UnregisterTabSpawner(FQuestObjectivesEditorTabs::QuestToolBarID);

	TabManagerReg->UnregisterTabSpawner(FQuestObjectivesEditorTabs::NavigationTab);
}

void FQuestObjectivesEditor::InitQuestObjectivesEditor(const EToolkitMode::Type Mode, const TSharedPtr< class IToolkitHost >& InitToolkitHost) 
{
	//InitQuestObjectivesProp();

	//FMOEditorStyle::Initialize();
	//FMOEditorStyle::ReloadTextures();
	
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Quest Editor Init Begin."));

	InitializeQuestTypeSelection();

	if (GetMutableDefault<UQuestSettings>()->bSystemActionEnable)
	{
		UKGQuestEditorSubSystem::Get().InitializeQuestActionClasses();
	}

	if (!GraphUndoRedoHandler)
	{
		GraphUndoRedoHandler = new FGraphUndoRedoHandler();
		GraphUndoRedoHandler->ActiveEditor = this;
	}
	DataEntity = NewObject<UQuestObjectDataEntity>();
	DataEntity->SetFlags(RF_Transactional);
	SetP4WorkSpace();
	LoadAllQuestAssets();

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	if (AssetRegistryModule.IsValid())
		AssetRegistryModule.Get().OnAssetRemoved().AddRaw(this, &FQuestObjectivesEditor::OnAssetRemoved);


	// Register custom graph nodes
	FEdGraphUtilities::RegisterVisualNodeFactory(MakeShareable(new FCCNodeFactory));

	GraphStack = FTabManager::NewStack()
		->SetSizeCoefficient(0.8f)
		->SetHideTabWell(true)
		->AddTab(FQuestObjectivesEditorTabs::ViewportID, ETabState::OpenedTab)
		->AddTab(FQuestObjectivesEditorTabs::ChapterGraphID,ETabState::OpenedTab)
		->AddTab(FQuestObjectivesEditorTabs::RingGraphID, ETabState::OpenedTab)
		->AddTab(FQuestObjectivesEditorTabs::QuestGraphID, ETabState::OpenedTab)
		->SetForegroundTab(FQuestObjectivesEditorTabs::QuestGraphID);


	// Default layout
	const TSharedRef<FTabManager::FLayout> StandaloneDefaultLayout = FTabManager::NewLayout("QuestObjectivesPropEditor_Layout_v2")
		->AddArea
		(
			FTabManager::NewPrimaryArea()
			->SetOrientation(Orient_Vertical)
			->Split
			(
				FTabManager::NewStack()
				->SetSizeCoefficient(0.05f)
				->SetHideTabWell(true)
				->AddTab(FQuestObjectivesEditorTabs::QuestToolBarID, ETabState::OpenedTab)
			)
			->Split
			(
				FTabManager::NewSplitter()
				->SetOrientation(Orient_Horizontal)
				->SetSizeCoefficient(0.95f)
				->Split
				(
					FTabManager::NewStack()
					->SetSizeCoefficient(0.3f)
					->SetHideTabWell(true)
					->AddTab(FQuestObjectivesEditorTabs::NavigationTab, ETabState::OpenedTab)
				)
				->Split
				(
					FTabManager::NewSplitter()->SetOrientation( Orient_Vertical )
					->Split
					(
						FTabManager::NewSplitter()
						->SetSizeCoefficient(0.8f)
						->Split
						(
							FTabManager::NewStack()
							->SetSizeCoefficient(0.6f)
							->AddTab(FQuestObjectivesEditorTabs::ChapterGraphID,ETabState::OpenedTab)
						)
						->Split
						(
							FTabManager::NewStack()
							->SetSizeCoefficient(0.6f)
							->AddTab(FQuestObjectivesEditorTabs::RingGraphID, ETabState::OpenedTab)
						)
					)
					->Split
					(
						FTabManager::NewStack()
						->SetSizeCoefficient( 0.20f )
						->AddTab( FQuestObjectivesEditorTabs::QuestFindResultsID, ETabState::OpenedTab )
					)
				)
				->Split
				(
					FTabManager::NewSplitter()
					->SetOrientation(Orient_Vertical)
					->SetSizeCoefficient(0.37f)
					->Split
					(
						FTabManager::NewSplitter()
						->SetOrientation(Orient_Horizontal)
						->SetSizeCoefficient(0.33f)
						->Split
						(
							FTabManager::NewStack()
							->SetSizeCoefficient(0.6f)
							->SetHideTabWell(true)
							->AddTab(FQuestObjectivesEditorTabs::DetailsID, ETabState::OpenedTab)
						)
					)
				)
			)
		);

	// Initialize the asset editor and spawn nothing (dummy layout)
	auto Template = StaticLoadObject(UObject::StaticClass(), NULL, TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestEditorInitObj.QuestEditorInitObj"));
	FoundObject = NewObject<UQuestObject>(Template, UQuestObject::StaticClass());
	FoundObject->AddToRoot();
	InitAssetEditor(Mode, InitToolkitHost, QuestObjectivesEditorAppName, StandaloneDefaultLayout, /*bCreateDefaultStandaloneMenu=*/ true, /*bCreateDefaultToolbar=*/ false, FoundObject.Get());

	RebuildLists(false);

	BindCommands();
	
	FKGQuestEditorModule& EditorModule = FModuleManager::GetModuleChecked<FKGQuestEditorModule>("KGQuestEditor");

	CachedQuestSubTargetMaxNumber = UKGQuestEditorSubSystem::Get().GetQuestSubTargetMaxNumber();

	//FString Action1Path = "/Game/Editor/QuestEditor/StructData/Structure/TargetParam/";

	//EditorModule.GetEDClassCollect()->ConvertStructToObjClass(UQuestActionBase::StaticClass(), Action1Path, Action1Path);

	// 容灾机制，设置定时器
	DisasterRecoveryBaseFolderPath = FPaths::ProjectSavedDir() + "C7Editor/Quests/";
	float DisasterRecoveryTimerRate = 60.0f;
	if (UQuestSettings* QuestSettings = GetMutableDefault<UQuestSettings>(UQuestSettings::StaticClass()))
	{
		DisasterRecoveryTimerRate = QuestSettings->DisasterRecoveryTimerRate;
	}
	GEditor->GetTimerManager()->SetTimer(
		DisasterRecoveryTimerHandle,
		FTimerDelegate::CreateRaw(this, &FQuestObjectivesEditor::DisasterRecoveryTask),
		DisasterRecoveryTimerRate, // 间隔秒数
		true    // 循环执行
	);
	
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Quest Editor Init End."));
}

void FQuestObjectivesEditor::DisasterRecoveryTask()
{
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Save Temp Quest File Start."));
	
	const FString ExportRingFolder = DisasterRecoveryBaseFolderPath + "Ring/";
	const FString ExportChapterFolder = DisasterRecoveryBaseFolderPath + "Chapter/";
	const FString TimeStampSuffix = FDateTime::Now().ToString(TEXT("__%Y%m%d_%H_%M_%S_%s"));

	//Export Ring
	{
		for (auto Ring : DataEntity->DirtyRings)
		{
			UQuestRing* RingData = Ring.Get();
			if (!RingData)
				continue;

			// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
			if (RingData->RingGraph == nullptr)
				PreRefreshRingGraph(RingData);

			TMap<FString, FString> ExPropertys;
			for (size_t i = 0; i < DataEntity->AllChapters.Num(); i++)
			{
				UQuestChapter* Chapter = DataEntity->AllChapters[i].Get();
				if (Chapter && RingData->ChapterID == Chapter->ChapterID)
				{
					ExPropertys.Add("ChapterName", Chapter->ChapterName);
					ExPropertys.Add("ChapterIndex", Chapter->ChapterIndex);
					break;
				}
			}

			FString ExportLuaString;
			// ParseSystemActions 会调用一个外部工具，很耗时（每次大约10s），容灾机制没必要
			ExportLuaString = FQuestLuaExporter::ExportRingData(RingData, &ExPropertys, false);
			if (ExportLuaString.IsEmpty())
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::DisasterRecoveryTask ExportRing Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
				continue;
			}

			FString ExportRingFilePath = ExportRingFolder + FString::FromInt(RingData->RingID) + TimeStampSuffix + ".lua";

			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ExportRingFilePath);

			if (!FFileHelper::SaveStringToFile(ExportLuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::DisasterRecoveryTask ExportRing SaveLua Error RingID %d ChapterID %d"), RingData->RingID, RingData->ChapterID);
				continue;
			}
			else
			{
				TempSaveFiles.Add(AbsolutePath);
			}
		}
	}

	//Export Chapter
	{
		for (auto Chapter : DataEntity->DirtyChapters)
		{
			UQuestChapter* ChapterData = Chapter.Get();
			if (!ChapterData)
				continue;

			// 因为lazy机制, 在GM批量导出等逻辑时存在标记为脏但没有加载Graph情况
			if (ChapterData->ChapterGraph == nullptr)
				PreRefreshChapterGraph(ChapterData);
			FString LuaString;
			LuaString = FQuestLuaExporter::ExportChapterData(ChapterData);
			if (LuaString.IsEmpty())
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::DisasterRecoveryTask ExportChapter Error ChapterID %d"), ChapterData->ChapterID);
				continue;
			}

			FString ChapterFilePath = ExportChapterFolder + FString::FromInt(ChapterData->ChapterID) + TimeStampSuffix + ".lua";

			const FString AbsolutePath = FPaths::ConvertRelativePathToFull(ChapterFilePath);

			if (!FFileHelper::SaveStringToFile(LuaString, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
			{
				UE_LOG(LogQuestObjectivesEditor, Error, TEXT("FQuestObjectivesEditor::DisasterRecoveryTask ExportChapter SaveLua Error ChapterID %d"), ChapterData->ChapterID);
				continue;
			}
			else
			{
				TempSaveFiles.Add(AbsolutePath);
			}
		}
	}
	
	UE_LOG(LogQuestObjectivesEditor, Log, TEXT("Save Temp Quest File End."));
}

FORCEINLINE TSharedPtr<class SQuestScrollWidget> FQuestObjectivesEditor::GetQuestScrollWidget() const
{
	return QuestScrollWidget; 
}

void FQuestObjectivesEditor::ShowObjectDetails(UObject* ObjectProperties)
{
	PropertyEditor->SetObject(ObjectProperties);
}


void SGraphEditor_QuestObjectives::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SGraphEditor::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
}

/** FGCObject interface */
void FQuestObjectivesEditor::AddReferencedObjects(FReferenceCollector& Collector)
{
	Collector.AddReferencedObject(DataEntity);
	//for(auto Obj : DataEntity->AllQuestObject)
	//{
	//	Collector.AddReferencedObject(Obj);
	//}
	//Collector.AddReferencedObjects(DataEntity->AllChapters);
	//Collector.AddReferencedObjects(DataEntity->AllQuestRings);
	//Collector.AddReferencedObjects(DataEntity->AllQuests);
}

#undef LOCTEXT_NAMESPACE

UE_ENABLE_OPTIMIZATION_SHIP