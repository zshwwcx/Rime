// Fill out your copyright notice in the Description page of Project Settings.


#include "QuestTemplate.h"
#include "EDGraph/Nodes/EDGraphNode_EntryNode.h"
#include "EDGraph/Graph/EventDrivenGraphSchema.h"
#include "EDGraph/Nodes/EDGraphNode_StateNode.h"
#include "FQuestObjectivesEditor.h"
#include "KGQuestEditorSubSystem.h"
#include "QuestObjectDataEntity.h"
#include "QuestSettings.h"
#include "3C/Animation/AnimAssetDefine.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"
//#include "SceneInstrumentTemplate.h"

#define LOCTEXT_NAMESPACE "QuestTemplate"

UE_DISABLE_OPTIMIZATION_SHIP

DEFINE_LOG_CATEGORY_STATIC(LogQuestTemplate, Log, All);

//bool UQuestCondition::ExecuteConditionFunctionImp()
//{
//	bool Ret = ExecuteConditionFunction();
//	Ret = bIsNot ? !Ret : Ret;
//	return Ret;
//}

//bool UQuestConditionOR::ExecuteConditionFunctionImp()
//{
//	bool Ret = false;
//	int Num = QuestConditionsArray.Num();
//	if (Num > 0)
//	{
//		for (int i = 0; i < Num; i++)
//		{
//			if (QuestConditionsArray[i]->ExecuteConditionFunctionImp())
//			{
//				Ret = true;
//				break;
//			}
//		}
//	}
//	Ret = bIsNot ? !Ret : Ret;
//	return Ret;
//}
//
//bool UQuestConditionAND::ExecuteConditionFunctionImp()
//{
//	bool Ret = false;
//	int Num = QuestConditionsArray.Num();
//	if (Num > 0)
//	{
//		Ret = true;
//		for (int i = 0; i < Num; i++)
//		{
//			if (!QuestConditionsArray[i]->ExecuteConditionFunctionImp())
//			{
//				Ret = false;
//				break;
//			}
//		}
//	}
//
//	Ret = bIsNot ? !Ret : Ret;
//	return Ret;
//}

#if WITH_EDITOR
UQuestChapter::UQuestChapter()
{
	bQuestTypeEditable = true;
}

FQuestObjectivesEditor* UQuestChapter::GetQuestEditor() const
{
	if (UEDGraphBase* ChapterGraphBase = Cast<UEDGraphBase>(ChapterGraph))
	{
		auto CurEditor = ChapterGraphBase->QuestObjectivesEditor;
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
		{
			return QuestEditor;
		}
	}
	return nullptr;
}

void UQuestChapter::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property == nullptr)
		return;

	UE_LOG(LogQuestTemplate, Log, TEXT("UQuestChapter PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());

	OnPropertyChangedToBp();
	QuestObjectName = ChapterName;
	OnRefreshChapter.Broadcast();
	if(PropertyChangedEvent.Property->GetName() == "QuestType" || PropertyChangedEvent.Property->GetName() == "ChapterName")
	{
		if (UEDGraphBase* ChapterGraphBase = Cast<UEDGraphBase>(ChapterGraph))
		{
			auto CurEditor = ChapterGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				for(auto Child : Children)
				{
					Child->QuestType = QuestType;
					if(auto Ring = Cast<UQuestRing>(Child))
					{
						QuestEditor->MarkAssetForDirty(Ring);
						for(auto C : Ring->Children)
						{
							C->QuestType = QuestType;
							if(auto Quest = Cast<UQuest>(C))
							{
								QuestEditor->MarkAssetForDirty(Quest);
							}
						}
					}
				}
				if(PropertyChangedEvent.Property->GetName() == "QuestType")
				{
					QuestEditor->OnChapterTypeChanged(this);
				}
			}
		}
	}
	else if (PropertyChangedEvent.Property->GetName() == GET_MEMBER_NAME_CHECKED(UQuestChapter, ChapterID))
	{
		FText CheckDialog;
		if (CheckChapterID(CheckDialog))
		{
			// 检查通过
			if (auto QuestEditor = GetQuestEditor())
			{
				// 保证 map 里都是新 id 到 obj 的映射
				// QuestObjectID 应保持在 map 里，防止其他任务改成当前任务的 QuestObjectID
				if (OldQuestObjectID != QuestObjectID)
				{
					QuestEditor->RemoveInDataEntityMap(OldQuestObjectID);
				}
				QuestEditor->AddInDataEntityMap(this);

				QuestEditor->GetDataEntity()->DirtyChapters.Add(this);

				// 更改id后，刷新一下左侧chapter的列表顺序
				QuestEditor->RefreshQuestObjectTree();
			}
		}
		else
		{
			FMessageDialog::Open(EAppMsgType::Ok, CheckDialog);

			if (auto QuestEditor = GetQuestEditor())
			{
				// 复原这次修改
				QuestEditor->RemoveInDataEntityMap(OldQuestObjectID);
				ChapterID = QuestObjectID;
				QuestEditor->AddInDataEntityMap(this);
			}
		}
	}
	else
	{
		if (UEDGraphBase* ChapterGraphBase = Cast<UEDGraphBase>(ChapterGraph))
		{
			auto CurEditor = ChapterGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				// 如果 Chapter 的属性在 Ring 里也存在（这里通过属性名相同来判断），则进一步判断是否要替换所有 Ring 里的属性
				for (TFieldIterator<FProperty> PropertyIt(UQuestRing::StaticClass()); PropertyIt; ++PropertyIt)
				{
					FProperty* TargetProperty = *PropertyIt;
					FProperty* SourceProperty = PropertyChangedEvent.Property;
					if (TargetProperty && (TargetProperty->GetName() == SourceProperty->GetName()))
					{
						// 白名单过滤
						if (!UKGQuestEditorSubSystem::Get().ChapterToRingProperties.Contains(TargetProperty->GetName()))
						{
							continue;
						}
						
						// 弹窗判断是否要替换
						// Found the property, ask for user confirmation
						FText DialogText = LOCTEXT("ReplacePropertyDialog", "Property exists in UQuestRing. Do you want to replace it?");

						EAppReturnType::Type DialogResult = FMessageDialog::Open(EAppMsgType::YesNo, DialogText);

						if (DialogResult == EAppReturnType::Yes)
						{
							// Replace property value
							void* SourceValue = SourceProperty->ContainerPtrToValuePtr<void>(this);
							for(auto Child : Children)
							{
								Child->QuestType = QuestType;
								if(auto Ring = Cast<UQuestRing>(Child))
								{
									void* TargetValue = TargetProperty->ContainerPtrToValuePtr<void>(Ring);
									if (SourceValue && TargetValue)
									{
										TargetProperty->CopyCompleteValue(TargetValue, SourceValue);
										QuestEditor->MarkAssetForDirty(Ring);

										if (PropertyChangedEvent.Property->GetName() == TEXT("RingName"))
										{
											QuestEditor->OnRefreshRingName();
											Ring->OnRefreshRingname.Broadcast();
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

void UQuestChapter::PreEditChange(FProperty* PropertyAboutToChange)
{
	Super::PreEditChange(PropertyAboutToChange);

	if (PropertyAboutToChange && PropertyAboutToChange->GetFName() == GET_MEMBER_NAME_CHECKED(UQuestChapter, ChapterID))
	{
		OldQuestObjectID = ChapterID;
	}
}

FQuestObjectivesEditor* UQuestRing::GetQuestEditor() const
{
	if (UEDGraphBase* RingGraphBase = Cast<UEDGraphBase>(RingGraph))
	{
		auto CurEditor = RingGraphBase->QuestObjectivesEditor;
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
		{
			return QuestEditor;
		}
	}
	return nullptr;
}

void UQuestRing::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property == nullptr)
		return;
	
	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("UQuestRing PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}

	OnPropertyChangedToBp();
	if(PropertyChangedEvent.Property->GetName() == TEXT("ConditionFlowChart"))
	{
		if(!ConditionFlowChart.Path.StartsWith("Execution.Conditions"))
		{
			FText ErrMessage = FText::FromString("Should start with \"Execution.Conditions\"");
			FMessageDialog::Open(EAppMsgType::Ok ,ErrMessage);
			ConditionFlowChart.Path = "";
		}
	}
	if (PropertyChangedEvent.Property->GetName() == TEXT("MainTag") || PropertyChangedEvent.Property->GetName() == TEXT("SubTagFirst")
		|| PropertyChangedEvent.Property->GetName() == TEXT("SubTagSecond"))
	{
		if(MainTag.Len()>4)
		{
			MainTag = MainTag.Left(4);
		}
		if(SubTagFirst.Len()>4)
		{
			SubTagFirst = SubTagFirst.Left(4);
		}
		if(SubTagSecond.Len()>4)
		{
			SubTagSecond = SubTagSecond.Left(4);
		}
	}

	if(PropertyChangedEvent.Property->GetName() == TEXT("RingID"))
	{
		// 检查 RingID 是否重复，是否在合法区间
		FText CheckDialog;
		if (CheckRingID(CheckDialog))
		{
			if (auto QuestEditor = GetQuestEditor())
			{
				// 保证 map 里都是新 id 到 obj 的映射
				if (OldQuestObjectID != QuestObjectID)
				{
					QuestEditor->RemoveInDataEntityMap(OldQuestObjectID);
				}
				QuestEditor->AddInDataEntityMap(this); // 在map里添加新的id，即 ringid
				// 手动添加到 Dirty，否则 MarkAssetForDirty 会生成新的文件，我们希望到保存时再生成
				QuestEditor->GetDataEntity()->DirtyRings.Add(this);
			}
			
			// 检查通过
			OnChangeRingID();
		}
		else
		{
			FMessageDialog::Open(EAppMsgType::Ok, CheckDialog);

			if (auto QuestEditor = GetQuestEditor())
			{
				// 复原这次修改
				QuestEditor->RemoveInDataEntityMap(OldQuestObjectID);
				RingID = QuestObjectID;
				QuestEditor->AddInDataEntityMap(this);
			}

			OnChangeRingID();
		}
	}
	
#if WITH_EDITORONLY_DATA
	QuestObjectName = RingName;
	if (UEDGraphBase* RingGraphBase = Cast<UEDGraphBase>(RingGraph))
	{
		auto CurEditor = RingGraphBase->QuestObjectivesEditor;
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
		{
			if (PropertyChangedEvent.Property->GetName() == TEXT("RingName"))
			{
				QuestEditor->OnRefreshRingName();
				OnRefreshRingname.Broadcast();
			}
			QuestEditor->MarkAssetForDirty(this);
		}
	}
#endif
}

void UQuestRing::PreEditChange(FProperty* PropertyAboutToChange)
{
	Super::PreEditChange(PropertyAboutToChange);

	if (PropertyAboutToChange && PropertyAboutToChange->GetFName() == GET_MEMBER_NAME_CHECKED(UQuestRing, RingID))
	{
		OldQuestObjectID = RingID;
	}
}

void UQuest::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) 
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property == nullptr)
		return;

	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("UQuest PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}

	OnPropertyChangedToBp();
	QuestObjectName = QuestName;
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			if (PropertyChangedEvent.Property->GetName() == TEXT("MainTarget"))
			{
				if(MainTargetTraceCombo.Num() > 0 && MainTarget && PropertyChangedEvent.ChangeType == EPropertyChangeType::ValueSet)
				{
					auto Reply = FMessageDialog::Open(EAppMsgType::YesNo , LOCTEXT("ChangeTraceParamConfirm", "Do you want to change trace param for trace combo to default trace param of new Main target?"));
					if(Reply == EAppReturnType::Yes)
					{
						MainTargetTraceCombo[0].TraceParam = MainTarget->TraceParam;
					}
				}
			}
			if (PropertyChangedEvent.Property->GetName() == TEXT("QuestName") || PropertyChangedEvent.Property->GetName() == TEXT("MainTarget")
				|| PropertyChangedEvent.Property->GetName() == TEXT("Desc")
				|| PropertyChangedEvent.Property->GetName() == TEXT("MainTargetTraceCombo")) // 可能是复制属性的方式
			{
				QuestEditor->OnRefreshQuestName();
				OnRefreshQuestName.Broadcast();
			}
			
			QuestEditor->MarkAssetForDirty(this);
		}
	}
	if(MainTarget)
	{
		MainTarget->bIsMain = true;
	}
	if (PropertyChangedEvent.Property->GetName() == GET_MEMBER_NAME_CHECKED(UQuest, QuestTargets))
	{
		int32 MaxQuestTargetsNum = 0;
		if (QuestObjectivesEditor.IsValid())
		{
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
			{
				MaxQuestTargetsNum = QuestEditor->GetCachedQuestSubTargetMaxNumber();
			}
		}
		if (MaxQuestTargetsNum != 0 && QuestTargets.Num() > MaxQuestTargetsNum)
		{
			QuestTargets.SetNum(MaxQuestTargetsNum);
			const FText NotificationText = FText::FromString(FString::Printf(TEXT("任务子目标数量不允许超过%d个"), MaxQuestTargetsNum));
			FNotificationInfo Info(NotificationText);
			Info.ExpireDuration = 5.0f;
			FSlateNotificationManager::Get().AddNotification(Info);		
		}

		// 目标描述文本, 和 PreEditChange 配合
		FString QuestTargetBPBaseClassPath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestTargetBPBase.QuestTargetBPBase_C");
		UClass* QuestTargetBPBaseClass = StaticLoadClass(UObject::StaticClass(), nullptr, *QuestTargetBPBaseClassPath);
		FObjectProperty* TraceParamProperty = CastField<FObjectProperty>(QuestTargetBPBaseClass->FindPropertyByName(TEXT("TraceParam")));
		FStrProperty* DescStringProperty = CastField<FStrProperty>(QuestTargetBPBaseClass->FindPropertyByName(TEXT("Desc")));
		if (TraceParamProperty && DescStringProperty)
		{
			for (int32 TargetIndex = 0; TargetIndex < QuestTargets.Num(); TargetIndex++)
			{
				if (EmptyTraceParamTargetIndex.Contains(TargetIndex))
				{
					UQuestTargetBase* QuestTarget = QuestTargets[TargetIndex];
					if (!QuestTarget) continue;

					UTaskTargetTrace* TraceParamValue = Cast<UTaskTargetTrace>(TraceParamProperty->GetPropertyValue_InContainer(QuestTarget));

					if (TraceParamValue)
					{
						// 说明这一次 TraceParam 从 null 变到有值，此时要尝试给对应的 Desc 添加富文本描述
						FString DescValue = DescStringProperty->GetPropertyValue_InContainer(QuestTarget);
						if (!DescValue.Contains(TEXT("<h>")) && !DescValue.Contains(TEXT("</>")))
						{
							DescValue.Append(TEXT("<h></>"));
							DescStringProperty->SetPropertyValue_InContainer(QuestTarget, DescValue);

							OnRefreshQuestName.Broadcast();
						}
					}
				}
			}
		}
	}
	if (PropertyChangedEvent.Property->GetName() == GET_MEMBER_NAME_CHECKED(UQuest, QuestID))
	{
		bool bChangeable = false;
		if (QuestObjectivesEditor.IsValid())
		{
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
			{
				FString QuestIDStr = FString::FromInt(QuestID);
				FString RingIDStr = FString::FromInt(RingID);
				if (!QuestIDStr.StartsWith(RingIDStr))
				{
					const FString Dialog = FString::Printf(TEXT("任务步骤[%d]前缀与其所属任务[%d]的ID不一致，请调整后再做尝试。"), QuestID, RingID);
					FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Dialog));
				}
				else if (QuestIDStr.Len() != RingIDStr.Len() + 2)
				{
					const FString Dialog = FString::Printf(TEXT("任务步骤ID[%d]后两位不符合ID规则，请调整到00到99范围内再做尝试。"), QuestID);
					FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Dialog));
				}
				else if (QuestEditor->GetDataEntity()->QuestMap.Contains(QuestID))
				{
					const FString Dialog = FString::Printf(TEXT("任务步骤ID[%d]被其他任务步骤使用，请调整后再做尝试。"), QuestID);
					FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Dialog));
				}
				else
				{
					// 检查通过
					bChangeable = true;
					// 保证 map 里都是新 id 到 obj 的映射
					if (OldQuestObjectID != QuestObjectID)
					{
						QuestEditor->RemoveInDataEntityMap(OldQuestObjectID);
					}
					QuestEditor->AddInDataEntityMap(this); // 在map里添加新的id
					OnRefreshQuestName.Broadcast();

					// 手动添加到 Dirty，否则 MarkAssetForDirty 会生成新的文件
					QuestEditor->GetDataEntity()->DirtyQuests.Add(this);
				}
			}
		}
		if (!bChangeable)
		{
			if (FQuestObjectivesEditor* QuestEditor = GetQuestEditor())
			{
				// 复原这次修改
				QuestEditor->RemoveInDataEntityMap(OldQuestObjectID);
				QuestID = QuestObjectID;
				QuestEditor->AddInDataEntityMap(this); // 在map里添加新的id
			}
			OnRefreshQuestName.Broadcast();
		}
	}
}

void UQuestRing::NotifyQuestEditor()
{
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			QuestEditor->MarkCurChapterForDirty();
		}
	}
}

bool UQuestRing::CanEditChange(const FProperty* InProperty) const
{
	if (InProperty)
	{
		if (!GetMutableDefault<UQuestSettings>()->bSystemActionEnable)
		{
			FString PropertyName = InProperty->GetName();
			if (PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UQuestRing, ApplySystemActions)
				|| PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UQuestRing, SubmitSystemActions)
				|| PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UQuestRing, AbandonSystemActions))
			{
				return false;
			}
		}
	}
	return Super::CanEditChange(InProperty);
}

void UQuest::NotifyQuestEditor() 
{
	// 这里需要注意, Quest的位置信息是存在Ring的RingGraph上的
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			QuestEditor->MarkCurRingForDirty();
		}
	}
}

void UQuest::NotifyQuestEditorForSelf() 
{
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			QuestEditor->MarkAssetForDirty(this);
		}
	}
}

void UQuest::NextTaskInfoNotifyQuestEditor() 
{
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			if (!QuestEditor->bLoadingRingGraph)
				QuestEditor->MarkAssetForDirty(this);
		}
	}
}

bool UQuest::CanEditChange(const FProperty* InProperty) const
{
	if (InProperty)
	{
		if (!GetMutableDefault<UQuestSettings>()->bSystemActionEnable)
		{
			FString PropertyName = InProperty->GetName();
			if (PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UQuest, BeginSystemActions)
				|| PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UQuest, EndSystemActions)
				|| PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UQuest, FailSystemActions))
			{
				return false;
			}
		}
	}
	return Super::CanEditChange(InProperty);
}

void UCreateQuestEdit::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property == nullptr)
		return;

	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("UCreateQuestEdit PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}

	if (PreQuest.IsValid())
	{
		const FName PreSelectTargetsPropertyName = GET_MEMBER_NAME_CHECKED(UCreateQuestEdit, PreSelectTargets);
		if (PropertyChangedEvent.Property && PropertyChangedEvent.Property->GetFName() == PreSelectTargetsPropertyName)
		{
			bool bCopyDesc = true;
			if (PreSelectTargets.Num() > 0)
			{
				for (UQuestTargetBase* PreCreateTarget : PreSelectTargets)
				{
					if (bCopyDesc && PreCreateTarget!=nullptr)
					{
						bCopyDesc = false;
						if (FProperty* targetProperty = PreCreateTarget->GetClass()->FindPropertyByName(TEXT("Desc")))
						{
							FString* Desc = targetProperty->ContainerPtrToValuePtr<FString>(PreCreateTarget);
							if (Desc->IsEmpty())
							{
								targetProperty->CopyCompleteValue(targetProperty->ContainerPtrToValuePtr<void>(PreCreateTarget), &PreQuest->QuestName);
							}
						}
					}
				}
			}
		}
	}
}

void UQuestTargetBase::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property == nullptr)
		return;

	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("UQuestTargetBase PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}

	OnPropertyChangedToBp();
	
	OnRefreshImportantData.Broadcast();

	NotifyQuestEditor();
}

void UQuestTargetBase::PostInitProperties()
{
	Super::PostInitProperties();

	OnPropertyChangedToBp();
}

void UQuestTargetBase::NotifyQuestEditor()
{
	if (QuestGraph.IsValid())
	{
		if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(QuestGraph))
		{
			auto CurEditor = QuestGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				QuestEditor->MarkCurQuestForDirty();
			}
		}
	}
}

UQuestActionBase* UQuestTargetBase::GetActionInstanceFromEvent(int32 Event)
{
	if (Event <= 0 || !QuestGraph.IsValid())
		return nullptr;
	
	FString BPFilePath = FPaths::ConvertRelativePathToFull(FPaths::EngineDir() / TEXT("../Client/Content/Editor/QuestEditor/TemplatePart/QuestAction"));
	TArray<FString> Files;
	IFileManager::Get().FindFiles(Files, *BPFilePath, TEXT("*.uasset"));

	for (const FString& File : Files)
	{
		FString FileName = FPaths::GetBaseFilename(File, true);
		FString AssetPath = FPaths::Combine(TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestAction"), FileName);
		AssetPath = AssetPath + TEXT(".") + FileName;
		FSoftObjectPath AssetRef(AssetPath);
		UObject* Obj = AssetRef.ResolveObject();
		if (Obj == nullptr)
		{
			Obj = AssetRef.TryLoad();
		}
		UClass* Class = Obj->GetClass();
		if (UBlueprint* BPObj = Cast<UBlueprint>(Obj))
		{
			Class = BPObj->GeneratedClass;
		}
		
		UQuestActionBase* QuestAction = NewObject<UQuestActionBase>(QuestGraph.Get(), Class);

		if (QuestAction && (QuestAction->Event == Event))
			return QuestAction;
	}

	return nullptr;
}

void UQuestTargetBase::OnAutoCreateNode()
{
	// 根据不同的Target节点自动创建对应的Action节点
	if (!QuestGraph.IsValid())
		return;

	// 根据配置生成Action节点
	UQuestActionBase* QuestAction = GetActionInstanceFromEvent(GetAutoCreateNodeEvent());

	// 根据配置拷贝数据给Action节点
	TMap<FString, FString> PropTable = GetAutoCreatePropTable();
	for (auto& Elem : PropTable)
	{
		for (TFieldIterator<FProperty> It(this->GetClass(), EFieldIteratorFlags::ExcludeSuper); It; ++It)
		{
			if (FProperty* ObjProperty = CastField<FProperty>(*It))
			{
				const FString& PropertyName = ObjProperty->GetName();
				if (PropertyName.Equals(Elem.Key))
				{
					for (TFieldIterator<FProperty> It_Tar(QuestAction->GetClass(), EFieldIteratorFlags::ExcludeSuper); It_Tar; ++It_Tar)
					{
						if (FProperty* TarObjProperty = CastField<FProperty>(*It_Tar))
						{
							const FString& TarPropertyName = TarObjProperty->GetName();
							if (TarPropertyName.Equals(Elem.Value))
							{
								if (ObjProperty->GetClass() == TarObjProperty->GetClass())
								{
									auto PropertySrc = ObjProperty->ContainerPtrToValuePtr<void>(this);
									auto PropertyDest = TarObjProperty->ContainerPtrToValuePtr<void>(QuestAction);
									TarObjProperty->CopyCompleteValue(PropertyDest, PropertySrc);	
								}
							}
						}
					}
				}
			}
		}
	}

	if (QuestAction == nullptr)
		return;
	
	if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(QuestGraph))
	{
		UEDGraphNode_EntryNode* BeginNode = nullptr;
		for (TObjectPtr<class UEdGraphNode>& GraphNode : QuestGraph->Nodes)
		{
			if (!GraphNode)
				continue;
			if (UEDGraphNode_EntryNode* ActionStateNode = Cast<UEDGraphNode_EntryNode>(GraphNode))
			{
				if (ActionStateNode->NodeType == EDNodeType::QuestBegin)
				{
					BeginNode = ActionStateNode;
					break;
				}
			}
		}

		if (BeginNode == nullptr)
			return;

		const UEdGraphSchema* Schema = QuestGraph->GetSchema();
		if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
		{
			FVector2D NewPlacePos = FVector2D(BeginNode->NodePosX + 150, BeginNode->NodePosY + 200);
			ThisSchema->CreateActionNode(QuestGraphBase, QuestAction, BeginNode->GetOutputPin(), NewPlacePos);
		}
	}
}

UQuestActionBase::UQuestActionBase(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{
	bDefaultObj = HasAnyFlags(RF_ClassDefaultObject);
}

void UQuestActionBase::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property == nullptr)
		return;

	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("UQuestActionBase PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}

	// 如果填写了相应对象的InstanceID，那么能从InstanceID追溯到它的NpcID、MonsterID或者是玩家，最终定位到该对象的动作库配置数据，获取动作的枚举名（没有枚举名的就获取英文名）
	// 101 - 指定对象播动作 - QA_PLAY_ANIMATION_BY_INSTANCEID
	// 176 - 指定对象播动作（可存档） - QA_SET-ANIMATION
	if (Event == 101 || Event == 176)
	{
		UClass* Class = this->GetClass();
		if (Class)
		{
			// 查找变量
			FProperty* InstanceIDProperty = FindFProperty<FProperty>(Class, "InstanceID");
			FProperty* AnimationNameProperty = FindFProperty<FProperty>(Class, "AnimationName");
			if (InstanceIDProperty && AnimationNameProperty)
			{
				void* InstanceIDValuePtr = InstanceIDProperty->ContainerPtrToValuePtr<void>(this);
				FString InstanceIDStr = *static_cast<FString*>(InstanceIDValuePtr);

				if (!InstanceIDStr.IsEmpty())
				{
					void* AnimationNameValuePtr = AnimationNameProperty->ContainerPtrToValuePtr<void>(this);
					FAnimLibAssetID* AnimLibAssetID = static_cast<FAnimLibAssetID*>(AnimationNameValuePtr);
					if (AnimLibAssetID)
					{
						FString AnimAssetID = UKGQuestEditorSubSystem::Get().GetAnimAssetID(InstanceIDStr);
						if (!AnimAssetID.IsEmpty())
						{
							AnimLibAssetID->SetAnimID(AnimAssetID);
						}
					}
				}
			}
		}
	}

	OnPropertyChangedToBp();

	OnRefreshImportantData.Broadcast();

	NotifyQuestEditor();
}

void UQuestActionBase::PostInitProperties()
{
	Super::PostInitProperties();

	OnPropertyChangedToBp();
}

void UQuestActionBase::NotifyQuestEditor()
{
	if (QuestGraph.IsValid())
	{
		if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(QuestGraph))
		{
			auto CurEditor = QuestGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				QuestEditor->MarkCurQuestForDirty();
			}
		}
	}
}

UQuestTargetBase::UQuestTargetBase(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{
	bDefaultObj = HasAnyFlags(RF_ClassDefaultObject);
}

void UQuestProgressBase::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property == nullptr)
		return;

	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("UQuestProgressBase PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}

	NotifyQuestEditor();
}

void UQuestProgressBase::NotifyQuestEditor()
{
	if (QuestGraph.IsValid())
	{
		if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(QuestGraph))
		{
			auto CurEditor = QuestGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				QuestEditor->MarkCurQuestForDirty();
			}
		}
	}
}

void UQuestEndBase::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property == nullptr)
		return;

	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("UQuestEndBase PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}

	NotifyQuestEditor();
}

void UQuestEndBase::NotifyQuestEditor()
{
	if (QuestGraph.IsValid())
	{
		if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(QuestGraph))
		{
			auto CurEditor = QuestGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				QuestEditor->MarkCurQuestForDirty();
			}
		}
	}
}

void URingTaskConditionBase::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property == nullptr)
		return;

	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("URingTaskConditionBase PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}

	const FName AndConditionsPropertyName = GET_MEMBER_NAME_CHECKED(FRingTaskAndConditions, AndConditions);
	
	if (PropertyChangedEvent.Property && PropertyChangedEvent.Property->GetFName() == AndConditionsPropertyName)
	{
		for (FRingTaskAndConditions& AndConditions : OrConditions)
		{
			// 检查AndConditions是否包含空的URingTaskConditionClass
			for (int32 Index = 0; Index < AndConditions.AndConditions.Num(); Index++)
			{
				URingTaskConditionClass*& Condition = AndConditions.AndConditions[Index];
				if (!Condition)
				{
					// 新建一个URingTaskConditionClass实例
					Condition = NewObject<URingTaskConditionClass>(this);

					// 设置它的默认值
					Condition->Variable = ERingTaskConditionType::ClassID;
					Condition->CompareType = ERingTaskCompareType::Equal;
					Condition->Value = 0;
				}
			}
		}
	}
	
    UObject* CurrentParent = GetOuter();
    while (CurrentParent)
    {
        UQuest* ParentQuest = Cast<UQuest>(CurrentParent);
        if (ParentQuest)
        {
            ParentQuest->NotifyQuestEditorForSelf();
        	break;
        }

		if(auto ParentRing = Cast<UQuestRing>(CurrentParent))
		{
			ParentRing->NextTaskInfoNotifyQuestEditor();
			break;
		}
    	
    	if(CurrentParent == nullptr)
    		break;
        CurrentParent = CurrentParent->GetOuter();
    }
}

void FGameplayID::GetDataSource(TArray<TSharedPtr<FString>>* &OutData)
{
}

void FDialogueID::GetDataSource(TArray<TSharedPtr<FString>>* &OutData)
{
	OutData = UKGQuestEditorSubSystem::Get().GetDialogueIDData();
}

void FNPCID::GetDataSource(TArray<TSharedPtr<FString>>*& OutData)
{
	OutData = UKGQuestEditorSubSystem::Get().GetNPCIDData();
}

void FItemID::GetDataSource(TArray<TSharedPtr<FString>>*& OutData)
{
	OutData = UKGQuestEditorSubSystem::Get().GetItemIDData();
}

void FTaskCollectID::GetDataSource(TArray<TSharedPtr<FString>>*& OutData)
{
	OutData = UKGQuestEditorSubSystem::Get().GetTaskCollectData();
}

void FItemSubmitID::GetDataSource(TArray<TSharedPtr<FString>>*& OutData)
{
	OutData = UKGQuestEditorSubSystem::Get().GetItemSubmitIDData();
}

void FMonsterID::GetDataSource(TArray<TSharedPtr<FString>>*& OutData)
{
	OutData = UKGQuestEditorSubSystem::Get().GetMonsterIDData();
}

void FOptionTextID::GetDataSource(TArray<TSharedPtr<FString>>*& OutData)
{
	OutData = UKGQuestEditorSubSystem::Get().GetOptionTextIDData();
}

void URingTaskConditionClass::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("URingTaskConditionClass PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}
	if(Variable == ERingTaskConditionType::FlowChartResult)
	{
		if(PropertyChangedEvent.Property->GetName() == "FlowChartPath")
        {
        	if(!FlowChartPath.Path.StartsWith("Execution.Conditions"))
        	{
        		FText ErrMessage = FText::FromString("Should start with \"Execution.Conditions\"");
        		FMessageDialog::Open(EAppMsgType::Ok ,ErrMessage);
        		FlowChartPath.Path = "";
        	}
			Key = FlowChartPath.Path;
        }
	}
}

UQuestObject::UQuestObject()
{
#if WITH_EDITOR
	SetFlags(RF_Transactional);
#endif
}

void UQuestObject::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	
}

void UInteractiveQuestCondition::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void DoSetParamVisible(UObject* Target, FName PropertyName, bool bVisible)
{
	if (FProperty* Prop = Target->GetClass()->FindPropertyByName(PropertyName))
	{
		if (bVisible)
		{
			Prop->SetMetaData("EditCondition", "true");
			Prop->SetMetaData("EditConditionHides", "false");	
		}
		else
		{
			Prop->SetMetaData("EditCondition", "false");
			Prop->SetMetaData("EditConditionHides", "true");
		}
	}
}

void UQuestChapter::SetParamVisible(FName PropertyName, bool bVisible)
{
	DoSetParamVisible(this, PropertyName, bVisible);
}

bool UQuestChapter::CheckChapterID(FText& OutCheckDialog, bool bCheckMap)
{
	FQuestObjectivesEditor* QuestEditor = GetQuestEditor();
	if (!QuestEditor)
	{
		OutCheckDialog = FText::Format(LOCTEXT("QuestChapterGetQuestEditorError", "章节为{0}，无法获取 QuestEditor。"), FText::FromString(FString::FromInt(ChapterID)));
		return false;
	}

	if (UQuestObjectDataEntity* DataEntity = QuestEditor->GetDataEntity())
	{
		int32 MinChapterID = 0;
		int32 MaxChapterIDLimit = 0;
		QuestEditor->GetChapterIDRange(QuestType, MinChapterID, MaxChapterIDLimit);

		if (ChapterID < MinChapterID || ChapterID > MaxChapterIDLimit)
		{
			const FText QuestTypeName = StaticEnum<EQuestType>()->GetDisplayNameTextByValue(int64(QuestType));
			OutCheckDialog = FText::Format(
				LOCTEXT("ChapterIDRangeError", "章节为{0}，其ID[{1}]并不在[{2}, {3}]范围内，请修改之后再做尝试。"),
				QuestTypeName,
				FText::FromString(FString::FromInt(ChapterID)), // 用int32类型会带分隔符，如 600000 会显示为 600,000 ，因此转为字符串类型
				FText::FromString(FString::FromInt(MinChapterID)),
				FText::FromString(FString::FromInt(MaxChapterIDLimit))
			);
			return false;
		}
		else if (bCheckMap && DataEntity->ChapterMap.Contains(ChapterID))
		{
			OutCheckDialog = FText::Format(
				LOCTEXT("ChapterIDBeUsedError", "章节ID[{0}]被其他章节使用，请调整后再做尝试。"),
				FText::FromString(FString::FromInt(ChapterID))
			);
			return false;
		}

		return true;
	}

	OutCheckDialog = FText::Format(LOCTEXT("QuestChapterGetDataEntityError", "章节为{0}，无法获取 DataEntity。"), FText::FromString(FString::FromInt(ChapterID)));
	return false;
}

UPreRingID::UPreRingID()
{
	Type = 1;
}

UAndRelation::UAndRelation()
{
	Type = 2;
}

UOrRelation::UOrRelation()
{
	Type = 3;
}

#if WITH_EDITOR
void UChapterEnd::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.Property)
	{
		UE_LOG(LogQuestTemplate, Log, TEXT("UChapterEnd PostEditChangeProperty: %s."), *PropertyChangedEvent.Property->GetName());
	}
	
	OnChapterEndChanged.Broadcast();
	NotifyEditorChapterEndChange();
}

void UChapterEnd::NotifyEditorChapterEndChange()
{
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			if (!QuestEditor->bLoadingRingGraph)
				QuestEditor->MarkAssetForDirty(Father);
		}
	}
}
#endif

void UQuestRing::NextTaskInfoNotifyQuestEditor()
{
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			if (!QuestEditor->bLoadingRingGraph)
				QuestEditor->MarkAssetForDirty(this);
		}
	}
}

void UQuestRing::SetParamVisible(FName PropertyName, bool bVisible)
{
	DoSetParamVisible(this, PropertyName, bVisible);
#if WITH_EDITORONLY_DATA
	if (UEDGraphBase* RingGraphBase = Cast<UEDGraphBase>(RingGraph))
	{
		auto CurEditor = RingGraphBase->QuestObjectivesEditor;
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
		{
			QuestEditor->OnRefreshPropertyEditor(this);
		}
	}
#endif
}

void UQuestRing::OnChangeRingID()
{
	if (FQuestObjectivesEditor* QuestEditor = GetQuestEditor())
	{
		QuestEditor->OnRefreshRingName();
		OnRefreshRingname.Broadcast();

		QuestEditor->FlushQuestsAfterRingIDChange(this);
	}
}

bool UQuestRing::CheckRingID(FText& OutCheckDialog, bool bCheckMap)
{
	FQuestObjectivesEditor* QuestEditor = GetQuestEditor();
	if (!QuestEditor)
	{
		OutCheckDialog = FText::Format(LOCTEXT("QuestRingGetQuestEditorError", "任务为{0}，无法获取 QuestEditor。"), FText::FromString(FString::FromInt(RingID)));
		return false;
	}

	if (UQuestObjectDataEntity* DataEntity = QuestEditor->GetDataEntity())
	{
		int32 MinRingID = 0;
		int32 MaxRingIDLimit = 0;
		QuestEditor->GetRingIDRange(QuestType, MinRingID, MaxRingIDLimit);

		if (RingID < MinRingID || RingID > MaxRingIDLimit)
		{
			const FText QuestTypeName = StaticEnum<EQuestType>()->GetDisplayNameTextByValue(int64(QuestType));
			OutCheckDialog = FText::Format(
				LOCTEXT("RingIDRangeError", "任务为{0}，其ID[{1}]并不在[{2}, {3}]范围内，请修改之后再做尝试。"),
				QuestTypeName,
				FText::FromString(FString::FromInt(RingID)), // 用int32类型会带分隔符，如 600000 会显示为 600,000 ，因此转为字符串类型
				FText::FromString(FString::FromInt(MinRingID)),
				FText::FromString(FString::FromInt(MaxRingIDLimit))
			);
			return false;
		}
		else if (bCheckMap && DataEntity->RingMap.Contains(RingID))
		{
			OutCheckDialog = FText::Format(
				LOCTEXT("RingIDBeUsedError", "任务ID[{0}]被其他任务使用，请调整后再做尝试。"),
				FText::FromString(FString::FromInt(RingID))
			);
			return false;
		}

		return true;
	}

	OutCheckDialog = FText::Format(LOCTEXT("QuestRingGetDataEntityError", "任务为{0}，无法获取 DataEntity。"), FText::FromString(FString::FromInt(RingID)));
	return false;
}

void UQuestActionBase::SetParamVisible(FName PropertyName, bool bVisible)
{
	DoSetParamVisible(this, PropertyName, bVisible);
	if (QuestGraph.IsValid())
	{
		if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(QuestGraph))
		{
			auto CurEditor = QuestGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				QuestEditor->OnRefreshPropertyEditor(this);
			}
		}
	}
}

void UQuestTargetBase::SetParamVisible(FName PropertyName, bool bVisible)
{
	DoSetParamVisible(this, PropertyName, bVisible);
	if (QuestGraph.IsValid())
	{
		if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(QuestGraph))
		{
			auto CurEditor = QuestGraphBase->QuestObjectivesEditor;
			if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(CurEditor.Pin().Get()))
			{
				QuestEditor->OnRefreshPropertyEditor(this);
			}
		}
	}
}

void UQuest::SetParamVisible(FName PropertyName, bool bVisible)
{
	DoSetParamVisible(this, PropertyName, bVisible);
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			QuestEditor->OnRefreshPropertyEditor(this);
		}
	}
}

#endif

void UQuest::CreateTargetsManually(TArray<UQuestTargetBase*>& InTargetList)
{
	if (QuestGraph == nullptr)
		return;
	if (UEDGraphBase* QuestGraphBase = Cast<UEDGraphBase>(QuestGraph))
	{
		UEDGraphNode_StateNodeBase* ProgressNode = nullptr;
		for (TObjectPtr<class UEdGraphNode>& GraphNode : QuestGraph->Nodes)
		{
			if (!GraphNode)
				continue;
			if (UEDGraphNode_StateNodeBase* ActionStateNode = Cast<UEDGraphNode_StateNodeBase>(GraphNode))
			{
				if (ActionStateNode->NodeType == EDNodeType::QuestProgress)
				{
					ProgressNode = ActionStateNode;
					break;
				}
			}
		}

		if (ProgressNode == nullptr)
			return;

		const UEdGraphSchema* Schema = QuestGraph->GetSchema();
		if (const UEventDrivenGraphSchema* ThisSchema = Cast<const UEventDrivenGraphSchema>(Schema))
		{
			int32 idx = 1 - InTargetList.Num(); // 随手写的,主要是尽量均匀分布而不是挤在一起
			for (UQuestTargetBase* PreCreateTarget : InTargetList)
			{
				if (!PreCreateTarget)
					continue;
				FVector2D NewPlacePos = FVector2D(ProgressNode->NodePosX + 150 * idx, ProgressNode->NodePosY + 200);
				ThisSchema->CreateQuestTargetNode(QuestGraphBase, PreCreateTarget, ProgressNode->GetOutputPin(), NewPlacePos);
				idx++;
			}
		}
	}
}

FQuestObjectivesEditor* UQuest::GetQuestEditor() const
{
	if (QuestObjectivesEditor.IsValid())
	{
		if (FQuestObjectivesEditor* QuestEditor = static_cast<FQuestObjectivesEditor*>(QuestObjectivesEditor.Pin().Get()))
		{
			return QuestEditor;
		}
	}

	return nullptr;
}

void UQuest::PostInitProperties()
{
	Super::PostInitProperties();
}

void UQuest::PreEditChange(FProperty* PropertyAboutToChange)
{
	Super::PreEditChange(PropertyAboutToChange);

	if (PropertyAboutToChange && PropertyAboutToChange->GetFName() == GET_MEMBER_NAME_CHECKED(UQuest, QuestID))
	{
		OldQuestObjectID = QuestID;
	}

	EmptyTraceParamTargetIndex.Empty();

	// 主目标
	if (PropertyAboutToChange && PropertyAboutToChange->GetFName() == TEXT("TraceParam"))
	{
		// TraceParam 为 nullptr 说明这次更改从 None 变化到有值，此时增加富文本
		if(MainTargetTraceCombo.Num() > 0 && MainTarget && !MainTargetTraceCombo[0].TraceParam)
		{
			// 任务目标描述
			if (!MainTargetTraceCombo[0].Desc.Contains(TEXT("<h>")) && !MainTargetTraceCombo[0].Desc.Contains(TEXT("</>")))
			{
				MainTargetTraceCombo[0].Desc.Append(TEXT("<h></>"));

				OnRefreshQuestName.Broadcast();
			}
		}
	}

	// 子目标，涉及蓝图类型，会麻烦一些
	// 此时先把 TraceParam 为 nullptr 的那些 QuestTarget 的 index 记录下来
	// 再在 PostEditChangeProperty 里配合，看这次更改是否从 None 变化到有值
	if (PropertyAboutToChange && PropertyAboutToChange->GetFName() == TEXT("QuestTargets"))
	{
		// 目标描述文本
		FString QuestTargetBPBaseClassPath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestTargetBPBase.QuestTargetBPBase_C");
		UClass* QuestTargetBPBaseClass = StaticLoadClass(UObject::StaticClass(), nullptr, *QuestTargetBPBaseClassPath);
		FObjectProperty* TraceParamProperty = CastField<FObjectProperty>(QuestTargetBPBaseClass->FindPropertyByName(TEXT("TraceParam")));

		for (int32 TargetIndex = 0; TargetIndex < QuestTargets.Num(); TargetIndex++)
		{
			UQuestTargetBase* QuestTarget = QuestTargets[TargetIndex];
			if (QuestTarget)
			{
				UTaskTargetTrace* TraceParamValue = Cast<UTaskTargetTrace>(TraceParamProperty->GetPropertyValue_InContainer(QuestTarget));
				if (!TraceParamValue)
				{
					EmptyTraceParamTargetIndex.Add(TargetIndex);
				}
			}
		}
	}
}

UE_ENABLE_OPTIMIZATION_SHIP

#undef LOCTEXT_NAMESPACE