#include "FindInQuests.h"

#include "FQuestObjectivesEditor.h"
#include "EDGraph/Graph/EventDrivenGraphSchema.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SButton.h"
#include "Misc/MessageDialog.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "ISourceControlModule.h"
#include "ISourceControlProvider.h"
#include "SourceControlOperations.h"
#include "SourceControlHelpers.h"

#define LOCTEXT_NAMESPACE "FindInQuests"


FFindInQuestsResult::FFindInQuestsResult(const FText& InDisplayText)
	: DisplayText(InDisplayText)
{
}

FReply FFindInQuestsResult::OnClick()
{
	return FReply::Handled();
}

FString FFindInQuestsResult::GetSourceText() const
{
	return SourceText;
}

FText FFindInQuestsResult::GetDisplayString() const
{
	return DisplayText;
}

void SFindInQuests::Construct(const FArguments& InArgs, TSharedPtr<FQuestObjectivesEditor> InQuestObjectivesEditor)
{
	QuestEditor = InQuestObjectivesEditor;
	
	this->ChildSlot
	[
		SNew(SBorder)
		.BorderImage(FAppStyle::Get().GetBrush("Brushes.Panel"))
		[
			SAssignNew(MainVerticalBox, SVerticalBox)
			+SVerticalBox::Slot()
			.AutoHeight()
			.Padding(8.f, 5.f, 8.f, 5.f)
			[
				// 搜索行
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.FillWidth(1)
				[
					SAssignNew(SearchTextField, SSearchBox)
					.HintText(LOCTEXT("QuestSearchHint", "Enter string or int to find reference in quests..."))
					.OnTextChanged(this, &SFindInQuests::OnSearchTextChanged)
					.OnTextCommitted(this, &SFindInQuests::OnSearchTextCommitted)
					.Visibility(EVisibility::Visible)
					.DelayChangeNotificationsWhileTyping(false)
				]
				+SHorizontalBox::Slot()
				.Padding(4.f, 0.f, 2.f, 0.f)
				.AutoWidth()
				[
					SNew(SCheckBox)
					.OnCheckStateChanged(this, &SFindInQuests::OnOpenWindowCheckStateChanged)
					.IsChecked(this, &SFindInQuests::ShouldOpenNewWindow)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("OpenNewWindowCheckboxText", "Open New Window"))
					]
				]
				+SHorizontalBox::Slot()
				.Padding(4.f, 0.f, 2.f, 0.f)
				.AutoWidth()
				[
					SNew(SCheckBox)
					.OnCheckStateChanged(this, &SFindInQuests::OnOnlyOpenedQuestStateChanged)
					.IsChecked(this, &SFindInQuests::ShouldOnlyOpenedQuest)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("OnlyOpenedQuestCheckboxText", "Only Search in Opened Quest"))
					]
				]
			]
			// 添加替换行
			+SVerticalBox::Slot()
			.AutoHeight()
			.Padding(8.f, 5.f, 8.f, 5.f)
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.FillWidth(1)
				[
					SAssignNew(ReplaceTextField, SEditableTextBox)
					.HintText(LOCTEXT("QuestReplaceHint", "Enter replacement text..."))
					.OnTextChanged(this, &SFindInQuests::OnReplaceTextChanged)
					.OnTextCommitted(this, &SFindInQuests::OnReplaceTextCommitted)
				]
				+SHorizontalBox::Slot()
				.Padding(4.f, 0.f, 0.f, 0.f)
				.AutoWidth()
				[
					SAssignNew(ReplaceButton, SButton)
					.Text(LOCTEXT("ReplaceButtonText", "Replace"))
					.ToolTipText(LOCTEXT("ReplaceButtonTooltip", "Replace selected items with the replacement text"))
					.OnClicked(this, &SFindInQuests::OnReplaceButtonClicked)
					.IsEnabled(this, &SFindInQuests::IsReplaceButtonEnabled)
				]
			]
			+SVerticalBox::Slot()
			.FillHeight(1.0f)
			[
				SNew(SBorder)
				.BorderImage(FAppStyle::Get().GetBrush("Brushes.Recessed"))
				.Padding(FMargin(8.f, 8.f, 4.f, 0.f))
				[
					SAssignNew(TreeView, SQuestSearchTreeViewType)
					.ItemHeight(24)
					.TreeItemsSource( &ItemsFound )
					.OnGenerateRow( this, &SFindInQuests::OnGenerateRow )
					.OnGetChildren( this, &SFindInQuests::OnGetChildren )
					.OnMouseButtonDoubleClick(this,&SFindInQuests::OnTreeSelectionDoubleClicked)
					.OnSelectionChanged(this, &SFindInQuests::OnTreeSelectionChanged)
					.SelectionMode( ESelectionMode::Multi )
					//.OnContextMenuOpening(this, &SFindInQuests::OnContextMenuOpening)
				]
			]
		]
	];
}

FString GetLastPathComponent(const FString& Path)
{
	int32 LastSlashIndex;
	if (Path.FindLastChar('/', LastSlashIndex))
	{
		return Path.RightChop(LastSlashIndex + 1);
	}
	return Path; // 如果没有找到斜杠，返回整个字符串
}

void SFindInQuests::MakeSearchQuery(FString InSearchString)
{
	HighlightText = FText::FromString(InSearchString);
	ItemsFound.Empty();
	SelectedItemsForReplace.Empty();
	
	TArray<FString> ChapterNames, RingNames;
	FString ChapterFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Chapter");
	FString RingFilePath = FPaths::ProjectContentDir() + FString("Script/Data/Config/Quest/Ring");
	if (!bOnlyOpenedQuest)
	{
		ChapterFilePath = FPaths::ConvertRelativePathToFull(ChapterFilePath);
		RingFilePath = FPaths::ConvertRelativePathToFull(RingFilePath);
		QuestEditor.Pin()->GetAllFilenamesInDirectory(ChapterFilePath, ChapterNames);
		QuestEditor.Pin()->GetAllFilenamesInDirectory(RingFilePath, RingNames);
	}
	else
	{
		// 只从当前打开的任务里搜索
		auto QuestObjectivesEditor = QuestEditor.Pin();
		if (QuestObjectivesEditor->GetChapterGraph().IsValid())
		{
			auto Chapter = Cast<UQuestChapter>(QuestObjectivesEditor->GetChapterGraph()->GetOuter());
			if (Chapter)
			{
				ChapterFilePath += FString("/") + FString::FromInt(Chapter->QuestObjectID) + FString(".lua");
				ChapterFilePath = FPaths::ConvertRelativePathToFull(ChapterFilePath);
				ChapterNames.Add(ChapterFilePath);
			}
		}
		if (QuestObjectivesEditor->GetRingGraph().IsValid())
		{
			auto Ring = Cast<UQuestRing>(QuestObjectivesEditor->GetRingGraph()->GetOuter());
			if (Ring)
			{
				RingFilePath += FString("/") + FString::FromInt(Ring->QuestObjectID) + FString(".lua");
				RingFilePath = FPaths::ConvertRelativePathToFull(RingFilePath);
				RingNames.Add(RingFilePath);
			}
		}
	}

	FQuestSearchResult ChapterCategory = FQuestSearchResult(new FFindInQuestsResult(LOCTEXT("QuestSearchChapterCategory", "Chapters:" )));
	SearchByCategory(InSearchString, ChapterCategory, ChapterNames);
	if (ChapterCategory->Children.Num() > 0)
	{
		ItemsFound.Add(ChapterCategory);
	}
	
	FQuestSearchResult RingCategory = FQuestSearchResult(new FFindInQuestsResult(LOCTEXT("QuestSearchRingCategory", "Rings:" )));
	SearchByCategory(InSearchString, RingCategory, RingNames);
	if (RingCategory->Children.Num() > 0)
	{
		ItemsFound.Add(RingCategory);
	}

	// Quest 数据包含在 Ring 中，因此传入 RingNames 特殊处理 Quest
	FQuestSearchResult QuestCategory = FQuestSearchResult(new FFindInQuestsResult(LOCTEXT("QuestSearchQuestCategory", "Quests:" )));
	SearchByCategory(InSearchString, QuestCategory, RingNames, true);
	if (QuestCategory->Children.Num() > 0)
	{
		ItemsFound.Add(QuestCategory);
	}

	if(ItemsFound.Num() == 0)
	{
		FText NoResultsText = LOCTEXT("QuestSearchNoResults", "No Results found");
		
		// Insert a fake result to inform user if none found
		ItemsFound.Add(FQuestSearchResult(new FFindInQuestsResult(NoResultsText)));
		HighlightText = FText::GetEmpty();
	}
	else
	{
		for(auto Item : ItemsFound)
		{
			ExpandAllChildren(Item, TreeView);
		}
	}
	TreeView->RequestTreeRefresh();
}

void SFindInQuests::SearchByCategory(const FString& InSearchString, FQuestSearchResult& InCategory, const TArray<FString>& CategoryData, bool bQuest)
{
	for (auto DataName : CategoryData)
	{
		TArray<FString> SearchingTexts;
		FFileHelper::LoadFileToStringArray(SearchingTexts, *DataName);

		TArray<FString> SearchingTextsWithoutQuestData;

		// QuestID 对应的文本内容
		TMap<FString, TArray<FString>> QuestID2Content;

		// 解析 QuestData 部分
		bool bIsQuestDataSection = false;
		int32 BracesCount = 0;
		FString ExtractedQuestID = "";
		for (const FString& Line : SearchingTexts)
		{
			// 检查是否是 QuestData 的起始行
			if (Line.Contains(TEXT("[\"QuestData\"] = {")))
			{
				bIsQuestDataSection = true;
				BracesCount++;
				continue; // 跳过起始行
			}

			// 如果进入了 QuestData 部分
			if (bIsQuestDataSection)
			{
				// 检查是否是 QuestData 的结束行
				if (Line.Contains(TEXT("{")))
				{
					BracesCount++;

					// 有两个 { , 说明当前行标识的是 QuestID
					// 如 [99005500] = {
					if (BracesCount == 2)
					{
						int32 StartIndex = Line.Find(TEXT("["));
						int32 EndIndex = Line.Find(TEXT("]"));

						if (StartIndex != INDEX_NONE && EndIndex != INDEX_NONE && EndIndex > StartIndex)
						{
							// 提取方括号中的内容
							ExtractedQuestID = Line.Mid(StartIndex + 1, EndIndex - StartIndex - 1);
							QuestID2Content.Add(ExtractedQuestID, {});
						}
						else
						{
							UE_LOG(LogTemp, Warning, TEXT("Failed to extract ExtractedQuestID. LineContent: %s"), *Line);
						}
					}
				}
				if (Line.Contains(TEXT("}")))
				{
					BracesCount--;
					if (BracesCount == 0)
					{
						bIsQuestDataSection = false;
					}
				}

				// 收集 QuestData 的内容
				if (QuestID2Content.Contains(ExtractedQuestID) && !ExtractedQuestID.IsEmpty())
				{
					QuestID2Content[ExtractedQuestID].Add(Line);
				}
			}
			else
			{
				SearchingTextsWithoutQuestData.Add(Line);
			}
		}

		// Quest 数据包含在 Ring 中，特殊处理
		if (bQuest)
		{
			// 判断 Quest 内容是否包含搜索条目
			for (const auto& [QuestID, ContentStringArray] : QuestID2Content)
			{
				auto Result = GetMatchedResult(ContentStringArray, InSearchString);
				if (Result.Num())
				{
					FQuestSearchResult DataInstance = MakeShared<FFindInQuestsResult>(FText::FromString(QuestID));
					DataInstance->SourceText = DataName;
					DataInstance->ItemID = QuestID;
					for (auto Res : Result)
					{
						FQuestSearchResult TextIns = MakeShared<FFindInQuestsResult>(FText::FromString(Res));
						TextIns->SourceText = DataInstance->SourceText;
						TextIns->ItemID = QuestID;
						TextIns->Parent = DataInstance;
						DataInstance->Children.Add(TextIns);
					}
					DataInstance->Parent = InCategory;
					InCategory->Children.Add(DataInstance);
				}
			}
		}
		else
		{
			auto Result = GetMatchedResult(SearchingTextsWithoutQuestData, InSearchString);
			auto DataID = GetLastPathComponent(DataName);
			DataID.Split(".", &DataID, nullptr);
			if (Result.Num())
			{
				FQuestSearchResult DataInstance = MakeShared<FFindInQuestsResult>(FText::FromString(DataID));
				DataInstance->SourceText = DataName;
				DataInstance->ItemID = DataID;
				for (auto Res : Result)
				{
					FQuestSearchResult TextIns = MakeShared<FFindInQuestsResult>(FText::FromString(Res));
					TextIns->SourceText = DataInstance->SourceText;
					TextIns->ItemID = DataID;
					TextIns->Parent = DataInstance;
					DataInstance->Children.Add(TextIns);
				}
				DataInstance->Parent = InCategory;
				InCategory->Children.Add(DataInstance);
			}
		}
	}
}

TArray<FString> SFindInQuests::GetMatchedResult(const TArray<FString>& InTargets, const FString& InSearchString)
{
	TArray<FString> Results;
	for (auto Target : InTargets)
	{
		if (!Target.Contains("="))
		{
			continue;
		}
		FString ValueText;
		Target.Split("=",nullptr, &ValueText);
		if (ValueText.Contains(InSearchString))
		{
			Results.Add(Target);
		}
	}
	return Results;
}

TArray<TPair<FString, int32>> SFindInQuests::GetMatchedResultWithLineNumber(const TArray<FString>& InTargets, const FString& InSearchString)
{
	TArray<TPair<FString, int32>> Results;
	for (int32 i = 0; i < InTargets.Num(); i++)
	{
		const FString& Target = InTargets[i];
		if (!Target.Contains("="))
		{
			continue;
		}
		FString ValueText;
		Target.Split("=", nullptr, &ValueText);
		ValueText.TrimStartAndEndInline();
		
		if (ValueText.Contains(InSearchString))
		{
			Results.Add(TPair<FString, int32>(Target, i));
		}
	}
	return Results;
}

void SFindInQuests::ExpandAllChildren(FQuestSearchResult InTreeNode, TSharedPtr<STreeView<TSharedPtr<FFindInQuestsResult>>> InTreeView)
{
	if (InTreeNode->Children.Num())
	{
		InTreeView->SetItemExpansion(InTreeNode, true);
		for (int32 i = 0; i < InTreeNode->Children.Num(); i++)
		{
			ExpandAllChildren(InTreeNode->Children[i], InTreeView);
		}
	}
}

void SFindInQuests::OnSearchTextChanged( const FText& Text)
{
	SearchValue = Text.ToString();
}

void SFindInQuests::OnSearchTextCommitted( const FText& Text, ETextCommit::Type CommitType )
{
	if (CommitType == ETextCommit::OnEnter)
	{
		MakeSearchQuery(SearchValue);
	}
}

void SFindInQuests::OnReplaceTextChanged(const FText& Text)
{
	ReplaceValue = Text.ToString();
}

void SFindInQuests::OnReplaceTextCommitted(const FText& Text, ETextCommit::Type CommitType)
{
	ReplaceValue = Text.ToString();
}

bool SFindInQuests::IsReplaceButtonEnabled() const
{
	// 当有选中的项目且有替换文本时启用按钮
	return SelectedItemsForReplace.Num() > 0 && !ReplaceValue.IsEmpty() && !SearchValue.IsEmpty();
}

void SFindInQuests::OnTreeSelectionChanged(FQuestSearchResult Item, ESelectInfo::Type SelectInfo)
{
	SelectedItemsForReplace.Empty();
	TreeView->GetSelectedItems(SelectedItemsForReplace);
	
	// 过滤掉类别节点，只保留具体的搜索结果
	SelectedItemsForReplace.RemoveAll([](const FQuestSearchResult& Item) {
		return !Item->Parent.IsValid(); // 移除没有父节点的类别节点
	});
}

FReply SFindInQuests::OnReplaceButtonClicked()
{
	if (SelectedItemsForReplace.Num() == 0 || ReplaceValue.IsEmpty() || SearchValue.IsEmpty())
	{
		return FReply::Handled();
	}
	
	// 显示确认对话框
	FText Message = FText::Format(
		LOCTEXT("ReplaceConfirmMessage", "Are you sure you want to replace '{0}' with '{1}' in {2} item(s)?"),
		FText::FromString(SearchValue),
		FText::FromString(ReplaceValue),
		FText::AsNumber(SelectedItemsForReplace.Num())
	);
	
	FText Title = LOCTEXT("ReplaceConfirmTitle", "Confirm Replacement");
	
	// 使用UE5的消息对话框
	EAppReturnType::Type ReturnType = FMessageDialog::Open(
		EAppMsgType::YesNo,
		Message,
		&Title
	);
	
	if (ReturnType == EAppReturnType::Yes)
	{
		// 执行替换
		PerformReplaceOperation();
	}
	
	return FReply::Handled();
}

bool SFindInQuests::TryCheckoutFiles(const TArray<FString>& FilesToCheckout)
{
	// 检查源控制模块是否可用
	ISourceControlModule& SourceControlModule = ISourceControlModule::Get();
	if (!SourceControlModule.IsEnabled())
	{
		UE_LOG(LogTemp, Warning, TEXT("Source control is not enabled"));
		return false;
	}
	
	ISourceControlProvider& SourceControlProvider = SourceControlModule.GetProvider();
	if (!SourceControlProvider.IsAvailable())
	{
		UE_LOG(LogTemp, Warning, TEXT("Source control provider is not available"));
		return false;
	}
	
	if (FilesToCheckout.Num() == 0)
	{
		return true;
	}
	
	// 批量执行checkout
	TArray<FString> AbsoluteFilePaths;
	for (const FString& FilePath : FilesToCheckout)
	{
		AbsoluteFilePaths.Add(FPaths::ConvertRelativePathToFull(FilePath));
	}
	
	// 批量检查文件状态
	TArray<FSourceControlStateRef> FileStates;
	SourceControlProvider.GetState(AbsoluteFilePaths, FileStates, EStateCacheUsage::ForceUpdate);
	
	// 收集需要checkout的文件
	TArray<FString> FilesToCheckoutBatch;
	for (int32 i = 0; i < FileStates.Num(); ++i)
	{
		const FSourceControlStateRef& FileState = FileStates[i];
		if (FileState->IsSourceControlled() && !FileState->IsCheckedOut() && !FileState->IsAdded())
		{
			FilesToCheckoutBatch.Add(AbsoluteFilePaths[i]);
		}
	}
	
	if (FilesToCheckoutBatch.Num() > 0)
	{
		// 批量执行checkout
		TSharedRef<FCheckOut, ESPMode::ThreadSafe> CheckOutOperation = ISourceControlOperation::Create<FCheckOut>();
		ECommandResult::Type Result = SourceControlProvider.Execute(CheckOutOperation, FilesToCheckoutBatch);
		
		if (Result == ECommandResult::Succeeded)
		{
			UE_LOG(LogTemp, Log, TEXT("Successfully checked out %d file(s)"), FilesToCheckoutBatch.Num());
			return true;
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("Failed to checkout files"));
			return false;
		}
	}
	
	return true; // 没有文件需要checkout也被认为是成功的
}

void SFindInQuests::PerformReplaceOperation()
{
	// 记录需要修改的文件
	TArray<FString> ModifiedFiles;
	
	// 收集需要替换的项目及其位置
	for (const auto& SelectedItem : SelectedItemsForReplace)
	{
		if (!SelectedItem.IsValid() || SelectedItem->SourceText.IsEmpty())
			continue;
		
		FString FilePath = SelectedItem->SourceText;
		FString OriginalLine = SelectedItem->DisplayText.ToString();
		
		// 执行替换
		FString NewLine = OriginalLine.Replace(*SearchValue, *ReplaceValue, ESearchCase::CaseSensitive);
		
		// 记录文件路径（去重）
		if (!ModifiedFiles.Contains(FilePath))
		{
			ModifiedFiles.Add(FilePath);
		}
	}
	
	if (ModifiedFiles.Num() == 0)
	{
		return;
	}
	
	// 尝试批量checkout文件
	bool bCheckoutSuccess = TryCheckoutFiles(ModifiedFiles);
	
	if (!bCheckoutSuccess)
	{
		// 显示警告但不阻止替换操作
		FNotificationInfo WarningInfo(LOCTEXT("CheckoutWarning", "Some files may not be checked out. You may need to manually checkout these files."));
		WarningInfo.ExpireDuration = 5.0f;
		FSlateNotificationManager::Get().AddNotification(WarningInfo);
	}
	
	// 对每个文件执行替换
	for (const FString& FilePath : ModifiedFiles)
	{
		// 读取原文件
		TArray<FString> FileLines;
		if (FFileHelper::LoadFileToStringArray(FileLines, *FilePath))
		{
			bool bFileModified = false;
			
			// 替换匹配的行
			for (int32 i = 0; i < FileLines.Num(); i++)
			{
				// 检查这一行是否包含搜索文本
				if (FileLines[i].Contains(SearchValue))
				{
					// 替换这一行中的搜索文本
					FString NewLine = FileLines[i].Replace(*SearchValue, *ReplaceValue, ESearchCase::CaseSensitive);
					FileLines[i] = NewLine;
					bFileModified = true;
				}
			}
			
			// 如果文件被修改，写回文件
			if (bFileModified)
			{
				// 直接保存到原文件（不创建备份）
				if (FFileHelper::SaveStringArrayToFile(FileLines, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly))
				{
					// 显示成功消息
					FNotificationInfo Info(FText::Format(
						LOCTEXT("ReplaceSuccess", "Successfully replaced text in {0}"),
						FText::FromString(FPaths::GetCleanFilename(FilePath))
					));
					Info.ExpireDuration = 3.0f;
					FSlateNotificationManager::Get().AddNotification(Info);
				}
				else
				{
					// 显示错误消息
					FNotificationInfo ErrorInfo(FText::Format(
						LOCTEXT("ReplaceError", "Failed to save file: {0}"),
						FText::FromString(FPaths::GetCleanFilename(FilePath))
					));
					ErrorInfo.ExpireDuration = 5.0f;
					FSlateNotificationManager::Get().AddNotification(ErrorInfo);
				}
			}
		}
	}
	
	// 重新执行搜索以更新显示
	MakeSearchQuery(SearchValue);
}

void SFindInQuests::OnGetChildren( FQuestSearchResult InItem, TArray< FQuestSearchResult >& OutChildren )
{
	OutChildren += InItem->Children;
}

void SFindInQuests::OnTreeSelectionDoubleClicked( FQuestSearchResult Item )
{
	if(Item.IsValid())
	{
		Item->OnClick();
		if (Item->ItemID.Len())
		{
			if (bShouldOpenNewWindow)
			{
				TSharedRef<FQuestObjectivesEditor> NewMissionObjectivesEditor(new FQuestObjectivesEditor());
				NewMissionObjectivesEditor->InitQuestObjectivesEditor(EToolkitMode::Standalone, nullptr);
				NewMissionObjectivesEditor->OnSearchTextCommitted(FText::FromString(Item->ItemID), ETextCommit::Type::OnEnter);
			}else
			{
				QuestEditor.Pin()->OnSearchTextCommitted(FText::FromString(Item->ItemID), ETextCommit::Type::OnEnter);
			}
		}
	}
}

TSharedRef<ITableRow> SFindInQuests::OnGenerateRow( FQuestSearchResult InItem, const TSharedRef<STableViewBase>& OwnerTable )
{
	// Finalize the search data, this does some non-thread safe actions that could not be done on the separate thread.
	InItem->FinalizeSearchData();

	bool bIsACategoryWidget = !InItem->Parent.IsValid();

	if (bIsACategoryWidget)
	{
		return SNew( STableRow< TSharedPtr<FFindInQuestsResult> >, OwnerTable )
			.Style( &FAppStyle::Get().GetWidgetStyle<FTableRowStyle>("ShowParentsTableView.Row") )
			.Padding(FMargin(2.f, 3.f, 2.f, 3.f))
			[
				SNew(STextBlock)
				.Text(InItem.Get(), &FFindInQuestsResult::GetDisplayString)
				.ToolTipText(LOCTEXT("QuestCategoryTooltip", "QuestCategory"))
			];
	}
	else // Functions/Event/Pin widget
	{
		FText SourceText = FText::GetEmpty();

		if(!InItem->GetSourceText().IsEmpty())
		{
			FFormatNamedArguments Args;
			Args.Add(TEXT("SourceQuest"), FText::FromString(InItem->GetSourceText()));

			SourceText = FText::Format(LOCTEXT("SourceQuestTitle", "Source Quest:[{SourceQuest}]"), Args);
		}

		FFormatNamedArguments Args;
		Args.Add(TEXT("DisplayTitle"), InItem->DisplayText);

		FText Tooltip = FText::Format(LOCTEXT("QuestSearchToolTip", "{DisplayTitle}"), Args);

		return SNew( STableRow< TSharedPtr<FFindInQuestsResult> >, OwnerTable )
			.Style( &FAppStyle::Get().GetWidgetStyle<FTableRowStyle>("ShowParentsTableView.Row") )
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				.Padding(2.f)
				[
					SNew(STextBlock)
						.Text(InItem.Get(), &FFindInQuestsResult::GetDisplayString)
						.HighlightText(HighlightText)
						.ToolTipText(Tooltip)
				]
				+SHorizontalBox::Slot()
				.FillWidth(1)
				.HAlign(HAlign_Right)
				.VAlign(VAlign_Center)
				.Padding(2.f)
				[
					SNew(STextBlock)
					.Text( SourceText )
					.HighlightText(HighlightText)
				]
			];
	}
}

#undef LOCTEXT_NAMESPACE