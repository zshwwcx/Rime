#pragma once

#include "Containers/Array.h"
#include "Containers/BitArray.h"
#include "Containers/Map.h"
#include "Containers/Set.h"
#include "Containers/SparseArray.h"
#include "Containers/UnrealString.h"
#include "CoreMinimal.h"
#include "Delegates/Delegate.h"
#include "EdGraph/EdGraphPin.h"
#include "EdGraph/EdGraphSchema.h"
#include "HAL/Platform.h"
#include "HAL/PlatformCrt.h"
#include "Input/Reply.h"
#include "Internationalization/Text.h"
#include "Layout/Visibility.h"
#include "Math/Color.h"
#include "Misc/Guid.h"
#include "Misc/Optional.h"
#include "SlateFwd.h"
#include "Styling/SlateColor.h"
#include "Templates/SharedPointer.h"
#include "Templates/TypeHash.h"
#include "Templates/UnrealTemplate.h"
#include "Textures/SlateIcon.h"
#include "Types/SlateEnums.h"
#include "UObject/NameTypes.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/SWidget.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Views/STableViewBase.h"
#include "Widgets/Views/STreeView.h"

class FJsonValue;
class FUICommandList;
class ITableRow;
class SDockTab;
class SVerticalBox;
class SWidget;
class UBlueprint;
class UClass;
class UObject;
struct FGeometry;
struct FKeyEvent;
struct FSlateBrush;


////////////////////////////////////
// FFindInQuestsResult

/* Item that matched the search results */
class FFindInQuestsResult : public TSharedFromThis< FFindInQuestsResult >
{
public:
	FFindInQuestsResult() = default;
	virtual ~FFindInQuestsResult() = default;

	/* Create a root */
	explicit FFindInQuestsResult(const FText& InDisplayText);

	/* Called when user clicks on the search item */
	virtual FReply OnClick();

	/** Finalizes any content for the search data that was unsafe to do on a separate thread */
	virtual void FinalizeSearchData() {};

	/* Gets the comment on this node if any */
	FString GetSourceText() const;

	/**
	* Parses search info for specific data important for displaying the search result in an easy to understand format
	*
	* @param	InTokens		The search tokens to check results against
	* @param	InKey			This is the tag for the data, describing what it is so special handling can occur if needed
	* @param	InValue			Compared against search query to see if it passes the filter, sometimes data is rejected because it is deemed unsearchable
	* @param	InParent		The parent search result
	*/
	virtual void ParseSearchInfo(FText InKey, FText InValue) {};

	/** Returns the display string for the row */
	FText GetDisplayString() const;

public:
	/*Any children listed under this category */
	TArray< TSharedPtr<FFindInQuestsResult> > Children;

	/*If it exists it is the blueprint*/
	TWeakPtr<FFindInQuestsResult> Parent;

	/*The display text for this item */
	FText DisplayText;

	/** Display text for source information */
	FString SourceText;

	FString ItemID;
};

typedef TSharedPtr<FFindInQuestsResult> FQuestSearchResult;
typedef STreeView<FQuestSearchResult>  SQuestSearchTreeViewType;

class KGQUESTEDITOR_API SFindInQuests: public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS( SFindInQuests )
	{}
SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, TSharedPtr<class FQuestObjectivesEditor> InQuestObjectivesEditor = nullptr);
	
	void MakeSearchQuery(FString InSearchString);

	void SearchByCategory(const FString &InSearchString, FQuestSearchResult &InCategory, const TArray<FString>& CategoryData, bool bQuest = false);

private:
	TArray<FString> GetMatchedResult(const TArray<FString>& InTargets,const FString& InSearchString);
	
	TArray<TPair<FString, int32>> GetMatchedResultWithLineNumber(const TArray<FString>& InTargets, const FString& InSearchString);

	void ExpandAllChildren(FQuestSearchResult InTreeNode, TSharedPtr<STreeView<TSharedPtr<FFindInQuestsResult>>> InTreeView);
	
	/*Called when user changes the text they are searching for */
	void OnSearchTextChanged(const FText& Text);

	/*Called when user changes commits text to the search box */
	void OnSearchTextCommitted(const FText& Text, ETextCommit::Type CommitType);
	
	/* Called when user changes the replace text */
	void OnReplaceTextChanged(const FText& Text);
	
	/* Called when user commits replace text */
	void OnReplaceTextCommitted(const FText& Text, ETextCommit::Type CommitType);

	/* Get the children of a row */
	void OnGetChildren( FQuestSearchResult InItem, TArray< FQuestSearchResult >& OutChildren );

	/* Called when user double-clicks on a new result */
	void OnTreeSelectionDoubleClicked( FQuestSearchResult Item );
	
	/* Called when tree selection changes */
	void OnTreeSelectionChanged(FQuestSearchResult Item, ESelectInfo::Type SelectInfo);

	/* Called when a new row is being generated */
	TSharedRef<ITableRow> OnGenerateRow(FQuestSearchResult InItem, const TSharedRef<STableViewBase>& OwnerTable);
	
	/* Called when replace button is clicked */
	FReply OnReplaceButtonClicked();
	
	/* Check if replace button is enabled */
	bool IsReplaceButtonEnabled() const;
	
	/* Perform the actual replace operation */
	void PerformReplaceOperation();
	
	/* Try to checkout files from Perforce */
	bool TryCheckoutFiles(const TArray<FString>& FilesToCheckout);

	void OnOpenWindowCheckStateChanged(ECheckBoxState NewState)
	{
		if (NewState == ECheckBoxState::Checked)
		{
			bShouldOpenNewWindow = true;
		}
		else
		{
			bShouldOpenNewWindow = false;
		}
	}

	void OnOnlyOpenedQuestStateChanged(ECheckBoxState NewState)
	{
		if (NewState == ECheckBoxState::Checked)
		{
			bOnlyOpenedQuest = true;
		}
		else
		{
			bOnlyOpenedQuest = false;
		}
	}
	
	ECheckBoxState ShouldOpenNewWindow()const
	{
		if (bShouldOpenNewWindow)
		{
			return ECheckBoxState::Checked;
		}
		else
		{
			return ECheckBoxState::Unchecked;
		}
	}

	ECheckBoxState ShouldOnlyOpenedQuest()const
	{
		if (bOnlyOpenedQuest)
		{
			return ECheckBoxState::Checked;
		}
		else
		{
			return ECheckBoxState::Unchecked;
		}
	}

private:
	TSharedPtr<SQuestSearchTreeViewType> TreeView;

	TWeakPtr<FQuestObjectivesEditor> QuestEditor;
	
	/** The search text box */
	TSharedPtr<class SSearchBox> SearchTextField;
	
	/** The replace text box */
	TSharedPtr<class SEditableTextBox> ReplaceTextField;
	
	/** The replace button */
	TSharedPtr<class SButton> ReplaceButton;
	
	/* This buffer stores the currently displayed results */
	TArray<FQuestSearchResult> ItemsFound;

	/** In Find Within Blueprint mode, we need to keep a handle on the root result, because it won't show up in the tree */
	FQuestSearchResult RootSearchResult;

	/* The string to highlight in the results */
	FText HighlightText;

	/* The string to search for */
	FString	SearchValue;
	
	/** The string to replace with */
	FString ReplaceValue;

	/** Thread object that searches through Blueprint data on a separate thread */
	TSharedPtr< class FStreamSearch> StreamSearch;

	/** Vertical box, used to add and remove widgets dynamically */
	TWeakPtr< SVerticalBox > MainVerticalBox;

	/** Weak pointer to the cache bar slot, so it can be removed */
	TWeakPtr< SWidget > CacheBarSlot;
	
	/** Commands handled by this widget */
	TSharedPtr< FUICommandList > CommandList;
	
	/** Selected items for replacement */
	TArray<FQuestSearchResult> SelectedItemsForReplace;

	bool bShouldOpenNewWindow = true;
	bool bOnlyOpenedQuest = false;
};