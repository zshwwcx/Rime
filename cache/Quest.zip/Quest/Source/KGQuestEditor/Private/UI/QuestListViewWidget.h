#pragma once
#include "Widgets/SCompoundWidget.h"
#include "QuestScrollWidget.h"


class SQuestListViewWidget :public SCompoundWidget {
public:
	SLATE_BEGIN_ARGS(SQuestListViewWidget)
	{
	}

	SLATE_END_ARGS()

	~SQuestListViewWidget();


public:

	void Construct(const FArguments& Args);

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime);

	//委托，用于定义每行数据如何显示
	TSharedRef<ITableRow> OnGenerateRow(TSharedPtr<FListViewItemData> data, const TSharedRef<STableViewBase>& OwnerTable);

	//用于选中时操作
	void OnSelectionChanged(TSharedPtr<FListViewItemData> ChoiseItemData, ESelectInfo::Type type);

	//重置数据，外部调用
	void SetItemList(TArray<TSharedPtr<FListViewItemData>> list);

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

	TSharedPtr<SListView<TSharedPtr<FListViewItemData>>> ListView;

	int GetCurrentPage() const { return CurrentPage; }

	//进入第一个ListView
	void EnterToPageOne();

	//进入第二个ListView
	void EnterToPageTwo();

	FString GetPathNameFromCurChooseQuestType();

	//进入第三个ListView
	void EnterToPageThree();

	//初始化ListView，第一次进入
	void InitQuestListView(const TSharedPtr<class SQuestScrollWidget>& ScrollWidget);

	void SetCurrentPage(int Page);

	//在视图中显示选中的章节的所有任务关系
	void ShowChoiseChapterGraph(TSharedPtr<FListViewItemData> ChoiseItemData);

	FReply OnClick_Item(TSharedPtr<FListViewItemData> ChoiseItemData);

	TSharedPtr<FListViewItemData> GetCurChoiseListViewItemData() const { return CurChoiseListViewItemData; }

	TMap<TSharedPtr<FListViewItemData>, TSharedPtr<STextBlock>> GetListViewItemAndButtonMap() { return ListViewItemAndTextBlockMap; }

	bool IsDeleteAsset() { return bIsDeleteAsset; }

	void SetLastPageChoiseSingleQuest(class USingleQuest* TempObject) { LastPageChoiseSingleQuest = TempObject; }
	class USingleQuest* GetLastPageChoiseSingleQuest() { return LastPageChoiseSingleQuest;}

private:

	void ClearData();

	void OnDeleteQuestClicked();

	void OnNewQuestClicked();

	void EmptyDataList();

private:

	//当前选择的任务类型
	EQuestFolderType CurChooseQuestType = EQuestFolderType::Quest_Plot;

	int CurrentPage = 0;

	TArray<TSharedPtr<FListViewItemData>> DataList;

	TSharedPtr<class SQuestScrollWidget> QuestScrollWidget;

	TSharedPtr<FListViewItemData> CurChoiseListViewItemData;

	TMap<TSharedPtr<FListViewItemData>, TSharedPtr<STextBlock>> ListViewItemAndTextBlockMap;

	TSharedPtr<FListViewItemData> CurDeleteItem;

	bool bIsDeleteAsset = false;

	//保存上个页面选中的QuestGroup
	TObjectPtr<UObject> LastPageChoiseQuestGroup;

	//保存上个页面选中的SingleQuest
	TObjectPtr<class USingleQuest> LastPageChoiseSingleQuest;


};