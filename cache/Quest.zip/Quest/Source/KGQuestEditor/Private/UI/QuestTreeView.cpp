// Fill out your copyright notice in the Description page of Project Settings.


#include "QuestTreeView.h"
#include "Misc/Paths.h"
//#include "EditorStyleSet.h"
#include "Styling/SlateTypes.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SBoxPanel.h"
#include "HAL/FileManager.h"
#include "FQuestObjectivesEditor.h"
#include "QuestTemplate.h"
#include "ObjectTools.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "../Graph/EdGraph_QuestObjectivesProp.h"
#include "../Graph/MONode_Quest.h"
#include "../Private/ContentBrowserUtils.h"
#include "EditorUtilityLibrary.h"
#include "../Widget/SCCGraphPalette.h"
//#include "EditorAssetLibrary.h"
#include "../Graph/MONode_QuestAction.h"
#include "../Graph/MONode_Root.h"
#include "FileHelpers.h"
#include "SourceControlHelpers.h"
#include "FileHelpers.h"
#include "UObject/Class.h"

#include "Subsystems/EditorAssetSubsystem.h"

#define LOCTEXT_NAMESPACE "Editor.QuestTreeView"

void SQuestTreeView::SaveButtonOnClickWithAsset(UObject* EditAsset)
{
	//对于QuestGroup的处理
	//UGroupQuestTemplate* GroupQuest = Cast<UGroupQuestTemplate>(EditAsset);
	//if (GroupQuest)
	//{
	//	//先将Graph中保存到ChapterAsset中
	//	if (UEdGraph_QuestObjectivesProp* QuestObjectivesGraph = Cast<UEdGraph_QuestObjectivesProp>(GetQuestObjectivesEditor()->GetGraphEditor()->GetCurrentGraph()))
	//	{
	//		GroupQuest->NodeGraph = QuestObjectivesGraph;

	//		//迁出所有Node资源
	//		TArray<UPackage*> TempAllNodePackages;
	//		TempAllNodePackages.Add(GroupQuest->GetOutermost());
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//			if (Node_Quest && Node_Quest->SingleQuest)
	//			{
	//				TempAllNodePackages.Add(Node_Quest->SingleQuest->GetOutermost());
	//			}
	//		}
	//		FEditorFileUtils::CheckoutPackages(TempAllNodePackages, NULL, false, false);

	//		//更新所有Node的标题
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//			if (Node_Quest)
	//			{
	//				UpdateNodeQuestText(Node_Quest);
	//			}
	//		}

	//		//保存Graph中Node包含的所有Quest到变量QuestArray中
	//		GroupQuest->QuestArray.Empty();
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//			if (Node_Quest && Node_Quest->SingleQuest && !GroupQuest->QuestArray.Contains(Node_Quest->SingleQuest))
	//			{
	//				GroupQuest->QuestArray.Add(Node_Quest->SingleQuest);
	//			}
	//		}

	//		//先将Node中Pre Quest和Post Quest数组清空
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//			if (Node_Quest && Node_Quest->SingleQuest)
	//			{
	//				Node_Quest->SingleQuest->PreQuestId.Empty();
	//				Node_Quest->SingleQuest->PostQuestId.Empty();

	//				//将每个Quest的ParentGroupId赋值
	//				Node_Quest->SingleQuest->ParentGroupId = GroupQuest->Id;
	//			}

	//		}

	//		//保存所有SingeleQuest的Level ID为GroupQuestTemplate的Level ID
	//		/*for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_Quest* CurrentNode = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//			if (CurrentNode)
	//			{
	//				CurrentNode->SingleQuest->LevelId = GroupQuest->LevelId;
	//				for (int j = 0; j < CurrentNode->SingleQuest->QuestActionNodeArray.Num(); j++)
	//				{
	//					CurrentNode->SingleQuest->QuestActionNodeArray[j]->LevelId = GroupQuest->LevelId;
	//				}
	//			}
	//		}*/

	//		//保存Node中Pre Quest和Post Quest
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_Quest* CurrentNode = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//			UMONode_Quest* ParentNode = nullptr;
	//			if (CurrentNode)
	//			{
	//				ParentNode = Cast<UMONode_Quest>(CurrentNode->GetParentNode());
	//			}
	//			if (ParentNode && CurrentNode && CurrentNode->SingleQuest && ParentNode->SingleQuest)
	//			{
	//				if (CurrentNode->SingleQuest->Id != 0 && !ParentNode->SingleQuest->PostQuestId.Contains(CurrentNode->SingleQuest->Id))
	//				{
	//					ParentNode->SingleQuest->PostQuestId.Add(CurrentNode->SingleQuest->Id);
	//				}

	//				if (ParentNode->SingleQuest->Id != 0 && !CurrentNode->SingleQuest->PreQuestId.Contains(ParentNode->SingleQuest->Id))
	//				{
	//					CurrentNode->SingleQuest->PreQuestId.Add(ParentNode->SingleQuest->Id);
	//				}
	//			}
	//		}

	//		//对Chapter中所有Node保存的SingleQuest保存成资源
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//			if (Node_Quest && Node_Quest->SingleQuest)
	//			{
	//				if (Node_Quest->SingleQuest->GetName() != FString::FromInt(Node_Quest->SingleQuest->Id))
	//				{
	//					if (Node_Quest->SingleQuest->Id != 0)
	//					{
	//						UEditorUtilityLibrary::RenameAsset(Node_Quest->SingleQuest, FString::FromInt(Node_Quest->SingleQuest->Id));
	//					}
	//				}
	//			}
	//		}

	//		//保存所有Node资源
	//		bool bSavePackages = UEditorLoadingAndSavingUtils::SavePackages(TempAllNodePackages, false);
	//	}


	//	if (GroupQuest->Id != 0)
	//	{
	//		if (FString::FromInt(GroupQuest->Id) != GroupQuest->GetName())
	//		{
	//			//如果GroupQuest改名了，那么之前的目录名也要改
	//			FString Path = FAssetData(GroupQuest).PackagePath.ToString();
	//			ContentBrowserUtils::RenameFolder(Path / FString::FromInt(GroupQuest->Id), Path / GroupQuest->GetName());
	//			UEditorUtilityLibrary::RenameAsset(GroupQuest, FString::FromInt(GroupQuest->Id));
	//		}
	//		FString Path = FAssetData(GroupQuest).PackageName.ToString();
	//		FQuestLibrary::QuestSaveAsset(Path);

	//		CurClickItem->ItemName = GroupQuest->Name;
	//	}
	//	else
	//	{
	//		FString Path = FAssetData(GroupQuest).PackageName.ToString();
	//		FQuestLibrary::QuestSaveAsset(Path);
	//	}

	//	if (CurClickItem->ItemName != "")
	//	{
	//		for (TPair<FTreeViewInstanceItem, TSharedPtr<STextBlock>>& element : ItemAndTextBlockMap)
	//		{
	//			if (element.Key == CurClickItem)
	//			{
	//				TSharedPtr<STextBlock> ItemBlock = element.Value;
	//				ItemBlock->SetText(FText::FromString(CurClickItem->ItemName));
	//			}
	//		}
	//	}

	//}

	////对于SingleQuest的处理
	//if (USingleQuest* SingleQuest = Cast<USingleQuest>(EditAsset))
	//{
	//	//先将Graph中保存到ChapterAsset中
	//	if (UEdGraph_QuestObjectivesProp* QuestObjectivesGraph = Cast<UEdGraph_QuestObjectivesProp>(GetQuestObjectivesEditor()->GetGraphEditor()->GetCurrentGraph()))
	//	{
	//		SingleQuest->NodeGraph = QuestObjectivesGraph;

	//		//更新所有Node的标题
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_QuestAction* Node_QuestAction = Cast<UMONode_QuestAction>(QuestObjectivesGraph->Nodes[i]);
	//			if (Node_QuestAction)
	//			{
	//				Node_QuestAction->UpdateTitle();
	//				//保存每个Action的ParentQuestID
	//				//保存Action的Level Id为SingleQuest的Level ID
	//				if (Node_QuestAction->QuestActionNode)
	//				{
	//					Node_QuestAction->QuestActionNode->ParentQuestId = SingleQuest->Id;
	//					//Node_QuestAction->QuestActionNode->LevelId = SingleQuest->LevelId;
	//				}


	//			}
	//		}


	//		//保存Graph中Node包含的所有Quest到变量QuestArray中
	//		SingleQuest->QuestActionNodeArray.Empty();
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_QuestAction* Node_QuestAction = Cast<UMONode_QuestAction>(QuestObjectivesGraph->Nodes[i]);
	//			if (Node_QuestAction && Node_QuestAction->QuestActionNode && !SingleQuest->QuestActionNodeArray.Contains(Node_QuestAction->QuestActionNode))
	//			{
	//				SingleQuest->QuestActionNodeArray.Add(Node_QuestAction->QuestActionNode);
	//			}
	//		}

	//		//先将Node中Pre Quest和Post Quest数组清空
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			UMONode_QuestAction* Node_QuestAction = Cast<UMONode_QuestAction>(QuestObjectivesGraph->Nodes[i]);
	//			if (Node_QuestAction && Node_QuestAction->QuestActionNode)
	//			{
	//				Node_QuestAction->QuestActionNode->PreQuestId.Empty();
	//				Node_QuestAction->QuestActionNode->PostQuestId.Empty();
	//			}
	//		}

	//		//保存Node中Pre Quest和Post Quest
	//		for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//		{
	//			if (UMONode_Root* RootNode = Cast<UMONode_Root>(QuestObjectivesGraph->Nodes[i]))
	//			{
	//				continue;
	//			}
	//			UMONode_QuestAction* CurrentNode = Cast<UMONode_QuestAction>(QuestObjectivesGraph->Nodes[i]);
	//			UMONode_QuestAction* ParentNode = nullptr;
	//			if (CurrentNode)
	//			{
	//				ParentNode = Cast<UMONode_QuestAction>(CurrentNode->GetParentNode());
	//			}
	//			if (ParentNode && CurrentNode && CurrentNode->QuestActionNode && ParentNode->QuestActionNode)
	//			{
	//				if (CurrentNode->QuestActionNode->Id != 0 && !ParentNode->QuestActionNode->PostQuestId.Contains(CurrentNode->QuestActionNode->Id))
	//				{
	//					ParentNode->QuestActionNode->PostQuestId.Add(CurrentNode->QuestActionNode->Id);
	//				}

	//				if (ParentNode->QuestActionNode->Id != 0 && !CurrentNode->QuestActionNode->PreQuestId.Contains(ParentNode->QuestActionNode->Id))
	//				{
	//					CurrentNode->QuestActionNode->PreQuestId.Add(ParentNode->QuestActionNode->Id);
	//				}
	//			}
	//		}
	//	}

	//	if (SingleQuest->Name != "")
	//	{
	//		CurClickItem->ItemName = SingleQuest->Name;
	//		for (TPair<FTreeViewInstanceItem, TSharedPtr<STextBlock>>& element : ItemAndTextBlockMap)
	//		{
	//			if (element.Key == CurClickItem)
	//			{
	//				TSharedPtr<STextBlock> ItemBlock = element.Value;
	//				ItemBlock->SetText(FText::FromString(CurClickItem->ItemName));
	//			}
	//		}
	//	}

	//	if (SingleQuest->GetName() != FString::FromInt(SingleQuest->Id))
	//	{
	//		if (SingleQuest->Id != 0)
	//		{
	//			UEditorUtilityLibrary::RenameAsset(SingleQuest, FString::FromInt(SingleQuest->Id));
	//		}
	//	}
	//	else
	//	{
	//		//TArray<UPackage*> OutermostPackagesToSave;
	//		//OutermostPackagesToSave.Add(SingleQuest->GetPackage());
	//		FString Path = FAssetData(SingleQuest).PackageName.ToString();
	//		USourceControlHelpers::CheckOutFile(Path, true);
	//		bool bSaveAsset = FQuestLibrary::QuestSaveAsset(Path);

	//		//FEditorFileUtils::PromptForCheckoutAndSave(OutermostPackagesToSave, true, true, 0,true);
	//	}

	//}
}

void SQuestTreeView::Construct(const FArguments& InArgs, TWeakPtr<class FQuestObjectivesEditor> InQuestObjectivesEditor)
{
	QuestObjectivesEditor = InQuestObjectivesEditor;
	InitTreeView();
	TSharedPtr<SVerticalBox> VerticalBox = SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.FillHeight(0.8)
		[
			SAssignNew(TreeViewPtr, STreeViewPtr)
			.TreeItemsSource(&TreeRootItems)
		.OnGenerateRow(this, &SQuestTreeView::GenerateTreeRow)
		.ItemHeight(30)
		.SelectionMode(ESelectionMode::Single)
		.OnGetChildren(this, &SQuestTreeView::GetChildrenForTree)
		.OnMouseButtonClick(this, &SQuestTreeView::OnMouseButtonClick)
		.OnSelectionChanged(this, &SQuestTreeView::OnSelectionChanged)
		//.OnContextMenuOpening(this, &SQuestTreeView::OnContextMenuOpening)
		.ClearSelectionOnClick(false)
		.HighlightParentNodesForSelection(true)
		]
	+ SVerticalBox::Slot()
		.AutoHeight()
		[

			SNew(SBox)
			.HeightOverride(50.0f)
		.Padding(10)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(0.0f)
		[
			SNew(SButton)
			.Visibility(EVisibility::Collapsed)
		.ContentPadding(3)
		.Content()
		[
			SNew(STextBlock)
			.Text(LOCTEXT("LastPage", "LastPage"))
		.ToolTipText(LOCTEXT("return", "return to the LastPage"))
		]
		]
	+ SHorizontalBox::Slot()
		.FillWidth(0.5)
		.Padding(0.0f)
		[
			SNew(SVerticalBox)
		]
	/*+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(0.0f)
		.HAlign(HAlign_Right)
		[
			SNew(SButton)
			.ContentPadding(3)
		.OnClicked(this, &SQuestTreeView::OnSaveButtonClick)
		.Content()
		[
			SNew(STextBlock)
			.Text(LOCTEXT("SaveAsset", "SaveAsset"))
		.ToolTipText(LOCTEXT("SaveAsset", "SaveAsset"))
		]
		]*/
		]
		];


	this->ChildSlot
		[
			VerticalBox.ToSharedRef()
		];
}


FReply SQuestTreeView::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.GetEffectingButton() == EKeys::RightMouseButton && !TreeViewPtr->IsRightClickScrolling())
	{
		for (TPair<FTreeViewInstanceItem, TSharedPtr<STableRow<FTreeViewInstanceItem>>>& element : ItemAndInstanceMap)
		{
			TSharedPtr<STableRow<FTreeViewInstanceItem>> InstanceItem = element.Value;
			if (InstanceItem && InstanceItem->IsHovered())
			{
				FTreeViewInstanceItem CurRightClickItem = element.Key;

				if (CurRightClickItem->QuestCategory == EQuestCategory::Type)
				{
					FMenuBuilder MenuBuilder(true, nullptr, nullptr, true);

					FUIAction NewQuestAction(FExecuteAction::CreateSP(this, &SQuestTreeView::OnNewChapterClicked, CurRightClickItem));
					MenuBuilder.BeginSection(NAME_None, NSLOCTEXT("PropertyView", "ExpansionHeading", "Expansion"));
					MenuBuilder.AddMenuEntry(NSLOCTEXT("PropertyView", "NewQuest", "New Chapter"), NSLOCTEXT("PropertyView", "CollapseAll_ToolTip", "New chapter"), FSlateIcon(), NewQuestAction);
					MenuBuilder.EndSection();
					FWidgetPath WidgetPath = MouseEvent.GetEventPath() != nullptr ? *MouseEvent.GetEventPath() : FWidgetPath();
					FSlateApplication::Get().PushMenu(AsShared(), WidgetPath, MenuBuilder.MakeWidget(), MouseEvent.GetScreenSpacePosition(), FPopupTransitionEffect::ContextMenu);
				}

				if (CurRightClickItem->QuestCategory == EQuestCategory::Chapter)
				{
					FMenuBuilder MenuBuilder(true, nullptr, nullptr, true);

					FUIAction DeleteQuestAction(FExecuteAction::CreateSP(this, &SQuestTreeView::OnDeleteChapterClicked, CurRightClickItem));

					MenuBuilder.BeginSection(NAME_None, NSLOCTEXT("PropertyView", "ExpansionHeading", "Expansion"));
					MenuBuilder.AddMenuEntry(NSLOCTEXT("PropertyView", "DelateQuest", "Delate Chapter"), NSLOCTEXT("PropertyView", "ExpandAll_ToolTip", "Delate chapter"), FSlateIcon(), DeleteQuestAction);
					MenuBuilder.EndSection();
					FWidgetPath WidgetPath = MouseEvent.GetEventPath() != nullptr ? *MouseEvent.GetEventPath() : FWidgetPath();
					FSlateApplication::Get().PushMenu(AsShared(), WidgetPath, MenuBuilder.MakeWidget(), MouseEvent.GetScreenSpacePosition(), FPopupTransitionEffect::ContextMenu);
				}


			}
		}
	}
	return FReply::Handled();
}


void SQuestTreeView::NewQuestAsset(class USingleQuest* SingleQuest)
{
	FTreeViewInstanceItem NewQuestItem = FTreeViewInstanceItem(new FTreeViewInstanceData(CurClickItem));
	NewQuestItem->ItemName = SingleQuest->GetName();
	NewQuestItem->QuestCategory = EQuestCategory::SingleQuest;
	NewQuestItem->QuestType = CurClickItem->QuestType;
	NewQuestItem->EditorAsset = SingleQuest;
	CurClickItem->Children.Add(NewQuestItem);

	TreeViewPtr->RequestTreeRefresh();
}


void SQuestTreeView::DeleteQuestAsset(class USingleQuest* SingleQuest)
{
	for (FTreeViewInstanceItem Item : CurClickItem->Children)
	{
		if (Item->EditorAsset == SingleQuest)
		{
			CurClickItem->Children.Remove(Item);
			break;
		}
	}

	TreeViewPtr->RequestTreeRefresh();
}


void SQuestTreeView::DoubleClickQuestNode(class USingleQuest* SingleQuest)
{
	for (FTreeViewInstanceItem Item : CurClickItem->Children)
	{
		if (Item->EditorAsset == SingleQuest)
		{
			TreeViewPtr->SetItemSelection(CurClickItem, false);
			TreeViewPtr->SetItemSelection(Item, true);
			TreeViewPtr->SetItemHighlighted(Item, false);
			TreeViewPtr->Private_OnItemClicked(Item);
			break;
		}
	}

	TreeViewPtr->RequestTreeRefresh();
}

void SQuestTreeView::SpawnRootFolder(const EQuestFolderType QuestFolderType)
{
	FTreeViewInstanceItem RootGoodImpressionLevel = FTreeViewInstanceItem(new FTreeViewInstanceData());
	RootGoodImpressionLevel->ItemName = UEnum::GetDisplayValueAsText(QuestFolderType).ToString();
	RootGoodImpressionLevel->QuestType = QuestFolderType;
	RootGoodImpressionLevel->QuestCategory = EQuestCategory::Type;
	TreeRootItems.Add(RootGoodImpressionLevel);
	ConstructChildrenRecursively(RootGoodImpressionLevel);
}

void SQuestTreeView::InitTreeView()
{
	/*FTreeViewInstanceItem Root = FTreeViewInstanceItem(new FTreeViewInstanceData(InRootPath));
	TreeRootItems.Add(Root);
	ConstructChildrenRecursively(Root);*/

	TreeRootItems.Empty();

	UEnum* Enum = StaticEnum<EQuestFolderType>();
	int32 NumEnums = Enum->NumEnums();
	for (int i = 0; i < NumEnums - 1; i++)
	{
		SpawnRootFolder((EQuestFolderType)Enum->GetValueByIndex(i));
	}

}

void SQuestTreeView::OnMouseButtonClick(FTreeViewInstanceItem ClickItem)
{
	CurClickItem = ClickItem;

	ShowChoiseChapterGraph(ClickItem);
}

TSharedPtr<SWidget> SQuestTreeView::OnContextMenuOpening()
{
	FMenuBuilder MenuBuilder(true, nullptr, nullptr, true);

	/*FUIAction DeleteQuestAction(FExecuteAction::CreateSP(this, &SQuestTreeView::OnDeleteQuestClicked));
	FUIAction NewQuestAction(FExecuteAction::CreateSP(this, &SQuestTreeView::OnNewQuestClicked));

	MenuBuilder.BeginSection(NAME_None, NSLOCTEXT("PropertyView", "ExpansionHeading", "Expansion"));
	MenuBuilder.AddMenuEntry(NSLOCTEXT("PropertyView", "NewQuest", "New Chapter"), NSLOCTEXT("PropertyView", "CollapseAll_ToolTip", "New chapter"), FSlateIcon(), NewQuestAction);
	MenuBuilder.AddMenuEntry(NSLOCTEXT("PropertyView", "DelateQuest", "Delate Chapter"), NSLOCTEXT("PropertyView", "ExpandAll_ToolTip", "Delate chapter"), FSlateIcon(), DeleteQuestAction);
	MenuBuilder.EndSection();*/

	//FWidgetPath WidgetPath = MouseEvent.GetEventPath() != nullptr ? *MouseEvent.GetEventPath() : FWidgetPath();

	//FSlateApplication::Get().PushMenu(AsShared(), WidgetPath, MenuBuilder.MakeWidget(), MouseEvent.GetScreenSpacePosition(), FPopupTransitionEffect::ContextMenu);

	return MenuBuilder.MakeWidget();
}

void SQuestTreeView::OnSelectionChanged(FTreeViewInstanceItem ChoiseItem, ESelectInfo::Type type)
{
	CurChangeItem = ChoiseItem;
}

void SQuestTreeView::ShowChoiseChapterGraph(FTreeViewInstanceItem ChoiseItem)
{
	//在右侧细节列表中显示章节的Asset的所有属性
	TArray<UObject*> TempObjects;
	TempObjects.Add(ChoiseItem->EditorAsset.Get());
	GetQuestObjectivesEditor()->PropertyEditorSetObjects(TempObjects);

	//对于章节的处理
	if (ChoiseItem->QuestCategory == EQuestCategory::Chapter || ChoiseItem->QuestCategory == EQuestCategory::SingleQuest)
	{
		//然后在图表中重新生成该chapter保存的所有节点连接关系
		USingleQuest* SingleQuest = Cast<USingleQuest>(ChoiseItem->EditorAsset);
		UGroupQuestTemplate* GroupQuestAsset = Cast<UGroupQuestTemplate>(ChoiseItem->EditorAsset);
		if (SingleQuest || GroupQuestAsset)
		{
			GetQuestObjectivesEditor()->SetCurrentEditorDataAsset(ChoiseItem->EditorAsset.Get());
			GetQuestObjectivesEditor()->InitQuestObjectivesProp();
		}
	}

}

void SQuestTreeView::OnDeleteChapterClicked(FTreeViewInstanceItem CurRightClickItem)
{
	TArray<UObject*> AssetsToDelete;
	if (CurRightClickItem->EditorAsset.Get())
	{
		GetQuestObjectivesEditor()->RemoveGraphEditor();

		bIsDeleteAsset = false;

		GetQuestObjectivesEditor()->SetCurrentEditorDataAsset(nullptr);

		AssetsToDelete.Add(CurRightClickItem->EditorAsset.Get());

		bool bHaveDelete = false;
		//如果是GroupQuest，要把整个目录删除
		if (UGroupQuestTemplate* GroupQuestTemplate = Cast<UGroupQuestTemplate>(CurRightClickItem->EditorAsset))
		{
			TArray<FString> PathsToDelete;
			FString Path = FAssetData(GroupQuestTemplate).PackageName.ToString();
			PathsToDelete.Add(Path);
			//先将目录中的所有文件全部删除
			TArray<UObject*> SingleQuestObjects = GetQuestObjectivesEditor()->GetAllObjectFromPathAndObjectClass(Path, USingleQuest::StaticClass());
			ObjectTools::ForceDeleteObjects(SingleQuestObjects, false);

			//再将QuestGroup删除
			ObjectTools::ForceDeleteObjects(AssetsToDelete, false);

			bHaveDelete = true;
			//然后再删除目录
			ContentBrowserUtils::DeleteFolders(PathsToDelete);
		}
		if (!bHaveDelete)
		{
			ObjectTools::ForceDeleteObjects(AssetsToDelete, false);
		}
	}
	CurRightClickItem->Parent->Children.Remove(CurRightClickItem);
	TreeViewPtr->RequestTreeRefresh();
}


void SQuestTreeView::OnNewChapterClicked(FTreeViewInstanceItem CurRightClickItem)
{
	//FString NewGroupQuestName = "";
	////创建Asset
	//FString CreateAssetFullPath;

	//int StartNum = 0;
	//if (GetQuestObjectivesEditor()->GetQuestTreeView()->GetCurClickItemQuestType() == EQuestFolderType::Quest_Plot)
	//{
	//	StartNum = 101;
	//}
	//else if (GetQuestObjectivesEditor()->GetQuestTreeView()->GetCurClickItemQuestType() == EQuestFolderType::Quest_Achievement)
	//{
	//	StartNum = 401;
	//}
	//else if (GetQuestObjectivesEditor()->GetQuestTreeView()->GetCurClickItemQuestType() == EQuestFolderType::Quest_Level)
	//{
	//	StartNum = 701;
	//}
	//for (int i = StartNum; i < 999; i++)
	//{
	//	FString CreateAssetPath = FQuestObjectivesEditor::QuestAssetPath / GetPathNameFromCurChooseQuestType(CurRightClickItem->QuestType);
	//	FString TempNum = FString::Printf(TEXT("%03d"), i);
	//	CreateAssetFullPath = CreateAssetPath / NewGroupQuestName + TempNum;
	//	UObject* TempObject = Cast<UObject>(StaticLoadObject(UObject::StaticClass(), NULL, *CreateAssetFullPath));
	//	if (TempObject == nullptr)
	//	{
	//		NewGroupQuestName += TempNum;
	//		break;
	//	}
	//}

	//UPackage* Package = CreatePackage(*(CreateAssetFullPath));
	//UGroupQuestTemplate* GroupQuestAsset = NewObject<UGroupQuestTemplate>(Package, UGroupQuestTemplate::StaticClass(), FName(NewGroupQuestName), EObjectFlags::RF_Public | RF_Standalone);
	//FAssetRegistryModule::AssetCreated(GroupQuestAsset);
	////这里看上去是命名，其实是让文件自动迁出
	//UEditorUtilityLibrary::RenameAsset(GroupQuestAsset, GroupQuestAsset->GetName());

	//GroupQuestAsset->Id = FCString::Atoi(*NewGroupQuestName);
	//FTreeViewInstanceItem NewChapterItem = FTreeViewInstanceItem(new FTreeViewInstanceData(CurRightClickItem));
	//NewChapterItem->ItemName = "NewChapter" + NewGroupQuestName;
	//NewChapterItem->QuestCategory = EQuestCategory::Chapter;
	//NewChapterItem->QuestType = CurRightClickItem->QuestType;
	//NewChapterItem->EditorAsset = GroupQuestAsset;
	//CurRightClickItem->Children.Add(NewChapterItem);

	//TreeViewPtr->RequestTreeRefresh();


}

void SQuestTreeView::ConstructChildrenRecursively(FTreeViewInstanceItem TreeItem)
{
	////if (TreeItem.IsValid())
	////{
	////	//找到此目录下所有文件
	////	TArray<FString> FindedFiles;
	////	FString SearchFile = TreeItem->DiskPath + "/*.*";
	////	IFileManager::Get().FindFiles(FindedFiles, *SearchFile, true, true);

	////	for (auto&element : FindedFiles)
	////	{
	////		//构建子节点
	////		FString FullPath = TreeItem->DiskPath + "/" + element;
	////		FTreeViewInstanceItem Child = FTreeViewInstanceItem(new FTreeViewInstanceData(FullPath, TreeItem));
	////		TreeItem->Children.Add(Child);
	////		if (Child->bIsDirectory)
	////		{
	////			//目录则递归获取其子节点信息
	////			ConstructChildrenRecursively(Child);
	////		}
	////	}
	////}

	//if (TreeItem->QuestCategory == EQuestCategory::Type)
	//{
	//	const FString Path = FQuestObjectivesEditor::QuestAssetPath / GetPathNameFromCurChooseQuestType(TreeItem->QuestType);
	//	TArray<UObject*>  GroupQuestObjects = GetQuestObjectivesEditor()->GetAllObjectFromPathAndObjectClass(Path, UGroupQuestTemplate::StaticClass());

	//	//将每个章节生成一个Item
	//	for (UObject* TempAsset : GroupQuestObjects)
	//	{
	//		if (UGroupQuestTemplate* GroupQuestAsset = Cast<UGroupQuestTemplate>(TempAsset))
	//		{
	//			FTreeViewInstanceItem ChildItem = FTreeViewInstanceItem(new FTreeViewInstanceData(TreeItem));
	//			if (GroupQuestAsset->Name == "")
	//			{
	//				ChildItem->ItemName = GroupQuestAsset->GetName();
	//			}
	//			else
	//			{
	//				ChildItem->ItemName = GroupQuestAsset->Name;
	//			}
	//			ChildItem->QuestCategory = EQuestCategory::Chapter;
	//			ChildItem->QuestType = TreeItem->QuestType;
	//			ChildItem->EditorAsset = TempAsset;
	//			TreeItem->Children.Add(ChildItem);
	//			ConstructChildrenRecursively(ChildItem);
	//		}
	//	}
	//}

	//if (TreeItem->QuestCategory == EQuestCategory::Chapter)
	//{
	//	//FString TypeFolderPath = FQuestObjectivesEditor::QuestAssetPath / GetPathNameFromCurChooseQuestType(TreeItem->QuestType);
	//	FString Path = FAssetData(TreeItem->EditorAsset).PackageName.ToString();
	//	TArray<UObject*>  SingleQuestObjects = GetQuestObjectivesEditor()->GetAllObjectFromPathAndObjectClass(Path, USingleQuest::StaticClass());

	//	//将每个章节生成一个Item
	//	for (UObject* TempAsset : SingleQuestObjects)
	//	{
	//		if (USingleQuest* GroupQuestAsset = Cast<USingleQuest>(TempAsset))
	//		{
	//			FTreeViewInstanceItem ChildItem = FTreeViewInstanceItem(new FTreeViewInstanceData(TreeItem));
	//			if (GroupQuestAsset->Name == "")
	//			{
	//				ChildItem->ItemName = GroupQuestAsset->GetName();
	//			}
	//			else
	//			{
	//				ChildItem->ItemName = GroupQuestAsset->Name;
	//			}
	//			ChildItem->QuestCategory = EQuestCategory::SingleQuest;
	//			ChildItem->QuestType = TreeItem->QuestType;
	//			ChildItem->EditorAsset = TempAsset;
	//			TreeItem->Children.Add(ChildItem);
	//		}
	//	}
	//}

}

FString SQuestTreeView::GetPathNameFromCurChooseQuestType(EQuestFolderType FolderType)
{
	FString TempFolderPath;
	switch (FolderType)
	{
	case EQuestFolderType::Quest_Plot:
		TempFolderPath = FQuestObjectivesEditor::PlotQuestName;
		break;
	case EQuestFolderType::Quest_Achievement:
		TempFolderPath = FQuestObjectivesEditor::AchievementQuestName;
		break;
	case EQuestFolderType::Quest_Level:
		TempFolderPath = FQuestObjectivesEditor::LevelQuestName;
		break;
	case EQuestFolderType::Quest_GoodImpression:
		TempFolderPath = FQuestObjectivesEditor::GoodImpressionName;
		break;
	default:
		break;
	}
	return TempFolderPath;
}

TSharedRef<ITableRow> SQuestTreeView::GenerateTreeRow(FTreeViewInstanceItem TreeItem, const TSharedRef<STableViewBase>& OwnerTable)
{
	TSharedPtr<SHorizontalBox> ItemBox;
	TSharedPtr<STextBlock> ItemBlock;

	check(TreeItem.IsValid());
	TSharedPtr<STableRow<FTreeViewInstanceItem>> InstanceItem = SNew(STableRow<FTreeViewInstanceItem>, OwnerTable)
		[
			SNew(SBox)
			.WidthOverride(200.0f)
		[
			SAssignNew(ItemBox, SHorizontalBox)
			/*+ SHorizontalBox::Slot()
			.VAlign(VAlign_Center)
			.AutoWidth()
			[
				TreeItem->CreateIcon().ToSharedRef()
			]*/
		+SHorizontalBox::Slot()
		.VAlign(VAlign_Center)
		.AutoWidth()
		[
			SAssignNew(ItemBlock, STextBlock)
			.Text(FText::FromString(TreeItem->ItemName))
		.Font(FStyleDefaults::GetFontInfo(17))
		]
		]
		];

	ItemAndInstanceMap.Add(TreeItem, InstanceItem);
	ItemAndTextBlockMap.Add(TreeItem, ItemBlock);

	return InstanceItem.ToSharedRef();
}

void SQuestTreeView::GetChildrenForTree(FTreeViewInstanceItem TreeItem, TArray< FTreeViewInstanceItem >& OutChildren)
{
	//获取TreeItem的子节点信息
	if (TreeItem.IsValid())
	{
		OutChildren = TreeItem->Children;
	}
}

FReply SQuestTreeView::OnSaveButtonClick()
{
	//保存当前选中条目的UObject
	if (CurClickItem == nullptr)
	{
		return FReply::Handled();
	}
	UObject* EditAsset = CurClickItem->EditorAsset.Get();

	SaveButtonOnClickWithAsset(EditAsset);

	TreeViewPtr->RequestTreeRefresh();

	return FReply::Handled();

}



FReply SQuestTreeView::OnFindBrowserOnClicked()
{
	if (CurClickItem && CurClickItem->EditorAsset.Get())
	{
		TArray<FAssetData> ObjectsToSync;
		ObjectsToSync.Add(FAssetData(CurClickItem->EditorAsset.Get()));
		GEditor->SyncBrowserToObjects(ObjectsToSync);
	}
	return FReply::Handled();
}

void SQuestTreeView::UpdateNodeQuestText(UMONode_Quest* Node_Quest)
{
	//if (Node_Quest)
	//{
	//	Node_Quest->UpdateTitle();

	//	//修改每个Quest在左侧显示的名称
	//	for (TPair<FTreeViewInstanceItem, TSharedPtr<STextBlock>>& element : ItemAndTextBlockMap)
	//	{
	//		if (element.Key->EditorAsset == Node_Quest->SingleQuest)
	//		{
	//			TSharedPtr<STextBlock> ItemBlock = element.Value;
	//			if (Node_Quest->SingleQuest)
	//			{
	//				if (Node_Quest->SingleQuest->Name == "")
	//				{
	//					ItemBlock->SetText(FText::FromString(FString::FromInt(Node_Quest->SingleQuest->Id)));
	//				}
	//				else
	//				{
	//					ItemBlock->SetText(FText::FromString(Node_Quest->SingleQuest->Name));
	//				}
	//			}
	//		}
	//	}
	//}
}

void SQuestTreeView::OnSearchTextChanged(FString SearchString)
{
	//这里是搜索框信息变化时的回调
	TreeViewPtr->ClearSelection();
	TreeViewPtr->ClearExpandedItems();

	if (SearchString == "")
	{
		InitTreeView();
		TreeViewPtr->RequestTreeRefresh();
		return;
	}

	for (FTreeViewInstanceItem ChildItem : TreeRootItems)
	{
		SearchChildrenItemWithText(ChildItem, SearchString);
	}

	TreeViewPtr->RequestTreeRefresh();
}

bool SQuestTreeView::SearchChildrenItemWithText(FTreeViewInstanceItem Item, FString SearchString)
{
	bool bContains = false;

	if (!Item.IsValid())
	{
		return bContains;
	}

	//否则遍历所有子节点，如果子节点包含该字符串，就将该节点添加到父节点中
	for (int i = 0; i < Item->Children.Num(); i++)
	{
		FTreeViewInstanceItem ChildItem = Item->Children[i];
		bool bChildContains = SearchChildrenItemWithText(ChildItem, SearchString);
		if (bChildContains)
		{
			bContains = true;
		}
		else
		{
			i--;
		}
	}

	//如果该节点包含搜索字符串，就展开父节点
	if ((Item->ItemName.Contains(SearchString) || bContains) && Item->Parent)
	{
		TreeViewPtr->SetItemExpansion(Item->Parent, true);
		bContains = true;
	}

	if (!bContains && Item->Parent && Item->Parent->Children.Contains(Item))
	{
		Item->Parent->Children.Remove(Item);
	}

	return bContains;

}


FTreeViewInstanceData::FTreeViewInstanceData()
{

}

FTreeViewInstanceData::FTreeViewInstanceData(TSharedPtr<FTreeViewInstanceData>& InParent)
	:Parent(InParent)
{
}

TSharedPtr<SWidget> FTreeViewInstanceData::CreateIcon() const
{
	FSlateColor IconColor = FSlateColor::UseForeground();
	//const FSlateBrush* Brush = FEditorStyle::GetBrush(bIsDirectory ? "ContentBrowser.AssetTreeFolderOpen" : "ContentBrowser.ColumnViewAssetIcon");
	FSlateBrush* Brush = nullptr;
	return SNew(SImage)
		.Image(Brush)
		.ColorAndOpacity(IconColor);
}

#undef LOCTEXT_NAMESPACE 
