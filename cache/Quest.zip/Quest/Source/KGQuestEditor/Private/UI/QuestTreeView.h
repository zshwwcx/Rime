// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Views/STableViewBase.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Views/STreeView.h"
#include "QuestScrollWidget.h"

class FTreeViewInstanceData
{
public:
	//用于构造根节点
	FTreeViewInstanceData();

	//用于构造子节点
	FTreeViewInstanceData(TSharedPtr<FTreeViewInstanceData>&InParent);

	//获得条目标志的Icon，用于区分目录还是文件
	TSharedPtr<SWidget> CreateIcon() const;

public:
	FString ItemName;
	EQuestFolderType QuestType = EQuestFolderType::Quest_Plot;
	EQuestCategory QuestCategory = EQuestCategory::Chapter;

#if WITH_EDITORONLY_DATA
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TWeakObjectPtr<UObject> EditorAsset = nullptr;
#endif

	//记录此节点对应的父节点
	TSharedPtr<FTreeViewInstanceData> Parent;

	//记录此节点对应的所有子节点
	TArray<TSharedPtr<FTreeViewInstanceData>> Children;
};

class SQuestTreeView : public SCompoundWidget
{
	SLATE_BEGIN_ARGS(SQuestTreeView) 
	{}
		SLATE_ARGUMENT(FString, RootPath)
	SLATE_END_ARGS()
public:
	/** Constructs this widget with InArgs */
	virtual void Construct(const FArguments& InArgs, TWeakPtr<class FQuestObjectivesEditor> InQuestObjectivesEditor);

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

	TSharedPtr<class FQuestObjectivesEditor> GetQuestObjectivesEditor() { return QuestObjectivesEditor.IsValid() ? QuestObjectivesEditor.Pin() : nullptr; }

	bool IsDeleteAsset() { return bIsDeleteAsset; }

	EQuestCategory GetCurClickItemCategory() { return CurClickItem->QuestCategory; }
	EQuestFolderType GetCurClickItemQuestType() { return CurClickItem->QuestType; }

	UObject* GetCurClickItemAsset() { return CurClickItem->EditorAsset.Get(); }

	void NewQuestAsset(class USingleQuest* SingleQuest);

	void DeleteQuestAsset(class USingleQuest* SingleQuest);

	void DoubleClickQuestNode(class USingleQuest* SingleQuest);

	void SpawnRootFolder(const EQuestFolderType QuestFolderType);

	//用于更新Quest节点的显示和在左侧下拉列表的名称的显示
	void UpdateNodeQuestText(class UMONode_Quest* Node_Quest);

	void OnSearchTextChanged(FString SearchString);

	FReply OnSaveButtonClick();

	FReply OnFindBrowserOnClicked();

	void SaveButtonOnClickWithAsset(UObject* EditAsset);


	
private:
	typedef TSharedPtr<FTreeViewInstanceData> FTreeViewInstanceItem;
	typedef STreeView<FTreeViewInstanceItem> STreeViewPtr;
	//根据根目录路径初始化TreeRootItems
	void InitTreeView();

	void ConstructChildrenRecursively(FTreeViewInstanceItem TreeItem);


	bool SearchChildrenItemWithText(FTreeViewInstanceItem Item, FString SearchString);
	

	//创建TreeItem的函数
	TSharedRef<ITableRow> GenerateTreeRow(FTreeViewInstanceItem TreeItem, const TSharedRef<STableViewBase>& OwnerTable);

	//获取某个节点的子节点信息
	void GetChildrenForTree(FTreeViewInstanceItem TreeItem, TArray< FTreeViewInstanceItem >& OutChildren);

	FString GetPathNameFromCurChooseQuestType(EQuestFolderType FolderType);

	void OnMouseButtonClick(FTreeViewInstanceItem ClickItem);

	void OnSelectionChanged(FTreeViewInstanceItem ChoiseItem, ESelectInfo::Type type);

	void ShowChoiseChapterGraph(FTreeViewInstanceItem ChoiseItem);

	void OnDeleteChapterClicked(FTreeViewInstanceItem CurRightClickItem);

	void OnNewChapterClicked(FTreeViewInstanceItem CurRightClickItem);

	TSharedPtr<SWidget> OnContextMenuOpening();


private:
	//实际的TreeView
	TSharedPtr<STreeViewPtr> TreeViewPtr;

	//包含所有根节点的数组
	TArray<FTreeViewInstanceItem> TreeRootItems;

	TWeakPtr<class FQuestObjectivesEditor> QuestObjectivesEditor;

	//当前选择的任务类型
	EQuestFolderType CurChooseQuestType = EQuestFolderType::Quest_Plot;

	FTreeViewInstanceItem CurClickItem;

	FTreeViewInstanceItem CurChangeItem;

	TMap<FTreeViewInstanceItem, TSharedPtr<STableRow<FTreeViewInstanceItem>>> ItemAndInstanceMap;

	TMap<FTreeViewInstanceItem, TSharedPtr<STextBlock>> ItemAndTextBlockMap;

	bool bIsDeleteAsset = false;


};
