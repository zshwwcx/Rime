// Copyright 2019-2020 Gamemakin LLC. All Rights Reserved.
#pragma once
#include "Widgets/SCompoundWidget.h"

class SQuestScrollItemWidget : public SCompoundWidget
{
public:

	SLATE_BEGIN_ARGS(SQuestScrollItemWidget)
	{
	}

	SLATE_END_ARGS()


public:
	
	void Construct(const FArguments& Args);


};