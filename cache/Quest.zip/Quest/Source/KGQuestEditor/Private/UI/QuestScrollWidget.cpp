// Copyright 2019-2020 Gamemakin LLC. All Rights Reserved.

#include "QuestScrollWidget.h"
//#include "UI/LintReportAssetDetails.h"
#include "QuestScrollItemWidget.h"
#include "QuestListViewWidget.h"
#include "Internationalization/Internationalization.h"
#include "Framework/MultiBox/SToolBarButtonBlock.h"
#include "ObjectTools.h"
#include "QuestTemplate.h"
#include "EditorUtilityLibrary.h"
#include "../Graph/EdGraph_QuestObjectivesProp.h"
#include "FQuestObjectivesEditor.h"
#include "GraphEditor.h"
#include "../Graph/MONode_Quest.h"
#include "../Graph/MONode_QuestAction.h"
#include "../Private/ContentBrowserUtils.h"
#include "QuestLibrary.h"
#include "../Graph/MONode_Root.h"
#include "FileHelpers.h"
#include "SourceControlHelpers.h"



#define LOCTEXT_NAMESPACE "Editor.QuestScrollWidget"


void SQuestScrollWidget::Construct(const FArguments& Args, TWeakPtr<class FQuestObjectivesEditor> InQuestObjectivesEditor)
{
	QuestObjectivesEditor = InQuestObjectivesEditor;

	ChildSlot
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
		.FillHeight(0.8)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		.VAlign(VAlign_Fill)
		.FillWidth(1.0f)
		.Padding(1.0f, 1.0f, 1.0f, 1.0f)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
		.FillHeight(1.0f)
		[
			SNew(SBorder)
			.Padding(FMargin(3))
		.BorderImage(FAppStyle::Get().GetBrush("ToolPanel.DarkGroupBorder"))
		[
			SAssignNew(ListViewWidget, SQuestListViewWidget)
		]
		]
		]
		]
	+ SVerticalBox::Slot()
		.AutoHeight()
		[

			SNew(SBox)
			.HeightOverride(50.0f)
		.Padding(10)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(0.0f)
		[
			SAssignNew(LastPageButton, SButton)
			.Visibility(this, &SQuestScrollWidget::OnGetLastPageVisibility)
		.ContentPadding(3)
		.OnClicked(this, &SQuestScrollWidget::OnLastPageButtonClicked)
		.Content()
		[
			SNew(STextBlock)
			.Text(LOCTEXT("LastPage", "LastPage"))
		.ToolTipText(LOCTEXT("return", "return to the LastPage"))
		]
		]
	+ SHorizontalBox::Slot()
		.FillWidth(0.5)
		.Padding(0.0f)
		[
			SNew(SVerticalBox)
		]
	+ SHorizontalBox::Slot()
		.AutoWidth()
		.Padding(0.0f)
		.HAlign(HAlign_Right)
		[
			SAssignNew(SaveAssetButton, SButton)
			.Visibility(this, &SQuestScrollWidget::OnGetLastPageVisibility)
		.ContentPadding(3)
		.OnClicked(this, &SQuestScrollWidget::OnSaveButtonClicked)
		.Content()
		[
			SNew(STextBlock)
			.Text(LOCTEXT("SaveAsset", "SaveAsset"))
		.ToolTipText(LOCTEXT("SaveAsset", "SaveAsset"))
		]



		]]
		]


		];

	ListViewWidget->InitQuestListView(SharedThis(this));
}


EVisibility SQuestScrollWidget::OnGetLastPageVisibility() const
{
	return EVisibility::Visible;
	//return CurrentStats.IsValid() ? EVisibility::Visible : EVisibility::Collapsed;
}

FReply SQuestScrollWidget::OnLastPageButtonClicked()
{
	if (GetQuestObjectivesEditor())
	{
		GetQuestObjectivesEditor()->RemoveGraphEditor();
	}

	if (ListViewWidget->GetCurrentPage() == 2)
	{
		ListViewWidget->EnterToPageOne();
	}
	if (ListViewWidget->GetCurrentPage() == 3)
	{
		
		ListViewWidget->EnterToPageTwo();
	}

	return FReply::Handled();

}

//保存
FReply SQuestScrollWidget::OnSaveButtonClicked()
{
	//保存当前选中条目的UObject
	//TSharedPtr<FListViewItemData> CurChoiseListViewItemData = ListViewWidget->GetCurChoiseListViewItemData();
	//if (CurChoiseListViewItemData)
	//{
	//	UObject* EditAsset = CurChoiseListViewItemData->EditorAsset;

	//	//对于QuestGroup的处理
	//	UGroupQuestTemplate* GroupQuest = Cast<UGroupQuestTemplate>(EditAsset);
	//	if (GroupQuest)
	//	{
	//		//先将Graph中保存到ChapterAsset中
	//		if (UEdGraph_QuestObjectivesProp* QuestObjectivesGraph = Cast<UEdGraph_QuestObjectivesProp>(GetQuestObjectivesEditor()->GetGraphEditor()->GetCurrentGraph()))
	//		{
	//			GroupQuest->NodeGraph = QuestObjectivesGraph;

	//			//更新所有Node的标题
	//			for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//			{
	//				UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//				if (Node_Quest)
	//				{
	//					Node_Quest->UpdateTitle();
	//				}
	//			}

	//			//保存Graph中Node包含的所有Quest到变量QuestArray中
	//			GroupQuest->QuestArray.Empty();
	//			for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//			{
	//				UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//				if (Node_Quest->SingleQuest && !GroupQuest->QuestArray.Contains(Node_Quest->SingleQuest))
	//				{
	//					GroupQuest->QuestArray.Add(Node_Quest->SingleQuest);
	//				}
	//			}

	//			//先将Node中Pre Quest和Post Quest数组清空
	//			for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//			{
	//				UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//				if (Node_Quest && Node_Quest->SingleQuest)
	//				{
	//					Node_Quest->SingleQuest->PreQuestId.Empty();
	//					Node_Quest->SingleQuest->PostQuestId.Empty();

	//					//将每个Quest的ParentGroupId赋值
	//					Node_Quest->SingleQuest->ParentGroupId = GroupQuest->Id;
	//				}

	//			}

	//			//保存Node中Pre Quest和Post Quest
	//			for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//			{
	//				UMONode_Quest* CurrentNode = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//				UMONode_Quest* ParentNode = Cast<UMONode_Quest>(CurrentNode->GetParentNode());
	//				if (ParentNode && CurrentNode && CurrentNode->SingleQuest && ParentNode->SingleQuest)
	//				{
	//					if (CurrentNode->SingleQuest->Id !=  0&& !ParentNode->SingleQuest->PostQuestId.Contains(CurrentNode->SingleQuest->Id))
	//					{
	//						ParentNode->SingleQuest->PostQuestId.Add(CurrentNode->SingleQuest->Id);
	//					}

	//					if (ParentNode->SingleQuest->Id != 0 && !CurrentNode->SingleQuest->PreQuestId.Contains(ParentNode->SingleQuest->Id))
	//					{
	//						CurrentNode->SingleQuest->PreQuestId.Add(ParentNode->SingleQuest->Id);
	//					}
	//				}
	//			}

	//			//对Chapter中所有Node保存的SingleQuest保存成资源
	//			for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//			{
	//				UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(QuestObjectivesGraph->Nodes[i]);
	//				if (Node_Quest && Node_Quest->SingleQuest)
	//				{
	//					if (Node_Quest->SingleQuest->GetName() != FString::FromInt(Node_Quest->SingleQuest->Id))
	//					{
	//						if (Node_Quest->SingleQuest->Id != 0)
	//						{
	//							UEditorUtilityLibrary::RenameAsset(Node_Quest->SingleQuest, FString::FromInt(Node_Quest->SingleQuest->Id));
	//						}
	//					}
	//				}
	//			}

	//		}


	//		if (GroupQuest->Id != 0)
	//		{
	//			if (FString::FromInt(GroupQuest->Id) != GroupQuest->GetName())
	//			{
	//				//如果GroupQuest改名了，那么之前的目录名也要改
	//				FString Path = FAssetData(GroupQuest).PackagePath.ToString();
	//				ContentBrowserUtils::RenameFolder(Path / FString::FromInt(GroupQuest->Id), Path / GroupQuest->GetName());
	//				UEditorUtilityLibrary::RenameAsset(GroupQuest, FString::FromInt(GroupQuest->Id));
	//			}
	//			FString Path = FAssetData(GroupQuest).PackageName.ToString();


	//			FQuestLibrary::QuestSaveAsset(Path);

	//			CurChoiseListViewItemData->ItemName = GroupQuest->Name;

	//			TMap<TSharedPtr<FListViewItemData>, TSharedPtr<STextBlock>> ListViewItemAndButtonMap = ListViewWidget->GetListViewItemAndButtonMap();
	//			for (TPair<TSharedPtr<FListViewItemData>, TSharedPtr<STextBlock>>& element : ListViewItemAndButtonMap)
	//			{
	//				if (element.Key == CurChoiseListViewItemData)
	//				{
	//					TSharedPtr<STextBlock> ItemTextBlock = element.Value;
	//					ItemTextBlock->SetText(FText::FromString(GroupQuest->Name));
	//				}
	//			}
	//		}
	//		else
	//		{
	//			FString Path = FAssetData(GroupQuest).PackageName.ToString();
	//			FQuestLibrary::QuestSaveAsset(Path);
	//		}

	//	}

	//	//对于SingleQuest的处理
	//	if (USingleQuest* SingleQuest = Cast<USingleQuest>(EditAsset))
	//	{
	//		//先将Graph中保存到ChapterAsset中
	//		if (UEdGraph_QuestObjectivesProp* QuestObjectivesGraph = Cast<UEdGraph_QuestObjectivesProp>(GetQuestObjectivesEditor()->GetGraphEditor()->GetCurrentGraph()))
	//		{
	//			SingleQuest->NodeGraph = QuestObjectivesGraph;

	//			//更新所有Node的标题
	//			for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//			{
	//				UMONode_QuestAction* Node_QuestAction = Cast<UMONode_QuestAction>(QuestObjectivesGraph->Nodes[i]);
	//				if (Node_QuestAction)
	//				{
	//					Node_QuestAction->UpdateTitle();
	//				}
	//			}

	//			//保存Graph中Node包含的所有Quest到变量QuestArray中
	//			SingleQuest->QuestActionNodeArray.Empty();
	//			for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//			{
	//				UMONode_QuestAction* Node_QuestAction = Cast<UMONode_QuestAction>(QuestObjectivesGraph->Nodes[i]);
	//				if (Node_QuestAction && Node_QuestAction->QuestActionNode && !SingleQuest->QuestActionNodeArray.Contains(Node_QuestAction->QuestActionNode))
	//				{
	//					SingleQuest->QuestActionNodeArray.Add(Node_QuestAction->QuestActionNode);
	//				}
	//			}

	//			//先将Node中Pre Quest和Post Quest数组清空
	//			for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//			{
	//				UMONode_QuestAction* Node_QuestAction = Cast<UMONode_QuestAction>(QuestObjectivesGraph->Nodes[i]);
	//				if (Node_QuestAction && Node_QuestAction->QuestActionNode)
	//				{
	//					Node_QuestAction->QuestActionNode->PreQuestId.Empty();
	//					Node_QuestAction->QuestActionNode->PostQuestId.Empty();
	//				}
	//			}

	//			//保存Node中Pre Quest和Post Quest
	//			for (int i = 0; i < QuestObjectivesGraph->Nodes.Num(); i++)
	//			{
	//				if (UMONode_Root* RootNode = Cast<UMONode_Root>(QuestObjectivesGraph->Nodes[i]))
	//				{
	//					continue;
	//				}
	//				UMONode_QuestAction* CurrentNode = Cast<UMONode_QuestAction>(QuestObjectivesGraph->Nodes[i]);
	//				UMONode_QuestAction* ParentNode = Cast<UMONode_QuestAction>(CurrentNode->GetParentNode());
	//				if (ParentNode && CurrentNode && CurrentNode->QuestActionNode && ParentNode->QuestActionNode)
	//				{
	//					if (CurrentNode->QuestActionNode->Id != 0 && !ParentNode->QuestActionNode->PostQuestId.Contains(CurrentNode->QuestActionNode->Id))
	//					{
	//						ParentNode->QuestActionNode->PostQuestId.Add(CurrentNode->QuestActionNode->Id);
	//					}

	//					if (ParentNode->QuestActionNode->Id != 0 && !CurrentNode->QuestActionNode->PreQuestId.Contains(ParentNode->QuestActionNode->Id))
	//					{
	//						CurrentNode->QuestActionNode->PreQuestId.Add(ParentNode->QuestActionNode->Id);
	//					}
	//				}
	//			}
	//		}

	//		if (SingleQuest->Name != "")
	//		{
	//			CurChoiseListViewItemData->ItemName = SingleQuest->Name;

	//			TMap<TSharedPtr<FListViewItemData>, TSharedPtr<STextBlock>> ListViewItemAndButtonMap = ListViewWidget->GetListViewItemAndButtonMap();
	//			for (TPair<TSharedPtr<FListViewItemData>, TSharedPtr<STextBlock>>& element : ListViewItemAndButtonMap)
	//			{
	//				if (element.Key == CurChoiseListViewItemData)
	//				{
	//					TSharedPtr<STextBlock> ItemTextBlock = element.Value;
	//					ItemTextBlock->SetText(FText::FromString(SingleQuest->Name));
	//				}
	//			}
	//		}

	//		if (SingleQuest->GetName() != FString::FromInt(SingleQuest->Id))
	//		{
	//			if (SingleQuest->Id != 0)
	//			{
	//				UEditorUtilityLibrary::RenameAsset(SingleQuest, FString::FromInt(SingleQuest->Id));
	//			}
	//		}
	//		else
	//		{
	//			//TArray<UPackage*> OutermostPackagesToSave;
	//			//OutermostPackagesToSave.Add(SingleQuest->GetPackage());
	//			FString Path = FAssetData(SingleQuest).PackageName.ToString();
	//			USourceControlHelpers::CheckOutFile(Path,true);
	//			bool bSaveAsset = FQuestLibrary::QuestSaveAsset(Path);

	//			//FEditorFileUtils::PromptForCheckoutAndSave(OutermostPackagesToSave, true, true, 0,true);
	//		}

	//	}



	//}



	return FReply::Handled();

}

void SQuestScrollWidget::RefreshButtonVisibility()
{
	if (ListViewWidget->GetCurrentPage() != 1)
	{
		SaveAssetButton->SetVisibility(EVisibility::Visible);
		LastPageButton->SetVisibility(EVisibility::Visible);
	}
	else
	{
		SaveAssetButton->SetVisibility(EVisibility::Hidden);
		LastPageButton->SetVisibility(EVisibility::Hidden);
	}
}

#undef LOCTEXT_NAMESPACE
