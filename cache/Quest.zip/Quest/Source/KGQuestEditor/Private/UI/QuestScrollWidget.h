// Copyright 2019-2020 Gamemakin LLC. All Rights Reserved.
#pragma once
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SScrollBox.h"
#include "../Private/Widgets/Views/SListPanel.h"


UENUM(BlueprintType, Meta = (Bitflags))
enum class EQuestFolderType : uint8
{
	Quest_Plot = 0				UMETA(DisplayName = "剧情任务"),
	Quest_Achievement				UMETA(DisplayName = "成就任务"),
	Quest_Level					UMETA(DisplayName = "关卡任务"),
	Quest_GoodImpression			UMETA(DisplayName = "好感度任务")

};

UENUM(BlueprintType, Meta = (Bitflags))
enum class EQuestCategory : uint8
{
	Type = 0			UMETA(DisplayName = "任务种类，第一层"),
	Chapter				UMETA(DisplayName = "章节任务，第二层"),
	SingleQuest		UMETA(DisplayName = "单个任务，第三层"),

};


struct FListViewItemData {

	FString ItemName;
	EQuestFolderType QuestType = EQuestFolderType::Quest_Plot;
	EQuestCategory QuestCategory = EQuestCategory::Chapter;

#if WITH_EDITORONLY_DATA
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	TWeakObjectPtr<UObject> EditorAsset = nullptr;
#endif

};

class SQuestScrollWidget : public SCompoundWidget
{
public:

	SLATE_BEGIN_ARGS(SQuestScrollWidget)
	{
	}

	SLATE_END_ARGS()


public:

	void Construct(const FArguments& Args, TWeakPtr<class FQuestObjectivesEditor> InQuestObjectivesEditor);

	EVisibility OnGetLastPageVisibility() const;
	FReply OnLastPageButtonClicked();
	FReply OnSaveButtonClicked();
	void RefreshButtonVisibility();

	TSharedPtr<class SQuestListViewWidget> GetListViewWidget() { return ListViewWidget; }

	TSharedPtr<class FQuestObjectivesEditor> GetQuestObjectivesEditor() { return QuestObjectivesEditor.IsValid() ? QuestObjectivesEditor.Pin() : nullptr; }

private:

	TSharedPtr<class SQuestListViewWidget> ListViewWidget;
	TWeakPtr<class FQuestObjectivesEditor> QuestObjectivesEditor;
	TSharedPtr<class SButton> LastPageButton;
	TSharedPtr<class SButton> SaveAssetButton;





};