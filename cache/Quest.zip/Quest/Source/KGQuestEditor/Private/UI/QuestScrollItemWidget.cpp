// Copyright 2019-2020 Gamemakin LLC. All Rights Reserved.

#include "QuestScrollItemWidget.h"


void SQuestScrollItemWidget::Construct(const FArguments& Args)
{

	ChildSlot
		[
			SNew(SVerticalBox)
			+SVerticalBox::Slot()
			.AutoHeight()
		.Padding(3.0f)
		[
			SNew(SEditableText)
			.Text(FText::FromString("dsfewrewr"))
			
		]
		];
}
