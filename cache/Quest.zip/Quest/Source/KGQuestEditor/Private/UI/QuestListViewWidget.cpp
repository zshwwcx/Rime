#include "QuestListViewWidget.h"
#include "Widgets/Input/SCheckBox.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "IDetailTreeNode.h"
#include "Framework/Commands/UIAction.h"
#include "../Private/SDetailTableRowBase.h"
#include "../Widget/SCCGraphPalette.h"
#include "FQuestObjectivesEditor.h"
#include "QuestTemplate.h"
#include "ObjectTools.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "../Graph/EdGraph_QuestObjectivesProp.h"
#include "../Graph/MONode_Quest.h"
#include "../Private/ContentBrowserUtils.h"
#include "EditorUtilityLibrary.h"

SQuestListViewWidget::~SQuestListViewWidget()
{
	
}

void SQuestListViewWidget::Construct(const FArguments& InArgs)
{
	ChildSlot[
		SAssignNew(ListView, SListView<TSharedPtr<FListViewItemData>>)
			.ListItemsSource(&DataList)
			.ScrollbarVisibility(EVisibility::All)
			.SelectionMode(ESelectionMode::Single)
			.OnGenerateRow(this, &SQuestListViewWidget::OnGenerateRow)
			.OnSelectionChanged(this, &SQuestListViewWidget::OnSelectionChanged)
	];
}


void SQuestListViewWidget::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{

}

TSharedRef<ITableRow> SQuestListViewWidget::OnGenerateRow(TSharedPtr<FListViewItemData> Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	TSharedPtr<STextBlock> ItemTextBlock;

	TSharedPtr<class SHorizontalBox> TempItemBox = SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.HAlign(HAlign_Fill)
		.VAlign(VAlign_Fill)
		[
			SNew(SOverlay)
			+ SOverlay::Slot()
		.VAlign(VAlign_Center)
		[
			SNew(SSpacer)
			.Size(FVector2D(1, 30))
		]

	+ SOverlay::Slot()
		.HAlign(HAlign_Fill)
		.VAlign(VAlign_Fill)
		[
			SNew(SButton)
			.HAlign(HAlign_Fill)
		.VAlign(VAlign_Fill)
		.OnClicked(this, &SQuestListViewWidget::OnClick_Item, Item)
		[
			SAssignNew(ItemTextBlock, STextBlock)
			.Text(FText::FromString(Item->ItemName))

		]
		]

		];

	ListViewItemAndTextBlockMap.Add(Item, ItemTextBlock);

	return
		SNew(STableRow<TSharedPtr<FListViewItemData>>, OwnerTable)
		[
			TempItemBox.ToSharedRef()
		];
}

FReply SQuestListViewWidget::OnClick_Item(TSharedPtr<FListViewItemData> ChoiseItemData)
{
	CurChoiseListViewItemData = ChoiseItemData;

	if (CurrentPage == 1)
	{
		//获取当前进入的任务类型
		if (DataList[0] == ChoiseItemData)
		{
			CurChooseQuestType = EQuestFolderType::Quest_Plot;
		}
		if (DataList[1] == ChoiseItemData)
		{
			CurChooseQuestType = EQuestFolderType::Quest_Achievement;
		}
		if (DataList[2] == ChoiseItemData)
		{
			CurChooseQuestType = EQuestFolderType::Quest_Level;
		}

		EnterToPageTwo();
		return FReply::Handled();
	}

	if (CurrentPage == 2 || CurrentPage == 3)
	{
		//在第二页面时，单击不会进入第三页面，而是显示Graph中任务关系
		ShowChoiseChapterGraph(ChoiseItemData);
		return FReply::Handled();

	}


	return FReply::Handled();
}

void SQuestListViewWidget::OnSelectionChanged(TSharedPtr<FListViewItemData> ChoiseItemData, ESelectInfo::Type type)
{

}

void SQuestListViewWidget::SetItemList(TArray<TSharedPtr<FListViewItemData>> list)
{
	DataList = list;
	//刷新UI
	ListView->RequestListRefresh();
}

FReply SQuestListViewWidget::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	//第一页不能添加和删除操作
	if (CurrentPage == 1)
	{
		return FReply::Handled();

	}

	//保存是哪一行点击了右键
	for (TPair<TSharedPtr<FListViewItemData>, TSharedPtr<STextBlock>>& element : ListViewItemAndTextBlockMap)
	{
		TSharedPtr<STextBlock> ItemTextBlock = element.Value;
		if (ItemTextBlock && ItemTextBlock->IsHovered())
		{
			CurDeleteItem = element.Key;
		}
	}

	//弹出右键的新建和删除下拉列表
	//第三页不让创建任务和删除任务，全部在第二页面去做
	if (CurrentPage == 2)
	{
		FMenuBuilder MenuBuilder(true, nullptr, nullptr, true);

		FUIAction DeleteQuestAction(FExecuteAction::CreateSP(this, &SQuestListViewWidget::OnDeleteQuestClicked));
		FUIAction NewQuestAction(FExecuteAction::CreateSP(this, &SQuestListViewWidget::OnNewQuestClicked));

		MenuBuilder.BeginSection(NAME_None, NSLOCTEXT("PropertyView", "ExpansionHeading", "Expansion"));
		MenuBuilder.AddMenuEntry(NSLOCTEXT("PropertyView", "NewQuest", "New Chapter"), NSLOCTEXT("PropertyView", "CollapseAll_ToolTip", "New chapter"), FSlateIcon(), NewQuestAction);
		MenuBuilder.AddMenuEntry(NSLOCTEXT("PropertyView", "DelateQuest", "Delate Chapter"), NSLOCTEXT("PropertyView", "ExpandAll_ToolTip", "Delate chapter"), FSlateIcon(), DeleteQuestAction);
		MenuBuilder.EndSection();


		FWidgetPath WidgetPath = MouseEvent.GetEventPath() != nullptr ? *MouseEvent.GetEventPath() : FWidgetPath();

		FSlateApplication::Get().PushMenu(AsShared(), WidgetPath, MenuBuilder.MakeWidget(), MouseEvent.GetScreenSpacePosition(), FPopupTransitionEffect::ContextMenu);
	}

	return FReply::Handled();

}

void SQuestListViewWidget::EnterToPageOne()
{
	EmptyDataList();

	CurrentPage = 1;
	QuestScrollWidget->RefreshButtonVisibility();

	TArray<TSharedPtr<FListViewItemData>> TempDataList;

	//剧情任务
	TSharedPtr<FListViewItemData> TempListViewItemData = MakeShareable(new FListViewItemData);
	TempListViewItemData->ItemName = FQuestObjectivesEditor::PlotQuestName;
	TempListViewItemData->QuestType = EQuestFolderType::Quest_Plot;
	TempListViewItemData->QuestCategory = EQuestCategory::Type;
	TempDataList.Add(TempListViewItemData);

	//成就任务
	TSharedPtr<FListViewItemData> TempListViewItemData1 = MakeShareable(new FListViewItemData);
	TempListViewItemData1->ItemName = FQuestObjectivesEditor::AchievementQuestName;
	TempListViewItemData1->QuestType = EQuestFolderType::Quest_Achievement;
	TempListViewItemData1->QuestCategory = EQuestCategory::Type;
	TempDataList.Add(TempListViewItemData1);

	//关卡任务
	TSharedPtr<FListViewItemData> TempListViewItemData2 = MakeShareable(new FListViewItemData);
	TempListViewItemData2->ItemName = FQuestObjectivesEditor::LevelQuestName;
	TempListViewItemData2->QuestType = EQuestFolderType::Quest_Level;
	TempListViewItemData2->QuestCategory = EQuestCategory::Type;
	TempDataList.Add(TempListViewItemData2);

	SetItemList(TempDataList);
}

void SQuestListViewWidget::EnterToPageTwo()
{
	//EmptyDataList();

	//CurrentPage = 2;
	//QuestScrollWidget->RefreshButtonVisibility();

	//RefreshPaletteItems();

	////在第二页根据选择剧情还是成就任务，来读取所有UGroupQuestTemplate类型的UObject
	//TSharedPtr<class FQuestObjectivesEditor> QuestObjectivesEditor = QuestScrollWidget->GetQuestObjectivesEditor();
	//if (QuestObjectivesEditor)
	//{
	//	TArray<UObject*>  GroupQuestObjects = QuestObjectivesEditor->GetAllObjectFromPathAndObjectClass(FQuestObjectivesEditor::QuestAssetPath / GetPathNameFromCurChooseQuestType(), UGroupQuestTemplate::StaticClass());

	//	//将每个章节生成一个Item
	//	for (UObject* TempAsset : GroupQuestObjects)
	//	{
	//		if (UGroupQuestTemplate* GroupQuestAsset = Cast<UGroupQuestTemplate>(TempAsset))
	//		{
	//			TSharedPtr<FListViewItemData> TempListViewItemData = MakeShareable(new FListViewItemData);
	//			if (GroupQuestAsset->Name == "")
	//			{
	//				TempListViewItemData->ItemName = GroupQuestAsset->GetName();
	//			}
	//			else
	//			{
	//				TempListViewItemData->ItemName = GroupQuestAsset->Name;
	//			}
	//			TempListViewItemData->QuestCategory = EQuestCategory::Chapter;
	//			TempListViewItemData->QuestType = CurChooseQuestType;
	//			TempListViewItemData->EditorAsset = TempAsset;
	//			DataList.Add(TempListViewItemData);

	//			SetItemList(DataList);
	//		}
	//	}

	//}

}

FString SQuestListViewWidget::GetPathNameFromCurChooseQuestType()
{
	FString TempFolderPath;
	switch (CurChooseQuestType)
	{
	case EQuestFolderType::Quest_Plot:
		TempFolderPath = FQuestObjectivesEditor::PlotQuestName;
		break;
	case EQuestFolderType::Quest_Achievement:
		TempFolderPath = FQuestObjectivesEditor::AchievementQuestName;
		break;
	case EQuestFolderType::Quest_Level:
		TempFolderPath = FQuestObjectivesEditor::LevelQuestName;
		break;
	default:
		break;
	}
	return TempFolderPath;
}

void SQuestListViewWidget::EnterToPageThree()
{
	//保存上个章节的名称
	//LastPageChoiseQuestGroup = CurChoiseListViewItemData->EditorAsset;

	////获取上个Graph的所有Node中的QuestGroup
	//UEdGraph_QuestObjectivesProp* Graph = QuestScrollWidget->GetQuestObjectivesEditor()->GetQuestObjectivesGraph();

	//TArray<USingleQuest*> SingleQuestArray;
	//if (Graph)
	//{
	//	for (int i = 0; i < Graph->Nodes.Num(); i++)
	//	{
	//		if (UMONode_Quest* Node_Quest = Cast<UMONode_Quest>(Graph->Nodes[i]))
	//		{
	//			if (Node_Quest->SingleQuest)
	//			{
	//				SingleQuestArray.Add(Node_Quest->SingleQuest);
	//			}
	//		}
	//	}
	//}

	//EmptyDataList();

	//CurrentPage = 3;
	//QuestScrollWidget->RefreshButtonVisibility();

	//RefreshPaletteItems();

	////刷新所有的SingleQuest列表
	//for (int i = 0; i < SingleQuestArray.Num(); i++)
	//{
	//	USingleQuest* SingleQuest = SingleQuestArray[i];

	//	TSharedPtr<FListViewItemData> TempListViewItemData = MakeShareable(new FListViewItemData);
	//	if (SingleQuest->Name == "")
	//	{
	//		TempListViewItemData->ItemName = SingleQuest->GetName();
	//	}
	//	else
	//	{
	//		TempListViewItemData->ItemName = SingleQuest->Name;
	//	}
	//	TempListViewItemData->QuestCategory = EQuestCategory::SingleQuest;
	//	TempListViewItemData->QuestType = CurChooseQuestType;
	//	TempListViewItemData->EditorAsset = SingleQuest;
	//	DataList.Add(TempListViewItemData);
	//	SetItemList(DataList);
	//}

	////删除Graph
	//if (QuestScrollWidget && QuestScrollWidget->GetQuestObjectivesEditor())
	//{
	//	QuestScrollWidget->GetQuestObjectivesEditor()->RemoveGraphEditor();
	//}

	////从左侧选择栏中选择上个页面选中的Quest
	//for (int i = 0; i < DataList.Num(); i++)
	//{
	//	TSharedPtr<FListViewItemData> ItemData = DataList[i];
	//	if (ItemData->EditorAsset == LastPageChoiseSingleQuest)
	//	{
	//		OnClick_Item(ItemData);
	//	}
	//}


}

void SQuestListViewWidget::InitQuestListView(const TSharedPtr<class SQuestScrollWidget>& ScrollWidget)
{
	QuestScrollWidget = ScrollWidget;
	EnterToPageOne();
}

void SQuestListViewWidget::SetCurrentPage(int Page)
{
	CurrentPage = Page;

	QuestScrollWidget->RefreshButtonVisibility();
}

void SQuestListViewWidget::ShowChoiseChapterGraph(TSharedPtr<FListViewItemData> ChoiseItemData)
{
	//在右侧细节列表中显示章节的Asset的所有属性
	TArray<UObject*> TempObjects;
	TempObjects.Add(ChoiseItemData->EditorAsset.Get());
	QuestScrollWidget->GetQuestObjectivesEditor()->PropertyEditorSetObjects(TempObjects);

	//对于章节的处理
	if (ChoiseItemData->QuestCategory == EQuestCategory::Chapter || ChoiseItemData->QuestCategory == EQuestCategory::SingleQuest)
	{
		//然后在图表中重新生成该chapter保存的所有节点连接关系
		USingleQuest* SingleQuest = Cast<USingleQuest>(ChoiseItemData->EditorAsset);
		UGroupQuestTemplate* GroupQuestAsset = Cast<UGroupQuestTemplate>(ChoiseItemData->EditorAsset);
		if (SingleQuest || GroupQuestAsset)
		{
			if (TSharedPtr<class FQuestObjectivesEditor> QuestObjectivesEditor = QuestScrollWidget->GetQuestObjectivesEditor())
			{
				QuestObjectivesEditor->SetCurrentEditorDataAsset(ChoiseItemData->EditorAsset.Get());

				QuestObjectivesEditor->InitQuestObjectivesProp();
			}
			//if (const UEdGraph_QuestObjectivesProp* QuestObjectivesGraph = QuestScrollWidget->GetQuestObjectivesEditor()->GetQuestObjectivesGraph())
			//{
			//	//删除所有节点
			//	for (UEdGraphNode* Node : QuestObjectivesGraph->Nodes)
			//	{
			//		QuestObjectivesGraph->RemoveNode(Node);
			//	}
			//	QuestObjectivesGraph->ChapterObject = GroupQuestAsset;
			//	if (GroupQuestAsset->NodeGraph)
			//	{
			//		QuestObjectivesGraph->ReGenerateAllNodes(GroupQuestAsset->NodeGraph);
			//	}
			//}
		}
	}

}

void SQuestListViewWidget::ClearData()
{
	DataList.Empty();
}

void SQuestListViewWidget::OnNewQuestClicked()
{
	if (CurrentPage == 2)
	{
		FString NewGroupQuestName = "NewChapter";

		//创建Asset
		FString CreateAssetFullPath;
		for (int i = 0; i < 100; i++)
		{
			FString CreateAssetPath = FQuestObjectivesEditor::QuestAssetPath / GetPathNameFromCurChooseQuestType();
			CreateAssetFullPath = CreateAssetPath / NewGroupQuestName + FString::FromInt(i);
			UObject* TempObject = Cast<UObject>(StaticLoadObject(UObject::StaticClass(), NULL, *CreateAssetFullPath));

			if (TempObject == nullptr)
			{
				NewGroupQuestName += FString::FromInt(i);
				break;
			}
		}

		UPackage* Package = CreatePackage(*(CreateAssetFullPath));
		UGroupQuestTemplate* GroupQuestAsset = NewObject<UGroupQuestTemplate>(Package, UGroupQuestTemplate::StaticClass(), FName(NewGroupQuestName), EObjectFlags::RF_Public | RF_Standalone);
		FAssetRegistryModule::AssetCreated(GroupQuestAsset);
		//这里看上去是命名，其实是让文件自动迁出
		UEditorUtilityLibrary::RenameAsset(GroupQuestAsset, GroupQuestAsset->GetName());

		//UPackage::SavePackage(Package, NULL, RF_Standalone, *CreateAssetFullPath, GError, nullptr, true, true, SAVE_NoError);

		//新建章节
		TSharedPtr<FListViewItemData> TempListViewItemData = MakeShareable(new FListViewItemData);
		TempListViewItemData->ItemName = NewGroupQuestName;
		TempListViewItemData->QuestCategory = EQuestCategory::Chapter;
		TempListViewItemData->QuestType = CurChooseQuestType;
		TempListViewItemData->EditorAsset = GroupQuestAsset;
		DataList.Add(TempListViewItemData);
		SetItemList(DataList);
	}

	if (CurrentPage == 3)
	{
		FString Path = FAssetData(LastPageChoiseQuestGroup).PackageName.ToString();
		FString NewGroupQuestName = LastPageChoiseQuestGroup->GetName() + "_NewQuest";

		//创建Asset
		FString CreateAssetFullPath;
		for (int i = 0; i < 100; i++)
		{
			CreateAssetFullPath = Path /  NewGroupQuestName + FString::FromInt(i);
			UObject* TempObject = Cast<UObject>(StaticLoadObject(UObject::StaticClass(), NULL, *CreateAssetFullPath));

			if (TempObject == nullptr)
			{
				NewGroupQuestName += FString::FromInt(i);
				break;
			}
		}
		UPackage* Package = CreatePackage(*(CreateAssetFullPath));
		USingleQuest* SingleQuest = NewObject<USingleQuest>(Package, USingleQuest::StaticClass(), FName(NewGroupQuestName), EObjectFlags::RF_Public | RF_Standalone);
		FAssetRegistryModule::AssetCreated(SingleQuest);
		//这里看上去是命名，其实是让文件自动迁出
		UEditorUtilityLibrary::RenameAsset(SingleQuest, SingleQuest->GetName());

		//新建任务
		TSharedPtr<FListViewItemData> TempListViewItemData = MakeShareable(new FListViewItemData);
		TempListViewItemData->ItemName = NewGroupQuestName;
		TempListViewItemData->QuestCategory = EQuestCategory::SingleQuest;
		TempListViewItemData->QuestType = CurChooseQuestType;
		TempListViewItemData->EditorAsset = SingleQuest;
		DataList.Add(TempListViewItemData);
		SetItemList(DataList);
	}
}

void SQuestListViewWidget::EmptyDataList()
{
	ListViewItemAndTextBlockMap.Empty();
	DataList.Empty();

	ListView->RequestListRefresh();
}

//删除
void SQuestListViewWidget::OnDeleteQuestClicked()
{
	if (CurDeleteItem)
	{
		TArray<UObject*> AssetsToDelete;
		if (CurDeleteItem->EditorAsset.Get())
		{
			if (CurChoiseListViewItemData == CurDeleteItem)
			{
				if (QuestScrollWidget && QuestScrollWidget->GetQuestObjectivesEditor())
				{
					QuestScrollWidget->GetQuestObjectivesEditor()->RemoveGraphEditor();
				}
			}
			
			bIsDeleteAsset = false;

			QuestScrollWidget->GetQuestObjectivesEditor()->SetCurrentEditorDataAsset(nullptr);

			AssetsToDelete.Add(CurDeleteItem->EditorAsset.Get());
			//ObjectTools::DeleteSingleObject(CurDeleteItem->ChapterAsset, true);

			bool bHaveDelete =false;
			//如果是GroupQuest，要把整个目录删除
			if (UGroupQuestTemplate* GroupQuestTemplate = Cast<UGroupQuestTemplate>(CurDeleteItem->EditorAsset))
			{
				TArray<FString> PathsToDelete;
				FString Path = FAssetData(GroupQuestTemplate).PackageName.ToString();
				PathsToDelete.Add(Path);
				//先将目录中的所有文件全部删除
				TArray<UObject*> SingleQuestObjects = QuestScrollWidget->GetQuestObjectivesEditor()->GetAllObjectFromPathAndObjectClass(Path, USingleQuest::StaticClass());
				ObjectTools::ForceDeleteObjects(SingleQuestObjects, false);

				//再将QuestGroup删除
				ObjectTools::ForceDeleteObjects(AssetsToDelete, false);

				bHaveDelete=true;
				//然后再删除目录
				ContentBrowserUtils::DeleteFolders(PathsToDelete);
			}
			if (!bHaveDelete)
			{
				ObjectTools::ForceDeleteObjects(AssetsToDelete, false);
			}
		}

		TArray<TSharedPtr<FListViewItemData>> TempDataList = DataList;
		TempDataList.Remove(CurDeleteItem);
		SetItemList(TempDataList);
	}


}
