#include "QuestAction.h"

#include "QuestTemplate.h"
#include "SClassViewer.h"
#include "FileAsset/QuestImporter.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "LuaSerialization/LuaValue.h"
#include "LuaSerialization/Serialization/LuaSerializer.h"


FBPVariableDescription* FQuestActionHelper::FindBPVariableByName(UBlueprint* Blueprint, const FName& InVarName)
{
	return Blueprint->NewVariables.FindByPredicate([&InVarName](const FBPVariableDescription& Desc)
				{
					return Desc.VarName == InVarName;
				});
}

void FQuestActionHelper::InitializeAllQuestActionClasses(TMap<FString, UClass*>& OutClassList, const TArray<FSystemActionDefine>& ActionDefines)
{
	for (const FSystemActionDefine& ActionDefine : ActionDefines)
	{
		CreateQuestActionClass(OutClassList, ActionDefine);
	}
	SClassViewer::RequestPopulateClassHierarchy();
}

void FQuestActionHelper::CreateQuestActionClass(TMap<FString, UClass*>& OutClassList, const FSystemActionDefine& ActionDefine)
{
	UPackage* TransientPackage = GetTransientPackage();
	FName BPClassName = FName(FString::Format(TEXT("QuestSystemActionClass_{0}"), {ActionDefine.ActionName}));
	UBlueprint* NewBlueprint = FKismetEditorUtilities::CreateBlueprint(
		UQuestSystemActionBase::StaticClass(), 
		TransientPackage, 
		BPClassName,
		EBlueprintType::BPTYPE_Normal,
		UBlueprint::StaticClass(), 
		UBlueprintGeneratedClass::StaticClass()
	);
	if (!ActionDefine.Description.IsEmpty())
	{
		NewBlueprint->BlueprintDisplayName = ActionDefine.Description;
		NewBlueprint->BlueprintDescription = ActionDefine.Description;
	}
	else
	{
		NewBlueprint->BlueprintDisplayName = ActionDefine.ActionName;
		NewBlueprint->BlueprintDescription = ActionDefine.ActionName;
	}
	UQuestSystemActionBase* CDO = Cast<UQuestSystemActionBase>(NewBlueprint->GeneratedClass->GetDefaultObject());
	CDO->ActionTypeName = ActionDefine.ActionName;
	OutClassList.Add(ActionDefine.ActionName, NewBlueprint->GeneratedClass);

	if (ActionDefine.QuestAddGet)
	{
		FSystemActionArg SystemActionArg;
		SystemActionArg.Name = TEXT("QuestAddGetInstanceID");
		SystemActionArg.Type = TEXT("Str()");
		SystemActionArg.Desc = TEXT("执行者InstanceID");
		SystemActionArg.VerboseDesc = TEXT("设置该接口的执行人InstanceID，不填表示玩家执行。注意：此设置不支持self为玩家的配置方式");
		AddProperty(NewBlueprint, SystemActionArg);
	}

	for (const FSystemActionArg& SystemActionArg : ActionDefine.ActionArgs)
	{
		AddProperty(NewBlueprint, SystemActionArg);
	}

	FCompilerResultsLog CompileLog;
	FKismetEditorUtilities::CompileBlueprint(
		NewBlueprint,
		EBlueprintCompileOptions::SkipGarbageCollection,
		&CompileLog
	);
}

void FQuestActionHelper::GetPinCategoryAndSubCategory(const FString& ArgType, FName& OutPinCategory, FName& OutSubCategory, EPinContainerType& OutContainerType, FEdGraphTerminalType& TerminalType)
{
	if (ArgType.StartsWith("Float"))
	{
		OutPinCategory = UEdGraphSchema_K2::PC_Real;
		OutSubCategory = UEdGraphSchema_K2::PC_Float;
	}
	else if (ArgType.StartsWith("Int"))
	{
		OutPinCategory = UEdGraphSchema_K2::PC_Int;
		OutSubCategory = NAME_None;
	}
	else if (ArgType.StartsWith("Bool"))
	{
		OutPinCategory = UEdGraphSchema_K2::PC_Boolean;
		OutSubCategory = NAME_None;
	}
	else if (ArgType.StartsWith("Str") || ArgType.StartsWith("Enum"))
	{
		OutPinCategory = UEdGraphSchema_K2::PC_String;
		OutSubCategory = NAME_None;
	}
	else if (ArgType.StartsWith("LuaList"))
	{
		OutContainerType = EPinContainerType::Array;
		FString ListPrefix = "LuaList";
		int32 StartCount = ListPrefix.Len();
		FString SubArgType = ArgType.Mid(StartCount + 1, ArgType.Len() - StartCount - 2);
		GetPinCategoryAndSubCategory(SubArgType, OutPinCategory, OutSubCategory, OutContainerType, TerminalType);
	}
	else if (ArgType.StartsWith("LuaDict"))
	{
		OutContainerType = EPinContainerType::Map;
		FString ListPrefix = "LuaDict";
		int32 StartCount = ListPrefix.Len();
		FString SubArgType = ArgType.Mid(StartCount + 1, ArgType.Len() - StartCount - 2);
		FString KeyArgType, ValueArgType;
		SubArgType.Split(TEXT(","), &KeyArgType, &ValueArgType);
		ValueArgType.TrimStartInline();
		GetPinCategoryAndSubCategory(KeyArgType, OutPinCategory, OutSubCategory, OutContainerType, TerminalType);
		GetPinCategoryAndSubCategory(ValueArgType, TerminalType.TerminalCategory, TerminalType.TerminalSubCategory, OutContainerType, TerminalType);
	}
}

void FQuestActionHelper::AddProperty(UBlueprint* Blueprint, const FSystemActionArg& SystemActionArg)
{
	FEdGraphPinType PinType;
	FString ArgType = SystemActionArg.Type;
	GetPinCategoryAndSubCategory(ArgType, PinType.PinCategory, PinType.PinSubCategory, PinType.ContainerType, PinType.PinValueType);
	FName VarName = FName(SystemActionArg.Name);
	FString VarDisplayName = SystemActionArg.Desc;
	FString ToolTips = SystemActionArg.VerboseDesc;
	FBlueprintEditorUtils::AddMemberVariable(
		Blueprint, 
		VarName, 
		PinType,
		SystemActionArg.Default
	);
	
	FBPVariableDescription* VariableDesc = FindBPVariableByName(Blueprint, VarName);
	FText Category = FText::FromString(TEXT("参数设置"));
	if (VariableDesc)
	{
		VariableDesc->SetMetaData(TEXT("Category"), Category.ToString());
		VariableDesc->Category = Category;
		VariableDesc->SetMetaData(TEXT("DisplayName"), VarDisplayName);
		VariableDesc->SetMetaData(TEXT("tooltip"), ToolTips);
	}
}

FString FQuestActionHelper::ExportPropertyToParam(FProperty* Property, const void* Address)
{
	FString Value = "";
	if (FMapProperty* MapProp = CastField<FMapProperty>(Property))
	{
		FScriptMapHelper MapHelper(MapProp, Address);
		if (MapHelper.Num() == 0)
		{
			return Value;
		}
		FProperty* KeyType = MapHelper.GetKeyProperty();
		FProperty* ValueType = MapHelper.GetValueProperty();
		TArray<FString> MapArgs;
		for (int32 i = 0; i < MapHelper.GetMaxIndex(); ++i)
		{
			if (!MapHelper.IsValidIndex(i))
			{
				continue;
			}
			void* KeyPtr = MapHelper.GetKeyPtr(i);
			void* ValuePtr = MapHelper.GetValuePtr(i);
			FString KeyStr;
			KeyType->ExportTextItem_Direct(KeyStr, KeyPtr, nullptr, nullptr, PPF_None);
			FString ValueStr = ExportPropertyToParam(ValueType, ValuePtr);
			if (KeyStr.IsEmpty() || ValueStr.IsEmpty())
			{
				continue;
			}
			if (KeyType->IsA<FStrProperty>())
			{
				KeyStr = FString::Printf(TEXT("'%s'"), *KeyStr);
			}
			if (ValueType->IsA<FStrProperty>())
			{
				ValueStr = FString::Printf(TEXT("'%s'"), *ValueStr);
			}
			MapArgs.Add(FString::Printf(TEXT("%s=%s"), *KeyStr, *ValueStr));
		}
		if (MapArgs.IsEmpty())
		{
			return Value;
		}
		FString MapArgsStr = FString::Join(MapArgs, TEXT(","));
		Value = FString::Printf(TEXT("{%s}"), *MapArgsStr);
	}
	else if (FArrayProperty* ArrayProp = CastField<FArrayProperty>(Property))
	{
		FScriptArrayHelper ArrayHelper(ArrayProp, Address);
		FProperty* ElementType = ArrayProp->Inner;
		TArray<FString> ArrayArgs;
		for (int32 i = 0; i < ArrayHelper.Num(); ++i)
		{
			void* ElementPtr = ArrayHelper.GetRawPtr(i);
			FString ValueStr = ExportPropertyToParam(ElementType, ElementPtr);
			if (ValueStr.IsEmpty())
			{
				continue;
			}
			if (ElementType->IsA<FStrProperty>())
			{
				ArrayArgs.Add(FString::Printf(TEXT("'%s'"), *ValueStr));
			}
			else
			{
				ArrayArgs.Add(ValueStr);
			}
		}
		if (ArrayArgs.IsEmpty())
		{
			return Value;
		}
		const FString ArrayArgsStr = FString::Join(ArrayArgs, TEXT(","));
		Value = FString::Printf(TEXT("{%s}"), *ArrayArgsStr);
	}
	else
	{
		Property->ExportTextItem_Direct(Value, Address, nullptr, nullptr, PPF_None);
	}
	return Value;
}

FString FQuestActionHelper::GetSystemActionsParams(TArray<class UQuestSystemActionBase*> SystemActions)
{
	TArray<FString> Args;
	for (UQuestSystemActionBase* SystemAction : SystemActions)
	{
		if (!SystemAction)
		{
			continue;
		}
		Args.Add(GetSystemActionParams(SystemAction));
	}
	return FString::Join(Args, TEXT(";"));
}

FString FQuestActionHelper::GetSystemActionParams(UQuestSystemActionBase* SystemAction)
{
	TArray<FString> Args;
	const UClass* ObjectClass = SystemAction->GetClass();
	FString QuestAddGetInstanceID;
	for (TFieldIterator<FProperty> PropIt(ObjectClass); PropIt; ++PropIt)
	{
		void* CurAddress = (*PropIt)->ContainerPtrToValuePtr<void>(SystemAction);
		FString FieldName = (*PropIt)->GetName();
		if (FieldName == "ActionTypeName")
		{
			continue;
		}
		FString Value = ExportPropertyToParam(*PropIt, CurAddress);
		if (Value.IsEmpty())
		{
			continue;
		}
		if (FieldName == "QuestAddGetInstanceID")
		{
			QuestAddGetInstanceID = Value;
			continue;
		}
		if ((*PropIt)->IsA<FStrProperty>())
		{
			Args.Add(FString::Printf(TEXT("%s='%s'"), *FieldName, *Value));
		}
		else
		{
			Args.Add(FString::Printf(TEXT("%s=%s"), *FieldName, *Value));
		}
	}
	const FString Params = FString::Join(Args, TEXT(","));
	FString GetInstanceStr = "";
	if (!QuestAddGetInstanceID.IsEmpty())
	{
		GetInstanceStr = FString::Printf(TEXT("Get(%s)."), *QuestAddGetInstanceID);
	}
	return FString::Printf(TEXT("%s%s(%s)"), *GetInstanceStr, *SystemAction->ActionTypeName, *Params);
}

bool FQuestActionHelper::IsLuaArray(const TSharedPtr<FLuaTable>& InLuaTable)
{
	if (InLuaTable->Values.IsEmpty())
	{
		return false;
	}
	int32 Index = 1;
	for (auto Kv : InLuaTable->Values)
	{
		if (Kv.Key != FString::FromInt(Index))
		{
			return false;
		}
		++Index;
	}
	return true;
}

void FQuestActionHelper::RemoveFuncParamInfos(const TSharedPtr<FLuaTable>& InLuaTable)
{
	for (auto Kv : InLuaTable->Values)
	{
		for (auto ParamTuple : Kv.Value->AsTable()->Values)
		{
			ParamTuple.Value->AsTable()->RemoveField(TEXT("FuncParamInfos"));
		}
	}
}

void FQuestActionHelper::TransArrayToIntTable(const TSharedPtr<FLuaTable>& InLuaTable)
{
	TArray<FString> Keys;
	InLuaTable->Values.GetKeys(Keys);
	for (const FString& Key : Keys)
	{
		const TSharedPtr<FLuaValue> Value = InLuaTable->Values[Key];
		TSharedPtr<FLuaTable>* SubLuaTable;
		if (Value->TryGetTable(SubLuaTable))
		{
			TransArrayToIntTable(*SubLuaTable);
			if (IsLuaArray(*SubLuaTable))
			{
				InLuaTable->SetField(Key, MakeShared<FLuaValueIntTable>(*SubLuaTable));
			}
		}
	}
}

void FQuestActionHelper::ParseSystemActions(const TArray<TPair<FString, TSharedPtr<FLuaValueIntTable>>>& SystemActionLuaTables)
{
	if (SystemActionLuaTables.IsEmpty())
	{
		return;
	}
	FString WorkDir = FPaths::Combine(FPaths::ProjectDir(), TEXT("../Tools/ExcelToLuaTool/EditoParserTool/distnew/EditoParserTool"));
	FString Process = FPaths::Combine(WorkDir, TEXT("EditoParserTool.exe"));
	if (!FPaths::FileExists(Process))
	{
		UE_LOG(LogTemp, Warning, TEXT("EditoParserTool not exists"));
		const FText Message = FText::FromString(TEXT("本地解析system action工具不存在，请确保/Tools/ExcelToLuaTool/EditoParserTool/distnew/EditoParserTool/EditoParserTool.exe存在后重新保存"));
		FMessageDialog::Open(EAppMsgType::Ok, Message);
		return;
	}
	TArray<FString> Args;
	for (const TPair<FString, TSharedPtr<FLuaValueIntTable>>& ParseTuple : SystemActionLuaTables)
	{
		Args.Add(FString::Printf(TEXT("\"%s\""), *ParseTuple.Key));
	}
	const FString Command = FString::Join(Args, TEXT(" "));
	int32 ResultCode;
	FString Result, ResultErr;
	if (!FPlatformProcess::ExecProcess(*Process, *Command, &ResultCode, &Result, &ResultErr, *WorkDir))
	{
		UE_LOG(LogTemp, Warning, TEXT("解析system action时返回错误信息: %s"), *ResultErr);
		const FText Message = FText::Format(FText::FromString(TEXT("解析system action时返回错误信息: {0}")), {FText::FromString(ResultErr)});
		FMessageDialog::Open(EAppMsgType::Ok, Message);
		return;
	}
	FString LuaPath = FPaths::Combine(WorkDir, TEXT("parser_result.lua"));
	TSharedPtr<FLuaTable> ParseResultTable = FQuestLuaImporter::ConvertLuaFileToLuaTable(LuaPath);
	if (!ParseResultTable.IsValid())
	{
		FString Message = TEXT("解析system action失败,检查本地parser_result.lua文件是否存在");
		UE_LOG(LogTemp, Warning, TEXT("%s"), *Message)
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Message));
		return;
	}
	bool bHasFailedResult = false;
	for (auto Kv : ParseResultTable->Values)
	{
		int32 Index = FCString::Atoi(*Kv.Key) - 1;
		if (Index >= SystemActionLuaTables.Num() || Index < 0)
		{
			bHasFailedResult = true;
			UE_LOG(LogTemp, Error, TEXT("解析system action失败!!"));
			continue;
		}
		if (TSharedPtr<FLuaTable> LT = Kv.Value->AsTable())
		{
			FString ErrorMsg;
			if (LT->TryGetStringField(TEXT("error_msg"), ErrorMsg))
			{
				if (!ErrorMsg.IsEmpty())
				{
					UE_LOG(LogTemp, Error, TEXT("解析system action失败!!错误信息: %s"), *ErrorMsg);
					bHasFailedResult = true;
				}
			}
			if (TSharedPtr<FLuaTable> RetData = LT->GetTableField(TEXT("ret_data")))
			{
				RemoveFuncParamInfos(RetData);
				TransArrayToIntTable(RetData);
				SystemActionLuaTables[Index].Value->SetValueTable(RetData);
			}
		}
	}
	if (bHasFailedResult)
	{
		const FText Message = FText::FromString(TEXT("解析system action时有报错，请检查日志"));
		FMessageDialog::Open(EAppMsgType::Ok, Message);
	}
}
