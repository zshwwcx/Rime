#pragma once
#include "LuaSerialization/LuaTable.h"

#include "QuestAction.generated.h"

class FQuestActionClassParam
{
	TMap<FString, FString> Params;
};

USTRUCT(Blueprintable)
struct FSystemActionArg
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	FString Name;
	UPROPERTY()
	FString Type;
	UPROPERTY()
	FString Desc;
	UPROPERTY()
	FString VerboseDesc;
	UPROPERTY()
	FString Tips;
	UPROPERTY()
	FString Default;
};

USTRUCT(Blueprintable)
struct FSystemActionDefine
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	FString ActionName;
	UPROPERTY()
	FString Description;
	UPROPERTY()
	FString DesignScope;
	UPROPERTY()
	TArray<FSystemActionArg> ActionArgs;
	UPROPERTY()
	bool QuestAddGet=false;
};

class FQuestActionHelper
{
public:
	static FBPVariableDescription* FindBPVariableByName(UBlueprint* Blueprint, const FName& InVarName);
	static void InitializeAllQuestActionClasses(TMap<FString, UClass*>& OutClassList, const TArray<FSystemActionDefine>& ActionDefines);
	static void CreateQuestActionClass(TMap<FString, UClass*>& OutClassList, const FSystemActionDefine& ActionDefine);
	static void GetPinCategoryAndSubCategory(const FString& ArgType, FName& OutPinCategory, FName& OutSubCategory, EPinContainerType& OutContainerType, FEdGraphTerminalType& TerminalType);
	static void AddProperty(UBlueprint* Blueprint, const FSystemActionArg& SystemActionArg);
	static FString ExportPropertyToParam(FProperty* Property, const void* Address);
	static FString GetSystemActionsParams(TArray<class UQuestSystemActionBase*> SystemActions);
	static FString GetSystemActionParams(class UQuestSystemActionBase* SystemAction);
	static bool IsLuaArray(const TSharedPtr<FLuaTable>& InLuaTable);
	static void RemoveFuncParamInfos(const TSharedPtr<FLuaTable>& InLuaTable);
	static void TransArrayToIntTable(const TSharedPtr<FLuaTable>& InLuaTable);
	static void ParseSystemActions(const TArray<TPair<FString, TSharedPtr<FLuaValueIntTable>>>& SystemActionLuaTables);
};