// Fill out your copyright notice in the Description page of Project Settings.


#include "UserSingleQuest.h"
#include "UserQuestActionNode.h"
#include "UserGroupQuest.h"
#include "QuestTemplate.h"
//#include "Manager/QuestManager.h"

//void UUserSingleQuest::InitQuest(UQuest* QuestTemp, UUserQuest* Parent, UQuestManager* missionMgr)
//{
//	Super::InitQuest(QuestTemp,Parent, missionMgr);
//
//	USingleQuest* SingleQuest = Cast<USingleQuest>(QuestTemplate);
//	if (SingleQuest != nullptr)
//	{
//		int Num = SingleQuest->QuestActionNodeArray.Num();
//		for (int i = 0; i < Num; i++)
//		{
//			UQuestActionNode* QuestActionNode = SingleQuest->QuestActionNodeArray[i];
//			if (QuestActionNode != nullptr)
//			{
//				UUserQuestActionNode* UserQuestActionNode = NewObject<UUserQuestActionNode>(this);
//				if (UserQuestActionNode == nullptr)
//				{
//					continue;
//				}
//
//				UserQuestActionNode->InitQuest(SingleQuest->QuestActionNodeArray[i],this, missionMgr);
//				UserQuestActionNodeArray.Add(UserQuestActionNode);
//			}
//		}
//	}
//}
//
//void UUserSingleQuest::DestroyAll()
//{
//	Super::DestroyAll();
//	UserQuestActionNodeArray.Empty();
//}
//
//const FName UUserSingleQuest::GetSingleQuestId()
//{
//	USingleQuest* SingleQuest=GetSingleQuestTemplate();
//
//	if (SingleQuest)
//	{
//		return SingleQuest->Id;
//	}
//
//	return NAME_None;
//}
//
//USingleQuest* UUserSingleQuest::GetSingleQuestTemplate()
//{
//	return Cast<USingleQuest>(QuestTemplate);
//}
//
//UUserQuestActionNode* UUserSingleQuest::GetCurUserQuestActionNode(const FName& ActionNodeId)
//{
//	int Num = UserQuestActionNodeArray.Num();
//	if (Num > 0)
//	{
//		for (int i = 0; i < Num; i++)
//		{
//			if (UserQuestActionNodeArray[i]->GetActionNodeId() == ActionNodeId)
//			{
//				return UserQuestActionNodeArray[i];
//			}
//
//		}
//	}
//	return nullptr;
//}
//
//bool UUserSingleQuest::CheckAcceptCondition()
//{
//	bool ret = UUserQuest::CheckAcceptCondition();
//
//	//检查行动节点的条件是否满足
//	if (ret)
//	{
//		int Num = UserQuestActionNodeArray.Num();
//		if (Num > 0)
//		{
//			for (int i = 0; i < Num; i++)
//			{
//				//行为节点是否完成
//				if (!UserQuestActionNodeArray[i]->CheckAcceptCondition())
//				{
//					ret = false;
//					return ret;
//				}
//			}
//		}
//	}
//
//	return ret;
//}
//
////检查完成接受条件，并更新任务状态
//bool UUserSingleQuest::CheckCompleteCondition()
//{
//	bool ret = UUserQuest::CheckCompleteCondition();
//
//	//检查行动节点的条件是否满足
//	if (ret)
//	{
//		int Num = UserQuestActionNodeArray.Num();
//		if (Num > 0)
//		{
//			for (int i = 0; i < Num; i++)
//			{
//				//行为节点是否完成
//				if (!UserQuestActionNodeArray[i]->CheckCompleteCondition())
//				{
//					ret = false;
//					return ret;
//				}
//			}
//		}
//	}
//
//	return ret;
//}
//
//void UUserSingleQuest::StartAcceptedQuest()
//{
//	UUserQuest::StartAcceptedQuest();
//	//按顺序开始行动节点执行
//
//	int Num = UserQuestActionNodeArray.Num();
//	if (Num > 0)
//	{
//		CurRunningIndex = 0;
//		CurRunningActionNode = UserQuestActionNodeArray[CurRunningIndex];
//	}
//
//	if (CurRunningActionNode)
//	{
//		CurRunningActionNode->AcceptQuest();
//	}
//}
//
//void UUserSingleQuest::UpdateRunningActionNode()
//{
//	//if (CurRunningActionNode != nullptr)
//	//{
//	//	if (CurRunningActionNode->GetQuestStatus() >= EQuestStatus::EMS_Complete)
//	//	{
//	//		int Num = UserQuestActionNodeArray.Num();
//	//		for (int i = 0; i < Num; i++)
//	//		{
//	//			//行为节点是否完成
//	//			if (UserQuestActionNodeArray[i]->GetQuestId() == CurRunningActionNode->GetPostQuestId())
//	//			{
//	//				CurRunningActionNode = UserQuestActionNodeArray[i];
//	//				break;
//	//			}
//	//		}
//
//	//
//	//	}
//	//}
//}
//
//
//void UUserSingleQuest::UpdateQuestStatus()
//{
//	EQuestStatus OldQuestStatus = QuestStatus;
//	if (QuestStatus < EQuestStatus::EMS_Accepted)
//	{
//		//任务尚未接受
//		if (CheckAcceptCondition())
//		{
//			QuestStatus = EQuestStatus::EMS_Accepted;
//		}
//	}
//	else if(QuestStatus < EQuestStatus::EMS_Complete)
//	{
//		UpdateRunningActionNode();
//		//任务尚未完成
//		if(CheckCompleteCondition())
//		{
//			QuestStatus = EQuestStatus::EMS_Complete;
//		}
//	}
//
//	//奖励领取状态 ，在基本类中设置
//
//	//更新当前任务列表
//	if (QuestManager)// && OldQuestStatus != QuestStatus)
//	{
//		QuestManager->UpdateCurQuests(this);
//	}
//}
//
//
////bool UUserSingleQuest::IsQuestComplete()
////{
////	return false;
////}
