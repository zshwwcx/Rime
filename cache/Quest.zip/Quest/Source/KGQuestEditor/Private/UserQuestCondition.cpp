// Fill out your copyright notice in the Description page of Project Settings.


#include "UserQuestCondition.h"
#include "UserQuest.h"
//#include "Core/Event/MessageSystem.h"
//#include "Manager/BaseManager.h"

//void UUserQuestCondition::Init(UQuestCondition* QuestConditionTemp, UUserQuest* TempParentQuest)
//{
//	QuestConditionTemplate = QuestConditionTemp;
//	ParentQuest = TempParentQuest;
//
//}
//
//void UUserQuestCondition::StartMsgRegister()
//{
//	OnMsgRegister();//消息监听
//}
//
//void UUserQuestCondition::EndMsgRegister()
//{
//	//因为事件监听会把所有对应消息类型的监听都去掉， 暂时关闭反注册，后面需要解决此问题
//	//OnMsgUnregister(); //去掉消息监听
//}
//
//void UUserQuestCondition::UpdateQuestStatus()
//{
//	if (IsMeetCondition())
//	{
//		if (ParentQuest)
//		{
//			ParentQuest->UpdateQuestStatus();
//		}
//
//		EndMsgRegister();
//
//	}
//}
//
//
//UMessageSystem* UUserQuestCondition::GetMessageSystem()
//{
//	UMessageSystem* MsgSys = UBaseManager::Get<UMessageSystem>(GetWorld());
//	return MsgSys;
//}
//
//UWorld* UUserQuestCondition::GetWorld() const
//{
//	UWorld* World = NULL;
//	if (ParentQuest)
//	{
//		World = ParentQuest->GetWorld();
//	}
//	return World;
//}

