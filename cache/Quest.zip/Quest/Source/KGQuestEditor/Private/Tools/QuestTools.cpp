#include "FQuestObjectivesEditor.h"
#include "KGQuestEditorSubSystem.h"
#include "3C/Animation/AnimAssetDefine.h"
#include "EDGraph/Nodes/EDGraphNode_Base.h"


namespace
{
	struct FSimpleActionRemapping
	{
		FString FuncName;
		TMap<FString, FString> ParamsMap;

		FSimpleActionRemapping(FString InFuncName, const TMap<FString, FString>& InParamsMap)
		{
			FuncName = InFuncName;
			ParamsMap = InParamsMap;
		}
	};

	TMap<int32, FSimpleActionRemapping> SpecialActionReplaceMap = {
		{123, FSimpleActionRemapping("SendTaskItem", {{"IsShowTips", "IsShowTips"},})},
		};

	TMap<int32, FSimpleActionRemapping> SimpleActionReplaceMap = {
		// 简单替换
		{149, FSimpleActionRemapping("CreateEntities", {{"InstanceID", "InstanceIDList"}})},
		{104, FSimpleActionRemapping("TeleportToPos", {{"LevelMapID", "LevelMapID"}, {"Position", "Pos"}, {"Rotation", "Yaw"}, })},
		{170, FSimpleActionRemapping("RunFlowChartAction", {{"FlowchartName", "FlowchartPath"}})},
		{102, FSimpleActionRemapping("PlaySingleBlackScreenSubtitles", {{"Desc", "Text"}, {"Duration", "Duration"}, {"CanSkip", "CanSkip"}, {"CanSkipTime", "CanSkipTime"}, {"BGType", "BGType"}})},
		{110, FSimpleActionRemapping("ShowMainStoryChapterUI", {{"ChapterId", "ChapterUIID"}})},
		{166, FSimpleActionRemapping("RemoveTaskItem", {{"Items", "ItemIDList"}})},
		{136, FSimpleActionRemapping("StartMoveCamera", {{"CameraInstanceID", "CameraInstanceID"}, {"BlendTime", "BlendTime"}})},
		{115, FSimpleActionRemapping("Play2DSound", {{"SoundPath", "AudioPath"}, })},
		{137, FSimpleActionRemapping("EndMoveCamera", {{"CameraInstanceID", "CameraInstanceID"}, {"BlendTime", "BlendTime"}})},
		{134, FSimpleActionRemapping("StartMorph", {{"MorphID", "MorphID"}})},
		{135, FSimpleActionRemapping("StopMorph", {})},
		{138, FSimpleActionRemapping("CameraLookAtPosition", {{"Position", "Pos"}, {"StartTime", "StartTime"}, {"Duration", "Duration"}, {"IsCanBreak", "IsCanBreak"}, {"BeFullRecover", "BeFullRecover"}})},
		{143, FSimpleActionRemapping("SpiritualVisionSwitch", {})},
		{175, FSimpleActionRemapping("StopAutoPath", {})},
		{142, FSimpleActionRemapping("SpiritualVisionSwitch", {})},
		{151, FSimpleActionRemapping("CreateEntityByClusters", {{"ClusterNames", "ClusterList"}})},
		{152, FSimpleActionRemapping("DestroyEntityByClusters", {{"ClusterNames", "ClusterList"}})},

		// 中等复杂替换
		{156, FSimpleActionRemapping("SetCamp", {{"Camp", "CampID"}})},
		{133, FSimpleActionRemapping("DelBuff", {{"BuffID", "BuffID"}, {"BuffNumber", "BuffLayer"}})},
		{129, FSimpleActionRemapping("GazeToCharacter", {{"TargetInstanceID", "TargetInstanceID"}, {"SocketName", "SocketName"}})},
		{122, FSimpleActionRemapping("SendSpaceMessage", {{"Message", "Message"}, {"Args", "Args"}})},
		{106, FSimpleActionRemapping("TeleportToTriggerLevelMap", {{"LevelMapID", "LevelMapID"}, {"TriggerID", "TriggerID"}, {"Rotation", "Direction"}})},
		{150, FSimpleActionRemapping("DestroyEntity", {})},
		{180, FSimpleActionRemapping("OpenLetter", {{"PaintingStratchID", "TableID"}})},

		// 复杂替换
		{105, FSimpleActionRemapping("TeleportMe", {{"Position", "Pos"}, {"Rotation", "Yaw"}})},
		{101, FSimpleActionRemapping("SetAnimation", {{"AnimationName", "FeatureName"}})},
		{107, FSimpleActionRemapping("TeleportToTrigger", {{"TriggerID", "TriggerID"}, {"Ratation", "Direction"}})},
		{154, FSimpleActionRemapping("RotateToEntity", {{"TargetInstanceID", "TargetInstanceID"}, {"RotateTime", "RotateTime"}, {"bShieldAnimation", "bShieldAnimation"}})},
		{132, FSimpleActionRemapping("AddSelfBuff", {{"BuffID", "BuffID"}, {"BuffNumber", "BuffLayer"}, {"BuffLevel", "BuffLevel"}, {"BuffTime", "Duration"}})},
		{118, FSimpleActionRemapping("StopAudioByCharacter", {})},
		{165, FSimpleActionRemapping("Say", {{"SetName", "ShowName"}, {"Type", "MsgType"}, {"Text", "Text"}, {"PlayTime", "Time"}, {"Sound", "Sound"}, {"SetTitle", "SetTile"}, {"IsShowTitle", "IsShowTitle"}})},
	};

	TSet<int32> HasGetFuncActionIDs = {156, 133, 129, 122, 150, 180, 105, 101, 107, 154, 132, 118, 165};

	TSet<int32> HasDelayFuncActionIDs = {104, 106, 105, 101, 107, 154, 132, 118, 165};

	TSet<int32> TransformEventSet = {};

	UQuestSystemActionBase* CreateDelayAction(UQuestActionBase* Action, UQuestObject* Ring)
	{
		if (Action == nullptr)
		{
			return nullptr;
		}
		// 单独处理旧action中的DelayTime参数到新action中的Delay函数的迁移
		if (!HasDelayFuncActionIDs.Contains(Action->Event))
		{
			return nullptr;
		}
		const TMap<FString, UClass*>& QuestActionClassList = UKGQuestEditorSubSystem::Get().GetSystemActionClassList();
		if (!QuestActionClassList.Contains("Delay"))
		{
			return nullptr;
		}
		UClass* SystemActionClass = QuestActionClassList["Delay"];
		FProperty* SrcProperty = Action->GetClass()->FindPropertyByName(FName("DelayTime"));
		if (SrcProperty == nullptr)
		{
			return nullptr;
		}
		FProperty* DestProperty = SystemActionClass->FindPropertyByName(FName("Second"));
		if (DestProperty == nullptr)
		{
			return nullptr;
		}
		void* SrcValuePtr = SrcProperty->ContainerPtrToValuePtr<void>(Action);
		if (SrcValuePtr == nullptr)
		{
			return nullptr;
		}
		const FDoubleProperty* DoubleProperty = CastField<FDoubleProperty>(SrcProperty);
		FFloatProperty* FloatProperty = CastField<FFloatProperty>(DestProperty);
		if (DoubleProperty == nullptr || FloatProperty == nullptr)
		{
			return nullptr;
		}
		double DelayTime = DoubleProperty->GetPropertyValue(SrcValuePtr);
		if (DelayTime == 0)
		{
			return nullptr;
		}
		UQuestSystemActionBase* SystemAction = NewObject<UQuestSystemActionBase>(Ring, SystemActionClass);
		void* DestValuePtr = DestProperty->ContainerPtrToValuePtr<void>(SystemAction);
		if (DestValuePtr == nullptr)
		{
			return nullptr;
		}
		FloatProperty->SetPropertyValue(DestValuePtr, DelayTime);
		return SystemAction;
	}

	TArray<UQuestSystemActionBase*> CreateSystemActionReplaceOldAction(UQuestActionBase* Action, UQuestObject* Ring)
	{
		TArray<UQuestSystemActionBase*> Result;
		if (Action == nullptr)
		{
			return Result;
		}
		const TMap<FString, UClass*>& QuestActionClassList = UKGQuestEditorSubSystem::Get().GetSystemActionClassList();
		if (!SimpleActionReplaceMap.Contains(Action->Event))
		{
			return Result;
		}
		auto Remapping = SimpleActionReplaceMap[Action->Event];
		FString FuncName = Remapping.FuncName;
		if (!QuestActionClassList.Contains(FuncName))
		{
			return Result;
		}
		UClass* SystemActionClass = QuestActionClassList[FuncName];
		if (SystemActionClass == nullptr)
		{
			return Result;
		}
		UQuestSystemActionBase* SystemAction = NewObject<UQuestSystemActionBase>(Ring, SystemActionClass);
		Result.Add(SystemAction);
		for (auto ParamPair : Remapping.ParamsMap)
		{
			FString SrcPropertyName = ParamPair.Key;
			FProperty* SrcProperty = Action->GetClass()->FindPropertyByName(FName(SrcPropertyName));
			if (SrcProperty == nullptr)
			{
				continue;
			}
			FString DestPropertyName = ParamPair.Value;
			FProperty* DestProperty = SystemActionClass->FindPropertyByName(FName(DestPropertyName));
			if (DestProperty == nullptr)
			{
				continue;
			}
			void* SrcValuePtr = SrcProperty->ContainerPtrToValuePtr<void>(Action);
			if (SrcValuePtr == nullptr)
			{
				continue;
			}
			void* DestValuePtr = DestProperty->ContainerPtrToValuePtr<void>(SystemAction);
			if (DestValuePtr == nullptr)
			{
				continue;
			}
			if (DestProperty->SameType(SrcProperty))
			{
				DestProperty->CopyCompleteValue(DestValuePtr, SrcValuePtr);
			}
			else
			{
				if (FStructProperty* StructProperty = CastField<FStructProperty>(SrcProperty))
				{
					const FString CPPType = StructProperty->GetCPPType(nullptr, 0);
					// 特殊处理FVector结构体参数，转化成新的TArray的形式
					if (CPPType == "FVector")
					{
						FVector* Vector = static_cast<FVector*>(SrcValuePtr);
						if (FArrayProperty* ArrayProperty = CastField<FArrayProperty>(DestProperty))
						{
							FProperty* ElemProperty = ArrayProperty->Inner;
							if (FFloatProperty* FloatProperty = CastField<FFloatProperty>(ElemProperty))
							{
								FScriptArrayHelper Helper(ArrayProperty, DestValuePtr);
								Helper.Resize(3);
								FloatProperty->SetPropertyValue(Helper.GetRawPtr(0), Vector->X);
								FloatProperty->SetPropertyValue(Helper.GetRawPtr(1), Vector->Y);
								FloatProperty->SetPropertyValue(Helper.GetRawPtr(2), Vector->Z);
							}
						}
					}
					// 特殊处理FAnimLibAssetID结构体
					else if (CPPType == "FAnimLibAssetID")
					{
						FAnimLibAssetID* AnimLibAssetID = static_cast<FAnimLibAssetID*>(SrcValuePtr);

						if (FStrProperty* DestFeatureNameProperty = CastField<FStrProperty>(SystemActionClass->FindPropertyByName(FName("FeatureName"))))
						{
							void* DestFeatureNameValuePtr = DestFeatureNameProperty->ContainerPtrToValuePtr<void>(SystemAction);
							DestFeatureNameProperty->SetPropertyValue(DestFeatureNameValuePtr, AnimLibAssetID->AssetID);
						}

						if (FStrProperty* DestAnimStageProperty = CastField<FStrProperty>(SystemActionClass->FindPropertyByName(FName("AnimStage"))))
						{
							void* DestAnimStageValuePtr = DestAnimStageProperty->ContainerPtrToValuePtr<void>(SystemAction);
							DestAnimStageProperty->SetPropertyValue(DestAnimStageValuePtr, AnimLibAssetID->StateName);
						}
					}
				}
				// 特殊处理 166:QA_REMOVE_QUEST_ITEM这个action中的Items字段
				else if (FArrayProperty* SrcArrayProperty = CastField<FArrayProperty>(SrcProperty))
				{
					FProperty* SrcElemProperty = SrcArrayProperty->Inner;
					// 特殊处理115播放2D音效
					if (Action->Event == 115)
					{
						if (FSoftObjectProperty* SoftObjectProperty = CastField<FSoftObjectProperty>(SrcElemProperty))
						{
							FScriptArrayHelper SrcArrayHelper(SrcArrayProperty, SrcValuePtr);
							if (SrcArrayHelper.Num() > 0)
							{
								void* ElementPtr = SrcArrayHelper.GetRawPtr(0);
								FSoftObjectPtr* ValuePtr = static_cast<FSoftObjectPtr*>(ElementPtr);
								if (FStrProperty* DestStrProperty = CastField<FStrProperty>(DestProperty))
								{
									DestStrProperty->SetPropertyValue(DestValuePtr, ValuePtr->ToString());
									for (int i = 1; i < SrcArrayHelper.Num(); ++i)
									{
										ElementPtr = SrcArrayHelper.GetRawPtr(i);
										UQuestSystemActionBase* NewSystemAction = NewObject<UQuestSystemActionBase>(Ring, SystemActionClass);
										Result.Add(NewSystemAction);
										DestValuePtr = DestProperty->ContainerPtrToValuePtr<void>(NewSystemAction);
										DestStrProperty->SetPropertyValue(DestValuePtr, ValuePtr->ToString());
									}
								}
							}
						}
					}
					else
					{
						if (FStructProperty* StructProp = CastField<FStructProperty>(SrcElemProperty))
						{
							if (StructProp->GetCPPType(nullptr, 0) != "FItemStructure")
							{
								continue;
							}
							FArrayProperty* DestArrayProperty = CastField<FArrayProperty>(DestProperty);
							if (DestArrayProperty == nullptr)
							{
								continue;
							}
							FScriptArrayHelper SrcArrayHelper(SrcArrayProperty, SrcValuePtr);
							FScriptArrayHelper DestArrayHelper(DestArrayProperty, DestValuePtr);
							DestArrayHelper.Resize(SrcArrayHelper.Num());
							FIntProperty* DestElemIntProperty = CastField<FIntProperty>(DestArrayProperty->Inner);
							if (DestElemIntProperty == nullptr)
							{
								continue;
							}
							FProperty* ItemIDProperty = nullptr;
							for (TFieldIterator<FProperty> PropIt(StructProp->Struct); PropIt; ++PropIt)
							{
								if ((*PropIt)->GetAuthoredName() == "ItemID")
								{
									ItemIDProperty = (*PropIt);
									break;
								}
							}
							if (ItemIDProperty == nullptr)
							{
								continue;
							}
							for (int i = 0; i< SrcArrayHelper.Num(); ++i)
							{
								void* ElementPtr = SrcArrayHelper.GetRawPtr(i);
								void* ItemIDValuePtr = ItemIDProperty->ContainerPtrToValuePtr<void>(ElementPtr);
								FGameplayID* ItemID = static_cast<FGameplayID*>(ItemIDValuePtr);
								DestElemIntProperty->SetPropertyValue(DestArrayHelper.GetRawPtr(i), ItemID->ID);
							}
						}
					}
				}
				// 特殊处理从FText到FString的迁移
				else if (FTextProperty* SrcTextProperty = CastField<FTextProperty>(SrcProperty))
				{
					if (FStrProperty* StrProperty = CastField<FStrProperty>(DestProperty))
					{
						StrProperty->SetPropertyValue(DestValuePtr, SrcTextProperty->GetPropertyValue(SrcValuePtr).ToString());
					}
				}
				// 特殊处理从double类型参数数据迁移到float类型数据
				else if (const FDoubleProperty* DoubleProperty = CastField<FDoubleProperty>(SrcProperty))
				{
					if (FFloatProperty* FloatProperty = CastField<FFloatProperty>(DestProperty))
					{
						FloatProperty->SetPropertyValue(DestValuePtr, DoubleProperty->GetPropertyValue(SrcValuePtr));
					}
				}
				// 特殊处理Enum
				else if (CastField<FEnumProperty>(SrcProperty) || CastField<FByteProperty>(SrcProperty))
				{
					if (FIntProperty* IntProperty = CastField<FIntProperty>(DestProperty))
					{
						IntProperty->SetPropertyValue(DestValuePtr, *static_cast<int8*>(SrcValuePtr));
					}
				}
			}
		}

		// 单独处理旧action中的InstanceID参数到新action中的Get函数的迁移
		if (HasGetFuncActionIDs.Contains(Action->Event))
		{
			FProperty* SrcProperty = Action->GetClass()->FindPropertyByName(FName("InstanceID"));
			if (SrcProperty == nullptr)
			{
				return Result;
			}
			FProperty* DestProperty = SystemActionClass->FindPropertyByName(FName("QuestAddGetInstanceID"));
			if (DestProperty == nullptr)
			{
				return Result;
			}
			void* SrcValuePtr = SrcProperty->ContainerPtrToValuePtr<void>(Action);
			if (SrcValuePtr == nullptr)
			{
				return Result;
			}
			void* DestValuePtr = DestProperty->ContainerPtrToValuePtr<void>(SystemAction);
			if (DestValuePtr == nullptr)
			{
				return Result;
			}
			FString SrcInstanceID;
			SrcProperty->ExportTextItem_Direct(SrcInstanceID, SrcValuePtr, nullptr, nullptr, PPF_None);
			if (SrcInstanceID == "0")
			{
				return Result;
			}
			if (DestProperty->SameType(SrcProperty))
			{
				DestProperty->CopyCompleteValue(DestValuePtr, SrcValuePtr);
			}
			else
			{
				if (FArrayProperty* ArrayProperty = CastField<FArrayProperty>(SrcProperty))
				{
					FScriptArrayHelper ArrayHelper(ArrayProperty, SrcValuePtr);
					FProperty* ElementType = ArrayProperty->Inner;
					if (ArrayHelper.Num() > 0)
					{
						void* ElementPtr = ArrayHelper.GetRawPtr(0);
						if (DestProperty->SameType(ElementType))
						{
							DestProperty->CopyCompleteValue(DestValuePtr, ElementPtr);
						}
						for (int i = 1; i < ArrayHelper.Num(); ++i)
						{
							UQuestSystemActionBase* NewSystemAction = NewObject<UQuestSystemActionBase>(Ring, SystemActionClass);
							Result.Add(NewSystemAction);
							ElementPtr = ArrayHelper.GetRawPtr(i);
							DestValuePtr = DestProperty->ContainerPtrToValuePtr<void>(NewSystemAction);
							if (DestProperty->SameType(ElementType))
							{
								DestProperty->CopyCompleteValue(DestValuePtr, ElementPtr);
							}
						}
					}
				}
			}
		}
		
		return Result;
	}

	TArray<UQuestSystemActionBase*> TransformSpecialAction(UQuestActionBase* Action, UQuestObject* Ring)
	{
		TArray<UQuestSystemActionBase*> Result;
		const TMap<FString, UClass*>& QuestActionClassList = UKGQuestEditorSubSystem::Get().GetSystemActionClassList();
		auto Remapping = SpecialActionReplaceMap[Action->Event];
		FString FuncName = Remapping.FuncName;
		if (!QuestActionClassList.Contains(FuncName))
		{
			return Result;
		}
		UClass* SystemActionClass = QuestActionClassList[FuncName];
		if (SystemActionClass == nullptr)
		{
			return Result;
		}
		FBoolProperty* SrcIsShowTipsProperty = CastField<FBoolProperty>(Action->GetClass()->FindPropertyByName(FName("IsShowTips")));
		if (SrcIsShowTipsProperty == nullptr)
		{
			return Result;
		}
		void* IsShowTipsPtr = SrcIsShowTipsProperty->ContainerPtrToValuePtr<void>(Action);
		bool SrcIsShowTipsValue = SrcIsShowTipsProperty->GetPropertyValue(IsShowTipsPtr);
		FArrayProperty* SrcItemsProperty = CastField<FArrayProperty>(Action->GetClass()->FindPropertyByName(FName("Items")));
		if (SrcItemsProperty == nullptr)
		{
			return Result;
		}
		FStructProperty* StructProp = CastField<FStructProperty>(SrcItemsProperty->Inner);
		if (StructProp == nullptr || StructProp->GetCPPType(nullptr, 0) != "FItemStructure")
		{
			return Result;
		}
		FProperty* ItemIDProperty = nullptr;
		FProperty* CountProperty = nullptr;
		for (TFieldIterator<FProperty> PropIt(StructProp->Struct); PropIt; ++PropIt)
		{
			if ((*PropIt)->GetAuthoredName() == "ItemID")
			{
				ItemIDProperty = (*PropIt);
			}
			if ((*PropIt)->GetAuthoredName() == "Count")
			{
				CountProperty = (*PropIt);
			}
		}
		if (ItemIDProperty == nullptr || CountProperty == nullptr)
		{
			return Result;
		}
		FIntProperty* DestItemIDProperty = CastField<FIntProperty>(SystemActionClass->FindPropertyByName(FName("ItemID")));
		FIntProperty* DestCountProperty = CastField<FIntProperty>(SystemActionClass->FindPropertyByName(FName("Count")));
		FBoolProperty* DestIsShowTipsProperty = CastField<FBoolProperty>(SystemActionClass->FindPropertyByName(FName("IsShowTips")));
		if (DestItemIDProperty == nullptr || DestCountProperty == nullptr || DestIsShowTipsProperty == nullptr)
		{
			return Result;
		}
		void* SrcValuePtr = SrcItemsProperty->ContainerPtrToValuePtr<void>(Action);
		FScriptArrayHelper ArrayHelper(SrcItemsProperty, SrcValuePtr);
		for (int i = 0; i < ArrayHelper.Num(); ++i)
		{
			UQuestSystemActionBase* SystemAction = NewObject<UQuestSystemActionBase>(Ring, SystemActionClass);
			Result.Add(SystemAction);
			void* ElementPtr = ArrayHelper.GetRawPtr(i);
			void* ItemIDValuePtr = ItemIDProperty->ContainerPtrToValuePtr<void>(ElementPtr);
			FGameplayID* ItemID = static_cast<FGameplayID*>(ItemIDValuePtr);
			int32 ItemIDValue = ItemID->ID;
			void* CountValuePtr = CountProperty->ContainerPtrToValuePtr<void>(ElementPtr);
			FIntProperty* CountIntProperty = CastField<FIntProperty>(CountProperty);
			int32 CountValue = CountIntProperty->GetPropertyValue(CountValuePtr);
			void* DestItemIDPtr = DestItemIDProperty->ContainerPtrToValuePtr<void>(SystemAction);
			DestItemIDProperty->SetPropertyValue(DestItemIDPtr, ItemIDValue);
			void* DestCountPtr = DestCountProperty->ContainerPtrToValuePtr<void>(SystemAction);
			DestCountProperty->SetPropertyValue(DestCountPtr, CountValue);
			void* DestIsShowTipsPtr = DestIsShowTipsProperty->ContainerPtrToValuePtr<void>(SystemAction);
			DestIsShowTipsProperty->SetPropertyValue(DestIsShowTipsPtr, SrcIsShowTipsValue);
		}
		return Result;
	}

	template<typename ActionType, typename SystemActionType>
	bool TransformOldActionToSystemAction(TArray<ActionType>& Actions, TArray<SystemActionType>& SystemActions, UQuestObject* Parent)
	{
		bool bSuccess = false;
		for (int32 i = Actions.Num() - 1; i >= 0; i--)
		{
			if (Actions[i] == nullptr)
			{
				continue;
			}
			if (!TransformEventSet.IsEmpty() && !TransformEventSet.Contains(Actions[i]->Event))
			{
				continue;
			}
			if (SpecialActionReplaceMap.Contains(Actions[i]->Event))
			{
				SystemActions.Append(TransformSpecialAction(Actions[i], Parent));
				Actions.RemoveAt(i);
				bSuccess = true;
			}
			else
			{
				TArray<UQuestSystemActionBase*> SystemActionArray = CreateSystemActionReplaceOldAction(Actions[i], Parent);
				if (!SystemActionArray.IsEmpty())
				{
					for (int32 j = SystemActionArray.Num() - 1; j >= 0; --j)
					{
						SystemActions.Insert(SystemActionArray[j], 0);
					}
					if (UQuestSystemActionBase* DelayAction = CreateDelayAction(Actions[i], Parent))
					{
						SystemActions.Insert(DelayAction, 0);
					}
					Actions.RemoveAt(i);
					bSuccess = true;
				}
			}
		}
		return bSuccess;
	}
}

FAutoConsoleCommand KGTransformActionParams(TEXT("KGQuest.TransformActionToSystemAction"), TEXT("KGQuest.TransformActionToSystemAction"), FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
{
	TransformEventSet.Empty();
	for (int32 i = 0; i < Args.Num(); i++)
	{
		TransformEventSet.Add(FCString::Atoi(*Args[i]));
	}
	TArray<UObject*> EditedAssets = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->GetAllEditedAssets();
	FQuestObjectivesEditor* QuestEditor = nullptr;
	for (UObject* EditedAsset : EditedAssets)
	{
		if (IAssetEditorInstance* EditorInstance = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(EditedAsset, true))
		{
			if (EditorInstance->GetEditorName() == TEXT("QuestObjectivesEditor"))
			{
				QuestEditor = static_cast<FQuestObjectivesEditor*>(EditorInstance);
				break;
			}
		}
	}
	if (QuestEditor == nullptr)
	{
		return;
	}

	TArray<TObjectPtr<UQuestChapter>>& AllChapters = QuestEditor->GetAllQuestChapters();
	for (auto Chapter : AllChapters)
	{
		if (Chapter == nullptr)
		{
			continue;
		}

		if (Chapter->ChapterGraph == nullptr)
		{
			QuestEditor->PreRefreshChapterGraph(Chapter);
		}
	}

	TSet<UQuestRing*> NeedResaveRings;
	TArray<TObjectPtr<UQuestRing>>& AllQuestRings = QuestEditor->GetAllQuestRings();

	for (auto Ring : AllQuestRings)
	{
		if (Ring == nullptr)
		{
			continue;
		}
		if (Ring->RingGraph == nullptr)
		{
			QuestEditor->PreRefreshRingGraph(Ring);
		}

		for (TObjectPtr<UEdGraphNode>& QuestNode : Ring->RingGraph->Nodes)
		{
			if (!QuestNode)
			{
				continue;
			}
			UEDGraphNode_Base* QNode = Cast<UEDGraphNode_Base>(QuestNode);
			if (QNode == nullptr)
			{
				continue;
			}
			UQuest* QuestData = Cast<UQuest>(QNode->NodeInstance);
			if (QuestData == nullptr)
			{
				continue;
			}
			if (QuestData->QuestGraph == nullptr)
			{
				QuestEditor->PreRefreshQuestGraph(QuestData);
			}
		}
	}
	QuestEditor->SaveRings(NeedResaveRings.Array());
}));
