// Fill out your copyright notice in the Description page of Project Settings.


#include "UserQuestActionNode.h"
#include "UserGroupQuest.h"
#include "QuestTemplate.h"

//void UUserQuestActionNode::InitQuest(UQuest* QuestTemp, UUserQuest* Parent, class UQuestManager* missionMgr)
//{
//	Super::InitQuest(QuestTemp,Parent, missionMgr);
//
//}
//
//void UUserQuestActionNode::DestroyAll()
//{
//	UUserQuest::DestroyAll();
//
//}
//
//const FName UUserQuestActionNode::GetActionNodeId()
//{
//	return QuestTemplate->Id;
//}
//
//void UUserQuestActionNode::UpdateQuestStatus()
//{
//	//节点是否执行完成  
//	if (QuestStatus < EQuestStatus::EMS_Accepted)
//	{
//		//任务尚未接受
//		if (CheckAcceptCondition())
//		{
//			QuestStatus = EQuestStatus::EMS_Accepted;
//		}
//	}
//	else if (QuestStatus < EQuestStatus::EMS_Complete)
//	{
//		//任务尚未完成
//		if (CheckCompleteCondition())
//		{
//			QuestStatus = EQuestStatus::EMS_Complete;
//		}
//	}
//
//	//刷新父任务状态
//	if (ParentQuest != nullptr)
//	{
//		ParentQuest->UpdateQuestStatus();
//	}
//
//}
//
//UQuestActionNode* UUserQuestActionNode::GetQuestActionNodeTemplate()
//{
//	return Cast<UQuestActionNode>(QuestTemplate);
//}

