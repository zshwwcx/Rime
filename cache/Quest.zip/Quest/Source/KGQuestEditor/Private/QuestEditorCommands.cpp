﻿#include "QuestEditorCommands.h"

#define LOCTEXT_NAMESPACE "FQuestEditorModule"



void FQuestEditorCommands::RegisterCommands()
{
	UI_COMMAND(CreateChapter, "Create", "Create a chapter under selected type", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(ChapterCopy, "Copy", "Copy selected chapters", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(ChapterCut, "Cut", "Copy and delete selected chapters", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(ChapterPaste, "Paste", "Paste copied chapters", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(ChapterDelete, "Delete", "Delete selected chapters", EUserInterfaceActionType::Button, FInputChord());
}

#undef LOCTEXT_NAMESPACE