// Copyright 15.07.2018 Tefel. All Rights Reserved. 

#pragma once
#include "SGraphPalette.h"

class  SCCGraphPalette : public SGraphPalette
{
public:
	SLATE_BEGIN_ARGS(SCCGraphPalette){}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, TWeakPtr<class FQuestObjectivesEditor> InQuestObjectivesEditor);
	virtual void CollectAllActions(FGraphActionListBuilderBase& OutAllActions) override;
	virtual TSharedRef<SWidget> OnCreateWidgetForAction(FCreateWidgetForActionData* const InCreateData);
	virtual FReply OnActionDragged(const TArray< TSharedPtr<FEdGraphSchemaAction> >& InActions, const FPointerEvent& MouseEvent);

	void Refresh();

	TWeakPtr<class FQuestObjectivesEditor> GetQuestObjectivesEditor() const { return QuestObjectivesEditor; }

protected:

	TWeakPtr<class FQuestObjectivesEditor> QuestObjectivesEditor;
};
