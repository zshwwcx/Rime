// Copyright 15.07.2018 Tefel. All Rights Reserved.

#pragma once
#include "EdGraphUtilities.h"

class  FCCNodeFactory : public FGraphPanelNodeFactory
{
private:
	virtual TSharedPtr<class SGraphNode> CreateNode(UEdGraphNode* Node) const override;
};
