// Copyright 15.07.2018 Tefel. All Rights Reserved.

#pragma once

#include "SGraphNode.h"
#include "../Graph/MONode_Base.h"

class UMONode_Base;

/**
 * Implements the message interaction graph panel.
 */
class  SCCStandardNode : public SGraphNode, public FNodePropertyObserver
{
public:
	SLATE_BEGIN_ARGS(SCCStandardNode) { }
	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, UMONode_Base* InNode);

	// SGraphNode interface
	virtual void UpdateGraphNode() override;
	void CreateRepetitionNumber(UMONode_Base* BaseNode);
	virtual void CreatePinWidgets() override;
	virtual void AddPin(const TSharedRef<SGraphPin>& PinToAdd) override;
	// End of SGraphNode interface

	// FPropertyObserver interface
	virtual void OnPropertyChanged(UMONode_Base* Sender, const FName& PropertyName) override;
	// End of FPropertyObserver interface

	// Called when text is being committed to check for validity
	bool OnVerifyNameTextChanged(const FText& InText, FText& OutErrorMessage);
	
	//双击回调1
	virtual FReply OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent) override;

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

	FText GetHeadTitle() const;

	FText GetHeadTitleID() const;

	FText GetHeadTitleType() const;

protected:
	virtual const FSlateBrush* GetNameIcon() const;

	static FLinearColor InactiveStateColor;
	static FLinearColor ActiveStateColorDim;
	static FLinearColor ActiveStateColorBright;

	TSharedPtr<SOverlay> RepetitionsCountOverlay;
	TSharedPtr<SHorizontalBox> TitleHorizontalBox;



};
