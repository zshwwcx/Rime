#pragma once

#include "CoreMinimal.h"
#include "FQuestObjectivesEditor.h"
#include "Widgets/SCompoundWidget.h"

class SIDExchangePanel : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SIDExchangePanel) {}
	SLATE_ARGUMENT(FQuestObjectivesEditor*, CurQuestObjectivesEditor)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

private:
	// 输入行结构体
	struct FInputRow
	{
		TSharedPtr<SSuggestionTextBox> FirstInput;
		TSharedPtr<SSuggestionTextBox> SecondInput;
	};
	
	void GetIDSuggestions(const FString& CurrText, TArray<FString>& OutSuggestions);

	// 按钮回调
	FReply HandleAddRowClicked();
	FReply HandleConfirmClicked();

	// 添加新行
	void AddNewRow();

private:
	FQuestObjectivesEditor* CurQuestObjectivesEditor = nullptr;

	TArray<TSharedPtr<FInputRow>> InputRows; // 存储所有输入行
	TSharedPtr<SVerticalBox> RowsContainer;  // 行容器
};