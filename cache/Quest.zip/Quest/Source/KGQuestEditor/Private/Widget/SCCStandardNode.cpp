// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "SCCStandardNode.h"
#include "GraphEditor.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "SCCOutputPin.h"
#include "SGraphPin.h"
#include "../Graph/MONode_Base.h"
#include "../MOEditorStyle.h"
#include "../Graph/MONode_Quest.h"
#include "../Graph/EdGraph_QuestObjectivesProp.h"
#include "FQuestObjectivesEditor.h"
#include "../UI/QuestScrollWidget.h"
#include "../UI/QuestListViewWidget.h"
#include "../Graph/MONode_QuestAction.h"
#include "QuestTemplate.h"


void SCCStandardNode::Construct(const FArguments& InArgs, UMONode_Base* InNode)
{
	GraphNode = InNode;

	this->SetCursor(EMouseCursor::CardinalCross);
	this->UpdateGraphNode();
}

const FSlateBrush* SCCStandardNode::GetNameIcon() const
{
	return FAppStyle::Get().GetBrush(TEXT("BTEditor.Graph.BTNode.Task.Wait.Icon"));
}

void SCCStandardNode::OnPropertyChanged(UMONode_Base* Sender, const FName& PropertyName)
{
	UpdateGraphNode();
}

bool SCCStandardNode::OnVerifyNameTextChanged(const FText& InText, FText& OutErrorMessage)
{
	OutErrorMessage = FText::FromString(TEXT("Error"));
	if (InText.ToString().Len() == 0) {
		OutErrorMessage = FText::FromString(TEXT("Invalid Name"));
		return false;
	}

	return true;
}

FReply SCCStandardNode::OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	if (UMONode_Base* BaseNode = Cast<UMONode_Base>(GraphNode))
	{
		BaseNode->OnMouseButtonDoubleClick();
	}

	return FReply::Unhandled();
}

FReply SCCStandardNode::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (MouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton))
	{
		UMONode_Base* BaseNode = CastChecked<UMONode_Base>(GraphNode);
		BaseNode->OnMouseButtonDown();
	}

	return FReply::Unhandled();
}

FText SCCStandardNode::GetHeadTitle() const
{
	UMONode_Base* BaseNode = CastChecked<UMONode_Base>(GraphNode);
	return BaseNode->GetHeadTitle();
}

FText SCCStandardNode::GetHeadTitleID() const
{
	UMONode_Base* BaseNode = CastChecked<UMONode_Base>(GraphNode);
	return BaseNode->GetHeadTitleID();
}

FText SCCStandardNode::GetHeadTitleType() const
{
	UMONode_Base* BaseNode = CastChecked<UMONode_Base>(GraphNode);
	return BaseNode->GetHeadTitleType();
}

void SCCStandardNode::UpdateGraphNode()
{
	UMONode_Base* BaseNode = CastChecked<UMONode_Base>(GraphNode);
	//UMOTextNode* TextNode = CastChecked<UMOTextNode>(BaseNode->AssociatedObject);

	InputPins.Empty();
	OutputPins.Empty();
	RightNodeBox.Reset();
	LeftNodeBox.Reset();

	const FSlateBrush* NodeTypeIcon = BaseNode->GetNodeIcon();
	const FSlateBrush* NodeBackgroundImage = BaseNode->GetNodeBackgroundImage();

	TSharedPtr<SErrorText> ErrorText;
	TSharedPtr<SNodeTitle> NodeTitle = SNew(SNodeTitle, GraphNode);

	this->ContentScale.Bind(this, &SGraphNode::GetContentScale);
	this->GetOrAddSlot(ENodeZone::Center)
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(SBorder)
			.BorderImage(NodeBackgroundImage)
			.Padding(0)
			[
				SAssignNew(RepetitionsCountOverlay, SOverlay)
				+ SOverlay::Slot()
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				.Padding(0.0f, 0.0f)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					[
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
						.HAlign(HAlign_Left)
						.FillWidth(0.1f)
						.Padding(FMargin(0.0f, 0.0f, 4.0f, 0.0f))
						[
							// INPUT PIN AREA
							SAssignNew(LeftNodeBox, SVerticalBox)
						]

						+ SHorizontalBox::Slot()
						.HAlign(HAlign_Fill)
						.VAlign(VAlign_Fill)
						[
							SNew(SHorizontalBox)
							+ SHorizontalBox::Slot()
							.AutoWidth()
							[
								SNew(SVerticalBox)
								+ SVerticalBox::Slot()
								.VAlign(VAlign_Center)
								.HAlign(HAlign_Center)
								[
									SNew(SBox)
									.WidthOverride(30)
									.HeightOverride(30.0f)
									[
										SNew(SImage)
										.Image(NodeTypeIcon)
									]
								]
							]

							+ SHorizontalBox::Slot()
							.HAlign(HAlign_Fill)
							.VAlign(VAlign_Fill)
							[
								SNew(SVerticalBox)
								+ SVerticalBox::Slot()
								.Padding(4.0f, 6.0f, 0.0f, 0.0f)
								[
									SNew(SHorizontalBox)
									+ SHorizontalBox::Slot()
									.AutoWidth()
									[
										SNew(STextBlock)
										.Visibility(EVisibility::HitTestInvisible)
										.TextStyle(FMOEditorStyle::Get(), "MO.NodeTitle")
										.Text(this, &SCCStandardNode::GetHeadTitleType)
									]

									+ SHorizontalBox::Slot()
									.AutoWidth()
									[
										SNew(STextBlock)
										.Visibility(EVisibility::HitTestInvisible)
										.TextStyle(FMOEditorStyle::Get(), "MO.NodeTitle")
										.Text(this, &SCCStandardNode::GetHeadTitleID)
									]
								]

								+ SVerticalBox::Slot()
								.Padding(4.0f, 6.0f, 0.0f, 0.0f)
								[
									SNew(STextBlock)
									.Visibility(EVisibility::HitTestInvisible)
									.TextStyle(FMOEditorStyle::Get(), "MO.NodeTitle")
									.Text(this, &SCCStandardNode::GetHeadTitle)
								]
							]

							
						]

						//+ SHorizontalBox::Slot()
						//.Padding(2.f, .0f)
						//[
						//	SNew(STextBlock)
						//	.Visibility(EVisibility::HitTestInvisible)
						//	.TextStyle(FMOEditorStyle::Get(), "MO.NodeText")
						//	.AutoWrapText(true)
						//	.WrapTextAt(220.f)
						//	//.Text(TextNode->Text)
						//]

						+ SHorizontalBox::Slot()
						.AutoWidth()
						.Padding(0.f, 0.f, 0.f, 6.f)
						[
							NodeTitle.ToSharedRef()
						]

						+ SHorizontalBox::Slot()
						.AutoWidth()
						.HAlign(HAlign_Right)
						.FillWidth(0.1f)
						.Padding(FMargin(4.0f, 0.0f, 0.0f, 0.0f))
						[
							// OUTPUT PIN AREA
							SAssignNew(RightNodeBox, SVerticalBox)
						]
					]
				]
			]
	];

	CreateRepetitionNumber(BaseNode);
	CreatePinWidgets();
}



void SCCStandardNode::CreateRepetitionNumber(UMONode_Base* BaseNode)
{
	//if (UMOObjectiveNode* ObjectiveNode = Cast<UMOObjectiveNode>(BaseNode->AssociatedObject))
	{
		/*int32 ObjectiveRepeatNumber = ObjectiveNode->GetRepetitionsCount();
		if (ObjectiveRepeatNumber > 1)
		{
			FString ObjectiveRepeatText = "x" + FString::FromInt(ObjectiveNode->GetRepetitionsCount());

			TitleHorizontalBox->AddSlot()
			[
				SNew(SBox)
				.WidthOverride(10.f)
				.HeightOverride(1.f)
			];

			RepetitionsCountOverlay->AddSlot(0)
			.HAlign(HAlign_Right)
			.VAlign(VAlign_Top)
			.Padding(0.0f, 4.0f, -16.f, 0.0f)
			[
				SNew(SBorder)
				.Padding(FMargin(6.0f))
				.BorderImage(FMOEditorStyle::GetBrush(TEXT("MOEditor.nodecirclebackground")))
				.BorderBackgroundColor(FColor::Black)
				[
					SNew(STextBlock)
					.Visibility(EVisibility::HitTestInvisible)
					.TextStyle(FMOEditorStyle::Get(), "MO.ObjectiveCount")
					.Text(FText::FromString(ObjectiveRepeatText))
				]
			];
		}*/
	}
}

void SCCStandardNode::CreatePinWidgets()
{
	UMONode_Base* Node = CastChecked<UMONode_Base>(GraphNode);
	{
		UEdGraphPin* CurPin = Node->GetOutputPin();
		if (CurPin)
		{
			TSharedPtr<SGraphPin> NewPin = SNew(SCCOutputPin, CurPin);
			NewPin->SetIsEditable(IsEditable);
			this->AddPin(NewPin.ToSharedRef());
			OutputPins.Add(NewPin.ToSharedRef());
		}
	}
	{
		UEdGraphPin* CurPin = Node->GetInputPin();
		if (CurPin)
		{
			TSharedPtr<SGraphPin> NewPin = SNew(SCCOutputPin, CurPin);
			NewPin->SetIsEditable(IsEditable);
			this->AddPin(NewPin.ToSharedRef());
			InputPins.Add(NewPin.ToSharedRef());
		}
	}
}

void SCCStandardNode::AddPin(const TSharedRef<SGraphPin>& PinToAdd)
{
	PinToAdd->SetOwner(SharedThis(this));

	const UEdGraphPin* PinObj = PinToAdd->GetPinObj();
	const bool bAdvancedParameter = PinObj && PinObj->bAdvancedView;
	if (bAdvancedParameter)
	{
		PinToAdd->SetVisibility(TAttribute<EVisibility>(PinToAdd, &SGraphPin::IsPinVisibleAsAdvanced));
	}

	if (PinToAdd->GetDirection() == EEdGraphPinDirection::EGPD_Input)
	{
		LeftNodeBox->AddSlot()
			.Padding(.0f, .0f, .0f, -3.f)
			[
				PinToAdd
			];
		InputPins.Add(PinToAdd);
	}
	else // Direction == EEdGraphPinDirection::EGPD_Output
	{
		RightNodeBox->AddSlot()
			[
				PinToAdd
			];
		OutputPins.Add(PinToAdd);
	}
}
