// Copyright 15.07.2018 Tefel. All Rights Reserved.

#include "CCNodeFactory.h"
#include "SCCStandardNode.h"
#include "../Graph/MONode_Base.h"

TSharedPtr<class SGraphNode> FCCNodeFactory::CreateNode(UEdGraphNode* Node) const
{	
	if (UMONode_Base* BaseNode = Cast<UMONode_Base>(Node))
	{
		BaseNode->CreateAsset();
		BaseNode->UpdateTitle();
		TSharedPtr<SCCStandardNode> StandardNode = SNew(SCCStandardNode, BaseNode);
		return StandardNode;
	}

	return NULL;
}
