#include "SIDExchangePanel.h"
#include "QuestObjectDataEntity.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SSuggestionTextBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Text/STextBlock.h"

#define LOCTEXT_NAMESPACE "IDExchange"

void SIDExchangePanel::Construct(const FArguments& InArgs)
{
	CurQuestObjectivesEditor = InArgs._CurQuestObjectivesEditor;

	ChildSlot
	[
		SNew(SVerticalBox)
		// 标题
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10)
		[
			SNew(STextBlock)
			.Text(LOCTEXT("Title", "ID 批量互换"))
			.Font(FAppStyle::GetFontStyle("HeadingExtraSmall"))
			.Justification(ETextJustify::Center)
		]
		
		// 可滚动的输入区域
		+ SVerticalBox::Slot()
		.FillHeight(1.0f)
		[
			SNew(SScrollBox)
			+ SScrollBox::Slot()
			[
				SAssignNew(RowsContainer, SVerticalBox)
			]
		]
		
		// 添加行按钮
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(5)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.HAlign(HAlign_Center)
			[
				SNew(SButton)
				.Text(LOCTEXT("AddButton", "+"))
				.OnClicked(this, &SIDExchangePanel::HandleAddRowClicked)
				.ContentPadding(FMargin(20, 5))
			]
		]
		
		// 确认按钮
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(10)
		[
			SNew(SButton)
			.Text(LOCTEXT("ConfirmButton", "确认"))
			.OnClicked(this, &SIDExchangePanel::HandleConfirmClicked)
			.HAlign(HAlign_Center)
			.ContentPadding(FMargin(20, 10))
		]
	];

	// 创建初始行
	AddNewRow();
}

void SIDExchangePanel::AddNewRow()
{
	TSharedPtr<FInputRow> NewRow = MakeShared<FInputRow>();
	
	// 创建两个输入框
	NewRow->FirstInput = SNew(SSuggestionTextBox)
		.HintText(LOCTEXT("FirstIDHint", "ID 1"))
		.ForegroundColor(FSlateColor::UseForeground())
		.OnShowingSuggestions(this, &SIDExchangePanel::GetIDSuggestions);
	
	NewRow->SecondInput = SNew(SSuggestionTextBox)
		.HintText(LOCTEXT("SecondIDHint", "ID 2"))
		.ForegroundColor(FSlateColor::UseForeground())
		.OnShowingSuggestions(this, &SIDExchangePanel::GetIDSuggestions);
	
	InputRows.Add(NewRow);
	
	// 添加到UI容器
	if (RowsContainer.IsValid())
	{
		RowsContainer->AddSlot()
		.AutoHeight()
		.Padding(5)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.FillWidth(1.0f)
			.Padding(2.0f)
			[
				NewRow->FirstInput.ToSharedRef()
			]
			
			+ SHorizontalBox::Slot()
			.FillWidth(1.0f)
			.Padding(2.0f)
			[
				NewRow->SecondInput.ToSharedRef()
			]
		];
	}
}

FReply SIDExchangePanel::HandleAddRowClicked()
{
	AddNewRow();
	return FReply::Handled();
}

void SIDExchangePanel::GetIDSuggestions(const FString& CurrText, TArray<FString>& OutSuggestions)
{
	if (CurQuestObjectivesEditor)
	{
		const int32 CurrId = FCString::Atoi(*CurrText);
		UQuestObjectDataEntity* CurrDataEntity = CurQuestObjectivesEditor->GetDataEntity();
		auto AddToSuggestions = [&CurrText, &OutSuggestions](int Id)
		{
			const FString IdStr = FString::FromInt(Id);
			if (IdStr.StartsWith(CurrText))
			{
				OutSuggestions.Add(IdStr);
			}
		};
		for (const auto& [Id, _] : CurrDataEntity->ChapterMap)
		{
			AddToSuggestions(Id);
		}
		for (const auto& [Id, _] : CurrDataEntity->RingMap)
		{
			AddToSuggestions(Id);
		}
		for (const auto& [Id, _] : CurrDataEntity->QuestMap)
		{
			AddToSuggestions(Id);
		}
	}
}

FReply SIDExchangePanel::HandleConfirmClicked()
{
	// 这里处理确认逻辑
	for (int32 i = 0; i < InputRows.Num(); ++i)
	{
		const FText FirstID = InputRows[i]->FirstInput->GetText();
		const FText SecondID = InputRows[i]->SecondInput->GetText();
		
		if (!FirstID.IsEmpty() && !SecondID.IsEmpty())
		{
			// 实际项目中这里执行ID互换逻辑
			UE_LOG(LogTemp, Display, TEXT("交换行 %d: %s <-> %s"), 
				i, 
				*FirstID.ToString(), 
				*SecondID.ToString());

			if (CurQuestObjectivesEditor)
			{
				CurQuestObjectivesEditor->IDExchange(FCString::Atoi(*FirstID.ToString()), FCString::Atoi(*SecondID.ToString()));
				InputRows[i]->FirstInput->SetText(FText::FromString(TEXT("")));
				InputRows[i]->SecondInput->SetText(FText::FromString(TEXT("")));
			}
		}
	}
	
	return FReply::Handled();
}

#undef LOCTEXT_NAMESPACE