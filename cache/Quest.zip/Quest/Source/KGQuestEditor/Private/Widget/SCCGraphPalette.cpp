// Copyright 15.07.2018 Tefel. All Rights Reserved. 

#include "SCCGraphPalette.h"
#include "../Graph/MONode_Root.h"
#include "FQuestObjectivesEditor.h"
#include "../Graph/EdGraphSchema_QuestObjectivesProp.h"
#include "../UI/QuestScrollWidget.h"
#include "../UI/QuestListViewWidget.h"

void SCCGraphPalette::Construct(const FArguments& InArgs, TWeakPtr<FQuestObjectivesEditor> InQuestObjectivesEditor)
{
	this->QuestObjectivesEditor = InQuestObjectivesEditor;

	this->ChildSlot
		[
			SNew(SBorder)
			.Padding(2.0f)
			.BorderImage(FAppStyle::Get().GetBrush("ToolPanel.GroupBorder"))
			[
				SNew(SVerticalBox)

				// Content list
				+ SVerticalBox::Slot()
				[
					SNew(SOverlay)

					+ SOverlay::Slot()
					.HAlign(HAlign_Fill)
					.VAlign(VAlign_Fill)
					[
						//SNullWidget::NullWidget
						SAssignNew(GraphActionMenu, SGraphActionMenu)
						.OnActionDragged(this, &SCCGraphPalette::OnActionDragged)
						.OnCreateWidgetForAction(this, &SCCGraphPalette::OnCreateWidgetForAction)
						.OnCollectAllActions(this, &SCCGraphPalette::CollectAllActions)
						.AutoExpandActionMenu(true)
					]
				]
			]
		];
}

void SCCGraphPalette::CollectAllActions(FGraphActionListBuilderBase& OutAllActions)
{
	UEdGraphSchema_QuestObjectivesProp* Schema = const_cast<UEdGraphSchema_QuestObjectivesProp*>(GetDefault<UEdGraphSchema_QuestObjectivesProp>());
	Schema->SetGraphPalette(SharedThis(this));
	TArray<TSharedPtr<FEdGraphSchemaAction> > Actions;
	FGraphActionMenuBuilder ActionMenuBuilder;
	if (QuestObjectivesEditor.IsValid()) {
		TSharedPtr<SGraphEditor> GraphEditor = QuestObjectivesEditor.Pin()->GetGraphEditor();
		if (GraphEditor.IsValid()) {
			UEdGraph* Graph = GraphEditor->GetCurrentGraph();

			// !!
			//TArray<UMONode_Root*> RootNodes;
			//Graph->GetNodesOfClass(RootNodes);
			//if (RootNodes.Num() > 0)
			{
				Schema->GetActionList(Actions, Graph, Schema->GetAllActionType());
				for (TSharedPtr<FEdGraphSchemaAction> Action : Actions) {
					ActionMenuBuilder.AddAction(Action);

				}
			}	
		}
	}
	OutAllActions.Append(ActionMenuBuilder);
}

void SCCGraphPalette::Refresh() {
	RefreshActionsList(true);
}

TSharedRef<SWidget> SCCGraphPalette::OnCreateWidgetForAction(FCreateWidgetForActionData* const InCreateData)
{
	return SGraphPalette::OnCreateWidgetForAction(InCreateData);
}

FReply SCCGraphPalette::OnActionDragged(const TArray< TSharedPtr<FEdGraphSchemaAction> >& InActions, const FPointerEvent& MouseEvent)
{
	
	return SGraphPalette::OnActionDragged(InActions, MouseEvent);
}
