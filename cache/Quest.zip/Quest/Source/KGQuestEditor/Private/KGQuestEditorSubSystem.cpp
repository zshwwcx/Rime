// Fill out your copyright notice in the Description page of Project Settings.


#include "KGQuestEditorSubSystem.h"

#include "FQuestObjectivesEditor.h"
#include "QuestObjectDataEntity.h"
#include "Action/QuestAction.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "FileAsset/QuestEditorLuaObj.h"
#include "FileAsset/QuestImporter.h"

UKGQuestEditorSubSystem& UKGQuestEditorSubSystem::Get()
{
	UKGQuestEditorSubSystem* Instance = GetPtr();
	check(Instance != nullptr);
	return *Instance;
}

UKGQuestEditorSubSystem* UKGQuestEditorSubSystem::GetPtr()
{
	return GEditor->GetEditorSubsystem<UKGQuestEditorSubSystem>();
}

void UKGQuestEditorSubSystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	// load config
	if (GConfig)
	{
		FString KGQuestConfigPath = FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("KGQuest/Config/KGQuestConfig.ini"));
		KGQuestConfigPath = FConfigCacheIni::NormalizeConfigIniPath(KGQuestConfigPath);

		IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
		if (PlatformFile.FileExists(*KGQuestConfigPath))
		{
			GConfig->Flush(true, *KGQuestConfigPath);

			if (!GConfig->GetArray(TEXT("ChapterToRingProperties"), TEXT("ChapterToRingProperty"), ChapterToRingProperties, KGQuestConfigPath))
			{
				UE_LOG(LogTemp, Error, TEXT("Can't Load ChapterToRingProperties from file : %s"), *KGQuestConfigPath);
			}
		}
	}

	if(IsRunningCommandlet())
	{
		return;
	}
}

void UKGQuestEditorSubSystem::Deinitialize()
{
	Super::Deinitialize();
	ShutDownLuaState();
}

void UKGQuestEditorSubSystem::ShutDownLuaState()
{
	CachedDialogueIDData.Empty();
	CachedNPCIDData.Empty();
	CachedItemIDData.Empty();
	CachedTaskCollectIDData.Empty();
	CachedMonsterIDData.Empty();
	CachedItemSubmitIDData.Empty();
    if (LuaEnv)
	{
        UEditorLuaEnv::DestroyLuaEnv(LuaEnv);
        LuaEnv = nullptr;
	}
	if (QuestEditorLuaObj.IsValid())
	{
		// 保证不再进 tick 逻辑
		QuestEditorLuaObj->SetTickableTickType(ETickableTickType::Never);
	}
	QuestEditorLuaObj = nullptr;
}

TArray<TSharedPtr<FString>>* UKGQuestEditorSubSystem::GetDialogueIDData()
{
	if(CachedDialogueIDData.Num() == 0)
	{
		TMap<int32, FString> OutData;
		if(QuestEditorLuaObj == nullptr)
		{
			CreateQuestEditorLuaObj(GetWorld());
		}
		QuestEditorLuaObj->GetDialogueData(OutData);
		for(auto Pair : OutData)
		{
			FString TempLine = FString::FromInt(Pair.Key) + " " + Pair.Value;
			CachedDialogueIDData.Add(MakeShareable(new FString(TempLine)));
		}
	}
	return &CachedDialogueIDData;
}

TArray<TSharedPtr<FString>>* UKGQuestEditorSubSystem::GetNPCIDData()
{
	if(CachedNPCIDData.Num() == 0)
	{
		TMap<int32, FString> OutData;
		if(QuestEditorLuaObj == nullptr)
		{
			CreateQuestEditorLuaObj(GetWorld());
		}
		QuestEditorLuaObj->GetNPCData(OutData);
		for(auto Pair : OutData)
		{
			FString TempLine = FString::FromInt(Pair.Key) + " " + Pair.Value;
			CachedNPCIDData.Add(MakeShareable(new FString(TempLine)));
		}
	}
	return &CachedNPCIDData;
}

TArray<TSharedPtr<FString>>* UKGQuestEditorSubSystem::GetItemIDData()
{
	if(CachedItemIDData.Num() == 0)
	{
		TMap<int32, FString> OutData;
		if(QuestEditorLuaObj == nullptr)
		{
			CreateQuestEditorLuaObj(GetWorld());
		}
		QuestEditorLuaObj->GetItemData(OutData);
		for(auto Pair : OutData)
		{
			FString TempLine = FString::FromInt(Pair.Key) + " " + Pair.Value;
			CachedItemIDData.Add(MakeShareable(new FString(TempLine)));
		}
	}
	return &CachedItemIDData;
}

TArray<TSharedPtr<FString>>* UKGQuestEditorSubSystem::GetTaskCollectData()
{
	if(CachedTaskCollectIDData.Num() == 0)
	{
		TMap<int32, FString> OutData;
		if(QuestEditorLuaObj == nullptr)
		{
			CreateQuestEditorLuaObj(GetWorld());
		}
		QuestEditorLuaObj->GetTaskCollectIDData(OutData);
		for(auto Pair : OutData)
		{
			FString TempLine = FString::FromInt(Pair.Key) + " " + Pair.Value;
			CachedTaskCollectIDData.Add(MakeShareable(new FString(TempLine)));
		}
	}
	return &CachedTaskCollectIDData;
}

TArray<TSharedPtr<FString>>* UKGQuestEditorSubSystem::GetMonsterIDData()
{
	if(CachedMonsterIDData.Num() == 0)
	{
		TMap<int32, FString> OutData;
		if(QuestEditorLuaObj == nullptr)
		{
			CreateQuestEditorLuaObj(GetWorld());
		}
		QuestEditorLuaObj->GetMonsterIDData(OutData);
		for(auto Pair : OutData)
		{
			FString TempLine = FString::FromInt(Pair.Key) + " " + Pair.Value;
			CachedMonsterIDData.Add(MakeShareable(new FString(TempLine)));
		}
	}
	return &CachedMonsterIDData;
}

TArray<TSharedPtr<FString>>* UKGQuestEditorSubSystem::GetOptionTextIDData()
{
	if (CachedOptionTextIDData.Num() == 0)
	{
		TMap<int32, FString> OutData;
		if (QuestEditorLuaObj == nullptr)
		{
			CreateQuestEditorLuaObj(GetWorld());
		}
		QuestEditorLuaObj->GetOptionTextIDData(OutData);
		for (auto Pair : OutData)
		{
			FString TempLine = FString::FromInt(Pair.Key) + " " + Pair.Value;
			CachedOptionTextIDData.Add(MakeShareable(new FString(TempLine)));
		}
	}
	return &CachedOptionTextIDData;
}

FString UKGQuestEditorSubSystem::GetAnimAssetID(const FString& InstanceID)
{
	if (QuestEditorLuaObj == nullptr)
	{
		CreateQuestEditorLuaObj(GetWorld());
	}
	return QuestEditorLuaObj->GetAnimAssetID(InstanceID);
}

TArray<TSharedPtr<FString>>* UKGQuestEditorSubSystem::GetItemSubmitIDData()
{
	if(CachedItemSubmitIDData.Num() == 0)
	{
		TMap<int32, FString> OutData;
		if(QuestEditorLuaObj == nullptr)
		{
			CreateQuestEditorLuaObj(GetWorld());
		}
		QuestEditorLuaObj->GetItemSubmitIDData(OutData);
		for(auto Pair : OutData)
		{
			FString TempLine = FString::FromInt(Pair.Key) + " " + Pair.Value;
			CachedItemSubmitIDData.Add(MakeShareable(new FString(TempLine)));
		}
	}
	return &CachedItemSubmitIDData;
}

TArray<FString> UKGQuestEditorSubSystem::DataCheck(const TArray<UQuestChapter*>& CheckChapters, const TArray<UQuestRing*>& CheckRings, const TArray<UQuest*>& CheckQuests)
{
	TArray<FString> WarningMsgs;

	DataCheckLua(WarningMsgs, CheckChapters, CheckRings, CheckQuests);
	DataCheckCpp(WarningMsgs, CheckChapters, CheckRings, CheckQuests);

	return WarningMsgs;
}

int32 UKGQuestEditorSubSystem::GetQuestSubTargetMaxNumber()
{
	if (QuestEditorLuaObj == nullptr)
	{
		CreateQuestEditorLuaObj(GetWorld());
	}
	return QuestEditorLuaObj->GetQuestSubTargetMaxNumber();
}

void UKGQuestEditorSubSystem::GetSystemActionDefine(TArray<FSystemActionDefine>& OutActionDefine)
{
	if (QuestEditorLuaObj == nullptr)
	{
		CreateQuestEditorLuaObj(GetWorld());
	}
	return QuestEditorLuaObj->GetSystemActionDefine(OutActionDefine);
}

void UKGQuestEditorSubSystem::InitializeQuestActionClasses()
{
	TArray<FSystemActionDefine> OutActionDefine;
	GetSystemActionDefine(OutActionDefine);
	if (!bQuestActionClassesInitialized)
	{
		bQuestActionClassesInitialized = true;
		FQuestActionHelper::InitializeAllQuestActionClasses(QuestActionClassList, OutActionDefine);
		FQuestImporter::InitializeSystemActionClassList(QuestActionClassList);
	}
}

void UKGQuestEditorSubSystem::CreateQuestEditorLuaObj(UWorld* InWorld)
{
    LuaEnv = UEditorLuaEnv::CreateLuaEnv(UQuestEditorLuaObj::StaticClass());
	CachedDialogueIDData.Empty();
    if (UQuestEditorLuaObj *_GameInstance = Cast<UQuestEditorLuaObj>(LuaEnv->GetLuaGameInstance()))
	{
		QuestEditorLuaObj = _GameInstance;
		_GameInstance->Inner_OnStart();
	}
}

void UKGQuestEditorSubSystem::DataCheckLua(TArray<FString>& WarningMsgs, const TArray<UQuestChapter*>& CheckChapters, const TArray<UQuestRing*>& CheckRings, const TArray<UQuest*>& CheckQuests)
{
	if (QuestEditorLuaObj == nullptr)
	{
		CreateQuestEditorLuaObj(GetWorld());
	}
	UE_LOG(LogTemp, Log, TEXT("UKGQuestEditorSubSystem DataCheck."));
	WarningMsgs.Append(QuestEditorLuaObj->DoDataCheck(CheckChapters, CheckRings, CheckQuests));
}

void UKGQuestEditorSubSystem::DataCheckCpp(TArray<FString>& WarningMsgs, const TArray<UQuestChapter*>& CheckChapters, const TArray<UQuestRing*>& CheckRings, const TArray<UQuest*>& CheckQuests)
{
	// 使用道具领取任务检查规则
	// 使用道具领取任务这里填写的id，任务之间是不能重复的，出现重复需要报错。
	FQuestObjectivesEditor* QuestEditorPtr = nullptr;
	FProperty* ItemIDProperty = nullptr;
	FIntProperty* IntProp = nullptr;
	for (UQuestRing* CheckRing : CheckRings)
	{
		if (CheckRing && CheckRing->ApplyType && CheckRing->ApplyType->Type == 3)
		{
			QuestEditorPtr = CheckRing->GetQuestEditor();
			ItemIDProperty = CheckRing->ApplyType->GetClass()->FindPropertyByName(TEXT("ItemID"));

			// 转换为结构体属性
			if (FStructProperty* StructProp = CastField<FStructProperty>(ItemIDProperty))
			{
				// 获取FItemID的结构体描述
				UScriptStruct* ItemIDStruct = StructProp->Struct;

				// 在结构体中查找ID属性
				if (FProperty* IDProp = ItemIDStruct->FindPropertyByName(TEXT("ID")))
				{
					IntProp = CastField<FIntProperty>(IDProp);
					break;
				}
			}
		}
	}
	if (QuestEditorPtr && ItemIDProperty && IntProp)
	{
		// 遍历所有的 Ring 收集所有的 使用道具领取任务 的 ItemID, 可以考虑初始化缓存起来
		TMap<int32, TSet<int32>> ItemID2RingIDs;
		for (UQuestRing* Ring : QuestEditorPtr->GetDataEntity()->AllQuestRings)
		{
			QuestEditorPtr->RefreshRingGraph(Ring, false);
			if (Ring && Ring->ApplyType && Ring->ApplyType->Type == 3)
			{
				void* ItemIDPtr = ItemIDProperty->ContainerPtrToValuePtr<void>(Ring->ApplyType);
				int32 IDValue = IntProp->GetPropertyValue_InContainer(ItemIDPtr);
				if (ItemID2RingIDs.Contains(IDValue))
				{
					ItemID2RingIDs[IDValue].Add(Ring->RingID);
				}
				else
				{
					ItemID2RingIDs.Add(IDValue, {Ring->RingID});
				}
			}
		}
		TArray<int32> ItemIDChecked;
		for (UQuestRing* CheckRing : CheckRings)
		{
			if (CheckRing && CheckRing->ApplyType && CheckRing->ApplyType->Type == 3)
			{
				void* ItemIDPtr = ItemIDProperty->ContainerPtrToValuePtr<void>(CheckRing->ApplyType);
				int32 IDValue = IntProp->GetPropertyValue_InContainer(ItemIDPtr);
				if (!ItemIDChecked.Contains(IDValue) && ItemID2RingIDs.Contains(IDValue) && ItemID2RingIDs[IDValue].Num() > 1)
				{
					ItemIDChecked.Add(IDValue); // 同一个 ItemID 只应该报一次错误
					FString WarningIDs;
					for (int32 WarningRingID : ItemID2RingIDs[IDValue])
					{
						if (!WarningIDs.IsEmpty()) WarningIDs += " ";
						WarningIDs += "[" + FString::FromInt(WarningRingID) + "]";
					}
					FString WarningMsg = FString::Format(TEXT("任务{0}的领取方式都是使用道具领取任务，但是它们共用了同一个道具[{1}]，请修改后再做尝试。"),
						{WarningIDs, IDValue});
					WarningMsgs.Add(FString::Format(TEXT("[问题{0}]{1}"), {WarningMsgs.Num() + 1, WarningMsg}));
				}
			}
		}
	}
}

FAutoConsoleCommand KGExportTargetsAndActions(
	TEXT("KGQuest.ExportTargetsAndActions"),
	TEXT("KGQuest.ExportTargetsAndActions"),
	FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
	{
		FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestTargets");
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

		FARFilter Filter;
		Filter.PackagePaths.Add(*BPFilePath);
		Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;
		
		TArray<FAssetData> AssetDataList;
		AssetRegistry.GetAssets(Filter, AssetDataList);

		TMap<FString, FString> TargetsMap;
		for (auto Asset : AssetDataList)
		{
			if (UBlueprint* BPObj = Cast<UBlueprint>(Asset.GetAsset()))
			{
				UClass* BPClass = BPObj->GeneratedClass;
				if (BPClass->IsChildOf(UQuestTargetBase::StaticClass()))
				{
					UQuestTargetBase* CDO = Cast<UQuestTargetBase>(BPClass->GetDefaultObject());
					TargetsMap.Add(Asset.AssetName.ToString(), FString::Printf(TEXT("%s_%d"), *BPObj->BlueprintDisplayName, CDO->Type));
				}
			}
		}
		BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestActions");
		Filter.PackagePaths.Empty();
		Filter.PackagePaths.Add(*BPFilePath);
		AssetRegistry.GetAssets(Filter, AssetDataList);
		TMap<FString, FString> ActionsMap;
		for (auto Asset : AssetDataList)
		{
			if (UBlueprint* BPObj = Cast<UBlueprint>(Asset.GetAsset()))
			{
				UClass* BPClass = BPObj->GeneratedClass;
				if (BPClass->IsChildOf(UQuestActionBase::StaticClass()))
				{
					UQuestActionBase* CDO = Cast<UQuestActionBase>(BPClass->GetDefaultObject());
					ActionsMap.Add(Asset.AssetName.ToString(), FString::Printf(TEXT("%s_%d"), *BPObj->BlueprintDisplayName, CDO->Event));
				}
			}
		}
		FString Output;
		Output.Append(FString::Printf(TEXT("[QuestTargets] %d\n"), TargetsMap.Num()));
		for (auto Kv : TargetsMap)
		{
			Output.Append(FString::Printf(TEXT("%s:%s\n"), *Kv.Key, *Kv.Value));
		}
		FString FilePath = FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("QuestEditor/QuestTargets.txt"));
		FString AbsolutePath = FPaths::ConvertRelativePathToFull(FilePath);
		FFileHelper::SaveStringToFile(Output, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly);

		Output.Empty();
		Output.Append(FString::Printf(TEXT("[QuestActions] %d\n"), ActionsMap.Num()));
		for (auto Kv : ActionsMap)
		{
			Output.Append(FString::Printf(TEXT("%s:%s\n"), *Kv.Key, *Kv.Value));
		}
		FilePath = FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("QuestEditor/QuestActions.txt"));
		AbsolutePath = FPaths::ConvertRelativePathToFull(FilePath);
		FFileHelper::SaveStringToFile(Output, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly);
	}));

FAutoConsoleCommand KGExportActionParams(
	TEXT("KGQuest.ExportActionParams"),
	TEXT("KGQuest.ExportActionParams"),
	FConsoleCommandWithArgsDelegate::CreateLambda([](const TArray<FString>& Args)
	{
		FString BPFilePath = TEXT("/Game/Editor/QuestEditor/TemplatePart/QuestActions");
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

		FARFilter Filter;
		Filter.PackagePaths.Add(*BPFilePath);
		Filter.ClassPaths.Add(UBlueprint::StaticClass()->GetClassPathName());
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;
		
		TArray<FAssetData> AssetDataList;
		AssetRegistry.GetAssets(Filter, AssetDataList);
		FString Output;
		FString Header = FString::Printf(TEXT("蓝图资源名,中文显示名,编号"));
		for (int32 i = 1; i < 11; i++)
		{
			Header += FString::Printf(TEXT(",参数%d,参数%d类型,参数%d默认值"), i, i, i);
		}
		Header += "\n";
		Output.Append(Header);
		
		for (auto Asset : AssetDataList)
		{
			if (UBlueprint* BPObj = Cast<UBlueprint>(Asset.GetAsset()))
			{
				UClass* BPClass = BPObj->GeneratedClass;
				if (BPClass->IsChildOf(UQuestActionBase::StaticClass()))
				{
					UQuestActionBase* CDO = Cast<UQuestActionBase>(BPClass->GetDefaultObject());
					FString Line = FString::Format(TEXT("{0},{1},{2}"),
						{
							Asset.AssetName.ToString(),
							BPObj->BlueprintDisplayName,
							CDO->Event
						});
					for (TFieldIterator<FProperty> PropIt(BPClass, EFieldIteratorFlags::ExcludeSuper); PropIt; ++PropIt)
					{
						FString DefaultValue;
						if (const void* ValuePtr = PropIt->ContainerPtrToValuePtr<void>(CDO))
						{
							PropIt->ExportTextItem_Direct(DefaultValue, ValuePtr, nullptr, nullptr, PPF_None);
						}
						FString PropType = PropIt->GetCPPType();
						if (FArrayProperty* ArrayProp = CastField<FArrayProperty>(*PropIt))
						{
							FProperty* ElementType = ArrayProp->Inner;
							PropType += FString::Printf(TEXT("(%s)"), *ElementType->GetCPPType());
						}
						Line += FString::Printf(TEXT(",%s,%s,\"%s\""), *PropIt->GetName(), *PropType, *DefaultValue);
					}
					Line += "\n";
					Output.Append(Line);
				}
			}
		}
		FString FilePath = FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("QuestEditor/QuestActionParams.csv"));
		FString AbsolutePath = FPaths::ConvertRelativePathToFull(FilePath);
		FFileHelper::SaveStringToFile(Output, *AbsolutePath, FFileHelper::EEncodingOptions::ForceUTF8, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly);
		
	}));
