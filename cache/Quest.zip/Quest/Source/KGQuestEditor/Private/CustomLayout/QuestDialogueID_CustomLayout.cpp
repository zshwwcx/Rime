#include "QuestDialogueID_CustomLayout.h"

#include "SIDConfigList.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "DialogueEditor/LuaAsset/LuaAssetHelper.h"

#define LOCTEXT_NAMESPACE "FQuestDialogueID_CustomLayout" 

void FQuestDialogueID_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	FDialogueID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SAssignNew(ValueHorizontalWidget, SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SAssignNew(IDPickerWidget, SIDPicker)
					.ActiveID(AsstIDPtr->ID)
					.OnSelectID(this, &FQuestDialogueID_CustomLayout::SetConfigID)
					.OnGetSourceData(this, &FQuestDialogueID_CustomLayout::GetDataSource)
					.OnSelectedInfo(this, &FQuestDialogueID_CustomLayout::GetSelectedInfo)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.Text(LOCTEXT("GetDialogueAssetButtonText", "GetDialogueAsset"))
				.OnClicked(this, &FQuestDialogueID_CustomLayout::OnGetDialogueAssetClicked)
			]
		];

}

void FQuestDialogueID_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}

void FQuestDialogueID_CustomLayout::GetDataSource(TArray<TSharedPtr<FString>>& OutData)
{
	TArray<TSharedPtr<FString>>* RetVal;
	FDialogueID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	AsstIDPtr->GetDataSource(RetVal);
	OutData = *RetVal;
}

void FQuestDialogueID_CustomLayout::SetConfigID(int32 InConfigID)
{
	FDialogueID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->ID != InConfigID)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->ID = InConfigID;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

void FQuestDialogueID_CustomLayout::GetSelectedInfo(FString String)
{
	FDialogueID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->AssetPath != String)
	{
		AsstIDPtr->AssetPath = String;
	}
}

FReply FQuestDialogueID_CustomLayout::OnGetDialogueAssetClicked()
{
	FDialogueID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr)
	{
		FLuaAssetHelper::OpenOrCreateDialogueByFileName(FString::FromInt(AsstIDPtr->ID));
		// auto AssetRegistry = IAssetRegistry::Get();
		// FString AssetPath = "/Game/Blueprint/DialogueSystem/DialogueAsset/";
		// FString AssetPathName = "/Game/Blueprint/DialogueSystem/DialogueAsset/" + AsstIDPtr->AssetPath;
		// TArray<FAssetData> FoundAssets;
		// AssetRegistry->GetAssetsByPath(FName(AssetPath), FoundAssets, true);
		// for (const FAssetData& AssetData : FoundAssets)
		// {
		// 	if (AssetData.GetSoftObjectPath().GetAssetPathString().Contains(AssetPathName))
		// 	{
		// 		UAssetEditorSubsystem* AssetEditorSubsystem = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
		// 		AssetEditorSubsystem->OpenEditorForAsset(AssetData.GetAsset());
		// 		break;
		// 	}
		// }
	}
	return FReply::Handled();
}


FDialogueID* FQuestDialogueID_CustomLayout::GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FDialogueID*>(RawData);

	return NULL;
}

#undef LOCTEXT_NAMESPACE 
