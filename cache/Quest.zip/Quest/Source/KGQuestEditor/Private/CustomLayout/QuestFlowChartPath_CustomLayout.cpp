#include "QuestFlowChartPath_CustomLayout.h"

#include "SFlowCharPath.h"

#define LOCTEXT_NAMESPACE "QuestEditorModule"

void FFlowChartPath_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	FFlowChartPath* AssetPtr = GetProperty(PropertyHandle.ToSharedRef());
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SAssignNew(ValueHorizontalWidget, SHorizontalBox)
			+ SHorizontalBox::Slot()
			[
				SAssignNew(FlowChartPathWidget, SFlowChartPath)
				.CurrentPath(AssetPtr->Path)
				.OnTextChanged(this, &FFlowChartPath_CustomLayout::OnTextChanged)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.Text(LOCTEXT("FlowChartPathButton", "Edit target map"))
				.OnClicked_Raw(this, &FFlowChartPath_CustomLayout::OnButtonClicked)
			]
		];

}

FReply FFlowChartPath_CustomLayout::OnButtonClicked()
{
	const FFlowChartPath* AssetPtr = GetProperty(PropertyHandle.ToSharedRef());
	if (AssetPtr)
	{
		FString StringFlowToolPath = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir());
		FString ProjectXMLPath = StringFlowToolPath;
		ProjectXMLPath += "../../Tools/FlowChartTool/c7.xml";
		StringFlowToolPath += "../../Tools/FlowChartTool/FlowChartTool.exe";
		FString Params = ProjectXMLPath + " " + AssetPtr->Path;
		
		uint32* ID = 0;

		FPlatformProcess::CreateProc(*StringFlowToolPath, *Params, true, false, false, ID, 0, nullptr, nullptr);
	}

	return FReply::Handled();
}

void FFlowChartPath_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}

void FFlowChartPath_CustomLayout::OnTextChanged(const FText& NewText)
{
	FFlowChartPath* AssetPtr = GetProperty(PropertyHandle.ToSharedRef());
	if (AssetPtr)
	{
		PropertyHandle->NotifyPreChange();
		AssetPtr->Path = NewText.ToString();
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

FFlowChartPath* FFlowChartPath_CustomLayout::GetProperty(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FFlowChartPath*>(RawData);

	return NULL;
}

#undef LOCTEXT_NAMESPACE