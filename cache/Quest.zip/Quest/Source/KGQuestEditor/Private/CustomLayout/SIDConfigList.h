﻿#pragma once

#include "SSearchableComboBox.h"
#include "Widgets/Input/SNumericEntryBox.h"
#include "PropertyCustomizationHelpers.h"
#include "QuestTemplate.h"

class SIDPicker : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnSelectedEvent, int32);
	DECLARE_DELEGATE_OneParam(FOnSelectedEventInfo, FString);
	DECLARE_DELEGATE_OneParam(FOnGetSourceData, TArray<TSharedPtr<FString>>&);
	
public:
	SLATE_BEGIN_ARGS(SIDPicker) : _ActiveID(0) {}
		SLATE_ARGUMENT(int32, ActiveID)
		SLATE_EVENT(FOnSelectedEvent, OnSelectID)
		SLATE_EVENT(FOnGetSourceData, OnGetSourceData)
		SLATE_EVENT(FOnSelectedEventInfo, OnSelectedInfo)
	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs)
	{
		this->ActiveID = InArgs._ActiveID;
		this->OnSelectID = InArgs._OnSelectID;
		this->OnSelectedEventInfo = InArgs._OnSelectedInfo;
		this->OnGetSourceData = InArgs._OnGetSourceData;
		
		InitConfigDisplay();

		this->ChildSlot
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				[
					SAssignNew(UserDefinedIDBox, SEditableTextBox)
					.Text(this, &SIDPicker::GetSelectedConfigIDName)
					.OnTextCommitted(this, &SIDPicker::OnUserDefinedTextCommitted)
				]
				
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Fill)
				.Padding(0)
				[
					SAssignNew(ConfigIDSearchComboBox, SSearchableComboBox)
						.OptionsSource(&OutIDMap)
						.OnGenerateWidget(this, &SIDPicker::MakeConfigIDWidget)
						.OnSelectionChanged(this, &SIDPicker::OnSelectionConfigIDChanged)
						.OnComboBoxOpening(this, &SIDPicker::OnConfigIDComboBoxOpened)
						[
							SNew(STextBlock)
								.Text(this, &SIDPicker::GetSelectedConfigIDName)
						]
				]
			];
	}

	void InitConfigDisplay()
	{
		OnGetSourceData.Execute(OutIDMap);
		if (ActiveID == 0)
		{
			CurrentSelectedConfigIDName = nullptr;
			return;
		}
		FString IDString = FString::FromInt(ActiveID);
		IDString += " ";
		for(auto String : OutIDMap)
		{
			if(String.IsValid() && String->Contains(IDString))
			{
				CurrentSelectedConfigIDName = String;
				OnSelectionConfigIDChanged(String, ESelectInfo::Type::Direct);
				break;
			}
		}
		if (!CurrentSelectedConfigIDName)
		{
			CurrentSelectedConfigIDName = MakeShareable(new FString(IDString));;
		}
	}

	TSharedRef<SWidget> MakeConfigIDWidget(TSharedPtr<FString> StringItem)
	{
		return SNew(STextBlock).Text(FText::FromString(*StringItem));
	}

	void OnUserDefinedTextCommitted(const FText& InText, ETextCommit::Type InCommitType)
	{
		auto StringItem = InText.ToString();
		for(auto String : OutIDMap)
		{
			if(String.IsValid() && String->Contains(StringItem))
			{
				OnSelectionConfigIDChanged(String, ESelectInfo::Type::Direct);
				return;
			}
		}
		StringItem += " ";
		OnSelectionConfigIDChanged(MakeShareable(new FString(StringItem)), ESelectInfo::Type::Direct);
	}
	
	void OnSelectionConfigIDChanged(TSharedPtr<FString> StringItem, ESelectInfo::Type SelectInfo)
	{
		if (StringItem.IsValid())
		{
			int32 SelectedID = 0;
			FString NumberString;
			FString SpecifierString;
			StringItem->Split(" ", &NumberString, &SpecifierString);
			if(NumberString.IsNumeric())
			{
				SelectedID = FCString::Atoi(*NumberString);
			}
			CurrentSelectedConfigIDName = StringItem;

			OnSelectID.ExecuteIfBound(SelectedID);
			OnSelectedEventInfo.ExecuteIfBound(SpecifierString);
		}
		// ConfigIDSearchComboBox->ClearSelection();
	}
	
	void OnSelectedConfigID(FString ID, FString BTName)
	{
		
	}
	
	void OnConfigIDComboBoxOpened()
	{
		//auto RawSource = OnGetSourceData.Execute();
		//OutIDMap = *static_cast<TArray<TSharedPtr<FString>>*>(RawSource);
	}

	FText GetSelectedConfigIDName() const
	{
		if(CurrentSelectedConfigIDName.IsValid())
		{
			FString IDStr;
			CurrentSelectedConfigIDName->Split(" ", &IDStr, nullptr);
			return FText::FromString(IDStr);
		}
		return FText();
	}

protected:

	TArray<TSharedPtr<FString>> OutIDMap;
	
	TSharedPtr<FString> CurrentSelectedConfigIDName;

	TSharedPtr<SEditableTextBox> UserDefinedIDBox;
	TSharedPtr<SSearchableComboBox> ConfigIDSearchComboBox;
	
	FOnSelectedEvent OnSelectID;
	FOnSelectedEventInfo OnSelectedEventInfo;
	FOnGetSourceData OnGetSourceData;

	int32 ActiveID = 0;
};
