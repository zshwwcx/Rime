#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "Templates/SharedPointer.h"

class FFlowChartPath_CustomLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FFlowChartPath_CustomLayout());
	}

	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) override;

	FReply OnButtonClicked();
	void OnTextChanged(const FText& NewText);
	struct FFlowChartPath* GetProperty(TSharedRef<IPropertyHandle> InPropertyHandle);
protected:
	TSharedPtr<IPropertyHandle> PropertyHandle;

	TSharedPtr<class SFlowChartPath> FlowChartPathWidget;
	TSharedPtr<class SHorizontalBox> ValueHorizontalWidget;
};

