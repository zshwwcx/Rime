﻿#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "Templates/SharedPointer.h"

class FQuestMonsterID_CustomLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FQuestMonsterID_CustomLayout());
	}

	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) override;

	void GetDataSource(TArray<TSharedPtr<FString>>& OutData);
	void SetConfigID(int32 InConfigID);
	void SetConfigName(FString InConfigName);
	static FText GetMonsterName(TSharedRef<IPropertyHandle> PropertyHandle);
	static struct FMonsterID* GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle);
protected:
	TSharedPtr<IPropertyHandle> PropertyHandle;

	TSharedPtr<class SIDPicker> IDPickerWidget;
	TSharedPtr<class SHorizontalBox> ValueHorizontalWidget;
};

