// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com


#include "QuestOptionTextID_CustomLayout.h"
#include "SIDConfigList.h"
#include "QuestTemplate.h"


#define LOCTEXT_NAMESPACE "FQuestOptionTextID_CustomLayout" 

void FQuestOptionTextID_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	FOptionTextID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SAssignNew(ValueHorizontalWidget, SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SAssignNew(IDPickerWidget, SIDPicker)
						.ActiveID(AsstIDPtr->ID)
						.OnSelectID(this, &FQuestOptionTextID_CustomLayout::SetConfigID)
						.OnGetSourceData(this, &FQuestOptionTextID_CustomLayout::GetDataSource)
						.OnSelectedInfo(this, &FQuestOptionTextID_CustomLayout::SetConfigName)
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
						.Text_Static(&FQuestOptionTextID_CustomLayout::GetTextName, PropertyHandle.ToSharedRef())
				]
		];

}

void FQuestOptionTextID_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{

}

void FQuestOptionTextID_CustomLayout::GetDataSource(TArray<TSharedPtr<FString>>& OutData)
{
	TArray<TSharedPtr<FString>>* RetVal;
	FOptionTextID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	AsstIDPtr->GetDataSource(RetVal);
	OutData = *RetVal;
}

void FQuestOptionTextID_CustomLayout::SetConfigID(int32 InConfigID)
{
	FOptionTextID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->ID != InConfigID)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->ID = InConfigID;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

void FQuestOptionTextID_CustomLayout::SetConfigName(FString InConfigName)
{
	FOptionTextID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->OptionText != InConfigName)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->OptionText = InConfigName;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

FText FQuestOptionTextID_CustomLayout::GetTextName(TSharedRef<IPropertyHandle> PropertyHandle)
{
	FOptionTextID* AssetIDPtr = GetPropertyID(PropertyHandle);
	if (AssetIDPtr)
	{
		return FText::FromString(AssetIDPtr->OptionText);
	}
	else
	{
		return FText::FromString("");
	}
}

FOptionTextID* FQuestOptionTextID_CustomLayout::GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FOptionTextID*>(RawData);

	return NULL;
}

#undef LOCTEXT_NAMESPACE