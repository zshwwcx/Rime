﻿#include "QuestTaskCollectID_CustomLayout.h"

#include "SIDConfigList.h"

void FQuestTaskCollectID_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	FTaskCollectID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SAssignNew(ValueHorizontalWidget, SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SAssignNew(IDPickerWidget, SIDPicker)
					.ActiveID(AsstIDPtr->ID)
					.OnSelectID(this, &FQuestTaskCollectID_CustomLayout::SetConfigID)
					.OnGetSourceData(this, &FQuestTaskCollectID_CustomLayout::GetDataSource)
					.OnSelectedInfo(this, &FQuestTaskCollectID_CustomLayout::SetConfigName)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(STextBlock)
				.Text_Static(&FQuestTaskCollectID_CustomLayout::GetTaskCollectName, PropertyHandle.ToSharedRef())
			]
		];

}

void FQuestTaskCollectID_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}

void FQuestTaskCollectID_CustomLayout::GetDataSource(TArray<TSharedPtr<FString>>& OutData)
{
	TArray<TSharedPtr<FString>>* RetVal;
	FTaskCollectID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	AsstIDPtr->GetDataSource(RetVal);
	OutData = *RetVal;
}

void FQuestTaskCollectID_CustomLayout::SetConfigID(int32 InConfigID)
{
	FTaskCollectID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->ID != InConfigID)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->ID = InConfigID;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

void FQuestTaskCollectID_CustomLayout::SetConfigName(FString InConfigName)
{
	FTaskCollectID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->TaskCollectName != InConfigName)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->TaskCollectName = InConfigName;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

FText FQuestTaskCollectID_CustomLayout::GetTaskCollectName(TSharedRef<IPropertyHandle> PropertyHandle)
{
	FTaskCollectID* AsstIDPtr = GetPropertyID(PropertyHandle);
	if (AsstIDPtr)
	{
		return FText::FromString(AsstIDPtr->TaskCollectName);
	}
	else
	{
		return FText::FromString("");
	}
}

FTaskCollectID* FQuestTaskCollectID_CustomLayout::GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FTaskCollectID*>(RawData);

	return NULL;
}
