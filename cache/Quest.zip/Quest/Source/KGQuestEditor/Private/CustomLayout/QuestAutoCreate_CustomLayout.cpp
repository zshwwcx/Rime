#include "QuestAutoCreate_CustomLayout.h"
#include "QuestAutoCreate.h"
#include "QuestTemplate.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SButton.h"

UE_DISABLE_OPTIMIZATION_SHIP

#define LOCTEXT_NAMESPACE "FQuestAutoCreate_CustomLayout"

FQuestAutoCreate* GetPropertyIsAutoCreate(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FQuestAutoCreate*>(RawData);

	return NULL;
}

FReply FQuestAutoCreate_CustomLayout::AutoCreateOnClick(TSharedRef<IPropertyHandle> InStructPropertyHandle, bool IsAutoCreate)
{
	if (InStructPropertyHandle->IsValidHandle())
	{
		TArray<UObject*> OuterObjects;
		InStructPropertyHandle->GetOuterObjects(OuterObjects);
		if (OuterObjects.Num() == 1)
		{
			if (UQuestTargetBase* TargetAction = Cast<UQuestTargetBase>(OuterObjects[0]))
				TargetAction->OnAutoCreateNode();
		}
	}
	
	return FReply::Handled();
}


void FQuestAutoCreate_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InStructPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{

}


void FQuestAutoCreate_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InStructPropertyHandle, IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	if (InStructPropertyHandle->IsValidHandle())
	{

		FQuestAutoCreate* Data = GetPropertyIsAutoCreate(InStructPropertyHandle);

		if (!Data)
		{
			return;
		}

		StructBuilder.AddCustomRow(LOCTEXT("CreateNode", "CreateNode"))
			.NameContent()
			[
				SNew(STextBlock)
					.Text(FText::FromString(TEXT("CreateNode")))
					.Font(IDetailLayoutBuilder::GetDetailFont())
			]
			.ValueContent()
			[
				SNew(SButton)
					.OnClicked(this, &FQuestAutoCreate_CustomLayout::AutoCreateOnClick, InStructPropertyHandle, Data->GetIsAutoCreate())
					.ContentPadding(FMargin(2))
					.Content()
					[
						SNew(STextBlock)
							.Justification(ETextJustify::Center)
							.Text(LOCTEXT("CreateNode", "CreateNode"))
					]
			];
	}
}


#undef LOCTEXT_NAMESPACE

UE_ENABLE_OPTIMIZATION_SHIP