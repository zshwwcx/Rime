#include "QuestItemID_CustomLayout.h"

#include "SIDConfigList.h"

void FQuestItemID_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	FItemID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SAssignNew(ValueHorizontalWidget, SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SAssignNew(IDPickerWidget, SIDPicker)
					.ActiveID(AsstIDPtr->ID)
					.OnSelectID(this, &FQuestItemID_CustomLayout::SetConfigID)
					.OnGetSourceData(this, &FQuestItemID_CustomLayout::GetDataSource)
					.OnSelectedInfo(this, &FQuestItemID_CustomLayout::SetConfigName)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(STextBlock)
				.Text_Static(&FQuestItemID_CustomLayout::GetItemName, PropertyHandle.ToSharedRef())
			]
		];

}

void FQuestItemID_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}

void FQuestItemID_CustomLayout::GetDataSource(TArray<TSharedPtr<FString>>& OutData)
{
	TArray<TSharedPtr<FString>>* RetVal;
	FItemID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	AsstIDPtr->GetDataSource(RetVal);
	OutData = *RetVal;
}

void FQuestItemID_CustomLayout::SetConfigID(int32 InConfigID)
{
	FItemID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->ID != InConfigID)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->ID = InConfigID;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

void FQuestItemID_CustomLayout::SetConfigName(FString InConfigName)
{
	FItemID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->ItemName != InConfigName)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->ItemName = InConfigName;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

FText FQuestItemID_CustomLayout::GetItemName(TSharedRef<IPropertyHandle> PropertyHandle)
{
	FItemID* AsstIDPtr = GetPropertyID(PropertyHandle);
	if (AsstIDPtr)
	{
		return FText::FromString(AsstIDPtr->ItemName);
	}
	else
	{
		return FText::FromString("");
	}
}

FItemID* FQuestItemID_CustomLayout::GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FItemID*>(RawData);

	return NULL;
}
