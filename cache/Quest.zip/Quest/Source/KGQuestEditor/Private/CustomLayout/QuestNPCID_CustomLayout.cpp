﻿#include "QuestNPCID_CustomLayout.h"

#include "SIDConfigList.h"

#define LOCTEXT_NAMESPACE "FQuestNPCID_CustomLayout" 

void FQuestNPCID_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	FNPCID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SAssignNew(ValueHorizontalWidget, SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SAssignNew(IDPickerWidget, SIDPicker)
					.ActiveID(AsstIDPtr->ID)
					.OnSelectID(this, &FQuestNPCID_CustomLayout::SetConfigID)
					.OnGetSourceData(this, &FQuestNPCID_CustomLayout::GetDataSource)
					.OnSelectedInfo(this, &FQuestNPCID_CustomLayout::SetConfigName)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SSpacer)
				.Size(FVector2D(8.f, 8.f))
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			[
				SNew(STextBlock)
				.Text_Static(&FQuestNPCID_CustomLayout::GetNPCName, PropertyHandle.ToSharedRef())
			]
		];

}

void FQuestNPCID_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}

void FQuestNPCID_CustomLayout::GetDataSource(TArray<TSharedPtr<FString>>& OutData)
{
	TArray<TSharedPtr<FString>>* RetVal;
	FNPCID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	AsstIDPtr->GetDataSource(RetVal);
	OutData = *RetVal;
}

void FQuestNPCID_CustomLayout::SetConfigID(int32 InConfigID)
{
	FNPCID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->ID != InConfigID)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->ID = InConfigID;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

void FQuestNPCID_CustomLayout::SetConfigName(FString InConfigName)
{
	FNPCID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->NPCName != InConfigName)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->NPCName = InConfigName;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

FText FQuestNPCID_CustomLayout::GetNPCName(TSharedRef<IPropertyHandle> PropertyHandle)
{
	FNPCID* AsstIDPtr = GetPropertyID(PropertyHandle);
	if (AsstIDPtr)
	{
		return FText::FromString(AsstIDPtr->NPCName);
	}
	else
	{
		return FText::FromString("");
	}
}

FNPCID* FQuestNPCID_CustomLayout::GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FNPCID*>(RawData);

	return NULL;
}

#undef LOCTEXT_NAMESPACE