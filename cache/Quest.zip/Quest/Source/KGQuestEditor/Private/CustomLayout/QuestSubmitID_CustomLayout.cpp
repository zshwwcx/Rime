﻿#include "QuestSubmitID_CustomLayout.h"

#include "SIDConfigList.h"

void FQuestSubmitID_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	FItemSubmitID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SAssignNew(ValueHorizontalWidget, SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SAssignNew(IDPickerWidget, SIDPicker)
					.ActiveID(AsstIDPtr->ID)
					.OnSelectID(this, &FQuestSubmitID_CustomLayout::SetConfigID)
					.OnGetSourceData(this, &FQuestSubmitID_CustomLayout::GetDataSource)
			]
		];

}

void FQuestSubmitID_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}

void FQuestSubmitID_CustomLayout::GetDataSource(TArray<TSharedPtr<FString>>& OutData)
{
	TArray<TSharedPtr<FString>>* RetVal;
	FItemSubmitID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	AsstIDPtr->GetDataSource(RetVal);
	OutData = *RetVal;
}

void FQuestSubmitID_CustomLayout::SetConfigID(int32 InConfigID)
{
	FItemSubmitID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->ID != InConfigID)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->ID = InConfigID;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

FItemSubmitID* FQuestSubmitID_CustomLayout::GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FItemSubmitID*>(RawData);

	return NULL;
}
