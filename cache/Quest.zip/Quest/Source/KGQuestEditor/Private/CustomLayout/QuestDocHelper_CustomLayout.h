#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "DetailWidgetRow.h"

#include "IDetailCustomization.h"
#include "Templates/SharedPointer.h"
#include "DetailLayoutBuilder.h"
#include "IDetailChildrenBuilder.h"

class FQuestDocHelper_CustomLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FQuestDocHelper_CustomLayout());
	}

	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) override;

	FReply OpenUrlOnClick(FString Url);

protected:
	TSharedPtr<IPropertyHandle> PropertyHandle;

};

