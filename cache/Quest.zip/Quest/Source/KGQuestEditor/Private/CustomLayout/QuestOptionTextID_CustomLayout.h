// Copyright Kuaishou Games, Inc. All Rights Reserved.
// Author: pengqi05@kuaishou.com

#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "DetailWidgetRow.h"

#include "IDetailCustomization.h"
#include "Templates/SharedPointer.h"
#include "DetailLayoutBuilder.h"
#include "IDetailChildrenBuilder.h"

/**
 * 主线任务剧情对话选项ID
 */
class FQuestOptionTextID_CustomLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FQuestOptionTextID_CustomLayout());
	}

	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils);

	void GetDataSource(TArray<TSharedPtr<FString>>& OutData);
	void SetConfigID(int32 InConfigID);
	void SetConfigName(FString InConfigName);
	static FText GetTextName(TSharedRef<IPropertyHandle> PropertyHandle);
	static struct FOptionTextID* GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle);
protected:
	TSharedPtr<IPropertyHandle> PropertyHandle;

	TSharedPtr<class SIDPicker> IDPickerWidget;
	TSharedPtr<class SHorizontalBox> ValueHorizontalWidget;
};
