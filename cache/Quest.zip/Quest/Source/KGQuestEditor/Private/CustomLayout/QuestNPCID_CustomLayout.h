﻿#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "DetailWidgetRow.h"

#include "IDetailCustomization.h"
#include "Templates/SharedPointer.h"
#include "DetailLayoutBuilder.h"
#include "IDetailChildrenBuilder.h"

class FQuestNPCID_CustomLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FQuestNPCID_CustomLayout());
	}

	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils);
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils);

	void GetDataSource(TArray<TSharedPtr<FString>>& OutData);
	void SetConfigID(int32 InConfigID);
	void SetConfigName(FString InConfigName);
	static FText GetNPCName(TSharedRef<IPropertyHandle> PropertyHandle);
	static struct FNPCID* GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle);
protected:
	TSharedPtr<IPropertyHandle> PropertyHandle;

	TSharedPtr<class SIDPicker> IDPickerWidget;
	TSharedPtr<class SHorizontalBox> ValueHorizontalWidget;
};

