#pragma once

#include "SSearchableComboBox.h"
#include "Widgets/Input/SNumericEntryBox.h"
#include "PropertyCustomizationHelpers.h"
#include "QuestTemplate.h"

class SFlowChartPath : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnChangedEvent, const FText&);
	
public:
	SLATE_BEGIN_ARGS(SFlowChartPath) : _CurrentPath("") {}
		SLATE_ARGUMENT(FString, CurrentPath)
		SLATE_EVENT(FOnChangedEvent, OnTextChanged)
	SLATE_END_ARGS()

public:
	void Construct(const FArguments& InArgs)
	{
		this->OnTextChanged = InArgs._OnTextChanged;
		this->CurrentPath = InArgs._CurrentPath;
		this->ChildSlot
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.Padding(0)
			[
				SAssignNew(TextBox, SEditableTextBox)
				.Text(FText::FromString(this->CurrentPath))
				.OnTextChanged(this->OnTextChanged)
			]
		];
	}

protected:
	
	TSharedPtr<SEditableTextBox> TextBox;
	
	FOnChangedEvent OnTextChanged;

	FString CurrentPath = "";
};