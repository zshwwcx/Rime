﻿#include "QuestMonsterID_CustomLayout.h"

#include "SIDConfigList.h"

void FQuestMonsterID_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	PropertyHandle = InPropertyHandle;
	FMonsterID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	HeaderRow
		.NameContent()
		[
			PropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SAssignNew(ValueHorizontalWidget, SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SAssignNew(IDPickerWidget, SIDPicker)
					.ActiveID(AsstIDPtr->ID)
					.OnSelectID(this, &FQuestMonsterID_CustomLayout::SetConfigID)
					.OnGetSourceData(this, &FQuestMonsterID_CustomLayout::GetDataSource)
					.OnSelectedInfo(this, &FQuestMonsterID_CustomLayout::SetConfigName)
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(STextBlock)
				.Text_Static(&FQuestMonsterID_CustomLayout::GetMonsterName, PropertyHandle.ToSharedRef())
			]
		];

}

void FQuestMonsterID_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}

void FQuestMonsterID_CustomLayout::GetDataSource(TArray<TSharedPtr<FString>>& OutData)
{
	TArray<TSharedPtr<FString>>* RetVal;
	FMonsterID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	AsstIDPtr->GetDataSource(RetVal);
	OutData = *RetVal;
}

void FQuestMonsterID_CustomLayout::SetConfigID(int32 InConfigID)
{
	FMonsterID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->ID != InConfigID)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->ID = InConfigID;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

void FQuestMonsterID_CustomLayout::SetConfigName(FString InConfigName)
{
	FMonsterID* AsstIDPtr = GetPropertyID(PropertyHandle.ToSharedRef());
	if (AsstIDPtr && AsstIDPtr->MonsterName != InConfigName)
	{
		PropertyHandle->NotifyPreChange();
		AsstIDPtr->MonsterName = InConfigName;
		PropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
	}
}

FText FQuestMonsterID_CustomLayout::GetMonsterName(TSharedRef<IPropertyHandle> PropertyHandle)
{
	FMonsterID* AsstIDPtr = GetPropertyID(PropertyHandle);
	if (AsstIDPtr)
	{
		return FText::FromString(AsstIDPtr->MonsterName);
	}
	else
	{
		return FText::FromString("");
	}
}

FMonsterID* FQuestMonsterID_CustomLayout::GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FMonsterID*>(RawData);

	return NULL;
}
