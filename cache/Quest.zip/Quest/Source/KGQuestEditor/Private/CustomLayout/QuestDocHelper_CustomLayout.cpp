#include "QuestDocHelper_CustomLayout.h"
#include "QuestDocHelper.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SButton.h"

#define LOCTEXT_NAMESPACE "FQuestDocHelper_CustomLayout"

FQuestDocHelper* GetPropertyUrl(TSharedRef<IPropertyHandle> InPropertyHandle)
{
	void* RawData = NULL;
	InPropertyHandle->GetValueData(RawData);

	if (RawData)
		return static_cast<FQuestDocHelper*>(RawData);

	return NULL;
}

FReply FQuestDocHelper_CustomLayout::OpenUrlOnClick(FString Url)
{
	FPlatformProcess::LaunchURL(*Url, NULL, NULL);

	return FReply::Unhandled();
}


void FQuestDocHelper_CustomLayout::CustomizeHeader(TSharedRef<IPropertyHandle> InStructPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{

}


void FQuestDocHelper_CustomLayout::CustomizeChildren(TSharedRef<IPropertyHandle> InStructPropertyHandle, IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	if (InStructPropertyHandle->IsValidHandle())
	{

		FQuestDocHelper* Data = GetPropertyUrl(InStructPropertyHandle);

		if (!Data)
		{
			return;
		}

		StructBuilder.AddCustomRow(LOCTEXT("Doc", "Doc"))
			.NameContent()
			[
				SNew(STextBlock)
					.Text(FText::FromString(TEXT("Doc")))
					.Font(IDetailLayoutBuilder::GetDetailFont())
			]
			.ValueContent()
			[
				SNew(SButton)
					.OnClicked(this, &FQuestDocHelper_CustomLayout::OpenUrlOnClick, Data->GetUrl())
					.ContentPadding(FMargin(2))
					.Content()
					[
						SNew(STextBlock)
							.Justification(ETextJustify::Center)
							.Text(LOCTEXT("Doc", "Doc"))
					]
			];

		uint32 NumChildren = 0;
		InStructPropertyHandle->GetNumChildren(NumChildren);

		for (uint32 ChildIndex = 0; ChildIndex < NumChildren; ChildIndex++)
		{
			StructBuilder.AddProperty(InStructPropertyHandle->GetChildHandle(ChildIndex).ToSharedRef());
		}
	}
}


#undef LOCTEXT_NAMESPACE