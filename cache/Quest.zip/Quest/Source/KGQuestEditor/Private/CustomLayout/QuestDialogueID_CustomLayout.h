﻿#pragma once

#include "CoreMinimal.h"
#include "IPropertyTypeCustomization.h"
#include "DetailWidgetRow.h"

#include "IDetailCustomization.h"
#include "Templates/SharedPointer.h"
#include "DetailLayoutBuilder.h"
#include "IDetailChildrenBuilder.h"

class FQuestDialogueID_CustomLayout : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance()
	{
		return MakeShareable(new FQuestDialogueID_CustomLayout());
	}

	
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> InPropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) override;

	void GetDataSource(TArray<TSharedPtr<FString>>& OutData);
	void SetConfigID(int32 InConfigID);
	void GetSelectedInfo(FString String);
	FReply OnGetDialogueAssetClicked();
	struct FDialogueID* GetPropertyID(TSharedRef<IPropertyHandle> InPropertyHandle);
protected:
	TSharedPtr<IPropertyHandle> PropertyHandle;

	TSharedPtr<class SIDPicker> IDPickerWidget;
	TSharedPtr<class SHorizontalBox> ValueHorizontalWidget;
};

