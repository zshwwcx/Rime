﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "FQuestObjectivesEditor.h"
#include "QuestObjectDataEntity.generated.h"

/**
 * 
 */
UCLASS()
class KGQUESTEDITOR_API UQuestObjectDataEntity : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY()
	TArray<TObjectPtr<UQuestObject>> AllQuestObject;

	UPROPERTY()
	TArray<TObjectPtr<UQuestChapter>> AllChapters;

	UPROPERTY()
	TArray<TObjectPtr<UQuestRing>> AllQuestRings;

	UPROPERTY()
	TArray<TObjectPtr<UQuest>> AllQuests;

	UPROPERTY()
	TMap<int32, TObjectPtr<UQuestObject>> QuestObjectMap; // QuestObjectID to UQuestObject (chapter, ring, quest)

	UPROPERTY()
	TMap<int32, TObjectPtr<UQuestChapter>> ChapterMap;

	UPROPERTY()
	TMap<int32, TObjectPtr<UQuestRing>> RingMap;

	UPROPERTY()
	TMap<int32, TObjectPtr<UQuest>> QuestMap;

	UPROPERTY()
	TArray<TObjectPtr<UQuestObject>> QuestTypes;
	
	UPROPERTY()
	TArray<TObjectPtr<UQuestObject>> QuestObjectRootItems;

	UPROPERTY()
	TArray<TObjectPtr<UQuestChapter>> ChapterListItems;

	UPROPERTY()
	TArray<TObjectPtr<UQuestRing>> RingListItems;

	UPROPERTY()
	TArray<TObjectPtr<UQuest>> QuestListItems;

	UPROPERTY()
	TSet<TWeakObjectPtr<UQuestChapter>> DirtyChapters;

	UPROPERTY()
	TSet<TWeakObjectPtr<UQuestRing>> DirtyRings;

	UPROPERTY()
	TSet<TWeakObjectPtr<UQuest>> DirtyQuests;

	UPROPERTY()
	TSet<TWeakObjectPtr<UQuestChapter>> DirtyCheckChapters;

	UPROPERTY()
	TSet<TWeakObjectPtr<UQuestRing>> DirtyCheckRings;

	UPROPERTY()
	TSet<TWeakObjectPtr<UQuest>> DirtyCheckQuests;
	
	UPROPERTY()
	TArray<TWeakObjectPtr<UQuestObject>> PendingDeleteObjects;

	UPROPERTY()
	TArray<TObjectPtr<UChapterEnd>> ChapterEnds;

	UPROPERTY()
	TArray<TObjectPtr<UQuestObject>> PasteBuffer;

	// Key:New Value:Old
	UPROPERTY()
	TMap<int32, int32> CopiedMapping;

	// Key:Old Value:New
	UPROPERTY()
	TMap<int32, int32> RevCopiedMapping;
};
