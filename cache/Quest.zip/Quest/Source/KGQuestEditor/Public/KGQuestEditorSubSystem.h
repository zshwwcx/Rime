// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EditorSubsystem.h"

#include "QuestTemplate.h"
#include "Action/QuestAction.h"
#include "KGQuestEditorSubSystem.generated.h"

class UQuestChapter;
class UQuestRing;
class UQuest;

/**
 * 
 */
UCLASS()
class KGQUESTEDITOR_API UKGQuestEditorSubSystem : public UEditorSubsystem
{
	GENERATED_BODY()

public:
	static UKGQuestEditorSubSystem& Get();
	static UKGQuestEditorSubSystem* GetPtr();

	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	void ShutDownLuaState();
	TArray<TSharedPtr<FString>>* GetDialogueIDData();
	TArray<TSharedPtr<FString>>* GetNPCIDData();
	TArray<TSharedPtr<FString>>* GetItemIDData();
	TArray<TSharedPtr<FString>>* GetTaskCollectData();
	TArray<TSharedPtr<FString>>* GetMonsterIDData();
	TArray<TSharedPtr<FString>>* GetItemSubmitIDData();
	TArray<TSharedPtr<FString>>* GetOptionTextIDData();
	
	FString GetAnimAssetID(const FString& InstanceID);

	// Quest Data Check
	TArray<FString> DataCheck(const TArray<UQuestChapter*>& CheckChapters, const TArray<UQuestRing*>& CheckRings, const TArray<UQuest*>& CheckQuests);

	int32 GetQuestSubTargetMaxNumber();

	void GetSystemActionDefine(TArray<FSystemActionDefine>& OutActionDefine);

	void InitializeQuestActionClasses();
	
private:
	void CreateQuestEditorLuaObj(class UWorld* InWorld);

private:
	void DataCheckLua(TArray<FString>& WarningMsgs, const TArray<UQuestChapter*>& CheckChapters, const TArray<UQuestRing*>& CheckRings, const TArray<UQuest*>& CheckQuests);
	void DataCheckCpp(TArray<FString>& WarningMsgs, const TArray<UQuestChapter*>& CheckChapters, const TArray<UQuestRing*>& CheckRings, const TArray<UQuest*>& CheckQuests);

public:
	// config
	TArray<FString> ChapterToRingProperties;

	const TMap<FString, UClass*>& GetSystemActionClassList() const {return QuestActionClassList;} 

private:
    class UEditorLuaEnv *LuaEnv = nullptr;
	TWeakObjectPtr<class UQuestEditorLuaObj> QuestEditorLuaObj;
	
	TArray<TSharedPtr<FString>> CachedDialogueIDData;
	TArray<TSharedPtr<FString>> CachedNPCIDData;
	TArray<TSharedPtr<FString>> CachedItemIDData;
	TArray<TSharedPtr<FString>> CachedTaskCollectIDData;
	TArray<TSharedPtr<FString>> CachedMonsterIDData;
	TArray<TSharedPtr<FString>> CachedItemSubmitIDData;
	TArray<TSharedPtr<FString>> CachedOptionTextIDData;

	bool bQuestActionClassesInitialized = false;
	
	UPROPERTY(Transient)
	TMap<FString, UClass*> QuestActionClassList;
};
