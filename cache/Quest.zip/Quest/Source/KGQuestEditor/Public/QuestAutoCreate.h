#pragma once


#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "QuestAutoCreate.generated.h"

//
USTRUCT(BlueprintType)
struct FQuestAutoCreate
{
	GENERATED_BODY()

	FQuestAutoCreate() {};

	FQuestAutoCreate(bool IsAutoCreate)
		:IsAutoCreate(IsAutoCreate)
	{};

public:
	bool GetIsAutoCreate()const { return IsAutoCreate; }

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	bool IsAutoCreate = true;
};