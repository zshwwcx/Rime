// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "UserQuest.h"
#include "UserQuestActionNode.h"
#include "UserSingleQuest.generated.h"

class UQuest;
/**
 * 记录单个任务动态信息与静态引用
 */
UCLASS(Blueprintable, BlueprintType)
class   UUserSingleQuest : public UUserQuest
{
	GENERATED_BODY()
//public:
//	virtual void InitQuest(UQuest* QuestTemplate, class  UUserQuest* Parent, class UQuestManager* missionMgr) override;
//	virtual void DestroyAll() override;
//
//
//	//获得组里指定任务ID的单个任务实例
//	UFUNCTION(BlueprintCallable)
//	UUserQuestActionNode* GetCurUserQuestActionNode(const FName& ActionNodeId);
//
//
//	//检查接受条件，并更新任务状态
//	virtual bool CheckAcceptCondition() override;
//	//检查完成接受条件，并更新任务状态
//	virtual bool CheckCompleteCondition() override;
//	//更新任务状态
//	virtual void UpdateQuestStatus() override;
//
//	//开始进行中的任务前的消息监听等工作
//	virtual void StartAcceptedQuest() override;
//protected:
//	//根据行动节点进度状态 ，更新当前运行中的行动节点
//	void UpdateRunningActionNode();
//
//public:
//	UFUNCTION(BlueprintCallable)
//	const FName GetSingleQuestId();
//	UFUNCTION(BlueprintCallable)
//	USingleQuest* GetSingleQuestTemplate();
//protected:
//	UPROPERTY(Transient)
//	TArray<UUserQuestActionNode*> UserQuestActionNodeArray;
//
//	UPROPERTY(Transient)
//	UUserQuestActionNode* CurRunningActionNode;
//	UPROPERTY(Transient)
//	int CurRunningIndex;
};
