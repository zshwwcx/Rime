// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "UserQuest.h"
#include "UserGroupQuest.generated.h"

class UUserSingleQuest;
class UUserGroupQuest;
/**
 * 记录单个任务组的动态信息和静态引用
 */
UCLASS(Blueprintable, BlueprintType)
class   UUserGroupQuest : public UUserQuest
{
	GENERATED_BODY()
//public:
//	virtual void InitQuest(UQuest* QuestTemplate, class  UUserQuest* Parent, class UQuestManager* missionMgr) override;
//	virtual void DestroyAll();
//
//	//检查接受条件，并更新任务状态
//	virtual bool CheckAcceptCondition() override;
//	//检查完成接受条件，并更新任务状态
//	virtual bool CheckCompleteCondition() override;
//	//更新任务状态
//	virtual void UpdateQuestStatus() override;
//	//virtual bool IsQuestComplete() override;
//public:
//
//public:
//	UFUNCTION(BlueprintCallable)
//	const FName GetGroupQuestId();
//
//	//获得组里指定任务ID的单个任务实例
//	UFUNCTION(BlueprintCallable)
//	UUserSingleQuest* GetUserSingleQuestInGroup(const FName& SingleQuestId);
//	
//	//获得组里指定子任务组ID的子组实例
//	UFUNCTION(BlueprintCallable)
//	UUserGroupQuest* GetChildUserGroupQuestInGroup(const FName& ChildGroupId);
//
//	UFUNCTION(BlueprintCallable)
//	UGroupQuestTemplate* GetGroupQuestTemplate() ;
//
//	bool CheckInChildUserGroupQuest(UGroupQuestTemplate* Template);
//
//	bool HasChildGroup = false;
//protected:
//	//当前任务组里包含的所有单个任务
//	UPROPERTY(Transient)
//	TArray<UUserSingleQuest*> UserSingleQuestArray;
//
//	//当前任务组包含的子任务组
//	UPROPERTY(Transient)
//	TArray<UUserGroupQuest*> ChildUserGroupQuestArray;
//
//	//UGroupQuestTemplate* GroupQuestTemplate;
};
