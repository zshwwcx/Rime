// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "UserQuest.h"
#include "UserQuestActionNode.generated.h"

class UQuestActionNode;
class UUserQuestCondition;
/**
 * 不同任务行动的记录信息的基类
 */
UCLASS(Blueprintable,BlueprintType)
class   UUserQuestActionNode : public UUserQuest
{
	GENERATED_BODY()
//public:
//	virtual void InitQuest(UQuest* QuestTemp, class  UUserQuest* Parent, class UQuestManager* missionMgr) ;
//	virtual void DestroyAll();
//	//更新任务状态
//	virtual void UpdateQuestStatus() override;
//public:
//
//	UFUNCTION(BlueprintCallable)
//	const FName GetActionNodeId();
//	////更新任务状态
//	// void UpdateQuestStatus() ;
//	////是否完成任务行为节点
//	//bool IsCompleteQuestAction();
//public://蓝图
//	UFUNCTION(BlueprintCallable)
//	UQuestActionNode* GetQuestActionNodeTemplate();
//
//
//private:
//

};
