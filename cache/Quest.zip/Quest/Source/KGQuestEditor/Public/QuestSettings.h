#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "UObject/SoftObjectPath.h"
#include "QuestSettings.generated.h"


UCLASS(Config = Editor, meta = (DisplayName = "QuestSettings"), DefaultConfig)
class UQuestSettings : public UDeveloperSettings
{
	GENERATED_BODY()
public:
	//环条件
	UPROPERTY(EditAnywhere, Config, Category = "Ring")
	FSoftObjectPath RingConditionClass;
	//任务成功条件
	UPROPERTY(EditAnywhere, Config, Category = "Quest")
	FSoftObjectPath QuestSuccessConditionClass;
	//单个任务数据
	UPROPERTY(EditAnywhere, Config, Category = "Quest")
	FSoftObjectPath QuestDataBP;
	//单个任务条件
	UPROPERTY(EditAnywhere, Config, Category = "Quest")
	FSoftObjectPath ActionConditionBaseClass;
	//新建任务窗口
	UPROPERTY(EditAnywhere, Config, Category = "Quest")
	bool bCreateQuestDialogue;
	//单个环数据
	UPROPERTY(EditAnywhere, Config, Category = "Ring")
	FSoftObjectPath RingDataBP;
	//新建环窗口
	UPROPERTY(EditAnywhere, Config, Category = "Ring")
	bool bCreateRingDialogue;
	//跳转自动设置的接取方式
	UPROPERTY(EditAnywhere, Config, Category = "Ring")
	FSoftObjectPath TransitionApplyType;
	//单个章节数据
	UPROPERTY(EditAnywhere, Config, Category = "Chapter")
	FSoftObjectPath ChapterDataBP;
	//新建章节窗口
	UPROPERTY(EditAnywhere, Config, Category = "Chapter")
	bool bCreateChapterDialogue;
	// Pure Lua
	UPROPERTY(EditAnywhere, Config, Category = "Test")
	bool bLuaVersion = false;
	//隐藏旧界面
	UPROPERTY(EditAnywhere, Config, Category = "Test")
	bool bShowDeprecatedWindow = false;
	// 保存 Quest 数据到 Ring 内，并优先从 Ring 内读 Quest 数据
	UPROPERTY(EditAnywhere, Config, Category = "Test")
	bool bSaveAndLoadQuestInRing = false;
	// 是否禁止单独导出 Quest 数据
	UPROPERTY(EditAnywhere, Config, Category = "Test")
	bool bForbidExportQuestFile = false;

	// 启用新的lua序列化反序列化
	UPROPERTY(EditAnywhere, Config, Category = "Test")
	bool bUseNewLuaSerializer = false;

	// 启用新的lua序列化反序列化后开启CDO功能
	UPROPERTY(EditAnywhere, Config, Category = "Test")
	bool bUseCDO = false;

	// 显示保存所有按钮，方便刷数据
	UPROPERTY(EditAnywhere, Config, Category = "Test")
	bool bShowSaveAllButton = false;

	// System Action的开关，默认关闭，测试好后再打开
	UPROPERTY(EditAnywhere, Config, Category = "Test")
	bool bSystemActionEnable = false;

	// 使用新版按文件热更的开关，默认关闭，测试好后再打开
	UPROPERTY(EditAnywhere, Config, Category = "Test")
	bool bUseNewReloadBat = false;

	UPROPERTY(EditAnywhere, Config, Category = "DisasterRecovery")
	float DisasterRecoveryTimerRate = 60.0f;
};

