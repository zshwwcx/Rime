// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"



DECLARE_LOG_CATEGORY_EXTERN(LogKGQuestEditor, Log, All);

class FKGQuestEditorModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;


	void OnPostEngineInit();


	struct FEDClassCollect* GetEDClassCollect();
public:
	TSharedPtr<struct FEDClassCollect> EDClassCollect;

	TSharedPtr<struct FGraphPanelNodeFactory> EDGraphPanelNodeFactory;
	TSharedPtr<struct FGraphPanelPinFactory> EDGraphPinNodeFactory;
};
