﻿#pragma once
#include "Framework/Commands/Commands.h"
#include "Internationalization/Internationalization.h"
#include "Styling/AppStyle.h"
#include "Templates/SharedPointer.h"
#include "UObject/NameTypes.h"
#include "UObject/UnrealNames.h"

class FUICommandInfo;

class FQuestEditorCommands : public TCommands<FQuestEditorCommands>
{
public:
	/** Constructor */
	FQuestEditorCommands()
		: TCommands<FQuestEditorCommands>("Quest Editor", NSLOCTEXT("FKGQuestEditorModule", "QuestEditor", "Quest Editor"), NAME_None,
			FAppStyle::GetAppStyleSetName())
	{
	}

	/** See tooltips in cpp for documentation */
	TSharedPtr<FUICommandInfo> CreateChapter;
	TSharedPtr<FUICommandInfo> ChapterCopy;
	TSharedPtr<FUICommandInfo> ChapterCut;
	TSharedPtr<FUICommandInfo> ChapterPaste;
	TSharedPtr<FUICommandInfo> ChapterDelete;

	/** Initialize commands */
	virtual void RegisterCommands() override;
};
