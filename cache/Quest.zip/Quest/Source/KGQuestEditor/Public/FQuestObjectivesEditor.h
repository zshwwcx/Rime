// Copyright 15.07.2018 Tefel. All Rights Reserved.

#pragma once

//#include "Toolkits/AssetEditorToolkit.h"
//#include "Toolkits/AssetEditorManager.h"
#include "CoreMinimal.h"
#include "Toolkits/IToolkit.h"
#include "Misc/NotifyHook.h"
#include "EditorUndoClient.h"
#include "IDetailsView.h"
#include "Tickable.h"
#include "AssetThumbnail.h"
#include "GraphEditor.h"
#include "Math/Color.h"
#include "Filters/SBasicFilterBar.h"
#include "QuestFilter.h"
#include "QuestTemplate.h"

#include "Framework/Docking/TabManager.h"
#include "WorkflowOrientedApp/WorkflowTabManager.h"



class UQuestObjectDataEntity;

class FQuestObjectivesEditorThumbnailPool : public FAssetThumbnailPool {
public:
	FQuestObjectivesEditorThumbnailPool(int NumObjectsInPool) : FAssetThumbnailPool(NumObjectsInPool) {}

	static TSharedPtr<FQuestObjectivesEditorThumbnailPool> Get() { return Instance; }
	static void Create() {
		Instance = MakeShareable(new FQuestObjectivesEditorThumbnailPool(512));
	}
private:
	static TSharedPtr<FQuestObjectivesEditorThumbnailPool> Instance;
};

class FQuestObjectivesEditor;

template<typename FilterType>
class FQuestFilter : public FQuestGenericFilter<FilterType>
{
public:
    DECLARE_DELEGATE_RetVal_OneParam(bool, FOnItemFiltered, FilterType);
    
	FQuestFilter(TSharedPtr<FFilterCategory> InCategory, const FString& InName, const FText& InDisplayName, FOnItemFiltered InFilterDelegate):
        FQuestGenericFilter<FilterType>(InCategory, InName, InDisplayName),FilterDelegate(InFilterDelegate)
	{

	}

    virtual bool PassesFilter( FilterType InItem ) const override
    {
        if(FilterDelegate.IsBound())
        {
            return FilterDelegate.Execute(InItem);
        }

        return false;
    }
    
	class FQuestObjectivesEditor* QuestEditor = nullptr;

	EQuestType QuestType = EQuestType::EQT_Max;
    
	virtual void ActiveStateChanged(bool bActive) override;
    
    
	void Init(class FQuestObjectivesEditor* InQuestEditor, FColor InColor, EQuestType InQuestType)
	{
		QuestEditor = InQuestEditor;

		QuestType = InQuestType;

        FQuestGenericFilter<FilterType>::Color = FLinearColor(InColor);

	}

    FOnItemFiltered FilterDelegate;
    
};

template<typename FilterType>
class SQuestFilterBar : public SBasicFilterBar<FilterType>
{
public:
	void EnalbeAllCustomFilters()
	{
		for (int i = 0; i < SBasicFilterBar<FilterType>::AllFrontendFilters.Num(); ++i)
		{
            SBasicFilterBar<FilterType>::AddFilterToBar(SBasicFilterBar<FilterType>::AllFrontendFilters[i]);
		}
	}

	void SetActive(int Index, bool bActive)
	{
		check(Index < SBasicFilterBar<FilterType>::AllFrontendFilters.Num());
		//SetFrontendFilterActive(AllFrontendFilters[Index], bActive);
		if (bActive)
		{
            SBasicFilterBar<FilterType>::ActiveFilters->Add(SBasicFilterBar<FilterType>::AllFrontendFilters[Index]);
		}
		else
		{
            SBasicFilterBar<FilterType>::ActiveFilters->Remove(SBasicFilterBar<FilterType>::AllFrontendFilters[Index]);
		}
	}

	void SetCheckBox(int Index, bool bActive)
	{
		if (SBasicFilterBar<FilterType>::Filters.Num() > Index)
		{
			SBasicFilterBar<FilterType>::Filters[Index]->SetEnabled(bActive);
		}
	}
};

class SGraphEditor_QuestObjectives : public SGraphEditor {
public:
	// SWidget implementation
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
	// End SWidget implementation
};

class FGraphUndoRedoHandler
{
public:
	FGraphUndoRedoHandler()
	{
		// 订阅撤销和重做事件
		FEditorDelegates::PostUndoRedo.AddRaw(this, &FGraphUndoRedoHandler::OnUndoRedo);
	}

	~FGraphUndoRedoHandler()
	{
		// 取消订阅撤销和重做事件
		FEditorDelegates::PostUndoRedo.RemoveAll(this);
	}

	void OnUndoRedo();
	
	FQuestObjectivesEditor* ActiveEditor;
};


/*-----------------------------------------------------------------------------
FQuestObjectivesEditor
-----------------------------------------------------------------------------*/

class FQuestObjectivesEditor : public FAssetEditorToolkit, public FNotifyHook, public FTickableGameObject, public FGCObject, public FEditorUndoClient
{
public:
	// IToolkit interface
	virtual void RegisterTabSpawners(const TSharedRef<class FTabManager>& TabManager) override;
	virtual void UnregisterTabSpawners(const TSharedRef<class FTabManager>& TabManager) override;
	// End of IToolkit interface

	// FAssetEditorToolkit
	virtual FName GetToolkitFName() const override;
	virtual FText GetBaseToolkitName() const override;
	virtual FText GetToolkitName() const override;
	virtual FLinearColor GetWorldCentricTabColorScale() const override;
	virtual FString GetWorldCentricTabPrefix() const override;
	// End of FAssetEditorToolkit

	// FTickableGameObject Interface
	virtual bool IsTickableInEditor() const override;
	virtual void Tick(float DeltaTime) override;
	virtual bool IsTickable() const override;
	virtual TStatId GetStatId() const override;
	// End of FTickableGameObject Interface

	void BindCommands();
	
	void InitQuestObjectivesEditor(const EToolkitMode::Type Mode, const TSharedPtr< class IToolkitHost >& InitToolkitHost);
	void DisasterRecoveryTask();

	FORCEINLINE TSharedPtr<SGraphEditor> GetGraphEditor() const { return GraphEditor; }
	
	FORCEINLINE TSharedPtr<class SQuestScrollWidget>  GetQuestScrollWidget() const;

	FORCEINLINE TSharedPtr<class SQuestTreeView>  GetQuestTreeView() const { return QuestTreeView; }


	void ShowObjectDetails(UObject* ObjectProperties);

	TArray<UObject*> GetAllObjectFromPathAndObjectClass(FString SearthPath, UClass* ObjectClass);

	void PropertyEditorSetObjects(TArray<UObject*> SelectedObjects) const;

	class UEdGraph_QuestObjectivesProp* GetQuestObjectivesGraph();

	void InitQuestObjectivesProp();

	void SetCurrentEditorDataAsset(UObject* Object) { CurEditorDataAsset = Object; }


	void RemoveGraphEditor();

	void AddGraphEditor();

	UQuestObjectDataEntity* GetDataEntity();
	void ModifyData();

	/** FGCObject interface */
	virtual void AddReferencedObjects( FReferenceCollector& Collector ) override;
	virtual FString GetReferencerName() const override
	{
		return TEXT("FQuestObjectivesEditor");
	}

	/** Called when a node's title is committed for a rename */
	void OnNodeTitleCommitted(const FText& NewText, ETextCommit::Type CommitInfo, UEdGraphNode* NodeBeingChanged);

public:
	void RefreshChapterGraphData();
	void QuestObjectTreeRefresh(bool bKeepSelection);
	void ClearRingGraph();
	void ClearChapterGraph();
    FQuestFilter<FString>::FOnItemFiltered OnQuestItemFilteredDelegate;

	void OnQuestTypeFilterChanged(EQuestType InType, bool bInActive);
	FReply OnSaveAssetInternal(bool bHotReload = false);
	FReply OnSaveAsset();
	FReply OnHotPatchAsset();
	FReply OnIDExchangeBtnClick();
	FReply OnRefresh();
	void GetAllFilenamesInDirectory(const FString& Directory, TArray<FString>& FileNames);
	void DeleteTempSaveFiles();
	
	FReply OnUndoButtonClicked();
	FReply OnRedoButtonClicked();
	FReply OnRefresh(bool bReload=true);
	FReply OnRefreshQuest(bool bReload=true);
	FReply OnRefreshLuaState();
	FReply OnCreateRing();
	FReply OnOpenIDDocumentClicked();
	
	FReply OnDeleteSelectQuest();
	void OnChapterSearchTextChanged(const FText& InSearchText);
	void OnSearchTextCommitted(const FText& InSearchText, ETextCommit::Type InCommitType);
	void ExportRingArray(const TArray<TObjectPtr<UQuestRing>>& Input, TArray<FString>& OutPut);
	void ExportQuestArray(const TArray<TObjectPtr<UQuest>>& Input, TArray<FString>& OutPut);
	FReply OnExportAll();
	FReply OnImportAll();
	FReply OnSaveAll();
	void SaveRings(TArray<UQuestRing*> InRings);
	FReply OnExportCDO();
	FReply DoExportAsset(TArray<UPackage*>& DirtyPkgs, TMap<UPackage*, UQuest*>& ModifyQuestMap, TMap<UPackage*, UQuestRing*>& ModifyRingMap);
	FReply OnOpenDisasterRecoveryFolderBtnClick();

	void RefreshLuaState();
	void OnRefreshChapter();
	void OnRefreshRingName();
	void OnRefreshQuestName();
	void OnRefreshPropertyEditor(UObject* InObj);
	void OnRefreshTargetStateIdx(UEdGraph* EDGraph);
	void OnRefreshActionStateIdx(UEdGraph* EDGraph);
	
	void LoadChapterGraph(UQuestChapter* InChapter);
	void RemapPreRingRelations(UPreRingInfo* InPreRingInfo);
	void LoadRingGraph(UQuestRing* InRing);
	void LoadQuestGraph(UQuest* InQuest);
	void LoadQuestGraphNew(UQuest* InQuest);
	void LoadQuestGraphNew(UQuest* InQuest, const TSharedPtr<class FLuaTable>& LuaTable);

	void CreateChapter();
	UQuestRing* CreateRing(UEdGraphPin* FromPin = nullptr);
	UChapterEnd* CreateChapterEnd(UEdGraphPin* FromPin = nullptr);
	UQuest* CreateQuest(UEdGraphPin* FromPin = nullptr);
	
	bool DeleteQuest(UQuest* InQuestData);
	bool DeleteRing(UQuestRing* InRingData);
	bool DeleteChapter(UQuestChapter* InChapterData);
	bool DeleteChapterEnd(UChapterEnd* ChapterEnd);

	bool ChangeQuestID(UQuest* InQuestData, int32 NewQuestID);
	void FlushQuestsAfterRingIDChange(UQuestRing* InRingData);
	void IDExchange(int32 FirstID, int32 SecondID);
	
	FReply TablePreview();
	void OnDataTableEditor(const UDataTable* InDataTable, const FName& Name);
	FReply OnShowSourceControlState();
	
	FReply OpenFlowChart();

	void GetChapterIDRange(EQuestType QuestType, int32& OutMinChapterID, int32& OutMaxChapterIDLimit);
	void GetRingIDRange(EQuestType QuestType, int32& OutMinRingID, int32& OutMaxRingIDLimit);

	FLinearColor GetChapterTypeColor(TObjectPtr<UQuestObject> Item);
	
	FString GetItemSourceControlState(TObjectPtr<UQuestObject> Item);
	
	TSharedRef<ITableRow> GenerateQuestObjectItemRow(TObjectPtr<UQuestObject> Item, const TSharedRef<STableViewBase>& OwnerTable);

	void OnGetQuestObjectTreeChildren(TObjectPtr<UQuestObject> InItem, TArray<TObjectPtr<UQuestObject>>& OutChildren);
	
	TSharedRef<ITableRow> GenerateChapterItemRow(TObjectPtr<UQuestChapter> Item, const TSharedRef<STableViewBase>& OwnerTable)
	{
		FString Display = FString::Printf(TEXT("%d - %s"), Item->QuestObjectID, *Item->QuestObjectName);
		FText DisplayText = FText::FromString(Display);
		return SNew(STableRow<TObjectPtr<UQuestChapter>>, OwnerTable)
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SImage)
					.Image(FAppStyle::GetBrush(TEXT("SourceControl.Add")))
					.ColorAndOpacity(FLinearColor::Red)
				]
				+ SHorizontalBox::Slot()
				[
					SNew(STextBlock)
					.Text(DisplayText)
					.ColorAndOpacity(GetChapterTypeColor(Item))
				]

			];
	}


	TSharedRef<ITableRow> GenerateRingItemRow(TObjectPtr<UQuestRing> Item, const TSharedRef<STableViewBase>& OwnerTable);
	TSharedRef<ITableRow> GenerateQuestItemRow(TObjectPtr<UQuest> Item, const TSharedRef<STableViewBase>& OwnerTable);

	/** Handler for list view selection changes */
	void OnQuestObjectListSelectionChanged(TObjectPtr< UQuestObject > InChangedItem, ESelectInfo::Type SelectInfo);
	FReply OnQuestObjectListKeyDownHandler(const FGeometry&, const FKeyEvent& InKeyEvent);
	void OnQuestObjectListMouseButtonClick(TObjectPtr<UQuestObject> InItem);
	TSharedPtr<SWidget> OnGetQuestObjectListContextMenu();
	
	void OnChapterListSelectionChanged(TObjectPtr< UQuestChapter > InChangedItem, ESelectInfo::Type SelectInfo);
	void OnChapterListItemDoubleClick(TObjectPtr< UQuestChapter > InItem);
	
	void OnRingListSelectionChanged(TObjectPtr<UQuestRing> InChangedItem, ESelectInfo::Type SelectInfo);
	void OnRingListItemClicked(TObjectPtr<UQuestRing> InItem);
	void OnRingListItemDoubleClick(TObjectPtr<UQuestRing> InItem);

	void OnQuestListSelectionChanged(TObjectPtr<UQuest> InChangedItem, ESelectInfo::Type SelectInfo);
	void OnQuestListItemClicked(TObjectPtr<UQuest> InItem);
	void OnQuestListItemDoubleClick(TObjectPtr<UQuest> InItem);

	void OnChapterTypeChanged(UQuestChapter* ChangedChapter);
	
	TSharedRef<SDockTab> SpawnTab_QuestToolBar(const FSpawnTabArgs& Args);
	TSharedRef<SDockTab> SpawnTab_NavigationTab(const FSpawnTabArgs& Args);
	TSharedRef<SDockTab> SpawnTab_ChapterGraph(const FSpawnTabArgs& Args);
	TSharedRef<SDockTab> SpawnTab_RingGraph(const FSpawnTabArgs& Args);
	TSharedRef<SDockTab> SpawnTab_FindInQuest(const FSpawnTabArgs& Args);

	bool RunP4Command(const FString& Command, FString& OutResult);
	bool SetP4WorkSpace();
	bool GetDepotPath(const FString& LocalPath, FString& DepotPath);
	bool GetLocalPath(const FString& DepotPath, FString& LocalPath);
	bool IsCheckedOutByOthers(const FString& FilePath);
	bool LockFile(const FString& FilePath);
	bool AddFile(const FString& FilePath);
	bool DeleteEmptyFilesInChangelist();
	
	bool MarkAssetForDirty(UQuestChapter* DirtyAsset);
	bool MarkAssetForDirty(UQuestRing* DirtyAsset);
	bool MarkAssetForDirty(UQuest* DirtyAsset);
	bool MarkAssetForDirty(UQuestObject* DirtyAsset);
	void MarkCurChapterForDirty();
	void MarkCurRingForDirty();
	void MarkCurQuestForDirty();

	bool MarkAssetForCheck(UQuestChapter* DirtyAsset);
	bool MarkAssetForCheck(UQuestRing* DirtyAsset);
	bool MarkAssetForCheck(UQuest* DirtyAsset);

	UQuest* GetQuestObjByQuestID(int32 QuestID, bool bReMapping = false);
	UQuestRing* GetRingObjByRingID(int32 RingID, bool bReMapping = false);
	UApplyBase* GetTransitionApplyType();

	bool bMarkingCurChapterDirty = false;
	bool bMarkingCurRingDirty = false;
	bool bMarkingCurQuestDirty = false;
	bool bLoadingChapterGraph = false;
	bool bLoadingRingGraph = false;
	bool bLoadingQuestGraph = false;
	bool bFocusingTreeView = false;

protected:
	int32 GetAvailableID(const UQuestObject* InObj, bool bCreate = true);

private:
	void RunBatFile(const FString& BatchFilePath, FString Param = "");

public:
	void PreRefreshQuestGraph(UQuest* QuestData);
	void RefreshQuestGraph(UQuest* QuestData);
	void CreateQuestGraph(UQuest* QuestData);
	void RefreshRingGraph(UQuestRing* RingData, bool bMarkCheck = true);

public:
	void RefreshQuestObjectTree();

protected:
	void OnSelectedQuestNodesChanged(const TSet<class UObject*>& NewSelection);

	bool CanDeleteQuestNodes() const;
	void OnDeleteQuestNode(class UEdGraph* InGraph);

	void CopySelectedQuestNodes(class UEdGraph* InGraph);
	bool CanCopyQuestNodes() const;

	void PasteSelectedQuestNodes(class UEdGraph* InGraph);
	bool CanPasteQuestNodes() const;

public:
	void PreRefreshRingGraph(UQuestRing* RingData);
	void PreRefreshChapterGraph(UQuestChapter* ChapterData);
	
protected: //Ring
	void OnSelectedRingNodesChanged(const TSet<class UObject*>& NewSelection);
	void OnRingNodeDoubleClicked(class UEdGraphNode* Node);

	bool CanDeleteNodes() const;
	void OnDeleteNode(class UEdGraph* InGraph);

	void OnCopyNode(UEdGraph* InGraph);
	void OnPasteNode(UEdGraph* InGraph);

public:
	void OnDeleteTransitionNode(class UEDGraphNode_Transition* TransitionNode);

protected: //Chapter
	void RefreshChapterGraph(UQuestChapter* ChapterData);
	void OnSelectedChapterNodesChanged(const TSet<class UObject*>& NewSelection);
	void OnChapterNodeDoubleClicked(class UEdGraphNode* InNode);
	void OnDeleteChapter();
	
private:
	
	void LoadAllQuestAssets();

public:
	void AddChapterObjToDataEntity(UQuestChapter* InObj);
	void AddRingObjToDataEntity(UQuestRing* InObj);
	void AddQuestObjToDataEntity(UQuest* InObj);
	bool RemoveChapterInDataEntity(UQuestChapter* InObj);
	bool RemoveRingInDataEntity(UQuestRing* InObj);
	bool RemoveQuestInDataEntity(UQuest* InObj);

	void RemoveInDataEntityMap(int32 InQuestObjectID);
	void AddInDataEntityMap(UQuestObject* InObj);

private:
	void AddChapterObj(UQuestChapter* InObj, bool bInit = false);
	void AddRingObj(UQuestRing* InObj, bool bInit = false);
	void AddQuestObj(UQuest* InObj, bool bInit = false);

	void DeleteChapterObj(UQuestChapter* InObj);
	void DeleteRingObj(UQuestRing* InObj);
	void DeleteQuestObj(UQuest* InObj);
	void RebuildQuestObjectRelations(UQuestObject* InObj, bool bDelete = false);
	
	void RebuildQuestObjectList(bool bKeepSelection);
	void RebuildChapterList(bool bKeepSelection,bool bFilter = true);
	void RebuildRingList(bool bKeepSelection);
	void RebuildQuestList(bool bKeepSelection);
	void RebuildLists(bool bKeepSelection);
	void RebuildRootItems();

	FString GetQuestTypeDisplayName(EQuestType InType);

	UQuestChapter* GetSelectedChapter();
	UQuestRing* GetSelectedRing();
	UQuest* GetSelectedQuest() const;

	void OnAssetRemoved(const FAssetData& InAssetData);
	bool bRemovingQuest = false;  // 编辑器内部删除Quest是允许的,这里做个标记避免OnAssetRemoved误判
	bool bRemoveQuestClosing = false;
	virtual void OnClose() override;
	virtual bool OnRequestClose(EAssetEditorCloseReason InCloseReason) override;

	// Quest Check Popup Window
	void ShowCheckResultMessageBox(const TArray<FString>& WarningMsgs, const TArray<FString>& ErrorMsgs);

	void InitializeQuestTypeSelection();
	TSharedRef<SWidget> GenerateFilterBtnMenuContent();

	void FilterQuestObject();
	void RecoverQuestObjectFilteredItems();
	void FilterQuestObjectBySearchText();
	void FilterQuestObjectTypes();
	
private:
	TWeakObjectPtr<UObject> FoundObject;
	
	TObjectPtr<UQuestObjectDataEntity> DataEntity; // cppcheck:ignore

	FGraphUndoRedoHandler* GraphUndoRedoHandler = nullptr;
	
	bool Actives[(int)EQuestType::EQT_Max + 1] = { 0 };
	TSharedPtr<SQuestFilterBar<FString>> FilterBar;
	TArray< TSharedRef<FFilterBase<FString>>> FilterType;

	//QuestObject List
	FString QuestObjectSearchText;
	TMap<EQuestType, bool> SelectedQuestTypes;
	TArray<TObjectPtr<UQuestObject>> QuestObjectFilteredItems; // cppcheck:ignore
	TSharedPtr<STreeView<TObjectPtr<UQuestObject>>> QuestObjectTreeView; // cppcheck:ignore
	
	//chapter list
	TSharedPtr<SListView<TObjectPtr<UQuestChapter>>> ChapterListView; // cppcheck:ignore

	// ring list
	TSharedPtr<SListView<TObjectPtr<UQuestRing>>> RingListView; // cppcheck:ignore

	// quest list
	TSharedPtr<SListView<TObjectPtr<UQuest>>> QuestListView; // cppcheck:ignore

	TSharedPtr<IDetailsView> PropertyEditor;

	// graphs
	TSharedPtr<FTabManager::FStack> GraphStack;

	TSharedPtr<SGraphEditor> RingGraphView;
	TSharedPtr<FUICommandList> RingGraphCommands;

	TSharedPtr<SGraphEditor> QuestGraphView;
	TSharedPtr<FUICommandList> QuestGraphCommands;

	TSharedPtr<SWindow> WarningWindow;
	TSharedPtr<SWindow> IDExchangeWindow;

private:
	TSharedPtr<FDocumentTracker> DocumentManager;
	TWeakPtr<FDocumentTabFactory> GraphEditorTabFactoryPtr;

private:
	TSharedRef<class SGraphEditor> CreateEDGraphEditorWidget(UEdGraph* InGraph);
	void EDDeleteSelectedNodes();
	bool EDCanDeleteNodes() const;

public:
	static const FString PlotQuestName;
	static const FString AchievementQuestName;
	static const FString LevelQuestName;
	static const FString GoodImpressionName;
	static const FString QuestAssetPath;
	
protected:
	TSharedRef<class SGraphEditor> CreateGraphEditorWidget(UEdGraph* InGraph);

	/** Select every node in the graph */
	void SelectAllNodes();
	/** Whether we can select every node */
	bool CanSelectAllNodes() const;

	/** Deletes all the selected nodes */
	void DeleteSelectedNodes();

	bool CanDeleteNode(class UEdGraphNode* Node);

	/** Delete an array of Material Graph Nodes and their corresponding expressions/comments */
	void DeleteNodes(const TArray<class UEdGraphNode*>& NodesToDelete);

	/** Delete only the currently selected nodes that can be duplicated */
	void DeleteSelectedDuplicatableNodes();

public:
	UQuestObject* DeepCopyQuestObject(UQuestObject* From, bool bForceNewInstanceID = false);

protected:
	void CopySelectedChapter();
	void OnCutSelectedChapter();
	bool CutSelectedChapter(bool bDeleteSelf = true);
	void PasteCopiedChapter(bool bNeedChangeID = true);
	void ReAllocateQuestObjectID(UQuestObject* Target, bool bKeepID = false);
	
	/** Copy the currently selected nodes */
	void CopySelectedNodes();
	/** Whether we are able to copy the currently selected nodes */
	bool CanCopyNodes() const;
	
	/** Paste the contents of the clipboard */
	void PasteNodes();
	virtual bool CanPasteNodes() const;
	bool CanPasteQuestNode() const;
	bool CanPasteRingNode() const;
	virtual void PasteNodesHere(const FVector2D& Location);

	/** Cut the currently selected nodes */
	void CutSelectedNodes();
	/** Whether we are able to cut the currently selected nodes */
	bool CanCutNodes() const;

	/** Duplicate the currently selected nodes */
	void DuplicateNodes();
	/** Whether we are able to duplicate the currently selected nodes */
	bool CanDuplicateNodes() const;

	void OnGraphChanged(const FEdGraphEditAction& Action);
	void OnChapterGraphChanged(const FEdGraphEditAction& Action);
	void OnRingGraphChanged(const FEdGraphEditAction& Action);
	void OnQuestGraphChanged(const FEdGraphEditAction& Action);
	void HandleGraphChanged();

protected:
	/** Called when "Save" is clicked for this asset */
	virtual void SaveAsset_Execute() override;

	/** Called when the selection changes in the GraphEditor */
	void OnSelectedNodesChanged(const TSet<class UObject*>& NewSelection);
	void OnQuestNodeDoubleClicked(class UEdGraphNode* Node);

protected:
	TSharedPtr<SGraphEditor> GraphEditor;
	TSharedPtr<FUICommandList> QuestObjectTreeCommands;
	TSharedPtr<FUICommandList> ChapterGraphEditorCommands;
	TSharedPtr<FUICommandList> RingGraphEditorCommands;
	TSharedPtr<FUICommandList> QuestGraphEditorCommands;
	TSharedPtr<SSearchBox> FilterTextBox;
	
	TSharedRef<SDockTab> SpawnTab_GraphEditor(const FSpawnTabArgs& Args);
	TSharedRef<SDockTab> SpawnTab_Details(const FSpawnTabArgs& Args);

	EVisibility GetDeleteDeleteVisibility() const;

	FReply SaveAssetOnClicked();
	FReply FindBrowserOnClicked();

	// ChapterGraph变化监听
	FDelegateHandle OnChapterGraphChangedDelegateHandle;
	// RingGraph变化监听
	FDelegateHandle OnRingGraphChangedDelegateHandle;
	// QuestGraph变化监听
	FDelegateHandle OnQuestGraphChangedDelegateHandle;

	TSharedPtr<class SQuestScrollWidget> QuestScrollWidget;

	TSharedPtr<class SQuestTreeView> QuestTreeView;

	/** Handle to the registered OnGraphChanged delegate. */
	FDelegateHandle OnGraphChangedDelegateHandle;

	bool bGraphStateChanged = false;

	TArray<TWeakObjectPtr<class UMONode_Base>> LastSelectedNodes;
	TWeakObjectPtr<> SelectNodeInstance;
	
	TArray<class UCCNode_Group*> LastSelectedGroupNodes;

	TSharedPtr<SHorizontalBox> GraphHorizontalBox;
	TSharedPtr<SDockTab> GraphDockTab;
	
	TWeakObjectPtr<UObject> CurEditorDataAsset = nullptr;

	TArray<UObject*> CopyNodesTemplateObjectArray;

protected:
	TSharedPtr<SVerticalBox> QuestGraphBox;
	TSharedPtr<SDockTab> QuestGraphDockTab;

protected:
	
	TSharedPtr<SVerticalBox> RingGraphBox;
	TSharedPtr<SDockTab> RingGraphDockTab;
	TWeakObjectPtr<class UEDGraphBase> RingGraph;
	TWeakObjectPtr<class UEDGraphBase> QuestGraph;

	TSharedPtr<SVerticalBox> ChapterGraphBox;
	TSharedPtr<SDockTab> ChapterGraphDockTab;
	TWeakObjectPtr<UEDGraphBase> ChapterGraph;

	/** Find results log as well as the search filter */
	TSharedPtr<class SFindInQuests> FindResults;
	TSharedPtr<SDockTab> QuestSearchResultsTab;
	
protected:
	bool bNextCreateQuest = false;
	
	bool bShowSourceControlState = false;

	int32 CachedQuestSubTargetMaxNumber=0;

	FTimerHandle DisasterRecoveryTimerHandle;
	TArray<FString> TempSaveFiles;
	FString DisasterRecoveryBaseFolderPath;
	
public:
	FORCEINLINE TWeakObjectPtr<UEDGraphBase> GetChapterGraph() const { return ChapterGraph; }
	FORCEINLINE TWeakObjectPtr<UEDGraphBase> GetRingGraph() const { return RingGraph; }
	FORCEINLINE TWeakObjectPtr<UEDGraphBase> GetQuestGraph() const { return QuestGraph; }
	FVector2D PlacePos;
	bool bUndoing = false;

	int32 GetCachedQuestSubTargetMaxNumber() const { return CachedQuestSubTargetMaxNumber; }

	TArray<TObjectPtr<UQuestChapter>>& GetAllQuestChapters();
	TArray<TObjectPtr<UQuestRing>>& GetAllQuestRings();
	TArray<TObjectPtr<UQuest>>& GetAllQuests();
};

