#pragma once


#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "QuestDocHelper.generated.h"

//
USTRUCT(BlueprintType)
struct FQuestDocHelper
{
	GENERATED_BODY()

	FQuestDocHelper() {};

	FQuestDocHelper(FString InUrl)
		:Url(InUrl)
	{};

public:
	FString GetUrl()const { return Url; }

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FString Url;
};