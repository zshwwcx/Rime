// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "QuestTemplate.h"
#include "UserQuestCondition.generated.h"

/**
 * 记录单个任务动态信息与静态引用
 */
UCLASS(Blueprintable, BlueprintType)
class   UUserQuestCondition : public UObject
{
	GENERATED_BODY()
//public:
//	virtual void Init(UQuestCondition* QuestConditionTemp, class UUserQuest* parentQuest);
//
//	class UWorld* GetWorld() const override;
//public:
//	void StartMsgRegister();
//	void EndMsgRegister();
//	UFUNCTION(BlueprintImplementableEvent,BlueprintCallable)
//	void OnMsgRegister();
//	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
//	void OnMsgUnregister();
//
//	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
//	bool IsMeetCondition();
//
//	//条件满足更新任务状态
//	UFUNCTION(BlueprintCallable)
//	void UpdateQuestStatus();
//
//	UFUNCTION(BlueprintCallable, BlueprintPure)
//	class	UMessageSystem* GetMessageSystem();
//
//	UFUNCTION(BlueprintCallable, BlueprintPure)
//	UQuestCondition* GetQuestConditionTemplate() 
//	{
//		return QuestConditionTemplate;
//	}
//
//protected:
//	UPROPERTY(Transient)
//	UQuestCondition* QuestConditionTemplate;
//	UPROPERTY(Transient)
//	UUserQuest* ParentQuest;
};
