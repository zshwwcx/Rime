// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "QuestDocHelper.h"
#include "QuestTemplate.generated.h"

#if WITH_EDITOR
class UQuestActionBase;
class UQuestSystemActionBase;
DECLARE_MULTICAST_DELEGATE(FUserRefreshChapter);
DECLARE_MULTICAST_DELEGATE(FUserRefreshChapterEnd);
DECLARE_MULTICAST_DELEGATE(FUserRefreshRingName);
DECLARE_MULTICAST_DELEGATE(FUserRefreshQuestName);
DECLARE_MULTICAST_DELEGATE(FUserRefreshImportantData);
#endif

#define LOCTEXT_NAMESPACE "QuestTemplate"

UENUM(BlueprintType, Blueprintable)
enum class EQuestType : uint8
{
	MAIN = 0 UMETA(DisplayName = "主线任务"),
	SUBTASK = 1 UMETA(DisplayName = "支线任务"),
	CITYCOLLECT = 2 UMETA(DisplayName = "百态任务"),
	WANDER = 3 UMETA(DisplayName = "漫游任务"),
	REPEAT = 4 UMETA(DisplayName = "系统任务"),
	WANTED = 5 UMETA(DisplayName = "生活任务", Deprecated, Hidden),
	SEQUENCE = 6 UMETA(DisplayName = "原著任务"),
	ROLEPLAY = 7 UMETA(DisplayName = "身份任务", Deprecated, Hidden),
	EQT_Max UMETA(DisplayName = "未定义", Hidden)
};

UENUM(BlueprintType, Blueprintable)
enum class ETaskType : uint8
{
	UNREPEATABLE = 0 UMETA(DisplayName = "一次性任务"),
	REPEATABLE UMETA(DisplayName = "日常任务"),
	REPEATABLE_WEEK UMETA(DisplayName = "周常任务"),
	ETT_Max UMETA(DisplayName = "未定义", Hidden)
};

UENUM(BlueprintType, Blueprintable)
enum class ERingTaskConditionType : uint8
{
	ClassID = 0 UMETA(DisplayName = "职业ID"),
	Gender UMETA(DisplayName = "性别(暂未实现)"),
	minlv UMETA(DisplayName = "最小等级"),
	maxlv UMETA(DisplayName = "最大等级"),
	DialogueID UMETA(DisplayName = "对话ID"),
	OptionID UMETA(DisplayName = "选项ID"),
	QTEPass UMETA(DisplayName = "QTE成功"),
    QTEFail UMETA(DisplayName = "QTE失败"),
	TalkID UMETA(DisplayName = "闲话ID"),
	FlowChartTag UMETA(DisplayName = "全局标记"),
	SubTargetCompleted UMETA(DisplayName = "子目标完成"),
	SubTargetActivated UMETA(DisplayName = "子目标激活"),
	QuestComplete UMETA(DisplayName = "任务步骤完成"),
	QuestActivated UMETA(DisplayName = "任务步骤激活"),
	RingComplete UMETA(DisplayName = "任务环完成"),
	RingActivated UMETA(DisplayName = "任务环激活"),
	FlowChartResult UMETA(DisplayName = "流程图结果")
};

UENUM(BlueprintType, Blueprintable)
enum class ERingTaskCompareType : uint8
{
	Equal = 0 UMETA(DisplayName = "=="),
	NotEqual UMETA(DisplayName = "!="),
	Greater UMETA(DisplayName = ">"),
	GreaterOrEql UMETA(DisplayName = ">="),
	Less UMETA(DisplayName = "<"),
	LessOrEql UMETA(DisplayName = "<="),
};

UENUM(BlueprintType, Blueprintable)
enum class EFallbackSetting : uint8
{
	Normal = 0 UMETA(DisplayName = "Normal"),
	Checkpoint UMETA(DisplayName = "Checkpoint"),
	FallbackPoint UMETA(DisplayName = "FallbackPoint"),
};

enum EQuestObjectType
{
	Root,
	Chapter,
	Ring,
	Quest
};

USTRUCT(BlueprintType, Blueprintable)
struct FGameplayID
{
	GENERATED_BODY()
	
	virtual ~FGameplayID() = default;
	virtual void GetDataSource(TArray<TSharedPtr<FString>>* &OutData);
	
	UPROPERTY()
	int32 ID = 0;
};

USTRUCT(BlueprintType, Blueprintable)
struct FDialogueID : public FGameplayID
{
	GENERATED_BODY()

	virtual void GetDataSource(TArray<TSharedPtr<FString>>* &OutData) override;

	FString AssetPath = "";
};

USTRUCT(BlueprintType, Blueprintable)
struct FNPCID : public FGameplayID
{
	GENERATED_BODY()

	virtual void GetDataSource(TArray<TSharedPtr<FString>>* &OutData) override;

	FString NPCName = "";
};

USTRUCT(BlueprintType, Blueprintable)
struct FItemID : public FGameplayID
{
	GENERATED_BODY()

	virtual void GetDataSource(TArray<TSharedPtr<FString>>* &OutData) override;

	FString ItemName = "";
};

USTRUCT(BlueprintType, Blueprintable)
struct FTaskCollectID : public FGameplayID
{
	GENERATED_BODY()

	virtual void GetDataSource(TArray<TSharedPtr<FString>>* &OutData) override;

	FString TaskCollectName = "";
};

USTRUCT(BlueprintType, Blueprintable)
struct FItemSubmitID : public FGameplayID
{
	GENERATED_BODY()

	virtual void GetDataSource(TArray<TSharedPtr<FString>>* &OutData) override;
};

USTRUCT(BlueprintType, Blueprintable)
struct FMonsterID : public FGameplayID
{
	GENERATED_BODY()

	virtual void GetDataSource(TArray<TSharedPtr<FString>>* &OutData) override;

	FString MonsterName = "";
};

USTRUCT(BlueprintType, Blueprintable)
struct FOptionTextID : public FGameplayID
{
	GENERATED_BODY()

	virtual void GetDataSource(TArray<TSharedPtr<FString>>*& OutData) override;

	FString OptionText = "";
};

USTRUCT(BlueprintType, Blueprintable)
struct FPreloadArgs
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere)
	bool bNeedPreload = true;

	UPROPERTY(EditAnywhere)
	FString PreloadQuestID = "-1";
};

USTRUCT(BlueprintType, Blueprintable)
struct FFlowChartPath
{
	GENERATED_BODY()

	FString Path = "";
};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class  UQuestRingData : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(VisibleAnywhere, Category = Quest)
	int32 ChapterID;

	UPROPERTY(EditDefaultsOnly, Category = Quest)
	FString RingName;

	UPROPERTY(EditDefaultsOnly, Category = Quest)
	FString AuthorName;

	UPROPERTY(EditAnywhere, Category = Reward)
	bool bAutoSubmitAfterDone;
	
	UPROPERTY(EditAnywhere, Category = Condition)
	int32 MinLevel;

	UPROPERTY(EditAnywhere, Category = Condition)
	int32 MaxLevel;

	UPROPERTY(EditAnywhere, Category = Condition)
	TArray<int32> ClassID;

	UPROPERTY(EditAnywhere, Category = Condition)
	int32 Gender;

	UPROPERTY(EditAnywhere, Category = Condition)
	int32 DialogID;

	UPROPERTY(EditAnywhere, Category = Condition)
	int32 OptionID;

	UPROPERTY()
	int32 PreRingID;

	UPROPERTY(EditAnywhere, Category = Abandon)
	bool bCanGiveUP;

	UPROPERTY(EditAnywhere, Category = Abandon)
	bool bAutoGiveUpAfterLeavingPlane;

	UPROPERTY(EditAnywhere, Category = Abandon)
	bool bAutoLeavePlaneAfterGiveUp;

	UPROPERTY(EditAnywhere, Category = Abandon)
	float CoolDownTimeAfterGiveUp;

	UPROPERTY(EditAnywhere, Category = Abandon)
	bool bHintOfReApply;
};

// Quest之间跳转的具体条件
UCLASS(BlueprintType, Blueprintable, editinlinenew)
class URingTaskConditionClass : public UObject
{
	GENERATED_BODY()
public:
	UPROPERTY(EditDefaultsOnly, meta = (Tooltip = "Variable"))
	ERingTaskConditionType Variable;

	UPROPERTY(EditDefaultsOnly, meta = (Tooltip = "FlowChartPath", EditCondition = "Variable == ERingTaskConditionType::FlowChartResult", EditConditionHides))
	FFlowChartPath FlowChartPath;
	
	UPROPERTY(EditDefaultsOnly, meta = (Tooltip = "Key", EditCondition = "Variable == ERingTaskConditionType::FlowChartTag", EditConditionHides))
	FString Key;

	UPROPERTY(EditDefaultsOnly, meta = (Tooltip = "CompareType"))
	ERingTaskCompareType CompareType;

	UPROPERTY(EditDefaultsOnly, meta = (Tooltip = "Value"))
	uint32 Value;

#if WITH_EDITOR
	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);
#endif
};

// Quest之间跳转的内层and逻辑
USTRUCT(BlueprintType, Blueprintable)
struct FRingTaskAndConditions
{
	GENERATED_BODY()
	// 内层代表着and的逻辑
	UPROPERTY(EditAnywhere, Instanced)
	TArray<URingTaskConditionClass*> AndConditions;
};

// Quest之间跳转的外层or逻辑
UCLASS(BlueprintType, Blueprintable, editinlinenew)
class URingTaskConditionBase : public UObject
{
	GENERATED_BODY()
public:
	// 外层代表着or的逻辑
	UPROPERTY()
	TArray<FRingTaskAndConditions> OrConditions;

	UPROPERTY(EditAnywhere, Instanced)
	TObjectPtr<URingTaskConditionClass> TaskCondition;

	UPROPERTY(VisibleAnywhere)
	int32 NextTaskID;

	UPROPERTY(EditAnywhere, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	FString DisplayName;

#if WITH_EDITOR
	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);
#endif
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class UTypedObjectBase : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, meta = (EditCondition = "Type == 99999", EditConditionHides = true, QuestExportIdenticalToDefault))
	int32 Type = 99999;
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class UApplyBase : public UTypedObjectBase
{
	GENERATED_BODY()
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class USubmitBase : public UTypedObjectBase
{
	GENERATED_BODY()
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class UFailedFallbackBase : public UTypedObjectBase
{
	GENERATED_BODY()
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class ULeavePlaneBase : public UTypedObjectBase
{
	GENERATED_BODY()
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class URewardBase : public UTypedObjectBase
{
	GENERATED_BODY()
};

// Ring激活的条件
UCLASS(BlueprintType, Blueprintable, editinlinenew)
class URingConditionBase : public UObject
{
	GENERATED_BODY()
public:
	// 外层代表着or的逻辑
	UPROPERTY(EditAnywhere)
	TArray<FRingTaskAndConditions> OrConditions;
};


// Action之间跳转的具体条件
UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UQuestActionConditionClass : public UObject
{
	GENERATED_BODY()
public:
	// Event编号,对应任务excel中的Condition Event
	UPROPERTY(EditDefaultsOnly, meta = (EditCondition = "ConditionID == 0"))
	int32 ConditionID;
};

// Action之间跳转的内层and逻辑
USTRUCT(BlueprintType, Blueprintable)
struct FQuestActionAndConditions
{
	GENERATED_BODY()
	// 内层代表着and的逻辑
	UPROPERTY(EditAnywhere, Instanced)
	TArray<UQuestActionConditionClass*> AndConditions;
};

// Action之间跳转的外层or逻辑
UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UQuestActionConditionBase : public UObject
{
	GENERATED_BODY()
public:
	// 外层代表着or的逻辑
	UPROPERTY(EditAnywhere)
	TArray<FQuestActionAndConditions> OrConditions;

	UPROPERTY(EditAnywhere, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	FString DisplayName;
};

//UCLASS(BlueprintType, Blueprintable, editinlinenew)
//class UQuestChapterData : public UObject
//{
//	GENERATED_BODY()
//public:
//};

UCLASS(BlueprintType, Blueprintable)
class UQuestObject : public UPrimaryDataAsset
{
	GENERATED_BODY()
public:
	UQuestObject();
	
	UPROPERTY(meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	int32 QuestObjectID;

	UPROPERTY(meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	FString QuestObjectName;

#if WITH_EDITOR
	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport))
	bool bQuestTypeEditable = false;
#endif
	
	UPROPERTY(EditAnywhere, Category = ChapterUnique, meta=(EditCondition = "bQuestTypeEditable == true", EditConditionHides, HideEditConditionToggle))
	EQuestType QuestType;
	
	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	TObjectPtr<UQuestObject> Father;

	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	TArray<TObjectPtr<UQuestObject>> Children;

	// 记录编辑器更改前的 id，例如更改 RingID 从 A 到 B，此时记录的为 A
	UPROPERTY(Transient, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	int32 OldQuestObjectID;

#if  WITH_EDITOR
	EQuestObjectType QuestObjectType;

	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);
	
	// 重载小于运算符
	bool operator<(const UQuestObject& Other) const {
		return QuestObjectID < Other.QuestObjectID;
	}

	// 重载大于运算符
	bool operator>(const UQuestObject& Other) const {
		return QuestObjectID > Other.QuestObjectID;
	}

	bool operator<=(const UQuestObject& Other) const {
		return QuestObjectID <= Other.QuestObjectID;
	}

	bool operator>=(const UQuestObject& Other) const {
		return QuestObjectID >= Other.QuestObjectID;
	}
#endif
};


// 预创建的Chapter
UCLASS(BlueprintType, Blueprintable)
class UPreQuestChapter : public UObject
{
	GENERATED_BODY()
public:

	UPROPERTY(EditDefaultsOnly)
	int32 ChapterID;

	UPROPERTY(EditDefaultsOnly)
	EQuestType QuestType;

	UPROPERTY(EditDefaultsOnly)
	FString ChapterName = LOCTEXT("PreChapterName", "New Chapter").ToString();

	UPROPERTY(EditDefaultsOnly, meta = (EditCondition = "QuestType == EQuestType::MAIN"))
	FString ChapterIndex;
};

// Chapter的数据层,会存盘至uasset文件
UCLASS(BlueprintType, Blueprintable)
class UQuestChapter : public UQuestObject
{
	GENERATED_BODY()
public:

	UPROPERTY(EditAnywhere, Category = ChapterUnique, meta = (ToolTip = "ChapterID"))
	int32 ChapterID;

	UPROPERTY(EditDefaultsOnly, Category = ChapterUnique, meta = (ToolTip = "ChapterName"))
	FString ChapterName;

	UPROPERTY(EditDefaultsOnly, Category = ChapterUnique, meta = (ToolTip = "ChapterIndex", EditCondition = "QuestType == EQuestType::MAIN || QuestType == EQuestType::SEQUENCE"))
	FString ChapterIndex;

	UPROPERTY(EditDefaultsOnly, Category = ChapterUnique, meta = (ToolTip = "AuthorName"))
	FString AuthorName;
	
	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	UEdGraph* ChapterGraph = nullptr;
	
	//UPROPERTY(EditAnywhere, Instanced)
	//UQuestChapterData* ChapterData;

#if WITH_EDITOR
	UQuestChapter();

	class FQuestObjectivesEditor* GetQuestEditor() const;
	
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void PreEditChange(FProperty* PropertyAboutToChange) override;

	UFUNCTION(BlueprintImplementableEvent)
	void OnPropertyChangedToBp();

	UFUNCTION(BlueprintCallable)
	void SetParamVisible(FName PropertyName, bool bVisible);

	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport))
	TArray<TObjectPtr<class UChapterEnd>> ChapterEnds;
	
	FUserRefreshChapter OnRefreshChapter;

	// 重载小于运算符
	bool operator<(const UQuestChapter& Other) const {
		return ChapterID < Other.ChapterID;
	}

	// 重载大于运算符
	bool operator>(const UQuestChapter& Other) const {
		return ChapterID > Other.ChapterID;
	}

	bool operator<=(const UQuestChapter& Other) const {
		return ChapterID <= Other.ChapterID;
	}

	bool operator>=(const UQuestChapter& Other) const {
		return ChapterID >= Other.ChapterID;
	}
#endif

public:
	bool CheckChapterID(FText& OutCheckDialog, bool bCheckMap = true);
};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UPreRingInfo : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(meta=(QuestExportIdenticalToDefault))
	int32 Type;
};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UPreRingID : public UPreRingInfo
{
	GENERATED_BODY()

public:
	UPreRingID();
	
	UPROPERTY(EditAnywhere)
	int32 PreRingID = -1;
};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UAndRelation : public UPreRingInfo
{
	GENERATED_BODY()

public:
	UAndRelation();
	
	UPROPERTY(EditAnywhere, Instanced)
	TArray<TObjectPtr<UPreRingInfo>> ChildInfo;
};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UOrRelation : public UPreRingInfo
{
	GENERATED_BODY()

public:
	UOrRelation();
	
	UPROPERTY(EditAnywhere, Instanced)
	TArray<TObjectPtr<UPreRingInfo>> ChildInfo;
};

//UCLASS(BlueprintType, Blueprintable, editinlinenew)
//class UQuestRingData : public UObject
//{
//	GENERATED_BODY()
//public:
//};

UCLASS(BlueprintType, Blueprintable)
class UPreQuestRing : public UObject
{
	GENERATED_BODY()
public:

	UPROPERTY(VisibleAnywhere, Category = QuestRingDefault)
	int32 ChapterID;

	UPROPERTY(EditDefaultsOnly, meta = (ClampMin = 1000, ClampMax = 99000), Category = QuestRingDefault)
	int32 RingID;

	UPROPERTY(EditAnywhere, Category = ChapterUnique)
	EQuestType QuestType;
	
	UPROPERTY(EditAnywhere, Category = QuestRingDefault)
	ETaskType Type;
	
	UPROPERTY(EditAnywhere, Category = QuestRingDefault)
	FString RingName;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (MultiLine = "true"))
	FString RingDescription;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (MultiLine = "true"))
	FString RingExplain;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault)
	TArray<int> RelatedPlanes;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault)
	int Version;
};

#if WITH_EDITOR
UCLASS(BlueprintType, Blueprintable)
class UPreChapterEnd : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, meta = (ClampMin = 60000, ClampMax = 999999, ToolTip = "NextRingID"), Category = QuestRingDefault)
	int32 NextRingID;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "Desc"))
	FString Desc;
};

UCLASS(BlueprintType, Blueprintable)
class UChapterEnd : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(VisibleAnywhere, meta = (ClampMin = 60000, ClampMax = 999999, ToolTip = "NextRingID"), Category = QuestRingDefault)
	int32 NextRingID;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "Desc"))
	FString Desc;
	
	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport))
	TObjectPtr<UQuestChapter> Father;

	FUserRefreshChapterEnd OnChapterEndChanged;
	
	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);

	void NotifyEditorChapterEndChange();

	TWeakPtr<FAssetEditorToolkit> QuestObjectivesEditor;
};
#endif

UCLASS(BlueprintType, Blueprintable)
class UQuestRing : public UQuestObject
{
	GENERATED_BODY()
public:
	UPROPERTY(VisibleAnywhere, Category = QuestRingDefault, meta = (ToolTip = "ChapterID"))
	int32 ChapterID;

	UPROPERTY(EditAnywhere, meta = (ClampMin = 60000, ClampMax = 999999, ToolTip = "RingID"), Category = QuestRingDefault)
	int32 RingID;
	
	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "Type"))
	ETaskType Type;

	UPROPERTY(EditDefaultsOnly, Category = QuestRingDefault, meta = (ToolTip = "RingName"))
	FString RingName;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "RingDescription", MultiLine = "true"))
	FString RingDescription;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "RingExplain", MultiLine = "true"))
	FString RingExplain;
	
	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "MainTag"))
	FString MainTag;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "MainTag"))
	bool bMainTagItem = true;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "SubTagFirst"))
	FString SubTagFirst;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "SubTagFirst"))
	bool bSubTagFirstItem = false;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "SubTagSecond"))
	FString SubTagSecond;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "SubTagSecond"))
	bool bSubTagSecondItem = false;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "RelatedPlanes"))
	TArray<int> RelatedPlanes;

	UPROPERTY(EditAnywhere, Category = QuestRingDefault, meta = (ToolTip = "Version"))
	int Version;

	UPROPERTY(EditAnywhere, meta = (ClampMin = 0, ClampMax = 100, ToolTip = "SubQuestType", EditCondition = "QuestType == EQuestType::WANDER", EditConditionHides, HideEditConditionToggle), Category = QuestRingDefault)
	int32 SubQuestType = 0;

	UPROPERTY(EditDefaultsOnly, Category = RingCondition, meta = (ToolTip = "ConditionFlowChart"))
	FFlowChartPath ConditionFlowChart;

	UPROPERTY(EditDefaultsOnly, Category = RingCondition, meta = (ToolTip = "AdventureRelated"))
	bool AdventureRelated;
	
	UPROPERTY(EditAnywhere, Instanced, Category = RingCondition, meta = (ToolTip = "PreRingRelations", QuestLazyImport))
	TObjectPtr<UPreRingInfo> PreRingRelations;
	
	UPROPERTY(EditAnywhere, Category = RingCondition, meta = (ToolTip = "MutuallyExclusiveRing"))
	TArray<int32> MutuallyExclusiveRing;
	
	//任务激活列表，能激活尽激活
	UPROPERTY(BlueprintReadOnly, Category = RingCondition, meta = (ToolTip = "NextTaskInfoList"))
	TArray<URingTaskConditionBase*> NextTaskInfoList;

	UPROPERTY(EditAnywhere, Instanced, Category = RingApply, meta = (ToolTip = "ApplyType", QuestLazyImport))
	TObjectPtr<UApplyBase> ApplyType;

	UPROPERTY(EditAnywhere, Instanced, Category = RingApply, meta = (ToolTip = "ApplySystemActions", QuestLazyImport))
	TArray<TObjectPtr<UQuestSystemActionBase>> ApplySystemActions;

	UPROPERTY(EditAnywhere, Instanced, Category = RingSubmit, meta = (ToolTip = "SubmitType", QuestLazyImport))
	TObjectPtr<USubmitBase> SubmitType;

	UPROPERTY(EditAnywhere, Instanced, Category = RingSubmit, meta = (ToolTip = "SubmitSystemActions", QuestLazyImport))
	TArray<TObjectPtr<UQuestSystemActionBase>> SubmitSystemActions;
	
	UPROPERTY(EditAnywhere, Category = RingAbandon, meta = (ToolTip = "bCanGiveUP"))
	bool bCanGiveUP;

	UPROPERTY(EditAnywhere, Category = RingAbandon, meta = (ToolTip = "bAutoGiveUpAfterLeavingPlane"))
	bool bAutoGiveUpAfterLeavingPlane;

	UPROPERTY(EditAnywhere, Category = RingAbandon, meta = (ToolTip = "bAutoLeavePlaneAfterGiveUp"))
	bool bAutoLeavePlaneAfterGiveUp;

	UPROPERTY(EditAnywhere, Category = RingAbandon, meta = (ToolTip = "CoolDownTimeAfterGiveUp"))
	float CoolDownTimeAfterGiveUp;

	UPROPERTY(EditAnywhere, Instanced, Category = RingAbandon, meta = (ToolTip = "AbandonSystemActions", QuestLazyImport))
	TArray<TObjectPtr<UQuestSystemActionBase>> AbandonSystemActions;
	
	//UPROPERTY(EditAnywhere, Instanced)
	//UQuestRingData* ChapterData;

#if WITH_EDITORONLY_DATA
	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	class UEdGraph* RingGraph = nullptr;

	FUserRefreshRingName OnRefreshRingname;
	
	TWeakPtr<class FAssetEditorToolkit> QuestObjectivesEditor;
#endif

#if WITH_EDITOR
	class FQuestObjectivesEditor* GetQuestEditor() const;
	
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void PreEditChange(FProperty* PropertyAboutToChange) override;

	void NotifyQuestEditor();

	virtual bool CanEditChange(const FProperty* InProperty) const override;

	UFUNCTION(BlueprintImplementableEvent)
	void OnPropertyChangedToBp();

	void NextTaskInfoNotifyQuestEditor();

	UFUNCTION(BlueprintCallable)
	void SetParamVisible(FName PropertyName, bool bVisible);
#endif

public:
	void OnChangeRingID();

	bool CheckRingID(FText& OutCheckDialog, bool bCheckMap = true);

public:
	UFUNCTION(BlueprintImplementableEvent)
	void SetMiniType(EQuestType ChapterType);
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class UQuestDataBase : public UObject
{
	GENERATED_BODY()
public:

	FUserRefreshImportantData OnRefreshImportantData;

	TWeakObjectPtr<UEdGraph> QuestGraph;
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class UQuestSystemActionBase : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY()
	FString ActionTypeName;
};

// TODO. 旧的这个类型或许该清理掉，但是还有诸如 InstanceID 的定制逻辑不确定要不要迁移
UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class UQuestActionBase : public UQuestDataBase
{
	GENERATED_BODY()
public:
	UQuestActionBase(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	// 用来控制只在蓝图中显示不在任务编辑器显示的属性
	UPROPERTY(Transient)
	bool bDefaultObj = false;
	
	// Event编号,对应任务excel中的Event
	UPROPERTY(EditDefaultsOnly, Category = QuestActionDefault, meta = (EditCondition = "bDefaultObj", EditConditionHides = "true", HideEditConditionToggle, QuestExportIdenticalToDefault), AssetRegistrySearchable)
	int32 Event = 99999;

	// UniqueID
	UPROPERTY(EditDefaultsOnly, Category = QuestActionDefault, meta = (
		EditCondition = "Event == 66 || Event == 67 || Event == 68",
		EditConditionHides = "true"
		))
	FString UniqueID;

	FLinearColor NodeColor = FLinearColor::Blue;

#if WITH_EDITOR
	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);
	
	void PostInitProperties();

	UFUNCTION(BlueprintImplementableEvent)
	void OnPropertyChangedToBp();

	UFUNCTION(BlueprintCallable)
	void SetParamVisible(FName PropertyName, bool bVisible);

	UFUNCTION(BlueprintCallable)
	void SetNodeColor(FLinearColor InNodeColor) { NodeColor = InNodeColor; }

	void NotifyQuestEditor();
#endif
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class UTaskTargetTrace : public UObject
{
	GENERATED_BODY()
	
public:
	UPROPERTY(EditDefaultsOnly, meta = (EditCondition = "Type == 99999", EditConditionHides = "true", QuestExportIdenticalToDefault))
	int32 Type = 99999;
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class UQuestTargetBase : public UQuestDataBase
{
	GENERATED_BODY()
public:
	UQuestTargetBase(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
	//目标数量
	UPROPERTY()
	int32 Target = 0;

	// 用来控制只在蓝图中显示不在任务编辑器显示的属性
	UPROPERTY(Transient)
	bool bDefaultObj = false;
	
	//目标类型
	UPROPERTY(EditDefaultsOnly, Category = QuestTargetDefault, meta = (EditCondition = "bDefaultObj", EditConditionHides = "true", HideEditConditionToggle, QuestExportIdenticalToDefault), AssetRegistrySearchable)
	int32 Type = 99999;
	
	// UniqueID
	UPROPERTY(EditDefaultsOnly, Category = UniqueID, meta = (EditCondition = "false", EditConditionHides = "true"))
	uint32 UniqueID = 0;

	UPROPERTY(EditAnywhere, Instanced, Category = "目标追踪设置", meta = (EditCondition = "bIsMain == false", EditConditionHides = "true", HideEditConditionToggle))
	TObjectPtr<UTaskTargetTrace> TraceParam;
	
	UPROPERTY(BlueprintReadOnly, meta = (EditCondition = "false", EditConditionHides, HideEditConditionToggle))
	bool bIsMain = false;
	
	FLinearColor NodeColor = FLinearColor::Yellow;

	void OnAutoCreateNode();

	UFUNCTION(BlueprintImplementableEvent)
	int32 GetAutoCreateNodeEvent();

	UFUNCTION(BlueprintImplementableEvent)
	TMap<FString, FString> GetAutoCreatePropTable();

	UQuestActionBase* GetActionInstanceFromEvent(int32 Event);
	
#if WITH_EDITOR
	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);

	void PostInitProperties();
	
	UFUNCTION(BlueprintImplementableEvent)
	void OnPropertyChangedToBp();

	UFUNCTION(BlueprintCallable)
	void SetParamVisible(FName PropertyName, bool bVisible);

	UFUNCTION(BlueprintCallable)
	void SetNodeColor(FLinearColor InNodeColor) { NodeColor = InNodeColor; }

	void NotifyQuestEditor();
#endif
};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UQuestConditionBase : public UQuestDataBase
{
	GENERATED_BODY()
public:
};

UCLASS(BlueprintType, Blueprintable, editinlinenew, Abstract)
class UQuestEndConditionBase : public UQuestDataBase
{
	GENERATED_BODY()
public:
	
	UPROPERTY(EditDefaultsOnly, Category = QuestEndConditionDefault, meta = (EditCondition = "Type == 99999", EditConditionHides = true, QuestExportIdenticalToDefault))
	int32 Type = 99999;
};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UQuestSuccessConditionBase : public UQuestDataBase
{
	GENERATED_BODY()
public:

};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UQuestBeginBase : public UQuestDataBase
{
	GENERATED_BODY()
public:

};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UQuestProgressBase : public UQuestDataBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = QuestProgressDefault, meta = (Tooltip = "是否需要完成所有任务目标才能完成任务"))
	bool bIsAnd = true;

#if WITH_EDITOR
	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);

	void NotifyQuestEditor();
#endif
};

UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UQuestEndBase : public UQuestDataBase
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, Instanced, Category = QuestEndConditionDefault)
	TArray<UQuestEndConditionBase*> FailCondition;

#if WITH_EDITOR
	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);
	
	void NotifyQuestEditor();
#endif
};

// 预创建的Quest
UCLASS(BlueprintType, Blueprintable)
class UPreQuest : public UObject
{
	GENERATED_BODY()
public:

	UPROPERTY(VisibleAnywhere, Category = QuestDefault)
	int32 ChapterID;

	UPROPERTY(VisibleAnywhere, Category = QuestDefault)
	int32 RingID;

	UPROPERTY(EditDefaultsOnly, meta = (ClampMin = 100000, ClampMax = 9999999), Category = QuestDefault)
	int32 QuestID;

	UPROPERTY(EditDefaultsOnly, Category = QuestDefault)
	FString QuestName;
};

UENUM(BlueprintType, Blueprintable)
enum class ETargetNumShowMode : uint8
{
	HideAll = 0 UMETA(DisplayName = "全部隐藏"),
	ShowNumOnly = 1 UMETA(DisplayName = "只显示数量"),
	ShowProgressBarOnly = 2 UMETA(DisplayName = "只显示进度条"),
	ShowAll = 3 UMETA(DisplayName = "全部显示")
};

USTRUCT()
struct FQuestTraceItem
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, meta = (MultiLine = "true"))
	FString Desc;
	
	UPROPERTY(EditAnywhere, meta = (MultiLine = "true"))
	FString MainTargetTips;
	
	UPROPERTY()
	bool bShowTargetNum = true;

	UPROPERTY(EditAnywhere)
	ETargetNumShowMode TargetNumShowMode = ETargetNumShowMode::HideAll;
	
	UPROPERTY(EditAnywhere)
	bool bIsDescVisible = true;

	UPROPERTY(EditAnywhere, Instanced)
	TObjectPtr<UTaskTargetTrace> TraceParam;
};

USTRUCT()
struct FPreloadIDs
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<int32> PreloadDialogIDs;

	UPROPERTY()
	TArray<int32> PreLoadCutSceneIDs;
};

UCLASS(BlueprintType, Blueprintable)
class UQuest : public UQuestObject
{
	GENERATED_BODY()
public:

	UPROPERTY(meta = (ToolTip = "ChapterID", QuestIgnoreExport, QuestIgnoreExportEditor))
	int32 ChapterID;

	UPROPERTY(meta = (ToolTip = "RingID", QuestIgnoreExport, QuestIgnoreExportEditor))
	int32 RingID;

	UPROPERTY(EditAnywhere, meta = (ToolTip = "QuestID"), Category = QuestDefault)
	int32 QuestID;
	
	UPROPERTY(EditDefaultsOnly, Category = QuestDefault, meta = (ToolTip = "QuestName"))
	FString QuestName;

	UPROPERTY(EditAnywhere, Category = QuestDefault, meta = (ToolTip = "IsSaveQuestPoint"))
	EFallbackSetting FallbackSetting;

	// 存档功能是否需要生效，默认生效
	UPROPERTY(EditAnywhere, Category = QuestDefault, meta = (ToolTip = "bCheckpointWork", EditCondition = "FallbackSetting == EFallbackSetting::Checkpoint", EditConditionHides = "true"))
	bool bCheckpointWork = true;

	UPROPERTY(EditAnywhere, Category = QuestDefault, meta = (ToolTip = "SavePlaneID", EditCondition = "FallbackSetting == EFallbackSetting::Checkpoint", EditConditionHides = "true"))
	int32 SavePlaneID;

	UPROPERTY(EditAnywhere, Instanced, Category = QuestBegin, meta = (ToolTip = "BeginSystemActions", QuestLazyImport))
	TArray<UQuestSystemActionBase*> BeginSystemActions;

	UPROPERTY(EditAnywhere, Instanced, Category = QuestMainTarget, meta = (ToolTip = "MainTarget", QuestLazyImport))
	UQuestTargetBase* MainTarget;
	
	UPROPERTY(EditAnywhere, Category = QuestMainTarget, meta = (ToolTip = "MainTargetTraceCombo", QuestLazyImport))
	TArray<FQuestTraceItem> MainTargetTraceCombo;
	
	UPROPERTY(EditAnywhere, Instanced, Category = QuestMainTarget, meta = (ToolTip = "ClickSystemActions", QuestLazyImport))
	TArray<UQuestSystemActionBase*> ClickSystemActions;
	
	UPROPERTY(EditAnywhere, Instanced, Category = QuestSubTarget, meta = (ToolTip = "QuestTargets", QuestLazyImport))
	TArray<UQuestTargetBase*> QuestTargets;

	UPROPERTY(EditAnywhere, Instanced, Category = QuestFailure, meta = (ToolTip = "FailConditions", QuestLazyImport, EditCondition = "false", EditConditionHides))
	TObjectPtr<UQuestEndConditionBase> FailConditions;

	UPROPERTY(EditAnywhere, Instanced, Category = QuestFailure, meta = (ToolTip = "FailedFallbackType", QuestLazyImport, EditCondition = "false", EditConditionHides))
	TObjectPtr<UFailedFallbackBase> FailedFallbackType;

	UPROPERTY(EditAnywhere, Instanced, Category = QuestFailure, meta = (ToolTip = "FailSystemActions", QuestLazyImport, EditCondition = "false", EditConditionHides))
	TArray<UQuestSystemActionBase*> FailSystemActions;

	UPROPERTY(EditAnywhere, Instanced, Category = QuestEnd, meta = (ToolTip = "EndSystemActions", QuestLazyImport))
	TArray<UQuestSystemActionBase*> EndSystemActions;

	UPROPERTY(EditAnywhere, Instanced, Category = QuestEnd, meta = (ToolTip = "LeavePlaneAction", QuestLazyImport))
	TObjectPtr<ULeavePlaneBase> LeavePlaneAction;

	UPROPERTY(EditAnywhere, Category = QuestReward, meta = (ToolTip = "Should Give Quest Reward", EditCondition = "FallbackSetting != EFallbackSetting::Checkpoint", EditConditionHides))
	bool bQuestReward = false;
	
	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	UQuestBeginBase* Begin;

	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	UQuestProgressBase* Progress;

	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	UQuestEndBase* End;

	UPROPERTY(BlueprintReadOnly, Category = QuestDefault)
	TArray<URingTaskConditionBase*> NextTaskInfoList;

	UPROPERTY()
	TMap<int32, FPreloadIDs> PreloadMap;

public:
#if WITH_EDITORONLY_DATA
	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport, QuestIgnoreExportEditor))
	class UEdGraph* QuestGraph = nullptr;

	UPROPERTY(Transient, meta = (LuaNoExport))
	TArray<int32> EmptyTraceParamTargetIndex;
#endif

	void CreateTargetsManually(TArray<UQuestTargetBase*>& InTargetList);

#if WITH_EDITOR
	class FQuestObjectivesEditor* GetQuestEditor() const;
	
	void PostInitProperties() override;

	void PreEditChange(FProperty* PropertyAboutToChange) override;
	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);

	UFUNCTION(BlueprintImplementableEvent)
	void OnPropertyChangedToBp();

	UFUNCTION(BlueprintCallable)
	void SetParamVisible(FName PropertyName, bool bVisible);
	
	FUserRefreshQuestName OnRefreshQuestName;
	
	TWeakPtr<class FAssetEditorToolkit> QuestObjectivesEditor;
	
	void NotifyQuestEditor();

	void NotifyQuestEditorForSelf();

	void NextTaskInfoNotifyQuestEditor();
	
	virtual bool CanEditChange(const FProperty* InProperty) const override;
#endif
};

// 创建Quest时可配置的条件选项
UCLASS(BlueprintType, Blueprintable, editinlinenew)
class UCreateQuestEdit : public UObject
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, Instanced, Category = CreateSetting)
	TArray<UQuestTargetBase*> PreSelectTargets;

	UPROPERTY(EditAnywhere, Category = CreateSetting)
	bool bCopyLastQuestData = true;

	TWeakObjectPtr<class UPreQuest> PreQuest;

#if WITH_EDITOR
	void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);
#endif
};


UENUM(BlueprintType, Blueprintable)
enum class EQuestActionNodeType : uint8
{
	EMN_ActionBase = 0					UMETA(DisplayName = "Action基类节点"),
	EMN_GroupQuest_Base = 1			UMETA(DisplayName = "GroupQuest节点"),
	EMN_QuestBase = 2					UMETA(DisplayName = "Quest基类节点"),
	EMN_Quest_LevelReward = 3			UMETA(DisplayName = "Quest关卡奖励节点"),
	EMN_Action_Visibility = 4			UMETA(DisplayName = "Visibility节点"),
	EMN_Action_PlayWidget = 5			UMETA(DisplayName = "PlayWidget节点"),
	EMN_Action_PlayDialogue = 6			UMETA(DisplayName = "Play对话节点"),
	EMN_Action_PlaySequence = 7			UMETA(DisplayName = "PlaySequence节点"),
	EMN_Action_Reward = 8				UMETA(DisplayName = "Reward节点"),
	EMN_Action_Interactive = 9			UMETA(DisplayName = "交互节点"),
	EMN_Action_EnterLevel = 10			UMETA(DisplayName = "进入关卡节点"),
	EMN_Action_SceneEvent = 11			UMETA(DisplayName = "场景事件节点"),
	EMN_Action_ActionEnd = 12			UMETA(DisplayName = "Action结束节点"),
	EMN_Action_ActionStart = 13			UMETA(DisplayName = "Action开始节点"),
	EMN_Action_ShowOrHideWidget = 14	UMETA(DisplayName = "显示隐藏UI节点"),


};

UENUM(BlueprintType, Blueprintable)
enum class EQuestActionLevelEvent : uint8
{
	NoneEvent = 0			UMETA(DisplayName = "无特殊事件播放"),
	AI_Down = 1				UMETA(DisplayName = "路人倒地"),
	UI_Show = 2				UMETA(DisplayName = "UI隐藏显示"),
	Boss_Show = 4			UMETA(DisplayName = "希玛现身"),



};

UENUM(BlueprintType, Blueprintable)
enum class EQuestStarReward : uint8
{
	OneStar = 0			UMETA(DisplayName = "一星"),
	TwoStar				UMETA(DisplayName = "二星"),
	ThreeStar 			UMETA(DisplayName = "三星"),
	FirstPass 			UMETA(DisplayName = "首次通关"),

};

UENUM(BlueprintType, Blueprintable)
enum class EAchieveQuestType : uint8
{
	QuestGroup = 0		UMETA(DisplayName = "QuestGroup"),
	Quest = 1				UMETA(DisplayName = "Quest"),
	QuestAction = 2		UMETA(DisplayName = "QuestAction"),

};




UCLASS(EditInlineNew, BlueprintType, Blueprintable)
class   UQuestCondition : public UObject
{
	GENERATED_BODY()
public:
	// 条件类型
	//UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	//int ConditionType = 0;

	// 对应的Instance类
	UPROPERTY(EditDefaultsOnly, Category = Common)
		TSubclassOf<class UUserQuestCondition> InstanceClass;

	// 取 "非"
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Common)
		bool bIsNot = false;

	//UFUNCTION(BlueprintCallable)
	//bool ExecuteConditionFunctionImp();

	//UFUNCTION(BlueprintImplementableEvent)
	//bool ExecuteConditionFunction();

};

/**
 * 专门用于交互的条件
 */
UCLASS(EditInlineNew, BlueprintType, Blueprintable)
class   UInteractiveQuestCondition : public UQuestCondition
{
	GENERATED_BODY()
public:

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	struct FSceneInstrumentRef ObjectID;

	//UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Transient)
	//	TArray<FInteractBehavior> InteractBehaviorArray;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int32 CompleteIndex;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		FGuid Guid;

	// UObject interface
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif


};

UCLASS(EditInlineNew, BlueprintType, Blueprintable)
class   UQuestConditionOR : public UQuestCondition
{
	GENERATED_BODY()
		//public:
		//	virtual bool ExecuteConditionFunctionImp();
public:
	UPROPERTY(EditDefaultsOnly, Instanced, BlueprintReadOnly, Category = Common)
		TArray<UQuestCondition*>  QuestConditionsArray;
};

UCLASS(EditInlineNew, BlueprintType, Blueprintable)
class   UQuestConditionAND : public UQuestCondition
{
	GENERATED_BODY()
		//public:
		//	virtual bool ExecuteConditionFunctionImp();
public:
	UPROPERTY(EditDefaultsOnly, Instanced, BlueprintReadOnly, Category = Common)
		TArray<UQuestCondition*>  QuestConditionsArray;
};



/**
描述单行动节点的基类， 单个任务单元，包含单元多个前置条件，多个完成条件信息; 单个任务包含多个行动节点的
*/
UCLASS(BlueprintType, Blueprintable)
class   UQuestActionNode :public UQuest
{
	GENERATED_BODY()

	FPrimaryAssetId GetPrimaryAssetId() const
	{
		return FPrimaryAssetId();
	}

public:
	//UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Common, meta = (Tooltip = "行动类型"))
	//int ActionType;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Common, meta = (Tooltip = "父类QuestID"))
		int64 ParentQuestId;

};

///**
//在任务编辑器中显示NPC和隐藏的节点
//*/
//UCLASS(BlueprintType, Blueprintable)
//class   UNPCVisibilityNode :public UQuestActionNode
//{
//	GENERATED_BODY()
//public:
//
//	UNPCVisibilityNode()
//	{
//		ActionNodeType = EQuestActionNodeType::EMN_Action_Visibility;
//	}
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "NPCVisibility", meta = (Tooltip = "NPCVisibility"))
//		int NPCId;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "NPCVisibility", meta = (Tooltip = "NPCVisibility"))
//		bool bTurnOn;
//
//};

/**
在任务编辑器中显示Widget
*/
//UCLASS(BlueprintType, Blueprintable)
//class   UPlayActionNode :public UQuestActionNode
//{
//	GENERATED_BODY()
//public:
//	
//	UPlayActionNode()
//	{
//		ActionNodeType = EQuestActionNodeType::EMN_Action_Play;
//	}
//	
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = Play ,EditCondition = "bPlayWidget == true"))
//		TSubclassOf<UUserWidget> WidgetRowName;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = Play, EditCondition = "bPlayWidget == true"))
//		float fPlayWidgetDelayTime;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = Play, EditCondition = "bPlaySequence == true"))
//		TSoftObjectPtr<ULevelSequence> SequenceRowName;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = Play, EditCondition = "bPlaySequence == true"))
//		float fPlaySequenceDelayTime;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = Play, EditCondition = "bPlayDialogue == true"))
//		TSoftObjectPtr<UPlotDialogueAsset> PlayDialogueID;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = Play, EditCondition = "bPlayDialogue == true"))
//		FDialoguePlaySettings DialoguePlaySettings;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = Play, EditCondition = "bPlayDialogue == true"))
//		float fPlayDialogueDelayTime;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = "Play"))
//		bool bPlayWidget;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = "Play"))
//		bool bPlaySequence;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayAction", meta = (Tooltip = "Play"))
//		bool bPlayDialogue;
//};

//UCLASS(BlueprintType, Blueprintable)
//class   URewardActionNode :public UQuestActionNode
//{
//	GENERATED_BODY()
//public:
//
//	URewardActionNode()
//	{
//		ActionNodeType = EQuestActionNodeType::EMN_Action_Reward;
//	}
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RewardAction", meta = (Tooltip = Reward))
//		TArray<FString> RewardArray;
//};

/**
描述单个任务的基类,单个任务静态数据集，每个任务包含不同的行动节点，以支持单个任务可以支持类似多个子任务的效果
*/
UCLASS(BlueprintType, Blueprintable)
class   USingleQuest :public UQuest
{
	GENERATED_BODY()
public:
	USingleQuest()
	{
		//ActionNodeType = EQuestActionNodeType::EMN_QuestBase;
	}

	UPROPERTY(VisibleAnywhere, Instanced, BlueprintReadOnly)
		TArray<UQuestActionNode*> QuestActionNodeArray;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		int64 ParentGroupId;



#if WITH_EDITORONLY_DATA
	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport))
		class UEdGraph* NodeGraph;
#endif
};

/**
关卡奖励节点
*/
//UCLASS(BlueprintType, Blueprintable)
//class   USingleQuest_LevelReward :public USingleQuest
//{
//	GENERATED_BODY()
//public:
//	USingleQuest_LevelReward()
//	{
//		ActionNodeType = EQuestActionNodeType::EMN_Quest_LevelReward;
//
//	}
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RewardQuest", meta = (Tooltip = "是否只是第一次获得"))
//	bool bFirstReward = false;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RewardQuest", meta = (Tooltip = "奖励对应的星级"))
//	EQuestStarReward StarReward;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RewardQuest", meta = (Tooltip = "星级对应的奖励"))
//	TArray<FString> RewardArray;
//
//};


/**
描述任务组的基类 (对应策划案上任务链及章节)，包含多个单个任务；可以嵌套任务组，包含任务组和任务的混合列表
*/
UCLASS(BlueprintType, Blueprintable)
class   UGroupQuestTemplate : public UQuest
{
	GENERATED_BODY()
public:
	UGroupQuestTemplate()
	{
		//ActionNodeType = EQuestActionNodeType::EMN_GroupQuest_Base;
	}



	UPROPERTY(VisibleAnywhere, Instanced, BlueprintReadOnly)
		TArray<UQuest*> QuestArray;


#if WITH_EDITORONLY_DATA
	UPROPERTY(BlueprintReadOnly, Category = Edit, meta = (QuestIgnoreExport))
		class UEdGraph* NodeGraph;
#endif
};

#undef LOCTEXT_NAMESPACE