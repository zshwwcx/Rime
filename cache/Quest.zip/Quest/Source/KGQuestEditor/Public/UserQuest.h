// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "QuestTemplate.h"
#include "UserQuest.generated.h"

class UUserQuestCondition;

/**
 * 单个任务的基类,记录单个任务(组)的动态信息和静态信息的引用，任务状态，任务进度等
 */
UCLASS(Abstract,Blueprintable,BlueprintType)
class   UUserQuest : public UObject
{
	GENERATED_BODY()
//public:
//	virtual void InitQuest(UQuest* QuestTemp,class  UUserQuest* Parent,class UQuestManager* missionMgr);
//	class UWorld* GetWorld() const override;
//	virtual void DestroyAll();
//
//	//更新任务状态
//	virtual void UpdateQuestStatus() {};
//
//	//检查接受条件
//	virtual bool CheckAcceptCondition();
//	//检查完成接受条件
//	virtual bool CheckCompleteCondition();
//
//	//开始进行中的任务前的消息监听等工作
//	virtual void  StartAcceptedQuest();
//
//public://蓝图
//	UFUNCTION(BlueprintImplementableEvent)
//	bool IsQuestComplete();
//
//		// 获取静态数据
//	UFUNCTION(BlueprintCallable, BlueprintPure)
//	class UQuest* GetQuestTemplate() const { return QuestTemplate; }
//
//	UFUNCTION(BlueprintCallable, BlueprintPure)
//	class UUserGroupQuest* GetParentUserGroupQuest();
//
//	// 获取当前任务的temolateID
//	UFUNCTION(BlueprintCallable, BlueprintPure)
//	const FName GetQuestId();
//	// 获取前置个任务的ID
//	UFUNCTION(BlueprintCallable, BlueprintPure)
//	const TArray<FName> GetPreQuestId();
//	// 获取后置任务的ID
//	UFUNCTION(BlueprintCallable, BlueprintPure)
//	const TArray<FName> GetPostQuestId();
//
//	//主动接受任务
//	UFUNCTION(BlueprintCallable)
//	bool AcceptQuest();
//
//	//主动领取任务奖励
//	UFUNCTION(BlueprintCallable)
//	bool GetQuestRewards();
//
//	UFUNCTION(BlueprintCallable, BlueprintPure)
//	EQuestStatus GetQuestStatus() { return QuestStatus; }
//
//protected:
//	UPROPERTY(Transient)
//	EQuestStatus QuestStatus;
//	UPROPERTY(Transient)
//	class UUserQuest* ParentQuest;
//	UPROPERTY(Transient)
//	UQuest*  QuestTemplate;
//	UPROPERTY(Transient)
//	class UQuestManager* QuestManager;
//	UPROPERTY(Transient)
//	TArray<UUserQuestCondition*> UserAcceptConditions;
//	UPROPERTY(Transient)
//	TArray<UUserQuestCondition*> UserCompleteConditions;
};
