#include "AnimGraphNode_ThreeLayerPostureBlend.h"
#include "EdGraphSchema_K2_Actions.h"
#include "Modules/ModuleManager.h"
#include "ToolMenus.h"

#include "Kismet2/CompilerResultsLog.h"
#include "GraphEditorActions.h"
#include "AssetRegistry/ARFilter.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "BlueprintActionFilter.h"
#include "BlueprintActionDatabaseRegistrar.h"
#include "EditorCategoryUtils.h"
#include "BlueprintNodeSpawner.h"
#include "Animation/AnimComposite.h"
#include "Animation/AnimSequence.h"
#include "Engine/Blueprint.h"
#include "Animation/AnimLayerInterface.h"



#include "EditorCategoryUtils.h"

#define LOCTEXT_NAMESPACE "UAnimGraphNode_ThreeLayerPostureBlend"

FLinearColor UAnimGraphNode_ThreeLayerPostureBlend::GetNodeTitleColor() const
{
	return FLinearColor(0.10f, 0.60f, 0.12f);
}

FText UAnimGraphNode_ThreeLayerPostureBlend::GetTooltipText() const
{
	return LOCTEXT("NodeToolTip", "Three Layer Posture Blend");
}

FText UAnimGraphNode_ThreeLayerPostureBlend::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	
	return LOCTEXT("BlendNodeTitle", "Three Layer Blend");
}


FString UAnimGraphNode_ThreeLayerPostureBlend::GetNodeCategory() const
{
	return TEXT("Animation|Blends");
}

void UAnimGraphNode_ThreeLayerPostureBlend::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	const FName PropertyName = (PropertyChangedEvent.Property ? PropertyChangedEvent.Property->GetFName() : NAME_None);

	if ((PropertyName == TEXT("Node")))
	{
		ReconstructNode();
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}



#undef LOCTEXT_NAMESPACE
