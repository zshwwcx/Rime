// Fill out your copyright notice in the Description page of Project Settings.


#include "AnimGraphNode_C7VehicleIK.h"
// Copyright Epic Games, Inc. All Rights Reserved.

#include "AnimNodeEditModes.h"
#include "Animation/AnimInstance.h"
#include "Components/SkeletalMeshComponent.h"
#include "DetailCategoryBuilder.h"

#define LOCTEXT_NAMESPACE "AnimGraphNode_VehicleIK"


UAnimGraphNode_C7VehicleIK::UAnimGraphNode_C7VehicleIK(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FText UAnimGraphNode_C7VehicleIK::GetTooltipText() const
{
	return LOCTEXT("AnimGraphNode_VehicleIK_Tooltip", "The Bone IK control applies an inverse kinematic (IK) solver to Locate Position");
}

FText UAnimGraphNode_C7VehicleIK::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return FText::FromString("C7VehicleIK");
}

FEditorModeID UAnimGraphNode_C7VehicleIK::GetEditorMode() const
{
	return FName("AnimGraph.SkeletalControl.VehicleIK");
}

void UAnimGraphNode_C7VehicleIK::Serialize(FArchive& Ar)
{
	Super::Serialize(Ar);
}


#undef LOCTEXT_NAMESPACE
