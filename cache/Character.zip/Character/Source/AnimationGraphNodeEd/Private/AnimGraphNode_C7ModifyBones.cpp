// Copyright Epic Games, Inc. All Rights Reserved.

#include "AnimGraphNode_C7ModifyBones.h"
#include "AnimNodeEditModes.h"
#include "Kismet2/CompilerResultsLog.h"

/////////////////////////////////////////////////////
// UAnimGraphNode_C7ModifyBones

#define LOCTEXT_NAMESPACE "A3Nodes"

UAnimGraphNode_C7ModifyBones::UAnimGraphNode_C7ModifyBones(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UAnimGraphNode_C7ModifyBones::ValidateAnimNodeDuringCompilation(USkeleton* ForSkeleton, FCompilerResultsLog& MessageLog)
{
	// Temporary fix where skeleton is not fully loaded during AnimBP compilation and thus virtual bone name check is invalid UE-39499 (NEED FIX) 
	if (ForSkeleton && !ForSkeleton->HasAnyFlags(RF_NeedPostLoad))
	{
		for (auto Param : Node.BonesParam)
		{
			if (ForSkeleton->GetReferenceSkeleton().FindBoneIndex(Param.Value.BoneToModify) == INDEX_NONE)
			{
				if (Param.Value.BoneToModify == NAME_None)
				{
					MessageLog.Warning(*LOCTEXT("NoBoneSelectedToModify", "@@ - You must pick a bone to modify").ToString(), this);
				}
				else
				{
					FFormatNamedArguments Args;
					Args.Add(TEXT("BoneName"), FText::FromName(Param.Value.BoneToModify));

					FText Msg = FText::Format(LOCTEXT("NoBoneFoundToModify", "@@ - Bone {BoneName} not found in Skeleton"), Args);

					MessageLog.Warning(*Msg.ToString(), this);
				}
			}	
		}
	}

	Super::ValidateAnimNodeDuringCompilation(ForSkeleton, MessageLog);
}


FText UAnimGraphNode_C7ModifyBones::GetTooltipText() const
{
	return LOCTEXT("AnimGraphNode_ModifyBone_Tooltip", "The Transform Bone node alters the transform - i.e. Translation, Rotation, or Scale - of the bone");
}

FText UAnimGraphNode_C7ModifyBones::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	if ((TitleType == ENodeTitleType::ListView || TitleType == ENodeTitleType::MenuTitle))
	{
		return  LOCTEXT("TransformModifyBone", "C7 Transform (Modify) Bones");
	}
	// @TODO: the bone can be altered in the property editor, so we have to 
	//        choose to mark this dirty when that happens for this to properly work
	else //if (!CachedNodeTitles.IsTitleCached(TitleType, this))
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("ControllerDescription"), LOCTEXT("TransformModifyBone", "C7 Transform (Modify) Bones"));
		
		for (auto Param : Node.BonesParam)
		{
			Args.Add(TEXT("BoneName"), FText::FromName(Param.Value.BoneToModify));	
		}

		// FText::Format() is slow, so we cache this to save on performance
		if (TitleType == ENodeTitleType::ListView || TitleType == ENodeTitleType::MenuTitle)
		{
			CachedNodeTitles.SetCachedTitle(TitleType, FText::Format(LOCTEXT("AnimGraphNode_ModifyBone_ListTitle", "{ControllerDescription} - Bone: {BoneName}"), Args), this);
		}
		else
		{
			CachedNodeTitles.SetCachedTitle(TitleType, FText::Format(LOCTEXT("AnimGraphNode_ModifyBone_Title", "{ControllerDescription}\nBone: {BoneName}"), Args), this);
		}
	}
	return CachedNodeTitles[TitleType];
}

void UAnimGraphNode_C7ModifyBones::CopyNodeDataToPreviewNode(FAnimNode_Base* InPreviewNode)
{
	// FAnimNode_C7ModifyBones* ModifyBone = static_cast<FAnimNode_C7ModifyBones*>(InPreviewNode);

	// Array Length not Equal
	// copies Pin values from the internal node to get data which are not compiled yet
	// ModifyBone->Translation = Node.Translation;
	// ModifyBone->Rotation = Node.Rotation;
	// ModifyBone->Scale = Node.Scale;

	// copies Modes
	// ModifyBone->TranslationMode = Node.TranslationMode;
	// ModifyBone->RotationMode = Node.RotationMode;
	// ModifyBone->ScaleMode = Node.ScaleMode;
	//
	// // copies Spaces
	// ModifyBone->TranslationSpace = Node.TranslationSpace;
	// ModifyBone->RotationSpace = Node.RotationSpace;
	// ModifyBone->ScaleSpace = Node.ScaleSpace;
}

FEditorModeID UAnimGraphNode_C7ModifyBones::GetEditorMode() const
{
	return FName("AnimGraph.SkeletalControl.C7ModifyBones");
}

void UAnimGraphNode_C7ModifyBones::CopyPinDefaultsToNodeData(UEdGraphPin* InPin)
{
	// if (InPin->GetName() == GET_MEMBER_NAME_STRING_CHECKED(FAnimNode_C7ModifyBones, Translation))
	// {
	// 	GetDefaultValue(GET_MEMBER_NAME_STRING_CHECKED(FAnimNode_C7ModifyBones, Translation), Node.Translation);
	// }
	// else if (InPin->GetName() == GET_MEMBER_NAME_STRING_CHECKED(FAnimNode_C7ModifyBones, Rotation))
	// {
	// 	GetDefaultValue(GET_MEMBER_NAME_STRING_CHECKED(FAnimNode_C7ModifyBones, Rotation), Node.Rotation);
	// }
	// else if (InPin->GetName() == GET_MEMBER_NAME_STRING_CHECKED(FAnimNode_C7ModifyBones, Scale))
	// {
	// 	GetDefaultValue(GET_MEMBER_NAME_STRING_CHECKED(FAnimNode_C7ModifyBones, Scale), Node.Scale);
	// }
}

#undef LOCTEXT_NAMESPACE
