#include "AnimGraphNode_WebSequencePlayer.h"
#include "EdGraphSchema_K2_Actions.h"
#include "Modules/ModuleManager.h"
#include "ToolMenus.h"

#include "Kismet2/CompilerResultsLog.h"
#include "GraphEditorActions.h"
#include "AssetRegistry/ARFilter.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "BlueprintActionFilter.h"
#include "BlueprintActionDatabaseRegistrar.h"
#include "EditorCategoryUtils.h"
#include "BlueprintNodeSpawner.h"
#include "Animation/AnimComposite.h"
#include "Animation/AnimSequence.h"
#include "Engine/Blueprint.h"
#include "Animation/AnimLayerInterface.h"
#include "Animation/AnimAttributes.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "DetailLayoutBuilder.h"
#include "Animation/AnimInstance.h"

#define LOCTEXT_NAMESPACE "UAnimGraphNode_WebSequencePlayer"


UAnimGraphNode_WebSequencePlayer::UAnimGraphNode_WebSequencePlayer(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FText UAnimGraphNode_WebSequencePlayer::GetTooltipText() const
{
	return LOCTEXT("NodeToolTip", "Play web sequence animation data");
}

FText UAnimGraphNode_WebSequencePlayer::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return LOCTEXT("NodeTitle", "Web Sequence Player");
}

FText UAnimGraphNode_WebSequencePlayer::GetMenuCategory() const
{
	return LOCTEXT("NodeCategory", "Web Animation");
}

FString UAnimGraphNode_WebSequencePlayer::GetNodeCategory() const
{
	return TEXT("Animation|Blends");
}

FLinearColor UAnimGraphNode_WebSequencePlayer::GetNodeTitleColor() const
{
	return FLinearColor(0.2f, 0.8f, 0.2f);
}

void UAnimGraphNode_WebSequencePlayer::ValidateAnimNodeDuringCompilation(USkeleton* ForSkeleton, FCompilerResultsLog& MessageLog)
{
	Super::ValidateAnimNodeDuringCompilation(ForSkeleton, MessageLog);
}

bool UAnimGraphNode_WebSequencePlayer::DoesSupportTimeForTransitionGetter() const
{
	return true;
}

UAnimationAsset* UAnimGraphNode_WebSequencePlayer::GetAnimationAsset() const
{
	return nullptr;
}

const TCHAR* UAnimGraphNode_WebSequencePlayer::GetTimePropertyName() const
{
	return TEXT("PlayTime");
}

UScriptStruct* UAnimGraphNode_WebSequencePlayer::GetTimePropertyStruct() const
{
	return FAnimNode_WebSequencePlayer::StaticStruct();
}


#undef LOCTEXT_NAMESPACE
