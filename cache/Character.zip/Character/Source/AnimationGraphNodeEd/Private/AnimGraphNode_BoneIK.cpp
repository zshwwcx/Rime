// Fill out your copyright notice in the Description page of Project Settings.


#include "AnimGraphNode_BoneIK.h"

// Copyright Epic Games, Inc. All Rights Reserved.

#include "AnimNodeEditModes.h"
#include "Animation/AnimInstance.h"
#include "Components/SkeletalMeshComponent.h"

// for customization details
#include "DetailLayoutBuilder.h"
#include "DetailCategoryBuilder.h"

// version handling
#include "AnimationCustomVersion.h"

#define LOCTEXT_NAMESPACE "AnimGraphNode_BoneIK"

/////////////////////////////////////////////////////
// FBoneIKDelegate

class FBoneIKDelegate : public TSharedFromThis<FBoneIKDelegate>
{
public:
	void UpdateLocationSpace(class IDetailLayoutBuilder* DetailBuilder)
	{
		if (DetailBuilder)
		{
			DetailBuilder->ForceRefreshDetails();
		}
	}
};

TSharedPtr<FBoneIKDelegate> UAnimGraphNode_BoneIK::BoneIKDelegate = NULL;

/////////////////////////////////////////////////////
// UAnimGraphNode_BoneIK


UAnimGraphNode_BoneIK::UAnimGraphNode_BoneIK(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FText UAnimGraphNode_BoneIK::GetControllerDescription() const
{
	return LOCTEXT("BoneIK", "Bone IK");
}

FText UAnimGraphNode_BoneIK::GetTooltipText() const
{
	return LOCTEXT("AnimGraphNode_BoneIK_Tooltip", "The Bone IK control applies an inverse kinematic (IK) solver to Locate Position");
}

FText UAnimGraphNode_BoneIK::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	if ((TitleType == ENodeTitleType::ListView || TitleType == ENodeTitleType::MenuTitle) && (Node.IKBone.BoneName == NAME_None))
	{
		return GetControllerDescription();
	}
	// @TODO: the bone can be altered in the property editor, so we have to 
	//        choose to mark this dirty when that happens for this to properly work
	else //if (!CachedNodeTitles.IsTitleCached(TitleType, this))
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("ControllerDescription"), GetControllerDescription());
		Args.Add(TEXT("BoneName"), FText::FromName(Node.IKBone.BoneName));

		// FText::Format() is slow, so we cache this to save on performance
		if (TitleType == ENodeTitleType::ListView || TitleType == ENodeTitleType::MenuTitle)
		{
			CachedNodeTitles.SetCachedTitle(TitleType, FText::Format(LOCTEXT("AnimGraphNode_IKBone_ListTitle", "{ControllerDescription} - Bone: {BoneName}"), Args), this);
		}
		else
		{
			CachedNodeTitles.SetCachedTitle(TitleType, FText::Format(LOCTEXT("AnimGraphNode_IKBone_Title", "{ControllerDescription}\nBone: {BoneName}"), Args), this);
		}
	}
	return CachedNodeTitles[TitleType];
}

void UAnimGraphNode_BoneIK::CopyNodeDataToPreviewNode(FAnimNode_Base* InPreviewNode)
{
	FAnimNode_BoneIK* BoneIK = static_cast<FAnimNode_BoneIK*>(InPreviewNode);

	// copies Pin values from the internal node to get data which are not compiled yet
	BoneIK->EffectorLocation = Node.EffectorLocation;
}

void UAnimGraphNode_BoneIK::CopyPinDefaultsToNodeData(UEdGraphPin* InPin)
{
	if (InPin->GetName() == GET_MEMBER_NAME_STRING_CHECKED(FAnimNode_BoneIK, EffectorLocation))
	{
		GetDefaultValue(GET_MEMBER_NAME_STRING_CHECKED(FAnimNode_BoneIK, EffectorLocation), Node.EffectorLocation);
	}
}

void UAnimGraphNode_BoneIK::CustomizeDetails(class IDetailLayoutBuilder& DetailBuilder)
{
	Super::CustomizeDetails(DetailBuilder);
}

FEditorModeID UAnimGraphNode_BoneIK::GetEditorMode() const
{
	return FName("AnimGraph.SkeletalControl.BoneIK");
}

void UAnimGraphNode_BoneIK::Serialize(FArchive& Ar)
{
	Super::Serialize(Ar);

	Ar.UsingCustomVersion(FAnimationCustomVersion::GUID);

	const int32 CustomAnimVersion = Ar.CustomVer(FAnimationCustomVersion::GUID);

	if (CustomAnimVersion < FAnimationCustomVersion::ConvertIKToSupportBoneSocketTarget)
	{
		if (Node.EffectorSpaceBoneName_DEPRECATED != NAME_None)
		{
			Node.EffectorTarget = FBoneSocketTarget(Node.EffectorSpaceBoneName_DEPRECATED);
		}
	}
}

void UAnimGraphNode_BoneIK::Draw(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* SkelMeshComp) const
{
	if (bEnableDebugDraw && SkelMeshComp)
	{
		if (FAnimNode_BoneIK* ActiveNode = GetActiveInstanceNode<FAnimNode_BoneIK>(SkelMeshComp->GetAnimInstance()))
		{
			ActiveNode->ConditionalDebugDraw(PDI, SkelMeshComp);
		}
	}
}

#undef LOCTEXT_NAMESPACE
