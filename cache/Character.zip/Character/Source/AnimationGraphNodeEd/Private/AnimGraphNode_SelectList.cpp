// Copyright Epic Games, Inc. All Rights Reserved.


#include "AnimGraphNode_SelectList.h"
#include "ToolMenus.h"
#include "Kismet2/BlueprintEditorUtils.h"

#include "AnimGraphCommands.h"
#include "ScopedTransaction.h"
#include "BlueprintEditor.h"

/////////////////////////////////////////////////////
// UAnimGraphNode_SelectList

#define LOCTEXT_NAMESPACE "UAnimGraphNode_SelectList"

UAnimGraphNode_SelectList::UAnimGraphNode_SelectList(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FLinearColor UAnimGraphNode_SelectList::GetNodeTitleColor() const
{
	return FLinearColor(0.2f, 0.8f, 0.2f);
}

FText UAnimGraphNode_SelectList::GetTooltipText() const
{
	return LOCTEXT("AnimGraphNode_BlendListByInt_Tooltip", "Select List (by int or bool)");
}

FText UAnimGraphNode_SelectList::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return LOCTEXT("AnimGraphNode_BlendListByInt_Title", "Select Poses");
}

void UAnimGraphNode_SelectList::CustomizePinData(UEdGraphPin* Pin, FName SourcePropertyName, int32 ArrayIndex) const
{
	if (SourcePropertyName.ToString().Contains(TEXT("ChildIndex")))
	{
		FString SourcePropertyNameString = SourcePropertyName.ToString();
		if (SourcePropertyNameString == TEXT("ActiveIntChildIndex1"))
		{
			Pin->PinFriendlyName = FText::FromString(TEXT("IntChildIndex1,Range:") + FString::FromInt(Node.IntIndexRange1));
		}
		else if (SourcePropertyNameString == TEXT("ActiveIntChildIndex2"))
		{
			Pin->PinFriendlyName = FText::FromString(TEXT("IntChildIndex2,Range:") + FString::FromInt(Node.IntIndexRange2));
		}
		else if (SourcePropertyNameString == TEXT("ActiveIntChildIndex3"))
		{
			Pin->PinFriendlyName = FText::FromString(TEXT("IntChildIndex3,Range:") + FString::FromInt(Node.IntIndexRange3));
		}
		else if (SourcePropertyNameString == TEXT("ActiveBoolChildIndex1"))
		{
			Pin->PinFriendlyName = FText::FromString(TEXT("BoolChildIndex1,Range:") + FString::FromInt(Node.BoolIndexRange1));
		}
		else if (SourcePropertyNameString == TEXT("ActiveBoolChildIndex2"))
		{
			Pin->PinFriendlyName = FText::FromString(TEXT("BoolChildIndex2,Range:") + FString::FromInt(Node.BoolIndexRange2));
		}
		else if (SourcePropertyNameString == TEXT("ActiveBoolChildIndex3"))
		{
			Pin->PinFriendlyName = FText::FromString(TEXT("BoolChildIndex3,Range:") + FString::FromInt(Node.BoolIndexRange3));
		}
	}
	else if (SourcePropertyName.ToString().Contains(TEXT("SelectPose")))
	{
		Pin->PinFriendlyName = FText::FromString(SourcePropertyName.ToString() + _GetSelectPoseIndexTip(ArrayIndex));
	}
}

void UAnimGraphNode_SelectList::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if(PropertyChangedEvent.ChangeType != EPropertyChangeType::Unspecified)
	{
		UpdateInputPin();
	}
	else
	{
		_UpdatePinVisibility();
	}
}

void UAnimGraphNode_SelectList::Serialize(FArchive& Ar)
{
	Super::Serialize(Ar);

	// 完成序列化后，更新一下Pin的连接，这里注意不能触发Recontruct
	_UpdatePinVisibility();
}

void UAnimGraphNode_SelectList::UpdateInputPin()
{
	int32 TotalPinNum = _UpdatePinVisibility();
	
	Modify();
	Node.ResizePose(TotalPinNum);
	ReconstructNode();
	FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(GetBlueprint());
}

int32 UAnimGraphNode_SelectList::_UpdatePinVisibility()
{
	FOptionalPinManager::CacheShownPins(ShowPinForProperties, OldShownPins);

	int32 TotalPinNum = 1;
	for (int i = 0; i < ShowPinForProperties.Num(); i++)
	{
		if (ShowPinForProperties[i].PropertyName == TEXT("ActiveIntChildIndex1"))
		{
			// SetPinVisibility(Node.IntIndexRange1 > 0, i);
			ShowPinForProperties[i].bShowPin = Node.IntIndexRange1 > 0;
			RangeList[0] = Node.IntIndexRange1 > 0 ? TotalPinNum : 0;
			TotalPinNum = Node.IntIndexRange1 > 0 ? TotalPinNum * (Node.IntIndexRange1 + 1) : TotalPinNum;
		}
		else if (ShowPinForProperties[i].PropertyName == TEXT("ActiveIntChildIndex2"))
		{
			// SetPinVisibility(Node.IntIndexRange2 > 0, i);
			ShowPinForProperties[i].bShowPin = Node.IntIndexRange2 > 0;
			RangeList[1] = Node.IntIndexRange2 > 0 ? TotalPinNum : 0;
			TotalPinNum = Node.IntIndexRange2 > 0 ? TotalPinNum * (Node.IntIndexRange2 + 1) : TotalPinNum;
		}
		else if (ShowPinForProperties[i].PropertyName == TEXT("ActiveIntChildIndex3"))
		{
			// SetPinVisibility(Node.IntIndexRange3 > 0, i);
			ShowPinForProperties[i].bShowPin = Node.IntIndexRange3 > 0;
			RangeList[2] = Node.IntIndexRange3 > 0 ? TotalPinNum : 0;
			TotalPinNum = Node.IntIndexRange3 > 0 ? TotalPinNum * (Node.IntIndexRange3 + 1) : TotalPinNum;
		}
		else if (ShowPinForProperties[i].PropertyName == TEXT("ActiveBoolChildIndex1"))
		{
			// SetPinVisibility(Node.BoolIndexRange1 > 0, i);
			ShowPinForProperties[i].bShowPin = Node.BoolIndexRange1 > 0;
			RangeList[3] = Node.BoolIndexRange1 > 0 ? TotalPinNum : 0;
			TotalPinNum = Node.BoolIndexRange1 > 0 ? TotalPinNum * (Node.BoolIndexRange1 + 1) : TotalPinNum;
		}
		else if (ShowPinForProperties[i].PropertyName == TEXT("ActiveBoolChildIndex2"))
		{
			// SetPinVisibility(Node.BoolIndexRange2 > 0, i);
			ShowPinForProperties[i].bShowPin = Node.BoolIndexRange2 > 0;
			RangeList[4] = Node.BoolIndexRange2 > 0 ? TotalPinNum : 0;
			TotalPinNum = Node.BoolIndexRange2 > 0 ? TotalPinNum * (Node.BoolIndexRange2 + 1) : TotalPinNum;
		}
		else if (ShowPinForProperties[i].PropertyName == TEXT("ActiveBoolChildIndex3"))
		{
			ShowPinForProperties[i].bShowPin = Node.BoolIndexRange3 > 0;
			RangeList[5] = Node.BoolIndexRange3 > 0 ? TotalPinNum : 0;
			TotalPinNum = Node.BoolIndexRange3 > 0 ? TotalPinNum * (Node.BoolIndexRange3 + 1) : TotalPinNum;
		}
	}

	FOptionalPinManager::EvaluateOldShownPins(ShowPinForProperties, OldShownPins, this);

	// 限制一下动画筛选节点数量上限，避免输错个数导致爆仓
	TotalPinNum = FMath::Clamp(TotalPinNum, 1, 20);

	return TotalPinNum;
}

FString UAnimGraphNode_SelectList::_GetSelectPoseIndexTip(const int32 Index) const
{
	FString OutIndexTip = TEXT("");
	int32 CurIndex = Index;

	for (int32 i = RangeList.Num() - 1; i >= 0; i--)
	{
		if (RangeList[i] > 0)
		{
			OutIndexTip.Append(FString::FromInt(CurIndex / RangeList[i]) + TEXT(":"));
			CurIndex = CurIndex % RangeList[i];
		}
	}

	return OutIndexTip.Reverse();
}

#undef LOCTEXT_NAMESPACE
