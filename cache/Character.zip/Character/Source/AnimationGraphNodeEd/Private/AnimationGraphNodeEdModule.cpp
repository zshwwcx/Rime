#include "AnimationGraphNodeEdModule.h"
#include "Modules/ModuleManager.h"
#include "Textures/SlateIcon.h"

#define LOCTEXT_NAMESPACE "FAnimationGraphNodeEdModule"



void FAnimationGraphNodeEdModule::StartupModule()
{
	UE_LOG(LogInit, Log, TEXT("AnimationGraphNodeEdModule StartupModule!"));
}



void FAnimationGraphNodeEdModule::ShutdownModule()
{
	
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FAnimationGraphNodeEdModule, AnimationGraphNodeEd)
