/**
 * Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */
 
#include "AnimGraphNode_AIFacePlayer.h"
#include "EdGraphSchema_K2_Actions.h"
#include "Modules/ModuleManager.h"
#include "ToolMenus.h"

#include "Kismet2/CompilerResultsLog.h"
#include "GraphEditorActions.h"
#include "AssetRegistry/ARFilter.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "BlueprintActionFilter.h"
#include "BlueprintActionDatabaseRegistrar.h"
#include "EditorCategoryUtils.h"
#include "BlueprintNodeSpawner.h"
#include "Animation/AnimComposite.h"
#include "Animation/AnimSequence.h"
#include "Engine/Blueprint.h"
#include "Animation/AnimLayerInterface.h"
#include "Animation/AnimAttributes.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "DetailLayoutBuilder.h"
#include "Animation/AnimInstance.h"

#define LOCTEXT_NAMESPACE "UAnimGraphNode_AIFacePlayer"


UAnimGraphNode_AIFacePlayer::UAnimGraphNode_AIFacePlayer(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FText UAnimGraphNode_AIFacePlayer::GetTooltipText() const
{
	return LOCTEXT("NodeToolTip", "Play AI Face animation data");
}

FText UAnimGraphNode_AIFacePlayer::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return LOCTEXT("NodeTitle", "AI Face Player");
}

FText UAnimGraphNode_AIFacePlayer::GetMenuCategory() const
{
	return LOCTEXT("NodeCategory", "AI Face");
}

FString UAnimGraphNode_AIFacePlayer::GetNodeCategory() const
{
	return TEXT("Animation|Blends");
}

FLinearColor UAnimGraphNode_AIFacePlayer::GetNodeTitleColor() const
{
	return FLinearColor(0.2f, 0.8f, 0.2f);
}

void UAnimGraphNode_AIFacePlayer::ValidateAnimNodeDuringCompilation(USkeleton* ForSkeleton, FCompilerResultsLog& MessageLog)
{
	Super::ValidateAnimNodeDuringCompilation(ForSkeleton, MessageLog);
}

bool UAnimGraphNode_AIFacePlayer::DoesSupportTimeForTransitionGetter() const
{
	return true;
}

UAnimationAsset* UAnimGraphNode_AIFacePlayer::GetAnimationAsset() const
{
	return nullptr;
}

const TCHAR* UAnimGraphNode_AIFacePlayer::GetTimePropertyName() const
{
	return TEXT("PlayTime");
}

UScriptStruct* UAnimGraphNode_AIFacePlayer::GetTimePropertyStruct() const
{
	return FAnimNode_AIFacePlayer::StaticStruct();
}


#undef LOCTEXT_NAMESPACE
