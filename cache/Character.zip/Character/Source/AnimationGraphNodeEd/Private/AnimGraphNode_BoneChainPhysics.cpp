#include "AnimGraphNode_BoneChainPhysics.h"

#define LOCTEXT_NAMESPACE "UAnimGraphNode_BoneChainPhysics"

UAnimGraphNode_BoneChainPhysics::UAnimGraphNode_BoneChainPhysics(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FText UAnimGraphNode_BoneChainPhysics::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return LOCTEXT("NodeTitle", "Bone Chain Physics");
}


void UAnimGraphNode_BoneChainPhysics::ValidateAnimNodePostCompile(FCompilerResultsLog& MessageLog, UAnimBlueprintGeneratedClass* CompiledClass, int32 CompiledNodeIndex)
{
	UAnimGraphNode_SkeletalControlBase::ValidateAnimNodePostCompile(MessageLog, CompiledClass, CompiledNodeIndex);
}


#undef LOCTEXT_NAMESPACE