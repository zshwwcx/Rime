#include "AnimGraphNode_FaceControl.h"

#include "Animation/AnimationSettings.h"
#include "Kismet2/CompilerResultsLog.h"

/////////////////////////////////////////////////////
// UAnimGraphNode_FaceControl

#define LOCTEXT_NAMESPACE "FaceControl"

UAnimGraphNode_FaceControl::UAnimGraphNode_FaceControl(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FLinearColor UAnimGraphNode_FaceControl::GetNodeTitleColor() const
{
	return FLinearColor(0.75f, 0.75f, 0.75f);
}

FText UAnimGraphNode_FaceControl::GetTooltipText() const
{
	return LOCTEXT("AnimGraphNode_FaceControl_Tooltip", "");
}

FText UAnimGraphNode_FaceControl::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return LOCTEXT("FaceControl", "FaceControl");
}

FString UAnimGraphNode_FaceControl::GetNodeCategory() const
{
	return TEXT("Animation|Face");
}

void UAnimGraphNode_FaceControl::ValidateAnimNodeDuringCompilation(class USkeleton* ForSkeleton, class FCompilerResultsLog& MessageLog)
{
	Super::ValidateAnimNodeDuringCompilation(ForSkeleton, MessageLog);
}
#undef LOCTEXT_NAMESPACE
