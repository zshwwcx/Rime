#pragma once

#include "AnimGraphNode_Base.h"
#include "3C/Animation/AnimationGraphNode/AnimNode_BoneChainPhysics.h"
#include "AnimGraphNode_SkeletalControlBase.h"

#include "AnimGraphNode_BoneChainPhysics.generated.h"

UCLASS()
class UAnimGraphNode_BoneChainPhysics : public UAnimGraphNode_SkeletalControlBase
{
	GENERATED_UCLASS_BODY()

	UPROPERTY(EditAnywhere, Category=Setting)
	FAnimNode_BoneChainPhysics Node;

public:
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;

protected:
	virtual void ValidateAnimNodePostCompile(FCompilerResultsLog& MessageLog, UAnimBlueprintGeneratedClass* CompiledClass, int32 CompiledNodeIndex) override;
	virtual const FAnimNode_SkeletalControlBase* GetNode() const override { return &Node; }
};