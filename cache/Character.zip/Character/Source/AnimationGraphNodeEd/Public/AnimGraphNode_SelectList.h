// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "AnimGraphNode_BlendListBase.h"
#include "3C/Animation/AnimationGraphNode/AnimNode_SelectList.h"
#include "AnimGraphNode_SelectList.generated.h"

UCLASS()
class UAnimGraphNode_SelectList : public UAnimGraphNode_Base
{
	GENERATED_UCLASS_BODY()

	UPROPERTY(EditAnywhere, Category=Settings)
	FAnimNode_SelectList Node;

	// UEdGraphNode interface
	virtual FText GetTooltipText() const override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	virtual FLinearColor GetNodeTitleColor() const override;
	// End of UEdGraphNode interface

	// UAnimGraphNode_Base interface
	virtual void CustomizePinData(UEdGraphPin* Pin, FName SourcePropertyName, int32 ArrayIndex) const override;
	// End of UAnimGraphNode_Base interface

	// UObject interface
	virtual void Serialize(FArchive& Ar) override;
	// End of UObject interface

	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

private:
	void UpdateInputPin();
	int32 _UpdatePinVisibility();
	FString _GetSelectPoseIndexTip(const int32 Index) const;

private:
	TArray<int32> RangeList = { 0,0,0,0,0,0 };
};
