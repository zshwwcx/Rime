/**
 * Auth :   liubo
 * Date :   2026-02-07 15:21
 * Comment: 实验功能，有很多临时代码，不要正式使用
 */
 
#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "EdGraph/EdGraphNodeUtils.h"
#include "AnimGraphNode_Base.h"
#include "AnimGraphNode_SkeletalControlBase.h"
#include "IAnimBlueprintCompilationContext.h"
#include "IAnimBlueprintGeneratedClassCompiledData.h"
#include "Animation/AnimationAsset.h"
#include "3C/Animation/AnimationGraphNode/AnimNode_AIFacePlayer.h"
#include "AnimGraphNode_AIFacePlayer.generated.h"



UCLASS(MinimalAPI, Experimental)
class UAnimGraphNode_AIFacePlayer : public UAnimGraphNode_Base
{
	GENERATED_UCLASS_BODY()
public:

	UPROPERTY(EditAnywhere, Category = Settings)
	FAnimNode_AIFacePlayer Node;

public:
	// 只保留基本的必需方法
	virtual FText GetTooltipText() const override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	virtual FText GetMenuCategory() const override;
	virtual FLinearColor GetNodeTitleColor() const override;
	virtual FString GetNodeCategory() const override;

	// 基本的AnimGraphNode接口
	virtual void ValidateAnimNodeDuringCompilation(USkeleton* ForSkeleton, FCompilerResultsLog& MessageLog) override;
	virtual bool DoesSupportTimeForTransitionGetter() const override;
	virtual UAnimationAsset* GetAnimationAsset() const override;
	virtual const TCHAR* GetTimePropertyName() const override;
	virtual UScriptStruct* GetTimePropertyStruct() const override;
};

