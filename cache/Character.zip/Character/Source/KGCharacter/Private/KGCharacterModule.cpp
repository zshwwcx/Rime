#include "KGCharacterModule.h"
#include "Core.h"
#if ALLOW_CONSOLE
#include "Engine/Console.h"
#include "3C/Camera/CameraManagerExtension.h"
#endif
#include "AvatarCreatorModule.h"
#include "3C/RoleComposite/RoleCompositeManager.h"
#include "Modules/ModuleManager.h"

#if __has_include("CxxReflectionKGCharacter.h")
#include "CxxReflectionKGCharacter.h"
#endif

#define LOCTEXT_NAMESPACE "FKGCharacterModule"

DEFINE_LOG_CATEGORY(LogKGCharacter);
DEFINE_LOG_CATEGORY(LogKGCombat);

void FKGCharacterModule::StartupModule()
{
	UE_LOG(LogInit, Log, TEXT("KGCharacterModule StartupModule!"));
	
#if (ALLOW_CONSOLE && UE_BUILD_DEVELOPMENT)
	UConsole::RegisterConsoleAutoCompleteEntries.AddStatic(&FCameraManagerExtension::PopulateAutoCompleteEntries);
#endif

#if __has_include("CxxReflectionKGCharacter.h") && !defined(KG_CXX_REFLECTING)
	REGISTER_LAZY_REGISTER(KGCharacter);
#endif

	FAvatarCreatorModule& AvatarCreatorModule = FModuleManager::Get().LoadModuleChecked<FAvatarCreatorModule>("AvatarCreator");
	AvatarCreatorModule.EnableAnimTickOptimization.BindStatic(&ULowLevelFunctions::EnableAnimTickOptimization);
	AvatarCreatorModule.UseParentCapsuleComponentBound.BindStatic(&URoleCompositeMgr::UseParentCapsuleComponentBound);
	AvatarCreatorModule.EnableSKMeshOptimization.BindStatic(&ULowLevelFunctions::EnableSKMeshOptimization);
}

void FKGCharacterModule::ShutdownModule()
{
}

IMPLEMENT_MODULE(FKGCharacterModule, KGCharacter)

#undef LOCTEXT_NAMESPACE