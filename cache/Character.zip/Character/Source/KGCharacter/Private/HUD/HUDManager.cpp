#include "HUD/HUDManager.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Controller/BasePlayerController.h"
#include "Manager/KGPlatformScalabilitySettings.h"
#include "3C/Character/C7Actor.h"
#include "3C/Core/C7ActorInterface.h"
#include "3C/Core/KGUEActorManager.h"
#include "Blueprint/GameViewportSubsystem.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "C7/KGTabClose.h"
#include "HUD/UmgProxy.h"
#include "HUD/Joystick/SKGVirtualJoystick.h"
#include "Engine/World.h"
#include "GameFramework/PlayerController.h"
#include "HUD/ActorPickerComponent.h"
#include "Lua/KGLuaEntityBase.h"
#include "HUD/DamageEffectComponent.h"
#include "HUD/MiniMapComponent.h"
#include "Managers/KGDataCacheManager.h"
#include "HUD/Debug/SKGDebugFPS.h"
#if WITH_EDITOR
#include "Editor.h"
#endif

DEFINE_LOG_CATEGORY(LogHUDManager);


using namespace NS_SLUA;
namespace NS_SLUA
{
    using namespace std;
    
    template <typename T>
    struct TLuaUtility;

    template <typename T>
    struct TLuaUtilityValue
    {
        static void Fill(T& Out, lua_State* L, int32 Index)
        {
            Out = LuaObject::checkValue<T>(L, Index);
        }
    };
    
    template <typename T>
    struct TLuaUtilityEnumValue
    {
        static void Fill(T& Out, lua_State* L, int32 Index)
        {
            Out = LuaObject::checkEnumValue<T>(L, Index);
        }
    };

    template <typename T>
    struct TLuaUtilityObject
    {
        static void Fill(T*& Out, lua_State* L, int32 Index)
        {
            Out = LuaObject::checkUD<T>(L, Index);
        }
    };
        
    template <typename T>
    struct TLuaUtilityArray
    {
        static void Fill(TArray<T>& Out, lua_State* L, int32 Index)
        {
            // 检查索引位置是否为表
            if(lua_istable(L, Index))
            {
                int32 ArrayLength = lua_objlen(L, Index);
                Out.Reset(ArrayLength);
                
                // 遍历 Lua table 的每个元素
                for(int32 i = 1; i <= ArrayLength; ++i)
                {
                    lua_rawgeti(L, Index, i);  // 将第i个元素压入栈顶
                    
                    T Element;
                    TLuaUtility<T>::Fill(Element, L, lua_gettop(L));  // 递归调用 Fill 方法
                    Out.Add(Element);
                    
                    lua_pop(L, 1);  // 弹出当前元素
                }
            }
        }
    };
    
    template<typename T>
    struct TLuaUtilityBase {
        using type = conditional_t<is_base_of_v<UObject, T> || is_same_v<UObject, T>, TLuaUtilityObject<T>,
            conditional_t<is_enum_v<T>, TLuaUtilityEnumValue<T>, TLuaUtilityValue<T>>>;
    };

    template<typename T>
    struct TLuaUtilityBase<TArray<T>> {
        using type = TLuaUtilityArray<T>;
    };

    template <typename T>
    struct TLuaUtility : TLuaUtilityBase<T>::type
    {
    };
    
    template<>
    struct TLuaUtilityValue<FSoftObjectPath>
    {
        static void Fill(FSoftObjectPath& Out, lua_State* L, int32 Index)
        {
            if (lua_isstring(L, Index))
            {
                const char* Path = lua_tostring(L, Index);
                Out.SetPath(UTF8_TO_TCHAR(Path));
            }
        }
    };
    
    template<>
    struct TLuaUtilityValue<FVector2D>
    {
        static void Fill(FVector2D& Out, lua_State* L, int32 Index)
        {
            Out = FVector2D::ZeroVector;
            if(lua_istable(L, Index))
            {
                int32 ArrayLength = lua_objlen(L, Index);
                if (ArrayLength > 0)
                {
                    lua_rawgeti(L, Index, 1);
                    TLuaUtility<double>::Fill(Out.X, L, lua_gettop(L));
                    lua_pop(L, 1);
                    
                    lua_rawgeti(L, Index, 2);
                    TLuaUtility<double>::Fill(Out.Y, L, lua_gettop(L));
                    lua_pop(L, 1);
                }
                else
                {
                    lua_pushstring(L, "X");
                    lua_rawget(L, Index);
                    TLuaUtility<double>::Fill(Out.X, L, lua_gettop(L));
                    lua_pop(L, 1);
                    
                    lua_pushstring(L, "Y");
                    lua_rawget(L, Index);
                    TLuaUtility<double>::Fill(Out.Y, L, lua_gettop(L));
                    lua_pop(L, 1);
                    
                }
            }
        }
    };
    
#define PARSE_FROM(prop) \
    if (!FCStringAnsi::Strcmp(Key, #prop)) { \
        using PropType = remove_pointer_t<decltype(remove_cvref_t<decltype(Result)>::prop)>; \
        TLuaUtility<PropType>::Fill(Result.prop, L, -1); \
        continue; \
    } 
    
    template <>
    FDamageTextConfig LuaObject::checkValue<FDamageTextConfig>(lua_State* L, int p)
    {
        AutoStack As(L);
        luaL_checktype(L, p, LUA_TTABLE);
        FDamageTextConfig Result;
        lua_pushnil(L);
        while (lua_next(L, 2) != 0)
        {
            const char* Key = lua_tostring(L, -2);
            {
                ON_SCOPE_EXIT { lua_pop(L, 1); };
                PARSE_FROM(DamageType);
                PARSE_FROM(StatePriority);
                PARSE_FROM(PushHeight);
                PARSE_FROM(BornRate);
                PARSE_FROM(AfterBornRate);
                PARSE_FROM(BornTime);
                PARSE_FROM(DeadRate);
                PARSE_FROM(AfterBornStayTime);
                PARSE_FROM(RunDirection);
                PARSE_FROM(RunSpeed);
                PARSE_FROM(RunTime);
                PARSE_FROM(MountBias);
                PARSE_FROM(XAxisExtraBias);
                PARSE_FROM(FontSizeOnMobile);
                PARSE_FROM(FontSizeOnPC);
                PARSE_FROM(FmtStr);
                PARSE_FROM(SignStr);
            }
        }

        return MoveTemp(Result);
    }
#undef PARSE_FROM
}



void UHUDManager::NativeInit()
{
	Super::NativeInit();
#if WITH_EDITOR
    FEditorDelegates::OnSwitchBeginPIEAndSIE.AddUObject(this, &UHUDManager::OnSwitchBeginPIEAndSIE);
#endif

	UmgProxy = NewObject<UUmgProxy>(this, UUmgProxy::StaticClass(), FName(TEXT("UmgProxy")));
    ABasePlayerController::OnRequestVirtualJoystickInitVisible.BindUObject(this, &UHUDManager::OnRequestVirtualJoystickInitVisible);
    
	// WidgetPool.SetWorld(GetWorld());
	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UHUDManager, "SetJoystickSafeZoneOffset", &UHUDManager::SetJoystickSafeZoneOffset);
	REG_MANAGER_FUNC(UHUDManager, "SetJoystickFixedCenter", &UHUDManager::SetJoystickFixedCenter);
	REG_MANAGER_FUNC(UHUDManager, "SetJoystickThresholdForWalking", &UHUDManager::SetJoystickThresholdForWalking);
	REG_MANAGER_FUNC(UHUDManager, "SetJoystickVisible", &UHUDManager::SetJoystickVisible);
	REG_MANAGER_FUNC(UHUDManager, "AttachJoystick", &UHUDManager::AttachJoystick);
	REG_MANAGER_FUNC(UHUDManager, "SetJoystickDelayTimeForCancelRunning", &UHUDManager::SetJoystickDelayTimeForCancelRunning);
	REG_MANAGER_FUNC(UHUDManager, "SetGesture", &UHUDManager::SetGesture);
	REG_MANAGER_FUNC(UHUDManager, "SetCameraControlParams", &UHUDManager::SetCameraControlParams);
	REG_MANAGER_FUNC(UHUDManager, "SetCameraScaleRate", &UHUDManager::SetCameraScaleRate);
	REG_MANAGER_FUNC(UHUDManager, "SetCameraScaleX", &UHUDManager::SetCameraScaleX);
	REG_MANAGER_FUNC(UHUDManager, "SetCameraScaleY", &UHUDManager::SetCameraScaleY);
	REG_MANAGER_FUNC(UHUDManager, "SetCameraSlideRate", &UHUDManager::SetCameraSlideRate);
	REG_MANAGER_FUNC(UHUDManager, "SetCameraDeadZoneOffset", &UHUDManager::SetCameraDeadZoneOffset);
	REG_MANAGER_FUNC(UHUDManager, "SetCameraMoveSize", &UHUDManager::SetCameraMoveSize);
	REG_MANAGER_FUNC(UHUDManager, "ClearJoystickTouchData", &UHUDManager::ClearJoystickTouchData);
    REG_MANAGER_FUNC(UHUDManager, "SetCollisionChannelsForSceneActor", &UHUDManager::SetCollisionChannelsForSceneActor)
    REG_MANAGER_FUNC(UHUDManager, "ClearCollisionChannelsForSceneActor", &UHUDManager::ClearCollisionChannelsForSceneActor)
    REG_MANAGER_FUNC(UHUDManager, "SetCollisionChannelsForScreenClick", &UHUDManager::SetCollisionChannelsForScreenClick)
    REG_MANAGER_FUNC(UHUDManager, "ClearCollisionChannelsForScreenClick", &UHUDManager::ClearCollisionChannelsForScreenClick)
    REG_MANAGER_FUNC(UHUDManager, "SetSelectTargetPointerLimitDistance", &UHUDManager::SetSelectTargetPointerLimitDistance)

    REG_MANAGER_FUNC(UHUDManager, "LoadDamageTextStyles", &UHUDManager::LoadDamageTextStyles);
    REG_MANAGER_FUNC(UHUDManager, "RegisterDamageTextConfig", &UHUDManager::RegisterDamageTextConfig);
    REG_MANAGER_FUNC(UHUDManager, "UnregisterDamageTextConfig", &UHUDManager::UnregisterDamageTextConfig);
    REG_MANAGER_FUNC(UHUDManager, "ClearDamageTextConfigs", &UHUDManager::ClearDamageTextConfigs);
    REG_MANAGER_FUNC(UHUDManager, "PrepareDamageTextDependencies", &UHUDManager::PrepareDamageTextDependencies);

    REG_MANAGER_FUNC(UHUDManager, "ShowDebugFPS", &UHUDManager::ShowDebugFPS);
    REG_MANAGER_FUNC(UHUDManager, "CloseDebugFPS", &UHUDManager::CloseDebugFPS);
    REG_MANAGER_FUNC(UHUDManager, "SetPlayerOffset", &UHUDManager::SetPlayerOffset);
}

void UHUDManager::NativeUninit()
{
    ABasePlayerController::OnRequestVirtualJoystickInitVisible.Unbind();
	Super::NativeUninit();

	// 释放所有HUDComponent
	ReleaseAllHUDComponents();
	// 释放WidgetPool
	ReleaseWidgetPool();
}


void UHUDManager::OnPostLoadMapWithWorld(UWorld* World)
{
	if(World == nullptr || World->PersistentLevel == nullptr)
	{
		return;
	}
	TickFunction.UnRegisterTickFunction();
	TickFunction.Manager = this;
	TickFunction.TickGroup = ETickingGroup::TG_PrePhysics;
	TickFunction.RegisterTickFunction(World->PersistentLevel);
}

void UHUDManager::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

	QUICK_SCOPE_CYCLE_COUNTER(UHUDManager_Tick)
	
    if (IsValid(DamageEffectComponent))
    {
        DamageEffectComponent->Tick(DeltaTime);
    }

	if (DebugFPSWidget.IsValid())
	{
		DebugFPSWidget->OnTick(DeltaTime);
	}

    if (IsValid(MiniMapComponent))
    {
        MiniMapComponent->Tick(DeltaTime);
    }
}

TWeakObjectPtr<UKGUserWidget> UHUDManager::CreateHUDComponentWidget(TSubclassOf<UUserWidget> WidgetClass, int32 ZOrder)
{
	if (auto ComponentWidget = Cast<UKGUserWidget>(WidgetPool.GetOrCreateInstance(WidgetClass)))
	{
		ComponentWidget->AddToViewport(ZOrder);
        if(UGameViewportSubsystem* Subsystem = GEngine->GetEngineSubsystem<UGameViewportSubsystem>())
	    {
	        auto GameViewportWidgetSlot = Subsystem->GetWidgetSlot(ComponentWidget);
	        GameViewportWidgetSlot.bAutoRemoveOnWorldRemoved = false;
	        Subsystem->SetWidgetSlot(ComponentWidget, GameViewportWidgetSlot);
	    }
	    
		TWeakObjectPtr<UKGUserWidget> WidgetPtr(ComponentWidget);
		return WidgetPtr;
	}
	
	return nullptr;
}

void UHUDManager::AddHUDComponent(UHUDComponent* Component)
{
	ComponentList.Add(Component);
}

void UHUDManager::InitWidgetPool()
{
	if (!WidgetPool.IsInitialized())
	{
		WidgetPool.SetWorld(GetWorld());
	    if (UmgProxy->UIRoot.IsValid())
	    {
	        WidgetPool.SetOwningWidget(UmgProxy->UIRoot.Get());
	    }
	}
}

void UHUDManager::InitAllHUDComponents()
{
	// TODO. 这个函数似乎没调用
	if (!WidgetPool.IsInitialized())
	{
		WidgetPool.SetWorld(GetWorld());
	}
	
	for (auto Component: ComponentList)
	{
		Component->InitHUDComponent(this);
	}
}

void UHUDManager::InitClickEffectComponent(UKGBasicManager* InManager)
{
	// 点击特效component
	CECompIns = NewObject<UClickEffectComponent>();
	CECompIns->InitHUDComponent(this);
	AddHUDComponent(CECompIns);
}

void UHUDManager::InitDamageEffectComponent()
{
    if (DamageEffectComponent)
    {
        return;
    }
    
	DamageEffectComponent = NewObject<UDamageEffectComponent>(this, UDamageEffectComponent::StaticClass());
	if (DamageEffectComponent)
	{
		DamageEffectComponent->InitHUDComponent(this);

		int32 DamageTextPoolSize = 0;
		if (UKGPlatformScalabilitySettings* PSSettings = UKGPlatformScalabilitySettings::GetInstance(this))
		{
			DamageTextPoolSize = int32(PSSettings->GetScalabilityValue<float>("DamageEffect", "DamageTextPoolSize"));
		}
		else
		{
			UE_LOG(LogHUDManager, Warning, TEXT("[HUDManager] Failed to get scalability settings for DamageEffect"));
		}
		if (DamageTextPoolSize <= 0)
		{
			DamageTextPoolSize = 128;
			UE_LOG(LogHUDManager, Warning, TEXT("[HUDManager] DamageTextPoolSize is invalid, set to default value: %d"), DamageTextPoolSize);
		}
		DamageEffectComponent->InitDamageTextPool(DamageTextPoolSize);

		AddHUDComponent(DamageEffectComponent);
	}
}

void UHUDManager::InitActorPickerComponent()
{
    if (!ActorPickerComponent)
    {
        ActorPickerComponent = NewObject<UActorPickerComponent>(this, UActorPickerComponent::StaticClass());
        if (ActorPickerComponent)
        {
            ActorPickerComponent->InitHUDComponent(this);
            AddHUDComponent(ActorPickerComponent);
        }
    }
}

void UHUDManager::InitMiniMapComponent()
{
    if (!MiniMapComponent)
    {
        MiniMapComponent = NewObject<UMiniMapComponent>(this, UMiniMapComponent::StaticClass());
        if (MiniMapComponent)
        {
            MiniMapComponent->InitHUDComponent(this);
            AddHUDComponent(MiniMapComponent);
        }
    }
}

void UHUDManager::DestroyMinimapComponent()
{
    if (MiniMapComponent)
    {
        MiniMapComponent = nullptr;
    }
}

void UHUDManager::ReleaseAllHUDComponents()
{
	for (auto Component: ComponentList)
	{
		Component->DeInitHUDComponent();
	}
	ComponentList.Empty();
}

void UHUDManager::ReleaseWidgetPool()
{
	WidgetPool.ReleaseAll(true);
}

void UHUDManager::ReleaseWidgetToPool(UUserWidget* ComponentWidget, bool bReleaseSlate)
{
	WidgetPool.Release(ComponentWidget, bReleaseSlate);
}

void UHUDManager::ReleaseWidgetsToPool(TArray<UUserWidget*> ComponentWidgets, bool bReleaseSlate)
{
	WidgetPool.Release(ComponentWidgets, bReleaseSlate);
}

UHUDComponent* UHUDManager::GetHUDComponentByType(EHUDComponentType ComponentType)
{
	// TODO: 临时补充函数实现，解决cpp hotfix link报错，后续补充具体实现
	return nullptr;
}

void UHUDManager::SetUIRoot(class UWidget* InUIRoot) const
{
	if (UmgProxy)
	{
		UmgProxy->SetUIRoot(InUIRoot);
	}
}

void UHUDManager::OnSwitchBeginPIEAndSIE(bool bSimulateInEditor)
{
    if (!bSimulateInEditor)
    {
        AttachJoystick();
    	CallLuaFunction("ShowVirtualJoystick");
    }
}

#pragma region Joystick
void UHUDManager::ClearJoystickTouchData() const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->ClearAllTouchData();
	}
}

void UHUDManager::SetJoystickSafeZoneOffset(float LeftOffset, float TopOffset, float RightOffset, float BottomOffset) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetSafeZoneOffset(LeftOffset, TopOffset, RightOffset, BottomOffset);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetJoystickSafeZoneOffset: Left = %.4f, Top = %.4f, Right = %.4f Bottom = %.4f"),
			LeftOffset, TopOffset, RightOffset, BottomOffset);
	}
}

void UHUDManager::SetJoystickFixedCenter(bool bFixed) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetFixedCenter(bFixed);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetJoystickFixedCenter: bFixed = %s"), bFixed ? TEXT("true") : TEXT("false"));
	}
}

void UHUDManager::SetJoystickThresholdForWalking(float Threshold) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetThresholdForWalking(Threshold);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetJoystickThresholdForWalking: Threshold = %.4f"), Threshold);
	}
}

void UHUDManager::SetJoystickVisible(bool bInVisible)
{
    if (bVirtualJoystickVisible == bInVisible)
    {
        return;
    }
    
    bVirtualJoystickVisible = bInVisible;
	if (UWorld* World = GetWorld())
	{
		if (auto* PC = World->GetFirstPlayerController())
		{
			PC->SetVirtualJoystickVisibility(bInVisible);
			UE_LOG(LogHUDManager, Log, TEXT("[GameStage][HUDManager][Joystick]SetJoystickVisible: Visible = %s PC:%s"),
			    bInVisible ? TEXT("true") : TEXT("false"), *PC->GetFullName());
        }
	}
}

void UHUDManager::SetJoystickDelayTimeForCancelRunning(float InDelayTime) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetDelayTimeForCancelRunning(InDelayTime);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetJoystickDelayTimeForCancelRunning: delayTime = %.4f"), InDelayTime);
	}
}

void UHUDManager::SetGesture(uint32 InGestureMask, float InPinchCheckInterval, int32 InMaxTouchFingerCount) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetGesture(InGestureMask, InPinchCheckInterval, InMaxTouchFingerCount);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetGesture: GestureMask = %u, PinchCheckInterval=%.4f, MaxTouchFingerCount=%d"),
			InGestureMask, InPinchCheckInterval, InMaxTouchFingerCount);
	}
}

void UHUDManager::SetCameraControlParams(float InScaleRate, float InScaleX, float InScaleY, float InSlideRate, float InCameraMoveSizeX, float InCameraMoveSizeY, float InCameraDeadZoneOffset) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetCameraControlParams(InScaleRate, InScaleX, InScaleY, InSlideRate, InCameraMoveSizeX, InCameraMoveSizeY, InCameraDeadZoneOffset);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetCameraControlParams: ScaleRate = %.4f, ScaleX = %.4f ScaleY = %.4f, SlideRate = %.4f, CameraMoveSize = (%.4f, %.4f), CameraDeadZoneOffset = %.4f"),
			InScaleRate, InScaleX, InScaleY, InSlideRate, InCameraMoveSizeX, InCameraMoveSizeY, InCameraDeadZoneOffset)
	}
}

void UHUDManager::SetCameraScaleRate(float InScaleRate) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetCameraScaleRate(InScaleRate);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetCameraScaleRate: %.4f"), InScaleRate);
	}
}

void UHUDManager::SetCameraScaleX(float InScaleX) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetScaleX(InScaleX);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetScaleX: %.4f"), InScaleX);
	}
}

void UHUDManager::SetCameraScaleY(float InScaleY) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetScaleY(InScaleY);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetScaleY: %.4f"), InScaleY);
	}
}

void UHUDManager::SetCameraSlideRate(float InSlideRate) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetSlideRate(InSlideRate);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetSlideRate: %.4f"), InSlideRate);
	}
}

void UHUDManager::SetCameraDeadZoneOffset(float InCameraDeadZoneOffset) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetCameraDeadZoneOffset(InCameraDeadZoneOffset);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetCameraDeadZoneOffset: %.4f"), InCameraDeadZoneOffset);
	}
}

void UHUDManager::SetCameraMoveSize(float InCameraMoveSizeX, float InCameraMoveSizeY) const
{
	if (auto KGVirtualJoystick = GetVirtualJoystick(); KGVirtualJoystick.IsValid())
	{
		KGVirtualJoystick->SetCameraMoveSize(InCameraMoveSizeX, InCameraMoveSizeY);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetCameraMoveSize: %.4f, %.4f"), InCameraMoveSizeX, InCameraMoveSizeY);
	}
}

void UHUDManager::SetLockMouseOnDraggingCamera(bool bLockMouseOnDraggingCamera)
{
    auto KGVirtualJoystick = GetVirtualJoystick();
    if (KGVirtualJoystick.IsValid())
    {
        KGVirtualJoystick->SetLockMouseOnDraggingCamera(bLockMouseOnDraggingCamera);
        UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]SetLockMouseOnDraggingCamera: %s"),
            bLockMouseOnDraggingCamera ? TEXT("true") : TEXT("false"));
    }
}

void UHUDManager::AttachJoystick()
{
	auto KGVirtualJoystick = GetVirtualJoystick();
	if (KGVirtualJoystick.IsValid() && !KGVirtualJoystick->OnUsingLeftJoystick.IsBoundToObject(this))
	{
		KGVirtualJoystick->CacheGameViewportWidgetPath();
		KGVirtualJoystick->OnUsingLeftJoystick.AddUObject(this, &UHUDManager::OnUsingVirtualJoystick);
	    KGVirtualJoystick->OnMainTouchFingerBegan.AddUObject(this, &UHUDManager::OnMainTouchBegin);
	    KGVirtualJoystick->OnMainTouchFingerEnded.AddUObject(this, &UHUDManager::OnMainTouchEnd);
		UE_LOG(LogHUDManager, Log, TEXT("[HUDManager][Joystick]AttachJoystick: %p"), this);
	}
}

void UHUDManager::SetCollisionChannelsForSceneActor(const TArray<int32>& InChannelsForSceneActor) const
{
    if (ActorPickerComponent)
    {
        ActorPickerComponent->SetCollisionChannelsForSceneActor(InChannelsForSceneActor);
    }
}

void UHUDManager::ClearCollisionChannelsForSceneActor() const
{
    if (ActorPickerComponent)
    {
        ActorPickerComponent->ClearCollisionChannelsForSceneActor();
    }
}

void UHUDManager::SetCollisionChannelsForScreenClick(const TArray<int32>& InChannelsForScreenClick) const
{
    if (ActorPickerComponent)
    {
        ActorPickerComponent->SetCollisionChannelsForScreenClick(InChannelsForScreenClick);
    }
}

void UHUDManager::ClearCollisionChannelsForScreenClick() const
{
    if (ActorPickerComponent)
    {
        ActorPickerComponent->ClearCollisionChannelsForScreenClick();
    }
}

void UHUDManager::SetSelectTargetPointerLimitDistance(float InDistance) const
{
    if (ActorPickerComponent)
    {
        ActorPickerComponent->SetSelectTargetPointerLimitDistance(InDistance);
    }
}

void UHUDManager::OnMainTouchBegin(const FVector2D& Pos, const FGeometry& Geometry, const FPointerEvent& PointerEvent)
{
    if (ActorPickerComponent)
    {
        ActorPickerComponent->PrePick(Pos, Geometry, PointerEvent);
    }

    CallLuaFunction("OnMainTouchBegin", Pos, PointerEvent.GetPointerIndex(), PointerEvent.GetEffectingButton().GetFName());
}

void UHUDManager::OnMainTouchEnd(const FVector2D& Pos, const FGeometry& Geometry, const FPointerEvent& PointerEvent)
{
    if (ActorPickerComponent)
    {
        TArray<KGEntityID> EntitiesUIDSceneActor;
        TArray<KGEntityID> EntitiesUIDScreenClick;
        if (ActorPickerComponent->Pick(Pos, Geometry, PointerEvent, EntitiesUIDSceneActor, EntitiesUIDScreenClick)
            && (EntitiesUIDSceneActor.Num() > 0 || EntitiesUIDScreenClick.Num() > 0))
        {
            CallLuaFunction("OnActorPicked", EntitiesUIDSceneActor, EntitiesUIDScreenClick);
        }
    }

    if (auto* TabClose = Cast<UKGTabClose>(UKGBasicManager::GetManagerByType(EManagerType::EMT_TabClose)))
    {
        TabClose->OnScreenInput(PointerEvent);
    }
    
    CallLuaFunction("OnMainTouchEnd", Pos, PointerEvent.GetPointerIndex(), PointerEvent.GetEffectingButton().GetFName());
}

void UHUDManager::OnUsingVirtualJoystick(bool bUsingJoystick)
{
	CallLuaFunction("OnUsingVirtualJoystick", bUsingJoystick);
}

bool UHUDManager::OnRequestVirtualJoystickInitVisible()
{
    return bVirtualJoystickVisible;
}

void UHUDManager::BindWidgets(UWidget* InMapTagLayer, UWidget* InFrustrumWidget, UWidget* InPlayerWidget, UKGRichTextBlock* InTextCoordWidget)
{
    if (MiniMapComponent)
    {
        MiniMapComponent->BindWidgets(InMapTagLayer, InFrustrumWidget, InPlayerWidget, InTextCoordWidget);
    }
}

void UHUDManager::SetPlayerOffset(float InOffsetX, float InOffsetY) const
{
    if (MiniMapComponent)
    {
        MiniMapComponent->SetPlayerOffset(InOffsetX, InOffsetY);
    }
}

TSharedPtr<SKGVirtualJoystick> UHUDManager::GetVirtualJoystick() const
{
	if (UWorld* World = GetWorld())
	{
		if (auto* BasePC = Cast<ABasePlayerController>(World->GetFirstPlayerController()))
		{
			auto KGVirtualJoystick = BasePC->GetVirtualJoystick();
			if (KGVirtualJoystick.IsValid())
			{
				return KGVirtualJoystick;
			}
		}
	}

	return nullptr;
}

#pragma endregion

#pragma region 伤害跳字

void UHUDManager::BindDamageUserWidget(class UUserWidget* InUserWidget, KGEntityID InEntityID, class UWidgetAnimation* InAnimation)
{
	if (!IsValidLowLevel() || !IsValid(this))
	{
		return;
	}
	
	if (!DamageEffectComponent )
	{
		InitDamageEffectComponent();
	}

	if (DamageEffectComponent)
	{
		DamageEffectComponent->BindDamageUserWidget(InUserWidget, InEntityID, InAnimation);
	}
}

void UHUDManager::UnbindDamageUserWidget(class UUserWidget* InUserWidget, KGEntityID InEntityID)
{
	if (!IsValidLowLevel() || !IsValid(this))
	{
		return;
	}
	
	if (DamageEffectComponent)
	{
		DamageEffectComponent->UnbindDamageUserWidget(InUserWidget, InEntityID);
	}
}

void UHUDManager::LoadDamageTextStyles(const FString& InDmgTextStyleDataTablePath) const
{
    if (!IsValidLowLevel() || !IsValid(this))
    {
        return;
    }
    
    if (IsValid(DamageEffectComponent))
    {
        DamageEffectComponent->LoadDamageTextStyle(InDmgTextStyleDataTablePath);
    }
}

void UHUDManager::RegisterDamageTextConfig(const FDamageTextConfig& InConfig) const
{
    if (!IsValidLowLevel() || !IsValid(this))
    {
        return;
    }
    
    if (IsValid(DamageEffectComponent))
    {
        DamageEffectComponent->RegisterDamageTextConfig(InConfig);
    }
}

void UHUDManager::UnregisterDamageTextConfig(int32 InDamageType) const
{
    if (!IsValidLowLevel() || !IsValid(this))
    {
        return;
    }
    
    if (IsValid(DamageEffectComponent))
    {
        DamageEffectComponent->UnregisterDamageTextConfig(InDamageType);
    }
}

void UHUDManager::ClearDamageTextConfigs() const
{
    if (!IsValidLowLevel() || !IsValid(this))
    {
        return;
    }
    
    if (IsValid(DamageEffectComponent))
    {
        DamageEffectComponent->ClearDamageTextConfigs();
    }
}

void UHUDManager::PrepareDamageTextDependencies() const
{
    if (!IsValidLowLevel() || !IsValid(this))
    {
        return;
    }
    
    if (IsValid(DamageEffectComponent))
    {
        DamageEffectComponent->PrepareAllDependencies();
    }
}

void UHUDManager::AddChannelSystemInfo(const FString& Text, const FString& ChannalTypeKey)
{
	CallLuaFunction("KCB_AddChannelSystemInfo", Text, ChannalTypeKey);
}

void UHUDManager::PlayDamageEffectOfTeamHUD(KGEntityID DefenderID)
{
	// TODO: Implement team HUD damage effect logic
	// 如果出现DefenderID不是自己的队友，那么上层队友缓存数据的更新维护有问题，需要检查

	if (DamageEffectComponent)
	{
		DamageEffectComponent->PlayDamageEffectOfTeamHUD(DefenderID);
	}
}

void UHUDManager::PlayDamageEffectOfGroupHUD(KGEntityID DefenderID)
{
	if (DamageEffectComponent)
	{
		DamageEffectComponent->PlayDamageEffectOfGroupHUD(DefenderID);
	}
}

void UHUDManager::PlayDamageEffectOfHeadInfoHUD(KGEntityID AttakerID, KGEntityID DefenderID, EDamageType1 Type1, EDamageType2 Type2)
{
	//TODO ref:function function HeadInfoFlag_OnTakeDamage:OnTakeDamage(damageCtx)
}


void UHUDManager::PlayDamageEffectOfDungeonReviveSystem()
{
	// TODO: Implement the dungeon revive system damage effect logic
	//REF
	/*
	---全屏受击提示
function DungeonReviveSystem:FullscreenHitFeedback(params)
	if Game.DamageEffectSystem:CheckIsDamage(params) and Game.NewUIManager:IsFullScreenUIOpen() then
		if not self.hitCD or _G._now(1) > self.hitCD then
			---检查是否在全屏界面上
			self.hitCD = _G._now(1) + Game.TableData.GetConstDataRow("BEATEN_HINT_COOLDOWN")
			UI.ShowUI("P_DungeonOutHurt")
		end
	end
end
	
	*/
}

void UHUDManager::PlayDamageTextV2(KGEntityID DefenderID, EDamageType DamageType, EDamageMethod DamageMethod, int32 TotalDamage, int32 RealDamage, float ShieldCost, KGEntityID InMainPlayerEntityID)
{
	if (DamageEffectComponent)
	{
		DamageEffectComponent->PlayDamageTextV2(DefenderID, DamageType, DamageMethod, TotalDamage, RealDamage, ShieldCost, InMainPlayerEntityID);
	}
}

void UHUDManager::PlayHealTextV2(KGEntityID DefenderID, int32 TotalHeal, KGEntityID InMainPlayerEntityID)
{
	if (DamageEffectComponent)
	{
		DamageEffectComponent->PlayHealTextV2(DefenderID, TotalHeal, InMainPlayerEntityID);
	}
}

void UHUDManager::PlayImmuneTextV2(KGEntityID DefenderID, KGEntityID InMainPlayerEntityID)
{
	if (DamageEffectComponent)
	{
		DamageEffectComponent->PlayImmuneTextV2(DefenderID, InMainPlayerEntityID);
	}
}

void UHUDManager::PlayHealLimitTextV2(KGEntityID DefenderID, KGEntityID InMainPlayerEntityID)
{
	if (DamageEffectComponent)
	{
		DamageEffectComponent->PlayHealLimitTextV2(DefenderID, InMainPlayerEntityID);
	}
}

void UHUDManager::PlayContinueDamage(KGEntityID DefenderID, EDamageType1 Type1, int NewTotalValue)
{
	//TODO: Implement logic to play continue damage effect ON HUD
}

KGEntityID UHUDManager::GetLockTargetEntityID()
{
	return KG_INVALID_ENTITY_ID; // TODO: Implement logic to return the locked target entity ID
}

FString UHUDManager::CustomPrintf(const FString& Format, const TArray<FString>& ArgumentStrings)
{
	// 如果格式字符串为空，直接返回空字符串
	if (Format.IsEmpty())
	{
		return FString();
	}

	// 如果没有参数，直接返回原格式字符串（移除所有格式说明符）
	if (ArgumentStrings.Num() == 0)
	{
		FString Result = Format;
		// 移除所有的 %s, %S, %d, %D
		Result = Result.Replace(TEXT("%s"), TEXT(""), ESearchCase::IgnoreCase);
		Result = Result.Replace(TEXT("%d"), TEXT(""), ESearchCase::IgnoreCase);
		return Result;
	}

	// 复制格式字符串用于处理
	FString ProcessedFormat = Format;

	// 第一步：统一将所有格式说明符替换为 %s
	ProcessedFormat = ProcessedFormat.Replace(TEXT("%S"), TEXT("%s"), ESearchCase::IgnoreCase);
	ProcessedFormat = ProcessedFormat.Replace(TEXT("%D"), TEXT("%s"), ESearchCase::IgnoreCase);

	// 第二步：使用 %s 分割字符串
	// 如果考虑 %% 转义字符，%%s 这样的写法会有问题，不过我们这里填入的都是中文，理论上不会出现这种情况，先不考虑
	TArray<FString> FormatParts;
	ProcessedFormat.ParseIntoArray(FormatParts, TEXT("%s"), false); // false 表示保留空字符串

	// 第三步：拼接结果
	FString Result;
	Result.Reserve(ProcessedFormat.Len() + 100);
	int32 ArgIndex = 0;

	for (int32 i = 0; i < FormatParts.Num(); ++i)
	{
		// 添加格式部分
		Result += FormatParts[i];

		// 在格式部分之间插入参数（最后一个部分后面不插入参数）
		if (i < FormatParts.Num() - 1)
		{
			if (ArgIndex < ArgumentStrings.Num())
			{
				// 有可用参数，插入参数
				Result += ArgumentStrings[ArgIndex];
				ArgIndex++;
			}
			// 如果没有可用参数，就不插入任何内容（相当于移除 %s）
			else
			{
				UE_LOG(LogHUDManager, Warning, TEXT("UHUDManager::CustomPrintf - Not enough arguments for format string: %s"), *Format);
			}
		}
	}

	// 如果有剩余的参数，记录警告信息
	if (ArgIndex < ArgumentStrings.Num())
	{
		UE_LOG(LogHUDManager, Warning, TEXT("UHUDManager::CustomPrintf - Too many arguments for format string: %s"), *Format);
	}

	return Result;
}

void UHUDManager::ShowDebugFPS()
{
	if (UWorld* World = GetWorld())
	{
		if (World->GetGameViewport())
		{
			DebugFPSWidget = SNew(SKGDebugFPS);

			//Using a ZOrder of INDEX_NONE as this causes it to get added on top of all other active widgets
			const int32 ZOrder = INDEX_NONE;
			World->GetGameViewport()->AddViewportWidgetContent(DebugFPSWidget.ToSharedRef(), ZOrder);
		}
	}
}

void UHUDManager::CloseDebugFPS()
{
	if (UWorld* World = GetWorld())
	{
		if (DebugFPSWidget.IsValid())
		{
			World->GetGameViewport()->RemoveViewportWidgetContent(DebugFPSWidget.ToSharedRef());
			DebugFPSWidget.Reset();
		}
	}
}


#pragma endregion

#pragma region ClickEffects
void UHUDManager::SetClickEffectParams(int32 ShowNum)
{
	if (CECompIns)
	{
		CECompIns->SetClickEffectNum(ShowNum);
	}
}

void UHUDManager::SetClickEffectVisibility(bool bVisible)
{
	if (CECompIns)
	{
		CECompIns->SetClickEffectVisibility(bVisible);
	}
}

#pragma endregion
