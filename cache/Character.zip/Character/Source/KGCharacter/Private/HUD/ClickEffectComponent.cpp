// Fill out your copyright notice in the Description page of Project Settings.


#include "HUD/ClickEffectComponent.h"
#include "HUD/ClickEffect/ClickEffectPanel.h"
#include "HUD/HUDManager.h"
#include "Manager/KGCppAssetManager.h"

void UClickEffectComponent::InitHUDComponent(UKGBasicManager* InManager)
{
	Super::InitHUDComponent(InManager);

	if (auto Manager = Cast<UHUDManager>(InManager))
	{
		if (auto* Mgr = Manager->GetManagerByType(EManagerType::EMT_CppAssetManager))
		{
			if (auto* AssetMgr = Cast<UKGCppAssetManager>(Mgr))
			{
				WidgetAssetLoadID = AssetMgr->AsyncLoadAsset(WidgetClassPath, FAsyncLoadCompleteDelegate::CreateUObject(this, &UClickEffectComponent::OnPendingListAssetsLoad));
			}
		}
	}
}

void UClickEffectComponent::OnPendingListAssetsLoad(int InLoadID, UObject* LoadedAsset)
{
	if (InLoadID == WidgetAssetLoadID)
	{
		if (auto WidgetClass = Cast<UClass>(LoadedAsset))
		{
			if (auto HUDCppMgr =  Cast<UHUDManager>(HUDManager.Get()))
			{
				ClickWidget = HUDCppMgr->CreateHUDComponentWidget(WidgetClass, 350000);
			}
			if (auto ClickEffectPanel = Cast<UClickEffectPanel>(ClickWidget.Get()))
			{
				UKGBasicManager* KGInputProcessManager = HUDManager->GetManagerByType(EManagerType::EMT_KGInputProcessorManager);
				if (KGInputProcessManager)
				{
					ClickEffectPanel->InitData(KGInputProcessManager);	
				}
			}
		}
	}
}

void UClickEffectComponent::SetClickEffectNum(int32 Num)
{
	if (ClickWidget.IsValid())
	{
		if (auto ClickEffectPanel = Cast<UClickEffectPanel>(ClickWidget.Get()))
		{
			ClickEffectPanel->SetTotalClickEffectNum(Num);
		}
	}
}

void UClickEffectComponent::SetClickEffectVisibility(bool bVisible)
{
	if (ClickWidget.IsValid())
	{
		if (auto ClickEffectPanel = Cast<UClickEffectPanel>(ClickWidget.Get()))
		{
			ClickEffectPanel->SetClickEffectVisibility(bVisible);
		}
	}
}
