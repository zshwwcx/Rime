// Fill out your copyright notice in the Description page of Project Settings.
#include "HUD/MiniMapComponent.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "UMG/Components/KGMapTagLayer.h"
#include "Components/RichTextBlock.h"
#include "UMG/Components/KGRichTextBlock.h"


void UMiniMapComponent::InitHUDComponent(UKGBasicManager* InManager)
{
    Super::InitHUDComponent(InManager);

    UEActorManagerPtr = UKGUEActorManager::GetInstance(this);
    if (!UEActorManagerPtr.IsValid())
    {
        UE_LOG(LogTemp, Warning, TEXT("UKGUEActorManager is not valid in UKGDamageProcessManager"));
    }
}

void UMiniMapComponent::BindWidgets(UWidget* InMapTagLayer, UWidget* InFrustrumWidget, UWidget* InPlayerWidget, UKGRichTextBlock* InTextCoordWidget)
{
    MapTagLayerWidget = InMapTagLayer;
    FrustrumWidget = InFrustrumWidget;
    PlayerAxisWidget = InPlayerWidget;
    CoordinateWidget = InTextCoordWidget;
}

void UMiniMapComponent::SetMapData()
{
}

void UMiniMapComponent::Tick(float InDeltaTime)
{
	QUICK_SCOPE_CYCLE_COUNTER(UMiniMapComponent_Tick)
	
    if (!UEActorManagerPtr.IsValid())
    {
        UEActorManagerPtr = UKGUEActorManager::GetInstance(this);
        if (!UEActorManagerPtr.IsValid())
        {
            return;
        }
    }
    
    KGEntityID MainPlayerEntityID = UEActorManagerPtr->GetMainPlayerEntityID();
    if (MainPlayerEntityID == KG_INVALID_ENTITY_ID)
    {
        return;
    }
    
    KGActorID ActorID = UEActorManagerPtr->GetActorIDByEntityID(MainPlayerEntityID);
    if (ActorID == KG_INVALID_ENTITY_ID)
    {
        return;
    }
    
    if (auto* MainPlayerEntity = UEActorManagerPtr->GetLuaEntity(MainPlayerEntityID))
    {
        UpdatePlayerCoordinate(MainPlayerEntity);
        UpdatePlayerAxis(MainPlayerEntity);
    }
}

void UMiniMapComponent::UpdatePlayerAxis(ICppEntityInterface* InMainPlayerEntity)
{
    check(InMainPlayerEntity);

    float RotationOffset = 0.f;
    if (MapTagLayerWidget.IsValid())
    {
        UKGMapTagLayer* TagLayer = Cast<UKGMapTagLayer>(MapTagLayerWidget.Get());
        if (TagLayer)
        {
            RotationOffset = 180.f - TagLayer->GetWidgetShearByWorldRotation(FRotator(0, 0, 0)) * 180 / UE_PI;
        }
    }

    FRotator Rotation = InMainPlayerEntity->GetRotation();
    bool bOnMount = false;
    if (ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(UEActorManagerPtr->GetActorByEntityID(UEActorManagerPtr->GetMainPlayerEntityID())))
    {
        URoleMovementComponent* RoleMovement = BaseCharacter ? Cast<URoleMovementComponent>(BaseCharacter->GetMovementComponent()) : nullptr;
        const bool bIsMount = RoleMovement && RoleMovement->IsMount();
        const bool bIsRider = RoleMovement && RoleMovement->IsMountRider();
        bOnMount = bIsMount || bIsRider;
    }
    
    if (bOnMount)
    {
        // TODO: limunan, mount
        //  Rotation = 
    }

    float Yaw = Rotation.Yaw + RotationOffset;
    if (PlayerAxisWidget.IsValid() && !FMath::IsNearlyEqual(LastPlayerYaw, Yaw, 0.01f))
    {
        LastPlayerYaw = Yaw;
        PlayerAxisWidget->SetRenderTransformAngle(Yaw);
    }

    float PlayerYaw = RotationOffset;
    if (auto* PlayerController = UGameplayStatics::GetPlayerController(this, 0))
    {
        Rotation = PlayerController->K2_GetActorRotation();
        PlayerYaw += Rotation.Yaw;
    }

    if (FrustrumWidget.IsValid() && !FMath::IsNearlyEqual(LastViewYaw, PlayerYaw, 0.01f))
    {
        LastViewYaw = PlayerYaw;
        FrustrumWidget->SetRenderTransformAngle(PlayerYaw);
    }
}

void UMiniMapComponent::SetPlayerOffset(float InOffsetX, float InOffsetY)
{
    PlayerOffset.X = InOffsetX;
    PlayerOffset.Y = InOffsetY;
}

void UMiniMapComponent::UpdatePlayerCoordinate(ICppEntityInterface* InMainPlayerEntity)
{
    check(InMainPlayerEntity);
    FVector Location = InMainPlayerEntity->GetLocation();
    FInt64Point Coordinate = FInt64Point(FMath::FloorToInt(Location.X / 100 + PlayerOffset.X),
        FMath::FloorToInt(Location.Y / 100 + PlayerOffset.Y));
    if (CoordinateWidget.IsValid() && LastPlayerLocation != Coordinate)
    {
        FString CoordinateString = FString::Printf(TEXT("%lld %lld"), Coordinate.X, Coordinate.Y);
        LastPlayerLocation = Coordinate;
        CoordinateWidget->SetText(FText::FromString(*CoordinateString));
    }
}


