#include "HUD/ActorPickerComponent.h"

#include "3C/Core/C7ActorInterface.h"
#include "3C/Core/KGUEActorManager.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "HUD/HUDManager.h"


void UActorPickerComponent::PrePick(const FVector2D& Pos, const FGeometry& Geometry, const FPointerEvent& PointerEvent)
{
    PointerIndex = PointerEvent.GetPointerIndex();
    TouchDownPosInScreenSpace = PointerEvent.GetScreenSpacePosition();
}

bool UActorPickerComponent::Pick(const FVector2D& Pos, const FGeometry& Geometry, const FPointerEvent& PointerEvent, TArray<KGEntityID>& OutEntitiesUIDSceneActors, TArray<KGEntityID>& OutEntitiesUIDScreenClick)
{
     SCOPED_NAMED_EVENT(UHUDManager_PickEntities, FColor::Green);
    
    if (PointerIndex != PointerEvent.GetPointerIndex())
    {
        return false;
    }

    PointerIndex = 0;
    FVector2D LastPos = TouchDownPosInScreenSpace;
    TouchDownPosInScreenSpace = FVector2D::ZeroVector;
    
    FVector2D Delta = PointerEvent.GetScreenSpacePosition() - LastPos;
    if (Delta.SizeSquared() >= SelectTargetPointerLimitDistance * SelectTargetPointerLimitDistance)
    {
        UE_LOG(LogHUDManager, Log, TEXT("%s: distance >= %.2f"), ANSI_TO_TCHAR(__FUNCTION__), SelectTargetPointerLimitDistance)
        return false;
    }

    auto* UEActorManager = UKGUEActorManager::GetInstance(this);
    if (!UEActorManager || !IsValid(UEActorManager))
    {
        UE_LOG(LogHUDManager, Log, TEXT("%s: UKGUEActorManager is invalid"), ANSI_TO_TCHAR(__FUNCTION__));
        return false;
    }
    
    OutEntitiesUIDSceneActors.Empty();
    OutEntitiesUIDScreenClick.Empty();
    
    FVector2D ScreenPos = PointerEvent.GetScreenSpacePosition();
    FVector2D LocalPos = USlateBlueprintLibrary::AbsoluteToLocal(Geometry, ScreenPos);
    FVector2D PixelPos;
    FVector2D ViewportPos;
    USlateBlueprintLibrary::LocalToViewport(GetWorld(), Geometry, LocalPos, PixelPos, ViewportPos);
    FVector PosInWorldSpace;
    FVector DirectionInWorldSpace;
    if (!UGameplayStatics::DeprojectScreenToWorld(UGameplayStatics::GetPlayerController(GetWorld(), 0), PixelPos, PosInWorldSpace, DirectionInWorldSpace))
    {
        UE_LOG(LogHUDManager, Log, TEXT("%s: DeprojectScreenToWorld failed"), ANSI_TO_TCHAR(__FUNCTION__));
        return false;
    }
    
    FVector LineTraceStart = PosInWorldSpace;
    FVector LineTraceEnd = PosInWorldSpace + DirectionInWorldSpace * 20000;
    
    TArray<AActor*> IgnoreActors;
    TArray<FHitResult> HitResults;
    if (ChannelsForSceneActors.Num() > 0 &&
        UKismetSystemLibrary::LineTraceMultiForObjects(GetWorld(), LineTraceStart, LineTraceEnd, ChannelsForSceneActors, false, IgnoreActors, EDrawDebugTrace::None, HitResults, false, FLinearColor::Red, FLinearColor::Green, 1))
    {
        for (const auto& Hit : HitResults)
        {
            AActor* Actor = Hit.GetActor();
            if (Actor && Actor->Implements<UC7ActorInterface>())
            {
                int64 EntityUID = Cast<IC7ActorInterface>(Actor)->GetEntityUID();
                if (EntityUID != KG_INVALID_ENTITY_ID)
                {
                    OutEntitiesUIDSceneActors.Add(EntityUID);
                }
            }
        }
    }

    HitResults.Empty(HitResults.Max());

    if (ChannelsForScreenClick.Num() > 0 &&
        UKismetSystemLibrary::LineTraceMultiForObjects(GetWorld(), LineTraceStart, LineTraceEnd, ChannelsForScreenClick, false, IgnoreActors, EDrawDebugTrace::None, HitResults, false, FLinearColor::Red, FLinearColor::Green, 1))
    {
        for (const auto& Hit : HitResults)
        {
            AActor* Actor = Hit.GetActor();
            if (Actor && Actor->Implements<UC7ActorInterface>())
            {
                int64 EntityUID = Cast<IC7ActorInterface>(Actor)->GetEntityUID();
                if (EntityUID != KG_INVALID_ENTITY_ID)
                {
                    OutEntitiesUIDScreenClick.Add(EntityUID);
                }
            }
        }
    }
    
    return true;
}

void UActorPickerComponent::SetSelectTargetPointerLimitDistance(float InLimitDistance)
{
    SelectTargetPointerLimitDistance = InLimitDistance;
}

void UActorPickerComponent::SetCollisionChannelsForSceneActor(const TArray<int32>& InChannelsForSceneActor)
{
    for (int32 Channel : InChannelsForSceneActor)
    {
        ChannelsForSceneActors.Push(TEnumAsByte<EObjectTypeQuery>(Channel));
    }
}

void UActorPickerComponent::ClearCollisionChannelsForSceneActor()
{
    ChannelsForSceneActors.Empty();
}

void UActorPickerComponent::SetCollisionChannelsForScreenClick(const TArray<int32>& InChannelsForScreenClick)
{
    for (int32 Channel : InChannelsForScreenClick)
    {
        ChannelsForScreenClick.Push(TEnumAsByte<EObjectTypeQuery>(Channel));
    }
}

void UActorPickerComponent::ClearCollisionChannelsForScreenClick()
{
    ChannelsForScreenClick.Empty();
}
