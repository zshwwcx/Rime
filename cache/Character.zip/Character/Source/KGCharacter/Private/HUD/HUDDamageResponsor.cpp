#include  "HUD/HUDDamageResponsor.h"

#include "Blueprint/UserWidget.h"


void UHUDDamageResponsor::Bind(UUserWidget* InUserWidget,int64 InEntityID, UWidgetAnimation* InAnimOnDamage)
{
	UserWidget = InUserWidget;
	EntityID = InEntityID;
	AnimOnDamage = InAnimOnDamage;
}

void UHUDDamageResponsor::Unbind()
{
	UserWidget = nullptr;
	EntityID = INDEX_NONE;
	AnimOnDamage = nullptr;
}

void UHUDDamageResponsor::PlayDamage()
{
	if (AnimOnDamage && UserWidget)
	{
		UserWidget->PlayAnimation(AnimOnDamage);
	}
}
