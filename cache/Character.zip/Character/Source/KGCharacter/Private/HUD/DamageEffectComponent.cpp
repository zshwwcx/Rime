// Fill out your copyright notice in the Description page of Project Settings.


#include "HUD/DamageEffectComponent.h"
#include "UI/KGUIPlatformCustomSetting.h"
#include "Manager/KGCppAssetManager.h"
#include "Manager/KGPlatformScalabilitySettings.h"
#include "3C/Core/KGUEActorManager.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "C7/WorldWidget2/WorldWidget2.h"
#include "C7/WorldWidget2/WorldWidgetManager2.h"
#include "HUD/HUDDamageResponsor.h"
#include "HUD/HUDManager.h"
#include "UMG/Blueprint/KGDamageResponsor.h"
#include "UMG/Components/KGTextBlock.h"
#include "Managers/KGDamageProcessManager.h"
#include "slua.h"
#include "C7/WorldWidget2/DamageEffectLayer.h"


DEFINE_LOG_CATEGORY(LogHUDDamageEffect);
#pragma optimize( "", off )

#define ENABLE_DMG_LOG 0

bool GKGHideDamageTextWhenActorOutOfSight = false;
static FAutoConsoleVariableRef CVarSlateTraceNavigationConfig(
    TEXT("KG.DamageText.HideTextWhenActorOutofSight"),
    GKGHideDamageTextWhenActorOutOfSight,
    TEXT("True hide damage text when target actor is out of sight.")
);

float GKGDamageTextCheckActorRenderedThreshold = 0.2f;
static FAutoConsoleVariableRef CVarDamageTextCheckActorRenderInterval(
TEXT("KG.DamageText.CheckActorRenderedThreshold"),
GKGDamageTextCheckActorRenderedThreshold,
TEXT("Interval for checking target actor was rendered.")
    );

FString UDamageEffectComponent::Layer_Name;

void FDamageText::Reset()
{
    Config = nullptr;
    
    Location = FVector2D::ZeroVector;
    Scale = FVector2D::One();
    Opacity = 1.f;
    AnimTime = 0.f;
    DefenderID = KG_INVALID_ENTITY_ID;
    MainPlayerID = KG_INVALID_ENTITY_ID;
    bCritical = false;
    DamageValue = 0;
    AnimStep = EDamageTextAnimStep::NotPlaying;
    TimestampStart = 0;
}

FString FDamageText::GetDamageText() const
{
    if (Config && !Config->FmtStr.IsEmpty())
    {
        return FString::Format(*Config->FmtStr, {DamageValue});
    }

    return FString::FromInt(DamageValue);
}

FVector2D FDamageText::GetRandomStartLocation() const
{
    if (Config)
    {
        double XOffset = 0.0;
        if (Config->XAxisExtraBias.Num() > 1)
        {
            XOffset = FMath::RandRange(Config->XAxisExtraBias[0], Config->XAxisExtraBias[1]);
        }
        return Config->MountBias + FVector2D(XOffset, 0);
    }

    return FVector2D::ZeroVector;
}

bool FDamageText::IsCrit() const
{
    if (Config)
    {
        return IsCritDamageVisualType(Config->DamageType);
    }
    
    return false;
}

int32 FDamageText::GetFontSize() const
{
    int32 FontSize;
#if WITH_EDITOR
    const UKGUIPlatformCustomSetting* C7DPISettings = GetDefault<UKGUIPlatformCustomSetting>();
    if (C7DPISettings!= nullptr )
    {
        FontSize = C7DPISettings->EditorPreviewPlatform == EDPIScalePreviewPlatforms::PC ? Config->FontSizeOnPC : Config->FontSizeOnMobile;
    }
    else
    {
        FontSize = Config->FontSizeOnPC;
    }
#elif PLATFORM_ANDROID || PLATFORM_IOS
    FontSize = Config->FontSizeOnMobile;
#else
    FontSize = Config->FontSizeOnPC;
#endif

    return FontSize;
}

void FDamageTextHandle::Release()
{
    if (DamageText && Pool)
    {
        Pool->InternalRelease(DamageText);
        DamageText = nullptr;
        Pool = nullptr;
    }
    TimestampStart = 0;
}

FDamageTextHandle FDamageTextPool::Obtain(const FDamageTextConfig* const Config)
{
    SCOPED_NAMED_EVENT(FDamageTextPool_Obtain, FColor::Blue);
    FScopeLock Lock(&PoolCriticalSection);
    
    FDamageText* NewText;
    
    if (FreeList.Num() > 0)
    {
        NewText = FreeList.Pop();
    }
    else
    {
    	// Preallocate 初始化池大小，如果为空则等待回收，不能无限增加
#if ENABLE_DMG_LOG
        UE_LOG(LogTemp, Warning, TEXT("FDamageTextPool::Obtain: FreeList is empty!"));
#endif
    	return FDamageTextHandle(this, nullptr);
    }

	if (NewText)
	{
	    NewText->Reset();
	    NewText->Config = Config;
	}
    
    return FDamageTextHandle(this, NewText);
}

void FDamageTextPool::InternalRelease(FDamageText* DamageText)
{
    if (!DamageText)
    {
        return;
    }

    if (FreeList.Contains(DamageText))
    {
        return;
    }
    
    FScopeLock Lock(&PoolCriticalSection);
    
    // 安全检查：确保对象属于此池
    bool bIsValid = false;
    for (const auto& Ptr : AllObjects)
    {
        if (Ptr.Get() == DamageText)
        {
            bIsValid = true;
            break;
        }
    }
    
    if (!bIsValid)
    {
#if ENABLE_DMG_LOG
        UE_LOG(LogTemp, Error, TEXT("Attempted to release foreign FDamageText object!"));
#endif
        return;
    }
    
    DamageText->Reset();
    FreeList.Add(DamageText);
}

void FDamageTextPool::Preallocate(int32 Count)
{
    FScopeLock Lock(&PoolCriticalSection);
    
    const int32 CurrentCount = AllObjects.Num();
    if (Count <= CurrentCount)
    {
        return;
    }
    
    const int32 AddCount = Count - CurrentCount;
    for (int32 i = 0; i < AddCount; ++i)
    {
        AllObjects.Add(MakeUnique<FDamageText>());
        FreeList.Add(AllObjects.Last().Get());
    }
}

void FDamageTextPool::GetPoolStats(int32& OutActiveCount, int32& OutFreeCount) const
{
    FScopeLock Lock(&PoolCriticalSection);
    OutFreeCount = FreeList.Num();
    OutActiveCount = AllObjects.Num() - OutFreeCount;
}


void FDamageTextQueue::PushDamageText(const FDamageTextHandle& Handle, TArray<FDamageTextHandle>& OutRemoveHandle,  int32 MaxDisplayCount)
{
    SCOPED_NAMED_EVENT(FDamageTextQueue_PushDamageText, FColor::Cyan);
	if (!DamageTexts.IsEmpty())
	{
		int32 Index = DamageTexts.HeapPush(Handle);
	    FDamageTextHandle& Cur = DamageTexts[Index];
		int32 CurrentCount = 0;
		for (int32 DamageTextIndex = DamageTexts.Num() - 1; DamageTextIndex >= 0; DamageTextIndex--)
		{
		    if (DamageTextIndex != Index)
		    {
		        FDamageTextHandle& DamageTextOther = DamageTexts[DamageTextIndex];
		        if (DamageTextOther->DefenderID == Cur->DefenderID && DamageTextOther->AnimTime - Cur->AnimTime < DamageTextOther->Config->BornTime + DamageTextOther->Config->AfterBornStayTime)
		        {
					if (MaxDisplayCount <= 0 || CurrentCount < MaxDisplayCount - 1) {
						DamageTextOther->Location += DamageTextOther->Config->RunDirection * DamageTextOther->Config->PushHeight;
					}
					else if (!OutRemoveHandle.Contains(DamageTextOther)) {
						OutRemoveHandle.Emplace(DamageTextOther);
					}
					CurrentCount++;
		        }
		    }
		}
	}
    else
    {
    	DamageTexts.HeapPush(Handle);
    }
}

void FDamageTextQueue::RemoveDamageText(const FDamageTextHandle& Handle)
{
    DamageTexts.Remove(Handle);
    DamageTexts.Heapify();
}

void FDamageTextQueue::Clear()
{
    for (auto& Handle : DamageTexts)
    {
        Handle.Release();
    }
    DamageTexts.Empty();
}

void UDamageEffectComponent::InitHUDComponent(UKGBasicManager* InManager)
{
	HUDManager = InManager;
    Layer_Name = UWorldWidgetManager2::GetWorldWidgetLayerNameByEnum(EWorldWidgetLayerType2::DamageEffect);
    ensure(!Layer_Name.IsEmpty());
}

void UDamageEffectComponent::DeInitHUDComponent()
{
    for (auto& DamageTextQueue : DamageTextQueues)
    {
        DamageTextQueue.Value.Clear();
    }
    DamageTextQueues.Empty();
    
	for (auto& Pair : DamageResponsors)
	{
		if (IsValid(Pair.Value))
		{
			Pair.Value->Unbind();
		}
	}
	
	DamageResponsors.Empty();

    ClearPendingLoadAssets();

    DamageTextConfigs.Empty();
    DamageTextStyles.Empty();
}

void UDamageEffectComponent::BindDamageUserWidget(class UUserWidget* InUserWidget, int64 InEntityID, class UWidgetAnimation* InAnimation)
{
	if (DamageResponsors.Contains(InEntityID))
	{
		DamageResponsors[InEntityID]->Bind(InUserWidget, InEntityID, InAnimation);
	}
	else
	{
		auto* Responsor = NewObject<UHUDDamageResponsor>(this, UHUDDamageResponsor::StaticClass());
		DamageResponsors.Add(InEntityID, Responsor);
		Responsor->Bind(InUserWidget, InEntityID, InAnimation);
	}
}

void UDamageEffectComponent::UnbindDamageUserWidget(class UUserWidget* InUserWidget, int64 InEntityID)
{
	if (auto* ResponsorPtr = DamageResponsors.Find(InEntityID); IsValid(*ResponsorPtr))
	{
		(*ResponsorPtr)->Unbind();
	}
}

void UDamageEffectComponent::PlayDamageEffectOfTeamHUD(int64 DefenderID) const
{
	if (auto* Responsor = DamageResponsors.FindRef(DefenderID))
	{
		Responsor->PlayDamage();
	}
}

void UDamageEffectComponent::PlayDamageEffectOfGroupHUD(int64 DefenderID) const
{
	if (auto* Responsor = DamageResponsors.FindRef(DefenderID))
	{
		Responsor->PlayDamage();
	}
}

void UDamageEffectComponent::PlayDamageEffectOfChat(int64 AttackerID, int64 DefenderID, EDamageType1 Type1, EDamageType2 Type2, float HPDelta, float DamageWithShield)
{
	//TODO ref:function ChatSystem:DamageShow(Params)
}

void UDamageEffectComponent::PlayDamageEffectOfHeadInfoHUD(int64 AttakerID, int64 DefenderID, EDamageType1 Type1, EDamageType2 Type2)
{
	//TODO ref:function function HeadInfoFlag_OnTakeDamage:OnTakeDamage(damageCtx)
}


void UDamageEffectComponent::PlayDamageEffectOfDungeonReviveSystem()
{
	
}

void UDamageEffectComponent::LoadDamageTextStyle(const FString& InTextStyleDataTablePath)
{
    if (DamageTextStyleDataTablePath == InTextStyleDataTablePath)
    {
        return;
    }
    
    DamageTextStyleDataTablePath = InTextStyleDataTablePath;
    AddPendingLoadAsset(InTextStyleDataTablePath);
}

void UDamageEffectComponent::UnloadDamageTextStyle()
{
    DamageTextStyles.Empty();
}

const FDamageTextStyle* UDamageEffectComponent::GetDamageTextStyle(EDamageVisualType InDamageType) const
{
    if (auto* Style = DamageTextStyles.Find(InDamageType))
    {
        return Style;
    }
    
    return DamageTextStyles.Find(EDamageVisualType::Damage);
}

void UDamageEffectComponent::RegisterDamageTextConfig(const FDamageTextConfig& InConfig)
{
    int32 DamageType = static_cast<int32>(InConfig.DamageType);
    if (DamageTextConfigs.Contains(DamageType))
    {
#if ENABLE_DMG_LOG
        UE_LOG(LogHUDDamageEffect, Log, TEXT("[DamageEffect]RegisterDamageTextConfig faield: already existed.DamageType:%d"), DamageType);
#endif
        return;
    }
    
    DamageTextConfigs.Add(DamageType, InConfig);

    DamageTextQueues.FindOrAdd(InConfig.StatePriority);
}

const FDamageTextConfig* UDamageEffectComponent::GetDamageTextConfig(int32 InDamageType) const
{
    if (auto Config = DamageTextConfigs.Find(InDamageType))
    {
        return Config;
    }
    
    return nullptr;
}

int32 UDamageEffectComponent::GetDamageVisualType(bool bDamageOnThird, EDamageType DamageType, EDamageMethod DamageMethod)
{
	int32 DmgVisualType = static_cast<uint8>(EDamageVisualType::Unknown);
	if (bDamageOnThird)
	{
		DmgVisualType |= static_cast<uint8>(EDamageVisualType::ThirdFlag); 
	}
	else if (DamageMethod == EDamageMethod::Critical)
	{
		// 发生在玩家自身的暴击伤害算作普通伤害
		return static_cast<uint8>(EDamageVisualType::Damage);
	}
	
	switch (DamageMethod)
	{
	case EDamageMethod::NormalHit:
		DmgVisualType |= static_cast<uint8>(EDamageVisualType::Damage);
		break;
	case EDamageMethod::Blocked:
		DmgVisualType |= static_cast<uint8>(EDamageVisualType::Block);
		break;
	case EDamageMethod::Critical:
		DmgVisualType |= static_cast<uint8>(EDamageVisualType::Damage);
		DmgVisualType |= static_cast<uint8>(EDamageVisualType::CritFlag);
		break;
	default:
		DmgVisualType |= static_cast<uint8>(EDamageVisualType::Damage);
		break;
	}

	return DmgVisualType;
}

void UDamageEffectComponent::UpdateDamageText(FDamageTextHandle& DamageTextHandle, float DeltaTime, const TSharedPtr<SWorldWidgetDamageEffectLayer>& DmgLayer)
{
    float TimeDilation = 1.f;
    if (DamageTextHandle->DefenderID != KG_INVALID_ID)
    {
        if (auto* UEActorMgr = UKGUEActorManager::GetInstance(this))
        {
            if (auto* Actor = UEActorMgr->GetActorByEntityID(DamageTextHandle->DefenderID))
            {
                TimeDilation = Actor->CustomTimeDilation;
            }
        }
    }

    // 完美闪避后缓动表现缩放了时间，要求相关跳字的表现也要缩放
    DamageTextHandle->AnimTime += DeltaTime * TimeDilation;

    if (DamageTextHandle->AnimStep == EDamageTextAnimStep::Done)
    {
        return;
    }

    UpdateDamageTextAnimStep(DamageTextHandle);

    UpdateDamageTextTransform(DamageTextHandle, DeltaTime);

    bool bVisible = true;
    bool bCanTick = true;
    if (HUDManager.IsValid())
    {
        if (auto* UEActorManager = Cast<UKGUEActorManager>(UKGBasicManager::GetManagerByType(HUDManager->GetWorld(), EManagerType::EMT_UEActorManager)))
        {
            if (GKGHideDamageTextWhenActorOutOfSight)
            {
                if (AActor* Actor = UEActorManager->GetActorByEntityID(DamageTextHandle->DefenderID))
                {
                    bVisible = Actor->WasRecentlyRendered(GKGDamageTextCheckActorRenderedThreshold);
                }
            }

            if (ICppEntityInterface* Entity = UEActorManager->GetLuaEntityByActorID(DamageTextHandle->DefenderID))
            {
                bCanTick = !Entity->IsDead();
            }
        }
    }

    if (DamageTextHandle->DamageTextUIToken != SWorldWidgetDamageEffectLayer::INVALID_TOKEN && DmgLayer.IsValid())
    {
        DmgLayer->UpdateDamageText(DamageTextHandle->DamageTextUIToken, DamageTextHandle->Location, DamageTextHandle->Scale, DamageTextHandle->Opacity, bVisible, bCanTick);
    }
}

void UDamageEffectComponent::UpdateDamageTextAnimStep(FDamageTextHandle& DamageTextHandle)
{
	if (DamageTextHandle->AnimStep == EDamageTextAnimStep::NotPlaying)
	{
		DamageTextHandle->AnimStep = EDamageTextAnimStep::Scaling;
	}

	if (DamageTextHandle->AnimStep == EDamageTextAnimStep::Scaling)
	{
		if (DamageTextHandle->AnimTime >= DamageTextHandle->Config->BornTime)
		{
			DamageTextHandle->AnimStep = EDamageTextAnimStep::Stay;
		}
	}

	// StayTime 可以为 0，此时可以在当前帧直接转移到 MovingOut 状态
	if (DamageTextHandle->AnimStep == EDamageTextAnimStep::Stay)
	{
		if (DamageTextHandle->AnimTime >= (DamageTextHandle->Config->BornTime + DamageTextHandle->Config->AfterBornStayTime))
		{
			DamageTextHandle->AnimStep = EDamageTextAnimStep::MovingOut;
		}
	}
	else if (DamageTextHandle->AnimStep == EDamageTextAnimStep::MovingOut)
	{
		if (DamageTextHandle->AnimTime >= (DamageTextHandle->Config->BornTime + DamageTextHandle->Config->AfterBornStayTime + DamageTextHandle->Config->RunTime))
		{
			DamageTextHandle->AnimStep = EDamageTextAnimStep::Done;

			// 第一次转移到 Done 状态才添加到 DamageTextsPendingRemoved 数组中
			if (!DamageTextsPendingRemoved.Contains(DamageTextHandle)) {
				DamageTextsPendingRemoved.Emplace(DamageTextHandle);
			}
		}
	}
}

void UDamageEffectComponent::UpdateDamageTextTransform(FDamageTextHandle& DamageTextHandle, float DeltaTime)
{
	if (DamageTextHandle->AnimStep == EDamageTextAnimStep::Scaling)
	{
		const float Percent = FMath::Clamp(DamageTextHandle->AnimTime / DamageTextHandle->Config->BornTime, 0.f, 1.f);
		DamageTextHandle->Scale = FMath::Lerp(FVector2D(DamageTextHandle->Config->BornRate), FVector2D(DamageTextHandle->Config->AfterBornRate), Percent);
	}
	else if (DamageTextHandle->AnimStep == EDamageTextAnimStep::MovingOut)
	{
		float Percent = FMath::Clamp((DamageTextHandle->AnimTime - DamageTextHandle->Config->BornTime - DamageTextHandle->Config->AfterBornStayTime) / DamageTextHandle->Config->RunTime, 0.f, 1.f);

	    DamageTextHandle->Opacity = FMath::Lerp(1.0f, 0.f, Percent);
		DamageTextHandle->Location += DamageTextHandle->Config->RunDirection * DeltaTime * DamageTextHandle->Config->RunSpeed;
		DamageTextHandle->Scale = FMath::Lerp(FVector2D(DamageTextHandle->Config->AfterBornRate), FVector2D(DamageTextHandle->Config->DeadRate), Percent);
#if ENABLE_DMG_LOG
	    UE_LOG(LogHUDDamageEffect, Log, TEXT("DamageTextTransform Updated %f loc:%s scale:%s opacity:%f"),
	        DamageTextHandle->TimestampStart, *DamageTextHandle->Location.ToString(), *DamageTextHandle->Scale.ToString(), DamageTextHandle->Opacity);
#endif
	}
}

void UDamageEffectComponent::ProcessPendingRemovedTexts(const TSharedPtr<SWorldWidgetDamageEffectLayer>& DmgLayer)
{
    UHUDManager* HUDMgr = HUDManager.IsValid() ? Cast<UHUDManager>(HUDManager.Get()) : nullptr;
    if (!HUDMgr || !IsValid(HUDMgr))
    {
        return;
    }
    
    bool bNeedRebuildHeap = false;
    for (auto& Text : DamageTextsPendingRemoved)
    {
        if (Text)
        {
            int32 StatePriority = Text->Config->StatePriority;
            if (auto* Queue = DamageTextQueues.Find(StatePriority))
            {
                Queue->RemoveDamageText(Text);
            }

            if (DmgLayer.IsValid())
            {
                DmgLayer->RemoveDamageText(Text->DamageTextUIToken);
                bNeedRebuildHeap = true;
            }
            
            Text.Release();
        }
    }
    DamageTextsPendingRemoved.Empty();
    
    if (bNeedRebuildHeap && DmgLayer.IsValid())
    {
        DmgLayer->RebuildDamageTextItemsHeap();
    }
}

bool UDamageEffectComponent::IsEntityDead(int64 InEntityID)
{
    bool bIsDead = false;
    if (auto* UEActorMgr = UKGUEActorManager::GetInstance(this))
    {
        if (ICppEntityInterface* Entity = UEActorMgr->GetLuaEntity(InEntityID))
        {
            bIsDead = Entity->IsDead();
        }
    }
    
    return bIsDead;
}

void UDamageEffectComponent::ParseAllDamageTextStyle(const UDataTable* InDataTable)
{
    if (!IsValid(InDataTable))
    {
        return;
    }
    
    TArray<FDamageTextStyleBP*> AllRows;
    // 获取所有行
    InDataTable->GetAllRows<FDamageTextStyleBP>(TEXT("GetAllItems"), AllRows);
    for (auto* Style : AllRows)
    {
        DamageTextStyles.Add(Style->DamageType, Style->Style);
    }
}

void UDamageEffectComponent::AddDamageTextToDamageEffectLayer(const FDamageTextHandle& DamageTextHandle)
{
    if (!DamageTextHandle)
    {
        UE_LOG(LogHUDDamageEffect, Warning, TEXT("AddDamageTextToDamageEffectLayer Failed:invalid damage text handle."));
        return;
    }
    
    auto DamageEffectLayer = GetDamageEffectLayer();
    if (!DamageEffectLayer.IsValid())
    {
        UE_LOG(LogHUDDamageEffect, Warning, TEXT("AddDamageTextToDamageEffectLayer Failed:can not find damage effect layer."));
        return;
    }

    KGActorID RefActorID = KG_INVALID_ACTOR_ID;
    if (auto* UEActorMgr = UKGUEActorManager::GetInstance(this))
    {
        RefActorID = UEActorMgr->GetActorIDByEntityID(DamageTextHandle->DefenderID);
    }

    if (RefActorID == KG_INVALID_ACTOR_ID)
    {
        UE_LOG(LogHUDDamageEffect, Warning, TEXT("AddDamageTextToDamageEffectLayer failed:can not find the target actor,entity id:%lld"), DamageTextHandle->DefenderID);
        return;
    }    
    
    const FDamageTextStyle* TemplateStyle = GetDamageTextStyle(DamageTextHandle->Config->DamageType);
    if(!TemplateStyle)
    {
        UE_LOG(LogHUDDamageEffect, Error, TEXT("AddDamageTextToDamageEffectLayer failed:has config for damage type:%d, please check config in %s"),
            DamageTextHandle->Config->DamageType, *DamageTextStyleDataTablePath);
    }
    
    FDamageTextStyle Style = TemplateStyle ? *TemplateStyle : FDamageTextStyle();
    Style.Font.Size = DamageTextHandle->GetFontSize();

    int32 Token = DamageEffectLayer->ShowDamageText(RefActorID, DamageTextHandle->DamageValue, DamageTextHandle->GetDamageText(), Style, 0, NAME_None);
    auto& DmgTextItem = DamageEffectLayer->GetDamageTextItem(Token);
    if (!SWorldWidgetDamageEffectLayer::IsNull(DmgTextItem) && DmgTextItem.IsValid())
    {
        DamageTextHandle->DamageTextUIToken = Token;
        DmgTextItem.Location = DamageTextHandle->Location;
        DmgTextItem.Scale = DamageTextHandle->Scale;
        DmgTextItem.DamageValue = DamageTextHandle->DamageValue;
        DmgTextItem.Opacity = DamageTextHandle->Opacity;
        DmgTextItem.bCanTick = !IsEntityDead(DamageTextHandle->DefenderID);
        DmgTextItem.ZOrder = DamageTextHandle->CalculateZOrderOffset();
        DmgTextItem.SignStr = DamageTextHandle->Config->SignStr;
        DmgTextItem.SetVisibilityFlag(SWorldWidgetDamageEffectLayer::EDamageTextVisFlag::DTVisFlag_Visible);
    }
    else
    {
        UE_LOG(LogHUDDamageEffect, Warning, TEXT("AddDamageTextToDamageEffectLayer failed:can not find the damage text item,token:%d"), Token)
    }
}

void UDamageEffectComponent::UnregisterDamageTextConfig(int32 InDamageType)
{
    DamageTextConfigs.Remove(InDamageType);
}

void UDamageEffectComponent::ClearDamageTextConfigs()
{
    DamageTextConfigs.Empty();
}

void UDamageEffectComponent::PrepareAllDependencies()
{
    if (HUDManager.IsValid())
    {
        if (auto* Mgr = HUDManager->GetManagerByType(GetWorld(), EManagerType::EMT_CppAssetManager))
        {
            auto* AssetMgr = Cast<UKGCppAssetManager>(Mgr);

            TArray<UObject*> Assets;
            LoadIDForPendingLoadAssets = AssetMgr->AsyncLoadAsset(PendingLoadAssets, Assets, FAsyncLoadListCompleteDelegate::CreateUObject(this, &UDamageEffectComponent::OnPendingListAssetsLoad));
        }
    }
}

void UDamageEffectComponent::PlayDamageTextV2(KGEntityID DefenderID, EDamageType DamageType, EDamageMethod DamageMethod, int32 TotalDamage, int32 RealDamage, float ShieldCost, KGEntityID InMainPlayerEntityID)
{
	SCOPED_NAMED_EVENT(DamageEffectComponent_PlayDamageEffectTextV2, FColor::Green);
#if ENABLE_DMG_LOG
	UE_LOG(LogHUDDamageEffect, Log, TEXT("[DamageEffectComponent]PlayDamageTextV2 defender:%lld, damageValue:%d"), DefenderID, InDamageValue);
#endif
    
	bool bDamageOnThird = DefenderID != InMainPlayerEntityID;
	const float HpDelta = RealDamage - ShieldCost;

	// 既有护盾又有扣血，此时应该有两种跳字：护盾 + 扣血
	// etc. TotalDamage 500 角色剩余血量 100 RealDamage 200 ShieldCost 100 HpDelta 100 此时应该跳字： 吸收+100 -100

	// 护盾跳字
	if (ShieldCost >= KINDA_SMALL_NUMBER)
	{
		int32 DamageVisualType = static_cast<uint8>(EDamageVisualType::Shield);
		if (bDamageOnThird)
		{
			DamageVisualType |= static_cast<uint8>(EDamageVisualType::ThirdFlag); 
		}
		if (const auto* DmgTextConfig = GetDamageTextConfig(static_cast<int32>(DamageVisualType)))
		{
			if (FDamageTextHandle Handle = DamageTextPool.Obtain(DmgTextConfig))
			{
				bool bCritical = (DamageMethod == EDamageMethod::Critical);
				InitDamageText(Handle, ShieldCost, DefenderID, InMainPlayerEntityID, bCritical);

				if (auto* Queue = DamageTextQueues.Find(Handle->GetStatePriority()))
				{
					if (auto* Mgr = HUDManager->GetManagerByType(GetWorld(), EManagerType::EMT_DamageProcessManager))
					{
						auto* DamageProcessManager = Cast<UKGDamageProcessManager>(Mgr);
						int32 MaxDisplayCount = DamageProcessManager->GetDamageTextMaxDisplayCount();
						Queue->PushDamageText(Handle, DamageTextsPendingRemoved, MaxDisplayCount);
					}
					else {
						Queue->PushDamageText(Handle, DamageTextsPendingRemoved);
					}
				}
			}
		}
		else
		{
#if ENABLE_DMG_LOG
			UE_LOG(LogHUDDamageEffect, Log, TEXT("[HUDDamageEffect]PlayDamageTextV2 failed:has no config for DamageVisualType:%d"), static_cast<int32>(DamageVisualType));
#endif
		}
	}

	// 扣血跳字
	if (HpDelta >= KINDA_SMALL_NUMBER)
	{
		int32 DamageVisualType = GetDamageVisualType(bDamageOnThird, DamageType, DamageMethod);
		if (const auto* DmgTextConfig = GetDamageTextConfig(static_cast<int32>(DamageVisualType)))
		{
			if (FDamageTextHandle Handle = DamageTextPool.Obtain(DmgTextConfig))
			{
				bool bCritical = (DamageMethod == EDamageMethod::Critical);
				InitDamageText(Handle, HpDelta, DefenderID, InMainPlayerEntityID, bCritical);

				if (auto* Queue = DamageTextQueues.Find(Handle->GetStatePriority()))
				{
					if (auto* Mgr = HUDManager->GetManagerByType(GetWorld(), EManagerType::EMT_DamageProcessManager))
					{
						auto* DamageProcessManager = Cast<UKGDamageProcessManager>(Mgr);
						int32 MaxDisplayCount = DamageProcessManager->GetDamageTextMaxDisplayCount();
						Queue->PushDamageText(Handle, DamageTextsPendingRemoved, MaxDisplayCount);
					}
					else {
						Queue->PushDamageText(Handle, DamageTextsPendingRemoved);
					}
				}
			}
		}
		else
		{
	#if ENABLE_DMG_LOG
			UE_LOG(LogHUDDamageEffect, Log, TEXT("[HUDDamageEffect]PlayDamageTextV2 failed:has no config for DamageVisualType:%d"), static_cast<int32>(DamageVisualType));
	#endif
		}
	}
}

void UDamageEffectComponent::PlayHealTextV2(KGEntityID DefenderID, int32 TotalHeal, KGEntityID InMainPlayerEntityID)
{
	SCOPED_NAMED_EVENT(DamageEffectComponent_PlayHealEffectTextV2, FColor::Green);
#if ENABLE_DMG_LOG
	UE_LOG(LogHUDDamageEffect, Log, TEXT("[DamageEffectComponent]PlayHealTextV2 defender:%lld, damageValue:%d"), DefenderID, InDamageValue);
#endif
    
	bool bDamageOnThird = DefenderID != InMainPlayerEntityID;
	int32 DamageVisualType = static_cast<uint8>(EDamageVisualType::Unknown);
	if (bDamageOnThird)
	{
		DamageVisualType |= static_cast<uint8>(EDamageVisualType::ThirdFlag); 
	}
	DamageVisualType |= static_cast<uint8>(EDamageVisualType::Cure);
	if (const auto* DmgTextConfig = GetDamageTextConfig(static_cast<int32>(DamageVisualType)))
	{
		if (FDamageTextHandle Handle = DamageTextPool.Obtain(DmgTextConfig))
		{
			InitDamageText(Handle, TotalHeal, DefenderID, InMainPlayerEntityID, false);

			if (auto* Queue = DamageTextQueues.Find(Handle->GetStatePriority()))
			{
				if (auto* Mgr = HUDManager->GetManagerByType(GetWorld(), EManagerType::EMT_DamageProcessManager))
				{
					auto* DamageProcessManager = Cast<UKGDamageProcessManager>(Mgr);
					int32 MaxDisplayCount = DamageProcessManager->GetDamageTextMaxDisplayCount();
					Queue->PushDamageText(Handle, DamageTextsPendingRemoved, MaxDisplayCount);
				}
				else {
					Queue->PushDamageText(Handle, DamageTextsPendingRemoved);
				}
			}
		}
	}
	else
	{
#if ENABLE_DMG_LOG
		UE_LOG(LogHUDDamageEffect, Log, TEXT("[HUDDamageEffect]PlayHealTextV2 failed:has no config for DamageVisualType:%d"), static_cast<int32>(DamageVisualType));
#endif
	}
}

void UDamageEffectComponent::PlayImmuneTextV2(KGEntityID DefenderID, KGEntityID InMainPlayerEntityID)
{
	SCOPED_NAMED_EVENT(DamageEffectComponent_PlayHealEffectTextV2, FColor::Green);
#if ENABLE_DMG_LOG
	UE_LOG(LogHUDDamageEffect, Log, TEXT("[DamageEffectComponent]PlayHealTextV2 defender:%lld, damageValue:%d"), DefenderID, InDamageValue);
#endif
    
	bool bDamageOnThird = DefenderID != InMainPlayerEntityID;
	int32 DamageVisualType = static_cast<uint8>(EDamageVisualType::Immune);
	if (bDamageOnThird)
	{
		DamageVisualType |= static_cast<uint8>(EDamageVisualType::ThirdFlag); 
	}
	if (const auto* DmgTextConfig = GetDamageTextConfig(static_cast<int32>(DamageVisualType)))
	{
		if (FDamageTextHandle Handle = DamageTextPool.Obtain(DmgTextConfig))
		{
			InitDamageText(Handle, 0, DefenderID, InMainPlayerEntityID, false);

			if (auto* Queue = DamageTextQueues.Find(Handle->GetStatePriority()))
			{
				if (auto* Mgr = HUDManager->GetManagerByType(GetWorld(), EManagerType::EMT_DamageProcessManager))
				{
					auto* DamageProcessManager = Cast<UKGDamageProcessManager>(Mgr);
					int32 MaxDisplayCount = DamageProcessManager->GetDamageTextMaxDisplayCount();
					Queue->PushDamageText(Handle, DamageTextsPendingRemoved, MaxDisplayCount);
				}
				else {
					Queue->PushDamageText(Handle, DamageTextsPendingRemoved);
				}
			}
		}
	}
	else
	{
#if ENABLE_DMG_LOG
		UE_LOG(LogHUDDamageEffect, Log, TEXT("[HUDDamageEffect]PlayImmuneTextV2 failed:has no config for DamageVisualType:%d"), static_cast<int32>(DamageVisualType));
#endif
	}
}

void UDamageEffectComponent::PlayHealLimitTextV2(KGEntityID DefenderID, KGEntityID InMainPlayerEntityID)
{
	SCOPED_NAMED_EVENT(DamageEffectComponent_PlayHealEffectTextV2, FColor::Green);
#if ENABLE_DMG_LOG
	UE_LOG(LogHUDDamageEffect, Log, TEXT("[DamageEffectComponent]PlayHealTextV2 defender:%lld, damageValue:%d"), DefenderID, InDamageValue);
#endif
    
	bool bDamageOnThird = DefenderID != InMainPlayerEntityID;
	int32 DamageVisualType = static_cast<uint8>(EDamageVisualType::HealLimit);
	if (bDamageOnThird)
	{
		DamageVisualType |= static_cast<uint8>(EDamageVisualType::ThirdFlag); 
	}
	if (const auto* DmgTextConfig = GetDamageTextConfig(static_cast<int32>(DamageVisualType)))
	{
		if (FDamageTextHandle Handle = DamageTextPool.Obtain(DmgTextConfig))
		{
			InitDamageText(Handle, 0, DefenderID, InMainPlayerEntityID, false);

			if (auto* Queue = DamageTextQueues.Find(Handle->GetStatePriority()))
			{
				if (auto* Mgr = HUDManager->GetManagerByType(GetWorld(), EManagerType::EMT_DamageProcessManager))
				{
					auto* DamageProcessManager = Cast<UKGDamageProcessManager>(Mgr);
					int32 MaxDisplayCount = DamageProcessManager->GetDamageTextMaxDisplayCount();
					Queue->PushDamageText(Handle, DamageTextsPendingRemoved, MaxDisplayCount);
				}
				else {
					Queue->PushDamageText(Handle, DamageTextsPendingRemoved);
				}
			}
		}
	}
	else
	{
#if ENABLE_DMG_LOG
		UE_LOG(LogHUDDamageEffect, Log, TEXT("[HUDDamageEffect]PlayHealLimitTextV2 failed:has no config for DamageVisualType:%d"), static_cast<int32>(DamageVisualType));
#endif
	}
}

void UDamageEffectComponent::OnPendingListAssetsLoad(int32 RequestID, const TArray<UObject*>& LoadedObjectList)
{
    if (LoadIDForPendingLoadAssets == RequestID)
    {
        UDataTable* DamageTextStyleDataTable = nullptr;
        for (auto* Obj : LoadedObjectList)
        {
            if (Obj->IsA<UDataTable>() && DamageTextStyleDataTablePath.Contains(Obj->GetPathName()))
            {
                DamageTextStyleDataTable = Cast<UDataTable>(Obj);    
                break;
            }
        }
        
        if (DamageTextStyleDataTable)
        {
            ParseAllDamageTextStyle(DamageTextStyleDataTable);
        }
        
        LoadIDForPendingLoadAssets = 0;
    }
}

void UDamageEffectComponent::Tick(float DeltaTime)
{
    if (LastTickFrameNo == GFrameNumber)
    {
        return;
    }
    LastTickFrameNo = GFrameNumber;

    SCOPED_NAMED_EVENT(UDamageEffectComponent_Tick, FColor::Magenta);
    
    TSharedPtr<SWorldWidgetDamageEffectLayer> DmgLayer = GetDamageEffectLayer();
    
    for (auto& Pair : DamageTextQueues)
    {
        for (auto& Handle : Pair.Value.DamageTexts)
        {
            UpdateDamageText(Handle, DeltaTime, DmgLayer);
        }
    }

    ProcessPendingRemovedTexts(DmgLayer);
}

#if WITH_EDITOR
TMap<int32, FDamageTextConfig>& UDamageEffectComponent::GetDamageTextConfigs()
{
    return DamageTextConfigs;
}

FDamageTextConfig* UDamageEffectComponent::GetDamageTextConfig(int32 InDamageType)
{
    return DamageTextConfigs.Find(InDamageType);
}

void UDamageEffectComponent::GetDamageTextTypes(TArray<int32>& OutDamageTypes) const
{
    DamageTextConfigs.GetKeys(OutDamageTypes);
}
#endif

void UDamageEffectComponent::InitDamageTextPool(int32 InDamageTextPoolSize)
{
	DamageTextPool.Preallocate(InDamageTextPoolSize);
}

TSharedPtr<SWorldWidgetDamageEffectLayer> UDamageEffectComponent::GetDamageEffectLayer()
{
    TSharedPtr<SWorldWidgetDamageEffectLayer> DmgLayer;
    if (auto* WorldWidgetMgr = UWorldWidgetManager2::GetInstance(this))
    {
        if (auto Layer = WorldWidgetMgr->GetWorldWidgetLayer(Layer_Name); Layer.IsValid())
        {
            auto Widget = StaticCastSharedRef<SWorldWidgetDamageEffectLayer>(Layer.Pin()->AsWidget());
            DmgLayer = Widget.ToSharedPtr();
        }
    }
    
    return MoveTemp(DmgLayer);
}

void UDamageEffectComponent::InitDamageText(FDamageTextHandle& DamageTextHandle, int32 InDamageValue, KGEntityID DefenderID, KGEntityID InMainPlayerEntityID, bool bCritical)
{
    if (!HUDManager.IsValid())
    {
        return;
    }

    UHUDManager* HUDMgr = Cast<UHUDManager>(HUDManager.Get());
    if (HUDMgr == nullptr || !IsValid(HUDMgr) || !DamageTextHandle->Config)
    {
        return;
    }

    bool bInDead = IsEntityDead(DefenderID);
    
    UE_LOG(LogInit, Log, TEXT("[DamageEffect]%s %llu bInDead:%d Frame:%llu"), ANSI_TO_TCHAR(__FUNCTION__), DefenderID, bInDead, GFrameCounter);

    SCOPED_NAMED_EVENT(DamageEffectComponent_InitDamageText, FColor::Emerald);
    check(DamageTextHandle->Config);
    
    DamageTextHandle->bCritical = bCritical;
    DamageTextHandle->DamageValue = InDamageValue;
    DamageTextHandle->DefenderID = DefenderID;
    DamageTextHandle->MainPlayerID = InMainPlayerEntityID;
    DamageTextHandle->TimestampStart = GetWorld()->GetTime().GetRealTimeSeconds();
    DamageTextHandle->Scale.Set(DamageTextHandle->Config->BornRate, DamageTextHandle->Config->BornRate);
    DamageTextHandle->Location = DamageTextHandle->GetRandomStartLocation();
    
    AddDamageTextToDamageEffectLayer(DamageTextHandle);
}

void UDamageEffectComponent::AddPendingLoadAsset(const FString& InAssetPath)
{
    PendingLoadAssets.AddUnique(InAssetPath);
}

void UDamageEffectComponent::ClearPendingLoadAssets()
{
    if (LoadIDForPendingLoadAssets > 0)
    {
        if (HUDManager.IsValid())
        {
            if (auto* Mgr = HUDManager->GetManagerByType(GetWorld(), EManagerType::EMT_CppAssetManager))
            {
                auto* AssetMgr = Cast<UKGCppAssetManager>(Mgr);
                AssetMgr->CancelAsyncLoadByLoadID(LoadIDForPendingLoadAssets);
            }
        }

        LoadIDForPendingLoadAssets = 0;
    }
    
    PendingLoadAssets.Empty();
}

#pragma optimize("", on)