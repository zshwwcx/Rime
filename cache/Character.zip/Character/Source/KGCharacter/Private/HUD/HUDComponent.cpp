#include "HUD/HUDComponent.h"

void UHUDComponent::InitHUDComponent(UKGBasicManager* InManager)
{
	HUDManager = InManager;
}

void UHUDComponent::DeInitHUDComponent()
{
	HUDManager = nullptr;
}

