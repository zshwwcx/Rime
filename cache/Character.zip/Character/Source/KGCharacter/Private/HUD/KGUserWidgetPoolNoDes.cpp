// KGUserWidgetPoolNoDes.cpp
#include "HUD/KGUserWidgetPoolNoDes.h"
#include "Engine/Engine.h"

FKGUserWidgetPoolNoDes::FKGUserWidgetPoolNoDes(UWorld* InWorldContext, UWidget* InParent)
    : WorldContext(InWorldContext)
    , ParentWidget(InParent)
{
}

FKGUserWidgetPoolNoDes::~FKGUserWidgetPoolNoDes()
{
    // ClearAllPools();
}

void FKGUserWidgetPoolNoDes::Initialize(UWorld* InWorldContext, UWidget* InParent)
{
    WorldContext = InWorldContext;
    ParentWidget = InParent;
}

void FKGUserWidgetPoolNoDes::Preallocate(TSubclassOf<UUserWidget> WidgetClass, int32 PreallocateCount, FKGWidgetNoDesCallback Callback)
{
    if (!IsInitialized() || !WidgetClass)
    {
        UE_LOG(LogTemp, Warning, TEXT("FKGUserWidgetPoolNoDes not initialized or invalid widget class"));
        return;
    }

	if (WidgetPoolMap.Contains(WidgetClass)) return;

    FKGWidgetPoolEntry& PoolEntry = GetOrCreatePoolEntry(WidgetClass);

    for (int32 i = 0; i < PreallocateCount; i++)
    {
        UUserWidget* NewWidget = CreateNewWidget(WidgetClass);
        if (NewWidget)
        {
            PoolEntry.AvailableWidgets.Add(NewWidget);
        }
    	Callback.Execute(NewWidget);
    }

    UE_LOG(LogTemp, Log, TEXT("Preallocated %d widgets of class %s"), PreallocateCount, *WidgetClass->GetName());
}

UUserWidget* FKGUserWidgetPoolNoDes::GetOrCreateInstance(TSubclassOf<UUserWidget> WidgetClass, bool& bCreatNew)
{
    if (!IsInitialized() || !WidgetClass)
    {
        UE_LOG(LogTemp, Error, TEXT("Cannot get widget instance: Pool not initialized or invalid widget class"));
        return nullptr;
    }

    FKGWidgetPoolEntry& PoolEntry = GetOrCreatePoolEntry(WidgetClass);

    UUserWidget* Widget = nullptr;
	bCreatNew = false;

    // 从池中获取可用Widget
    for (int32 i = PoolEntry.AvailableWidgets.Num() - 1; i >= 0; i--)
    {
        if (PoolEntry.AvailableWidgets[i])
        {
            Widget = PoolEntry.AvailableWidgets[i].Get();
            PoolEntry.AvailableWidgets.RemoveAt(i);
            break;
        }
        else
        {
            PoolEntry.AvailableWidgets.RemoveAt(i);
        }
    }

    // 如果池中没有可用Widget，创建新实例
    if (!Widget)
    {
        Widget = CreateNewWidget(WidgetClass);
        if (!Widget)
        {
            UE_LOG(LogTemp, Error, TEXT("Failed to create widget instance of class %s"), *WidgetClass->GetName());
            return nullptr;
        }
    	bCreatNew = true;
    }

    // 添加到活跃列表
    PoolEntry.ActiveWidgets.Add(Widget);

    // 设置为可见状态
    Widget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	// debug查看统计
	// UE_LOG(LogTemp, Log, TEXT("%s"), *GetStats());

    return Widget;
}

void FKGUserWidgetPoolNoDes::ReleaseInstance(UUserWidget* Widget)
{
    if (!Widget || !IsInitialized())
    {
        return;
    }

    TSubclassOf<UUserWidget> WidgetClass = Widget->GetClass();
    FKGWidgetPoolEntry* PoolEntry = WidgetPoolMap.Find(WidgetClass);
    
    if (!PoolEntry)
    {
        return;
    }

    // 从活跃列表中移除
    for (int32 i = PoolEntry->ActiveWidgets.Num() - 1; i >= 0; i--)
    {
        if (!PoolEntry->ActiveWidgets[i])
        {
            PoolEntry->ActiveWidgets.RemoveAt(i);
        }
        else if (PoolEntry->ActiveWidgets[i].Get() == Widget)
        {
            PoolEntry->ActiveWidgets.RemoveAt(i);
            break;
        }
    }

    // 设置回收状态
    Widget->SetVisibility(ESlateVisibility::Collapsed);

    // 放回池中
    PoolEntry->AvailableWidgets.Add(Widget);
}

void FKGUserWidgetPoolNoDes::ClearPool(TSubclassOf<UUserWidget> WidgetClass)
{
    FKGWidgetPoolEntry* PoolEntry = WidgetPoolMap.Find(WidgetClass);
    if (PoolEntry)
    {
        for (auto& WidgetPtr : PoolEntry->AvailableWidgets)
        {
            if (UUserWidget* Widget = WidgetPtr.Get())
            {
                Widget->RemoveFromParent();
            }
        }
        
        for (auto& WidgetPtr : PoolEntry->ActiveWidgets)
        {
            if (UUserWidget* Widget = WidgetPtr.Get())
            {
                Widget->RemoveFromParent();
            }
        }
        
        WidgetPoolMap.Remove(WidgetClass);
    }
}

void FKGUserWidgetPoolNoDes::ClearAllPools()
{
    for (auto& PoolPair : WidgetPoolMap)
    {
        FKGWidgetPoolEntry& PoolEntry = PoolPair.Value;
        
        for (auto& WidgetPtr : PoolEntry.AvailableWidgets)
        {
            if (UUserWidget* Widget = WidgetPtr.Get())
            {
                Widget->RemoveFromParent();
            }
        }
        
        for (auto& WidgetPtr : PoolEntry.ActiveWidgets)
        {
            if (UUserWidget* Widget = WidgetPtr.Get())
            {
                Widget->RemoveFromParent();
            }
        }
    }

    WidgetPoolMap.Empty();
}

int32 FKGUserWidgetPoolNoDes::GetAvailableCount(TSubclassOf<UUserWidget> WidgetClass) const
{
    if (const FKGWidgetPoolEntry* PoolEntry = FindPoolEntry(WidgetClass))
    {
        return GetValidWidgetCount(PoolEntry->AvailableWidgets);
    }
    return 0;
}

int32 FKGUserWidgetPoolNoDes::GetTotalCount(TSubclassOf<UUserWidget> WidgetClass) const
{
    if (const FKGWidgetPoolEntry* PoolEntry = FindPoolEntry(WidgetClass))
    {
        return GetValidWidgetCount(PoolEntry->AvailableWidgets) + GetValidWidgetCount(PoolEntry->ActiveWidgets);
    }
    return 0;
}

FString FKGUserWidgetPoolNoDes::GetStats() const
{
    FString Stats;
    Stats += FString::Printf(TEXT("FKGUserWidgetPoolNoDes Stats:\n"));
    Stats += FString::Printf(TEXT("Initialized: %s\n"), IsInitialized() ? TEXT("Yes") : TEXT("No"));
    Stats += FString::Printf(TEXT("WorldContext Valid: %s\n"), WorldContext.IsValid() ? TEXT("Yes") : TEXT("No"));
    Stats += FString::Printf(TEXT("ParentWidget Valid: %s\n"), ParentWidget.IsValid() ? TEXT("Yes") : TEXT("No"));
    Stats += FString::Printf(TEXT("Total Pool Types: %d\n"), WidgetPoolMap.Num());
    
    for (const auto& PoolPair : WidgetPoolMap)
    {
        TSubclassOf<UUserWidget> WidgetClass = PoolPair.Key;
        const FKGWidgetPoolEntry& PoolEntry = PoolPair.Value;
        
        int32 AvailableCount = GetValidWidgetCount(PoolEntry.AvailableWidgets);
        int32 ActiveCount = GetValidWidgetCount(PoolEntry.ActiveWidgets);
        
        Stats += FString::Printf(TEXT("  %s: Available=%d, Active=%d, Total=%d\n"), 
            *WidgetClass->GetName(), AvailableCount, ActiveCount, AvailableCount + ActiveCount);
    }
    
    return Stats;
}

UUserWidget* FKGUserWidgetPoolNoDes::CreateNewWidget(TSubclassOf<UUserWidget> WidgetClass)
{
    if (!WidgetClass)
    {
        return nullptr;
    }

	UUserWidget* NewWidget;

	UWidget* OwningWidgetPtr = GetValidParentWidget();
	if (OwningWidgetPtr)
	{
		NewWidget = CreateWidget(OwningWidgetPtr, WidgetClass);
	}
	else
	{
		NewWidget = CreateWidget(GetValidWorldContext(), WidgetClass);
	}

    if (NewWidget)
    {
        // 初始状态为Collapsed
        NewWidget->SetVisibility(ESlateVisibility::Collapsed);
    }

    return NewWidget;
}

int32 FKGUserWidgetPoolNoDes::GetValidWidgetCount(const TArray<TObjectPtr<UUserWidget>>& WidgetArray) const
{
    int32 Count = 0;
    for (const auto& WidgetPtr : WidgetArray)
    {
        if (WidgetPtr)
        {
            Count++;
        }
    }
    return Count;
}

UWorld* FKGUserWidgetPoolNoDes::GetValidWorldContext() const
{
    return WorldContext.IsValid() ? WorldContext.Get() : nullptr;
}

UWidget* FKGUserWidgetPoolNoDes::GetValidParentWidget() const
{
    return ParentWidget.IsValid() ? ParentWidget.Get() : nullptr;
}

FKGWidgetPoolEntry& FKGUserWidgetPoolNoDes::GetOrCreatePoolEntry(TSubclassOf<UUserWidget> WidgetClass)
{
    return WidgetPoolMap.FindOrAdd(WidgetClass);
}

const FKGWidgetPoolEntry* FKGUserWidgetPoolNoDes::FindPoolEntry(TSubclassOf<UUserWidget> WidgetClass) const
{
    return WidgetPoolMap.Find(WidgetClass);
}