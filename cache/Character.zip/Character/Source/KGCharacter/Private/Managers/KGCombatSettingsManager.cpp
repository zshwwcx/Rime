﻿#include "Managers/KGCombatSettingsManager.h"

#include "KGCharacterModule.h"
#include "Curves/CurveFloat.h"
#include "TypeDefines/LuaTypes.h"

void UKGCombatSettingsManager::NativeInit()
{
	Super::NativeInit();

	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGCombatSettingsManager, "KAPI_CombatSettings_EnablePerfectDodge", &UKGCombatSettingsManager::KAPI_CombatSettings_EnablePerfectDodge);
	REG_MANAGER_FUNC(UKGCombatSettingsManager, "KAPI_CombatSettings_SetPerfectDodgeInfo", &UKGCombatSettingsManager::KAPI_CombatSettings_SetPerfectDodgeInfo);
	
	REG_MANAGER_FUNC(UKGCombatSettingsManager, "KAPI_CombatSettings_SetTargetSelectParams", &UKGCombatSettingsManager::KAPI_CombatSettings_SetTargetSelectParams);
	REG_MANAGER_FUNC(UKGCombatSettingsManager, "KAPI_CombatSettings_EnableDefaultSort", &UKGCombatSettingsManager::KAPI_CombatSettings_EnableDefaultSort);
}

void UKGCombatSettingsManager::NativeUninit()
{
	Super::NativeUninit();
}

void UKGCombatSettingsManager::KAPI_CombatSettings_SetPerfectDodgeInfo(
	const FString& AttackerCurve, const FString& DefenderCurve, const FString& EnvCurve, float CurveSampleIntervalTime,
	const FName& InDitherAlphaParamName, float InDitherDuration)
{
	// 初始化的时候设置, 同步加载
	AttackerCurveAvgSlomoRate = 1.0f;
	AttackerCurveSlomoRateSegments.Empty();
	if (!AttackerCurve.IsEmpty())
	{
		AttackerPerfectDodgeCurve = Cast<UCurveFloat>(StaticLoadObject(UCurveFloat::StaticClass(), nullptr, *AttackerCurve));
		if (AttackerPerfectDodgeCurve)
		{
			float MinTime, MaxTime;
			AttackerPerfectDodgeCurve->GetTimeRange(MinTime, MaxTime);
			AttackerCurveTotalTime = MaxTime - MinTime;
			if (AttackerCurveTotalTime < UE_KINDA_SMALL_NUMBER)
			{
				UE_LOG(LogKGCombat, Error, 
					TEXT("UKGCombatSettingsManager::KAPI_CombatSettings_SetPerfectDodgeInfo, invalid AttackerCurve time range: %s"), *AttackerCurve);
			}
			else
			{
				CurveSampleIntervalTime = FMath::Clamp(CurveSampleIntervalTime, UE_KINDA_SMALL_NUMBER, AttackerCurveTotalTime);
				float TotalSlomoTime = 0.0f;
				for (float Time = MinTime; Time < MaxTime; Time += CurveSampleIntervalTime)
				{
					const float CurrentDilation = AttackerPerfectDodgeCurve->GetFloatValue(Time);
					TotalSlomoTime += FMath::Max(0.0f, CurrentDilation) * CurveSampleIntervalTime;
				}
				AttackerCurveAvgSlomoRate = TotalSlomoTime / AttackerCurveTotalTime;

				const auto& CurveKeys = AttackerPerfectDodgeCurve->FloatCurve.GetConstRefOfKeys();
				const auto NumKeys = CurveKeys.Num();
				if (NumKeys <= 1)
				{
					UE_LOG(LogKGCombat, Error,
						TEXT("UKGCombatSettingsManager::KAPI_CombatSettings_SetPerfectDodgeInfo, AttackerCurve need at least two keys: %s"), *AttackerCurve);
				}
				else
				{
					for (int32 i = 0; i < CurveKeys.Num() - 1; i++)
					{
						const auto& CurveKey = CurveKeys[i];
						auto& Segment = AttackerCurveSlomoRateSegments.AddDefaulted_GetRef();
						Segment.SegmentStartTime = CurveKey.Time;
						Segment.SegmentAvgSlomoRate = (CurveKey.Value + CurveKeys[i + 1].Value) * 0.5f;
					}
				}
			}
		}
		else
		{
			UE_LOG(LogKGCombat, Error,
				TEXT("UKGCombatSettingsManager::KAPI_CombatSettings_SetPerfectDodgeInfo, invalid AttackerCurve: %s"), *AttackerCurve);
		}
	}
	
	if (!DefenderCurve.IsEmpty())
	{
		DefenderPerfectDodgeCurve = Cast<UCurveFloat>(StaticLoadObject(UCurveFloat::StaticClass(), nullptr, *DefenderCurve));
		UE_CLOG(DefenderPerfectDodgeCurve == nullptr, LogKGCombat, Error,
			TEXT("UKGCombatSettingsManager::KAPI_CombatSettings_SetPerfectDodgeInfo, invalid DefenderCurve: %s"), *DefenderCurve);
	}
	
	if (!EnvCurve.IsEmpty())
	{
		EnvPerfectDodgeCurve = Cast<UCurveFloat>(StaticLoadObject(UCurveFloat::StaticClass(), nullptr, *EnvCurve));
		UE_CLOG(EnvPerfectDodgeCurve == nullptr, LogKGCombat, Error,
			TEXT("UKGCombatSettingsManager::KAPI_CombatSettings_SetPerfectDodgeInfo, invalid EnvCurve: %s"), *EnvCurve);
	}
	
	DitherAlphaParamName = InDitherAlphaParamName;
	DitherDuration = InDitherDuration;
}

void UKGCombatSettingsManager::KAPI_CombatSettings_SetTargetSelectParams(
	uint32 InAoeMaxTargetSelectNum, float InAttackSelectDefaultDistance, float InAttackSelectDefaultAngle, uint32 InMaxTargetSelectReentranceNum,
	uint64 InTargetActorAllTypeMask,
	const TArray<int32>& InObjectTypesToQuery_AbilityWithSceneActor, const TArray<int32>& InObjectTypesToQuery_AbilityDefault)
{
	AoeMaxTargetSelectNum = InAoeMaxTargetSelectNum;
	MaxTargetSelectReentranceNum = InMaxTargetSelectReentranceNum;
	AttackSelectDefaultDistance = InAttackSelectDefaultDistance;
	AttackSelectDefaultAngle = InAttackSelectDefaultAngle;
	TargetActorAllTypeMask = InTargetActorAllTypeMask;
	ObjectTypesToQuery_AbilityWithSceneActor = InObjectTypesToQuery_AbilityWithSceneActor;
	ObjectTypesToQuery_AbilityDefault = InObjectTypesToQuery_AbilityDefault;
}

const TArray<int32>& UKGCombatSettingsManager::GetSceneQueryObjectTypes(uint64 SceneQueryObjectTypeMask)
{
	if (SceneQueryObjectTypeMask == 0 || SceneQueryObjectTypeMask == TargetActorAllTypeMask)
	{
		return ObjectTypesToQuery_AbilityWithSceneActor;
	}
	
	if (SceneQueryObjectTypeMask & static_cast<uint64>(EKGTargetActorType::Interactor))
	{
		return ObjectTypesToQuery_AbilityWithSceneActor;
	}
	
	return ObjectTypesToQuery_AbilityDefault;
}
