

#include "CoreMinimal.h"
#include "Managers/KGDataCacheManager.h"	

#include "3C/Core/AttachJointComponent_V2.h"
#include "3C/Audio/KGAudioNotifyHelper.h"
#include "KGCharacterModule.h"
#include "KGUI.h"


void UKGDataCacheManager::NativeInit()
{
	Super::NativeInit();

	ElementEffectsDataCache.Init(64); // Initialize with a cache size of 64
	ElementSingleEffectsDataCache.Init(64); // Initialize with a cache size of 64

	SkillDataCache.Init(128);
	SpellFieldDataCache.Init(128);
	BulletDataCache.Init(128);

	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CleanCache", &UKGDataCacheManager::KAPI_DataCache_CleanCache);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheSkillData", &UKGDataCacheManager::KAPI_DataCache_CacheSkillData);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheSpellFieldData", &UKGDataCacheManager::KAPI_DataCache_CacheSpellFieldData);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheBulletData", &UKGDataCacheManager::KAPI_DataCache_CacheBulletData);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheBuffData", &UKGDataCacheManager::KAPI_DataCache_CacheBuffData);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_SetSkillAKEventName", &UKGDataCacheManager::KAPI_DataCache_SetSkillAKEventName);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheSpellFieldData", &UKGDataCacheManager::KAPI_DataCache_CacheSpellFieldData);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_SetCameraShakeScale", &UKGDataCacheManager::KAPI_DataCache_SetCameraShakeScale);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheEntityName", &UKGDataCacheManager::KAPI_DataCache_CacheEntityName);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheStringConst", &UKGDataCacheManager::KAPI_DataCache_CacheStringConst);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheStringConstList", &UKGDataCacheManager::KAPI_DataCache_CacheStringConstList);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheReminderData", &UKGDataCacheManager::KAPI_DataCache_CacheReminderData);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheVehicleWayPathDataSinglePoint", &UKGDataCacheManager::KAPI_DataCache_CacheVehicleWayPathDataSinglePoint);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheTargetSelectRuleData", &UKGDataCacheManager::KAPI_DataCache_CacheTargetSelectRuleData);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheGameplaySplinePoint", &UKGDataCacheManager::KAPI_DataCache_CacheGameplaySplinePoint);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheGameplaySplineTransform", &UKGDataCacheManager::KAPI_DataCache_CacheGameplaySplineTransform);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheGameplaySplineStation", &UKGDataCacheManager::KAPI_DataCache_CacheGameplaySplineStation);
	
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheWeaponTypeData", &UKGDataCacheManager::KAPI_DataCache_CacheWeaponTypeData);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheWeaponInfoData", &UKGDataCacheManager::KAPI_DataCache_CacheWeaponInfoData);

	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_SetEnableVirtualAttach", &UKGDataCacheManager::KAPI_DataCache_SetEnableVirtualAttach);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_SetVirtualAttachUseBezierMode", &UKGDataCacheManager::KAPI_DataCache_SetVirtualAttachUseBezierMode);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_SetVirtualAttachUseFaceToMoveDirMode", &UKGDataCacheManager::KAPI_DataCache_SetVirtualAttachUseFaceToMoveDirMode);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_SetVirtualAttachDoCollision", &UKGDataCacheManager::KAPI_DataCache_SetVirtualAttachDoCollision);
	
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddGroupMemberList", &UKGDataCacheManager::KAPI_DataCache_AddGroupMemberList);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_RemoveGroupMembers", &UKGDataCacheManager::KAPI_DataCache_RemoveGroupMembers);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_ClearGroupMemberList", &UKGDataCacheManager::KAPI_DataCache_ClearGroupMemberList);

	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheTeamMemberIDList", &UKGDataCacheManager::KAPI_DataCache_CacheTeamMemberIDList);
	
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddMaterialParamsData_FloatParam", &UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_FloatParam);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddMaterialParamsData_VectorParam", &UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_VectorParam);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddMaterialParamsData_TextureParam", &UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_TextureParam);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddMaterialParamsData_CurveParam", &UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_CurveParam);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddMaterialParamsData_FloatLinearSampleParam", &UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_FloatLinearSampleParam);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddMaterialParamsData_VectorLinearSampleParam", &UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_VectorLinearSampleParam);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_RemoveMaterialParamsData", &UKGDataCacheManager::KAPI_DataCache_RemoveMaterialParamsData);
	
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddNiagaraParamsData_FloatParam", &UKGDataCacheManager::KAPI_DataCache_AddNiagaraParamsData_FloatParam);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddNiagaraParamsData_CurveParam", &UKGDataCacheManager::KAPI_DataCache_AddNiagaraParamsData_CurveParam);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_AddNiagaraParamsData_FloatLinearSampleParam", &UKGDataCacheManager::KAPI_DataCache_AddNiagaraParamsData_FloatLinearSampleParam);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_RemoveNiagaraParamsData", &UKGDataCacheManager::KAPI_DataCache_RemoveNiagaraParamsData);
	
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheDissolveEffectData", &UKGDataCacheManager::KAPI_DataCache_CacheDissolveEffectData);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheAttachedNiagaraEffectData", &UKGDataCacheManager::KAPI_DataCache_CacheAttachedNiagaraEffectData);
	
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheDecalConfigData", &UKGDataCacheManager::KAPI_DataCache_CacheDecalConfigData);

	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheTriggerDriftParams", &UKGDataCacheManager::KAPI_DataCache_CacheTriggerDriftParams);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheGlideLoopParams", &UKGDataCacheManager::KAPI_DataCache_CacheGlideLoopParams);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheTerrainFootprintData", &UKGDataCacheManager::KAPI_DataCache_CacheTerrainFootprintData);

	#pragma region 控件蓝图文本表

	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_ClearWidgetBlueprintTextDisplayStringCache", &UKGDataCacheManager::KAPI_DataCache_ClearWidgetBlueprintTextDisplayStringCache);
	REG_MANAGER_FUNC(UKGDataCacheManager, "KAPI_DataCache_CacheWidgetBlueprintTextDisplayString", &UKGDataCacheManager::KAPI_DataCache_CacheWidgetBlueprintTextDisplayString);

	if (auto KGUI = FModuleManager::GetModulePtr<FKGUIModule>("KGUI"))
	{
		// 向KGUI模块注册，这样那边就可以从C++侧访问文本表了。
		KGUI->SetWidgetBlueprintTextProvider(this);
	}
	else
	{
		UE_LOG(LogKGCharacter, Error, TEXT("Can not find KGUI module!"));
	}

	#pragma endregion
}

void UKGDataCacheManager::NativeUninit()
{
	#pragma region 控件蓝图文本表
	if (auto KGUI = FModuleManager::GetModulePtr<FKGUIModule>("KGUI"))
	{
		// 反注册控件蓝图文本表接口
		ensure(KGUI->GetWidgetBlueprintTextProvider() == this);
		KGUI->SetWidgetBlueprintTextProvider(nullptr);
	}

	#pragma endregion

	Super::NativeUninit();

	CleanCache();
}

void UKGDataCacheManager::CleanCache()
{
	ElementEffectsDataCache.CleanCache();

	ElementSingleEffectsDataCache.CleanCache();

	SkillDataCache.CleanCache();
	SpellFieldDataCache.CleanCache();
	BulletDataCache.CleanCache();

	VehicleWayPathDataCache.CleanCache();
	
	SplinePointDataCache.CleanCache();
	
	TeamMemberIDListCache.Empty();

	GroupMemberListCache.Empty();

	WidgetBlueprintTextDisplayStringCache.CleanCache();  // 控件蓝图文本表
}

void UKGDataCacheManager::KAPI_DataCache_CleanCache()
{
	UE_LOG(LogKGCharacter, Log, TEXT("KGDataCacheManager::KAPI_DataCache_CleanCache called - Begin"));
	CleanCache();
	UE_LOG(LogKGCharacter, Log, TEXT("KGDataCacheManager::KAPI_DataCache_CleanCache called - End"));
}

FElementEffectsData* UKGDataCacheManager::GetElementEffectsData(int32 ID)
{
	FElementEffectsData* Data = ElementEffectsDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetElementEffectsData", ID);

		// after calling lua, we should try to get the data again
		Data = ElementEffectsDataCache.Get(ID);
	}

	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheElementEffectsData(int32 ID,
	int32 ElementTypeID,
	int32 NoCriticalEffectId,
	int32 CriticalEffectId,
	FString icon)
{
	FElementEffectsData Data;
	Data.ElementTypeID = ElementTypeID;
	Data.NoCriticalEffectId = NoCriticalEffectId;
	Data.CriticalEffectId = CriticalEffectId;
	Data.icon = icon;

	ElementEffectsDataCache.Add(ID, Data);
}

FElementSingleEffectData* UKGDataCacheManager::GetElementSingleEffectsData(int32 ID)
{
	FElementSingleEffectData* Data = ElementSingleEffectsDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetElementSingleEffectsData", ID);
		// after calling lua, we should try to get the data again
		Data = ElementSingleEffectsDataCache.Get(ID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheElementSingleEffectsData(int32 ID,
	int32 CastSkill,
	FString EleDamage,
	float DamageDiffusionCoeff,
	const TArray<int32>& AddBuffs,
	bool IsRandomBuff,
	const TArray<int32>& TargetAddBuffs,
	bool IsTargetRandomBuff,
	int32 ExtraAtkRandomTimes)
{
	FElementSingleEffectData Data;
	Data.CastSkill = CastSkill;
	Data.EleDamage = EleDamage;
	Data.DamageDiffusionCoeff = DamageDiffusionCoeff;
	Data.AddBuffs = AddBuffs;
	Data.IsRandomBuff = IsRandomBuff;
	Data.TargetAddBuffs = TargetAddBuffs;
	Data.IsTargetRandomBuff = IsTargetRandomBuff;
	Data.ExtraAtkRandomTimes = ExtraAtkRandomTimes;
	ElementSingleEffectsDataCache.Add(ID, Data);
}


FSkillData* UKGDataCacheManager::GetSkillData(int32 ID)
{
	FSkillData* Data = SkillDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetSkillData", ID);
		// after calling lua, we should try to get the data again
		Data = SkillDataCache.Get(ID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheSkillData(int32 ID, const FString& Name, 
	// 受击表现相关
	const FString& HitEffectPath, const FString& HitSoundPath,
	EHitEffectPlayLocationMode LocationMode, bool bFlashWhite, const FString& OnHitShake, 
	float HitEffectOffsetX, float HitEffectOffsetY, float HitEffectOffsetZ,
	float HitEffectScaleX, float HitEffectScaleY, float HitEffectScaleZ,
	float HitEffectRotPitch, float HitEffectRotYaw, float HitEffectRotRoll,
	float HitEffectPlayRate, FName HitEffectPosUsedSocket,
	// 目标筛选相关
	uint32 TargetNum, 
	// 目标筛选相关, RangeParams
	bool bHasRangeParams, EKGTargetSelectShapeType ShapeType,
	float Param0, float Param1, float Param2, float Param3, float Param4, float Param5,
	EKGTargetSelectCoordinateType CoordinateType, float ClockwiseRotation, float CoordinateOffsetX,
	float CoordinateOffsetY, float CoordinateOffsetZ,
	// 目标筛选相关, BackupRangeParams
	bool bHasBackupRangeParams, EKGTargetSelectShapeType BackupShapeType, 
	float BackupParam0, float BackupParam1, float BackupParam2, float BackupParam3, float BackupParam4, float BackupParam5,
	EKGTargetSelectCoordinateType BackupCoordinateType, float BackupClockwiseRotation, float BackupCoordinateOffsetX,
	float BackupCoordinateOffsetY, float BackupCoordinateOffsetZ,
	// 目标筛选相关, SearchTargetParams
	uint64 GlobalTargetTypeMask, uint32 FactionMask, EKGQuerySelfType QuerySelfType,
	uint64 TargetTypeMask, uint32 ClassTypeMask, EKGEntityAliveType EntityAliveType, EKGHitLimitType HitLimitType,
	// 施法相关
	float Dist
	)
{
	FVector CoordinateOffset(CoordinateOffsetX, CoordinateOffsetY, CoordinateOffsetZ);
	if (CoordinateOffset.ContainsNaN())
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDataCacheManager::KAPI_DataCache_CacheSkillData: CoordinateOffset contains NaN for ID %d"), ID);
		return;
	}
	
	FVector BackupCoordinateOffset(BackupCoordinateOffsetX, BackupCoordinateOffsetY, BackupCoordinateOffsetZ);
	if (BackupCoordinateOffset.ContainsNaN())
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDataCacheManager::KAPI_DataCache_CacheSkillData: BackupCoordinateOffset contains NaN for ID %d"), ID);
		return;
	}
	
	FSkillData Data;
	Data.ID = ID;
	Data.Name = Name;
	
	Data.VFXData.HitEffectPath = HitEffectPath;
	Data.VFXData.HitSoundPath = HitSoundPath;
	Data.VFXData.LocationMode = LocationMode;
	Data.VFXData.bFlashWhite = bFlashWhite;
	Data.VFXData.OnHitShake = OnHitShake;
	Data.VFXData.HitEffectOffset = FVector(HitEffectOffsetX, HitEffectOffsetY, HitEffectOffsetZ);
	Data.VFXData.HitEffectScale = FVector(HitEffectScaleX, HitEffectScaleY, HitEffectScaleZ);
	Data.VFXData.HitFxPlayRate = HitEffectPlayRate;
	Data.VFXData.HitFxPosUsedSocket = HitEffectPosUsedSocket;
	Data.VFXData.HitEffectRotation = FRotator(HitEffectRotPitch, HitEffectRotYaw, HitEffectRotRoll);

	// range params
	Data.bHasRangeParams = bHasRangeParams;
	auto& RangeData = Data.RangeParams.RangeData;
	RangeData.ShapeType = ShapeType;
	RangeData.SetShapeParams(Param0, Param1, Param2, Param3, Param4, Param5);
	RangeData.CoordinateType = CoordinateType;
	RangeData.ClockwiseRotation = ClockwiseRotation;
	RangeData.CoordinateOffset = CoordinateOffset;
	
	Data.bHasBackupRangeParams = bHasBackupRangeParams;
	auto& BackupRangeData = Data.BackupRangeParams.RangeData;
	BackupRangeData.ShapeType = BackupShapeType;
	BackupRangeData.SetShapeParams(BackupParam0, BackupParam1, BackupParam2, BackupParam3, BackupParam4, BackupParam5);
	BackupRangeData.CoordinateType = BackupCoordinateType;
	BackupRangeData.ClockwiseRotation = BackupClockwiseRotation;
	BackupRangeData.CoordinateOffset = BackupCoordinateOffset;
	
	// target params
	auto& TargetParams = Data.SearchTargetParams;
	TargetParams.GlobalTargetTypeMask = GlobalTargetTypeMask;
	TargetParams.FactionMask = FactionMask;
	TargetParams.QuerySelfType = QuerySelfType;
	TargetParams.TargetTypeMask = TargetTypeMask;
	TargetParams.ClassTypeMask = ClassTypeMask;
	TargetParams.EntityAliveType = EntityAliveType;
	TargetParams.HitLimitType = HitLimitType;
	
	Data.TargetNum = TargetNum;
	
	Data.Dist = Dist;
	
	SkillDataCache.Add(ID, Data);
}

FSpellFieldData* UKGDataCacheManager::GetSpellFieldData(int32 ID)
{
	FSpellFieldData* Data = SpellFieldDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetSpellFieldData", ID);
		// after calling lua, we should try to get the data again
		Data = SpellFieldDataCache.Get(ID);
	}
	return Data;
}


void UKGDataCacheManager::KAPI_DataCache_CacheSpellFieldData(int32 ID, const FString& HitEffectPath, const FString& HitSoundPath,
	EHitEffectPlayLocationMode LocationMode, bool bFlashWhite, const FString& OnHitShake,
	float HitEffectOffsetX, float HitEffectOffsetY, float HitEffectOffsetZ,
	float HitEffectScaleX, float HitEffectScaleY, float HitEffectScaleZ,
	float HitEffectRotationPitch, float HitEffectRotationYaw, float HitEffectRotationRoll,
	float HitEffectPlayRate, FName HitEffectPosUsedSocket,
	// 目标筛选相关
	uint32 TargetNum,
	// 目标筛选相关, RangeParams
	bool bHasRangeParams, EKGTargetSelectShapeType ShapeType, 
	float Param0, float Param1, float Param2, float Param3, float Param4, float Param5,
	EKGTargetSelectCoordinateType CoordinateType, float ClockwiseRotation, float CoordinateOffsetX,
	float CoordinateOffsetY, float CoordinateOffsetZ,
	// 目标筛选相关, SearchTargetParams
	uint64 GlobalTargetTypeMask, uint32 FactionMask, EKGQuerySelfType QuerySelfType,
	uint64 TargetTypeMask, uint32 ClassTypeMask, EKGEntityAliveType EntityAliveType, EKGHitLimitType HitLimitType,
	// 完美闪避检测时机
	const TArray<float>& CheckTimeLowerBounds, const TArray<float>& CheckTimeUpperBounds
	)
{
	FVector CoordinateOffset(CoordinateOffsetX, CoordinateOffsetY, CoordinateOffsetZ);
	if (CoordinateOffset.ContainsNaN())
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDataCacheManager::KAPI_DataCache_CacheSpellFieldData: CoordinateOffset contains NaN for ID %d"), ID);
		return;
	}
	
	if (CheckTimeLowerBounds.Num() != CheckTimeUpperBounds.Num())
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDataCacheManager::KAPI_DataCache_CacheSpellFieldData: CheckTimeLowerBounds and CheckTimeUpperBounds size mismatch for ID %d"), ID);
		return;
	}

	FSpellFieldData Data;
	Data.ID = ID;
	Data.VFXData.HitEffectPath = HitEffectPath;
	Data.VFXData.HitSoundPath = HitSoundPath;
	Data.VFXData.LocationMode = LocationMode;
	Data.VFXData.bFlashWhite = bFlashWhite;
	Data.VFXData.OnHitShake = OnHitShake;

	Data.VFXData.HitEffectOffset = FVector(HitEffectOffsetX, HitEffectOffsetY, HitEffectOffsetZ);
	Data.VFXData.HitEffectScale = FVector(HitEffectScaleX, HitEffectScaleY, HitEffectScaleZ);
	Data.VFXData.HitFxPlayRate = HitEffectPlayRate;
	Data.VFXData.HitFxPosUsedSocket = HitEffectPosUsedSocket;
	Data.VFXData.HitEffectRotation = FRotator(HitEffectRotationPitch, HitEffectRotationYaw, HitEffectRotationRoll);

	// range params
	Data.bHasRangeParams = bHasRangeParams;
	auto& RangeData = Data.RangeParams.RangeData;
	RangeData.ShapeType = ShapeType;
	RangeData.SetShapeParams(Param0, Param1, Param2, Param3, Param4, Param5);
	RangeData.CoordinateType = CoordinateType;
	RangeData.ClockwiseRotation = ClockwiseRotation;
	RangeData.CoordinateOffset = CoordinateOffset;
	
	// target params
	auto& TargetParams = Data.SearchTargetParams;
	TargetParams.GlobalTargetTypeMask = GlobalTargetTypeMask;
	TargetParams.FactionMask = FactionMask;
	TargetParams.QuerySelfType = QuerySelfType;
	TargetParams.TargetTypeMask = TargetTypeMask;
	TargetParams.ClassTypeMask = ClassTypeMask;
	TargetParams.EntityAliveType = EntityAliveType;
	TargetParams.HitLimitType = HitLimitType;
	
	Data.TargetNum = TargetNum;
	
	if (CheckTimeLowerBounds.Num() > 0)
	{
		Data.CheckTimeList.Reserve(CheckTimeLowerBounds.Num());
		for (int32 Index = 0; Index < CheckTimeLowerBounds.Num(); ++Index)
		{
			Data.CheckTimeList.Add(FVector2D(CheckTimeLowerBounds[Index], CheckTimeUpperBounds[Index]));
		}
	
	}

	SpellFieldDataCache.Add(ID, Data);
}

FBulletData* UKGDataCacheManager::GetBulletData(int32 ID)
{
	FBulletData* Data = BulletDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetBulletData", ID);
		// after calling lua, we should try to get the data again
		Data = BulletDataCache.Get(ID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheBulletData(
	int32 ID, float MaxLifeTime, float MoveDist, float DelayDestroyTime, uint8 TrailType, const FString& StartPosAnchorBone,
	float StartPosAnchorOffsetX, float StartPosAnchorOffsetY, float StartPosAnchorOffsetZ,
	// 移动相关
	const FString& TargetPosAnchorBone, float DelayLaunchTime, float Velocity, float Acceleration, float AngularVelocity, float MaxHomingAngle,
	float TargetPointMoveSpeed, float TrackDuration, float RoundStartCoordinateX, float RoundStartCoordinateY, float RoundStartCoordinateZ,
	float RoundCenterCoordinateX, float RoundCenterCoordinateY, float RoundCenterCoordinateZ,
	// 出生特效相关
	const FString& SpawnEffectPath, uint8 SpawnEffectFollowType, bool bSpawnEffectFollowScale,
	float SpawnEffectOffsetX, float SpawnEffectOffsetY, float SpawnEffectOffsetZ,
	float SpawnEffectPitch, float SpawnEffectYaw, float SpawnEffectRoll, float SpawnEffectScaleX, float SpawnEffectScaleY, float SpawnEffectScaleZ,
	// 拖尾特效相关
	const FString& TrailEffectPath, uint8 TrailEffectFollowType, bool bTrailEffectFollowScale, float TrailEffectDelayDestroyTime,
	float TrailEffectOffsetX, float TrailEffectOffsetY, float TrailEffectOffsetZ,
	float TrailEffectPitch, float TrailEffectYaw, float TrailEffectRoll, float TrailEffectScaleX, float TrailEffectScaleY, float TrailEffectScaleZ,
	// 销毁特效相关
	const FString& DestroyEffectPath, bool bDestroyEffectFollowScale, float DestroyEffectOffsetX, float DestroyEffectOffsetY, float DestroyEffectOffsetZ,
	float DestroyEffectPitch, float DestroyEffectYaw, float DestroyEffectRoll, float DestroyEffectScaleX, float DestroyEffectScaleY, float DestroyEffectScaleZ,
	// 受击表现相关
	const FString& HitEffectPath, const FString& HitSoundPath,
	EHitEffectPlayLocationMode LocationMode, bool bFlashWhite, const FString& OnHitShake,
	float HitEffectOffsetX, float HitEffectOffsetY, float HitEffectOffsetZ,
	float HitEffectScaleX, float HitEffectScaleY, float HitEffectScaleZ,
	float HitEffectRotationPitch, float HitEffectRotationYaw, float HitEffectRotationRoll,
	float HitEffectPlayRate, FName HitEffectPosUsedSocket,

	// 水波纹相关
	bool bEnableWaterWave, float WaterWaveRadius, float DepthThreshold, float DistanceThreshold, int32 WaveMotorTextureID,
	float ScaleX, float ScaleY, float MaxHeight, float FoamScale,
	// 其他表现
	const FString& FireAudioName, const FString& FadeAudioName, bool bCheckPrefectDodge, float CollisionRadius, uint32 PerfectDodgeSkillID,
	// 特效优先级
	uint8 EffectPriority
	)
{
	FBulletData Data;
	if (TrailType < static_cast<uint8>(EKGBulletTrailType::Max))
	{
		Data.TrailType = static_cast<EKGBulletTrailType>(TrailType);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: Invalid TrailType %d for Bullet ID %d"), TrailType, ID);
		return;
	}
	
	Data.ID = ID;
	// 基础信息
	Data.MaxLifeTime = MaxLifeTime;
	Data.MoveDist = MoveDist;
	Data.DelayDestroyTime = DelayDestroyTime;
	Data.StartPosAnchorBone = StartPosAnchorBone;
	Data.StartPosAnchorOffset = FVector(StartPosAnchorOffsetX, StartPosAnchorOffsetY, StartPosAnchorOffsetZ);
	UE_CLOG(Data.StartPosAnchorOffset.ContainsNaN(), LogKGCombat, Error, 
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: StartPosAnchorOffset contains NaN for Bullet ID %d"), ID);

	// 移动相关
	Data.TargetPosAnchorBone = TargetPosAnchorBone;
	Data.DelayLaunchTime = DelayLaunchTime;
	Data.Velocity = Velocity;
	Data.Acceleration = Acceleration;
	Data.AngularVelocity = AngularVelocity;
	Data.MaxHomingAngle = MaxHomingAngle;
	Data.TargetPointMoveSpeed = TargetPointMoveSpeed;
	Data.TrackDuration = TrackDuration;
	Data.RoundStartCoordinates = FVector(RoundStartCoordinateX, RoundStartCoordinateY, RoundStartCoordinateZ);
	UE_CLOG(Data.RoundStartCoordinates.ContainsNaN(), LogKGCombat, Error, 
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: RoundStartCoordinates contains NaN for Bullet ID %d"), ID);
	Data.RoundCenterCoordinates = FVector(RoundCenterCoordinateX, RoundCenterCoordinateY, RoundCenterCoordinateZ);
	UE_CLOG(Data.RoundCenterCoordinates.ContainsNaN(), LogKGCombat, Error, 
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: RoundCenterCoordinates contains NaN for Bullet ID %d"), ID);
	
	// 出生特效
	auto& BulletSpawnEffectData = Data.BulletSpawnEffectData;
	BulletSpawnEffectData.EffectPath = SpawnEffectPath;
	BulletSpawnEffectData.bFollowScale = bSpawnEffectFollowScale;
	BulletSpawnEffectData.EffectOffset = FVector(SpawnEffectOffsetX, SpawnEffectOffsetY, SpawnEffectOffsetZ);
	UE_CLOG(BulletSpawnEffectData.EffectOffset.ContainsNaN(), LogKGCombat, Error, 
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: SpawnEffectOffset contains NaN for Bullet ID %d"), ID);
	BulletSpawnEffectData.EffectRotation = FRotator(SpawnEffectPitch, SpawnEffectYaw, SpawnEffectRoll);
	UE_CLOG(BulletSpawnEffectData.EffectRotation.ContainsNaN(), LogKGCombat, Error, 
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: SpawnEffectRotation contains NaN for Bullet ID %d"), ID);
	BulletSpawnEffectData.EffectScale = FVector(SpawnEffectScaleX, SpawnEffectScaleY, SpawnEffectScaleZ);
	UE_CLOG(BulletSpawnEffectData.EffectScale.ContainsNaN(), LogKGCombat, Error, 
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: SpawnEffectScale contains NaN for Bullet ID %d"), ID);
	if (SpawnEffectFollowType < static_cast<uint8>(EKGBulletNiagaraFollowType::Max))
	{
		Data.SpawnEffectFollowType = static_cast<EKGBulletNiagaraFollowType>(SpawnEffectFollowType);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: Invalid SpawnEffectFollowType %d for Bullet ID %d"), SpawnEffectFollowType, ID);
		return;
	}

	// 拖尾特效
	auto& BulletTrailEffectData = Data.BulletTrailEffectData;
	BulletTrailEffectData.EffectPath = TrailEffectPath;
	BulletTrailEffectData.bFollowScale = bTrailEffectFollowScale;
	BulletTrailEffectData.EffectOffset = FVector(TrailEffectOffsetX, TrailEffectOffsetY, TrailEffectOffsetZ);
	UE_CLOG(BulletTrailEffectData.EffectOffset.ContainsNaN(), LogKGCombat, Error, 
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: TrailEffectOffset contains NaN for Bullet ID %d"), ID);
	BulletTrailEffectData.EffectRotation = FRotator(TrailEffectPitch, TrailEffectYaw, TrailEffectRoll);
	UE_CLOG(BulletTrailEffectData.EffectRotation.ContainsNaN(), LogKGCombat, Error, 
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: TrailEffectRotation contains NaN for Bullet ID %d"), ID);
	BulletTrailEffectData.EffectScale = FVector(TrailEffectScaleX, TrailEffectScaleY, TrailEffectScaleZ);
	UE_CLOG(BulletTrailEffectData.EffectScale.ContainsNaN(), LogKGCombat, Error, 
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: TrailEffectScale contains NaN for Bullet ID %d"), ID);
	Data.TrailEffectDelayDestroyTime = TrailEffectDelayDestroyTime;
	if (TrailEffectFollowType < static_cast<uint8>(EKGBulletNiagaraFollowType::Max))
	{
		Data.TrailEffectFollowType = static_cast<EKGBulletNiagaraFollowType>(TrailEffectFollowType);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: Invalid TrailEffectFollowType %d for Bullet ID %d"), TrailEffectFollowType, ID);
		return;
	}

	// 销毁特效
	auto& BulletDestroyEffectData = Data.BulletDestroyEffectData;
	BulletDestroyEffectData.EffectPath = DestroyEffectPath;
	BulletDestroyEffectData.bFollowScale = bDestroyEffectFollowScale;
	BulletDestroyEffectData.EffectOffset = FVector(DestroyEffectOffsetX, DestroyEffectOffsetY, DestroyEffectOffsetZ);
	UE_CLOG(BulletDestroyEffectData.EffectOffset.ContainsNaN(), LogKGCombat, Error,
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: DestroyEffectOffset contains NaN for Bullet ID %d"), ID);
	BulletDestroyEffectData.EffectRotation = FRotator(DestroyEffectPitch, DestroyEffectYaw, DestroyEffectRoll);
	UE_CLOG(BulletDestroyEffectData.EffectRotation.ContainsNaN(), LogKGCombat, Error,
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: DestroyEffectRotation contains NaN for Bullet ID %d"), ID);
	BulletDestroyEffectData.EffectScale = FVector(DestroyEffectScaleX, DestroyEffectScaleY, DestroyEffectScaleZ);
	UE_CLOG(BulletDestroyEffectData.EffectScale.ContainsNaN(), LogKGCombat, Error,
		TEXT("UKGDataCacheManager::KAPI_DataCache_CacheBulletData: DestroyEffectScale contains NaN for Bullet ID %d"), ID);

	// 受击表现
	auto& VFXData = Data.VFXData;
	VFXData.HitEffectPath = HitEffectPath;
	VFXData.HitSoundPath = HitSoundPath;
	VFXData.LocationMode = LocationMode;
	VFXData.bFlashWhite = bFlashWhite;
	VFXData.OnHitShake = OnHitShake;
	VFXData.HitEffectOffset = FVector(HitEffectOffsetX, HitEffectOffsetY, HitEffectOffsetZ);
	VFXData.HitEffectScale = FVector(HitEffectScaleX, HitEffectScaleY, HitEffectScaleZ);
	VFXData.HitFxPlayRate = HitEffectPlayRate;
	VFXData.HitFxPosUsedSocket = HitEffectPosUsedSocket;
	VFXData.HitEffectRotation = FRotator(HitEffectRotationPitch, HitEffectRotationYaw, HitEffectRotationRoll);

	// 水波纹相关
	Data.bEnableWaterWave = bEnableWaterWave;
	Data.WaterWaveRadius = WaterWaveRadius;
	Data.DepthThreshold = DepthThreshold;
	Data.DistanceThreshold = DistanceThreshold;
	Data.WaveMotorTextureID = WaveMotorTextureID;
	Data.ScaleX = ScaleX;
	Data.ScaleY = ScaleY;
	Data.MaxHeight = MaxHeight;
	Data.FoamScale = FoamScale;
	
	// 其他信息
	Data.FireAudioName = FireAudioName;
	Data.FadeAudioName = FadeAudioName;
	Data.bCheckPrefectDodge = bCheckPrefectDodge;
	Data.CollisionRadius = CollisionRadius;
	Data.PerfectDodgeSkillID = PerfectDodgeSkillID;

	Data.EffectPriority = EffectPriority;
	
	BulletDataCache.Add(ID, Data);
}

FBuffData* UKGDataCacheManager::GetBuffData(int32 ID)
{
	FBuffData* Data = BuffDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetBuffData", ID);
		// after calling lua, we should try to get the data again
		Data = BuffDataCache.Get(ID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheBuffData(int32 ID, const FString& Name)
{
	FBuffData Data;
	Data.ID = ID;
	Data.BuffName = Name;
	BuffDataCache.Add(ID, Data);
}

const FString& UKGDataCacheManager::GetEntityName(KGEntityID ID)
{
	FString* Name = EntityNamesCache.Get(ID);
	if (Name == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetEntityName", ID);
		// after calling lua, we should try to get the data again
		Name = EntityNamesCache.Get(ID);
	}

	if (Name)
	{
		return *Name;
	}

	return EmptyString;
}

void UKGDataCacheManager::KAPI_DataCache_CacheEntityName(KGEntityID ID, const FString& Name)
{
	EntityNamesCache.Add(ID, Name);
}

const FString& UKGDataCacheManager::GetStringConst(const FString& Key)
{
	FString* StringConst = StringConstCache.Get(Key);
	if (StringConst == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetStringConst", Key);
		// after calling lua, we should try to get the data again
		StringConst = StringConstCache.Get(Key);
	}

	if (StringConst)
	{
		return *StringConst;
	}

	return EmptyString;
}

void UKGDataCacheManager::KAPI_DataCache_CacheStringConst(const FString& Key, const FString& Val)
{
	StringConstCache.Add(Key, Val);
}

const TArray<FString>& UKGDataCacheManager::GetStringConstList(const FString& Key)
{
	const TArray<FString>* StringConstList = StringConstListCache.Get(Key);
	if (StringConstList == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetStringConstList", Key);
		// after calling lua, we should try to get the data again
		StringConstList = StringConstListCache.Get(Key);
	}

	if (StringConstList)
	{
		return *StringConstList;
	}

	return EmptyStringList;
}

void UKGDataCacheManager::KAPI_DataCache_CacheStringConstList(const FString& Key, const TArray<FString>& Val)
{
	StringConstListCache.Add(Key, Val);
}

FReminderData* UKGDataCacheManager::GetReminderData(const FString& Key)
{
	FReminderData* ReminderData = ReminderDataCache.Get(Key);
	if (ReminderData == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetReminderData", Key);
		// after calling lua, we should try to get the data again
		ReminderData = ReminderDataCache.Get(Key);
	}
	return ReminderData;
}

void UKGDataCacheManager::KAPI_DataCache_CacheReminderData(const FString& Key, const FString& Text1)
{
	FReminderData Data;
	Data.Text1 = Text1;
	ReminderDataCache.Add(Key, Data);
}

float UKGDataCacheManager::GetCameraShakeScale()
{
	if (CameraShakeScale < 0)
	{
		CallLuaFunction("KCB_GetCameraShakeScale");
	}
	return CameraShakeScale;
}

void UKGDataCacheManager::KAPI_DataCache_SetCameraShakeScale(float InCameraShakeScale)
{
	CameraShakeScale = InCameraShakeScale;
}


void UKGDataCacheManager::KAPI_DataCache_CacheTeamMemberIDList(const TArray<KGEntityID>& InTeamIDList)
{
	TeamMemberIDListCache.Empty();
	TeamMemberIDListCache.Reserve(InTeamIDList.Num());
	TeamMemberIDListCache = InTeamIDList;
}



bool UKGDataCacheManager::IsTeamMemberByID(KGEntityID TeamMemberID)
{
	return TeamMemberIDListCache.Contains(TeamMemberID);
}

void UKGDataCacheManager::KAPI_DataCache_AddGroupMemberList(int32 TeamIndex, const TArray<KGEntityID>& InGroupMemberList)
{
	if (GroupMemberListCache.Num() <= TeamIndex)
	{
		GroupMemberListCache.SetNumZeroed(TeamIndex + 1);
	}

	if (GroupMemberListCache.IsValidIndex(TeamIndex))
	{
		for (KGEntityID ID : InGroupMemberList)
		{
			GroupMemberListCache[TeamIndex].TeamMemberIDs.Emplace(ID);
		}		
	}
}

void UKGDataCacheManager::KAPI_DataCache_RemoveGroupMembers(const TArray<KGEntityID>& InGroupMemberRemoved)
{
	for (auto& Members : GroupMemberListCache)
	{
		for (KGEntityID ID : InGroupMemberRemoved)
		{
			Members.TeamMemberIDs.Remove(ID);
		}
	}
}

void UKGDataCacheManager::KAPI_DataCache_ClearGroupMemberList()
{
	GroupMemberListCache.Empty();
}

bool UKGDataCacheManager::IsGroupmemberByID(KGEntityID GroupMemberID)
{
	//后续必要时再优化查找算法
	for (const FTeamMemberList& MemberList : GroupMemberListCache)
	{
		if (MemberList.TeamMemberIDs.Contains(GroupMemberID))
		{
			return true;
		}
	}

	return false;
}

void UKGDataCacheManager::KAPI_CacheHeadInfoList(const TArray<int32>& InHeadInfoList)
{
	HeadInfoListCache.Empty();
	HeadInfoListCache.Reserve(InHeadInfoList.Num());
	HeadInfoListCache = InHeadInfoList;
}

bool UKGDataCacheManager::HasHeadInfoByID(int32 entityID)
{
	return HeadInfoListCache.Contains(entityID);
}

FKGMaterialParamsData* UKGDataCacheManager::GetMaterialParamsData(int32 ID)
{
	FKGMaterialParamsData* Data = MaterialParamsDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetMaterialParamsData", ID);
		// after calling lua, we should try to get the data again
		Data = MaterialParamsDataCache.Get(ID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_FloatParam(int32 MaterialParamID, const FName& ParamName, float ParamValue)
{
	FKGMaterialParamsData& Data = MaterialParamsDataCache.FindOrAdd(MaterialParamID);
	Data.ScalarParams.Add(ParamName, ParamValue);
}

void UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_VectorParam(int32 MaterialParamID, const FName& ParamName, float R, float G, float B, float A)
{
	FLinearColor Color(R, G, B, A);
	UE_CLOG(FVector4(Color).ContainsNaN(), LogTemp, Error,
		TEXT("KAPI_DataCache_AddMaterialParamsData_VectorParam contains NaN: %d %s %f %f %f %f"), MaterialParamID, *ParamName.ToString(), R, G, B, A);
	
	FKGMaterialParamsData& Data = MaterialParamsDataCache.FindOrAdd(MaterialParamID);
	Data.VectorParams.Add(ParamName, Color);
}

void UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_TextureParam(int32 MaterialParamID, const FName& ParamName, const FString& TexturePath)
{
	FKGMaterialParamsData& Data = MaterialParamsDataCache.FindOrAdd(MaterialParamID);
	Data.TextureParams.Add(ParamName, TexturePath);
}

void UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_CurveParam(int32 MaterialParamID, const FName& ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime)
{
	FKGMaterialParamsData& Data = MaterialParamsDataCache.FindOrAdd(MaterialParamID);
	FKGCurveMaterialParam CurveParam;
	CurveParam.CurvePath = CurvePath;
	CurveParam.bNeedRemap = bNeedRemap;
	CurveParam.RemapTime = RemapTime;
	Data.CurveParams.Add(ParamName, CurveParam);
}

void UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_FloatLinearSampleParam(int32 MaterialParamID, const FName& ParamName, float StartVal, float EndVal, float Duration)
{
	FKGMaterialParamsData& Data = MaterialParamsDataCache.FindOrAdd(MaterialParamID);
	FKGLinearSampleMaterialParam<float> LinearSampleParam;
	LinearSampleParam.StartVal = StartVal;
	LinearSampleParam.EndVal = EndVal;
	LinearSampleParam.Duration = Duration;
	Data.LinearSampleScalarParams.Add(ParamName, LinearSampleParam);
}

void UKGDataCacheManager::KAPI_DataCache_AddMaterialParamsData_VectorLinearSampleParam(
	int32 MaterialParamID, const FName& ParamName, float StartR, float StartG, float StartB, float StartA, float EndR, float EndG, float EndB, float EndA, float Duration)
{
	FKGMaterialParamsData& Data = MaterialParamsDataCache.FindOrAdd(MaterialParamID);
	FKGLinearSampleMaterialParam<FLinearColor> LinearSampleParam;
	FLinearColor StartVal(StartR, StartG, StartB, StartA);
	UE_CLOG(FVector4(StartVal).ContainsNaN(), LogTemp, Error,
		TEXT("KAPI_DataCache_AddMaterialParamsData_VectorLinearSampleParam StartVal contains NaN: %d %s %f %f %f %f"),
		MaterialParamID, *ParamName.ToString(), StartR, StartG, StartB, StartA);
	LinearSampleParam.StartVal = StartVal;
	FLinearColor EndVal(EndR, EndG, EndB, EndA);
	UE_CLOG(FVector4(EndVal).ContainsNaN(), LogTemp, Error,
		TEXT("KAPI_DataCache_AddMaterialParamsData_VectorLinearSampleParam EndVal contains NaN: %d %s %f %f %f %f"),
		MaterialParamID, *ParamName.ToString(), EndR, EndG, EndB, EndA);
	LinearSampleParam.EndVal = EndVal;
	LinearSampleParam.Duration = Duration;
	Data.LinearSampleVectorParams.Add(ParamName, LinearSampleParam);
}

void UKGDataCacheManager::KAPI_DataCache_RemoveMaterialParamsData(int32 MaterialParamID, const FName& ParamName)
{
	if (FKGMaterialParamsData* Data = MaterialParamsDataCache.Get(MaterialParamID))
	{
		Data->ScalarParams.Remove(ParamName);
		Data->VectorParams.Remove(ParamName);
		Data->TextureParams.Remove(ParamName);
		Data->CurveParams.Remove(ParamName);
		Data->LinearSampleScalarParams.Remove(ParamName);
		Data->LinearSampleVectorParams.Remove(ParamName);
	}
}

FKGNiagaraParamData* UKGDataCacheManager::GetNiagaraParamsData(int32 ID)
{
	auto* Data = NiagaraParamsDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetNiagaraParamsData", ID);
		// after calling lua, we should try to get the data again
		Data = NiagaraParamsDataCache.Get(ID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_AddNiagaraParamsData_FloatParam(int32 ParamID, const FName& ParamName, float ParamValue)
{
	auto& Data = NiagaraParamsDataCache.FindOrAdd(ParamID);
	Data.ScalarParams.Add(ParamName, ParamValue);
}

void UKGDataCacheManager::KAPI_DataCache_AddNiagaraParamsData_CurveParam(int32 ParamID, const FName& ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime)
{
	auto& Data = NiagaraParamsDataCache.FindOrAdd(ParamID);
	FKGCurveMaterialParam CurveParam;
	CurveParam.CurvePath = CurvePath;
	CurveParam.bNeedRemap = bNeedRemap;
	CurveParam.RemapTime = RemapTime;
	Data.CurveParams.Add(ParamName, CurveParam);
}

void UKGDataCacheManager::KAPI_DataCache_AddNiagaraParamsData_FloatLinearSampleParam(int32 ParamID, const FName& ParamName, float StartVal, float EndVal, float Duration)
{
	auto& Data = NiagaraParamsDataCache.FindOrAdd(ParamID);
	FKGLinearSampleMaterialParam<float> LinearSampleParam;
	LinearSampleParam.StartVal = StartVal;
	LinearSampleParam.EndVal = EndVal;
	LinearSampleParam.Duration = Duration;
	Data.LinearSampleScalarParams.Add(ParamName, LinearSampleParam);
}

void UKGDataCacheManager::KAPI_DataCache_RemoveNiagaraParamsData(int32 ParamID, const FName& ParamName)
{
	if (auto* Data = NiagaraParamsDataCache.Get(ParamID))
	{
		Data->ScalarParams.Remove(ParamName);
		Data->CurveParams.Remove(ParamName);
		Data->LinearSampleScalarParams.Remove(ParamName);
	}
}

FKGDissolveEffectData* UKGDataCacheManager::GetDissolveEffectData(int32 ID)
{
	FKGDissolveEffectData* Data = DissolveEffectDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetDissolveEffectData", ID);
		// after calling lua, we should try to get the data again
		Data = DissolveEffectDataCache.Get(ID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheDissolveEffectData(
	int32 ID, bool bOverrideDissolveColor, float DissolveColorR, float DissolveColorG, float DissolveColorB, float DissolveColorA,
	float Duration, int32 DissolveType, const TArray<int32>& EffectIDs,
	const TArray<FName>& MaterialSlotNames, const FString& WeaponDissolveSMEffectPath, const FString& WeaponDissolveSKEffectPath,
	float WeaponDissolveEffectPlayRate, const FName& DissolveSwitchParamName, bool bLinearSampleDissolve)
{
	FKGDissolveEffectData DissolveEffectData;
	DissolveEffectData.bOverrideDissolveColor = bOverrideDissolveColor;
	if (bOverrideDissolveColor)
	{
		FLinearColor DissolveColor(DissolveColorR, DissolveColorG, DissolveColorB, DissolveColorA);
		UE_CLOG(FVector4(DissolveColor).ContainsNaN(), LogTemp, Error,
			TEXT("KAPI_DataCache_CacheDissolveEffectData DissolveColor contains NaN: %d %f %f %f %f"),
			ID, DissolveColorR, DissolveColorG, DissolveColorB, DissolveColorA);
		DissolveEffectData.OverrideDissolveColor = DissolveColor;
	}

	DissolveEffectData.Duration = Duration;
	DissolveEffectData.DissolveType = DissolveType;
	DissolveEffectData.EffectIDs = EffectIDs;
	DissolveEffectData.MaterialSlotNames = MaterialSlotNames;
	DissolveEffectData.WeaponDissolveSMEffectPath = WeaponDissolveSMEffectPath;
	DissolveEffectData.WeaponDissolveSKEffectPath = WeaponDissolveSKEffectPath;
	DissolveEffectData.DissolveSwitchParamName = DissolveSwitchParamName;
	DissolveEffectData.WeaponDissolveEffectPlayRate = WeaponDissolveEffectPlayRate;
	DissolveEffectData.bLinearSampleDissolve = bLinearSampleDissolve;

	DissolveEffectDataCache.Add(ID, DissolveEffectData);
}

FKGAttachedNiagaraEffectData* UKGDataCacheManager::GetAttachedNiagaraEffectData(int32 ID)
{
	auto* Data = AttachedNiagaraEffectDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetAttachedNiagaraEffectData", ID);
		// after calling lua, we should try to get the data again
		Data = AttachedNiagaraEffectDataCache.Get(ID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheAttachedNiagaraEffectData(
	int32 ID, const FString& EffectPath, const FName& AttachBoneName, const FString& AttachComponentName, 
	float OffsetX, float OffsetY, float OffsetZ,
	float Pitch, float Yaw, float Roll, float Scale, bool bAttachToCamera)
{
	FKGAttachedNiagaraEffectData AttachedNiagaraEffectData;
	AttachedNiagaraEffectData.NiagaraEffectPath = EffectPath;
	AttachedNiagaraEffectData.AttachPointName = AttachBoneName;
	AttachedNiagaraEffectData.AttachComponentName = AttachComponentName;
	AttachedNiagaraEffectData.RelativeTransform = FTransform(
		FRotator(Pitch, Yaw, Roll),
		FVector(OffsetX, OffsetY, OffsetZ),
		FVector(Scale));
	UE_CLOG(AttachedNiagaraEffectData.RelativeTransform.ContainsNaN(), LogTemp, Error,
		TEXT("KAPI_DataCache_CacheAttachedNiagaraEffectData RelativeTransform contains NaN: %d %s %f %f %f %f %f %f %f"),
		ID, *AttachBoneName.ToString(), OffsetX, OffsetY, OffsetZ, Pitch, Yaw, Roll, Scale);
	AttachedNiagaraEffectData.bAttachToCamera = bAttachToCamera;
	AttachedNiagaraEffectDataCache.Add(ID, AttachedNiagaraEffectData);
}

FString UKGDataCacheManager::GetSkillAKEventName(const FString& OriginalName, EPlayerSlotSuffix Type)
{
	FSkillAkEventKey Key;
	Key.OriginName = OriginalName;
	Key.Type = Type;

	FString* Ret = SkillAKEventNamesCache.Get(Key);
	if (Ret == nullptr)
	{
		CallLuaFunction("KCB_GetSkillAKEventName", OriginalName, Type);

		Ret = SkillAKEventNamesCache.Get(Key);
	}

	if (Ret)
	{
		return *Ret;
	}

	return FString();
}

void UKGDataCacheManager::KAPI_DataCache_SetSkillAKEventName(const FString& OriginalName, int Type, const FString& EventName)
{
	FSkillAkEventKey Key;
	Key.OriginName = OriginalName;

	if (Type < 0 || Type >= (int)EPlayerSlotSuffix::MAX)
	{
		UE_LOG(LogTemp, Warning, TEXT("KAPI_DataCache_SetSkillAKEventName invalid type:%d %s"), Type, *OriginalName);
		return;
	}

	Key.Type = (EPlayerSlotSuffix)Type;

	SkillAKEventNamesCache.Add(Key, EventName);
}

FVehicleWayPathData* UKGDataCacheManager::GetVehicleWayPathData(uint32 ID)
{
	FVehicleWayPathData* Data = VehicleWayPathDataCache.Get(ID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_VehicleWayPathData", ID);
		// after calling lua, we should try to get the data again
		Data = VehicleWayPathDataCache.Get(ID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheVehicleWayPathDataSinglePoint(uint32 PathID, float InputKey, float PosX,
	float PosY, float PosZ, float Pitch, float Yaw, float Roll, float ArriveTangentX, float ArriveTangentY,
	float ArriveTangentZ, float LeaveTangentX, float LeaveTangentY, float LeaveTangentZ, int32 PointType, bool IsStop,
	float InStopDistance, float OutStopDistance, float StopTime)
{
	FVehicleWayPathPointData PointData;
	PointData.InputKey = InputKey;
	PointData.Position = FVector(PosX, PosY, PosZ);
	PointData.Rotation = FRotator(Pitch, Yaw, Roll);
	PointData.ArriveTangent = FVector(ArriveTangentX, ArriveTangentY, ArriveTangentZ);
	PointData.LeaveTangent = FVector(LeaveTangentX, LeaveTangentY, LeaveTangentZ);
	PointData.PointType = PointType;
	PointData.IsStop = IsStop;
	PointData.InStopDistance = InStopDistance;
	PointData.OutStopDistance = OutStopDistance;
	PointData.StopTime = StopTime;
	FVehicleWayPathData* Data = VehicleWayPathDataCache.Get(PathID);
	if (Data == nullptr)
	{
		FVehicleWayPathData NewData;
		NewData.PathPoints.Add(PointData);
		VehicleWayPathDataCache.Add(PathID, NewData);
	}
	else
	{
		Data->PathPoints.Add(PointData);
	}
}

FGameplaySplineData* UKGDataCacheManager::GetGameplaySplineData(const FString& InstanceID)
{
	FGameplaySplineData* Data = SplinePointDataCache.Get(InstanceID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetGameplaySplineData", InstanceID);
		CallLuaFunction("KCB_GetGameplaySplineTransform", InstanceID);
		// after calling lua, we should try to get the data again
		Data = SplinePointDataCache.Get(InstanceID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheGameplaySplinePoint(const FString& InstanceID, float InputKey, float PosX,
	float PosY, float PosZ, float Pitch, float Yaw, float Roll, float ArriveTangentX, float ArriveTangentY,
	float ArriveTangentZ, float LeaveTangentX, float LeaveTangentY, float LeaveTangentZ, int32 PointType)
{
	FGameplaySplinePoint PointData;
	PointData.InputKey = InputKey;
	PointData.Position = FVector(PosX, PosY, PosZ);
	PointData.Rotation = FRotator(Pitch, Yaw, Roll);
	PointData.ArriveTangent = FVector(ArriveTangentX, ArriveTangentY, ArriveTangentZ);
	PointData.LeaveTangent = FVector(LeaveTangentX, LeaveTangentY, LeaveTangentZ);
	PointData.PointType = PointType;
	FGameplaySplineData* Data = SplinePointDataCache.Get(InstanceID);
	if (Data == nullptr)
	{
		FGameplaySplineData NewData;
		NewData.PathPoints.Add(PointData);
		SplinePointDataCache.Add(InstanceID, NewData);
	}
	else
	{
		Data->PathPoints.Add(PointData);
	}
}

void UKGDataCacheManager::KAPI_DataCache_CacheGameplaySplineTransform(		
	const FString& InstanceID,
	bool bClosedLoop,
	float X, float Y, float Z,
	float Pitch, float Yaw, float Roll
)
{
	FTransform SplineTransform = FTransform(FRotator(Pitch, Yaw, Roll), FVector(X, Y, Z));
	FGameplaySplineData* Data = SplinePointDataCache.Get(InstanceID);
	if (Data == nullptr)
	{
		FGameplaySplineData NewData;
		NewData.ClosedLoop = bClosedLoop;
		NewData.SplineTransform = SplineTransform;
		SplinePointDataCache.Add(InstanceID, NewData);
	}
	else
	{
		Data->ClosedLoop = bClosedLoop;
		Data->SplineTransform = SplineTransform;
	}
}

FGameplaySplineStationData* UKGDataCacheManager::GetGameplaySplineStationData(const FString& InstanceID)
{
	FGameplaySplineStationData* Data = SplineStationDataCache.Get(InstanceID);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetGameplaySplineStationData", InstanceID);
		// after calling lua, we should try to get the data again
		Data = SplineStationDataCache.Get(InstanceID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheGameplaySplineStation(const FString& InstanceID, bool IsStop,
	float InStopDistance, float OutStopDistance, float StopTime)
{
	FGameplaySplineStation StationData;
	StationData.IsStop = IsStop;
	StationData.InStopDistance = InStopDistance;
	StationData.OutStopDistance = OutStopDistance;
	StationData.StopTime = StopTime;
	FGameplaySplineStationData* Data = SplineStationDataCache.Get(InstanceID);
	if (Data == nullptr)
	{
		FGameplaySplineStationData NewData;
		NewData.Stations.Add(StationData);
		SplineStationDataCache.Add(InstanceID, NewData);
	}
	else
	{
		Data->Stations.Add(StationData);
	}
}

FKGDecalConfigData* UKGDataCacheManager::GetDecalConfigData(uint32 TemplateType, EDecalShapeType ShapeType, uint32 ScaleMode)
{
	FKGDecalConfigKey DecalConfigKey;
	DecalConfigKey.TemplateType = TemplateType;
	DecalConfigKey.ShapeType = ShapeType;
	DecalConfigKey.ScaleMode = ScaleMode;
	auto* Data = DecalConfigDataCache.Get(DecalConfigKey);
	if (Data == nullptr)
	{
		// if the data is not cached, we need to call lua to get it
		CallLuaFunction("KCB_GetDecalConfigData", TemplateType, ShapeType, ScaleMode);
		// after calling lua, we should try to get the data again
		Data = DecalConfigDataCache.Get(DecalConfigKey);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheDecalConfigData(
	uint32 TemplateType, EDecalShapeType ShapeType, uint32 ScaleMode, const FString& MatPath)
{
	FKGDecalConfigKey DecalConfigKey;
	DecalConfigKey.TemplateType = TemplateType;
	DecalConfigKey.ShapeType = ShapeType;
	DecalConfigKey.ScaleMode = ScaleMode;
	FKGDecalConfigData Data;
	Data.MatPath = MatPath;
	DecalConfigDataCache.Add(DecalConfigKey, Data);
}

const FTriggerDriftParams& UKGDataCacheManager::GetTriggerDriftParams()
{
	if (!TriggerDriftParams.bInitialized)
	{
		CallLuaFunction("KCB_GetTriggerDriftParams");
	}
	return TriggerDriftParams;
}

void UKGDataCacheManager::KAPI_DataCache_CacheTriggerDriftParams(const FString& InDecalPath_L, const FString& InDecalPath_R, const FString& StartAudio, const FString& StopAudio)
{
	TriggerDriftParams.bInitialized = true;
	TriggerDriftParams.TriggerDriftDecalPath_L = InDecalPath_L;
	TriggerDriftParams.TriggerDriftDecalPath_R = InDecalPath_R;
	TriggerDriftParams.TriggerDriftStartAudio = StartAudio;
	TriggerDriftParams.TriggerDriftStopAudio = StopAudio;
	TriggerDriftParams.TriggerDriftStartAudio_1P = FString(StartAudio).Append(FKGAudioNotifyHelper::MainPlayerSuffix);
	TriggerDriftParams.TriggerDriftStopAudio_1P = FString(StopAudio).Append(FKGAudioNotifyHelper::MainPlayerSuffix);
}

const FGlideLoopParams& UKGDataCacheManager::GetGlideLoopParams()
{
	if (!TriggerDriftParams.bInitialized)
	{
		CallLuaFunction("KCB_GetGlideLoopParams");
	}
	return GlideLoopParams;
}

void UKGDataCacheManager::KAPI_DataCache_CacheGlideLoopParams(uint8 InLocoState, const FString& InHandNiagaraPath, const FString& InArmNiagaraPath_L, const FString& InArmNiagaraPath_R,
		const FString& InNiagaraAttachPoint_HL, const FString& InNiagaraAttachPoint_HR, const FString& InNiagaraAttachPoint_AL, const FString& InNiagaraAttachPoint_AR)
{
	GlideLoopParams.bInitialized = true;
	GlideLoopParams.LocoState = InLocoState;;
	GlideLoopParams.HandNiagaraPath = InHandNiagaraPath;
	GlideLoopParams.ArmNiagaraPath_L = InArmNiagaraPath_L;
	GlideLoopParams.ArmNiagaraPath_R = InArmNiagaraPath_R;
	GlideLoopParams.NiagaraAttachPoint_HL = FName(InNiagaraAttachPoint_HL);
	GlideLoopParams.NiagaraAttachPoint_HR = FName(InNiagaraAttachPoint_HR);
	GlideLoopParams.NiagaraAttachPoint_AL = FName(InNiagaraAttachPoint_AL);
	GlideLoopParams.NiagaraAttachPoint_AR = FName(InNiagaraAttachPoint_AR);
}

FTerrainFootprintData* UKGDataCacheManager::GetTerrainFootprintData(const FString& TerrainName)
{
	FTerrainFootprintData* Data = TerrainFootprintDataCache.Get(TerrainName);
	if (!Data)
	{
		CallLuaFunction("KCB_GetTerrainFootprintData", TerrainName);
		Data = TerrainFootprintDataCache.Get(TerrainName);
	}
	return Data;
}

FWeaponTypeData* UKGDataCacheManager::GetWeaponTypeData(int WeaponType)
{
	FWeaponTypeData* Data = WeaponTypeDataCache.Get(WeaponType);
	if (!Data)
	{
		CallLuaFunction("KCB_GetWeaponTypeData", WeaponType);
		Data = WeaponTypeDataCache.Get(WeaponType);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheWeaponTypeData(int WeaponType, int DisappearEffect, int DisappearStartTime, int AppearEffect, int AppearStartTime)
{
	FWeaponTypeData Data;
	Data.WeaponType = WeaponType;
	Data.DisappearEffect = DisappearEffect;
	Data.DisappearStartTime = DisappearStartTime;
	Data.AppearEffect = AppearEffect;
	Data.AppearStartTime = AppearStartTime;
	WeaponTypeDataCache.Add(WeaponType, Data);
}

FWeaponInfoData* UKGDataCacheManager::GetWeaponInfoData(int WeaponID)
{
	FWeaponInfoData* Data = WeaponInfoDataCache.Get(WeaponID);
	if (!Data)
	{
		CallLuaFunction("KCB_GetWeaponInfoData", WeaponID);
		Data = WeaponInfoDataCache.Get(WeaponID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheWeaponInfoData(int WeaponID, int WeaponType, int WeaponSlot, FString ModelID, FString WeaponFightToIdleAnimPath, int DisappearEffect, int DisappearStartTime, int AppearEffect,
	int AppearStartTime, TArray<int> SubWeapons)
{
	FWeaponInfoData Data;
	Data.WeaponID = WeaponID;
	Data.WeaponType = WeaponType;
	Data.WeaponSlot = WeaponSlot;
	Data.ModelID = ModelID;
	Data.WeaponFightToIdleAnimPath = WeaponFightToIdleAnimPath;
	Data.DisappearEffect = DisappearEffect;
	Data.DisappearStartTime = DisappearStartTime;
	Data.AppearEffect = AppearEffect;
	Data.AppearStartTime = AppearStartTime;
	Data.SubWeapons = SubWeapons;
	WeaponInfoDataCache.Add(WeaponID, Data);
}

FVirtualAttachInfo* UKGDataCacheManager::GetVirtualAttachInfo(int VirtualAttachID)
{
	FVirtualAttachInfo* Data = VirtualAttachDataCache.Get(VirtualAttachID);
	if (!Data)
	{
		CallLuaFunction("KCB_GetVirtualAttachInfo", VirtualAttachID);
		Data = VirtualAttachDataCache.Get(VirtualAttachID);
	}
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_SetEnableVirtualAttach(int VirtualAttachID, FName SocketName, float RelLocX, float RelLocY, float RelLocZ, float RelPitch, float RelYaw, float RelRoll,
	float SocketLocationX, float SocketLocationY, float SocketLocationZ, float SocketRotationPitch, float SocketRotationYaw, float SocketRotationRoll)
{
	FVirtualAttachInfo& Info = VirtualAttachDataCache.FindOrAdd(VirtualAttachID);
	Info.AttachSocket = SocketName;
	Info.RelLocation = FVector(RelLocX, RelLocY, RelLocZ);
	Info.RelRotation = FRotator(RelPitch, RelYaw, RelRoll);
	Info.SocketLocation = FVector(SocketLocationX, SocketLocationY, SocketLocationZ);
	Info.SocketRotation = FRotator(SocketRotationPitch, SocketRotationYaw, SocketRotationRoll);
}

void UKGDataCacheManager::KAPI_DataCache_SetVirtualAttachUseBezierMode(int VirtualAttachID, float BezierStep, float BezierStepMaxDist, float BezierSpeedAlpha, float BezierLagSpeed, float BezierDirectionMultiplier,
	bool bWithInCircle, float InCircleLagSpeed, float InCircleLagTolerance)
{
	FVirtualAttachInfo& Info = VirtualAttachDataCache.FindOrAdd(VirtualAttachID);
	Info.BezierStep = BezierStep;
	Info.BezierStepMaxDist = BezierStepMaxDist;
	Info.BezierSpeedAlpha = BezierSpeedAlpha;
	Info.BezierLagSpeed = BezierLagSpeed;
	Info.BezierDirectionMultiplier = BezierDirectionMultiplier;
	Info.bWithInCircle = bWithInCircle;
	Info.InCircleLagSpeed = InCircleLagSpeed;
	Info.InCircleLagTolerance = InCircleLagTolerance;
	Info.LocationUpdateMode = bWithInCircle ? uint8(ELocationUpdateMode::Bezier_WithInCircleLag) : uint8(ELocationUpdateMode::Bezier);
}

void UKGDataCacheManager::KAPI_DataCache_SetVirtualAttachUseFaceToMoveDirMode(int VirtualAttachID, float AttachRotationLagSpeed, float FaceToMoveDirectionTolerance, bool bClampPitch, float PitchClampAngleMin,
	float PitchClampAngleMax)
{
	FVirtualAttachInfo& Info = VirtualAttachDataCache.FindOrAdd(VirtualAttachID);
	Info.RotationUpdateMode = uint8(ERotationUpdateMode::FaceToMoveDir);
	Info.AttachRotationLagSpeed = AttachRotationLagSpeed;
	Info.FaceToMoveDirectionTolerance = FaceToMoveDirectionTolerance;
	Info.bClampPitch = bClampPitch;
	Info.PitchClampAngleMin = PitchClampAngleMin;
	Info.PitchClampAngleMax = PitchClampAngleMax;
}

void UKGDataCacheManager::KAPI_DataCache_SetVirtualAttachDoCollision(int VirtualAttachID, bool bDoCollisionTest, float CollisionProbeSize, const TArray<int>& CollisionChannels)
{
	FVirtualAttachInfo& Info = VirtualAttachDataCache.FindOrAdd(VirtualAttachID);
	Info.bDoCollisionTest = bDoCollisionTest;
	Info.CollisionProbeSize = CollisionProbeSize;
	Info.CollisionChannels = CollisionChannels;
}

void UKGDataCacheManager::KAPI_DataCache_CacheTerrainFootprintData(const FString& TerrainName, bool bTriggerOnLeave, float RemainTime, float LifeTime, float FadeOutTime, 
                                                                   float DecalSizeX, float DecalSizeY, float DecalSizeZ, const FString& DecalMaterialPath, const TArray<FString>& SameEffectTerrainList)
{
	FTerrainFootprintData Data;
	Data.bTriggerOnLeave = bTriggerOnLeave;
	Data.RemainTime = RemainTime;
	Data.LifeTime = LifeTime;
	Data.FadeOutTime = FadeOutTime;
	Data.DecalSize.X = DecalSizeX;
	Data.DecalSize.Y = DecalSizeY;
	Data.DecalSize.Z = DecalSizeZ;
	Data.DecalMaterialPath = DecalMaterialPath;
	Data.SameEffectTerrainList = SameEffectTerrainList;
	TerrainFootprintDataCache.Add(TerrainName, Data);
}

FKGTargetSelectRuleData* UKGDataCacheManager::GetTargetSelectRuleData(uint32 RuleID)
{
	FKGTargetSelectRuleData* Data = TargetSelectRuleDataCache.Get(RuleID);
	if (!Data)
	{
		CallLuaFunction("KCB_GetTargetSelectRuleData", RuleID);
		Data = TargetSelectRuleDataCache.Get(RuleID);
	}
	
	return Data;
}

void UKGDataCacheManager::KAPI_DataCache_CacheTargetSelectRuleData(
	uint32 RuleID, uint32 MaxNum, uint32 BackupRuleID, EKGTargetSelectBackupMode BackupMode,
	EKGTargetSortStrategy SortType, bool bDistanceSortUseIncOrder, 
	// range params
	EKGTargetSelectShapeType ShapeType, float Param0, float Param1, float Param2, float Param3, float Param4, float Param5,
	EKGTargetSelectCoordinateType CoordinateType, float ClockwiseRotation, float CoordinateOffsetX, float CoordinateOffsetY, 
	float CoordinateOffsetZ,
	// target params
	uint64 GlobalTargetTypeMask, uint32 FactionMask, EKGQuerySelfType QuerySelfType,
	uint64 TargetTypeMask, uint32 ClassTypeMask, EKGEntityAliveType EntityAliveType, EKGHitLimitType HitLimitType)
{
	FVector CoordinateOffset(CoordinateOffsetX, CoordinateOffsetY, CoordinateOffsetZ);
	if (CoordinateOffset.ContainsNaN())
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDataCacheManager::KAPI_DataCache_CacheTargetSelectRuleData: CoordinateOffset contains NaN for RuleID %d"), RuleID);
		return;
	}
	
	FKGTargetSelectRuleData Data;
	Data.MaxNum = MaxNum;
	Data.BackupRuleID = BackupRuleID;
	Data.BackupMode = BackupMode;
	Data.SortType = SortType;
	Data.bDistanceSortUseIncOrder = bDistanceSortUseIncOrder;
	
	// range params
	auto& RangeData = Data.RangeParams.RangeData;
	RangeData.ShapeType = ShapeType;
	RangeData.SetShapeParams(Param0, Param1, Param2, Param3, Param4, Param5);
	RangeData.CoordinateType = CoordinateType;
	RangeData.ClockwiseRotation = ClockwiseRotation;
	RangeData.CoordinateOffset = CoordinateOffset;
	
	// target params
	auto& TargetParams = Data.SearchTargetParams;
	TargetParams.GlobalTargetTypeMask = GlobalTargetTypeMask;
	TargetParams.FactionMask = FactionMask;
	TargetParams.QuerySelfType = QuerySelfType;
	TargetParams.TargetTypeMask = TargetTypeMask;
	TargetParams.ClassTypeMask = ClassTypeMask;
	TargetParams.EntityAliveType = EntityAliveType;
	TargetParams.HitLimitType = HitLimitType;
	
	TargetSelectRuleDataCache.Add(RuleID, Data);
}

#pragma region 控件蓝图文本表

const FString* UKGDataCacheManager::GetWidgetBlueprintTextDisplayString(const FString& Key)
{
	auto WidgetBlueprintTextString = WidgetBlueprintTextDisplayStringCache.Get(Key);
	if (WidgetBlueprintTextString == nullptr)
	{
		CallLuaFunction("KCB_GetWidgetBlueprintTextDisplayString", Key);
		WidgetBlueprintTextString = WidgetBlueprintTextDisplayStringCache.Get(Key);
	}
	return WidgetBlueprintTextString;
}

void UKGDataCacheManager::ClearWidgetBlueprintTextDisplayStringCache()
{
	WidgetBlueprintTextDisplayStringCache.CleanCache();
}

void UKGDataCacheManager::KAPI_DataCache_ClearWidgetBlueprintTextDisplayStringCache()
{
	ClearWidgetBlueprintTextDisplayStringCache();
}

void UKGDataCacheManager::KAPI_DataCache_CacheWidgetBlueprintTextDisplayString(const FString& Key, const FString& DisplayString)
{
	WidgetBlueprintTextDisplayStringCache.Add(Key, DisplayString);
};

#pragma endregion
