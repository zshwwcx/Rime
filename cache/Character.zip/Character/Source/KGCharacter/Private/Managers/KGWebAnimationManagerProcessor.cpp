/**
 * Copyright KuaiShou Games, Inc. All Right Reserved
 * Auth :   liubo
 * Date :
 * Comment: AI视频-脚悬空问题
 */
#include "CoreMinimal.h"
#include "Engine.h"
#include "Misc/FileHelper.h" // 用于文件读取
#include "Serialization/JsonReader.h" // JSON读取
#include "Serialization/JsonSerializer.h"
#include "Managers/KGWebAnimationManager.h"	

#include "Dom/JsonObject.h"
#include "JsonObjectConverter.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"

DECLARE_LOG_CATEGORY_EXTERN(LogAIAnim, Log, All);
DEFINE_LOG_CATEGORY(LogAIAnim);

int bAIAnimFloatingFootDebug = 1;
static FAutoConsoleVariableRef CVarbAIAnimFloatingFootDebug(
	TEXT("c7.ai.anim.floatingfoot.debug"),
	bAIAnimFloatingFootDebug,
	TEXT("c7.ai.anim.floatingfoot.debug"),
	ECVF_Default);


namespace transl_filter
{
	struct FBoneTransformData
	{
		FString Parent;
		FVector Rotation;
		FVector Translation;
		FQuat Orientation;
	};

	// 更简洁的静态函数版本
	class Interp1D {
	public:
		// 线性插值和外推
		static TArray<float> linear_extrapolate(const TArray<float>& x_known,
			const TArray<float>& y_known,
			const TArray<float>& x_new) {

			if (x_known.Num() != y_known.Num()) {
				return TArray<float>();
			}

			if (x_known.Num() < 2) {
				return TArray<float>();
			}

			// 检查x_known是否严格递增
			for (size_t i = 1; i < x_known.Num(); ++i) {
				if (x_known[i] <= x_known[i - 1]) {
					return TArray<float>();
				}
			}

			TArray<float> result;
			result.Reserve(x_new.Num());

			int n = x_known.Num();

			for (float x : x_new) {
				// 如果x小于第一个已知点，使用前两个点外推
				if (x <= x_known[0]) {
					float x0 = x_known[0];
					float x1 = x_known[1];
					float y0 = y_known[0];
					float y1 = y_known[1];
					float y = y0 + (x - x0) * (y1 - y0) / (x1 - x0);
					result.Add(y);
					continue;
				}

				// 如果x大于最后一个已知点，使用最后两个点外推
				if (x >= x_known[n - 1]) {
					float x0 = x_known[n - 2];
					float x1 = x_known[n - 1];
					float y0 = y_known[n - 2];
					float y1 = y_known[n - 1];
					float y = y1 + (x - x1) * (y1 - y0) / (x1 - x0);
					result.Add(y);
					continue;
				}

				// 在已知点范围内，找到x所在的区间并进行线性插值
				for (int i = 0; i < n - 1; i++) {
					if (x >= x_known[i] && x <= x_known[i + 1]) {
						float x0 = x_known[i];
						float x1 = x_known[i + 1];
						float y0 = y_known[i];
						float y1 = y_known[i + 1];

						// 线性插值
						float y = y0 + (x - x0) * (y1 - y0) / (x1 - x0);
						result.Add(y);
						break;
					}
				}
			}

			return result;
		}
		
		template<class T1, class T2>
		static TArray<T2> transform(const TArray<T1>& x_new2)
		{
			TArray<T2> x_new;
			x_new.Reserve(x_new2.Num());
			for (const auto& It : x_new2)
			{
				x_new.Add(It);
			}		
			return x_new;
		}

		static TArray<float> linear_extrapolate_int(const TArray<float>& x_known,
			const TArray<float>& y_known,
			const TArray<int>& x_new2)
		{
			return linear_extrapolate(x_known, y_known, transform<int, float>(x_new2));

		}

		// 便捷函数：生成从0到num_frames-1的序列并插值
		static TArray<float> linear_extrapolate_arange(const TArray<float>& x_known,
			const TArray<float>& y_known,
			int num_frames) {
			TArray<float> x_new;
			x_new.Reserve(num_frames);

			for (int i = 0; i < num_frames; ++i) {
				x_new.Add(static_cast<float>(i));
			}

			return linear_extrapolate(x_known, y_known, x_new);
		}
	};

	class NumpyGradient {
	public:
		// 计算一维数组的梯度，假设均匀间距为1
		static TArray<float> gradient(const TArray<float>& f) {
			return gradient(f, 1.0f);
		}

		// 计算一维数组的梯度，可指定间距
		static TArray<float> gradient(const TArray<float>& f, float dx) {
			int n = f.Num();

			if (n == 0) {
				return TArray<float>();
			}

			if (n == 1) {
				return TArray<float>();
			}

			TArray<float> grad;
			grad.Empty(n);
			grad.AddDefaulted(n);

			// 内部点使用中心差分
			for (int i = 1; i < n - 1; ++i) {
				grad[i] = (f[i + 1] - f[i - 1]) / (2.0f * dx);
			}

			// 边界点使用前向/后向差分
			grad[0] = (f[1] - f[0]) / dx;          // 左边界
			grad[n - 1] = (f[n - 1] - f[n - 2]) / dx; // 右边界

			return grad;
		}

		// 计算一维数组的梯度，可指定非均匀间距
		static TArray<float> gradient(const TArray<float>& f, const TArray<float>& x) {
			int n = f.Num();

			if (n == 0) {
				return TArray<float>();
			}

			if (x.Num() != n) {
				return TArray<float>();
			}

			if (n == 1) {
				return TArray<float>{0.0f};
			}

			TArray<float> grad;
			grad.Empty(n);
			grad.AddDefaulted(n);

			// 内部点使用中心差分
			for (int i = 1; i < n - 1; ++i) {
				float dx1 = x[i] - x[i - 1];
				float dx2 = x[i + 1] - x[i];
				grad[i] = (f[i + 1] - f[i - 1]) / (dx1 + dx2);
			}

			// 边界点使用前向/后向差分
			grad[0] = (f[1] - f[0]) / (x[1] - x[0]);  // 左边界
			grad[n - 1] = (f[n - 1] - f[n - 2]) / (x[n - 1] - x[n - 2]);  // 右边界

			return grad;
		}

		// 二阶梯度（二阶导数）
		static TArray<float> gradient2(const TArray<float>& f, float dx = 1.0f) {
			int n = f.Num();

			if (n < 3) {
				return TArray<float>();
			}

			TArray<float> grad2;
			grad2.Empty(n);
			grad2.AddDefaulted(n);

			// 内部点
			for (int i = 1; i < n - 1; ++i) {
				grad2[i] = (f[i + 1] - 2.0f * f[i] + f[i - 1]) / (dx * dx);
			}

			// 边界点（使用单边差分）
			grad2[0] = (f[2] - 2.0f * f[1] + f[0]) / (dx * dx);
			grad2[n - 1] = (f[n - 1] - 2.0f * f[n - 2] + f[n - 3]) / (dx * dx);

			return grad2;
		}
	};



	typedef TStaticArray<float, 2> array2d_t;

	// 后续改成智能指针，否则很费
	typedef TArray<FVector> array_frame_t;				// 1个人的数据
	typedef TArray<array_frame_t> array_people_frame_t;	// 2级array：reshape(num_people, num_frames, 3)
	typedef TArray<TArray<FVector>> array_frame_52_t;	// 1个人的数据
	typedef TArray<array_frame_52_t> array_people_frame_52_t; // 3级array： reshape(num_people, num_frames, 52, 3)

	enum class EFrameType : uint8
	{
		None,
		ground,
		jump,
		drift,
		ground_err
	};


	template<class T>
	static void set_array_value(TArray<T>& frame_types, int start, int end, const T& v)
	{
		for (int i = start; i < end && i < frame_types.Num(); i++)
		{
			frame_types[i] = v;
		}
	}


	static TArray<float> np_gradient(const TArray<float>& ground_heights)
	{
		return NumpyGradient::gradient(ground_heights);
	}

	// 取最大值， [start, end)
	static float np_max(const TArray<float>& data, int start, int end)
	{
		if (!data.IsValidIndex(start))
		{
			return 0;
		}

		float ret = data[start];
		for (int i = start + 1; i < end && i < data.Num(); i++)
		{
			ret = FMath::Max<float>(ret, data[i]);
		}
		return ret;
	}

	template<class T>
	static int np_sum(const TArray<T>& arr, const T& v)
	{
		int Sum = 0;
		for (const auto& It : arr)
		{
			if (It == v)
			{
				Sum++;
			}
		}
		return Sum;
	}
	static FMatrix R_from_rotvec(const FVector& RotVector)
	{
		//FTransform t(RotVector.Rotation(), FVector::Zero(), FVector::One());
		//return t.ToMatrixWithScale();
		float Angle = RotVector.Size();

		if (Angle < KINDA_SMALL_NUMBER)
		{
			return FMatrix::Identity;
		}

		FVector Axis = RotVector.GetSafeNormal();
		FQuat Quat(Axis, Angle);

		return FQuatRotationMatrix(Quat);
	}
	static FVector op_at(const FMatrix& m, const FVector& rotvec)
	{
		return m.TransformPosition(rotvec);
	}
	static FVector op_at(const FVector& rotvec, const FMatrix& m)
	{
		return m.TransformPosition(rotvec);
	}
	static FMatrix op_at(const FMatrix& m, const FMatrix& m2)
	{
		return m2 * m;
	}
	static float np_min(const array2d_t& a2d)
	{
		check(a2d.Num() == 2);
		return FMath::Min<float>(a2d[0], a2d[1]);
	}
	static TArray<float> np_min(const TArray<array2d_t>& foot_heights)
	{
		TArray<float> ret;
		ret.Reserve(foot_heights.Num());
		for (const auto& It : foot_heights)
		{
			ret.Add(np_min(It));
		}
		return ret;
	}
	static float np_min(const TArray<float>& foot_heights)
	{
		if (foot_heights.Num() == 0)
		{
			return 0;
		}
		auto ret = foot_heights[0];
		for (const auto& It : foot_heights)
		{
			if (It < ret)
			{
				ret = It;
			}
		}
		return ret;
	}
	static float np_max(const TArray<float>& foot_heights)
	{
		if (foot_heights.Num() == 0)
		{
			return 0;
		}
		auto ret = foot_heights[0];
		for (const auto& It : foot_heights)
		{
			if (It > ret)
			{
				ret = It;
			}
		}
		return ret;
	}
	static float np_mean(const TArray<float>& foot_heights)
	{
		if (foot_heights.Num() == 0)
		{
			return 0;
		}
		float sum = 0;
		for (const auto& It : foot_heights)
		{
			sum += It;
		}
		return sum / foot_heights.Num();
	}
	static float np_min(const TArray<FVector>& foot_heights, int Axis)
	{
		if (foot_heights.Num() == 0)
		{
			return 0;
		}
		auto ret = foot_heights[0][Axis];
		for (const auto& It : foot_heights)
		{
			if (It[Axis] < ret)
			{
				ret = It[Axis];
			}
		}
		return ret;
	}
	static float np_max(const TArray<FVector>& foot_heights, int Axis)
	{
		if (foot_heights.Num() == 0)
		{
			return 0;
		}
		auto ret = foot_heights[0][Axis];
		for (const auto& It : foot_heights)
		{
			if (It[Axis] > ret)
			{
				ret = It[Axis];
			}
		}
		return ret;
	}

	template<class T>
	TArray<int> np_where(const TArray<T>& arr, const T& v)
	{
		TArray<int> Ret;

		for (int i = 0; i < arr.Num(); i++)
		{
			if (arr[i] == v)
			{
				Ret.Add(i);
			}
		}
		return Ret;
	}
	template<class T>
	TArray<T> pick_data(const TArray<T>& arr, const TArray<int> indices)
	{
		TArray<T> Ret;
		for (const auto& It : indices)
		{
			if (arr.IsValidIndex(It))
			{
				Ret.Add(arr[It]);
			}
		}
		return Ret;
	}
	template<class T>
	TArray<T> sub_data(const TArray<T>& arr, const T& v)
	{
		TArray<T> Ret;
		for (const auto& It : arr)
		{
			Ret.Add(It - v);
		}
		return Ret;
	}
	template<class T>
	void sub_data(TArray<T>& out, const TArray<T>& arr, int Axis, const T& v)
	{
		for (int i = 0; i < arr.Num(); i++)
		{
			out[Axis][i] = arr[Axis][i] - v;
		}
	}
	TArray<int> np_arange(int N)
	{
		TArray<int> Ret;
		Ret.Reserve(N);
		for (int i = 0; i < N; i++)
		{
			Ret.Add(i);
		}
		return Ret;
	}

	// 修改data[Axis]的数据( out[axis][i] = data[axis][i] - arr[i]）
	template<class T, class T2>
	bool modify_array(TArray<T>& Out, const TArray<T>& data, int Axis, const TArray<T2>& arr)
	{
		// 数组大小必须一样！
		if (arr.Num() != data.Num())
		{
			return false;
		}
		if (Out.Num() != data.Num())
		{
			return false;
		}


		for (int i = 0; i < data.Num(); i++)
		{
			Out[i][Axis] = data[i][Axis] - arr[i];
		}
		return true;
	}

	void np_zeros_like(array_people_frame_t& filtered_transl, const array_people_frame_t& transl)
	{
		filtered_transl.Empty(transl.Num());
		filtered_transl.AddDefaulted(transl.Num());
		for (int i = 0; i < filtered_transl.Num(); i++)
		{
			filtered_transl[i].Empty(transl[i].Num());
			filtered_transl[i].AddDefaulted(transl[i].Num());
		}
	}

	// 一堆常量
	const char* SMPL_JOINTS[] =
	{
		"pelvis",          
		"left_hip",        
		"right_hip",       
		"spine1",          
		"left_knee",       
		"right_knee",      
		"spine2",          
		"left_ankle",      
		"right_ankle",     
		"spine3",          
		"left_foot",       
		"right_foot",      
		"neck",            
		"left_collar",     
		"right_collar",    
		"head",            
		"left_shoulder",   
		"right_shoulder",  
		"left_elbow",      
		"right_elbow",     
		"left_wrist",      
		"right_wrist",     
		"left_index1",     
		"left_index2",     
		"left_index3",     
		"left_middle1",    
		"left_middle2",    
		"left_middle3",    
		"left_pinky1",     
		"left_pinky2",     
		"left_pinky3",     
		"left_ring1",      
		"left_ring2",      
		"left_ring3",      
		"left_thumb1",     
		"left_thumb2",     
		"left_thumb3",     
		"right_index1",    
		"right_index2",    
		"right_index3",    
		"right_middle1",   
		"right_middle2",   
		"right_middle3",   
		"right_pinky1",    
		"right_pinky2",    
		"right_pinky3",    
		"right_ring1",     
		"right_ring2",     
		"right_ring3",     
		"right_thumb1",    
		"right_thumb2",    
		"right_thumb3",    
	};
	// 必须存在的
	const char* MUST_HAVE_BONES[] = 
	{
		"left_hip",
		"left_knee",
		"left_ankle",
		"left_foot",
		"right_hip",
		"right_knee",
		"right_ankle",
		"right_foot",
	};
	constexpr int NUM_BONES = 52;

	// 算法需要的变量
	static TMap<FString, int> SMPL_JOINTS_MAP;
	static TMap<FString, TMap<FString, FVector>> REF_POSE_MAP;
	static FString SmplRefPosString;
	static bool bInited = false;


	extern bool correct_transl_with_foot_constraint(array_frame_t& Out, const array_frame_t& transl_data,
		const TArray<float>& ground_foot_heights, const TArray<EFrameType>& frame_types,
		const TArray<FIntVector2>& jump_segments, float ground_height,
		FOutputDevice* debug_file = nullptr);

	extern bool compute_foot_world_positions(TArray<array2d_t>& Out_foot_heights, const TArray<TArray<FVector>>& pose_data, const TArray<FVector>& transl_data);

	TArray<EFrameType> classify_frames(const TArray<float>& ground_heights, const TArray<FIntVector2>& jump_segments,
		float ground_height, float ground_tolerance, float velocity_threshold);

	extern TArray<FIntVector2> identify_real_jumps(const TArray<float>& ground_heights, float ground_height,
		int max_jump_frames, float min_jump_height, float max_jump_height, float velocity_threshold,
		FOutputDevice* debug_file);

	void Init()
	{
		SMPL_JOINTS_MAP.Empty();
		int Cnt = UE_ARRAY_COUNT(SMPL_JOINTS);
		for (int i = 0; i < Cnt; i++)
		{
			SMPL_JOINTS_MAP.FindOrAdd(SMPL_JOINTS[i], i);
		}
		if (SMPL_JOINTS_MAP.Num() != Cnt)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("Init, invalid SMPL_JOINTS_MAP.Num=%d"), SMPL_JOINTS_MAP.Num());

			SMPL_JOINTS_MAP.Empty();
		}
		SMPL_JOINTS_MAP.Shrink();
	}
	static FString GetRootDir()
	{
		return FPaths::Combine(*FPaths::ProjectSavedDir(), TEXT("ai_anim"));
	}



	static bool get_world_transform(FVector& OutWorldPos, FMatrix& OutWorldRot, const char* joint_name, const TArray<FVector>& pose_frame, const FVector& parent_world_pos, const FMatrix& parent_world_rot)
	{
		// """计算关节的世界位置和旋转"""
		auto joint_idx = SMPL_JOINTS_MAP.Find(joint_name);
		if (joint_idx == nullptr || !pose_frame.IsValidIndex(*joint_idx))
		{
			UE_LOG(LogAIAnim, Warning, TEXT("get_world_transform, invalid joint_name=%hs"), joint_name);
			return false;
		}
		auto ptr = REF_POSE_MAP.Find(joint_name);
		if (ptr == nullptr)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("get_world_transform, invalid joint_name=%hs"), joint_name);
			return false;
		}
		auto ptr_trans = ptr->Find("translation");
		if (ptr_trans == nullptr)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("get_world_transform, invalid joint data=%hs"), joint_name);
			return false;
		}

		auto rotvec = pose_frame[*joint_idx];
		auto local_trans = *ptr_trans;//REF_POSE_MAP[joint_name]["translation"];
		auto local_rot = R_from_rotvec(rotvec);
		auto world_rot = op_at(parent_world_rot, local_rot);
		auto world_pos = parent_world_pos + op_at(parent_world_rot, local_trans);

		OutWorldPos = world_pos;
		OutWorldRot = world_rot;

		return true;
	}

	static bool compute_single_frame_foot_positions(FVector& Out_left_foot_pos, FVector& Out_right_foot_pos, const TArray<FVector>& pose_frame, const FVector& transl, bool return_full_pos = false)
	{
		if (pose_frame.Num() < NUM_BONES)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("compute_single_frame_foot_positions, invalid pose_frame.Num=%d"), pose_frame.Num());
			return false;
		}
		/*
		"""
		计算单帧中左右脚的世界 Y 坐标

		参数:
			pose_frame: (52, 3) 当前帧的 pose 数据（角轴表示）
			transl: (3,) root 的世界位置
			REF_POSE_MAP: 参考骨架字典
			return_full_pos: 是否返回完整的 xyz 坐标

		返回:
			如果 return_full_pos=False: left_foot_y, right_foot_y
			如果 return_full_pos=True: (left_foot_pos, right_foot_pos) 其中每个是 (3,) 数组
		"""
		*/

		// # 从 pelvis 开始
		auto pelvis_world_pos = transl;
		auto pelvis_rotvec = pose_frame[0]; // # pelvis 是索引 0
		auto pelvis_world_rot = R_from_rotvec(pelvis_rotvec);

		// # 计算左脚链: pelvis → left_hip → left_knee → left_ankle → left_foot
		FVector left_hip_pos(ForceInit);
		FMatrix left_hip_rot(ForceInit);
		bool b1 = get_world_transform(left_hip_pos, left_hip_rot, "left_hip", pose_frame, pelvis_world_pos, pelvis_world_rot);

		FVector left_knee_pos(ForceInit);
		FMatrix left_knee_rot(ForceInit);
		bool b2 = b1 && get_world_transform(left_knee_pos, left_knee_rot, "left_knee", pose_frame, left_hip_pos, left_hip_rot);

		FVector left_ankle_pos(ForceInit);
		FMatrix left_ankle_rot(ForceInit);
		bool b3 = b2 && get_world_transform(left_ankle_pos, left_ankle_rot, "left_ankle", pose_frame, left_knee_pos, left_knee_rot);

		FVector left_foot_pos(ForceInit);
		FMatrix left_foot_rot(ForceInit);
		bool b4 = b3 && get_world_transform(left_foot_pos, left_foot_rot, "left_foot", pose_frame, left_ankle_pos, left_ankle_rot);

		// # 计算右脚链: pelvis → right_hip → right_knee → right_ankle → right_foot
		FVector right_hip_pos(ForceInit);
		FMatrix right_hip_rot(ForceInit);
		bool b5 = b4 && get_world_transform(right_hip_pos, right_hip_rot, "right_hip", pose_frame, pelvis_world_pos, pelvis_world_rot);

		FVector right_knee_pos(ForceInit);
		FMatrix right_knee_rot(ForceInit);
		bool b6 = b5 && get_world_transform(right_knee_pos, right_knee_rot, "right_knee", pose_frame, right_hip_pos, right_hip_rot);

		FVector right_ankle_pos(ForceInit);
		FMatrix right_ankle_rot(ForceInit);
		bool b7 = b6 && get_world_transform(right_ankle_pos, right_ankle_rot, "right_ankle", pose_frame, right_knee_pos, right_knee_rot);

		FVector right_foot_pos(ForceInit);
		FMatrix right_foot_rot(ForceInit);
		bool b8 = b7 && get_world_transform(right_foot_pos, right_foot_rot, "right_foot", pose_frame, right_ankle_pos, right_ankle_rot);

		Out_left_foot_pos = left_foot_pos;
		Out_right_foot_pos = right_foot_pos;

		return b8;
	}




	bool filter_transl_per_person_with_foot_detection(array_frame_t& Out, const array_frame_t& transl_data,
		const array_frame_52_t& pose_data, int fps = 30, 
		int person_idx = 0,
		FOutputDevice* debug_file = nullptr, 
		float max_jump_duration_sec = 0.8f,
		float min_jump_height=0.05f, float max_jump_height=0.8f, float jump_velocity_threshold=0.1f,
		float ground_tolerance=0.01f, float ground_velocity_threshold=0.02f)
	{
		/*
			"""
			基于脚部坐标的滤波：
			1. 计算脚部的世界坐标
			2. 用较低的脚的 Y 值判断地面接触
			3. 识别真正的跳跃段
			4. 其余时间校正 transl 的 Y 值
			"""
		*/

		auto num_frames = transl_data.Num();
		//array_frame_t filtered_data = transl_data; // 值拷贝一份

		// # 计算所有帧的脚部世界坐标
		TArray<array2d_t> foot_heights;
		compute_foot_world_positions(foot_heights, pose_data, transl_data);

		// # 使用较低的脚作为地面参考
		auto ground_foot_heights = np_min(foot_heights);
		if (ground_foot_heights.Num() == 0)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("filter_transl_per_person_with_foot_detection, invalid ground_foot_heights"));
			return false;
		}

		// # 先验1: 第一帧的较低脚是真实地面高度
		auto true_ground_height = ground_foot_heights[0];

		auto max_jump_frames = int(max_jump_duration_sec * fps);
		auto jump_velocity_threshold_per_frame = jump_velocity_threshold / fps;
		auto ground_velocity_threshold_per_frame = ground_velocity_threshold / fps;

		if (debug_file)
		{
			FVector left_foot_pos_0(ForceInit), right_foot_pos_0(ForceInit);
			compute_single_frame_foot_positions(left_foot_pos_0, right_foot_pos_0, pose_data[0], transl_data[0], true);

			debug_file->Logf(TEXT("\n=== 基于脚部坐标的滤波 - 人物 {%d} ===\n"), person_idx);
			debug_file->Logf(TEXT("\n第一帧数据分析:\n"));
			debug_file->Logf(TEXT("  Root 位置 (transl): [{%.6f}, {%.6f}, {%.6f}]\n"),
				transl_data[0][0], transl_data[0][1], transl_data[0][2]);
			debug_file->Logf(TEXT("  左脚世界位置: [{%.6f}, {%.6f}, {%.6f}]\n"),
				left_foot_pos_0[0], left_foot_pos_0[1], left_foot_pos_0[2]);
			debug_file->Logf(TEXT("  右脚世界位置: [{%.6f}, {%.6f}, {%.6f}]\n"),
				right_foot_pos_0[0], right_foot_pos_0[1], right_foot_pos_0[2]);
			debug_file->Logf(TEXT("  较低脚的高度（地面参考）: {%.6f}\n"), true_ground_height);
			debug_file->Logf(TEXT("  Root 到较低脚的距离: {%.6f}\n"),
				transl_data[0][1] - true_ground_height);
			debug_file->Logf(TEXT("\n数据范围:\n"));
			debug_file->Logf(TEXT("  脚部高度范围: {%.6f} ~ {%.6f}\n"),
				np_min(ground_foot_heights), 
				np_max(ground_foot_heights));
			debug_file->Logf(TEXT("  Root 高度范围: {%.6f} ~ {%.6f}\n"),
				np_min(transl_data, 1),
				np_max(transl_data, 1));
			debug_file->Logf(TEXT("\n滤波参数:\n"));
			debug_file->Logf(TEXT("  最大跳跃时长: {%d}帧 ({%.3f}秒)\n"), max_jump_frames, max_jump_duration_sec);
			debug_file->Logf(TEXT("  跳跃高度范围: {%.3f} ~ {%.3f}米\n"), min_jump_height, max_jump_height);
		}

		// # 步骤1: 识别真正的跳跃段（基于脚部高度）
		auto jump_segments = identify_real_jumps(
			ground_foot_heights, true_ground_height, max_jump_frames, 
			min_jump_height, max_jump_height, jump_velocity_threshold_per_frame, 
			debug_file);

		// # 步骤2: 标记地面帧和跳跃帧
		auto frame_types = classify_frames(ground_foot_heights, jump_segments, true_ground_height,
			ground_tolerance, ground_velocity_threshold_per_frame);

		// # 步骤3: 计算每一帧脚的漂移，并校正 transl
		array_frame_t corrected_transl;
		correct_transl_with_foot_constraint(corrected_transl,
			transl_data, ground_foot_heights, frame_types, jump_segments,
			true_ground_height, debug_file
		);

		//filtered_data = corrected_transl;

		if (debug_file)
		{
			TArray<array2d_t> corrected_foot_heights;
			compute_foot_world_positions(corrected_foot_heights, pose_data, corrected_transl);
			auto corrected_ground_heights = np_min(corrected_foot_heights);

			debug_file->Logf(TEXT("\n滤波结果分析:\n"));
			debug_file->Logf(TEXT("校正后脚部范围: {%.6f} ~ {%.6f}\n"),
				np_min(corrected_ground_heights), np_max(corrected_ground_heights));
			debug_file->Logf(TEXT("第一帧脚部高度: {%.6f} (应为: {%.6f})\n"), corrected_ground_heights[0], true_ground_height);
			debug_file->Logf(TEXT("最后帧脚部高度: {%.6f}\n"), corrected_ground_heights.Last());

			auto ground_frames = np_sum<EFrameType>(frame_types, EFrameType::ground);
			auto jump_frames = np_sum<EFrameType>(frame_types, EFrameType::jump);
			auto drift_frames = np_sum<EFrameType>(frame_types, EFrameType::drift);

			debug_file->Logf(TEXT("帧类型统计:\n"));
			debug_file->Logf(TEXT("  地面帧: {%d} ({%.1f}%)\n"),
				ground_frames, 1.0f* ground_frames / num_frames * 100);
			debug_file->Logf(TEXT("  跳跃帧: {%d} ({%.1f}%)\n"),
				jump_frames, 1.0f* jump_frames / num_frames * 100);
			debug_file->Logf(TEXT("  漂移帧: {%d} ({%.1f}%)\n"),
				drift_frames, 1.0f* drift_frames / num_frames * 100);

			if (jump_segments.Num() > 0)
			{
				debug_file->Logf(TEXT("\n检测到的跳跃段:\n"));
				for (int i = 0; i < jump_segments.Num(); i++)
				{
					const auto& It = jump_segments[i];
					auto start = It.X;
					auto end = It.Y;
					auto duration_ms = (end - start + 1) * 1000.0f / fps;
					auto max_height = np_max(corrected_ground_heights, start, end + 1);
					auto jump_height = max_height - true_ground_height;

					debug_file->Logf(TEXT("  跳跃{%d}: 帧{%d}-{%d} ({%.3f}ms), 高度{%.3f}m\n"),
						i+1, start, end, duration_ms, jump_height);
				}
			}
		}

		Out = std::move(corrected_transl);
		return true;
	}


	// 返回每帧“左右脚的Y轴值”
	bool compute_foot_world_positions(TArray<array2d_t>& Out_foot_heights, const TArray<TArray<FVector>>& pose_data, const TArray<FVector>& transl_data)
	{
		/*
			"""
			计算所有帧中左右脚的世界坐标

			参数:
				pose_data: (num_frames, 52, 3) pose 数据（角轴表示）
				transl_data: (num_frames, 3) root 的世界位置
				REF_POSE_MAP: 参考骨架字典

			返回:
				foot_heights: (num_frames, 2) 每帧的 [left_foot_y, right_foot_y]
			"""
		*/
		const int YAxis = 1;

		auto num_frames = pose_data.Num();
		TArray<array2d_t>& foot_heights = Out_foot_heights;
		foot_heights.Empty(num_frames);
		foot_heights.AddDefaulted(num_frames);

		for (int i = 0; i < num_frames; i++)
		{
			const auto& pose_frame = pose_data[i];
			const auto& transl_frame = transl_data[i];

			FVector left_foot_y(ForceInit);
			FVector right_foot_y(ForceInit);
			compute_single_frame_foot_positions(left_foot_y, right_foot_y, pose_frame, transl_frame);

			foot_heights[i][0] = left_foot_y[YAxis];
			foot_heights[i][1] = right_foot_y[YAxis];
		}
		return true;
	}

	// 
	TArray<FIntVector2> find_continuous_segments(const TArray<bool>& boolean_array)
	{
		/*
			"""
			找到布尔数组中连续为True的段
			"""
		*/

		TArray<FIntVector2> Ret;
		constexpr int INVALID_INDEX = -1;
		int start_idx = INVALID_INDEX;

		for (int i = 0; i < boolean_array.Num(); i++)
		{
			auto is_true = boolean_array[i];
			if (is_true && start_idx == INVALID_INDEX)
			{
				start_idx = i;
			}
			else if (!is_true && start_idx != INVALID_INDEX)
			{
				Ret.Add(FIntVector2(start_idx, i-1));
				start_idx = INVALID_INDEX;
			}
		}

		if (start_idx != INVALID_INDEX)
		{
			Ret.Add(FIntVector2(start_idx, boolean_array.Num() - 1));
		}

		return Ret;
	}


	TArray<FIntVector2> identify_real_jumps(const TArray<float>& ground_heights, float ground_height,
		int max_jump_frames, float min_jump_height, float max_jump_height, float velocity_threshold, 
		FOutputDevice* debug_file)
	{
		/*
		    """
			识别真正的跳跃段（基于脚部高度）
			"""
		*/

		auto num_frames = ground_heights.Num();
		auto velocity = np_gradient(ground_heights);

		TArray<bool> above_ground;
		above_ground.Empty(ground_heights.Num());
		above_ground.AddDefaulted(ground_heights.Num());
		for (int i = 0; i < ground_heights.Num(); i++)
		{
			above_ground[i] = ground_heights[i] > (ground_height + min_jump_height);
		}

		if (debug_file)
		{
			int N = np_sum(above_ground, true);
			debug_file->Logf(TEXT("可能离地的帧数: %d\n"), N);
		}

		auto potential_jumps = find_continuous_segments(above_ground);

		TArray<FIntVector2> valid_jumps;
		for (const auto& It : potential_jumps)
		{
			auto start = It.X;
			auto end = It.Y;
			auto duration = end - start + 1;
			auto max_height_in_segment = np_max(ground_heights, start, end + 1);
			auto jump_height = max_height_in_segment - ground_height;
			auto is_valid_duration = duration <= max_jump_frames;
			auto is_valid_height = min_jump_height <= jump_height && jump_height <= max_jump_height;

			auto has_takeoff_velocity = false;
			auto has_landing_velocity = false;

			if (start > 0 && velocity.IsValidIndex(start))
			{
				auto takeoff_velocity = FMath::Abs(velocity[start]);
				has_takeoff_velocity = takeoff_velocity >= velocity_threshold;
			}

			if ((end < num_frames - 1) && velocity.IsValidIndex(end))
			{
				auto landing_velocity = FMath::Abs(velocity[end]);
				has_landing_velocity = landing_velocity >= velocity_threshold;
			}

			if (is_valid_duration && is_valid_height
				&& (has_takeoff_velocity || has_landing_velocity))
			{
				valid_jumps.Add(FIntVector2(start, end));
				if (debug_file)
				{
					debug_file->Logf(TEXT("有效跳跃: 帧{%d}-{%d}, 时长{%d}帧, 高度{%.3f}m\n"), 
						start, end, duration, jump_height);
				}
			}
			else
			{
				if (debug_file)
				{
					debug_file->Logf(TEXT("无效跳跃: 帧{%d}-{%d}, 时长{%d}帧, 高度{%.3f}m\n"),
						start, end, duration, jump_height);
					debug_file->Logf(TEXT("(时长OK:{%d}, 高度OK:{%d}, 速度OK:{%d})\n"),
						is_valid_duration, is_valid_height, has_takeoff_velocity || has_landing_velocity);
				}
			}

		}

		return valid_jumps;
	}

	TArray<EFrameType> classify_frames(const TArray<float>& ground_heights, const TArray<FIntVector2>& jump_segments, 
		float ground_height, float ground_tolerance, float velocity_threshold)
	{
		/*
			"""
			将每一帧分类为：ground（地面）、jump（跳跃）、drift（漂移）
			"""
		*/
		TArray<EFrameType> frame_types;
		if (ground_heights.Num() == 0)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("classify_frames, invalid ground_heights.Num=%d"), ground_heights.Num());
			return frame_types;
		}

		auto num_frames = ground_heights.Num();
		frame_types.Empty(num_frames);
		frame_types.AddDefaulted(num_frames);
		set_array_value(frame_types, 0, frame_types.Num(), EFrameType::drift);

		// # 标记跳跃帧
		auto velocity = np_gradient(ground_heights);
		for (const auto& It : jump_segments)
		{
			auto start = It.X;
			auto end = It.Y;
			set_array_value(frame_types, start, end+1, EFrameType::jump);
		}

		if (velocity.Num() < num_frames)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("classify_frames, invalid velocity.Num=%d"), velocity.Num());
			return frame_types;
		}

		// # 标记地面帧（不在跳跃段内，且接近地面高度，速度较小）
		for (int i = 0; i < num_frames; i++)
		{
			if (frame_types[i] != EFrameType::jump)
			{
				auto height_diff = FMath::Abs(ground_heights[i] - ground_height);
				auto is_near_ground = height_diff <= ground_tolerance;
				auto is_stable = FMath::Abs(velocity[i]) <= velocity_threshold;

				if (is_near_ground && is_stable)
				{
					frame_types[i] = EFrameType::ground_err; // todo. 改成正确的
				}
			}
		}

		return frame_types;
	}



	bool correct_transl_with_foot_constraint(array_frame_t& Out, const array_frame_t& transl_data,
		const TArray<float>& ground_foot_heights, const TArray<EFrameType>& frame_types,
		const TArray<FIntVector2>& jump_segments, float ground_height,
		FOutputDevice* debug_file)
	{
	/*
	    """
		基于脚部地面约束校正 transl 的 Y 值
    
		核心思路:
		1. 计算每一帧脚的漂移 = 实际脚高 - 应有脚高
		2. 用脚的漂移来校正 transl 的 Y 值
		"""	
	*/
		auto corrected_transl = transl_data;
		auto num_frames = transl_data.Num();


		if (frame_types.Num() < num_frames)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("correct_transl_with_foot_constraint, invalid frame_types.Num=%d, frames=%d"),
				frame_types.Num(), num_frames);
			return false;
		}
		// # 找到所有地面帧
		auto ground_frame_indices = np_where(frame_types, EFrameType::ground);

		if (ground_frame_indices.Num() == 0)
		{
			// # 如果没有检测到地面帧，强制第一帧为地面
			ground_frame_indices.Add(0);
			if (debug_file)
			{
				debug_file->Logf(TEXT("警告: 没有检测到地面帧，使用第一帧作为参考\n"));
			}
		}

		// # 计算地面帧的脚部漂移
		auto ground_heights_at_ground_frames = pick_data(ground_foot_heights, ground_frame_indices);
		auto ground_drifts = sub_data(ground_heights_at_ground_frames, ground_height);

		if (ground_frame_indices.Num() != ground_drifts.Num())
		{
			UE_LOG(LogAIAnim, Warning, TEXT("correct_transl_with_foot_constraint, invalid ground_frame_indices.Num=%d, %d"), 
				ground_frame_indices.Num(), ground_drifts.Num());

			return false;
		}

		if (debug_file)
		{
			debug_file->Logf(TEXT("地面帧脚部漂移统计:\n"));
			debug_file->Logf(TEXT("  平均漂移: {%.6f}m\n"), np_mean(ground_drifts));
			debug_file->Logf(TEXT("  最大漂移: {%.6f}m\n"), np_max(ground_drifts));
			debug_file->Logf(TEXT("  最小漂移: {%.6f}m\n"), np_min(ground_drifts));
		}

		// # 使用线性插值计算每一帧的脚部漂移
		TArray<float> frame_drifts;
		if (ground_frame_indices.Num() == 1)
		{
			// # 只有一个地面帧，假设线性漂移
			auto drift_per_frame = ground_drifts[0] / (ground_frame_indices[0] + 1);
			frame_drifts.Reserve(num_frames);
			for (int i = 0; i < num_frames; i++)
			{
				frame_drifts.Add(drift_per_frame * i);
			}
		}
		else
		{
			// # 多个地面帧，使用插值
			auto x_new = np_arange(num_frames);

			auto TempV = Interp1D::linear_extrapolate_int(Interp1D::transform<int, float>(ground_frame_indices), ground_drifts, x_new);
			frame_drifts = std::move(TempV);
		}

		// # 应用漂移校正到 transl 的 Y 值
		constexpr int YAxis = 1;
		ensure(corrected_transl.Num() == transl_data.Num());
		ensure(corrected_transl.Num() == frame_drifts.Num());

		if (corrected_transl.Num() != transl_data.Num()
			|| corrected_transl.Num() != frame_drifts.Num())
		{
			UE_LOG(LogAIAnim, Warning, TEXT("correct_transl_with_foot_constraint, invalid frame_drifts.Num=%d, %d, %d"),
				corrected_transl.Num(),
				transl_data.Num(), frame_drifts.Num());

			return false;
		}

		modify_array(corrected_transl, transl_data, YAxis, frame_drifts);

		// # 强制第一帧的脚回到地面高度
		auto first_frame_foot_drift = ground_foot_heights[0] - ground_height;
		corrected_transl[0][YAxis] = corrected_transl[0][YAxis] - first_frame_foot_drift;

		if (ground_foot_heights.Num() < num_frames)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("correct_transl_with_foot_constraint, invalid ground_foot_heights.Num=%d, %d"),
				ground_foot_heights.Num(), num_frames);
			return false;
		}
		if (corrected_transl.Num() < num_frames)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("correct_transl_with_foot_constraint, invalid corrected_transl.Num=%d, %d"),
				corrected_transl.Num(), num_frames);
			return false;
		}

		for (int i = 0; i < num_frames; i++)
		{
			if (!frame_types.IsValidIndex(i))
			{
				continue;
			}

			if (frame_types[i] == EFrameType::ground)
			{
				auto foot_drift = ground_foot_heights[i] - ground_height;
				corrected_transl[i][YAxis] = corrected_transl[i][YAxis] - foot_drift;
			}
			else if (frame_types[i] == EFrameType::drift)
			{
				auto in_jump_vicinity = false;
				for (const auto& It : jump_segments)
				{
					auto start = It.X;
					auto end = It.Y;
					// # 跳跃段前后2帧
					if (FMath::Abs(i - start) <= 2
						|| FMath::Abs(i - end) <= 2)
					{
						in_jump_vicinity = true;
					}
				}
				if (!in_jump_vicinity)
				{
					auto foot_drift = ground_foot_heights[i] - ground_height;
					corrected_transl[i][YAxis] = corrected_transl[i][YAxis] - foot_drift;
				}
			}

		}

		Out = std::move(corrected_transl);
		return true;
	}

	void filter_transl(array_people_frame_t& Outfiltered_transl, TArray<float>& Outfoot_offsets, const array_people_frame_t& transl, const array_people_frame_52_t& pose, int fps, FOutputDevice* debug_file)
	{
		auto num_people = transl.Num();
		array_people_frame_t& filtered_transl = Outfiltered_transl;
		np_zeros_like(filtered_transl, transl);

		TArray<float>& foot_offsets = Outfoot_offsets;
		foot_offsets.Empty();

		for (int person_idx = 0; person_idx < num_people; person_idx++)
		{
			const auto& person_transl = transl[person_idx];
			const auto& person_pose = pose[person_idx];

			// # 计算第一帧的脚部位置
			FVector left_foot_pos_0(ForceInit), right_foot_pos_0(ForceInit);
			compute_single_frame_foot_positions(left_foot_pos_0, right_foot_pos_0, 
				person_pose[0], person_transl[0], true);

			// # 计算 Root 到较低脚的距离
			auto lower_foot_y = FMath::Min<float>(left_foot_pos_0.Y, right_foot_pos_0.Y);
			auto foot_offset = person_transl[0].Y - lower_foot_y;
			foot_offsets.Add(foot_offset);

			filter_transl_per_person_with_foot_detection(filtered_transl[person_idx], person_transl,
				person_pose, fps, person_idx, debug_file);

		}

		//return filtered_transl, foot_offsets;
	}

	bool LoadSmplJson()
	{
		REF_POSE_MAP.Empty();

		FString JsonString;

		if (SmplRefPosString.IsEmpty())
		{
			// 尝试从smpl中读取，调试用的
#if !UE_BUILD_SHIPPING
			FString FilePath = GetRootDir() / TEXT("smpl_pose.json");

			if (!FFileHelper::LoadFileToString(JsonString, *FilePath))
			{
				UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, Failed to load JSON file: %s"), *FilePath);
				return false;
			}
#endif
		}
		else
		{
			JsonString = SmplRefPosString;
		}

		if (JsonString.IsEmpty())
		{
			UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, Failed to load JSON string"));
			return false;
		}

		TSharedPtr<FJsonObject> JsonObject;
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);

		if (!FJsonSerializer::Deserialize(Reader, JsonObject) || !JsonObject.IsValid())
		{
			UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, Failed to parse JSON"));
			return false;
		}

		// 遍历所有键（bone names）
		TMap<FString, FBoneTransformData> SmplInfo;
		for (const auto& Entry : JsonObject->Values)
		{
			FString BoneName = Entry.Key;
			TSharedPtr<FJsonValue> BoneValue = Entry.Value;
			auto Ptr = SmplInfo.Find(BoneName);
			if (Ptr != nullptr)
			{
				UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, Same Bone:%s"), *BoneName);
				continue;
			}
			else
			{
				SmplInfo.Add(BoneName, FBoneTransformData());
				Ptr = SmplInfo.Find(BoneName);
			}


			if (BoneValue->Type == EJson::Object)
			{
				TSharedPtr<FJsonObject> BoneObject = BoneValue->AsObject();

				FBoneTransformData& BoneData = *Ptr;

				// 读取 rotation 数组
				if (BoneObject->HasField(TEXT("rotation")))
				{
					const TArray<TSharedPtr<FJsonValue>>* RotationArray;
					if (BoneObject->TryGetArrayField(TEXT("rotation"), RotationArray))
					{
						TArray<float> Rotation;
						for (const TSharedPtr<FJsonValue>& Value : *RotationArray)
						{
							float FloatValue = static_cast<float>(Value->AsNumber());
							Rotation.Add(FloatValue);
						}
						if (Rotation.Num() == 3)
						{
							BoneData.Rotation = FVector(Rotation[0], Rotation[1], Rotation[2]);
						}
						else
						{
							UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, Rotation count error! cnt=%d"), Rotation.Num());
						}
					}
				}

				// 读取 translation 数组
				if (BoneObject->HasField(TEXT("translation")))
				{
					const TArray<TSharedPtr<FJsonValue>>* TranslationArray;
					if (BoneObject->TryGetArrayField(TEXT("translation"), TranslationArray))
					{
						TArray<float> Translation;
						for (const TSharedPtr<FJsonValue>& Value : *TranslationArray)
						{
							float FloatValue = static_cast<float>(Value->AsNumber());
							Translation.Add(FloatValue);
						}
						if (Translation.Num() == 3)
						{
							BoneData.Translation = FVector(Translation[0], Translation[1], Translation[2]);
						}
						else
						{
							UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, Translation count error! cnt=%d"), Translation.Num());
						}
						
					}
				}

				// 读取 orientation 数组
				if (BoneObject->HasField(TEXT("orientation")))
				{
					const TArray<TSharedPtr<FJsonValue>>* OrientationArray;
					if (BoneObject->TryGetArrayField(TEXT("orientation"), OrientationArray))
					{
						TArray<float> Orientation;
						for (const TSharedPtr<FJsonValue>& Value : *OrientationArray)
						{
							float FloatValue = static_cast<float>(Value->AsNumber());
							Orientation.Add(FloatValue);
						}
						if (Orientation.Num() == 4)
						{
							BoneData.Orientation = FQuat(Orientation[0], Orientation[1], Orientation[2], Orientation[3]);
						}
						else
						{
							UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, Orientation count error! cnt=%d"), Orientation.Num());
						}
					}
				}

				// 读取 parent
				if (BoneObject->HasField(TEXT("parent")))
				{
					FString ParentName;
					if (BoneObject->TryGetStringField(TEXT("parent"), ParentName))
					{
						BoneData.Parent = ParentName;
					}
				}
			}
		}

		// 检查数量，必须是52个
		if (SmplInfo.Num() < NUM_BONES)
		{
			// 打印错误
			UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, Bone count error! cnt=%d"), SmplInfo.Num());
			return false;
		}


		// 骨骼数目不对！
		int Cnt = UE_ARRAY_COUNT(SMPL_JOINTS);
		if (Cnt < NUM_BONES)
		{
			return false;
		}

		// 检查，必须都得有合法的父子关系
		for (int i = 0; i < Cnt; i++)
		{
			auto BoneInfoPtr = SmplInfo.Find(SMPL_JOINTS[i]);
			if (BoneInfoPtr == nullptr)
			{
				UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, InValid Bone Name=%hs"), SMPL_JOINTS[i]);
				return false;
			}
			if (BoneInfoPtr->Parent.IsEmpty())
			{
				UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, InValid Bone Parent=%hs"), SMPL_JOINTS[i]);
				return false;
			}
			if (SmplInfo.Find(BoneInfoPtr->Parent) == nullptr)
			{
				UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, InValid Bone Parent=%hs, Parent=%s"), SMPL_JOINTS[i], *BoneInfoPtr->Parent);
				return false;
			}
		}

		// 检查，必须都得有一些特定的骨骼
		Cnt = UE_ARRAY_COUNT(MUST_HAVE_BONES);
		for (int i = 0; i < Cnt; i++)
		{
			if (SmplInfo.Find(MUST_HAVE_BONES[i]) == nullptr)
			{
				UE_LOG(LogAIAnim, Warning, TEXT("LoadSmplJson, InValid Bone Name=%hs"), MUST_HAVE_BONES[i]);
				return false;
			}
		}

		for (const auto& It : SmplInfo)
		{
			auto& VMap = REF_POSE_MAP.Add(It.Key);
			VMap.Add("rotation", It.Value.Rotation);
			VMap.Add("translation", It.Value.Translation);
		}
		REF_POSE_MAP.Shrink();

		return true;
	}

	bool DoTranslFilter(TArray<float>& OutTransl, TArray<float>& OutFootOffsets, const array_people_frame_t& transl, const array_people_frame_52_t& pose, int fps)
	{
		// 初始化：refpose等
		if (!bInited)
		{
			IFileManager::Get().MakeDirectory(*GetRootDir());

			Init();

			LoadSmplJson();

			bInited = true;
		}

		if (SMPL_JOINTS_MAP.Num() != NUM_BONES)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("DoTranslFilter, invalid REF_POSE_MAP.Num=%d"), REF_POSE_MAP.Num());
			return false;
		}

		if (REF_POSE_MAP.Num() < NUM_BONES)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("DoTranslFilter, invalid REF_POSE_MAP.Num=%d"), REF_POSE_MAP.Num());
			return false;
		}	
		if (fps <= 10)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("DoTranslFilter, invalid FPS=%d"), fps);
			return false;
		}

		// 干活
		array_people_frame_t filtered_transl;
		TArray<float> foot_offsets;

		{
#if !UE_BUILD_SHIPPING
			if (bAIAnimFloatingFootDebug)
			{
				FString FilePath = FPaths::Combine(GetRootDir(), TEXT("c7_data_debug_v2.txt"));
				auto FileAr = TUniquePtr<FArchive>(IFileManager::Get().CreateDebugFileWriter(*FilePath));
				FOutputDeviceArchiveWrapper OutputLog(FileAr.Get());

				filter_transl(filtered_transl, foot_offsets, transl, pose, fps, &OutputLog);
			}
			else
#endif
			{
				filter_transl(filtered_transl, foot_offsets, transl, pose, fps, nullptr);
			}

			// 如果数量对不上，说明也有问题
			bool bSucc = true;
			if (filtered_transl.Num() != transl.Num())
			{
				bSucc = false;
				UE_LOG(LogAIAnim, Warning, TEXT("DoTranslFilter, invalid filtered_transl.Num=%d"), filtered_transl.Num());
			}
			else
			{
				for(int i=0; i< filtered_transl.Num(); i++)
				{
					if (transl[i].Num() != filtered_transl[i].Num())
					{
						bSucc = false;
						UE_LOG(LogAIAnim, Warning, TEXT("DoTranslFilter, invalid filtered_transl[%d].Num=%d"), i, filtered_transl[i].Num());
					}
				}
			}

			if (bSucc)
			{
				// 脚偏移的数量和人数，得对上
				if (foot_offsets.Num() != filtered_transl.Num())
				{
					UE_LOG(LogAIAnim, Warning, TEXT("DoTranslFilter, invalid foot_offsets.Num=%d, filtered_transl.Num=%d"), foot_offsets.Num(), filtered_transl.Num());
					bSucc = false;
				}
			}

			if (!bSucc)
			{
				return false;
			}
		}

		if (filtered_transl.Num() == 0)
		{
			return false;
		}

		OutTransl.Empty();
		OutTransl.Reserve(filtered_transl.Num() * filtered_transl[0].Num() * 3);
		for (const auto& It : filtered_transl)
		{
			for (const auto& Jt : It)
			{
				OutTransl.Add(Jt.X);
				OutTransl.Add(Jt.Y);
				OutTransl.Add(Jt.Z);
			}
		}
		OutFootOffsets = foot_offsets;

		return true;
	}

	static TArray<float> DecodeBase64ToFloatArray(const FString& Base64String)
	{
		TArray<float> FloatArray;
		if (Base64String.IsEmpty())
		{
			UE_LOG(LogAIAnim, Warning, TEXT("DecodeBase64ToFloatArray, Base64 string is empty"));
			return FloatArray;
		}
		// 解码Base64
		TArray<uint8> BinaryData;
		FBase64::Decode(Base64String, BinaryData);

		if ((BinaryData.Num() % sizeof(float)) != 0)
		{
			UE_LOG(LogAIAnim, Warning, TEXT("DecodeBase64ToFloatArray, Base64 decode error"));
			return FloatArray;
		}

		// 将二进制数据转换为float数组
		int32 NumFloats = BinaryData.Num() / sizeof(float);
		FloatArray.Reserve(NumFloats);

		const float* FloatPtr = reinterpret_cast<const float*>(BinaryData.GetData());
		for (int32 i = 0; i < NumFloats; i++)
		{
			FloatArray.Add(FloatPtr[i]);
		}
		return FloatArray;
	}

	static bool GetJsonData(const FString& FilePath,
		TArray<float>& OutTransl, TArray<float>& OutPose, int& OutPeople, 
		float& OutFrameRate, int& OutFrameNum,
		TArray<float>& OutOffsets)
	{
#if !UE_BUILD_SHIPPING
		FString JsonString;
		if (!FFileHelper::LoadFileToString(JsonString, *FilePath))
		{
			UE_LOG(LogAIAnim, Warning, TEXT("Failed to load JSON file: %s"), *FilePath);
			return false;
		}

		TSharedPtr<FJsonObject> JsonObject;
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);

		if (!FJsonSerializer::Deserialize(Reader, JsonObject) || !JsonObject.IsValid())
		{
			UE_LOG(LogAIAnim, Warning, TEXT("Failed to parse JSON"));
			return false;
		}
		float FrameRate = 15;
		int num_people = 0;
		int num_joints = 52;
		int num_frames = 0;
		FString poseBase64;
		FString translBase64;
		FString camera_TBase64;
		FString camera_RBase64;
		FString audioBase64;
		FString emotionBase64;
		FString emotionConfBase64;
		FString validMaskBase64;
		const TArray<TSharedPtr<FJsonValue>>* foot_offset = nullptr;
		TArray<float> FootOffsetYArray;

		//如果存在 result 字段，直接使用 result 字段
		if (JsonObject->HasField(TEXT("result")))
		{
			TSharedPtr<FJsonObject> ResultObject = JsonObject->GetObjectField(TEXT("result"));
			if (ResultObject.IsValid())
			{
				JsonObject = ResultObject;
			}
		}

		// 解析JSON数据
		JsonObject->TryGetNumberField(TEXT("fps"), FrameRate);
		JsonObject->TryGetNumberField(TEXT("num_people"), num_people);
		JsonObject->TryGetNumberField(TEXT("num_frames"), num_frames);
		JsonObject->TryGetStringField(TEXT("pose"), poseBase64);
		JsonObject->TryGetStringField(TEXT("transl"), translBase64);
		JsonObject->TryGetStringField(TEXT("camera_T"), camera_TBase64);
		JsonObject->TryGetStringField(TEXT("camera_R"), camera_RBase64);
		JsonObject->TryGetStringField(TEXT("audio_wave"), audioBase64);
		JsonObject->TryGetStringField(TEXT("emotion"), emotionBase64);
		JsonObject->TryGetStringField(TEXT("emotion_conf"), emotionConfBase64);
		JsonObject->TryGetStringField(TEXT("valid_mask"), validMaskBase64);

		if (JsonObject->TryGetArrayField(TEXT("foot_offset"), foot_offset) && foot_offset != nullptr)
		{
			if (foot_offset->Num() > 0)
			{
				for (const auto& It : *foot_offset)
				{
					if (It != nullptr)
					{
						float FootOffsetY = 0;
						FootOffsetY = It->AsNumber();
						FootOffsetYArray.Add(FootOffsetY);
					}
					else
					{
						FootOffsetYArray.Add(0);
					}

				}
			}
		}

		UE_LOG(LogAIAnim, Log, TEXT("GetJsonData: fps = %.1f num_people = %d, num_joints = %d, num_frames = %d"),
			FrameRate, num_people, num_joints, num_frames);


		TArray<float> Camera_T = DecodeBase64ToFloatArray(camera_TBase64);
		TArray<float> Camera_R = DecodeBase64ToFloatArray(camera_RBase64);

		TArray<float> PoseData = DecodeBase64ToFloatArray(poseBase64);
		TArray<float> transl = DecodeBase64ToFloatArray(translBase64);

		OutTransl = std::move(transl);
		OutPose = std::move(PoseData);
		OutFrameRate = std::move(FrameRate);
		OutPeople = num_people;
		OutFrameNum = num_frames;
		OutOffsets = FootOffsetYArray;
#endif

		return true;
	}

	static int CompareFloatArray(const TArray<float>& ArrLeft, const TArray<float>& ArrRight)
	{
		if (ArrLeft.Num() != ArrRight.Num())
		{
			return 0;
		}
		int ErrIdx = -1;
		for (int i = 0; i < ArrLeft.Num(); i++)
		{
			if (FMath::Abs(ArrLeft[i] - ArrRight[i]) > UE_KINDA_SMALL_NUMBER)
			{
				ErrIdx = i;
				break;
			}
		}
		return ErrIdx;
	}
}



extern bool PreprocessAIData(TArray<float>& OutTransl, TArray<float>& OutFootOffsets, int num_frames, int num_people, const TArray<float>& PoseData, const TArray<float>& TranslData)
{
	SCOPED_NAMED_EVENT(PreprocessAIData, FColor::Red);

	using namespace transl_filter;

	if (num_frames < 1 || num_people < 1)
	{
		UE_LOG(LogAIAnim, Warning, TEXT("PreprocessAIData, invalid frames=%d or people=%d"), num_frames, num_people);
		return false;
	}

	if (PoseData.Num() < 1 || TranslData.Num() < 1)
	{
		UE_LOG(LogAIAnim, Warning, TEXT("PreprocessAIData, too few PoseData.Num=%d or TranslData.Num=%d"), 
			PoseData.Num(), TranslData.Num());
		return false;
	}

	// 检查数量，是否正确
	auto PoseNum = PoseData.Num();
	if (PoseNum % (num_frames * num_people * NUM_BONES * 3) != 0)
	{
		UE_LOG(LogAIAnim, Warning, TEXT("PreprocessAIData, invalid PoseData.Num=%d"), PoseData.Num());
		return false;
	}
	auto TransNum = TranslData.Num();
	if (TransNum % (num_frames * num_people * 3) != 0)
	{
		UE_LOG(LogAIAnim, Warning, TEXT("PreprocessAIData, invalid TranslData.Num=%d"), TranslData.Num());
		return false;
	}

	array_people_frame_52_t pose;
	array_people_frame_t transl;
	int fps = 30;

	{
		int IdxPose = 0;
		for (int p = 0; p < num_people; p++)
		{
			pose.Add(array_frame_52_t());
			array_frame_52_t& one_person = pose.Last();
			one_person.Reserve(num_frames);

			for (int f = 0; f < num_frames; f++)
			{
				one_person.Add(TArray<FVector>());
				TArray<FVector>& one_frame = one_person.Last();
				one_frame.Reserve(NUM_BONES);

				for (int b = 0; b < NUM_BONES; b++)
				{
					FVector v(PoseData[IdxPose + 0], PoseData[IdxPose + 1], PoseData[IdxPose + 2]);
					IdxPose += 3;
					one_frame.Add(v);
				}
			}
		}
	}

	{
		int IdxTransl = 0;
		for (int p = 0; p < num_people; p++)
		{
			transl.Add(array_frame_t());
			array_frame_t& one_person = transl.Last();
			one_person.Reserve(num_frames);

			for (int f = 0; f < num_frames; f++)
			{
				FVector v(TranslData[IdxTransl + 0], TranslData[IdxTransl + 1], TranslData[IdxTransl + 2]);
				IdxTransl += 3;
				one_person.Add(v);
			}
		}	
	}


	bool b = transl_filter::DoTranslFilter(OutTransl, OutFootOffsets, transl, pose, fps);

	return b;
}
extern void AIAnimCompareData(const FString& OldFile, const FString& NewFile)
{
	// 调试用的
#if !UE_BUILD_SHIPPING
	TArray<float> OutTransl;
	TArray<float> OutPose;
	int OutPeople = 0;
	float OutFrameRate = 0;
	int OutFrameNum = 0;
	TArray<float> OutOffsets;
	transl_filter::GetJsonData(OldFile, OutTransl, OutPose, OutPeople, OutFrameRate, OutFrameNum, OutOffsets);

	TArray<float> OutTranslNew;
	TArray<float> OutPoseNew;
	int OutPeopleNew = 0;
	float OutFrameRateNew = 0;
	int OutFrameNumNew = 0;
	TArray<float> OutOffsetsNew;
	transl_filter::GetJsonData(NewFile, OutTranslNew, OutPoseNew, OutPeopleNew, OutFrameRateNew, OutFrameNumNew, OutOffsetsNew);


	TArray<float> CppTransl;
	TArray<float> CppFootOffsets;
	PreprocessAIData(CppTransl, CppFootOffsets, OutFrameNum, OutPeople, OutPose, OutTransl);

	// 拿到结果后，对比一下，如果数据不对，那么打印两者信息
	{
		if (CppTransl.Num() == OutTranslNew.Num())
		{
			int ErrIdx = transl_filter::CompareFloatArray(CppTransl, OutTranslNew);
			if (ErrIdx == -1)
			{
				UE_LOG(LogAIAnim, Log, TEXT("TranslData Is Same"));
			}
			else
			{
				UE_LOG(LogAIAnim, Warning, TEXT("TranslData Is Not Same. ErrIdx=%d"), ErrIdx);

				// 打印数据
				{
					{
						FString FilePath = FPaths::Combine(transl_filter::GetRootDir(), TEXT("filtered_transl_cpp.txt"));
						auto FileAr = TUniquePtr<FArchive>(IFileManager::Get().CreateDebugFileWriter(*FilePath));
						FOutputDeviceArchiveWrapper OutputLog(FileAr.Get());
						for (const auto& It : CppTransl)
						{
							OutputLog.Logf(TEXT("%.3f"), It);
						}
						OutputLog.Logf(TEXT("\n\n"));
					}

					{
						FString FilePath = FPaths::Combine(transl_filter::GetRootDir(), TEXT("filtered_transl_py.txt"));
						auto FileAr = TUniquePtr<FArchive>(IFileManager::Get().CreateDebugFileWriter(*FilePath));
						FOutputDeviceArchiveWrapper OutputLog(FileAr.Get());
						for (const auto& It : OutTranslNew)
						{
							OutputLog.Logf(TEXT("%.3f"), It);
						}
						OutputLog.Logf(TEXT("\n\n"));
					}
				}
			}
		}
		else
		{
			UE_LOG(LogAIAnim, Warning, TEXT("TranslData Is Not Same. cpp-Transl.Num=%d, Transl.Num=%d"), CppTransl.Num(), OutTranslNew.Num());
		}

		if (CppFootOffsets.Num() == OutOffsetsNew.Num())
		{
			int ErrIdx = transl_filter::CompareFloatArray(CppFootOffsets, OutOffsetsNew);
			if (ErrIdx == -1)
			{
				UE_LOG(LogAIAnim, Log, TEXT("Offsets Is Same"));
			}
			else
			{
				UE_LOG(LogAIAnim, Warning, TEXT("Offsets Is Not Same. ErrIdx=%d"), ErrIdx);

				// 打印数据
				{
					FString FilePath = FPaths::Combine(transl_filter::GetRootDir(), TEXT("offsets_diff.txt"));
					auto FileAr = TUniquePtr<FArchive>(IFileManager::Get().CreateDebugFileWriter(*FilePath));
					FOutputDeviceArchiveWrapper OutputLog(FileAr.Get());
					{
						for (const auto& It : CppFootOffsets)
						{
							OutputLog.Logf(TEXT("%.3f"), It);
						}
						OutputLog.Logf(TEXT("\n\n"));
					}

					{
						for (const auto& It : OutOffsetsNew)
						{
							OutputLog.Logf(TEXT("%.3f"), It);
						}
						OutputLog.Logf(TEXT("\n\n"));
					}
				}
			}
		}
		else
		{
			UE_LOG(LogAIAnim, Warning, TEXT("Offsets Is Not Same. cpp-offset.Num=%d, offsets.Num=%d"), CppFootOffsets.Num(), OutOffsetsNew.Num());
		}
	}
#endif
}
extern void AIAnimSetSmplPoseData(const FString& RawData)
{
	transl_filter::SmplRefPosString = RawData;
}

void FFloatingFootProcessor::ThreadWork(FAIAnimProcessorContext& Context)
{
	TArray<float> OutTransl;
	TArray<float> OutFootOffsets;

	if (PreprocessAIData(OutTransl, OutFootOffsets, Context.num_frames, Context.num_people, Context.PoseData, Context.transl)
		&& Context.transl.Num() == OutTransl.Num())
	{
		for (int i = 0; i < OutFootOffsets.Num(); i++)
		{
			if (OutFootOffsets[i] > 0)
			{
				auto FootOffsetY = OutFootOffsets[i];
				FootOffsetY = (FootOffsetY - 0.93) * 100; // 算法对应的魔数，暂定，后续会调整。
				FootOffsetY = FootOffsetY > 0 ? FMath::CeilToInt(FootOffsetY) : FMath::FloorToInt(FootOffsetY);
				OutFootOffsets[i] = FootOffsetY;

				Context.bFootOffsetY = true;
			}
		}

		Context.transl = OutTransl;
		Context.FootOffsetYArray = OutFootOffsets;

		UE_LOG(LogAIAnim, Log, TEXT("FFloatingFootProcessor Succ"));
	}
	else
	{
		UE_LOG(LogAIAnim, Warning, TEXT("FFloatingFootProcessor Failed"));
	}
}
