#include "Managers/KGDamageProcessManager.h"
#include "3C/Camera/CameraManager.h"
#include "ICppEntity.h"
#include "3C/Util/KGUtils.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Material/KGMaterialManager.h"
#include "Lua/KGLuaEntityBase.h"
#include "TypeDefines/LuaEnums.h"
#include "TypeDefines/Types.h"
#include "3C/Core/C7ActorInterface.h"



// 开发期输出性能桩，发布版本或后期可以禁用掉
#if 1 && !UE_BUILD_SHIPPING
	#define SCOPED_NAMED_EVENT_DAMAGEPROCESS(NAME) SCOPED_NAMED_EVENT(NAME, FColor::Red)
#else
	#define SCOPED_NAMED_EVENT_DAMAGEPROCESS(NAME)
#endif




void FDamageContext::Init(DamageContextNew* InMsgData)
{
	check(InMsgData);
	MsgData = InMsgData;

	// old 
	if (MsgData->BitFlags & int(EDamageFlagType::bHeal))
	{
		Type1 = EDamageType1::Heal;
	}
	else if (MsgData->BitFlags & int(EDamageFlagType::bSteal))
	{
		Type1 = EDamageType1::Steal;	
	}	
	else if (MsgData->BitFlags & int(EDamageFlagType::bActionBlocked))	
	{		
		Type1 = EDamageType1::bActionBlocked;	
	}	
	else if (MsgData->BitFlags & int(EDamageFlagType::bShallowGrave))	
	{		
		Type1 = EDamageType1::ShallowGrave;	
	}	
	else if (MsgData->BitFlags & int(EDamageFlagType::bImmune))	
	{		
		Type1 = EDamageType1::Immune;	
	}
	else if (MsgData->BitFlags & int(EDamageFlagType::bActionHit))	
	{		
	    Type1 = EDamageType1::bActionHit;	
	}

	if (MsgData->BitFlags & int(EDamageFlagType::bActionCrit))	
	{		
		bCritical = true;	
	}	

	if (MsgData->BitFlags & int(EDamageFlagType::bDead))	
	{		
		bDead = true;	
	}	

	switch (MsgData->DamageType)	
	{	
		case 0:
		Type2 = EDamageType2::NoneDamage;
		break;	
		case 1:		
		Type2 = EDamageType2::PhysicalDamage;		
		break;	
		case 2:		
		Type2 = EDamageType2::SpellDamage;		
		break;	
		default:		
			break;	
	}

    DamageWithShield = Type1 != EDamageType1::Heal && MsgData->HpDelta <= 0 ? MsgData->ShieldCost - MsgData->HpDelta : MsgData->DamageValue;
	
	if (MsgData->InstigatorID == 0)	
	{		
		MsgData->InstigatorID = MsgData->AttackerID;	
	}

	// new
	switch (MsgData->DamageType)
	{	
	case 0:
		DamageType = EDamageType::None;
		break;
	case 1:
		DamageType = EDamageType::Physics;
		break;
	case 2:
		DamageType = EDamageType::Magic;
		break;
	default:
		break;
	}
	switch (MsgData->DamageMethod)
	{	
	case 0:
		DamageMethod = EDamageMethod::NormalHit;
		break;
	case 1:
		DamageMethod = EDamageMethod::Blocked;
		break;
	case 2:
		DamageMethod = EDamageMethod::Critical;
		break;
	default:
		break;
	}
}

void UKGDamageProcessManager::NativeInit()
{
	Super::NativeInit();

	FCoreDelegates::OnBeginFrame.AddUObject(this, &UKGDamageProcessManager::OnFrameBegin);

	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_HandleDamageSyncV2", &UKGDamageProcessManager::KAPI_HandleDamageSyncV2);
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_HandleHealSyncV2", &UKGDamageProcessManager::KAPI_HandleHealSyncV2);
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_HandleImmuneSyncV2", &UKGDamageProcessManager::KAPI_HandleImmuneSyncV2);
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_HandleHealLimitSyncV2", &UKGDamageProcessManager::KAPI_HandleHealLimitSyncV2);
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_HandleBeatenSync", &UKGDamageProcessManager::KAPI_HandleBeatenSync);
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_HandleBeatenSyncWithSpecifyHitTrans", &UKGDamageProcessManager::KAPI_HandleBeatenSyncWithSpecifyHitTrans);
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_InitDamageProcessParams", &UKGDamageProcessManager::KAPI_InitDamageProcessParams);
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_InitFullScreenHitBackParams", &UKGDamageProcessManager::KAPI_InitFullScreenHitBackParams);
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_ConvertBattleChannelData", &UKGDamageProcessManager::KAPI_ConvertBattleChannelData);
	REG_MANAGER_FUNC(UKGDamageProcessManager, "KAPI_SetGlobalHitEffectPriority", &UKGDamageProcessManager::KAPI_SetGlobalHitEffectPriority);
}

void UKGDamageProcessManager::NativeUninit()
{
	Super::NativeUninit();

	FCoreDelegates::OnBeginFrame.RemoveAll(this);
}


void UKGDamageProcessManager::OnFrameBegin()
{	
	FrameCounter++;
	OSTime = FPlatformTime::Seconds();

	HitSoundCounter = 0;

	UWorld* World = GetWorld();	
	if (World == nullptr)	
	{		
		return;	
	}	
	
	FrameBeginTime = World->GetTimeSeconds();
	
}

//临时从LUA调入的接口
void UKGDamageProcessManager::KAPI_HandleDamageSyncV2(KGEntityID AttackerID, KGEntityID DefenderID, int AbilityIDWithType, int DamageMethod, int DamageType, int TotalDamage, int ShieldCost, int RealDamage, bool IsDead)
{
	SCOPED_NAMED_EVENT_DAMAGEPROCESS(KAPI_HandleDamageSyncV2);
	DamageContextNew msg;
	msg.AttackerID = AttackerID;
	msg.DefenderID = DefenderID;
	msg.AssetIDWithType = AbilityIDWithType;
	msg.DamageMethod = DamageMethod;
	msg.DamageType = DamageType;
	msg.TotalDamage = TotalDamage;
	msg.ShieldCost = ShieldCost;
	msg.RealDamage = RealDamage;
	msg.IsDead = IsDead;

	HandleDamageSyncV2(&msg);
}

void UKGDamageProcessManager::KAPI_HandleHealSyncV2(KGEntityID AttackerID, KGEntityID DefenderID, int AbilityIDWithType, int TotalHeal, int RealHeal)
{
	SCOPED_NAMED_EVENT_DAMAGEPROCESS(KAPI_HandleHealSyncV2);
	DamageContextNew msg;
	msg.AssetIDWithType = AbilityIDWithType;
	msg.AttackerID = AttackerID;
	msg.DefenderID = DefenderID;
	msg.TotalHeal = TotalHeal;
	msg.RealHeal = RealHeal;

	HandleHealSyncV2(&msg);
}

void UKGDamageProcessManager::KAPI_HandleImmuneSyncV2(KGEntityID AttackerID, KGEntityID DefenderID, int AbilityIDWithType)
{
	SCOPED_NAMED_EVENT_DAMAGEPROCESS(KAPI_HandleImmuneSyncV2);
	DamageContextNew msg;
	msg.AssetIDWithType = AbilityIDWithType;
	msg.AttackerID = AttackerID;
	msg.DefenderID = DefenderID;

	HandleImmuneSyncV2(&msg);
}

void UKGDamageProcessManager::KAPI_HandleHealLimitSyncV2(KGEntityID AttackerID, KGEntityID DefenderID, int AbilityIDWithType)
{
	SCOPED_NAMED_EVENT_DAMAGEPROCESS(KAPI_HandleHealLimitSyncV2);
	DamageContextNew msg;
	msg.AssetIDWithType = AbilityIDWithType;
	msg.AttackerID = AttackerID;
	msg.DefenderID = DefenderID;

	HandleHealLimitSyncV2(&msg);
}



void UKGDamageProcessManager::KAPI_HandleBeatenSyncWithSpecifyHitTrans(
	uint64 HitSrcInsIdWithType,
	int ActionUniqueID,
	KGEntityID InstigatorID,
	KGEntityID AttackerID,
	KGEntityID DefenderID,
	FVector SpecifyHitLocation,
	FVector SpecifyHitNormal
)
{
	SCOPED_NAMED_EVENT_DAMAGEPROCESS(KAPI_HandleBeatenSyncWithSpecifyHitTrans);
	BeatenContext msg;
	msg.HitSrcInsIdWithType = HitSrcInsIdWithType;
	msg.ActionUniqueID = ActionUniqueID;
	msg.InstigatorID = InstigatorID;
	msg.AttackerID = AttackerID;
	msg.DefenderID = DefenderID;
	msg.bNeedSpecifyTrans = true;
	msg.SpecifyTrans.SetLocation(SpecifyHitLocation);
	msg.SpecifyTrans.SetRotation(SpecifyHitNormal.Rotation().Quaternion());

	HandleBeatenSync(&msg);
}


void UKGDamageProcessManager::KAPI_HandleBeatenSync(
	uint64 HitSrcInsIdWithType,
	int ActionUniqueID,
	KGEntityID InstigatorID,
	KGEntityID AttackerID,
	KGEntityID DefenderID
)
{
	SCOPED_NAMED_EVENT_DAMAGEPROCESS(KAPI_HandleBeatenSync);
	BeatenContext msg;
	msg.HitSrcInsIdWithType = HitSrcInsIdWithType;
	msg.ActionUniqueID = ActionUniqueID;
	msg.InstigatorID = InstigatorID;
	msg.AttackerID = AttackerID;
	msg.DefenderID = DefenderID;

	HandleBeatenSync(&msg);
}

void UKGDamageProcessManager::KAPI_InitDamageProcessParams(
	float InWhiteFlashMinInterval, float InWhiteFlashEffectiveTime, FName InWhiteFlashParamName, float InWhiteFlashIntensity, uint8 InWhiteFlashEffectType,
	float InMaxHitEffectPlayTimeMs, int32 InDamageTextMaxDisplayCount)
{
	WhiteFlashMinInterval = InWhiteFlashMinInterval;
	WhiteFlashEffectiveTime = InWhiteFlashEffectiveTime;
	WhiteFlashParamName = InWhiteFlashParamName;
	WhiteFlashIntensity = InWhiteFlashIntensity;
	WhiteFlashEffectType = static_cast<EKGMaterialEffectType>(InWhiteFlashEffectType);
	DamageTextMaxDisplayCount = InDamageTextMaxDisplayCount;

	MaxHitEffectPlayTimeMs = InMaxHitEffectPlayTimeMs;
}

void UKGDamageProcessManager::KAPI_InitFullScreenHitBackParams(FString WidgetPath, float CD, int32 ZOrder, FString AnimationName)
{
	FullScreenHitFeedBackPanelPath = WidgetPath;
	FullScreenHitFeedBackCD = CD;
	FullScreenHitFeedBackWidgetZOrder = ZOrder;
	FullScreenHitFeedBackWidgetAnimationName = AnimationName;
}

TArray<FString> UKGDamageProcessManager::KAPI_ConvertBattleChannelData(const TArray<FBattleChatRawData>& BattleChatRawDataList)
{
	TArray<FString> Result;
	for (const FBattleChatRawData& BattleChatRawData : BattleChatRawDataList)
	{
		FString ConvertedData = ConvertBattleChannelDataInternal(BattleChatRawData);
		if (!ConvertedData.IsEmpty())
		{
			Result.Add(ConvertedData);
		}
	}

	return Result;
}

void UKGDamageProcessManager::KAPI_SetGlobalHitEffectPriority(const int InPriority)
{
	GlobalHitEffectPriority = InPriority;
}

int32 UKGDamageProcessManager::GetDamageTextMaxDisplayCount()
{
	return DamageTextMaxDisplayCount;
}

void UKGDamageProcessManager::HandleDamageSyncV2(DamageContextNew* Context)
{
	//only check if the context is valid at the beginning	
	if (Context == nullptr)	
	{		
		return;	
	}

	bool HasValidManagers = UpAndCheckManagers();
	if (!HasValidManagers)
	{		
		UE_LOG(LogTemp, Warning, TEXT("UKGDamageProcessManager: Managers are not valid."));
		return;	
	}


	// update MainPlayerEntityID
	KGEntityID MainPlayerEntityID = UEActorManagerPtr->GetMainPlayerEntityID();
	if (MainPlayerEntityID == KG_INVALID_ENTITY_ID)
	{
		return; // Main player entity ID is invalid, exit early
	}
	
	FDamageContext DamageContext;	
	DamageContext.Init(Context);	
	DamageContext.MainPlayerEntityID = MainPlayerEntityID;
	DamageContext.ControlledUnitUID = UEActorManagerPtr->GetMainPlayerControlledEntityID();

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayDamageOfChatHUD)
		if (ShouldPlayDamageOfChatHUDV2(DamageContext))
		{
			PlayDamageOfChatHUDV2(DamageContext);
		}
	}


	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayDamageOfHeadInfoHUD)
		if (ShouldPlayDamageOfHeadInfoHUDV2(DamageContext))
		{
			PlayDamageOfHeadInfoHUDV2(DamageContext);
		}
	}

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayDamageOfDungeonReviveSystemV2)
		if (ShouldPlayDamageOfDungeonReviveSystemV2(DamageContext))
		{
			PlayDamageOfDungeonReviveSystemV2(DamageContext);
		}
	}


	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayDamageText)
		if (ShouldPlayDamageTextV2(DamageContext, true, false, false))
		{
			PlayDamageTextV2(DamageContext);
		}
	}

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayContinueDamage)
		if (ShouldPlayContinueDamageV2(DamageContext, false))
		{
			PlayContinueDamageV2(DamageContext, false);
		}
	}

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayFullScreenFeedBack)
		if (ShouldPlayFullScreenFeedBackV2(DamageContext))
		{
			PlayFullScreenFeedBack();
		}
	}
}

void UKGDamageProcessManager::HandleHealSyncV2(DamageContextNew* Context)
{
	//only check if the context is valid at the beginning	
	if (Context == nullptr)	
	{		
		return;	
	}

	bool HasValidManagers = UpAndCheckManagers();
	if (!HasValidManagers)
	{		
		UE_LOG(LogTemp, Warning, TEXT("UKGDamageProcessManager: Managers are not valid."));
		return;	
	}


	// update MainPlayerEntityID
	KGEntityID MainPlayerEntityID = UEActorManagerPtr->GetMainPlayerEntityID();
	if (MainPlayerEntityID == KG_INVALID_ENTITY_ID)
	{
		return; // Main player entity ID is invalid, exit early
	}
	
	FDamageContext DamageContext;	
	DamageContext.Init(Context);	
	DamageContext.MainPlayerEntityID = MainPlayerEntityID;
	DamageContext.ControlledUnitUID = UEActorManagerPtr->GetMainPlayerControlledEntityID();

	{
		if (DamageContext.MsgData->AttackerID == DamageContext.MainPlayerEntityID)
		{
			if (DataCacheManagerPtr->IsTeamMemberByID(DamageContext.MsgData->DefenderID))
			{
				SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayHealOfTeamHUD)
				PlayDamageOfTeamHUDV2(DamageContext);
			}

			if (DataCacheManagerPtr->IsGroupmemberByID(DamageContext.MsgData->DefenderID))
			{
				SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayHealOfGroupHUD)
				PlayDamageOfGroupHUDV2(DamageContext);
			}
		}
	}

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayHealOfChatHUD)
		if (ShouldPlayDamageOfChatHUDV2(DamageContext))
		{
			PlayHealOfChatHUDV2(DamageContext);
		}
	}

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayHealText)
		if (ShouldPlayDamageTextV2(DamageContext, false, true, false))
		{
			PlayHealTextV2(DamageContext);
		}
	}

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayContinueDamage)
		if (ShouldPlayContinueDamageV2(DamageContext, true))
		{
			PlayContinueDamageV2(DamageContext, true);
		}
	}
}

void UKGDamageProcessManager::HandleImmuneSyncV2(DamageContextNew* Context)
{
	//only check if the context is valid at the beginning	
	if (Context == nullptr)	
	{		
		return;	
	}

	bool HasValidManagers = UpAndCheckManagers();
	if (!HasValidManagers)
	{		
		UE_LOG(LogTemp, Warning, TEXT("UKGDamageProcessManager: Managers are not valid."));
		return;	
	}


	// update MainPlayerEntityID
	KGEntityID MainPlayerEntityID = UEActorManagerPtr->GetMainPlayerEntityID();
	if (MainPlayerEntityID == KG_INVALID_ENTITY_ID)
	{
		return; // Main player entity ID is invalid, exit early
	}
	
	FDamageContext DamageContext;	
	DamageContext.Init(Context);	
	DamageContext.MainPlayerEntityID = MainPlayerEntityID;
	DamageContext.ControlledUnitUID = UEActorManagerPtr->GetMainPlayerControlledEntityID();

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayDamageText)
		if (ShouldPlayDamageTextV2(DamageContext, false, false, true))
		{
			PlayImmuneTextV2(DamageContext);
		}
	}
}

void UKGDamageProcessManager::HandleHealLimitSyncV2(DamageContextNew* Context)
{
	//only check if the context is valid at the beginning	
	if (Context == nullptr)	
	{		
		return;	
	}

	bool HasValidManagers = UpAndCheckManagers();
	if (!HasValidManagers)
	{		
		UE_LOG(LogTemp, Warning, TEXT("UKGDamageProcessManager: Managers are not valid."));
		return;	
	}


	// update MainPlayerEntityID
	KGEntityID MainPlayerEntityID = UEActorManagerPtr->GetMainPlayerEntityID();
	if (MainPlayerEntityID == KG_INVALID_ENTITY_ID)
	{
		return; // Main player entity ID is invalid, exit early
	}
	
	FDamageContext DamageContext;	
	DamageContext.Init(Context);	
	DamageContext.MainPlayerEntityID = MainPlayerEntityID;

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayHealLimitOfChatHUD)
		if (ShouldPlayDamageOfChatHUDV2(DamageContext))
		{
			PlayHealLimitOfChatHUDV2(DamageContext);
		}
	}

	// 跳字增加禁疗
	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayHealLimitText)
		if (ShouldPlayDamageTextV2(DamageContext, false, false, false))
		{
			PlayHealLimitTextV2(DamageContext);
		}
	}
}

void UKGDamageProcessManager::HandleBeatenSync(BeatenContext* Context)
{
	if (Context == nullptr)
	{
		return;
	}

	bool R = UpAndCheckManagers();
	if (R == false)
	{
		return;
	}


	int Type = Context->HitSrcInsIdWithType % 10;
	uint32 AssetID = Context->HitSrcInsIdWithType / 10;

	if (Type < 0 || Type >= static_cast<int>(EDoFightActionSourceType::Max))
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGDamageProcessManager::HandleBeatenSync: Invalid Type %d id %d"), Type, AssetID);
		return;
	}


	FDamageVFXContext DamageVFXContext;
	DamageVFXContext.MsgData = Context;
	DamageVFXContext.SourceType = static_cast<EDoFightActionSourceType>(Type);
	DamageVFXContext.AssetID = AssetID;

	if (Context->InstigatorID == 0)
	{
		Context->InstigatorID = Context->AttackerID;
	}


	if (DamageVFXContext.SourceType == EDoFightActionSourceType::Skill)
	{
		if (FSkillData* SkillData = DataCacheManagerPtr->GetSkillData(DamageVFXContext.AssetID))
		{
			DamageVFXContext.VFXData = &SkillData->VFXData;
		}
	}
	else if (DamageVFXContext.SourceType == EDoFightActionSourceType::SpellField)
	{
		if (FSpellFieldData* Data = DataCacheManagerPtr->GetSpellFieldData(DamageVFXContext.AssetID))
		{
			DamageVFXContext.VFXData = &(Data->VFXData);
		}
	}
	else if (DamageVFXContext.SourceType == EDoFightActionSourceType::Bullet)
	{
		if (FBulletData* BulletData = DataCacheManagerPtr->GetBulletData(DamageVFXContext.AssetID))
		{
			DamageVFXContext.VFXData = &(BulletData->VFXData);
		}
	}
	else
	{
		return;
	}

	if (DamageVFXContext.VFXData == nullptr)
	{
		return;
	}

	KGEntityID MainPlayerEntityID = UEActorManagerPtr->GetMainPlayerEntityID();
	if(MainPlayerEntityID == KG_INVALID_ENTITY_ID)
	{
		return;
	}
	DamageVFXContext.MainPlayerEntityID = MainPlayerEntityID;
	DamageVFXContext.ControlledUnitUID = UEActorManagerPtr->GetMainPlayerControlledEntityID();
	
	DamageVFXContext.DefenderEntity = UEActorManagerPtr->GetLuaEntity(DamageVFXContext.MsgData->DefenderID);
	if (DamageVFXContext.DefenderEntity == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGDamageProcessManager::HandleBeatenSync: DefenderEntity is null for DefenderID: %lld"), DamageVFXContext.MsgData->DefenderID);
		return;
	}
	
	DamageVFXContext.InstigatorEntity = UEActorManagerPtr->GetLuaEntity(DamageVFXContext.MsgData->InstigatorID);
	if (DamageVFXContext.InstigatorEntity == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGDamageProcessManager::HandleBeatenSync: InstigatorEntity is null for InstigatorID: %lld"), DamageVFXContext.MsgData->InstigatorID);
		return;
	}


	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayHitEffect)
		if (ShouldPlayHitEffect(DamageVFXContext))
		{
			PlayHitEffect(DamageVFXContext);
		}
	}


	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayHitSound)
		if (ShouldPlayHitSound(DamageVFXContext))
		{
			PlayHitSound(DamageVFXContext);
		}
	}

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayCameraShake)
		if (ShouldPlayCameraShake(DamageVFXContext))
		{
			PlayCameraShake(DamageVFXContext);
		}
	}

	{
		SCOPED_NAMED_EVENT_DAMAGEPROCESS(PlayFlashEffect)
		if (ShouldPlayFlashEffect(DamageVFXContext))
		{
			PlayFlashEffect(DamageVFXContext);
		}
	}

}

void UKGDamageProcessManager::HandleSetInBattle(KGEntityID eID, bool bInBattle, bool bInBattleOld)
{
	if (bInBattle != bInBattleOld)
	{
		ContinuousDamageCounter = 0.0f;
		ContinuousHealCounter = 0.0f;
	}
}

//bool UKGDamageProcessManager::ShouldPlayElementEffect(FDamageContext& InContext)
//{	
//	check(InContext.MsgData);	
//	if (InContext.MsgData->EleEffectId <= 0)	
//	{		
//		return false;	
//	}	
//	
//	return true;
//}
//
//void UKGDamageProcessManager::PlayElementEffect(FDamageContext& InContext)
//{	
//	check(InContext.MsgData);	
//	check(DataCacheManagerPtr.IsValid());	
//	FElementEffectsData* ElementEffectData = DataCacheManagerPtr->GetElementEffectsData(InContext.MsgData->EleEffectId);	
//	if (ElementEffectData == nullptr)	
//	{		
//		UE_LOG(LogTemp, Warning, TEXT("ElementEffectData is null for ID: %d"), InContext.MsgData->EleEffectId);		
//		return;
//	}	
//	
//	if (ElementEffectData->ElementTypeID <= 0)	
//	{		
//		UE_LOG(LogTemp, Warning, TEXT("ElementTypeID is invalid for ID: %d"), InContext.MsgData->EleEffectId);		
//		return;	
//	}	
//	
//	int ToUseEffectId = InContext.bCritical ? ElementEffectData->CriticalEffectId : ElementEffectData->NoCriticalEffectId;	
//	if (ToUseEffectId <= 0)	
//	{		
//		UE_LOG(LogTemp, Warning, TEXT("ToUseEffectId is invalid for ID: %d"), InContext.MsgData->EleEffectId);		
//		return;	
//	}	
//	
//	FElementSingleEffectData* ElementSingleEffectData = DataCacheManagerPtr->GetElementSingleEffectsData(ToUseEffectId);	
//	if (ElementSingleEffectData == nullptr)	
//	{		
//		UE_LOG(LogTemp, Warning, TEXT("ElementSingleEffectData is null for ID: %d"), ToUseEffectId);		
//		return;	
//	}	
//	
//	bool bByself = InContext.MsgData->InstigatorID == InContext.MsgData->DefenderID;	
//	FString& NiagraAssetPath = bByself ? ElementSingleEffectData->SelfElementNiagara : ElementSingleEffectData->TargetElementNiagara;	
//	if (NiagraAssetPath.IsEmpty())	
//	{		
//		UE_LOG(LogTemp, Warning, TEXT("NiagraAssetPath is empty for ID: %d"), ToUseEffectId);		
//		return;	
//	}	
//	
//	AActor* DefenderActor = UEActorManagerPtr->GetActorByEntityID(InContext.MsgData->DefenderID);
//	ACharacter* DefenderCharacter = Cast<ACharacter>(DefenderActor);	
//	
//	if (DefenderCharacter == nullptr)	
//	{		
//		UE_LOG(LogTemp, Warning, TEXT("DefenderActor is not a valid ACharacter for DefenderID: %lld"), InContext.MsgData->DefenderID);	
//		return;	
//	}	
//	
//	USkeletalMeshComponent* MeshComp = DefenderCharacter->GetMesh();	
//	if (MeshComp == nullptr)	
//	{		
//		UE_LOG(LogTemp, Warning, TEXT("MeshComp is null for DefenderID: %lld"), InContext.MsgData->DefenderID);		
//		return;	
//	}	
//	
//	FString SocketName(TEXT("pelvis_Slot"));	
//	PlayNiagara(NiagraAssetPath, InContext.MsgData->DefenderID, SocketName);
//}

KGEntityID UKGDamageProcessManager::GetMainPlayerEntityID()
{
	if (UEActorManagerPtr.IsValid())
	{
		return UEActorManagerPtr->GetMainPlayerEntityID();
	}
	return KG_INVALID_ENTITY_ID;
}

bool UKGDamageProcessManager::UpAndCheckManagers()
{
	if (!DataCacheManagerPtr.IsValid())
	{
		DataCacheManagerPtr = UKGDataCacheManager::GetInstance(this);
		if (!DataCacheManagerPtr.IsValid())
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGDataCacheManager is not valid in UKGDamageProcessManager"));
			return false;
		}
	}
	if (!EffectManagerPtr.IsValid())
	{
		EffectManagerPtr = UKGEffectManager::GetInstance(this);
		if (!EffectManagerPtr.IsValid())
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGEffectManager is not valid in UKGDamageProcessManager"));
			return false;
		}
	}
	if (!MaterialManagerPtr.IsValid())
	{
		MaterialManagerPtr = UKGMaterialManager::GetInstance(this);
		if (!MaterialManagerPtr.IsValid())
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGMaterialManager is not valid in UKGDamageProcessManager"));
			return false;
		}
	}
	if (!UEActorManagerPtr.IsValid())
	{
		UEActorManagerPtr = UKGUEActorManager::GetInstance(this);
		if (!UEActorManagerPtr.IsValid())
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGUEActorManager is not valid in UKGDamageProcessManager"));
			return false;
		}
	}
	if (!HUDManagerPtr.IsValid())
	{
		HUDManagerPtr = UHUDManager::GetInstance(this);
		if (!HUDManagerPtr.IsValid())
		{
			UE_LOG(LogTemp, Warning, TEXT("UHUDManager is not valid in UKGDamageProcessManager"));
			return false;
		}
	}

	if (!AudioManagerPtr.IsValid())
	{
		AudioManagerPtr = UKGAkAudioManager::GetInstance(this);
		if (!AudioManagerPtr.IsValid())
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGAkAudioManager is not valid in UKGDamageProcessManager"));
			return false;
		}
	}
	if (!AssetManagerPtr.IsValid())
	{
		AssetManagerPtr = UKGCppAssetManager::GetInstance(this);
		if (!AssetManagerPtr.IsValid())
		{
			UE_LOG(LogTemp, Warning, TEXT("UKGCppAssetManager is not valid in UKGDamageProcessManager"));
			return false;
		}
	}
	
	return true;
}

bool UKGDamageProcessManager::ShouldPlayDamageOfBossHead(FDamageContext& InContext)
{	
	if (InContext.Type1 == EDamageType1::Immune)
	{
		return false; // 不播放免疫效果的头部特效
	}

	return false;
}

void UKGDamageProcessManager::PlayBossHeadEffect(FDamageContext& InContext)
{

}

void UKGDamageProcessManager::PlayDamageOfTeamHUDV2(FDamageContext& InContext)
{	
	check(HUDManagerPtr.IsValid());
	HUDManagerPtr->PlayDamageEffectOfTeamHUD(InContext.MsgData->DefenderID);
}


void UKGDamageProcessManager::PlayDamageOfGroupHUDV2(FDamageContext& InContext)
{	
	check(HUDManagerPtr.IsValid());
	HUDManagerPtr->PlayDamageEffectOfGroupHUD(InContext.MsgData->DefenderID);
}


bool UKGDamageProcessManager::ShouldPlayDamageOfChatHUDV2(FDamageContext& InContext)
{
	check(DataCacheManagerPtr.IsValid());
	check(InContext.MsgData);

	if (InContext.MsgData->AttackerID == InContext.MainPlayerEntityID || InContext.MsgData->DefenderID == InContext.MainPlayerEntityID)
	{
		return true;
	}

	ICppEntityInterface* InstigatorEntity = UEActorManagerPtr->GetLuaEntity(InContext.MsgData->AttackerID);
	if (InstigatorEntity == nullptr)
	{
		return false; // 没有找到对应的实体
	}
	const FCppEntityData& InstigatorEntityData = InstigatorEntity->GetEntityData();
	if (InstigatorEntityData.BossType == EBossType::Create)
	{
		return true;
	}
	if (InstigatorEntityData.FinalOwnerID != InContext.MsgData->AttackerID)
	{
		// 有的召唤物比如占卜家的技能，BossType 似乎不会设置，默认为 NoMonster
		return true;
	}
	
	ICppEntityInterface* DefenderEntity = UEActorManagerPtr->GetLuaEntity(InContext.MsgData->DefenderID);
	if (DefenderEntity == nullptr)
	{
		return false; // 没有找到对应的实体
	}
	const FCppEntityData& DefenderEntityData = DefenderEntity->GetEntityData();
	if (DefenderEntityData.BossType == EBossType::Create)
	{
		return true;
	}

	return false;
}

void UKGDamageProcessManager::PlayDamageOfChatHUDV2(FDamageContext& InContext)
{
	check(HUDManagerPtr.IsValid());
	check(InContext.MsgData);

	CallLuaFunction("KCB_AddNewBattleChannelData",
		EDamageProcessType::Damage,
		InContext.MsgData->AttackerID,
		InContext.MsgData->DefenderID,
		InContext.MainPlayerEntityID,
		InContext.MsgData->AssetIDWithType,
		InContext.MsgData->TotalDamage,
		InContext.MsgData->RealDamage,
		InContext.DamageType,
		InContext.DamageMethod,
		InContext.MsgData->ShieldCost
	);
}

void UKGDamageProcessManager::PlayHealOfChatHUDV2(FDamageContext& InContext)
{
	check(HUDManagerPtr.IsValid());
	check(InContext.MsgData);

	CallLuaFunction("KCB_AddNewBattleChannelData",
		EDamageProcessType::Heal,
		InContext.MsgData->AttackerID,
		InContext.MsgData->DefenderID,
		InContext.MainPlayerEntityID,
		InContext.MsgData->AssetIDWithType,
		InContext.MsgData->TotalHeal,
		InContext.MsgData->RealHeal,
		EDamageType::None,
		EDamageMethod::NormalHit,
		0
	);
}

void UKGDamageProcessManager::PlayHealLimitOfChatHUDV2(FDamageContext& InContext)
{
	check(HUDManagerPtr.IsValid());
	check(InContext.MsgData);

	CallLuaFunction("KCB_AddNewBattleChannelData",
		EDamageProcessType::HealLimit,
		InContext.MsgData->AttackerID,
		InContext.MsgData->DefenderID,
		InContext.MainPlayerEntityID,
		InContext.MsgData->AssetIDWithType,
		0,
		0,
		EDamageType::None,
		EDamageMethod::NormalHit,
		0
	);
}

bool UKGDamageProcessManager::ShouldPlayDamageOfHeadInfoHUDV2(FDamageContext& InContext)
{
	check(DataCacheManagerPtr.IsValid());
	check(InContext.MsgData);

	if (DataCacheManagerPtr->HasHeadInfoByID(InContext.MsgData->DefenderID) == false)
	{
		return false; // 没有头部信息，不播放效果
	}

	if (InContext.MsgData->AttackerID != InContext.MainPlayerEntityID)
	{
		return false; // 不是主玩家发起的伤害，不播放效果
	}

	return true;
}

void UKGDamageProcessManager::PlayDamageOfHeadInfoHUDV2(FDamageContext& InContext)
{
	check(HUDManagerPtr.IsValid());
	//TODO ref:function function HeadInfoFlag_OnTakeDamage:OnTakeDamage(damageCtx)
	// HUDManagerPtr->PlayDamageEffectOfHeadInfoHUD(
	// 	InContext.MsgData->AttackerID,
	// 	InContext.MsgData->DefenderID,
	// 	InContext.Type1,
	// 	InContext.Type2
	// );
}

bool UKGDamageProcessManager::ShouldPlayDamageOfDungeonReviveSystemV2(FDamageContext& InContext)
{
	check(DataCacheManagerPtr.IsValid());
	check(InContext.MsgData);

	if (InContext.MsgData->AttackerID != InContext.MainPlayerEntityID)
	{
		return false; // 不是主玩家发起的伤害，不播放效果
	}

	if (InContext.MsgData->DefenderID != InContext.MainPlayerEntityID)
	{
		return false; // 不是主玩家受到的伤害，不播放效果
	}
	return true;
}

void UKGDamageProcessManager::PlayDamageOfDungeonReviveSystemV2(FDamageContext& InContext)
{
	check(HUDManagerPtr.IsValid());
	HUDManagerPtr->PlayDamageEffectOfDungeonReviveSystem();
}

bool UKGDamageProcessManager::ShouldPlayDamageTextV2(FDamageContext& InContext, bool bDamage, bool bHeal, bool bImmune)
{
	check(DataCacheManagerPtr.IsValid());
	check(UEActorManagerPtr.IsValid());
	check(InContext.MsgData);
    
	if (!IsRelatedToPlayer(InContext))
	{
		return false;
	}

	ICppEntityInterface* Entity = UEActorManagerPtr->GetLuaEntity(InContext.MsgData->DefenderID);
	if (Entity == nullptr)
	{
		return false; // 没有找到对应的实体
	}

	float ThresholdChecking = 0.2f;
	if (auto* ConsoleObj = IConsoleManager::Get().FindConsoleVariable(TEXT("KG.DamageText.CheckActorRenderedThreshold")))
	{
		ConsoleObj->GetValue(ThresholdChecking);
	}

	// 拿不到ActorID，表明Entity还没有创建完成（对应lua侧Entity的bInWorld为false），这个时候不处理伤害相关逻辑
	KGActorID ActorID = UEActorManagerPtr->GetActorIDByEntityID(InContext.MsgData->DefenderID);
	if (ActorID == KG_INVALID_ACTOR_ID)
	{
		return false;
	}
    
	AActor* Actor = UEActorManagerPtr->GetActorByEntityID(InContext.MsgData->DefenderID);
	if (Actor && !Actor->WasRecentlyRendered(ThresholdChecking))
	{
		return false;
	}

	//中立或敌对的不可见对象不需要飘字
	FCppEntityData& EntityData = Entity->GetEntityData();
	if (EntityData.bVisible == false)
	{
		if (EntityData.CampType == ECampType::Enemy || EntityData.CampType == ECampType::Neutral)
		{
			return false;
		}	
	}

	//免疫处理
	if(bImmune)
	{
		FImmuneRecordKey Key(InContext.MsgData->AttackerID, InContext.MsgData->AssetIDWithType);
		float* LastImmuneTime = ImmuneRecords.Find(Key);
		if (LastImmuneTime == nullptr)
		{
			// 没有记录，添加新的记录
			ImmuneRecords.Add(Key, OSTime);
		}
		else
		{
			float deltaTime = OSTime - *LastImmuneTime;
			if (deltaTime < ImmuneRecordTime)
			{
				return false; // 在免疫记录时间内，不播放飘字
			}
		    
			// 更新记录时间
			*LastImmuneTime = OSTime;
		}
		return true;
	}
	else if (bHeal)
	{
		if(FMath::Abs(InContext.MsgData->TotalHeal) < 0.01)
		{
			return false;
		}
	}
	else if(bDamage)
	{
		if (FMath::Abs(InContext.MsgData->TotalDamage) < 0.01)
		{
			return false;
		}
	}

	return true;
}

void UKGDamageProcessManager::PlayDamageTextV2(FDamageContext& InContext) const
{
	SCOPED_NAMED_EVENT(PlayDamageTextV2, FColor::Silver);
	check(HUDManagerPtr.IsValid());
	check(InContext.MsgData);

	HUDManagerPtr->PlayDamageTextV2(InContext.MsgData->DefenderID, InContext.DamageType,
		InContext.DamageMethod, InContext.MsgData->TotalDamage, InContext.MsgData->RealDamage,
		InContext.MsgData->ShieldCost, InContext.MainPlayerEntityID);
}

void UKGDamageProcessManager::PlayHealTextV2(FDamageContext& InContext) const
{
	SCOPED_NAMED_EVENT(PlayHealTextV2, FColor::Silver);
	check(HUDManagerPtr.IsValid());
	check(InContext.MsgData);

	HUDManagerPtr->PlayHealTextV2(InContext.MsgData->DefenderID, InContext.MsgData->TotalHeal,InContext.MainPlayerEntityID);
}

void UKGDamageProcessManager::PlayImmuneTextV2(FDamageContext& InContext) const
{
	SCOPED_NAMED_EVENT(PlayImmuneTextV2, FColor::Silver);
	check(HUDManagerPtr.IsValid());
	check(InContext.MsgData);

	HUDManagerPtr->PlayImmuneTextV2(InContext.MsgData->DefenderID, InContext.MainPlayerEntityID);
}

void UKGDamageProcessManager::PlayHealLimitTextV2(FDamageContext& InContext) const
{
	SCOPED_NAMED_EVENT(PlayHealLimitTextV2, FColor::Silver);
	check(HUDManagerPtr.IsValid());
	check(InContext.MsgData);

	HUDManagerPtr->PlayHealLimitTextV2(InContext.MsgData->DefenderID, InContext.MainPlayerEntityID);
}

bool UKGDamageProcessManager::ShouldPlayContinueDamageV2(FDamageContext& InContext, bool bHeal)
{
	check(InContext.MsgData);
	if (InContext.MsgData->AttackerID != InContext.MainPlayerEntityID)
	{
		return false; // 不是主玩家发起的伤害，不播放效果
	}

	//这个逻辑有点诡异
	if(!bHeal && InContext.MsgData->DefenderID == InContext.MainPlayerEntityID)
	{
		return false;
	}
	
	return true;
}

void UKGDamageProcessManager::PlayContinueDamageV2(FDamageContext& InContext, bool bHeal)
{
	check(InContext.MsgData);
	check(HUDManagerPtr.IsValid());

	int32 TotalValue = 0;
	if (bHeal)
	{
		ContinuousHealCounter += FMath::Abs(InContext.MsgData->HpDelta);
		TotalValue = ContinuousHealCounter;
	}
	else
	{
		ContinuousDamageCounter += FMath::Abs(InContext.DamageWithShield);
		TotalValue = ContinuousDamageCounter;
	}

	//TODO: Implement logic to play continue damage effect ON HUD
	// HUDManagerPtr->PlayContinueDamage(InContext.MsgData->DefenderID, InContext.Type1, TotalValue);
}

bool UKGDamageProcessManager::ShouldPlayHitEffect(FDamageVFXContext& InContext)
{
	if (InContext.VFXData == nullptr)
	{
		return false;
	}

	if (InContext.VFXData->HitEffectPath.IsEmpty())
	{
		return false;
	}

	check(InContext.DefenderEntity);
	if (!InContext.DefenderEntity->GetLuaEntityBase()->GetActor())
	{
		return false;
	}
	
	return true;
}

void UKGDamageProcessManager::PlayHitEffect(FDamageVFXContext& InContext)
{
	check(EffectManagerPtr.IsValid());
	
	// 特效优先级裁剪策划出了新的方案, 这里暂时先不处理, 后续补充
	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = InContext.VFXData->HitEffectPath;
	PlayNiagaraParams.EffectTags.Add(EKGNiagaraEffectTag::BATTLE);
	PlayNiagaraParams.SpawnerID = InContext.DefenderEntity->GetLuaEntityBase()->GetActorID(); 
	PlayNiagaraParams.SpawnerEntityID = InContext.MsgData->DefenderID;
	PlayNiagaraParams.InstigatorEntityID = InContext.MsgData->InstigatorID;
	PlayNiagaraParams.TotalLifeMs = MaxHitEffectPlayTimeMs;
	PlayNiagaraParams.bFollowSlomo = true;
	PlayNiagaraParams.EffectPlayRate = InContext.VFXData->HitFxPlayRate;
	PlayNiagaraParams.NiagaraBusinessPriority = GlobalHitEffectPriority;
	if (InContext.VFXData->LocationMode == EHitEffectPlayLocationMode::HitLocation)
	{
		TryUpdateEffectTransform(InContext);
		FKGUnattachedNiagaraSpawnInfo SpawnInfo;
		FTransform EffectTransform = InContext.EffectTransform.GetValue();
		/*EffectTransform.SetLocation(EffectTransform.GetLocation() + InContext.VFXData->HitEffectOffset);
		EffectTransform.SetScale3D(InContext.VFXData->HitEffectScale);*/
		SpawnInfo.WorldOrRelativeTrans = EffectTransform;
		PlayNiagaraParams.SetUnattachedSpawnInfo(SpawnInfo);
	}
	else
	{
		FKGAttachedNiagaraSpawnInfo SpawnInfo;
		SpawnInfo.bAbsoluteRotation = true;
		SpawnInfo.bAbsoluteScale = true;

		FTransform EffectTransform = FTransform::Identity;
		EffectTransform.SetLocation(InContext.VFXData->HitEffectOffset);
		EffectTransform.SetScale3D(InContext.VFXData->HitEffectScale);
		SpawnInfo.RelativeTrans = EffectTransform;

		PlayNiagaraParams.SetAttachedSpawnInfo(SpawnInfo);
	}

	EffectManagerPtr->CreateNiagaraSystem(PlayNiagaraParams);
}

bool UKGDamageProcessManager::ShouldPlayHitSound(FDamageVFXContext& InContext)
{
	check(InContext.MsgData);
	check(AudioManagerPtr.IsValid());
	check(UEActorManagerPtr.IsValid());
	check(HUDManagerPtr.IsValid());
	check(DataCacheManagerPtr.IsValid());

	if (HitSoundCounter > 5)
	{
		return false;
	}

	if (InContext.VFXData == nullptr)
	{
		return false;
	}

	if (InContext.VFXData->HitSoundPath.IsEmpty())
	{
		return false;
	}

	if (InContext.MsgData->InstigatorID == InContext.MainPlayerEntityID 
		|| InContext.MsgData->InstigatorID == InContext.ControlledUnitUID)
	{
		return true; // 主玩家发起的攻击
	}
	
	if (InContext.DefenderEntity == nullptr)
	{
		return false;
	}

	// 检查是否是BOSS
	if (InContext.InstigatorEntity == nullptr)
	{
		return false; // 没有找到对应的实体
	}
	FCppEntityData& EntityData = InContext.InstigatorEntity->GetEntityData();
	if (EntityData.BossType == EBossType::BOSS)
	{
		return true; // BOSS发起的攻击
	}

	//检查是否是锁定对象
	KGEntityID LockedEntityID = HUDManagerPtr->GetLockTargetEntityID();
	if (LockedEntityID == InContext.MsgData->InstigatorID)
	{
		return true;
	}
	
	//如果都不是上述情况，就统一接受数量控制
	int CurrentNum = AudioManagerPtr->GetBattleEventNum();
	if (CurrentNum >= AudioManagerPtr->GetBattleEventLimit())
	{
		return false;
	}

	return true;
}

void UKGDamageProcessManager::PlayHitSound(FDamageVFXContext& InContext)
{
	HitSoundCounter++;

	// 1, 尝试更新播放位置
	TryUpdateEffectTransform(InContext);
	
	// 2. 得到真正的 EventName
	// 是否来自P1
	bool bFromLocal = InContext.MsgData->InstigatorID == InContext.MainPlayerEntityID || InContext.MsgData->InstigatorID == InContext.ControlledUnitUID;
	// 是否打向P1
	bool bHitLocal = InContext.MsgData->DefenderID == InContext.MainPlayerEntityID || InContext.MsgData->DefenderID == InContext.ControlledUnitUID;
	
	// 3. 播放音效
	FVector Location = InContext.EffectTransform.GetValue().GetLocation();
	AudioManagerPtr->InnerPostEventForSkill(InContext.VFXData->HitSoundPath, 0, bFromLocal, bHitLocal, true, false, Location.X, Location.Y, Location.Z, true, false, true, false);
}

bool UKGDamageProcessManager::ShouldPlayCameraShake(FDamageVFXContext& InContext)
{
	check(InContext.MsgData);
	check(AssetManagerPtr.IsValid());

	if (InContext.VFXData == nullptr)
	{
		return false;
	}

	if (InContext.VFXData->OnHitShake.IsEmpty())
	{
		return false;
	}

	ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0));
	if (!CameraManager)
	{
		return false;
	}

	if (InContext.MsgData->InstigatorID == InContext.MainPlayerEntityID 
		|| InContext.MsgData->DefenderID == InContext.MainPlayerEntityID
		|| InContext.MsgData->InstigatorID == InContext.ControlledUnitUID 
		|| InContext.MsgData->DefenderID == InContext.ControlledUnitUID)
	{
		return true;
	}

	return false;
}

void UKGDamageProcessManager::PlayCameraShake(FDamageVFXContext& InContext)
{
	AssetManagerPtr->AsyncLoadAsset(InContext.VFXData->OnHitShake, FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGDamageProcessManager::OnCameraShakeAssetLoaded, InContext.VFXData->OnHitShake));
}

void UKGDamageProcessManager::OnCameraShakeAssetLoaded(int InLoadID, UObject* LoadedCameraShakeAsset, FString AssetPath)
{
	UClass* ShakeClass = Cast<UClass>(LoadedCameraShakeAsset);
	if (!ShakeClass)
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDamageProcessManager::OnCameraShakeAssetLoaded, invalid loaded asset %s"), *AssetPath);
		return;
	}

	ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0));
	if (!CameraManager) return;

	CameraManager->StartCameraShakeWithDuration(ShakeClass, DataCacheManagerPtr->GetCameraShakeScale());
}

bool UKGDamageProcessManager::ShouldPlayFlashEffect(FDamageVFXContext& InContext)
{
	if (!InContext.VFXData)
	{
		return false;
	}
	
	if (!InContext.VFXData->bFlashWhite)
	{
		return false;
	}

	if (InContext.MsgData->InstigatorID != InContext.MainPlayerEntityID 
		&& InContext.MsgData->DefenderID != InContext.MainPlayerEntityID
		&& InContext.MsgData->InstigatorID != InContext.ControlledUnitUID 
		&& InContext.MsgData->DefenderID != InContext.ControlledUnitUID)
	{
		return false;
	}
	
	if(InContext.DefenderEntity)
	{
		const double CurrentTimeSeconds = FPlatformTime::Seconds();
		auto& EntityData = InContext.DefenderEntity->GetEntityData();
		return EntityData.NextValidWhiteFlashTimestampSeconds <= CurrentTimeSeconds;
	}

	return false;
}

void UKGDamageProcessManager::PlayFlashEffect(FDamageVFXContext& InContext)
{
	check(MaterialManagerPtr.IsValid());
	AActor* Actor = InContext.DefenderEntity->GetLuaEntityBase()->GetActor();
	if (!Actor)
	{
		return;
	}
	
	const double CurrentTimeSeconds = FPlatformTime::Seconds();
	auto& EntityData = InContext.DefenderEntity->GetEntityData();
	EntityData.NextValidWhiteFlashTimestampSeconds = CurrentTimeSeconds + WhiteFlashMinInterval;
	
	const auto TaskID = MaterialManagerPtr->AddTransientUpdateTask(
		Actor, WhiteFlashEffectiveTime, WhiteFlashEffectType != EKGMaterialEffectType::None, WhiteFlashEffectType);
	MaterialManagerPtr->SetScalarParameterByTransientTaskId(TaskID, WhiteFlashParamName, WhiteFlashIntensity);
}

bool UKGDamageProcessManager::ShouldPlayFullScreenFeedBackV2(FDamageContext& InContext)
{
	// 不是受击伤害，无需播放
	if (InContext.MsgData->DefenderID != InContext.MainPlayerEntityID)
	{
		return false;
	}
	
	// 非全屏状态，无需播放受击
	if (!bFullScreenSignature)
	{
		return false;
	}
	const FDateTime TimeNow = FDateTime::Now();
	const FTimespan DeltaTime = TimeNow - LastPlayFullScreenFeedBackTime;
	if (DeltaTime.GetTotalSeconds() > FullScreenHitFeedBackCD)
	{
		LastPlayFullScreenFeedBackTime = TimeNow;
		return true;
	}

	return false;
}

void UKGDamageProcessManager::PlayFullScreenFeedBack()
{
	if (!FullScreenHitFeedBackWidget.IsValid())
	{
		AsyncLoadFeedBackWidget(FullScreenHitFeedBackPanelPath, FullScreenHitFeedBackWidgetZOrder);
		return;
	}

	if (!FullScreenHitFeedBackWidgetAnimation.IsValid())
	{
		FullScreenHitFeedBackWidgetAnimation = FullScreenHitFeedBackWidget->GetWidgetAnimationByName(FullScreenHitFeedBackWidget.Get(), FullScreenHitFeedBackWidgetAnimationName);	
	}

	if (FullScreenHitFeedBackWidgetAnimation.IsValid())
	{
		FullScreenHitFeedBackWidget->PlayAnimation(FullScreenHitFeedBackWidgetAnimation.Get());
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("UKGDamageProcessManager::PlayFullScreenFeedBack, invalid FullScreenHitFeedBackWidgetAnimation %s"), *FullScreenHitFeedBackWidgetAnimationName);
	}
}

void UKGDamageProcessManager::AsyncLoadFeedBackWidget(FString WidgetClassPath, int32 ZOrder)
{
	check(AssetManagerPtr.IsValid());
	
	if (AssetManagerPtr.IsValid())
	{
		AssetManagerPtr->AsyncLoadAsset(WidgetClassPath, FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGDamageProcessManager::OnFullScreenHitFeedBackWidgetLoaded, WidgetClassPath, ZOrder));
	}
}

void UKGDamageProcessManager::OnFullScreenHitFeedBackWidgetLoaded(int32 RequestID, UObject* LoadedAsset, FString AssetPath, int32 ZOrder)
{
	UClass* FeedBackHitClass = Cast<UClass>(LoadedAsset);
	if (!FeedBackHitClass)
	{
		UE_LOG(LogTemp, Error, TEXT("UKGDamageProcessManager::OnFullScreenHitFeedBackWidgetLoaded, invalid loaded asset %s"), *AssetPath);
		return;
	}
	FullScreenHitFeedBackWidget = HUDManagerPtr->CreateHUDComponentWidget(FeedBackHitClass, ZOrder);

	PlayFullScreenFeedBack();
}


void UKGDamageProcessManager::GetHitFxTransformDefault(FTransform& EffectTransform, AActor* Defender, AActor* Instigator, const FDamageVFXContext& FxContent)
{
	FVector DefenderLoc = Defender->GetActorLocation();
	FVector InstigatorLoc = Instigator->GetActorLocation();
	FVector Impulse = InstigatorLoc - DefenderLoc;
	Impulse = Impulse.GetSafeNormal();

	USceneComponent* RootComp = Defender->GetRootComponent();
	if (!RootComp)
	{
		return;
	}
	float Bias = RootComp->GetLocalBounds().SphereRadius;
	if (UCapsuleComponent* Capsule = Cast<UCapsuleComponent>(RootComp))
	{
		Bias = Capsule->GetScaledCapsuleRadius();
	}

	EffectTransform.SetLocation(FVector(DefenderLoc.X + Impulse.X * Bias, DefenderLoc.Y + Impulse.Y * Bias, DefenderLoc.Z) + FxContent.VFXData->HitEffectOffset);
	const FQuat& Q1 = Impulse.ToOrientationQuat();
	const FQuat& Q2 = (FxContent.VFXData->HitEffectRotation * -1).Quaternion();
	EffectTransform.SetRotation(Q1 * Q2);

	EffectTransform.SetScale3D(FxContent.VFXData->HitEffectScale);

}

void UKGDamageProcessManager::GetHitFxTransformBySocket(FTransform& EffectTransform, AActor* Defender, AActor* Instigator, const FDamageVFXContext& FxContent)
{	
	UMeshComponent* SKComp;
	IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(Defender);
	if (C7ActorInterface)
	{
		SKComp = C7ActorInterface->GetMainMesh();
	}
	else
	{
		SKComp = Defender->FindComponentByClass<USkeletalMeshComponent>();
	}

	if (SKComp)
	{
		EffectTransform.SetLocation(SKComp->GetSocketLocation(FxContent.VFXData->HitFxPosUsedSocket) + FxContent.VFXData->HitEffectOffset);

		FVector InstigatorLoc = Instigator->GetActorLocation();
		FVector DefenderLoc = Defender->GetActorLocation();
		FVector Impulse = InstigatorLoc - DefenderLoc;
		Impulse = Impulse.GetSafeNormal();
		const FQuat& Q1 = Impulse.ToOrientationQuat();
		const FQuat& Q2 = (FxContent.VFXData->HitEffectRotation * -1).Quaternion();
		EffectTransform.SetRotation(Q1 * Q2);

		EffectTransform.SetScale3D(FxContent.VFXData->HitEffectScale);

	}
	else
	{
		GetHitFxTransformDefault(EffectTransform, Defender, Instigator, FxContent);
	}
}

void UKGDamageProcessManager::TryUpdateEffectTransform(FDamageVFXContext& InOutContext)
{
	if (InOutContext.EffectTransform.IsSet())
	{
		return;
	}

	AActor* Defender = nullptr;
	AActor* Instigator = nullptr;
	check(InOutContext.DefenderEntity);
	check(InOutContext.InstigatorEntity);
	if (InOutContext.DefenderEntity->GetLuaEntityBase())
	{
		Defender = InOutContext.DefenderEntity->GetLuaEntityBase()->GetActor();
	}
	if (InOutContext.InstigatorEntity->GetLuaEntityBase())
	{
		Instigator = InOutContext.InstigatorEntity->GetLuaEntityBase()->GetActor();
	}

	InOutContext.EffectTransform = FTransform(InOutContext.DefenderEntity->GetRotation(), InOutContext.DefenderEntity->GetLocation());
	if (!Defender || !Instigator)
	{
		return;
	}
	
	FTransform EffectTransform = FTransform::Identity;
	FVector DefenderLoc = Defender->GetActorLocation();
	if (InOutContext.VFXData->LocationMode == EHitEffectPlayLocationMode::HitLocation)
	{
		if (InOutContext.MsgData->bNeedSpecifyTrans)
		{
			EffectTransform = InOutContext.MsgData->SpecifyTrans;
		}
		else
		{
			if (InOutContext.VFXData->HitFxPosUsedSocket != NAME_None)
			{	
				GetHitFxTransformBySocket(EffectTransform, Defender, Instigator, InOutContext);
			}
			else
			{
				GetHitFxTransformDefault(EffectTransform, Defender, Instigator, InOutContext);
			}
		}
	}
	else
	{
		EffectTransform.SetLocation(DefenderLoc);
		EffectTransform.SetRotation(Defender->GetActorQuat());
	}

	InOutContext.EffectTransform = EffectTransform;
}

bool UKGDamageProcessManager::IsRelatedToPlayer(const FDamageContext& InContext) const
{
	const KGEntityID PlayerUID = InContext.MainPlayerEntityID;
	const KGEntityID ControlledUnitUID = InContext.ControlledUnitUID;
	
    if (InContext.MsgData->InstigatorID == PlayerUID 
    	|| InContext.MsgData->DefenderID == PlayerUID 
    	|| InContext.MsgData->InstigatorID == ControlledUnitUID 
    	|| InContext.MsgData->DefenderID == ControlledUnitUID)
    {
        return true;
    }

	ICppEntityInterface* EntityDefender = UEActorManagerPtr->GetLuaEntity(InContext.MsgData->DefenderID);
	if (EntityDefender 
		&& (EntityDefender->GetEntityData().FinalOwnerID == PlayerUID 
			|| EntityDefender->GetEntityData().FinalOwnerID == ControlledUnitUID))
    {
        return true;
    }

    ICppEntityInterface* EntityInstigator = UEActorManagerPtr->GetLuaEntity(InContext.MsgData->InstigatorID);
    if (EntityInstigator
    	&& (EntityInstigator->GetEntityData().FinalOwnerID == PlayerUID 
    		|| EntityInstigator->GetEntityData().FinalOwnerID == ControlledUnitUID))
    {
        return true;
    }
	
    return false;
}

FString UKGDamageProcessManager::ConvertBattleChannelDataInternal(const FBattleChatRawData& BattleChatRawData)
{
	// ProcessedData 可以由 lua 拼接好，此时直接返回不做处理即可
	if (!BattleChatRawData.ProcessedData.IsEmpty()) return BattleChatRawData.ProcessedData;
	
	FString Text = "";
	if (UKGDataCacheManager* DataCacheManager = Cast<UKGDataCacheManager>(GetManagerByType(EManagerType::EMT_DataCacheManager)))
	{
		SourceName = BattleChatRawData.AttackerName;
		TargetName = BattleChatRawData.DefenderName;

		if (BattleChatRawData.DamageMethod == EDamageMethod::Blocked)
		{
			CriticalText = DataCacheManager->GetStringConst(TEXT("SOCIAL_CHAT_BATTLE_BLOCK_STRIKE"));
		}
		else if (BattleChatRawData.DamageMethod == EDamageMethod::Critical)
		{
			CriticalText = DataCacheManager->GetStringConst(TEXT("SOCIAL_CHAT_BATTLE_CRITICAL_STRIKE"));
		}
		else
		{
			CriticalText = "";
		}

		if (BattleChatRawData.AssetIDWithType % 10 == 0 || BattleChatRawData.AssetIDWithType % 10 == 2)
		{
			const int32 SkillID = BattleChatRawData.AssetIDWithType / 10;
			if (FSkillData* SkillData = DataCacheManager->GetSkillData(SkillID))
			{
				const FString& SkillName = SkillData->Name;
				Text = ConvertBattleChannelSkillData(BattleChatRawData, SkillName, DataCacheManager);
			}
			else if (not BattleChatRawData.PassiveSkillName.IsEmpty())
			{
				Text = ConvertBattleChannelSkillData(BattleChatRawData, BattleChatRawData.PassiveSkillName, DataCacheManager);
			}
		}
		else if (BattleChatRawData.AssetIDWithType % 10 == 1)
		{
			const int32 BuffID = BattleChatRawData.AssetIDWithType / 10;
			if (FBuffData* BuffData = DataCacheManager->GetBuffData(BuffID))
			{
				const FString& BuffName = BuffData->BuffName;
				Text = ConvertBattleChannelSkillData(BattleChatRawData, BuffName, DataCacheManager);
			}
		}
	}
	return Text;
}

FString UKGDamageProcessManager::ConvertBattleChannelSkillData(const FBattleChatRawData& BattleChatRawData, const FString& SkillName, UKGDataCacheManager* DataCacheManager)
{
	FString Text = "";
	bool HasSourceName = !SourceName.IsEmpty();
	bool HasTargetName = !TargetName.IsEmpty();
	if (BattleChatRawData.DamageProcessType == EDamageProcessType::Heal)
	{
		if (BattleChatRawData.TotalValue > 0)
		{
			if (BattleChatRawData.AttackerID == BattleChatRawData.MainPlayerEntityID || BattleChatRawData.DefenderID != BattleChatRawData.MainPlayerEntityID)
			{
				if (HasTargetName)
				{
					if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_REG")))
					{
						TArray<FString> ArgumentStrings{ SkillName, TargetName, FString::FromInt(BattleChatRawData.TotalValue), "" };
						Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
					}
				}
				else
				{
					if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_REG_UNKNOWN")))
					{
						TArray<FString> ArgumentStrings{ SkillName, FString::FromInt(BattleChatRawData.TotalValue), "" };
						Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
					}
				}
			}
			else
			{
				if (HasSourceName)
				{
					if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_HPREG")))
					{
						TArray<FString> ArgumentStrings{ SourceName, SkillName, FString::FromInt(BattleChatRawData.TotalValue), "" };
						Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
					}
				}
				else
				{
					if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_HPREG_UNKNOWN")))
					{
						TArray<FString> ArgumentStrings{ SkillName, FString::FromInt(BattleChatRawData.TotalValue), "" };
						Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
					}
				}
			}
		}
	}
	else if (BattleChatRawData.DamageProcessType == EDamageProcessType::HealLimit)
	{
		const FString& HealLimitText = DataCacheManager->GetStringConst(TEXT("SOCIAL_CHAT_BATTLE_LIMIT_HEAL"));
		if (BattleChatRawData.AttackerID == BattleChatRawData.MainPlayerEntityID || BattleChatRawData.DefenderID != BattleChatRawData.MainPlayerEntityID)
		{
			if (HasTargetName)
			{
				if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_REG")))
				{
					TArray<FString> ArgumentStrings{ SkillName, TargetName, "0", HealLimitText };
					Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
				}
			}
			else
			{
				if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_REG_UNKNOWN")))
				{
					TArray<FString> ArgumentStrings{ SkillName, "0", HealLimitText };
					Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
				}
			}
		}
		else
		{
			if (HasSourceName)
			{
				if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_HPREG")))
				{
					TArray<FString> ArgumentStrings{ SourceName, SkillName, "0", HealLimitText };
					Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
				}
			}
			else
			{
				if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_HPREG_UNKNOWN")))
				{
					TArray<FString> ArgumentStrings{ SkillName, "0", HealLimitText };
					Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
				}
			}
		}
	}
	else if (BattleChatRawData.DamageProcessType == EDamageProcessType::Damage)
	{
		int32 HpDelta = BattleChatRawData.RealValue - BattleChatRawData.ShieldCost;
		if (BattleChatRawData.RealValue > 0)
		{
			TArray<FString> DamageTypeList = DataCacheManager->GetStringConstList(TEXT("SOCIAL_CHAT_BATTLE_DAMAGE_TYPE"));;
			DamageTypeText = "";
			if (!DamageTypeList.IsEmpty())
			{
				if (BattleChatRawData.DamageType == EDamageType::Physics)
				{
					DamageTypeText = DamageTypeList[0];
				}
				else if (BattleChatRawData.DamageType == EDamageType::Magic && DamageTypeList.IsValidIndex(1))
				{
					DamageTypeText = DamageTypeList[1];
				}
			}
			FString ShieldCostText = ""; // 护盾吸收
			if (BattleChatRawData.ShieldCost > 0)
			{
				const FString& ShieldReminderData = DataCacheManager->GetStringConst(TEXT("CHAT_BATTLE_SHIELD"));
				if (!ShieldReminderData.IsEmpty())
				{
					ShieldCostText = UHUDManager::CustomPrintf(ShieldReminderData, { FString::FromInt(int32(BattleChatRawData.ShieldCost)) });
				}
			}
			if (BattleChatRawData.AttackerID == BattleChatRawData.MainPlayerEntityID || BattleChatRawData.DefenderID != BattleChatRawData.MainPlayerEntityID)
			{
				// 我打别人
				if (HasTargetName)
				{
					if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_ATK_ACTIVE")))
					{
						TArray<FString> ArgumentStrings{ SkillName, TargetName, FString::FromInt(HpDelta), DamageTypeText, ShieldCostText, CriticalText };
						Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
					}
				}
				else
				{
					if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_ATK_ACTIVE_UNKNOWN")))
					{
						TArray<FString> ArgumentStrings{ SkillName, FString::FromInt(HpDelta), DamageTypeText, ShieldCostText, CriticalText };
						Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
					}
				}
			}
			else
			{
				// 被别人打
				if (HasSourceName)
				{
					if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_ATK_PASSIVE")))
					{
						TArray<FString> ArgumentStrings{ SourceName, SkillName, FString::FromInt(HpDelta), DamageTypeText, ShieldCostText, CriticalText };
						Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
					}
				}
				else
				{
					if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_ATK_PASSIVE_UNKNOWN")))
					{
						TArray<FString> ArgumentStrings{ SkillName, FString::FromInt(HpDelta), DamageTypeText, ShieldCostText, CriticalText };
						Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
					}
				}
			}
		}
	}
	else if (BattleChatRawData.DamageProcessType == EDamageProcessType::Control)
	{
		FString ControlText = "";
		if (BattleChatRawData.ControlAddResultType == EControlAddResultType::Immune) {
			ControlText = DataCacheManager->GetStringConst(TEXT("CHAT_BATTLE_CONTROL_IMMUNE"));
		}
		else if (BattleChatRawData.ControlAddResultType == EControlAddResultType::Fail)
		{
			ControlText = DataCacheManager->GetStringConst(TEXT("CHAT_BATTLE_CONTROL_FAIL"));
		}
		if (BattleChatRawData.AttackerID == BattleChatRawData.MainPlayerEntityID || BattleChatRawData.DefenderID != BattleChatRawData.MainPlayerEntityID)
		{
			if (HasTargetName)
			{
				if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_CONTROL_ACTIVE")))
				{
					TArray<FString> ArgumentStrings{ SkillName, TargetName, BattleChatRawData.ControlName, ControlText };
					Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
				}
			}
			else
			{
				if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_CONTROL_ACTIVE_UNKNOWN")))
				{
					TArray<FString> ArgumentStrings{ SkillName, BattleChatRawData.ControlName, ControlText };
					Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
				}
			}
		}
		else
		{
			if (HasSourceName)
			{
				if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_CONTROL_PASSIVE")))
				{
					TArray<FString> ArgumentStrings{ SourceName, SkillName, BattleChatRawData.ControlName, ControlText };
					Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
				}
			}
			else
			{
				if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_CONTROL_PASSIVE_UNKNOWN")))
				{
					TArray<FString> ArgumentStrings{ SkillName, BattleChatRawData.ControlName, ControlText };
					Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
				}
			}
		}
	}
	else if (BattleChatRawData.DamageProcessType == EDamageProcessType::BurnBody)
	{
		if (BattleChatRawData.AttackerID == BattleChatRawData.MainPlayerEntityID || BattleChatRawData.DefenderID != BattleChatRawData.MainPlayerEntityID)
		{
			if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_BURNBODY_ACTIVE")))
			{
				TArray<FString> ArgumentStrings{ SkillName, TargetName };
				Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
			}
		}
		else
		{
			if (FReminderData* ReminderData = DataCacheManager->GetReminderData(TEXT("CHAT_FIGHT_BURNBODY_PASSIVE")))
			{
				TArray<FString> ArgumentStrings{ SourceName, SkillName };
				Text = UHUDManager::CustomPrintf(ReminderData->Text1, ArgumentStrings);
			}
		}
	}
	return Text;
}

