#include "Managers/KGCombatUnitManager.h"

#include "3C/Character/BulletActor.h"
#include "3C/Character/C7DecalActor.h"
#include "KGCharacterModule.h"
#include "Components/DecalComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Util/KGUtils.h"

#pragma region Common

void UKGCombatUnitManager::NativeInit()
{
	Super::NativeInit();

	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_RegisterCombatUnitClass", &UKGCombatUnitManager::KAPI_CombatUnitManager_RegisterCombatUnitClass);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_RegisterCombatUnitBPClass", &UKGCombatUnitManager::KAPI_CombatUnitManager_RegisterCombatUnitBPClass);
	
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetBulletInfo", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetBulletInfo);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SpawnBullet", &UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnBullet);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SpawnClientPerformBullet", &UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnClientPerformBullet);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_DestroyBullet", &UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyBullet);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_DestroyBulletByInstID", &UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyBulletByInstID);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_DestroyBulletsByInstigatorID", &UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyBulletsByInstigatorID);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_BulletLoseTarget", &UKGCombatUnitManager::KAPI_CombatUnitManager_BulletLoseTarget);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetBulletsHiddenStateByInstigatorID", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetBulletsHiddenStateByInstigatorID);
	
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalInfo", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalInfo);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_AddRecFillModeParam", &UKGCombatUnitManager::KAPI_CombatUnitManager_AddRecFillModeParam);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_ClearRecFillModeParams", &UKGCombatUnitManager::KAPI_CombatUnitManager_ClearRecFillModeParams);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_AddCircleLikeFillModeParam", &UKGCombatUnitManager::KAPI_CombatUnitManager_AddCircleLikeFillModeParam);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_ClearCircleLikeFillModeParams", &UKGCombatUnitManager::KAPI_CombatUnitManager_ClearCircleLikeFillModeParams);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_AddRecDissolveModeParam", &UKGCombatUnitManager::KAPI_CombatUnitManager_AddRecDissolveModeParam);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_ClearRecDissolveModeParams", &UKGCombatUnitManager::KAPI_CombatUnitManager_ClearRecDissolveModeParams);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_AddCircleLikeDissolveModeParam", &UKGCombatUnitManager::KAPI_CombatUnitManager_AddCircleLikeDissolveModeParam);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_ClearCircleLikeDissolveModeParams", &UKGCombatUnitManager::KAPI_CombatUnitManager_ClearCircleLikeDissolveModeParams);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_GenerateDecalInstID", &UKGCombatUnitManager::KAPI_CombatUnitManager_GenerateDecalInstID);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SpawnDecalByTemplate", &UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalByTemplate);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SpawnDecalCustomized", &UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalCustomized);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_DestroyDecal", &UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyDecal);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalHiddenInGame", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalHiddenInGame);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_HideAllDecalsVisibility", &UKGCombatUnitManager::KAPI_CombatUnitManager_HideAllDecalsVisibility);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalTextureMaterialParam", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalTextureMaterialParam);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalVectorMaterialParam", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalVectorMaterialParam);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalFloatMaterialParam", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalFloatMaterialParam);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalSize", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalSize);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalWorldLocation", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalWorldLocation);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalRelativeLocation", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalRelativeLocation);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalRelativeRotation", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalRelativeRotation);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_DecalAttachToActor", &UKGCombatUnitManager::KAPI_CombatUnitManager_DecalAttachToActor);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_DecalSetAbsolute", &UKGCombatUnitManager::KAPI_CombatUnitManager_DecalSetAbsolute);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_SetDecalActorLabel", &UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalActorLabel);
	REG_MANAGER_FUNC(UKGCombatUnitManager, "KAPI_CombatUnitManager_GetDecalActorID", &UKGCombatUnitManager::KAPI_CombatUnitManager_GetDecalActorID);
	REG_EXTENSION_METHOD_IMP(UKGCombatUnitManager, "KAPI_CombatUnitManager_GetDecalLocationAndRotation_P", {
		CheckUD(UKGCombatUnitManager, L, 1);
		return UD->KAPI_CombatUnitManager_GetDecalLocationAndRotation_P(L);
	});
	REG_EXTENSION_METHOD_IMP(UKGCombatUnitManager, "KAPI_CombatUnitManager_GetDecalUpQuat_P", {
		CheckUD(UKGCombatUnitManager, L, 1);
		return UD->KAPI_CombatUnitManager_GetDecalUpQuat_P(L);
	});	
	REG_EXTENSION_METHOD_IMP(UKGCombatUnitManager, "KAPI_CombatUnitManager_GetDecalUpRotator_P", {
		CheckUD(UKGCombatUnitManager, L, 1);
		return UD->KAPI_CombatUnitManager_GetDecalUpRotator_P(L);
	});
	REG_EXTENSION_METHOD_IMP(UKGCombatUnitManager, "KAPI_CombatUnitManager_GetDecalSize_P", {
		CheckUD(UKGCombatUnitManager, L, 1);
		return UD->KAPI_CombatUnitManager_GetDecalSize_P(L);
	});
}

void UKGCombatUnitManager::NativeUninit()
{
	Super::NativeUninit();
}

void UKGCombatUnitManager::RegisterCombatUnitClass(uint8 InType, UClass* InClass)
{
	if (!IsValid(InClass))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::RegisterCombatUnitClass InClass is invalid"));
		return;
	}

	if (InType >= static_cast<uint8>(EKGCombatUnitType::Max))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::RegisterCombatUnitClass InType is invalid: %d"), InType);
		return;
	}

	CombatUnitClassMap.Add(static_cast<EKGCombatUnitType>(InType), InClass);
}

bool UKGCombatUnitManager::UpdateAndCacheManagers()
{
	if (!DataCacheManager.IsValid())
	{
		DataCacheManager = UKGDataCacheManager::GetInstance(this);
		if (!DataCacheManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnBullet DataCacheManager is invalid"));
			return false;
		}
	}

	if (!ActorManager.IsValid())
	{
		ActorManager = UKGUEActorManager::GetInstance(this);
		if (!ActorManager.IsValid())
		{
			UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnBullet DataCacheManager is invalid"));
			return false;
		}
	}

	return true;
}

void UKGCombatUnitManager::OnPostLoadMapWithWorld(UWorld* World)
{
	Super::OnPostLoadMapWithWorld(World);

	BulletActorsByInstID.Empty();
	BulletActorsByInstigatorID.Empty();
	DecalActorsBySpawnerID.Empty();
	DecalActorsByInstID.Empty();
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_RegisterCombatUnitBPClass(uint8 InType, const FString& InBPClass)
{
	UClass* BPClass = LoadClass<AActor>(nullptr, *InBPClass);
	if (!IsValid(BPClass))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_RegisterCombatUnitBPClass LoadClass failed for %s"), *InBPClass);
		return;
	}

	RegisterCombatUnitClass(InType, BPClass);
}

#pragma endregion Common

#pragma region Bullet

KGActorID UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnBullet(
	uint32 TemplateID, float LifeTimeSeconds, KGEntityID LauncherID, KGEntityID InstigatorID, KGEntityID TargetID,
	float ServerTargetPosX, float ServerTargetPosY, float ServerTargetPosZ, float StartPosX, float StartPosY, float StartPosZ,
	float StartPitch, float StartYaw, float ServerPosOffsetX, float ServerPosOffsetY, float ServerPosOffsetZ,
	float ServerRotOffsetPitch, float ServerRotOffsetYaw, float ServerRotOffsetRoll, EKGBulletOffsetMode OffsetMode, uint64 InstID, 
	bool bOwnerHidden, bool bInALSAiming)
{
	return SpawnBullet(
		TemplateID, LifeTimeSeconds, LauncherID, InstigatorID,
		TargetID, ServerTargetPosX, ServerTargetPosY, ServerTargetPosZ,
		StartPosX, StartPosY, StartPosZ, StartPitch, StartYaw,
		ServerPosOffsetX, ServerPosOffsetY, ServerPosOffsetZ,
		ServerRotOffsetPitch, ServerRotOffsetYaw, ServerRotOffsetRoll,
		OffsetMode, InstID, bOwnerHidden, bInALSAiming);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetBulletInfo(float InBulletDestroyNiagaraLifeTimeSeconds, const TArray<int32>& InObjectTypesToQuery, int32 InBulletAudioFadeTimeMS)
{
	BulletDestroyNiagaraLifeTimeSeconds = InBulletDestroyNiagaraLifeTimeSeconds;
	for (auto InObjectTypeToQuery : InObjectTypesToQuery)
	{
		PerfectDodgeObjectTypesToQuery.Add(static_cast<TEnumAsByte<EObjectTypeQuery>>(InObjectTypeToQuery));
	}
	BulletAudioFadeTimeMS = InBulletAudioFadeTimeMS;
}

KGActorID UKGCombatUnitManager::SpawnBullet(
	uint32 TemplateID, float LifeTimeSeconds, KGEntityID LauncherID, KGEntityID InstigatorID,
	KGEntityID TargetID, float ServerTargetPosX, float ServerTargetPosY, float ServerTargetPosZ,
	float StartPosX, float StartPosY, float StartPosZ, float StartPitch, float StartYaw,
	float ServerPosOffsetX, float ServerPosOffsetY, float ServerPosOffsetZ,
	float ServerRotOffsetPitch, float ServerRotOffsetYaw, float ServerRotOffsetRoll,
	EKGBulletOffsetMode OffsetMode, uint64 InstID, bool bOwnerHidden, bool bInALSAiming)
{
	SCOPED_NAMED_EVENT(UKGCombatUnitManager_SpawnBullet, FColor::Red);
	
	if (!UpdateAndCacheManagers())
	{
		return KG_INVALID_ACTOR_ID;
	}
	check(DataCacheManager.IsValid());
	check(ActorManager.IsValid());

	UWorld*	World = GetWorld();
	if (!World)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnBullet World is invalid"));
		return KG_INVALID_ACTOR_ID;
	}
	
	FBulletData* BulletDataPtr = DataCacheManager->GetBulletData(TemplateID);
	if (BulletDataPtr == nullptr)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnBullet BulletData is null for ID %d"), TemplateID);
		return KG_INVALID_ACTOR_ID;
	}

	FVector StartPos(StartPosX, StartPosY, StartPosZ);
	FRotator StartRot(StartPitch, StartYaw, 0.0f);
	FVector ServerTargetPos(ServerTargetPosX, ServerTargetPosY, ServerTargetPosZ);
	FVector ServerPosOffset(ServerPosOffsetX, ServerPosOffsetY, ServerPosOffsetZ);
	FRotator ServerRotOffset(ServerRotOffsetPitch, ServerRotOffsetYaw, ServerRotOffsetRoll);
	
	FTransform BulletSpawnTransform;
	if (!ABulletActor::CalculateSpawnTransform(
		ActorManager.Get(), *BulletDataPtr, LauncherID, TargetID,
		StartPos, StartRot, ServerPosOffset, ServerRotOffset, OffsetMode, BulletSpawnTransform, bInALSAiming))
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnBullet CalculateSpawnTransform failed"));
		return 0;
	}
	
	ABulletActor* BulletActor;
	{
		SCOPED_NAMED_EVENT(UKGCombatUnitManager_SpawnBullet_SpawnActor, FColor::Red);
		BulletActor = Cast<ABulletActor>(World->SpawnActor(ABulletActor::StaticClass(), &BulletSpawnTransform));
	}
	if (!BulletActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnBullet SpawnActor failed"));
		return KG_INVALID_ACTOR_ID;
	}

	BulletActor->InitParams(*BulletDataPtr, LauncherID, InstigatorID, TargetID, LifeTimeSeconds,
	    ServerTargetPos, StartPos, StartRot, BulletDestroyNiagaraLifeTimeSeconds, InstID, BulletAudioFadeTimeMS);
	BulletActor->EnterWorld();

	if (bOwnerHidden)
	{
		UE_LOG(LogKGCombat, Log, TEXT("UKGCombatUnitManager::SpawnBullet bullet init hidden %s, %lld"), *BulletActor->GetName(), InstID);
		BulletActor->UpdateHiddenState(true);
	}
	
	if (InstID != KG_INVALID_BULLET_INST_ID)
	{
		UE_CLOG(BulletActorsByInstID.Contains(InstID), LogKGCombat, Error,
			TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnBullet InstID %llu already exists"), InstID);
		BulletActorsByInstID.Add(InstID, BulletActor);
	}

	if (InstigatorID != KG_INVALID_BULLET_INST_ID)
	{
		auto& InstigatorBullets = BulletActorsByInstigatorID.FindOrAdd(InstigatorID);
		InstigatorBullets.Add(BulletActor);
	}
	
	return KGUtils::GetIDByObject(BulletActor);
}

KGActorID UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnClientPerformBullet(
	uint32 TemplateID, EKGBulletDirectionMode DirectionMode, KGEntityID LauncherID, KGEntityID TargetID, float YawOffset, float PitchOffset,
	float PosOffsetX, float PosOffsetY, float PosOffsetZ, bool bOwnerHidden)
{
	SCOPED_NAMED_EVENT(UKGCombatUnitManager_SpawnClientPerformBullet, FColor::Red);

	if (!UpdateAndCacheManagers())
	{
		return KG_INVALID_ACTOR_ID;
	}
	check(DataCacheManager.IsValid());
	check(ActorManager.IsValid());

	FBulletData* BulletDataPtr = DataCacheManager->GetBulletData(TemplateID);
	if (BulletDataPtr == nullptr)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnClientPerformBullet BulletData is null for ID %d"), TemplateID);
		return KG_INVALID_ACTOR_ID;
	}

	auto* LauncherEntity = ActorManager->GetLuaEntity(LauncherID);
	if (!LauncherEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnClientPerformBullet LauncherEntity is null for ID %lld"), LauncherID);
		return KG_INVALID_ACTOR_ID;
	}
	
	auto* TargetEntity = ActorManager->GetLuaEntity(TargetID);
	if (!TargetEntity)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnClientPerformBullet TargetEntity is null for ID %lld"), TargetID);
		return KG_INVALID_ACTOR_ID;
	}

	FVector PosOffset(PosOffsetX, PosOffsetY, PosOffsetZ);
	if (PosOffset.ContainsNaN())
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnClientPerformBullet PosOffset contains NaN"));
		return KG_INVALID_ACTOR_ID;
	}

	bool bUseBonePos = false;
	FVector LauncherPos;
	if (BulletDataPtr->StartPosAnchorBone.IsEmpty())
	{
		if (AActor* TargetActor = TargetEntity->GetLuaEntityBase()->GetActor())
		{
			if (USkeletalMeshComponent* SkeletalMeshComp = TargetActor->FindComponentByClass<USkeletalMeshComponent>())
			{
				LauncherPos = SkeletalMeshComp->GetBoneLocation(*BulletDataPtr->StartPosAnchorBone);
				bUseBonePos = true;
			}
		}
	}

	if (!bUseBonePos)
	{
		LauncherPos = TargetEntity->GetLocation();
	}

	FRotator LauncherRot = FRotator(0.0f, TargetEntity->GetRotation().Yaw, 0.0f);
	FVector Root1Pos = LauncherRot.RotateVector(BulletDataPtr->StartPosAnchorOffset) + LauncherPos;

	LauncherRot.Pitch += PitchOffset;
	LauncherRot.Yaw += YawOffset;
	FVector Root2Pos = LauncherRot.RotateVector(PosOffset) + Root1Pos;

	FVector TargetPos;
	float LifeTimeSeconds = BulletDataPtr->MaxLifeTime;
	if (BulletDataPtr->TrailType == EKGBulletTrailType::Direction)
	{
		const float Velocity = BulletDataPtr->Velocity;
		const float Acceleration = BulletDataPtr->Acceleration;
		const float MoveDist = BulletDataPtr->MoveDist;
		float CalcDist = Velocity * LifeTimeSeconds + 0.5 * Acceleration * LifeTimeSeconds * LifeTimeSeconds;
		if (CalcDist > MoveDist)
		{
			if (Acceleration > UE_KINDA_SMALL_NUMBER)
			{
				// 1/2 a*t^2 + v*t - s = 0 => t = (sqrt(2*a*s + v^2) - v) / a
				LifeTimeSeconds = (FMath::Sqrt(2.0 * Acceleration * MoveDist + Velocity * Velocity) - Velocity) / Acceleration;
			}
			else if (Velocity > UE_KINDA_SMALL_NUMBER)
			{
				LifeTimeSeconds = MoveDist / Velocity;
			}
			else
			{
				UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnClientPerformBullet bullet with zero velocity and zero acceleration %d"), TemplateID);
				return KG_INVALID_ACTOR_ID;
			}
		}

		const FRotator& SelfRot = LauncherEntity->GetRotation();
		TargetPos = LauncherPos + SelfRot.RotateVector(FVector(MoveDist, 0.0f, 0.0f));
	}
	else if (BulletDataPtr->TrailType == EKGBulletTrailType::Line)
	{
		TargetPos = TargetEntity->GetLocation();

		if (BulletDataPtr->Velocity > UE_KINDA_SMALL_NUMBER)
		{
			LifeTimeSeconds = (TargetPos - LauncherPos).Size2D() / BulletDataPtr->Velocity;
		}
		else
		{
			UE_LOG(LogKGCombat, Log, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnClientPerformBullet bullet with zero velocity %d, use max life time"), TemplateID);
		}
	}
	else
	{
		TargetPos = TargetEntity->GetLocation();
	}

	FRotator StartRot = FRotator::ZeroRotator;
	if (DirectionMode == EKGBulletDirectionMode::Root1ToRoot2)
	{
		if (!Root1Pos.Equals(Root2Pos, UE_KINDA_SMALL_NUMBER))
		{
			StartRot = (Root2Pos - Root1Pos).Rotation();
		}
	}
	else if (DirectionMode == EKGBulletDirectionMode::UseDirectionByConfig || DirectionMode == EKGBulletDirectionMode::Direction2Target)
	{
		if (!TargetPos.Equals(LauncherPos, UE_KINDA_SMALL_NUMBER))
		{
			StartRot = (TargetPos - LauncherPos).Rotation();	
		}
	}
	else if (DirectionMode == EKGBulletDirectionMode::UseDirectionByTask)
	{
		StartRot = LauncherRot;
	}
	else
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnClientPerformBullet invalid DirectionMode %d"), static_cast<int32>(DirectionMode));
		return KG_INVALID_ACTOR_ID;
	}

	return SpawnBullet(
			TemplateID, LifeTimeSeconds, LauncherID, LauncherID, TargetID,
			TargetPos.X, TargetPos.Y, TargetPos.Z,
			Root2Pos.X, Root2Pos.Y, Root2Pos.Z, StartRot.Pitch, StartRot.Roll,
			0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f,
			EKGBulletOffsetMode::Spawner, KG_INVALID_BULLET_INST_ID, bOwnerHidden);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyBullet(KGActorID BulletID, int8 DestroyReason)
{
	ABulletActor* BulletActor = Cast<ABulletActor>(KGUtils::GetObjectByID(BulletID));
	if (!BulletActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyBullet invalid BulletActor ID %lld"), BulletID);
		return;
	}

	DestroyBullet(BulletActor, static_cast<EKGBulletDestroyReason>(DestroyReason));
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyBulletByInstID(uint64 InstID, int8 DestroyReason)
{
	if (!BulletActorsByInstID.Contains(InstID))
	{
		return;
	}

	auto BulletActor = BulletActorsByInstID[InstID];
	if (!BulletActor.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyBulletByInstID invalid BulletActor InstID %llu"), InstID);
		return;
	}

	DestroyBullet(BulletActor.Get(), static_cast<EKGBulletDestroyReason>(DestroyReason));
}

void UKGCombatUnitManager::DestroyBulletsByInstigatorID(KGEntityID InstigatorID)
{
	if (!BulletActorsByInstigatorID.Contains(InstigatorID))
	{
		return;
	}

	TSet<TWeakObjectPtr<ABulletActor>> TempBulletActors = BulletActorsByInstigatorID[InstigatorID];
	for (auto& BulletActorPtr : TempBulletActors)
	{
		if (BulletActorPtr.IsValid())
		{
			DestroyBullet(BulletActorPtr.Get(), EKGBulletDestroyReason::INSTIGATOR_DESTROY);
		}
	}
	BulletActorsByInstigatorID.Remove(InstigatorID);
}

void UKGCombatUnitManager::DestroyBullet(ABulletActor* BulletActor, EKGBulletDestroyReason DestroyReason)
{
	if (!BulletActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::DestroyBullet BulletActor is null"));
		return;
	}

	SCOPED_NAMED_EVENT(UKGCombatUnitManager_DestroyBullet, FColor::Red);
	
	const auto InstID = BulletActor->GetInstID();
	if (InstID != KG_INVALID_BULLET_INST_ID)
	{
		BulletActorsByInstID.Remove(InstID);
	}

	const auto InstigatorID = BulletActor->GetInstigatorID();
	if (InstigatorID != KG_INVALID_ENTITY_ID)
	{
		if (BulletActorsByInstigatorID.Contains(InstigatorID))
		{
			BulletActorsByInstigatorID[InstigatorID].Remove(BulletActor);
		}
	}

	BulletActor->ExitWorld(DestroyReason);
	BulletActor->Destroy();
}

void UKGCombatUnitManager::GetAllBulletActorsByInstigatorID(KGEntityID InstigatorID, TSet<TWeakObjectPtr<ABulletActor>>& OutBulletActors)
{
	if (BulletActorsByInstigatorID.Contains(InstigatorID))
	{
		OutBulletActors = BulletActorsByInstigatorID[InstigatorID];
	}
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetBulletsHiddenStateByInstigatorID(KGEntityID InstigatorID, bool bHidden)
{
	auto* BulletActorsPtr = BulletActorsByInstigatorID.Find(InstigatorID);
	if (!BulletActorsPtr)
	{
		return;
	}
	
	for (auto& BulletActorPtr : *BulletActorsPtr)
	{
		if (BulletActorPtr.IsValid())
		{
			BulletActorPtr->UpdateHiddenState(bHidden);
		}
	}
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_BulletLoseTarget(uint64 InstID)
{
	if (!BulletActorsByInstID.Contains(InstID))
	{
		return;
	}

	auto BulletActor = BulletActorsByInstID[InstID];
	if (!BulletActor.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_BulletLoseTarget invalid BulletActor InstID %llu"), InstID);
		return;
	}

	BulletActor->LoseTarget();
}

#pragma endregion Bullet

#pragma region Decal

#define KG_CALL_DECAL_ACTOR_FUNCTION(FunctionName, DecalInstID, ...) \
	if (!DecalActorsByInstID.Contains(DecalInstID)) \
	{ \
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalInstID %ld"), *FString(__FUNCTION__), DecalInstID); \
		return; \
	} \
	auto& DecalActor = DecalActorsByInstID[DecalInstID]; \
	if (!DecalActor.IsValid()) \
	{ \
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalActor ID %ld"), *FString(__FUNCTION__), DecalInstID); \
		return; \
	} \
	DecalActor->FunctionName(__VA_ARGS__);

#define KG_CALL_DECAL_ACTOR_FUNCTION_RETVAL(DefaultRetVal, FunctionName, DecalInstID, ...) \
	if (!DecalActorsByInstID.Contains(DecalInstID)) \
	{ \
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalInstID %ld"), *FString(__FUNCTION__), DecalInstID); \
		return DefaultRetVal; \
	} \
	auto& DecalActor = DecalActorsByInstID[DecalInstID]; \
	if (!DecalActor.IsValid()) \
	{ \
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalActor ID %ld"), *FString(__FUNCTION__), DecalInstID); \
		return DefaultRetVal; \
	} \
	return DecalActor->FunctionName(__VA_ARGS__);
	

uint32 UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalByTemplate(
	KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID, float PosX, float PosY, float PosZ, float Pitch, float Yaw, float Roll,
	EDecalPositionMode PosMode, EDecalRotationMode RotMode, const FName& AttachBoneName, bool bAbsoluteScale,
	bool bUseColor, float ColorR, float ColorG, float ColorB, float ColorA,
	bool bUseGlowColor, float GlowColorR, float GlowColorG, float GlowColorB, float GlowColorA,
	bool bNeedCheckGround, float FadeInTimeSeconds, float FadeOutTimeSeconds, float LifeTimeSeconds, float DissolveTimeSeconds,
	uint32 TemplateType, EDecalShapeType ShapeType, float Length, float Width, float Angle, float Radius,
	float InnerRadius, float OuterRadius, float FillingDuration, const FString& FillCurvePath, bool bLoopControl,  EDecalPointAtTargetType PointAtTargetType,
	uint8 ScaleMode, EDecalRecFillMode RecFillMode, EDecalCircleLikeFillMode CircleLikeFillMode,
	EDecalRecDissolveMode RecDissolveMode, EDecalCircleLikeDissolveMode CircleLikeDissolveMode, uint32 CustomDecalInstID)
{
	SCOPED_NAMED_EVENT(KAPI_CombatUnitManager_SpawnDecalByTemplate, FColor::Red);

	if (!UpdateAndCacheManagers())
	{
		return KG_INVALID_DECAL_INST_ID;
	}
	check(DataCacheManager.IsValid());
	check(ActorManager.IsValid());

	auto* DecalConfigData = DataCacheManager->GetDecalConfigData(TemplateType, ShapeType, ScaleMode);
	if (!DecalConfigData)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalByTemplate DecalConfigData is null for TemplateType %d, ShapeType %d, ScaleMode %d"),
			static_cast<int32>(TemplateType), static_cast<int32>(ShapeType), ScaleMode);
		return KG_INVALID_DECAL_INST_ID;
	}

	if (DecalConfigData->MatPath.IsEmpty())
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalByTemplate invalid decal material path for TemplateType %d, ShapeType %d, ScaleMode %d"),
			static_cast<int32>(TemplateType), static_cast<int32>(ShapeType), ScaleMode);
		return KG_INVALID_DECAL_INST_ID;
	}

	FTransform InTransform = FTransform::Identity;
	InTransform.SetLocation(FVector(PosX, PosY, PosZ));
	InTransform.SetRotation(FQuat(FRotator(Pitch, Yaw, Roll)));
	if (InTransform.ContainsNaN())
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalByTemplate SpawnTransform contains NaN"));
		return KG_INVALID_DECAL_INST_ID;
	}
	
	AC7DecalActor* DecalActor = SpawnDecalActorCommon();
	if (!DecalActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalByTemplate SpawnDecalActor failed, %d, %d, %d"), 
			static_cast<int32>(TemplateType), static_cast<int32>(ShapeType), ScaleMode);
		return KG_INVALID_DECAL_INST_ID;
	}
	
	DecalActor->InitParamsByTemplate(
		*DecalConfigData, ActorManager, this, SpawnerEntityID, InstigatorEntityID, 
		InTransform, PosMode, RotMode, AttachBoneName, bAbsoluteScale, TemplateDecalSizeX,
		bUseColor, ColorR, ColorG, ColorB, ColorA,
		bUseGlowColor, GlowColorR, GlowColorG, GlowColorB, GlowColorA,
		bNeedCheckGround, FadeInTimeSeconds, FadeOutTimeSeconds, LifeTimeSeconds, DissolveTimeSeconds,
		ShapeType, Length, Width, Angle, Radius, InnerRadius, OuterRadius, FillingDuration, FillCurvePath, bLoopControl, PointAtTargetType,
		RecFillMode, CircleLikeFillMode, RecDissolveMode, CircleLikeDissolveMode);
	DecalActor->EnterWorld();

	return PostProcessDecalActor(DecalActor, SpawnerEntityID, CustomDecalInstID);
}

uint32 UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalCustomized(
	KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID, const FString& MaterialPath, float DecalSizeX, float DecalSizeY, float DecalSizeZ,
	float PosX, float PosY, float PosZ, float Pitch, float Yaw, float Roll,
	EDecalPositionMode InPosMode, EDecalRotationMode InRotMode, const FName& AttachBoneName,  bool bAbsoluteScale,
	bool bNeedCheckGround, float FadeInTimeSeconds, float FadeOutTimeSeconds, float LifeTimeSeconds, float DissolveTimeSeconds,
	bool bOverrideAngle, float Angle, bool bOverrideInnerRadius, float InnerRadius, bool bOverrideOuterRadius, float OuterRadius,
	bool bOverrideControl, EDecalParamModifyType ControlModifyType, float ConstControlValue, float ControlDuration, const FString& ControlCurvePath,
	bool bLoopControl, EDecalPointAtTargetType PointAtTargetType, uint32 CustomDecalInstID)
{
	SCOPED_NAMED_EVENT(KAPI_CombatUnitManager_SpawnDecalCustomized, FColor::Red);

	if (MaterialPath.IsEmpty())
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalCustomized invalid MaterialPath"));
		return KG_INVALID_DECAL_INST_ID;
	}
	
	if (!UpdateAndCacheManagers())
	{
		return KG_INVALID_DECAL_INST_ID;
	}
	check(DataCacheManager.IsValid());
	check(ActorManager.IsValid());

	FTransform InTransform = FTransform::Identity;
	InTransform.SetLocation(FVector(PosX, PosY, PosZ));
	InTransform.SetRotation(FQuat(FRotator(Pitch, Yaw, Roll)));
	if (InTransform.ContainsNaN())
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalCustomized SpawnTransform contains NaN"));
		return KG_INVALID_DECAL_INST_ID;
	}
	
	AC7DecalActor* DecalActor = SpawnDecalActorCommon();
	if (!DecalActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalCustomized SpawnDecalActor failed, %s"), *MaterialPath);
		return KG_INVALID_DECAL_INST_ID;
	}

	DecalActor->InitParamsCustomized(
		SpawnerEntityID, ActorManager, this, InstigatorEntityID,
		MaterialPath, DecalSizeX, DecalSizeY, DecalSizeZ,
		InPosMode, InRotMode, AttachBoneName, bAbsoluteScale, bNeedCheckGround, InTransform,
		FadeInTimeSeconds, FadeOutTimeSeconds, LifeTimeSeconds, DissolveTimeSeconds,
		bOverrideAngle, Angle, bOverrideInnerRadius, InnerRadius, bOverrideOuterRadius, OuterRadius,
		bOverrideControl, ControlModifyType, ConstControlValue, ControlDuration, ControlCurvePath, bLoopControl, PointAtTargetType);
	DecalActor->EnterWorld();

	return PostProcessDecalActor(DecalActor, SpawnerEntityID, CustomDecalInstID);
}

uint32 UKGCombatUnitManager::SpawnDecalSimple(const FKGSimpleDecalSpawnParams& Params)
{
	SCOPED_NAMED_EVENT(UKGCombatUnitManager_SpawnDecalSimple, FColor::Red);
	
	if (Params.MaterialPath.IsEmpty())
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::SpawnDecalSimple invalid MaterialPath"));
		return KG_INVALID_DECAL_INST_ID;
	}
	
	if (!Params.SpawnerActor.IsValid())
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::SpawnDecalSimple invalid spawner actor"));
		return KG_INVALID_DECAL_INST_ID;
	}
	
	if (!UpdateAndCacheManagers())
	{
		return KG_INVALID_DECAL_INST_ID;
	}
	check(DataCacheManager.IsValid());
	check(ActorManager.IsValid());
	
	AC7DecalActor* DecalActor = SpawnDecalActorCommon();
	if (!DecalActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::SpawnDecalSimple SpawnDecalActor failed, %s"), *Params.MaterialPath);
		return KG_INVALID_DECAL_INST_ID;
	}

	DecalActor->InitParamsByDecalSpawnParams(Params, ActorManager, this);
	DecalActor->EnterWorld();

	return PostProcessDecalActor(DecalActor, KG_INVALID_ENTITY_ID, KG_INVALID_DECAL_INST_ID);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyDecal(uint32 DecalInstID, bool bFadeOut)
{
	if (!DecalActorsByInstID.Contains(DecalInstID))
	{
		return;
	}
	
	AC7DecalActor* DecalActor = DecalActorsByInstID[DecalInstID].Get();
	if (!DecalActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_DestroyDecal invalid DecalActor ID %ld"), DecalInstID);
		return;
	}
	
	DestroyDecal(DecalActor, bFadeOut);
}

void UKGCombatUnitManager::DestroyDecal(AC7DecalActor* DecalActor, bool bFadeOut)
{
	if (!IsValid(DecalActor))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::DestroyDecal DecalActor is invalid"));
		return;
	}

	if (bFadeOut && DecalActor->FadeOut())
	{
		return;
	}
	
	const auto SpawnerID = DecalActor->GetSpawnerEntityID();
	if (DecalActorsBySpawnerID.Contains(SpawnerID))
	{
		DecalActorsBySpawnerID[SpawnerID].Remove(DecalActor);
	}

	DecalActor->ExitWorld();
	DecalActor->Destroy();
}

void UKGCombatUnitManager::DestroyDecalActorBySpawnerID(KGEntityID SpawnerEntityID)
{
	auto* DecalActorSetPtr = DecalActorsBySpawnerID.Find(SpawnerEntityID);
	if (!DecalActorSetPtr)
	{
		return;
	}

	TSet TempDecalActors(*DecalActorSetPtr);
	for (auto& DecalActorPtr : TempDecalActors)
	{
		if (DecalActorPtr.IsValid())
		{
			DestroyDecal(DecalActorPtr.Get(), false);
		}
	}
	
	DecalActorsBySpawnerID.Remove(SpawnerEntityID);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalHiddenInGame(uint32 DecalInstID, bool bHidden, EKGDecalHiddenReason Reason)
{
	KG_CALL_DECAL_ACTOR_FUNCTION(SetDecalHiddenInGame, DecalInstID, bHidden, Reason);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalTextureMaterialParam(uint32 DecalInstID, const FName& ParamName, const FString& TexturePath)
{
	if (TexturePath.IsEmpty())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalTextureMaterialParam invalid TexturePath for DecalInstID %ld"), DecalInstID);
		return;
	}

	if (ParamName.IsNone())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalTextureMaterialParam invalid ParamName for DecalInstID %ld"), DecalInstID);
		return;
	}
	
	KG_CALL_DECAL_ACTOR_FUNCTION(SetTextureMaterialParam, DecalInstID, ParamName, TexturePath);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalVectorMaterialParam(uint32 DecalInstID, const FName& ParamName, float R, float G, float B, float A)
{
	FLinearColor ColorParam(R, G, B, A);
	UE_CLOG(FVector4(ColorParam).ContainsNaN(), LogKGCombat, Error,
		TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalVectorMaterialParam ColorParam contains NaN for DecalInstID %ld"), DecalInstID);
	KG_CALL_DECAL_ACTOR_FUNCTION(SetVectorMaterialParam, DecalInstID, ParamName, ColorParam);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalFloatMaterialParam(uint32 DecalInstID, const FName& ParamName, float Value)
{
	KG_CALL_DECAL_ACTOR_FUNCTION(SetFloatMaterialParam, DecalInstID, ParamName, Value);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalSize(uint32 DecalInstID, float SizeX, float SizeY, float SizeZ)
{
	KG_CALL_DECAL_ACTOR_FUNCTION(SetDecalSize, DecalInstID, SizeX, SizeY, SizeZ);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalWorldLocation(uint32 DecalInstID, float PosX, float PosY, float PosZ)
{
	FVector Location(PosX, PosY, PosZ);
	UE_CLOG(Location.ContainsNaN(), LogKGCombat, Error,
		TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalWorldLocation Location contains NaN for DecalInstID %ld"), DecalInstID);
	KG_CALL_DECAL_ACTOR_FUNCTION(SetActorLocation, DecalInstID, Location);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalRelativeLocation(uint32 DecalInstID, float PosX, float PosY, float PosZ)
{
	UE_LOG(LogKGCombat, Log, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalRelativeLocation DecalInstID %ld, PosX %f, PosY %f, PosZ %f"),
		DecalInstID, PosX, PosY, PosZ);
	FVector NewRelativeLocation(PosX, PosY, PosZ);
	UE_CLOG(NewRelativeLocation.ContainsNaN(), LogKGCombat, Error,
		TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SetRelativeLocation NewRelativeLocation contains NaN for DecalInstID %ld"), DecalInstID);
	KG_CALL_DECAL_ACTOR_FUNCTION(SetActorRelativeLocation, DecalInstID, NewRelativeLocation);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalRelativeRotation(uint32 DecalInstID, float Pitch, float Yaw, float Roll)
{
	UE_LOG(LogKGCombat, Log, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalRelativeRotation DecalInstID %ld, Pitch %f, Yaw %f, Roll %f"),
		DecalInstID, Pitch, Yaw, Roll);
	FRotator NewRelativeRotation(Pitch, Yaw, Roll);
	UE_CLOG(NewRelativeRotation.ContainsNaN(), LogKGCombat, Error,
		TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalRelativeRotation NewRelativeRotation contains NaN for DecalInstID %ld"), DecalInstID);
	KG_CALL_DECAL_ACTOR_FUNCTION(SetActorRelativeRotation, DecalInstID, NewRelativeRotation);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_DecalAttachToActor(uint32 DecalInstID, KGActorID ParentActorID, FName SocketName, EAttachmentRule LocationRule, EAttachmentRule RotationRule, EAttachmentRule ScaleRule, bool bWeldSimulatedBodies)
{
	AActor* ParentActor = KGUtils::GetActorByID(ParentActorID);
	if (!ParentActor)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_DecalAttachToActor invalid ParentActor ID %lld"), ParentActorID);
		return;
	}
	KG_CALL_DECAL_ACTOR_FUNCTION(K2_AttachToActor, DecalInstID, ParentActor, SocketName, LocationRule, RotationRule, ScaleRule, bWeldSimulatedBodies);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_DecalSetAbsolute(uint32 DecalInstID, bool bNewAbsoluteLocation, bool bNewAbsoluteRotation, bool bNewAbsoluteScale)
{
	KG_CALL_DECAL_ACTOR_FUNCTION(SetAbsolute, DecalInstID, bNewAbsoluteLocation, bNewAbsoluteRotation, bNewAbsoluteScale);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalActorLabel(uint32 DecalInstID, const FString& NewActorLabel, bool bMarkDirty)
{
#if WITH_EDITOR
	KG_CALL_DECAL_ACTOR_FUNCTION(SetActorLabel, DecalInstID, NewActorLabel, bMarkDirty);
#endif
}

KGActorID UKGCombatUnitManager::KAPI_CombatUnitManager_GetDecalActorID(uint32 DecalInstID)
{
	KG_CALL_DECAL_ACTOR_FUNCTION_RETVAL(KG_INVALID_ACTOR_ID, GetActorID, DecalInstID);
}

int UKGCombatUnitManager::KAPI_CombatUnitManager_GetDecalLocationAndRotation_P(lua_State* L)
{
	uint32 DecalInstID = luaL_checkinteger(L, 2);
	if (!DecalActorsByInstID.Contains(DecalInstID))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalInstID %ld"), *FString(__FUNCTION__), DecalInstID);
		return 0;
	}
	
	auto& DecalActor = DecalActorsByInstID[DecalInstID];
	if (!DecalActor.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalActor ID %ld"), *FString(__FUNCTION__), DecalInstID);
		return 0;
	}
	
	const auto& Location = DecalActor->GetActorLocation();
	const auto& Quat = DecalActor->GetActorRotation().Quaternion();
	lua_pushnumber(L, Location.X);
	lua_pushnumber(L, Location.Y);
	lua_pushnumber(L, Location.Z);
	lua_pushnumber(L, Quat.X);
	lua_pushnumber(L, Quat.Y);
	lua_pushnumber(L, Quat.Z);
	lua_pushnumber(L, Quat.W);
	return 7;
}

int UKGCombatUnitManager::KAPI_CombatUnitManager_GetDecalUpQuat_P(lua_State* L)
{
	uint32 DecalInstID = luaL_checkinteger(L, 2);
	if (!DecalActorsByInstID.Contains(DecalInstID))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalInstID %ld"), *FString(__FUNCTION__), DecalInstID);
		return 0;
	}
	
	auto& DecalActor = DecalActorsByInstID[DecalInstID];
	if (!DecalActor.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalActor ID %ld"), *FString(__FUNCTION__), DecalInstID);
		return 0;
	}

	const auto& Quat = DecalActor->GetActorUpVector().ToOrientationQuat();
	lua_pushnumber(L, Quat.X);
	lua_pushnumber(L, Quat.Y);
	lua_pushnumber(L, Quat.Z);
	lua_pushnumber(L, Quat.W);
	return 4;
}

int UKGCombatUnitManager::KAPI_CombatUnitManager_GetDecalUpRotator_P(lua_State* L)
{
	uint32 DecalInstID = luaL_checkinteger(L, 2);
	if (!DecalActorsByInstID.Contains(DecalInstID))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalInstID %ld"), *FString(__FUNCTION__), DecalInstID);
		return 0;
	}
	
	auto& DecalActor = DecalActorsByInstID[DecalInstID];
	if (!DecalActor.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalActor ID %ld"), *FString(__FUNCTION__), DecalInstID);
		return 0;
	}

	const auto& Rotator = DecalActor->GetActorUpVector().ToOrientationRotator();
	lua_pushnumber(L, Rotator.Pitch);
	lua_pushnumber(L, Rotator.Yaw);
	lua_pushnumber(L, Rotator.Roll);
	return 3;
}

int UKGCombatUnitManager::KAPI_CombatUnitManager_GetDecalSize_P(lua_State* L)
{
	uint32 DecalInstID = luaL_checkinteger(L, 2);
	if (!DecalActorsByInstID.Contains(DecalInstID))
	{
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalInstID %ld"), *FString(__FUNCTION__), DecalInstID);
		return 0;
	}
	
	auto& DecalActor = DecalActorsByInstID[DecalInstID];
	if (!DecalActor.IsValid())
	{
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalActor ID %ld"), *FString(__FUNCTION__), DecalInstID);
		return 0;
	}

	UDecalComponent* DecalComp = DecalActor->GetDecal();
	if (!DecalComp)
	{
		UE_LOG(LogKGCombat, Warning, TEXT("%s invalid DecalComp ID %ld"), *FString(__FUNCTION__), DecalInstID);
		return 0;
	}

	const auto& DecalSize = DecalComp->DecalSize;
	lua_pushnumber(L, DecalSize.X);
	lua_pushnumber(L, DecalSize.Y);
	lua_pushnumber(L, DecalSize.Z);
	return 3;
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_HideAllDecalsVisibility(bool bHide, EKGDecalHiddenReason Reason)
{
	if (bHide)
	{
		GlobalHiddenReasons.Add(Reason);
	}
	else
	{
		GlobalHiddenReasons.Remove(Reason);
	}
	
	for (auto& DecalActorPair : DecalActorsByInstID)
	{
		auto& DecalActor = DecalActorPair.Value;
		if (DecalActor.IsValid())
		{
			DecalActor->SetDecalHiddenInGame(bHide, Reason);
		}
	}
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_SetDecalInfo(
	const FName& InColorMaterialParamName, const FName& InGlowColorMaterialParamName, const FName& InControlModeMaterialParamName,
	const FName& InDecalWorldSizeMaterialParamName, const FName& InGridSizeMaterialParamName, const FName& InControlMaterialParamName,
	const FName& InInnerCircleSizeMaterialParamName, const FName& InOuterRadiusMaterialParamName, const FName& InSectorAngleMaterialParamName,
	const FName& InDissolveProgressMaterialParamName, const FName& InOpacityMaterialParamName, const FName& InDissolveModeMaterialParamName,
	float InTemplateDecalSizeX, float DefaultDecalPitch, float DefaultDecalYaw, float DefaultDecalRoll)
{
	ColorMaterialParamName = InColorMaterialParamName;
	GlowColorMaterialParamName = InGlowColorMaterialParamName;
	ControlModeMaterialParamName = InControlModeMaterialParamName;
	DecalWorldSizeMaterialParamName = InDecalWorldSizeMaterialParamName;
	GridSizeMaterialParamName = InGridSizeMaterialParamName;
	ControlMaterialParamName = InControlMaterialParamName;
	InnerCircleSizeMaterialParamName = InInnerCircleSizeMaterialParamName;
	OuterRadiusMaterialParamName = InOuterRadiusMaterialParamName;
	SectorAngleMaterialParamName = InSectorAngleMaterialParamName;
	DissolveProgressMaterialParamName = InDissolveProgressMaterialParamName;
	OpacityMaterialParamName = InOpacityMaterialParamName;
	DissolveModeMaterialParamName = InDissolveModeMaterialParamName;
	TemplateDecalSizeX = InTemplateDecalSizeX;
	DefaultDecalQuat = FRotator(DefaultDecalPitch, DefaultDecalYaw, DefaultDecalRoll).Quaternion();
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_AddRecFillModeParam(EDecalRecFillMode InFillMode, float R, float G, float B, float A)
{
	FLinearColor ColorParam(R, G, B, A);
	UE_CLOG(FVector4(ColorParam).ContainsNaN(), LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_AddRecFillModeParam ColorParam contains NaN"));
	RecFillModeParams.Add(InFillMode, ColorParam);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_ClearRecFillModeParams()
{
	RecFillModeParams.Empty();
}

bool UKGCombatUnitManager::GetRecFillModeParam(EDecalRecFillMode InFillMode, FLinearColor& OutColor) const
{
	if (!RecFillModeParams.Contains(InFillMode))
	{
		return false;
	}

	OutColor = RecFillModeParams[InFillMode];
	return true;
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_AddCircleLikeFillModeParam(EDecalCircleLikeFillMode InFillMode, float R, float G, float B, float A)
{
	FLinearColor ColorParam(R, G, B, A);
	UE_CLOG(FVector4(ColorParam).ContainsNaN(), LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_AddCircleLikeFillModeParam ColorParam contains NaN"));
	CircleLikeFillModeParams.Add(InFillMode, ColorParam);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_ClearCircleLikeFillModeParams()
{
	CircleLikeFillModeParams.Empty();
}

bool UKGCombatUnitManager::GetCircleLikeFillModeParam(EDecalCircleLikeFillMode InFillMode, FLinearColor& OutColor) const
{
	if (!CircleLikeFillModeParams.Contains(InFillMode))
	{
		return false;
	}

	OutColor = CircleLikeFillModeParams[InFillMode];
	return true;
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_AddRecDissolveModeParam(EDecalRecDissolveMode InDissolveMode, float R, float G, float B, float A)
{
	FLinearColor ColorParam(R, G, B, A);
	UE_CLOG(FVector4(ColorParam).ContainsNaN(), LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_AddRecDissolveModeParam ColorParam contains NaN"));
	RecDissolveModeParams.Add(InDissolveMode, ColorParam);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_ClearRecDissolveModeParams()
{
	RecDissolveModeParams.Empty();
}

bool UKGCombatUnitManager::GetRecDissolveModeParam(EDecalRecDissolveMode InDissolveMode, FLinearColor& OutColor) const
{
	if (!RecDissolveModeParams.Contains(InDissolveMode))
	{
		return false;
	}

	OutColor = RecDissolveModeParams[InDissolveMode];
	return true;
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_AddCircleLikeDissolveModeParam(
	EDecalCircleLikeDissolveMode InDissolveMode, float R, float G, float B, float A)
{
	FLinearColor ColorParam(R, G, B, A);
	UE_CLOG(FVector4(ColorParam).ContainsNaN(), LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_AddCircleLikeDissolveModeParam ColorParam contains NaN"));
	CircleLikeDissolveModeParams.Add(InDissolveMode, ColorParam);
}

void UKGCombatUnitManager::KAPI_CombatUnitManager_ClearCircleLikeDissolveModeParams()
{
	CircleLikeDissolveModeParams.Empty();
}

bool UKGCombatUnitManager::GetCircleLikeDissolveModeParam(EDecalCircleLikeDissolveMode InDissolveMode, FLinearColor& OutColor) const
{
	if (!CircleLikeDissolveModeParams.Contains(InDissolveMode))
	{
		return false;
	}

	OutColor = CircleLikeDissolveModeParams[InDissolveMode];
	return true;
}

AC7DecalActor* UKGCombatUnitManager::SpawnDecalActorCommon()
{
	UWorld*	World = GetWorld();
	if (!World)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::SpawnDecalActorCommon World is invalid"));
		return nullptr;
	}

	// 先都在原点创建actor, 后续attach & set absolute做完以后再设置transform, 避免位置设置逻辑分散在两个地方不方便理解
	AC7DecalActor* DecalActor;
	{
		SCOPED_NAMED_EVENT(KAPI_CombatUnitManager_SpawnActor, FColor::Red);
		DecalActor = Cast<AC7DecalActor>(World->SpawnActor(AC7DecalActor::StaticClass()));
	}
	if (!DecalActor)
	{
		UE_LOG(LogKGCombat, Error, TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalByTemplate SpawnActor failed"));
		return nullptr;
	}

	if (GlobalHiddenReasons.Num() > 0)
	{
		for (const auto Reason : GlobalHiddenReasons)
		{
			DecalActor->SetDecalHiddenInGame(true, Reason);	
		}
	}

	return DecalActor;
}

uint32 UKGCombatUnitManager::PostProcessDecalActor(AC7DecalActor* DecalActor, KGEntityID SpawnerEntityID, uint32 CustomDecalInstID)
{
	if (!IsValid(DecalActor))
	{
		return KG_INVALID_DECAL_INST_ID;
	}
	
	if (SpawnerEntityID != KG_INVALID_ENTITY_ID)
	{
		DecalActorsBySpawnerID.FindOrAdd(SpawnerEntityID).Add(DecalActor);
	}
	
	uint32 DecalInstID;
	if (CustomDecalInstID != KG_INVALID_DECAL_INST_ID)
	{
		DecalInstID = CustomDecalInstID;
	}
	else
	{
		DecalInstID = GenerateDecalInstID();
	}
	
	if (DecalActorsByInstID.Contains(DecalInstID))
	{
		UE_LOG(LogKGCombat, Error,
			TEXT("UKGCombatUnitManager::KAPI_CombatUnitManager_SpawnDecalByTemplate DecalInstID %u already exists"), DecalInstID);
		return KG_INVALID_DECAL_INST_ID;
	}

	DecalActorsByInstID.Add(DecalInstID, DecalActor);
	DecalActor->SetDecalInstID(DecalInstID);
	return DecalInstID;
}

uint32 UKGCombatUnitManager::GenerateDecalInstID()
{
	static uint32 CurrentDecalInstID = 0;
	CurrentDecalInstID++;
	if (CurrentDecalInstID == 0x7fffffff)
	{
		CurrentDecalInstID = 1;
	}
	return CurrentDecalInstID;
}

#pragma endregion Decal
