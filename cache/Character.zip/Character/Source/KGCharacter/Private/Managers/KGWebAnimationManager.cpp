#include "CoreMinimal.h"
#include "Managers/KGWebAnimationManager.h"	
#include "Misc/FileHelper.h" // 用于文件读取
#include "Serialization/JsonReader.h" // JSON读取
#include "Serialization/JsonSerializer.h"
#include "Misc/Base64.h" // Base64解码
#include "Dom/JsonObject.h"
#include "JsonObjectConverter.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "Manager/KGCppAssetManager.h"
#include "AnimationRuntime.h" 
#include "3C/Camera/CameraManager.h"
#include "3C/Animation/WebAnimation/FKRetarget.h"

void FAIAnimProcessorManager::ThreadWork()
{
	SCOPED_NAMED_EVENT(FAIAnimProcessorManager_ThreadWork, FColor::Red);
	for (auto& It : ProcessorList)
	{
		if (It.Get())
		{
			It->PreThreadWork(Context);
		}
	}
	for (auto& It : ProcessorList)
	{
		if (It.Get())
		{
			It->ThreadWork(Context);
		}
	}
	ProcessorList.Empty();
}
void FAIAnimProcessorManager::AddProcessor(TSharedPtr<IAIAnimProcessor> Processor)
{
	ProcessorList.Add(Processor);
}

void UKGWebAnimationManager::NativeInit()
{
	Super::NativeInit();
	using namespace NS_SLUA;

	this->DebugRK = FVector(1, 1, -1);
	this->DebugRot = FRotator(0, 0, 0);
	this->DebugAxis = {0, 1, 2, 3};
	
	// 初始化默认权重
	PeopleSortWeights.Add(TEXT("bbox_size"), 0.4f);
	PeopleSortWeights.Add(TEXT("center_dist"), 0.3f);
	PeopleSortWeights.Add(TEXT("motion"), 0.3f);
	
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_SetBodyParts", &UKGWebAnimationManager::KAPI_WebAnimation_SetBodyParts);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_ParseAndCacheWebAnimationData", &UKGWebAnimationManager::KAPI_WebAnimation_ParseAndCacheWebAnimationData);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_ParseAndCacheWebAnimationDataNew", &UKGWebAnimationManager::KAPI_WebAnimation_ParseAndCacheWebAnimationDataNew);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_PreloadPose", &UKGWebAnimationManager::KAPI_WebAnimation_PreloadPose);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_PreloadPoseFromJson", &UKGWebAnimationManager::KAPI_WebAnimation_PreloadPoseFromJson);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_ClearAllWebAnimationData", &UKGWebAnimationManager::KAPI_WebAnimation_ClearAllWebAnimationData);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_ClearWebAnimationData", &UKGWebAnimationManager::KAPI_WebAnimation_ClearWebAnimationData);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_PlayCameraAnimation", &UKGWebAnimationManager::KAPI_WebAnimation_PlayCameraAnimation);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_SetDebugInfo", &UKGWebAnimationManager::KAPI_WebAnimation_SetDebugInfo);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_GetEmotionArray", &UKGWebAnimationManager::KAPI_WebAnimation_GetEmotionArray);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_GetEmotionConfArray", &UKGWebAnimationManager::KAPI_WebAnimation_GetEmotionConfArray);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_GetCameraRotArray", &UKGWebAnimationManager::KAPI_WebAnimation_GetCameraRotArray);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_GetCameraPosArray", &UKGWebAnimationManager::KAPI_WebAnimation_GetCameraPosArray);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_GetPeopleCount", &UKGWebAnimationManager::KAPI_WebAnimation_GetPeopleCount);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_SetPeopleSortWeight", &UKGWebAnimationManager::KAPI_WebAnimation_SetPeopleSortWeight);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_SetBlendFadeTime", &UKGWebAnimationManager::KAPI_WebAnimation_SetBlendFadeTime);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_GetSampleRate", &UKGWebAnimationManager::KAPI_WebAnimation_GetSampleRate);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_GetDuration", &UKGWebAnimationManager::KAPI_WebAnimation_GetDuration);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_GetPeopleInitPos", &UKGWebAnimationManager::KAPI_WebAnimation_GetPeopleInitPos);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_WebAnimation_GetFrameShape", &UKGWebAnimationManager::KAPI_WebAnimation_GetFrameShape);
	REG_MANAGER_FUNC(UKGWebAnimationManager, "KAPI_GetIsInitialized", &UKGWebAnimationManager::KAPI_GetIsInitialized);
}

void UKGWebAnimationManager::NativeUninit()
{
	Super::NativeUninit();
	WebAnimSequenceCache.Empty();
}


// 序列化：TMap -> JSON 字符串
bool UKGWebAnimationManager::SerializeBoneLocationDataToJson(int32 Index)
{
#if WITH_EDITOR
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject);

	auto BoneLocationData = BoneLocationDataMap.Find(Index);
	if (BoneLocationData == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to find BoneLocationData for Index %d"), Index);
		return false;
	}
	// 遍历 TMap，添加到 JsonObject
	for (const auto& Pair : *BoneLocationData)
	{
		const FString& BoneName = Pair.Key;
		const FVector& Location = Pair.Value;
		// 检查是否是 bodyPart
		if (!BodyParts.Contains(BoneName))
		{
			continue;
		}
		
		// 创建 Vector 的 JsonObject
		TSharedPtr<FJsonObject> VectorObject = MakeShareable(new FJsonObject);
		const float MinValue = 0.0001f;
		// 太小的值 直接设置为0
		if (FMath::Abs(Location.X) < MinValue)
		{
			VectorObject->SetNumberField(TEXT("X"), 0);
		}
		else
		{
			VectorObject->SetNumberField(TEXT("X"), Location.X);
		}
		
		if (FMath::Abs(Location.Y) < MinValue)
		{
			VectorObject->SetNumberField(TEXT("Y"), 0);
		}
		else
		{
			VectorObject->SetNumberField(TEXT("Y"), Location.Y);
		}

		if (FMath::Abs(Location.Z) < MinValue)
		{
			VectorObject->SetNumberField(TEXT("Z"), 0);
		}
		else
		{
			VectorObject->SetNumberField(TEXT("Z"), Location.Z);
		}

		JsonObject->SetObjectField(BoneName, VectorObject);
	}

	// 将 JsonObject 转换为字符串
	FString OutputString;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputString);
	FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer);


	// 获取Save目录
	FString SaveDir = FPaths::ProjectSavedDir();
	if (!SaveDir.EndsWith(TEXT("/")))
	{
		SaveDir += TEXT("/");
	}
	FString FilePath = SaveDir + TEXT("WebAnimationBoneLocation.json");
	if (FFileHelper::SaveStringToFile(OutputString, *FilePath))
	{
		UE_LOG(LogTemp, Log, TEXT("Successfully saved bone location data to: %s"), *FilePath);
		return true;
	}
#endif
	return false;
}

// 反序列化：JSON 字符串 -> TMap
bool UKGWebAnimationManager::DeserializeBoneLocationDataFromJson(const FString& JsonString, int32 Index)
{
	if (BoneLocationDataMap.Contains(Index))
	{
		return true;
	}

	// 先添加空的TMap，然后通过引用来填充数据
	TMap<FString, FVector>& BoneLocationData = BoneLocationDataMap.Add(Index, TMap<FString, FVector>());
	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);

	if (!FJsonSerializer::Deserialize(Reader, JsonObject) || !JsonObject.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to parse JSON string , jsonLen: %d"), JsonString.Len());
		return false;
	}

	// 遍历 JsonObject
	for (const auto& Pair : JsonObject->Values)
	{
		const FString& BoneName = Pair.Key;
		TSharedPtr<FJsonValue> Value = Pair.Value;

		if (Value->Type == EJson::Object)
		{
			TSharedPtr<FJsonObject> VectorObject = Value->AsObject();

			double X = VectorObject->GetNumberField(TEXT("X"));
			double Y = VectorObject->GetNumberField(TEXT("Y"));
			double Z = VectorObject->GetNumberField(TEXT("Z"));

			FVector Location(X, Y, Z);
			BoneLocationData.Add(BoneName, Location);
		}
	}

	UE_LOG(LogTemp, Log, TEXT("Successfully deserialized %d bones from JSON"), BoneLocationData.Num());
	return true;
}

// 获取指定索引的骨骼位置数据（返回指针，避免拷贝）
const TMap<FString, FVector>* UKGWebAnimationManager::GetBoneLocationData(int32 SexIndex) const
{
	return BoneLocationDataMap.Find(SexIndex);
}

// 读取动画的第一帧数据
bool UKGWebAnimationManager::EditorGetBoneLocationData(UAnimSequence* AnimSequence, int32 Index)
{
#if WITH_EDITOR
	BoneLocationDataMap.Empty();
	if (!AnimSequence)
	{
		return false;
	}

	// 获取骨骼架构
	USkeleton* Skeleton = AnimSequence->GetSkeleton();
	if (!Skeleton)
	{
		UE_LOG(LogTemp, Error, TEXT("Animation sequence has no skeleton"));
		return false;
	}

	// 获取引用骨骼信息
	const FReferenceSkeleton& RefSkeleton = Skeleton->GetReferenceSkeleton();
	int32 NumBones = RefSkeleton.GetNum();

	if (NumBones == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("Skeleton has no bones"));
		return false;
	}

	// 获取动画数据模型
	const IAnimationDataModel* DataModel = AnimSequence->GetDataModel();
	if (!DataModel)
	{
		UE_LOG(LogTemp, Error, TEXT("Animation sequence has no data model"));
		return false;
	}

	// 检查动画是否有帧数据
	int32 NumFrames = DataModel->GetNumberOfFrames();
	if (NumFrames == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("Animation sequence has no frames"));
		return false;
	}
	auto& BoneLocationData = BoneLocationDataMap.Add(Index, TMap<FString, FVector>());
	// 遍历所有骨骼，获取第一帧的位置数据
	for (int32 BoneIndex = 0; BoneIndex < NumBones; BoneIndex++)
	{
		FName BoneName = RefSkeleton.GetBoneName(BoneIndex);

		// 检查是否有该骨骼的动画轨道
		const FBoneAnimationTrack* BoneTrack = DataModel->FindBoneTrackByName(BoneName);
		if (!BoneTrack)
		{
			// 如果没有动画轨道，使用参考姿态的位置
			FTransform RefPose = RefSkeleton.GetRefBonePose()[BoneIndex];
			BoneLocationData.Add(BoneName.ToString(), RefPose.GetLocation());
			continue;
		}

		// 获取第一帧的变换数据
		if (BoneTrack->InternalTrackData.PosKeys.Num() > 0)
		{
			// 使用动画轨道的位置数据
			FVector FirstFramePosition = FVector(BoneTrack->InternalTrackData.PosKeys[0]);
			BoneLocationData.Add(BoneName.ToString(), FirstFramePosition);
		}
		else
		{
			// 如果没有位置关键帧，使用参考姿态
			FTransform RefPose = RefSkeleton.GetRefBonePose()[BoneIndex];
			BoneLocationData.Add(BoneName.ToString(), RefPose.GetLocation());
		}
	}

	UE_LOG(LogTemp, Log, TEXT("Successfully extracted bone location data from, Found %d bones"),
		BoneLocationData.Num());

	SerializeBoneLocationDataToJson(Index);
#endif
	return true;
}

TArray<float> UKGWebAnimationManager::DecodeBase64ToFloatArray(const FString& Base64String)
{
	TArray<float> FloatArray;
	if (Base64String.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("Base64 string is empty"));
		return FloatArray;
	}
	// 解码Base64
	TArray<uint8> BinaryData;
	FBase64::Decode(Base64String, BinaryData);

	// 将二进制数据转换为float数组
	int32 NumFloats = BinaryData.Num() / sizeof(float);
	FloatArray.Reserve(NumFloats);

	const float* FloatPtr = reinterpret_cast<const float*>(BinaryData.GetData());
	for (int32 i = 0; i < NumFloats; i++)
	{
		FloatArray.Add(FloatPtr[i]);
	}
	return FloatArray;
}

TArray<int8> UKGWebAnimationManager::DecodeBase64ToInt8Array(const FString& Base64String)
{
	TArray<int8> Int8Array;
	if (Base64String.IsEmpty())
	{
		UE_LOG(LogTemp, Error, TEXT("Base64 string is empty"));
		return Int8Array;
	}
	// 解码Base64
	TArray<uint8> BinaryData;
	FBase64::Decode(Base64String, BinaryData);

	// 将二进制数据转换为int8数组
	int32 NumInt8s = BinaryData.Num();
	Int8Array.Reserve(NumInt8s);

	const int8* Int8Ptr = reinterpret_cast<const int8*>(BinaryData.GetData());
	for (int32 i = 0; i < NumInt8s; i++)
	{
		Int8Array.Add(Int8Ptr[i]);
	}

	return Int8Array;
}


int32 UKGWebAnimationManager::CreateAnimationFromJson(const FString& AnimationName, const FString& FilePath)
{
	SCOPED_NAMED_EVENT(KGWebAnimationManager_CreateAnimationFromJson, FColor::Red);

	FString JsonString;
	if (!FFileHelper::LoadFileToString(JsonString, *FilePath))
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to load JSON file: %s"), *FilePath);
		return false;
	}

	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);

	if (!FJsonSerializer::Deserialize(Reader, JsonObject) || !JsonObject.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to parse JSON"));
		return false;
	}
	float FrameRate = 15;
	int num_people = 0;
	int num_joints = 52;
	int num_frames = 0;
	FString poseBase64;
	FString translBase64;
	FString camera_TBase64;
	FString camera_RBase64;
	FString audioBase64;
	FString emotionBase64;
	FString emotionConfBase64;
	FString validMaskBase64;
	const TArray<TSharedPtr<FJsonValue>>* foot_offset = nullptr;
	TArray<float> FootOffsetYArray;

	//如果存在 result 字段，直接使用 result 字段
	if (JsonObject->HasField(TEXT("result")))
	{
		TSharedPtr<FJsonObject> ResultObject = JsonObject->GetObjectField(TEXT("result"));
		if (ResultObject.IsValid())
		{
			JsonObject = ResultObject;
		}
	}
	
	// 解析JSON数据
	JsonObject->TryGetNumberField(TEXT("fps"), FrameRate);
	JsonObject->TryGetNumberField(TEXT("num_people"), num_people);
	JsonObject->TryGetNumberField(TEXT("num_frames"), num_frames);
	JsonObject->TryGetStringField(TEXT("pose"), poseBase64);
	JsonObject->TryGetStringField(TEXT("transl"), translBase64);
	JsonObject->TryGetStringField(TEXT("camera_T"), camera_TBase64);
	JsonObject->TryGetStringField(TEXT("camera_R"), camera_RBase64);
	JsonObject->TryGetStringField(TEXT("audio_wave"), audioBase64);
	JsonObject->TryGetStringField(TEXT("emotion"), emotionBase64);
	JsonObject->TryGetStringField(TEXT("emotion_conf"), emotionConfBase64);
	JsonObject->TryGetStringField(TEXT("valid_mask"), validMaskBase64);

	// 解析 frame_shape
	TArray<int32> FrameShapeArray;
	const TArray<TSharedPtr<FJsonValue>>* FrameShapeValues = nullptr;
	if (JsonObject->TryGetArrayField(TEXT("frame_shape"), FrameShapeValues))
	{
		for (const TSharedPtr<FJsonValue>& Value : *FrameShapeValues)
		{
			FrameShapeArray.Add(static_cast<int32>(Value->AsNumber()));
		}
	}

	bool bFootOffsetY = false;
	if (JsonObject->TryGetArrayField(TEXT("foot_offset"), foot_offset) && foot_offset != nullptr)
	{
		if (foot_offset->Num() > 0)
		{
			for (const auto& It : *foot_offset)
			{
				if (It != nullptr)
				{
					float FootOffsetY = 0;
					FootOffsetY = It->AsNumber();
					FootOffsetY = (FootOffsetY - 0.93) * 100; // 算法对应的魔数，暂定，后续会调整。
					FootOffsetY = FootOffsetY > 0 ? FMath::CeilToInt(FootOffsetY) : FMath::FloorToInt(FootOffsetY);
					FootOffsetYArray.Add(FootOffsetY);
					bFootOffsetY = true;
				}
				else
				{
					FootOffsetYArray.Add(0);
				}

			}
		}
	}

	// 解析 dominant_score
	TMap<FString, TArray<float>> DominantScore;
	if (JsonObject->HasField(TEXT("dominant_score")))
	{
		const TSharedPtr<FJsonObject>* DominantScoreObject;
		if (JsonObject->TryGetObjectField(TEXT("dominant_score"), DominantScoreObject))
		{
			for (const auto& Pair : (*DominantScoreObject)->Values)
			{
				const FString& Key = Pair.Key;
				const TArray<TSharedPtr<FJsonValue>>* ValueArray;
				if ((*DominantScoreObject)->TryGetArrayField(Key, ValueArray))
				{
					TArray<float> FloatArray;
					FloatArray.Reserve(ValueArray->Num());
					for (const TSharedPtr<FJsonValue>& Value : *ValueArray)
					{
						FloatArray.Add(Value->AsNumber());
					}
					DominantScore.Add(Key, FloatArray);
					UE_LOG(LogTemp, Log, TEXT("Parsed dominant_score[%s]: %d values"), *Key, FloatArray.Num());
				}
			}
		}
	}

	UE_LOG(LogTemp, Log, TEXT("CreateAnimationFromJson: fps = %.1f num_people = %d, num_joints = %d, num_frames = %d"),
		FrameRate, num_people, num_joints, num_frames);

	
	TArray<float> Camera_T = DecodeBase64ToFloatArray(camera_TBase64);
	TArray<float> Camera_R = DecodeBase64ToFloatArray(camera_RBase64);
	
	TArray<float> PoseData = DecodeBase64ToFloatArray(poseBase64);
	TArray<float> transl= DecodeBase64ToFloatArray(translBase64);


	auto Ret = CreateAnimation(AnimationName, 
		Camera_T, Camera_R, PoseData, transl,
		FrameRate, num_frames, num_people, num_joints,
		audioBase64, emotionBase64, emotionConfBase64, validMaskBase64,
		DominantScore, FootOffsetYArray, bFootOffsetY, FrameShapeArray);

	OnAnimCreated(AnimationName);

	return Ret;
}

int32 UKGWebAnimationManager::CreateAnimation(const FString& AnimationName,
	const TArray<float>& Camera_T, const TArray<float>& Camera_R,
	const TArray<float>& PoseData1, const TArray<float>& transl,
	float FrameRate, int num_frames, int num_people, int num_joints,
	const FString& audioBase64, const FString& emotionBase64, const FString& emotionConfBase64, const FString& validMaskBase64,

	const TMap<FString, TArray<float>>& DominantScore, const TArray<float>& FootOffsetYArray, bool bFootOffsetY,
	const TArray<int32>& FrameShapeArray, const TArray<TArray<float>>& BlendArray)
{
	SCOPED_NAMED_EVENT(KGWebAnimationManager_CreateAnimation, FColor::Red);

	// 骨骼重定向：为每种性别生成一套PoseData
	TArray<TArray<float>> PoseDataBySex;
	PoseDataBySex.SetNum((int32)EWebAnimationSexType::Max);
	
	for (int32 SexIndex = 0; SexIndex < (int32)EWebAnimationSexType::Max; SexIndex++)
	{
		if (Retargeters.IsValidIndex(SexIndex) && Retargeters[SexIndex].IsInitialized())
		{
			UE_LOG(LogTemp, Log, TEXT("Performing FK retargeting for sex %d start..."), SexIndex);
			TArray<float> OutPoseData;
			Retargeters[SexIndex].RetargetMotionCore(PoseData1, OutPoseData, num_frames, num_people, num_joints, num_joints);
			PoseDataBySex[SexIndex] = MoveTemp(OutPoseData);
			UE_LOG(LogTemp, Log, TEXT("Performing FK retargeting for sex %d end..."), SexIndex);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("Skipping retargeting for sex %d: not initialized"), SexIndex);
			PoseDataBySex[SexIndex] = PoseData1; // 未初始化时使用原始数据
		}
	}

	float IntervalTime = 1.0f / FrameRate;

	// 清理旧数据
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		WebAnimSequenceCache.Remove(AnimationName);
	}
	
	TSharedPtr<FVideoGenData> VideoGenData = MakeShareable(new FVideoGenData());
	WebAnimSequenceCache.Add(AnimationName, VideoGenData);
	if (!audioBase64.IsEmpty())
	{
		FBase64::Decode(audioBase64, VideoGenData->Audio);
		// debug 输出文件
		//auto AudioPath = FilePath.Replace(TEXT(".json"), TEXT(".wav"));
		//FFileHelper::SaveArrayToFile(VideoGenData->Audio, *AudioPath);
	}
	VideoGenData->SampleRate = FrameRate;

	// 初始化按性别分组的数据结构
	VideoGenData->CustomAnimDataBySex.SetNum((int32)EWebAnimationSexType::Max);
	VideoGenData->PeopleInitPosBySex.SetNum((int32)EWebAnimationSexType::Max);
	
	VideoGenData->FrameCount = num_frames;
	VideoGenData->Duration = 1.0f * (num_frames - 1) * IntervalTime;
	VideoGenData->NumPeople = num_people;
	VideoGenData->FrameShape = FrameShapeArray;

	// 解析表情动画
	if (!emotionBase64.IsEmpty() && !emotionConfBase64.IsEmpty())
	{
		TArray<int8> EmotionData = DecodeBase64ToInt8Array(emotionBase64);
		TArray<float> EmotionConfData = DecodeBase64ToFloatArray(emotionConfBase64);
		ParseEmoAnimation(VideoGenData, EmotionData, EmotionConfData);
	}
	

	VideoGenData->DominantScore = DominantScore;

	SortDominantScore(VideoGenData);

	// 保存 BlendArray 数据（如果有的话）
	if (BlendArray.Num() > 0)
	{
		VideoGenData->BlendArray = BlendArray;
		UE_LOG(LogTemp, Log, TEXT("CreateAnimation: Saved BlendArray data for %d people"), BlendArray.Num());
	}

	// 记录第一个人物的基准旋转角度（假设人是站着的）
	FRotator FirstBaseRot = FRotator::ZeroRotator;
	// 记录第一个人物的基准位置
	FVector FirstBasePose = FVector::ZeroVector;
	
	// 为每种性别生成一套动画数据
	for (int32 SexIndex = 0; SexIndex < (int32)EWebAnimationSexType::Max; SexIndex++)
	{
		const TArray<float>& PoseData = PoseDataBySex[SexIndex];
		
		// 获取对应性别的骨骼位置数据
		TMap<FString, FVector>* BoneLocationData = BoneLocationDataMap.Find(SexIndex);
		if (BoneLocationData == nullptr)
		{
			UE_LOG(LogTemp, Error, TEXT("BoneLocationData not found for sex %d, skipping"), SexIndex);
			continue;
		}
		
		for (int32 people = 0; people < num_people; people++)
		{
		TSharedPtr<FCustomAnimationData> AnimationData = MakeShareable(new FCustomAnimationData());
		AnimationData->Duration = VideoGenData->Duration;
		AnimationData->bLooping = true;
		AnimationData->BoneTracks.Empty();
		int32 MaxNumberOfKeys = 0;

		float FootOffsetY = 0;
		if (FootOffsetYArray.Num() > 0 && people < FootOffsetYArray.Num())
		{
			FootOffsetY = FootOffsetYArray[people];
		}

		int32 peoplePoseIndex = people * num_frames * num_joints * 3;
		// 为每个骨骼添加轨道并设置关键帧
		for (int32 BoneIndex = 0; BoneIndex < num_joints; BoneIndex++)
		{
			FString BoneNameString = BodyParts[BoneIndex];
			if (BodyParts.IsValidIndex(BoneIndex))
			{
			}
			else
			{
				continue;
			}

			FC7BoneAnimationTrack SpineTrack;
			SpineTrack.BoneName = BoneNameString;

			for (int32 FrameIndex = 0; FrameIndex < num_frames; FrameIndex++)
			{
				FBoneKeyframe Keyframe;
				Keyframe.Time = FrameIndex * IntervalTime;

				// 计算数据索引
				int32 DataIndex = (FrameIndex * num_joints + BoneIndex) * 3 + peoplePoseIndex;

				if (DataIndex + 2 < PoseData.Num())
				{
					// 提取位置和旋转数据
					FVector Position = FVector::ZeroVector;
					if (const FVector* FoundPosition = BoneLocationData->Find(BoneNameString))
					{
						Position = *FoundPosition;
					}

					// FBX右手坐标系的angle-axis数据
					FVector3f FBX_Axis(
						PoseData[DataIndex + 0],
						PoseData[DataIndex + 1],
						PoseData[DataIndex + 2]
					);

					// 获取旋转角（弧度）
					float FBX_AngleRad = FBX_Axis.Length();
					FQuat ResultQuat;

					// 避免除零错误
					if (FBX_AngleRad < SMALL_NUMBER)
					{
						ResultQuat = FQuat::Identity;
					}
					else
					{
						// 归一化轴
						FBX_Axis.Normalize();

						// FBX右手坐标系到UE左手坐标系的转换
						FVector UE_Axis;
						UE_Axis.X = FBX_Axis.X;
						UE_Axis.Y = -FBX_Axis.Y;  // Y轴翻转
						UE_Axis.Z = FBX_Axis.Z;

						float UE_AngleRad = -FBX_AngleRad;  // 角度翻转

						// 在UE坐标系下生成四元数
						ResultQuat = FQuat(UE_Axis, UE_AngleRad);
						ResultQuat.Normalize();
					}

					FVector Scale(
						1,
						1,
						1
					);
					Keyframe.Location = Position;
					Keyframe.Rotation = FRotator(ResultQuat);  // 使用我们计算出的四元数
					Keyframe.Scale = Scale;

					if (people == 0 && FrameIndex == 0 && BoneNameString == "pelvis")
					{
						// 应用 180° 的 Z 轴旋转偏移
						FQuat MeshRotationOffset = FQuat(FVector::UpVector, FMath::DegreesToRadians(180.0f));
						// 转换到世界空间（或角色空间）
						FQuat PelvisWorldRotation = MeshRotationOffset * ResultQuat;
						// 使用 Right 向量计算 Yaw
						FVector RightVector = PelvisWorldRotation.GetRightVector();
						FVector HorizontalRight = FVector(RightVector.X, RightVector.Y, 0.f);
						HorizontalRight.Normalize();
						float CharacterYaw = FMath::Atan2(HorizontalRight.Y, HorizontalRight.X) * (180.f / PI);

						FirstBaseRot = FRotator(0.f, CharacterYaw, 0.f);
						UE_LOG(LogTemp, Log, TEXT("TestCameraMove: FirstBaseYaw %s "),  *FirstBasePose.ToString());
						VideoGenData->FirstBaseRot = FirstBaseRot;
					}
				}
				
				SpineTrack.Keyframes.Add(Keyframe);

			}
			AnimationData->BoneTracks.Add(SpineTrack);
		}
	
		// 处理根节点的位移
		if (transl.Num() >= num_people * num_frames * 3)
		{
			FC7BoneAnimationTrack SpineTrack;
			SpineTrack.BoneName = "root";
			float fbxK = 100;
			
			// 计算当前人物的transl数据起始索引: people * num_frames * 3
			int32 peopleTranslIndex = people * num_frames * 3;
			
			// 提取当前人物第一帧的位移作为基准姿态
			FVector basePose = FVector(
				transl[peopleTranslIndex + 2] * fbxK,
				transl[peopleTranslIndex + 0] * fbxK,
				transl[peopleTranslIndex + 1] * fbxK
			);
			
			// 存储每个人物的第一帧位置（只在第一种性别时设置，因为位置与性别无关）
			if (SexIndex == 0)
			{
				VideoGenData->PeopleInitPosBySex[SexIndex].Add(basePose);
				UE_LOG(LogTemp, Log, TEXT("People %d InitPos: %s"), people, *basePose.ToString());
			}
			else
			{
				// 其他性别复制第一种性别的位置数据
				VideoGenData->PeopleInitPosBySex[SexIndex].Add(basePose);
			}
			
			// 只在第一种性别时设置基准位置
			if (SexIndex == 0)
			{
				// 只在第一个人的第一帧时设置相机基准位置
				// 如果有PeopleSort，使用排序后的第一个人（主导人物）
				bool isFirstPerson = people == 0;
				if (VideoGenData->PeopleSort.Num() > 0)
				{
					isFirstPerson = (people == VideoGenData->PeopleSort[0]);
				}
				
				if (isFirstPerson && FirstBasePose.IsZero())
				{
					FirstBasePose = basePose;
					UE_LOG(LogTemp, Log, TEXT("TestCameraMove: FirstBasePose from people %d, %s"), people, *FirstBasePose.ToString());
				}
			}
		
			for (int32 FrameIndex = 0; FrameIndex < num_frames; FrameIndex++)
			{
				FBoneKeyframe Keyframe;
				Keyframe.Time = FrameIndex * IntervalTime;

				// 计算当前人物当前帧的transl索引
				int TranslIndex = peopleTranslIndex + FrameIndex * 3;
				//从transl里面提取根位移
				FVector Position = FVector(
					transl[TranslIndex + 2] * fbxK,
					transl[TranslIndex + 0] * fbxK,
					transl[TranslIndex + 1] * fbxK
				);
				Position = Position - basePose;

				Position = FVector(Position.Y, Position.X, Position.Z);
				
				//根节点的旋转 固定为0
				FQuat Rotation(
						0,
					0,
					0,
					1
				);
				if (this->DebugAxis.Num() >= 3)
				{
					Position = Position + FVector(this->DebugAxis[0], this->DebugAxis[1], this->DebugAxis[2]);
				}
				if (bFootOffsetY)
				{
					Position = Position + FVector(0, 0, FootOffsetY);
				}
				Keyframe.Location = Position;
				Keyframe.Rotation = FRotator(Rotation);
				Keyframe.Scale = FVector(1,1,1);
				SpineTrack.Keyframes.Add(Keyframe);
			}
			AnimationData->BoneTracks.Add(SpineTrack);
			AnimationData->RootBoneIndex = AnimationData->BoneTracks.Num() - 1;
			}
			VideoGenData->CustomAnimDataBySex[SexIndex].Add(AnimationData);
			UE_LOG(LogTemp, Log, TEXT("KAPI_WebAnimation_ParseAndCacheWebAnimationData: Sex %d, People %d"), SexIndex, people);
		}
	} // end of SexIndex loop

	
	ParseCameraAnimation(Camera_T, Camera_R, VideoGenData, FirstBasePose);

	// 解析valid_mask数据 (int8 array [n,f,3])
	ParseAndProcessValidMask(VideoGenData, validMaskBase64, num_people, num_frames);
	
	UE_LOG(LogTemp, Log, TEXT("KAPI_WebAnimation_ParseAndCacheWebAnimationData: %s %.1f"), *AnimationName, VideoGenData->Duration);
	return VideoGenData->NumPeople;
}


bool UKGWebAnimationManager::ParseCameraAnimation(const TArray<float>& Camera_T, const TArray<float>& Camera_R,
    TSharedPtr<FVideoGenData> VideoGenData, FVector FirstBasePose)
{
    if (VideoGenData->FrameCount != Camera_T.Num() / 3)
    {
        UE_LOG(LogTemp, Error, TEXT("ParseCameraAnimation: Camera_T and VideoGenData must have the same number of frames %d %d"),
            VideoGenData->FrameCount, Camera_T.Num() / 3);
        return false;
    }
    
    if (VideoGenData->FrameCount != Camera_R.Num() / 9)
    {
        UE_LOG(LogTemp, Error, TEXT("ParseCameraAnimation: Camera_R and VideoGenData must have the same number of frames %d %d"),
            VideoGenData->FrameCount, Camera_R.Num() / 9);
        return false;
    }

    UE_LOG(LogTemp, Warning, TEXT("=== ParseCameraAnimation Start ==="));
    float fbxK = 100;
	
	VideoGenData->CameraRotate.Empty();
	VideoGenData->CameraMove.Empty();
	
	for (int32 FrameIndex = 0; FrameIndex < VideoGenData->FrameCount; FrameIndex++)
    {
        int32 TIndex = FrameIndex * 3;
        int32 RIndex = FrameIndex * 9;

        // ---------------------------------------------------------
        // 1. 原始数据读取 (Raw Input)
        // ---------------------------------------------------------
        // Python: camera_R[i_frame]
        // 注意：FMatrix 构造函数是行主序，这里直接填入即可
        FMatrix Mat_Raw;
        Mat_Raw.SetIdentity();
        Mat_Raw.M[0][0] = Camera_R[RIndex + 0]; Mat_Raw.M[0][1] = Camera_R[RIndex + 1]; Mat_Raw.M[0][2] = Camera_R[RIndex + 2];
        Mat_Raw.M[1][0] = Camera_R[RIndex + 3]; Mat_Raw.M[1][1] = Camera_R[RIndex + 4]; Mat_Raw.M[1][2] = Camera_R[RIndex + 5];
        Mat_Raw.M[2][0] = Camera_R[RIndex + 6]; Mat_Raw.M[2][1] = Camera_R[RIndex + 7]; Mat_Raw.M[2][2] = Camera_R[RIndex + 8];

        FVector Vec_Raw(Camera_T[TIndex + 0], Camera_T[TIndex + 1], Camera_T[TIndex + 2]);

    	bool isDebug = this->DebugAxis.Contains(FrameIndex);
        if (isDebug)
        {
            UE_LOG(LogTemp, Warning, TEXT("=== FRAME %d DEBUG (C++) ==="), FrameIndex);
            UE_LOG(LogTemp, Log, TEXT("Raw T: X=%f, Y=%f, Z=%f"), Vec_Raw.X, Vec_Raw.Y, Vec_Raw.Z);
            UE_LOG(LogTemp, Log, TEXT("Raw R (Row 0): %f, %f, %f"), Mat_Raw.M[0][0], Mat_Raw.M[0][1], Mat_Raw.M[0][2]);
            UE_LOG(LogTemp, Log, TEXT("Raw R (Row 1): %f, %f, %f"), Mat_Raw.M[1][0], Mat_Raw.M[1][1], Mat_Raw.M[1][2]);
            UE_LOG(LogTemp, Log, TEXT("Raw R (Row 2): %f, %f, %f"), Mat_Raw.M[2][0], Mat_Raw.M[2][1], Mat_Raw.M[2][2]);
        }


        // ---------------------------------------------------------
        // 2. 复刻 Python 的数学逻辑 (Math Step)
        //    目标：算出在 "Python逻辑空间" 下的最终 t 和 r
        // ---------------------------------------------------------
        
		// Python: r = camera_R[i_frame] -> t = -r.T @ t
		FMatrix Mat_Transposed = Mat_Raw.GetTransposed();

		float temp_x = Mat_Transposed.M[0][0] * Vec_Raw.X + Mat_Transposed.M[0][1] * Vec_Raw.Y + Mat_Transposed.M[0][2] * Vec_Raw.Z;
		float temp_y = Mat_Transposed.M[1][0] * Vec_Raw.X + Mat_Transposed.M[1][1] * Vec_Raw.Y + Mat_Transposed.M[1][2] * Vec_Raw.Z;
		float temp_z = Mat_Transposed.M[2][0] * Vec_Raw.X + Mat_Transposed.M[2][1] * Vec_Raw.Y + Mat_Transposed.M[2][2] * Vec_Raw.Z;

		// 修正：Y分量应该是正的
		FVector Vec_Step1(-temp_x, temp_z, -temp_y);  // 注意这里的符号调整

		// Python: r = r.T @ M_AxisCorrection
		FMatrix Mat_Step1 = Mat_Transposed;
		Mat_Step1.M[0][1] *= -1;
		Mat_Step1.M[1][1] *= -1;
		Mat_Step1.M[2][1] *= -1;
		Mat_Step1.M[0][2] *= -1;
		Mat_Step1.M[1][2] *= -1;
		Mat_Step1.M[2][2] *= -1;

		FQuat Quat_Scipy = FQuat(Mat_Step1);

		Quat_Scipy.X = -Quat_Scipy.X;
		Quat_Scipy.Y = -Quat_Scipy.Y;
		Quat_Scipy.Z = -Quat_Scipy.Z;
    	
		if (isDebug)
		{
			UE_LOG(LogTemp, Log, TEXT("Debug: temp before negation: X=%f, Y=%f, Z=%f"), temp_x, temp_y, temp_z);
			UE_LOG(LogTemp, Log, TEXT("Step 1 T (Calculated): X=%f, Y=%f, Z=%f"), Vec_Step1.X, Vec_Step1.Y, Vec_Step1.Z);
			UE_LOG(LogTemp, Log, TEXT("Step 1 Quat (Scipy xyzw): X=%f, Y=%f, Z=%f, W=%f"), Quat_Scipy.X, Quat_Scipy.Y, Quat_Scipy.Z, Quat_Scipy.W);
		}

		// ---------------------------------------------------------
		// 3. 转换到 Blender 空间 (To Blender Space)
		// ---------------------------------------------------------

		// 位置已经在Step 1中转换了
    	FVector Pos_Blender = Vec_Step1;

        // Python: rotation = mathutils.Quaternion((r_q[3], r_q[0], -r_q[2], r_q[1]))
        // 这里的映射是：Blender(W,X,Y,Z) = Scipy(W,X,-Z,Y)
        FQuat Quat_Blender;
        Quat_Blender.W = Quat_Scipy.W;      // W_b = W_s
        Quat_Blender.X = Quat_Scipy.X;      // X_b = X_s  
        Quat_Blender.Y = -Quat_Scipy.Z;     // Y_b = -Z_s
        Quat_Blender.Z = Quat_Scipy.Y;      // Z_b = Y_s


		// Python: rotation = rotation @ Q_CamCorrection
    	
		//FQuat Quat_CamCorrection(0.70710678f, 0.0f, 0.0f, 0.70710678f);
		//FQuat Quat_Blender_Final = Quat_Blender * Quat_CamCorrection;

		if (isDebug)
		{
			UE_LOG(LogTemp, Log, TEXT("Step 2 Pos (Blender): X=%f, Y=%f, Z=%f"), Pos_Blender.X, Pos_Blender.Y, Pos_Blender.Z);
			//UE_LOG(LogTemp, Log, TEXT("Step 2 Quat (Blender WXYZ): W=%f, X=%f, Y=%f, Z=%f"),
			//	Quat_Blender_Final.W, Quat_Blender_Final.X, Quat_Blender_Final.Y, Quat_Blender_Final.Z);
		}

        // ---------------------------------------------------------
        // 4. 最终映射：Blender 空间 -> UE5 空间 (Coordinate Mapping)
        //    Blender (右手系 Z-up, Y-fwd) -> UE5 (左手系 Z-up, X-fwd)
        // ---------------------------------------------------------
        
        // --- 位移转换 ---
        // Blender X (Right) -> UE Y (Right)
        // Blender Y (Fwd)   -> UE X (Fwd)
        // Blender Z (Up)    -> UE Z (Up)
        FVector Pos_UE(-Pos_Blender.Y, Pos_Blender.X, Pos_Blender.Z);

        FVector FinalPosition = (Pos_UE * fbxK) - FirstBasePose;
        VideoGenData->CameraMove.Add(FinalPosition);

		FRotator Rot_UE = FQuat(Quat_Scipy.Z, -Quat_Scipy.X, -Quat_Scipy.Y, Quat_Scipy.W).Rotator();
    	VideoGenData->CameraRotate.Add(Rot_UE);

		if (isDebug)
		{
    		//打印最终UE信息
    		UE_LOG(LogTemp, Log, TEXT("Step 3 Pos (UE): X=%f, Y=%f, Z=%f"), Pos_UE.X, Pos_UE.Y, Pos_UE.Z);
			UE_LOG(LogTemp, Log, TEXT("Step 3 Rot %s"), *Rot_UE.ToString());
    		UE_LOG(LogTemp, Warning, TEXT("=============================="));
    	}
    }

    UE_LOG(LogTemp, Warning, TEXT("=== ParseCameraAnimation Complete ==="));
    return true;
}


bool UKGWebAnimationManager::ParseEmoAnimation(TSharedPtr<FVideoGenData> VideoGenData,
	const TArray<int8>& RawEmotionArray,
	const TArray<float>& RawEmotionConfArray)
{
	if (RawEmotionArray.IsEmpty() || RawEmotionConfArray.IsEmpty() || RawEmotionArray.Num() != RawEmotionConfArray.Num())
	{
		return false;
	}

	int FrameCount = RawEmotionArray.Num() / VideoGenData->NumPeople;
	// 解析表情动画
	for (int32 peopleIndex = 0; peopleIndex < VideoGenData->NumPeople; peopleIndex++)
	{
		 VideoGenData->EmotionArray.Add(TArray<int32>());
		 VideoGenData->EmotionConfArray.Add(TArray<float>());
		for (int32 FrameIndex = 0; FrameIndex < FrameCount; FrameIndex++)
		{
			int32 DataIndex = FrameCount * peopleIndex + FrameIndex;
			VideoGenData->EmotionArray[peopleIndex].Add(RawEmotionArray[DataIndex]);
			VideoGenData->EmotionConfArray[peopleIndex].Add(RawEmotionConfArray[DataIndex]);
		}
	}
	return true;
}

TSharedPtr<FCustomAnimationData> UKGWebAnimationManager::GetWebAnimSequence(const FString& AnimationName, int32 Index, int32 SexIndex)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid())
		{
			// 检查性别索引是否有效
			if (!VideoGenData->CustomAnimDataBySex.IsValidIndex(SexIndex))
			{
				UE_LOG(LogTemp, Warning, TEXT("[GetWebAnimSequence] %s: Invalid SexIndex %d"), *AnimationName, SexIndex);
				return nullptr;
			}
			
			// 如果有PeopleSort数据且Index在其范围内，使用排序后的索引
			int32 ActualIndex = Index;
			if (VideoGenData->PeopleSort.IsValidIndex(Index))
			{
				ActualIndex = VideoGenData->PeopleSort[Index];
				UE_LOG(LogTemp, Log, TEXT("[GetWebAnimSequence] %s: Using sorted index %d -> %d, Sex %d"), *AnimationName, Index, ActualIndex, SexIndex);
			}
			
			// 检查实际索引是否合法
			if (VideoGenData->CustomAnimDataBySex[SexIndex].IsValidIndex(ActualIndex))
			{
				return VideoGenData->CustomAnimDataBySex[SexIndex][ActualIndex];
			}
		}
	}
	return nullptr;
}

TSharedPtr<FVideoGenData> UKGWebAnimationManager::GetWebAnimData(const FString& AnimationName)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		return WebAnimSequenceCache[AnimationName];
	}
	return nullptr;
}

const TArray<int8>* UKGWebAnimationManager::GetValidMask(const FString& AnimationName, int32 PeopleIndex) const
{
	if (!WebAnimSequenceCache.Contains(AnimationName))
	{
		return nullptr;
	}

	const TSharedPtr<FVideoGenData>& VideoGenData = WebAnimSequenceCache[AnimationName];
	if (!VideoGenData.IsValid())
	{
		return nullptr;
	}

	// 如果有PeopleSort数据，使用排序后的索引
	int32 ActualIndex = PeopleIndex;
	if (VideoGenData->PeopleSort.IsValidIndex(PeopleIndex))
	{
		ActualIndex = VideoGenData->PeopleSort[PeopleIndex];
		UE_LOG(LogTemp, Log, TEXT("[GetValidMask] %s: Using sorted index %d -> %d"), *AnimationName, PeopleIndex, ActualIndex);
	}

	// 检查ValidMask数据是否有效
	if (!VideoGenData->ValidMask.IsValidIndex(ActualIndex))
	{
		UE_LOG(LogTemp, Warning, TEXT("[GetValidMask] %s: Invalid PeopleIndex %d (ActualIndex %d, ValidMask.Num=%d)"),
			*AnimationName, PeopleIndex, ActualIndex, VideoGenData->ValidMask.Num());
		return nullptr;
	}

	return &VideoGenData->ValidMask[ActualIndex];
}

const TArray<float>* UKGWebAnimationManager::GetBlendArray(const FString& AnimationName, int32 PeopleIndex) const
{
	if (!WebAnimSequenceCache.Contains(AnimationName))
	{
		return nullptr;
	}

	const TSharedPtr<FVideoGenData>& VideoGenData = WebAnimSequenceCache[AnimationName];
	if (!VideoGenData.IsValid())
	{
		return nullptr;
	}

	// 如果有PeopleSort数据，使用排序后的索引
	int32 ActualIndex = PeopleIndex;
	if (VideoGenData->PeopleSort.IsValidIndex(PeopleIndex))
	{
		ActualIndex = VideoGenData->PeopleSort[PeopleIndex];
		UE_LOG(LogTemp, Log, TEXT("[GetBlendArray] %s: Using sorted index %d -> %d"), *AnimationName, PeopleIndex, ActualIndex);
	}

	// 检查BlendArray数据是否有效
	if (!VideoGenData->BlendArray.IsValidIndex(ActualIndex))
	{
		UE_LOG(LogTemp, Warning, TEXT("[GetBlendArray] %s: Invalid PeopleIndex %d (ActualIndex %d, BlendArray.Num=%d)"),
			*AnimationName, PeopleIndex, ActualIndex, VideoGenData->BlendArray.Num());
		return nullptr;
	}

	return &VideoGenData->BlendArray[ActualIndex];
}

int32 UKGWebAnimationManager::KAPI_WebAnimation_ParseAndCacheWebAnimationData(const FString& AnimationName, const FString& FilePath)
{
	if (!bIsInitialized)
	{
		return -1;
	}
	
	UE_LOG(LogTemp, Log, TEXT("KAPI_WebAnimation_ParseAndCacheWebAnimationData: %s %s"), *AnimationName, *FilePath);
    int32 Ret = CreateAnimationFromJson(AnimationName, FilePath);
	if (Ret > 0)
	{
		UE_LOG(LogTemp, Log, TEXT("Successfully parsed and cached animation: %s, NumPeople: %d"), *AnimationName, Ret);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to parse and cache animation: %s"), *AnimationName);
	}
	return Ret;
}

int bUseParseAndCacheWebAnimationDataNew = 0;
static FAutoConsoleVariableRef CVarbUseParseAndCacheWebAnimationDataNew(
	TEXT("c7.ai.animnew"),
	bUseParseAndCacheWebAnimationDataNew,
	TEXT("c7.ai.animnew"),
	ECVF_Default);

int bUseParseAndCacheWebAnimationDataNewCpp = 1;
static FAutoConsoleVariableRef CVarbUseParseAndCacheWebAnimationDataNewCpp(
	TEXT("c7.ai.animnewcpp"),
	bUseParseAndCacheWebAnimationDataNewCpp,
	TEXT("c7.ai.animnewcpp"),
	ECVF_Default);

int32 UKGWebAnimationManager::KAPI_WebAnimation_ParseAndCacheWebAnimationDataNew(const FString& AnimationName, const FString& FilePath1)
{
	UE_LOG(LogTemp, Log, TEXT("liubo, AI-ANIM, KAPI_WebAnimation_ParseAndCacheWebAnimationData: %s %s"), *AnimationName, *FilePath1);

	FString FilePath = FilePath1;

	if (bUseParseAndCacheWebAnimationDataNewCpp == 1)
	{
		return KAPI_WebAnimation_ParseAndCacheWebAnimationDataWithProcessor(AnimationName, FilePath1);
	}

#if WITH_EDITOR
	// 临时代码，只在编辑器下起作用，给策划看效果用的。
	// 先处理json内容
	if(bUseParseAndCacheWebAnimationDataNew)
	{
		SCOPED_NAMED_EVENT(KAPI_WebAnimation_ParseAndCacheWebAnimationDataNew, FColor::Red);

		IFileManager& FileManager = IFileManager::Get();
		bool bSucc = false;
		auto OldFolder = FPaths::GetPath(FilePath);
		auto OldJsonName = FPaths::GetCleanFilename(FilePath);
		// 固定叫这个名字		
		// 删掉旧的
		auto AIToolsFolder = FPaths::ConvertRelativePathToFull(FPaths::Combine(FPaths::ProjectDir(), TEXT("../Tools/AI/transl_filter")));
		FString TempFile("c7_data.txt");
		FString TempFileOutput("c7_data_md.txt");
		auto TempFileFullname = FString::Printf(TEXT("%s/%s"), *AIToolsFolder, *TempFile);
		FileManager.Delete(*TempFileFullname, false, true, true);
		FileManager.Copy(*TempFileFullname, *FilePath, true, true);
		{
			FString ExePath = FPaths::Combine(AIToolsFolder, TEXT("c7_proc.bat"));
			FString Parameters;

			FProcHandle ProcessHandle = FPlatformProcess::CreateProc(*ExePath, *Parameters, false, true, true, nullptr, 0, nullptr, nullptr);
			if (ProcessHandle.IsValid())
			{
				FPlatformProcess::WaitForProc(ProcessHandle);

				int32 ReturnCode;
				if (FPlatformProcess::GetProcReturnCode(ProcessHandle, &ReturnCode))
				{
					if (ReturnCode == 0)
					{
						// 取数据
						bSucc = FileManager.FileExists(*TempFileFullname);
						UE_LOG(LogTemp, Log, TEXT("liubo, AI-ANIM, 处理成功, bSucc=%d"), bSucc);
					}
					else
					{
						UE_LOG(LogTemp, Warning, TEXT("liubo, AI-ANIM, 进程返回码：%d"), ReturnCode);
					}
				}
				FPlatformProcess::CloseProc(ProcessHandle);
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("liubo, AI-ANIM, 无法启动外部程序：%s"), *ExePath);
			}
		}


		// 设置新的	
		auto NewFileName = FString::Printf(TEXT("%s/new_%s"), *OldFolder, *OldJsonName);

		if (bSucc)
		{
			FileManager.Delete(*NewFileName, false, true, true);
			FileManager.Copy(*NewFileName, *FString::Printf(TEXT("%s/%s"), *AIToolsFolder, *TempFileOutput), true, true);
			FilePath = NewFileName;

			// 对比数据
			extern void AIAnimCompareData(const FString & OldFile, const FString & NewFile);
			AIAnimCompareData(FilePath1, FilePath);
		}
	}
	else
	{
		UE_LOG(LogTemp, Log, TEXT("liubo, AI-ANIM, Use Old Logic"));
	}
#endif

	UE_LOG(LogTemp, Log, TEXT("liubo, AI-ANIM, AnimPath：%s"), *FilePath);

	int32 Ret = CreateAnimationFromJson(AnimationName, FilePath);
	if (Ret > 0)
	{
		UE_LOG(LogTemp, Log, TEXT("Successfully parsed and cached animation: %s, NumPeople: %d"), *AnimationName, Ret);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to parse and cache animation: %s"), *AnimationName);
	}
	return Ret;
}

int32 UKGWebAnimationManager::KAPI_WebAnimation_ParseAndCacheWebAnimationDataWithProcessor(const FString& AnimationName, const FString& FilePath)
{
	SCOPED_NAMED_EVENT(KAPI_WebAnimation_ParseAndCacheWebAnimationDataWithProcessor, FColor::Red);

	UE_LOG(LogTemp, Log, TEXT("liubo, AI-ANIM, KAPI_WebAnimation_ParseAndCacheWebAnimationDataWithProcessor: %s %s"), *AnimationName, *FilePath);

	int32 Ret = CreateAnimationFromJsonWithProcessor(AnimationName, FilePath);
	return Ret;
}

void UKGWebAnimationManager::KAPI_WebAnimation_PreloadPose(const FString& BasePoseAsset)
{
	if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
	{
		int AssetLoadID = AssetManager->AsyncLoadAsset(
			BasePoseAsset, FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGWebAnimationManager::OnPoseAssetLoaded));
	}
}

void UKGWebAnimationManager::KAPI_WebAnimation_PreloadPoseFromJson(const FString& JsonStr)
{
	DeserializeBoneLocationDataFromJson(JsonStr, 0);
}

void UKGWebAnimationManager::OnPoseAssetLoaded(int InLoadID, UObject* Asset)
{
	UE_LOG(LogTemp, Log, TEXT("UKGWebAnimationManager UDataTable OnPoseAssetLoaded: %s"), *Asset->GetName());
	UDataTable* DataTableAsset = Cast<UDataTable>(Asset);
	if (DataTableAsset == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("DataTableAsset is null"));
		return;
	}

	// 重定向数据加载 - 男女各需要一套 smpl_pose + skel_pose
	FString ContextString;
	
	// 加载男性数据
	const FWebAnimationInitStrData* smplPoseMItem = DataTableAsset->FindRow<FWebAnimationInitStrData>(TEXT("smpl_pose_m"), ContextString);
	const FWebAnimationInitStrData* skelPoseMItem = DataTableAsset->FindRow<FWebAnimationInitStrData>(TEXT("skel_pose_m"), ContextString);
	
	// 加载女性数据
	const FWebAnimationInitStrData* smplPoseFItem = DataTableAsset->FindRow<FWebAnimationInitStrData>(TEXT("smpl_pose_f"), ContextString);
	const FWebAnimationInitStrData* skelPoseFItem = DataTableAsset->FindRow<FWebAnimationInitStrData>(TEXT("skel_pose_f"), ContextString);
	
	// 检查必要数据是否存在
	if (smplPoseMItem == nullptr || skelPoseMItem == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to find smpl_pose_m or skel_pose_m in DataTable"));
		return;
	}
	if (smplPoseFItem == nullptr || skelPoseFItem == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to find smpl_pose_f or skel_pose_f in DataTable"));
		return;
	}
	
	// 设置给外部使用（使用男性数据作为默认）
	extern void AIAnimSetSmplPoseData(const FString & RawData);
	AIAnimSetSmplPoseData(smplPoseMItem->Content);

	// 初始化男女两套重定向器
	Retargeters.SetNum((int32)EWebAnimationSexType::Max);
	
	// 男性重定向器：smpl_pose_m + skel_pose_m
	Retargeters[(int32)EWebAnimationSexType::Male].InitializeFromJson(smplPoseMItem->Content, skelPoseMItem->Content);
	UE_LOG(LogTemp, Log, TEXT("Initialized male retargeter with smpl_pose_m + skel_pose_m"));
	
	// 女性重定向器：smpl_pose_f + skel_pose_f
	Retargeters[(int32)EWebAnimationSexType::Female].InitializeFromJson(smplPoseFItem->Content, skelPoseFItem->Content);
	UE_LOG(LogTemp, Log, TEXT("Initialized female retargeter with smpl_pose_f + skel_pose_f"));

	// 加载基础姿态数据
	const FWebAnimationInitStrData* basePoseMItem = DataTableAsset->FindRow<FWebAnimationInitStrData>(TEXT("base_pose_m"), ContextString);
	const FWebAnimationInitStrData* basePoseFItem = DataTableAsset->FindRow<FWebAnimationInitStrData>(TEXT("base_pose_f"), ContextString);
	if (basePoseMItem == nullptr || basePoseFItem == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to find base_pose_m or base_pose_f in DataTable"));
		return;
	}
	DeserializeBoneLocationDataFromJson(basePoseMItem->Content, 0);
	DeserializeBoneLocationDataFromJson(basePoseFItem->Content, 1);

	// 标记初始化完成
	bIsInitialized = true;
	UE_LOG(LogTemp, Log, TEXT("UKGWebAnimationManager initialization completed"));
}

void UKGWebAnimationManager::KAPI_WebAnimation_SetBodyParts(const TArray<FString>& parts)
{
	BodyParts = parts;
}

void UKGWebAnimationManager::KAPI_WebAnimation_SetBlendFadeTime(float InTime)
{
	BlendFadeTime = InTime;
}

void UKGWebAnimationManager::KAPI_WebAnimation_ClearAllWebAnimationData()
{
	WebAnimSequenceCache.Empty();
}

bool UKGWebAnimationManager::KAPI_WebAnimation_ClearWebAnimationData(const FString& AnimationName)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		WebAnimSequenceCache.Remove(AnimationName);
		return true;
	}
	return false;
}

/// @brief 播放相机动画, 相机位置会根据玩家位置和旋转进行调整
/// @param AnimationName 动画名称
/// @param PlayerPos 玩家位置
/// @param PlayerRot 玩家旋转
/// @return 是否成功
int64 UKGWebAnimationManager::KAPI_WebAnimation_PlayCameraAnimation(const FString& AnimationName, FVector PlayerPos, FRotator PlayerRot,
	float BlendInTime, float BlendOutTime, float PlayRate, bool EnablePivot, FVector PivotOffset)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		if (ACameraManager* CameraManager = Cast<ACameraManager>(UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0)))
		{
			auto VideoGenData = WebAnimSequenceCache[AnimationName];
			if (VideoGenData == nullptr)
			{
				return 0;
			}

			FQuat PlayerQuat = PlayerRot.Quaternion();
			TArray<FVector> CameraMove;
			int DebugCount = 2;
			for (const FVector& Pos : VideoGenData->CameraMove)
			{
    			FVector PosMove = FVector(Pos.X * this->DebugRK.X, Pos.Y * this->DebugRK.Y, Pos.Z * this->DebugRK.Z);
    			
				// 相机位置根据玩家位置和旋转进行调整
				FVector spinPos = PlayerQuat.RotateVector(PosMove);
				CameraMove.Add(PlayerPos + spinPos + this->DebugOffset);
				if (DebugCount-- > 0)
				{
					UE_LOG(LogTemp, Log, TEXT("TestCameraMove: %.2f %s -> %s "), PlayerRot.Yaw,  *Pos.ToString(), *spinPos.ToString());
				}
			}

			DebugCount = 2;
			TArray<FRotator> CameraRotate;
			for (const FRotator& Rot : VideoGenData->CameraRotate)
			{
				// 相机旋转根据玩家旋转进行调整
				FRotator spinRot = Rot;
				spinRot.Yaw += PlayerRot.Yaw;
				spinRot.Roll += this->DebugRot.Roll;
				spinRot.Pitch += this->DebugRot.Pitch;
				spinRot.Yaw += this->DebugRot.Yaw;

				CameraRotate.Add(spinRot);
				if (DebugCount-- > 0)
				{
					UE_LOG(LogTemp, Log, TEXT("TestCameraMove: Rot %s"), *Rot.ToString());
					UE_LOG(LogTemp, Log, TEXT("TestCameraMove: PlayerRot %s"), *PlayerRot.ToString());
					UE_LOG(LogTemp, Log, TEXT("TestCameraMove: spinRot %s"), *spinRot.ToString());
				}
			}
			
			if (EnablePivot)
			{
				TArray<FVector> PivotPoints;
				
				// 获取排序后的第一个玩家（主导人物）的索引
				int32 MainPersonIndex = 0;
				if (VideoGenData->PeopleSort.Num() > 0)
				{
					MainPersonIndex = VideoGenData->PeopleSort[0];
				}
				
				// 从主导人物的CustomAnimData中提取root骨骼动画数据（使用男性数据作为默认）
				const int32 DefaultSexIndex = (int32)EWebAnimationSexType::Male;
				if (VideoGenData->CustomAnimDataBySex.IsValidIndex(DefaultSexIndex) &&
					VideoGenData->CustomAnimDataBySex[DefaultSexIndex].IsValidIndex(MainPersonIndex))
				{
					auto MainPersonAnimData = VideoGenData->CustomAnimDataBySex[DefaultSexIndex][MainPersonIndex];
					if (MainPersonAnimData.IsValid())
					{
						// 直接使用RootBoneIndex获取root骨骼轨道
						if (MainPersonAnimData->RootBoneIndex >= 0 && 
							MainPersonAnimData->BoneTracks.IsValidIndex(MainPersonAnimData->RootBoneIndex))
						{
							const auto& RootBoneTrack = MainPersonAnimData->BoneTracks[MainPersonAnimData->RootBoneIndex];

							// 遍历所有关键帧，生成PivotPoints
							for (const auto& Keyframe : RootBoneTrack.Keyframes)
							{
								FVector WorldRootPos = Keyframe.Location + PivotOffset;
								PivotPoints.Add(PlayerPos + WorldRootPos + this->DebugOffset);
							}
						}
					}
				}
				
				if (PivotPoints.Num() > 0)
				{
					UE_LOG(LogTemp, Log, TEXT("KAPI_WebAnimation_PlayCameraAnimation: Generated %d pivot points from main person (index %d)"), 
						PivotPoints.Num(), MainPersonIndex);
				}
				else
				{
					UE_LOG(LogTemp, Warning, TEXT("KAPI_WebAnimation_PlayCameraAnimation: No pivot points generated, falling back to non-pivot camera move"));
					return 0;
				}
				
				return CameraManager->KCB_Camera_StartCameraAIMoveWithPivot(CameraMove, CameraRotate, PivotPoints,
					VideoGenData->SampleRate, BlendInTime, BlendOutTime, PlayRate);
			}
			return CameraManager->KCB_Camera_StartCameraAIMove(CameraMove, CameraRotate,
				VideoGenData->SampleRate, BlendInTime, BlendOutTime, PlayRate);

			
		}
	}
	return 0;
}

void UKGWebAnimationManager::KAPI_WebAnimation_SetDebugInfo(FVector debugRK, FRotator debugRot, FVector offset, const TArray<int32>& debugAxis)
{
	this->DebugRK = debugRK;
	this->DebugRot = debugRot;
	this->DebugOffset = offset;
	this->DebugAxis = debugAxis;
}


TArray<int32> UKGWebAnimationManager::KAPI_WebAnimation_GetEmotionArray(const FString& AnimationName, int32 PeopleIndex)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid() && VideoGenData->EmotionArray.IsValidIndex(PeopleIndex))
		{
			return VideoGenData->EmotionArray[PeopleIndex];
		}
	}
	return TArray<int32>();
}

FVector UKGWebAnimationManager::KAPI_WebAnimation_GetPeopleInitPos(const FString& AnimationName, int32 PeopleIndex, int32 SexIndex)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid())
		{
			// 检查性别索引是否有效
			if (!VideoGenData->PeopleInitPosBySex.IsValidIndex(SexIndex))
			{
				UE_LOG(LogTemp, Warning, TEXT("KAPI_WebAnimation_GetPeopleInitPos: Invalid SexIndex=%d"), SexIndex);
				return FVector::ZeroVector;
			}
			
			// 如果有PeopleSort，使用排序后的索引
			int32 ActualIndex = PeopleIndex;
			if (VideoGenData->PeopleSort.IsValidIndex(PeopleIndex))
			{
				ActualIndex = VideoGenData->PeopleSort[PeopleIndex];
			}
			
			// 检查实际索引是否有效
			if (VideoGenData->PeopleInitPosBySex[SexIndex].IsValidIndex(ActualIndex))
			{
				FVector InitPos = VideoGenData->PeopleInitPosBySex[SexIndex][ActualIndex];
				UE_LOG(LogTemp, Log, TEXT("KAPI_WebAnimation_GetPeopleInitPos: InitPos=%s, Sex=%d"), *InitPos.ToString(), SexIndex);
				return InitPos;
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("KAPI_WebAnimation_GetPeopleInitPos: ActualIndex=%d is out of range (PeopleInitPosBySex[%d].Num=%d)"),
					ActualIndex, SexIndex, VideoGenData->PeopleInitPosBySex[SexIndex].Num());
			}
		}
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("KAPI_WebAnimation_GetPeopleInitPos: AnimationName=%s not found in cache"), *AnimationName);
	}
	
	return FVector::ZeroVector;
}

TArray<float> UKGWebAnimationManager::KAPI_WebAnimation_GetEmotionConfArray(const FString& AnimationName, int32 PeopleIndex)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid() && VideoGenData->EmotionConfArray.IsValidIndex(PeopleIndex))
		{
			return VideoGenData->EmotionConfArray[PeopleIndex];
		}
	}
	return TArray<float>();
}

TArray<FRotator> UKGWebAnimationManager::KAPI_WebAnimation_GetCameraRotArray(const FString& AnimationName)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid())
		{
			return VideoGenData->CameraRotate;
		}
	}
	return TArray<FRotator>();
}

TArray<FVector> UKGWebAnimationManager::KAPI_WebAnimation_GetCameraPosArray(const FString& AnimationName)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid())
		{
			return VideoGenData->CameraMove;
		}
	}
	return TArray<FVector>();
}

TArray<int32> UKGWebAnimationManager::KAPI_WebAnimation_GetFrameShape(const FString& AnimationName)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid())
		{
			return VideoGenData->FrameShape;
		}
	}
	return TArray<int32>();
}

bool UKGWebAnimationManager::KAPI_GetIsInitialized()
{
	return bIsInitialized;
}

int32 UKGWebAnimationManager::KAPI_WebAnimation_GetPeopleCount(const FString& AnimationName)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid())
		{
			return VideoGenData->NumPeople;
		}
	}
	return 0;
}


float UKGWebAnimationManager::KAPI_WebAnimation_GetDuration(const FString& AnimationName)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid())
		{
			return VideoGenData->Duration;
		}
	}
	return 0;
}

float UKGWebAnimationManager::KAPI_WebAnimation_GetSampleRate(const FString& AnimationName)
{
	if (WebAnimSequenceCache.Contains(AnimationName))
	{
		auto VideoGenData = WebAnimSequenceCache[AnimationName];
		if (VideoGenData.IsValid())
		{
			return VideoGenData->SampleRate;
		}
	}
	return 0;
}

bool UKGWebAnimationManager::KAPI_WebAnimation_SetPeopleSortWeight(const FString& ItemName, float Weight)
{
	if (Weight < 0.0f || Weight > 1.0f)
	{
		UE_LOG(LogTemp, Warning, TEXT("[KAPI_WebAnimation_SetPeopleSortWeight] Invalid weight %.2f for %s (should be 0-1)"), Weight, *ItemName);
		return false;
	}

	PeopleSortWeights.Add(ItemName, Weight);
	UE_LOG(LogTemp, Log, TEXT("[KAPI_WebAnimation_SetPeopleSortWeight] Set weight for %s = %.2f"), *ItemName, Weight);
	return true;
}

bool UKGWebAnimationManager::SortDominantScore(TSharedPtr<FVideoGenData> VideoGenData)
{
	if (!VideoGenData.IsValid())
	{
		UE_LOG(LogTemp, Warning, TEXT("[SortDominantScore] VideoGenData is invalid"));
		return false;
	}

	// 获取人数
	int32 NumPeople = VideoGenData->NumPeople;
	if (NumPeople <= 1)
	{
		UE_LOG(LogTemp, Log, TEXT("[SortDominantScore] NumPeople <= 1, skip sorting"));
		return false;
	}

	// 检查DominantScore数据
	if (VideoGenData->DominantScore.Num() == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SortDominantScore] DominantScore is empty"));
		return false;
	}

	// 存储每个人的索引和总分
	struct FPeopleScore
	{
		int32 Index;
		float Score;
	};

	TArray<FPeopleScore> PeopleScores;
	PeopleScores.Reserve(NumPeople);

	// 计算每个人的加权总分
	for (int32 i = 0; i < NumPeople; ++i)
	{
		float TotalScore = 0.0f;

		// 遍历所有配置的权重维度
		for (const auto& WeightPair : PeopleSortWeights)
		{
			const FString& DimensionName = WeightPair.Key;
			const float Weight = WeightPair.Value;

			const TArray<float>* ScoreArray = VideoGenData->DominantScore.Find(DimensionName);
			if (ScoreArray && ScoreArray->IsValidIndex(i))
			{
				TotalScore += (*ScoreArray)[i] * Weight;
			}
		}

		// 存储人物索引和总分
		PeopleScores.Add({i, TotalScore});
	}

	// 按总分降序排序
	PeopleScores.Sort([](const FPeopleScore& A, const FPeopleScore& B) {
		return A.Score > B.Score;
	});

	// 提取排序后的人物索引
	TArray<int32> PeopleSort;
	PeopleSort.Reserve(NumPeople);
	for (const FPeopleScore& Item : PeopleScores)
	{
		PeopleSort.Add(Item.Index);
	}

	// 设置PeopleSort
	VideoGenData->PeopleSort = PeopleSort;

	// 输出权重信息
	FString WeightInfo;
	for (const auto& WeightPair : PeopleSortWeights)
	{
		if (!WeightInfo.IsEmpty())
		{
			WeightInfo += TEXT(", ");
		}
		WeightInfo += FString::Printf(TEXT("%s:%.2f"), *WeightPair.Key, WeightPair.Value);
	}

	UE_LOG(LogTemp, Log, TEXT("[SortDominantScore] Sorted %d people with weights (%s)"), NumPeople, *WeightInfo);

	return true;
}

void UKGWebAnimationManager::InterpolateAnimationData(TSharedPtr<FVideoGenData> VideoGenData)
{
	if (!VideoGenData.IsValid() || VideoGenData->ValidMask.Num() == 0)
	{
		return;
	}

	const int32 NumPeople = VideoGenData->NumPeople;
	const int32 NumFrames = VideoGenData->FrameCount;
	const int32 NumSex = VideoGenData->CustomAnimDataBySex.Num();

	// 预分配内存，避免多次分配
	TArray<int32> ValidIndices;
	ValidIndices.Reserve(NumFrames);

	for (int32 PersonIndex = 0; PersonIndex < NumPeople; ++PersonIndex)
	{
		if (!VideoGenData->ValidMask.IsValidIndex(PersonIndex)) continue;

		const TArray<int8>& PersonMask = VideoGenData->ValidMask[PersonIndex];

		// 复用数组，避免重复分配
		ValidIndices.Reset();

		// 1. 找出有效帧索引
		const int32 MaskNum = PersonMask.Num();
		for (int32 f = 0; f < NumFrames; ++f)
		{
			const int32 MaskIdx = f * 3;
			if (MaskIdx < MaskNum && PersonMask[MaskIdx] > 0)
			{
				ValidIndices.Add(f);
			}
		}

		if (ValidIndices.Num() == 0) continue;

		// 缓存边界值
		const int32 FirstValid = ValidIndices[0];
		const int32 LastValid = ValidIndices.Last();
		const int32 ValidCount = ValidIndices.Num();

		// 2. 处理所有性别版本
		for (int32 SexIndex = 0; SexIndex < NumSex; ++SexIndex)
		{
			auto& SexData = VideoGenData->CustomAnimDataBySex[SexIndex];
			if (!SexData.IsValidIndex(PersonIndex)) continue;

			TSharedPtr<FCustomAnimationData>& AnimData = SexData[PersonIndex];
			if (!AnimData.IsValid()) continue;

			for (FC7BoneAnimationTrack& Track : AnimData->BoneTracks)
			{
				TArray<FBoneKeyframe>& Keyframes = Track.Keyframes;
				if (Keyframes.Num() < NumFrames) continue;

				// Case A: Leading Gaps - 复制第一个有效帧
				if (FirstValid > 0)
				{
					const FBoneKeyframe& FirstFrame = Keyframes[FirstValid];
					for (int32 f = 0; f < FirstValid; ++f)
					{
						Keyframes[f].Location = FirstFrame.Location;
						Keyframes[f].Rotation = FirstFrame.Rotation;
					}
				}

				// Case B: Middle Gaps - 预计算倒数避免重复除法
				for (int32 i = 0; i < ValidCount - 1; ++i)
				{
					const int32 p = ValidIndices[i];
					const int32 q = ValidIndices[i + 1];
					const int32 Gap = q - p;

					if (Gap > 1)
					{
						const FVector& PosP = Keyframes[p].Location;
						const FVector& PosQ = Keyframes[q].Location;
						const FQuat QuatP = Keyframes[p].Rotation.Quaternion();
						const FQuat QuatQ = Keyframes[q].Rotation.Quaternion();

						// 预计算倒数，避免循环内重复除法
						const float InvGap = 1.0f / static_cast<float>(Gap);

						for (int32 m = p + 1; m < q; ++m)
						{
							const float Alpha = static_cast<float>(m - p) * InvGap;
							Keyframes[m].Location = FMath::Lerp(PosP, PosQ, Alpha);
							// 使用 Slerp 保证旋转过渡最平滑
							Keyframes[m].Rotation = FQuat::Slerp(QuatP, QuatQ, Alpha).Rotator();
						}
					}
				}

				// Case C: Trailing Gaps
				if (LastValid < NumFrames - 1)
				{
					const FBoneKeyframe& LastFrame = Keyframes[LastValid];
					for (int32 f = LastValid + 1; f < NumFrames; ++f)
					{
						Keyframes[f].Location = LastFrame.Location;
						Keyframes[f].Rotation = LastFrame.Rotation;
					}
				}
			}
		}
	}
}

int32 UKGWebAnimationManager::CalculateLastValidFrameIndices(TSharedPtr<FVideoGenData> VideoGenData, int32 NumFrames)
{
	if (!VideoGenData.IsValid() || VideoGenData->ValidMask.Num() == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CalculateLastValidFrameIndices] Invalid VideoGenData or empty ValidMask"));
		return -1;
	}
	
	int32 NumPeople = VideoGenData->ValidMask.Num();
	int32 MaxLastValidFrame = -1;
	
	// 遍历每个人物
	for (int32 PersonIndex = 0; PersonIndex < NumPeople; PersonIndex++)
	{
		const TArray<int8>& PersonMask = VideoGenData->ValidMask[PersonIndex];
		int32 LastValidIndex = -1;
		
		// 从最后一帧往前查找
		for (int32 FrameIndex = NumFrames - 1; FrameIndex >= 0; FrameIndex--)
		{
			// 每帧有3个值: body/left_hand/right_hand
			int32 BaseIndex = FrameIndex * 3;
			// 检查这一帧的任意一个部位是否可信 (大于0)
			if (BaseIndex + 2 < PersonMask.Num())
			{
				int8 BodyValid = PersonMask[BaseIndex + 0];
				// 只要身体不可信 就是不可信
				if (BodyValid > 0 )
				{
					LastValidIndex = FrameIndex;
					break;
				}
			}
		}
		
		// 更新最大的最后可信帧索引
		if (LastValidIndex > MaxLastValidFrame)
		{
			MaxLastValidFrame = LastValidIndex;
		}
		
		UE_LOG(LogTemp, Log, TEXT("[CalculateLastValidFrameIndices] Person %d last valid frame: %d"), PersonIndex, LastValidIndex);
	}
	
	UE_LOG(LogTemp, Log, TEXT("[CalculateLastValidFrameIndices] Max last valid frame across all people: %d"), MaxLastValidFrame);
	return MaxLastValidFrame;
}

bool UKGWebAnimationManager::TrimVideoGenDataToFrame(TSharedPtr<FVideoGenData> VideoGenData, int32 EndFrame)
{
	if (!VideoGenData.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("[TrimVideoGenDataToFrame] Invalid VideoGenData"));
		return false;
	}
	
	if (EndFrame < 0 || EndFrame >= VideoGenData->FrameCount)
	{
		UE_LOG(LogTemp, Error, TEXT("[TrimVideoGenDataToFrame] Invalid EndFrame: %d (total frames: %d)"), EndFrame, VideoGenData->FrameCount);
		return false;
	}
	
	// 计算新的帧数（从0到EndFrame，包含）
	int32 NewFrameCount = EndFrame + 1;
	float NewDuration = NewFrameCount / VideoGenData->SampleRate;
	
	UE_LOG(LogTemp, Log, TEXT("[TrimVideoGenDataToFrame] Trimming from %d frames to %d frames (duration: %.2f -> %.2f)"), 
		VideoGenData->FrameCount, NewFrameCount, VideoGenData->Duration, NewDuration);
	
	// 1. 裁剪骨骼动画数据 (CustomAnimDataBySex)
	for (int32 SexIndex = 0; SexIndex < VideoGenData->CustomAnimDataBySex.Num(); SexIndex++)
	{
		for (int32 PersonIndex = 0; PersonIndex < VideoGenData->CustomAnimDataBySex[SexIndex].Num(); PersonIndex++)
		{
			TSharedPtr<FCustomAnimationData> AnimData = VideoGenData->CustomAnimDataBySex[SexIndex][PersonIndex];
			if (!AnimData.IsValid())
			{
				continue;
			}
			
			// 遍历每个骨骼轨道
			for (FC7BoneAnimationTrack& BoneTrack : AnimData->BoneTracks)
			{
				if (BoneTrack.Keyframes.Num() > NewFrameCount)
				{
					// 裁剪关键帧，保留[0, EndFrame]
					BoneTrack.Keyframes.SetNum(NewFrameCount);
				}
			}
			
			// 更新动画时长
			AnimData->Duration = NewDuration;
		}
	}
	
	// 2. 裁剪相机动画 (CameraMove & CameraRotate)
	if (VideoGenData->CameraMove.Num() > NewFrameCount)
	{
		VideoGenData->CameraMove.SetNum(NewFrameCount);
	}
	if (VideoGenData->CameraRotate.Num() > NewFrameCount)
	{
		VideoGenData->CameraRotate.SetNum(NewFrameCount);
	}
	
	// 3. 裁剪表情数据 (EmotionArray & EmotionConfArray)
	// emotion和emotion_conf的维度是[n, f/fps]，即每秒一个值，不是每帧
	int32 NewEmotionCount = FMath::CeilToInt(NewDuration); // 向上取整，确保覆盖所有时间
	for (int32 PersonIndex = 0; PersonIndex < VideoGenData->EmotionArray.Num(); PersonIndex++)
	{
		if (VideoGenData->EmotionArray[PersonIndex].Num() > NewEmotionCount)
		{
			VideoGenData->EmotionArray[PersonIndex].SetNum(NewEmotionCount);
		}
	}
	for (int32 PersonIndex = 0; PersonIndex < VideoGenData->EmotionConfArray.Num(); PersonIndex++)
	{
		if (VideoGenData->EmotionConfArray[PersonIndex].Num() > NewEmotionCount)
		{
			VideoGenData->EmotionConfArray[PersonIndex].SetNum(NewEmotionCount);
		}
	}
	
	// 4. 裁剪ValidMask数据 [n,f,3]
	for (int32 PersonIndex = 0; PersonIndex < VideoGenData->ValidMask.Num(); PersonIndex++)
	{
		TArray<int8>& PersonMask = VideoGenData->ValidMask[PersonIndex];
		int32 NewMaskSize = NewFrameCount * 3; // 每帧有3个值
		if (PersonMask.Num() > NewMaskSize)
		{
			PersonMask.SetNum(NewMaskSize);
		}
	}
	
	// 5. 更新元数据
	VideoGenData->FrameCount = NewFrameCount;
	VideoGenData->Duration = NewDuration;
	
	UE_LOG(LogTemp, Log, TEXT("[TrimVideoGenDataToFrame] Successfully trimmed video data to %d frames"), NewFrameCount);
	return true;
}

bool UKGWebAnimationManager::ParseAndProcessValidMask(TSharedPtr<FVideoGenData> VideoGenData, const FString& ValidMaskBase64, int32 NumPeople, int32 NumFrames)
{
	if (ValidMaskBase64.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("[ParseAndProcessValidMask] ValidMask data is empty"));
		return false;
	}
	
	if (!VideoGenData.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("[ParseAndProcessValidMask] Invalid VideoGenData"));
		return false;
	}
	
	// 解码Base64数据
	TArray<int8> ValidMaskData = DecodeBase64ToInt8Array(ValidMaskBase64);
	
	// 验证数据大小: num_people * num_frames * 3
	int32 ExpectedSize = NumPeople * NumFrames * 3;
	if (ValidMaskData.Num() != ExpectedSize)
	{
		UE_LOG(LogTemp, Warning, TEXT("[ParseAndProcessValidMask] Size mismatch: expected %d, got %d"), 
			ExpectedSize, ValidMaskData.Num());
		return false;
	}
	
	UE_LOG(LogTemp, Log, TEXT("[ParseAndProcessValidMask] Parsed valid_mask: %d values (num_people=%d, num_frames=%d)"), 
		ValidMaskData.Num(), NumPeople, NumFrames);
	
	// 将一维数组按人物分割成二维数组
	VideoGenData->ValidMask.Empty();
	VideoGenData->ValidMask.Reserve(NumPeople);
	
	int32 ValuesPerPerson = NumFrames * 3;
	for (int32 i = 0; i < NumPeople; i++)
	{
		TArray<int8> PersonValidMask;
		PersonValidMask.Reserve(ValuesPerPerson);
		
		for (int32 j = 0; j < ValuesPerPerson; j++)
		{
			PersonValidMask.Add(ValidMaskData[i * ValuesPerPerson + j]);
		}
		
		VideoGenData->ValidMask.Add(PersonValidMask);
	}
	
	// 在修剪和进一步处理之前，先进行插值修复
	InterpolateAnimationData(VideoGenData);

	// 计算所有人物中最后一个可信帧的最大索引
	int32 MaxLastValidFrame = CalculateLastValidFrameIndices(VideoGenData, NumFrames);
	UE_LOG(LogTemp, Log, TEXT("[ParseAndProcessValidMask] Max last valid frame across all people: %d/%d"), 
		MaxLastValidFrame, NumFrames);
	
	// 如果存在有效帧，修剪视频数据到最后可信帧
	if (MaxLastValidFrame >= 0)
	{
		return TrimVideoGenDataToFrame(VideoGenData, MaxLastValidFrame);
	}
	
	UE_LOG(LogTemp, Warning, TEXT("[ParseAndProcessValidMask] No valid frames found, video data not trimmed"));
	return true; // 解析成功，但没有有效帧
}


int32 UKGWebAnimationManager::CreateAnimationFromJsonWithProcessor(const FString& AnimationName, const FString& FilePath)
{
	SCOPED_NAMED_EVENT(CreateAnimationFromJsonWithProcessor, FColor::Red);

	FString JsonString;
	if (!FFileHelper::LoadFileToString(JsonString, *FilePath))
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to load JSON file: %s"), *FilePath);
		return -1;
	}

	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);

	if (!FJsonSerializer::Deserialize(Reader, JsonObject) || !JsonObject.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to parse JSON"));
		return -1;
	}

	float FrameRate = 15;
	int num_people = 0;
	int num_joints = 52;
	int num_frames = 0;
	FString poseBase64;
	FString translBase64;
	FString camera_TBase64;
	FString camera_RBase64;
	FString audioBase64;
	FString emotionBase64;
	FString emotionConfBase64;
	FString validMaskBase64;
	const TArray<TSharedPtr<FJsonValue>>* foot_offset = nullptr;
	TArray<float> FootOffsetYArray;

	//如果存在 result 字段，直接使用 result 字段
	if (JsonObject->HasField(TEXT("result")))
	{
		TSharedPtr<FJsonObject> ResultObject = JsonObject->GetObjectField(TEXT("result"));
		if (ResultObject.IsValid())
		{
			JsonObject = ResultObject;
		}
	}

	// 解析JSON数据
	JsonObject->TryGetNumberField(TEXT("fps"), FrameRate);
	JsonObject->TryGetNumberField(TEXT("num_people"), num_people);
	JsonObject->TryGetNumberField(TEXT("num_frames"), num_frames);
	JsonObject->TryGetStringField(TEXT("pose"), poseBase64);
	JsonObject->TryGetStringField(TEXT("transl"), translBase64);
	JsonObject->TryGetStringField(TEXT("camera_T"), camera_TBase64);
	JsonObject->TryGetStringField(TEXT("camera_R"), camera_RBase64);
	JsonObject->TryGetStringField(TEXT("audio_wave"), audioBase64);
	JsonObject->TryGetStringField(TEXT("emotion"), emotionBase64);
	JsonObject->TryGetStringField(TEXT("emotion_conf"), emotionConfBase64);
	JsonObject->TryGetStringField(TEXT("valid_mask"), validMaskBase64);


	// 解析 frame_shape
	TArray<int32> FrameShapeArray;
	const TArray<TSharedPtr<FJsonValue>>* FrameShapeValues = nullptr;
	if (JsonObject->TryGetArrayField(TEXT("frame_shape"), FrameShapeValues))
	{
		for (const TSharedPtr<FJsonValue>& Value : *FrameShapeValues)
		{
			FrameShapeArray.Add(static_cast<int32>(Value->AsNumber()));
		}
	}

	
	// 解析 dominant_score
	TMap<FString, TArray<float>> DominantScore;
	if (JsonObject->HasField(TEXT("dominant_score")))
	{
		const TSharedPtr<FJsonObject>* DominantScoreObject;
		if (JsonObject->TryGetObjectField(TEXT("dominant_score"), DominantScoreObject))
		{
			for (const auto& Pair : (*DominantScoreObject)->Values)
			{
				const FString& Key = Pair.Key;
				const TArray<TSharedPtr<FJsonValue>>* ValueArray;
				if ((*DominantScoreObject)->TryGetArrayField(Key, ValueArray))
				{
					TArray<float> FloatArray;
					FloatArray.Reserve(ValueArray->Num());
					for (const TSharedPtr<FJsonValue>& Value : *ValueArray)
					{
						FloatArray.Add(Value->AsNumber());
					}
					DominantScore.Add(Key, FloatArray);
					UE_LOG(LogTemp, Log, TEXT("Parsed dominant_score[%s]: %d values"), *Key, FloatArray.Num());
				}
			}
		}
	}

	UE_LOG(LogTemp, Log, TEXT("CreateAnimationFromJson: fps = %.1f num_people = %d, num_joints = %d, num_frames = %d"),
		FrameRate, num_people, num_joints, num_frames);


	TArray<float> Camera_T = DecodeBase64ToFloatArray(camera_TBase64);
	TArray<float> Camera_R = DecodeBase64ToFloatArray(camera_RBase64);

	TArray<float> PoseData = DecodeBase64ToFloatArray(poseBase64);
	TArray<float> transl = DecodeBase64ToFloatArray(translBase64);


	// 新的流程
	{
		// 放到game线程即可
		auto Mgr = MakeAIAnimProcessorManager();

		// 以下，放到异步线程中
		// 一堆数据
		auto& Context = Mgr->Context;
		Context.AnimationName = AnimationName;
		Context.Camera_T = std::move(Camera_T);
		Context.Camera_R = std::move(Camera_R);
		Context.PoseData = std::move(PoseData);
		Context.transl = std::move(transl);
		Context.FrameRate = std::move(FrameRate);
		Context.num_people = num_people;
		Context.num_joints = num_joints;
		Context.num_frames = num_frames;
		Context.audioBase64 = std::move(audioBase64);
		Context.emotionBase64 = std::move(emotionBase64);
		Context.emotionConfBase64 = std::move(emotionConfBase64);
		Context.validMaskBase64 = std::move(validMaskBase64);
		Context.DominantScore = std::move(DominantScore);
		Context.FrameShapeArray = std::move(FrameShapeArray);
		Context.BlendFadeTime = BlendFadeTime;

		// 一堆处理器
		{
			Mgr->AddProcessor(MakeShared<FBlendArrayGenerator>());
			Mgr->AddProcessor(MakeShared<FFloatingFootProcessor>());
		}

		// 干活
		ENamedThreads::Type ThreadId = ENamedThreads::Type(ProcessorManagerThreadId);

		TWeakObjectPtr<UKGWebAnimationManager> WeakObjPtr(this);
		AsyncTask(ThreadId, [WeakObjPtr, Mgr]()
			{
				// 多线程干活
				if (Mgr.Get())
				{
					Mgr->ThreadWork();
				}

				// 主线程通知干完了
				AsyncTask(ENamedThreads::GameThread, [WeakObjPtr, Mgr]()
					{
						if (WeakObjPtr.IsValid() && Mgr.Get())
						{
							// 干完了
							WeakObjPtr->OnProcessorManagerDone(Mgr);
						}
					});
			});
	}

	// 如果是异步的，这里没数据的
	auto Ptr = WebAnimSequenceCache.Find(AnimationName);
	if (Ptr != nullptr && Ptr->Get())
	{
		return Ptr->Get()->NumPeople;
	}

	return 0;
}

TSharedPtr<FAIAnimProcessorManager> UKGWebAnimationManager::MakeAIAnimProcessorManager()
{
	auto Mgr = MakeShared<FAIAnimProcessorManager>();
	AIAnimProcessorManagerList.Add(Mgr);
	return Mgr;
}

void UKGWebAnimationManager::OnProcessorManagerDone(TSharedPtr<FAIAnimProcessorManager> Mgr)
{
	if (!Mgr.Get())
	{
		return;
	}
	check(IsInGameThread());

	// 这里是游戏线程
	const auto& Context = Mgr->Context;
	FString Anim = Context.AnimationName;

	CreateAnimation(Context.AnimationName,
		Context.Camera_T, Context.Camera_R, Context.PoseData, Context.transl,
		Context.FrameRate, Context.num_frames, Context.num_people, Context.num_joints,
		Context.audioBase64, Context.emotionBase64, Context.emotionConfBase64, Context.validMaskBase64,
		Context.DominantScore, Context.FootOffsetYArray, Context.bFootOffsetY, Context.FrameShapeArray,
		Context.BlendArray);

	// 清理
	AIAnimProcessorManagerList.Remove(Mgr);

	OnAnimCreated(Anim);
}
void UKGWebAnimationManager::OnAnimCreated(const FString& Anim)
{
	check(IsInGameThread());

	auto Ptr = WebAnimSequenceCache.Find(Anim);
	int People = 0;
	if (Ptr != nullptr && Ptr->Get())
	{
		People = Ptr->Get()->NumPeople;
	}
	CallLuaFunction("KCB_OnAddOneAnim", Anim, People);
}


void FBlendArrayGenerator::ThreadWork(FAIAnimProcessorContext& Context)
{
	SCOPED_NAMED_EVENT(FBlendArrayGenerator_ThreadWork, FColor::Green);

	// 解码 ValidMask 数据
	if (Context.validMaskBase64.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("[FBlendArrayGenerator] ValidMask data is empty, skipping BlendArray generation"));
		return;
	}

	TArray<uint8> BinaryData;
	FBase64::Decode(Context.validMaskBase64, BinaryData);

	int32 ExpectedSize = Context.num_people * Context.num_frames * 3;
	if (BinaryData.Num() != ExpectedSize)
	{
		UE_LOG(LogTemp, Error, TEXT("[FBlendArrayGenerator] ValidMask size mismatch: expected %d, got %d"),
			ExpectedSize, BinaryData.Num());
		return;
	}

	const int8* ValidMaskData = reinterpret_cast<const int8*>(BinaryData.GetData());

	// 计算 Fade 帧数（基于 BlendFadeTime 和 FrameRate）
	int32 FadeFrames = FMath::CeilToInt(Context.BlendFadeTime * Context.FrameRate);
	if (FadeFrames < 1)
	{
		FadeFrames = 1;
	}

	UE_LOG(LogTemp, Log, TEXT("[FBlendArrayGenerator] Processing BlendArray: people=%d, frames=%d, fade_time=%.2fs, fade_frames=%d"),
		Context.num_people, Context.num_frames, Context.BlendFadeTime, FadeFrames);

	// 初始化 BlendArray
	Context.BlendArray.Empty();
	Context.BlendArray.SetNum(Context.num_people);

	// 为每个人物生成 BlendArray
	for (int32 PeopleIndex = 0; PeopleIndex < Context.num_people; PeopleIndex++)
	{
		TArray<float>& PersonBlendArray = Context.BlendArray[PeopleIndex];
		PersonBlendArray.SetNum(Context.num_frames);

		int32 PeopleValidMaskOffset = PeopleIndex * Context.num_frames * 3;

		// 第一遍：直接根据 ValidMask 设置基础值
		for (int32 FrameIndex = 0; FrameIndex < Context.num_frames; FrameIndex++)
		{
			int32 ValidMaskIndex = PeopleValidMaskOffset + FrameIndex * 3;
			int8 BodyValid = ValidMaskData[ValidMaskIndex + 0]; // 只考虑身体部分

			PersonBlendArray[FrameIndex] = (BodyValid > 0) ? 1.0f : 0.0f;
		}

		// 第二遍：在边界处应用线性衰减
		for (int32 FrameIndex = 0; FrameIndex < Context.num_frames; FrameIndex++)
		{
			// 如果当前帧是无效的（0.0），检查前后是否有有效帧，应用衰减
			if (PersonBlendArray[FrameIndex] < 0.5f) // 无效帧
			{
				// 向前查找最近的有效帧（必须是原始有效帧 1.0）
				int32 PrevValidFrame = -1;
				for (int32 i = FrameIndex - 1; i >= 0 && i >= FrameIndex - FadeFrames; i--)
				{
					if (PersonBlendArray[i] > 0.99f)
					{
						PrevValidFrame = i;
						break;
					}
				}

				// 向后查找最近的有效帧（必须是原始有效帧 1.0）
				int32 NextValidFrame = -1;
				for (int32 i = FrameIndex + 1; i < Context.num_frames && i <= FrameIndex + FadeFrames; i++)
				{
					if (PersonBlendArray[i] > 0.99f)
					{
						NextValidFrame = i;
						break;
					}
				}

				// 如果前面有有效帧，计算衰减
				if (PrevValidFrame >= 0)
				{
					int32 Distance = FrameIndex - PrevValidFrame;
					if (Distance <= FadeFrames)
					{
						float Alpha = 1.0f - (float)Distance / (float)FadeFrames;
						PersonBlendArray[FrameIndex] = FMath::Max(PersonBlendArray[FrameIndex], Alpha);
					}
				}

				// 如果后面有有效帧，计算衰减（取较大值）
				if (NextValidFrame >= 0)
				{
					int32 Distance = NextValidFrame - FrameIndex;
					if (Distance <= FadeFrames)
					{
						float Alpha = 1.0f - (float)Distance / (float)FadeFrames;
						PersonBlendArray[FrameIndex] = FMath::Max(PersonBlendArray[FrameIndex], Alpha);
					}
				}
			}
		}

		// 统计信息
		int32 FullBlendCount = 0;
		int32 ZeroBlendCount = 0;
		int32 PartialBlendCount = 0;

		for (float BlendValue : PersonBlendArray)
		{
			if (BlendValue >= 1.0f)
				FullBlendCount++;
			else if (BlendValue <= 0.0f)
				ZeroBlendCount++;
			else
				PartialBlendCount++;
		}

		UE_LOG(LogTemp, Log, TEXT("[FBlendArrayGenerator] Person %d: Full=1.0(%d), Zero=0.0(%d), Partial(%d)"),
			PeopleIndex, FullBlendCount, ZeroBlendCount, PartialBlendCount);
	}

	UE_LOG(LogTemp, Log, TEXT("[FBlendArrayGenerator] BlendArray generation completed for %d people"), Context.num_people);
}
