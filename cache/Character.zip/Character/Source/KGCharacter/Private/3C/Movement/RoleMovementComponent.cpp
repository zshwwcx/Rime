

#include "3C/Movement/RoleMovementComponent.h"
#include "Engine/DemoNetDriver.h"
#include "Engine/ScopedMovementUpdate.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameFramework/Character.h"

#include "Components/BoxComponent.h"
#include "Components/SphereComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Navigation/PathFollowingComponent.h"
#include "NavigationSystem.h"

#include "DoraSDK.h"
#include "3C/SyncProtocol/NetSyncManager.h"
#include "Misc/KGGameInstanceBase.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/C7RootMotionSource.h"
#include "3C/Movement/RMFunctionLibrary.h"
#include "Manager/KGObjectActorManager.h"

#include "Animation/AnimInstance.h"
#include "3C/Animation/CarrierAnimInstance.h"

#include "Kismet/KismetMathLibrary.h"
#include "Misc/MathFormula.h"

#if WITH_EDITOR
#include "DrawDebugHelpers.h"
#endif

// New Feature: Movement Pipeline @sunya 20231220
#include "AkComponent.h"
#include "Manager/KGAkAudioManager.h"
#include "3C/Character/BriefCharacter.h"
#include "Logging/LogMacros.h"
#include "3C/Core/KGUEActorManager.h"
#include "Manager/KGCppAssetManager.h"
#include "Manager/KGPlatformScalabilitySettings.h"
#include "3C/Util/KGUtils.h"
#include "PCGSplineComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "Managers/KGDataCacheManager.h"

DEFINE_LOG_CATEGORY_STATIC(LogRoleMovement, Log, All);
DECLARE_CYCLE_STAT(TEXT("Char PhysWalkingWithVelocity"), STAT_CharPhysWalkingWithVelocity, STATGROUP_Character);
DECLARE_CYCLE_STAT(TEXT("Char PhysFallingWithVelocity"), STAT_CharPhysFallingWithVelocity, STATGROUP_Character);

// Defines for build configs
#if DO_CHECK && !UE_BUILD_SHIPPING // Disable even if checks in shipping are enabled.
#define devCode( Code )		checkCode( Code )
#else
#define devCode(...)
#endif
// New Feature: END

UE_DISABLE_OPTIMIZATION_SHIP


namespace CharacterMovementCVars_C7
{
	static int32 DisplayNetMoveSimulatedCorrections = 0;
	FAutoConsoleVariableRef CVarNetVisualizeSimulatedCorrections
	(
		TEXT("p.DisplayNetMoveSimulatedCorrections"),
		DisplayNetMoveSimulatedCorrections,
		TEXT("")
		TEXT("0: Disable, 1: Enable"),
		ECVF_Cheat
	);
}

void FRoleMovementComponentLateTickFunction::ExecuteTick(float DeltaTime, enum ELevelTick TickType, ENamedThreads::Type CurrentThread, const FGraphEventRef& MyCompletionGraphEvent)
{
	FActorComponentTickFunction::ExecuteTickHelper(Target, /*bTickInEditor=*/ false, DeltaTime, TickType, [this](float DilatedTime)
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("FRoleMovementComponentLateTickFunction");
			QUICK_SCOPE_CYCLE_COUNTER(FRoleMovementComponentLateTickFunction)
			if (Target->bEnableMoveTick)
			{
				Target->LateUpdate(DilatedTime);
			}
		});
}

#pragma region Important
FRoleMovementStaticDataInfo URoleMovementComponent::StaticDataInfo = FRoleMovementStaticDataInfo();
FText URoleMovementComponent::AnimNotifyGroundSupportControlReason = FText::FromString(TEXT("AnimNotify"));
URoleMovementComponent::URoleMovementComponent(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	LateTickFunction.bCanEverTick = true;
	LateTickFunction.bStartWithTickEnabled = true;
	LateTickFunction.SetTickFunctionEnable(true);
	LateTickFunction.TickGroup = TG_EndPhysics; //before rigid body and cloth simulation hujianglong@kuaishou.com
	LateTickFunction.bHighPriority = true;

	NavMovementProperties.bUseAccelerationForPaths = true;
	bEnableMoveTick = true;

	// 初始设置为行走模式
	MovementMode = MOVE_Walking;

	// 网络平滑模式设置为4次平滑
	NetworkSmoothingMode = ENetworkSmoothingMode::Exponential;

	MovementSynchronizer.Init(this);
	MovementSimulator.Init(this);

	//using namespace NS_SLUA;
	//REG_EXTENSION_METHOD(URoleMovementComponent, "RefreshMeshOriginLRForSmooth", &URoleMovementComponent::RefreshMeshOriginLRForSmooth);
}

void URoleMovementComponent::BeginPlay()
{
	Super::BeginPlay();

	// 因为是纯C++类，不会自动调用ReceiveBeginPlay，这里手动调用
	ReceiveBeginPlay();

	RoleMP.Init(*this);
	ResetMoveDriveMode();
	ResetUsingLateUpdate();
	LocoInputSemantic = ELocoInputSemantic::OnGroundSemantic;
	LocoInputModifyMode = ELocoInputModifyMode::NoModifyMode;
	CurrentNetSimulateStatus = -1;
	IsNeedSyncUpMovement = false;
	LocoStopDelayTime = 0.0f;
	eMoveSyncRole = EMoveSyncRole::RoleNoSyncMove;
	SplineController.Init(*this);
}

void URoleMovementComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	ResetUsingLateUpdate();
	ResetWaterDetect();
	StopMoveWithSpline();
	ClearSplineActor();
	ScenePD.Reset();
	eMoveDriveMode = EMoveDriveMode::NoDrive;
	CurrentNetSimulateStatus = -1;
	IsNeedSyncUpMovement = false;

	Super::EndPlay(EndPlayReason);
}

void URoleMovementComponent::ResetToDefaultsForCache()
{
	RoleMP.Init(*this);
	ResetMoveDriveMode();
	ResetUsingLateUpdate();
	ResetWaterDetect();
	StopMoveWithSpline();
	ClearSplineActor();
	LocoInputSemantic = ELocoInputSemantic::OnGroundSemantic;
	LocoInputModifyMode = ELocoInputModifyMode::NoModifyMode;
	CurrentNetSimulateStatus = -1;
	IsNeedSyncUpMovement = false;
	LocoStopDelayTime = 0.0f;
	eMoveSyncRole = EMoveSyncRole::RoleNoSyncMove;
	eMoveDriveRelation = EMoveDriveRelation::DriveNoRelation;
	NeedUpdateMovementLeftTime = 0.2f;
	NeedUpdateMovementLeftTimeConfig = 0.2f;

	ALSSpeedCurve = nullptr;
	ALSSpeedCurveLoadID = -1;
	ALSRotationCurve = nullptr;
	ALSRotationCurveLoadID = -1;
	LockingTargetActorID = KG_INVALID_ACTOR_ID;
	
	InitMeshOriginLR(false);
}

void URoleMovementComponent::EnterWorld(bool InIsMainPlayer, bool InIsAvatar)
{
	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(CharacterOwner);
	if (!BaseCharacter)
	{
		UE_LOG(LogRoleMovement, Warning, TEXT("URoleMovementComponent::EnterWorld cast to ABaseCharacter failed"));
		return;
	}
	int64 EntityId = BaseCharacter->GetEntityUID();
	if (EntityId == 0)
	{
		UE_LOG(LogRoleMovement, Error, TEXT("URoleMovementComponent::EnterWorld get EntityId failed"));
		return;
	}
	MovementSynchronizer.SetNeedHandshake(true);
	ConsumeActorDataCache(EntityId);

	SetGravityScale(StaticDataInfo.LocoGravityScale);
	SetJumpZVelocity(StaticDataInfo.LocoJumpZVelocity);
	SetEnterFallingVelocityZ(StaticDataInfo.EnterFallingVelocityZ);
	SetGravityVelocityZMax(StaticDataInfo.GravityVelocityZMax);
	if (UBaseAnimInstance* baseAnimInst = GetAnimInstanceForMovement())
	{
		baseAnimInst->SetHighJumpEndVelocityZThreshold(StaticDataInfo.HighJumpEndVelocityZThreshold);
	}
	IsMainPlayer = InIsMainPlayer ? 1 : 0;
	IsAvatar = InIsAvatar ? 1 : 0;
	
	UKGPlatformScalabilitySettings* PlatformScalabilitySettings = UKGPlatformScalabilitySettings::GetInstance(this);
	if (!PlatformScalabilitySettings)
	{
		return;
	}
	UsingMainMeshChildTransformUpdateOptimization = PlatformScalabilitySettings->GetScalabilityValue<bool>("Movement", "UsingMainMeshChildTransformUpdateOptimization");
}



void URoleMovementComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleMovementComponent_TickComponent");
    TRACE_CPUPROFILER_EVENT_SCOPE_TEXT(*GetOwner()->GetName());
	
	if (!bEnableMoveTick || !IsActive() || !HasValidData() || ShouldSkipUpdate(DeltaTime))
	{
		return;
	}

	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("UPawnMovementComponent_TickComponent");
		UPawnMovementComponent::TickComponent(DeltaTime, TickType, ThisTickFunction);
	}

	if (eMoveDriveMode == EMoveDriveMode::NoDrive)
	{
		return;
	}


	// 3C为了解决角色出生时，可能因为地表还没有加载完成导致的角色下坠问题 @LiWeiWei
	if (TrackFloorDisableMoveMaxTime > 0 && IsValid(GetWorld()))
	{
		TrackFloorDisableMoveMaxTime -= DeltaTime;

		if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
		{
			FVector StickGroundLoc = Character->GetActorLocation();
			if (Character->CheckActorStickGround(GetTrackFloorCollisionPresetName(), MoveableFloorMaxHeight * 0.5f, StickGroundLoc))
			{
				if (bNeedBornStickGround)
				{
					CharacterOwner->SetActorLocation(StickGroundLoc);
				}

				TrackFloorDisableMoveMaxTime = 0.0f;
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_OnTrackFloorEnable");
			}
			else
			{
				UE_LOG(LogRoleMovement, Warning, TEXT("RoleMoveComp TrackFloor StickGround Failed! Name:%s, Level:%s, StickGroundLoc:%s"), *GetOwner()->GetName(), *GetWorld()->GetMapName(), *StickGroundLoc.ToString());
			}
		}

		return;
	}
	MovementSynchronizer.Tick(DeltaTime);
	MovementSimulator.Tick(DeltaTime);
	
	// todo 这里回调设计待处理: 要按照input 和 apply两个阶段来处理回调, 每个阶段的回调都要在阶段末尾调用, 且应用者不能假设回调依赖来设计业务 @sunya
	RoleMP.PrepareMovementContextBeforeInputCalculate();
	IsNeedDoLateUpdate = true;

	bool isBriefSync = MovementSimulator.GetSimulateType() == EMoveSimulateType::ServerBrief;
	// ===================================驱动模式处理===============================================
	// ------------------------1.计算当前是否为本地模拟, 还是网络模拟--------------------------------
	UpdateNetSimulateStatusImmediately();

	// ------------------------计算当前是否为本地模拟, 还是网络模拟 End--------------------------------
	FTransform Trans = GetActorRideModeTransform();
	LastFrameLoc = Trans.GetLocation();
	LastFrameRot = Trans.GetRotation();
	// 2. 根据网络数据进行移动模拟驱动输入计算
	if (GetCurrentIsNetSimulate())
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("NetDriveCalculate");
		SimulateDeltaAccumulation += DeltaTime;
		// 做一个P3的同步位移控制降频降帧, 单个单位移动, 还是会有多个部件的Transform的开销(累积20us左右)
		if(SimulateDeltaAccumulation >= CurrentSimulateDeltaThreshold)
		{
			
			FVector pos;
			FRotator rotator;
			if (MovementSimulator.SimulatedTick(SimulateDeltaAccumulation, pos, rotator)) {
				ProduceNetShadowMovement(pos, rotator);
			}

			SimulateDeltaAccumulation = 0.0f;
		}
	}
	// 3. 寻路驱动的移动输入计算
	// 4. 本地的移动计算驱动输入计算
	else
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("AuthorityDriveCalculate");
		bool needCalculateLocomotionDrive = eMoveDriveMode == EMoveDriveMode::DriveLocally || eMoveDriveMode == EMoveDriveMode::DriveByNavigate;
		// 这里先打一个RootMotionSource的补丁条件
		needCalculateLocomotionDrive = needCalculateLocomotionDrive || CurrentRootMotion.HasActiveRootMotionSources();
		needCalculateLocomotionDrive |= IsDriveMountDriveAttachStage();

		// P1/P3的carrier都不需要算, 等着Rider来驱动处理
		bool noNeedCalculateLocomotionDrive = eMoveDriveRelation == EMoveDriveRelation::DriveMountAsCarrier || eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsRider;

		if (!noNeedCalculateLocomotionDrive && needCalculateLocomotionDrive) {
			if (this->bAllowMoveWithSpline)
			{
				TickSplineMove(DeltaTime);
			}
			CalculateLocomotionDriveInput(DeltaTime);

			// FallingStepOn机制
			if (NeedDoUpdateStepOnDuration())
			{
				UpdateStepOnDuration(DeltaTime);
			}
			if (NeedDoFallingStepOnDetect())
			{
				DoFallingStepOnDetect(DeltaTime);
			}
		}

	}

	// ALS 打开, 无论是本地操控还是网络模拟, 都需要计算处理
	if(IsALSMovementMode())
	{
		CalculateALSLocoControlData(DeltaTime);
	}
	
	// ===================================驱动模式处理    END=========================================
	

	// 5.移动驱动的输入apply,MovementPipeline计算--->计算结果真正应用, 按需进行Late编排, 支持在Animation之后的变化和回调处理后, 再按需进行apply
	// 移动和动画, 都会去更新MainMesh的childs(挂接武器、挂接装饰、特效等等), 会重复更新, 且开销较高, 需要去除一次冗余
	// 前置信息:
	//		[1] 非LateUpdate下, SkeletalMeshComponent依赖RoleMovementComponent, 执行顺序Movement Update Childs-> Anim Update Childs
	//		[2] LateUpdate下, SkeletalMeshComponent依赖RoleMovementComponent, 但LateUpdate会在SkeletalMeshComponent的FinalizeAnimation之后,
	//			执行顺序Movement TickComponent -> Anim Update Childs -> Movement LateUpdate update Childs
	//
	//	外部逻辑set transform接口: 非LateUpdate模式, 统一设置成则设置SetPropagateToDoAllChildAndRestoreToOriginal
	//							 LateUpdate模式, 设置成SetPropagateToIgnoreAndRestoreToOriginal
	//
	// 非LateUpdate模式:
	//		如果当帧有新transform需要更新, 则设置SetPropagateToDoAllChildAndRestoreToOriginal, 让动画FinalzeAnimation去全刷新
	//		如果当前帧没有transform更新, 则无需设置, 让动画按照已有strategy更新(外部没有set, 默认就是Original)
	// LateUpdate模式:
	//		在LateUpdate执行前(主PrimaryTick中)统一设置SetPropagateToIgnoreAndRestoreToOriginal, 让动画不进行更新child, 让child更新都放到移动中
	//		如果有移动, 恢复成Original模式, 且则执行原始逻辑
	//		如果没有移动(前面设置了ignore, 所以一定没有更新, 这里一定要补一次),  则补一次OnlyUpdateIfUsingSocket的更新(把动画部分补齐); 然后再恢复成original模式

	// 设计保底:
	// 前置已知:  Movement、Animation TickEnable变动, 都是在WorldTick调度最前面和最后面, 所以Movement->Animation执行链过程间, 是不会有tick enable变动
	// 使用场景:
	//	[1]只有Movement Animation 同时在在Tick, 才开启上面的去冗余机制
	//  [2]去冗余处理, Movement是生产控制者, Animation是消费者, 如果有任何预期以外的情况, 理论情况下只有一帧会更新不及时, 后续都会正常更新
	
	// 骑乘、载具是再进阶优化项, 人是挂到自坐骑上的, 可以让坐骑统一来更新@孙亚
	// 前置信息:
	//	[1]所有被挂接的乘客/rider, 都进行ignore的设置, 并且所有的乘客/rider 实际是没有主动Movement的, 这一次的消耗是没有的
	//  [2]重复的地方是, 坐骑移动刷自己的时候, 会刷自己和乘客身上所有mesh一次； 坐骑动画Finalize的时候, 自己和乘客所有mesh又刷一次; 乘客自己动画Finalize的时候, 又会刷一次自己mesh一次
	//		总共冗余: 坐骑自己2次, 所有乘客3次
	// 非LateUpdate模式:
	// 所有挂接单位, 在动画Finalize的事件中, 设置ignore; 坐骑在finalize事件中, 恢复所有乘客为original, 让动画进行刷新
	// 所有乘客, 不需要处理, 因为乘客不会自己调用移动
	// 坐骑, 和上面独立单位处理一致

	// LateUpdate模式:
	// 所有挂接单位、坐骑, 在动画Finalize的事件中, 设置ignore;
	// 所有乘客, 不需要处理, 因为乘客不会自己调用移动
	// 在坐骑的移动中,按照上面独立单位处理一致; 处理的时候, 恢复所有passenger 为orignal, 然后再刷新
	if (!UsingLateUpdate) {

		LateUpdate(DeltaTime);
	}

	// brief 同���, 表现相关可以阉割
	if (isBriefSync) {
		return;
	}
	
	if(UsingMainMeshChildTransformUpdateOptimization)
	{
		
		if(GetUsingLateUpdateForPropagationOptimize())
		{
			if(eMoveDriveRelation == EMoveDriveRelation::DriveNoRelation || IsCarrierDriveRelationWhenAttached())
			{
				// LateUpdate模式下, 都要提前设置
				SetToMainMeshIgnoreChildTransformStrategy();
			}
		}
		
	}

	// 记录移动距离
	if (IsDisRecording)
	{
		UpdateRecordingDis();
	}

	if (!CharacterOwner->GetWorld()->IsPreviewWorld())
	{
		if (CouldApplyDynamicWaterWave()) {
			TryApplyDynamicWaterWaveFromLocomotion(DeltaTime);
		}

		if (CouldApplyLocalWindField()) {
			TryApplyLocalWindFieldFromLocomotion(DeltaTime);
		}
	}

	if (ScenePD.IsValid()) {
		ScenePD->DoScenePerceptionDetect(DeltaTime, *GetRealMovementViewProxy(), RoleMP.GetMovementContext());
	}
}

void URoleMovementComponent::CalculateLocomotionDriveInput(float DeltaTime) {
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleMovementComponent::CalculateLocomotionDriveInputAsAuthority");
	bool bAllowLocoStart = GetAllowLocoStart() || eMoveDriveMode == EMoveDriveMode::DriveByNavigate;

	// 3.1 进行本地操控的变量输入获取, 摇杆
	HasRawLocoInput = ConsumeLocoInputVector(LocoInputVector, RawInputMoveVector, DeltaTime);
	HasRequestedVelocityInput = ConsumeRequestedVelocityInputVector(RequestedVelocityInputVector);
	// 根据输入源配置整合最终的InputVector
	HasRawLocoInput = ComputeFinalInputVector(LocoInputVector, RequestedVelocityInputVector);

	bool hasValidInputVecForZoneChange = HasRawLocoInput && bAllowLocoStart;
	TryChangeLocoInputZone(hasValidInputVecForZoneChange, LocoInputVector);

	// 3.2 准备移动计算的输入环节数据
	auto& MovementContext = RoleMP.GetMovementContext();

	bool hasLocoInput = HasRawLocoInput && AllowProactiveMovement();
	ModifyLocoInputVector(LocoInputVector, hasLocoInput);
	MovementContext.SetLocoInputVec(LocoInputVector, hasLocoInput, DeltaTime);


	// 3.3 计算用于Locomotion驱动的动画变量
	FaceAndDriveDiffRadian = 0.f;
	if (hasLocoInput)
	{
		const FRotator Rotator = GetActorRideModeTransform().Rotator();
		const float LocoInputYaw = LocoInputVector.Rotation().Yaw;
		FaceAndDriveDiffRadian = FMath::DegreesToRadians(MathFormula::ClosetYawSignedDiff(Rotator.Yaw, LocoInputYaw));
		FaceAndDriveDiffRadian = FMath::RoundToFloat(FaceAndDriveDiffRadian * 1000) / 1000; // 保留三位小数

		// 倒车起步情况，这里需要额外检查，否则CheckIsBackCarByMoveDelta无法和FaceAndDriveDiffRadian同时更新，动画蓝图的MoveTurn判断会有问题
		CheckIsBackCarByInputVector();
	}

	bool isNeedSetLocoStart = (bAllowLocoStart && hasLocoInput);

	if (ForceLocoStart == FORCE_LOCO_START_TRUE)
	{
		isNeedSetLocoStart = true;
	}else if(ForceLocoStart == FORCE_LOCO_START_FALSE)
	{
		isNeedSetLocoStart = false;
	}
	
	LocoStopDelayTime -= DeltaTime;

	if (isNeedSetLocoStart)
	{
		SetIsLocoStart(true);
		LocoStopDelayTime = LocoStopDelayTimeThreshold;
	}
	else
	{
		// 只有不是强制LocoStart的设置才走时间的控制(视为输入驱动loco Start)
		if (ForceLocoStart == NO_FORCE_LOCO_START && LocoStopDelayTime <= 0.0f) {
			SetIsLocoStart(false);
		}
		else
		{
			SetIsLocoStart(false);
		}

	}
}

bool URoleMovementComponent::CheckIsBackCarAngleAllowed(const float& InputYaw) const
{
	if (GetLocoInputSemantic() != ELocoInputSemantic::OnActorCordinateSemanitic)
	{
		// 非拟真驾驶模式，不触发倒车
		return false;
	}

	const FRotator Rotator = GetActorRideModeTransform().Rotator();
	return FMath::Abs(FRotator::NormalizeAxis(InputYaw - Rotator.Yaw)) > (180 - StaticDataInfo.BackCarAngle);
}

void URoleMovementComponent::CheckIsBackCarByInputVector()
{
	if (!GetIsBackCar() && IsInRideState() && RoleMP.GetMovementContext().GetMountType() == int(EMountType::Car))
	{
		const float LocoInputYaw = LocoInputVector.Rotation().Yaw;
		if (CheckIsBackCarAngleAllowed(LocoInputYaw)) // 龙头与朝向角度满足倒车角度要求
		{
			FVector CarVelocity = GetRealMovementViewProxy()->Velocity;
			if (CarVelocity.Size2D() <= StaticDataInfo.TriggerBackCarSpeedLimit)
			{
				RoleMP.GetMovementContext().SetIsBackCar(true);
			}
		}
	}
}

bool URoleMovementComponent::CheckIsBackCarByMoveDelta(const FVector& InMoveDelta) const
{
	if (IsInRideState() && RoleMP.GetMovementContext().GetMountType() == int(EMountType::Car) && !InMoveDelta.IsNearlyZero())
	{
		const float MoveDeltaYaw = InMoveDelta.Rotation().Yaw;
		if (CheckIsBackCarAngleAllowed(MoveDeltaYaw)) // 龙头与朝向角度满足倒车角度要求
		{
			FVector CarVelocity = const_cast<URoleMovementComponent*>(this)->GetRealMovementViewProxy()->Velocity;
			if (GetIsBackCar() || (CarVelocity.Size2D() <= (StaticDataInfo.TriggerBackCarSpeedLimit)))// 当上一帧也在倒车，或速度小于倒车速度限制时，允许倒车，
			{
				return true;
			}
		}
	}

	return false;
}

EFaceDirectionInputMode URoleMovementComponent::GetFaceDriveDirectionVec()
{
	if (ALS_RotationMode == EALS_RotationMode::VelocityDirection)
	{
		return EFaceDirectionInputMode::VelocityDirection;;
	}

	if (ALS_RotationMode == EALS_RotationMode::Aiming || ALS_RotationMode == EALS_RotationMode::LookingDirection)
	{
		return EFaceDirectionInputMode::CameraControlDirection;
	}

	return EFaceDirectionInputMode::VelocityDirection;
}

void URoleMovementComponent::LateUpdate(float DeltaTime)
{
	if (!IsNeedDoLateUpdate) {
		return;
	}

	QUICK_SCOPE_CYCLE_COUNTER(URoleMovementComponent_LateUpdate);
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("URoleMovementComponent_LateUpdate");
	
	RoleMP.PrepareMovementContextBeforeCalculateAndApply(this, DeltaTime);
	// 使用Produce和Consume方式保障一次有效的TickComponent 有且只有一次LateUpdate
	IsNeedDoLateUpdate = false;

	bool HasNewTransformApply = false;
	if (MountRelationCooperator.IsValid())
	{
		if (IsDriveVehicleRelation())
		{
			LateUpdateWithVehicle(DeltaTime, HasNewTransformApply);
		}
		else
		{
			LateUpdateWithMount(DeltaTime, HasNewTransformApply);	
		}
	}
	else
	{
		LateUpdateOnlyPlayer(DeltaTime, HasNewTransformApply);
	}

	//
	if(UsingMainMeshChildTransformUpdateOptimization )
	{
		if(!HasNewTransformApply)
		{
			if(eMoveDriveRelation == EMoveDriveRelation::DriveNoRelation)
			{
				// 只有使用LateUpdate模式的时候, 补一次child transform 更新
				// 非LateUpdate模式, 不需要额外处理, 动画自己会在Finalize中进行处理
				if(GetUsingLateUpdateForPropagationOptimize()){
					if(CharacterOwner && CharacterOwner->GetMesh())
					{
						auto* MainMesh = CharacterOwner->GetMesh();
						MainMesh->SetPropagateToOriginal();
						if(NeedUpdateAllChildrenWithTransformChanged)
						{
							MainMesh->UpdateChildTransforms(EUpdateTransformFlags::None);
						}
						else
						{
							MainMesh->UpdateChildTransforms(EUpdateTransformFlags::OnlyUpdateIfUsingSocket);
						}
					}
				}
			}
			else if(IsMountRiderWhenAttached() && MountRelationCooperator.IsValid())
			{
				// 自己是Rider, 自己驱动了Carraier, LateUpdate使用自己的即可
				if(GetUsingLateUpdateForPropagationOptimize())
				{
					auto* CarrierCharacterOwner = MountRelationCooperator->GetCharacterOwner();
					if(CarrierCharacterOwner && CarrierCharacterOwner->GetMesh())
					{
						auto* MainMesh = CarrierCharacterOwner->GetMesh();
						MainMesh->SetPropagateToOriginal();
						MountRelationCooperator->SetPassengersToOriginalChildTransformStrategyAsCarrier();
						if(NeedUpdateAllChildrenWithTransformChanged)
						{
							MainMesh->UpdateChildTransforms(EUpdateTransformFlags::None);
						}
						else
						{
							MainMesh->UpdateChildTransforms(EUpdateTransformFlags::OnlyUpdateIfUsingSocket);
						}
					
					}
				}
			
			}
		}
		// 外部设置过, 这里统一重置掉几颗
		NeedUpdateAllChildrenWithTransformChanged = false;
		
	}

	// 3. PostLateUpdate
	if (GetAutoUpdatePostureAndPlayRate())
	{
		if(eAutoUpdatePostureMode == EAutoUpdatePostureMode::ALS_MODE)
		{
			DoAutoUpdatePostureAndPlayRateWithALSMode();
		}
		else
		{
			DoAutoUpdatePostureAndPlayRateWithCycleMotionMode();
		}
	}
	RoleMP.ApplyMovementContextOnPostLateUpdate(this, DeltaTime);

	// 4. 权威端控制上传
	if (IsNeedSyncUpMovement) {
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("SyncUpMovement");
		DoSyncUpMovementData(DeltaTime);
	}

	// Locomotion参数反推
	if ((GetCurrentIsNetSimulate() && !(MovementSimulator.GetSimulateType() == EMoveSimulateType::ServerBrief)) || bAllowMoveWithSpline) {
		LocomotionParamInverseCalculate(DeltaTime);
	}
	else {
		SetIsLocomotionParamInverseCalculate(false);
	}

	// 矫正器执行回调
	EMovementCorrectorType FinishCorrectType = RoleMP.GetMovementContext().ConsumeFinishedCorrectorType();
	if (FinishCorrectType != EMovementCorrectorType::None)
	{
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_MovementCorrectorFinished", FinishCorrectType);
		}	
	}


}

void URoleMovementComponent::LateUpdateOnlyPlayer(float DeltaTime, bool & HasNewTransformApplied)
{
	bool isAttachedMovement = eMoveDriveMode == EMoveDriveMode::DriveByAttachedParent;
	
	bool isNetSimulate = GetCurrentIsNetSimulate();

	bool isRMSuccess = false;
	FVector calculatedWorldVelocity = FVector::ZeroVector;
	FVector worldVelocity = FVector::ZeroVector;
	FQuat worldQuat = RoleMP.GetMovementContext().GetCurrentActorTransform().GetRotation();
	FQuat calculatedWorldQuat = worldQuat;
	//1.MovementPipeline计算
	if (!isNetSimulate && !isAttachedMovement) {
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("CalculateMovementPipeline");
		//还是要计算消耗, 会涉及到时间的tick消耗;
		// todo 看这里能不能直接把ViewProxy的概念直接往外拆
		isRMSuccess = RoleMP.CalculateMovement(DeltaTime, this, calculatedWorldVelocity, calculatedWorldQuat);
		if (isRMSuccess) {
			if (AllowMovement()) {
				worldVelocity = calculatedWorldVelocity;
			}
			if (AllowRotation()) {
				worldQuat = calculatedWorldQuat;
			}
			// 消耗非移动操控部分数据
			FVector consumedMeshOffset;
			if (RoleMP.GetMovementContext().ConsumeMeshAdditionalOffset(consumedMeshOffset)) {
				GetRealMovementViewProxy()->SetAdditionalMeshRL(consumedMeshOffset);
			}
		}
	}

	bool isIgnorePhysicFixup = RoleMP.GetMovementContext().IsIgnorePhysicFixup();
	bool usingWorldVelocityToUpdate = false;

	if (!isAttachedMovement) {  // 挂接是由外部处理, 这里不需要做处理
	// 2.1.网络同步简单处理应用
		if (isNetSimulate)
		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("NetDriveApply");
			QUICK_SCOPE_CYCLE_COUNTER(STAT_NetDriveApply);

			FVector FinalWorldPos;
			FRotator FinalWorldRotator;
			if (RoleMP.CalculateNetShadowMovement(DeltaTime, *this, FinalWorldPos, FinalWorldRotator)) {
		
				PerformSimpleMovement(DeltaTime, FinalWorldPos, FinalWorldRotator.Quaternion(), HasNewTransformApplied);
			}
		}
		// 2.2根据本地情况进行计算-应用
		else {
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("AuthorityDriveApply");
			QUICK_SCOPE_CYCLE_COUNTER(STAT_AuthorityDriveApply);
		
			if (isRMSuccess) {
				PerformPhysicMovementWithVelocity(DeltaTime, worldVelocity, worldQuat, isIgnorePhysicFixup, HasNewTransformApplied);
				usingWorldVelocityToUpdate = true;
			}
		}
	}

	MovementDataUpdate(DeltaTime, worldVelocity, usingWorldVelocityToUpdate);
}

void URoleMovementComponent::LateUpdateWithMount(float DeltaTime, bool & HasNewTransformApplied)
{
	bool isNetSimulate = GetCurrentIsNetSimulate();
	bool bMountAsCarrier = eMoveDriveRelation == EMoveDriveRelation::DriveMountAsCarrier;
	bool isMovementCalculatedByOther = bMountAsCarrier || eMoveDriveRelation == EMoveDriveRelation::DriveMountAsPassenger || 
		eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsPassenger;
	
	bool bP1PlayerPerformance = eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP1PerformanceStage;
	bool bP3PlayerPerformance = eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP3PerformanceStage;
	bool bP1PlayerAttachStage = eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP1RiderAttachStage;
	bool bP3PlayerAttachStage = eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP3RiderAttachStage;
	bool bMountPerformance = eMoveDriveRelation == EMoveDriveRelation::DriveMountAsCarrierPerformance;
	bool bP3OffMountStage = eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP3OffMountStage;

	bool isRMSuccess = false;
	FVector calculatedWorldVelocity = FVector::ZeroVector;
	FVector worldVelocity = FVector::ZeroVector;
	FQuat worldQuat = RoleMP.GetMovementContext().GetCurrentActorTransform().GetRotation();
	FQuat calculatedWorldQuat = worldQuat;
	
	// 1.MovementPipeline计算
	// 如果不需要计算运动 且 (非网络模式下 或者 处于网络模式下但是也处于骑乘表演中) 则需要应用Rootmotion数据
	if ((!isNetSimulate or bP1PlayerPerformance or bP3PlayerPerformance or bP3OffMountStage) && !isMovementCalculatedByOther) {
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("CalculateMovementPipeline");
		//还是要计算消耗, 会涉及到时间的tick消耗;
		// todo 看这里能不能直接把ViewProxy的概念直接往外拆
		isRMSuccess = RoleMP.CalculateMovement(DeltaTime, this, calculatedWorldVelocity, calculatedWorldQuat);

		if (isRMSuccess) {
			if (AllowMovement()) {
				worldVelocity = calculatedWorldVelocity;
			}
			if (AllowRotation()) {
				worldQuat = calculatedWorldQuat;
			}

			// 消耗非移动操控部分数据
			FVector consumedMeshOffset;
			if (RoleMP.GetMovementContext().ConsumeMeshAdditionalOffset(consumedMeshOffset)) {
				GetRealMovementViewProxy()->SetAdditionalMeshRL(consumedMeshOffset);
			}
		}
	}

	bool isIgnorePhysicFixup = RoleMP.GetMovementContext().IsIgnorePhysicFixup();
	bool usingWorldVelocityToUpdate = false;
	
	// 2.1.网络同步简单处理应用
	// P1 玩家本地表演上坐骑
	if ((bP1PlayerPerformance || bMountPerformance) && isRMSuccess)
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("AuthorityDriveApply");
		QUICK_SCOPE_CYCLE_COUNTER(STAT_AuthorityDriveApply_Mount);
		
		PerformPhysicMovementWithVelocity(DeltaTime, worldVelocity, worldQuat, isIgnorePhysicFixup, HasNewTransformApplied);
		usingWorldVelocityToUpdate = true;
	}
	// P1 玩家挂接阶段 直接驱动坐骑, 角色自己会被挂接机制进行带着移动
	else if (bP1PlayerAttachStage && isRMSuccess)
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("AuthorityDriveApply");
		QUICK_SCOPE_CYCLE_COUNTER(STAT_AuthorityDriveApply_Attach);

		MountRelationCooperator->PerformMountMovementAsCarrier(DeltaTime, *this, worldVelocity, worldQuat, isIgnorePhysicFixup, HasNewTransformApplied);
	}
	// P3 玩家本地表演上坐骑 || 挂接阶段
	else if (bP3PlayerPerformance || bP3PlayerAttachStage)
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("NetDriveApply");
		QUICK_SCOPE_CYCLE_COUNTER(STAT_NetDriveApply_Mount);

		// p3 玩家处于这个阶段的时候需要把数据应用到自身
		if (bP3PlayerPerformance && isRMSuccess)
		{
			PerformPhysicMovementWithVelocity(DeltaTime, worldVelocity, worldQuat, isIgnorePhysicFixup, HasNewTransformApplied);
			usingWorldVelocityToUpdate = true;
		}

		// p3 玩家在这两个阶段中的任意一个阶段都需要 同步网络数据给坐骑
		FVector FinalWorldPos;
		FRotator FinalWorldRotator;
		if (eMoveDriveMode == EMoveDriveMode::DriveLocally && bP3PlayerAttachStage)
		{
			MountRelationCooperator->PerformPhysicMovementWithVelocity(DeltaTime, worldVelocity, worldQuat, isIgnorePhysicFixup, HasNewTransformApplied);
		}
		else if (RoleMP.CalculateNetShadowMovement(DeltaTime, *this, FinalWorldPos, FinalWorldRotator)) {
			PerformMountMovementAsRiderFromNet(DeltaTime, FinalWorldPos, FinalWorldRotator.Quaternion(), HasNewTransformApplied);
		}
	}
	// P3 下坐骑阶段
	else if (bP3OffMountStage)
	{
		FVector FinalWorldPos;
		FRotator FinalWorldRotator;
		if (RoleMP.CalculateNetShadowMovement(DeltaTime, *this, FinalWorldPos, FinalWorldRotator)) {
			PerformSimpleMovement(DeltaTime, FinalWorldPos, FinalWorldRotator.Quaternion(), HasNewTransformApplied);
		}
	}
	
	MovementDataUpdate(DeltaTime, worldVelocity, usingWorldVelocityToUpdate);

	// 音频事件
	if (bMountAsCarrier)
	{
		UpdateMountAudioRTPC();
	}
}

void URoleMovementComponent::LateUpdateWithVehicle(float DeltaTime, bool & HasNewTransformApplied)
{
	const bool bP1VehicleCarrier = eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsCarrier;
	const bool bP3VehicleCarrier = eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsP3Carrier;
	
	FVector calculatedWorldVelocity = FVector::ZeroVector;
	FVector worldVelocity = FVector::ZeroVector;
	FQuat worldQuat = RoleMP.GetMovementContext().GetCurrentActorTransform().GetRotation();
	FQuat calculatedWorldQuat = worldQuat;

	bool isIgnorePhysicFixup = RoleMP.GetMovementContext().IsIgnorePhysicFixup();
	bool usingWorldVelocityToUpdate = false;
	
	if (bP1VehicleCarrier && MountRelationCooperator.IsValid())
	{
		// 权威驾驶端
		if (RoleMP.CalculateMovement(DeltaTime, this, calculatedWorldVelocity, calculatedWorldQuat))
		{
			if (AllowMovement()) {
				worldVelocity = calculatedWorldVelocity;
			}
			if (AllowRotation()) {
				worldQuat = calculatedWorldQuat;
			}
			PerformMountMovementAsCarrier(DeltaTime, *this, worldVelocity, worldQuat, isIgnorePhysicFixup, HasNewTransformApplied);
		}
	}
	else if (bP3VehicleCarrier)
	{
		// 网络同步数据
		FVector FinalWorldPos;
		FRotator FinalWorldRotator;
		if (RoleMP.CalculateNetShadowMovement(DeltaTime, *this, FinalWorldPos, FinalWorldRotator)) {
			PerformSimpleMovement(DeltaTime, FinalWorldPos, FinalWorldRotator.Quaternion(), HasNewTransformApplied);
		}
	}
	
	MovementDataUpdate(DeltaTime, worldVelocity, usingWorldVelocityToUpdate);
}

void URoleMovementComponent::SetUsingLateUpdate(bool isUsing) {
	if (isUsing == UsingLateUpdate) {
		return;
	}
	
	UsingLateUpdate = isUsing;
	// LateUpdate模式变动, 恢复更新逻辑到默认, 避免模式变动引起的策略残留不一致
	SetToMainMeshOriginalChildTransformStrategy();
	
	if (UsingLateUpdate)
	{
		if (SetupActorComponentTickFunction(&LateTickFunction))
		{

			// 如果没有动画, 就可以不用做分开调度, 分开调度是为了满足主控:
			// [1]RoleMovementComponent的TickComponent计算操控输入
			// [2]动画使用操控输入进行动画节点计算, 动画节点确定LocoState, LocoState回调到脚本改变操控状态
			// [3]RoleMovementComponent的LateUpdate 使用最新的操控状态进行移动计算与生效apply

			// Mesh会依赖Movement的PrimaryTick, 这个是在ACharacter中自己做的
			LateTickFunction.Target = this;
			LateTickFunction.AddPrerequisite(this, this->PrimaryComponentTick);

			if (CharacterOwner && CharacterOwner->GetMesh()) {
				auto* curMesh = CharacterOwner->GetMesh();
				LateTickFunction.AddPrerequisite(curMesh, curMesh->PrimaryComponentTick);

				//ClothTick需要延后到LateTickFunction之后
				TArray<USkeletalMeshComponent*> Components;
				CharacterOwner->GetComponents<USkeletalMeshComponent>(Components);
				for (USkeletalMeshComponent* Component : Components)
                {
					Component->ClothTickFunction.AddPrerequisite(this, LateTickFunction);
                }

				if(IsMountRiderWhenAttached() && MountRelationCooperator.IsValid() && MountRelationCooperator->GetCharacterOwner() )
				{
					auto * MountMesh = MountRelationCooperator->GetCharacterOwner()->GetMesh();
					if(MountMesh)
					{
						LateTickFunction.AddPrerequisite(MountMesh, MountMesh->PrimaryComponentTick);
					}
				}
			}
		}
	}
	else
	{
		if(IsMountRiderWhenAttached() && MountRelationCooperator.IsValid() && MountRelationCooperator->GetCharacterOwner())
		{
			auto * MountMesh = MountRelationCooperator->GetCharacterOwner()->GetMesh();
			if(MountMesh)
			{
				LateTickFunction.RemovePrerequisite(MountMesh, MountMesh->PrimaryComponentTick);
			}
		}
		
		if (LateTickFunction.IsTickFunctionRegistered())
		{
			LateTickFunction.Target = nullptr;
			LateTickFunction.UnRegisterTickFunction();
		}
	}
}

void URoleMovementComponent::SetNeedLocoAnimStateChangedNotifyFromLocomotionSM(bool isNeed)
{
	if(isNeed)
	{
		SetNeedNotifyLocoStateChanged(true);
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)){
			// 脚本回到相应LocoState
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyLocoStateChanged", -1, GetLocomotionStateFromMask());
		}
	}
	else
	{
		SetNeedNotifyLocoStateChanged(false);
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)){
			// 脚本回到Idle
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyLocoStateChanged", -1, 1);
		}
	}
}

void URoleMovementComponent::DoSetMoveDriveMode(EMoveDriveMode InDriveMode) {
	if (InDriveMode == eMoveDriveMode) {
		return;
	}
	ALOG_DEBUG_POSITION(this, "URoleMovementComponent::DoSetMoveDriveMode %d -> %d", static_cast<int>(eMoveDriveMode), static_cast<int>(InDriveMode));

	LastUpdateRequestedVelocity.Set(0.0f, 0.0f, 0.0f);
	LocoInputVector.Set(0.0f, 0.0f, 0.0f);
	RawInputMoveVector.Set(0.0f, 0.0f, 0.0f);
	HasRawLocoInput = false;

	// 旧状态退出的逻辑
	switch (eMoveDriveMode)
	{
		// 从Nodrive和DriveByAttachedParent切换到其他状态，清空一下初始速度和加速度
	case(EMoveDriveMode::NoDrive):
		Velocity = FVector::ZeroVector;
		break;
	case(EMoveDriveMode::DriveByAttachedParent):
		Velocity = FVector::ZeroVector;

		if (GetIsMainPlayer())
		{
			FString ControlTag = TEXT("DoSetMoveDriveMode");
			SetDisableLocoJumpWeakValue(false, ControlTag, true);
			SetDisableLocoDodgeWeakValue(false, ControlTag, true);
			SetDisableLocoMoveWeakValue(false, ControlTag, true);
			SetDisableLocoRotateWeakValue(false, ControlTag);
			ClearUsingLateUpdateForceValue(ControlTag);
		}
		SetEnterFallingVelocityZ(0.0f);
		break;
	case(EMoveDriveMode::DriveByNavigate):
	case(EMoveDriveMode::DriveLocally):
		if (InDriveMode != EMoveDriveMode::DriveByNavigate && InDriveMode != EMoveDriveMode::DriveLocally && GetIsAvatar()){
			SetNeedLocoAnimStateChangedNotifyFromLocomotionSM(false);
		}
		break;
	}

	EMoveDriveMode OldMoveDriveMode = eMoveDriveMode;
	eMoveDriveMode = InDriveMode;

	// 新状态进入时的逻辑
	switch (InDriveMode)
	{
		// 切换到NoDrive和DriveByAttachedParent时重置一下LocoStart和LocoStop
	case(EMoveDriveMode::NoDrive):
		SetIsLocoStart(false);
		break;
	case(EMoveDriveMode::DriveByAttachedParent):
		SetIsLocoStart(false);
		// 挂载关联移动下，不进行OnMovementModeChanged的逻辑处理，因此这里主动清理Base和CurrentFloor
		ClearBaseAndCurrentFloor();

		if (GetIsMainPlayer())
		{
			FString ControlTag = TEXT("DoSetMoveDriveMode");
			SetDisableLocoJumpWeakValue(true, ControlTag, true);
			SetDisableLocoDodgeWeakValue(true, ControlTag, true);
			SetDisableLocoMoveWeakValue(true, ControlTag, true);
			SetDisableLocoRotateWeakValue(true, ControlTag);
			SetUsingLateUpdateForceValue(false, ControlTag);
		}
		else if(IsMountRider() && GetIsAvatar())
		{
			SetNeedLocoAnimStateChangedNotifyFromLocomotionSM(false);
		}

		SetEnterFallingVelocityZ(StaticDataInfo.EnterFallingVelocityZ);
		break;
		// 切换到DriveByNet时重置一下数据包，之前的数据包会因为非DriveByNet未处理贴地
	case(EMoveDriveMode::DriveByNet):
		//MovementSimulator.Clear();
	case(EMoveDriveMode::DriveByNavigate):
	case(EMoveDriveMode::DriveLocally):
		if (OldMoveDriveMode != EMoveDriveMode::DriveByNavigate && OldMoveDriveMode != EMoveDriveMode::DriveLocally && GetIsAvatar()){
			SetNeedLocoAnimStateChangedNotifyFromLocomotionSM(true);
		}
		break;
	}

	UpdateNetSimulateStatusImmediately();
}
void URoleMovementComponent::SetMoveDriveMode(EMoveDriveMode InDriveMode)
{

	DoSetMoveDriveMode(InDriveMode);
}

bool URoleMovementComponent::SetMoveDriveRelation(EMoveDriveRelation DriveRelation, int64 relationActorId) {
	if (DriveRelation == EMoveDriveRelation::DriveNoRelation) {
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::SetMoveDriveRelation: Using CleanMoveDriveRelation Interface"));
		return false;
	}

	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::SetMoveDriveRelation: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return false;
	}

	ABaseCharacter* targetCharacter = Cast<ABaseCharacter>(UOAM->GetObjectByID(relationActorId));
	if (!targetCharacter) {
#if !UE_BUILD_SHIPPING
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::SetMoveDriveRelation: Unexpected Lifetime For ABaseCharacter: %d."), relationActorId);
#endif
		return false;
	}

	MountRelationCooperator = Cast<URoleMovementComponent>(targetCharacter->GetMovementComponent());
#if !UE_BUILD_SHIPPING
	if (!MountRelationCooperator.IsValid()) {
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::SetMoveDriveRelation: Unexpected Lifetime For URoleMovementComponent: %d."), relationActorId);
	}
#endif

	eMoveDriveRelation = DriveRelation;

	// 存在坐骑 RootMotion Consume异常的情况,额外consume一次
	if (eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP1RiderAttachStage)
	{
		ABaseCharacter* MountCharacter = Cast<ABaseCharacter>(MountRelationCooperator->GetOwner());
		USkeletalMeshComponent* MainMesh = MountCharacter ? MountCharacter->GetMainMesh() : nullptr;
		if (UBaseAnimInstance* AnimIns = Cast<UBaseAnimInstance>(MainMesh->GetAnimInstance()))
		{
			FRootMotionMovementParams ExtractedRootMotion;
			AnimIns->ConsumeRootMotionFromAnimation(ExtractedRootMotion);
		}
	}

	// 挂载关联移动下，不进行OnMovementModeChanged的逻辑处理，因此这里主动清理Base和CurrentFloor
	if (IsInterconnectedMovement())
	{
		ClearBaseAndCurrentFloor();
	}

	
	if(IsMountRiderWhenAttached() && MountRelationCooperator.IsValid() && MountRelationCooperator->GetCharacterOwner() && UsingLateUpdate)
	{
		auto * MountMesh = MountRelationCooperator->GetCharacterOwner()->GetMesh();
		if(MountMesh)
		{
			LateTickFunction.AddPrerequisite(MountMesh, MountMesh->PrimaryComponentTick);
		}
	}

	if(UsingMainMeshChildTransformUpdateOptimization)
	{
		if(CharacterOwner && CharacterOwner->GetMesh())
		{
			auto * MainMesh = CharacterOwner->GetMesh();
			if(MainMesh)
			{
				if(MainMeshAnimBoneTransformFinalizeDelegateHandle.IsValid())
				{
					MainMesh->UnregisterOnBoneTransformsFinalizedDelegate(MainMeshAnimBoneTransformFinalizeDelegateHandle);
				}
				
				MainMeshAnimBoneTransformFinalizeDelegateHandle = MainMesh->RegisterOnBoneTransformsFinalizedDelegate(
					FOnBoneTransformsFinalizedMultiCast::FDelegate::CreateUObject(
						this, &URoleMovementComponent::OnMainMeshAnimBoneTransformFinalize
						));
			}
		}
	}

	return true;
}

void URoleMovementComponent::CleanMoveDriveRelation() {

	if(IsMountRiderWhenAttached() && MountRelationCooperator.IsValid() && MountRelationCooperator->GetCharacterOwner())
	{
		auto * MountMesh = MountRelationCooperator->GetCharacterOwner()->GetMesh();
		if(MountMesh)
		{
			LateTickFunction.RemovePrerequisite(MountMesh, MountMesh->PrimaryComponentTick);
		}
	}

	if(UsingMainMeshChildTransformUpdateOptimization)
	{
		if(CharacterOwner && CharacterOwner->GetMesh())
		{
			auto * MainMesh = CharacterOwner->GetMesh();
			if(MainMesh)
			{
				if(MainMeshAnimBoneTransformFinalizeDelegateHandle.IsValid())
				{
					MainMesh->UnregisterOnBoneTransformsFinalizedDelegate(MainMeshAnimBoneTransformFinalizeDelegateHandle);
					MainMeshAnimBoneTransformFinalizeDelegateHandle.Reset();
				}
			}
		}
	}
	
	// 作为判断玩家下坐骑的条件
	if (IsMount())
	{
		UpdateMountAKEventStatus(false);
	}
	
	eMoveDriveRelation = EMoveDriveRelation::DriveNoRelation;
	MountRelationCooperator.Reset();
}

bool URoleMovementComponent::SetPassengerMoveDriveRelation(int64 relationActorId)
{
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::SetPassengerMoveDriveRelation: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return false;
	}

	ABaseCharacter* targetCharacter = Cast<ABaseCharacter>(UOAM->GetObjectByID(relationActorId));
	if (!targetCharacter) {
#if !UE_BUILD_SHIPPING
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::SetPassengerMoveDriveRelation: Unexpected Lifetime For ABaseCharacter: %d."), relationActorId);
#endif
		return false;
	}

	TWeakObjectPtr<UBaseAnimInstance> RelationCooperator = Cast<UBaseAnimInstance>(targetCharacter->GetMainMesh()->GetAnimInstance());
#if !UE_BUILD_SHIPPING
	if (!RelationCooperator.IsValid()) {
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::SetPassengerMoveDriveRelation: Unexpected Lifetime For URoleMovementComponent: %d."), relationActorId);
	}
#endif
	MountPassengerRelationMap.Add(relationActorId, RelationCooperator);
	if(URoleMovementComponent * RelationRMC = Cast<URoleMovementComponent>(targetCharacter->GetMovementComponent()))
	{
		// todo 这里只处理了Mount, Vehicle 后面要补 @程东
		RelationRMC->SetMoveDriveRelation(EMoveDriveRelation::DriveMountAsPassenger, UOAM->GetIDByObejct(this->GetCharacterOwner()));
	}
	
	return true;
}

void URoleMovementComponent::RemovePassengerMoveDriveRelation(int64 relationActorId)
{
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this);
	if (!UOAM)
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::RemovePassengerMoveDriveRelation: Unexpected Lifetime For ObjectActorManager ."));
#endif
		return ;
	}

	ABaseCharacter* targetCharacter = Cast<ABaseCharacter>(UOAM->GetObjectByID(relationActorId));
	if (!targetCharacter) {
#if !UE_BUILD_SHIPPING
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::RemovePassengerMoveDriveRelation: Unexpected Lifetime For ABaseCharacter: %d."), relationActorId);
#endif
		return ;
	}
	if(URoleMovementComponent * RelationRMC = Cast<URoleMovementComponent>(targetCharacter->GetMovementComponent()))
	{
		RelationRMC->CleanMoveDriveRelation();
	}

	MountPassengerRelationMap.Remove(relationActorId);
}


bool URoleMovementComponent::GetLocallyControlled()
{
	return bLocallyControlled;
}

void URoleMovementComponent::ChangeServerForcedControl(int32 InSign, bool bAdd)
{
	bool bPrevServerForcedControl = GetServerForcedControl();
	if (bAdd)
	{
		ServerForcedControl.AddUnique(InSign);
	}
	else
	{
		ServerForcedControl.RemoveSwap(InSign);
	}
	if (GetServerForcedControl() != bPrevServerForcedControl)
	{
		OnServerForcedControlChanged(!bPrevServerForcedControl);
	}
}

bool URoleMovementComponent::GetNeedClientLocalCalculate() {
	return CurrentRootMotion.HasActiveRootMotionSources() || (GetActiveMoveCorrectorType() == EMovementCorrectorType::MotionWarpCorrector && !IsDriveMountDrivePerformanceStage())
		|| GetActiveMoveCorrectorType() == EMovementCorrectorType::DestSmoothCorrector || CurRootMotionContext.CurRootMotion.IsValid();
}

ABaseCharacter* URoleMovementComponent::GetCharacterOwnerForRuntimeOrEditor()
{
	if(CharacterOwner)
	{
		return Cast<ABaseCharacter>(CharacterOwner);
	}
	// Editor下, MovementComponent有些初始化流程不走, 所以没有CharacterOwner的绑定
	return Cast<ABaseCharacter>(GetOwner());
}

bool URoleMovementComponent::GetServerForcedControl()
{
	return ServerForcedControl.Num() > 0;
}

void URoleMovementComponent::UpdateNetSimulateStatusImmediately() 
{
	bool isBriefSync = MovementSimulator.GetSimulateType() == EMoveSimulateType::ServerBrief;
	int8 CalculatedNetSimulate = eMoveDriveMode == EMoveDriveMode::DriveByNet ? 1 : 0;
	// 极简模式下, 只需要单纯的插值获取位置即可
	if (isBriefSync) {
		CalculatedNetSimulate = 1;
	}
	else {
		if (GetServerForcedControl())
		{
			CalculatedNetSimulate = 1;
		}
		//  战斗中, 使用RootMotionSource, 或者使用了DestSmooth/MotionWarp，变成了移动同步专属的本地移动驱动方式, 这里要注意耦合
		if (GetNeedClientLocalCalculate() || eMoveDriveMode == EMoveDriveMode::DriveByAttachedParent) {
			CalculatedNetSimulate = 0;
		}
	}

	if (CalculatedNetSimulate != CurrentNetSimulateStatus) {
		ALOG_DEBUG_POSITION(this, "URoleMovementComponent::UpdateNetSimulateStatusImmediately CalculatedNetSimulate[%d], eMoveDriveMode[%d], isBriefSync[%d], ServerForcedControl[%d], NeedClientLocalCalculate[%d]",
			CalculatedNetSimulate, static_cast<int>(eMoveDriveMode), isBriefSync, GetServerForcedControl(), GetNeedClientLocalCalculate());
		CurrentNetSimulateStatus = CalculatedNetSimulate;
		if (!isBriefSync) {
		
			MovementSimulator.Clear(EMoveSimulateClearReason::SimulateStatusUpdate);

			// 有模拟变动的逻辑开关, 放这里
			if (GetCurrentIsNetSimulate())
			{
				// 对于服务器控制的无LocoState信息的对象，目前不存在空中LocoState需求
				// 需要在这里重置为Walking的MovementMode
				if (GetLocomotionStateFromMask() == 0)
				{
					SimpleUpdateMovementModeFromNet(false);
				}
			}
			else
			{

				// 进行一次rootmotion consume, 避免网络同步模式下, 也有动画的rootmotion的积累, 导致后续主动操控位置输出不正确
				FRootMotionMovementParams ExtractedRootMotion;
				ConsumeRootMotionFromAnimation(ExtractedRootMotion);
			}

			DoNotifyCalculatedNetSimulateChanged();
		}
	}
}

FRotator URoleMovementComponent::GetMovementControlRotation()
{
	if (auto* CharacterPlayer = GetCharacterOwner())
	{
		// 相机的部分是带缓动的, 所以会迟滞; GetControlRotation是直接相机目标的Rotation
		// todo 这里等俊杰确认, 是否相机的View rotation一定要往controller rotation上回写
		// 建议是回写,后面做各种镜头模式下的驱动向量, 就在这里做规则
		if (const APlayerController* PC = Cast<APlayerController>(CharacterPlayer->GetController()))
		{
			return PC->PlayerCameraManager->GetCameraCacheView().Rotation;
		}

		// 目前只有玩家会有 Controller
		// 如果 CharacterPlayer 身上拿不到 ControllerPtr 的话,Controller 就未切换 使用 GetWorld()->GetFirstPlayerController() Controller
		if (auto ControllerPtr = GetWorld()->GetFirstPlayerController()) {
			return ControllerPtr->GetControlRotation();
		}
	}

	return FRotator::ZeroRotator;
}

const FName& URoleMovementComponent::GetTrackFloorCollisionPresetName()
{
	if (GetIsMainPlayer())
	{
		return StaticDataInfo.MainPlayerTrackFloorCollisionPresetName;
	}
	return StaticDataInfo.CommonTrackFloorCollisionPresetName;
}

void URoleMovementComponent::DoNotifyCalculatedNetSimulateChanged()
{
	UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement();
	IC7ActorInterface* IC7Actor = Cast<IC7ActorInterface>(CharacterOwner);
	bool bCurIsNetSimulate = GetCurrentIsNetSimulate();
	if (AnimInstance)
	{
		if (bCurIsNetSimulate)
		{
			if (GetClientMoveSyncRole() == EMoveSyncRole::RoleSyncSourceFromOtherClient && !GetServerForcedControl())
			{
				// 普通的P3玩家上行移动包模式时，不需要触发NetSimulateDelayedAnimMovePostureCacheTime
				AnimInstance->DelayedAnimMovePostureCacheTime = StaticDataInfo.LocalDriveDelayedAnimMovePostureCacheTime;
			}
			else
			{
				AnimInstance->DelayedAnimMovePostureCacheTime = StaticDataInfo.NetSimulateDelayedAnimMovePostureCacheTime;
			}
		}
		else
		{
			AnimInstance->DelayedAnimMovePostureCacheTime = StaticDataInfo.LocalDriveDelayedAnimMovePostureCacheTime;
		}
	}

	if (IC7Actor && !GetIsMainPlayer())
	{
		if (bCurIsNetSimulate)
		{
			IC7Actor->DoSetCollisionPresetForRootAndMeshComponents(CharacterOwner, false, NetSimulateRoorPresetName, NetSimulateChildPresetName);
		}
		else
		{
			IC7Actor->DoSetCollisionPresetForRootAndMeshComponents(CharacterOwner, false, DefaultRootPresetName, DefaultChildPresetName);
		}
	}

	if (IsDriveMountDriveAttachStage() && MountRelationCooperator.IsValid())
	{
		if (IC7ActorInterface* MountActorInterface = Cast<IC7ActorInterface>(MountRelationCooperator.Get()->GetOwner()))
		{
			if (bCurIsNetSimulate)
			{
				MountActorInterface->DoSetCollisionPresetForRootAndMeshComponents(MountRelationCooperator.Get()->GetOwner(), false, NetSimulateRoorPresetName, NetSimulateChildPresetName);
			}
			else
			{
				MountActorInterface->DoSetCollisionPresetForRootAndMeshComponents(MountRelationCooperator.Get()->GetOwner(), false, DefaultRootPresetName, DefaultChildPresetName);
			}
		}
	}
}

void URoleMovementComponent::OnServerForcedControlChanged(bool bServerForcedControl)
{
	if (!bServerForcedControl)
	{
		MovementSimulator.FinishSimulate();
	}

	if (GetClientMoveSyncRole() == EMoveSyncRole::RoleSyncSourceFromOtherClient)
	{
		if (GetCurrentIsNetSimulate())
		{
			UBaseAnimInstance* AnimInstance = nullptr;
			IC7ActorInterface* IC7Actor = Cast<IC7ActorInterface>(CharacterOwner);
			if (IC7Actor)
			{
				if (USkeletalMeshComponent* SKMesh = Cast<USkeletalMeshComponent>(IC7Actor->GetMainMesh()))
				{
					AnimInstance = Cast<UBaseAnimInstance>(SKMesh->GetAnimInstance());
				}
			}
			if (AnimInstance)
			{
				if (bServerForcedControl)
				{
					AnimInstance->DelayedAnimMovePostureCacheTime = StaticDataInfo.NetSimulateDelayedAnimMovePostureCacheTime;
				}
				else
				{
					// 普通的P3玩家非ServerForceControl的上行移动包模式时，不需要触发NetSimulateDelayedAnimMovePostureCacheTime
					AnimInstance->DelayedAnimMovePostureCacheTime = StaticDataInfo.LocalDriveDelayedAnimMovePostureCacheTime;
				}
			}
			
		}
	}
}

void URoleMovementComponent::SetUpdatedComponent(USceneComponent* NewUpdatedComponent)
{
	Super::SetUpdatedComponent(NewUpdatedComponent);

	RefreshMeshAdditionalLR();

}

void URoleMovementComponent::EnableMoveTick(bool bEnable)
{
	bEnableMoveTick = bEnable;

	if (!bEnable)
	{
		SetBase(nullptr);
	}
}

void URoleMovementComponent::TeleportTo(const FVector& Location, const FRotator& Rotation, bool bNoCheck)
{
	ALOG_DEBUG_POSITION(this, "URoleMovementComponent::TeleportTo Location[%s]", *Location.ToString());
	Velocity = FVector::ZeroVector;
	LastUpdateLocation = Location;
	LastUpdateRotation = Rotation.Quaternion();
	
	MovementSynchronizer.Clear();
	MovementSimulator.Clear(EMoveSimulateClearReason::Teleport);

	if (CharacterOwner)
	{
		CharacterOwner->TeleportTo(Location, Rotation, true, bNoCheck);
	}
}

bool URoleMovementComponent::GetIsEnableExecuteMotionWarp()
{
	switch (MotionWarpControl)
	{
		case EMotionWarpControlType::ForceEnableMotionWarp:
			return true;
		case EMotionWarpControlType::ForceDisableMotionWarp:
			return false;
		default:
			return !GetCurrentIsNetSimulate();
	}
}

#pragma endregion Important



#pragma region Movement
void URoleMovementComponent::ChangeDisableMovement(bool bDisable)
{
	if (bDisable)
	{
		bDisableMovement = true;
		LocoStopDelayTime = -1.0f;
	}
	else
	{
		bDisableMovement = false;
	}
}

bool URoleMovementComponent::AllowMovement() const
{
	return !bDisableMovement;
}

void URoleMovementComponent::ChangeDisableRotation(bool bDisable)
{
	bDisableRotation = bDisable;
}

bool URoleMovementComponent::AllowRotation() const
{
	return !bDisableRotation;
}

void URoleMovementComponent::ChangeDisableProactiveMovement(bool bDisable)
{
	if (bDisable)
	{
		bDisableProactiveMovement = true;
		LocoStopDelayTime = -1.0f;
	}
	else
	{
		bDisableProactiveMovement = false;
	}
}

bool URoleMovementComponent::AllowProactiveMovement() const
{
	return !bDisableProactiveMovement && AllowMovement();
}

bool URoleMovementComponent::AllowProactiveJump() const
{
	return !bDisableProactiveJump;
}

bool URoleMovementComponent::AllowProactiveDodge() const
{
	return !bDisableProactiveDodge;
}

void URoleMovementComponent::ChangeDisableProactiveRotation(bool bDisable)
{
	bDisableProactiveRotation = bDisable;
}

bool URoleMovementComponent::AllowProactiveRotation() const
{
	return !bDisableProactiveRotation && AllowRotation();
}

void URoleMovementComponent::ChangeDisableProactiveJump(bool bDisable)
{
	bDisableProactiveJump = bDisable;

	SetJumpAllowed(!bDisableProactiveJump);
}

void URoleMovementComponent::ChangeDisableProactiveDodge(bool bDisable)
{
	bDisableProactiveDodge = bDisable;
}

void URoleMovementComponent::ChangeDisableMeshPredict(int64 InSign, bool bDisable)
{
	if (bDisable)
	{
		DisableMeshPredict.AddUnique(InSign);
	}
	else
	{
		DisableMeshPredict.RemoveSwap(InSign);
	}

}

bool URoleMovementComponent::AllowMeshPredict() const
{
	return DisableMeshPredict.Num() <= 0;
}

bool URoleMovementComponent::IsProactiveMoving(bool InCheckRM)
{
	if (InCheckRM && IsRunningRootMotion())
	{
		return false;
	}

	return GetIsLocoStartFromMask() || RoleMP.LocoInputThrusterMC.IsEnabled();
}

bool URoleMovementComponent::IsValidProactiveMoving(bool InCheckRM)
{
	if (InCheckRM && IsRunningRootMotion())
	{
		return false;
	}

	return GetIsLocoStartFromMask() || (RoleMP.LocoInputThrusterMC.IsEnabled() && HasLocoInput());
}

bool URoleMovementComponent::DoJump(bool bReplayingMoves)
{
	bool Result = Super::DoJump(bReplayingMoves);

	if (Result)
	{
		// 正在执行的RMS要缓存一帧Z轴的变化，防止RMS结束时把速度重置为0，如果下一帧RMS没有结束则会自动重置这个变量
		for (const auto& RMS : CurrentRootMotion.RootMotionSources)
		{
			if (RMS.IsValid() && RMS->GetScriptStruct()->IsChildOf(FRootMotionSource_MoveToDynamicForce::StaticStruct()))
			{
				RMS->FinishVelocityParams.SetVelocity.Z = Velocity.Z;
			}
		}
	}

	return Result;
}

// New Feature: Movement Pipeline @sunya 20231220

// 跟 UCharacterMovementComponent::PhysicsRotation一致, 只计算, 不直接引用
FQuat URoleMovementComponent::GetPhysicsWorldRotation(float DeltaTime) {
	if (!UpdatedComponent) {
		return FQuat::Identity;
	}
	FRotator CurrentRotation = UpdatedComponent->GetComponentRotation(); // Normalized
	CurrentRotation.DiagnosticCheckNaN(TEXT("CharacterMovementComponent::PhysicsRotation(): CurrentRotation"));

	if (!(bOrientRotationToMovement || bUseControllerDesiredRotation))
	{
		return FQuat(CurrentRotation);
	}

	if (!HasValidData() || (!CharacterOwner->Controller && !bRunPhysicsWithNoController))
	{
		return FQuat(CurrentRotation);
	}


	FRotator DeltaRot = GetDeltaRotation(DeltaTime);
	DeltaRot.DiagnosticCheckNaN(TEXT("CharacterMovementComponent::PhysicsRotation(): GetDeltaRotation"));

	FRotator DesiredRotation = CurrentRotation;
	if (bOrientRotationToMovement)
	{
		DesiredRotation = ComputeOrientToMovementRotation(CurrentRotation, DeltaTime, DeltaRot);
	}
	else if (CharacterOwner->Controller && bUseControllerDesiredRotation)
	{
		DesiredRotation = CharacterOwner->Controller->GetDesiredRotation();
	}
	else if (!CharacterOwner->Controller && bRunPhysicsWithNoController && bUseControllerDesiredRotation)
	{
		if (AController* ControllerOwner = Cast<AController>(CharacterOwner->GetOwner()))
		{
			DesiredRotation = ControllerOwner->GetDesiredRotation();
		}
	}
	else
	{
		return FQuat(CurrentRotation);
	}

	if (ShouldRemainVertical())
	{
		DesiredRotation.Pitch = 0.f;
		DesiredRotation.Yaw = FRotator::NormalizeAxis(DesiredRotation.Yaw);
		DesiredRotation.Roll = 0.f;
	}
	else
	{
		DesiredRotation.Normalize();
	}

	// Accumulate a desired new rotation.
	const float AngleTolerance = 1e-3f;

	if (!CurrentRotation.Equals(DesiredRotation, AngleTolerance))
	{
		// PITCH
		if (!FMath::IsNearlyEqual(CurrentRotation.Pitch, DesiredRotation.Pitch, AngleTolerance))
		{
			DesiredRotation.Pitch = FMath::FixedTurn(CurrentRotation.Pitch, DesiredRotation.Pitch, DeltaRot.Pitch);
		}

		// YAW
		if (!FMath::IsNearlyEqual(CurrentRotation.Yaw, DesiredRotation.Yaw, AngleTolerance))
		{
			DesiredRotation.Yaw = FMath::FixedTurn(CurrentRotation.Yaw, DesiredRotation.Yaw, DeltaRot.Yaw);
		}

		// ROLL
		if (!FMath::IsNearlyEqual(CurrentRotation.Roll, DesiredRotation.Roll, AngleTolerance))
		{
			DesiredRotation.Roll = FMath::FixedTurn(CurrentRotation.Roll, DesiredRotation.Roll, DeltaRot.Roll);
		}

		// Set the new rotation.
		DesiredRotation.DiagnosticCheckNaN(TEXT("CharacterMovementComponent::PhysicsRotation(): DesiredRotation"));
	}

	return FQuat(DesiredRotation);
}

void URoleMovementComponent::SwitchOnLocoYawController(EMovementOutputMode outputMode, EInterpolationMode interMode, float interArgValue, EArgSourceMode inputSourceMode, float fixValue, const FVector& targetPos, int64 InActorID)
{
	RoleMP.LocoYawController.SetCalculateModes(outputMode, interMode, interArgValue);

	if (inputSourceMode == EArgSourceMode::FixedValue || inputSourceMode == EArgSourceMode::FixedDeltaSpeed) {
		RoleMP.LocoYawController.SetTargetYaw(fixValue);
		//return;
	}

	if (inputSourceMode == EArgSourceMode::TargetPos) {
		RoleMP.LocoYawController.SetTargetPos(targetPos);
		//return;
	}

	if (inputSourceMode == EArgSourceMode::TargetActor) {
		UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this);
		if (!UOAM)
		{
			return;
		}

		AActor* targetActor = Cast<AActor>(UOAM->GetObjectByID(InActorID));
		RoleMP.LocoYawController.SetTargetActor(targetActor);
		//return;
	}
	RoleMP.LocoYawController.SetArgSourceMode(inputSourceMode);
	if (!RoleMP.LocoYawController.IsSwitchOn())
	{
		RoleMP.LocoYawController.Reset();
		RoleMP.LocoYawController.SwitchOn();
	}
}

void URoleMovementComponent::UpdateLocoYawControllerInterpValue(const float& interArgValue)
{
	RoleMP.LocoYawController.SetInterpolationArg(interArgValue);
}

void URoleMovementComponent::SetLocoYawControllerUseLastValidInputWhenLostInput(bool InbUse)
{
	RoleMP.LocoYawController.SetUseLastValidInputWhenLostInput(InbUse);
}

void URoleMovementComponent::SwitchOffLocoYawController()
{
	if (RoleMP.LocoYawController.IsSwitchOn())
	{
		RoleMP.LocoYawController.SwitchOff();
	}
}
// ===========================================todo Thruster 的操作的API暴露, 很繁琐, 要统一处理下 @孙亚 20250825===================================
bool URoleMovementComponent::GetInputThrusterIsSwitchedOn() {
	return RoleMP.LocoInputThrusterMC.IsSwitchedOn();
}

void URoleMovementComponent::SwitchOnLocoInputThruster(float OverrideMaxSpeed, float OverrideMaxAcce, float OverrideMaxBrakingDeccVel,
	bool bUseSpecificInitVel, float SpecificVelX, float SpecificVelY, float SpecificVelZ)
{
	if (GetInputThrusterIsSwitchedOn())
	{
		return;
	}

	RoleMP.LocoInputThrusterMC.Reset();
	RoleMP.LocoInputThrusterMC.SetEnable(true);

	UpdateLocoInputThrusterArgs(OverrideMaxSpeed, OverrideMaxAcce, OverrideMaxBrakingDeccVel, bUseSpecificInitVel, SpecificVelX, SpecificVelY, SpecificVelZ);
}

void URoleMovementComponent::UpdateLocoInputThrusterArgs(float OverrideMaxSpeed, float OverrideMaxAcce, float OverrideMaxBrakingDeccVel,
	bool bUseSpecificInitVel, float SpecificVelX, float SpecificVelY, float SpecificVelZ)
{
	if (bUseSpecificInitVel)
	{
		RoleMP.LocoInputThrusterMC.SetCurVelocity(FVector(SpecificVelX, SpecificVelY, SpecificVelZ), GetLocoMaxSpeed());
	}
	else
	{
		RoleMP.LocoInputThrusterMC.SetCurVelocity(GetMovementVelocity(), GetLocoMaxSpeed());
	}
	RoleMP.LocoInputThrusterMC.SetMaxSpeed(OverrideMaxSpeed);
	RoleMP.LocoInputThrusterMC.SetMaxAccelerate(OverrideMaxAcce);
	RoleMP.LocoInputThrusterMC.SetMaxBrakingDeceleration(OverrideMaxBrakingDeccVel);
}

void URoleMovementComponent::UpdateLocoInputThrusterCurVelocity(float SpecificVelX, float SpecificVelY, float SpecificVelZ)
{
	RoleMP.LocoInputThrusterMC.SetCurVelocity(FVector(SpecificVelX, SpecificVelY, SpecificVelZ), GetLocoMaxSpeed());
}

void URoleMovementComponent::SetLocoInputThrusterOrientationAdjustHalfTime(float InOrientationAdjustHalfTime)
{
	RoleMP.LocoInputThrusterMC.SetOrientationAdjustHalfTime(InOrientationAdjustHalfTime);
}

void URoleMovementComponent::SetLocoInputThrusterGlideMainSpeedRate(float InMainSpeedRate)
{
	StaticDataInfo.GlideThrusterMainSpeedRate = FMath::Clamp(InMainSpeedRate, 0.0f, 1.0f);
	StaticDataInfo.GlideThrusterSideSpeedRate = 0.5f * (1.0 - StaticDataInfo.GlideThrusterMainSpeedRate);
}

void URoleMovementComponent::SetLocoInputThrusterGlideSideSpeedAdjustDeltaYaw(float InAdjustDeltaYaw)
{
	StaticDataInfo.GlideThrusterAdjustDeltaYaw = FMath::Clamp(InAdjustDeltaYaw, 0.0f, 90.0f);
}

void URoleMovementComponent::SetLocoInputThrusterGlideSideAcceAndDece(float InSideSpeedAcceleration, float InSideSpeedDeceleration)
{
	StaticDataInfo.GlideThrusterSideSpeedAcce = FMath::Max(InSideSpeedAcceleration, 0.0f);
	StaticDataInfo.GlideThrusterSideSpeedDece = FMath::Max(InSideSpeedDeceleration, 0.0f);
}

EInputThrusterAdjustMode URoleMovementComponent::SetLocoInputThrusterSpeedAdjustModeWeakValue(EInputThrusterAdjustMode InSpeedAdjustMode)
{
	return RoleMP.LocoInputThrusterMC.SetSpeedAdjustModeWeakValue(InSpeedAdjustMode, GetLocoMaxSpeed());
}

EInputThrusterAdjustMode URoleMovementComponent::SetLocoInputThrusterSpeedAdjustModeForceValue(EInputThrusterAdjustMode InSpeedAdjustMode)
{
	return RoleMP.LocoInputThrusterMC.SetSpeedAdjustModeForceValue(InSpeedAdjustMode, GetLocoMaxSpeed());
}

EInputThrusterAdjustMode URoleMovementComponent::ClearLocoInputThrusterSpeedAdjustModeForceValue()
{
	return RoleMP.LocoInputThrusterMC.ClearSpeedAdjustModeForceValue(GetLocoMaxSpeed());
}

EInputThrusterAdjustMode URoleMovementComponent::ResetLocoInputThrusterSpeedAdjustMode()
{
	return RoleMP.LocoInputThrusterMC.ResetSpeedAdjustMode(GetLocoMaxSpeed());
}

void URoleMovementComponent::SwitchOffLocoInputThruster()
{
	if (!GetInputThrusterIsSwitchedOn())
	{
		return;
	}

	RoleMP.LocoInputThrusterMC.SetEnable(false);
}

void URoleMovementComponent::ClearInputThrusterFadeOutEffect()
{
	RoleMP.LocoInputThrusterMC.ClearFadeOutEffect();
}

bool URoleMovementComponent::GetPositionAdditiveThrusterIsSwitchedOn() {
	return RoleMP.PositionAdditiveITMC.IsSwitchedOn();
}

void URoleMovementComponent::SwitchOnPositionAdditiveThruster(float OverrideMaxSpeed, float OverrideMaxAcce, float OverrideMaxBrakingDeccVel,
	bool bUseSpecificInitVel, float SpecificVelX, float SpecificVelY, float SpecificVelZ)
{
	if (GetPositionAdditiveThrusterIsSwitchedOn())
	{
		return;
	}

	RoleMP.PositionAdditiveITMC.Reset();
	RoleMP.PositionAdditiveITMC.SetEnable(true);
	
	// 用于追逐战需求，与PositionAdditiveThruster生命周期强绑定
	RoleMP.GetMovementContext().SetIsAllowOffsetAbsoluteWorldPos(true);

	UpdatePositionAdditiveThrusterArgs(OverrideMaxSpeed, OverrideMaxAcce, OverrideMaxBrakingDeccVel, bUseSpecificInitVel, SpecificVelX, SpecificVelY, SpecificVelZ);
}

void URoleMovementComponent::UpdatePositionAdditiveThrusterArgs(float OverrideMaxSpeed, float OverrideMaxAcce, float OverrideMaxBrakingDeccVel,
	bool bUseSpecificInitVel, float SpecificVelX, float SpecificVelY, float SpecificVelZ)
{
	if (bUseSpecificInitVel)
	{
		RoleMP.PositionAdditiveITMC.SetCurVelocity(FVector(SpecificVelX, SpecificVelY, SpecificVelZ), GetLocoMaxSpeed());
	}
	else
	{
		RoleMP.PositionAdditiveITMC.SetCurVelocity(GetMovementVelocity(), GetLocoMaxSpeed());
	}
	RoleMP.PositionAdditiveITMC.SetMaxSpeed(OverrideMaxSpeed);
	RoleMP.PositionAdditiveITMC.SetMaxAccelerate(OverrideMaxAcce);
	RoleMP.PositionAdditiveITMC.SetMaxBrakingDeceleration(OverrideMaxBrakingDeccVel);
}

void URoleMovementComponent::UpdatePositionAdditiveThrusterMode(EMovementSpace MS, float XScale, float YScale, float ZScale, float MoveDistLimited)
{
	RoleMP.PositionAdditiveITMC.SetLimitedRadius(MoveDistLimited);
	RoleMP.PositionAdditiveITMC.SetAllowAxisMove(XScale, YScale, ZScale);
	RoleMP.PositionAdditiveITMC.SetMovementSpace(MS);
}

void URoleMovementComponent::SetPositionAdditiveThrusterSpeedAdjustMode(EInputThrusterAdjustMode InSpeedAdjustMode)
{
	RoleMP.PositionAdditiveITMC.SetSpeedAdjustMode(InSpeedAdjustMode, GetLocoMaxSpeed());
}

void URoleMovementComponent::SwitchOffPositionAdditiveThruster(bool NeedPositionAdditiveFadeOut, float FadeOutTime)
{
	if (!GetPositionAdditiveThrusterIsSwitchedOn())
	{
		return;
	}

	if(NeedPositionAdditiveFadeOut)
	{
		RoleMP.PositionAdditiveITMC.SetSwitchOffFadeOutTime(FadeOutTime);	
	}
	else
	{
		RoleMP.PositionAdditiveITMC.SetEnable(false);
	}

	// 用于追逐战需求，与PositionAdditiveThruster生命周期强绑定
	RoleMP.GetMovementContext().SetIsAllowOffsetAbsoluteWorldPos(false);
}

void URoleMovementComponent::ClearPositionAdditiveThrusterFadeOutEffect()
{
	RoleMP.PositionAdditiveITMC.ClearFadeOutEffect();
}


// ===========================================todo Thruster 的操作的API暴露, 很繁琐, 要统一处理下 @孙亚 20250825===================================

bool URoleMovementComponent::GetGravationalThrusterIsSwitchedOn()
{
	return RoleMP.GravationalThrusterMC.IsEnabled();
}

void URoleMovementComponent::AddGravationalMsg(float InCenterLocX, float InCenterLocY, float InCenterLocZ, float InMaxGravationalSpeed, int64 InGUID, bool InAllowZGravational)
{
	RoleMP.GravationalThrusterMC.AddGravationalInfo(InCenterLocX, InCenterLocY, InCenterLocZ, InMaxGravationalSpeed, InGUID, InAllowZGravational);
}

void URoleMovementComponent::RemoveGravationalMsg(int64 InGUID)
{
	RoleMP.GravationalThrusterMC.RemoveGravationalInfo(InGUID);
}

void URoleMovementComponent::ClearAllGravationalMsg()
{
	RoleMP.GravationalThrusterMC.SetEnable(false);
}

void URoleMovementComponent::RotateInstantlyByMovePipeline(FRotator InRotator)
{
	// 对于怪物不需要做这个
	// 因为bNeedRotateInstantly的重置是在是在RotateInstantlyTargetRotator消耗的地方，而消耗需要!isNetSimulate才会触发
	// 因此对于怪物如果设置了此处，可能在一段时间后当isNetSimulate时使用了此次设置的InRotator
	// BUG #198337
	if (eMoveSyncRole == EMoveSyncRole::RoleSyncSourceFromOwnClient) {
		RoleMP.GetMovementContext().SetNeedRotateInstantly(InRotator);
	}
}

void URoleMovementComponent::SetMovePipelineRotationOutputMask(bool AllowPitch, bool AllowYaw, bool AllowRoll)
{
	RoleMP.GetMovementContext().SetRotationOutputMask(AllowPitch, AllowYaw, AllowRoll);
}

#pragma region Corrector
EMovementCorrectorType URoleMovementComponent::GetActiveMoveCorrectorType()
{
	return RoleMP.MovementCorrectorManager.GetActiveType();
	
}

bool URoleMovementComponent::ForceActivateMoveCorrector(EMovementCorrectorType mcType)
{
	return RoleMP.MovementCorrectorManager.ForceActivateMoveCorrector(mcType);
}

bool URoleMovementComponent::ForceDeActivateMoveCorrector(EMovementCorrectorType mcType)
{
	return RoleMP.MovementCorrectorManager.ForceDeActivateMoveCorrector(mcType);
}

int URoleMovementComponent::ObtainMoveCorrector(ECorrectorObtainPriority pri, EMovementCorrectorType mcType)
{
	return RoleMP.MovementCorrectorManager.ObtainMoveCorrector(pri, mcType);
}

bool URoleMovementComponent::ReleaseMoveCorrector(int releasedToken, EMovementCorrectorType mcType)
{
	return RoleMP.MovementCorrectorManager.ReleaseMoveCorrector(releasedToken, mcType);
}


void URoleMovementComponent::SetMountType(int MountType, bool bMountRider)
{
	// 设置玩家数据
	RoleMP.GetMovementContext().SetMountType(MountType);
	if (UBaseAnimInstance* AnimIns = GetAnimInstanceForMovement())
	{
		AnimIns->SetMountType(MountType);
		AnimIns->SetIsMountRider(bMountRider);
	}

	// 设置坐骑数据
	if (MountRelationCooperator.IsValid())
	{
		MountRelationCooperator->RoleMP.GetMovementContext().SetMountType(MountType);
		if (MountRelationCooperator->IsMount())
		{
			MountRelationCooperator->bMainPlayerMount = GetIsMainPlayer();

			int MaxSpeed = SpeedStages.Num() == 3 ? SpeedStages[2] : GetMaxSpeed();
			MaxSpeed = FMath::Max(MaxSpeed, 1);
			MountRelationCooperator->MountMaxSpeed = MaxSpeed;
			MountRelationCooperator->UpdateMountAKEventStatus(true);
		}
		
		if (UCarrierAnimInstance* MountAnimIns = Cast<UCarrierAnimInstance>(MountRelationCooperator->GetAnimInstanceForMovement()))
		{
			MountAnimIns->SetMountType(MountType);
			MountAnimIns->SetIsMountRider(bMountRider);
		}
	}
}

void URoleMovementComponent::SetRealMountDeltaYawScale(float InScalse)
{
	RoleMP.GetMovementContext().SetRealMountDeltaYawScale(InScalse);
}

void URoleMovementComponent::SetMountMaxDeltaYaw(float InMaxDeltaYaw)
{
	RoleMP.GetMovementContext().SetMountMaxDeltaYaw(InMaxDeltaYaw);
}

void URoleMovementComponent::SetMountLength(float InFrontLength, float InEndLength)
{
	RoleMP.GetMovementContext().SetMountLength(InFrontLength, InEndLength);
}

void URoleMovementComponent::SetMountWheelMoveAngle(float InFrontAngle, float InEndAngle)
{
	RoleMP.GetMovementContext().SetMountMoveAngle(InFrontAngle, InEndAngle);
}

void URoleMovementComponent::SetRideMountCorrectorDirInterpolateParam(float InValue)
{
	RoleMP.MovementCorrectorManager.SetRideMountCorrectorDirInterpolateParam(InValue);
}

void URoleMovementComponent::SetRideMountCorrectorSpeedToRidingDirInterpolateCurve(KGObjectID InCurveID)
{
	if (UCurveFloat* Curve = Cast<UCurveFloat>(KGUtils::GetObjectByID(InCurveID)))
	{
		RoleMP.MovementCorrectorManager.SetRideMountCorrectorSpeedToRidingDirInterpolateCurve(Curve);
	}
}

void URoleMovementComponent::SetRideMountCorrectorSpeedToMaxDriftSpeedCurve(KGObjectID InCurveID)
{
	if (UCurveFloat* Curve = Cast<UCurveFloat>(KGUtils::GetObjectByID(InCurveID)))
	{
		RoleMP.MovementCorrectorManager.SetRideMountCorrectorSpeedToMaxDriftSpeedCurve(Curve);
	}
}

void URoleMovementComponent::SetRideMountCorrectorDriftSpeedRateToSpeedDecayCurve(KGObjectID InCurveID)
{
	if (UCurveFloat* Curve = Cast<UCurveFloat>(KGUtils::GetObjectByID(InCurveID)))
	{
		RoleMP.MovementCorrectorManager.SetRideMountCorrectorDriftSpeedRateToSpeedDecayCurve(Curve);
	}
}

void URoleMovementComponent::SetRideMountCorrectorSpeedToDriftForceDecayHalfTimeCurve(KGObjectID InCurveID)
{
	if (UCurveFloat* Curve = Cast<UCurveFloat>(KGUtils::GetObjectByID(InCurveID)))
	{
		RoleMP.MovementCorrectorManager.SetRideMountCorrectorSpeedToDriftForceDecayHalfTimeCurve(Curve);
	}
}

void URoleMovementComponent::SetRideMountCorrectorSpeedToDriftForceYawHalfTimeCurve(KGObjectID InCurveID)
{
	if (UCurveFloat* Curve = Cast<UCurveFloat>(KGUtils::GetObjectByID(InCurveID)))
	{
		RoleMP.MovementCorrectorManager.SetRideMountCorrectorSpeedToDriftForceYawHalfTimeCurve(Curve);
	}
}

void URoleMovementComponent::SetRideMountCorrectorAllowDrift(bool InAllow)
{
	RoleMP.MovementCorrectorManager.SetRideMountCorrectorAllowDrift(InAllow);
	RoleMP.GetMovementContext().SetAllowDrift(InAllow);
}

void URoleMovementComponent::SetRideMountCorrectorLeftWheelToCenterDist(float InValue)
{
	RoleMP.MovementCorrectorManager.SetRideMountCorrectorLeftWheelToCenterDist(InValue);
}

void URoleMovementComponent::SetRideMountCorrectorRightWheelToCenterDist(float InValue)
{
	RoleMP.MovementCorrectorManager.SetRideMountCorrectorRightWheelToCenterDist(InValue);
}

void URoleMovementComponent::SetMountRadius(float InFrontRadius, float InEndRadius)
{
	RoleMP.GetMovementContext().SetMountRadius(InFrontRadius, InEndRadius);
}

void URoleMovementComponent::SetRidingPostureParam(int64 SkeletalMeshID, float PitchHalfTime, float RootUpHalfTime)
{
	RoleMP.GetMovementContext().SetRidingPostureParam(SkeletalMeshID, PitchHalfTime, RootUpHalfTime);
}

void URoleMovementComponent::SetRidingWheelParam(FName FWheelName, FName RWheelName)
{
	RoleMP.GetMovementContext().SetRidingWheelParam(FWheelName, RWheelName);
}

int URoleMovementComponent::ObtainMotionWarpForRotationWithFixMode(ECorrectorObtainPriority pri, int transOperateMask, const float pitch, const float targetYaw, const float roll) {

	return RoleMP.MovementCorrectorManager.ObtainRotationWarpWithFixMode(pri, RoleMP.GetMovementContext(), transOperateMask, pitch, targetYaw, roll);
}

int URoleMovementComponent::ObtainMotionWarpForTranslationWithFixMode(ECorrectorObtainPriority pri, FVector targetpos, ERootWarpMode rootMotionMode, const FName& WarpTargetName) {

	return RoleMP.MovementCorrectorManager.ObtainTranslationWarpWithFixMode(pri, RoleMP.GetMovementContext(), targetpos, rootMotionMode, WarpTargetName);
}

void URoleMovementComponent::UpdateTargetPosAndRotation(const FVector& targetpos, const FRotator& targetRot)
{
	RoleMP.MovementCorrectorManager.UpdateTargetPosAndRotation(targetpos, targetRot);
}

bool URoleMovementComponent::UpdateRotationWarpArgWithFixMode(int mcToken, int transOperateMask, const float pitch, const float targetYaw, const float roll) {
	return RoleMP.MovementCorrectorManager.UpdateRotationWarpArgWithFixMode(mcToken, RoleMP.GetMovementContext(), transOperateMask, pitch, targetYaw, roll);
}

bool URoleMovementComponent::UpdateWarpRate(int mcToken, float Rate) {
	return RoleMP.MovementCorrectorManager.UpdateWarpRate(mcToken, Rate);
}

int URoleMovementComponent::ObtainMotionWarpWithActorSocket(ECorrectorObtainPriority pri, ERootWarpMode rootWarpMode, int64 EntityID, const FName& SocketName, const FVector& Offset)
{
	TWeakObjectPtr<AActor> Actor = KGUtils::GetActorByID(EntityID);
	if (Actor.IsValid())
	{
		return RoleMP.MovementCorrectorManager.ObtainMotionWarpWithActorSocket(pri, RoleMP.GetMovementContext(), rootWarpMode, Actor, SocketName, Offset);	
	}
	return -1;
}

int URoleMovementComponent::ObtainMotionWarpWithActorSpaceTransform(ECorrectorObtainPriority pri, ERootWarpMode rootWarpMode, int64 EntityID, const FTransform& targetTransformInActorSpace)
{
	if (auto Entity = UKGUEActorManager::GetLuaEntity(GetWorld(), EntityID))
	{
		if (AActor* Actor = Entity->GetLuaEntityBase()->GetActor())
		{
			return RoleMP.MovementCorrectorManager.ObtainMotionWarpWithActorSpaceTransform(pri, RoleMP.GetMovementContext(), rootWarpMode, Actor, targetTransformInActorSpace);	
		}
	}
	return -1;
}

int URoleMovementComponent::ObtainRotationWarpWithLocoInputMode(ECorrectorObtainPriority pri, const float inputQueryDuration, EFaceDirectionInputMode FaceMode)
{
	LocoInputModeRotationMotionWarpToken = RoleMP.MovementCorrectorManager.ObtainRotationWarpWithLocoInputMode(pri, RoleMP.GetMovementContext(), inputQueryDuration, FaceMode);
	return LocoInputModeRotationMotionWarpToken;
}

bool URoleMovementComponent::ReleaseMotionWarp(int mcToken)
{
	return RoleMP.MovementCorrectorManager.ReleaseMotionWarp(mcToken);
}

int URoleMovementComponent::ObtainTwoRoleAnimCoordinateMC(KGAnimPlayReqID OwnAnimID, KGAnimPlayReqID CollaboratorAnimID, KGEntityID CollaboratorUID, bool EnsurePhysicsSafe, float InterTime)
{
	return RoleMP.MovementCorrectorManager.ObtainTwoRoleAnimCoordinateMC(OwnAnimID, CollaboratorAnimID, CollaboratorUID, EnsurePhysicsSafe, InterTime);
}
bool URoleMovementComponent::ReleaseTwoRoleAnimCoordinateMC(int Token)
{
	return RoleMP.MovementCorrectorManager.ReleaseTwoRoleAnimCoordinateMC(Token);
}

void URoleMovementComponent::SetDestSmoothCorrectorParam(float InSmoothTime, float InHalfTime)
{
	RoleMP.MovementCorrectorManager.SetDestSmoothCorrectorParam(InSmoothTime, InHalfTime);
}

void URoleMovementComponent::SetDestSmoothCorrectorType(ESmoothCorrectorType Type, float Speed)
{
	RoleMP.MovementCorrectorManager.SetDestSmoothCorrectorType(Type, Speed);
}

void URoleMovementComponent::SetDestLocSmoothParam(const FVector InStartPos, const FVector InEndPos)
{
	RoleMP.MovementCorrectorManager.SetDestLocSmoothParam(InStartPos, InEndPos);
}

void URoleMovementComponent::SetDestRotSmoothParam(float InStartYaw, float InEndYaw)
{
	RoleMP.MovementCorrectorManager.SetDestRotSmoothParam(InStartYaw, InEndYaw);
}

void URoleMovementComponent::SetDestSmoothTargetActor(int64 InTargetEntityId)
{
	if (auto Entity = UKGUEActorManager::GetLuaEntity(GetWorld(), InTargetEntityId))
	{
		if (AActor* Actor = Entity->GetLuaEntityBase()->GetActor())
		{
			RoleMP.MovementCorrectorManager.SetDestSmoothTargetActor(Actor);
		}
	}
}

int URoleMovementComponent::ObtainPitchAdjustCorrector(
	float XForward, float YForward, float XBackward, float YBackward, float MinHeight, float MaxHeight, float DetectDistance, float HalflifeTime, TArray<int32>  DetectObjectTypes)
{
	return RoleMP.PostureCorrectorManager.ObtainPitchAdjustCorrector(XForward, YForward, XBackward, YBackward, MinHeight, MaxHeight, DetectDistance, HalflifeTime, DetectObjectTypes);
}
void URoleMovementComponent::ReleasePitchAdjustCorrector(int Token)
{
	RoleMP.PostureCorrectorManager.ReleasePitchAdjustCorrector(Token);
}

int URoleMovementComponent::ObtainSplineStationController(const FString InSplineInsID, const float InMaxSpeed, const uint8 InMoveFlag)
{
	int32 Token = SplineController.ObtainSplineStationController(InSplineInsID, InMaxSpeed, InMoveFlag);
	bAllowMoveWithSpline = Token > 0;
	return Token;
}
void URoleMovementComponent::ReleaseSplineStationController(int Token)
{
	bAllowMoveWithSpline = SplineController.ReleaseSplineStationController(Token);
}

bool URoleMovementComponent::RestartSplineStationController(int Token, uint8 MoveFlag)
{
	return SplineController.RestartSplineStationController(Token, MoveFlag);
}

void URoleMovementComponent::SetWaterMovementCorrectorWaterSurfaceDelta(const float& InDelta, const float& InDuration)
{
	RoleMP.MovementCorrectorManager.SetWaterMovementCorrectorWaterSurfaceDelta(InDelta, InDuration);
}
#pragma endregion Corrector

void URoleMovementComponent::SetLocoInputToSurfModifyMode(float InMinAcceAngle, float InMaxAcceAngle, float InMinAdjustAngle, float InMaxAdjustAngle)
{
	MinAcceAngle = InMinAcceAngle;
	MaxAcceAngle = InMaxAcceAngle;
	MinAdjustAngle = InMinAdjustAngle;
	MaxAdjustAngle = InMaxAdjustAngle;
	LocoInputModifyMode = ELocoInputModifyMode::SurfModifyMode;
}

void URoleMovementComponent::SetLocoInputToNoModifyMode()
{
	LocoInputModifyMode = ELocoInputModifyMode::NoModifyMode;
}

void URoleMovementComponent::SetLocoInputToInputForwardModifyMode()
{
	LocoInputModifyMode = ELocoInputModifyMode::InputForwardModifyMode;
}

bool URoleMovementComponent::ConsumeRootMotionFromAnimation(FRootMotionMovementParams& ExtractedRootMotion) {
	UBaseAnimInstance* baseAnimInst = GetAnimInstanceForMovement();
	if (!baseAnimInst) {
		return false;
	}

	baseAnimInst->ConsumeRootMotionFromAnimation(ExtractedRootMotion);

	return true;
}


// 具有坐骑关系时, 确定真正的移动对象, 它可以提供rootmotion、操控notify等信息给移动权威控制者, 在其Pipeline中进行计算
URoleMovementComponent* URoleMovementComponent::GetRealMovementViewProxy() {
	// 载具自己就是真正移动者
	if(eMoveDriveRelation  == EMoveDriveRelation::DriveVehicleAsCarrier)
	{
		return this;
	}
	
	if (MountRelationCooperator.IsValid()) {
		bool IsRider = (eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsRiderStart  && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsRiderEnd);
		bool IsPassenger = (eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsPassengerStart  && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsPassengerEnd);
		bool bVehicleRider = IsVehicleDriver();
		// Rider和Passenger的Cooperator是 坐骑Carrier
		if(IsRider || IsPassenger || bVehicleRider)
		{
			return MountRelationCooperator.Get();
		}
	}
	return this;
}

// 移动真正的操控权威者, 权威者根据逻辑状态、各种移动开关来执行MovementPipeline, 结合GetRealMovementViewProxy来计算其最终的移动位置, 其移动后通过挂接的方式带着panssgenger和rider走
URoleMovementComponent* URoleMovementComponent::GetRealMovementControlViewProxy()
{
	if(eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsCarrier)
	{
		
	// 载具自己就是权威的操控Entity单位
		return this;
	}

	//坐骑关系中, Rider自己是权威者
	if(eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsRiderStart && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsRiderEnd )
	{
		// 坐骑时, Rider是真正的操控Entity
		return this;
	}
	
	if(MountRelationCooperator.IsValid())
	{
		// 载具关系中, 权威者是载具自己
		if(eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsPassenger || eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsRider)
		{
			return MountRelationCooperator.Get();
		}
	
		// 坐骑关系中, 乘客、Carrier的权威者是Rider
		if(eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsPassengerStart && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsPassengerEnd)
		{
			// Passenger的Cooperator是坐骑, 坐骑的权威操控者就是Rider
			return MountRelationCooperator->GetRealMovementControlViewProxy();
		}

		if(eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsCarrierStart && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsCarrierEnd){
			// 自己是坐骑, 权威操控者是Rider; 坐骑的Cooperator是Rider
			return MountRelationCooperator.Get();
		}
	}

	return this;
}

URoleMovementComponent* URoleMovementComponent::GetMountRiderMovementViewProxy()
{
	if (eMoveDriveRelation == EMoveDriveRelation::DriveMountAsCarrier && MountRelationCooperator.IsValid()) {
		return MountRelationCooperator.Get();
	}
	return this;
}

bool URoleMovementComponent::CalculateMovementFromAnimRootMotion(MovementContext& MovementContext, FTransform& ExtractTrandform)
{
	// todo:
	//     1) 需要做运动的Delta、绝对世界位置互斥检查/处理
	//     2) LogicRuleMovement的运动计算器种类扩充
	//	   3) WorldPositionDelta、WorldRotDelta的修整器机制制作

	// 1. 进行数据源抽取, 可以来自于网络/动画/寻路
	//    开启了RootMotionFromEverything, Montange的中的sequence也会在多线程上被extract, 不需要再单独进行TickPose处理


	// 自己的RootMotion也要消耗, 避免数据累积
	FRootMotionMovementParams ExtractedRootMotion;
	bool isConsumed = ConsumeRootMotionFromAnimation(ExtractedRootMotion);

	// 骑乘机制里, RootMotion来源于坐骑
	if (IsDriveMountDriveAttachStage() && bRootMotionFromMountCarrier) {
		if (!MountRelationCooperator.IsValid()) {
#if !UE_BUILD_SHIPPING
			UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::CalculateMovementFromAnimRootMotion: Unexpected MountRelationCooperator lifetime."));
#endif
			return false;

		}
		return MountRelationCooperator->CalculateMovementFromAnimRootMotion(MovementContext, ExtractTrandform);

	}


	if (!isConsumed || !ExtractedRootMotion.bHasRootMotion)
	{
		return false;
	}
	ExtractTrandform = ExtractedRootMotion.GetRootMotionTransform();
	return true;
}

void URoleMovementComponent::ApplyAnimRootMotionTransform(MovementContext& MovementContext, const FTransform& InExtractTrandform, FVector& translationDelta, FQuat& rotDelta)
{
	if (IsDriveMountDriveAttachStage() && MountRelationCooperator.IsValid() && bRootMotionFromMountCarrier) {
		MountRelationCooperator->ApplyAnimRootMotionTransform(MovementContext, InExtractTrandform, translationDelta, rotDelta);
		return;
	}
	
	MovementContext.SetRootmotionDeltaTransLocalSpace(InExtractTrandform);
	auto* Mesh = CharacterOwner->GetMesh();
	FTransform WorldTransform = Mesh->ConvertLocalRootMotionToWorld(InExtractTrandform);
	// 目前所有动画Rootmotion应该都为动画状态机的主动移动触发
	translationDelta = WorldTransform.GetTranslation();
	rotDelta = WorldTransform.GetRotation();

#if UE_BUILD_DEVELOPMENT
	MovementContext.SetRootTransform(InExtractTrandform);
#endif //  UE_BUILD_DEVELOPMENT
}

bool URoleMovementComponent::CalculateMovementFromRoomMotionSources(float timeTick, FVector& translationDelta, FQuat& rotDelta)
{
	if (CurRootMotionContext.CurRootMotion.IsValid())
	{
		CurRootMotionContext.CurRootMotion->Update(timeTick, *CharacterOwner, translationDelta, rotDelta);
		// 检查是否已经结束
		if (CurRootMotionContext.CurRootMotion->IsFinish())
		{
			StopCurrentMove();
		}
		return true;
	}
	if (!CurrentRootMotion.HasActiveRootMotionSources())
	{
		return false;
	}

	// 抽取RootMotionSource的位移, 其最终输出都是在世界空间下
	// 脚本的KCB_NotifyParabolaRootMotionStopped已经没有实现了，这里暂时屏蔽，有需要再恢复
	/*for (auto RootMotionSource : CurrentRootMotion.RootMotionSources)
	{
		if (RootMotionSource.Get()->Status.HasFlag(ERootMotionSourceStatusFlags::Finished) || RootMotionSource.Get()->Status.HasFlag(ERootMotionSourceStatusFlags::MarkedForRemoval))
		{
			if (RootMotionSource.Get()->GetScriptStruct() == FC7RootMotionSource_MoveParabola::StaticStruct())
			{
				if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
				{
					ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyParabolaRootMotionStopped");
				}
			}
		}
	}*/
	CurrentRootMotion.CleanUpInvalidRootMotion(timeTick, *CharacterOwner, *this);
	CurrentRootMotion.PrepareRootMotion(timeTick, *CharacterOwner, *this, true);


	// 清理、新增操作之后, 无有效source
	if (!CurrentRootMotion.HasActiveRootMotionSources())
	{
		return false;
	}

	// Apply override velocity
	if (CurrentRootMotion.HasOverrideVelocity())
	{
		OverrideVelocityWorldSpaceRMS = FVector::ZeroVector;
		CurrentRootMotion.AccumulateOverrideRootMotionVelocity(timeTick, *CharacterOwner, *this, OverrideVelocityWorldSpaceRMS);
		translationDelta = OverrideVelocityWorldSpaceRMS * timeTick;

		FQuat RootMotionRotationQuat = FQuat::Identity;
		CurrentRootMotion.GetOverrideRootMotionRotation(timeTick, *CharacterOwner, *this, RootMotionRotationQuat);
		rotDelta = RootMotionRotationQuat;
	}

	// Next apply additive root motion
	if (CurrentRootMotion.HasAdditiveVelocity())
	{
		AdditiveVelocityWorldSpaceRMS = FVector::ZeroVector;
		CurrentRootMotion.AccumulateAdditiveRootMotionVelocity(timeTick, *CharacterOwner, *this, AdditiveVelocityWorldSpaceRMS);
		CurrentRootMotion.bIsAdditiveVelocityApplied = true; // Remember that we have it applied
		translationDelta += AdditiveVelocityWorldSpaceRMS * timeTick;
	}

	return true;
}

bool URoleMovementComponent::DoLocoJump() {
	GravityVelocity.Z = JumpZVelocity;
 	SetMovementMode(MOVE_Falling);

	return true;
}

void URoleMovementComponent::OnScriptDoLocoJump(bool bNeedDoLocoJump, bool bNeedOverrideJumpZVel, float OverrideJumpZVel)
{
	URoleMovementComponent* RealMoveProxy = GetRealMovementViewProxy();
	RealMoveProxy = ((RealMoveProxy == this) || !IsValid(RealMoveProxy)) ? nullptr : RealMoveProxy;

	if (GetHasGroundSupport())
	{
		if (CurLocoJumpForceIgnoreGroundSupportDuration < 0.0f)
		{
			SetHasForceIgnoreGroundSupport(TEXT("TriggerLocoJump"), true);
			SetHasForceIgnoreLocoGroundSupport(TEXT("TriggerLocoJump"), true);
		}
		CurLocoJumpForceIgnoreGroundSupportDuration = StaticDataInfo.TotalLocoJumpForceIgnoreGroundSupportDuration;
	}

	SetGravityVelocity(0.0f, 0.0f, 0.0f);
	SetMovementMode(MOVE_Falling);
	if (RealMoveProxy)
	{
		RealMoveProxy->SetGravityVelocity(0.0f, 0.0f, 0.0f);
		RealMoveProxy->SetMovementMode(MOVE_Falling);
	}

	if (bNeedDoLocoJump)
	{
		if (bNeedOverrideJumpZVel)
		{
			float OldJumpZVelocity = JumpZVelocity;
			SetJumpZVelocity(OverrideJumpZVel);
			DoLocoJump();
			SetJumpZVelocity(OldJumpZVelocity);
			// 坐骑在主角的移动管线中计算，不需要执行DoLocoJump逻辑
			//if (RealMoveProxy)
			//{
			//	RealMoveProxy->SetJumpZVelocity(OverrideJumpZVel);
			//	RealMoveProxy->DoLocoJump();
			//	RealMoveProxy->SetJumpZVelocity(OldJumpZVelocity);
			//}
		}
		else
		{
			DoLocoJump();
			// 坐骑在主角的移动管线中计算，不需要执行DoLocoJump逻辑
			//if (RealMoveProxy)
			//{
			//	RealMoveProxy->DoLocoJump();
			//}
		}
	}
}

void URoleMovementComponent::UpdateLocoJumpForceIgnoreGroundSupportDuration(const float& InDeltaTime)
{
	if (CurLocoJumpForceIgnoreGroundSupportDuration > 0)
	{
		// 这里都是用WithoutUpdate版本，后续马上会执行全局的UpdateHasGroundSupport(true)
		if (GetCurrentIsNetSimulate())
		{
			// 变为网络模拟后，需要立刻关闭主控跳跃的ForceIgnoreGroundSupport逻辑
			CurLocoJumpForceIgnoreGroundSupportDuration = -1.0f;
			SetHasForceIgnoreGroundSupportWithoutUpdate(TEXT("TriggerLocoJump"), false);
			SetHasForceIgnoreLocoGroundSupportWithoutUpdate(TEXT("TriggerLocoJump"), false);
		}
		else
		{
			CurLocoJumpForceIgnoreGroundSupportDuration -= InDeltaTime;
			// 如果时间耗尽，或者MovementMode确实成功离地，取消该机制
			// 水面移动时始终处于Falling状态，不生效上面的机制
			if (CurLocoJumpForceIgnoreGroundSupportDuration < 0 || (!GetIsInWaterWalk() && MovementMode == MOVE_Falling))
			{
				SetHasForceIgnoreGroundSupportWithoutUpdate(TEXT("TriggerLocoJump"), false);
				SetHasForceIgnoreLocoGroundSupportWithoutUpdate(TEXT("TriggerLocoJump"), false);
			}
		}
	}
}

bool URoleMovementComponent::SetIsGravityOn(bool isOn)
{
	if (!IsGravityOn && isOn)
	{
		// 开启重力时继承Z
		FVector CurZVelocity = FVector(0.0f, 0.0f, FMath::Min(Velocity.Z, GravityVelocityZMax));
		GravityVelocity = NewFallVelocity(CurZVelocity, FVector::ZeroVector, 1.0f);
		GravityVelocity.Z = FMath::Min(GravityVelocity.Z, GravityVelocityZMax);
	}
	else if (!isOn && IsGravityOn)
	{
		GravityVelocity.Set(0.0f, 0.0f, 0.0f);
	}

	return IsGravityOn = isOn;
}

void URoleMovementComponent::SetIsIgnorePhysFixup(bool IsIgnore)
{
	IsIgnorePhysFixup = IsIgnore; 
}

float URoleMovementComponent::GetGravityZ() const
{
	if (GravityAdjustCurve.IsValid())
	{
		return Super::GetGravityZ() - UMovementComponent::GetGravityZ() * GravityAdjustCurve->GetFloatValue(GravityAdjustCurveTime);
	}
	
	return Super::GetGravityZ();
}

void URoleMovementComponent::SetGravityAdjustCurve(const FString& GravityAdjustCurvePath)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (AssetManager)
	{
		if (GravityAdjustCurveLoadID.IsSet())
		{
			AssetManager->CancelAsyncLoadByLoadID(GravityAdjustCurveLoadID.GetValue());
			GravityAdjustCurveLoadID.Reset();
		}
		GravityAdjustCurveLoadID = AssetManager->AsyncLoadAsset(
			GravityAdjustCurvePath, FAsyncLoadCompleteDelegate::CreateUObject(this, &URoleMovementComponent::OnGravityAdjustCurveLoaded), static_cast<int32>(EAssetLoadPriority::MoveCurve));
	}
}

void URoleMovementComponent::ClearGravityAdjustCurve()
{ 
	GravityAdjustCurve = nullptr; 
	ResetGravityAdjustCurveTime(); 

	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (AssetManager)
	{
		if (GravityAdjustCurveLoadID.IsSet())
		{
			AssetManager->CancelAsyncLoadByLoadID(GravityAdjustCurveLoadID.GetValue());
			GravityAdjustCurveLoadID.Reset();
		}
	}
}

void URoleMovementComponent::OnGravityAdjustCurveLoaded(int InLoadID, UObject* LoadedAsset)
{
	if (UCurveFloat* Curve = Cast<UCurveFloat>(LoadedAsset))
	{
		GravityAdjustCurve = TStrongObjectPtr(Curve);
		ResetGravityAdjustCurveTime();
	}
	GravityAdjustCurveLoadID.Reset();
}

bool URoleMovementComponent::CalculateGravity(float timeTick, FVector& translationDelta) {
	// 如果后面要做复杂的支撑面和重力控制, 这里清理逻辑就需要迭代。 
	// 这里默认是只支持Z上是重力方向的, 有点硬, 后面按需扩
	const FVector Gravity(0.f, 0.f, GetGravityZ());
	if (IsGravityOn) {
		GravityVelocity = NewFallVelocity(GravityVelocity, Gravity, timeTick);
		GravityVelocity.Z = FMath::Min(GravityVelocity.Z, GravityVelocityZMax);
		if (GravityAdjustCurve.IsValid())
		{
			GravityAdjustCurveTime += timeTick;
		}
	}

	// 已经落地了, 速度可以直接置0
	if (IsMovingOnGround() && GravityVelocity.Z < 0) {
		GravityVelocity.Set(0.0f, 0.0f, 0.0f);
	}

	translationDelta = GravityVelocity * timeTick;

	return true;
}

FVector URoleMovementComponent::PreCalculateGravity(float timeTick) const
{
	FVector PreGravityVelocity = GravityVelocity;
	const FVector Gravity(0.f, 0.f, GetGravityZ());
	
	if (IsGravityOn) {
		PreGravityVelocity = NewFallVelocity(PreGravityVelocity, Gravity, timeTick);
		PreGravityVelocity.Z = FMath::Min(PreGravityVelocity.Z, GravityVelocityZMax);
	}

	// 已经落地了, 速度可以直接置0
	if (MovementMode != MOVE_Falling && PreGravityVelocity.Z < 0) {
		PreGravityVelocity.Set(0.0f, 0.0f, 0.0f);
	}

	return PreGravityVelocity * timeTick;
}


void URoleMovementComponent::StartNewPhysicsWithVelocity(float deltaTime, const FVector& MovementVelocity) {
	if ((deltaTime < MIN_TICK_TIME) || !HasValidData())
	{
		return;
	}

	if (UpdatedComponent->IsSimulatingPhysics())
	{
#if !UE_BUILD_SHIPPING
		UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::StartNewPhysics: UpdateComponent (%s) is simulating physics - aborting."), *UpdatedComponent->GetPathName());

#endif
		return;
	}

	QUICK_SCOPE_CYCLE_COUNTER(URoleMovementComponent_StartNewPhysicsWithVelocity)
	
	const bool bSavedMovementInProgress = bMovementInProgress;
	bMovementInProgress = true;

	FVector OldLocation = UpdatedComponent->GetComponentLocation();
	switch (MovementMode)
	{
	case MOVE_None:
		break;
	case MOVE_Walking:
		PhysWalkingWithVelocity(deltaTime, MovementVelocity);
		break;
	case MOVE_Falling:
		PhysFallingWithVelocity(deltaTime, MovementVelocity);
		break;

	default:
		UE_LOG(LogRoleMovement, Warning, TEXT("%s has unsupported movement mode %d"), *CharacterOwner->GetName(), int32(MovementMode));
		SetMovementMode(MOVE_None);
		break;
	}


	bMovementInProgress = bSavedMovementInProgress;
	if (bDeferUpdateMoveComponent)
	{
		SetUpdatedComponent(DeferredUpdatedMoveComponent);
	}
}

void URoleMovementComponent::PhysWalkingWithVelocity(float deltaTime, const FVector& MovementVelocity) {
	SCOPE_CYCLE_COUNTER(STAT_CharPhysWalkingWithVelocity);

	if (deltaTime < MIN_TICK_TIME)
	{
		return;
	}

	if (!CharacterOwner /*|| (!CharacterOwner->Controller && !bRunPhysicsWithNoController && !HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity()&& (CharacterOwner->GetLocalRole() != ROLE_SimulatedProxy))*/)
	{
		Acceleration = FVector::ZeroVector;
		Velocity = FVector::ZeroVector;
		return;
	}

	/*if (!UpdatedComponent->IsQueryCollisionEnabled())
	{
		SetMovementMode(MOVE_Walking);
		return;
	}*/

	devCode(ensureMsgf(!Velocity.ContainsNaN(), TEXT("PhysWalking: Velocity contains NaN before Iteration (%s)\n%s"), *GetPathNameSafe(this), *Velocity.ToString()));

	bJustTeleported = false;
	float remainingTime = deltaTime;

	// Perform the move

	{
		bJustTeleported = false;
		const float timeTick = remainingTime;
		remainingTime = 0.0f;
		Velocity = MovementVelocity;
		// Save current values
		UPrimitiveComponent* const OldBase = GetMovementBase();
		const FVector PreviousBaseLocation = (OldBase != NULL) ? OldBase->GetComponentLocation() : FVector::ZeroVector;
		const FVector OldLocation = UpdatedComponent->GetComponentLocation();
		const FFindFloorResult OldFloor = CurrentFloor;

		// Compute move parameters
		const FVector MoveVelocity = Velocity;
		const FVector Delta = timeTick * MoveVelocity;
		const bool bZeroDelta = Delta.IsNearlyZero();
		FStepDownResult StepDownResult;

		if (bZeroDelta)
		{
			remainingTime = 0.f;
		}
		else
		{
			// try to move forward
			MoveAlongFloor(MoveVelocity, timeTick, &StepDownResult);

			if (IsFalling())
			{
				// 不做了, 直接交给下一帧处理
				return;
			}
			else if (IsSwimming()) //just entered water
			{
				return;
			}
		}

		// Update floor.
		// StepUp might have already done it for us.
		if (StepDownResult.bComputedFloor)
		{
			CurrentFloor = StepDownResult.FloorResult;
		}
		else
		{
			FindFloor(UpdatedComponent->GetComponentLocation(), CurrentFloor, bZeroDelta, NULL);
		}

		// check for ledges here
		const bool bCheckLedges = !CanWalkOffLedges();
		if (bCheckLedges && !CurrentFloor.IsWalkableFloor() && !bZeroDelta)
		{
			// calculate possible alternate movement
			FFindFloorResult FindFloorResult;
			const FVector NewDelta = GetLedgeMove(OldLocation, Delta, FindFloorResult);
			if (!NewDelta.IsZero())
			{
				// first revert this move
				RevertMove(OldLocation, OldBase, PreviousBaseLocation, OldFloor, false);


				// Try new movement direction
				MoveAlongFloor(NewDelta / timeTick, timeTick, &StepDownResult);

				if (IsFalling())
				{
					// 上面已经求了安全的边缘移动速度, 就不应该进入falling了
					ensureAlways(false);
					// 不做了, 直接交给下一帧处理
					return;
				}
				else if (IsSwimming()) //just entered water
				{
					return;
				}
			}
			else
			{
				// 没有合理的边缘运动, 直接回退移动
				// revert this move
				RevertMove(OldLocation, OldBase, PreviousBaseLocation, OldFloor, true);

			}
		}
		else
		{
			// Validate the floor check
			if (CurrentFloor.IsWalkableFloor())
			{
				AdjustFloorHeight();
				SetBase(CurrentFloor.HitResult.Component.Get(), CurrentFloor.HitResult.BoneName);
			}
			else if (CurrentFloor.HitResult.bStartPenetrating && remainingTime <= 0.f)
			{
				// The floor check failed because it started in penetration
				// We do not want to try to move downward because the downward sweep failed, rather we'd like to try to pop out of the floor.
				FHitResult Hit(CurrentFloor.HitResult);
				Hit.TraceEnd = Hit.TraceStart + FVector(0.f, 0.f, MAX_FLOOR_DIST);
				const FVector RequestedAdjustment = GetPenetrationAdjustment(Hit);
				ResolvePenetration(RequestedAdjustment, Hit, UpdatedComponent->GetComponentQuat());
				bForceNextFloorCheck = true;
			}


			if (IsSwimming()) //just entered water
			{
				return;
			}

			// See if we need to start falling.
			if (!CurrentFloor.IsWalkableFloor() && !CurrentFloor.HitResult.bStartPenetrating)
			{
				const bool bMustJump = bJustTeleported || bZeroDelta || (OldBase == NULL || (!OldBase->IsQueryCollisionEnabled() && MovementBaseUtility::IsDynamicBase(OldBase)));
				if (bMustJump || CanWalkOffLedges())
				{
					// 只进行跌落处理, 物理修正交给下一帧
					HandleWalkingOffLedge(OldFloor.HitResult.ImpactNormal, OldFloor.HitResult.Normal, OldLocation, timeTick);
					StartFalling(-1, -1.0f, 0.0f, FVector::ZeroVector, OldLocation);
					return;
				}
			}
		}


	}
}

void URoleMovementComponent::PhysFallingWithVelocity(float deltaTime, const FVector& MovementVelocity) {
	SCOPE_CYCLE_COUNTER(STAT_CharPhysFallingWithVelocity);

	if (deltaTime < MIN_TICK_TIME)
	{
		return;
	}

	float remainingTime = deltaTime;
	{
		float timeTick = remainingTime;
		remainingTime -= timeTick;

		const FVector OldLocation = UpdatedComponent->GetComponentLocation();
		const FQuat PawnRotation = UpdatedComponent->GetComponentQuat();
		bJustTeleported = false;

		const FVector OldVelocityWithRootMotion = Velocity;

		const FVector OldVelocity = Velocity;


		Velocity = MovementVelocity;
		// Compute change in position (using midpoint integration method).
		//FVector Adjusted = 0.5f * (OldVelocityWithRootMotion + Velocity) * timeTick;
		FVector Adjusted = Velocity * timeTick;
		// Special handling if ending the jump force where we didn't apply gravity during the jump.
		/*if (bEndingJumpForce && !bApplyGravityWhileJumping)
		{
			// We had a portion of the time at constant speed then a portion with acceleration due to gravity.
			// Account for that here with a more correct change in position.
			const float NonGravityTime = FMath::Max(0.f, timeTick - GravityTime);
			Adjusted = (OldVelocityWithRootMotion * NonGravityTime) + (0.5f * (OldVelocityWithRootMotion + Velocity) * GravityTime);
		}*/

		// Move
		FHitResult Hit(1.f);
		SafeMoveUpdatedComponent(Adjusted, PawnRotation, true, Hit);

		if (!HasValidData())
		{
			return;
		}

		float LastMoveTimeSlice = timeTick;
		float subTimeTickRemaining = timeTick * (1.f - Hit.Time);

		if (IsSwimming()) //just entered water
		{
			// 交给下一帧处理
			return;
		}
		else if (Hit.bBlockingHit)
		{
			if (IsValidLandingSpot(UpdatedComponent->GetComponentLocation(), Hit))
			{
				ProcessLanded(Hit, -1.0, -1);
				FVector tempVel = Velocity;
				tempVel.Z = 0;
				//落地会损失一些水平移动, 这里要补回来
				if (tempVel.Size() > UE_SMALL_NUMBER) {
					StartNewPhysicsWithVelocity(subTimeTickRemaining, tempVel);
				}
				return;
			}
			else
			{
				// Compute impact deflection based on final velocity, not integration step.
				// This allows us to compute a new velocity from the deflected vector, and ensures the full gravity effect is included in the slide result.
				Adjusted = Velocity * timeTick;

				// See if we can convert a normally invalid landing spot (based on the hit result) to a usable one.
				if (!Hit.bStartPenetrating && ShouldCheckForValidLandingSpot(timeTick, Adjusted, Hit))
				{
					const FVector PawnLocation = UpdatedComponent->GetComponentLocation();
					FFindFloorResult FloorResult;
					FindFloor(PawnLocation, FloorResult, false);
					if (FloorResult.IsWalkableFloor() && IsValidLandingSpot(PawnLocation, FloorResult.HitResult))
					{
						// 只做逻辑mode切换, 不做运动补全
						ProcessLanded(FloorResult.HitResult, -1.0f, -1);
						return;
					}
				}

				HandleImpact(Hit, LastMoveTimeSlice, Adjusted);

				// If we've changed physics mode, abort.
				if (!HasValidData() || !IsFalling())
				{
					return;
				}

				// Limit air control based on what we hit.
				// We moved to the impact point using air control, but may want to deflect from there based on a limited air control acceleration.
				FVector VelocityNoAirControl = OldVelocity;
				FVector AirControlAccel = ScaleInputAcceleration(MovementVelocity.GetSafeNormal());

				const bool bHasLimitedAirControl = AirControlAccel.SizeSquared2D() > UE_SMALL_NUMBER;

				const FVector OldHitNormal = Hit.Normal;
				const FVector OldHitImpactNormal = Hit.ImpactNormal;
				FVector Delta = ComputeSlideVector(Adjusted, 1.f - Hit.Time, OldHitNormal, Hit);

				if (subTimeTickRemaining > UE_KINDA_SMALL_NUMBER && !bJustTeleported)
				{
					const FVector NewVelocity = (Delta / subTimeTickRemaining);
					Velocity = HasAnimRootMotion() || CurrentRootMotion.HasOverrideVelocityWithIgnoreZAccumulate() ? FVector(Velocity.X, Velocity.Y, NewVelocity.Z) : NewVelocity;
				}

				if (subTimeTickRemaining > UE_KINDA_SMALL_NUMBER && (Delta | Adjusted) > 0.f)
				{
					// Move in deflected direction.
					SafeMoveUpdatedComponent(Delta, PawnRotation, true, Hit);

					if (Hit.bBlockingHit)
					{
						// hit second wall
						LastMoveTimeSlice = subTimeTickRemaining;
						subTimeTickRemaining = subTimeTickRemaining * (1.f - Hit.Time);

						if (IsValidLandingSpot(UpdatedComponent->GetComponentLocation(), Hit))
						{
							ProcessLanded(Hit, -1.0F, -1);
							return;
						}

						HandleImpact(Hit, LastMoveTimeSlice, Delta);

						// If we've changed physics mode, abort.
						if (!HasValidData() || !IsFalling())
						{
							return;
						}

						// Act as if there was no air control on the last move when computing new deflection.
						if (bHasLimitedAirControl && Hit.Normal.Z > 0.001f)
						{
							// const FVector LastMoveNoAirControl = VelocityNoAirControl * LastMoveTimeSlice;
							// Delta = ComputeSlideVector(LastMoveNoAirControl, 1.f, OldHitNormal, Hit);
							// 空中速度计算环节已在移动管线中完成，直接使用Delta计算ComputeSlideVector即可，by: Shi Zhengkai
							Delta = ComputeSlideVector(Delta, 1.f, OldHitNormal, Hit);
						}

						FVector PreTwoWallDelta = Delta;
						TwoWallAdjust(Delta, Hit, OldHitNormal);

						// Limit air control, but allow a slide along the second wall.
						if (bHasLimitedAirControl)
						{
							const bool bCheckLandingSpot = false; // we already checked above.
							const FVector AirControlDeltaV = LimitAirControl(subTimeTickRemaining, AirControlAccel, Hit, bCheckLandingSpot) * subTimeTickRemaining;

							// Only allow if not back in to first wall
							if (FVector::DotProduct(AirControlDeltaV, OldHitNormal) > 0.f)
							{
								Delta += (AirControlDeltaV * subTimeTickRemaining);
							}
						}

						// bDitch=true means that pawn is straddling two slopes, neither of which it can stand on
						bool bDitch = ((OldHitImpactNormal.Z > 0.f) && (Hit.ImpactNormal.Z > 0.f) && (FMath::Abs(Delta.Z) <= UE_KINDA_SMALL_NUMBER) && ((Hit.ImpactNormal | OldHitImpactNormal) < 0.f));
						SafeMoveUpdatedComponent(Delta, PawnRotation, true, Hit);
						if (Hit.Time == 0.f)
						{
							// if we are stuck then try to side step
							FVector SideDelta = (OldHitNormal + Hit.ImpactNormal).GetSafeNormal2D();
							if (SideDelta.IsNearlyZero())
							{
								SideDelta = FVector(OldHitNormal.Y, -OldHitNormal.X, 0).GetSafeNormal();
							}
							SafeMoveUpdatedComponent(SideDelta, PawnRotation, true, Hit);
						}

						if (bDitch || IsValidLandingSpot(UpdatedComponent->GetComponentLocation(), Hit) || Hit.Time == 0.f)
						{
							ProcessLanded(Hit, -1.0f, -1.0f);
							return;
						}
						else if (GetPerchRadiusThreshold() > 0.f && Hit.Time == 1.f && OldHitImpactNormal.Z >= GetWalkableFloorZ())
						{
							// We might be in a virtual 'ditch' within our perch radius. This is rare.
							const FVector PawnLocation = UpdatedComponent->GetComponentLocation();
							const float ZMovedDist = FMath::Abs(PawnLocation.Z - OldLocation.Z);
							const float MovedDist2DSq = (PawnLocation - OldLocation).SizeSquared2D();
							if (ZMovedDist <= 0.2f * timeTick && MovedDist2DSq <= 4.f * timeTick)
							{
								FVector CurrentVelocity = Velocity;
								CurrentVelocity.X += 0.25f * GetMaxSpeed() * (RandomStream.FRand() - 0.5f);
								CurrentVelocity.Y += 0.25f * GetMaxSpeed() * (RandomStream.FRand() - 0.5f);
								CurrentVelocity.Z = FMath::Max<float>(JumpZVelocity * 0.25f, 1.f);
								Delta = CurrentVelocity * timeTick;
								SafeMoveUpdatedComponent(Delta, PawnRotation, true, Hit);
							}
						}
					}
				}
			}
		}
	}
}

void URoleMovementComponent::PullMovementCalculatedDataFromRider(URoleMovementComponent& riderRMC) {
	SetIsLocoStart(riderRMC.GetIsLocoStart());
}

void URoleMovementComponent::PushMovementStateToRider(URoleMovementComponent& riderRMC) {
	// 坐骑同步移动模式时不能直接调用 UE SetMovementMode，会触发 OnMoveModeChanged 接口使得骑乘者与坐骑自身产生偏移
	riderRMC.SetMovementMode(MovementMode);
}

void URoleMovementComponent::PushAnimDataToRider(URoleMovementComponent& riderRMC)
{
	UBaseAnimInstance* RiderAnimIns = riderRMC.GetAnimInstanceForMovement();
	UCarrierAnimInstance* MountAnimIns = Cast<UCarrierAnimInstance>(GetAnimInstanceForMovement());
	if (!RiderAnimIns || !MountAnimIns) return;

	UpdateAnimDataRiderWithMount(RiderAnimIns, MountAnimIns);

	riderRMC.GetRoleMP().GetMovementContext().SetMountPostureParam(MountAnimIns->MountPitch, MountAnimIns->MountRoll, MountAnimIns->MountRootOffset);
}



void URoleMovementComponent::PerformMountMovementAsCarrier(float DeltaTime, URoleMovementComponent& riderRMC,  FVector& worldVelocity, const FQuat& worldQaut, bool isIgnorePhyiscFixup, bool & HasNewTransformApplied) {

	PullMovementCalculatedDataFromRider(riderRMC);

	PerformPhysicMovementWithVelocity(DeltaTime, worldVelocity, worldQaut, isIgnorePhyiscFixup, HasNewTransformApplied);

	PushMovementStateToRider(riderRMC);

	PushAnimDataToRider(riderRMC);
}

void URoleMovementComponent::UpdateAnimDataRiderWithMount(UBaseAnimInstance* RiderAnimIns, UCarrierAnimInstance* MountAnimIns)
{
	if (!RiderAnimIns || !MountAnimIns) return;

	// 同步数据
	RiderAnimIns->FootPosture = MountAnimIns->FootPosture;
	RiderAnimIns->BooleanFootPosture = RiderAnimIns->FootPosture > 0;
	RiderAnimIns->LocoStateInnerIndex = MountAnimIns->LocoStateInnerIndex;
	RiderAnimIns->CachedFootPosture = MountAnimIns->CachedFootPosture;

	// 数据数据在玩家身上,MovePosture也只有玩家在计算
	MountAnimIns->AnimMovePosture = RiderAnimIns->AnimMovePosture;
	MountAnimIns->DelayedAnimMovePosture = RiderAnimIns->DelayedAnimMovePosture;
	MountAnimIns->bIsWalkDelayedAnimMovePosture = RiderAnimIns->bIsWalkDelayedAnimMovePosture;
	MountAnimIns->bIsRunDelayedAnimMovePosture = RiderAnimIns->bIsRunDelayedAnimMovePosture;
	MountAnimIns->bIsSprintDelayedAnimMovePosture = RiderAnimIns->bIsSprintDelayedAnimMovePosture;

	// 同步数据到乘客
	if (URoleMovementComponent* MountMoveComponent = GetRealMovementViewProxy())
	{
		for (auto PassengerIter : MountMoveComponent->MountPassengerRelationMap)
		{
			TWeakObjectPtr<UBaseAnimInstance> PassengeAnimIns = PassengerIter.Value;
			if (PassengeAnimIns.IsValid())
			{
				PassengeAnimIns->AnimMovePosture = RiderAnimIns->AnimMovePosture;
				PassengeAnimIns->DelayedAnimMovePosture = RiderAnimIns->DelayedAnimMovePosture;
				PassengeAnimIns->bIsWalkDelayedAnimMovePosture = RiderAnimIns->bIsWalkDelayedAnimMovePosture;
				PassengeAnimIns->bIsRunDelayedAnimMovePosture = RiderAnimIns->bIsRunDelayedAnimMovePosture;
				PassengeAnimIns->bIsSprintDelayedAnimMovePosture = RiderAnimIns->bIsSprintDelayedAnimMovePosture;
			}
		}	
	}
}

FTransform URoleMovementComponent::GetActorRideModeTransform() const
{
	const bool bUseMountTrans = EMoveDriveRelation::DriveMountAsRiderP1PerformanceStage <= eMoveDriveRelation && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsRiderEnd;
	const bool bRelationTransform = (IsVehicleDriver() || bUseMountTrans) && MountRelationCooperator.IsValid();
	if (bRelationTransform)
	{
		return MountRelationCooperator->GetActorTransform();
	}
	else
	{
		return GetActorTransform();
	}
}

void URoleMovementComponent::PerformMountMovementAsRiderFromNet(float DeltaSeconds, const FVector& newLocation, const FQuat& newQuat, bool & HasNewTransformApplied) {

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("PerformMountMovementAsRider");

	// 获取玩家身上存储的坐骑参数
	float MountPitch = 0.f;
	float MountRoll = 0.f;
	float MountRootOffset = 0.f;
	GetRoleMP().GetMovementContext().GetMountPostureParam(MountPitch, MountRoll, MountRootOffset);

	if (!MountRelationCooperator.IsValid()) {
		return;
	}

	FVector outPosition = newLocation;
	FQuat outQuat = newQuat;
	UCarrierAnimInstance* carrierAnimInstPtr = Cast<UCarrierAnimInstance>(MountRelationCooperator->GetAnimInstanceForMovement());
	if (carrierAnimInstPtr) {
		carrierAnimInstPtr->UpdateMountPostureParam(MountPitch, MountRoll, MountRootOffset);

		// P3 同步坐骑数据到玩家动画蓝图
		if (UBaseAnimInstance* RiderAnimIns = GetAnimInstanceForMovement())
		{
			UpdateAnimDataRiderWithMount(RiderAnimIns, carrierAnimInstPtr);
		}
	}

	MountRelationCooperator->PerformSimpleMovement(DeltaSeconds, outPosition, outQuat, HasNewTransformApplied);

}

void URoleMovementComponent::PerformSimpleMovement(float DeltaSeconds, FVector& newLocation, const FQuat& newQuat, bool & HasNewTransformApplied) {

	TRACE_CPUPROFILER_EVENT_SCOPE_STR("PerformSimpleMovement");

	// 处理逐帧贴地需求
	if (GetNeedFrameStickGround() && DeltaSeconds > SMALL_NUMBER)
	{
		FVector CurPos = UpdatedComponent->GetComponentLocation();
		FVector WorldPosDiff = newLocation - CurPos;
		bool CanStickGround = true;
		if(WorldPosDiff.IsNearlyZero())
		{
			CanStickGround = CanStickGroundWhenZeroVelocity;
			CanStickGroundWhenZeroVelocity = false;
		}
		else
		{
			CanStickGroundWhenZeroVelocity = true;
		}

		if(CanStickGround)
		{
			RoleMP.GetMovementContext().IncreaseHasForceGroundSupportCount();
			RoleMP.GetMovementContext().IncreaseHasForceLocoGroundSupportCount();
			newLocation = CalculateFrameStickGroundLoc(WorldPosDiff) + CurPos;
		}
	}
	
	if(newLocation.Equals(UpdatedComponent->GetComponentLocation()) && newQuat.Rotator().EqualsOrientation(UpdatedComponent->GetComponentRotation()))
	{
		return;
	}

	HasNewTransformApplied = true;
	if(UsingMainMeshChildTransformUpdateOptimization)
	{
		if(!GetUsingLateUpdateForPropagationOptimize())
		{
			// 让更新放到动画Finalize里做
			SetToMainMeshDoAllChildTransformStrategy();
		}
		else
		{
			// 恢复成正常模式, 然后这里进行全部一次更新
			SetToMainMeshOriginalChildTransformStrategy();
			
			// 如果自己是carrier, 这里就要统一处理掉自己的挂接的单位部分
			if(IsCarrierDriveRelationWhenAttached())
			{
				SetPassengersToOriginalChildTransformStrategyAsCarrier();
			}
		}
	}
	
	CharacterOwner->SetActorLocationAndRotation(newLocation, newQuat);

}

void URoleMovementComponent::PerformPhysicMovementWithVelocity(float DeltaSeconds, FVector& worldVelocity, const FQuat& worldQuat, bool isIgnorePhyiscFixup,  bool & HasNewTransformApplied)
{

	bool FinalIgnorePhyiscFixup = isIgnorePhyiscFixup || IsIgnorePhysFixup;
	
	if (FinalIgnorePhyiscFixup) {
		FVector newWorldPos = GetActorLocation() + worldVelocity * DeltaSeconds;
		PerformSimpleMovement(DeltaSeconds, newWorldPos, worldQuat, HasNewTransformApplied);
		// 如果跳过了物理模拟，尝试存下Base的位置，不然再次开启物理模式时可能会累积一段很长的位移
		MaybeSaveBaseLocation();
		return;
	}

	const UWorld* MyWorld = GetWorld();
	if (!HasValidData() || MyWorld == nullptr)
	{
		return;
	}

	// 处理逐帧贴地需求
	if (GetNeedFrameStickGround() && DeltaSeconds > SMALL_NUMBER)
	{
		bool CanStickGround = true;
		if(worldVelocity.IsNearlyZero())
		{
			CanStickGround = CanStickGroundWhenZeroVelocity;
			CanStickGroundWhenZeroVelocity = false;
		}
		else
		{
			CanStickGroundWhenZeroVelocity = true;
		}

		if(CanStickGround)
		{
			RoleMP.GetMovementContext().IncreaseHasForceGroundSupportCount();
			RoleMP.GetMovementContext().IncreaseHasForceLocoGroundSupportCount();
			worldVelocity = CalculateFrameStickGroundLoc(worldVelocity * DeltaSeconds) / DeltaSeconds;
		}
	}
	
	bool NeedUpdateMovement = NeedUpdateMovementLeftTime > 0.0f;
	NeedUpdateMovementLeftTime -= DeltaSeconds;

	if(!NeedUpdateMovement && NeedUpdateMovementLeftTimeConfig < 0.0f)
	{
		NeedUpdateMovement = true;
		NeedUpdateMovementLeftTime = 0.2f;
	}

	// 传送等直接设置位置
	if(!NeedUpdateMovement && !LastUpdateVelocity.IsZero())
	{
		NeedUpdateMovement = true;
		// 有需要真正刷新的, 就更新一下时间, 让其update到稳定
		NeedUpdateMovementLeftTime = NeedUpdateMovementLeftTimeConfig;
	}

	// 有运动速度
	if(!NeedUpdateMovement && !(worldVelocity.IsNearlyZero() && worldQuat.Rotator().EqualsOrientation(UpdatedComponent->GetComponentRotation())))
	{
		NeedUpdateMovement = true;
		// 有需要真正刷新的, 就更新一下时间, 让其update到稳定
		NeedUpdateMovementLeftTime = NeedUpdateMovementLeftTimeConfig;
	}

	// 有运动支持平台
	if(!NeedUpdateMovement &&  MovementBaseUtility::IsDynamicBase(GetMovementBase()))
	{
		NeedUpdateMovement = true;
		// 有需要真正刷新的, 就更新一下时间, 让其update到稳定
		NeedUpdateMovementLeftTime = NeedUpdateMovementLeftTimeConfig;
	}

	if(!NeedUpdateMovement)
	{
		return;
	}

	bTeleportedSinceLastUpdate = UpdatedComponent->GetComponentLocation() != LastUpdateLocation;
	bForceNextFloorCheck |= (IsMovingOnGround() && bTeleportedSinceLastUpdate);


	FVector OldVelocity;
	FVector OldLocation;

	{
		FScopedMovementUpdate ScopedMovementUpdate(UpdatedComponent, bEnableScopedMovementUpdates ? EScopedUpdate::DeferredUpdates : EScopedUpdate::ImmediateUpdates);

		// 更新地表
		MaybeUpdateBasedMovement(DeltaSeconds);

		OldVelocity = Velocity;
		OldLocation = UpdatedComponent->GetComponentLocation();


		if (MovementMode == MOVE_NavWalking && bWantsToLeaveNavWalking)
		{
			TryToLeaveNavWalking();
		}


		if (worldVelocity.Z > EnterFallingVelocityZ && !GetRealMovementControlViewProxy()->GetNeedFrameStickGround())
		{
			// 有起跳趋势时，将MovementMode置为Falling，那么StartNewPhysicsWithVelocity可以执行PhysFallingWithVelocity
			// 否则PhysWalkingWithVelocity将有贴地行为，从而无法起跳
			SetMovementMode(MOVE_Falling);
		}

		{
			TRACE_CPUPROFILER_EVENT_SCOPE_STR("StartNewPhysicsWithVelocity");
			StartNewPhysicsWithVelocity(DeltaSeconds, worldVelocity);
		}

		if (!HasValidData())
		{
			return;
		}

		MoveUpdatedComponent(FVector::ZeroVector, worldQuat, true);

		//LastUpdateRequestedVelocity = bHasRequestedVelocity ? RequestedVelocity : FVector::ZeroVector;
		//bHasRequestedVelocity = false;

		OnMovementUpdated(DeltaSeconds, OldLocation, OldVelocity);

		HasNewTransformApplied = ScopedMovementUpdate.IsTransformDirty();
		if(UsingMainMeshChildTransformUpdateOptimization && HasNewTransformApplied)
		{
			if(!GetUsingLateUpdateForPropagationOptimize())
			{
				// 让更新放到动画Finalize里做
				SetToMainMeshDoAllChildTransformStrategy();
			}
			else
			{
				// 恢复成正常模式, 然后这里进行全部一次更新
				SetToMainMeshOriginalChildTransformStrategy();
				// 如果自己是carrier, 这里就要统一处理掉自己的挂接的单位部分
				if(IsCarrierDriveRelationWhenAttached())
				{
					SetPassengersToOriginalChildTransformStrategyAsCarrier();
				}
			}
		}
	}

	CallMovementUpdateDelegate(DeltaSeconds, OldLocation, OldVelocity);

	MaybeSaveBaseLocation();
	UpdateComponentVelocity();

	//const FVector NewLocation = UpdatedComponent ? UpdatedComponent->GetComponentLocation() : FVector::ZeroVector;
	//const FQuat NewRotation = UpdatedComponent ? UpdatedComponent->GetComponentQuat() : FQuat::Identity;

	//LastUpdateLocation = NewLocation;
	//LastUpdateRotation = NewRotation;
	//LastUpdateVelocity = Velocity;
	//LastAcceleration = Acceleration;
}

void URoleMovementComponent::MovementDataUpdate(float DeltaSeconds, const FVector& worldVelocity, bool usingWorldVelocity)
{
	LastUpdateRequestedVelocity = bHasRequestedVelocity ? RequestedVelocity : FVector::ZeroVector;
	bHasRequestedVelocity = false;

	const FVector NewLocation = UpdatedComponent ? UpdatedComponent->GetComponentLocation() : FVector::ZeroVector;
	const FQuat NewRotation = UpdatedComponent ? UpdatedComponent->GetComponentQuat() : FQuat::Identity;


	if (DeltaSeconds > KINDA_SMALL_NUMBER) {
		FVector OldUpdatedVelocity = LastUpdateVelocity;
		LastUpdateVelocity = (NewLocation - LastUpdateLocation) / DeltaSeconds;
		MovementAcceleration = (LastUpdateVelocity - OldUpdatedVelocity)/DeltaSeconds;
	}

	if (usingWorldVelocity) {
		ExpectVelocity = worldVelocity;
	}
	else {
		ExpectVelocity = LastUpdateVelocity;
	}
	if (GetMovementMode() != MOVE_Walking)
	{
		LastExpectVelocityInAir = ExpectVelocity;
	}

	
	Velocity = LastUpdateVelocity;
	LastUpdateLocation = NewLocation;
	LastUpdateRotation = NewRotation;
	LastAcceleration = Acceleration;

	UpdateComponentVelocity();
}

bool URoleMovementComponent::GetUsingLateUpdateForPropagationOptimize()
{
	// 只有坐骑Mount情况下, carrier驱动是由rider的TickComponent来做的, 所以拿驱动着就是对的
	if(IsMountWhenAttached() && MountRelationCooperator.IsValid()){
	
		return MountRelationCooperator->GetUsingLateUpdate();
	}
	
	return UsingLateUpdate;
}

void URoleMovementComponent::SetToMainMeshIgnoreChildTransformStrategy()
{
	if(!UsingMainMeshChildTransformUpdateOptimization)
	{
		return;
	}
	
	if(!CharacterOwner)
	{
		return;
	}

	auto * MainMesh = CharacterOwner->GetMesh();
	if(!MainMesh)
	{
		return;
	}
	
	if(!IsComponentTickEnabled() || !MainMesh->IsComponentTickEnabled())
	{	MainMesh->SetPropagateToOriginal();
		return;
	}
	
	MainMesh->SetPropagateToIgnoreAndRestoreToOriginal();
}

void URoleMovementComponent::SetToMainMeshDoAllChildTransformStrategy()
{
	if(!UsingMainMeshChildTransformUpdateOptimization)
	{
		return;
	}
	
	if(!CharacterOwner)
	{
		return;
	}

	auto * MainMesh = CharacterOwner->GetMesh();
	if(!MainMesh)
	{
		return;
	}

	// 使用LateUpdate模式下, 一定不会设置这里的更新方式
	ensure(!UsingLateUpdate);
	if(!IsComponentTickEnabled() || !MainMesh->IsComponentTickEnabled())
	{
		MainMesh->SetPropagateToOriginal();
		return;
	}
	
	MainMesh->SetPropagateToDoAllChildAndRestoreToOriginal();
}

void URoleMovementComponent::SetToMainMeshOriginalChildTransformStrategy()
{
	if(!UsingMainMeshChildTransformUpdateOptimization)
	{
		return;
	}
	
	if(!CharacterOwner)
	{
		return;
	}

	auto * MainMesh = CharacterOwner->GetMesh();
	if(!MainMesh)
	{
		return;
	}
	
	MainMesh->SetPropagateToOriginal();
}

void URoleMovementComponent::SetPassengersToOriginalChildTransformStrategyAsCarrier()
{
	if(MountRelationCooperator.IsValid())
	{
		MountRelationCooperator->SetToMainMeshOriginalChildTransformStrategy();
	}
	
	for (auto PassengerIter : MountPassengerRelationMap)
	{
		TWeakObjectPtr<UBaseAnimInstance> PassengeAnimIns = PassengerIter.Value;
		if (PassengeAnimIns.IsValid() && PassengeAnimIns->GetSkelMeshComponent())
		{
			PassengeAnimIns->GetSkelMeshComponent()->SetPropagateToOriginal();
		}
	}	
}

void URoleMovementComponent::UpdateMainMeshChildTransformStrategyWhenTransformChange()
{

	if (!UsingMainMeshChildTransformUpdateOptimization)
	{
		return;
	}

	NeedUpdateAllChildrenWithTransformChanged = true;
	if(!GetUsingLateUpdateForPropagationOptimize())
	{
		// 让动画进行Finalize的时候进行处理
		SetToMainMeshDoAllChildTransformStrategy();
	}else
	{
		// 避免动画处理, 让自己的Update进行处理
		SetToMainMeshIgnoreChildTransformStrategy();
	}
}

void URoleMovementComponent::OnMainMeshAnimBoneTransformFinalize()
{
	if(!UsingMainMeshChildTransformUpdateOptimization)
	{
		return;
	}

	if(!GetUsingLateUpdateForPropagationOptimize())
	{
		if(IsRiderDriveRelationWhenAttached() || IsPassengerDriveRelationWhenAttached())
		{
			SetToMainMeshIgnoreChildTransformStrategy();
			return;
		}

		// 坐骑, 恢复自己所有附属挂接单位, 然后让坐骑的动画进行统一更新
		if(IsCarrierDriveRelationWhenAttached())
		{
			SetPassengersToOriginalChildTransformStrategyAsCarrier();
		}
	}
	else
	{
		SetToMainMeshIgnoreChildTransformStrategy();
	}
	
}

void URoleMovementComponent::ApplyImpartedMovementBaseVelocity()
{
	DecayingFormerBaseVelocity = GetImpartedMovementBaseVelocity();
	// 推进器已经有空中速度继承能力，这里无需再次执行，By Shi Zhengkai
	// Velocity += DecayingFormerBaseVelocity;
	if (bMovementInProgress && CurrentRootMotion.HasAdditiveVelocity())
	{
		// If we leave a base during movement and we have additive root motion, we need to add the imparted velocity so that it retains it next tick
		CurrentRootMotion.LastPreAdditiveVelocity += DecayingFormerBaseVelocity;
	}
	//if (!CharacterMovementCVars::bAddFormerBaseVelocityToRootMotionOverrideWhenFalling || FormerBaseVelocityDecayHalfLife == 0.f)
	//{
		DecayingFormerBaseVelocity = FVector::ZeroVector;
	//}
}
// New Feature: END

FVector URoleMovementComponent::GetPredictFinalLocFromCurrentLoc(const FVector& InExpectedFinalLoc, const float RadiusShrink, const float HalfHeightShrink)
{
	const FVector CurrentLocation = UpdatedComponent->GetComponentLocation();
	return GetPredictFinalMoveDelta(InExpectedFinalLoc - CurrentLocation, &CurrentLocation, RadiusShrink, HalfHeightShrink) + CurrentLocation;
}

FVector URoleMovementComponent::GetPredictFinalLocFromSpecificStartLoc(const FVector& InExpectedFinalLoc, const FVector& InSpecificStartLoc, const float RadiusShrink, const float HalfHeightShrink)
{
	return GetPredictFinalMoveDelta(InExpectedFinalLoc - InSpecificStartLoc, &InSpecificStartLoc, RadiusShrink, HalfHeightShrink) + InSpecificStartLoc;
}

FVector URoleMovementComponent::GetPredictFinalMoveDelta(const FVector& InExpectedMoveDelta, const FVector* InSpecificStartLoc, const float RadiusShrink, const float HalfHeightShrink)
{
	float ExpectedMoveDeltaZ = InExpectedMoveDelta.Z;
	FVector ExpectedMoveDeltaXY = InExpectedMoveDelta;
	ExpectedMoveDeltaXY.Z = 0.0f;
	if (IsEnableImpetus()) 
	{
		// 推挤不需要Z上的处理
		OnlyCalculateImpetusDelta(ExpectedMoveDeltaXY, 0.33f);

	}

	// 战斗区域调整位移
	DealMoveDeltaByMoveConstraint(ExpectedMoveDeltaXY);
	ExpectedMoveDeltaXY.Z = ExpectedMoveDeltaZ;

	FCollisionResponseTemplate CollisionProfile;
	if (!UCollisionProfile::Get()->GetProfileTemplate(GetTrackFloorCollisionPresetName(), CollisionProfile))
	{
		UE_LOG(LogTemp, Log, TEXT("Character:%s GetPredictFinalMoveDelta Failed! InValid CollisionPresetName:%s"), *CharacterOwner->GetName(), *GetTrackFloorCollisionPresetName().ToString());
		
		return ExpectedMoveDeltaXY;
	}
	FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(GetPredictFinalMoveDelta), false, CharacterOwner);
	QueryParams.bIgnoreTouches = true;
	FCollisionResponseParams CollisionResponseParams = CollisionProfile.ResponseToChannels;
	const ECollisionChannel CollisionChannel = CollisionProfile.ObjectType;

	const FVector CurrentLocation = InSpecificStartLoc ? *InSpecificStartLoc : UpdatedComponent->GetComponentLocation();
	float PawnRadius = 0.0f, PawnHalfHeight = 0.0f;
	if (UCapsuleComponent* CapsuleComponent = CharacterOwner->GetCapsuleComponent())
	{
		CapsuleComponent->GetScaledCapsuleSize(PawnRadius, PawnHalfHeight);
	}

	FCollisionShape CollisionShape = FCollisionShape::MakeCapsule(PawnRadius * RadiusShrink, PawnHalfHeight * HalfHeightShrink);
	FHitResult OutHitRes = FHitResult();
	if (GetWorld()->SweepSingleByChannel(OutHitRes, CurrentLocation, CurrentLocation + ExpectedMoveDeltaXY, FQuat::Identity, CollisionChannel, CollisionShape, QueryParams, CollisionResponseParams))
	{
		return OutHitRes.Location - CurrentLocation;
	}

	return ExpectedMoveDeltaXY;
}

void URoleMovementComponent::TryChangeLocoInputZone(bool hasValidInput, const FVector& rawLocoInputVec)
{
	if (!hasValidInput || rawLocoInputVec.IsNearlyZero())
	{
		if (NeedNotifyLocoInputZoneChanged && LastLocoInputVecState != -1)
		{
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
			{
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyLocoInputZoneChanged", -1);
			}
		}
		LastLocoInputVecState = -1;
		return;
	}

	float MoveAxisLen = rawLocoInputVec.Size();
	for (int32 i = 0; i < LocoInputZones.Num(); i++)
	{
		if (MoveAxisLen > LocoInputZones[i] + LocoInputBoundaryWidth && LastLocoInputVecState != i)
		{
			if (NeedNotifyLocoInputZoneChanged)
			{
				if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
				{
					ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyLocoInputZoneChanged", i);
				}
			}
			LastLocoInputVecState = i;
			return;
		}
		else if (MoveAxisLen >= LocoInputZones[i] - LocoInputBoundaryWidth && LastLocoInputVecState == i)
		{
			return;
		}
	}

	if (NeedNotifyLocoInputZoneChanged && LastLocoInputVecState != LocoInputZones.Num())
	{
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyLocoInputZoneChanged", LocoInputZones.Num());
		}
	}
	LastLocoInputVecState = LocoInputZones.Num();
}

void URoleMovementComponent::CalcCustomInput(FVector& CustomInput)
{
	if (this->bHasCustomInput)
	{
		switch (CustomInputType)
		{
		case ECustomInputType::Override:
			CustomInput = ExternalCustomInput;
			break;
		case ECustomInputType::Additive:
			CustomInput += ExternalCustomInput;
			break;
		default:
			break;
		}
	}
}

bool URoleMovementComponent::ConsumeLocoInputVector(FVector& locoInputVec, FVector& rawInputMoveVec, float TimeDelta)
{
	locoInputVec.Set(0.0, 0.0, 0.0);

	// 这里的rawInputMoveVec包含两个部分：
	// 1. 玩家摇杆或键盘WASD的原始XY方向的原始输入，由AddMovementInput到AddInputVector触发
	// 2. 寻路组件等其他世界坐标系输入，由RequestPathMove到Internal_AddMovementInput触发
	// 两种输入目前不会重合，by： shi zhengkai
	rawInputMoveVec = ConsumeInputVector();
	CalcCustomInput(rawInputMoveVec);

	if (!CharacterOwner) {
		return false;
	}

	FRotator CurControlRotation = GetMovementControlRotation();

	if (rawInputMoveVec.Size() > 1.0f)
	{
		// 使用键盘输入时，同时按下XY两个方向的输入，会得到1.414长度的输入，这种情况暂时Normalize处理，避免斜向移动更快
		rawInputMoveVec.Normalize();
	}
	else if (rawInputMoveVec.Size() < LocoInputDeadZone)
	{
		rawInputMoveVec = FVector::Zero();
	}

	if (ELocoInputSemantic::RawInputSemantic == LocoInputSemantic) {
		locoInputVec = rawInputMoveVec;
	}
	else if (ELocoInputSemantic::OnGroundSemantic == LocoInputSemantic) {
		auto controllerPtr = GetWorld()->GetFirstPlayerController();
		if (!controllerPtr) {
			return false;
		}

		// 将摇杆输入转化到世界坐标系并加入locoInputVec
		float currRadians = FMath::Atan2(rawInputMoveVec.Y, rawInputMoveVec.X);
		float X_D = FMath::Cos(currRadians);
		float Y_D = FMath::Sin(currRadians);
		FRotator controlDir = CurControlRotation;
		controlDir.Pitch = 0;
		controlDir.Roll = 0;
		FVector forwardDir = controlDir.RotateVector(FVector::ForwardVector);
		FVector rightDir = controlDir.RotateVector(FVector::RightVector);
		locoInputVec = (forwardDir * X_D + rightDir * Y_D) * rawInputMoveVec.Size();

		if (locoInputVec.Size2D() > 1.0f)
		{
			locoInputVec.Normalize();
		}
	}
	else if (ELocoInputSemantic::OnActorCordinateSemanitic == LocoInputSemantic)
	{
		FVector CharacterForwardXYNormal = CharacterOwner->GetActorForwardVector().GetSafeNormal2D();
		locoInputVec = FQuat::FindBetweenVectors(FVector::XAxisVector, CharacterForwardXYNormal).RotateVector(rawInputMoveVec);
	}
	else if (ELocoInputSemantic::OnClimbSemanitic == LocoInputSemantic)
	{
		FVector CharacterForwardNormal = CharacterOwner->GetActorForwardVector();
		CharacterForwardNormal.Z = 0.0f;
		if (CharacterForwardNormal.IsNearlyZero())
		{
			// 说明角色胶囊体躺着朝向天上，一般不会出现这种情况，这里保底处理
			locoInputVec.Set(0.0f, 0.0f, 1.0f);
		}
		else
		{
			locoInputVec.Set(0.0f, 0.0f, rawInputMoveVec.X);
			// 这里的CharacterForwardNormal已经是水平面的ForwardNormal
			CharacterForwardNormal = CharacterForwardNormal.GetSafeNormal();
			locoInputVec += rawInputMoveVec.Y * CharacterForwardNormal.RotateAngleAxis(90, FVector(0.0f, 0.0f, 1.0f));

		}
	}
	
	float OldControlRotYaw = LastControlRotation.Yaw;
	LastControlRotation = CurControlRotation;

	if(!FMath::IsNearlyZero(TimeDelta))
	{
		ControlYawDiffRatio = MathFormula::ClosetYawAbsDiff(OldControlRotYaw, CurControlRotation.Yaw) / TimeDelta;
	}
	
	return !locoInputVec.IsNearlyZero();
}

bool URoleMovementComponent::ConsumeRequestedVelocityInputVector(FVector& RequestedVelocityInputVec)
{
	if(eRequestMoveControlMode == ERequestMoveControlMode::VelocityAsLocoInput || eRequestMoveControlMode == ERequestMoveControlMode::VelocityWithEngineDefault)
	{
		RequestedVelocityInputVec =  bHasRequestedVelocity ? RequestedVelocity : FVector::ZeroVector;
		RequestedVelocityInputVec = RequestedVelocityInputVec.GetSafeNormal();
	
		// 为什么要用Last? 这样会晚停一帧
		// 为什么要进行MaxSpeed的处理来模拟摇杆过程性的操作改变?
		if (!RequestedVelocityInputVec.IsNearlyZero())
		{
			return true;
		}

		return false;
	}
	else
	{
		return false;
	}
}

void URoleMovementComponent::ModifyLocoInputVector(FVector& locoInputVec, bool& hasLocoInput) {
	if (ELocoInputModifyMode::NoModifyMode == LocoInputModifyMode) {
		return;
	}
	if (ELocoInputModifyMode::InputForwardModifyMode == LocoInputModifyMode)
	{
		FVector ControlForward = FRotator(0.0f, LastControlRotation.Yaw, 0.0f).Vector();
		locoInputVec = FMath::Max(locoInputVec.Dot(ControlForward), 0.0f) * ControlForward;
		hasLocoInput = !locoInputVec.IsNearlyZero();
		return;
	}
	if (ELocoInputModifyMode::SurfModifyMode == LocoInputModifyMode) {
		FVector CharacterForwardNormal = CharacterOwner->GetActorForwardVector();
		CharacterForwardNormal.Normalize();

		hasLocoInput = true;
		if (locoInputVec.IsNearlyZero())
		{
			locoInputVec = CharacterForwardNormal;
			return;
		}

		if (FVector::DotProduct(locoInputVec, CharacterForwardNormal) < 0.0f)
		{
			locoInputVec = locoInputVec - 2 * FVector::DotProduct(locoInputVec, CharacterForwardNormal) * CharacterForwardNormal;
		}

		float XYAngle = FMath::RadiansToDegrees(locoInputVec.HeadingAngle() - CharacterForwardNormal.HeadingAngle());
		XYAngle = XYAngle > 180.0f ? XYAngle - 360.0f : XYAngle < -180.0f ? XYAngle + 360.0f : XYAngle;	// -180~180
		XYAngle = XYAngle > 90.0f ? 180.0 - XYAngle : XYAngle < -90.0f ? -180.0f - XYAngle : XYAngle;	// -90~90

		if (XYAngle > MinAdjustAngle)
		{
			XYAngle = FMath::Min(XYAngle, MaxAdjustAngle);
			XYAngle = (MaxAcceAngle - MinAcceAngle) / (MaxAdjustAngle - MinAdjustAngle) * (XYAngle - MinAdjustAngle) + MinAcceAngle;
			locoInputVec = CharacterForwardNormal.RotateAngleAxis(XYAngle, FVector(0.0f, 0.0f, 1.0f));
		}
		else if (XYAngle < -MinAdjustAngle)
		{
			XYAngle = FMath::Min(-XYAngle, MaxAdjustAngle);
			XYAngle = (MaxAcceAngle - MinAcceAngle) / (MaxAdjustAngle - MinAdjustAngle) * (XYAngle - MinAdjustAngle) + MinAcceAngle;
			locoInputVec = CharacterForwardNormal.RotateAngleAxis(-XYAngle, FVector(0.0f, 0.0f, 1.0f));
		}

		// 加速度方向与角色朝向角度小于MinAdjustAngle，不允许调整
		return;
	}

	return;
}

void URoleMovementComponent::FixSampledRootMotionTransByMeshFaceRotate(FTransform & SampledRMTransform, bool OnlyFixTranslation)
{
	
	FTransform MeshRelativeTrans = FTransform::Identity;
	MeshRelativeTrans.SetRotation(OMeshRR);

	if(!OnlyFixTranslation)
	{
		SampledRMTransform = SampledRMTransform * MeshRelativeTrans;
	}
	else
	{
		SampledRMTransform.SetLocation(MeshRelativeTrans.TransformPosition(SampledRMTransform.GetLocation()));
	}
}

void URoleMovementComponent::GetSynchronizedPosAndRot(FVector& pos, FRotator& rotator) 
{
	MovementSimulator.GetLatestPosAndRot(pos, rotator);
}

void URoleMovementComponent::SetLocoMaxMoveArgs(float MaxSpeed, float MaxAcce, float MaxDece)
{
	// 参数为负数的时候不进行修改
	if(MaxSpeed >= 0.0f)
	{
		SetLocoMaxSpeed(MaxSpeed);
	}

	if(MaxAcce >= 0.0f)
	{
		SetLocoMaxAcceleration(MaxAcce);
	}

	if(MaxDece >= 0.0f)
	{
		SetLocoMaxBrakingDeceleration(MaxDece);
	}
	
}

FVector URoleMovementComponent::GetActorFeetLocation() const
{
	if (IsDriveMountDriveAttachStage() && MountRelationCooperator.IsValid())
	{
		return MountRelationCooperator.Get()->GetActorFeetLocation();
	}

	return Super::GetActorFeetLocation();
}

float URoleMovementComponent::GetLocoMaxSpeed()  const
{ 
	return LocoMaxSpeed * InWaterLocoMaxSpeedScale; 
}

void URoleMovementComponent::SetLocoMaxSpeed(float InLocoMaxSpeed) 
{ 
	LocoMaxSpeed = InLocoMaxSpeed > 0.0f ? InLocoMaxSpeed : 0.0f; 

	if (bAutoUpdatePostureAndPlayRate)
	{
		DoAutoUpdateForUseLocoMaxSpeedAllTime();
	}
}

void URoleMovementComponent::UpdateInWaterLocoMaxSpeedScale()
{
	float OldInWaterLocoMaxSpeedScale = InWaterLocoMaxSpeedScale;

	if (IsInWater && GetIsInNormalWalking())
	{
		float CurDistToWaterSurface = GetCurDistToWaterSurface();
		// 处于水面下时，计算水面减速逻辑
		if (CurDistToWaterSurface < 0.0f)
		{
			if (UCapsuleComponent* CapsuleComp = Cast<UCapsuleComponent>(UpdatedComponent))
			{
				float SelfHalfHeight = CapsuleComp->GetScaledCapsuleHalfHeight();
				InWaterLocoMaxSpeedScale = 1 - FMath::Clamp(-0.5f * CurDistToWaterSurface / SelfHalfHeight, 0.0f, 1- URoleMovementComponent::StaticDataInfo.MinInWaterLocoMaxSpeedScale);
				if (FMath::Abs(OldInWaterLocoMaxSpeedScale - InWaterLocoMaxSpeedScale) > 0.001f) {
					DoAutoUpdateForUseLocoMaxSpeedAllTime();
				}
				return;
			}
		}
	}
	
	// 不满足水面减速逻辑，统一将InWaterLocoMaxSpeedScale设置回1
	InWaterLocoMaxSpeedScale = 1;
	if (FMath::Abs(OldInWaterLocoMaxSpeedScale - InWaterLocoMaxSpeedScale) > 0.001f) {
		DoAutoUpdateForUseLocoMaxSpeedAllTime();
	}
}

float URoleMovementComponent::GetMaxAcceleration() const 
{
	if(IsALSMovementMode()){
		return GetALSMappedSpeedFromCurve().X;
	}
	
	// 空中状态对加速度做限制，避免帧率过低时的飞天
	// https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/213522
	return MovementMode == MOVE_Falling ? FMath::Min(3000.0f, LocoMaxAcceleration) : LocoMaxAcceleration;
};

float URoleMovementComponent::GetMaxBrakingDeceleration() const
{
	if(IsALSMovementMode())
	{
		if (MovementMode == MOVE_Falling){
			return 0.0f;
		}
		else{
			return GetALSMappedSpeedFromCurve().Y;
		}
	}
	return LocoMaxBrakingDeceleration;
};

void URoleMovementComponent::RequestDirectMove(const FVector& MoveVelocity, bool bForceMaxSpeed)
{
	RequestDirectMoveWithZ(MoveVelocity, bForceMaxSpeed, false);
}

void URoleMovementComponent::RequestDirectMoveWithZ(const FVector& MoveVelocity, bool bForceMaxSpeed, bool bAllowZAxis)
{
	if (MoveVelocity.SizeSquared() < UE_KINDA_SMALL_NUMBER)
	{
		return;
	}

	// 这里默认设置一次, 如果需要使用其他模式, 再RequestDirectMove后自行设置, 这样可以兼容引擎接口
	eRequestMoveControlMode = ERequestMoveControlMode::VelocityWithEngineDefault;
	
	if (ShouldPerformAirControlForPathFollowing())
	{
		const FVector FallVelocity = MoveVelocity.GetClampedToMaxSize(GetMaxSpeed());
		PerformAirControlForPathFollowing(FallVelocity, FallVelocity.Z);
		return;
	}

	RequestedVelocity = MoveVelocity;
	bHasRequestedVelocity = true;
	bRequestedMoveWithMaxSpeed = bForceMaxSpeed;

	// 如果允许Z轴移动，或者不在地面，保留Z分量；否则强制Z=0
	if (IsMovingOnGround() && !bAllowZAxis)
	{
		RequestedVelocity.Z = 0.0f;
	}
}

bool URoleMovementComponent::ApplyRequestedMove(float DeltaTime, float MaxAccel, float MaxSpeed, float Friction, float BrakingDeceleration, FVector& OutAcceleration, float& OutRequestedSpeed)
{
	if (bHasRequestedVelocity)
	{
		const float RequestedSpeedSquared = RequestedVelocity.SizeSquared();
		if (RequestedSpeedSquared < UE_KINDA_SMALL_NUMBER)
		{
			return false;
		}

		// Compute requested speed from path following
		float RequestedSpeed = FMath::Sqrt(RequestedSpeedSquared);
		const FVector RequestedMoveDir = RequestedVelocity / RequestedSpeed;
		if (!bJustUseRequestedVel)
		{
			RequestedSpeed = (bRequestedMoveWithMaxSpeed ? MaxSpeed : FMath::Min(MaxSpeed, RequestedSpeed));
		}

		// Compute actual requested velocity
		const FVector MoveVelocity = RequestedMoveDir * RequestedSpeed;
		// Compute acceleration. Use MaxAccel to limit speed increase, 1% buffer.
		FVector NewAcceleration = FVector::ZeroVector;
		const float CurrentSpeedSq = Velocity.SizeSquared();
		if (ShouldComputeAccelerationToReachRequestedVelocity(RequestedSpeed))
		{
			// Turn in the same manner as with input acceleration.
			const float VelSize = FMath::Sqrt(CurrentSpeedSq);
			Velocity = Velocity - (Velocity - RequestedMoveDir * VelSize) * FMath::Min(DeltaTime * Friction, 1.f);

			// How much do we need to accelerate to get to the new velocity?
			NewAcceleration = ((MoveVelocity - Velocity) / DeltaTime);
			NewAcceleration = NewAcceleration.GetClampedToMaxSize(MaxAccel);
		}
		else
		{
			// Just set velocity directly.
			// If decelerating we do so instantly, so we don't slide through the destination if we can't brake fast enough.
			Velocity = MoveVelocity;
		}

		// Copy to out params
		OutRequestedSpeed = RequestedSpeed;
		OutAcceleration = NewAcceleration;
		return true;
	}

	return false;
}

void URoleMovementComponent::RequestMoveWithVelocityToSetAbsolutePosAndRot(FVector WorldPos, FQuat WorldRot)
{
	bHasRequestedVelocity = true;
	eRequestMoveControlMode = ERequestMoveControlMode::VelocityToSetAbsolutePosAndRot;
	RequestMovePosData = WorldPos;
	RequestMoveWorldRotData = WorldRot;
}

void URoleMovementComponent::RequestMoveWithVelocityToSetAbsolutePosAndUseYawController(FVector WorldPos, FQuat WorldRot )
{
	bHasRequestedVelocity = true;
	eRequestMoveControlMode = ERequestMoveControlMode::VelocityToSetAbsolutePosAndUseYawController;
	RequestMovePosData = WorldPos;
	RequestMoveWorldRotData = WorldRot;
}

void URoleMovementComponent::RequestMoveWithVelocityToPosDeltaAndUseYawController(FVector WorldPosDelta, FQuat WorldRot)
{
	bHasRequestedVelocity = true;
	eRequestMoveControlMode = ERequestMoveControlMode::VelocityToPosDeltaAndUseYawController;
	RequestMovePosData = WorldPosDelta;
	RequestMoveWorldRotData = WorldRot;
}

bool URoleMovementComponent::ComputeFinalInputVector(FVector& InLocoInputVector, FVector& InRequestedVelocityInputVector)
{
	// 根据LocoInputSources确认InpuVector应该如何设置
	TArray<ELocoInputSource> LocoInputSources = GetLocoInputSources();

	bool bCurPrioritInputSourceValid = false;
	for (int32 i = 0; i < LocoInputSources.Num(); i++)
	{
		bCurPrioritInputSourceValid = false;
		bool bInputVectorNeeded = false;
		bool bRequestedVelocityNeeded = false;

		if ((LocoInputSources[i] == ELocoInputSource::RootmotionSource || LocoInputSources[i] == ELocoInputSource::AnimationRootmotion) && !InLocoInputVector.IsNearlyZero())
		{
			bInputVectorNeeded = true;
			bCurPrioritInputSourceValid = true;
		}
		else if (LocoInputSources[i] == ELocoInputSource::RequestVelocity && !InRequestedVelocityInputVector.IsNearlyZero())
		{
			bRequestedVelocityNeeded = true;
			bCurPrioritInputSourceValid = true;
		}

		if (bCurPrioritInputSourceValid)
		{
			if (!bInputVectorNeeded)
			{
				InLocoInputVector.Set(0.0f, 0.0f, 0.0f);
			}

			if (bRequestedVelocityNeeded)
			{
				InLocoInputVector += InRequestedVelocityInputVector;
			}
			break;
		}
	}

	if (!bCurPrioritInputSourceValid)
	{
		InLocoInputVector.Set(0.0f, 0.0f, 0.0f);
	}

	return !InLocoInputVector.IsNearlyZero();
}

void URoleMovementComponent::LocomotionParamInverseCalculate(const float DeltaTime)
{
	SetIsLocomotionParamInverseCalculate(true);

	URoleMovementComponent* RealMoveComp = GetRealMovementViewProxy();
	const FVector& InNewLoc = RealMoveComp->UpdatedComponent->GetComponentLocation();
	const FRotator& InNewRot = RealMoveComp->UpdatedComponent->GetComponentRotation();

	// 坐骑相关数据反推
	FRideMountContextInfo MountContext = RoleMP.GetMovementContext().GetRideMountContextInfo();
	USkeletalMeshComponent* MountMesh = Cast<USkeletalMeshComponent>(UKGObjectActorManager::GetInstance(this)->GetObjectByID(MountContext.SkeletalMeshID));
	if (!MountMesh)
	{
		ClearTriggerDriftByInverseCalculate();
		return;
	}
	
	if (!Velocity.IsZero())
	{
		bNeedResetMountSimulateData = true;
		// MountContext中的数据, 是不是自行车自己的数据, 可以往自行车自己身上放?? 支持后面坐骑多样性
		FVector CurFrontWheelLocation = InNewLoc + InNewRot.Vector() * MountContext.MountFrontLength;
		FVector LastFrontWheelLocation = RealMoveComp->LastFrameLoc + RealMoveComp->LastFrameRot.Rotator().Vector() * MountContext.MountFrontLength;
		FVector CurEndWheelLocation = InNewLoc - InNewRot.Vector() * MountContext.MountEndLength;
		FVector LastEndWheelLocation = RealMoveComp->LastFrameLoc - RealMoveComp->LastFrameRot.Rotator().Vector() * MountContext.MountEndLength;
		bool CurIsBackCar = (InNewLoc - RealMoveComp->LastFrameLoc).Dot(InNewRot.Vector()) < 0;

		FVector FrontDirVec = CurFrontWheelLocation - LastFrontWheelLocation;
		FrontDirVec.Z = 0.0f;
		if (CurIsBackCar)
		{
			FrontDirVec = -FrontDirVec;
		}

		// 设置前后轮的转动距离
		RoleMP.GetMovementContext().SetMountMoveAngle(
			FRotator::NormalizeAxis(MountContext.MountFrontMoveAngle + (CurIsBackCar ? -1 : 1) * 180 * FrontDirVec.Size2D() / MountContext.MountFrontRadius / PI),
			FRotator::NormalizeAxis(MountContext.MountEndMoveAngle + (CurIsBackCar ? -1 : 1) * 180 * (CurEndWheelLocation - LastEndWheelLocation).Size2D() / MountContext.MountEndRadius / PI)
		);

		// 设置前轮朝向
		float RealMoveDirYaw = InNewRot.Yaw;
		if (FrontDirVec.Size2D() > 1.0f)
		{
			RealMoveDirYaw = FrontDirVec.Rotation().Yaw;
		}
		// 根据当前龙头朝向，计算插值后的实际龙头朝向
		RealMoveDirYaw = MathFormula::YawDecayWithNormalized(InNewRot.Yaw + MountContext.MountDirYawToActorYawDelta, RealMoveDirYaw, 0.05, DeltaTime);
		RoleMP.GetMovementContext().SetMountDirYawToActorYawDelta(
			FMath::Clamp(FRotator::NormalizeAxis(RealMoveDirYaw - InNewRot.Yaw), -MountContext.MountMaxDeltaYaw, MountContext.MountMaxDeltaYaw)
		);

		// 处理漂移速度逻辑
		if (RoleMP.GetMovementContext().GetAllowDrift() && DeltaTime > 0)
		{
			if (!CurIsBackCar)
			{
				float DriftForce = FMath::Abs((InNewLoc - RealMoveComp->LastFrameLoc).Dot(FRotator(0.0f, RealMoveDirYaw + 90.0f, 0.0f).Vector()));
				CheckTriggerDriftByInverseCalculate(DriftForce / DeltaTime);
			}
			else
			{
				ClearTriggerDriftByInverseCalculate();
			}
		}
	}
	else if (bNeedResetMountSimulateData)
	{
		float RealMoveDirYaw = MathFormula::YawDecayWithNormalized(MountContext.MountDirYawToActorYawDelta, 0, 0.05, DeltaTime);
		RoleMP.GetMovementContext().SetMountDirYawToActorYawDelta(RealMoveDirYaw);

		if (RealMoveDirYaw == 0)
		{
			bNeedResetMountSimulateData = false;
		}

		// 处理漂移速度逻辑
		if (RoleMP.GetMovementContext().GetAllowDrift() && DeltaTime > 0)
		{
			bool CurIsBackCar = (InNewLoc - RealMoveComp->LastFrameLoc).Dot(InNewRot.Vector()) < 0;
			if (!CurIsBackCar)
			{
				float DriftForce = FMath::Abs((InNewLoc - RealMoveComp->LastFrameLoc).Dot(FRotator(0.0f, RealMoveDirYaw + 90.0f, 0.0f).Vector()));
				CheckTriggerDriftByInverseCalculate(DriftForce / DeltaTime);
			}
			else
			{
				ClearTriggerDriftByInverseCalculate();
			}
		}
	}
}

void URoleMovementComponent::SetIsLocomotionParamInverseCalculate(bool InIsCal)
{
	if (IsLocomotionParamInverseCalculate == InIsCal) {
		return;
	}
	IsLocomotionParamInverseCalculate = InIsCal;

	if (!IsLocomotionParamInverseCalculate)
	{
		// 退出LocomotionParamInverseCalculate环节时，清理数据
		ClearTriggerDriftByInverseCalculate();
	}
}
#pragma endregion Movement



#pragma region AutoAnimPostureAndPlayRate
void URoleMovementComponent::InitSpeedStagesAndPosture(float WalkSpeed, float RunSpeed, float SprintSpeed, int WalkPosture, int RunPosture, int SprintPosture)
{
	SpeedStages.Empty();
	SpeedStages.Add(WalkSpeed);
	SpeedStages.Add(RunSpeed);
	SpeedStages.Add(SprintSpeed);
	SpeedStagesToMovePosture.Empty();
	SpeedStagesToMovePosture.Add(WalkPosture);
	SpeedStagesToMovePosture.Add(RunPosture);
	SpeedStagesToMovePosture.Add(SprintPosture);
	SpeedBoundary.Empty();
	for (int32 i = 0; i < SpeedStages.Num() - 1; i++)
	{
		SpeedBoundary.Add(FMath::Sqrt(SpeedStages[i] * SpeedStages[i + 1]));
	}

	ClearAutoUpdatePostureSpeedBuffer();
}

void URoleMovementComponent::SetAutoUpdatePostureAndPlayRate(bool bUpdate)
{
	bAutoUpdatePostureAndPlayRate = bUpdate;

	SpeedStateIdx = -1;
	ClearAutoUpdatePostureSpeedBuffer();

	if (bUpdate)
	{
		// 进入AutoUpdatePosture时，对于UseLocoMaxSpeedAllTime的情况，更新一次AnimMovePostureAndPlayRate
		DoAutoUpdateForUseLocoMaxSpeedAllTime();
	}
	else
	{
		// 退出AutoUpdatePosture时，强制更新一次AnimMovePostureAndPlayRate
		float CurLocoMaxSpeed = GetLocoMaxSpeed();
		float CurSpeedStateIndex = GetSpeedStateIndex(CurLocoMaxSpeed);
		UpdateAnimMovePostureAndPlayRateBySpeedStateIndex(CurSpeedStateIndex, CurLocoMaxSpeed);
	}
}

bool URoleMovementComponent::GetAutoUpdatePostureAndPlayRate()
{
	if(IsALSMovementMode())
	{
		return true;
	}
	return bAutoUpdatePostureAndPlayRate;
}

void URoleMovementComponent::SetAutoUpdatePostureMode(EAutoUpdatePostureMode Mode)
{
	if(Mode == eAutoUpdatePostureMode)
	{
		return;
	}
	
	eAutoUpdatePostureMode = Mode;
};

void URoleMovementComponent::SetAutoUpdatePostureWithCycleMotionMode()
{
	SetAutoUpdatePostureMode(EAutoUpdatePostureMode::CYCLE_MOTION_MODE);
}
void URoleMovementComponent::SetAutoUpdatePostureWithALSMode()
{
	SetAutoUpdatePostureMode(EAutoUpdatePostureMode::ALS_MODE);
	
}


void URoleMovementComponent::ClearAutoUpdatePostureSpeedBuffer()
{
	for (int i = 0; i < SpeedBuffer.Num(); i++)
	{
		SpeedBuffer[i] = -1.0f;
	}
}


float URoleMovementComponent::GetSpeedBufferAverageSpeed()
{
	float SpeedSum = 0.0f;
	int SpeedCnt = 0;
	for (const float CurSpeed : SpeedBuffer)
	{
		if (CurSpeed > 0)
		{
			SpeedSum += CurSpeed;
			SpeedCnt++;
		}
	}
	return SpeedCnt == 0 ? 0 : SpeedSum / SpeedCnt;
}

void URoleMovementComponent::DoAutoUpdatePostureAndPlayRateWithCycleMotionMode()
{
	switch (AutoUpdatePostureVelocityRule)
	{
	case EAutoUpdatePostureVelocityRule::EAUPVR_UseLocoMaxSpeedAllTime:
	{
		// 在SetLocoMaxSpeed中直接触发
		return;
	}
	case EAutoUpdatePostureVelocityRule::EAUPVR_UseRealVelocity:
	{
		float CurMovementSpeed = GetMovementSpeed();
		// 排除奇异值
		if (CurMovementSpeed <= GetLocoMaxSpeed())
		{
			SpeedBuffer.Add(CurMovementSpeed);
			SpeedBuffer.RemoveAt(0);
		}
		break;
	}
	//case EAutoUpdatePostureVelocityRule::EAUPVR_UseLocoMaxSpeedWhenLocoStart:
	//{
	//	break;
	//}
	}
	float VelocityValue = GetAutoUpdatePostureSpeed();
	SpeedStateIdx = GetSpeedStateIndex(VelocityValue);
	UpdateAnimMovePostureAndPlayRateBySpeedStateIndex(SpeedStateIdx, VelocityValue);
}

float URoleMovementComponent::GetAutoUpdatePostureSpeed()
{
	switch (AutoUpdatePostureVelocityRule)
	{
	case EAutoUpdatePostureVelocityRule::EAUPVR_UseLocoMaxSpeedAllTime:
	{
		return GetLocoMaxSpeed();
	}
	case EAutoUpdatePostureVelocityRule::EAUPVR_UseRealVelocity:
	{
		return GetSpeedBufferAverageSpeed();
	}
	case EAutoUpdatePostureVelocityRule::EAUPVR_UseLocoMaxSpeedWhenLocoStart:
	{
		return GetIsLocoStart() ? GetLocoMaxSpeed() : 0.0f;
	}
	}
	return 0.0f;
}

void URoleMovementComponent::DoAutoUpdateForUseLocoMaxSpeedAllTime()
{
	if (eAutoUpdatePostureMode == EAutoUpdatePostureMode::CYCLE_MOTION_MODE)
	{
		if (AutoUpdatePostureVelocityRule == EAutoUpdatePostureVelocityRule::EAUPVR_UseLocoMaxSpeedAllTime)
		{
			float CurLocoMaxSpeed = GetLocoMaxSpeed();
			SpeedStateIdx = GetSpeedStateIndex(CurLocoMaxSpeed);
			UpdateAnimMovePostureAndPlayRateBySpeedStateIndex(SpeedStateIdx, CurLocoMaxSpeed);
		}
	}
}

void URoleMovementComponent::DoAutoUpdatePostureAndPlayRateWithALSMode()
{

	if(0 == SpeedStages.Num() || 0 == SpeedStagesToMovePosture.Num() || SpeedStages.Num() != SpeedStagesToMovePosture.Num())
	{
		return;
	}
	
	// ALS 根据输入确定理论上想要操控的速度, 但是因为移动规则限制, 内部本身会回退到更低速度的AnimMovePosture
	int CurLogicSpeed = GetLocoMaxSpeed();
	SpeedStateIdx = GetSpeedStateIndex(CurLogicSpeed);

	// 逻辑和动画ALS分开
	int32 FinalALSAnimSpeedState = SpeedStateIdx;

	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		if (FinalALSAnimSpeedState >= 0 && SpeedStages.Num() > FinalALSAnimSpeedState && SpeedStagesToMovePosture.Num() > FinalALSAnimSpeedState)
		{
	
			AnimInstance->SetAnimMovePostureAndPlayRate(SpeedStagesToMovePosture[FinalALSAnimSpeedState], 1.0f);

			if (GetIsMainPlayer() && StaticDataInfo.AnimMovePostureToMaxStepHeightMap.Contains(SpeedStagesToMovePosture[FinalALSAnimSpeedState]))
			{
				MaxStepHeight = StaticDataInfo.AnimMovePostureToMaxStepHeightMap[SpeedStagesToMovePosture[FinalALSAnimSpeedState]];
			}

		}

		// 按照ALS中的方式进行基于速度的表现MovePosture处理, 里面会设计到状态过渡控制影响IK、移动混合数值的处理
		FVector VelXY = GetMovementVelocity();
		VelXY.Z = 0;
		int SpeedStageByRealTimeVelocity = VelXY.Size();
		int FinalMovePostureByRealtimeVelocityStateIdx = FinalALSAnimSpeedState;
		const int SPEED_TOLERATE = 10;
		if(SpeedStages.Num() - 1 >= SPRINT_SPEED_STAGE_INDEX)
		{
			if(SpeedStageByRealTimeVelocity >= SpeedStages[RUN_SPEED_STAGE_INDEX] + SPEED_TOLERATE)
			{
				FinalMovePostureByRealtimeVelocityStateIdx = FinalALSAnimSpeedState;
			}
			else if(SpeedStageByRealTimeVelocity >= SpeedStages[WALK_SPEED_STAGE_INDEX] + SPEED_TOLERATE)
			{
				FinalMovePostureByRealtimeVelocityStateIdx = RUN_SPEED_STAGE_INDEX;
			}
			else
			{
				FinalMovePostureByRealtimeVelocityStateIdx = WALK_SPEED_STAGE_INDEX;
			}
		}

		AnimInstance->SetALSMovePosture(SpeedStagesToMovePosture[FinalMovePostureByRealtimeVelocityStateIdx]);
	}
	
	
}

int32 URoleMovementComponent::GetSpeedStateIndex(const float& InSpeed)
{	
	if (SpeedStateIdx < 0)
	{
		// 无初始值的情况，直接从速度低往速度高查找
		for (int32 i = 0; i < SpeedBoundary.Num(); i++)
		{
			if (InSpeed <= SpeedBoundary[i])
			{
				return i;
			}
		}
		return SpeedBoundary.Num();
	}
	else
	{
		// 对于LocoMaxSpeed的计算情况，可以不用考虑SpeedBoundaryWidth
		float RealSpeedBoundaryWidth = AutoUpdatePostureVelocityRule == EAutoUpdatePostureVelocityRule::EAUPVR_UseRealVelocity ? SpeedBoundaryWidth : 0.0f;

		// 向上查找姿态进阶
		for (int32 i = SpeedBoundary.Num() - 1; i >= SpeedStateIdx; i--)
		{
			if (InSpeed > SpeedBoundary[i] + RealSpeedBoundaryWidth)
			{
				return i + 1;
			}
		}

		// 向下查找姿态回落
		for (int32 i = 0; i <= FMath::Min(SpeedStateIdx, SpeedBoundary.Num() - 1); i++)
		{
			if (InSpeed < SpeedBoundary[i] - RealSpeedBoundaryWidth)
			{
				return i;
			}
		}

		// 对于走跑冲刺不同姿态使用相同速度的情况，核心理念是：减少姿态跨越
		return SpeedStateIdx;
	}
}

bool URoleMovementComponent::UpdateAnimMovePostureAndPlayRateBySpeedStateIndex(const int32& InSpeedStateIndex, const float& InSpeed)
{
	if (InSpeedStateIndex >= 0 && SpeedStages.Num() > InSpeedStateIndex && SpeedStagesToMovePosture.Num() > InSpeedStateIndex)
	{
		const float PlayRate = fmax(0.1f, fmin(3.0f, InSpeed / SpeedStages[InSpeedStateIndex]));
		if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
		{
			AnimInstance->SetAnimMovePostureAndPlayRate(SpeedStagesToMovePosture[InSpeedStateIndex], PlayRate);
			if (GetIsMainPlayer() && StaticDataInfo.AnimMovePostureToMaxStepHeightMap.Contains(SpeedStagesToMovePosture[InSpeedStateIndex]))
			{
				MaxStepHeight = StaticDataInfo.AnimMovePostureToMaxStepHeightMap[SpeedStagesToMovePosture[InSpeedStateIndex]];
			}
		}

		return true;
	}

	return false;
}
#pragma endregion AutoAnimPostureAndPlayRate



void URoleMovementComponent::PullMovementControlDataByAnim(UBaseAnimInstance& animInst, float DeltaTime) {
	URoleMovementComponent* logicMasterRMC = GetMountRiderMovementViewProxy();
	animInst.PullLocomotionControlDataFromRoleMovement(*logicMasterRMC, DeltaTime);
}

void URoleMovementComponent::UpdateMountAKEventStatus(bool bStart)
{
	int MountType = RoleMP.GetMovementContext().GetMountType();
	
	if (!StaticDataInfo.CommonMountAKEventParamMap.Contains(MountType) || bMountEventPosted == bStart) return;
	FMountAKEventParam& MountAKEventParam = StaticDataInfo.CommonMountAKEventParamMap[MountType];

	ABaseCharacter* Character = GetCharacterOwnerForRuntimeOrEditor();
	if (!Character) return;

	UAkComponent* AkComponent = Character->GetComponentByClass<UAkComponent>();
	if (!AkComponent) return;

	UKGAkAudioManager* AudioManager = UKGAkAudioManager::GetInstance(AkComponent);
	if (!AudioManager) return;

	bMountEventPosted = bStart;
	
	FString StartEventName = bMainPlayerMount ? (bStart ? MountAKEventParam.StartAKEventP1 : MountAKEventParam.StopAKEventP1) : (bStart ? MountAKEventParam.StartAKEventP3 : MountAKEventParam.StopAKEventP3);
	if (StartEventName != "")
	{
		AudioManager->InnerPostEventOnAkComp(StartEventName, AkComponent, true);
	}

	if (bStart)
	{
		FString GetInEventName = bMainPlayerMount ? MountAKEventParam.GetInAKEventP1 : MountAKEventParam.GetInAKEventP3;
		if (GetInEventName != "")
		{
			AudioManager->InnerPostEventOnAkComp(GetInEventName, AkComponent, true);
		}
	}
}

void URoleMovementComponent::UpdateMountAudioRTPC()
{
	int MountType = RoleMP.GetMovementContext().GetMountType();
	if (!StaticDataInfo.CommonMountAKEventParamMap.Contains(MountType)) return;
	FString RTPCName = StaticDataInfo.CommonMountAKEventParamMap[MountType].StartRTPCName;
	if (RTPCName == "") return;
	
	if (ABaseCharacter* Character = GetCharacterOwnerForRuntimeOrEditor())
	{
		if (UAkComponent* AkComponent = Character->GetComponentByClass<UAkComponent>())
		{
			if (UKGAkAudioManager* AudioManager = UKGAkAudioManager::GetInstance(AkComponent))
			{
				float RtpcValue = FMath::Clamp(Velocity.Length() / MountMaxSpeed, 0, 1) * 100;
				AudioManager->SetRtpcValueOnAkGameObject(AkComponent, StaticDataInfo.CommonMountAKEventParamMap[MountType].StartRTPCName, RtpcValue);
			}
		}	
	}
}

bool URoleMovementComponent::IsDriveMountDrivePerformanceStage() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP1PerformanceStage or
		eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP3PerformanceStage or
		eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP3OffMountStage;
}

bool URoleMovementComponent::IsDriveMountDriveAttachStage() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP1RiderAttachStage or eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP3RiderAttachStage;
}
bool URoleMovementComponent::IsDriveMountAsRiderP3OffMountStage() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP3OffMountStage;
}
bool URoleMovementComponent::IsNeedConsumeMountSimulateData() const
{
	return !IsDriveMountAsRiderP3OffMountStage();
}
bool URoleMovementComponent::IsMount() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveMountAsCarrierPerformance || eMoveDriveRelation == EMoveDriveRelation::DriveMountAsCarrier;
}

bool URoleMovementComponent::IsMountWhenAttached() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveMountAsCarrier;
}

bool URoleMovementComponent::IsMountRider() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP1PerformanceStage ||
		eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP3PerformanceStage ||
		eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP1RiderAttachStage ||
		eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP3RiderAttachStage ||
		eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP3OffMountStage;
}
bool URoleMovementComponent::IsMountRiderWhenAttached() const
{
	return 
		eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP1RiderAttachStage ||
		eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP3RiderAttachStage;
}

bool URoleMovementComponent::IsMountP1Rider() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveMountAsRiderP1PerformanceStage  || eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP1RiderAttachStage;
}

#pragma region MovementMode

bool URoleMovementComponent::IsInterconnectedMovement() {
	if (eMoveDriveMode == EMoveDriveMode::DriveByAttachedParent) {
		return true;
	}
	
	if (IsDriveMountDriveAttachStage()) {
		return true;
	}

	if (eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsPassenger) {
		return true;
	}

	if (eMoveDriveRelation == EMoveDriveRelation::DriveMountAsPassenger) {
		return true;
	}

	return false;
}

void URoleMovementComponent::InitLocoStateVelocityHistory(int Count)
{
	RoleMP.GetMovementContext().InitLocoStateVelocityHistory(Count);
}

void URoleMovementComponent::SetHasForceGroundSupport(FString ReasonTag, bool InHasForceGroundSupport)
{
	SetHasForceGroundSupportWithoutUpdate(ReasonTag, InHasForceGroundSupport);
	UpdateHasGroundSupport();
}

void URoleMovementComponent::SetHasForceGroundSupportWithoutUpdate(FString ReasonTag, bool InHasForceGroundSupport)
{
	if (!ForceIgnoreGroundSupportReason.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("SetHasForceGroundSupportWithoutUpdate Error! Has ForceIgnoreGroundSupportReason! InReason:%s"), *ReasonTag);
	}

	if (InHasForceGroundSupport)
	{
		if (ForceGroundSupportReason.Contains(ReasonTag))
		{
			ForceGroundSupportReason[ReasonTag] += 1;

		}
		else
		{
			ForceGroundSupportReason.Add(ReasonTag, 1);
		}
	}
	else
	{
		if (ForceGroundSupportReason.Contains(ReasonTag))
		{
			ForceGroundSupportReason[ReasonTag] -= 1;
			if (ForceGroundSupportReason[ReasonTag] <= 0)
			{
				ForceGroundSupportReason.Remove(ReasonTag);
			}
		}
	}
}

void URoleMovementComponent::SetHasForceIgnoreGroundSupport(FString ReasonTag, bool InHasForceIgnoreGroundSupport)
{
	SetHasForceIgnoreGroundSupportWithoutUpdate(ReasonTag, InHasForceIgnoreGroundSupport);
	UpdateHasGroundSupport();
}

void URoleMovementComponent::SetHasForceIgnoreGroundSupportWithoutUpdate(FString ReasonTag, bool InHasForceIgnoreGroundSupport)
{
	if (!ForceGroundSupportReason.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("SetHasForceIgnoreGroundSupportWithoutUpdate Error! Has ForceGroundSupportReason! InReason:%s"), *ReasonTag);
	}

	if (InHasForceIgnoreGroundSupport)
	{
		if (ForceIgnoreGroundSupportReason.Contains(ReasonTag))
		{
			ForceIgnoreGroundSupportReason[ReasonTag] += 1;

		}
		else
		{
			ForceIgnoreGroundSupportReason.Add(ReasonTag, 1);
		}
	}
	else
	{
		if (ForceIgnoreGroundSupportReason.Contains(ReasonTag))
		{
			ForceIgnoreGroundSupportReason[ReasonTag] -= 1;
			if (ForceIgnoreGroundSupportReason[ReasonTag] <= 0)
			{
				ForceIgnoreGroundSupportReason.Remove(ReasonTag);
			}
		}
	}
}

void URoleMovementComponent::SetIsRootMotionSourceForceGroundSupport(bool bForce)
{
	RoleMP.GetMovementContext().SetIsRootMotionSourceForceGroundSupport(bForce);
}

void URoleMovementComponent::SetHasForceLocoGroundSupport(FString ReasonTag, bool InHasForceLocoGroundSupport)
{
	SetHasForceLocoGroundSupportWithoutUpdate(ReasonTag, InHasForceLocoGroundSupport);
	UpdateHasGroundSupport();
}

void URoleMovementComponent::SetHasForceLocoGroundSupportWithoutUpdate(FString ReasonTag, bool InHasForceLocoGroundSupport)
{
	if (!ForceIgnoreLocoGroundSupportReason.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("SetHasForceLocoGroundSupportWithoutUpdate Error! Has ForceIgnoreLocoGroundSupportReason! InReason:%s"), *ReasonTag);
	}

	if (InHasForceLocoGroundSupport)
	{
		if (ForceLocoGroundSupportReason.Contains(ReasonTag))
		{
			ForceLocoGroundSupportReason[ReasonTag] += 1;

		}
		else
		{
			ForceLocoGroundSupportReason.Add(ReasonTag, 1);
		}
	}
	else
	{
		if (ForceLocoGroundSupportReason.Contains(ReasonTag))
		{
			ForceLocoGroundSupportReason[ReasonTag] -= 1;
			if (ForceLocoGroundSupportReason[ReasonTag] <= 0)
			{
				ForceLocoGroundSupportReason.Remove(ReasonTag);
			}
		}
	}
}

void URoleMovementComponent::SetHasForceIgnoreLocoGroundSupport(FString ReasonTag, bool InHasForceIgnoreLocoGroundSupport)
{
	SetHasForceIgnoreLocoGroundSupportWithoutUpdate(ReasonTag, InHasForceIgnoreLocoGroundSupport);
	UpdateHasGroundSupport();
}

void URoleMovementComponent::SetHasForceIgnoreLocoGroundSupportWithoutUpdate(FString ReasonTag, bool InHasForceIgnoreLocoGroundSupport)
{
	if (!ForceLocoGroundSupportReason.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("SetHasForceIgnoreLocoGroundSupportWithoutUpdate Error! Has ForceLocoGroundSupportReason! InReason:%s"), *ReasonTag);
	}

	if (InHasForceIgnoreLocoGroundSupport)
	{
		if (ForceIgnoreLocoGroundSupportReason.Contains(ReasonTag))
		{
			ForceIgnoreLocoGroundSupportReason[ReasonTag] += 1;

		}
		else
		{
			ForceIgnoreLocoGroundSupportReason.Add(ReasonTag, 1);
		}
	}
	else
	{
		if (ForceIgnoreLocoGroundSupportReason.Contains(ReasonTag))
		{
			ForceIgnoreLocoGroundSupportReason[ReasonTag] -= 1;
			if (ForceIgnoreLocoGroundSupportReason[ReasonTag] <= 0)
			{
				ForceIgnoreLocoGroundSupportReason.Remove(ReasonTag);
			}
		}
	}
}

void URoleMovementComponent::UpdateHasGroundSupport(bool bCheckMoveContext)
{
	bool bLastHasGroundSupport = bHasGroundSupport;
	bool bLastHasLocoGroundSupport = bHasLocoGroundSupport;
	if (bCheckMoveContext)
	{
		bLastMCHasForceGroundSupport = GetRoleMP().GetMovementContext().HasForceGroundSupport();
		bLastMCHasForceLocoGroundSupport = GetRoleMP().GetMovementContext().HasForceLocoGroundSupport();
	}

	if (!ForceGroundSupportReason.IsEmpty())
	{
		bHasGroundSupport = true;
	}
	else if (!ForceIgnoreGroundSupportReason.IsEmpty())
	{
		bHasGroundSupport = false;
	}
	else if (bLastMCHasForceGroundSupport)
	{
		bHasGroundSupport = true;
	}
	else
	{
		bHasGroundSupport = (MovementMode != EMovementMode::MOVE_Falling && MovementMode != EMovementMode::MOVE_Flying);
	}

	if (!ForceLocoGroundSupportReason.IsEmpty())
	{
		bHasLocoGroundSupport = true;
	}
	else if (!ForceIgnoreLocoGroundSupportReason.IsEmpty())
	{
		bHasLocoGroundSupport = false;
	}
	else if (bLastMCHasForceLocoGroundSupport)
	{
		bHasLocoGroundSupport = true;
	}
	else
	{
		bHasLocoGroundSupport = (MovementMode != EMovementMode::MOVE_Falling && MovementMode != EMovementMode::MOVE_Flying);
	}

	if (bNeedNotifyHasGroundSupportChanged && (bHasGroundSupport != bLastHasGroundSupport || bHasLocoGroundSupport != bLastHasLocoGroundSupport))
	{
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyHasGroundSupportChanged", bHasGroundSupport, bHasLocoGroundSupport);
		}
	}
}

void URoleMovementComponent::OnMovementModeChanged(EMovementMode PreviousMovementMode, uint8 PreviousCustomMode)
{
	// 挂载关联移动下，不进行mode的逻辑处理
	if (!IsInterconnectedMovement()) {
		Super::OnMovementModeChanged(PreviousMovementMode, PreviousCustomMode);
	}

	UpdateHasGroundSupport();
	UpdateIsFallingStepOnDetecting(MovementMode);
}

int32 URoleMovementComponent::SetGroundSupportFromAnimNotify(bool bForceLocoGroundSupport, bool bForceIgnoreLocoGroundSupport)
{
	if (!bForceLocoGroundSupport && !bForceIgnoreLocoGroundSupport)
	{
		// UE_LOG(LogTemp, Warning, TEXT("[szk]SetGroundSupportFromAnimNotify, InValid!"));
		return -1;
	}

	if (AnimNotifyGroundSupportControlToken > 0)
	{
		// 首先取消前置Notify的地面支撑控制
		// UE_LOG(LogTemp, Warning, TEXT("[szk]SetGroundSupportFromAnimNotify, Clear InAdvance! Token:%i"), AnimNotifyGroundSupportControlToken);
		ClearGroundSupportFromAnimNotify(AnimNotifyGroundSupportControlToken);
	}

	if (bForceLocoGroundSupport)
	{
		SetHasForceLocoGroundSupport(AnimNotifyGroundSupportControlReason.ToString(), true);
		bIsAnimNotifyForceLocoGroundSupport = bForceLocoGroundSupport;
	}
	else if (bForceIgnoreLocoGroundSupport)
	{
		SetHasForceIgnoreLocoGroundSupport(AnimNotifyGroundSupportControlReason.ToString(), true);
		bIsAnimNotifyForceIgnoreLocoGroundSupport = bForceIgnoreLocoGroundSupport;
	}

	AnimNotifyGroundSupportControlTokenCount += 1;
	if (AnimNotifyGroundSupportControlTokenCount > 99999)
	{
		AnimNotifyGroundSupportControlTokenCount = 1;
	}
	AnimNotifyGroundSupportControlToken = AnimNotifyGroundSupportControlTokenCount;
	/*UE_LOG(LogTemp, Warning, TEXT("[szk]SetGroundSupportFromAnimNotify, Token:%i, Force:%d, ForceIgnore:%d!"),
		AnimNotifyGroundSupportControlToken, bIsAnimNotifyForceLocoGroundSupport, bIsAnimNotifyForceIgnoreLocoGroundSupport);*/
	return AnimNotifyGroundSupportControlToken;
}

void URoleMovementComponent::ClearGroundSupportFromAnimNotify(int32 InToken)
{
	if (AnimNotifyGroundSupportControlToken == InToken)
	{
		if (bIsAnimNotifyForceLocoGroundSupport)
		{
			SetHasForceLocoGroundSupport(AnimNotifyGroundSupportControlReason.ToString(), false);
		}
		else if (bIsAnimNotifyForceIgnoreLocoGroundSupport)
		{
			SetHasForceIgnoreLocoGroundSupport(AnimNotifyGroundSupportControlReason.ToString(), false);
		}
		/*UE_LOG(LogTemp, Warning, TEXT("[szk]ClearGroundSupportFromAnimNotify, Token:%i, Force:%d, ForceIgnore:%d!"),
			AnimNotifyGroundSupportControlToken, bIsAnimNotifyForceLocoGroundSupport, bIsAnimNotifyForceIgnoreLocoGroundSupport);*/
		bIsAnimNotifyForceLocoGroundSupport = false;
		bIsAnimNotifyForceIgnoreLocoGroundSupport = false;
		AnimNotifyGroundSupportControlToken = -1;
	}
	
}
#pragma endregion MovementMode



#pragma region Smooth
void URoleMovementComponent::RefreshMeshAdditionalLR()
{
	if (!IsValid(CharacterOwner))
	{
		return;
	}

	if (UPrimitiveComponent* Mesh = CharacterOwner->GetMesh())
	{
		if (bOriginOMeshRLInited)
		{
			AdditionalMeshRL = Mesh->GetRelativeLocation() - OMeshRL - GetStickGroundMeshRL();
			AdditionalMeshRR = OMeshRR.Inverse() * Mesh->GetRelativeRotation().Quaternion();
		}
		else
		{
			// 还未更新OriginMeshRL时，不能触发Additional信息更新
			OMeshRL = Mesh->GetRelativeLocation();
			OMeshRR = Mesh->GetRelativeRotation().Quaternion();
			AdditionalMeshRL = FVector::ZeroVector;
			AdditionalMeshRR = FQuat::Identity;
		}
	}
}

void URoleMovementComponent::InitMeshOriginLR(bool InbForceReInit)
{
	if (!IsValid(CharacterOwner))
	{
		return;
	}

	if (UPrimitiveComponent* Mesh = CharacterOwner->GetMesh())
	{
		if (!InbForceReInit && bOriginOMeshRLInited)
		{
			// 重复执行InitMeshOriginLR，需要先回退OriginMesh的Location和Rotation
			OMeshRL = Mesh->GetRelativeLocation() - AdditionalMeshRL - GetStickGroundMeshRL();
			OMeshRR = Mesh->GetRelativeRotation().Quaternion() * AdditionalMeshRR.Inverse();
			AdditionalMeshRL = FVector::ZeroVector;
			AdditionalMeshRR = FQuat::Identity;
		}
		else
		{
			OMeshRL = Mesh->GetRelativeLocation();
			OMeshRR = Mesh->GetRelativeRotation().Quaternion();
		}

		Mesh->SetRelativeLocation(GetFinalMeshRL());
		Mesh->SetRelativeRotation(GetFinalMeshRR().Rotator());
		
		bOriginOMeshRLInited = true;
	}
}

void URoleMovementComponent::SetAdditionalMeshRL(float InLX, float InLY, float InLZ)
{
	if (bOriginOMeshRLInited)
	{
		// 只有执行过InitMeshOriginLR之后，才允许设置AdditionalMeshRL
		AdditionalMeshRL.X = InLX;
		AdditionalMeshRL.Y = InLY;
		AdditionalMeshRL.Z = InLZ;

		if (!IsValid(CharacterOwner))
		{
			return;
		}

		if (UPrimitiveComponent* Mesh = CharacterOwner->GetMesh())
		{
			Mesh->SetRelativeLocation(GetFinalMeshRL(), false, nullptr, ETeleportType::TeleportPhysics);
		}
	}
}

FVector URoleMovementComponent::GetStickGroundMeshRL()
{
	if (bUseStickGoundMeshOffset && IsValid(CharacterOwner))
	{
		if (UCapsuleComponent* CapsuleComp = CharacterOwner->GetCapsuleComponent())
		{
			FVector CapsuleScale = CapsuleComp->GetComponentScale();
			return FVector(0.0f, 0.0f, (FMath::Abs(CapsuleScale.Z) > 0.0f) ? (StaticDataInfo.StickGroundMeshZOffset / CapsuleScale.Z) : 0.0f);
		}
	}

	return FVector::ZeroVector;
}

void URoleMovementComponent::SetUseStickGroundMeshOffset(bool InbUse)
{
	if (bUseStickGoundMeshOffset == InbUse) {
		return;
	}

	bUseStickGoundMeshOffset = InbUse;
	if (bOriginOMeshRLInited)
	{
		if (!IsValid(CharacterOwner))
		{
			return;
		}

		if (UPrimitiveComponent* Mesh = CharacterOwner->GetMesh())
		{
			Mesh->SetRelativeLocation(GetFinalMeshRL());
		}
	}
}

void URoleMovementComponent::SetAdditionalMeshRL(const FVector& offset) {
	SetAdditionalMeshRL(offset.X, offset.Y, offset.Z);
}

void URoleMovementComponent::SetAdditionalMeshRR(float InRX, float InRY, float InRZ, float InRW)
{
	AdditionalMeshRR.X = InRX;
	AdditionalMeshRR.Y = InRY;
	AdditionalMeshRR.Z = InRZ;
	AdditionalMeshRR.W = InRW;

	if (!IsValid(CharacterOwner))
	{
		return;
	}

	if (UPrimitiveComponent* Mesh = CharacterOwner->GetMesh())
	{
		Mesh->SetRelativeRotation(GetFinalMeshRR(), false, nullptr, ETeleportType::TeleportPhysics);
	}
}

FVector URoleMovementComponent::GetFinalMeshRL() 
{ 
	return OMeshRL + AdditionalMeshRL + GetStickGroundMeshRL();
}


#pragma endregion Smooth


bool URoleMovementComponent::GetIsMainPlayer()
{
	if (IsMainPlayer >= 0){
		return IsMainPlayer == 1;
	}
	
	if (ICppEntityInterface* SelfCppEntity = UKGUEActorManager::GetLuaEntityByActor(CharacterOwner))
	{
		IsMainPlayer = SelfCppEntity->GetIsMainPlayer() ? 1 : 0;
		return IsMainPlayer == 1;
	}

	UE_LOG(LogTemp, Warning, TEXT("GetIsMainPlayer Failed! Result May be InCorrect!"));
	return IsMainPlayer == 1;
}

bool URoleMovementComponent::GetIsAvatar()
{
	if (IsAvatar >= 0) {
		return IsAvatar == 1;
	}

	if (ICppEntityInterface* SelfCppEntity = UKGUEActorManager::GetLuaEntityByActor(CharacterOwner))
	{
		IsAvatar = SelfCppEntity->GetIsAvatar() ? 1 : 0;
		return IsAvatar == 1;
	}

	UE_LOG(LogTemp, Warning, TEXT("GetIsAvatar Failed! Result May be InCorrect!"));
	return IsAvatar == 1;
}

bool URoleMovementComponent::IsVehicleDriver() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsRider;
}

bool URoleMovementComponent::IsDriveVehicleRelation() const
{
	return  EMoveDriveRelation::DriveVehicleAsCarrier <= eMoveDriveRelation && eMoveDriveRelation <= EMoveDriveRelation::DriveVehicleAsPassenger;
}

// 包括骑乘 和 载具
bool URoleMovementComponent::IsCarrierDriveRelationWhenAttached() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveMountAsCarrier || eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsCarrier ;
}

// 包括骑乘 和 载具
bool URoleMovementComponent::IsPassengerDriveRelationWhenAttached() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveMountAsPassenger || eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsPassenger;
}

bool URoleMovementComponent::IsRiderDriveRelationWhenAttached() const
{
	return eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsRider ||
			eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP1RiderAttachStage ||
				eMoveDriveRelation == EMoveDriveRelation::DriveMountAsP3RiderAttachStage;
}

//  会出现 RoleMovementComponent拿AnimInstance时, 动画ABP在线程并行求值的过程中
//  但ABP中一般是拿动画蓝图相关的内存区域、拿Skeleton这些不会涉及到gameplay数据的内容
//  所以, 这里进行AnimInstance的操作应该是不会出现Data race的。 
UBaseAnimInstance* URoleMovementComponent::GetAnimInstanceForMovement() const {
	AActor* Owner = GetOwner();
	if(ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(Owner))
	{
		return Cast<UBaseAnimInstance>(BaseCharacter->GetMesh() ? BaseCharacter->GetMesh()->GetAnimInstance() : nullptr);
	}
	return nullptr;
}

#pragma region RootMotion
int32 URoleMovementComponent::ApplyRootMotion
(
	int64 InSign, float SX, float SY, float SZ, float EX, float EY, float EZ, float InDuration, UCurveFloat* InTMCurve, UCurveVector* InPOCurve,
	int32 InPriority, float InPlayRate, float InClampVelocity, int32 InTypeMask, int32 InSettingFlags, float InMinPercent, float InMaxPercent, int32 AccumulateMode
)
{
	return ApplyRootMotion(InSign, FVector(SX, SY, SZ), FVector(EX, EY, EZ), InDuration, InTMCurve, InPOCurve, InPriority, InPlayRate, InClampVelocity, InTypeMask, InSettingFlags, InMinPercent, InMaxPercent, AccumulateMode);
}

int32 URoleMovementComponent::ApplyRootMotion
(
	int64 InSign, const FVector& InStart, const FVector& InEnd, float InDuration, UCurveFloat* InTMCurve, UCurveVector* InPOCurve,
	int32 InPriority, float InPlayRate, float InClampVelocity, int32 InTypeMask, int32 InSettingFlags, float InMinPercent, float InMaxPercent, int32 AccumulateMode
)
{
	for (const auto& RMS : CurrentRootMotion.RootMotionSources)
	{
		if (RMS.IsValid() && RMS->GetScriptStruct()->IsChildOf(FRootMotionSource_MoveToDynamicForce::StaticStruct()) && RMS->AccumulateMode == ERootMotionAccumulateMode::Override)
		{
			RMS->Status.SetFlag(ERootMotionSourceStatusFlags::MarkedForRemoval);
		}
	}

	for (const auto& RMS : CurrentRootMotion.PendingAddRootMotionSources)
	{
		if (RMS.IsValid() && RMS->GetScriptStruct()->IsChildOf(FRootMotionSource_MoveToDynamicForce::StaticStruct()) && RMS->AccumulateMode == ERootMotionAccumulateMode::Override)
		{
			RMS->Status.SetFlag(ERootMotionSourceStatusFlags::MarkedForRemoval);
		}
	}

	// 制作RootMotionSource
	TSharedPtr<FC7RootMotionSource_MoveToDynamicForce> MoveToForce = MakeShareable<FC7RootMotionSource_MoveToDynamicForce>(new FC7RootMotionSource_MoveToDynamicForce());
	if (MoveToForce.IsValid())
	{
		MoveToForce->AccumulateMode = (ERootMotionAccumulateMode)AccumulateMode;
		MoveToForce->bRestrictSpeedToExpected = true;
		// 设置RootMotion的Flag
		int32 BitMask = 1;
		while (BitMask <= InSettingFlags)
		{
			if ((BitMask & InSettingFlags) > 0)
			{
				MoveToForce->Settings.SetFlag((ERootMotionSourceSettingsFlags)BitMask);
			}

			BitMask <<= 1;
		}

		MoveToForce->InstanceName = FName(FString::Printf(TEXT("%lld"), InSign));
		MoveToForce->Priority = InPriority;
		MoveToForce->StartLocation = InStart;
		MoveToForce->TargetLocation = InEnd;
		MoveToForce->Duration = FMath::Max(InDuration, 0.01f);
		MoveToForce->PlayRate = FMath::Max(InPlayRate, 0.01f);
		MoveToForce->TimeMappingCurve = InTMCurve;
		MoveToForce->PathOffsetCurve = InPOCurve;
		MoveToForce->TypeMask = InTypeMask;

		if (InClampVelocity > 1e-2)
		{
			MoveToForce->FinishVelocityParams.Mode = ERootMotionFinishVelocityMode::ClampVelocity;
			MoveToForce->FinishVelocityParams.ClampVelocity = InClampVelocity;
		}
		else if (InClampVelocity < 0.0)
		{
			MoveToForce->FinishVelocityParams.Mode = ERootMotionFinishVelocityMode::MaintainLastRootMotionVelocity;
		}
		else
		{
			MoveToForce->FinishVelocityParams.Mode = ERootMotionFinishVelocityMode::SetVelocity;
			MoveToForce->FinishVelocityParams.SetVelocity = FVector::ZeroVector;
		}

		MoveToForce->SetServerPercent(InMinPercent, InMaxPercent);

		return ApplyRootMotionSource(MoveToForce);
	}

	return -1;
}


int32 URoleMovementComponent::AddViolentRotateParams(float TargetRoll, float TargetPitch, float TargetYaw, float InMaxRotateSpeed, float BlendInTime, float BlendOutTime,
	float RotateRuleRoll, float RotateRulePitch, float RotateRuleYaw, float InDuration)
{
	StopCurrentMove();
	FRotator TargetRot = FRotator(TargetPitch, TargetYaw, TargetRoll);
	FRotator RotateRule = FRotator(RotateRulePitch, RotateRuleYaw, RotateRuleRoll);

	TSharedPtr<FC7RootMotion_ViolentRotate> ViolentRotate = MakeShareable<FC7RootMotion_ViolentRotate>(new FC7RootMotion_ViolentRotate());
	if (ViolentRotate.IsValid())
	{
		ViolentRotate->Duration = InDuration;
		ViolentRotate->TargetRot = TargetRot;
		ViolentRotate->MaxRotateSpeed = InMaxRotateSpeed;
		ViolentRotate->BlendIn = BlendInTime;
		ViolentRotate->BlendOut = BlendOutTime;
		ViolentRotate->RotateRule = RotateRule;

		if (ViolentRotate->Initialize())
		{
			CurRootMotionContext.CurRootMotion.Reset();
			CurRootMotionContext.CurRootMotion = ViolentRotate;
		}
		return CurRootMotionContext.CurRootMotion->GID;
	}
	return -1;
}

int32 URoleMovementComponent::AddMoveLinearSpeed(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InDuration, bool KeepGravity)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());

	FVector InEnd(EndPosX, EndPosY, EndPosZ);
	check(!InEnd.ContainsNaN());

	StopCurrentMove();
	TSharedPtr<FC7RootMotion_Move3D> Move3D = MakeShareable<FC7RootMotion_Move3D>(new FC7RootMotion_Move3D());
	if (Move3D.IsValid())
	{
		Move3D->StartPosition = InStart;
		Move3D->EndPosition = InEnd;
		Move3D->Duration = InDuration;
		Move3D->KeepGravity = KeepGravity;
		if (Move3D->Initialize())
		{
			CurRootMotionContext.CurRootMotion = Move3D;
		}
		return Move3D->GID;
	}
	return -1;
}

int32 URoleMovementComponent::AddMoveVariableSpeed(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InitSpeed, float Acc, float MaxDuration)
{
	FVector InSpecifyTargetPos(EndPosX, EndPosY, EndPosZ);
	check(!InSpecifyTargetPos.ContainsNaN());

	FVector StartPos(StartPosX, StartPosY, StartPosZ);
	check(!StartPos.ContainsNaN());

	StopCurrentMove();

	TSharedPtr<FC7RootMotion_UnifornVariableMotion>  UnifornVariableMotion = MakeShareable<FC7RootMotion_UnifornVariableMotion>(new FC7RootMotion_UnifornVariableMotion());
	if (UnifornVariableMotion.IsValid())
	{
		UnifornVariableMotion->Duration = MaxDuration;
		UnifornVariableMotion->InitVelocityVal = InitSpeed;
		UnifornVariableMotion->AccelerationVal = Acc;
		UnifornVariableMotion->TargetPos = InSpecifyTargetPos;
		UnifornVariableMotion->StartPos = StartPos;

		if (UnifornVariableMotion->Initialize())
		{
			CurRootMotionContext.CurRootMotion = UnifornVariableMotion;
		}
		return UnifornVariableMotion->GID;
	}
	return -1;
}

int32 URoleMovementComponent::AddMoveParabola(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InDuration, float InPeekHeight)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());

	FVector InEnd(EndPosX, EndPosY, EndPosZ);
	check(!InEnd.ContainsNaN());

	StopCurrentMove();

	TSharedPtr<FC7RootMotion_MoveParaCurve> MoveParaCurve = MakeShareable<FC7RootMotion_MoveParaCurve>(new FC7RootMotion_MoveParaCurve());
	if (MoveParaCurve.IsValid())
	{
		MoveParaCurve->Duration = InDuration;
		MoveParaCurve->PeekHeight = InPeekHeight;
		MoveParaCurve->StartPosition = InStart;
		MoveParaCurve->EndPosition = InEnd;
		if (MoveParaCurve->Initialize())
		{
			CurRootMotionContext.CurRootMotion = MoveParaCurve;
		}
		return MoveParaCurve->GID;
	}
	return -1;
}

int32 URoleMovementComponent::AddMoveMustHitTarget(KGObjectID TargetEntityID, float InDuration)
{
	if (TargetEntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogTemp, Log, TEXT("URoleMovementComponent::AddMoveMustHitTarget, invalid TargetEntityID"));
		return -1;
	}
	
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager)
	{
		UE_LOG(LogTemp, Error, TEXT("URoleMovementComponent::AddMoveMustHitTarget, invalid ActorManager"));
		return -1;
	}

	auto* TargetEntity = ActorManager->GetLuaEntity(TargetEntityID);
	if (!TargetEntity)
	{
		UE_LOG(LogTemp, Log, TEXT("URoleMovementComponent::AddMoveMustHitTarget, invalid TargetEntity, %lld"), TargetEntityID);
		return -1;
	}

	StopCurrentMove();

	TSharedPtr<FC7RootMotion_MustHitTarget> MoveMissile = MakeShareable<FC7RootMotion_MustHitTarget>(new FC7RootMotion_MustHitTarget());
	if (MoveMissile.IsValid())
	{
		MoveMissile->Duration = InDuration;
		MoveMissile->TargetEntity = TargetEntity;
		MoveMissile->TargetEntityID = TargetEntityID;

		if (MoveMissile->Initialize())
		{
			CurRootMotionContext.CurRootMotion = MoveMissile;
		}
		return MoveMissile->GID;
	}
	return -1;
}

int32 URoleMovementComponent::AddMoveTrackTarget(KGObjectID TargetEntityID, float InVelocity, float Acc, float RotSpeed, float InRotAngleThreshold, float InDuration)
{
	if (TargetEntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogTemp, Log, TEXT("URoleMovementComponent::AddMoveTrackTarget, invalid TargetEntityID"));
		return -1;
	}
	
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager)
	{
		UE_LOG(LogTemp, Error, TEXT("URoleMovementComponent::AddMoveTrackTarget, invalid ActorManager"));
		return -1;
	}

	auto* TargetEntity = ActorManager->GetLuaEntity(TargetEntityID);
	if (!TargetEntity)
	{
		UE_LOG(LogTemp, Log, TEXT("URoleMovementComponent::AddMoveTrackTarget, invalid TargetEntity, %lld"), TargetEntityID);
		return -1;
	}

	StopCurrentMove();

	TSharedPtr<FC7RootMotion_TrackTarget> MoveMissile = MakeShareable<FC7RootMotion_TrackTarget>(new FC7RootMotion_TrackTarget());
	if (MoveMissile.IsValid())
	{
		MoveMissile->Duration = InDuration;
		MoveMissile->TargetEntityID = TargetEntityID;
		MoveMissile->TargetEntity = TargetEntity;
		MoveMissile->RotSpeed = RotSpeed;
		MoveMissile->AccelerationVal = Acc;
		MoveMissile->InitVelocityVal = InVelocity;
		MoveMissile->RotAngleThreshold = InRotAngleThreshold;

		if (MoveMissile->Initialize())
		{
			CurRootMotionContext.CurRootMotion = MoveMissile;
		}
		return MoveMissile->GID;
	}
	return -1;
}

int32 URoleMovementComponent::AddMoveLinearSpeedWithCurve(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InDuration, const FString& RootMotionCurvePath, bool KeepGravity, float InScale)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());

	FVector InEnd(EndPosX, EndPosY, EndPosZ);
	check(!InEnd.ContainsNaN());

	StopCurrentMove();

	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogTemp, Error, TEXT("invalid asset manager"));
		return -1;
	}

	TSharedPtr<FC7RootMotion_Move3DCurve> Move3D = MakeShareable<FC7RootMotion_Move3DCurve>(new FC7RootMotion_Move3DCurve());
	if (Move3D.IsValid())
	{
		Move3D->StartPosition = InStart;
		Move3D->EndPosition = InEnd;
		Move3D->Duration = InDuration;
		Move3D->KeyFrameCurve = nullptr;
		Move3D->KeepGravity = KeepGravity;
		Move3D->Scale = InScale;
		if (Move3D->Initialize())
		{
			CurRootMotionContext.CurRootMotion = Move3D;

#if !UE_BUILD_TEST && !UE_BUILD_SHIPPING
			CurRootMotionContext.AssetPathDebugUse = RootMotionCurvePath;
#endif
			CurRootMotionContext.AssetLoadID = AssetManager->AsyncLoadAsset(
				RootMotionCurvePath, FAsyncLoadCompleteDelegate::CreateUObject(this, &URoleMovementComponent::OnMoveCurveLoaded), static_cast<int32>(EAssetLoadPriority::MoveCurve));
			return Move3D->GID;
		}
	}
	return -1;
}


void URoleMovementComponent::OnMoveCurveLoaded(int InLoadID, UObject* LoadedAsset)
{
	UCurveLinearColor* CurveLinearColor = Cast<UCurveLinearColor>(LoadedAsset);
	if (!CurveLinearColor)
	{
#if !UE_BUILD_TEST && !UE_BUILD_SHIPPING
		UE_LOG(LogTemp, Error, TEXT("URoleMovementComponent::OnMoveCurveLoaded, invalid curve asset loaded, %s"), *CurRootMotionContext.AssetPathDebugUse);
#endif
		return;
	}

	// 设置曲线数据
	if (CurRootMotionContext.CurRootMotion.IsValid())
	{
		TSharedPtr<FC7RootMotion_Move3DCurve> Move3D = StaticCastSharedPtr<FC7RootMotion_Move3DCurve>(CurRootMotionContext.CurRootMotion);
		Move3D->SetCurve(*CharacterOwner, CurveLinearColor);
	}
	CurRootMotionContext.AssetLoadID.Reset();
}

void URoleMovementComponent::StopCurrentMove()
{
	if (CurRootMotionContext.CurRootMotion.IsValid())
	{
		CurRootMotionContext.CurRootMotion.Reset();

	}

	if (CurRootMotionContext.AssetLoadID.IsSet())
	{
		UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
		if (AssetManager)
		{
			AssetManager->CancelAsyncLoadByLoadID(CurRootMotionContext.AssetLoadID.GetValue());
			CurRootMotionContext.AssetLoadID.Reset();
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("invalid asset manager"));
		}
	}
}

bool URoleMovementComponent::IsMoveKeepGravity()
{
	if (CurRootMotionContext.CurRootMotion.IsValid())
	{
		return CurRootMotionContext.CurRootMotion->KeepGravity;
	}
	return false;
}

void URoleMovementComponent::RemoveRootMotionByID(int32 InID)
{
	RemoveRootMotionSourceByID((uint16)InID);
	if (CurRootMotionContext.CurRootMotion.IsValid() && CurRootMotionContext.CurRootMotion->GID == InID)
	{
		StopCurrentMove();
	}
}

void URoleMovementComponent::RemoveRootMotion(FName InstanceName)
{
	RemoveRootMotionSource(InstanceName);
}

bool URoleMovementComponent::IsRunningRootMotion()
{
	return IsRunningAnimRootMotion() || IsRunningRootMotionSource();
}

bool URoleMovementComponent::IsRunningAnimRootMotion()
{

	return HasValidData() && (HasAnimRootMotion() || CharacterOwner->IsPlayingNetworkedRootMotionMontage()) && AllowRootMotionByTypeMask(1);
}

bool URoleMovementComponent::IsRunningRootMotionSource()
{
	if (!CurrentRootMotion.HasActiveRootMotionSources())
	{
		return false;
	}

	int32 ValidRMS = 0;
	for (int32 i = 0; i < CurrentRootMotion.RootMotionSources.Num(); ++i)
	{
		const TSharedPtr<FRootMotionSource>& RMS = CurrentRootMotion.RootMotionSources[i];

		if (RMS.IsValid() && RMS->GetScriptStruct()->IsChildOf(FC7RootMotionSource_MoveToDynamicForce::StaticStruct()))
		{
			if (FC7RootMotionSource_MoveToDynamicForce* MoveToActorForce = static_cast<FC7RootMotionSource_MoveToDynamicForce*>(RMS.Get()))
			{
				if (AllowRootMotionByTypeMask(MoveToActorForce->TypeMask))
				{
					ValidRMS += 1;
				}
			}
		}
		else
		{
			ValidRMS += 1;
		}
	}

	for (int32 i = 0; i < CurrentRootMotion.PendingAddRootMotionSources.Num(); ++i)
	{
		const TSharedPtr<FRootMotionSource>& RMS = CurrentRootMotion.PendingAddRootMotionSources[i];

		if (RMS.IsValid() && RMS->GetScriptStruct()->IsChildOf(FC7RootMotionSource_MoveToDynamicForce::StaticStruct()))
		{
			if (FC7RootMotionSource_MoveToDynamicForce* MoveToActorForce = static_cast<FC7RootMotionSource_MoveToDynamicForce*>(RMS.Get()))
			{
				if (AllowRootMotionByTypeMask(MoveToActorForce->TypeMask))
				{
					ValidRMS += 1;
				}
			}
		}
		else
		{
			ValidRMS += 1;
		}
	}

	return ValidRMS > 0;
}

#pragma endregion RootMotion


#pragma region Locomotion
void URoleMovementComponent::SetLocomotionStateInMask(uint8 NewLocomotionType)
{
	// 第一位是给IsLocoStart使用的，第二位是LocoStateInnerIndex，后6位是LocomotionState
	LocomotionStateMaskData = LocomotionStateMaskData & LOCO_INNERINDEX_MASK;
	LocomotionStateMaskData |= (NewLocomotionType & LOCO_STATE_MASK);
}

uint8 URoleMovementComponent::GetLocomotionStateFromMask() const
{
	return LocomotionStateMaskData & LOCO_STATE_MASK;
}

void URoleMovementComponent::SetIsLocoStartInMask(bool bLocoStart)
{
	// 原先该参数保留在LocomotionStateMaskData，现在单独抽出，并保留函数名InMask后缀以区分
	bIsLocoStart = bLocoStart;
}

bool URoleMovementComponent::GetIsLocoStartFromMask() 
{
	// 原先该参数保留在LocomotionStateMaskData，现在单独抽出，并保留函数名InMask后缀以区分
	return bIsLocoStart;
}

bool URoleMovementComponent::GetIsLocoStart()
{
	if (ForceLocoStart == FORCE_LOCO_START_TRUE)
	{
		return true;
	}
	else if (ForceLocoStart == FORCE_LOCO_START_FALSE)
	{
		return false;
	}
	return bIsLocoStart;
}

void URoleMovementComponent::SetLocoStateInnerIndexInMask(uint8 NewLocoStateInnerIndex)
{
	// 目前LocoStateInnerIndex只能为0或者1，先简单处理
	if (NewLocoStateInnerIndex > 0)
	{
		LocomotionStateMaskData |= LOCO_INNERINDEX_MASK;
	}
	else
	{
		LocomotionStateMaskData &= ~LOCO_INNERINDEX_MASK;
	}
}

uint8 URoleMovementComponent::GetLocoStateInnerIndexFromMask()
{
	return (LocomotionStateMaskData & LOCO_INNERINDEX_MASK) >> LOCO_INNERINDEX_OFFSET;
}

void URoleMovementComponent::DoAnyLocoStateChangedFromStateMachine(const uint8 InNewLocomotionState, const int InLocoStateInnerIndex)
{
	if (LocoStateDataSource == ELocoStateDataSource::ELSDS_LocomotionStateMaskData)
	{
		uint8 LastLocomotionState = GetLocomotionStateFromMask();

		// 对于转身这种ABP进行reentry的状态, 在进行crossfade的时候, 引擎是不支持transition的, 所以这里用重置progress来解决P3表现问题
		// 详见
		if (LastLocomotionState == InNewLocomotionState && StaticDataInfo.ResetProgressWhenSyncReentryLocoStates.Contains(InNewLocomotionState))
		{
			SetNeedResetLocoStateProgressForSync();
		}
		
		if (SetLocomotionState(InNewLocomotionState))
		{
			SetLocoStateInnerIndex(InLocoStateInnerIndex << LOCO_INNERINDEX_OFFSET);
		}
	}
	
	// 因为可能随时会有切换LocoStateDataSource的需求，因此LocalLocomotionState也持续更新
	// 默认LocoStateDataSource为ELSDS_LocomotionStateMaskData时，该数据不会有影响
	SetLocalLocomotionState(InNewLocomotionState);
}

void URoleMovementComponent::SetLocoStateDataSource(ELocoStateDataSource InSource)
{
	if (LocoStateDataSource == InSource)
	{
		return;
	}

	if (InSource == ELocoStateDataSource::ELSDS_LocalLocoStateData)
	{
		uint8 LastLocoState = GetLocomotionStateDataMask();
		DoLocoStateChangeNotify(LastLocoState, GetLocalLocomotionState());
	}
	else if (InSource == ELocoStateDataSource::ELSDS_LocomotionStateMaskData)
	{
		uint8 NewLocoState = GetLocomotionStateDataMask();
		DoLocoStateChangeNotify(GetLocalLocomotionState(), NewLocoState);
	}
	
	LocoStateDataSource = InSource;
}

void URoleMovementComponent::ReceiveNeedResetLocoStateProgressForSync()
{
	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		AnimInstance->SetAllSequencePlayerProgressInStateNode(GetLocomotionStateFromMask(), 0.0f);
	}

	if (IsDriveMountDriveAttachStage()) {
		if (MountRelationCooperator.IsValid()) {
			MountRelationCooperator->ReceiveNeedResetLocoStateProgressForSync();
		}

		return;
	}
	
}
#pragma endregion Locomotion


void URoleMovementComponent::SetNavWalkingPhysics(bool bEnable)
{
	Super::SetNavWalkingPhysics(bEnable);

	// NOTE @liufan NavWalking修改ECC_WorldStatic，ECC_WorldDynamic碰撞属性为Overlap，否则会导致无法交互
	if (UpdatedPrimitive)
	{
		if (bEnable)
		{
			UpdatedPrimitive->SetCollisionResponseToChannel(ECC_WorldStatic, ECR_Overlap);
			UpdatedPrimitive->SetCollisionResponseToChannel(ECC_WorldDynamic, ECR_Overlap);
		}
	}
}



#pragma region Network
void URoleMovementComponent::ReceiveSetLocationAndRotation(float X, float Y, float Z, float Roll, float Pitch, float Yaw, bool InNeedStickGround)
{
	if (!IsActive() || !HasValidData())
	{
		return;
	}
	ALOG_DEBUG_POSITION(this, "URoleMovementComponent::ReceiveSetLocationAndRotation Position[%f,%f,%f]", X, Y, Z);
	MovementSimulator.Clear(EMoveSimulateClearReason::SetLocationAndRotation);

	FVector NewLocation(X, Y, Z);
	if(InNeedStickGround)
	{
		FixServerLocation(MovementMode, NewLocation);
	}
	
	FRotator NewRotation(Pitch, Yaw, Roll);

	CharacterOwner->SetActorLocationAndRotation(NewLocation, NewRotation);

#if UE_BUILD_DEVELOPMENT
	if (ABaseCharacter::IsShowMoveSyncHistoryInConfig(GetCharacterOwner()))
	{
		if (ISceneDrawerInterface* drawerSubsystemPtr = ABaseCharacter::GetSceneDrawerTool())
		{
			drawerSubsystemPtr->DrawMoveSyncData(NewLocation, NewRotation, FColor::Red);
		}
	}
#endif
}

void URoleMovementComponent::FixServerLocation(TEnumAsByte<EMovementMode> InMode, float InX, float InY, float InZ, float& OutX, float& OutY, float& OutZ)
{
	FVector Result(InX, InY, InZ);
	FixServerLocation(InMode, Result);

	OutX = Result.X;
	OutY = Result.Y;
	OutZ = Result.Z;
}

void URoleMovementComponent::FixServerLocation(TEnumAsByte<EMovementMode> InMode, FVector& InOutLocation)
{
	if (InMode == MOVE_Walking || InMode == MOVE_NavWalking)
	{
		FFindFloorResult FixedServerFloor;
		FindFloor(InOutLocation, FixedServerFloor, true, nullptr);
		if (FixedServerFloor.IsWalkableFloor())
		{
			InOutLocation.Z = InOutLocation.Z - FixedServerFloor.GetDistanceToFloor();
		}
	}
}
#pragma endregion Network

#pragma region Synchronization
int64 URoleMovementComponent::GetEntityId()
{
	if (!CharacterOwner)
	{
		UE_LOG(LogTemp, Error, TEXT("[Synchronization] URoleMovementComponent::GetEntityId get CharacterOwner failed"));
		return 0;
	}
	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(CharacterOwner);
	if (!BaseCharacter)
	{
		UE_LOG(LogTemp, Error, TEXT("[Synchronization] URoleMovementComponent::GetEntityId cast to ABaseCharacter failed"));
		return 0;
	}
	return BaseCharacter->GetEntityUID();
}

int32 URoleMovementComponent::GetSpaceId()
{
	if (!CharacterOwner)
	{
		UE_LOG(LogTemp, Error, TEXT("[Synchronization] URoleMovementComponent::GetSpaceId get CharacterOwner failed"));
		return 0;
	}
	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(CharacterOwner);
	if (!BaseCharacter)
	{
		UE_LOG(LogTemp, Error, TEXT("[Synchronization] URoleMovementComponent::GetSpaceId cast to ABaseCharacter failed"));
		return 0;
	}
	auto* CppEntity = UKGUEActorManager::GetLuaEntityByActor(BaseCharacter);
	if (!CppEntity)
	{
		UE_LOG(LogTemp, Error, TEXT("[Synchronization] URoleMovementComponent::GetSpaceId get CppEntity failed"));
		return 0;
	}
	return CppEntity->GetLogicSpaceID();
}

void URoleMovementComponent::OnReceiveMovementData(MovementData&& Data)
{
	if (Data.Protocol == NetChannelDataProtocol::ClientSyncMovement && eMoveSyncRole == EMoveSyncRole::RoleSyncSourceFromOwnClient)
	{
		if (URoleMovementComponent* MoveComp = GetEntityMoveComponent(DebugEntityId); MoveComp)
		{
			MoveComp->MovementSimulator.OnReceiveMovementData(std::move(Data));
		}
	}
	else if (Data.ControlEntityId != 0)
	{
		URoleMovementComponent* MoveComp = GetEntityMoveComponent((KGEntityID)Data.ControlEntityId);
		if (MoveComp)
		{
			MoveComp->MovementSimulator.OnReceiveMovementData(std::move(Data));
		}
	}
	else
	{
		MovementSimulator.OnReceiveMovementData(std::move(Data));
	}
}

void URoleMovementComponent::OnReceiveRotateInstantly(const RotateInstantlyMsg& Msg)
{
	if (!Msg.FromServer && eMoveSyncRole == EMoveSyncRole::RoleSyncSourceFromOwnClient)
	{
		if (URoleMovementComponent* MoveComp = GetEntityMoveComponent(DebugEntityId); MoveComp)
		{
			MoveComp->MovementSimulator.OnReceiveRotateInstantly(Msg);
		}
	}
	else
	{
		MovementSimulator.OnReceiveRotateInstantly(Msg);
	}
}

void URoleMovementComponent::OnReceiveHandshake(const HandshakeMsg& Msg)
{
	MovementSynchronizer.OnHandshake(Msg.Protocol, Msg.SpaceId);
}

void URoleMovementComponent::ServerLocomotionStateUpdate(uint8 LocomotionState, uint8 LocomotionMoveType)
{
	UE_LOG(LogRoleMovement, Log, TEXT("URoleMovementComponent::ServerLocomotionStateUpdate LocomotionState[%u], MoveType[%u]"),
		LocomotionState, LocomotionMoveType);

	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		AnimInstance->SetAnimMoveMode(LocomotionMoveType);
	}
}

void URoleMovementComponent::GetTargetDirectionParam(bool& bHasDirection, float& TargetDirection)
{
	MovementSimulator.GetTargetDirectionParam(bHasDirection, TargetDirection);
}

void URoleMovementComponent::UpdateIsUsingTargetAngleLean(bool bTargetAngle)
{
	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		AnimInstance->SetBodyLeanAxisDataSource(bTargetAngle ? EBodyLeanAxisDataSource::DestAngle : EBodyLeanAxisDataSource::None);
		AnimInstance->SetLocEnableBodyLean(bTargetAngle);
	}
}

void URoleMovementComponent::SetClientMoveDataRelativeTarget(int64 TargetGUID)
{
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this);
	if (!UOAM)
	{
		return;
	}

	ClearClientMoveDataRelativeTarget();
	
	if (AActor* InTarget = Cast<AActor>(UOAM->GetObjectByID(TargetGUID)))
	{
		ClientMoveDataRelativeTarget = InTarget;
		MovementSynchronizer.SetLastFrameRelativePosition(CharacterOwner->GetActorLocation() - InTarget->GetActorLocation());

		if(ABaseCharacter *MovePlatformTarget = Cast<ABaseCharacter>(ClientMoveDataRelativeTarget))
		{
			if(URoleMovementComponent *TargetRMC = Cast<URoleMovementComponent>(MovePlatformTarget->GetCharacterMoveComp()))
			{
				PrimaryComponentTick.AddPrerequisite(TargetRMC, TargetRMC->PrimaryComponentTick);
			}
			
		}
	}
}

// 这里测试一下, 如果脚本做的不干净, 这里可能调度依赖问题, 就要增加机制强制让Target被EndPlay的时候解除掉调度的依赖处理
void URoleMovementComponent::ClearClientMoveDataRelativeTarget()
{
	if(ClientMoveDataRelativeTarget.IsValid())
	{
		if(ABaseCharacter *MovePlatformTarget = Cast<ABaseCharacter>(ClientMoveDataRelativeTarget))
		{
			if(URoleMovementComponent *TargetRMC = Cast<URoleMovementComponent>(MovePlatformTarget->GetCharacterMoveComp()))
			{
				PrimaryComponentTick.RemovePrerequisite(TargetRMC, TargetRMC->PrimaryComponentTick);
			}
			
		}
	}
	
	ClientMoveDataRelativeTarget = nullptr;
	MovementSynchronizer.SetLastFrameRelativePosition(FVector::ZeroVector);
}

void URoleMovementComponent::SetClientMoveSyncRole(EMoveSyncRole syncRole)
{
	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement()) {
		// P3 玩家, 禁止调状态机动作跳转
		AnimInstance->SetIsSlaveAnimControl(syncRole == EMoveSyncRole::RoleSyncSourceFromOtherClient);
	}
	
	eMoveSyncRole = syncRole;
}

void URoleMovementComponent::ConsumeActorDataCache(int64 EntityId)
{
	auto Entity = UKGUEActorManager::GetLuaEntity(GetWorld(), EntityId);
	if (!Entity)
	{
		UE_LOG(LogRoleMovement, Error, TEXT("URoleMovementComponent::ConsumeActorDataCache get Entity failed, EntityId[%lld]"), EntityId);
		return;
	}
	Entity->OnEnterWorld();
}

void URoleMovementComponent::ConsumeLocoStateMaskFromNet(uint8 locoStateMask, bool InbIsLocoStart) {
	// 注意: 下面两个判断的根本原因是玩家角���的权威源差异引起,
	// 移动起始和结束, IsLocoStart 权威源有两个: [1] P1客户端当ServerForceControl == false时, 由客户端上行;  [2]  其他情况由服务端下行 (非玩家角色只有服务器权威)
	//
	// 但是, LocomotionState目前只有客户端P1玩家有该操控变动逻辑, 只有P1客户端是权威源

	// 有数据下行, 但是本地不是网络模拟处理流程, 直接放弃数据

	bool needConsume = GetCurrentIsNetSimulate();
	needConsume = needConsume || eMoveDriveRelation == EMoveDriveRelation::DriveMountAsCarrier;

	if (!needConsume) {
		return;
	}

	if (IsDriveMountDriveAttachStage()) {
		if (MountRelationCooperator.IsValid()) {
			MountRelationCooperator->ConsumeLocoStateMaskFromNet(locoStateMask, InbIsLocoStart);
		}

		return;
	}

	SetIsLocoStart(InbIsLocoStart);

	// P1 ServerForceControl打开后, 服务器下行数据, 里面的LocomotionState数据由P1上行, 不再需要重复处理
	if (IsNeedSyncUpMovement) {
		return;
	}

	// 这里需要注意，玩家断线, 服务器会设置LocoState为0，会触发下面SetMovementModeByLocoState的LocoState恢复默认机制
	uint8 LocoState = locoStateMask & LOCO_STATE_MASK;
	if (eMoveSyncRole == EMoveSyncRole::RoleSyncSourceFromServer && LocoState == 0)
	{
		// 如果是从服务器控制的有效LocoState回归0，则重置LocoState和MovementMode
		if (GetLocomotionStateFromMask() != 0)
		{
			SetLocomotionStateInMask(LocoState);
			SetMovementModeByLocoState(LocoState);
		}
		return;
	}

	const uint8 LocoSubState = locoStateMask & LOCO_INNERINDEX_MASK;
	bool bNeedLocoCrossfade = SetLocomotionState(LocoState);
	SetLocoStateInnerIndex(LocoSubState);
	LocoState = SetMovementModeByLocoState(LocoState);

	if (bNeedLocoCrossfade)
	{
		const auto* Mesh = CharacterOwner->GetMesh();
		UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement();
		if (AnimInstance)
		{
			AnimInstance->LocomotionCrossfadeInFixedTime(LocoState, 0.1f);
		}
	}
}

void URoleMovementComponent::DoSyncUpMovementData(float DeltaTime) {

	QUICK_SCOPE_CYCLE_COUNTER(URoleMovementComponent_DoSyncUpMovementData)
	
	// 更新后的快照
	if (CaptureNetSynchronizeSnapshot(CapturedMovementSnapshot, MovementSynchronizer.GetMoveSyncMode())) {

		// 尝试将数据发送给服务器
		MovementSynchronizer.TrySyncMovement(DeltaTime, CapturedMovementSnapshot);
	}
}

void URoleMovementComponent::DoSyncUpIdleMovementData()
{
	if (CaptureNetSynchronizeSnapshot(CapturedMovementSnapshot, MovementSynchronizer.GetMoveSyncMode()))
	{
		CapturedMovementSnapshot.IsLocoStart = false;
		CapturedMovementSnapshot.LocomotionState = 0;
		CapturedMovementSnapshot.IsJumping = false;
		MovementSynchronizer.TrySyncMovement(0.0f, CapturedMovementSnapshot);
	}
}

URoleMovementComponent* URoleMovementComponent::GetEntityMoveComponent(KGEntityID EntityId)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogRoleMovement, Error, TEXT("URoleMovementComponent::GetEntityMoveComponent GetCurrentPlayWorld failed"));
		return nullptr;
	}
	auto Entity = UKGUEActorManager::GetLuaEntity(World, EntityId);
	if (!Entity)
	{
		return nullptr;
	}
	auto Character = Cast<ABaseCharacter>(Entity->GetLuaEntityBase()->GetActor());
	if (!Character)
	{
		UE_LOG(LogRoleMovement, Error, TEXT("URoleMovementComponent::GetEntityMoveComponent cast to ABaseCharacter failed"));
		return nullptr;
	}
	URoleMovementComponent* MoveComp = Cast<URoleMovementComponent>(Character->GetMovementComponent());
	if (!MoveComp)
	{
		UE_LOG(LogRoleMovement, Error, TEXT("URoleMovementComponent::GetEntityMoveComponent get URoleMovementComponent failed"));
		return nullptr;
	}
	if (MoveComp->GetLocallyControlled())
	{
		UE_LOG(LogRoleMovement, Error, TEXT("URoleMovementComponent::GetEntityMoveComponent is locally controlled"));
		return nullptr;
	}
	return MoveComp;
}

void URoleMovementComponent::SetMovementVisibility(bool IsVisible)
{
	if(IsVisible == false){
		SimulateDeltaThresholdWhenInvisible = SimulateDeltaThresholdWhenInvisibleConfig;
	}
	else
	{
		SimulateDeltaThresholdWhenInvisible = 0;
	}

	CurrentSimulateDeltaThreshold = FMath::Max(SimulateDeltaThresholdWhenInvisible, SimulateDeltaThresholdByLod);
	
}
void URoleMovementComponent::SetMovementLOD(int LOD, float SimulateTimeThreshold)
{
	SimulateDeltaThresholdByLod = SimulateTimeThreshold;

	CurrentSimulateDeltaThreshold = FMath::Max(SimulateDeltaThresholdWhenInvisible, SimulateDeltaThresholdByLod);
}

void URoleMovementComponent::SetIsNeedSyncUpMovement(bool isNeed) 
{
	if (IsNeedSyncUpMovement && !isNeed)
	{
		// 移动同步停掉，发送一个Idle包
		DoSyncUpIdleMovementData();
	}
	IsNeedSyncUpMovement = isNeed;
}

void URoleMovementComponent::SetLocoGroupAndDefaultLocoState(int InLocoGroup, int defaultLocoState)
{
	uint8 CurLocomotionState = GetLocalLocomotionState();
	bool oldIsDefaultLocoState = (CurLocomotionState == DefaultLocoState) || (CurLocomotionState == 0);
	
	DefaultLocoState = defaultLocoState;
	LocoGroup = InLocoGroup;
	bool newIsDefaultLocoState = (CurLocomotionState == DefaultLocoState) || (CurLocomotionState == 0);
	bInDefaultLocoState = newIsDefaultLocoState;

	if (oldIsDefaultLocoState != newIsDefaultLocoState && NeedNotifyLocoStateEnterOrLeaveDefault) {
		if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(CharacterOwner))
		{
			OwnerCppEntityInterface->NotifyLocoStateChangedEnterOrLeaveDefault(newIsDefaultLocoState, CurLocomotionState, CurLocomotionState, true);
		}
	}
}

void URoleMovementComponent::SetIsLocoStart(bool NewIsLocoStart)
{
	bool oldIsLocoStart = GetIsLocoStartFromMask();
	SetIsLocoStartInMask(NewIsLocoStart);
	bool newIsLocoStart = GetIsLocoStartFromMask();
	if (oldIsLocoStart != newIsLocoStart)
	{
		if (NeedNotifyLocoStartChanged == true)
		{
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
			{
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyLocoStartChanged", newIsLocoStart);
			}	
		}

		if (bEnableCollisionWithMainPlayer)
		{
			UpdateCollisionWithLocoStart(NewIsLocoStart);
		}
	}
}

bool URoleMovementComponent::SetLocomotionState(uint8 NewLocomotionState)
{
	// 在BaseAnimInstance中做了保护，只有主控角色会调用(现在P3玩家也会调用)
	uint8 LastLocomotionState = GetLocomotionStateFromMask();

	if (LastLocomotionState != NewLocomotionState)
	{
		SetLocomotionStateInMask(NewLocomotionState);

		if (LocoStateDataSource == ELocoStateDataSource::ELSDS_LocomotionStateMaskData)
		{
			DoLocoStateChangeNotify(LastLocomotionState, NewLocomotionState);
		}

		DynamicWaterWaveLocomotionSwitch = GetIsDynamicWaterWaveLocoState(NewLocomotionState);

		ClearNeedResetLocoStateProgressForSync();

		return true;
	}

	return false;
}

bool URoleMovementComponent::SetLocalLocomotionState(uint8 NewLocalLocoState)
{
	uint8 LastLocalLocoState = GetLocalLocomotionState();

	if (LastLocalLocoState != NewLocalLocoState)
	{
		LocalLocoStateData = NewLocalLocoState;

		if (LocoStateDataSource == ELocoStateDataSource::ELSDS_LocalLocoStateData)
		{
			DoLocoStateChangeNotify(LastLocalLocoState, NewLocalLocoState);
		}

		return true;
	}

	return false;
}

void URoleMovementComponent::DoLocoStateChangeNotify(uint8 LastLocoState, uint8 NewLocoState)
{

	bool oldIsDefaultLocoState = (LastLocoState == DefaultLocoState) || (LastLocoState == 0);
	bool newIsDefaultLocoState = (NewLocoState == DefaultLocoState) || (NewLocoState == 0);
	bInDefaultLocoState = newIsDefaultLocoState;

	if (LastLocoState != NewLocoState)
	{
		DoLocoStateChangedOperationCommonly(LastLocoState, NewLocoState);
	}
	
	if (NeedNotifyLocoStateChanged)
	{
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyLocoStateChanged", LastLocoState, NewLocoState);
		}

		if (LastLocoState != NewLocoState)
		{
			DoLocoStateChangedOperationWhenNeedNotify(LastLocoState, NewLocoState);
		}
	}
	
	if (oldIsDefaultLocoState != newIsDefaultLocoState && NeedNotifyLocoStateEnterOrLeaveDefault) {
		if (ICppEntityInterface* OwnerCppEntityInterface = UKGUEActorManager::GetLuaEntityByActor(CharacterOwner))
        {
			OwnerCppEntityInterface->NotifyLocoStateChangedEnterOrLeaveDefault(newIsDefaultLocoState, LastLocoState, NewLocoState, false);
        }
	}

	if (oldIsDefaultLocoState && !newIsDefaultLocoState)
	{
		OnLeaveDefaultLocoState.Broadcast();	
	}
}

void URoleMovementComponent::SetLocoStateInnerIndex(uint8 NewLocoStateInnerIndex)
{
	uint8 LastLocoStateInnerIndex = GetLocoStateInnerIndexFromMask();

	if (LastLocoStateInnerIndex != NewLocoStateInnerIndex)
	{
		SetLocoStateInnerIndexInMask(NewLocoStateInnerIndex);
	}
}

uint8 URoleMovementComponent::SetMovementModeByLocoState(uint8 NewLocomotionState)
{
	EMovementMode NewMovementMode = EMovementMode::MOVE_Walking;
	if (StaticDataInfo.LocoStateToMovementModeMap.Contains(int32(NewLocomotionState)))
	{
		NewMovementMode = EMovementMode(*StaticDataInfo.LocoStateToMovementModeMap.Find(int32(NewLocomotionState)));
	}
	else
	{
		// P3角色下线时，LocomotionState为0，此时返回LocoState为DefaultLocoState，并将NewMovementMode设置为DefaultLocoState的MovementMode，或Walking
		NewLocomotionState = DefaultLocoState;
		if (StaticDataInfo.LocoStateToMovementModeMap.Contains(int32(NewLocomotionState)))
		{
			NewMovementMode = EMovementMode(*StaticDataInfo.LocoStateToMovementModeMap.Find(int32(NewLocomotionState)));
		}
	}

	if (GetMovementMode() != NewMovementMode)
	{
		ApplyNetworkMovementMode(NewMovementMode);
	}

	return NewLocomotionState;
}

void URoleMovementComponent::SimpleUpdateMovementModeFromNet(bool bJumping)
{
	EMovementMode NewMovementMode = bJumping ? MOVE_Falling : MOVE_Walking;
	if (GetMovementMode() != NewMovementMode)
	{
		ApplyNetworkMovementMode(NewMovementMode);
	}
}

void URoleMovementComponent::RotateToDirectionInstantly(float Yaw) 	
{
	MovementSynchronizer.RotateToDirectionInstantly(Yaw);
}

void URoleMovementComponent::ProduceNetShadowMovement(const FVector& Position, const FRotator& Rotation)
{
	RoleMP.GetMovementContext().ProduceNetShadowMovement(Position, Rotation);
}

void URoleMovementComponent::OnSimulateMoveEvent(EMoveSimulateType SimulateType, bool bMove)
{
	// UE_LOG(LogRoleMovement, Log, TEXT("xxc@OnSimulateMoveEvent bMove[%d]"), bMove);
}

void URoleMovementComponent::FixServerPositionToFloor(FVector& Position)
{
	return MovementSimulator.FixServerPositionToFloor(Position);
}
#pragma endregion Synchronization



#pragma region Snapshot
bool URoleMovementComponent::CaptureNetSynchronizeSnapshot(FMovementSnapshot& OutSnapshot, EMoveSyncMode SyncMode)
{
	UWorld* World = GetWorld();
	ACharacter* Character = GetCharacterOwner();
	// 目前编辑预览模式下不需要发送数据给服务���（之后启动了虚拟服务器再说）
	if (!IsActive() || !World || World->IsPreviewWorld() || !Character)
	{
		return false;
	}

	OutSnapshot.Reset();

	// 计算同步时间间隔以及统计时使用"真实物理时间"，因为客户端可能卡帧，其他计算使用"游戏逻辑时间"
	OutSnapshot.RealNow = World->GetRealTimeSeconds(); // 真实物理时间
	uint8 ownLocomotionState = GetLocomotionStateDataMask();
	OutSnapshot.LocomotionState = ownLocomotionState;
	OutSnapshot.IsLocoStart = GetIsLocoStartFromMask();
	OutSnapshot.bResetLocoProgress = bNeedResetLocoStateProgressForSync;

	// LocoAnimState部分上传的是坐骑的, 应用的时候要应用到坐骑上
	if ((IsDriveMountDriveAttachStage() || IsDriveMountDrivePerformanceStage()) && MountRelationCooperator.IsValid()) {
		OutSnapshot.LocomotionState = MountRelationCooperator->GetLocomotionStateDataMask();
		OutSnapshot.Position = MountRelationCooperator->GetActorLocation();
		OutSnapshot.Rotation = MountRelationCooperator->GetActorTransform().Rotator();
	}
	else
	{
		OutSnapshot.Position = Character->GetActorLocation();
		OutSnapshot.Rotation = Character->GetActorRotation();
		if (eMoveDriveRelation == EMoveDriveRelation::DriveVehicleAsCarrier && MountRelationCooperator.IsValid())
		{
			OutSnapshot.ControlEntityId = MountRelationCooperator.Get()->GetEntityId();
		}
	}

	OutSnapshot.IsJumping = MovementMode == MOVE_Falling && GetIsJumpLocoState(GetLocomotionStateFromMask());
	OutSnapshot.IsRiding = IsInRideState();
	if (OutSnapshot.IsRiding)
	{
		GetRoleMP().GetMovementContext().GetMountPostureParam(OutSnapshot.MountPitch, OutSnapshot.MountRoll, OutSnapshot.MountRootOffset);	
	}

	if (EMoveSyncMode::Relative == SyncMode)
	{
		AActor* RelativeTarget = ClientMoveDataRelativeTarget.Get();
		if (IsValid(RelativeTarget))
		{
			OutSnapshot.IsMovingOnPlatform = true;
			OutSnapshot.PlatformTransform = RelativeTarget->GetTransform();
			FTransform InverseTransform = OutSnapshot.PlatformTransform.Inverse();
			OutSnapshot.RelativePosition = InverseTransform.TransformPosition(OutSnapshot.Position);
			OutSnapshot.RelativeRotation = InverseTransform.TransformRotation(OutSnapshot.Rotation.Quaternion()).Rotator();
			OutSnapshot.PlatformVelocity = RelativeTarget->GetVelocity();
		}
	}

	OutSnapshot.GravityScale = GravityScale;

	return true;

}

#pragma endregion Snapshot



#pragma region Impetus
void URoleMovementComponent::SetEnableImpetus(bool Enable)
{
	if (Enable)
	{
		EnableImpetus = EnableImpetus + 1;
	}
	else
	{
		EnableImpetus = FMath::Max(0, EnableImpetus - 1);
	}
}

void URoleMovementComponent::ChangeImpetusActorMap(int64 InActorID, bool bAdd)
{
	UKGObjectActorManager* UOAM = UKGObjectActorManager::GetInstance(this);
	if (!UOAM)
	{
		return;
	}

	ChangeImpetusActorMap_P(Cast<AActor>(UOAM->GetObjectByID(InActorID)), bAdd);
}

void URoleMovementComponent::ChangeImpetusActorMap_P(AActor* InActor, bool bAdd)
{
	if (!InActor)
	{
		return;
	}

	if (bAdd)
	{
		if (int32* Result = OverlapImpetusActorMap.Find(InActor))
		{
			(*Result) = (*Result) + 1;
		}
		else
		{
			OverlapImpetusActorMap.Add(InActor, 1);
		}
	}
	else
	{
		if (int32* Result = OverlapImpetusActorMap.Find(InActor))
		{
			(*Result) = (*Result) - 1;

			if ((*Result) <= 0)
			{
				OverlapImpetusActorMap.Remove(InActor);
			}
		}
	}
}

FVector URoleMovementComponent::OnlyCalculateImpetusDelta(FVector& ResultDelta, float InDeltaTime)
{
	TArray<AActor*> OverlapActors;
	for (TMap<TWeakObjectPtr<AActor>, int32>::TIterator It(OverlapImpetusActorMap); It; ++It)
	{
		if (!It->Key.IsValid())
		{
			It.RemoveCurrent();
		}
		else
		{
			OverlapActors.Add(It->Key.Get());
		}
	}

	FVector CurrentImpetus = FVector::ZeroVector;
	if (UCapsuleComponent* SelfCapsule = Cast<UCapsuleComponent>(UpdatedComponent))
	{
		FVector SelfLoc = SelfCapsule->GetComponentLocation();
		float SelfRadius = SelfCapsule->GetScaledCapsuleRadius();
		float SelfHalfHeight = SelfCapsule->GetScaledCapsuleHalfHeight();
		FVector SelfForwardVector = SelfCapsule->GetForwardVector();

		// 没有移动
		if (ResultDelta.IsNearlyZero())
		{
			FVector TempVector = FVector::ZeroVector;
			for (int32 i = 0; i < OverlapActors.Num(); ++i)
			{
				if (UCapsuleComponent* CurCapsule = Cast<UCapsuleComponent>(OverlapActors[i]->GetRootComponent()))
				{
					if (URMFunctionLibrary::GetCapsuleToCapsuleStaticImpetus(SelfLoc, SelfHalfHeight, SelfRadius + ExtraDistanceForImpetusActor, SelfForwardVector,
						CurCapsule->GetComponentLocation(), CurCapsule->GetScaledCapsuleHalfHeight(), CurCapsule->GetScaledCapsuleRadius(), TempVector))
					{
						CurrentImpetus += TempVector;
					}
				}
			}
		}
		// 移动中
		else
		{
			FVector TempVector = FVector::ZeroVector;
			if (IsRunningRootMotion())
			{
				float ResultDeltaScale = 1.0f;
				for (int32 i = 0; i < OverlapActors.Num(); ++i)
				{
					if (UCapsuleComponent* CurCapsule = Cast<UCapsuleComponent>(OverlapActors[i]->GetRootComponent()))
					{
						float tResultDeltaScale = URMFunctionLibrary::GetCapsuleToCapsuleDynamicImpetus(SelfLoc, ResultDelta, SelfHalfHeight, SelfRadius + ExtraDistanceForImpetusActor,
							CurCapsule->GetComponentLocation(), CurCapsule->GetScaledCapsuleHalfHeight(), CurCapsule->GetScaledCapsuleRadius(), TempVector);

						ResultDeltaScale = FMath::Min(tResultDeltaScale, ResultDeltaScale);

						if ((SelfLoc - CurCapsule->GetComponentLocation()).Size2D() < SelfRadius + CurCapsule->GetScaledCapsuleRadius())
						{
							// 对于陷入目标胶囊体的情况，ResultDeltaScale已经为0了，还需要挤出去
							CurrentImpetus += TempVector;
						}
					}
				}
				ResultDelta = ResultDelta * ResultDeltaScale;
			}
			else
			{
				bool HasValidImptus = false;
				bool HasDuplicatedImptus = false;
				float ResultDeltaScale = 1.0f;
				for (int32 i = 0; i < OverlapActors.Num(); ++i)
				{
					if (UCapsuleComponent* CurCapsule = Cast<UCapsuleComponent>(OverlapActors[i]->GetRootComponent()))
					{
						float tResultDeltaScale = URMFunctionLibrary::GetCapsuleToCapsuleDynamicImpetus(SelfLoc, ResultDelta, SelfHalfHeight, SelfRadius + ExtraDistanceForImpetusActor,
							CurCapsule->GetComponentLocation(), CurCapsule->GetScaledCapsuleHalfHeight(), CurCapsule->GetScaledCapsuleRadius(), TempVector);

						if (tResultDeltaScale < ResultDeltaScale)
						{
							// 存在更近距离的阻挡
							ResultDeltaScale = tResultDeltaScale;
							if (!HasDuplicatedImptus) {
								if (HasValidImptus) {
									HasDuplicatedImptus = true;
									CurrentImpetus = FVector::ZeroVector;
								}
								else {
									CurrentImpetus = TempVector;
									HasValidImptus = true;
								}
							}
							else
							{
								if ((SelfLoc - CurCapsule->GetComponentLocation()).Size2D() < SelfRadius + CurCapsule->GetScaledCapsuleRadius())
								{
									// 对于陷入目标胶囊体的情况，ResultDeltaScale已经为0了，还需要挤出去
									CurrentImpetus += TempVector;
								}
							}
							
						}
					}
				}
				if (HasDuplicatedImptus) {
					ResultDelta = ResultDelta * ResultDeltaScale;
				}
			}
		}
	}

	if (!CurrentImpetus.IsNearlyZero())
	{
		// 限制推挤距离
		float ImpetusLength = CurrentImpetus.Size2D();
		FVector ImpetusNor = CurrentImpetus / ImpetusLength;
		CurrentImpetus = ImpetusNor * FMath::Clamp(ImpetusLength, 0.0, MaxImpetus * InDeltaTime);

		ResultDelta = ResultDelta + CurrentImpetus;
	}

	return CurrentImpetus;
}

float URoleMovementComponent::CalculatetComponentXYRadius(USceneComponent* InComponent)
{
	if (!IsValid(InComponent))
	{
		return 0.0f;
	}

	if (USphereComponent* Sphere = Cast<USphereComponent>(InComponent))
	{
		return Sphere->GetScaledSphereRadius();
	}
	else if (UCapsuleComponent* Capsule = Cast<UCapsuleComponent>(InComponent))
	{
		return Capsule->GetScaledCapsuleRadius();
	}
	else if (UBoxComponent* Box = Cast<UBoxComponent>(InComponent))
	{
		float UpDot = FMath::Abs(FVector::UpVector.Dot(Box->GetUpVector()));
		float RightDot = FMath::Abs(FVector::UpVector.Dot(Box->GetRightVector()));
		float ForwardDot = FMath::Abs(FVector::UpVector.Dot(Box->GetForwardVector()));

		float Length = 0.0f;
		if (UpDot > RightDot && UpDot > ForwardDot)
		{
			Length = FMath::Max(Box->GetScaledBoxExtent().X, Box->GetScaledBoxExtent().Y);
		}
		else if (RightDot > UpDot && RightDot > ForwardDot)
		{
			Length = FMath::Max(Box->GetScaledBoxExtent().X, Box->GetScaledBoxExtent().Z);
		}
		else
		{
			Length = FMath::Max(Box->GetScaledBoxExtent().Y, Box->GetScaledBoxExtent().Z);
		}

		return Length;
	}

	return InComponent->GetLocalBounds().SphereRadius;
}

void URoleMovementComponent::ProduceReplacedFinalWorldPosDelta(const FVector& PositionDelta, bool ReplaceX, bool ReplaceY, bool ReplaceZ)
{
	RoleMP.GetMovementContext().ProduceReplacedFinalWorldDeltaOuterFromPipeline(PositionDelta, ReplaceX, ReplaceY, ReplaceZ);
}

void URoleMovementComponent::ProduceReplacedFinalWorldRotation(const FQuat& WorldRot, bool ReplacePitch, bool ReplaceYaw, bool ReplaceRoll)
{
	RoleMP.GetMovementContext().ProduceReplacedFinalWorldRotationOuterFromPipeline(WorldRot, ReplacePitch, ReplaceYaw, ReplaceRoll);
}

#pragma endregion Impetus



#pragma region BattleZone

void URoleMovementComponent::AddSingleMoveConstraintSphere(const FVector& InCenter, const float InRadius, EMoveConstraintType InConstraintType, bool InbDoHitCallBack, int64 InToken)
{
	TArray<FMoveConstraintAreaInfo> NewMCAIs;

	NewMCAIs.Add(MakeSphereMoveConstraintAreaInfo(
		InCenter,
		FRotator(),
		InRadius
	));
	AddMoveConstraintInfos(NewMCAIs, InConstraintType, InbDoHitCallBack, InToken);
}

void URoleMovementComponent::AddSingleMoveConstraintBox(const FVector& InCenter, const FRotator& InRotator, const FVector& InBoxExtent, EMoveConstraintType InConstraintType, bool InbDoHitCallBack, int64 InToken)
{
	TArray<FMoveConstraintAreaInfo> NewMCAIs;

	NewMCAIs.Add(MakeBoxMoveConstraintAreaInfo(
		InCenter,
		InRotator,
		InBoxExtent
	));
	AddMoveConstraintInfos(NewMCAIs, InConstraintType, InbDoHitCallBack, InToken);
}

FMoveConstraintAreaInfo URoleMovementComponent::MakeSphereMoveConstraintAreaInfo(const FVector& InCenter, const FRotator& InRotator, const float InRadius)
{
	FMoveConstraintAreaInfo OutInfo = FMoveConstraintAreaInfo();
	OutInfo.ShapeType = EMoveConstraintAreaType::EMCAT_Sphere;
	OutInfo.ScaledSphereRadius = InRadius;
	OutInfo.ConstrainOriginLoc = InCenter;
	OutInfo.ConstrainOriginRot = InRotator;
	return OutInfo;
}

FMoveConstraintAreaInfo URoleMovementComponent::MakeBoxMoveConstraintAreaInfo(const FVector& InCenter, const FRotator& InRotator, const FVector& InBoxExtent)
{
	FMoveConstraintAreaInfo OutInfo = FMoveConstraintAreaInfo();
	OutInfo.ShapeType = EMoveConstraintAreaType::EMCAT_Box;
	OutInfo.ScaledBoxExtent = InBoxExtent;
	OutInfo.ConstrainOriginLoc = InCenter;
	OutInfo.ConstrainOriginRot = InRotator;
	return OutInfo;
}

void URoleMovementComponent::AddMoveConstraintInfos(const TArray<FMoveConstraintAreaInfo>& MoveConstrainAreas, EMoveConstraintType InConstraintType, bool InbDoHitCallBack, int64 InToken)
{
	for (FMoveConstraintInfo SingleMCI : MoveConstraintInfos)
	{
		if (SingleMCI.Token == InToken)
		{
			UE_LOG(LogTemp, Warning, TEXT("URoleMovementComponent::AddMoveConstraintInfos Error! Duplicated InToken!"));
			return;
		}
	}

	FMoveConstraintInfo NewMCI = FMoveConstraintInfo();
	NewMCI.ConstraintAreaInfos.Append(MoveConstrainAreas);
	NewMCI.MoveConstraintType = InConstraintType;
	NewMCI.bDoCallBack = InbDoHitCallBack;
	NewMCI.Token = InToken;

	MoveConstraintInfos.Add(NewMCI);
}

void URoleMovementComponent::RemoveMoveConstraintInfos(int64 InToken)
{
	for (int32 i = MoveConstraintInfos.Num() - 1; i >= 0; i--)
	{
		if (MoveConstraintInfos[i].Token == InToken)
		{
			MoveConstraintInfos.RemoveAt(i);
			return;
		}
	}
}

void URoleMovementComponent::DealMoveDeltaByMoveConstraint(FVector& InAndOutMoveDelta)
{
	FVector StartLocation = UpdatedComponent->GetComponentLocation();
	float Radius = CalculatetComponentXYRadius(UpdatedComponent);
	FVector EndLocation = StartLocation + InAndOutMoveDelta;

	FVector TempVec = FVector::ZeroVector;
	FVector OptionalHitNormal = FVector::ZeroVector;
	for (FMoveConstraintInfo& SingleMoveConstraintInfo : MoveConstraintInfos)
	{
		if (DealMoveDeltaForMoveConstraint(SingleMoveConstraintInfo, StartLocation, EndLocation, Radius, TempVec, OptionalHitNormal))
		{
			EndLocation = TempVec;

			if (SingleMoveConstraintInfo.bDoCallBack)
			{
				if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
				{
					ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyHitMoveConstraintBounds", SingleMoveConstraintInfo.Token, OptionalHitNormal);
				}
			}

			InAndOutMoveDelta = EndLocation - StartLocation;
			if (InAndOutMoveDelta.IsNearlyZero())
			{
				// 位移已经变为0，就不再检查了
				return;
			}
		}
	}
}

bool URoleMovementComponent::FindLocationXYInMoveConstraint(const FVector& ExpectedLoc, FVector& FinalValidLoc)
{
	FVector CheckLocation = ExpectedLoc;
	float Radius = CalculatetComponentXYRadius(UpdatedComponent);
	FVector TempVec = FVector::ZeroVector;
	FVector TempNormalVec = FVector::ZeroVector;
	bool bHasConstraint = false;
	for (FMoveConstraintInfo& SingleMoveConstraintInfo : MoveConstraintInfos)
	{
		// 位置检查，只检查ForceIn和ForceOut
		if (SingleMoveConstraintInfo.MoveConstraintType == EMoveConstraintType::EMCT_ForceAreaIn)
		{
			bool bInArea = FindValidTargetLocForMultyMoveConstrainArea(SingleMoveConstraintInfo.ConstraintAreaInfos, SingleMoveConstraintInfo.MoveConstraintType, CheckLocation, Radius, TempVec, TempNormalVec);
			if (!bInArea)
			{
				bHasConstraint = true;
				CheckLocation = TempVec;
			}
		}
		else if (SingleMoveConstraintInfo.MoveConstraintType == EMoveConstraintType::EMCT_ForceAreaOut)
		{
			bool bInArea = FindValidTargetLocForMultyMoveConstrainArea(SingleMoveConstraintInfo.ConstraintAreaInfos, SingleMoveConstraintInfo.MoveConstraintType, CheckLocation, Radius, TempVec, TempNormalVec);
			if (bInArea)
			{
				bHasConstraint = true;
				CheckLocation = TempVec;
			}
		}
	}

	FinalValidLoc = CheckLocation;
	return bHasConstraint;
}

bool URoleMovementComponent::DealMoveDeltaForMoveConstraint(FMoveConstraintInfo MoveConstrainInfo, const FVector& InStartLoc, const FVector& InEndLoc, const float InRadius, FVector& OutFinalValidLoc, FVector& OutOptionalHitNormal)
{
	FVector ValidLocForStart = FVector::ZeroVector;
	FVector ValidLocForEnd = FVector::ZeroVector;
	FVector EdgeNormalForStart = FVector::ZeroVector;
	FVector EdgeNormalForEnd = FVector::ZeroVector;
	bool bStartLocInArea = FindValidTargetLocForMultyMoveConstrainArea(MoveConstrainInfo.ConstraintAreaInfos, MoveConstrainInfo.MoveConstraintType, InStartLoc, InRadius, ValidLocForStart, EdgeNormalForStart);
	bool bEndLocInArea = FindValidTargetLocForMultyMoveConstrainArea(MoveConstrainInfo.ConstraintAreaInfos, MoveConstrainInfo.MoveConstraintType, InEndLoc, InRadius, ValidLocForEnd, EdgeNormalForEnd);

	if (MoveConstrainInfo.MoveConstraintType == EMoveConstraintType::EMCT_OnlyAllowOut)
	{
		if (!bStartLocInArea && bEndLocInArea)
		{
			OutFinalValidLoc = ValidLocForEnd;
			OutOptionalHitNormal = EdgeNormalForEnd;
			return true;
		}
	}
	else if (MoveConstrainInfo.MoveConstraintType == EMoveConstraintType::EMCT_OnlyAllowIn)
	{
		if (bStartLocInArea && !bEndLocInArea)
		{
			OutFinalValidLoc = ValidLocForEnd;
			OutOptionalHitNormal = EdgeNormalForEnd;
			return true;
		}
	}
	else if (MoveConstrainInfo.MoveConstraintType == EMoveConstraintType::EMCT_ForceAreaOut)
	{
		if (bEndLocInArea)
		{
			OutFinalValidLoc = ValidLocForEnd;
			OutOptionalHitNormal = EdgeNormalForEnd;
			return true;
		}
	}
	else if (MoveConstrainInfo.MoveConstraintType == EMoveConstraintType::EMCT_ForceAreaIn)
	{
		if (!bEndLocInArea)
		{
			OutFinalValidLoc = ValidLocForEnd;
			OutOptionalHitNormal = EdgeNormalForEnd;
			return true;
		}
	}
	else if (MoveConstrainInfo.MoveConstraintType == EMoveConstraintType::EMCT_ForbidInAndOut)
	{
		if (bStartLocInArea != bEndLocInArea)
		{
			OutFinalValidLoc = ValidLocForEnd;
			OutOptionalHitNormal = EdgeNormalForEnd;
			return true;
		}
	}

	OutFinalValidLoc = InEndLoc;
	return false;
}

bool URoleMovementComponent::FindValidTargetLocForMultyMoveConstrainArea(TArray<FMoveConstraintAreaInfo> MoveConstrainAreas, EMoveConstraintType InConstraintType, const FVector& InExpectedLoc, const float InRadius, FVector& OutEdgeLoc, FVector& OutEdgeNormal)
{
	TArray<TPair<FVector, FVector>> OutEdgeLocAndNormalList = TArray<TPair<FVector, FVector>>();
	TArray<TPair<int32, float>> OutEdgeDistanceList = TArray<TPair<int32, float>>();
	bool OutExpectedLocInArea = false;
	for (int32 i = 0; i < MoveConstrainAreas.Num(); i++)
	{
		bool bExpectedLocInArea = FindValidTargetLocForSingleMoveConstrainArea(MoveConstrainAreas[i], InConstraintType, InExpectedLoc, InRadius, OutEdgeLoc, OutEdgeNormal);
		OutEdgeLocAndNormalList.Add(TPair<FVector, FVector>(OutEdgeLoc, OutEdgeNormal));
		OutEdgeDistanceList.Add(TPair<int32, float>(i, (InExpectedLoc - OutEdgeLoc).Size()));
		// InExpectedLoc在任一一个区域内，都视作在区域内
		if (bExpectedLocInArea)
		{
			OutExpectedLocInArea = true;
		}
	}

	// 取最近的边界点作为最终边界点输出
	OutEdgeDistanceList.Sort([](const TPair<FVector, float>& A, const TPair<FVector, float>& B)
		{
			return A.Value <= B.Value;
		});
	
	const auto& AreaIndex = OutEdgeDistanceList[0].Key;
	OutEdgeLoc = OutEdgeLocAndNormalList[AreaIndex].Key;
	OutEdgeNormal = OutEdgeLocAndNormalList[AreaIndex].Value;
	return OutExpectedLocInArea;
}

bool URoleMovementComponent::FindValidTargetLocForSingleMoveConstrainArea(FMoveConstraintAreaInfo MoveConstrainArea, EMoveConstraintType InConstraintType, const FVector& InExpectedLoc, const float InRadius, FVector& OutEdgeLoc, FVector& OutEdgeNormal)
{
	bool bExpectedLocInArea = false;
	if (MoveConstrainArea.ShapeType == EMoveConstraintAreaType::EMCAT_Sphere)
	{
		FVector Center = MoveConstrainArea.ConstrainOriginLoc;
		float ScaledSphereRadius = MoveConstrainArea.ScaledSphereRadius;

		FVector CenterToExpectedLoc2D = InExpectedLoc - Center;
		CenterToExpectedLoc2D.Z = 0.0f;
		if (CenterToExpectedLoc2D.IsNearlyZero())
		{
			CenterToExpectedLoc2D = FVector(1.0f, 0.0f, 0.0f);
		}
		float CenterToExpectedLoc2DSize = CenterToExpectedLoc2D.Size2D();

		// 这块临界值情况操作需要特别小心！
		if (InConstraintType == EMoveConstraintType::EMCT_OnlyAllowOut || InConstraintType == EMoveConstraintType::EMCT_ForceAreaOut)
		{
			ScaledSphereRadius = ScaledSphereRadius + InRadius;
			bExpectedLocInArea = CenterToExpectedLoc2DSize <= ScaledSphereRadius;
			OutEdgeLoc = Center + (ScaledSphereRadius + 1.0f) * CenterToExpectedLoc2D.GetSafeNormal();
			OutEdgeNormal = (OutEdgeLoc - Center).GetSafeNormal();
		}
		else if (InConstraintType == EMoveConstraintType::EMCT_OnlyAllowIn || InConstraintType == EMoveConstraintType::EMCT_ForceAreaIn)
		{
			ScaledSphereRadius = FMath::Max(0.0f, ScaledSphereRadius - InRadius);
			bExpectedLocInArea = CenterToExpectedLoc2DSize <= ScaledSphereRadius;
			OutEdgeLoc = Center + FMath::Max(0.0f, ScaledSphereRadius - 1.0f) * CenterToExpectedLoc2D.GetSafeNormal();
			OutEdgeNormal = (Center - OutEdgeLoc).GetSafeNormal();
		}
		else if (InConstraintType == EMoveConstraintType::EMCT_ForbidInAndOut)
		{
			bExpectedLocInArea = CenterToExpectedLoc2DSize <= ScaledSphereRadius;
			ScaledSphereRadius = bExpectedLocInArea ? FMath::Max(0.0f, ScaledSphereRadius - InRadius) : ScaledSphereRadius + InRadius;
			OutEdgeLoc = Center + (ScaledSphereRadius + (bExpectedLocInArea ? -1.0f : 1.0f)) * CenterToExpectedLoc2D.GetSafeNormal();
			bExpectedLocInArea = CenterToExpectedLoc2DSize < ScaledSphereRadius;
			OutEdgeNormal = bExpectedLocInArea ? (Center - OutEdgeLoc).GetSafeNormal() : (OutEdgeLoc - Center).GetSafeNormal();
		}

		OutEdgeLoc.Z = InExpectedLoc.Z;
	}
	else if(MoveConstrainArea.ShapeType == EMoveConstraintAreaType::EMCAT_Box)
	{
		// 方形, 判断目的点是否在方形区域内
		FVector Center = MoveConstrainArea.ConstrainOriginLoc;
		FRotator Rotation = MoveConstrainArea.ConstrainOriginRot;
		FVector2D Size = FVector2D(MoveConstrainArea.ScaledBoxExtent);

		FTransform RectangleT = FTransform(Rotation, Center);
		FVector LocalExpectedLoc = RectangleT.InverseTransformPosition(InExpectedLoc);

		// UKismetSystemLibrary::DrawDebugBox(this, Center, MoveConstrainArea.ScaledBoxExtent, FLinearColor::Green, Rotation, 0.1f);

		// 这块临界值情况操作需要特别小心！
		if (InConstraintType == EMoveConstraintType::EMCT_OnlyAllowOut || InConstraintType == EMoveConstraintType::EMCT_ForceAreaOut)
		{
			Size.X += InRadius; Size.Y += InRadius;
			bExpectedLocInArea = (LocalExpectedLoc.X >= -Size.X) && (LocalExpectedLoc.X <= Size.X) && (LocalExpectedLoc.Y >= -Size.Y) && (LocalExpectedLoc.Y <= Size.Y);

			float CloseX = LocalExpectedLoc.X >= 0.0f ? Size.X + 1.0f : -Size.X - 1.0f;
			float CloseY = LocalExpectedLoc.Y >= 0.0f ? Size.Y + 1.0f : -Size.Y - 1.0f;

			if (FMath::Abs(LocalExpectedLoc.X - CloseX) <= FMath::Abs(LocalExpectedLoc.Y - CloseY))
			{
				OutEdgeLoc.X = CloseX;
				OutEdgeLoc.Y = FMath::Clamp(LocalExpectedLoc.Y, -Size.Y - 1.0f, Size.Y + 1.0f);
				OutEdgeNormal = FVector(CloseX >= 0 ? 1 : -1, 0, 0);
			}
			else
			{
				OutEdgeLoc.Y = CloseY;
				OutEdgeLoc.X = FMath::Clamp(LocalExpectedLoc.X, -Size.X - 1.0f, Size.X + 1.0f);
				OutEdgeNormal = FVector(0, CloseY >= 0 ? 1 : -1,0);
			}
			OutEdgeLoc.Z = 0.0f;
			OutEdgeLoc = RectangleT.TransformPosition(OutEdgeLoc);
			OutEdgeNormal = Rotation.RotateVector(OutEdgeNormal);
		}
		else if (InConstraintType == EMoveConstraintType::EMCT_OnlyAllowIn || InConstraintType == EMoveConstraintType::EMCT_ForceAreaIn)
		{
			Size.X = FMath::Max(0.0f, Size.X - InRadius); Size.Y = FMath::Max(0.0f, Size.Y - InRadius);
			bExpectedLocInArea = (LocalExpectedLoc.X >= -Size.X) && (LocalExpectedLoc.X <= Size.X) && (LocalExpectedLoc.Y >= -Size.Y) && (LocalExpectedLoc.Y <= Size.Y);

			float CloseX = LocalExpectedLoc.X >= 0.0f ? FMath::Max(0.0f, Size.X - 1.0f) : -FMath::Max(0.0f, Size.X - 1.0f);
			float CloseY = LocalExpectedLoc.Y >= 0.0f ? FMath::Max(0.0f, Size.Y - 1.0f) : -FMath::Max(0.0f, Size.Y - 1.0f);

			if (FMath::Abs(LocalExpectedLoc.X - CloseX) <= FMath::Abs(LocalExpectedLoc.Y - CloseY))
			{
				OutEdgeLoc.X = CloseX;
				OutEdgeLoc.Y = FMath::Clamp(LocalExpectedLoc.Y, -FMath::Max(0.0f, Size.Y - 1.0f), FMath::Max(0.0f, Size.Y - 1.0f));
				OutEdgeNormal = FVector(CloseX >= 0 ? -1 : 1, 0, 0);
			}
			else
			{
				OutEdgeLoc.Y = CloseY;
				OutEdgeLoc.X = FMath::Clamp(LocalExpectedLoc.X, -FMath::Max(0.0f, Size.X - 1.0f), FMath::Max(0.0f, Size.X - 1.0f));
				OutEdgeNormal = FVector(0, CloseY >= 0 ? -1 : 1,0);
			}
			OutEdgeLoc.Z = 0.0f;
			OutEdgeLoc = RectangleT.TransformPosition(OutEdgeLoc);
			OutEdgeNormal = Rotation.RotateVector(OutEdgeNormal);
		}
		else if (InConstraintType == EMoveConstraintType::EMCT_ForbidInAndOut)
		{
			bExpectedLocInArea = (LocalExpectedLoc.X >= -Size.X) && (LocalExpectedLoc.X <= Size.X) && (LocalExpectedLoc.Y >= -Size.Y) && (LocalExpectedLoc.Y <= Size.Y);
			Size.X = bExpectedLocInArea ? FMath::Max(0.0f, Size.X - InRadius) : Size.X + InRadius;
			Size.Y = bExpectedLocInArea ? FMath::Max(0.0f, Size.Y - InRadius) : Size.Y + InRadius;

			float CloseX = LocalExpectedLoc.X > 0.0f ? (bExpectedLocInArea ? FMath::Max(0.0f, Size.X - 1.0f) : Size.X + 1.0f) : (bExpectedLocInArea ? -FMath::Max(0.0f, Size.X - 1.0f) : -Size.X - 1.0f);
			float CloseY = LocalExpectedLoc.Y > 0.0f ? (bExpectedLocInArea ? FMath::Max(0.0f, Size.Y - 1.0f) : Size.Y + 1.0f) : (bExpectedLocInArea ? -FMath::Max(0.0f, Size.Y - 1.0f) : -Size.Y - 1.0f);

			if (FMath::Abs(LocalExpectedLoc.X - CloseX) <= FMath::Abs(LocalExpectedLoc.Y - CloseY))
			{
				OutEdgeLoc.X = CloseX;
				OutEdgeLoc.Y = bExpectedLocInArea ? FMath::Clamp(LocalExpectedLoc.Y, -FMath::Max(0.0f, Size.Y - 1.0f), FMath::Max(0.0f, Size.Y - 1.0f))
					: FMath::Clamp(LocalExpectedLoc.Y, -Size.Y - 1.0f, Size.Y + 1.0f);
				OutEdgeNormal = FVector(
					bExpectedLocInArea ?
						(CloseX >= 0 ? -1 : 1) :
						(CloseX >= 0 ? 1 : -1),
					0,
					0
					);
			}
			else
			{
				OutEdgeLoc.Y = CloseY;
				OutEdgeLoc.X = bExpectedLocInArea ? FMath::Clamp(LocalExpectedLoc.X, -FMath::Max(0.0f, Size.X - 1.0f), FMath::Max(0.0f, Size.X - 1.0f))
					: FMath::Clamp(LocalExpectedLoc.X, -Size.X - 1.0f, Size.X + 1.0f);
				OutEdgeNormal = FVector(0,
					bExpectedLocInArea ?
						(CloseY >= 0 ? -1 : 1) :
						(CloseY >= 0 ? 1 : -1),
						0
					);
			}
			OutEdgeLoc.Z = 0.0f;
			OutEdgeLoc = RectangleT.TransformPosition(OutEdgeLoc);
			OutEdgeNormal = Rotation.RotateVector(OutEdgeNormal);
		}

		OutEdgeLoc.Z = InExpectedLoc.Z;
	}

	return bExpectedLocInArea;
}
#pragma endregion BattleZone



#pragma region DisRecording
void URoleMovementComponent::StartDisRecording()
{
	DeltaXYZ = 0.0f;
	DeltaXY = 0.0f;
	DeltaZ = 0.0f;
	IsDisRecording = true;
}

void URoleMovementComponent::StopDisRecording()
{
	IsDisRecording = false;
	DeltaXYZ = 0.0f;
	DeltaXY = 0.0f;
	DeltaZ = 0.0f;
}

float URoleMovementComponent::GetDeltaDis(int32 DeltaLocType, float& LastDeltaDis)
{
	float outRes = 0.0f;
	if (DeltaLocType == 1)
	{
		outRes = DeltaXYZ >= LastDeltaDis ? DeltaXYZ - LastDeltaDis : DeltaXYZ - LastDeltaDis + 3.0E+30;
		LastDeltaDis = DeltaXYZ;
	}
	else if (DeltaLocType == 2)
	{
		outRes = DeltaXY >= LastDeltaDis ? DeltaXY - LastDeltaDis : DeltaXY - LastDeltaDis + 3.0E+30;
		LastDeltaDis = DeltaXY;
	}
	else if (DeltaLocType == 3)
	{
		outRes = DeltaZ >= LastDeltaDis ? DeltaZ - LastDeltaDis : DeltaZ - LastDeltaDis + 3.0E+30;
		LastDeltaDis = DeltaZ;
	}

	return outRes;
}

void URoleMovementComponent::UpdateRecordingDis()
{
	FVector DeltaLoc = UpdatedComponent->GetComponentLocation() - LastFrameLoc;
	DeltaZ += FMath::Abs(DeltaLoc.Z);
	DeltaZ = DeltaZ > 3.0E+30 ? DeltaZ - 3.0E+30 : DeltaZ;
	DeltaXY += FMath::Sqrt(DeltaLoc.X * DeltaLoc.X + DeltaLoc.Y * DeltaLoc.Y);
	DeltaXY = DeltaXY > 3.0E+30 ? DeltaXY - 3.0E+30 : DeltaXY;
	DeltaXYZ += FMath::Sqrt(DeltaLoc.X * DeltaLoc.X + DeltaLoc.Y * DeltaLoc.Y + DeltaLoc.Z * DeltaLoc.Z);
	DeltaXYZ = DeltaXYZ > 3.0E+30 ? DeltaXYZ - 3.0E+30 : DeltaXYZ;
}
#pragma endregion DisRecording



#pragma region FrameStickGround
FVector URoleMovementComponent::CalculateFrameStickGroundLoc(const FVector& OldFinalWorldMovementDelta)
{
	FVector RealFinalWorldMovementDelta = OldFinalWorldMovementDelta;
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
	{
		FVector OutRes = FVector();
		FVector CurPos = UpdatedComponent->GetComponentLocation();
		if (bCheckCollisionBetweenMoveDelta2D && OldFinalWorldMovementDelta.Size2D() > 0.0f) {
			// 检查逐帧贴地水平位移间的碰撞
			Character->SimpleCheckCollisionBetweenMoveDelta2D(RealFinalWorldMovementDelta, OldFinalWorldMovementDelta);
			if (RealFinalWorldMovementDelta.IsNearlyZero()) 
			{
				SetIsLocoStartInMask(false);
				return FVector::ZeroVector;
			}
		}

		FVector ExectedPos = CurPos + RealFinalWorldMovementDelta;
		if (Character->CheckActorStickGround(GetTrackFloorCollisionPresetName(), FrameStickGroundDistance, OutRes, &ExectedPos, bUseComplexFrameStickGround))
		{
			// 实际位移稍微低一点，确保移动到底
			OutRes = OutRes - CurPos - FVector(0.0f, 0.0f, UCharacterMovementComponent::MAX_FLOOR_DIST);
			return OutRes;
		}
	}

	if (bKeepOriginMoveDeltaWhenStickGroundFailed) 
	{
		return RealFinalWorldMovementDelta;
	}
	else 
	{
		SetIsLocoStartInMask(false);
		return FVector::ZeroVector;
	}
}
#pragma endregion FrameStickGround



#pragma region ScenePerception

void URoleMovementComponent::RefreshWorkingWaterWaveRequestId() {
	// 按需扩展游泳的波纹切换
	WorkingWaterWaveRequestId = WaterWaveRequestId;
}

void URoleMovementComponent::SetWaterWaveRequestId(int32 requestId) {
	WaterWaveRequestId = requestId;
	RefreshWorkingWaterWaveRequestId();
}

void URoleMovementComponent::SetWaterSurfaceWaveMotorTextureId(int32 motorTextureId) {
	WaterWaveMotorTextureId = motorTextureId;
}

void URoleMovementComponent::SetWaterSurfaceWaveMotorOffset(const FVector2D& Offset)
{
	WaterSurfaceWaveOffset = Offset;
}

void URoleMovementComponent::SetLocalWindSwitchData(bool bOpen, float scaleXForD, float scaleYForD, float strengthForD, float fanCenterAngleForD, float scaleXForO, float scaleYForO, float strengthForO, float fanCenterAngleForO)
{
	LocalWindSwitch = bOpen;
	LocalMoveWindFieldData.Set(scaleXForD, scaleYForD, strengthForD, fanCenterAngleForD);
	LocalJumpWindFieldData.Set(scaleXForO, scaleYForO, strengthForO, fanCenterAngleForO);
}

void URoleMovementComponent::UpdateIsWaterWalkAllowed(bool newIsAllowed)
{
	if (NeedNotifyIsWaterWalkAllowed)
	{
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyIsWaterWalkAllowedChanged", newIsAllowed);
		}
	}
}

bool URoleMovementComponent::CheckIsPredictWaterWalkAllowedAtLocation(const FVector& InDeltaLoc, float& OutDistToWaterSurface)
{
	if (ScenePD.IsValid()) {
		return ScenePD->CheckIsPredictWaterWalkAllowedAtLocation(*this, InDeltaLoc, OutDistToWaterSurface);
	}
	return false;
}

void URoleMovementComponent::SetInWaterAndInSwitmDepthFromScenePD(bool newInWater, bool newInSwimDepth, bool NeedForceLeaveSwim) {
	bool oldInWater = IsInWater;
	bool oldInSwimDepth = IsInSwimDepth;

	bool hasChanged = false;
	if (newInWater != IsInWater) {

		SetIsInWaterFromScenePD(newInWater);
		GetRealMovementViewProxy()->SetIsInWaterFromScenePD(newInWater);

		hasChanged = true;
	}

	if (newInSwimDepth != IsInSwimDepth) {
		IsInSwimDepth = newInSwimDepth;
		GetRealMovementViewProxy()->IsInSwimDepth = newInSwimDepth;

		hasChanged = true;
	}

	if (hasChanged) {
		RefreshWorkingWaterWaveRequestId();
		if (NeedInWaterChangedNotify)
		{
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
			{
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyInWaterChanged", oldInWater, IsInWater, oldInSwimDepth, newInSwimDepth);
				return;
			}
		}
	}
	if (newInSwimDepth) 
	{
		if (GetIsMainPlayer() && GetIsInNormalWalking())
		{
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
			{
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_ForceEnterSwim");
			}
		}
	}
	else if (GetIsForceCheckSwimDepthLocoState(GetLocalLocomotionState()))
	{
		if (NeedForceLeaveSwim)
		{
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
			{
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_NotifyForceLeaveSwim");
			}
		}
	}
}


void URoleMovementComponent::TryApplyDynamicWaterWaveFromLocomotion(float deltaTime) {
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("TryApplyDynamicWaterWaveFromLocomotion");
	TimeLeftToNextApplyWave -= deltaTime;
	if (TimeLeftToNextApplyWave > 0.0f) {
		return;
	}

	if(!GetIsWaterDetected() || GetCurDistToWaterSurface() > WaterWaveApplyForLocoHeightThreshold)
	{
		return;
	}

	if (!OnAddMotorForDynamicWaterWave.IsBound()) {
		return;
	}

	if (Velocity.Length() < WaterWaveApplyForLocoThreshold) {
		return;
	}

	auto* mesh = CharacterOwner->GetMesh();
	if (!mesh) {
		return;
	}
	TimeLeftToNextApplyWave = ApplyDynamicWaterWaveTimeGap;

	FVector location = mesh->K2_GetComponentLocation();
	FRotator ActorRotation = CharacterOwner->GetActorRotation();
	FVector orientationX = ActorRotation.Vector();
	FVector orientationY = FRotationMatrix(ActorRotation).GetScaledAxis(EAxis::Y);
	location = location + orientationX * WaterSurfaceWaveOffset.X + orientationY * WaterSurfaceWaveOffset.Y;

	float actorYaw = ActorRotation.Yaw;
	OnAddMotorForDynamicWaterWave.ExecuteIfBound(WorkingWaterWaveRequestId,
		WaterWaveMotorTextureId, location.X, location.Y, actorYaw,
		WaterSurfaceWaveData.X, WaterSurfaceWaveData.Y, WaterSurfaceWaveData.Z, WaterSurfaceWaveData.W, 0, 0, 0, 0, 0);
}

void URoleMovementComponent::TryApplyLocalWindFieldFromLocomotion(float deltaTime) {
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("TryApplyDynamicWaterWaveFromLocomotion");
	TimeLeftToNextApplyWind -= deltaTime;
	TimeLeftToNextApplyJumpWind -= deltaTime;
	if (TimeLeftToNextApplyWind > 0.0f) {
		return;
	}

	if(GetCurGroundDist() > LocalWindApplyForLocoHeightThreshold){
		return;
	}
	
	if (!OnAddMotorForLocalWindField.IsBound()) {
		return;
	}

	if (Velocity.Length() < LocalWindApplyForLocoThreshold) {
		return;
	}

	auto* mesh = CharacterOwner->GetMesh();
	if (!mesh) {
		return;
	}
	TimeLeftToNextApplyWind = ApplyLocalWindFieldTimeGap;

	FVector location = mesh->K2_GetComponentLocation();
	float actorYaw = CharacterOwner->GetActorRotation().Yaw;

	OnAddMotorForLocalWindField.ExecuteIfBound((int32)LocalMoveWindType, location.X, location.Y, actorYaw,
		LocalMoveWindFieldData.X, LocalMoveWindFieldData.Y, LocalMoveWindFieldData.Z, LocalMoveWindFieldData.W, 0, 0);
}

void URoleMovementComponent::TryApplyLocalJumpWind() {
	if (TimeLeftToNextApplyJumpWind > 0.0f) {
		return;
	}
	if (!OnAddMotorForLocalWindField.IsBound()) {
		return;
	}

	auto* mesh = CharacterOwner->GetMesh();
	if (!mesh) {
		return;
	}
	TimeLeftToNextApplyJumpWind = ApplyLocalJumpWindFieldTimeGap;

	FVector location = mesh->K2_GetComponentLocation();
	float actorYaw = CharacterOwner->GetActorRotation().Yaw;

	OnAddMotorForLocalWindField.ExecuteIfBound((int32)LocalJumpWindType, location.X, location.Y, actorYaw,
		LocalJumpWindFieldData.X, LocalJumpWindFieldData.Y, LocalJumpWindFieldData.Z, LocalJumpWindFieldData.W, 0, 0); 

}

void URoleMovementComponent::EnsureScenePerceptionDetector() {
	if (ScenePD.IsValid()) {
		return;
	}

	ScenePD = MakeUnique<ScenePerceptionDetector>();
	return;
}


void URoleMovementComponent::ResetWaterDetect() {
	NeedInWaterChangedNotify = false;
	IsInSwimDepth = false;
	IsInWater = false;
	WorkingWaterWaveRequestId = -1;
	WaterWaveRequestId = -1;
	WaterSurfaceWaveData.Set(1.0, 1.0, 1.0, 1.0);

	if (ScenePD.IsValid()) {
		ScenePD->SwitchGroundDetect(false, ECC_WorldStatic, 0);
		ScenePD->SwitchWaterDetect(false, ECC_WorldStatic, 0);
	}
}

void URoleMovementComponent::SwitchWaterDetect(bool isSwitchOn, ECollisionChannel waterChannel, float detectLength, bool InAllowDetectWaterByCollision) {
	if (!isSwitchOn && !ScenePD.IsValid()) {
		return;
	}

	EnsureScenePerceptionDetector();
	ScenePD->SwitchWaterDetect(isSwitchOn, waterChannel, detectLength, InAllowDetectWaterByCollision);
}

void URoleMovementComponent::SwitchGroundDetect(bool isSwitchOn, ECollisionChannel groundChannel, float detectLength) {
	if (!isSwitchOn && !ScenePD.IsValid()) {
		return;
	}

	EnsureScenePerceptionDetector();
	ScenePD->SwitchGroundDetect(isSwitchOn, groundChannel, detectLength);

}

void URoleMovementComponent::SetDetectStartZOffset(float zOffset) {

	if (!ScenePD.IsValid()) {
		return;
	}

	ScenePD->SetDetectStartZOffset(zOffset);
}

void URoleMovementComponent::SetNeedNotifyIsWaterWalkAllowed(bool isNeed, bool InitIsWaterWalkAllowed)
{
	NeedNotifyIsWaterWalkAllowed = isNeed;

	if (!ScenePD.IsValid()) {
		return;
	}
	ScenePD->InitIsWaterWalkAllowed(InitIsWaterWalkAllowed);
}

void URoleMovementComponent::SetDetectDistanceThresholdTolerateValue(float groundDistTolerateValue, float waterDistTolerateValue) 
{
	if (!ScenePD.IsValid()) {
		return;
	}
	ScenePD->SetDetectDistanceThresholdTolerateValue(groundDistTolerateValue, waterDistTolerateValue);
}

void URoleMovementComponent::SetNeedInWaterChangedNotify(bool isNeed, float inWaterThreshold, float inSwimDepthThreshold, float InWaterWalkDepthThreshold) {


	NeedInWaterChangedNotify = isNeed;

	if (isNeed) {

		if (!ScenePD.IsValid()) {
			return;
		}
		ScenePD->SetDetectDepthThreshold(inWaterThreshold, inSwimDepthThreshold, InWaterWalkDepthThreshold);
	}

}

float URoleMovementComponent::GetInSwimDepthThreshold() const
{
	if (!ScenePD.IsValid())
	{
		return 0.f;
	}

	return ScenePD->GetInSwimDepthThreashold();
}

bool URoleMovementComponent::GetIsInWater() {
	return IsInWater;
}

bool URoleMovementComponent::GetNeedFootStepNotify() {
	return bNeedFootStepNotify;
}

void URoleMovementComponent::SetNeedFootStepNotify(bool bNeedNotify) {
	bNeedFootStepNotify = bNeedNotify;
}

bool URoleMovementComponent::GetIsInSwimDepth() {
	return IsInSwimDepth;
}

bool URoleMovementComponent::GetNeedInWaterChangedNotify() {
	return NeedInWaterChangedNotify;
}


bool URoleMovementComponent::GetIsDetectGround() {
	if (!ScenePD.IsValid()) {
		return false;
	}

	return ScenePD->GetIsDetectGround();
}

bool URoleMovementComponent::GetIsGroundDetected() {

	if (!ScenePD.IsValid()) {
		return false;
	}

	return ScenePD->GetIsGroundDetected();
}

float URoleMovementComponent::GetCurGroundDist() {

	if (!ScenePD.IsValid()) {
		return 0.0f;
	}

	return ScenePD->GetCurGroundDist();

}

bool URoleMovementComponent::GetCurGroundSurfacePosition(FVector& OutGroundPos)
{
	if (!ScenePD.IsValid()) {
		return false;
	}

	OutGroundPos = ScenePD->GetCurGroundSurfacePosition();
	return true;
}

bool URoleMovementComponent::GetIsDetectWater() {
	if (!ScenePD.IsValid()) {
		return false;
	}

	return ScenePD->GetIsDetectWater();
}

bool URoleMovementComponent::GetIsWaterWalkAllowed()
{
	if (!ScenePD.IsValid()) {
		return false;
	}

	return ScenePD->GetIsWaterWalkAllowed();
}

float URoleMovementComponent::GetCurWaterDepth() {

	if (!ScenePD.IsValid()) {
		return 0.0f;
	}
	return ScenePD->GetCurWaterDepth();
}

float URoleMovementComponent::GetGroundDetectLength() {

	if (!ScenePD.IsValid()) {
		return 0.0f;
	}
	return ScenePD->GetGroundDetectLength();
}

float URoleMovementComponent::GetWaterDetectLength() {

	if (!ScenePD.IsValid()) {
		return 0.0f;
	}
	return ScenePD->GetWaterDetectLength();
}

float URoleMovementComponent::GetCurDistToWaterSurface() const {

	if (!ScenePD.IsValid()) {
		return 0.0f;
	}
	return ScenePD->GetCurDistToWaterSurface();
}

bool URoleMovementComponent::GetIsWaterDetected() const {

	if (!ScenePD.IsValid()) {
		return 0.0f;
	}
	return ScenePD->GetIsWaterDetected();
}

void URoleMovementComponent::CheckPreLanding(const float& InDeltaTime)
{
	if (GetIsInWaterWalk() || GetIsInSwim()) {
		return;
	}

	const float& CurGroundDist = GetCurGroundDist();
	const float& VelcityZ = GetMovementVelocity().Z;
	if (CurGroundDist > 0.0f && VelcityZ < 0.0f)
	{
		const float& MaxDeltaPreLandingDist = FMath::Max(-StaticDataInfo.PreLandMaxHeight, VelcityZ * StaticDataInfo.PreLandVelocityZCalculateDuration);
		if ((CurGroundDist + MaxDeltaPreLandingDist) < 0.0f)
		{
			RoleMP.GetMovementContext().IncreaseHasForceGroundSupportCount();
			RoleMP.GetMovementContext().IncreaseHasForceLocoGroundSupportCount();
		}
	}
}

bool URoleMovementComponent::CheckPreInWater(const float& InDeltaTime, const float& InCurWaterDist)
{
	const float& VelcityZ = GetMovementVelocity().Z;
	if (InCurWaterDist > 0.0f && VelcityZ < 0.0f)
	{
		const float& MaxDeltaPreLandingDist = FMath::Max(-StaticDataInfo.PreLandMaxHeight, VelcityZ * StaticDataInfo.PreLandVelocityZCalculateDuration);
		if ((InCurWaterDist + MaxDeltaPreLandingDist) < 0.0f)
		{
			return true;
		}
	}

	return false;
}

#pragma region Climb
bool URoleMovementComponent::OnReceiveClimbablePos(const FHitResult& Hit, ScenePerceptionDetector& InScenePD)
{
	if (GravityVelocity.Z > 0.0f || GetHasLocoGroundSupport())
	{
		return false;
	}

	if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
	{
		ACTOR_CALL_LUA_ENTITY(Character, "KCB_OnReceiveClimbalePos");
	}

	if (UCapsuleComponent* CapsuleRoot = CharacterOwner->GetCapsuleComponent())
	{
		CapsuleRoot->GetScaledCapsuleSize(CapsuleRadiusBeforeClimb, CapsuleHalfHeightBeforeClimb);
		CapsuleRoot->SetCapsuleSize(GetClimbCapsuleRadius(), FMath::Max(GetClimbCapsuleRadius(), CapsuleHalfHeightBeforeClimb));
	}

	// 更新目标攀爬位置和朝向
	GetRoleMP().GetMovementContext().SetTargetClimbImpactLoc(Hit.ImpactPoint);
	GetRoleMP().GetMovementContext().SetTargetClimbLoc(Hit.Location);
	GetRoleMP().GetMovementContext().SetTargetClimbInverseImpactRot((-Hit.ImpactNormal).Rotation());

	SetGravityVelocity(0.0f, 0.0f, 0.0f);

	return true;
}

void URoleMovementComponent::OnReceiveLeavingClimbStage()
{
	if (ProactivelyLeavingClimbStage(false))
	{
		if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_OnReceiveLeavingClimbStage");
		}
	}
}

bool URoleMovementComponent::ProactivelyLeavingClimbStage(bool InAllowReClimb)
{
	if (ScenePD.IsValid())
	{
		// 这里恢复胶囊体的竖直需要立即执行，否则可能会有移动表现问题
		FRotator CurCharacterRot = UpdatedComponent->GetComponentRotation();
		CurCharacterRot.Pitch = 0.0f;
		CurCharacterRot.Roll = 0.0f;
		UpdatedComponent->SetWorldRotation(CurCharacterRot);

		if (UCapsuleComponent* CapsuleRoot = CharacterOwner->GetCapsuleComponent())
		{
			CapsuleRoot->SetCapsuleSize(CapsuleRadiusBeforeClimb, CapsuleHalfHeightBeforeClimb);
		}

		ScenePD->SetCurClimbDetectStage(InAllowReClimb ? EClimbDetectStage::ECDS_TryFindClimbPos : EClimbDetectStage::ECDS_LeavingClimb);

		return true;
	}

	return false;
}

void URoleMovementComponent::SwitchClimbDetect(bool isSwitchOn)
{
	if (ScenePD.IsValid())
	{
		ScenePD->SwitchClimbDetect(isSwitchOn);
	}
}

void URoleMovementComponent::SetClimbAngleRange(float InMinClimbAngleCos, float InMaxClimbAngleCos)
{
	StaticDataInfo.MinClimbAngleCos = InMinClimbAngleCos;
	StaticDataInfo.MaxClimbAngleCos = InMaxClimbAngleCos;
}

void URoleMovementComponent::SetDisableClimbTag(FName InDisableClimbComponentTag)
{
	if (ScenePD.IsValid())
	{
		ScenePD->SetDisableClimbTag(InDisableClimbComponentTag);
	}
}

void URoleMovementComponent::SetClimbPosDetectInfo(float InClimbRadius, float InDetectLength)
{
	StaticDataInfo.ClimbCapsuleRadius = InClimbRadius;
	StaticDataInfo.TryClimbDetectDistance = InDetectLength;
}

void URoleMovementComponent::SetClimbBoundsCheckInfo(bool InCheckBounds, float InMinimumClimbBoundsRadius, float InMinimumClimbBoundsBoxLength)
{
	StaticDataInfo.bNeedClimbCheckBounds = InCheckBounds;
	StaticDataInfo.MinimumClimbBoundsRadius = InMinimumClimbBoundsRadius;
	StaticDataInfo.MinimumClimbBoundsBoxLength = InMinimumClimbBoundsBoxLength;
}

bool URoleMovementComponent::DoClimbingInPipeline(float deltaTime)
{
	if (ScenePD.IsValid())
	{
		return ScenePD->DoClimbingInPipeline(deltaTime, *this, GetRoleMP().GetMovementContext());
	}

	return false;
}

bool URoleMovementComponent::ReDoClimbingFitInPipeline(float deltaTime, const FVector& OldXYDelta, FVector& NewDelta)
{
	if (ScenePD.IsValid())
	{
		return ScenePD->ReDoClimbingFitInPipeline(deltaTime, *this, OldXYDelta, NewDelta);
	}

	return false;
}
#pragma endregion Climb

#pragma region Hurdle
void URoleMovementComponent::SetHurdleDetect(float HurdleYaw, float YawThreshold, float InIdleSpeedThreshold,
	const TArray<int>& InHurdleDetectObjectTypes, float InHurdleDegreeThreshold, float InIdleHurdleDetect,
	float InIdleMinHurdleLedge, float InIdleMaxHurdleLedge, float InIdleMaxHurdleThickness,
	float InIdleHurdleTypeShortThicknessThreshold, float InIdleHurdleTypeLongThicknessThreshold,
	float InIdleHurdleTypeFallingDistance, float InWalkHurdleDetect, float InWalkMinHurdleLedge,
	float InWalkMaxHurdleLedge, float InWalkMaxHurdleThickness, float InWalkHurdleTypeShortThicknessThreshold,
	float InWalkHurdleTypeLongThicknessThreshold, float InWalkHurdleTypeFallingDistance, float InRunHurdleDetect,
	float InRunMinHurdleLedge, float InRunMaxHurdleLedge,
	float InRunMaxHurdleThickness, float InRunHurdleTypeShortThicknessThreshold,
	float InRunHurdleTypeLongThicknessThreshold, float InRunHurdleTypeFallingDistance)
{
	if (ScenePD.IsValid())
	{
		ScenePD->SetHurdleDetect(HurdleYaw, YawThreshold, InIdleSpeedThreshold, InHurdleDetectObjectTypes, InHurdleDegreeThreshold,
			InIdleHurdleDetect, InIdleMinHurdleLedge, InIdleMaxHurdleLedge, InIdleMaxHurdleThickness, InIdleHurdleTypeShortThicknessThreshold, InIdleHurdleTypeLongThicknessThreshold, InIdleHurdleTypeFallingDistance,
			InWalkHurdleDetect, InWalkMinHurdleLedge, InWalkMaxHurdleLedge, InWalkMaxHurdleThickness, InWalkHurdleTypeShortThicknessThreshold, InWalkHurdleTypeLongThicknessThreshold, InWalkHurdleTypeFallingDistance,
			InRunHurdleDetect, InRunMinHurdleLedge, InRunMaxHurdleLedge, InRunMaxHurdleThickness, InRunHurdleTypeShortThicknessThreshold, InRunHurdleTypeLongThicknessThreshold, InRunHurdleTypeFallingDistance
		);
	}
}

bool URoleMovementComponent::CheckHurdle(UCapsuleComponent* Capsule, int& HurdleType, FVector& AlignPoint,
	FVector& FirstWarpPoint, FVector& SecondWarpPoint, FVector& FallingWarpPoint, float& HurdleYaw)
{
	if(Capsule == nullptr)
	{
		return false;
	}

	if (ScenePD.IsValid())
	{
		return ScenePD->CheckHurdle(this, Capsule, HurdleType, AlignPoint, FirstWarpPoint, SecondWarpPoint, FallingWarpPoint, HurdleYaw);
	}

	return false;
}

bool URoleMovementComponent::GetHurdleHandIKLocation(const FVector& EffectBoneLocation, FVector& OutLocation, float DetectDepth)
{
	if(ScenePD.IsValid())
	{
		return ScenePD->GetHurdleHandIKLocation(this, EffectBoneLocation, OutLocation, DetectDepth);
	}
	return false;
}

void URoleMovementComponent::OpenHurdleDebug(bool bOpen) const
{
	if(ScenePD.IsValid())
	{
		return ScenePD->OpenHurdleDebug(bOpen);
	}
}

#pragma endregion Hurdle

#pragma region DistNotify
void URoleMovementComponent::AddGrounDistToNotify(const float& GroundDistToNotify, const FString& Reason)
{
	if (ScenePD.IsValid())
	{
		return ScenePD->AddGrounDistToNotify(GroundDistToNotify, Reason);
	}
}

void URoleMovementComponent::RemoveGrounDistToNotify(const float& GroundDistToNotify, const FString& Reason)
{
	if (ScenePD.IsValid())
	{
		return ScenePD->RemoveGrounDistToNotify(GroundDistToNotify, Reason);
	}
}

void URoleMovementComponent::ClearGrounDistToNotify()
{
	if (ScenePD.IsValid())
	{
		return ScenePD->ClearGrounDistToNotify();
	}
}

void URoleMovementComponent::AddWaterDistToNotify(const float& WaterDistToNotify, const FString& Reason)
{
	if (ScenePD.IsValid())
	{
		return ScenePD->AddWaterDistToNotify(WaterDistToNotify, Reason);
	}
}

void URoleMovementComponent::RemoveWaterDistToNotify(const float& WaterDistToNotify, const FString& Reason)
{
	if (ScenePD.IsValid())
	{
		return ScenePD->RemoveWaterDistToNotify(WaterDistToNotify, Reason);
	}
}

void URoleMovementComponent::ClearWaterDistToNotify()
{
	if (ScenePD.IsValid())
	{
		return ScenePD->ClearWaterDistToNotify();
	}
}

void URoleMovementComponent::AddWaterDepthToNotify(const float& WaterDepthToNotify, const FString& Reason)
{
	if (ScenePD.IsValid())
	{
		return ScenePD->AddWaterDepthToNotify(WaterDepthToNotify, Reason);
	}
}

void URoleMovementComponent::RemoveWaterDepthToNotify(const float& WaterDepthToNotify, const FString& Reason)
{
	if (ScenePD.IsValid())
	{
		return ScenePD->RemoveWaterDepthToNotify(WaterDepthToNotify, Reason);
	}
}

void URoleMovementComponent::ClearWaterDepthToNotify()
{
	if (ScenePD.IsValid())
	{
		return ScenePD->ClearWaterDepthToNotify();
	}
}
#pragma endregion DistNotify

#pragma endregion ScenePerception

bool URoleMovementComponent::CheckCharacterIsStuck()
{
	if (ScenePD.IsValid()) {

		UWorld* World = this->GetWorld();
		ACharacter* Character = this->GetCharacterOwner();
		return ScenePD->CheckCharacterIsStuck(World, Character);
	}
	return false;
}

void URoleMovementComponent::MoveToPosWithoutBlock()
{
	if (!ScenePD.IsValid()) {
		return;
	}
	UWorld* World = this->GetWorld();
	ACharacter* Character = this->GetCharacterOwner();
	FVector TargetPos;
	if (!ScenePD->GetPosWithoutBlock(World, Character, TargetPos))
	{
		return;
	}
	Character->SetActorLocation(TargetPos, false, nullptr, ETeleportType::TeleportPhysics);
}


void URoleMovementComponent::InitSplineActor(FVector Loc, FRotator Rot)
{
	AActor* InSplineActor = GetWorld()->SpawnActor(AActor::StaticClass(), &Loc, &Rot);
	TWeakObjectPtr<AActor> SplineActorWeakObjectPtr(InSplineActor);
	if (!SplineActorWeakObjectPtr.IsValid())
	{
		this->SplineActor = nullptr;
		return;
	}
	this->SplineActor = SplineActorWeakObjectPtr;
	SplineActor->AddComponentByClass(USceneComponent::StaticClass(), false, FTransform(), false);
	SplineActor->SetActorLocation(Loc);
	SplineActor->SetActorRotation(Rot);
	if (!SplineActor->GetComponentByClass<USplineComponent>())
	{
		SplineActor->AddComponentByClass(USplineComponent::StaticClass(), false, FTransform(), false);
	}
}

void URoleMovementComponent::ClearSplineActor()
{
	if (!SplineActor.IsValid()) return;
	SplineActor->SetActorHiddenInGame(true);
	SplineActor->Destroy();
	SplineActor.Reset();
}

TArray<FSplinePoint> URoleMovementComponent::ConstructSplinePointList(const TArray<FVector>& SplinePoints, ESplinePointType::Type PointType)
{
	TArray<FSplinePoint> PointArray;
	for (int32 i = 0; i < SplinePoints.Num(); i++)
	{
		FSplinePoint SplinePoint = FSplinePoint(i, SplinePoints[i], PointType);
		PointArray.Add(SplinePoint);
	}
	return PointArray;
}

void URoleMovementComponent::InitSplineMoveParams(float MaxVelocity, int StartIndex, ESplineMoveMode InSplineMoveMode)
{

	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if (!SplineComp)
	{
		UE_LOG(LogRoleMovement, Error, TEXT("must have SplineComp when InitSplineMoveParams!!"));
		return;
	}
	
	this->bAllowMoveWithSpline = true;
	this->SplineMoveDistance = StartIndex < 0? 0.0: SplineComp->GetDistanceAlongSplineAtSplinePoint(StartIndex);
	this->SplineMoveMaxVelocity = MaxVelocity;
	this->OriginVelocity = MaxVelocity;
	this->SplineMoveStartIndex = StartIndex;
	this->bHasReachSplineStartPoint = StartIndex < 0 ? true: false;
	this->bRequestedMoveUseAcceleration = false;
	this->SplineMoveMode = InSplineMoveMode;
	this->SplineMoveDirectionMode = InSplineMoveMode == ESplineMoveMode::Backtrack? ESplineMoveDirectionMode::Backward: ESplineMoveDirectionMode::Forward;
	bhasResetSplineMoveMaxVelocity = false;
	bNeedAdjustPos = false;
	CountUpdateSpeedDeltaTime = 0.f;
	bStartAnimMoveToPoint = false;
	bEndAnimMoveToPoint = false;
	MoveToPointStartAnimTime = 0.f;
	MoveToPointEndAnimTime = 0.f;
	MoveToPointEndHalfTime = 0.f;
	BarkStopToken.Reset();

	CurrentCycleMotionIndex = CM_START_INDEX;
	SplineMoveTotalTime = -1.0;
	SplineMoveAccuTime = 0;
	SplineMoveAnimPlayRate = 1.0f;

	bNeedSplineMoveStopInAdvance = false;
	MaxSplineMoveStopInAdvanceTime = -1.0f;
	MaxSplineMoveStopInAdvanceDist = -1.0f;
	
	this->bJustUseRequestedVel = true;
	SetForceLocoStartToTrue();
	
	UpdateSplineMoveVel(StartIndex);
}

void URoleMovementComponent::ResumeSplineMoveWhenBorn(const TArray<FSplinePoint>& SplinePoints, float MaxVelocity, const FVector& CurServerPos, int CurPointIndex, ESplineMoveMode InSplineMoveMode)
{	
	if (CurPointIndex > SplinePoints.Num() - 1)
	{
		return;
	}
	ACharacter* Character = this->GetCharacterOwner();
	
	this->StartMoveWithSplinePoints(SplinePoints, MaxVelocity, -1, InSplineMoveMode);
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if (!SplineComp)
	{
		UE_LOG(LogRoleMovement, Error, TEXT("must have SplineComp when ResumeSplineMoveWhenBorn!!"));
		return;
	}
	FVector CurPointPos = SplineComp->GetLocationAtSplinePoint(CurPointIndex, ESplineCoordinateSpace::Type::World);
	FVector NextPointPos = SplineComp->GetLocationAtSplinePoint(CurPointIndex + 1, ESplineCoordinateSpace::Type::World);
	float Percent = (CurServerPos - CurPointPos).Length() / (NextPointPos - CurPointPos).Length();

	const double StartDist = SplineComp->GetDistanceAlongSplineAtSplinePoint(CurPointIndex);
	const double NextDist = SplineComp->GetDistanceAlongSplineAtSplinePoint(CurPointIndex + 1);

	// 已经走过的距离
	this->SplineMoveDistance = (NextDist - StartDist) * Percent + StartDist;
	FTransform TargetTrans = SplineComp->GetTransformAtDistanceAlongSpline(this->SplineMoveDistance, ESplineCoordinateSpace::Type::World, true);
	FVector CaptureLocation = TraceGroundCaptureLocation(TargetTrans.GetLocation());
	TeleportTo(CaptureLocation, TargetTrans.GetRotation().Rotator());
}

void URoleMovementComponent::StartMoveWithSplinePoints(const TArray<FSplinePoint>& SplinePoints, float MaxVelocity, int StartIndex, ESplineMoveMode InSplineMoveMode)
{
	if (SplinePoints.Num() == 0)
	{
		return;
	}
	if (this->bAllowMoveWithSpline)
	{
		return;
	}

	FVector ActorLoc = SplinePoints[0].Position;
	InitSplineActor(ActorLoc, FRotator::ZeroRotator);
	if (!SplineActor.IsValid())
	{
		return;
	}
	
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	SplineComp->ClearSplinePoints();

	// 这里有一个规则: FSplinePoint 本身应该包含的是相对于 SplineActor的起始点的坐标
	// 不过动态构建的时候使用的都是 世界坐标所以这里需要进行一次坐标空间转换
	const FTransform& ComponentTransform = SplineComp->GetComponentTransform();
	const FTransform InverseTransform = ComponentTransform.Inverse();

	TArray<FSplinePoint> TempSplinePoints = SplinePoints;
	for (FSplinePoint& Point : TempSplinePoints)
	{
		// 转换位置 (世界坐标 -> 本地坐标)
		Point.Position = InverseTransform.TransformPosition(Point.Position);
		// 转换到达切线 (世界方向 -> 本地方向)
		Point.ArriveTangent = InverseTransform.TransformVector(Point.ArriveTangent);
		// 转换离开切线 (世界方向 -> 本地方向)
		Point.LeaveTangent = InverseTransform.TransformVector(Point.LeaveTangent);
	}
	SplineComp->AddPoints(TempSplinePoints);
	
	if (InSplineMoveMode == ESplineMoveMode::Cycle)
	{
		SplineComp->SetClosedLoop(true);
	}
	
	InitSplineMoveParams(MaxVelocity, StartIndex, InSplineMoveMode);
}

void URoleMovementComponent::UpdateMoveParamWithSpline(const bool& bStartAnim, const float& StartAnimTime, const bool& bEndAnim, const float& EndAnimTime, const float& EndHalfTime)
{
	SplineMoveCurVelocity = 0.f;
	CountUpdateSpeedDeltaTime = 0.f;
	bStartAnimMoveToPoint = bStartAnim;
	bEndAnimMoveToPoint = bEndAnim;
	MoveToPointStartAnimTime = StartAnimTime;
	MoveToPointEndAnimTime = EndAnimTime;
	MoveToPointEndHalfTime = EndHalfTime;
}

void URoleMovementComponent::InitSplineMoveModes(ESplineMoveProgressMode ProgressMode, float SpeedOrTime, ESplineMoveDriveMode DriveMode)
{
	SplineMoveProgressMode = ProgressMode;
	if(SplineMoveProgressMode == ESplineMoveProgressMode::ProgressByTime || SplineMoveProgressMode == ESplineMoveProgressMode::ProgressByCycleMotion)
	{
		SplineMoveTotalTime = SpeedOrTime;
		SplineMoveAccuTime = 0;

		if(SplineActor.IsValid())
		{
			USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
			SplineComp->Duration = SplineMoveTotalTime;
		}
		
	}
	else if(SplineMoveProgressMode == ESplineMoveProgressMode::ProgressBySpeed)
	{
		// todo 补充 
	}

	SplineMoveDriveMode = DriveMode;
}


bool URoleMovementComponent::InitSplineMoveWithCycleMotion(FName StartName, FName LoopName, FName EndName, bool UseXYOnly, float AnimPlayRate)
{
	OnlyUsingXYMove = UseXYOnly;
	SplineMoveAnimPlayRate = AnimPlayRate;
	
	float TotalTime = EvaluateDurationWhenSplineMoveWithCycleMotion(StartName, LoopName, EndName, true, SplineMoveAnimPlayRate);
	if(FMath::IsNearlyZero(TotalTime))
	{
		UE_LOG(LogRoleMovement, Warning,
			TEXT("[URoleMovementComponent:InitSplineMoveWithCycleMotion] Cannot Init SplineMove With CycleMotion ")
		);
		return false;
	}

	InitSplineMoveModes(ESplineMoveProgressMode::ProgressByCycleMotion, TotalTime, ESplineMoveDriveMode::DriveByRootMotion);
	return true;
}

void URoleMovementComponent::DialogueInitSplineMoveWithCycleMotion(FName StartAnim_L, FName StartAnim_R, FName LoopName, FName EndAnimName_L, FName EndAnimName_R, bool IsFrameCheck,
	float MapInX, float MapInY, float MapOutX, float MapOutY, int LStartEnterLoopFrame, int RStartEnterLoopFrame, bool UseXYOnly)
{
	OnlyUsingXYMove = UseXYOnly;
	float TotalTime = DialogueEvaluateDurationWhenSplineMoveWithCycleMotion(StartAnim_L, StartAnim_R, LoopName, EndAnimName_L, EndAnimName_R, IsFrameCheck, MapInX, MapInY, MapOutX, MapOutY,
		LStartEnterLoopFrame, RStartEnterLoopFrame, true);
	if(FMath::IsNearlyZero(TotalTime))
	{
		UE_LOG(LogRoleMovement, Warning,
			TEXT("[URoleMovementComponent:InitSplineMoveWithCycleMotion] Cannot Init SplineMove With CycleMotion ")
		);
		return;
	}

	InitSplineMoveModes(ESplineMoveProgressMode::ProgressByCycleMotion, TotalTime, ESplineMoveDriveMode::DriveByRootMotion);
}

float URoleMovementComponent::DialogueEvaluateDurationWhenSplineMoveWithCycleMotion(FName StartAnim_L, FName StartAnim_R, FName LoopAnimName, FName EndAnimName_L, FName EndAnimName_R, bool IsFrameCheck, float MapInX, float MapInY, float MapOutX, float MapOutY, int LStartEnterLoopFrame, int RStartEnterLoopFrame, bool NeedInitMoveData)
{
	if (!SplineActor.IsValid()) return 0;

	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if(!SplineComp) return 0;
	
	UBaseAnimInstance * AnimInst = this->GetAnimInstanceForMovement();
	if(!AnimInst) return 0;
	
	float StartDuration = 0, LoopDuration = 0, EndDuration = 0;
	float StartDistance = 0, LoopDistance = 0, EndDistance = 0;
	float StartYawDiff = 0, LoopYawDiff = 0, EndYawDiff = 0;

	FName StartAnimName = StartAnim_L;
	FName EndAnimName = EndAnimName_L;
	
	AnimInst->GetLocoAnimRootMotionInfo(LoopAnimName, 0, -1, LoopDuration, LoopDistance, LoopYawDiff);

	float TotalSplineLength = SplineComp->GetSplineLength();
	float AvgLoopSpeed = LoopDistance / LoopDuration;
	float LoopMoveDuration = 0.f;
	float TotalTime = 0.f;
	float RealStartDuration = 0.f;
	
	AnimInst->CalculateLoopToEndTimeWithDistance(StartAnim_L, StartAnim_R, LoopAnimName, EndAnimName_L, EndAnimName_R, TotalSplineLength,
			MapInX, MapInY, MapOutX, MapOutY, LStartEnterLoopFrame, RStartEnterLoopFrame, LoopMoveDuration, SplineEndStartTime, TotalTime, RealStartDuration, StartAnimName, EndAnimName);
	AnimInst->GetLocoAnimRootMotionInfo(EndAnimName, SplineEndStartTime, -1, EndDuration, EndDistance, EndYawDiff);
	AnimInst->GetLocoAnimRootMotionInfo(StartAnimName, 0, RealStartDuration, StartDuration, StartDistance, StartYawDiff);

	EndDuration -= SplineEndStartTime;
	if (NeedInitMoveData)
	{
		bFrameCheckDialogue = IsFrameCheck;
		CycleMotionMovePhaseData.Reset();
		CurrentCycleMotionIndex = CM_START_INDEX;
		CycleMotionMovePhaseData.Emplace(RealStartDuration, StartDistance, RealStartDuration > 0.01f? StartDistance/RealStartDuration: 1.0f);
		CycleMotionMovePhaseData.Emplace(LoopMoveDuration, LoopDistance, AvgLoopSpeed);
		CycleMotionMovePhaseData.Emplace(EndDuration, EndDistance, EndDuration > 0.01f? EndDistance/EndDuration: 1.0f);

		CycleMotionMoveAnimName.Reset();
		CycleMotionMoveAnimName.Emplace(StartAnimName);
		CycleMotionMoveAnimName.Emplace(LoopAnimName);
		CycleMotionMoveAnimName.Emplace(EndAnimName);
	}
	
	return TotalTime;
}

float URoleMovementComponent::DialogueEvaluateDurationWhenSplineMoveWithSplinePoints(const TArray<FVector>& SplinePoints, FName StartAnim_L, FName StartAnim_R, FName LoopAnimName,
	FName EndAnimName_L, FName EndAnimName_R, bool IsFrameCheck, float MapInX, float MapInY, float MapOutX, float MapOutY, int LStartEnterLoopFrame, int RStartEnterLoopFrame)
{
	if (SplinePoints.Num() <= 1)
	{
		UE_LOG(LogRoleMovement, Error, TEXT("[URoleMovementComponent:DialogueEvaluateDurationWhenSplineMoveWithSplinePoints] SplinePoints Size nil, SplinePoints.Num:%i"), SplinePoints.Num());
		return 0.f;
	}
	
	ClearSplineActor();
	
	FVector Loc = SplinePoints[0];
	FRotator Rot(0, 0, 0);
	InitSplineActor(Loc, Rot);
	if (!SplineActor.IsValid()) return 0.f;

	float TotalTime = 0.f;
	if (USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>())
	{
		SplineComp->ClearSplinePoints();
		for (auto& SplinePoint : SplinePoints)
		{
			SplineComp->AddSplinePoint(SplinePoint, ESplineCoordinateSpace::World);
		}

		TotalTime = DialogueEvaluateDurationWhenSplineMoveWithCycleMotion(StartAnim_L, StartAnim_R, LoopAnimName, EndAnimName_L, EndAnimName_R, IsFrameCheck, MapInX, MapInY, MapOutX, MapOutY,
			LStartEnterLoopFrame, RStartEnterLoopFrame, false);
		SplineComp->ClearSplinePoints();
		ClearSplineActor();
	}
	
	return TotalTime;
}

float URoleMovementComponent::GetSplineMoveLength()
{

	if (!SplineActor.IsValid())
	{
		return 0;
	}
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if(!SplineComp)
	{
		return 0;
	}


	return SplineComp->GetSplineLength();
}

float URoleMovementComponent::GetSplineMoveDuration()
{
	if (!SplineActor.IsValid())
	{
		return 0;
	}
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if(!SplineComp)
	{
		return 0;
	}

	return SplineComp->Duration;
}


float URoleMovementComponent::GetDistanceOnMoveSplineByTime(float DriveTime, int & CycleMotionPhaseIndex)
{
	if (!SplineActor.IsValid())
	{
		return 0;
	}
	
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if(!SplineComp)
	{
		return 0;
	}
	// 考虑骑乘的时候, 真正移动单位是坐骑
	URoleMovementComponent * RealRMC = GetRealMovementViewProxy();

	UBaseAnimInstance * AnimInst = RealRMC->GetAnimInstanceForMovement();
	if(!AnimInst){
		return 0;
	}

	if(SplineMoveProgressMode == ESplineMoveProgressMode::ProgressByCycleMotion)
	{
		bool IsUseALSMove = IsALSMovementMode();
		int ValidDataCount = CM_END_INDEX + 1;
		if(CycleMotionMovePhaseData.Num() != ValidDataCount || CycleMotionMoveAnimName.Num() != ValidDataCount)
		{
			UE_LOG(LogRoleMovement, Error,
				TEXT("[URoleMovementComponent:GetDistanceOnMoveSplineByTime] Invalid CycleMotion Data, Move Num: %d, Anim Num:%d"),
				CycleMotionMovePhaseData.Num(), CycleMotionMoveAnimName.Num()
			);

			return 0;
		}

		float TIME_TOLERATE = 0.001f;
		float TotalDistance = 0;
		const auto & StartMoveData = CycleMotionMovePhaseData[CM_START_INDEX];
		float LeftTime = DriveTime;
		if(DriveTime <= StartMoveData.X && StartMoveData.X > TIME_TOLERATE)
		{
			float DurationOut, DistanceOut, YawDiffOut;
			if(IsUseALSMove){
				const FVector & MovePhaseData = CycleMotionMovePhaseData[CM_START_INDEX];
				DistanceOut = MovePhaseData.Y * (DriveTime * DriveTime) / (MovePhaseData.X * MovePhaseData.X);
			}
			else
			{
				AnimInst->GetLocoAnimRootMotionInfo(CycleMotionMoveAnimName[CM_START_INDEX], 0, DriveTime * SplineMoveAnimPlayRate, DurationOut, DistanceOut, YawDiffOut);
				if (FMath::IsNearlyZero(DistanceOut) && DurationOut > 0.0f)
				{
					// 没有动画rootmotion时，使用匀加速模拟
					DistanceOut = CycleMotionMovePhaseData[CM_START_INDEX].Y * (DriveTime * DriveTime) / (DurationOut * DurationOut);
				}
			}
			TotalDistance += DistanceOut;
			CycleMotionPhaseIndex = CM_START_INDEX;
			return TotalDistance;
		}
		else
		{
			TotalDistance += StartMoveData.Y;
			LeftTime -= StartMoveData.X;
		}
		
		
		const auto& LoopMoveData = CycleMotionMovePhaseData[CM_LOOP_INDEX];
		const auto& EndMoveData = CycleMotionMovePhaseData[CM_END_INDEX];
		float LoopTotalTime = LoopMoveData.X;
		
		if(LeftTime <= LoopTotalTime && LoopTotalTime > TIME_TOLERATE)
		{
			// loop阶段使用速度 * 时间
			TotalDistance += LoopMoveData.Z * LeftTime;
			CycleMotionPhaseIndex = CM_LOOP_INDEX;
			return TotalDistance;
			
		}
		else
		{
			TotalDistance += LoopMoveData.Z * LoopTotalTime;
			LeftTime -= LoopTotalTime;
		}
		
		if(EndMoveData.Z > TIME_TOLERATE)
		{
			float DurationOut, DistanceOut, YawDiffOut;
			if(IsUseALSMove){
				const FVector & MovePhaseData = CycleMotionMovePhaseData[CM_END_INDEX];
				DistanceOut = MovePhaseData.Y * (1.0 - ((MovePhaseData.X - LeftTime) * (MovePhaseData.X - LeftTime) / (MovePhaseData.X * MovePhaseData.X)));
			}
			else
			{
				AnimInst->GetLocoAnimRootMotionInfo(CycleMotionMoveAnimName[CM_END_INDEX], SplineEndStartTime, SplineEndStartTime + LeftTime * SplineMoveAnimPlayRate, DurationOut, DistanceOut, YawDiffOut);
				if (FMath::IsNearlyZero(DistanceOut) && DurationOut > 0.0f)
				{
					// 没有动画rootmotion时，使用匀减速模拟
					DistanceOut = CycleMotionMovePhaseData[CM_END_INDEX].Y * (1 - ((DurationOut - LeftTime) * (DurationOut - LeftTime) / (DurationOut * DurationOut)));
				}
			}
			TotalDistance += DistanceOut;
		}
		CycleMotionPhaseIndex = CM_END_INDEX;
		return TotalDistance;
	}

	// 其他的方式
	return 0;
	
}

float URoleMovementComponent::DialogueGetDistanceOnMoveSplineByTime(float DriveTime, int& CycleMotionPhaseIndex, bool bCrossInstance)
{
	if (!SplineActor.IsValid())
	{
		return 0;
	}
	
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if(!SplineComp)
	{
		return 0;
	}
	// 考虑骑乘的时候, 真正移动单位是坐骑
	URoleMovementComponent * RealRMC = GetRealMovementViewProxy();

	UBaseAnimInstance * AnimInst = RealRMC->GetAnimInstanceForMovement();
	if(!AnimInst){
		return 0;
	}

	if(SplineMoveProgressMode == ESplineMoveProgressMode::ProgressByCycleMotion)
	{
		int ValidDataCount = CM_END_INDEX + 1;
		if(CycleMotionMovePhaseData.Num() != ValidDataCount || CycleMotionMoveAnimName.Num() != ValidDataCount)
		{
			UE_LOG(LogRoleMovement, Error,
				TEXT("[URoleMovementComponent:DialogueGetDistanceOnMoveSplineByTime] Invalid CycleMotion Data, Move Num: %d, Anim Num:%d"),
				CycleMotionMovePhaseData.Num(), CycleMotionMoveAnimName.Num()
			);

			return 0;
		}

		float TIME_TOLERATE = 0.001f;
		float TotalDistance = 0;
		const auto & StartMoveData = CycleMotionMovePhaseData[CM_START_INDEX];
		float LeftTime = DriveTime;
		if(DriveTime <= StartMoveData.X && StartMoveData.X > TIME_TOLERATE)
		{
			float DurationOut, DistanceOut, YawDiffOut;
			AnimInst->GetLocoAnimRootMotionInfo(CycleMotionMoveAnimName[CM_START_INDEX], 0, DriveTime, DurationOut, DistanceOut, YawDiffOut);
			TotalDistance += DistanceOut;
			CycleMotionPhaseIndex = CM_START_INDEX;
			AnimInst->DialogueCrossfadeToStage(EDialogueStage::MoveStart, bCrossInstance);
			return TotalDistance;
		}
		else
		{
			TotalDistance += StartMoveData.Y;
			LeftTime -= StartMoveData.X;
		}
		
		
		const auto& LoopMoveData = CycleMotionMovePhaseData[CM_LOOP_INDEX];
		const auto& EndMoveData = CycleMotionMovePhaseData[CM_END_INDEX];
		float LoopTotalTime = LoopMoveData.X;
		
		if(LeftTime <= LoopTotalTime && LoopTotalTime > TIME_TOLERATE)
		{
			// loop阶段使用速度 * 时间
			TotalDistance += LoopMoveData.Z * LeftTime;
			CycleMotionPhaseIndex = CM_LOOP_INDEX;
			AnimInst->DialogueCrossfadeToStage(EDialogueStage::MoveLoop, bCrossInstance);
			return TotalDistance;
			
		}
		else
		{
			TotalDistance += LoopMoveData.Z * LoopTotalTime;
			LeftTime -= LoopTotalTime;
		}
		
		if(EndMoveData.Z > TIME_TOLERATE)
		{
			float DurationOut, DistanceOut, YawDiffOut;
			AnimInst->GetLocoAnimRootMotionInfo(CycleMotionMoveAnimName[CM_END_INDEX], SplineEndStartTime, SplineEndStartTime + LeftTime, DurationOut, DistanceOut, YawDiffOut);
			TotalDistance += DistanceOut;
			AnimInst->DialogueCrossfadeToStage(EDialogueStage::MoveEnd, bCrossInstance);
		}
		CycleMotionPhaseIndex = CM_END_INDEX;
		return TotalDistance;
	}

	// 其他的方式
	return 0;
}

bool URoleMovementComponent::GetWorldTransformOnMoveSplineByTime(float Time, FTransform & OutputTrans)
{
	if (!SplineActor.IsValid())
	{
		return false;
	}
	
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if(!SplineComp)
	{
		return false;
	}

	int CurrentCycleMotionPhaseIndex = CM_START_INDEX;
	OutputTrans = SplineComp->GetTransformAtDistanceAlongSpline(GetDistanceOnMoveSplineByTime(Time, CurrentCycleMotionPhaseIndex), ESplineCoordinateSpace::World, false);
	return true;
}

float URoleMovementComponent::EvaluateDurationWhenSplineMoveWithCycleMotion(FName StartAnimName, FName LoopAnimName, FName EndAnimName, bool NeedInitMoveData, float AnimPlayRate)
{
	if (!SplineActor.IsValid())
	{
		return 0;
	}
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if(!SplineComp)
	{
		return 0;
	}

	float StartDuration = 0, LoopDuration = 0, EndDuration = 0;
	float StartDistance = 0, LoopDistance = 0, EndDistance = 0;
	float StartYawDiff = 0, LoopYawDiff = 0, EndYawDiff = 0;

	if (!InnerEvaluateDurationWhenSplineMoveWithSplinePoints(StartAnimName, LoopAnimName, EndAnimName, StartDuration, LoopDuration, EndDuration,
		StartDistance, LoopDistance, EndDistance, StartYawDiff, LoopYawDiff, EndYawDiff, AnimPlayRate > 0.0f ? AnimPlayRate : 1.0f))
	{
		return 0;
	}

	float TotalSplineLength = SplineComp->GetSplineLength();
	float StartAndEndDistance = StartDistance + EndDistance;

	float LeftDistance = TotalSplineLength - StartAndEndDistance;
	float TotalTime = StartDuration + EndDuration;
	float AvgLoopSpeed = LoopDistance / LoopDuration;
	float LoopMoveDuration = LeftDistance / AvgLoopSpeed;

	// Loop时长过短，会导致“Loop时ForceLocoStart为true，End再为false”的流程，无法流转到动画蓝图
	if(StartAndEndDistance > TotalSplineLength || LoopMoveDuration < 0.2f)
	{
		UE_LOG(LogRoleMovement, Warning,
			TEXT("[URoleMovementComponent:EvaluateDurationWhenSplineMoveWithCycleMotion] Spline Length To Short To Use CycleMotion, SplineLength:%.2f, StartAndEnd Length:%.2f"),
			TotalSplineLength, StartAndEndDistance
			);

		return 0;
	}

	TotalTime += LoopMoveDuration;

	if (NeedInitMoveData)
	{
		CycleMotionMovePhaseData.Reset();
		CurrentCycleMotionIndex = CM_START_INDEX;
		CycleMotionMovePhaseData.Emplace(StartDuration, StartDistance, StartDuration > 0.01f? StartDistance/StartDuration: 1.0f);
		CycleMotionMovePhaseData.Emplace(LoopMoveDuration, LoopDistance, AvgLoopSpeed);
		CycleMotionMovePhaseData.Emplace(EndDuration, EndDistance, EndDuration > 0.01f? EndDistance/EndDuration: 1.0f);

		CycleMotionMoveAnimName.Reset();
		CycleMotionMoveAnimName.Emplace(StartAnimName);
		CycleMotionMoveAnimName.Emplace(LoopAnimName);
		CycleMotionMoveAnimName.Emplace(EndAnimName);
		
	}
	
	return TotalTime;
}

bool URoleMovementComponent::InnerEvaluateDurationWhenSplineMoveWithSplinePoints(const FName& StartAnimName, const FName& LoopAnimName, const FName& EndAnimName, float& StartDuration, 
	float& LoopDuration, float& EndDuration, float& StartDistance, float& LoopDistance, float& EndDistance, float& StartYawDiff, float& LoopYawDiff, float& EndYawDiff, const float& AnimPlayRate)
{
	// 考虑骑乘的时候, 真正移动单位是坐骑
	URoleMovementComponent* RealRMC = GetRealMovementViewProxy();

	UBaseAnimInstance* AnimInst = RealRMC->GetAnimInstanceForMovement();
	if (!AnimInst) {
		return false;
	}

	float CurMaxSpeed = GetLocoMaxSpeed();
	
	if(IsALSMovementMode())
	{
		// 
		StartDuration = 0.4;
		StartDistance = 0;
		StartYawDiff = 0;
		LoopDuration = 0.8;
		LoopDistance = 0;
		LoopYawDiff = 0;
		EndDuration = 0.4;
		EndDistance = 0;
		EndYawDiff = 0;
	}
	else
	{
		AnimInst->GetLocoAnimRootMotionInfo(StartAnimName, 0, -1, StartDuration, StartDistance, StartYawDiff);
		AnimInst->GetLocoAnimRootMotionInfo(LoopAnimName, 0, -1, LoopDuration, LoopDistance, LoopYawDiff);
		AnimInst->GetLocoAnimRootMotionInfo(EndAnimName, 0, -1, EndDuration, EndDistance, EndYawDiff);
	}

	if (StartDuration > 0.0f)
	{
		if (FMath::IsNearlyZero(StartDistance))
		{
			StartDistance = 0.5f * CurMaxSpeed * StartDuration;
		}
		else
		{
			StartDuration = StartDuration / AnimPlayRate;
		}
	}
	if (LoopDuration > 0.0f)
	{
		if (FMath::IsNearlyZero(LoopDistance))
		{
			LoopDistance = CurMaxSpeed * LoopDuration;
		}
		else
		{
			LoopDuration = LoopDuration / AnimPlayRate;
		}
	}
	if (EndDuration > 0.0f)
	{
		if (FMath::IsNearlyZero(EndDistance))
		{
			EndDistance = 0.5f * CurMaxSpeed * EndDuration;
		}
		else
		{
			EndDuration = EndDuration / AnimPlayRate;
		}
	}

	if (FMath::IsNearlyZero(LoopDuration) || FMath::IsNearlyZero(LoopDistance))
	{
		UE_LOG(LogRoleMovement, Warning,
			TEXT("[URoleMovementComponent:InnerEvaluateDurationWhenSplineMoveWithSplinePoints] Loop Anim:%s Need RootMotion Length :%.2f, duration:%.2f"),
			*LoopAnimName.ToString(), LoopDistance, LoopDuration
		);

		return false;
	}

	return true;
}

bool URoleMovementComponent::ChangeSpeedDuringSplineMoveWithCycleMotion(const FName& StartAnimName, const FName& LoopAnimName, const FName& EndAnimName, float AnimPlayRate)
{
	if (!SplineActor.IsValid())
	{
		return false;
	}
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if (!SplineComp)
	{
		return false;
	}

	if (CurrentCycleMotionIndex == CM_END_INDEX)
	{
		// 如果已经在停步阶段，就不处理了
		return false;
	}

	if (CycleMotionMovePhaseData.Num() < 3)
	{
		// 数据不完整，不处理
		return false;
	}

	float StartDuration = 0, LoopDuration = 0, EndDuration = 0;
	float StartDistance = 0, LoopDistance = 0, EndDistance = 0;
	float StartYawDiff = 0, LoopYawDiff = 0, EndYawDiff = 0;

	if (!InnerEvaluateDurationWhenSplineMoveWithSplinePoints(StartAnimName, LoopAnimName, EndAnimName, StartDuration, LoopDuration, EndDuration,
		StartDistance, LoopDistance, EndDistance, StartYawDiff, LoopYawDiff, EndYawDiff, AnimPlayRate > 0.0f ? AnimPlayRate : 1.0f))
	{
		return false;
	}

	float TotalSplineLength = SplineComp->GetSplineLength();
	float AvgLoopSpeed = LoopDistance / LoopDuration;
	float LoopMoveDist = TotalSplineLength - CycleMotionMovePhaseData[0].Y - EndDistance;
	if (CurrentCycleMotionIndex == CM_START_INDEX)
	{
		// 起步姿态，起步姿势就不更改了，只改Loop和End的
		if (LoopMoveDist < 0.0f)
		{
			// 更新速度后停步动作长度如果超过总距离，那说明剩余距离很短了，不处理
			return false;
		}
		SplineMoveTotalTime = CycleMotionMovePhaseData[0].X + CycleMotionMovePhaseData[2].X + LoopMoveDist / AvgLoopSpeed;
		SplineMoveAnimPlayRate = AnimPlayRate;
		CycleMotionMovePhaseData[1].X = LoopMoveDist / AvgLoopSpeed;
		CycleMotionMovePhaseData[1].Y = LoopDistance;
		CycleMotionMovePhaseData[1].Z = AvgLoopSpeed;
		CycleMotionMovePhaseData[2].X = EndDuration;
		CycleMotionMovePhaseData[2].Y = EndDistance;
		CycleMotionMovePhaseData[2].Z = EndDuration > 0.01f ? EndDistance / EndDuration : 1.0f;

		CycleMotionMoveAnimName[1] = LoopAnimName;
		CycleMotionMoveAnimName[2] = EndAnimName;
	}
	else if (CurrentCycleMotionIndex == CM_LOOP_INDEX)
	{
		// 在Loop阶段，计算稍微麻烦些，需要找到正确的位置
		float LoopAccuTime = SplineMoveAccuTime - CycleMotionMovePhaseData[0].X;
		float LoopAccuDist = LoopAccuTime * CycleMotionMovePhaseData[1].Z;
		float RemainLoopMoveDist = TotalSplineLength - CycleMotionMovePhaseData[0].Y - EndDistance - LoopAccuDist;
		if (RemainLoopMoveDist < 0.0f)
		{
			// 更新速度后停步动作长度如果超过总距离，那说明剩余距离很短了，不处理
			return false;
		}
		SplineMoveAccuTime = CycleMotionMovePhaseData[0].X + LoopAccuDist / AvgLoopSpeed;
		SplineMoveTotalTime = CycleMotionMovePhaseData[0].X + CycleMotionMovePhaseData[2].X + LoopMoveDist / AvgLoopSpeed;
		SplineMoveAnimPlayRate = AnimPlayRate;
		CycleMotionMovePhaseData[1].X = LoopMoveDist / AvgLoopSpeed;
		CycleMotionMovePhaseData[1].Y = LoopDistance;
		CycleMotionMovePhaseData[1].Z = AvgLoopSpeed;
		CycleMotionMovePhaseData[2].X = EndDuration;
		CycleMotionMovePhaseData[2].Y = EndDistance;
		CycleMotionMovePhaseData[2].Z = EndDuration > 0.01f ? EndDistance / EndDuration : 1.0f;

		CycleMotionMoveAnimName[1] = LoopAnimName;
		CycleMotionMoveAnimName[2] = EndAnimName;
	}

	return true;
}

float URoleMovementComponent::EvaluateDurationWhenSplineMoveWithSplinePoints(const TArray<FVector>& SplinePoints, FName StartAnimName, FName LoopAnimName, FName EndAnimName, float AnimPlayRate)
{
	if (SplinePoints.Num() <= 1)
	{
		UE_LOG(LogRoleMovement, Error, TEXT("[URoleMovementComponent:EvaluateDurationWhenSplineMoveWithSplinePoints] SplinePoints Size nil, SplinePoints.Num:%i"), SplinePoints.Num());
		return 0.f;
	}
	
	ClearSplineActor();
	
	FVector Loc = SplinePoints[0];
	FRotator Rot(0, 0, 0);
	InitSplineActor(Loc, Rot);
	if (!SplineActor.IsValid()) return 0.f;

	float TotalTime = 0.f;
	if (USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>())
	{
		SplineComp->ClearSplinePoints();
		for (auto& SplinePoint : SplinePoints)
		{
			SplineComp->AddSplinePoint(SplinePoint, ESplineCoordinateSpace::World);
		}

		TotalTime = EvaluateDurationWhenSplineMoveWithCycleMotion(StartAnimName, LoopAnimName, EndAnimName, false, AnimPlayRate);
		SplineComp->ClearSplinePoints();
		ClearSplineActor();
	}
	
	return TotalTime;
}

void URoleMovementComponent::UpdateCurSplineMoveVelocity(USplineComponent* SplineComp, float DeltaTime)
{
	if (!SplineComp) return;

	// 起步速度
	if (!bStartAnimMoveToPoint && SplineMoveCurVelocity != SplineMoveMaxVelocity)
	{
		SplineMoveCurVelocity = SplineMoveMaxVelocity;
	}
	else if (bStartAnimMoveToPoint && SplineMoveCurVelocity < SplineMoveMaxVelocity && MoveToPointStartAnimTime > 0.f)
	{
		CountUpdateSpeedDeltaTime += DeltaTime;
		float Alpha = FMath::Clamp(CountUpdateSpeedDeltaTime/MoveToPointStartAnimTime, 0, 1);
		SplineMoveCurVelocity = FMath::Lerp(0, SplineMoveMaxVelocity, Alpha);
		if (Alpha == 1)
		{
			MoveToPointStartAnimTime = 0.f;
			CountUpdateSpeedDeltaTime = 0.f;
		}
	}

	if (bEndAnimMoveToPoint && MoveToPointEndAnimTime > 0.f && !BarkStopToken.IsSet())
	{
		// 这里减速效果只给到曲线终点就停止移动的模式使用
		if (SplineMoveMode == ESplineMoveMode::Single)
		{
			float RemainDistance = SplineComp->GetSplineLength() - this->SplineMoveDistance;
			if (RemainDistance < 0.5 * SplineMoveMaxVelocity * MoveToPointEndAnimTime)
			{
				BarkStopToken = ObtainMoveCorrector(ECorrectorObtainPriority::Action, EMovementCorrectorType::DestSmoothCorrector);
				SetDestSmoothCorrectorParam(MoveToPointEndAnimTime, MoveToPointEndHalfTime);
				SetDestSmoothCorrectorType(ESmoothCorrectorType::TimeAlphaSmooth, SplineMoveCurVelocity);
				SetDestLocSmoothParam(GetActorLocation(), SplineComp->GetLocationAtSplinePoint(SplineComp->GetNumberOfSplinePoints() - 1, ESplineCoordinateSpace::Type::World));
			}
		}
	}
}

void URoleMovementComponent::PauseSplineMove()
{
	if (!this->bAllowMoveWithSpline)
	{
		return;
	}
	this->bPauseSplineMove = true;
	ClearForceLocoStart();
}

void URoleMovementComponent::ResumeSplineMove()
{
	if (!this->bAllowMoveWithSpline)
	{
		return;
	}
	this->bPauseSplineMove = false;
	SetForceLocoStartToTrue();
}

void URoleMovementComponent::UpdateSplineMoveVel(int PointIndex)
{
	if (!this->bAllowMoveWithSpline)
	{
		return;
	}

	if (PointIndex < 0)
	{
		return;
	}

	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if (!SplineComp)
	{
		return;
	}
	
	FVector2D DirXY = GetDirOfOwnerAndSplineStartPoint(PointIndex);
	float DiffLen = (DirXY).Length();
	const double StartDist = SplineComp->GetDistanceAlongSplineAtSplinePoint(PointIndex);
	const double NextDist = SplineComp->GetDistanceAlongSplineAtSplinePoint(PointIndex + 1);
	float OriginTime = (NextDist - StartDist) / OriginVelocity;
	SplineMoveMaxVelocity = (DiffLen + (NextDist - StartDist)) / OriginTime;
}


FVector2D URoleMovementComponent::GetDirOfOwnerAndSplineStartPoint(int PointIndex)
{
	check(SplineActor.IsValid());
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	FVector2D SplineStartLoc = FVector2D(SplineComp->GetLocationAtSplinePoint(PointIndex, ESplineCoordinateSpace::Type::World));
	ACharacter* Character = this->GetCharacterOwner();
	if (!Character) return FVector2D::ZeroVector;
	
	FVector2D CharacterLoc = FVector2D(Character->GetActorLocation());

	FVector2D DirXY = SplineStartLoc - CharacterLoc;
	return DirXY;
}

bool URoleMovementComponent::GetDialogueAnimStageAnimLength(float& StartLength, float& LoopLength, float& EndLength)
{
	if (CycleMotionMoveAnimName.Num() !=  CM_END_INDEX + 1)
	{
		return false;
	}

	UBaseAnimInstance * AnimInst = GetRealMovementViewProxy()->GetAnimInstanceForMovement();
	if(!AnimInst){
		return false;
	}

	float DistanceOut = 0.f;
	float YawDiffOut = 0.f;
	AnimInst->GetLocoAnimRootMotionInfo(CycleMotionMoveAnimName[CM_START_INDEX], 0, -1, StartLength, DistanceOut, YawDiffOut);
	AnimInst->GetLocoAnimRootMotionInfo(CycleMotionMoveAnimName[CM_LOOP_INDEX], 0, -1, LoopLength, DistanceOut, YawDiffOut);
	AnimInst->GetLocoAnimRootMotionInfo(CycleMotionMoveAnimName[CM_END_INDEX], 0, -1, EndLength, DistanceOut, YawDiffOut);
	return true;
}

void URoleMovementComponent::SplineMoveSkipToByTime(float MoveTime)
{
	USplineComponent* SplineComp = SplineActor.IsValid() ? SplineActor->GetComponentByClass<USplineComponent>() : nullptr;
	if (!SplineComp)
	{
		UE_LOG(LogTemp, Warning, TEXT("URoleMovementComponent::SplineMoveSkipToByTime	SplineActor = nullptr or SplineComp = nullptr"))
		return;
	}
	UBaseAnimInstance* AnimInst = GetRealMovementViewProxy()->GetAnimInstanceForMovement();
	if(!AnimInst){
		return;
	}
	
	if(CycleMotionMovePhaseData.Num() != CM_END_INDEX + 1)
	{
		return;
	}
	
	float MoveDistance = 0.f;
	if (MoveTime >= SplineMoveTotalTime)
	{
		SplineMoveAccuTime = SplineMoveTotalTime;
		MoveDistance = SplineComp->GetSplineLength();
		CurrentCycleMotionIndex = CM_END_INDEX;
		
		// 如果是剧情模式下移动,需要动作严格对齐的话,额外处理动画跳转 & 到达终点
		if (bFrameCheckDialogue)
		{
			AnimInst->DialogueCrossfadeToStage(EDialogueStage::Idle, true);	
		}
	}
	else
	{
		SplineMoveAccuTime = MoveTime;
		// 如果是剧情模式下移动,需要动作严格对齐的话,额外处理动画跳转
		if (bFrameCheckDialogue)
		{
			float StartAnimLength = 0.f, LoopAnimLength = 0.f, EndAnimLength = 0.f;
			bool bValidAnimLength = GetDialogueAnimStageAnimLength(StartAnimLength, LoopAnimLength, EndAnimLength);
			if (!bValidAnimLength) return;

			float StartTime = 0.f;
			float StartToLoopTime = AnimInst->GetSequenceStartToLoopStartTime();
			float LoopToEndStartTime = AnimInst->GetSequenceLoopToEndStartTime();
			
			// 曲线内
			const auto & StartMoveData = CycleMotionMovePhaseData[CM_START_INDEX];
			const auto& LoopMoveData = CycleMotionMovePhaseData[CM_LOOP_INDEX];
			if (SplineMoveAccuTime <= StartMoveData.X)
			{
				// 跳转到起步阶段
				if (StartAnimLength > 0)
				{
					StartTime = SplineMoveAccuTime;
					AnimInst->DialogueUpdateStagePercent(EDialogueStage::MoveStart, SplineMoveAccuTime / StartAnimLength);	
				}
			}
			else if (SplineMoveAccuTime <= StartMoveData.X + LoopMoveData.X)
			{
				// 跳转到循环阶段
				if (LoopAnimLength > 0)
				{
					float LeftTime = SplineMoveAccuTime - StartMoveData.X - StartToLoopTime;
					int IntegerPart = FMath::Floor(LeftTime / LoopAnimLength);
					StartToLoopTime = LeftTime - IntegerPart * LoopAnimLength;
					AnimInst->DialogueUpdateStagePercent(EDialogueStage::MoveLoop, StartToLoopTime / LoopAnimLength);
				}
			}
			else
			{
				// 跳转到停步阶段
				if (EndAnimLength > 0)
				{
					float LeftTime = SplineMoveAccuTime - StartMoveData.X - LoopMoveData.X;
					LoopToEndStartTime = LoopToEndStartTime + LeftTime;
					AnimInst->DialogueUpdateStagePercent(EDialogueStage::MoveEnd, LoopToEndStartTime / EndAnimLength);
				}
			}
			AnimInst->UpdateSequenceStartTime(StartTime, StartToLoopTime, LoopToEndStartTime);
		}
		
		MoveDistance = bFrameCheckDialogue ? DialogueGetDistanceOnMoveSplineByTime(SplineMoveAccuTime, CurrentCycleMotionIndex, true) : GetDistanceOnMoveSplineByTime(SplineMoveAccuTime, CurrentCycleMotionIndex);
	}
	this->SplineMoveDistance = MoveDistance;
	SplineMoveAccuTime = FMath::Min(SplineMoveTotalTime, MoveTime);
	FTransform NextSplineTrans = SplineComp->GetTransformAtDistanceAlongSpline(MoveDistance, ESplineCoordinateSpace::Type::World, true);
	// 目标位置
	FVector CaptureLocation = TraceGroundCaptureLocation(NextSplineTrans.GetLocation());
	// 目标朝向
	FRotator DestRotation = GetRealMovementViewProxy()->GetActorRideModeTransform().Rotator();
	DestRotation.Pitch = 0.f;
	DestRotation.Roll = 0.f;
	float DistanceCheck = 1.f;
	if (MoveDistance >= DistanceCheck)
	{
		FTransform LastTrans = SplineComp->GetTransformAtDistanceAlongSpline(MoveDistance - DistanceCheck, ESplineCoordinateSpace::Type::World, true);
		DestRotation.Yaw = UKismetMathLibrary::FindLookAtRotation(LastTrans.GetLocation(), NextSplineTrans.GetLocation()).Yaw;
	}
	
	GetRealMovementViewProxy()->TeleportTo(CaptureLocation, DestRotation);
}

void URoleMovementComponent::TickSplineMove(float DeltaTime)
{
	if (SplineController.HasSplineControllWorking())
	{
		const bool bControlFinished = SplineController.TickSplineMove(*this, DeltaTime);
		if (bControlFinished)
		{
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner))
			{
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_SplineControllerFinished");
			}	
		}
		return;
	}
	
	if (this->bPauseSplineMove)
	{
		return;
	}
	if (!SplineActor.IsValid())
	{
		return;
	}

	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if (!SplineComp)
	{
		return;
	}

	if(SplineMoveProgressMode == ESplineMoveProgressMode::ProgressByTime || SplineMoveProgressMode == ESplineMoveProgressMode::ProgressByCycleMotion )
	{
		if (CheckCanSplineMoveStopInAdvance())
		{
			return;
		}

		// 结束要在上一次位移计时、位移运动生效后才能处理
		if(SplineMoveAccuTime >= SplineMoveTotalTime)
		{
			StopMoveWithSpline();
			return;
		}
		
		SplineMoveAccuTime += DeltaTime;
		float NextDistance = bFrameCheckDialogue ? DialogueGetDistanceOnMoveSplineByTime(SplineMoveAccuTime, CurrentCycleMotionIndex) : GetDistanceOnMoveSplineByTime(SplineMoveAccuTime, CurrentCycleMotionIndex);
		
		this->SplineMoveDistance = NextDistance;
		FTransform NextSplineTrans = SplineComp->GetTransformAtDistanceAlongSpline(	NextDistance, ESplineCoordinateSpace::Type::World, true);
		RoleMP.PositionAdditiveITMC.SetUsingForSplineMove(true, NextSplineTrans);
		URoleMovementComponent *RealMoveProxy = GetRealMovementViewProxy();
		FVector CurXYVel = RealMoveProxy->GetMovementVelocity();
		CurXYVel.Z = 0;
		FQuat CurRotation = NextSplineTrans.GetRotation();
		if(CurXYVel.Length() > 0.0)
		{
			CurRotation = CurXYVel.ToOrientationQuat();
		}

		if(!OnlyUsingXYMove)
		{
			RequestMoveWithVelocityToSetAbsolutePosAndUseYawController(NextSplineTrans.GetTranslation(), CurRotation);
		}
		else
		{
			FVector MoveDelta = NextSplineTrans.GetTranslation() - RealMoveProxy->GetLocation();
			MoveDelta.Z = 0;
			RequestMoveWithVelocityToPosDeltaAndUseYawController(MoveDelta, CurRotation);
		}
		
		if(CurrentCycleMotionIndex == CM_END_INDEX)
		{
			SetForceLocoStartToFalse();
		}

		return;
	}
	
	if (!bHasReachSplineStartPoint and SplineMoveStartIndex >= 0)
	{
		FVector2D DirXY = GetDirOfOwnerAndSplineStartPoint(SplineMoveStartIndex);
		float DiffLen = DirXY.Length();
		if (DiffLen > MovementConst::SPLINE_START_LOC_AND_OWNER_LOC_THRESHOLD)
		{
			FVector Dir(DirXY.X, DirXY.Y, 0.0f);
			Dir.Normalize();
			if (SplineMoveMaxVelocity * DeltaTime > DiffLen)
			{
				RequestMoveWithVelocityToPosDeltaAndUseYawController(Dir * DiffLen, Dir.ToOrientationRotator().Quaternion());
				bHasReachSplineStartPoint = true;
			}
			else
			{
				RequestMoveWithVelocityToPosDeltaAndUseYawController(Dir * SplineMoveMaxVelocity * DeltaTime, Dir.ToOrientationRotator().Quaternion());
			}
			return;
		}
	}
	bHasReachSplineStartPoint = true;


	// 刹停终止
	if (BarkStopToken.IsSet())
	{
		FVector ActorLoc = GetActorLocation();
		FVector LastPoint = SplineComp->GetLocationAtSplinePoint(SplineComp->GetNumberOfSplinePoints() - 1, ESplineCoordinateSpace::Type::World);
		if (FMath::IsNearlyEqual(ActorLoc.X, LastPoint.X, 1) && FMath::IsNearlyEqual(ActorLoc.Y, LastPoint.Y, 1))
		{
			StopMoveWithSpline();
		}
	}
	else
	{
		// 曲线移动正常停止
		if ((SplineMoveDirectionMode == ESplineMoveDirectionMode::Forward && SplineComp->GetSplineLength() <= this->SplineMoveDistance) || 
			(SplineMoveDirectionMode == ESplineMoveDirectionMode::Backward && this->SplineMoveDistance <= 0))
		{
			//StopMoveWithSpline();
			ProcessWhenReachEndPoint(SplineComp->GetSplineLength());
			return;
		}
		FTransform CurSplineTrans = SplineComp->GetTransformAtDistanceAlongSpline(this->SplineMoveDistance, ESplineCoordinateSpace::Type::World, true);
		if (!bhasResetSplineMoveMaxVelocity and SplineMoveStartIndex >= 0 and this->SplineMoveDistance >= SplineComp->GetDistanceAlongSplineAtSplinePoint(SplineMoveStartIndex + 1))
		{
			SplineMoveMaxVelocity = OriginVelocity;
			bhasResetSplineMoveMaxVelocity = true;
		}

		// 误差调整
		if (bNeedAdjustPos and abs(SplineMoveDistance - SplineComp->GetDistanceAlongSplineAtSplinePoint(AdjustPosPointIndex)) > MovementConst::SPLINE_ADJUST_POS_DIFF_THRESHOLD)
		{
			float RealDur = (SplineComp->GetSplineLength() - SplineComp->GetDistanceAlongSplineAtSplinePoint(AdjustPosPointIndex)) / OriginVelocity;
			SplineMoveMaxVelocity = (SplineComp->GetSplineLength() - SplineMoveDistance) / RealDur;

		}
		bNeedAdjustPos = false;

		// 起步加速处理
		UpdateCurSplineMoveVelocity(SplineComp, DeltaTime);

		CalcSplineMoveDistance(DeltaTime);
		FTransform TargetTrans = SplineComp->GetTransformAtDistanceAlongSpline(this->SplineMoveDistance, ESplineCoordinateSpace::Type::World, true);


		FVector VelDir = (TargetTrans.GetLocation() - CurSplineTrans.GetLocation());
		RequestMoveWithVelocityToPosDeltaAndUseYawController(VelDir, VelDir.GetSafeNormal().ToOrientationRotator().Quaternion());

	}
}

bool URoleMovementComponent::CheckCanSplineMoveStopInAdvance()
{
	// 没有提前结束需求，不提前打断
	if (!bNeedSplineMoveStopInAdvance) 
	{
		return false;
	}

	// 到达提前结束时间，执行提前打断
	if (MaxSplineMoveStopInAdvanceTime > 0.0f && MaxSplineMoveStopInAdvanceTime >= (SplineMoveTotalTime - SplineMoveAccuTime))
	{
		StopMoveWithSpline();
		return true;
	}

	if (MaxSplineMoveStopInAdvanceDist < 0.0f) {
		return false;
	}

	if (!SplineActor.IsValid())
	{
		return false;
	}
	USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
	if (!SplineComp)
	{
		return false;
	}
	
	URoleMovementComponent* RealMoveProxy = GetRealMovementViewProxy();
	FVector DeltaLoc = RealMoveProxy->GetLocation() - SplineComp->GetLocationAtDistanceAlongSpline(SplineComp->GetSplineLength(), ESplineCoordinateSpace::World);
	// 与终点的水平距离到达提前结束距离，且高度相差不是太大时，提前打断
	if (FMath::Abs(DeltaLoc.Z) < 300.0f && DeltaLoc.Size2D() < MaxSplineMoveStopInAdvanceDist)
	{
		StopMoveWithSpline();
		return true;
	}

	return false;
}

void URoleMovementComponent::AdjustPosWhenSplineMove(int PointIndex)
{
	// 目前在脚本控制了只有循环模式的曲线移动才做修复
	bNeedAdjustPos = true;
	AdjustPosPointIndex = PointIndex;
}

void URoleMovementComponent::ProcessWhenReachEndPoint(float SplineLength)
{
	switch (this->SplineMoveMode)
	{
	case ESplineMoveMode::Single:
		StopMoveWithSpline();
		break;
	case ESplineMoveMode::Backtrack:
		StopMoveWithSpline();
		break;
	case ESplineMoveMode::Cycle:
		this->SplineMoveDistance = SplineMoveDistance - SplineLength;
		break;
	case ESplineMoveMode::BackOnce:
		if (SplineMoveDirectionMode != OriSplineMoveDirectionMode)
		{
			StopMoveWithSpline();
			break;
		}
		if (SplineMoveDirectionMode == ESplineMoveDirectionMode::Forward)
		{
			this->SplineMoveDistance = SplineLength;
			SplineMoveDirectionMode = ESplineMoveDirectionMode::Backward;
		}
		else if (SplineMoveDirectionMode == ESplineMoveDirectionMode::Backward)
		{
			this->SplineMoveDistance = 0;
			SplineMoveDirectionMode = ESplineMoveDirectionMode::Forward;
		}
		break;
	default:
		break;
	}
}

void URoleMovementComponent::CalcSplineMoveDistance(float DeltaTime)
{
	if (SplineMoveDirectionMode == ESplineMoveDirectionMode::Forward)
	{
		this->SplineMoveDistance += SplineMoveCurVelocity * DeltaTime;
	}
	else if (SplineMoveDirectionMode == ESplineMoveDirectionMode::Backward)
	{
		this->SplineMoveDistance -= SplineMoveCurVelocity * DeltaTime;
	}

}

FVector URoleMovementComponent::TraceGroundCaptureLocation(FVector Position)
{
	if (!CharacterOwner) return Position;
	
	TArray<AActor*> ActorsToIgnore;
	FHitResult HitResult;
	bool bHit = UKismetSystemLibrary::LineTraceSingle(this, Position + FVector::UpVector * 20, Position + FVector::DownVector * 200, ETraceTypeQuery::TraceTypeQuery1, true, ActorsToIgnore, EDrawDebugTrace::None, HitResult, true);
	if (bHit)
	{
		if (UCapsuleComponent* CapsuleComponent = CharacterOwner->GetCapsuleComponent())
		{
			Position.Z = HitResult.Location.Z + CapsuleComponent->GetScaledCapsuleHalfHeight();
		}
	}

	return Position;
}

void URoleMovementComponent::StopMoveWithSpline()
{
	if (!this->bAllowMoveWithSpline)
	{
		return;
	}
	ClearForceLocoStart();
	this->bAllowMoveWithSpline = false;
	this->bPauseSplineMove = false;
	this->SplineMoveStartIndex = -1;
	this->bRequestedMoveUseAcceleration = true;
	this->bJustUseRequestedVel = false;
	bFrameCheckDialogue = false;

	// 场景摧毁的时候, 可能这个SplineActor会被先干掉
	if(this->SplineActor.IsValid())
	{
		UWorld* CW = this->SplineActor->GetWorld();
		if (CW)
		{
			CW->DestroyActor(this->SplineActor.Get());
		}
	}
	
	if (BarkStopToken.IsSet())
	{
		ReleaseMoveCorrector(BarkStopToken.GetValue(), EMovementCorrectorType::DestSmoothCorrector);
		BarkStopToken.Reset();
	}

	ClearSplineActor();
	if (ABaseCharacter* Character = GetCharacterOwnerForRuntimeOrEditor())
	{
		ACTOR_CALL_LUA_ENTITY(Character, "KCB_OnSplineMoveFinished");
	}
}


void URoleMovementComponent::SetContinuousCustomInput(const FVector& CustomInput, ECustomInputType InputType)
{
	this->ExternalCustomInput = CustomInput;
	this->bHasCustomInput = true;
	this->CustomInputType = InputType;
}

void URoleMovementComponent::ClearContinuousCustomInput()
{
	this->bHasCustomInput = false;
	this->CustomInputType = ECustomInputType::NoInput;
}

KGObjectID URoleMovementComponent::CreatePCGSplineComponentForVehiclePath(uint32 PathID, const FVector& Location, const FRotator& Rotation, bool bClosedLoop)
{
	if (UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(this))
	{
		if (FVehicleWayPathData* VehicleWayPathData = DataCacheManager->GetVehicleWayPathData(PathID))
		{
			const int32 PointNum = VehicleWayPathData->PathPoints.Num();
			if (PointNum < 2)
			{
				UE_LOG(LogRoleMovement, Error, TEXT("URoleMovementComponent::CreatePCGSplineComponentForVehiclePath found path data[:%d] invalid point number"), PathID);
				return KG_INVALID_ID;
			}
			
			if (UActorComponent* ActorComponent = GetOwner()->AddComponentByClass(UPCGSplineComponent::StaticClass(), false, FTransform(), false))
			{
				if (UPCGSplineComponent* SplineComponent = Cast<UPCGSplineComponent>(ActorComponent))
				{
					SplineComponent->ClearSplinePoints(false);
					SplineComponent->SetClosedLoop(bClosedLoop);
					SplineComponent->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
					SplineComponent->SetWorldTransform(FTransform(Rotation, Location));
#if WITH_EDITOR
					GetOwner()->AddInstanceComponent(SplineComponent);
#endif
					const auto& VehiclePoints = VehicleWayPathData->PathPoints;
					std::vector<SplineInterpolator::PointAttr> PointsAttr;
					PointsAttr.reserve(VehiclePoints.Num());
					for (int32 PointIndex=0; PointIndex<PointNum; PointIndex++)
					{
						const auto& VehiclePoint = VehiclePoints[PointIndex];
						auto SplinePoint = FSplinePoint(
							VehiclePoint.InputKey,
							VehiclePoint.Position,
							VehiclePoint.ArriveTangent,
							VehiclePoint.LeaveTangent,
							VehiclePoint.Rotation,
							FVector(1.0f),
							ConvertInterpCurveModeToSplinePointType(EInterpCurveMode(VehiclePoint.PointType))
							);
						SplineComponent->AddPoint(SplinePoint, PointIndex==PointNum-1);
						
						PointsAttr.emplace_back(
							SplineInterpolator::PointAttr{
								VehiclePoint.IsStop,
								VehiclePoint.InStopDistance,
								VehiclePoint.OutStopDistance,
								VehiclePoint.StopTime
							}
						);
					}
					MovementSimulator.AddFixedPathBySpawnedSpline(PathID, SplineComponent, PointsAttr);
					return KGUtils::GetIDByObject(SplineComponent);
				}
			}
		}
		else
		{
			UE_LOG(LogRoleMovement, Error, TEXT("URoleMovementComponent::CreatePCGSplineComponentForVehiclePath get path data:%d, failed"), PathID);
		}
	}

	return KG_INVALID_ID;
}

#if UE_BUILD_DEVELOPMENT
void URoleMovementComponent::AppendDebugInfo(FString& infoOut) {
	infoOut.Append(TEXT("===================<Title_Blue>URoleMovementComponent</>===================\n"));
	infoOut.Appendf(TEXT("MovementMode: %d  LogicMovePosture:%d\n"), (int)MovementMode, LogicMovePosture);
	infoOut.Appendf(TEXT("UsingLateUpdate:%d WeakValue:%s ForceValue:%d, ForceTag:%s\n"), UsingLateUpdate, *GetArrayReasonInfo(UsingLateUpdateCountArray),
		UsingLateUpdateForceValue.IsSet() ? UsingLateUpdateForceValue.GetValue() : -1,
		UsingLateUpdateForceValueTag.IsSet() ? *UsingLateUpdateForceValueTag.GetValue() : TEXT("Null"));
	infoOut.Appendf(TEXT("MoveDriveMode:%d WeakValue:%d WeakTag:%s ForceValue:%d, ForceTag:%s\n"), GetMoveDriveMode(), MoveDriveModeWeakValue, *MoveDriveModeWeakTag,
		MoveDriveModeForceValue.IsSet() ? (int)MoveDriveModeForceValue.GetValue() : -1,
		MoveDriveModeForceValueTag.IsSet() ? *MoveDriveModeForceValueTag.GetValue() : TEXT("Null"));
	infoOut.Appendf(TEXT("MoveSyncRole:%d  CurrentNetSimulateStatus:%d IsNeedSyncUpMovement:%d   NeedNotifyLocoStartChanged:%d  NeedNotifyLocoStateChanged:%d   NeedNotifyLocoInputZoneChanged:%d\n"),
		eMoveSyncRole, GetCurrentIsNetSimulate(), IsNeedSyncUpMovement, NeedNotifyLocoStartChanged, NeedNotifyLocoStateChanged, NeedNotifyLocoInputZoneChanged);
	infoOut.Appendf(TEXT("ClientMoveSyncMode:%d  RelativeTargetObjectID:%lld \n"),
		ClientMoveSyncMode, ClientMoveDataRelativeTarget.IsValid()? ClientMoveDataRelativeTarget.KGGetObjectID():0);

	infoOut.Appendf(TEXT("NeedNotifyLocoStateEnterOrLeaveDefault:%d   DefaultLocoState:%d   bInDefaultLocoState:%d\n"),
		NeedNotifyLocoStateEnterOrLeaveDefault, DefaultLocoState, bInDefaultLocoState);

	infoOut.Appendf(TEXT("GetAutoUpdatePostureAndPlayRate:%d, WeakValue:%s; ForceValue:%d, ForceTag:%s\n"),
		GetAutoUpdatePostureAndPlayRate(), *GetArrayReasonInfo(AutoUpdatePostureWeakValueCountArray), AutoUpdatePostureForceValue.IsSet() ? AutoUpdatePostureForceValue.GetValue() : -1,
		AutoUpdatePostureForceValueTag.IsSet() ? *AutoUpdatePostureForceValueTag.GetValue() : TEXT("Null"));

	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		infoOut.Appendf(TEXT("RootmotionMode:%d WeakValue:%d WeakTag:%s ForceValue:%d, ForceTag:%s\n"), int(AnimInstance->RootMotionMode), int(RootmotionModeWeakValue), *RootmotionModeWeakTag,
			RootmotionModeForceValue.IsSet() ? int(RootmotionModeForceValue.GetValue()) : -1,
			RootmotionModeForceValueTag.IsSet() ? *RootmotionModeForceValueTag.GetValue() : TEXT("Null"));
	}

	infoOut.Appendf(TEXT("LocoInputThruster:%d WeakValue:%d WeakTag:%s ForceValue:%d, ForceTag:%s\n"), GetInputThrusterIsSwitchedOn(), LocoInputThrusterWeakValue, *LocoInputThrusterWeakTag,
		LocoInputThrusterForceValue.IsSet() ? int(LocoInputThrusterForceValue.GetValue()) : -1,
		LocoInputThrusterForceValueTag.IsSet() ? *LocoInputThrusterForceValueTag.GetValue() : TEXT("Null"));

	infoOut.Appendf(TEXT("bNeedFrameStickGround:%d WeakValue:%s ForceValue:%d, ForceTag:%s\n"), bNeedFrameStickGround, *GetArrayReasonInfo(NeedFrameStickGroundCountArray),
		NeedFrameStickGroundForceValue.IsSet() ? NeedFrameStickGroundForceValue.GetValue() : -1,
		NeedFrameStickGroundForceValueTag.IsSet() ? *NeedFrameStickGroundForceValueTag.GetValue() : TEXT("Null"));

	infoOut.Appendf(TEXT("IsGravityOn:%d  GravityZ:%f GravityScale:%f  GravityVelocity:%s\n"), IsGravityOn, GetGravityZ(), GravityScale, *(GravityVelocity.ToString()));
	infoOut.Appendf(TEXT("GravityOnWeakValue:%s GravityCount:%i  GravityOnForceValue:%d, GravityOnForceTag:%s\n"), *GetMapReasonInfo(IsGravityOnCountMap), _GravityOnCountValue,
		IsGravityOnForceValue.IsSet() ? IsGravityOnForceValue.GetValue() : -1,
		IsGravityOnForceValueTag.IsSet() ? *IsGravityOnForceValueTag.GetValue() : TEXT("Null"));

	infoOut.Appendf(TEXT("requestedVelocity:%s HasRawLocoInput:%d  RawLocoInput:%s\n"),
		*(RequestedVelocity.ToString()), HasRawLocoInput, *(RawInputMoveVector.ToString()));

	infoOut.Appendf(TEXT("LocoInputSemantic:%d LocoInputModifyMode:%d   LocoInput:%s \n"),
		LocoInputSemantic, LocoInputModifyMode, *(LocoInputVector.ToString()));

	infoOut.Appendf(TEXT("bNeedBornStickGround:%d  bNeedServerFixPosition:%d IsIgnorePhysFixup:%d  \n"), bNeedBornStickGround,  bNeedServerFixPosition, IsIgnorePhysFixup);

	infoOut.Appendf(TEXT("bForceLocoStart:%d IsLocoStart:%d  LocoStateFromMask:%d  LocalLocoState:%d  LocoStateDataSource:%d \n"),
		GetForceLocoStart(), GetIsLocoStartFromMask(), GetLocomotionStateFromMask(), GetLocalLocomotionState(), LocoStateDataSource);

	infoOut.Appendf(TEXT("DisableRootMotionTypes:%d \n"), (GetDisableRootMotionTypes().Num()));

	infoOut.Appendf(TEXT("<Red>bEnableLocoContol</>:%d\n"), bEnableLocoContol);
	infoOut.Appendf(TEXT("<Red>DisableMovement</>:%d WeakValue:%s ForceValue:%d, ForceTag:%s\n"), bDisableMovement, *GetMapReasonInfo(IsDisableMoveAllCountMap),
		IsDisableMoveAllForceValue.IsSet() ? IsDisableMoveAllForceValue.GetValue() : -1,
		IsDisableMoveAllForceValueTag.IsSet() ? *IsDisableMoveAllForceValueTag.GetValue() : TEXT("Null"));
	infoOut.Appendf(TEXT("<Red>DisableLocoMove</>:%d WeakValue:%s ForceValue:%d, ForceTag:%s\n"), bDisableProactiveMovement, *GetMapReasonInfo(IsDisableLocoMoveCountMap),
		IsDisableLocoMoveForceValue.IsSet() ? IsDisableLocoMoveForceValue.GetValue() : -1,
		IsDisableLocoMoveForceValueTag.IsSet() ? *IsDisableLocoMoveForceValueTag.GetValue() : TEXT("Null"));
	infoOut.Appendf(TEXT("<Red>AllowLocoStart</>:%d WeakValue:%s ForceValue:%d, ForceTag:%s\n"), AllowLocoStart, *GetMapReasonInfo(IsDisableLocoStartCountMap),
		IsDisableLocoStartForceValue.IsSet() ? IsDisableLocoStartForceValue.GetValue() : -1,
		IsDisableLocoStartForceValueTag.IsSet() ? *IsDisableLocoStartForceValueTag.GetValue() : TEXT("Null"));
	infoOut.Appendf(TEXT("<Red>DisableRotation</>:%d WeakValue:%s ForceValue:%d, ForceTag:%s\n"), bDisableRotation, *GetMapReasonInfo(IsDisableRotateAllCountMap),
		IsDisableRotateAllForceValue.IsSet() ? IsDisableRotateAllForceValue.GetValue() : -1,
		IsDisableRotateAllForceValueTag.IsSet() ? *IsDisableRotateAllForceValueTag.GetValue() : TEXT("Null"));
	infoOut.Appendf(TEXT("<Red>DisableLocoRotation</>:%d WeakValue:%s ForceValue:%d, ForceTag:%s\n"), bDisableProactiveRotation, *GetMapReasonInfo(IsDisableLocoRotateCountMap),
		IsDisableLocoRotateForceValue.IsSet() ? IsDisableLocoRotateForceValue.GetValue() : -1,
		IsDisableLocoRotateForceValueTag.IsSet() ? *IsDisableLocoRotateForceValueTag.GetValue() : TEXT("Null"));
	infoOut.Appendf(TEXT("<Red>DisableProactiveJump</>:%d WeakValue:%s ForceValue:%d, ForceTag:%s\n"), bDisableProactiveJump, *GetMapReasonInfo(IsDisableLocoJumpCountMap),
		IsDisableLocoJumpForceValue.IsSet() ? IsDisableLocoJumpForceValue.GetValue() : -1,
		IsDisableLocoJumpForceValueTag.IsSet() ? *IsDisableLocoJumpForceValueTag.GetValue() : TEXT("Null"));
	infoOut.Appendf(TEXT("<Red>DisableProactiveDodge</>:%d WeakValue:%s ForceValue:%d, ForceTag:%s\n"), bDisableProactiveDodge, *GetMapReasonInfo(IsDisableLocoDodgeCountMap),
		IsDisableLocoDodgeForceValue.IsSet() ? IsDisableLocoDodgeForceValue.GetValue() : -1,
		IsDisableLocoDodgeForceValueTag.IsSet() ? *IsDisableLocoDodgeForceValueTag.GetValue() : TEXT("Null"));

	infoOut.Appendf(TEXT("WorkingWaterWaveRequestId:%d  \n"), WorkingWaterWaveRequestId);

	FVector curPos = GetActorLocation();
	FRotator curRotator = GetActorTransform().Rotator();
	FVector syncedPos = FVector(-9999.0f, -9999.0f, -9999.0f);
	FRotator syncedRot = FRotator(-99.0f, -99.0f, -99.0f);
	GetSynchronizedPosAndRot(syncedPos, syncedRot);

	infoOut.Appendf(TEXT("ActorPos:%s, ActorRotator:%s, FaceAndDriveDiffRadian:%f\n"), *curPos.ToString(), *curRotator.ToString(), FaceAndDriveDiffRadian);
	infoOut.Appendf(TEXT("OMeshRL:%s, StickGroundMeshRL:%s, AdditionalMeshRL:%s \n"), *OMeshRL.ToCompactString(), *GetStickGroundMeshRL().ToCompactString(), *AdditionalMeshRL.ToCompactString());

	FVector diffPos = syncedPos;
	diffPos.X = abs(syncedPos.X - curPos.X);
	diffPos.Y = abs(syncedPos.Y - curPos.Y);
	diffPos.Z = abs(syncedPos.Z - curPos.Z);

	FRotator diffRot = syncedRot;
	diffRot.Pitch = MathFormula::ClosetYawAbsDiff(syncedRot.Pitch, curRotator.Pitch);
	diffRot.Yaw = MathFormula::ClosetYawAbsDiff(syncedRot.Yaw, curRotator.Yaw);
	diffRot.Roll = MathFormula::ClosetYawAbsDiff(syncedRot.Roll, curRotator.Roll);

	infoOut.Appendf(TEXT("SimulateDeltaThresholdByLod:%2.f, SDTWhenInvisible:%.2f CurrentSDT:%.2f SDAccumulation:%.2f\n"),
		SimulateDeltaThresholdByLod, SimulateDeltaThresholdWhenInvisible, CurrentSimulateDeltaThreshold, SimulateDeltaAccumulation);
	infoOut.Appendf(TEXT("SyncPos:%s, SyncRotator:%s  DIFF Pos : %s, Rotator : %s\n"), *syncedPos.ToString(), *syncedRot.ToString(), *diffPos.ToString(), *diffRot.ToString());

	infoOut.Appendf(TEXT("Veclocity: %s, Value: %.2f  EnableImpetus:%.2f \n"), *Velocity.ToString(), Velocity.Size(), GetEnableImpetus());
	infoOut.Appendf(TEXT("MaxAcceleration: %.2f, MaxBrakingDeceleration: %.2f\n"), GetMaxAcceleration(), GetMaxBrakingDeceleration());

	infoOut.Appendf(TEXT("LocalWindSwitch: %d \n"), LocalWindSwitch);
	infoOut.Appendf(TEXT("DynamicWaterWaveLocomotionSwitch: %d \n"), DynamicWaterWaveLocomotionSwitch);
	
	infoOut.Appendf(TEXT("bHasGroundSupport: %d, bLastMCHasForceGroundSupport:%d, ForceGroundSupportInfo:%s\n"), bHasGroundSupport, bLastMCHasForceGroundSupport, *GetMapReasonInfo(ForceGroundSupportReason));
	infoOut.Appendf(TEXT("ForceIgnoreGroundSupportReason:%s\n"), *GetMapReasonInfo(ForceIgnoreGroundSupportReason));
	infoOut.Appendf(TEXT("bHasLocoGroundSupport: %d, bLastMCHasLocoForceGroundSupport:%d, LocoForceGroundSupportInfo:%s\n"), bHasLocoGroundSupport, bLastMCHasForceLocoGroundSupport, *GetMapReasonInfo(ForceLocoGroundSupportReason));
	infoOut.Appendf(TEXT("LocoForceIgnoreGroundSupportInfo:%s\n"), *GetMapReasonInfo(ForceIgnoreLocoGroundSupportReason));

	if (CurrentFloor.bWalkableFloor)
	{
		infoOut.Appendf(TEXT("FloorNormal:%s,  FloorSlopeAngle:%f\n"), *CurrentFloor.HitResult.ImpactNormal.ToString(), FMath::Acos(CurrentFloor.HitResult.ImpactNormal.Z) * 180 / PI);
	}
	else
	{
		infoOut.Appendf(TEXT("No Walkable Floor\n"));
	}
	infoOut.Appendf(TEXT("ExpectVelocity:%s,  ExpectSpeed:%f,  LastExpectVelocityInAir:%s, LastExpectSpeedInAir:%f\n"), *ExpectVelocity.ToString(), ExpectVelocity.Size(), *LastExpectVelocityInAir.ToString(), LastExpectVelocityInAir.Size());

	const float CurtAutoUpdatePostureSpeed = GetAutoUpdatePostureSpeed();
	SpeedStateIdx = GetSpeedStateIndex(CurtAutoUpdatePostureSpeed);
	if (SpeedStateIdx >= 0 && SpeedStateIdx < SpeedStages.Num() && SpeedStateIdx < SpeedStagesToMovePosture.Num())
	{
		infoOut.Appendf(TEXT("CurAutoUpdatePostureSpeed:%.3f,  SpeedStateIdx:%d,  SpeedStageTheshold:%.3f   AnimMovePosture:%d\n"), CurtAutoUpdatePostureSpeed, SpeedStateIdx, SpeedStages[SpeedStateIdx], SpeedStagesToMovePosture[SpeedStateIdx]);
	}	
	
	bool bCurRootMotionIsValid = CurRootMotionContext.CurRootMotion.IsValid();
	if (bCurRootMotionIsValid)
	{
		TSharedPtr<FC7RootMotionBase> CRM = CurRootMotionContext.CurRootMotion;
		infoOut.Appendf(TEXT("CurRootMotionIsValid true, RM Name %s\n"), *CRM->StaticStruct()->GetName());
		CRM->GetDebugInfo(infoOut);
	}
	else
	{
		infoOut.Appendf(TEXT("No CurRootMotionIsValid\n"));
	}

	infoOut.Appendf(TEXT("IsRunningAnimRootMotion: %d, IsRunningRootMotionSource:%d,  HasAnimRootMotion:%d\n"),
		IsRunningAnimRootMotion(), IsRunningRootMotionSource(), HasAnimRootMotion());

	infoOut.Appendf(TEXT("HasActiveRootMotionSources: %d, HasOverrideVelocity:%d,  HasAdditiveVelocity:%d, OverrideVelocity: %s, AdditiveVelocity: %s\n"),
		CurrentRootMotion.HasActiveRootMotionSources(), CurrentRootMotion.HasOverrideVelocity(), CurrentRootMotion.HasAdditiveVelocity(),
		*OverrideVelocityWorldSpaceRMS.ToString(), *AdditiveVelocityWorldSpaceRMS.ToString());


	
	if(SplineActor.IsValid())
	{
		USplineComponent* SplineComp = SplineActor->GetComponentByClass<USplineComponent>();
		if(SplineComp != nullptr)
		{
			infoOut.Appendf(TEXT("==============================Spline Move Control=======================\n"));
			infoOut.Appendf(TEXT("SplineMoveMode: %d, SplineMoveDirectionMode:%d,  OriSplineMoveDirectionMode:%d  SplineMoveProgressMode:%d  SplineMoveDriveMode:%d\n"),
						SplineMoveMode, SplineMoveDirectionMode, OriSplineMoveDirectionMode, SplineMoveProgressMode, SplineMoveDriveMode);
			
			infoOut.Appendf(TEXT("CycleMotionMoveAnimName Num: %d, CycleMotionMovePhaseData:%d,  CurrentCycleMotionIndex:%d\n"),\
				CycleMotionMoveAnimName.Num(), CycleMotionMovePhaseData.Num(), CurrentCycleMotionIndex);
			
			infoOut.Appendf(TEXT("bAllowMoveWithSpline: %d, bPauseSplineMove:%d,  SplineMoveTotalTime:%.2f  SplineMoveTotalLength:%2.f\n"),
				bAllowMoveWithSpline, bPauseSplineMove, GetSplineMoveDuration(), GetSplineMoveLength());
			infoOut.Appendf(TEXT("SplineMoveDistance: %.2f, SplineMoveAccuTime:%.2f CurrentCycleMotionIndex:%d \n"),
			SplineMoveDistance, SplineMoveAccuTime, CurrentCycleMotionIndex);

			FTransform NextSplineTrans = SplineComp->GetTransformAtDistanceAlongSpline(	SplineMoveDistance, ESplineCoordinateSpace::Type::World, true);
			SplineComp->SetDrawDebug(true);
			DrawDebugPoint(GetWorld(), NextSplineTrans.GetTranslation(), 20, FColor::Red, false, 0.1);
		}
	}
	
	
	RoleMP.AppendDebugInfo(infoOut);

	if (ScenePD.IsValid()) {
		ScenePD->AppendDebugInfo(infoOut);
	}
	if (LocoControlOP.IsValid()) {
		LocoControlOP->AppendDebugInfo(infoOut);
	}

	float PawnRadius = 0.0f, PawnHalfHeight = 0.0f;
	if (UCapsuleComponent* CapsuleRoot = CharacterOwner->GetCapsuleComponent())
	{
		CapsuleRoot->GetScaledCapsuleSize(PawnRadius, PawnHalfHeight);
	}
	if (NeedDoFallingStepOnDetect())
	{
		FVector CurActorLoc = GetActorLocation();
		FVector CurActorForward = CharacterOwner->GetActorForwardVector();
		FVector ExpectedActorLoc = CurActorLoc + CurActorForward * FallingStepOnDetectDistance;
		UKismetSystemLibrary::DrawDebugLine(this, ExpectedActorLoc + FVector(0.0f, 0.0f, MaxFallingStepOnHeight), ExpectedActorLoc + FVector(0.0f, 0.0f, -PawnHalfHeight), FLinearColor::Green, 0.1f, 1.0f);
	}
	if (HasFallingStepOnLocation)
	{
		UKismetSystemLibrary::DrawDebugCapsule(this, DebugFallingStepOnLocation, PawnHalfHeight, PawnRadius, FRotator::ZeroRotator, FLinearColor::Red, 0.1f, 1.0f);
		HasFallingStepOnLocation = false;
	}

	if (RoleMP.LocoInputThrusterMC.GetSpeedAdjustMode() == EInputThrusterAdjustMode::GlideThruster)
	{
		const float GlideThrusterLeftCurSpeed = RoleMP.LocoInputThrusterMC.GlideThrusterLeftCurSpeed;
		const FVector GlideThrusterMainCurVelocity = RoleMP.LocoInputThrusterMC.GlideThrusterMainCurVelocity;
		const float GlideThrusterRightCurSpeed = RoleMP.LocoInputThrusterMC.GlideThrusterRightCurSpeed;
		const FVector CurActorLoc = GetActorLocation();
		const FVector CurActorForward = CharacterOwner->GetActorForwardVector();
		const FVector CurActorRight = CurActorForward.RotateAngleAxis(90.0f, FVector::ZAxisVector);

		UKismetSystemLibrary::DrawDebugLine(this, CurActorLoc, CurActorLoc + GlideThrusterMainCurVelocity, FLinearColor::Green, 0.1f, 1.0f);
		UKismetSystemLibrary::DrawDebugLine(this, CurActorLoc + 50.0f * CurActorRight, CurActorLoc + 50.0f * CurActorRight + CurActorForward * GlideThrusterRightCurSpeed, FLinearColor::Red, 0.1f, 1.0f);
		UKismetSystemLibrary::DrawDebugLine(this, CurActorLoc - 50.0f * CurActorRight, CurActorLoc - 50.0f * CurActorRight + CurActorForward * GlideThrusterLeftCurSpeed, FLinearColor::Red, 0.1f, 1.0f);
	}
}
#endif

void URoleMovementComponent::ClearBasedMovement()
{
	SetBase(nullptr);
}

void URoleMovementComponent::ClearBaseAndCurrentFloor()
{
	SetBase(nullptr);
	CurrentFloor.Clear();
}


#pragma region FallingStepOn

void URoleMovementComponent::DoFallingStepOnDetect(float InDeltaTime)
{
	if (GetCurGroundDist() < MaxFallingStepOnHeight)
	{
		return;
	}

	FVector CurActorLoc = GetActorLocation();
	FVector CurActorForward = CharacterOwner->GetActorForwardVector();
	FVector ExpectedActorLoc = CurActorLoc + CurActorForward * FallingStepOnDetectDistance;

	FCollisionResponseTemplate CollisionProfile;
	if (!UCollisionProfile::Get()->GetProfileTemplate(GetTrackFloorCollisionPresetName(), CollisionProfile))
	{
		UCollisionProfile::Get()->GetProfileTemplate(TEXT("Pawn"), CollisionProfile);
	}
	FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(FallingStepOn), false, CharacterOwner);
	QueryParams.bIgnoreTouches = true;
	FCollisionResponseParams CollisionResponseParams = CollisionProfile.ResponseToChannels;
	const ECollisionChannel CollisionChannel = CollisionProfile.ObjectType;

	float PawnRadius = 0.0f, PawnHalfHeight = 0.0f;
	if (UCapsuleComponent* CapsuleRoot = CharacterOwner->GetCapsuleComponent())
	{
		CapsuleRoot->GetScaledCapsuleSize(PawnRadius, PawnHalfHeight);
	}
	FCollisionShape CollisionShape = FCollisionShape::MakeCapsule(PawnRadius, PawnHalfHeight);

	FHitResult HitResult;
	if (GetWorld()->LineTraceSingleByChannel(HitResult, ExpectedActorLoc + FVector(0.0f, 0.0f, MaxFallingStepOnHeight), ExpectedActorLoc + FVector(0.0f, 0.0f, -PawnHalfHeight), CollisionChannel, QueryParams, CollisionResponseParams))
	{
		if (IsWalkable(HitResult))
		{
			if (GetWorld()->SweepSingleByChannel(HitResult, HitResult.ImpactPoint + FVector(0.0f, 0.0f, PawnHalfHeight + 10.0f), HitResult.ImpactPoint + FVector(0.0f, 0.0f, PawnHalfHeight - 1.0f), FQuat::Identity, CollisionChannel, CollisionShape, QueryParams, CollisionResponseParams))
			{
				TryExecuteStepOn(HitResult);
			}
		}
	}
}

bool URoleMovementComponent::TryFindStepOnLoc(const FVector& InImpactLoc, FHitResult& OutHitRes, const float* SpecificCapsuleRadius, const float* SpecificCapsuleHalfHeight)
{
	FCollisionResponseTemplate CollisionProfile;
	if (!UCollisionProfile::Get()->GetProfileTemplate(GetTrackFloorCollisionPresetName(), CollisionProfile))
	{
		UCollisionProfile::Get()->GetProfileTemplate(TEXT("Pawn"), CollisionProfile);
	}
	FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(FallingStepOn), false, CharacterOwner);
	QueryParams.bIgnoreTouches = true;
	FCollisionResponseParams CollisionResponseParams = CollisionProfile.ResponseToChannels;
	const ECollisionChannel CollisionChannel = CollisionProfile.ObjectType;

	float PawnRadius = 0.0f, PawnHalfHeight = 0.0f;
	if (UCapsuleComponent* CapsuleRoot = CharacterOwner->GetCapsuleComponent())
	{
		CapsuleRoot->GetScaledCapsuleSize(PawnRadius, PawnHalfHeight);
	}
	PawnRadius = SpecificCapsuleRadius ? *SpecificCapsuleRadius : PawnRadius;
	PawnHalfHeight = SpecificCapsuleHalfHeight ? *SpecificCapsuleHalfHeight : PawnHalfHeight;
	FCollisionShape CollisionShape = FCollisionShape::MakeCapsule(PawnRadius, PawnHalfHeight);

	// 起始的检查位置，需要多加一个PawnRadius，避免卡在斜面里
	if (GetWorld()->SweepSingleByChannel(OutHitRes, InImpactLoc + FVector(0.0f, 0.0f, PawnRadius + PawnHalfHeight + 10.0f), InImpactLoc + FVector(0.0f, 0.0f, PawnHalfHeight - 1.0f), FQuat::Identity, CollisionChannel, CollisionShape, QueryParams, CollisionResponseParams))
	{
		if (IsWalkable(OutHitRes))
		{
			return true;
		}
	}

	return false;
}

bool URoleMovementComponent::TryExecuteStepOn(const FHitResult& InHitRes)
{
	if (FallingStepOnDestSmoothToken < 0 && IsWalkable(InHitRes))
	{
		FallingStepOnDestSmoothToken = ObtainMoveCorrector(ECorrectorObtainPriority::Action, EMovementCorrectorType::DestSmoothCorrector);
		if (FallingStepOnDestSmoothToken > 0)
		{
			SetDestSmoothCorrectorParam(StepOnTotalDuration, StepOnTotalHalfTime);
			SetDestLocSmoothParam(GetActorLocation(), InHitRes.Location);
			CurStepOnDuration = StepOnTotalDuration;
			CurStepOnCoolDown = StepOnCoolDown;
			SetHasForceLocoGroundSupportWithoutUpdate(TEXT("FallingStepOn"), true);
#if UE_BUILD_DEVELOPMENT
			HasFallingStepOnLocation = true;
			DebugFallingStepOnLocation = InHitRes.Location;
#endif
			return true;
		}
	}

	return false;
}

void URoleMovementComponent::UpdateStepOnDuration(float InDeltaTime)
{
	CurStepOnDuration -= InDeltaTime;
	CurStepOnCoolDown -= InDeltaTime;
	if (FallingStepOnDestSmoothToken > 0 && CurStepOnDuration < 0.0f)
	{
		ReleaseMoveCorrector(FallingStepOnDestSmoothToken, EMovementCorrectorType::DestSmoothCorrector);
		FallingStepOnDestSmoothToken = -1;
		SetHasForceLocoGroundSupportWithoutUpdate(TEXT("FallingStepOn"), false);
	}
}

void URoleMovementComponent::UpdateIsFallingStepOnDetecting(EMovementMode InMovementMode)
{
	bIsFallingStepOnDetecting = ((InMovementMode == MOVE_Falling) && bAllowFallingStepOn);
}

#pragma endregion FallingStepOn

void URoleMovementComponent::UpdateRoleMovementStaticData(FString InMainPlayerTrackFloorCollisionPresetName, FString InCommonTrackFloorCollisionPresetName,
	float InLocoGravityScale, float InLocoJumpZVelocity, float InEnterFallingVelocityZ, float InHighJumpEndVelocityZThreshold, float InGravityVelocityZMax,
	float InStickGroundMeshZOffset, float InTotalLocoJumpForceIgnoreGroundSupportDuration, float InNetSimulateDelayedAnimMovePostureCacheTime,
	float InLocalDriveDelayedAnimMovePostureCacheTime, float InPreLandMaxHeight, float InPreLandVelocityZCalculateDuration, 
	const TArray<int32>& InDynamicWaterWaveLocoStates, const TMap<int32, uint8>& InLocoStateToMovementModeMap,
	const TArray<int32>& InJumpLocoStates, const TArray<int32>& InDodgeLocoStates, const TArray<int32>& InWaterMoveDisableOnGroundStates, const TMap<int32, float>& InLocoStateToMaxAccelerationMap,
	const TMap<int32, float>& InLocoStateToMaxBrakingDecelerationMap, const TMap<int32, TArray<float>>& InLocoGroupToSpeedStagesMap,
	const TMap<int32, TArray<int>>& InLocoGroupToMovePosturesMap, const TMap<int32, float>& InLocoStateToOverrideGravityScaleMap,
	const TMap<int32, int32>& InLocoStateToLocoMoveCorrectorTypeMap, const TMap<int32, FScriptDoLocoJumpInfo>& InLocoStateToScriptDoLocoJumpInfoMap,
	const TMap<int32, FLocoAnimStateBoolInfo>& InLocoStateToEnableInputAxisInfoMap, const TMap<int32, FLocoAnimStateBoolInfo>& InLocoStateToEnableBodyLeanInfoMap,
	const TArray<int32>& InForceCheckSwimDepthLocoStates, const TMap<int32, float>& InAnimMovePostureToMaxStepHeightMap,
	float InClimbCapsuleRadius, float InTryClimbDetectDistance, bool InbNeedClimbCheckBounds, float InMinimumClimbBoundsRadius, float InMinimumClimbBoundsBoxLength,
	float InMinClimbAngleCos, float InMaxClimbAngleCos, float InGlideThrusterMainSpeedRate, float InGlideThrusterAdjustDeltaYaw, float InGlideThrusterSideSpeedAcce, 
	float InGlideThrusterSideSpeedDece, float InMinInWaterLocoMaxSpeedScale, float InBackCarAngle, float InBackCarSpeedLimit, float InTriggerBackCarSpeedLimit,
	float InVerticalDriftSpeedToTriggerDriftDecal, float InSpeedGapForTriggerDriftDecal,
	const TMap<int32, FMountAKEventParam>& CommonMountAKEventParamMap, const TArray<int32>& ResetProgressWhenSyncReentryLocoStates)
{
	StaticDataInfo.MainPlayerTrackFloorCollisionPresetName = FName(InMainPlayerTrackFloorCollisionPresetName);
	StaticDataInfo.CommonTrackFloorCollisionPresetName = FName(InCommonTrackFloorCollisionPresetName);
	StaticDataInfo.LocoGravityScale = InLocoGravityScale;
	StaticDataInfo.LocoJumpZVelocity = InLocoJumpZVelocity;
	StaticDataInfo.EnterFallingVelocityZ = InEnterFallingVelocityZ;
	StaticDataInfo.HighJumpEndVelocityZThreshold = InHighJumpEndVelocityZThreshold;
	StaticDataInfo.GravityVelocityZMax = InGravityVelocityZMax;
	StaticDataInfo.StickGroundMeshZOffset = InStickGroundMeshZOffset;
	StaticDataInfo.TotalLocoJumpForceIgnoreGroundSupportDuration = InTotalLocoJumpForceIgnoreGroundSupportDuration;
	StaticDataInfo.NetSimulateDelayedAnimMovePostureCacheTime = InNetSimulateDelayedAnimMovePostureCacheTime;
	StaticDataInfo.LocalDriveDelayedAnimMovePostureCacheTime = InLocalDriveDelayedAnimMovePostureCacheTime;
	StaticDataInfo.PreLandMaxHeight = InPreLandMaxHeight;
	StaticDataInfo.PreLandVelocityZCalculateDuration = InPreLandVelocityZCalculateDuration;

	// LocoState或LocoGroup的操控相关
	StaticDataInfo.DynamicWaterWaveLocoStates = InDynamicWaterWaveLocoStates;
	StaticDataInfo.LocoStateToMovementModeMap = InLocoStateToMovementModeMap;
	StaticDataInfo.JumpLocoStates = InJumpLocoStates;
	StaticDataInfo.DodgeLocoStates = InDodgeLocoStates;
	StaticDataInfo.WaterMoveDisableOnGroundStates = InWaterMoveDisableOnGroundStates;
	StaticDataInfo.LocoStateToMaxAccelerationMap = InLocoStateToMaxAccelerationMap;
	StaticDataInfo.LocoStateToMaxBrakingDecelerationMap = InLocoStateToMaxBrakingDecelerationMap;
	StaticDataInfo.LocoGroupToSpeedStagesMap = InLocoGroupToSpeedStagesMap;
	StaticDataInfo.LocoGroupToMovePosturesMap = InLocoGroupToMovePosturesMap;
	StaticDataInfo.LocoStateToOverrideGravityScaleMap = InLocoStateToOverrideGravityScaleMap;
	StaticDataInfo.LocoStateToLocoMoveCorrectorTypeMap = InLocoStateToLocoMoveCorrectorTypeMap;
	StaticDataInfo.LocoStateToScriptDoLocoJumpInfoMap = InLocoStateToScriptDoLocoJumpInfoMap;
	StaticDataInfo.ForceCheckSwimDepthLocoStates = InForceCheckSwimDepthLocoStates;
	StaticDataInfo.AnimMovePostureToMaxStepHeightMap = InAnimMovePostureToMaxStepHeightMap;
	StaticDataInfo.ResetProgressWhenSyncReentryLocoStates = ResetProgressWhenSyncReentryLocoStates;
	// BodyLean Related
	StaticDataInfo.LocoStateToEnableInputAxisInfoMap = InLocoStateToEnableInputAxisInfoMap;
	StaticDataInfo.LocoStateToEnableBodyLeanInfoMap = InLocoStateToEnableBodyLeanInfoMap;
	// 坐骑相关
	StaticDataInfo.CommonMountAKEventParamMap = CommonMountAKEventParamMap;

	// 攀爬相关
	StaticDataInfo.ClimbCapsuleRadius = InClimbCapsuleRadius;
	StaticDataInfo.TryClimbDetectDistance = InTryClimbDetectDistance;
	StaticDataInfo.bNeedClimbCheckBounds = InbNeedClimbCheckBounds;
	StaticDataInfo.MinimumClimbBoundsRadius = InMinimumClimbBoundsRadius;
	StaticDataInfo.MinimumClimbBoundsBoxLength = InMinimumClimbBoundsBoxLength;
	StaticDataInfo.MinClimbAngleCos = InMinClimbAngleCos;
	StaticDataInfo.MaxClimbAngleCos = InMaxClimbAngleCos;

	// 漂浮相关
	StaticDataInfo.GlideThrusterMainSpeedRate = FMath::Clamp(InGlideThrusterMainSpeedRate, 0.0f, 1.0f);
	StaticDataInfo.GlideThrusterSideSpeedRate = 0.5f * (1.0 - StaticDataInfo.GlideThrusterMainSpeedRate);
	StaticDataInfo.GlideThrusterAdjustDeltaYaw = FMath::Clamp(InGlideThrusterAdjustDeltaYaw, 0.0f, 90.0f);
	StaticDataInfo.GlideThrusterSideSpeedAcce = FMath::Max(InGlideThrusterSideSpeedAcce, 0.0f);
	StaticDataInfo.GlideThrusterSideSpeedDece = FMath::Max(InGlideThrusterSideSpeedDece, 0.0f);

	// 其他玩法逻辑相关
	StaticDataInfo.MinInWaterLocoMaxSpeedScale = InMinInWaterLocoMaxSpeedScale;
	StaticDataInfo.BackCarAngle = InBackCarAngle;
	StaticDataInfo.BackCarSpeedLimit = InBackCarSpeedLimit;
	StaticDataInfo.TriggerBackCarSpeedLimit = InTriggerBackCarSpeedLimit;

	// 车辙拖尾特效相关
	StaticDataInfo.VerticalDriftSpeedToTriggerDriftDecal = InVerticalDriftSpeedToTriggerDriftDecal;
	StaticDataInfo.SpeedGapForTriggerDriftDecal = InSpeedGapForTriggerDriftDecal;
}

void URoleMovementComponent::UpdateLocoControlStaticData(const TMap<int32, FLocoControlInfoDetails>& InStaticDefaultTemplateInitData, const TMap<int32, FLocoControlInfoDetails>& InStaticDefaultTemplateUpdateData,
	const TMap<int32, FUpperControlLogicIDInfo>& InStaticUpperControlLogicUpdateData, const TArray<FString>& InInitTitleListForLua, const TArray<FString>& InUpdateTitleListForLua)
{
	LocoControlOperator::UpdateLocoControlStaticData(InStaticDefaultTemplateInitData, InStaticDefaultTemplateUpdateData, 
		InStaticUpperControlLogicUpdateData, InInitTitleListForLua, InUpdateTitleListForLua);
}


#pragma region LocoStateChangedOperation
void URoleMovementComponent::DoLocoStateChangedOperationCommonly(uint8 LastLocoState, uint8 NewLocoState)
{
	if (LocoInputModeRotationMotionWarpToken > 0)
	{
		ReleaseMotionWarp(LocoInputModeRotationMotionWarpToken);
		LocoInputModeRotationMotionWarpToken = -1;
	}

	if (AnimNotifyGroundSupportControlToken > 0)
	{
		// 取消前置LocoState的Notify的地面支撑控制
		// UE_LOG(LogTemp, Warning, TEXT("[szk]DoLocoStateChangeNotify, Clear InAdvance! Token:%i"), AnimNotifyGroundSupportControlToken);
		ClearGroundSupportFromAnimNotify(AnimNotifyGroundSupportControlToken);
	}

	if (InputAxisSwitch || BodyLeanSwitch)
	{
		if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
		{
			if (InputAxisSwitch)
			{
				bool OldLocoStateEnableInputAxis = GetEnableInputAxisForLocoState(LastLocoState);
				bool NewLocoStateEnableInputAxis = GetEnableInputAxisForLocoState(NewLocoState);
				if (OldLocoStateEnableInputAxis != NewLocoStateEnableInputAxis)
				{
					AnimInstance->SetLocEnableInputAxis(NewLocoStateEnableInputAxis);
				}
			}

			if (BodyLeanSwitch)
			{
				bool OldLocoStateEnableBodyLean = GetEnableBodyLeanForLocoState(LastLocoState);
				bool NewLocoStateEnableBodyLean = GetEnableBodyLeanForLocoState(NewLocoState);
				if (NewLocoStateEnableBodyLean != OldLocoStateEnableBodyLean)
				{
					AnimInstance->SetLocEnableBodyLean(NewLocoStateEnableBodyLean);
				}
			}
		}
	}

	CheckNeedGlideLoopNiagara(NewLocoState);
}

void URoleMovementComponent::DoLocoStateChangedOperationWhenNeedNotify(uint8 LastLocoState, uint8 NewLocoState)
{
	
}

bool URoleMovementComponent::GetEnableInputAxisForLocoState(uint8 InLocoState)
{
	bool OutRes = false;
	if (StaticDataInfo.LocoStateToEnableInputAxisInfoMap.Contains(InLocoState))
	{
		const FLocoAnimStateBoolInfo& EnableInputAxisInfo = StaticDataInfo.LocoStateToEnableInputAxisInfoMap[InLocoState];
		
		bool IsRider = (eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsRiderStart && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsRiderEnd);
		bool IsPassenger = (eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsPassengerStart && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsPassengerEnd);
		bool IsMount = (eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsCarrierStart && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsCarrierEnd);
		if (IsRider || IsPassenger || IsMount)
		{
			// 坐骑关系时，检查MountOverrideInfo
			EMountType CurMountType = EMountType(GetRealMovementControlViewProxy()->RoleMP.GetMovementContext().GetMountType());
			if (EnableInputAxisInfo.MountOverrideInfo.Contains(CurMountType))
			{
				OutRes = EnableInputAxisInfo.MountOverrideInfo[CurMountType];
			}
			else
			{
				OutRes = EnableInputAxisInfo.CommonValue;
			}
		}
		else
		{
			OutRes = EnableInputAxisInfo.CommonValue;
		}
	}
	return OutRes;
}

bool URoleMovementComponent::GetEnableBodyLeanForLocoState(uint8 InLocoState)
{
	bool OutRes = false;
	if (StaticDataInfo.LocoStateToEnableBodyLeanInfoMap.Contains(InLocoState))
	{
		const FLocoAnimStateBoolInfo& EnableBodyLeanInfo = StaticDataInfo.LocoStateToEnableBodyLeanInfoMap[InLocoState];

		bool IsRider = (eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsRiderStart && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsRiderEnd);
		bool IsPassenger = (eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsPassengerStart && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsPassengerEnd);
		bool IsMount = (eMoveDriveRelation >= EMoveDriveRelation::DriveMountAsCarrierStart && eMoveDriveRelation <= EMoveDriveRelation::DriveMountAsCarrierEnd);
		if (IsRider || IsPassenger || IsMount)
		{
			// 坐骑关系时，检查MountOverrideInfo
			EMountType CurMountType = EMountType(GetRealMovementControlViewProxy()->RoleMP.GetMovementContext().GetMountType());
			if (EnableBodyLeanInfo.MountOverrideInfo.Contains(CurMountType))
			{
				OutRes = EnableBodyLeanInfo.MountOverrideInfo[CurMountType];
			}
			else
			{
				OutRes = EnableBodyLeanInfo.CommonValue;
			}
		}
		else
		{
			OutRes = EnableBodyLeanInfo.CommonValue;
		}
	}
	return OutRes;
}

void URoleMovementComponent::SetBodyLeanSwitch(bool InSwitch) 
{ 
	BodyLeanSwitch = InSwitch; 
	if (UBaseAnimInstance* baseAnimInst = GetAnimInstanceForMovement())
	{
		baseAnimInst->BodyLeanSwitch = InSwitch;
	}
}

void URoleMovementComponent::SetInputAxisSwitch(bool InSwitch)
{ 
	InputAxisSwitch = InSwitch; 
	if (UBaseAnimInstance* baseAnimInst = GetAnimInstanceForMovement())
	{
		baseAnimInst->InputAxisSwitch = InSwitch;
	}
}
#pragma endregion LocoStateChangedOperation

#pragma region TriggerDrift

void URoleMovementComponent::CheckTriggerDriftByInverseCalculate(float DriftForce)
{
	// UE_LOG(LogTemp, Log, TEXT("[CheckTriggerDriftByInverseCalculate] %f"), DriftForce);
	float VerticalDriftSpeedToTriggerDriftDecal = GetVerticalDriftSpeedToTriggerDriftDecal();
	float SpeedGapForTriggerDriftDecal = GetSpeedGapForTriggerDriftDecal();
	if (DriftForce > VerticalDriftSpeedToTriggerDriftDecal + SpeedGapForTriggerDriftDecal)
	{
		if (!bNetDriveDriftPerformanceAttach)
		{
			bNetDriveDriftPerformanceAttach = true;
			RoleMP.GetMovementContext().IncreaseTriggerDriftDecalCount();	
		}
	}
	else if (DriftForce < VerticalDriftSpeedToTriggerDriftDecal - SpeedGapForTriggerDriftDecal)
	{
		if (bNetDriveDriftPerformanceAttach)
		{
			bNetDriveDriftPerformanceAttach = false;
			RoleMP.GetMovementContext().DecreaseTriggerDriftDecalCount();	
		}
	}
}

void URoleMovementComponent::ClearTriggerDriftByInverseCalculate()
{
	if (bNetDriveDriftPerformanceAttach)
	{
		bNetDriveDriftPerformanceAttach = false;
		RoleMP.GetMovementContext().DecreaseTriggerDriftDecalCount();
	}
}

void URoleMovementComponent::EnableDynamicCollisionWithMainPlayer(bool bEnable)
{
	bEnableCollisionWithMainPlayer = bEnable;
	UpdateCollisionWithLocoStart(GetIsLocoStart());
}

void URoleMovementComponent::UpdateCollisionWithLocoStart(bool bLocoStart)
{
	UKGUEActorManager* UEActorManagerPtr = UKGUEActorManager::GetInstance(this);
	if (!UEActorManagerPtr) return;
	KGEntityID MainPlayerEid = UEActorManagerPtr->GetMainPlayerEntityID();
	if (MainPlayerEid == KG_INVALID_ENTITY_ID) return;
	AActor* Actor = UEActorManagerPtr->GetActorByEntityID(MainPlayerEid);
	if (!Actor) return;
	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(Actor);
	if (!BaseCharacter) return;

	if (URoleMovementComponent* MoveComponent = Cast<URoleMovementComponent>(BaseCharacter->GetMovementComponent()))
	{
		MoveComponent->ChangeImpetusActorMap_P(GetOwner(), !bLocoStart);
	}
}

#pragma endregion TriggerDrift

#pragma region ALS
void URoleMovementComponent::SetupASLMovementControlData(const FString & SpeedCurvePath, const FString& RotCurvePath)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogTemp, Error, TEXT("[ URoleMovementComponent::SetupASLMovementControlData] invalid asset manager"));
		return ;
	}


	ALSSpeedCurveLoadID = AssetManager->AsyncLoadAsset(
				SpeedCurvePath, FAsyncLoadCompleteDelegate::CreateUObject(this, &URoleMovementComponent::OnALSMovementControlCurveLoaded),
				static_cast<int32>(EAssetLoadPriority::MoveCurve));
	
	ALSRotationCurveLoadID = AssetManager->AsyncLoadAsset(
			RotCurvePath, FAsyncLoadCompleteDelegate::CreateUObject(this, &URoleMovementComponent::OnALSMovementControlCurveLoaded),
			static_cast<int32>(EAssetLoadPriority::MoveCurve));
}

void URoleMovementComponent::OnALSMovementControlCurveLoaded(int InLoadID, UObject* LoadedAsset)
{
	if(ALSSpeedCurveLoadID == InLoadID)
	{
		if (UCurveVector* Curve = Cast<UCurveVector>(LoadedAsset))
		{
			ALSSpeedCurve = Curve;
		}
		ALSSpeedCurveLoadID = -1;
	}

	if(ALSRotationCurveLoadID == InLoadID)
	{
		if (UCurveFloat* Curve = Cast<UCurveFloat>(LoadedAsset))
		{
			ALSRotationCurve = Curve;
		}
		ALSRotationCurveLoadID = -1;
	}
}

FVector URoleMovementComponent::GetALSMappedSpeedFromCurve() const
{
	if(!IsValid(ALSSpeedCurve)){
		return FVector::Zero();
	}
	return ALSSpeedCurve->GetVectorValue(GetALSMappedSpeedCurveInTime());
	
}

float URoleMovementComponent::GetALSMappedSpeedCurveInTime() const
{
	float CurveInTime = 0.0f;
	FVector VelXY = GetMovementVelocity(); 
	VelXY.Z = 0;
	float CurMovementSpeed = VelXY.Size();
	if(SpeedStages.Num() <= SPRINT_SPEED_STAGE_INDEX){
		return CurveInTime;
	}
	
	float WalkSpeed = SpeedStages[WALK_SPEED_STAGE_INDEX];
	float RunSpeed = SpeedStages[RUN_SPEED_STAGE_INDEX];
	float SprintSpeed = SpeedStages[SPRINT_SPEED_STAGE_INDEX];
	
	if(CurMovementSpeed < WalkSpeed)
	{
		CurveInTime = UKismetMathLibrary::MapRangeClamped(CurMovementSpeed, 0, WalkSpeed, WALK_SPEED_STAGE_INDEX, WALK_SPEED_STAGE_INDEX + 1);
	}
	else if (CurMovementSpeed < RunSpeed)
	{
		CurveInTime = UKismetMathLibrary::MapRangeClamped(CurMovementSpeed, WalkSpeed, RunSpeed, RUN_SPEED_STAGE_INDEX, RUN_SPEED_STAGE_INDEX + 1);
	}
	else
	{
		CurveInTime = UKismetMathLibrary::MapRangeClamped(CurMovementSpeed, RunSpeed, SprintSpeed, SPRINT_SPEED_STAGE_INDEX, SPRINT_SPEED_STAGE_INDEX + 1);
	}

	return CurveInTime;
}

float URoleMovementComponent::GetALSRotationRate()
{
	if(!IsValid(ALSRotationCurve))
	{
		return 1.0f;
	}

	float MoveSpeedInTime = GetALSMappedSpeedCurveInTime();
	float MappedCurveRotValue = ALSRotationCurve->GetFloatValue(MoveSpeedInTime);
	float result = MappedCurveRotValue * UKismetMathLibrary::MapRangeClamped(ControlYawDiffRatio, 0, 300, 1.0, 3.0);


	return result;
}

float URoleMovementComponent::CalculateALSRotationTargetYaw(float DeltaTime)
{
	const FRotator& CurActorRotation = GetActorTransform().Rotator();
	// 默认使用角色当前朝向
	FRotator ExpectedRot = CurActorRotation;
	
	// 仅在LocoYawController开启并处于ALSVelocityRotYaw模式时，才使用Velocity参与计算
	if (RoleMP.LocoYawController.IsSwitchOn() && RoleMP.LocoYawController.GetArgSourceMode() == EArgSourceMode::ALSVelocityRotYaw)
	{
		// XY速度非0时，使用速度朝向
		FVector CurVelocity = GetMovementVelocity();
		CurVelocity.Z = 0.0f;
		if (!CurVelocity.IsNearlyZero())
		{
			ExpectedRot = CurVelocity.Rotation();
		}
	}

	float ActorRotRate = GetALSRotationRate();
	float RInterSpeed = 800;
	if (ALS_RotationMode == EALS_RotationMode::VelocityDirection)
	{
		RInterSpeed = OverrideLerpSpeedForVelocityDirection > 0.0f ? OverrideLerpSpeedForVelocityDirection : 800;
	}
	else if (ALS_RotationMode == EALS_RotationMode::LookingDirection)
	{
		RInterSpeed = 500;
	}
	else
	{
		RInterSpeed = 1000;
		ActorRotRate = 20;
	}

	ALSTargetRotation = FMath::RInterpConstantTo(ALSTargetRotation, ExpectedRot, DeltaTime, RInterSpeed);
	FRotator ActorRot = FMath::RInterpTo(GetActorTransform().Rotator(), ALSTargetRotation, DeltaTime, ActorRotRate);

	return ActorRot.Yaw;
}

void URoleMovementComponent::CalculateALSLocoControlData(float DeltaTime)
{

	// 1.根据速度算角色朝向, 用于万向移动模式
	RoleMP.GetMovementContext().SetALSRotTargetYaw(CalculateALSRotationTargetYaw(DeltaTime));

	//2. 计算Aim 朝向
	// 在寻路、网络控制下, 非主动操控的移动
	float LookWorldYaw = 0.0f;
	FRotator ActorRotator = GetActorTransform().Rotator();
	const float MOVEMENT_VEL_TOLERATE = 5.0f;
	bool HasValidMovementSpeed = GetMovementVelocity().Size() > MOVEMENT_VEL_TOLERATE;
	if(GetCurrentIsNetSimulate() || GetHasRequestedVelocity())
	{
	
		if(HasValidMovementSpeed)
		{
			ALSAimingRotation = GetMovementVelocity().GetSafeNormal().Rotation();
		}
		else
		{
			ALSAimingRotation = ActorRotator;
		}

		LookWorldYaw = ALSAimingRotation.Yaw;
		
	}
	else
	{
		// 主动操控下的
		if (ALS_RotationMode == EALS_RotationMode::Aiming)
		{
			ALSAimingRotation = GetMovementControlRotation();
		}
		else
		{

			// 有点先用点, 是相机lookat在用; target有可能是lookat机制在用、也有可能是battle lock在用
			if(IsLockingPosition())
			{
				FVector ToLockingTargetVec = LockingTargetPosition - GetActorTransform().GetTranslation();
				ToLockingTargetVec.Normalize();
				ALSAimingRotation = ToLockingTargetVec.Rotation();
			
			}
			else if (IsLockingTarget())
			{
				AActor* LockingTarget = KGUtils::GetActorByID(GetLockingTargetCharacterID());
				if(LockingTarget)
				{
					FVector ToLockingTargetVec = LockingTarget->GetActorTransform().GetTranslation() - GetActorTransform().GetTranslation();
					ToLockingTargetVec.Normalize();
					ALSAimingRotation = ToLockingTargetVec.Rotation();
				}
			}
			else
			{
				ALSAimingRotation = GetMovementControlRotation();
			}
		}

		// 这里可能会晚一帧, 但是没有关系
		LookWorldYaw = LocoInputVector.Rotation().Yaw;
	}

	if(ALS_RotationMode == EALS_RotationMode::VelocityDirection)
	{
		if(HasValidMovementSpeed && GetIsLocoStart())
		{
			float LocalLookYawDiff = MathFormula::ClosetYawSignedDiff(ActorRotator.Yaw, LookWorldYaw);
			LookYawInLocalSpace = FMath::FInterpTo(LookYawInLocalSpace, LocalLookYawDiff, DeltaTime, LookYawInterpolationSpeed);
		}
		else
		{
			LookWorldYaw = 0.0f;
			LookYawInLocalSpace = FMath::FInterpTo(LookYawInLocalSpace, LookWorldYaw, DeltaTime, LookYawInterpolationSpeed);
		}
	}
}

bool URoleMovementComponent::IsLockingTarget()
{
	return  (LockingTargetActorID == KG_INVALID_ACTOR_ID? false : true);
}

void URoleMovementComponent::SetLockingTargetCharacterID(KGActorID CharacterID)
{
	LockingTargetActorID = CharacterID;
}

void URoleMovementComponent::SetLockingTargetPosition(bool IsLocking, float X, float Y, float Z)
{
	IsLockingTargetPosition = IsLocking;
	LockingTargetPosition.Set(X, Y, Z);
}

#pragma endregion ALS

#pragma region SpiritualJump

void URoleMovementComponent::CheckNeedGlideLoopNiagara(uint8 NewLocoState)
{
	auto* EffectMgr = UKGEffectManager::GetInstance(this);
	if (!EffectMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CheckNeedGlideLoopNiagara] get KGEffectManager failed"));
		return;
	}

	auto* DataCacheMgr = UKGDataCacheManager::GetInstance(this);
	if (!DataCacheMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CheckNeedGlideLoopNiagara] get KGDataCacheManager failed"));
		return;
	}

	const FGlideLoopParams& GlideLoopParams = DataCacheMgr->GetGlideLoopParams();
	if (NewLocoState == GlideLoopParams.LocoState)
	{
		if (GlideLoopNiagaraID_HL == 0)
		{
			FKGPlayNiagaraParams Params;
			SetGlideLoopNiagaraParams(Params, GlideLoopParams.HandNiagaraPath, GlideLoopParams.NiagaraAttachPoint_HL, true);
			GlideLoopNiagaraID_HL = EffectMgr->CreateNiagaraSystem(Params);
		}

		if (GlideLoopNiagaraID_HR == 0)
		{
			FKGPlayNiagaraParams Params;
			SetGlideLoopNiagaraParams(Params, GlideLoopParams.HandNiagaraPath, GlideLoopParams.NiagaraAttachPoint_HR, true);
			GlideLoopNiagaraID_HR = EffectMgr->CreateNiagaraSystem(Params);
		}

		if (GlideLoopNiagaraID_AL == 0)
		{
			FKGPlayNiagaraParams Params;
			SetGlideLoopNiagaraParams(Params, GlideLoopParams.ArmNiagaraPath_L, GlideLoopParams.NiagaraAttachPoint_AL, false);
			GlideLoopNiagaraID_AL = EffectMgr->CreateNiagaraSystem(Params);
		}

		if (GlideLoopNiagaraID_AR == 0)
		{
			FKGPlayNiagaraParams Params;
			SetGlideLoopNiagaraParams(Params, GlideLoopParams.ArmNiagaraPath_R, GlideLoopParams.NiagaraAttachPoint_AR, false);
			GlideLoopNiagaraID_AR = EffectMgr->CreateNiagaraSystem(Params);
		}
	}
	else
	{
		if (GlideLoopNiagaraID_HL != 0)
		{
			EffectMgr->DeactivateNiagaraSystem(GlideLoopNiagaraID_HL);
			GlideLoopNiagaraID_HL = 0;
		}

		if (GlideLoopNiagaraID_HR != 0)
		{
			EffectMgr->DeactivateNiagaraSystem(GlideLoopNiagaraID_HR);
			GlideLoopNiagaraID_HR = 0;
		}

		if (GlideLoopNiagaraID_AL != 0)
		{
			EffectMgr->DeactivateNiagaraSystem(GlideLoopNiagaraID_AL);
			GlideLoopNiagaraID_AL = 0;
		}

		if (GlideLoopNiagaraID_AR != 0)
		{
			EffectMgr->DeactivateNiagaraSystem(GlideLoopNiagaraID_AR);
			GlideLoopNiagaraID_AR = 0;
		}
	}
}

void URoleMovementComponent::SetGlideLoopNiagaraParams(FKGPlayNiagaraParams& InParams, const FString& NiagaraPath, const FName& AttachPoint, bool bIsHandEffect) const
{
	InParams.NiagaraEffectPath = NiagaraPath;
	InParams.SpawnerID = KGUtils::GetIDByObject(GetOwner());
	FKGAttachedNiagaraSpawnInfo AttachInfo;
	AttachInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseMainMeshComponent;
	AttachInfo.AttachPointName = AttachPoint;
	InParams.SetAttachedSpawnInfo(AttachInfo);
	if (bIsHandEffect)
	{
		InParams.EffectTags.Add(EKGNiagaraEffectTag::SPIRITUAL_GLIDE_HAND_EFFECT);
	}
}

#pragma endregion SpiritualJump

#pragma region Terrain

void URoleMovementComponent::RecordFootStepTerrain(const FString& InTerrainName)
{
	auto* DataCacheMgr = UKGDataCacheManager::GetInstance(this);
	if (!DataCacheMgr)
	{
		return;
	}

	// 可以触发脚印的材质,才记录
	if (DataCacheMgr->GetTerrainFootprintData(InTerrainName))
	{
		LastFootStepTerrainName = InTerrainName;
		if (UWorld* World = GetWorld())
		{
			LastFootStepRecordTime = World->GetTimeSeconds();
		}	
	}
}

#pragma endregion Terrain


#pragma region LocoControlOperator
void URoleMovementComponent::InitLocoControlOperatorNeededScriptData(bool InNeedBornStickGround)
{
	EnsureLocoControlOperator();
	if (!LocoControlOP.IsValid()) {
		return;
	}

	LocoControlOP->InitNeededScriptData(InNeedBornStickGround);
}

bool URoleMovementComponent::InitLocoControlOperatorDefaultTemplateID(int32 InDefaultTemplateID)
{
	EnsureLocoControlOperator();
	if (!LocoControlOP.IsValid()) {
		return false;
	}
	LocoControlOP->InitLocoControlOperator(this);

	return LocoControlOP->InitDefaultTemplateID(InDefaultTemplateID);
}

bool URoleMovementComponent::LocoControlOperatorDoUpperControlLogic(int32 InUpperContolLogicID)
{
	if (!LocoControlOP.IsValid()) {
		return false;
	}

	return LocoControlOP->DoUpperControlLogic(InUpperContolLogicID);
}

bool URoleMovementComponent::LocoControlOperatorUnDoUpperControlLogic(int32 InUpperContolLogicID)
{
	if (!LocoControlOP.IsValid()) {
		return false;
	}

	return LocoControlOP->UnDoUpperControlLogic(InUpperContolLogicID);
}

void URoleMovementComponent::EnsureLocoControlOperator() {
	if (LocoControlOP.IsValid()) {
		return;
	}

	LocoControlOP = MakeUnique<LocoControlOperator>();
	return;
}
#pragma endregion LocoControlOperator


#pragma region PropertyControl
void URoleMovementComponent::ResetAllControlForMainplayer()
{
	ClearAllGravationalMsg();
	ResetAutoUpdatePostureAndPlayRate();
	ResetLocoInputThruster();
	ResetRootmotionMode();
	ResetNeedFrameStickGround();
	ResetIsGravityOn();
	ResetDisableMoveAll();
	ResetDisableLocoMove();
	ResetDisableLocoStart();
	ResetDisableRotateAll();
	ResetDisableLocoRotate();
	ResetDisableLocoJump();
	ResetDisableLocoDodge();
	ResetMoveDriveMode();
	ResetUsingLateUpdate();
}

bool URoleMovementComponent::SetAutoUpdatePostureAndPlayRateWeakValue(bool InNeedAutoUpdate, const FString& InTag)
{
	bool bOldNeedAutoUpdatePostureAndPlayRate = bAutoUpdatePostureAndPlayRate;
	if (InNeedAutoUpdate) {
		AutoUpdatePostureWeakValueCountArray.AddUnique(InTag);
	}
	else
	{
		if (AutoUpdatePostureWeakValueCountArray.Contains(InTag)) {
			AutoUpdatePostureWeakValueCountArray.Remove(InTag);
		}
	}

	bool NewNeedAutoUpdatePostureAndPlayRate = AutoUpdatePostureForceValue.IsSet() ? AutoUpdatePostureForceValue.GetValue() : !AutoUpdatePostureWeakValueCountArray.IsEmpty();
	if (NewNeedAutoUpdatePostureAndPlayRate != bOldNeedAutoUpdatePostureAndPlayRate) {
		SetAutoUpdatePostureAndPlayRate(NewNeedAutoUpdatePostureAndPlayRate);
	}

	return bAutoUpdatePostureAndPlayRate;
}

bool URoleMovementComponent::SetAutoUpdatePostureAndPlayRateForceValue(bool InNeedAutoUpdate, const FString& InTag)
{
	bool bOldNeedAutoUpdatePostureAndPlayRate = bAutoUpdatePostureAndPlayRate;
	if (AutoUpdatePostureForceValueTag.IsSet() && AutoUpdatePostureForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("SetAutoUpdatePostureAndPlayRateForceValue Error! Already Has Force Tag:%s, InTag:%s"), *AutoUpdatePostureForceValueTag.GetValue(), *InTag);
	}
	AutoUpdatePostureForceValueTag = InTag;
	AutoUpdatePostureForceValue = InNeedAutoUpdate;

	bool NewNeedAutoUpdatePostureAndPlayRate = AutoUpdatePostureForceValue.GetValue();
	if (NewNeedAutoUpdatePostureAndPlayRate != bOldNeedAutoUpdatePostureAndPlayRate) {
		SetAutoUpdatePostureAndPlayRate(NewNeedAutoUpdatePostureAndPlayRate);
	}

	return bAutoUpdatePostureAndPlayRate;
}

bool URoleMovementComponent::ClearAutoUpdatePostureAndPlayRateForceValue(const FString& InTag)
{
	bool bOldNeedAutoUpdatePostureAndPlayRate = bAutoUpdatePostureAndPlayRate;
	if (!AutoUpdatePostureForceValueTag.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearAutoUpdatePostureAndPlayRateForceValue Error! No Force Tag"));
		return bAutoUpdatePostureAndPlayRate;
	}
	else if (AutoUpdatePostureForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearAutoUpdatePostureAndPlayRateForceValue Error! CurForceTag:%s, InTag:%s"), *AutoUpdatePostureForceValueTag.GetValue(), *InTag);
		return bAutoUpdatePostureAndPlayRate;
	}
	AutoUpdatePostureForceValueTag.Reset();
	AutoUpdatePostureForceValue.Reset();

	bool NewNeedAutoUpdatePostureAndPlayRate = !AutoUpdatePostureWeakValueCountArray.IsEmpty();
	if (NewNeedAutoUpdatePostureAndPlayRate != bOldNeedAutoUpdatePostureAndPlayRate) {
		SetAutoUpdatePostureAndPlayRate(NewNeedAutoUpdatePostureAndPlayRate);
	}

	return bAutoUpdatePostureAndPlayRate;
}

bool URoleMovementComponent::ResetAutoUpdatePostureAndPlayRate()
{
	AutoUpdatePostureForceValueTag.Reset();
	AutoUpdatePostureForceValue.Reset();
	AutoUpdatePostureWeakValueCountArray.Empty();
	if (bAutoUpdatePostureAndPlayRate) {
		SetAutoUpdatePostureAndPlayRate(false);
	}
	return bAutoUpdatePostureAndPlayRate;
}

bool URoleMovementComponent::SetLocoInputThrusterWeakValue(bool InIsSwitch, const FString& InTag, const float& OverrideMaxSpeed, const float& OverrideMaxAcce, const float& OverrideMaxBrakingDeccVel)
{
	LocoInputThrusterWeakValue = InIsSwitch;
	LocoInputThrusterWeakTag = InTag;
	LocoInputThrusterWeakMaxSpeed = OverrideMaxSpeed;
	LocoInputThrusterWeakMaxAcce = OverrideMaxAcce;
	LocoInputThrusterWeakMaxBrakingDec = OverrideMaxBrakingDeccVel;

	if (LocoInputThrusterForceValue.IsSet())
	{
		return LocoInputThrusterForceValue.GetValue();
	}

	if (InIsSwitch) {
		SwitchOnLocoInputThruster(OverrideMaxSpeed, OverrideMaxAcce, OverrideMaxBrakingDeccVel);
	}
	else {
		SwitchOffLocoInputThruster();
	}

	return InIsSwitch;
}

bool URoleMovementComponent::SetLocoInputThrusterForceValue(bool InIsSwitch, const FString& InTag, const float& OverrideMaxSpeed, const float& OverrideMaxAcce, const float& OverrideMaxBrakingDeccVel)
{
	if (LocoInputThrusterForceValueTag.IsSet() && LocoInputThrusterForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetLocoInputThrusterForceValue Error! Already Has ForceTag:%s, InTag:%s"), *LocoInputThrusterForceValueTag.GetValue(), *InTag);
		return LocoInputThrusterForceValue.GetValue();
	}

	LocoInputThrusterForceValueTag = InTag;
	LocoInputThrusterForceValue = InIsSwitch;

	if (InIsSwitch) {
		SwitchOnLocoInputThruster(OverrideMaxSpeed, OverrideMaxAcce, OverrideMaxBrakingDeccVel);
	}
	else {
		SwitchOffLocoInputThruster();
	}
	return LocoInputThrusterForceValue.GetValue();
}

bool URoleMovementComponent::ClearLocoInputThrusterForceValue(const FString& InTag)
{
	if (!LocoInputThrusterForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearSetRootmotionModeForceValue Error! No Force Tag"));
		return LocoInputThrusterWeakValue;
	}
	else if (LocoInputThrusterForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearLocoInputThrusterForceValue Error! CurForceTag:%s, InTag:%s"), *LocoInputThrusterForceValueTag.GetValue(), *InTag);
		return LocoInputThrusterForceValue.GetValue();
	}

	LocoInputThrusterForceValueTag.Reset();
	LocoInputThrusterForceValue.Reset();

	if (LocoInputThrusterWeakValue) {
		SwitchOnLocoInputThruster(LocoInputThrusterWeakMaxSpeed, LocoInputThrusterWeakMaxAcce, LocoInputThrusterWeakMaxBrakingDec);
	}
	else {
		SwitchOffLocoInputThruster();
	}
	return LocoInputThrusterWeakValue;
}

bool URoleMovementComponent::ResetLocoInputThruster()
{
	LocoInputThrusterForceValueTag.Reset();
	LocoInputThrusterForceValue.Reset();
	LocoInputThrusterWeakValue = false;
	LocoInputThrusterWeakTag = TEXT("Null");
	LocoInputThrusterWeakMaxSpeed = -1.0f;
	LocoInputThrusterWeakMaxAcce = -1.0f;
	LocoInputThrusterWeakMaxBrakingDec = -1.0f;

	SwitchOffLocoInputThruster();
	return false;
}

bool URoleMovementComponent::SetDisableMoveTurnWeakValue(bool InNeedDisable, const FString& InTag)
{
	if (InNeedDisable) {
		DisableMoveTurnWeakValueArray.AddUnique(InTag);
	}
	else {
		if (DisableMoveTurnWeakValueArray.Contains(InTag)) {
			DisableMoveTurnWeakValueArray.Remove(InTag);
		}
	}
	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		AnimInstance->bDisableMoveTurn = !DisableMoveTurnWeakValueArray.IsEmpty();
	}
	return !DisableMoveTurnWeakValueArray.IsEmpty();
}

int32 URoleMovementComponent::SetRootmotionModeWeakValue(int32 InRootMotionMode, const FString& InTag)
{
	RootmotionModeWeakValue = InRootMotionMode;
	RootmotionModeWeakTag = InTag;

	if (RootmotionModeForceValue.IsSet())
	{
		return RootmotionModeForceValue.GetValue();
	}

	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		AnimInstance->SetRootMotionMode(TEnumAsByte<ERootMotionMode::Type>(RootmotionModeWeakValue));
	}	
	return RootmotionModeWeakValue;
}

int32 URoleMovementComponent::SetRootmotionModeForceValue(int32 InRootMotionMode, const FString& InTag)
{
	if (RootmotionModeForceValueTag.IsSet() && RootmotionModeForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetRootmotionModeForceValue Error! Already Has ForceTag:%s, InTag:%s"), *RootmotionModeForceValueTag.GetValue(), *InTag);
		return RootmotionModeForceValue.GetValue();
	}

	RootmotionModeForceValueTag = InTag;
	RootmotionModeForceValue = InRootMotionMode;

	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		AnimInstance->SetRootMotionMode(TEnumAsByte<ERootMotionMode::Type>(RootmotionModeForceValue.GetValue()));
	}
	return RootmotionModeForceValue.GetValue();
}

int32 URoleMovementComponent::ClearSetRootmotionModeForceValue(const FString& InTag)
{
	if (!RootmotionModeForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearSetRootmotionModeForceValue Error! No Force Tag"));
		return RootmotionModeWeakValue;
	}
	else if (RootmotionModeForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearSetRootmotionModeForceValue Error! CurForceTag:%s, InTag:%s"), *RootmotionModeForceValueTag.GetValue(), *InTag);
		return RootmotionModeForceValue.GetValue();
	}

	RootmotionModeForceValueTag.Reset();
	RootmotionModeForceValue.Reset();

	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		AnimInstance->SetRootMotionMode(TEnumAsByte<ERootMotionMode::Type>(RootmotionModeWeakValue));
	}
	return RootmotionModeWeakValue;
}

int32 URoleMovementComponent::ResetRootmotionMode()
{
	RootmotionModeForceValueTag.Reset();
	RootmotionModeForceValue.Reset();
	RootmotionModeWeakValue = ERootMotionMode::IgnoreRootMotion;
	RootmotionModeWeakTag = TEXT("Null");

	if (UBaseAnimInstance* AnimInstance = GetAnimInstanceForMovement())
	{
		AnimInstance->SetRootMotionMode(TEnumAsByte<ERootMotionMode::Type>(RootmotionModeWeakValue));
	}
	return RootmotionModeWeakValue;
}

bool URoleMovementComponent::SetNeedFrameStickGroundWeakValue(bool InNeedFrameStickGround, const FString& InTag)
{
	if (InNeedFrameStickGround) {
		NeedFrameStickGroundCountArray.AddUnique(InTag);
	}
	else {
		if (NeedFrameStickGroundCountArray.Contains(InTag)) {
			NeedFrameStickGroundCountArray.Remove(InTag);
		}
	}

	if (NeedFrameStickGroundForceValue.IsSet())
	{
		return GetNeedFrameStickGround();
	}

	SetNeedFrameStickGround(!NeedFrameStickGroundCountArray.IsEmpty());
	return GetNeedFrameStickGround();
}

bool URoleMovementComponent::SetNeedFrameStickGroundForceValue(bool InNeedFrameStickGround, const FString& InTag)
{
	if (NeedFrameStickGroundForceValueTag.IsSet() && NeedFrameStickGroundForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetNeedFrameStickGroundForceValue Error! Already Has ForceTag:%s, InTag:%s"), *NeedFrameStickGroundForceValueTag.GetValue(), *InTag);
		return GetNeedFrameStickGround();
	}

	NeedFrameStickGroundForceValueTag = InTag;
	NeedFrameStickGroundForceValue = InNeedFrameStickGround;

	SetNeedFrameStickGround(NeedFrameStickGroundForceValue.GetValue());
	return GetNeedFrameStickGround();
}

bool URoleMovementComponent::ClearNeedFrameStickGroundForceValue(const FString& InTag)
{
	if (!NeedFrameStickGroundForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearSetRootmotionModeForceValue Error! No Force Tag"));
		return GetNeedFrameStickGround();
	}
	else if (NeedFrameStickGroundForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearNeedFrameStickGroundForceValue Error! CurForceTag:%s, InTag:%s"), *NeedFrameStickGroundForceValueTag.GetValue(), *InTag);
		return GetNeedFrameStickGround();
	}

	NeedFrameStickGroundForceValueTag.Reset();
	NeedFrameStickGroundForceValue.Reset();

	SetNeedFrameStickGround(!NeedFrameStickGroundCountArray.IsEmpty());
	return GetNeedFrameStickGround();
}

bool URoleMovementComponent::ResetNeedFrameStickGround()
{
	NeedFrameStickGroundForceValueTag.Reset();
	NeedFrameStickGroundForceValue.Reset();
	NeedFrameStickGroundCountArray.Empty();

	SetNeedFrameStickGround(false);
	return false;
}

bool URoleMovementComponent::SetIsGravityOnWeakValue(bool InIsGravityOn, const FString& InTag)
{	
	int32 OldGravityOnCountValue = _GravityOnCountValue;
	if (InIsGravityOn) {
		if (IsGravityOnCountMap.Contains(InTag))
		{
			IsGravityOnCountMap[InTag] += 1;
			if (IsGravityOnCountMap[InTag] == 0) {
				IsGravityOnCountMap.Remove(InTag);
			}
		}
		else {
			IsGravityOnCountMap.Add(InTag, 1);
		}
		_GravityOnCountValue += 1;
	}
	else {
		if (IsGravityOnCountMap.Contains(InTag))
		{
			IsGravityOnCountMap[InTag] -= 1;
			if (IsGravityOnCountMap[InTag] == 0) {
				IsGravityOnCountMap.Remove(InTag);
			}
		}
		else {
			IsGravityOnCountMap.Add(InTag, -1);
		}
		_GravityOnCountValue -= 1;
	}

	if (IsGravityOnForceValue.IsSet())
	{
		return IsGravityOn;
	}

	SetIsGravityOn(_GravityOnCountValue >= 0);
	return IsGravityOn;
}

bool URoleMovementComponent::SetIsGravityOnForceValue(bool InIsGravityOn, const FString& InTag)
{
	if (IsGravityOnForceValueTag.IsSet() && IsGravityOnForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetIsGravityOnForceValue Error! Already Has ForceTag:%s, InTag:%s"), *IsGravityOnForceValueTag.GetValue(), *InTag);
		return IsGravityOn;
	}

	IsGravityOnForceValueTag = InTag;
	IsGravityOnForceValue = InIsGravityOn;

	SetIsGravityOn(IsGravityOnForceValue.GetValue());
	return IsGravityOn;
}

bool URoleMovementComponent::ClearIsGravityOnForceValue(const FString& InTag)
{
	if (!IsGravityOnForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearSetRootmotionModeForceValue Error! No Force Tag"));
		return IsGravityOn;
	}
	else if (IsGravityOnForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearIsGravityOnForceValue Error! CurForceTag:%s, InTag:%s"), *IsGravityOnForceValueTag.GetValue(), *InTag);
		return IsGravityOn;
	}

	IsGravityOnForceValueTag.Reset();
	IsGravityOnForceValue.Reset();

	SetIsGravityOn(_GravityOnCountValue >= 0);
	return IsGravityOn;
}

bool URoleMovementComponent::ResetIsGravityOn()
{
	IsGravityOnForceValueTag.Reset();
	IsGravityOnForceValue.Reset();
	IsGravityOnCountMap.Empty();
	_GravityOnCountValue = 0;

	SetIsGravityOn(true);
	return IsGravityOn;
}

bool URoleMovementComponent::SetDisableMoveAllWeakValue(bool InDisableMoveAll, const FString& InTag, bool bNeedDoScriptLogic)
{
	bool OldAllowMovement = AllowMovement();
	if (InDisableMoveAll) {
		if (IsDisableMoveAllCountMap.Contains(InTag))
		{
			IsDisableMoveAllCountMap[InTag] += 1;
		}
		else {
			IsDisableMoveAllCountMap.Add(InTag, 1);
		}
	}
	else {
		if (IsDisableMoveAllCountMap.Contains(InTag))
		{
			IsDisableMoveAllCountMap[InTag] -= 1;
			if (IsDisableMoveAllCountMap[InTag] == 0) {
				IsDisableMoveAllCountMap.Remove(InTag);
			}
		}
		else {
			UE_LOG(LogTemp, Warning, TEXT("SetDisableMoveAllWeakValue Error! No Tag:%s to Remove!"), *InTag);
		}
	}

	if (IsDisableMoveAllForceValue.IsSet())
	{
		return false;
	}

	bool NewAllowMovement = IsDisableMoveAllCountMap.IsEmpty();
	if (NewAllowMovement != OldAllowMovement)
	{
		ChangeDisableMovement(!NewAllowMovement);
		if (!NewAllowMovement && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)){
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableMoveAll");
			}
		}
	}

	return !NewAllowMovement && OldAllowMovement;
}

bool URoleMovementComponent::SetDisableMoveAllForceValue(bool InDisableMoveAll, const FString& InTag, bool bNeedDoScriptLogic)
{
	if (IsDisableMoveAllForceValueTag.IsSet() && IsDisableMoveAllForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetDisableMoveAllForceValue Error! Already Has ForceTag:%s, InTag:%s"), *IsDisableMoveAllForceValueTag.GetValue(), *InTag);
		return false;
	}
	bool OldAllowMovement = AllowMovement();
	IsDisableMoveAllForceValueTag = InTag;
	IsDisableMoveAllForceValue = InDisableMoveAll;
	bool NewAllowMovement = !IsDisableMoveAllForceValue.GetValue();

	if (NewAllowMovement != OldAllowMovement)
	{
		ChangeDisableMovement(!NewAllowMovement);
		if (!NewAllowMovement && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableMoveAll");
			}
		}
	}

	return !NewAllowMovement && OldAllowMovement;
}

bool URoleMovementComponent::ClearDisableMoveAllForceValue(const FString& InTag, bool bNeedDoScriptLogic)
{
	if (!IsDisableMoveAllForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearDisableMoveAllForceValue Error! No Force Tag"));
		return false;
	}
	else if (IsDisableMoveAllForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearDisableMoveAllForceValue Error! CurForceTag:%s, InTag:%s"), *IsDisableMoveAllForceValueTag.GetValue(), *InTag);
		return false;
	}

	bool OldAllowMovement = AllowMovement();
	IsDisableMoveAllForceValueTag.Reset();
	IsDisableMoveAllForceValue.Reset();
	bool NewAllowMovement = IsDisableMoveAllCountMap.IsEmpty();
	
	if (NewAllowMovement != OldAllowMovement)
	{
		ChangeDisableMovement(!NewAllowMovement);
		if (!NewAllowMovement && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableMoveAll");
			}
		}
	}

	return !NewAllowMovement && OldAllowMovement;
}

bool URoleMovementComponent::ResetDisableMoveAll(bool bNeedDoScriptLogic)
{
	bool OldAllowMovement = AllowMovement();

	IsDisableMoveAllForceValueTag.Reset();
	IsDisableMoveAllForceValue.Reset();
	IsDisableMoveAllCountMap.Empty();

	bool NewAllowMovement = true;

	if (NewAllowMovement != OldAllowMovement)
	{
		ChangeDisableMovement(!NewAllowMovement);
		if (!NewAllowMovement && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableMoveAll");
			}
		}
	}

	return !NewAllowMovement && OldAllowMovement;
}

bool URoleMovementComponent::SetDisableLocoMoveWeakValue(bool InDisableLocoMove, const FString& InTag, bool bNeedDoScriptLogic)
{
	bool OldAllowLocoMove = !bDisableProactiveMovement;
	if (InDisableLocoMove) {
		if (IsDisableLocoMoveCountMap.Contains(InTag))
		{
			IsDisableLocoMoveCountMap[InTag] += 1;
		}
		else {
			IsDisableLocoMoveCountMap.Add(InTag, 1);
		}
	}
	else {
		if (IsDisableLocoMoveCountMap.Contains(InTag))
		{
			IsDisableLocoMoveCountMap[InTag] -= 1;
			if (IsDisableLocoMoveCountMap[InTag] == 0) {
				IsDisableLocoMoveCountMap.Remove(InTag);
			}
		}
		else {
			UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoMoveWeakValue Error! No Tag:%s to Remove!"), *InTag);
		}
	}

	if (IsDisableLocoMoveForceValue.IsSet())
	{
		return false;
	}

	bool NewAllowLocoMove = IsDisableLocoMoveCountMap.IsEmpty();
	if (NewAllowLocoMove != OldAllowLocoMove)
	{
		ChangeDisableProactiveMovement(!NewAllowLocoMove);
		if (!NewAllowLocoMove && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableLocoMove");
			}
		}
	}

	return !NewAllowLocoMove && OldAllowLocoMove;
}

bool URoleMovementComponent::SetDisableLocoMoveForceValue(bool InDisableLocoMove, const FString& InTag, bool bNeedDoScriptLogic)
{
	if (IsDisableLocoMoveForceValueTag.IsSet() && IsDisableLocoMoveForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoMoveForceValue Error! Already Has ForceTag:%s, InTag:%s"), *IsDisableLocoMoveForceValueTag.GetValue(), *InTag);
		return false;
	}
	bool OldAllowLocoMove = !bDisableProactiveMovement;
	IsDisableLocoMoveForceValueTag = InTag;
	IsDisableLocoMoveForceValue = InDisableLocoMove;
	bool NewAllowLocoMove = !IsDisableLocoMoveForceValue.GetValue();

	if (NewAllowLocoMove != OldAllowLocoMove)
	{
		ChangeDisableProactiveMovement(!NewAllowLocoMove);
		if (!NewAllowLocoMove && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableLocoMove");
			}
		}
	}

	return !NewAllowLocoMove && OldAllowLocoMove;
}

bool URoleMovementComponent::ClearDisableLocoMoveForceValue(const FString& InTag, bool bNeedDoScriptLogic)
{
	if (!IsDisableLocoMoveForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoMoveForceValue Error! No Force Tag"));
		return false;
	}
	else if (IsDisableLocoMoveForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoMoveForceValue Error! CurForceTag:%s, InTag:%s"), *IsDisableLocoMoveForceValueTag.GetValue(), *InTag);
		return false;
	}

	bool OldAllowLocoMove = !bDisableProactiveMovement;
	IsDisableLocoMoveForceValueTag.Reset();
	IsDisableLocoMoveForceValue.Reset();
	bool NewAllowLocoMove = IsDisableLocoMoveCountMap.IsEmpty();

	if (NewAllowLocoMove != OldAllowLocoMove)
	{
		ChangeDisableProactiveMovement(!NewAllowLocoMove);
		if (!NewAllowLocoMove && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableLocoMove");
			}
		}
	}

	return !NewAllowLocoMove && OldAllowLocoMove;
}

bool URoleMovementComponent::ResetDisableLocoMove(bool bNeedDoScriptLogic)
{
	bool OldAllowLocoMove = !bDisableProactiveMovement;

	IsDisableLocoMoveForceValueTag.Reset();
	IsDisableLocoMoveForceValue.Reset();
	IsDisableLocoMoveCountMap.Empty();

	bool NewAllowLocoMove = true;

	if (NewAllowLocoMove != OldAllowLocoMove)
	{
		ChangeDisableProactiveMovement(!NewAllowLocoMove);
		if (!NewAllowLocoMove && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableLocoMove");
			}
		}
	}

	return !NewAllowLocoMove && OldAllowLocoMove;
}

bool URoleMovementComponent::SetDisableLocoStartWeakValue(bool InDisableLocoStart, const FString& InTag, bool bNeedDoScriptLogic)
{
	bool OldAllowLocoStart = AllowLocoStart;
	if (InDisableLocoStart) {
		if (IsDisableLocoStartCountMap.Contains(InTag))
		{
			IsDisableLocoStartCountMap[InTag] += 1;
		}
		else {
			IsDisableLocoStartCountMap.Add(InTag, 1);
		}
	}
	else {
		if (IsDisableLocoStartCountMap.Contains(InTag))
		{
			IsDisableLocoStartCountMap[InTag] -= 1;
			if (IsDisableLocoStartCountMap[InTag] == 0) {
				IsDisableLocoStartCountMap.Remove(InTag);
			}
		}
		else {
			UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoStartWeakValue Error! No Tag:%s to Remove!"), *InTag);
		}
	}

	if (IsDisableLocoStartForceValue.IsSet())
	{
		return false;
	}

	bool NewAllowLocoStart = IsDisableLocoStartCountMap.IsEmpty();
	if (NewAllowLocoStart != OldAllowLocoStart)
	{
		SetAllowLocoStart(NewAllowLocoStart);
		if (!NewAllowLocoStart && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableLocoStart");
			}
		}
	}

	return !NewAllowLocoStart && OldAllowLocoStart;
}

bool URoleMovementComponent::SetDisableLocoStartForceValue(bool InDisableLocoStart, const FString& InTag, bool bNeedDoScriptLogic)
{
	if (IsDisableLocoStartForceValueTag.IsSet() && IsDisableLocoStartForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoStartForceValue Error! Already Has ForceTag:%s, InTag:%s"), *IsDisableLocoStartForceValueTag.GetValue(), *InTag);
		return false;
	}
	bool OldAllowLocoStart = AllowLocoStart;
	IsDisableLocoStartForceValueTag = InTag;
	IsDisableLocoStartForceValue = InDisableLocoStart;
	bool NewAllowLocoStart = !IsDisableLocoStartForceValue.GetValue();

	if (NewAllowLocoStart != OldAllowLocoStart)
	{
		SetAllowLocoStart(NewAllowLocoStart);
		if (!NewAllowLocoStart && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableLocoStart");
			}
		}
	}

	return !NewAllowLocoStart && OldAllowLocoStart;
}

bool URoleMovementComponent::ClearDisableLocoStartForceValue(const FString& InTag, bool bNeedDoScriptLogic)
{
	if (!IsDisableLocoStartForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoStartForceValue Error! No Force Tag"));
		return false;
	}
	else if (IsDisableLocoStartForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoStartForceValue Error! CurForceTag:%s, InTag:%s"), *IsDisableLocoStartForceValueTag.GetValue(), *InTag);
		return false;
	}

	bool OldAllowLocoStart = AllowLocoStart;
	IsDisableLocoStartForceValueTag.Reset();
	IsDisableLocoStartForceValue.Reset();
	bool NewAllowLocoStart = IsDisableLocoStartCountMap.IsEmpty();

	if (NewAllowLocoStart != OldAllowLocoStart)
	{
		SetAllowLocoStart(NewAllowLocoStart);
		if (!NewAllowLocoStart && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableLocoStart");
			}
		}
	}

	return !NewAllowLocoStart && OldAllowLocoStart;
}

bool URoleMovementComponent::ResetDisableLocoStart(bool bNeedDoScriptLogic)
{
	bool OldAllowLocoStart = AllowLocoStart;

	IsDisableLocoStartForceValueTag.Reset();
	IsDisableLocoStartForceValue.Reset();
	IsDisableLocoStartCountMap.Empty();

	bool NewAllowLocoStart = true;

	if (NewAllowLocoStart != OldAllowLocoStart)
	{
		SetAllowLocoStart(NewAllowLocoStart);
		if (!NewAllowLocoStart && bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableLocoStart");
			}
		}
	}

	return !NewAllowLocoStart && OldAllowLocoStart;
}

bool URoleMovementComponent::SetDisableRotateAllWeakValue(bool InDisableRotateAll, const FString& InTag)
{
	bool OldAllowRotation = AllowRotation();
	if (InDisableRotateAll) {
		if (IsDisableRotateAllCountMap.Contains(InTag))
		{
			IsDisableRotateAllCountMap[InTag] += 1;
		}
		else {
			IsDisableRotateAllCountMap.Add(InTag, 1);
		}
	}
	else {
		if (IsDisableRotateAllCountMap.Contains(InTag))
		{
			IsDisableRotateAllCountMap[InTag] -= 1;
			if (IsDisableRotateAllCountMap[InTag] == 0) {
				IsDisableRotateAllCountMap.Remove(InTag);
			}
		}
		else {
			UE_LOG(LogTemp, Warning, TEXT("SetDisableRotateAllWeakValue Error! No Tag:%s to Remove!"), *InTag);
		}
	}

	if (IsDisableRotateAllForceValue.IsSet())
	{
		return !AllowRotation();
	}

	bool NewAllowRotation = IsDisableRotateAllCountMap.IsEmpty();
	if (NewAllowRotation != OldAllowRotation)
	{
		ChangeDisableRotation(!NewAllowRotation);
	}

	return !AllowRotation();
}

bool URoleMovementComponent::SetDisableRotateAllForceValue(bool InDisableRotateAll, const FString& InTag)
{
	if (IsDisableRotateAllForceValueTag.IsSet() && IsDisableRotateAllForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetDisableRotateAllForceValue Error! Already Has ForceTag:%s, InTag:%s"), *IsDisableRotateAllForceValueTag.GetValue(), *InTag);
		return !AllowRotation();
	}
	bool OldAllowRotation = AllowRotation();
	IsDisableRotateAllForceValueTag = InTag;
	IsDisableRotateAllForceValue = InDisableRotateAll;
	bool NewAllowRotation = !IsDisableRotateAllForceValue.GetValue();

	if (NewAllowRotation != OldAllowRotation)
	{
		ChangeDisableRotation(!NewAllowRotation);
	}

	return !AllowRotation();
}

bool URoleMovementComponent::ClearDisableRotateAllForceValue(const FString& InTag)
{
	if (!IsDisableRotateAllForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearDisableRotateAllForceValue Error! No Force Tag"));
		return !AllowRotation();
	}
	else if (IsDisableRotateAllForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearDisableRotateAllForceValue Error! CurForceTag:%s, InTag:%s"), *IsDisableRotateAllForceValueTag.GetValue(), *InTag);
		return !AllowRotation();
	}

	bool OldAllowRotation = AllowRotation();
	IsDisableRotateAllForceValueTag.Reset();
	IsDisableRotateAllForceValue.Reset();
	bool NewAllowRotation = IsDisableRotateAllCountMap.IsEmpty();

	if (NewAllowRotation != OldAllowRotation)
	{
		ChangeDisableRotation(!NewAllowRotation);
	}

	return !AllowRotation();
}

bool URoleMovementComponent::ResetDisableRotateAll()
{
	bool OldAllowRotation = AllowRotation();

	IsDisableRotateAllForceValueTag.Reset();
	IsDisableRotateAllForceValue.Reset();
	IsDisableRotateAllCountMap.Empty();

	bool NewAllowRotation = true;

	if (NewAllowRotation != OldAllowRotation)
	{
		ChangeDisableRotation(!NewAllowRotation);
	}

	return !AllowRotation();
}

bool URoleMovementComponent::SetDisableLocoJumpWeakValue(bool InDisableLocoJump, const FString& InTag, bool bNeedDoScriptLogic)
{
	if (!GetIsMainPlayer()) {
		return false;
	}
	
	bool OldAllowLocoJump = AllowProactiveJump();
	if (InDisableLocoJump) {
		if (IsDisableLocoJumpCountMap.Contains(InTag)){
			IsDisableLocoJumpCountMap[InTag] += 1;
		}
		else {
			IsDisableLocoJumpCountMap.Add(InTag, 1);
		}
	}
	else {
		if (IsDisableLocoJumpCountMap.Contains(InTag))
		{
			IsDisableLocoJumpCountMap[InTag] -= 1;
			if (IsDisableLocoJumpCountMap[InTag] == 0) {
				IsDisableLocoJumpCountMap.Remove(InTag);
			}
		}
		else {
			UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoJumpWeakValue Error! No Tag:%s to Remove!"), *InTag);
		}
	}

	if (IsDisableLocoJumpForceValue.IsSet())
	{
		return false;
	}

	bool NewAllowLocoJump = IsDisableLocoJumpCountMap.IsEmpty();
	if (NewAllowLocoJump != OldAllowLocoJump)
	{
		ChangeDisableProactiveJump(!NewAllowLocoJump);
		if (bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableProactiveJump", !NewAllowLocoJump);
			}
		}
	}

	return NewAllowLocoJump != OldAllowLocoJump;
}

bool URoleMovementComponent::SetDisableLocoJumpForceValue(bool InDisableLocoJump, const FString& InTag, bool bNeedDoScriptLogic)
{
	if (!GetIsMainPlayer()) {
		return false;
	}

	if (IsDisableLocoJumpForceValueTag.IsSet() && IsDisableLocoJumpForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoJumpForceValue Error! Already Has ForceTag:%s, InTag:%s"), *IsDisableLocoJumpForceValueTag.GetValue(), *InTag);
		return false;
	}
	bool OldAllowLocoJump = AllowProactiveJump();
	IsDisableLocoJumpForceValueTag = InTag;
	IsDisableLocoJumpForceValue = InDisableLocoJump;
	bool NewAllowLocoJump = !IsDisableLocoJumpForceValue.GetValue();

	if (NewAllowLocoJump != OldAllowLocoJump)
	{
		ChangeDisableProactiveJump(!NewAllowLocoJump);
		if (bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableProactiveJump", !NewAllowLocoJump);
			}
		}
	}

	return NewAllowLocoJump != OldAllowLocoJump;
}

bool URoleMovementComponent::ClearDisableLocoJumpForceValue(const FString& InTag, bool bNeedDoScriptLogic)
{
	if (!GetIsMainPlayer()) {
		return false;
	}

	if (!IsDisableLocoJumpForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoJumpForceValue Error! No Force Tag"));
		return false;
	}
	else if (IsDisableLocoJumpForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoJumpForceValue Error! CurForceTag:%s, InTag:%s"), *IsDisableLocoJumpForceValueTag.GetValue(), *InTag);
		return false;
	}

	bool OldAllowLocoJump = AllowProactiveJump();
	IsDisableLocoJumpForceValueTag.Reset();
	IsDisableLocoJumpForceValue.Reset();
	bool NewAllowLocoJump = IsDisableLocoJumpCountMap.IsEmpty();

	if (NewAllowLocoJump != OldAllowLocoJump)
	{
		ChangeDisableProactiveJump(!NewAllowLocoJump);
		if (bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableProactiveJump", !NewAllowLocoJump);
			}
		}
	}

	return NewAllowLocoJump != OldAllowLocoJump;
}

bool URoleMovementComponent::ResetDisableLocoJump(bool bNeedDoScriptLogic)
{
	if (!GetIsMainPlayer()) {
		return false;
	}

	bool OldAllowLocoJump = AllowProactiveJump();

	IsDisableLocoJumpForceValueTag.Reset();
	IsDisableLocoJumpForceValue.Reset();
	IsDisableLocoJumpCountMap.Empty();

	bool NewAllowLocoJump = true;

	if (NewAllowLocoJump != OldAllowLocoJump)
	{
		ChangeDisableProactiveJump(!NewAllowLocoJump);
		if (bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableProactiveJump", !NewAllowLocoJump);
			}
		}
	}

	return NewAllowLocoJump != OldAllowLocoJump;
}

bool URoleMovementComponent::CheckDisableLocoJumpHasTag(const FString& InTag)
{
	return IsDisableLocoJumpCountMap.Contains(InTag) || (IsDisableLocoJumpForceValueTag.IsSet() && IsDisableLocoJumpForceValueTag.GetValue() == InTag);
}

bool URoleMovementComponent::SetDisableLocoDodgeWeakValue(bool InDisableLocoDodge, const FString& InTag, bool bNeedDoScriptLogic)
{
	if (!GetIsMainPlayer()) {
		return false;
	}

	bool OldAllowLocoDodge = AllowProactiveDodge();
	if (InDisableLocoDodge) {
		if (IsDisableLocoDodgeCountMap.Contains(InTag)) {
			IsDisableLocoDodgeCountMap[InTag] += 1;
		}
		else {
			IsDisableLocoDodgeCountMap.Add(InTag, 1);
		}
	}
	else {
		if (IsDisableLocoDodgeCountMap.Contains(InTag))
		{
			IsDisableLocoDodgeCountMap[InTag] -= 1;
			if (IsDisableLocoDodgeCountMap[InTag] == 0) {
				IsDisableLocoDodgeCountMap.Remove(InTag);
			}
		}
		else {
			UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoDodgeWeakValue Error! No Tag:%s to Remove!"), *InTag);
		}
	}

	if (IsDisableLocoDodgeForceValue.IsSet())
	{
		return false;
	}

	bool NewAllowLocoDodge = IsDisableLocoDodgeCountMap.IsEmpty();
	if (NewAllowLocoDodge != OldAllowLocoDodge)
	{
		ChangeDisableProactiveDodge(!NewAllowLocoDodge);
		if (bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableProactiveDodge", !NewAllowLocoDodge);
			}
		}
	}

	return NewAllowLocoDodge != OldAllowLocoDodge;
}

bool URoleMovementComponent::SetDisableLocoDodgeForceValue(bool InDisableLocoDodge, const FString& InTag, bool bNeedDoScriptLogic)
{
	if (!GetIsMainPlayer()) {
		return false;
	}

	if (IsDisableLocoDodgeForceValueTag.IsSet() && IsDisableLocoDodgeForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoDodgeForceValue Error! Already Has ForceTag:%s, InTag:%s"), *IsDisableLocoDodgeForceValueTag.GetValue(), *InTag);
		return false;
	}
	bool OldAllowLocoDodge = AllowProactiveDodge();
	IsDisableLocoDodgeForceValueTag = InTag;
	IsDisableLocoDodgeForceValue = InDisableLocoDodge;
	bool NewAllowLocoDodge = !IsDisableLocoDodgeForceValue.GetValue();

	if (NewAllowLocoDodge != OldAllowLocoDodge)
	{
		ChangeDisableProactiveDodge(!NewAllowLocoDodge);
		if (bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableProactiveDodge", !NewAllowLocoDodge);
			}
		}
	}

	return NewAllowLocoDodge != OldAllowLocoDodge;
}

bool URoleMovementComponent::ClearDisableLocoDodgeForceValue(const FString& InTag, bool bNeedDoScriptLogic)
{
	if (!GetIsMainPlayer()) {
		return false;
	}

	if (!IsDisableLocoDodgeForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoDodgeForceValue Error! No Force Tag"));
		return false;
	}
	else if (IsDisableLocoDodgeForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoDodgeForceValue Error! CurForceTag:%s, InTag:%s"), *IsDisableLocoDodgeForceValueTag.GetValue(), *InTag);
		return false;
	}

	bool OldAllowLocoDodge = AllowProactiveDodge();
	IsDisableLocoDodgeForceValueTag.Reset();
	IsDisableLocoDodgeForceValue.Reset();
	bool NewAllowLocoDodge = IsDisableLocoDodgeCountMap.IsEmpty();

	if (NewAllowLocoDodge != OldAllowLocoDodge)
	{
		ChangeDisableProactiveDodge(!NewAllowLocoDodge);
		if (bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableProactiveDodge", !NewAllowLocoDodge);
			}
		}
	}

	return NewAllowLocoDodge != OldAllowLocoDodge;
}

bool URoleMovementComponent::ResetDisableLocoDodge(bool bNeedDoScriptLogic)
{
	if (!GetIsMainPlayer()) {
		return false;
	}

	bool OldAllowLocoDodge = AllowProactiveDodge();

	IsDisableLocoDodgeForceValueTag.Reset();
	IsDisableLocoDodgeForceValue.Reset();
	IsDisableLocoDodgeCountMap.Empty();

	bool NewAllowLocoDodge = true;

	if (NewAllowLocoDodge != OldAllowLocoDodge)
	{
		ChangeDisableProactiveDodge(!NewAllowLocoDodge);
		if (bNeedDoScriptLogic) {
			if (ABaseCharacter* Character = Cast<ABaseCharacter>(CharacterOwner)) {
				ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoScriptLogicForDisableProactiveDodge", !NewAllowLocoDodge);
			}
		}
	}

	return NewAllowLocoDodge != OldAllowLocoDodge;
}

bool URoleMovementComponent::CheckDisableLocoDodgeHasTag(const FString& InTag)
{
	return IsDisableLocoDodgeCountMap.Contains(InTag) || (IsDisableLocoDodgeForceValueTag.IsSet() && IsDisableLocoDodgeForceValueTag.GetValue() == InTag);
}

bool URoleMovementComponent::SetDisableLocoRotateWeakValue(bool InDisableLocoRotate, const FString& InTag)
{
	bool OldAllowLocoRotation = !bDisableProactiveRotation;
	if (InDisableLocoRotate) {
		if (IsDisableLocoRotateCountMap.Contains(InTag))
		{
			IsDisableLocoRotateCountMap[InTag] += 1;
		}
		else {
			IsDisableLocoRotateCountMap.Add(InTag, 1);
		}
	}
	else {
		if (IsDisableLocoRotateCountMap.Contains(InTag))
		{
			IsDisableLocoRotateCountMap[InTag] -= 1;
			if (IsDisableLocoRotateCountMap[InTag] == 0) {
				IsDisableLocoRotateCountMap.Remove(InTag);
			}
		}
		else {
			UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoRotateWeakValue Error! No Tag:%s to Remove!"), *InTag);
		}
	}

	if (IsDisableLocoRotateForceValue.IsSet())
	{
		return !bDisableProactiveRotation;
	}

	bool NewAllowLocoRotation = IsDisableLocoRotateCountMap.IsEmpty();
	if (NewAllowLocoRotation != OldAllowLocoRotation)
	{
		ChangeDisableProactiveRotation(!NewAllowLocoRotation);
	}

	return !bDisableProactiveRotation;
}

bool URoleMovementComponent::SetDisableLocoRotateForceValue(bool InDisableLocoRotate, const FString& InTag)
{
	if (IsDisableLocoRotateForceValueTag.IsSet() && IsDisableLocoRotateForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetDisableLocoRotateForceValue Error! Already Has ForceTag:%s, InTag:%s"), *IsDisableLocoRotateForceValueTag.GetValue(), *InTag);
		return !bDisableProactiveRotation;
	}
	bool OldAllowLocoRotation = !bDisableProactiveRotation;
	IsDisableLocoRotateForceValueTag = InTag;
	IsDisableLocoRotateForceValue = InDisableLocoRotate;
	bool NewAllowLocoRotation = !IsDisableLocoRotateForceValue.GetValue();

	if (NewAllowLocoRotation != OldAllowLocoRotation)
	{
		ChangeDisableProactiveRotation(!NewAllowLocoRotation);
	}

	return !bDisableProactiveRotation;
}

bool URoleMovementComponent::ClearDisableLocoRotateForceValue(const FString& InTag)
{
	if (!IsDisableLocoRotateForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoRotateForceValue Error! No Force Tag"));
		return !bDisableProactiveRotation;
	}
	else if (IsDisableLocoRotateForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearDisableLocoRotateForceValue Error! CurForceTag:%s, InTag:%s"), *IsDisableLocoRotateForceValueTag.GetValue(), *InTag);
		return !bDisableProactiveRotation;
	}

	bool OldAllowLocoRotation = !bDisableProactiveRotation;
	IsDisableLocoRotateForceValueTag.Reset();
	IsDisableLocoRotateForceValue.Reset();
	bool NewAllowLocoRotation = IsDisableLocoRotateCountMap.IsEmpty();

	if (NewAllowLocoRotation != OldAllowLocoRotation)
	{
		ChangeDisableProactiveRotation(!NewAllowLocoRotation);
	}

	return !bDisableProactiveRotation;
}

bool URoleMovementComponent::ResetDisableLocoRotate()
{
	bool OldAllowLocoRotation = !bDisableProactiveRotation;

	IsDisableLocoRotateForceValueTag.Reset();
	IsDisableLocoRotateForceValue.Reset();
	IsDisableLocoRotateCountMap.Empty();

	bool NewAllowLocoRotation = true;

	if (NewAllowLocoRotation != OldAllowLocoRotation)
	{
		ChangeDisableProactiveRotation(!NewAllowLocoRotation);
	}

	return !bDisableProactiveRotation;
}

EMoveDriveMode URoleMovementComponent::SetMoveDriveModeWeakValue(EMoveDriveMode InMoveDriveMode, const FString& InTag)
{
	MoveDriveModeWeakValue = InMoveDriveMode;
	MoveDriveModeWeakTag = InTag;

	if (MoveDriveModeForceValue.IsSet())
	{
		return eMoveDriveMode;
	}

	SetMoveDriveMode(MoveDriveModeWeakValue);
	return eMoveDriveMode;
}

EMoveDriveMode URoleMovementComponent::SetMoveDriveModeForceValue(EMoveDriveMode InMoveDriveMode, const FString& InTag)
{
	if (MoveDriveModeForceValueTag.IsSet() && MoveDriveModeForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetMoveDriveModeForceValue Error! Already Has ForceTag:%s, InTag:%s"), *MoveDriveModeForceValueTag.GetValue(), *InTag);
		return eMoveDriveMode;
	}

	MoveDriveModeForceValueTag = InTag;
	MoveDriveModeForceValue = InMoveDriveMode;

	SetMoveDriveMode(InMoveDriveMode);
	return eMoveDriveMode;
}

EMoveDriveMode URoleMovementComponent::ClearMoveDriveModeForceValue(const FString& InTag)
{
	if (!MoveDriveModeForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearMoveDriveModeForceValue Error! No Force Tag"));
		return eMoveDriveMode;
	}
	else if (MoveDriveModeForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearMoveDriveModeForceValue Error! CurForceTag:%s, InTag:%s"), *MoveDriveModeForceValueTag.GetValue(), *InTag);
		return eMoveDriveMode;
	}

	LocoInputThrusterForceValueTag.Reset();
	LocoInputThrusterForceValue.Reset();

	SetMoveDriveMode(MoveDriveModeWeakValue);
	return eMoveDriveMode;
}

EMoveDriveMode URoleMovementComponent::ResetMoveDriveMode()
{
	MoveDriveModeWeakValue = EMoveDriveMode::NoDrive;
	MoveDriveModeWeakTag = TEXT("Null");
	MoveDriveModeForceValue.Reset();
	MoveDriveModeForceValueTag.Reset();
	SetMoveDriveMode(MoveDriveModeWeakValue);
	
	return eMoveDriveMode;
}

bool URoleMovementComponent::SetUsingLateUpdateWeakValue(bool InUsingLateUpdate, const FString& InTag)
{
	if (InUsingLateUpdate) {
		UsingLateUpdateCountArray.AddUnique(InTag);
	}
	else {
		if (UsingLateUpdateCountArray.Contains(InTag)) {
			UsingLateUpdateCountArray.Remove(InTag);
		}
	}

	if (UsingLateUpdateForceValue.IsSet())
	{
		return GetUsingLateUpdate();
	}

	SetUsingLateUpdate(!UsingLateUpdateCountArray.IsEmpty());
	return GetUsingLateUpdate();
}

bool URoleMovementComponent::SetUsingLateUpdateForceValue(bool InUsingLateUpdate, const FString& InTag)
{
	if (UsingLateUpdateForceValueTag.IsSet() && UsingLateUpdateForceValueTag.GetValue() != InTag)
	{
		UE_LOG(LogTemp, Warning, TEXT("SetUsingLateUpdateForceValue Error! Already Has ForceTag:%s, InTag:%s"), *UsingLateUpdateForceValueTag.GetValue(), *InTag);
		return GetNeedFrameStickGround();
	}

	UsingLateUpdateForceValueTag = InTag;
	UsingLateUpdateForceValue = InUsingLateUpdate;

	SetUsingLateUpdate(UsingLateUpdateForceValue.GetValue());
	return GetUsingLateUpdate();
}

bool URoleMovementComponent::ClearUsingLateUpdateForceValue(const FString& InTag)
{
	if (!UsingLateUpdateForceValue.IsSet())
	{
		// UE_LOG(LogTemp, Warning, TEXT("ClearUsingLateUpdateForceValue Error! No Force Tag"));
		return GetUsingLateUpdate();
	}
	else if (UsingLateUpdateForceValueTag.GetValue() != InTag) {
		UE_LOG(LogTemp, Warning, TEXT("ClearUsingLateUpdateForceValue Error! CurForceTag:%s, InTag:%s"), *UsingLateUpdateForceValueTag.GetValue(), *InTag);
		return GetUsingLateUpdate();
	}

	UsingLateUpdateForceValueTag.Reset();
	UsingLateUpdateForceValue.Reset();

	SetUsingLateUpdate(!UsingLateUpdateCountArray.IsEmpty());
	return GetUsingLateUpdate();
}

bool URoleMovementComponent::ResetUsingLateUpdate()
{
	UsingLateUpdateForceValueTag.Reset();
	UsingLateUpdateForceValue.Reset();
	UsingLateUpdateCountArray.Empty();

	SetUsingLateUpdate(false);
	return GetUsingLateUpdate();
}
#pragma endregion PropertyControl

UE_ENABLE_OPTIMIZATION_SHIP
