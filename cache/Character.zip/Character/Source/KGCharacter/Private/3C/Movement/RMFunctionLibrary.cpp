#include "3C/Movement/RMFunctionLibrary.h"

#include "GameFramework/Character.h"
#include "Components/CapsuleComponent.h"

#include "Kismet/KismetSystemLibrary.h"



#pragma region Impetus

bool URMFunctionLibrary::GetCapsuleToCapsuleStaticImpetus(FVector OwnerLoc, float OwnerHalfHeight, float OwnerRadius, FVector OwnerForwadVector, FVector TargetLoc, float TargetHalfHeight, float TargetRadius, FVector& OutImpetusValue)
{
	if (OwnerHalfHeight < 0.0f || OwnerRadius < 0.0f || TargetHalfHeight < 0.0f || TargetRadius < 0.0f || OwnerForwadVector.IsNearlyZero())
	{
		UE_LOG(LogTemp, Warning, TEXT("RMFunctionLibrary::GetCapsuleToCapsuleStaticImpetus Param Error! OwnerHalfHeight:%f, OwnerRadius:%f, TargetHalfHeight:%f, TargetRadius:%f, OwnerForwadVector:%s"), 
			OwnerHalfHeight, OwnerRadius, TargetHalfHeight, TargetRadius, *OwnerForwadVector.ToString());
		return false;
	}

	//if (OwnerRadius > OwnerHalfHeight)
	//{
	//	OwnerHalfHeight = OwnerRadius;
	//}
	//if (TargetRadius > TargetHalfHeight)
	//{
	//	TargetHalfHeight = TargetRadius;
	//}

	if (FMath::Abs(OwnerLoc.Z - TargetLoc.Z) >= OwnerHalfHeight + TargetHalfHeight)
	{
		// 高度相差过大，不可能推挤
		OutImpetusValue = FVector::ZeroVector;
		return false;
	}

	FVector TargetToOwner2D = OwnerLoc - TargetLoc;
	TargetToOwner2D.Z = 0.0f;
	if (TargetToOwner2D.Size2D() >= OwnerRadius + TargetRadius)
	{
		// 水平位移相差过大，不可能推挤
		OutImpetusValue = FVector::ZeroVector;
		return false;
	}

	float ExpectedDistanece = OwnerRadius + TargetRadius;
	//if (FMath::Abs(OwnerLoc.Z - TargetLoc.Z) <= (OwnerHalfHeight - OwnerRadius + TargetHalfHeight - TargetRadius))
	//{
	//	// 竖直侧边重叠的情况，只需要通过半径计算推挤距离
	//	ExpectedDistanece = OwnerRadius + TargetRadius;
	//}
	//else
	//{
	//	// 圆弧边可能接触的情况

	//	// FMath::Abs(OwnerLoc.Z - TargetLoc.Z)范围在(OwnerHalfHeight - OwnerRadius + TargetHalfHeight - TargetRadius, OwnerHalfHeight + TargetHalfHeight)
	//	// 下面的CenterHeight范围在(0,OwnerRadius + TargetRadius)
	//	float CenterHeight = FMath::Abs(OwnerLoc.Z - TargetLoc.Z) - (OwnerHalfHeight - OwnerRadius + TargetHalfHeight - TargetRadius);
	//	ExpectedDistanece = FMath::Sqrt(FMath::Square(OwnerRadius + TargetRadius) - FMath::Square(CenterHeight));
	//}

	if (TargetToOwner2D.IsNearlyZero())
	{
		// 完全重合，按照Owner朝向反向退回去
		OutImpetusValue = -OwnerForwadVector.GetSafeNormal2D() * ExpectedDistanece;
		return true;
	}
	else if (TargetToOwner2D.Size2D() < ExpectedDistanece)
	{
		// 部分重合，按照TargetToOnwer方向退回去
		OutImpetusValue = TargetToOwner2D.GetSafeNormal2D() * (ExpectedDistanece - TargetToOwner2D.Size2D());
		return true;
	}

	OutImpetusValue = FVector::ZeroVector;
	return false;
}

float URMFunctionLibrary::GetCapsuleToCapsuleDynamicImpetus(FVector OwnerStartLoc, FVector OwnerMoveDelta, float OwnerHalfHeight, float OwnerRadius, FVector TargetLoc, float TargetHalfHeight, float TargetRadius, FVector& OutImpetusValue)
{
	if (OwnerHalfHeight < 0.0f || OwnerRadius < 0.0f || TargetHalfHeight < 0.0f || TargetRadius < 0.0f || OwnerMoveDelta.IsNearlyZero())
	{
		UE_LOG(LogTemp, Warning, TEXT("RMFunctionLibrary::GetCapsuleToCapsuleDynamicImpetus Param Error! OwnerHalfHeight:%f, OwnerRadius:%f, TargetHalfHeight:%f, TargetRadius:%f, OwnerMoveDelta:%s"),
			OwnerHalfHeight, OwnerRadius, TargetHalfHeight, TargetRadius, *OwnerMoveDelta.ToString());
		return 1.0f;
	}

	//if (OwnerRadius > OwnerHalfHeight)
	//{
	//	OwnerHalfHeight = OwnerRadius;
	//}
	//if (TargetRadius > TargetHalfHeight)
	//{
	//	TargetHalfHeight = TargetRadius;
	//}

	float tmin = 0.0f, tmax = 1.0f;
	// 开始检查高度有无重合
	if (FMath::Abs(OwnerMoveDelta.Z) < SMALL_NUMBER)
	{
		if (FMath::Abs(TargetLoc.Z - OwnerStartLoc.Z) <= (OwnerHalfHeight + TargetHalfHeight))
		{
			tmin = 0.0f;
			tmax = 1.0f;
		}
		else
		{
			// 高度相差过大，不可能推挤
			OutImpetusValue = FVector::ZeroVector;
			return 1.0f;
		}
	}
	else 
	{
		if (OwnerMoveDelta.Z > 0.0f)
		{
			tmax = (TargetLoc.Z + OwnerHalfHeight + TargetHalfHeight - OwnerStartLoc.Z) / OwnerMoveDelta.Z;
			tmin = (TargetLoc.Z - OwnerHalfHeight - TargetHalfHeight - OwnerStartLoc.Z) / OwnerMoveDelta.Z;
		}
		else
		{
			tmax = (TargetLoc.Z - OwnerHalfHeight - TargetHalfHeight - OwnerStartLoc.Z) / OwnerMoveDelta.Z;
			tmin = (TargetLoc.Z + OwnerHalfHeight + TargetHalfHeight - OwnerStartLoc.Z) / OwnerMoveDelta.Z;
		}

		if (tmin > 1.0f || tmax < 0.0f)
		{
			// 高度相差过大，不可能推挤
			OutImpetusValue = FVector::ZeroVector;
			return 1.0f;
		}
		else
		{
			tmin = FMath::Max(tmin, 0.0f);
			tmax = FMath::Min(tmax, 1.0f);
		}
	}

	float MinDistXY = URMFunctionLibrary::PointToSegmentDisInXY(TargetLoc, OwnerStartLoc, OwnerStartLoc + OwnerMoveDelta);
	if (MinDistXY >= OwnerRadius + TargetRadius)
	{
		// 水平位移相差过大，不可能推挤
		OutImpetusValue = FVector::ZeroVector;
		return 1.0f;
	}

	if (URMFunctionLibrary::GetCapsuleToCapsuleStaticImpetus(OwnerStartLoc, OwnerHalfHeight, OwnerRadius, OwnerMoveDelta, TargetLoc, TargetHalfHeight, TargetRadius, OutImpetusValue))
	{
		// 初始位置就有推挤，直接结束
		return 0.0f;
	}

	float a = FMath::Square(OwnerMoveDelta.X) + FMath::Square(OwnerMoveDelta.Y);
	float b = 2 * (OwnerMoveDelta.X * (OwnerStartLoc.X - TargetLoc.X) + OwnerMoveDelta.Y * (OwnerStartLoc.Y - TargetLoc.Y));
	float c = FMath::Square(OwnerStartLoc.X - TargetLoc.X) + FMath::Square(OwnerStartLoc.Y - TargetLoc.Y) - FMath::Square(OwnerRadius + TargetRadius);
	if ((b * b - 4 * a * c) >= 0)
	{
		float t1 = 0.5 * (-b + FMath::Sqrt(b * b - 4 * a * c)) / a;
		float t2 = 0.5 * (-b - FMath::Sqrt(b * b - 4 * a * c)) / a;
		if (t1 < tmin || t2 > tmax)
		{
			// 未找到可能推挤的点
			OutImpetusValue = FVector::ZeroVector;
			return 1.0f;
		}
		else
		{
			FVector ImpetusOwnerLocXY = OwnerStartLoc + OwnerMoveDelta * FMath::Min(tmax, t2);
			ImpetusOwnerLocXY.Z = 0.0f;
			FVector RemianOwnerMoveDeltaXY = OwnerMoveDelta * (1 - FMath::Min(tmax, t2));
			RemianOwnerMoveDeltaXY.Z = 0.0f;

			/*FVector ImpetusDirXY = ImpetusOwnerLocXY - TargetLoc;
			ImpetusDirXY = ImpetusDirXY.GetSafeNormal2D();
			OutImpetusValue = RemianOwnerMoveDeltaXY - RemianOwnerMoveDeltaXY.Dot(ImpetusDirXY) * ImpetusDirXY;*/

			FVector OwnerToTargetDirXY = TargetLoc - ImpetusOwnerLocXY;
			OwnerToTargetDirXY = OwnerToTargetDirXY.GetSafeNormal2D();
			OutImpetusValue = - RemianOwnerMoveDeltaXY.Dot(OwnerToTargetDirXY) * OwnerToTargetDirXY;
			
			return FMath::Min(tmax, t2);
		}
	}
	else
	{
		// 未找到可能推挤的点
		OutImpetusValue = FVector::ZeroVector;
		return 1.0f;
	}

	// OutImpetusValue = FVector::ZeroVector;
	// return 1.0f;
}
#pragma endregion Impetus



#pragma region Math
float URMFunctionLibrary::PointToSegmentDisInXY(const FVector& InP, const FVector& InLS, const FVector& InLE)
{
	FVector v1 = FVector(InP.X - InLS.X, InP.Y - InLS.Y, 0.0f);
	FVector v2 = FVector(InLE.X - InLS.X, InLE.Y - InLS.Y, 0.0f);
	float dot = v1.X * v2.X + v1.Y * v2.Y;
	if (dot <= 0) {
		return (InP - InLS).Size2D();
	}

	float length = (InLS - InLE).Size2D();
	if (dot >= length * length) {
		return (InP - InLE).Size2D();
	}

	float cross = v1.X * v2.Y - v1.Y * v2.X;
	return FMath::Abs(cross / length);
}
#pragma endregion Math