// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Movement/MovementPipeline/MovementCorrector/TwoRoleAnimCoordinateMC.h"
#include "3C/Movement/MovementPipeline/MovementContext.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Core/KGUEActorManager.h"
#include "Misc/MathFormula.h"
#include "Kismet/KismetSystemLibrary.h"
#include "3C/Util/KGUtils.h"
#include "3C/Character/BaseCharacter.h"
#include "Components/CapsuleComponent.h"

FTwoRoleAnimCoordinateMC::FTwoRoleAnimCoordinateMC()
{
}

FTwoRoleAnimCoordinateMC::~FTwoRoleAnimCoordinateMC()
{
}

void FTwoRoleAnimCoordinateMC::Init(MovementContext* MC)
{
}

void FTwoRoleAnimCoordinateMC::Reset(MovementContext* MC)
{
	InterpolationDuration = 0;
}



bool FTwoRoleAnimCoordinateMC::DoMovementCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
{
	auto * ActorMgr = UKGUEActorManager::GetInstance(MovementComponent.GetWorld());
	if(!ActorMgr)
	{
		return false;
	}
	
	auto *OwnCppEntityPtr = ActorMgr->GetLuaEntityByActor(MovementComponent.GetOwner());
	if(!OwnCppEntityPtr)
	{
		return false;
	}

	if(!CollaboratorRoleAnimSeq.IsValid())
	{
		auto * CppEntityPtr= ActorMgr->GetLuaEntity(CollaboratorRoleUID);
		if(!CppEntityPtr)
		{
			return false;
		}

		CollaboratorRoleAnimSeq = CppEntityPtr->GetFirstAnimSequenceByAnimPlayID(CollaboratorRoleAnimID);
	}

	if(!MainRoleAnimSeq.IsValid())
	{
		if(!OwnCppEntityPtr)
		{
			return false;
		}

		MainRoleAnimSeq = OwnCppEntityPtr->GetFirstAnimSequenceByAnimPlayID(MainRoleAnimID);
	}

	if(!CollaboratorRoleAnimSeq.IsValid() || !MainRoleAnimSeq.IsValid())
	{
		return false;
	}

	ABaseCharacter * CollChar = Cast<ABaseCharacter>(ActorMgr->GetActorByEntityID(CollaboratorRoleUID));
	if(!CollChar)
	{
		return false;
	}

	URoleMovementComponent * CollRMC = Cast<URoleMovementComponent>(CollChar->GetMovementComponent());
	if(!CollRMC)
	{
		return false;
	}
	
	UCapsuleComponent* CapsuleComp = CollChar->GetCapsuleComponent();
	if (!CapsuleComp)
	{
		return false;
	}

	InterpolationDuration += DeltaTime;
	float InterAlpha = 1.0f;
	if(InterpolationDuration < LinearInterpolateTime)
	{
		InterAlpha = InterpolationDuration / LinearInterpolateTime;
	}
	
	float PlayedTime = OwnCppEntityPtr->GetFirstAnimSequencePlayTimeByAnimPlayID(MainRoleAnimID) + DeltaTime;
	FTransform MainTrans = MainRoleAnimSeq->ExtractRootTrackTransform(PlayedTime, nullptr);
	FTransform CollTrans = CollaboratorRoleAnimSeq->ExtractRootTrackTransform(PlayedTime, nullptr);
	FTransform RelativeTrans = CollTrans.GetRelativeTransform(MainTrans);
	
	// 这里的运算, 需要考虑资源上的旋转90度
	CollRMC->FixSampledRootMotionTransByMeshFaceRotate(RelativeTrans, true);
	FTransform CurMainRoleTrans = MC.GetCurrentActorTransform();
	CurMainRoleTrans.SetLocation(MC.GetMeshWorldTransform().GetLocation());
	FTransform FinalTrans = RelativeTrans * CurMainRoleTrans;
	
	FVector FinalPos = FinalTrans.GetLocation();
	FinalPos.Z += CapsuleComp->GetScaledCapsuleHalfHeight();
	
	FVector CurCollPos = CollRMC->GetLocation();
	FQuat CurRot = CollRMC->GetActorTransform().GetRotation();
	
	CollRMC->ProduceReplacedFinalWorldPosDelta((FinalPos - CurCollPos) * InterAlpha, true, true, true);
	CollRMC->ProduceReplacedFinalWorldRotation(FQuat::Slerp(CurRot, FinalTrans.GetRotation(), InterAlpha), true, true, true);
	
	return true;
}

void FTwoRoleAnimCoordinateMC::SetTwoRoleCoordinateParams(KGAnimPlayReqID MainAnimID, KGAnimPlayReqID CollaboratorAnimID, KGEntityID CollaboratorUID, bool EnsureSafe, float InterTime)
{
	MainRoleAnimID = MainAnimID;
	CollaboratorRoleAnimID = CollaboratorAnimID;
	CollaboratorRoleUID = CollaboratorUID;
	EnsureMovePhysicSafe = EnsureSafe;
	LinearInterpolateTime = InterTime;
}

#if UE_BUILD_DEVELOPMENT
void FTwoRoleAnimCoordinateMC::AppendDebugInfo(FString& infoOut)
{
	infoOut.Append(TEXT("===================<Title_Blue>FTwoRoleAnimCoordinateMC</>===================\n"));
	infoOut.Appendf(TEXT("MainRoleAnimID:%d  CollaboratorRoleAnimID:%d  CollaboratorRoleUID:%d  EnsureMovePhysicSafe%d \n"),
		MainRoleAnimID, CollaboratorRoleAnimID, CollaboratorRoleUID, EnsureMovePhysicSafe);
	infoOut.Appendf(TEXT("HasMainAnimSeq:%s  HasCollaAnimSeq:%s\n"),
		MainRoleAnimSeq.IsValid()? *(MainRoleAnimSeq->GetPathName()): *FString("None"),
		CollaboratorRoleAnimSeq.IsValid()? *(CollaboratorRoleAnimSeq->GetPathName()): *FString("None"));
}
#endif