#include "3C/Movement/MovementPipeline/PostureCorrector/PostureCorrectorManager.h"
#include "3C/Movement/MovementPipeline/PostureCorrector/PitchAdjustOnSurfacePCB.h"
#include  "3C/Movement/RoleMovementComponent.h"

FPostureCorrectorManager::FPostureCorrectorManager()
{
}

FPostureCorrectorManager::~FPostureCorrectorManager()
{
	for (int index = 0; index < (int)EPostureCorrectorType::Max; ++index) {
		auto correctorPtr = PostureCorrectors[index];
		if (correctorPtr != nullptr) {
			correctorPtr->Reset(*MoveContext);
			delete correctorPtr;
		}
		PostureCorrectors[index] = nullptr;
	}
	Owner = nullptr;
	MoveContext = nullptr;
}

void FPostureCorrectorManager::Init(URoleMovementComponent& MovementComponent)
{
	CurActiveType = EPostureCorrectorType::None;
	for (int index = 0; index < (int)EPostureCorrectorType::Max; ++index)
	{
		PostureCorrectorTokens[index] = 1;
	}
	Owner = &MovementComponent;
	MoveContext = &Owner->GetRoleMP().GetMovementContext();
}

bool FPostureCorrectorManager::DoPostureCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
{
	EPostureCorrectorType WorkingType = GetActiveType();

	if (WorkingType != EPostureCorrectorType::None)
	{
		if (PostureCorrectors[(int)WorkingType] != nullptr)
		{
			PostureCorrectors[(int)WorkingType]->DoPostureCorrection(MovementComponent, MC, DeltaTime);
			return true;
		}
	}
	return false;
}

// todo 先不做基于优先级的管理, 后面需要的时候再添加, 并且要和MoveCorrectorManager进行结构整合 @孙亚
bool FPostureCorrectorManager::EnsurePostureCorrectorAvailable(ECorrectorObtainPriority pri, EPostureCorrectorType MovementCorrectorType, const MovementContext & MC)
{
	const int TypeIndex = (int)MovementCorrectorType;

	if (PostureCorrectors[TypeIndex] == nullptr)
	{
		PostureCorrectors[TypeIndex] = CreatePostureCorrector(MovementCorrectorType, MC);
		if(PostureCorrectors[TypeIndex] == nullptr)
		{
			return false;
		}
		
		PostureCorrectors[TypeIndex]->Reset(MC);
	}

	return true;
}

FPostureCorrectorBase* FPostureCorrectorManager::CreatePostureCorrector(EPostureCorrectorType PostureCorrectorType, const MovementContext & MC)
{
	FPostureCorrectorBase* NewCorrector = nullptr;
	switch (PostureCorrectorType)
	{
	case EPostureCorrectorType::PitchAdjustOnSurfacePCB:
		NewCorrector = new FPitchAdjustOnSurfacePCB();
		break;
	default:
		break;
	}

	if (NewCorrector == nullptr) {
		return nullptr;
	}
	NewCorrector->Init(MC);
	return NewCorrector;
}

EPostureCorrectorType FPostureCorrectorManager::GetActiveType() const
{
	return CurActiveType;
}

void FPostureCorrectorManager::UpdateCurActiveType(EPostureCorrectorType PreferedTypeWhenEqual, const MovementContext& MC)
{
	CurActiveType = PreferedTypeWhenEqual;
	
	PostureCorrectors[(int)PreferedTypeWhenEqual]->Reset(MC);
}

bool FPostureCorrectorManager::ReleasePostureCorrector(int releasedToken, EPostureCorrectorType mcType)
{
	int mcIndex = (int)mcType;

	auto* mc = PostureCorrectors[mcIndex];
	if (mc == nullptr)
	{
		return false;
	}

	if (PostureCorrectorTokens[mcIndex] != releasedToken)
	{
		return false;
	}

	CurActiveType = EPostureCorrectorType::None;
	return true;
}

// ========================================一系列的对外开放的Obtain/Release接口===============================
int FPostureCorrectorManager::ObtainPitchAdjustCorrector(
	float XForward, float YForward, float XBackward, float YBackward, float MinHeight, float MaxHeight, float DetectDistance, float HalflifeTime, TArray<int32> & DetectObjectTypes)
{
	EPostureCorrectorType PcType = EPostureCorrectorType::PitchAdjustOnSurfacePCB;
	int mcIndex = (int)EPostureCorrectorType::PitchAdjustOnSurfacePCB;

	if(CurActiveType != EPostureCorrectorType::None)
	{
		UE_LOG(LogTemp, Error, TEXT("[FPostureCorrectorManager::ObtainPitchAdjustCorrector]Already Has Acitvated Posture Corrector :%d"), CurActiveType);
		return -1;
	}

	if(!Owner.IsValid())
	{
		return -1;
	}

	const auto & MC = Owner->GetRoleMP().GetMovementContext();
	if(!EnsurePostureCorrectorAvailable(ECorrectorObtainPriority::NoUsed, PcType, MC))
	{
		UE_LOG(LogTemp, Error, TEXT("[FPostureCorrectorManager::ObtainPitchAdjustCorrector] Cannot Ensure Posture Corrector :%d"), CurActiveType);
		return -1;
	}

	auto* PostureCorrector = static_cast<FPitchAdjustOnSurfacePCB*>(PostureCorrectors[mcIndex]);
	if(!PostureCorrector)
	{
		UE_LOG(LogTemp, Error, TEXT("[FPostureCorrectorManager::ObtainPitchAdjustCorrector] Cannot Ensure FPitchAdjustOnSurfacePCB Posture Corrector :%d"), CurActiveType);
		return -1;
	}
	
	PostureCorrectorTokens[mcIndex] += 1;
	const int MAX_TOKEN = 86400;
	if (PostureCorrectorTokens[mcIndex] > MAX_TOKEN)
	{
		PostureCorrectorTokens[mcIndex] = 1;
	}


	UpdateCurActiveType(PcType, MC);

	PostureCorrector->StartPitchAdjust(XForward, YForward, XBackward, YBackward, MinHeight, MaxHeight,  DetectDistance, HalflifeTime, DetectObjectTypes);

	return PostureCorrectorTokens[mcIndex];
}

void FPostureCorrectorManager::ReleasePitchAdjustCorrector(int Token)
{
	ReleasePostureCorrector(Token, EPostureCorrectorType::PitchAdjustOnSurfacePCB);
}

// ========================================一系列的对外开放的Obtain/Release接口 END===============================

#if UE_BUILD_DEVELOPMENT
void FPostureCorrectorManager::AppendDebugInfo(FString& infoOut)
{
	EPostureCorrectorType WorkingType = GetActiveType();
	if (WorkingType != EPostureCorrectorType::None)
	{
		if (PostureCorrectors[(int)WorkingType] != nullptr)
		{
			PostureCorrectors[(int)WorkingType]->AppendDebugInfo(infoOut);
		}
	}
};
#endif
