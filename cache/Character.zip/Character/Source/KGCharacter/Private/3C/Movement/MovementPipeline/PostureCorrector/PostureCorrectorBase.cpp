#include "3C/Movement/MovementPipeline/PostureCorrector/PostureCorrectorBase.h"

FPostureCorrectorBase::FPostureCorrectorBase()
{
}

FPostureCorrectorBase::~FPostureCorrectorBase()
{
}

// 注意, 姿态计算调整是要等前面所有计算环节完毕, 得到能够作为基准的World Trans才能做, 所以这里就提前进行管线中的结果获取
FTransform FPostureCorrectorBase::GetCurActorTransformForPostureCorrection(const MovementContext & MC)
{
	auto CurTrans = MC.GetCurrentActorTransform();
	FQuat FinalRot = MC.GetFinalWorldRot(CurTrans.GetRotation());
	// 这里位移获取要注意, 是使用当前快照的旋转进行世界位置的获取, 要跟CalculateMovement一样
	CurTrans.SetTranslation(CurTrans.GetTranslation() + MC.GetFinalWorldPosDelta(CurTrans.GetRotation()));
	CurTrans.SetRotation(FinalRot);
	return CurTrans;
}

#if UE_BUILD_DEVELOPMENT
void FPostureCorrectorBase::AppendDebugInfo(FString& infoOut)
{
	
}
#endif