#include "3C/Movement/SplineController/SplineController.h"
#include "3C/Movement/SplineController/SplineStationControl.h"
#include  "3C/Movement/RoleMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "3C/Character/BaseCharacter.h"

FSplineController::FSplineController()
{
}

FSplineController::~FSplineController()
{
	for (int index = 0; index < (int)ESplineControlType::Max; ++index) {
		auto ControllerPtr = Controllers[index];
		if (ControllerPtr != nullptr) {
			ControllerPtr->Reset();
			delete ControllerPtr;
		}
		Controllers[index] = nullptr;
	}
	Owner = nullptr;
}

void FSplineController::Init(URoleMovementComponent& MovementComponent)
{
	CurActiveType = ESplineControlType::None;
	for (int index = 0; index < (int)ESplineControlType::Max; ++index)
	{
		SplineControlTokens[index] = 1;
	}
	Owner = &MovementComponent;
	
	if (ACharacter* Character = Owner.Get()->GetCharacterOwner())
	{
		if (UCapsuleComponent* CapsuleComponent = Character->GetCapsuleComponent())
		{
			CapsuleComponent->GetScaledCapsuleSize(OwnerCapsuleRadius, OwnerCapsuleHalfHeight);
		}
	}
}

bool FSplineController::TickSplineMove(URoleMovementComponent& MovementComponent, float DeltaTime)
{
	ESplineControlType WorkingType = GetActiveType();

	if (WorkingType != ESplineControlType::None)
	{
		if (Controllers[(int)WorkingType] != nullptr)
		{
			return Controllers[(int)WorkingType]->TickSplineMove(MovementComponent, DeltaTime);
		}
	}
	return false;
}

bool FSplineController::EnsureSplineControlAvailable(ESplineControlType MovementControllerType)
{
	const int TypeIndex = (int)MovementControllerType;

	if (Controllers[TypeIndex] == nullptr)
	{
		Controllers[TypeIndex] = CreateSplineController(MovementControllerType);
		if(Controllers[TypeIndex] == nullptr)
		{
			return false;
		}
		
		Controllers[TypeIndex]->Reset();
	}

	return true;
}

FSplineControlBase* FSplineController::CreateSplineController(ESplineControlType SplineControllType)
{
	FSplineStationControl* NewController = nullptr;
	switch (SplineControllType)
	{
	case ESplineControlType::Station:
		NewController = new FSplineStationControl();
		break;
	default:
		break;
	}

	if (NewController == nullptr) {
		return nullptr;
	}
	return NewController;
}

ESplineControlType FSplineController::GetActiveType() const
{
	return CurActiveType;
}

void FSplineController::UpdateCurActiveType(ESplineControlType PreferedTypeWhenEqual)
{
	CurActiveType = PreferedTypeWhenEqual;
	
	Controllers[(int)PreferedTypeWhenEqual]->Reset();
}

bool FSplineController::ReleaseSplineController(int releasedToken, ESplineControlType mcType)
{
	int mcIndex = (int)mcType;

	auto* mc = Controllers[mcIndex];
	if (mc == nullptr)
	{
		return false;
	}

	if (SplineControlTokens[mcIndex] != releasedToken)
	{
		return false;
	}

	CurActiveType = ESplineControlType::None;
	return true;
}

// ========================================一系列的对外开放的Obtain/Release接口===============================
int FSplineController::ObtainSplineStationController(const FString InSplineInsID, const float MaxSpeed, const uint8 MoveFlag)
{
	ESplineControlType Type = ESplineControlType::Station;
	int mcIndex = (int)ESplineControlType::Station;

	if(CurActiveType != ESplineControlType::None)
	{
		UE_LOG(LogTemp, Error, TEXT("[FSplineController::ObtainPitchAdjustController]Already Has Acitvated Posture Controller :%d"), CurActiveType);
		return -1;
	}

	if(!Owner.IsValid())
	{
		return -1;
	}
	
	if(!EnsureSplineControlAvailable(Type))
	{
		UE_LOG(LogTemp, Error, TEXT("[FSplineController::ObtainSplineStationControl] Cannot Ensure Posture Controller :%d"), CurActiveType);
		return -1;
	}

	auto* SplineControll = static_cast<FSplineStationControl*>(Controllers[mcIndex]);
	if(!SplineControll)
	{
		UE_LOG(LogTemp, Error, TEXT("[FSplineController::ObtainSplineStationControl] Cannot Ensure FStation Posture Controller :%d"), CurActiveType);
		return -1;
	}
	
	SplineControlTokens[mcIndex] += 1;
	const int MAX_TOKEN = 86400;
	if (SplineControlTokens[mcIndex] > MAX_TOKEN)
	{
		SplineControlTokens[mcIndex] = 1;
	}

	UpdateCurActiveType(Type);
	
	SplineControll->Init(OwnerCapsuleHalfHeight, OwnerCapsuleRadius, InSplineInsID);
	SplineControll->SetupMoveInfo(MaxSpeed, MoveFlag);
	
	return SplineControlTokens[mcIndex];
}

bool FSplineController::RestartSplineStationController(int Token, uint8 MoveFlag)
{
	int mcIndex = (int)ESplineControlType::Station;
	auto* mc = Controllers[mcIndex];
	if (mc == nullptr)
	{
		return false;
	}
	if (SplineControlTokens[mcIndex] != Token)
	{
		return false;
	}
	auto* SplineControll = static_cast<FSplineStationControl*>(Controllers[mcIndex]);
	if(!SplineControll)
	{
		return false;
	}
	return SplineControll->RestartWithMoveFlag(MoveFlag);
}

bool FSplineController::ReleaseSplineStationController(int Token)
{
	return ReleaseSplineController(Token, ESplineControlType::Station);
}

// ========================================一系列的对外开放的Obtain/Release接口 END===============================

#if UE_BUILD_DEVELOPMENT
void FSplineController::AppendDebugInfo(FString& infoOut)
{
	ESplineControlType WorkingType = GetActiveType();
	if (WorkingType != ESplineControlType::None)
	{
		if (Controllers[(int)WorkingType] != nullptr)
		{
			Controllers[(int)WorkingType]->AppendDebugInfo(infoOut);
		}
	}
};
#endif
