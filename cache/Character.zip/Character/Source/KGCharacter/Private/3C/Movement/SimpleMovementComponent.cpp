#include "3C/Movement/SimpleMovementComponent.h"

#include "KGCharacterModule.h"
#include "Manager/KGCppAssetManager.h"
#include "3C/Core/KGUEActorManager.h"
#include "3C/Util/KGUtils.h"
#include "KGWaterSubsystem.h"
#include "Misc/ObjCrashCollector.h"
#include "WaterDynamicLocalWaveSubsystem.h"
#include "GameFramework/Actor.h"
#include "3C/Interactor/WorldManager.h"

USimpleMovementComponent::USimpleMovementComponent(const FObjectInitializer& ObjectInitializer) :
                                                                                                Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
}

void USimpleMovementComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	AActor* Owner = GetOwner();
	if (SimpleMovementContext.CurRootMotion.IsValid() && Owner)
	{
		FVector TranslationDelta = FVector::ZeroVector;
		FQuat RotDelta = FQuat::Identity;
		SimpleMovementContext.CurRootMotion->Update(DeltaTime, *Owner, TranslationDelta, RotDelta);
		// 检查是否已经结束
		if (SimpleMovementContext.CurRootMotion->IsFinish())
		{
			SimpleMovementContext.CurRootMotion.Reset();
			SetComponentTickEnabled(false);
		}
			
		FVector TargetLoc = Owner->GetActorLocation() + TranslationDelta;
		FRotator TargetRot = Owner->GetActorRotation() + RotDelta.Rotator();
		Owner->SetActorLocation(TargetLoc);
		Owner->SetActorRotation(TargetRot);
		
		if (EnableWaterWave)
		{
			bool IsWaterDetectedByWaterSubsystem = false;
			float WaterSubSystemWaterDepth = 0.0f;
			float WaterSubSystemWaterHeight = 0.0f;
			if (const UKGWaterSubsystem* WaterSubsystem = UKGWaterSubsystem::GetWaterSubsystem(Owner->GetWorld()))
			{
				WaterSubSystemWaterDepth = WaterSubsystem->GetWaterDepth(TargetLoc);
				WaterSubSystemWaterHeight = WaterSubsystem->GetWaterHeight(TargetLoc);
				if (WaterSubSystemWaterDepth > 0.0f)
				{
					IsWaterDetectedByWaterSubsystem = true;
				}
			}

			const float NearlyWaterDistance = fabs(TargetLoc.Z - ActorRadiusForWaterWave - WaterSubSystemWaterHeight);
			if(IsWaterDetectedByWaterSubsystem && WaterSubSystemWaterDepth > WaterDepthThreshold && NearlyWaterDistance < WaterWaveDistanceThreshold)
			{
				if (UWorldManager* WorldMgr = UWorldManager::GetInstance(Owner))
				{
					WorldMgr->ExecuteMotorForDynamicWaterWave(WaterWaveMotorTypeID, TargetLoc.X, TargetLoc.Y, TargetRot.Yaw,
					WaterWaveScaleX*ActorRadiusForWaterWave, WaterWaveScaleY*ActorRadiusForWaterWave, WaterWaveMaxHeight, WaterWaveFoamScale);
				}
			}
		}
	}
}

void USimpleMovementComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	StopCurrentMove();
	
	Super::EndPlay(EndPlayReason);
}
	
void USimpleMovementComponent::AddWaterWavDetectParam(bool InEnable, float InWaterDepthThreshold, float InWaterWaveDistanceThreshold, float InActorRadiusForWaterWave)
{
	this->EnableWaterWave = InEnable;
	this->WaterDepthThreshold = InWaterDepthThreshold;
	this->WaterWaveDistanceThreshold = InWaterWaveDistanceThreshold;
	this->ActorRadiusForWaterWave = InActorRadiusForWaterWave;
}

void USimpleMovementComponent::AddWaterWaveMoveParam(int InMotorTypeID, float InWaterWaveScaleX, float InWaterWaveScaleY, float InWaterWaveMaxHeight, float InWaterWaveFoamScale)
{
	this->WaterWaveMotorTypeID = InMotorTypeID;
	this->WaterWaveScaleX = InWaterWaveScaleX;
	this->WaterWaveScaleY = InWaterWaveScaleY;
	this->WaterWaveMaxHeight = InWaterWaveMaxHeight;
	this->WaterWaveFoamScale = InWaterWaveFoamScale;
}

int32 USimpleMovementComponent::AddMoveLinearSpeed(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InDuration, bool KeepGravity)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());

	FVector InEnd(EndPosX, EndPosY, EndPosZ);
	check(!InEnd.ContainsNaN());

	SetMovable();
	StopCurrentMove();
	TSharedPtr<FC7RootMotion_Move3D> Move3D = MakeShareable<FC7RootMotion_Move3D>(new FC7RootMotion_Move3D());
	if (Move3D.IsValid())
	{
		Move3D->StartPosition = InStart;
		Move3D->EndPosition = InEnd;
		Move3D->Duration = InDuration;
		Move3D->KeepGravity = KeepGravity;
		if (Move3D->Initialize())
		{
			SimpleMovementContext.CurRootMotion = Move3D;
			SetComponentTickEnabled(true);
		}
		return Move3D->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

int32 USimpleMovementComponent::AddMoveVariableSpeed(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InitSpeed, float Acc, float MaxDuration)
{
	FVector InSpecifyTargetPos(EndPosX, EndPosY, EndPosZ);
	check(!InSpecifyTargetPos.ContainsNaN());

	FVector StartPos(StartPosX, StartPosY, StartPosZ);
	check(!StartPos.ContainsNaN());

	SetMovable();
	StopCurrentMove();

	TSharedPtr<FC7RootMotion_UnifornVariableMotion>  UnifornVariableMotion = MakeShareable<FC7RootMotion_UnifornVariableMotion>(new FC7RootMotion_UnifornVariableMotion());
	if (UnifornVariableMotion.IsValid())
	{
		UnifornVariableMotion->Duration = MaxDuration;
		UnifornVariableMotion->InitVelocityVal = InitSpeed;
		UnifornVariableMotion->AccelerationVal = Acc;
		UnifornVariableMotion->TargetPos = InSpecifyTargetPos;
		UnifornVariableMotion->StartPos = StartPos;

		if (UnifornVariableMotion->Initialize())
		{
			SimpleMovementContext.CurRootMotion = UnifornVariableMotion;
			SetComponentTickEnabled(true);
		}
		return UnifornVariableMotion->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

//指定水平速度和竖直加速度的抛物线位移
int32 USimpleMovementComponent::AddMoveParabolaWithHorizontalVelocity(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InHorizontalVelocity, float Acc)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());

	FVector InEnd(EndPosX, EndPosY, EndPosZ);
	check(!InEnd.ContainsNaN());

	SetMovable();
	StopCurrentMove();

	TSharedPtr<FC7RootMotion_ParabolaWithHorizontalVelocity> MoveParaCurve = MakeShareable<FC7RootMotion_ParabolaWithHorizontalVelocity>(new FC7RootMotion_ParabolaWithHorizontalVelocity());
	if (MoveParaCurve.IsValid())
	{

		MoveParaCurve->StartPosition = InStart;
		MoveParaCurve->EndPosition = InEnd;
		MoveParaCurve->HorizontalVelocity = InHorizontalVelocity;
		MoveParaCurve->VerticalAcc = Acc;
		if (MoveParaCurve->Initialize())
		{
			SimpleMovementContext.CurRootMotion = MoveParaCurve;
			SetComponentTickEnabled(true);
		}
		return MoveParaCurve->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;

}

int32 USimpleMovementComponent::AddMoveParabolaWithTrack(KGEntityID TargetEntityID, float InTrackPointMoveSpeed, float InTrackDuration, float InFlyDuration, float Acc)
{
	if (TargetEntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogKGCombat, Log, TEXT("USimpleMovementComponent::AddMoveParabolaWithTrack, invalid TargetEntityID"));
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}
	
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("USimpleMovementComponent::AddMoveParabolaWithTrack, invalid ActorManager"));
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}

	auto* TargetEntity = ActorManager->GetLuaEntity(TargetEntityID);
	if (!TargetEntity)
	{
		UE_LOG(LogKGCombat, Log, TEXT("USimpleMovementComponent::AddMoveParabolaWithTrack, invalid TargetEntity, %lld"), TargetEntityID);
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}

	TSharedPtr<FC7RootMotion_ParabolaTackTarget> MoveParaCurve = MakeShareable<FC7RootMotion_ParabolaTackTarget>(new FC7RootMotion_ParabolaTackTarget());
	if (MoveParaCurve.IsValid())
	{
		MoveParaCurve->Duration = InFlyDuration;
		MoveParaCurve->VerticalAcc = Acc;
		MoveParaCurve->TrackPointMoveSpeed = InTrackPointMoveSpeed;
		MoveParaCurve->TrackDuration = InTrackDuration;
		MoveParaCurve->TargetEntityID = TargetEntityID;
		MoveParaCurve->TargetEntity = TargetEntity;
		if (MoveParaCurve->Initialize())
		{
			SimpleMovementContext.CurRootMotion = MoveParaCurve;
			SetComponentTickEnabled(true);
		}
		return MoveParaCurve->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

// 指定时间和竖直加速度的抛物线位移
int32 USimpleMovementComponent::AddMoveParabolaWithDuration(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InDuration, float Acc)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());

	FVector InEnd(EndPosX, EndPosY, EndPosZ);
	check(!InEnd.ContainsNaN());

	SetMovable();
	StopCurrentMove();

	TSharedPtr<FC7RootMotion_ParabolaWithDuration> MoveParaCurve = MakeShareable<FC7RootMotion_ParabolaWithDuration>(new FC7RootMotion_ParabolaWithDuration());
	if (MoveParaCurve.IsValid())
	{
		MoveParaCurve->Duration = InDuration;
		MoveParaCurve->VerticalAcc = Acc;
		MoveParaCurve->StartPosition = InStart;
		MoveParaCurve->EndPosition = InEnd;
		if (MoveParaCurve->Initialize())
		{
			SimpleMovementContext.CurRootMotion = MoveParaCurve;
			SetComponentTickEnabled(true);
		}
		return MoveParaCurve->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

int32 USimpleMovementComponent::AddMoveParabola(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InDuration, float InPeekHeight)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());

	FVector InEnd(EndPosX, EndPosY, EndPosZ);
	check(!InEnd.ContainsNaN());

	SetMovable();
	StopCurrentMove();

	TSharedPtr<FC7RootMotion_MoveParaCurve> MoveParaCurve = MakeShareable<FC7RootMotion_MoveParaCurve>(new FC7RootMotion_MoveParaCurve());
	if (MoveParaCurve.IsValid())
	{
		MoveParaCurve->Duration = InDuration;
		MoveParaCurve->PeekHeight = InPeekHeight;
		MoveParaCurve->StartPosition = InStart;
		MoveParaCurve->EndPosition = InEnd;
		if (MoveParaCurve->Initialize())
		{
			SimpleMovementContext.CurRootMotion = MoveParaCurve;
			SetComponentTickEnabled(true);
		}
		return MoveParaCurve->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

int32 USimpleMovementComponent::AddMoveMustHitTarget(KGEntityID TargetEntityID, float InDuration, FName TargetBone)
{
	if (TargetEntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogKGCombat, Log, TEXT("USimpleMovementComponent::AddMoveMustHitTarget, invalid TargetEntityID"));
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}
	
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("USimpleMovementComponent::AddMoveMustHitTarget, invalid ActorManager"));
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}

	auto* TargetEntity = ActorManager->GetLuaEntity(TargetEntityID);
	if (!TargetEntity)
	{
		UE_LOG(LogKGCombat, Log, TEXT("USimpleMovementComponent::AddMoveMustHitTarget, invalid TargetEntity, %lld"), TargetEntityID);
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}

	SetMovable();
	StopCurrentMove();

	TSharedPtr<FC7RootMotion_MustHitTarget> MoveMissile = MakeShareable<FC7RootMotion_MustHitTarget>(new FC7RootMotion_MustHitTarget());
	if (MoveMissile.IsValid())
	{
		MoveMissile->Duration = InDuration;
		MoveMissile->TargetEntity = TargetEntity;
		MoveMissile->TargetEntityID = TargetEntityID;
		MoveMissile->TargetBone = TargetBone;

		if (MoveMissile->Initialize())
		{
			SimpleMovementContext.CurRootMotion = MoveMissile;
			SetComponentTickEnabled(true);
		}
		return MoveMissile->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

int32 USimpleMovementComponent::AddMoveTrackTarget(KGEntityID TargetEntityID, float InVelocity, float Acc, float RotSpeed, float InRotAngleThreshold, float InDuration)
{
	if (TargetEntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogKGCombat, Log, TEXT("USimpleMovementComponent::AddMoveTrackTarget, invalid TargetEntityID"));
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}
	
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("USimpleMovementComponent::AddMoveTrackTarget, invalid ActorManager"));
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}

	auto* TargetEntity = ActorManager->GetLuaEntity(TargetEntityID);
	if (!TargetEntity)
	{
		UE_LOG(LogKGCombat, Log, TEXT("USimpleMovementComponent::AddMoveTrackTarget, invalid TargetEntity, %lld"), TargetEntityID);
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}

	SetMovable();
	StopCurrentMove();

	TSharedPtr<FC7RootMotion_TrackTarget> MoveMissile = MakeShareable<FC7RootMotion_TrackTarget>(new FC7RootMotion_TrackTarget());
	if (MoveMissile.IsValid())
	{
		MoveMissile->Duration = InDuration;
		MoveMissile->TargetEntity = TargetEntity;
		MoveMissile->TargetEntityID = TargetEntityID;
		MoveMissile->RotSpeed = RotSpeed;
		MoveMissile->AccelerationVal = Acc;
		MoveMissile->InitVelocityVal = InVelocity;
		MoveMissile->RotAngleThreshold = InRotAngleThreshold;

		if (MoveMissile->Initialize())
		{
			SimpleMovementContext.CurRootMotion = MoveMissile;
			SetComponentTickEnabled(true);
		}
		return MoveMissile->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

int32 USimpleMovementComponent::AddMoveLinearSpeedWithCurve(float StartPosX, float StartPosY, float StartPosZ, float EndPosX, float EndPosY, float EndPosZ, float InDuration, const FString& RootMotionCurvePath, bool KeepGravity)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());

	FVector InEnd(EndPosX, EndPosY, EndPosZ);
	check(!InEnd.ContainsNaN());

	SetMovable();
	StopCurrentMove();

	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogTemp, Error, TEXT("invalid asset manager"));
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}

	TSharedPtr<FC7RootMotion_Move3DCurve> Move3D = MakeShareable<FC7RootMotion_Move3DCurve>(new FC7RootMotion_Move3DCurve());
	if (Move3D.IsValid())
	{
		Move3D->StartPosition = InStart;
		Move3D->EndPosition = InEnd;
		Move3D->Duration = InDuration;
		Move3D->KeyFrameCurve = nullptr;
		Move3D->KeepGravity = KeepGravity;
		if (Move3D->Initialize())
		{
			SimpleMovementContext.CurRootMotion = Move3D;

#if !UE_BUILD_TEST && !UE_BUILD_SHIPPING
			SimpleMovementContext.AssetPathDebugUse = RootMotionCurvePath;
#endif
			SimpleMovementContext.AssetLoadID = AssetManager->AsyncLoadAsset(
				RootMotionCurvePath, FAsyncLoadCompleteDelegate::CreateUObject(this, &USimpleMovementComponent::OnMoveCurveLoaded), static_cast<int32>(EAssetLoadPriority::MoveCurve));
			return Move3D->GID;
		}
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}


int32 USimpleMovementComponent::AddMoveRound(float StartPosX, float StartPosY, float StartPosZ, float CircleCenterPosX, float CircleCenterPosY, float CircleCenterPosZ, float InDuration, float InRotateSpeed)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());

	FVector InCircleCenterLoc(CircleCenterPosX, CircleCenterPosY, CircleCenterPosZ);
	check(!InCircleCenterLoc.ContainsNaN());

	SetMovable();
	StopCurrentMove();

	TSharedPtr<FC7RootMotion_Round> Move3D = MakeShareable<FC7RootMotion_Round>(new FC7RootMotion_Round());
	if (Move3D.IsValid())
	{
		Move3D->CircleCenterLoc = InCircleCenterLoc;
		Move3D->Duration = InDuration;
		Move3D->RotateSpeed = InRotateSpeed;
		Move3D->StartLoc = InStart;
		if (Move3D->Initialize())
		{
			SimpleMovementContext.CurRootMotion = Move3D;
			SetComponentTickEnabled(true);
		}
		return Move3D->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

int32 USimpleMovementComponent::AddMoveBezierUniformAccelerationThenVelocity(
	float StartPosX, float StartPosY, float StartPosZ, float StartDirX, float StartDirY, float StartDirZ, float StartLen,
	float EndPosX, float EndPosY, float EndPosZ, float EndDirX, float EndDirY, float EndDirZ, float EndLen,
	float InSlowdownRatio, float VelocityInitRatio, float InDuration
	)
{
	FVector InStart(StartPosX, StartPosY, StartPosZ);
	check(!InStart.ContainsNaN());
	
	FVector InEnd(EndPosX, EndPosY, EndPosZ);
	check(!InEnd.ContainsNaN());

	SetMovable();
	StopCurrentMove();

	TSharedPtr<FC7RootMotion_BezierUniformAccelerationThenVelocity> Move3D = MakeShareable<FC7RootMotion_BezierUniformAccelerationThenVelocity>(new FC7RootMotion_BezierUniformAccelerationThenVelocity());
	if (Move3D.IsValid())
	{
		Move3D->StartLoc = InStart;
		Move3D->StartDir = FVector(StartDirX, StartDirY, StartDirZ);
		Move3D->StartLen = StartLen;
		Move3D->EndLoc = InEnd;
		Move3D->EndDir = FVector(EndDirX, EndDirY, EndDirZ);
		Move3D->EndLen = EndLen;
		Move3D->Duration = InDuration;
		// 匀减速的初始速度与平均速度的比例
		Move3D->VelocityInitRatio = VelocityInitRatio;
		// 匀减速占总路程的比例
		Move3D->SlowdownRatioByDistance = InSlowdownRatio;
		if (Move3D->Initialize())
		{
			SimpleMovementContext.CurRootMotion = Move3D;
			SetComponentTickEnabled(true);
		}
		return Move3D->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

int32 USimpleMovementComponent::TrackTargetWithDistThreshold(KGEntityID TargetEntityID, float Speed, float DistThreshold)
{
	if (TargetEntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogKGCombat, Log, TEXT("USimpleMovementComponent::TrackTargetWithDistThreshold, invalid TargetEntityID"));
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}
	
	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(this);
	if (!ActorManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("USimpleMovementComponent::TrackTargetWithDistThreshold, invalid ActorManager"));
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}

	auto* TargetEntity = ActorManager->GetLuaEntity(TargetEntityID);
	if (!TargetEntity)
	{
		UE_LOG(LogKGCombat, Log, TEXT("USimpleMovementComponent::TrackTargetWithDistThreshold, invalid TargetEntity, %lld"), TargetEntityID);
		return KG_SIMPLE_MOVEMENT_INVALID_GID;
	}

	SetMovable();
	StopCurrentMove();

	TSharedPtr<FC7RootMotion_TrackTargetWithDistThreshold> MoveMissile = MakeShareable<FC7RootMotion_TrackTargetWithDistThreshold>(new FC7RootMotion_TrackTargetWithDistThreshold());
	if (MoveMissile.IsValid())
	{
		MoveMissile->Duration = FLT_MAX;
		MoveMissile->TargetEntityID = TargetEntityID;
		MoveMissile->TargetEntity = TargetEntity;
		MoveMissile->Speed = Speed;
		MoveMissile->DistThreshold = DistThreshold;

		if (MoveMissile->Initialize())
		{
			SimpleMovementContext.CurRootMotion = MoveMissile;
			SetComponentTickEnabled(true);
		}
		return MoveMissile->GID;
	}
	return KG_SIMPLE_MOVEMENT_INVALID_GID;
}

void USimpleMovementComponent::OnMoveCurveLoaded(int InLoadID, UObject* LoadedAsset)
{
	UCurveLinearColor* CurveLinearColor = Cast<UCurveLinearColor>(LoadedAsset);
	if (!CurveLinearColor)
	{
#if !UE_BUILD_TEST && !UE_BUILD_SHIPPING
		UE_LOG(LogTemp, Error, TEXT("USimpleMovementComponent::OnMoveCurveLoaded, invalid curve asset loaded, %s"), *SimpleMovementContext.AssetPathDebugUse);
#endif
		return;
	}
	
	// 设置曲线数据
	AActor* Owner = GetOwner();
	if (SimpleMovementContext.CurRootMotion.IsValid() && Owner)
	{
		TSharedPtr<FC7RootMotion_Move3DCurve> Move3D = StaticCastSharedPtr<FC7RootMotion_Move3DCurve>(SimpleMovementContext.CurRootMotion);
		Move3D->SetCurve(*Owner, CurveLinearColor);
		SetComponentTickEnabled(true);
	}
	SimpleMovementContext.AssetLoadID.Reset();
}


void USimpleMovementComponent::MustMoveInLine()
{
	if (SimpleMovementContext.CurRootMotion.IsValid())
	{
		SimpleMovementContext.CurRootMotion->MustMoveInLine();
	}
}

void USimpleMovementComponent::StopCurrentMove()
{
	if (SimpleMovementContext.CurRootMotion.IsValid())
	{
		SimpleMovementContext.CurRootMotion.Reset();
	}

	if (SimpleMovementContext.AssetLoadID.IsSet())
	{
		UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
		if (AssetManager)
		{
			AssetManager->CancelAsyncLoadByLoadID(SimpleMovementContext.AssetLoadID.GetValue());
			SimpleMovementContext.AssetLoadID.Reset();
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("invalid asset manager"));
		}
	}
}

void USimpleMovementComponent::SetMovable()
{
	if (AActor* Owner = GetOwner())
	{
		if (USceneComponent* RootComponent = Owner->GetRootComponent())
		{
			RootComponent->SetMobility(EComponentMobility::Movable);
		}
	}
}
