#include "3C/Movement/CurveMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/LuaActorBase.h"
#include "Kismet/KismetMathLibrary.h"


static bool bCurveMovementEnableDebug = false;
FAutoConsoleVariableRef CurveMovementConsoleVariables[] =
{
	FAutoConsoleVariableRef(TEXT("CurveMovement.EnableDebug"),bCurveMovementEnableDebug,TEXT("false: Disable, true: Enable"))
};

UE_DISABLE_OPTIMIZATION

UCurveMovementComponent::UCurveMovementComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	
}

void UCurveMovementComponent::InitializeComponent()
{
	Super::InitializeComponent();

	Velocity = FVector::ZeroVector;

	if (UCapsuleComponent* Capsule = Cast<UCapsuleComponent>(UpdatedComponent))
	{
		CapsuleHalfHeight = Capsule->GetScaledCapsuleHalfHeight();
		CapsuleRadius = Capsule->GetScaledCapsuleRadius();
	}

	TraceObjectTypes.Add(EObjectTypeQuery::ObjectTypeQuery1);

	Deactivate();

	bEnableMove = false;

	if (SyncTargetPos.IsZero() && UpdatedComponent)
	{
		SyncTargetPos = UpdatedComponent->GetComponentLocation();
	}
}

void UCurveMovementComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	QUICK_SCOPE_CYCLE_COUNTER(STAT_UCurveMovementComponent_TickComponent);

	if (HasDeactivate() || ShouldSkipUpdate(DeltaTime) || !UpdatedComponent)
	{
		return ;
	}


	if (bCurveMovementEnableDebug)
	{
		DrawDebugSphere(GetWorld(), SyncTargetPos, 20, 32, FColor::Red, false, DeltaTime + 0.15f);

		FVector _DebugLastPoint(0);
		for (auto& Elem : DebugSyncPoints)
		{
			if (!_DebugLastPoint.IsNearlyZero())
			{
				_DebugLastPoint.Z -= CapsuleHalfHeight;
				FVector EndPos(Elem.Pos);
				EndPos.Z -= CapsuleHalfHeight;
				DrawDebugDirectionalArrow(GetWorld(), _DebugLastPoint, EndPos, 200, FColor::Blue, false, DeltaTime + 0.15f);
			}

			_DebugLastPoint = Elem.Pos;
		}
		FString _DebugDes = FString::Format(TEXT("{0}"), {UpdatedComponent->ComponentVelocity.Size()});
		DrawDebugString(GetWorld(), UpdatedComponent->GetComponentLocation(), _DebugDes, nullptr, FColor::Green, DeltaTime, false, 4);
	}

	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	AActor* ActorOwner = UpdatedComponent->GetOwner();
	if (!ActorOwner || UpdatedComponent->IsSimulatingPhysics())
	{
		return;
	}

	if (CheckAndBreakSyncPos())
	{
		return;
	}

	int32 NewSpeedState = 0;
	if (!UpdatedComponent->ComponentVelocity.IsNearlyZero())
	{
		NewSpeedState = 1;
	}

	if (NewSpeedState != LastSpeedState)
	{
		if (ABaseCharacter* Char = Cast<ABaseCharacter>(GetOwner())) {
			ACTOR_CALL_LUA_ENTITY(Char, "KCB_OnCurveMoveStateChanged", NewSpeedState);
		}
		LastSpeedState = NewSpeedState;
	}

	if (!bEnableMove)
	{
		UpdatedComponent->ComponentVelocity = FVector::ZeroVector;
		return ;
	}

	if (TargetPoint.TimeStamp == 0 && !SyncPointQueue.IsEmpty())
	{
		SyncPointQueue.Dequeue(TargetPoint);
	}

	if (TargetPoint.TimeStamp == 0)
	{
		UpdatedComponent->ComponentVelocity = FVector::ZeroVector;
		return ;
	}

	FVector Loc = UpdatedComponent->GetComponentLocation();
	
	float _Dis = (TargetPoint.Pos - Loc).Size();
	if (_Dis <= AcceptanceRadius)
	{
		bool bFind(false);
		while (SyncPointQueue.Dequeue(TargetPoint))
		{
			_Dis = (TargetPoint.Pos - Loc).Size();

			if (_Dis > AcceptanceRadius)
			{
				bFind = true;
				break;
			}
		}

		if (!bFind)
		{
			TargetPoint.TimeStamp = 0;
			UpdatedComponent->ComponentVelocity = FVector::ZeroVector;
			return;
		}
	}
	
	if (TargetPoint.SyncSpeed == 0)
	{
		float _Speed = (Velocity.Size() + Acceleration * DeltaTime);

		Velocity = ComputePointMVelocity(TargetPoint, _Speed);
	}
	else
	{
		LastSyncSpeed = FMath::FInterpTo(LastSyncSpeed, TargetPoint.SyncSpeed, DeltaTime, SpeedChangeRate);
		//Velocity = ComputePointMVelocity(TargetPoint, GetMaxSpeed());

		if (bCurveMovementEnableDebug)
		{
			if (TargetPoint.SyncSpeed == 0)
			{
				DrawDebugBox(GetWorld(), Loc, FVector(30,20,30), FColor::Black);
			}
		}

		float NewSpeed(LastSyncSpeed);

		float _SyncTargetDis = (SyncTargetPos - Loc).Size();

		if (_SyncTargetDis < SlowMoveMaxDis)
		{
			NewSpeed = (_SyncTargetDis / SlowMoveMaxDis) * (NewSpeed - SlowMoveMinSpeed) + SlowMoveMinSpeed;

			NewSpeed = FMath::Clamp(NewSpeed, SlowMoveMinSpeed, GetMaxSpeed());
		}
		else
		{
			if (_SyncTargetDis > MaxCatchDis)
			{
				NewSpeed = (_SyncTargetDis / BreakRestoreLen) * (MaxCatchSpeed - NewSpeed) + NewSpeed;
				NewSpeed = FMath::Clamp(NewSpeed, GetMaxSpeed(), MaxCatchSpeed);
			}
			else
			{
				if (SyncSpeedConfig > 0)
				{
					NewSpeed = SyncSpeedConfig;
				}

				NewSpeed = FMath::Clamp(NewSpeed, SlowMoveMinSpeed, GetMaxSpeed());
			}
		}


		Velocity = FMath::VInterpTo(Velocity, ComputePointMVelocity(TargetPoint, NewSpeed) , DeltaTime, VelocityChangeRate);

		if (bCurveMovementEnableDebug)
		{
			FVector Normal = TargetPoint.Pos - Loc;
			Normal.Normalize();

			FVector End = Loc + Normal * NewSpeed;

			if (Normal.Size() <= 0.01)
			{
				FVector _End = Loc + Debug_LastTargetNormal * NewSpeed;

				DrawDebugDirectionalArrow(GetWorld(), Loc, _End, NewSpeed, FColor::Red, false);
			}

			DrawDebugDirectionalArrow(GetWorld(), Loc, End, NewSpeed, FColor::Red, false, DeltaTime + 0.001);

			Debug_LastTargetNormal = Normal;
		}
	}

	//if (bCurveMovementEnableDebug)
	//{
	//	{
	//		//DrawDebugString(GetWorld(), Loc, FString::FromInt(DeltaTime * 1000), nullptr, FColor::Red, DeltaTime, false, 4);
	//	}

	//	//UE_LOG(LogTemp, Log, TEXT("%s UCurveMovementComponent Time %s"), *GetOwner()->GetName(), *FString::FromInt(GetWorld()->GetTimeSeconds() * 1000));
	//	//UE_LOG(LogTemp, Log, TEXT("%s UCurveMovementComponent Velocity %s"), *GetOwner()->GetName(), *FString::FromInt(Velocity.Size()));
	//	//UE_LOG(LogTemp, Log, TEXT("%s UCurveMovementComponent Loc %s"), *GetOwner()->GetName(), *Loc.ToString());
	//	//UE_LOG(LogTemp, Log, TEXT("%s UCurveMovementComponent TargetPoint %s"), *GetOwner()->GetName(), *TargetPoint.Pos.ToString());
	//}

	//if (!Velocity.IsNearlyZero(0.01f))
	{
		//LastMoveDelta = FMath::VInterpTo(LastMoveDelta, Velocity * DeltaTime, DeltaTime, 5);

		LastMoveDelta = Velocity * DeltaTime;

		LastMoveDelta = LastMoveDelta.GetClampedToMaxSize(_Dis);

		//if (bCurveMovementEnableDebug)
		//{
		//	//UE_LOG(LogTemp, Log, TEXT("%s UCurveMovementComponent MoveDelta %s"), *GetOwner()->GetName(), *LastMoveDelta.ToString());
		//	//UE_LOG(LogTemp, Log, TEXT("%s UCurveMovementComponent MoveDeltaLen %s"), *GetOwner()->GetName(), *FString::FromInt(LastMoveDelta.Size() * 100));
		//	//UE_LOG(LogTemp, Log, TEXT("%s UCurveMovementComponent DeltaTime %s"), *GetOwner()->GetName(), *FString::FromInt(DeltaTime * 10000));
		//}

		FQuat CurQ = UpdatedComponent->GetComponentQuat();
		FQuat TargetR = !Velocity.IsNearlyZero(0.01f) ? Velocity.ToOrientationQuat() : UpdatedComponent->GetComponentQuat();

		FQuat NewRotation = FMath::QInterpTo(CurQ, TargetR, DeltaTime, RotationLagSpeed);

		//{
			//FVector TargetLoc(Loc);

			////TargetLoc += LastMoveDelta;

			//FVector StartPos = TargetLoc;
			//FVector EndPos = CapsuleHalfHeight * FVector::DownVector + Loc;

			//Temp_OutHits.Empty();
			//UKismetSystemLibrary::SphereTraceMultiForObjects(UpdatedComponent, StartPos, EndPos, CapsuleRadius,
			//	TraceObjectTypes, false, ActorsToIgnore, bCurveMovementEnableDebug ? EDrawDebugTrace::ForDuration : EDrawDebugTrace::None, Temp_OutHits, true,
			//	FLinearColor::Red, FLinearColor::Green, DeltaTime + 0.015f);

		//	if (Temp_OutHits.Num() > 0)
		//	{
		//		FVector _GroundPos(StartPos);
		//		float _MaxGroundDis((StartPos - EndPos).Size());
		//		for (struct FHitResult& _TempHit : Temp_OutHits)
		//		{
		//			float _Dis = (StartPos - _TempHit.ImpactPoint).Length();
		//			if (_MaxGroundDis > _Dis)
		//			{
		//				_MaxGroundDis = _Dis;
		//				_GroundPos = _TempHit.ImpactPoint;
		//			}
		//		}
		//		if (_GroundPos == StartPos)
		//		{
		//			TargetLoc.Z = StartPos.Z;
		//		}
		//		else
		//		{
		//			TargetLoc.Z = _GroundPos.Z + CapsuleHalfHeight;
		//		}
		//	}

		//	TargetLoc.Z = FMath::FInterpTo(Loc.Z, TargetLoc.Z, DeltaTime, WalkableOffsetSpeed);

		//	LastMoveDelta = TargetLoc - Loc;

		//	LastMoveDelta = LastMoveDelta.GetClampedToMaxSize(Dis);
		//}

		FHitResult Hit(1.f);

		TGuardValue<EMoveComponentFlags> ScopedFlagRestore(MoveComponentFlags, MoveComponentFlags);
		MoveUpdatedComponent(LastMoveDelta, NewRotation, false, &Hit);
	}

	UpdatedComponent->ComponentVelocity = Velocity;
}

FVector UCurveMovementComponent::ComputeVelocity(FVector InitialVelocity, float DeltaTime) const
{
	return InitialVelocity;
}

FVector UCurveMovementComponent::ComputeMoveDelta(const FVector& InVelocity, float DeltaTime) const
{
	const FVector NewVelocity = ComputeVelocity(InVelocity, DeltaTime);
	const FVector Delta = InVelocity * 0.8 * DeltaTime;
	return Delta;
}

FVector UCurveMovementComponent::ComputePointMVelocity(const FMoveCurvePointData& InPoint, const float& InSpeed)
{
	if(!UpdatedComponent)
		return FVector::ZeroVector;

	FVector Loc = UpdatedComponent->GetComponentLocation();

	FVector Normal = InPoint.Pos - Loc;

	float Dis = Normal.Size();
	if (Dis <= AcceptanceRadius)
	{
		return FVector::ZeroVector;
	}

	Normal.Normalize();

	return Normal * InSpeed;
}

bool UCurveMovementComponent::CheckAndBreakSyncPos()
{
	FVector Loc = FVector::ZeroVector;
	if (UpdatedComponent)
	{
		Loc = UpdatedComponent->GetComponentLocation();
	}

	float Dis = (Loc - SyncTargetPos).Size();

	if (Dis > BreakRestoreLen)
	{
		++BreakRestoreMark;
	}
	else
	{
		BreakRestoreMark = 0;
	}

	if (BreakRestoreMark > BreakRestoreMaxCount)
	{
		if (AActor* Owner = GetOwner())
		{
			Owner->TeleportTo(SyncTargetPos, Owner->GetActorRotation(), false, false);

			SyncPointQueue.Empty();
			TargetPoint.TimeStamp = 0;

			if (bCurveMovementEnableDebug)
			{
				DrawDebugSphere(GetWorld(), SyncTargetPos, 100, 32, FColor::Red);
			}
		}

		BreakRestoreMark = 0;

		return true;
	}

	return false;
}

void UCurveMovementComponent::OnSyncMoveState(int32 PathIndex, float X, float Y, float Z)
{
	FMoveCurvePointData _NewPointData;
	_NewPointData.Pos.X = X;
	_NewPointData.Pos.Y = Y;
	_NewPointData.Pos.Z = Z + CapsuleHalfHeight;
	_NewPointData.TimeStamp =  GetWorld()->GetRealTimeSeconds() * 10000;

	if (_LastSyncPoint.TimeStamp > 0)
	{
		float GapTime = _NewPointData.TimeStamp - _LastSyncPoint.TimeStamp;
		if (GapTime > 0)
		{
			_NewPointData.SyncSpeed = (_NewPointData.Pos - _LastSyncPoint.Pos).Size() / GapTime * 10000;
			_NewPointData.SyncSpeed =  FMath::Clamp(_NewPointData.SyncSpeed, 0, GetMaxSpeed());
		}
	}

	SyncPointQueue.Enqueue(_NewPointData);

	SyncTargetPos = _NewPointData.Pos;
	_LastSyncPoint = _NewPointData;

	if (bCurveMovementEnableDebug)
	{
		DebugSyncPoints.Push(_NewPointData);

		if (DebugSyncPoints.Num() > 60)
		{
			DebugSyncPoints.RemoveAt(0);
		}
	}
}

void UCurveMovementComponent::OnSyncEnableState(bool bEnable, int32 PathIndex, float Speed)
{
	if (bEnable != bEnableMove)
	{
		SyncPointQueue.Empty();
		TargetPoint.TimeStamp = 0;
	}

	if (bEnable && Speed > 0)
	{
		Activate();

		bEnableMove = true;
	}
	else
	{
		bEnableMove = false;
	}

	MaxSpeed = Speed;
}


void UCurveMovementComponent::SetCurveMoveParams(int breakRestoreLen, int slowMoveMaxDis, int maxCatchDis, int maxCatchSpeed, int velocityChangeRate, int speedChangeRate, int syncSpeedConfig) {
		this->BreakRestoreLen = breakRestoreLen;
		this->SlowMoveMaxDis = slowMoveMaxDis;
		this->MaxCatchDis = maxCatchDis;
		this->MaxCatchSpeed = maxCatchSpeed;
		this->VelocityChangeRate = velocityChangeRate;
		this->SpeedChangeRate = speedChangeRate;
		this->SyncSpeedConfig = syncSpeedConfig;
}

void UCurveMovementComponent::SetCurvePath(const TArray<FCurvePathPoint>& InPath)
{
	CurvePath.Empty();

	for (const FCurvePathPoint& Elem : InPath)
	{
		CurvePath.Add(Elem.Index, Elem);
	}
}

UE_ENABLE_OPTIMIZATION