#include "3C/Movement/MovementPipeline/MovementCalculator/MovementCalculatorBase.h"


#if UE_BUILD_DEVELOPMENT
void MovementCalculatorBase::AppendDebugInfo(FString& infoOut) {
	infoOut.Appendf(TEXT("IsEnabled:%d  MovementSpace:%d\n"), IsEnabled(), MovementSpace);
}

#endif
