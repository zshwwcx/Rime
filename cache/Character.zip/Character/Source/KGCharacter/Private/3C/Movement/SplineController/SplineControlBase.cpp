#include "3C/Movement/SplineController/SplineControlBase.h"

#include "3C/Interactor/WorldManager.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Components/SplineComponent.h"

FSplineControlBase::FSplineControlBase()
{
}

FSplineControlBase::~FSplineControlBase()
{
}

void FSplineControlBase::Init(const float InCapHalfHeight, const float InCapRadius, const FString& InSplineInsID)
{
	OwnerCapsuleHalfHeight = InCapHalfHeight;
	OwnerCapsuleRadius = InCapRadius;
	SplineInsID = InSplineInsID;
	bSplineInitialized = false;
	OnInit();
}

void FSplineControlBase::Reset()
{
	SplineInsID.Empty();
	bSplineInitialized = false;
	bIsSplinePendingLoad = false;
	SplineActor.Reset();
	SplineComp.Reset();
	bMoveFinished = false;
	OnReset();
}

bool FSplineControlBase::TickSplineMove(URoleMovementComponent& MovementComponent, float DeltaTime)
{
	UpdateSplineState(MovementComponent);
	
	if (bSplineInitialized)
	{
		if (SplineActor.IsValid() && SplineComp.IsValid())
		{
			return DoSplineControlTick(MovementComponent, DeltaTime);
		}
	}
	return false;
}

void FSplineControlBase::UpdateSplineState(const URoleMovementComponent& MovementComponent)
{
	if (bSplineInitialized)
	{
		return;
	}
	UWorldManager* WorldManager = UWorldManager::GetInstance(MovementComponent.GetWorld());
	if (!WorldManager)
	{
		return;
	}
	
	if (!bIsSplinePendingLoad)
	{
		bIsSplinePendingLoad = WorldManager->IsGameplaySplineActorPendingLoad(SplineInsID);
	}
	if (bIsSplinePendingLoad)
	{
		return;
	}
	
	SplineActor = WorldManager->GetGameplaySplineActorIfReady(SplineInsID);
	if (SplineActor.IsValid())
	{
		SplineComp = SplineActor->GetSplineComponent();
		
		bSplineInitialized = SplineActor.IsValid() && SplineComp.IsValid();
		
		if (bSplineInitialized)
		{
			SetUpAfterSplineReady();
		}
	}
	
}



#if UE_BUILD_DEVELOPMENT

void FSplineControlBase::AppendDebugInfo(FString& infoOut)
{
	
}
#endif