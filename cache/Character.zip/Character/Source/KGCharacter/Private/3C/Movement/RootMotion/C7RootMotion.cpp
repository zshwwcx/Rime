#include "3C/Movement/RootMotion/C7RootMotion.h"

#include "KGCharacterModule.h"
#include "GameFramework/Character.h"
#include "Kismet/KismetSystemLibrary.h"
#include "3C/Character/BaseCharacter.h"
#include "Components/SkeletalMeshComponent.h"


static FLinearColor EvaluateVectorCurveAtFraction_C7RootMotion(const UCurveLinearColor& Curve, const float Fraction) {
  float MinCurveTime(0.f);
  float MaxCurveTime(1.f);

  Curve.GetTimeRange(MinCurveTime, MaxCurveTime);
  return Curve.GetUnadjustedLinearColorValue(FMath::GetRangeValue(FVector2f(MinCurveTime, MaxCurveTime), Fraction));
}

int32 FC7RootMotionBase::NewGID()
{ 
	static int32 GIDCounter = 0;
	GIDCounter++;
    if (GIDCounter < 0) 
		GIDCounter = 1;
	return GIDCounter;
}

void FC7RootMotionBase::GetActorFloorPos(TWeakObjectPtr<AActor> Actor, FVector& OutPos)
{
	UObject* WorldContextObject = Cast<UObject>(Actor->GetWorld());
	if (!UKismetSystemLibrary::IsValid(WorldContextObject))
	{
		return;
	}
	
	FVector StartPos = Actor->GetActorLocation();
	OutPos = StartPos; // 默认位置为起始位置
	FVector EndPos = StartPos + FVector(0, 0, -10000); // 向下射线检测

	TArray<AActor*> IgnoredActors;
	TArray<FHitResult> OutHits;

	if (bool bHit = UKismetSystemLibrary::LineTraceMulti(WorldContextObject, StartPos, EndPos,
		ETraceTypeQuery::TraceTypeQuery1, false, IgnoredActors,
		EDrawDebugTrace::Type::None, OutHits, true))
	{
		const auto& Elem = OutHits.Last();
		if (Elem.HitObjectHandle.FetchActor()
			&& (Elem.HitObjectHandle.FetchActor()->IsA<ABaseCharacter>()))
		{
			return;
		}

		OutPos = Elem.ImpactPoint;
	}
}

bool FC7RootMotionBase::TryUpdateTargetEntity(UWorld* World, KGEntityID TargetEntityID, TWeakInterfacePtr<ICppEntityInterface>& OutTargetEntity)
{
	if (OutTargetEntity.IsValid())
	{
		return true;
	}

	if (!World)
	{
		UE_LOG(LogKGCombat, Error, TEXT("FC7RootMotionBase::TryUpdateTargetEntity, invalid World"));
		return false;
	}

	UKGUEActorManager* ActorManager = UKGUEActorManager::GetInstance(World);
	if (!ActorManager)
	{
		UE_LOG(LogKGCombat, Error, TEXT("FC7RootMotionBase::TryUpdateTargetEntity, invalid ActorManager"));
		return false;
	}

	// 单位出AOI以后尝试重新获取target entity
	OutTargetEntity = ActorManager->GetLuaEntity(TargetEntityID);
	return OutTargetEntity.IsValid();
}

bool FC7RootMotionBase::Initialize() 
{
	GID = NewGID();
	return true;
}

bool FC7RootMotion_Move3D::Initialize() {
	GID = NewGID();
	return true;
}

void FC7RootMotion_Move3D::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{
		float MoveFraction = GetClampFraction();
		const FVector CurrentLocation = Actor.GetActorLocation();
		FVector CurPosition = StartPosition + (EndPosition - StartPosition) * MoveFraction;
		translationDelta = (CurPosition - CurrentLocation);
		UE_LOG(LogTemp, Warning, TEXT("zzp zzp update Pos %s, translationDelta %s"), *CurrentLocation.ToString(), *translationDelta.ToString());
		if (KeepGravity)
		{
			// 保持重力情况下，不计算高度差，由外部应用重力
			translationDelta.Z = 0;
		}
		rotDelta = FQuat::Identity;
	}
}

bool FC7RootMotion_Move3DCurve::Initialize() {
	GID = NewGID();
    return true;
}

void FC7RootMotion_Move3DCurve::SetCurve(const AActor& Actor, UCurveLinearColor* CurveLinearColor)
{
	if (!CurveLinearColor)
		return;
	KeyFrameCurve = TStrongObjectPtr(CurveLinearColor);
	if (!KeyFrameCurve.IsValid())
		return;
	FVector Dir = EndPosition - StartPosition;
	if (Dir.Length() <= UE_SMALL_NUMBER)
	{
		// 终点和起点基本一致，按照曲线的轨迹来移动 
		CurveX = Actor.GetActorForwardVector();
		CurveY = Actor.GetActorRightVector();
		return;
	}
	// 起点终点不一致情况下，不应用Scale
	Scale = 1.0f;
	// 弧度
	float Yaw = FMath::Atan2(Dir.Y, Dir.X);
	FLinearColor StartFrame = EvaluateVectorCurveAtFraction_C7RootMotion(*KeyFrameCurve.Get(), 0.0f);
	FLinearColor EndFrame = EvaluateVectorCurveAtFraction_C7RootMotion(*KeyFrameCurve.Get(), 1.0f);
	FVector CurveDir = FVector(EndFrame.R, EndFrame.G, EndFrame.B) - FVector(StartFrame.R, StartFrame.G, StartFrame.B);
	if (CurveDir.Size2D() <= UE_SMALL_NUMBER)
	{
		// 曲线长度为0，改为位移修正方式
		CurveX = Actor.GetActorForwardVector();
		CurveY = Actor.GetActorRightVector();
		PosDiff = Dir;
		return;
	}
	float CurveYaw = FMath::Atan2(CurveDir.Y, CurveDir.X);
	// 曲线中x轴对应的yaw
	float CurveXYaw = Yaw - CurveYaw;
	// 曲线中y轴对应的yaw
	float CurveYYaw = Yaw + (PI / 2.0f - CurveYaw);
	CurveX = FVector(FMath::Cos(CurveXYaw), FMath::Sin(CurveXYaw), 0.0f) * Dir.Size2D() / CurveDir.Size2D();
	CurveY = FVector(FMath::Cos(CurveYYaw), FMath::Sin(CurveYYaw), 0.0f) * Dir.Size2D() / CurveDir.Size2D();
	HeightDiff = Dir.Z - (EndFrame.A - StartFrame.A);
	LastYaw = 0.0f;
}

void FC7RootMotion_Move3DCurve::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER) 
	{
		if (KeyFrameCurve.IsValid())
		{
			float MoveFraction = GetClampFraction();
			const FVector CurrentLocation = Actor.GetActorLocation();
			float CurrentYaw = Actor.GetActorRotation().Yaw;

			FLinearColor KeyFrame = EvaluateVectorCurveAtFraction_C7RootMotion(*KeyFrameCurve.Get(), MoveFraction) * Scale;
			FVector Position(KeyFrame.R, KeyFrame.G, 0);
			FVector CurPosition = StartPosition + KeyFrame.R * CurveX + KeyFrame.G * CurveY;
			// 每次tick补一下高度，保证最后终点刚好能到
			CurPosition.Z += KeyFrame.B + HeightDiff * MoveFraction;
			// 曲线长度为0，通过每帧位移修正处理
			CurPosition = CurPosition + PosDiff * MoveFraction;
			float Yaw = KeyFrame.A;
            float DelatYaw = Yaw - LastYaw;
			LastYaw = Yaw;
			translationDelta = CurPosition - CurrentLocation;
			if (KeepGravity)
			{
				// 保持重力情况下，不计算高度差，由外部应用重力
				translationDelta.Z = 0;
			}

			FRotator Rotator(0, DelatYaw, 0);
			rotDelta = FQuat(Rotator);
		}
	}
}

FVector FC7RootMotion_MoveParaCurve::EvaluatePosition(float _CurrentTime)
{
	float ZOffset = Velocity_Vertical * CurrentTime - Acc_Gravity * CurrentTime * CurrentTime * .5f;
	FVector Position = Velocity_Horizontal * CurrentTime * HorizontalOrientation;
	if (Position.Size2D() > HorizontalShift)
	{
		Position = EndPosition;
	}
	else
	{
		Position += StartPosition;
	}
	Position.Z = StartPosition.Z + ZOffset;
	return Position;
}

bool FC7RootMotion_MoveParaCurve::Initialize()
{
	GID = NewGID();
	//检查除数不为0
	if (FMath::IsNearlyZero(Duration))
	{
		return false;
	}
	//配置的最高点要高于终点位置
	float Distance_Vertical = EndPosition.Z - StartPosition.Z;
	if (Distance_Vertical > PeekHeight)
	{
		return false;
	}
	float Distance_Horizontal = (EndPosition - StartPosition).Size2D();
	if (FMath::IsNearlyZero(PeekHeight))
	{
		Velocity_Vertical = 2.f * Distance_Vertical / Duration;
		Acc_Gravity = Velocity_Vertical * Velocity_Vertical * .5f / Distance_Vertical;
	}
	else
	{
		Velocity_Vertical = 2.f * PeekHeight / Duration + 2.f * FMath::Sqrt(PeekHeight * (PeekHeight - Distance_Vertical)) / Duration;
		Acc_Gravity = Velocity_Vertical * Velocity_Vertical * .5f / PeekHeight;
	}
	Velocity_Horizontal = Distance_Horizontal / Duration;
	/*if (Distance_Vertical > .0f)
	{
		Velocity_Horizontal = Distance_Horizontal / Duration;
	}
	else
	{
		Velocity_Horizontal = Velocity_Vertical * Distance_Horizontal * .25f / PeekHeight;
	}*/
	HorizontalOrientation = EndPosition - StartPosition;
	HorizontalShift = HorizontalOrientation.Size2D();
	if (FMath::IsNearlyZero(HorizontalShift))
	{
		HorizontalOrientation = FVector::ZeroVector;
	}
	else
	{
		HorizontalOrientation = HorizontalOrientation / HorizontalShift;

	}

	return true;
}

void FC7RootMotion_MoveParaCurve::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	if (Duration > UE_SMALL_NUMBER )//&& DeltaTime > UE_SMALL_NUMBER)
	{
		float MoveFraction = GetClampFraction();
		FVector CurrentTargetLocation = EvaluatePosition(MoveFraction);
		FVector CurrentLocation = Actor.GetActorLocation();
		if (MoveFraction >= 1.0f)
		{
			CurrentTargetLocation = EndPosition;
		}
		translationDelta = CurrentTargetLocation - CurrentLocation;
		rotDelta = FQuat::Identity;
	}
}

void FC7RootMotion_ParabolaBase::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{
		FVector TargetLocation = EndPosition;
		if (!IsFinish())
		{
			FVector2D CurXYPos = FVector2D(StartPosition) + CurrentTime * HorizontalVelocity * HorizontalDir;
			float ZOffset = VerticalVelocity * CurrentTime - 0.5 * VerticalAcc * CurrentTime * CurrentTime;
			float CurZPos = StartPosition.Z + ZOffset;
			TargetLocation = FVector(CurXYPos.X, CurXYPos.Y, CurZPos);
		}

		FVector CurrentLocation = Actor.GetActorLocation();
		translationDelta = TargetLocation - CurrentLocation;
		rotDelta = FQuat::Identity;
	}
}


bool FC7RootMotion_ParabolaWithHorizontalVelocity::Initialize()
{
	GID = NewGID();
	float HorizontalDistance = (EndPosition - StartPosition).Size2D();
	
	Duration = HorizontalDistance / HorizontalVelocity;

	float VerticalDis = EndPosition.Z - StartPosition.Z;
	VerticalVelocity = (VerticalDis + 0.5 * VerticalAcc * Duration * Duration) / Duration;

	HorizontalDir = FVector2D(EndPosition) - FVector2D(StartPosition);
	HorizontalDir = HorizontalDir.GetSafeNormal();

	return true;
}

bool FC7RootMotion_ParabolaWithDuration::Initialize()
{
	GID = NewGID();
	float HorizontalDistance = (EndPosition - StartPosition).Size2D();

	HorizontalVelocity = HorizontalDistance / Duration;

	float VerticalDis = EndPosition.Z - StartPosition.Z;
	VerticalVelocity = (VerticalDis + 0.5 * VerticalAcc * Duration * Duration) / Duration;

	HorizontalDir = FVector2D(EndPosition) - FVector2D(StartPosition);
	HorizontalDir = HorizontalDir.GetSafeNormal();

	return true;
}


void FC7RootMotion_ParabolaTackTarget::CalcMoveParams(const AActor& Actor, float DeltaTime)
{
	auto& TrackPointLoc = CachedTrackPointLoc.GetValue();
	// 计算追踪点的位置
	if (CurrentTime < TrackDuration)
	{
		FVector TargetActorLoc = TargetEntity->GetLocation();
		FVector TrackPointDir = TargetActorLoc - TrackPointLoc;
		if (TrackPointMoveSpeed * DeltaTime > TrackPointDir.Length())
		{
			TrackPointLoc = TargetActorLoc;
		}
		else
		{
			TrackPointDir = TrackPointDir.GetSafeNormal();
			TrackPointLoc = TrackPointLoc + TrackPointDir * TrackPointMoveSpeed * DeltaTime;
		}
	}
	
	FVector CurLoc = Actor.GetActorLocation();
	float HorizontalDistance = (TrackPointLoc - CurLoc).Size2D();

	float LeftDuration = Duration - PreviousTime;
	HorizontalVelocity = HorizontalDistance / LeftDuration;

	float VerticalDis = TrackPointLoc.Z - CurLoc.Z;
	VerticalVelocity = (VerticalDis + 0.5 * VerticalAcc * LeftDuration * LeftDuration) / LeftDuration;

	HorizontalDir = FVector2D(TrackPointLoc) - FVector2D(CurLoc);
	HorizontalDir = HorizontalDir.GetSafeNormal();

	CurrentPos = CurLoc;
}

bool FC7RootMotion_ParabolaTackTarget::Initialize()
{
	GID = NewGID();
	
	return true;
}

void FC7RootMotion_ParabolaTackTarget::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	
	if (!TargetEntity.IsValid() && !TryUpdateTargetEntity(Actor.GetWorld(), TargetEntityID, TargetEntity))
	{
		return;
	}
	check(TargetEntity.IsValid());
	if (!CachedTrackPointLoc.IsSet())
	{
		CachedTrackPointLoc = TargetEntity->GetLocation();
	}
	auto& TrackPointLoc = CachedTrackPointLoc.GetValue();
	
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{	
		if (bMustMoveInLine)
		{
			FVector TargetPos = LineMoveStartPos + (CurrentTime - LineMoveStartTime) / (Duration - LineMoveStartTime) * (TrackPointLoc - LineMoveStartPos);
			translationDelta = TargetPos - Actor.GetActorLocation();
			rotDelta = (translationDelta.ToOrientationRotator() - Actor.GetActorRotation()).Quaternion();
			return;

		}
		CalcMoveParams(Actor, DeltaTime);
		if (!IsFinish())
		{
			FVector2D XYPosDelta = HorizontalDir * HorizontalVelocity * DeltaTime;
			float ZPosDelta = VerticalVelocity * DeltaTime - 0.5 * VerticalAcc * DeltaTime * DeltaTime;
			translationDelta = FVector(XYPosDelta.X, XYPosDelta.Y, ZPosDelta);
		}
		else
		{
			FVector CurrentLocation = Actor.GetActorLocation();
			translationDelta = TrackPointLoc - CurrentLocation;
		}
		rotDelta = (translationDelta.ToOrientationRotator() - Actor.GetActorRotation()).Quaternion();
	}
}


bool FC7RootMotion_MustHitTarget::Initialize()
{
	GID = NewGID();
	return true;
}

void FC7RootMotion_MustHitTarget::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);

	if (!TargetEntity.IsValid() && !TryUpdateTargetEntity(Actor.GetWorld(), TargetEntityID, TargetEntity))
	{
		return;
	}
	check(TargetEntity.IsValid());
	
	FVector TargetLoc = TargetEntity->GetLocation();
	if (AActor* TargetActor = TargetEntity->GetLuaEntityBase()->GetActor())
	{
		if (USkeletalMeshComponent* SkComp = TargetActor->GetComponentByClass<USkeletalMeshComponent>())
		{
			if (SkComp->GetBoneIndex(TargetBone) != INDEX_NONE)
			{
				FTransform TargetTransform = SkComp->GetBoneTransform(TargetBone);
				TargetLoc = TargetTransform.GetLocation();
			}
		}	
	}

	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{
		FVector CurLoc = Actor.GetActorLocation();
		FVector Dir = TargetLoc - CurLoc;
		Dir = Dir.GetSafeNormal();
		FRotator CurRot = Actor.GetActorRotation();
		FRotator TargetRot = Dir.ToOrientationRotator();

		float LastDur = Duration - PreviousTime;
		if (DeltaTime >= LastDur)
		{
			translationDelta = TargetLoc - CurLoc;
		}
		else
		{
			translationDelta = (DeltaTime / LastDur) * (TargetLoc - CurLoc);
		}
		rotDelta = (TargetRot - CurRot).Quaternion();
		return;
	}
}

bool FC7RootMotion_TrackTarget::Initialize()
{
	GID = NewGID();
	LastVelocityVal = InitVelocityVal;
	return true;
}

void FC7RootMotion_TrackTarget::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	
	if (!TargetEntity.IsValid() && !TryUpdateTargetEntity(Actor.GetWorld(), TargetEntityID, TargetEntity))
	{
		return;
	}
	check(TargetEntity.IsValid());
	
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{	
		if (bMustMoveInLine)
		{
			FVector TargetPos = LineMoveStartPos + (CurrentTime - LineMoveStartTime) / (Duration - LineMoveStartTime) * (TargetActorPos - LineMoveStartPos);
			translationDelta = TargetPos - Actor.GetActorLocation();
			rotDelta = (translationDelta.ToOrientationRotator() - Actor.GetActorRotation()).Quaternion();
			return;
		}
		FVector TargetLoc = TargetEntity->GetLocation();
		TargetActorPos = TargetLoc;
		FVector CurLoc = Actor.GetActorLocation();
		CurrentPos = CurLoc;

		FVector Dir = TargetLoc - CurLoc;
		Dir = Dir.GetSafeNormal();
		FRotator CurRot = Actor.GetActorRotation();
		FRotator TargetRot = Dir.ToOrientationRotator();

		// 非必中追踪
		FQuat CurQuat = CurRot.Quaternion();
		FQuat TargetQuat = TargetRot.Quaternion();
		float AngleDiff = CurQuat.AngularDistance(TargetQuat);
		if (RotAngleThreshold > 0 && FMath::RadiansToDegrees(AngleDiff) < RotAngleThreshold)
		{
			float WillRoteRadian = FMath::DegreesToRadians(RotSpeed * DeltaTime);
			if (WillRoteRadian > AngleDiff)
			{
				rotDelta = (TargetRot - CurRot).Quaternion();
			}
			else
			{
				FRotator NewRot = FQuat::Slerp(CurQuat, TargetQuat, WillRoteRadian / AngleDiff).Rotator();
				rotDelta = (NewRot - CurRot).Quaternion();
			}
		}
		else
		{
			rotDelta = FQuat::Identity;
		}

		FVector CurRotVector = CurRot.Vector();
		CurRotVector = CurRotVector.GetSafeNormal();

		FVector InitVel = CurRotVector * LastVelocityVal;
		FVector Acc = CurRotVector * AccelerationVal;
		translationDelta = InitVel * DeltaTime + Acc * DeltaTime * DeltaTime * 0.5;
		LastVelocityVal = LastVelocityVal + AccelerationVal * DeltaTime;
	}
}

bool FC7RootMotion_UnifornVariableMotion::Initialize()
{
	GID = NewGID();
	LastFramePos = StartPos;
	return true;
}


bool FC7RootMotion_UnifornVariableMotion::IsFinish()
{
	float DiffLen = (CurrentPos - TargetPos).Length();
	return CurrentTime >= Duration || DiffLen <= MotionConst::TARGETPOS_AND_CURRENTPOS_THRESHOLD;
}

void FC7RootMotion_UnifornVariableMotion::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{
		FVector VelDir = TargetPos - StartPos;
		VelDir = VelDir.GetSafeNormal();

		FVector InitVel = VelDir * InitVelocityVal;
		FVector Acc = VelDir * AccelerationVal;
		FVector Displacement = InitVel * CurrentTime + Acc * CurrentTime * CurrentTime * 0.5;
		CurrentPos = Displacement + StartPos;
		translationDelta = CurrentPos - LastFramePos;
		LastFramePos = CurrentPos;
		rotDelta = FQuat::Identity;
	}
}

bool FC7RootMotion_ViolentRotate::Initialize()
{
	GID = NewGID();
	return true;
}

void FC7RootMotion_ViolentRotate::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{
		FRotator CurrentRotation = Actor.GetActorRotation();

		if (!bInBlendOut)
		{
			if (CurrentTime < BlendIn)
			{
				RotateSpeed.Roll = FMath::Lerp(0.0f, MaxRotateSpeed, CurrentTime / BlendIn);
				RotateSpeed.Pitch = FMath::Lerp(0.0f, MaxRotateSpeed, CurrentTime / BlendIn);
				RotateSpeed.Yaw = FMath::Lerp(0.0f, MaxRotateSpeed, CurrentTime / BlendIn);
			}
			else if ((Duration - CurrentTime) <= BlendOut)
			{
				if (!bInBlendOut)
				{
					float RemainAngle = FMath::Floor(RotateSpeed.Roll * 0.5f / 360.0f * BlendOut) * 360.0f;

					BlendOutRotation = Actor.GetActorRotation().GetNormalized();

					if (FMath::IsNearlyZero(RotateRule.Roll))
					{
						RemainPath.Roll = 0.0f;
					}
					else
					{
						if (RotateRule.Roll > 0.0f)
						{
							float Delta = TargetRot.Roll - BlendOutRotation.Roll;
							if (Delta < 0.0f)
							{
								Delta += 360.0f;
							}
							RemainPath.Roll = RemainAngle + Delta;
						}
						else
						{
							float Delta = TargetRot.Roll - BlendOutRotation.Roll;
							if (Delta > 0.0f)
							{
								Delta -= 360.0f;
							}
							RemainPath.Roll = 0.0f - RemainAngle - Delta;
						}
					}

					if (FMath::IsNearlyZero(RotateRule.Pitch))
					{
						RemainPath.Pitch = 0.0f;
					}
					else
					{
						if (RotateRule.Pitch > 0.0f)
						{
							float Delta = TargetRot.Pitch - BlendOutRotation.Pitch;
							if (Delta < 0.0f)
							{
								Delta += 360.0f;
							}
							RemainPath.Pitch = RemainAngle + Delta;
						}
						else
						{
							float Delta = TargetRot.Pitch - BlendOutRotation.Pitch;
							if (Delta > 0.0f)
							{
								Delta -= 360.0f;
							}
							RemainPath.Pitch = 0.0f - RemainAngle - Delta;
						}
					}

					if (FMath::IsNearlyZero(RotateRule.Yaw))
					{
						RemainPath.Yaw = 0.0f;
					}
					else
					{
						if (RotateRule.Yaw > 0.0f)
						{
							float Delta = TargetRot.Yaw - BlendOutRotation.Yaw;
							if (Delta < 0.0f)
							{
								Delta += 360.0f;
							}
							RemainPath.Yaw = RemainAngle + Delta;
						}
						else
						{
							float Delta = TargetRot.Yaw - BlendOutRotation.Yaw;
							if (Delta > 0.0f)
							{
								Delta -= 360.0f;
							}
							RemainPath.Yaw = 0.0f - RemainAngle - Delta;
						}
					}

					bInBlendOut = true;
				}
			}
			else
			{
				RotateSpeed.Roll = MaxRotateSpeed;
				RotateSpeed.Pitch = MaxRotateSpeed;
				RotateSpeed.Yaw = MaxRotateSpeed;
			}
		}

		if (bInBlendOut)
		{
			float Prop = (Duration - CurrentTime) / BlendOut;
			float Prop3 = Prop * Prop * Prop;

			if (!FMath::IsNearlyZero(RotateRule.Roll))
			{
				float Path = RemainPath.Roll * (1.0f - Prop3);
				float MaxPath = (BlendOut - Duration + CurrentTime) * MaxRotateSpeed;
				Path = FMath::Min(Path, MaxPath);
				CurrentRotation.Roll = BlendOutRotation.Roll + Path;
			}

			if (!FMath::IsNearlyZero(RotateRule.Pitch))
			{
				float Path = RemainPath.Pitch * (1.0f - Prop3);
				float MaxPath = (BlendOut - Duration + CurrentTime) * MaxRotateSpeed;
				Path = FMath::Min(Path, MaxPath);
				CurrentRotation.Pitch = BlendOutRotation.Pitch + Path;
			}

			if (!FMath::IsNearlyZero(RotateRule.Yaw))
			{
				float Path = RemainPath.Yaw * (1.0f - Prop3);
				float MaxPath = (BlendOut - Duration + CurrentTime) * MaxRotateSpeed;
				Path = FMath::Min(Path, MaxPath);
				CurrentRotation.Yaw = BlendOutRotation.Yaw + Path;
			}
		}
		else
		{
			if (!FMath::IsNearlyZero(RotateRule.Roll))
			{
				CurrentRotation.Roll = CurrentRotation.Roll + RotateSpeed.Roll * DeltaTime * RunningRate * FMath::Sign(RotateRule.Roll);
			}

			if (!FMath::IsNearlyZero(RotateRule.Pitch))
			{
				CurrentRotation.Pitch = CurrentRotation.Pitch + RotateSpeed.Pitch * DeltaTime * RunningRate * FMath::Sign(RotateRule.Pitch);
			}

			if (!FMath::IsNearlyZero(RotateRule.Yaw))
			{
				CurrentRotation.Yaw = CurrentRotation.Yaw + RotateSpeed.Yaw * DeltaTime * RunningRate * FMath::Sign(RotateRule.Yaw);
			}
		}

		translationDelta = FVector::ZeroVector;
		rotDelta = (CurrentRotation - Actor.GetActorRotation()).Quaternion();
	}
}



bool FC7RootMotion_Round::Initialize()
{
	GID = NewGID();
	RadiusDir = StartLoc - CircleCenterLoc;
	RadiusLen = RadiusDir.Length();
	RadiusDir = RadiusDir.GetSafeNormal();
	UpVec = FRotationMatrix(RadiusDir.Rotation()).GetScaledAxis(EAxis::Z);

	LastFrameLoc = StartLoc;
	return true;
}

void FC7RootMotion_Round::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{
		float RotAngle = RotateSpeed * DeltaTime;
		RadiusDir = RadiusDir.RotateAngleAxis(RotAngle, UpVec);
		FVector TargetLoc = CircleCenterLoc + RadiusDir * RadiusLen;
		translationDelta = TargetLoc - LastFrameLoc;
		LastFrameLoc = TargetLoc;
		rotDelta = FQuat::Identity;
	}
}

bool FC7RootMotion_TrackTargetWithDistThreshold::Initialize()
{
	GID = NewGID();
	return true;
}


void FC7RootMotion_TrackTargetWithDistThreshold::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{
		if (!TargetEntity.IsValid() && !TryUpdateTargetEntity(Actor.GetWorld(), TargetEntityID, TargetEntity))
		{
			translationDelta = FVector::ZeroVector;
			rotDelta = FQuat::Identity;
			return;
		}
		check(TargetEntity.IsValid());
		
		FVector TargetLoc = TargetEntity->GetLocation();
		if (AActor* TargetActor = TargetEntity->GetLuaEntityBase()->GetActor())
		{
			GetActorFloorPos(TargetActor, TargetLoc);
		}

		FVector CurLoc = Actor.GetActorLocation();

		FVector Dir = TargetLoc - CurLoc;
		if (Dir.Size() < DistThreshold)
		{
			// 如果与目标的距离小于阈值，则不再追踪
			translationDelta = FVector::ZeroVector;
			rotDelta = FQuat::Identity;
			return;
		}

		Dir = Dir.GetSafeNormal();
		FRotator CurRot = Actor.GetActorRotation();
		FRotator TargetRot = Dir.ToOrientationRotator();

		translationDelta = DeltaTime * Speed * Dir;
		rotDelta = FQuat::Identity;
	}
}

bool FC7RootMotion_BezierUniformAccelerationThenVelocity::Initialize()
{
	if (Duration < UE_SMALL_NUMBER)
	{
		UE_LOG(LogTemp, Warning, TEXT("FC7RootMotion_BezierUniformAccelerationThenVelocity::Initialize found small duration"))
		return false;
	}
	
	// 三阶贝塞尔的四个点StartLoc、StartControlPoint、EndControlPoint、EndLoc
	StartControlPoint = StartLoc + StartDir * StartLen;
	EndControlPoint = EndLoc + EndDir * EndLen;
	if (StartControlPoint.Equals(StartLoc, 1) || EndControlPoint.Equals(EndLoc, 1) || StartLoc.Equals(EndLoc, 1))
	{
		// 四个点太近了，直接匀速直线运动吧，后面计算也不走了
		UE_LOG(LogTemp, Warning, TEXT("BezierUniformAccelerationThenVelocity::Initialize found near control points, will work as uniform velocity. StartLoc:%s, StartDir:%s, StartLen:%f, EndLoc:%s, EndDir:%s, EndLen:%f"),
		*StartLoc.ToString(), *StartDir.ToString(), StartLen, *EndLoc.ToString(), *EndDir.ToString(), EndLen)
		UE_LOG(LogTemp, Warning, TEXT("Duration:%f, VelocityInitRatio:%f, SlowdownRatioByDistance:%f"), Duration, VelocityInitRatio, SlowdownRatioByDistance)
		
		SlowdownTotalTime = -1;
		return FC7RootMotionBase::Initialize();
	}

	// 采样拟合贝塞尔曲线
	FSplineCurves MySplineCurves;
	const int32 Samples = FMath::Max(SplineSamples, 4);
	for (int32 i=0; i<=Samples; i++)
	{
		float T = (float)i / Samples;
		FVector Pos = CubicBezierInterp(StartLoc, StartControlPoint, EndControlPoint, EndLoc, T);
		
		MySplineCurves.Position.Points.Emplace(i, Pos, FVector::ZeroVector, FVector::ZeroVector, CIM_CurveAuto);
		MySplineCurves.Rotation.Points.Emplace(i, FQuat::Identity, FQuat::Identity, FQuat::Identity, CIM_CurveAuto);
		MySplineCurves.Scale.Points.Emplace(i, FVector(1.0f), FVector::ZeroVector, FVector::ZeroVector, CIM_CurveAuto);
	}
	MySplineCurves.UpdateSpline(false);
	SplineCurves = MySplineCurves;
	
	SlowdownRatioByDistance = FMath::Max(0.1, SlowdownRatioByDistance);
	float S = SplineCurves.GetSplineLength();
	float T = Duration;
	
	// 要满足先匀减速再匀速的初速度的下界，即只有初速度大于平均速度才能先减速再匀速
	float VelocityLowest = S/Duration;
	// 在下界的基础上乘上大于1的系数，保证有解
	VelocityInit = VelocityLowest * FMath::Max(1.1, VelocityInitRatio);

	// 最终方程: T*Vm^2 + [TVo-(a+1)S]Vm - (1-a)SVo = 0
	// 求根公式: 正根(-B+sqrt(B^2-4AC))/(2*A)
	float A = T;
	float B = T*VelocityInit - (SlowdownRatioByDistance+1) * S;
	float C = -(1-SlowdownRatioByDistance)*S*VelocityInit;
	float Bsquare4AC = B*B-4*A*C;
	if (Bsquare4AC >= 0)
	{
		float SqrtRoot = sqrt(Bsquare4AC);
		VelocityMin = FMath::Max(1, (-B+SqrtRoot)/(2*A));
		SlowdownTotalTime = FMath::Max(0.01, Duration - ((1-SlowdownRatioByDistance)*S)/VelocityMin);
		SlowdownAcceleration = (VelocityMin-VelocityInit)/SlowdownTotalTime;
		SlowdownTotalDistance = VelocityInit*SlowdownTotalTime + 0.5*SlowdownAcceleration*SlowdownTotalTime*SlowdownTotalTime;
#if UE_BUILD_DEVELOPMENT
		// 这两算出来应该严格相等，打印一下
		UE_LOG(LogTemp, Display, TEXT("FC7RootMotion_BezierUniformAccelerationThenVelocity slowdown distance error %f "), SlowdownTotalDistance - S*SlowdownRatioByDistance)
#endif
	}
	else
	{
		// 如果走到这就匀速直线运动吧
		UE_LOG(LogTemp, Warning, TEXT("BezierUniformAccelerationThenVelocity::Initialize can not found velocity min, will work as uniform velocity. StartLoc:%s, StartDir:%s, StartLen:%f, EndLoc:%s, EndDir:%s, EndLen:%f"),
		*StartLoc.ToString(), *StartDir.ToString(), StartLen, *EndLoc.ToString(), *EndDir.ToString(), EndLen)
		UE_LOG(LogTemp, Warning, TEXT("Duration:%f, VelocityInitRatio:%f, SlowdownRatioByDistance:%f"), Duration, VelocityInitRatio, SlowdownRatioByDistance)
		
		SlowdownTotalTime = -1;
	}
	return FC7RootMotionBase::Initialize();
}

void FC7RootMotion_BezierUniformAccelerationThenVelocity::Update(float DeltaTime, const AActor& Actor, FVector& translationDelta, FQuat& rotDelta)
{
	UpdateTime(DeltaTime);
	if (Duration > UE_SMALL_NUMBER && DeltaTime > UE_SMALL_NUMBER)
	{
		float T = GetClampFraction();
		const FVector CurrentLocation = Actor.GetActorLocation();
		FVector NextLocation;
		if (SlowdownTotalTime > 0)
		{
			float CurDistance = 0.f;
			float CurTime = T*Duration;
			if (CurTime <= SlowdownTotalTime)
			{
				// 匀减速 S=vt1+0.5*a*t1^2
				CurDistance = VelocityInit*CurTime + 0.5*SlowdownAcceleration*CurTime*CurTime;
			}
			else
			{
				// 匀速 S=S1+v(T-t1)
				CurDistance = SlowdownTotalDistance + VelocityMin*(CurTime - SlowdownTotalTime);
			}
			const float Param = SplineCurves.ReparamTable.Eval(CurDistance, 0.0f);
			NextLocation = SplineCurves.Position.Eval(Param, FVector::ZeroVector);
		}
		else
		{
			NextLocation = StartLoc + (EndLoc - StartLoc) * T;
		}
		translationDelta = (NextLocation - CurrentLocation);
		rotDelta = FQuat::Identity;
	}
}