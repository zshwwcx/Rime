// #pragma once

#include "3C/Movement/ScenePerception/ScenePerceptionDetector.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Movement/MovementPipeline/MovementContext.h"
#include "Components/CapsuleComponent.h"
#include "Engine/HitResult.h"
#include "Misc/MathFormula.h"
#include "KismetTraceUtils.h"
#include "Engine/BlockingVolume.h"
#include "BlockoutToolsParent.h"

#include "KGWaterSubsystem.h"

bool ScenePerceptionDetector::DoScenePerceptionDetect(float deltaTime, URoleMovementComponent& roleMC, MovementContext& MC) {
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("DoScenePerceptionDetect");
	auto* character = Cast<ABaseCharacter>(roleMC.GetRealMovementViewProxy()->GetCharacterOwner());

	if (!character) {
		return false;
	}
	

	bool hasDetectWork = IsDetectGround || IsDetectWater;
	if (!hasDetectWork) {
		return false;
	}

	// 需要一个表现侧看起来的脚底位置
	// 不能直接用actor位置, 因为有mesh的relative的offset的变换, actor位置现在就模型而言是有半高偏差的(配表的)
	FVector meshLocation = character->GetCharacterMeshLocation();
	FVector detectStartPos = FVector(meshLocation.X, meshLocation.Y, meshLocation.Z + DetectStartZOffset);
	TArray<AActor*> ActorsToIgnore;
	EDrawDebugTrace::Type drawDebugTrace = EDrawDebugTrace::None;

	if (IsDetectGround) {
		float OldGroundDist = CurGroundDist;
		FHitResult groundDetectOutHit;
		
		if (roleMC.CurrentFloor.IsWalkableFloor())
		{
			IsGroundDetected = true;
			groundDetectOutHit = roleMC.CurrentFloor.HitResult;
		}
		else
		{
			IsGroundDetected = DoGroundDetectByCollision(roleMC, meshLocation, deltaTime, groundDetectOutHit);
		}

		if(IsGroundDetected){
			CurGroundSurfacePosition = groundDetectOutHit.ImpactPoint;
			CurGroundDist = meshLocation.Z - CurGroundSurfacePosition.Z;
		}
		else {
			CurGroundDist = GroundDetectLength;
		}

		CheckGroundDistsToNotify(OldGroundDist, CurGroundDist, roleMC);
	}

	if (IsDetectWater) {
		float OldDistToWaterSurface = CurDistToWaterSurface;
		float OldWaterDepth = CurWaterDepth;

		// 先使用引擎提供的UKGWaterSubsystem尝试查询水深
		float WaterSubSystemWaterDepth = 0.0f;
		float WaterSubSystemWaterHeight = 0.0f;
		bool IsWaterDetectedByWaterSubsystem = DoWaterDetectByWaterSubSystem(roleMC, meshLocation, WaterSubSystemWaterDepth, WaterSubSystemWaterHeight);

		// UKGWaterSubsystem未查询到水体时，仍然保留碰撞的查询方式，避免以往功能失效
		bool IsWaterDetectedByCollision = false;
		FHitResult waterDetectOutHit;
		float WaterDepthLimit = -1.0f;	// 碰撞检查的水体，需要反向查找做水深限制处理，大于等于0时生效
		if (!IsWaterDetectedByWaterSubsystem && AllowDetectWaterByCollision)
		{
			IsWaterDetectedByCollision = DoWaterDetectByCollision(roleMC, meshLocation, waterDetectOutHit, WaterDepthLimit);
		}

		// todo 这里差一个进出的容忍范围处理
		bool newIsInWater = false;
		bool newIsInSwimDepth = false;
		bool NeedForceLeaveSwim = true;
		
		bool oldIsInWater = roleMC.GetIsInWater();
		bool oldIsInSwimDepth = roleMC.GetIsInSwimDepth();

		IsWaterDetected = IsWaterDetectedByWaterSubsystem || IsWaterDetectedByCollision;
		if (IsWaterDetected)
		{
			if (IsWaterDetectedByWaterSubsystem)
			{
				CurWaterSurfacePosition = FVector(meshLocation.X, meshLocation.Y, WaterSubSystemWaterHeight);
				CurDistToWaterSurface = meshLocation.Z - CurWaterSurfacePosition.Z;
				if (IsGroundDetected){
					// 水深数据受到地面位置的限制
					CurWaterDepth = FMath::Min(WaterSubSystemWaterDepth, FMath::Max(CurWaterSurfacePosition.Z - CurGroundSurfacePosition.Z, 0.0f));
				}
				else {
					CurWaterDepth = WaterSubSystemWaterDepth;
				}
				
			}
			else if (IsWaterDetectedByCollision)
			{
				CurWaterSurfacePosition = waterDetectOutHit.ImpactPoint;
				CurDistToWaterSurface = meshLocation.Z - CurWaterSurfacePosition.Z;
				if (IsGroundDetected) {
					// 水深数据受到地面位置的限制
					CurWaterDepth = FMath::Max(CurWaterSurfacePosition.Z - CurGroundSurfacePosition.Z, 0.0f);
				}
				else {
					CurWaterDepth = WaterDetectLength;
				}				

				if (WaterDepthLimit >= 0.0f)
				{
					CurWaterDepth = FMath::Min(CurWaterDepth, WaterDepthLimit);
					CurDistToWaterSurface = FMath::Max(CurDistToWaterSurface, -WaterDepthLimit);
				}
			}
			
			float distZFromWaterSurfaceToMesh = -CurDistToWaterSurface;

			// 角色在水面上
			if (distZFromWaterSurfaceToMesh < 0.0f) {
				newIsInWater = roleMC.CheckPreInWater(deltaTime, CurDistToWaterSurface);
				newIsInSwimDepth = false;
			}
			else {
				float finalToleratedInWaterDepthValue = InWaterDepthThreshold - WaterDistanceThresholdToelerateValue;
				if (finalToleratedInWaterDepthValue < 0.0f) {
					finalToleratedInWaterDepthValue = InWaterDepthThreshold;
				}

				// 进出水的探知是必须的
				if (distZFromWaterSurfaceToMesh > InWaterDepthThreshold) {
					newIsInWater = true;
				}
				// 做一个出水的容忍
				else if (oldIsInWater && distZFromWaterSurfaceToMesh > finalToleratedInWaterDepthValue){
					newIsInWater = true;
				}
				
				// 游泳深度的探测是可选的
				if (InSwimDepthThreashold > 0) {
					float finalToleratedInSwimDepthValue = InSwimDepthThreashold - WaterDistanceThresholdToelerateValue;
					if (finalToleratedInSwimDepthValue < 0.0f) {
						finalToleratedInSwimDepthValue = InSwimDepthThreashold;
					}
					NeedForceLeaveSwim = distZFromWaterSurfaceToMesh < finalToleratedInSwimDepthValue;

					if (distZFromWaterSurfaceToMesh > InSwimDepthThreashold) {
						newIsInSwimDepth = true;
					}
					else if (oldIsInSwimDepth && distZFromWaterSurfaceToMesh > finalToleratedInSwimDepthValue) {
						newIsInSwimDepth = true;
					}
				}

			}
		}
		else {
			CurWaterDepth = 0.0f;
			CurDistToWaterSurface = 0.0f;
		}
		
		roleMC.SetInWaterAndInSwitmDepthFromScenePD(newIsInWater, newIsInSwimDepth, NeedForceLeaveSwim);
		roleMC.UpdateInWaterLocoMaxSpeedScale();
		UpdateIsWaterWalkAllowed(roleMC);
		CheckWaterDistsToNotify(OldDistToWaterSurface, CurDistToWaterSurface, roleMC);
		CheckWaterDepthsToNotify(OldWaterDepth, CurWaterDepth, roleMC);
	}

	if (CanDoClimbStageUpdate())
	{
		DoClimbStageUpdate(deltaTime, roleMC, MC);
	}

	return true;
}

bool ScenePerceptionDetector::DoGroundDetectByCollision(const URoleMovementComponent& InRoleMC, const FVector& InMeshLoc, const float& InDeltaTime, FHitResult& OutGroundDetectHit)
{
	TArray<AActor*> ActorsToIgnore;
	EDrawDebugTrace::Type drawDebugTrace = EDrawDebugTrace::None;

	FVector detectStartPos = FVector(InMeshLoc.X, InMeshLoc.Y, InMeshLoc.Z + DetectStartZOffset);
	FVector groundDetectEndPos = FVector(InMeshLoc.X, InMeshLoc.Y, InMeshLoc.Z - GroundDetectLength);

	return UKismetSystemLibrary::LineTraceSingleForObjects(&InRoleMC, detectStartPos, groundDetectEndPos,
		GroundCollisionChannels, false, ActorsToIgnore, drawDebugTrace, OutGroundDetectHit, true,
		FLinearColor::Red, FLinearColor::Green, InDeltaTime);
}

bool ScenePerceptionDetector::DoWaterDetectByWaterSubSystem(const URoleMovementComponent& InRoleMC, const FVector& InMeshLoc, float& OutWaterDepth, float& OutWaterHeight)
{
	if (UKGWaterSubsystem* WaterSubsystem = UKGWaterSubsystem::GetWaterSubsystem(InRoleMC.GetWorld()))
	{
		OutWaterDepth = WaterSubsystem->GetWaterDepth(InMeshLoc);
		OutWaterHeight = WaterSubsystem->GetWaterHeight(InMeshLoc);
		if (OutWaterDepth > 0.0f)
		{
			return true;
		}
	}
	return false;
}

bool ScenePerceptionDetector::DoWaterDetectByCollision(const URoleMovementComponent& InRoleMC, const FVector& InMeshLoc, FHitResult& OutWaterDetectHit, float& OutWaterDepthLimit)
{
	FVector detectStartPos = FVector(InMeshLoc.X, InMeshLoc.Y, InMeshLoc.Z + DetectStartZOffset);
	FVector waterDetectEndPos = FVector(InMeshLoc.X, InMeshLoc.Y, InMeshLoc.Z - WaterDetectLength);
	TArray<AActor*> ActorsToIgnore;
	EDrawDebugTrace::Type drawDebugTrace = EDrawDebugTrace::None;
	OutWaterDepthLimit = -1.0f;
	
	bool OurIsWaterDetectedByCollision = UKismetSystemLibrary::LineTraceSingleForObjects(&InRoleMC, detectStartPos, waterDetectEndPos,
		WaterCollisionChannels, false, ActorsToIgnore, drawDebugTrace, OutWaterDetectHit, true,
		FLinearColor::Yellow, FLinearColor::Blue, 0.5f);
	if (OurIsWaterDetectedByCollision)
	{
		// 碰撞查到水体时，反向查找水体下沿的水深限制
		TArray<FHitResult> TempHits;
		if (UKismetSystemLibrary::LineTraceMultiForObjects(&InRoleMC, waterDetectEndPos, OutWaterDetectHit.ImpactPoint,
			WaterCollisionChannels, false, ActorsToIgnore, drawDebugTrace, TempHits, true,
			FLinearColor::Yellow, FLinearColor::Blue, 0.5f))
		{
			for (const FHitResult& SingleHit : TempHits)
			{
				// 找到相同的水体
				if (SingleHit.Component == OutWaterDetectHit.Component)
				{
					// 初始穿透，说明水很深，不施加水深限制
					if (!SingleHit.bStartPenetrating)
					{
						OutWaterDepthLimit = FMath::Max(0.0f, OutWaterDetectHit.ImpactPoint.Z - SingleHit.ImpactPoint.Z);
					}
					break;
				}
			}
		}
		else
		{
			OutWaterDepthLimit = 0.0f;
		}
	}

	return OurIsWaterDetectedByCollision;
}

void ScenePerceptionDetector::SwitchGroundDetect(bool isSwitchOn, ECollisionChannel groundChannel, float detectLength) {
	IsDetectGround = isSwitchOn;

	if (isSwitchOn) {
		GroundCollisionChannels.Empty();
		GroundCollisionChannels.Add(TEnumAsByte<EObjectTypeQuery>(UEngineTypes::ConvertToObjectType(groundChannel)));
		GroundDetectLength = detectLength;
		if (IsDetectWater) {
			// water一定是需要探测地面, 要做水深的处理
			GroundDetectLength = FMath::Max(GroundDetectLength, WaterDetectLength);
		}
	}
	else {
		CurGroundDist = 0.0f;
		IsGroundDetected = false;
		IsInEnterGroundDistance = true;
		IsInLeaveGroundDistance = false;
	}
}

void ScenePerceptionDetector::SwitchWaterDetect(bool isSwitchOn, ECollisionChannel waterChannel, float detectLength, bool InAllowDetectWaterByCollision){
	IsDetectWater = isSwitchOn;
	AllowDetectWaterByCollision = InAllowDetectWaterByCollision;

	if (isSwitchOn) {
		WaterCollisionChannels.Empty();
		WaterCollisionChannels.Add(TEnumAsByte<EObjectTypeQuery>(UEngineTypes::ConvertToObjectType(waterChannel)));
		WaterDetectLength = detectLength;
		if (IsDetectGround) {
			// water一定是需要探测地面, 要做水深的处理
			GroundDetectLength = FMath::Max(GroundDetectLength, WaterDetectLength);
		}
	}
	else {
		IsWaterDetected = false;
		CurWaterDepth = 0.0f;
		CurDistToWaterSurface = 0.0f;
	}

}

void ScenePerceptionDetector::SetDetectDistanceThresholdTolerateValue(float groundDistTolerateValue, float waterDistTolerateValue) {
	GroundDistanceThresholdTolerateValue = groundDistTolerateValue > 0.0f? groundDistTolerateValue : 0.0f;
	WaterDistanceThresholdToelerateValue = waterDistTolerateValue > 0.0f? waterDistTolerateValue: 0.0f;
}

void ScenePerceptionDetector::SetDetectDepthThreshold(float inWater, float inSwimDepth, float InWalkWaterDepth)
{ 
	InWaterDepthThreshold = inWater >= 0.0f? inWater: 0.0f;
	InSwimDepthThreashold = inSwimDepth; 
	InWaterWalkDepthThreashold = InWalkWaterDepth;
}

bool ScenePerceptionDetector::GetPosWithoutBlock(const UObject* WorldContextObject, AActor* Character, FVector& TargetPos)
{

	FVector Loc = Character->GetActorLocation();

	UCapsuleComponent* CapsuleComponent = Cast<UCapsuleComponent>(Character->GetRootComponent());
	if (!CapsuleComponent)
	{
		return false;
	}
	float Radius = CapsuleComponent->GetScaledCapsuleRadius();
	float HalfHeight = CapsuleComponent->GetScaledCapsuleHalfHeight();

	FVector StartPos = Loc + FVector(0, 0, (Radius + HalfHeight) * 3);

	TArray<AActor*> IgnoreActorList;
	IgnoreActorList.Add(Character);

	FHitResult OutHit;
	bool bHit = UKismetSystemLibrary::CapsuleTraceSingle(WorldContextObject, StartPos, Loc, Radius, HalfHeight, UEngineTypes::ConvertToTraceType(ECC_WorldStatic), false, IgnoreActorList, EDrawDebugTrace::None, OutHit, true);
	if (!bHit)
	{
		return false;
	}

	TargetPos = OutHit.Location;
	return true;
}


bool ScenePerceptionDetector::CheckCharacterIsStuck(const UObject* WorldContextObject, AActor* Character)
{
	//暂时只支持Capsule
	UCapsuleComponent* CurC = Cast<UCapsuleComponent>(Character->GetRootComponent());
	check(CurC);

	float Radius = CurC->GetScaledCapsuleRadius();
	float HalfHeight = CurC->GetScaledCapsuleHalfHeight();
	FVector Loc = Character->GetActorLocation();

	TArray<TEnumAsByte<EObjectTypeQuery> > ObjectTypes;
	ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECC_WorldStatic));

	TArray<AActor*> IgnoreActorList;
	IgnoreActorList.Add(Character);

	TArray<AActor*> OutActorList;
	//使用overlap判断是不是卡住了
	bool bBlock = UKismetSystemLibrary::CapsuleOverlapActors(WorldContextObject, Loc, Radius, HalfHeight, ObjectTypes, nullptr, IgnoreActorList, OutActorList);

	return bBlock;
}

void ScenePerceptionDetector::UpdateIsWaterWalkAllowed(URoleMovementComponent& roleMC)
{
	bool OldIsWaterWalkAllowed = bIsWaterWalkAllowed;

	if (OldIsWaterWalkAllowed && roleMC.GetIsInWaterWalk())
	{
		switch (InnerCheckIsWaterWalkAllowedWhenInState(roleMC, IsGroundDetected, IsWaterDetected, CurDistToWaterSurface, CurGroundDist))
		{
		case 0:
			bIsWaterWalkAllowed = false;
			break;
		case 1:
			bIsWaterWalkAllowed = true;
			break;
		}
	}
	else
	{
		switch (InnerCheckIsWaterWalkAllowedWhenNotInState(IsGroundDetected, IsWaterDetected, CurDistToWaterSurface, CurGroundDist, CurWaterDepth))
		{
		case 0:
			bIsWaterWalkAllowed = false;
			break;
		case 1:
			bIsWaterWalkAllowed = true;
			break;
		}
	}

	if (OldIsWaterWalkAllowed != bIsWaterWalkAllowed)
	{
		roleMC.UpdateIsWaterWalkAllowed(bIsWaterWalkAllowed);
	}
}

bool ScenePerceptionDetector::CheckIsPredictWaterWalkAllowedAtLocation(URoleMovementComponent& InRoleMC, const FVector& InDeltaLoc, float& OutDistToWaterSurface)
{
	ABaseCharacter* character = Cast<ABaseCharacter>(InRoleMC.GetRealMovementViewProxy()->GetCharacterOwner());
	if (!character) { return false; }
	FVector MeshLoc = character->GetCharacterMeshLocation();
	FVector CheckLocation = MeshLoc + InDeltaLoc;
	//UKismetSystemLibrary::DrawDebugSphere(&InRoleMC, CheckLocation, 50, 12, FLinearColor::Red, 5.0f, 3.0f);

	FHitResult GroundDetectHit;
	bool HasGround = DoGroundDetectByCollision(InRoleMC, CheckLocation, 0.0f, GroundDetectHit);
	float GroundDist = GroundDetectLength;
	if (HasGround) { GroundDist = MeshLoc.Z - GroundDetectHit.ImpactPoint.Z; }

	float WaterDepth, WaterHeight = 0.0f;
	bool HasWater = DoWaterDetectByWaterSubSystem(InRoleMC, CheckLocation, WaterDepth, WaterHeight);
	if (HasWater)
	{
		OutDistToWaterSurface = MeshLoc.Z - WaterHeight;
		if (OutDistToWaterSurface > 500.f) {
			// 如果距离水面高度过高，也不触发预测水面移动了
			return false;
		}
		if (IsGroundDetected) {
			// 水深数据受到地面位置的限制
			WaterDepth = FMath::Min(WaterDepth, FMath::Max(WaterHeight - GroundDetectHit.ImpactPoint.Z, 0.0f));
		}
	}


	return InnerCheckIsWaterWalkAllowedWhenNotInState(HasGround, HasWater, OutDistToWaterSurface, GroundDist, WaterDepth) == 1;
}

uint8 ScenePerceptionDetector::InnerCheckIsWaterWalkAllowedWhenInState(const URoleMovementComponent& InRoleMC, bool InIsGroundDetected, bool InIsWaterDetected, const float& InCurDistToWaterSurface, const float& InCurGroundDist)
{
	uint8 OutRes = 2;
	// 检查退出水面移动的条件
	if (InIsGroundDetected)
	{
		if (InIsWaterDetected)
		{
			// 地面高于水面才退出水面移动
			OutRes = (InCurDistToWaterSurface < InCurGroundDist) ? 1 : 0;
		}
		else
		{
			// 只检查到地面，没有水面，不允许水面移动
			OutRes = 0;
		}
	}
	else
	{
		if (InIsWaterDetected)
		{
			// 只检查到水面，没有地面，允许水面移动
			OutRes = 1;
		}
		//else
		//{
		//	// 无法判断
		//}
	}

	// 对于退出WaterWalk的情况，除了地面高于水面，还需要角色落地，才可以退出
	if (OutRes == 0 && InRoleMC.MovementMode != MOVE_Walking)
	{
		OutRes = 1;
	}

	return OutRes;
}

uint8 ScenePerceptionDetector::InnerCheckIsWaterWalkAllowedWhenNotInState(bool InIsGroundDetected, bool InIsWaterDetected, const float& InCurDistToWaterSurface, const float& InCurGroundDist, const float& InCurWaterDepth)
{
	// 检查允许进入水面移动的条件
	if (InIsGroundDetected)
	{
		if (InIsWaterDetected)
		{
			// 水面高于地面，且水深超过水面移动要求深度，才能允许水面移动
			return (InCurDistToWaterSurface < (InCurGroundDist - InWaterWalkDepthThreashold)) ? 1 : 0;
		}
		else
		{
			// 只有地没有水，不许进入水面移动
			return 0;
		}
	}
	else
	{
		if (InIsWaterDetected)
		{
			// 只检查到水面，没有地面，需要水深超过游泳深度，才允许水面移动
			return (InCurWaterDepth > InWaterWalkDepthThreashold) ? 1 : 0;
		}
		else
		{
			// 无法判断
			return 2;
		}
	}
}



#pragma region DistNotify
void ScenePerceptionDetector::CheckGroundDistsToNotify(const float& OldGroundDist, const float& NewGroundDist, URoleMovementComponent& roleMC)
{
	for (int32 i = 0; i < GroundDistListToNotify.Num(); i++)
	{
		if (NewGroundDist > OldGroundDist)
		{
			if (!(OldGroundDist < (GroundDistListToNotify[i] + GroundDistanceThresholdTolerateValue) && NewGroundDist > (GroundDistListToNotify[i] + GroundDistanceThresholdTolerateValue)))
			{
				continue;
			}
		}
		else if (NewGroundDist < OldGroundDist)
		{
			if (!(OldGroundDist > (GroundDistListToNotify[i] - GroundDistanceThresholdTolerateValue) && NewGroundDist < (GroundDistListToNotify[i] - GroundDistanceThresholdTolerateValue)))
			{
				continue;
			}
		}
		else
		{
			continue;
		}

		if (ABaseCharacter* Character = Cast<ABaseCharacter>(roleMC.GetCharacterOwner()))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_GroundDistsChanged", OldGroundDist, NewGroundDist);
		}
		return;
	}
}

void ScenePerceptionDetector::AddGrounDistToNotify(const float& GroundDistToNotify, const FString& Reason)
{
	if (GroundDistListReasonMap.Contains(GroundDistToNotify))
	{
		GroundDistListReasonMap[GroundDistToNotify].AddUnique(Reason);
	}
	else
	{
		GroundDistListReasonMap.Add(GroundDistToNotify, TArray<FString>{Reason});

		GroundDistListToNotify.AddUnique(GroundDistToNotify);
		GroundDistListToNotify.Sort();
	}
}

void ScenePerceptionDetector::RemoveGrounDistToNotify(const float& GroundDistToNotify, const FString& Reason)
{
	if (GroundDistListReasonMap.Contains(GroundDistToNotify))
	{
		if (GroundDistListReasonMap[GroundDistToNotify].Contains(Reason))
		{
			GroundDistListReasonMap[GroundDistToNotify].Remove(Reason);
			if (GroundDistListReasonMap[GroundDistToNotify].IsEmpty())
			{
				GroundDistListReasonMap.Remove(GroundDistToNotify);
				if (GroundDistListToNotify.Contains(GroundDistToNotify))
				{
					GroundDistListToNotify.Remove(GroundDistToNotify);
				}
			}
		}
	}
}

void ScenePerceptionDetector::CheckWaterDistsToNotify(const float& OldWaterDist, const float& NewWaterDist, URoleMovementComponent& roleMC)
{
	for (int32 i = 0; i < WaterDistListToNotify.Num(); i++)
	{
		if (NewWaterDist > OldWaterDist)
		{
			if (!(OldWaterDist < (WaterDistListToNotify[i] + WaterDistanceThresholdToelerateValue) && NewWaterDist > (WaterDistListToNotify[i] + WaterDistanceThresholdToelerateValue)))
			{
				continue;
			}
		}
		else if (NewWaterDist < OldWaterDist)
		{
			if (!(OldWaterDist > (WaterDistListToNotify[i] - WaterDistanceThresholdToelerateValue) && NewWaterDist < (WaterDistListToNotify[i] - WaterDistanceThresholdToelerateValue)))
			{
				continue;
			}
		}
		else
		{
			continue;
		}

		if (ABaseCharacter* Character = Cast<ABaseCharacter>(roleMC.GetCharacterOwner()))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_WaterDistsChanged", OldWaterDist, NewWaterDist);
		}
		return;
	}
}

void ScenePerceptionDetector::AddWaterDistToNotify(const float& WaterDistToNotify, const FString& Reason)
{
	if (WaterDistListReasonMap.Contains(WaterDistToNotify))
	{
		WaterDistListReasonMap[WaterDistToNotify].AddUnique(Reason);
	}
	else
	{
		WaterDistListReasonMap.Add(WaterDistToNotify, TArray<FString>{Reason});

		WaterDistListToNotify.AddUnique(WaterDistToNotify);
		WaterDistListToNotify.Sort();
	}
}

void ScenePerceptionDetector::RemoveWaterDistToNotify(const float& WaterDistToNotify, const FString& Reason)
{
	if (WaterDistListReasonMap.Contains(WaterDistToNotify))
	{
		if (WaterDistListReasonMap[WaterDistToNotify].Contains(Reason))
		{
			WaterDistListReasonMap[WaterDistToNotify].Remove(Reason);
			if (WaterDistListReasonMap[WaterDistToNotify].IsEmpty())
			{
				WaterDistListReasonMap.Remove(WaterDistToNotify);
				if (WaterDistListToNotify.Contains(WaterDistToNotify))
				{
					WaterDistListToNotify.Remove(WaterDistToNotify);
				}
			}
		}
	}
}

void ScenePerceptionDetector::CheckWaterDepthsToNotify(const float& OldWaterDepth, const float& NewWaterDepth, URoleMovementComponent& roleMC)
{
	for (int32 i = 0; i < WaterDepthListToNotify.Num(); i++)
	{
		if (NewWaterDepth > OldWaterDepth)
		{
			if (!(OldWaterDepth < (WaterDepthListToNotify[i] + WaterDistanceThresholdToelerateValue) && NewWaterDepth >(WaterDepthListToNotify[i] + WaterDistanceThresholdToelerateValue)))
			{
				continue;
			}
		}
		else if (NewWaterDepth < OldWaterDepth)
		{
			if (!(OldWaterDepth > (WaterDepthListToNotify[i] - WaterDistanceThresholdToelerateValue) && NewWaterDepth < (WaterDepthListToNotify[i] - WaterDistanceThresholdToelerateValue)))
			{
				continue;
			}
		}
		else
		{
			continue;
		}

		if (ABaseCharacter* Character = Cast<ABaseCharacter>(roleMC.GetCharacterOwner()))
		{
			ACTOR_CALL_LUA_ENTITY(Character, "KCB_WaterDepthsChanged", OldWaterDepth, NewWaterDepth);
		}
		return;
	}
}

void ScenePerceptionDetector::AddWaterDepthToNotify(const float& WaterDepthToNotify, const FString& Reason)
{
	if (WaterDepthListReasonMap.Contains(WaterDepthToNotify))
	{
		WaterDepthListReasonMap[WaterDepthToNotify].AddUnique(Reason);
	}
	else
	{
		WaterDepthListReasonMap.Add(WaterDepthToNotify, TArray<FString>{Reason});

		WaterDepthListToNotify.AddUnique(WaterDepthToNotify);
		WaterDepthListToNotify.Sort();
	}
}

void ScenePerceptionDetector::RemoveWaterDepthToNotify(const float& WaterDepthToNotify, const FString& Reason)
{
	if (WaterDepthListReasonMap.Contains(WaterDepthToNotify))
	{
		if (WaterDepthListReasonMap[WaterDepthToNotify].Contains(Reason))
		{
			WaterDepthListReasonMap[WaterDepthToNotify].Remove(Reason);
			if (WaterDepthListReasonMap[WaterDepthToNotify].IsEmpty())
			{
				WaterDepthListReasonMap.Remove(WaterDepthToNotify);
				if (WaterDepthListToNotify.Contains(WaterDepthToNotify))
				{
					WaterDepthListToNotify.Remove(WaterDepthToNotify);
				}
			}
		}
	}
}
#pragma endregion DistNotify



#pragma region Climb
bool ScenePerceptionDetector::IsWalkableFromClimb(const struct FHitResult& Hit, class URoleMovementComponent& roleMC)
{
	// Never walk up vertical surfaces.
	const FVector GravityRelativeImpactNormal = roleMC.RotateWorldToGravity(Hit.ImpactNormal);
	if (GravityRelativeImpactNormal.Z < UE_KINDA_SMALL_NUMBER)
	{
		return false;
	}

	// Can't walk on this surface if it is too steep.
	if (GravityRelativeImpactNormal.Z < MaxClimbOnAngleCos)
	{
		return false;
	}

	return true;
}

EIsClimbableRes ScenePerceptionDetector::IsClimbable(const FHitResult& Hit, class URoleMovementComponent& roleMC)
{
	if (!Hit.bBlockingHit)
	{
		return EIsClimbableRes::EICR_NotClimbale;
	}

	if (IsWalkableFromClimb(Hit, roleMC))
	{
		return EIsClimbableRes::EICR_ClimbStepOn;
	}
	
	if (const UPrimitiveComponent* HitComponent = Hit.Component.Get())
	{
		if (HitComponent->GetCollisionObjectType() != ECC_WorldStatic)
		{
			return EIsClimbableRes::EICR_NotClimbale;
		}

		if (AActor* HitCompOwner = HitComponent->GetOwner())
		{
			// 空气墙默认不允许攀爬
			// Todo：需要进一步优化默认禁用逻辑，ABlockingVolume太过宽泛，新增空气墙ObjectType处理
			if (HitCompOwner->IsA<ABlockingVolume>() || HitCompOwner->IsA<ABlockoutToolsParent>())
			{
				return EIsClimbableRes::EICR_NotClimbale;
			}
		}

		if (HitComponent->ComponentHasTag(DisableClimbComponentTag))
		{
			if (ACharacter* Owner = roleMC.GetCharacterOwner())
			{
				FVector ActorForward = Owner->GetActorForwardVector();
				if (ActorForward.Dot(-Hit.ImpactNormal) > 0.5f)
				{
					// 角色与无法攀爬的墙面发现夹角小于60°时，需要强制退出
					return EIsClimbableRes::EICR_ForceNotClimbale;
				}
			}
			return EIsClimbableRes::EICR_NotClimbale;
		}

		if (roleMC.GetNeedClimbCheckBounds())
		{
			FTransform ComponentToWorldTransform = HitComponent->GetComponentTransform();
			FBoxSphereBounds Bounds = HitComponent->CalcBounds(ComponentToWorldTransform);
			if (FMath::Abs(Bounds.SphereRadius) < roleMC.GetMinimumClimbBoundsRadius())
			{
				return EIsClimbableRes::EICR_NotClimbale;
			}

			FBoxSphereBounds LocalBounds = HitComponent->GetLocalBounds();
			FVector LocalBoundsWorldOrigin = ComponentToWorldTransform.TransformPosition(LocalBounds.Origin);
			FVector LocalBoundsWorldOriginToTraceStart = Hit.TraceStart - LocalBoundsWorldOrigin;
			FVector LocalBoundsToTraceStartInLocalSpace = ComponentToWorldTransform.InverseTransformVector(LocalBoundsWorldOriginToTraceStart);
			// 看看攀爬点碰撞到哪个面上，只检查对应面的Extent是否满足要求
			float XtoBoxExtentXRate = LocalBounds.BoxExtent.X <= 0.0f ? 0.0f : FMath::Abs(LocalBoundsToTraceStartInLocalSpace.X) / LocalBounds.BoxExtent.X;
			float YtoBoxExtentYRate = LocalBounds.BoxExtent.Y <= 0.0f ? 0.0f : FMath::Abs(LocalBoundsToTraceStartInLocalSpace.Y) / LocalBounds.BoxExtent.Y;
			float ZtoBoxExtentXRate = LocalBounds.BoxExtent.Z <= 0.0f ? 0.0f : FMath::Abs(LocalBoundsToTraceStartInLocalSpace.Z) / LocalBounds.BoxExtent.Z;

			if (XtoBoxExtentXRate > YtoBoxExtentYRate && XtoBoxExtentXRate > ZtoBoxExtentXRate)
			{
				if (LocalBounds.BoxExtent.Y * ComponentToWorldTransform.GetScale3D().Y < roleMC.GetMinimumClimbBoundsBoxLength() ||
					LocalBounds.BoxExtent.Z * ComponentToWorldTransform.GetScale3D().Z < roleMC.GetMinimumClimbBoundsBoxLength())
				{
					return EIsClimbableRes::EICR_NotClimbale;
				}
			}
			else if (YtoBoxExtentYRate > XtoBoxExtentXRate && YtoBoxExtentYRate > ZtoBoxExtentXRate)
			{
				if (LocalBounds.BoxExtent.X * ComponentToWorldTransform.GetScale3D().X < roleMC.GetMinimumClimbBoundsBoxLength() ||
					LocalBounds.BoxExtent.Z * ComponentToWorldTransform.GetScale3D().Z < roleMC.GetMinimumClimbBoundsBoxLength())
				{
					return EIsClimbableRes::EICR_NotClimbale;
				}
			}
			else
			{
				if (LocalBounds.BoxExtent.X * ComponentToWorldTransform.GetScale3D().X < roleMC.GetMinimumClimbBoundsBoxLength() ||
					LocalBounds.BoxExtent.Y * ComponentToWorldTransform.GetScale3D().Y < roleMC.GetMinimumClimbBoundsBoxLength())
				{
					return EIsClimbableRes::EICR_NotClimbale;
				}
			}
		}
	}

	const FVector GravityRelativeImpactNormal = Hit.ImpactNormal;
	if (GravityRelativeImpactNormal.Z >= roleMC.GetMaxClimbAngleCos() && GravityRelativeImpactNormal.Z <= roleMC.GetMinClimbAngleCos())
	{
		return EIsClimbableRes::EICR_IsClimbale;
	}

	return EIsClimbableRes::EICR_NotClimbale;
}

bool ScenePerceptionDetector::DoClimbStageUpdate(float deltaTime, class URoleMovementComponent& roleMC, class MovementContext& MC)
{
	ABaseCharacter* Character = Cast<ABaseCharacter>(roleMC.GetRealMovementViewProxy()->GetCharacterOwner());
	if (!Character)
	{
		return false;
	}

	if (CurClimbDetectStage == EClimbDetectStage::ECDS_TryFindClimbPos)
	{
		// FindClimbPos成功，进入Climbing
		if(DoClimbStageUpdateForTryFindClimbPosStage(deltaTime, roleMC, MC, Character))
		{
			CurClimbDetectStage = EClimbDetectStage::ECDS_Climbing;
		}
	}
	// 这里主要处理攀爬的自动退出逻辑
	else if (CurClimbDetectStage == EClimbDetectStage::ECDS_Climbing)
	{
		// Climbing失败，进入LeavingClimb
		if (!DoClimbStageUpdateForClimbingStage(deltaTime, roleMC, MC))
		{
			CurClimbDetectStage = EClimbDetectStage::ECDS_LeavingClimb;
		}
	}
	else if (CurClimbDetectStage == EClimbDetectStage::ECDS_LeavingClimb)
	{
		// LeavingClimb成功，再次回到TryFindClimbPos阶段
		if (DoClimbStageUpdateForLeavingClimbStage(deltaTime, roleMC, MC, Character))
		{
			CurClimbDetectStage = EClimbDetectStage::ECDS_TryFindClimbPos;
		}
	}

	return true;
}

bool ScenePerceptionDetector::DoClimbingInPipeline(float deltaTime, class URoleMovementComponent& roleMC, class MovementContext& MC)
{
	if (CanDoClimbingInPipeline())
	{
		FTransform CurWorldTrans = MC.GetCurrentActorTransform();
		FVector FinalWorldMovementDelta = MC.GetFinalWorldPosDelta(CurWorldTrans.GetRotation());
		FQuat FinalWorldQuat = MC.GetFinalWorldRot(CurWorldTrans.GetRotation());

		ACharacter* CharacterOwner = roleMC.GetCharacterOwner();
		if (!IsValid(CharacterOwner))
		{
			return false;
		}

		FCollisionResponseTemplate CollisionProfile;
		if (!UCollisionProfile::Get()->GetProfileTemplate(roleMC.GetTrackFloorCollisionPresetName(), CollisionProfile))
		{
			UCollisionProfile::Get()->GetProfileTemplate(TEXT("Pawn"), CollisionProfile);
		}
		FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(DoClimbingInPipeline), false, CharacterOwner);
		QueryParams.bIgnoreTouches = true;
		FCollisionResponseParams CollisionResponseParams = CollisionProfile.ResponseToChannels;
		const ECollisionChannel CollisionChannel = CollisionProfile.ObjectType;
		FCollisionShape HalfCollisionShape = FCollisionShape::MakeSphere(0.5f * roleMC.GetClimbCapsuleRadius());
		FCollisionShape EightyPerCentCollisionShape = FCollisionShape::MakeSphere(0.8f * roleMC.GetClimbCapsuleRadius());

		if (CurClimbDetectStage == EClimbDetectStage::ECDS_Climbing)
		{
			// 1. 没有位移，直接保持之前的计算结果重新插值
			if (FinalWorldMovementDelta.IsNearlyZero())
			{
				_UpdateMCForDoClimbingInPipeline(deltaTime, nullptr, MC, FinalWorldQuat);
				return true;
			}

			const FVector& TargetClimbImpactLoc = MC.GetTargetClimbImpactLoc();
			const FVector& TargetClimbLoc = MC.GetTargetClimbLoc();
			const FRotator& TargetClimbInverseImpactRot = MC.GetTargetClimbInverseImpactRot();
			const FVector TargetClimbInverseImpactVec = TargetClimbInverseImpactRot.Vector();
			FHitResult HitResult;
			TArray<FHitResult> HitResults;

			// 2. 先尝试从当前位置向目标移动，看有无碰撞。这里可以处理阴角的翻转
			FVector DetectStartLoc = CurWorldTrans.GetLocation();
			FVector DetectEndLoc = DetectStartLoc + FinalWorldMovementDelta.GetSafeNormal() * (FinalWorldMovementDelta.Size() + 0.5f * roleMC.GetClimbCapsuleRadius() + 5.0f);
#if UE_BUILD_DEVELOPMENT	
			if (ClimbDebugDrawMode == 1)
			{
				DrawDebugSphereTraceSingle(CharacterOwner->GetWorld(), DetectStartLoc, DetectEndLoc, 0.5f * roleMC.GetClimbCapsuleRadius(), EDrawDebugTrace::ForOneFrame, false, HitResult, FLinearColor::Green, FLinearColor::Red, 0.5f);
			}
#endif

			if (CharacterOwner->GetWorld()->SweepSingleByChannel(HitResult, DetectStartLoc, DetectEndLoc, FQuat::Identity, CollisionChannel, HalfCollisionShape, QueryParams, CollisionResponseParams))
			{
				int Res = _UpdateClimbHitRes(deltaTime, HitResult, roleMC, MC, FinalWorldQuat, -FinalWorldMovementDelta.GetSafeNormal() * (0.5f * roleMC.GetClimbCapsuleRadius() + 5.0f));
				if (Res >= 0)
				{
					return Res > 0;
				}
			}

			// 3. 再尝试从预期位置往TargetClimbInverseImpactVec查找攀爬位置。
			DetectStartLoc = CurWorldTrans.GetLocation() + FinalWorldMovementDelta;
			DetectEndLoc = DetectStartLoc + TargetClimbInverseImpactVec * (0.5 * roleMC.GetClimbCapsuleRadius());
#if UE_BUILD_DEVELOPMENT
			if (ClimbDebugDrawMode == 2)
			{
				DrawDebugSphereTraceSingle(CharacterOwner->GetWorld(), DetectStartLoc, DetectEndLoc, 0.8f * roleMC.GetClimbCapsuleRadius(), EDrawDebugTrace::ForOneFrame, false, HitResult, FLinearColor::Green, FLinearColor::Red, 0.5f);
			}
#endif
			if (CharacterOwner->GetWorld()->SweepSingleByChannel(HitResult, DetectStartLoc, DetectEndLoc, FQuat::Identity, CollisionChannel, EightyPerCentCollisionShape, QueryParams, CollisionResponseParams))
			{
				int Res = _UpdateClimbHitRes(deltaTime, HitResult, roleMC, MC, FinalWorldQuat, -TargetClimbInverseImpactVec * (0.2f * roleMC.GetClimbCapsuleRadius()));
				if (Res >= 0)
				{
					return Res > 0;
				}
			}
			else
			{
				// 阳角翻越
				DetectStartLoc = DetectEndLoc;/*CurWorldTrans.GetLocation() + FinalWorldMovementDelta + TargetClimbInverseImpactVec * (0.5 * ClimbRadius);*/ 
				DetectEndLoc = CurWorldTrans.GetLocation() + TargetClimbInverseImpactVec * (0.5 * roleMC.GetClimbCapsuleRadius()) - FinalWorldMovementDelta.GetSafeNormal() * 0.8f * roleMC.GetClimbCapsuleRadius();
#if UE_BUILD_DEVELOPMENT
				if (ClimbDebugDrawMode == 3)
				{
					DrawDebugSphereTraceSingle(CharacterOwner->GetWorld(), DetectStartLoc, DetectEndLoc, 0.8f * roleMC.GetClimbCapsuleRadius(), EDrawDebugTrace::ForOneFrame, false, HitResult, FLinearColor::Green, FLinearColor::Red, 0.5f);
				}
#endif
				if (CharacterOwner->GetWorld()->SweepSingleByChannel(HitResult, DetectStartLoc, DetectEndLoc, FQuat::Identity, CollisionChannel, EightyPerCentCollisionShape, QueryParams, CollisionResponseParams))
				{
					int Res = _UpdateClimbHitRes(deltaTime, HitResult, roleMC, MC, FinalWorldQuat, FinalWorldMovementDelta.GetSafeNormal() * (0.2f * roleMC.GetClimbCapsuleRadius()));
					if (Res >= 0)
					{
						if (Res > 0)
						{
							ExecuteBlend();
						}
						return Res > 0;
					}
				}
			}

			// 如果怎么样都找不到合适的攀爬点，先保持不动
			_UpdateMCForDoClimbingInPipeline(deltaTime, nullptr, MC, FinalWorldQuat);
			return false;
		}
	}

	return false;
}

int ScenePerceptionDetector::_UpdateClimbHitRes(float deltaTime, FHitResult& InHitResult, class URoleMovementComponent& InRoleMC, class MovementContext& InMC, const FQuat& InFinalWorldQuat, const FVector& InHitLocAdjust)
{
	EIsClimbableRes ClimbaleRes = IsClimbable(InHitResult, InRoleMC);
	if (ClimbaleRes == EIsClimbableRes::EICR_IsClimbale)
	{
		InHitResult.Location += InHitLocAdjust;
		_UpdateMCForDoClimbingInPipeline(deltaTime, &InHitResult, InMC, InFinalWorldQuat);
		return 1;
	}
	else if (ClimbaleRes == EIsClimbableRes::EICR_ForceNotClimbale)
	{
		CancelClimbInPipeline(InRoleMC, InMC, InFinalWorldQuat);
		return 0;
	}
	else if (ClimbaleRes == EIsClimbableRes::EICR_ClimbStepOn)
	{
		if (InRoleMC.TryFindStepOnLoc(InHitResult.ImpactPoint, InHitResult, &InRoleMC.CapsuleRadiusBeforeClimb, &InRoleMC.CapsuleHalfHeightBeforeClimb))
		{
			InRoleMC.TryExecuteStepOn(InHitResult);
			CancelClimbInPipeline(InRoleMC, InMC, InFinalWorldQuat);
			return 0;
		}
	}

	return -1;
}

void ScenePerceptionDetector::_UpdateMCForDoClimbingInPipeline(float deltaTime, const FHitResult* InHitResult, class MovementContext& MC, const FQuat& InFinalWorldQuat)
{
	// 没有InHitResult，则按照之前的结果进行插值
	if (InHitResult)
	{
		MC.SetTargetClimbImpactLoc(InHitResult->ImpactPoint);
		MC.SetTargetClimbLoc(InHitResult->Location);
		MC.SetTargetClimbInverseImpactRot((InHitResult->ImpactPoint - InHitResult->Location).Rotation());
		// MC.SetTargetClimbInverseImpactRot((-InHitResult->ImpactNormal).Rotation());
	}

	MC.ClearAbsoluteWorldPos();
	MC.ClearAbsoluteWorldRot();
	if (CurBlendTime > 0.0f)
	{
		FVector NewMovementDelta = FVector::ZeroVector;
		MathFormula::DecayValue(NewMovementDelta, MC.GetCurrentActorTransform().GetTranslation(), MC.GetTargetClimbLoc(), TotalBlendTime, deltaTime);
		MC.OccupyAbsoluteWorldPos(NewMovementDelta);

		CurBlendTime -= deltaTime;
	}
	else
	{
		MC.OccupyAbsoluteWorldPos(MC.GetTargetClimbLoc());
	}

	FRotator NewWorldRot = FRotator::ZeroRotator;
	MathFormula::DecayValue(NewWorldRot, InFinalWorldQuat.Rotator(), MC.GetTargetClimbInverseImpactRot(), 0.05f, deltaTime);
	MC.OccupyAbsoluteWorldRot(NewWorldRot.Quaternion());
}

#pragma region Hurdle

bool ScenePerceptionDetector::CheckHurdle(URoleMovementComponent* RoleMC, UCapsuleComponent* Capsule,
	int& HurdleType, FVector& AlignPoint, FVector& FirstWarpPoint, FVector& SecondWarpPoint, FVector& FallingWarpPoint,
	float& OutHurdleYaw)
{
	if(RoleMC == nullptr || Capsule == nullptr)
	{
		return false;
	}

	UWorld* World = RoleMC->GetWorld();
	if(World == nullptr)
	{
		return false;
	}
	
	const FVector InputLocoVec = RoleMC->GetLocoInputVector();
	if(InputLocoVec.IsNearlyZero() || FMath::RadiansToDegrees(FMath::Acos(InputLocoVec | RoleMC->GetForwardVector())) > HurdleYawThreshold)
	{
		return false;
	}

	static constexpr float LocationCorrectOffset = 2.f;
	static constexpr float LocationAlignCorrectOffset = 10.f;
	static constexpr float LocationCorrectOffset_Small = 1.f;
	static constexpr float FallingCorrectOffset_Small = 100.f;

	float HurdleDetect = IdleHurdleDetect;
	float MinHurdleLedge = IdleMinHurdleLedge;
	float MaxHurdleLedge = IdleMaxHurdleLedge;
	float MaxHurdleThickness = IdleMaxHurdleThickness;
	float HurdleTypeShortThicknessThreshold = IdleHurdleTypeShortThicknessThreshold;
	float HurdleTypeLongThicknessThreshold = IdleHurdleTypeLongThicknessThreshold;
	float HurdleTypeFallingDistance = IdleHurdleTypeFallingDistance;
	
	float MoveSpeed = RoleMC->GetMovementSpeed();
	if(MoveSpeed > WalkSpeedThreshold)
	{
		int SpeedStage = RoleMC->GetSpeedState();
		if(SpeedStage < 1)
		{
			HurdleDetect = WalkHurdleDetect;
			MinHurdleLedge = WalkMinHurdleLedge;
			MaxHurdleLedge = WalkMaxHurdleLedge;
			MaxHurdleThickness = WalkMaxHurdleThickness;
			HurdleTypeShortThicknessThreshold = WalkHurdleTypeShortThicknessThreshold;
			HurdleTypeLongThicknessThreshold = WalkHurdleTypeLongThicknessThreshold;
			HurdleTypeFallingDistance = WalkHurdleTypeFallingDistance;
		}
		else
		{
			HurdleDetect = RunHurdleDetect;
			MinHurdleLedge = RunMinHurdleLedge;
			MaxHurdleLedge = RunMaxHurdleLedge;
			MaxHurdleThickness = RunMaxHurdleThickness;
			HurdleTypeShortThicknessThreshold = RunHurdleTypeShortThicknessThreshold;
			HurdleTypeLongThicknessThreshold = RunHurdleTypeLongThicknessThreshold;
			HurdleTypeFallingDistance = RunHurdleTypeFallingDistance;
		}
	}

	const float CapsuleRadius = Capsule->GetScaledCapsuleRadius();
	const float CapsuleHalfHeight = Capsule->GetScaledCapsuleHalfHeight();
	const float HalfHeight = (MaxHurdleLedge - MinHurdleLedge) / 2.f;

	FVector RowBaseLocation = RoleMC->GetLocation();
	FVector BaseLocation = RowBaseLocation;
	BaseLocation.Z -= CapsuleHalfHeight - LocationCorrectOffset;
	FVector FrontLedgeDetectStart = BaseLocation - InputLocoVec * CapsuleRadius;
	FrontLedgeDetectStart.Z += (MaxHurdleLedge + MinHurdleLedge) / 2.f;
	FVector FrontLedgeDetectEnd = FrontLedgeDetectStart + InputLocoVec * (HurdleDetect + CapsuleRadius);

	FCollisionShape DetectCollisionShape = FCollisionShape::MakeCapsule(CapsuleRadius, HalfHeight);
	HurdleDetectQueryParams.ClearIgnoredSourceObjects();
	HurdleDetectQueryParams.AddIgnoredActor(RoleMC->GetCharacterOwner());

	FHitResult HitResult;
	{
		const bool bHit = World->SweepSingleByObjectType(HitResult, FrontLedgeDetectStart, FrontLedgeDetectEnd,
		                                                 FQuat::Identity, HurdleDetectObjectQueryParams,
		                                                 DetectCollisionShape, HurdleDetectQueryParams);
	}
	if(!HitResult.IsValidBlockingHit())
	{
		return false;
	}

	const FVector InitialTraceImpactPoint = HitResult.ImpactPoint;
	FVector InitialTraceImpactNormal = FRotator(0, HurdleYaw + 180.f, 0).Vector();

	FVector FirstPointTraceEnd = InitialTraceImpactPoint /* - InitialTraceImpactNormal * CapsuleRadius */;
	FirstPointTraceEnd.Z = BaseLocation.Z;

	FVector FirstPointTraceStart = FirstPointTraceEnd;
	FirstPointTraceStart.Z += MaxHurdleLedge + CapsuleRadius + LocationCorrectOffset;

	DetectCollisionShape.SetSphere(CapsuleRadius);
	{
		if (bOpenHurdleDebug) UKismetSystemLibrary::SphereTraceSingleForObjects(World, FirstPointTraceStart, FirstPointTraceEnd, CapsuleRadius, HurdleQueryTypes, false, {}, EDrawDebugTrace::ForDuration, HitResult, true);
		const bool bHit = World->SweepSingleByObjectType(HitResult, FirstPointTraceStart, FirstPointTraceEnd,
														 FQuat::Identity, HurdleDetectObjectQueryParams,
														 DetectCollisionShape, HurdleDetectQueryParams);
	}
	if(!HitResult.IsValidBlockingHit())
	{
		return false;
	}

	FVector FirstWarpLocation = HitResult.Location;
	FirstWarpLocation.Z = HitResult.ImpactPoint.Z;
	if(!CapsuleHasRoomCheck(World, FirstWarpLocation, CapsuleHalfHeight, CapsuleRadius))
	{
		return false;
	}

	FVector BackFloorDetectStart = FirstPointTraceStart - InitialTraceImpactNormal * (MaxHurdleThickness + CapsuleRadius + LocationCorrectOffset) + FVector::DownVector * (HalfHeight + CapsuleRadius);
	FVector BackFloorDetectEnd = FirstPointTraceStart + FVector::DownVector * (HalfHeight + CapsuleRadius);

	DetectCollisionShape.SetCapsule(CapsuleRadius, HalfHeight);
	{
		const bool bHit = World->SweepSingleByObjectType(HitResult, BackFloorDetectStart, BackFloorDetectEnd,
		                                                 FQuat::Identity, HurdleDetectObjectQueryParams,
		                                                 DetectCollisionShape, HurdleDetectQueryParams);
	}
	if(!HitResult.IsValidBlockingHit())
	{
		return false;
	}

	FVector SecondPointTraceStart = HitResult.Location + InitialTraceImpactNormal * CapsuleRadius / 2.f;
	SecondPointTraceStart.Z = FirstPointTraceStart.Z;
	FVector SecondPointTraceEnd = SecondPointTraceStart;
	SecondPointTraceEnd.Z = BaseLocation.Z;

	DetectCollisionShape.SetSphere(CapsuleRadius);
	{
		if (bOpenHurdleDebug) UKismetSystemLibrary::SphereTraceSingleForObjects(World, SecondPointTraceStart, SecondPointTraceEnd, CapsuleRadius, HurdleQueryTypes, false, {}, EDrawDebugTrace::ForDuration, HitResult, true);
		const bool bHit = World->SweepSingleByObjectType(HitResult, SecondPointTraceStart, SecondPointTraceEnd,
														 FQuat::Identity, HurdleDetectObjectQueryParams,
														 DetectCollisionShape, HurdleDetectQueryParams);
	}
	if(!HitResult.IsValidBlockingHit())
	{
		return false;
	}

	FVector SecondWarpLocation = HitResult.Location;
	SecondWarpLocation.Z = HitResult.ImpactPoint.Z;
	if(!CapsuleHasRoomCheck(World, SecondWarpLocation, CapsuleHalfHeight, CapsuleRadius))
	{
		return false;
	}

	AlignPoint = RowBaseLocation;
	if(ABaseCharacter* Player = Cast<ABaseCharacter>(RoleMC->GetCharacterOwner()))
	{
		if (FVector::DistXY(AlignPoint, FirstPointTraceStart) > (CapsuleRadius + LocationAlignCorrectOffset))
		{
			if (!Player->SimpleGetAndCheckStickGroundLocationFromSpecificLocation(FirstPointTraceStart + (CapsuleRadius + LocationAlignCorrectOffset) * InitialTraceImpactNormal, AlignPoint))
			{
				AlignPoint = RowBaseLocation;
			}
			// AlignPoint.Z = RowBaseLocation.Z; // TODO
		}
	}
	AlignPoint.Z -= CapsuleHalfHeight;

	int OutHurdleType = EHurdleType::ThickThreeWrap_Left;
	FVector SecondWarpLocationCopy = SecondWarpLocation;
	if((SecondWarpLocation - FirstWarpLocation).SizeSquared() < HurdleTypeShortThicknessThreshold * HurdleTypeShortThicknessThreshold)
	{
		OutHurdleType = CheckHurdleIsRight(World, FirstWarpLocation, SecondWarpLocation, CapsuleRadius, FirstPointTraceStart.Z, BaseLocation.Z) ? EHurdleType::Slim_Right : EHurdleType::Slim_Left;
	}
	else
	{
		FVector TopLedgeCheckCenter = (FirstPointTraceStart + SecondPointTraceStart) / 2.f;
		TopLedgeCheckCenter.Z = (SecondPointTraceStart.Z + FMath::Max(FirstWarpLocation.Z, SecondWarpLocation.Z) + LocationCorrectOffset) / 2.f;
		// FVector Box{(SecondPointTraceStart - FirstPointTraceStart).Length() / 2.f, CapsuleRadius, FMath::Abs(SecondPointTraceStart.Z - TopLedgeCheckCenter.Z)};
		// FQuat BoxDir = (SecondPointTraceStart - FirstPointTraceStart).Rotation().Quaternion();
		// UKismetSystemLibrary::DrawDebugBox(World, TopLedgeCheckCenter, Box, FLinearColor::Blue, BoxDir.Rotator());
		FVector MidRoomCheckStart = FirstWarpLocation; MidRoomCheckStart.Z += LocationCorrectOffset_Small;
		FVector MidRoomCheckEnd = SecondWarpLocation; MidRoomCheckEnd.Z += LocationCorrectOffset_Small;
		if (bOpenHurdleDebug) UKismetSystemLibrary::LineTraceSingleForObjects(World, MidRoomCheckStart, MidRoomCheckEnd, HurdleQueryTypes, false, {}, EDrawDebugTrace::ForDuration, HitResult, true);
		if(World->LineTraceSingleByObjectType(HitResult, MidRoomCheckStart, MidRoomCheckEnd, HurdleDetectObjectQueryParams, HurdleDetectQueryParams))
		{
			DetectCollisionShape.SetSphere(CapsuleRadius);
			{
				FVector MidPointTraceStart = (FirstPointTraceStart + SecondPointTraceStart) / 2.f;
				FVector MidPointTraceEnd = MidPointTraceStart;
				MidPointTraceEnd.Z = BaseLocation.Z;
				const bool bHit = World->SweepSingleByObjectType(HitResult, MidPointTraceStart, MidPointTraceEnd, FQuat::Identity, HurdleDetectObjectQueryParams, DetectCollisionShape, HurdleDetectQueryParams);
				if ((SecondWarpLocation - FirstWarpLocation).SizeSquared() < HurdleTypeLongThicknessThreshold * HurdleTypeLongThicknessThreshold)
				{
					OutHurdleType = CheckHurdleIsRight(World, FirstWarpLocation, SecondWarpLocation, CapsuleRadius, FirstPointTraceStart.Z, BaseLocation.Z) ? EHurdleType::ThickTwoWrap_Right : EHurdleType::ThickTwoWrap_Left;
					if(HitResult.IsValidBlockingHit())
					{
						FirstWarpLocation = HitResult.Location;
						FirstWarpLocation.Z = HitResult.ImpactPoint.Z;
						SecondWarpLocation = FirstWarpLocation;
					}
					else
					{
						float MaxZ = FMath::Max(FirstWarpLocation.Z, SecondWarpLocation.Z);
						FirstWarpLocation = (FirstWarpLocation + SecondWarpLocation) / 2.f;
						FirstWarpLocation.Z = MaxZ;
						SecondWarpLocation = FirstWarpLocation;
					}
				}
				else
				{
					OutHurdleType = CheckHurdleIsRight(World, FirstWarpLocation, SecondWarpLocation, CapsuleRadius, FirstPointTraceStart.Z, BaseLocation.Z) ? EHurdleType::ThickThreeWrap_Right : EHurdleType::ThickThreeWrap_Left;
					if(HitResult.IsValidBlockingHit())
					{
						FirstWarpLocation.Z = HitResult.ImpactPoint.Z;
						SecondWarpLocation.Z = FirstWarpLocation.Z;
					}
				}
			}
		}
		else
		{
			if (CheckHurdleIsRight(World, FirstWarpLocation, SecondWarpLocation, CapsuleRadius, FirstPointTraceStart.Z, BaseLocation.Z))
			{
				OutHurdleType = EHurdleType::ThickThreeWrap_Right;
			}
		}
	}

	FVector ThirdPointTraceStart = SecondWarpLocationCopy - InitialTraceImpactNormal * HurdleTypeFallingDistance;
	FVector ThirdPointTraceEnd = ThirdPointTraceStart;
	ThirdPointTraceEnd.Z = BaseLocation.Z - FallingCorrectOffset_Small;

	DetectCollisionShape.SetSphere(CapsuleRadius);
	{
		if (bOpenHurdleDebug) UKismetSystemLibrary::SphereTraceSingleForObjects(World, ThirdPointTraceStart, ThirdPointTraceEnd, CapsuleRadius, HurdleQueryTypes, false, {}, EDrawDebugTrace::ForDuration, HitResult, true);
 		const bool bHit = World->SweepSingleByObjectType(HitResult, ThirdPointTraceStart, ThirdPointTraceEnd,
														 FQuat::Identity, HurdleDetectObjectQueryParams,
														 DetectCollisionShape, HurdleDetectQueryParams);
	}
	if(HitResult.IsValidBlockingHit())
	{
		FallingWarpPoint = HitResult.Location;
		FallingWarpPoint.Z = HitResult.ImpactPoint.Z;

		if(ABaseCharacter* Player = Cast<ABaseCharacter>(RoleMC->GetCharacterOwner()))
		{
			FallingWarpPoint = Player->SimpleGetStickGroundLocationFromSpecificLocation(FallingWarpPoint);
			FallingWarpPoint.Z -= CapsuleHalfHeight;
		}
	}
	else
	{
		FallingWarpPoint = ThirdPointTraceEnd;
	}

	if(OutHurdleType == EHurdleType::Slim_Left || OutHurdleType == EHurdleType::Slim_Right)
	{
		float MaxZ = FMath::Max(FirstWarpLocation.Z, SecondWarpLocation.Z);
		FirstWarpLocation = (FirstWarpLocation + SecondWarpLocation) / 2.f;
		FirstWarpLocation.Z = MaxZ;
		SecondWarpLocation = FirstWarpLocation;
	}
	
	HurdleType = OutHurdleType;
	FirstWarpPoint = FirstWarpLocation;
	FirstWarpPoint.Z += LocationCorrectOffset;
	SecondWarpPoint = SecondWarpLocation;
	SecondWarpPoint.Z += LocationCorrectOffset;
	OutHurdleYaw = (-InitialTraceImpactNormal).Rotation().Yaw;

	return true;
}

bool ScenePerceptionDetector::CheckHurdleIsRight(class UWorld* World, const FVector& Start, const FVector& End,
	float Radius, float TopZ, float BaseZ) const
{
	if(World == nullptr)
	{
		return false;
	}

	FRotator StartToEnd = (End - Start).Rotation();
	StartToEnd.Pitch = 0.f;
	StartToEnd.Yaw += 90.f;
	const FVector LeftToRightDir = StartToEnd.Vector();
	const FVector Mid = (Start + End) / 2.f;
	FVector Left =  Mid - LeftToRightDir * Radius / 2.f;
	FVector Right =  Mid + LeftToRightDir * Radius / 2.f;
	FVector LeftStart = Left; LeftStart.Z = TopZ;
	FVector LeftEnd = Left; LeftEnd.Z = BaseZ;
	FVector RightStart = Right; RightStart.Z = TopZ;
	FVector RightEnd = Right; RightEnd.Z = BaseZ;

	FHitResult HitResult;
	{
		if (World->LineTraceSingleByObjectType(HitResult, LeftStart, LeftEnd, HurdleDetectObjectQueryParams, HurdleDetectQueryParams))
		{
			Left = HitResult.ImpactPoint;
			if (World->LineTraceSingleByObjectType(HitResult, RightStart, RightEnd, HurdleDetectObjectQueryParams, HurdleDetectQueryParams))
			{
				Right = HitResult.ImpactPoint;
				if (Right.Z > Left.Z)
				{
					float SinValue = FMath::Sin(FMath::DegreesToRadians((Left - Right).Rotation().Pitch));
					float SinThreshold = FMath::Sin(FMath::DegreesToRadians(HurdleDegreeThreshold));
					if (SinValue * SinValue > SinThreshold * SinThreshold)
					{
						return true;
					}
				}
			}
		}
	}
	return false;
}

bool ScenePerceptionDetector::CapsuleHasRoomCheck(UWorld* World, const FVector& BaseLocation, float HalfHeight, float Radius) const
{
	if(World == nullptr)
	{
		return false;
	}
	static constexpr float LocationCorrectOffset = 2.f;

	FVector TraceCenter = BaseLocation;
	TraceCenter.Z += HalfHeight + LocationCorrectOffset;
	const FCollisionShape SphereCollisionShape = FCollisionShape::MakeCapsule(Radius, HalfHeight);
	return !World->OverlapAnyTestByObjectType(TraceCenter, FQuat::Identity, HurdleDetectObjectQueryParams, SphereCollisionShape, HurdleDetectQueryParams);
}

bool ScenePerceptionDetector::GetHurdleHandIKLocation(URoleMovementComponent* RoleMC, const FVector& EffectBoneLocation, FVector& OutLocation, float DetectDepth) const
{
	if(RoleMC == nullptr)
	{
		return false;
	}

	UWorld* World = RoleMC->GetWorld();
	if(World == nullptr)
	{
		return false;
	}

	static constexpr float HandIKDetectCorrectOffset = 30.f; 
	static constexpr float HandRadius = 10.f;
	
	const FVector DetectStart = EffectBoneLocation + FVector::UpVector * HandIKDetectCorrectOffset;
	const FVector DetectEnd = EffectBoneLocation + FVector::DownVector * DetectDepth;
	FHitResult OutResult;
	{
		FCollisionQueryParams QueryParams;
		QueryParams.AddIgnoredActor(RoleMC->GetCharacterOwner());
		if (bOpenHurdleDebug) UKismetSystemLibrary::SphereTraceSingleForObjects(World, DetectStart, DetectEnd, HandRadius, HurdleQueryTypes, false, {}, EDrawDebugTrace::ForDuration, OutResult, true);
		const bool bHit = World->SweepSingleByObjectType(OutResult, DetectStart, DetectEnd, FQuat::Identity, HurdleDetectObjectQueryParams, FCollisionShape::MakeSphere(HandRadius), QueryParams);
	}
	if(OutResult.IsValidBlockingHit())
	{
		FVector Result = OutResult.Location;
		Result.Z = OutResult.ImpactPoint.Z;
		OutLocation = Result;
		return true;
	}

	return false;
}

void ScenePerceptionDetector::SetHurdleDetect(float InHurdleYaw, float InHurdleYawThreshold, float InIdleSpeedThreshold,
	const TArray<int>& InHurdleDetectObjectTypes, float InHurdleDegreeThreshold, float InIdleHurdleDetect,
	float InIdleMinHurdleLedge, float InIdleMaxHurdleLedge, float InIdleMaxHurdleThickness,
	float InIdleHurdleTypeShortThicknessThreshold, float InIdleHurdleTypeLongThicknessThreshold,
	float InIdleHurdleTypeFallingDistance, float InWalkHurdleDetect, float InWalkMinHurdleLedge,
	float InWalkMaxHurdleLedge, float InWalkMaxHurdleThickness, float InWalkHurdleTypeShortThicknessThreshold,
	float InWalkHurdleTypeLongThicknessThreshold, float InWalkHurdleTypeFallingDistance, float InRunHurdleDetect,
	float InRunMinHurdleLedge, float InRunMaxHurdleLedge,
	float InRunMaxHurdleThickness, float InRunHurdleTypeShortThicknessThreshold,
	float InRunHurdleTypeLongThicknessThreshold, float InRunHurdleTypeFallingDistance)
{
	HurdleYaw = InHurdleYaw;
	HurdleYawThreshold = InHurdleYawThreshold;
	WalkSpeedThreshold = InIdleSpeedThreshold;
	TArray<TEnumAsByte<EObjectTypeQuery>> HurdleDetectObjectTypes;
	for(auto& ObjectType : InHurdleDetectObjectTypes)
	{
		HurdleDetectObjectTypes.Emplace(static_cast<EObjectTypeQuery>(ObjectType));
	}
	HurdleQueryTypes = HurdleDetectObjectTypes;
	HurdleDetectObjectQueryParams = HurdleDetectObjectTypes;
	HurdleDegreeThreshold = InHurdleDegreeThreshold;

	IdleHurdleDetect = InIdleHurdleDetect;
	IdleMinHurdleLedge = InIdleMinHurdleLedge;
	IdleMaxHurdleLedge = InIdleMaxHurdleLedge;
	IdleMaxHurdleThickness = InIdleMaxHurdleThickness;
	IdleHurdleTypeShortThicknessThreshold = InIdleHurdleTypeShortThicknessThreshold;
	IdleHurdleTypeLongThicknessThreshold = InIdleHurdleTypeLongThicknessThreshold;
	IdleHurdleTypeFallingDistance = InIdleHurdleTypeFallingDistance;

	WalkHurdleDetect = InWalkHurdleDetect;
	WalkMinHurdleLedge = InWalkMinHurdleLedge;
	WalkMaxHurdleLedge = InWalkMaxHurdleLedge;
	WalkMaxHurdleThickness = InWalkMaxHurdleThickness;
	WalkHurdleTypeShortThicknessThreshold = InWalkHurdleTypeShortThicknessThreshold;
	WalkHurdleTypeLongThicknessThreshold = InWalkHurdleTypeLongThicknessThreshold;
	WalkHurdleTypeFallingDistance = InWalkHurdleTypeFallingDistance;

	RunHurdleDetect = InRunHurdleDetect;
	RunMinHurdleLedge = InRunMinHurdleLedge;
	RunMaxHurdleLedge = InRunMaxHurdleLedge;
	RunMaxHurdleThickness = InRunMaxHurdleThickness;
	RunHurdleTypeShortThicknessThreshold = InRunHurdleTypeShortThicknessThreshold;
	RunHurdleTypeLongThicknessThreshold = InRunHurdleTypeLongThicknessThreshold;
	RunHurdleTypeFallingDistance = InRunHurdleTypeFallingDistance;
}

void ScenePerceptionDetector::OpenHurdleDebug(bool bOpen)
{
	bOpenHurdleDebug = bOpen;
}
#pragma endregion Hurdle

bool ScenePerceptionDetector::ReDoClimbingFitInPipeline(float deltaTime, class URoleMovementComponent& roleMC, const FVector& OldXYDelta, FVector& NewDelta)
{
	// Todo
	return false;
}

void ScenePerceptionDetector::CancelClimbInPipeline(class URoleMovementComponent& roleMC, class MovementContext& MC, const FQuat& FinalWorldQuat)
{
	roleMC.OnReceiveLeavingClimbStage();
	// 要注意抢占清理一下朝向中的Pitch和Roll
	MC.ClearAbsoluteWorldRot();
	FRotator FinalRotator = FinalWorldQuat.Rotator(); FinalRotator.Pitch = 0.0f; FinalRotator.Roll = 0.0f;
	MC.OccupyAbsoluteWorldRot(FinalRotator.Quaternion());

	CurClimbDetectStage = EClimbDetectStage::ECDS_LeavingClimb;
}

bool ScenePerceptionDetector::DoClimbStageUpdateForTryFindClimbPosStage(float deltaTime, class URoleMovementComponent& roleMC, class MovementContext& MC, class ABaseCharacter* MoveAgent)
{
	if (CurReEnterClimCoolDown > 0.0f)
	{
		CurReEnterClimCoolDown -= deltaTime;
		return false;
	}

	ACharacter* CharacterOwner = roleMC.GetCharacterOwner();
	if (!IsValid(CharacterOwner))
	{
		return false;
	}

	FCollisionResponseTemplate CollisionProfile;
	if (!UCollisionProfile::Get()->GetProfileTemplate(roleMC.GetTrackFloorCollisionPresetName(), CollisionProfile))
	{
		UCollisionProfile::Get()->GetProfileTemplate(TEXT("Pawn"), CollisionProfile);
	}
	FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(DoClimbingInPipeline), false, CharacterOwner);
	QueryParams.bIgnoreTouches = true;
	FCollisionResponseParams CollisionResponseParams = CollisionProfile.ResponseToChannels;
	const ECollisionChannel CollisionChannel = CollisionProfile.ObjectType;
	FCollisionShape CollisionShape = FCollisionShape::MakeSphere(roleMC.GetClimbCapsuleRadius());

	FVector DetectStartLoc = MoveAgent->GetActorLocation() - MoveAgent->GetActorForwardVector() * roleMC.GetClimbCapsuleRadius();
	FVector DetectEndLoc = DetectStartLoc + MoveAgent->GetActorForwardVector() * roleMC.GetTryClimbDetectDistance();

	FHitResult FinalHitResult;
	TArray<FHitResult> HitResults;
#if UE_BUILD_DEVELOPMENT
	if (ClimbDebugDrawMode > 0)
	{
		DrawDebugSphereTraceSingle(CharacterOwner->GetWorld(), DetectStartLoc, DetectEndLoc, roleMC.GetClimbCapsuleRadius(), EDrawDebugTrace::ForOneFrame, false, FinalHitResult, FLinearColor::Green, FLinearColor::Red, 0.5f);
	}
#endif
	CharacterOwner->GetWorld()->SweepMultiByChannel(HitResults, DetectStartLoc, DetectEndLoc, FQuat::Identity, CollisionChannel, CollisionShape, QueryParams, CollisionResponseParams);
	for (FHitResult& SingleHitRes : HitResults)
	{
		if (IsClimbable(SingleHitRes, roleMC) == EIsClimbableRes::EICR_IsClimbale)
		{
			if (SingleHitRes.bStartPenetrating)
			{
				// 如果角色位置与墙壁有Penetrate，需要拔出来再检查一次
				FVector StickOutLoc = SingleHitRes.ImpactPoint + SingleHitRes.Normal * (roleMC.GetClimbCapsuleRadius() + 5.0f);
#if UE_BUILD_DEVELOPMENT
				if (ClimbDebugDrawMode > 0)
				{
					DrawDebugSphereTraceSingle(CharacterOwner->GetWorld(), StickOutLoc, DetectEndLoc, roleMC.GetClimbCapsuleRadius(), EDrawDebugTrace::ForOneFrame, false, FinalHitResult, FLinearColor::Green, FLinearColor::Red, 0.5f);
				}
#endif
				CharacterOwner->GetWorld()->SweepSingleByChannel(FinalHitResult, StickOutLoc, DetectEndLoc, FQuat::Identity, CollisionChannel, CollisionShape, QueryParams, CollisionResponseParams);
				if (!(IsClimbable(FinalHitResult, roleMC) == EIsClimbableRes::EICR_IsClimbale && !FinalHitResult.bStartPenetrating))
				{
					continue;
				}
			}
			else
			{
				// 检查位置没有Penetrate，可以直接用
				FinalHitResult = SingleHitRes;
			}

			// 看看这个攀爬位置是否可以直接站立，直接站立的不要
			CharacterOwner->GetWorld()->SweepSingleByChannel(SingleHitRes, SingleHitRes.Location + FVector(0.0f, 0.0f, 2.0f), SingleHitRes.Location - FVector(0.0f, 0.0f, 2.0f), FQuat::Identity, CollisionChannel, CollisionShape, QueryParams, CollisionResponseParams);
			EIsClimbableRes Res = IsClimbable(SingleHitRes, roleMC);
			if (Res != EIsClimbableRes::EICR_ClimbStepOn && Res != EIsClimbableRes::EICR_ForceNotClimbale)
			{
				if (roleMC.OnReceiveClimbablePos(FinalHitResult, *this))
				{
					ExecuteBlend();
					return true;
				}
			}
		}
	}

	return false;
}

bool ScenePerceptionDetector::DoClimbStageUpdateForClimbingStage(float deltaTime, class URoleMovementComponent& roleMC, class MovementContext& MC)
{
	if (roleMC.GetHasLocoGroundSupport())
	{
		if (roleMC.CurrentFloor.IsWalkableFloor())
		{
			FHitResult HitRes = roleMC.CurrentFloor.HitResult;
			if (roleMC.TryFindStepOnLoc(HitRes.ImpactPoint, HitRes, &roleMC.CapsuleRadiusBeforeClimb, &roleMC.CapsuleHalfHeightBeforeClimb))
			{
				roleMC.OnReceiveLeavingClimbStage();
				roleMC.TryExecuteStepOn(HitRes);
				return false;
			}
		}		
	}

	return true;
}

bool ScenePerceptionDetector::DoClimbStageUpdateForLeavingClimbStage(float deltaTime, class URoleMovementComponent& roleMC, class MovementContext& MC, class ABaseCharacter* MoveAgent)
{
	if (roleMC.GetHasLocoGroundSupport())
	{
		return true;
	}

	return false;
}

void ScenePerceptionDetector::SetCurClimbDetectStage(EClimbDetectStage InClimbDetectStage)
{
	if (CurClimbDetectStage != InClimbDetectStage)
	{
		if (InClimbDetectStage == EClimbDetectStage::ECDS_TryFindClimbPos)
		{
			CurReEnterClimCoolDown = ReEnterClimCoolDown;
		}
		CurClimbDetectStage = InClimbDetectStage;
	}
	
}
#pragma endregion Climb



#if UE_BUILD_DEVELOPMENT
void ScenePerceptionDetector::AppendDebugInfo(FString& infoOut)
{
	if (IsDetectWater || IsDetectGround)
	{
		infoOut.Append(TEXT("===================<Title_Blue>Scene Perception</>===================\n"));
		infoOut.Appendf(TEXT("GroundDistListToNotify:"));
		for (float Dist : GroundDistListToNotify)
		{
			infoOut.Appendf(TEXT("%f, "), Dist);
		}
		infoOut.Appendf(TEXT("\n"));
		infoOut.Appendf(TEXT("GroundDistListReasonMap:\n"));
		for (const TPair<float, TArray<FString>>& Pair : GroundDistListReasonMap)
		{
			infoOut.Appendf(TEXT("%f-"), Pair.Key);
			for (const FString& Reason : Pair.Value)
			{
				infoOut.Appendf(TEXT("%s,"), *Reason);
			}
			infoOut.Appendf(TEXT("\n"));
		}
		
		infoOut.Appendf(TEXT("WaterDistListToNotify:"));
		for (float Dist : WaterDistListToNotify)
		{
			infoOut.Appendf(TEXT("%f, "), Dist);
		}
		infoOut.Appendf(TEXT("\n"));
		infoOut.Appendf(TEXT("WaterDistListReasonMap:\n"));
		for (const TPair<float, TArray<FString>>& Pair : WaterDistListReasonMap)
		{
			infoOut.Appendf(TEXT("%f-"), Pair.Key);
			for (const FString& Reason : Pair.Value)
			{
				infoOut.Appendf(TEXT("%s,"), *Reason);
			}
			infoOut.Appendf(TEXT("\n"));
		}
	}
	


	if (IsValid(GWorld))
	{
		// 查询一定范围内有无携带DisableClimbComponentTag的StaticMeshComponent，有就显示出来
		DisableClimbComponentTagCheckTimes -= 1;
		if (DisableClimbComponentTagCheckTimes < 0)
		{
			if (ACharacter* PlayerCharacter = UGameplayStatics::GetPlayerCharacter(GWorld, 0))
			{
				TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes = { UEngineTypes::ConvertToObjectType(ECC_WorldStatic) };
				TArray<UPrimitiveComponent*> OutComponents = TArray<UPrimitiveComponent*>();
				if (UKismetSystemLibrary::SphereOverlapComponents(GWorld, PlayerCharacter->GetActorLocation(), 1000.0f, ObjectTypes, UStaticMeshComponent::StaticClass(), TArray<AActor*>(), OutComponents))
				{
					for (UPrimitiveComponent* SingleComp : OutComponents)
					{
						if (SingleComp->ComponentHasTag(DisableClimbComponentTag))
						{
							FTransform ComponentToWorldTransform = SingleComp->GetComponentTransform();
							FBoxSphereBounds Bounds = SingleComp->CalcBounds(ComponentToWorldTransform);
							UKismetSystemLibrary::DrawDebugSphere(GWorld, Bounds.Origin, Bounds.SphereRadius, 12, FLinearColor::Red, 0.5f, 3.0f);

							FBoxSphereBounds LocalBounds = SingleComp->GetLocalBounds();
							FVector LocalBoundsWorldOrigin = ComponentToWorldTransform.TransformPosition(LocalBounds.Origin);
							UKismetSystemLibrary::DrawDebugBox(GWorld, LocalBoundsWorldOrigin, LocalBounds.BoxExtent * ComponentToWorldTransform.GetScale3D(), FLinearColor::Green, ComponentToWorldTransform.GetRotation().Rotator(), 0.5f, 3.0f);
						}
					}
				}
			}
			// Debug功能，降低点检查频率，避免卡顿
			DisableClimbComponentTagCheckTimes = 5;
		}
	}
}
#endif