#include "3C/Movement/C7RootMotionSource.h"
#include "GameFramework/Character.h"

#include  "3C/Movement/RoleMovementComponent.h"

static FLinearColor EvaluateVectorCurveAtFraction_C7RootMotionSource(const UCurveLinearColor& Curve, const float Fraction) {
  float MinCurveTime(0.f);
  float MaxCurveTime(1.f);

  Curve.GetTimeRange(MinCurveTime, MaxCurveTime);
  return Curve.GetUnadjustedLinearColorValue(FMath::GetRangeValue(FVector2f(MinCurveTime, MaxCurveTime), Fraction));
}

void FC7RootMotionSource_MoveToDynamicForce::PrepareRootMotion(float SimulationTime, float MovementTickTime, const ACharacter& Character, const UCharacterMovementComponent& MoveComponent)
{
	SimulationTime = SimulationTime * PlayRate;

	RootMotionParams.Clear();

	bool bCanUse = true;
	if (const URoleMovementComponent* RMoveComp = Cast<URoleMovementComponent>(&MoveComponent))
	{
		bCanUse = RMoveComp->AllowRootMotionByTypeMask(TypeMask);
	}

	if (Duration > UE_SMALL_NUMBER && MovementTickTime > UE_SMALL_NUMBER && bCanUse)
	{
		if (AccumulateMode == ERootMotionAccumulateMode::Override)
		{
			float MoveFraction = (GetTime() + SimulationTime) / Duration;
			if (TimeMappingCurve)
			{
				float MinCurveTime(0.f);
				float MaxCurveTime(1.f);

				TimeMappingCurve->GetTimeRange(MinCurveTime, MaxCurveTime);
				MoveFraction = TimeMappingCurve->GetFloatValue(FMath::GetRangeValue(FVector2f(MinCurveTime, MaxCurveTime), MoveFraction));
			}
			FVector CurrentTargetLocation = FMath::Lerp<FVector, float>(StartLocation, TargetLocation, FMath::Clamp(MoveFraction, ServerMinPercent, ServerMaxPercent)) + GetPathOffsetInWorldSpace(MoveFraction);

			const FVector CurrentLocation = Character.GetActorLocation();

			FVector Force = (CurrentTargetLocation - CurrentLocation) / MovementTickTime;

			if (!bMakeUpLag && bRestrictSpeedToExpected && !Force.IsNearlyZero(UE_KINDA_SMALL_NUMBER))
			{
				float PreviousMoveFraction = GetTime() / Duration;
				if (TimeMappingCurve)
				{
					float MinCurveTime(0.f);
					float MaxCurveTime(1.f);

					TimeMappingCurve->GetTimeRange(MinCurveTime, MaxCurveTime);
					PreviousMoveFraction = TimeMappingCurve->GetFloatValue(FMath::GetRangeValue(FVector2f(MinCurveTime, MaxCurveTime), PreviousMoveFraction));
				}
				FVector CurrentExpectedLocation = FMath::Lerp<FVector, float>(StartLocation, TargetLocation, FMath::Clamp(PreviousMoveFraction, ServerMinPercent, ServerMaxPercent)) + GetPathOffsetInWorldSpace(PreviousMoveFraction);

				const FVector ExpectedForce = (CurrentTargetLocation - CurrentExpectedLocation) / MovementTickTime;
				float ErrorDistance = 50.0f / MovementTickTime;

				if (Settings.HasFlag(ERootMotionSourceSettingsFlags::IgnoreZAccumulate))
				{
					const float ExpectedSpeed = ExpectedForce.Size();
					const float ExpectedSpeed2D = ExpectedForce.Size2D();
					const float CurrentSpeed2DSqr = Force.SizeSquared2D();

					if (CurrentSpeed2DSqr > FMath::Square(ExpectedSpeed2D + ErrorDistance))
					{
						Force.Normalize();
						Force *= ExpectedSpeed;
					}
				}
				else
				{
					const float ExpectedSpeed = ExpectedForce.Size();
					const float CurrentSpeedSqr = Force.SizeSquared();

					if (CurrentSpeedSqr > FMath::Square(ExpectedSpeed + ErrorDistance))
					{
						Force.Normalize();
						Force *= ExpectedSpeed;
					}
				}
			}

			bMakeUpLag = false;

			FTransform NewTransform(Force);
			RootMotionParams.Set(NewTransform);
			//UE_LOG(LogTemp, Warning, TEXT("[szk]PrepareRootMotion, NewTransform: %f, %f, %f. Duration:%f"), NewTransform.GetTranslation().X, NewTransform.GetTranslation().Y, NewTransform.GetTranslation().Z, Duration);
		}
		else if(AccumulateMode == ERootMotionAccumulateMode::Additive)
		{
			float MoveFraction = (GetTime() + SimulationTime) / Duration;

			if (TimeMappingCurve)
			{
				float MinCurveTime(0.f);
				float MaxCurveTime(1.f);

				TimeMappingCurve->GetTimeRange(MinCurveTime, MaxCurveTime);
				MoveFraction = TimeMappingCurve->GetFloatValue(FMath::GetRangeValue(FVector2f(MinCurveTime, MaxCurveTime), MoveFraction));
			}

			FVector CurrentTargetLocation = FMath::Lerp<FVector, float>(StartLocation, TargetLocation, MoveFraction);
			CurrentTargetLocation += GetPathOffsetInWorldSpace(MoveFraction);



			float PreviousMoveFraction = GetTime() / Duration;
			if (TimeMappingCurve)
			{
				float MinCurveTime(0.f);
				float MaxCurveTime(1.f);

				TimeMappingCurve->GetTimeRange(MinCurveTime, MaxCurveTime);
				PreviousMoveFraction = TimeMappingCurve->GetFloatValue(FMath::GetRangeValue(FVector2f(MinCurveTime, MaxCurveTime), PreviousMoveFraction));
			}

			FVector PreviousExpectedLocation = FMath::Lerp<FVector, float>(StartLocation, TargetLocation, PreviousMoveFraction);
			PreviousExpectedLocation += GetPathOffsetInWorldSpace(PreviousMoveFraction);

			

			FVector Force = (CurrentTargetLocation - PreviousExpectedLocation) / MovementTickTime;

			FTransform NewTransform(Force);
			RootMotionParams.Set(NewTransform);
			//UE_LOG(LogTemp, Warning, TEXT("[szk]PrepareRootMotion, NewTransform: %f, %f, %f. Duration:%f"), NewTransform.GetTranslation().X, NewTransform.GetTranslation().Y, NewTransform.GetTranslation().Z, Duration);
		}
	}

	if (bCanUse)
	{
		if ((uint8)OriginAccumulateMode == 255)
		{
			OriginAccumulateMode = AccumulateMode;
		}
		AccumulateMode = OriginAccumulateMode;
	}
	else
	{
		AccumulateMode = (ERootMotionAccumulateMode)255;
	}

	SetTime(GetTime() + SimulationTime);

	// 重置速度设置为零向量
	//FinishVelocityParams.SetVelocity = FVector::ZeroVector;
}

UScriptStruct* FC7RootMotionSource_MoveToDynamicForce::GetScriptStruct() const
{
	return FC7RootMotionSource_MoveToDynamicForce::StaticStruct();
}

void FC7RootMotionSource_MoveToDynamicForce::SetServerPercent(float InMinPercent, float InMaxPercent)
{
	ServerMinPercent = InMinPercent;
	ServerMaxPercent = InMaxPercent;
}

FVector FC7RootMotionSource_MoveToDynamicForce::SetServerInformation(const FVector& InStartLocation, const FVector& InTargetLocation, float InDuration, float InTime, float InMinPercent, float InMaxPercent)
{
	Duration = InDuration;
	StartLocation = InStartLocation;
	TargetLocation = InTargetLocation;

	CurrentTime = FMath::Clamp(FMath::Max(CurrentTime, InTime), 0.0f, Duration);

	ServerMinPercent = InMinPercent;
	ServerMaxPercent = InMaxPercent;

	float MoveFraction = GetTime() / Duration;
	if (TimeMappingCurve)
	{
		float MinCurveTime(0.f);
		float MaxCurveTime(1.f);

		TimeMappingCurve->GetTimeRange(MinCurveTime, MaxCurveTime);
		MoveFraction = TimeMappingCurve->GetFloatValue(FMath::GetRangeValue(FVector2f(MinCurveTime, MaxCurveTime), MoveFraction));
	}

	FVector CurrentTargetLocation = FMath::Lerp<FVector, float>(StartLocation, TargetLocation, FMath::Clamp(MoveFraction, ServerMinPercent, ServerMaxPercent)) + GetPathOffsetInWorldSpace(MoveFraction);

	return CurrentTargetLocation;
}


FVector FC7RootMotionSource_MoveParabola::EvaluatePosition(float _CurrentTime)
{
	float ZOffset = Velocity_Vertical * CurrentTime - Acc_Gravity * _CurrentTime * _CurrentTime * .5f;
	FVector Position = Velocity_Horizontal * _CurrentTime * HorizontalOrientation;
	if (Position.Size2D() > HorizontalShift)
	{
		Position = EndPosition;
	}
	else
	{
		Position += StartPosition;
	}
	Position.Z = StartPosition.Z + ZOffset;
	return Position;
}

bool FC7RootMotionSource_MoveParabola::InitializeParameters()
{
	//检查除数不为0
	if (FMath::IsNearlyZero(Duration) || FMath::IsNearlyZero(PeekHeight))
	{
		return false;
	}
	//配置的最高点要高于终点位置
	float Distance_Vertical = EndPosition.Z - StartPosition.Z;
	if (Distance_Vertical > PeekHeight)
	{
		return false;
	}
	float Distance_Horizontal = (EndPosition - StartPosition).Size2D();
	Velocity_Vertical = 2.f * PeekHeight / Duration + 2.f * FMath::Sqrt(PeekHeight * (PeekHeight - Distance_Vertical)) / Duration;
	Acc_Gravity = Velocity_Vertical * Velocity_Vertical * .5f / PeekHeight;
	if (Distance_Vertical > .0f)
	{
		Velocity_Horizontal = Distance_Horizontal / Duration;
	}
	else
	{
		Velocity_Horizontal = Velocity_Vertical * Distance_Horizontal * .25f / PeekHeight;
	}
	HorizontalOrientation = EndPosition - StartPosition;
	HorizontalShift = HorizontalOrientation.Size2D();
	if (FMath::IsNearlyZero(HorizontalShift))
	{
		return false;
	}
	HorizontalOrientation = HorizontalOrientation / HorizontalShift;
	return true;
}

void FC7RootMotionSource_MoveParabola::PrepareRootMotion(float SimulationTime, float MovementTickTime, const ACharacter& Character, const UCharacterMovementComponent& MoveComponent)
{
	SimulationTime = SimulationTime * PlayRate;
	RootMotionParams.Clear();
	if (Duration > UE_SMALL_NUMBER && MovementTickTime > UE_SMALL_NUMBER)
	{
		if (AccumulateMode == ERootMotionAccumulateMode::Override)
		{
			float MoveFraction = (GetTime() + SimulationTime);
			FVector CurrentTargetLocation = EvaluatePosition(MoveFraction);
			const FVector CurrentLocation = Character.GetActorLocation();
			FVector Force = (CurrentTargetLocation - CurrentLocation) / MovementTickTime;
			
			
			if (!Force.IsNearlyZero(UE_KINDA_SMALL_NUMBER))
			{
				float PreviousMoveFraction = GetTime();
				FVector CurrentExpectedLocation = EvaluatePosition(PreviousMoveFraction);

				const FVector ExpectedForce = (CurrentTargetLocation - CurrentExpectedLocation) / MovementTickTime;
				float ErrorDistance = 50.0f / MovementTickTime;

				const float ExpectedSpeed = ExpectedForce.Size();
				const float CurrentSpeedSqr = Force.SizeSquared();

				if (CurrentSpeedSqr > FMath::Square(ExpectedSpeed + ErrorDistance))
				{
					Force.Normalize();
					Force *= ExpectedSpeed;
				}
			}
			
			FTransform NewTransform(Force);
			//UKismetSystemLibrary::DrawDebugPoint(&Character, CurrentLocation, 10, FLinearColor::Blue, 5);
			RootMotionParams.Set(NewTransform);
		}
	}
	SetTime(GetTime() + SimulationTime);
}


UScriptStruct* FC7RootMotionSource_MoveParabola::GetScriptStruct() const
{
	return FC7RootMotionSource_MoveParabola::StaticStruct();
}



bool FC7RootMotionSource_Move3D::InitializeParameters()
{
	if (KeyFrameCurve == nullptr) 
		return true;
	FVector Dir = EndPosition - StartPosition;
	// 弧度
	float Yaw = FMath::Atan2(Dir.Y, Dir.X);
	FLinearColor StartFrame = EvaluateVectorCurveAtFraction_C7RootMotionSource(*KeyFrameCurve, 0.0f);
    FLinearColor EndFrame = EvaluateVectorCurveAtFraction_C7RootMotionSource(*KeyFrameCurve, 1.0f);
    FVector CurveDir = FVector(EndFrame.R, EndFrame.G, EndFrame.B) - FVector(StartFrame.R, StartFrame.G, StartFrame.B);
    if (CurveDir.Size2D() <= UE_SMALL_NUMBER) 
		return false;
    float CurveYaw = FMath::Atan2(CurveDir.Y, CurveDir.X);
    // 曲线中x轴对应的yaw
	float CurveXYaw = Yaw - CurveYaw;
	// 曲线中y轴对应的yaw
    float CurveYYaw = Yaw + (PI / 2.0f - CurveYaw);
	CurveX = FVector(FMath::Cos(CurveXYaw), FMath::Sin(CurveXYaw), 0.0f) * Dir.Size2D() / CurveDir.Size2D();
	CurveY = FVector(FMath::Cos(CurveYYaw), FMath::Sin(CurveYYaw), 0.0f) * Dir.Size2D() / CurveDir.Size2D();
    HeightDiff = Dir.Z - (EndFrame.A - StartFrame.A);
	LastYaw = 0.0f;
	return true;
}

void FC7RootMotionSource_Move3D::PrepareRootMotion(float SimulationTime, float MovementTickTime, const ACharacter& Character, const UCharacterMovementComponent& MoveComponent)
{
	SimulationTime = SimulationTime * PlayRate;
	RootMotionParams.Clear();
	if (Duration > UE_SMALL_NUMBER && MovementTickTime > UE_SMALL_NUMBER) 
	{
		float MoveFraction = (GetTime() + SimulationTime) / Duration;
		const FVector CurrentLocation = Character.GetActorLocation();
		float CurrentYaw = Character.GetActorRotation().Yaw;
		if (KeyFrameCurve)
		{
			FLinearColor KeyFrame = EvaluateVectorCurveAtFraction_C7RootMotionSource(*KeyFrameCurve, MoveFraction);
            FVector Position(KeyFrame.R, KeyFrame.G, 0);
            FVector CurPosition = StartPosition + KeyFrame.R * CurveX + KeyFrame.G * CurveY;
            // 每次tick补一下高度，保证最后终点刚好能到
			float CurHeight = KeyFrame.B + HeightDiff * MoveFraction;
            CurPosition.Z = CurHeight;
			float Yaw = KeyFrame.A;
            float DelatYaw = Yaw - LastYaw;
			LastYaw = Yaw;
			FVector Force = (CurPosition - CurrentLocation) / MovementTickTime;
			
			FTransform NewTransform(Force);
			FRotator Rotator(0, DelatYaw, 0);
			FQuat Quat = FQuat(Rotator);
			NewTransform.SetRotation(Quat);
			RootMotionParams.Set(NewTransform);
		} else
		{
			// 没有曲线的情况下，线性插值
			FVector CurPosition = StartPosition + (EndPosition - StartPosition) * MoveFraction;

			FVector Force = (CurPosition - CurrentLocation) / MovementTickTime;
			FTransform NewTransform(Force);
			RootMotionParams.Set(NewTransform);
		}
	}
	SetTime(GetTime() + SimulationTime);
}

UScriptStruct* FC7RootMotionSource_Move3D::GetScriptStruct() const {
  return FC7RootMotionSource_Move3D::StaticStruct();
}