// #pragma once
#include "3C/Movement/MovementPipeline/MovementCalculator/InputThrusterMC.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Character/BaseCharacter.h"

#include "Misc/MathFormula.h"

// 为地面Locomotion移动定制的程序驱动机制, 只有xy平面上的处理
bool InputThrusterMC::CalculateMovementTick(const float deltaTime, const bool isNeedOutput, const FTransform& baseTransform, MovementContext& outputContext)
{

	if (CurFadeOutTime > 0.0f)
	{
		float FadeRatio = 1.0f;
		if(FadeOutTime > 0.001f)
		{
			FadeRatio = CurFadeOutTime / FadeOutTime;
		}
		
		CurVelocity = StartFadeOutVelocity;
		
		OutputFinalMovementDelta(isNeedOutput, CurVelocity*deltaTime, true, FadeRatio, outputContext);

		CurFadeOutTime -= deltaTime;
		if (CurFadeOutTime < 0.0f)
		{
			Reset();
		}
	}
	else
	{
		const FVector& InputLocVector = outputContext.GetLocoInputVec();
		const float MaxBrakingDeceleration = ForceMaxBrakingDeceleration >= 0.0f ? ForceMaxBrakingDeceleration : outputContext.GetMaxBrakingDeceleration();

		if (InputLocVector.Size() > 0.0f)
		{
			switch (SpeedAdjustMode)
			{
			case EInputThrusterAdjustMode::InputAdditive:
				DoAcceForInputAdditive(deltaTime, outputContext);
				break;
			case EInputThrusterAdjustMode::AdjustOrientation:
				DoAcceForAdjustOrientation(deltaTime, outputContext);
				break;
			case EInputThrusterAdjustMode::CarDrive:
				DoAcceForCarDrive(deltaTime, outputContext);
				break;
			case EInputThrusterAdjustMode::GlideThruster:
				DoAcceForGlideThruster(deltaTime, outputContext);
				break;
			case EInputThrusterAdjustMode::ALSMovementMode:
				DoAcceForALSMovementMode(deltaTime, outputContext);
				break;
			}
		}
		else if (MaxBrakingDeceleration > 0)
		{
			switch (SpeedAdjustMode)
			{
			case EInputThrusterAdjustMode::InputAdditive:
				DoBrakeForInputAdditive(deltaTime, outputContext);
				break;
			case EInputThrusterAdjustMode::AdjustOrientation:
				DoBrakeForAdjustOrientation(deltaTime, outputContext);
				break;
			case EInputThrusterAdjustMode::CarDrive:
				DoBrakeForCarDrive(deltaTime, outputContext);
				break;
			case EInputThrusterAdjustMode::GlideThruster:
				DoBrakeForGlideThruster(deltaTime, outputContext);
				break;
			case EInputThrusterAdjustMode::ALSMovementMode:
				DoBrakeForALSMovementMode(deltaTime, outputContext);
				break;
			}
		}
		else
		{
			const float velocitySpeed = CurVelocity.Length();
			const float MaxLocoSpeed = ForceMaxSpeed > 0.0f ? ForceMaxSpeed : (outputContext.GetIsBackCar() ? URoleMovementComponent::GetBackCarSpeedLimit() : outputContext.GetMaxLocoSpeed());

			if (velocitySpeed > MaxLocoSpeed){
				CurVelocity = MaxLocoSpeed * CurVelocity.GetSafeNormal();
			}

			if (SpeedAdjustMode == EInputThrusterAdjustMode::CarDrive) {
				LerpCurVelocityDirToActorDir(CurVelocity, baseTransform, outputContext, deltaTime);
			}
		}

		FVector OutVelocity = CurVelocity;
		if(BlendInTime > 0.0f && CurBlendInTime < BlendInTime && OutVelocity.Size() > 0.1f)
		{
			CurBlendInTime += deltaTime;
			float VelocityFadeInRatio = CurBlendInTime / BlendInTime;

			if(VelocityFadeInRatio > 1.0f)
			{
				VelocityFadeInRatio = 1.0f;
			}

			if(VelocityFadeInRatio < 0.0f){
				VelocityFadeInRatio = 0.0f;
			}

			float TargetSpeed = OutVelocity.Size();
			float SourceSpeed = BlendFadeInVelocity.Size();

			OutVelocity.Normalize();
			OutVelocity = OutVelocity * (VelocityFadeInRatio * TargetSpeed + (1.0f - VelocityFadeInRatio) * SourceSpeed);
		}
		OutputFinalMovementDelta(isNeedOutput, OutVelocity * deltaTime, false, 0.0, outputContext);
	}

	return true;
}

bool InputThrusterMC::IsEnabled()
{
	return MovementCalculatorBase::IsEnabled() || CurFadeOutTime > 0.0f;
}

void InputThrusterMC::SetEnable(bool InEnable)
{
	if (Enabled && !InEnable)
	{
		StartFadeOutVelocity = CurVelocity;
		CurFadeOutTime = FadeOutTime;
	}
	else
	{
		StartFadeOutVelocity.Zero();
		CurFadeOutTime = -1.0f;
	}

	MovementCalculatorBase::SetEnable(InEnable);
}

void InputThrusterMC::AdjustCurVelocityRot(const FRotator& InRotation)
{
	if (!CurVelocity.IsNearlyZero())
	{
		CurVelocity = InRotation.Vector() * CurVelocity.Size();
	}
}

void InputThrusterMC::LerpCurVelocityDirToActorDir(FVector& InOutCurVeclocity, const FTransform& InBaseTransform, MovementContext& InContext, const float deltaTime)
{
	if (!InOutCurVeclocity.IsNearlyZero())
	{
		const FVector& velSafeNormalized = InOutCurVeclocity.GetSafeNormal();
		FRotator CurVelocityRotation = velSafeNormalized.Rotation();
		float NextYaw = MathFormula::YawDecayWithNormalized(CurVelocityRotation.Yaw,
			InContext.GetIsBackCar() ? InBaseTransform.Rotator().Yaw + 180.0f : InBaseTransform.Rotator().Yaw,
			0.1, deltaTime);
		float Shrink = FMath::Cos(FMath::DegreesToRadians(NextYaw - CurVelocityRotation.Yaw));
		CurVelocityRotation.Yaw = NextYaw;
		CurVelocity = CurVelocityRotation.Vector() * CurVelocity.Size() * Shrink;
	}
}

void InputThrusterMC::SetSpeedAdjustMode(EInputThrusterAdjustMode InSpeedAdjustMode, const float& RoleMovementCompLocoMaxSpeed)
{
	SpeedAdjustMode = InSpeedAdjustMode;
	// 这时也需要更新一下CurVelocity
	SetCurVelocity(CurVelocity, RoleMovementCompLocoMaxSpeed);
}

void InputThrusterMC::SetCurVelocity(const FVector& initVelocity, const float& RoleMovementCompLocoMaxSpeed)
{ 
	const float MaxLocoSpeed = ForceMaxSpeed > 0.0f ? ForceMaxSpeed : RoleMovementCompLocoMaxSpeed;
	if (SpeedAdjustMode == EInputThrusterAdjustMode::GlideThruster)
	{
		const float MaxMainSpeed = URoleMovementComponent::GetGlideThrusterMainSpeedRate() * MaxLocoSpeed;

		FVector XYVelocity = initVelocity;
		XYVelocity.Z = 0.0f;
		float CurSpeed = XYVelocity.Size();
		if (CurSpeed > MaxMainSpeed)
		{
			const float MaxSideSpeed = URoleMovementComponent::GetGlideThrusterSideSpeedRate() * MaxLocoSpeed;
			GlideThrusterMainCurVelocity = MaxMainSpeed * (XYVelocity.GetSafeNormal());
			GlideThrusterLeftCurSpeed = FMath::Min(0.5 * (CurSpeed - MaxMainSpeed), MaxSideSpeed);
			GlideThrusterRightCurSpeed = GlideThrusterLeftCurSpeed;
		}
		else
		{
			GlideThrusterMainCurVelocity = XYVelocity;
			GlideThrusterLeftCurSpeed = 0.0f;
			GlideThrusterRightCurSpeed = 0.0f;
		}
		// CurVelocity由下一帧CalculateMovementTick计算
	}
	else
	{
		CurVelocity = initVelocity;
		CurVelocity.Z = 0.0f; // 推进器的初始Z轴速度，由重力继承
		if (CurVelocity.Size() > MaxLocoSpeed)
		{
			CurVelocity = MaxLocoSpeed * CurVelocity.GetSafeNormal();
		}
	}
}	

void InputThrusterMC::OutputFinalMovementDelta(bool IsNeedOutput, const FVector& MovementDelta, bool NeedRatioMode, float Ratio, MovementContext& MC)
{
	if(!IsNeedOutput)
	{
		return;
	}

	// 测试推进器输入使用
	//if (!MovementDelta.IsNearlyZero())
	//{
	//	if (ACharacter* PlayerCharacter = UGameplayStatics::GetPlayerCharacter(GWorld, 0))
	//	{
	//		UKismetSystemLibrary::DrawDebugLine(PlayerCharacter, PlayerCharacter->GetActorLocation(),
	//			PlayerCharacter->GetActorLocation() + MovementDelta * 300.0f,
	//			FLinearColor::Red, 0.05f, 3.0f);
	//	}
	//}
	
	if(MovementSpace == EMovementSpace::ELocal)
	{
		if(NeedRatioMode)
		{
			MC.AccumulateLocalPosDeltaWithBlend(MovementDelta, Ratio);
		}
		else
		{
			MC.AccumulateLocalPosDelta(MovementDelta);
		}
		
	}
	else
	{
		if(NeedRatioMode)
		{
			MC.AccumulateWorldPosDeltaWithBlend(MovementDelta, Ratio);
		}
		else
		{
			MC.AccumulateWorldPosDelta(MovementDelta);
		}
	}
}

void InputThrusterMC::DoAcceForInputAdditive(const float& deltaTime, MovementContext& outputContext)
{
	const FVector& InputLocVector = outputContext.GetLocoInputVec();
	const float MaxLocoSpeed = ForceMaxSpeed > 0.0f ? ForceMaxSpeed : (outputContext.GetIsBackCar() ? URoleMovementComponent::GetBackCarSpeedLimit() : outputContext.GetMaxLocoSpeed());
	const float MaxAcceleration = ForceMaxAcceleration > 0.0f ? ForceMaxAcceleration : outputContext.GetMaxAcceleration();
	// 加速
	CurVelocity += InputLocVector * MaxAcceleration * deltaTime;
	if (CurVelocity.Length() > MaxLocoSpeed)
	{
		CurVelocity = MaxLocoSpeed * CurVelocity.GetSafeNormal();
	}
}

void InputThrusterMC::DoBrakeForInputAdditive(const float& deltaTime, MovementContext& outputContext)
{
	DoBrakeForAdjustOrientation(deltaTime, outputContext);
}

void InputThrusterMC::DoAcceForAdjustOrientation(const float& deltaTime, MovementContext& outputContext)
{
	const FVector& InputLocVector = outputContext.GetLocoInputVec();
	const FVector& InputDir = InputLocVector.GetSafeNormal();
	const float velocitySpeed = CurVelocity.Length();
	const FVector& velSafeNormalized = CurVelocity.GetSafeNormal();
	const float MaxLocoSpeed = ForceMaxSpeed > 0.0f ? ForceMaxSpeed : (outputContext.GetIsBackCar() ? URoleMovementComponent::GetBackCarSpeedLimit() : outputContext.GetMaxLocoSpeed());
	const float MaxAcceleration = ForceMaxAcceleration > 0.0f ? ForceMaxAcceleration : outputContext.GetMaxAcceleration();
	if (velocitySpeed > 0.0f)
	{
		FRotator DeltaVelRotator = InputDir.Rotation();
		FRotator CurSpeedRotator = velSafeNormalized.Rotation();
		MathFormula::DecayValue(DeltaVelRotator, CurSpeedRotator, DeltaVelRotator, OrientationAdjustHalfTime, deltaTime);

		CurVelocity = DeltaVelRotator.Vector() * FMath::Min(MaxLocoSpeed, velocitySpeed + MaxAcceleration * deltaTime);
	}
	else
	{
		CurVelocity = InputDir * FMath::Min(MaxLocoSpeed, MaxAcceleration * deltaTime);
	}
}
void InputThrusterMC::DoBrakeForAdjustOrientation(const float& deltaTime, MovementContext& outputContext)
{
	const FTransform& baseTransform = outputContext.GetCurrentActorTransform();
	const float velocitySpeed = CurVelocity.Length();
	const FVector& velSafeNormalized = CurVelocity.GetSafeNormal();
	const float MaxLocoSpeed = ForceMaxSpeed > 0.0f ? ForceMaxSpeed : (outputContext.GetIsBackCar() ? URoleMovementComponent::GetBackCarSpeedLimit() : outputContext.GetMaxLocoSpeed());
	const float MaxBrakingDeceleration = ForceMaxBrakingDeceleration >= 0.0f ? ForceMaxBrakingDeceleration : outputContext.GetMaxBrakingDeceleration();

	if (velocitySpeed > MaxLocoSpeed)
	{
		CurVelocity = MaxLocoSpeed * CurVelocity.GetSafeNormal();
	}

	// 减速
	const float deceValue = deltaTime * MaxBrakingDeceleration;
	if (velocitySpeed > deceValue)
	{
		CurVelocity -= velSafeNormalized * deceValue;
	}
	else
	{
		CurVelocity.Set(0.0f, 0.0f, 0.0f);
	}
}

void InputThrusterMC::DoAcceForCarDrive(const float& deltaTime, MovementContext& outputContext)
{
	const FTransform& baseTransform = outputContext.GetCurrentActorTransform();
	const FVector& CurActorForward = baseTransform.Rotator().Vector();
	const bool IsSimulateRealDrive = outputContext.GetELocoInputSemantic() == ELocoInputSemantic::OnActorCordinateSemanitic;

	if (IsSimulateRealDrive)
	{
		const FVector& InputDir = outputContext.GetLocoInputVec().GetSafeNormal();
		
		const float CurVelocityDotCurActorForward = CurVelocity.Dot(CurActorForward);
		const float InputDirDotCurActorForward = InputDir.Dot(CurActorForward);
		// 这里本来都应该是0，给点冗余值避免纯AD左右输入时的问题
		if ((CurVelocityDotCurActorForward >= 0.0f && InputDirDotCurActorForward >= -0.1f) || (CurVelocityDotCurActorForward <= 0.0f && InputDirDotCurActorForward <= 0.1f))
		{
			// 同向情况，使用使用默认加速逻辑
			DoAcceForAdjustOrientation(deltaTime, outputContext);
		}
		else 
		{
			// 拟真模式下，需要模拟真实油门
			const float velocitySpeed = CurVelocity.Length();
			const FVector& velSafeNormalized = CurVelocity.GetSafeNormal();
			const float MaxAcceleration = ForceMaxAcceleration > 0.0f ? ForceMaxAcceleration : outputContext.GetMaxAcceleration();
			const float MaxBrakingDeceleration = ForceMaxBrakingDeceleration >= 0.0f ? ForceMaxBrakingDeceleration : outputContext.GetMaxBrakingDeceleration();

			// 这时先把InputDir镜像到预期的ActorForward方向上
			FVector MirrorInputDir = InputDir - CurActorForward * 2 * InputDir.Dot(CurActorForward);
			FRotator DeltaVelRotator = MirrorInputDir.Rotation();
			FRotator CurSpeedRotator = velSafeNormalized.Rotation();
			MathFormula::DecayValue(DeltaVelRotator, CurSpeedRotator, DeltaVelRotator, OrientationAdjustHalfTime, deltaTime);

			float NewVelocityValue = velocitySpeed - (MaxAcceleration + MaxBrakingDeceleration) * deltaTime;
			if (NewVelocityValue < 0.0f) {
				// 速度减少为反向后，需要重新镜像到预期的ActorForward方向上
				CurVelocity = DeltaVelRotator.Vector() * -NewVelocityValue;
				CurVelocity = CurVelocity - CurActorForward * 2 * CurVelocity.Dot(CurActorForward);
				
				// 还需要立即修改倒车参数
				// !CurVelocityDotCurActorForward >= 0.0f表示旧IsBackCar，现在反向设置
				outputContext.SetIsBackCar(CurVelocityDotCurActorForward >= 0.0f);
			}
			else {
				CurVelocity = DeltaVelRotator.Vector() * NewVelocityValue;
			}
		}
	}
	else 
	{
		// 非拟真模式，直接使用默认加速逻辑
		DoAcceForAdjustOrientation(deltaTime, outputContext);
	}

	// 限制一下推进器向量在MountMaxDeltaYaw范围内
	if (!CurVelocity.IsNearlyZero())
	{
		const FRideMountContextInfo& ContextInfo = outputContext.GetRideMountContextInfo();
		float MountMaxDeltaYaw = ContextInfo.MountMaxDeltaYaw;
		float CurVelocityYaw = CurVelocity.Rotation().Yaw;
		float TargetYaw = baseTransform.Rotator().Yaw;
		if (IsSimulateRealDrive) {
			// 拟真模式下，角度限制以速度为准
			// 这里本来都应该是0，给点冗余值避免纯AD左右输入时的问题
			TargetYaw = FRotator::NormalizeAxis(TargetYaw + (CurVelocity.GetSafeNormal().Dot(CurActorForward) < -0.1f ? 180.0f : 0.0f));
		}
		else {
			// 非拟真模式下，角度限制以Context的IsBackCar逻辑为准
			TargetYaw = FRotator::NormalizeAxis(TargetYaw + (outputContext.GetIsBackCar() ? 180.0f : 0.0f));
		}

		if (MountMaxDeltaYaw > 0.0f && MathFormula::ClosetYawAbsDiff(TargetYaw, CurVelocityYaw) > MountMaxDeltaYaw)
		{
			float DeltaYaw = FRotator::NormalizeAxis(CurVelocityYaw - TargetYaw);
			float RealVelocityYaw = DeltaYaw > 0.0 ? TargetYaw + MountMaxDeltaYaw : TargetYaw - MountMaxDeltaYaw;
			CurVelocity = CurVelocity.Size() * (FRotator(0.0f, RealVelocityYaw, 0.0f).Vector());
		}
	}
}
void InputThrusterMC::DoBrakeForCarDrive(const float& deltaTime, MovementContext& outputContext)
{
	DoBrakeForAdjustOrientation(deltaTime, outputContext);

	const FTransform& baseTransform = outputContext.GetCurrentActorTransform();
	LerpCurVelocityDirToActorDir(CurVelocity, baseTransform, outputContext, deltaTime);
}

void InputThrusterMC::DoAcceForGlideThruster(const float& deltaTime, MovementContext& outputContext)
{
	const FVector& InputLocVector = outputContext.GetLocoInputVec();
	const FVector& InputDir = InputLocVector.GetSafeNormal();
	const float MaxLocoSpeed = ForceMaxSpeed > 0.0f ? ForceMaxSpeed : (outputContext.GetIsBackCar() ? URoleMovementComponent::GetBackCarSpeedLimit() : outputContext.GetMaxLocoSpeed());
	const float MaxAcceleration = ForceMaxAcceleration > 0.0f ? ForceMaxAcceleration : outputContext.GetMaxAcceleration();

	const FTransform& baseTransform = outputContext.GetCurrentActorTransform();
	const FVector& CurActorForward = baseTransform.Rotator().Vector();
	const float DeltaYaw = FRotator::NormalizeAxis(InputDir.Rotation().Yaw - baseTransform.Rotator().Yaw);
	const float MaxSideSpeed = URoleMovementComponent::GetGlideThrusterSideSpeedRate() * MaxLocoSpeed;
	const float MaxMainSpeed = URoleMovementComponent::GetGlideThrusterMainSpeedRate() * MaxLocoSpeed;

	if (DeltaYaw >= URoleMovementComponent::GetGlideThrusterAdjustDeltaYaw())
	{
		GlideThrusterLeftCurSpeed = FMath::Min(GlideThrusterLeftCurSpeed + URoleMovementComponent::GetGlideThrusterSideSpeedAcce() * deltaTime, MaxSideSpeed);
		GlideThrusterRightCurSpeed = FMath::Max(GlideThrusterRightCurSpeed - URoleMovementComponent::GetGlideThrusterSideSpeedAcce() * deltaTime, -MaxSideSpeed);
	}
	else if (DeltaYaw > -URoleMovementComponent::GetGlideThrusterAdjustDeltaYaw())
	{
		GlideThrusterLeftCurSpeed = FMath::Min(GlideThrusterLeftCurSpeed + URoleMovementComponent::GetGlideThrusterSideSpeedAcce() * deltaTime, MaxSideSpeed);
		GlideThrusterRightCurSpeed = FMath::Min(GlideThrusterRightCurSpeed + URoleMovementComponent::GetGlideThrusterSideSpeedAcce() * deltaTime, MaxSideSpeed);
	}
	else
	{
		GlideThrusterLeftCurSpeed = FMath::Max(GlideThrusterLeftCurSpeed - URoleMovementComponent::GetGlideThrusterSideSpeedAcce() * deltaTime, -MaxSideSpeed);
		GlideThrusterRightCurSpeed = FMath::Min(GlideThrusterRightCurSpeed + URoleMovementComponent::GetGlideThrusterSideSpeedAcce() * deltaTime, MaxSideSpeed);
	}

	GlideThrusterMainCurVelocity += InputLocVector * URoleMovementComponent::GetGlideThrusterMainSpeedRate() * MaxAcceleration * deltaTime;
	if (GlideThrusterMainCurVelocity.Length() > MaxMainSpeed)
	{
		GlideThrusterMainCurVelocity = MaxMainSpeed * GlideThrusterMainCurVelocity.GetSafeNormal();
	}
	CurVelocity = GlideThrusterMainCurVelocity + CurActorForward * (GlideThrusterLeftCurSpeed + GlideThrusterRightCurSpeed);
}
void InputThrusterMC::DoBrakeForGlideThruster(const float& deltaTime, MovementContext& outputContext)
{
	const float MaxLocoSpeed = ForceMaxSpeed > 0.0f ? ForceMaxSpeed : (outputContext.GetIsBackCar() ? URoleMovementComponent::GetBackCarSpeedLimit() : outputContext.GetMaxLocoSpeed());
	const float MaxBrakingDeceleration = ForceMaxBrakingDeceleration >= 0.0f ? ForceMaxBrakingDeceleration : outputContext.GetMaxBrakingDeceleration();
	const FTransform& baseTransform = outputContext.GetCurrentActorTransform();
	const FVector& CurActorForward = baseTransform.Rotator().Vector();
	const float MaxMainSpeed = URoleMovementComponent::GetGlideThrusterMainSpeedRate() * MaxLocoSpeed;

	GlideThrusterLeftCurSpeed = GlideThrusterLeftCurSpeed > 0.0f ? FMath::Max(GlideThrusterLeftCurSpeed - URoleMovementComponent::GetGlideThrusterSideSpeedDece() * deltaTime, 0.0f)
		: FMath::Min(GlideThrusterLeftCurSpeed + URoleMovementComponent::GetGlideThrusterSideSpeedDece() * deltaTime, 0.0f);
	GlideThrusterRightCurSpeed = GlideThrusterRightCurSpeed > 0.0f ? FMath::Max(GlideThrusterRightCurSpeed - URoleMovementComponent::GetGlideThrusterSideSpeedDece() * deltaTime, 0.0f)
		: FMath::Min(GlideThrusterRightCurSpeed + URoleMovementComponent::GetGlideThrusterSideSpeedDece() * deltaTime, 0.0f);

	if (GlideThrusterMainCurVelocity.Size() > MaxMainSpeed)
	{
		GlideThrusterMainCurVelocity = MaxMainSpeed * GlideThrusterMainCurVelocity.GetSafeNormal();
	}
	const float deceValue = deltaTime * MaxBrakingDeceleration * URoleMovementComponent::GetGlideThrusterMainSpeedRate();
	if (GlideThrusterMainCurVelocity.Size() > deceValue)
	{
		GlideThrusterMainCurVelocity -= GlideThrusterMainCurVelocity.GetSafeNormal() * deceValue;
	}
	else
	{
		GlideThrusterMainCurVelocity.Set(0.0f, 0.0f, 0.0f);
	}

	CurVelocity = GlideThrusterMainCurVelocity + CurActorForward * (GlideThrusterLeftCurSpeed + GlideThrusterRightCurSpeed);
}

void InputThrusterMC::DoAcceForALSMovementMode(const float& deltaTime, MovementContext& outputContext)
{
	const FVector& InputDir = outputContext.GetLocoInputVec().GetSafeNormal();
	const float MaxLocoSpeed = ForceMaxSpeed > 0.0f ? ForceMaxSpeed : (outputContext.GetIsBackCar() ? URoleMovementComponent::GetBackCarSpeedLimit() : outputContext.GetMaxLocoSpeed());
	const float MaxAcceleration = ForceMaxAcceleration > 0.0f ? ForceMaxAcceleration : outputContext.GetMaxAcceleration();

	const float VelSize = CurVelocity.Size();
	const float Friction = 4.0f; // 用的ALS中的数值
	CurVelocity = CurVelocity - (CurVelocity - InputDir * VelSize) * FMath::Min(deltaTime * Friction, 1.f);
	CurVelocity += InputDir * MaxAcceleration * deltaTime;
	CurVelocity = CurVelocity.GetClampedToMaxSize(MaxLocoSpeed);
}
void InputThrusterMC::DoBrakeForALSMovementMode(const float& deltaTime, MovementContext& outputContext)
{
	const float MaxBrakingDeceleration = ForceMaxBrakingDeceleration >= 0.0f ? ForceMaxBrakingDeceleration : outputContext.GetMaxBrakingDeceleration();
	const float Friction = 4.0f; // 用的ALS里面的数值
	const FVector& RevAccel = (-MaxBrakingDeceleration * CurVelocity.GetSafeNormal());
	// apply friction and braking
	FVector VelocityDelta = ((-Friction) * CurVelocity + RevAccel) * deltaTime;
	if (VelocityDelta.Size() > CurVelocity.Size())
	{
		CurVelocity.Set(0, 0, 0);
	}
	else
	{
		CurVelocity = CurVelocity + VelocityDelta;
	}
}

EInputThrusterAdjustMode InputThrusterMC::SetSpeedAdjustModeWeakValue(EInputThrusterAdjustMode InSpeedAdjustMode, const float& RoleMovementCompLocoMaxSpeed)
{
	SpeedAdjustModeWeakValue = InSpeedAdjustMode;

	if (SpeedAdjustModeForceValue.IsSet())
	{
		return SpeedAdjustMode;
	}

	if (SpeedAdjustMode != InSpeedAdjustMode) {
		SetSpeedAdjustMode(InSpeedAdjustMode, RoleMovementCompLocoMaxSpeed);
	}
	
	return SpeedAdjustMode;
}

EInputThrusterAdjustMode InputThrusterMC::SetSpeedAdjustModeForceValue(EInputThrusterAdjustMode InSpeedAdjustMode, const float& RoleMovementCompLocoMaxSpeed)
{
	SpeedAdjustModeForceValue = InSpeedAdjustMode;
	if (SpeedAdjustMode != InSpeedAdjustMode) {
		SetSpeedAdjustMode(InSpeedAdjustMode, RoleMovementCompLocoMaxSpeed);
	}

	return SpeedAdjustMode;
}

EInputThrusterAdjustMode InputThrusterMC::ClearSpeedAdjustModeForceValue(const float& RoleMovementCompLocoMaxSpeed)
{
	SpeedAdjustModeForceValue.Reset();
	if (SpeedAdjustMode != SpeedAdjustModeWeakValue) {
		SetSpeedAdjustMode(SpeedAdjustModeWeakValue, RoleMovementCompLocoMaxSpeed);
	}

	return SpeedAdjustMode;
}

EInputThrusterAdjustMode InputThrusterMC::ResetSpeedAdjustMode(const float& RoleMovementCompLocoMaxSpeed)
{
	SpeedAdjustModeForceValue.Reset();
	SpeedAdjustModeWeakValue = EInputThrusterAdjustMode::InputAdditive;

	if (SpeedAdjustMode != SpeedAdjustModeWeakValue) {
		SetSpeedAdjustMode(SpeedAdjustModeWeakValue, RoleMovementCompLocoMaxSpeed);
	}

	return SpeedAdjustMode;
}

#if UE_BUILD_DEVELOPMENT
void InputThrusterMC::AppendDebugInfo(FString& infoOut) {
	infoOut.Appendf(TEXT("====================%s==============\n"), *GetDebugInfoTitle());
	infoOut.Appendf(TEXT("IsEnabled:%d  IsSwitchedOn:%d  MovementSpace:%d\n"), IsEnabled(), IsSwitchedOn(), MovementSpace);
	infoOut.Appendf(TEXT("CurVelocity:%s CurVel:%f, CurVelXY:%f\n"), *(CurVelocity.ToString()), CurVelocity.Size(), CurVelocity.Size2D());
	infoOut.Appendf(TEXT(" FadeIn:%f/%f  StartBlendVelocity:%s FadeOut:%f/%f  StartFadeOutVelocity:%s\n"), CurBlendInTime, BlendInTime, *BlendFadeInVelocity.ToString(),  CurFadeOutTime, FadeOutTime, *(StartFadeOutVelocity.ToString()));
	infoOut.Appendf(TEXT("FMaxSpeed:%f  FMaxAcce:%f  FMaxBrakingDec:%f\n"), ForceMaxSpeed, ForceMaxAcceleration, ForceMaxBrakingDeceleration);
}

#endif


// ======================================================PositionAdditiveITMC=================================================
bool PositionAdditiveITMC::CalculateMovementTick(const float deltaTime, const bool isNeedOutput, const FTransform& baseTransform, MovementContext& outputContext)
{

	if(SwitchOffFadeOutTime >= 0)
	{
		SwitchOffAccuDuration += deltaTime;
		if(SwitchOffAccuDuration >= SwitchOffFadeOutTime)
		{
			PositionAdditiveOffset.Set(0, 0, 0);
			InputThrusterMC::OutputFinalMovementDelta(isNeedOutput, PositionAdditiveOffset, false, 0.0, outputContext);
			MovementCalculatorBase::SetEnable(false);
			SwitchOffFadeOutTime = -1.0;
			return true;
		}
		else
		{
			PositionAdditiveOffset = PositionAdditiveOffset * (1.0f- (SwitchOffAccuDuration / SwitchOffFadeOutTime));
			InputThrusterMC::OutputFinalMovementDelta(isNeedOutput, PositionAdditiveOffset, false, 0.0, outputContext);
			return true;
		}
		
	}
	else
	{
		return InputThrusterMC::CalculateMovementTick(deltaTime, isNeedOutput, baseTransform, outputContext);
	}
}

void PositionAdditiveITMC::Reset()
{
	InputThrusterMC::Reset();
	PositionAdditiveOffset.Set(0, 0, 0);
	MoveAxisScale.Set(1.0, 1.0, 1.0);
	SwitchOffFadeOutTime = -1;
	SwitchOffAccuDuration = 0.0f;
	LimitedRadius = 100.0f;
	UsingForSplineMove = false;
	
}


void PositionAdditiveITMC::OutputFinalMovementDelta(bool IsNeedOutput, const FVector& MovementDelta, bool NeedRatioMode, float Ratio, MovementContext& MC)
{
	FVector FinalMovementDelta = MovementDelta;
	
	FinalMovementDelta.X *= MoveAxisScale.X;
	FinalMovementDelta.Y *= MoveAxisScale.Y;
	FinalMovementDelta.Z *= MoveAxisScale.Z;
	
	PositionAdditiveOffset += FinalMovementDelta;

	// 目前制作球形
	if(FMath::Abs(PositionAdditiveOffset.X) > LimitedRadius)
	{
		PositionAdditiveOffset.X = LimitedRadius * FMath::Sign(PositionAdditiveOffset.X);
	}

	if(FMath::Abs(PositionAdditiveOffset.Y) > LimitedRadius)
	{
		PositionAdditiveOffset.Y = LimitedRadius * FMath::Sign(PositionAdditiveOffset.Y);
	}
	
	if(FMath::Abs(PositionAdditiveOffset.Z) > LimitedRadius)
	{
		PositionAdditiveOffset.Z = LimitedRadius * FMath::Sign(PositionAdditiveOffset.Z);
	}

	if(!IsNeedOutput)
	{
		return;
	}
	
	if(UsingForSplineMove)
	{
		FVector WorldDeltaPos = PositionAdditiveOffset;
		if(MovementSpace == EMovementSpace::ELocal)
		{
			WorldDeltaPos = SplineMoveBaseTrans.TransformVectorNoScale(WorldDeltaPos);
	
		}
		
		if(NeedRatioMode)
		{
			MC.AccumulateWorldPosDeltaWithBlend(WorldDeltaPos, Ratio);
		}
		else
		{
			MC.AccumulateWorldPosDelta(WorldDeltaPos);
		}
		return;
	}
	
	InputThrusterMC::OutputFinalMovementDelta(IsNeedOutput, PositionAdditiveOffset, false, 0.0, MC);
}


#if UE_BUILD_DEVELOPMENT
void PositionAdditiveITMC::AppendDebugInfo(FString& infoOut) {
	InputThrusterMC::AppendDebugInfo(infoOut);
	infoOut.Append(TEXT("Curreint Is PositionAdditiveITMC  \n"));
	infoOut.Appendf(TEXT("XYZScale:%s  LimitedRadius:%.2f  PositionOffset:%s \n"),
		*MoveAxisScale.ToCompactString(), LimitedRadius, *PositionAdditiveOffset.ToCompactString());
	infoOut.Appendf(TEXT("SwitchOffFadeOutTime:%.2f  SwitchOffAccuDuration:%.2f \n"), SwitchOffFadeOutTime, SwitchOffAccuDuration);
}

#endif