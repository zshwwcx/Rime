// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Movement/MovementPipeline/MovementCorrector/MotionWarpCorrector.h"

#include "3C/Core/C7ActorInterface.h"
#include "3C/Character/LuaActorBase.h"
#include  "3C/Movement/RoleMovementComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "Misc/MathFormula.h"
#include "Kismet/KismetSystemLibrary.h"



static const float VALID_WARP_THRESHOLD = 0.2f;

MotionWarpCorrector::MotionWarpCorrector()
{
}

MotionWarpCorrector::~MotionWarpCorrector()
{
}

void MotionWarpCorrector::Init(MovementContext* MC)
{
	Reset(MC);
}

void MotionWarpCorrector::ResetSpecialParams()
{
	NameToWarpTargetInfo.Empty();
}

void MotionWarpCorrector::Reset(MovementContext* MC)
{
	WarpTranslationASM = EArgSourceMode::NoArgSource;
	WarpRotationASM = EArgSourceMode::NoArgSource;
	RootWarpMode = ERootWarpMode::KeepRoot;
	IsInitRotationWarpSuccess = false;
	IsInitTranslationWarpSuccess = false;
	WarpDuration = 0.0f;
	CurWarpAccuTime = 0.0f;
	CurWarpRate = 1.0f;
	RotatorDiffInLocalSpace.Set(0, 0, 0);
	RotatorAccumulated.Set(0, 0, 0);
	IsPreparedDoneForCorrection = false;
	WarpTargetPos.Set(0.0f, 0.0f, 0.0f);
	//NameToTargetPosMap.Empty(); 
	CurWarpTargetName = NAME_None;
	LocalEndRMTrans.SetIdentity();
	LocalStartRMTrans.SetIdentity();
	WorldSpaceWarpTransform.SetIdentity();
	WarpTransOperateMask = (int)ETransformOperateMask::NONE;
	TargetActor.Reset();
	WarpAnimStartTime = 0.0f;
	WarpAnim.Reset();
	WarpedXYScale = 0.0f;
	WarpedZScale = 0.0f;
	WarpRotDireciton = ERotationWrapDirection::Auto;
}

bool MotionWarpCorrector::DoMovementCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
{
	
	// 还没有开始调用, 或者已经结束
	if (WarpDuration <= 0.0f || CurWarpAccuTime >= WarpDuration) {
		return false;
	}

	ensureAlways(WarpTranslationASM != EArgSourceMode::NoArgSource || WarpRotationASM != EArgSourceMode::NoArgSource);

	float SampleDelta = DeltaTime;
	if (WarpAnim.IsValid()) {
		SampleDelta = DeltaTime * WarpAnim->RateScale * CurWarpRate;

		// 第一次进来, 如果直接用starttime+deltatime, 可能和实际动画的time对不上
		if(FMath::IsNearlyZero(CurWarpAccuTime))
		{
			if(auto* AnimInst = MovementComponent.GetAnimInstanceForMovement())
			{
				float CurPlayedTime = 0.0f;
				if(AnimInst->GetAnimSequenceBaseCurrentPlayedTime(WarpAnim.Get(), CurPlayedTime))
				{
					SampleDelta = CurPlayedTime - WarpAnimStartTime;
				}
			}
		}
	}

	bool isUsingTranslationWarp = UsingTranslationWarp();
	bool isUsingRotationWarp = UsingRotationWarp();
		
	if (IsPreparedDoneForCorrection == false) {
		IsPreparedDoneForCorrection = true;
		
		if (isUsingRotationWarp) {
			SetupRotationWarpForCorrection(MC, LocalStartRMTrans, LocalEndRMTrans);
		}

		if (isUsingTranslationWarp) {
			SetupTranslationWarpForCorrection(MC);
		}
	}

	FVector DeltaTargetLoc = FVector::ZeroVector;
	if (TargetActor.IsValid())
	{
		FVector OldLoc = CurrentActorLocation;
		if (TargetSocketName.IsNone())
		{
			UpdateTargetActorSpaceWarpTransform();
			WarpTargetPos = CurrentActorTargetTransform.GetLocation();
			WarpTargetRotator = CurrentActorTargetTransform.GetRotation().Rotator();
		}
		else
		{
			UpdateTargetSocketWarpTransform();
			WarpTargetPos = CurrentSocketTransform.GetLocation();
			WarpTargetRotator = CurrentSocketTransform.GetRotation().Rotator();
		}
		DeltaTargetLoc = CurrentActorLocation - OldLoc;
	}
	
	if (WarpRotationASM == EArgSourceMode::LocoInputVector) {
		if (CurWarpAccuTime <= InputQueryDuration && WarpAnim.IsValid()) {
			
			float prevClosetAngleSignedDiff = MathFormula::ClosetYawSignedDiff(ActorStartRotator.Yaw, WarpTargetRotator.Yaw);
			
			float NewInputYaw = MC.GetFaceDirectionInputVec(WarpTargetRotationLocoSource).ToOrientationRotator().Yaw;
			float currentClosetAngleSignedDiff = MathFormula::ClosetYawSignedDiff(ActorStartRotator.Yaw, NewInputYaw);

			// 只有新输入想要扩大角度差时, 才接受新输入
			if((prevClosetAngleSignedDiff * currentClosetAngleSignedDiff > 0) &&  ((fabs(currentClosetAngleSignedDiff) - fabs(prevClosetAngleSignedDiff)) > VALID_WARP_THRESHOLD))
			{
				WarpTargetRotator.Yaw = NewInputYaw;
				LocalStartRMTrans = WarpAnim->ExtractRootTrackTransform(WarpAnimStartTime + CurWarpAccuTime, nullptr);
				LocalEndRMTrans = WarpAnim->ExtractRootTrackTransform(WarpAnimStartTime + WarpDuration, nullptr);
				// 输入目标每帧在变, 每次空间都需要重新算
				SetupRotationWarpForCorrection(MC, LocalStartRMTrans, LocalEndRMTrans);
			}
		}
	}
	
	float leftTimeToWarp = WarpDuration - CurWarpAccuTime;

	WarpProgressBlend.Update(SampleDelta);

	const auto& curActorTrans = MC.GetCurrentActorTransform();
	// 最后一次tick, 直接设定到目标值
	if (leftTimeToWarp < SampleDelta || !WarpAnim.IsValid()) {
		MC.SetFinishedCorrectorType(EMovementCorrectorType::MotionWarpCorrector);
		if (isUsingTranslationWarp) {
			UpdateGravityAndPhysicFix(MC);
			if (ERootWarpMode::RootAsCapsuleCenterKeepWorld != RootWarpMode && ERootWarpMode::RootAsCapsuleBottomKeepWorld != RootWarpMode)
			{
				MC.OccupyAbsoluteWorldPos(WarpTargetPos);
			}
		}
		
		if (isUsingRotationWarp) {
			FRotator finalRot = WarpTargetRotator;
			MC.OccupyAbsoluteWorldRot(finalRot.Quaternion());
		}
		CurWarpAccuTime = WarpDuration;
		return true;
	}

	CurWarpAccuTime += SampleDelta;

	// 因为notify可能不是帧对齐的, 所以这里时间本身可能不准确, 例如有一个半帧时间偏差, 但是不要紧, 这里是直接位移在local空间的值, 直接变换到世界空间, 是准确的
	float CurrentAnimSampleTime = WarpAnimStartTime + CurWarpAccuTime;

	if (isUsingTranslationWarp) {
		LocalSampleTrans = WarpAnim->ExtractRootMotionFromRange(WarpAnimStartTime, CurrentAnimSampleTime);
		UpdateGravityAndPhysicFix(MC);
		
		if (IsInitTranslationWarpSuccess == true)
		{
			if (WarpTranslationASM == EArgSourceMode::TargetActor
				|| WarpTranslationASM == EArgSourceMode::TargetActorDynamic)
			{
				ActorTransWhenStart.AddToTranslation(DeltaTargetLoc);

				if (WarpTranslationASM == EArgSourceMode::TargetActorDynamic)
				{
					if (!DeltaTargetLoc.IsNearlyZero())
					{
						UpdateTranslationWarpForCorrection(MC, WarpTargetPos - ActorTransWhenStart.GetTranslation());
					}
				}
			}
		}
			
		if (IsInitTranslationWarpSuccess == true) {		
			FVector ToWorldVec = WarpTargetPos - ActorTransWhenStart.GetTranslation();

			FVector CurrentTranslationVec = LocalSampleTrans.GetTranslation();
			float LocalSpazeZ = CurrentTranslationVec.Z;
			// 没有合理位移, 直接拉到终点位置
			if (WarpedXYScale < 0.01f) {
				WarpedTranslation = ToWorldVec;
				WarpedTranslation.Z = 0;
			}
			else {
			
				CurrentTranslationVec.Z = 0;
				WarpedTranslation = WorldSpaceWarpTransform.TransformVector(CurrentTranslationVec); // 要wrap localstart中的点
				WarpedTranslation = WarpedTranslation * WarpedXYScale; // 这里做各轴上数值缩放
			}
			
			float ZRatio = 1.0f;
			// 没有位移, 就直接拉到终点高度
			if (fabs(WarpedZScale) < 0.1f) {
				WarpedTranslation.Z = ToWorldVec.Z;
			}
			else {
				ZRatio = LocalSpazeZ / RootZOffsetLocal; // 对Root与模型皮的偏移, 就跟着root运动, 设置只mesh偏移的时候, 这样才能补偿actor 运动中的偏移
				WarpedTranslation.Z = LocalSpazeZ * WarpedZScale;
			}
		
			
			FVector warpedWorldPosition = WarpedTranslation + ActorTransWhenStart.GetTranslation();
			
			// Root 有变换调整, 根据模式处理mesh offset、世界位置Z修正
			if (ERootWarpMode::RootAsCapsuleCenter == RootWarpMode || ERootWarpMode::RootAsCapsuleCenterKeepWorld == RootWarpMode) {
				float warpedMeshZ = ZRatio * (RootZOffsetEnd - RootZOffsetStart);
				MC.ProduceMeshAdditionalOffset(0, 0, warpedMeshZ);
				// 补偿逻辑位置
				warpedWorldPosition.Z = warpedWorldPosition.Z +(RootZOffsetEnd - RootZOffsetStart) - warpedMeshZ;
			}
			else if(ERootWarpMode::RootAsCapsuleBottom == RootWarpMode || ERootWarpMode::RootAsCapsuleBottomKeepWorld == RootWarpMode) {
				float warpedMeshZ = ZRatio * (RootZOffsetEnd - RootZOffsetStart);
				// 注意, 这里是要将FinalMeshOffset从0变成OrignialMeshOffset, 使用的是AddtionalMeshOffset接口完成, 所以AdditionalMeshOffset应该是逐渐往0靠拢即可
				MC.ProduceMeshAdditionalOffset(0, 0, warpedMeshZ - RootZOffsetEnd);
				// 补偿逻辑位置
				warpedWorldPosition.Z = warpedWorldPosition.Z - warpedMeshZ;
			}

			
			if (ERootWarpMode::RootAsCapsuleCenterKeepWorld != RootWarpMode && ERootWarpMode::RootAsCapsuleBottomKeepWorld != RootWarpMode)
			{
				MC.OccupyAbsoluteWorldPos(warpedWorldPosition);
			}
		}
		else {
			if (ERootWarpMode::RootAsCapsuleCenterKeepWorld != RootWarpMode && ERootWarpMode::RootAsCapsuleBottomKeepWorld != RootWarpMode)
			{
				const float blendAlpha = WarpProgressBlend.GetAlpha();
				const FVector StartLoc = ActorTransWhenStart.GetLocation();
				const FVector EndPoint = StartLoc + blendAlpha * (WarpTargetPos - StartLoc);
				MC.OccupyAbsoluteWorldPos(EndPoint);
			}
		}
	}

	if (isUsingRotationWarp) {
		FRotator curActorRotator = curActorTrans.GetRotation().Rotator();
		FRotator finalRot = curActorRotator;
		
		if (IsInitRotationWarpSuccess) {

			// 这里和Tranlation的warp不一样, Translation使用的是整体空间变换, Rotation则是要一个Delta
			FRotator sampleRotator = WarpAnim->ExtractRootMotionFromRange(WarpAnimStartTime + CurWarpAccuTime - SampleDelta, WarpAnimStartTime + CurWarpAccuTime).Rotator();
			// 这里累计值要自己用数值, 否则会被FRotator规约到180度范围内, 无法做超过180度的处理了
			RotatorAccumulated.X += sampleRotator.Pitch;
			RotatorAccumulated.Y += sampleRotator.Yaw;
			RotatorAccumulated.Z += sampleRotator.Roll;
			// 如果有rootmotion数据, 就用rootmotion warp缩放, 否则就使用插值
			if ((WarpTransOperateMask) | (int)(ETransformOperateMask::PITCH)) {
				finalRot.Pitch = DoAngleCloseWarp(
					ActorStartRotator.Pitch, WarpTargetRotator.Pitch, RotatorDiffInLocalSpace.X, RotatorAccumulated.X, ERotationWrapDirection::Auto);
			}
			
			if ((WarpTransOperateMask) | (int)(ETransformOperateMask::YAW)) {
				finalRot.Yaw = DoAngleCloseWarp(
					ActorStartRotator.Yaw, WarpTargetRotator.Yaw, RotatorDiffInLocalSpace.Y, RotatorAccumulated.Y, YawRotDirection);
			}

			if ((WarpTransOperateMask) | (int)(ETransformOperateMask::ROLL)) {
				finalRot.Roll = DoAngleCloseWarp(
					ActorStartRotator.Roll, WarpTargetRotator.Roll, RotatorDiffInLocalSpace.Z, RotatorAccumulated.Z, ERotationWrapDirection::Auto);
			}
		}
		MC.OccupyAbsoluteWorldRot(finalRot.Quaternion());
	}
	return true;

}


float MotionWarpCorrector::DoAngleCloseWarp(float actorStartAngle, float warpTargetAngle, float angleDiffInLocalSpace, float RotateInLocalSpace, ERotationWrapDirection RotDirection) {


	// 实际旋转角，永远要按照劣弧进行旋转
	float closetAngleSignedDiff = MathFormula::ClosetYawSignedDiff(actorStartAngle, warpTargetAngle);

	if (fabs(angleDiffInLocalSpace) > VALID_WARP_THRESHOLD && fabs(closetAngleSignedDiff) > VALID_WARP_THRESHOLD)
	{

		// 需要做一个数值容忍, 动画数据可能本身有很小的值, 不干净
		if (fabs(RotateInLocalSpace) > VALID_WARP_THRESHOLD) {
			
			// 进行同向方向的旋转warp处理
			// 进行采样数据的同方向数值修正, 动画数据本身可能是会有符号抖动的

			if (RotDirection == ERotationWrapDirection::Left) {
			if (closetAngleSignedDiff > 0) {
					closetAngleSignedDiff = -(360.0f - closetAngleSignedDiff);
			}

			}
			else if (RotDirection == ERotationWrapDirection::Right) {
				if (closetAngleSignedDiff < 0) {
					closetAngleSignedDiff = 360 + closetAngleSignedDiff;
		}
		
			}
		}
		else {
			RotateInLocalSpace = 0.0f;
		}

		return actorStartAngle + fabs(closetAngleSignedDiff / angleDiffInLocalSpace) * RotateInLocalSpace;;
	}
	else 
	{
		return  WarpProgressBlend.GetAlpha() * closetAngleSignedDiff + actorStartAngle;
	}
}

bool MotionWarpCorrector::UpdateTranslationWarpForCorrection(const MovementContext& MC, FVector toWarpTargetVec)
{
	FTransform compoentSpaceRootmotionTrans = LocalEndRMTrans.GetRelativeTransform(LocalStartRMTrans);
	FVector componentTranslationVec = compoentSpaceRootmotionTrans.GetTranslation();
	
	// 距离太小了, 直接不用做了
	if (toWarpTargetVec.Length() < 0.1f) {
		return false;
	}

	if (componentTranslationVec.Length() < 0.1f) {
		return false;
	}

	float WorldZOffset = toWarpTargetVec.Z;

	// 注意, 这里的缩放是带朝向的, 直接对Z轴运动单独处理
	if (fabs(WorldZOffset) < 1.0f || fabs(RootZOffsetLocal) < 1.0f) {
		WarpedZScale = 0.0f;
	}
	else {
		WarpedZScale = WorldZOffset / RootZOffsetLocal;
	}

	// 不做Z的空间变换, 否则整个Z的变换会被拉变形, 这里还是保持在世界空间的Z轴上
	componentTranslationVec.Z = 0;
	FTransform componentToLocalWrapTrans;
	FRotator AlignBases = componentTranslationVec.ToOrientationRotator();
	AlignBases.Roll = 0;
	componentToLocalWrapTrans.SetRotation(AlignBases.Quaternion());
	
	WorldSpaceWarpTransform.SetIdentity();
	toWarpTargetVec.Z = 0;

	FRotator WorldTargetBase = toWarpTargetVec.ToOrientationRotator();
	WorldTargetBase.Roll = 0;
	WorldSpaceWarpTransform.SetRotation(WorldTargetBase.Quaternion());

	WorldSpaceWarpTransform = componentToLocalWrapTrans.Inverse() * WorldSpaceWarpTransform;
	if (toWarpTargetVec.Length() < 1.0f || componentTranslationVec.Length() < 1.0f) {
		WarpedXYScale = 0.0f;
	}
	else {
		WarpedXYScale = toWarpTargetVec.Length() / componentTranslationVec.Length();
	}
	WorldSpaceWarpTransform.SetScale3D(FVector(1.0, 1.0, 1.0));
	
	return true;
}

void MotionWarpCorrector::SetupTranslationWarpForCorrection(const MovementContext& MC) {
	// 这里先支持固定点, 如果是动态点, 则需要拆出去, 并且每次DoMovementCorrection进行重新计算
	// 变换规则:
	// [1] 根据模型空间的矩阵差, 得到基准
	// [2] 根据玩家当前位置、目标位置, 得到目标空间
	// [3] 得到[1]->[2]的变换
	// [4] 运算过程中, 根据rootmotion 的累积得到RootMotion在LocalSpace中的位移点
	// [5] 使用[3] 变换[4]中的点, 最终完成变换
	// 注意: [1] [4]中美术动作的起始空间可能不是(0, 0, 0), 所以做了Relative的变换, 变换后等价变成了LocalSpace的(0,0,0)标准空间; [2]中同理

	FTransform compoentSpaceRootmotionTrans = LocalEndRMTrans.GetRelativeTransform(LocalStartRMTrans);
	FVector componentTranslationVec = compoentSpaceRootmotionTrans.GetTranslation();
	
	ActorTransWhenStart = MC.GetCurrentActorTransform();

	FVector orginalMeshOffset = MC.GetMeshOrignalOffset();
	FVector currentWorldTranslation = ActorTransWhenStart.GetTranslation();
	
	FVector targetPosForWarpSpaceCaculate = WarpTargetPos;
	RootZOffsetLocal = componentTranslationVec.Z;
	// 只要有Root Z Offset的处理Warp, 约定整个运动过程是视作Root来进行处理, 在运算过程中进行逻辑位置和MeshZOffset修正
	if (RootWarpMode == ERootWarpMode::RootAsCapsuleCenter || RootWarpMode == ERootWarpMode::RootAsCapsuleCenterKeepWorld) {
		RootZOffsetStart = orginalMeshOffset.Z;
		RootZOffsetEnd = 0.0f;

		// 进行位置处理, 虚拟运动是从Root开始的, 便于整个Warp流程的计算
		// TargetPos是不变的, 即TargetPos是Root最终运动位置, 也是逻辑位置
		currentWorldTranslation.Z -= (RootZOffsetEnd - RootZOffsetStart);
	}
	else if(RootWarpMode == ERootWarpMode::RootAsCapsuleBottom || RootWarpMode == ERootWarpMode::RootAsCapsuleBottomKeepWorld) {
		RootZOffsetStart = 0.0f;
		RootZOffsetEnd = orginalMeshOffset.Z;

		// 进行位置处理, 运动是从Root开始的, 也是当前逻辑位置, 便于整个Warp流程的计算
		// WarpTargetPos是按照Root的最终目标位置传入的, 但实际的最终逻辑位置是Root位置 - MeshOffset
		WarpTargetPos.Z -= RootZOffsetEnd;

	}
	else {
		RootZOffsetStart = 0.0f;
		RootZOffsetEnd = 0.0f;
	
	}
	ActorTransWhenStart.SetTranslation(currentWorldTranslation);
	
	IsInitTranslationWarpSuccess = UpdateTranslationWarpForCorrection(MC, targetPosForWarpSpaceCaculate - currentWorldTranslation);
}

void MotionWarpCorrector::UpdateTargetSocketWarpTransform()
{
	if (!TargetActor.IsValid()) return;
	
	IC7ActorInterface* C7ActorInterface = Cast<IC7ActorInterface>(TargetActor.Get());
	USkeletalMeshComponent* MainMesh = C7ActorInterface ? C7ActorInterface->GetMainMesh() : nullptr;
	// 初始化第一帧位置
	if (MainMesh)
	{
		CurrentSocketTransform = MainMesh->DoesSocketExist(TargetSocketName) ? MainMesh->GetSocketTransform(TargetSocketName) : MainMesh->GetBoneTransform(TargetSocketName);
		CurrentSocketTransform.SetLocation(CurrentSocketTransform.GetLocation() + TargetSocketOffset);
	}
	else
	{
		CurrentSocketTransform = TargetActor->GetActorTransform();
	}
	CurrentActorLocation = CurrentSocketTransform.GetLocation();
}

void MotionWarpCorrector::UpdateTargetActorSpaceWarpTransform()
{
	if (!TargetActor.IsValid()) return;
	
	CurrentActorTargetTransform = TargetActor->GetActorTransform();
	CurrentActorTargetTransform = TargetTransformInActorSpace * CurrentActorTargetTransform;
	
	CurrentActorLocation = TargetActor->GetActorLocation();
}

void MotionWarpCorrector::UpdateGravityAndPhysicFix(MovementContext& MC)
{
	if (ERootWarpMode::RootAsCapsuleCenterKeepWorld != RootWarpMode and ERootWarpMode::RootAsCapsuleBottomKeepWorld != RootWarpMode)
	{
		MC.IncreaseIgnoreGravity();
		MC.IncreaseIgnorePhyiscFixup();	
	}
}


void MotionWarpCorrector::UseTranslationWarpWithFixMode(MovementContext& MC, const FVector& targetpos, ERootWarpMode rootWarpMode, const FName& WarpTargetName) {
	ensureAlways(IsPreparedDoneForCorrection == false);
	//WarpTargetPos = targetpos;
	// 如果是当前运行的Warp，直接设置Warp目标位置，否则缓存起来，可能后面的Warp会用到
	if (WarpTargetName == CurWarpTargetName)
	{
		WarpTargetPos = targetpos;
		WarpTranslationASM = EArgSourceMode::FixedValue;
		RootWarpMode = rootWarpMode;
	}
	else
	{
		NameToWarpTargetInfo.Add(WarpTargetName, FWarpTargetInfo(targetpos, EArgSourceMode::FixedValue, rootWarpMode));
	}
}


void MotionWarpCorrector::SetupRotationWarpForCorrection(const MovementContext& MC,  const FTransform& startLocalTrans, const FTransform& endLocalTrans){
	
	FRotator RotatorDiff  = endLocalTrans.GetRelativeTransform(startLocalTrans).Rotator();
	RotatorDiffInLocalSpace.X = RotatorDiff.Pitch;
	RotatorDiffInLocalSpace.Y = RotatorDiff.Yaw;
	RotatorDiffInLocalSpace.Z = RotatorDiff.Roll;
	RotatorAccumulated.Set(0, 0, 0);
	if (WarpRotDireciton == ERotationWrapDirection::Auto) {
		if (WarpAnim.IsValid()) {
			// 使用中间数据采样来自动确定旋转方向, 要修正末尾数值符号不对时的问题(Unreal导入旋转时超过180或者刚好180会有朝向数值符号取反问题)
			FRotator MiddleRotatorDiff = WarpAnim->ExtractRootMotionFromRange(WarpAnimStartTime, WarpAnimStartTime + WarpDuration / 2.0f).Rotator();

			if (fabs(MiddleRotatorDiff.Yaw) > VALID_WARP_THRESHOLD) {
				if (MiddleRotatorDiff.Yaw > 0) {
					YawRotDirection = ERotationWrapDirection::Right;
				}
				else {
					YawRotDirection = ERotationWrapDirection::Left;
				}
			}
		}
		else {
			if (fabs(RotatorDiffInLocalSpace.Y) > VALID_WARP_THRESHOLD) {
				if (RotatorDiffInLocalSpace.Y > 0) {
					YawRotDirection = ERotationWrapDirection::Right;
				}
				else {
					YawRotDirection = ERotationWrapDirection::Left;
				}
			}
		}

	}
	else {
		YawRotDirection = WarpRotDireciton;
	}
	
	if (fabs(RotatorDiffInLocalSpace.Y) > VALID_WARP_THRESHOLD) {
		if (YawRotDirection == ERotationWrapDirection::Left && RotatorDiffInLocalSpace.Y > 0) {
			RotatorDiffInLocalSpace.Y = -(360.0f - RotatorDiffInLocalSpace.Y);
		}
		else if (YawRotDirection == ERotationWrapDirection::Right && RotatorDiffInLocalSpace.Y < 0) {
			RotatorDiffInLocalSpace.Y = 360.0f + RotatorDiffInLocalSpace.Y;
		}
	}

#if WITH_EDITOR
	if (FMath::Abs(RotatorDiffInLocalSpace.X) > 360.0f || FMath::Abs(RotatorDiffInLocalSpace.Y) > 360.0f || FMath::Abs(RotatorDiffInLocalSpace.Z) > 360.0f)
	{
		ensureAlways(true);
		UE_LOG(LogTemp, Warning, TEXT("[MotionWarp]RotatorDiffInLocalSpace Exceed 360.0f! Check Animation!"))
	}
#endif

	ActorStartRotator = MC.GetCurrentActorTransform().GetRotation().Rotator();
	IsInitRotationWarpSuccess = true;
}

void MotionWarpCorrector::UseRotationWarpWithFixMode(MovementContext& MC, int transOperateMask, const float pitch, const float targetYaw, const float roll) {
	ensureAlways(IsPreparedDoneForCorrection == false);
	
	UpdateRotationWarpArgWithFixMode(MC, transOperateMask, pitch, targetYaw, roll);

}

void MotionWarpCorrector::UpdateWarpRate(float rate) {
	CurWarpRate = rate;
}

void MotionWarpCorrector::UpdateRotationWarpArgWithFixMode(MovementContext& MC, int transOperateMask, const float pitch, const float targetYaw, const float roll) {
	bool hasRotationSet = false;

	WarpTargetRotator = MC.GetCurrentActorTransform().GetRotation().Rotator();

	if ((transOperateMask) | (int)(ETransformOperateMask::PITCH)) {
		WarpTargetRotator.Pitch = pitch;
		hasRotationSet = true;
	}

	if ((transOperateMask) | (int)(ETransformOperateMask::YAW)) {
		WarpTargetRotator.Yaw = targetYaw;
		hasRotationSet = true;
	}

	if ((transOperateMask) | (int)(ETransformOperateMask::ROLL)) {
		WarpTargetRotator.Roll = roll;
		hasRotationSet = true;
	}

	ensureAlways(hasRotationSet == true);

	WarpTransOperateMask = transOperateMask;

	WarpRotationASM = EArgSourceMode::FixedValue;

	if(IsPreparedDoneForCorrection){
		SetupRotationWarpForCorrection(MC, LocalStartRMTrans, LocalEndRMTrans);
	}

}

void MotionWarpCorrector::UseRotationWarpWithLocoInputMode(MovementContext& MC, const float inputQueryDuration, EFaceDirectionInputMode FaceMode) {
	ensureAlways(IsPreparedDoneForCorrection == false);
	
	WarpTransOperateMask = (int) ETransformOperateMask::YAW;
	InputQueryDuration = inputQueryDuration;
	WarpRotationASM = EArgSourceMode::LocoInputVector;
	WarpTargetRotator = MC.GetCurrentActorTransform().Rotator();
	WarpTargetRotationLocoSource = FaceMode;
	WarpTargetRotator.Yaw = MC.GetFaceDirectionInputVec(FaceMode).ToOrientationRotator().Yaw;
}

void MotionWarpCorrector::UpdateTargetPosAndRotation(const FVector& targetpos, const FRotator& targetRot)
{
	WarpTargetPos = targetpos;
	WarpTargetRotator = targetRot;
}

void MotionWarpCorrector::UseSocketWarpWithFixMode(MovementContext& MC, ERootWarpMode rootWarpMode, TWeakObjectPtr<AActor> Actor, const FName& SocketName, const FVector& Offset)
{
	RootWarpMode = rootWarpMode;
	TargetActor = Actor;
	TargetSocketName = SocketName;
	TargetSocketOffset = Offset;
	
	UpdateTargetSocketWarpTransform();
	
	UseTranslationWarpWithFixMode(MC, CurrentSocketTransform.GetLocation(), rootWarpMode);
	FRotator Rot = CurrentSocketTransform.GetRotation().Rotator();
	UpdateRotationWarpArgWithFixMode(MC, (int)ETransformOperateMask::ROTATION_MASK, Rot.Pitch, Rot.Yaw, Rot.Roll);

	WarpTranslationASM = EArgSourceMode::TargetActorDynamic;
	WarpRotationASM = EArgSourceMode::TargetActorDynamic;
}


void MotionWarpCorrector::UseActorSpaceTransformWarpWithFixMode(MovementContext& MC, ERootWarpMode rootWarpMode, TWeakObjectPtr<AActor> Actor, const FTransform& targetTransformInActorSpace)
{
	RootWarpMode = rootWarpMode;
	TargetActor = Actor;
	TargetTransformInActorSpace = targetTransformInActorSpace;
	
	UpdateTargetActorSpaceWarpTransform();
	
	UseTranslationWarpWithFixMode(MC, CurrentActorTargetTransform.GetLocation(), rootWarpMode);
	FRotator Rot = CurrentActorTargetTransform.GetRotation().Rotator();
	UpdateRotationWarpArgWithFixMode(MC, (int)ETransformOperateMask::ROTATION_MASK, Rot.Pitch, Rot.Yaw, Rot.Roll);
	
	WarpTranslationASM = EArgSourceMode::TargetActorDynamic;
	WarpRotationASM = EArgSourceMode::TargetActorDynamic;
}

// Rootmotion的Local数据->变换成warp区间所确定的local空间(有旋转、scale的处理)->变换成Component空间->变换到世界空间(有旋转、scale的处理)
// 调用时机: 1) 动画Notify的调用
//           2) 代码中的逻辑调用(例如技能编辑器中)
void MotionWarpCorrector::InitWorldSpaceWarpTransform(MovementContext* MC,
	float duration, float startTime, ERotationWrapDirection RotDirection,
	const FTransform& localStartRMTrans, const FTransform& localEndRMTrans, UAnimSequenceBase* Animation, const FName& WarpTargetName) {

	if (!CurWarpTargetName.IsEqual(WarpTargetName))
	{
		Reset(MC);
	}
	ensureAlways(IsInitRotationWarpSuccess == false && IsInitTranslationWarpSuccess == false);
	ensureAlways(duration > 0.0f);
	WarpRotDireciton = RotDirection;
	WarpDuration = duration;
	WarpAnimStartTime = startTime;
	WarpAnim = Animation;
	CurWarpAccuTime = 0.0f;
	WarpedXYScale = 1.0f;

	LocalStartRMTrans = localStartRMTrans;
	LocalEndRMTrans = localEndRMTrans;

	WarpProgressBlend.Reset();
	WarpProgressBlend.SetValueRange(0, 1);
	WarpProgressBlend.SetBlendTime(WarpDuration);
	WarpProgressBlend.SetBlendOption(EAlphaBlendOption::Cubic);

	WarpedTranslation.Set(0.0f, 0.0f, 0.0f);
	CurWarpTargetName = WarpTargetName;
	// 可能在当前warp开始之前就设置了Warp的目标位置
	if (NameToWarpTargetInfo.Contains(CurWarpTargetName))
	{
		WarpTargetPos = NameToWarpTargetInfo[CurWarpTargetName].TargetPos;
		WarpTranslationASM = NameToWarpTargetInfo[CurWarpTargetName].WarpTranslationASM;
		RootWarpMode = NameToWarpTargetInfo[CurWarpTargetName].RootWarpMode;
	}

	return;
}


#if UE_BUILD_DEVELOPMENT
void MotionWarpCorrector::AppendDebugInfo(FString& infoOut) {
	infoOut.Append(TEXT("===================<Title_Blue>MotionWarpCorrector</>===================\n"));
	
	if (WarpAnim.IsValid()) {
		infoOut.Appendf(TEXT("AnimRate:%f  WarpAnim:%s  \n"), WarpAnim->RateScale, *WarpAnim->GetPathName());
	}
	infoOut.Appendf(TEXT("RootWarpMode:%d  WarpTransOperateMask:%d  WarpDuration:%f  IsPreparedDoneForCorrection:%d IsInitRotationWarpSuccess:%d  IsInitTranslationWarpSuccess:%d\n")
		, RootWarpMode, WarpTransOperateMask, WarpDuration, IsPreparedDoneForCorrection, IsInitRotationWarpSuccess, IsInitTranslationWarpSuccess);


	infoOut.Appendf(TEXT("HasTargetActor:%d  TargetSocketName:%s TargetSocketOffset：%s WarpTranslationASM：%d  WarpRotationASM:%d \n")
		, TargetActor.IsValid(), *TargetSocketName.ToString(), *TargetSocketOffset.ToCompactString(), WarpTranslationASM, WarpRotationASM);

	infoOut.Appendf(TEXT("WarpTargetPos:%s  WarpTargetRotator:%s  WarpRate:%f  InputQueryDuration:%f  \n")
		, *(WarpTargetPos.ToString()), *WarpTargetRotator.ToCompactString(), CurWarpRate, InputQueryDuration);
	infoOut.Appendf(TEXT("LocalStartRMTrans:%s  LocalEndRMTrans:%s\n")
		, *(LocalStartRMTrans.ToString()), *(LocalEndRMTrans.ToString()));
	
	FVector ClosetSignDiff;
	ClosetSignDiff.X = MathFormula::ClosetYawSignedDiff(ActorStartRotator.Pitch, WarpTargetRotator.Pitch);
	ClosetSignDiff.Y = MathFormula::ClosetYawSignedDiff(ActorStartRotator.Yaw, WarpTargetRotator.Yaw);
	ClosetSignDiff.Z = MathFormula::ClosetYawSignedDiff(ActorStartRotator.Roll, WarpTargetRotator.Roll);
	infoOut.Appendf(TEXT("WarpRotDireciton:%d  YawRotDirection:%d   RotatorDiffInLocalSpace:%s  ClosetSignDiff:%s ActorStartRotator:%s \n")
		, WarpRotDireciton, YawRotDirection, *RotatorDiffInLocalSpace.ToCompactString(), *ClosetSignDiff.ToString(), *ActorStartRotator.ToCompactString()) ;
	infoOut.Appendf(TEXT("RootZOffsetStart:%f   RootZOffsetEnd:%f  RootZOffsetLocal:%f\n"), RootZOffsetStart, RootZOffsetEnd, RootZOffsetLocal);
	infoOut.Appendf(TEXT("WarpedXYScale:%f  WarpedZScale:%f   \n"), WarpedXYScale, WarpedZScale);

	infoOut.Appendf(TEXT("CurWarpAccuTime:%f  AccumulateRotator:%s  LocalSampleTrans: %s  \n"), CurWarpAccuTime, *RotatorAccumulated.ToString(), *(LocalSampleTrans.ToString()));

	infoOut.Appendf(TEXT(" warpedTranslation:%s\n"),*WarpedTranslation.ToCompactString()

	);

}

#endif