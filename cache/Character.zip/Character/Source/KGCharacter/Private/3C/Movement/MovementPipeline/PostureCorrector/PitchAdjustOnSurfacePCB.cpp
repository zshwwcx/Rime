// Fill out your copyright notice in the Description page of Project Settings.

#include "CoreMinimal.h"
#include "3C/Movement/MovementPipeline/MovementContext.h"
#include "3C/Movement/MovementPipeline/PostureCorrector/PitchAdjustOnSurfacePCB.h"
#include "Misc/MathFormula.h"
#include "Kismet/KismetMathLibrary.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Components/CapsuleComponent.h"

void FPitchAdjustOnSurfacePCB::Init(const MovementContext & MC)
 {
 }
 void FPitchAdjustOnSurfacePCB::Reset(const MovementContext & MC)
 {
	CurrentPitchAdjust = MC.GetCurrentActorTransform().Rotator().Pitch;
 }

 bool FPitchAdjustOnSurfacePCB::DoPostureCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
 {
	 if(DetectObjectTypes.IsEmpty())
	 {
		 return false;
	 }

	auto * CurWorld = MovementComponent.GetWorld();
	if(!CurWorld)
	{
		return false;
	}

 	auto CurTrans = GetCurActorTransformForPostureCorrection(MC);
	
 	FVector LocalUpOffset{0, 0, DetectDistance/2.0f};
	FVector LocalDownOffset{0, 0, -DetectDistance};
	FRotator WorldYawRot = CurTrans.GetRotation().Rotator();
	FVector WorldPos = CurTrans.GetTranslation();
	WorldYawRot.Pitch = 0;
	WorldYawRot.Roll = 0;
 	FVector ForwardWorldStartPos = WorldYawRot.RotateVector(ForwardOffset) + WorldPos + LocalUpOffset ;
 	FVector BackwardWorldStartPos = WorldYawRot.RotateVector(BackwardOffset)+ WorldPos  + LocalUpOffset;


 	FVector ForwardWorldEndPos = WorldYawRot.RotateVector(ForwardOffset) + WorldPos +LocalDownOffset;
 	FVector BackwardWorldEndPos = WorldYawRot.RotateVector(BackwardOffset) + WorldPos + LocalDownOffset;

	FVector CenterWorldStartPos = CurTrans.GetLocation() + LocalUpOffset;
	FVector CenterWorldEndPos = CurTrans.GetLocation() + LocalDownOffset;
	// Actor位置在胶囊体中心（高于地面半高），所以中心位置减去半高再做射线检测
	// Forward和BackWard是ActorSpace下的位置，本身已经配置在底部，所以不需要减去半高
	if (MovementComponent.UpdatedComponent)
	{
		if (UCapsuleComponent* CapsuleComponent = Cast<UCapsuleComponent>(MovementComponent.UpdatedComponent))
		{
			const float HalfHeight = CapsuleComponent->GetScaledCapsuleHalfHeight();
			CenterWorldStartPos.Z -= HalfHeight;
			CenterWorldEndPos.Z -= HalfHeight;
		}
	}
	
	float ResultPitch = CurTrans.Rotator().Pitch;
	
	
	TArray<AActor*> IgnoreActor;
	FHitResult CenterOutHit;
	// 要根据pitch调整的原因, 进行Z上的offset调整, 保障调整后, 头部或者尾部不会有穿帮; 
	float XAxisLengthToAdjustHeightOffset = 0;
	float StickToGroundHeightOffset = 0;
	float BackToCenterPitch = ResultPitch;
	if(UKismetSystemLibrary::SphereTraceSingleForObjects(CurWorld, CenterWorldStartPos, CenterWorldEndPos, 5, DetectObjectTypes, false, IgnoreActor, EDrawDebugTrace::None, CenterOutHit, true))

	{

		StickToGroundHeightOffset = CenterOutHit.Location.Z - CurTrans.GetTranslation().Z;
		
		FHitResult ForwardOutputHit;
		UKismetSystemLibrary::SphereTraceSingleForObjects(CurWorld, ForwardWorldStartPos, ForwardWorldEndPos, 5, DetectObjectTypes, false, IgnoreActor, EDrawDebugTrace::None, ForwardOutputHit, true);
		
		FHitResult BackwardOutputHit;
		UKismetSystemLibrary::SphereTraceSingleForObjects(CurWorld, BackwardWorldStartPos, BackwardWorldEndPos, 5, DetectObjectTypes, false, IgnoreActor, EDrawDebugTrace::None, BackwardOutputHit, true);

		if(ForwardOutputHit.IsValidBlockingHit() || BackwardOutputHit.IsValidBlockingHit())
		{
			// 前后都有碰撞
			if(ForwardOutputHit.IsValidBlockingHit() && BackwardOutputHit.IsValidBlockingHit())
			{
				FVector BackToCenter = CenterOutHit.Location - BackwardOutputHit.Location;
				FVector CenterToForward = ForwardOutputHit.Location - CenterOutHit.Location;
				
				BackToCenterPitch = BackToCenter.ToOrientationRotator().Pitch;
				float CenterToForwardPitch = CenterToForward.ToOrientationRotator().Pitch;

				// 要识别凸坡还是凹坡, 注意Pitch的数值, 角度越大pitch越大, 所以下面比较的时候要注意大小符号
				bool IsCenterOnConvexSlope = (MathFormula::ClosetYawSignedDiff(CenterToForwardPitch, BackToCenterPitch) > 0);
				if(IsCenterOnConvexSlope)
				{
					ResultPitch = (ForwardOutputHit.Location - CenterOutHit.Location).ToOrientationRotator().Pitch;
				}
				else
				{
					// 凹坡才是使用末尾和头部进行姿态调整
					ResultPitch = (ForwardOutputHit.Location - BackwardOutputHit.Location).ToOrientationRotator().Pitch;
					XAxisLengthToAdjustHeightOffset = BackwardOffset.X;
					
				}
			}
			// 只有前有碰撞
			else if(ForwardOutputHit.IsValidBlockingHit())
			{
				ResultPitch = (ForwardOutputHit.Location - CenterOutHit.Location).ToOrientationRotator().Pitch;
			}else
			// 只有后有碰撞
			{
				ResultPitch = (CenterOutHit.Location - BackwardOutputHit.Location).ToOrientationRotator().Pitch;
			}
		}
		
	}
	
	XAxisLengthToAdjustHeightOffset = FMath::Abs(XAxisLengthToAdjustHeightOffset);
	
	CurrentPitchAdjust = MathFormula::DecayValue(CurrentPitchAdjust, ResultPitch, AdjustHalflifeTime, DeltaTime );
	
	FRotator FinalWorldRotation = CurTrans.GetRotation().Rotator();
	FinalWorldRotation.Pitch = CurrentPitchAdjust;

	float TargetHeightOffset = 0;
	if(XAxisLengthToAdjustHeightOffset > 1.0 && HeightAdjustOffsetMax > 0)
	{
		
		float AbsPitch = MathFormula::ClosetYawAbsDiff(ResultPitch, BackToCenterPitch);
		float HeightOffset = FMath::Tan(FMath::DegreesToRadians(AbsPitch)) * XAxisLengthToAdjustHeightOffset;

		if(HeightOffset > HeightAdjustOffsetMin)
		{
			TargetHeightOffset = HeightOffset;
		}

		if(TargetHeightOffset > HeightAdjustOffsetMax)
		{
			TargetHeightOffset = HeightAdjustOffsetMax;
		}
	}

	CurrentHeightAdjustOffset = MathFormula::DecayValue(CurrentHeightAdjustOffset, TargetHeightOffset, AdjustHalflifeTime, DeltaTime);
	// 暂时可以不做贴地处理, 贴地的话可能会出现瞬时跳变(地形), 如果后续需要, 贴地高度调整也要用半衰处理
	//MC.AccumulateWorldPosDelta(FVector(0, 0, StickToGroundHeightOffset));
	MC.AccumulateLocalPosDelta(FVector(0, 0, CurrentHeightAdjustOffset));
	MC.OccupyAbsoluteWorldRot(FinalWorldRotation.Quaternion());
	return true;
 }

void FPitchAdjustOnSurfacePCB::StartPitchAdjust(float XForward, float YForward, float XBackward, float YBackward, float MinHeight, float MaxHeight, float DetectDist, float HalflifeTime,  TArray<int32> & ObjectTypes)
{
	ForwardOffset.Set(XForward, YForward, 0);
	BackwardOffset.Set(XBackward, YBackward, 0);
	DetectDistance = DetectDist;
	AdjustHalflifeTime = HalflifeTime;
	
	for (int32 ObjectTypeInt: ObjectTypes)
	{
		DetectObjectTypes.Add(TEnumAsByte<EObjectTypeQuery>(ObjectTypeInt));
	}
	CurrentHeightAdjustOffset = 0;
	HeightAdjustOffsetMin = MinHeight;
	HeightAdjustOffsetMax = MaxHeight;

}

#if UE_BUILD_DEVELOPMENT
void FPitchAdjustOnSurfacePCB::AppendDebugInfo(FString& infoOut)
{
	infoOut.Append(TEXT("===================<Title_Blue>FPitchAdjustOnSurfacePCB</>===================\n"));
	infoOut.Appendf(TEXT("ForwardOffset:%s  BackwardOffset:%s \n"), *ForwardOffset.ToCompactString(), *BackwardOffset.ToCompactString());
	infoOut.Appendf(TEXT("DetectDistance:%.2f  AdjustHalflifeTime:%.2f HeightAdjustOffsetMin:%.2f  HeightAdjustOffsetMax:%2.f   ObjectTypeNum:%d\n"),
		DetectDistance, AdjustHalflifeTime, HeightAdjustOffsetMin, HeightAdjustOffsetMax, DetectObjectTypes.Num());
	infoOut.Appendf(TEXT("CurrentHeightAdjustOffset:%.2f  CurrentPitchAdjust:%.2f  \n"), CurrentHeightAdjustOffset, CurrentPitchAdjust);
	
}
#endif