// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Movement/MovementPipeline/MovementCorrector/OnGroundMovementCorrector.h"

#include "3C/Character/BaseCharacter.h"
#include  "3C/Movement/RoleMovementComponent.h"
#include "Misc/MathFormula.h"

FOnGroundMovementCorrector::FOnGroundMovementCorrector()
{
}

FOnGroundMovementCorrector::~FOnGroundMovementCorrector()
{
}

void FOnGroundMovementCorrector::Init(MovementContext* MC)
{
}

void FOnGroundMovementCorrector::Reset(MovementContext* MC)
{
	MovementDeltaScaleRatio = 1.f;
	bLastInputYawValid = false;
}

bool FOnGroundMovementCorrector::DoMovementCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
{
	FTransform ActorTransform = MovementComponent.GetActorTransform();
	FVector InputVector = MC.GetLocoInputVec();
	bool hasInput = MC.GetHasLocoInput();

	FVector WorldMovementDelta = MC.GetWorldPosDelta();
	WorldMovementDelta.Z = 0.f;

	float CurTransformYaw = ActorTransform.Rotator().Yaw;
	float InputYaw = !hasInput ? (bLastInputYawValid ? LastInputYaw : CurTransformYaw) : InputVector.Rotation().Yaw;

	LastInputYaw = InputYaw;
	bLastInputYawValid = bLastInputYawValid || !InputVector.IsNearlyZero();

	float YawDiff = FMath::DegreesToRadians(MathFormula::ClosetYawAbsDiff(CurTransformYaw, InputYaw));

	float ScaleRatio = 1.0f - YawDiff / PI;
	float HalfLife = 0.01f;

	if (YawDiff > FMath::DegreesToRadians(MovementComponent.StopMoveAngle))
	{
		ScaleRatio = ScaleRatio * ScaleRatio * ScaleRatio * ScaleRatio;
		HalfLife = MovementComponent.StopMoveHalfLife;

		MovementDeltaScaleRatio = MathFormula::DecayValue(MovementDeltaScaleRatio, ScaleRatio, HalfLife, DeltaTime);
		WorldMovementDelta *= MovementDeltaScaleRatio;

		// 		UKismetSystemLibrary::PrintString(&MovementComponent, 
		//  		FString::Format(TEXT("DoMovementCorrection FrameNum = {0}  MovementDeltaScaleRatio = {1} HalfLife = {2}, ScaleRatio = {3}"), 
		//  		{ GFrameCounter, MovementDeltaScaleRatio, HalfLife, ScaleRatio }));
	}
	else if (YawDiff > FMath::DegreesToRadians(MovementComponent.StartMoveAngle))
	{
		ScaleRatio = 1.f;
		HalfLife = MovementComponent.StartMoveHalfLife;

		FVector RealInputNormalVector = FRotator(0, InputYaw, 0).RotateVector(FVector::ForwardVector);
		WorldMovementDelta = RealInputNormalVector * WorldMovementDelta.Size() * (WorldMovementDelta.Dot(RealInputNormalVector) > 0 ? 1 : 0);
		MovementDeltaScaleRatio = MathFormula::DecayValue(MovementDeltaScaleRatio, ScaleRatio, HalfLife, DeltaTime);
		WorldMovementDelta *= MovementDeltaScaleRatio;
	}
	else
	{
		FVector RealInputNormalVector = FRotator(0, InputYaw, 0).RotateVector(FVector::ForwardVector);
		WorldMovementDelta = RealInputNormalVector * WorldMovementDelta.Size() * (WorldMovementDelta.Dot(RealInputNormalVector) > 0 ? 1 : -1);
		ScaleRatio = 1.f;
		if (MovementDeltaScaleRatio < 0.99f)
		{
			MovementDeltaScaleRatio = MathFormula::DecayValue(MovementDeltaScaleRatio, ScaleRatio, 0.01f, DeltaTime);

			WorldMovementDelta *= MovementDeltaScaleRatio;
		}
		else
		{
			MovementDeltaScaleRatio = 1.f;
		}
	}

	WorldMovementDelta.Z = MC.GetWorldPosDelta().Z;
	// 	UKismetSystemLibrary::PrintString(&MovementComponent, 
	// 		FString::Format(TEXT("DoMovementCorrection FrameNum = {0} YawDiff = {1} ScaleRatio = {2} MovementDeltaScaleRatio = {3} OriginDis = {4}, FinalDis = {5}"), 
	// 		{ GFrameCounter, YawDiff, ScaleRatio, MovementDeltaScaleRatio, MC.GetWorldPosDelta().Length(), WorldMovementDelta.Length()}));

	// UE_LOG(LogTemp, Warning, TEXT("[szk]FOnGroundMovementCorrector, WorldMovementDelta: %f %f %f"), WorldMovementDelta.X, WorldMovementDelta.Y, WorldMovementDelta.Z);
	MC.SetWorldPosDelta(WorldMovementDelta);

	return true;
}





#if UE_BUILD_DEVELOPMENT
void FOnGroundMovementCorrector::AppendDebugInfo(FString& infoOut)
{
	infoOut.Append(TEXT("===================<Title_Blue>FOnGroundMovementCorrector</>===================\n"));
	infoOut.Appendf(TEXT("MovementDeltaScaleRatio:%f\n"), MovementDeltaScaleRatio);
	infoOut.Appendf(TEXT("bLastInputYawValid:%d  LastInputYaw:%f\n"), bLastInputYawValid, LastInputYaw);
}
#endif