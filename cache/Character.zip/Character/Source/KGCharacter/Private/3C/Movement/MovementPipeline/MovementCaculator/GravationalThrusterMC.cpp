// #pragma once
#include "3C/Movement/MovementPipeline/MovementCalculator/GravationalThrusterMC.h"

// 为地面Locomotion移动定制的程序驱动机制, 只有xy平面上的处理
bool GravationalThrusterMC::CalculateMovementTick(const float deltaTime, const bool isNeedOutput, const FTransform& baseTransform, MovementContext& outputContext)
{
	if (!isNeedOutput) {
		return false;
	}

	const FVector CurActorLocation = baseTransform.GetTranslation();	// 当前角色位置
	const FVector CurWorldPosDelta = outputContext.GetWorldPosDelta();	// 之前计算的当帧位移
	
	FVector FinalGravation = FVector::Zero();
	float OriginGravationForceForXY = 0.0f;
	float OriginGravationForceForXYZ = 0.0f;
	for (int32 i = 0; i < GravationalInfos.Num(); i++)
	{
		FVector tDeltaGravation = GravationalInfos[i].CenterLocation - CurActorLocation;
		
		// 对于原点正好处于角色位置的引力源，提供一个OriginGravationForce，用于抵消其他引力作用
		if (GravationalInfos[i].bAllowZGravational)
		{
			if (tDeltaGravation.Size() < deltaTime * GravationalInfos[i].MaxGravationalSpeed)
			{
				OriginGravationForceForXYZ += GravationalInfos[i].MaxGravationalSpeed * deltaTime;
				continue;
			}
		}
		else
		{
			if (tDeltaGravation.Size2D() < deltaTime * GravationalInfos[i].MaxGravationalSpeed)
			{
				OriginGravationForceForXY += GravationalInfos[i].MaxGravationalSpeed * deltaTime;
				continue;
			}
		}

		FinalGravation += GravationalInfos[i].bAllowZGravational ? tDeltaGravation.GetSafeNormal() * GravationalInfos[i].MaxGravationalSpeed * deltaTime :
			tDeltaGravation.GetSafeNormal2D() * GravationalInfos[i].MaxGravationalSpeed * deltaTime;
	}

	FVector ExpectedFinalDelta = FinalGravation + CurWorldPosDelta;	// 不考虑OriginGravationForce的预期最终位置
	// 先计算水平面的OriginGravationForce
	if (OriginGravationForceForXY > 0.0f)
	{
		if (ExpectedFinalDelta.Size2D() <= OriginGravationForceForXY)
		{
			ExpectedFinalDelta.X = 0.0f;
			ExpectedFinalDelta.Y = 0.0f;
		}
		else
		{
			ExpectedFinalDelta -= ExpectedFinalDelta.GetSafeNormal2D() * (ExpectedFinalDelta.Size2D() - OriginGravationForceForXY);
		}
	}
	// 再计算三维的OriginGravationForce
	if (OriginGravationForceForXYZ > 0.0f)
	{
		if (ExpectedFinalDelta.Size() <= OriginGravationForceForXYZ)
		{
			ExpectedFinalDelta = FVector::Zero();
		}
		else
		{
			ExpectedFinalDelta -= ExpectedFinalDelta.GetSafeNormal() * (ExpectedFinalDelta.Size() - OriginGravationForceForXYZ);
		}
	}

	outputContext.SetWorldPosDelta(ExpectedFinalDelta);
	return true;
}

void GravationalThrusterMC::AddGravationalInfo(float InCenterLocX, float InCenterLocY, float InCenterLocZ, float InMaxGravationalSpeed, int64 InGUID, bool InAllowZGravational)
{
	for (int32 i = 0; i < GravationalInfos.Num(); i++)
	{
		if (GravationalInfos[i].GUID == InGUID)
		{
			GravationalInfos[i].bAllowZGravational = InAllowZGravational;
			GravationalInfos[i].CenterLocation.X = InCenterLocX;
			GravationalInfos[i].CenterLocation.Y = InCenterLocY;
			GravationalInfos[i].CenterLocation.Z = InCenterLocZ;
			GravationalInfos[i].MaxGravationalSpeed = InMaxGravationalSpeed;
			return;
		}
	}

	GravationalInfos.Add(GravationalInfo(FVector(InCenterLocX, InCenterLocY, InCenterLocZ), InMaxGravationalSpeed, InGUID, InAllowZGravational));
	SetEnable(true);
}

void GravationalThrusterMC::RemoveGravationalInfo(int64 InGUID)
{
	for (int32 i = GravationalInfos.Num() - 1; i >= 0; i--)
	{
		if (GravationalInfos[i].GUID == InGUID)
		{
			GravationalInfos.RemoveAt(i);

			if (GravationalInfos.IsEmpty())
			{
				SetEnable(false);
			}

			return;
		}
	}
}


#if UE_BUILD_DEVELOPMENT
void GravationalThrusterMC::AppendDebugInfo(FString& infoOut) {
	infoOut.Append(TEXT("====================GravationalThrusterMC==============\n"));
	for (int32 i = 0; i < GravationalInfos.Num(); i++)
	{
		infoOut.Appendf(TEXT("GUID:%i  CenterLocation:%s  MaxGravationalSpeed:%f  bAllowZGravational:%s\n"), GravationalInfos[i].GUID, 
			*GravationalInfos[i].CenterLocation.ToString(), GravationalInfos[i].MaxGravationalSpeed, GravationalInfos[i].bAllowZGravational ? TEXT("true") : TEXT("false"));
	}
}

#endif