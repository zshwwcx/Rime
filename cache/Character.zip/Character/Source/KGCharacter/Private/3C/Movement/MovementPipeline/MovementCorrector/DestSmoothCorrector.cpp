// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Movement/MovementPipeline/MovementCorrector/DestSmoothCorrector.h"
#include "3C/Movement/MovementPipeline/MovementContext.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "Misc/MathFormula.h"
#include "Kismet/KismetSystemLibrary.h"
UE_DISABLE_OPTIMIZATION
FDestSmoothCorrector::FDestSmoothCorrector()
{
}

FDestSmoothCorrector::~FDestSmoothCorrector()
{
}

void FDestSmoothCorrector::Init(MovementContext* MC)
{
}

void FDestSmoothCorrector::Reset(MovementContext* MC)
{
	bHasLocationSmooth = false;
	bHasRotationSmooth = false;
	bDestInTargetActorSpace = false;
	
	CurSmoothTime = 0.0;
	HalfTime = 0.1;
}

void FDestSmoothCorrector::SetDestLocSmoothParam(const FVector InStartPos, const FVector InEndPos)
{
	bHasLocationSmooth = true;

	StartPos = InStartPos;
	DestPos = InEndPos;
}

void FDestSmoothCorrector::SetDestRotSmoothParam(float InStartYaw, float InEndYaw)
{
	bHasRotationSmooth = true;

	StartYaw = InStartYaw;
	DestYaw = InEndYaw;
}

void FDestSmoothCorrector::SetSmoothCorrectorType(ESmoothCorrectorType Type, float Speed)
{
	SmoothCorrectorType = Type;
	CurRunSpeed = Speed;
}

void FDestSmoothCorrector::SetDestTargetActor(AActor* InTargetActor)
{
	bDestInTargetActorSpace = true;
	
	TargetActor = InTargetActor;
	
	if (bHasRotationSmooth)
	{
		StartPosInActorSpace = StartPos;
		DestPosInActorSpace = DestPos;
	}

	if (bHasLocationSmooth)
	{
		StartRotationInActorSpace = FRotator(0, StartYaw, 0).Quaternion();
		DestRotationInActorSpace = FRotator(0, DestYaw, 0).Quaternion();
	}
}

void FDestSmoothCorrector::UpdateDestPosAndRotInActorSpace()
{
	if (TargetActor.IsValid())
	{
		FTransform TargetActorTransform = TargetActor->GetActorTransform();
		if (bHasLocationSmooth)
		{
			DestPos = TargetActorTransform.TransformPosition(DestPosInActorSpace);
			StartPos = TargetActorTransform.TransformPosition(StartPosInActorSpace);
		}
		
		if (bHasRotationSmooth)
		{
			DestYaw = TargetActorTransform.TransformRotation(DestRotationInActorSpace).Rotator().Yaw;
			StartYaw = TargetActorTransform.TransformRotation(StartRotationInActorSpace).Rotator().Yaw;
		}
	}

}

bool FDestSmoothCorrector::DoMovementCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
{
	if (CurSmoothTime > SmoothTime || (!bHasLocationSmooth && !bHasRotationSmooth))
	{
		return false;
	}
	else if (CurSmoothTime + DeltaTime >= SmoothTime)
	{
		if (bDestInTargetActorSpace)
		{
			UpdateDestPosAndRotInActorSpace();
		}
		
		FTransform ActorTransform = MC.GetCurrentActorTransform();

		if (bHasLocationSmooth)
		{
			// UE_LOG(LogTemp, Warning, TEXT("[szk]FDestSmoothCorrector, OccupyAbsoluteWorldPos1:%s"), *DestPos.ToString());
			MC.ClearAbsoluteWorldPos();
			MC.ClearAccumulateWorldPosDelta();
			MC.AccumulateWorldPosDelta(DestPos - ActorTransform.GetTranslation());
		}

		if (bHasRotationSmooth)
		{
			MC.ClearAbsoluteWorldRot();
			MC.ClearAccumulateLocalRotDelta();
			MC.OccupyAbsoluteWorldRot(FRotator(0.0f, DestYaw, 0.0f).Quaternion());
		}

		MC.SetFinishedCorrectorType(EMovementCorrectorType::DestSmoothCorrector);
	}
	else
	{
		if (bDestInTargetActorSpace)
		{
			UpdateDestPosAndRotInActorSpace();
		}
		
		FTransform ActorTransform = MC.GetCurrentActorTransform();
		if (bHasLocationSmooth)
		{
			FVector OriginFinalLoc = MC.GetFinalWorldPosDelta(ActorTransform.GetRotation()) + ActorTransform.GetTranslation();
			
			if ((DestPos - StartPos).IsNearlyZero())
			{
				// 理论上DestPos和StartPos不应该一样，这里保底处理
				FVector ExpectFinalLoc = FVector();
				MathFormula::DecayValue(ExpectFinalLoc, OriginFinalLoc, DestPos, HalfTime, CurSmoothTime);

				// UE_LOG(LogTemp, Warning, TEXT("[szk]FDestSmoothCorrector, OccupyAbsoluteWorldPos3:%s"), *ExpectFinalLoc.ToString());
				MC.ClearAbsoluteWorldPos();
				MC.ClearAccumulateWorldPosDelta();
				MC.AccumulateWorldPosDelta(ExpectFinalLoc - ActorTransform.GetTranslation());
			}
			else
			{
				FVector AbsoluteWorldPosDelta = MC.GetFinalWorldPosDelta(ActorTransform.GetRotation());
				if (SmoothCorrectorType == ESmoothCorrectorType::HalfTimeSmooth)
				{
					FVector StartToDesNorm = (DestPos - StartPos).GetSafeNormal();
					float ImpectValue = (OriginFinalLoc - StartPos).Dot(StartToDesNorm);
					if (ImpectValue < 0.0f)
					{
						OriginFinalLoc -= StartToDesNorm * ImpectValue;
					}
					else
					{
						ImpectValue = (OriginFinalLoc - DestPos).Dot(StartToDesNorm);
						if (ImpectValue > 0.0f)
						{
							OriginFinalLoc -= StartToDesNorm * ImpectValue;
						}
					}
				
					FVector ExpectFinalLoc = FVector();
					MathFormula::DecayValue(ExpectFinalLoc, StartPos, DestPos, HalfTime, CurSmoothTime);
					MathFormula::DecayValue(ExpectFinalLoc, OriginFinalLoc, ExpectFinalLoc, HalfTime, CurSmoothTime);
					AbsoluteWorldPosDelta = ExpectFinalLoc - ActorTransform.GetTranslation();
					UE_LOG(LogTemp,Display,TEXT("Dest correrct (%f,%f,%f)"), AbsoluteWorldPosDelta.X, AbsoluteWorldPosDelta.Y,  AbsoluteWorldPosDelta.Z)
				}
				else if (SmoothCorrectorType == ESmoothCorrectorType::TimeAlphaSmooth && SmoothTime > 0)
				{
					const float Alpha = FMath::Clamp(CurSmoothTime / SmoothTime, 0, 1);
					const float Distance = CurRunSpeed * (1 - Alpha) * DeltaTime;
					const float MaxDistance = FVector::Distance(StartPos, DestPos);
					const float UsedAlpha = Distance / FMath::Max(1, MaxDistance);
					
					AbsoluteWorldPosDelta = FMath::Lerp(StartPos, DestPos, UsedAlpha) - StartPos;
				}
				
				// OriginFinalLoc在StartPos到DestPos线段的投影应该控制在线段内，否则可能会有来回拖拽的不好表现
				

				// UE_LOG(LogTemp, Warning, TEXT("[szk]FDestSmoothCorrector, OccupyAbsoluteWorldPos2:%s"), *ExpectFinalLoc.ToString());
				MC.ClearAbsoluteWorldPos();
				MC.ClearAccumulateWorldPosDelta();
				MC.AccumulateWorldPosDelta(AbsoluteWorldPosDelta);
			}
		}
		
		if (bHasRotationSmooth)
		{
			FQuat OriginFinalRot = MC.GetFinalWorldRot(ActorTransform.GetRotation());
			float ExpectFinalYaw = MathFormula::DecayValue(ActorTransform.GetRotation().Rotator().Yaw, DestYaw, HalfTime, DeltaTime);

			MC.ClearAbsoluteWorldRot();
			MC.ClearAccumulateLocalRotDelta();
			MC.OccupyAbsoluteWorldRot(FRotator(0.0f, ExpectFinalYaw, 0.0f).Quaternion());
		}
	}

	CurSmoothTime += DeltaTime;

	return true;
}

#if UE_BUILD_DEVELOPMENT
void FDestSmoothCorrector::AppendDebugInfo(FString& infoOut)
{
	infoOut.Append(TEXT("===================<Title_Blue>FDestSmoothCorrector</>===================\n"));
	infoOut.Appendf(TEXT("bHasLocationSmooth:%d  StartPos:%s  DestPos:%s  bHasRotationSmooth:%d  StartYaw:%f  DestYaw:%f\n")
		, bHasLocationSmooth, *(StartPos.ToString()), *(DestPos.ToString()), bHasRotationSmooth, StartYaw, DestYaw);
	infoOut.Appendf(TEXT("SmoothTime:%f  CurSmoothTime:%f  HalfTime:%f\n")
		, SmoothTime, CurSmoothTime, HalfTime);
}
#endif

UE_ENABLE_OPTIMIZATION