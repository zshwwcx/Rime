// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Movement/MovementPipeline/MovementCorrector/OnWaterMovementCorrector.h"

#include "3C/Character/BaseCharacter.h"
#include  "3C/Movement/RoleMovementComponent.h"
#include "Misc/MathFormula.h"

FOnWaterMovementCorrector::FOnWaterMovementCorrector()
{
}

FOnWaterMovementCorrector::~FOnWaterMovementCorrector()
{
}

void FOnWaterMovementCorrector::Init(MovementContext* MC)
{
	bIsWaterMoveDisableOnGroundLocoState = true;
}

void FOnWaterMovementCorrector::Reset(MovementContext* MC)
{
	bIsWaterMoveDisableOnGroundLocoState = true;

	// 初始化时更新CurWaterSurfaceDelta到预期WaterSurfaceDelta，
	// 并且设置离水面状态，由下一帧计算决定是否贴水面
	CurWaterSurfaceDelta = WaterSurfaceDelta;
	bIsStickWaterSurface = false;
}

bool FOnWaterMovementCorrector::DoMovementCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
{
	bool OldbIsWaterMoveDisableOnGroundLocoState = bIsWaterMoveDisableOnGroundLocoState;
	bIsWaterMoveDisableOnGroundLocoState = MovementComponent.GetIsWaterMoveDisableOnGroundLocoState(MovementComponent.GetLocalLocomotionState());

	CurWaterSurfaceDelta = MathFormula::LinearCloseToDst(CurWaterSurfaceDelta, WaterSurfaceDelta, WaterSurfaceDeltaChangeSpeed, DeltaTime);

	if (bIsWaterMoveDisableOnGroundLocoState != OldbIsWaterMoveDisableOnGroundLocoState)
	{
		FOnGroundMovementCorrector::Reset(&MC);
	}

	if (!bIsWaterMoveDisableOnGroundLocoState)
	{
		// 不是禁用OnGround的WaterMove状态，则需要执行基类FOnGroundMovementCorrector逻辑
		 FOnGroundMovementCorrector::DoMovementCorrection(MovementComponent, MC, DeltaTime);
	}

	if (MovementComponent.GetIsWaterDetected())
	{
		float CurDistToWaterSurface = MovementComponent.GetCurDistToWaterSurface();
		// 这里会计算已有的WorldPosDelta，叠加预计算的重力速度
		FVector WorldMovementDelta = MC.GetWorldPosDelta() + MovementComponent.PreCalculateGravity(DeltaTime);
		float ZVelocity = DeltaTime > 0.0f ? WorldMovementDelta.Z / DeltaTime : WorldMovementDelta.Z;
		bool bNeedLeaveWaterSurface = ZVelocity > MovementComponent.GetEnterFallingVelocityZ();
		bool bNeedDoStickGroundCalculate = false;

		// 贴近水面移动流程
		if (bIsStickWaterSurface)
		{
			// 需要离开水面
			if (bNeedLeaveWaterSurface)
			{
				bIsStickWaterSurface = false;
			}
			// 贴近水面移动
			else
			{
				bNeedDoStickGroundCalculate = true;
			}
		}
		// 不贴近水面移动流程
		else
		{
			// 重新贴近水面移动
			if (CurDistToWaterSurface < 0.1f || WorldMovementDelta.Z + CurDistToWaterSurface < 0.1f)
			{
				bIsStickWaterSurface = true;
				bNeedDoStickGroundCalculate = true;
			}
		}

		if (bNeedDoStickGroundCalculate)
		{
			WorldMovementDelta.Z = CurWaterSurfaceDelta - CurDistToWaterSurface;
			MC.SetWorldPosDelta(WorldMovementDelta);

			// 这一帧应用了PreCalculate的GravityVelocity，需要关闭当帧的重力计算
			MC.IncreaseIgnoreGravity();
			// GroundSupportCount的控制需要由FOnWaterMovementCorrector自身去控制
			MC.IncreaseHasForceGroundSupportCount();
			MC.IncreaseHasForceLocoGroundSupportCount();
		}
	}

	return true;
}

void FOnWaterMovementCorrector::SetWaterSurfaceDelta(const float& InDelta, const float& InDuration)
{
	WaterSurfaceDelta = InDelta;

	if (CurWaterSurfaceDelta >= WaterSurfaceDelta)
	{
		// 水平面降低
		WaterSurfaceDeltaChangeSpeed = (CurWaterSurfaceDelta - WaterSurfaceDelta) / FMath::Max(0.01f, InDuration);
	}
	else
	{
		// 水平面升高
		WaterSurfaceDeltaChangeSpeed = (WaterSurfaceDelta - CurWaterSurfaceDelta) / FMath::Max(0.01f, InDuration);
	}
}





#if UE_BUILD_DEVELOPMENT
void FOnWaterMovementCorrector::AppendDebugInfo(FString& infoOut)
{
	infoOut.Append(TEXT("===================<Title_Blue>FOnWaterMovementCorrector</>===================\n"));
	infoOut.Appendf(TEXT("MovementDeltaScaleRatio:%f\n"), MovementDeltaScaleRatio);
	infoOut.Appendf(TEXT("bLastInputYawValid:%d  LastInputYaw:%f\n"), bLastInputYawValid, LastInputYaw);
	infoOut.Appendf(TEXT("bIsWaterMoveDisableOnGroundLocoState:%d\n"), bIsWaterMoveDisableOnGroundLocoState);
	infoOut.Appendf(TEXT("CurWaterSurfaceDelta:%f WaterSurfaceDelta:%f\n"), CurWaterSurfaceDelta, WaterSurfaceDelta);
	infoOut.Appendf(TEXT("bIsStickWaterSurface:%d\n"), bIsStickWaterSurface);
}
#endif