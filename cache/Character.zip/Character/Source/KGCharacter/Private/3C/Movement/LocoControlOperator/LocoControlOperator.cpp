#include "3C/Movement/LocoControlOperator/LocoControlOperator.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Character/BaseCharacter.h"


TMap<int32, FLocoControlInfoDetails> LocoControlOperator::StaticDefaultTemplateInitData = TMap<int32, FLocoControlInfoDetails>();
TMap<int32, FLocoControlInfoDetails> LocoControlOperator::StaticDefaultTemplateUpdateData = TMap<int32, FLocoControlInfoDetails>();
TMap<int32, FUpperControlLogicIDInfo> LocoControlOperator::StaticUpperControlLogicUpdateData = TMap<int32, FUpperControlLogicIDInfo>();
TArray<FString> LocoControlOperator::InitTitleListForLua = TArray<FString>();
TArray<FString> LocoControlOperator::UpdateTitleListForLua = TArray<FString>();
FString LocoControlOperator::LocoControlTag = TEXT("LocoControlOperator");

TMap<FString, bool(LocoControlOperator::*)(float)> LocoControlOperator::InitTitleToFuncMapForC = TMap<FString, bool(LocoControlOperator::*)(float)>{
	{TEXT("LocoStateDataSource"), &LocoControlOperator::InitLocoStateDataSource},
	{TEXT("ClientMoveSyncRole"), &LocoControlOperator::InitClientMoveSyncRole},
	{TEXT("BornTrackFloorTime"), &LocoControlOperator::InitBornTrackFloorTime}
};
TMap<FString, bool(LocoControlOperator::*)(float, float)> LocoControlOperator::UpdateTitleToFuncMapForC = TMap<FString, bool(LocoControlOperator::*)(float, float)>{
	{TEXT("InputSemantic"), &LocoControlOperator::UpdateInputSemantic},
	{TEXT("IsIgnorePhysFixup"), &LocoControlOperator::UpdateSetIsIgnorePhysFixup},
	{TEXT("HasForceLocoGroundSupport"), &LocoControlOperator::UpdateHasForceLocoGroundSupport},
	{TEXT("HasForceGroundSupport"), &LocoControlOperator::UpdateHasForceGroundSupport},
	{TEXT("HasRootMotionSourceForceGround"), &LocoControlOperator::UpdateHasRootMotionSourceForceGround},
	{TEXT("NeedSyncUpMovement"), &LocoControlOperator::UpdateNeedSyncUpMovement},
	{TEXT("IsForbiddenInputZoneChangeMovePosture"), &LocoControlOperator::ForbiddenInputZoneChangeMovePosture},
	{TEXT("DisableAnimNodeCal"), &LocoControlOperator::DisableAnimNodeCal},
	{TEXT("IsAutoUpdatePostureAndPlayRate"), &LocoControlOperator::UpdateIsAutoUpdatePostureAndPlayRate},
	{TEXT("HasCollisionDisable"), &LocoControlOperator::UpdateHasCollisionDisable},
	{TEXT("DisableMoveTurn"), &LocoControlOperator::DisableMoveTurn},
	{TEXT("RootmotionModeSource"), &LocoControlOperator::UpdateRootmotionModeSource},
	{TEXT("HasLocoInputThrusterDisable"), &LocoControlOperator::UpdateHasLocoInputThrusterDisable},
	{TEXT("IsFrameStickToGround"), &LocoControlOperator::UpdateIsFrameStickToGround},
	{TEXT("IsGravityOff"), &LocoControlOperator::UpdateIsGravityOff},
	{TEXT("HasMoveAllDisable"), &LocoControlOperator::UpdateHasMoveAllDisable},
	{TEXT("HasRotateAllDisable"), &LocoControlOperator::UpdateHasRotateAllDisable},
	{TEXT("HasLocoJumpDisable"), &LocoControlOperator::UpdateHasLocoJumpDisable},
	{TEXT("HasLocoDodgeDisable"), &LocoControlOperator::UpdateHasLocoDodgeDisable},
	{TEXT("HasLocoMoveDisable"), &LocoControlOperator::UpdateHasLocoMoveDisable},
	{TEXT("HasLocoRotateDisable"), &LocoControlOperator::UpdateHasLocoRotateDisable},
	{TEXT("HasLocoStartDisable"), &LocoControlOperator::UpdateHasLocoStartDisable},
	{TEXT("IsForbiddenMoveCorrector"), &LocoControlOperator::ForbiddenMoveCorrector},
	{TEXT("MoveDriveMode"), &LocoControlOperator::UpdateMoveDriveMode},	
};
void LocoControlOperator::UpdateLocoControlStaticData(const TMap<int32, FLocoControlInfoDetails>& InStaticDefaultTemplateInitData, const TMap<int32, FLocoControlInfoDetails>& InStaticDefaultTemplateUpdateData,
	const TMap<int32, FUpperControlLogicIDInfo>& InStaticUpperControlLogicUpdateData, const TArray<FString>& InInitTitleListForLua, const TArray<FString>& InUpdateTitleListForLua)
{
	// 静态表格数据
	StaticDefaultTemplateInitData = InStaticDefaultTemplateInitData;
	StaticDefaultTemplateUpdateData = InStaticDefaultTemplateUpdateData;
	StaticUpperControlLogicUpdateData = InStaticUpperControlLogicUpdateData;
	InitTitleListForLua = InInitTitleListForLua;
	UpdateTitleListForLua = InUpdateTitleListForLua;
}

void LocoControlOperator::InitLocoControlOperator(URoleMovementComponent* InOwnerMoveComp)
{
	OwnerMoveComp = InOwnerMoveComp;
	DefaultTemplateID.Reset();
}

void LocoControlOperator::InitNeededScriptData(bool InNeedBornStickGround)
{
	bNeedBornStickGround = InNeedBornStickGround;
}

bool LocoControlOperator::DoUpperControlLogic(int32 InUpperContolLogicID)
{
	if (bIsExcecutingUpperControlLogic) {
		// 正在执行其他UpperLogic，加入Pending
		PendingUpperControlLogicIDList.Add(FPendingUpperControlLogicIDInfo(InUpperContolLogicID, true));
		return true;
	}

	if (!StaticUpperControlLogicUpdateData.Contains(InUpperContolLogicID))
	{
		UE_LOG(LogTemp, Warning, TEXT("LocoControlOperator DoUpperControlLogic Error! No Info For UpperContolLogicID %i"), InUpperContolLogicID);
		return false;
	}

	if (!DefaultTemplateID.IsSet())
	{
		if (CachedUpperControlLogicIDList.Contains(InUpperContolLogicID))
		{
			UE_LOG(LogTemp, Warning, TEXT("LocoControlOperator DoUpperControlLogic Error! Already Activated UpperContolLogicID %i"), InUpperContolLogicID);
			return false;
		}

		CachedUpperControlLogicIDList.Add(InUpperContolLogicID);
		return true;
	}

	for (const TPair<int32, int32>& SingleInfo : UpperControlLogicIDList)
	{
		if (SingleInfo.Key == InUpperContolLogicID)
		{
			UE_LOG(LogTemp, Warning, TEXT("LocoControlOperator DoUpperControlLogic Error! Already Activated UpperContolLogicID %i"), InUpperContolLogicID);
			return false;
		}
	}

	bIsExcecutingUpperControlLogic = true;
	const FUpperControlLogicIDInfo& UpperControlLogicInfoTodo = *StaticUpperControlLogicUpdateData.Find(InUpperContolLogicID);
	for (int32 i = 0; i < UpperControlLogicIDList.Num(); i++)
	{
		if (UpperControlLogicInfoTodo.Priority <= UpperControlLogicIDList[i].Value)
		{
			// 找到小于等于的Priority，直接插入队列
			UpperControlLogicIDList.Insert(TPair<int32, int32>(UpperControlLogicInfoTodo.ID, UpperControlLogicInfoTodo.Priority), i);
			bool OutRes = InnerUpdateLocoControl();

			bIsExcecutingUpperControlLogic = false;
			CheckPendingUpperControlLogic();
			return OutRes;
		}
	}

	// 找不到小于等于的Priority，直接插入队尾
	UpperControlLogicIDList.Add(TPair<int32, int32>(UpperControlLogicInfoTodo.ID, UpperControlLogicInfoTodo.Priority));
	bool OutRes = InnerUpdateLocoControl();

	bIsExcecutingUpperControlLogic = false;
	CheckPendingUpperControlLogic();
	return OutRes;
}

bool LocoControlOperator::UnDoUpperControlLogic(int32 InUpperContolLogicID)
{
	if (bIsExcecutingUpperControlLogic) {
		// 正在执行其他UpperLogic，加入Pending
		PendingUpperControlLogicIDList.Add(FPendingUpperControlLogicIDInfo(InUpperContolLogicID, false));
		return true;
	}

	if (!StaticUpperControlLogicUpdateData.Contains(InUpperContolLogicID))
	{
		UE_LOG(LogTemp, Warning, TEXT("LocoControlOperator UnDoUpperControlLogic Error! No Info For UpperContolLogicID %i"), InUpperContolLogicID);
		return false;
	}

	if (!DefaultTemplateID.IsSet())
	{
		if (!CachedUpperControlLogicIDList.Contains(InUpperContolLogicID))
		{
			UE_LOG(LogTemp, Warning, TEXT("LocoControlOperator UnDoUpperControlLogic Error! NonActivated UpperContolLogicID %i"), InUpperContolLogicID);
			return false;
		}

		CachedUpperControlLogicIDList.Remove(InUpperContolLogicID);
		return true;
	}

	bool AllowUndo = false;
	for (const TPair<int32, int32>& SingleInfo : UpperControlLogicIDList)
	{
		if (SingleInfo.Key == InUpperContolLogicID)
		{
			AllowUndo = true;
			break;
		}
	}
	if (!AllowUndo) 
	{
		UE_LOG(LogTemp, Warning, TEXT("LocoControlOperator UnDoUpperControlLogic Error! NonActivated UpperContolLogicID %i"), InUpperContolLogicID);
		return false;
	}
	
	bIsExcecutingUpperControlLogic = true;
	const FUpperControlLogicIDInfo& UpperControlLogicInfoTodo = *StaticUpperControlLogicUpdateData.Find(InUpperContolLogicID);
	for (int32 i = 0; i < UpperControlLogicIDList.Num(); i++)
	{
		if (UpperControlLogicInfoTodo.ID == UpperControlLogicIDList[i].Key)
		{
			UpperControlLogicIDList.RemoveAt(i);
			bool OutRes = InnerUpdateLocoControl();

			bIsExcecutingUpperControlLogic = false;
			CheckPendingUpperControlLogic();
			return OutRes;
		}
	}

	// 不应该走到这里
	bIsExcecutingUpperControlLogic = false;
	UE_LOG(LogTemp, Warning, TEXT("LocoControlOperator UnDoUpperControlLogic Error! UnExpected Here2 %i"), InUpperContolLogicID);
	return false;
}

bool LocoControlOperator::InnerDoInitFunc(const FString& InTitle, const float& InValue, TArray<FLocoControlInfoForLua>& OutKCBLuaStruct)
{
	if (InitTitleToFuncMapForC.Contains(InTitle))
	{
		// C++可以执行的内容，直接在C++执行
		bool(LocoControlOperator:: * Func)(float) = *InitTitleToFuncMapForC.Find(InTitle);
		if ((this->*Func)(InValue)) 
		{
			InnerUpdateEffectedLocoControlParamInfo(InTitle, InValue);
			return true;
		}
		else 
		{
			return false;
		}
	}
	else if(InitTitleListForLua.Contains(InTitle))
	{
		// C++无法执行的内容，存储信息后抛回脚本执行
		OutKCBLuaStruct.Add(FLocoControlInfoForLua(InTitle, InValue, -1));
		InnerUpdateEffectedLocoControlParamInfo(InTitle, InValue);

		return true;
	}

	return false;
}

bool LocoControlOperator::InnerDoUpdateFunc(const FString& InTitle, const float& InOldValue, const float& InNewValue, TArray<FLocoControlInfoForLua>& OutKCBLuaStruct)
{
	if (UpdateTitleToFuncMapForC.Contains(InTitle))
	{
		// C++可以执行的内容，直接在C++执行
		bool(LocoControlOperator:: * Func)(float, float) = *UpdateTitleToFuncMapForC.Find(InTitle);
		if ((this->*Func)(InOldValue, InNewValue)) {
			InnerUpdateEffectedLocoControlParamInfo(InTitle, InNewValue);
			return true;
		}
		else {
			return false;
		}
	}
	else if (UpdateTitleListForLua.Contains(InTitle))
	{
		// C++无法执行的内容，存储信息后抛回脚本执行
		OutKCBLuaStruct.Add(FLocoControlInfoForLua(InTitle, InNewValue, InOldValue));
		InnerUpdateEffectedLocoControlParamInfo(InTitle, InNewValue);

		return true;
	}

	return false;
}

void LocoControlOperator::InnerUpdateEffectedLocoControlParamInfo(const FString& InTitle, const float& InNewValue)
{
	if (InNewValue >= 0)
	{
		if (EffectedLocoControlParamInfo.InfoMap.Contains(InTitle)){
			EffectedLocoControlParamInfo.InfoMap[InTitle] = InNewValue;
		}
		else{
			EffectedLocoControlParamInfo.InfoMap.Add(InTitle, InNewValue);
		}
	}
	else
	{
		if (EffectedLocoControlParamInfo.InfoMap.Contains(InTitle)){
			EffectedLocoControlParamInfo.InfoMap.Remove(InTitle);
		}
	}
}

bool LocoControlOperator::InitDefaultTemplateID(int32 InDefaultTemplateID)
{
	if (!StaticDefaultTemplateInitData.Contains(InDefaultTemplateID) || !StaticDefaultTemplateUpdateData.Contains(InDefaultTemplateID)) {
		UE_LOG(LogTemp, Warning, TEXT("LocoControlOperator::InitDefaultTemplateID, InValid DefaultTemplateID:%i"), InDefaultTemplateID);
		return false;
	}

	DefaultTemplateID.Reset();
	UpperControlLogicIDList.Empty();
	EffectedLocoControlParamInfo.InfoMap.Empty();
	PendingUpperControlLogicIDList.Empty();

	TArray<FLocoControlInfoForLua> KCBLuaStruct = {};

	// 执行初始化函数(DefaultTemplate中蓝色列)
	const FLocoControlInfoDetails* SingleDefaultTemplateInitData = StaticDefaultTemplateInitData.Find(InDefaultTemplateID);
	for (const TPair<FString, float>& SingleInfo : SingleDefaultTemplateInitData->InfoMap)
	{
		InnerDoInitFunc(SingleInfo.Key, SingleInfo.Value, KCBLuaStruct);
	}

	const FLocoControlInfoDetails* SingleDefaultTemplateUpdateData = StaticDefaultTemplateUpdateData.Find(InDefaultTemplateID);
	for (const TPair<FString, float>& SingleInfo : SingleDefaultTemplateUpdateData->InfoMap)
	{
		InnerDoUpdateFunc(SingleInfo.Key, -1, SingleInfo.Value, KCBLuaStruct);
	}

	DefaultTemplateID = InDefaultTemplateID;

	if (!KCBLuaStruct.IsEmpty()) {
		// 抛回脚本执行逻辑
		DoLocoControlLogicInLua(KCBLuaStruct);
	}

	if (!CachedUpperControlLogicIDList.IsEmpty()){
		for (const int32& CachedID : CachedUpperControlLogicIDList) {
			DoUpperControlLogic(CachedID);
		}
		CachedUpperControlLogicIDList.Empty();
	}
	
	return true;
}

bool LocoControlOperator::InnerUpdateLocoControl()
{
	if (!DefaultTemplateID.IsSet() || !StaticDefaultTemplateInitData.Contains(DefaultTemplateID.GetValue()) || !StaticDefaultTemplateUpdateData.Contains(DefaultTemplateID.GetValue())) {
		UE_LOG(LogTemp, Warning, TEXT("LocoControlOperator InnerUpdateLocoControl DefautTemplateID Error! DefautTemplateID :%i"),
			DefaultTemplateID.IsSet() ? DefaultTemplateID.GetValue() : -1);
		return false;
	}
	const FLocoControlInfoDetails& DefaultTemplateUpdateInfo = *StaticDefaultTemplateUpdateData.Find(DefaultTemplateID.GetValue());

	TArray<FString> CalculatedTitles = {};
	TArray<FLocoControlInfoForLua> KCBLuaStruct = {};

	// 遍历所有激活的UpperControlLogicID
	for (const TPair<int32, int32>& SingleUpperControlLogicIDInfo : UpperControlLogicIDList)
	{
		// 拿到对应UpperControlLogicID的信息
		if (const FUpperControlLogicIDInfo* Info = StaticUpperControlLogicUpdateData.Find(SingleUpperControlLogicIDInfo.Key))
		{
			// 遍历对应信息中的有效词条
			for (const TPair<FString, float>& TitleToValue : Info->ControlInfo.InfoMap)
			{
				// 如果该词条已经在更高优先级中计算过，忽视
				if (!CalculatedTitles.Contains(TitleToValue.Key))
				{
					float OldValue = EffectedLocoControlParamInfo.InfoMap.Contains(TitleToValue.Key) ? *EffectedLocoControlParamInfo.InfoMap.Find(TitleToValue.Key) : -1;
					float NewValue = TitleToValue.Value;
					if (NewValue != OldValue) {
						InnerDoUpdateFunc(TitleToValue.Key, OldValue, NewValue, KCBLuaStruct);
					}
					CalculatedTitles.Add(TitleToValue.Key);
				}
			}
		}
	}

	// 再遍历一下DefaultTemplate中的Update参数
	for (const TPair<FString, float>& TitleToValue : DefaultTemplateUpdateInfo.InfoMap)
	{
		// 如果该词条已经在更高优先级中计算过，忽视
		if (!CalculatedTitles.Contains(TitleToValue.Key))
		{
			float OldValue = EffectedLocoControlParamInfo.InfoMap.Contains(TitleToValue.Key) ? *EffectedLocoControlParamInfo.InfoMap.Find(TitleToValue.Key) : -1;
			float NewValue = TitleToValue.Value;
			if (NewValue != OldValue) {
				InnerDoUpdateFunc(TitleToValue.Key, OldValue, NewValue, KCBLuaStruct);
			}
			CalculatedTitles.Add(TitleToValue.Key);
		}
	}

	// 再遍历一下EffectedLocoControlParamInfo，是否有需要取消的参数
	TArray<TPair<FString, float>> ToDeleteUpperConrolList;
	for (const TPair<FString, float>& TitleToValue : EffectedLocoControlParamInfo.InfoMap)
	{
		// 如果有词条没有计算过，需要取消
		if (!CalculatedTitles.Contains(TitleToValue.Key))
		{
			ToDeleteUpperConrolList.Add(TPair<FString, float>(TitleToValue.Key, TitleToValue.Value));
		}
	}
	for (const TPair<FString, float>& TitleToOldValue : ToDeleteUpperConrolList)
	{
		InnerDoUpdateFunc(TitleToOldValue.Key, TitleToOldValue.Value, -1, KCBLuaStruct);
	}

	if (!KCBLuaStruct.IsEmpty()) {
		// 抛回脚本执行逻辑
		DoLocoControlLogicInLua(KCBLuaStruct);
	}
	
	return true;
}

void LocoControlOperator::CheckPendingUpperControlLogic()
{
	for (const FPendingUpperControlLogicIDInfo& SingleUpperInfo : PendingUpperControlLogicIDList)
	{
		if (SingleUpperInfo.bAddOrRemove) {
			DoUpperControlLogic(SingleUpperInfo.ID);
		}
		else {
			UnDoUpperControlLogic(SingleUpperInfo.ID);
		}
	}
	PendingUpperControlLogicIDList.Empty();
}

void LocoControlOperator::DoLocoControlLogicInLua(const TArray<FLocoControlInfoForLua>& InLocoControlInfosForLua)
{
	if (!OwnerMoveComp.IsValid()) {
		return;
	}

	if (ABaseCharacter* Character = Cast<ABaseCharacter>(OwnerMoveComp->GetCharacterOwner()))
	{
		ACTOR_CALL_LUA_ENTITY(Character, "KCB_DoLocoControlLogicInLua", InLocoControlInfosForLua);
	}
}

bool LocoControlOperator::InitLocoStateDataSource(float InValue)
{
	if (!OwnerMoveComp.IsValid()){
		return false;
	}

	OwnerMoveComp->SetLocoStateDataSource(ELocoStateDataSource(InValue));
	return true;
}

bool LocoControlOperator::InitClientMoveSyncRole(float InValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetClientMoveSyncRole(EMoveSyncRole(InValue));
	return true;
}

bool LocoControlOperator::InitBornTrackFloorTime(float InValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	if (!bNeedBornStickGround || InValue < SMALL_NUMBER)
	{
		OwnerMoveComp->SetNeedBornStickGround(false);
		OwnerMoveComp->SetTrackFloorDisableMoveMaxTime(0.0);
		return true;
	}

	OwnerMoveComp->SetNeedBornStickGround(true);
	OwnerMoveComp->SetTrackFloorDisableMoveMaxTime(InValue);
	return true;
}

bool LocoControlOperator::UpdateInputSemantic(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	if (InNewValue >= 0) {
		OwnerMoveComp->SetLocoInputSemantic(ELocoInputSemantic(InNewValue));
	}
	else {
		// todo 这里有设置问题, 如果default为 - 1, 可能会把之前的默认给冲掉, 需要所有控制进control; 现在先处理成c++的默认值
		OwnerMoveComp->SetLocoInputSemantic(ELocoInputSemantic::OnGroundSemantic);
	}

	return true;
}

// todo 这一批接口有问题, 因为没有处理InOldValue, 可能会导致控制被冲掉丢失的问题 @施政恺
bool LocoControlOperator::UpdateSetIsIgnorePhysFixup(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetIsIgnorePhysFixup(InNewValue > 0);
	return true;
}

bool LocoControlOperator::UpdateHasForceLocoGroundSupport(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetHasForceLocoGroundSupport(TEXT("LocoControlOperator"), InNewValue > 0);
	return true;
}

bool LocoControlOperator::UpdateHasForceGroundSupport(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetHasForceGroundSupport(TEXT("LocoControlOperator"), InNewValue > 0);
	return true;
}

bool LocoControlOperator::UpdateHasRootMotionSourceForceGround(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetIsRootMotionSourceForceGroundSupport(InNewValue > 0);
	return true;
}

bool LocoControlOperator::UpdateNeedSyncUpMovement(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetIsNeedSyncUpMovement(InNewValue > 0);
	return true;
}

bool LocoControlOperator::ForbiddenInputZoneChangeMovePosture(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetNeedNotifyLocoInputZoneChanged(!(InNewValue > 0));
	return true;
}

bool LocoControlOperator::DisableAnimNodeCal(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	if (UBaseAnimInstance* AnimInst = OwnerMoveComp->GetAnimInstanceForMovement())
	{
		AnimInst->SetIsSlaveAnimControl(InNewValue > 0);
		return true;
	}
	
	return false;
}

bool LocoControlOperator::UpdateIsAutoUpdatePostureAndPlayRate(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	if (InNewValue > 0)
	{
		OwnerMoveComp->SetAutoUpdatePostureAndPlayRateWeakValue(true, LocoControlTag);
		OwnerMoveComp->ClearAutoUpdatePostureAndPlayRateForceValue(LocoControlTag);
	}
	else
	{
		OwnerMoveComp->SetAutoUpdatePostureAndPlayRateWeakValue(false, LocoControlTag);
		if (InNewValue < 0.0)
		{
			// 小于0时，不设置ForceForbidenAutoUpdate
			OwnerMoveComp->ClearAutoUpdatePostureAndPlayRateForceValue(LocoControlTag);
		}
		else
		{
			//  仅仅真正需要关闭时，才设置ForceForbidenAutoUpdate
			OwnerMoveComp->SetAutoUpdatePostureAndPlayRateForceValue(false, LocoControlTag);
		}
	}

	if (UBaseAnimInstance* AnimInst = OwnerMoveComp->GetAnimInstanceForMovement())
	{
		AnimInst->SetAnimMovePostureAndPlayRate(AnimInst->DelayedAnimMovePosture, 1.0f);
	}

	return true;
}

bool LocoControlOperator::UpdateHasCollisionDisable(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	if (!OwnerMoveComp->GetIsMainPlayer()) {
		// 暂时只对主角做碰撞处理, 服务器 NPC & P3玩家 自身无碰撞
		return true;
	}

	if (UPrimitiveComponent* RootComponent = Cast<UPrimitiveComponent>(OwnerMoveComp->UpdatedComponent))
	{
		if (InNewValue > 0){
			RootComponent->SetCollisionResponseToChannel(ECC_WorldStatic, ECollisionResponse::ECR_Ignore);
		}
		else {
			RootComponent->SetCollisionResponseToChannel(ECC_WorldStatic, ECollisionResponse::ECR_Block);
		}
	}

	return true;
}

bool LocoControlOperator::DisableMoveTurn(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetDisableMoveTurnWeakValue(InNewValue > 0, LocoControlTag);

	return true;
}

bool LocoControlOperator::UpdateRootmotionModeSource(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetRootmotionModeWeakValue(InNewValue >= 0 ? static_cast<ERootMotionMode::Type>(InNewValue) : ERootMotionMode::IgnoreRootMotion, LocoControlTag);
	return true;
}

bool LocoControlOperator::UpdateHasLocoInputThrusterDisable(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	if (InNewValue > 0) {
		OwnerMoveComp->SetLocoInputThrusterForceValue(false, LocoControlTag, -1, -1, -1);
	}
	else {
		OwnerMoveComp->ClearLocoInputThrusterForceValue(LocoControlTag);
	}
	return true;
}

bool LocoControlOperator::UpdateIsFrameStickToGround(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetNeedFrameStickGroundWeakValue(InNewValue > 0, LocoControlTag);
	return true;
}

bool LocoControlOperator::UpdateIsGravityOff(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetIsGravityOnWeakValue(InNewValue <= 0, LocoControlTag);
	return true;
}

bool LocoControlOperator::UpdateHasMoveAllDisable(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetDisableMoveAllWeakValue(InNewValue > 0, LocoControlTag, true);
	return true;
}

bool LocoControlOperator::UpdateHasRotateAllDisable(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetDisableRotateAllWeakValue(InNewValue > 0, LocoControlTag);
	return true;
}

bool LocoControlOperator::UpdateHasLocoJumpDisable(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetDisableLocoJumpWeakValue(InNewValue > 0, LocoControlTag, true);
	return true;
}

bool LocoControlOperator::UpdateHasLocoDodgeDisable(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetDisableLocoDodgeWeakValue(InNewValue > 0, LocoControlTag, true);
	return true;
}

bool LocoControlOperator::UpdateHasLocoMoveDisable(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetDisableLocoMoveWeakValue(InNewValue > 0, LocoControlTag, true);
	return true;
}

bool LocoControlOperator::UpdateHasLocoRotateDisable(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetDisableLocoRotateWeakValue(InNewValue > 0, LocoControlTag);
	return true;
}

bool LocoControlOperator::UpdateHasLocoStartDisable(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	OwnerMoveComp->SetDisableLocoStartWeakValue(InNewValue > 0, LocoControlTag, true);
	return true;
}

bool LocoControlOperator::ForbiddenMoveCorrector(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	// 这个逻辑不太好处理，触发频率不高，暂时通过回调触发
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(OwnerMoveComp->GetCharacterOwner()))
	{
		ACTOR_CALL_LUA_ENTITY(Character, "KCB_ForbiddenMoveCorrector", InNewValue > 0);
	}

	return true;
}

bool LocoControlOperator::UpdateMoveDriveMode(float InOldValue, float InNewValue)
{
	if (!OwnerMoveComp.IsValid()) {
		return false;
	}

	EMoveDriveMode TargetMoveDriveMode = EMoveDriveMode::NoDrive;
	if (InNewValue > 0) {
		TargetMoveDriveMode = EMoveDriveMode(int(InNewValue));
	}
	OwnerMoveComp->SetMoveDriveModeWeakValue(TargetMoveDriveMode, LocoControlTag);
	return true;
}

#if UE_BUILD_DEVELOPMENT
void LocoControlOperator::AppendDebugInfo(FString& infoOut)
{
	infoOut.Append(TEXT("===================<Title_Blue>LocoControlOperator</>===================\n"));
	infoOut.Appendf(TEXT("DefaultTemplateID:%i\n"), DefaultTemplateID.IsSet() ? DefaultTemplateID.GetValue() : -1);
	infoOut.Append(TEXT("UpperControlLogicIDs: "));
	for (const TPair<int32, int32> &SingleUpperControlLogicInfo : UpperControlLogicIDList)
	{
		infoOut.Appendf(TEXT("%i:%i, "), SingleUpperControlLogicInfo.Key, SingleUpperControlLogicInfo.Value);
	}

	infoOut.Append(TEXT("\nEffectedLocoControlParamInfo: "));
	for (const TPair<FString, float>& SingleEffectedLocoControlParamInfo : EffectedLocoControlParamInfo.InfoMap)
	{
		infoOut.Appendf(TEXT("%s:%f, "), *SingleEffectedLocoControlParamInfo.Key, SingleEffectedLocoControlParamInfo.Value);
	}
	infoOut.Append(TEXT("\n"));
}
#endif