#include "3C/Movement/MovementPipeline/MovementCorrector/OnRideMountMovementCorrector.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Animation/CarrierAnimInstance.h"
#include  "3C/Movement/RoleMovementComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "Misc/MathFormula.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Curves/CurveFloat.h"

FOnRideMountMovementCorrector::FOnRideMountMovementCorrector()
{
}

FOnRideMountMovementCorrector::~FOnRideMountMovementCorrector()
{
}

void FOnRideMountMovementCorrector::Init(MovementContext* MC)
{
}

void FOnRideMountMovementCorrector::Reset(MovementContext* MC)
{
	RidingCorrectInfo.RidingModeMountFrontAngle = 0.0f;
	RidingCorrectInfo.RidingModeMountEndAngle = 0.0f;
	RidingCorrectInfo.DriftForce.Set(0.0f, 0.0f, 0.0f);

	if (MC)
	{
		MC->SetIsBackCar(false);
		MC->SetMountDirYawToActorYawDelta(0.0f);
		if (bIsDriftDecalAttach)
		{
			bIsDriftDecalAttach = false;
			MC->DecreaseTriggerDriftDecalCount();	
		}
	}
}

bool FOnRideMountMovementCorrector::DoMovementCorrection(const URoleMovementComponent& MovementComponent,
	MovementContext& MC, float DeltaTime)
{
	switch (EMountType(MC.GetMountType()))
	{
		case EMountType::Bike:
		case EMountType::Car:
		{
			return DoBikeMovementCorrection(MovementComponent, MC, DeltaTime);
		}
		case EMountType::Horse:
		{
			return DoHorseMovementCorrection(MovementComponent, MC, DeltaTime);
		}
		default:
			break;
	}
	
	return false;
}

bool FOnRideMountMovementCorrector::DoBikeMovementCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
{
	FTransform ActorTransform = MovementComponent.GetActorRideModeTransform();
	
	// 计算只涉及XY平面，最后恢复Z轴速度
	FVector WorldMovementDelta = MC.GetWorldPosDelta();
	WorldMovementDelta.Z = 0.f;
	float CurTransformYaw = ActorTransform.Rotator().Yaw;
	FVector ActorForward = FRotator(0.0f, CurTransformYaw, 0.0f).Vector();
	
	// 当前龙头朝向与角色朝向的夹角 FRideMountContextInfo
	const FRideMountContextInfo& ContextInfo = MC.GetRideMountContextInfo();
	float CurMountDirYawToActorYawDelta = ContextInfo.MountDirYawToActorYawDelta;
	float MountMaxDeltaYaw = ContextInfo.MountMaxDeltaYaw;
	
	// 处理倒车逻辑
	bool bUseBackCarMove = MovementComponent.CheckIsBackCarByMoveDelta(WorldMovementDelta);
	MC.SetIsBackCar(bUseBackCarMove);
	if (bUseBackCarMove)
	{
		bUseBackCarMove = true;
		// 这时先把WorldMovementDelta镜像回ActorForward方向上
		WorldMovementDelta = WorldMovementDelta - ActorForward * 2 * WorldMovementDelta.Dot(ActorForward);
	}

	// 没有位移向量时，可以认为车把需要回归向角色朝向
	float MovementDeltaYaw = !WorldMovementDelta.IsNearlyZero() ? WorldMovementDelta.Rotation().Yaw : CurTransformYaw;
	float RealMoveDirYaw = MovementDeltaYaw;

	// 输入向量朝向与角色朝向相差超过 MountMaxDeltaYaw 时，需要Clamp回去
	// MountMaxDeltaYaw大于 0 时生效
	if (MountMaxDeltaYaw > 0.0f && MathFormula::ClosetYawAbsDiff(CurTransformYaw, MovementDeltaYaw) > MountMaxDeltaYaw)
	{
		float DeltaYaw = FRotator::NormalizeAxis(MovementDeltaYaw - CurTransformYaw);
		// 计算不考虑龙头偏转半衰时间时的预期龙头方向
		RealMoveDirYaw = DeltaYaw > 0.0 ? CurTransformYaw + MountMaxDeltaYaw : CurTransformYaw - MountMaxDeltaYaw;
	}
	
	// 根据当前龙头朝向，计算插值后的实际龙头朝向
	float PredictProjectMoveSpeed = WorldMovementDelta.Size2D();
	RealMoveDirYaw = MathFormula::YawDecayWithNormalized(CurTransformYaw + CurMountDirYawToActorYawDelta, RealMoveDirYaw, GetRidingDirInterpolateValue(PredictProjectMoveSpeed), DeltaTime);
	MC.SetMountDirYawToActorYawDelta(FRotator::NormalizeAxis(RealMoveDirYaw - CurTransformYaw));

	// MoveDir表示龙头朝向
	FVector MoveDir = FRotator(0.0f, RealMoveDirYaw, 0.0f).Vector();
	FVector ProjectMoveDelta = MoveDir.Dot(WorldMovementDelta) * MoveDir;
	float ProjectMoveSpeed = DeltaTime > 0.0f ? ProjectMoveDelta.Size2D() / DeltaTime : 99999.0f;
	
	if (bUseBackCarMove)
	{
		// 倒车情况下，使用反向的前轮位移
		ProjectMoveDelta = -ProjectMoveDelta;
	}
	
#if UE_BUILD_DEVELOPMENT
	DebugProjectMoveSpeed = ProjectMoveSpeed;
#endif

	// 处理漂移逻辑(倒车时不允许触发漂移逻辑)
	if (RidingCorrectInfo.bAllowDrift && !bUseBackCarMove)
	{
		if (DeltaTime > 0.0f)
		{
			if (ProjectMoveDelta.Size2D() > 0.0f)
			{
				RidingCorrectInfo.DriftForce = FMath::Min(GetMaxDriftSpeedCurve(ProjectMoveSpeed), RidingCorrectInfo.DriftForce.Size2D() + ProjectMoveDelta.Size2D() / DeltaTime) * (RidingCorrectInfo.DriftForce.IsNearlyZero() ? ActorForward : RidingCorrectInfo.DriftForce.GetSafeNormal2D());
			}
		}
		else if(ProjectMoveDelta.Size2D() > 0.0f)
		{
			RidingCorrectInfo.DriftForce = GetMaxDriftSpeedCurve(ProjectMoveSpeed) * (RidingCorrectInfo.DriftForce.IsNearlyZero() ? ActorForward : RidingCorrectInfo.DriftForce.GetSafeNormal2D());
		}
		if (!RidingCorrectInfo.DriftForce.IsNearlyZero())
		{
			float NewDriftForceLength = MathFormula::DecayValue(RidingCorrectInfo.DriftForce.Size(), 0.0f, GetDriftForceDecayHalfTime(ProjectMoveSpeed), DeltaTime);
			float NewYaw = MathFormula::YawDecayWithNormalized(RidingCorrectInfo.DriftForce.GetSafeNormal2D().Rotation().Yaw, CurTransformYaw, GetDriftForceYawHalfTime(ProjectMoveSpeed), DeltaTime);
			RidingCorrectInfo.DriftForce = NewDriftForceLength * (FRotator(0.0f, NewYaw, 0.0f).Vector());
#if UE_BUILD_DEVELOPMENT
			// UKismetSystemLibrary::DrawDebugLine(&MovementComponent, ActorTransform.GetLocation(), ActorTransform.GetLocation() + RidingCorrectInfo.DriftForce, FLinearColor::Green, 0.1f);
			DriftForceStartPos = ActorTransform.GetLocation();
			DriftForceEndPos = ActorTransform.GetLocation() + RidingCorrectInfo.DriftForce;
#endif
		}
	}
	else
	{
		RidingCorrectInfo.DriftForce.Set(0.0f, 0.0f, 0.0f);
	}
	
	if (ProjectMoveDelta.Size2D() > ContextInfo.MountFrontLength + ContextInfo.MountEndLength)
	{
		// 单帧位移超过车长时
		WorldMovementDelta = ActorForward * ContextInfo.MountFrontLength + MoveDir * (ProjectMoveDelta.Size() - ContextInfo.MountFrontLength);
		WorldMovementDelta.Z = MC.GetWorldPosDelta().Z;
		FVector VerticleDriftForce = RidingCorrectInfo.DriftForce - RidingCorrectInfo.DriftForce.Dot(FRotator(0.0f, RealMoveDirYaw, 0.0f).Vector()) * (RidingCorrectInfo.DriftForce.GetSafeNormal2D());
		CheckTriggerDriftDecalCount(MC, VerticleDriftForce);

		DoSpeedDecayByDrift(WorldMovementDelta, VerticleDriftForce);

#if UE_BUILD_DEVELOPMENT
		MC.SetWorldPosDelta(GetWorldPosDeltaByLRWheel(MovementComponent, WorldMovementDelta + (VerticleDriftForce * DeltaTime), RealMoveDirYaw - CurTransformYaw, CurTransformYaw, RealMoveDirYaw, ActorTransform.GetLocation()));
#else
		MC.SetWorldPosDelta(GetWorldPosDeltaByLRWheel(WorldMovementDelta + (VerticleDriftForce * DeltaTime), RealMoveDirYaw - CurTransformYaw, CurTransformYaw, RealMoveDirYaw));
#endif
		MC.OccupyAbsoluteWorldRot(FQuat(FRotator(0.0f, RealMoveDirYaw, 0.0f)));
	
		// 设置前后轮的转动距离
		float MountMovementLength = WorldMovementDelta.Size2D();
		RidingCorrectInfo.RidingModeMountFrontAngle = FRotator::NormalizeAxis(RidingCorrectInfo.RidingModeMountFrontAngle + (bUseBackCarMove ? -1 : 1) * 180 * MountMovementLength / ContextInfo.MountFrontRadius / PI);
		RidingCorrectInfo.RidingModeMountEndAngle = FRotator::NormalizeAxis(RidingCorrectInfo.RidingModeMountEndAngle + (bUseBackCarMove ? -1 : 1) * 180 * MountMovementLength / ContextInfo.MountEndRadius / PI);
		MC.SetMountMoveAngle(RidingCorrectInfo.RidingModeMountFrontAngle, RidingCorrectInfo.RidingModeMountEndAngle);
	}
	else if (ProjectMoveDelta.Size2D() > 0.0f)
	{
		// 这段Delta运动前后车头位置
		FVector OldFrontLoc = ActorTransform.GetLocation() + ActorForward * ContextInfo.MountFrontLength;
		FVector OldEndLoc = ActorTransform.GetLocation() - ActorForward * ContextInfo.MountEndLength;
		FVector NewFrontLoc = OldFrontLoc + ProjectMoveDelta;
	
		FVector FrontMoveProjectToActorForward = (NewFrontLoc - OldFrontLoc).Dot(ActorForward) * ActorForward;
		float NewFrontToNewOldLengthProjectToActorForward = FMath::Sqrt(FMath::Square(ContextInfo.MountFrontLength + ContextInfo.MountEndLength) - FMath::Square((NewFrontLoc - OldFrontLoc - FrontMoveProjectToActorForward).Size()));
		FVector NewEndLoc = OldFrontLoc + FrontMoveProjectToActorForward - NewFrontToNewOldLengthProjectToActorForward * ActorForward;
	
		FVector NewForwardVec = (NewFrontLoc - NewEndLoc).GetSafeNormal();
		FVector NewLoc = (NewForwardVec * ContextInfo.MountEndLength) + NewEndLoc;
	
		WorldMovementDelta = NewLoc - ActorTransform.GetLocation();
		WorldMovementDelta.Z = MC.GetWorldPosDelta().Z;
		FVector VerticleDriftForce = RidingCorrectInfo.DriftForce - RidingCorrectInfo.DriftForce.Dot(NewForwardVec) * (RidingCorrectInfo.DriftForce.GetSafeNormal2D());
		CheckTriggerDriftDecalCount(MC, VerticleDriftForce);

		DoSpeedDecayByDrift(WorldMovementDelta, VerticleDriftForce);

#if UE_BUILD_DEVELOPMENT
		MC.SetWorldPosDelta(GetWorldPosDeltaByLRWheel(MovementComponent, WorldMovementDelta + VerticleDriftForce * DeltaTime, RealMoveDirYaw - CurTransformYaw, CurTransformYaw, NewForwardVec.Rotation().Yaw, ActorTransform.GetLocation()));
#else
		MC.SetWorldPosDelta(GetWorldPosDeltaByLRWheel(WorldMovementDelta + VerticleDriftForce * DeltaTime, RealMoveDirYaw - CurTransformYaw, CurTransformYaw, NewForwardVec.Rotation().Yaw));
#endif
		MC.OccupyAbsoluteWorldRot(FQuat(FRotator(0, NewForwardVec.Rotation().Yaw, 0)));
	
		// 设置前后轮的转动距离
		RidingCorrectInfo.RidingModeMountFrontAngle = FRotator::NormalizeAxis(RidingCorrectInfo.RidingModeMountFrontAngle + (bUseBackCarMove ? -1 : 1) * 180 * (NewFrontLoc - OldFrontLoc).Size2D() / ContextInfo.MountFrontRadius / PI);
		RidingCorrectInfo.RidingModeMountEndAngle = FRotator::NormalizeAxis(RidingCorrectInfo.RidingModeMountEndAngle + (bUseBackCarMove ? -1 : 1) * 180 * (NewEndLoc - OldEndLoc).Size2D() / ContextInfo.MountEndRadius / PI);
		MC.SetMountMoveAngle(RidingCorrectInfo.RidingModeMountFrontAngle, RidingCorrectInfo.RidingModeMountEndAngle);
	}
	else
	{
		WorldMovementDelta.X = 0.0f;
		WorldMovementDelta.Y = 0.0f;
		WorldMovementDelta.Z = MC.GetWorldPosDelta().Z;
		FVector VerticleDriftForce = RidingCorrectInfo.DriftForce - RidingCorrectInfo.DriftForce.Dot(ActorTransform.Rotator().Vector()) * (RidingCorrectInfo.DriftForce.GetSafeNormal2D());
		CheckTriggerDriftDecalCount(MC, VerticleDriftForce);

		// 本身速度为0的分支，不用处理了
		// DoSpeedDecayByDrift(WorldMovementDelta, VerticleDriftForce);

#if UE_BUILD_DEVELOPMENT
		MC.SetWorldPosDelta(GetWorldPosDeltaByLRWheel(MovementComponent, WorldMovementDelta + VerticleDriftForce * DeltaTime, RealMoveDirYaw - CurTransformYaw, CurTransformYaw, CurTransformYaw, ActorTransform.GetLocation()));
#else
		MC.SetWorldPosDelta(GetWorldPosDeltaByLRWheel(WorldMovementDelta + VerticleDriftForce * DeltaTime, RealMoveDirYaw - CurTransformYaw, CurTransformYaw, CurTransformYaw));
#endif
		// MC.OccupyAbsoluteWorldRot(FQuat(FRotator(0, ActorTransform.Rotator().Yaw, 0)));
	}

	return true;
}

void FOnRideMountMovementCorrector::DoSpeedDecayByDrift(FVector& InOutWorldMovementDelta, const FVector& InVerticleDriftForce)
{
	// 处理漂移衰减
	if (InOutWorldMovementDelta.Size2D() > 0.0f) {
		float DecayRate = GetSpeedDecayByDriftSpeedRate(InVerticleDriftForce.Size2D() / InOutWorldMovementDelta.Size2D());
		// UE_LOG(LogTemp, Warning, TEXT("[szk]DriftToSpeedRate:%f, DecayRate:%f"), InVerticleDriftForce.Size2D() / InOutWorldMovementDelta.Size2D(), DecayRate);
		InOutWorldMovementDelta.X *= DecayRate;
		InOutWorldMovementDelta.Y *= DecayRate;
	}
}

FVector FOnRideMountMovementCorrector::GetWorldPosDeltaByLRWheel(const FVector& OriginWorldPosDelta, const float MountDirYawToActorYawDelta, const float OldForwardYaw, const float NewForwardYaw)
{
	// 90为右轮转向，-90为左轮转向
	bool bRightOrLeft = FRotator::NormalizeAxis(MountDirYawToActorYawDelta) > 0.0f;
	float DeltaYaw = bRightOrLeft ? 90.0f : -90.0f;
	float WheelToCenterDist = bRightOrLeft ? RidingCorrectInfo.RightWheelToCenterDist : RidingCorrectInfo.LeftWheelToCenterDist;
	FVector OldCenterToWheel = FRotator(0.0f, OldForwardYaw + DeltaYaw, 0.0f).Vector() * WheelToCenterDist;
	FVector NewCenterToWheel = FRotator(0.0f, NewForwardYaw + DeltaYaw, 0.0f).Vector() * WheelToCenterDist;
	return OldCenterToWheel + OriginWorldPosDelta - NewCenterToWheel;
}

#if UE_BUILD_DEVELOPMENT
FVector FOnRideMountMovementCorrector::GetWorldPosDeltaByLRWheel(const UObject& WorldContext, const FVector& OriginWorldPosDelta, const float MountDirYawToActorYawDelta, const float OldForwardYaw, const float NewForwardYaw, const FVector& CurLoc)
{
	// 90为右轮转向，-90为左轮转向
	bool bRightOrLeft = FRotator::NormalizeAxis(MountDirYawToActorYawDelta) > 0.0f;
	float DeltaYaw = bRightOrLeft ? 90.0f : -90.0f;
	float WheelToCenterDist = bRightOrLeft ? RidingCorrectInfo.RightWheelToCenterDist : RidingCorrectInfo.LeftWheelToCenterDist;
	FVector OldCenterToWheel = FRotator(0.0f, OldForwardYaw + DeltaYaw, 0.0f).Vector() * WheelToCenterDist;
	FVector NewCenterToWheel = FRotator(0.0f, NewForwardYaw + DeltaYaw, 0.0f).Vector() * WheelToCenterDist;
	if (WheelToCenterDist > 0.0f && !OriginWorldPosDelta.IsNearlyZero())
	{
		LRWheelPos[0] = CurLoc; LRWheelPos[1] = CurLoc + OldCenterToWheel;
		LRWheelPos[2] = CurLoc + OldCenterToWheel; LRWheelPos[3] = CurLoc + OldCenterToWheel + OriginWorldPosDelta;
		LRWheelPos[4] = CurLoc + OldCenterToWheel + OriginWorldPosDelta; LRWheelPos[5] = CurLoc + OldCenterToWheel + OriginWorldPosDelta - NewCenterToWheel;
		/*UKismetSystemLibrary::DrawDebugLine(&WorldContext, CurLoc, CurLoc + OldCenterToWheel, FLinearColor::Red, 0.1f);
		UKismetSystemLibrary::DrawDebugLine(&WorldContext, CurLoc + OldCenterToWheel, CurLoc + OldCenterToWheel + OriginWorldPosDelta, FLinearColor::Red, 0.1f);
		UKismetSystemLibrary::DrawDebugLine(&WorldContext, CurLoc + OldCenterToWheel + OriginWorldPosDelta, CurLoc + OldCenterToWheel + OriginWorldPosDelta - NewCenterToWheel, FLinearColor::Red, 0.1f);*/
	}
	return OldCenterToWheel + OriginWorldPosDelta - NewCenterToWheel;
}
#endif

bool FOnRideMountMovementCorrector::DoHorseMovementCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
{
	FTransform ActorTransform = MovementComponent.GetActorRideModeTransform();
	FVector InputVector = MC.GetLocoInputVec();
	bool hasInput = MC.GetHasLocoInput();
	
	float CurTransformYaw = ActorTransform.Rotator().Yaw;
	
	// 当前龙头朝向与角色朝向的夹角 FRideMountContextInfo
	const FRideMountContextInfo& ContextInfo = MC.GetRideMountContextInfo();
	float CurMountDirYawToActorYawDelta = ContextInfo.MountDirYawToActorYawDelta;
	float MountMaxDeltaYaw = ContextInfo.MountMaxDeltaYaw;
	
	// 没有输入向量时，可以认为车把需要回归向角色朝向
	float InputVectorYaw = (hasInput && !InputVector.IsNearlyZero()) ? InputVector.Rotation().Yaw : CurTransformYaw;
	// 输入向量朝向与角色朝向相差超过 MountMaxDeltaYaw 时，需要Clamp回去
	// MountMaxDeltaYaw大于 0 时生效
	const float DeltaYaw = FRotator::NormalizeAxis(InputVectorYaw - CurTransformYaw);
	bool bBlendIn = FMath::Abs(DeltaYaw) > MountMaxDeltaYaw * 0.1;
	
	const float TargetValue = DeltaYaw > 0 ? 1 : -1;
	const float TargetAXis = bBlendIn ? TargetValue : 0;
	CurMountDirYawToActorYawDelta = MathFormula::DecayValue(CurMountDirYawToActorYawDelta, TargetAXis, RidingCorrectInfo.RidingDirInterpolateParam, DeltaTime);
	// 根据当前龙头朝向，计算插值后的实际龙头朝向
	MC.SetMountDirYawToActorYawDelta(CurMountDirYawToActorYawDelta);
	
	return true;
}

void FOnRideMountMovementCorrector::CheckTriggerDriftDecalCount(MovementContext& MC, const FVector& VerticalDriftForce)
{
	float VerticalDriftSpeedToTriggerDriftDecal = URoleMovementComponent::GetVerticalDriftSpeedToTriggerDriftDecal();
	float SpeedGapForTriggerDriftDecal = URoleMovementComponent::GetSpeedGapForTriggerDriftDecal();
	if (VerticalDriftForce.Length() > VerticalDriftSpeedToTriggerDriftDecal + SpeedGapForTriggerDriftDecal)
	{
		if (!bIsDriftDecalAttach)
		{
			bIsDriftDecalAttach = true;
			MC.IncreaseTriggerDriftDecalCount();	
		}
	}
	else if (VerticalDriftForce.Length() < VerticalDriftSpeedToTriggerDriftDecal - SpeedGapForTriggerDriftDecal)
	{
		if (bIsDriftDecalAttach)
		{
			bIsDriftDecalAttach = false;
			MC.DecreaseTriggerDriftDecalCount();	
		}
	}
}

#if UE_BUILD_DEVELOPMENT
void FOnRideMountMovementCorrector::AppendDebugInfo(FString& infoOut) {
	infoOut.Append(TEXT("===================<Title_Blue>RideMountMovementCorrector</>===================\n"));
	infoOut.Appendf(TEXT("bAllowDrift:%d   ProjectMoveSpeed:%f   DriftForce:%s   DriftForceLength%f\n"), RidingCorrectInfo.bAllowDrift
		, DebugProjectMoveSpeed, *RidingCorrectInfo.DriftForce.ToCompactString(), RidingCorrectInfo.DriftForce.Size2D());
	infoOut.Appendf(TEXT("RidingDirInterpolateValue:%f   MaxDriftSpeed:%f   DriftForceDecayHalfTime%f   DriftForceYawHalfTime:%f\n")
		, GetRidingDirInterpolateValue(DebugProjectMoveSpeed), GetMaxDriftSpeedCurve(DebugProjectMoveSpeed), 
		GetDriftForceDecayHalfTime(DebugProjectMoveSpeed), GetDriftForceYawHalfTime(DebugProjectMoveSpeed));

	if (IsValid(GWorld))
	{
		UKismetSystemLibrary::DrawDebugLine(GWorld, DriftForceStartPos, DriftForceEndPos, FLinearColor::Green, 0.1f);
		UKismetSystemLibrary::DrawDebugLine(GWorld, LRWheelPos[0], LRWheelPos[1], FLinearColor::Red, 0.1f);
		UKismetSystemLibrary::DrawDebugLine(GWorld, LRWheelPos[2], LRWheelPos[3], FLinearColor::Red, 0.1f);
		UKismetSystemLibrary::DrawDebugLine(GWorld, LRWheelPos[4], LRWheelPos[5], FLinearColor::Red, 0.1f);
	}
}

#endif