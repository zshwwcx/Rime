// #pragma once
#include "3C/Movement/MovementPipeline/RoleMovementPipeline.h"

#include "AkComponent.h"
#include "Manager/KGAkAudioManager.h"
#include "3C/Audio/KGAudioNotifyHelper.h"
#include "3C/Movement/MovementPipeline/MovementContext.h"

#include "3C/Character/BaseCharacter.h"
#include "3C/Movement/RoleMovementComponent.h"
#include  "KGCore/Public/Misc/MathFormula.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Util/KGUtils.h"


void MovementContext::SetLocoInputVec(const FVector& inputVec, bool isActive, float DeltaTime) {

	LocoInputVec = inputVec;
	if (LocoInputVec.Length() > 1.0f) {
		LocoInputVec = LocoInputVec.GetSafeNormal();
	}

	HasLocoInput = isActive;
	if (isActive) {
		LastActiveLocoInputVec = inputVec;
		
		CachedLocoInputVec = inputVec;
		CurLocoInputVecCacheTime = LocoInputVecCacheTime;
	}
	else if(CurLocoInputVecCacheTime > 0.0f)
	{
		CurLocoInputVecCacheTime -= DeltaTime;
		if (CurLocoInputVecCacheTime <= 0.0f)
		{
			CachedLocoInputVec.Set(0.0f, 0.0f, 0.0f);
		}
	}
}

FVector MovementContext::GetFinalWorldPosDelta(const FQuat& worldRot) const {
	if (AbsoluteWorldPosCount > 0) {

		if(IsAllowOffsetAbsoluteWorldPos)
		{
			return WorldAbsolutePos - CurrentActorTransform.GetTranslation() + WorldPosDelta + worldRot.RotateVector(LocalPosDelta);
		}
		else
		{
			return WorldAbsolutePos - CurrentActorTransform.GetTranslation();
		}
	}

	return WorldPosDelta + worldRot.RotateVector(LocalPosDelta);
}

FQuat MovementContext::GetFinalWorldRot(const FQuat& baseWorldRot) const {
	FQuat OutQuat = FQuat::Identity;
	if (AbsoluteWorldRotCount > 0) 
	{
		OutQuat = WorldAbsoluteRot;
	}
	else
	{
		OutQuat = baseWorldRot * LocalRotDelta;
		if (bHasMovementBase && bLastHasMovementBase)
		{
			// 只处理Yaw偏转
			FRotator DeltaRotator = ((MovementBaseTransform.GetRotation()) * ((LastMovementBaseTransform.GetRotation()).Inverse())).Rotator();
			DeltaRotator.Pitch = 0.0f;
			DeltaRotator.Roll = 0.0f;
			OutQuat = OutQuat * (DeltaRotator.Quaternion());
		}
	}

	FRotator OutRotator = OutQuat.Rotator();
	FRotator BaseRotator = baseWorldRot.Rotator();
	if ((RotationOutputMask & RotationPitchOutputMask) == 0) {
		OutRotator.Pitch = BaseRotator.Pitch;
	}
	if ((RotationOutputMask & RotationYawOutputMask) == 0) {
		OutRotator.Yaw = BaseRotator.Yaw;
	}
	if ((RotationOutputMask & RotationRollOutputMask) == 0) {
		OutRotator.Roll = BaseRotator.Roll;
	}

	return OutRotator.Quaternion();
}

void MovementContext::SetRotationOutputMask(bool AllowPitch, bool AllowYaw, bool AllowRoll)
{
	if (AllowPitch) {
		RotationOutputMask |= RotationPitchOutputMask;
	}
	else {
		RotationOutputMask &= (~RotationPitchOutputMask);
	}

	if (AllowYaw) {
		RotationOutputMask |= RotationYawOutputMask;
	}
	else {
		RotationOutputMask &= (~RotationYawOutputMask);
	}

	if (AllowRoll) {
		RotationOutputMask |= RotationRollOutputMask;
	}
	else {
		RotationOutputMask &= (~RotationRollOutputMask);
	}
}

bool MovementContext::ConsumeMeshAdditionalOffset(FVector& offset) {
	if (!HasMeshAdditionalOffset) {
		return false;
	}

	offset = MeshAdditionalOffset;
	HasMeshAdditionalOffset = false;
	MeshAdditionalOffset.Set(0, 0, 0);
	return true;
}

bool MovementContext::ConsumeNetShadowMovement(FVector& pos, FRotator& rotator) {
	ensureAlways(IsCalculateAndApplyStagePrepared);
	if (!HasNetShadowData) {
		return false;
	}

	pos = NetShadowPos;
	rotator = NetShadowRotator;
	HasNetShadowData = false;
	return true;

}


FVector MovementContext::GetFaceDirectionInputVec(EFaceDirectionInputMode FaceMode)
{
	if(FaceMode == EFaceDirectionInputMode::VelocityDirection)
	{
		return LastActiveLocoInputVec;
	}

	if(FaceMode == EFaceDirectionInputMode::CameraControlDirection)
	{
		return ControllerRotator.Vector();
	}

	return LocoInputVec;
	
}

void MovementContext::ProduceReplacedFinalWorldDeltaOuterFromPipeline(const FVector& PosDelta, bool ReplacedX, bool ReplacedY, bool ReplacedZ)
{
	if(ReplacedX)
	{
		ReplacedFinalTransformMask |= REPLACE_X_MASK;
	}

	if(ReplacedY)
	{
		ReplacedFinalTransformMask |= REPLACE_Y_MASK;
	}

	if(ReplacedZ)
	{
		ReplacedFinalTransformMask |= REPLACE_Z_MASK;
	}
	
	
	ReplacedFinalWorldDeltaOuterFromPipeline = PosDelta;
}

void MovementContext::ConsumeReplacedFinalWorldDeltaOuterFromPipeline(FVector & OutFinalWorldDelta)
{
	if(ReplacedFinalTransformMask & REPLACE_X_MASK)
	{
		OutFinalWorldDelta.X = ReplacedFinalWorldDeltaOuterFromPipeline.X;
	}
	
	if(ReplacedFinalTransformMask & REPLACE_Y_MASK)
	{
		OutFinalWorldDelta.Y = ReplacedFinalWorldDeltaOuterFromPipeline.Y;
	}

	if(ReplacedFinalTransformMask & REPLACE_Z_MASK)
	{
		OutFinalWorldDelta.Z = ReplacedFinalWorldDeltaOuterFromPipeline.Z;
	}
	
	ReplacedFinalWorldDeltaOuterFromPipeline.Set(0, 0, 0);
}

void MovementContext::ProduceReplacedFinalWorldRotationOuterFromPipeline(const FQuat & FinalQuat, bool ReplacePitch, bool ReplaceYaw, bool ReplaceRoll)
{
	if(ReplacePitch)
	{
		ReplacedFinalTransformMask |= REPLACE_PITCH_MASK;
	}

	if(ReplaceYaw)
	{
		ReplacedFinalTransformMask |= REPLACE_YAW_MASK;
	}

	if(ReplaceRoll)
	{
		ReplacedFinalTransformMask |= REPLACE_ROLL_MASK;
	}
	
	
	ReplacedFinalWorldRotationOuterFromPipeline = FinalQuat.Rotator();
}
void MovementContext::ConsumeReplacedFinalWorldRotationOuterFromPipeline(FQuat & FinalQuat)
{
	FRotator FinalRot = FinalQuat.Rotator();
	
	if(ReplacedFinalTransformMask & REPLACE_PITCH_MASK)
	{
		FinalRot.Pitch = ReplacedFinalWorldRotationOuterFromPipeline.Pitch;
	}
	
	if(ReplacedFinalTransformMask & REPLACE_YAW_MASK)
	{
		FinalRot.Yaw = ReplacedFinalWorldRotationOuterFromPipeline.Yaw;
	}

	if(ReplacedFinalTransformMask & REPLACE_ROLL_MASK)
	{
		FinalRot.Roll = ReplacedFinalWorldRotationOuterFromPipeline.Roll;
	}
	
	FinalQuat = FinalRot.Quaternion();
}


void MovementContext::UpdateMovementBaseInfo(UPrimitiveComponent* InBase, FName InBaseBoneName)
{
	bLastHasMovementBase = bHasMovementBase;
	LastMovementBaseTransform = MovementBaseTransform;

	if (IsValid(InBase))
	{
		FQuat NewBaseQuat = FQuat::Identity;
		FVector NewBaseLocation = FVector::ZeroVector;
		bHasMovementBase = MovementBaseUtility::GetMovementBaseTransform(InBase, InBaseBoneName, NewBaseLocation, NewBaseQuat);

		MovementBaseTransform = InBase->GetComponentTransform();
		MovementBaseTransform.SetTranslation(NewBaseLocation);
		MovementBaseTransform.SetRotation(NewBaseQuat);
		
		if ((LastMovementBase.IsValid() && LastMovementBase.Get() != InBase) || (LastBaseBoneName != InBaseBoneName))
		{
			// 如果发生了Base或者BoneName的改变，需要视为Last无Base
			bLastHasMovementBase = false;
			LastMovementBaseTransform = FTransform::Identity;
		}
	}
	else
	{
		bHasMovementBase = false;
		MovementBaseTransform = FTransform::Identity;
	}

	LastMovementBase = InBase;
	LastBaseBoneName = InBaseBoneName;
}


void MovementContext::AccumulateWorldPosDelta(const FVector& delta)
{
	ensureAlways(IsCalculateAndApplyStagePrepared);

	WorldPosDelta = WorldPosDelta + delta;
}

void MovementContext::AccumulateLocalPosDeltaWithBlend(const FVector& delta, float BlendWeight)
{
	ensureAlways(IsCalculateAndApplyStagePrepared);

	if(BlendWeight < 0.0f)
	{
		BlendWeight = 0.0f;
	}

	if(BlendWeight > 1.0f)
	{
		BlendWeight = 1.0f;
	}
	LocalPosDelta = (1.0f - BlendWeight) * LocalPosDelta + BlendWeight * delta;
}

void MovementContext::AccumulateWorldPosDeltaWithBlend(const FVector& delta, float BlendWeight)
{
	ensureAlways(IsCalculateAndApplyStagePrepared);

	if(BlendWeight < 0.0f)
	{
		BlendWeight = 0.0f;
	}

	if(BlendWeight > 1.0f)
	{
		BlendWeight = 1.0f;
	}
	WorldPosDelta = (1.0f - BlendWeight) * WorldPosDelta + BlendWeight * delta;
}

void MovementContext::StartMovementVelocityStable(float TolerateRatio, bool ToUseVelHistoryAvg)
{
	IsInVelocityStable = true;
	VelocityDiffTolerateRatio = TolerateRatio;
	UseVelHistoryAvg = ToUseVelHistoryAvg;
}

void MovementContext::EndMovementVelocityStable(float DelayEffectTime)
{
	VelocityStableDelayEffectTime = DelayEffectTime;

	if (DelayEffectTime == 0.f)
	{
		IsInVelocityStable = false;
	}
}

void MovementContext::DoWorldPosDeltaOutputStable(float TimeDelta)
{
	int HistorySize = LocoStateVelocityHistory.Num();
	if(HistorySize == 0)
	{
		return;
	}
	
	if(FMath::IsNearlyZero(TimeDelta))
	{
		TimeDelta = 0.001f;
	}

	// 给一个0.2系数的时间偏移, 尽量能够向下取整, 兼容30帧时候的计算误差
	int VelocityFrameCount = int((TimeDelta + 0.2 * FRAME_TIME_FOR_LOCO_VELOCITY_BLEND) /FRAME_TIME_FOR_LOCO_VELOCITY_BLEND);

	if(VelocityFrameCount <= 0 && VelocityFrameCount >= MAX_VEL_HISTORY_COUNT)
	{
		VelocityFrameCount = 1;
	}

	FVector CurWorldVelocity = WorldPosDelta / TimeDelta;

	if(IsInVelocityStable)
	{
		uint8 LastVelIndex = VelHistoryIndex;
		if(LastVelIndex == 0 )
		{
			LastVelIndex = HistorySize -1;
		}
		else
		{
			LastVelIndex -= 1;
		}
		FVector LastVelocity = LocoStateVelocityHistory[LastVelIndex];

		const float MinTolerateVelThreshold = 100;
		if(LastVelocity.Size() > MinTolerateVelThreshold)
		{
			float DiffVel = fabs( LastVelocity.Size() - CurWorldVelocity.Size());
			//超过稳定差值阈值, 直接剔除数据
			if(DiffVel / LastVelocity.Size()  > VelocityDiffTolerateRatio)
			{
				CurWorldVelocity = LastVelocity;
			}
		}
	}
	
	while(VelocityFrameCount > 0)
	{
		VelocityFrameCount -= 1;

		LocoStateVelocityHistory[VelHistoryIndex] = CurWorldVelocity;
		VelHistoryIndex += 1;
		if(VelHistoryIndex >= HistorySize){
			VelHistoryIndex = 0;
		}
	}

	// 不在过渡流程中, 不做矫正
	if(!IsInVelocityStable){
		return ;
	}

	
	if(UseVelHistoryAvg)
	{
		FVector AvgVelocity = FVector::Zero();
		for(auto const& HisVel:LocoStateVelocityHistory)
		{
			AvgVelocity += HisVel;
		}
		AvgVelocity = AvgVelocity / HistorySize;

		WorldPosDelta = AvgVelocity * TimeDelta;
	}
	else
	{
		WorldPosDelta = CurWorldVelocity * TimeDelta;
	}
}


void MovementContext::InitLocoStateVelocityHistory(int Count)
{
	VelHistoryCount = Count;
	if (VelHistoryCount <= 0)
	{
		VelHistoryCount = 6;
	}

	// 不能超过uint8
	if(VelHistoryCount > MAX_VEL_HISTORY_COUNT)
	{
		VelHistoryCount = MAX_VEL_HISTORY_COUNT;
	}
	
	LocoStateVelocityHistory.SetNumZeroed(VelHistoryCount, 0.0f);
	
	VelHistoryIndex = 0;
}

void MovementContext::UpdateVelocityStableDelayEffectTime(float DeltaTime)
{
	if (VelocityStableDelayEffectTime > 0)
	{
		VelocityStableDelayEffectTime -= DeltaTime;
		VelocityStableDelayEffectTime = VelocityStableDelayEffectTime > 0 ? VelocityStableDelayEffectTime : 0;
		IsInVelocityStable = VelocityStableDelayEffectTime == 0 ? false : true;
	}
}

#if UE_BUILD_DEVELOPMENT
void MovementContext::AppendDebugInfo(FString& infoOut) {
	infoOut.Appendf(TEXT("==================MovementContext=============\n"));

	infoOut.Appendf(TEXT("HasLocoInput:%d   LocoInputVec:%s  LastActiveInputVec:%s  ActionInputVec:%s\n"),
		HasLocoInput, *(LocoInputVec.ToString()), *(LastActiveLocoInputVec.ToString()), *(ActionInputVec.ToString()));

	infoOut.Appendf(TEXT("AllowLocoMove:%d   AllowLocoRot:%d  MaxLocoSpeed:%f  MaxAcceleration:%f   MaxBrakingDeceleration:%f  \n")
		, AllowLocoMove, AllowLocoRot, MaxLocoSpeed, MaxAcceleration, MaxBrakingDeceleration);

	infoOut.Appendf(TEXT("IgnoreGravityCount:%d   IgnorePhysicFixupCount:%d  \n")
		, IgnoreGravityCount, IgnorePhysicsFixupCount);

	infoOut.Appendf(TEXT("HasForceGroundSupportCount:%d   HasForceLocoGroundSupportCount:%d  \n")
		, HasForceGroundSupportCount, HasForceLocoGroundSupportCount);

	infoOut.Appendf(TEXT("CurrentVelocity:%s   CurrentActorPos:%s  CurrentActorRotator:%s MeshPos:%s  MeshRot:%s   \n"),
		*(CurrentVelocity.ToString()), *(CurrentActorTransform.GetTranslation().ToString()),  *CurrentActorTransform.GetRotation().Rotator().ToString(),
		*(MeshToActorTransform.GetTranslation().ToString()),  *MeshToActorTransform.GetRotation().Rotator().ToString());


	FVector AvgVelocity = FVector::Zero();
	if(LocoStateVelocityHistory.Num() > 0)
	{
		for(auto const& HisVel:LocoStateVelocityHistory)
		{
			AvgVelocity += HisVel;
		}
		AvgVelocity = AvgVelocity / LocoStateVelocityHistory.Num();
	}
	
	infoOut.Appendf(TEXT("VelHistoryCount:%d  IsInVelocityStable:%d  HistoryAvgVelocity:%s   \n"),
		VelHistoryCount, IsInVelocityStable, *(AvgVelocity.ToCompactString()));
	
	infoOut.Appendf(TEXT("AbsoluteWorldPosCount:%d  IsAllowOffsetAbsoluteWorldPos:%d  WorldAbsolutePos:%s  WorldPosDelta:%s  LocalPosDelta:%s   \n"),
		AbsoluteWorldPosCount, IsAllowOffsetAbsoluteWorldPos, *(WorldAbsolutePos.ToString()), *(WorldPosDelta.ToString()), *(LocalPosDelta.ToString()));

	infoOut.Appendf(TEXT("AbsoluteWorldRotCount:%d   WorldAbsoluteRot:%s   LocalRotDelta:%s   \n"),
		AbsoluteWorldRotCount, *(WorldAbsoluteRot.Rotator().ToString()), *(LocalRotDelta.Rotator().ToString()));
	
	infoOut.Appendf(TEXT("RootmotionDeltaTransLocalSpace:%s   \n"), *(RootmotionDeltaTransLocalSpace.ToString()));

	infoOut.Appendf(TEXT("RootTransform:%s   CalculateWorldTranslationDelta:%s   CalculateWorldRotationDeltaDelta:%s   \n"),
		*(RootTransform.ToString()), *(CalculateWorldTranslationDelta.ToString()), *(CalculateWorldRotationDeltaDelta.Rotator().ToString()));

	infoOut.Appendf(TEXT("FinalWorldTranslationDelta:%s  \n"),*(FinalWorldTranslationDelta.ToString()));

	infoOut.Appendf(TEXT("HasMeshAdditionalOffset:%b   MeshAdditionalOffset::%s   \n"),
		HasMeshAdditionalOffset, *(MeshAdditionalOffset.ToCompactString()));
}

#endif

void RoleMovementPipeline::Init(URoleMovementComponent& roleMovementComponent)
{
	Owner = &roleMovementComponent;
	MovementCorrectorManager.Init(roleMovementComponent);
	PostureCorrectorManager.Init(roleMovementComponent);
}

void RoleMovementPipeline::PrepareMovementContextBeforeInputCalculate() {
	MovementContext.ResetMovementContext();
}

void RoleMovementPipeline::PrepareMovementContextBeforeCalculateAndApply(URoleMovementComponent* roleMovementComponent, float DeltaTime) {
	if (!roleMovementComponent->UpdatedComponent) {
		return ;
	}

	URoleMovementComponent* realMovementProxy = roleMovementComponent->GetRealMovementViewProxy();
	if (!realMovementProxy) {
		return ;
	}
	
	FTransform meshCompTrans;
	FTransform meshWorldTrans;
	auto* CharacterOwner = realMovementProxy->GetCharacterOwner();
	if (CharacterOwner) {
		USkeletalMeshComponent* SkelMeshComp = CharacterOwner->GetMesh();
		if (SkelMeshComp) {
			meshCompTrans = SkelMeshComp->GetRelativeTransform();
			meshWorldTrans = SkelMeshComp->GetComponentTransform();
		}
	}

	// 这里需要拿到玩家身上的Controller,所以不使用代理
	FRotator ControllerRotator = roleMovementComponent->GetMovementControlRotation();
	FTransform ProxyWorldTrans = realMovementProxy->GetActorTransform();

	// 这里开始分逻辑和表现代理, 例如: 骑乘的时候表现代理用的是坐骑, 逻辑(输入、重力、法术场引力...)用的还是玩家自己
	// Pipeline中只要是使用MovementContext来计算, 应该问题就不大

	float MaxAcceleration = roleMovementComponent->GetMaxAcceleration();
	float MaxBrakingDeceleration = roleMovementComponent->GetMaxBrakingDeceleration();
	MovementContext.ResetMovementCalculateAndApplyContext(
		ProxyWorldTrans, meshCompTrans, meshWorldTrans, realMovementProxy->GetMovementVelocity(),
		roleMovementComponent->GetMaxSpeed(),
		MaxAcceleration, MaxBrakingDeceleration,
		roleMovementComponent->AllowProactiveMovement(), roleMovementComponent->AllowProactiveRotation(),
		realMovementProxy->GetOMeshRL(), ControllerRotator, realMovementProxy->GetFaceDriveDirectionVec()
	);
	MovementContext.UpdateVelocityStableDelayEffectTime(DeltaTime);

	return ;
}
void RoleMovementPipeline::ApplyMovementContextOnPostLateUpdate(URoleMovementComponent* roleMovementComponent, float DeltaTime)
{
	// 更新MoveContext的ForceGroundSupport
	roleMovementComponent->CheckPreLanding(DeltaTime);
	roleMovementComponent->UpdateLocoJumpForceIgnoreGroundSupportDuration(DeltaTime);
	roleMovementComponent->UpdateHasGroundSupport(true);

	if (DisableAnimRootmotionRotationDuration > 0.0f)
	{
		DisableAnimRootmotionRotationDuration -= DeltaTime;
	}

	URoleMovementComponent* realMovementProxy = roleMovementComponent->GetRealMovementViewProxy();
	if (!realMovementProxy) {
		return;
	}
	ACharacter* CharacterOwner = realMovementProxy->GetCharacterOwner();
	if (!CharacterOwner) {
		return;
	}
	MovementContext.UpdateMovementBaseInfo(realMovementProxy->GetMovementBase(), CharacterOwner->GetBasedMovement().BoneName);
	// 要做一个保底的清理, 不能在MoveContext初始化的地方清理, 因为是外部塞数据, 所以要自己在计算末尾进行处理
	MovementContext.CleanupReplacedDataOuterFormPipeline();

	CheckTriggerDriftPerformance(roleMovementComponent);
}

void RoleMovementPipeline::CheckTriggerDriftPerformance(URoleMovementComponent* RMComp)
{
	auto* EffectMgr = UKGEffectManager::GetInstance(RMComp);
	if (!EffectMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CheckTriggerDriftPerformance] get KGEffectManager failed"));
		return;
	}

	auto* AudioMgr = UKGAkAudioManager::GetInstance(RMComp);
	if (!AudioMgr)
	{
		return;
	}

	auto* ActorMgr = UKGUEActorManager::GetInstance(RMComp);
	if (!ActorMgr)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CheckTriggerDriftPerformance] get KGUEActorManager failed"));
		return;
	}

	AActor* OwnerActor = RMComp->GetOwner();
	if (!OwnerActor)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CheckTriggerDriftPerformance] get Owner failed"));
		return;
	}
	
	ICppEntityInterface* EntityInterface = ActorMgr->GetLuaEntityByActor(OwnerActor);
	if (!EntityInterface)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CheckTriggerDriftPerformance] get entity failed"));
		return;
	}

	auto* DataCacheMgr = UKGDataCacheManager::GetInstance(RMComp);
	if (!DataCacheMgr)
	{
		return;
	}
	
	bool bRightOrLeft =  MovementContext.GetMountDirYawToActorYawDelta() > 0.f;
	if (MovementContext.IsTriggerDriftDecalNeedAttach() && RMComp->GetHasGroundSupport())
	{
		const FTriggerDriftParams& TriggerDriftParams = DataCacheMgr->GetTriggerDriftParams();
		if (bRightOrLeft)
		{
			if (TriggerDriftDecalID_L != 0)
			{
				EffectMgr->DeactivateNiagaraSystem(TriggerDriftDecalID_L);
				TriggerDriftDecalID_L = 0;
			}

			if (TriggerDriftDecalID_R == 0)
			{
				FKGPlayNiagaraParams Params;
				SetTriggerDriftDecalParams(Params, RMComp->GetRealMovementViewProxy(), bRightOrLeft, TriggerDriftParams);
				TriggerDriftDecalID_R = EffectMgr->CreateNiagaraSystem(Params);
			}
		}
		else
		{
			if (TriggerDriftDecalID_R != 0)
			{
				EffectMgr->DeactivateNiagaraSystem(TriggerDriftDecalID_R);
				TriggerDriftDecalID_R = 0;
			}

			if (TriggerDriftDecalID_L == 0)
			{
				FKGPlayNiagaraParams Params;
				SetTriggerDriftDecalParams(Params, RMComp->GetRealMovementViewProxy(), bRightOrLeft, TriggerDriftParams);
				TriggerDriftDecalID_L = EffectMgr->CreateNiagaraSystem(Params);
			}
		}

		if (TriggerDriftAudioPlayingID == 0)
		{
			if (UAkComponent* AkComponent = OwnerActor->GetComponentByClass<UAkComponent>())
			{
				const FString& EventName = EntityInterface->GetIsUnderMainPlayerControl() ? TriggerDriftParams.TriggerDriftStartAudio_1P : TriggerDriftParams.TriggerDriftStartAudio;
				if (FKGAudioNotifyHelper::IsMajorUnit(EntityInterface) || AudioMgr->CanPostNotifyEvent(true))
				{
					TriggerDriftAudioPlayingID = AudioMgr->InnerPostEventOnAkComp(EventName, AkComponent);	
				}
			}
		}
	}
	else
	{
		if (TriggerDriftDecalID_R != 0)
		{
			EffectMgr->DeactivateNiagaraSystem(TriggerDriftDecalID_R);
			TriggerDriftDecalID_R = 0;
		}
		
		if (TriggerDriftDecalID_L != 0)
		{
			EffectMgr->DeactivateNiagaraSystem(TriggerDriftDecalID_L);
			TriggerDriftDecalID_L = 0;
		}

		if (TriggerDriftAudioPlayingID != 0)
		{
			if (UAkComponent* AkComponent = OwnerActor->GetComponentByClass<UAkComponent>())
			{
				const FTriggerDriftParams& TriggerDriftParams = DataCacheMgr->GetTriggerDriftParams();
				const FString& EventName = EntityInterface->GetIsUnderMainPlayerControl() ? TriggerDriftParams.TriggerDriftStopAudio_1P : TriggerDriftParams.TriggerDriftStopAudio;
				AudioMgr->InnerPostEventOnAkComp(EventName, AkComponent);
				TriggerDriftAudioPlayingID = 0;
			}
		}
	}
}

void RoleMovementPipeline::SetTriggerDriftDecalParams(FKGPlayNiagaraParams& InParams, const URoleMovementComponent* MountRMComp, bool bRightOrLeft, const FTriggerDriftParams& TriggerDriftParams)
{
	// 特效的左右指的是火花的朝向,和车的转弯方向相反
	InParams.NiagaraEffectPath = bRightOrLeft ? TriggerDriftParams.TriggerDriftDecalPath_R : TriggerDriftParams.TriggerDriftDecalPath_L;
	InParams.SpawnerID = KGUtils::GetIDByObject(MountRMComp ? MountRMComp->GetOwner() : nullptr);
	FKGAttachedNiagaraSpawnInfo AttachInfo;
	AttachInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseMainMeshComponent;
	InParams.SetAttachedSpawnInfo(AttachInfo);
}

bool RoleMovementPipeline::CalculateMovement(const float timeDelta, URoleMovementComponent* roleMovementComponent, FVector & worldVelocity, FQuat& worldQuat) {

	/*=======================逻辑位移运动计算部分===============
	运动计算来源:
	  1) 本地计算: 动画RootMotion、RootMotionSource、UE Character操控移动。 上层控制互斥模式
				   位移Calculator(基于速度的推进器、抛物线控制器、基于key-point的路径运动器...)。 可按需扩展, 上层组织additive部分并行生效， override的互斥生效
				   MoveCorrector: 按照上层开关规则, 进行位移/旋转数值修正。  可按需扩展, 上层组织哪些部分需要生效并行生效、哪些是互斥生效

	  2) 网络同步: 同步下行位置与朝向

	计算空间:
	  1) 世界空间: 朝向、位置都是世界空间的描述, 有Absolute数据和Delta数据两种
	  2) 本地空间: 朝向、位置都是本地空间(在角色world transform下的空间), 只有Delta数据

	计算模式:
	 1) 叠加模式: world空间下的delta直接叠加, local空间下转到world空间下再进行叠加
	 2) 世界空间抢占模式: 直接根据世界指定位置进行位置设置, 且有且只有一个计算器可以工作

	计算流程:
		SourceMoveMode确定基础运动数值->通过Calculator进行位移叠加、或override抢占-> MoveCorrector进行位移限制修正

		
	例子:

	一个叠加模式复杂例子: 角色开启火箭背包(总是将角色往当前面向上进行位移推进) + 角色进行四向移动 + 黑洞引力场吸附角色
					 火箭背包推进器的Local空间Delta换算成世界空间delta + RootMotion 世界Delta + 黑洞引力场推进器世界delta, 完成整体位移控制

	一个世界空间抢占模式例子: 受击时根据受击位移路劲, 按照规定的速率进行运动
					 路径PathMovementCalculator直接计算世界位置, 然后进行位置直接设置
	
	一些MoveCorrector的应用例子:
		1）基础移动速度MoveCorrector:  RootMotion驱动基础移动， 角色在进行180度朝向改变时, 为了避免明显蛇形位移, 在驱动朝向与面向较大时, 需要进行速度标量的缩小
		2) 攻击中的位移MoveCorrector: 带有RootMotion的攻击动作攻击目标时， 离目标越近，则需要进行速度标量缩小, 控制攻击者离目标的最小距离
		3) 攀爬中的MoveCorrector: 墙面移动使用动作驱动, 但是会受到墙面物理起伏/阻挡, 需要按照攀爬自己的规则进行移动缩放调整
		4) C7的战斗推挤、战斗活动区域限制。
		
		1） 2） 3） 是会根据逻辑状态进行互斥生效管理。 4）可以按需并行开关
	
	骑乘挂接支持:
	 [1] RootMotion源可以来自于坐骑
	 [2] 整个运行的Pipeline, 可以用玩家的逻辑数据(引力场是作用在玩家身上的逻辑数据Thruster、减速buff之类的同理), 配合[1]来计算坐骑的运动
	*/
	
	QUICK_SCOPE_CYCLE_COUNTER(RoleMovementPipeline_CalculateMovement);
	
	FTransform ProxyWorldTrans = MovementContext.GetCurrentActorTransform();

	// 1.RootmotionSource
	bool hasRootMotionSource = false;
	FVector RootmotionSourceTranslationDelta = FVector::ZeroVector;
	FQuat RootmotionSourceQuatDelta = FQuat::Identity;
	// 2.AnimRootmotion
	bool hasAnimRootMotion = false;
	FTransform LocalAnimRootmotionTransform = FTransform::Identity;
	FVector AnimRootmotionTranslationDelta = FVector::ZeroVector;
	FQuat AnimRootmotionQuatDelta = FQuat::Identity;
	
	// 3.RequestedVelocity
	bool hasRequestedVelocity = false;
	FVector Acceleration = FVector::ZeroVector;
	float RequestedSpeed = 0.0f;
	bool EnableLocoThrusterByRequestVelocity = true;
	bool CanCalculatePositionMotion = true;
	bool CanCalculateRotationMotion = true;
	bool LocoYawControllerUseDirectRotation = false; // 强行使用YawController
	FQuat LocoYawDirectRotation = ProxyWorldTrans.GetRotation();

	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("CalculateFromRootmotion");
		//1. 确定WorldSpace下的移动输出源, 得到基础移动delta数据。 输入源关系由LocoInputSources管理
		{
			// 1.1 上层逻辑触发的非基础移动, 会使用RootMotionSource
			bool hasRootMotionSourceKeepGravity = roleMovementComponent->IsMoveKeepGravity();
			hasRootMotionSource = roleMovementComponent->CalculateMovementFromRoomMotionSources(timeDelta, RootmotionSourceTranslationDelta, RootmotionSourceQuatDelta);

			// 1.2 Locomotion层的AnimRootMotion也需要消耗, 可以不应用, 否则会有累积问题
			hasAnimRootMotion = roleMovementComponent->CalculateMovementFromAnimRootMotion(MovementContext, LocalAnimRootmotionTransform);

			// 1.3 基于速度驱动的逻辑
			hasRequestedVelocity = roleMovementComponent->GetHasRequestedVelocity(); 
#if UE_BUILD_DEVELOPMENT
			DebugHasRootMotionSource = hasRootMotionSource;
			DebugOriginRMSDelta = RootmotionSourceTranslationDelta;
			DebugOriginRMSQuatDelta = RootmotionSourceQuatDelta;
			DebugOriginRMSDeltaVel = timeDelta > 0.0f ? RootmotionSourceTranslationDelta.Size() / timeDelta : RootmotionSourceTranslationDelta.Size();
			DebugOriginRMSDeltaVelXY = timeDelta > 0.0f ? RootmotionSourceTranslationDelta.Size2D() / timeDelta : RootmotionSourceTranslationDelta.Size();

			DebugHasAnimRootMotion = hasAnimRootMotion;
			DebugLocalAnimRMTransform = LocalAnimRootmotionTransform;
			DebugLocalAnimRMDeltaVel = timeDelta > 0.0f ? DebugLocalAnimRMTransform.GetTranslation().Size() / timeDelta : DebugLocalAnimRMTransform.GetTranslation().Size();
			DebugLocalAnimRMDeltaVelXY = timeDelta > 0.0f ? DebugLocalAnimRMTransform.GetTranslation().Size2D() / timeDelta : DebugLocalAnimRMTransform.GetTranslation().Size2D();

			DebugHasRequestedVelocity = hasRequestedVelocity;
			DebugRequestedVelocityAcceleration = Acceleration;
			DebugRequestedSpeed = RequestedSpeed;
#endif

			// 1.4 根据配置的优先级进行输入源筛选
			TArray<ELocoInputSource> LocoInputSources = MovementContext.GetLocoInputSources();
			for (int32 i = 0; i < LocoInputSources.Num(); i++)
			{
				bool bCurPrioritInputSourceValid = false;
				if (LocoInputSources[i] == ELocoInputSource::RootmotionSource && hasRootMotionSource)
				{
					bCurPrioritInputSourceValid = true;
					// rootmotionsource 关闭重力 
					if (!hasRootMotionSourceKeepGravity)
					{
						MovementContext.IncreaseIgnoreGravity();
					}
					// Rootmotion期间保持LocoState为地面状态，避免基础移动操控影响
					if (MovementContext.IsRootMotionSourceForceGroundSupport())
					{
						MovementContext.IncreaseHasForceLocoGroundSupportCount();
					}

					MovementContext.AccumulateWorldPosDelta(RootmotionSourceTranslationDelta * RootmotionOutputScale);
					MovementContext.AccumulateLocalRotDelta(RootmotionSourceQuatDelta);

#if UE_BUILD_DEVELOPMENT
					DebugRMSDeltaOutput = RootmotionSourceTranslationDelta * RootmotionOutputScale;
					DebugRMSDeltaOutputVel = timeDelta > 0.0f ? DebugRMSDeltaOutput.Size() / timeDelta : DebugRMSDeltaOutput.Size();
					DebugRMSDeltaOutputVelXY = timeDelta > 0.0f ? DebugRMSDeltaOutput.Size2D() / timeDelta : DebugRMSDeltaOutput.Size2D();
					DebugRMSQuatOutput = RootmotionSourceQuatDelta;
#endif
				}
				else if (LocoInputSources[i] == ELocoInputSource::AnimationRootmotion && hasAnimRootMotion)
				{
					bCurPrioritInputSourceValid = true;
					roleMovementComponent->ApplyAnimRootMotionTransform(MovementContext, LocalAnimRootmotionTransform, AnimRootmotionTranslationDelta, AnimRootmotionQuatDelta);

					MovementContext.AccumulateWorldPosDelta(AnimRootmotionTranslationDelta * RootmotionOutputScale);
					MovementContext.AccumulateLocalRotDelta(DisableAnimRootmotionRotationDuration > 0.0f ? FQuat::Identity : AnimRootmotionQuatDelta);

#if UE_BUILD_DEVELOPMENT
					DebugAnimRMDeltaOutput = AnimRootmotionTranslationDelta * RootmotionOutputScale;
					DebugAnimRMDeltaOutputVel = timeDelta > 0.0f ? DebugAnimRMDeltaOutput.Size() / timeDelta : DebugAnimRMDeltaOutput.Size();
					DebugAnimRMDeltaOutputVelXY = timeDelta > 0.0f ? DebugAnimRMDeltaOutput.Size2D() / timeDelta : DebugAnimRMDeltaOutput.Size2D();
					DebugAnimRMSQuatOutput = DisableAnimRootmotionRotationDuration > 0.0f ? FQuat::Identity : AnimRootmotionQuatDelta;
#endif
				}
				else if (LocoInputSources[i] == ELocoInputSource::RequestVelocity && hasRequestedVelocity)
				{
					bCurPrioritInputSourceValid = true;

					ERequestMoveControlMode RequestMoveMode = roleMovementComponent->GetRequestMoveControlMode();

					if (RequestMoveMode == ERequestMoveControlMode::VelocityWithEngineDefault)
					{
						roleMovementComponent->ApplyRequestedMove(timeDelta, roleMovementComponent->GetMaxAcceleration(),
							roleMovementComponent->GetMaxSpeed(), roleMovementComponent->GroundFriction,
							roleMovementComponent->GetMaxBrakingDeceleration(), Acceleration, RequestedSpeed);

						MovementContext.AccumulateWorldPosDelta(roleMovementComponent->RequestedVelocity.GetSafeNormal() * RequestedSpeed * timeDelta);
						EnableLocoThrusterByRequestVelocity = false;
					}
					else if (RequestMoveMode == ERequestMoveControlMode::VelocityToSetAbsolutePosAndRot)
					{
						MovementContext.OccupyAbsoluteWorldPos(roleMovementComponent->GetRequestMovePosData());
						MovementContext.OccupyAbsoluteWorldRot(roleMovementComponent->GetRequestMoveWorldRotData());
						MovementContext.ResetNeedRotateInstantly();
						CanCalculateRotationMotion = false;
					}
					else if (RequestMoveMode == ERequestMoveControlMode::VelocityToSetAbsolutePosAndUseYawController)
					{
						MovementContext.OccupyAbsoluteWorldPos(roleMovementComponent->GetRequestMovePosData());
						LocoYawControllerUseDirectRotation = true;
						LocoYawDirectRotation = roleMovementComponent->GetRequestMoveWorldRotData();
					}
					else if (RequestMoveMode == ERequestMoveControlMode::VelocityToPosDeltaAndUseYawController)
					{
						MovementContext.AccumulateWorldPosDelta(roleMovementComponent->GetRequestMovePosData());
						LocoYawControllerUseDirectRotation = true;
						EnableLocoThrusterByRequestVelocity = false;
						LocoYawDirectRotation = roleMovementComponent->GetRequestMoveWorldRotData();
					}

#if UE_BUILD_DEVELOPMENT
					DebugRequestedVelocityDeltaOutput = roleMovementComponent->RequestedVelocity.GetSafeNormal() * RequestedSpeed * timeDelta;
					DebugRequestedVelocityDeltaOutputVel = timeDelta > 0.0f ? DebugRequestedVelocityDeltaOutput.Size() / timeDelta : DebugRequestedVelocityDeltaOutput.Size();
					DebugRequestedVelocityOutputVelXY = timeDelta > 0.0f ? DebugRequestedVelocityDeltaOutput.Size2D() / timeDelta : DebugRequestedVelocityDeltaOutput.Size2D();
#endif
				}
				
				if (bCurPrioritInputSourceValid)
				{
					break;
				}
			}
		}

#if UE_BUILD_DEVELOPMENT
		if (ABaseCharacter::IsShowRootMotionDeltaDataInConfig(roleMovementComponent->GetOwner())) {
			MovementContext.SetCalculateWorldTranslationDelta(MovementContext.GetWorldPosDelta());
			MovementContext.SetCalculateWorldRotationDelta(MovementContext.GetLocalRotDelta());
		}
#endif //  UE_BUILD_DEVELOPMENT

	}

	
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("CalculateFromRuleCalculator");
		if(CanCalculatePositionMotion)
		{
			//3. Calculator部分, 可多个并行。
			// 作为基础移动的基础输出Thruster, 要受EnableLocoThrusterByRequestVelocity控制
			if (LocoInputThrusterMC.IsEnabled() && EnableLocoThrusterByRequestVelocity)
			{
				// 直接进行velocity blend, 抛弃掉前面的位移输出, 例如: Notify中的使用
				if(LocoInputThrusterMC.HasStartVelocityBlendIn())
				{
					MovementContext.ClearAccumulateWorldPosDelta();
				}
				
				LocoInputThrusterMC.CalculateMovementTick(timeDelta, MovementContext.GetAllowLocoMove(), ProxyWorldTrans, MovementContext);
			}

			// 进行运动速度的过渡处理
			MovementContext.DoWorldPosDeltaOutputStable(timeDelta);
			
			if(PositionAdditiveITMC.IsEnabled())
			{
				PositionAdditiveITMC.CalculateMovementTick(timeDelta, MovementContext.GetAllowLocoMove(), ProxyWorldTrans, MovementContext);
			}
		}
		
		// 旋转calculator的实现
		// 后续可以按需进行生效的calculator组织
		if(CanCalculateRotationMotion){
			if (MovementContext.GetNeedRotateInstantly())
			{
				LocoYawController.DoRotateInstantlyLogic(MovementContext.GetAllowLocoRot(), MovementContext, MovementContext.GetRotateInstantlyTargetRotator());
				LocoInputThrusterMC.AdjustCurVelocityRot(MovementContext.GetRotateInstantlyTargetRotator());
				MovementContext.ResetNeedRotateInstantly();
				DisableAnimRootmotionRotationDuration = 0.2f;
			}
			else if (LocoYawController.IsSwitchOn() || LocoYawControllerUseDirectRotation)
			{
				LocoYawController.CalculateRotationTick(
					MovementContext.GetAllowLocoRot(), timeDelta, ProxyWorldTrans, MovementContext,
					LocoYawControllerUseDirectRotation, LocoYawDirectRotation);
			}
			
			// 进行LocalSpace、WorldSpace下的数据addtivie累积(可以具有多个)， 或者直接被Override覆盖(逻辑控制上, 最多有一个在work生效, 需要上层控制)

		}
	}

	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("CalculateFromMoveCorrector");
		// 3. MoveCorrector & PostureCorrector 部分
		if(CanCalculateRotationMotion)
		{
			PostureCorrectorManager.DoPostureCorrection(*roleMovementComponent, MovementContext, timeDelta);
		}
			
		if(CanCalculatePositionMotion)
		{
			MovementCorrectorManager.DoMovementCorrection(*roleMovementComponent, MovementContext, timeDelta);

			// 4. 重力的计算
			FVector GravityTranslationDelta = FVector::ZeroVector;
			roleMovementComponent->CalculateGravity(timeDelta, GravityTranslationDelta);
			if (!MovementContext.IsIgnoreGravity()) {
				MovementContext.AccumulateWorldPosDelta(GravityTranslationDelta);
			}

			// 5. 引力场需要最后计算，因为涉及引力原点附近的临界情况计算
			if (GravationalThrusterMC.IsEnabled())
			{
				GravationalThrusterMC.CalculateMovementTick(timeDelta, true, ProxyWorldTrans, MovementContext);
			}

		}
	}

	bool bHasClimbOutput = false;
	if(CanCalculatePositionMotion && CanCalculateRotationMotion)
	{
		// 攀爬处理
		bHasClimbOutput = roleMovementComponent->DoClimbingInPipeline(timeDelta);
	}

	FVector finalWorldMovementDelta = MovementContext.GetFinalWorldPosDelta(ProxyWorldTrans.GetRotation());

	// 对于计算出来的结果进行一次外部机制触发修正处理
	MovementContext.ConsumeReplacedFinalWorldDeltaOuterFromPipeline(finalWorldMovementDelta);
	
	FVector finalXYMD = finalWorldMovementDelta;
	finalXYMD.Z = 0;
	
#if UE_BUILD_DEVELOPMENT
	if (ABaseCharacter::IsShowRootMotionDeltaDataInConfig(roleMovementComponent->GetOwner())) {
		MovementContext.SetFinalWorldTranslationDelta(finalWorldMovementDelta);
	}
#endif //  UE_BUILD_DEVELOPMENT
	
	{
		TRACE_CPUPROFILER_EVENT_SCOPE_STR("CalculateFromFinalStage");
		if(CanCalculatePositionMotion){
			if (roleMovementComponent->IsEnableImpetus()) {
				// 推挤不需要Z上的处理
				TRACE_CPUPROFILER_EVENT_SCOPE_STR("CalculateFromImpetus");
				const FVector ImpetusDelta = roleMovementComponent->OnlyCalculateImpetusDelta(finalXYMD, timeDelta);

			}

			// 战斗区域调整位移
			roleMovementComponent->DealMoveDeltaByMoveConstraint(finalXYMD);
		}

		if (bHasClimbOutput && (FMath::Abs(finalWorldMovementDelta.X - finalXYMD.X) > 1.0f || FMath::Abs(finalWorldMovementDelta.Y - finalXYMD.Y) > 1.0f))
		{
			// 推挤或者战斗区域调整导致最终位移发生变化，重新贴合一次
			finalXYMD.Z = finalWorldMovementDelta.Z;
			roleMovementComponent->ReDoClimbingFitInPipeline(timeDelta, finalXYMD, finalWorldMovementDelta);
		}
		else
		{
			finalWorldMovementDelta.X = finalXYMD.X;
			finalWorldMovementDelta.Y = finalXYMD.Y;
		}
	}


	worldVelocity = finalWorldMovementDelta / timeDelta;
	
	worldQuat = MovementContext.GetFinalWorldRot(ProxyWorldTrans.GetRotation());

	// 对于计算出来的结果进行一次外部机制触发修正处理
	MovementContext.ConsumeReplacedFinalWorldRotationOuterFromPipeline(worldQuat);

#if UE_BUILD_DEVELOPMENT
	DebugFinalWorldDelta = finalWorldMovementDelta;
	DebugFinalWorldQuat = worldQuat;
	DebugFinalWorldDeltaVel = timeDelta > 0.0f ? DebugFinalWorldDelta.Size() / timeDelta : DebugFinalWorldDelta.Size();
	DebugFinalWorldDeltaVelXY = timeDelta > 0.0f ? DebugFinalWorldDelta.Size2D() / timeDelta : DebugFinalWorldDelta.Size2D();
#endif //  UE_BUILD_DEVELOPMENT
	return true;

}

bool RoleMovementPipeline::CalculateNetShadowMovement(const float delta, URoleMovementComponent & RoleMovementComponent, FVector &worldPos, FRotator & worldRotator)
{
	bool TransformChanged = MovementContext.ConsumeNetShadowMovement(worldPos, worldRotator);
	if(!PostureCorrectorManager.HasPostureCorrectorWorking())
	{
		return TransformChanged;
	}
	
	FTransform OldActorTrans = MovementContext.GetCurrentActorTransform();
	if(TransformChanged)
	{
		// 更新shadow 信息, 送给后续的pipeline计算
		// todo 这里不能这样做, 或者posture corrector阶段, 一定要用当前生效的transform去做
		MovementContext.AccumulateWorldPosDelta(worldPos - OldActorTrans.GetLocation());
		MovementContext.OccupyAbsoluteWorldRot(worldRotator.Quaternion());
	}
	
	TransformChanged |= PostureCorrectorManager.DoPostureCorrection(RoleMovementComponent, MovementContext, delta);

	if(TransformChanged)
	{
		worldRotator = MovementContext.GetFinalWorldRot(OldActorTrans.GetRotation()).Rotator();
		// 这里位移获取要注意, 是使用当前快照的旋转进行世界位置的获取, 要跟CalculateMovement一样
		worldPos = MovementContext.GetFinalWorldPosDelta(OldActorTrans.GetRotation()) + OldActorTrans.GetTranslation();
	
	}
	return TransformChanged;
}

#if UE_BUILD_DEVELOPMENT
void RoleMovementPipeline::AppendDebugInfo(FString& infoOut) {
	infoOut.Append(TEXT("==================RoleMovementPipeline================\n"));
	infoOut.Appendf(TEXT("RootmotionOutputScale:%s  DisableAnimRootmotionRotationDuration:%f\n"), *(RootmotionOutputScale.ToString()), DisableAnimRootmotionRotationDuration);
	infoOut.Appendf(TEXT("HasRootMotionSource:%d [OriginRootmotionSource] Delta:%s DeltaVel:%f DeltaVelXY:%f QuatDelta:%s \n"), DebugHasRootMotionSource, 
		*DebugOriginRMSDelta.ToString(), DebugOriginRMSDeltaVel, DebugOriginRMSDeltaVelXY, *DebugOriginRMSQuatDelta.Rotator().ToString());
	infoOut.Appendf(TEXT("[RootmotionSourceOutput]Delta:%s DeltaVel:%f DeltaVelXY:%f QuatDelta:%s \n"),
		*DebugRMSDeltaOutput.ToString(), DebugRMSDeltaOutputVel, DebugRMSDeltaOutputVelXY, *DebugRMSQuatOutput.Rotator().ToString());
	infoOut.Appendf(TEXT("HasAnimRootMotion:%d [OriginAnimRootmotion] Delta:%s DeltaVel:%f DeltaVelXY:%f QuatDelta:%s \n"), DebugHasAnimRootMotion,
			*DebugLocalAnimRMTransform.GetTranslation().ToString(), DebugLocalAnimRMDeltaVel, DebugLocalAnimRMDeltaVelXY, *DebugLocalAnimRMTransform.GetRotation().Rotator().ToString());
	infoOut.Appendf(TEXT("[AnimRootmotionOutput]Delta:%s DeltaVel:%f DeltaVelXY:%f QuatDelta:%s \n"),
		*DebugAnimRMDeltaOutput.ToString(), DebugAnimRMDeltaOutputVel, DebugAnimRMDeltaOutputVelXY, *DebugAnimRMSQuatOutput.Rotator().ToString());
	infoOut.Appendf(TEXT("HasRequestedVelocity:%d [OriginRequestedVelocity] Acceleration:%s RequestedSpeed:%f \n"), DebugHasRequestedVelocity,
		*DebugRequestedVelocityAcceleration.ToString(), DebugRequestedSpeed);
	infoOut.Appendf(TEXT("[RequestedVelocityOutput]Delta:%s DeltaVel:%f DeltaVelXY:%f\n"),
		*DebugRequestedVelocityDeltaOutput.ToString(), DebugRequestedVelocityDeltaOutputVel, DebugRequestedVelocityOutputVelXY);
	infoOut.Appendf(TEXT("[FinalOutput]Delta:%s DeltaVel:%f DeltaVelXY:%f QuatDelta:%s \n"),
		*DebugFinalWorldDelta.ToString(), DebugFinalWorldDeltaVel, DebugFinalWorldDeltaVelXY, *DebugFinalWorldQuat.Rotator().ToString());
	infoOut.Appendf(TEXT("[TriggerDrift] bNeedAttach=%d \n"), MovementContext.IsTriggerDriftDecalNeedAttach());
	
	LocoInputThrusterMC.AppendDebugInfo(infoOut);

	LocoYawController.AppendDebugInfo(infoOut);
	GravationalThrusterMC.AppendDebugInfo(infoOut);
	PositionAdditiveITMC.AppendDebugInfo(infoOut);

	MovementContext.AppendDebugInfo(infoOut);
	MovementCorrectorManager.AppendDebugInfo(infoOut);
	PostureCorrectorManager.AppendDebugInfo(infoOut);

	ResetPipeLineDebugInfo();
};

void RoleMovementPipeline::ResetPipeLineDebugInfo()
{
	// 1.RootmotionSource
	DebugHasRootMotionSource = false;
	DebugOriginRMSDelta = FVector::ZeroVector;
	DebugOriginRMSDeltaVel = 0.0f;
	DebugOriginRMSDeltaVelXY = 0.0f;
	DebugOriginRMSQuatDelta = FQuat::Identity;

	DebugRMSDeltaOutput = FVector::ZeroVector;
	DebugRMSDeltaOutputVel = 0.0f;
	DebugRMSDeltaOutputVelXY = 0.0f;
	DebugRMSQuatOutput = FQuat::Identity;
	// 2.AnimRootmotion
	DebugHasAnimRootMotion = false;
	DebugLocalAnimRMTransform = FTransform::Identity;
	DebugLocalAnimRMDeltaVel = 0.0f;
	DebugLocalAnimRMDeltaVelXY = 0.0f;

	DebugAnimRMDeltaOutput = FVector::ZeroVector;
	DebugAnimRMDeltaOutputVel = 0.0f;
	DebugAnimRMDeltaOutputVelXY = 0.0f;
	DebugAnimRMSQuatOutput = FQuat::Identity;
	// 3.RequestedVelocity
	DebugHasRequestedVelocity = false;
	DebugRequestedVelocityAcceleration = FVector::ZeroVector;
	DebugRequestedSpeed = 0.0f;

	DebugRequestedVelocityDeltaOutput = FVector::ZeroVector;
	DebugRequestedVelocityDeltaOutputVel = 0.0f;
	DebugRequestedVelocityOutputVelXY = 0.0f;
	// 4. FinalRes
	DebugFinalWorldDelta = FVector::ZeroVector;
	DebugFinalWorldQuat = FQuat::Identity;
	DebugFinalWorldDeltaVel = 0.0f;
	DebugFinalWorldDeltaVelXY = 0.0f;
}
#endif
