// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Movement/MovementPipeline/MovementCorrector/MovementCorrectorManager.h"

#include "3C/Movement/MovementPipeline/MovementCorrector/OnRideMountMovementCorrector.h"
#include "3C/Movement/MovementPipeline/MovementCorrector/MovementCorrectorBase.h"
#include "3C/Movement/MovementPipeline/MovementCorrector/OnGroundMovementCorrector.h"
#include "3C/Movement/MovementPipeline/MovementCorrector/DestSmoothCorrector.h"
#include "3C/Movement/MovementPipeline/MovementCorrector/MotionWarpCorrector.h"
#include "3C/Movement/MovementPipeline/MovementCorrector/OnWaterMovementCorrector.h"
#include "3C/Movement/MovementPipeline/MovementCorrector/TwoRoleAnimCoordinateMC.h"
#include  "3C/Movement/RoleMovementComponent.h"


FMovementCorrectorManager::FMovementCorrectorManager()
{
}

FMovementCorrectorManager::~FMovementCorrectorManager()
{
	
	for (int index = 0; index < (int)EMovementCorrectorType::Max; ++index) {
		auto correctorPtr = MovementCorrectors[index];
		if (correctorPtr != nullptr) {
			correctorPtr->Reset(MoveContext);
			delete correctorPtr;
		}
		MovementCorrectors[index] = nullptr;
	}

	MoveContext = nullptr;
	Owner = nullptr;
}

void FMovementCorrectorManager::Init(URoleMovementComponent& MovementComponent)
{
	CurActiveType = EMovementCorrectorType::None;
	for (int index = 0; index < (int)EMovementCorrectorType::Max; ++index)
	{
		MovementCorrectorTokens[index] = 1;
	}

	Owner = &MovementComponent;
	MoveContext = &MovementComponent.GetRoleMP().GetMovementContext();
}

void FMovementCorrectorManager::DoMovementCorrection(const URoleMovementComponent& MovementComponent, MovementContext& MC, float DeltaTime)
{
	EMovementCorrectorType WorkingType = GetActiveType();

	if (WorkingType != EMovementCorrectorType::None)
	{
		if (MovementCorrectors[(int)WorkingType] != nullptr)
		{
			MovementCorrectors[(int)WorkingType]->DoMovementCorrection(MovementComponent, MC, DeltaTime);
		}
	}

	for (EMovementCorrectorType ForceActiveType : ForceActiveTypes)
	{
		if (WorkingType != ForceActiveType && MovementCorrectors[(int)ForceActiveType] != nullptr)
		{
			MovementCorrectors[(int)ForceActiveType]->DoMovementCorrection(MovementComponent, MC, DeltaTime);
		}
	}
}

FMovementCorrectorBase* FMovementCorrectorManager::CreateMovementCorrector(EMovementCorrectorType MovementCorrectorType)
{
	FMovementCorrectorBase* NewCorrector = nullptr;
	switch (MovementCorrectorType)
	{
	case EMovementCorrectorType::OnGroundCorrector:
		NewCorrector = new FOnGroundMovementCorrector();
		break;
	case EMovementCorrectorType::MotionWarpCorrector:
		NewCorrector = new MotionWarpCorrector();
		break;
	case EMovementCorrectorType::DestSmoothCorrector:
		NewCorrector = new FDestSmoothCorrector();
		break;
	case EMovementCorrectorType::OnRideMountCorrector:
		NewCorrector = new FOnRideMountMovementCorrector();
		break;
	case EMovementCorrectorType::OnWaterCorrector:
		NewCorrector = new FOnWaterMovementCorrector();
		break;
	case EMovementCorrectorType::TwoRoleAnimCoordinateMC:
		NewCorrector = new FTwoRoleAnimCoordinateMC();
		break;
	default:
		break;
	}

	if (NewCorrector == nullptr) {
		return nullptr;
	}
	NewCorrector->Init(MoveContext);
	return NewCorrector;
}

bool FMovementCorrectorManager::EnsureMoveCorrectorAvailable(ECorrectorObtainPriority pri, EMovementCorrectorType MovementCorrectorType)
{
	const int CorrectorTypeIndex = (int)MovementCorrectorType;
	if (MovementCorrectorWorkingPriorities[CorrectorTypeIndex] != ECorrectorObtainPriority::NoUsed && pri < MovementCorrectorWorkingPriorities[CorrectorTypeIndex]) {
		return false;
	}

	if (MovementCorrectors[CorrectorTypeIndex] == nullptr)
	{
		MovementCorrectors[CorrectorTypeIndex] = CreateMovementCorrector(MovementCorrectorType);
		if(MovementCorrectors[CorrectorTypeIndex] == nullptr)
		{
			return false;
		}
		MovementCorrectors[CorrectorTypeIndex]->Reset(MoveContext);
	}

	return true;
}

int FMovementCorrectorManager::GetCorrectorCurToken(EMovementCorrectorType mcType)
{
	int mcIndex = (int)mcType;
	return MovementCorrectorTokens[mcIndex];
}

int FMovementCorrectorManager::ObtainMoveCorrector(ECorrectorObtainPriority pri, EMovementCorrectorType mcType)
{
	int mcIndex = (int)mcType;

	if (mcType != EMovementCorrectorType::None && MovementCorrectorWorkingPriorities[mcIndex] != pri)
	{
		MovementCorrectorTokens[mcIndex] += 1;

		if (MovementCorrectorTokens[mcIndex] > MAX_TOKEN)
		{
			MovementCorrectorTokens[mcIndex] = 1;
		}

		MovementCorrectorWorkingPriorities[mcIndex] = pri;
	}

	UpdateCurActiveType(mcType);
	return MovementCorrectorTokens[mcIndex];
}

bool FMovementCorrectorManager::ReleaseMoveCorrector(int releasedToken, EMovementCorrectorType mcType)
{
	int mcIndex = (int)mcType;

	auto* mc = MovementCorrectors[mcIndex];
	if (mc == nullptr)
	{
		return false;
	}

	if (MovementCorrectorTokens[mcIndex] != releasedToken)
	{
		return false;
	}

	MovementCorrectorWorkingPriorities[mcIndex] = ECorrectorObtainPriority::NoUsed;
	UpdateCurActiveType(mcType);
	return true;
}



int FMovementCorrectorManager::ObtainTranslationWarpWithFixMode(ECorrectorObtainPriority pri, MovementContext& MC, const FVector& targetpos, ERootWarpMode rootWarpMode, const FName& WarpTargetName)
{
	if (!EnsureMoveCorrectorAvailable(pri, EMovementCorrectorType::MotionWarpCorrector)) {
		return -1;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::MotionWarpCorrector]);
	if (!motionWarpCorrector) {
		return -1;
	}

	int outToken = ObtainMoveCorrector(pri, EMovementCorrectorType::MotionWarpCorrector);
	motionWarpCorrector->UseTranslationWarpWithFixMode(MC, targetpos, rootWarpMode, WarpTargetName);
	return outToken;
}

bool FMovementCorrectorManager::UpdateRotationWarpArgWithFixMode(int mcToken, MovementContext& MC, int transOperateMask, const float pitch, const float targetYaw, const float roll)
{
	if (CurActiveType != EMovementCorrectorType::MotionWarpCorrector) {
		return false;
	}

	int mcIndex = (int)CurActiveType;
	if (MovementCorrectorTokens[mcIndex] != mcToken) {
		return false;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[mcIndex]);
	if (!motionWarpCorrector) {
		return false;
	}

	motionWarpCorrector->UpdateRotationWarpArgWithFixMode(MC, transOperateMask, pitch, targetYaw, roll);
	return true;
}

bool  FMovementCorrectorManager::UpdateWarpRate(int mcToken, float Rate) {
	if (CurActiveType != EMovementCorrectorType::MotionWarpCorrector) {
		return false;
	}

	int mcIndex = (int)CurActiveType;
	if (MovementCorrectorTokens[mcIndex] != mcToken) {
		return false;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[mcIndex]);
	if (!motionWarpCorrector) {
		return false;
	}

	motionWarpCorrector->UpdateWarpRate(Rate);
	return true;
}

int FMovementCorrectorManager::ObtainRotationWarpWithFixMode(ECorrectorObtainPriority pri, MovementContext& MC, int transOperateMask, const float pitch, const float targetYaw, const float roll)
{
	if (!EnsureMoveCorrectorAvailable(pri, EMovementCorrectorType::MotionWarpCorrector)) {
		return -1;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::MotionWarpCorrector]);
	if (!motionWarpCorrector) {
		return -1;
	}
	int outToken = ObtainMoveCorrector(pri, EMovementCorrectorType::MotionWarpCorrector);
	motionWarpCorrector->UseRotationWarpWithFixMode(MC, transOperateMask, pitch, targetYaw, roll);

	return outToken;
}



int FMovementCorrectorManager::ObtainMotionWarpWithActorSocket(ECorrectorObtainPriority pri, MovementContext& MC, ERootWarpMode rootWarpMode, TWeakObjectPtr<AActor> Actor, const FName& SocketName, const FVector& Offset)
{
	if (!EnsureMoveCorrectorAvailable(pri, EMovementCorrectorType::MotionWarpCorrector)) {
		return -1;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::MotionWarpCorrector]);
	if (!motionWarpCorrector) {
		return -1;
	}

	int outToken = ObtainMoveCorrector(pri, EMovementCorrectorType::MotionWarpCorrector);
	motionWarpCorrector->UseSocketWarpWithFixMode(MC, rootWarpMode, Actor, SocketName, Offset);

	return outToken;
}

int FMovementCorrectorManager::ObtainMotionWarpWithActorSpaceTransform(ECorrectorObtainPriority pri, MovementContext& MC, ERootWarpMode rootWarpMode, TWeakObjectPtr<AActor> Actor, const FTransform& targetTransformInActorSpace)
{
	if (!EnsureMoveCorrectorAvailable(pri, EMovementCorrectorType::MotionWarpCorrector)) {
		return -1;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::MotionWarpCorrector]);
	if (!motionWarpCorrector) {
		return -1;
	}

	int outToken = ObtainMoveCorrector(pri, EMovementCorrectorType::MotionWarpCorrector);
	motionWarpCorrector->UseActorSpaceTransformWarpWithFixMode(MC, rootWarpMode, Actor, targetTransformInActorSpace);

	return outToken;
}

int FMovementCorrectorManager::ObtainRotationWarpWithLocoInputMode(ECorrectorObtainPriority pri, MovementContext& MC, const float inputQueryDuration, EFaceDirectionInputMode FaceMode)
{
	if (!EnsureMoveCorrectorAvailable(pri, EMovementCorrectorType::MotionWarpCorrector)) {
		return -1;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::MotionWarpCorrector]);
	if (!motionWarpCorrector) {
		return false;
	}

	int outToken = ObtainMoveCorrector(pri, EMovementCorrectorType::MotionWarpCorrector);
	motionWarpCorrector->UseRotationWarpWithLocoInputMode(MC, inputQueryDuration, FaceMode);

	return outToken;
}

bool FMovementCorrectorManager::StopMotionWarp(const FName& WarpTargetName)
{
	// MotionWarp Notify结束时调用
	if (CurActiveType != EMovementCorrectorType::MotionWarpCorrector) {
		return false;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::MotionWarpCorrector]);
	if (!motionWarpCorrector) {
		return false;
	}

	if (motionWarpCorrector->GetCurWarpTargetName().IsEqual(WarpTargetName))
	{
		motionWarpCorrector->Reset(MoveContext);
	}
	
	return true;
}


bool FMovementCorrectorManager::StartMotionWarp(float duration, float startTime, ERotationWrapDirection RotDirection, const FTransform& localStartRMTrans, const FTransform& localEndRMTrans, UAnimSequenceBase* Animation, const FName& WarpTargetName)
{
	// 先用obtain设置参数, 然后anim 里面进行notify进行实际启动

	if (CurActiveType != EMovementCorrectorType::MotionWarpCorrector) {
		return false;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::MotionWarpCorrector]);
	if (!motionWarpCorrector) {
		return false;
	}

	
	
	motionWarpCorrector->InitWorldSpaceWarpTransform(MoveContext, duration, startTime, RotDirection, localStartRMTrans, localEndRMTrans, Animation, WarpTargetName);
	return true;
}

bool FMovementCorrectorManager::ReleaseMotionWarp(int token)
{
	if (CurActiveType != EMovementCorrectorType::MotionWarpCorrector) {
		return false;
	}

	auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::MotionWarpCorrector]);
	if (!motionWarpCorrector) {
		return false;
	}
	/*
	* 由于不同的MotionWarp的motionWarpCorrector是同一个对象，同时有需求是同一段动画使用多个MotionWarp，其中部分参数在单个MotionWarp结束时不去清理
	* 所以需要在这里清理一下这些参数
	*/
	motionWarpCorrector->ResetSpecialParams(); 
	return ReleaseMoveCorrector(token, EMovementCorrectorType::MotionWarpCorrector);
}

void FMovementCorrectorManager::UpdateTargetPosAndRotation(const FVector& targetpos, const FRotator& targetRot)
{
	if (auto* motionWarpCorrector = static_cast<MotionWarpCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::MotionWarpCorrector]))
	{
		motionWarpCorrector->UpdateTargetPosAndRotation(targetpos, targetRot);
	}
}

void FMovementCorrectorManager::SetDestLocSmoothParam(const FVector InStartPos, const FVector InEndPos)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::DestSmoothCorrector))
	{
		return;
	}

	FDestSmoothCorrector* DestSmoothCorrector = static_cast<FDestSmoothCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::DestSmoothCorrector]);
	if (!DestSmoothCorrector) {
		return;
	}

	DestSmoothCorrector->SetDestLocSmoothParam(InStartPos, InEndPos);
}

void FMovementCorrectorManager::SetDestRotSmoothParam(float InStartYaw, float InEndYaw)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::DestSmoothCorrector))
	{
		return;
	}

	FDestSmoothCorrector* DestSmoothCorrector = static_cast<FDestSmoothCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::DestSmoothCorrector]);
	if (!DestSmoothCorrector) {
		return;
	}

	DestSmoothCorrector->SetDestRotSmoothParam(InStartYaw, InEndYaw);
}

void FMovementCorrectorManager::SetDestSmoothCorrectorType(ESmoothCorrectorType Type, float Speed)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::DestSmoothCorrector))
	{
		return;
	}

	FDestSmoothCorrector* DestSmoothCorrector = static_cast<FDestSmoothCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::DestSmoothCorrector]);
	if (!DestSmoothCorrector) {
		return;
	}

	DestSmoothCorrector->SetSmoothCorrectorType(Type, Speed);
}

int FMovementCorrectorManager::ObtainTwoRoleAnimCoordinateMC(KGAnimPlayReqID OwnAnimID, KGAnimPlayReqID CollaboratorAnimID, KGEntityID CollaboratorUID, bool EnsurePhysicsSafe, float InterTime)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::TwoRoleAnimCoordinateMC))
	{
		return -1;
	}

	auto* TwoRoleMC = static_cast<FTwoRoleAnimCoordinateMC *>(MovementCorrectors[(int)EMovementCorrectorType::TwoRoleAnimCoordinateMC]);
	if (!TwoRoleMC) {
		return false;
	}

	int outToken = ObtainMoveCorrector(ECorrectorObtainPriority::Action, EMovementCorrectorType::TwoRoleAnimCoordinateMC);
	TwoRoleMC->SetTwoRoleCoordinateParams(OwnAnimID, CollaboratorAnimID, CollaboratorUID, EnsurePhysicsSafe, InterTime);
	return outToken;
}

bool FMovementCorrectorManager::ReleaseTwoRoleAnimCoordinateMC(int Token)
{
	return ReleaseMoveCorrector(Token, EMovementCorrectorType::TwoRoleAnimCoordinateMC);
}

void FMovementCorrectorManager::SetDestSmoothCorrectorParam(float InSmoothTime, float InHalfTime)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::DestSmoothCorrector))
	{
		return;
	}

	FDestSmoothCorrector* DestSmoothCorrector = static_cast<FDestSmoothCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::DestSmoothCorrector]);
	if (!DestSmoothCorrector) {
		return;
	}

	DestSmoothCorrector->SetDestSmoothCorrectorParam(InSmoothTime, InHalfTime);
}

void FMovementCorrectorManager::SetDestSmoothTargetActor(AActor* TargetActor)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::DestSmoothCorrector))
	{
		return;
	}

	FDestSmoothCorrector* DestSmoothCorrector = static_cast<FDestSmoothCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::DestSmoothCorrector]);
	if (!DestSmoothCorrector) {
		return;
	}

	DestSmoothCorrector->SetDestTargetActor(TargetActor);
}

void FMovementCorrectorManager::SetRideMountCorrectorDirInterpolateParam(float InValue)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnRideMountCorrector))
	{
		return;
	}

	FOnRideMountMovementCorrector* OnRideMountCorrector = static_cast<FOnRideMountMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnRideMountCorrector]);
	if (!OnRideMountCorrector) {
		return;
	}

	OnRideMountCorrector->SetRidingDirInterpolateParam(InValue);
}

void FMovementCorrectorManager::SetRideMountCorrectorSpeedToRidingDirInterpolateCurve(UCurveFloat* InCurve)
{

	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnRideMountCorrector))
	{
		return;
	}

	FOnRideMountMovementCorrector* OnRideMountCorrector = static_cast<FOnRideMountMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnRideMountCorrector]);
	if (!OnRideMountCorrector) {
		return;
	}

	OnRideMountCorrector->SetSpeedToRidingDirInterpolateCurve(InCurve);
}

void FMovementCorrectorManager::SetRideMountCorrectorSpeedToMaxDriftSpeedCurve(UCurveFloat* InCurve)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnRideMountCorrector))
	{
		return;
	}

	FOnRideMountMovementCorrector* OnRideMountCorrector = static_cast<FOnRideMountMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnRideMountCorrector]);
	if (!OnRideMountCorrector) {
		return;
	}

	OnRideMountCorrector->SetSpeedToMaxDriftSpeedCurve(InCurve);
}

void FMovementCorrectorManager::SetRideMountCorrectorDriftSpeedRateToSpeedDecayCurve(UCurveFloat* InCurve)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnRideMountCorrector))
	{
		return;
	}

	FOnRideMountMovementCorrector* OnRideMountCorrector = static_cast<FOnRideMountMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnRideMountCorrector]);
	if (!OnRideMountCorrector) {
		return;
	}

	OnRideMountCorrector->SetDriftSpeedRateToSpeedDecayCurve(InCurve);
}

void FMovementCorrectorManager::SetRideMountCorrectorSpeedToDriftForceDecayHalfTimeCurve(UCurveFloat* InCurve)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnRideMountCorrector))
	{
		return;
	}

	FOnRideMountMovementCorrector* OnRideMountCorrector = static_cast<FOnRideMountMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnRideMountCorrector]);
	if (!OnRideMountCorrector) {
		return;
	}

	OnRideMountCorrector->SetSpeedToDriftForceDecayHalfTimeCurve(InCurve);
}

void FMovementCorrectorManager::SetRideMountCorrectorSpeedToDriftForceYawHalfTimeCurve(UCurveFloat* InCurve)
{

	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnRideMountCorrector))
	{
		return;
	}

	FOnRideMountMovementCorrector* OnRideMountCorrector = static_cast<FOnRideMountMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnRideMountCorrector]);
	if (!OnRideMountCorrector) {
		return;
	}

	OnRideMountCorrector->SetSpeedToDriftForceYawHalfTimeCurve(InCurve);
}

void FMovementCorrectorManager::SetRideMountCorrectorAllowDrift(bool InAllow)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnRideMountCorrector))
	{
		return;
	}

	FOnRideMountMovementCorrector* OnRideMountCorrector = static_cast<FOnRideMountMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnRideMountCorrector]);
	if (!OnRideMountCorrector) {
		return;
	}

	OnRideMountCorrector->SetRidingAllowDrift(InAllow);
}

void FMovementCorrectorManager::SetRideMountCorrectorLeftWheelToCenterDist(float InValue)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnRideMountCorrector))
	{
		return;
	}

	FOnRideMountMovementCorrector* OnRideMountCorrector = static_cast<FOnRideMountMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnRideMountCorrector]);
	if (!OnRideMountCorrector) {
		return;
	}

	OnRideMountCorrector->SetLeftWheelToCenterDist(InValue);
}

void FMovementCorrectorManager::SetRideMountCorrectorRightWheelToCenterDist(float InValue)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnRideMountCorrector))
	{
		return;
	}

	FOnRideMountMovementCorrector* OnRideMountCorrector = static_cast<FOnRideMountMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnRideMountCorrector]);
	if (!OnRideMountCorrector) {
		return;
	}

	OnRideMountCorrector->SetRightWheelToCenterDist(InValue);
}

void FMovementCorrectorManager::SetWaterMovementCorrectorWaterSurfaceDelta(const float& InDelta, const float& InDuration)
{
	if (!EnsureMoveCorrectorAvailable(ECorrectorObtainPriority::Action, EMovementCorrectorType::OnWaterCorrector))
	{
		return;
	}

	FOnWaterMovementCorrector* OnWaterMoveCorrector = static_cast<FOnWaterMovementCorrector*>(MovementCorrectors[(int)EMovementCorrectorType::OnWaterCorrector]);
	if (!OnWaterMoveCorrector) {
		return;
	}

	OnWaterMoveCorrector->SetWaterSurfaceDelta(InDelta, InDuration);
}



EMovementCorrectorType FMovementCorrectorManager::GetActiveType() const
{
	return CurActiveType;
}

void FMovementCorrectorManager::UpdateCurActiveType(EMovementCorrectorType PreferedTypeWhenEqual)
{
	EMovementCorrectorType NewCurActiveType = EMovementCorrectorType::None;
	ECorrectorObtainPriority CurMaxPriority = ECorrectorObtainPriority::NoUsed;

	for (int index = 0; index < (int)EMovementCorrectorType::Max; ++index)
	{
		if ((int)MovementCorrectorWorkingPriorities[index] > (int)CurMaxPriority)
		{
			CurMaxPriority = MovementCorrectorWorkingPriorities[index];
			NewCurActiveType = (EMovementCorrectorType)index;
		}
		else if ((int)MovementCorrectorWorkingPriorities[index] == (int)CurMaxPriority && MovementCorrectorWorkingPriorities[index] != ECorrectorObtainPriority::NoUsed && (int)PreferedTypeWhenEqual == index)
		{
			// CurMaxPriority = MovementCorrectorWorkingPriorities[index];
			NewCurActiveType = PreferedTypeWhenEqual;
		}
	}

	SetMovementCorrector(NewCurActiveType);
}

void FMovementCorrectorManager::SetMovementCorrector(EMovementCorrectorType MovementCorrectorType)
{
	if (CurActiveType == MovementCorrectorType)
	{
		return;
	}

	// 不是ForceAcive的Corrector，可以失活并Reset
	if (!ForceActiveTypes.Contains(CurActiveType))
	{
		// Reset“正在激活，即将失活的MovementCorrector”
		if (MovementCorrectors[(int)CurActiveType])
		{
			MovementCorrectors[(int)CurActiveType]->Reset(MoveContext);
		}
	}	

	if (MovementCorrectorType <= EMovementCorrectorType::None || MovementCorrectorType >= EMovementCorrectorType::Max)
	{
		CurActiveType = EMovementCorrectorType::None;
		return;
	}

	CurActiveType = MovementCorrectorType;

	if (MovementCorrectors[(int)MovementCorrectorType] == nullptr)
	{
		MovementCorrectors[(int)MovementCorrectorType] = CreateMovementCorrector(MovementCorrectorType);
	}

	// 不是ForceAcive的Corrector，可以重新激活并Reset
	if (!ForceActiveTypes.Contains(MovementCorrectorType))
	{
		MovementCorrectors[(int)MovementCorrectorType]->Reset(MoveContext);
	}
}

bool FMovementCorrectorManager::ForceActivateMoveCorrector(EMovementCorrectorType mcType)
{
	if (ForceActiveTypes.Contains(mcType))
	{
		// 已经处于ForceActive状态，忽略
		return false;
	}
	
	ForceActiveTypes.Add(mcType);
	
	if (CurActiveType == mcType)
	{
		// 与优先级管理的CurActiveType一致，已经Activate，忽视
		return true;
	}

	if (MovementCorrectors[(int)mcType] == nullptr)
	{
		MovementCorrectors[(int)mcType] = CreateMovementCorrector(mcType);
	}
		
	MovementCorrectors[(int)mcType]->Reset(MoveContext);

	return true;
}

bool FMovementCorrectorManager::ForceDeActivateMoveCorrector(EMovementCorrectorType mcType)
{
	if (!ForceActiveTypes.Contains(mcType))
	{
		// 不处于ForceActive状态，忽略
		return false;
	}

	ForceActiveTypes.Remove(mcType);

	if (CurActiveType == mcType)
	{
		// 与优先级管理的CurActiveType一致，仍然需要Activate，忽视
		return true;
	}

	if (MovementCorrectors[(int)CurActiveType])
	{
		MovementCorrectors[(int)mcType]->Reset(MoveContext);
	}

	return true;
}

#if UE_BUILD_DEVELOPMENT
void FMovementCorrectorManager::AppendDebugInfo(FString& infoOut)
{
	EMovementCorrectorType WorkingType = GetActiveType();
	if (WorkingType != EMovementCorrectorType::None)
	{
		if (MovementCorrectors[(int)WorkingType] != nullptr)
		{
			MovementCorrectors[(int)WorkingType]->AppendDebugInfo(infoOut);
		}
	}
};
#endif