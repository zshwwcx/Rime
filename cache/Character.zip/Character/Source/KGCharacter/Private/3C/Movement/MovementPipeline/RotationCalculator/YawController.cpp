// #pragma once
#include "3C/Movement/MovementPipeline/RotationCalculator/YawController.h"
#include "Misc/MathFormula.h"


void YawController::Reset()
{
	LastValidInput.Set(0.0f, 0.0f, 0.0f);
}

// 只能是世界空间下的计算
bool YawController::CalculateRotationTick(bool isNeedOutput, float deltaTime, const FTransform& baseTrans, MovementContext& mc, bool UseDirectRot, const FQuat &DirectTargetRotation) {
	if (!isNeedOutput) {
		return false;
	}

	FRotator currentRotator = baseTrans.Rotator();
	float currentYaw = FRotator::NormalizeAxis(currentRotator.Yaw);
	float finalTargetYaw = currentYaw;

	// ALS下会根据速度自己每帧算
	bool FinalUseDirectRot = (ArgSourceMode != EArgSourceMode::ALSVelocityRotYaw) && UseDirectRot;
	float RealInterpolationArg = FinalUseDirectRot ? 0.05f : InterpolationArg;

	if (FinalUseDirectRot)
	{
		LastValidInput = FVector::ZeroVector;
		finalTargetYaw = DirectTargetRotation.Rotator().Yaw;
	}
	else
	{
		// 进来的数据是已经换算好的世界空间下的方向Vector了, 换算的部分是由控制层(摇杆输入、AI寻路)对应模式下, 进行基础移动层功能调用时, 进行输入解释换算的
		if (ArgSourceMode == EArgSourceMode::LocoInputVector) {
			FVector InputVec = mc.GetLocoInputVec();
			InputVec.Z = 0.0f;

			bool hasLocoInput = mc.GetHasLocoInput();
			if (hasLocoInput && !InputVec.IsNearlyZero())
			{
				// 有可能仅有Z轴输入
				LastValidInput = InputVec;
			}
			else if (bUseLastValidInputWhenLostInput && !LastValidInput.IsNearlyZero())
			{
				InputVec = LastValidInput;
			}

			if (!InputVec.IsNearlyZero())
			{
				finalTargetYaw = InputVec.GetSafeNormal().Rotation().Yaw;
			}
		}
		else if(ArgSourceMode == EArgSourceMode::ActionInputVector){
			finalTargetYaw = mc.GetActionInputVec().Rotation().Yaw;
		}
		else if (ArgSourceMode == EArgSourceMode::TargetPos) {
			finalTargetYaw = (TargetPos - baseTrans.GetTranslation()).GetSafeNormal().Rotation().Yaw;
		}
		else if (ArgSourceMode == EArgSourceMode::TargetActor) {
			// 用于处理隐身状态下不跟随旋转，Todo:待C++隐身状态定义完善后更新接口
			// https://gamecloud-redmine.corp.kuaishou.com/1007/projects/c7/issues/174569
			if (TargetActor.IsValid() && !TargetActor->IsHidden()) {	
				finalTargetYaw = (TargetActor->GetActorLocation() - baseTrans.GetTranslation()).GetSafeNormal().Rotation().Yaw;
			}
		}
		else  if (ArgSourceMode == EArgSourceMode::FixedValue) {
			finalTargetYaw = TargetYaw;
		}
		else  if (ArgSourceMode == EArgSourceMode::FixedDeltaSpeed) {
			finalTargetYaw = currentYaw + TargetYaw * deltaTime;
		}
		else  if (ArgSourceMode == EArgSourceMode::ControllerDir) {
			finalTargetYaw = mc.GetControllerRotator().Yaw;
		}
		else  if (ArgSourceMode == EArgSourceMode::ALSVelocityRotYaw) {
			finalTargetYaw = mc.GetALSRotTargetYaw();
		}
		else {
			// 不应该出现在这里, 查脚本使用情况
			ensureAlways(false);
			return false;
		}
	}

	finalTargetYaw = FRotator::NormalizeAxis(finalTargetYaw);
	finalTargetYaw = MathFormula::SameSignAngle(currentYaw, finalTargetYaw);

	float nextYaw = currentYaw;
	// ALS模式直接用算好的值, 没有内部插值
	if (ArgSourceMode != EArgSourceMode::ALSVelocityRotYaw)
	{
		if (InterMode == EInterpolationMode::Halflife) {
			nextYaw = MathFormula::DecayValue(currentYaw, finalTargetYaw, RealInterpolationArg, deltaTime);
		}
		else {
			nextYaw = MathFormula::LinearCloseToDst(currentYaw, finalTargetYaw, RealInterpolationArg, deltaTime);
		}
	}

	float sameSignYawDiff = MathFormula::ClosetYawSignedDiff(currentYaw, nextYaw);
	


	if (OutputMode == EMovementOutputMode::EOverride) {
		if (FMath::Abs(sameSignYawDiff) < MathFormula::RotateTolerateDegree) {
			currentRotator.Yaw = finalTargetYaw;
			mc.OccupyAbsoluteWorldRot(FQuat(currentRotator));
			return true;
		}

		currentRotator.Yaw = nextYaw;
		mc.OccupyAbsoluteWorldRot(FQuat(currentRotator));
		return true;
	}

	if (OutputMode == EMovementOutputMode::EAdditive) {
		if (FMath::Abs(sameSignYawDiff) < MathFormula::RotateTolerateDegree) {
			return true;
		}
		FRotator deltaRot(0.0f, sameSignYawDiff, 0.0f);
		mc.AccumulateLocalRotDelta(FQuat(deltaRot));
		return true;
	}

	return true;
}

bool YawController::DoRotateInstantlyLogic(bool isNeedOutput, MovementContext& mc, FRotator RotateInstantlyTargetRotator)
{
	if (!isNeedOutput) {
		return false;
	}

	mc.OccupyAbsoluteWorldRot(FQuat(RotateInstantlyTargetRotator));
	LastValidInput.Set(0.0f, 0.0f, 0.0f);
	return true;
}

#if UE_BUILD_DEVELOPMENT
void YawController::AppendDebugInfo(FString& infoOut) {
	infoOut.Append(TEXT("-----------YawController-------\n"));
	infoOut.Appendf(TEXT("TargetYaw:%f   TargetPos:%s  LastValidInput:%s  \n"), TargetYaw,*(TargetPos.ToString()), *(LastValidInput.ToString()));
	RotationCalculatorBase::AppendDebugInfo(infoOut);
}
#endif

