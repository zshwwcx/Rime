#include "3C/Movement/MovementSynchronization.h"
#include "GameFramework/PhysicsVolume.h"
#include "Components/CapsuleComponent.h"
#include "DoraSDK.h"
#include "3C/Character/BaseCharacter.h"
#include "3C/Character/BriefCharacter.h"
#include "3C/Interactor/Spline/C7GamePlaySplineActorBase.h"
#include "3C/Interactor/Spline/C7GameplaySplineWithStation.h"
#include "3C/Movement/RoleMovementComponent.h"
#include "3C/Movement/C7RootMotionSource.h"

bool SplineInterpolator::TryInit(UObject* WorldContext, uint32 InPathId, float InSpeed)
{
	if (InPathId == PathId && FMath::IsNearlyEqual(Speed, InSpeed))
	{
		return bInitSuccess;
	}
	
	if (InSpeed < UE_SMALL_NUMBER)
	{
		UE_LOG(LogTemp, Warning, TEXT("SplineInterpolator::TryInit invalid InSpeed[%f]"), InSpeed);
		return false;
	}
	
	UWorldManager* WorldManager = UWorldManager::GetInstance(WorldContext);
	if (!WorldManager)
	{
		UE_LOG(LogTemp, Display, TEXT("SplineInterpolator::TryInit get world manager failed"));
		return false;
	}
	
	// 等待加载完再走初始化流程，理论上Spline会比载具更早加载好
	const FString PathInsID = FString::Printf(TEXT("%u"), InPathId);
	if ( WorldManager->IsGameplaySplineActorPendingLoad(PathInsID))
	{
		UE_LOG(LogTemp, Display, TEXT("SplineInterpolator::TryInit get spline actor in loading %u"), InPathId);
		return false;
	}
	
	// Spline加载好之后，如果下面初始化失败，不会再次尝试
	bInitSuccess = false;
	PathId = InPathId;
	Speed = InSpeed;
	AC7GameplaySplineActorBase* SplineActorBase  = WorldManager->GetGameplaySplineActorIfReady(PathInsID);
	if (!SplineActorBase)
	{
		UE_LOG(LogTemp, Warning, TEXT("SplineInterpolator::TryInit get gameplay spline actor failed %u"), InPathId);
		return false;
	}
	
	SplineActor = SplineActorBase;
	SplineComp = SplineActorBase->GetSplineComponent();
	if (!SplineComp.IsValid())
	{
		UE_LOG(LogTemp, Warning, TEXT("SplineInterpolator::TryInit get gameplay spline component failed %u"), InPathId);
		return false;
	}
	
	if (!InitSplineAttr())
	{
		UE_LOG(LogTemp, Warning, TEXT("SplineInterpolator::TryInit InitSplineAttr failed"));
		return false;
	}

	TimeTable.clear();
	ReverseTimeTable.clear();

	bInitSuccess = SplineComp->IsClosedLoop() ? InitLoop() : InitNoLoop();
	return bInitSuccess;
}

bool SplineInterpolator::InitSplineAttr()
{
	if (SplineActor.IsValid())
	{
		if (const AC7GameplaySplineWithStation* SplineWithStation = Cast<const AC7GameplaySplineWithStation>(SplineActor.Get()))
		{
			PointsAttr.clear();
			PointsAttr.reserve(SplineWithStation->Stations.Num());
			for (const auto& Station : SplineWithStation->Stations)
			{
				PointsAttr.emplace_back(PointAttr{ Station.IsStop, Station.InStopDistance * 100.f, Station.OutStopDistance * 100.f, Station.StopTime });
			}
			return true;
		}
	}
	return false;
}

void SplineInterpolator::AddSpawnedSpline(uint32 PathID, USplineComponent* SplineComponent, std::vector<SplineInterpolator::PointAttr> PointAttrs)
{
	if (SpawnedSplineComps.Contains(PathID))
	{
		UE_LOG(LogTemp, Error, TEXT("[Synchronization] SplineInterpolator::AddSpawnedSpline path already exist [%d]"), PathID);
		return;
	}
	
	if (SpawnedSplinePointsAttr.Contains(PathID))
	{
		UE_LOG(LogTemp, Error, TEXT("[Synchronization] SplineInterpolator::AddSpawnedSpline point attrs already exist [%d]"), PathID);
		return;
	}
	
	SpawnedSplineComps.Add(PathID, SplineComponent);
	SpawnedSplinePointsAttr.Add(PathID, PointAttrs);
}

bool SplineInterpolator::InitNoLoop()
{
	HasStop = false;
	int MinIndex = -1;
	int MaxIndex = -1;
	float MinDistance = 0.0f;
	float MaxDistance = 0.0f;

	for (int Index = 0; Index < static_cast<int>(PointsAttr.size()); ++Index)
	{
		const PointAttr &Attr = PointsAttr[Index];
		if (Attr.IsStop) 
		{
			if (MinIndex < 0) 
			{
				MinIndex = Index;
			}
			if (Index > MaxIndex) 
			{
				MaxIndex = Index;
			}
			HasStop = true;
		}
	}
	if (MinIndex < 0 && MaxIndex < 0) {
		MinIndex = 0;
		MaxIndex = static_cast<int>(PointsAttr.size()) - 1;
	}
	if (MinIndex < 0 || MaxIndex < 0 || MinIndex == MaxIndex)
	{
		UE_LOG(LogTemp, Warning, TEXT("SplineInterpolator::InitNoLoop invalid MinIndex[%d], MaxIndex[%d], PathId[%u]"), MinIndex, MaxIndex, PathId);
		return false;
	}

	MinDistance = SplineComp->GetDistanceAlongSplineAtSplinePoint(MinIndex);
	MaxDistance = SplineComp->GetDistanceAlongSplineAtSplinePoint(MaxIndex);
	Length = MaxDistance - MinDistance;

	// 简化计算，暂不支持速度区间重叠
	float Time = 0.0f;
	float Dis = MinDistance;
	auto& Table = TimeTable;
	Table.emplace_back(TimeInfo{ Time, Dis, FLAG_NONE });

	if (HasStop)
	{
		for (int Index = MinIndex; Index <= MaxIndex; ++Index)
		{
			const PointAttr& Attr = PointsAttr[Index];
			if (Attr.IsStop)
			{
				float StopDis = SplineComp->GetDistanceAlongSplineAtSplinePoint(Index);
				float SlowDownDis = StopDis - Attr.InStopDistance;
				float SpeedUpDis = StopDis + Attr.OutStopDistance;

				if (Index != MinIndex)
				{
					if (SlowDownDis < Dis)
					{
						// 减速前已进入最大速度
						UE_LOG(LogTemp, Warning, TEXT("SplineInterpolator::InitNoLoop invalid spline data Index[%d], PathId[%u]"), Index, PathId);
						return false;
					}
					if (float DeltaTime = (SlowDownDis - Dis) / Speed; DeltaTime > 0.0f) 
					{
						Time += DeltaTime;
						Table.emplace_back(TimeInfo{ Time, SlowDownDis, FLAG_NONE });
					}
					if (float DeltaTime = Attr.InStopDistance * 2 / Speed; DeltaTime > 0.0f) 
					{
						Time += DeltaTime;
						Table.emplace_back(TimeInfo{ Time, StopDis, FLAG_SLOW_DOWN });
					}
				}

				if (Index != MaxIndex)
				{
					if (float DeltaTime = Attr.StopTime; DeltaTime > 0.0f) 
					{
						Time += DeltaTime;
						Table.emplace_back(TimeInfo{ Time, StopDis, FLAG_STOP });
					}
					if (float DeltaTime = Attr.OutStopDistance * 2 / Speed; DeltaTime > 0.0f) 
					{
						Time += DeltaTime;
						Table.emplace_back(TimeInfo{ Time, SpeedUpDis, FLAG_SPEED_UP });
					}
				}

				Dis = SpeedUpDis;
			}
		}
		Duration = Time;
	}
	else
	{
		Duration = Length / Speed;
		Table.emplace_back(TimeInfo{ Duration, Length, FLAG_NONE });
	}

	Time = 0.0f;
	Dis = MaxDistance;
	auto& Rtable = ReverseTimeTable;
	Rtable.emplace_back(TimeInfo{ Time, Dis, FLAG_NONE });

	if (HasStop)
	{
		for (int Index = MaxIndex; Index >= MinIndex; --Index)
		{
			const PointAttr& Attr = PointsAttr[Index];
			if (Attr.IsStop)
			{
				float StopDis = SplineComp->GetDistanceAlongSplineAtSplinePoint(Index);
				float SlowDownDis = StopDis + Attr.InStopDistance;
				float SpeedUpDis = StopDis - Attr.OutStopDistance;

				if (Index != MaxIndex)
				{
					if (SlowDownDis > Dis)
					{
						// 减速前已进入最大速度
						UE_LOG(LogTemp, Warning, TEXT("SplineInterpolator::InitNoLoop invalid spline data Index[%d], PathId[%u]"), Index, PathId);
						return false;
					}
					if (float DeltaTime = (Dis - SlowDownDis) / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.emplace_back(TimeInfo{ Time, SlowDownDis, FLAG_NONE });
					}
					if (float DeltaTime = Attr.InStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.emplace_back(TimeInfo{ Time, StopDis, FLAG_SLOW_DOWN });
					}
				}

				if (Index != MinIndex)
				{
					if (float DeltaTime = Attr.StopTime; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.emplace_back(TimeInfo{ Time, StopDis, FLAG_STOP });
					}
					if (float DeltaTime = Attr.OutStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.emplace_back(TimeInfo{ Time, SpeedUpDis, FLAG_SPEED_UP });
					}
				}

				Dis = SpeedUpDis;
			}
		}
	}
	else
	{
		Time = Length / Speed;
		Rtable.emplace_back(TimeInfo{ Time, 0.0f, FLAG_NONE });
	}

	return true;
}

bool SplineInterpolator::InitLoop()
{
	HasStop = false;
	int PointNum = static_cast<int>(PointsAttr.size());
	int StartIndex = 0;
	for (int Index = 0; Index < PointNum; ++Index)
	{
		const PointAttr& Attr = PointsAttr[Index];
		if (Attr.IsStop)
		{
			StartIndex = Index;
			HasStop = true;
			break;
		}
	}
	int EndIndex = StartIndex + PointNum;

	float StartDistance = SplineComp->GetDistanceAlongSplineAtSplinePoint(StartIndex);
	float EndDistance = SplineComp->GetDistanceAlongSplineAtSplinePoint(EndIndex);
	Length = SplineComp->GetSplineLength();

	// 简化计算，暂不支持速度区间重叠
	float Time = 0.0f;
	float Dis = StartDistance;
	auto& Table = TimeTable;
	Table.emplace_back(TimeInfo{ Time, Dis, FLAG_NONE });


	if (HasStop)
	{
		for (int Index = StartIndex; Index <= EndIndex; ++Index)
		{
			int AttrIndex = Index % PointNum;
			const PointAttr& Attr = PointsAttr[AttrIndex];
			if (Attr.IsStop)
			{
				int DisIndex = AttrIndex == 0 && Index != 0 ? PointNum : AttrIndex;
				float StopDis = SplineComp->GetDistanceAlongSplineAtSplinePoint(DisIndex);
				float SlowDownDis = StopDis - Attr.InStopDistance;
				float SpeedUpDis = StopDis + Attr.OutStopDistance;

				if (Index != StartIndex)
				{
					if (SlowDownDis < 0)
					{
						SlowDownDis += Length;
					}
					if (StopDis > Dis && SlowDownDis < Dis)
					{
						// 减速前已进入最大速度
						UE_LOG(LogTemp, Warning, TEXT("SplineInterpolator::InitLoop invalid spline data Index[%d], PathId[%u], SlowDownDis[%f], Dis[%f]"),
							Index, PathId, SlowDownDis, Dis);
						return false;
					}
					float Diff = SlowDownDis - Dis;
					if (float DeltaTime = (Diff > 0.0f ? Diff : Diff + Length) / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Table.emplace_back(TimeInfo{ Time, SlowDownDis, FLAG_NONE });
					}
					if (float DeltaTime = Attr.InStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Table.emplace_back(TimeInfo{ Time, StopDis, FLAG_SLOW_DOWN });
					}
				}

				if (Index != EndIndex)
				{
					if (float DeltaTime = Attr.StopTime; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Table.emplace_back(TimeInfo{ Time, StopDis, FLAG_STOP });
					}
					if (SpeedUpDis > Length)
					{
						SpeedUpDis -= Length;
					}
					if (float DeltaTime = Attr.OutStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Table.emplace_back(TimeInfo{ Time, SpeedUpDis, FLAG_SPEED_UP });
					}
				}

				Dis = SpeedUpDis;
			}
		}
		Duration = Time;
	}
	else
	{
		Duration = Length / Speed;
		Table.emplace_back(TimeInfo{ Duration, Length, FLAG_NONE });
	}

	Time = 0.0f;
	Dis = EndDistance;
	auto& Rtable = ReverseTimeTable;
	Rtable.emplace_back(TimeInfo{ Time, Dis, FLAG_NONE });

	if (HasStop)
	{
		for (int Index = EndIndex; Index >= StartIndex; --Index)
		{
			int AttrIndex = Index % PointNum;
			const PointAttr& Attr = PointsAttr[AttrIndex];
			if (Attr.IsStop)
			{
				int DisIndex = AttrIndex == 0 && Index != 0 ? PointNum : AttrIndex;
				float StopDis = SplineComp->GetDistanceAlongSplineAtSplinePoint(DisIndex);
				float SlowDownDis = StopDis + Attr.InStopDistance;
				float SpeedUpDis = StopDis - Attr.OutStopDistance;

				if (Index != EndIndex)
				{
					if (SlowDownDis > Length)
					{
						SlowDownDis -= Length;
					}
					if (StopDis < Dis && SlowDownDis > Dis)
					{
						// 减速前已进入最大速度
						UE_LOG(LogTemp, Warning, TEXT("SplineInterpolator::InitLoop invalid spline data Index[%d], PathId[%u], SlowDownDis[%f], Dis[%f]"),
							Index, PathId, SlowDownDis, Dis);
						return false;
					}
					float Diff = Dis - SlowDownDis;
					if (float DeltaTime = (Diff > 0.0f ? Diff : Diff + Length) / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.emplace_back(TimeInfo{ Time, SlowDownDis, FLAG_NONE });
					}
					if (float DeltaTime = Attr.InStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.emplace_back(TimeInfo{ Time, StopDis, FLAG_SLOW_DOWN });
					}
				}

				if (Index != StartIndex)
				{
					if (float DeltaTime = Attr.StopTime; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.emplace_back(TimeInfo{ Time, StopDis, FLAG_STOP });
					}
					if (SpeedUpDis < 0)
					{
						SpeedUpDis += Length;
					}
					if (float DeltaTime = Attr.OutStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.emplace_back(TimeInfo{ Time, SpeedUpDis, FLAG_SPEED_UP });
					}
				}

				Dis = SpeedUpDis;
			}
		}
	}
	else
	{
		Time = Length / Speed;
		Rtable.emplace_back(TimeInfo{ Time, 0.0f, FLAG_NONE });
	}

	return true;
}

void SplineInterpolator::SetFlag(uint8_t InFlag)
{
	if (Flag == InFlag)
	{
		return;
	}
	CurTimeTable = (InFlag & FixedPathFlag::Reverse) ? &ReverseTimeTable : &TimeTable;
	Flag = InFlag;
}

bool SplineInterpolator::Eval(float InTime, FVector& OutPosition, FRotator& OutRotation)
{
	if (!SplineComp.IsValid())
	{
		return false;
	}
	float Distance = EvalTimeTable(InTime);
	FTransform Transform = SplineComp->GetTransformAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
	OutPosition = Transform.GetLocation();
	FQuat Quat = Transform.GetRotation();
	// 非环路倒车行驶
	if (Flag & FixedPathFlag::ReverseDirection)
	{
		FVector Forward = Quat.Rotator().Vector();
		Forward = -1.0 * Forward;
		OutRotation = Forward.Rotation();
	}
	else
	{
		OutRotation = Quat.Rotator();
	}
	return true;
}

bool TimeTableComp(float Val, const SplineInterpolator::TimeInfo& P) { return P.Time > Val; }

float SplineInterpolator::EvalTimeTable(float InVal)
{
	const auto& Points = *CurTimeTable;
	auto It = std::upper_bound(Points.begin(), Points.end(), InVal, TimeTableComp);
	if (It == Points.begin())
	{
		return Points.front().Distance;
	}
	else if (It == Points.end())
	{
		return Points.back().Distance;
	}

	const auto& PrevPoint = *(It - 1);
	const auto& NextPoint = *It;
	const float Diff = NextPoint.Time - PrevPoint.Time;
	if (Diff <= 0.0f)
	{
		return PrevPoint.Distance;
	}

	float Alpha = (InVal - PrevPoint.Time) / Diff;
	if (NextPoint.Flag == FLAG_SLOW_DOWN)
	{
		// y = 1 - (1 - x)^2
		Alpha = 1.0f - Alpha;
		Alpha = 1.0f - Alpha * Alpha;
	}
	else if (NextPoint.Flag == FLAG_SPEED_UP)
	{
		// y = x^2
		Alpha = Alpha * Alpha;
	}

	if (SplineComp->IsClosedLoop()) 
	{
		if (Flag & FixedPathFlag::Reverse)
		{
			if (PrevPoint.Distance < NextPoint.Distance)
			{
				float Distance = FMath::Lerp(PrevPoint.Distance + Length, NextPoint.Distance, Alpha);
				return Distance < Length ? Distance : Distance - Length;
			}
		}
		else
		{
			if (PrevPoint.Distance > NextPoint.Distance)
			{
				float Distance = FMath::Lerp(PrevPoint.Distance, NextPoint.Distance + Length, Alpha);
				return Distance < Length ? Distance : Distance - Length;
			}
		}
	}
	return FMath::Lerp(PrevPoint.Distance, NextPoint.Distance, Alpha);
}

void FMovementSynchronizer::Init(URoleMovementComponent* InOwner) 
{
	Owner = InOwner;
	DefaultGravityScale = Owner->GravityScale;
	LastSyncGravityScale = Owner->GravityScale;
}

void FMovementSynchronizer::Clear() 
{
	LastTickTime = 0.0;
}

//接口UBriefMovementComponent会调用 @hujianglong
void FMovementSynchronizer::Tick(float DeltaTime)
{
	int32 DeltaTimeInUs = static_cast<int32>(DeltaTime * 1000000.0f);
	if (DeltaTimeInUs <= 0)
	{
		return;
	}
	SyncTimestamp += DeltaTimeInUs;
	if (SyncTimestamp < 0)
	{
		SyncTimestamp = 0;
	}
	else if (SyncTimestamp > MovementConst::MAX_SYNC_TIMESTAMP)
	{
		SyncTimestamp -= MovementConst::MAX_SYNC_TIMESTAMP;
	}
}

void FMovementSynchronizer::TrySyncMovement(float DeltaTime, const FMovementSnapshot& Snapshot)
{
	// 计算同步时间间隔以及统计时使用"真实物理时间"，因为客户端可能卡帧，其他计算使用"游戏逻辑时间"
	double SyncTimeElapsed = Snapshot.RealNow - LastSyncTime;

	uint16 Flags = 0;

	if (Snapshot.IsLocoStart)
	{
		Flags |= MovementSyncFlag::IsLocoStart;
	}
	if (Snapshot.IsJumping)
	{
		Flags |= MovementSyncFlag::Jumping;
		if (Snapshot.GravityScale != DefaultGravityScale)
		{
			Flags |= MovementSyncFlag::GravityScale;
		}
	}
	if (Snapshot.IsRiding)
	{
		Flags |= MovementSyncFlag::Riding;
	}
	if (Snapshot.bResetLocoProgress)
	{
		Flags |= MovementSyncFlag::ResetLocoProgress;
		Owner->ClearNeedResetLocoStateProgressForSync();
	}
	if (Snapshot.IsMovingOnPlatform)
	{
		Flags |= MovementSyncFlag::Relative;
		RelativeVelocity = LastTickTime > 0.0f && DeltaTime > 0.0f ? (Snapshot.RelativePosition - LastFrameRelativePosition) / DeltaTime : FVector::ZeroVector;
		LastFrameRelativePosition = Snapshot.RelativePosition;
	}
	if (Snapshot.ControlEntityId != 0)
	{
		Flags |= MovementSyncFlag::ControlEntity;
	}

	Velocity = LastTickTime > 0.0f && DeltaTime > 0.0f ? (Snapshot.Position - LastFramePosition) / DeltaTime : FVector::ZeroVector;
	LastFramePosition = Snapshot.Position;

	float MoveTime = GetPredictMoveTime(Snapshot);
	if (CanSyncMovement(Snapshot, SyncTimeElapsed, MoveTime, Flags))
	{
		LastSyncTime = Snapshot.RealNow;
		LastSyncVelocity = Velocity;
		LastSyncRotation = Snapshot.Rotation;
		LastSyncMoveTime = MoveTime;
		LastSyncLocomotionState = Snapshot.LocomotionState;
		LastSyncFlags = Flags;

		int64 EntityId = Owner->GetEntityId();
		if (EntityId <= 0)
		{
			return;
		}

		CheckSendHandshake(EntityId);

		Buffer.Clear();
		Buffer.PutUint8((uint8)NetChannelDataProtocol::ClientSyncMovement);
		Buffer.PutInt32(SyncTimestamp);
		Buffer.PutFVector32(Snapshot.Position); // TODO: 可以进一步压缩，每一位用3字节表示
		Buffer.PutInt16((int16)FMath::RoundToInt(Snapshot.Rotation.Yaw));
		Buffer.PutFVector32(Velocity); // TODO: 可以进一步压缩，每一位用2字节表示
		Buffer.PutInt16((int16)FMath::RoundToInt(MoveTime * 1000.0f));
		Buffer.PutUint8(Snapshot.LocomotionState);
		if ((Flags >> 8) != 0)
		{
			Flags |= MovementSyncFlag::Extension;
			Buffer.PutUint8((uint8)Flags);
			Buffer.PutUint8((uint8)(Flags >> 8));
		}
		else
		{
			Buffer.PutUint8((uint8)Flags);
		}
		// 下面的打包顺序不能随便改，需要和服务端解包顺序一致
		if (Snapshot.IsRiding)
		{
			Buffer.PutInt16((int16)FMath::RoundToInt(Snapshot.MountPitch));
			Buffer.PutInt16((int16)FMath::RoundToInt(Snapshot.MountRoll));
			Buffer.PutInt16((int16)FMath::RoundToInt(Snapshot.MountRootOffset));
		}
		if (Snapshot.IsMovingOnPlatform)
		{
			LastSyncRelativeVelocity = RelativeVelocity;
			LastSyncRelativeRotation = Snapshot.RelativeRotation;

			Buffer.PutFVector32(Snapshot.RelativePosition);
			Buffer.PutInt16((int16)FMath::RoundToInt(Snapshot.RelativeRotation.Yaw));
			Buffer.PutFVector32(RelativeVelocity);
		}
		if (Snapshot.IsJumping)
		{
			if (Flags & MovementSyncFlag::GravityScale)
			{
				Buffer.PutInt16((int16)FMath::RoundToInt(Owner->GravityScale * 100.0f));
			}
			LastSyncGravityScale = Snapshot.GravityScale;
		}
		if (Snapshot.ControlEntityId != 0)
		{
			Buffer.PutUint64((uint64)EntityId);
			EntityId = Snapshot.ControlEntityId;
		}

		SendSceneMessage((uint64)EntityId, Buffer.GetDataBegin(), Buffer.GetWritten());
	}

	LastTickTime = Snapshot.RealNow;
}

bool FMovementSynchronizer::CanSyncMovement(const FMovementSnapshot& Snapshot, float SyncTimeElapsed, float MoveTime, uint16 Flags)
{
	if (Owner->GetServerForcedControl())
	{
		return false;
	}

	if (LastSyncLocomotionState != Snapshot.LocomotionState || Flags != LastSyncFlags || Snapshot.bResetLocoProgress)
	{
		return true;
	}

	if (MoveTime > 0.0f)
	{
		if (SyncTimeElapsed >= LastSyncMoveTime) // P3移动完成，需要再进行同步
		{
			return true;
		}
	}

	FRotator RotationSyncDiff = Snapshot.IsMovingOnPlatform ? Snapshot.RelativeRotation - LastSyncRelativeRotation : Snapshot.Rotation - LastSyncRotation;
	FVector VelocitySyncDiff = Snapshot.IsMovingOnPlatform ? RelativeVelocity - LastSyncRelativeVelocity : Velocity - LastSyncVelocity;
	if (Flags & MovementSyncFlag::Jumping)
	{
		if (!FMath::IsNearlyEqual(Snapshot.GravityScale, LastSyncGravityScale))
		{
			return true;
		}
		VelocitySyncDiff.Z = 0; // 跳跃时，只关注水平方向的速度
	}

	bool bMoving = !Velocity.IsZero() || !RotationSyncDiff.IsZero() || !VelocitySyncDiff.IsZero();
	if (bMoving || NeedHandshake)
	{
		if (SyncTimeElapsed > MovementConst::SLOW_SYNC_INTERVAL) // 很久没有同步了，同步一次，校验性质的
		{
			return true;
		}

		if (SyncTimeElapsed < MovementConst::QUICK_SYNC_INTERVAL) // 限制同步频率
		{
			return false;
		}

		if (VelocitySyncDiff.SizeSquared() >= VELOCITY_EPSILON_SQUARED
			|| RotationSyncDiff.Euler().SizeSquared() >= ROTATION_EPSILON_SQUARED)
		{
			return true;
		}
	}
	else
	{
		if (SyncTimeElapsed > MovementConst::MOTIONLESS_SYNC_INTERVAL) // 没有移动的时候，同步频率更低
		{
			return true;
		}
	}

	return false;
}

EMoveSyncMode FMovementSynchronizer::GetMoveSyncMode()
{
	if (Owner->ClientMoveSyncMode == EMoveSyncMode::Relative)
	{
		if (IsValid(Owner->ClientMoveDataRelativeTarget.Get()))
		{
			return EMoveSyncMode::Relative;
		}
	}

	return EMoveSyncMode::Default;
}

float FMovementSynchronizer::GetPredictMoveTime(const FMovementSnapshot& Snapshot)
{
	FVector PredictVelocity = Snapshot.IsMovingOnPlatform ? RelativeVelocity : Velocity;
	if (Snapshot.IsJumping)
	{
		return GetJumpPredictMoveTime(Snapshot, PredictVelocity);
	}
	else
	{
		return PredictVelocity.IsNearlyZero() ? 0.0f : 
			(GetPredictPosition(Snapshot, PredictVelocity) - Owner->GetCharacterOwner()->GetActorLocation()).Size() / PredictVelocity.Size();
	}
}

float FMovementSynchronizer::GetJumpPredictMoveTime(const FMovementSnapshot& Snapshot, const FVector& InVelocity)
{
	ACharacter* CharacterOwner = GetPredictCharacter(Snapshot);
	UCapsuleComponent* CapsuleComponent = CharacterOwner->GetCapsuleComponent();
	float Radius = CapsuleComponent ? CapsuleComponent->GetScaledCapsuleRadius() : 35.0f;
	float HalfHeight = CapsuleComponent ? CapsuleComponent->GetScaledCapsuleHalfHeight() : 72.0f;
	HalfHeight *= CAPSULE_HEIGHT_SCALE_FACTOR;
	float GravityZ = Owner->GetGravityZ();
	float VelocityLimit = -Owner->GetPhysicsVolume()->TerminalVelocity;

	float MoveTime = 0.0f;
	FVector StartPos = CharacterOwner->GetActorLocation();
	FVector PredictPos = StartPos;
	float VelocityZ = InVelocity.Z;

	for (int LoopTimes = 0; LoopTimes < 100 && MoveTime < MovementConst::PREDICT_TIME; ++LoopTimes)
	{
		float SimulateTime = FMath::Min(0.1f, MovementConst::PREDICT_TIME - MoveTime);
		float EndVelocityZ = FMath::Max(VelocityZ + GravityZ * SimulateTime, VelocityLimit);
		FVector DeltaVector;

		if (VelocityZ > 0.0f && EndVelocityZ < 0.0f)
		{
			EndVelocityZ = 0.0f;
			SimulateTime = VelocityZ / -GravityZ;
			DeltaVector.Z = VelocityZ / 2.0f * SimulateTime;
		}
		else
		{
			if (VelocityZ - VelocityLimit > UE_SMALL_NUMBER && FMath::IsNearlyEqual(EndVelocityZ, VelocityLimit))
			{
				SimulateTime = (VelocityLimit - VelocityZ) / -GravityZ;
			}
			DeltaVector.Z = (VelocityZ + EndVelocityZ) / 2.0f * SimulateTime;
		}
		VelocityZ = EndVelocityZ;

		if (SimulateTime < 1e-6)
		{
			continue;
		}

		DeltaVector.X = InVelocity.X * SimulateTime;
		DeltaVector.Y = InVelocity.Y * SimulateTime;
		PredictPos = StartPos + DeltaVector;

		FHitResult HitResult;
		if (UKismetSystemLibrary::CapsuleTraceSingleByProfile(CharacterOwner, StartPos, PredictPos, Radius, HalfHeight,
			FName("Pawn"), false, IgnoredActors, EDrawDebugTrace::None, HitResult, true))
		{
			PredictPos = StartPos + (DeltaVector.GetSafeNormal() * HitResult.Distance);
			// TODO: 这是粗略的计算，可以再细化
			MoveTime += HitResult.Distance / DeltaVector.Size() * SimulateTime;
			break;
		}

		MoveTime += SimulateTime;
		StartPos = PredictPos;
	}

	//DrawDebugCapsule(Owner->GetWorld(), PredictPos, HalfHeight, Radius, FQuat::MakeFromEuler(FVector(0, 0, 0)), FColor::Blue);
	return MoveTime;
}

FVector FMovementSynchronizer::GetPredictPosition(const FMovementSnapshot& Snapshot, const FVector& InVelocity)
{
	FVector CurrentPosition = Owner->GetCharacterOwner()->GetActorLocation();
	FVector PredictPosition = GetSimplePredictPosition(Snapshot, InVelocity);

	FVector BattleZonePredictPosition;
	Owner->FindLocationXYInMoveConstraint(PredictPosition, BattleZonePredictPosition);
	PredictPosition = BattleZonePredictPosition;

	FVector RootMotionFinalPosition;
	float RootMotionRemainTime;

	if (Owner->IsRunningRootMotionSource() && GetRootMotionResult(&RootMotionFinalPosition, &RootMotionRemainTime))
	{
		FVector RootMotionDelta = RootMotionFinalPosition - CurrentPosition;
		FVector PredictDelta = PredictPosition - CurrentPosition;
		if (RootMotionDelta.IsNearlyZero() || PredictDelta.IsNearlyZero())
		{
			return CurrentPosition;
		}

		double L1 = RootMotionDelta.Length();
		double L2 = PredictDelta.Length();
		double Cosine = RootMotionDelta.Dot(PredictDelta) / L1 / L2;

		if (Cosine >= FMath::Cos(FMath::DegreesToRadians(10.0)) && L2 * Cosine > L1)
		{
			return FMath::LerpStable(CurrentPosition, PredictPosition, L1 / L2 / Cosine);
		}
	}

	return PredictPosition;
}

FVector FMovementSynchronizer::GetSimplePredictPosition(const FMovementSnapshot& Snapshot, const FVector& InVelocity)
{
	ACharacter* CharacterOwner = GetPredictCharacter(Snapshot);
	UCapsuleComponent* CapsuleComponent = CharacterOwner->GetCapsuleComponent();
	float Radius = CapsuleComponent ? CapsuleComponent->GetScaledCapsuleRadius() : 35.0f;
	float HalfHeight = CapsuleComponent ? CapsuleComponent->GetScaledCapsuleHalfHeight() : 72.0f;
	HalfHeight *= CAPSULE_HEIGHT_SCALE_FACTOR;

	const FVector& StartPos = CharacterOwner->GetActorLocation();
	FVector PredictPos = StartPos + InVelocity * MovementConst::PREDICT_TIME;
	FVector PredictDirection = InVelocity.GetSafeNormal();
	float MoveDistance = InVelocity.Size() * MovementConst::PREDICT_TIME;

	FHitResult HitResult;
	if (UKismetSystemLibrary::CapsuleTraceSingleByProfile(CharacterOwner, StartPos, PredictPos, Radius, HalfHeight,
		FName("Pawn"), false, IgnoredActors, EDrawDebugTrace::None, HitResult, true))
	{
		MoveDistance = HitResult.Distance;
		PredictPos = StartPos + (PredictDirection * HitResult.Distance);
	}

	if (!Owner->IsMovingOnGround())
	{
		return PredictPos;
	}

	//在地面 需要打射线判断悬崖
	float DetectDistance = Radius;
	float DropTestDist = HalfHeight + 15.0f;
	FVector LastDetectPosition = StartPos + PredictDirection * DetectDistance;

	//每隔CharacterController直径距离向下打一条射线，判断是否有悬崖
	for (int LoopTimes = 0; LoopTimes < 100 && DetectDistance < MoveDistance; ++LoopTimes)
	{
		LastDetectPosition = StartPos + PredictDirection * DetectDistance;

		FHitResult DownHitResult;
		if (!UKismetSystemLibrary::LineTraceSingleByProfile(CharacterOwner, LastDetectPosition,
			LastDetectPosition + (FVector::DownVector * DropTestDist),
			FName("Pawn"), false, IgnoredActors,
			EDrawDebugTrace::None, DownHitResult, true, FLinearColor::Yellow))
		{
			//探到悬崖了，向前多移动半径距离 防止在悬崖边上卡顿
			return LastDetectPosition + PredictDirection * Radius;
		}
		DetectDistance += Radius * 2.0f;
	}

	//没有中途探测到悬崖 需要再在终点探测一次
	FHitResult DownHitResult;
	if (UKismetSystemLibrary::LineTraceSingleByProfile(CharacterOwner, PredictPos,
		PredictPos + (FVector::DownVector * DropTestDist),
		FName("Pawn"), false, IgnoredActors,
		EDrawDebugTrace::None, DownHitResult, true, FLinearColor::Yellow))
	{
		return PredictPos;
	}

	return LastDetectPosition;
}

bool FMovementSynchronizer::GetRootMotionResult(FVector* OutFinalPosition, float* OutRemainTime)
{
	for (int32 Idx = 0; Idx < Owner->CurrentRootMotion.RootMotionSources.Num(); ++Idx)
	{
		const TSharedPtr<FRootMotionSource>& RMS = Owner->CurrentRootMotion.RootMotionSources[Idx];

		if (RMS.IsValid() && RMS->GetScriptStruct()->IsChildOf(FC7RootMotionSource_MoveToDynamicForce::StaticStruct()))
		{
			if (FC7RootMotionSource_MoveToDynamicForce* MoveToActorForce = static_cast<FC7RootMotionSource_MoveToDynamicForce*>(RMS.Get()))
			{
				if (Owner->AllowRootMotionByTypeMask(MoveToActorForce->TypeMask))
				{
					*OutFinalPosition = MoveToActorForce->TargetLocation;
					*OutRemainTime = MoveToActorForce->Duration - MoveToActorForce->CurrentTime;
					return true;
				}
			}
		}
	}
	return false;
}

ACharacter* FMovementSynchronizer::GetPredictCharacter(const FMovementSnapshot& Snapshot)
{
	if (Snapshot.IsRiding)
	{
		URoleMovementComponent* MountMoveComp = Owner->GetRealMovementViewProxy();
		if (MountMoveComp && MountMoveComp->GetCharacterOwner())
		{
			// 使用坐骑进行预测
			return MountMoveComp->GetCharacterOwner();
		}
	}
	return Owner->GetCharacterOwner();
}

void FMovementSynchronizer::OnHandshake(uint8 HandshakeProtocol, int32 SpaceId)
{
	int32 CurrentSpaceId = Owner->GetSpaceId();
	switch (HandshakeProtocol)
	{
	case MovementHandshakeProtocol::Request:
		NeedHandshake = true;
		if (CurrentSpaceId != SpaceId)
		{
			UE_LOG(LogTemp, Log, TEXT("[Synchronization] MovementSynchronizer::OnHandshake Request CurrentSpaceId[%d], SpaceId[%d]"), CurrentSpaceId, SpaceId);
		}
		break;
	case MovementHandshakeProtocol::Ack:
		NeedHandshake = false;
		UE_LOG(LogTemp, Log, TEXT("[Synchronization] MovementSynchronizer::OnHandshake Ack CurrentSpaceId[%d], SpaceId[%d]"), CurrentSpaceId, SpaceId);
		break;
	default:
		UE_LOG(LogTemp, Error, TEXT("[Synchronization] MovementSynchronizer::OnHandshake error Protocol[%d]"), HandshakeProtocol);
		break;
	}
}

void FMovementSynchronizer::RotateToDirectionInstantly(float Yaw)
{
	ACharacter* CharacterOwner = Owner->GetCharacterOwner();
	if (!CharacterOwner)
	{
		return;
	}
	FRotator Rotation = CharacterOwner->GetActorRotation();
	Rotation.Yaw = Yaw;

	CharacterOwner->SetActorRotation(Rotation);

	int64 EntityId = Owner->GetEntityId();
	if (EntityId <= 0)
	{
		return;
	}

	LastSyncRotation = Rotation;

	CheckSendHandshake(EntityId);

	PackRotateInstantlyMsg(&Buffer, (uint64)EntityId, SyncTimestamp, Rotation.Yaw);
	SendSceneMessage((uint64)EntityId, Buffer.GetDataBegin(), Buffer.GetWritten());
}

void FMovementSynchronizer::CheckSendHandshake(int64 EntityId)
{
	// 如果需要握手，先发送握手包
	if (NeedHandshake)
	{
		PackHandshakeMsg(&Buffer, Owner->GetSpaceId());
		SendSceneMessage((uint64)EntityId, Buffer.GetDataBegin(), Buffer.GetWritten());
	}
}

void FMovementSynchronizer::SendSceneMessage(uint64_t EntityId, const char* Data, size_t Len)
{
#if !UE_BUILD_SHIPPING
	if (UDoraSDK::bRecordingMessages && Len > 0)
	{
		ReadBuffer RecordingBuffer(Data, Len);
		NetChannelDataProtocol Protocol = (NetChannelDataProtocol)RecordingBuffer.ReadUint8();
		switch (Protocol)
		{
		case NetChannelDataProtocol::Handshake:
		{
			HandshakeMsg HSM = UnpackHandshakeMsg(&RecordingBuffer);
			UDoraSDK::RecordMessage(EntityId, FString::Printf(TEXT("Protocol = \'Handshake\', SpaceId = %i"), HSM.SpaceId));
			break;
		}
		case NetChannelDataProtocol::RotateInstantly:
		{
			RotateInstantlyMsg RIM = UnpackRotateInstantlyMsg(&RecordingBuffer);
			UDoraSDK::RecordMessage(EntityId, FString::Printf(TEXT("Protocol = \'RotateInstantly\',Timestamp = %i, Rotation = %s, FromServer = %d"), RIM.Timestamp, 
				*FString::Printf(TEXT("{Pitch = %f, Yaw = %f, Roll = %f}"), RIM.Rotation.Pitch, RIM.Rotation.Yaw, RIM.Rotation.Roll), RIM.FromServer));
			break;
		}
		case NetChannelDataProtocol::ClientSyncMovement:
		{
			MovementData MD = UnpackClientMoveMsg(&RecordingBuffer);
			UDoraSDK::RecordMessage(EntityId, 
				FString::Printf(TEXT("Protocol = \'ClientSyncMovement\', Timestamp = %i, Location = %s, Rotation = %s, Velocity = %s, MoveTime = %i, LocomotionState = %i, Flags = %i, \
MountPitch = %f, MountRoll = %f, MountRootOffset = %f, RelativeLocation = %s, RelativeRotation = %s, RelativeVelocity = %s, GravityScale = %f, \
bHasTargetDirection = %d, TargetDirection = %f, LocoStateUsed = %d, FixedPathDataPathID = %i, FixedPathDataFrame = %i, FixedPathDataFlag = %i, FixedPathDataSpeed = %i"),
					MD.Timestamp, *FString::Printf(TEXT("{X = %f, Y = %f, Z = %f}"), MD.Transform.Position.X, MD.Transform.Position.Y, MD.Transform.Position.Z), 
					*FString::Printf(TEXT("{Pitch = %f, Yaw = %f, Roll = %f}"), MD.Transform.Rotation.Pitch, MD.Transform.Rotation.Yaw, MD.Transform.Rotation.Roll),
					*FString::Printf(TEXT("{X = %f, Y = %f, Z = %f}"), MD.Transform.Velocity.X, MD.Transform.Velocity.Y, MD.Transform.Velocity.Z),
					MD.MoveTime, MD.LocomotionState, MD.Flags, MD.MountPitch, MD.MountRoll, MD.MountRootOffset,
					*FString::Printf(TEXT("{X = %f, Y = %f, Z = %f}"), MD.RelativeTranform.Position.X, MD.RelativeTranform.Position.Y, MD.RelativeTranform.Position.Z), 
					*FString::Printf(TEXT("{Pitch = %f, Yaw = %f, Roll = %f}"), MD.RelativeTranform.Rotation.Pitch, MD.RelativeTranform.Rotation.Yaw, MD.RelativeTranform.Rotation.Roll),
					*FString::Printf(TEXT("{X = %f, Y = %f, Z = %f}"), MD.RelativeTranform.Velocity.X, MD.RelativeTranform.Velocity.Y, MD.RelativeTranform.Velocity.Z),
					MD.GravityScale, MD.bHasTargetDirection, MD.TargetDirection, MD.LocoStateUsed, MD.FixedPath.PathId, MD.FixedPath.Frame, MD.FixedPath.Flag, MD.FixedPath.Speed));
			break;
		}
		}
	}
#endif
	UDoraSDK::SendSceneMessage(EntityId, Data, Len);
}



void FMovementSimulator::Init(URoleMovementComponent *InOwner)
{
    Owner = InOwner;
    DefaultGravityScale = Owner->GravityScale;
}

void FMovementSimulator::InitBriefOwner(ABriefCharacter *InOwner) 
{
	BriefOwner = InOwner;
}

int64 FMovementSimulator::GetBriefEntityId()
{
    if (!BriefOwner.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("[Synchronization] MovementSimulator::GetEntityId get CharacterOwner failed"));
		return 0;
	}
    return BriefOwner->GetEntityUID();
}

void FMovementSimulator::Clear(EMoveSimulateClearReason Reason)
{
	ALOG_DEBUG_POSITION(Owner, "FMovementSimulator::Clear");
    if (Owner.IsValid() && !MovementDatas.empty() && MovementDatas.back().Transform.Velocity.IsZero())
	{
		Owner->Velocity = FVector::ZeroVector;
	}
	MovementDatas.clear();
	bLastHasUpdateLocomotionState = false;
	LastLocomotionState = 0;
	LastIsLocoStart = false;
	bIsMoving = false;
	LastSimulatePosition = FVector::ZeroVector;
}

void FMovementSimulator::Tick(float DeltaTime)
{
	int32 DeltaTimeInUs = static_cast<int32>(DeltaTime * 1000000.0f);
	if (DeltaTimeInUs <= 0)
	{
		return;
	}
	SimulatedTimestamp += DeltaTimeInUs;
	if (SimulatedTimestamp < 0)
	{
		SimulatedTimestamp = 0;
		MovementDatas.clear();
	}
	else if (SimulatedTimestamp > MovementConst::MAX_SYNC_TIMESTAMP)
	{
		SimulatedTimestamp -= MovementConst::MAX_SYNC_TIMESTAMP;
	}
}

void FMovementSimulator::OnReceiveMovementData(MovementData&& MovementData)
{
	switch (MovementData.Protocol)
	{
	case NetChannelDataProtocol::ClientSyncMovement:
		if (SimulateType != EMoveSimulateType::Client)
		{
			ChangeSimulateType(EMoveSimulateType::Client);
			UE_LOG(LogTemp, Log, TEXT("MovementSimulator::OnReceiveServerData entity[%lld] change simulate type to Client"), Owner->GetEntityId());
		}
		break;
	case NetChannelDataProtocol::ServerSyncMovement:
		if (NeedFixServerPositionToFloor() && !(MovementData.Flags & MovementSyncFlag::Floating))
		{
			FixServerPositionToFloor(MovementData.Transform.Position);
		}
		if (SimulateType != EMoveSimulateType::Server)
		{
			ChangeSimulateType(EMoveSimulateType::Server);
			UE_LOG(LogTemp, Log, TEXT("MovementSimulator::OnReceiveServerData entity[%lld] change simulate type to Server"), Owner->GetEntityId());
		}
		break;
	case NetChannelDataProtocol::ServerSyncBriefMovement:
		if (SimulateType != EMoveSimulateType::ServerBrief)
		{
			ChangeSimulateType(EMoveSimulateType::ServerBrief);
			UE_LOG(LogTemp, Log, TEXT("MovementSimulator::OnReceiveServerData entity[%lld] change simulate type to ServerBrief"), GetBriefEntityId());
		}
		break;
	case NetChannelDataProtocol::FixedPathSyncMovement:
		if (SimulateType != EMoveSimulateType::FixedPath)
		{
			ChangeSimulateType(EMoveSimulateType::FixedPath);
			UE_LOG(LogTemp, Log, TEXT("MovementSimulator::OnReceiveServerData entity[%lld] change simulate type to FixedPath"), Owner->GetEntityId());
		}
		break;
	default:
		UE_LOG(LogTemp, Error, TEXT("MovementSimulator::OnReceiveServerData error Protocol[%u]"), MovementData.Protocol);
		return;
	}

#if UE_BUILD_DEVELOPMENT
    if (Owner.IsValid() && ABaseCharacter::IsShowMoveSyncHistoryInConfig(Owner->GetCharacterOwner()))
	{
		if (ISceneDrawerInterface* pDrawerSubsystem = ABaseCharacter::GetSceneDrawerTool())
		{
			pDrawerSubsystem->DrawMoveSyncData(MovementData.Transform.Position, MovementData.Transform.Rotation, FColor::Green);
		}
	}
#endif

	bool bServerBriefControlled = SimulateType == EMoveSimulateType::ServerBrief;
	const int32 TargetSimulatedDelayInUs = static_cast<int32>((bServerBriefControlled ?
		(MovementConst::TARGET_SIMULATED_DELAY + MovementConst::SLOW_SYNC_INTERVAL) : MovementConst::TARGET_SIMULATED_DELAY) * 1000000.0f);
	const int32 MaxSimulatedDelayInUs = static_cast<int32>((bServerBriefControlled ?
		(MovementConst::MAX_SIMULATED_DELAY + MovementConst::SLOW_SYNC_INTERVAL) : MovementConst::MAX_SIMULATED_DELAY) * 1000000.0f);

	if (LastReceivedTimestamp < 0)
	{
		SimulatedTimestamp = MovementData.Timestamp - TargetSimulatedDelayInUs;
	}

	if (LastReceivedTimestamp == MovementData.Timestamp)
	{
		if (!MovementDatas.empty() && MovementDatas.back().Timestamp == LastReceivedTimestamp)
		{
			UE_LOG(LogTemp, Log, TEXT("[Synchronization] MovementSimulator::OnReceiveMovementData override Timestamp[%d]"), MovementData.Timestamp);
			MovementDatas.pop_back();
		}
	}
	else if (LastReceivedTimestamp > MovementData.Timestamp)
	{
		if (LastReceivedTimestamp - MovementData.Timestamp < 0.5f * MovementConst::MAX_SYNC_TIMESTAMP)
		{
			UE_LOG(LogTemp, Log, TEXT("[Synchronization] MovementSimulator::OnReceiveMovementData reset Timestamp[%d]"), MovementData.Timestamp);
			MovementDatas.clear();
			SimulatedTimestamp = MovementData.Timestamp - TargetSimulatedDelayInUs;
		}
		else
		{
			UE_LOG(LogTemp, Log, TEXT("[Synchronization] MovementSimulator::OnReceiveMovementData LastReceivedTimestamp[%d], Timestamp[%d], SimulatedTimestamp[%d]"),
				LastReceivedTimestamp, MovementData.Timestamp, SimulatedTimestamp);

			SimulatedTimestamp -= MovementConst::MAX_SYNC_TIMESTAMP;
			Timestamp0 = FMath::Max(Timestamp0 - MovementConst::MAX_SYNC_TIMESTAMP, -1);
			Timestamp1 = FMath::Max(Timestamp1 - MovementConst::MAX_SYNC_TIMESTAMP, -1);
			RotateInstantlyTimestamp = FMath::Max(RotateInstantlyTimestamp - MovementConst::MAX_SYNC_TIMESTAMP, -1);
			for (auto It = MovementDatas.begin(); It != MovementDatas.end(); ++It)
			{
				It->Timestamp -= MovementConst::MAX_SYNC_TIMESTAMP;
			}
		}
	}

	SimulatedTimestamp = FMath::Clamp(SimulatedTimestamp, MovementData.Timestamp - MaxSimulatedDelayInUs, MovementData.Timestamp);
	int32 CurrentDelay = MovementData.Timestamp - SimulatedTimestamp;
	int32 SmoothDelay = static_cast<int32>(DELAY_SMOOTH_ALPHA * CurrentDelay + (1 - DELAY_SMOOTH_ALPHA) * TargetSimulatedDelayInUs);
	SmoothDelayDelta = CurrentDelay - SmoothDelay;

	MovementData.LocoStateUsed = false;
	LastReceivedTimestamp = MovementData.Timestamp;

	ALOG_DEBUG_POSITION(Owner, "FMovementSimulator::OnReceiveMovementData Position[%s]", *MovementData.Transform.Position.ToString());

	MovementDatas.push_back(std::move(MovementData));
	while (MovementDatas.size() > MOVE_SYNC_BUFFER_SIZE)
	{
		//ACharacter* CharacterOwner = Owner->GetCharacterOwner();
		//FString Name = CharacterOwner ? CharacterOwner->GetName() : "Unknown";
		//UE_LOG(LogRoleMovement, Error, TEXT("[Synchronization] MovementSimulator::OnReceiveMovementData movement datas excced, "
		//	"EntityId[%lld], Name[%s], IsActive[%d]"), GetEntityId(), *Name, Owner->IsActive());
		MovementDatas.pop_front();
	}
}

bool FMovementSimulator::GetLatestPosAndRot(FVector& Position, FRotator& Rotation)
{
	Position = FVector::ZeroVector;
	Rotation = FRotator::ZeroRotator;
	return true;
}

//接口UBriefMovementComponent会调用 @hujianglong
bool FMovementSimulator::SimulatedTick(float DeltaTime, FVector& OutPosition, FRotator& OutRotation)
{
	if (SimulateType == EMoveSimulateType::ServerBrief)
	{
		if (!BriefOwner.IsValid())
		{
			return false;
		}
		if (!bInitOwnerCapsuleHalfHeight)
		{
			if (UCapsuleComponent* Component = BriefOwner->GetCapsule())
			{
				OwnerCapsuleHalfHeight = Component->GetScaledCapsuleHalfHeight();
			}
			bInitOwnerCapsuleHalfHeight = true;
		}
	}
	else
	{
        if (!Owner.IsValid())
        {
            return false;
		}
		if (!Owner->GetCharacterOwner())
		{
			return false;
		}
		if (!bInitOwnerCapsuleHalfHeight)
		{
			if (UCapsuleComponent* Component = Owner->GetCharacterOwner()->GetCapsuleComponent())
			{
				OwnerCapsuleHalfHeight = Component->GetScaledCapsuleHalfHeight();
			}
			bInitOwnerCapsuleHalfHeight = true;
		}
	}

	UpdateSimulateDelay(DeltaTime);

	// 获取时间小于 serverTime 的最新点 p0, 其后一个点是 p1，可能收到了也可能没收到
	MovementDataNode Node = MovementDatas.end();
	for (auto It = MovementDatas.begin(); It != MovementDatas.end() && It->Timestamp <= SimulatedTimestamp; ++It)
	{
		Node = It;
	}
	bool Succ = false;
	switch (SimulateType)
	{
	case EMoveSimulateType::ServerBrief:
		Succ = SimulateBrief(DeltaTime, SimulatedTimestamp, Node, OutPosition);
		break;
	case EMoveSimulateType::FixedPath:
		Succ = SimulateFixedPath(DeltaTime, SimulatedTimestamp, Node, OutPosition, OutRotation);
		break;
	default:
		Succ = SimulateFull(DeltaTime, SimulatedTimestamp, Node, OutPosition, OutRotation);
		break;
	}

	if (Node != MovementDatas.end())
	{
		MovementDatas.erase(MovementDatas.begin(), Node);
	}

	if (Succ)
	{
		UpdateMoveState(OutPosition);
		if (SimulateType == EMoveSimulateType::FixedPath)
		{
			Owner->SetIsLocoStart(bIsMoving);
			TriggerMoveEvent();
		}
	}

	return Succ;
}

void FMovementSimulator::UpdateSimulateDelay(float DeltaTime)
{
	if (SmoothDelayDelta == 0)
	{
		return;
	}
	int32 MaxUpdateDelay = static_cast<int32>(DeltaTime * DELAY_DELTA_CONSUME_ALPHA * 1000000.0f);
	int32 ConsumeDelta = SmoothDelayDelta > 0 ? FMath::Min(SmoothDelayDelta, MaxUpdateDelay) : FMath::Max(SmoothDelayDelta, -MaxUpdateDelay);
	SimulatedTimestamp += ConsumeDelta;
	SmoothDelayDelta -= ConsumeDelta;
}

void FMovementSimulator::UpdateLocomotionState(MovementDataNode Node)
{
	if (Node != MovementDatas.begin())
	{
		for (auto It = MovementDatas.begin(); It != Node; ++It)
		{
			MovementData& Point = *It;
			if (!Point.LocoStateUsed)
			{
				UpdateLocomotionState(Point);
			}
		}
	}

	MovementData& Point0 = *Node;
	if (++Node != MovementDatas.end())
	{
		MovementData& Point1 = *Node;
		// 特殊处理移动启动，否则会出现滑步
		if ((Point0.Flags & MovementSyncFlag::IsLocoStart) == 0 && (Point1.Flags & MovementSyncFlag::IsLocoStart) != 0)
		{
			UpdateLocomotionState(Point1);
			return;
		}
	}
	UpdateLocomotionState(Point0);
}

void FMovementSimulator::UpdateLocomotionState(MovementData& Point)
{
	Point.LocoStateUsed = true;
	UpdateLocomotionState(Point.LocomotionState, Point.Flags & MovementSyncFlag::IsLocoStart, Point.Flags & MovementSyncFlag::ResetLocoProgress);
	if (Point.Flags & MovementSyncFlag::ResetLocoProgress)
	{
		Point.Flags ^= MovementSyncFlag::ResetLocoProgress;
	}
}

void FMovementSimulator::UpdateLocomotionState(uint8 LocomotionState, bool bIsLocoStart, bool bResetLocoProgress)
{
	if (bResetLocoProgress)
	{
		Owner->ReceiveNeedResetLocoStateProgressForSync();
	}
	if (bLastHasUpdateLocomotionState && LastLocomotionState == LocomotionState && LastIsLocoStart == bIsLocoStart)
	{
		return;
	}
	bLastHasUpdateLocomotionState = true;
	LastLocomotionState = LocomotionState;
	LastIsLocoStart = bIsLocoStart;
	Owner->ConsumeLocoStateMaskFromNet(LocomotionState, bIsLocoStart);
}

bool FMovementSimulator::SimulateFull(float DeltaTime, int32 CurrentTime, MovementDataNode Node, FVector& OutPosition, FRotator& OutRotation)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("SimulateFull");

	if (Node == MovementDatas.end())
	{
		return false;
	}

	ACharacter* CharacterOwner = Owner->GetCharacterOwner();
	SimulateContext Context;

	const MovementData& Point0 = *Node;

	if (Point0.Flags & MovementSyncFlag::Riding)
	{
		// 是否需要使用坐骑数据
		if (Owner->IsNeedConsumeMountSimulateData())
		{
			UpdateRiding(Node, Context);
		}
		else
		{
			return false;
		}
	}

	FVector Position = CharacterOwner->GetActorLocation();
	if (Point0.Flags & MovementSyncFlag::Jumping)
	{
		SimulateJumping(CurrentTime, Node, Position, Context);
	}
	else
	{
		SimulateDefault(DeltaTime, CurrentTime, Node, Position, Context);
	}

	OutPosition = Position;

	UpdateRotation(DeltaTime, CurrentTime, Node, OutRotation);

	UpdateLocomotionState(Node);

	return true;
}

void FMovementSimulator::UpdateRotation(float DeltaTime, int32 CurrentTime, MovementDataNode Node, FRotator& OutRotation)
{
	bool bTargetPointChanged = false;

	const MovementData& Point0 = *Node;
	const MovementData* TargetPoint = &Point0;

	if (++Node != MovementDatas.end())
	{
		const MovementData& Point1 = *Node;
		TargetPoint = &Point1;

		if (Timestamp0 != Point0.Timestamp || Timestamp1 != Point1.Timestamp)
		{
			Timestamp0 = Point0.Timestamp;
			Timestamp1 = Point1.Timestamp;
			InterpolationTime = Point1.Timestamp - CurrentTime + static_cast<int32>(DeltaTime * 1000000.0f);
			bTargetPointChanged = true;
		}
	}
	else
	{
		if (Timestamp0 != Point0.Timestamp || Timestamp1 != -1)
		{
			Timestamp0 = Point0.Timestamp;
			Timestamp1 = -1;
			InterpolationTime = 0;
			bTargetPointChanged = true;
		}
	}

	if (bTargetPointChanged)
	{
		OnUpdateTargetDirection(*TargetPoint);
	}

	float Alpha = InterpolationTime > 0 ? FMath::Clamp(1 - (float)(TargetPoint->Timestamp - CurrentTime) / (float)InterpolationTime, 0.0f, 1.0f) : 1.0f;
	const FRotator& CurrentRotation = Owner->GetActorRideModeTransform().Rotator();
	if (bTargetPointChanged)
	{
		StartRotation = CurrentRotation;
	}

	if (CurrentTime <= RotateInstantlyTimestamp || TargetPoint->Timestamp <= RotateInstantlyTimestamp)
	{
		OutRotation = CurrentRotation;
		return;
	}

	RotateInstantlyTimestamp = -1;

	const FRotator& TargetRotation = TargetPoint->Transform.Rotation;
	if (TargetPoint->Flags & MovementSyncFlag::Use3DRotation)
	{
		OutRotation = UE::Math::TQuat<double>::Slerp(StartRotation.Quaternion(), TargetRotation.Quaternion(), Alpha).Rotator();
	}
	else
	{
		OutRotation.Yaw = FMath::LerpStable(MathFormula::SameSignAngle(CurrentRotation.Yaw, StartRotation.Yaw), MathFormula::SameSignAngle(CurrentRotation.Yaw, TargetRotation.Yaw), Alpha);
		OutRotation.Pitch = 0.0f;
		OutRotation.Roll = 0.0f;
	}
}

void FMovementSimulator::SimulateDefault(float DeltaTime, int32 CurrentTime, MovementDataNode Node, FVector& Position, SimulateContext& InContext)
{
	const MovementData& Point0 = *Node;
	const MovementTransform& Transform0 = GetMovementTransform(Point0);
	FVector CurrentPosition = Owner->GetCharacterOwner()->GetActorLocation();

	if (++Node != MovementDatas.end())
	{
		const MovementData& Point1 = *Node;
		const MovementTransform& Transform1 = GetMovementTransform(Point1);

		int32 StartTimeStamp = !Transform0.Velocity.IsNearlyZero() ? Point0.Timestamp :
			FMath::Min(CurrentTime, FMath::Max(Point0.Timestamp, Point1.Timestamp - static_cast<int32>(MovementConst::QUICK_SYNC_INTERVAL * 1000000.0f)));

		float Alpha = Point1.Timestamp <= StartTimeStamp ? 1.0f : (float)(CurrentTime - StartTimeStamp) / (float)(Point1.Timestamp - StartTimeStamp);
		Position = FMath::LerpStable(Transform0.Position, Transform1.Position, Alpha);
		InContext.Alpha = Alpha;
		ALOG_DEBUG_POSITION(Owner, "FMovementSimulator::SimulateDefault 1 Position[%s], CurrentPosition[%s], RealSpeed[%f], Position0[%s], Position1[%s]", 
			*Position.ToString(), *CurrentPosition.ToString(), (Position - CurrentPosition).Length() / DeltaTime, *Transform0.Position.ToString(), *Transform1.Position.ToString());
	}
	else
	{
		int32 MoveTimeInUs = Point0.MoveTime * 1000;
		FVector PredictPosition = Transform0.Position + Transform0.Velocity * MoveTimeInUs / 1000000.0f;
		int32 ElapsedTime = CurrentTime - Point0.Timestamp;
		if (MoveTimeInUs > 0)
		{
			float Alpha = FMath::Clamp((float)ElapsedTime / (float)MoveTimeInUs, 0.0f, 1.0f);
			Position = FMath::LerpStable(Transform0.Position, PredictPosition, Alpha);
			ALOG_DEBUG_POSITION(Owner, "FMovementSimulator::SimulateDefault 2 Position[%s], CurrentPosition[%s], RealSpeed[%f], Position0[%s]", 
				*Position.ToString(), *CurrentPosition.ToString(), (Position - CurrentPosition).Length() / DeltaTime, *Transform0.Position.ToString());
		}
		else
		{
			Position = Transform0.Position;
			ALOG_DEBUG_POSITION(Owner, "FMovementSimulator::SimulateDefault 3 Position[%s], CurrentPosition[%s], RealSpeed[%f]", 
				*Position.ToString(), *CurrentPosition.ToString(), (Position - CurrentPosition).Length() / DeltaTime);
		}
		InContext.Alpha = 0.0f;
	}
}

void FMovementSimulator::SimulateJumping(int32 CurrentTime, MovementDataNode Node, FVector& Position, SimulateContext& InContext)
{
	const MovementData& Point0 = *Node;
	const MovementTransform& Transform0 = GetMovementTransform(Point0);

	if (++Node != MovementDatas.end())
	{
		const MovementData& Point1 = *Node;
		const MovementTransform& Transform1 = GetMovementTransform(Point1);

		float Alpha = (float)(CurrentTime - Point0.Timestamp) / (float)(Point1.Timestamp - Point0.Timestamp);
		Position = FMath::LerpStable(Transform0.Position, Transform1.Position, Alpha);

		float TotalTime = (float)(Point1.Timestamp - Point0.Timestamp) / 1000000.0f;
		float ElapsedTime = (float)(CurrentTime - Point0.Timestamp) / 1000000.0f;

		// 计算补偿速度
		float FallingHeight = CalculateFallingHeight(Transform0.Velocity.Z, Point0.GravityScale, TotalTime);
		float CompensateVelocityZ = (Transform1.Position.Z - Transform0.Position.Z - FallingHeight) / TotalTime;

		FallingHeight = CalculateFallingHeight(Transform0.Velocity.Z, Point0.GravityScale, ElapsedTime);
		Position.Z = Transform0.Position.Z + FallingHeight + CompensateVelocityZ * ElapsedTime;

		InContext.Alpha = Alpha;
	}
	else
	{
		int32 MoveTimeInUs = (Point0.Protocol == NetChannelDataProtocol::ClientSyncMovement) ? Point0.MoveTime * 1000 :
			static_cast<int32>(1000000.0f / static_cast<float>(MovementConst::SERVER_FRAME_RATE) * MovementConst::SERVER_EXTRAPOLATION_RATIO);
		int32 ElapsedTime = CurrentTime - Point0.Timestamp;
		if (MoveTimeInUs > 0)
		{
			float ElapsedTimeInS = (float)FMath::Min(ElapsedTime, MoveTimeInUs) / 1000000.0f;
			float FallingHeight = CalculateFallingHeight(Transform0.Velocity.Z, Point0.GravityScale, ElapsedTimeInS);

			Position.X = Transform0.Position.X + Transform0.Velocity.X * ElapsedTimeInS;
			Position.Y = Transform0.Position.Y + Transform0.Velocity.Y * ElapsedTimeInS;
			Position.Z = Transform0.Position.Z + FallingHeight;
		}

		InContext.Alpha = 0.0f;
	}
}

float FMovementSimulator::CalculateFallingHeight(float VelocityZ, float GravityScale, float FallingTime)
{
	if (FMath::IsNearlyEqual(GravityScale, 0.0f))
	{
		GravityScale = DefaultGravityScale;
	}

	float GravityZ = Owner->GetGravityZ() * GravityScale / Owner->GravityScale;
	float VelocityLimit = -Owner->GetPhysicsVolume()->TerminalVelocity;

	float EndVelocityZ = FMath::Max(VelocityZ + GravityZ * FallingTime, VelocityLimit);

	float Height = 0.0f;
	if (FMath::IsNearlyEqual(EndVelocityZ, VelocityLimit))
	{
		if (VelocityZ - VelocityLimit > UE_SMALL_NUMBER)
		{
			float AccelerateTime = (VelocityLimit - VelocityZ) / -GravityZ;
			return (VelocityZ + EndVelocityZ) / 2.0f * AccelerateTime + EndVelocityZ * (FallingTime - AccelerateTime);
		}
		else
		{
			return VelocityZ * FallingTime;
		}
	}
	else
	{
		return (VelocityZ + EndVelocityZ) / 2.0f * FallingTime;
	}
}

float FMovementSimulator::SameSignAngle(float DstAngle)
{
	return MathFormula::SameSignAngle(Owner->GetCharacterOwner()->GetActorRotation().Yaw, DstAngle);
}

float FMovementSimulator::SameSignMountPitchAngle(float DstAngle)
{
	float MountPitch = Owner->GetRoleMP().GetMovementContext().GetMountPitch();
	return MathFormula::SameSignAngle(MountPitch, DstAngle);
}

float FMovementSimulator::SameSignMountRollAngle(float DstAngle)
{
	float MountRoll = Owner->GetRoleMP().GetMovementContext().GetMountRoll();
	return MathFormula::SameSignAngle(MountRoll, DstAngle);
}

void FMovementSimulator::UpdateRiding(MovementDataNode Node, SimulateContext& InContext)
{
	const MovementData& Point0 = *Node;
	float MountPitch = 0.0f;
	float MountRoll = 0.0f;
	float MountRootOffset = 0.0f;
	if (++Node != MovementDatas.end())
	{
		const MovementData& Point1 = *Node;
		MountPitch = FMath::LerpStable(SameSignMountPitchAngle(Point0.MountPitch), SameSignMountPitchAngle(Point1.MountPitch), InContext.Alpha);
		MountRoll = FMath::LerpStable(SameSignMountPitchAngle(Point0.MountRoll), SameSignMountPitchAngle(Point1.MountRoll), InContext.Alpha);
		MountRootOffset = FMath::LerpStable((Point0.MountRootOffset), (Point1.MountRootOffset), InContext.Alpha);
	}
	else
	{
		MountPitch = SameSignMountPitchAngle(Point0.MountPitch);
		MountRoll = SameSignMountRollAngle(Point0.MountRoll);
		MountRootOffset = Point0.MountRootOffset;
	}
	Owner->GetRoleMP().GetMovementContext().SetMountPostureParam(MountPitch, MountRoll, MountRootOffset);
}

bool FMovementSimulator::SimulateBrief(float DeltaTime, int32 CurrentTime, MovementDataNode Node, FVector& OutPosition)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("SimulateBrief");

	if (!BriefOwner.IsValid())
    {
        return false;
    }

	if (++Node == MovementDatas.end())
	{
		return false;
	}
	const MovementData& Point1 = *Node;

	float Alpha = Point1.Timestamp <= SimulatedTimestamp ? 1.0f : FMath::Min(DeltaTime * 1000000.0f / (float)(Point1.Timestamp - SimulatedTimestamp), 1.0f);
    FVector Position = FMath::LerpStable(BriefOwner->GetBriefActorTransform()->GetLocation(), Point1.Transform.Position, Alpha);

	OutPosition = Position;
	return true;
}

void FMovementSimulator::FinishSimulate() 
{
	MovementDatas.clear();
	UpdateLocomotionState(0, false);
}

bool FMovementSimulator::NeedFixServerPositionToFloor()
{
	return Owner->GetNeedServerFixPosition() && Owner->IsMovingOnGround() && Owner->GetCurrentIsNetSimulate();
}

void FMovementSimulator::FixServerPositionToFloor(FVector& Position)
{
	if (ABaseCharacter* Character = Cast<ABaseCharacter>(Owner->GetCharacterOwner()))
	{
		FVector FloorPosition = Position;
		URoleMovementComponent* MoveComp = Cast<URoleMovementComponent>(Character->GetMovementComponent());

		if (Character->CheckActorStickGround(IsValid(MoveComp) ? MoveComp->GetTrackFloorCollisionPresetName() : DefaultMovementFindFloorCollisionPresetName, 55.0f, FloorPosition, &Position, false))
		{
			Position.Z = FloorPosition.Z;
		}
	}
}

void FMovementSimulator::GetTargetDirectionParam(bool& bDriectionValue, float& TargetValue)
{
	bDriectionValue = bHasTargetDirection;
	TargetValue = TargetDirection;
}

void FMovementSimulator::AddFixedPathBySpawnedSpline(uint32 PathID, USplineComponent* SplineComponent, std::vector<SplineInterpolator::PointAttr> PointAttrs)
{
	FixedPathInterp.AddSpawnedSpline(PathID, SplineComponent, PointAttrs);
}

MovementTransform FMovementSimulator::GetMovementTransform(const MovementData& Point)
{
	if (Point.Flags & MovementSyncFlag::Relative)
	{
		AActor* RelativeTarget = Owner->ClientMoveDataRelativeTarget.Get();
		if (IsValid(RelativeTarget))
		{
			FTransform Transform = RelativeTarget->GetTransform();
			return MovementTransform
			{
				Transform.TransformPosition(Point.RelativeTranform.Position),
				Transform.TransformRotation(Owner->GetCharacterOwner()->GetActorQuat()).Rotator(),
				Transform.TransformVector(Point.RelativeTranform.Velocity),
			};
		}
	}
	return Point.Transform;
}

void FMovementSimulator::OnReceiveRotateInstantly(const RotateInstantlyMsg& Msg)
{
	RotateInstantlyTimestamp = Msg.Timestamp;
	ACharacter* CharacterOwner = Owner->GetCharacterOwner();
	if (CharacterOwner)
	{
		FRotator Rotation = CharacterOwner->GetActorRotation();
		Rotation.Yaw = Msg.Rotation.Yaw;
		CharacterOwner->SetActorRotation(Rotation);
		Owner->RotateInstantlyByMovePipeline(Rotation);
		Owner->ProduceNetShadowMovement(CharacterOwner->GetActorLocation(), Rotation);
	}
}

void FMovementSimulator::UpdateMoveState(const FVector& Position)
{
	bool OldIsMoveing = bIsMoving;

	if (bIsMoving)
	{
		if ((Position - LastSimulatePosition).IsNearlyZero())
		{
			bIsMoving = false;
		}
	}
	else
	{
		if (!LastSimulatePosition.IsNearlyZero() && !(Position - LastSimulatePosition).IsNearlyZero())
		{
			bIsMoving = true;
		}
	}

	LastSimulatePosition = Position;
	bMoveStateChanged = OldIsMoveing != bIsMoving;
}

void FMovementSimulator::TriggerMoveEvent()
{
	if (bMoveStateChanged)
	{
		bMoveStateChanged = false;
		Owner->OnSimulateMoveEvent(SimulateType, bIsMoving);
	}
}

void FMovementSimulator::OnUpdateTargetDirection(const MovementData& TargetPoint)
{
	if (bHasTargetDirection != TargetPoint.bHasTargetDirection)
	{
		Owner->UpdateIsUsingTargetAngleLean(TargetPoint.bHasTargetDirection);
	}
	bHasTargetDirection = TargetPoint.bHasTargetDirection;
	if (bHasTargetDirection)
	{
		TargetDirection = TargetPoint.TargetDirection;
		UE_LOG(LogTemp, Log, TEXT("[Synchronization] OnUpdateTargetDirection CurrentYaw[%f], TargetYaw[%f], bHasTargetDirection[%d]"),
			Owner->GetCharacterOwner()->GetActorRotation().Yaw, TargetPoint.TargetDirection, bHasTargetDirection);
	}
}

void FMovementSimulator::ChangeSimulateType(EMoveSimulateType Type)
{
	bool bFullBriefChange = (SimulateType == EMoveSimulateType::Server && Type == EMoveSimulateType::ServerBrief)
		|| (SimulateType == EMoveSimulateType::ServerBrief && Type == EMoveSimulateType::Server);
	if (!bFullBriefChange)
	{
		MovementDatas.clear();
	}
	LastReceivedTimestamp = -1;
	SimulateType = Type;
}

bool FMovementSimulator::SimulateFixedPath(float DeltaTime, int32 CurrentTime, MovementDataNode Node, FVector& OutPosition, FRotator& OutRotation)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("SimulateFixedPath");

	if (Node == MovementDatas.end())
	{
		return false;
	}

	if (!Owner.IsValid())
    {
        return false;
    }

	ACharacter* CharacterOwner = Owner->GetCharacterOwner();
	OutPosition = CharacterOwner->GetActorLocation();
	OutRotation = CharacterOwner->GetActorRotation();

	const MovementData& Point0 = *Node;
	const FixedPathData& FixedPath0 = Point0.FixedPath;
    if (!FixedPathInterp.TryInit(Owner.Get(), FixedPath0.PathId, static_cast<float>(FixedPath0.Speed)))
	{
		UE_LOG(LogTemp, Warning, TEXT("[Synchronization] SimulateFixedPath interp init failed"));
		return false;
	}
	FixedPathInterp.SetFlag(FixedPath0.Flag);

	float Time = static_cast<float>(FixedPath0.Frame) / 15.0f;
	if (!(FixedPath0.Flag & FixedPathFlag::Pause))
	{
		Time += static_cast<float>(CurrentTime - Point0.Timestamp) / 1000000.0f;
	}

	bool FixedPathFinished = Time >= FixedPathInterp.GetDuration();
	if (FixedPathFinished && bFixedPathFinished)
	{
		return true;
	}
	bFixedPathFinished = FixedPathFinished;

	if (FixedPathInterp.Eval(Time, OutPosition, OutRotation))
	{
		OutPosition.Z += OwnerCapsuleHalfHeight;
	}

	return true;
}