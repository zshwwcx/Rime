#include "3C/Movement/SplineController/SplineStationControl.h"
#include "3C/Interactor/Spline/C7GameplaySplineWithStation.h"
#include "Components/SplineComponent.h"
#include "3C/Movement/RoleMovementComponent.h"

FSplineStationControl::FSplineStationControl()
{
}

FSplineStationControl::~FSplineStationControl()
{
}

void FSplineStationControl::OnInit()
{
	
}
void FSplineStationControl::OnReset()
{
	bStationDataCorrect = false;
	bClosedLoop = false;
	HasStop = false;
	Flag = 0;
	CurTime = 0.f;
	Speed = 0.0f;
	Length = 0.0f;
	Duration = 0.0f;
	TimeTable.Empty();
	ReverseTimeTable.Empty();
	CurTimeTable = &TimeTable;
}
	
bool FSplineStationControl::SetUpAfterSplineReady()
{
	if (const AC7GameplaySplineWithStation* SplineWithStation = Cast<const AC7GameplaySplineWithStation>(SplineActor.Get()))
	{
		Stations = SplineWithStation->Stations;
		bClosedLoop = SplineComp->IsClosedLoop();
		bStationDataCorrect = InitStationAfterSplineReady();
		ConsumeMoveFlag();
		return bStationDataCorrect;
	}
	return false;
}

bool FSplineStationControl::DoSplineControlTick(URoleMovementComponent& MovementComponent, float DeltaTime)
{
	if (!bStationDataCorrect)
	{
		return false;
	}
	
	if (!(Flag & MoveFlag::Pause))
	{
		CurTime += DeltaTime;
	}

	bool FixedPathFinished = CurTime >= GetDuration();
	if (FixedPathFinished && bMoveFinished)
	{
		return true;
	}
	bMoveFinished = FixedPathFinished;

	FVector OutPosition = FVector::ZeroVector;
	FRotator OutRotation = FRotator::ZeroRotator;
	if (Eval(CurTime, OutPosition, OutRotation))
	{
		OutPosition.Z += OwnerCapsuleHalfHeight;
		
		MovementComponent.RequestMoveWithVelocityToSetAbsolutePosAndRot(OutPosition, OutRotation.Quaternion());
	}
	
	return bMoveFinished;
}

bool FSplineStationControl::RestartWithMoveFlag(uint8 InMoveFlag)
{
	CurTime = 0.f;
	bMoveFinished = false;
	if (!bSplineInitialized)
	{
		bCacheMoveFlag = true;
		TargetFlag = InMoveFlag;
		return true;
	}
	bCacheMoveFlag = false;
	SetFlag(InMoveFlag);
	return true;
}

bool FSplineStationControl::InitStationAfterSplineReady()
{
	bool bCloseLoop = SplineComp->IsClosedLoop();
	int32 StationNum = Stations.Num();
	int32 PointNum = SplineComp->GetNumberOfSplinePoints();
	if (PointNum < 2 || PointNum != SplineComp->GetNumberOfSplinePoints())
	{
		UE_LOG(LogTemp, Warning, TEXT("FSplineStationControl::InitStationAfterSplineReady point num less than 2 or station num not equals, PointNum:%d, StationNum:%d"), PointNum, StationNum)
		return false;
	}
	
	for (auto& Station : Stations)
	{
		Station.InStopDistance *= 100.f;
		Station.OutStopDistance *= 100.f;
	}
	return bCloseLoop ? InitLoop() : InitNoLoop();
}

void FSplineStationControl::ConsumeMoveFlag()
{
	if (bCacheMoveFlag)
	{
		SetFlag(TargetFlag);
		bCacheMoveFlag = false;
	}
}

bool FSplineStationControl::InitLoop()
{
	HasStop = false;
	int32 PointNum = Stations.Num();
	int StartIndex = 0;
	for (int Index = 0; Index < PointNum; ++Index)
	{
		const auto& Attr = Stations[Index];
		if (Attr.IsStop)
		{
			StartIndex = Index;
			HasStop = true;
			break;
		}
	}
	int EndIndex = StartIndex + PointNum;

	float StartDistance = SplineComp->GetDistanceAlongSplineAtSplinePoint(StartIndex);
	float EndDistance = SplineComp->GetDistanceAlongSplineAtSplinePoint(EndIndex);
	Length = SplineComp->GetSplineLength();

	// 简化计算，暂不支持速度区间重叠
	float Time = 0.0f;
	float Dis = StartDistance;
	auto& Table = TimeTable;
	Table.Emplace(TimeInfo{ Time, Dis, FLAG_NONE });


	if (HasStop)
	{
		for (int Index = StartIndex; Index <= EndIndex; ++Index)
		{
			int AttrIndex = Index % PointNum;
			const auto& Attr = Stations[AttrIndex];
			if (Attr.IsStop)
			{
				int DisIndex = AttrIndex == 0 && Index != 0 ? PointNum : AttrIndex;
				float StopDis = SplineComp->GetDistanceAlongSplineAtSplinePoint(DisIndex);
				float SlowDownDis = StopDis - Attr.InStopDistance;
				float SpeedUpDis = StopDis + Attr.OutStopDistance;

				if (Index != StartIndex)
				{
					if (SlowDownDis < 0)
					{
						SlowDownDis += Length;
					}
					if (StopDis > Dis && SlowDownDis < Dis)
					{
						// 减速前已进入最大速度
						UE_LOG(LogTemp, Warning, TEXT("FSplineStationControl::InitLoop invalid spline data Index[%d], SplineInsID[%s], SlowDownDis[%f], Dis[%f]"),
							Index, *SplineInsID, SlowDownDis, Dis);
						return false;
					}
					float Diff = SlowDownDis - Dis;
					if (float DeltaTime = (Diff > 0.0f ? Diff : Diff + Length) / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Table.Emplace(TimeInfo{ Time, SlowDownDis, FLAG_NONE });
					}
					if (float DeltaTime = Attr.InStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Table.Emplace(TimeInfo{ Time, StopDis, FLAG_SLOW_DOWN });
					}
				}

				if (Index != EndIndex)
				{
					if (float DeltaTime = Attr.StopTime; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Table.Emplace(TimeInfo{ Time, StopDis, FLAG_STOP });
					}
					if (SpeedUpDis > Length)
					{
						SpeedUpDis -= Length;
					}
					if (float DeltaTime = Attr.OutStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Table.Emplace(TimeInfo{ Time, SpeedUpDis, FLAG_SPEED_UP });
					}
				}

				Dis = SpeedUpDis;
			}
		}
		Duration = Time;
	}
	else
	{
		Duration = Length / Speed;
		Table.Emplace(TimeInfo{ Duration, Length, FLAG_NONE });
	}

	Time = 0.0f;
	Dis = EndDistance;
	auto& Rtable = ReverseTimeTable;
	Rtable.Emplace(TimeInfo{ Time, Dis, FLAG_NONE });

	if (HasStop)
	{
		for (int Index = EndIndex; Index >= StartIndex; --Index)
		{
			int AttrIndex = Index % PointNum;
			const auto& Attr = Stations[AttrIndex];
			if (Attr.IsStop)
			{
				int DisIndex = AttrIndex == 0 && Index != 0 ? PointNum : AttrIndex;
				float StopDis = SplineComp->GetDistanceAlongSplineAtSplinePoint(DisIndex);
				float SlowDownDis = StopDis + Attr.InStopDistance;
				float SpeedUpDis = StopDis - Attr.OutStopDistance;

				if (Index != EndIndex)
				{
					if (SlowDownDis > Length)
					{
						SlowDownDis -= Length;
					}
					if (StopDis < Dis && SlowDownDis > Dis)
					{
						// 减速前已进入最大速度
						UE_LOG(LogTemp, Warning, TEXT("FSplineStationControl::InitLoop invalid spline data Index[%d], SplineInsID[%s], SlowDownDis[%f], Dis[%f]"),
							Index, *SplineInsID, SlowDownDis, Dis);
						return false;
					}
					float Diff = Dis - SlowDownDis;
					if (float DeltaTime = (Diff > 0.0f ? Diff : Diff + Length) / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.Emplace(TimeInfo{ Time, SlowDownDis, FLAG_NONE });
					}
					if (float DeltaTime = Attr.InStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.Emplace(TimeInfo{ Time, StopDis, FLAG_SLOW_DOWN });
					}
				}

				if (Index != StartIndex)
				{
					if (float DeltaTime = Attr.StopTime; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.Emplace(TimeInfo{ Time, StopDis, FLAG_STOP });
					}
					if (SpeedUpDis < 0)
					{
						SpeedUpDis += Length;
					}
					if (float DeltaTime = Attr.OutStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.Emplace(TimeInfo{ Time, SpeedUpDis, FLAG_SPEED_UP });
					}
				}

				Dis = SpeedUpDis;
			}
		}
	}
	else
	{
		Time = Length / Speed;
		Rtable.Emplace(TimeInfo{ Time, 0.0f, FLAG_NONE });
	}

	return true;
}

bool FSplineStationControl::InitNoLoop()
{
	HasStop = false;
	int MinIndex = -1;
	int MaxIndex = -1;
	float MinDistance = 0.0f;
	float MaxDistance = 0.0f;

	for (int Index = 0; Index < Stations.Num(); ++Index)
	{
		const auto &Attr = Stations[Index];
		if (Attr.IsStop) 
		{
			if (MinIndex < 0) 
			{
				MinIndex = Index;
			}
			if (Index > MaxIndex) 
			{
				MaxIndex = Index;
			}
			HasStop = true;
		}
	}
	if (MinIndex < 0 && MaxIndex < 0) {
		MinIndex = 0;
		MaxIndex = Stations.Num() - 1;
	}
	if (MinIndex < 0 || MaxIndex < 0 || MinIndex == MaxIndex)
	{
		UE_LOG(LogTemp, Warning, TEXT("FSplineStationControl::InitNoLoop invalid MinIndex[%d], MaxIndex[%d], SplineInsID[%s]"), MinIndex, MaxIndex, *SplineInsID);
		return false;
	}

	MinDistance = SplineComp->GetDistanceAlongSplineAtSplinePoint(MinIndex);
	MaxDistance = SplineComp->GetDistanceAlongSplineAtSplinePoint(MaxIndex);
	Length = MaxDistance - MinDistance;

	// 简化计算，暂不支持速度区间重叠
	float Time = 0.0f;
	float Dis = MinDistance;
	auto& Table = TimeTable;
	Table.Emplace(TimeInfo{ Time, Dis, FLAG_NONE });

	if (HasStop)
	{
		for (int Index = MinIndex; Index <= MaxIndex; ++Index)
		{
			const auto& Attr = Stations[Index];
			if (Attr.IsStop)
			{
				float StopDis = SplineComp->GetDistanceAlongSplineAtSplinePoint(Index);
				float SlowDownDis = StopDis - Attr.InStopDistance;
				float SpeedUpDis = StopDis + Attr.OutStopDistance;

				if (Index != MinIndex)
				{
					if (SlowDownDis < Dis)
					{
						// 减速前已进入最大速度
						UE_LOG(LogTemp, Warning, TEXT("FSplineStationControl::InitNoLoop invalid spline data Index[%d], SplineInsID[%s]"), Index, *SplineInsID);
						return false;
					}
					if (float DeltaTime = (SlowDownDis - Dis) / Speed; DeltaTime > 0.0f) 
					{
						Time += DeltaTime;
						Table.Emplace(TimeInfo{ Time, SlowDownDis, FLAG_NONE });
					}
					if (float DeltaTime = Attr.InStopDistance * 2 / Speed; DeltaTime > 0.0f) 
					{
						Time += DeltaTime;
						Table.Emplace(TimeInfo{ Time, StopDis, FLAG_SLOW_DOWN });
					}
				}

				if (Index != MaxIndex)
				{
					if (float DeltaTime = Attr.StopTime; DeltaTime > 0.0f) 
					{
						Time += DeltaTime;
						Table.Emplace(TimeInfo{ Time, StopDis, FLAG_STOP });
					}
					if (float DeltaTime = Attr.OutStopDistance * 2 / Speed; DeltaTime > 0.0f) 
					{
						Time += DeltaTime;
						Table.Emplace(TimeInfo{ Time, SpeedUpDis, FLAG_SPEED_UP });
					}
				}

				Dis = SpeedUpDis;
			}
		}
		Duration = Time;
	}
	else
	{
		Duration = Length / Speed;
		Table.Emplace(TimeInfo{ Duration, Length, FLAG_NONE });
	}

	Time = 0.0f;
	Dis = MaxDistance;
	auto& Rtable = ReverseTimeTable;
	Rtable.Emplace(TimeInfo{ Time, Dis, FLAG_NONE });

	if (HasStop)
	{
		for (int Index = MaxIndex; Index >= MinIndex; --Index)
		{
			const auto& Attr = Stations[Index];
			if (Attr.IsStop)
			{
				float StopDis = SplineComp->GetDistanceAlongSplineAtSplinePoint(Index);
				float SlowDownDis = StopDis + Attr.InStopDistance;
				float SpeedUpDis = StopDis - Attr.OutStopDistance;

				if (Index != MaxIndex)
				{
					if (SlowDownDis > Dis)
					{
						// 减速前已进入最大速度
						UE_LOG(LogTemp, Warning, TEXT("FSplineStationControl::InitNoLoop invalid spline data Index[%d], SplineInsID[%s]"), Index, *SplineInsID);
						return false;
					}
					if (float DeltaTime = (Dis - SlowDownDis) / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.Emplace(TimeInfo{ Time, SlowDownDis, FLAG_NONE });
					}
					if (float DeltaTime = Attr.InStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.Emplace(TimeInfo{ Time, StopDis, FLAG_SLOW_DOWN });
					}
				}

				if (Index != MinIndex)
				{
					if (float DeltaTime = Attr.StopTime; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.Emplace(TimeInfo{ Time, StopDis, FLAG_STOP });
					}
					if (float DeltaTime = Attr.OutStopDistance * 2 / Speed; DeltaTime > 0.0f)
					{
						Time += DeltaTime;
						Rtable.Emplace(TimeInfo{ Time, SpeedUpDis, FLAG_SPEED_UP });
					}
				}

				Dis = SpeedUpDis;
			}
		}
	}
	else
	{
		Time = Length / Speed;
		Rtable.Emplace(TimeInfo{ Time, 0.0f, FLAG_NONE });
	}

	return true;
}

float FSplineStationControl::EvalTimeTable(float InVal)
{
	const auto& Points = *CurTimeTable;
	int32 PointNum = Points.Num();
	if (PointNum < 2)
	{
		return 0;
	}
	
	int32 Index = 0;
	for (; Index < PointNum; ++Index)
	{
		auto& Point = Points[Index];
		if (Point.Time > InVal )
		{
			break;
		}
	}
	
	if (Index == 0)
	{
		return Points[0].Distance;
	}
	else if (Index == PointNum)
	{
		return Points[PointNum-1].Distance;
	}

	const auto& PrevPoint = Points[Index-1];
	const auto& NextPoint = Points[Index];
	const float Diff = NextPoint.Time - PrevPoint.Time;
	if (Diff <= 0.0f)
	{
		return PrevPoint.Distance;
	}

	float Alpha = (InVal - PrevPoint.Time) / Diff;
	if (NextPoint.Flag == FLAG_SLOW_DOWN)
	{
		// y = 1 - (1 - x)^2
		Alpha = 1.0f - Alpha;
		Alpha = 1.0f - Alpha * Alpha;
	}
	else if (NextPoint.Flag == FLAG_SPEED_UP)
	{
		// y = x^2
		Alpha = Alpha * Alpha;
	}

	if (SplineComp->IsClosedLoop()) 
	{
		if (Flag & MoveFlag::Reverse)
		{
			if (PrevPoint.Distance < NextPoint.Distance)
			{
				float Distance = FMath::Lerp(PrevPoint.Distance + Length, NextPoint.Distance, Alpha);
				return Distance < Length ? Distance : Distance - Length;
			}
		}
		else
		{
			if (PrevPoint.Distance > NextPoint.Distance)
			{
				float Distance = FMath::Lerp(PrevPoint.Distance, NextPoint.Distance + Length, Alpha);
				return Distance < Length ? Distance : Distance - Length;
			}
		}
	}
	return FMath::Lerp(PrevPoint.Distance, NextPoint.Distance, Alpha);
}

void FSplineStationControl::SetFlag(uint8_t InFlag)
{
	if (Flag == InFlag)
	{
		return;
	}
	CurTimeTable = (InFlag & MoveFlag::Reverse) ? &ReverseTimeTable : &TimeTable;
	Flag = InFlag;
}

bool FSplineStationControl::Eval(float InTime, FVector& OutPosition, FRotator& OutRotation)
{
	float Distance = EvalTimeTable(InTime);
	FTransform Transform = SplineComp->GetTransformAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
	OutPosition = Transform.GetLocation();
	FQuat Quat = Transform.GetRotation();
	// 非环路倒车行驶
	if (Flag & MoveFlag::ReverseDirection)
	{
		FVector Forward = Quat.Rotator().Vector();
		Forward = -1.0 * Forward;
		OutRotation = Forward.Rotation();
	}
	else
	{
		OutRotation = Quat.Rotator();
	}
	return true;
}

#if UE_BUILD_DEVELOPMENT
void FSplineStationControl::AppendDebugInfo(FString& infoOut)
{
	
}
#endif