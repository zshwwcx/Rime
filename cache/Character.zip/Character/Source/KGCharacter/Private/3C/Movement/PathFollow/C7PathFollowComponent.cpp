#include "3C/Movement/PathFollow/C7PathFollowComponent.h"

#include "3C/Character/BaseCharacter.h"
#include  "3C/Movement/RoleMovementComponent.h"
#include "3C/Core/KGUEActorManager.h"
#include "Components/CapsuleComponent.h"


UC7PathFollowComponent::UC7PathFollowComponent(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	
}

void UC7PathFollowComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	if (bIsSimpleFollowing)
	{
		ApplySimpleFollow();
		SimpleFollowTickAcc += DeltaTime;
		if (SimpleFollowTickAcc >= SimpleFollowTickInterval)
		{
			SimpleFollowTickAcc = 0.0f;
			UpdateSimpleFollow();
		}
		return;
	}

	UPathFollowingComponent::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (IsValid(RelativeLocPathFollowTarget.Get()))
	{
		FVector OwnerLoc = GetOwner()->GetActorLocation();
		FVector TargetLoc = RelativeLocPathFollowTarget.Get()->GetActorLocation();
		float TargetActorVelocityValue = DeltaTime > 0.0f ? (TargetLoc - LastFrameTargetActorLoc).Size() / DeltaTime : RelativeLocPathFollowTarget.Get()->GetVelocity().Size();
		LastFrameTargetActorLoc = TargetLoc;

		FRotator TargetRot = RelativeLocPathFollowTarget.Get()->GetActorRotation();
		TargetLoc = TargetLoc + TargetRot.RotateVector(KeepinngPathFollowRelativeLoc);

		float TargetVelocityValue = DeltaTime > 0.0f ? FMath::Min((TargetLoc - LastFrameTargetLoc).Size() / DeltaTime, TargetActorVelocityValue) : TargetActorVelocityValue;
		LastFrameTargetLoc = TargetLoc;
		float TargetOwnerDist2D = (TargetLoc - OwnerLoc).Size2D();

		// UE_LOG(LogTemp, Warning, TEXT("[szk]TargetSpeed:%f, TargetOwnerDist2D:%f"), TargetVelocityValue, TargetOwnerDist2D);
		
		if (IsRestartChecking)
		{
			// 自身与目标位置距离大于KeepingPathFollowGap，或目标位置与进入Restart时的距离大于KeepingPathFollowGap，允许重新启动
			if (TargetOwnerDist2D > KeepingPathFollowGap || (TargetLoc - StartRestartCheckTargetRelativeLoc).Size() > KeepingPathFollowGap)
			{
				if (ABaseCharacter* OwnerActor = Cast<ABaseCharacter>(GetOwner()))
				{
					ACTOR_CALL_LUA_ENTITY(OwnerActor, "KCB_OnReceiveRelativeLocPathFollowTargetMovedFar");
				}
			}
		}
		
		if (IsChaseVelocityChecking)
		{
			if (URoleMovementComponent* RoleMoveComp = GetOwner()->FindComponentByClass<URoleMovementComponent>())
			{
				// 远距离追赶逻辑
				if (TargetOwnerDist2D > VelocitySuitGap)
				{
					if (TargetOwnerDist2D > (VelocitySuitGap * 2.0f - KeepingPathFollowAcceptanceRadius))
					{
						// 避免速度抖动
						TargetVelocityValue += SpeedAdjustValue;
					}
					// 自身与目标距离大于VelocitySuitGap时，速度使用DefaultChaseSpeed和目标速度的最大值
					float MaxVelocity = FMath::Max(DefaultChaseSpeed, TargetVelocityValue);
					RoleMoveComp->SetLocoMaxSpeed(MaxVelocity);
					// UE_LOG(LogTemp, Warning, TEXT("[szk]LocoMaxSpeed1:%f"), MaxVelocity);
				}
				// 近距离跟随逻辑
				else
				{
					if (TargetOwnerDist2D > (VelocitySuitGap * 0.5f + KeepingPathFollowAcceptanceRadius))
					{
						// 避免速度抖动
						TargetVelocityValue += SpeedAdjustValue;
					}
					// 自身与目标距离小于VelocitySuitGap时，速度使用MinChaseSpeed和目标速度的最大值
					float MinVelocity = FMath::Max(MinChaseSpeed, TargetVelocityValue);
					RoleMoveComp->SetLocoMaxSpeed(MinVelocity);
					// UE_LOG(LogTemp, Warning, TEXT("[szk]LocoMaxSpeed2:%f"), MinVelocity);
				}
			}
		}
	}
}

void UC7PathFollowComponent::UpdatePathSegment()
{
	Super::UpdatePathSegment();

	if (!Path.IsValid() || NavMovementInterface == nullptr)
	{
		return;
	}

	if (HasMovementAuthority() && Status == EPathFollowingStatus::Moving && MoveSegmentEndIndex > PreciseAcceptanceRadiusCheckStartNodeIndex)
	{
		const float AcceptanceRangeToUse = GetFinalAcceptanceRadius(*Path, OriginalMoveRequestGoalLocation);
		// 对于AcceptanceRadius为0的精确到达情况，判断角色回归DefaultLocoState后结束
		if (AcceptanceRangeToUse <= 0.0f)
		{
			if (URoleMovementComponent* RoleMoveComp = GetOwner()->FindComponentByClass<URoleMovementComponent>())
			{
				if (RoleMoveComp->IsInDefaultLocoState())
				{
// 这里的逻辑参考UPathFollowingComponent::HasReachedDestination
					const FVector CurrentLocation = NavMovementInterface->GetFeetLocation();
					
					// get cylinder at goal location
					FVector GoalLocation = *Path->GetPathPointLocation(Path->GetPathPoints().Num() - 1);
					float GoalRadius = 0.0f;
					float GoalHalfHeight = 0.0f;

					// take goal's current location, unless path is partial or last segment doesn't reach goal actor (used by tethered AI)
					if (!Path->IsPartial() && bMoveToGoalOnLastSegment)
					{
						GoalLocation = *CurrentDestination;

						// Testing IsNearlyZero is not optimal as (0,0,0) could be a valid world position. Tracking the initialization state inside FBasedPosition would be better.
						if (GoalLocation.IsNearlyZero() && DestinationActor.IsValid() && !bMoveToGoalClampedToNavigation)
						{
							// In case CurrentDestination is not set because we didn't update MoveSegment yet, let's use the goal Actor's location directly
							if (DestinationAgent)
							{
								const AActor* OwnerActor = GetOwner();
								FVector GoalOffset;
								DestinationAgent->GetMoveGoalReachTest(OwnerActor, MoveOffset, GoalOffset, GoalRadius, GoalHalfHeight);

								GoalLocation = FQuatRotationTranslationMatrix(DestinationActor->GetActorQuat(), DestinationAgent->GetNavAgentLocation()).TransformPosition(GoalOffset);
							}
							else
							{
								GoalLocation = DestinationActor->GetActorLocation();
							}
						}
					}

					if ((CurrentLocation - GoalLocation).SizeSquared2D() < SMALL_NUMBER)
					{
						OnPathFinished(EPathFollowingResult::Success, FPathFollowingResultFlags::None);
					}
				}
			}
		}
		
	}
}

void UC7PathFollowComponent::FollowPathSegment(float DeltaTime)
{
	if (!Path.IsValid() || NavMovementInterface == nullptr)
	{
		return;
	}

	const FVector CurrentLocation = NavMovementInterface->GetFeetLocation();
	const FVector CurrentTarget = GetCurrentTargetLocation();

	// set to false by default, we will set set this back to true if appropriate
	bIsDecelerating = false;

	const bool bAccelerationBased = NavMovementInterface->UseAccelerationForPathFollowing();
	if (bAccelerationBased)
	{
		CurrentMoveInput = (CurrentTarget - CurrentLocation).GetSafeNormal();

		if (bStopMovementOnFinish && (MoveSegmentStartIndex >= DecelerationSegmentIndex))
		{
// Modify Start By Shi Zhengkai: 相对位置寻路时，期望还是在相对位置处再触发减速
			// const FVector PathEnd = Path->GetEndLocation();
			const FVector PathEnd = CurrentTarget;
// Modify End

			const FVector::FReal DistToEndSq = FVector::DistSquared(CurrentLocation, PathEnd);

// Modify Start By Shi Zhengkai: 不使用减速机制，直接使用速度判断
			// const bool bShouldDecelerate = DistToEndSq < FMath::Square(CachedBrakingDistance);
			const bool bShouldDecelerate = DistToEndSq < FMath::Square(NavMovementInterface->GetMaxSpeedForNavMovement() * DeltaTime);
			if (bShouldDecelerate)
			{
				bIsDecelerating = true;

				//const FVector::FReal  SpeedPct = FMath::Clamp(FMath::Sqrt(DistToEndSq) / CachedBrakingDistance, 0., 1.);
				//CurrentMoveInput *= SpeedPct;
				// 最后用一帧速度来拟合，避免来回拖拽
				FVector MoveVelocity = (CurrentTarget - CurrentLocation) / DeltaTime;
				PostProcessMove.ExecuteIfBound(this, MoveVelocity);
				NavMovementInterface->RequestDirectMove(MoveVelocity, false);
				return;
			}
// Modify End
		}

		PostProcessMove.ExecuteIfBound(this, CurrentMoveInput);
		NavMovementInterface->RequestPathMove(CurrentMoveInput);
	}
	else
	{
		FVector MoveVelocity = (CurrentTarget - CurrentLocation) / DeltaTime;

		const int32 LastSegmentStartIndex = Path->GetPathPoints().Num() - 2;
		const bool bNotFollowingLastSegment = (MoveSegmentStartIndex < LastSegmentStartIndex);

		PostProcessMove.ExecuteIfBound(this, MoveVelocity);
		NavMovementInterface->RequestDirectMove(MoveVelocity, bNotFollowingLastSegment);
	}
}

void UC7PathFollowComponent::SetKeepingPahthFollowInfo(AActor* PathFollowTarget, float InX, float InY, float InZ, float InGap)
{
	if (IsValid(PathFollowTarget))
	{
		RelativeLocPathFollowTarget = PathFollowTarget;
		KeepinngPathFollowRelativeLoc.Set(InX, InY, InZ);
		KeepingPathFollowGap = InGap;

		LastFrameTargetActorLoc = RelativeLocPathFollowTarget.Get()->GetActorLocation();
		FRotator TargetRot = RelativeLocPathFollowTarget.Get()->GetActorRotation();
		LastFrameTargetLoc = LastFrameTargetActorLoc + TargetRot.RotateVector(KeepinngPathFollowRelativeLoc);
	}
}

void UC7PathFollowComponent::ResetKeepingPahthFollowInfo()
{
	RelativeLocPathFollowTarget = nullptr;
	KeepinngPathFollowRelativeLoc.Set(0.0f, 0.0f, 0.0f);
	StartRestartCheckTargetRelativeLoc.Set(0.0f, 0.0f, 0.0f);

	IsRestartChecking = false;
	IsChaseVelocityChecking = false;
}

void UC7PathFollowComponent::StartRestartCheck()
{
	if (IsValid(RelativeLocPathFollowTarget.Get()))
	{
		IsRestartChecking = true;

		StartRestartCheckTargetRelativeLoc = RelativeLocPathFollowTarget.Get()->GetActorLocation();
		FRotator TargetRot = RelativeLocPathFollowTarget.Get()->GetActorRotation();
		StartRestartCheckTargetRelativeLoc = StartRestartCheckTargetRelativeLoc + TargetRot.RotateVector(KeepinngPathFollowRelativeLoc);
	}
}

void UC7PathFollowComponent::StopRestartCheck()
{
	IsRestartChecking = false;
	StartRestartCheckTargetRelativeLoc.Set(0.0f, 0.0f, 0.0f);
}

void UC7PathFollowComponent::StartChaseVelocityCheck(float InMinChaseSpeed, float InDefaultChaseSpeed, float InVelocitySuitGap, float InKeepingPathFollowAcceptanceRadius)
{
	if (IsValid(RelativeLocPathFollowTarget.Get()))
	{
		MinChaseSpeed = InMinChaseSpeed;
		KeepingPathFollowAcceptanceRadius = InKeepingPathFollowAcceptanceRadius;
		VelocitySuitGap = FMath::Max(InVelocitySuitGap, KeepingPathFollowAcceptanceRadius);
		DefaultChaseSpeed = InDefaultChaseSpeed;
		IsChaseVelocityChecking = true;
	}
}

void UC7PathFollowComponent::StopChaseVelocityCheck()
{
	IsChaseVelocityChecking = false;
}

void UC7PathFollowComponent::UpdateNavData(ANavigationData* InNavigateData)
{
	if (IsValid(InNavigateData))
	{
		MyNavData = InNavigateData;
	}
}

// ========== 简单跟随功能实现 ==========

void UC7PathFollowComponent::StartSimpleFollow(AActor* TargetActor, float InnerRadius, float OuterRadius, float OffsetX, float OffsetY, float OffsetZ, bool bEnableFrameStickGround)
{
	if (!IsValid(TargetActor))
	{
		return;
	}

	SimpleFollowTarget = TargetActor;
	bIsSimpleFollowing = true;
	SimpleFollowInnerRadius = FMath::Max(0.0f, InnerRadius);
	SimpleFollowOuterRadius = FMath::Max(SimpleFollowInnerRadius, OuterRadius);
	SimpleFollowOffset.Set(OffsetX, OffsetY, OffsetZ);
	SimpleFollowTickAcc = 0.0f;
	
	// 预计算半径平方值
	InnerRadiusSquared = FMath::Square(SimpleFollowInnerRadius);
	OuterRadiusSquared = FMath::Square(SimpleFollowOuterRadius);
	
	// 缓存所有组件
	AActor* Owner = GetOwner();
	CachedOwner = Owner;
	if (Owner)
	{
		CachedRoleMoveComp = Owner->FindComponentByClass<URoleMovementComponent>();
		
		if (CachedRoleMoveComp.IsValid())
		{
			CachedMaxSpeed = CachedRoleMoveComp->GetLocoMaxSpeed();
			CachedEnableFrameStickGround = bEnableFrameStickGround;
			
			CachedRoleMoveComp->SetUseComplexFrameStickGround(false);
			CachedRoleMoveComp->SetNeedFrameStickGroundForceValue(bEnableFrameStickGround, TEXT("SimpleFollow"));
		}
		
		if (UCapsuleComponent* FollowerCapsule = Owner->FindComponentByClass<UCapsuleComponent>())
		{
			CachedFollowerHalfHeight = FollowerCapsule->GetScaledCapsuleHalfHeight();
		}
	}
	
	CachedTargetMoveComp = TargetActor->FindComponentByClass<URoleMovementComponent>();
	
	// 初始化缓存状态
	bCachedWantsMove = false;
	CachedMoveVelocity = FVector::ZeroVector;
	
	SetComponentTickEnabled(true);
	UpdateSimpleFollow();
}

void UC7PathFollowComponent::StopSimpleFollow()
{
	bIsSimpleFollowing = false;
	SimpleFollowTarget = nullptr;

	// 停止移动
	if (CachedRoleMoveComp.IsValid())
	{
		CachedRoleMoveComp->ClearNeedFrameStickGroundForceValue(TEXT("SimpleFollow"));
		CachedRoleMoveComp->RequestDirectMove(FVector::ZeroVector, false);
	}
	
	// 清理缓存
	CachedOwner = nullptr;
	CachedRoleMoveComp = nullptr;
	CachedTargetMoveComp = nullptr;
	CachedMaxSpeed = 0.0f;
	CachedFollowerHalfHeight = 0.0f;
	CachedEnableFrameStickGround = false;
	bCachedWantsMove = false;
	CachedMoveVelocity = FVector::ZeroVector;
	
	if (!GetNeedTick())
	{
		SetComponentTickEnabled(false);
	}
}

void UC7PathFollowComponent::ApplySimpleFollow()
{
	if (!bCachedWantsMove || !CachedRoleMoveComp.IsValid())
	{
		return;
	}

	// 是否开启逐帧贴地
	if (CachedEnableFrameStickGround)
	{
		CachedRoleMoveComp->RequestDirectMove(CachedMoveVelocity, false);
	}
	else
	{
		CachedRoleMoveComp->RequestDirectMoveWithZ(CachedMoveVelocity, false, true);
	}
}

void UC7PathFollowComponent::UpdateSimpleFollow()
{
	if (!SimpleFollowTarget.IsValid() || !CachedOwner.IsValid() || !CachedRoleMoveComp.IsValid())
	{
		StopSimpleFollow();
		return;
	}

	// 判断主角是否在地面
	if (CachedTargetMoveComp.IsValid())
	{
		if (!CachedTargetMoveComp->GetHasLocoGroundSupport())
		{
			bCachedWantsMove = false;
			CachedMoveVelocity = FVector::ZeroVector;
			return;
		}
	}
	
	// 获取位置并计算距离
	const FVector OwnerLocation = CachedOwner->GetActorLocation();
	const FVector RawTargetLocation = SimpleFollowTarget->GetActorLocation();
	const FVector RawToTarget = RawTargetLocation - OwnerLocation;
	const float DistSqRaw2D = RawToTarget.X * RawToTarget.X + RawToTarget.Y * RawToTarget.Y;

	FVector TargetLocation = RawTargetLocation;
	// 计算旋转偏移
	if (!SimpleFollowOffset.IsNearlyZero())
	{
		const FRotator TargetActorRot = SimpleFollowTarget->GetActorRotation();
		TargetLocation += TargetActorRot.RotateVector(SimpleFollowOffset);
	}
	const FVector ToTarget = TargetLocation - OwnerLocation;
	const float DistSq2D = ToTarget.X * ToTarget.X + ToTarget.Y * ToTarget.Y;

	// 在小圈内，待机
	if (DistSqRaw2D <= InnerRadiusSquared)
	{
		bCachedWantsMove = false;
		CachedMoveVelocity = FVector::ZeroVector;
		return;
	}
	
	// 超过大圈半径，直接瞬移
	if (DistSqRaw2D > OuterRadiusSquared)
	{
		FVector TeleportLocation = TargetLocation;
		if (CachedFollowerHalfHeight > 0.0f)
		{
			// 优先用目标胶囊体计算bottom：TargetCenterZ - TargetHalfHeight，再加上跟随者HalfHeight
			if (UCapsuleComponent* TargetCapsule = SimpleFollowTarget->FindComponentByClass<UCapsuleComponent>())
			{
				const float TargetHalfHeight = TargetCapsule->GetScaledCapsuleHalfHeight();
				TeleportLocation.Z = TargetLocation.Z - TargetHalfHeight + CachedFollowerHalfHeight;
			}
		}
		
		FRotator TeleportRotation = SimpleFollowTarget->GetActorRotation();
		TeleportRotation.Pitch = 0.0f;
		TeleportRotation.Roll = 0.0f;
		
		CachedRoleMoveComp->RequestDirectMove(FVector::ZeroVector, false);
		CachedRoleMoveComp->GetRealMovementViewProxy()->TeleportTo(TeleportLocation, TeleportRotation, true);
		bCachedWantsMove = false;
		CachedMoveVelocity = FVector::ZeroVector;
		return;
	}

	// 小圈和大圈之间，更新缓存的移动数据
	if (DistSq2D <= KINDA_SMALL_NUMBER)
	{
		bCachedWantsMove = false;
		CachedMoveVelocity = FVector::ZeroVector;
		return;
	}

	const float DistToTarget = FMath::Sqrt(DistSq2D);
	const float InvDist = 1.0f / DistToTarget;
	FVector MoveDirection(ToTarget.X * InvDist, ToTarget.Y * InvDist, 0.0f);
	
	// 接近内圈时减速
	float DesiredSpeed = CachedMaxSpeed;
	const float DecelerationStart = SimpleFollowInnerRadius * 1.5f;
	const float DistToSpeed = FMath::Sqrt(DistSqRaw2D);
	if (DistToSpeed < DecelerationStart)
	{
		float SpeedRatio = (DistToSpeed - SimpleFollowInnerRadius) / (SimpleFollowInnerRadius * 0.5f);
		DesiredSpeed = CachedMaxSpeed * FMath::Max(0.3f, SpeedRatio);
	}
	
	// 更新缓存
	CachedMoveVelocity = MoveDirection * DesiredSpeed;

	// 非贴地，计算Z方向移动
	if (!CachedEnableFrameStickGround && CachedRoleMoveComp->GetHasLocoGroundSupport())
	{
		if (ABaseCharacter* OwnerCharacter = Cast<ABaseCharacter>(CachedOwner.Get()))
		{
			FVector TargetStickGroundLoc = OwnerCharacter->SimpleGetStickGroundLocationFromSpecificLocation(TargetLocation);
			float TargetDesiredZ = TargetStickGroundLoc.Z;
			
			float ZHeightDiff = TargetDesiredZ - OwnerLocation.Z;
			
			float HorizontalSpeed = FMath::Sqrt(CachedMoveVelocity.X * CachedMoveVelocity.X + CachedMoveVelocity.Y * CachedMoveVelocity.Y);
			HorizontalSpeed = FMath::Max(HorizontalSpeed, 1.0f); // 防止除0
			float EstimatedTime = HorizontalSpeed > KINDA_SMALL_NUMBER ? 
				FMath::Max(FMath::Sqrt(DistSq2D) / HorizontalSpeed, SimpleFollowTickInterval) : 
				SimpleFollowTickInterval;
			EstimatedTime = FMath::Max(EstimatedTime, 0.001f); // 防止除0
			
			float ZVelocity = ZHeightDiff / EstimatedTime;
			ZVelocity = FMath::Clamp(ZVelocity, -MaxVerticalSpeed, MaxVerticalSpeed);
			
			// 最小高度差阈值，避免抖动
			if (FMath::Abs(ZHeightDiff) > 0.1f)
			{
				CachedMoveVelocity.Z = ZVelocity;
			}
			else
			{
				CachedMoveVelocity.Z = 0.0f;
			}
		}
	}
	
	bCachedWantsMove = true;
}
