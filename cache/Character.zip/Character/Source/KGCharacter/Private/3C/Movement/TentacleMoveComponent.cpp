// Fill out your copyright notice in the Description page of Project Settings.


#include "3C/Movement/TentacleMoveComponent.h"

#include "3C/Character/BaseCharacter.h"
#include "NiagaraComponent.h"
#include "NiagaraFunctionLibrary.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetSystemLibrary.h"

// 发射起始点
static const FName& PN_START_POINT = "StartPoint";
// 发射目标点
static const FName& PN_END_POINT = "EndPoint";
// 碰撞法向量
static const FName& PN_IMPACT_NORMAL = "ImpactNormal";
// 数值越大,熟手越细
static const FName& PN_SIZE = "Size";
// 骨骼名
static const FName& PN_ATTACH_BONE = "pelvis";

// #pragma optimize("", off)

// Sets default values for this component's properties
UTentacleMoveComponent::UTentacleMoveComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	NiagaraList.Empty();
	SetComponentTickInterval(1.f);
}


// Called when the game starts
void UTentacleMoveComponent::BeginPlay()
{
	Super::BeginPlay();

	ABaseCharacter* BaseCharacter = Cast<ABaseCharacter>(GetOwner());
	if (!BaseCharacter)
	{
		return;
	}

	NiagaraList.Reserve(NiagaraLimit);
	TempNiagaraList.Reserve(NiagaraLimit);
	
	AttachComponent = BaseCharacter->GetMainMesh();
	CapsuleComponent = BaseCharacter->GetCapsuleComponent();
	CharacterMovementComponent = BaseCharacter->GetCharacterMoveComp();
}

void UTentacleMoveComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	for (auto Niagara : NiagaraList)
	{
		if (Niagara.IsValid())
		{
			Niagara->DeactivateImmediate();
			Niagara.Reset();
		}
	}

	AggroTargetActor.Reset();

	AttachComponent.Reset();
	CapsuleComponent.Reset();
	CharacterMovementComponent.Reset();

	NiagaraList.Empty();
	TempNiagaraList.Empty();
	ActorsToIgnore.Empty();
	
	Super::EndPlay(EndPlayReason);	
}

// Called every frame
void UTentacleMoveComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!AttachComponent.IsValid() || !CapsuleComponent.IsValid() || !CharacterMovementComponent.IsValid())
	{
		return;
	}

	float Speed = CharacterMovementComponent->Velocity.Size();
	if (FMath::IsNearlyZero(Speed, 1) && NiagaraList.Num() >= NiagaraLimit)
	{
		return;
	}

	UpdateTickInterval();	
	FHitResult Hit;
	GetTraceHitResult(Hit);
	LaunchNiagaraAndUpdate(Hit);
}

void UTentacleMoveComponent::SetNewAggroTargetActor(AActor* NewAggroTargetActor)
{
	if (!IsValid(NewAggroTargetActor))
	{
		AggroTargetActor.Reset();
		return;
	}
	
	AggroTargetActor = NewAggroTargetActor;
}

void UTentacleMoveComponent::UpdateTickInterval()
{
	float Speed = CharacterMovementComponent->Velocity.Size();
	if (FMath::IsNearlyZero(Speed, 1))
	{
		SetComponentTickInterval(0.f);
	}
	else
	{
		SetComponentTickInterval(1.f / (Speed / RatioOfSpeedToLaunch));	
	}
}

void UTentacleMoveComponent::GetTraceHitResult(FHitResult& HitResult)
{
	FVector StartLoc = CapsuleComponent->GetComponentLocation();
	const FVector& EndLoc = GetLineTraceTarget(StartLoc);
	ActorsToIgnore.Empty();
	
	bool bHit = UKismetSystemLibrary::LineTraceSingle(
		this, StartLoc, EndLoc,
		UEngineTypes::ConvertToTraceType(ECC_Visibility), false,
		ActorsToIgnore, EDrawDebugTrace::None, HitResult, true);
	if (!bHit)
	{
		// UE_LOG(LogTemp, Log, TEXT("UTentacleMoveComponent::TickComponent hit failed, use EndLoc %s"), *EndLoc.ToString());
		HitResult.TraceEnd = EndLoc;
	}
}

void UTentacleMoveComponent::LaunchNiagaraAndUpdate(const FHitResult& Hit)
{
	// 剔除无效的
	TempNiagaraList.Reset();
	for (auto Niagara : NiagaraList)
	{
		if (Niagara.IsValid() && Niagara->IsActive())
		{
			TempNiagaraList.PushLast(Niagara);
		}
	}
	
	NiagaraList.Reset();
	NiagaraList = MoveTemp(TempNiagaraList);
	
	// 淘汰最旧的特效
	if (NiagaraList.Num() >= NiagaraLimit)
	{
		TWeakObjectPtr<UNiagaraComponent>& NiagaraComponent = NiagaraList.First();
		if (NiagaraComponent.IsValid() && NiagaraComponent->IsActive())
		{
			NiagaraComponent->DeactivateImmediate();	
		}
		NiagaraComponent.Reset();
		NiagaraList.PopFirst();
	}
	
	UNiagaraComponent* NewNiagara = UNiagaraFunctionLibrary::SpawnSystemAttached(
		NiagaraAsset, AttachComponent.Get(),
		PN_ATTACH_BONE, FVector(0, 0, -20), FRotator::ZeroRotator, EAttachLocation::KeepRelativeOffset,
		true);
	if (NewNiagara)
	{
		float RandSize = FMath::RandRange(SizeRange.X, SizeRange.Y);
		NewNiagara->SetVariableFloat(PN_SIZE, RandSize);
		NewNiagara->SetVariableVec3(PN_START_POINT, Hit.TraceStart);
		NewNiagara->SetVariableVec3(PN_END_POINT, Hit.TraceEnd);
		NewNiagara->SetVariableVec3(PN_IMPACT_NORMAL, Hit.ImpactNormal);
		NiagaraList.PushLast(NewNiagara);
	}
}

FVector UTentacleMoveComponent::GetLineTraceTarget(const FVector& StartLoc) const
{
	int32 RandFanAngle = 0;
	float Speed = CharacterMovementComponent->Velocity.Size();
	if(FMath::IsNearlyZero(Speed, 1))
	{
		RandFanAngle = FMath::RandRange(0, 360);
	}
	else
	{
		// 正负范围内随机扇形角度
		RandFanAngle = FMath::RandRange(-1 * FanAngle, FanAngle);
	}
	
	// 一半到整个半径的范围内随机扇形半径
	float RandFanRadius = FMath::Sqrt(FMath::RandRange(FMath::Pow(FanRadiusRange.X, 2), FMath::Pow(FanRadiusRange.Y, 2)));

	FRotator TargetRotator;
	FRotator CapsuleRotator = CapsuleComponent->GetComponentRotation();
	if (AggroTargetActor.IsValid())
	{
		FRotator LookAtRotator = UKismetMathLibrary::FindLookAtRotation(StartLoc, AggroTargetActor->GetActorLocation());
		FQuat MiddleQuat = FQuat::Slerp(CapsuleRotator.Quaternion(), LookAtRotator.Quaternion(), 0.5);
		TargetRotator = MiddleQuat.Rotator();
	}
	else
	{
		TargetRotator = CapsuleRotator;
	}
	
	TargetRotator = FRotator(TargetRotator.Pitch, TargetRotator.Yaw + RandFanAngle, TargetRotator.Roll);
	FVector Delta = TargetRotator.Quaternion().RotateVector(FVector(RandFanRadius, 0, 0));
	
	FVector EndLoc = StartLoc + Delta;
	return FVector(EndLoc.X, EndLoc.Y, EndLoc.Z - CapsuleComponent->GetUnscaledCapsuleHalfHeight());
}

// #pragma optimize("", on)
