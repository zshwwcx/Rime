﻿#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParticleColorScaleLinearSample.h"

#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"
#include "3C/Effect/KGEffectManager.h"

bool FKGNiagaraUpdateTaskUpdateParticleColorScaleLinearSample::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}

	if (FMath::IsNearlyZero(Duration))
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParticleColorScaleLinearSample: duration is zero, %s"), *InTaskTarget.GetDebugInfo());
		return false;
	}
	
	AccumulatedTime += DeltaTime;

	if (!StartVal.IsSet())
	{
		StartVal = NiagaraComponent->GetParticleColorScale();
	}

	const float StartParticleColorScale = StartVal.GetValue();
	float ParticleColorScale = StartParticleColorScale + (EndVal - StartParticleColorScale) * (AccumulatedTime / Duration);
	if (StartParticleColorScale > EndVal)
	{
		ParticleColorScale = FMath::Clamp(ParticleColorScale, EndVal, StartParticleColorScale);
	}
	else
	{
		ParticleColorScale = FMath::Clamp(ParticleColorScale, StartParticleColorScale, EndVal);
	}
	
	if (InTaskTarget.NiagaraUpdateContextPtr)
	{
		ParticleColorScale *= InTaskTarget.NiagaraUpdateContextPtr->GetBaseTransparencyScaleFactor();
	}
	else if (EffectManager.IsValid())
	{
		ParticleColorScale *= EffectManager->GetEnvTransparencyScaleFactor();
	}
	
	NiagaraComponent->SetParticleColorScale(ParticleColorScale);
		
	if (AccumulatedTime >= Duration && !bFinished)
	{
		bFinished = true;
	}
	return true;
}
