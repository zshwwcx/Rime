﻿#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParamByLinearSample.h"

#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"

bool FKGNiagaraUpdateTaskUpdateParamByLinearSample::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}
	
	if (bFinished)
	{
		return false;
	}
	
	float AccumulatedTimeUsed = AccumulatedTime;
	AccumulatedTime += DeltaTime;
	if (bUseNiagaraAccumulatedTime && InTaskTarget.NiagaraUpdateContextPtr)
	{
		AccumulatedTimeUsed = InTaskTarget.NiagaraUpdateContextPtr->AccumulatedTime;
	}
		
	float AccumulatePercentage;
	if (!FMath::IsNearlyZero(Duration, UE_KINDA_SMALL_NUMBER))
	{
		AccumulatePercentage = FMath::Clamp(AccumulatedTimeUsed / Duration, 0.0, 1.0);
	}
	else
	{
		AccumulatePercentage = 1.0f;
	}
	
	if (ValueType == EFKGNiagaraParamLinearSampleValueType::Scalar)
	{
		const float ParamVal = StartVal.GetSubtype<float>() + (EndVal.GetSubtype<float>() - StartVal.GetSubtype<float>()) * AccumulatePercentage;
		CurVal.SetSubtype<float>(ParamVal);
		UE_LOG(LogEM, Verbose, TEXT("FKGNiagaraUpdateTaskUpdateParamByLinearSample::OnUpdate, %s, %s, %f"), *InTaskTarget.GetDebugInfo(), *ParamName.ToString(), ParamVal);
		NiagaraComponent->SetFloatParameter(ParamName, ParamVal);
	}
	else if (ValueType == EFKGNiagaraParamLinearSampleValueType::Vector)
	{
		const FVector ParamVal = StartVal.GetSubtype<FVector>() + (EndVal.GetSubtype<FVector>() - StartVal.GetSubtype<FVector>()) * AccumulatePercentage;
		CurVal.SetSubtype<FVector>(ParamVal);
		UE_LOG(LogEM, Verbose, TEXT("FKGNiagaraUpdateTaskUpdateParamByLinearSample::OnUpdate, %s, %s, %s"), *InTaskTarget.GetDebugInfo(), *ParamName.ToString(), *ParamVal.ToString());
		NiagaraComponent->SetVectorParameter(ParamName, ParamVal);
	}
		
	if (AccumulatedTimeUsed >= Duration && !bFinished)
	{
		bFinished = true;
	}
	return true;
}
