#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskConstantNiagaraParams.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"
#include "NiagaraFunctionLibrary.h"
#include "Components/MeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "Engine/World.h"

bool FKGNiagaraUpdateTaskConstantNiagaraParams::OnTaskInit(const FKGNiagaraUpdateTaskTarget& TaskTarget)
{
	auto NiagaraComponent = TaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::Init, NiagaraComponent is null"));
		return false;
	}

	for (const auto& Kvp : UserVals_Float)
	{
		NiagaraComponent->SetFloatParameter(Kvp.Key, Kvp.Value);
	}

	for (const auto& Kvp : UserVals_Vec3)
	{
		NiagaraComponent->SetVectorParameter(Kvp.Key, Kvp.Value);
	}

	for (const auto& Kvp : UserVals_Vec2)
	{
		NiagaraComponent->SetVariableVec2(Kvp.Key, Kvp.Value);
	}

	for (const auto& Kvp : UserVals_LinearColor)
	{
		NiagaraComponent->SetVariableLinearColor(Kvp.Key, Kvp.Value);
	}

	for (const auto& Kvp : UserVals_Textures)
	{
		if (Kvp.Value.LoadedTexture.IsValid())
		{
			NiagaraComponent->SetVariableTexture(Kvp.Key, Kvp.Value.LoadedTexture.Get());
		}
	}
	
	if (ComponentTags.Num() > 0)
	{
		NiagaraComponent->ComponentTags = ComponentTags;
	}
	
	if (bForceRenderCustomDepth.IsSet())
	{
		NiagaraComponent->SetRenderCustomDepth(bForceRenderCustomDepth.GetValue());
		NiagaraComponent->SetCustomDepthStencilValue(ForceCustomDepthStencilValue);
	}
	else if (bEnableCustomDepth)
	{
		NiagaraComponent->SetRenderCustomDepth(bEnableCustomDepth);
		NiagaraComponent->SetCustomDepthStencilValue(CustomDepthStencilValue);
	}

	if (bRenderInMainPass.IsSet())
	{
		NiagaraComponent->SetRenderInMainPass(bRenderInMainPass.GetValue());	
	}

	if (TranslucencySortPriority != 0)
	{
		NiagaraComponent->SetTranslucentSortPriority(TranslucencySortPriority);
	}

	if (TranslucencySortDistanceOffset != 0)
	{
		NiagaraComponent->SetTranslucencySortDistanceOffset(TranslucencySortDistanceOffset);
	}

	return true;
}

bool FKGNiagaraUpdateTaskConstantNiagaraParams::OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& TaskTarget)
{
	if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get()))
	{
		for (const auto& Kvp : UserVals_Textures)
		{
			if (Kvp.Value.LoadID != 0)
			{
				AssetManager->CancelAsyncLoadByLoadID(Kvp.Value.LoadID);
			}
		}
	}
	else
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::OnDestroy, no asset manager"));
	}
	
	return FKGNiagaraUpdateTaskBase::OnTaskDestroy(TaskTarget);
}

void FKGNiagaraUpdateTaskConstantNiagaraParams::SetCustomDepthInfo(bool bInEnableCustomDepth, int32 InCustomDepthStencilValue)
{
	bEnableCustomDepth = bInEnableCustomDepth;
	CustomDepthStencilValue = InCustomDepthStencilValue;
	if (!bForceRenderCustomDepth.IsSet())
	{
		auto* OwnerContextPtr = GetNiagaraUpdateContext();
		if (!OwnerContextPtr)
		{
			UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::SetCustomDepthInfo, OwnerContextPtr is null"));
			return;
		}
		
		if (auto NiagaraComponent = OwnerContextPtr->NiagaraComponent)
		{
			NiagaraComponent->SetRenderCustomDepth(bEnableCustomDepth);
			NiagaraComponent->SetCustomDepthStencilValue(CustomDepthStencilValue);
		}
	}
}

void FKGNiagaraUpdateTaskConstantNiagaraParams::SetForceCustomDepthInfo(bool bInEnableCustomDepth, int32 InCustomDepthStencilValue)
{
	bForceRenderCustomDepth = bInEnableCustomDepth;
	ForceCustomDepthStencilValue = InCustomDepthStencilValue;

	auto* OwnerContextPtr = GetNiagaraUpdateContext();
	if (!OwnerContextPtr)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::SetForceCustomDepthInfo, OwnerContextPtr is null"));
		return;
	}
	
	if (auto NiagaraComponent = OwnerContextPtr->NiagaraComponent)
	{
		NiagaraComponent->SetRenderCustomDepth(bInEnableCustomDepth);
		NiagaraComponent->SetCustomDepthStencilValue(InCustomDepthStencilValue);
	}	
}

void FKGNiagaraUpdateTaskConstantNiagaraParams::RevertForceCustomDepthInfo()
{
	if (!bForceRenderCustomDepth.IsSet())
	{
		return;
	}
	
	bForceRenderCustomDepth.Reset();
	auto* OwnerContextPtr = GetNiagaraUpdateContext();
	if (!OwnerContextPtr)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::RevertForceCustomDepthInfo, OwnerContextPtr is null"));
		return;
	}
	
	if (auto NiagaraComponent = OwnerContextPtr->NiagaraComponent)
	{
		NiagaraComponent->SetRenderCustomDepth(bEnableCustomDepth);
		NiagaraComponent->SetCustomDepthStencilValue(CustomDepthStencilValue);
	}	
}

void FKGNiagaraUpdateTaskConstantNiagaraParams::SetSpiritualVisionColor(bool bInSpiritualVision, const FLinearColor& InSpiritualVisionMeshColor)
{
	bSpiritualVision = bInSpiritualVision;
	SpiritualVisionMeshColor = InSpiritualVisionMeshColor;
}

void FKGNiagaraUpdateTaskConstantNiagaraParams::UpdateSpiritualVisionColorParams(const FName& ParamName, bool bEnableSpiritualVision)
{
	if (!bSpiritualVision)
	{
		return;
	}

	FLinearColor NewMeshColor = FLinearColor::White;
	if (bEnableSpiritualVision)
	{
		NewMeshColor = SpiritualVisionMeshColor;
	}

	auto* OwnerContextPtr = GetNiagaraUpdateContext();
	if (!OwnerContextPtr)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::UpdateSpiritualVisionColorParams, OwnerContextPtr is null"));
		return;
	}
	
	if (OwnerContextPtr->NiagaraComponent)
	{
		OwnerContextPtr->NiagaraComponent->SetVariableLinearColor(ParamName, NewMeshColor);
	}
	else
	{
		UserVals_LinearColor.Add(ParamName, NewMeshColor);
	}
}

void FKGNiagaraUpdateTaskConstantNiagaraParams::SetTextureParam(const FName& ParamName, const FString& TexturePath)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get());
	if (!AssetManager)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::SetTextureParam, no asset manager"));
		return;
	}

	if (UserVals_Textures.Contains(ParamName))
	{
		const auto& TextureInfo = UserVals_Textures[ParamName];
		if (TextureInfo.LoadID != 0)
		{
			AssetManager->CancelAsyncLoadByLoadID(TextureInfo.LoadID);
		}
	}

	FKGNiagaraTextureParams TextureInfo;
	TextureInfo.TexturePath = TexturePath;
	TextureInfo.LoadID = AssetManager->AsyncLoadAsset(
		TexturePath, FAsyncLoadCompleteDelegate::CreateRaw(
		this, &FKGNiagaraUpdateTaskConstantNiagaraParams::InternalOnTextureAssetLoaded, ParamName));
	UserVals_Textures.Add(ParamName, TextureInfo);
}

void FKGNiagaraUpdateTaskConstantNiagaraParams::RemoveTextureParam(const FName& ParamName)
{
	if (UserVals_Textures.Contains(ParamName))
	{
		auto& TextureInfo = UserVals_Textures[ParamName];
		if (TextureInfo.LoadID != 0)
		{
			if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get()))
			{
				AssetManager->CancelAsyncLoadByLoadID(TextureInfo.LoadID);
			}
			else
			{
				UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::RemoveTextureParam, no asset manager"));
			}
		}

		UserVals_Textures.Remove(ParamName);
	}

	auto* OwnerContextPtr = GetNiagaraUpdateContext();
	if (!OwnerContextPtr)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::RemoveTextureParam, OwnerContextPtr is null"));
		return;
	}

	if (OwnerContextPtr->NiagaraComponent)
	{
		OwnerContextPtr->NiagaraComponent->SetVariableTexture(ParamName, nullptr);
	}
}

void FKGNiagaraUpdateTaskConstantNiagaraParams::InternalOnTextureAssetLoaded(int InLoadID, UObject* LoadedAssets, FName ParamName)
{
	auto* OwnerContextPtr = GetNiagaraUpdateContext();
	if (!OwnerContextPtr)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::InternalOnTextureAssetLoaded, OwnerContextPtr is null"));
		return;
	}
	
	if (!UserVals_Textures.Contains(ParamName))
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::InternalOnTextureAssetLoaded, cannot find ParamName %s, %s"),
			*ParamName.ToString(), *OwnerContextPtr->ToString());
		return;
	}

	auto& TextureInfo = UserVals_Textures[ParamName];
	UTexture* Texture = Cast<UTexture>(LoadedAssets);
	if (!Texture)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskConstantNiagaraParams::InternalOnTextureAssetLoaded, invalid texture loaded %s, %s"),
			*TextureInfo.TexturePath, *OwnerContextPtr->ToString());
		return;
	}

	if (OwnerContextPtr->NiagaraComponent)
	{
		OwnerContextPtr->NiagaraComponent->SetVariableTexture(ParamName, Texture);
		UserVals_Textures.Remove(ParamName);
	}
	else
	{
		TextureInfo.LoadID = 0;
		TextureInfo.LoadedTexture = TStrongObjectPtr(Texture);
	}
}
