#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateSplineParams.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Effect/KGEffectManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "3C/Util/KGUtils.h"
#include "NiagaraComponent.h"
#include "NiagaraDataInterfaceSpline.h"
#include "Components/SplineComponent.h"

bool FKGNiagaraUpdateTaskUpdateSplineParams::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get());
	if (!AssetManager)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalSetSplineLinkParamByAssetPath, no asset manager"));
		return false;
	}

	if (SplineBPAssetLoadID != 0)
	{
		AssetManager->CancelAsyncLoadByLoadID(SplineBPAssetLoadID);
	}

	SplineBPAssetLoadID = AssetManager->AsyncLoadAsset(
		SplineBPPath,
		FAsyncLoadCompleteDelegate::CreateRaw(this, &FKGNiagaraUpdateTaskUpdateSplineParams::InternalOnSplineAssetLoaded));

	return true;
}

bool FKGNiagaraUpdateTaskUpdateSplineParams::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}
	
	if (!InTaskTarget.NiagaraUpdateContextPtr)
	{
		return false;
	}
	
	if (!this->CachedSplineComponent.IsValid())
	{
		return false;
	}
	
	const FVector& SourceLocation = NiagaraComponent->GetComponentLocation();
	FVector TargetLocation;
	if (!this->InternalGetSplineTargetLocation(TargetLocation, *InTaskTarget.NiagaraUpdateContextPtr))
	{
		return false;
	}
	
	this->CachedSplineComponent->SetWorldLocation(SourceLocation);
	FVector SourceToTarget = TargetLocation - SourceLocation;
	if (!FMath::IsNearlyZero(SourceToTarget.Size(), UE_KINDA_SMALL_NUMBER))
	{
		this->CachedSplineComponent->SetWorldRotation(FRotator(0, SourceToTarget.GetSafeNormal().ToOrientationRotator().Yaw, 0));	
	}

	this->CachedSplineComponent->SetLocationAtSplinePoint(0, SourceLocation, ESplineCoordinateSpace::World, true);
	this->CachedSplineComponent->SetLocationAtSplinePoint(1, TargetLocation, ESplineCoordinateSpace::World, true);
	
	return true;
}

bool FKGNiagaraUpdateTaskUpdateSplineParams::OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (this->CachedSplineActor.IsValid())
	{
		this->CachedSplineActor->Destroy();
	}

	if (this->SplineBPAssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(this->SplineBPAssetLoadID);
		}
		else
		{
			UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::Destroy, no asset manager found"));
		}
		this->SplineBPAssetLoadID = 0;
	}
	
	return true;
}

void FKGNiagaraUpdateTaskUpdateSplineParams::InternalOnSplineAssetLoaded(int InLoadID, UObject* LoadedAssets)
{
	SplineBPAssetLoadID = 0;

	if (!EffectManager.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalOnSplineAssetLoaded, invalid effect manager"));
		return;
	}

	auto* OwnerContextPtr = GetNiagaraUpdateContext();
	if (!OwnerContextPtr)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalOnSplineAssetLoaded, OwnerContextPtr is null"));
		return;
	}
	
	if (TargetParams.Method == EKGNiagaraUpdateSplineTargetMethod::BindToTargetComponent)
	{
		if (!UpdateTargetComponent(*OwnerContextPtr, TargetParams.TargetComponentId, TargetParams.TargetSocketName))
		{
			return;
		}	
	}
	
	// Setup Spline
	if (this->InternalInitializeSplineComponent(*OwnerContextPtr, LoadedAssets))
	{
		return;
	}
	
	FKGNiagaraUpdateTaskTarget TaskTarget;
	TaskTarget.NiagaraUpdateContextPtr = OwnerContextPtr;
	DoTaskUpdate(0.0f, TaskTarget);
}

bool FKGNiagaraUpdateTaskUpdateSplineParams::UpdateTargetComponent(
	const FKGNiagaraUpdateContext& UpdateContext, KGObjectID TargetComponentId, const FName& TargetSocketName)
{
	USceneComponent* TargetComponent = Cast<USceneComponent>(KGUtils::GetObjectByID(TargetComponentId));
	if (!IsValid(TargetComponent))
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalInitializeTargetComponent, invalid target component, %s"),
			*UpdateContext.ToString());
		return false;
	}

	bIsTargetSocketValid = TargetComponent->DoesSocketExist(TargetSocketName);
	CachedTargetComponent = TargetComponent;
	return true;
}

bool FKGNiagaraUpdateTaskUpdateSplineParams::InternalInitializeSplineComponent(FKGNiagaraUpdateContext& UpdateContext, UObject* LoadedSplineAssets)
{
	if (this->CachedSplineComponent.IsValid())
	{
		return true;
	}
	
	UWorld* World = EffectManager->GetWorld();
	if (!World)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalInitializeSplineComponent, invalid world, %s"), *UpdateContext.ToString());
		return false;
	}

	AActor* SpawnerActor = Cast<AActor>(KGUtils::GetObjectByID(UpdateContext.PlayNiagaraParams.SpawnerID));
	if (!SpawnerActor)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalInitializeSplineComponent, invalid spawner actor, %s"), *UpdateContext.ToString());
		return false;
	}

	UClass* SplineBPClass = Cast<UClass>(LoadedSplineAssets);
	if (SplineBPClass == nullptr)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalInitializeSplineComponent, invalid SplineBPClass %s, %s"),
			*SplineBPPath, *UpdateContext.ToString());
		return false;
	}
	
	this->CachedSplineActor = World->SpawnActor(SplineBPClass, &SpawnerActor->GetActorTransform());
	USplineComponent* SplineComponent = Cast<USplineComponent>(this->CachedSplineActor->GetComponentByClass(USplineComponent::StaticClass()));
	if (!SplineComponent)
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalInitializeSplineComponent, cannot find spline comp in spline actor"));
		return false;
	}

	int32 SplinePointNum = SplineComponent->GetNumberOfSplinePoints();
	if (SplinePointNum != 2)
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalInitializeSplineComponent, invalid spline point num"));
		return false;
	}
	
	if (!UpdateContext.AttachComponent.IsValid())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalInitializeSplineComponent, cannot use spline link without attached comp"));
		return false;
	}

	auto NiagaraComponent = UpdateContext.NiagaraComponent;
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalInitializeSplineComponent, niagara component not created"));
		return false;
	}

	const FNiagaraParameterStore& OverrideParameters = NiagaraComponent->GetOverrideParameters();
	const FString& ParamName = SplineUserVarName;
	FNiagaraVariable Variable(FNiagaraTypeDefinition(UNiagaraDataInterfaceSpline::StaticClass()), *ParamName);

	int32 Index = OverrideParameters.IndexOf(Variable);
	if (Index == INDEX_NONE)
	{
		UE_LOG(LogEM, Warning,
			TEXT("Could not find index of variable \"%s\" in the OverrideParameters map of NiagaraSystem \"%s\"."),
			*ParamName, *NiagaraComponent->GetOwner()->GetActorNameOrLabel());
		return false;
	}

	UNiagaraDataInterfaceSpline* SplineInterface = Cast<UNiagaraDataInterfaceSpline>(OverrideParameters.GetDataInterface(Index));
	if (!SplineInterface)
	{
		UE_LOG(LogEM, Warning,
			TEXT("Did not find a matching Water Data Interface variable named \"%s\" in the User variables of NiagaraSystem \"%s\" ."),
			*ParamName, *NiagaraComponent->GetOwner()->GetActorNameOrLabel());
		return false;
	}

	SplineInterface->SoftSourceActor = this->CachedSplineActor.Get();
	this->CachedSplineComponent = SplineComponent;

	return true;
}

bool FKGNiagaraUpdateTaskUpdateSplineParams::InternalGetSplineTargetLocation(FVector& OutTargetPoint, FKGNiagaraUpdateContext& UpdateContext)
{
	if (this->TargetParams.Method == EKGNiagaraUpdateSplineTargetMethod::BindToLocation)
	{
		AActor* Spawner = KGUtils::GetActorByID(UpdateContext.PlayNiagaraParams.SpawnerID);
		if (!Spawner)
		{
			UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalGetSplineTargetLocation, cannot find spawner with ID %lld"),
				UpdateContext.PlayNiagaraParams.SpawnerID);
			return false;
		}

		FTransform LocalToWorldTransform = FTransform::Identity;
		LocalToWorldTransform.SetLocation(Spawner->GetActorLocation());
		LocalToWorldTransform.SetRotation(FRotator(0.0f, TargetParams.RelativeYaw, 0.0f).Quaternion());
		OutTargetPoint = LocalToWorldTransform.TransformPosition(OutTargetPoint);
		return true;
	}
	
	if (this->TargetParams.Method == EKGNiagaraUpdateSplineTargetMethod::BindToLocationOnGround)
	{
		if (UpdateContext.NiagaraComponent == nullptr)
			return false;

		AActor* Spawner = KGUtils::GetActorByID(UpdateContext.PlayNiagaraParams.SpawnerID);
		if (!Spawner)
		{
			UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskUpdateSplineParams::InternalGetSplineTargetLocation, cannot find spawner with ID %lld"),
				UpdateContext.PlayNiagaraParams.SpawnerID);
			return false;
		}

		FTransform LocalToWorldTransform = FTransform::Identity;
		LocalToWorldTransform.SetLocation(Spawner->GetActorLocation());
		LocalToWorldTransform.SetRotation(FRotator(0.0f, TargetParams.RelativeYaw, 0.0f).Quaternion());
		const auto& WorldPosBeforeStickGround = LocalToWorldTransform.TransformPosition(TargetParams.TargetLocation);
		FVector PointOnGround;
		if (!this->InternalGetPointOnGround(UpdateContext, WorldPosBeforeStickGround, PointOnGround))
			return false;
		
		OutTargetPoint = PointOnGround;
		return true;
	}
	
	if (this->TargetParams.Method == EKGNiagaraUpdateSplineTargetMethod::BindToTargetComponent)
	{
		if (!this->CachedTargetComponent.IsValid())
			return false;

		if (bIsTargetSocketValid)
		{
			OutTargetPoint = CachedTargetComponent->GetSocketLocation(TargetParams.TargetSocketName);
		}
		else
		{
			OutTargetPoint = CachedTargetComponent->GetComponentLocation();
		}
		return true;
	}
	
	return false;
}

bool FKGNiagaraUpdateTaskUpdateSplineParams::InternalGetPointOnGround(FKGNiagaraUpdateContext& UpdateContext, const FVector& InWorldPoint, FVector& OutPointOnGround)
{
	if (!EffectManager.IsValid())
	{
		return false;
	}
	
	UWorld* World = EffectManager->GetWorld();
	if (World == nullptr)
	{
		return false;
	}
	
	FVector Start = InWorldPoint + FVector(0.f, 0.f, 100.f);
	FVector End = InWorldPoint + FVector(0.f, 0.f, -10000.f);
	
	FHitResult HitResult;
	FCollisionQueryParams Params;
	Params.bTraceComplex = true;
	if (UpdateContext.NiagaraComponent != nullptr)
		Params.AddIgnoredActor(UpdateContext.NiagaraComponent->GetOwner());
	if (this->CachedSplineActor.IsValid())
		Params.AddIgnoredActor(this->CachedSplineActor.Get());
	
	bool bHit = World->LineTraceSingleByChannel(HitResult, Start, End, ECC_Visibility, Params);
	if (!bHit)
	{
		OutPointOnGround.Set(InWorldPoint.X, InWorldPoint.Y, 0);
		return false;
	}
    
	OutPointOnGround = HitResult.ImpactPoint;

	return true;
}

