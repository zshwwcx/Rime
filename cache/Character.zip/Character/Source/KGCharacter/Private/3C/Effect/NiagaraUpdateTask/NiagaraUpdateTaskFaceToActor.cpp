﻿#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFaceToActor.h"

#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"
#include "GameFramework/Actor.h"

bool FKGNiagaraUpdateTaskFaceToActor::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (InTaskTarget.NiagaraUpdateContextPtr)
	{
		const auto& PlayNiagaraParams = InTaskTarget.NiagaraUpdateContextPtr->PlayNiagaraParams;
		if (PlayNiagaraParams.NeedAttach())
		{
			const auto& AttachedSpawnInfo = PlayNiagaraParams.GetAttachedSpawnInfoChecked();
			CachedInitRelativeRotation = AttachedSpawnInfo.RelativeTrans.Rotator();
			CacheInitRelativeRotationQuat = AttachedSpawnInfo.RelativeTrans.GetRotation();	
		}
		else
		{
			const auto& UnattachedSpawnInfo = PlayNiagaraParams.GetUnattachedSpawnInfoChecked();
			CachedInitRelativeRotation = UnattachedSpawnInfo.WorldOrRelativeTrans.Rotator();
			CacheInitRelativeRotationQuat = UnattachedSpawnInfo.WorldOrRelativeTrans.GetRotation();	
		}
	}

	return true;
}

bool FKGNiagaraUpdateTaskFaceToActor::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}

	if (!FacingTargetActor.IsValid())
	{
		return false;
	}

	const FVector& SourceLocation = NiagaraComponent->GetComponentLocation();
	const FVector& TargetLocation = FacingTargetActor->GetActorLocation();
	if (FMath::IsNearlyEqual(SourceLocation.X, TargetLocation.X, KINDA_SMALL_NUMBER) &&
		FMath::IsNearlyEqual(SourceLocation.Y, TargetLocation.Y, KINDA_SMALL_NUMBER))
	{
		return false;
	}

	FRotator NewRotation = NiagaraComponent->GetComponentRotation();
	if (RotationType == EKGNiagaraFaceToActorRotationType::OnlyRotateYaw)
	{
		const float TargetYaw = (TargetLocation - SourceLocation).GetSafeNormal().Rotation().Yaw;
		NewRotation.Yaw = TargetYaw + CachedInitRelativeRotation.Yaw;
	}
	else
	{
		const auto& TargetQuat = (TargetLocation - SourceLocation).GetSafeNormal().ToOrientationQuat();
		NewRotation = (TargetQuat * CacheInitRelativeRotationQuat).Rotator();
	}

	NiagaraComponent->SetWorldRotation(NewRotation);
	return true;
}
