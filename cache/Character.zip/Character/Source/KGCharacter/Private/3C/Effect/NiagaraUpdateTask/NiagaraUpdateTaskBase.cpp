#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskBase.h"

#include "NiagaraComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "3C/Util/KGUtils.h"

static uint32 GenerateTaskID()
{
	static uint32 TaskID = 0;
	TaskID++;
	if (TaskID >= 0x7fffffff)
	{
		TaskID = 1;
	}
	return TaskID;
}

UNiagaraComponent* FKGNiagaraUpdateTaskTarget::GetNiagaraComponent() const
{
	if (NiagaraUpdateContextPtr != nullptr)
	{
		return NiagaraUpdateContextPtr->NiagaraComponent;
	}
	
	return NiagaraComponent.Get();
}

AActor* FKGNiagaraUpdateTaskTarget::GetSpawnerActor() const
{
	if (NiagaraUpdateContextPtr != nullptr)
	{
		return KGUtils::GetActorByID(NiagaraUpdateContextPtr->PlayNiagaraParams.SpawnerID);
	}
	
	if (NiagaraComponent.IsValid())
	{
		// 对于场景常见的niagara component, owner不是world settings
		return NiagaraComponent->GetOwner();
	}
	
	return nullptr;
}

FString FKGNiagaraUpdateTaskTarget::GetDebugInfo() const
{
	if (NiagaraUpdateContextPtr != nullptr)
	{
		return NiagaraUpdateContextPtr->ToString();
	}
	
	if (NiagaraComponent.IsValid())
	{
		return FString::Printf(TEXT("NiagaraComp: %s, Asset: %s, Owner: %s"), 
			*NiagaraComponent->GetName(),
			NiagaraComponent->GetAsset() ? *NiagaraComponent->GetAsset()->GetPathName() : TEXT("nullptr"),
			NiagaraComponent->GetOwner() ? *NiagaraComponent->GetOwner()->GetName() : TEXT("nullptr"));
	}

	return TEXT("InvalidUpdateTarget");
}

FKGNiagaraUpdateTaskBase::FKGNiagaraUpdateTaskBase()
{
	TaskID = GenerateTaskID();
}

void FKGNiagaraUpdateTaskBase::SetNiagaraUpdateContextInfo(FKGNiagaraUpdateContext* InOwnerContextPtr)
{
	check(InOwnerContextPtr);
	NiagaraEffectID = InOwnerContextPtr->NiagaraEffectId;
	EffectManager = InOwnerContextPtr->EffectManager;
	UE_CLOG(NiagaraEffectID == 0 || !EffectManager.IsValid(), LogEM, Error,
		TEXT("FKGNiagaraUpdateTaskBase::SetNiagaraUpdateContextInfo called with invalid NiagaraEffectID %d or EffectManager %d "),
		NiagaraEffectID, EffectManager.IsValid());
}

void FKGNiagaraUpdateTaskBase::SetNativeNiagaraComponentInfo(UNiagaraComponent* InNiagaraComponent, UKGEffectManager* InEffectManager)
{
	if (!IsValid(InNiagaraComponent) || !IsValid(InEffectManager))
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskBase::SetNativeNiagaraComponentInfo, invalid niagara info or effect manager"));
		return;
	}
	
	NativeNiagaraComponent = InNiagaraComponent;
	EffectManager = InEffectManager;
}

FKGNiagaraUpdateContext* FKGNiagaraUpdateTaskBase::GetNiagaraUpdateContext() const
{
	return EffectManager.IsValid() ? EffectManager->GetNiagaraUpdateContextPtr(NiagaraEffectID) : nullptr;
}

UNiagaraComponent* FKGNiagaraUpdateTaskBase::GetNativeNiagaraComponent() const
{
	return NativeNiagaraComponent.Get();
}

bool FKGNiagaraUpdateTaskBase::DoTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (TaskState != EKGNiagaraUpdateTaskState::UnInitialized)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskBase::Init called when TaskState is not UnInitialized! TaskID: %d, TaskType: %d"),
			TaskID, GetTaskType());
		return false;
	}

	if (!OnTaskInit(InTaskTarget))
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskBase::OnInit failed! TaskID: %d, TaskType: %d"),
			TaskID, GetTaskType());
		return false;
	}
	
	TaskState = EKGNiagaraUpdateTaskState::Initialized;
	return true;
}

bool FKGNiagaraUpdateTaskBase::DoTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (TaskState == EKGNiagaraUpdateTaskState::Initialized)
	{
		return OnTaskUpdate(DeltaTime, InTaskTarget);
	}

	return false;
}

bool FKGNiagaraUpdateTaskBase::DoTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (TaskState == EKGNiagaraUpdateTaskState::Destroyed)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskBase::Destroy called when TaskState is already Destroyed! TaskID: %d, TaskType: %d"),
			TaskID, GetTaskType());
		return false;
	}

	if (!OnTaskDestroy(InTaskTarget))
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskBase::OnDestroy failed! TaskID: %d, TaskType: %d"),
			TaskID, GetTaskType());
		return false;
	}

	TaskState = EKGNiagaraUpdateTaskState::Destroyed;
	return true;
}
