#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParamByCurve.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Effect/KGEffectManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"

bool FKGNiagaraUpdateTaskUpdateParamByCurve::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get());
	if (!AssetManager)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParamByCurve::InternalAddFloatCurveParamsByCurvePath, no asset manager"));
		return false;
	}

	CurveAssetLoadId = AssetManager->AsyncLoadAsset(
		CurveParams.CurvePath, FAsyncLoadCompleteDelegate::CreateRaw(this, &FKGNiagaraUpdateTaskUpdateParamByCurve::InternalOnFloatCurveAssetLoaded));
	return true;
}

bool FKGNiagaraUpdateTaskUpdateParamByCurve::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}

	if (!CurveFloatEvalHelper.IsValid())
	{
		return false;
	}

	float AccumulatedTimeUsed = AccumulatedTime;
	AccumulatedTime += DeltaTime;
	if (bUseNiagaraAccumulatedTime && InTaskTarget.NiagaraUpdateContextPtr)
	{
		AccumulatedTimeUsed = InTaskTarget.NiagaraUpdateContextPtr->AccumulatedTime;
	}
		
	float CurveVal = 0.0f;
	if (!CurveFloatEvalHelper.GetValue(AccumulatedTimeUsed, CurveVal))
	{
		UE_LOG(LogEM, Error, TEXT("Eval curve float failed"));
		return false;
	}

	NiagaraComponent->SetFloatParameter(ParamName, CurveVal);
		
	if (CurveFloatEvalHelper.DoesTimeReachEnd(AccumulatedTimeUsed) && !bFinished)
	{
		bFinished = true;
	}
	return true;
}

bool FKGNiagaraUpdateTaskUpdateParamByCurve::OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (CurveAssetLoadId != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(CurveAssetLoadId);
		}
		else
		{
			UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParamByCurve::Destroy, no asset manager found"));
		}
		CurveAssetLoadId = 0;
	}
	
	return true;
}

void FKGNiagaraUpdateTaskUpdateParamByCurve::InternalOnFloatCurveAssetLoaded(int InLoadID, UObject* LoadedAssets)
{
	CurveAssetLoadId = 0;

	auto* OwnerContextPtr = GetNiagaraUpdateContext();
	UCurveFloat* CurveFloat = Cast<UCurveFloat>(LoadedAssets);
	if (!CurveFloat)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParamByCurve::InternalOnFloatCurveAssetLoaded, invalid CurveAsset %s, %s"),
			*CurveParams.CurvePath, OwnerContextPtr ? *OwnerContextPtr->ToString() : TEXT("nullptr"));
		return;
	}
	
	CurveFloatEvalHelper.InitEvalParams(CurveParams.bNeedRemap, CurveParams.RemapTime, CurveParams.bLoop, CurveFloat);

	if (bDestroyNiagaraOnCurveEvalFinished && EffectManager.IsValid() && OwnerContextPtr)
	{
		float MinTime = 0.0f;
		float MaxTime = 0.0f;
		CurveFloat->GetTimeRange(MinTime, MaxTime);
		const auto Duration = MaxTime - MinTime;
		if (Duration < UE_KINDA_SMALL_NUMBER)
		{
			UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParamByCurve::OnBlendOutCurveLoaded, invalid curve duration %f, %s"), Duration, *OwnerContextPtr->ToString());
			return;
		}

		UE_LOG(LogEM, Log, TEXT("FKGNiagaraUpdateTaskUpdateParamByCurve::OnBlendOutCurveLoaded, set niagara %s deactivate in %f seconds"),
			*OwnerContextPtr->ToString(), Duration);
		EffectManager->SetNiagaraLifeTimeTimer(OwnerContextPtr->NiagaraEffectId, EKGNiagaraTimeoutState::Deactivate, Duration);
	}
}
