#include "3C/Effect/KGEffectManager.h"

#include "3C/Core/C7ActorInterface.h"
#include "GameFramework/Character.h"

#include "NiagaraComponent.h"

#include "Engine.h"
#include "Manager/KGCppAssetManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "3C/Core/KGUEActorManager.h"
#include "lua.hpp"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraWorldManager.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParamByCurve.h"
#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParamByLinearSample.h"
#include "3C/Util/KGActorUtil.h"
#include "Misc/ObjCrashCollector.h"
#include "Engine/World.h"
#include "Managers/KGDataCacheManager.h"
#include "3C/Util/KGUtils.h"
#include "Kismet/KismetMathLibrary.h"

DEFINE_LOG_CATEGORY(LogEM);

// niagara pre-allocated size
#define KG_NIAGARA_UPDATE_CONTEXT_INIT_SIZE (64)

#define KG_INVALID_NIAGARA_SYSTEM_ID (0)
#define KG_NIAGARA_MAX_COMMON_EFFECT_TAGS (64)
#define KG_NIAGARA_MIN_DELAY_DESTROY_TIME (0.001f)

#define KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(FuncName, EffectID, ...) \
	if (FKGNiagaraUpdateContext* NiagaraUpdateContext = NiagaraUpdateContexts.Find(EffectID)) \
	{ \
		NiagaraUpdateContext->FuncName(__VA_ARGS__); \
		UpdateTickableNiagaraIds(*NiagaraUpdateContext); \
	} \
	else \
	{ \
		UE_LOG(LogEM, Warning, TEXT("%s, EffectID %d not found in NiagaraUpdateContexts!"), *FString(__FUNCTION__), EffectID); \
	}

bool GEnableNiagaraDrawDebug = false;
static FAutoConsoleVariableRef CVarEnableNiagaraDrawDebug(
	TEXT("gp.EnableNiagaraDrawDebug"),
	GEnableNiagaraDrawDebug,
	TEXT("EnableNiagaraDrawDebug."),
	ECVF_Default
);

bool GEnableNativeNiagaraDrawDebug = false;
static FAutoConsoleVariableRef CVarEnableNativeNiagaraDrawDebug(
	TEXT("gp.EnableNativeNiagaraDrawDebug"),
	GEnableNativeNiagaraDrawDebug,
	TEXT("EnableNativeNiagaraDrawDebug."),
	ECVF_Default
);

bool GKGForbidCreateNiagara = false;
static FAutoConsoleVariableRef CVarForbidCreateNiagara(
	TEXT("gp.ForbidCreateNiagara"),
	GKGForbidCreateNiagara,
	TEXT("ForbidCreateNiagara."),
	ECVF_Default
);

static bool GbEnableNiagaraComponentPool = true;
static FAutoConsoleVariableRef CVarEnableNiagaraComponentPool(
	TEXT("gp.EnableNiagaraComponentPool"),
	GbEnableNiagaraComponentPool,
	TEXT("EnableNiagaraComponentPool."),
	ECVF_Default
);

#if WITH_EDITOR
// 如果开启了调试模式, 一方面会禁用NCPool, 此外会通过定制的特效创建接口创建非attached niagara component
// 仅在编辑器模式下生效
static bool GbShowNiagaraInWorldOutliner = false;
static FAutoConsoleVariableRef CVarShowNiagaraInWorldOutliner(
	TEXT("gp.ShowNiagaraInWorldOutliner"),
	GbShowNiagaraInWorldOutliner,
	TEXT("ShowNiagaraInWorldOutliner."),
	ECVF_Default
);
#endif

static bool ShouldUseNiagaraComponentPool()
{
	return GbEnableNiagaraComponentPool
#if WITH_EDITOR
	&& !GbShowNiagaraInWorldOutliner
#endif
	;
}

#pragma region Important

void UKGEffectManager::NativeInit()
{
	PendingActiveNiagaraIds.Reserve(KG_NIAGARA_UPDATE_CONTEXT_INIT_SIZE);
	TickableNiagaraIds.Reserve(KG_NIAGARA_UPDATE_CONTEXT_INIT_SIZE);
	NiagaraUpdateContexts.Reserve(KG_NIAGARA_UPDATE_CONTEXT_INIT_SIZE);
	NiagaraComponentToNiagaraId.Reserve(KG_NIAGARA_UPDATE_CONTEXT_INIT_SIZE);
	NativeEnvNiagaraComponents.Reserve(KG_NIAGARA_UPDATE_CONTEXT_INIT_SIZE * 2);

	NiagaraScoreManager = MakeShared<FKGNiagaraScoreManager>();
	NiagaraScoreManager->Init(this);

	UNiagaraComponent::OnNiagaraSystemInstanceControllerPreCreated.AddUObject(this, &UKGEffectManager::OnNiagaraSystemInstancePreCreated);
	FNiagaraSystemInstance::OnNiagaraSystemInstanceDeallocated.AddUObject(this, &UKGEffectManager::OnNiagaraSystemInstanceDeallocated);
	
	using namespace NS_SLUA;
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_CreateNiagaraSystemAtLocation", &UKGEffectManager::KAPI_EffectManager_CreateNiagaraSystemAtLocation);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_CreateNiagaraSystemAttached", &UKGEffectManager::KAPI_EffectManager_CreateNiagaraSystemAttached);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_CreateNiagaraSystemByEffectDataID", &UKGEffectManager::KAPI_EffectManager_CreateNiagaraSystemByEffectDataID);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_CreateWeaponDissolveNiagaraEffect", &UKGEffectManager::KAPI_EffectManager_CreateWeaponDissolveNiagaraEffect);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_CreateSkillNiagaraSystemNew", &UKGEffectManager::KAPI_EffectManager_CreateSkillNiagaraSystemNew);
	
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_DeactivateNiagaraSystem", &UKGEffectManager::KAPI_EffectManager_DeactivateNiagaraSystem);
	REG_MANAGER_FUNC(UKGEffectManager, "DestroyNiagaraSystem", &UKGEffectManager::DestroyNiagaraSystem);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_DeactivateNiagaraSystemsByEffectTag", &UKGEffectManager::KAPI_EffectManager_DeactivateNiagaraSystemsByEffectTag);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_DestroyNiagaraSystemsByEffectTag", &UKGEffectManager::KAPI_EffectManager_DestroyNiagaraSystemsByEffectTag);
	REG_MANAGER_FUNC(UKGEffectManager, "DestroyNiagarasBySpawnerId", &UKGEffectManager::DestroyNiagarasBySpawnerId);
	REG_MANAGER_FUNC(UKGEffectManager, "DestroyAllNiagaras", &UKGEffectManager::DestroyAllNiagaras);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_DetachNiagaraEffect", &UKGEffectManager::KAPI_EffectManager_DetachNiagaraEffect);
	
	REG_MANAGER_FUNC(UKGEffectManager, "GenerateEffectId", &UKGEffectManager::GenerateEffectId);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraTickTimeLimit", &UKGEffectManager::SetNiagaraTickTimeLimit);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetWaitAttachComponentTimeoutSeconds", &UKGEffectManager::KAPI_EffectManager_SetWaitAttachComponentTimeoutSeconds);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetCheckGroundInfo", &UKGEffectManager::KAPI_EffectManager_SetCheckGroundInfo);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetNiagaraQualityInfo", &UKGEffectManager::KAPI_EffectManager_SetNiagaraQualityInfo);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_DisableQualityLevelOffsetAndTransparencyScale", &UKGEffectManager::KAPI_EffectManager_DisableQualityLevelOffsetAndTransparencyScale);
	REG_MANAGER_FUNC(UKGEffectManager, "AddSurfaceCdInfo", &UKGEffectManager::AddSurfaceCdInfo);
	REG_MANAGER_FUNC(UKGEffectManager, "SetInWaterEffectOffset", &UKGEffectManager::SetInWaterEffectOffset);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetWeaponDissolveEffectInfo", &UKGEffectManager::KAPI_EffectManager_SetWeaponDissolveEffectInfo);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetEnvNiagaraEffectTypeAssetPaths", &UKGEffectManager::KAPI_EffectManager_SetEnvNiagaraEffectTypeAssetPaths);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetOtherPlayerNiagaraPriorityThresholdIgnoreHidden", &UKGEffectManager::KAPI_EffectManager_SetOtherPlayerNiagaraPriorityThresholdIgnoreHidden);
	
	REG_MANAGER_FUNC(UKGEffectManager, "NotifyRemoveComponent", &UKGEffectManager::NotifyRemoveComponent);
	REG_MANAGER_FUNC(UKGEffectManager, "NotifyNiagaraAttachComponentCreated", &UKGEffectManager::NotifyNiagaraAttachComponentCreated);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraDelayDestroy", &UKGEffectManager::SetNiagaraDelayDestroy);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateAllNiagaraFloatParamBySpawnerId", &UKGEffectManager::UpdateAllNiagaraFloatParamBySpawnerId);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateNiagaraFloatParam", &UKGEffectManager::UpdateNiagaraFloatParam);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateNiagaraVec2Param", &UKGEffectManager::UpdateNiagaraVec2Param);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateNiagaraVec3Param", &UKGEffectManager::UpdateNiagaraVec3Param);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_UpdateNiagaraTextureParam", &UKGEffectManager::KAPI_EffectManager_UpdateNiagaraTextureParam);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_RemoveNiagaraTextureParam", &UKGEffectManager::KAPI_EffectManager_RemoveNiagaraTextureParam);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateAllNiagaraLinearColorParamBySpawnerId", &UKGEffectManager::UpdateAllNiagaraLinearColorParamBySpawnerId);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateAllSpiritualVisionMeshColorParam", &UKGEffectManager::UpdateAllSpiritualVisionMeshColorParam);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateNiagaraLinearColorParam", &UKGEffectManager::UpdateNiagaraLinearColorParam);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateNiagaraFollowActor", &UKGEffectManager::UpdateNiagaraFollowActor);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateNiagaraCameraArmLengthParam", &UKGEffectManager::UpdateNiagaraCameraArmLengthParam);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdatePositionWithArcParams", &UKGEffectManager::UpdatePositionWithArcParams);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateLinearSampleParamTargetValue", &UKGEffectManager::UpdateLinearSampleParamTargetValue);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_FinishLinearSampleParamTask", &UKGEffectManager::KAPI_EffectManager_FinishLinearSampleParamTask);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraRenderCustomDepthBySpawnerId", &UKGEffectManager::SetNiagaraRenderCustomDepthBySpawnerId);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_UpdateNiagaraHiddenState", &UKGEffectManager::KAPI_EffectManager_UpdateNiagaraHiddenState);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_UpdateNiagaraHiddenStateByEffectTag", &UKGEffectManager::KAPI_EffectManager_UpdateNiagaraHiddenStateByEffectTag);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateEffectVisibilityBySpawnerID", &UKGEffectManager::UpdateEffectVisibilityBySpawnerID);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateSystemUserVariableMeshComponent", &UKGEffectManager::UpdateSystemUserVariableMeshComponent);
	REG_MANAGER_FUNC(UKGEffectManager, "AddLinearSampleVectorParams", &UKGEffectManager::AddLinearSampleVectorParams);
	REG_MANAGER_FUNC(UKGEffectManager, "AddLinearSampleFloatParams", &UKGEffectManager::AddLinearSampleFloatParams);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraFaceToLocation", &UKGEffectManager::SetNiagaraFaceToLocation);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetNiagaraFaceToActor", &UKGEffectManager::KAPI_EffectManager_SetNiagaraFaceToActor);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetNiagaraFaceToCamera", &UKGEffectManager::KAPI_EffectManager_SetNiagaraFaceToCamera);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraFollowCameraFOV", &UKGEffectManager::SetNiagaraFollowCameraFOV);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraRenderCustomDepth", &UKGEffectManager::SetNiagaraRenderCustomDepth);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraComponentTags", &UKGEffectManager::SetNiagaraComponentTags);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetParticleColorScaleUpdateCurve", &UKGEffectManager::KAPI_EffectManager_SetParticleColorScaleUpdateCurve);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_BlendOutNiagaraByNiagaraParam", &UKGEffectManager::KAPI_EffectManager_BlendOutNiagaraByNiagaraParam);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraSplineLinkToComponent", &UKGEffectManager::SetNiagaraSplineLinkToComponent);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraSplineLinkToLocation", &UKGEffectManager::SetNiagaraSplineLinkToLocation);
	REG_MANAGER_FUNC(UKGEffectManager, "UpdateNiagaraSplineLinkTargetLocation", &UKGEffectManager::UpdateNiagaraSplineLinkTargetLocation);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_UpdateNiagaraSplineLinkTargetComponent", &UKGEffectManager::KAPI_EffectManager_UpdateNiagaraSplineLinkTargetComponent);
	REG_MANAGER_FUNC(UKGEffectManager, "AddFloatCurveParams", &UKGEffectManager::AddFloatCurveParams);
	REG_MANAGER_FUNC(UKGEffectManager, "IsNiagaraEffectValid", &UKGEffectManager::IsNiagaraEffectValid);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraRenderInMainPass", &UKGEffectManager::SetNiagaraRenderInMainPass);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraTranslucentSortPriority", &UKGEffectManager::SetNiagaraTranslucentSortPriority);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraTranslucencySortDistanceOffset", &UKGEffectManager::SetNiagaraTranslucencySortDistanceOffset);
	REG_MANAGER_FUNC(UKGEffectManager, "AppendNiagaraExtraEffectTags", &UKGEffectManager::AppendNiagaraExtraEffectTags);
	REG_MANAGER_FUNC(UKGEffectManager, "AppendNiagaraExtraEffectTag", &UKGEffectManager::AppendNiagaraExtraEffectTag);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_EnableNiagaraEffectTypeDebugCheck", &UKGEffectManager::KAPI_EffectManager_EnableNiagaraEffectTypeDebugCheck);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraEnableSpiritualVisionMeshColorChange", &UKGEffectManager::SetNiagaraEnableSpiritualVisionMeshColorChange);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetNiagaraFollowActorRotation", &UKGEffectManager::KAPI_EffectManager_SetNiagaraFollowActorRotation);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_UpdateParamByHeightDiff", &UKGEffectManager::KAPI_EffectManager_UpdateParamByHeightDiff);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetNiagaraStickOnGround", &UKGEffectManager::KAPI_EffectManager_SetNiagaraStickOnGround);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetEffectAudio", &UKGEffectManager::KAPI_EffectManager_SetEffectAudio);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetNiagaraParamByEffectID", &UKGEffectManager::KAPI_EffectManager_SetNiagaraParamByEffectID);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_ChangeNiagaraAttachSocket", &UKGEffectManager::KAPI_EffectManager_ChangeNiagaraAttachSocket);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetActorForceUseAbsoluteScale", &UKGEffectManager::KAPI_EffectManager_SetActorForceUseAbsoluteScale);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetNiagaraFollowSpawnerHiddenState", &UKGEffectManager::KAPI_EffectManager_SetNiagaraFollowSpawnerHiddenState);
	
	/** BEGIN: Niagara Score **/
	REG_MANAGER_FUNC(UKGEffectManager, "SetBattleEffectScoreControlForceEnabled", &UKGEffectManager::SetBattleEffectScoreControlForceEnabled);
	REG_MANAGER_FUNC(UKGEffectManager, "SetBattleEffectScoreControlEnabled", &UKGEffectManager::SetBattleEffectScoreControlEnabled);
	REG_MANAGER_FUNC(UKGEffectManager, "SetEnvEffectSlowTickForceEnabled", &UKGEffectManager::SetEnvEffectSlowTickForceEnabled);
	REG_MANAGER_FUNC(UKGEffectManager, "SetEnvEffectSlowTickEnabled", &UKGEffectManager::SetEnvEffectSlowTickEnabled);
	
	REG_MANAGER_FUNC(UKGEffectManager, "SetBattleEffectIgnorePriority4", &UKGEffectManager::SetBattleEffectIgnorePriority4);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraScoreCapacity", &UKGEffectManager::SetNiagaraScoreCapacity);
	REG_MANAGER_FUNC(UKGEffectManager, "SetNiagaraScoreData", &UKGEffectManager::SetNiagaraScoreData);
	REG_MANAGER_FUNC(UKGEffectManager, "PrintNiagaraScoreDebugMessage", &UKGEffectManager::PrintNiagaraScoreDebugMessage);
	REG_MANAGER_FUNC(UKGEffectManager, "SetEnvEffectConfig", &UKGEffectManager::SetEnvEffectConfig);
	REG_MANAGER_FUNC(UKGEffectManager, "SetBattleEffectSlowTickForceEnabled", &UKGEffectManager::SetBattleEffectSlowTickForceEnabled);
	REG_MANAGER_FUNC(UKGEffectManager, "SetBattleEffectSlowTickEnabled", &UKGEffectManager::SetBattleEffectSlowTickEnabled);
	REG_MANAGER_FUNC(UKGEffectManager, "SetBattleEffectSlowTickConfig", &UKGEffectManager::SetBattleEffectSlowTickConfig);
	REG_MANAGER_FUNC(UKGEffectManager, "SetSlowTickRate", &UKGEffectManager::SetSlowTickRate);
	/** END: Niagara Score **/

	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetNativeNiagaraParamsByNiagaraTagAndParamID", &UKGEffectManager::KAPI_EffectManager_SetNativeNiagaraParamsByNiagaraTagAndParamID);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_SetNativeNiagaraParamsByParamID", &UKGEffectManager::KAPI_EffectManager_SetNativeNiagaraParamsByParamID);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_AddNativeNiagaraLinearSampleFloatParam", &UKGEffectManager::KAPI_EffectManager_AddNativeNiagaraLinearSampleFloatParam);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_AddNativeNiagaraCurveParam", &UKGEffectManager::KAPI_EffectManager_AddNativeNiagaraCurveParam);
	REG_MANAGER_FUNC(UKGEffectManager, "KAPI_EffectManager_RemoveNativeNiagaraUpdateTask", &UKGEffectManager::KAPI_EffectManager_RemoveNativeNiagaraUpdateTask);
	
	Super::NativeInit();
}

void UKGEffectManager::NativeUninit()
{
	FNiagaraSystemInstance::OnNiagaraSystemInstanceAllocated.RemoveAll(this);
	FNiagaraSystemInstance::OnNiagaraSystemInstanceDeallocated.RemoveAll(this);
	
	DestroyAllNiagaras();
	
	if (this->NiagaraScoreManager.IsValid())
	{
		this->NiagaraScoreManager->Quit();
		this->NiagaraScoreManager.Reset();
	}
	
	Super::NativeUninit();
}

void UKGEffectManager::OnPostLoadMapWithWorld(UWorld* World)
{
	Super::OnPostLoadMapWithWorld(World);
	
	// 这里不能直接empty掉, 可能新场景的特效已经在里面了
	TSet<TWeakObjectPtr<UNiagaraComponent>> NewNativeEnvNiagaraComponents;
	for (const auto& Comp : NativeEnvNiagaraComponents)
	{
		if (Comp.IsValid())
		{
			NewNativeEnvNiagaraComponents.Add(Comp);
		}
	}
	NativeEnvNiagaraComponents = NewNativeEnvNiagaraComponents;
	
	ForceUseAbsoluteScaleActors.Empty();
	ActorsWithTimeDilation.Empty();
}

#pragma endregion Important

#pragma region Tick

void UKGEffectManager::Tick(float DeltaTime)
{
	TRACE_CPUPROFILER_EVENT_SCOPE_STR("UKGEffectManager_Tick");
	
	UpdateNiagaras(DeltaTime);

	if (this->NiagaraScoreManager.IsValid())
	{
		this->NiagaraScoreManager->Tick(DeltaTime);
	}
}

#pragma endregion Tick

#pragma region Delegates
UKGEffectManager::EffectManagerNiagaraComponentChangeDelegate UKGEffectManager::OnNiagaraComponentActive;
UKGEffectManager::EffectManagerNiagaraComponentChangeDelegate UKGEffectManager::OnNiagaraComponentDeActive;
#pragma endregion Delegates

#pragma region Niagara

int32 UKGEffectManager::KAPI_EffectManager_CreateNiagaraSystemAtLocation(
	const FString& NiagaraEffectPath, int32 CustomEffectID,
	uint8 SearchSpawnLocationType, FName AttachPointName, bool bNeedFitGround,
	KGObjectID SpawnerID, KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID,
	bool bFollowHidden, bool bFollowSlomo, bool bFollowCameraFOV,
	float SpawnTrans_LX, float SpawnTrans_LY, float SpawnTrans_LZ,
	bool bUseQuat, float PitchOrX, float YawOrY, float RollOrZ, float W,
	float SpawnTrans_SX, float SpawnTrans_SY, float SpawnTrans_SZ,
	bool bIsPlayerEffect, bool bActivateImmediately,
	float TransparencyScale,
	float TotalLifeMs, uint8 NiagaraDestroyType, float BlendInTimeSeconds, float BlendOutTimeSeconds,
	float EffectPlayRate, bool bDestroyWhenSpawnerExitWorld, bool bBattleEffect, int32 NiagaraBusinessPriority)
{
	FKGUnattachedNiagaraSpawnInfo SpawnInfo;
	SpawnInfo.SearchSpawnLocationType = static_cast<EKGNiagaraSearchSpawnLocationType>(SearchSpawnLocationType);
	SpawnInfo.AttachPointName = AttachPointName;
	AssembleSpawnTrans(
		SpawnTrans_LX, SpawnTrans_LY, SpawnTrans_LZ,
		bUseQuat, PitchOrX, YawOrY, RollOrZ, W,
		SpawnTrans_SX, SpawnTrans_SY, SpawnTrans_SZ, SpawnInfo.WorldOrRelativeTrans);
	return ScriptCreateNiagaraSystemCommon(
		NiagaraEffectPath, CustomEffectID, NAME_None, false,
		false, FKGAttachedNiagaraSpawnInfo(), SpawnInfo,
		SpawnerID, SpawnerEntityID, InstigatorEntityID,
		bFollowHidden, bFollowSlomo, bFollowCameraFOV, bNeedFitGround,
		bIsPlayerEffect, bActivateImmediately,
		TransparencyScale, TotalLifeMs, NiagaraDestroyType,
		BlendInTimeSeconds, BlendOutTimeSeconds, EffectPlayRate, bDestroyWhenSpawnerExitWorld,
		bBattleEffect, NiagaraBusinessPriority);
}

int32 UKGEffectManager::KAPI_EffectManager_CreateNiagaraSystemAttached(
	const FString& NiagaraEffectPath, int32 CustomEffectID,
	uint8 SearchAttachComponentType, KGObjectID AttachComponentID, bool bAbsoluteScale, bool bAbsoluteRotation, FName AttachPointName,
	int32 LocationType, FName AttachComponentName, FName AttachComponentTag, UClass* ComponentClass,bool bCacheEvenIfDynamicMeshCtxNotFound,
	KGObjectID SpawnerID, KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID,
	bool bFollowHidden, bool bFollowSlomo, bool bFollowCameraFOV,
	float SpawnTrans_LX, float SpawnTrans_LY, float SpawnTrans_LZ,
	bool bUseQuat, float PitchOrX, float YawOrY, float RollOrZ, float W,
	float SpawnTrans_SX, float SpawnTrans_SY, float SpawnTrans_SZ,
	bool bIsPlayerEffect, bool bActivateImmediately,
	float TransparencyScale, float TotalLifeMs, uint8 NiagaraDestroyType,
	float BlendInTimeSeconds, float BlendOutTimeSeconds, float EffectPlayRate, bool bDestroyWhenSpawnerExitWorld,
	bool bBattleEffect,	int32 NiagaraBusinessPriority)
{
	FKGAttachedNiagaraSpawnInfo SpawnInfo;
	SpawnInfo.SearchAttachComponentType = static_cast<EKGNiagaraSearchAttachComponentType>(SearchAttachComponentType);
	if (SpawnInfo.SearchAttachComponentType == EKGNiagaraSearchAttachComponentType::UseCustomAttachComponent)
	{
		SpawnInfo.CustomAttachComponent = Cast<USceneComponent>(KGUtils::GetObjectByID(AttachComponentID));
		if (!SpawnInfo.CustomAttachComponent.IsValid())
		{
			UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::KAPI_EffectManager_CreateNiagaraSystemAttached, invalid custom attach component %lld"), AttachComponentID);
			return KG_INVALID_NIAGARA_SYSTEM_ID;	
		}
	}
	SpawnInfo.bAbsoluteRotation = bAbsoluteRotation;
	SpawnInfo.bAbsoluteScale = bAbsoluteScale;
	SpawnInfo.AttachPointName = AttachPointName;
	SpawnInfo.LocationType = TEnumAsByte<EAttachLocation::Type>(LocationType);
	SpawnInfo.ComponentTag = AttachComponentTag;
	SpawnInfo.ComponentClass = ComponentClass;
	AssembleSpawnTrans(
		SpawnTrans_LX, SpawnTrans_LY, SpawnTrans_LZ,
		bUseQuat, PitchOrX, YawOrY, RollOrZ, W,
		SpawnTrans_SX, SpawnTrans_SY, SpawnTrans_SZ, SpawnInfo.RelativeTrans);
	return ScriptCreateNiagaraSystemCommon(
		NiagaraEffectPath, CustomEffectID,
		AttachComponentName, bCacheEvenIfDynamicMeshCtxNotFound,
		true, SpawnInfo, FKGUnattachedNiagaraSpawnInfo(),
		SpawnerID, SpawnerEntityID, InstigatorEntityID,
		bFollowHidden, bFollowSlomo, bFollowCameraFOV, false,
		bIsPlayerEffect, bActivateImmediately,
		TransparencyScale, TotalLifeMs, NiagaraDestroyType,
		BlendInTimeSeconds, BlendOutTimeSeconds, EffectPlayRate, bDestroyWhenSpawnerExitWorld,
		bBattleEffect, NiagaraBusinessPriority);
}

int32 UKGEffectManager::CreateNiagaraSystemByAttachEffectDataID(
	int32 EffectDataID, float Duration, EKGNiagaraDestroyType DestroyType, bool bOverrideBlendOutTime, float BlendOutTimeSeconds,
	bool bHasEffectTag, int32 ExtraEffectTag, KGActorID SpawnerID, KGEntityID SpawnerEntityID, uint32 CustomEffectID)
{
	UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(this);
	if (!DataCacheManager)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::CreateNiagaraSystemByAttachEffectDataID, invalid data cache manager"));
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
	
	auto* AttachEffectData = DataCacheManager->GetAttachedNiagaraEffectData(EffectDataID);
	if (!AttachEffectData)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::CreateNiagaraSystemByAttachEffectDataID, invalid attach data effect"));
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
	
	AActor* SpawnerActor = KGUtils::GetActorByID(SpawnerID);;
	if (!IsValid(SpawnerActor))
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::CreateNiagaraSystemByAttachEffectDataID, invalid spawner actor %lld"), SpawnerID);
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
	
	FKGPlayNiagaraParams PlayNiagaraParams;
	
	FKGAttachedNiagaraSpawnInfo SpawnInfo;
	if (AttachEffectData->bAttachToCamera)
	{
		SpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::UseCameraRootComponent;
		PlayNiagaraParams.bFollowCameraFOV = true;
	}
	else if (!AttachEffectData->AttachComponentName.IsEmpty())
	{
		FName ComponentTag = *AttachEffectData->AttachComponentName;
		const auto& Components = SpawnerActor->GetComponentsByTag(USceneComponent::StaticClass(), ComponentTag);
		if (Components.Num() == 0)
		{
			UE_LOG(LogEM, Log, TEXT("UKGEffectManager::CreateNiagaraSystemByAttachEffectDataID, no component found with tag %s in actor %s"),
				*AttachEffectData->AttachComponentName, *SpawnerActor->GetName());
			return KG_INVALID_NIAGARA_SYSTEM_ID;
		}
		SpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::FindComponentByComponentName;
		PlayNiagaraParams.AttachComponentName = ComponentTag;
	}
	else
	{
		SpawnInfo.SearchAttachComponentType = EKGNiagaraSearchAttachComponentType::FindComponentBySocketName;
	}
	
	PlayNiagaraParams.NiagaraEffectPath = AttachEffectData->NiagaraEffectPath;
	PlayNiagaraParams.SpawnerID = SpawnerID;
	PlayNiagaraParams.SpawnerEntityID = SpawnerEntityID;
	PlayNiagaraParams.TotalLifeMs = Duration * 1000.0f;
	PlayNiagaraParams.NiagaraDestroyType = DestroyType;
	
	if (CustomEffectID != 0)
	{
		PlayNiagaraParams.CustomEffectID = CustomEffectID;
	}
	if (bOverrideBlendOutTime)
	{
		PlayNiagaraParams.BlendOutTimeSeconds = BlendOutTimeSeconds;
	}
	if (bHasEffectTag)
	{
		PlayNiagaraParams.EffectTags.Add(static_cast<EKGNiagaraEffectTag>(ExtraEffectTag));	
	}
	
	SpawnInfo.AttachPointName = AttachEffectData->AttachPointName;
	SpawnInfo.RelativeTrans = AttachEffectData->RelativeTransform;
	PlayNiagaraParams.SetAttachedSpawnInfo(SpawnInfo);
	return CreateNiagaraSystem(PlayNiagaraParams);
}

int32 UKGEffectManager::KAPI_EffectManager_CreateWeaponDissolveNiagaraEffect(
	KGActorID WeaponActorID, KGActorID WeaponOwnerID, KGEntityID WeaponOwnerEntityID, const FString& SKWeaponDissolveEffectPath, const FString& SMWeaponDissolveEffectPath,
	float DissolveTime, bool bDissolveIn, float EffectPlayRate, int32 CustomEffectID)
{
	AActor* WeaponActor = KGUtils::GetActorByID(WeaponActorID);
	if (!IsValid(WeaponActor))
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::KAPI_EffectManager_CreateWeaponDissolveNiagaraEffect, invalid weapon actor %lld"), WeaponActorID);
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
	
	return CreateWeaponDissolveNiagaraEffect(
		WeaponActor, WeaponOwnerID, WeaponOwnerEntityID,
		SKWeaponDissolveEffectPath, SMWeaponDissolveEffectPath, DissolveTime, bDissolveIn, EffectPlayRate, CustomEffectID);
}

int32 UKGEffectManager::CreateWeaponDissolveNiagaraEffect(AActor* WeaponActor, KGActorID WeaponOwnerID, KGEntityID WeaponOwnerEntityID,
    const FString& SKWeaponDissolveEffectPath, const FString& SMWeaponDissolveEffectPath, float DissolveTime, bool bDissolveIn,
    float EffectPlayRate, int32 CustomEffectID)
{
	if (!IsValid(WeaponActor))
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::CreateWeaponDissolveNiagaraEffect, invalid weapon actor"));
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}

	AActor* WeaponOwnerActor = KGUtils::GetActorByID(WeaponOwnerID);
	if (!WeaponOwnerActor)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::CreateWeaponDissolveNiagaraEffect, invalid weapon owner actor %lld"), WeaponOwnerID);
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}

	if (WeaponOwnerEntityID == KG_INVALID_ENTITY_ID)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::CreateWeaponDissolveNiagaraEffect, invalid weapon owner entity id for actor %lld"), WeaponOwnerID);
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
	
	FKGPlayNiagaraParams PlayNiagaraParams;
	FString ParamName;
	KGObjectID MeshCompID;
	if (UStaticMeshComponent* StaticMeshComponent = WeaponActor->FindComponentByClass<UStaticMeshComponent>())
	{
		ParamName = WeaponDissolveSMParamName;
		MeshCompID = KGUtils::GetIDByObject(StaticMeshComponent);
		PlayNiagaraParams.NiagaraEffectPath = SMWeaponDissolveEffectPath;
	}
	else if (USkeletalMeshComponent* SkeletalMeshComponent = WeaponActor->FindComponentByClass<USkeletalMeshComponent>())
	{
		ParamName = WeaponDissolveSKParamName;
		MeshCompID = KGUtils::GetIDByObject(SkeletalMeshComponent);
		PlayNiagaraParams.NiagaraEffectPath = SKWeaponDissolveEffectPath;
	}
	else
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::CreateWeaponDissolveNiagaraEffect, no valid mesh component found in weapon actor %s"), *WeaponActor->GetName());
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}

	PlayNiagaraParams.TotalLifeMs = DissolveTime * 1000.0f;
	PlayNiagaraParams.bActivateImmediately = true;
	PlayNiagaraParams.SpawnerID = WeaponOwnerID;
	PlayNiagaraParams.SpawnerEntityID = WeaponOwnerEntityID;
	PlayNiagaraParams.EffectPlayRate = EffectPlayRate;
	if (CustomEffectID != 0)
	{
		PlayNiagaraParams.CustomEffectID = CustomEffectID;
	}

	bool bUseCloneMesh = false;
	if (bDissolveIn)
	{
		FKGAttachedNiagaraSpawnInfo AttachedNiagaraSpawnInfo;
		PlayNiagaraParams.SetAttachedSpawnInfo(AttachedNiagaraSpawnInfo);
	}
	else
	{
		FKGUnattachedNiagaraSpawnInfo UnattachedNiagaraSpawnInfo;
		UnattachedNiagaraSpawnInfo.SearchSpawnLocationType = EKGNiagaraSearchSpawnLocationType::UseActorTransform;
		PlayNiagaraParams.SetUnattachedSpawnInfo(UnattachedNiagaraSpawnInfo);
		bUseCloneMesh = true;
	}

	const auto EffectID = CreateNiagaraSystem(PlayNiagaraParams);
	if (EffectID != KG_INVALID_NIAGARA_SYSTEM_ID)
	{
		UpdateNiagaraFloatParam(EffectID, WeaponDissolveExistTimeParamName, DissolveTime * WeaponDissolveExistingTimeRatio);
		UpdateSystemUserVariableMeshComponent(EffectID, ParamName, MeshCompID, {}, bUseCloneMesh, false);
	}

	return EffectID;
}

int32 UKGEffectManager::KAPI_EffectManager_CreateSkillNiagaraSystemNew(
	const FString& NiagaraEffectPath, int32 CustomEffectID,
	uint8 SearchAttachComponentType, const FName& AttachComponentName, 
	bool bAbsoluteScale, EKGNiagaraPositionMode PositionMode, EKGNiagaraRotationMode RotationMode,
	FName AttachPointName, KGEntityID RotationTargetEntityID, bool bNeedFitGround, bool bCacheEvenIfDynamicMeshCtxNotFound,
	KGObjectID SpawnerID, KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID,
	float SpawnTrans_LX, float SpawnTrans_LY, float SpawnTrans_LZ,
	float Pitch, float Yaw, float Roll, 
	float SpawnTrans_SX, float SpawnTrans_SY, float SpawnTrans_SZ,
	float TransparencyScale, float TotalLifeMs, float BlendOutTimeSeconds,
	float EffectPlayRate, int32 NiagaraBusinessPriority)
{
	const bool bNeedAttach = PositionMode == EKGNiagaraPositionMode::Follow ||
		RotationMode == EKGNiagaraRotationMode::Follow;
	FKGPlayNiagaraParams PlayNiagaraParams;
	if (bNeedAttach)
	{
		FKGAttachedNiagaraSpawnInfo AttachedSpawnInfo;
		AttachedSpawnInfo.SearchAttachComponentType = static_cast<EKGNiagaraSearchAttachComponentType>(SearchAttachComponentType);
		AttachedSpawnInfo.AttachPointName = AttachPointName;
		AttachedSpawnInfo.bAbsoluteScale = bAbsoluteScale;
		AssembleSpawnTrans(
			SpawnTrans_LX, SpawnTrans_LY, SpawnTrans_LZ,
			false, Pitch, Yaw, Roll, 0.0f,
			SpawnTrans_SX, SpawnTrans_SY, SpawnTrans_SZ, AttachedSpawnInfo.RelativeTrans);
		PlayNiagaraParams.SetAttachedSpawnInfo(AttachedSpawnInfo);
	}
	else
	{
		FKGUnattachedNiagaraSpawnInfo UnattachedSpawnInfo;
		UnattachedSpawnInfo.AttachPointName = AttachPointName;
		UnattachedSpawnInfo.bAbsoluteScale = bAbsoluteScale;
		AssembleSpawnTrans(
			SpawnTrans_LX, SpawnTrans_LY, SpawnTrans_LZ,
			false, Pitch, Yaw, Roll, 0.0f,
			SpawnTrans_SX, SpawnTrans_SY, SpawnTrans_SZ, UnattachedSpawnInfo.WorldOrRelativeTrans);
		PlayNiagaraParams.SetUnattachedSpawnInfo(UnattachedSpawnInfo);
	}
	PlayNiagaraParams.bUseSkillNiagaraSpawnInfo = true;
	PlayNiagaraParams.RotationMode = RotationMode;
	PlayNiagaraParams.PositionMode = PositionMode;
	PlayNiagaraParams.RotationTargetEntityID = RotationTargetEntityID;
	PlayNiagaraParams.AttachComponentName = AttachComponentName;
	PlayNiagaraParams.bCacheEvenIfDynamicMeshCtxNotFound = bCacheEvenIfDynamicMeshCtxNotFound;
	PlayNiagaraParams.StickGroundType = bNeedFitGround ? EKGNiagaraStickGroundType::StickToGround : EKGNiagaraStickGroundType::DoNotStickToGround;
	
	PlayNiagaraParams.NiagaraEffectPath = NiagaraEffectPath;
	PlayNiagaraParams.SpawnerID = SpawnerID;
	PlayNiagaraParams.SpawnerEntityID = SpawnerEntityID;
	PlayNiagaraParams.InstigatorEntityID = InstigatorEntityID;
	PlayNiagaraParams.TotalLifeMs = TotalLifeMs;
	PlayNiagaraParams.BlendOutTimeSeconds = BlendOutTimeSeconds;
	PlayNiagaraParams.EffectPlayRate = EffectPlayRate;
	PlayNiagaraParams.TransparencyScale = TransparencyScale;
	PlayNiagaraParams.EffectTags.Add(EKGNiagaraEffectTag::BATTLE);
	PlayNiagaraParams.NiagaraBusinessPriority = NiagaraBusinessPriority;
	if (CustomEffectID > 0)
	{
		PlayNiagaraParams.CustomEffectID = CustomEffectID;
	}
	const auto EffectID = CreateNiagaraSystem(PlayNiagaraParams);
	if (EffectID != KG_INVALID_NIAGARA_SYSTEM_ID)
	{
		if (RotationMode == EKGNiagaraRotationMode::ToCameraYaw)
		{
			SetNiagaraFaceToCamera(EffectID, EKGNiagaraFaceToActorRotationType::OnlyRotateYaw);
		}
	}
	return EffectID;
}

int32 UKGEffectManager::CreateNiagaraSystem(const FKGPlayNiagaraParams& PlayNiagaraParams)
{
#if KG_EFFECTMANAGER_ENABLE_STAT
	if (GKGForbidCreateNiagara)
	{
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
#endif

	SCOPED_NAMED_EVENT(UKGEffectManager_CreateNiagaraSystem, FColor::Red);
	
	if (PlayNiagaraParams.NiagaraEffectPath.IsEmpty())
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::CreateNiagaraSystem, no niagara effect path"));
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
	
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this);
	if (!AssetManager)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::CreateNiagaraSystem, no asset manager"));
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}

	AActor* Spawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
	if (!Spawner)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::CreateNiagaraSystem, invalid spawner id %lld"), PlayNiagaraParams.SpawnerID);
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}

	int32 NiagaraEffectId;
	if (PlayNiagaraParams.CustomEffectID.IsSet())
	{
		NiagaraEffectId = PlayNiagaraParams.CustomEffectID.GetValue();
	}
	else
	{
		NiagaraEffectId = GenerateNiagaraEffectId();
	}
	
	// 外部参数误传可能导致custom effect id错掉, 自生成的id一般不会有问题
	if (NiagaraUpdateContexts.Contains(NiagaraEffectId))
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::CreateNiagaraSystem, effect id already in use %d, %s"), 
			NiagaraEffectId, *PlayNiagaraParams.NiagaraEffectPath);
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
	
	FKGNiagaraUpdateContext TempUpdateContext;
	TempUpdateContext.PlayNiagaraParams = PlayNiagaraParams;
	TempUpdateContext.EffectManager = this;
	TempUpdateContext.bForceUseAbsoluteScale = DoesActorForceUseAbsoluteScale(PlayNiagaraParams.SpawnerID);
	TempUpdateContext.NiagaraEffectId = NiagaraEffectId;
	if (!TempUpdateContext.RefreshAttachComponentOrSpawnTrans())
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::CreateNiagaraSystem, failed to get attach component or spawn transform %lld"), PlayNiagaraParams.SpawnerID);
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
	
	FKGNiagaraUpdateContext& UpdateContext = NiagaraUpdateContexts.Add(NiagaraEffectId, TempUpdateContext);
	UpdateContext.RefreshNiagaraCommonTags();
	UpdateContext.LifeTimeHandle.SetOwnerActor(Spawner);
	UpdateContext.ChangeVisibilityTimerHandle.SetOwnerActor(Spawner);
	
	UE_LOG(LogEM, Log,
		TEXT("UKGEffectManager::CreateNiagaraSystem, NiagaraEffectId %d, SpawnerID: %lld, NiagaraEffectPath: %s"),
		NiagaraEffectId, PlayNiagaraParams.SpawnerID, *PlayNiagaraParams.NiagaraEffectPath);

	BindEffectToSpawner(NiagaraEffectId, UpdateContext.PlayNiagaraParams.SpawnerID, true,
		EKGNiagaraBehaviorOnExtraSpawnerDestroy::DestroyEffect, EKGNiagaraHiddenReason::OWNER_SET_HIDDEN, UpdateContext);

	for (const auto EffectTag : UpdateContext.PlayNiagaraParams.EffectTags)
	{
		auto& EffectIds = EffectTagToEffectIds.FindOrAdd(EffectTag);
		EffectIds.Add(NiagaraEffectId);
		UE_LOG(LogEM, Log,
			TEXT("UKGEffectManager set effect tag on create niagara, NiagaraEffectId %d, NiagaraEffectPath: %s, EffectTag: %d"),
			NiagaraEffectId, *PlayNiagaraParams.NiagaraEffectPath, EffectTag);
	}
	
	UObject* NiagaraAsset = nullptr;
	UpdateContext.AssetLoadID = AssetManager->AsyncLoadAsset(
		PlayNiagaraParams.NiagaraEffectPath, NiagaraAsset, 
		FAsyncLoadCompleteDelegate::CreateUObject(this, &UKGEffectManager::InternalOnNiagaraAssetsLoaded, NiagaraEffectId, true));
	
	if (NiagaraAsset != nullptr)
	{
		InternalOnNiagaraAssetsLoaded(KG_CPP_INVALID_ASSET_LOAD_ID, NiagaraAsset, NiagaraEffectId, false);
	}
	
	return NiagaraEffectId;
}

bool UKGEffectManager::DeactivateNiagaraSystem(
	int32 NiagaraEffectId, bool bOverrideBlendOut, bool bNewNiagaraBlendOut, bool bOverrideBlendOutTime, float NewBlendOutTimeSeconds)
{
	FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!UpdateContextPtr)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::DeactivateNiagaraSystem, cannot find NiagaraEffectId %d"), NiagaraEffectId);
		return false;
	}

	SCOPED_NAMED_EVENT(UKGEffectManager_DeactivateNiagaraSystem, FColor::Red);
	
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::DeactivateNiagaraSystem, %s"), *UpdateContextPtr->ToString());
	
	// 还在资源加载中
	if (UpdateContextPtr->AssetLoadID != 0)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::DeactivateNiagaraSystem, loading niagara asset, cancel loading process %s"), *UpdateContextPtr->ToString())
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
		{
			AssetManager->CancelAsyncLoadByLoadID(UpdateContextPtr->AssetLoadID);
			UpdateContextPtr->AssetLoadID = 0;
		}
	}

	UNiagaraComponent* NiagaraComponent = UpdateContextPtr->NiagaraComponent;
	if (NiagaraComponent == nullptr)
	{
		// 还处于pending activate状态
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::DeactivateNiagaraSystem, niagara pending activate, destroy immediately %s"), *UpdateContextPtr->ToString());
		return InternalDestroyNiagaraSystem(NiagaraEffectId);
	}

	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::DeactivateNiagaraSystem, deactivate niagara %s"), *UpdateContextPtr->ToString());

	const bool bShouldBlendOut = bOverrideBlendOut ? bNewNiagaraBlendOut : UpdateContextPtr->PlayNiagaraParams.NiagaraDestroyType == EKGNiagaraDestroyType::BlendOutBeforeDestroy;
	float BlendOutTimeSeconds = bOverrideBlendOutTime ? NewBlendOutTimeSeconds : UpdateContextPtr->PlayNiagaraParams.BlendOutTimeSeconds;
	BlendOutTimeSeconds = FMath::Max(BlendOutTimeSeconds, KG_NIAGARA_MIN_DELAY_DESTROY_TIME);
	
	const float DelayDestroyTimeSeconds = bShouldBlendOut ? BlendOutTimeSeconds : KG_NIAGARA_MIN_DELAY_DESTROY_TIME;
	SetNiagaraLifeTimeTimer(NiagaraEffectId, EKGNiagaraTimeoutState::Destroy, DelayDestroyTimeSeconds);
	
	if (bShouldBlendOut)
	{
		InternalSetLinearSampleParticleColorScaleUpdateTask(*UpdateContextPtr, false, BlendOutTimeSeconds, false);
	}
	else
	{
		NiagaraComponent->Deactivate();
	}
	
	return false;
}

bool UKGEffectManager::DestroyNiagaraSystem(int32 NiagaraEffectId)
{
	return InternalDestroyNiagaraSystem(NiagaraEffectId);
}

void UKGEffectManager::KAPI_EffectManager_DeactivateNiagaraSystemsByEffectTag(
	KGObjectID SpawnerId, int32 EffectTag, bool bOverrideBlendOut, bool bNewNiagaraBlendOut, bool bOverrideBlendOutTime, float NewBlendOutTimeSeconds)
{
	const auto EffectTagEnum = static_cast<EKGNiagaraEffectTag>(EffectTag);
	if (!EffectTagToEffectIds.Contains(EffectTagEnum))
	{
		return;
	}

	TSet<int32> TempEffectIds = EffectTagToEffectIds[EffectTagEnum];
	for (int32 EffectId : TempEffectIds)
	{
		FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(EffectId);
		if (UpdateContextPtr && UpdateContextPtr->PlayNiagaraParams.SpawnerID == SpawnerId)
		{
			DeactivateNiagaraSystem(EffectId, bOverrideBlendOut, bNewNiagaraBlendOut, bOverrideBlendOutTime, NewBlendOutTimeSeconds);
		}
	}
}

void UKGEffectManager::KAPI_EffectManager_DestroyNiagaraSystemsByEffectTag(KGObjectID SpawnerId, int32 EffectTag)
{
	const auto EffectTagEnum = static_cast<EKGNiagaraEffectTag>(EffectTag);
	if (!EffectTagToEffectIds.Contains(EffectTagEnum))
	{
		return;
	}

	TSet<int32> TempEffectIds = EffectTagToEffectIds[EffectTagEnum];
	for (int32 EffectId : TempEffectIds)
	{
		FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(EffectId);
		if (UpdateContextPtr && UpdateContextPtr->PlayNiagaraParams.SpawnerID == SpawnerId)
		{
			DestroyNiagaraSystem(EffectId);
		}
	}
}

void UKGEffectManager::DestroyNiagarasBySpawnerId(KGObjectID SpawnerId, bool bSpawnerExitWorld)
{
	DestroyOrDeactivateNiagarasBySpawnerId(SpawnerId, bSpawnerExitWorld, true);
}

void UKGEffectManager::DeactivateNiagarasBySpawnerId(KGObjectID SpawnerId, bool bSpawnerExitWorld)
{
	DestroyOrDeactivateNiagarasBySpawnerId(SpawnerId, bSpawnerExitWorld, false);
}

void UKGEffectManager::DestroyAllNiagaras()
{
	TArray<int32> NiagaraEffectIds;
	NiagaraUpdateContexts.GenerateKeyArray(NiagaraEffectIds);

	for (const auto EffectId : NiagaraEffectIds)
	{
		DestroyNiagaraSystem(EffectId);
	}
}

void UKGEffectManager::CheckGroundLocation(AActor* Spawner, bool bUsePlaneLocation, FVector& InOutLocation)
{
	if (!Spawner)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::CheckGroundLocation, invalid spawner"));
		return;
	}

	const auto& Offset = GroundCheckOffset;

	// 一些体型较大的角色贴地检测距离3m会有问题, 先继续使用原始的贴地检测逻辑
	if (bUsePlaneLocation)
	{
		const FVector& PlaneNormal = Spawner->GetActorUpVector();
		const FVector& PlanePoint = UKGActorUtil::V2GetActorBottomLocation(Spawner);
		const FVector& TestPlanePoint = UKismetMathLibrary::ProjectPointOnToPlane(InOutLocation, PlanePoint, PlaneNormal);
		InOutLocation = TestPlanePoint;	
	}
	
	// 接下来根据该寻路网格点向下做射线检查，找到模型表面
	FHitResult HitResult;
	bool bSuccess = UKismetSystemLibrary::LineTraceSingle(
		Spawner, InOutLocation + FVector::DownVector * Offset.X, InOutLocation + FVector::DownVector * Offset.Y, 
		UEngineTypes::ConvertToTraceType(GroundCheckObjectType), false, {},
		EDrawDebugTrace::None, HitResult, true, FLinearColor::Red, FLinearColor::Green, 0.0f);
	
	if (bSuccess)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::CheckGroundLocation, hit ground at location %s %s %s"), *HitResult.ImpactPoint.ToString(), 
			*GetNameSafe(HitResult.GetActor()), *GetNameSafe(HitResult.GetComponent()));
		InOutLocation = HitResult.ImpactPoint;
	}
	else
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::CheckGroundLocation, do not find ground at location %s"), *InOutLocation.ToString());
	}
}

void UKGEffectManager::KAPI_EffectManager_SetWeaponDissolveEffectInfo(
	const FString& InWeaponDissolveSMParamName, const FString& InWeaponDissolveSKParamName, FName InWeaponDissolveExistTimeParamName, float InWeaponDissolveExistingTimeRatio)
{
	WeaponDissolveSMParamName = InWeaponDissolveSMParamName;
	WeaponDissolveSKParamName = InWeaponDissolveSKParamName;
	WeaponDissolveExistingTimeRatio = InWeaponDissolveExistingTimeRatio;
	WeaponDissolveExistTimeParamName = InWeaponDissolveExistTimeParamName;
}

UNiagaraComponent* UKGEffectManager::GetNiagaraComponentByNiagaraEffectId(int32 NiagaraEffectId)
{
	if (!NiagaraUpdateContexts.Contains(NiagaraEffectId))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::GetNiagaraComponentByNiagaraEffectId, cannot find NiagaraEffectId %d"), NiagaraEffectId);
		return nullptr;
	}

	UNiagaraComponent* NiagaraComponent = NiagaraUpdateContexts[NiagaraEffectId].NiagaraComponent;
	if (!IsValid(NiagaraComponent))
	{
		// UE_LOG(LogEM, Log, TEXT("UKGEffectManager::GetNiagaraComponentByNiagaraEffectId, Component of NiagaraEffectId %d is released"), NiagaraEffectId);
		return nullptr;
	}

	return NiagaraComponent;
}

bool UKGEffectManager::GetNiagaraEffectIdByNiagaraComponent(UNiagaraComponent* NiagaraComponent, int32& OutNiagaraEffectId)
{
	if (!IsValid(NiagaraComponent))
	{
		return false;
	}
	
	if (NiagaraComponentToNiagaraId.Contains(NiagaraComponent))
	{
		OutNiagaraEffectId = NiagaraComponentToNiagaraId[NiagaraComponent];
		return true;
	}
	
	return false;
}

void UKGEffectManager::SetNiagaraLifeTimeTimer(int32 NiagaraEffectId, EKGNiagaraTimeoutState State, float DelayTimeSeconds)
{
	auto* ContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!ContextPtr)
	{
		return;
	}
	
	ContextPtr->LifeTimeHandle.ClearTimer();
	const bool bUseTimerManager = !ActorsWithTimeDilation.Contains(ContextPtr->PlayNiagaraParams.SpawnerID);
	UE_LOG(LogEM, Log,
		TEXT("UKGEffectManager::SetNiagaraLifeTimeTimer, start life time timer %f seconds, %s, bUseTimerManager=%d"),
		DelayTimeSeconds, *ContextPtr->ToString(), bUseTimerManager);
	ContextPtr->LifeTimeHandle.InitOnceTimer(DelayTimeSeconds, 
		FTimerDelegate::CreateUObject(this, &UKGEffectManager::OnNiagaraLifeTimeTimerExpired, NiagaraEffectId, State), bUseTimerManager);
}

void UKGEffectManager::RemoveNiagaraLifeTimeTimer(int32 NiagaraEffectId)
{
	auto* ContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!ContextPtr)
	{
		return;
	}
	
	ContextPtr->LifeTimeHandle.ClearTimer();
}

void UKGEffectManager::SetNiagaraWaitAttachComponentTimer(FKGNiagaraUpdateContext& InOutContext, float WaitTimeSeconds)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::SetNiagaraWaitAttachComponentTimer, World is null, %s"), *InOutContext.ToString());
		return;
	}

	if (FMath::IsNearlyZero(WaitTimeSeconds))
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::SetNiagaraWaitAttachComponentTimer, WaitTimeSeconds is nearly zero, %s"), *InOutContext.ToString());
		return;
	}

	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::SetNiagaraWaitAttachComponentTimer, WaitTimeSeconds: %f, %s"), WaitTimeSeconds, *InOutContext.ToString());

	World->GetTimerManager().ClearTimer(InOutContext.WaitAttachComponentHandle);
	World->GetTimerManager().SetTimer(InOutContext.WaitAttachComponentHandle,
		FTimerDelegate::CreateUObject(this, &UKGEffectManager::OnNiagaraWaitAttachComponentTimerTimeout, InOutContext.NiagaraEffectId),
		WaitTimeSeconds, false);
}

void UKGEffectManager::ClearNiagaraWaitAttachComponentTimer(FKGNiagaraUpdateContext& InOutContext)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::ClearNiagaraWaitAttachComponentTimer, World is null, %s"), *InOutContext.ToString());
		return;
	}

	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::ClearNiagaraWaitAttachComponentTimer, %s"), *InOutContext.ToString());
	World->GetTimerManager().ClearTimer(InOutContext.WaitAttachComponentHandle);
	InOutContext.WaitAttachComponentHandle.Invalidate();
}

void UKGEffectManager::OnNiagaraWaitAttachComponentTimerTimeout(int32 NiagaraEffectId)
{
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::OnNiagaraWaitAttachComponentTimerTimeout, %d"), NiagaraEffectId);
	DestroyNiagaraSystem(NiagaraEffectId);
}

bool UKGEffectManager::GetEffectTagMask(EKGNiagaraEffectTag EffectTag, TBitArray<>& OutMask) const
{
	if (!EffectTagHiddenState.Contains(EffectTag))
	{
		return false;
	}

	OutMask = EffectTagHiddenState[EffectTag];
	return true;
}

void UKGEffectManager::KAPI_EffectManager_DetachNiagaraEffect(int32 NiagaraEffectId)
{
	this->DetachNiagaraEffect(NiagaraEffectId);
}

int32 UKGEffectManager::ScriptCreateNiagaraSystemCommon(
	const FString& NiagaraEffectPath, int32 CustomEffectID,
	const FName& InAttachComponentName, bool bCacheEvenIfDynamicMeshCtxNotFound,
	bool bNeedAttach, const FKGAttachedNiagaraSpawnInfo& AttachedSpawnInfo, const FKGUnattachedNiagaraSpawnInfo& UnattachedSpawnInfo,
	KGObjectID SpawnerID, KGEntityID SpawnerEntityID, KGEntityID InstigatorEntityID,
	bool bFollowHidden, bool bFollowSlomo, bool bFollowCameraFOV, bool bNeedFitGround,
	bool bIsPlayerEffect, bool bActivateImmediately,
	float TransparencyScale, float TotalLifeMs, uint8 NiagaraDestroyType,
	float BlendInTimeSeconds, float BlendOutTimeSeconds, float EffectPlayRate, bool bDestroyWhenSpawnerExitWorld,
	bool bBattleEffect, int32 NiagaraBusinessPriority)
{
	AActor* Spawner = KGUtils::GetActorByID(SpawnerID);
	if (!Spawner)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::ScriptCreateNiagaraSystemCommon, invalid Spawner %lld"), SpawnerID);
		return KG_INVALID_NIAGARA_SYSTEM_ID;
	}
	
	FKGPlayNiagaraParams PlayNiagaraParams;
	PlayNiagaraParams.NiagaraEffectPath = NiagaraEffectPath;
	PlayNiagaraParams.SpawnerID = SpawnerID;
	if (CustomEffectID > 0)
	{
		PlayNiagaraParams.CustomEffectID = CustomEffectID;
	}
	
	if (bNeedAttach)
	{
		PlayNiagaraParams.SetAttachedSpawnInfo(AttachedSpawnInfo);
	}
	else
	{
		PlayNiagaraParams.SetUnattachedSpawnInfo(UnattachedSpawnInfo);
	}
	
	PlayNiagaraParams.bUseSkillNiagaraSpawnInfo = false;
	PlayNiagaraParams.EffectPlayRate = EffectPlayRate;
	PlayNiagaraParams.bActivateImmediately = bActivateImmediately;
	PlayNiagaraParams.bPreCullCheck = !bIsPlayerEffect;
	PlayNiagaraParams.bIsPlayerEffect = bIsPlayerEffect;
	PlayNiagaraParams.TransparencyScale = TransparencyScale;
	PlayNiagaraParams.bFollowHidden = bFollowHidden;
	PlayNiagaraParams.bFollowSlomo = bFollowSlomo;
	PlayNiagaraParams.bFollowCameraFOV = bFollowCameraFOV;
	PlayNiagaraParams.StickGroundType = bNeedFitGround ? EKGNiagaraStickGroundType::StickToGround : EKGNiagaraStickGroundType::DoNotStickToGround;
	PlayNiagaraParams.TotalLifeMs = TotalLifeMs;
	PlayNiagaraParams.NiagaraDestroyType = static_cast<EKGNiagaraDestroyType>(NiagaraDestroyType);
	PlayNiagaraParams.BlendInTimeSeconds = BlendInTimeSeconds;
	PlayNiagaraParams.BlendOutTimeSeconds = BlendOutTimeSeconds;
	PlayNiagaraParams.bDestroyWhenSpawnerExitWorld = bDestroyWhenSpawnerExitWorld;
	PlayNiagaraParams.SpawnerEntityID = SpawnerEntityID;
	PlayNiagaraParams.InstigatorEntityID = InstigatorEntityID;
	PlayNiagaraParams.AttachComponentName = InAttachComponentName;
	PlayNiagaraParams.bCacheEvenIfDynamicMeshCtxNotFound = bCacheEvenIfDynamicMeshCtxNotFound;

	if (bBattleEffect)
	{
		PlayNiagaraParams.EffectTags.Add(EKGNiagaraEffectTag::BATTLE);
	}
	PlayNiagaraParams.NiagaraBusinessPriority = NiagaraBusinessPriority;
	
	return CreateNiagaraSystem(PlayNiagaraParams);
}

void UKGEffectManager::AssembleSpawnTrans(
	float SpawnTrans_LX, float SpawnTrans_LY, float SpawnTrans_LZ,
	bool bUseQuat, float PitchOrX, float YawOrY, float RollOrZ, float W,
	float SpawnTrans_SX, float SpawnTrans_SY, float SpawnTrans_SZ, FTransform& OutSpawnTrans)
{
	const FVector SpawnPos = FVector(SpawnTrans_LX, SpawnTrans_LY, SpawnTrans_LZ);
	checkf(!SpawnPos.ContainsNaN(), TEXT("UKGEffectManager::AssembleSpawnTrans, spawn pos contains NAN"));
	OutSpawnTrans.SetLocation(SpawnPos);

	if (!bUseQuat)
	{
		const FRotator SpawnRot(PitchOrX, YawOrY, RollOrZ);
		checkf(!SpawnRot.ContainsNaN(), TEXT("UKGEffectManager::AssembleSpawnTrans, spawn rot contains NAN"));
		OutSpawnTrans.SetRotation(SpawnRot.Quaternion());
	}
	else
	{
		FQuat SpawnQuat = FQuat(PitchOrX, YawOrY, RollOrZ, W);
		checkf(!SpawnQuat.ContainsNaN(), TEXT("UKGEffectManager::AssembleSpawnTrans, spawn quat contains NAN"));
		OutSpawnTrans.SetRotation(SpawnQuat);
	}

	const FVector SpawnScale = FVector(SpawnTrans_SX, SpawnTrans_SY, SpawnTrans_SZ);
	checkf(!SpawnScale.ContainsNaN(), TEXT("UKGEffectManager::AssembleSpawnTrans, spawn scale contains NAN"));
	OutSpawnTrans.SetScale3D(SpawnScale);
}

void UKGEffectManager::OnNiagaraLifeTimeTimerExpired(int32 NiagaraEffectId, EKGNiagaraTimeoutState State)
{
	auto* ContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!ContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::OnNiagaraLifeTimeTimerExpired, cannot find NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}
	
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::OnNiagaraLifeTimeTimerExpired, %s, State %d"), *ContextPtr->ToString(), static_cast<int32>(State));

	if (State == EKGNiagaraTimeoutState::Deactivate)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::OnNiagaraLifeTimeTimerExpired, deactivate niagara %d"), NiagaraEffectId);
		DeactivateNiagaraSystem(NiagaraEffectId);
	}
	else if (State == EKGNiagaraTimeoutState::Destroy)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::OnNiagaraLifeTimeTimerExpired, destroy niagara %d"), NiagaraEffectId);
		InternalDestroyNiagaraSystem(NiagaraEffectId);
	}
}

void UKGEffectManager::UpdateAllNiagaraFloatParamBySpawnerId(KGObjectID SpawnerId, const FName& ParamName, float InVal)
{
	if (!SpawnerIdToEffectIds.Contains(SpawnerId))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateAllNiagaraFloatParamBySpawnerId, cannot find spawner id %lld"), SpawnerId);
		return;
	}

	for (auto EffectId : SpawnerIdToEffectIds[SpawnerId])
	{
		UpdateNiagaraFloatParam(EffectId, ParamName, InVal);
	}
}

void UKGEffectManager::UpdateNiagaraFloatParam(int32 NiagaraEffectId, const FName& ParamName, float InVal)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(UpdateNiagaraFloatParam, NiagaraEffectId, ParamName, InVal);
}

void UKGEffectManager::UpdateNiagaraVec2Param(int32 NiagaraEffectId, const FName& ParamName, float InX, float InY)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(UpdateNiagaraVec2Param, NiagaraEffectId, ParamName, InX, InY);
}

void UKGEffectManager::UpdateNiagaraVec3Param(int32 NiagaraEffectId, const FName& ParamName, float InX, float InY, float InZ)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(UpdateNiagaraVec3Param, NiagaraEffectId, ParamName, InX, InY, InZ);
}

void UKGEffectManager::KAPI_EffectManager_UpdateNiagaraTextureParam(int32 NiagaraEffectId, const FName& ParamName, const FString& TexturePath)
{
	if (TexturePath.IsEmpty())
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::KAPI_EffectManager_UpdateNiagaraTextureParam, empty texture path, %d"), NiagaraEffectId);
		return;
	}
	
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(UpdateNiagaraTextureParam, NiagaraEffectId, ParamName, TexturePath);
}

void UKGEffectManager::KAPI_EffectManager_RemoveNiagaraTextureParam(int32 NiagaraEffectId, const FName& ParamName)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(RemoveNiagaraTextureParam, NiagaraEffectId, ParamName);
}

void UKGEffectManager::UpdateAllNiagaraLinearColorParamBySpawnerId(KGObjectID SpawnerId, const FName& ParamName, float InR, float InG, float InB, float InA)
{
	if (!SpawnerIdToEffectIds.Contains(SpawnerId))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateAllNiagaraLinearColorParamBySpawnerId, cannot find spawner id %lld"), SpawnerId);
		return;
	}

	for (auto EffectId : SpawnerIdToEffectIds[SpawnerId])
	{
		UpdateNiagaraLinearColorParam(EffectId, ParamName, InR, InG, InB, InA);
	}
}

void UKGEffectManager::UpdateAllSpiritualVisionMeshColorParam(KGObjectID SpawnerId, const FName& ParamName, bool bEnableSpiritualVision)
{
	if (!SpawnerIdToEffectIds.Contains(SpawnerId))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateAllSpiritualVisionMeshColorParam, cannot find spawner id %lld"), SpawnerId);
		return;
	}

	for (auto EffectId : SpawnerIdToEffectIds[SpawnerId])
	{
		FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(EffectId);
		if (!UpdateContextPtr)
		{
			UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::UpdateAllSpiritualVisionMeshColorParam, cannot find NiagaraEffectId %d"), EffectId);
			continue;
		}

		UpdateContextPtr->UpdateSpiritualVisionColorParams(ParamName, bEnableSpiritualVision);
	}
}

void UKGEffectManager::UpdateNiagaraLinearColorParam(int32 NiagaraEffectId, const FName& ParamName, float InR, float InG, float InB, float InA)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(UpdateNiagaraLinearColorParam, NiagaraEffectId, ParamName, InR, InG, InB, InA);
}

void UKGEffectManager::UpdateNiagaraFollowActor(int32 NiagaraEffectId, const FName& ParamName, KGObjectID FollowActorId, bool bAbsoluteNiagaraRotationInFollow)
{
	FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!UpdateContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::UpdateNiagaraFollowActor, cannot find NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}

	BindEffectToSpawner(NiagaraEffectId, FollowActorId, false, EKGNiagaraBehaviorOnExtraSpawnerDestroy::DestroyEffect,
		EKGNiagaraHiddenReason::OWNER_SET_HIDDEN, *UpdateContextPtr);
	UpdateContextPtr->UpdateNiagaraFollowActor(ParamName, FollowActorId, bAbsoluteNiagaraRotationInFollow);
	UpdateTickableNiagaraIds(*UpdateContextPtr);
}

void UKGEffectManager::UpdateNiagaraCameraArmLengthParam(int32 NiagaraEffectId, const FName& ParamName)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(UpdateNiagaraCameraArmLengthParam, NiagaraEffectId, ParamName);
}

void UKGEffectManager::UpdatePositionWithArcParams(int32 NiagaraEffectId, const FName& ParamName, float Radius, float StartRelativeYaw, float RotateAngle, float Duration)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(UpdatePositionWithArcParams, NiagaraEffectId, ParamName, Radius, StartRelativeYaw, RotateAngle, Duration);
}

void UKGEffectManager::DetachNiagaraEffect(int32 NiagaraEffectId)
{
	FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!UpdateContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::DetachNiagaraEffect: Cannot find NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}
	
	if (!UpdateContextPtr->PlayNiagaraParams.NeedAttach())
	{
		UE_LOG(LogEM, Log,
			TEXT("UKGEffectManager::DetachNiagaraEffect, niagara do not need attach or invalid attach component %s"),
			*UpdateContextPtr->ToString());
		return;
	}

	InternalDetachNiagaraEffect(*UpdateContextPtr);
}

void UKGEffectManager::InternalDetachNiagaraEffect(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext)
{
	auto& PlayNiagaraParams = InOutNiagaraUpdateContext.PlayNiagaraParams;
	if (!PlayNiagaraParams.NeedAttach())
	{
		UE_LOG(LogEM, Log,
			TEXT("UKGEffectManager::DetachNiagaraEffect, niagara do not need attach or invalid attach component %s"),
			*InOutNiagaraUpdateContext.ToString());
		return;
	}
	
	// 特效没有加载完成就 Detach 了
	if (InOutNiagaraUpdateContext.NiagaraComponent == nullptr)
	{
		// 等待 Niagara OnActivate 时，执行真正的 Detach 操作。
		InOutNiagaraUpdateContext.bNeedDetachDeferred = true;
	}
	else
	{
		InOutNiagaraUpdateContext.DetachNiagaraEffect();
	}
}

bool UKGEffectManager::UpdateLinearSampleParamTargetValue(
	int32 NiagaraEffectId, const FName& ParamName, float TargetVal, bool bUseNewDuration, float InNewDuration)
{
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!NiagaraUpdateContextPtr)
	{
		// 有可能特效会被提前culling, 这里日志等级从error调整为warning
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::UpdateLinearSampleParamTargetValue, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return false;
	}
	return NiagaraUpdateContextPtr->UpdateLinearSampleParamTargetValue(ParamName, TargetVal, bUseNewDuration, InNewDuration);
}

void UKGEffectManager::AddOrUpdateLinearSampleParamTargetValueByEffectTag(
	EKGNiagaraEffectTag EffectTag, const FName& ParamName, float StartValue, float TargetValue, bool bUseNewDuration, float NewDuration)
{
	auto* EffectIDsPtr = EffectTagToEffectIds.Find(EffectTag);
	if (!EffectIDsPtr)
	{
		return;
	}
	
	for (int32 EffectId : *EffectIDsPtr)
	{
		AddOrUpdateLinearSampleParamTargetValue(EffectId, ParamName, StartValue, TargetValue, bUseNewDuration, NewDuration);
	}
}

void UKGEffectManager::AddOrUpdateLinearSampleParamTargetValue(
	int32 NiagaraEffectId, const FName& ParamName, float StartValue, float TargetValue, bool bUseNewDuration, float NewDuration)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(AddOrUpdateLinearSampleParamTargetValue, NiagaraEffectId, ParamName, StartValue, TargetValue, bUseNewDuration, NewDuration);
}

void UKGEffectManager::FinishLinearSampleParamTask(int32 NiagaraEffectId, const FName& ParamName)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(FinishLinearSampleParamTask, NiagaraEffectId, ParamName);
}

void UKGEffectManager::KAPI_EffectManager_BlendOutNiagaraByNiagaraParam(
	int32 NiagaraEffectId, const FString& CurvePath, const FName& ParamName, float StartVal, float EndVal, float Duration)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(BlendOutNiagaraByNiagaraParam, NiagaraEffectId, CurvePath, ParamName, StartVal, EndVal, Duration);
}

void UKGEffectManager::KAPI_EffectManager_SetNiagaraFollowActorRotation(int32 NiagaraEffectId)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraFollowActorRotation, NiagaraEffectId);
}

void UKGEffectManager::KAPI_EffectManager_UpdateParamByHeightDiff(int32 NiagaraEffectId, const FString& CurvePath, const FName& ParamName, float VisibilityChangeBlendTime, float HeightDiffHalfLifeTime)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(UpdateParamByHeightDiff, NiagaraEffectId, CurvePath, ParamName, VisibilityChangeBlendTime, HeightDiffHalfLifeTime);
}

void UKGEffectManager::KAPI_EffectManager_SetNiagaraStickOnGround(int32 NiagaraEffectId, float UpCheckDistance, float DownCheckDistance, bool bUseNiagaraAsPivotPos)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraStickOnGround, NiagaraEffectId, UpCheckDistance, DownCheckDistance, bUseNiagaraAsPivotPos);
}

void UKGEffectManager::UpdateNiagaraPlayRateBySpawnerID(KGActorID SpawnerID)
{
	if (!SpawnerIdToEffectIds.Contains(SpawnerID))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateNiagaraPlayRateBySpawnerID, cannot find spawner id %lld"), SpawnerID);
		return;
	}

	for (auto EffectId : SpawnerIdToEffectIds[SpawnerID])
	{
		FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(EffectId);
		if (!UpdateContextPtr)
		{
			UE_LOG(LogEM, Error, TEXT("UKGEffectManager::UpdateNiagaraPlayRateBySpawnerID, cannot find NiagaraEffectId %d"), EffectId);
			continue;
		}

		if (UpdateContextPtr->PlayNiagaraParams.bFollowSlomo)
		{
			UpdateContextPtr->UpdateNiagaraPlayRate();	
		}
	}
}

void UKGEffectManager::KAPI_EffectManager_SetEffectAudio(int32 NiagaraEffectId, const FString& AudioName)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetEffectAudio, NiagaraEffectId, AudioName);
}

void UKGEffectManager::KAPI_EffectManager_SetNiagaraParamByEffectID(int32 NiagaraEffectId, uint32 ParamID)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraParamByEffectID, NiagaraEffectId, ParamID);
}

void UKGEffectManager::KAPI_EffectManager_ChangeNiagaraAttachSocket(int32 NiagaraEffectId, const FName& NewSocketName)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(ChangeAttachSocket, NiagaraEffectId, NewSocketName);
}

void UKGEffectManager::KAPI_EffectManager_SetActorForceUseAbsoluteScale(KGActorID ActorID, bool bForceUseAbsoluteScale)
{
	const bool bOldForceUseAbsoluteScale = ForceUseAbsoluteScaleActors.Contains(ActorID);
	if (bOldForceUseAbsoluteScale == bForceUseAbsoluteScale)
	{
		return;
	}
	
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::KAPI_EffectManager_SetActorForceUseAbsoluteScale, Actor %s(%lld), bForceUseAbsoluteScale %d"),
	 	*GetNameSafe(KGUtils::GetActorByID(ActorID)), ActorID, bForceUseAbsoluteScale);
	if (bForceUseAbsoluteScale)
	{
		ForceUseAbsoluteScaleActors.Add(ActorID);
	}
	else
	{
		ForceUseAbsoluteScaleActors.Remove(ActorID);
	}
	
	if (!SpawnerIdToEffectIds.Contains(ActorID))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::KAPI_EffectManager_SetActorForceUseAbsoluteScale, cannot find spawner id %lld"), ActorID);
		return;
	}

	for (auto EffectId : SpawnerIdToEffectIds[ActorID])
	{
		FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(EffectId);
		if (!UpdateContextPtr)
		{
			UE_LOG(LogEM, Error, TEXT("UKGEffectManager::KAPI_EffectManager_SetActorForceUseAbsoluteScale, cannot find NiagaraEffectId %d"), EffectId);
			continue;
		}
		
		// 有可能是link target
		if (UpdateContextPtr->PlayNiagaraParams.SpawnerID == ActorID)
		{
			UpdateContextPtr->SetForceUseAbsoluteScale(bForceUseAbsoluteScale);	
		}
	}
}

void UKGEffectManager::KAPI_EffectManager_SetNiagaraFollowSpawnerHiddenState(uint32 NiagaraEffectId, bool bFollowSpawnerHiddenState)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraFollowSpawnerHiddenState, NiagaraEffectId, bFollowSpawnerHiddenState);
}

void UKGEffectManager::SetNiagaraRenderCustomDepthBySpawnerId(KGObjectID SpawnerId, bool bEnableCustomDepth, float CustomDepthStencilValue)
{
	if (!SpawnerIdToEffectIds.Contains(SpawnerId))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::SetNiagaraRenderCustomDepthBySpawnerId, cannot find spawner id %lld"), SpawnerId);
		return;
	}

	for (auto EffectId : SpawnerIdToEffectIds[SpawnerId])
	{
		FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(EffectId);
		if (!UpdateContextPtr)
		{
			UE_LOG(LogEM, Error, TEXT("UKGEffectManager::SetNiagaraRenderCustomDepthBySpawnerId, cannot find NiagaraEffectId %d"), EffectId);
			continue;
		}

		UpdateContextPtr->SetCustomDepthInfo(bEnableCustomDepth, CustomDepthStencilValue);
	}
}

void UKGEffectManager::ForceSetNiagaraRenderCustomDepthBySpawnerId(KGObjectID SpawnerId, bool bEnableCustomDepth, float CustomDepthStencilValue)
{
	if (!SpawnerIdToEffectIds.Contains(SpawnerId))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::ForceSetNiagaraRenderCustomDepthBySpawnerId, cannot find spawner id %lld"), SpawnerId);
		return;
	}

	for (auto EffectId : SpawnerIdToEffectIds[SpawnerId])
	{
		KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetForceCustomDepthInfo, EffectId, bEnableCustomDepth, CustomDepthStencilValue);
	}
}

void UKGEffectManager::RevertForceNiagaraCustomDepthControlBySpawnerId(KGObjectID SpawnerId)
{
	if (!SpawnerIdToEffectIds.Contains(SpawnerId))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::RevertForceNiagaraCustomDepthControlBySpawnerId, cannot find spawner id %lld"), SpawnerId);
		return;
	}

	for (auto EffectId : SpawnerIdToEffectIds[SpawnerId])
	{
		KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(RevertForceCustomDepthInfo, EffectId);
	}
}

void UKGEffectManager::UpdateNiagaraHiddenState(int32 NiagaraEffectId, bool bHidden, uint8 HiddenReason, bool bUseBlendTime, float BlendTimeSeconds)
{
	check(HiddenReason < KG_NIAGARA_MAX_HIDDEN_REASONS);
	
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!NiagaraUpdateContextPtr)
	{
		// 特效可能会被culling, 日志等级改为warning
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::UpdateNiagaraHiddenState, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}

	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateNiagaraHiddenState, Niagara %s, bHidden %d, HiddenReason %d"),
		*NiagaraUpdateContextPtr->ToString(), bHidden, HiddenReason);

	if (bUseBlendTime && BlendTimeSeconds > UE_KINDA_SMALL_NUMBER)
	{
		InternalUpdateNiagaraHiddenStateWithBlendTime(*NiagaraUpdateContextPtr, bHidden, HiddenReason, BlendTimeSeconds);
	}
	else
	{
		InternalUpdateNiagaraHiddenState(*NiagaraUpdateContextPtr, bHidden, HiddenReason, false);
	}
}

void UKGEffectManager::UpdateNiagaraHiddenStateByEffectTag(int32 EffectTag, bool bHidden, uint8 HiddenReason, bool bUseBlendTime, float BlendTimeSeconds)
{
	check(HiddenReason < KG_NIAGARA_MAX_HIDDEN_REASONS);
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateNiagaraHiddenStateByEffectTag, EffectTag %d, bHidden %d, HiddenReason %d"),
		EffectTag, bHidden, HiddenReason);
	
	const auto EffectTagEnum = static_cast<EKGNiagaraEffectTag>(EffectTag);
	if (!EffectTagHiddenState.Contains(EffectTagEnum))
	{
		TBitArray<> EffectHiddenStates(false, KG_NIAGARA_MAX_HIDDEN_REASONS);
		EffectTagHiddenState.Add(EffectTagEnum, EffectHiddenStates);
	}

	EffectTagHiddenState[EffectTagEnum][HiddenReason] = bHidden;
	
	if (auto* EffectIdsPtr = EffectTagToEffectIds.Find(EffectTagEnum))
	{
		for (const auto EffectId : *EffectIdsPtr)
		{
			UpdateNiagaraHiddenState(EffectId, bHidden, HiddenReason, bUseBlendTime, BlendTimeSeconds);
		}
	}
}

void UKGEffectManager::UpdateEffectVisibilityBySpawnerID(KGObjectID SpawnerId, bool bVisible, uint8 HiddenReason)
{
	if (!SpawnerIdToEffectIds.Contains(SpawnerId))
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::UpdateEffectVisibilityBySpawnerID, cannot find spawner id %lld"), SpawnerId);
		return;
	}

	for (auto EffectId : SpawnerIdToEffectIds[SpawnerId])
	{
		FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(EffectId);
		if (!NiagaraUpdateContextPtr)
		{
			UE_LOG(LogEM, Error, TEXT("UKGEffectManager::UpdateEffectVisibilityBySpawnerID, invalid NiagaraEffectId %d"), EffectId);
			continue;
		}

		const bool bIsEffectSpawner = (SpawnerId == NiagaraUpdateContextPtr->PlayNiagaraParams.SpawnerID);
		bool bShouldFollowHidden = NiagaraUpdateContextPtr->PlayNiagaraParams.bFollowHidden;
		if (bIsEffectSpawner)
		{
			bShouldFollowHidden &= NiagaraUpdateContextPtr->bFollowSpawnerHiddenState;
		}
		
		UE_LOG(LogEM, Log,
			TEXT("UKGEffectManager::UpdateEffectVisibilityBySpawnerID, set effect visibility, FollowHidden: %d, OldVisible: %d, NewVisible: %d, Reason: %d, %s, %s, %lld"),
			bShouldFollowHidden, NiagaraUpdateContextPtr->HiddenMask == 0,
			bVisible, HiddenReason, *NiagaraUpdateContextPtr->ToString(), *GetNameSafe(KGUtils::GetActorByID(SpawnerId)), SpawnerId);

		if (bShouldFollowHidden)
		{
			InternalUpdateNiagaraHiddenState(*NiagaraUpdateContextPtr, !bVisible, HiddenReason, false);
		}
	}
}

void UKGEffectManager::UpdateSystemUserVariableMeshComponent(
	int32 NiagaraEffectId, const FString& ParamName, KGObjectID MeshCompID, const TArray<FName>& SkeletalMeshFilterBones,
	bool bUseCloneMeshCompOnSystemUserVariableMeshComponent, bool bUseNiagaraComponentTransform)
{
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!NiagaraUpdateContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::OverrideSystemUserVariableMeshComponent, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}
	NiagaraUpdateContextPtr->UpdateSystemUserVariableMeshComponent(ParamName, MeshCompID, SkeletalMeshFilterBones,
		bUseCloneMeshCompOnSystemUserVariableMeshComponent, bUseNiagaraComponentTransform);
	if (!bUseCloneMeshCompOnSystemUserVariableMeshComponent)
	{
		BindEffectToLinkedComponent(MeshCompID, NiagaraEffectId, EKGNiagaraBehaviorOnExtraSpawnerDestroy::DestroyEffect,
			EKGNiagaraHiddenReason::OWNER_SET_HIDDEN, *NiagaraUpdateContextPtr);	
	}
}

int32 UKGEffectManager::SetNiagaraSplineLinkToComponent(
	int32 NiagaraEffectId, const FString& SplineBPPath, const FString& SplineUserVarName, KGObjectID TargetComponentId, FName TargetSocketName,
	EKGNiagaraBehaviorOnExtraSpawnerDestroy Behavior, EKGNiagaraHiddenReason HiddenReason)
{
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!NiagaraUpdateContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::SetNiagaraSplineLinkToComponent, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return KG_INVALID_UPDATE_TASK_ID;
	}

	FKGNiagaraUpdateSplineTargetParams TargetParams;
	TargetParams.Method = EKGNiagaraUpdateSplineTargetMethod::BindToTargetComponent;
	TargetParams.TargetComponentId = TargetComponentId;
	TargetParams.TargetSocketName = TargetSocketName;

	const auto TaskID = NiagaraUpdateContextPtr->SetNiagaraSplineLink(SplineBPPath, SplineUserVarName, TargetParams);
	BindEffectToLinkedComponent(TargetComponentId, NiagaraEffectId, Behavior, HiddenReason, *NiagaraUpdateContextPtr);
	UpdateTickableNiagaraIds(*NiagaraUpdateContextPtr);
	return TaskID;
}

int32 UKGEffectManager::SetNiagaraSplineLinkToLocation(
	int32 NiagaraEffectId, const FString& SplineBPPath, const FString& SplineUserVarName, float RelativeYaw,
	float TargetLocationX, float TargetLocationY, float TargetLocationZ, bool bCastToGround)
{
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!NiagaraUpdateContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::SetNiagaraSplineLinkToPoint, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return KG_INVALID_UPDATE_TASK_ID;
	}

	FKGNiagaraUpdateSplineTargetParams TargetParams;
	TargetParams.Method = bCastToGround ?
		EKGNiagaraUpdateSplineTargetMethod::BindToLocationOnGround :
		EKGNiagaraUpdateSplineTargetMethod::BindToLocation;
	TargetParams.TargetLocation.Set(TargetLocationX, TargetLocationY, TargetLocationZ);
	TargetParams.RelativeYaw = RelativeYaw;

	int32 TaskId = NiagaraUpdateContextPtr->SetNiagaraSplineLink(SplineBPPath, SplineUserVarName, TargetParams);
	
	UpdateTickableNiagaraIds(*NiagaraUpdateContextPtr);

	return TaskId;
}

int32 UKGEffectManager::UpdateNiagaraSplineLinkTargetLocation(int32 NiagaraEffectId, int32 UpdateTaskId, float Yaw, float TargetLocationX, float TargetLocationY, float TargetLocationZ)
{
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!NiagaraUpdateContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::SetNiagaraSplineLinkTargetLocation, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return KG_INVALID_UPDATE_TASK_ID;
	}

	FVector TargetLocation(TargetLocationX, TargetLocationY, TargetLocationZ);
	if (TargetLocation.ContainsNaN())
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::SetNiagaraSplineLinkTargetLocation, invalid TargetLocation %s, %d"),
			*TargetLocation.ToString(), NiagaraEffectId);
		return KG_INVALID_UPDATE_TASK_ID;
	}
	
	return NiagaraUpdateContextPtr->SetNiagaraSplineLinkTargetLocation(UpdateTaskId, Yaw, TargetLocation);
}

void UKGEffectManager::KAPI_EffectManager_UpdateNiagaraSplineLinkTargetComponent(int32 NiagaraEffectId, int32 UpdateTaskId,
	KGObjectID TargetComponentId, FName TargetSocketName, EKGNiagaraBehaviorOnExtraSpawnerDestroy Behavior, EKGNiagaraHiddenReason HiddenReason)
{
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!NiagaraUpdateContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::KAPI_EffectManager_UpdateNiagaraSplineLinkTargetComponent, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}

	if (!NiagaraUpdateContextPtr->UpdateNiagaraSplineLinkTargetComponent(UpdateTaskId, TargetComponentId, TargetSocketName))
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::KAPI_EffectManager_UpdateNiagaraSplineLinkTargetComponent, failed to update target component, %s"),
			*NiagaraUpdateContextPtr->ToString());
		return;
	}

	ClearAllExtraSpawners(*NiagaraUpdateContextPtr);
	BindEffectToLinkedComponent(TargetComponentId, NiagaraEffectId, Behavior, HiddenReason, *NiagaraUpdateContextPtr);
}

void UKGEffectManager::AddLinearSampleVectorParams(
	int32 NiagaraEffectId, const FName& ParamName, float StartX, float StartY, float StartZ,
	float EndX, float EndY, float EndZ, float Duration, bool bUseNiagaraAccumulatedTime)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(AddLinearSampleVectorParams, NiagaraEffectId, ParamName, StartX, StartY, StartZ, EndX, EndY, EndZ, Duration, bUseNiagaraAccumulatedTime);
}

void UKGEffectManager::AddLinearSampleFloatParams(
	int32 NiagaraEffectId, const FName& ParamName, float StartVal, float EndVal, float Duration, bool bUseNiagaraAccumulatedTime)
{
	if (Duration < UE_KINDA_SMALL_NUMBER)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::AddLinearSampleFloatParams, invalid duration %f, %d"),
			Duration, NiagaraEffectId);
		return;
	}
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(AddLinearSampleFloatParams, NiagaraEffectId, ParamName, StartVal, EndVal, Duration, bUseNiagaraAccumulatedTime);
}

void UKGEffectManager::AddFloatCurveParams(
	int32 NiagaraEffectId, FName ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(AddFloatCurveParams, NiagaraEffectId, ParamName, CurvePath, bNeedRemap, RemapTime, false, false);
}

void UKGEffectManager::SetNiagaraRenderInMainPass(int32 EffectID, bool bRenderInMainPass)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraRenderInMainPass, EffectID, bRenderInMainPass);
}

void UKGEffectManager::SetNiagaraTranslucentSortPriority(int32 EffectID, int32 TranslucentSortPriority)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraTranslucentSortPriority, EffectID, TranslucentSortPriority);
}

void UKGEffectManager::SetNiagaraTranslucencySortDistanceOffset(int32 EffectID, int32 TranslucencySortDistanceOffset)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraTranslucencySortDistanceOffset, EffectID, TranslucencySortDistanceOffset);
}

void UKGEffectManager::AppendNiagaraExtraEffectTags(int32 EffectID, const TArray<int32>& ExtraEffectTags)
{
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(EffectID);
	if (!NiagaraUpdateContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::SetNiagaraExtraEffectTags, invalid NiagaraEffectId %d"), EffectID);
		return;
	}

	for (const auto EffectTag : ExtraEffectTags)
	{
		const auto EffectTagEnum = static_cast<EKGNiagaraEffectTag>(EffectTag);
		NiagaraUpdateContextPtr->PlayNiagaraParams.EffectTags.Add(EffectTagEnum);
		auto& EffectIds = EffectTagToEffectIds.FindOrAdd(EffectTagEnum);
		EffectIds.Add(NiagaraUpdateContextPtr->NiagaraEffectId);
	}
}

void UKGEffectManager::AppendNiagaraExtraEffectTag(int32 EffectID, int32 ExtraEffectTag)
{
	AppendNiagaraExtraEffectTags(EffectID, {ExtraEffectTag});
}

void UKGEffectManager::KAPI_EffectManager_EnableNiagaraEffectTypeDebugCheck(int32 EffectID, int32 SkillIdDebugUsage)
{
#if KG_EFFECTMANAGER_ENABLE_STAT
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(EffectID);
	if (!NiagaraUpdateContextPtr)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::EnableNiagaraEffectTypeDebugCheck, invalid NiagaraEffectId %d"), EffectID);
		return;
	}
	
	NiagaraUpdateContextPtr->bEnableNiagaraEffectTypeDebugCheck = true;
	NiagaraUpdateContextPtr->SkillIdDebugUsage = SkillIdDebugUsage;
#endif
}

void UKGEffectManager::SetNiagaraEnableSpiritualVisionMeshColorChange(int32 EffectID, float InR, float InG, float InB, float InA)
{
	FLinearColor Color(InR, InG, InB, InA);
	check(!FVector4(Color).ContainsNaN());
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetSpiritualVisionColor, EffectID, true, Color);
}

void UKGEffectManager::SetNiagaraFaceToLocation(int32 NiagaraEffectId, float InLocationX, float InLocationY)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraFaceToLocation, NiagaraEffectId, InLocationX, InLocationY);
}

void UKGEffectManager::KAPI_EffectManager_SetNiagaraFaceToActor(int32 NiagaraEffectId, KGObjectID FacingTargetActorId, EKGNiagaraFaceToActorRotationType RotationType)
{
	AActor* TargetActor = KGUtils::GetActorByID(FacingTargetActorId);
	if (!TargetActor)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::KAPI_EffectManager_SetNiagaraFaceToActor, invalid target actor, %d"), NiagaraEffectId);
		return;
	}
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraFaceToActor, NiagaraEffectId, TargetActor, RotationType);
}

void UKGEffectManager::SetNiagaraFaceToCamera(int32 NiagaraEffectId, EKGNiagaraFaceToActorRotationType RotationType)
{
	APlayerCameraManager* PlayerCameraManager = UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0);
	if (!PlayerCameraManager)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::KAPI_EffectManager_SetNiagaraFaceToCamera, invalid PlayerCameraManager %d"), NiagaraEffectId);
		return;
	}
	
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraFaceToActor, NiagaraEffectId, PlayerCameraManager, RotationType);
}

void UKGEffectManager::SetNiagaraFollowCameraFOV(int32 NiagaraEffectId)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraFollowCameraFOV, NiagaraEffectId);
}

void UKGEffectManager::SetNiagaraRenderCustomDepth(int32 NiagaraEffectId, bool bEnableCustomDepth, int32 CustomDepthStencilValue)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetCustomDepthInfo, NiagaraEffectId, bEnableCustomDepth, CustomDepthStencilValue);
}

void UKGEffectManager::SetNiagaraComponentTags(int32 NiagaraEffectId, const TArray<FName>& ComponentTags)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetNiagaraComponentTags, NiagaraEffectId, ComponentTags);
}

void UKGEffectManager::KAPI_EffectManager_SetParticleColorScaleUpdateCurve(int32 NiagaraEffectId, const FString& CurvePath, float Duration)
{
	KG_CALL_NIAGARA_UPDATE_CONTEXT_FUNC(SetParticleColorScaleUpdateCurve, NiagaraEffectId, CurvePath, Duration);
}

bool UKGEffectManager::GetSurfaceCdInfo(const FName& EffectPath, float& OutCdTimeSeconds)
{
	if (SurfaceCdInfo.Contains(EffectPath))
	{
		OutCdTimeSeconds = SurfaceCdInfo[EffectPath];
		return true;
	}

	return false;
}

int32 UKGEffectManager::GenerateEffectId()
{
	return GenerateNiagaraEffectId();
}

void UKGEffectManager::KAPI_EffectManager_SetNiagaraQualityInfo(
	EKGNiagaraQualityLevel InPlayerNiagaraQualityLevel, 
	EKGNiagaraParticleColorScaleLevel InPlayerParticleColorScaleLevel, 
	EKGNiagaraQualityLevel InOtherPlayerNiagaraQualityLevel, 
	EKGNiagaraParticleColorScaleLevel InOtherPlayerParticleColorScaleLevel,
	EKGNiagaraQualityLevel InEnvNiagaraQualityLevel, 
	EKGNiagaraParticleColorScaleLevel InEnvParticleColorScaleLevel)
{
	SCOPED_NAMED_EVENT(UKGEffectManager_SetNiagaraQualityInfo, FColor::Red);
	
	if (PlayerNiagaraQualityLevel != InPlayerNiagaraQualityLevel)
	{
		SetQualityLevelByEffectSettings(EKGNiagaraEffectTag::MAIN_PLAYER, InPlayerNiagaraQualityLevel);
	}
	
	if (OtherPlayerNiagaraQualityLevel != InOtherPlayerNiagaraQualityLevel)
	{
		SetQualityLevelByEffectSettings(EKGNiagaraEffectTag::OTHER_PLAYER, InOtherPlayerNiagaraQualityLevel);
	}
	
	if (EnvNiagaraQualityLevel != InEnvNiagaraQualityLevel)
	{
		SetQualityLevelByEffectSettings(EKGNiagaraEffectTag::ENV, InEnvNiagaraQualityLevel);
		
		SCOPED_NAMED_EVENT(UKGEffectManager_SetNiagaraQualityInfo_SetNativeNiagaraQualityLevel, FColor::Red);
		for (auto& NativeNiagaraComponent : NativeEnvNiagaraComponents)
		{
			if (!NativeNiagaraComponent.IsValid())
			{
				continue;
			}
			
			NativeNiagaraComponent->SetComponentQualityLevel(static_cast<int32>(InEnvNiagaraQualityLevel));
		}
	}
	
	PlayerTransparencyScaleFactor = (static_cast<int8>(InPlayerParticleColorScaleLevel) + 1.0f) / 4.0f;
	if (PlayerParticleColorScaleLevel != InPlayerParticleColorScaleLevel)
	{
		SetTransparencyScaleByEffectSettings(EKGNiagaraEffectTag::MAIN_PLAYER, PlayerTransparencyScaleFactor);
	}
	
	OtherPlayerTransparencyScaleFactor = (static_cast<int8>(InOtherPlayerParticleColorScaleLevel) + 1.0f) / 4.0f;
	if (OtherPlayerParticleColorScaleLevel != InOtherPlayerParticleColorScaleLevel)
	{
		SetTransparencyScaleByEffectSettings(EKGNiagaraEffectTag::OTHER_PLAYER, OtherPlayerTransparencyScaleFactor);
		
		const bool bOldHiddenOtherPlayerEffect = OtherPlayerParticleColorScaleLevel == EKGNiagaraParticleColorScaleLevel::Low;
		const bool bNewHiddenOtherPlayerEffect = InOtherPlayerParticleColorScaleLevel == EKGNiagaraParticleColorScaleLevel::Low;
		if (bOldHiddenOtherPlayerEffect != bNewHiddenOtherPlayerEffect)
		{
			UE_LOG(LogEM, Log, TEXT("UKGEffectManager::KAPI_EffectManager_SetNiagaraQualityInfo, update other player effect hidden state from %d to %d"),
				bOldHiddenOtherPlayerEffect, bNewHiddenOtherPlayerEffect);
			UpdateNiagaraHiddenStateByEffectTag(
				static_cast<int32>(EKGNiagaraEffectTag::OTHER_PLAYER_LOW_QUALITY), bNewHiddenOtherPlayerEffect, 
				static_cast<uint8>(EKGNiagaraHiddenReason::OTHER_PLAYER_QUALITY_LEVEL_LOW), false, 0.0f);
		}
	}
	
	EnvTransparencyScaleFactor = (static_cast<int8>(InEnvParticleColorScaleLevel) + 1.0f) / 4.0f;
	if (EnvParticleColorScaleLevel != InEnvParticleColorScaleLevel)
	{
		SetTransparencyScaleByEffectSettings(EKGNiagaraEffectTag::ENV, EnvTransparencyScaleFactor);
		
		SCOPED_NAMED_EVENT(UKGEffectManager_SetNiagaraQualityInfo_SetNativeNiagaraTransparencyScale, FColor::Red);
		for (auto& NativeNiagaraComponent : NativeEnvNiagaraComponents)
		{
			if (!NativeNiagaraComponent.IsValid())
			{
				continue;
			}
			
			NativeNiagaraComponent->SetParticleColorScale(EnvTransparencyScaleFactor);
		}
	}
	
	PlayerNiagaraQualityLevel = InPlayerNiagaraQualityLevel;
	PlayerParticleColorScaleLevel = InPlayerParticleColorScaleLevel;
	OtherPlayerNiagaraQualityLevel = InOtherPlayerNiagaraQualityLevel;
	OtherPlayerParticleColorScaleLevel = InOtherPlayerParticleColorScaleLevel;
	EnvNiagaraQualityLevel = InEnvNiagaraQualityLevel;
	EnvParticleColorScaleLevel = InEnvParticleColorScaleLevel;
}

void UKGEffectManager::InternalSetLinearSampleParticleColorScaleUpdateTask(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext, bool bBlendIn, float Duration, bool bInitBlendIn)
{
	InOutNiagaraUpdateContext.SetLinearSampleParticleColorScaleUpdateTask(bBlendIn, Duration, bInitBlendIn);
	UpdateTickableNiagaraIds(InOutNiagaraUpdateContext);
}

void UKGEffectManager::SetTransparencyScaleByEffectSettings(EKGNiagaraEffectTag EffectTag, float TransparencyScaleBySettings)
{
	SCOPED_NAMED_EVENT(UKGEffectManager_SetTransparencyScaleByEffectSettings, FColor::Red);
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::SetTransparencyScaleByEffectSettings, EffectTag %d, TransparencyScaleBySettings %f"),
		EffectTag, TransparencyScaleBySettings);
	auto* EffectIDsPtr = EffectTagToEffectIds.Find(EffectTag);
	if (!EffectIDsPtr)
	{
		return;
	}
	
	for (const auto EffectID : *EffectIDsPtr)
	{
		auto* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(EffectID);
		if (!NiagaraUpdateContextPtr)
		{
			continue;
		}
		
		if (FMath::IsNearlyEqual(NiagaraUpdateContextPtr->TransparencyScaleBySettings, TransparencyScaleBySettings))
		{
			continue;
		}
		
		NiagaraUpdateContextPtr->TransparencyScaleBySettings = TransparencyScaleBySettings;
		NiagaraUpdateContextPtr->RefreshTransparencyScale();
	}
}

void UKGEffectManager::SetQualityLevelByEffectSettings(EKGNiagaraEffectTag EffectTag, EKGNiagaraQualityLevel QualityLevelBySettings)
{
	SCOPED_NAMED_EVENT(UKGEffectManager_SetQualityLevelByEffectSettings, FColor::Red);
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::SetQualityLevelByEffectSettings, EffectTag %d, QualityLevelBySettings %d"),
		EffectTag, QualityLevelBySettings);
	auto* EffectIDsPtr = EffectTagToEffectIds.Find(EffectTag);
	if (!EffectIDsPtr)
	{
		return;
	}
	
	auto NewQualityLevel = static_cast<int8>(QualityLevelBySettings);
	for (const auto EffectID : *EffectIDsPtr)
	{
		auto* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(EffectID);
		if (!NiagaraUpdateContextPtr)
		{
			continue;
		}
		
		if (NiagaraUpdateContextPtr->QualityLevel.IsSet() && 
			NiagaraUpdateContextPtr->QualityLevel.GetValue() == NewQualityLevel)
		{
			continue;
		}
		
		NiagaraUpdateContextPtr->QualityLevel = NewQualityLevel;
		if (NiagaraUpdateContextPtr->NiagaraComponent)
		{
			NiagaraUpdateContextPtr->NiagaraComponent->SetComponentQualityLevel(NewQualityLevel);
		}
	}
}

bool UKGEffectManager::IsEnvNiagaraEffect(UNiagaraComponent* NiagaraComponent) const
{
	if (!IsValid(NiagaraComponent))
	{
		return false;
	}
	
	auto* NiagaraSystem = NiagaraComponent->GetAsset();
	if (!NiagaraSystem)
	{
		return false;
	}
	
	auto* NiagaraEffectType = NiagaraSystem->GetEffectType();
	if (!NiagaraEffectType)
	{
		return false;
	}
	
	return EnvNiagaraEffectTypes.Contains(NiagaraEffectType);
}

void UKGEffectManager::KAPI_EffectManager_SetEnvNiagaraEffectTypeAssetPaths(const TArray<FString>& AssetPaths)
{
	EnvNiagaraEffectTypes.Empty();
	
	for (const auto& AssetPath : AssetPaths)
	{
		// 这里仅在初始化时设置
		if (UNiagaraEffectType* NiagaraEffectType = LoadObject<UNiagaraEffectType>(nullptr, *AssetPath))
		{
			EnvNiagaraEffectTypes.Add(NiagaraEffectType);
			UE_LOG(LogEM, Log, TEXT("UKGEffectManager::KAPI_EffectManager_SetEnvNiagaraEffectTypeAssetPaths, add env niagara effect type %s"), *AssetPath);
		}
		else
		{
			UE_LOG(LogEM, Error, TEXT("UKGEffectManager::KAPI_EffectManager_SetEnvNiagaraEffectTypeAssetPaths, failed to load niagara effect type %s"), *AssetPath);
		}
	}
}

void UKGEffectManager::OnNiagaraSystemInstancePreCreated(UNiagaraComponent* NiagaraComponent)
{
	if (!IsValid(NiagaraComponent))
	{
		return;
	}
	
	if (NiagaraComponentToNiagaraId.Contains(NiagaraComponent))
	{
		// 特效管理器自身管理的特效
		return;
	}
	
	if (!IsEnvNiagaraEffect(NiagaraComponent))
	{
		return;
	}
	
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::OnNiagaraSystemInstancePreCreated, native env niagara component added, %s, %s, %f, %d"),
		*NiagaraComponent->GetName(), NiagaraComponent->GetAsset() ? *NiagaraComponent->GetAsset()->GetPathName() : TEXT("nullptr"),
		EnvTransparencyScaleFactor, EnvNiagaraQualityLevel);
	
 	NiagaraComponent->SetParticleColorScale(EnvTransparencyScaleFactor);
	NiagaraComponent->SetComponentQualityLevel(static_cast<int32>(EnvNiagaraQualityLevel));
	NativeEnvNiagaraComponents.Add(NiagaraComponent);
}

void UKGEffectManager::OnNiagaraSystemInstanceDeallocated(FNiagaraSystemInstancePtr& InNiagaraSystemInstancePtr)
{
	if (!InNiagaraSystemInstancePtr.IsValid())
	{
		return;
	}

	TWeakObjectPtr NiagaraComponent = Cast<UNiagaraComponent>(InNiagaraSystemInstancePtr->GetAttachComponent());
	if (!NiagaraComponent.IsValid())
	{
		return;
	}
	
	if (NativeEnvNiagaraComponents.Contains(NiagaraComponent))
	{
		NativeEnvNiagaraComponents.Remove(NiagaraComponent);	
	}
}

int32 UKGEffectManager::GenerateNiagaraEffectId()
{
	static uint32 NiagaraEffectId = 1;
	NiagaraEffectId++;
	if (NiagaraEffectId >= 0x7fffffff)
	{
		NiagaraEffectId = 1;
	}

	return NiagaraEffectId;
}

int32 UKGEffectManager::GenerateNiagaraBudgetToken()
{
	static uint32 NiagaraBudgetToken = 1;
	NiagaraBudgetToken++;
	if (NiagaraBudgetToken >= 0x7fffffff)
	{
		NiagaraBudgetToken = 1;
	}

	return NiagaraBudgetToken;
}

void UKGEffectManager::UpdateNiagaras(float DeltaTime)
{
	{
		SCOPED_NAMED_EVENT(UKGEffectManager_UpdateNiagaras_ActivateNiagaraSystem, FColor::Red);
		const double StartTime = FPlatformTime::Seconds();
		int32 NiagaraEffectId = 0;
		while (PendingActiveNiagaraIds.TryPopLast(NiagaraEffectId))
		{
			// 查找不到是合理的，因为destroy时PendingActiveNiagaraIds不会做清理
			if (!NiagaraUpdateContexts.Contains(NiagaraEffectId))
			{
				continue;
			}
		
			ActivateNiagaraSystem(NiagaraEffectId);

			if (FPlatformTime::Seconds() - StartTime >= TickTimeLimitSeconds)
			{
				break;
			}
		}
	}

	{
		SCOPED_NAMED_EVENT(UKGEffectManager_UpdateNiagaras_UpdateNiagaraContext, FColor::Red);
		for (const int32 TickableNiagaraId : TickableNiagaraIds)
		{
			check(TickableNiagaraIds.Contains(TickableNiagaraId));
			UpdatePerNiagaraContext(NiagaraUpdateContexts[TickableNiagaraId], DeltaTime);
		}
	}

	{
		SCOPED_NAMED_EVENT(UKGEffectManager_UpdateNiagaras_UpdateNativeNiagaraUpdateTasks, FColor::Red);
		UpdateNativeNiagaraUpdateTasks(DeltaTime);
	}
	
	{
		SCOPED_NAMED_EVENT(UKGEffectManager_UpdateNiagaras_UpdateDilationTimers, FColor::Red);
		UpdateDilationTimers(DeltaTime);
	}
	
#if !UE_BUILD_SHIPPING && !UE_BUILD_TEST
	if (GEnableNiagaraDrawDebug || GEnableNativeNiagaraDrawDebug)
	{
		GEngine->AddOnScreenDebugMessage(INDEX_NONE, .0f, FColor::Green,
			FString::Printf(TEXT("[GPNiagaras] %d [TickableGPNiagaras] %d [NativeEnvNiagaras] %d"),
			NiagaraUpdateContexts.Num(), TickableNiagaraIds.Num(), NativeEnvNiagaraComponents.Num()));
	}
	
	if (GEnableNiagaraDrawDebug)
	{
		for (auto& Kvp : NiagaraUpdateContexts)
		{
			const auto& UpdateContext = Kvp.Value;
			auto* NiagaraComponent = UpdateContext.NiagaraComponent;
			if (!NiagaraComponent)
			{
				continue;
			}
			
			const FVector NiagaraLocation = NiagaraComponent->GetComponentLocation();
			const bool bEnvEffect = UpdateContext.PlayNiagaraParams.EffectTags.Contains(EKGNiagaraEffectTag::ENV);
			const FString Msg = FString::Printf(TEXT("%s, v: %d, pcs: %.3f, ql: %d %s"),
					*GetNameSafe(NiagaraComponent->GetAsset()),
					NiagaraComponent->IsVisible() && !NiagaraComponent->bHiddenInGame,
					NiagaraComponent->GetParticleColorScale(),
					UpdateContext.QualityLevel.IsSet() ? UpdateContext.QualityLevel.GetValue() : -1,
					bEnvEffect ? TEXT("[ENV]") : TEXT(""));
			DrawDebugSphere(GetWorld(), NiagaraLocation, 5.0f, 12, FColor::Red, false, 0.1f);
			DrawDebugString(GetWorld(), NiagaraLocation, Msg, nullptr, FColor::Green, 0.0f);	
		}
	}
	
	if (GEnableNativeNiagaraDrawDebug)
	{
		for (auto& NativeEnvNiagaraComp : NativeEnvNiagaraComponents)
		{
			if (!NativeEnvNiagaraComp.IsValid())
			{
				continue;
			}
			
			const FVector NiagaraLocation = NativeEnvNiagaraComp->GetComponentLocation();
			bool bVisible = NativeEnvNiagaraComp->IsVisible() && !NativeEnvNiagaraComp->bHiddenInGame;
			if (auto* Owner = NativeEnvNiagaraComp->GetOwner())
			{
				bVisible = bVisible && !Owner->IsHidden();
			}
			const FString Msg = FString::Printf(TEXT("%s, v: %d, pcs: %.3f, ql: %d"),
					*GetNameSafe(NativeEnvNiagaraComp->GetAsset()),
					bVisible, NativeEnvNiagaraComp->GetParticleColorScale(), NativeEnvNiagaraComp->GetComponentQualityLevel());
			DrawDebugSphere(GetWorld(), NiagaraLocation, 5.0f, 12, FColor::Orange, false, 0.1f);
			DrawDebugString(GetWorld(), NiagaraLocation, Msg, nullptr, FColor::Cyan, 0.0f);	
		}
	}
#endif
}

UNiagaraComponent* UKGEffectManager::ActivateNiagaraSystem(int32 NiagaraEffectId)
{
	SCOPED_NAMED_EVENT(UKGEffectManager_ActivateNiagaraSystem, FColor::Red);
	
	if (!NiagaraUpdateContexts.Contains(NiagaraEffectId))
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::ActivateNiagaraSystem, invalid NiagaraEffectId %d"), NiagaraEffectId);
		InternalDestroyNiagaraSystem(NiagaraEffectId);
		return nullptr;
	}

	FKGNiagaraUpdateContext& UpdateContext = NiagaraUpdateContexts[NiagaraEffectId];
	FKGPlayNiagaraParams& PlayNiagaraParams = UpdateContext.PlayNiagaraParams;
	if (UpdateContext.bRequiresAttachComponent && !UpdateContext.AttachComponent.IsValid())
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::ActivateNiagaraSystem, niagara attach component invalid %s"), *UpdateContext.ToString());
		SetNiagaraWaitAttachComponentTimer(UpdateContext, WaitAttachComponentTimeoutSeconds);
		return nullptr;
	}

	auto EffectPath = FName(*PlayNiagaraParams.NiagaraEffectPath);
	auto IsBattleEffect = PlayNiagaraParams.EffectTags.Contains(EKGNiagaraEffectTag::BATTLE);

	auto Priority = PlayNiagaraParams.NiagaraBusinessPriority >= 0 ? PlayNiagaraParams.NiagaraBusinessPriority : UpdateContext.NiagaraSystem->GetPriority();
	
	float OutScoreToRelease = 0;	// 需要额外释放多少预算
	float OutMaxRequiredScore = 0;	// OutMaxRequiredScore该特效最大占用预算

	// 先判断下性能预算够不够，并不实际spawn/active
	if (IsBattleEffect && !this->NiagaraScoreManager->CheckScorePoolAvailable(UpdateContext.NiagaraSystem, EffectPath, Priority, OutScoreToRelease, OutMaxRequiredScore))
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::CheckScorePoolAvailable Failed, SystemPath=%s, Priority=%d"),
			*EffectPath.ToString(), Priority);

		DestroyNiagaraSystem(NiagaraEffectId);
		return nullptr;
	}
	
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::ActivateNiagaraSystem, %s"), *UpdateContext.ToString());

	UpdateContext.InheritOwnerCustomDepthInfo();
	
	FFXSystemSpawnParameters SpawnParams;
	SpawnParams.WorldContextObject = GetWorld();
	SpawnParams.SystemTemplate = UpdateContext.NiagaraSystem;
	if (ShouldUseNiagaraComponentPool())
	{
		SpawnParams.PoolingMethod = EPSCPoolMethod::ManualRelease;
	}
	else
	{
		SpawnParams.PoolingMethod = EPSCPoolMethod::None;
		SpawnParams.bAutoDestroy = true;
	}

	SpawnParams.Location = UpdateContext.NewWorldSpaceOrRelativeSpawnTrans.GetLocation();
	SpawnParams.Rotation = UpdateContext.NewWorldSpaceOrRelativeSpawnTrans.Rotator();
	SpawnParams.Scale = UpdateContext.NewWorldSpaceOrRelativeSpawnTrans.GetScale3D();
	SpawnParams.bPreCullCheck = PlayNiagaraParams.bPreCullCheck;
	SpawnParams.bIsPlayerEffect = PlayNiagaraParams.bIsPlayerEffect;

	// 有一些初始化逻辑在Activate里调用，为了不修改引擎代码，这里先强制AutoActivate为false
	// 拿到NiagaraComponent设置正确的初始值后再手动Activate
	SpawnParams.bAutoActivate = false;

	UNiagaraComponent* NiagaraComponent;
	if (PlayNiagaraParams.NeedAttach())
	{
		auto& AttachedSpawnInfo = PlayNiagaraParams.GetAttachedSpawnInfoChecked();
		SpawnParams.AttachPointName = AttachedSpawnInfo.AttachPointName;
		SpawnParams.AttachToComponent = UpdateContext.AttachComponent.Get();
		SpawnParams.LocationType = AttachedSpawnInfo.LocationType;
		
		NiagaraComponent = UNiagaraFunctionLibrary::SpawnSystemAttachedWithParams(SpawnParams);
	}
	else
	{
		// 只影响特效大小, 不影响特效位置
		auto& UnattachedSpawnInfo = PlayNiagaraParams.GetUnattachedSpawnInfoChecked();
		if (UpdateContext.bForceUseAbsoluteScale && !UnattachedSpawnInfo.bAbsoluteScale)
		{
			UE_LOG(LogEM, Log, TEXT("UKGEffectManager::ActivateNiagaraSystem, %s force use absolute scale enabled, use scale %s -> %s"), 
				*UpdateContext.ToString(),
				*SpawnParams.Scale.ToString(),
				*UnattachedSpawnInfo.WorldOrRelativeTrans.GetScale3D().ToString());
			SpawnParams.Scale = UnattachedSpawnInfo.WorldOrRelativeTrans.GetScale3D();
		}
		NiagaraComponent = UNiagaraFunctionLibrary::SpawnSystemAtLocationWithParams(SpawnParams);
	}
	
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::ActivateNiagaraSystem, possible culling, %s"), *UpdateContext.ToString());
		InternalDestroyNiagaraSystem(NiagaraEffectId);
		return nullptr;
	}

	// 记录 NiagaraComponent 指针，在后续的 InternalDestroyNiagaraSystem 中才能被正确归还。
	UpdateContext.NiagaraComponent = NiagaraComponent;

	// 这个要放到NiagaraComponent创建之后, Activate之前调用
	UpdateContext.RefreshQualityLevelAndTransparencyScale();
	
	// 这个一定要放在Activate之前调用, 避免Activate之后调用导致NiagaraSystemInstance Reset
	if (UpdateContext.QualityLevel.IsSet())
	{
		NiagaraComponent->SetComponentQualityLevel(UpdateContext.QualityLevel.GetValue(), false);	
	}
	
	// 这里特效已经创建了，可以拿到真实位置，基于位置尝试释放距离更远，优先级更低的特效。如果失败还是会销毁该特效
	if (IsBattleEffect && !this->NiagaraScoreManager->PrepareNiagaraActivation(NiagaraComponent, EffectPath, Priority, OutScoreToRelease, OutMaxRequiredScore))
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::ActivateNiagaraSystem, NiagaraScore Prepare Activation Failed, SystemPath=%s, Priority=%d"),
			*EffectPath.ToString(), Priority);

		InternalDestroyNiagaraSystem(NiagaraEffectId);
		
		return nullptr;
	}

	// yunhan:其他玩家的特效做降频处理
	if (PlayNiagaraParams.EffectTags.Contains(EKGNiagaraEffectTag::OTHER_PLAYER))
	{
		this->NiagaraScoreManager->SetBattleEffectTickingRate(NiagaraComponent);
	}

	// 需要提前到Activate前面，否则active后查询TAG会找不到
	NiagaraComponentToNiagaraId.Add(TWeakObjectPtr<UNiagaraComponent>(NiagaraComponent), NiagaraEffectId);

	NiagaraComponent->Activate(true);
	OnNiagaraComponentActive.Broadcast(NiagaraComponent, PlayNiagaraParams);
	
	if (UpdateContext.NeedsUpdate())
	{
		TickableNiagaraIds.Add(NiagaraEffectId);
	}

	// niagara system finish时需要通知业务做状态清理
	NiagaraComponent->OnSystemFinished.AddDynamic(this, &UKGEffectManager::InternalOnNiagaraSystemFinished);
	
#if WITH_EDITOR
	if (GbShowNiagaraInWorldOutliner)
	{
		AActor* NewSpawner = KGUtils::GetActorByID(PlayNiagaraParams.SpawnerID);
		if (UpdateContext.NiagaraSystem && NewSpawner)
		{
			const FString NewName = FString::Printf(TEXT("%s_%d"), *UpdateContext.NiagaraSystem->GetName(), NiagaraEffectId);
			if (NiagaraComponent->Rename(*NewName, NewSpawner))
			{
				if (auto* OwnerActor = NiagaraComponent->GetOwner())
				{
					OwnerActor->AddInstanceComponent(NiagaraComponent);
				}	
			}
		}
	}
#endif
	
	RefreshNiagaraStateOnActivate(NiagaraEffectId, UpdateContext);

#if KG_EFFECTMANAGER_ENABLE_STAT
	if (UpdateContext.bEnableNiagaraEffectTypeDebugCheck)
	{
		FString NiagaraEffectTypeName;
		if (UpdateContext.NiagaraSystem && UpdateContext.NiagaraSystem->GetEffectType())
		{
			NiagaraEffectTypeName = UpdateContext.NiagaraSystem->GetEffectType()->GetName();
		}
		CallLuaFunction("KCB_NiagaraEffectTypeDebugCheck", PlayNiagaraParams.NiagaraEffectPath,
			NiagaraEffectTypeName, UpdateContext.SkillIdDebugUsage, PlayNiagaraParams.InstigatorEntityID);
	}
#endif
	return NiagaraComponent;
}

void UKGEffectManager::InternalOnNiagaraSystemFinished(UNiagaraComponent* NiagaraComponent)
{
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::InternalOnNiagaraSystemFinished, invalid NiagaraComponent"));
		return;
	}

	TWeakObjectPtr<UNiagaraComponent> NiagaraComponentWeakPtr(NiagaraComponent);
	if (!NiagaraComponentToNiagaraId.Contains(NiagaraComponentWeakPtr))
	{
		UE_LOG(LogEM, Error,
			TEXT("UKGEffectManager::InternalOnNiagaraSystemFinished, cannot find NiagaraEffectId by NiagaraComponent %s"),
			*GetNameSafe(NiagaraComponent));
		return;
	}

	const int32 EffectID = NiagaraComponentToNiagaraId[NiagaraComponentWeakPtr];
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::InternalOnNiagaraSystemFinished, %s, bIsCulledByScalability: %d"),
		NiagaraUpdateContexts.Contains(EffectID) ? *NiagaraUpdateContexts[EffectID].ToString() : TEXT("invalid"),
		NiagaraComponent->GetIsCulledByScalability());

	InternalDestroyNiagaraSystem(EffectID);
}

bool UKGEffectManager::GetPlayNiagaraParams(TWeakObjectPtr<UNiagaraComponent> NiagaraComponentWeakPtr, FKGPlayNiagaraParams& OutParams)
{
	if (!NiagaraComponentWeakPtr.IsValid())
	{
		return false;
	}
	
	if (!NiagaraComponentToNiagaraId.Contains(NiagaraComponentWeakPtr))
	{
		return false;
	}

	const int32 EffectID = NiagaraComponentToNiagaraId[NiagaraComponentWeakPtr];
	FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(EffectID);
	if (!UpdateContextPtr)
	{
		return false;
	}

	OutParams = UpdateContextPtr->PlayNiagaraParams;
	return true;
}

bool UKGEffectManager::DoesActorForceUseAbsoluteScale(KGActorID ActorID)
{
	return ForceUseAbsoluteScaleActors.Contains(ActorID);
}

void UKGEffectManager::SetActorEnableTimeDilation(KGActorID ActorID, bool bEnableTimeDilation)
{
	const bool bOldEnabled = ActorsWithTimeDilation.Contains(ActorID);
	if (bOldEnabled == bEnableTimeDilation)
	{
		return;
	}
	
	if (bEnableTimeDilation)
	{
		ActorsWithTimeDilation.Add(ActorID);
	}
	else
	{
		ActorsWithTimeDilation.Remove(ActorID);
	}
	
	SetTimerModeByActorID(ActorID, bEnableTimeDilation);
}

bool UKGEffectManager::InternalDestroyNiagaraSystem(int32 NiagaraEffectId)
{
	SCOPED_NAMED_EVENT(UKGEffectManager_InternalDestroyNiagaraSystem, FColor::Red);

	FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!UpdateContextPtr)
	{
		return false;
	}

	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::InternalDestroyNiagaraSystem, %s"), *UpdateContextPtr->ToString());
	UpdateContextPtr->OnNiagaraSystemDestroyed();
	
	// 还在资源加载中
	if (UpdateContextPtr->AssetLoadID != 0)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::InternalDestroyNiagaraSystem, loading niagara asset, cancel loading process %s"), *UpdateContextPtr->ToString())
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(this))
		{
			AssetManager->CancelAsyncLoadByLoadID(UpdateContextPtr->AssetLoadID);
		}
	}
	
	const auto& PlayNiagaraParams = UpdateContextPtr->PlayNiagaraParams;
	
	// 如果niagara update context是 pending activate状态, 那么这里NiagaraComponent就可能为空
	if (UpdateContextPtr->NiagaraComponent != nullptr)
	{
		auto WeakPtr = TWeakObjectPtr<UNiagaraComponent>(UpdateContextPtr->NiagaraComponent);

		NiagaraComponentToNiagaraId.Remove(WeakPtr);
		OnNiagaraComponentDeActive.Broadcast(UpdateContextPtr->NiagaraComponent, PlayNiagaraParams);
		UpdateContextPtr->NiagaraComponent->OnSystemFinished.RemoveAll(this);
		// loop类型的特效需要DeactivateImmediate通知SystemInstance立即结束, 否则会出现发射器无法正常结束的问题
		UpdateContextPtr->NiagaraComponent->DeactivateImmediate();
		if (ShouldUseNiagaraComponentPool())
		{
			UpdateContextPtr->NiagaraComponent->ReleaseToPool();
		}
	}

	if (auto* EffectsOnSpawner = SpawnerIdToEffectIds.Find(PlayNiagaraParams.SpawnerID))
	{
		EffectsOnSpawner->Remove(NiagaraEffectId);
	}
	if (UpdateContextPtr->ExtraSpawnerInfos.Num() > 0)
	{
		for (const auto& Kvp : UpdateContextPtr->ExtraSpawnerInfos)
		{
			const auto ExtraSpawnerId = Kvp.Key;
			if (auto* EffectsOnSpawner = SpawnerIdToEffectIds.Find(ExtraSpawnerId))
			{
				if (EffectsOnSpawner->Contains(NiagaraEffectId))
				{
					EffectsOnSpawner->Remove(NiagaraEffectId);
				}
				else
				{
					UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::ClearEffectState, cannot find NiagaraEffectId %d in SpawnerId %lld"), NiagaraEffectId, ExtraSpawnerId);
				}
			}
		}
	}

	if (PlayNiagaraParams.EffectTags.Num() > 0)
	{
		for (const auto EffectTag : PlayNiagaraParams.EffectTags)
		{
			if (EffectTagToEffectIds.Contains(EffectTag) && EffectTagToEffectIds[EffectTag].Contains(NiagaraEffectId))
			{
				EffectTagToEffectIds[EffectTag].Remove(NiagaraEffectId);
			}
		}
	}

	if (TickableNiagaraIds.Contains(NiagaraEffectId))
	{
		TickableNiagaraIds.Remove(NiagaraEffectId);
	}

	UpdateContextPtr->LifeTimeHandle.ClearTimer();
	UpdateContextPtr->ChangeVisibilityTimerHandle.ClearTimer();
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(UpdateContextPtr->WaitAttachComponentHandle);
	}
	else
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::ClearEffectState, invalid world, %s"), *UpdateContextPtr->ToString());
	}

	NiagaraUpdateContexts.Remove(NiagaraEffectId);
	
	return true;
}

void UKGEffectManager::NotifyRemoveComponent(KGObjectID ActorId, KGObjectID ComponentId)
{
	USceneComponent* InAttachComponent = Cast<USceneComponent>(KGUtils::GetObjectByID(ComponentId));
	if (!InAttachComponent)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::NotifyRemoveComponent, invalid component %lld"), ComponentId);
		return;
	}
	
	if (!SpawnerIdToEffectIds.Contains(ActorId))
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::NotifyRemoveComponent, invalid ActorId %lld"), ActorId);
		return;
	}

	for (int32 EffectId : SpawnerIdToEffectIds[ActorId])
	{
		FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(EffectId);
		if (UpdateContextPtr && UpdateContextPtr->PlayNiagaraParams.NeedAttach() && UpdateContextPtr->AttachComponent.Get() == InAttachComponent)
		{
			InternalDetachNiagaraEffect(*UpdateContextPtr);
		}
	}
}

void UKGEffectManager::NotifyNiagaraAttachComponentCreated(int32 NiagaraEffectId)
{
	FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!UpdateContextPtr)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::NotifyNiagaraAttachComponentCreated, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}

	if (UpdateContextPtr->bRequiresAttachComponent && !UpdateContextPtr->AttachComponent.IsValid())
	{
		UpdateContextPtr->RefreshAttachComponentOrSpawnTrans();
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::NotifyNiagaraAttachComponentCreated, refresh niagara attach component, %s, AttachComponent %s"),
			*UpdateContextPtr->ToString(), *GetNameSafe(UpdateContextPtr->AttachComponent.Get()));
	}
	
	if (UpdateContextPtr->WaitAttachComponentHandle.IsValid() &&
		UpdateContextPtr->AttachComponent.IsValid())
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::NotifyNiagaraAttachComponentCreated, active niagara, %s"),
			*UpdateContextPtr->ToString());
		ClearNiagaraWaitAttachComponentTimer(*UpdateContextPtr);
		ActivateNiagaraSystem(NiagaraEffectId);
	}
}

void UKGEffectManager::SetNiagaraDelayDestroy(int32 NiagaraEffectId, float DelayDestroyTimeMs)
{
	FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!UpdateContextPtr)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::SetNiagaraDelayDestroy, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}
	
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::SetNiagaraDelayDestroy, DelayDestroyTimeMs %f, %s"), DelayDestroyTimeMs, *UpdateContextPtr->ToString());

	// 没加载完但是又需要挂载就不设置延迟销毁了，因为要挂载的actorComp此时已经销毁了，创建了应该也没法没法挂接
	if (UpdateContextPtr->NiagaraSystem == nullptr && UpdateContextPtr->PlayNiagaraParams.NeedAttach())
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::SetNiagaraDelayDestroy, NiagaraSystem not ready, destroy niagara, NiagaraEffectId %d"), NiagaraEffectId);
		DestroyNiagaraSystem(NiagaraEffectId);
		return;
	}

	SetNiagaraLifeTimeTimer(NiagaraEffectId, EKGNiagaraTimeoutState::Destroy, DelayDestroyTimeMs / 1000.0f);
}

void UKGEffectManager::InternalUpdateNiagaraHiddenState(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext, bool bHidden, uint8 HiddenReason, bool bInitHiddenState)
{
	InOutNiagaraUpdateContext.UpdateNiagaraHiddenState(bHidden, HiddenReason, bInitHiddenState);
}

void UKGEffectManager::InternalUpdateNiagaraHiddenStateWithBlendTime(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext, bool bHidden, uint8 HiddenReason, float BlendTime)
{
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::InternalUpdateNiagaraHiddenStateWithBlendTime, NiagaraEffectId %d, bHidden %d, HiddenReason %d, BlendTime %f"),
		InOutNiagaraUpdateContext.NiagaraEffectId, bHidden, HiddenReason, BlendTime);

	if (FMath::IsNearlyZero(BlendTime) || BlendTime <= 0.0f)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::InternalUpdateNiagaraHiddenStateWithBlendTime, invalid BlendTime %f, %s"),
			BlendTime, *InOutNiagaraUpdateContext.ToString());
		return;
	}
	
	InOutNiagaraUpdateContext.ChangeVisibilityTimerHandle.ClearTimer();
	if (bHidden)
	{
		InternalSetLinearSampleParticleColorScaleUpdateTask(InOutNiagaraUpdateContext, false, BlendTime, false);
		
		const bool bUseTimerManager = !ActorsWithTimeDilation.Contains(InOutNiagaraUpdateContext.PlayNiagaraParams.SpawnerID);
		UE_LOG(LogEM, Log,
			TEXT("UKGEffectManager::InternalUpdateNiagaraHiddenStateWithBlendTime, start life time timer %f seconds, %s, bUseTimerManager=%d"),
			BlendTime, *InOutNiagaraUpdateContext.ToString(), bUseTimerManager);
		InOutNiagaraUpdateContext.ChangeVisibilityTimerHandle.InitOnceTimer(BlendTime, 
			FTimerDelegate::CreateUObject(this, &UKGEffectManager::OnNiagaraHiddenDelayTimerExpired, InOutNiagaraUpdateContext.NiagaraEffectId, bHidden, HiddenReason),
			bUseTimerManager);
	}
	else
	{
		InternalUpdateNiagaraHiddenState(InOutNiagaraUpdateContext, bHidden, HiddenReason, false);
		InternalSetLinearSampleParticleColorScaleUpdateTask(InOutNiagaraUpdateContext, true, BlendTime, false);
	}
}

void UKGEffectManager::OnNiagaraHiddenDelayTimerExpired(int32 NiagaraEffectId, bool bHidden, uint8 HiddenReason)
{
	FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!UpdateContextPtr)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::OnNiagaraHiddenDelayTimerExpired, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}

	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::OnNiagaraHiddenDelayTimerExpired, NiagaraEffectId %d, bHidden %d, HiddenReason %d"),
		NiagaraEffectId, bHidden, HiddenReason);

	InternalUpdateNiagaraHiddenState(*UpdateContextPtr, bHidden, HiddenReason, false);
}

void UKGEffectManager::UpdateDilationTimers(float DeltaTime)
{
	if (ActorsWithTimeDilation.Num() == 0)
	{
		return;
	}
	
	for (auto ActorID : ActorsWithTimeDilation)
	{
		// tick timer回调可能会走到特效销毁逻辑, 因为完美闪避目前最多涉及两个角色, 性能这块问题不大, 先用copy的方案
		if (auto* EffectIDsPtr = SpawnerIdToEffectIds.Find(ActorID))
		{
			auto TempEffectIDs(*EffectIDsPtr);
			for (const auto EffectID : TempEffectIDs)
			{
				if (auto* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(EffectID))
				{
					if (NiagaraUpdateContextPtr->PlayNiagaraParams.SpawnerID != ActorID)
					{
						continue;
					}
					
					NiagaraUpdateContextPtr->LifeTimeHandle.UpdateTickTimer(DeltaTime);
					NiagaraUpdateContextPtr->ChangeVisibilityTimerHandle.UpdateTickTimer(DeltaTime);
				}
			}
		}
	}
}

void UKGEffectManager::SetTimerModeByActorID(KGActorID ActorID, bool bEnableTimeDilation)
{
	if (auto* EffectIDsPtr = SpawnerIdToEffectIds.Find(ActorID))
	{
		for (const auto EffectID : *EffectIDsPtr)
		{
			if (auto* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(EffectID))
			{
				if (NiagaraUpdateContextPtr->PlayNiagaraParams.SpawnerID != ActorID)
				{
					continue;
				}
				
				NiagaraUpdateContextPtr->LifeTimeHandle.ChangeTimerMode(bEnableTimeDilation);
				NiagaraUpdateContextPtr->ChangeVisibilityTimerHandle.ChangeTimerMode(bEnableTimeDilation);
			}
		}
	}
}

void UKGEffectManager::UpdatePerNiagaraContext(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext, float DeltaTime)
{
	UNiagaraComponent* NiagaraComponent = InOutNiagaraUpdateContext.NiagaraComponent;
	if (NiagaraComponent == nullptr)
	{
		return;
	}
	
	const float ScaledDeltaTime = DeltaTime * InOutNiagaraUpdateContext.DynamicPlayRate;
	InOutNiagaraUpdateContext.AccumulatedTime += ScaledDeltaTime;
	InOutNiagaraUpdateContext.TickUpdateTasks(ScaledDeltaTime);
}

void UKGEffectManager::UpdateTickableNiagaraIds(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext)
{
	const auto NiagaraEffectId = InOutNiagaraUpdateContext.NiagaraEffectId;
	const bool bNeedsUpdate = InOutNiagaraUpdateContext.NeedsUpdate();
	const bool bIsInTickQueue = TickableNiagaraIds.Contains(NiagaraEffectId);
	if (bNeedsUpdate && !bIsInTickQueue)
	{
		TickableNiagaraIds.Add(NiagaraEffectId);
	}
	else if (!bNeedsUpdate && bIsInTickQueue)
	{
		TickableNiagaraIds.Remove(NiagaraEffectId);
	}
}

void UKGEffectManager::InternalOnNiagaraAssetsLoaded(int InLoadID, UObject* NiagaraSystem, int32 NiagaraEffectId, bool bAsyncAssetLoadCallback)
{
	FKGNiagaraUpdateContext* NiagaraUpdateContextPtr = NiagaraUpdateContexts.Find(NiagaraEffectId);
	if (!NiagaraUpdateContextPtr)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::InternalOnNiagaraAssetsLoaded, invalid NiagaraEffectId %d"), NiagaraEffectId);
		return;
	}
	const auto& PlayNiagaraParams = NiagaraUpdateContextPtr->PlayNiagaraParams;

	if (bAsyncAssetLoadCallback)
	{
		NiagaraUpdateContextPtr->AssetLoadID = 0;
	}

	// 避免重复执行
	if (NiagaraUpdateContextPtr->bAssetLoaded)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::InternalOnNiagaraAssetsLoaded, asset already loaded, %s"),
			*NiagaraUpdateContextPtr->ToString());
		return;
	}
	NiagaraUpdateContextPtr->bAssetLoaded = true;
	
	UE_LOG(LogEM, Log, TEXT("UKGEffectManager::InternalOnNiagaraAssetsLoaded, NiagaraEffectId %d, NiagaraEffectPath: %s"),
		NiagaraEffectId, *PlayNiagaraParams.NiagaraEffectPath);

	NiagaraUpdateContextPtr->NiagaraSystem = Cast<UNiagaraSystem>(NiagaraSystem);
	if (NiagaraUpdateContextPtr->NiagaraSystem == nullptr)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::InternalOnNiagaraAssetsLoaded, invalid niagara system, %d %s"), 
			NiagaraEffectId, *PlayNiagaraParams.NiagaraEffectPath);
		InternalDestroyNiagaraSystem(NiagaraEffectId);
		return;
	}

	if (PlayNiagaraParams.bActivateImmediately)
	{
		ActivateNiagaraSystem(NiagaraEffectId);
	}
	else
	{
		PendingActiveNiagaraIds.PushFirst(NiagaraEffectId);	
	}
}

void UKGEffectManager::RefreshNiagaraStateOnActivate(int32 NiagaraEffectId, FKGNiagaraUpdateContext& InOutNiagaraUpdateContext)
{
	SCOPED_NAMED_EVENT(UKGEffectManager_RefreshNiagaraStateOnActivate, FColor::Red);
	
	const auto& PlayNiagaraParams = InOutNiagaraUpdateContext.PlayNiagaraParams;
	auto NiagaraComponent = InOutNiagaraUpdateContext.NiagaraComponent;
	check(NiagaraComponent);
	
	InOutNiagaraUpdateContext.OnNiagaraSystemActivate();
	UpdateTickableNiagaraIds(InOutNiagaraUpdateContext);
	
	if (PlayNiagaraParams.TotalLifeMs > 0)
	{
		SetNiagaraLifeTimeTimer(NiagaraEffectId, EKGNiagaraTimeoutState::Deactivate, PlayNiagaraParams.TotalLifeMs / 1000.0f);
	}
}

void UKGEffectManager::BindEffectToSpawner(int32 NiagaraEffectId, KGObjectID SpawnerID, bool bIsSpawnerEffectOwner,
	EKGNiagaraBehaviorOnExtraSpawnerDestroy Behavior, EKGNiagaraHiddenReason HiddenReason, FKGNiagaraUpdateContext& InOutNiagaraUpdateContext)
{
	if (SpawnerID == 0)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::BindEffectToSpawner, invalid spawner id"));
		return;
	}
	
	if (!SpawnerIdToEffectIds.Contains(SpawnerID))
	{
		SpawnerIdToEffectIds.Add(SpawnerID,{});
	}
	SpawnerIdToEffectIds[SpawnerID].Add(NiagaraEffectId);
	
	if (!bIsSpawnerEffectOwner)
	{
		auto& Info = InOutNiagaraUpdateContext.ExtraSpawnerInfos.Add(SpawnerID);
		Info.BehaviorOnDestroy = Behavior;
		Info.HiddenReason = HiddenReason;
	}
}

void UKGEffectManager::BindEffectToLinkedComponent(KGObjectID ComponentID, int32 NiagaraEffectId,
	EKGNiagaraBehaviorOnExtraSpawnerDestroy Behavior, EKGNiagaraHiddenReason HiddenReason, FKGNiagaraUpdateContext& InOutNiagaraUpdateContext)
{
	UActorComponent* Component = Cast<UActorComponent>(KGUtils::GetObjectByID(ComponentID));
	if (!Component)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::BindEffectToLinkedComponent, invalid component %lld"), ComponentID);
		return;
	}

	AActor* ComponentOwner = Component->GetOwner();
	if (!ComponentOwner)
	{
		return;
	}

	BindEffectToSpawner(NiagaraEffectId, KGUtils::GetIDByObject(ComponentOwner), false, Behavior, HiddenReason, InOutNiagaraUpdateContext);
}

void UKGEffectManager::ClearAllExtraSpawners(FKGNiagaraUpdateContext& InOutNiagaraUpdateContext)
{
	const auto EffectID = InOutNiagaraUpdateContext.NiagaraEffectId;
	for (const auto& Kvp : InOutNiagaraUpdateContext.ExtraSpawnerInfos)
	{
		if (auto* EffectIDsPtr = SpawnerIdToEffectIds.Find(Kvp.Key))
		{
			if (EffectIDsPtr->Contains(EffectID))
			{
				EffectIDsPtr->Remove(EffectID);
			}
		}
	}
	
	InOutNiagaraUpdateContext.ExtraSpawnerInfos.Empty();
}

void UKGEffectManager::DestroyOrDeactivateNiagarasBySpawnerId(KGObjectID SpawnerId, bool bSpawnerExitWorld, bool bDestroy)
{
	if (!SpawnerIdToEffectIds.Contains(SpawnerId))
	{
		return;
	}

	// DestroyNiagaraSystem过程中修改SpawnerIdToEffectIds
	TSet<int32> TempEffectIds = SpawnerIdToEffectIds[SpawnerId];
	for (int32 EffectId : TempEffectIds)
	{
		FKGNiagaraUpdateContext* UpdateContextPtr = NiagaraUpdateContexts.Find(EffectId);
		if (UpdateContextPtr)
		{
			// 如果spawner是特效的extra spawner, 且外部标记了仅隐藏特效, 那么这里只执行特效隐藏
			auto* ExtraSpawnerInfoPtr = UpdateContextPtr->ExtraSpawnerInfos.Find(SpawnerId);
			if (ExtraSpawnerInfoPtr != nullptr && ExtraSpawnerInfoPtr->BehaviorOnDestroy == EKGNiagaraBehaviorOnExtraSpawnerDestroy::HideEffect)
			{
				UE_LOG(LogEM, Log, TEXT("UKGEffectManager::DestroyOrDeactivateNiagarasBySpawnerId, hide niagara effect %d for extra spawner %lld"),
					EffectId, SpawnerId);
				UpdateNiagaraHiddenState(EffectId, true, static_cast<uint8>(ExtraSpawnerInfoPtr->HiddenReason), false, 0.0f);
			}
			else if (bSpawnerExitWorld && !UpdateContextPtr->PlayNiagaraParams.bDestroyWhenSpawnerExitWorld)
			{
				UE_LOG(LogEM, Log, TEXT("UKGEffectManager::DestroyOrDeactivateNiagarasBySpawnerId, deactivate niagara effect %d for spawner exit world"),
					EffectId);
				InternalDetachNiagaraEffect(*UpdateContextPtr);
			}
			else if (bDestroy)
			{
				DestroyNiagaraSystem(EffectId);
			}
			else
			{
				DeactivateNiagaraSystem(EffectId);
			}
		}
	}

	SpawnerIdToEffectIds.Remove(SpawnerId);
	if (ActorsWithTimeDilation.Contains(SpawnerId))
	{
		ActorsWithTimeDilation.Remove(SpawnerId);
	}
}

#pragma endregion Niagara

#pragma region Niagara Score
void UKGEffectManager::SetNiagaraScoreCapacity(
		int32 QualityLevel,
		float MinFPS, float MaxFPS,
		float MinCap, float MaxCap,
		const FString& PriorityPercentages)
{
	if (!this->NiagaraScoreManager.IsValid())
		return;
	if (QualityLevel < 0 || QualityLevel > 4) // QualityLevel must be 0-4
		return;
	if (PriorityPercentages.IsEmpty())
		return;

	FKGNiagaraScoreCapacitySettings CapacitySettings;
	CapacitySettings.FpsRange.Set(MinFPS, MaxFPS);
	CapacitySettings.CapacityRange.Set(MinCap, MaxCap);
	
	CapacitySettings.PriorityCapacityPercentages.Empty();

	TArray<FString> Segments;
	PriorityPercentages.ParseIntoArray(Segments, TEXT(","));
	for (const FString& Str : Segments)
	{
		float Value = 0;
		LexTryParseString(Value, *Str);
		
		CapacitySettings.PriorityCapacityPercentages.Add(Value);
	}
	
	this->NiagaraScoreManager->SetNiagaraScoreCapacitySettings(QualityLevel, CapacitySettings);
}

void UKGEffectManager::SetNiagaraScoreData(const FString& InNiagaraSystemPath,
		uint8 Score_QL0_200, uint8 Score_QL0_500, uint8 Score_QL0_1000, uint8 Score_QL0_2000, uint8 Score_QL0_4000, uint8 Score_QL0_8000,
		uint8 Score_QL1_200, uint8 Score_QL1_500, uint8 Score_QL1_1000, uint8 Score_QL1_2000, uint8 Score_QL1_4000, uint8 Score_QL1_8000,
		uint8 Score_QL2_200, uint8 Score_QL2_500, uint8 Score_QL2_1000, uint8 Score_QL2_2000, uint8 Score_QL2_4000, uint8 Score_QL2_8000,
		uint8 Score_QL3_200, uint8 Score_QL3_500, uint8 Score_QL3_1000, uint8 Score_QL3_2000, uint8 Score_QL3_4000, uint8 Score_QL3_8000,
		uint8 Score_QL4_200, uint8 Score_QL4_500, uint8 Score_QL4_1000, uint8 Score_QL4_2000, uint8 Score_QL4_4000, uint8 Score_QL4_8000)
{
	if (!this->NiagaraScoreManager.IsValid())
		return;
	if (InNiagaraSystemPath.IsEmpty())
		return;
	
	FKGNiagaraScoreData ScoreData;
	ScoreData.Score_QL0_200 = Score_QL0_200;
	ScoreData.Score_QL0_500 = Score_QL0_500;
	ScoreData.Score_QL0_1000 = Score_QL0_1000;
	ScoreData.Score_QL0_2000 = Score_QL0_2000;
	ScoreData.Score_QL0_4000 = Score_QL0_4000;
	ScoreData.Score_QL0_8000 = Score_QL0_8000;
	
	ScoreData.Score_QL1_200 = Score_QL1_200;
	ScoreData.Score_QL1_500 = Score_QL1_500;
	ScoreData.Score_QL1_1000 = Score_QL1_1000;
	ScoreData.Score_QL1_2000 = Score_QL1_2000;
	ScoreData.Score_QL1_4000 = Score_QL1_4000;
	ScoreData.Score_QL1_8000 = Score_QL1_8000;
	
	ScoreData.Score_QL2_200 = Score_QL2_200;
	ScoreData.Score_QL2_500 = Score_QL2_500;
	ScoreData.Score_QL2_1000 = Score_QL2_1000;
	ScoreData.Score_QL2_2000 = Score_QL2_2000;
	ScoreData.Score_QL2_4000 = Score_QL2_4000;
	ScoreData.Score_QL2_8000 = Score_QL2_8000;
	
	ScoreData.Score_QL3_200 = Score_QL3_200;
	ScoreData.Score_QL3_500 = Score_QL3_500;
	ScoreData.Score_QL3_1000 = Score_QL3_1000;
	ScoreData.Score_QL3_2000 = Score_QL3_2000;
	ScoreData.Score_QL3_4000 = Score_QL3_4000;
	ScoreData.Score_QL3_8000 = Score_QL3_8000;

	ScoreData.Score_QL4_200 = Score_QL4_200;
	ScoreData.Score_QL4_500 = Score_QL4_500;
	ScoreData.Score_QL4_1000 = Score_QL4_1000;
	ScoreData.Score_QL4_2000 = Score_QL4_2000;
	ScoreData.Score_QL4_4000 = Score_QL4_4000;
	ScoreData.Score_QL4_8000 = Score_QL4_8000;

	this->NiagaraScoreManager->SetNiagaraScoreData(FName(InNiagaraSystemPath), ScoreData);
}

void UKGEffectManager::PrintNiagaraScoreDebugMessage() const
{
}

void UKGEffectManager::SetBattleEffectScoreControlForceEnabled(int Value)
{
	this->NiagaraScoreManager->SetBattleEffectScoreControlForceEnabled(Value);	
}

void UKGEffectManager::SetBattleEffectScoreControlEnabled(bool bEnabled)
{
	this->NiagaraScoreManager->SetBattleEffectScoreControlEnabled(bEnabled);	
}

void UKGEffectManager::SetEnvEffectSlowTickForceEnabled(int Value)
{
	this->NiagaraScoreManager->SetEnvEffectSlowTickForceEnabled(Value);	
}

void UKGEffectManager::SetEnvEffectSlowTickEnabled(bool bEnabled)
{
	this->NiagaraScoreManager->SetEnvEffectSlowTickEnabled(bEnabled);	
}

// 设置环境特效(非战斗特效)的参数, InCheckInterval是检查间隔, InDistance是降频生效距离
void UKGEffectManager::SetEnvEffectConfig(float InCheckInterval, int InDistance) const
{
	this->NiagaraScoreManager->SetEnvEffectConfig(InCheckInterval, InDistance);
}

void UKGEffectManager::SetBattleEffectIgnorePriority4(int Value)
{
	this->NiagaraScoreManager->SetBattleEffectIgnorePriority4(Value);	
}

void UKGEffectManager::SetBattleEffectSlowTickForceEnabled(int Value, bool bIsDistanceCheckEnable) const
{
	this->NiagaraScoreManager->SetBattleEffectSlowTickForceEnabled(Value, bIsDistanceCheckEnable);
}

void UKGEffectManager::SetBattleEffectSlowTickEnabled(bool bIsEnable) const
{
	this->NiagaraScoreManager->SetBattleEffectSlowTickEnabled(bIsEnable);
}

void UKGEffectManager::SetBattleEffectSlowTickConfig(float InDistance) const
{
	this->NiagaraScoreManager->SetBattleEffectSlowTickConfig(InDistance);
}

void UKGEffectManager::SetSlowTickRate(int InSlowTickRate, bool bIsForce) const
{
	this->NiagaraScoreManager->SetSlowTickRate(InSlowTickRate, bIsForce);
}

#pragma endregion Niagara Score

#pragma region Effect NativeNiagaraComponent

uint32 UKGEffectManager::KAPI_EffectManager_AddNativeNiagaraLinearSampleFloatParam(KGObjectID NiagaraComponentID, const FName& ParamName, float StartVal, float EndVal, float Duration)
{
	UNiagaraComponent* NiagaraComponent = Cast<UNiagaraComponent>(KGUtils::GetObjectByID(NiagaraComponentID));
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::KAPI_EffectManager_AddNativeNiagaraLinearSampleFloatParam, invalid niagara component %lld"), NiagaraComponentID);
		return KG_INVALID_UPDATE_TASK_ID;
	}
	
	return AddNativeNiagaraLinearSampleFloatParam(NiagaraComponent, ParamName, StartVal, EndVal, Duration);
}

uint32 UKGEffectManager::KAPI_EffectManager_AddNativeNiagaraCurveParam(KGObjectID NiagaraComponentID, const FName& ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime)
{
	UNiagaraComponent* NiagaraComponent = Cast<UNiagaraComponent>(KGUtils::GetObjectByID(NiagaraComponentID));
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::KAPI_EffectManager_AddNativeNiagaraCurveParam, invalid niagara component %lld"), NiagaraComponentID);
		return KG_INVALID_UPDATE_TASK_ID;
	}
	
	return AddNativeNiagaraCurveParam(NiagaraComponent, ParamName, CurvePath, bNeedRemap, RemapTime);
}

void UKGEffectManager::KAPI_EffectManager_SetNativeNiagaraParamsByParamID(KGObjectID NiagaraComponentID, uint32 ParamID)
{
	UNiagaraComponent* NiagaraComponent = Cast<UNiagaraComponent>(KGUtils::GetObjectByID(NiagaraComponentID));
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::KAPI_EffectManager_SetNativeNiagaraParamsByParamID, invalid niagara component %lld"), NiagaraComponentID);
		return;
	}
	
	SetNativeNiagaraParamsByParamID(NiagaraComponent, ParamID);
}

void UKGEffectManager::KAPI_EffectManager_SetNativeNiagaraParamsByNiagaraTagAndParamID(KGActorID ActorID, const FName& CompTag, uint32 ParamID)
{
	AActor* Actor = KGUtils::GetActorByID(ActorID);
	if (!Actor)
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::KAPI_EffectManager_SetNativeNiagaraParamsByNiagaraTagAndParamID, invalid Actor %lld"), ActorID);
		return;
	}
	
	const auto& Comps = Actor->GetComponentsByTag(UNiagaraComponent::StaticClass(), CompTag);
	if (Comps.Num() == 0)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::KAPI_EffectManager_SetNativeNiagaraParamsByNiagaraTagAndParamID, cannot find comps by tag %s, %s"), 
			*Actor->GetName(), *CompTag.ToString());
		return;
	}
	
	for (const auto& Comp : Comps)
	{
		SetNativeNiagaraParamsByParamID(Cast<UNiagaraComponent>(Comp), ParamID);
	}
}

uint32 UKGEffectManager::AddNativeNiagaraLinearSampleFloatParam(UNiagaraComponent* NiagaraComponent, const FName& ParamName, float StartVal, float EndVal, float Duration)
{
	if (!IsValid(NiagaraComponent))
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::AddLinearSampleFloatParam, invalid niagara component"));
		return KG_INVALID_UPDATE_TASK_ID;
	}
	
	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByLinearSample> TaskPtr = MakeShared<FKGNiagaraUpdateTaskUpdateParamByLinearSample>();
	TaskPtr->SetNativeNiagaraComponentInfo(NiagaraComponent, this);
	TaskPtr->ParamName = ParamName;
	TaskPtr->ValueType = EFKGNiagaraParamLinearSampleValueType::Scalar;
	TaskPtr->OriginStartVal.SetSubtype<float>(StartVal);
	TaskPtr->StartVal.SetSubtype<float>(StartVal);
	TaskPtr->OriginEndVal.SetSubtype<float>(EndVal);
	TaskPtr->EndVal.SetSubtype<float>(EndVal);
	TaskPtr->OriginDuration = Duration;
	TaskPtr->Duration = Duration;
	TaskPtr->bUseNiagaraAccumulatedTime = false;
	
	const auto TaskID = TaskPtr->GetTaskID();
	NativeNiagaraUpdateTasks.Add(TaskID, TaskPtr);
	
	TaskPtr->DoTaskInit(NiagaraComponent);
	return TaskID;
}

uint32 UKGEffectManager::AddNativeNiagaraCurveParam(UNiagaraComponent* NiagaraComponent, const FName& ParamName, const FString& CurvePath, bool bNeedRemap, float RemapTime)
{
	if (!IsValid(NiagaraComponent))
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::AddCurveParam, invalid niagara component"));
		return KG_INVALID_UPDATE_TASK_ID;
	}
	
	TSharedPtr<FKGNiagaraUpdateTaskUpdateParamByCurve> TaskPtr = MakeShared<FKGNiagaraUpdateTaskUpdateParamByCurve>();
	TaskPtr->SetNativeNiagaraComponentInfo(NiagaraComponent, this);
	TaskPtr->ParamName = ParamName;
	TaskPtr->bUseNiagaraAccumulatedTime = false;
	TaskPtr->CurveParams.CurvePath = CurvePath;
	TaskPtr->CurveParams.bNeedRemap = bNeedRemap;
	TaskPtr->CurveParams.RemapTime = RemapTime;
	
	const auto TaskID = TaskPtr->GetTaskID();
	NativeNiagaraUpdateTasks.Add(TaskID, TaskPtr);
	
	TaskPtr->DoTaskInit(NiagaraComponent);
	return TaskID;
}

void UKGEffectManager::RemoveNativeNiagaraUpdateTask(uint32 TaskID)
{
	if (!NativeNiagaraUpdateTasks.Contains(TaskID))
	{
		return;
	}
	
	auto& TaskPtr = NativeNiagaraUpdateTasks[TaskID];
	if (TaskPtr.IsValid())
	{
		TaskPtr->DoTaskDestroy(TaskPtr->GetNativeNiagaraComponent());
	}

	NativeNiagaraUpdateTasks.Remove(TaskID);
}

void UKGEffectManager::SetNativeNiagaraParamsByParamID(UNiagaraComponent* NiagaraComponent, uint32 ParamID)
{
	if (!IsValid(NiagaraComponent))
	{
		UE_LOG(LogEM, Warning, TEXT("UKGEffectManager::SetNiagaraParamsByParamID, invalid niagara component"));
		return;
	}
	
	UKGDataCacheManager* DataCacheManager = UKGDataCacheManager::GetInstance(this);
	if (!DataCacheManager)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::SetNiagaraParamsByParamID, invalid data cache manager"));
		return;
	}
	
	auto* NiagaraParamData = DataCacheManager->GetNiagaraParamsData(ParamID);
	if (!NiagaraParamData)
	{
		UE_LOG(LogEM, Error, TEXT("UKGEffectManager::SetNiagaraParamsByParamID, invalid NiagaraParamData %d"), ParamID);
		return;
	}
	
	for (const auto& Kvp : NiagaraParamData->ScalarParams)
	{
		UE_LOG(LogEM, Log, TEXT("UKGEffectManager::SetNativeNiagaraParamsByParamID, %s, %s, %f"), 
			*NiagaraComponent->GetName(), *Kvp.Key.ToString(), Kvp.Value);
		NiagaraComponent->SetFloatParameter(Kvp.Key, Kvp.Value);
	}
	
	for (const auto& Kvp : NiagaraParamData->LinearSampleScalarParams)
	{
		AddNativeNiagaraLinearSampleFloatParam(NiagaraComponent, Kvp.Key, Kvp.Value.StartVal, Kvp.Value.EndVal, Kvp.Value.Duration);
	}
	
	for (const auto& Kvp : NiagaraParamData->CurveParams)
	{
		AddNativeNiagaraCurveParam(NiagaraComponent, Kvp.Key, Kvp.Value.CurvePath, Kvp.Value.bNeedRemap, Kvp.Value.RemapTime);
	}
}

void UKGEffectManager::UpdateNativeNiagaraUpdateTasks(float DeltaTime)
{
	if (NativeNiagaraUpdateTasks.Num() == 0)
	{
		return;
	}
	
	TArray<uint32, TInlineAllocator<2>> TaskIDsToRemove;
	for (const auto& Kvp : NativeNiagaraUpdateTasks)
	{
		auto& TaskID = Kvp.Key;
		auto& TaskPtr = Kvp.Value;
		if (!TaskPtr.IsValid())
		{
			TaskIDsToRemove.Add(TaskID);
			continue;
		}
		
		auto* NiagaraComponent = TaskPtr->GetNativeNiagaraComponent();
		if (!NiagaraComponent)
		{
			TaskIDsToRemove.Add(TaskID);
			continue;
		}
		
		TaskPtr->DoTaskUpdate(DeltaTime, NiagaraComponent);
		if (TaskPtr->IsFinished() && TaskPtr->ShouldAutoDestroyWhenFinished())
		{
			TaskIDsToRemove.Add(TaskID);	
		}
	}

	for (const auto TaskID : TaskIDsToRemove)
	{
		RemoveNativeNiagaraUpdateTask(TaskID);
	}
}

#pragma endregion Effect NativeNiagaraComponent
