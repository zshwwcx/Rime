﻿#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdatePositionWithArcParams.h"

#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"

bool FKGNiagaraUpdateTaskUpdatePositionWithArcParams::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}

	if (FMath::IsNearlyZero(Duration, UE_KINDA_SMALL_NUMBER) ||
		FMath::IsNearlyZero(Radius, UE_KINDA_SMALL_NUMBER))
	{
		return false;
	}
	
	AccumulatedTime += DeltaTime;
	const float CurRelativeYaw = StartRelativeYaw + AccumulatedTime / Duration * RotateAngle;
	// 这里默认算的是特效component space相对位置
	const FVector& RelativeLocation = FRotator(0.0f, CurRelativeYaw, 0.0f).Vector() * Radius;
	NiagaraComponent->SetVectorParameter(ParamName, RelativeLocation);

	if (AccumulatedTime >= Duration && !bFinished)
	{
		bFinished = true;
	}
	return true;
}
