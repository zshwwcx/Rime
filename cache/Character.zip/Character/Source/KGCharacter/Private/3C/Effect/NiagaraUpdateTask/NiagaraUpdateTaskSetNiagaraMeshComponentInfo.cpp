#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskSetNiagaraMeshComponentInfo.h"

#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "3C/Util/KGUtils.h"
#include "NiagaraComponent.h"
#include "NiagaraFunctionLibrary.h"
#include "Components/MeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"

bool FKGNiagaraUpdateTaskSetNiagaraMeshComponentInfo::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	auto NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskSetNiagaraMeshComponentInfo::Init, NiagaraComponent is null"));
		return false;
	}
	
	if (MeshComponentInfo.bUseCloneMesh)
	{
		OverrideSystemUserVariableMeshComponentWithCloneMesh(
			InTaskTarget, MeshComponentInfo.ComponentID, MeshComponentInfo.bUseNiagaraComponentTransform, MeshComponentInfo.SkeletalMeshFilterBones);
	}
	else
	{
		OverrideSystemUserVariableMeshComponent(InTaskTarget, MeshComponentInfo.ComponentID, MeshComponentInfo.SkeletalMeshFilterBones);
	}

	return true;
}

bool FKGNiagaraUpdateTaskSetNiagaraMeshComponentInfo::OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (CloneActor.IsValid())
	{
		CloneActor->Destroy();
	}
	return true;
}

KGObjectID FKGNiagaraUpdateTaskSetNiagaraMeshComponentInfo::OverrideSystemUserVariableMeshComponentWithCloneMesh(
	const FKGNiagaraUpdateTaskTarget& InTaskTarget, KGObjectID OriginMeshCompID, bool bUseNiagaraComponentTransform, const TArray<FName>& SkeletalMeshFilterBones)
{
	auto NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, NiagaraComponent not ready %s"),
			*InTaskTarget.GetDebugInfo());
		return KG_INVALID_ID;
	}

	UMeshComponent* OriginMeshComponent = Cast<UMeshComponent>(KGUtils::GetObjectByID(OriginMeshCompID));
	if (!OriginMeshComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, invalid OriginMeshCompID %s"),
			*InTaskTarget.GetDebugInfo());
		return KG_INVALID_ID;
	}

	if (!OriginMeshComponent->IsA(UStaticMeshComponent::StaticClass()) && !OriginMeshComponent->IsA(USkeletalMeshComponent::StaticClass()))
	{
		UE_LOG(LogEM, Error,
			TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, need static mesh component or skeletal mesh component, but got %s"),
			*GetNameSafe(OriginMeshComponent->GetClass()));
		return KG_INVALID_ID;
	}

	AActor* OriginActor = OriginMeshComponent->GetOwner();
	if (!OriginActor)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, invalid Owner %s"),
			*InTaskTarget.GetDebugInfo());
		return KG_INVALID_ID;
	}

	UWorld* World = OriginActor->GetWorld();
	if (!World)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, invalid World %s"),
			*InTaskTarget.GetDebugInfo());
		return KG_INVALID_ID;
	}
	
	// 新增component挂接在原始actor上可能会导致原始actor上的逻辑误操作对应的component, 因此这里使用clone actor的方案
	CloneActor = World->SpawnActor<AActor>(AActor::StaticClass());
	if (!CloneActor.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, spawn clone actor failed, %s"),
			*InTaskTarget.GetDebugInfo());
		return KG_INVALID_ID;
	}
	
	if (UStaticMeshComponent* OriginStaticMeshComponent = Cast<UStaticMeshComponent>(OriginMeshComponent))
	{
		UStaticMeshComponent* CloneStaticMeshComponent = Cast<UStaticMeshComponent>(
			CloneActor->AddComponentByClass(UStaticMeshComponent::StaticClass(), false, FTransform::Identity, false));
		if (!CloneStaticMeshComponent)
		{
			UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, failed to create static mesh component %s"),
				*InTaskTarget.GetDebugInfo());
			return KG_INVALID_ID;
		}
		
		// SetActorTransform一定要在AddComponentByClass之前, 这是因为AddComponentByClass之前Actor并没有RootComponent, 设置Transform没有任何意义
		if (bUseNiagaraComponentTransform)
		{
			CloneActor->SetActorTransform(NiagaraComponent->GetComponentTransform());
		}
		else
		{
			CloneActor->SetActorTransform(OriginMeshComponent->GetComponentTransform());
		}
		CloneStaticMeshComponent->SetStaticMesh(OriginStaticMeshComponent->GetStaticMesh());
		CloneStaticMeshComponent->SetCollisionProfileName(OriginMeshComponent->GetCollisionProfileName());
		CloneStaticMeshComponent->SetHiddenInGame(true);
		UNiagaraFunctionLibrary::OverrideSystemUserVariableStaticMeshComponent(NiagaraComponent, ParamName, CloneStaticMeshComponent);

		return KGUtils::GetIDByObject(CloneStaticMeshComponent);
	}

	USkeletalMeshComponent* OriginSkeletalMeshComponent = Cast<USkeletalMeshComponent>(OriginMeshComponent);
	checkf(OriginSkeletalMeshComponent != nullptr, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, invalid mesh component type"));
	
	USkeletalMeshComponent* CloneSkeletalMeshComponent = Cast<USkeletalMeshComponent>(
		CloneActor->AddComponentByClass(USkeletalMeshComponent::StaticClass(), false, FTransform::Identity, false));
	if (!CloneSkeletalMeshComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, failed to create skeletal mesh component %s"),
			*InTaskTarget.GetDebugInfo());
		return KG_INVALID_ID;
	}

	// SetActorTransform一定要在AddComponentByClass之前, 这是因为AddComponentByClass之前Actor并没有RootComponent, 设置Transform没有任何意义
	if (bUseNiagaraComponentTransform)
	{
		CloneActor->SetActorTransform(NiagaraComponent->GetComponentTransform());
	}
	else
	{
		CloneActor->SetActorTransform(OriginMeshComponent->GetComponentTransform());
	}
	CloneSkeletalMeshComponent->SetSkeletalMesh(OriginSkeletalMeshComponent->GetSkeletalMeshAsset());
	CloneSkeletalMeshComponent->SetCollisionProfileName(OriginMeshComponent->GetCollisionProfileName());
	// 暂时先不考虑动画pose的拷贝
	CloneSkeletalMeshComponent->SetHiddenInGame(true);
	UNiagaraFunctionLibrary::OverrideSystemUserVariableSkeletalMeshComponent(NiagaraComponent, ParamName, CloneSkeletalMeshComponent);
	if (SkeletalMeshFilterBones.Num() > 0)
	{
		UNiagaraFunctionLibrary::SetSkeletalMeshDataInterfaceFilteredBones(NiagaraComponent, ParamName, SkeletalMeshFilterBones);	
	}

	return KGUtils::GetIDByObject(CloneSkeletalMeshComponent);
}

void FKGNiagaraUpdateTaskSetNiagaraMeshComponentInfo::OverrideSystemUserVariableMeshComponent(
	const FKGNiagaraUpdateTaskTarget& InTaskTarget, KGObjectID MeshCompID, const TArray<FName>& SkeletalMeshFilterBones)
{
	auto NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponentWithCloneMesh, NiagaraComponent not ready %s"),
			*InTaskTarget.GetDebugInfo());
		return;
	}

	UMeshComponent* MeshComponent = Cast<UMeshComponent>(KGUtils::GetObjectByID(MeshCompID));
	if (!MeshComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponent, invalid OriginMeshCompID %s"),
			*InTaskTarget.GetDebugInfo());
		return;
	}

	if (!MeshComponent->IsA(UStaticMeshComponent::StaticClass()) && !MeshComponent->IsA(USkeletalMeshComponent::StaticClass()))
	{
		UE_LOG(LogEM, Error,
			TEXT("FKGNiagaraUpdateContext::OverrideSystemUserVariableMeshComponent, need static mesh component or skeletal mesh component, but got %s"),
			*GetNameSafe(MeshComponent->GetClass()));
		return;
	}

	if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(MeshComponent))
	{
		UNiagaraFunctionLibrary::OverrideSystemUserVariableStaticMeshComponent(NiagaraComponent, ParamName, StaticMeshComponent);
	}
	else if (USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(MeshComponent))
	{
		UNiagaraFunctionLibrary::OverrideSystemUserVariableSkeletalMeshComponent(NiagaraComponent, ParamName, SkeletalMeshComponent);
		if (SkeletalMeshFilterBones.Num() > 0)
		{
			UNiagaraFunctionLibrary::SetSkeletalMeshDataInterfaceFilteredBones(NiagaraComponent, ParamName, SkeletalMeshFilterBones);	
		}
	}
}

