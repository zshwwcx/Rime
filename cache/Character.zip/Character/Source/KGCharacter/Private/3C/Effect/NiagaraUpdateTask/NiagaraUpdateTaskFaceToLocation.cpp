﻿#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFaceToLocation.h"

#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"

bool FKGNiagaraUpdateTaskFaceToLocation::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (InTaskTarget.NiagaraUpdateContextPtr)
	{
		if (auto* AttachedSpawnInfoPtr = InTaskTarget.NiagaraUpdateContextPtr->PlayNiagaraParams.GetAttachedSpawnInfoPtr())
		{
			CachedInitRelativeYaw = AttachedSpawnInfoPtr->RelativeTrans.Rotator().Yaw;
		}	
	}
	
	return true;
}

bool FKGNiagaraUpdateTaskFaceToLocation::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}

	const FVector& SourceLocation = NiagaraComponent->GetComponentLocation();
	if (FMath::IsNearlyEqual(SourceLocation.X, FacingTargetLocation.X, KINDA_SMALL_NUMBER) &&
		FMath::IsNearlyEqual(SourceLocation.Y, FacingTargetLocation.Y, KINDA_SMALL_NUMBER))
	{
		return false;
	}
	
	const float TargetYaw = (FacingTargetLocation - SourceLocation).GetSafeNormal().Rotation().Yaw;
	FRotator NewRotation = NiagaraComponent->GetComponentRotation();
	NewRotation.Yaw = TargetYaw + CachedInitRelativeYaw;

	NiagaraComponent->SetWorldRotation(NewRotation);
	return true;
}
