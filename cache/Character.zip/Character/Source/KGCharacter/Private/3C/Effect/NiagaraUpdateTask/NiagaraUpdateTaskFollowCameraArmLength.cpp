﻿#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFollowCameraArmLength.h"

#include "3C/Effect/KGEffectManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"

bool FKGNiagaraUpdateTaskFollowCameraArmLength::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (!EffectManager.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskFollowCameraArmLength::Init, invalid EffectManager %s"), *InTaskTarget.GetDebugInfo());
		return false;
	}
	
	CachedPlayerCameraManager = UGameplayStatics::GetPlayerCameraManager(EffectManager->GetWorld(), 0);
	if (!CachedPlayerCameraManager.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskFollowCameraArmLength::Init, invalid PlayerCameraManager %s"), *InTaskTarget.GetDebugInfo());
		return false;
	}

	CachedPlayerCharacter = UGameplayStatics::GetPlayerCharacter(EffectManager->GetWorld(), 0);
	if (!CachedPlayerCharacter.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskFollowCameraArmLength::Init, invalid PlayerCharacter %s"), *InTaskTarget.GetDebugInfo());
		return false;
	}

	return true;
}

bool FKGNiagaraUpdateTaskFollowCameraArmLength::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}
	
	if (!CachedPlayerCameraManager.IsValid() || !CachedPlayerCharacter.IsValid())
	{
		return false;
	}
	
	const float Dist = (CachedPlayerCameraManager->GetCameraLocation() - CachedPlayerCharacter->GetActorLocation()).Size();
	NiagaraComponent->SetVariableFloat(CameraArmLengthParamName, Dist);
	return true;
}
