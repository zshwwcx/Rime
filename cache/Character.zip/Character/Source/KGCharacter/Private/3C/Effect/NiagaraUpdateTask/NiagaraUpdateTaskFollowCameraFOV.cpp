﻿#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFollowCameraFOV.h"

#include "3C/Effect/KGEffectManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"
#include "Kismet/GameplayStatics.h"

bool FKGNiagaraUpdateTaskFollowCameraFOV::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	CachedCameraManager = UGameplayStatics::GetPlayerCameraManager(EffectManager.Get(), 0);
	if (!CachedCameraManager.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskFollowCameraFOV::Init, invalid PlayerCameraManager %s"), *InTaskTarget.GetDebugInfo());
		return false;
	}
	
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskFollowCameraFOV::Init, NiagaraComponent is null, %s"),
			*InTaskTarget.GetDebugInfo());
		return false;
	}

	InitComponentScale = NiagaraComponent->GetComponentScale();
	return true;
}

bool FKGNiagaraUpdateTaskFollowCameraFOV::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}

	if (!CachedCameraManager.IsValid())
	{
		return false;
	}

	float FOV = CachedCameraManager->GetFOVAngle();
	if (FOV >= 180.0f || FOV <= 0.0f)
	{
		NiagaraComponent->SetRelativeScale3D(InitComponentScale);
		return false;
	}

	if (CacheCameraFOV <= 0.0f || !FMath::IsNearlyEqual(CacheCameraFOV, FOV))
	{
		float HalfAngle = FMath::DegreesToRadians(FOV * 0.5f);
		float Scale = FMath::Sin(HalfAngle) / FMath::Cos(HalfAngle);

		NiagaraComponent->SetRelativeScale3D(FVector(InitComponentScale.X, InitComponentScale.Y * Scale, InitComponentScale.Z * Scale));
	}

	CacheCameraFOV = FOV;
	return true;
}
