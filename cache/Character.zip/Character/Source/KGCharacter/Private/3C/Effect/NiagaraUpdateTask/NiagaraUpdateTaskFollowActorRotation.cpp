#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskFollowActorRotation.h"

#include "NiagaraComponent.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "3C/Util/KGUtils.h"

bool FKGNiagaraUpdateTaskFollowActorRotation::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (InTaskTarget.NiagaraUpdateContextPtr)
	{
		const auto& PlayNiagaraParams = InTaskTarget.NiagaraUpdateContextPtr->PlayNiagaraParams;
		if (auto* AttachedSpawnInfoPtr = PlayNiagaraParams.GetAttachedSpawnInfoPtr())
		{
			CachedInitRelativeRotation = AttachedSpawnInfoPtr->RelativeTrans.GetRotation();
		}
	}

	return true;
}

bool FKGNiagaraUpdateTaskFollowActorRotation::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}

	AActor* Spawner = InTaskTarget.GetSpawnerActor();
	if (!IsValid(Spawner))
	{
		return false;
	}
	
	NiagaraComponent->SetWorldRotation(Spawner->GetActorRotation().Quaternion() * CachedInitRelativeRotation);

	return true;
}
