#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskStickOnGround.h"

#include "NiagaraComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "Engine/World.h"
#include "3C/Util/KGUtils.h"

bool FKGNiagaraUpdateTaskStickOnGround::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	SpawnerActor = InTaskTarget.GetSpawnerActor();
	if (!SpawnerActor.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskSetParamByHeightDiff::OnInit, invalid spawner actor, %s"), *InTaskTarget.GetDebugInfo());
		return false;
	}
	
	SetNiagaraStickOnGround(InTaskTarget);
	return true;
}

bool FKGNiagaraUpdateTaskStickOnGround::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	SetNiagaraStickOnGround(InTaskTarget);
	return true;
}

void FKGNiagaraUpdateTaskStickOnGround::SetNiagaraStickOnGround(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComp = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComp)
	{
		return;
	}

	if (!EffectManager.IsValid())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskStickOnGround::OnUpdate, invalid effect manager"));
		return;
	}

	if (!SpawnerActor.IsValid())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskStickOnGround::OnUpdate, invalid spawn actor"));
		return;
	}

	UWorld* World = NiagaraComp->GetWorld();
	if (World == nullptr)
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskStickOnGround::OnUpdate, invalid world"));
		return;
	}

	FVector PivotPos;
	if (bUseNiagaraAsPivotPos)
	{
		PivotPos = NiagaraComp->GetComponentLocation();
	}
	else
	{
		PivotPos = SpawnerActor->GetActorLocation();
	}
	const FVector& TraceStartPos = PivotPos + FVector(0.f, 0.f, GroundCheckUpDistance);
	const FVector& TraceEndPos = PivotPos - FVector(0.f, 0.f, GroundCheckDownDistance);
	
	FHitResult HitResult;
	FCollisionQueryParams Params;
	Params.bTraceComplex = true;
	
	bool bHit = World->LineTraceSingleByChannel(HitResult, TraceStartPos, TraceEndPos, EffectManager->GetGroundCheckObjectType(), Params);
	if (!bHit)
	{
		UE_LOG(LogEM, Verbose, TEXT("FKGNiagaraUpdateTaskStickOnGround::OnUpdate, line trace no hit, StartPos: %s, EndPos: %s"),
			*TraceStartPos.ToString(), *TraceEndPos.ToString());
		NiagaraComp->SetWorldLocation(TraceEndPos);
		return;
	}
	
	NiagaraComp->SetWorldLocation(HitResult.ImpactPoint);
}
