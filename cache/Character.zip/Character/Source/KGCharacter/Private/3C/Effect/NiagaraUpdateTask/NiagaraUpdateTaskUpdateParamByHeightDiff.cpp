#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParamByHeightDiff.h"

#include "Manager/KGCppAssetManager.h"
#include "Misc/MathFormula.h"
#include "NiagaraComponent.h"
#include "Components/CapsuleComponent.h"
#include "3C/Effect/KGEffectManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "3C/Util/KGUtils.h"

bool FKGNiagaraUpdateTaskUpdateParamByHeightDiff::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get());
	if (!AssetManager)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParamByCurve::InternalAddFloatCurveParamsByCurvePath, no asset manager"));
		return false;
	}

	SpawnerActor = InTaskTarget.GetSpawnerActor();
	if (!SpawnerActor.IsValid())
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskSetParamByHeightDiff::OnInit, invalid spawner actor, SpawnerID: %s"), *InTaskTarget.GetDebugInfo());
		return false;
	}
	
	if (UCapsuleComponent* CapsuleComp = SpawnerActor->FindComponentByClass<UCapsuleComponent>())
	{
		CapsuleHalfHeight = CapsuleComp->GetScaledCapsuleHalfHeight();
	}
	else
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskSetParamByHeightDiff::OnInit, spawner actor has no capsule component, Spawner: %s"),
			*SpawnerActor->GetName());
	}

	CurveAssetLoadId = AssetManager->AsyncLoadAsset(
		CurvePath, FAsyncLoadCompleteDelegate::CreateRaw(this, &FKGNiagaraUpdateTaskUpdateParamByHeightDiff::InternalOnFloatCurveAssetLoaded));
	return true;
}

bool FKGNiagaraUpdateTaskUpdateParamByHeightDiff::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComp = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComp)
	{
		return false;
	}
	
	auto* UpdateContextPtr = InTaskTarget.NiagaraUpdateContextPtr;
	if (!UpdateContextPtr)
	{
		return false;
	}

	if (!CurveAsset.IsValid())
	{
		// 资源还在加载中
		return false;
	}

	if (!SpawnerActor.IsValid())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskUpdateParamByHeightDiff::OnUpdate, invalid spawn actor"));
		return false;
	}
	
	if (!EffectManager.IsValid())
	{
		UE_LOG(LogEM, Warning, TEXT("FKGNiagaraUpdateTaskUpdateParamByHeightDiff::OnUpdate, invalid effect manager"));
		return false;
	}

	float CurHeightDiff = SpawnerActor->GetActorLocation().Z - CapsuleHalfHeight - NiagaraComp->GetComponentLocation().Z;
	float HeightDiff;
	if (LastFrameHeightDiff.IsSet())
	{
		HeightDiff = MathFormula::DecayValue(LastFrameHeightDiff.GetValue(), CurHeightDiff, HeightDiffHalfLifeTime, DeltaTime);
	}
	else
	{
		HeightDiff = CurHeightDiff;
	}
	LastFrameHeightDiff = CurHeightDiff;
	float ParamValue = CurveAsset->GetFloatValue(HeightDiff);
	NiagaraComp->SetFloatParameter(ParamName, ParamValue);

	if (bCurNiagaraHidden && ParamValue > UE_KINDA_SMALL_NUMBER)
	{
		EffectManager->UpdateNiagaraHiddenState(
			UpdateContextPtr->NiagaraEffectId, false, static_cast<uint8>(EKGNiagaraHiddenReason::HEIGHT_DIFF_OVER_THRESHOLD),
			VisibilityChangeBlendTime > UE_KINDA_SMALL_NUMBER, VisibilityChangeBlendTime);
		bCurNiagaraHidden = false;
	} 
	else if (!bCurNiagaraHidden && ParamValue <= UE_KINDA_SMALL_NUMBER)
	{
		EffectManager->UpdateNiagaraHiddenState(
			UpdateContextPtr->NiagaraEffectId, true, static_cast<uint8>(EKGNiagaraHiddenReason::HEIGHT_DIFF_OVER_THRESHOLD),
			VisibilityChangeBlendTime > UE_KINDA_SMALL_NUMBER, VisibilityChangeBlendTime);
		bCurNiagaraHidden = true;
	}
	return true;
}

bool FKGNiagaraUpdateTaskUpdateParamByHeightDiff::OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (CurveAssetLoadId != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(CurveAssetLoadId);
		}
		else
		{
			UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskSetParamByHeightDiff::Destroy, no asset manager found"));
		}
		CurveAssetLoadId = 0;
	}
	
	return FKGNiagaraUpdateTaskBase::OnTaskDestroy(InTaskTarget);
}

void FKGNiagaraUpdateTaskUpdateParamByHeightDiff::InternalOnFloatCurveAssetLoaded(int InLoadID, UObject* LoadedAssets)
{
	UCurveFloat* LoadedCurve = Cast<UCurveFloat>(LoadedAssets);
	if (!LoadedCurve)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskSetParamByHeightDiff::InternalOnFloatCurveAssetLoaded, load curve failed: %s"), *CurvePath);
		return;
	}

	CurveAssetLoadId = 0;
	CurveAsset = TStrongObjectPtr(LoadedCurve);
}
