#include "3C/Effect/NiagaraUpdateTask/NiagaraUpdateTaskUpdateParticleColorScale.h"

#include "Manager/KGCppAssetManager.h"
#include "3C/Effect/KGEffectManager.h"
#include "3C/Effect/KGNiagaraUpdateContext.h"
#include "NiagaraComponent.h"

bool FKGNiagaraUpdateTaskUpdateParticleColorScale::OnTaskInit(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get());
	if (!AssetManager)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParticleColorScale::InternalSetParticleColorCurveByAssetPath, no asset manager"));
		return false;
	}

	ParticleColorCurveAssetLoadID = AssetManager->AsyncLoadAsset(
		ParticleColorScaleUpdateCurve, FAsyncLoadCompleteDelegate::CreateRaw(
		this, &FKGNiagaraUpdateTaskUpdateParticleColorScale::InternalOnParticleColorCurveAssetLoaded));
	return true;
}

bool FKGNiagaraUpdateTaskUpdateParticleColorScale::OnTaskUpdate(float DeltaTime, const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	UNiagaraComponent* NiagaraComponent = InTaskTarget.GetNiagaraComponent();
	if (!NiagaraComponent)
	{
		return false;
	}

	if (!CurveFloatEvalHelper.IsValid())
	{
		return false;
	}
	
	float AccumulatedTimeUsed = AccumulatedTime;
	AccumulatedTime += DeltaTime;
	if (bUseNiagaraAccumulatedTime && InTaskTarget.NiagaraUpdateContextPtr)
	{
		AccumulatedTimeUsed = InTaskTarget.NiagaraUpdateContextPtr->AccumulatedTime;
	}
		
	float CurveVal = 0.0f;
	if (!CurveFloatEvalHelper.GetValue(AccumulatedTimeUsed, CurveVal))
	{
		UE_LOG(LogEM, Error, TEXT("Eval curve float failed"));
		return false;
	}
	
	if (InTaskTarget.NiagaraUpdateContextPtr)
	{
		CurveVal *= InTaskTarget.NiagaraUpdateContextPtr->GetBaseTransparencyScaleFactor();
	}
	else if (EffectManager.IsValid())
	{
		CurveVal *= EffectManager->GetEnvTransparencyScaleFactor();
	}
	
	NiagaraComponent->SetParticleColorScale(CurveVal);
		
	if (CurveFloatEvalHelper.DoesTimeReachEnd(AccumulatedTimeUsed) && !bFinished)
	{
		bFinished = true;
	}
	return true;
}

bool FKGNiagaraUpdateTaskUpdateParticleColorScale::OnTaskDestroy(const FKGNiagaraUpdateTaskTarget& InTaskTarget)
{
	if (ParticleColorCurveAssetLoadID != 0)
	{
		if (UKGCppAssetManager* AssetManager = UKGCppAssetManager::GetInstance(EffectManager.Get()))
		{
			AssetManager->CancelAsyncLoadByLoadID(ParticleColorCurveAssetLoadID);
		}
		else
		{
			UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParticleColorScale::Destroy, no asset manager found"));
		}
	}
	return true;
}

void FKGNiagaraUpdateTaskUpdateParticleColorScale::InternalOnParticleColorCurveAssetLoaded(int InLoadID, UObject* LoadedAssets)
{
	auto* OwnerContextPtr = GetNiagaraUpdateContext();
	if (!OwnerContextPtr)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParticleColorScale::InternalOnParticleColorCurveAssetLoaded, OwnerContextPtr is null"));
		return;
	}
	
	ParticleColorCurveAssetLoadID = 0;
	UCurveFloat* CurveFloat = Cast<UCurveFloat>(LoadedAssets);
	if (!CurveFloat)
	{
		UE_LOG(LogEM, Error, TEXT("FKGNiagaraUpdateTaskUpdateParticleColorScale::InternalOnParticleColorCurveAssetLoaded, invalid ParticleColorScaleUpdateCurve %s, %s"),
			*ParticleColorScaleUpdateCurve, *OwnerContextPtr->ToString());
		return;
	}
	
	const bool bNeedRemap = !FMath::IsNearlyZero(ParticleColorScaleCurveTime);
	CurveFloatEvalHelper.InitEvalParams(bNeedRemap, ParticleColorScaleCurveTime, false, CurveFloat);
}
